NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 E  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -3.0999999046325684e+00
    phi[0,1]  R94       -2.2400000095367432e+00
    phi[0,1]  R95       -2.2400000095367432e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       -3.0999999046325684e+00
    phi[0,1]  R98       -2.5699999332427979e+00
    phi[0,1]  R99       -2.5699999332427979e+00
    phi[0,1]  R100      -3.0999999046325684e+00
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -2.0899999141693115e+00
    phi[0,1]  R103      -2.0899999141693115e+00
    phi[0,1]  R104      -3.0999999046325684e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      1.2621669769287109e+00
    phi[0,1]  R107      -1.8700447678565979e-01
    phi[0,1]  R108      -2.3810358345508575e-01
    phi[0,1]  R109      -1.9615067541599274e-01
    phi[0,1]  R110      1.0863114595413208e+00
    phi[0,1]  R111      1.4630975723266602e+00
    phi[0,1]  R112      2.1433849334716797e+00
    phi[0,1]  R113      5.7174688577651978e-01
    phi[0,1]  R114      -8.8971102237701416e-01
    phi[0,1]  R115      7.5941520929336548e-01
    phi[0,1]  R116      -2.6377239227294922e+00
    phi[0,1]  R117      -1.87230384349823
    phi[0,1]  R118      -3.2113018035888672e+00
    phi[0,1]  R119      -1.9259686470031738e+00
    phi[0,1]  R120      -2.3777470588684082e+00
    phi[0,1]  R121      -1.5696136951446533e+00
    phi[0,1]  R122      -2.0015113353729248e+00
    phi[0,1]  R123      -1.4809193611145020e+00
    phi[0,1]  R124      -2.2183518409729004e+00
    phi[0,1]  R125      -1.1367689371109009e+00
    phi[0,1]  R126      -2.3354647159576416e+00
    phi[0,1]  R127      -0.445394903421402
    phi[0,1]  R128      -1.2232719659805298e+00
    phi[0,1]  R129      -9.1452288627624512e-01
    phi[0,1]  R130      -1.7560687065124512e+00
    phi[0,1]  R131      -6.6290742158889771e-01
    phi[0,1]  R132      -1.3124618530273438e+00
    phi[0,1]  R133      -1.8474997282028198e+00
    phi[0,1]  R134      -1.4468442201614380e+00
    phi[0,1]  R135      -2.1146330833435059e+00
    phi[0,1]  R136      -2.9739284515380859e-01
    phi[0,1]  R137      -1.0260802507400513e+00
    phi[0,1]  R138      -1.8242663145065308e+00
    phi[0,1]  R139      -2.4387869834899902e+00
    phi[0,1]  R140      -5.9454232454299927e-01
    phi[0,1]  R141      -2.3536629676818848e+00
    phi[0,1]  R142      -5.1163703203201294e-01
    phi[0,1]  R143      -3.1615219116210938e+00
    phi[0,1]  R144      -3.4288191795349121e+00
    phi[0,1]  R145      -2.11822247505188
    phi[0,1]  R146      -2.20697283744812
    phi[0,1]  R147      -1.3179209232330322e+00
    phi[0,1]  R148      -6.5040457248687744e-01
    phi[0,1]  R149      -7.5624758005142212e-01
    phi[0,1]  R150      1.2640888690948486e+00
    phi[0,1]  R151      -4.2234754562377930e+00
    phi[0,1]  R152      -6.0573083162307739e-01
    phi[0,1]  R153      -1.1357687711715698e+00
    phi[0,1]  R154      -2.2926783561706543e+00
    phi[0,1]  R155      4.9104818701744080e-01
    phi[0,1]  R156      -3.4803483486175537e+00
    phi[0,1]  R157      -7.1242088079452515e-01
    phi[0,1]  R158      -3.8439631462097168e+00
    phi[0,1]  R159      -1.9073326587677002e+00
    phi[0,1]  R160      -1.6850266456604004e+00
    phi[0,1]  R161      2.2834914922714233e-01
    phi[0,1]  R162      -2.7735722064971924e+00
    phi[0,1]  R163      3.9466607570648193e-01
    phi[0,1]  R164      -2.2161221504211426e+00
    phi[0,1]  R165      1.9455415010452271e-01
    phi[0,1]  R166      3.0833598971366882e-01
    phi[0,1]  R167      1.4661832153797150e-01
    phi[0,1]  R168      -1.4160670340061188e-01
    phi[0,1]  R169      3.2561904191970825e-01
    phi[0,1]  R170      1.1721019744873047e+00
    phi[0,1]  R171      -9.2350691556930542e-02
    phi[0,1]  R172      1.1272922903299332e-01
    phi[0,1]  R173      -5.5888897180557251e-01
    phi[0,1]  R174      5.6324616074562073e-02
    phi[0,1]  R175      -8.3351694047451019e-02
    phi[0,1]  R176      1.5122046470642090e+00
    phi[0,1]  R177      1.8786925077438354e+00
    phi[0,1]  R178      1.3538198471069336e+00
    phi[0,1]  R179      1.1434762477874756e+00
    phi[0,1]  R180      1.3845786452293396e-01
    phi[0,1]  R181      5.8665180206298828e-01
    phi[0,1]  R182      4.7123658657073975e-01
    phi[0,1]  R183      3.4744834899902344e-01
    phi[0,1]  R184      3.9218023419380188e-01
    phi[0,1]  R185      7.9502648115158081e-01
    phi[0,1]  R186      -1.3512454032897949e+00
    phi[0,1]  R187      -2.1624910831451416e+00
    phi[0,1]  R188      -1.4589997529983521e+00
    phi[0,1]  R189      -2.1291601657867432e+00
    phi[0,1]  R190      -2.8630278110504150e+00
    phi[0,1]  R191      -2.8188045024871826e+00
    phi[0,1]  R192      -3.1261193752288818e+00
    phi[0,1]  R193      -2.5161948204040527e+00
    phi[0,1]  R194      -2.4665021896362305e+00
    phi[0,1]  R195      -1.9759575128555298e+00
    phi[0,1]  R196      -1.7280288934707642e+00
    phi[0,1]  R197      -1.8815766572952271e+00
    phi[0,1]  R198      -2.0937781333923340e+00
    phi[0,1]  R199      -1.2506715059280396e+00
    phi[0,1]  R200      -9.4535273313522339e-01
    phi[0,1]  R201      -4.7492614388465881e-01
    phi[0,1]  R202      -1.8106349706649780e+00
    phi[0,1]  R203      1.5474514961242676e+00
    phi[0,1]  R204      2.24182391166687
    phi[0,1]  R205      1.8333379030227661e+00
    phi[0,1]  R206      -2.3807556629180908e+00
    phi[0,1]  R207      -2.0846297740936279e+00
    phi[0,1]  R208      -2.6277689933776855e+00
    phi[0,1]  R209      -8.0714064836502075e-01
    phi[0,1]  R210      1.9428071975708008e+00
    phi[0,1]  R211      -8.7230563163757324e-01
    phi[0,1]  R212      -8.4345024824142456e-01
    phi[0,1]  R213      -4.2313066124916077e-01
    phi[0,1]  R214      -1.0141084343194962e-01
    phi[0,1]  R215      -6.0488724708557129e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R216      -3.0999999046325684e+00
    phi[1,0]  R217      -3.0999999046325684e+00
    phi[1,0]  R218      -2.2400000095367432e+00
    phi[1,0]  R219      -2.2400000095367432e+00
    phi[1,0]  R220      -3.0999999046325684e+00
    phi[1,0]  R221      -3.0999999046325684e+00
    phi[1,0]  R222      -2.5699999332427979e+00
    phi[1,0]  R223      -2.5699999332427979e+00
    phi[1,0]  R224      -3.0999999046325684e+00
    phi[1,0]  R225      -3.0999999046325684e+00
    phi[1,0]  R226      -2.0899999141693115e+00
    phi[1,0]  R227      -2.0899999141693115e+00
    phi[1,0]  R228      -3.0999999046325684e+00
    phi[1,0]  R229      -3.0999999046325684e+00
    phi[1,0]  R230      3.0833598971366882e-01
    phi[1,0]  R231      1.4661832153797150e-01
    phi[1,0]  R232      -1.4160670340061188e-01
    phi[1,0]  R233      3.2561904191970825e-01
    phi[1,0]  R234      1.1721019744873047e+00
    phi[1,0]  R235      -9.2350691556930542e-02
    phi[1,0]  R236      1.1272922903299332e-01
    phi[1,0]  R237      -5.5888897180557251e-01
    phi[1,0]  R238      5.6324616074562073e-02
    phi[1,0]  R239      -8.3351694047451019e-02
    phi[1,0]  R240      1.5122046470642090e+00
    phi[1,0]  R241      1.8786925077438354e+00
    phi[1,0]  R242      1.3538198471069336e+00
    phi[1,0]  R243      1.1434762477874756e+00
    phi[1,0]  R244      1.3845786452293396e-01
    phi[1,0]  R245      5.8665180206298828e-01
    phi[1,0]  R246      4.7123658657073975e-01
    phi[1,0]  R247      3.4744834899902344e-01
    phi[1,0]  R248      3.9218023419380188e-01
    phi[1,0]  R249      7.9502648115158081e-01
    phi[1,0]  R250      -1.3512454032897949e+00
    phi[1,0]  R251      -2.1624910831451416e+00
    phi[1,0]  R252      -1.4589997529983521e+00
    phi[1,0]  R253      -2.1291601657867432e+00
    phi[1,0]  R254      -2.8630278110504150e+00
    phi[1,0]  R255      -2.8188045024871826e+00
    phi[1,0]  R256      -3.1261193752288818e+00
    phi[1,0]  R257      -2.5161948204040527e+00
    phi[1,0]  R258      -2.4665021896362305e+00
    phi[1,0]  R259      -1.9759575128555298e+00
    phi[1,0]  R260      -1.7280288934707642e+00
    phi[1,0]  R261      -1.8815766572952271e+00
    phi[1,0]  R262      -2.0937781333923340e+00
    phi[1,0]  R263      -1.2506715059280396e+00
    phi[1,0]  R264      -9.4535273313522339e-01
    phi[1,0]  R265      -4.7492614388465881e-01
    phi[1,0]  R266      -1.8106349706649780e+00
    phi[1,0]  R267      1.5474514961242676e+00
    phi[1,0]  R268      2.24182391166687
    phi[1,0]  R269      1.8333379030227661e+00
    phi[1,0]  R270      -2.3807556629180908e+00
    phi[1,0]  R271      -2.0846297740936279e+00
    phi[1,0]  R272      -2.6277689933776855e+00
    phi[1,0]  R273      -8.0714064836502075e-01
    phi[1,0]  R274      1.9428071975708008e+00
    phi[1,0]  R275      -8.7230563163757324e-01
    phi[1,0]  R276      -8.4345024824142456e-01
    phi[1,0]  R277      -4.2313066124916077e-01
    phi[1,0]  R278      -1.0141084343194962e-01
    phi[1,0]  R279      -6.0488724708557129e-01
    phi[1,0]  R280      1.2621669769287109e+00
    phi[1,0]  R281      -1.8700447678565979e-01
    phi[1,0]  R282      -2.3810358345508575e-01
    phi[1,0]  R283      -1.9615067541599274e-01
    phi[1,0]  R284      1.0863114595413208e+00
    phi[1,0]  R285      1.4630975723266602e+00
    phi[1,0]  R286      2.1433849334716797e+00
    phi[1,0]  R287      5.7174688577651978e-01
    phi[1,0]  R288      -8.8971102237701416e-01
    phi[1,0]  R289      7.5941520929336548e-01
    phi[1,0]  R290      -2.6377239227294922e+00
    phi[1,0]  R291      -1.87230384349823
    phi[1,0]  R292      -3.2113018035888672e+00
    phi[1,0]  R293      -1.9259686470031738e+00
    phi[1,0]  R294      -2.3777470588684082e+00
    phi[1,0]  R295      -1.5696136951446533e+00
    phi[1,0]  R296      -2.0015113353729248e+00
    phi[1,0]  R297      -1.4809193611145020e+00
    phi[1,0]  R298      -2.2183518409729004e+00
    phi[1,0]  R299      -1.1367689371109009e+00
    phi[1,0]  R300      -2.3354647159576416e+00
    phi[1,0]  R301      -0.445394903421402
    phi[1,0]  R302      -1.2232719659805298e+00
    phi[1,0]  R303      -9.1452288627624512e-01
    phi[1,0]  R304      -1.7560687065124512e+00
    phi[1,0]  R305      -6.6290742158889771e-01
    phi[1,0]  R306      -1.3124618530273438e+00
    phi[1,0]  R307      -1.8474997282028198e+00
    phi[1,0]  R308      -1.4468442201614380e+00
    phi[1,0]  R309      -2.1146330833435059e+00
    phi[1,0]  R310      -2.9739284515380859e-01
    phi[1,0]  R311      -1.0260802507400513e+00
    phi[1,0]  R312      -1.8242663145065308e+00
    phi[1,0]  R313      -2.4387869834899902e+00
    phi[1,0]  R314      -5.9454232454299927e-01
    phi[1,0]  R315      -2.3536629676818848e+00
    phi[1,0]  R316      -5.1163703203201294e-01
    phi[1,0]  R317      -3.1615219116210938e+00
    phi[1,0]  R318      -3.4288191795349121e+00
    phi[1,0]  R319      -2.11822247505188
    phi[1,0]  R320      -2.20697283744812
    phi[1,0]  R321      -1.3179209232330322e+00
    phi[1,0]  R322      -6.5040457248687744e-01
    phi[1,0]  R323      -7.5624758005142212e-01
    phi[1,0]  R324      1.2640888690948486e+00
    phi[1,0]  R325      -4.2234754562377930e+00
    phi[1,0]  R326      -6.0573083162307739e-01
    phi[1,0]  R327      -1.1357687711715698e+00
    phi[1,0]  R328      -2.2926783561706543e+00
    phi[1,0]  R329      4.9104818701744080e-01
    phi[1,0]  R330      -3.4803483486175537e+00
    phi[1,0]  R331      -7.1242088079452515e-01
    phi[1,0]  R332      -3.8439631462097168e+00
    phi[1,0]  R333      -1.9073326587677002e+00
    phi[1,0]  R334      -1.6850266456604004e+00
    phi[1,0]  R335      2.2834914922714233e-01
    phi[1,0]  R336      -2.7735722064971924e+00
    phi[1,0]  R337      3.9466607570648193e-01
    phi[1,0]  R338      -2.2161221504211426e+00
    phi[1,0]  R339      1.9455415010452271e-01
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R340      -3.0999999046325684e+00
    phi[0,3]  R341      -3.0999999046325684e+00
    phi[0,3]  R342      -2.2400000095367432e+00
    phi[0,3]  R343      -2.2400000095367432e+00
    phi[0,3]  R344      -3.0999999046325684e+00
    phi[0,3]  R345      -3.0999999046325684e+00
    phi[0,3]  R346      -2.5699999332427979e+00
    phi[0,3]  R347      -2.5699999332427979e+00
    phi[0,3]  R348      -3.0999999046325684e+00
    phi[0,3]  R349      -3.0999999046325684e+00
    phi[0,3]  R350      -2.0899999141693115e+00
    phi[0,3]  R351      -2.0899999141693115e+00
    phi[0,3]  R352      -3.0999999046325684e+00
    phi[0,3]  R353      -3.0999999046325684e+00
    phi[0,3]  R354      1.2621669769287109e+00
    phi[0,3]  R355      -1.8700447678565979e-01
    phi[0,3]  R356      -2.3810358345508575e-01
    phi[0,3]  R357      -1.9615067541599274e-01
    phi[0,3]  R358      1.0863114595413208e+00
    phi[0,3]  R359      1.4630975723266602e+00
    phi[0,3]  R360      2.1433849334716797e+00
    phi[0,3]  R361      5.7174688577651978e-01
    phi[0,3]  R362      -8.8971102237701416e-01
    phi[0,3]  R363      7.5941520929336548e-01
    phi[0,3]  R364      -2.6377239227294922e+00
    phi[0,3]  R365      -1.87230384349823
    phi[0,3]  R366      -3.2113018035888672e+00
    phi[0,3]  R367      -1.9259686470031738e+00
    phi[0,3]  R368      -2.3777470588684082e+00
    phi[0,3]  R369      -1.5696136951446533e+00
    phi[0,3]  R370      -2.0015113353729248e+00
    phi[0,3]  R371      -1.4809193611145020e+00
    phi[0,3]  R372      -2.2183518409729004e+00
    phi[0,3]  R373      -1.1367689371109009e+00
    phi[0,3]  R374      -2.3354647159576416e+00
    phi[0,3]  R375      -0.445394903421402
    phi[0,3]  R376      -1.2232719659805298e+00
    phi[0,3]  R377      -9.1452288627624512e-01
    phi[0,3]  R378      -1.7560687065124512e+00
    phi[0,3]  R379      -6.6290742158889771e-01
    phi[0,3]  R380      -1.3124618530273438e+00
    phi[0,3]  R381      -1.8474997282028198e+00
    phi[0,3]  R382      -1.4468442201614380e+00
    phi[0,3]  R383      -2.1146330833435059e+00
    phi[0,3]  R384      -2.9739284515380859e-01
    phi[0,3]  R385      -1.0260802507400513e+00
    phi[0,3]  R386      -1.8242663145065308e+00
    phi[0,3]  R387      -2.4387869834899902e+00
    phi[0,3]  R388      -5.9454232454299927e-01
    phi[0,3]  R389      -2.3536629676818848e+00
    phi[0,3]  R390      -5.1163703203201294e-01
    phi[0,3]  R391      -3.1615219116210938e+00
    phi[0,3]  R392      -3.4288191795349121e+00
    phi[0,3]  R393      -2.11822247505188
    phi[0,3]  R394      -2.20697283744812
    phi[0,3]  R395      -1.3179209232330322e+00
    phi[0,3]  R396      -6.5040457248687744e-01
    phi[0,3]  R397      -7.5624758005142212e-01
    phi[0,3]  R398      1.2640888690948486e+00
    phi[0,3]  R399      -4.2234754562377930e+00
    phi[0,3]  R400      -6.0573083162307739e-01
    phi[0,3]  R401      -1.1357687711715698e+00
    phi[0,3]  R402      -2.2926783561706543e+00
    phi[0,3]  R403      4.9104818701744080e-01
    phi[0,3]  R404      -3.4803483486175537e+00
    phi[0,3]  R405      -7.1242088079452515e-01
    phi[0,3]  R406      -3.8439631462097168e+00
    phi[0,3]  R407      -1.9073326587677002e+00
    phi[0,3]  R408      -1.6850266456604004e+00
    phi[0,3]  R409      2.2834914922714233e-01
    phi[0,3]  R410      -2.7735722064971924e+00
    phi[0,3]  R411      3.9466607570648193e-01
    phi[0,3]  R412      -2.2161221504211426e+00
    phi[0,3]  R413      1.9455415010452271e-01
    phi[0,3]  R414      7.3822331428527832e-01
    phi[0,3]  R415      8.9754724502563477e-01
    phi[0,3]  R416      1.0670480728149414e+00
    phi[0,3]  R417      7.5229823589324951e-01
    phi[0,3]  R418      1.8569492101669312e+00
    phi[0,3]  R419      1.1916958093643188e+00
    phi[0,3]  R420      8.1400975584983826e-02
    phi[0,3]  R421      3.3278873562812805e-01
    phi[0,3]  R422      -6.2773388624191284e-01
    phi[0,3]  R423      -4.6158069372177124e-01
    phi[0,3]  R424      -1.2588771581649780e+00
    phi[0,3]  R425      -2.5696113109588623e+00
    phi[0,3]  R426      -2.2249560356140137e+00
    phi[0,3]  R427      -2.7997941970825195e+00
    phi[0,3]  R428      -1.3001343011856079e+00
    phi[0,3]  R429      -6.4240384101867676e-01
    phi[0,3]  R430      -1.8600250482559204e+00
    phi[0,3]  R431      -1.8854376077651978e+00
    phi[0,3]  R432      -2.0086333751678467e+00
    phi[0,3]  R433      -2.1496284008026123e+00
    phi[0,3]  R434      -9.0118497610092163e-01
    phi[0,3]  R435      -2.1802146434783936e+00
    phi[0,3]  R436      -2.0869106054306030e-01
    phi[0,3]  R437      -2.0088760852813721e+00
    phi[0,3]  R438      -7.4766385555267334e-01
    phi[0,3]  R439      -2.2666380405426025e+00
    phi[0,3]  R440      -2.3804028034210205e+00
    phi[0,3]  R441      -8.3778429031372070e-01
    phi[0,3]  R442      -1.7409626245498657e+00
    phi[0,3]  R443      1.3137128353118896e+00
    phi[0,3]  R444      -5.0773626565933228e-01
    phi[0,3]  R445      -1.3846476376056671e-01
    phi[0,3]  R446      -2.7457067966461182e+00
    phi[0,3]  R447      -2.2210865020751953e+00
    phi[0,3]  R448      4.4964618980884552e-02
    phi[0,3]  R449      -2.0459055900573730e+00
    phi[0,3]  R450      -1.0858291387557983e+00
    phi[0,3]  R451      -4.2121219635009766e-01
    phi[0,3]  R452      -1.06468665599823
    phi[0,3]  R453      -4.1692990064620972e-01
    phi[0,3]  R454      1.0826381444931030e+00
    phi[0,3]  R455      -4.6248561143875122e-01
    phi[0,3]  R456      1.1655737161636353e+00
    phi[0,3]  R457      -3.5086565017700195e+00
    phi[0,3]  R458      -3.2664747238159180e+00
    phi[0,3]  R459      -9.7572129964828491e-01
    phi[0,3]  R460      -2.4977467060089111e+00
    phi[0,3]  R461      -2.0630528926849365e+00
    phi[0,3]  R462      -1.3015854358673096e+00
    phi[0,3]  R463      -2.5785512924194336e+00
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R464      -3.0999999046325684e+00
    phi[3,0]  R465      -3.0999999046325684e+00
    phi[3,0]  R466      -2.2400000095367432e+00
    phi[3,0]  R467      -2.2400000095367432e+00
    phi[3,0]  R468      -3.0999999046325684e+00
    phi[3,0]  R469      -3.0999999046325684e+00
    phi[3,0]  R470      -2.5699999332427979e+00
    phi[3,0]  R471      -2.5699999332427979e+00
    phi[3,0]  R472      -3.0999999046325684e+00
    phi[3,0]  R473      -3.0999999046325684e+00
    phi[3,0]  R474      -2.0899999141693115e+00
    phi[3,0]  R475      -2.0899999141693115e+00
    phi[3,0]  R476      -3.0999999046325684e+00
    phi[3,0]  R477      -3.0999999046325684e+00
    phi[3,0]  R478      7.3822331428527832e-01
    phi[3,0]  R479      8.9754724502563477e-01
    phi[3,0]  R480      1.0670480728149414e+00
    phi[3,0]  R481      7.5229823589324951e-01
    phi[3,0]  R482      1.8569492101669312e+00
    phi[3,0]  R483      1.1916958093643188e+00
    phi[3,0]  R484      8.1400975584983826e-02
    phi[3,0]  R485      3.3278873562812805e-01
    phi[3,0]  R486      -6.2773388624191284e-01
    phi[3,0]  R487      -4.6158069372177124e-01
    phi[3,0]  R488      -1.2588771581649780e+00
    phi[3,0]  R489      -2.5696113109588623e+00
    phi[3,0]  R490      -2.2249560356140137e+00
    phi[3,0]  R491      -2.7997941970825195e+00
    phi[3,0]  R492      -1.3001343011856079e+00
    phi[3,0]  R493      -6.4240384101867676e-01
    phi[3,0]  R494      -1.8600250482559204e+00
    phi[3,0]  R495      -1.8854376077651978e+00
    phi[3,0]  R496      -2.0086333751678467e+00
    phi[3,0]  R497      -2.1496284008026123e+00
    phi[3,0]  R498      -9.0118497610092163e-01
    phi[3,0]  R499      -2.1802146434783936e+00
    phi[3,0]  R500      -2.0869106054306030e-01
    phi[3,0]  R501      -2.0088760852813721e+00
    phi[3,0]  R502      -7.4766385555267334e-01
    phi[3,0]  R503      -2.2666380405426025e+00
    phi[3,0]  R504      -2.3804028034210205e+00
    phi[3,0]  R505      -8.3778429031372070e-01
    phi[3,0]  R506      -1.7409626245498657e+00
    phi[3,0]  R507      1.3137128353118896e+00
    phi[3,0]  R508      -5.0773626565933228e-01
    phi[3,0]  R509      -1.3846476376056671e-01
    phi[3,0]  R510      -2.7457067966461182e+00
    phi[3,0]  R511      -2.2210865020751953e+00
    phi[3,0]  R512      4.4964618980884552e-02
    phi[3,0]  R513      -2.0459055900573730e+00
    phi[3,0]  R514      -1.0858291387557983e+00
    phi[3,0]  R515      -4.2121219635009766e-01
    phi[3,0]  R516      -1.06468665599823
    phi[3,0]  R517      -4.1692990064620972e-01
    phi[3,0]  R518      1.0826381444931030e+00
    phi[3,0]  R519      -4.6248561143875122e-01
    phi[3,0]  R520      1.1655737161636353e+00
    phi[3,0]  R521      -3.5086565017700195e+00
    phi[3,0]  R522      -3.2664747238159180e+00
    phi[3,0]  R523      -9.7572129964828491e-01
    phi[3,0]  R524      -2.4977467060089111e+00
    phi[3,0]  R525      -2.0630528926849365e+00
    phi[3,0]  R526      -1.3015854358673096e+00
    phi[3,0]  R527      -2.5785512924194336e+00
    phi[3,0]  R528      1.2621669769287109e+00
    phi[3,0]  R529      -1.8700447678565979e-01
    phi[3,0]  R530      -2.3810358345508575e-01
    phi[3,0]  R531      -1.9615067541599274e-01
    phi[3,0]  R532      1.0863114595413208e+00
    phi[3,0]  R533      1.4630975723266602e+00
    phi[3,0]  R534      2.1433849334716797e+00
    phi[3,0]  R535      5.7174688577651978e-01
    phi[3,0]  R536      -8.8971102237701416e-01
    phi[3,0]  R537      7.5941520929336548e-01
    phi[3,0]  R538      -2.6377239227294922e+00
    phi[3,0]  R539      -1.87230384349823
    phi[3,0]  R540      -3.2113018035888672e+00
    phi[3,0]  R541      -1.9259686470031738e+00
    phi[3,0]  R542      -2.3777470588684082e+00
    phi[3,0]  R543      -1.5696136951446533e+00
    phi[3,0]  R544      -2.0015113353729248e+00
    phi[3,0]  R545      -1.4809193611145020e+00
    phi[3,0]  R546      -2.2183518409729004e+00
    phi[3,0]  R547      -1.1367689371109009e+00
    phi[3,0]  R548      -2.3354647159576416e+00
    phi[3,0]  R549      -0.445394903421402
    phi[3,0]  R550      -1.2232719659805298e+00
    phi[3,0]  R551      -9.1452288627624512e-01
    phi[3,0]  R552      -1.7560687065124512e+00
    phi[3,0]  R553      -6.6290742158889771e-01
    phi[3,0]  R554      -1.3124618530273438e+00
    phi[3,0]  R555      -1.8474997282028198e+00
    phi[3,0]  R556      -1.4468442201614380e+00
    phi[3,0]  R557      -2.1146330833435059e+00
    phi[3,0]  R558      -2.9739284515380859e-01
    phi[3,0]  R559      -1.0260802507400513e+00
    phi[3,0]  R560      -1.8242663145065308e+00
    phi[3,0]  R561      -2.4387869834899902e+00
    phi[3,0]  R562      -5.9454232454299927e-01
    phi[3,0]  R563      -2.3536629676818848e+00
    phi[3,0]  R564      -5.1163703203201294e-01
    phi[3,0]  R565      -3.1615219116210938e+00
    phi[3,0]  R566      -3.4288191795349121e+00
    phi[3,0]  R567      -2.11822247505188
    phi[3,0]  R568      -2.20697283744812
    phi[3,0]  R569      -1.3179209232330322e+00
    phi[3,0]  R570      -6.5040457248687744e-01
    phi[3,0]  R571      -7.5624758005142212e-01
    phi[3,0]  R572      1.2640888690948486e+00
    phi[3,0]  R573      -4.2234754562377930e+00
    phi[3,0]  R574      -6.0573083162307739e-01
    phi[3,0]  R575      -1.1357687711715698e+00
    phi[3,0]  R576      -2.2926783561706543e+00
    phi[3,0]  R577      4.9104818701744080e-01
    phi[3,0]  R578      -3.4803483486175537e+00
    phi[3,0]  R579      -7.1242088079452515e-01
    phi[3,0]  R580      -3.8439631462097168e+00
    phi[3,0]  R581      -1.9073326587677002e+00
    phi[3,0]  R582      -1.6850266456604004e+00
    phi[3,0]  R583      2.2834914922714233e-01
    phi[3,0]  R584      -2.7735722064971924e+00
    phi[3,0]  R585      3.9466607570648193e-01
    phi[3,0]  R586      -2.2161221504211426e+00
    phi[3,0]  R587      1.9455415010452271e-01
    phi[10,0]  R0        -1
    phi[10,0]  R2        0.755894890876533
    phi[10,0]  R3        -1.3610207536303220e+00
    phi[10,0]  R4        -2.6529262301834429e+00
    phi[10,0]  R5        1.1396941064726960e+00
    phi[10,0]  R6        -1.1530987079493753e+00
    phi[10,0]  R7        -1.1636170550572769e+00
    phi[10,0]  R8        -2.9247029633787682e+00
    phi[10,0]  R90       1
    phi[10,0]  R588      -3.8558947955091014e+00
    phi[10,0]  R589      -2.3441050137560353e+00
    phi[10,0]  R590      -8.7897925590642112e-01
    phi[10,0]  R591      -3.6010207631670652e+00
    phi[10,0]  R592      -4.4707367444912549e-01
    phi[10,0]  R593      -5.7529261348160112e+00
    phi[10,0]  R594      -3.7096940397154938e+00
    phi[10,0]  R595      -1.4303058267701019e+00
    phi[10,0]  R596      -1.9469011966831931e+00
    phi[10,0]  R597      -4.2530986125819439e+00
    phi[10,0]  R598      -9.2638285911203466e-01
    phi[10,0]  R599      -3.2536169692265884e+00
    phi[10,0]  R600      -1.7529694125380013e-01
    phi[10,0]  R601      -6.0247028680113370e+00
    phi[10,0]  R602      -1.1880885596500912e-01
    phi[10,0]  R603      -1.3276372244161427e+00
    phi[10,0]  R604      -2.3820032392369610e+00
    phi[10,0]  R605      -2.0244543298712689e+00
    phi[10,0]  R606      -1.7404830589264542e-01
    phi[10,0]  R607      -1.7871308106468664e-01
    phi[10,0]  R608      -1.9048116505298829e-01
    phi[10,0]  R609      -2.4617842481025720e-01
    phi[10,0]  R610      -1.6356554872494524e+00
    phi[10,0]  R611      -4.2871500628266190e-01
    phi[10,0]  R612      -1.7113539183150772e-01
    phi[10,0]  R613      -2.0914696076782846e-01
    phi[10,0]  R614      -2.6273103599112124e-01
    phi[10,0]  R615      -3.0464699619834712e-01
    phi[10,0]  R616      -3.1756223680372253e-01
    phi[10,0]  R617      -3.7107275003230455e-01
    phi[10,0]  R618      -3.7466205279225551e-01
    phi[10,0]  R619      -3.7489437571896334e-01
    phi[10,0]  R620      -4.1076731070860362e-01
    phi[10,0]  R621      -4.1625707317027205e-01
    phi[10,0]  R622      -2.1589013205618590e-01
    phi[10,0]  R623      -2.8144622241339468e-01
    phi[10,0]  R624      -3.4521059639461371e-01
    phi[10,0]  R625      -3.4832755719668751e-01
    phi[10,0]  R626      -3.8006473376478844e-01
    phi[10,0]  R627      -3.9402596969136194e-01
    phi[10,0]  R628      -3.9930360530095266e-01
    phi[10,0]  R629      -4.1592950383619565e-01
    phi[10,0]  R630      -4.1829604119551611e-01
    phi[10,0]  R631      -4.2290567448987093e-01
    phi[10,0]  R632      -1.6452919682193434e-01
    phi[10,0]  R633      -2.0634641176653767e-01
    phi[10,0]  R634      -2.2833052652756702e-01
    phi[10,0]  R635      -2.6424151335614043e-01
    phi[10,0]  R636      -2.7395330710251059e-01
    phi[10,0]  R637      -2.7804432691636283e-01
    phi[10,0]  R638      -2.8837984452236737e-01
    phi[10,0]  R639      -2.9515836875497614e-01
    phi[10,0]  R640      -3.2928183312706594e-01
    phi[10,0]  R641      -3.4821092384151164e-01
    phi[10,0]  R642      -2.1333633739046709e-01
    phi[10,0]  R643      -2.2946617241945533e-01
    phi[10,0]  R644      -2.4303324968756979e-01
    phi[10,0]  R645      -2.6030492843693132e-01
    phi[10,0]  R646      -2.9466518273863640e-01
    phi[10,0]  R647      -3.3918685087746514e-01
    phi[10,0]  R648      -3.6111732260699742e-01
    phi[10,0]  R649      -4.2135948626836695e-01
    phi[10,0]  R650      -4.8276228003184873e-01
    phi[10,0]  R651      -4.8823852297046344e-01
    phi[10,0]  R652      -2.8193392592483590e-01
    phi[10,0]  R653      -3.5143279291451229e-01
    phi[10,0]  R654      -4.0352891935428348e-01
    phi[10,0]  R655      -4.5109438215527065e-01
    phi[10,0]  R656      -4.6220649788009127e-01
    phi[10,0]  R657      -5.1890132649417553e-01
    phi[10,0]  R658      -5.5730942588231880e-01
    phi[10,0]  R659      -5.6425342767231645e-01
    phi[10,0]  R660      -5.8835314761906732e-01
    phi[10,0]  R661      -5.8942618887024190e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R662      -3.0999999046325684e+00
    phi[1,2]  R663      -3.0999999046325684e+00
    phi[1,2]  R664      -2.2400000095367432e+00
    phi[1,2]  R665      -2.2400000095367432e+00
    phi[1,2]  R666      -3.0999999046325684e+00
    phi[1,2]  R667      -3.0999999046325684e+00
    phi[1,2]  R668      -2.5699999332427979e+00
    phi[1,2]  R669      -2.5699999332427979e+00
    phi[1,2]  R670      -3.0999999046325684e+00
    phi[1,2]  R671      -3.0999999046325684e+00
    phi[1,2]  R672      -2.0899999141693115e+00
    phi[1,2]  R673      -2.0899999141693115e+00
    phi[1,2]  R674      -3.0999999046325684e+00
    phi[1,2]  R675      -3.0999999046325684e+00
    phi[1,2]  R676      3.0833598971366882e-01
    phi[1,2]  R677      1.4661832153797150e-01
    phi[1,2]  R678      -1.4160670340061188e-01
    phi[1,2]  R679      3.2561904191970825e-01
    phi[1,2]  R680      1.1721019744873047e+00
    phi[1,2]  R681      -9.2350691556930542e-02
    phi[1,2]  R682      1.1272922903299332e-01
    phi[1,2]  R683      -5.5888897180557251e-01
    phi[1,2]  R684      5.6324616074562073e-02
    phi[1,2]  R685      -8.3351694047451019e-02
    phi[1,2]  R686      1.5122046470642090e+00
    phi[1,2]  R687      1.8786925077438354e+00
    phi[1,2]  R688      1.3538198471069336e+00
    phi[1,2]  R689      1.1434762477874756e+00
    phi[1,2]  R690      1.3845786452293396e-01
    phi[1,2]  R691      5.8665180206298828e-01
    phi[1,2]  R692      4.7123658657073975e-01
    phi[1,2]  R693      3.4744834899902344e-01
    phi[1,2]  R694      3.9218023419380188e-01
    phi[1,2]  R695      7.9502648115158081e-01
    phi[1,2]  R696      -1.3512454032897949e+00
    phi[1,2]  R697      -2.1624910831451416e+00
    phi[1,2]  R698      -1.4589997529983521e+00
    phi[1,2]  R699      -2.1291601657867432e+00
    phi[1,2]  R700      -2.8630278110504150e+00
    phi[1,2]  R701      -2.8188045024871826e+00
    phi[1,2]  R702      -3.1261193752288818e+00
    phi[1,2]  R703      -2.5161948204040527e+00
    phi[1,2]  R704      -2.4665021896362305e+00
    phi[1,2]  R705      -1.9759575128555298e+00
    phi[1,2]  R706      -1.7280288934707642e+00
    phi[1,2]  R707      -1.8815766572952271e+00
    phi[1,2]  R708      -2.0937781333923340e+00
    phi[1,2]  R709      -1.2506715059280396e+00
    phi[1,2]  R710      -9.4535273313522339e-01
    phi[1,2]  R711      -4.7492614388465881e-01
    phi[1,2]  R712      -1.8106349706649780e+00
    phi[1,2]  R713      1.5474514961242676e+00
    phi[1,2]  R714      2.24182391166687
    phi[1,2]  R715      1.8333379030227661e+00
    phi[1,2]  R716      -2.3807556629180908e+00
    phi[1,2]  R717      -2.0846297740936279e+00
    phi[1,2]  R718      -2.6277689933776855e+00
    phi[1,2]  R719      -8.0714064836502075e-01
    phi[1,2]  R720      1.9428071975708008e+00
    phi[1,2]  R721      -8.7230563163757324e-01
    phi[1,2]  R722      -8.4345024824142456e-01
    phi[1,2]  R723      -4.2313066124916077e-01
    phi[1,2]  R724      -1.0141084343194962e-01
    phi[1,2]  R725      -6.0488724708557129e-01
    phi[1,2]  R726      2.2216885089874268e+00
    phi[1,2]  R727      3.2516045570373535e+00
    phi[1,2]  R728      2.57004451751709
    phi[1,2]  R729      1.6635321378707886e+00
    phi[1,2]  R730      2.6930334568023682e+00
    phi[1,2]  R731      1.0987802743911743e+00
    phi[1,2]  R732      1.5404895544052124e+00
    phi[1,2]  R733      1.5247035026550293e+00
    phi[1,2]  R734      2.6107805967330933e-01
    phi[1,2]  R735      -1.0657718032598495e-01
    phi[1,2]  R736      -1.6624023914337158e+00
    phi[1,2]  R737      -1.5109596252441406e+00
    phi[1,2]  R738      -2.0542309284210205e+00
    phi[1,2]  R739      -0.836368203163147
    phi[1,2]  R740      -1.2578293085098267e+00
    phi[1,2]  R741      -1.6636800765991211e+00
    phi[1,2]  R742      -1.3232668638229370e+00
    phi[1,2]  R743      -9.3648397922515869e-01
    phi[1,2]  R744      -2.2336082458496094e+00
    phi[1,2]  R745      -8.7310045957565308e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R746      -3.0999999046325684e+00
    phi[2,1]  R747      -3.0999999046325684e+00
    phi[2,1]  R748      -2.2400000095367432e+00
    phi[2,1]  R749      -2.2400000095367432e+00
    phi[2,1]  R750      -3.0999999046325684e+00
    phi[2,1]  R751      -3.0999999046325684e+00
    phi[2,1]  R752      -2.5699999332427979e+00
    phi[2,1]  R753      -2.5699999332427979e+00
    phi[2,1]  R754      -3.0999999046325684e+00
    phi[2,1]  R755      -3.0999999046325684e+00
    phi[2,1]  R756      -2.0899999141693115e+00
    phi[2,1]  R757      -2.0899999141693115e+00
    phi[2,1]  R758      -3.0999999046325684e+00
    phi[2,1]  R759      -3.0999999046325684e+00
    phi[2,1]  R760      2.2216885089874268e+00
    phi[2,1]  R761      3.2516045570373535e+00
    phi[2,1]  R762      2.57004451751709
    phi[2,1]  R763      1.6635321378707886e+00
    phi[2,1]  R764      2.6930334568023682e+00
    phi[2,1]  R765      1.0987802743911743e+00
    phi[2,1]  R766      1.5404895544052124e+00
    phi[2,1]  R767      1.5247035026550293e+00
    phi[2,1]  R768      2.6107805967330933e-01
    phi[2,1]  R769      -1.0657718032598495e-01
    phi[2,1]  R770      -1.6624023914337158e+00
    phi[2,1]  R771      -1.5109596252441406e+00
    phi[2,1]  R772      -2.0542309284210205e+00
    phi[2,1]  R773      -0.836368203163147
    phi[2,1]  R774      -1.2578293085098267e+00
    phi[2,1]  R775      -1.6636800765991211e+00
    phi[2,1]  R776      -1.3232668638229370e+00
    phi[2,1]  R777      -9.3648397922515869e-01
    phi[2,1]  R778      -2.2336082458496094e+00
    phi[2,1]  R779      -8.7310045957565308e-01
    phi[2,1]  R780      3.0833598971366882e-01
    phi[2,1]  R781      1.4661832153797150e-01
    phi[2,1]  R782      -1.4160670340061188e-01
    phi[2,1]  R783      3.2561904191970825e-01
    phi[2,1]  R784      1.1721019744873047e+00
    phi[2,1]  R785      -9.2350691556930542e-02
    phi[2,1]  R786      1.1272922903299332e-01
    phi[2,1]  R787      -5.5888897180557251e-01
    phi[2,1]  R788      5.6324616074562073e-02
    phi[2,1]  R789      -8.3351694047451019e-02
    phi[2,1]  R790      1.5122046470642090e+00
    phi[2,1]  R791      1.8786925077438354e+00
    phi[2,1]  R792      1.3538198471069336e+00
    phi[2,1]  R793      1.1434762477874756e+00
    phi[2,1]  R794      1.3845786452293396e-01
    phi[2,1]  R795      5.8665180206298828e-01
    phi[2,1]  R796      4.7123658657073975e-01
    phi[2,1]  R797      3.4744834899902344e-01
    phi[2,1]  R798      3.9218023419380188e-01
    phi[2,1]  R799      7.9502648115158081e-01
    phi[2,1]  R800      -1.3512454032897949e+00
    phi[2,1]  R801      -2.1624910831451416e+00
    phi[2,1]  R802      -1.4589997529983521e+00
    phi[2,1]  R803      -2.1291601657867432e+00
    phi[2,1]  R804      -2.8630278110504150e+00
    phi[2,1]  R805      -2.8188045024871826e+00
    phi[2,1]  R806      -3.1261193752288818e+00
    phi[2,1]  R807      -2.5161948204040527e+00
    phi[2,1]  R808      -2.4665021896362305e+00
    phi[2,1]  R809      -1.9759575128555298e+00
    phi[2,1]  R810      -1.7280288934707642e+00
    phi[2,1]  R811      -1.8815766572952271e+00
    phi[2,1]  R812      -2.0937781333923340e+00
    phi[2,1]  R813      -1.2506715059280396e+00
    phi[2,1]  R814      -9.4535273313522339e-01
    phi[2,1]  R815      -4.7492614388465881e-01
    phi[2,1]  R816      -1.8106349706649780e+00
    phi[2,1]  R817      1.5474514961242676e+00
    phi[2,1]  R818      2.24182391166687
    phi[2,1]  R819      1.8333379030227661e+00
    phi[2,1]  R820      -2.3807556629180908e+00
    phi[2,1]  R821      -2.0846297740936279e+00
    phi[2,1]  R822      -2.6277689933776855e+00
    phi[2,1]  R823      -8.0714064836502075e-01
    phi[2,1]  R824      1.9428071975708008e+00
    phi[2,1]  R825      -8.7230563163757324e-01
    phi[2,1]  R826      -8.4345024824142456e-01
    phi[2,1]  R827      -4.2313066124916077e-01
    phi[2,1]  R828      -1.0141084343194962e-01
    phi[2,1]  R829      -6.0488724708557129e-01
    phi[2,8]  R18       1
    phi[2,8]  R19       1
    phi[2,8]  R72       -1
    phi[2,8]  R830      -3.0999999046325684e+00
    phi[2,8]  R831      -3.0999999046325684e+00
    phi[2,8]  R832      -2.2400000095367432e+00
    phi[2,8]  R833      -2.2400000095367432e+00
    phi[2,8]  R834      -3.0999999046325684e+00
    phi[2,8]  R835      -3.0999999046325684e+00
    phi[2,8]  R836      -2.5699999332427979e+00
    phi[2,8]  R837      -2.5699999332427979e+00
    phi[2,8]  R838      -3.0999999046325684e+00
    phi[2,8]  R839      -3.0999999046325684e+00
    phi[2,8]  R840      -2.0899999141693115e+00
    phi[2,8]  R841      -2.0899999141693115e+00
    phi[2,8]  R842      -3.0999999046325684e+00
    phi[2,8]  R843      -3.0999999046325684e+00
    phi[2,8]  R844      2.2216885089874268e+00
    phi[2,8]  R845      3.2516045570373535e+00
    phi[2,8]  R846      2.57004451751709
    phi[2,8]  R847      1.6635321378707886e+00
    phi[2,8]  R848      2.6930334568023682e+00
    phi[2,8]  R849      1.0987802743911743e+00
    phi[2,8]  R850      1.5404895544052124e+00
    phi[2,8]  R851      1.5247035026550293e+00
    phi[2,8]  R852      2.6107805967330933e-01
    phi[2,8]  R853      -1.0657718032598495e-01
    phi[2,8]  R854      -1.6624023914337158e+00
    phi[2,8]  R855      -1.5109596252441406e+00
    phi[2,8]  R856      -2.0542309284210205e+00
    phi[2,8]  R857      -0.836368203163147
    phi[2,8]  R858      -1.2578293085098267e+00
    phi[2,8]  R859      -1.6636800765991211e+00
    phi[2,8]  R860      -1.3232668638229370e+00
    phi[2,8]  R861      -9.3648397922515869e-01
    phi[2,8]  R862      -2.2336082458496094e+00
    phi[2,8]  R863      -8.7310045957565308e-01
    phi[2,8]  R864      2.1634502410888672e+00
    phi[2,8]  R865      2.6221516132354736e+00
    phi[2,8]  R866      1.7823657989501953e+00
    phi[2,8]  R867      1.9324274063110352e+00
    phi[2,8]  R868      1.7130719423294067e+00
    phi[2,8]  R869      2.3169786930084229e+00
    phi[2,8]  R870      1.7829190492630005e+00
    phi[2,8]  R871      3.5299210548400879e+00
    phi[2,8]  R872      3.2690410614013672e+00
    phi[2,8]  R873      2.75260591506958
    phi[2,8]  R874      -1.9525480270385742e+00
    phi[2,8]  R875      -1.4175292253494263e+00
    phi[2,8]  R876      -2.1970111131668091e-01
    phi[2,8]  R877      -4.1523718833923340e+00
    phi[2,8]  R878      -2.0246975421905518e+00
    phi[2,8]  R879      -2.4550344944000244e+00
    phi[2,8]  R880      -3.2680863142013550e-01
    phi[2,8]  R881      -2.5848476886749268e+00
    phi[2,8]  R882      7.4764645099639893e-01
    phi[2,8]  R883      -3.1898903846740723e+00
    phi[2,8]  R884      -5.4546165466308594e-01
    phi[2,8]  R885      -1.1594562530517578e+00
    phi[2,8]  R886      -3.4043356776237488e-01
    phi[2,8]  R887      -2.9325668811798096e+00
    phi[2,8]  R888      -2.8987884521484375e+00
    phi[2,8]  R889      0.979177713394165
    phi[2,8]  R890      1.3944133520126343e+00
    phi[2,8]  R891      -3.6619114875793457e+00
    phi[2,8]  R892      -2.1798050403594971e+00
    phi[2,8]  R893      -7.4842017889022827e-01
    phi[2,8]  R894      -2.3533110618591309e+00
    phi[2,8]  R895      -3.6799725890159607e-01
    phi[2,8]  R896      1.0972465276718140e+00
    phi[2,8]  R897      -3.1089329719543457e+00
    phi[2,8]  R898      -3.3948142528533936e+00
    phi[2,8]  R899      -3.2857654094696045e+00
    phi[2,8]  R900      -3.1955838203430176e+00
    phi[2,8]  R901      -4.8639902472496033e-01
    phi[2,8]  R902      -1.7044667005538940e+00
    phi[2,8]  R903      -1.0529565811157227e+00
    phi[2,8]  R904      7.2772687673568726e-01
    phi[2,8]  R905      -3.6033661365509033e+00
    phi[2,8]  R906      -2.7375929355621338e+00
    phi[2,8]  R907      -0.211117684841156
    phi[2,8]  R908      -1.1090617179870605e+00
    phi[2,8]  R909      -2.6246135234832764e+00
    phi[2,8]  R910      -4.2373692989349365e-01
    phi[2,8]  R911      -2.4279634952545166e+00
    phi[2,8]  R912      -1.2560037374496460e+00
    phi[2,8]  R913      -1.9961750507354736e+00
    phi[2,8]  R914      -6.0812622308731079e-01
    phi[2,8]  R915      -3.2924744486808777e-01
    phi[2,8]  R916      -2.0905160903930664e+00
    phi[2,8]  R917      -3.5219824314117432e+00
    phi[2,8]  R918      -3.0424852371215820e+00
    phi[2,8]  R919      2.1669404506683350e+00
    phi[2,8]  R920      3.1997540593147278e-01
    phi[2,8]  R921      -1.3156360387802124e+00
    phi[2,8]  R922      -1.7798343896865845e+00
    phi[2,8]  R923      -1.2834142446517944e+00
    phi[2,8]  R924      1.3197565078735352e+00
    phi[2,8]  R925      -0.632849395275116
    phi[2,8]  R926      -1.4857529401779175e+00
    phi[2,8]  R927      1.5595804452896118e+00
    phi[2,8]  R928      -4.1266790032386780e-01
    phi[2,8]  R929      -6.7522341012954712e-01
    phi[2,8]  R930      -4.1413583755493164e+00
    phi[2,8]  R931      6.6483139991760254e-01
    phi[2,8]  R932      -3.6913793087005615e+00
    phi[2,8]  R933      -2.3175554275512695e+00
    phi[2,8]  R934      2.2089569568634033e+00
    phi[2,8]  R935      1.3484935760498047e+00
    phi[2,8]  R936      -4.8041185736656189e-01
    phi[2,8]  R937      -2.6452083587646484e+00
    phi[2,8]  R938      2.8764119148254395e+00
    phi[2,8]  R939      -3.4812183380126953e+00
    phi[2,8]  R940      -2.5862739086151123e+00
    phi[2,8]  R941      -2.5641758441925049e+00
    phi[2,8]  R942      -3.3103356361389160e+00
    phi[2,8]  R943      -2.3477177619934082e+00
    phi[2,8]  R944      -3.2525966167449951e+00
    phi[2,8]  R945      -2.9624862670898438e+00
    phi[2,8]  R946      -2.0929579734802246e+00
    phi[2,8]  R947      -4.2364826202392578e+00
    phi[2,8]  R948      -1.8103140592575073e+00
    phi[2,8]  R949      2.9038208723068237e-01
    phi[2,8]  R950      1.6057683229446411e+00
    phi[2,8]  R951      1.0093998908996582e-01
    phi[2,8]  R952      1.1565150022506714e+00
    phi[2,8]  R953      1.1449407339096069e+00
    phi[8,2]  R18       -1
    phi[8,2]  R72       1
    phi[8,2]  R73       1
    phi[8,2]  R954      -3.0999999046325684e+00
    phi[8,2]  R955      -3.0999999046325684e+00
    phi[8,2]  R956      -2.2400000095367432e+00
    phi[8,2]  R957      -2.2400000095367432e+00
    phi[8,2]  R958      -3.0999999046325684e+00
    phi[8,2]  R959      -3.0999999046325684e+00
    phi[8,2]  R960      -2.5699999332427979e+00
    phi[8,2]  R961      -2.5699999332427979e+00
    phi[8,2]  R962      -3.0999999046325684e+00
    phi[8,2]  R963      -3.0999999046325684e+00
    phi[8,2]  R964      -2.0899999141693115e+00
    phi[8,2]  R965      -2.0899999141693115e+00
    phi[8,2]  R966      -3.0999999046325684e+00
    phi[8,2]  R967      -3.0999999046325684e+00
    phi[8,2]  R968      2.1634502410888672e+00
    phi[8,2]  R969      2.6221516132354736e+00
    phi[8,2]  R970      1.7823657989501953e+00
    phi[8,2]  R971      1.9324274063110352e+00
    phi[8,2]  R972      1.7130719423294067e+00
    phi[8,2]  R973      2.3169786930084229e+00
    phi[8,2]  R974      1.7829190492630005e+00
    phi[8,2]  R975      3.5299210548400879e+00
    phi[8,2]  R976      3.2690410614013672e+00
    phi[8,2]  R977      2.75260591506958
    phi[8,2]  R978      -1.9525480270385742e+00
    phi[8,2]  R979      -1.4175292253494263e+00
    phi[8,2]  R980      -2.1970111131668091e-01
    phi[8,2]  R981      -4.1523718833923340e+00
    phi[8,2]  R982      -2.0246975421905518e+00
    phi[8,2]  R983      -2.4550344944000244e+00
    phi[8,2]  R984      -3.2680863142013550e-01
    phi[8,2]  R985      -2.5848476886749268e+00
    phi[8,2]  R986      7.4764645099639893e-01
    phi[8,2]  R987      -3.1898903846740723e+00
    phi[8,2]  R988      -5.4546165466308594e-01
    phi[8,2]  R989      -1.1594562530517578e+00
    phi[8,2]  R990      -3.4043356776237488e-01
    phi[8,2]  R991      -2.9325668811798096e+00
    phi[8,2]  R992      -2.8987884521484375e+00
    phi[8,2]  R993      0.979177713394165
    phi[8,2]  R994      1.3944133520126343e+00
    phi[8,2]  R995      -3.6619114875793457e+00
    phi[8,2]  R996      -2.1798050403594971e+00
    phi[8,2]  R997      -7.4842017889022827e-01
    phi[8,2]  R998      -2.3533110618591309e+00
    phi[8,2]  R999      -3.6799725890159607e-01
    phi[8,2]  R1000     1.0972465276718140e+00
    phi[8,2]  R1001     -3.1089329719543457e+00
    phi[8,2]  R1002     -3.3948142528533936e+00
    phi[8,2]  R1003     -3.2857654094696045e+00
    phi[8,2]  R1004     -3.1955838203430176e+00
    phi[8,2]  R1005     -4.8639902472496033e-01
    phi[8,2]  R1006     -1.7044667005538940e+00
    phi[8,2]  R1007     -1.0529565811157227e+00
    phi[8,2]  R1008     7.2772687673568726e-01
    phi[8,2]  R1009     -3.6033661365509033e+00
    phi[8,2]  R1010     -2.7375929355621338e+00
    phi[8,2]  R1011     -0.211117684841156
    phi[8,2]  R1012     -1.1090617179870605e+00
    phi[8,2]  R1013     -2.6246135234832764e+00
    phi[8,2]  R1014     -4.2373692989349365e-01
    phi[8,2]  R1015     -2.4279634952545166e+00
    phi[8,2]  R1016     -1.2560037374496460e+00
    phi[8,2]  R1017     -1.9961750507354736e+00
    phi[8,2]  R1018     -6.0812622308731079e-01
    phi[8,2]  R1019     -3.2924744486808777e-01
    phi[8,2]  R1020     -2.0905160903930664e+00
    phi[8,2]  R1021     -3.5219824314117432e+00
    phi[8,2]  R1022     -3.0424852371215820e+00
    phi[8,2]  R1023     2.1669404506683350e+00
    phi[8,2]  R1024     3.1997540593147278e-01
    phi[8,2]  R1025     -1.3156360387802124e+00
    phi[8,2]  R1026     -1.7798343896865845e+00
    phi[8,2]  R1027     -1.2834142446517944e+00
    phi[8,2]  R1028     1.3197565078735352e+00
    phi[8,2]  R1029     -0.632849395275116
    phi[8,2]  R1030     -1.4857529401779175e+00
    phi[8,2]  R1031     1.5595804452896118e+00
    phi[8,2]  R1032     -4.1266790032386780e-01
    phi[8,2]  R1033     -6.7522341012954712e-01
    phi[8,2]  R1034     -4.1413583755493164e+00
    phi[8,2]  R1035     6.6483139991760254e-01
    phi[8,2]  R1036     -3.6913793087005615e+00
    phi[8,2]  R1037     -2.3175554275512695e+00
    phi[8,2]  R1038     2.2089569568634033e+00
    phi[8,2]  R1039     1.3484935760498047e+00
    phi[8,2]  R1040     -4.8041185736656189e-01
    phi[8,2]  R1041     -2.6452083587646484e+00
    phi[8,2]  R1042     2.8764119148254395e+00
    phi[8,2]  R1043     -3.4812183380126953e+00
    phi[8,2]  R1044     -2.5862739086151123e+00
    phi[8,2]  R1045     -2.5641758441925049e+00
    phi[8,2]  R1046     -3.3103356361389160e+00
    phi[8,2]  R1047     -2.3477177619934082e+00
    phi[8,2]  R1048     -3.2525966167449951e+00
    phi[8,2]  R1049     -2.9624862670898438e+00
    phi[8,2]  R1050     -2.0929579734802246e+00
    phi[8,2]  R1051     -4.2364826202392578e+00
    phi[8,2]  R1052     -1.8103140592575073e+00
    phi[8,2]  R1053     2.9038208723068237e-01
    phi[8,2]  R1054     1.6057683229446411e+00
    phi[8,2]  R1055     1.0093998908996582e-01
    phi[8,2]  R1056     1.1565150022506714e+00
    phi[8,2]  R1057     1.1449407339096069e+00
    phi[8,2]  R1058     2.2216885089874268e+00
    phi[8,2]  R1059     3.2516045570373535e+00
    phi[8,2]  R1060     2.57004451751709
    phi[8,2]  R1061     1.6635321378707886e+00
    phi[8,2]  R1062     2.6930334568023682e+00
    phi[8,2]  R1063     1.0987802743911743e+00
    phi[8,2]  R1064     1.5404895544052124e+00
    phi[8,2]  R1065     1.5247035026550293e+00
    phi[8,2]  R1066     2.6107805967330933e-01
    phi[8,2]  R1067     -1.0657718032598495e-01
    phi[8,2]  R1068     -1.6624023914337158e+00
    phi[8,2]  R1069     -1.5109596252441406e+00
    phi[8,2]  R1070     -2.0542309284210205e+00
    phi[8,2]  R1071     -0.836368203163147
    phi[8,2]  R1072     -1.2578293085098267e+00
    phi[8,2]  R1073     -1.6636800765991211e+00
    phi[8,2]  R1074     -1.3232668638229370e+00
    phi[8,2]  R1075     -9.3648397922515869e-01
    phi[8,2]  R1076     -2.2336082458496094e+00
    phi[8,2]  R1077     -8.7310045957565308e-01
    phi[2,9]  R18       1
    phi[2,9]  R19       1
    phi[2,9]  R81       -1
    phi[2,9]  R1078     -3.0999999046325684e+00
    phi[2,9]  R1079     -3.0999999046325684e+00
    phi[2,9]  R1080     -2.2400000095367432e+00
    phi[2,9]  R1081     -2.2400000095367432e+00
    phi[2,9]  R1082     -3.0999999046325684e+00
    phi[2,9]  R1083     -3.0999999046325684e+00
    phi[2,9]  R1084     -2.5699999332427979e+00
    phi[2,9]  R1085     -2.5699999332427979e+00
    phi[2,9]  R1086     -3.0999999046325684e+00
    phi[2,9]  R1087     -3.0999999046325684e+00
    phi[2,9]  R1088     -2.0899999141693115e+00
    phi[2,9]  R1089     -2.0899999141693115e+00
    phi[2,9]  R1090     -3.0999999046325684e+00
    phi[2,9]  R1091     -3.0999999046325684e+00
    phi[2,9]  R1092     2.2216885089874268e+00
    phi[2,9]  R1093     3.2516045570373535e+00
    phi[2,9]  R1094     2.57004451751709
    phi[2,9]  R1095     1.6635321378707886e+00
    phi[2,9]  R1096     2.6930334568023682e+00
    phi[2,9]  R1097     1.0987802743911743e+00
    phi[2,9]  R1098     1.5404895544052124e+00
    phi[2,9]  R1099     1.5247035026550293e+00
    phi[2,9]  R1100     2.6107805967330933e-01
    phi[2,9]  R1101     -1.0657718032598495e-01
    phi[2,9]  R1102     -1.6624023914337158e+00
    phi[2,9]  R1103     -1.5109596252441406e+00
    phi[2,9]  R1104     -2.0542309284210205e+00
    phi[2,9]  R1105     -0.836368203163147
    phi[2,9]  R1106     -1.2578293085098267e+00
    phi[2,9]  R1107     -1.6636800765991211e+00
    phi[2,9]  R1108     -1.3232668638229370e+00
    phi[2,9]  R1109     -9.3648397922515869e-01
    phi[2,9]  R1110     -2.2336082458496094e+00
    phi[2,9]  R1111     -8.7310045957565308e-01
    phi[2,9]  R1112     3.4904921054840088e+00
    phi[2,9]  R1113     1.4727970361709595e+00
    phi[2,9]  R1114     2.5210235118865967e+00
    phi[2,9]  R1115     1.7337300777435303e+00
    phi[2,9]  R1116     1.9884278774261475e+00
    phi[2,9]  R1117     3.4749491214752197e+00
    phi[2,9]  R1118     4.2311649322509766e+00
    phi[2,9]  R1119     2.8107554912567139e+00
    phi[2,9]  R1120     2.5325076580047607e+00
    phi[2,9]  R1121     -2.2708638012409210e-01
    phi[2,9]  R1122     -4.5547986030578613e-01
    phi[2,9]  R1123     -2.4728229045867920e+00
    phi[2,9]  R1124     1.2274993658065796e+00
    phi[2,9]  R1125     -1.9573992490768433e-01
    phi[2,9]  R1126     -4.8519638180732727e-01
    phi[2,9]  R1127     -3.7261424064636230e+00
    phi[2,9]  R1128     -2.5186202526092529e+00
    phi[2,9]  R1129     -8.3140349388122559e-01
    phi[2,9]  R1130     -1.6850026845932007e+00
    phi[2,9]  R1131     -2.5643837451934814e+00
    phi[2,9]  R1132     -3.0810458660125732e+00
    phi[2,9]  R1133     -2.7657559514045715e-01
    phi[2,9]  R1134     -1.4796851873397827e+00
    phi[2,9]  R1135     2.4014606475830078e+00
    phi[2,9]  R1136     -9.0325701236724854e-01
    phi[2,9]  R1137     -2.3807880878448486e+00
    phi[2,9]  R1138     -1.1103235483169556e+00
    phi[2,9]  R1139     2.2838933467864990e+00
    phi[2,9]  R1140     -5.0104662775993347e-02
    phi[2,9]  R1141     -4.0013399124145508e+00
    phi[2,9]  R1142     -1.1639746427536011e+00
    phi[2,9]  R1143     -2.55611515045166
    phi[2,9]  R1144     2.0806839466094971e+00
    phi[2,9]  R1145     -1.9095526933670044e+00
    phi[2,9]  R1146     -7.8921101987361908e-02
    phi[2,9]  R1147     -1.9729385375976562e+00
    phi[2,9]  R1148     2.6759386062622070e+00
    phi[2,9]  R1149     4.6213066577911377e-01
    phi[2,9]  R1150     -4.4570879936218262e+00
    phi[2,9]  R1151     4.0773463249206543e+00
    phi[2,9]  R1152     -2.1155569553375244e+00
    phi[2,9]  R1153     -3.4662010669708252e+00
    phi[2,9]  R1154     -2.2347145080566406e+00
    phi[2,9]  R1155     2.4870846271514893e+00
    phi[2,9]  R1156     -1.4745303988456726e-01
    phi[2,9]  R1157     1.9755135774612427e+00
    phi[2,9]  R1158     3.3077652454376221e+00
    phi[2,9]  R1159     -4.6425480842590332e+00
    phi[2,9]  R1160     -3.0799205303192139e+00
    phi[2,9]  R1161     -1.6020667552947998e+00
    phi[2,9]  R1162     -2.6461389064788818e+00
    phi[2,9]  R1163     -2.0077441632747650e-01
    phi[2,9]  R1164     2.4712851047515869e+00
    phi[2,9]  R1165     -2.5821166038513184e+00
    phi[2,9]  R1166     -3.5815567970275879e+00
    phi[2,9]  R1167     -4.2060499191284180e+00
    phi[2,9]  R1168     -3.3878018856048584e+00
    phi[2,9]  R1169     -0.839398205280304
    phi[2,9]  R1170     1.4603896141052246e+00
    phi[2,9]  R1171     -1.5206488966941833e-01
    phi[2,9]  R1172     2.0051459968090057e-01
    phi[2,9]  R1173     -1.9171637296676636e+00
    phi[2,9]  R1174     -1.2257201671600342e+00
    phi[2,9]  R1175     9.5642918348312378e-01
    phi[2,9]  R1176     -4.4751472473144531e+00
    phi[2,9]  R1177     1.3491888344287872e-01
    phi[2,9]  R1178     -1.8634755611419678e+00
    phi[2,9]  R1179     1.4654016494750977e+00
    phi[2,9]  R1180     2.1931796073913574e+00
    phi[2,9]  R1181     -2.5477592945098877e+00
    phi[9,2]  R18       -1
    phi[9,2]  R81       1
    phi[9,2]  R82       1
    phi[9,2]  R1182     -3.0999999046325684e+00
    phi[9,2]  R1183     -3.0999999046325684e+00
    phi[9,2]  R1184     -2.2400000095367432e+00
    phi[9,2]  R1185     -2.2400000095367432e+00
    phi[9,2]  R1186     -3.0999999046325684e+00
    phi[9,2]  R1187     -3.0999999046325684e+00
    phi[9,2]  R1188     -2.5699999332427979e+00
    phi[9,2]  R1189     -2.5699999332427979e+00
    phi[9,2]  R1190     -3.0999999046325684e+00
    phi[9,2]  R1191     -3.0999999046325684e+00
    phi[9,2]  R1192     -2.0899999141693115e+00
    phi[9,2]  R1193     -2.0899999141693115e+00
    phi[9,2]  R1194     -3.0999999046325684e+00
    phi[9,2]  R1195     -3.0999999046325684e+00
    phi[9,2]  R1196     3.4904921054840088e+00
    phi[9,2]  R1197     1.4727970361709595e+00
    phi[9,2]  R1198     2.5210235118865967e+00
    phi[9,2]  R1199     1.7337300777435303e+00
    phi[9,2]  R1200     1.9884278774261475e+00
    phi[9,2]  R1201     3.4749491214752197e+00
    phi[9,2]  R1202     4.2311649322509766e+00
    phi[9,2]  R1203     2.8107554912567139e+00
    phi[9,2]  R1204     2.5325076580047607e+00
    phi[9,2]  R1205     -2.2708638012409210e-01
    phi[9,2]  R1206     -4.5547986030578613e-01
    phi[9,2]  R1207     -2.4728229045867920e+00
    phi[9,2]  R1208     1.2274993658065796e+00
    phi[9,2]  R1209     -1.9573992490768433e-01
    phi[9,2]  R1210     -4.8519638180732727e-01
    phi[9,2]  R1211     -3.7261424064636230e+00
    phi[9,2]  R1212     -2.5186202526092529e+00
    phi[9,2]  R1213     -8.3140349388122559e-01
    phi[9,2]  R1214     -1.6850026845932007e+00
    phi[9,2]  R1215     -2.5643837451934814e+00
    phi[9,2]  R1216     -3.0810458660125732e+00
    phi[9,2]  R1217     -2.7657559514045715e-01
    phi[9,2]  R1218     -1.4796851873397827e+00
    phi[9,2]  R1219     2.4014606475830078e+00
    phi[9,2]  R1220     -9.0325701236724854e-01
    phi[9,2]  R1221     -2.3807880878448486e+00
    phi[9,2]  R1222     -1.1103235483169556e+00
    phi[9,2]  R1223     2.2838933467864990e+00
    phi[9,2]  R1224     -5.0104662775993347e-02
    phi[9,2]  R1225     -4.0013399124145508e+00
    phi[9,2]  R1226     -1.1639746427536011e+00
    phi[9,2]  R1227     -2.55611515045166
    phi[9,2]  R1228     2.0806839466094971e+00
    phi[9,2]  R1229     -1.9095526933670044e+00
    phi[9,2]  R1230     -7.8921101987361908e-02
    phi[9,2]  R1231     -1.9729385375976562e+00
    phi[9,2]  R1232     2.6759386062622070e+00
    phi[9,2]  R1233     4.6213066577911377e-01
    phi[9,2]  R1234     -4.4570879936218262e+00
    phi[9,2]  R1235     4.0773463249206543e+00
    phi[9,2]  R1236     -2.1155569553375244e+00
    phi[9,2]  R1237     -3.4662010669708252e+00
    phi[9,2]  R1238     -2.2347145080566406e+00
    phi[9,2]  R1239     2.4870846271514893e+00
    phi[9,2]  R1240     -1.4745303988456726e-01
    phi[9,2]  R1241     1.9755135774612427e+00
    phi[9,2]  R1242     3.3077652454376221e+00
    phi[9,2]  R1243     -4.6425480842590332e+00
    phi[9,2]  R1244     -3.0799205303192139e+00
    phi[9,2]  R1245     -1.6020667552947998e+00
    phi[9,2]  R1246     -2.6461389064788818e+00
    phi[9,2]  R1247     -2.0077441632747650e-01
    phi[9,2]  R1248     2.4712851047515869e+00
    phi[9,2]  R1249     -2.5821166038513184e+00
    phi[9,2]  R1250     -3.5815567970275879e+00
    phi[9,2]  R1251     -4.2060499191284180e+00
    phi[9,2]  R1252     -3.3878018856048584e+00
    phi[9,2]  R1253     -0.839398205280304
    phi[9,2]  R1254     1.4603896141052246e+00
    phi[9,2]  R1255     -1.5206488966941833e-01
    phi[9,2]  R1256     2.0051459968090057e-01
    phi[9,2]  R1257     -1.9171637296676636e+00
    phi[9,2]  R1258     -1.2257201671600342e+00
    phi[9,2]  R1259     9.5642918348312378e-01
    phi[9,2]  R1260     -4.4751472473144531e+00
    phi[9,2]  R1261     1.3491888344287872e-01
    phi[9,2]  R1262     -1.8634755611419678e+00
    phi[9,2]  R1263     1.4654016494750977e+00
    phi[9,2]  R1264     2.1931796073913574e+00
    phi[9,2]  R1265     -2.5477592945098877e+00
    phi[9,2]  R1266     2.2216885089874268e+00
    phi[9,2]  R1267     3.2516045570373535e+00
    phi[9,2]  R1268     2.57004451751709
    phi[9,2]  R1269     1.6635321378707886e+00
    phi[9,2]  R1270     2.6930334568023682e+00
    phi[9,2]  R1271     1.0987802743911743e+00
    phi[9,2]  R1272     1.5404895544052124e+00
    phi[9,2]  R1273     1.5247035026550293e+00
    phi[9,2]  R1274     2.6107805967330933e-01
    phi[9,2]  R1275     -1.0657718032598495e-01
    phi[9,2]  R1276     -1.6624023914337158e+00
    phi[9,2]  R1277     -1.5109596252441406e+00
    phi[9,2]  R1278     -2.0542309284210205e+00
    phi[9,2]  R1279     -0.836368203163147
    phi[9,2]  R1280     -1.2578293085098267e+00
    phi[9,2]  R1281     -1.6636800765991211e+00
    phi[9,2]  R1282     -1.3232668638229370e+00
    phi[9,2]  R1283     -9.3648397922515869e-01
    phi[9,2]  R1284     -2.2336082458496094e+00
    phi[9,2]  R1285     -8.7310045957565308e-01
    phi[2,11]  R18       1
    phi[2,11]  R19       1
    phi[2,11]  R20       -1.0660697052501651e+00
    phi[2,11]  R21       -1.7609238894928119e+00
    phi[2,11]  R22       8.0637182422278020e-01
    phi[2,11]  R23       2.2759530614163310e+00
    phi[2,11]  R24       -2.8768387459556162e+00
    phi[2,11]  R25       -8.4146320256262763e-01
    phi[2,11]  R26       2.7420950358790686e+00
    phi[2,11]  R91       -1
    phi[2,11]  R1286     -4.1660696098827330e+00
    phi[2,11]  R1287     -2.0339301993824033e+00
    phi[2,11]  R1288     -4.0009238990295550e+00
    phi[2,11]  R1289     -4.7907612004393130e-01
    phi[2,11]  R1290     -2.2936280804097882e+00
    phi[2,11]  R1291     -3.9063717288553486e+00
    phi[2,11]  R1292     -2.9404687182646683e-01
    phi[2,11]  R1293     -4.8459529946591289e+00
    phi[2,11]  R1294     -5.9768386505881850e+00
    phi[2,11]  R1295     -2.2316115867695219e-01
    phi[2,11]  R1296     -2.9314631167319392e+00
    phi[2,11]  R1297     -1.2485367116066839e+00
    phi[2,11]  R1298     -3.5790486875349981e-01
    phi[2,11]  R1299     -5.8420949405116369e+00
    phi[2,11]  R1300     -5.0037708276029491e-02
    phi[2,11]  R1301     -6.0952812604354811e-02
    phi[2,11]  R1302     -6.1735312768291362e-02
    phi[2,11]  R1303     -6.7729314702634991e-02
    phi[2,11]  R1304     -6.8042849041074049e-02
    phi[2,11]  R1305     -1.7364500877396560e-01
    phi[2,11]  R1306     -1.8203825395094753e-01
    phi[2,11]  R1307     -1.9171738603196031e-01
    phi[2,11]  R1308     -2.1724282005439677e-01
    phi[2,11]  R1309     -2.3665338731842006e-01
    phi[2,11]  R1310     -3.3255023897663083e-01
    phi[2,11]  R1311     -2.1102377742049523e+00
    phi[2,11]  R1312     -9.6707826168607824e-01
    phi[2,11]  R1313     -1.8776230367124833e+00
    phi[2,11]  R1314     -6.1674611258713741e-01
    phi[2,11]  R1315     -1.9661618561406864e+00
    phi[2,11]  R1316     -5.8060612253950283e-01
    phi[2,11]  R1317     -1.4269020987274934e+00
    phi[2,11]  R1318     -4.0442933621919153e-01
    phi[2,11]  R1319     -4.2648266574367044e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1320     -3.0999999046325684e+00
    phi[3,4]  R1321     -3.0999999046325684e+00
    phi[3,4]  R1322     -2.2400000095367432e+00
    phi[3,4]  R1323     -2.2400000095367432e+00
    phi[3,4]  R1324     -3.0999999046325684e+00
    phi[3,4]  R1325     -3.0999999046325684e+00
    phi[3,4]  R1326     -2.5699999332427979e+00
    phi[3,4]  R1327     -2.5699999332427979e+00
    phi[3,4]  R1328     -3.0999999046325684e+00
    phi[3,4]  R1329     -3.0999999046325684e+00
    phi[3,4]  R1330     -2.0899999141693115e+00
    phi[3,4]  R1331     -2.0899999141693115e+00
    phi[3,4]  R1332     -3.0999999046325684e+00
    phi[3,4]  R1333     -3.0999999046325684e+00
    phi[3,4]  R1334     7.3822331428527832e-01
    phi[3,4]  R1335     8.9754724502563477e-01
    phi[3,4]  R1336     1.0670480728149414e+00
    phi[3,4]  R1337     7.5229823589324951e-01
    phi[3,4]  R1338     1.8569492101669312e+00
    phi[3,4]  R1339     1.1916958093643188e+00
    phi[3,4]  R1340     8.1400975584983826e-02
    phi[3,4]  R1341     3.3278873562812805e-01
    phi[3,4]  R1342     -6.2773388624191284e-01
    phi[3,4]  R1343     -4.6158069372177124e-01
    phi[3,4]  R1344     -1.2588771581649780e+00
    phi[3,4]  R1345     -2.5696113109588623e+00
    phi[3,4]  R1346     -2.2249560356140137e+00
    phi[3,4]  R1347     -2.7997941970825195e+00
    phi[3,4]  R1348     -1.3001343011856079e+00
    phi[3,4]  R1349     -6.4240384101867676e-01
    phi[3,4]  R1350     -1.8600250482559204e+00
    phi[3,4]  R1351     -1.8854376077651978e+00
    phi[3,4]  R1352     -2.0086333751678467e+00
    phi[3,4]  R1353     -2.1496284008026123e+00
    phi[3,4]  R1354     -9.0118497610092163e-01
    phi[3,4]  R1355     -2.1802146434783936e+00
    phi[3,4]  R1356     -2.0869106054306030e-01
    phi[3,4]  R1357     -2.0088760852813721e+00
    phi[3,4]  R1358     -7.4766385555267334e-01
    phi[3,4]  R1359     -2.2666380405426025e+00
    phi[3,4]  R1360     -2.3804028034210205e+00
    phi[3,4]  R1361     -8.3778429031372070e-01
    phi[3,4]  R1362     -1.7409626245498657e+00
    phi[3,4]  R1363     1.3137128353118896e+00
    phi[3,4]  R1364     -5.0773626565933228e-01
    phi[3,4]  R1365     -1.3846476376056671e-01
    phi[3,4]  R1366     -2.7457067966461182e+00
    phi[3,4]  R1367     -2.2210865020751953e+00
    phi[3,4]  R1368     4.4964618980884552e-02
    phi[3,4]  R1369     -2.0459055900573730e+00
    phi[3,4]  R1370     -1.0858291387557983e+00
    phi[3,4]  R1371     -4.2121219635009766e-01
    phi[3,4]  R1372     -1.06468665599823
    phi[3,4]  R1373     -4.1692990064620972e-01
    phi[3,4]  R1374     1.0826381444931030e+00
    phi[3,4]  R1375     -4.6248561143875122e-01
    phi[3,4]  R1376     1.1655737161636353e+00
    phi[3,4]  R1377     -3.5086565017700195e+00
    phi[3,4]  R1378     -3.2664747238159180e+00
    phi[3,4]  R1379     -9.7572129964828491e-01
    phi[3,4]  R1380     -2.4977467060089111e+00
    phi[3,4]  R1381     -2.0630528926849365e+00
    phi[3,4]  R1382     -1.3015854358673096e+00
    phi[3,4]  R1383     -2.5785512924194336e+00
    phi[3,4]  R1384     -1.1803207397460938e+00
    phi[3,4]  R1385     -1.0226593017578125e+00
    phi[3,4]  R1386     5.3557878732681274e-01
    phi[3,4]  R1387     -7.2056733071804047e-02
    phi[3,4]  R1388     4.4423915445804596e-02
    phi[3,4]  R1389     7.9085648059844971e-01
    phi[3,4]  R1390     3.8938531279563904e-01
    phi[3,4]  R1391     -0.890080451965332
    phi[3,4]  R1392     -2.6615941897034645e-03
    phi[3,4]  R1393     3.4879669547080994e-01
    phi[3,4]  R1394     2.0948119461536407e-01
    phi[3,4]  R1395     -1.4072811603546143e-01
    phi[3,4]  R1396     -3.1512579321861267e-01
    phi[3,4]  R1397     -6.0556107759475708e-01
    phi[3,4]  R1398     -7.4485290050506592e-01
    phi[3,4]  R1399     -1.2922185659408569e+00
    phi[3,4]  R1400     -1.9896326065063477e+00
    phi[3,4]  R1401     -5.5601352453231812e-01
    phi[3,4]  R1402     1.0376328229904175e+00
    phi[3,4]  R1403     4.8660403490066528e-01
    phi[3,4]  R1404     1.9935253858566284e+00
    phi[3,4]  R1405     1.1443718671798706e+00
    phi[3,4]  R1406     -1.7569573223590851e-01
    phi[3,4]  R1407     -8.9544010162353516e-01
    phi[3,4]  R1408     1.3855372369289398e-01
    phi[3,4]  R1409     -1.0285872220993042e+00
    phi[3,4]  R1410     -1.8514494895935059e+00
    phi[3,4]  R1411     9.3731634318828583e-02
    phi[3,4]  R1412     -2.3990623950958252e+00
    phi[3,4]  R1413     4.5352160930633545e-01
    phi[3,4]  R1414     1.0340896844863892e+00
    phi[3,4]  R1415     -1.0753592103719711e-01
    phi[3,4]  R1416     -1.9674565792083740e+00
    phi[3,4]  R1417     8.7110280990600586e-01
    phi[3,4]  R1418     -2.0630495548248291e+00
    phi[3,4]  R1419     6.3689678907394409e-01
    phi[3,4]  R1420     -1.6721128225326538e+00
    phi[3,4]  R1421     5.6432944536209106e-01
    phi[3,4]  R1422     -3.3749365806579590e+00
    phi[3,4]  R1423     -9.2608731985092163e-01
    phi[3,4]  R1424     -8.0464309453964233e-01
    phi[3,4]  R1425     -1.0530525445938110e+00
    phi[3,4]  R1426     5.3729003667831421e-01
    phi[3,4]  R1427     -6.4232003688812256e-01
    phi[3,4]  R1428     4.9741452932357788e-01
    phi[3,4]  R1429     -1.8689255416393280e-01
    phi[3,4]  R1430     1.8261855840682983e-01
    phi[3,4]  R1431     -1.0706702470779419e+00
    phi[3,4]  R1432     -7.8237062692642212e-01
    phi[3,4]  R1433     -9.6827322244644165e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1434     -3.0999999046325684e+00
    phi[4,3]  R1435     -3.0999999046325684e+00
    phi[4,3]  R1436     -2.2400000095367432e+00
    phi[4,3]  R1437     -2.2400000095367432e+00
    phi[4,3]  R1438     -3.0999999046325684e+00
    phi[4,3]  R1439     -3.0999999046325684e+00
    phi[4,3]  R1440     -2.5699999332427979e+00
    phi[4,3]  R1441     -2.5699999332427979e+00
    phi[4,3]  R1442     -3.0999999046325684e+00
    phi[4,3]  R1443     -3.0999999046325684e+00
    phi[4,3]  R1444     -2.0899999141693115e+00
    phi[4,3]  R1445     -2.0899999141693115e+00
    phi[4,3]  R1446     -3.0999999046325684e+00
    phi[4,3]  R1447     -3.0999999046325684e+00
    phi[4,3]  R1448     -1.1803207397460938e+00
    phi[4,3]  R1449     -1.0226593017578125e+00
    phi[4,3]  R1450     5.3557878732681274e-01
    phi[4,3]  R1451     -7.2056733071804047e-02
    phi[4,3]  R1452     4.4423915445804596e-02
    phi[4,3]  R1453     7.9085648059844971e-01
    phi[4,3]  R1454     3.8938531279563904e-01
    phi[4,3]  R1455     -0.890080451965332
    phi[4,3]  R1456     -2.6615941897034645e-03
    phi[4,3]  R1457     3.4879669547080994e-01
    phi[4,3]  R1458     2.0948119461536407e-01
    phi[4,3]  R1459     -1.4072811603546143e-01
    phi[4,3]  R1460     -3.1512579321861267e-01
    phi[4,3]  R1461     -6.0556107759475708e-01
    phi[4,3]  R1462     -7.4485290050506592e-01
    phi[4,3]  R1463     -1.2922185659408569e+00
    phi[4,3]  R1464     -1.9896326065063477e+00
    phi[4,3]  R1465     -5.5601352453231812e-01
    phi[4,3]  R1466     1.0376328229904175e+00
    phi[4,3]  R1467     4.8660403490066528e-01
    phi[4,3]  R1468     1.9935253858566284e+00
    phi[4,3]  R1469     1.1443718671798706e+00
    phi[4,3]  R1470     -1.7569573223590851e-01
    phi[4,3]  R1471     -8.9544010162353516e-01
    phi[4,3]  R1472     1.3855372369289398e-01
    phi[4,3]  R1473     -1.0285872220993042e+00
    phi[4,3]  R1474     -1.8514494895935059e+00
    phi[4,3]  R1475     9.3731634318828583e-02
    phi[4,3]  R1476     -2.3990623950958252e+00
    phi[4,3]  R1477     4.5352160930633545e-01
    phi[4,3]  R1478     1.0340896844863892e+00
    phi[4,3]  R1479     -1.0753592103719711e-01
    phi[4,3]  R1480     -1.9674565792083740e+00
    phi[4,3]  R1481     8.7110280990600586e-01
    phi[4,3]  R1482     -2.0630495548248291e+00
    phi[4,3]  R1483     6.3689678907394409e-01
    phi[4,3]  R1484     -1.6721128225326538e+00
    phi[4,3]  R1485     5.6432944536209106e-01
    phi[4,3]  R1486     -3.3749365806579590e+00
    phi[4,3]  R1487     -9.2608731985092163e-01
    phi[4,3]  R1488     -8.0464309453964233e-01
    phi[4,3]  R1489     -1.0530525445938110e+00
    phi[4,3]  R1490     5.3729003667831421e-01
    phi[4,3]  R1491     -6.4232003688812256e-01
    phi[4,3]  R1492     4.9741452932357788e-01
    phi[4,3]  R1493     -1.8689255416393280e-01
    phi[4,3]  R1494     1.8261855840682983e-01
    phi[4,3]  R1495     -1.0706702470779419e+00
    phi[4,3]  R1496     -7.8237062692642212e-01
    phi[4,3]  R1497     -9.6827322244644165e-01
    phi[4,3]  R1498     7.3822331428527832e-01
    phi[4,3]  R1499     8.9754724502563477e-01
    phi[4,3]  R1500     1.0670480728149414e+00
    phi[4,3]  R1501     7.5229823589324951e-01
    phi[4,3]  R1502     1.8569492101669312e+00
    phi[4,3]  R1503     1.1916958093643188e+00
    phi[4,3]  R1504     8.1400975584983826e-02
    phi[4,3]  R1505     3.3278873562812805e-01
    phi[4,3]  R1506     -6.2773388624191284e-01
    phi[4,3]  R1507     -4.6158069372177124e-01
    phi[4,3]  R1508     -1.2588771581649780e+00
    phi[4,3]  R1509     -2.5696113109588623e+00
    phi[4,3]  R1510     -2.2249560356140137e+00
    phi[4,3]  R1511     -2.7997941970825195e+00
    phi[4,3]  R1512     -1.3001343011856079e+00
    phi[4,3]  R1513     -6.4240384101867676e-01
    phi[4,3]  R1514     -1.8600250482559204e+00
    phi[4,3]  R1515     -1.8854376077651978e+00
    phi[4,3]  R1516     -2.0086333751678467e+00
    phi[4,3]  R1517     -2.1496284008026123e+00
    phi[4,3]  R1518     -9.0118497610092163e-01
    phi[4,3]  R1519     -2.1802146434783936e+00
    phi[4,3]  R1520     -2.0869106054306030e-01
    phi[4,3]  R1521     -2.0088760852813721e+00
    phi[4,3]  R1522     -7.4766385555267334e-01
    phi[4,3]  R1523     -2.2666380405426025e+00
    phi[4,3]  R1524     -2.3804028034210205e+00
    phi[4,3]  R1525     -8.3778429031372070e-01
    phi[4,3]  R1526     -1.7409626245498657e+00
    phi[4,3]  R1527     1.3137128353118896e+00
    phi[4,3]  R1528     -5.0773626565933228e-01
    phi[4,3]  R1529     -1.3846476376056671e-01
    phi[4,3]  R1530     -2.7457067966461182e+00
    phi[4,3]  R1531     -2.2210865020751953e+00
    phi[4,3]  R1532     4.4964618980884552e-02
    phi[4,3]  R1533     -2.0459055900573730e+00
    phi[4,3]  R1534     -1.0858291387557983e+00
    phi[4,3]  R1535     -4.2121219635009766e-01
    phi[4,3]  R1536     -1.06468665599823
    phi[4,3]  R1537     -4.1692990064620972e-01
    phi[4,3]  R1538     1.0826381444931030e+00
    phi[4,3]  R1539     -4.6248561143875122e-01
    phi[4,3]  R1540     1.1655737161636353e+00
    phi[4,3]  R1541     -3.5086565017700195e+00
    phi[4,3]  R1542     -3.2664747238159180e+00
    phi[4,3]  R1543     -9.7572129964828491e-01
    phi[4,3]  R1544     -2.4977467060089111e+00
    phi[4,3]  R1545     -2.0630528926849365e+00
    phi[4,3]  R1546     -1.3015854358673096e+00
    phi[4,3]  R1547     -2.5785512924194336e+00
    phi[10,3]  R27       -1
    phi[10,3]  R29       0.755894890876533
    phi[10,3]  R30       -1.3610207536303220e+00
    phi[10,3]  R31       -2.6529262301834429e+00
    phi[10,3]  R32       1.1396941064726960e+00
    phi[10,3]  R33       -1.1530987079493753e+00
    phi[10,3]  R34       -1.1636170550572769e+00
    phi[10,3]  R35       -2.9247029633787682e+00
    phi[10,3]  R90       1
    phi[10,3]  R1548     -3.8558947955091014e+00
    phi[10,3]  R1549     -2.3441050137560353e+00
    phi[10,3]  R1550     -8.7897925590642112e-01
    phi[10,3]  R1551     -3.6010207631670652e+00
    phi[10,3]  R1552     -4.4707367444912549e-01
    phi[10,3]  R1553     -5.7529261348160112e+00
    phi[10,3]  R1554     -3.7096940397154938e+00
    phi[10,3]  R1555     -1.4303058267701019e+00
    phi[10,3]  R1556     -1.9469011966831931e+00
    phi[10,3]  R1557     -4.2530986125819439e+00
    phi[10,3]  R1558     -9.2638285911203466e-01
    phi[10,3]  R1559     -3.2536169692265884e+00
    phi[10,3]  R1560     -1.7529694125380013e-01
    phi[10,3]  R1561     -6.0247028680113370e+00
    phi[10,3]  R1562     -1.3646915912172464e-01
    phi[10,3]  R1563     -1.4382568823440312e-01
    phi[10,3]  R1564     -1.5095726610748428e-01
    phi[10,3]  R1565     -1.6080680693321159e-01
    phi[10,3]  R1566     -1.8346909227723529e-01
    phi[10,3]  R1567     -2.0937032295102154e-01
    phi[10,3]  R1568     -2.2255740332274438e+00
    phi[10,3]  R1569     -0.304163420270816
    phi[10,3]  R1570     -1.5937713097710793e+00
    phi[10,3]  R1571     -1.4600032880147396e+00
    phi[10,3]  R1572     -1.8840280682261490e-01
    phi[10,3]  R1573     -2.1806870059515848e-01
    phi[10,3]  R1574     -2.2780068704914980e-01
    phi[10,3]  R1575     -2.3685031802759315e-01
    phi[10,3]  R1576     -3.7889086415725237e-01
    phi[10,3]  R1577     -3.8606515742463454e-01
    phi[10,3]  R1578     -1.7082950007175475e+00
    phi[10,3]  R1579     -1.5475556969664221e+00
    phi[10,3]  R1580     -8.3279898589143686e-01
    phi[10,3]  R1581     -8.8185312263260274e-01
    phi[10,3]  R1582     -2.3585219084610265e-01
    phi[10,3]  R1583     -2.6236375981549065e-01
    phi[10,3]  R1584     -2.6670630347677959e-01
    phi[10,3]  R1585     -3.4861229554167950e-01
    phi[10,3]  R1586     -3.4949371227233222e-01
    phi[10,3]  R1587     -3.6356221994723192e-01
    phi[10,3]  R1588     -4.4068903590171260e-01
    phi[10,3]  R1589     -8.9190733749274420e-01
    phi[10,3]  R1590     -4.9895339043227938e-01
    phi[10,3]  R1591     -5.7201897920378730e-01
    phi[10,3]  R1592     -1.5732855156685166e-01
    phi[10,3]  R1593     -1.6875540141147916e-01
    phi[10,3]  R1594     -1.8411553643713630e-01
    phi[10,3]  R1595     -0.194942446590205
    phi[10,3]  R1596     -2.0087552177796014e-01
    phi[10,3]  R1597     -2.1390369852853475e-01
    phi[10,3]  R1598     -2.1785180075887822e-01
    phi[10,3]  R1599     -2.1818471682109586e-01
    phi[10,3]  R1600     -2.4251584415267802e-01
    phi[10,3]  R1601     -2.5067073194903988e-01
    phi[10,3]  R1602     -1.6514961982276510e-01
    phi[10,3]  R1603     -1.8020447872377771e-01
    phi[10,3]  R1604     -1.9024713361907408e-01
    phi[10,3]  R1605     -2.2527926621429284e-01
    phi[10,3]  R1606     -2.5121379939799748e-01
    phi[10,3]  R1607     -2.8765185840947138e-01
    phi[10,3]  R1608     -2.9311039794255178e-01
    phi[10,3]  R1609     -3.2533431044551642e-01
    phi[10,3]  R1610     -5.3257615097294020e-01
    phi[10,3]  R1611     -5.7411721716106534e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1612     -3.0999999046325684e+00
    phi[4,5]  R1613     -3.0999999046325684e+00
    phi[4,5]  R1614     -2.2400000095367432e+00
    phi[4,5]  R1615     -2.2400000095367432e+00
    phi[4,5]  R1616     -3.0999999046325684e+00
    phi[4,5]  R1617     -3.0999999046325684e+00
    phi[4,5]  R1618     -2.5699999332427979e+00
    phi[4,5]  R1619     -2.5699999332427979e+00
    phi[4,5]  R1620     -3.0999999046325684e+00
    phi[4,5]  R1621     -3.0999999046325684e+00
    phi[4,5]  R1622     -2.0899999141693115e+00
    phi[4,5]  R1623     -2.0899999141693115e+00
    phi[4,5]  R1624     -3.0999999046325684e+00
    phi[4,5]  R1625     -3.0999999046325684e+00
    phi[4,5]  R1626     -1.1803207397460938e+00
    phi[4,5]  R1627     -1.0226593017578125e+00
    phi[4,5]  R1628     5.3557878732681274e-01
    phi[4,5]  R1629     -7.2056733071804047e-02
    phi[4,5]  R1630     4.4423915445804596e-02
    phi[4,5]  R1631     7.9085648059844971e-01
    phi[4,5]  R1632     3.8938531279563904e-01
    phi[4,5]  R1633     -0.890080451965332
    phi[4,5]  R1634     -2.6615941897034645e-03
    phi[4,5]  R1635     3.4879669547080994e-01
    phi[4,5]  R1636     2.0948119461536407e-01
    phi[4,5]  R1637     -1.4072811603546143e-01
    phi[4,5]  R1638     -3.1512579321861267e-01
    phi[4,5]  R1639     -6.0556107759475708e-01
    phi[4,5]  R1640     -7.4485290050506592e-01
    phi[4,5]  R1641     -1.2922185659408569e+00
    phi[4,5]  R1642     -1.9896326065063477e+00
    phi[4,5]  R1643     -5.5601352453231812e-01
    phi[4,5]  R1644     1.0376328229904175e+00
    phi[4,5]  R1645     4.8660403490066528e-01
    phi[4,5]  R1646     1.9935253858566284e+00
    phi[4,5]  R1647     1.1443718671798706e+00
    phi[4,5]  R1648     -1.7569573223590851e-01
    phi[4,5]  R1649     -8.9544010162353516e-01
    phi[4,5]  R1650     1.3855372369289398e-01
    phi[4,5]  R1651     -1.0285872220993042e+00
    phi[4,5]  R1652     -1.8514494895935059e+00
    phi[4,5]  R1653     9.3731634318828583e-02
    phi[4,5]  R1654     -2.3990623950958252e+00
    phi[4,5]  R1655     4.5352160930633545e-01
    phi[4,5]  R1656     1.0340896844863892e+00
    phi[4,5]  R1657     -1.0753592103719711e-01
    phi[4,5]  R1658     -1.9674565792083740e+00
    phi[4,5]  R1659     8.7110280990600586e-01
    phi[4,5]  R1660     -2.0630495548248291e+00
    phi[4,5]  R1661     6.3689678907394409e-01
    phi[4,5]  R1662     -1.6721128225326538e+00
    phi[4,5]  R1663     5.6432944536209106e-01
    phi[4,5]  R1664     -3.3749365806579590e+00
    phi[4,5]  R1665     -9.2608731985092163e-01
    phi[4,5]  R1666     -8.0464309453964233e-01
    phi[4,5]  R1667     -1.0530525445938110e+00
    phi[4,5]  R1668     5.3729003667831421e-01
    phi[4,5]  R1669     -6.4232003688812256e-01
    phi[4,5]  R1670     4.9741452932357788e-01
    phi[4,5]  R1671     -1.8689255416393280e-01
    phi[4,5]  R1672     1.8261855840682983e-01
    phi[4,5]  R1673     -1.0706702470779419e+00
    phi[4,5]  R1674     -7.8237062692642212e-01
    phi[4,5]  R1675     -9.6827322244644165e-01
    phi[4,5]  R1676     0.466277539730072
    phi[4,5]  R1677     -2.5494914054870605e+00
    phi[4,5]  R1678     -4.2799420654773712e-02
    phi[4,5]  R1679     -6.3579076528549194e-01
    phi[4,5]  R1680     -1.0831786394119263e+00
    phi[4,5]  R1681     3.8297316431999207e-01
    phi[4,5]  R1682     1.1744762659072876e+00
    phi[4,5]  R1683     1.2327330112457275e+00
    phi[4,5]  R1684     1.7566983699798584e+00
    phi[4,5]  R1685     1.9722408056259155e+00
    phi[4,5]  R1686     6.6315829753875732e-01
    phi[4,5]  R1687     9.5017510652542114e-01
    phi[4,5]  R1688     1.3566298484802246e+00
    phi[4,5]  R1689     1.1523184776306152e+00
    phi[4,5]  R1690     8.4187999367713928e-02
    phi[4,5]  R1691     -0.855229377746582
    phi[4,5]  R1692     -1.3249965012073517e-01
    phi[4,5]  R1693     -1.1735585927963257e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1694     -3.0999999046325684e+00
    phi[5,4]  R1695     -3.0999999046325684e+00
    phi[5,4]  R1696     -2.2400000095367432e+00
    phi[5,4]  R1697     -2.2400000095367432e+00
    phi[5,4]  R1698     -3.0999999046325684e+00
    phi[5,4]  R1699     -3.0999999046325684e+00
    phi[5,4]  R1700     -2.5699999332427979e+00
    phi[5,4]  R1701     -2.5699999332427979e+00
    phi[5,4]  R1702     -3.0999999046325684e+00
    phi[5,4]  R1703     -3.0999999046325684e+00
    phi[5,4]  R1704     -2.0899999141693115e+00
    phi[5,4]  R1705     -2.0899999141693115e+00
    phi[5,4]  R1706     -3.0999999046325684e+00
    phi[5,4]  R1707     -3.0999999046325684e+00
    phi[5,4]  R1708     0.466277539730072
    phi[5,4]  R1709     -2.5494914054870605e+00
    phi[5,4]  R1710     -4.2799420654773712e-02
    phi[5,4]  R1711     -6.3579076528549194e-01
    phi[5,4]  R1712     -1.0831786394119263e+00
    phi[5,4]  R1713     3.8297316431999207e-01
    phi[5,4]  R1714     1.1744762659072876e+00
    phi[5,4]  R1715     1.2327330112457275e+00
    phi[5,4]  R1716     1.7566983699798584e+00
    phi[5,4]  R1717     1.9722408056259155e+00
    phi[5,4]  R1718     6.6315829753875732e-01
    phi[5,4]  R1719     9.5017510652542114e-01
    phi[5,4]  R1720     1.3566298484802246e+00
    phi[5,4]  R1721     1.1523184776306152e+00
    phi[5,4]  R1722     8.4187999367713928e-02
    phi[5,4]  R1723     -0.855229377746582
    phi[5,4]  R1724     -1.3249965012073517e-01
    phi[5,4]  R1725     -1.1735585927963257e+00
    phi[5,4]  R1726     -1.1803207397460938e+00
    phi[5,4]  R1727     -1.0226593017578125e+00
    phi[5,4]  R1728     5.3557878732681274e-01
    phi[5,4]  R1729     -7.2056733071804047e-02
    phi[5,4]  R1730     4.4423915445804596e-02
    phi[5,4]  R1731     7.9085648059844971e-01
    phi[5,4]  R1732     3.8938531279563904e-01
    phi[5,4]  R1733     -0.890080451965332
    phi[5,4]  R1734     -2.6615941897034645e-03
    phi[5,4]  R1735     3.4879669547080994e-01
    phi[5,4]  R1736     2.0948119461536407e-01
    phi[5,4]  R1737     -1.4072811603546143e-01
    phi[5,4]  R1738     -3.1512579321861267e-01
    phi[5,4]  R1739     -6.0556107759475708e-01
    phi[5,4]  R1740     -7.4485290050506592e-01
    phi[5,4]  R1741     -1.2922185659408569e+00
    phi[5,4]  R1742     -1.9896326065063477e+00
    phi[5,4]  R1743     -5.5601352453231812e-01
    phi[5,4]  R1744     1.0376328229904175e+00
    phi[5,4]  R1745     4.8660403490066528e-01
    phi[5,4]  R1746     1.9935253858566284e+00
    phi[5,4]  R1747     1.1443718671798706e+00
    phi[5,4]  R1748     -1.7569573223590851e-01
    phi[5,4]  R1749     -8.9544010162353516e-01
    phi[5,4]  R1750     1.3855372369289398e-01
    phi[5,4]  R1751     -1.0285872220993042e+00
    phi[5,4]  R1752     -1.8514494895935059e+00
    phi[5,4]  R1753     9.3731634318828583e-02
    phi[5,4]  R1754     -2.3990623950958252e+00
    phi[5,4]  R1755     4.5352160930633545e-01
    phi[5,4]  R1756     1.0340896844863892e+00
    phi[5,4]  R1757     -1.0753592103719711e-01
    phi[5,4]  R1758     -1.9674565792083740e+00
    phi[5,4]  R1759     8.7110280990600586e-01
    phi[5,4]  R1760     -2.0630495548248291e+00
    phi[5,4]  R1761     6.3689678907394409e-01
    phi[5,4]  R1762     -1.6721128225326538e+00
    phi[5,4]  R1763     5.6432944536209106e-01
    phi[5,4]  R1764     -3.3749365806579590e+00
    phi[5,4]  R1765     -9.2608731985092163e-01
    phi[5,4]  R1766     -8.0464309453964233e-01
    phi[5,4]  R1767     -1.0530525445938110e+00
    phi[5,4]  R1768     5.3729003667831421e-01
    phi[5,4]  R1769     -6.4232003688812256e-01
    phi[5,4]  R1770     4.9741452932357788e-01
    phi[5,4]  R1771     -1.8689255416393280e-01
    phi[5,4]  R1772     1.8261855840682983e-01
    phi[5,4]  R1773     -1.0706702470779419e+00
    phi[5,4]  R1774     -7.8237062692642212e-01
    phi[5,4]  R1775     -9.6827322244644165e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1776     -3.0999999046325684e+00
    phi[5,6]  R1777     -3.0999999046325684e+00
    phi[5,6]  R1778     -2.2400000095367432e+00
    phi[5,6]  R1779     -2.2400000095367432e+00
    phi[5,6]  R1780     -3.0999999046325684e+00
    phi[5,6]  R1781     -3.0999999046325684e+00
    phi[5,6]  R1782     -2.5699999332427979e+00
    phi[5,6]  R1783     -2.5699999332427979e+00
    phi[5,6]  R1784     -3.0999999046325684e+00
    phi[5,6]  R1785     -3.0999999046325684e+00
    phi[5,6]  R1786     -2.0899999141693115e+00
    phi[5,6]  R1787     -2.0899999141693115e+00
    phi[5,6]  R1788     -3.0999999046325684e+00
    phi[5,6]  R1789     -3.0999999046325684e+00
    phi[5,6]  R1790     0.466277539730072
    phi[5,6]  R1791     -2.5494914054870605e+00
    phi[5,6]  R1792     -4.2799420654773712e-02
    phi[5,6]  R1793     -6.3579076528549194e-01
    phi[5,6]  R1794     -1.0831786394119263e+00
    phi[5,6]  R1795     3.8297316431999207e-01
    phi[5,6]  R1796     1.1744762659072876e+00
    phi[5,6]  R1797     1.2327330112457275e+00
    phi[5,6]  R1798     1.7566983699798584e+00
    phi[5,6]  R1799     1.9722408056259155e+00
    phi[5,6]  R1800     6.6315829753875732e-01
    phi[5,6]  R1801     9.5017510652542114e-01
    phi[5,6]  R1802     1.3566298484802246e+00
    phi[5,6]  R1803     1.1523184776306152e+00
    phi[5,6]  R1804     8.4187999367713928e-02
    phi[5,6]  R1805     -0.855229377746582
    phi[5,6]  R1806     -1.3249965012073517e-01
    phi[5,6]  R1807     -1.1735585927963257e+00
    phi[5,6]  R1808     -1.7363774776458740e+00
    phi[5,6]  R1809     -1.6987472772598267e+00
    phi[5,6]  R1810     -4.1817754507064819e-01
    phi[5,6]  R1811     -6.3606750965118408e-01
    phi[5,6]  R1812     6.3806581497192383e-01
    phi[5,6]  R1813     1.9814034700393677e+00
    phi[5,6]  R1814     1.3474426269531250e+00
    phi[5,6]  R1815     1.4074758291244507e+00
    phi[5,6]  R1816     1.8616461753845215e+00
    phi[5,6]  R1817     1.7375346422195435e+00
    phi[5,6]  R1818     -9.5647692680358887e-01
    phi[5,6]  R1819     -1.6106113195419312e+00
    phi[5,6]  R1820     -1.6129747629165649e+00
    phi[5,6]  R1821     -1.9755884408950806e+00
    phi[5,6]  R1822     -1.5151931047439575e+00
    phi[5,6]  R1823     -2.3251590728759766e+00
    phi[5,6]  R1824     -1.3488869667053223e+00
    phi[5,6]  R1825     -1.0211920738220215e+00
    phi[5,6]  R1826     -2.4547557830810547e+00
    phi[5,6]  R1827     -1.1471191644668579e+00
    phi[5,6]  R1828     -1.7967853546142578e+00
    phi[5,6]  R1829     -7.1519494056701660e-01
    phi[5,6]  R1830     5.3730927407741547e-02
    phi[5,6]  R1831     -1.7378469705581665e+00
    phi[5,6]  R1832     -7.6790265738964081e-02
    phi[5,6]  R1833     -1.9498925209045410e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R1834     -3.0999999046325684e+00
    phi[6,5]  R1835     -3.0999999046325684e+00
    phi[6,5]  R1836     -2.2400000095367432e+00
    phi[6,5]  R1837     -2.2400000095367432e+00
    phi[6,5]  R1838     -3.0999999046325684e+00
    phi[6,5]  R1839     -3.0999999046325684e+00
    phi[6,5]  R1840     -2.5699999332427979e+00
    phi[6,5]  R1841     -2.5699999332427979e+00
    phi[6,5]  R1842     -3.0999999046325684e+00
    phi[6,5]  R1843     -3.0999999046325684e+00
    phi[6,5]  R1844     -2.0899999141693115e+00
    phi[6,5]  R1845     -2.0899999141693115e+00
    phi[6,5]  R1846     -3.0999999046325684e+00
    phi[6,5]  R1847     -3.0999999046325684e+00
    phi[6,5]  R1848     -1.7363774776458740e+00
    phi[6,5]  R1849     -1.6987472772598267e+00
    phi[6,5]  R1850     -4.1817754507064819e-01
    phi[6,5]  R1851     -6.3606750965118408e-01
    phi[6,5]  R1852     6.3806581497192383e-01
    phi[6,5]  R1853     1.9814034700393677e+00
    phi[6,5]  R1854     1.3474426269531250e+00
    phi[6,5]  R1855     1.4074758291244507e+00
    phi[6,5]  R1856     1.8616461753845215e+00
    phi[6,5]  R1857     1.7375346422195435e+00
    phi[6,5]  R1858     -9.5647692680358887e-01
    phi[6,5]  R1859     -1.6106113195419312e+00
    phi[6,5]  R1860     -1.6129747629165649e+00
    phi[6,5]  R1861     -1.9755884408950806e+00
    phi[6,5]  R1862     -1.5151931047439575e+00
    phi[6,5]  R1863     -2.3251590728759766e+00
    phi[6,5]  R1864     -1.3488869667053223e+00
    phi[6,5]  R1865     -1.0211920738220215e+00
    phi[6,5]  R1866     -2.4547557830810547e+00
    phi[6,5]  R1867     -1.1471191644668579e+00
    phi[6,5]  R1868     -1.7967853546142578e+00
    phi[6,5]  R1869     -7.1519494056701660e-01
    phi[6,5]  R1870     5.3730927407741547e-02
    phi[6,5]  R1871     -1.7378469705581665e+00
    phi[6,5]  R1872     -7.6790265738964081e-02
    phi[6,5]  R1873     -1.9498925209045410e+00
    phi[6,5]  R1874     0.466277539730072
    phi[6,5]  R1875     -2.5494914054870605e+00
    phi[6,5]  R1876     -4.2799420654773712e-02
    phi[6,5]  R1877     -6.3579076528549194e-01
    phi[6,5]  R1878     -1.0831786394119263e+00
    phi[6,5]  R1879     3.8297316431999207e-01
    phi[6,5]  R1880     1.1744762659072876e+00
    phi[6,5]  R1881     1.2327330112457275e+00
    phi[6,5]  R1882     1.7566983699798584e+00
    phi[6,5]  R1883     1.9722408056259155e+00
    phi[6,5]  R1884     6.6315829753875732e-01
    phi[6,5]  R1885     9.5017510652542114e-01
    phi[6,5]  R1886     1.3566298484802246e+00
    phi[6,5]  R1887     1.1523184776306152e+00
    phi[6,5]  R1888     8.4187999367713928e-02
    phi[6,5]  R1889     -0.855229377746582
    phi[6,5]  R1890     -1.3249965012073517e-01
    phi[6,5]  R1891     -1.1735585927963257e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R1892     -3.0999999046325684e+00
    phi[6,7]  R1893     -3.0999999046325684e+00
    phi[6,7]  R1894     -2.2400000095367432e+00
    phi[6,7]  R1895     -2.2400000095367432e+00
    phi[6,7]  R1896     -3.0999999046325684e+00
    phi[6,7]  R1897     -3.0999999046325684e+00
    phi[6,7]  R1898     -2.5699999332427979e+00
    phi[6,7]  R1899     -2.5699999332427979e+00
    phi[6,7]  R1900     -3.0999999046325684e+00
    phi[6,7]  R1901     -3.0999999046325684e+00
    phi[6,7]  R1902     -2.0899999141693115e+00
    phi[6,7]  R1903     -2.0899999141693115e+00
    phi[6,7]  R1904     -3.0999999046325684e+00
    phi[6,7]  R1905     -3.0999999046325684e+00
    phi[6,7]  R1906     -1.7363774776458740e+00
    phi[6,7]  R1907     -1.6987472772598267e+00
    phi[6,7]  R1908     -4.1817754507064819e-01
    phi[6,7]  R1909     -6.3606750965118408e-01
    phi[6,7]  R1910     6.3806581497192383e-01
    phi[6,7]  R1911     1.9814034700393677e+00
    phi[6,7]  R1912     1.3474426269531250e+00
    phi[6,7]  R1913     1.4074758291244507e+00
    phi[6,7]  R1914     1.8616461753845215e+00
    phi[6,7]  R1915     1.7375346422195435e+00
    phi[6,7]  R1916     -9.5647692680358887e-01
    phi[6,7]  R1917     -1.6106113195419312e+00
    phi[6,7]  R1918     -1.6129747629165649e+00
    phi[6,7]  R1919     -1.9755884408950806e+00
    phi[6,7]  R1920     -1.5151931047439575e+00
    phi[6,7]  R1921     -2.3251590728759766e+00
    phi[6,7]  R1922     -1.3488869667053223e+00
    phi[6,7]  R1923     -1.0211920738220215e+00
    phi[6,7]  R1924     -2.4547557830810547e+00
    phi[6,7]  R1925     -1.1471191644668579e+00
    phi[6,7]  R1926     -1.7967853546142578e+00
    phi[6,7]  R1927     -7.1519494056701660e-01
    phi[6,7]  R1928     5.3730927407741547e-02
    phi[6,7]  R1929     -1.7378469705581665e+00
    phi[6,7]  R1930     -7.6790265738964081e-02
    phi[6,7]  R1931     -1.9498925209045410e+00
    phi[6,7]  R1932     1.0104973316192627e+00
    phi[6,7]  R1933     1.10867178440094
    phi[6,7]  R1934     3.3407423645257950e-02
    phi[6,7]  R1935     0.521316647529602
    phi[6,7]  R1936     1.1180651187896729e+00
    phi[6,7]  R1937     1.0119259357452393e+00
    phi[6,7]  R1938     -5.3073018789291382e-01
    phi[6,7]  R1939     -1.1281306743621826e+00
    phi[6,7]  R1940     1.7591068744659424e+00
    phi[6,7]  R1941     1.4970685243606567e+00
    phi[6,7]  R1942     -1.2542389631271362e+00
    phi[6,7]  R1943     -1.5016587972640991e+00
    phi[6,7]  R1944     -1.7590734958648682e+00
    phi[6,7]  R1945     -1.1584981679916382e+00
    phi[6,7]  R1946     -1.8643788099288940e+00
    phi[6,7]  R1947     -1.6898518800735474e+00
    phi[6,7]  R1948     -8.2104313373565674e-01
    phi[6,7]  R1949     -1.9598876237869263e+00
    phi[6,7]  R1950     -1.6876850128173828e+00
    phi[6,7]  R1951     -2.1231966018676758e+00
    phi[6,7]  R1952     -8.4606006741523743e-02
    phi[6,7]  R1953     -2.6637795567512512e-01
    phi[6,7]  R1954     -1.9401203393936157e+00
    phi[6,7]  R1955     6.2804079055786133e-01
    phi[6,7]  R1956     -3.5028311610221863e-01
    phi[6,7]  R1957     -2.4033676087856293e-01
    phi[6,7]  R1958     -1.3029394149780273e+00
    phi[6,7]  R1959     4.4234764575958252e-01
    phi[6,7]  R1960     -1.5416851043701172e+00
    phi[6,7]  R1961     -1.0891468524932861e+00
    phi[6,7]  R1962     -9.5075517892837524e-01
    phi[6,7]  R1963     -9.2837697267532349e-01
    phi[6,7]  R1964     -2.7207186818122864e-01
    phi[6,7]  R1965     5.4030284285545349e-02
    phi[6,7]  R1966     2.7308133244514465e-01
    phi[6,7]  R1967     1.3003057241439819e-01
    phi[6,7]  R1968     -3.9329674839973450e-01
    phi[6,7]  R1969     -1.6586083173751831e-01
    phi[6,7]  R1970     -1.8623694181442261e+00
    phi[6,7]  R1971     -4.1338509321212769e-01
    phi[6,7]  R1972     -8.2793760299682617e-01
    phi[6,7]  R1973     9.2070117592811584e-02
    phi[6,7]  R1974     8.2646727561950684e-01
    phi[6,7]  R1975     -7.6317095756530762e-01
    phi[6,7]  R1976     -1.4238414764404297e+00
    phi[6,7]  R1977     -2.1155829429626465e+00
    phi[6,7]  R1978     -1.1043585538864136e+00
    phi[6,7]  R1979     -1.1694883108139038e+00
    phi[6,7]  R1980     3.5722288489341736e-01
    phi[6,7]  R1981     4.5418989658355713e-01
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R1982     -3.0999999046325684e+00
    phi[7,6]  R1983     -3.0999999046325684e+00
    phi[7,6]  R1984     -2.2400000095367432e+00
    phi[7,6]  R1985     -2.2400000095367432e+00
    phi[7,6]  R1986     -3.0999999046325684e+00
    phi[7,6]  R1987     -3.0999999046325684e+00
    phi[7,6]  R1988     -2.5699999332427979e+00
    phi[7,6]  R1989     -2.5699999332427979e+00
    phi[7,6]  R1990     -3.0999999046325684e+00
    phi[7,6]  R1991     -3.0999999046325684e+00
    phi[7,6]  R1992     -2.0899999141693115e+00
    phi[7,6]  R1993     -2.0899999141693115e+00
    phi[7,6]  R1994     -3.0999999046325684e+00
    phi[7,6]  R1995     -3.0999999046325684e+00
    phi[7,6]  R1996     1.0104973316192627e+00
    phi[7,6]  R1997     1.10867178440094
    phi[7,6]  R1998     3.3407423645257950e-02
    phi[7,6]  R1999     0.521316647529602
    phi[7,6]  R2000     1.1180651187896729e+00
    phi[7,6]  R2001     1.0119259357452393e+00
    phi[7,6]  R2002     -5.3073018789291382e-01
    phi[7,6]  R2003     -1.1281306743621826e+00
    phi[7,6]  R2004     1.7591068744659424e+00
    phi[7,6]  R2005     1.4970685243606567e+00
    phi[7,6]  R2006     -1.2542389631271362e+00
    phi[7,6]  R2007     -1.5016587972640991e+00
    phi[7,6]  R2008     -1.7590734958648682e+00
    phi[7,6]  R2009     -1.1584981679916382e+00
    phi[7,6]  R2010     -1.8643788099288940e+00
    phi[7,6]  R2011     -1.6898518800735474e+00
    phi[7,6]  R2012     -8.2104313373565674e-01
    phi[7,6]  R2013     -1.9598876237869263e+00
    phi[7,6]  R2014     -1.6876850128173828e+00
    phi[7,6]  R2015     -2.1231966018676758e+00
    phi[7,6]  R2016     -8.4606006741523743e-02
    phi[7,6]  R2017     -2.6637795567512512e-01
    phi[7,6]  R2018     -1.9401203393936157e+00
    phi[7,6]  R2019     6.2804079055786133e-01
    phi[7,6]  R2020     -3.5028311610221863e-01
    phi[7,6]  R2021     -2.4033676087856293e-01
    phi[7,6]  R2022     -1.3029394149780273e+00
    phi[7,6]  R2023     4.4234764575958252e-01
    phi[7,6]  R2024     -1.5416851043701172e+00
    phi[7,6]  R2025     -1.0891468524932861e+00
    phi[7,6]  R2026     -9.5075517892837524e-01
    phi[7,6]  R2027     -9.2837697267532349e-01
    phi[7,6]  R2028     -2.7207186818122864e-01
    phi[7,6]  R2029     5.4030284285545349e-02
    phi[7,6]  R2030     2.7308133244514465e-01
    phi[7,6]  R2031     1.3003057241439819e-01
    phi[7,6]  R2032     -3.9329674839973450e-01
    phi[7,6]  R2033     -1.6586083173751831e-01
    phi[7,6]  R2034     -1.8623694181442261e+00
    phi[7,6]  R2035     -4.1338509321212769e-01
    phi[7,6]  R2036     -8.2793760299682617e-01
    phi[7,6]  R2037     9.2070117592811584e-02
    phi[7,6]  R2038     8.2646727561950684e-01
    phi[7,6]  R2039     -7.6317095756530762e-01
    phi[7,6]  R2040     -1.4238414764404297e+00
    phi[7,6]  R2041     -2.1155829429626465e+00
    phi[7,6]  R2042     -1.1043585538864136e+00
    phi[7,6]  R2043     -1.1694883108139038e+00
    phi[7,6]  R2044     3.5722288489341736e-01
    phi[7,6]  R2045     4.5418989658355713e-01
    phi[7,6]  R2046     -1.7363774776458740e+00
    phi[7,6]  R2047     -1.6987472772598267e+00
    phi[7,6]  R2048     -4.1817754507064819e-01
    phi[7,6]  R2049     -6.3606750965118408e-01
    phi[7,6]  R2050     6.3806581497192383e-01
    phi[7,6]  R2051     1.9814034700393677e+00
    phi[7,6]  R2052     1.3474426269531250e+00
    phi[7,6]  R2053     1.4074758291244507e+00
    phi[7,6]  R2054     1.8616461753845215e+00
    phi[7,6]  R2055     1.7375346422195435e+00
    phi[7,6]  R2056     -9.5647692680358887e-01
    phi[7,6]  R2057     -1.6106113195419312e+00
    phi[7,6]  R2058     -1.6129747629165649e+00
    phi[7,6]  R2059     -1.9755884408950806e+00
    phi[7,6]  R2060     -1.5151931047439575e+00
    phi[7,6]  R2061     -2.3251590728759766e+00
    phi[7,6]  R2062     -1.3488869667053223e+00
    phi[7,6]  R2063     -1.0211920738220215e+00
    phi[7,6]  R2064     -2.4547557830810547e+00
    phi[7,6]  R2065     -1.1471191644668579e+00
    phi[7,6]  R2066     -1.7967853546142578e+00
    phi[7,6]  R2067     -7.1519494056701660e-01
    phi[7,6]  R2068     5.3730927407741547e-02
    phi[7,6]  R2069     -1.7378469705581665e+00
    phi[7,6]  R2070     -7.6790265738964081e-02
    phi[7,6]  R2071     -1.9498925209045410e+00
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2072     -3.0999999046325684e+00
    phi[7,8]  R2073     -3.0999999046325684e+00
    phi[7,8]  R2074     -2.2400000095367432e+00
    phi[7,8]  R2075     -2.2400000095367432e+00
    phi[7,8]  R2076     -3.0999999046325684e+00
    phi[7,8]  R2077     -3.0999999046325684e+00
    phi[7,8]  R2078     -2.5699999332427979e+00
    phi[7,8]  R2079     -2.5699999332427979e+00
    phi[7,8]  R2080     -3.0999999046325684e+00
    phi[7,8]  R2081     -3.0999999046325684e+00
    phi[7,8]  R2082     -2.0899999141693115e+00
    phi[7,8]  R2083     -2.0899999141693115e+00
    phi[7,8]  R2084     -3.0999999046325684e+00
    phi[7,8]  R2085     -3.0999999046325684e+00
    phi[7,8]  R2086     1.0104973316192627e+00
    phi[7,8]  R2087     1.10867178440094
    phi[7,8]  R2088     3.3407423645257950e-02
    phi[7,8]  R2089     0.521316647529602
    phi[7,8]  R2090     1.1180651187896729e+00
    phi[7,8]  R2091     1.0119259357452393e+00
    phi[7,8]  R2092     -5.3073018789291382e-01
    phi[7,8]  R2093     -1.1281306743621826e+00
    phi[7,8]  R2094     1.7591068744659424e+00
    phi[7,8]  R2095     1.4970685243606567e+00
    phi[7,8]  R2096     -1.2542389631271362e+00
    phi[7,8]  R2097     -1.5016587972640991e+00
    phi[7,8]  R2098     -1.7590734958648682e+00
    phi[7,8]  R2099     -1.1584981679916382e+00
    phi[7,8]  R2100     -1.8643788099288940e+00
    phi[7,8]  R2101     -1.6898518800735474e+00
    phi[7,8]  R2102     -8.2104313373565674e-01
    phi[7,8]  R2103     -1.9598876237869263e+00
    phi[7,8]  R2104     -1.6876850128173828e+00
    phi[7,8]  R2105     -2.1231966018676758e+00
    phi[7,8]  R2106     -8.4606006741523743e-02
    phi[7,8]  R2107     -2.6637795567512512e-01
    phi[7,8]  R2108     -1.9401203393936157e+00
    phi[7,8]  R2109     6.2804079055786133e-01
    phi[7,8]  R2110     -3.5028311610221863e-01
    phi[7,8]  R2111     -2.4033676087856293e-01
    phi[7,8]  R2112     -1.3029394149780273e+00
    phi[7,8]  R2113     4.4234764575958252e-01
    phi[7,8]  R2114     -1.5416851043701172e+00
    phi[7,8]  R2115     -1.0891468524932861e+00
    phi[7,8]  R2116     -9.5075517892837524e-01
    phi[7,8]  R2117     -9.2837697267532349e-01
    phi[7,8]  R2118     -2.7207186818122864e-01
    phi[7,8]  R2119     5.4030284285545349e-02
    phi[7,8]  R2120     2.7308133244514465e-01
    phi[7,8]  R2121     1.3003057241439819e-01
    phi[7,8]  R2122     -3.9329674839973450e-01
    phi[7,8]  R2123     -1.6586083173751831e-01
    phi[7,8]  R2124     -1.8623694181442261e+00
    phi[7,8]  R2125     -4.1338509321212769e-01
    phi[7,8]  R2126     -8.2793760299682617e-01
    phi[7,8]  R2127     9.2070117592811584e-02
    phi[7,8]  R2128     8.2646727561950684e-01
    phi[7,8]  R2129     -7.6317095756530762e-01
    phi[7,8]  R2130     -1.4238414764404297e+00
    phi[7,8]  R2131     -2.1155829429626465e+00
    phi[7,8]  R2132     -1.1043585538864136e+00
    phi[7,8]  R2133     -1.1694883108139038e+00
    phi[7,8]  R2134     3.5722288489341736e-01
    phi[7,8]  R2135     4.5418989658355713e-01
    phi[7,8]  R2136     2.1634502410888672e+00
    phi[7,8]  R2137     2.6221516132354736e+00
    phi[7,8]  R2138     1.7823657989501953e+00
    phi[7,8]  R2139     1.9324274063110352e+00
    phi[7,8]  R2140     1.7130719423294067e+00
    phi[7,8]  R2141     2.3169786930084229e+00
    phi[7,8]  R2142     1.7829190492630005e+00
    phi[7,8]  R2143     3.5299210548400879e+00
    phi[7,8]  R2144     3.2690410614013672e+00
    phi[7,8]  R2145     2.75260591506958
    phi[7,8]  R2146     -1.9525480270385742e+00
    phi[7,8]  R2147     -1.4175292253494263e+00
    phi[7,8]  R2148     -2.1970111131668091e-01
    phi[7,8]  R2149     -4.1523718833923340e+00
    phi[7,8]  R2150     -2.0246975421905518e+00
    phi[7,8]  R2151     -2.4550344944000244e+00
    phi[7,8]  R2152     -3.2680863142013550e-01
    phi[7,8]  R2153     -2.5848476886749268e+00
    phi[7,8]  R2154     7.4764645099639893e-01
    phi[7,8]  R2155     -3.1898903846740723e+00
    phi[7,8]  R2156     -5.4546165466308594e-01
    phi[7,8]  R2157     -1.1594562530517578e+00
    phi[7,8]  R2158     -3.4043356776237488e-01
    phi[7,8]  R2159     -2.9325668811798096e+00
    phi[7,8]  R2160     -2.8987884521484375e+00
    phi[7,8]  R2161     0.979177713394165
    phi[7,8]  R2162     1.3944133520126343e+00
    phi[7,8]  R2163     -3.6619114875793457e+00
    phi[7,8]  R2164     -2.1798050403594971e+00
    phi[7,8]  R2165     -7.4842017889022827e-01
    phi[7,8]  R2166     -2.3533110618591309e+00
    phi[7,8]  R2167     -3.6799725890159607e-01
    phi[7,8]  R2168     1.0972465276718140e+00
    phi[7,8]  R2169     -3.1089329719543457e+00
    phi[7,8]  R2170     -3.3948142528533936e+00
    phi[7,8]  R2171     -3.2857654094696045e+00
    phi[7,8]  R2172     -3.1955838203430176e+00
    phi[7,8]  R2173     -4.8639902472496033e-01
    phi[7,8]  R2174     -1.7044667005538940e+00
    phi[7,8]  R2175     -1.0529565811157227e+00
    phi[7,8]  R2176     7.2772687673568726e-01
    phi[7,8]  R2177     -3.6033661365509033e+00
    phi[7,8]  R2178     -2.7375929355621338e+00
    phi[7,8]  R2179     -0.211117684841156
    phi[7,8]  R2180     -1.1090617179870605e+00
    phi[7,8]  R2181     -2.6246135234832764e+00
    phi[7,8]  R2182     -4.2373692989349365e-01
    phi[7,8]  R2183     -2.4279634952545166e+00
    phi[7,8]  R2184     -1.2560037374496460e+00
    phi[7,8]  R2185     -1.9961750507354736e+00
    phi[7,8]  R2186     -6.0812622308731079e-01
    phi[7,8]  R2187     -3.2924744486808777e-01
    phi[7,8]  R2188     -2.0905160903930664e+00
    phi[7,8]  R2189     -3.5219824314117432e+00
    phi[7,8]  R2190     -3.0424852371215820e+00
    phi[7,8]  R2191     2.1669404506683350e+00
    phi[7,8]  R2192     3.1997540593147278e-01
    phi[7,8]  R2193     -1.3156360387802124e+00
    phi[7,8]  R2194     -1.7798343896865845e+00
    phi[7,8]  R2195     -1.2834142446517944e+00
    phi[7,8]  R2196     1.3197565078735352e+00
    phi[7,8]  R2197     -0.632849395275116
    phi[7,8]  R2198     -1.4857529401779175e+00
    phi[7,8]  R2199     1.5595804452896118e+00
    phi[7,8]  R2200     -4.1266790032386780e-01
    phi[7,8]  R2201     -6.7522341012954712e-01
    phi[7,8]  R2202     -4.1413583755493164e+00
    phi[7,8]  R2203     6.6483139991760254e-01
    phi[7,8]  R2204     -3.6913793087005615e+00
    phi[7,8]  R2205     -2.3175554275512695e+00
    phi[7,8]  R2206     2.2089569568634033e+00
    phi[7,8]  R2207     1.3484935760498047e+00
    phi[7,8]  R2208     -4.8041185736656189e-01
    phi[7,8]  R2209     -2.6452083587646484e+00
    phi[7,8]  R2210     2.8764119148254395e+00
    phi[7,8]  R2211     -3.4812183380126953e+00
    phi[7,8]  R2212     -2.5862739086151123e+00
    phi[7,8]  R2213     -2.5641758441925049e+00
    phi[7,8]  R2214     -3.3103356361389160e+00
    phi[7,8]  R2215     -2.3477177619934082e+00
    phi[7,8]  R2216     -3.2525966167449951e+00
    phi[7,8]  R2217     -2.9624862670898438e+00
    phi[7,8]  R2218     -2.0929579734802246e+00
    phi[7,8]  R2219     -4.2364826202392578e+00
    phi[7,8]  R2220     -1.8103140592575073e+00
    phi[7,8]  R2221     2.9038208723068237e-01
    phi[7,8]  R2222     1.6057683229446411e+00
    phi[7,8]  R2223     1.0093998908996582e-01
    phi[7,8]  R2224     1.1565150022506714e+00
    phi[7,8]  R2225     1.1449407339096069e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2226     -3.0999999046325684e+00
    phi[8,7]  R2227     -3.0999999046325684e+00
    phi[8,7]  R2228     -2.2400000095367432e+00
    phi[8,7]  R2229     -2.2400000095367432e+00
    phi[8,7]  R2230     -3.0999999046325684e+00
    phi[8,7]  R2231     -3.0999999046325684e+00
    phi[8,7]  R2232     -2.5699999332427979e+00
    phi[8,7]  R2233     -2.5699999332427979e+00
    phi[8,7]  R2234     -3.0999999046325684e+00
    phi[8,7]  R2235     -3.0999999046325684e+00
    phi[8,7]  R2236     -2.0899999141693115e+00
    phi[8,7]  R2237     -2.0899999141693115e+00
    phi[8,7]  R2238     -3.0999999046325684e+00
    phi[8,7]  R2239     -3.0999999046325684e+00
    phi[8,7]  R2240     2.1634502410888672e+00
    phi[8,7]  R2241     2.6221516132354736e+00
    phi[8,7]  R2242     1.7823657989501953e+00
    phi[8,7]  R2243     1.9324274063110352e+00
    phi[8,7]  R2244     1.7130719423294067e+00
    phi[8,7]  R2245     2.3169786930084229e+00
    phi[8,7]  R2246     1.7829190492630005e+00
    phi[8,7]  R2247     3.5299210548400879e+00
    phi[8,7]  R2248     3.2690410614013672e+00
    phi[8,7]  R2249     2.75260591506958
    phi[8,7]  R2250     -1.9525480270385742e+00
    phi[8,7]  R2251     -1.4175292253494263e+00
    phi[8,7]  R2252     -2.1970111131668091e-01
    phi[8,7]  R2253     -4.1523718833923340e+00
    phi[8,7]  R2254     -2.0246975421905518e+00
    phi[8,7]  R2255     -2.4550344944000244e+00
    phi[8,7]  R2256     -3.2680863142013550e-01
    phi[8,7]  R2257     -2.5848476886749268e+00
    phi[8,7]  R2258     7.4764645099639893e-01
    phi[8,7]  R2259     -3.1898903846740723e+00
    phi[8,7]  R2260     -5.4546165466308594e-01
    phi[8,7]  R2261     -1.1594562530517578e+00
    phi[8,7]  R2262     -3.4043356776237488e-01
    phi[8,7]  R2263     -2.9325668811798096e+00
    phi[8,7]  R2264     -2.8987884521484375e+00
    phi[8,7]  R2265     0.979177713394165
    phi[8,7]  R2266     1.3944133520126343e+00
    phi[8,7]  R2267     -3.6619114875793457e+00
    phi[8,7]  R2268     -2.1798050403594971e+00
    phi[8,7]  R2269     -7.4842017889022827e-01
    phi[8,7]  R2270     -2.3533110618591309e+00
    phi[8,7]  R2271     -3.6799725890159607e-01
    phi[8,7]  R2272     1.0972465276718140e+00
    phi[8,7]  R2273     -3.1089329719543457e+00
    phi[8,7]  R2274     -3.3948142528533936e+00
    phi[8,7]  R2275     -3.2857654094696045e+00
    phi[8,7]  R2276     -3.1955838203430176e+00
    phi[8,7]  R2277     -4.8639902472496033e-01
    phi[8,7]  R2278     -1.7044667005538940e+00
    phi[8,7]  R2279     -1.0529565811157227e+00
    phi[8,7]  R2280     7.2772687673568726e-01
    phi[8,7]  R2281     -3.6033661365509033e+00
    phi[8,7]  R2282     -2.7375929355621338e+00
    phi[8,7]  R2283     -0.211117684841156
    phi[8,7]  R2284     -1.1090617179870605e+00
    phi[8,7]  R2285     -2.6246135234832764e+00
    phi[8,7]  R2286     -4.2373692989349365e-01
    phi[8,7]  R2287     -2.4279634952545166e+00
    phi[8,7]  R2288     -1.2560037374496460e+00
    phi[8,7]  R2289     -1.9961750507354736e+00
    phi[8,7]  R2290     -6.0812622308731079e-01
    phi[8,7]  R2291     -3.2924744486808777e-01
    phi[8,7]  R2292     -2.0905160903930664e+00
    phi[8,7]  R2293     -3.5219824314117432e+00
    phi[8,7]  R2294     -3.0424852371215820e+00
    phi[8,7]  R2295     2.1669404506683350e+00
    phi[8,7]  R2296     3.1997540593147278e-01
    phi[8,7]  R2297     -1.3156360387802124e+00
    phi[8,7]  R2298     -1.7798343896865845e+00
    phi[8,7]  R2299     -1.2834142446517944e+00
    phi[8,7]  R2300     1.3197565078735352e+00
    phi[8,7]  R2301     -0.632849395275116
    phi[8,7]  R2302     -1.4857529401779175e+00
    phi[8,7]  R2303     1.5595804452896118e+00
    phi[8,7]  R2304     -4.1266790032386780e-01
    phi[8,7]  R2305     -6.7522341012954712e-01
    phi[8,7]  R2306     -4.1413583755493164e+00
    phi[8,7]  R2307     6.6483139991760254e-01
    phi[8,7]  R2308     -3.6913793087005615e+00
    phi[8,7]  R2309     -2.3175554275512695e+00
    phi[8,7]  R2310     2.2089569568634033e+00
    phi[8,7]  R2311     1.3484935760498047e+00
    phi[8,7]  R2312     -4.8041185736656189e-01
    phi[8,7]  R2313     -2.6452083587646484e+00
    phi[8,7]  R2314     2.8764119148254395e+00
    phi[8,7]  R2315     -3.4812183380126953e+00
    phi[8,7]  R2316     -2.5862739086151123e+00
    phi[8,7]  R2317     -2.5641758441925049e+00
    phi[8,7]  R2318     -3.3103356361389160e+00
    phi[8,7]  R2319     -2.3477177619934082e+00
    phi[8,7]  R2320     -3.2525966167449951e+00
    phi[8,7]  R2321     -2.9624862670898438e+00
    phi[8,7]  R2322     -2.0929579734802246e+00
    phi[8,7]  R2323     -4.2364826202392578e+00
    phi[8,7]  R2324     -1.8103140592575073e+00
    phi[8,7]  R2325     2.9038208723068237e-01
    phi[8,7]  R2326     1.6057683229446411e+00
    phi[8,7]  R2327     1.0093998908996582e-01
    phi[8,7]  R2328     1.1565150022506714e+00
    phi[8,7]  R2329     1.1449407339096069e+00
    phi[8,7]  R2330     1.0104973316192627e+00
    phi[8,7]  R2331     1.10867178440094
    phi[8,7]  R2332     3.3407423645257950e-02
    phi[8,7]  R2333     0.521316647529602
    phi[8,7]  R2334     1.1180651187896729e+00
    phi[8,7]  R2335     1.0119259357452393e+00
    phi[8,7]  R2336     -5.3073018789291382e-01
    phi[8,7]  R2337     -1.1281306743621826e+00
    phi[8,7]  R2338     1.7591068744659424e+00
    phi[8,7]  R2339     1.4970685243606567e+00
    phi[8,7]  R2340     -1.2542389631271362e+00
    phi[8,7]  R2341     -1.5016587972640991e+00
    phi[8,7]  R2342     -1.7590734958648682e+00
    phi[8,7]  R2343     -1.1584981679916382e+00
    phi[8,7]  R2344     -1.8643788099288940e+00
    phi[8,7]  R2345     -1.6898518800735474e+00
    phi[8,7]  R2346     -8.2104313373565674e-01
    phi[8,7]  R2347     -1.9598876237869263e+00
    phi[8,7]  R2348     -1.6876850128173828e+00
    phi[8,7]  R2349     -2.1231966018676758e+00
    phi[8,7]  R2350     -8.4606006741523743e-02
    phi[8,7]  R2351     -2.6637795567512512e-01
    phi[8,7]  R2352     -1.9401203393936157e+00
    phi[8,7]  R2353     6.2804079055786133e-01
    phi[8,7]  R2354     -3.5028311610221863e-01
    phi[8,7]  R2355     -2.4033676087856293e-01
    phi[8,7]  R2356     -1.3029394149780273e+00
    phi[8,7]  R2357     4.4234764575958252e-01
    phi[8,7]  R2358     -1.5416851043701172e+00
    phi[8,7]  R2359     -1.0891468524932861e+00
    phi[8,7]  R2360     -9.5075517892837524e-01
    phi[8,7]  R2361     -9.2837697267532349e-01
    phi[8,7]  R2362     -2.7207186818122864e-01
    phi[8,7]  R2363     5.4030284285545349e-02
    phi[8,7]  R2364     2.7308133244514465e-01
    phi[8,7]  R2365     1.3003057241439819e-01
    phi[8,7]  R2366     -3.9329674839973450e-01
    phi[8,7]  R2367     -1.6586083173751831e-01
    phi[8,7]  R2368     -1.8623694181442261e+00
    phi[8,7]  R2369     -4.1338509321212769e-01
    phi[8,7]  R2370     -8.2793760299682617e-01
    phi[8,7]  R2371     9.2070117592811584e-02
    phi[8,7]  R2372     8.2646727561950684e-01
    phi[8,7]  R2373     -7.6317095756530762e-01
    phi[8,7]  R2374     -1.4238414764404297e+00
    phi[8,7]  R2375     -2.1155829429626465e+00
    phi[8,7]  R2376     -1.1043585538864136e+00
    phi[8,7]  R2377     -1.1694883108139038e+00
    phi[8,7]  R2378     3.5722288489341736e-01
    phi[8,7]  R2379     4.5418989658355713e-01
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2380     -3.0999999046325684e+00
    phi[8,9]  R2381     -3.0999999046325684e+00
    phi[8,9]  R2382     -2.2400000095367432e+00
    phi[8,9]  R2383     -2.2400000095367432e+00
    phi[8,9]  R2384     -3.0999999046325684e+00
    phi[8,9]  R2385     -3.0999999046325684e+00
    phi[8,9]  R2386     -2.5699999332427979e+00
    phi[8,9]  R2387     -2.5699999332427979e+00
    phi[8,9]  R2388     -3.0999999046325684e+00
    phi[8,9]  R2389     -3.0999999046325684e+00
    phi[8,9]  R2390     -2.0899999141693115e+00
    phi[8,9]  R2391     -2.0899999141693115e+00
    phi[8,9]  R2392     -3.0999999046325684e+00
    phi[8,9]  R2393     -3.0999999046325684e+00
    phi[8,9]  R2394     2.1634502410888672e+00
    phi[8,9]  R2395     2.6221516132354736e+00
    phi[8,9]  R2396     1.7823657989501953e+00
    phi[8,9]  R2397     1.9324274063110352e+00
    phi[8,9]  R2398     1.7130719423294067e+00
    phi[8,9]  R2399     2.3169786930084229e+00
    phi[8,9]  R2400     1.7829190492630005e+00
    phi[8,9]  R2401     3.5299210548400879e+00
    phi[8,9]  R2402     3.2690410614013672e+00
    phi[8,9]  R2403     2.75260591506958
    phi[8,9]  R2404     -1.9525480270385742e+00
    phi[8,9]  R2405     -1.4175292253494263e+00
    phi[8,9]  R2406     -2.1970111131668091e-01
    phi[8,9]  R2407     -4.1523718833923340e+00
    phi[8,9]  R2408     -2.0246975421905518e+00
    phi[8,9]  R2409     -2.4550344944000244e+00
    phi[8,9]  R2410     -3.2680863142013550e-01
    phi[8,9]  R2411     -2.5848476886749268e+00
    phi[8,9]  R2412     7.4764645099639893e-01
    phi[8,9]  R2413     -3.1898903846740723e+00
    phi[8,9]  R2414     -5.4546165466308594e-01
    phi[8,9]  R2415     -1.1594562530517578e+00
    phi[8,9]  R2416     -3.4043356776237488e-01
    phi[8,9]  R2417     -2.9325668811798096e+00
    phi[8,9]  R2418     -2.8987884521484375e+00
    phi[8,9]  R2419     0.979177713394165
    phi[8,9]  R2420     1.3944133520126343e+00
    phi[8,9]  R2421     -3.6619114875793457e+00
    phi[8,9]  R2422     -2.1798050403594971e+00
    phi[8,9]  R2423     -7.4842017889022827e-01
    phi[8,9]  R2424     -2.3533110618591309e+00
    phi[8,9]  R2425     -3.6799725890159607e-01
    phi[8,9]  R2426     1.0972465276718140e+00
    phi[8,9]  R2427     -3.1089329719543457e+00
    phi[8,9]  R2428     -3.3948142528533936e+00
    phi[8,9]  R2429     -3.2857654094696045e+00
    phi[8,9]  R2430     -3.1955838203430176e+00
    phi[8,9]  R2431     -4.8639902472496033e-01
    phi[8,9]  R2432     -1.7044667005538940e+00
    phi[8,9]  R2433     -1.0529565811157227e+00
    phi[8,9]  R2434     7.2772687673568726e-01
    phi[8,9]  R2435     -3.6033661365509033e+00
    phi[8,9]  R2436     -2.7375929355621338e+00
    phi[8,9]  R2437     -0.211117684841156
    phi[8,9]  R2438     -1.1090617179870605e+00
    phi[8,9]  R2439     -2.6246135234832764e+00
    phi[8,9]  R2440     -4.2373692989349365e-01
    phi[8,9]  R2441     -2.4279634952545166e+00
    phi[8,9]  R2442     -1.2560037374496460e+00
    phi[8,9]  R2443     -1.9961750507354736e+00
    phi[8,9]  R2444     -6.0812622308731079e-01
    phi[8,9]  R2445     -3.2924744486808777e-01
    phi[8,9]  R2446     -2.0905160903930664e+00
    phi[8,9]  R2447     -3.5219824314117432e+00
    phi[8,9]  R2448     -3.0424852371215820e+00
    phi[8,9]  R2449     2.1669404506683350e+00
    phi[8,9]  R2450     3.1997540593147278e-01
    phi[8,9]  R2451     -1.3156360387802124e+00
    phi[8,9]  R2452     -1.7798343896865845e+00
    phi[8,9]  R2453     -1.2834142446517944e+00
    phi[8,9]  R2454     1.3197565078735352e+00
    phi[8,9]  R2455     -0.632849395275116
    phi[8,9]  R2456     -1.4857529401779175e+00
    phi[8,9]  R2457     1.5595804452896118e+00
    phi[8,9]  R2458     -4.1266790032386780e-01
    phi[8,9]  R2459     -6.7522341012954712e-01
    phi[8,9]  R2460     -4.1413583755493164e+00
    phi[8,9]  R2461     6.6483139991760254e-01
    phi[8,9]  R2462     -3.6913793087005615e+00
    phi[8,9]  R2463     -2.3175554275512695e+00
    phi[8,9]  R2464     2.2089569568634033e+00
    phi[8,9]  R2465     1.3484935760498047e+00
    phi[8,9]  R2466     -4.8041185736656189e-01
    phi[8,9]  R2467     -2.6452083587646484e+00
    phi[8,9]  R2468     2.8764119148254395e+00
    phi[8,9]  R2469     -3.4812183380126953e+00
    phi[8,9]  R2470     -2.5862739086151123e+00
    phi[8,9]  R2471     -2.5641758441925049e+00
    phi[8,9]  R2472     -3.3103356361389160e+00
    phi[8,9]  R2473     -2.3477177619934082e+00
    phi[8,9]  R2474     -3.2525966167449951e+00
    phi[8,9]  R2475     -2.9624862670898438e+00
    phi[8,9]  R2476     -2.0929579734802246e+00
    phi[8,9]  R2477     -4.2364826202392578e+00
    phi[8,9]  R2478     -1.8103140592575073e+00
    phi[8,9]  R2479     2.9038208723068237e-01
    phi[8,9]  R2480     1.6057683229446411e+00
    phi[8,9]  R2481     1.0093998908996582e-01
    phi[8,9]  R2482     1.1565150022506714e+00
    phi[8,9]  R2483     1.1449407339096069e+00
    phi[8,9]  R2484     3.4904921054840088e+00
    phi[8,9]  R2485     1.4727970361709595e+00
    phi[8,9]  R2486     2.5210235118865967e+00
    phi[8,9]  R2487     1.7337300777435303e+00
    phi[8,9]  R2488     1.9884278774261475e+00
    phi[8,9]  R2489     3.4749491214752197e+00
    phi[8,9]  R2490     4.2311649322509766e+00
    phi[8,9]  R2491     2.8107554912567139e+00
    phi[8,9]  R2492     2.5325076580047607e+00
    phi[8,9]  R2493     -2.2708638012409210e-01
    phi[8,9]  R2494     -4.5547986030578613e-01
    phi[8,9]  R2495     -2.4728229045867920e+00
    phi[8,9]  R2496     1.2274993658065796e+00
    phi[8,9]  R2497     -1.9573992490768433e-01
    phi[8,9]  R2498     -4.8519638180732727e-01
    phi[8,9]  R2499     -3.7261424064636230e+00
    phi[8,9]  R2500     -2.5186202526092529e+00
    phi[8,9]  R2501     -8.3140349388122559e-01
    phi[8,9]  R2502     -1.6850026845932007e+00
    phi[8,9]  R2503     -2.5643837451934814e+00
    phi[8,9]  R2504     -3.0810458660125732e+00
    phi[8,9]  R2505     -2.7657559514045715e-01
    phi[8,9]  R2506     -1.4796851873397827e+00
    phi[8,9]  R2507     2.4014606475830078e+00
    phi[8,9]  R2508     -9.0325701236724854e-01
    phi[8,9]  R2509     -2.3807880878448486e+00
    phi[8,9]  R2510     -1.1103235483169556e+00
    phi[8,9]  R2511     2.2838933467864990e+00
    phi[8,9]  R2512     -5.0104662775993347e-02
    phi[8,9]  R2513     -4.0013399124145508e+00
    phi[8,9]  R2514     -1.1639746427536011e+00
    phi[8,9]  R2515     -2.55611515045166
    phi[8,9]  R2516     2.0806839466094971e+00
    phi[8,9]  R2517     -1.9095526933670044e+00
    phi[8,9]  R2518     -7.8921101987361908e-02
    phi[8,9]  R2519     -1.9729385375976562e+00
    phi[8,9]  R2520     2.6759386062622070e+00
    phi[8,9]  R2521     4.6213066577911377e-01
    phi[8,9]  R2522     -4.4570879936218262e+00
    phi[8,9]  R2523     4.0773463249206543e+00
    phi[8,9]  R2524     -2.1155569553375244e+00
    phi[8,9]  R2525     -3.4662010669708252e+00
    phi[8,9]  R2526     -2.2347145080566406e+00
    phi[8,9]  R2527     2.4870846271514893e+00
    phi[8,9]  R2528     -1.4745303988456726e-01
    phi[8,9]  R2529     1.9755135774612427e+00
    phi[8,9]  R2530     3.3077652454376221e+00
    phi[8,9]  R2531     -4.6425480842590332e+00
    phi[8,9]  R2532     -3.0799205303192139e+00
    phi[8,9]  R2533     -1.6020667552947998e+00
    phi[8,9]  R2534     -2.6461389064788818e+00
    phi[8,9]  R2535     -2.0077441632747650e-01
    phi[8,9]  R2536     2.4712851047515869e+00
    phi[8,9]  R2537     -2.5821166038513184e+00
    phi[8,9]  R2538     -3.5815567970275879e+00
    phi[8,9]  R2539     -4.2060499191284180e+00
    phi[8,9]  R2540     -3.3878018856048584e+00
    phi[8,9]  R2541     -0.839398205280304
    phi[8,9]  R2542     1.4603896141052246e+00
    phi[8,9]  R2543     -1.5206488966941833e-01
    phi[8,9]  R2544     2.0051459968090057e-01
    phi[8,9]  R2545     -1.9171637296676636e+00
    phi[8,9]  R2546     -1.2257201671600342e+00
    phi[8,9]  R2547     9.5642918348312378e-01
    phi[8,9]  R2548     -4.4751472473144531e+00
    phi[8,9]  R2549     1.3491888344287872e-01
    phi[8,9]  R2550     -1.8634755611419678e+00
    phi[8,9]  R2551     1.4654016494750977e+00
    phi[8,9]  R2552     2.1931796073913574e+00
    phi[8,9]  R2553     -2.5477592945098877e+00
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2554     -3.0999999046325684e+00
    phi[9,8]  R2555     -3.0999999046325684e+00
    phi[9,8]  R2556     -2.2400000095367432e+00
    phi[9,8]  R2557     -2.2400000095367432e+00
    phi[9,8]  R2558     -3.0999999046325684e+00
    phi[9,8]  R2559     -3.0999999046325684e+00
    phi[9,8]  R2560     -2.5699999332427979e+00
    phi[9,8]  R2561     -2.5699999332427979e+00
    phi[9,8]  R2562     -3.0999999046325684e+00
    phi[9,8]  R2563     -3.0999999046325684e+00
    phi[9,8]  R2564     -2.0899999141693115e+00
    phi[9,8]  R2565     -2.0899999141693115e+00
    phi[9,8]  R2566     -3.0999999046325684e+00
    phi[9,8]  R2567     -3.0999999046325684e+00
    phi[9,8]  R2568     3.4904921054840088e+00
    phi[9,8]  R2569     1.4727970361709595e+00
    phi[9,8]  R2570     2.5210235118865967e+00
    phi[9,8]  R2571     1.7337300777435303e+00
    phi[9,8]  R2572     1.9884278774261475e+00
    phi[9,8]  R2573     3.4749491214752197e+00
    phi[9,8]  R2574     4.2311649322509766e+00
    phi[9,8]  R2575     2.8107554912567139e+00
    phi[9,8]  R2576     2.5325076580047607e+00
    phi[9,8]  R2577     -2.2708638012409210e-01
    phi[9,8]  R2578     -4.5547986030578613e-01
    phi[9,8]  R2579     -2.4728229045867920e+00
    phi[9,8]  R2580     1.2274993658065796e+00
    phi[9,8]  R2581     -1.9573992490768433e-01
    phi[9,8]  R2582     -4.8519638180732727e-01
    phi[9,8]  R2583     -3.7261424064636230e+00
    phi[9,8]  R2584     -2.5186202526092529e+00
    phi[9,8]  R2585     -8.3140349388122559e-01
    phi[9,8]  R2586     -1.6850026845932007e+00
    phi[9,8]  R2587     -2.5643837451934814e+00
    phi[9,8]  R2588     -3.0810458660125732e+00
    phi[9,8]  R2589     -2.7657559514045715e-01
    phi[9,8]  R2590     -1.4796851873397827e+00
    phi[9,8]  R2591     2.4014606475830078e+00
    phi[9,8]  R2592     -9.0325701236724854e-01
    phi[9,8]  R2593     -2.3807880878448486e+00
    phi[9,8]  R2594     -1.1103235483169556e+00
    phi[9,8]  R2595     2.2838933467864990e+00
    phi[9,8]  R2596     -5.0104662775993347e-02
    phi[9,8]  R2597     -4.0013399124145508e+00
    phi[9,8]  R2598     -1.1639746427536011e+00
    phi[9,8]  R2599     -2.55611515045166
    phi[9,8]  R2600     2.0806839466094971e+00
    phi[9,8]  R2601     -1.9095526933670044e+00
    phi[9,8]  R2602     -7.8921101987361908e-02
    phi[9,8]  R2603     -1.9729385375976562e+00
    phi[9,8]  R2604     2.6759386062622070e+00
    phi[9,8]  R2605     4.6213066577911377e-01
    phi[9,8]  R2606     -4.4570879936218262e+00
    phi[9,8]  R2607     4.0773463249206543e+00
    phi[9,8]  R2608     -2.1155569553375244e+00
    phi[9,8]  R2609     -3.4662010669708252e+00
    phi[9,8]  R2610     -2.2347145080566406e+00
    phi[9,8]  R2611     2.4870846271514893e+00
    phi[9,8]  R2612     -1.4745303988456726e-01
    phi[9,8]  R2613     1.9755135774612427e+00
    phi[9,8]  R2614     3.3077652454376221e+00
    phi[9,8]  R2615     -4.6425480842590332e+00
    phi[9,8]  R2616     -3.0799205303192139e+00
    phi[9,8]  R2617     -1.6020667552947998e+00
    phi[9,8]  R2618     -2.6461389064788818e+00
    phi[9,8]  R2619     -2.0077441632747650e-01
    phi[9,8]  R2620     2.4712851047515869e+00
    phi[9,8]  R2621     -2.5821166038513184e+00
    phi[9,8]  R2622     -3.5815567970275879e+00
    phi[9,8]  R2623     -4.2060499191284180e+00
    phi[9,8]  R2624     -3.3878018856048584e+00
    phi[9,8]  R2625     -0.839398205280304
    phi[9,8]  R2626     1.4603896141052246e+00
    phi[9,8]  R2627     -1.5206488966941833e-01
    phi[9,8]  R2628     2.0051459968090057e-01
    phi[9,8]  R2629     -1.9171637296676636e+00
    phi[9,8]  R2630     -1.2257201671600342e+00
    phi[9,8]  R2631     9.5642918348312378e-01
    phi[9,8]  R2632     -4.4751472473144531e+00
    phi[9,8]  R2633     1.3491888344287872e-01
    phi[9,8]  R2634     -1.8634755611419678e+00
    phi[9,8]  R2635     1.4654016494750977e+00
    phi[9,8]  R2636     2.1931796073913574e+00
    phi[9,8]  R2637     -2.5477592945098877e+00
    phi[9,8]  R2638     2.1634502410888672e+00
    phi[9,8]  R2639     2.6221516132354736e+00
    phi[9,8]  R2640     1.7823657989501953e+00
    phi[9,8]  R2641     1.9324274063110352e+00
    phi[9,8]  R2642     1.7130719423294067e+00
    phi[9,8]  R2643     2.3169786930084229e+00
    phi[9,8]  R2644     1.7829190492630005e+00
    phi[9,8]  R2645     3.5299210548400879e+00
    phi[9,8]  R2646     3.2690410614013672e+00
    phi[9,8]  R2647     2.75260591506958
    phi[9,8]  R2648     -1.9525480270385742e+00
    phi[9,8]  R2649     -1.4175292253494263e+00
    phi[9,8]  R2650     -2.1970111131668091e-01
    phi[9,8]  R2651     -4.1523718833923340e+00
    phi[9,8]  R2652     -2.0246975421905518e+00
    phi[9,8]  R2653     -2.4550344944000244e+00
    phi[9,8]  R2654     -3.2680863142013550e-01
    phi[9,8]  R2655     -2.5848476886749268e+00
    phi[9,8]  R2656     7.4764645099639893e-01
    phi[9,8]  R2657     -3.1898903846740723e+00
    phi[9,8]  R2658     -5.4546165466308594e-01
    phi[9,8]  R2659     -1.1594562530517578e+00
    phi[9,8]  R2660     -3.4043356776237488e-01
    phi[9,8]  R2661     -2.9325668811798096e+00
    phi[9,8]  R2662     -2.8987884521484375e+00
    phi[9,8]  R2663     0.979177713394165
    phi[9,8]  R2664     1.3944133520126343e+00
    phi[9,8]  R2665     -3.6619114875793457e+00
    phi[9,8]  R2666     -2.1798050403594971e+00
    phi[9,8]  R2667     -7.4842017889022827e-01
    phi[9,8]  R2668     -2.3533110618591309e+00
    phi[9,8]  R2669     -3.6799725890159607e-01
    phi[9,8]  R2670     1.0972465276718140e+00
    phi[9,8]  R2671     -3.1089329719543457e+00
    phi[9,8]  R2672     -3.3948142528533936e+00
    phi[9,8]  R2673     -3.2857654094696045e+00
    phi[9,8]  R2674     -3.1955838203430176e+00
    phi[9,8]  R2675     -4.8639902472496033e-01
    phi[9,8]  R2676     -1.7044667005538940e+00
    phi[9,8]  R2677     -1.0529565811157227e+00
    phi[9,8]  R2678     7.2772687673568726e-01
    phi[9,8]  R2679     -3.6033661365509033e+00
    phi[9,8]  R2680     -2.7375929355621338e+00
    phi[9,8]  R2681     -0.211117684841156
    phi[9,8]  R2682     -1.1090617179870605e+00
    phi[9,8]  R2683     -2.6246135234832764e+00
    phi[9,8]  R2684     -4.2373692989349365e-01
    phi[9,8]  R2685     -2.4279634952545166e+00
    phi[9,8]  R2686     -1.2560037374496460e+00
    phi[9,8]  R2687     -1.9961750507354736e+00
    phi[9,8]  R2688     -6.0812622308731079e-01
    phi[9,8]  R2689     -3.2924744486808777e-01
    phi[9,8]  R2690     -2.0905160903930664e+00
    phi[9,8]  R2691     -3.5219824314117432e+00
    phi[9,8]  R2692     -3.0424852371215820e+00
    phi[9,8]  R2693     2.1669404506683350e+00
    phi[9,8]  R2694     3.1997540593147278e-01
    phi[9,8]  R2695     -1.3156360387802124e+00
    phi[9,8]  R2696     -1.7798343896865845e+00
    phi[9,8]  R2697     -1.2834142446517944e+00
    phi[9,8]  R2698     1.3197565078735352e+00
    phi[9,8]  R2699     -0.632849395275116
    phi[9,8]  R2700     -1.4857529401779175e+00
    phi[9,8]  R2701     1.5595804452896118e+00
    phi[9,8]  R2702     -4.1266790032386780e-01
    phi[9,8]  R2703     -6.7522341012954712e-01
    phi[9,8]  R2704     -4.1413583755493164e+00
    phi[9,8]  R2705     6.6483139991760254e-01
    phi[9,8]  R2706     -3.6913793087005615e+00
    phi[9,8]  R2707     -2.3175554275512695e+00
    phi[9,8]  R2708     2.2089569568634033e+00
    phi[9,8]  R2709     1.3484935760498047e+00
    phi[9,8]  R2710     -4.8041185736656189e-01
    phi[9,8]  R2711     -2.6452083587646484e+00
    phi[9,8]  R2712     2.8764119148254395e+00
    phi[9,8]  R2713     -3.4812183380126953e+00
    phi[9,8]  R2714     -2.5862739086151123e+00
    phi[9,8]  R2715     -2.5641758441925049e+00
    phi[9,8]  R2716     -3.3103356361389160e+00
    phi[9,8]  R2717     -2.3477177619934082e+00
    phi[9,8]  R2718     -3.2525966167449951e+00
    phi[9,8]  R2719     -2.9624862670898438e+00
    phi[9,8]  R2720     -2.0929579734802246e+00
    phi[9,8]  R2721     -4.2364826202392578e+00
    phi[9,8]  R2722     -1.8103140592575073e+00
    phi[9,8]  R2723     2.9038208723068237e-01
    phi[9,8]  R2724     1.6057683229446411e+00
    phi[9,8]  R2725     1.0093998908996582e-01
    phi[9,8]  R2726     1.1565150022506714e+00
    phi[9,8]  R2727     1.1449407339096069e+00
    phi[9,11]  R81       1
    phi[9,11]  R82       1
    phi[9,11]  R83       -1.0660697052501651e+00
    phi[9,11]  R84       -1.7609238894928119e+00
    phi[9,11]  R85       8.0637182422278020e-01
    phi[9,11]  R86       2.2759530614163310e+00
    phi[9,11]  R87       -2.8768387459556162e+00
    phi[9,11]  R88       -8.4146320256262763e-01
    phi[9,11]  R89       2.7420950358790686e+00
    phi[9,11]  R91       -1
    phi[9,11]  R2728     -4.1660696098827330e+00
    phi[9,11]  R2729     -2.0339301993824033e+00
    phi[9,11]  R2730     -4.0009238990295550e+00
    phi[9,11]  R2731     -4.7907612004393130e-01
    phi[9,11]  R2732     -2.2936280804097882e+00
    phi[9,11]  R2733     -3.9063717288553486e+00
    phi[9,11]  R2734     -2.9404687182646683e-01
    phi[9,11]  R2735     -4.8459529946591289e+00
    phi[9,11]  R2736     -5.9768386505881850e+00
    phi[9,11]  R2737     -2.2316115867695219e-01
    phi[9,11]  R2738     -2.9314631167319392e+00
    phi[9,11]  R2739     -1.2485367116066839e+00
    phi[9,11]  R2740     -3.5790486875349981e-01
    phi[9,11]  R2741     -5.8420949405116369e+00
    phi[9,11]  R2742     -5.2165415441536744e-02
    phi[9,11]  R2743     -5.7698428478834662e-02
    phi[9,11]  R2744     -1.0343230236901757e-01
    phi[9,11]  R2745     -2.6691066934436858e-01
    phi[9,11]  R2746     -2.7966400749075149e-01
    phi[9,11]  R2747     -3.6143829422038776e-01
    phi[9,11]  R2748     -3.9872736292916855e-01
    phi[9,11]  R2749     -4.0018966750906193e-01
    phi[9,11]  R2750     -4.2403456166059961e-01
    phi[9,11]  R2751     -1.8057308608564573e+00
    phi[9,11]  R2752     -3.9714708033916779e-01
    phi[9,11]  R2753     -2.2935371367176183e-01
    phi[9,11]  R2754     -2.3193076877136964e-01
    phi[9,11]  R2755     -2.4686513439413355e-01
    phi[9,11]  R2756     -2.4779381014657986e-01
    phi[9,11]  R2757     -4.9134645650145004e-01
    phi[9,11]  R2758     -8.7362484432081544e-01
    phi[9,11]  R2759     -2.5510132957561327e-01
    phi[9,11]  R2760     -2.6979419183999753e-01
    phi[9,11]  R2761     -2.7995749871300823e-01
    phi[9,11]  R2762     -2.2849611100233069e-01
    phi[9,11]  R2763     -5.6458560000342306e-01
    phi[9,11]  R2764     -1.1022805074465580e+00
    phi[9,11]  R2765     -3.0989312784010004e-01
    phi[9,11]  R2766     -3.2420038314636090e-01
    phi[9,11]  R2767     -3.2714606353472675e-01
    phi[9,11]  R2768     -3.3510365295366173e-01
    phi[9,11]  R2769     -3.4515835010793072e-01
    phi[9,11]  R2770     -3.4606257167896826e-01
    phi[9,11]  R2771     -3.4627231361669253e-01
    phi[9,11]  R2772     -2.4246833263173517e-01
    phi[9,11]  R2773     -2.7241960224073836e-01
    phi[9,11]  R2774     -2.8435774449746454e-01
    phi[9,11]  R2775     -3.5514056619314149e-01
    phi[9,11]  R2776     -3.1495825346088063e-01
    phi[9,11]  R2777     -3.1586249331809446e-01
    phi[9,11]  R2778     -3.2487646169799289e-01
    phi[9,11]  R2779     -3.2523763291582375e-01
    phi[9,11]  R2780     -0.37009822977772
    phi[9,11]  R2781     -3.8645134568654704e-01
    phi[9,11]  R2782     -2.2416626736777023e-01
    phi[9,11]  R2783     -2.3756510712631540e-01
    phi[9,11]  R2784     -6.1160926429578133e-01
    phi[9,11]  R2785     -2.8417204625133197e-01
    phi[9,11]  R2786     -1.0522930890175179e+00
    phi[9,11]  R2787     -2.9492852419846116e-01
    phi[9,11]  R2788     -3.1703893290211660e-01
    phi[9,11]  R2789     -3.2671310773913476e-01
    phi[9,11]  R2790     -3.4417955233679365e-01
    phi[9,11]  R2791     -3.8996792547161241e-01
    phi[9,11]  R2792     -2.2446036123338997e-01
    phi[9,11]  R2793     -2.3813091917703549e-01
    phi[9,11]  R2794     -2.8159670833999195e-01
    phi[9,11]  R2795     -1.0224047794792237e+00
    phi[9,11]  R2796     -3.0475998650961467e-01
    phi[9,11]  R2797     -3.1778669969508266e-01
    phi[9,11]  R2798     -3.2592505210125289e-01
    phi[9,11]  R2799     -3.4033196090586348e-01
    phi[9,11]  R2800     -3.5994701820367192e-01
    phi[9,11]  R2801     -1.2708930513158387e+00
    phi[9,11]  R2802     -1.9063327730706958e-01
    phi[9,11]  R2803     -3.7566510527401453e-01
    phi[9,11]  R2804     -2.3262771496824564e-01
    phi[9,11]  R2805     -2.6522363341923016e-01
    phi[9,11]  R2806     -2.7477848213423339e-01
    phi[9,11]  R2807     -1.7676000062946553e+00
    phi[9,11]  R2808     -9.7453767192158613e-01
    phi[9,11]  R2809     -0.804068934452403
    phi[9,11]  R2810     -6.6280195257583507e-01
    phi[9,11]  R2811     -1.7937785539750131e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R92       -1
    z[0,1,0]  R93       1
    z[0,1,0]  R106      -8.6556434631347656e-01
    z[0,1,0]  R107      -4.1236069053411484e-02
    z[0,1,0]  R108      1.0510524362325668e-01
    z[0,1,0]  R109      8.8532008230686188e-02
    z[0,1,0]  R110      -7.9787355661392212e-01
    z[0,1,0]  R111      -7.5574278831481934e-01
    z[0,1,0]  R112      -7.5591254234313965e-01
    z[0,1,0]  R113      1.4318588376045227e-01
    z[0,1,0]  R114      1.8367926776409149e-01
    z[0,1,0]  R115      -1.3492894172668457e-01
    z[0,1,0]  R116      1.0312058776617050e-01
    z[0,1,0]  R117      1.4673198759555817e-01
    z[0,1,0]  R118      -3.2835164666175842e-01
    z[0,1,0]  R119      -6.2497153878211975e-02
    z[0,1,0]  R120      0.575777530670166
    z[0,1,0]  R121      1.7961759865283966e-01
    z[0,1,0]  R122      2.9430544376373291e-01
    z[0,1,0]  R123      1.4689160883426666e-01
    z[0,1,0]  R124      2.3537835478782654e-01
    z[0,1,0]  R125      1.6539818048477173e-01
    z[0,1,0]  R126      -1.1978947371244431e-01
    z[0,1,0]  R127      -2.1345306932926178e-01
    z[0,1,0]  R128      5.0198280811309814e-01
    z[0,1,0]  R129      6.5568894147872925e-02
    z[0,1,0]  R130      -1.6261696815490723e-01
    z[0,1,0]  R131      3.1055265665054321e-01
    z[0,1,0]  R132      -2.0735581219196320e-01
    z[0,1,0]  R133      6.8226224184036255e-01
    z[0,1,0]  R134      6.6444432735443115e-01
    z[0,1,0]  R135      0.780838668346405
    z[0,1,0]  R136      -3.7238067388534546e-01
    z[0,1,0]  R137      1.6116203367710114e-01
    z[0,1,0]  R138      -4.0826341509819031e-01
    z[0,1,0]  R139      -3.4886884689331055e-01
    z[0,1,0]  R140      -9.6671558916568756e-02
    z[0,1,0]  R141      3.0254465341567993e-01
    z[0,1,0]  R142      -2.9394960403442383e-01
    z[0,1,0]  R143      4.2535030841827393e-01
    z[0,1,0]  R144      2.7053418755531311e-01
    z[0,1,0]  R145      -1.4853386580944061e-01
    z[0,1,0]  R146      -6.4769279956817627e-01
    z[0,1,0]  R147      -6.1156213283538818e-01
    z[0,1,0]  R148      -3.8871932029724121e-01
    z[0,1,0]  R149      -1.3857544958591461e-01
    z[0,1,0]  R150      -1.3292810320854187e-01
    z[0,1,0]  R151      2.0611186325550079e-01
    z[0,1,0]  R152      -1.3159725069999695e-01
    z[0,1,0]  R153      5.4140859842300415e-01
    z[0,1,0]  R154      8.4151971340179443e-01
    z[0,1,0]  R155      -4.2333474755287170e-01
    z[0,1,0]  R156      4.0024355053901672e-01
    z[0,1,0]  R157      -1.3610808551311493e-01
    z[0,1,0]  R158      0.00855422206223011
    z[0,1,0]  R159      7.7543449401855469e-01
    z[0,1,0]  R160      -4.4643476605415344e-02
    z[0,1,0]  R161      -4.1574668884277344e-01
    z[0,1,0]  R162      8.0693048238754272e-01
    z[0,1,0]  R163      -2.6147079467773438e-01
    z[0,1,0]  R164      5.6743097305297852e-01
    z[0,1,0]  R165      -1.3485701382160187e-01
    z[0,1,0]  R166      -1.2722581624984741e-01
    z[0,1,0]  R167      2.0702557638287544e-02
    z[0,1,0]  R168      1.7400571703910828e-01
    z[0,1,0]  R169      1.6851654276251793e-02
    z[0,1,0]  R170      -4.9683997035026550e-01
    z[0,1,0]  R171      1.2294229120016098e-01
    z[0,1,0]  R172      3.8583450019359589e-02
    z[0,1,0]  R173      7.2080634534358978e-02
    z[0,1,0]  R174      7.7041331678628922e-04
    z[0,1,0]  R175      7.2286769747734070e-02
    z[0,1,0]  R176      -7.5946646928787231e-01
    z[0,1,0]  R177      -8.2690078020095825e-01
    z[0,1,0]  R178      -7.8685903549194336e-01
    z[0,1,0]  R179      -7.4463844299316406e-01
    z[0,1,0]  R180      -2.6125228404998779e-01
    z[0,1,0]  R181      -0.654283344745636
    z[0,1,0]  R182      -4.2415246367454529e-01
    z[0,1,0]  R183      -2.5743165612220764e-01
    z[0,1,0]  R184      -2.8072366118431091e-01
    z[0,1,0]  R185      -3.8944289088249207e-01
    z[0,1,0]  R186      5.0468966364860535e-02
    z[0,1,0]  R187      0.562359631061554
    z[0,1,0]  R188      -7.1691438555717468e-02
    z[0,1,0]  R189      4.9378836154937744e-01
    z[0,1,0]  R190      9.2348873615264893e-01
    z[0,1,0]  R191      6.8466496467590332e-01
    z[0,1,0]  R192      8.0839455127716064e-01
    z[0,1,0]  R193      7.8445595502853394e-01
    z[0,1,0]  R194      7.0763266086578369e-01
    z[0,1,0]  R195      2.7363106608390808e-01
    z[0,1,0]  R196      4.3372777104377747e-01
    z[0,1,0]  R197      4.9973770976066589e-01
    z[0,1,0]  R198      4.5048114657402039e-01
    z[0,1,0]  R199      3.3973124623298645e-01
    z[0,1,0]  R200      2.6258271932601929e-01
    z[0,1,0]  R201      -3.6433931440114975e-02
    z[0,1,0]  R202      0.683049201965332
    z[0,1,0]  R203      -8.6409854888916016e-01
    z[0,1,0]  R204      -8.6637049913406372e-01
    z[0,1,0]  R205      -8.2070887088775635e-01
    z[0,1,0]  R206      8.3364957571029663e-01
    z[0,1,0]  R207      5.1239848136901855e-01
    z[0,1,0]  R208      7.4250853061676025e-01
    z[0,1,0]  R209      4.6475287526845932e-02
    z[0,1,0]  R210      -8.0535590648651123e-01
    z[0,1,0]  R211      2.1084900200366974e-01
    z[0,1,0]  R212      1.6341623663902283e-01
    z[0,1,0]  R213      4.5319050550460815e-02
    z[0,1,0]  R214      -1.7409981787204742e-01
    z[0,1,0]  R215      2.1518768742680550e-02
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R94       -1
    z[0,1,1]  R95       1
    z[0,1,1]  R106      3.4495043754577637e-01
    z[0,1,1]  R107      -4.9976086616516113e-01
    z[0,1,1]  R108      -4.7554585337638855e-01
    z[0,1,1]  R109      -6.7512750625610352e-01
    z[0,1,1]  R110      -1.7502070963382721e-01
    z[0,1,1]  R111      -2.4693377315998077e-01
    z[0,1,1]  R112      -1.1827751249074936e-01
    z[0,1,1]  R113      -5.5128842592239380e-01
    z[0,1,1]  R114      1.1151216179132462e-01
    z[0,1,1]  R115      -2.7934971451759338e-01
    z[0,1,1]  R116      -8.5020369291305542e-01
    z[0,1,1]  R117      -5.9273320436477661e-01
    z[0,1,1]  R118      -5.1442635059356689e-01
    z[0,1,1]  R119      -3.3093014359474182e-01
    z[0,1,1]  R120      -3.5620692372322083e-01
    z[0,1,1]  R121      2.3276938498020172e-01
    z[0,1,1]  R122      4.7947758436203003e-01
    z[0,1,1]  R123      4.0138053894042969e-01
    z[0,1,1]  R124      9.1129429638385773e-02
    z[0,1,1]  R125      6.3216572999954224e-01
    z[0,1,1]  R126      -8.8463604450225830e-02
    z[0,1,1]  R127      -5.3806287050247192e-01
    z[0,1,1]  R128      -6.6432762145996094e-01
    z[0,1,1]  R129      -7.2125440835952759e-01
    z[0,1,1]  R130      -2.6211544871330261e-01
    z[0,1,1]  R131      -0.501920759677887
    z[0,1,1]  R132      2.0636498928070068e-02
    z[0,1,1]  R133      3.3570915460586548e-01
    z[0,1,1]  R134      1.0734263807535172e-01
    z[0,1,1]  R135      6.6693723201751709e-02
    z[0,1,1]  R136      2.9823088645935059e-01
    z[0,1,1]  R137      -7.5452917814254761e-01
    z[0,1,1]  R138      -3.2540559768676758e-01
    z[0,1,1]  R139      -5.0323939323425293e-01
    z[0,1,1]  R140      -7.5589370727539062e-01
    z[0,1,1]  R141      -0.687433660030365
    z[0,1,1]  R142      -3.8846787810325623e-01
    z[0,1,1]  R143      -3.9844623208045959e-01
    z[0,1,1]  R144      -3.2046353816986084e-01
    z[0,1,1]  R145      -2.0761089026927948e-01
    z[0,1,1]  R146      -4.3487891554832458e-01
    z[0,1,1]  R147      -7.4214714765548706e-01
    z[0,1,1]  R148      -5.5393588542938232e-01
    z[0,1,1]  R149      3.2467627525329590e-01
    z[0,1,1]  R150      -6.2469649314880371e-01
    z[0,1,1]  R151      -1.2720146775245667e-01
    z[0,1,1]  R152      -2.3071397840976715e-01
    z[0,1,1]  R153      3.4664157032966614e-01
    z[0,1,1]  R154      7.2865389287471771e-02
    z[0,1,1]  R155      -3.5707134008407593e-01
    z[0,1,1]  R156      -3.9317104220390320e-01
    z[0,1,1]  R157      -2.7948483824729919e-01
    z[0,1,1]  R158      1.3539044186472893e-02
    z[0,1,1]  R159      0.156547412276268
    z[0,1,1]  R160      -1.3347235508263111e-02
    z[0,1,1]  R161      -3.4653863310813904e-01
    z[0,1,1]  R162      -2.4881218373775482e-01
    z[0,1,1]  R163      7.2614312171936035e-01
    z[0,1,1]  R164      -5.4835790395736694e-01
    z[0,1,1]  R165      7.5021088123321533e-01
    z[0,1,1]  R166      -4.0606725215911865e-01
    z[0,1,1]  R167      -8.5662293434143066e-01
    z[0,1,1]  R168      -6.6742545366287231e-01
    z[0,1,1]  R169      -3.8001769781112671e-01
    z[0,1,1]  R170      -1.2752562761306763e-01
    z[0,1,1]  R171      -6.2731981277465820e-01
    z[0,1,1]  R172      1.8085278570652008e-01
    z[0,1,1]  R173      -6.1604923009872437e-01
    z[0,1,1]  R174      -5.5951058864593506e-01
    z[0,1,1]  R175      -4.0628954768180847e-01
    z[0,1,1]  R176      -3.2694950699806213e-01
    z[0,1,1]  R177      -1.8602201342582703e-01
    z[0,1,1]  R178      -4.8230059444904327e-02
    z[0,1,1]  R179      -2.7818185091018677e-01
    z[0,1,1]  R180      4.6050807833671570e-01
    z[0,1,1]  R181      2.7634924277663231e-02
    z[0,1,1]  R182      1.5746396780014038e-01
    z[0,1,1]  R183      0.412733256816864
    z[0,1,1]  R184      3.6810505390167236e-01
    z[0,1,1]  R185      4.1212329268455505e-01
    z[0,1,1]  R186      5.1099520921707153e-01
    z[0,1,1]  R187      1.5516389906406403e-01
    z[0,1,1]  R188      3.5979580879211426e-01
    z[0,1,1]  R189      6.4920186996459961e-02
    z[0,1,1]  R190      3.4705594182014465e-01
    z[0,1,1]  R191      -2.2733153402805328e-01
    z[0,1,1]  R192      -1.5694728493690491e-01
    z[0,1,1]  R193      5.3272019140422344e-03
    z[0,1,1]  R194      1.8249194324016571e-01
    z[0,1,1]  R195      -2.9867708683013916e-01
    z[0,1,1]  R196      -1.2157098948955536e-01
    z[0,1,1]  R197      -6.7000240087509155e-01
    z[0,1,1]  R198      -5.6848609447479248e-01
    z[0,1,1]  R199      -0.54603111743927
    z[0,1,1]  R200      -3.9111602306365967e-01
    z[0,1,1]  R201      -3.1595990061759949e-01
    z[0,1,1]  R202      4.4881820678710938e-01
    z[0,1,1]  R203      -9.2467240989208221e-02
    z[0,1,1]  R204      -5.3211987018585205e-02
    z[0,1,1]  R205      -5.8870144188404083e-02
    z[0,1,1]  R206      -1.9726459681987762e-01
    z[0,1,1]  R207      2.0762990415096283e-01
    z[0,1,1]  R208      -1.7342941462993622e-01
    z[0,1,1]  R209      8.1048947572708130e-01
    z[0,1,1]  R210      -4.0847569704055786e-01
    z[0,1,1]  R211      6.9204968214035034e-01
    z[0,1,1]  R212      6.3707798719406128e-01
    z[0,1,1]  R213      7.3784333467483521e-01
    z[0,1,1]  R214      4.9446558952331543e-01
    z[0,1,1]  R215      4.8585602641105652e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R96       -1
    z[0,1,2]  R97       1
    z[0,1,2]  R106      2.7621725574135780e-02
    z[0,1,2]  R107      7.3466020822525024e-01
    z[0,1,2]  R108      6.8202590942382812e-01
    z[0,1,2]  R109      4.5618841052055359e-01
    z[0,1,2]  R110      -0.0845438539981842
    z[0,1,2]  R111      -0.0838879719376564
    z[0,1,2]  R112      -8.3456777036190033e-02
    z[0,1,2]  R113      6.6848099231719971e-01
    z[0,1,2]  R114      4.7175869345664978e-01
    z[0,1,2]  R115      6.5274572372436523e-01
    z[0,1,2]  R116      -3.9539617300033569e-01
    z[0,1,2]  R117      -5.1124978065490723e-01
    z[0,1,2]  R118      -2.8793439269065857e-01
    z[0,1,2]  R119      -2.7269563078880310e-01
    z[0,1,2]  R120      -3.3951789140701294e-01
    z[0,1,2]  R121      -6.9787585735321045e-01
    z[0,1,2]  R122      -6.5587985515594482e-01
    z[0,1,2]  R123      -8.2782596349716187e-01
    z[0,1,2]  R124      -5.7603049278259277e-01
    z[0,1,2]  R125      -6.3554090261459351e-01
    z[0,1,2]  R126      -6.6490036249160767e-01
    z[0,1,2]  R127      -3.2557302713394165e-01
    z[0,1,2]  R128      -1.1641083657741547e-01
    z[0,1,2]  R129      2.1482974290847778e-01
    z[0,1,2]  R130      8.1824511289596558e-02
    z[0,1,2]  R131      1.4156261086463928e-01
    z[0,1,2]  R132      -5.0084173679351807e-02
    z[0,1,2]  R133      -6.5664090216159821e-02
    z[0,1,2]  R134      3.1432278454303741e-02
    z[0,1,2]  R135      -2.5956818461418152e-01
    z[0,1,2]  R136      -7.7168178558349609e-01
    z[0,1,2]  R137      -2.0968298614025116e-01
    z[0,1,2]  R138      -1.9802008569240570e-01
    z[0,1,2]  R139      -4.7668609023094177e-01
    z[0,1,2]  R140      1.9084939360618591e-01
    z[0,1,2]  R141      2.7320548892021179e-01
    z[0,1,2]  R142      -2.9504847526550293e-01
    z[0,1,2]  R143      -1.9627763330936432e-01
    z[0,1,2]  R144      -1.3070015609264374e-01
    z[0,1,2]  R145      -2.6683833450078964e-02
    z[0,1,2]  R146      -4.4522222876548767e-01
    z[0,1,2]  R147      -1.1112175136804581e-01
    z[0,1,2]  R148      -2.4236644804477692e-01
    z[0,1,2]  R149      -6.1946034431457520e-01
    z[0,1,2]  R150      2.7883926033973694e-01
    z[0,1,2]  R151      -6.6978245973587036e-01
    z[0,1,2]  R152      -6.2185734510421753e-02
    z[0,1,2]  R153      -7.4284210801124573e-02
    z[0,1,2]  R154      -1.0192904621362686e-01
    z[0,1,2]  R155      5.8484065532684326e-01
    z[0,1,2]  R156      -3.4029707312583923e-01
    z[0,1,2]  R157      -7.9746223986148834e-02
    z[0,1,2]  R158      -6.2350231409072876e-01
    z[0,1,2]  R159      -3.8162497803568840e-03
    z[0,1,2]  R160      -1.1624182574450970e-02
    z[0,1,2]  R161      0.644105076789856
    z[0,1,2]  R162      1.5265475213527679e-01
    z[0,1,2]  R163      -3.2871926669031382e-03
    z[0,1,2]  R164      -0.286289244890213
    z[0,1,2]  R165      1.9715599715709686e-01
    z[0,1,2]  R166      8.3968991041183472e-01
    z[0,1,2]  R167      3.6968412995338440e-01
    z[0,1,2]  R168      0.459505558013916
    z[0,1,2]  R169      7.1922683715820312e-01
    z[0,1,2]  R170      7.7588593959808350e-01
    z[0,1,2]  R171      4.2355218529701233e-01
    z[0,1,2]  R172      8.0315440893173218e-01
    z[0,1,2]  R173      3.7288326025009155e-01
    z[0,1,2]  R174      4.3731957674026489e-01
    z[0,1,2]  R175      6.7767697572708130e-01
    z[0,1,2]  R176      -5.0836914777755737e-01
    z[0,1,2]  R177      -4.2291939258575439e-01
    z[0,1,2]  R178      -4.8327657580375671e-01
    z[0,1,2]  R179      -5.7509851455688477e-01
    z[0,1,2]  R180      -6.9054877758026123e-01
    z[0,1,2]  R181      -4.6498143672943115e-01
    z[0,1,2]  R182      -2.6943698525428772e-01
    z[0,1,2]  R183      -0.669501543045044
    z[0,1,2]  R184      -5.2097642421722412e-01
    z[0,1,2]  R185      -5.3540790081024170e-01
    z[0,1,2]  R186      -3.6459747701883316e-02
    z[0,1,2]  R187      -1.4083737134933472e-01
    z[0,1,2]  R188      -2.3714843392372131e-01
    z[0,1,2]  R189      5.4901713132858276e-01
    z[0,1,2]  R190      6.1884272843599319e-02
    z[0,1,2]  R191      6.7300267517566681e-02
    z[0,1,2]  R192      -1.6915030777454376e-01
    z[0,1,2]  R193      1.6775536537170410e-01
    z[0,1,2]  R194      1.9526395201683044e-01
    z[0,1,2]  R195      8.6094796657562256e-02
    z[0,1,2]  R196      4.6372807025909424e-01
    z[0,1,2]  R197      -1.9680503010749817e-01
    z[0,1,2]  R198      8.0855436623096466e-02
    z[0,1,2]  R199      4.7880895435810089e-02
    z[0,1,2]  R200      2.1502092480659485e-01
    z[0,1,2]  R201      3.0873468518257141e-01
    z[0,1,2]  R202      5.2402138710021973e-01
    z[0,1,2]  R203      -4.4109621644020081e-01
    z[0,1,2]  R204      -0.150368332862854
    z[0,1,2]  R205      -3.0549362301826477e-01
    z[0,1,2]  R206      0.374489426612854
    z[0,1,2]  R207      5.0314950942993164e-01
    z[0,1,2]  R208      -2.0568031072616577e-01
    z[0,1,2]  R209      0.0821487233042717
    z[0,1,2]  R210      -8.9237973093986511e-02
    z[0,1,2]  R211      -3.8678056001663208e-01
    z[0,1,2]  R212      -5.2411282062530518e-01
    z[0,1,2]  R213      -3.7047600746154785e-01
    z[0,1,2]  R214      -0.631361186504364
    z[0,1,2]  R215      -4.3349912762641907e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R98       -1
    z[0,1,3]  R99       1
    z[0,1,3]  R106      -3.5168325901031494e-01
    z[0,1,3]  R107      -3.1265783309936523e-01
    z[0,1,3]  R108      -2.9012054204940796e-01
    z[0,1,3]  R109      -4.4434544444084167e-01
    z[0,1,3]  R110      -6.9123253226280212e-02
    z[0,1,3]  R111      -1.6010272502899170e-01
    z[0,1,3]  R112      -6.1893612146377563e-03
    z[0,1,3]  R113      4.2321330308914185e-01
    z[0,1,3]  R114      -3.2259920239448547e-01
    z[0,1,3]  R115      2.7095075696706772e-02
    z[0,1,3]  R116      1.9906303286552429e-01
    z[0,1,3]  R117      9.8733194172382355e-02
    z[0,1,3]  R118      2.7285942435264587e-01
    z[0,1,3]  R119      1.3957878947257996e-01
    z[0,1,3]  R120      1.2894868850708008e-01
    z[0,1,3]  R121      -3.2551360130310059e-01
    z[0,1,3]  R122      -3.4541919827461243e-01
    z[0,1,3]  R123      -3.1703576445579529e-01
    z[0,1,3]  R124      -6.7687761783599854e-01
    z[0,1,3]  R125      6.3811734318733215e-02
    z[0,1,3]  R126      -4.9727335572242737e-01
    z[0,1,3]  R127      -5.6930756568908691e-01
    z[0,1,3]  R128      -1.3958480954170227e-01
    z[0,1,3]  R129      -5.4697811603546143e-01
    z[0,1,3]  R130      0.805844783782959
    z[0,1,3]  R131      -4.9574910663068295e-03
    z[0,1,3]  R132      -6.2206178903579712e-01
    z[0,1,3]  R133      5.2626281976699829e-01
    z[0,1,3]  R134      5.6888228654861450e-01
    z[0,1,3]  R135      4.4461691379547119e-01
    z[0,1,3]  R136      -1.0837078839540482e-01
    z[0,1,3]  R137      4.5038022100925446e-02
    z[0,1,3]  R138      -4.1925823688507080e-01
    z[0,1,3]  R139      -1.5297304093837738e-01
    z[0,1,3]  R140      -4.0619823336601257e-01
    z[0,1,3]  R141      1.5630979090929031e-02
    z[0,1,3]  R142      -6.4796352386474609e-01
    z[0,1,3]  R143      2.3813745379447937e-01
    z[0,1,3]  R144      7.2073060274124146e-01
    z[0,1,3]  R145      6.2681853771209717e-01
    z[0,1,3]  R146      6.4228519797325134e-02
    z[0,1,3]  R147      -1.3735200464725494e-01
    z[0,1,3]  R148      4.4287565350532532e-01
    z[0,1,3]  R149      -4.1826283931732178e-01
    z[0,1,3]  R150      3.7058338522911072e-01
    z[0,1,3]  R151      3.4639132022857666e-01
    z[0,1,3]  R152      8.5716533660888672e-01
    z[0,1,3]  R153      6.5562093257904053e-01
    z[0,1,3]  R154      3.0329120159149170e-01
    z[0,1,3]  R155      -2.0099332928657532e-01
    z[0,1,3]  R156      1.7543128132820129e-01
    z[0,1,3]  R157      6.7784392833709717e-01
    z[0,1,3]  R158      0.71389240026474
    z[0,1,3]  R159      3.9879637956619263e-01
    z[0,1,3]  R160      -7.6556110382080078e-01
    z[0,1,3]  R161      -2.1251289546489716e-01
    z[0,1,3]  R162      5.0486225634813309e-02
    z[0,1,3]  R163      4.8082742094993591e-01
    z[0,1,3]  R164      -0.0451047383248806
    z[0,1,3]  R165      4.3817591667175293e-01
    z[0,1,3]  R166      -1.9909712672233582e-01
    z[0,1,3]  R167      -1.6519768536090851e-01
    z[0,1,3]  R168      2.0185695588588715e-01
    z[0,1,3]  R169      -2.7235820889472961e-01
    z[0,1,3]  R170      2.0207263529300690e-02
    z[0,1,3]  R171      -3.0750006437301636e-01
    z[0,1,3]  R172      2.9661837220191956e-01
    z[0,1,3]  R173      5.0223521888256073e-02
    z[0,1,3]  R174      0.077674001455307
    z[0,1,3]  R175      -4.4104721397161484e-02
    z[0,1,3]  R176      -6.4003534615039825e-02
    z[0,1,3]  R177      4.1698209941387177e-02
    z[0,1,3]  R178      7.3577851057052612e-02
    z[0,1,3]  R179      3.5545095801353455e-02
    z[0,1,3]  R180      3.1346008181571960e-01
    z[0,1,3]  R181      -1.4843994379043579e-01
    z[0,1,3]  R182      2.3004728555679321e-01
    z[0,1,3]  R183      4.4075345993041992e-01
    z[0,1,3]  R184      3.6550438404083252e-01
    z[0,1,3]  R185      3.0500376224517822e-01
    z[0,1,3]  R186      6.3105963170528412e-02
    z[0,1,3]  R187      6.1312373727560043e-03
    z[0,1,3]  R188      7.2842933237552643e-02
    z[0,1,3]  R189      -1.8690697848796844e-01
    z[0,1,3]  R190      -4.0619168430566788e-03
    z[0,1,3]  R191      -3.0977734923362732e-01
    z[0,1,3]  R192      -2.3131315410137177e-01
    z[0,1,3]  R193      -4.2744103074073792e-01
    z[0,1,3]  R194      -1.7304801940917969e-01
    z[0,1,3]  R195      -3.1542572379112244e-01
    z[0,1,3]  R196      -4.2001712322235107e-01
    z[0,1,3]  R197      -3.9449888467788696e-01
    z[0,1,3]  R198      -0.572258710861206
    z[0,1,3]  R199      -0.360209584236145
    z[0,1,3]  R200      -4.7984135150909424e-01
    z[0,1,3]  R201      -2.7646675705909729e-02
    z[0,1,3]  R202      5.0068624317646027e-02
    z[0,1,3]  R203      -3.8766807410866022e-03
    z[0,1,3]  R204      3.5247886180877686e-01
    z[0,1,3]  R205      1.8729597330093384e-01
    z[0,1,3]  R206      -3.0640000104904175e-01
    z[0,1,3]  R207      -2.9593247175216675e-01
    z[0,1,3]  R208      -1.3290596008300781e-01
    z[0,1,3]  R209      1.5202455222606659e-01
    z[0,1,3]  R210      -2.3024519905447960e-02
    z[0,1,3]  R211      5.6639021635055542e-01
    z[0,1,3]  R212      4.8683652281761169e-01
    z[0,1,3]  R213      4.5692732930183411e-01
    z[0,1,3]  R214      5.1947754621505737e-01
    z[0,1,3]  R215      6.1422526836395264e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R100      -1
    z[0,1,4]  R101      1
    z[0,1,4]  R106      -6.6957190632820129e-02
    z[0,1,4]  R107      2.1465896070003510e-01
    z[0,1,4]  R108      2.7437087893486023e-01
    z[0,1,4]  R109      6.2506482005119324e-02
    z[0,1,4]  R110      3.9351871609687805e-01
    z[0,1,4]  R111      0.422784686088562
    z[0,1,4]  R112      2.4455915391445160e-01
    z[0,1,4]  R113      -1.3691918551921844e-01
    z[0,1,4]  R114      -5.9453827142715454e-01
    z[0,1,4]  R115      -6.2357103824615479e-01
    z[0,1,4]  R116      2.1007342636585236e-01
    z[0,1,4]  R117      5.6166488677263260e-02
    z[0,1,4]  R118      -6.3911330699920654e-01
    z[0,1,4]  R119      -7.8037220239639282e-01
    z[0,1,4]  R120      -5.7170045375823975e-01
    z[0,1,4]  R121      -1.2757124379277229e-02
    z[0,1,4]  R122      -3.5243952274322510e-01
    z[0,1,4]  R123      -1.1243198066949844e-01
    z[0,1,4]  R124      -3.2792448997497559e-01
    z[0,1,4]  R125      -5.1740769296884537e-02
    z[0,1,4]  R126      -4.2554304003715515e-01
    z[0,1,4]  R127      -3.4818568825721741e-01
    z[0,1,4]  R128      -3.9911502599716187e-01
    z[0,1,4]  R129      -2.4722869694232941e-01
    z[0,1,4]  R130      -2.5145837664604187e-01
    z[0,1,4]  R131      -3.9427399635314941e-01
    z[0,1,4]  R132      3.0580586194992065e-01
    z[0,1,4]  R133      6.5072283148765564e-02
    z[0,1,4]  R134      -1.2051870115101337e-02
    z[0,1,4]  R135      2.4295248091220856e-01
    z[0,1,4]  R136      1.1104691773653030e-01
    z[0,1,4]  R137      -2.9548043012619019e-01
    z[0,1,4]  R138      3.9793637394905090e-01
    z[0,1,4]  R139      -0.35687056183815
    z[0,1,4]  R140      -1.3751165568828583e-01
    z[0,1,4]  R141      -4.9464112520217896e-01
    z[0,1,4]  R142      4.0702825784683228e-01
    z[0,1,4]  R143      -4.1676875948905945e-01
    z[0,1,4]  R144      -3.2262614369392395e-01
    z[0,1,4]  R145      -1.8061390519142151e-01
    z[0,1,4]  R146      -2.9686695337295532e-01
    z[0,1,4]  R147      -7.1076206862926483e-02
    z[0,1,4]  R148      -2.4156036972999573e-01
    z[0,1,4]  R149      -2.0897619426250458e-02
    z[0,1,4]  R150      1.0163921862840652e-01
    z[0,1,4]  R151      -5.3750729560852051e-01
    z[0,1,4]  R152      3.0570149421691895e-01
    z[0,1,4]  R153      7.2318062186241150e-02
    z[0,1,4]  R154      -3.7874445319175720e-01
    z[0,1,4]  R155      5.9320259839296341e-02
    z[0,1,4]  R156      -4.6008464694023132e-01
    z[0,1,4]  R157      5.8294606208801270e-01
    z[0,1,4]  R158      -0.0536101870238781
    z[0,1,4]  R159      -4.6203276515007019e-01
    z[0,1,4]  R160      -3.6614328622817993e-01
    z[0,1,4]  R161      2.5582334399223328e-01
    z[0,1,4]  R162      -1.3138620555400848e-01
    z[0,1,4]  R163      2.2937799990177155e-01
    z[0,1,4]  R164      5.2642589807510376e-01
    z[0,1,4]  R165      -3.5246974229812622e-01
    z[0,1,4]  R166      -5.2067171782255173e-02
    z[0,1,4]  R167      -1.1456907959654927e-03
    z[0,1,4]  R168      -3.6360761523246765e-01
    z[0,1,4]  R169      3.8033846765756607e-02
    z[0,1,4]  R170      2.1731720864772797e-01
    z[0,1,4]  R171      2.2090306878089905e-01
    z[0,1,4]  R172      4.2820364236831665e-01
    z[0,1,4]  R173      2.2266179323196411e-01
    z[0,1,4]  R174      0.602392315864563
    z[0,1,4]  R175      4.5574018359184265e-01
    z[0,1,4]  R176      -4.7931659966707230e-02
    z[0,1,4]  R177      -5.3476560860872269e-02
    z[0,1,4]  R178      -2.7044081687927246e-01
    z[0,1,4]  R179      4.7364749014377594e-02
    z[0,1,4]  R180      -1.3396562635898590e-01
    z[0,1,4]  R181      -2.5589841604232788e-01
    z[0,1,4]  R182      9.7017228603363037e-02
    z[0,1,4]  R183      7.3426604270935059e-02
    z[0,1,4]  R184      1.8762914836406708e-01
    z[0,1,4]  R185      -1.4057025313377380e-01
    z[0,1,4]  R186      -3.0107897520065308e-01
    z[0,1,4]  R187      -2.0867292582988739e-01
    z[0,1,4]  R188      1.1813201010227203e-01
    z[0,1,4]  R189      2.3920483887195587e-02
    z[0,1,4]  R190      -0.0217477697879076
    z[0,1,4]  R191      -5.2040744572877884e-02
    z[0,1,4]  R192      1.6099634766578674e-01
    z[0,1,4]  R193      -3.1772014498710632e-01
    z[0,1,4]  R194      -4.4278463721275330e-01
    z[0,1,4]  R195      3.2765313982963562e-01
    z[0,1,4]  R196      -4.5414149761199951e-01
    z[0,1,4]  R197      3.1276699900627136e-01
    z[0,1,4]  R198      1.6534550487995148e-01
    z[0,1,4]  R199      4.7791969776153564e-01
    z[0,1,4]  R200      1.5253904461860657e-01
    z[0,1,4]  R201      2.6589216664433479e-02
    z[0,1,4]  R202      -2.1097426116466522e-01
    z[0,1,4]  R203      -1.6661521792411804e-01
    z[0,1,4]  R204      2.5000625848770142e-01
    z[0,1,4]  R205      2.3330490291118622e-01
    z[0,1,4]  R206      1.0494589060544968e-01
    z[0,1,4]  R207      -1.7684867978096008e-01
    z[0,1,4]  R208      -6.4213410019874573e-02
    z[0,1,4]  R209      -1.1015962064266205e-01
    z[0,1,4]  R210      2.4497982114553452e-02
    z[0,1,4]  R211      -4.0380254387855530e-02
    z[0,1,4]  R212      -1.8860971927642822e-01
    z[0,1,4]  R213      -1.6324110329151154e-01
    z[0,1,4]  R214      1.0699438303709030e-01
    z[0,1,4]  R215      3.3944758772850037e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R102      -1
    z[0,1,5]  R103      1
    z[0,1,5]  R106      1.1650804430246353e-02
    z[0,1,5]  R107      -1.6273267567157745e-01
    z[0,1,5]  R108      -2.7441319823265076e-01
    z[0,1,5]  R109      -1.3563459739089012e-02
    z[0,1,5]  R110      -2.6757022738456726e-01
    z[0,1,5]  R111      3.4697356820106506e-01
    z[0,1,5]  R112      2.0508494973182678e-01
    z[0,1,5]  R113      3.3434204757213593e-02
    z[0,1,5]  R114      -5.0606679916381836e-01
    z[0,1,5]  R115      -1.7889726161956787e-01
    z[0,1,5]  R116      -1.6252931952476501e-01
    z[0,1,5]  R117      5.9391415119171143e-01
    z[0,1,5]  R118      -1.9189855456352234e-01
    z[0,1,5]  R119      4.2806863784790039e-01
    z[0,1,5]  R120      2.7523204684257507e-01
    z[0,1,5]  R121      -0.511264443397522
    z[0,1,5]  R122      -0.0551532544195652
    z[0,1,5]  R123      7.5839549303054810e-02
    z[0,1,5]  R124      -6.1982583254575729e-02
    z[0,1,5]  R125      -3.1618049740791321e-01
    z[0,1,5]  R126      -3.2758924365043640e-01
    z[0,1,5]  R127      3.7728220224380493e-02
    z[0,1,5]  R128      2.1341986954212189e-01
    z[0,1,5]  R129      -2.5816529989242554e-01
    z[0,1,5]  R130      3.8002288341522217e-01
    z[0,1,5]  R131      -5.1978421211242676e-01
    z[0,1,5]  R132      -4.6375676989555359e-01
    z[0,1,5]  R133      2.0037825405597687e-01
    z[0,1,5]  R134      4.2616373300552368e-01
    z[0,1,5]  R135      1.8339498341083527e-01
    z[0,1,5]  R136      3.3599036931991577e-01
    z[0,1,5]  R137      -1.5354098379611969e-01
    z[0,1,5]  R138      -2.2313885390758514e-01
    z[0,1,5]  R139      4.2628234624862671e-01
    z[0,1,5]  R140      -4.3180641531944275e-01
    z[0,1,5]  R141      -1.9204846024513245e-01
    z[0,1,5]  R142      -3.0016237497329712e-01
    z[0,1,5]  R143      4.5417442917823792e-01
    z[0,1,5]  R144      1.8342629075050354e-01
    z[0,1,5]  R145      5.6681233644485474e-01
    z[0,1,5]  R146      2.4742105603218079e-01
    z[0,1,5]  R147      1.1944817006587982e-01
    z[0,1,5]  R148      2.5705319643020630e-01
    z[0,1,5]  R149      -5.0330072641372681e-01
    z[0,1,5]  R150      1.1723132431507111e-01
    z[0,1,5]  R151      5.6994143873453140e-02
    z[0,1,5]  R152      2.7316540479660034e-01
    z[0,1,5]  R153      -3.4446594119071960e-01
    z[0,1,5]  R154      -2.0171286165714264e-01
    z[0,1,5]  R155      -5.5400699377059937e-01
    z[0,1,5]  R156      4.0052446722984314e-01
    z[0,1,5]  R157      3.0932599306106567e-01
    z[0,1,5]  R158      -4.4391206465661526e-03
    z[0,1,5]  R159      1.8181413412094116e-02
    z[0,1,5]  R160      -2.0574663579463959e-01
    z[0,1,5]  R161      -1.5640632808208466e-01
    z[0,1,5]  R162      -1.7433337867259979e-02
    z[0,1,5]  R163      -3.1434756517410278e-01
    z[0,1,5]  R164      1.5541951172053814e-02
    z[0,1,5]  R165      2.3965077102184296e-01
    z[0,1,5]  R166      -2.6185715198516846e-01
    z[0,1,5]  R167      -2.4369697272777557e-01
    z[0,1,5]  R168      -3.0192995071411133e-01
    z[0,1,5]  R169      1.8738912418484688e-02
    z[0,1,5]  R170      -9.8352529108524323e-02
    z[0,1,5]  R171      3.9602303504943848e-01
    z[0,1,5]  R172      -2.1167115867137909e-01
    z[0,1,5]  R173      -2.9340144991874695e-01
    z[0,1,5]  R174      -3.5542976856231689e-01
    z[0,1,5]  R175      3.7708008289337158e-01
    z[0,1,5]  R176      5.5474311113357544e-02
    z[0,1,5]  R177      1.2986877560615540e-01
    z[0,1,5]  R178      -0.253933846950531
    z[0,1,5]  R179      -1.2982282042503357e-01
    z[0,1,5]  R180      3.5530611872673035e-01
    z[0,1,5]  R181      3.9429646730422974e-01
    z[0,1,5]  R182      -4.8040366172790527e-01
    z[0,1,5]  R183      3.2295471429824829e-01
    z[0,1,5]  R184      5.8690625429153442e-01
    z[0,1,5]  R185      4.4697627425193787e-01
    z[0,1,5]  R186      -7.2650724649429321e-01
    z[0,1,5]  R187      -7.7126610279083252e-01
    z[0,1,5]  R188      -8.5369080305099487e-01
    z[0,1,5]  R189      -1.0248441249132156e-01
    z[0,1,5]  R190      -1.0205791890621185e-01
    z[0,1,5]  R191      -4.4212377071380615e-01
    z[0,1,5]  R192      -7.9361595213413239e-02
    z[0,1,5]  R193      2.2805219888687134e-01
    z[0,1,5]  R194      -4.4459503889083862e-01
    z[0,1,5]  R195      2.0874033868312836e-01
    z[0,1,5]  R196      -4.3574118614196777e-01
    z[0,1,5]  R197      -8.1849955022335052e-02
    z[0,1,5]  R198      1.4777642488479614e-01
    z[0,1,5]  R199      4.7310128808021545e-01
    z[0,1,5]  R200      6.6230261325836182e-01
    z[0,1,5]  R201      -8.7718927860260010e-01
    z[0,1,5]  R202      1.3225401751697063e-02
    z[0,1,5]  R203      5.8165524154901505e-02
    z[0,1,5]  R204      -8.5439709946513176e-03
    z[0,1,5]  R205      3.7420755624771118e-01
    z[0,1,5]  R206      6.8470202386379242e-02
    z[0,1,5]  R207      2.9246711730957031e-01
    z[0,1,5]  R208      -5.9198802709579468e-01
    z[0,1,5]  R209      -0.0754462406039238
    z[0,1,5]  R210      -0.163039892911911
    z[0,1,5]  R211      -5.8868058025836945e-02
    z[0,1,5]  R212      -1.4028537273406982e-01
    z[0,1,5]  R213      2.8312322497367859e-01
    z[0,1,5]  R214      1.2301035970449448e-01
    z[0,1,5]  R215      1.2846863828599453e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R104      -1
    z[0,1,6]  R105      1
    z[0,1,6]  R106      -5.2389286458492279e-02
    z[0,1,6]  R107      -1.9620814919471741e-01
    z[0,1,6]  R108      2.5079402327537537e-01
    z[0,1,6]  R109      3.5598197579383850e-01
    z[0,1,6]  R110      3.0722799897193909e-01
    z[0,1,6]  R111      1.8991814553737640e-01
    z[0,1,6]  R112      5.5293250083923340e-01
    z[0,1,6]  R113      1.7244604229927063e-01
    z[0,1,6]  R114      0.132745161652565
    z[0,1,6]  R115      2.3685809969902039e-01
    z[0,1,6]  R116      -3.0023558065295219e-03
    z[0,1,6]  R117      -1.1126353405416012e-02
    z[0,1,6]  R118      -1.5780167281627655e-01
    z[0,1,6]  R119      2.2599419578909874e-02
    z[0,1,6]  R120      8.4277898073196411e-02
    z[0,1,6]  R121      2.4292401969432831e-01
    z[0,1,6]  R122      -8.2080394029617310e-02
    z[0,1,6]  R123      1.1452677100896835e-01
    z[0,1,6]  R124      -1.8692702054977417e-01
    z[0,1,6]  R125      2.4975709617137909e-01
    z[0,1,6]  R126      -7.0599899627268314e-03
    z[0,1,6]  R127      0.334903746843338
    z[0,1,6]  R128      2.6230832934379578e-01
    z[0,1,6]  R129      -4.8832472413778305e-02
    z[0,1,6]  R130      -2.0278413593769073e-01
    z[0,1,6]  R131      4.5380666851997375e-01
    z[0,1,6]  R132      -5.0844949483871460e-01
    z[0,1,6]  R133      -3.1010892987251282e-01
    z[0,1,6]  R134      -2.0153287053108215e-01
    z[0,1,6]  R135      -1.6770051419734955e-01
    z[0,1,6]  R136      1.9983239471912384e-01
    z[0,1,6]  R137      4.9782890081405640e-01
    z[0,1,6]  R138      -5.5163258314132690e-01
    z[0,1,6]  R139      -2.5561100244522095e-01
    z[0,1,6]  R140      1.1177039146423340e-01
    z[0,1,6]  R141      -2.8189316391944885e-01
    z[0,1,6]  R142      2.5481504853814840e-03
    z[0,1,6]  R143      -4.3024727702140808e-01
    z[0,1,6]  R144      -3.8709992170333862e-01
    z[0,1,6]  R145      -4.3280977010726929e-01
    z[0,1,6]  R146      -1.9919589161872864e-01
    z[0,1,6]  R147      -1.5708579123020172e-01
    z[0,1,6]  R148      4.0341550111770630e-01
    z[0,1,6]  R149      0.250916063785553
    z[0,1,6]  R150      0.594076931476593
    z[0,1,6]  R151      -2.8386563062667847e-01
    z[0,1,6]  R152      1.5093356370925903e-01
    z[0,1,6]  R153      1.6574905812740326e-01
    z[0,1,6]  R154      4.9676052294671535e-03
    z[0,1,6]  R155      -2.0203253254294395e-02
    z[0,1,6]  R156      -4.0810006856918335e-01
    z[0,1,6]  R157      -4.4969558715820312e-02
    z[0,1,6]  R158      -3.1377106904983521e-01
    z[0,1,6]  R159      -3.6554921418428421e-02
    z[0,1,6]  R160      -4.8499208688735962e-01
    z[0,1,6]  R161      -3.9638879895210266e-01
    z[0,1,6]  R162      -4.9349474906921387e-01
    z[0,1,6]  R163      1.4735881984233856e-01
    z[0,1,6]  R164      -1.2634842097759247e-01
    z[0,1,6]  R165      -8.0381870269775391e-02
    z[0,1,6]  R166      -5.4073341190814972e-02
    z[0,1,6]  R167      2.0596711337566376e-01
    z[0,1,6]  R168      -2.2136306762695312e-01
    z[0,1,6]  R169      5.1189702749252319e-01
    z[0,1,6]  R170      -2.7853175997734070e-01
    z[0,1,6]  R171      3.3431991934776306e-01
    z[0,1,6]  R172      6.7832171916961670e-02
    z[0,1,6]  R173      -5.8142983913421631e-01
    z[0,1,6]  R174      2.1421007812023163e-02
    z[0,1,6]  R175      -1.3646802306175232e-01
    z[0,1,6]  R176      2.2000966966152191e-01
    z[0,1,6]  R177      2.8514152765274048e-01
    z[0,1,6]  R178      -4.4002164155244827e-02
    z[0,1,6]  R179      -1.3049638271331787e-01
    z[0,1,6]  R180      -1.9374759867787361e-02
    z[0,1,6]  R181      -3.3459511399269104e-01
    z[0,1,6]  R182      6.5542489290237427e-01
    z[0,1,6]  R183      1.0579691082239151e-01
    z[0,1,6]  R184      3.1926054507493973e-02
    z[0,1,6]  R185      2.8151726722717285e-01
    z[0,1,6]  R186      -3.3550536632537842e-01
    z[0,1,6]  R187      -3.7513405084609985e-02
    z[0,1,6]  R188      -2.4722217023372650e-01
    z[0,1,6]  R189      -6.3602608442306519e-01
    z[0,1,6]  R190      1.0947944223880768e-01
    z[0,1,6]  R191      -4.2530137300491333e-01
    z[0,1,6]  R192      -4.5555481314659119e-01
    z[0,1,6]  R193      1.4421868324279785e-01
    z[0,1,6]  R194      -6.4467117190361023e-02
    z[0,1,6]  R195      -7.6031780242919922e-01
    z[0,1,6]  R196      -9.7609780728816986e-02
    z[0,1,6]  R197      4.9747385084629059e-02
    z[0,1,6]  R198      -3.0115723609924316e-01
    z[0,1,6]  R199      4.6444587409496307e-02
    z[0,1,6]  R200      0.199208065867424
    z[0,1,6]  R201      -0.180533766746521
    z[0,1,6]  R202      1.0107289999723434e-01
    z[0,1,6]  R203      -1.3805307447910309e-01
    z[0,1,6]  R204      1.9272369146347046e-01
    z[0,1,6]  R205      1.0131252929568291e-02
    z[0,1,6]  R206      1.2763187289237976e-01
    z[0,1,6]  R207      -0.486610472202301
    z[0,1,6]  R208      -6.3732050359249115e-02
    z[0,1,6]  R209      5.4153460264205933e-01
    z[0,1,6]  R210      3.8584148883819580e-01
    z[0,1,6]  R211      -3.3422295004129410e-02
    z[0,1,6]  R212      2.1657595410943031e-02
    z[0,1,6]  R213      2.6306835934519768e-02
    z[0,1,6]  R214      -1.7360873520374298e-01
    z[0,1,6]  R215      -2.8791844844818115e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R216      -1
    z[1,0,0]  R217      1
    z[1,0,0]  R230      -1.2722581624984741e-01
    z[1,0,0]  R231      2.0702557638287544e-02
    z[1,0,0]  R232      1.7400571703910828e-01
    z[1,0,0]  R233      1.6851654276251793e-02
    z[1,0,0]  R234      -4.9683997035026550e-01
    z[1,0,0]  R235      1.2294229120016098e-01
    z[1,0,0]  R236      3.8583450019359589e-02
    z[1,0,0]  R237      7.2080634534358978e-02
    z[1,0,0]  R238      7.7041331678628922e-04
    z[1,0,0]  R239      7.2286769747734070e-02
    z[1,0,0]  R240      -7.5946646928787231e-01
    z[1,0,0]  R241      -8.2690078020095825e-01
    z[1,0,0]  R242      -7.8685903549194336e-01
    z[1,0,0]  R243      -7.4463844299316406e-01
    z[1,0,0]  R244      -2.6125228404998779e-01
    z[1,0,0]  R245      -0.654283344745636
    z[1,0,0]  R246      -4.2415246367454529e-01
    z[1,0,0]  R247      -2.5743165612220764e-01
    z[1,0,0]  R248      -2.8072366118431091e-01
    z[1,0,0]  R249      -3.8944289088249207e-01
    z[1,0,0]  R250      5.0468966364860535e-02
    z[1,0,0]  R251      0.562359631061554
    z[1,0,0]  R252      -7.1691438555717468e-02
    z[1,0,0]  R253      4.9378836154937744e-01
    z[1,0,0]  R254      9.2348873615264893e-01
    z[1,0,0]  R255      6.8466496467590332e-01
    z[1,0,0]  R256      8.0839455127716064e-01
    z[1,0,0]  R257      7.8445595502853394e-01
    z[1,0,0]  R258      7.0763266086578369e-01
    z[1,0,0]  R259      2.7363106608390808e-01
    z[1,0,0]  R260      4.3372777104377747e-01
    z[1,0,0]  R261      4.9973770976066589e-01
    z[1,0,0]  R262      4.5048114657402039e-01
    z[1,0,0]  R263      3.3973124623298645e-01
    z[1,0,0]  R264      2.6258271932601929e-01
    z[1,0,0]  R265      -3.6433931440114975e-02
    z[1,0,0]  R266      0.683049201965332
    z[1,0,0]  R267      -8.6409854888916016e-01
    z[1,0,0]  R268      -8.6637049913406372e-01
    z[1,0,0]  R269      -8.2070887088775635e-01
    z[1,0,0]  R270      8.3364957571029663e-01
    z[1,0,0]  R271      5.1239848136901855e-01
    z[1,0,0]  R272      7.4250853061676025e-01
    z[1,0,0]  R273      4.6475287526845932e-02
    z[1,0,0]  R274      -8.0535590648651123e-01
    z[1,0,0]  R275      2.1084900200366974e-01
    z[1,0,0]  R276      1.6341623663902283e-01
    z[1,0,0]  R277      4.5319050550460815e-02
    z[1,0,0]  R278      -1.7409981787204742e-01
    z[1,0,0]  R279      2.1518768742680550e-02
    z[1,0,0]  R280      -8.6556434631347656e-01
    z[1,0,0]  R281      -4.1236069053411484e-02
    z[1,0,0]  R282      1.0510524362325668e-01
    z[1,0,0]  R283      8.8532008230686188e-02
    z[1,0,0]  R284      -7.9787355661392212e-01
    z[1,0,0]  R285      -7.5574278831481934e-01
    z[1,0,0]  R286      -7.5591254234313965e-01
    z[1,0,0]  R287      1.4318588376045227e-01
    z[1,0,0]  R288      1.8367926776409149e-01
    z[1,0,0]  R289      -1.3492894172668457e-01
    z[1,0,0]  R290      1.0312058776617050e-01
    z[1,0,0]  R291      1.4673198759555817e-01
    z[1,0,0]  R292      -3.2835164666175842e-01
    z[1,0,0]  R293      -6.2497153878211975e-02
    z[1,0,0]  R294      0.575777530670166
    z[1,0,0]  R295      1.7961759865283966e-01
    z[1,0,0]  R296      2.9430544376373291e-01
    z[1,0,0]  R297      1.4689160883426666e-01
    z[1,0,0]  R298      2.3537835478782654e-01
    z[1,0,0]  R299      1.6539818048477173e-01
    z[1,0,0]  R300      -1.1978947371244431e-01
    z[1,0,0]  R301      -2.1345306932926178e-01
    z[1,0,0]  R302      5.0198280811309814e-01
    z[1,0,0]  R303      6.5568894147872925e-02
    z[1,0,0]  R304      -1.6261696815490723e-01
    z[1,0,0]  R305      3.1055265665054321e-01
    z[1,0,0]  R306      -2.0735581219196320e-01
    z[1,0,0]  R307      6.8226224184036255e-01
    z[1,0,0]  R308      6.6444432735443115e-01
    z[1,0,0]  R309      0.780838668346405
    z[1,0,0]  R310      -3.7238067388534546e-01
    z[1,0,0]  R311      1.6116203367710114e-01
    z[1,0,0]  R312      -4.0826341509819031e-01
    z[1,0,0]  R313      -3.4886884689331055e-01
    z[1,0,0]  R314      -9.6671558916568756e-02
    z[1,0,0]  R315      3.0254465341567993e-01
    z[1,0,0]  R316      -2.9394960403442383e-01
    z[1,0,0]  R317      4.2535030841827393e-01
    z[1,0,0]  R318      2.7053418755531311e-01
    z[1,0,0]  R319      -1.4853386580944061e-01
    z[1,0,0]  R320      -6.4769279956817627e-01
    z[1,0,0]  R321      -6.1156213283538818e-01
    z[1,0,0]  R322      -3.8871932029724121e-01
    z[1,0,0]  R323      -1.3857544958591461e-01
    z[1,0,0]  R324      -1.3292810320854187e-01
    z[1,0,0]  R325      2.0611186325550079e-01
    z[1,0,0]  R326      -1.3159725069999695e-01
    z[1,0,0]  R327      5.4140859842300415e-01
    z[1,0,0]  R328      8.4151971340179443e-01
    z[1,0,0]  R329      -4.2333474755287170e-01
    z[1,0,0]  R330      4.0024355053901672e-01
    z[1,0,0]  R331      -1.3610808551311493e-01
    z[1,0,0]  R332      0.00855422206223011
    z[1,0,0]  R333      7.7543449401855469e-01
    z[1,0,0]  R334      -4.4643476605415344e-02
    z[1,0,0]  R335      -4.1574668884277344e-01
    z[1,0,0]  R336      8.0693048238754272e-01
    z[1,0,0]  R337      -2.6147079467773438e-01
    z[1,0,0]  R338      5.6743097305297852e-01
    z[1,0,0]  R339      -1.3485701382160187e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R218      -1
    z[1,0,1]  R219      1
    z[1,0,1]  R230      -4.0606725215911865e-01
    z[1,0,1]  R231      -8.5662293434143066e-01
    z[1,0,1]  R232      -6.6742545366287231e-01
    z[1,0,1]  R233      -3.8001769781112671e-01
    z[1,0,1]  R234      -1.2752562761306763e-01
    z[1,0,1]  R235      -6.2731981277465820e-01
    z[1,0,1]  R236      1.8085278570652008e-01
    z[1,0,1]  R237      -6.1604923009872437e-01
    z[1,0,1]  R238      -5.5951058864593506e-01
    z[1,0,1]  R239      -4.0628954768180847e-01
    z[1,0,1]  R240      -3.2694950699806213e-01
    z[1,0,1]  R241      -1.8602201342582703e-01
    z[1,0,1]  R242      -4.8230059444904327e-02
    z[1,0,1]  R243      -2.7818185091018677e-01
    z[1,0,1]  R244      4.6050807833671570e-01
    z[1,0,1]  R245      2.7634924277663231e-02
    z[1,0,1]  R246      1.5746396780014038e-01
    z[1,0,1]  R247      0.412733256816864
    z[1,0,1]  R248      3.6810505390167236e-01
    z[1,0,1]  R249      4.1212329268455505e-01
    z[1,0,1]  R250      5.1099520921707153e-01
    z[1,0,1]  R251      1.5516389906406403e-01
    z[1,0,1]  R252      3.5979580879211426e-01
    z[1,0,1]  R253      6.4920186996459961e-02
    z[1,0,1]  R254      3.4705594182014465e-01
    z[1,0,1]  R255      -2.2733153402805328e-01
    z[1,0,1]  R256      -1.5694728493690491e-01
    z[1,0,1]  R257      5.3272019140422344e-03
    z[1,0,1]  R258      1.8249194324016571e-01
    z[1,0,1]  R259      -2.9867708683013916e-01
    z[1,0,1]  R260      -1.2157098948955536e-01
    z[1,0,1]  R261      -6.7000240087509155e-01
    z[1,0,1]  R262      -5.6848609447479248e-01
    z[1,0,1]  R263      -0.54603111743927
    z[1,0,1]  R264      -3.9111602306365967e-01
    z[1,0,1]  R265      -3.1595990061759949e-01
    z[1,0,1]  R266      4.4881820678710938e-01
    z[1,0,1]  R267      -9.2467240989208221e-02
    z[1,0,1]  R268      -5.3211987018585205e-02
    z[1,0,1]  R269      -5.8870144188404083e-02
    z[1,0,1]  R270      -1.9726459681987762e-01
    z[1,0,1]  R271      2.0762990415096283e-01
    z[1,0,1]  R272      -1.7342941462993622e-01
    z[1,0,1]  R273      8.1048947572708130e-01
    z[1,0,1]  R274      -4.0847569704055786e-01
    z[1,0,1]  R275      6.9204968214035034e-01
    z[1,0,1]  R276      6.3707798719406128e-01
    z[1,0,1]  R277      7.3784333467483521e-01
    z[1,0,1]  R278      4.9446558952331543e-01
    z[1,0,1]  R279      4.8585602641105652e-01
    z[1,0,1]  R280      3.4495043754577637e-01
    z[1,0,1]  R281      -4.9976086616516113e-01
    z[1,0,1]  R282      -4.7554585337638855e-01
    z[1,0,1]  R283      -6.7512750625610352e-01
    z[1,0,1]  R284      -1.7502070963382721e-01
    z[1,0,1]  R285      -2.4693377315998077e-01
    z[1,0,1]  R286      -1.1827751249074936e-01
    z[1,0,1]  R287      -5.5128842592239380e-01
    z[1,0,1]  R288      1.1151216179132462e-01
    z[1,0,1]  R289      -2.7934971451759338e-01
    z[1,0,1]  R290      -8.5020369291305542e-01
    z[1,0,1]  R291      -5.9273320436477661e-01
    z[1,0,1]  R292      -5.1442635059356689e-01
    z[1,0,1]  R293      -3.3093014359474182e-01
    z[1,0,1]  R294      -3.5620692372322083e-01
    z[1,0,1]  R295      2.3276938498020172e-01
    z[1,0,1]  R296      4.7947758436203003e-01
    z[1,0,1]  R297      4.0138053894042969e-01
    z[1,0,1]  R298      9.1129429638385773e-02
    z[1,0,1]  R299      6.3216572999954224e-01
    z[1,0,1]  R300      -8.8463604450225830e-02
    z[1,0,1]  R301      -5.3806287050247192e-01
    z[1,0,1]  R302      -6.6432762145996094e-01
    z[1,0,1]  R303      -7.2125440835952759e-01
    z[1,0,1]  R304      -2.6211544871330261e-01
    z[1,0,1]  R305      -0.501920759677887
    z[1,0,1]  R306      2.0636498928070068e-02
    z[1,0,1]  R307      3.3570915460586548e-01
    z[1,0,1]  R308      1.0734263807535172e-01
    z[1,0,1]  R309      6.6693723201751709e-02
    z[1,0,1]  R310      2.9823088645935059e-01
    z[1,0,1]  R311      -7.5452917814254761e-01
    z[1,0,1]  R312      -3.2540559768676758e-01
    z[1,0,1]  R313      -5.0323939323425293e-01
    z[1,0,1]  R314      -7.5589370727539062e-01
    z[1,0,1]  R315      -0.687433660030365
    z[1,0,1]  R316      -3.8846787810325623e-01
    z[1,0,1]  R317      -3.9844623208045959e-01
    z[1,0,1]  R318      -3.2046353816986084e-01
    z[1,0,1]  R319      -2.0761089026927948e-01
    z[1,0,1]  R320      -4.3487891554832458e-01
    z[1,0,1]  R321      -7.4214714765548706e-01
    z[1,0,1]  R322      -5.5393588542938232e-01
    z[1,0,1]  R323      3.2467627525329590e-01
    z[1,0,1]  R324      -6.2469649314880371e-01
    z[1,0,1]  R325      -1.2720146775245667e-01
    z[1,0,1]  R326      -2.3071397840976715e-01
    z[1,0,1]  R327      3.4664157032966614e-01
    z[1,0,1]  R328      7.2865389287471771e-02
    z[1,0,1]  R329      -3.5707134008407593e-01
    z[1,0,1]  R330      -3.9317104220390320e-01
    z[1,0,1]  R331      -2.7948483824729919e-01
    z[1,0,1]  R332      1.3539044186472893e-02
    z[1,0,1]  R333      0.156547412276268
    z[1,0,1]  R334      -1.3347235508263111e-02
    z[1,0,1]  R335      -3.4653863310813904e-01
    z[1,0,1]  R336      -2.4881218373775482e-01
    z[1,0,1]  R337      7.2614312171936035e-01
    z[1,0,1]  R338      -5.4835790395736694e-01
    z[1,0,1]  R339      7.5021088123321533e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R220      -1
    z[1,0,2]  R221      1
    z[1,0,2]  R230      8.3968991041183472e-01
    z[1,0,2]  R231      3.6968412995338440e-01
    z[1,0,2]  R232      0.459505558013916
    z[1,0,2]  R233      7.1922683715820312e-01
    z[1,0,2]  R234      7.7588593959808350e-01
    z[1,0,2]  R235      4.2355218529701233e-01
    z[1,0,2]  R236      8.0315440893173218e-01
    z[1,0,2]  R237      3.7288326025009155e-01
    z[1,0,2]  R238      4.3731957674026489e-01
    z[1,0,2]  R239      6.7767697572708130e-01
    z[1,0,2]  R240      -5.0836914777755737e-01
    z[1,0,2]  R241      -4.2291939258575439e-01
    z[1,0,2]  R242      -4.8327657580375671e-01
    z[1,0,2]  R243      -5.7509851455688477e-01
    z[1,0,2]  R244      -6.9054877758026123e-01
    z[1,0,2]  R245      -4.6498143672943115e-01
    z[1,0,2]  R246      -2.6943698525428772e-01
    z[1,0,2]  R247      -0.669501543045044
    z[1,0,2]  R248      -5.2097642421722412e-01
    z[1,0,2]  R249      -5.3540790081024170e-01
    z[1,0,2]  R250      -3.6459747701883316e-02
    z[1,0,2]  R251      -1.4083737134933472e-01
    z[1,0,2]  R252      -2.3714843392372131e-01
    z[1,0,2]  R253      5.4901713132858276e-01
    z[1,0,2]  R254      6.1884272843599319e-02
    z[1,0,2]  R255      6.7300267517566681e-02
    z[1,0,2]  R256      -1.6915030777454376e-01
    z[1,0,2]  R257      1.6775536537170410e-01
    z[1,0,2]  R258      1.9526395201683044e-01
    z[1,0,2]  R259      8.6094796657562256e-02
    z[1,0,2]  R260      4.6372807025909424e-01
    z[1,0,2]  R261      -1.9680503010749817e-01
    z[1,0,2]  R262      8.0855436623096466e-02
    z[1,0,2]  R263      4.7880895435810089e-02
    z[1,0,2]  R264      2.1502092480659485e-01
    z[1,0,2]  R265      3.0873468518257141e-01
    z[1,0,2]  R266      5.2402138710021973e-01
    z[1,0,2]  R267      -4.4109621644020081e-01
    z[1,0,2]  R268      -0.150368332862854
    z[1,0,2]  R269      -3.0549362301826477e-01
    z[1,0,2]  R270      0.374489426612854
    z[1,0,2]  R271      5.0314950942993164e-01
    z[1,0,2]  R272      -2.0568031072616577e-01
    z[1,0,2]  R273      0.0821487233042717
    z[1,0,2]  R274      -8.9237973093986511e-02
    z[1,0,2]  R275      -3.8678056001663208e-01
    z[1,0,2]  R276      -5.2411282062530518e-01
    z[1,0,2]  R277      -3.7047600746154785e-01
    z[1,0,2]  R278      -0.631361186504364
    z[1,0,2]  R279      -4.3349912762641907e-01
    z[1,0,2]  R280      2.7621725574135780e-02
    z[1,0,2]  R281      7.3466020822525024e-01
    z[1,0,2]  R282      6.8202590942382812e-01
    z[1,0,2]  R283      4.5618841052055359e-01
    z[1,0,2]  R284      -0.0845438539981842
    z[1,0,2]  R285      -0.0838879719376564
    z[1,0,2]  R286      -8.3456777036190033e-02
    z[1,0,2]  R287      6.6848099231719971e-01
    z[1,0,2]  R288      4.7175869345664978e-01
    z[1,0,2]  R289      6.5274572372436523e-01
    z[1,0,2]  R290      -3.9539617300033569e-01
    z[1,0,2]  R291      -5.1124978065490723e-01
    z[1,0,2]  R292      -2.8793439269065857e-01
    z[1,0,2]  R293      -2.7269563078880310e-01
    z[1,0,2]  R294      -3.3951789140701294e-01
    z[1,0,2]  R295      -6.9787585735321045e-01
    z[1,0,2]  R296      -6.5587985515594482e-01
    z[1,0,2]  R297      -8.2782596349716187e-01
    z[1,0,2]  R298      -5.7603049278259277e-01
    z[1,0,2]  R299      -6.3554090261459351e-01
    z[1,0,2]  R300      -6.6490036249160767e-01
    z[1,0,2]  R301      -3.2557302713394165e-01
    z[1,0,2]  R302      -1.1641083657741547e-01
    z[1,0,2]  R303      2.1482974290847778e-01
    z[1,0,2]  R304      8.1824511289596558e-02
    z[1,0,2]  R305      1.4156261086463928e-01
    z[1,0,2]  R306      -5.0084173679351807e-02
    z[1,0,2]  R307      -6.5664090216159821e-02
    z[1,0,2]  R308      3.1432278454303741e-02
    z[1,0,2]  R309      -2.5956818461418152e-01
    z[1,0,2]  R310      -7.7168178558349609e-01
    z[1,0,2]  R311      -2.0968298614025116e-01
    z[1,0,2]  R312      -1.9802008569240570e-01
    z[1,0,2]  R313      -4.7668609023094177e-01
    z[1,0,2]  R314      1.9084939360618591e-01
    z[1,0,2]  R315      2.7320548892021179e-01
    z[1,0,2]  R316      -2.9504847526550293e-01
    z[1,0,2]  R317      -1.9627763330936432e-01
    z[1,0,2]  R318      -1.3070015609264374e-01
    z[1,0,2]  R319      -2.6683833450078964e-02
    z[1,0,2]  R320      -4.4522222876548767e-01
    z[1,0,2]  R321      -1.1112175136804581e-01
    z[1,0,2]  R322      -2.4236644804477692e-01
    z[1,0,2]  R323      -6.1946034431457520e-01
    z[1,0,2]  R324      2.7883926033973694e-01
    z[1,0,2]  R325      -6.6978245973587036e-01
    z[1,0,2]  R326      -6.2185734510421753e-02
    z[1,0,2]  R327      -7.4284210801124573e-02
    z[1,0,2]  R328      -1.0192904621362686e-01
    z[1,0,2]  R329      5.8484065532684326e-01
    z[1,0,2]  R330      -3.4029707312583923e-01
    z[1,0,2]  R331      -7.9746223986148834e-02
    z[1,0,2]  R332      -6.2350231409072876e-01
    z[1,0,2]  R333      -3.8162497803568840e-03
    z[1,0,2]  R334      -1.1624182574450970e-02
    z[1,0,2]  R335      0.644105076789856
    z[1,0,2]  R336      1.5265475213527679e-01
    z[1,0,2]  R337      -3.2871926669031382e-03
    z[1,0,2]  R338      -0.286289244890213
    z[1,0,2]  R339      1.9715599715709686e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R222      -1
    z[1,0,3]  R223      1
    z[1,0,3]  R230      -1.9909712672233582e-01
    z[1,0,3]  R231      -1.6519768536090851e-01
    z[1,0,3]  R232      2.0185695588588715e-01
    z[1,0,3]  R233      -2.7235820889472961e-01
    z[1,0,3]  R234      2.0207263529300690e-02
    z[1,0,3]  R235      -3.0750006437301636e-01
    z[1,0,3]  R236      2.9661837220191956e-01
    z[1,0,3]  R237      5.0223521888256073e-02
    z[1,0,3]  R238      0.077674001455307
    z[1,0,3]  R239      -4.4104721397161484e-02
    z[1,0,3]  R240      -6.4003534615039825e-02
    z[1,0,3]  R241      4.1698209941387177e-02
    z[1,0,3]  R242      7.3577851057052612e-02
    z[1,0,3]  R243      3.5545095801353455e-02
    z[1,0,3]  R244      3.1346008181571960e-01
    z[1,0,3]  R245      -1.4843994379043579e-01
    z[1,0,3]  R246      2.3004728555679321e-01
    z[1,0,3]  R247      4.4075345993041992e-01
    z[1,0,3]  R248      3.6550438404083252e-01
    z[1,0,3]  R249      3.0500376224517822e-01
    z[1,0,3]  R250      6.3105963170528412e-02
    z[1,0,3]  R251      6.1312373727560043e-03
    z[1,0,3]  R252      7.2842933237552643e-02
    z[1,0,3]  R253      -1.8690697848796844e-01
    z[1,0,3]  R254      -4.0619168430566788e-03
    z[1,0,3]  R255      -3.0977734923362732e-01
    z[1,0,3]  R256      -2.3131315410137177e-01
    z[1,0,3]  R257      -4.2744103074073792e-01
    z[1,0,3]  R258      -1.7304801940917969e-01
    z[1,0,3]  R259      -3.1542572379112244e-01
    z[1,0,3]  R260      -4.2001712322235107e-01
    z[1,0,3]  R261      -3.9449888467788696e-01
    z[1,0,3]  R262      -0.572258710861206
    z[1,0,3]  R263      -0.360209584236145
    z[1,0,3]  R264      -4.7984135150909424e-01
    z[1,0,3]  R265      -2.7646675705909729e-02
    z[1,0,3]  R266      5.0068624317646027e-02
    z[1,0,3]  R267      -3.8766807410866022e-03
    z[1,0,3]  R268      3.5247886180877686e-01
    z[1,0,3]  R269      1.8729597330093384e-01
    z[1,0,3]  R270      -3.0640000104904175e-01
    z[1,0,3]  R271      -2.9593247175216675e-01
    z[1,0,3]  R272      -1.3290596008300781e-01
    z[1,0,3]  R273      1.5202455222606659e-01
    z[1,0,3]  R274      -2.3024519905447960e-02
    z[1,0,3]  R275      5.6639021635055542e-01
    z[1,0,3]  R276      4.8683652281761169e-01
    z[1,0,3]  R277      4.5692732930183411e-01
    z[1,0,3]  R278      5.1947754621505737e-01
    z[1,0,3]  R279      6.1422526836395264e-01
    z[1,0,3]  R280      -3.5168325901031494e-01
    z[1,0,3]  R281      -3.1265783309936523e-01
    z[1,0,3]  R282      -2.9012054204940796e-01
    z[1,0,3]  R283      -4.4434544444084167e-01
    z[1,0,3]  R284      -6.9123253226280212e-02
    z[1,0,3]  R285      -1.6010272502899170e-01
    z[1,0,3]  R286      -6.1893612146377563e-03
    z[1,0,3]  R287      4.2321330308914185e-01
    z[1,0,3]  R288      -3.2259920239448547e-01
    z[1,0,3]  R289      2.7095075696706772e-02
    z[1,0,3]  R290      1.9906303286552429e-01
    z[1,0,3]  R291      9.8733194172382355e-02
    z[1,0,3]  R292      2.7285942435264587e-01
    z[1,0,3]  R293      1.3957878947257996e-01
    z[1,0,3]  R294      1.2894868850708008e-01
    z[1,0,3]  R295      -3.2551360130310059e-01
    z[1,0,3]  R296      -3.4541919827461243e-01
    z[1,0,3]  R297      -3.1703576445579529e-01
    z[1,0,3]  R298      -6.7687761783599854e-01
    z[1,0,3]  R299      6.3811734318733215e-02
    z[1,0,3]  R300      -4.9727335572242737e-01
    z[1,0,3]  R301      -5.6930756568908691e-01
    z[1,0,3]  R302      -1.3958480954170227e-01
    z[1,0,3]  R303      -5.4697811603546143e-01
    z[1,0,3]  R304      0.805844783782959
    z[1,0,3]  R305      -4.9574910663068295e-03
    z[1,0,3]  R306      -6.2206178903579712e-01
    z[1,0,3]  R307      5.2626281976699829e-01
    z[1,0,3]  R308      5.6888228654861450e-01
    z[1,0,3]  R309      4.4461691379547119e-01
    z[1,0,3]  R310      -1.0837078839540482e-01
    z[1,0,3]  R311      4.5038022100925446e-02
    z[1,0,3]  R312      -4.1925823688507080e-01
    z[1,0,3]  R313      -1.5297304093837738e-01
    z[1,0,3]  R314      -4.0619823336601257e-01
    z[1,0,3]  R315      1.5630979090929031e-02
    z[1,0,3]  R316      -6.4796352386474609e-01
    z[1,0,3]  R317      2.3813745379447937e-01
    z[1,0,3]  R318      7.2073060274124146e-01
    z[1,0,3]  R319      6.2681853771209717e-01
    z[1,0,3]  R320      6.4228519797325134e-02
    z[1,0,3]  R321      -1.3735200464725494e-01
    z[1,0,3]  R322      4.4287565350532532e-01
    z[1,0,3]  R323      -4.1826283931732178e-01
    z[1,0,3]  R324      3.7058338522911072e-01
    z[1,0,3]  R325      3.4639132022857666e-01
    z[1,0,3]  R326      8.5716533660888672e-01
    z[1,0,3]  R327      6.5562093257904053e-01
    z[1,0,3]  R328      3.0329120159149170e-01
    z[1,0,3]  R329      -2.0099332928657532e-01
    z[1,0,3]  R330      1.7543128132820129e-01
    z[1,0,3]  R331      6.7784392833709717e-01
    z[1,0,3]  R332      0.71389240026474
    z[1,0,3]  R333      3.9879637956619263e-01
    z[1,0,3]  R334      -7.6556110382080078e-01
    z[1,0,3]  R335      -2.1251289546489716e-01
    z[1,0,3]  R336      5.0486225634813309e-02
    z[1,0,3]  R337      4.8082742094993591e-01
    z[1,0,3]  R338      -0.0451047383248806
    z[1,0,3]  R339      4.3817591667175293e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R224      -1
    z[1,0,4]  R225      1
    z[1,0,4]  R230      -5.2067171782255173e-02
    z[1,0,4]  R231      -1.1456907959654927e-03
    z[1,0,4]  R232      -3.6360761523246765e-01
    z[1,0,4]  R233      3.8033846765756607e-02
    z[1,0,4]  R234      2.1731720864772797e-01
    z[1,0,4]  R235      2.2090306878089905e-01
    z[1,0,4]  R236      4.2820364236831665e-01
    z[1,0,4]  R237      2.2266179323196411e-01
    z[1,0,4]  R238      0.602392315864563
    z[1,0,4]  R239      4.5574018359184265e-01
    z[1,0,4]  R240      -4.7931659966707230e-02
    z[1,0,4]  R241      -5.3476560860872269e-02
    z[1,0,4]  R242      -2.7044081687927246e-01
    z[1,0,4]  R243      4.7364749014377594e-02
    z[1,0,4]  R244      -1.3396562635898590e-01
    z[1,0,4]  R245      -2.5589841604232788e-01
    z[1,0,4]  R246      9.7017228603363037e-02
    z[1,0,4]  R247      7.3426604270935059e-02
    z[1,0,4]  R248      1.8762914836406708e-01
    z[1,0,4]  R249      -1.4057025313377380e-01
    z[1,0,4]  R250      -3.0107897520065308e-01
    z[1,0,4]  R251      -2.0867292582988739e-01
    z[1,0,4]  R252      1.1813201010227203e-01
    z[1,0,4]  R253      2.3920483887195587e-02
    z[1,0,4]  R254      -0.0217477697879076
    z[1,0,4]  R255      -5.2040744572877884e-02
    z[1,0,4]  R256      1.6099634766578674e-01
    z[1,0,4]  R257      -3.1772014498710632e-01
    z[1,0,4]  R258      -4.4278463721275330e-01
    z[1,0,4]  R259      3.2765313982963562e-01
    z[1,0,4]  R260      -4.5414149761199951e-01
    z[1,0,4]  R261      3.1276699900627136e-01
    z[1,0,4]  R262      1.6534550487995148e-01
    z[1,0,4]  R263      4.7791969776153564e-01
    z[1,0,4]  R264      1.5253904461860657e-01
    z[1,0,4]  R265      2.6589216664433479e-02
    z[1,0,4]  R266      -2.1097426116466522e-01
    z[1,0,4]  R267      -1.6661521792411804e-01
    z[1,0,4]  R268      2.5000625848770142e-01
    z[1,0,4]  R269      2.3330490291118622e-01
    z[1,0,4]  R270      1.0494589060544968e-01
    z[1,0,4]  R271      -1.7684867978096008e-01
    z[1,0,4]  R272      -6.4213410019874573e-02
    z[1,0,4]  R273      -1.1015962064266205e-01
    z[1,0,4]  R274      2.4497982114553452e-02
    z[1,0,4]  R275      -4.0380254387855530e-02
    z[1,0,4]  R276      -1.8860971927642822e-01
    z[1,0,4]  R277      -1.6324110329151154e-01
    z[1,0,4]  R278      1.0699438303709030e-01
    z[1,0,4]  R279      3.3944758772850037e-01
    z[1,0,4]  R280      -6.6957190632820129e-02
    z[1,0,4]  R281      2.1465896070003510e-01
    z[1,0,4]  R282      2.7437087893486023e-01
    z[1,0,4]  R283      6.2506482005119324e-02
    z[1,0,4]  R284      3.9351871609687805e-01
    z[1,0,4]  R285      0.422784686088562
    z[1,0,4]  R286      2.4455915391445160e-01
    z[1,0,4]  R287      -1.3691918551921844e-01
    z[1,0,4]  R288      -5.9453827142715454e-01
    z[1,0,4]  R289      -6.2357103824615479e-01
    z[1,0,4]  R290      2.1007342636585236e-01
    z[1,0,4]  R291      5.6166488677263260e-02
    z[1,0,4]  R292      -6.3911330699920654e-01
    z[1,0,4]  R293      -7.8037220239639282e-01
    z[1,0,4]  R294      -5.7170045375823975e-01
    z[1,0,4]  R295      -1.2757124379277229e-02
    z[1,0,4]  R296      -3.5243952274322510e-01
    z[1,0,4]  R297      -1.1243198066949844e-01
    z[1,0,4]  R298      -3.2792448997497559e-01
    z[1,0,4]  R299      -5.1740769296884537e-02
    z[1,0,4]  R300      -4.2554304003715515e-01
    z[1,0,4]  R301      -3.4818568825721741e-01
    z[1,0,4]  R302      -3.9911502599716187e-01
    z[1,0,4]  R303      -2.4722869694232941e-01
    z[1,0,4]  R304      -2.5145837664604187e-01
    z[1,0,4]  R305      -3.9427399635314941e-01
    z[1,0,4]  R306      3.0580586194992065e-01
    z[1,0,4]  R307      6.5072283148765564e-02
    z[1,0,4]  R308      -1.2051870115101337e-02
    z[1,0,4]  R309      2.4295248091220856e-01
    z[1,0,4]  R310      1.1104691773653030e-01
    z[1,0,4]  R311      -2.9548043012619019e-01
    z[1,0,4]  R312      3.9793637394905090e-01
    z[1,0,4]  R313      -0.35687056183815
    z[1,0,4]  R314      -1.3751165568828583e-01
    z[1,0,4]  R315      -4.9464112520217896e-01
    z[1,0,4]  R316      4.0702825784683228e-01
    z[1,0,4]  R317      -4.1676875948905945e-01
    z[1,0,4]  R318      -3.2262614369392395e-01
    z[1,0,4]  R319      -1.8061390519142151e-01
    z[1,0,4]  R320      -2.9686695337295532e-01
    z[1,0,4]  R321      -7.1076206862926483e-02
    z[1,0,4]  R322      -2.4156036972999573e-01
    z[1,0,4]  R323      -2.0897619426250458e-02
    z[1,0,4]  R324      1.0163921862840652e-01
    z[1,0,4]  R325      -5.3750729560852051e-01
    z[1,0,4]  R326      3.0570149421691895e-01
    z[1,0,4]  R327      7.2318062186241150e-02
    z[1,0,4]  R328      -3.7874445319175720e-01
    z[1,0,4]  R329      5.9320259839296341e-02
    z[1,0,4]  R330      -4.6008464694023132e-01
    z[1,0,4]  R331      5.8294606208801270e-01
    z[1,0,4]  R332      -0.0536101870238781
    z[1,0,4]  R333      -4.6203276515007019e-01
    z[1,0,4]  R334      -3.6614328622817993e-01
    z[1,0,4]  R335      2.5582334399223328e-01
    z[1,0,4]  R336      -1.3138620555400848e-01
    z[1,0,4]  R337      2.2937799990177155e-01
    z[1,0,4]  R338      5.2642589807510376e-01
    z[1,0,4]  R339      -3.5246974229812622e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R226      -1
    z[1,0,5]  R227      1
    z[1,0,5]  R230      -2.6185715198516846e-01
    z[1,0,5]  R231      -2.4369697272777557e-01
    z[1,0,5]  R232      -3.0192995071411133e-01
    z[1,0,5]  R233      1.8738912418484688e-02
    z[1,0,5]  R234      -9.8352529108524323e-02
    z[1,0,5]  R235      3.9602303504943848e-01
    z[1,0,5]  R236      -2.1167115867137909e-01
    z[1,0,5]  R237      -2.9340144991874695e-01
    z[1,0,5]  R238      -3.5542976856231689e-01
    z[1,0,5]  R239      3.7708008289337158e-01
    z[1,0,5]  R240      5.5474311113357544e-02
    z[1,0,5]  R241      1.2986877560615540e-01
    z[1,0,5]  R242      -0.253933846950531
    z[1,0,5]  R243      -1.2982282042503357e-01
    z[1,0,5]  R244      3.5530611872673035e-01
    z[1,0,5]  R245      3.9429646730422974e-01
    z[1,0,5]  R246      -4.8040366172790527e-01
    z[1,0,5]  R247      3.2295471429824829e-01
    z[1,0,5]  R248      5.8690625429153442e-01
    z[1,0,5]  R249      4.4697627425193787e-01
    z[1,0,5]  R250      -7.2650724649429321e-01
    z[1,0,5]  R251      -7.7126610279083252e-01
    z[1,0,5]  R252      -8.5369080305099487e-01
    z[1,0,5]  R253      -1.0248441249132156e-01
    z[1,0,5]  R254      -1.0205791890621185e-01
    z[1,0,5]  R255      -4.4212377071380615e-01
    z[1,0,5]  R256      -7.9361595213413239e-02
    z[1,0,5]  R257      2.2805219888687134e-01
    z[1,0,5]  R258      -4.4459503889083862e-01
    z[1,0,5]  R259      2.0874033868312836e-01
    z[1,0,5]  R260      -4.3574118614196777e-01
    z[1,0,5]  R261      -8.1849955022335052e-02
    z[1,0,5]  R262      1.4777642488479614e-01
    z[1,0,5]  R263      4.7310128808021545e-01
    z[1,0,5]  R264      6.6230261325836182e-01
    z[1,0,5]  R265      -8.7718927860260010e-01
    z[1,0,5]  R266      1.3225401751697063e-02
    z[1,0,5]  R267      5.8165524154901505e-02
    z[1,0,5]  R268      -8.5439709946513176e-03
    z[1,0,5]  R269      3.7420755624771118e-01
    z[1,0,5]  R270      6.8470202386379242e-02
    z[1,0,5]  R271      2.9246711730957031e-01
    z[1,0,5]  R272      -5.9198802709579468e-01
    z[1,0,5]  R273      -0.0754462406039238
    z[1,0,5]  R274      -0.163039892911911
    z[1,0,5]  R275      -5.8868058025836945e-02
    z[1,0,5]  R276      -1.4028537273406982e-01
    z[1,0,5]  R277      2.8312322497367859e-01
    z[1,0,5]  R278      1.2301035970449448e-01
    z[1,0,5]  R279      1.2846863828599453e-02
    z[1,0,5]  R280      1.1650804430246353e-02
    z[1,0,5]  R281      -1.6273267567157745e-01
    z[1,0,5]  R282      -2.7441319823265076e-01
    z[1,0,5]  R283      -1.3563459739089012e-02
    z[1,0,5]  R284      -2.6757022738456726e-01
    z[1,0,5]  R285      3.4697356820106506e-01
    z[1,0,5]  R286      2.0508494973182678e-01
    z[1,0,5]  R287      3.3434204757213593e-02
    z[1,0,5]  R288      -5.0606679916381836e-01
    z[1,0,5]  R289      -1.7889726161956787e-01
    z[1,0,5]  R290      -1.6252931952476501e-01
    z[1,0,5]  R291      5.9391415119171143e-01
    z[1,0,5]  R292      -1.9189855456352234e-01
    z[1,0,5]  R293      4.2806863784790039e-01
    z[1,0,5]  R294      2.7523204684257507e-01
    z[1,0,5]  R295      -0.511264443397522
    z[1,0,5]  R296      -0.0551532544195652
    z[1,0,5]  R297      7.5839549303054810e-02
    z[1,0,5]  R298      -6.1982583254575729e-02
    z[1,0,5]  R299      -3.1618049740791321e-01
    z[1,0,5]  R300      -3.2758924365043640e-01
    z[1,0,5]  R301      3.7728220224380493e-02
    z[1,0,5]  R302      2.1341986954212189e-01
    z[1,0,5]  R303      -2.5816529989242554e-01
    z[1,0,5]  R304      3.8002288341522217e-01
    z[1,0,5]  R305      -5.1978421211242676e-01
    z[1,0,5]  R306      -4.6375676989555359e-01
    z[1,0,5]  R307      2.0037825405597687e-01
    z[1,0,5]  R308      4.2616373300552368e-01
    z[1,0,5]  R309      1.8339498341083527e-01
    z[1,0,5]  R310      3.3599036931991577e-01
    z[1,0,5]  R311      -1.5354098379611969e-01
    z[1,0,5]  R312      -2.2313885390758514e-01
    z[1,0,5]  R313      4.2628234624862671e-01
    z[1,0,5]  R314      -4.3180641531944275e-01
    z[1,0,5]  R315      -1.9204846024513245e-01
    z[1,0,5]  R316      -3.0016237497329712e-01
    z[1,0,5]  R317      4.5417442917823792e-01
    z[1,0,5]  R318      1.8342629075050354e-01
    z[1,0,5]  R319      5.6681233644485474e-01
    z[1,0,5]  R320      2.4742105603218079e-01
    z[1,0,5]  R321      1.1944817006587982e-01
    z[1,0,5]  R322      2.5705319643020630e-01
    z[1,0,5]  R323      -5.0330072641372681e-01
    z[1,0,5]  R324      1.1723132431507111e-01
    z[1,0,5]  R325      5.6994143873453140e-02
    z[1,0,5]  R326      2.7316540479660034e-01
    z[1,0,5]  R327      -3.4446594119071960e-01
    z[1,0,5]  R328      -2.0171286165714264e-01
    z[1,0,5]  R329      -5.5400699377059937e-01
    z[1,0,5]  R330      4.0052446722984314e-01
    z[1,0,5]  R331      3.0932599306106567e-01
    z[1,0,5]  R332      -4.4391206465661526e-03
    z[1,0,5]  R333      1.8181413412094116e-02
    z[1,0,5]  R334      -2.0574663579463959e-01
    z[1,0,5]  R335      -1.5640632808208466e-01
    z[1,0,5]  R336      -1.7433337867259979e-02
    z[1,0,5]  R337      -3.1434756517410278e-01
    z[1,0,5]  R338      1.5541951172053814e-02
    z[1,0,5]  R339      2.3965077102184296e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R228      -1
    z[1,0,6]  R229      1
    z[1,0,6]  R230      -5.4073341190814972e-02
    z[1,0,6]  R231      2.0596711337566376e-01
    z[1,0,6]  R232      -2.2136306762695312e-01
    z[1,0,6]  R233      5.1189702749252319e-01
    z[1,0,6]  R234      -2.7853175997734070e-01
    z[1,0,6]  R235      3.3431991934776306e-01
    z[1,0,6]  R236      6.7832171916961670e-02
    z[1,0,6]  R237      -5.8142983913421631e-01
    z[1,0,6]  R238      2.1421007812023163e-02
    z[1,0,6]  R239      -1.3646802306175232e-01
    z[1,0,6]  R240      2.2000966966152191e-01
    z[1,0,6]  R241      2.8514152765274048e-01
    z[1,0,6]  R242      -4.4002164155244827e-02
    z[1,0,6]  R243      -1.3049638271331787e-01
    z[1,0,6]  R244      -1.9374759867787361e-02
    z[1,0,6]  R245      -3.3459511399269104e-01
    z[1,0,6]  R246      6.5542489290237427e-01
    z[1,0,6]  R247      1.0579691082239151e-01
    z[1,0,6]  R248      3.1926054507493973e-02
    z[1,0,6]  R249      2.8151726722717285e-01
    z[1,0,6]  R250      -3.3550536632537842e-01
    z[1,0,6]  R251      -3.7513405084609985e-02
    z[1,0,6]  R252      -2.4722217023372650e-01
    z[1,0,6]  R253      -6.3602608442306519e-01
    z[1,0,6]  R254      1.0947944223880768e-01
    z[1,0,6]  R255      -4.2530137300491333e-01
    z[1,0,6]  R256      -4.5555481314659119e-01
    z[1,0,6]  R257      1.4421868324279785e-01
    z[1,0,6]  R258      -6.4467117190361023e-02
    z[1,0,6]  R259      -7.6031780242919922e-01
    z[1,0,6]  R260      -9.7609780728816986e-02
    z[1,0,6]  R261      4.9747385084629059e-02
    z[1,0,6]  R262      -3.0115723609924316e-01
    z[1,0,6]  R263      4.6444587409496307e-02
    z[1,0,6]  R264      0.199208065867424
    z[1,0,6]  R265      -0.180533766746521
    z[1,0,6]  R266      1.0107289999723434e-01
    z[1,0,6]  R267      -1.3805307447910309e-01
    z[1,0,6]  R268      1.9272369146347046e-01
    z[1,0,6]  R269      1.0131252929568291e-02
    z[1,0,6]  R270      1.2763187289237976e-01
    z[1,0,6]  R271      -0.486610472202301
    z[1,0,6]  R272      -6.3732050359249115e-02
    z[1,0,6]  R273      5.4153460264205933e-01
    z[1,0,6]  R274      3.8584148883819580e-01
    z[1,0,6]  R275      -3.3422295004129410e-02
    z[1,0,6]  R276      2.1657595410943031e-02
    z[1,0,6]  R277      2.6306835934519768e-02
    z[1,0,6]  R278      -1.7360873520374298e-01
    z[1,0,6]  R279      -2.8791844844818115e-01
    z[1,0,6]  R280      -5.2389286458492279e-02
    z[1,0,6]  R281      -1.9620814919471741e-01
    z[1,0,6]  R282      2.5079402327537537e-01
    z[1,0,6]  R283      3.5598197579383850e-01
    z[1,0,6]  R284      3.0722799897193909e-01
    z[1,0,6]  R285      1.8991814553737640e-01
    z[1,0,6]  R286      5.5293250083923340e-01
    z[1,0,6]  R287      1.7244604229927063e-01
    z[1,0,6]  R288      0.132745161652565
    z[1,0,6]  R289      2.3685809969902039e-01
    z[1,0,6]  R290      -3.0023558065295219e-03
    z[1,0,6]  R291      -1.1126353405416012e-02
    z[1,0,6]  R292      -1.5780167281627655e-01
    z[1,0,6]  R293      2.2599419578909874e-02
    z[1,0,6]  R294      8.4277898073196411e-02
    z[1,0,6]  R295      2.4292401969432831e-01
    z[1,0,6]  R296      -8.2080394029617310e-02
    z[1,0,6]  R297      1.1452677100896835e-01
    z[1,0,6]  R298      -1.8692702054977417e-01
    z[1,0,6]  R299      2.4975709617137909e-01
    z[1,0,6]  R300      -7.0599899627268314e-03
    z[1,0,6]  R301      0.334903746843338
    z[1,0,6]  R302      2.6230832934379578e-01
    z[1,0,6]  R303      -4.8832472413778305e-02
    z[1,0,6]  R304      -2.0278413593769073e-01
    z[1,0,6]  R305      4.5380666851997375e-01
    z[1,0,6]  R306      -5.0844949483871460e-01
    z[1,0,6]  R307      -3.1010892987251282e-01
    z[1,0,6]  R308      -2.0153287053108215e-01
    z[1,0,6]  R309      -1.6770051419734955e-01
    z[1,0,6]  R310      1.9983239471912384e-01
    z[1,0,6]  R311      4.9782890081405640e-01
    z[1,0,6]  R312      -5.5163258314132690e-01
    z[1,0,6]  R313      -2.5561100244522095e-01
    z[1,0,6]  R314      1.1177039146423340e-01
    z[1,0,6]  R315      -2.8189316391944885e-01
    z[1,0,6]  R316      2.5481504853814840e-03
    z[1,0,6]  R317      -4.3024727702140808e-01
    z[1,0,6]  R318      -3.8709992170333862e-01
    z[1,0,6]  R319      -4.3280977010726929e-01
    z[1,0,6]  R320      -1.9919589161872864e-01
    z[1,0,6]  R321      -1.5708579123020172e-01
    z[1,0,6]  R322      4.0341550111770630e-01
    z[1,0,6]  R323      0.250916063785553
    z[1,0,6]  R324      0.594076931476593
    z[1,0,6]  R325      -2.8386563062667847e-01
    z[1,0,6]  R326      1.5093356370925903e-01
    z[1,0,6]  R327      1.6574905812740326e-01
    z[1,0,6]  R328      4.9676052294671535e-03
    z[1,0,6]  R329      -2.0203253254294395e-02
    z[1,0,6]  R330      -4.0810006856918335e-01
    z[1,0,6]  R331      -4.4969558715820312e-02
    z[1,0,6]  R332      -3.1377106904983521e-01
    z[1,0,6]  R333      -3.6554921418428421e-02
    z[1,0,6]  R334      -4.8499208688735962e-01
    z[1,0,6]  R335      -3.9638879895210266e-01
    z[1,0,6]  R336      -4.9349474906921387e-01
    z[1,0,6]  R337      1.4735881984233856e-01
    z[1,0,6]  R338      -1.2634842097759247e-01
    z[1,0,6]  R339      -8.0381870269775391e-02
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R340      -1
    z[0,3,0]  R341      1
    z[0,3,0]  R354      -8.6556434631347656e-01
    z[0,3,0]  R355      -4.1236069053411484e-02
    z[0,3,0]  R356      1.0510524362325668e-01
    z[0,3,0]  R357      8.8532008230686188e-02
    z[0,3,0]  R358      -7.9787355661392212e-01
    z[0,3,0]  R359      -7.5574278831481934e-01
    z[0,3,0]  R360      -7.5591254234313965e-01
    z[0,3,0]  R361      1.4318588376045227e-01
    z[0,3,0]  R362      1.8367926776409149e-01
    z[0,3,0]  R363      -1.3492894172668457e-01
    z[0,3,0]  R364      1.0312058776617050e-01
    z[0,3,0]  R365      1.4673198759555817e-01
    z[0,3,0]  R366      -3.2835164666175842e-01
    z[0,3,0]  R367      -6.2497153878211975e-02
    z[0,3,0]  R368      0.575777530670166
    z[0,3,0]  R369      1.7961759865283966e-01
    z[0,3,0]  R370      2.9430544376373291e-01
    z[0,3,0]  R371      1.4689160883426666e-01
    z[0,3,0]  R372      2.3537835478782654e-01
    z[0,3,0]  R373      1.6539818048477173e-01
    z[0,3,0]  R374      -1.1978947371244431e-01
    z[0,3,0]  R375      -2.1345306932926178e-01
    z[0,3,0]  R376      5.0198280811309814e-01
    z[0,3,0]  R377      6.5568894147872925e-02
    z[0,3,0]  R378      -1.6261696815490723e-01
    z[0,3,0]  R379      3.1055265665054321e-01
    z[0,3,0]  R380      -2.0735581219196320e-01
    z[0,3,0]  R381      6.8226224184036255e-01
    z[0,3,0]  R382      6.6444432735443115e-01
    z[0,3,0]  R383      0.780838668346405
    z[0,3,0]  R384      -3.7238067388534546e-01
    z[0,3,0]  R385      1.6116203367710114e-01
    z[0,3,0]  R386      -4.0826341509819031e-01
    z[0,3,0]  R387      -3.4886884689331055e-01
    z[0,3,0]  R388      -9.6671558916568756e-02
    z[0,3,0]  R389      3.0254465341567993e-01
    z[0,3,0]  R390      -2.9394960403442383e-01
    z[0,3,0]  R391      4.2535030841827393e-01
    z[0,3,0]  R392      2.7053418755531311e-01
    z[0,3,0]  R393      -1.4853386580944061e-01
    z[0,3,0]  R394      -6.4769279956817627e-01
    z[0,3,0]  R395      -6.1156213283538818e-01
    z[0,3,0]  R396      -3.8871932029724121e-01
    z[0,3,0]  R397      -1.3857544958591461e-01
    z[0,3,0]  R398      -1.3292810320854187e-01
    z[0,3,0]  R399      2.0611186325550079e-01
    z[0,3,0]  R400      -1.3159725069999695e-01
    z[0,3,0]  R401      5.4140859842300415e-01
    z[0,3,0]  R402      8.4151971340179443e-01
    z[0,3,0]  R403      -4.2333474755287170e-01
    z[0,3,0]  R404      4.0024355053901672e-01
    z[0,3,0]  R405      -1.3610808551311493e-01
    z[0,3,0]  R406      0.00855422206223011
    z[0,3,0]  R407      7.7543449401855469e-01
    z[0,3,0]  R408      -4.4643476605415344e-02
    z[0,3,0]  R409      -4.1574668884277344e-01
    z[0,3,0]  R410      8.0693048238754272e-01
    z[0,3,0]  R411      -2.6147079467773438e-01
    z[0,3,0]  R412      5.6743097305297852e-01
    z[0,3,0]  R413      -1.3485701382160187e-01
    z[0,3,0]  R414      -0.944106936454773
    z[0,3,0]  R415      -8.9444696903228760e-01
    z[0,3,0]  R416      -8.8479697704315186e-01
    z[0,3,0]  R417      -8.3608752489089966e-01
    z[0,3,0]  R418      -7.4958759546279907e-01
    z[0,3,0]  R419      -6.0549592971801758e-01
    z[0,3,0]  R420      8.9866951107978821e-02
    z[0,3,0]  R421      -1.5696670114994049e-01
    z[0,3,0]  R422      4.4755467772483826e-01
    z[0,3,0]  R423      3.8049522042274475e-01
    z[0,3,0]  R424      2.2003683447837830e-01
    z[0,3,0]  R425      2.8103478252887726e-02
    z[0,3,0]  R426      2.6788082718849182e-01
    z[0,3,0]  R427      4.0804773569107056e-01
    z[0,3,0]  R428      7.6667505502700806e-01
    z[0,3,0]  R429      0.556808590888977
    z[0,3,0]  R430      4.4196322560310364e-01
    z[0,3,0]  R431      3.7991029024124146e-01
    z[0,3,0]  R432      3.3493974804878235e-01
    z[0,3,0]  R433      2.6604282855987549e-01
    z[0,3,0]  R434      -1.7396806180477142e-01
    z[0,3,0]  R435      7.4199743568897247e-02
    z[0,3,0]  R436      -2.5420048832893372e-01
    z[0,3,0]  R437      2.0277349278330803e-02
    z[0,3,0]  R438      -1.5550833940505981e-01
    z[0,3,0]  R439      1.4069461822509766e-01
    z[0,3,0]  R440      1.8428291380405426e-01
    z[0,3,0]  R441      7.2697833180427551e-02
    z[0,3,0]  R442      6.1067931354045868e-02
    z[0,3,0]  R443      -1.0487715899944305e-01
    z[0,3,0]  R444      -4.9134048819541931e-01
    z[0,3,0]  R445      -4.0034279227256775e-01
    z[0,3,0]  R446      -5.8334946632385254e-01
    z[0,3,0]  R447      -3.3326229453086853e-01
    z[0,3,0]  R448      -3.1065317988395691e-01
    z[0,3,0]  R449      -1.7757639288902283e-01
    z[0,3,0]  R450      5.4894924163818359e-01
    z[0,3,0]  R451      -2.0485103130340576e-01
    z[0,3,0]  R452      -3.8280868530273438e-01
    z[0,3,0]  R453      -5.7402960956096649e-02
    z[0,3,0]  R454      -0.668807327747345
    z[0,3,0]  R455      -4.1047197580337524e-01
    z[0,3,0]  R456      -6.2148553133010864e-01
    z[0,3,0]  R457      3.4815111756324768e-01
    z[0,3,0]  R458      -1.1442486941814423e-01
    z[0,3,0]  R459      -9.2298634350299835e-02
    z[0,3,0]  R460      -2.4793858826160431e-01
    z[0,3,0]  R461      1.5128245949745178e-01
    z[0,3,0]  R462      7.7955538034439087e-01
    z[0,3,0]  R463      8.5126173496246338e-01
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R342      -1
    z[0,3,1]  R343      1
    z[0,3,1]  R354      3.4495043754577637e-01
    z[0,3,1]  R355      -4.9976086616516113e-01
    z[0,3,1]  R356      -4.7554585337638855e-01
    z[0,3,1]  R357      -6.7512750625610352e-01
    z[0,3,1]  R358      -1.7502070963382721e-01
    z[0,3,1]  R359      -2.4693377315998077e-01
    z[0,3,1]  R360      -1.1827751249074936e-01
    z[0,3,1]  R361      -5.5128842592239380e-01
    z[0,3,1]  R362      1.1151216179132462e-01
    z[0,3,1]  R363      -2.7934971451759338e-01
    z[0,3,1]  R364      -8.5020369291305542e-01
    z[0,3,1]  R365      -5.9273320436477661e-01
    z[0,3,1]  R366      -5.1442635059356689e-01
    z[0,3,1]  R367      -3.3093014359474182e-01
    z[0,3,1]  R368      -3.5620692372322083e-01
    z[0,3,1]  R369      2.3276938498020172e-01
    z[0,3,1]  R370      4.7947758436203003e-01
    z[0,3,1]  R371      4.0138053894042969e-01
    z[0,3,1]  R372      9.1129429638385773e-02
    z[0,3,1]  R373      6.3216572999954224e-01
    z[0,3,1]  R374      -8.8463604450225830e-02
    z[0,3,1]  R375      -5.3806287050247192e-01
    z[0,3,1]  R376      -6.6432762145996094e-01
    z[0,3,1]  R377      -7.2125440835952759e-01
    z[0,3,1]  R378      -2.6211544871330261e-01
    z[0,3,1]  R379      -0.501920759677887
    z[0,3,1]  R380      2.0636498928070068e-02
    z[0,3,1]  R381      3.3570915460586548e-01
    z[0,3,1]  R382      1.0734263807535172e-01
    z[0,3,1]  R383      6.6693723201751709e-02
    z[0,3,1]  R384      2.9823088645935059e-01
    z[0,3,1]  R385      -7.5452917814254761e-01
    z[0,3,1]  R386      -3.2540559768676758e-01
    z[0,3,1]  R387      -5.0323939323425293e-01
    z[0,3,1]  R388      -7.5589370727539062e-01
    z[0,3,1]  R389      -0.687433660030365
    z[0,3,1]  R390      -3.8846787810325623e-01
    z[0,3,1]  R391      -3.9844623208045959e-01
    z[0,3,1]  R392      -3.2046353816986084e-01
    z[0,3,1]  R393      -2.0761089026927948e-01
    z[0,3,1]  R394      -4.3487891554832458e-01
    z[0,3,1]  R395      -7.4214714765548706e-01
    z[0,3,1]  R396      -5.5393588542938232e-01
    z[0,3,1]  R397      3.2467627525329590e-01
    z[0,3,1]  R398      -6.2469649314880371e-01
    z[0,3,1]  R399      -1.2720146775245667e-01
    z[0,3,1]  R400      -2.3071397840976715e-01
    z[0,3,1]  R401      3.4664157032966614e-01
    z[0,3,1]  R402      7.2865389287471771e-02
    z[0,3,1]  R403      -3.5707134008407593e-01
    z[0,3,1]  R404      -3.9317104220390320e-01
    z[0,3,1]  R405      -2.7948483824729919e-01
    z[0,3,1]  R406      1.3539044186472893e-02
    z[0,3,1]  R407      0.156547412276268
    z[0,3,1]  R408      -1.3347235508263111e-02
    z[0,3,1]  R409      -3.4653863310813904e-01
    z[0,3,1]  R410      -2.4881218373775482e-01
    z[0,3,1]  R411      7.2614312171936035e-01
    z[0,3,1]  R412      -5.4835790395736694e-01
    z[0,3,1]  R413      7.5021088123321533e-01
    z[0,3,1]  R414      -1.4133305847644806e-01
    z[0,3,1]  R415      3.1024524569511414e-01
    z[0,3,1]  R416      -7.7348113059997559e-02
    z[0,3,1]  R417      -2.5451722741127014e-01
    z[0,3,1]  R418      -3.5656234622001648e-01
    z[0,3,1]  R419      -1.1910539120435715e-01
    z[0,3,1]  R420      8.5235631465911865e-01
    z[0,3,1]  R421      0.825688362121582
    z[0,3,1]  R422      8.4348762035369873e-01
    z[0,3,1]  R423      8.3468645811080933e-01
    z[0,3,1]  R424      -8.1150442361831665e-01
    z[0,3,1]  R425      -5.7987397909164429e-01
    z[0,3,1]  R426      -6.5155172348022461e-01
    z[0,3,1]  R427      -6.5436708927154541e-01
    z[0,3,1]  R428      -3.1652554869651794e-01
    z[0,3,1]  R429      -3.0074384808540344e-01
    z[0,3,1]  R430      -4.0133380889892578e-01
    z[0,3,1]  R431      -2.6648142933845520e-01
    z[0,3,1]  R432      -4.2979344725608826e-01
    z[0,3,1]  R433      -2.3862951993942261e-01
    z[0,3,1]  R434      1.6371791064739227e-01
    z[0,3,1]  R435      1.5403643250465393e-01
    z[0,3,1]  R436      -1.1247289367020130e-02
    z[0,3,1]  R437      1.7395548522472382e-01
    z[0,3,1]  R438      -6.5469431877136230e-01
    z[0,3,1]  R439      -8.2501769065856934e-02
    z[0,3,1]  R440      -5.5584597587585449e-01
    z[0,3,1]  R441      6.4218886196613312e-02
    z[0,3,1]  R442      -3.2696792483329773e-01
    z[0,3,1]  R443      4.2401787638664246e-01
    z[0,3,1]  R444      2.6551276445388794e-01
    z[0,3,1]  R445      -5.3360808640718460e-02
    z[0,3,1]  R446      -6.0729876160621643e-02
    z[0,3,1]  R447      -2.1936267614364624e-01
    z[0,3,1]  R448      5.2177053689956665e-01
    z[0,3,1]  R449      -2.4402105808258057e-01
    z[0,3,1]  R450      -7.2244131565093994e-01
    z[0,3,1]  R451      -1.3527034223079681e-01
    z[0,3,1]  R452      2.3988784849643707e-01
    z[0,3,1]  R453      -8.2922744750976562e-01
    z[0,3,1]  R454      -3.0286094546318054e-01
    z[0,3,1]  R455      -3.9802485704421997e-01
    z[0,3,1]  R456      5.1660817861557007e-01
    z[0,3,1]  R457      -6.8225634098052979e-01
    z[0,3,1]  R458      -5.0074762105941772e-01
    z[0,3,1]  R459      -0.630085289478302
    z[0,3,1]  R460      -3.1725892424583435e-01
    z[0,3,1]  R461      -4.0940544009208679e-01
    z[0,3,1]  R462      2.0677064359188080e-01
    z[0,3,1]  R463      1.3145956397056580e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R344      -1
    z[0,3,2]  R345      1
    z[0,3,2]  R354      2.7621725574135780e-02
    z[0,3,2]  R355      7.3466020822525024e-01
    z[0,3,2]  R356      6.8202590942382812e-01
    z[0,3,2]  R357      4.5618841052055359e-01
    z[0,3,2]  R358      -0.0845438539981842
    z[0,3,2]  R359      -0.0838879719376564
    z[0,3,2]  R360      -8.3456777036190033e-02
    z[0,3,2]  R361      6.6848099231719971e-01
    z[0,3,2]  R362      4.7175869345664978e-01
    z[0,3,2]  R363      6.5274572372436523e-01
    z[0,3,2]  R364      -3.9539617300033569e-01
    z[0,3,2]  R365      -5.1124978065490723e-01
    z[0,3,2]  R366      -2.8793439269065857e-01
    z[0,3,2]  R367      -2.7269563078880310e-01
    z[0,3,2]  R368      -3.3951789140701294e-01
    z[0,3,2]  R369      -6.9787585735321045e-01
    z[0,3,2]  R370      -6.5587985515594482e-01
    z[0,3,2]  R371      -8.2782596349716187e-01
    z[0,3,2]  R372      -5.7603049278259277e-01
    z[0,3,2]  R373      -6.3554090261459351e-01
    z[0,3,2]  R374      -6.6490036249160767e-01
    z[0,3,2]  R375      -3.2557302713394165e-01
    z[0,3,2]  R376      -1.1641083657741547e-01
    z[0,3,2]  R377      2.1482974290847778e-01
    z[0,3,2]  R378      8.1824511289596558e-02
    z[0,3,2]  R379      1.4156261086463928e-01
    z[0,3,2]  R380      -5.0084173679351807e-02
    z[0,3,2]  R381      -6.5664090216159821e-02
    z[0,3,2]  R382      3.1432278454303741e-02
    z[0,3,2]  R383      -2.5956818461418152e-01
    z[0,3,2]  R384      -7.7168178558349609e-01
    z[0,3,2]  R385      -2.0968298614025116e-01
    z[0,3,2]  R386      -1.9802008569240570e-01
    z[0,3,2]  R387      -4.7668609023094177e-01
    z[0,3,2]  R388      1.9084939360618591e-01
    z[0,3,2]  R389      2.7320548892021179e-01
    z[0,3,2]  R390      -2.9504847526550293e-01
    z[0,3,2]  R391      -1.9627763330936432e-01
    z[0,3,2]  R392      -1.3070015609264374e-01
    z[0,3,2]  R393      -2.6683833450078964e-02
    z[0,3,2]  R394      -4.4522222876548767e-01
    z[0,3,2]  R395      -1.1112175136804581e-01
    z[0,3,2]  R396      -2.4236644804477692e-01
    z[0,3,2]  R397      -6.1946034431457520e-01
    z[0,3,2]  R398      2.7883926033973694e-01
    z[0,3,2]  R399      -6.6978245973587036e-01
    z[0,3,2]  R400      -6.2185734510421753e-02
    z[0,3,2]  R401      -7.4284210801124573e-02
    z[0,3,2]  R402      -1.0192904621362686e-01
    z[0,3,2]  R403      5.8484065532684326e-01
    z[0,3,2]  R404      -3.4029707312583923e-01
    z[0,3,2]  R405      -7.9746223986148834e-02
    z[0,3,2]  R406      -6.2350231409072876e-01
    z[0,3,2]  R407      -3.8162497803568840e-03
    z[0,3,2]  R408      -1.1624182574450970e-02
    z[0,3,2]  R409      0.644105076789856
    z[0,3,2]  R410      1.5265475213527679e-01
    z[0,3,2]  R411      -3.2871926669031382e-03
    z[0,3,2]  R412      -0.286289244890213
    z[0,3,2]  R413      1.9715599715709686e-01
    z[0,3,2]  R414      3.1066054478287697e-02
    z[0,3,2]  R415      -2.8208622243255377e-03
    z[0,3,2]  R416      -6.7019328474998474e-02
    z[0,3,2]  R417      1.4348384737968445e-01
    z[0,3,2]  R418      2.6731422543525696e-01
    z[0,3,2]  R419      -8.3356760442256927e-02
    z[0,3,2]  R420      -5.5839867854956537e-05
    z[0,3,2]  R421      1.4025759696960449e-01
    z[0,3,2]  R422      1.1999390274286270e-01
    z[0,3,2]  R423      1.0017056018114090e-02
    z[0,3,2]  R424      -1.1276292800903320e-01
    z[0,3,2]  R425      -2.7658042311668396e-01
    z[0,3,2]  R426      3.2855155877768993e-03
    z[0,3,2]  R427      -4.0102750062942505e-02
    z[0,3,2]  R428      -1.1400407552719116e-01
    z[0,3,2]  R429      -1.6668376326560974e-01
    z[0,3,2]  R430      1.4053578674793243e-01
    z[0,3,2]  R431      2.3021285235881805e-01
    z[0,3,2]  R432      -1.4832855761051178e-01
    z[0,3,2]  R433      1.3894286751747131e-01
    z[0,3,2]  R434      -8.0853068828582764e-01
    z[0,3,2]  R435      -8.9067792892456055e-01
    z[0,3,2]  R436      -4.1614410281181335e-01
    z[0,3,2]  R437      -4.1055321693420410e-01
    z[0,3,2]  R438      5.7632780075073242e-01
    z[0,3,2]  R439      -7.0586651563644409e-01
    z[0,3,2]  R440      -2.3154844343662262e-01
    z[0,3,2]  R441      5.5463171005249023e-01
    z[0,3,2]  R442      -4.2904245853424072e-01
    z[0,3,2]  R443      1.9134703278541565e-01
    z[0,3,2]  R444      -5.7128328084945679e-01
    z[0,3,2]  R445      -3.7148031592369080e-01
    z[0,3,2]  R446      -5.6626230478286743e-01
    z[0,3,2]  R447      -5.5301815271377563e-01
    z[0,3,2]  R448      -5.7177132368087769e-01
    z[0,3,2]  R449      -4.0159627795219421e-01
    z[0,3,2]  R450      -1.7308506369590759e-01
    z[0,3,2]  R451      -3.7613001465797424e-01
    z[0,3,2]  R452      -0.646323025226593
    z[0,3,2]  R453      4.9229413270950317e-01
    z[0,3,2]  R454      -7.6841311529278755e-03
    z[0,3,2]  R455      -7.0883341133594513e-02
    z[0,3,2]  R456      -3.2401564717292786e-01
    z[0,3,2]  R457      -4.4205355644226074e-01
    z[0,3,2]  R458      -3.5247129201889038e-01
    z[0,3,2]  R459      1.5784873068332672e-01
    z[0,3,2]  R460      -5.9990704059600830e-01
    z[0,3,2]  R461      -7.1209657192230225e-01
    z[0,3,2]  R462      1.3143076002597809e-01
    z[0,3,2]  R463      -2.8840396553277969e-02
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R346      -1
    z[0,3,3]  R347      1
    z[0,3,3]  R354      -3.5168325901031494e-01
    z[0,3,3]  R355      -3.1265783309936523e-01
    z[0,3,3]  R356      -2.9012054204940796e-01
    z[0,3,3]  R357      -4.4434544444084167e-01
    z[0,3,3]  R358      -6.9123253226280212e-02
    z[0,3,3]  R359      -1.6010272502899170e-01
    z[0,3,3]  R360      -6.1893612146377563e-03
    z[0,3,3]  R361      4.2321330308914185e-01
    z[0,3,3]  R362      -3.2259920239448547e-01
    z[0,3,3]  R363      2.7095075696706772e-02
    z[0,3,3]  R364      1.9906303286552429e-01
    z[0,3,3]  R365      9.8733194172382355e-02
    z[0,3,3]  R366      2.7285942435264587e-01
    z[0,3,3]  R367      1.3957878947257996e-01
    z[0,3,3]  R368      1.2894868850708008e-01
    z[0,3,3]  R369      -3.2551360130310059e-01
    z[0,3,3]  R370      -3.4541919827461243e-01
    z[0,3,3]  R371      -3.1703576445579529e-01
    z[0,3,3]  R372      -6.7687761783599854e-01
    z[0,3,3]  R373      6.3811734318733215e-02
    z[0,3,3]  R374      -4.9727335572242737e-01
    z[0,3,3]  R375      -5.6930756568908691e-01
    z[0,3,3]  R376      -1.3958480954170227e-01
    z[0,3,3]  R377      -5.4697811603546143e-01
    z[0,3,3]  R378      0.805844783782959
    z[0,3,3]  R379      -4.9574910663068295e-03
    z[0,3,3]  R380      -6.2206178903579712e-01
    z[0,3,3]  R381      5.2626281976699829e-01
    z[0,3,3]  R382      5.6888228654861450e-01
    z[0,3,3]  R383      4.4461691379547119e-01
    z[0,3,3]  R384      -1.0837078839540482e-01
    z[0,3,3]  R385      4.5038022100925446e-02
    z[0,3,3]  R386      -4.1925823688507080e-01
    z[0,3,3]  R387      -1.5297304093837738e-01
    z[0,3,3]  R388      -4.0619823336601257e-01
    z[0,3,3]  R389      1.5630979090929031e-02
    z[0,3,3]  R390      -6.4796352386474609e-01
    z[0,3,3]  R391      2.3813745379447937e-01
    z[0,3,3]  R392      7.2073060274124146e-01
    z[0,3,3]  R393      6.2681853771209717e-01
    z[0,3,3]  R394      6.4228519797325134e-02
    z[0,3,3]  R395      -1.3735200464725494e-01
    z[0,3,3]  R396      4.4287565350532532e-01
    z[0,3,3]  R397      -4.1826283931732178e-01
    z[0,3,3]  R398      3.7058338522911072e-01
    z[0,3,3]  R399      3.4639132022857666e-01
    z[0,3,3]  R400      8.5716533660888672e-01
    z[0,3,3]  R401      6.5562093257904053e-01
    z[0,3,3]  R402      3.0329120159149170e-01
    z[0,3,3]  R403      -2.0099332928657532e-01
    z[0,3,3]  R404      1.7543128132820129e-01
    z[0,3,3]  R405      6.7784392833709717e-01
    z[0,3,3]  R406      0.71389240026474
    z[0,3,3]  R407      3.9879637956619263e-01
    z[0,3,3]  R408      -7.6556110382080078e-01
    z[0,3,3]  R409      -2.1251289546489716e-01
    z[0,3,3]  R410      5.0486225634813309e-02
    z[0,3,3]  R411      4.8082742094993591e-01
    z[0,3,3]  R412      -0.0451047383248806
    z[0,3,3]  R413      4.3817591667175293e-01
    z[0,3,3]  R414      -2.3871541023254395e-01
    z[0,3,3]  R415      -2.9863205552101135e-01
    z[0,3,3]  R416      -1.6798898577690125e-02
    z[0,3,3]  R417      -2.6354414224624634e-01
    z[0,3,3]  R418      -3.3292093873023987e-01
    z[0,3,3]  R419      -1.7964872717857361e-01
    z[0,3,3]  R420      -4.3329432606697083e-01
    z[0,3,3]  R421      4.7001048922538757e-01
    z[0,3,3]  R422      3.3752273768186569e-02
    z[0,3,3]  R423      -1.3107106089591980e-01
    z[0,3,3]  R424      3.4038993716239929e-01
    z[0,3,3]  R425      7.3964673280715942e-01
    z[0,3,3]  R426      5.3205049037933350e-01
    z[0,3,3]  R427      2.7089712023735046e-01
    z[0,3,3]  R428      2.5936564803123474e-01
    z[0,3,3]  R429      4.3587756156921387e-01
    z[0,3,3]  R430      -7.3502779006958008e-01
    z[0,3,3]  R431      -7.5853610038757324e-01
    z[0,3,3]  R432      -7.4429786205291748e-01
    z[0,3,3]  R433      -6.6490846872329712e-01
    z[0,3,3]  R434      -2.3528985679149628e-01
    z[0,3,3]  R435      -4.0259385108947754e-01
    z[0,3,3]  R436      -1.9214524328708649e-01
    z[0,3,3]  R437      -4.7693881392478943e-01
    z[0,3,3]  R438      1.9922161102294922e-01
    z[0,3,3]  R439      -1.2619754672050476e-01
    z[0,3,3]  R440      -3.2596865296363831e-01
    z[0,3,3]  R441      -5.2830260992050171e-01
    z[0,3,3]  R442      -2.3884449899196625e-01
    z[0,3,3]  R443      1.5330067276954651e-01
    z[0,3,3]  R444      -1.3977591693401337e-01
    z[0,3,3]  R445      -5.2640640735626221e-01
    z[0,3,3]  R446      1.1290020495653152e-01
    z[0,3,3]  R447      -3.5654491186141968e-01
    z[0,3,3]  R448      -0.0711822658777237
    z[0,3,3]  R449      -0.726284384727478
    z[0,3,3]  R450      8.2584097981452942e-02
    z[0,3,3]  R451      -7.2395765781402588e-01
    z[0,3,3]  R452      2.3945966362953186e-01
    z[0,3,3]  R453      5.5998995900154114e-02
    z[0,3,3]  R454      -5.6604892015457153e-01
    z[0,3,3]  R455      -7.7647775411605835e-01
    z[0,3,3]  R456      2.5465661287307739e-01
    z[0,3,3]  R457      -1.8583337962627411e-01
    z[0,3,3]  R458      5.5111092329025269e-01
    z[0,3,3]  R459      2.2040309011936188e-01
    z[0,3,3]  R460      4.0116113424301147e-01
    z[0,3,3]  R461      -1.0231083631515503e-01
    z[0,3,3]  R462      5.5638146400451660e-01
    z[0,3,3]  R463      2.8883364796638489e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R348      -1
    z[0,3,4]  R349      1
    z[0,3,4]  R354      -6.6957190632820129e-02
    z[0,3,4]  R355      2.1465896070003510e-01
    z[0,3,4]  R356      2.7437087893486023e-01
    z[0,3,4]  R357      6.2506482005119324e-02
    z[0,3,4]  R358      3.9351871609687805e-01
    z[0,3,4]  R359      0.422784686088562
    z[0,3,4]  R360      2.4455915391445160e-01
    z[0,3,4]  R361      -1.3691918551921844e-01
    z[0,3,4]  R362      -5.9453827142715454e-01
    z[0,3,4]  R363      -6.2357103824615479e-01
    z[0,3,4]  R364      2.1007342636585236e-01
    z[0,3,4]  R365      5.6166488677263260e-02
    z[0,3,4]  R366      -6.3911330699920654e-01
    z[0,3,4]  R367      -7.8037220239639282e-01
    z[0,3,4]  R368      -5.7170045375823975e-01
    z[0,3,4]  R369      -1.2757124379277229e-02
    z[0,3,4]  R370      -3.5243952274322510e-01
    z[0,3,4]  R371      -1.1243198066949844e-01
    z[0,3,4]  R372      -3.2792448997497559e-01
    z[0,3,4]  R373      -5.1740769296884537e-02
    z[0,3,4]  R374      -4.2554304003715515e-01
    z[0,3,4]  R375      -3.4818568825721741e-01
    z[0,3,4]  R376      -3.9911502599716187e-01
    z[0,3,4]  R377      -2.4722869694232941e-01
    z[0,3,4]  R378      -2.5145837664604187e-01
    z[0,3,4]  R379      -3.9427399635314941e-01
    z[0,3,4]  R380      3.0580586194992065e-01
    z[0,3,4]  R381      6.5072283148765564e-02
    z[0,3,4]  R382      -1.2051870115101337e-02
    z[0,3,4]  R383      2.4295248091220856e-01
    z[0,3,4]  R384      1.1104691773653030e-01
    z[0,3,4]  R385      -2.9548043012619019e-01
    z[0,3,4]  R386      3.9793637394905090e-01
    z[0,3,4]  R387      -0.35687056183815
    z[0,3,4]  R388      -1.3751165568828583e-01
    z[0,3,4]  R389      -4.9464112520217896e-01
    z[0,3,4]  R390      4.0702825784683228e-01
    z[0,3,4]  R391      -4.1676875948905945e-01
    z[0,3,4]  R392      -3.2262614369392395e-01
    z[0,3,4]  R393      -1.8061390519142151e-01
    z[0,3,4]  R394      -2.9686695337295532e-01
    z[0,3,4]  R395      -7.1076206862926483e-02
    z[0,3,4]  R396      -2.4156036972999573e-01
    z[0,3,4]  R397      -2.0897619426250458e-02
    z[0,3,4]  R398      1.0163921862840652e-01
    z[0,3,4]  R399      -5.3750729560852051e-01
    z[0,3,4]  R400      3.0570149421691895e-01
    z[0,3,4]  R401      7.2318062186241150e-02
    z[0,3,4]  R402      -3.7874445319175720e-01
    z[0,3,4]  R403      5.9320259839296341e-02
    z[0,3,4]  R404      -4.6008464694023132e-01
    z[0,3,4]  R405      5.8294606208801270e-01
    z[0,3,4]  R406      -0.0536101870238781
    z[0,3,4]  R407      -4.6203276515007019e-01
    z[0,3,4]  R408      -3.6614328622817993e-01
    z[0,3,4]  R409      2.5582334399223328e-01
    z[0,3,4]  R410      -1.3138620555400848e-01
    z[0,3,4]  R411      2.2937799990177155e-01
    z[0,3,4]  R412      5.2642589807510376e-01
    z[0,3,4]  R413      -3.5246974229812622e-01
    z[0,3,4]  R414      1.6339996457099915e-01
    z[0,3,4]  R415      -5.2320018410682678e-02
    z[0,3,4]  R416      -2.7691149711608887e-01
    z[0,3,4]  R417      -3.3400258421897888e-01
    z[0,3,4]  R418      3.0865228176116943e-01
    z[0,3,4]  R419      2.8320398926734924e-01
    z[0,3,4]  R420      2.0661781728267670e-01
    z[0,3,4]  R421      -1.7275722324848175e-01
    z[0,3,4]  R422      -6.0702469199895859e-02
    z[0,3,4]  R423      2.2721193730831146e-01
    z[0,3,4]  R424      -1.2641771696507931e-02
    z[0,3,4]  R425      -1.3777954876422882e-01
    z[0,3,4]  R426      -4.0162146091461182e-01
    z[0,3,4]  R427      -5.1921719312667847e-01
    z[0,3,4]  R428      1.8441526591777802e-01
    z[0,3,4]  R429      0.0917959213256836
    z[0,3,4]  R430      -2.2069972753524780e-01
    z[0,3,4]  R431      -2.4616606533527374e-01
    z[0,3,4]  R432      4.3175943195819855e-02
    z[0,3,4]  R433      -2.7231946587562561e-01
    z[0,3,4]  R434      1.4991672337055206e-01
    z[0,3,4]  R435      7.3038570582866669e-02
    z[0,3,4]  R436      1.2004748731851578e-01
    z[0,3,4]  R437      -1.6610343754291534e-01
    z[0,3,4]  R438      7.4635609984397888e-02
    z[0,3,4]  R439      -3.2716533541679382e-01
    z[0,3,4]  R440      -5.2616512775421143e-01
    z[0,3,4]  R441      -5.2414391189813614e-02
    z[0,3,4]  R442      7.6712578535079956e-01
    z[0,3,4]  R443      7.2057497501373291e-01
    z[0,3,4]  R444      -2.1359895169734955e-01
    z[0,3,4]  R445      2.2223877906799316e-01
    z[0,3,4]  R446      -0.164543017745018
    z[0,3,4]  R447      -3.8728281855583191e-01
    z[0,3,4]  R448      3.3666431903839111e-01
    z[0,3,4]  R449      -3.3305177092552185e-01
    z[0,3,4]  R450      7.8389182686805725e-02
    z[0,3,4]  R451      4.9128594994544983e-01
    z[0,3,4]  R452      5.0390070676803589e-01
    z[0,3,4]  R453      -2.4160590767860413e-01
    z[0,3,4]  R454      3.5600054264068604e-01
    z[0,3,4]  R455      3.9648368954658508e-02
    z[0,3,4]  R456      1.3042362034320831e-01
    z[0,3,4]  R457      -3.2231798768043518e-01
    z[0,3,4]  R458      3.4890845417976379e-01
    z[0,3,4]  R459      5.7207494974136353e-01
    z[0,3,4]  R460      4.8841181397438049e-01
    z[0,3,4]  R461      0.535327136516571
    z[0,3,4]  R462      -0.0871153250336647
    z[0,3,4]  R463      -3.4129226207733154e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R350      -1
    z[0,3,5]  R351      1
    z[0,3,5]  R354      1.1650804430246353e-02
    z[0,3,5]  R355      -1.6273267567157745e-01
    z[0,3,5]  R356      -2.7441319823265076e-01
    z[0,3,5]  R357      -1.3563459739089012e-02
    z[0,3,5]  R358      -2.6757022738456726e-01
    z[0,3,5]  R359      3.4697356820106506e-01
    z[0,3,5]  R360      2.0508494973182678e-01
    z[0,3,5]  R361      3.3434204757213593e-02
    z[0,3,5]  R362      -5.0606679916381836e-01
    z[0,3,5]  R363      -1.7889726161956787e-01
    z[0,3,5]  R364      -1.6252931952476501e-01
    z[0,3,5]  R365      5.9391415119171143e-01
    z[0,3,5]  R366      -1.9189855456352234e-01
    z[0,3,5]  R367      4.2806863784790039e-01
    z[0,3,5]  R368      2.7523204684257507e-01
    z[0,3,5]  R369      -0.511264443397522
    z[0,3,5]  R370      -0.0551532544195652
    z[0,3,5]  R371      7.5839549303054810e-02
    z[0,3,5]  R372      -6.1982583254575729e-02
    z[0,3,5]  R373      -3.1618049740791321e-01
    z[0,3,5]  R374      -3.2758924365043640e-01
    z[0,3,5]  R375      3.7728220224380493e-02
    z[0,3,5]  R376      2.1341986954212189e-01
    z[0,3,5]  R377      -2.5816529989242554e-01
    z[0,3,5]  R378      3.8002288341522217e-01
    z[0,3,5]  R379      -5.1978421211242676e-01
    z[0,3,5]  R380      -4.6375676989555359e-01
    z[0,3,5]  R381      2.0037825405597687e-01
    z[0,3,5]  R382      4.2616373300552368e-01
    z[0,3,5]  R383      1.8339498341083527e-01
    z[0,3,5]  R384      3.3599036931991577e-01
    z[0,3,5]  R385      -1.5354098379611969e-01
    z[0,3,5]  R386      -2.2313885390758514e-01
    z[0,3,5]  R387      4.2628234624862671e-01
    z[0,3,5]  R388      -4.3180641531944275e-01
    z[0,3,5]  R389      -1.9204846024513245e-01
    z[0,3,5]  R390      -3.0016237497329712e-01
    z[0,3,5]  R391      4.5417442917823792e-01
    z[0,3,5]  R392      1.8342629075050354e-01
    z[0,3,5]  R393      5.6681233644485474e-01
    z[0,3,5]  R394      2.4742105603218079e-01
    z[0,3,5]  R395      1.1944817006587982e-01
    z[0,3,5]  R396      2.5705319643020630e-01
    z[0,3,5]  R397      -5.0330072641372681e-01
    z[0,3,5]  R398      1.1723132431507111e-01
    z[0,3,5]  R399      5.6994143873453140e-02
    z[0,3,5]  R400      2.7316540479660034e-01
    z[0,3,5]  R401      -3.4446594119071960e-01
    z[0,3,5]  R402      -2.0171286165714264e-01
    z[0,3,5]  R403      -5.5400699377059937e-01
    z[0,3,5]  R404      4.0052446722984314e-01
    z[0,3,5]  R405      3.0932599306106567e-01
    z[0,3,5]  R406      -4.4391206465661526e-03
    z[0,3,5]  R407      1.8181413412094116e-02
    z[0,3,5]  R408      -2.0574663579463959e-01
    z[0,3,5]  R409      -1.5640632808208466e-01
    z[0,3,5]  R410      -1.7433337867259979e-02
    z[0,3,5]  R411      -3.1434756517410278e-01
    z[0,3,5]  R412      1.5541951172053814e-02
    z[0,3,5]  R413      2.3965077102184296e-01
    z[0,3,5]  R414      -4.1141159832477570e-02
    z[0,3,5]  R415      -1.1985564604401588e-02
    z[0,3,5]  R416      1.4819647371768951e-01
    z[0,3,5]  R417      -1.0341908782720566e-01
    z[0,3,5]  R418      -1.5589644201099873e-02
    z[0,3,5]  R419      7.0687723159790039e-01
    z[0,3,5]  R420      -4.2672500014305115e-02
    z[0,3,5]  R421      9.3455202877521515e-02
    z[0,3,5]  R422      -2.4984742701053619e-01
    z[0,3,5]  R423      2.3103237152099609e-01
    z[0,3,5]  R424      -1.6044294834136963e-01
    z[0,3,5]  R425      1.4248742163181305e-01
    z[0,3,5]  R426      2.3973587155342102e-01
    z[0,3,5]  R427      -2.4542784690856934e-01
    z[0,3,5]  R428      4.4444516301155090e-01
    z[0,3,5]  R429      5.5228674411773682e-01
    z[0,3,5]  R430      1.3328480720520020e-01
    z[0,3,5]  R431      -2.2664764523506165e-01
    z[0,3,5]  R432      1.1630005389451981e-01
    z[0,3,5]  R433      1.0064236819744110e-01
    z[0,3,5]  R434      -2.9604652523994446e-01
    z[0,3,5]  R435      -8.5728786885738373e-02
    z[0,3,5]  R436      -6.8737751245498657e-01
    z[0,3,5]  R437      -7.3190432786941528e-01
    z[0,3,5]  R438      -3.5814478993415833e-01
    z[0,3,5]  R439      5.8670127391815186e-01
    z[0,3,5]  R440      4.0954446792602539e-01
    z[0,3,5]  R441      -2.6134172081947327e-01
    z[0,3,5]  R442      -0.087669737637043
    z[0,3,5]  R443      -4.3736183643341064e-01
    z[0,3,5]  R444      -4.2121067643165588e-01
    z[0,3,5]  R445      -0.574893593788147
    z[0,3,5]  R446      -5.1622176170349121e-01
    z[0,3,5]  R447      3.9533430337905884e-01
    z[0,3,5]  R448      4.2813035845756531e-01
    z[0,3,5]  R449      -4.8270203173160553e-02
    z[0,3,5]  R450      2.8862106800079346e-01
    z[0,3,5]  R451      -5.1075357943773270e-02
    z[0,3,5]  R452      -2.4388688802719116e-01
    z[0,3,5]  R453      6.0606010258197784e-02
    z[0,3,5]  R454      -8.9180164039134979e-02
    z[0,3,5]  R455      -0.0878542810678482
    z[0,3,5]  R456      1.1024557054042816e-02
    z[0,3,5]  R457      -2.2485619783401489e-01
    z[0,3,5]  R458      -2.9883494973182678e-01
    z[0,3,5]  R459      2.6258125901222229e-01
    z[0,3,5]  R460      1.6365723311901093e-01
    z[0,3,5]  R461      7.3313899338245392e-02
    z[0,3,5]  R462      -1.2089667469263077e-01
    z[0,3,5]  R463      -1.2820911407470703e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R352      -1
    z[0,3,6]  R353      1
    z[0,3,6]  R354      -5.2389286458492279e-02
    z[0,3,6]  R355      -1.9620814919471741e-01
    z[0,3,6]  R356      2.5079402327537537e-01
    z[0,3,6]  R357      3.5598197579383850e-01
    z[0,3,6]  R358      3.0722799897193909e-01
    z[0,3,6]  R359      1.8991814553737640e-01
    z[0,3,6]  R360      5.5293250083923340e-01
    z[0,3,6]  R361      1.7244604229927063e-01
    z[0,3,6]  R362      0.132745161652565
    z[0,3,6]  R363      2.3685809969902039e-01
    z[0,3,6]  R364      -3.0023558065295219e-03
    z[0,3,6]  R365      -1.1126353405416012e-02
    z[0,3,6]  R366      -1.5780167281627655e-01
    z[0,3,6]  R367      2.2599419578909874e-02
    z[0,3,6]  R368      8.4277898073196411e-02
    z[0,3,6]  R369      2.4292401969432831e-01
    z[0,3,6]  R370      -8.2080394029617310e-02
    z[0,3,6]  R371      1.1452677100896835e-01
    z[0,3,6]  R372      -1.8692702054977417e-01
    z[0,3,6]  R373      2.4975709617137909e-01
    z[0,3,6]  R374      -7.0599899627268314e-03
    z[0,3,6]  R375      0.334903746843338
    z[0,3,6]  R376      2.6230832934379578e-01
    z[0,3,6]  R377      -4.8832472413778305e-02
    z[0,3,6]  R378      -2.0278413593769073e-01
    z[0,3,6]  R379      4.5380666851997375e-01
    z[0,3,6]  R380      -5.0844949483871460e-01
    z[0,3,6]  R381      -3.1010892987251282e-01
    z[0,3,6]  R382      -2.0153287053108215e-01
    z[0,3,6]  R383      -1.6770051419734955e-01
    z[0,3,6]  R384      1.9983239471912384e-01
    z[0,3,6]  R385      4.9782890081405640e-01
    z[0,3,6]  R386      -5.5163258314132690e-01
    z[0,3,6]  R387      -2.5561100244522095e-01
    z[0,3,6]  R388      1.1177039146423340e-01
    z[0,3,6]  R389      -2.8189316391944885e-01
    z[0,3,6]  R390      2.5481504853814840e-03
    z[0,3,6]  R391      -4.3024727702140808e-01
    z[0,3,6]  R392      -3.8709992170333862e-01
    z[0,3,6]  R393      -4.3280977010726929e-01
    z[0,3,6]  R394      -1.9919589161872864e-01
    z[0,3,6]  R395      -1.5708579123020172e-01
    z[0,3,6]  R396      4.0341550111770630e-01
    z[0,3,6]  R397      0.250916063785553
    z[0,3,6]  R398      0.594076931476593
    z[0,3,6]  R399      -2.8386563062667847e-01
    z[0,3,6]  R400      1.5093356370925903e-01
    z[0,3,6]  R401      1.6574905812740326e-01
    z[0,3,6]  R402      4.9676052294671535e-03
    z[0,3,6]  R403      -2.0203253254294395e-02
    z[0,3,6]  R404      -4.0810006856918335e-01
    z[0,3,6]  R405      -4.4969558715820312e-02
    z[0,3,6]  R406      -3.1377106904983521e-01
    z[0,3,6]  R407      -3.6554921418428421e-02
    z[0,3,6]  R408      -4.8499208688735962e-01
    z[0,3,6]  R409      -3.9638879895210266e-01
    z[0,3,6]  R410      -4.9349474906921387e-01
    z[0,3,6]  R411      1.4735881984233856e-01
    z[0,3,6]  R412      -1.2634842097759247e-01
    z[0,3,6]  R413      -8.0381870269775391e-02
    z[0,3,6]  R414      -4.8421375453472137e-02
    z[0,3,6]  R415      -1.0789953172206879e-01
    z[0,3,6]  R416      3.2823103666305542e-01
    z[0,3,6]  R417      1.5453889966011047e-01
    z[0,3,6]  R418      1.8215131759643555e-01
    z[0,3,6]  R419      -9.3076303601264954e-03
    z[0,3,6]  R420      1.8209001421928406e-01
    z[0,3,6]  R421      -1.2016330659389496e-01
    z[0,3,6]  R422      8.1099696457386017e-02
    z[0,3,6]  R423      -1.9036976993083954e-01
    z[0,3,6]  R424      3.7223890423774719e-01
    z[0,3,6]  R425      9.8171653226017952e-03
    z[0,3,6]  R426      -4.3109733611345291e-02
    z[0,3,6]  R427      -2.2044392302632332e-02
    z[0,3,6]  R428      -0.0145966662093997
    z[0,3,6]  R429      2.6133781671524048e-01
    z[0,3,6]  R430      -1.3080660998821259e-01
    z[0,3,6]  R431      -2.1050852537155151e-01
    z[0,3,6]  R432      -3.3424910902976990e-01
    z[0,3,6]  R433      -5.7147359848022461e-01
    z[0,3,6]  R434      3.5175263881683350e-01
    z[0,3,6]  R435      -5.1904983818531036e-02
    z[0,3,6]  R436      0.488119512796402
    z[0,3,6]  R437      -1.0014699399471283e-01
    z[0,3,6]  R438      -2.0374302566051483e-01
    z[0,3,6]  R439      -8.9272432029247284e-02
    z[0,3,6]  R440      -2.2940912842750549e-01
    z[0,3,6]  R441      -5.7690918445587158e-01
    z[0,3,6]  R442      -2.2818987071514130e-01
    z[0,3,6]  R443      1.9642080366611481e-01
    z[0,3,6]  R444      3.4517055749893188e-01
    z[0,3,6]  R445      2.0465636253356934e-01
    z[0,3,6]  R446      -1.7046001553535461e-01
    z[0,3,6]  R447      -3.1872513890266418e-01
    z[0,3,6]  R448      -5.1207724958658218e-02
    z[0,3,6]  R449      -3.2695299386978149e-01
    z[0,3,6]  R450      2.2473935782909393e-01
    z[0,3,6]  R451      -1.7372079193592072e-01
    z[0,3,6]  R452      8.6256787180900574e-02
    z[0,3,6]  R453      -3.9381444454193115e-02
    z[0,3,6]  R454      7.6236926019191742e-02
    z[0,3,6]  R455      -2.3633965849876404e-01
    z[0,3,6]  R456      3.9987966418266296e-01
    z[0,3,6]  R457      -1.7006626725196838e-01
    z[0,3,6]  R458      -3.1170496344566345e-01
    z[0,3,6]  R459      -3.5321542620658875e-01
    z[0,3,6]  R460      -2.2743065655231476e-01
    z[0,3,6]  R461      1.2947093928232789e-03
    z[0,3,6]  R462      2.2358534857630730e-02
    z[0,3,6]  R463      -2.0223094522953033e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R464      -1
    z[3,0,0]  R465      1
    z[3,0,0]  R478      -0.944106936454773
    z[3,0,0]  R479      -8.9444696903228760e-01
    z[3,0,0]  R480      -8.8479697704315186e-01
    z[3,0,0]  R481      -8.3608752489089966e-01
    z[3,0,0]  R482      -7.4958759546279907e-01
    z[3,0,0]  R483      -6.0549592971801758e-01
    z[3,0,0]  R484      8.9866951107978821e-02
    z[3,0,0]  R485      -1.5696670114994049e-01
    z[3,0,0]  R486      4.4755467772483826e-01
    z[3,0,0]  R487      3.8049522042274475e-01
    z[3,0,0]  R488      2.2003683447837830e-01
    z[3,0,0]  R489      2.8103478252887726e-02
    z[3,0,0]  R490      2.6788082718849182e-01
    z[3,0,0]  R491      4.0804773569107056e-01
    z[3,0,0]  R492      7.6667505502700806e-01
    z[3,0,0]  R493      0.556808590888977
    z[3,0,0]  R494      4.4196322560310364e-01
    z[3,0,0]  R495      3.7991029024124146e-01
    z[3,0,0]  R496      3.3493974804878235e-01
    z[3,0,0]  R497      2.6604282855987549e-01
    z[3,0,0]  R498      -1.7396806180477142e-01
    z[3,0,0]  R499      7.4199743568897247e-02
    z[3,0,0]  R500      -2.5420048832893372e-01
    z[3,0,0]  R501      2.0277349278330803e-02
    z[3,0,0]  R502      -1.5550833940505981e-01
    z[3,0,0]  R503      1.4069461822509766e-01
    z[3,0,0]  R504      1.8428291380405426e-01
    z[3,0,0]  R505      7.2697833180427551e-02
    z[3,0,0]  R506      6.1067931354045868e-02
    z[3,0,0]  R507      -1.0487715899944305e-01
    z[3,0,0]  R508      -4.9134048819541931e-01
    z[3,0,0]  R509      -4.0034279227256775e-01
    z[3,0,0]  R510      -5.8334946632385254e-01
    z[3,0,0]  R511      -3.3326229453086853e-01
    z[3,0,0]  R512      -3.1065317988395691e-01
    z[3,0,0]  R513      -1.7757639288902283e-01
    z[3,0,0]  R514      5.4894924163818359e-01
    z[3,0,0]  R515      -2.0485103130340576e-01
    z[3,0,0]  R516      -3.8280868530273438e-01
    z[3,0,0]  R517      -5.7402960956096649e-02
    z[3,0,0]  R518      -0.668807327747345
    z[3,0,0]  R519      -4.1047197580337524e-01
    z[3,0,0]  R520      -6.2148553133010864e-01
    z[3,0,0]  R521      3.4815111756324768e-01
    z[3,0,0]  R522      -1.1442486941814423e-01
    z[3,0,0]  R523      -9.2298634350299835e-02
    z[3,0,0]  R524      -2.4793858826160431e-01
    z[3,0,0]  R525      1.5128245949745178e-01
    z[3,0,0]  R526      7.7955538034439087e-01
    z[3,0,0]  R527      8.5126173496246338e-01
    z[3,0,0]  R528      -8.6556434631347656e-01
    z[3,0,0]  R529      -4.1236069053411484e-02
    z[3,0,0]  R530      1.0510524362325668e-01
    z[3,0,0]  R531      8.8532008230686188e-02
    z[3,0,0]  R532      -7.9787355661392212e-01
    z[3,0,0]  R533      -7.5574278831481934e-01
    z[3,0,0]  R534      -7.5591254234313965e-01
    z[3,0,0]  R535      1.4318588376045227e-01
    z[3,0,0]  R536      1.8367926776409149e-01
    z[3,0,0]  R537      -1.3492894172668457e-01
    z[3,0,0]  R538      1.0312058776617050e-01
    z[3,0,0]  R539      1.4673198759555817e-01
    z[3,0,0]  R540      -3.2835164666175842e-01
    z[3,0,0]  R541      -6.2497153878211975e-02
    z[3,0,0]  R542      0.575777530670166
    z[3,0,0]  R543      1.7961759865283966e-01
    z[3,0,0]  R544      2.9430544376373291e-01
    z[3,0,0]  R545      1.4689160883426666e-01
    z[3,0,0]  R546      2.3537835478782654e-01
    z[3,0,0]  R547      1.6539818048477173e-01
    z[3,0,0]  R548      -1.1978947371244431e-01
    z[3,0,0]  R549      -2.1345306932926178e-01
    z[3,0,0]  R550      5.0198280811309814e-01
    z[3,0,0]  R551      6.5568894147872925e-02
    z[3,0,0]  R552      -1.6261696815490723e-01
    z[3,0,0]  R553      3.1055265665054321e-01
    z[3,0,0]  R554      -2.0735581219196320e-01
    z[3,0,0]  R555      6.8226224184036255e-01
    z[3,0,0]  R556      6.6444432735443115e-01
    z[3,0,0]  R557      0.780838668346405
    z[3,0,0]  R558      -3.7238067388534546e-01
    z[3,0,0]  R559      1.6116203367710114e-01
    z[3,0,0]  R560      -4.0826341509819031e-01
    z[3,0,0]  R561      -3.4886884689331055e-01
    z[3,0,0]  R562      -9.6671558916568756e-02
    z[3,0,0]  R563      3.0254465341567993e-01
    z[3,0,0]  R564      -2.9394960403442383e-01
    z[3,0,0]  R565      4.2535030841827393e-01
    z[3,0,0]  R566      2.7053418755531311e-01
    z[3,0,0]  R567      -1.4853386580944061e-01
    z[3,0,0]  R568      -6.4769279956817627e-01
    z[3,0,0]  R569      -6.1156213283538818e-01
    z[3,0,0]  R570      -3.8871932029724121e-01
    z[3,0,0]  R571      -1.3857544958591461e-01
    z[3,0,0]  R572      -1.3292810320854187e-01
    z[3,0,0]  R573      2.0611186325550079e-01
    z[3,0,0]  R574      -1.3159725069999695e-01
    z[3,0,0]  R575      5.4140859842300415e-01
    z[3,0,0]  R576      8.4151971340179443e-01
    z[3,0,0]  R577      -4.2333474755287170e-01
    z[3,0,0]  R578      4.0024355053901672e-01
    z[3,0,0]  R579      -1.3610808551311493e-01
    z[3,0,0]  R580      0.00855422206223011
    z[3,0,0]  R581      7.7543449401855469e-01
    z[3,0,0]  R582      -4.4643476605415344e-02
    z[3,0,0]  R583      -4.1574668884277344e-01
    z[3,0,0]  R584      8.0693048238754272e-01
    z[3,0,0]  R585      -2.6147079467773438e-01
    z[3,0,0]  R586      5.6743097305297852e-01
    z[3,0,0]  R587      -1.3485701382160187e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R466      -1
    z[3,0,1]  R467      1
    z[3,0,1]  R478      -1.4133305847644806e-01
    z[3,0,1]  R479      3.1024524569511414e-01
    z[3,0,1]  R480      -7.7348113059997559e-02
    z[3,0,1]  R481      -2.5451722741127014e-01
    z[3,0,1]  R482      -3.5656234622001648e-01
    z[3,0,1]  R483      -1.1910539120435715e-01
    z[3,0,1]  R484      8.5235631465911865e-01
    z[3,0,1]  R485      0.825688362121582
    z[3,0,1]  R486      8.4348762035369873e-01
    z[3,0,1]  R487      8.3468645811080933e-01
    z[3,0,1]  R488      -8.1150442361831665e-01
    z[3,0,1]  R489      -5.7987397909164429e-01
    z[3,0,1]  R490      -6.5155172348022461e-01
    z[3,0,1]  R491      -6.5436708927154541e-01
    z[3,0,1]  R492      -3.1652554869651794e-01
    z[3,0,1]  R493      -3.0074384808540344e-01
    z[3,0,1]  R494      -4.0133380889892578e-01
    z[3,0,1]  R495      -2.6648142933845520e-01
    z[3,0,1]  R496      -4.2979344725608826e-01
    z[3,0,1]  R497      -2.3862951993942261e-01
    z[3,0,1]  R498      1.6371791064739227e-01
    z[3,0,1]  R499      1.5403643250465393e-01
    z[3,0,1]  R500      -1.1247289367020130e-02
    z[3,0,1]  R501      1.7395548522472382e-01
    z[3,0,1]  R502      -6.5469431877136230e-01
    z[3,0,1]  R503      -8.2501769065856934e-02
    z[3,0,1]  R504      -5.5584597587585449e-01
    z[3,0,1]  R505      6.4218886196613312e-02
    z[3,0,1]  R506      -3.2696792483329773e-01
    z[3,0,1]  R507      4.2401787638664246e-01
    z[3,0,1]  R508      2.6551276445388794e-01
    z[3,0,1]  R509      -5.3360808640718460e-02
    z[3,0,1]  R510      -6.0729876160621643e-02
    z[3,0,1]  R511      -2.1936267614364624e-01
    z[3,0,1]  R512      5.2177053689956665e-01
    z[3,0,1]  R513      -2.4402105808258057e-01
    z[3,0,1]  R514      -7.2244131565093994e-01
    z[3,0,1]  R515      -1.3527034223079681e-01
    z[3,0,1]  R516      2.3988784849643707e-01
    z[3,0,1]  R517      -8.2922744750976562e-01
    z[3,0,1]  R518      -3.0286094546318054e-01
    z[3,0,1]  R519      -3.9802485704421997e-01
    z[3,0,1]  R520      5.1660817861557007e-01
    z[3,0,1]  R521      -6.8225634098052979e-01
    z[3,0,1]  R522      -5.0074762105941772e-01
    z[3,0,1]  R523      -0.630085289478302
    z[3,0,1]  R524      -3.1725892424583435e-01
    z[3,0,1]  R525      -4.0940544009208679e-01
    z[3,0,1]  R526      2.0677064359188080e-01
    z[3,0,1]  R527      1.3145956397056580e-01
    z[3,0,1]  R528      3.4495043754577637e-01
    z[3,0,1]  R529      -4.9976086616516113e-01
    z[3,0,1]  R530      -4.7554585337638855e-01
    z[3,0,1]  R531      -6.7512750625610352e-01
    z[3,0,1]  R532      -1.7502070963382721e-01
    z[3,0,1]  R533      -2.4693377315998077e-01
    z[3,0,1]  R534      -1.1827751249074936e-01
    z[3,0,1]  R535      -5.5128842592239380e-01
    z[3,0,1]  R536      1.1151216179132462e-01
    z[3,0,1]  R537      -2.7934971451759338e-01
    z[3,0,1]  R538      -8.5020369291305542e-01
    z[3,0,1]  R539      -5.9273320436477661e-01
    z[3,0,1]  R540      -5.1442635059356689e-01
    z[3,0,1]  R541      -3.3093014359474182e-01
    z[3,0,1]  R542      -3.5620692372322083e-01
    z[3,0,1]  R543      2.3276938498020172e-01
    z[3,0,1]  R544      4.7947758436203003e-01
    z[3,0,1]  R545      4.0138053894042969e-01
    z[3,0,1]  R546      9.1129429638385773e-02
    z[3,0,1]  R547      6.3216572999954224e-01
    z[3,0,1]  R548      -8.8463604450225830e-02
    z[3,0,1]  R549      -5.3806287050247192e-01
    z[3,0,1]  R550      -6.6432762145996094e-01
    z[3,0,1]  R551      -7.2125440835952759e-01
    z[3,0,1]  R552      -2.6211544871330261e-01
    z[3,0,1]  R553      -0.501920759677887
    z[3,0,1]  R554      2.0636498928070068e-02
    z[3,0,1]  R555      3.3570915460586548e-01
    z[3,0,1]  R556      1.0734263807535172e-01
    z[3,0,1]  R557      6.6693723201751709e-02
    z[3,0,1]  R558      2.9823088645935059e-01
    z[3,0,1]  R559      -7.5452917814254761e-01
    z[3,0,1]  R560      -3.2540559768676758e-01
    z[3,0,1]  R561      -5.0323939323425293e-01
    z[3,0,1]  R562      -7.5589370727539062e-01
    z[3,0,1]  R563      -0.687433660030365
    z[3,0,1]  R564      -3.8846787810325623e-01
    z[3,0,1]  R565      -3.9844623208045959e-01
    z[3,0,1]  R566      -3.2046353816986084e-01
    z[3,0,1]  R567      -2.0761089026927948e-01
    z[3,0,1]  R568      -4.3487891554832458e-01
    z[3,0,1]  R569      -7.4214714765548706e-01
    z[3,0,1]  R570      -5.5393588542938232e-01
    z[3,0,1]  R571      3.2467627525329590e-01
    z[3,0,1]  R572      -6.2469649314880371e-01
    z[3,0,1]  R573      -1.2720146775245667e-01
    z[3,0,1]  R574      -2.3071397840976715e-01
    z[3,0,1]  R575      3.4664157032966614e-01
    z[3,0,1]  R576      7.2865389287471771e-02
    z[3,0,1]  R577      -3.5707134008407593e-01
    z[3,0,1]  R578      -3.9317104220390320e-01
    z[3,0,1]  R579      -2.7948483824729919e-01
    z[3,0,1]  R580      1.3539044186472893e-02
    z[3,0,1]  R581      0.156547412276268
    z[3,0,1]  R582      -1.3347235508263111e-02
    z[3,0,1]  R583      -3.4653863310813904e-01
    z[3,0,1]  R584      -2.4881218373775482e-01
    z[3,0,1]  R585      7.2614312171936035e-01
    z[3,0,1]  R586      -5.4835790395736694e-01
    z[3,0,1]  R587      7.5021088123321533e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R468      -1
    z[3,0,2]  R469      1
    z[3,0,2]  R478      3.1066054478287697e-02
    z[3,0,2]  R479      -2.8208622243255377e-03
    z[3,0,2]  R480      -6.7019328474998474e-02
    z[3,0,2]  R481      1.4348384737968445e-01
    z[3,0,2]  R482      2.6731422543525696e-01
    z[3,0,2]  R483      -8.3356760442256927e-02
    z[3,0,2]  R484      -5.5839867854956537e-05
    z[3,0,2]  R485      1.4025759696960449e-01
    z[3,0,2]  R486      1.1999390274286270e-01
    z[3,0,2]  R487      1.0017056018114090e-02
    z[3,0,2]  R488      -1.1276292800903320e-01
    z[3,0,2]  R489      -2.7658042311668396e-01
    z[3,0,2]  R490      3.2855155877768993e-03
    z[3,0,2]  R491      -4.0102750062942505e-02
    z[3,0,2]  R492      -1.1400407552719116e-01
    z[3,0,2]  R493      -1.6668376326560974e-01
    z[3,0,2]  R494      1.4053578674793243e-01
    z[3,0,2]  R495      2.3021285235881805e-01
    z[3,0,2]  R496      -1.4832855761051178e-01
    z[3,0,2]  R497      1.3894286751747131e-01
    z[3,0,2]  R498      -8.0853068828582764e-01
    z[3,0,2]  R499      -8.9067792892456055e-01
    z[3,0,2]  R500      -4.1614410281181335e-01
    z[3,0,2]  R501      -4.1055321693420410e-01
    z[3,0,2]  R502      5.7632780075073242e-01
    z[3,0,2]  R503      -7.0586651563644409e-01
    z[3,0,2]  R504      -2.3154844343662262e-01
    z[3,0,2]  R505      5.5463171005249023e-01
    z[3,0,2]  R506      -4.2904245853424072e-01
    z[3,0,2]  R507      1.9134703278541565e-01
    z[3,0,2]  R508      -5.7128328084945679e-01
    z[3,0,2]  R509      -3.7148031592369080e-01
    z[3,0,2]  R510      -5.6626230478286743e-01
    z[3,0,2]  R511      -5.5301815271377563e-01
    z[3,0,2]  R512      -5.7177132368087769e-01
    z[3,0,2]  R513      -4.0159627795219421e-01
    z[3,0,2]  R514      -1.7308506369590759e-01
    z[3,0,2]  R515      -3.7613001465797424e-01
    z[3,0,2]  R516      -0.646323025226593
    z[3,0,2]  R517      4.9229413270950317e-01
    z[3,0,2]  R518      -7.6841311529278755e-03
    z[3,0,2]  R519      -7.0883341133594513e-02
    z[3,0,2]  R520      -3.2401564717292786e-01
    z[3,0,2]  R521      -4.4205355644226074e-01
    z[3,0,2]  R522      -3.5247129201889038e-01
    z[3,0,2]  R523      1.5784873068332672e-01
    z[3,0,2]  R524      -5.9990704059600830e-01
    z[3,0,2]  R525      -7.1209657192230225e-01
    z[3,0,2]  R526      1.3143076002597809e-01
    z[3,0,2]  R527      -2.8840396553277969e-02
    z[3,0,2]  R528      2.7621725574135780e-02
    z[3,0,2]  R529      7.3466020822525024e-01
    z[3,0,2]  R530      6.8202590942382812e-01
    z[3,0,2]  R531      4.5618841052055359e-01
    z[3,0,2]  R532      -0.0845438539981842
    z[3,0,2]  R533      -0.0838879719376564
    z[3,0,2]  R534      -8.3456777036190033e-02
    z[3,0,2]  R535      6.6848099231719971e-01
    z[3,0,2]  R536      4.7175869345664978e-01
    z[3,0,2]  R537      6.5274572372436523e-01
    z[3,0,2]  R538      -3.9539617300033569e-01
    z[3,0,2]  R539      -5.1124978065490723e-01
    z[3,0,2]  R540      -2.8793439269065857e-01
    z[3,0,2]  R541      -2.7269563078880310e-01
    z[3,0,2]  R542      -3.3951789140701294e-01
    z[3,0,2]  R543      -6.9787585735321045e-01
    z[3,0,2]  R544      -6.5587985515594482e-01
    z[3,0,2]  R545      -8.2782596349716187e-01
    z[3,0,2]  R546      -5.7603049278259277e-01
    z[3,0,2]  R547      -6.3554090261459351e-01
    z[3,0,2]  R548      -6.6490036249160767e-01
    z[3,0,2]  R549      -3.2557302713394165e-01
    z[3,0,2]  R550      -1.1641083657741547e-01
    z[3,0,2]  R551      2.1482974290847778e-01
    z[3,0,2]  R552      8.1824511289596558e-02
    z[3,0,2]  R553      1.4156261086463928e-01
    z[3,0,2]  R554      -5.0084173679351807e-02
    z[3,0,2]  R555      -6.5664090216159821e-02
    z[3,0,2]  R556      3.1432278454303741e-02
    z[3,0,2]  R557      -2.5956818461418152e-01
    z[3,0,2]  R558      -7.7168178558349609e-01
    z[3,0,2]  R559      -2.0968298614025116e-01
    z[3,0,2]  R560      -1.9802008569240570e-01
    z[3,0,2]  R561      -4.7668609023094177e-01
    z[3,0,2]  R562      1.9084939360618591e-01
    z[3,0,2]  R563      2.7320548892021179e-01
    z[3,0,2]  R564      -2.9504847526550293e-01
    z[3,0,2]  R565      -1.9627763330936432e-01
    z[3,0,2]  R566      -1.3070015609264374e-01
    z[3,0,2]  R567      -2.6683833450078964e-02
    z[3,0,2]  R568      -4.4522222876548767e-01
    z[3,0,2]  R569      -1.1112175136804581e-01
    z[3,0,2]  R570      -2.4236644804477692e-01
    z[3,0,2]  R571      -6.1946034431457520e-01
    z[3,0,2]  R572      2.7883926033973694e-01
    z[3,0,2]  R573      -6.6978245973587036e-01
    z[3,0,2]  R574      -6.2185734510421753e-02
    z[3,0,2]  R575      -7.4284210801124573e-02
    z[3,0,2]  R576      -1.0192904621362686e-01
    z[3,0,2]  R577      5.8484065532684326e-01
    z[3,0,2]  R578      -3.4029707312583923e-01
    z[3,0,2]  R579      -7.9746223986148834e-02
    z[3,0,2]  R580      -6.2350231409072876e-01
    z[3,0,2]  R581      -3.8162497803568840e-03
    z[3,0,2]  R582      -1.1624182574450970e-02
    z[3,0,2]  R583      0.644105076789856
    z[3,0,2]  R584      1.5265475213527679e-01
    z[3,0,2]  R585      -3.2871926669031382e-03
    z[3,0,2]  R586      -0.286289244890213
    z[3,0,2]  R587      1.9715599715709686e-01
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R470      -1
    z[3,0,3]  R471      1
    z[3,0,3]  R478      -2.3871541023254395e-01
    z[3,0,3]  R479      -2.9863205552101135e-01
    z[3,0,3]  R480      -1.6798898577690125e-02
    z[3,0,3]  R481      -2.6354414224624634e-01
    z[3,0,3]  R482      -3.3292093873023987e-01
    z[3,0,3]  R483      -1.7964872717857361e-01
    z[3,0,3]  R484      -4.3329432606697083e-01
    z[3,0,3]  R485      4.7001048922538757e-01
    z[3,0,3]  R486      3.3752273768186569e-02
    z[3,0,3]  R487      -1.3107106089591980e-01
    z[3,0,3]  R488      3.4038993716239929e-01
    z[3,0,3]  R489      7.3964673280715942e-01
    z[3,0,3]  R490      5.3205049037933350e-01
    z[3,0,3]  R491      2.7089712023735046e-01
    z[3,0,3]  R492      2.5936564803123474e-01
    z[3,0,3]  R493      4.3587756156921387e-01
    z[3,0,3]  R494      -7.3502779006958008e-01
    z[3,0,3]  R495      -7.5853610038757324e-01
    z[3,0,3]  R496      -7.4429786205291748e-01
    z[3,0,3]  R497      -6.6490846872329712e-01
    z[3,0,3]  R498      -2.3528985679149628e-01
    z[3,0,3]  R499      -4.0259385108947754e-01
    z[3,0,3]  R500      -1.9214524328708649e-01
    z[3,0,3]  R501      -4.7693881392478943e-01
    z[3,0,3]  R502      1.9922161102294922e-01
    z[3,0,3]  R503      -1.2619754672050476e-01
    z[3,0,3]  R504      -3.2596865296363831e-01
    z[3,0,3]  R505      -5.2830260992050171e-01
    z[3,0,3]  R506      -2.3884449899196625e-01
    z[3,0,3]  R507      1.5330067276954651e-01
    z[3,0,3]  R508      -1.3977591693401337e-01
    z[3,0,3]  R509      -5.2640640735626221e-01
    z[3,0,3]  R510      1.1290020495653152e-01
    z[3,0,3]  R511      -3.5654491186141968e-01
    z[3,0,3]  R512      -0.0711822658777237
    z[3,0,3]  R513      -0.726284384727478
    z[3,0,3]  R514      8.2584097981452942e-02
    z[3,0,3]  R515      -7.2395765781402588e-01
    z[3,0,3]  R516      2.3945966362953186e-01
    z[3,0,3]  R517      5.5998995900154114e-02
    z[3,0,3]  R518      -5.6604892015457153e-01
    z[3,0,3]  R519      -7.7647775411605835e-01
    z[3,0,3]  R520      2.5465661287307739e-01
    z[3,0,3]  R521      -1.8583337962627411e-01
    z[3,0,3]  R522      5.5111092329025269e-01
    z[3,0,3]  R523      2.2040309011936188e-01
    z[3,0,3]  R524      4.0116113424301147e-01
    z[3,0,3]  R525      -1.0231083631515503e-01
    z[3,0,3]  R526      5.5638146400451660e-01
    z[3,0,3]  R527      2.8883364796638489e-01
    z[3,0,3]  R528      -3.5168325901031494e-01
    z[3,0,3]  R529      -3.1265783309936523e-01
    z[3,0,3]  R530      -2.9012054204940796e-01
    z[3,0,3]  R531      -4.4434544444084167e-01
    z[3,0,3]  R532      -6.9123253226280212e-02
    z[3,0,3]  R533      -1.6010272502899170e-01
    z[3,0,3]  R534      -6.1893612146377563e-03
    z[3,0,3]  R535      4.2321330308914185e-01
    z[3,0,3]  R536      -3.2259920239448547e-01
    z[3,0,3]  R537      2.7095075696706772e-02
    z[3,0,3]  R538      1.9906303286552429e-01
    z[3,0,3]  R539      9.8733194172382355e-02
    z[3,0,3]  R540      2.7285942435264587e-01
    z[3,0,3]  R541      1.3957878947257996e-01
    z[3,0,3]  R542      1.2894868850708008e-01
    z[3,0,3]  R543      -3.2551360130310059e-01
    z[3,0,3]  R544      -3.4541919827461243e-01
    z[3,0,3]  R545      -3.1703576445579529e-01
    z[3,0,3]  R546      -6.7687761783599854e-01
    z[3,0,3]  R547      6.3811734318733215e-02
    z[3,0,3]  R548      -4.9727335572242737e-01
    z[3,0,3]  R549      -5.6930756568908691e-01
    z[3,0,3]  R550      -1.3958480954170227e-01
    z[3,0,3]  R551      -5.4697811603546143e-01
    z[3,0,3]  R552      0.805844783782959
    z[3,0,3]  R553      -4.9574910663068295e-03
    z[3,0,3]  R554      -6.2206178903579712e-01
    z[3,0,3]  R555      5.2626281976699829e-01
    z[3,0,3]  R556      5.6888228654861450e-01
    z[3,0,3]  R557      4.4461691379547119e-01
    z[3,0,3]  R558      -1.0837078839540482e-01
    z[3,0,3]  R559      4.5038022100925446e-02
    z[3,0,3]  R560      -4.1925823688507080e-01
    z[3,0,3]  R561      -1.5297304093837738e-01
    z[3,0,3]  R562      -4.0619823336601257e-01
    z[3,0,3]  R563      1.5630979090929031e-02
    z[3,0,3]  R564      -6.4796352386474609e-01
    z[3,0,3]  R565      2.3813745379447937e-01
    z[3,0,3]  R566      7.2073060274124146e-01
    z[3,0,3]  R567      6.2681853771209717e-01
    z[3,0,3]  R568      6.4228519797325134e-02
    z[3,0,3]  R569      -1.3735200464725494e-01
    z[3,0,3]  R570      4.4287565350532532e-01
    z[3,0,3]  R571      -4.1826283931732178e-01
    z[3,0,3]  R572      3.7058338522911072e-01
    z[3,0,3]  R573      3.4639132022857666e-01
    z[3,0,3]  R574      8.5716533660888672e-01
    z[3,0,3]  R575      6.5562093257904053e-01
    z[3,0,3]  R576      3.0329120159149170e-01
    z[3,0,3]  R577      -2.0099332928657532e-01
    z[3,0,3]  R578      1.7543128132820129e-01
    z[3,0,3]  R579      6.7784392833709717e-01
    z[3,0,3]  R580      0.71389240026474
    z[3,0,3]  R581      3.9879637956619263e-01
    z[3,0,3]  R582      -7.6556110382080078e-01
    z[3,0,3]  R583      -2.1251289546489716e-01
    z[3,0,3]  R584      5.0486225634813309e-02
    z[3,0,3]  R585      4.8082742094993591e-01
    z[3,0,3]  R586      -0.0451047383248806
    z[3,0,3]  R587      4.3817591667175293e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R472      -1
    z[3,0,4]  R473      1
    z[3,0,4]  R478      1.6339996457099915e-01
    z[3,0,4]  R479      -5.2320018410682678e-02
    z[3,0,4]  R480      -2.7691149711608887e-01
    z[3,0,4]  R481      -3.3400258421897888e-01
    z[3,0,4]  R482      3.0865228176116943e-01
    z[3,0,4]  R483      2.8320398926734924e-01
    z[3,0,4]  R484      2.0661781728267670e-01
    z[3,0,4]  R485      -1.7275722324848175e-01
    z[3,0,4]  R486      -6.0702469199895859e-02
    z[3,0,4]  R487      2.2721193730831146e-01
    z[3,0,4]  R488      -1.2641771696507931e-02
    z[3,0,4]  R489      -1.3777954876422882e-01
    z[3,0,4]  R490      -4.0162146091461182e-01
    z[3,0,4]  R491      -5.1921719312667847e-01
    z[3,0,4]  R492      1.8441526591777802e-01
    z[3,0,4]  R493      0.0917959213256836
    z[3,0,4]  R494      -2.2069972753524780e-01
    z[3,0,4]  R495      -2.4616606533527374e-01
    z[3,0,4]  R496      4.3175943195819855e-02
    z[3,0,4]  R497      -2.7231946587562561e-01
    z[3,0,4]  R498      1.4991672337055206e-01
    z[3,0,4]  R499      7.3038570582866669e-02
    z[3,0,4]  R500      1.2004748731851578e-01
    z[3,0,4]  R501      -1.6610343754291534e-01
    z[3,0,4]  R502      7.4635609984397888e-02
    z[3,0,4]  R503      -3.2716533541679382e-01
    z[3,0,4]  R504      -5.2616512775421143e-01
    z[3,0,4]  R505      -5.2414391189813614e-02
    z[3,0,4]  R506      7.6712578535079956e-01
    z[3,0,4]  R507      7.2057497501373291e-01
    z[3,0,4]  R508      -2.1359895169734955e-01
    z[3,0,4]  R509      2.2223877906799316e-01
    z[3,0,4]  R510      -0.164543017745018
    z[3,0,4]  R511      -3.8728281855583191e-01
    z[3,0,4]  R512      3.3666431903839111e-01
    z[3,0,4]  R513      -3.3305177092552185e-01
    z[3,0,4]  R514      7.8389182686805725e-02
    z[3,0,4]  R515      4.9128594994544983e-01
    z[3,0,4]  R516      5.0390070676803589e-01
    z[3,0,4]  R517      -2.4160590767860413e-01
    z[3,0,4]  R518      3.5600054264068604e-01
    z[3,0,4]  R519      3.9648368954658508e-02
    z[3,0,4]  R520      1.3042362034320831e-01
    z[3,0,4]  R521      -3.2231798768043518e-01
    z[3,0,4]  R522      3.4890845417976379e-01
    z[3,0,4]  R523      5.7207494974136353e-01
    z[3,0,4]  R524      4.8841181397438049e-01
    z[3,0,4]  R525      0.535327136516571
    z[3,0,4]  R526      -0.0871153250336647
    z[3,0,4]  R527      -3.4129226207733154e-01
    z[3,0,4]  R528      -6.6957190632820129e-02
    z[3,0,4]  R529      2.1465896070003510e-01
    z[3,0,4]  R530      2.7437087893486023e-01
    z[3,0,4]  R531      6.2506482005119324e-02
    z[3,0,4]  R532      3.9351871609687805e-01
    z[3,0,4]  R533      0.422784686088562
    z[3,0,4]  R534      2.4455915391445160e-01
    z[3,0,4]  R535      -1.3691918551921844e-01
    z[3,0,4]  R536      -5.9453827142715454e-01
    z[3,0,4]  R537      -6.2357103824615479e-01
    z[3,0,4]  R538      2.1007342636585236e-01
    z[3,0,4]  R539      5.6166488677263260e-02
    z[3,0,4]  R540      -6.3911330699920654e-01
    z[3,0,4]  R541      -7.8037220239639282e-01
    z[3,0,4]  R542      -5.7170045375823975e-01
    z[3,0,4]  R543      -1.2757124379277229e-02
    z[3,0,4]  R544      -3.5243952274322510e-01
    z[3,0,4]  R545      -1.1243198066949844e-01
    z[3,0,4]  R546      -3.2792448997497559e-01
    z[3,0,4]  R547      -5.1740769296884537e-02
    z[3,0,4]  R548      -4.2554304003715515e-01
    z[3,0,4]  R549      -3.4818568825721741e-01
    z[3,0,4]  R550      -3.9911502599716187e-01
    z[3,0,4]  R551      -2.4722869694232941e-01
    z[3,0,4]  R552      -2.5145837664604187e-01
    z[3,0,4]  R553      -3.9427399635314941e-01
    z[3,0,4]  R554      3.0580586194992065e-01
    z[3,0,4]  R555      6.5072283148765564e-02
    z[3,0,4]  R556      -1.2051870115101337e-02
    z[3,0,4]  R557      2.4295248091220856e-01
    z[3,0,4]  R558      1.1104691773653030e-01
    z[3,0,4]  R559      -2.9548043012619019e-01
    z[3,0,4]  R560      3.9793637394905090e-01
    z[3,0,4]  R561      -0.35687056183815
    z[3,0,4]  R562      -1.3751165568828583e-01
    z[3,0,4]  R563      -4.9464112520217896e-01
    z[3,0,4]  R564      4.0702825784683228e-01
    z[3,0,4]  R565      -4.1676875948905945e-01
    z[3,0,4]  R566      -3.2262614369392395e-01
    z[3,0,4]  R567      -1.8061390519142151e-01
    z[3,0,4]  R568      -2.9686695337295532e-01
    z[3,0,4]  R569      -7.1076206862926483e-02
    z[3,0,4]  R570      -2.4156036972999573e-01
    z[3,0,4]  R571      -2.0897619426250458e-02
    z[3,0,4]  R572      1.0163921862840652e-01
    z[3,0,4]  R573      -5.3750729560852051e-01
    z[3,0,4]  R574      3.0570149421691895e-01
    z[3,0,4]  R575      7.2318062186241150e-02
    z[3,0,4]  R576      -3.7874445319175720e-01
    z[3,0,4]  R577      5.9320259839296341e-02
    z[3,0,4]  R578      -4.6008464694023132e-01
    z[3,0,4]  R579      5.8294606208801270e-01
    z[3,0,4]  R580      -0.0536101870238781
    z[3,0,4]  R581      -4.6203276515007019e-01
    z[3,0,4]  R582      -3.6614328622817993e-01
    z[3,0,4]  R583      2.5582334399223328e-01
    z[3,0,4]  R584      -1.3138620555400848e-01
    z[3,0,4]  R585      2.2937799990177155e-01
    z[3,0,4]  R586      5.2642589807510376e-01
    z[3,0,4]  R587      -3.5246974229812622e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R474      -1
    z[3,0,5]  R475      1
    z[3,0,5]  R478      -4.1141159832477570e-02
    z[3,0,5]  R479      -1.1985564604401588e-02
    z[3,0,5]  R480      1.4819647371768951e-01
    z[3,0,5]  R481      -1.0341908782720566e-01
    z[3,0,5]  R482      -1.5589644201099873e-02
    z[3,0,5]  R483      7.0687723159790039e-01
    z[3,0,5]  R484      -4.2672500014305115e-02
    z[3,0,5]  R485      9.3455202877521515e-02
    z[3,0,5]  R486      -2.4984742701053619e-01
    z[3,0,5]  R487      2.3103237152099609e-01
    z[3,0,5]  R488      -1.6044294834136963e-01
    z[3,0,5]  R489      1.4248742163181305e-01
    z[3,0,5]  R490      2.3973587155342102e-01
    z[3,0,5]  R491      -2.4542784690856934e-01
    z[3,0,5]  R492      4.4444516301155090e-01
    z[3,0,5]  R493      5.5228674411773682e-01
    z[3,0,5]  R494      1.3328480720520020e-01
    z[3,0,5]  R495      -2.2664764523506165e-01
    z[3,0,5]  R496      1.1630005389451981e-01
    z[3,0,5]  R497      1.0064236819744110e-01
    z[3,0,5]  R498      -2.9604652523994446e-01
    z[3,0,5]  R499      -8.5728786885738373e-02
    z[3,0,5]  R500      -6.8737751245498657e-01
    z[3,0,5]  R501      -7.3190432786941528e-01
    z[3,0,5]  R502      -3.5814478993415833e-01
    z[3,0,5]  R503      5.8670127391815186e-01
    z[3,0,5]  R504      4.0954446792602539e-01
    z[3,0,5]  R505      -2.6134172081947327e-01
    z[3,0,5]  R506      -0.087669737637043
    z[3,0,5]  R507      -4.3736183643341064e-01
    z[3,0,5]  R508      -4.2121067643165588e-01
    z[3,0,5]  R509      -0.574893593788147
    z[3,0,5]  R510      -5.1622176170349121e-01
    z[3,0,5]  R511      3.9533430337905884e-01
    z[3,0,5]  R512      4.2813035845756531e-01
    z[3,0,5]  R513      -4.8270203173160553e-02
    z[3,0,5]  R514      2.8862106800079346e-01
    z[3,0,5]  R515      -5.1075357943773270e-02
    z[3,0,5]  R516      -2.4388688802719116e-01
    z[3,0,5]  R517      6.0606010258197784e-02
    z[3,0,5]  R518      -8.9180164039134979e-02
    z[3,0,5]  R519      -0.0878542810678482
    z[3,0,5]  R520      1.1024557054042816e-02
    z[3,0,5]  R521      -2.2485619783401489e-01
    z[3,0,5]  R522      -2.9883494973182678e-01
    z[3,0,5]  R523      2.6258125901222229e-01
    z[3,0,5]  R524      1.6365723311901093e-01
    z[3,0,5]  R525      7.3313899338245392e-02
    z[3,0,5]  R526      -1.2089667469263077e-01
    z[3,0,5]  R527      -1.2820911407470703e-01
    z[3,0,5]  R528      1.1650804430246353e-02
    z[3,0,5]  R529      -1.6273267567157745e-01
    z[3,0,5]  R530      -2.7441319823265076e-01
    z[3,0,5]  R531      -1.3563459739089012e-02
    z[3,0,5]  R532      -2.6757022738456726e-01
    z[3,0,5]  R533      3.4697356820106506e-01
    z[3,0,5]  R534      2.0508494973182678e-01
    z[3,0,5]  R535      3.3434204757213593e-02
    z[3,0,5]  R536      -5.0606679916381836e-01
    z[3,0,5]  R537      -1.7889726161956787e-01
    z[3,0,5]  R538      -1.6252931952476501e-01
    z[3,0,5]  R539      5.9391415119171143e-01
    z[3,0,5]  R540      -1.9189855456352234e-01
    z[3,0,5]  R541      4.2806863784790039e-01
    z[3,0,5]  R542      2.7523204684257507e-01
    z[3,0,5]  R543      -0.511264443397522
    z[3,0,5]  R544      -0.0551532544195652
    z[3,0,5]  R545      7.5839549303054810e-02
    z[3,0,5]  R546      -6.1982583254575729e-02
    z[3,0,5]  R547      -3.1618049740791321e-01
    z[3,0,5]  R548      -3.2758924365043640e-01
    z[3,0,5]  R549      3.7728220224380493e-02
    z[3,0,5]  R550      2.1341986954212189e-01
    z[3,0,5]  R551      -2.5816529989242554e-01
    z[3,0,5]  R552      3.8002288341522217e-01
    z[3,0,5]  R553      -5.1978421211242676e-01
    z[3,0,5]  R554      -4.6375676989555359e-01
    z[3,0,5]  R555      2.0037825405597687e-01
    z[3,0,5]  R556      4.2616373300552368e-01
    z[3,0,5]  R557      1.8339498341083527e-01
    z[3,0,5]  R558      3.3599036931991577e-01
    z[3,0,5]  R559      -1.5354098379611969e-01
    z[3,0,5]  R560      -2.2313885390758514e-01
    z[3,0,5]  R561      4.2628234624862671e-01
    z[3,0,5]  R562      -4.3180641531944275e-01
    z[3,0,5]  R563      -1.9204846024513245e-01
    z[3,0,5]  R564      -3.0016237497329712e-01
    z[3,0,5]  R565      4.5417442917823792e-01
    z[3,0,5]  R566      1.8342629075050354e-01
    z[3,0,5]  R567      5.6681233644485474e-01
    z[3,0,5]  R568      2.4742105603218079e-01
    z[3,0,5]  R569      1.1944817006587982e-01
    z[3,0,5]  R570      2.5705319643020630e-01
    z[3,0,5]  R571      -5.0330072641372681e-01
    z[3,0,5]  R572      1.1723132431507111e-01
    z[3,0,5]  R573      5.6994143873453140e-02
    z[3,0,5]  R574      2.7316540479660034e-01
    z[3,0,5]  R575      -3.4446594119071960e-01
    z[3,0,5]  R576      -2.0171286165714264e-01
    z[3,0,5]  R577      -5.5400699377059937e-01
    z[3,0,5]  R578      4.0052446722984314e-01
    z[3,0,5]  R579      3.0932599306106567e-01
    z[3,0,5]  R580      -4.4391206465661526e-03
    z[3,0,5]  R581      1.8181413412094116e-02
    z[3,0,5]  R582      -2.0574663579463959e-01
    z[3,0,5]  R583      -1.5640632808208466e-01
    z[3,0,5]  R584      -1.7433337867259979e-02
    z[3,0,5]  R585      -3.1434756517410278e-01
    z[3,0,5]  R586      1.5541951172053814e-02
    z[3,0,5]  R587      2.3965077102184296e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R476      -1
    z[3,0,6]  R477      1
    z[3,0,6]  R478      -4.8421375453472137e-02
    z[3,0,6]  R479      -1.0789953172206879e-01
    z[3,0,6]  R480      3.2823103666305542e-01
    z[3,0,6]  R481      1.5453889966011047e-01
    z[3,0,6]  R482      1.8215131759643555e-01
    z[3,0,6]  R483      -9.3076303601264954e-03
    z[3,0,6]  R484      1.8209001421928406e-01
    z[3,0,6]  R485      -1.2016330659389496e-01
    z[3,0,6]  R486      8.1099696457386017e-02
    z[3,0,6]  R487      -1.9036976993083954e-01
    z[3,0,6]  R488      3.7223890423774719e-01
    z[3,0,6]  R489      9.8171653226017952e-03
    z[3,0,6]  R490      -4.3109733611345291e-02
    z[3,0,6]  R491      -2.2044392302632332e-02
    z[3,0,6]  R492      -0.0145966662093997
    z[3,0,6]  R493      2.6133781671524048e-01
    z[3,0,6]  R494      -1.3080660998821259e-01
    z[3,0,6]  R495      -2.1050852537155151e-01
    z[3,0,6]  R496      -3.3424910902976990e-01
    z[3,0,6]  R497      -5.7147359848022461e-01
    z[3,0,6]  R498      3.5175263881683350e-01
    z[3,0,6]  R499      -5.1904983818531036e-02
    z[3,0,6]  R500      0.488119512796402
    z[3,0,6]  R501      -1.0014699399471283e-01
    z[3,0,6]  R502      -2.0374302566051483e-01
    z[3,0,6]  R503      -8.9272432029247284e-02
    z[3,0,6]  R504      -2.2940912842750549e-01
    z[3,0,6]  R505      -5.7690918445587158e-01
    z[3,0,6]  R506      -2.2818987071514130e-01
    z[3,0,6]  R507      1.9642080366611481e-01
    z[3,0,6]  R508      3.4517055749893188e-01
    z[3,0,6]  R509      2.0465636253356934e-01
    z[3,0,6]  R510      -1.7046001553535461e-01
    z[3,0,6]  R511      -3.1872513890266418e-01
    z[3,0,6]  R512      -5.1207724958658218e-02
    z[3,0,6]  R513      -3.2695299386978149e-01
    z[3,0,6]  R514      2.2473935782909393e-01
    z[3,0,6]  R515      -1.7372079193592072e-01
    z[3,0,6]  R516      8.6256787180900574e-02
    z[3,0,6]  R517      -3.9381444454193115e-02
    z[3,0,6]  R518      7.6236926019191742e-02
    z[3,0,6]  R519      -2.3633965849876404e-01
    z[3,0,6]  R520      3.9987966418266296e-01
    z[3,0,6]  R521      -1.7006626725196838e-01
    z[3,0,6]  R522      -3.1170496344566345e-01
    z[3,0,6]  R523      -3.5321542620658875e-01
    z[3,0,6]  R524      -2.2743065655231476e-01
    z[3,0,6]  R525      1.2947093928232789e-03
    z[3,0,6]  R526      2.2358534857630730e-02
    z[3,0,6]  R527      -2.0223094522953033e-01
    z[3,0,6]  R528      -5.2389286458492279e-02
    z[3,0,6]  R529      -1.9620814919471741e-01
    z[3,0,6]  R530      2.5079402327537537e-01
    z[3,0,6]  R531      3.5598197579383850e-01
    z[3,0,6]  R532      3.0722799897193909e-01
    z[3,0,6]  R533      1.8991814553737640e-01
    z[3,0,6]  R534      5.5293250083923340e-01
    z[3,0,6]  R535      1.7244604229927063e-01
    z[3,0,6]  R536      0.132745161652565
    z[3,0,6]  R537      2.3685809969902039e-01
    z[3,0,6]  R538      -3.0023558065295219e-03
    z[3,0,6]  R539      -1.1126353405416012e-02
    z[3,0,6]  R540      -1.5780167281627655e-01
    z[3,0,6]  R541      2.2599419578909874e-02
    z[3,0,6]  R542      8.4277898073196411e-02
    z[3,0,6]  R543      2.4292401969432831e-01
    z[3,0,6]  R544      -8.2080394029617310e-02
    z[3,0,6]  R545      1.1452677100896835e-01
    z[3,0,6]  R546      -1.8692702054977417e-01
    z[3,0,6]  R547      2.4975709617137909e-01
    z[3,0,6]  R548      -7.0599899627268314e-03
    z[3,0,6]  R549      0.334903746843338
    z[3,0,6]  R550      2.6230832934379578e-01
    z[3,0,6]  R551      -4.8832472413778305e-02
    z[3,0,6]  R552      -2.0278413593769073e-01
    z[3,0,6]  R553      4.5380666851997375e-01
    z[3,0,6]  R554      -5.0844949483871460e-01
    z[3,0,6]  R555      -3.1010892987251282e-01
    z[3,0,6]  R556      -2.0153287053108215e-01
    z[3,0,6]  R557      -1.6770051419734955e-01
    z[3,0,6]  R558      1.9983239471912384e-01
    z[3,0,6]  R559      4.9782890081405640e-01
    z[3,0,6]  R560      -5.5163258314132690e-01
    z[3,0,6]  R561      -2.5561100244522095e-01
    z[3,0,6]  R562      1.1177039146423340e-01
    z[3,0,6]  R563      -2.8189316391944885e-01
    z[3,0,6]  R564      2.5481504853814840e-03
    z[3,0,6]  R565      -4.3024727702140808e-01
    z[3,0,6]  R566      -3.8709992170333862e-01
    z[3,0,6]  R567      -4.3280977010726929e-01
    z[3,0,6]  R568      -1.9919589161872864e-01
    z[3,0,6]  R569      -1.5708579123020172e-01
    z[3,0,6]  R570      4.0341550111770630e-01
    z[3,0,6]  R571      0.250916063785553
    z[3,0,6]  R572      0.594076931476593
    z[3,0,6]  R573      -2.8386563062667847e-01
    z[3,0,6]  R574      1.5093356370925903e-01
    z[3,0,6]  R575      1.6574905812740326e-01
    z[3,0,6]  R576      4.9676052294671535e-03
    z[3,0,6]  R577      -2.0203253254294395e-02
    z[3,0,6]  R578      -4.0810006856918335e-01
    z[3,0,6]  R579      -4.4969558715820312e-02
    z[3,0,6]  R580      -3.1377106904983521e-01
    z[3,0,6]  R581      -3.6554921418428421e-02
    z[3,0,6]  R582      -4.8499208688735962e-01
    z[3,0,6]  R583      -3.9638879895210266e-01
    z[3,0,6]  R584      -4.9349474906921387e-01
    z[3,0,6]  R585      1.4735881984233856e-01
    z[3,0,6]  R586      -1.2634842097759247e-01
    z[3,0,6]  R587      -8.0381870269775391e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R662      -1
    z[1,2,0]  R663      1
    z[1,2,0]  R676      -1.2722581624984741e-01
    z[1,2,0]  R677      2.0702557638287544e-02
    z[1,2,0]  R678      1.7400571703910828e-01
    z[1,2,0]  R679      1.6851654276251793e-02
    z[1,2,0]  R680      -4.9683997035026550e-01
    z[1,2,0]  R681      1.2294229120016098e-01
    z[1,2,0]  R682      3.8583450019359589e-02
    z[1,2,0]  R683      7.2080634534358978e-02
    z[1,2,0]  R684      7.7041331678628922e-04
    z[1,2,0]  R685      7.2286769747734070e-02
    z[1,2,0]  R686      -7.5946646928787231e-01
    z[1,2,0]  R687      -8.2690078020095825e-01
    z[1,2,0]  R688      -7.8685903549194336e-01
    z[1,2,0]  R689      -7.4463844299316406e-01
    z[1,2,0]  R690      -2.6125228404998779e-01
    z[1,2,0]  R691      -0.654283344745636
    z[1,2,0]  R692      -4.2415246367454529e-01
    z[1,2,0]  R693      -2.5743165612220764e-01
    z[1,2,0]  R694      -2.8072366118431091e-01
    z[1,2,0]  R695      -3.8944289088249207e-01
    z[1,2,0]  R696      5.0468966364860535e-02
    z[1,2,0]  R697      0.562359631061554
    z[1,2,0]  R698      -7.1691438555717468e-02
    z[1,2,0]  R699      4.9378836154937744e-01
    z[1,2,0]  R700      9.2348873615264893e-01
    z[1,2,0]  R701      6.8466496467590332e-01
    z[1,2,0]  R702      8.0839455127716064e-01
    z[1,2,0]  R703      7.8445595502853394e-01
    z[1,2,0]  R704      7.0763266086578369e-01
    z[1,2,0]  R705      2.7363106608390808e-01
    z[1,2,0]  R706      4.3372777104377747e-01
    z[1,2,0]  R707      4.9973770976066589e-01
    z[1,2,0]  R708      4.5048114657402039e-01
    z[1,2,0]  R709      3.3973124623298645e-01
    z[1,2,0]  R710      2.6258271932601929e-01
    z[1,2,0]  R711      -3.6433931440114975e-02
    z[1,2,0]  R712      0.683049201965332
    z[1,2,0]  R713      -8.6409854888916016e-01
    z[1,2,0]  R714      -8.6637049913406372e-01
    z[1,2,0]  R715      -8.2070887088775635e-01
    z[1,2,0]  R716      8.3364957571029663e-01
    z[1,2,0]  R717      5.1239848136901855e-01
    z[1,2,0]  R718      7.4250853061676025e-01
    z[1,2,0]  R719      4.6475287526845932e-02
    z[1,2,0]  R720      -8.0535590648651123e-01
    z[1,2,0]  R721      2.1084900200366974e-01
    z[1,2,0]  R722      1.6341623663902283e-01
    z[1,2,0]  R723      4.5319050550460815e-02
    z[1,2,0]  R724      -1.7409981787204742e-01
    z[1,2,0]  R725      2.1518768742680550e-02
    z[1,2,0]  R726      -8.6114391684532166e-02
    z[1,2,0]  R727      -2.6662680506706238e-01
    z[1,2,0]  R728      -5.2559429407119751e-01
    z[1,2,0]  R729      1.3804684579372406e-01
    z[1,2,0]  R730      -1.7923644185066223e-01
    z[1,2,0]  R731      2.6704484224319458e-01
    z[1,2,0]  R732      -9.4874203205108643e-02
    z[1,2,0]  R733      1.7659552395343781e-01
    z[1,2,0]  R734      3.6078906059265137e-01
    z[1,2,0]  R735      1.1271440237760544e-01
    z[1,2,0]  R736      1.9500410556793213e-01
    z[1,2,0]  R737      2.3636843264102936e-01
    z[1,2,0]  R738      3.1732618808746338e-01
    z[1,2,0]  R739      8.7245799601078033e-02
    z[1,2,0]  R740      1.6199515759944916e-01
    z[1,2,0]  R741      4.6486815810203552e-01
    z[1,2,0]  R742      -1.2235434353351593e-01
    z[1,2,0]  R743      -1.1196144670248032e-01
    z[1,2,0]  R744      -1.0307740420103073e-01
    z[1,2,0]  R745      -2.4501538276672363e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R664      -1
    z[1,2,1]  R665      1
    z[1,2,1]  R676      -4.0606725215911865e-01
    z[1,2,1]  R677      -8.5662293434143066e-01
    z[1,2,1]  R678      -6.6742545366287231e-01
    z[1,2,1]  R679      -3.8001769781112671e-01
    z[1,2,1]  R680      -1.2752562761306763e-01
    z[1,2,1]  R681      -6.2731981277465820e-01
    z[1,2,1]  R682      1.8085278570652008e-01
    z[1,2,1]  R683      -6.1604923009872437e-01
    z[1,2,1]  R684      -5.5951058864593506e-01
    z[1,2,1]  R685      -4.0628954768180847e-01
    z[1,2,1]  R686      -3.2694950699806213e-01
    z[1,2,1]  R687      -1.8602201342582703e-01
    z[1,2,1]  R688      -4.8230059444904327e-02
    z[1,2,1]  R689      -2.7818185091018677e-01
    z[1,2,1]  R690      4.6050807833671570e-01
    z[1,2,1]  R691      2.7634924277663231e-02
    z[1,2,1]  R692      1.5746396780014038e-01
    z[1,2,1]  R693      0.412733256816864
    z[1,2,1]  R694      3.6810505390167236e-01
    z[1,2,1]  R695      4.1212329268455505e-01
    z[1,2,1]  R696      5.1099520921707153e-01
    z[1,2,1]  R697      1.5516389906406403e-01
    z[1,2,1]  R698      3.5979580879211426e-01
    z[1,2,1]  R699      6.4920186996459961e-02
    z[1,2,1]  R700      3.4705594182014465e-01
    z[1,2,1]  R701      -2.2733153402805328e-01
    z[1,2,1]  R702      -1.5694728493690491e-01
    z[1,2,1]  R703      5.3272019140422344e-03
    z[1,2,1]  R704      1.8249194324016571e-01
    z[1,2,1]  R705      -2.9867708683013916e-01
    z[1,2,1]  R706      -1.2157098948955536e-01
    z[1,2,1]  R707      -6.7000240087509155e-01
    z[1,2,1]  R708      -5.6848609447479248e-01
    z[1,2,1]  R709      -0.54603111743927
    z[1,2,1]  R710      -3.9111602306365967e-01
    z[1,2,1]  R711      -3.1595990061759949e-01
    z[1,2,1]  R712      4.4881820678710938e-01
    z[1,2,1]  R713      -9.2467240989208221e-02
    z[1,2,1]  R714      -5.3211987018585205e-02
    z[1,2,1]  R715      -5.8870144188404083e-02
    z[1,2,1]  R716      -1.9726459681987762e-01
    z[1,2,1]  R717      2.0762990415096283e-01
    z[1,2,1]  R718      -1.7342941462993622e-01
    z[1,2,1]  R719      8.1048947572708130e-01
    z[1,2,1]  R720      -4.0847569704055786e-01
    z[1,2,1]  R721      6.9204968214035034e-01
    z[1,2,1]  R722      6.3707798719406128e-01
    z[1,2,1]  R723      7.3784333467483521e-01
    z[1,2,1]  R724      4.9446558952331543e-01
    z[1,2,1]  R725      4.8585602641105652e-01
    z[1,2,1]  R726      -6.2125867605209351e-01
    z[1,2,1]  R727      -5.1839131116867065e-01
    z[1,2,1]  R728      -6.4223206043243408e-01
    z[1,2,1]  R729      -8.5852009057998657e-01
    z[1,2,1]  R730      -8.8854783773422241e-01
    z[1,2,1]  R731      7.0590265095233917e-02
    z[1,2,1]  R732      -2.2162930667400360e-01
    z[1,2,1]  R733      9.3165911734104156e-02
    z[1,2,1]  R734      1.9307444989681244e-01
    z[1,2,1]  R735      -0.20382159948349
    z[1,2,1]  R736      4.5184570550918579e-01
    z[1,2,1]  R737      3.8862824440002441e-01
    z[1,2,1]  R738      4.1592359542846680e-01
    z[1,2,1]  R739      0.513628363609314
    z[1,2,1]  R740      3.7828582525253296e-01
    z[1,2,1]  R741      2.9255113005638123e-01
    z[1,2,1]  R742      6.3944053649902344e-01
    z[1,2,1]  R743      4.4198375940322876e-01
    z[1,2,1]  R744      8.5158699750900269e-01
    z[1,2,1]  R745      8.5738492012023926e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R666      -1
    z[1,2,2]  R667      1
    z[1,2,2]  R676      8.3968991041183472e-01
    z[1,2,2]  R677      3.6968412995338440e-01
    z[1,2,2]  R678      0.459505558013916
    z[1,2,2]  R679      7.1922683715820312e-01
    z[1,2,2]  R680      7.7588593959808350e-01
    z[1,2,2]  R681      4.2355218529701233e-01
    z[1,2,2]  R682      8.0315440893173218e-01
    z[1,2,2]  R683      3.7288326025009155e-01
    z[1,2,2]  R684      4.3731957674026489e-01
    z[1,2,2]  R685      6.7767697572708130e-01
    z[1,2,2]  R686      -5.0836914777755737e-01
    z[1,2,2]  R687      -4.2291939258575439e-01
    z[1,2,2]  R688      -4.8327657580375671e-01
    z[1,2,2]  R689      -5.7509851455688477e-01
    z[1,2,2]  R690      -6.9054877758026123e-01
    z[1,2,2]  R691      -4.6498143672943115e-01
    z[1,2,2]  R692      -2.6943698525428772e-01
    z[1,2,2]  R693      -0.669501543045044
    z[1,2,2]  R694      -5.2097642421722412e-01
    z[1,2,2]  R695      -5.3540790081024170e-01
    z[1,2,2]  R696      -3.6459747701883316e-02
    z[1,2,2]  R697      -1.4083737134933472e-01
    z[1,2,2]  R698      -2.3714843392372131e-01
    z[1,2,2]  R699      5.4901713132858276e-01
    z[1,2,2]  R700      6.1884272843599319e-02
    z[1,2,2]  R701      6.7300267517566681e-02
    z[1,2,2]  R702      -1.6915030777454376e-01
    z[1,2,2]  R703      1.6775536537170410e-01
    z[1,2,2]  R704      1.9526395201683044e-01
    z[1,2,2]  R705      8.6094796657562256e-02
    z[1,2,2]  R706      4.6372807025909424e-01
    z[1,2,2]  R707      -1.9680503010749817e-01
    z[1,2,2]  R708      8.0855436623096466e-02
    z[1,2,2]  R709      4.7880895435810089e-02
    z[1,2,2]  R710      2.1502092480659485e-01
    z[1,2,2]  R711      3.0873468518257141e-01
    z[1,2,2]  R712      5.2402138710021973e-01
    z[1,2,2]  R713      -4.4109621644020081e-01
    z[1,2,2]  R714      -0.150368332862854
    z[1,2,2]  R715      -3.0549362301826477e-01
    z[1,2,2]  R716      0.374489426612854
    z[1,2,2]  R717      5.0314950942993164e-01
    z[1,2,2]  R718      -2.0568031072616577e-01
    z[1,2,2]  R719      0.0821487233042717
    z[1,2,2]  R720      -8.9237973093986511e-02
    z[1,2,2]  R721      -3.8678056001663208e-01
    z[1,2,2]  R722      -5.2411282062530518e-01
    z[1,2,2]  R723      -3.7047600746154785e-01
    z[1,2,2]  R724      -0.631361186504364
    z[1,2,2]  R725      -4.3349912762641907e-01
    z[1,2,2]  R726      6.4191657304763794e-01
    z[1,2,2]  R727      5.4716587066650391e-01
    z[1,2,2]  R728      4.7255662083625793e-01
    z[1,2,2]  R729      3.6511132121086121e-01
    z[1,2,2]  R730      5.3928568959236145e-02
    z[1,2,2]  R731      -4.6291261911392212e-01
    z[1,2,2]  R732      -6.8764805793762207e-01
    z[1,2,2]  R733      -3.6826652288436890e-01
    z[1,2,2]  R734      -4.5904904603958130e-01
    z[1,2,2]  R735      -9.3029528856277466e-01
    z[1,2,2]  R736      6.2224364280700684e-01
    z[1,2,2]  R737      3.3884134888648987e-01
    z[1,2,2]  R738      2.3745256662368774e-01
    z[1,2,2]  R739      6.0588216781616211e-01
    z[1,2,2]  R740      5.2405965328216553e-01
    z[1,2,2]  R741      5.2620679140090942e-01
    z[1,2,2]  R742      2.5405415892601013e-01
    z[1,2,2]  R743      2.0580118894577026e-01
    z[1,2,2]  R744      1.7980951070785522e-01
    z[1,2,2]  R745      1.2643806636333466e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R668      -1
    z[1,2,3]  R669      1
    z[1,2,3]  R676      -1.9909712672233582e-01
    z[1,2,3]  R677      -1.6519768536090851e-01
    z[1,2,3]  R678      2.0185695588588715e-01
    z[1,2,3]  R679      -2.7235820889472961e-01
    z[1,2,3]  R680      2.0207263529300690e-02
    z[1,2,3]  R681      -3.0750006437301636e-01
    z[1,2,3]  R682      2.9661837220191956e-01
    z[1,2,3]  R683      5.0223521888256073e-02
    z[1,2,3]  R684      0.077674001455307
    z[1,2,3]  R685      -4.4104721397161484e-02
    z[1,2,3]  R686      -6.4003534615039825e-02
    z[1,2,3]  R687      4.1698209941387177e-02
    z[1,2,3]  R688      7.3577851057052612e-02
    z[1,2,3]  R689      3.5545095801353455e-02
    z[1,2,3]  R690      3.1346008181571960e-01
    z[1,2,3]  R691      -1.4843994379043579e-01
    z[1,2,3]  R692      2.3004728555679321e-01
    z[1,2,3]  R693      4.4075345993041992e-01
    z[1,2,3]  R694      3.6550438404083252e-01
    z[1,2,3]  R695      3.0500376224517822e-01
    z[1,2,3]  R696      6.3105963170528412e-02
    z[1,2,3]  R697      6.1312373727560043e-03
    z[1,2,3]  R698      7.2842933237552643e-02
    z[1,2,3]  R699      -1.8690697848796844e-01
    z[1,2,3]  R700      -4.0619168430566788e-03
    z[1,2,3]  R701      -3.0977734923362732e-01
    z[1,2,3]  R702      -2.3131315410137177e-01
    z[1,2,3]  R703      -4.2744103074073792e-01
    z[1,2,3]  R704      -1.7304801940917969e-01
    z[1,2,3]  R705      -3.1542572379112244e-01
    z[1,2,3]  R706      -4.2001712322235107e-01
    z[1,2,3]  R707      -3.9449888467788696e-01
    z[1,2,3]  R708      -0.572258710861206
    z[1,2,3]  R709      -0.360209584236145
    z[1,2,3]  R710      -4.7984135150909424e-01
    z[1,2,3]  R711      -2.7646675705909729e-02
    z[1,2,3]  R712      5.0068624317646027e-02
    z[1,2,3]  R713      -3.8766807410866022e-03
    z[1,2,3]  R714      3.5247886180877686e-01
    z[1,2,3]  R715      1.8729597330093384e-01
    z[1,2,3]  R716      -3.0640000104904175e-01
    z[1,2,3]  R717      -2.9593247175216675e-01
    z[1,2,3]  R718      -1.3290596008300781e-01
    z[1,2,3]  R719      1.5202455222606659e-01
    z[1,2,3]  R720      -2.3024519905447960e-02
    z[1,2,3]  R721      5.6639021635055542e-01
    z[1,2,3]  R722      4.8683652281761169e-01
    z[1,2,3]  R723      4.5692732930183411e-01
    z[1,2,3]  R724      5.1947754621505737e-01
    z[1,2,3]  R725      6.1422526836395264e-01
    z[1,2,3]  R726      3.7220796942710876e-01
    z[1,2,3]  R727      4.6839761734008789e-01
    z[1,2,3]  R728      1.6719271242618561e-01
    z[1,2,3]  R729      1.2000499665737152e-01
    z[1,2,3]  R730      2.8061398863792419e-01
    z[1,2,3]  R731      7.1794402599334717e-01
    z[1,2,3]  R732      5.9474724531173706e-01
    z[1,2,3]  R733      8.6313569545745850e-01
    z[1,2,3]  R734      4.6029153466224670e-01
    z[1,2,3]  R735      1.5579879283905029e-01
    z[1,2,3]  R736      -8.6404690518975258e-03
    z[1,2,3]  R737      -1.1484029702842236e-02
    z[1,2,3]  R738      7.7955529093742371e-02
    z[1,2,3]  R739      -1.7613553791306913e-04
    z[1,2,3]  R740      1.1394208669662476e-01
    z[1,2,3]  R741      2.9837839305400848e-02
    z[1,2,3]  R742      -4.2753354646265507e-03
    z[1,2,3]  R743      2.0318765193223953e-02
    z[1,2,3]  R744      -2.0815165340900421e-01
    z[1,2,3]  R745      -9.9909320473670959e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R670      -1
    z[1,2,4]  R671      1
    z[1,2,4]  R676      -5.2067171782255173e-02
    z[1,2,4]  R677      -1.1456907959654927e-03
    z[1,2,4]  R678      -3.6360761523246765e-01
    z[1,2,4]  R679      3.8033846765756607e-02
    z[1,2,4]  R680      2.1731720864772797e-01
    z[1,2,4]  R681      2.2090306878089905e-01
    z[1,2,4]  R682      4.2820364236831665e-01
    z[1,2,4]  R683      2.2266179323196411e-01
    z[1,2,4]  R684      0.602392315864563
    z[1,2,4]  R685      4.5574018359184265e-01
    z[1,2,4]  R686      -4.7931659966707230e-02
    z[1,2,4]  R687      -5.3476560860872269e-02
    z[1,2,4]  R688      -2.7044081687927246e-01
    z[1,2,4]  R689      4.7364749014377594e-02
    z[1,2,4]  R690      -1.3396562635898590e-01
    z[1,2,4]  R691      -2.5589841604232788e-01
    z[1,2,4]  R692      9.7017228603363037e-02
    z[1,2,4]  R693      7.3426604270935059e-02
    z[1,2,4]  R694      1.8762914836406708e-01
    z[1,2,4]  R695      -1.4057025313377380e-01
    z[1,2,4]  R696      -3.0107897520065308e-01
    z[1,2,4]  R697      -2.0867292582988739e-01
    z[1,2,4]  R698      1.1813201010227203e-01
    z[1,2,4]  R699      2.3920483887195587e-02
    z[1,2,4]  R700      -0.0217477697879076
    z[1,2,4]  R701      -5.2040744572877884e-02
    z[1,2,4]  R702      1.6099634766578674e-01
    z[1,2,4]  R703      -3.1772014498710632e-01
    z[1,2,4]  R704      -4.4278463721275330e-01
    z[1,2,4]  R705      3.2765313982963562e-01
    z[1,2,4]  R706      -4.5414149761199951e-01
    z[1,2,4]  R707      3.1276699900627136e-01
    z[1,2,4]  R708      1.6534550487995148e-01
    z[1,2,4]  R709      4.7791969776153564e-01
    z[1,2,4]  R710      1.5253904461860657e-01
    z[1,2,4]  R711      2.6589216664433479e-02
    z[1,2,4]  R712      -2.1097426116466522e-01
    z[1,2,4]  R713      -1.6661521792411804e-01
    z[1,2,4]  R714      2.5000625848770142e-01
    z[1,2,4]  R715      2.3330490291118622e-01
    z[1,2,4]  R716      1.0494589060544968e-01
    z[1,2,4]  R717      -1.7684867978096008e-01
    z[1,2,4]  R718      -6.4213410019874573e-02
    z[1,2,4]  R719      -1.1015962064266205e-01
    z[1,2,4]  R720      2.4497982114553452e-02
    z[1,2,4]  R721      -4.0380254387855530e-02
    z[1,2,4]  R722      -1.8860971927642822e-01
    z[1,2,4]  R723      -1.6324110329151154e-01
    z[1,2,4]  R724      1.0699438303709030e-01
    z[1,2,4]  R725      3.3944758772850037e-01
    z[1,2,4]  R726      2.6416091248393059e-02
    z[1,2,4]  R727      -3.3045294880867004e-01
    z[1,2,4]  R728      1.0801636381074786e-03
    z[1,2,4]  R729      -5.0684046000242233e-02
    z[1,2,4]  R730      -1.1764678172767162e-02
    z[1,2,4]  R731      -3.6642208695411682e-01
    z[1,2,4]  R732      -2.5889590382575989e-01
    z[1,2,4]  R733      2.6452008169144392e-03
    z[1,2,4]  R734      -5.5785093456506729e-02
    z[1,2,4]  R735      -6.1872941441833973e-03
    z[1,2,4]  R736      2.3640081286430359e-01
    z[1,2,4]  R737      -1.0277015715837479e-01
    z[1,2,4]  R738      4.2747011780738831e-01
    z[1,2,4]  R739      -1.0872618108987808e-01
    z[1,2,4]  R740      5.1522469520568848e-01
    z[1,2,4]  R741      1.4857383072376251e-01
    z[1,2,4]  R742      2.4948436766862869e-02
    z[1,2,4]  R743      3.2144007086753845e-01
    z[1,2,4]  R744      3.0023893713951111e-01
    z[1,2,4]  R745      -4.9544990062713623e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R672      -1
    z[1,2,5]  R673      1
    z[1,2,5]  R676      -2.6185715198516846e-01
    z[1,2,5]  R677      -2.4369697272777557e-01
    z[1,2,5]  R678      -3.0192995071411133e-01
    z[1,2,5]  R679      1.8738912418484688e-02
    z[1,2,5]  R680      -9.8352529108524323e-02
    z[1,2,5]  R681      3.9602303504943848e-01
    z[1,2,5]  R682      -2.1167115867137909e-01
    z[1,2,5]  R683      -2.9340144991874695e-01
    z[1,2,5]  R684      -3.5542976856231689e-01
    z[1,2,5]  R685      3.7708008289337158e-01
    z[1,2,5]  R686      5.5474311113357544e-02
    z[1,2,5]  R687      1.2986877560615540e-01
    z[1,2,5]  R688      -0.253933846950531
    z[1,2,5]  R689      -1.2982282042503357e-01
    z[1,2,5]  R690      3.5530611872673035e-01
    z[1,2,5]  R691      3.9429646730422974e-01
    z[1,2,5]  R692      -4.8040366172790527e-01
    z[1,2,5]  R693      3.2295471429824829e-01
    z[1,2,5]  R694      5.8690625429153442e-01
    z[1,2,5]  R695      4.4697627425193787e-01
    z[1,2,5]  R696      -7.2650724649429321e-01
    z[1,2,5]  R697      -7.7126610279083252e-01
    z[1,2,5]  R698      -8.5369080305099487e-01
    z[1,2,5]  R699      -1.0248441249132156e-01
    z[1,2,5]  R700      -1.0205791890621185e-01
    z[1,2,5]  R701      -4.4212377071380615e-01
    z[1,2,5]  R702      -7.9361595213413239e-02
    z[1,2,5]  R703      2.2805219888687134e-01
    z[1,2,5]  R704      -4.4459503889083862e-01
    z[1,2,5]  R705      2.0874033868312836e-01
    z[1,2,5]  R706      -4.3574118614196777e-01
    z[1,2,5]  R707      -8.1849955022335052e-02
    z[1,2,5]  R708      1.4777642488479614e-01
    z[1,2,5]  R709      4.7310128808021545e-01
    z[1,2,5]  R710      6.6230261325836182e-01
    z[1,2,5]  R711      -8.7718927860260010e-01
    z[1,2,5]  R712      1.3225401751697063e-02
    z[1,2,5]  R713      5.8165524154901505e-02
    z[1,2,5]  R714      -8.5439709946513176e-03
    z[1,2,5]  R715      3.7420755624771118e-01
    z[1,2,5]  R716      6.8470202386379242e-02
    z[1,2,5]  R717      2.9246711730957031e-01
    z[1,2,5]  R718      -5.9198802709579468e-01
    z[1,2,5]  R719      -0.0754462406039238
    z[1,2,5]  R720      -0.163039892911911
    z[1,2,5]  R721      -5.8868058025836945e-02
    z[1,2,5]  R722      -1.4028537273406982e-01
    z[1,2,5]  R723      2.8312322497367859e-01
    z[1,2,5]  R724      1.2301035970449448e-01
    z[1,2,5]  R725      1.2846863828599453e-02
    z[1,2,5]  R726      2.3521322011947632e-01
    z[1,2,5]  R727      1.6307172179222107e-01
    z[1,2,5]  R728      -2.4484235048294067e-01
    z[1,2,5]  R729      3.0416178703308105e-01
    z[1,2,5]  R730      0.251397043466568
    z[1,2,5]  R731      1.6475871205329895e-01
    z[1,2,5]  R732      -1.5033662319183350e-01
    z[1,2,5]  R733      1.9075880944728851e-01
    z[1,2,5]  R734      5.6018787622451782e-01
    z[1,2,5]  R735      1.8015068769454956e-01
    z[1,2,5]  R736      -5.2143466472625732e-01
    z[1,2,5]  R737      -8.0909961462020874e-01
    z[1,2,5]  R738      -6.8678516149520874e-01
    z[1,2,5]  R739      -5.1308321952819824e-01
    z[1,2,5]  R740      -4.8027858138084412e-01
    z[1,2,5]  R741      -5.6475079059600830e-01
    z[1,2,5]  R742      -6.9524812698364258e-01
    z[1,2,5]  R743      -0.643557608127594
    z[1,2,5]  R744      -2.4108362197875977e-01
    z[1,2,5]  R745      2.2438602149486542e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R674      -1
    z[1,2,6]  R675      1
    z[1,2,6]  R676      -5.4073341190814972e-02
    z[1,2,6]  R677      2.0596711337566376e-01
    z[1,2,6]  R678      -2.2136306762695312e-01
    z[1,2,6]  R679      5.1189702749252319e-01
    z[1,2,6]  R680      -2.7853175997734070e-01
    z[1,2,6]  R681      3.3431991934776306e-01
    z[1,2,6]  R682      6.7832171916961670e-02
    z[1,2,6]  R683      -5.8142983913421631e-01
    z[1,2,6]  R684      2.1421007812023163e-02
    z[1,2,6]  R685      -1.3646802306175232e-01
    z[1,2,6]  R686      2.2000966966152191e-01
    z[1,2,6]  R687      2.8514152765274048e-01
    z[1,2,6]  R688      -4.4002164155244827e-02
    z[1,2,6]  R689      -1.3049638271331787e-01
    z[1,2,6]  R690      -1.9374759867787361e-02
    z[1,2,6]  R691      -3.3459511399269104e-01
    z[1,2,6]  R692      6.5542489290237427e-01
    z[1,2,6]  R693      1.0579691082239151e-01
    z[1,2,6]  R694      3.1926054507493973e-02
    z[1,2,6]  R695      2.8151726722717285e-01
    z[1,2,6]  R696      -3.3550536632537842e-01
    z[1,2,6]  R697      -3.7513405084609985e-02
    z[1,2,6]  R698      -2.4722217023372650e-01
    z[1,2,6]  R699      -6.3602608442306519e-01
    z[1,2,6]  R700      1.0947944223880768e-01
    z[1,2,6]  R701      -4.2530137300491333e-01
    z[1,2,6]  R702      -4.5555481314659119e-01
    z[1,2,6]  R703      1.4421868324279785e-01
    z[1,2,6]  R704      -6.4467117190361023e-02
    z[1,2,6]  R705      -7.6031780242919922e-01
    z[1,2,6]  R706      -9.7609780728816986e-02
    z[1,2,6]  R707      4.9747385084629059e-02
    z[1,2,6]  R708      -3.0115723609924316e-01
    z[1,2,6]  R709      4.6444587409496307e-02
    z[1,2,6]  R710      0.199208065867424
    z[1,2,6]  R711      -0.180533766746521
    z[1,2,6]  R712      1.0107289999723434e-01
    z[1,2,6]  R713      -1.3805307447910309e-01
    z[1,2,6]  R714      1.9272369146347046e-01
    z[1,2,6]  R715      1.0131252929568291e-02
    z[1,2,6]  R716      1.2763187289237976e-01
    z[1,2,6]  R717      -0.486610472202301
    z[1,2,6]  R718      -6.3732050359249115e-02
    z[1,2,6]  R719      5.4153460264205933e-01
    z[1,2,6]  R720      3.8584148883819580e-01
    z[1,2,6]  R721      -3.3422295004129410e-02
    z[1,2,6]  R722      2.1657595410943031e-02
    z[1,2,6]  R723      2.6306835934519768e-02
    z[1,2,6]  R724      -1.7360873520374298e-01
    z[1,2,6]  R725      -2.8791844844818115e-01
    z[1,2,6]  R726      -1.7870176816359162e-03
    z[1,2,6]  R727      -7.4849396944046021e-02
    z[1,2,6]  R728      -0.00873769260942936
    z[1,2,6]  R729      -3.3102288842201233e-02
    z[1,2,6]  R730      1.8266259133815765e-01
    z[1,2,6]  R731      -1.8044899404048920e-01
    z[1,2,6]  R732      -1.6020901501178741e-01
    z[1,2,6]  R733      2.0764118432998657e-01
    z[1,2,6]  R734      3.0501919984817505e-01
    z[1,2,6]  R735      1.5341801941394806e-01
    z[1,2,6]  R736      -2.0680311322212219e-01
    z[1,2,6]  R737      1.1379343271255493e-01
    z[1,2,6]  R738      0.097191721200943
    z[1,2,6]  R739      2.9394736886024475e-01
    z[1,2,6]  R740      2.1659180521965027e-01
    z[1,2,6]  R741      2.8197491168975830e-01
    z[1,2,6]  R742      -1.6610570251941681e-01
    z[1,2,6]  R743      4.8151633143424988e-01
    z[1,2,6]  R744      2.0062738656997681e-01
    z[1,2,6]  R745      3.5508644580841064e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R746      -1
    z[2,1,0]  R747      1
    z[2,1,0]  R760      -8.6114391684532166e-02
    z[2,1,0]  R761      -2.6662680506706238e-01
    z[2,1,0]  R762      -5.2559429407119751e-01
    z[2,1,0]  R763      1.3804684579372406e-01
    z[2,1,0]  R764      -1.7923644185066223e-01
    z[2,1,0]  R765      2.6704484224319458e-01
    z[2,1,0]  R766      -9.4874203205108643e-02
    z[2,1,0]  R767      1.7659552395343781e-01
    z[2,1,0]  R768      3.6078906059265137e-01
    z[2,1,0]  R769      1.1271440237760544e-01
    z[2,1,0]  R770      1.9500410556793213e-01
    z[2,1,0]  R771      2.3636843264102936e-01
    z[2,1,0]  R772      3.1732618808746338e-01
    z[2,1,0]  R773      8.7245799601078033e-02
    z[2,1,0]  R774      1.6199515759944916e-01
    z[2,1,0]  R775      4.6486815810203552e-01
    z[2,1,0]  R776      -1.2235434353351593e-01
    z[2,1,0]  R777      -1.1196144670248032e-01
    z[2,1,0]  R778      -1.0307740420103073e-01
    z[2,1,0]  R779      -2.4501538276672363e-01
    z[2,1,0]  R780      -1.2722581624984741e-01
    z[2,1,0]  R781      2.0702557638287544e-02
    z[2,1,0]  R782      1.7400571703910828e-01
    z[2,1,0]  R783      1.6851654276251793e-02
    z[2,1,0]  R784      -4.9683997035026550e-01
    z[2,1,0]  R785      1.2294229120016098e-01
    z[2,1,0]  R786      3.8583450019359589e-02
    z[2,1,0]  R787      7.2080634534358978e-02
    z[2,1,0]  R788      7.7041331678628922e-04
    z[2,1,0]  R789      7.2286769747734070e-02
    z[2,1,0]  R790      -7.5946646928787231e-01
    z[2,1,0]  R791      -8.2690078020095825e-01
    z[2,1,0]  R792      -7.8685903549194336e-01
    z[2,1,0]  R793      -7.4463844299316406e-01
    z[2,1,0]  R794      -2.6125228404998779e-01
    z[2,1,0]  R795      -0.654283344745636
    z[2,1,0]  R796      -4.2415246367454529e-01
    z[2,1,0]  R797      -2.5743165612220764e-01
    z[2,1,0]  R798      -2.8072366118431091e-01
    z[2,1,0]  R799      -3.8944289088249207e-01
    z[2,1,0]  R800      5.0468966364860535e-02
    z[2,1,0]  R801      0.562359631061554
    z[2,1,0]  R802      -7.1691438555717468e-02
    z[2,1,0]  R803      4.9378836154937744e-01
    z[2,1,0]  R804      9.2348873615264893e-01
    z[2,1,0]  R805      6.8466496467590332e-01
    z[2,1,0]  R806      8.0839455127716064e-01
    z[2,1,0]  R807      7.8445595502853394e-01
    z[2,1,0]  R808      7.0763266086578369e-01
    z[2,1,0]  R809      2.7363106608390808e-01
    z[2,1,0]  R810      4.3372777104377747e-01
    z[2,1,0]  R811      4.9973770976066589e-01
    z[2,1,0]  R812      4.5048114657402039e-01
    z[2,1,0]  R813      3.3973124623298645e-01
    z[2,1,0]  R814      2.6258271932601929e-01
    z[2,1,0]  R815      -3.6433931440114975e-02
    z[2,1,0]  R816      0.683049201965332
    z[2,1,0]  R817      -8.6409854888916016e-01
    z[2,1,0]  R818      -8.6637049913406372e-01
    z[2,1,0]  R819      -8.2070887088775635e-01
    z[2,1,0]  R820      8.3364957571029663e-01
    z[2,1,0]  R821      5.1239848136901855e-01
    z[2,1,0]  R822      7.4250853061676025e-01
    z[2,1,0]  R823      4.6475287526845932e-02
    z[2,1,0]  R824      -8.0535590648651123e-01
    z[2,1,0]  R825      2.1084900200366974e-01
    z[2,1,0]  R826      1.6341623663902283e-01
    z[2,1,0]  R827      4.5319050550460815e-02
    z[2,1,0]  R828      -1.7409981787204742e-01
    z[2,1,0]  R829      2.1518768742680550e-02
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R748      -1
    z[2,1,1]  R749      1
    z[2,1,1]  R760      -6.2125867605209351e-01
    z[2,1,1]  R761      -5.1839131116867065e-01
    z[2,1,1]  R762      -6.4223206043243408e-01
    z[2,1,1]  R763      -8.5852009057998657e-01
    z[2,1,1]  R764      -8.8854783773422241e-01
    z[2,1,1]  R765      7.0590265095233917e-02
    z[2,1,1]  R766      -2.2162930667400360e-01
    z[2,1,1]  R767      9.3165911734104156e-02
    z[2,1,1]  R768      1.9307444989681244e-01
    z[2,1,1]  R769      -0.20382159948349
    z[2,1,1]  R770      4.5184570550918579e-01
    z[2,1,1]  R771      3.8862824440002441e-01
    z[2,1,1]  R772      4.1592359542846680e-01
    z[2,1,1]  R773      0.513628363609314
    z[2,1,1]  R774      3.7828582525253296e-01
    z[2,1,1]  R775      2.9255113005638123e-01
    z[2,1,1]  R776      6.3944053649902344e-01
    z[2,1,1]  R777      4.4198375940322876e-01
    z[2,1,1]  R778      8.5158699750900269e-01
    z[2,1,1]  R779      8.5738492012023926e-01
    z[2,1,1]  R780      -4.0606725215911865e-01
    z[2,1,1]  R781      -8.5662293434143066e-01
    z[2,1,1]  R782      -6.6742545366287231e-01
    z[2,1,1]  R783      -3.8001769781112671e-01
    z[2,1,1]  R784      -1.2752562761306763e-01
    z[2,1,1]  R785      -6.2731981277465820e-01
    z[2,1,1]  R786      1.8085278570652008e-01
    z[2,1,1]  R787      -6.1604923009872437e-01
    z[2,1,1]  R788      -5.5951058864593506e-01
    z[2,1,1]  R789      -4.0628954768180847e-01
    z[2,1,1]  R790      -3.2694950699806213e-01
    z[2,1,1]  R791      -1.8602201342582703e-01
    z[2,1,1]  R792      -4.8230059444904327e-02
    z[2,1,1]  R793      -2.7818185091018677e-01
    z[2,1,1]  R794      4.6050807833671570e-01
    z[2,1,1]  R795      2.7634924277663231e-02
    z[2,1,1]  R796      1.5746396780014038e-01
    z[2,1,1]  R797      0.412733256816864
    z[2,1,1]  R798      3.6810505390167236e-01
    z[2,1,1]  R799      4.1212329268455505e-01
    z[2,1,1]  R800      5.1099520921707153e-01
    z[2,1,1]  R801      1.5516389906406403e-01
    z[2,1,1]  R802      3.5979580879211426e-01
    z[2,1,1]  R803      6.4920186996459961e-02
    z[2,1,1]  R804      3.4705594182014465e-01
    z[2,1,1]  R805      -2.2733153402805328e-01
    z[2,1,1]  R806      -1.5694728493690491e-01
    z[2,1,1]  R807      5.3272019140422344e-03
    z[2,1,1]  R808      1.8249194324016571e-01
    z[2,1,1]  R809      -2.9867708683013916e-01
    z[2,1,1]  R810      -1.2157098948955536e-01
    z[2,1,1]  R811      -6.7000240087509155e-01
    z[2,1,1]  R812      -5.6848609447479248e-01
    z[2,1,1]  R813      -0.54603111743927
    z[2,1,1]  R814      -3.9111602306365967e-01
    z[2,1,1]  R815      -3.1595990061759949e-01
    z[2,1,1]  R816      4.4881820678710938e-01
    z[2,1,1]  R817      -9.2467240989208221e-02
    z[2,1,1]  R818      -5.3211987018585205e-02
    z[2,1,1]  R819      -5.8870144188404083e-02
    z[2,1,1]  R820      -1.9726459681987762e-01
    z[2,1,1]  R821      2.0762990415096283e-01
    z[2,1,1]  R822      -1.7342941462993622e-01
    z[2,1,1]  R823      8.1048947572708130e-01
    z[2,1,1]  R824      -4.0847569704055786e-01
    z[2,1,1]  R825      6.9204968214035034e-01
    z[2,1,1]  R826      6.3707798719406128e-01
    z[2,1,1]  R827      7.3784333467483521e-01
    z[2,1,1]  R828      4.9446558952331543e-01
    z[2,1,1]  R829      4.8585602641105652e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R750      -1
    z[2,1,2]  R751      1
    z[2,1,2]  R760      6.4191657304763794e-01
    z[2,1,2]  R761      5.4716587066650391e-01
    z[2,1,2]  R762      4.7255662083625793e-01
    z[2,1,2]  R763      3.6511132121086121e-01
    z[2,1,2]  R764      5.3928568959236145e-02
    z[2,1,2]  R765      -4.6291261911392212e-01
    z[2,1,2]  R766      -6.8764805793762207e-01
    z[2,1,2]  R767      -3.6826652288436890e-01
    z[2,1,2]  R768      -4.5904904603958130e-01
    z[2,1,2]  R769      -9.3029528856277466e-01
    z[2,1,2]  R770      6.2224364280700684e-01
    z[2,1,2]  R771      3.3884134888648987e-01
    z[2,1,2]  R772      2.3745256662368774e-01
    z[2,1,2]  R773      6.0588216781616211e-01
    z[2,1,2]  R774      5.2405965328216553e-01
    z[2,1,2]  R775      5.2620679140090942e-01
    z[2,1,2]  R776      2.5405415892601013e-01
    z[2,1,2]  R777      2.0580118894577026e-01
    z[2,1,2]  R778      1.7980951070785522e-01
    z[2,1,2]  R779      1.2643806636333466e-01
    z[2,1,2]  R780      8.3968991041183472e-01
    z[2,1,2]  R781      3.6968412995338440e-01
    z[2,1,2]  R782      0.459505558013916
    z[2,1,2]  R783      7.1922683715820312e-01
    z[2,1,2]  R784      7.7588593959808350e-01
    z[2,1,2]  R785      4.2355218529701233e-01
    z[2,1,2]  R786      8.0315440893173218e-01
    z[2,1,2]  R787      3.7288326025009155e-01
    z[2,1,2]  R788      4.3731957674026489e-01
    z[2,1,2]  R789      6.7767697572708130e-01
    z[2,1,2]  R790      -5.0836914777755737e-01
    z[2,1,2]  R791      -4.2291939258575439e-01
    z[2,1,2]  R792      -4.8327657580375671e-01
    z[2,1,2]  R793      -5.7509851455688477e-01
    z[2,1,2]  R794      -6.9054877758026123e-01
    z[2,1,2]  R795      -4.6498143672943115e-01
    z[2,1,2]  R796      -2.6943698525428772e-01
    z[2,1,2]  R797      -0.669501543045044
    z[2,1,2]  R798      -5.2097642421722412e-01
    z[2,1,2]  R799      -5.3540790081024170e-01
    z[2,1,2]  R800      -3.6459747701883316e-02
    z[2,1,2]  R801      -1.4083737134933472e-01
    z[2,1,2]  R802      -2.3714843392372131e-01
    z[2,1,2]  R803      5.4901713132858276e-01
    z[2,1,2]  R804      6.1884272843599319e-02
    z[2,1,2]  R805      6.7300267517566681e-02
    z[2,1,2]  R806      -1.6915030777454376e-01
    z[2,1,2]  R807      1.6775536537170410e-01
    z[2,1,2]  R808      1.9526395201683044e-01
    z[2,1,2]  R809      8.6094796657562256e-02
    z[2,1,2]  R810      4.6372807025909424e-01
    z[2,1,2]  R811      -1.9680503010749817e-01
    z[2,1,2]  R812      8.0855436623096466e-02
    z[2,1,2]  R813      4.7880895435810089e-02
    z[2,1,2]  R814      2.1502092480659485e-01
    z[2,1,2]  R815      3.0873468518257141e-01
    z[2,1,2]  R816      5.2402138710021973e-01
    z[2,1,2]  R817      -4.4109621644020081e-01
    z[2,1,2]  R818      -0.150368332862854
    z[2,1,2]  R819      -3.0549362301826477e-01
    z[2,1,2]  R820      0.374489426612854
    z[2,1,2]  R821      5.0314950942993164e-01
    z[2,1,2]  R822      -2.0568031072616577e-01
    z[2,1,2]  R823      0.0821487233042717
    z[2,1,2]  R824      -8.9237973093986511e-02
    z[2,1,2]  R825      -3.8678056001663208e-01
    z[2,1,2]  R826      -5.2411282062530518e-01
    z[2,1,2]  R827      -3.7047600746154785e-01
    z[2,1,2]  R828      -0.631361186504364
    z[2,1,2]  R829      -4.3349912762641907e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R752      -1
    z[2,1,3]  R753      1
    z[2,1,3]  R760      3.7220796942710876e-01
    z[2,1,3]  R761      4.6839761734008789e-01
    z[2,1,3]  R762      1.6719271242618561e-01
    z[2,1,3]  R763      1.2000499665737152e-01
    z[2,1,3]  R764      2.8061398863792419e-01
    z[2,1,3]  R765      7.1794402599334717e-01
    z[2,1,3]  R766      5.9474724531173706e-01
    z[2,1,3]  R767      8.6313569545745850e-01
    z[2,1,3]  R768      4.6029153466224670e-01
    z[2,1,3]  R769      1.5579879283905029e-01
    z[2,1,3]  R770      -8.6404690518975258e-03
    z[2,1,3]  R771      -1.1484029702842236e-02
    z[2,1,3]  R772      7.7955529093742371e-02
    z[2,1,3]  R773      -1.7613553791306913e-04
    z[2,1,3]  R774      1.1394208669662476e-01
    z[2,1,3]  R775      2.9837839305400848e-02
    z[2,1,3]  R776      -4.2753354646265507e-03
    z[2,1,3]  R777      2.0318765193223953e-02
    z[2,1,3]  R778      -2.0815165340900421e-01
    z[2,1,3]  R779      -9.9909320473670959e-02
    z[2,1,3]  R780      -1.9909712672233582e-01
    z[2,1,3]  R781      -1.6519768536090851e-01
    z[2,1,3]  R782      2.0185695588588715e-01
    z[2,1,3]  R783      -2.7235820889472961e-01
    z[2,1,3]  R784      2.0207263529300690e-02
    z[2,1,3]  R785      -3.0750006437301636e-01
    z[2,1,3]  R786      2.9661837220191956e-01
    z[2,1,3]  R787      5.0223521888256073e-02
    z[2,1,3]  R788      0.077674001455307
    z[2,1,3]  R789      -4.4104721397161484e-02
    z[2,1,3]  R790      -6.4003534615039825e-02
    z[2,1,3]  R791      4.1698209941387177e-02
    z[2,1,3]  R792      7.3577851057052612e-02
    z[2,1,3]  R793      3.5545095801353455e-02
    z[2,1,3]  R794      3.1346008181571960e-01
    z[2,1,3]  R795      -1.4843994379043579e-01
    z[2,1,3]  R796      2.3004728555679321e-01
    z[2,1,3]  R797      4.4075345993041992e-01
    z[2,1,3]  R798      3.6550438404083252e-01
    z[2,1,3]  R799      3.0500376224517822e-01
    z[2,1,3]  R800      6.3105963170528412e-02
    z[2,1,3]  R801      6.1312373727560043e-03
    z[2,1,3]  R802      7.2842933237552643e-02
    z[2,1,3]  R803      -1.8690697848796844e-01
    z[2,1,3]  R804      -4.0619168430566788e-03
    z[2,1,3]  R805      -3.0977734923362732e-01
    z[2,1,3]  R806      -2.3131315410137177e-01
    z[2,1,3]  R807      -4.2744103074073792e-01
    z[2,1,3]  R808      -1.7304801940917969e-01
    z[2,1,3]  R809      -3.1542572379112244e-01
    z[2,1,3]  R810      -4.2001712322235107e-01
    z[2,1,3]  R811      -3.9449888467788696e-01
    z[2,1,3]  R812      -0.572258710861206
    z[2,1,3]  R813      -0.360209584236145
    z[2,1,3]  R814      -4.7984135150909424e-01
    z[2,1,3]  R815      -2.7646675705909729e-02
    z[2,1,3]  R816      5.0068624317646027e-02
    z[2,1,3]  R817      -3.8766807410866022e-03
    z[2,1,3]  R818      3.5247886180877686e-01
    z[2,1,3]  R819      1.8729597330093384e-01
    z[2,1,3]  R820      -3.0640000104904175e-01
    z[2,1,3]  R821      -2.9593247175216675e-01
    z[2,1,3]  R822      -1.3290596008300781e-01
    z[2,1,3]  R823      1.5202455222606659e-01
    z[2,1,3]  R824      -2.3024519905447960e-02
    z[2,1,3]  R825      5.6639021635055542e-01
    z[2,1,3]  R826      4.8683652281761169e-01
    z[2,1,3]  R827      4.5692732930183411e-01
    z[2,1,3]  R828      5.1947754621505737e-01
    z[2,1,3]  R829      6.1422526836395264e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R754      -1
    z[2,1,4]  R755      1
    z[2,1,4]  R760      2.6416091248393059e-02
    z[2,1,4]  R761      -3.3045294880867004e-01
    z[2,1,4]  R762      1.0801636381074786e-03
    z[2,1,4]  R763      -5.0684046000242233e-02
    z[2,1,4]  R764      -1.1764678172767162e-02
    z[2,1,4]  R765      -3.6642208695411682e-01
    z[2,1,4]  R766      -2.5889590382575989e-01
    z[2,1,4]  R767      2.6452008169144392e-03
    z[2,1,4]  R768      -5.5785093456506729e-02
    z[2,1,4]  R769      -6.1872941441833973e-03
    z[2,1,4]  R770      2.3640081286430359e-01
    z[2,1,4]  R771      -1.0277015715837479e-01
    z[2,1,4]  R772      4.2747011780738831e-01
    z[2,1,4]  R773      -1.0872618108987808e-01
    z[2,1,4]  R774      5.1522469520568848e-01
    z[2,1,4]  R775      1.4857383072376251e-01
    z[2,1,4]  R776      2.4948436766862869e-02
    z[2,1,4]  R777      3.2144007086753845e-01
    z[2,1,4]  R778      3.0023893713951111e-01
    z[2,1,4]  R779      -4.9544990062713623e-02
    z[2,1,4]  R780      -5.2067171782255173e-02
    z[2,1,4]  R781      -1.1456907959654927e-03
    z[2,1,4]  R782      -3.6360761523246765e-01
    z[2,1,4]  R783      3.8033846765756607e-02
    z[2,1,4]  R784      2.1731720864772797e-01
    z[2,1,4]  R785      2.2090306878089905e-01
    z[2,1,4]  R786      4.2820364236831665e-01
    z[2,1,4]  R787      2.2266179323196411e-01
    z[2,1,4]  R788      0.602392315864563
    z[2,1,4]  R789      4.5574018359184265e-01
    z[2,1,4]  R790      -4.7931659966707230e-02
    z[2,1,4]  R791      -5.3476560860872269e-02
    z[2,1,4]  R792      -2.7044081687927246e-01
    z[2,1,4]  R793      4.7364749014377594e-02
    z[2,1,4]  R794      -1.3396562635898590e-01
    z[2,1,4]  R795      -2.5589841604232788e-01
    z[2,1,4]  R796      9.7017228603363037e-02
    z[2,1,4]  R797      7.3426604270935059e-02
    z[2,1,4]  R798      1.8762914836406708e-01
    z[2,1,4]  R799      -1.4057025313377380e-01
    z[2,1,4]  R800      -3.0107897520065308e-01
    z[2,1,4]  R801      -2.0867292582988739e-01
    z[2,1,4]  R802      1.1813201010227203e-01
    z[2,1,4]  R803      2.3920483887195587e-02
    z[2,1,4]  R804      -0.0217477697879076
    z[2,1,4]  R805      -5.2040744572877884e-02
    z[2,1,4]  R806      1.6099634766578674e-01
    z[2,1,4]  R807      -3.1772014498710632e-01
    z[2,1,4]  R808      -4.4278463721275330e-01
    z[2,1,4]  R809      3.2765313982963562e-01
    z[2,1,4]  R810      -4.5414149761199951e-01
    z[2,1,4]  R811      3.1276699900627136e-01
    z[2,1,4]  R812      1.6534550487995148e-01
    z[2,1,4]  R813      4.7791969776153564e-01
    z[2,1,4]  R814      1.5253904461860657e-01
    z[2,1,4]  R815      2.6589216664433479e-02
    z[2,1,4]  R816      -2.1097426116466522e-01
    z[2,1,4]  R817      -1.6661521792411804e-01
    z[2,1,4]  R818      2.5000625848770142e-01
    z[2,1,4]  R819      2.3330490291118622e-01
    z[2,1,4]  R820      1.0494589060544968e-01
    z[2,1,4]  R821      -1.7684867978096008e-01
    z[2,1,4]  R822      -6.4213410019874573e-02
    z[2,1,4]  R823      -1.1015962064266205e-01
    z[2,1,4]  R824      2.4497982114553452e-02
    z[2,1,4]  R825      -4.0380254387855530e-02
    z[2,1,4]  R826      -1.8860971927642822e-01
    z[2,1,4]  R827      -1.6324110329151154e-01
    z[2,1,4]  R828      1.0699438303709030e-01
    z[2,1,4]  R829      3.3944758772850037e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R756      -1
    z[2,1,5]  R757      1
    z[2,1,5]  R760      2.3521322011947632e-01
    z[2,1,5]  R761      1.6307172179222107e-01
    z[2,1,5]  R762      -2.4484235048294067e-01
    z[2,1,5]  R763      3.0416178703308105e-01
    z[2,1,5]  R764      0.251397043466568
    z[2,1,5]  R765      1.6475871205329895e-01
    z[2,1,5]  R766      -1.5033662319183350e-01
    z[2,1,5]  R767      1.9075880944728851e-01
    z[2,1,5]  R768      5.6018787622451782e-01
    z[2,1,5]  R769      1.8015068769454956e-01
    z[2,1,5]  R770      -5.2143466472625732e-01
    z[2,1,5]  R771      -8.0909961462020874e-01
    z[2,1,5]  R772      -6.8678516149520874e-01
    z[2,1,5]  R773      -5.1308321952819824e-01
    z[2,1,5]  R774      -4.8027858138084412e-01
    z[2,1,5]  R775      -5.6475079059600830e-01
    z[2,1,5]  R776      -6.9524812698364258e-01
    z[2,1,5]  R777      -0.643557608127594
    z[2,1,5]  R778      -2.4108362197875977e-01
    z[2,1,5]  R779      2.2438602149486542e-01
    z[2,1,5]  R780      -2.6185715198516846e-01
    z[2,1,5]  R781      -2.4369697272777557e-01
    z[2,1,5]  R782      -3.0192995071411133e-01
    z[2,1,5]  R783      1.8738912418484688e-02
    z[2,1,5]  R784      -9.8352529108524323e-02
    z[2,1,5]  R785      3.9602303504943848e-01
    z[2,1,5]  R786      -2.1167115867137909e-01
    z[2,1,5]  R787      -2.9340144991874695e-01
    z[2,1,5]  R788      -3.5542976856231689e-01
    z[2,1,5]  R789      3.7708008289337158e-01
    z[2,1,5]  R790      5.5474311113357544e-02
    z[2,1,5]  R791      1.2986877560615540e-01
    z[2,1,5]  R792      -0.253933846950531
    z[2,1,5]  R793      -1.2982282042503357e-01
    z[2,1,5]  R794      3.5530611872673035e-01
    z[2,1,5]  R795      3.9429646730422974e-01
    z[2,1,5]  R796      -4.8040366172790527e-01
    z[2,1,5]  R797      3.2295471429824829e-01
    z[2,1,5]  R798      5.8690625429153442e-01
    z[2,1,5]  R799      4.4697627425193787e-01
    z[2,1,5]  R800      -7.2650724649429321e-01
    z[2,1,5]  R801      -7.7126610279083252e-01
    z[2,1,5]  R802      -8.5369080305099487e-01
    z[2,1,5]  R803      -1.0248441249132156e-01
    z[2,1,5]  R804      -1.0205791890621185e-01
    z[2,1,5]  R805      -4.4212377071380615e-01
    z[2,1,5]  R806      -7.9361595213413239e-02
    z[2,1,5]  R807      2.2805219888687134e-01
    z[2,1,5]  R808      -4.4459503889083862e-01
    z[2,1,5]  R809      2.0874033868312836e-01
    z[2,1,5]  R810      -4.3574118614196777e-01
    z[2,1,5]  R811      -8.1849955022335052e-02
    z[2,1,5]  R812      1.4777642488479614e-01
    z[2,1,5]  R813      4.7310128808021545e-01
    z[2,1,5]  R814      6.6230261325836182e-01
    z[2,1,5]  R815      -8.7718927860260010e-01
    z[2,1,5]  R816      1.3225401751697063e-02
    z[2,1,5]  R817      5.8165524154901505e-02
    z[2,1,5]  R818      -8.5439709946513176e-03
    z[2,1,5]  R819      3.7420755624771118e-01
    z[2,1,5]  R820      6.8470202386379242e-02
    z[2,1,5]  R821      2.9246711730957031e-01
    z[2,1,5]  R822      -5.9198802709579468e-01
    z[2,1,5]  R823      -0.0754462406039238
    z[2,1,5]  R824      -0.163039892911911
    z[2,1,5]  R825      -5.8868058025836945e-02
    z[2,1,5]  R826      -1.4028537273406982e-01
    z[2,1,5]  R827      2.8312322497367859e-01
    z[2,1,5]  R828      1.2301035970449448e-01
    z[2,1,5]  R829      1.2846863828599453e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R758      -1
    z[2,1,6]  R759      1
    z[2,1,6]  R760      -1.7870176816359162e-03
    z[2,1,6]  R761      -7.4849396944046021e-02
    z[2,1,6]  R762      -0.00873769260942936
    z[2,1,6]  R763      -3.3102288842201233e-02
    z[2,1,6]  R764      1.8266259133815765e-01
    z[2,1,6]  R765      -1.8044899404048920e-01
    z[2,1,6]  R766      -1.6020901501178741e-01
    z[2,1,6]  R767      2.0764118432998657e-01
    z[2,1,6]  R768      3.0501919984817505e-01
    z[2,1,6]  R769      1.5341801941394806e-01
    z[2,1,6]  R770      -2.0680311322212219e-01
    z[2,1,6]  R771      1.1379343271255493e-01
    z[2,1,6]  R772      0.097191721200943
    z[2,1,6]  R773      2.9394736886024475e-01
    z[2,1,6]  R774      2.1659180521965027e-01
    z[2,1,6]  R775      2.8197491168975830e-01
    z[2,1,6]  R776      -1.6610570251941681e-01
    z[2,1,6]  R777      4.8151633143424988e-01
    z[2,1,6]  R778      2.0062738656997681e-01
    z[2,1,6]  R779      3.5508644580841064e-01
    z[2,1,6]  R780      -5.4073341190814972e-02
    z[2,1,6]  R781      2.0596711337566376e-01
    z[2,1,6]  R782      -2.2136306762695312e-01
    z[2,1,6]  R783      5.1189702749252319e-01
    z[2,1,6]  R784      -2.7853175997734070e-01
    z[2,1,6]  R785      3.3431991934776306e-01
    z[2,1,6]  R786      6.7832171916961670e-02
    z[2,1,6]  R787      -5.8142983913421631e-01
    z[2,1,6]  R788      2.1421007812023163e-02
    z[2,1,6]  R789      -1.3646802306175232e-01
    z[2,1,6]  R790      2.2000966966152191e-01
    z[2,1,6]  R791      2.8514152765274048e-01
    z[2,1,6]  R792      -4.4002164155244827e-02
    z[2,1,6]  R793      -1.3049638271331787e-01
    z[2,1,6]  R794      -1.9374759867787361e-02
    z[2,1,6]  R795      -3.3459511399269104e-01
    z[2,1,6]  R796      6.5542489290237427e-01
    z[2,1,6]  R797      1.0579691082239151e-01
    z[2,1,6]  R798      3.1926054507493973e-02
    z[2,1,6]  R799      2.8151726722717285e-01
    z[2,1,6]  R800      -3.3550536632537842e-01
    z[2,1,6]  R801      -3.7513405084609985e-02
    z[2,1,6]  R802      -2.4722217023372650e-01
    z[2,1,6]  R803      -6.3602608442306519e-01
    z[2,1,6]  R804      1.0947944223880768e-01
    z[2,1,6]  R805      -4.2530137300491333e-01
    z[2,1,6]  R806      -4.5555481314659119e-01
    z[2,1,6]  R807      1.4421868324279785e-01
    z[2,1,6]  R808      -6.4467117190361023e-02
    z[2,1,6]  R809      -7.6031780242919922e-01
    z[2,1,6]  R810      -9.7609780728816986e-02
    z[2,1,6]  R811      4.9747385084629059e-02
    z[2,1,6]  R812      -3.0115723609924316e-01
    z[2,1,6]  R813      4.6444587409496307e-02
    z[2,1,6]  R814      0.199208065867424
    z[2,1,6]  R815      -0.180533766746521
    z[2,1,6]  R816      1.0107289999723434e-01
    z[2,1,6]  R817      -1.3805307447910309e-01
    z[2,1,6]  R818      1.9272369146347046e-01
    z[2,1,6]  R819      1.0131252929568291e-02
    z[2,1,6]  R820      1.2763187289237976e-01
    z[2,1,6]  R821      -0.486610472202301
    z[2,1,6]  R822      -6.3732050359249115e-02
    z[2,1,6]  R823      5.4153460264205933e-01
    z[2,1,6]  R824      3.8584148883819580e-01
    z[2,1,6]  R825      -3.3422295004129410e-02
    z[2,1,6]  R826      2.1657595410943031e-02
    z[2,1,6]  R827      2.6306835934519768e-02
    z[2,1,6]  R828      -1.7360873520374298e-01
    z[2,1,6]  R829      -2.8791844844818115e-01
    z[2,8,0]  R20       -1
    z[2,8,0]  R74       1
    z[2,8,0]  R830      -1
    z[2,8,0]  R831      1
    z[2,8,0]  R844      -8.6114391684532166e-02
    z[2,8,0]  R845      -2.6662680506706238e-01
    z[2,8,0]  R846      -5.2559429407119751e-01
    z[2,8,0]  R847      1.3804684579372406e-01
    z[2,8,0]  R848      -1.7923644185066223e-01
    z[2,8,0]  R849      2.6704484224319458e-01
    z[2,8,0]  R850      -9.4874203205108643e-02
    z[2,8,0]  R851      1.7659552395343781e-01
    z[2,8,0]  R852      3.6078906059265137e-01
    z[2,8,0]  R853      1.1271440237760544e-01
    z[2,8,0]  R854      1.9500410556793213e-01
    z[2,8,0]  R855      2.3636843264102936e-01
    z[2,8,0]  R856      3.1732618808746338e-01
    z[2,8,0]  R857      8.7245799601078033e-02
    z[2,8,0]  R858      1.6199515759944916e-01
    z[2,8,0]  R859      4.6486815810203552e-01
    z[2,8,0]  R860      -1.2235434353351593e-01
    z[2,8,0]  R861      -1.1196144670248032e-01
    z[2,8,0]  R862      -1.0307740420103073e-01
    z[2,8,0]  R863      -2.4501538276672363e-01
    z[2,8,0]  R864      -8.5061663389205933e-01
    z[2,8,0]  R865      -6.6478002071380615e-01
    z[2,8,0]  R866      -6.8220239877700806e-01
    z[2,8,0]  R867      -4.2338940501213074e-01
    z[2,8,0]  R868      -5.4683411121368408e-01
    z[2,8,0]  R869      3.4477461129426956e-02
    z[2,8,0]  R870      -1.3178817927837372e-01
    z[2,8,0]  R871      -1.1144463717937469e-01
    z[2,8,0]  R872      6.1237372457981110e-02
    z[2,8,0]  R873      1.2883530557155609e-01
    z[2,8,0]  R874      7.5623080134391785e-02
    z[2,8,0]  R875      2.0187151432037354e-01
    z[2,8,0]  R876      8.8159903883934021e-02
    z[2,8,0]  R877      1.7221964895725250e-01
    z[2,8,0]  R878      -3.8590118288993835e-01
    z[2,8,0]  R879      -2.1298557519912720e-01
    z[2,8,0]  R880      -3.4787435084581375e-02
    z[2,8,0]  R881      0.144593745470047
    z[2,8,0]  R882      -1.7110320925712585e-01
    z[2,8,0]  R883      -8.2352012395858765e-02
    z[2,8,0]  R884      -7.3613594286143780e-03
    z[2,8,0]  R885      2.2473397850990295e-01
    z[2,8,0]  R886      -4.5772069692611694e-01
    z[2,8,0]  R887      3.5058337450027466e-01
    z[2,8,0]  R888      -2.9376265406608582e-01
    z[2,8,0]  R889      -4.7494354844093323e-01
    z[2,8,0]  R890      -5.0987863540649414e-01
    z[2,8,0]  R891      1.2680661678314209e-01
    z[2,8,0]  R892      -4.7340753674507141e-01
    z[2,8,0]  R893      -5.9228497743606567e-01
    z[2,8,0]  R894      2.2725613415241241e-01
    z[2,8,0]  R895      1.6647150740027428e-02
    z[2,8,0]  R896      6.6248111426830292e-02
    z[2,8,0]  R897      4.9591418355703354e-02
    z[2,8,0]  R898      2.3875980079174042e-01
    z[2,8,0]  R899      -2.0266209542751312e-01
    z[2,8,0]  R900      1.8510530889034271e-01
    z[2,8,0]  R901      -9.6003741025924683e-02
    z[2,8,0]  R902      6.1135566234588623e-01
    z[2,8,0]  R903      -3.0051884055137634e-01
    z[2,8,0]  R904      8.3354108035564423e-02
    z[2,8,0]  R905      -9.0884536504745483e-02
    z[2,8,0]  R906      -3.9024937152862549e-01
    z[2,8,0]  R907      2.0824769139289856e-01
    z[2,8,0]  R908      0.728653073310852
    z[2,8,0]  R909      -1.0147596150636673e-01
    z[2,8,0]  R910      4.1850557923316956e-01
    z[2,8,0]  R911      7.3393404483795166e-01
    z[2,8,0]  R912      7.3931068181991577e-01
    z[2,8,0]  R913      7.7196583151817322e-02
    z[2,8,0]  R914      -1.5070086717605591e-01
    z[2,8,0]  R915      -5.3566700220108032e-01
    z[2,8,0]  R916      2.7248108386993408e-01
    z[2,8,0]  R917      2.2686022520065308e-01
    z[2,8,0]  R918      -1.8101686239242554e-01
    z[2,8,0]  R919      -0.244932159781456
    z[2,8,0]  R920      -5.3288701921701431e-02
    z[2,8,0]  R921      -4.9755790829658508e-01
    z[2,8,0]  R922      1.4224074780941010e-01
    z[2,8,0]  R923      -0.27867591381073
    z[2,8,0]  R924      -2.4550264701247215e-02
    z[2,8,0]  R925      2.1306996047496796e-01
    z[2,8,0]  R926      0.0872528925538063
    z[2,8,0]  R927      -5.5026117712259293e-02
    z[2,8,0]  R928      2.8675207495689392e-01
    z[2,8,0]  R929      7.4092823266983032e-01
    z[2,8,0]  R930      1.2137080729007721e-01
    z[2,8,0]  R931      -5.8641177415847778e-01
    z[2,8,0]  R932      9.0669281780719757e-02
    z[2,8,0]  R933      6.9981443881988525e-01
    z[2,8,0]  R934      -2.6681980118155479e-02
    z[2,8,0]  R935      -2.0519353449344635e-01
    z[2,8,0]  R936      6.7276817560195923e-01
    z[2,8,0]  R937      -2.2326491773128510e-01
    z[2,8,0]  R938      -4.3854388594627380e-01
    z[2,8,0]  R939      2.2516788914799690e-02
    z[2,8,0]  R940      -0.459357351064682
    z[2,8,0]  R941      -0.426647424697876
    z[2,8,0]  R942      -2.2971516475081444e-02
    z[2,8,0]  R943      2.5697913765907288e-01
    z[2,8,0]  R944      -5.2027054131031036e-02
    z[2,8,0]  R945      -4.7266975045204163e-02
    z[2,8,0]  R946      5.9770947694778442e-01
    z[2,8,0]  R947      3.8361188769340515e-01
    z[2,8,0]  R948      2.3431569337844849e-01
    z[2,8,0]  R949      5.1072686910629272e-02
    z[2,8,0]  R950      -1.3900332152843475e-01
    z[2,8,0]  R951      -1.7442011833190918e-01
    z[2,8,0]  R952      -2.9155322909355164e-01
    z[2,8,0]  R953      -3.0238136649131775e-01
    z[2,8,1]  R21       -1
    z[2,8,1]  R75       1
    z[2,8,1]  R832      -1
    z[2,8,1]  R833      1
    z[2,8,1]  R844      -6.2125867605209351e-01
    z[2,8,1]  R845      -5.1839131116867065e-01
    z[2,8,1]  R846      -6.4223206043243408e-01
    z[2,8,1]  R847      -8.5852009057998657e-01
    z[2,8,1]  R848      -8.8854783773422241e-01
    z[2,8,1]  R849      7.0590265095233917e-02
    z[2,8,1]  R850      -2.2162930667400360e-01
    z[2,8,1]  R851      9.3165911734104156e-02
    z[2,8,1]  R852      1.9307444989681244e-01
    z[2,8,1]  R853      -0.20382159948349
    z[2,8,1]  R854      4.5184570550918579e-01
    z[2,8,1]  R855      3.8862824440002441e-01
    z[2,8,1]  R856      4.1592359542846680e-01
    z[2,8,1]  R857      0.513628363609314
    z[2,8,1]  R858      3.7828582525253296e-01
    z[2,8,1]  R859      2.9255113005638123e-01
    z[2,8,1]  R860      6.3944053649902344e-01
    z[2,8,1]  R861      4.4198375940322876e-01
    z[2,8,1]  R862      8.5158699750900269e-01
    z[2,8,1]  R863      8.5738492012023926e-01
    z[2,8,1]  R864      -1.5238077938556671e-01
    z[2,8,1]  R865      -4.9546480178833008e-01
    z[2,8,1]  R866      -1.3301602005958557e-01
    z[2,8,1]  R867      -3.3557718992233276e-01
    z[2,8,1]  R868      -1.6564594209194183e-01
    z[2,8,1]  R869      -9.8058469593524933e-02
    z[2,8,1]  R870      1.6699803993105888e-02
    z[2,8,1]  R871      -2.0967480540275574e-01
    z[2,8,1]  R872      -3.4673564136028290e-02
    z[2,8,1]  R873      4.7680456191301346e-02
    z[2,8,1]  R874      8.7954843044281006e-01
    z[2,8,1]  R875      7.4665105342864990e-01
    z[2,8,1]  R876      7.5145530700683594e-01
    z[2,8,1]  R877      0.565773069858551
    z[2,8,1]  R878      5.5502235889434814e-01
    z[2,8,1]  R879      6.4108473062515259e-01
    z[2,8,1]  R880      -8.4837704896926880e-02
    z[2,8,1]  R881      5.5654048919677734e-01
    z[2,8,1]  R882      -5.7708561420440674e-01
    z[2,8,1]  R883      6.4547479152679443e-01
    z[2,8,1]  R884      7.9739069938659668e-01
    z[2,8,1]  R885      7.3832303285598755e-01
    z[2,8,1]  R886      6.4866358041763306e-01
    z[2,8,1]  R887      6.1946231126785278e-01
    z[2,8,1]  R888      7.0504951477050781e-01
    z[2,8,1]  R889      6.8237692117691040e-01
    z[2,8,1]  R890      5.7485276460647583e-01
    z[2,8,1]  R891      0.730842649936676
    z[2,8,1]  R892      7.4944311380386353e-01
    z[2,8,1]  R893      5.7339757680892944e-01
    z[2,8,1]  R894      8.4325706958770752e-01
    z[2,8,1]  R895      6.8030416965484619e-01
    z[2,8,1]  R896      -2.7212768793106079e-01
    z[2,8,1]  R897      -6.3387066125869751e-02
    z[2,8,1]  R898      2.7062773704528809e-02
    z[2,8,1]  R899      2.5001174211502075e-01
    z[2,8,1]  R900      -2.7819997072219849e-01
    z[2,8,1]  R901      -4.0184023976325989e-01
    z[2,8,1]  R902      -8.2699873019009829e-04
    z[2,8,1]  R903      -9.4911180436611176e-02
    z[2,8,1]  R904      6.2830311059951782e-01
    z[2,8,1]  R905      6.0234630107879639e-01
    z[2,8,1]  R906      6.5705102682113647e-01
    z[2,8,1]  R907      3.5974937677383423e-01
    z[2,8,1]  R908      9.5749676227569580e-02
    z[2,8,1]  R909      -4.8531722277402878e-02
    z[2,8,1]  R910      -3.8195803761482239e-01
    z[2,8,1]  R911      7.5192131102085114e-02
    z[2,8,1]  R912      1.3157719373703003e-01
    z[2,8,1]  R913      -3.1927531957626343e-01
    z[2,8,1]  R914      7.9016172885894775e-01
    z[2,8,1]  R915      8.2258272171020508e-01
    z[2,8,1]  R916      8.8666254281997681e-01
    z[2,8,1]  R917      7.5900465250015259e-01
    z[2,8,1]  R918      0.809294581413269
    z[2,8,1]  R919      5.1300019025802612e-01
    z[2,8,1]  R920      7.6782727241516113e-01
    z[2,8,1]  R921      5.9720373153686523e-01
    z[2,8,1]  R922      1.5615494549274445e-01
    z[2,8,1]  R923      -1.3358376920223236e-01
    z[2,8,1]  R924      3.1324383616447449e-01
    z[2,8,1]  R925      7.7548390626907349e-01
    z[2,8,1]  R926      1.7036555707454681e-01
    z[2,8,1]  R927      -4.1772177815437317e-01
    z[2,8,1]  R928      -0.253431499004364
    z[2,8,1]  R929      2.1579198539257050e-01
    z[2,8,1]  R930      1.3170754909515381e-01
    z[2,8,1]  R931      -3.4229966998100281e-01
    z[2,8,1]  R932      2.3952980339527130e-01
    z[2,8,1]  R933      1.8633915483951569e-01
    z[2,8,1]  R934      6.8395271897315979e-02
    z[2,8,1]  R935      -5.6348246335983276e-01
    z[2,8,1]  R936      2.7041158080101013e-01
    z[2,8,1]  R937      -2.5729942321777344e-01
    z[2,8,1]  R938      -0.0911824107170105
    z[2,8,1]  R939      6.5456062555313110e-02
    z[2,8,1]  R940      -1.0315380990505219e-01
    z[2,8,1]  R941      -2.5617891550064087e-01
    z[2,8,1]  R942      -2.3504646122455597e-01
    z[2,8,1]  R943      -1.7841754853725433e-01
    z[2,8,1]  R944      -1.6186280548572540e-01
    z[2,8,1]  R945      8.3938315510749817e-02
    z[2,8,1]  R946      1.8751224875450134e-01
    z[2,8,1]  R947      4.7296587377786636e-02
    z[2,8,1]  R948      -8.9162372052669525e-02
    z[2,8,1]  R949      -9.0641617774963379e-01
    z[2,8,1]  R950      -8.6645781993865967e-01
    z[2,8,1]  R951      -8.3836305141448975e-01
    z[2,8,1]  R952      -9.1352224349975586e-01
    z[2,8,1]  R953      -8.3615368604660034e-01
    z[2,8,2]  R22       -1
    z[2,8,2]  R76       1
    z[2,8,2]  R834      -1
    z[2,8,2]  R835      1
    z[2,8,2]  R844      6.4191657304763794e-01
    z[2,8,2]  R845      5.4716587066650391e-01
    z[2,8,2]  R846      4.7255662083625793e-01
    z[2,8,2]  R847      3.6511132121086121e-01
    z[2,8,2]  R848      5.3928568959236145e-02
    z[2,8,2]  R849      -4.6291261911392212e-01
    z[2,8,2]  R850      -6.8764805793762207e-01
    z[2,8,2]  R851      -3.6826652288436890e-01
    z[2,8,2]  R852      -4.5904904603958130e-01
    z[2,8,2]  R853      -9.3029528856277466e-01
    z[2,8,2]  R854      6.2224364280700684e-01
    z[2,8,2]  R855      3.3884134888648987e-01
    z[2,8,2]  R856      2.3745256662368774e-01
    z[2,8,2]  R857      6.0588216781616211e-01
    z[2,8,2]  R858      5.2405965328216553e-01
    z[2,8,2]  R859      5.2620679140090942e-01
    z[2,8,2]  R860      2.5405415892601013e-01
    z[2,8,2]  R861      2.0580118894577026e-01
    z[2,8,2]  R862      1.7980951070785522e-01
    z[2,8,2]  R863      1.2643806636333466e-01
    z[2,8,2]  R864      4.7955888509750366e-01
    z[2,8,2]  R865      5.2574193477630615e-01
    z[2,8,2]  R866      0.565449595451355
    z[2,8,2]  R867      8.1553924083709717e-01
    z[2,8,2]  R868      6.4739727973937988e-01
    z[2,8,2]  R869      -3.7284132838249207e-01
    z[2,8,2]  R870      -1.2426032125949860e-01
    z[2,8,2]  R871      -1.4245571196079254e-01
    z[2,8,2]  R872      -0.0619538351893425
    z[2,8,2]  R873      1.6244810819625854e-01
    z[2,8,2]  R874      -5.9567335993051529e-02
    z[2,8,2]  R875      4.6708053350448608e-01
    z[2,8,2]  R876      2.3357817530632019e-01
    z[2,8,2]  R877      -2.5872397422790527e-01
    z[2,8,2]  R878      -3.5164999961853027e-01
    z[2,8,2]  R879      0.294384241104126
    z[2,8,2]  R880      -3.7575873732566833e-01
    z[2,8,2]  R881      -6.5847319364547729e-01
    z[2,8,2]  R882      -2.9010412096977234e-01
    z[2,8,2]  R883      -2.9292309284210205e-01
    z[2,8,2]  R884      -0.102711021900177
    z[2,8,2]  R885      -2.1386066079139709e-01
    z[2,8,2]  R886      -0.245735302567482
    z[2,8,2]  R887      -4.9894452095031738e-01
    z[2,8,2]  R888      -1.9249689579010010e-01
    z[2,8,2]  R889      2.5324749946594238e-01
    z[2,8,2]  R890      -3.1486704945564270e-01
    z[2,8,2]  R891      -2.2246772050857544e-01
    z[2,8,2]  R892      3.6608977243304253e-03
    z[2,8,2]  R893      -3.7173548340797424e-01
    z[2,8,2]  R894      -1.9826452434062958e-01
    z[2,8,2]  R895      3.0065628886222839e-01
    z[2,8,2]  R896      -5.4874461889266968e-01
    z[2,8,2]  R897      1.2436462938785553e-01
    z[2,8,2]  R898      -2.1571689844131470e-01
    z[2,8,2]  R899      6.0266986489295959e-02
    z[2,8,2]  R900      1.3241645693778992e-01
    z[2,8,2]  R901      -7.5738435983657837e-01
    z[2,8,2]  R902      -4.2077675461769104e-01
    z[2,8,2]  R903      -8.3095115423202515e-01
    z[2,8,2]  R904      1.3665291666984558e-01
    z[2,8,2]  R905      -4.5909079909324646e-01
    z[2,8,2]  R906      9.8254293203353882e-02
    z[2,8,2]  R907      -4.2626655101776123e-01
    z[2,8,2]  R908      1.3493350148200989e-01
    z[2,8,2]  R909      -3.0118385329842567e-02
    z[2,8,2]  R910      -0.602405846118927
    z[2,8,2]  R911      -3.7822088599205017e-01
    z[2,8,2]  R912      -1.4436319470405579e-01
    z[2,8,2]  R913      -0.777163565158844
    z[2,8,2]  R914      -4.3973001837730408e-01
    z[2,8,2]  R915      -6.8632923066616058e-02
    z[2,8,2]  R916      3.4726104140281677e-01
    z[2,8,2]  R917      1.0989388078451157e-01
    z[2,8,2]  R918      2.4211842101067305e-03
    z[2,8,2]  R919      9.6697226166725159e-02
    z[2,8,2]  R920      2.7760079503059387e-01
    z[2,8,2]  R921      -1.9307935237884521e-01
    z[2,8,2]  R922      7.6088112592697144e-01
    z[2,8,2]  R923      0.29134401679039
    z[2,8,2]  R924      -2.4838103353977203e-01
    z[2,8,2]  R925      1.2162237614393234e-01
    z[2,8,2]  R926      8.0715399980545044e-01
    z[2,8,2]  R927      -0.432815819978714
    z[2,8,2]  R928      -8.0312824249267578e-01
    z[2,8,2]  R929      -2.5108432769775391e-01
    z[2,8,2]  R930      -2.9693427681922913e-01
    z[2,8,2]  R931      -5.6551790237426758e-01
    z[2,8,2]  R932      1.9435006380081177e-01
    z[2,8,2]  R933      -1.7551237344741821e-01
    z[2,8,2]  R934      -6.7357398569583893e-02
    z[2,8,2]  R935      -5.7572543621063232e-01
    z[2,8,2]  R936      -2.7424991130828857e-01
    z[2,8,2]  R937      1.4285388588905334e-01
    z[2,8,2]  R938      3.7022361159324646e-01
    z[2,8,2]  R939      -6.6915291547775269e-01
    z[2,8,2]  R940      1.1230655014514923e-01
    z[2,8,2]  R941      -1.3322305679321289e-01
    z[2,8,2]  R942      -6.1300748586654663e-01
    z[2,8,2]  R943      2.2271849215030670e-01
    z[2,8,2]  R944      -4.7684401273727417e-02
    z[2,8,2]  R945      -1.5192721784114838e-01
    z[2,8,2]  R946      -3.2909657806158066e-02
    z[2,8,2]  R947      3.5245963931083679e-01
    z[2,8,2]  R948      0.0596194826066494
    z[2,8,2]  R949      -3.6621391773223877e-01
    z[2,8,2]  R950      -3.6664634943008423e-01
    z[2,8,2]  R951      -3.6266416311264038e-01
    z[2,8,2]  R952      -1.9708488881587982e-01
    z[2,8,2]  R953      -2.6363670825958252e-01
    z[2,8,3]  R23       -1
    z[2,8,3]  R77       1
    z[2,8,3]  R836      -1
    z[2,8,3]  R837      1
    z[2,8,3]  R844      3.7220796942710876e-01
    z[2,8,3]  R845      4.6839761734008789e-01
    z[2,8,3]  R846      1.6719271242618561e-01
    z[2,8,3]  R847      1.2000499665737152e-01
    z[2,8,3]  R848      2.8061398863792419e-01
    z[2,8,3]  R849      7.1794402599334717e-01
    z[2,8,3]  R850      5.9474724531173706e-01
    z[2,8,3]  R851      8.6313569545745850e-01
    z[2,8,3]  R852      4.6029153466224670e-01
    z[2,8,3]  R853      1.5579879283905029e-01
    z[2,8,3]  R854      -8.6404690518975258e-03
    z[2,8,3]  R855      -1.1484029702842236e-02
    z[2,8,3]  R856      7.7955529093742371e-02
    z[2,8,3]  R857      -1.7613553791306913e-04
    z[2,8,3]  R858      1.1394208669662476e-01
    z[2,8,3]  R859      2.9837839305400848e-02
    z[2,8,3]  R860      -4.2753354646265507e-03
    z[2,8,3]  R861      2.0318765193223953e-02
    z[2,8,3]  R862      -2.0815165340900421e-01
    z[2,8,3]  R863      -9.9909320473670959e-02
    z[2,8,3]  R864      2.5020893663167953e-02
    z[2,8,3]  R865      -2.0159909501671791e-02
    z[2,8,3]  R866      -2.4972374737262726e-01
    z[2,8,3]  R867      2.0682762563228607e-01
    z[2,8,3]  R868      8.6605958640575409e-02
    z[2,8,3]  R869      8.7584728002548218e-01
    z[2,8,3]  R870      0.886455774307251
    z[2,8,3]  R871      7.7952551841735840e-01
    z[2,8,3]  R872      6.8842327594757080e-01
    z[2,8,3]  R873      7.6254725456237793e-01
    z[2,8,3]  R874      -2.1076574921607971e-01
    z[2,8,3]  R875      1.7412135004997253e-01
    z[2,8,3]  R876      2.5826262310147285e-02
    z[2,8,3]  R877      1.6320027410984039e-01
    z[2,8,3]  R878      2.8141847252845764e-01
    z[2,8,3]  R879      3.7003250326961279e-03
    z[2,8,3]  R880      -0.00538968201726675
    z[2,8,3]  R881      2.6330480352044106e-02
    z[2,8,3]  R882      -1.0333186388015747e-01
    z[2,8,3]  R883      1.6312251985073090e-01
    z[2,8,3]  R884      6.8231053650379181e-02
    z[2,8,3]  R885      0.591113269329071
    z[2,8,3]  R886      -1.8255592882633209e-01
    z[2,8,3]  R887      0.0961490273475647
    z[2,8,3]  R888      -1.9007220864295959e-01
    z[2,8,3]  R889      2.4882838129997253e-01
    z[2,8,3]  R890      2.1823190152645111e-01
    z[2,8,3]  R891      -1.9260866940021515e-01
    z[2,8,3]  R892      -0.00952579453587532
    z[2,8,3]  R893      -2.9420253634452820e-01
    z[2,8,3]  R894      1.9434593617916107e-01
    z[2,8,3]  R895      -3.4812459349632263e-01
    z[2,8,3]  R896      2.1785824000835419e-01
    z[2,8,3]  R897      -6.4719247817993164e-01
    z[2,8,3]  R898      -7.3756092786788940e-01
    z[2,8,3]  R899      -8.5562056303024292e-01
    z[2,8,3]  R900      -0.709907591342926
    z[2,8,3]  R901      2.2079738974571228e-01
    z[2,8,3]  R902      3.9861035346984863e-01
    z[2,8,3]  R903      -8.2400523126125336e-02
    z[2,8,3]  R904      4.2890876531600952e-01
    z[2,8,3]  R905      -1.1907821148633957e-01
    z[2,8,3]  R906      -3.1710562109947205e-01
    z[2,8,3]  R907      4.3346762657165527e-01
    z[2,8,3]  R908      5.7884871959686279e-01
    z[2,8,3]  R909      -8.2855713367462158e-01
    z[2,8,3]  R910      2.7887905016541481e-02
    z[2,8,3]  R911      3.4898456931114197e-01
    z[2,8,3]  R912      3.9520654082298279e-01
    z[2,8,3]  R913      1.0373300313949585e-01
    z[2,8,3]  R914      2.6181671023368835e-01
    z[2,8,3]  R915      3.0752778053283691e-02
    z[2,8,3]  R916      -1.0336022078990936e-01
    z[2,8,3]  R917      -1.0176008194684982e-01
    z[2,8,3]  R918      -1.9595865160226822e-02
    z[2,8,3]  R919      5.7871639728546143e-01
    z[2,8,3]  R920      4.3673789501190186e-01
    z[2,8,3]  R921      2.7254721149802208e-02
    z[2,8,3]  R922      -5.4215413331985474e-01
    z[2,8,3]  R923      3.5157926380634308e-02
    z[2,8,3]  R924      8.2601845264434814e-01
    z[2,8,3]  R925      4.0940120816230774e-01
    z[2,8,3]  R926      -4.6199521422386169e-01
    z[2,8,3]  R927      3.7539044022560120e-01
    z[2,8,3]  R928      9.1040439903736115e-02
    z[2,8,3]  R929      4.2059344053268433e-01
    z[2,8,3]  R930      -4.6221151947975159e-01
    z[2,8,3]  R931      7.8479431569576263e-02
    z[2,8,3]  R932      -0.835407018661499
    z[2,8,3]  R933      4.3667939305305481e-01
    z[2,8,3]  R934      8.7394517660140991e-01
    z[2,8,3]  R935      3.2051730155944824e-01
    z[2,8,3]  R936      4.9250802397727966e-01
    z[2,8,3]  R937      -7.9185032844543457e-01
    z[2,8,3]  R938      1.9741542637348175e-01
    z[2,8,3]  R939      4.6691466122865677e-03
    z[2,8,3]  R940      -4.7329258918762207e-01
    z[2,8,3]  R941      -4.7493028640747070e-01
    z[2,8,3]  R942      -3.6188460886478424e-02
    z[2,8,3]  R943      -2.6878905296325684e-01
    z[2,8,3]  R944      -6.1702221632003784e-01
    z[2,8,3]  R945      -7.4480628967285156e-01
    z[2,8,3]  R946      0.576059877872467
    z[2,8,3]  R947      -4.5782437920570374e-01
    z[2,8,3]  R948      5.5540060997009277e-01
    z[2,8,3]  R949      -3.3231852576136589e-03
    z[2,8,3]  R950      1.4756141602993011e-01
    z[2,8,3]  R951      -2.0093291997909546e-01
    z[2,8,3]  R952      -1.4315296709537506e-01
    z[2,8,3]  R953      2.6009619235992432e-01
    z[2,8,4]  R24       -1
    z[2,8,4]  R78       1
    z[2,8,4]  R838      -1
    z[2,8,4]  R839      1
    z[2,8,4]  R844      2.6416091248393059e-02
    z[2,8,4]  R845      -3.3045294880867004e-01
    z[2,8,4]  R846      1.0801636381074786e-03
    z[2,8,4]  R847      -5.0684046000242233e-02
    z[2,8,4]  R848      -1.1764678172767162e-02
    z[2,8,4]  R849      -3.6642208695411682e-01
    z[2,8,4]  R850      -2.5889590382575989e-01
    z[2,8,4]  R851      2.6452008169144392e-03
    z[2,8,4]  R852      -5.5785093456506729e-02
    z[2,8,4]  R853      -6.1872941441833973e-03
    z[2,8,4]  R854      2.3640081286430359e-01
    z[2,8,4]  R855      -1.0277015715837479e-01
    z[2,8,4]  R856      4.2747011780738831e-01
    z[2,8,4]  R857      -1.0872618108987808e-01
    z[2,8,4]  R858      5.1522469520568848e-01
    z[2,8,4]  R859      1.4857383072376251e-01
    z[2,8,4]  R860      2.4948436766862869e-02
    z[2,8,4]  R861      3.2144007086753845e-01
    z[2,8,4]  R862      3.0023893713951111e-01
    z[2,8,4]  R863      -4.9544990062713623e-02
    z[2,8,4]  R864      -6.0702785849571228e-02
    z[2,8,4]  R865      -1.6370341181755066e-01
    z[2,8,4]  R866      -2.1409824490547180e-01
    z[2,8,4]  R867      -1.0911155492067337e-02
    z[2,8,4]  R868      -1.8714027106761932e-01
    z[2,8,4]  R869      -2.6003894209861755e-01
    z[2,8,4]  R870      4.6505674719810486e-02
    z[2,8,4]  R871      -5.3447896242141724e-01
    z[2,8,4]  R872      -0.631626546382904
    z[2,8,4]  R873      -6.0656398534774780e-01
    z[2,8,4]  R874      3.8101791869848967e-03
    z[2,8,4]  R875      -1.3773700594902039e-01
    z[2,8,4]  R876      -2.6488479971885681e-01
    z[2,8,4]  R877      5.4444384574890137e-01
    z[2,8,4]  R878      2.2349333763122559e-01
    z[2,8,4]  R879      5.1280868053436279e-01
    z[2,8,4]  R880      -4.9400264024734497e-01
    z[2,8,4]  R881      2.6858943700790405e-01
    z[2,8,4]  R882      -0.381608247756958
    z[2,8,4]  R883      0.672268271446228
    z[2,8,4]  R884      -4.3929553031921387e-01
    z[2,8,4]  R885      6.3479013741016388e-02
    z[2,8,4]  R886      -3.5290178656578064e-01
    z[2,8,4]  R887      -2.2511450946331024e-01
    z[2,8,4]  R888      2.7396363019943237e-01
    z[2,8,4]  R889      -0.324464350938797
    z[2,8,4]  R890      -4.2967510223388672e-01
    z[2,8,4]  R891      2.7419865131378174e-01
    z[2,8,4]  R892      3.5170897841453552e-01
    z[2,8,4]  R893      -2.0574498921632767e-03
    z[2,8,4]  R894      5.4170109331607819e-02
    z[2,8,4]  R895      -5.3116941452026367e-01
    z[2,8,4]  R896      -4.3936005234718323e-01
    z[2,8,4]  R897      2.3174965381622314e-01
    z[2,8,4]  R898      1.9797667860984802e-01
    z[2,8,4]  R899      2.7299249172210693e-01
    z[2,8,4]  R900      3.4672826528549194e-01
    z[2,8,4]  R901      0.256306916475296
    z[2,8,4]  R902      1.2066429853439331e-01
    z[2,8,4]  R903      4.5660361647605896e-02
    z[2,8,4]  R904      -6.1327022314071655e-01
    z[2,8,4]  R905      5.9897321462631226e-01
    z[2,8,4]  R906      4.8401924967765808e-01
    z[2,8,4]  R907      8.9172385632991791e-02
    z[2,8,4]  R908      1.9298788160085678e-02
    z[2,8,4]  R909      9.8577544093132019e-02
    z[2,8,4]  R910      -1.0599945485591888e-01
    z[2,8,4]  R911      3.6982879042625427e-01
    z[2,8,4]  R912      1.7723430693149567e-01
    z[2,8,4]  R913      -4.5534770935773849e-02
    z[2,8,4]  R914      -5.9796366840600967e-02
    z[2,8,4]  R915      -1.6417492926120758e-01
    z[2,8,4]  R916      -9.0975128114223480e-02
    z[2,8,4]  R917      5.3408050537109375e-01
    z[2,8,4]  R918      0.520047664642334
    z[2,8,4]  R919      -5.3054285049438477e-01
    z[2,8,4]  R920      -2.5470888614654541e-01
    z[2,8,4]  R921      4.0219381451606750e-01
    z[2,8,4]  R922      -3.1121345236897469e-02
    z[2,8,4]  R923      3.2903265953063965e-01
    z[2,8,4]  R924      -5.1761273294687271e-02
    z[2,8,4]  R925      -3.8550980389118195e-02
    z[2,8,4]  R926      -4.5182496309280396e-02
    z[2,8,4]  R927      -3.6956712603569031e-01
    z[2,8,4]  R928      -1.3292072713375092e-01
    z[2,8,4]  R929      -1.8835441768169403e-01
    z[2,8,4]  R930      5.5422937870025635e-01
    z[2,8,4]  R931      -1.3107995688915253e-01
    z[2,8,4]  R932      2.4477869272232056e-01
    z[2,8,4]  R933      4.5653986930847168e-01
    z[2,8,4]  R934      -1.4539791643619537e-01
    z[2,8,4]  R935      -2.5600489974021912e-01
    z[2,8,4]  R936      -2.0681457221508026e-01
    z[2,8,4]  R937      4.1539192199707031e-01
    z[2,8,4]  R938      -4.3201935291290283e-01
    z[2,8,4]  R939      2.6885172724723816e-01
    z[2,8,4]  R940      5.6846636533737183e-01
    z[2,8,4]  R941      6.3694953918457031e-01
    z[2,8,4]  R942      5.3225511312484741e-01
    z[2,8,4]  R943      2.6034596562385559e-01
    z[2,8,4]  R944      4.3744844198226929e-01
    z[2,8,4]  R945      1.2768211960792542e-01
    z[2,8,4]  R946      4.9454993009567261e-01
    z[2,8,4]  R947      5.9390527009963989e-01
    z[2,8,4]  R948      4.8084896802902222e-01
    z[2,8,4]  R949      1.5543513000011444e-01
    z[2,8,4]  R950      -1.1964630335569382e-02
    z[2,8,4]  R951      2.3769660294055939e-01
    z[2,8,4]  R952      -6.2905423343181610e-02
    z[2,8,4]  R953      2.1035051345825195e-01
    z[2,8,5]  R25       -1
    z[2,8,5]  R79       1
    z[2,8,5]  R840      -1
    z[2,8,5]  R841      1
    z[2,8,5]  R844      2.3521322011947632e-01
    z[2,8,5]  R845      1.6307172179222107e-01
    z[2,8,5]  R846      -2.4484235048294067e-01
    z[2,8,5]  R847      3.0416178703308105e-01
    z[2,8,5]  R848      0.251397043466568
    z[2,8,5]  R849      1.6475871205329895e-01
    z[2,8,5]  R850      -1.5033662319183350e-01
    z[2,8,5]  R851      1.9075880944728851e-01
    z[2,8,5]  R852      5.6018787622451782e-01
    z[2,8,5]  R853      1.8015068769454956e-01
    z[2,8,5]  R854      -5.2143466472625732e-01
    z[2,8,5]  R855      -8.0909961462020874e-01
    z[2,8,5]  R856      -6.8678516149520874e-01
    z[2,8,5]  R857      -5.1308321952819824e-01
    z[2,8,5]  R858      -4.8027858138084412e-01
    z[2,8,5]  R859      -5.6475079059600830e-01
    z[2,8,5]  R860      -6.9524812698364258e-01
    z[2,8,5]  R861      -0.643557608127594
    z[2,8,5]  R862      -2.4108362197875977e-01
    z[2,8,5]  R863      2.2438602149486542e-01
    z[2,8,5]  R864      -1.3654959201812744e-01
    z[2,8,5]  R865      -9.2440247535705566e-02
    z[2,8,5]  R866      1.0115293785929680e-02
    z[2,8,5]  R867      1.0998719371855259e-02
    z[2,8,5]  R868      1.2060520052909851e-01
    z[2,8,5]  R869      -9.4037890434265137e-02
    z[2,8,5]  R870      -3.7226337194442749e-01
    z[2,8,5]  R871      -1.7053464055061340e-01
    z[2,8,5]  R872      -3.1147161126136780e-01
    z[2,8,5]  R873      -2.4714589118957520e-02
    z[2,8,5]  R874      -3.2154834270477295e-01
    z[2,8,5]  R875      2.6955306529998779e-01
    z[2,8,5]  R876      -5.3265053033828735e-01
    z[2,8,5]  R877      1.7484933137893677e-01
    z[2,8,5]  R878      1.6320532560348511e-01
    z[2,8,5]  R879      -2.1414074301719666e-01
    z[2,8,5]  R880      7.7239155769348145e-01
    z[2,8,5]  R881      1.3511365652084351e-01
    z[2,8,5]  R882      6.2932890653610229e-01
    z[2,8,5]  R883      -2.1945912390947342e-02
    z[2,8,5]  R884      3.3637553453445435e-01
    z[2,8,5]  R885      6.4657934010028839e-02
    z[2,8,5]  R886      3.4015449881553650e-01
    z[2,8,5]  R887      -1.7019546031951904e-01
    z[2,8,5]  R888      5.1290357112884521e-01
    z[2,8,5]  R889      -2.0324380695819855e-01
    z[2,8,5]  R890      -1.7839151620864868e-01
    z[2,8,5]  R891      5.2952367067337036e-01
    z[2,8,5]  R892      1.2697046995162964e-01
    z[2,8,5]  R893      -2.0534142851829529e-01
    z[2,8,5]  R894      3.8339513540267944e-01
    z[2,8,5]  R895      -6.2285237014293671e-02
    z[2,8,5]  R896      4.9384722113609314e-01
    z[2,8,5]  R897      7.0507985353469849e-01
    z[2,8,5]  R898      4.7425702214241028e-01
    z[2,8,5]  R899      2.9225319623947144e-01
    z[2,8,5]  R900      4.9426114559173584e-01
    z[2,8,5]  R901      3.1892961263656616e-01
    z[2,8,5]  R902      4.8496076464653015e-01
    z[2,8,5]  R903      4.0534928441047668e-01
    z[2,8,5]  R904      1.6330938786268234e-02
    z[2,8,5]  R905      1.9894470274448395e-01
    z[2,8,5]  R906      -1.7619448900222778e-01
    z[2,8,5]  R907      -5.9015041589736938e-01
    z[2,8,5]  R908      3.0861091613769531e-01
    z[2,8,5]  R909      5.2670252323150635e-01
    z[2,8,5]  R910      0.238073468208313
    z[2,8,5]  R911      7.0517018437385559e-02
    z[2,8,5]  R912      -4.1556927561759949e-01
    z[2,8,5]  R913      1.5158849954605103e-01
    z[2,8,5]  R914      -1.3737757503986359e-01
    z[2,8,5]  R915      5.3427174687385559e-02
    z[2,8,5]  R916      2.3475063499063253e-03
    z[2,8,5]  R917      -2.4367213249206543e-01
    z[2,8,5]  R918      -3.1883720308542252e-02
    z[2,8,5]  R919      -0.221435084939003
    z[2,8,5]  R920      -2.3268258571624756e-01
    z[2,8,5]  R921      -4.3591648340225220e-01
    z[2,8,5]  R922      9.1966040432453156e-02
    z[2,8,5]  R923      8.3843415975570679e-01
    z[2,8,5]  R924      -3.9317813515663147e-01
    z[2,8,5]  R925      -4.1142249107360840e-01
    z[2,8,5]  R926      1.2930651009082794e-01
    z[2,8,5]  R927      5.8101141452789307e-01
    z[2,8,5]  R928      4.9192342907190323e-02
    z[2,8,5]  R929      3.4624036401510239e-02
    z[2,8,5]  R930      5.9644037485122681e-01
    z[2,8,5]  R931      4.2838081717491150e-01
    z[2,8,5]  R932      3.7177410721778870e-01
    z[2,8,5]  R933      -2.0003531873226166e-01
    z[2,8,5]  R934      -4.4080230593681335e-01
    z[2,8,5]  R935      0.372408926486969
    z[2,8,5]  R936      6.6106610000133514e-02
    z[2,8,5]  R937      2.1512353420257568e-01
    z[2,8,5]  R938      -6.4128667116165161e-01
    z[2,8,5]  R939      5.8276677131652832e-01
    z[2,8,5]  R940      2.9139328002929688e-01
    z[2,8,5]  R941      2.3616470396518707e-01
    z[2,8,5]  R942      3.9361339807510376e-01
    z[2,8,5]  R943      0.679141640663147
    z[2,8,5]  R944      6.2278968095779419e-01
    z[2,8,5]  R945      6.0777628421783447e-01
    z[2,8,5]  R946      -1.0870582610368729e-01
    z[2,8,5]  R947      3.1675449013710022e-01
    z[2,8,5]  R948      4.4717827439308167e-01
    z[2,8,5]  R949      2.5152226909995079e-02
    z[2,8,5]  R950      -2.3318465054035187e-01
    z[2,8,5]  R951      -1.5005064010620117e-01
    z[2,8,5]  R952      1.3023109734058380e-01
    z[2,8,5]  R953      -0.0937047228217125
    z[2,8,6]  R26       -1
    z[2,8,6]  R80       1
    z[2,8,6]  R842      -1
    z[2,8,6]  R843      1
    z[2,8,6]  R844      -1.7870176816359162e-03
    z[2,8,6]  R845      -7.4849396944046021e-02
    z[2,8,6]  R846      -0.00873769260942936
    z[2,8,6]  R847      -3.3102288842201233e-02
    z[2,8,6]  R848      1.8266259133815765e-01
    z[2,8,6]  R849      -1.8044899404048920e-01
    z[2,8,6]  R850      -1.6020901501178741e-01
    z[2,8,6]  R851      2.0764118432998657e-01
    z[2,8,6]  R852      3.0501919984817505e-01
    z[2,8,6]  R853      1.5341801941394806e-01
    z[2,8,6]  R854      -2.0680311322212219e-01
    z[2,8,6]  R855      1.1379343271255493e-01
    z[2,8,6]  R856      0.097191721200943
    z[2,8,6]  R857      2.9394736886024475e-01
    z[2,8,6]  R858      2.1659180521965027e-01
    z[2,8,6]  R859      2.8197491168975830e-01
    z[2,8,6]  R860      -1.6610570251941681e-01
    z[2,8,6]  R861      4.8151633143424988e-01
    z[2,8,6]  R862      2.0062738656997681e-01
    z[2,8,6]  R863      3.5508644580841064e-01
    z[2,8,6]  R864      -1.7260447144508362e-02
    z[2,8,6]  R865      -2.0662035793066025e-02
    z[2,8,6]  R866      2.9811248183250427e-01
    z[2,8,6]  R867      -2.7274868916720152e-03
    z[2,8,6]  R868      -4.4423291087150574e-01
    z[2,8,6]  R869      8.1322342157363892e-02
    z[2,8,6]  R870      -2.0091181993484497e-01
    z[2,8,6]  R871      3.0219249427318573e-02
    z[2,8,6]  R872      1.4600034058094025e-01
    z[2,8,6]  R873      -6.8772301077842712e-02
    z[2,8,6]  R874      2.6324397325515747e-01
    z[2,8,6]  R875      -2.4828876554965973e-01
    z[2,8,6]  R876      1.3578110933303833e-01
    z[2,8,6]  R877      -4.7924673557281494e-01
    z[2,8,6]  R878      -0.513411283493042
    z[2,8,6]  R879      -3.8489320874214172e-01
    z[2,8,6]  R880      -0.0986989438533783
    z[2,8,6]  R881      3.8036710023880005e-01
    z[2,8,6]  R882      -3.4328781068325043e-02
    z[2,8,6]  R883      -1.0835714638233185e-01
    z[2,8,6]  R884      2.0683281123638153e-01
    z[2,8,6]  R885      3.1815614551305771e-02
    z[2,8,6]  R886      1.8912982940673828e-01
    z[2,8,6]  R887      -3.9436578750610352e-01
    z[2,8,6]  R888      -7.2801060974597931e-02
    z[2,8,6]  R889      -1.9014558196067810e-01
    z[2,8,6]  R890      2.1530769765377045e-01
    z[2,8,6]  R891      8.7286166846752167e-02
    z[2,8,6]  R892      -2.7257224917411804e-01
    z[2,8,6]  R893      2.3130492866039276e-01
    z[2,8,6]  R894      1.0132461041212082e-01
    z[2,8,6]  R895      1.9825181365013123e-01
    z[2,8,6]  R896      3.6885300278663635e-01
    z[2,8,6]  R897      -0.0913926288485527
    z[2,8,6]  R898      2.9600170254707336e-01
    z[2,8,6]  R899      2.7688222005963326e-02
    z[2,8,6]  R900      -4.8201397061347961e-02
    z[2,8,6]  R901      1.9878593087196350e-01
    z[2,8,6]  R902      2.0137897133827209e-01
    z[2,8,6]  R903      1.9239969551563263e-01
    z[2,8,6]  R904      -1.3886536657810211e-01
    z[2,8,6]  R905      7.5013726949691772e-02
    z[2,8,6]  R906      -2.0114743709564209e-01
    z[2,8,6]  R907      3.1841254234313965e-01
    z[2,8,6]  R908      -1.0493180155754089e-01
    z[2,8,6]  R909      1.1313805729150772e-01
    z[2,8,6]  R910      4.9736884236335754e-01
    z[2,8,6]  R911      2.2158469259738922e-01
    z[2,8,6]  R912      2.3445343971252441e-01
    z[2,8,6]  R913      -5.0230240821838379e-01
    z[2,8,6]  R914      0.261868417263031
    z[2,8,6]  R915      -3.0893087387084961e-02
    z[2,8,6]  R916      -5.2927918732166290e-03
    z[2,8,6]  R917      -7.3460757732391357e-02
    z[2,8,6]  R918      -0.201044961810112
    z[2,8,6]  R919      -4.5461758971214294e-02
    z[2,8,6]  R920      -1.4415824413299561e-01
    z[2,8,6]  R921      -7.7320039272308350e-02
    z[2,8,6]  R922      -2.7034339308738708e-01
    z[2,8,6]  R923      0.0845186710357666
    z[2,8,6]  R924      2.7805145364254713e-03
    z[2,8,6]  R925      8.3542689681053162e-03
    z[2,8,6]  R926      -2.8224778175354004e-01
    z[2,8,6]  R927      1.4170059561729431e-01
    z[2,8,6]  R928      4.2444637417793274e-01
    z[2,8,6]  R929      3.5754811763763428e-01
    z[2,8,6]  R930      5.6581471115350723e-02
    z[2,8,6]  R931      -1.1086313426494598e-01
    z[2,8,6]  R932      2.4395607411861420e-02
    z[2,8,6]  R933      0.0748407393693924
    z[2,8,6]  R934      -1.0414259135723114e-01
    z[2,8,6]  R935      -4.4331338256597519e-02
    z[2,8,6]  R936      3.3066761493682861e-01
    z[2,8,6]  R937      -1.3299232721328735e-01
    z[2,8,6]  R938      -1.5949106216430664e-01
    z[2,8,6]  R939      -3.6813411116600037e-01
    z[2,8,6]  R940      -3.6560556292533875e-01
    z[2,8,6]  R941      -2.1807946264743805e-01
    z[2,8,6]  R942      -3.5904118418693542e-01
    z[2,8,6]  R943      5.0126284360885620e-01
    z[2,8,6]  R944      -9.4208948314189911e-02
    z[2,8,6]  R945      1.6494569182395935e-01
    z[2,8,6]  R946      -1.3512144982814789e-01
    z[2,8,6]  R947      -2.5242233276367188e-01
    z[2,8,6]  R948      -4.4038379192352295e-01
    z[2,8,6]  R949      1.2994153797626495e-01
    z[2,8,6]  R950      1.3858821988105774e-01
    z[2,8,6]  R951      1.2574154138565063e-01
    z[2,8,6]  R952      1.4876842498779297e-02
    z[2,8,6]  R953      -0.138673335313797
    z[8,2,0]  R20       1
    z[8,2,0]  R74       -1
    z[8,2,0]  R954      -1
    z[8,2,0]  R955      1
    z[8,2,0]  R968      -8.5061663389205933e-01
    z[8,2,0]  R969      -6.6478002071380615e-01
    z[8,2,0]  R970      -6.8220239877700806e-01
    z[8,2,0]  R971      -4.2338940501213074e-01
    z[8,2,0]  R972      -5.4683411121368408e-01
    z[8,2,0]  R973      3.4477461129426956e-02
    z[8,2,0]  R974      -1.3178817927837372e-01
    z[8,2,0]  R975      -1.1144463717937469e-01
    z[8,2,0]  R976      6.1237372457981110e-02
    z[8,2,0]  R977      1.2883530557155609e-01
    z[8,2,0]  R978      7.5623080134391785e-02
    z[8,2,0]  R979      2.0187151432037354e-01
    z[8,2,0]  R980      8.8159903883934021e-02
    z[8,2,0]  R981      1.7221964895725250e-01
    z[8,2,0]  R982      -3.8590118288993835e-01
    z[8,2,0]  R983      -2.1298557519912720e-01
    z[8,2,0]  R984      -3.4787435084581375e-02
    z[8,2,0]  R985      0.144593745470047
    z[8,2,0]  R986      -1.7110320925712585e-01
    z[8,2,0]  R987      -8.2352012395858765e-02
    z[8,2,0]  R988      -7.3613594286143780e-03
    z[8,2,0]  R989      2.2473397850990295e-01
    z[8,2,0]  R990      -4.5772069692611694e-01
    z[8,2,0]  R991      3.5058337450027466e-01
    z[8,2,0]  R992      -2.9376265406608582e-01
    z[8,2,0]  R993      -4.7494354844093323e-01
    z[8,2,0]  R994      -5.0987863540649414e-01
    z[8,2,0]  R995      1.2680661678314209e-01
    z[8,2,0]  R996      -4.7340753674507141e-01
    z[8,2,0]  R997      -5.9228497743606567e-01
    z[8,2,0]  R998      2.2725613415241241e-01
    z[8,2,0]  R999      1.6647150740027428e-02
    z[8,2,0]  R1000     6.6248111426830292e-02
    z[8,2,0]  R1001     4.9591418355703354e-02
    z[8,2,0]  R1002     2.3875980079174042e-01
    z[8,2,0]  R1003     -2.0266209542751312e-01
    z[8,2,0]  R1004     1.8510530889034271e-01
    z[8,2,0]  R1005     -9.6003741025924683e-02
    z[8,2,0]  R1006     6.1135566234588623e-01
    z[8,2,0]  R1007     -3.0051884055137634e-01
    z[8,2,0]  R1008     8.3354108035564423e-02
    z[8,2,0]  R1009     -9.0884536504745483e-02
    z[8,2,0]  R1010     -3.9024937152862549e-01
    z[8,2,0]  R1011     2.0824769139289856e-01
    z[8,2,0]  R1012     0.728653073310852
    z[8,2,0]  R1013     -1.0147596150636673e-01
    z[8,2,0]  R1014     4.1850557923316956e-01
    z[8,2,0]  R1015     7.3393404483795166e-01
    z[8,2,0]  R1016     7.3931068181991577e-01
    z[8,2,0]  R1017     7.7196583151817322e-02
    z[8,2,0]  R1018     -1.5070086717605591e-01
    z[8,2,0]  R1019     -5.3566700220108032e-01
    z[8,2,0]  R1020     2.7248108386993408e-01
    z[8,2,0]  R1021     2.2686022520065308e-01
    z[8,2,0]  R1022     -1.8101686239242554e-01
    z[8,2,0]  R1023     -0.244932159781456
    z[8,2,0]  R1024     -5.3288701921701431e-02
    z[8,2,0]  R1025     -4.9755790829658508e-01
    z[8,2,0]  R1026     1.4224074780941010e-01
    z[8,2,0]  R1027     -0.27867591381073
    z[8,2,0]  R1028     -2.4550264701247215e-02
    z[8,2,0]  R1029     2.1306996047496796e-01
    z[8,2,0]  R1030     0.0872528925538063
    z[8,2,0]  R1031     -5.5026117712259293e-02
    z[8,2,0]  R1032     2.8675207495689392e-01
    z[8,2,0]  R1033     7.4092823266983032e-01
    z[8,2,0]  R1034     1.2137080729007721e-01
    z[8,2,0]  R1035     -5.8641177415847778e-01
    z[8,2,0]  R1036     9.0669281780719757e-02
    z[8,2,0]  R1037     6.9981443881988525e-01
    z[8,2,0]  R1038     -2.6681980118155479e-02
    z[8,2,0]  R1039     -2.0519353449344635e-01
    z[8,2,0]  R1040     6.7276817560195923e-01
    z[8,2,0]  R1041     -2.2326491773128510e-01
    z[8,2,0]  R1042     -4.3854388594627380e-01
    z[8,2,0]  R1043     2.2516788914799690e-02
    z[8,2,0]  R1044     -0.459357351064682
    z[8,2,0]  R1045     -0.426647424697876
    z[8,2,0]  R1046     -2.2971516475081444e-02
    z[8,2,0]  R1047     2.5697913765907288e-01
    z[8,2,0]  R1048     -5.2027054131031036e-02
    z[8,2,0]  R1049     -4.7266975045204163e-02
    z[8,2,0]  R1050     5.9770947694778442e-01
    z[8,2,0]  R1051     3.8361188769340515e-01
    z[8,2,0]  R1052     2.3431569337844849e-01
    z[8,2,0]  R1053     5.1072686910629272e-02
    z[8,2,0]  R1054     -1.3900332152843475e-01
    z[8,2,0]  R1055     -1.7442011833190918e-01
    z[8,2,0]  R1056     -2.9155322909355164e-01
    z[8,2,0]  R1057     -3.0238136649131775e-01
    z[8,2,0]  R1058     -8.6114391684532166e-02
    z[8,2,0]  R1059     -2.6662680506706238e-01
    z[8,2,0]  R1060     -5.2559429407119751e-01
    z[8,2,0]  R1061     1.3804684579372406e-01
    z[8,2,0]  R1062     -1.7923644185066223e-01
    z[8,2,0]  R1063     2.6704484224319458e-01
    z[8,2,0]  R1064     -9.4874203205108643e-02
    z[8,2,0]  R1065     1.7659552395343781e-01
    z[8,2,0]  R1066     3.6078906059265137e-01
    z[8,2,0]  R1067     1.1271440237760544e-01
    z[8,2,0]  R1068     1.9500410556793213e-01
    z[8,2,0]  R1069     2.3636843264102936e-01
    z[8,2,0]  R1070     3.1732618808746338e-01
    z[8,2,0]  R1071     8.7245799601078033e-02
    z[8,2,0]  R1072     1.6199515759944916e-01
    z[8,2,0]  R1073     4.6486815810203552e-01
    z[8,2,0]  R1074     -1.2235434353351593e-01
    z[8,2,0]  R1075     -1.1196144670248032e-01
    z[8,2,0]  R1076     -1.0307740420103073e-01
    z[8,2,0]  R1077     -2.4501538276672363e-01
    z[8,2,1]  R21       1
    z[8,2,1]  R75       -1
    z[8,2,1]  R956      -1
    z[8,2,1]  R957      1
    z[8,2,1]  R968      -1.5238077938556671e-01
    z[8,2,1]  R969      -4.9546480178833008e-01
    z[8,2,1]  R970      -1.3301602005958557e-01
    z[8,2,1]  R971      -3.3557718992233276e-01
    z[8,2,1]  R972      -1.6564594209194183e-01
    z[8,2,1]  R973      -9.8058469593524933e-02
    z[8,2,1]  R974      1.6699803993105888e-02
    z[8,2,1]  R975      -2.0967480540275574e-01
    z[8,2,1]  R976      -3.4673564136028290e-02
    z[8,2,1]  R977      4.7680456191301346e-02
    z[8,2,1]  R978      8.7954843044281006e-01
    z[8,2,1]  R979      7.4665105342864990e-01
    z[8,2,1]  R980      7.5145530700683594e-01
    z[8,2,1]  R981      0.565773069858551
    z[8,2,1]  R982      5.5502235889434814e-01
    z[8,2,1]  R983      6.4108473062515259e-01
    z[8,2,1]  R984      -8.4837704896926880e-02
    z[8,2,1]  R985      5.5654048919677734e-01
    z[8,2,1]  R986      -5.7708561420440674e-01
    z[8,2,1]  R987      6.4547479152679443e-01
    z[8,2,1]  R988      7.9739069938659668e-01
    z[8,2,1]  R989      7.3832303285598755e-01
    z[8,2,1]  R990      6.4866358041763306e-01
    z[8,2,1]  R991      6.1946231126785278e-01
    z[8,2,1]  R992      7.0504951477050781e-01
    z[8,2,1]  R993      6.8237692117691040e-01
    z[8,2,1]  R994      5.7485276460647583e-01
    z[8,2,1]  R995      0.730842649936676
    z[8,2,1]  R996      7.4944311380386353e-01
    z[8,2,1]  R997      5.7339757680892944e-01
    z[8,2,1]  R998      8.4325706958770752e-01
    z[8,2,1]  R999      6.8030416965484619e-01
    z[8,2,1]  R1000     -2.7212768793106079e-01
    z[8,2,1]  R1001     -6.3387066125869751e-02
    z[8,2,1]  R1002     2.7062773704528809e-02
    z[8,2,1]  R1003     2.5001174211502075e-01
    z[8,2,1]  R1004     -2.7819997072219849e-01
    z[8,2,1]  R1005     -4.0184023976325989e-01
    z[8,2,1]  R1006     -8.2699873019009829e-04
    z[8,2,1]  R1007     -9.4911180436611176e-02
    z[8,2,1]  R1008     6.2830311059951782e-01
    z[8,2,1]  R1009     6.0234630107879639e-01
    z[8,2,1]  R1010     6.5705102682113647e-01
    z[8,2,1]  R1011     3.5974937677383423e-01
    z[8,2,1]  R1012     9.5749676227569580e-02
    z[8,2,1]  R1013     -4.8531722277402878e-02
    z[8,2,1]  R1014     -3.8195803761482239e-01
    z[8,2,1]  R1015     7.5192131102085114e-02
    z[8,2,1]  R1016     1.3157719373703003e-01
    z[8,2,1]  R1017     -3.1927531957626343e-01
    z[8,2,1]  R1018     7.9016172885894775e-01
    z[8,2,1]  R1019     8.2258272171020508e-01
    z[8,2,1]  R1020     8.8666254281997681e-01
    z[8,2,1]  R1021     7.5900465250015259e-01
    z[8,2,1]  R1022     0.809294581413269
    z[8,2,1]  R1023     5.1300019025802612e-01
    z[8,2,1]  R1024     7.6782727241516113e-01
    z[8,2,1]  R1025     5.9720373153686523e-01
    z[8,2,1]  R1026     1.5615494549274445e-01
    z[8,2,1]  R1027     -1.3358376920223236e-01
    z[8,2,1]  R1028     3.1324383616447449e-01
    z[8,2,1]  R1029     7.7548390626907349e-01
    z[8,2,1]  R1030     1.7036555707454681e-01
    z[8,2,1]  R1031     -4.1772177815437317e-01
    z[8,2,1]  R1032     -0.253431499004364
    z[8,2,1]  R1033     2.1579198539257050e-01
    z[8,2,1]  R1034     1.3170754909515381e-01
    z[8,2,1]  R1035     -3.4229966998100281e-01
    z[8,2,1]  R1036     2.3952980339527130e-01
    z[8,2,1]  R1037     1.8633915483951569e-01
    z[8,2,1]  R1038     6.8395271897315979e-02
    z[8,2,1]  R1039     -5.6348246335983276e-01
    z[8,2,1]  R1040     2.7041158080101013e-01
    z[8,2,1]  R1041     -2.5729942321777344e-01
    z[8,2,1]  R1042     -0.0911824107170105
    z[8,2,1]  R1043     6.5456062555313110e-02
    z[8,2,1]  R1044     -1.0315380990505219e-01
    z[8,2,1]  R1045     -2.5617891550064087e-01
    z[8,2,1]  R1046     -2.3504646122455597e-01
    z[8,2,1]  R1047     -1.7841754853725433e-01
    z[8,2,1]  R1048     -1.6186280548572540e-01
    z[8,2,1]  R1049     8.3938315510749817e-02
    z[8,2,1]  R1050     1.8751224875450134e-01
    z[8,2,1]  R1051     4.7296587377786636e-02
    z[8,2,1]  R1052     -8.9162372052669525e-02
    z[8,2,1]  R1053     -9.0641617774963379e-01
    z[8,2,1]  R1054     -8.6645781993865967e-01
    z[8,2,1]  R1055     -8.3836305141448975e-01
    z[8,2,1]  R1056     -9.1352224349975586e-01
    z[8,2,1]  R1057     -8.3615368604660034e-01
    z[8,2,1]  R1058     -6.2125867605209351e-01
    z[8,2,1]  R1059     -5.1839131116867065e-01
    z[8,2,1]  R1060     -6.4223206043243408e-01
    z[8,2,1]  R1061     -8.5852009057998657e-01
    z[8,2,1]  R1062     -8.8854783773422241e-01
    z[8,2,1]  R1063     7.0590265095233917e-02
    z[8,2,1]  R1064     -2.2162930667400360e-01
    z[8,2,1]  R1065     9.3165911734104156e-02
    z[8,2,1]  R1066     1.9307444989681244e-01
    z[8,2,1]  R1067     -0.20382159948349
    z[8,2,1]  R1068     4.5184570550918579e-01
    z[8,2,1]  R1069     3.8862824440002441e-01
    z[8,2,1]  R1070     4.1592359542846680e-01
    z[8,2,1]  R1071     0.513628363609314
    z[8,2,1]  R1072     3.7828582525253296e-01
    z[8,2,1]  R1073     2.9255113005638123e-01
    z[8,2,1]  R1074     6.3944053649902344e-01
    z[8,2,1]  R1075     4.4198375940322876e-01
    z[8,2,1]  R1076     8.5158699750900269e-01
    z[8,2,1]  R1077     8.5738492012023926e-01
    z[8,2,2]  R22       1
    z[8,2,2]  R76       -1
    z[8,2,2]  R958      -1
    z[8,2,2]  R959      1
    z[8,2,2]  R968      4.7955888509750366e-01
    z[8,2,2]  R969      5.2574193477630615e-01
    z[8,2,2]  R970      0.565449595451355
    z[8,2,2]  R971      8.1553924083709717e-01
    z[8,2,2]  R972      6.4739727973937988e-01
    z[8,2,2]  R973      -3.7284132838249207e-01
    z[8,2,2]  R974      -1.2426032125949860e-01
    z[8,2,2]  R975      -1.4245571196079254e-01
    z[8,2,2]  R976      -0.0619538351893425
    z[8,2,2]  R977      1.6244810819625854e-01
    z[8,2,2]  R978      -5.9567335993051529e-02
    z[8,2,2]  R979      4.6708053350448608e-01
    z[8,2,2]  R980      2.3357817530632019e-01
    z[8,2,2]  R981      -2.5872397422790527e-01
    z[8,2,2]  R982      -3.5164999961853027e-01
    z[8,2,2]  R983      0.294384241104126
    z[8,2,2]  R984      -3.7575873732566833e-01
    z[8,2,2]  R985      -6.5847319364547729e-01
    z[8,2,2]  R986      -2.9010412096977234e-01
    z[8,2,2]  R987      -2.9292309284210205e-01
    z[8,2,2]  R988      -0.102711021900177
    z[8,2,2]  R989      -2.1386066079139709e-01
    z[8,2,2]  R990      -0.245735302567482
    z[8,2,2]  R991      -4.9894452095031738e-01
    z[8,2,2]  R992      -1.9249689579010010e-01
    z[8,2,2]  R993      2.5324749946594238e-01
    z[8,2,2]  R994      -3.1486704945564270e-01
    z[8,2,2]  R995      -2.2246772050857544e-01
    z[8,2,2]  R996      3.6608977243304253e-03
    z[8,2,2]  R997      -3.7173548340797424e-01
    z[8,2,2]  R998      -1.9826452434062958e-01
    z[8,2,2]  R999      3.0065628886222839e-01
    z[8,2,2]  R1000     -5.4874461889266968e-01
    z[8,2,2]  R1001     1.2436462938785553e-01
    z[8,2,2]  R1002     -2.1571689844131470e-01
    z[8,2,2]  R1003     6.0266986489295959e-02
    z[8,2,2]  R1004     1.3241645693778992e-01
    z[8,2,2]  R1005     -7.5738435983657837e-01
    z[8,2,2]  R1006     -4.2077675461769104e-01
    z[8,2,2]  R1007     -8.3095115423202515e-01
    z[8,2,2]  R1008     1.3665291666984558e-01
    z[8,2,2]  R1009     -4.5909079909324646e-01
    z[8,2,2]  R1010     9.8254293203353882e-02
    z[8,2,2]  R1011     -4.2626655101776123e-01
    z[8,2,2]  R1012     1.3493350148200989e-01
    z[8,2,2]  R1013     -3.0118385329842567e-02
    z[8,2,2]  R1014     -0.602405846118927
    z[8,2,2]  R1015     -3.7822088599205017e-01
    z[8,2,2]  R1016     -1.4436319470405579e-01
    z[8,2,2]  R1017     -0.777163565158844
    z[8,2,2]  R1018     -4.3973001837730408e-01
    z[8,2,2]  R1019     -6.8632923066616058e-02
    z[8,2,2]  R1020     3.4726104140281677e-01
    z[8,2,2]  R1021     1.0989388078451157e-01
    z[8,2,2]  R1022     2.4211842101067305e-03
    z[8,2,2]  R1023     9.6697226166725159e-02
    z[8,2,2]  R1024     2.7760079503059387e-01
    z[8,2,2]  R1025     -1.9307935237884521e-01
    z[8,2,2]  R1026     7.6088112592697144e-01
    z[8,2,2]  R1027     0.29134401679039
    z[8,2,2]  R1028     -2.4838103353977203e-01
    z[8,2,2]  R1029     1.2162237614393234e-01
    z[8,2,2]  R1030     8.0715399980545044e-01
    z[8,2,2]  R1031     -0.432815819978714
    z[8,2,2]  R1032     -8.0312824249267578e-01
    z[8,2,2]  R1033     -2.5108432769775391e-01
    z[8,2,2]  R1034     -2.9693427681922913e-01
    z[8,2,2]  R1035     -5.6551790237426758e-01
    z[8,2,2]  R1036     1.9435006380081177e-01
    z[8,2,2]  R1037     -1.7551237344741821e-01
    z[8,2,2]  R1038     -6.7357398569583893e-02
    z[8,2,2]  R1039     -5.7572543621063232e-01
    z[8,2,2]  R1040     -2.7424991130828857e-01
    z[8,2,2]  R1041     1.4285388588905334e-01
    z[8,2,2]  R1042     3.7022361159324646e-01
    z[8,2,2]  R1043     -6.6915291547775269e-01
    z[8,2,2]  R1044     1.1230655014514923e-01
    z[8,2,2]  R1045     -1.3322305679321289e-01
    z[8,2,2]  R1046     -6.1300748586654663e-01
    z[8,2,2]  R1047     2.2271849215030670e-01
    z[8,2,2]  R1048     -4.7684401273727417e-02
    z[8,2,2]  R1049     -1.5192721784114838e-01
    z[8,2,2]  R1050     -3.2909657806158066e-02
    z[8,2,2]  R1051     3.5245963931083679e-01
    z[8,2,2]  R1052     0.0596194826066494
    z[8,2,2]  R1053     -3.6621391773223877e-01
    z[8,2,2]  R1054     -3.6664634943008423e-01
    z[8,2,2]  R1055     -3.6266416311264038e-01
    z[8,2,2]  R1056     -1.9708488881587982e-01
    z[8,2,2]  R1057     -2.6363670825958252e-01
    z[8,2,2]  R1058     6.4191657304763794e-01
    z[8,2,2]  R1059     5.4716587066650391e-01
    z[8,2,2]  R1060     4.7255662083625793e-01
    z[8,2,2]  R1061     3.6511132121086121e-01
    z[8,2,2]  R1062     5.3928568959236145e-02
    z[8,2,2]  R1063     -4.6291261911392212e-01
    z[8,2,2]  R1064     -6.8764805793762207e-01
    z[8,2,2]  R1065     -3.6826652288436890e-01
    z[8,2,2]  R1066     -4.5904904603958130e-01
    z[8,2,2]  R1067     -9.3029528856277466e-01
    z[8,2,2]  R1068     6.2224364280700684e-01
    z[8,2,2]  R1069     3.3884134888648987e-01
    z[8,2,2]  R1070     2.3745256662368774e-01
    z[8,2,2]  R1071     6.0588216781616211e-01
    z[8,2,2]  R1072     5.2405965328216553e-01
    z[8,2,2]  R1073     5.2620679140090942e-01
    z[8,2,2]  R1074     2.5405415892601013e-01
    z[8,2,2]  R1075     2.0580118894577026e-01
    z[8,2,2]  R1076     1.7980951070785522e-01
    z[8,2,2]  R1077     1.2643806636333466e-01
    z[8,2,3]  R23       1
    z[8,2,3]  R77       -1
    z[8,2,3]  R960      -1
    z[8,2,3]  R961      1
    z[8,2,3]  R968      2.5020893663167953e-02
    z[8,2,3]  R969      -2.0159909501671791e-02
    z[8,2,3]  R970      -2.4972374737262726e-01
    z[8,2,3]  R971      2.0682762563228607e-01
    z[8,2,3]  R972      8.6605958640575409e-02
    z[8,2,3]  R973      8.7584728002548218e-01
    z[8,2,3]  R974      0.886455774307251
    z[8,2,3]  R975      7.7952551841735840e-01
    z[8,2,3]  R976      6.8842327594757080e-01
    z[8,2,3]  R977      7.6254725456237793e-01
    z[8,2,3]  R978      -2.1076574921607971e-01
    z[8,2,3]  R979      1.7412135004997253e-01
    z[8,2,3]  R980      2.5826262310147285e-02
    z[8,2,3]  R981      1.6320027410984039e-01
    z[8,2,3]  R982      2.8141847252845764e-01
    z[8,2,3]  R983      3.7003250326961279e-03
    z[8,2,3]  R984      -0.00538968201726675
    z[8,2,3]  R985      2.6330480352044106e-02
    z[8,2,3]  R986      -1.0333186388015747e-01
    z[8,2,3]  R987      1.6312251985073090e-01
    z[8,2,3]  R988      6.8231053650379181e-02
    z[8,2,3]  R989      0.591113269329071
    z[8,2,3]  R990      -1.8255592882633209e-01
    z[8,2,3]  R991      0.0961490273475647
    z[8,2,3]  R992      -1.9007220864295959e-01
    z[8,2,3]  R993      2.4882838129997253e-01
    z[8,2,3]  R994      2.1823190152645111e-01
    z[8,2,3]  R995      -1.9260866940021515e-01
    z[8,2,3]  R996      -0.00952579453587532
    z[8,2,3]  R997      -2.9420253634452820e-01
    z[8,2,3]  R998      1.9434593617916107e-01
    z[8,2,3]  R999      -3.4812459349632263e-01
    z[8,2,3]  R1000     2.1785824000835419e-01
    z[8,2,3]  R1001     -6.4719247817993164e-01
    z[8,2,3]  R1002     -7.3756092786788940e-01
    z[8,2,3]  R1003     -8.5562056303024292e-01
    z[8,2,3]  R1004     -0.709907591342926
    z[8,2,3]  R1005     2.2079738974571228e-01
    z[8,2,3]  R1006     3.9861035346984863e-01
    z[8,2,3]  R1007     -8.2400523126125336e-02
    z[8,2,3]  R1008     4.2890876531600952e-01
    z[8,2,3]  R1009     -1.1907821148633957e-01
    z[8,2,3]  R1010     -3.1710562109947205e-01
    z[8,2,3]  R1011     4.3346762657165527e-01
    z[8,2,3]  R1012     5.7884871959686279e-01
    z[8,2,3]  R1013     -8.2855713367462158e-01
    z[8,2,3]  R1014     2.7887905016541481e-02
    z[8,2,3]  R1015     3.4898456931114197e-01
    z[8,2,3]  R1016     3.9520654082298279e-01
    z[8,2,3]  R1017     1.0373300313949585e-01
    z[8,2,3]  R1018     2.6181671023368835e-01
    z[8,2,3]  R1019     3.0752778053283691e-02
    z[8,2,3]  R1020     -1.0336022078990936e-01
    z[8,2,3]  R1021     -1.0176008194684982e-01
    z[8,2,3]  R1022     -1.9595865160226822e-02
    z[8,2,3]  R1023     5.7871639728546143e-01
    z[8,2,3]  R1024     4.3673789501190186e-01
    z[8,2,3]  R1025     2.7254721149802208e-02
    z[8,2,3]  R1026     -5.4215413331985474e-01
    z[8,2,3]  R1027     3.5157926380634308e-02
    z[8,2,3]  R1028     8.2601845264434814e-01
    z[8,2,3]  R1029     4.0940120816230774e-01
    z[8,2,3]  R1030     -4.6199521422386169e-01
    z[8,2,3]  R1031     3.7539044022560120e-01
    z[8,2,3]  R1032     9.1040439903736115e-02
    z[8,2,3]  R1033     4.2059344053268433e-01
    z[8,2,3]  R1034     -4.6221151947975159e-01
    z[8,2,3]  R1035     7.8479431569576263e-02
    z[8,2,3]  R1036     -0.835407018661499
    z[8,2,3]  R1037     4.3667939305305481e-01
    z[8,2,3]  R1038     8.7394517660140991e-01
    z[8,2,3]  R1039     3.2051730155944824e-01
    z[8,2,3]  R1040     4.9250802397727966e-01
    z[8,2,3]  R1041     -7.9185032844543457e-01
    z[8,2,3]  R1042     1.9741542637348175e-01
    z[8,2,3]  R1043     4.6691466122865677e-03
    z[8,2,3]  R1044     -4.7329258918762207e-01
    z[8,2,3]  R1045     -4.7493028640747070e-01
    z[8,2,3]  R1046     -3.6188460886478424e-02
    z[8,2,3]  R1047     -2.6878905296325684e-01
    z[8,2,3]  R1048     -6.1702221632003784e-01
    z[8,2,3]  R1049     -7.4480628967285156e-01
    z[8,2,3]  R1050     0.576059877872467
    z[8,2,3]  R1051     -4.5782437920570374e-01
    z[8,2,3]  R1052     5.5540060997009277e-01
    z[8,2,3]  R1053     -3.3231852576136589e-03
    z[8,2,3]  R1054     1.4756141602993011e-01
    z[8,2,3]  R1055     -2.0093291997909546e-01
    z[8,2,3]  R1056     -1.4315296709537506e-01
    z[8,2,3]  R1057     2.6009619235992432e-01
    z[8,2,3]  R1058     3.7220796942710876e-01
    z[8,2,3]  R1059     4.6839761734008789e-01
    z[8,2,3]  R1060     1.6719271242618561e-01
    z[8,2,3]  R1061     1.2000499665737152e-01
    z[8,2,3]  R1062     2.8061398863792419e-01
    z[8,2,3]  R1063     7.1794402599334717e-01
    z[8,2,3]  R1064     5.9474724531173706e-01
    z[8,2,3]  R1065     8.6313569545745850e-01
    z[8,2,3]  R1066     4.6029153466224670e-01
    z[8,2,3]  R1067     1.5579879283905029e-01
    z[8,2,3]  R1068     -8.6404690518975258e-03
    z[8,2,3]  R1069     -1.1484029702842236e-02
    z[8,2,3]  R1070     7.7955529093742371e-02
    z[8,2,3]  R1071     -1.7613553791306913e-04
    z[8,2,3]  R1072     1.1394208669662476e-01
    z[8,2,3]  R1073     2.9837839305400848e-02
    z[8,2,3]  R1074     -4.2753354646265507e-03
    z[8,2,3]  R1075     2.0318765193223953e-02
    z[8,2,3]  R1076     -2.0815165340900421e-01
    z[8,2,3]  R1077     -9.9909320473670959e-02
    z[8,2,4]  R24       1
    z[8,2,4]  R78       -1
    z[8,2,4]  R962      -1
    z[8,2,4]  R963      1
    z[8,2,4]  R968      -6.0702785849571228e-02
    z[8,2,4]  R969      -1.6370341181755066e-01
    z[8,2,4]  R970      -2.1409824490547180e-01
    z[8,2,4]  R971      -1.0911155492067337e-02
    z[8,2,4]  R972      -1.8714027106761932e-01
    z[8,2,4]  R973      -2.6003894209861755e-01
    z[8,2,4]  R974      4.6505674719810486e-02
    z[8,2,4]  R975      -5.3447896242141724e-01
    z[8,2,4]  R976      -0.631626546382904
    z[8,2,4]  R977      -6.0656398534774780e-01
    z[8,2,4]  R978      3.8101791869848967e-03
    z[8,2,4]  R979      -1.3773700594902039e-01
    z[8,2,4]  R980      -2.6488479971885681e-01
    z[8,2,4]  R981      5.4444384574890137e-01
    z[8,2,4]  R982      2.2349333763122559e-01
    z[8,2,4]  R983      5.1280868053436279e-01
    z[8,2,4]  R984      -4.9400264024734497e-01
    z[8,2,4]  R985      2.6858943700790405e-01
    z[8,2,4]  R986      -0.381608247756958
    z[8,2,4]  R987      0.672268271446228
    z[8,2,4]  R988      -4.3929553031921387e-01
    z[8,2,4]  R989      6.3479013741016388e-02
    z[8,2,4]  R990      -3.5290178656578064e-01
    z[8,2,4]  R991      -2.2511450946331024e-01
    z[8,2,4]  R992      2.7396363019943237e-01
    z[8,2,4]  R993      -0.324464350938797
    z[8,2,4]  R994      -4.2967510223388672e-01
    z[8,2,4]  R995      2.7419865131378174e-01
    z[8,2,4]  R996      3.5170897841453552e-01
    z[8,2,4]  R997      -2.0574498921632767e-03
    z[8,2,4]  R998      5.4170109331607819e-02
    z[8,2,4]  R999      -5.3116941452026367e-01
    z[8,2,4]  R1000     -4.3936005234718323e-01
    z[8,2,4]  R1001     2.3174965381622314e-01
    z[8,2,4]  R1002     1.9797667860984802e-01
    z[8,2,4]  R1003     2.7299249172210693e-01
    z[8,2,4]  R1004     3.4672826528549194e-01
    z[8,2,4]  R1005     0.256306916475296
    z[8,2,4]  R1006     1.2066429853439331e-01
    z[8,2,4]  R1007     4.5660361647605896e-02
    z[8,2,4]  R1008     -6.1327022314071655e-01
    z[8,2,4]  R1009     5.9897321462631226e-01
    z[8,2,4]  R1010     4.8401924967765808e-01
    z[8,2,4]  R1011     8.9172385632991791e-02
    z[8,2,4]  R1012     1.9298788160085678e-02
    z[8,2,4]  R1013     9.8577544093132019e-02
    z[8,2,4]  R1014     -1.0599945485591888e-01
    z[8,2,4]  R1015     3.6982879042625427e-01
    z[8,2,4]  R1016     1.7723430693149567e-01
    z[8,2,4]  R1017     -4.5534770935773849e-02
    z[8,2,4]  R1018     -5.9796366840600967e-02
    z[8,2,4]  R1019     -1.6417492926120758e-01
    z[8,2,4]  R1020     -9.0975128114223480e-02
    z[8,2,4]  R1021     5.3408050537109375e-01
    z[8,2,4]  R1022     0.520047664642334
    z[8,2,4]  R1023     -5.3054285049438477e-01
    z[8,2,4]  R1024     -2.5470888614654541e-01
    z[8,2,4]  R1025     4.0219381451606750e-01
    z[8,2,4]  R1026     -3.1121345236897469e-02
    z[8,2,4]  R1027     3.2903265953063965e-01
    z[8,2,4]  R1028     -5.1761273294687271e-02
    z[8,2,4]  R1029     -3.8550980389118195e-02
    z[8,2,4]  R1030     -4.5182496309280396e-02
    z[8,2,4]  R1031     -3.6956712603569031e-01
    z[8,2,4]  R1032     -1.3292072713375092e-01
    z[8,2,4]  R1033     -1.8835441768169403e-01
    z[8,2,4]  R1034     5.5422937870025635e-01
    z[8,2,4]  R1035     -1.3107995688915253e-01
    z[8,2,4]  R1036     2.4477869272232056e-01
    z[8,2,4]  R1037     4.5653986930847168e-01
    z[8,2,4]  R1038     -1.4539791643619537e-01
    z[8,2,4]  R1039     -2.5600489974021912e-01
    z[8,2,4]  R1040     -2.0681457221508026e-01
    z[8,2,4]  R1041     4.1539192199707031e-01
    z[8,2,4]  R1042     -4.3201935291290283e-01
    z[8,2,4]  R1043     2.6885172724723816e-01
    z[8,2,4]  R1044     5.6846636533737183e-01
    z[8,2,4]  R1045     6.3694953918457031e-01
    z[8,2,4]  R1046     5.3225511312484741e-01
    z[8,2,4]  R1047     2.6034596562385559e-01
    z[8,2,4]  R1048     4.3744844198226929e-01
    z[8,2,4]  R1049     1.2768211960792542e-01
    z[8,2,4]  R1050     4.9454993009567261e-01
    z[8,2,4]  R1051     5.9390527009963989e-01
    z[8,2,4]  R1052     4.8084896802902222e-01
    z[8,2,4]  R1053     1.5543513000011444e-01
    z[8,2,4]  R1054     -1.1964630335569382e-02
    z[8,2,4]  R1055     2.3769660294055939e-01
    z[8,2,4]  R1056     -6.2905423343181610e-02
    z[8,2,4]  R1057     2.1035051345825195e-01
    z[8,2,4]  R1058     2.6416091248393059e-02
    z[8,2,4]  R1059     -3.3045294880867004e-01
    z[8,2,4]  R1060     1.0801636381074786e-03
    z[8,2,4]  R1061     -5.0684046000242233e-02
    z[8,2,4]  R1062     -1.1764678172767162e-02
    z[8,2,4]  R1063     -3.6642208695411682e-01
    z[8,2,4]  R1064     -2.5889590382575989e-01
    z[8,2,4]  R1065     2.6452008169144392e-03
    z[8,2,4]  R1066     -5.5785093456506729e-02
    z[8,2,4]  R1067     -6.1872941441833973e-03
    z[8,2,4]  R1068     2.3640081286430359e-01
    z[8,2,4]  R1069     -1.0277015715837479e-01
    z[8,2,4]  R1070     4.2747011780738831e-01
    z[8,2,4]  R1071     -1.0872618108987808e-01
    z[8,2,4]  R1072     5.1522469520568848e-01
    z[8,2,4]  R1073     1.4857383072376251e-01
    z[8,2,4]  R1074     2.4948436766862869e-02
    z[8,2,4]  R1075     3.2144007086753845e-01
    z[8,2,4]  R1076     3.0023893713951111e-01
    z[8,2,4]  R1077     -4.9544990062713623e-02
    z[8,2,5]  R25       1
    z[8,2,5]  R79       -1
    z[8,2,5]  R964      -1
    z[8,2,5]  R965      1
    z[8,2,5]  R968      -1.3654959201812744e-01
    z[8,2,5]  R969      -9.2440247535705566e-02
    z[8,2,5]  R970      1.0115293785929680e-02
    z[8,2,5]  R971      1.0998719371855259e-02
    z[8,2,5]  R972      1.2060520052909851e-01
    z[8,2,5]  R973      -9.4037890434265137e-02
    z[8,2,5]  R974      -3.7226337194442749e-01
    z[8,2,5]  R975      -1.7053464055061340e-01
    z[8,2,5]  R976      -3.1147161126136780e-01
    z[8,2,5]  R977      -2.4714589118957520e-02
    z[8,2,5]  R978      -3.2154834270477295e-01
    z[8,2,5]  R979      2.6955306529998779e-01
    z[8,2,5]  R980      -5.3265053033828735e-01
    z[8,2,5]  R981      1.7484933137893677e-01
    z[8,2,5]  R982      1.6320532560348511e-01
    z[8,2,5]  R983      -2.1414074301719666e-01
    z[8,2,5]  R984      7.7239155769348145e-01
    z[8,2,5]  R985      1.3511365652084351e-01
    z[8,2,5]  R986      6.2932890653610229e-01
    z[8,2,5]  R987      -2.1945912390947342e-02
    z[8,2,5]  R988      3.3637553453445435e-01
    z[8,2,5]  R989      6.4657934010028839e-02
    z[8,2,5]  R990      3.4015449881553650e-01
    z[8,2,5]  R991      -1.7019546031951904e-01
    z[8,2,5]  R992      5.1290357112884521e-01
    z[8,2,5]  R993      -2.0324380695819855e-01
    z[8,2,5]  R994      -1.7839151620864868e-01
    z[8,2,5]  R995      5.2952367067337036e-01
    z[8,2,5]  R996      1.2697046995162964e-01
    z[8,2,5]  R997      -2.0534142851829529e-01
    z[8,2,5]  R998      3.8339513540267944e-01
    z[8,2,5]  R999      -6.2285237014293671e-02
    z[8,2,5]  R1000     4.9384722113609314e-01
    z[8,2,5]  R1001     7.0507985353469849e-01
    z[8,2,5]  R1002     4.7425702214241028e-01
    z[8,2,5]  R1003     2.9225319623947144e-01
    z[8,2,5]  R1004     4.9426114559173584e-01
    z[8,2,5]  R1005     3.1892961263656616e-01
    z[8,2,5]  R1006     4.8496076464653015e-01
    z[8,2,5]  R1007     4.0534928441047668e-01
    z[8,2,5]  R1008     1.6330938786268234e-02
    z[8,2,5]  R1009     1.9894470274448395e-01
    z[8,2,5]  R1010     -1.7619448900222778e-01
    z[8,2,5]  R1011     -5.9015041589736938e-01
    z[8,2,5]  R1012     3.0861091613769531e-01
    z[8,2,5]  R1013     5.2670252323150635e-01
    z[8,2,5]  R1014     0.238073468208313
    z[8,2,5]  R1015     7.0517018437385559e-02
    z[8,2,5]  R1016     -4.1556927561759949e-01
    z[8,2,5]  R1017     1.5158849954605103e-01
    z[8,2,5]  R1018     -1.3737757503986359e-01
    z[8,2,5]  R1019     5.3427174687385559e-02
    z[8,2,5]  R1020     2.3475063499063253e-03
    z[8,2,5]  R1021     -2.4367213249206543e-01
    z[8,2,5]  R1022     -3.1883720308542252e-02
    z[8,2,5]  R1023     -0.221435084939003
    z[8,2,5]  R1024     -2.3268258571624756e-01
    z[8,2,5]  R1025     -4.3591648340225220e-01
    z[8,2,5]  R1026     9.1966040432453156e-02
    z[8,2,5]  R1027     8.3843415975570679e-01
    z[8,2,5]  R1028     -3.9317813515663147e-01
    z[8,2,5]  R1029     -4.1142249107360840e-01
    z[8,2,5]  R1030     1.2930651009082794e-01
    z[8,2,5]  R1031     5.8101141452789307e-01
    z[8,2,5]  R1032     4.9192342907190323e-02
    z[8,2,5]  R1033     3.4624036401510239e-02
    z[8,2,5]  R1034     5.9644037485122681e-01
    z[8,2,5]  R1035     4.2838081717491150e-01
    z[8,2,5]  R1036     3.7177410721778870e-01
    z[8,2,5]  R1037     -2.0003531873226166e-01
    z[8,2,5]  R1038     -4.4080230593681335e-01
    z[8,2,5]  R1039     0.372408926486969
    z[8,2,5]  R1040     6.6106610000133514e-02
    z[8,2,5]  R1041     2.1512353420257568e-01
    z[8,2,5]  R1042     -6.4128667116165161e-01
    z[8,2,5]  R1043     5.8276677131652832e-01
    z[8,2,5]  R1044     2.9139328002929688e-01
    z[8,2,5]  R1045     2.3616470396518707e-01
    z[8,2,5]  R1046     3.9361339807510376e-01
    z[8,2,5]  R1047     0.679141640663147
    z[8,2,5]  R1048     6.2278968095779419e-01
    z[8,2,5]  R1049     6.0777628421783447e-01
    z[8,2,5]  R1050     -1.0870582610368729e-01
    z[8,2,5]  R1051     3.1675449013710022e-01
    z[8,2,5]  R1052     4.4717827439308167e-01
    z[8,2,5]  R1053     2.5152226909995079e-02
    z[8,2,5]  R1054     -2.3318465054035187e-01
    z[8,2,5]  R1055     -1.5005064010620117e-01
    z[8,2,5]  R1056     1.3023109734058380e-01
    z[8,2,5]  R1057     -0.0937047228217125
    z[8,2,5]  R1058     2.3521322011947632e-01
    z[8,2,5]  R1059     1.6307172179222107e-01
    z[8,2,5]  R1060     -2.4484235048294067e-01
    z[8,2,5]  R1061     3.0416178703308105e-01
    z[8,2,5]  R1062     0.251397043466568
    z[8,2,5]  R1063     1.6475871205329895e-01
    z[8,2,5]  R1064     -1.5033662319183350e-01
    z[8,2,5]  R1065     1.9075880944728851e-01
    z[8,2,5]  R1066     5.6018787622451782e-01
    z[8,2,5]  R1067     1.8015068769454956e-01
    z[8,2,5]  R1068     -5.2143466472625732e-01
    z[8,2,5]  R1069     -8.0909961462020874e-01
    z[8,2,5]  R1070     -6.8678516149520874e-01
    z[8,2,5]  R1071     -5.1308321952819824e-01
    z[8,2,5]  R1072     -4.8027858138084412e-01
    z[8,2,5]  R1073     -5.6475079059600830e-01
    z[8,2,5]  R1074     -6.9524812698364258e-01
    z[8,2,5]  R1075     -0.643557608127594
    z[8,2,5]  R1076     -2.4108362197875977e-01
    z[8,2,5]  R1077     2.2438602149486542e-01
    z[8,2,6]  R26       1
    z[8,2,6]  R80       -1
    z[8,2,6]  R966      -1
    z[8,2,6]  R967      1
    z[8,2,6]  R968      -1.7260447144508362e-02
    z[8,2,6]  R969      -2.0662035793066025e-02
    z[8,2,6]  R970      2.9811248183250427e-01
    z[8,2,6]  R971      -2.7274868916720152e-03
    z[8,2,6]  R972      -4.4423291087150574e-01
    z[8,2,6]  R973      8.1322342157363892e-02
    z[8,2,6]  R974      -2.0091181993484497e-01
    z[8,2,6]  R975      3.0219249427318573e-02
    z[8,2,6]  R976      1.4600034058094025e-01
    z[8,2,6]  R977      -6.8772301077842712e-02
    z[8,2,6]  R978      2.6324397325515747e-01
    z[8,2,6]  R979      -2.4828876554965973e-01
    z[8,2,6]  R980      1.3578110933303833e-01
    z[8,2,6]  R981      -4.7924673557281494e-01
    z[8,2,6]  R982      -0.513411283493042
    z[8,2,6]  R983      -3.8489320874214172e-01
    z[8,2,6]  R984      -0.0986989438533783
    z[8,2,6]  R985      3.8036710023880005e-01
    z[8,2,6]  R986      -3.4328781068325043e-02
    z[8,2,6]  R987      -1.0835714638233185e-01
    z[8,2,6]  R988      2.0683281123638153e-01
    z[8,2,6]  R989      3.1815614551305771e-02
    z[8,2,6]  R990      1.8912982940673828e-01
    z[8,2,6]  R991      -3.9436578750610352e-01
    z[8,2,6]  R992      -7.2801060974597931e-02
    z[8,2,6]  R993      -1.9014558196067810e-01
    z[8,2,6]  R994      2.1530769765377045e-01
    z[8,2,6]  R995      8.7286166846752167e-02
    z[8,2,6]  R996      -2.7257224917411804e-01
    z[8,2,6]  R997      2.3130492866039276e-01
    z[8,2,6]  R998      1.0132461041212082e-01
    z[8,2,6]  R999      1.9825181365013123e-01
    z[8,2,6]  R1000     3.6885300278663635e-01
    z[8,2,6]  R1001     -0.0913926288485527
    z[8,2,6]  R1002     2.9600170254707336e-01
    z[8,2,6]  R1003     2.7688222005963326e-02
    z[8,2,6]  R1004     -4.8201397061347961e-02
    z[8,2,6]  R1005     1.9878593087196350e-01
    z[8,2,6]  R1006     2.0137897133827209e-01
    z[8,2,6]  R1007     1.9239969551563263e-01
    z[8,2,6]  R1008     -1.3886536657810211e-01
    z[8,2,6]  R1009     7.5013726949691772e-02
    z[8,2,6]  R1010     -2.0114743709564209e-01
    z[8,2,6]  R1011     3.1841254234313965e-01
    z[8,2,6]  R1012     -1.0493180155754089e-01
    z[8,2,6]  R1013     1.1313805729150772e-01
    z[8,2,6]  R1014     4.9736884236335754e-01
    z[8,2,6]  R1015     2.2158469259738922e-01
    z[8,2,6]  R1016     2.3445343971252441e-01
    z[8,2,6]  R1017     -5.0230240821838379e-01
    z[8,2,6]  R1018     0.261868417263031
    z[8,2,6]  R1019     -3.0893087387084961e-02
    z[8,2,6]  R1020     -5.2927918732166290e-03
    z[8,2,6]  R1021     -7.3460757732391357e-02
    z[8,2,6]  R1022     -0.201044961810112
    z[8,2,6]  R1023     -4.5461758971214294e-02
    z[8,2,6]  R1024     -1.4415824413299561e-01
    z[8,2,6]  R1025     -7.7320039272308350e-02
    z[8,2,6]  R1026     -2.7034339308738708e-01
    z[8,2,6]  R1027     0.0845186710357666
    z[8,2,6]  R1028     2.7805145364254713e-03
    z[8,2,6]  R1029     8.3542689681053162e-03
    z[8,2,6]  R1030     -2.8224778175354004e-01
    z[8,2,6]  R1031     1.4170059561729431e-01
    z[8,2,6]  R1032     4.2444637417793274e-01
    z[8,2,6]  R1033     3.5754811763763428e-01
    z[8,2,6]  R1034     5.6581471115350723e-02
    z[8,2,6]  R1035     -1.1086313426494598e-01
    z[8,2,6]  R1036     2.4395607411861420e-02
    z[8,2,6]  R1037     0.0748407393693924
    z[8,2,6]  R1038     -1.0414259135723114e-01
    z[8,2,6]  R1039     -4.4331338256597519e-02
    z[8,2,6]  R1040     3.3066761493682861e-01
    z[8,2,6]  R1041     -1.3299232721328735e-01
    z[8,2,6]  R1042     -1.5949106216430664e-01
    z[8,2,6]  R1043     -3.6813411116600037e-01
    z[8,2,6]  R1044     -3.6560556292533875e-01
    z[8,2,6]  R1045     -2.1807946264743805e-01
    z[8,2,6]  R1046     -3.5904118418693542e-01
    z[8,2,6]  R1047     5.0126284360885620e-01
    z[8,2,6]  R1048     -9.4208948314189911e-02
    z[8,2,6]  R1049     1.6494569182395935e-01
    z[8,2,6]  R1050     -1.3512144982814789e-01
    z[8,2,6]  R1051     -2.5242233276367188e-01
    z[8,2,6]  R1052     -4.4038379192352295e-01
    z[8,2,6]  R1053     1.2994153797626495e-01
    z[8,2,6]  R1054     1.3858821988105774e-01
    z[8,2,6]  R1055     1.2574154138565063e-01
    z[8,2,6]  R1056     1.4876842498779297e-02
    z[8,2,6]  R1057     -0.138673335313797
    z[8,2,6]  R1058     -1.7870176816359162e-03
    z[8,2,6]  R1059     -7.4849396944046021e-02
    z[8,2,6]  R1060     -0.00873769260942936
    z[8,2,6]  R1061     -3.3102288842201233e-02
    z[8,2,6]  R1062     1.8266259133815765e-01
    z[8,2,6]  R1063     -1.8044899404048920e-01
    z[8,2,6]  R1064     -1.6020901501178741e-01
    z[8,2,6]  R1065     2.0764118432998657e-01
    z[8,2,6]  R1066     3.0501919984817505e-01
    z[8,2,6]  R1067     1.5341801941394806e-01
    z[8,2,6]  R1068     -2.0680311322212219e-01
    z[8,2,6]  R1069     1.1379343271255493e-01
    z[8,2,6]  R1070     0.097191721200943
    z[8,2,6]  R1071     2.9394736886024475e-01
    z[8,2,6]  R1072     2.1659180521965027e-01
    z[8,2,6]  R1073     2.8197491168975830e-01
    z[8,2,6]  R1074     -1.6610570251941681e-01
    z[8,2,6]  R1075     4.8151633143424988e-01
    z[8,2,6]  R1076     2.0062738656997681e-01
    z[8,2,6]  R1077     3.5508644580841064e-01
    z[2,9,0]  R20       -1
    z[2,9,0]  R83       1
    z[2,9,0]  R1078     -1
    z[2,9,0]  R1079     1
    z[2,9,0]  R1092     -8.6114391684532166e-02
    z[2,9,0]  R1093     -2.6662680506706238e-01
    z[2,9,0]  R1094     -5.2559429407119751e-01
    z[2,9,0]  R1095     1.3804684579372406e-01
    z[2,9,0]  R1096     -1.7923644185066223e-01
    z[2,9,0]  R1097     2.6704484224319458e-01
    z[2,9,0]  R1098     -9.4874203205108643e-02
    z[2,9,0]  R1099     1.7659552395343781e-01
    z[2,9,0]  R1100     3.6078906059265137e-01
    z[2,9,0]  R1101     1.1271440237760544e-01
    z[2,9,0]  R1102     1.9500410556793213e-01
    z[2,9,0]  R1103     2.3636843264102936e-01
    z[2,9,0]  R1104     3.1732618808746338e-01
    z[2,9,0]  R1105     8.7245799601078033e-02
    z[2,9,0]  R1106     1.6199515759944916e-01
    z[2,9,0]  R1107     4.6486815810203552e-01
    z[2,9,0]  R1108     -1.2235434353351593e-01
    z[2,9,0]  R1109     -1.1196144670248032e-01
    z[2,9,0]  R1110     -1.0307740420103073e-01
    z[2,9,0]  R1111     -2.4501538276672363e-01
    z[2,9,0]  R1112     -1.9803822040557861e-01
    z[2,9,0]  R1113     2.5238662958145142e-01
    z[2,9,0]  R1114     -1.1824974417686462e-01
    z[2,9,0]  R1115     9.9914371967315674e-02
    z[2,9,0]  R1116     2.4679099023342133e-01
    z[2,9,0]  R1117     3.8315400481224060e-02
    z[2,9,0]  R1118     -2.7499571442604065e-01
    z[2,9,0]  R1119     -3.7888471037149429e-02
    z[2,9,0]  R1120     -4.1742104291915894e-01
    z[2,9,0]  R1121     4.5252367854118347e-01
    z[2,9,0]  R1122     -2.2583612799644470e-01
    z[2,9,0]  R1123     -6.3919335603713989e-02
    z[2,9,0]  R1124     -6.7560482025146484e-01
    z[2,9,0]  R1125     -6.5368419885635376e-01
    z[2,9,0]  R1126     -9.0757891535758972e-02
    z[2,9,0]  R1127     4.4519278407096863e-01
    z[2,9,0]  R1128     3.5323637723922729e-01
    z[2,9,0]  R1129     -5.9289741516113281e-01
    z[2,9,0]  R1130     -1.8929685652256012e-01
    z[2,9,0]  R1131     1.3136033713817596e-01
    z[2,9,0]  R1132     2.3055012524127960e-01
    z[2,9,0]  R1133     1.2396096438169479e-01
    z[2,9,0]  R1134     4.2159575223922729e-01
    z[2,9,0]  R1135     -8.1610918045043945e-02
    z[2,9,0]  R1136     -2.1789768710732460e-02
    z[2,9,0]  R1137     -1.4977262914180756e-01
    z[2,9,0]  R1138     -1.1833619326353073e-01
    z[2,9,0]  R1139     -1.9463555514812469e-01
    z[2,9,0]  R1140     1.4824509620666504e-01
    z[2,9,0]  R1141     1.2747310101985931e-02
    z[2,9,0]  R1142     -5.1304832100868225e-02
    z[2,9,0]  R1143     6.9660387933254242e-02
    z[2,9,0]  R1144     -3.2370465993881226e-01
    z[2,9,0]  R1145     -1.6792871057987213e-01
    z[2,9,0]  R1146     1.7671565711498260e-01
    z[2,9,0]  R1147     6.2303312122821808e-02
    z[2,9,0]  R1148     -8.3578817546367645e-02
    z[2,9,0]  R1149     -3.5809274762868881e-02
    z[2,9,0]  R1150     0.321304053068161
    z[2,9,0]  R1151     -2.4650232493877411e-01
    z[2,9,0]  R1152     7.9818665981292725e-02
    z[2,9,0]  R1153     -1.3058078475296497e-02
    z[2,9,0]  R1154     -8.2875989377498627e-02
    z[2,9,0]  R1155     -1.0611154884099960e-01
    z[2,9,0]  R1156     4.4820201396942139e-01
    z[2,9,0]  R1157     1.6390676796436310e-01
    z[2,9,0]  R1158     -2.9395204037427902e-02
    z[2,9,0]  R1159     1.3103142380714417e-01
    z[2,9,0]  R1160     -2.9077364131808281e-02
    z[2,9,0]  R1161     -9.6925839781761169e-02
    z[2,9,0]  R1162     -1.0229860199615359e-03
    z[2,9,0]  R1163     0.0597953163087368
    z[2,9,0]  R1164     1.5860667824745178e-01
    z[2,9,0]  R1165     4.5685794949531555e-01
    z[2,9,0]  R1166     -1.3246141374111176e-01
    z[2,9,0]  R1167     1.3124756515026093e-01
    z[2,9,0]  R1168     -1.8175707757472992e-01
    z[2,9,0]  R1169     1.6447648406028748e-01
    z[2,9,0]  R1170     -6.8660169839859009e-02
    z[2,9,0]  R1171     1.8588909506797791e-01
    z[2,9,0]  R1172     4.0934991091489792e-02
    z[2,9,0]  R1173     8.4374286234378815e-02
    z[2,9,0]  R1174     -3.5348582267761230e-01
    z[2,9,0]  R1175     6.3521102070808411e-02
    z[2,9,0]  R1176     1.7299221456050873e-01
    z[2,9,0]  R1177     4.0706256031990051e-01
    z[2,9,0]  R1178     3.1329661607742310e-01
    z[2,9,0]  R1179     -2.1327106654644012e-01
    z[2,9,0]  R1180     -3.1297969818115234e-01
    z[2,9,0]  R1181     9.2750859260559082e-01
    z[2,9,1]  R21       -1
    z[2,9,1]  R84       1
    z[2,9,1]  R1080     -1
    z[2,9,1]  R1081     1
    z[2,9,1]  R1092     -6.2125867605209351e-01
    z[2,9,1]  R1093     -5.1839131116867065e-01
    z[2,9,1]  R1094     -6.4223206043243408e-01
    z[2,9,1]  R1095     -8.5852009057998657e-01
    z[2,9,1]  R1096     -8.8854783773422241e-01
    z[2,9,1]  R1097     7.0590265095233917e-02
    z[2,9,1]  R1098     -2.2162930667400360e-01
    z[2,9,1]  R1099     9.3165911734104156e-02
    z[2,9,1]  R1100     1.9307444989681244e-01
    z[2,9,1]  R1101     -0.20382159948349
    z[2,9,1]  R1102     4.5184570550918579e-01
    z[2,9,1]  R1103     3.8862824440002441e-01
    z[2,9,1]  R1104     4.1592359542846680e-01
    z[2,9,1]  R1105     0.513628363609314
    z[2,9,1]  R1106     3.7828582525253296e-01
    z[2,9,1]  R1107     2.9255113005638123e-01
    z[2,9,1]  R1108     6.3944053649902344e-01
    z[2,9,1]  R1109     4.4198375940322876e-01
    z[2,9,1]  R1110     8.5158699750900269e-01
    z[2,9,1]  R1111     8.5738492012023926e-01
    z[2,9,1]  R1112     -0.656193733215332
    z[2,9,1]  R1113     -6.1848628520965576e-01
    z[2,9,1]  R1114     -7.4918586015701294e-01
    z[2,9,1]  R1115     2.0149391144514084e-02
    z[2,9,1]  R1116     -2.6095548644661903e-02
    z[2,9,1]  R1117     0.0388895608484745
    z[2,9,1]  R1118     2.8341708704829216e-02
    z[2,9,1]  R1119     0.139244943857193
    z[2,9,1]  R1120     8.0143705010414124e-02
    z[2,9,1]  R1121     8.4198370575904846e-02
    z[2,9,1]  R1122     8.9956164360046387e-01
    z[2,9,1]  R1123     9.5434391498565674e-01
    z[2,9,1]  R1124     4.5133581757545471e-01
    z[2,9,1]  R1125     5.8734935522079468e-01
    z[2,9,1]  R1126     8.0117923021316528e-01
    z[2,9,1]  R1127     8.0742782354354858e-01
    z[2,9,1]  R1128     7.7990013360977173e-01
    z[2,9,1]  R1129     4.0210062265396118e-01
    z[2,9,1]  R1130     7.3686122894287109e-01
    z[2,9,1]  R1131     7.2755759954452515e-01
    z[2,9,1]  R1132     8.9741885662078857e-01
    z[2,9,1]  R1133     0.683401346206665
    z[2,9,1]  R1134     6.6133803129196167e-01
    z[2,9,1]  R1135     3.7302395701408386e-01
    z[2,9,1]  R1136     7.2715944051742554e-01
    z[2,9,1]  R1137     -7.9600110650062561e-02
    z[2,9,1]  R1138     -8.5365541279315948e-02
    z[2,9,1]  R1139     2.9185783863067627e-01
    z[2,9,1]  R1140     4.7772899270057678e-01
    z[2,9,1]  R1141     -2.7412655949592590e-01
    z[2,9,1]  R1142     0.836509644985199
    z[2,9,1]  R1143     -1.0116760432720184e-01
    z[2,9,1]  R1144     3.7425440549850464e-01
    z[2,9,1]  R1145     6.4585089683532715e-01
    z[2,9,1]  R1146     6.5990155935287476e-01
    z[2,9,1]  R1147     6.5809983015060425e-01
    z[2,9,1]  R1148     3.7371945381164551e-01
    z[2,9,1]  R1149     4.0544113516807556e-01
    z[2,9,1]  R1150     1.9971008598804474e-01
    z[2,9,1]  R1151     6.8549059331417084e-02
    z[2,9,1]  R1152     9.0633255243301392e-01
    z[2,9,1]  R1153     8.5411381721496582e-01
    z[2,9,1]  R1154     7.6084333658218384e-01
    z[2,9,1]  R1155     3.5391521453857422e-01
    z[2,9,1]  R1156     6.8245339393615723e-01
    z[2,9,1]  R1157     4.8359535634517670e-02
    z[2,9,1]  R1158     -4.0118005126714706e-03
    z[2,9,1]  R1159     3.0325686931610107e-01
    z[2,9,1]  R1160     -3.0065795779228210e-01
    z[2,9,1]  R1161     3.0287555418908596e-03
    z[2,9,1]  R1162     9.2261385917663574e-01
    z[2,9,1]  R1163     8.4715765714645386e-01
    z[2,9,1]  R1164     -4.4515966437757015e-03
    z[2,9,1]  R1165     6.7066210508346558e-01
    z[2,9,1]  R1166     1.9737848639488220e-01
    z[2,9,1]  R1167     2.5924494862556458e-01
    z[2,9,1]  R1168     2.1058626472949982e-02
    z[2,9,1]  R1169     3.7837183475494385e-01
    z[2,9,1]  R1170     8.6386218667030334e-02
    z[2,9,1]  R1171     -2.2493258118629456e-02
    z[2,9,1]  R1172     3.6461940407752991e-01
    z[2,9,1]  R1173     9.3463861942291260e-01
    z[2,9,1]  R1174     -6.1719310283660889e-01
    z[2,9,1]  R1175     7.5483016669750214e-02
    z[2,9,1]  R1176     1.4851692318916321e-01
    z[2,9,1]  R1177     1.9161993637681007e-02
    z[2,9,1]  R1178     4.6353090554475784e-02
    z[2,9,1]  R1179     -6.9504901766777039e-02
    z[2,9,1]  R1180     8.4414362907409668e-02
    z[2,9,1]  R1181     -3.2704740762710571e-01
    z[2,9,2]  R22       -1
    z[2,9,2]  R85       1
    z[2,9,2]  R1082     -1
    z[2,9,2]  R1083     1
    z[2,9,2]  R1092     6.4191657304763794e-01
    z[2,9,2]  R1093     5.4716587066650391e-01
    z[2,9,2]  R1094     4.7255662083625793e-01
    z[2,9,2]  R1095     3.6511132121086121e-01
    z[2,9,2]  R1096     5.3928568959236145e-02
    z[2,9,2]  R1097     -4.6291261911392212e-01
    z[2,9,2]  R1098     -6.8764805793762207e-01
    z[2,9,2]  R1099     -3.6826652288436890e-01
    z[2,9,2]  R1100     -4.5904904603958130e-01
    z[2,9,2]  R1101     -9.3029528856277466e-01
    z[2,9,2]  R1102     6.2224364280700684e-01
    z[2,9,2]  R1103     3.3884134888648987e-01
    z[2,9,2]  R1104     2.3745256662368774e-01
    z[2,9,2]  R1105     6.0588216781616211e-01
    z[2,9,2]  R1106     5.2405965328216553e-01
    z[2,9,2]  R1107     5.2620679140090942e-01
    z[2,9,2]  R1108     2.5405415892601013e-01
    z[2,9,2]  R1109     2.0580118894577026e-01
    z[2,9,2]  R1110     1.7980951070785522e-01
    z[2,9,2]  R1111     1.2643806636333466e-01
    z[2,9,2]  R1112     6.0119831562042236e-01
    z[2,9,2]  R1113     6.5845674276351929e-01
    z[2,9,2]  R1114     -3.7292090058326721e-01
    z[2,9,2]  R1115     -1.6844037920236588e-02
    z[2,9,2]  R1116     0.208670973777771
    z[2,9,2]  R1117     5.1197123527526855e-01
    z[2,9,2]  R1118     2.3732237517833710e-01
    z[2,9,2]  R1119     2.5929355621337891e-01
    z[2,9,2]  R1120     -2.3566943407058716e-01
    z[2,9,2]  R1121     -1.7263881862163544e-01
    z[2,9,2]  R1122     -1.1932317912578583e-01
    z[2,9,2]  R1123     -4.7704420983791351e-02
    z[2,9,2]  R1124     1.5714508295059204e-01
    z[2,9,2]  R1125     3.1169608235359192e-01
    z[2,9,2]  R1126     -1.5421368181705475e-01
    z[2,9,2]  R1127     1.0783152282238007e-01
    z[2,9,2]  R1128     -3.2978415489196777e-01
    z[2,9,2]  R1129     -1.9020775333046913e-02
    z[2,9,2]  R1130     -0.388967901468277
    z[2,9,2]  R1131     -0.0613291971385479
    z[2,9,2]  R1132     2.5621551275253296e-01
    z[2,9,2]  R1133     3.0200770497322083e-01
    z[2,9,2]  R1134     2.6487665250897408e-02
    z[2,9,2]  R1135     5.3616754710674286e-02
    z[2,9,2]  R1136     2.7006408572196960e-01
    z[2,9,2]  R1137     -3.5139295458793640e-01
    z[2,9,2]  R1138     9.5755748450756073e-02
    z[2,9,2]  R1139     1.0427531599998474e-01
    z[2,9,2]  R1140     0.0639515370130539
    z[2,9,2]  R1141     -2.7095419168472290e-01
    z[2,9,2]  R1142     1.4329145848751068e-01
    z[2,9,2]  R1143     5.3386755287647247e-02
    z[2,9,2]  R1144     -2.5896275043487549e-01
    z[2,9,2]  R1145     -2.8887179493904114e-01
    z[2,9,2]  R1146     3.2635146379470825e-01
    z[2,9,2]  R1147     -5.0705488771200180e-02
    z[2,9,2]  R1148     2.8788352012634277e-01
    z[2,9,2]  R1149     -2.5966507196426392e-01
    z[2,9,2]  R1150     -1.2561090290546417e-02
    z[2,9,2]  R1151     3.4817758202552795e-01
    z[2,9,2]  R1152     1.0591665655374527e-01
    z[2,9,2]  R1153     -3.5850632190704346e-01
    z[2,9,2]  R1154     -4.2443636059761047e-01
    z[2,9,2]  R1155     5.0838928669691086e-02
    z[2,9,2]  R1156     1.2665954232215881e-01
    z[2,9,2]  R1157     1.7349500954151154e-01
    z[2,9,2]  R1158     3.4177505970001221e-01
    z[2,9,2]  R1159     -2.2517672181129456e-01
    z[2,9,2]  R1160     -3.2769733667373657e-01
    z[2,9,2]  R1161     7.5107440352439880e-02
    z[2,9,2]  R1162     -1.1293012648820877e-01
    z[2,9,2]  R1163     2.7016565203666687e-01
    z[2,9,2]  R1164     0.284115195274353
    z[2,9,2]  R1165     -2.3836031556129456e-01
    z[2,9,2]  R1166     -3.4947404265403748e-01
    z[2,9,2]  R1167     -1.2920296192169189e-01
    z[2,9,2]  R1168     -4.3436264991760254e-01
    z[2,9,2]  R1169     -2.1037213504314423e-01
    z[2,9,2]  R1170     4.2275067418813705e-02
    z[2,9,2]  R1171     -3.4015023708343506e-01
    z[2,9,2]  R1172     2.7779853343963623e-01
    z[2,9,2]  R1173     5.8591767447069287e-04
    z[2,9,2]  R1174     -2.4033807218074799e-01
    z[2,9,2]  R1175     -1.5402874350547791e-01
    z[2,9,2]  R1176     -7.2709627449512482e-02
    z[2,9,2]  R1177     -4.8643833398818970e-01
    z[2,9,2]  R1178     -4.1759368777275085e-01
    z[2,9,2]  R1179     -2.0346195995807648e-01
    z[2,9,2]  R1180     -1.0566321760416031e-01
    z[2,9,2]  R1181     -1.2967251241207123e-01
    z[2,9,3]  R23       -1
    z[2,9,3]  R86       1
    z[2,9,3]  R1084     -1
    z[2,9,3]  R1085     1
    z[2,9,3]  R1092     3.7220796942710876e-01
    z[2,9,3]  R1093     4.6839761734008789e-01
    z[2,9,3]  R1094     1.6719271242618561e-01
    z[2,9,3]  R1095     1.2000499665737152e-01
    z[2,9,3]  R1096     2.8061398863792419e-01
    z[2,9,3]  R1097     7.1794402599334717e-01
    z[2,9,3]  R1098     5.9474724531173706e-01
    z[2,9,3]  R1099     8.6313569545745850e-01
    z[2,9,3]  R1100     4.6029153466224670e-01
    z[2,9,3]  R1101     1.5579879283905029e-01
    z[2,9,3]  R1102     -8.6404690518975258e-03
    z[2,9,3]  R1103     -1.1484029702842236e-02
    z[2,9,3]  R1104     7.7955529093742371e-02
    z[2,9,3]  R1105     -1.7613553791306913e-04
    z[2,9,3]  R1106     1.1394208669662476e-01
    z[2,9,3]  R1107     2.9837839305400848e-02
    z[2,9,3]  R1108     -4.2753354646265507e-03
    z[2,9,3]  R1109     2.0318765193223953e-02
    z[2,9,3]  R1110     -2.0815165340900421e-01
    z[2,9,3]  R1111     -9.9909320473670959e-02
    z[2,9,3]  R1112     2.6745793223381042e-01
    z[2,9,3]  R1113     2.1631832420825958e-01
    z[2,9,3]  R1114     4.9046754837036133e-01
    z[2,9,3]  R1115     8.1015920639038086e-01
    z[2,9,3]  R1116     8.7596577405929565e-01
    z[2,9,3]  R1117     6.1187815666198730e-01
    z[2,9,3]  R1118     6.0210049152374268e-01
    z[2,9,3]  R1119     5.6074738502502441e-01
    z[2,9,3]  R1120     4.2829075455665588e-01
    z[2,9,3]  R1121     8.7676249444484711e-02
    z[2,9,3]  R1122     3.2030718284659088e-04
    z[2,9,3]  R1123     -1.5726526081562042e-01
    z[2,9,3]  R1124     0.510026752948761
    z[2,9,3]  R1125     2.9189857840538025e-01
    z[2,9,3]  R1126     5.0670951604843140e-01
    z[2,9,3]  R1127     2.1482449956238270e-03
    z[2,9,3]  R1128     0.194418266415596
    z[2,9,3]  R1129     5.4579585790634155e-01
    z[2,9,3]  R1130     1.1006633937358856e-01
    z[2,9,3]  R1131     0.210173562169075
    z[2,9,3]  R1132     -1.1477672308683395e-01
    z[2,9,3]  R1133     1.6191175580024719e-01
    z[2,9,3]  R1134     7.8962184488773346e-02
    z[2,9,3]  R1135     7.9013293981552124e-01
    z[2,9,3]  R1136     5.6404348462820053e-02
    z[2,9,3]  R1137     -4.3802550435066223e-01
    z[2,9,3]  R1138     -4.9159732460975647e-01
    z[2,9,3]  R1139     3.3527228236198425e-01
    z[2,9,3]  R1140     0.500817060470581
    z[2,9,3]  R1141     -4.3633630871772766e-01
    z[2,9,3]  R1142     9.9438525736331940e-02
    z[2,9,3]  R1143     1.9843837618827820e-01
    z[2,9,3]  R1144     5.3493392467498779e-01
    z[2,9,3]  R1145     -1.0884377360343933e-01
    z[2,9,3]  R1146     4.5015761256217957e-01
    z[2,9,3]  R1147     1.1064665019512177e-01
    z[2,9,3]  R1148     5.5983585119247437e-01
    z[2,9,3]  R1149     6.4900976419448853e-01
    z[2,9,3]  R1150     -0.381475031375885
    z[2,9,3]  R1151     4.9845075607299805e-01
    z[2,9,3]  R1152     1.0783334076404572e-01
    z[2,9,3]  R1153     7.5359144248068333e-03
    z[2,9,3]  R1154     -1.3345412909984589e-01
    z[2,9,3]  R1155     8.1412959098815918e-01
    z[2,9,3]  R1156     4.1875693202018738e-01
    z[2,9,3]  R1157     7.2381514310836792e-01
    z[2,9,3]  R1158     0.524556577205658
    z[2,9,3]  R1159     -4.8285833001136780e-01
    z[2,9,3]  R1160     -6.8804478645324707e-01
    z[2,9,3]  R1161     -6.6409087181091309e-01
    z[2,9,3]  R1162     6.1818454414606094e-02
    z[2,9,3]  R1163     3.6368572711944580e-01
    z[2,9,3]  R1164     7.0382076501846313e-01
    z[2,9,3]  R1165     1.5992195904254913e-01
    z[2,9,3]  R1166     -6.0701805353164673e-01
    z[2,9,3]  R1167     -5.1418608427047729e-01
    z[2,9,3]  R1168     -0.731490433216095
    z[2,9,3]  R1169     5.5768400430679321e-01
    z[2,9,3]  R1170     2.6345852017402649e-01
    z[2,9,3]  R1171     -9.4710178673267365e-02
    z[2,9,3]  R1172     7.2435122728347778e-01
    z[2,9,3]  R1173     3.2289031893014908e-02
    z[2,9,3]  R1174     -3.7586545944213867e-01
    z[2,9,3]  R1175     5.9365427494049072e-01
    z[2,9,3]  R1176     -0.61862713098526
    z[2,9,3]  R1177     1.6522195935249329e-01
    z[2,9,3]  R1178     2.1658472716808319e-01
    z[2,9,3]  R1179     1.1529392749071121e-01
    z[2,9,3]  R1180     2.3029154539108276e-01
    z[2,9,3]  R1181     -3.3830992877483368e-02
    z[2,9,4]  R24       -1
    z[2,9,4]  R87       1
    z[2,9,4]  R1086     -1
    z[2,9,4]  R1087     1
    z[2,9,4]  R1092     2.6416091248393059e-02
    z[2,9,4]  R1093     -3.3045294880867004e-01
    z[2,9,4]  R1094     1.0801636381074786e-03
    z[2,9,4]  R1095     -5.0684046000242233e-02
    z[2,9,4]  R1096     -1.1764678172767162e-02
    z[2,9,4]  R1097     -3.6642208695411682e-01
    z[2,9,4]  R1098     -2.5889590382575989e-01
    z[2,9,4]  R1099     2.6452008169144392e-03
    z[2,9,4]  R1100     -5.5785093456506729e-02
    z[2,9,4]  R1101     -6.1872941441833973e-03
    z[2,9,4]  R1102     2.3640081286430359e-01
    z[2,9,4]  R1103     -1.0277015715837479e-01
    z[2,9,4]  R1104     4.2747011780738831e-01
    z[2,9,4]  R1105     -1.0872618108987808e-01
    z[2,9,4]  R1106     5.1522469520568848e-01
    z[2,9,4]  R1107     1.4857383072376251e-01
    z[2,9,4]  R1108     2.4948436766862869e-02
    z[2,9,4]  R1109     3.2144007086753845e-01
    z[2,9,4]  R1110     3.0023893713951111e-01
    z[2,9,4]  R1111     -4.9544990062713623e-02
    z[2,9,4]  R1112     -2.2025765478610992e-01
    z[2,9,4]  R1113     4.9540884792804718e-02
    z[2,9,4]  R1114     -1.9937008619308472e-01
    z[2,9,4]  R1115     1.5698830783367157e-01
    z[2,9,4]  R1116     -1.9919518381357193e-02
    z[2,9,4]  R1117     -5.7643294334411621e-01
    z[2,9,4]  R1118     -4.1490471363067627e-01
    z[2,9,4]  R1119     -6.8947827816009521e-01
    z[2,9,4]  R1120     8.0657035112380981e-02
    z[2,9,4]  R1121     -2.3938387632369995e-01
    z[2,9,4]  R1122     -2.5749403238296509e-01
    z[2,9,4]  R1123     -1.5698436647653580e-02
    z[2,9,4]  R1124     6.4038641750812531e-02
    z[2,9,4]  R1125     -6.4481054432690144e-03
    z[2,9,4]  R1126     1.4860455691814423e-01
    z[2,9,4]  R1127     2.1630044281482697e-01
    z[2,9,4]  R1128     -1.8657873570919037e-01
    z[2,9,4]  R1129     2.4084559082984924e-01
    z[2,9,4]  R1130     2.0764137804508209e-01
    z[2,9,4]  R1131     2.4053536355495453e-01
    z[2,9,4]  R1132     1.1786674708127975e-01
    z[2,9,4]  R1133     4.6568755060434341e-03
    z[2,9,4]  R1134     2.0146493613719940e-01
    z[2,9,4]  R1135     -4.7542190551757812e-01
    z[2,9,4]  R1136     1.6603556275367737e-01
    z[2,9,4]  R1137     0.263406902551651
    z[2,9,4]  R1138     2.3883616924285889e-01
    z[2,9,4]  R1139     -6.7056399583816528e-01
    z[2,9,4]  R1140     -2.4792028963565826e-01
    z[2,9,4]  R1141     4.6367591619491577e-01
    z[2,9,4]  R1142     2.2562585771083832e-01
    z[2,9,4]  R1143     4.4862195849418640e-01
    z[2,9,4]  R1144     -3.6542826890945435e-01
    z[2,9,4]  R1145     -3.4813615679740906e-01
    z[2,9,4]  R1146     1.0701561719179153e-01
    z[2,9,4]  R1147     -2.8643617033958435e-01
    z[2,9,4]  R1148     -6.4117950201034546e-01
    z[2,9,4]  R1149     -4.3757069110870361e-01
    z[2,9,4]  R1150     3.1786888837814331e-01
    z[2,9,4]  R1151     -3.4919813275337219e-01
    z[2,9,4]  R1152     5.7811133563518524e-02
    z[2,9,4]  R1153     2.5662171840667725e-01
    z[2,9,4]  R1154     -2.6620498299598694e-01
    z[2,9,4]  R1155     -5.4105542600154877e-02
    z[2,9,4]  R1156     -2.5736445188522339e-01
    z[2,9,4]  R1157     -4.0130594372749329e-01
    z[2,9,4]  R1158     -4.9146994948387146e-01
    z[2,9,4]  R1159     4.8633995652198792e-01
    z[2,9,4]  R1160     3.8258891552686691e-02
    z[2,9,4]  R1161     -4.3908131122589111e-01
    z[2,9,4]  R1162     3.5036456584930420e-01
    z[2,9,4]  R1163     3.3553251996636391e-03
    z[2,9,4]  R1164     -5.3329789638519287e-01
    z[2,9,4]  R1165     2.5605052709579468e-01
    z[2,9,4]  R1166     3.9515992999076843e-01
    z[2,9,4]  R1167     2.5869178771972656e-01
    z[2,9,4]  R1168     9.3507938086986542e-02
    z[2,9,4]  R1169     -0.154225692152977
    z[2,9,4]  R1170     -4.0393674373626709e-01
    z[2,9,4]  R1171     -6.1272329092025757e-01
    z[2,9,4]  R1172     2.5348857045173645e-01
    z[2,9,4]  R1173     -2.1339474618434906e-01
    z[2,9,4]  R1174     3.6196881532669067e-01
    z[2,9,4]  R1175     -2.2272971272468567e-01
    z[2,9,4]  R1176     5.5822777748107910e-01
    z[2,9,4]  R1177     -4.1396361589431763e-01
    z[2,9,4]  R1178     -1.0913689434528351e-01
    z[2,9,4]  R1179     -2.0239000022411346e-01
    z[2,9,4]  R1180     -5.0234001874923706e-01
    z[2,9,4]  R1181     1.0885780304670334e-01
    z[2,9,5]  R25       -1
    z[2,9,5]  R88       1
    z[2,9,5]  R1088     -1
    z[2,9,5]  R1089     1
    z[2,9,5]  R1092     2.3521322011947632e-01
    z[2,9,5]  R1093     1.6307172179222107e-01
    z[2,9,5]  R1094     -2.4484235048294067e-01
    z[2,9,5]  R1095     3.0416178703308105e-01
    z[2,9,5]  R1096     0.251397043466568
    z[2,9,5]  R1097     1.6475871205329895e-01
    z[2,9,5]  R1098     -1.5033662319183350e-01
    z[2,9,5]  R1099     1.9075880944728851e-01
    z[2,9,5]  R1100     5.6018787622451782e-01
    z[2,9,5]  R1101     1.8015068769454956e-01
    z[2,9,5]  R1102     -5.2143466472625732e-01
    z[2,9,5]  R1103     -8.0909961462020874e-01
    z[2,9,5]  R1104     -6.8678516149520874e-01
    z[2,9,5]  R1105     -5.1308321952819824e-01
    z[2,9,5]  R1106     -4.8027858138084412e-01
    z[2,9,5]  R1107     -5.6475079059600830e-01
    z[2,9,5]  R1108     -6.9524812698364258e-01
    z[2,9,5]  R1109     -0.643557608127594
    z[2,9,5]  R1110     -2.4108362197875977e-01
    z[2,9,5]  R1111     2.2438602149486542e-01
    z[2,9,5]  R1112     -1.9467087090015411e-01
    z[2,9,5]  R1113     2.6567959785461426e-01
    z[2,9,5]  R1114     2.2427400574088097e-02
    z[2,9,5]  R1115     -5.4391944408416748e-01
    z[2,9,5]  R1116     -3.5637673735618591e-01
    z[2,9,5]  R1117     -4.8700369894504547e-02
    z[2,9,5]  R1118     -7.5534239411354065e-02
    z[2,9,5]  R1119     -3.2818788290023804e-01
    z[2,9,5]  R1120     -4.0075135231018066e-01
    z[2,9,5]  R1121     4.8053160309791565e-01
    z[2,9,5]  R1122     -1.5864242613315582e-01
    z[2,9,5]  R1123     -1.8162797391414642e-01
    z[2,9,5]  R1124     1.1702164262533188e-01
    z[2,9,5]  R1125     1.4710952341556549e-01
    z[2,9,5]  R1126     8.5905738174915314e-02
    z[2,9,5]  R1127     1.8779808282852173e-01
    z[2,9,5]  R1128     -1.3045580685138702e-01
    z[2,9,5]  R1129     1.2709461152553558e-01
    z[2,9,5]  R1130     -4.6299362182617188e-01
    z[2,9,5]  R1131     5.8834099769592285e-01
    z[2,9,5]  R1132     5.4942883551120758e-02
    z[2,9,5]  R1133     3.9418280124664307e-01
    z[2,9,5]  R1134     -0.301368772983551
    z[2,9,5]  R1135     -2.5309933349490166e-02
    z[2,9,5]  R1136     4.2968633770942688e-01
    z[2,9,5]  R1137     7.5681346654891968e-01
    z[2,9,5]  R1138     6.8053728342056274e-01
    z[2,9,5]  R1139     -5.4070943593978882e-01
    z[2,9,5]  R1140     -5.3338271379470825e-01
    z[2,9,5]  R1141     5.2292549610137939e-01
    z[2,9,5]  R1142     2.7252739667892456e-01
    z[2,9,5]  R1143     -4.6664139628410339e-01
    z[2,9,5]  R1144     -0.513565719127655
    z[2,9,5]  R1145     5.2712988853454590e-01
    z[2,9,5]  R1146     -4.5385599136352539e-01
    z[2,9,5]  R1147     5.8251172304153442e-01
    z[2,9,5]  R1148     -2.1387417614459991e-01
    z[2,9,5]  R1149     -1.5060220845043659e-02
    z[2,9,5]  R1150     6.8639487028121948e-01
    z[2,9,5]  R1151     -2.4893115460872650e-01
    z[2,9,5]  R1152     3.8159903883934021e-01
    z[2,9,5]  R1153     1.7658115923404694e-01
    z[2,9,5]  R1154     0.375962495803833
    z[2,9,5]  R1155     -2.2506140172481537e-01
    z[2,9,5]  R1156     -7.0776619017124176e-02
    z[2,9,5]  R1157     -4.2152115702629089e-01
    z[2,9,5]  R1158     -6.0033202171325684e-01
    z[2,9,5]  R1159     5.8392065763473511e-01
    z[2,9,5]  R1160     4.4555336236953735e-01
    z[2,9,5]  R1161     0.540216326713562
    z[2,9,5]  R1162     5.9696469455957413e-02
    z[2,9,5]  R1163     -2.3778945207595825e-01
    z[2,9,5]  R1164     -2.4003544449806213e-01
    z[2,9,5]  R1165     -4.2458108067512512e-01
    z[2,9,5]  R1166     5.4056447744369507e-01
    z[2,9,5]  R1167     7.1215301752090454e-01
    z[2,9,5]  R1168     4.3745765089988708e-01
    z[2,9,5]  R1169     -3.7895795702934265e-01
    z[2,9,5]  R1170     -8.3969587087631226e-01
    z[2,9,5]  R1171     6.5132617950439453e-01
    z[2,9,5]  R1172     -4.1937139630317688e-01
    z[2,9,5]  R1173     -1.4807693660259247e-01
    z[2,9,5]  R1174     0.404939204454422
    z[2,9,5]  R1175     -6.5721738338470459e-01
    z[2,9,5]  R1176     4.8852661252021790e-01
    z[2,9,5]  R1177     3.3111223578453064e-01
    z[2,9,5]  R1178     0.810812771320343
    z[2,9,5]  R1179     0.654262900352478
    z[2,9,5]  R1180     5.9761160612106323e-01
    z[2,9,5]  R1181     -2.4756550788879395e-02
    z[2,9,6]  R26       -1
    z[2,9,6]  R89       1
    z[2,9,6]  R1090     -1
    z[2,9,6]  R1091     1
    z[2,9,6]  R1092     -1.7870176816359162e-03
    z[2,9,6]  R1093     -7.4849396944046021e-02
    z[2,9,6]  R1094     -0.00873769260942936
    z[2,9,6]  R1095     -3.3102288842201233e-02
    z[2,9,6]  R1096     1.8266259133815765e-01
    z[2,9,6]  R1097     -1.8044899404048920e-01
    z[2,9,6]  R1098     -1.6020901501178741e-01
    z[2,9,6]  R1099     2.0764118432998657e-01
    z[2,9,6]  R1100     3.0501919984817505e-01
    z[2,9,6]  R1101     1.5341801941394806e-01
    z[2,9,6]  R1102     -2.0680311322212219e-01
    z[2,9,6]  R1103     1.1379343271255493e-01
    z[2,9,6]  R1104     0.097191721200943
    z[2,9,6]  R1105     2.9394736886024475e-01
    z[2,9,6]  R1106     2.1659180521965027e-01
    z[2,9,6]  R1107     2.8197491168975830e-01
    z[2,9,6]  R1108     -1.6610570251941681e-01
    z[2,9,6]  R1109     4.8151633143424988e-01
    z[2,9,6]  R1110     2.0062738656997681e-01
    z[2,9,6]  R1111     3.5508644580841064e-01
    z[2,9,6]  R1112     1.0395793616771698e-01
    z[2,9,6]  R1113     1.9415576010942459e-02
    z[2,9,6]  R1114     -6.9697767496109009e-02
    z[2,9,6]  R1115     1.1169490963220596e-01
    z[2,9,6]  R1116     -1.2352060526609421e-02
    z[2,9,6]  R1117     1.6082102060317993e-01
    z[2,9,6]  R1118     5.7173055410385132e-01
    z[2,9,6]  R1119     -1.2007039785385132e-01
    z[2,9,6]  R1120     6.4285027980804443e-01
    z[2,9,6]  R1121     6.8001949787139893e-01
    z[2,9,6]  R1122     1.8460302054882050e-01
    z[2,9,6]  R1123     -1.5779319405555725e-01
    z[2,9,6]  R1124     1.9296933710575104e-01
    z[2,9,6]  R1125     -1.5386903285980225e-01
    z[2,9,6]  R1126     1.9968789815902710e-01
    z[2,9,6]  R1127     -2.3701782524585724e-01
    z[2,9,6]  R1128     -2.6190373301506042e-01
    z[2,9,6]  R1129     -3.3819109201431274e-01
    z[2,9,6]  R1130     -1.7705438658595085e-02
    z[2,9,6]  R1131     -3.8312196731567383e-02
    z[2,9,6]  R1132     -2.1390339732170105e-01
    z[2,9,6]  R1133     4.9474292993545532e-01
    z[2,9,6]  R1134     4.9652910232543945e-01
    z[2,9,6]  R1135     1.8477691337466240e-02
    z[2,9,6]  R1136     4.2714181542396545e-01
    z[2,9,6]  R1137     1.1721289902925491e-01
    z[2,9,6]  R1138     4.5573955774307251e-01
    z[2,9,6]  R1139     -1.0785336047410965e-01
    z[2,9,6]  R1140     -3.8591352105140686e-01
    z[2,9,6]  R1141     -4.1525909304618835e-01
    z[2,9,6]  R1142     3.7685650587081909e-01
    z[2,9,6]  R1143     -7.2364950180053711e-01
    z[2,9,6]  R1144     6.8157516419887543e-02
    z[2,9,6]  R1145     -2.4559737741947174e-01
    z[2,9,6]  R1146     8.1955626606941223e-02
    z[2,9,6]  R1147     -3.5615113377571106e-01
    z[2,9,6]  R1148     1.4210730791091919e-02
    z[2,9,6]  R1149     -3.9242914319038391e-01
    z[2,9,6]  R1150     -3.7285405397415161e-01
    z[2,9,6]  R1151     0.617212176322937
    z[2,9,6]  R1152     -1.9595511257648468e-02
    z[2,9,6]  R1153     -2.1142356097698212e-01
    z[2,9,6]  R1154     -6.3874870538711548e-02
    z[2,9,6]  R1155     3.8014820218086243e-01
    z[2,9,6]  R1156     2.6594460010528564e-01
    z[2,9,6]  R1157     -2.7939301729202271e-01
    z[2,9,6]  R1158     7.2171583771705627e-02
    z[2,9,6]  R1159     -1.7181229591369629e-01
    z[2,9,6]  R1160     -3.5775211453437805e-01
    z[2,9,6]  R1161     -2.4354150891304016e-01
    z[2,9,6]  R1162     7.6739199459552765e-02
    z[2,9,6]  R1163     1.3014088571071625e-01
    z[2,9,6]  R1164     -2.3814998567104340e-01
    z[2,9,6]  R1165     1.1520184576511383e-01
    z[2,9,6]  R1166     6.7315578460693359e-02
    z[2,9,6]  R1167     -2.4576807022094727e-01
    z[2,9,6]  R1168     -0.206540048122406
    z[2,9,6]  R1169     -5.5418390035629272e-01
    z[2,9,6]  R1170     -2.1993513405323029e-01
    z[2,9,6]  R1171     2.0152269303798676e-01
    z[2,9,6]  R1172     -1.5294280648231506e-01
    z[2,9,6]  R1173     -2.2544318437576294e-01
    z[2,9,6]  R1174     -9.2782024294137955e-03
    z[2,9,6]  R1175     -3.6410698294639587e-01
    z[2,9,6]  R1176     -9.8761796951293945e-02
    z[2,9,6]  R1177     5.3759759664535522e-01
    z[2,9,6]  R1178     -9.5262423157691956e-02
    z[2,9,6]  R1179     6.5266633033752441e-01
    z[2,9,6]  R1180     4.7035521268844604e-01
    z[2,9,6]  R1181     4.8429798334836960e-02
    z[9,2,0]  R20       1
    z[9,2,0]  R83       -1
    z[9,2,0]  R1182     -1
    z[9,2,0]  R1183     1
    z[9,2,0]  R1196     -1.9803822040557861e-01
    z[9,2,0]  R1197     2.5238662958145142e-01
    z[9,2,0]  R1198     -1.1824974417686462e-01
    z[9,2,0]  R1199     9.9914371967315674e-02
    z[9,2,0]  R1200     2.4679099023342133e-01
    z[9,2,0]  R1201     3.8315400481224060e-02
    z[9,2,0]  R1202     -2.7499571442604065e-01
    z[9,2,0]  R1203     -3.7888471037149429e-02
    z[9,2,0]  R1204     -4.1742104291915894e-01
    z[9,2,0]  R1205     4.5252367854118347e-01
    z[9,2,0]  R1206     -2.2583612799644470e-01
    z[9,2,0]  R1207     -6.3919335603713989e-02
    z[9,2,0]  R1208     -6.7560482025146484e-01
    z[9,2,0]  R1209     -6.5368419885635376e-01
    z[9,2,0]  R1210     -9.0757891535758972e-02
    z[9,2,0]  R1211     4.4519278407096863e-01
    z[9,2,0]  R1212     3.5323637723922729e-01
    z[9,2,0]  R1213     -5.9289741516113281e-01
    z[9,2,0]  R1214     -1.8929685652256012e-01
    z[9,2,0]  R1215     1.3136033713817596e-01
    z[9,2,0]  R1216     2.3055012524127960e-01
    z[9,2,0]  R1217     1.2396096438169479e-01
    z[9,2,0]  R1218     4.2159575223922729e-01
    z[9,2,0]  R1219     -8.1610918045043945e-02
    z[9,2,0]  R1220     -2.1789768710732460e-02
    z[9,2,0]  R1221     -1.4977262914180756e-01
    z[9,2,0]  R1222     -1.1833619326353073e-01
    z[9,2,0]  R1223     -1.9463555514812469e-01
    z[9,2,0]  R1224     1.4824509620666504e-01
    z[9,2,0]  R1225     1.2747310101985931e-02
    z[9,2,0]  R1226     -5.1304832100868225e-02
    z[9,2,0]  R1227     6.9660387933254242e-02
    z[9,2,0]  R1228     -3.2370465993881226e-01
    z[9,2,0]  R1229     -1.6792871057987213e-01
    z[9,2,0]  R1230     1.7671565711498260e-01
    z[9,2,0]  R1231     6.2303312122821808e-02
    z[9,2,0]  R1232     -8.3578817546367645e-02
    z[9,2,0]  R1233     -3.5809274762868881e-02
    z[9,2,0]  R1234     0.321304053068161
    z[9,2,0]  R1235     -2.4650232493877411e-01
    z[9,2,0]  R1236     7.9818665981292725e-02
    z[9,2,0]  R1237     -1.3058078475296497e-02
    z[9,2,0]  R1238     -8.2875989377498627e-02
    z[9,2,0]  R1239     -1.0611154884099960e-01
    z[9,2,0]  R1240     4.4820201396942139e-01
    z[9,2,0]  R1241     1.6390676796436310e-01
    z[9,2,0]  R1242     -2.9395204037427902e-02
    z[9,2,0]  R1243     1.3103142380714417e-01
    z[9,2,0]  R1244     -2.9077364131808281e-02
    z[9,2,0]  R1245     -9.6925839781761169e-02
    z[9,2,0]  R1246     -1.0229860199615359e-03
    z[9,2,0]  R1247     0.0597953163087368
    z[9,2,0]  R1248     1.5860667824745178e-01
    z[9,2,0]  R1249     4.5685794949531555e-01
    z[9,2,0]  R1250     -1.3246141374111176e-01
    z[9,2,0]  R1251     1.3124756515026093e-01
    z[9,2,0]  R1252     -1.8175707757472992e-01
    z[9,2,0]  R1253     1.6447648406028748e-01
    z[9,2,0]  R1254     -6.8660169839859009e-02
    z[9,2,0]  R1255     1.8588909506797791e-01
    z[9,2,0]  R1256     4.0934991091489792e-02
    z[9,2,0]  R1257     8.4374286234378815e-02
    z[9,2,0]  R1258     -3.5348582267761230e-01
    z[9,2,0]  R1259     6.3521102070808411e-02
    z[9,2,0]  R1260     1.7299221456050873e-01
    z[9,2,0]  R1261     4.0706256031990051e-01
    z[9,2,0]  R1262     3.1329661607742310e-01
    z[9,2,0]  R1263     -2.1327106654644012e-01
    z[9,2,0]  R1264     -3.1297969818115234e-01
    z[9,2,0]  R1265     9.2750859260559082e-01
    z[9,2,0]  R1266     -8.6114391684532166e-02
    z[9,2,0]  R1267     -2.6662680506706238e-01
    z[9,2,0]  R1268     -5.2559429407119751e-01
    z[9,2,0]  R1269     1.3804684579372406e-01
    z[9,2,0]  R1270     -1.7923644185066223e-01
    z[9,2,0]  R1271     2.6704484224319458e-01
    z[9,2,0]  R1272     -9.4874203205108643e-02
    z[9,2,0]  R1273     1.7659552395343781e-01
    z[9,2,0]  R1274     3.6078906059265137e-01
    z[9,2,0]  R1275     1.1271440237760544e-01
    z[9,2,0]  R1276     1.9500410556793213e-01
    z[9,2,0]  R1277     2.3636843264102936e-01
    z[9,2,0]  R1278     3.1732618808746338e-01
    z[9,2,0]  R1279     8.7245799601078033e-02
    z[9,2,0]  R1280     1.6199515759944916e-01
    z[9,2,0]  R1281     4.6486815810203552e-01
    z[9,2,0]  R1282     -1.2235434353351593e-01
    z[9,2,0]  R1283     -1.1196144670248032e-01
    z[9,2,0]  R1284     -1.0307740420103073e-01
    z[9,2,0]  R1285     -2.4501538276672363e-01
    z[9,2,1]  R21       1
    z[9,2,1]  R84       -1
    z[9,2,1]  R1184     -1
    z[9,2,1]  R1185     1
    z[9,2,1]  R1196     -0.656193733215332
    z[9,2,1]  R1197     -6.1848628520965576e-01
    z[9,2,1]  R1198     -7.4918586015701294e-01
    z[9,2,1]  R1199     2.0149391144514084e-02
    z[9,2,1]  R1200     -2.6095548644661903e-02
    z[9,2,1]  R1201     0.0388895608484745
    z[9,2,1]  R1202     2.8341708704829216e-02
    z[9,2,1]  R1203     0.139244943857193
    z[9,2,1]  R1204     8.0143705010414124e-02
    z[9,2,1]  R1205     8.4198370575904846e-02
    z[9,2,1]  R1206     8.9956164360046387e-01
    z[9,2,1]  R1207     9.5434391498565674e-01
    z[9,2,1]  R1208     4.5133581757545471e-01
    z[9,2,1]  R1209     5.8734935522079468e-01
    z[9,2,1]  R1210     8.0117923021316528e-01
    z[9,2,1]  R1211     8.0742782354354858e-01
    z[9,2,1]  R1212     7.7990013360977173e-01
    z[9,2,1]  R1213     4.0210062265396118e-01
    z[9,2,1]  R1214     7.3686122894287109e-01
    z[9,2,1]  R1215     7.2755759954452515e-01
    z[9,2,1]  R1216     8.9741885662078857e-01
    z[9,2,1]  R1217     0.683401346206665
    z[9,2,1]  R1218     6.6133803129196167e-01
    z[9,2,1]  R1219     3.7302395701408386e-01
    z[9,2,1]  R1220     7.2715944051742554e-01
    z[9,2,1]  R1221     -7.9600110650062561e-02
    z[9,2,1]  R1222     -8.5365541279315948e-02
    z[9,2,1]  R1223     2.9185783863067627e-01
    z[9,2,1]  R1224     4.7772899270057678e-01
    z[9,2,1]  R1225     -2.7412655949592590e-01
    z[9,2,1]  R1226     0.836509644985199
    z[9,2,1]  R1227     -1.0116760432720184e-01
    z[9,2,1]  R1228     3.7425440549850464e-01
    z[9,2,1]  R1229     6.4585089683532715e-01
    z[9,2,1]  R1230     6.5990155935287476e-01
    z[9,2,1]  R1231     6.5809983015060425e-01
    z[9,2,1]  R1232     3.7371945381164551e-01
    z[9,2,1]  R1233     4.0544113516807556e-01
    z[9,2,1]  R1234     1.9971008598804474e-01
    z[9,2,1]  R1235     6.8549059331417084e-02
    z[9,2,1]  R1236     9.0633255243301392e-01
    z[9,2,1]  R1237     8.5411381721496582e-01
    z[9,2,1]  R1238     7.6084333658218384e-01
    z[9,2,1]  R1239     3.5391521453857422e-01
    z[9,2,1]  R1240     6.8245339393615723e-01
    z[9,2,1]  R1241     4.8359535634517670e-02
    z[9,2,1]  R1242     -4.0118005126714706e-03
    z[9,2,1]  R1243     3.0325686931610107e-01
    z[9,2,1]  R1244     -3.0065795779228210e-01
    z[9,2,1]  R1245     3.0287555418908596e-03
    z[9,2,1]  R1246     9.2261385917663574e-01
    z[9,2,1]  R1247     8.4715765714645386e-01
    z[9,2,1]  R1248     -4.4515966437757015e-03
    z[9,2,1]  R1249     6.7066210508346558e-01
    z[9,2,1]  R1250     1.9737848639488220e-01
    z[9,2,1]  R1251     2.5924494862556458e-01
    z[9,2,1]  R1252     2.1058626472949982e-02
    z[9,2,1]  R1253     3.7837183475494385e-01
    z[9,2,1]  R1254     8.6386218667030334e-02
    z[9,2,1]  R1255     -2.2493258118629456e-02
    z[9,2,1]  R1256     3.6461940407752991e-01
    z[9,2,1]  R1257     9.3463861942291260e-01
    z[9,2,1]  R1258     -6.1719310283660889e-01
    z[9,2,1]  R1259     7.5483016669750214e-02
    z[9,2,1]  R1260     1.4851692318916321e-01
    z[9,2,1]  R1261     1.9161993637681007e-02
    z[9,2,1]  R1262     4.6353090554475784e-02
    z[9,2,1]  R1263     -6.9504901766777039e-02
    z[9,2,1]  R1264     8.4414362907409668e-02
    z[9,2,1]  R1265     -3.2704740762710571e-01
    z[9,2,1]  R1266     -6.2125867605209351e-01
    z[9,2,1]  R1267     -5.1839131116867065e-01
    z[9,2,1]  R1268     -6.4223206043243408e-01
    z[9,2,1]  R1269     -8.5852009057998657e-01
    z[9,2,1]  R1270     -8.8854783773422241e-01
    z[9,2,1]  R1271     7.0590265095233917e-02
    z[9,2,1]  R1272     -2.2162930667400360e-01
    z[9,2,1]  R1273     9.3165911734104156e-02
    z[9,2,1]  R1274     1.9307444989681244e-01
    z[9,2,1]  R1275     -0.20382159948349
    z[9,2,1]  R1276     4.5184570550918579e-01
    z[9,2,1]  R1277     3.8862824440002441e-01
    z[9,2,1]  R1278     4.1592359542846680e-01
    z[9,2,1]  R1279     0.513628363609314
    z[9,2,1]  R1280     3.7828582525253296e-01
    z[9,2,1]  R1281     2.9255113005638123e-01
    z[9,2,1]  R1282     6.3944053649902344e-01
    z[9,2,1]  R1283     4.4198375940322876e-01
    z[9,2,1]  R1284     8.5158699750900269e-01
    z[9,2,1]  R1285     8.5738492012023926e-01
    z[9,2,2]  R22       1
    z[9,2,2]  R85       -1
    z[9,2,2]  R1186     -1
    z[9,2,2]  R1187     1
    z[9,2,2]  R1196     6.0119831562042236e-01
    z[9,2,2]  R1197     6.5845674276351929e-01
    z[9,2,2]  R1198     -3.7292090058326721e-01
    z[9,2,2]  R1199     -1.6844037920236588e-02
    z[9,2,2]  R1200     0.208670973777771
    z[9,2,2]  R1201     5.1197123527526855e-01
    z[9,2,2]  R1202     2.3732237517833710e-01
    z[9,2,2]  R1203     2.5929355621337891e-01
    z[9,2,2]  R1204     -2.3566943407058716e-01
    z[9,2,2]  R1205     -1.7263881862163544e-01
    z[9,2,2]  R1206     -1.1932317912578583e-01
    z[9,2,2]  R1207     -4.7704420983791351e-02
    z[9,2,2]  R1208     1.5714508295059204e-01
    z[9,2,2]  R1209     3.1169608235359192e-01
    z[9,2,2]  R1210     -1.5421368181705475e-01
    z[9,2,2]  R1211     1.0783152282238007e-01
    z[9,2,2]  R1212     -3.2978415489196777e-01
    z[9,2,2]  R1213     -1.9020775333046913e-02
    z[9,2,2]  R1214     -0.388967901468277
    z[9,2,2]  R1215     -0.0613291971385479
    z[9,2,2]  R1216     2.5621551275253296e-01
    z[9,2,2]  R1217     3.0200770497322083e-01
    z[9,2,2]  R1218     2.6487665250897408e-02
    z[9,2,2]  R1219     5.3616754710674286e-02
    z[9,2,2]  R1220     2.7006408572196960e-01
    z[9,2,2]  R1221     -3.5139295458793640e-01
    z[9,2,2]  R1222     9.5755748450756073e-02
    z[9,2,2]  R1223     1.0427531599998474e-01
    z[9,2,2]  R1224     0.0639515370130539
    z[9,2,2]  R1225     -2.7095419168472290e-01
    z[9,2,2]  R1226     1.4329145848751068e-01
    z[9,2,2]  R1227     5.3386755287647247e-02
    z[9,2,2]  R1228     -2.5896275043487549e-01
    z[9,2,2]  R1229     -2.8887179493904114e-01
    z[9,2,2]  R1230     3.2635146379470825e-01
    z[9,2,2]  R1231     -5.0705488771200180e-02
    z[9,2,2]  R1232     2.8788352012634277e-01
    z[9,2,2]  R1233     -2.5966507196426392e-01
    z[9,2,2]  R1234     -1.2561090290546417e-02
    z[9,2,2]  R1235     3.4817758202552795e-01
    z[9,2,2]  R1236     1.0591665655374527e-01
    z[9,2,2]  R1237     -3.5850632190704346e-01
    z[9,2,2]  R1238     -4.2443636059761047e-01
    z[9,2,2]  R1239     5.0838928669691086e-02
    z[9,2,2]  R1240     1.2665954232215881e-01
    z[9,2,2]  R1241     1.7349500954151154e-01
    z[9,2,2]  R1242     3.4177505970001221e-01
    z[9,2,2]  R1243     -2.2517672181129456e-01
    z[9,2,2]  R1244     -3.2769733667373657e-01
    z[9,2,2]  R1245     7.5107440352439880e-02
    z[9,2,2]  R1246     -1.1293012648820877e-01
    z[9,2,2]  R1247     2.7016565203666687e-01
    z[9,2,2]  R1248     0.284115195274353
    z[9,2,2]  R1249     -2.3836031556129456e-01
    z[9,2,2]  R1250     -3.4947404265403748e-01
    z[9,2,2]  R1251     -1.2920296192169189e-01
    z[9,2,2]  R1252     -4.3436264991760254e-01
    z[9,2,2]  R1253     -2.1037213504314423e-01
    z[9,2,2]  R1254     4.2275067418813705e-02
    z[9,2,2]  R1255     -3.4015023708343506e-01
    z[9,2,2]  R1256     2.7779853343963623e-01
    z[9,2,2]  R1257     5.8591767447069287e-04
    z[9,2,2]  R1258     -2.4033807218074799e-01
    z[9,2,2]  R1259     -1.5402874350547791e-01
    z[9,2,2]  R1260     -7.2709627449512482e-02
    z[9,2,2]  R1261     -4.8643833398818970e-01
    z[9,2,2]  R1262     -4.1759368777275085e-01
    z[9,2,2]  R1263     -2.0346195995807648e-01
    z[9,2,2]  R1264     -1.0566321760416031e-01
    z[9,2,2]  R1265     -1.2967251241207123e-01
    z[9,2,2]  R1266     6.4191657304763794e-01
    z[9,2,2]  R1267     5.4716587066650391e-01
    z[9,2,2]  R1268     4.7255662083625793e-01
    z[9,2,2]  R1269     3.6511132121086121e-01
    z[9,2,2]  R1270     5.3928568959236145e-02
    z[9,2,2]  R1271     -4.6291261911392212e-01
    z[9,2,2]  R1272     -6.8764805793762207e-01
    z[9,2,2]  R1273     -3.6826652288436890e-01
    z[9,2,2]  R1274     -4.5904904603958130e-01
    z[9,2,2]  R1275     -9.3029528856277466e-01
    z[9,2,2]  R1276     6.2224364280700684e-01
    z[9,2,2]  R1277     3.3884134888648987e-01
    z[9,2,2]  R1278     2.3745256662368774e-01
    z[9,2,2]  R1279     6.0588216781616211e-01
    z[9,2,2]  R1280     5.2405965328216553e-01
    z[9,2,2]  R1281     5.2620679140090942e-01
    z[9,2,2]  R1282     2.5405415892601013e-01
    z[9,2,2]  R1283     2.0580118894577026e-01
    z[9,2,2]  R1284     1.7980951070785522e-01
    z[9,2,2]  R1285     1.2643806636333466e-01
    z[9,2,3]  R23       1
    z[9,2,3]  R86       -1
    z[9,2,3]  R1188     -1
    z[9,2,3]  R1189     1
    z[9,2,3]  R1196     2.6745793223381042e-01
    z[9,2,3]  R1197     2.1631832420825958e-01
    z[9,2,3]  R1198     4.9046754837036133e-01
    z[9,2,3]  R1199     8.1015920639038086e-01
    z[9,2,3]  R1200     8.7596577405929565e-01
    z[9,2,3]  R1201     6.1187815666198730e-01
    z[9,2,3]  R1202     6.0210049152374268e-01
    z[9,2,3]  R1203     5.6074738502502441e-01
    z[9,2,3]  R1204     4.2829075455665588e-01
    z[9,2,3]  R1205     8.7676249444484711e-02
    z[9,2,3]  R1206     3.2030718284659088e-04
    z[9,2,3]  R1207     -1.5726526081562042e-01
    z[9,2,3]  R1208     0.510026752948761
    z[9,2,3]  R1209     2.9189857840538025e-01
    z[9,2,3]  R1210     5.0670951604843140e-01
    z[9,2,3]  R1211     2.1482449956238270e-03
    z[9,2,3]  R1212     0.194418266415596
    z[9,2,3]  R1213     5.4579585790634155e-01
    z[9,2,3]  R1214     1.1006633937358856e-01
    z[9,2,3]  R1215     0.210173562169075
    z[9,2,3]  R1216     -1.1477672308683395e-01
    z[9,2,3]  R1217     1.6191175580024719e-01
    z[9,2,3]  R1218     7.8962184488773346e-02
    z[9,2,3]  R1219     7.9013293981552124e-01
    z[9,2,3]  R1220     5.6404348462820053e-02
    z[9,2,3]  R1221     -4.3802550435066223e-01
    z[9,2,3]  R1222     -4.9159732460975647e-01
    z[9,2,3]  R1223     3.3527228236198425e-01
    z[9,2,3]  R1224     0.500817060470581
    z[9,2,3]  R1225     -4.3633630871772766e-01
    z[9,2,3]  R1226     9.9438525736331940e-02
    z[9,2,3]  R1227     1.9843837618827820e-01
    z[9,2,3]  R1228     5.3493392467498779e-01
    z[9,2,3]  R1229     -1.0884377360343933e-01
    z[9,2,3]  R1230     4.5015761256217957e-01
    z[9,2,3]  R1231     1.1064665019512177e-01
    z[9,2,3]  R1232     5.5983585119247437e-01
    z[9,2,3]  R1233     6.4900976419448853e-01
    z[9,2,3]  R1234     -0.381475031375885
    z[9,2,3]  R1235     4.9845075607299805e-01
    z[9,2,3]  R1236     1.0783334076404572e-01
    z[9,2,3]  R1237     7.5359144248068333e-03
    z[9,2,3]  R1238     -1.3345412909984589e-01
    z[9,2,3]  R1239     8.1412959098815918e-01
    z[9,2,3]  R1240     4.1875693202018738e-01
    z[9,2,3]  R1241     7.2381514310836792e-01
    z[9,2,3]  R1242     0.524556577205658
    z[9,2,3]  R1243     -4.8285833001136780e-01
    z[9,2,3]  R1244     -6.8804478645324707e-01
    z[9,2,3]  R1245     -6.6409087181091309e-01
    z[9,2,3]  R1246     6.1818454414606094e-02
    z[9,2,3]  R1247     3.6368572711944580e-01
    z[9,2,3]  R1248     7.0382076501846313e-01
    z[9,2,3]  R1249     1.5992195904254913e-01
    z[9,2,3]  R1250     -6.0701805353164673e-01
    z[9,2,3]  R1251     -5.1418608427047729e-01
    z[9,2,3]  R1252     -0.731490433216095
    z[9,2,3]  R1253     5.5768400430679321e-01
    z[9,2,3]  R1254     2.6345852017402649e-01
    z[9,2,3]  R1255     -9.4710178673267365e-02
    z[9,2,3]  R1256     7.2435122728347778e-01
    z[9,2,3]  R1257     3.2289031893014908e-02
    z[9,2,3]  R1258     -3.7586545944213867e-01
    z[9,2,3]  R1259     5.9365427494049072e-01
    z[9,2,3]  R1260     -0.61862713098526
    z[9,2,3]  R1261     1.6522195935249329e-01
    z[9,2,3]  R1262     2.1658472716808319e-01
    z[9,2,3]  R1263     1.1529392749071121e-01
    z[9,2,3]  R1264     2.3029154539108276e-01
    z[9,2,3]  R1265     -3.3830992877483368e-02
    z[9,2,3]  R1266     3.7220796942710876e-01
    z[9,2,3]  R1267     4.6839761734008789e-01
    z[9,2,3]  R1268     1.6719271242618561e-01
    z[9,2,3]  R1269     1.2000499665737152e-01
    z[9,2,3]  R1270     2.8061398863792419e-01
    z[9,2,3]  R1271     7.1794402599334717e-01
    z[9,2,3]  R1272     5.9474724531173706e-01
    z[9,2,3]  R1273     8.6313569545745850e-01
    z[9,2,3]  R1274     4.6029153466224670e-01
    z[9,2,3]  R1275     1.5579879283905029e-01
    z[9,2,3]  R1276     -8.6404690518975258e-03
    z[9,2,3]  R1277     -1.1484029702842236e-02
    z[9,2,3]  R1278     7.7955529093742371e-02
    z[9,2,3]  R1279     -1.7613553791306913e-04
    z[9,2,3]  R1280     1.1394208669662476e-01
    z[9,2,3]  R1281     2.9837839305400848e-02
    z[9,2,3]  R1282     -4.2753354646265507e-03
    z[9,2,3]  R1283     2.0318765193223953e-02
    z[9,2,3]  R1284     -2.0815165340900421e-01
    z[9,2,3]  R1285     -9.9909320473670959e-02
    z[9,2,4]  R24       1
    z[9,2,4]  R87       -1
    z[9,2,4]  R1190     -1
    z[9,2,4]  R1191     1
    z[9,2,4]  R1196     -2.2025765478610992e-01
    z[9,2,4]  R1197     4.9540884792804718e-02
    z[9,2,4]  R1198     -1.9937008619308472e-01
    z[9,2,4]  R1199     1.5698830783367157e-01
    z[9,2,4]  R1200     -1.9919518381357193e-02
    z[9,2,4]  R1201     -5.7643294334411621e-01
    z[9,2,4]  R1202     -4.1490471363067627e-01
    z[9,2,4]  R1203     -6.8947827816009521e-01
    z[9,2,4]  R1204     8.0657035112380981e-02
    z[9,2,4]  R1205     -2.3938387632369995e-01
    z[9,2,4]  R1206     -2.5749403238296509e-01
    z[9,2,4]  R1207     -1.5698436647653580e-02
    z[9,2,4]  R1208     6.4038641750812531e-02
    z[9,2,4]  R1209     -6.4481054432690144e-03
    z[9,2,4]  R1210     1.4860455691814423e-01
    z[9,2,4]  R1211     2.1630044281482697e-01
    z[9,2,4]  R1212     -1.8657873570919037e-01
    z[9,2,4]  R1213     2.4084559082984924e-01
    z[9,2,4]  R1214     2.0764137804508209e-01
    z[9,2,4]  R1215     2.4053536355495453e-01
    z[9,2,4]  R1216     1.1786674708127975e-01
    z[9,2,4]  R1217     4.6568755060434341e-03
    z[9,2,4]  R1218     2.0146493613719940e-01
    z[9,2,4]  R1219     -4.7542190551757812e-01
    z[9,2,4]  R1220     1.6603556275367737e-01
    z[9,2,4]  R1221     0.263406902551651
    z[9,2,4]  R1222     2.3883616924285889e-01
    z[9,2,4]  R1223     -6.7056399583816528e-01
    z[9,2,4]  R1224     -2.4792028963565826e-01
    z[9,2,4]  R1225     4.6367591619491577e-01
    z[9,2,4]  R1226     2.2562585771083832e-01
    z[9,2,4]  R1227     4.4862195849418640e-01
    z[9,2,4]  R1228     -3.6542826890945435e-01
    z[9,2,4]  R1229     -3.4813615679740906e-01
    z[9,2,4]  R1230     1.0701561719179153e-01
    z[9,2,4]  R1231     -2.8643617033958435e-01
    z[9,2,4]  R1232     -6.4117950201034546e-01
    z[9,2,4]  R1233     -4.3757069110870361e-01
    z[9,2,4]  R1234     3.1786888837814331e-01
    z[9,2,4]  R1235     -3.4919813275337219e-01
    z[9,2,4]  R1236     5.7811133563518524e-02
    z[9,2,4]  R1237     2.5662171840667725e-01
    z[9,2,4]  R1238     -2.6620498299598694e-01
    z[9,2,4]  R1239     -5.4105542600154877e-02
    z[9,2,4]  R1240     -2.5736445188522339e-01
    z[9,2,4]  R1241     -4.0130594372749329e-01
    z[9,2,4]  R1242     -4.9146994948387146e-01
    z[9,2,4]  R1243     4.8633995652198792e-01
    z[9,2,4]  R1244     3.8258891552686691e-02
    z[9,2,4]  R1245     -4.3908131122589111e-01
    z[9,2,4]  R1246     3.5036456584930420e-01
    z[9,2,4]  R1247     3.3553251996636391e-03
    z[9,2,4]  R1248     -5.3329789638519287e-01
    z[9,2,4]  R1249     2.5605052709579468e-01
    z[9,2,4]  R1250     3.9515992999076843e-01
    z[9,2,4]  R1251     2.5869178771972656e-01
    z[9,2,4]  R1252     9.3507938086986542e-02
    z[9,2,4]  R1253     -0.154225692152977
    z[9,2,4]  R1254     -4.0393674373626709e-01
    z[9,2,4]  R1255     -6.1272329092025757e-01
    z[9,2,4]  R1256     2.5348857045173645e-01
    z[9,2,4]  R1257     -2.1339474618434906e-01
    z[9,2,4]  R1258     3.6196881532669067e-01
    z[9,2,4]  R1259     -2.2272971272468567e-01
    z[9,2,4]  R1260     5.5822777748107910e-01
    z[9,2,4]  R1261     -4.1396361589431763e-01
    z[9,2,4]  R1262     -1.0913689434528351e-01
    z[9,2,4]  R1263     -2.0239000022411346e-01
    z[9,2,4]  R1264     -5.0234001874923706e-01
    z[9,2,4]  R1265     1.0885780304670334e-01
    z[9,2,4]  R1266     2.6416091248393059e-02
    z[9,2,4]  R1267     -3.3045294880867004e-01
    z[9,2,4]  R1268     1.0801636381074786e-03
    z[9,2,4]  R1269     -5.0684046000242233e-02
    z[9,2,4]  R1270     -1.1764678172767162e-02
    z[9,2,4]  R1271     -3.6642208695411682e-01
    z[9,2,4]  R1272     -2.5889590382575989e-01
    z[9,2,4]  R1273     2.6452008169144392e-03
    z[9,2,4]  R1274     -5.5785093456506729e-02
    z[9,2,4]  R1275     -6.1872941441833973e-03
    z[9,2,4]  R1276     2.3640081286430359e-01
    z[9,2,4]  R1277     -1.0277015715837479e-01
    z[9,2,4]  R1278     4.2747011780738831e-01
    z[9,2,4]  R1279     -1.0872618108987808e-01
    z[9,2,4]  R1280     5.1522469520568848e-01
    z[9,2,4]  R1281     1.4857383072376251e-01
    z[9,2,4]  R1282     2.4948436766862869e-02
    z[9,2,4]  R1283     3.2144007086753845e-01
    z[9,2,4]  R1284     3.0023893713951111e-01
    z[9,2,4]  R1285     -4.9544990062713623e-02
    z[9,2,5]  R25       1
    z[9,2,5]  R88       -1
    z[9,2,5]  R1192     -1
    z[9,2,5]  R1193     1
    z[9,2,5]  R1196     -1.9467087090015411e-01
    z[9,2,5]  R1197     2.6567959785461426e-01
    z[9,2,5]  R1198     2.2427400574088097e-02
    z[9,2,5]  R1199     -5.4391944408416748e-01
    z[9,2,5]  R1200     -3.5637673735618591e-01
    z[9,2,5]  R1201     -4.8700369894504547e-02
    z[9,2,5]  R1202     -7.5534239411354065e-02
    z[9,2,5]  R1203     -3.2818788290023804e-01
    z[9,2,5]  R1204     -4.0075135231018066e-01
    z[9,2,5]  R1205     4.8053160309791565e-01
    z[9,2,5]  R1206     -1.5864242613315582e-01
    z[9,2,5]  R1207     -1.8162797391414642e-01
    z[9,2,5]  R1208     1.1702164262533188e-01
    z[9,2,5]  R1209     1.4710952341556549e-01
    z[9,2,5]  R1210     8.5905738174915314e-02
    z[9,2,5]  R1211     1.8779808282852173e-01
    z[9,2,5]  R1212     -1.3045580685138702e-01
    z[9,2,5]  R1213     1.2709461152553558e-01
    z[9,2,5]  R1214     -4.6299362182617188e-01
    z[9,2,5]  R1215     5.8834099769592285e-01
    z[9,2,5]  R1216     5.4942883551120758e-02
    z[9,2,5]  R1217     3.9418280124664307e-01
    z[9,2,5]  R1218     -0.301368772983551
    z[9,2,5]  R1219     -2.5309933349490166e-02
    z[9,2,5]  R1220     4.2968633770942688e-01
    z[9,2,5]  R1221     7.5681346654891968e-01
    z[9,2,5]  R1222     6.8053728342056274e-01
    z[9,2,5]  R1223     -5.4070943593978882e-01
    z[9,2,5]  R1224     -5.3338271379470825e-01
    z[9,2,5]  R1225     5.2292549610137939e-01
    z[9,2,5]  R1226     2.7252739667892456e-01
    z[9,2,5]  R1227     -4.6664139628410339e-01
    z[9,2,5]  R1228     -0.513565719127655
    z[9,2,5]  R1229     5.2712988853454590e-01
    z[9,2,5]  R1230     -4.5385599136352539e-01
    z[9,2,5]  R1231     5.8251172304153442e-01
    z[9,2,5]  R1232     -2.1387417614459991e-01
    z[9,2,5]  R1233     -1.5060220845043659e-02
    z[9,2,5]  R1234     6.8639487028121948e-01
    z[9,2,5]  R1235     -2.4893115460872650e-01
    z[9,2,5]  R1236     3.8159903883934021e-01
    z[9,2,5]  R1237     1.7658115923404694e-01
    z[9,2,5]  R1238     0.375962495803833
    z[9,2,5]  R1239     -2.2506140172481537e-01
    z[9,2,5]  R1240     -7.0776619017124176e-02
    z[9,2,5]  R1241     -4.2152115702629089e-01
    z[9,2,5]  R1242     -6.0033202171325684e-01
    z[9,2,5]  R1243     5.8392065763473511e-01
    z[9,2,5]  R1244     4.4555336236953735e-01
    z[9,2,5]  R1245     0.540216326713562
    z[9,2,5]  R1246     5.9696469455957413e-02
    z[9,2,5]  R1247     -2.3778945207595825e-01
    z[9,2,5]  R1248     -2.4003544449806213e-01
    z[9,2,5]  R1249     -4.2458108067512512e-01
    z[9,2,5]  R1250     5.4056447744369507e-01
    z[9,2,5]  R1251     7.1215301752090454e-01
    z[9,2,5]  R1252     4.3745765089988708e-01
    z[9,2,5]  R1253     -3.7895795702934265e-01
    z[9,2,5]  R1254     -8.3969587087631226e-01
    z[9,2,5]  R1255     6.5132617950439453e-01
    z[9,2,5]  R1256     -4.1937139630317688e-01
    z[9,2,5]  R1257     -1.4807693660259247e-01
    z[9,2,5]  R1258     0.404939204454422
    z[9,2,5]  R1259     -6.5721738338470459e-01
    z[9,2,5]  R1260     4.8852661252021790e-01
    z[9,2,5]  R1261     3.3111223578453064e-01
    z[9,2,5]  R1262     0.810812771320343
    z[9,2,5]  R1263     0.654262900352478
    z[9,2,5]  R1264     5.9761160612106323e-01
    z[9,2,5]  R1265     -2.4756550788879395e-02
    z[9,2,5]  R1266     2.3521322011947632e-01
    z[9,2,5]  R1267     1.6307172179222107e-01
    z[9,2,5]  R1268     -2.4484235048294067e-01
    z[9,2,5]  R1269     3.0416178703308105e-01
    z[9,2,5]  R1270     0.251397043466568
    z[9,2,5]  R1271     1.6475871205329895e-01
    z[9,2,5]  R1272     -1.5033662319183350e-01
    z[9,2,5]  R1273     1.9075880944728851e-01
    z[9,2,5]  R1274     5.6018787622451782e-01
    z[9,2,5]  R1275     1.8015068769454956e-01
    z[9,2,5]  R1276     -5.2143466472625732e-01
    z[9,2,5]  R1277     -8.0909961462020874e-01
    z[9,2,5]  R1278     -6.8678516149520874e-01
    z[9,2,5]  R1279     -5.1308321952819824e-01
    z[9,2,5]  R1280     -4.8027858138084412e-01
    z[9,2,5]  R1281     -5.6475079059600830e-01
    z[9,2,5]  R1282     -6.9524812698364258e-01
    z[9,2,5]  R1283     -0.643557608127594
    z[9,2,5]  R1284     -2.4108362197875977e-01
    z[9,2,5]  R1285     2.2438602149486542e-01
    z[9,2,6]  R26       1
    z[9,2,6]  R89       -1
    z[9,2,6]  R1194     -1
    z[9,2,6]  R1195     1
    z[9,2,6]  R1196     1.0395793616771698e-01
    z[9,2,6]  R1197     1.9415576010942459e-02
    z[9,2,6]  R1198     -6.9697767496109009e-02
    z[9,2,6]  R1199     1.1169490963220596e-01
    z[9,2,6]  R1200     -1.2352060526609421e-02
    z[9,2,6]  R1201     1.6082102060317993e-01
    z[9,2,6]  R1202     5.7173055410385132e-01
    z[9,2,6]  R1203     -1.2007039785385132e-01
    z[9,2,6]  R1204     6.4285027980804443e-01
    z[9,2,6]  R1205     6.8001949787139893e-01
    z[9,2,6]  R1206     1.8460302054882050e-01
    z[9,2,6]  R1207     -1.5779319405555725e-01
    z[9,2,6]  R1208     1.9296933710575104e-01
    z[9,2,6]  R1209     -1.5386903285980225e-01
    z[9,2,6]  R1210     1.9968789815902710e-01
    z[9,2,6]  R1211     -2.3701782524585724e-01
    z[9,2,6]  R1212     -2.6190373301506042e-01
    z[9,2,6]  R1213     -3.3819109201431274e-01
    z[9,2,6]  R1214     -1.7705438658595085e-02
    z[9,2,6]  R1215     -3.8312196731567383e-02
    z[9,2,6]  R1216     -2.1390339732170105e-01
    z[9,2,6]  R1217     4.9474292993545532e-01
    z[9,2,6]  R1218     4.9652910232543945e-01
    z[9,2,6]  R1219     1.8477691337466240e-02
    z[9,2,6]  R1220     4.2714181542396545e-01
    z[9,2,6]  R1221     1.1721289902925491e-01
    z[9,2,6]  R1222     4.5573955774307251e-01
    z[9,2,6]  R1223     -1.0785336047410965e-01
    z[9,2,6]  R1224     -3.8591352105140686e-01
    z[9,2,6]  R1225     -4.1525909304618835e-01
    z[9,2,6]  R1226     3.7685650587081909e-01
    z[9,2,6]  R1227     -7.2364950180053711e-01
    z[9,2,6]  R1228     6.8157516419887543e-02
    z[9,2,6]  R1229     -2.4559737741947174e-01
    z[9,2,6]  R1230     8.1955626606941223e-02
    z[9,2,6]  R1231     -3.5615113377571106e-01
    z[9,2,6]  R1232     1.4210730791091919e-02
    z[9,2,6]  R1233     -3.9242914319038391e-01
    z[9,2,6]  R1234     -3.7285405397415161e-01
    z[9,2,6]  R1235     0.617212176322937
    z[9,2,6]  R1236     -1.9595511257648468e-02
    z[9,2,6]  R1237     -2.1142356097698212e-01
    z[9,2,6]  R1238     -6.3874870538711548e-02
    z[9,2,6]  R1239     3.8014820218086243e-01
    z[9,2,6]  R1240     2.6594460010528564e-01
    z[9,2,6]  R1241     -2.7939301729202271e-01
    z[9,2,6]  R1242     7.2171583771705627e-02
    z[9,2,6]  R1243     -1.7181229591369629e-01
    z[9,2,6]  R1244     -3.5775211453437805e-01
    z[9,2,6]  R1245     -2.4354150891304016e-01
    z[9,2,6]  R1246     7.6739199459552765e-02
    z[9,2,6]  R1247     1.3014088571071625e-01
    z[9,2,6]  R1248     -2.3814998567104340e-01
    z[9,2,6]  R1249     1.1520184576511383e-01
    z[9,2,6]  R1250     6.7315578460693359e-02
    z[9,2,6]  R1251     -2.4576807022094727e-01
    z[9,2,6]  R1252     -0.206540048122406
    z[9,2,6]  R1253     -5.5418390035629272e-01
    z[9,2,6]  R1254     -2.1993513405323029e-01
    z[9,2,6]  R1255     2.0152269303798676e-01
    z[9,2,6]  R1256     -1.5294280648231506e-01
    z[9,2,6]  R1257     -2.2544318437576294e-01
    z[9,2,6]  R1258     -9.2782024294137955e-03
    z[9,2,6]  R1259     -3.6410698294639587e-01
    z[9,2,6]  R1260     -9.8761796951293945e-02
    z[9,2,6]  R1261     5.3759759664535522e-01
    z[9,2,6]  R1262     -9.5262423157691956e-02
    z[9,2,6]  R1263     6.5266633033752441e-01
    z[9,2,6]  R1264     4.7035521268844604e-01
    z[9,2,6]  R1265     4.8429798334836960e-02
    z[9,2,6]  R1266     -1.7870176816359162e-03
    z[9,2,6]  R1267     -7.4849396944046021e-02
    z[9,2,6]  R1268     -0.00873769260942936
    z[9,2,6]  R1269     -3.3102288842201233e-02
    z[9,2,6]  R1270     1.8266259133815765e-01
    z[9,2,6]  R1271     -1.8044899404048920e-01
    z[9,2,6]  R1272     -1.6020901501178741e-01
    z[9,2,6]  R1273     2.0764118432998657e-01
    z[9,2,6]  R1274     3.0501919984817505e-01
    z[9,2,6]  R1275     1.5341801941394806e-01
    z[9,2,6]  R1276     -2.0680311322212219e-01
    z[9,2,6]  R1277     1.1379343271255493e-01
    z[9,2,6]  R1278     0.097191721200943
    z[9,2,6]  R1279     2.9394736886024475e-01
    z[9,2,6]  R1280     2.1659180521965027e-01
    z[9,2,6]  R1281     2.8197491168975830e-01
    z[9,2,6]  R1282     -1.6610570251941681e-01
    z[9,2,6]  R1283     4.8151633143424988e-01
    z[9,2,6]  R1284     2.0062738656997681e-01
    z[9,2,6]  R1285     3.5508644580841064e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1320     -1
    z[3,4,0]  R1321     1
    z[3,4,0]  R1334     -0.944106936454773
    z[3,4,0]  R1335     -8.9444696903228760e-01
    z[3,4,0]  R1336     -8.8479697704315186e-01
    z[3,4,0]  R1337     -8.3608752489089966e-01
    z[3,4,0]  R1338     -7.4958759546279907e-01
    z[3,4,0]  R1339     -6.0549592971801758e-01
    z[3,4,0]  R1340     8.9866951107978821e-02
    z[3,4,0]  R1341     -1.5696670114994049e-01
    z[3,4,0]  R1342     4.4755467772483826e-01
    z[3,4,0]  R1343     3.8049522042274475e-01
    z[3,4,0]  R1344     2.2003683447837830e-01
    z[3,4,0]  R1345     2.8103478252887726e-02
    z[3,4,0]  R1346     2.6788082718849182e-01
    z[3,4,0]  R1347     4.0804773569107056e-01
    z[3,4,0]  R1348     7.6667505502700806e-01
    z[3,4,0]  R1349     0.556808590888977
    z[3,4,0]  R1350     4.4196322560310364e-01
    z[3,4,0]  R1351     3.7991029024124146e-01
    z[3,4,0]  R1352     3.3493974804878235e-01
    z[3,4,0]  R1353     2.6604282855987549e-01
    z[3,4,0]  R1354     -1.7396806180477142e-01
    z[3,4,0]  R1355     7.4199743568897247e-02
    z[3,4,0]  R1356     -2.5420048832893372e-01
    z[3,4,0]  R1357     2.0277349278330803e-02
    z[3,4,0]  R1358     -1.5550833940505981e-01
    z[3,4,0]  R1359     1.4069461822509766e-01
    z[3,4,0]  R1360     1.8428291380405426e-01
    z[3,4,0]  R1361     7.2697833180427551e-02
    z[3,4,0]  R1362     6.1067931354045868e-02
    z[3,4,0]  R1363     -1.0487715899944305e-01
    z[3,4,0]  R1364     -4.9134048819541931e-01
    z[3,4,0]  R1365     -4.0034279227256775e-01
    z[3,4,0]  R1366     -5.8334946632385254e-01
    z[3,4,0]  R1367     -3.3326229453086853e-01
    z[3,4,0]  R1368     -3.1065317988395691e-01
    z[3,4,0]  R1369     -1.7757639288902283e-01
    z[3,4,0]  R1370     5.4894924163818359e-01
    z[3,4,0]  R1371     -2.0485103130340576e-01
    z[3,4,0]  R1372     -3.8280868530273438e-01
    z[3,4,0]  R1373     -5.7402960956096649e-02
    z[3,4,0]  R1374     -0.668807327747345
    z[3,4,0]  R1375     -4.1047197580337524e-01
    z[3,4,0]  R1376     -6.2148553133010864e-01
    z[3,4,0]  R1377     3.4815111756324768e-01
    z[3,4,0]  R1378     -1.1442486941814423e-01
    z[3,4,0]  R1379     -9.2298634350299835e-02
    z[3,4,0]  R1380     -2.4793858826160431e-01
    z[3,4,0]  R1381     1.5128245949745178e-01
    z[3,4,0]  R1382     7.7955538034439087e-01
    z[3,4,0]  R1383     8.5126173496246338e-01
    z[3,4,0]  R1384     1.1587698757648468e-01
    z[3,4,0]  R1385     3.8701277226209641e-02
    z[3,4,0]  R1386     -9.7453221678733826e-03
    z[3,4,0]  R1387     1.9839751720428467e-01
    z[3,4,0]  R1388     -5.3450185805559158e-02
    z[3,4,0]  R1389     -4.1370356082916260e-01
    z[3,4,0]  R1390     5.1985946483910084e-03
    z[3,4,0]  R1391     6.3221298158168793e-02
    z[3,4,0]  R1392     1.8728289008140564e-01
    z[3,4,0]  R1393     -1.7933090031147003e-01
    z[3,4,0]  R1394     -2.3720602691173553e-01
    z[3,4,0]  R1395     1.1222624778747559e-01
    z[3,4,0]  R1396     -0.077292300760746
    z[3,4,0]  R1397     2.3319798707962036e-01
    z[3,4,0]  R1398     1.2503399921115488e-04
    z[3,4,0]  R1399     1.3410587608814240e-01
    z[3,4,0]  R1400     3.0718800425529480e-01
    z[3,4,0]  R1401     -1.1665239185094833e-01
    z[3,4,0]  R1402     8.6510226130485535e-02
    z[3,4,0]  R1403     -8.5522763431072235e-02
    z[3,4,0]  R1404     -3.8181382417678833e-01
    z[3,4,0]  R1405     -3.1299063563346863e-01
    z[3,4,0]  R1406     -2.2579859197139740e-01
    z[3,4,0]  R1407     5.1869653165340424e-02
    z[3,4,0]  R1408     -3.9654752612113953e-01
    z[3,4,0]  R1409     -6.8331561982631683e-02
    z[3,4,0]  R1410     1.4130171388387680e-02
    z[3,4,0]  R1411     -0.374836266040802
    z[3,4,0]  R1412     -5.9481244534254074e-03
    z[3,4,0]  R1413     -3.9449077844619751e-01
    z[3,4,0]  R1414     -3.5857826471328735e-01
    z[3,4,0]  R1415     8.1744618713855743e-02
    z[3,4,0]  R1416     8.8852338492870331e-02
    z[3,4,0]  R1417     -3.2260206341743469e-01
    z[3,4,0]  R1418     1.7839437723159790e-01
    z[3,4,0]  R1419     -0.574947714805603
    z[3,4,0]  R1420     3.4821593761444092e-01
    z[3,4,0]  R1421     -7.2644799947738647e-02
    z[3,4,0]  R1422     7.4504047632217407e-01
    z[3,4,0]  R1423     1.6636660695075989e-01
    z[3,4,0]  R1424     3.4775093197822571e-02
    z[3,4,0]  R1425     -1.7973975837230682e-01
    z[3,4,0]  R1426     -2.3917232453823090e-01
    z[3,4,0]  R1427     -1.4337505400180817e-01
    z[3,4,0]  R1428     -3.0383253097534180e-01
    z[3,4,0]  R1429     -3.5776841640472412e-01
    z[3,4,0]  R1430     2.0762230455875397e-01
    z[3,4,0]  R1431     5.1076811552047729e-01
    z[3,4,0]  R1432     1.9453017413616180e-01
    z[3,4,0]  R1433     -2.9797112941741943e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1322     -1
    z[3,4,1]  R1323     1
    z[3,4,1]  R1334     -1.4133305847644806e-01
    z[3,4,1]  R1335     3.1024524569511414e-01
    z[3,4,1]  R1336     -7.7348113059997559e-02
    z[3,4,1]  R1337     -2.5451722741127014e-01
    z[3,4,1]  R1338     -3.5656234622001648e-01
    z[3,4,1]  R1339     -1.1910539120435715e-01
    z[3,4,1]  R1340     8.5235631465911865e-01
    z[3,4,1]  R1341     0.825688362121582
    z[3,4,1]  R1342     8.4348762035369873e-01
    z[3,4,1]  R1343     8.3468645811080933e-01
    z[3,4,1]  R1344     -8.1150442361831665e-01
    z[3,4,1]  R1345     -5.7987397909164429e-01
    z[3,4,1]  R1346     -6.5155172348022461e-01
    z[3,4,1]  R1347     -6.5436708927154541e-01
    z[3,4,1]  R1348     -3.1652554869651794e-01
    z[3,4,1]  R1349     -3.0074384808540344e-01
    z[3,4,1]  R1350     -4.0133380889892578e-01
    z[3,4,1]  R1351     -2.6648142933845520e-01
    z[3,4,1]  R1352     -4.2979344725608826e-01
    z[3,4,1]  R1353     -2.3862951993942261e-01
    z[3,4,1]  R1354     1.6371791064739227e-01
    z[3,4,1]  R1355     1.5403643250465393e-01
    z[3,4,1]  R1356     -1.1247289367020130e-02
    z[3,4,1]  R1357     1.7395548522472382e-01
    z[3,4,1]  R1358     -6.5469431877136230e-01
    z[3,4,1]  R1359     -8.2501769065856934e-02
    z[3,4,1]  R1360     -5.5584597587585449e-01
    z[3,4,1]  R1361     6.4218886196613312e-02
    z[3,4,1]  R1362     -3.2696792483329773e-01
    z[3,4,1]  R1363     4.2401787638664246e-01
    z[3,4,1]  R1364     2.6551276445388794e-01
    z[3,4,1]  R1365     -5.3360808640718460e-02
    z[3,4,1]  R1366     -6.0729876160621643e-02
    z[3,4,1]  R1367     -2.1936267614364624e-01
    z[3,4,1]  R1368     5.2177053689956665e-01
    z[3,4,1]  R1369     -2.4402105808258057e-01
    z[3,4,1]  R1370     -7.2244131565093994e-01
    z[3,4,1]  R1371     -1.3527034223079681e-01
    z[3,4,1]  R1372     2.3988784849643707e-01
    z[3,4,1]  R1373     -8.2922744750976562e-01
    z[3,4,1]  R1374     -3.0286094546318054e-01
    z[3,4,1]  R1375     -3.9802485704421997e-01
    z[3,4,1]  R1376     5.1660817861557007e-01
    z[3,4,1]  R1377     -6.8225634098052979e-01
    z[3,4,1]  R1378     -5.0074762105941772e-01
    z[3,4,1]  R1379     -0.630085289478302
    z[3,4,1]  R1380     -3.1725892424583435e-01
    z[3,4,1]  R1381     -4.0940544009208679e-01
    z[3,4,1]  R1382     2.0677064359188080e-01
    z[3,4,1]  R1383     1.3145956397056580e-01
    z[3,4,1]  R1384     5.1945990324020386e-01
    z[3,4,1]  R1385     4.3598660826683044e-01
    z[3,4,1]  R1386     2.7470833063125610e-01
    z[3,4,1]  R1387     2.9422539472579956e-01
    z[3,4,1]  R1388     5.3513032197952271e-01
    z[3,4,1]  R1389     5.2059924602508545e-01
    z[3,4,1]  R1390     8.5285681486129761e-01
    z[3,4,1]  R1391     8.5074758529663086e-01
    z[3,4,1]  R1392     8.1643897294998169e-01
    z[3,4,1]  R1393     7.6616877317428589e-01
    z[3,4,1]  R1394     -8.7570571899414062e-01
    z[3,4,1]  R1395     -0.948878824710846
    z[3,4,1]  R1396     -8.3460867404937744e-01
    z[3,4,1]  R1397     -0.800197958946228
    z[3,4,1]  R1398     -8.3948266506195068e-01
    z[3,4,1]  R1399     -7.5415897369384766e-01
    z[3,4,1]  R1400     -7.2628623247146606e-01
    z[3,4,1]  R1401     -7.4365448951721191e-01
    z[3,4,1]  R1402     -7.2204142808914185e-01
    z[3,4,1]  R1403     -4.2506304383277893e-01
    z[3,4,1]  R1404     0.69159334897995
    z[3,4,1]  R1405     0.718513011932373
    z[3,4,1]  R1406     5.8092606067657471e-01
    z[3,4,1]  R1407     6.1590307950973511e-01
    z[3,4,1]  R1408     6.2844419479370117e-01
    z[3,4,1]  R1409     5.1614028215408325e-01
    z[3,4,1]  R1410     5.3301292657852173e-01
    z[3,4,1]  R1411     5.4256129264831543e-01
    z[3,4,1]  R1412     4.7060114145278931e-01
    z[3,4,1]  R1413     5.1736724376678467e-01
    z[3,4,1]  R1414     8.1953680515289307e-01
    z[3,4,1]  R1415     7.3447358608245850e-01
    z[3,4,1]  R1416     6.4253956079483032e-01
    z[3,4,1]  R1417     6.2869960069656372e-01
    z[3,4,1]  R1418     6.3185513019561768e-01
    z[3,4,1]  R1419     7.6218783855438232e-01
    z[3,4,1]  R1420     6.7630988359451294e-01
    z[3,4,1]  R1421     -0.663023829460144
    z[3,4,1]  R1422     -1.7637096345424652e-01
    z[3,4,1]  R1423     -1.2277159839868546e-01
    z[3,4,1]  R1424     8.4047597646713257e-01
    z[3,4,1]  R1425     8.0599933862686157e-01
    z[3,4,1]  R1426     0.778223991394043
    z[3,4,1]  R1427     9.6594981849193573e-02
    z[3,4,1]  R1428     2.2723279893398285e-02
    z[3,4,1]  R1429     -2.1410322189331055e-01
    z[3,4,1]  R1430     1.2241020798683167e-02
    z[3,4,1]  R1431     -5.4259186983108521e-01
    z[3,4,1]  R1432     -0.0758294016122818
    z[3,4,1]  R1433     1.6085606068372726e-02
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1324     -1
    z[3,4,2]  R1325     1
    z[3,4,2]  R1334     3.1066054478287697e-02
    z[3,4,2]  R1335     -2.8208622243255377e-03
    z[3,4,2]  R1336     -6.7019328474998474e-02
    z[3,4,2]  R1337     1.4348384737968445e-01
    z[3,4,2]  R1338     2.6731422543525696e-01
    z[3,4,2]  R1339     -8.3356760442256927e-02
    z[3,4,2]  R1340     -5.5839867854956537e-05
    z[3,4,2]  R1341     1.4025759696960449e-01
    z[3,4,2]  R1342     1.1999390274286270e-01
    z[3,4,2]  R1343     1.0017056018114090e-02
    z[3,4,2]  R1344     -1.1276292800903320e-01
    z[3,4,2]  R1345     -2.7658042311668396e-01
    z[3,4,2]  R1346     3.2855155877768993e-03
    z[3,4,2]  R1347     -4.0102750062942505e-02
    z[3,4,2]  R1348     -1.1400407552719116e-01
    z[3,4,2]  R1349     -1.6668376326560974e-01
    z[3,4,2]  R1350     1.4053578674793243e-01
    z[3,4,2]  R1351     2.3021285235881805e-01
    z[3,4,2]  R1352     -1.4832855761051178e-01
    z[3,4,2]  R1353     1.3894286751747131e-01
    z[3,4,2]  R1354     -8.0853068828582764e-01
    z[3,4,2]  R1355     -8.9067792892456055e-01
    z[3,4,2]  R1356     -4.1614410281181335e-01
    z[3,4,2]  R1357     -4.1055321693420410e-01
    z[3,4,2]  R1358     5.7632780075073242e-01
    z[3,4,2]  R1359     -7.0586651563644409e-01
    z[3,4,2]  R1360     -2.3154844343662262e-01
    z[3,4,2]  R1361     5.5463171005249023e-01
    z[3,4,2]  R1362     -4.2904245853424072e-01
    z[3,4,2]  R1363     1.9134703278541565e-01
    z[3,4,2]  R1364     -5.7128328084945679e-01
    z[3,4,2]  R1365     -3.7148031592369080e-01
    z[3,4,2]  R1366     -5.6626230478286743e-01
    z[3,4,2]  R1367     -5.5301815271377563e-01
    z[3,4,2]  R1368     -5.7177132368087769e-01
    z[3,4,2]  R1369     -4.0159627795219421e-01
    z[3,4,2]  R1370     -1.7308506369590759e-01
    z[3,4,2]  R1371     -3.7613001465797424e-01
    z[3,4,2]  R1372     -0.646323025226593
    z[3,4,2]  R1373     4.9229413270950317e-01
    z[3,4,2]  R1374     -7.6841311529278755e-03
    z[3,4,2]  R1375     -7.0883341133594513e-02
    z[3,4,2]  R1376     -3.2401564717292786e-01
    z[3,4,2]  R1377     -4.4205355644226074e-01
    z[3,4,2]  R1378     -3.5247129201889038e-01
    z[3,4,2]  R1379     1.5784873068332672e-01
    z[3,4,2]  R1380     -5.9990704059600830e-01
    z[3,4,2]  R1381     -7.1209657192230225e-01
    z[3,4,2]  R1382     1.3143076002597809e-01
    z[3,4,2]  R1383     -2.8840396553277969e-02
    z[3,4,2]  R1384     -2.3583377897739410e-01
    z[3,4,2]  R1385     -1.5753577649593353e-01
    z[3,4,2]  R1386     2.2737956047058105e-01
    z[3,4,2]  R1387     -3.5226836800575256e-02
    z[3,4,2]  R1388     -1.5581825375556946e-01
    z[3,4,2]  R1389     -2.1102492511272430e-01
    z[3,4,2]  R1390     9.6422888338565826e-02
    z[3,4,2]  R1391     -0.194339781999588
    z[3,4,2]  R1392     4.0524479001760483e-02
    z[3,4,2]  R1393     2.1498893201351166e-01
    z[3,4,2]  R1394     -2.4073255062103271e-01
    z[3,4,2]  R1395     1.7117829620838165e-01
    z[3,4,2]  R1396     -1.0943584889173508e-01
    z[3,4,2]  R1397     3.2340955734252930e-01
    z[3,4,2]  R1398     1.6987487673759460e-01
    z[3,4,2]  R1399     -3.1586271524429321e-01
    z[3,4,2]  R1400     -8.7423577904701233e-02
    z[3,4,2]  R1401     5.4338318295776844e-04
    z[3,4,2]  R1402     4.0635776519775391e-01
    z[3,4,2]  R1403     4.1774931550025940e-01
    z[3,4,2]  R1404     3.8258284330368042e-01
    z[3,4,2]  R1405     3.4474813938140869e-01
    z[3,4,2]  R1406     -5.6983286142349243e-01
    z[3,4,2]  R1407     -8.5677266120910645e-02
    z[3,4,2]  R1408     -4.5456889271736145e-01
    z[3,4,2]  R1409     -5.4782372713088989e-01
    z[3,4,2]  R1410     -4.2600205540657043e-01
    z[3,4,2]  R1411     -4.5178778469562531e-02
    z[3,4,2]  R1412     -7.2194474935531616e-01
    z[3,4,2]  R1413     -8.4986887872219086e-02
    z[3,4,2]  R1414     -0.00379387685097754
    z[3,4,2]  R1415     -2.7375376224517822e-01
    z[3,4,2]  R1416     -5.8329051733016968e-01
    z[3,4,2]  R1417     -1.1103716678917408e-02
    z[3,4,2]  R1418     -3.1555393338203430e-01
    z[3,4,2]  R1419     1.2540809810161591e-01
    z[3,4,2]  R1420     6.9144517183303833e-02
    z[3,4,2]  R1421     1.1344595253467560e-01
    z[3,4,2]  R1422     -5.4198831319808960e-01
    z[3,4,2]  R1423     6.1031565070152283e-02
    z[3,4,2]  R1424     -1.6788861155509949e-01
    z[3,4,2]  R1425     -4.6955174207687378e-01
    z[3,4,2]  R1426     4.6259054541587830e-01
    z[3,4,2]  R1427     8.8542439043521881e-02
    z[3,4,2]  R1428     2.9090738296508789e-01
    z[3,4,2]  R1429     -1.9310995936393738e-01
    z[3,4,2]  R1430     2.7238744497299194e-01
    z[3,4,2]  R1431     0.452673077583313
    z[3,4,2]  R1432     1.2094288133084774e-02
    z[3,4,2]  R1433     -1.0561206936836243e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1326     -1
    z[3,4,3]  R1327     1
    z[3,4,3]  R1334     -2.3871541023254395e-01
    z[3,4,3]  R1335     -2.9863205552101135e-01
    z[3,4,3]  R1336     -1.6798898577690125e-02
    z[3,4,3]  R1337     -2.6354414224624634e-01
    z[3,4,3]  R1338     -3.3292093873023987e-01
    z[3,4,3]  R1339     -1.7964872717857361e-01
    z[3,4,3]  R1340     -4.3329432606697083e-01
    z[3,4,3]  R1341     4.7001048922538757e-01
    z[3,4,3]  R1342     3.3752273768186569e-02
    z[3,4,3]  R1343     -1.3107106089591980e-01
    z[3,4,3]  R1344     3.4038993716239929e-01
    z[3,4,3]  R1345     7.3964673280715942e-01
    z[3,4,3]  R1346     5.3205049037933350e-01
    z[3,4,3]  R1347     2.7089712023735046e-01
    z[3,4,3]  R1348     2.5936564803123474e-01
    z[3,4,3]  R1349     4.3587756156921387e-01
    z[3,4,3]  R1350     -7.3502779006958008e-01
    z[3,4,3]  R1351     -7.5853610038757324e-01
    z[3,4,3]  R1352     -7.4429786205291748e-01
    z[3,4,3]  R1353     -6.6490846872329712e-01
    z[3,4,3]  R1354     -2.3528985679149628e-01
    z[3,4,3]  R1355     -4.0259385108947754e-01
    z[3,4,3]  R1356     -1.9214524328708649e-01
    z[3,4,3]  R1357     -4.7693881392478943e-01
    z[3,4,3]  R1358     1.9922161102294922e-01
    z[3,4,3]  R1359     -1.2619754672050476e-01
    z[3,4,3]  R1360     -3.2596865296363831e-01
    z[3,4,3]  R1361     -5.2830260992050171e-01
    z[3,4,3]  R1362     -2.3884449899196625e-01
    z[3,4,3]  R1363     1.5330067276954651e-01
    z[3,4,3]  R1364     -1.3977591693401337e-01
    z[3,4,3]  R1365     -5.2640640735626221e-01
    z[3,4,3]  R1366     1.1290020495653152e-01
    z[3,4,3]  R1367     -3.5654491186141968e-01
    z[3,4,3]  R1368     -0.0711822658777237
    z[3,4,3]  R1369     -0.726284384727478
    z[3,4,3]  R1370     8.2584097981452942e-02
    z[3,4,3]  R1371     -7.2395765781402588e-01
    z[3,4,3]  R1372     2.3945966362953186e-01
    z[3,4,3]  R1373     5.5998995900154114e-02
    z[3,4,3]  R1374     -5.6604892015457153e-01
    z[3,4,3]  R1375     -7.7647775411605835e-01
    z[3,4,3]  R1376     2.5465661287307739e-01
    z[3,4,3]  R1377     -1.8583337962627411e-01
    z[3,4,3]  R1378     5.5111092329025269e-01
    z[3,4,3]  R1379     2.2040309011936188e-01
    z[3,4,3]  R1380     4.0116113424301147e-01
    z[3,4,3]  R1381     -1.0231083631515503e-01
    z[3,4,3]  R1382     5.5638146400451660e-01
    z[3,4,3]  R1383     2.8883364796638489e-01
    z[3,4,3]  R1384     0.730543851852417
    z[3,4,3]  R1385     7.0127081871032715e-01
    z[3,4,3]  R1386     8.2396721839904785e-01
    z[3,4,3]  R1387     0.727130115032196
    z[3,4,3]  R1388     6.3442248106002808e-01
    z[3,4,3]  R1389     0.633794367313385
    z[3,4,3]  R1390     -3.9689075946807861e-01
    z[3,4,3]  R1391     1.0902449488639832e-01
    z[3,4,3]  R1392     1.2227544933557510e-01
    z[3,4,3]  R1393     4.8029428720474243e-01
    z[3,4,3]  R1394     -4.7331269830465317e-02
    z[3,4,3]  R1395     -1.4609293639659882e-01
    z[3,4,3]  R1396     -1.9677279889583588e-01
    z[3,4,3]  R1397     1.7926159780472517e-03
    z[3,4,3]  R1398     9.0469516813755035e-02
    z[3,4,3]  R1399     2.3210534453392029e-01
    z[3,4,3]  R1400     1.5827704966068268e-01
    z[3,4,3]  R1401     -8.2274377346038818e-02
    z[3,4,3]  R1402     -1.4462047256529331e-02
    z[3,4,3]  R1403     -7.4838304519653320e-01
    z[3,4,3]  R1404     2.4816274642944336e-01
    z[3,4,3]  R1405     2.2176474332809448e-02
    z[3,4,3]  R1406     -2.5665040593594313e-03
    z[3,4,3]  R1407     2.1752910688519478e-02
    z[3,4,3]  R1408     5.9062212705612183e-02
    z[3,4,3]  R1409     -2.1189042925834656e-01
    z[3,4,3]  R1410     0.0831940770149231
    z[3,4,3]  R1411     -4.1274357587099075e-02
    z[3,4,3]  R1412     -2.5362381339073181e-01
    z[3,4,3]  R1413     3.1121477484703064e-01
    z[3,4,3]  R1414     -4.0754970163106918e-02
    z[3,4,3]  R1415     -3.0387207865715027e-01
    z[3,4,3]  R1416     -9.3949548900127411e-02
    z[3,4,3]  R1417     -1.1556169390678406e-01
    z[3,4,3]  R1418     -3.5379728674888611e-01
    z[3,4,3]  R1419     -2.3951049894094467e-02
    z[3,4,3]  R1420     -2.1424324810504913e-01
    z[3,4,3]  R1421     5.6550878286361694e-01
    z[3,4,3]  R1422     -3.3582359552383423e-01
    z[3,4,3]  R1423     -9.1047853231430054e-01
    z[3,4,3]  R1424     -6.9805346429347992e-02
    z[3,4,3]  R1425     1.1960940808057785e-01
    z[3,4,3]  R1426     -2.4114339053630829e-01
    z[3,4,3]  R1427     -9.3121886253356934e-01
    z[3,4,3]  R1428     -7.8325563669204712e-01
    z[3,4,3]  R1429     -0.847061276435852
    z[3,4,3]  R1430     -7.1464049816131592e-01
    z[3,4,3]  R1431     1.1077910661697388e-01
    z[3,4,3]  R1432     -8.0553990602493286e-01
    z[3,4,3]  R1433     -8.6751186847686768e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1328     -1
    z[3,4,4]  R1329     1
    z[3,4,4]  R1334     1.6339996457099915e-01
    z[3,4,4]  R1335     -5.2320018410682678e-02
    z[3,4,4]  R1336     -2.7691149711608887e-01
    z[3,4,4]  R1337     -3.3400258421897888e-01
    z[3,4,4]  R1338     3.0865228176116943e-01
    z[3,4,4]  R1339     2.8320398926734924e-01
    z[3,4,4]  R1340     2.0661781728267670e-01
    z[3,4,4]  R1341     -1.7275722324848175e-01
    z[3,4,4]  R1342     -6.0702469199895859e-02
    z[3,4,4]  R1343     2.2721193730831146e-01
    z[3,4,4]  R1344     -1.2641771696507931e-02
    z[3,4,4]  R1345     -1.3777954876422882e-01
    z[3,4,4]  R1346     -4.0162146091461182e-01
    z[3,4,4]  R1347     -5.1921719312667847e-01
    z[3,4,4]  R1348     1.8441526591777802e-01
    z[3,4,4]  R1349     0.0917959213256836
    z[3,4,4]  R1350     -2.2069972753524780e-01
    z[3,4,4]  R1351     -2.4616606533527374e-01
    z[3,4,4]  R1352     4.3175943195819855e-02
    z[3,4,4]  R1353     -2.7231946587562561e-01
    z[3,4,4]  R1354     1.4991672337055206e-01
    z[3,4,4]  R1355     7.3038570582866669e-02
    z[3,4,4]  R1356     1.2004748731851578e-01
    z[3,4,4]  R1357     -1.6610343754291534e-01
    z[3,4,4]  R1358     7.4635609984397888e-02
    z[3,4,4]  R1359     -3.2716533541679382e-01
    z[3,4,4]  R1360     -5.2616512775421143e-01
    z[3,4,4]  R1361     -5.2414391189813614e-02
    z[3,4,4]  R1362     7.6712578535079956e-01
    z[3,4,4]  R1363     7.2057497501373291e-01
    z[3,4,4]  R1364     -2.1359895169734955e-01
    z[3,4,4]  R1365     2.2223877906799316e-01
    z[3,4,4]  R1366     -0.164543017745018
    z[3,4,4]  R1367     -3.8728281855583191e-01
    z[3,4,4]  R1368     3.3666431903839111e-01
    z[3,4,4]  R1369     -3.3305177092552185e-01
    z[3,4,4]  R1370     7.8389182686805725e-02
    z[3,4,4]  R1371     4.9128594994544983e-01
    z[3,4,4]  R1372     5.0390070676803589e-01
    z[3,4,4]  R1373     -2.4160590767860413e-01
    z[3,4,4]  R1374     3.5600054264068604e-01
    z[3,4,4]  R1375     3.9648368954658508e-02
    z[3,4,4]  R1376     1.3042362034320831e-01
    z[3,4,4]  R1377     -3.2231798768043518e-01
    z[3,4,4]  R1378     3.4890845417976379e-01
    z[3,4,4]  R1379     5.7207494974136353e-01
    z[3,4,4]  R1380     4.8841181397438049e-01
    z[3,4,4]  R1381     0.535327136516571
    z[3,4,4]  R1382     -0.0871153250336647
    z[3,4,4]  R1383     -3.4129226207733154e-01
    z[3,4,4]  R1384     -8.1146813929080963e-02
    z[3,4,4]  R1385     -4.3037894368171692e-01
    z[3,4,4]  R1386     2.9538854956626892e-01
    z[3,4,4]  R1387     2.4446974694728851e-01
    z[3,4,4]  R1388     -1.2033727020025253e-01
    z[3,4,4]  R1389     1.5191417932510376e-01
    z[3,4,4]  R1390     7.2274312376976013e-02
    z[3,4,4]  R1391     -3.6287853121757507e-01
    z[3,4,4]  R1392     1.5929432213306427e-01
    z[3,4,4]  R1393     -3.2231506705284119e-01
    z[3,4,4]  R1394     3.0326032638549805e-01
    z[3,4,4]  R1395     8.3895117044448853e-02
    z[3,4,4]  R1396     -1.7281009256839752e-01
    z[3,4,4]  R1397     4.8168513923883438e-02
    z[3,4,4]  R1398     -3.4734839200973511e-01
    z[3,4,4]  R1399     1.6019767522811890e-01
    z[3,4,4]  R1400     -2.4893178045749664e-01
    z[3,4,4]  R1401     4.4497553259134293e-02
    z[3,4,4]  R1402     5.3775101900100708e-01
    z[3,4,4]  R1403     1.5182322263717651e-01
    z[3,4,4]  R1404     1.5464043617248535e-01
    z[3,4,4]  R1405     3.2749116420745850e-01
    z[3,4,4]  R1406     4.8573720455169678e-01
    z[3,4,4]  R1407     1.8877701461315155e-01
    z[3,4,4]  R1408     4.0514644980430603e-01
    z[3,4,4]  R1409     4.0021431446075439e-01
    z[3,4,4]  R1410     -9.5006980001926422e-02
    z[3,4,4]  R1411     6.3432060182094574e-02
    z[3,4,4]  R1412     -0.375505656003952
    z[3,4,4]  R1413     3.2811316847801208e-01
    z[3,4,4]  R1414     -1.7451224848628044e-03
    z[3,4,4]  R1415     3.4370237588882446e-01
    z[3,4,4]  R1416     -6.6038645803928375e-02
    z[3,4,4]  R1417     5.0186789035797119e-01
    z[3,4,4]  R1418     -2.7187541127204895e-01
    z[3,4,4]  R1419     -1.4624411240220070e-02
    z[3,4,4]  R1420     -2.2746595740318298e-01
    z[3,4,4]  R1421     1.5908056497573853e-01
    z[3,4,4]  R1422     8.2281278446316719e-03
    z[3,4,4]  R1423     2.4427349865436554e-01
    z[3,4,4]  R1424     9.0380340814590454e-02
    z[3,4,4]  R1425     -2.1852515637874603e-01
    z[3,4,4]  R1426     -1.2365867942571640e-01
    z[3,4,4]  R1427     1.1866585165262222e-01
    z[3,4,4]  R1428     3.2401621341705322e-01
    z[3,4,4]  R1429     1.4881283044815063e-01
    z[3,4,4]  R1430     3.4713208675384521e-01
    z[3,4,4]  R1431     -3.4721145033836365e-01
    z[3,4,4]  R1432     0.181483656167984
    z[3,4,4]  R1433     -3.1620559096336365e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1330     -1
    z[3,4,5]  R1331     1
    z[3,4,5]  R1334     -4.1141159832477570e-02
    z[3,4,5]  R1335     -1.1985564604401588e-02
    z[3,4,5]  R1336     1.4819647371768951e-01
    z[3,4,5]  R1337     -1.0341908782720566e-01
    z[3,4,5]  R1338     -1.5589644201099873e-02
    z[3,4,5]  R1339     7.0687723159790039e-01
    z[3,4,5]  R1340     -4.2672500014305115e-02
    z[3,4,5]  R1341     9.3455202877521515e-02
    z[3,4,5]  R1342     -2.4984742701053619e-01
    z[3,4,5]  R1343     2.3103237152099609e-01
    z[3,4,5]  R1344     -1.6044294834136963e-01
    z[3,4,5]  R1345     1.4248742163181305e-01
    z[3,4,5]  R1346     2.3973587155342102e-01
    z[3,4,5]  R1347     -2.4542784690856934e-01
    z[3,4,5]  R1348     4.4444516301155090e-01
    z[3,4,5]  R1349     5.5228674411773682e-01
    z[3,4,5]  R1350     1.3328480720520020e-01
    z[3,4,5]  R1351     -2.2664764523506165e-01
    z[3,4,5]  R1352     1.1630005389451981e-01
    z[3,4,5]  R1353     1.0064236819744110e-01
    z[3,4,5]  R1354     -2.9604652523994446e-01
    z[3,4,5]  R1355     -8.5728786885738373e-02
    z[3,4,5]  R1356     -6.8737751245498657e-01
    z[3,4,5]  R1357     -7.3190432786941528e-01
    z[3,4,5]  R1358     -3.5814478993415833e-01
    z[3,4,5]  R1359     5.8670127391815186e-01
    z[3,4,5]  R1360     4.0954446792602539e-01
    z[3,4,5]  R1361     -2.6134172081947327e-01
    z[3,4,5]  R1362     -0.087669737637043
    z[3,4,5]  R1363     -4.3736183643341064e-01
    z[3,4,5]  R1364     -4.2121067643165588e-01
    z[3,4,5]  R1365     -0.574893593788147
    z[3,4,5]  R1366     -5.1622176170349121e-01
    z[3,4,5]  R1367     3.9533430337905884e-01
    z[3,4,5]  R1368     4.2813035845756531e-01
    z[3,4,5]  R1369     -4.8270203173160553e-02
    z[3,4,5]  R1370     2.8862106800079346e-01
    z[3,4,5]  R1371     -5.1075357943773270e-02
    z[3,4,5]  R1372     -2.4388688802719116e-01
    z[3,4,5]  R1373     6.0606010258197784e-02
    z[3,4,5]  R1374     -8.9180164039134979e-02
    z[3,4,5]  R1375     -0.0878542810678482
    z[3,4,5]  R1376     1.1024557054042816e-02
    z[3,4,5]  R1377     -2.2485619783401489e-01
    z[3,4,5]  R1378     -2.9883494973182678e-01
    z[3,4,5]  R1379     2.6258125901222229e-01
    z[3,4,5]  R1380     1.6365723311901093e-01
    z[3,4,5]  R1381     7.3313899338245392e-02
    z[3,4,5]  R1382     -1.2089667469263077e-01
    z[3,4,5]  R1383     -1.2820911407470703e-01
    z[3,4,5]  R1384     6.3424748368561268e-03
    z[3,4,5]  R1385     2.8956970572471619e-01
    z[3,4,5]  R1386     2.3998151719570160e-01
    z[3,4,5]  R1387     2.4932898581027985e-01
    z[3,4,5]  R1388     -4.3083101511001587e-01
    z[3,4,5]  R1389     0.253202348947525
    z[3,4,5]  R1390     1.0113696753978729e-01
    z[3,4,5]  R1391     -2.5225368142127991e-01
    z[3,4,5]  R1392     -4.9402132630348206e-01
    z[3,4,5]  R1393     2.6839631609618664e-03
    z[3,4,5]  R1394     1.1054874956607819e-01
    z[3,4,5]  R1395     1.2872508168220520e-01
    z[3,4,5]  R1396     1.3896699249744415e-01
    z[3,4,5]  R1397     1.1986243724822998e-01
    z[3,4,5]  R1398     3.1845462322235107e-01
    z[3,4,5]  R1399     -3.1852710247039795e-01
    z[3,4,5]  R1400     -1.2174678593873978e-01
    z[3,4,5]  R1401     4.6465528011322021e-01
    z[3,4,5]  R1402     -1.0141479969024658e-01
    z[3,4,5]  R1403     1.4903669059276581e-01
    z[3,4,5]  R1404     1.5225917100906372e-01
    z[3,4,5]  R1405     1.6096018254756927e-01
    z[3,4,5]  R1406     -2.0274797081947327e-01
    z[3,4,5]  R1407     9.3289494514465332e-02
    z[3,4,5]  R1408     1.0635881125926971e-01
    z[3,4,5]  R1409     -3.0697991605848074e-03
    z[3,4,5]  R1410     4.4315528124570847e-02
    z[3,4,5]  R1411     5.9369522333145142e-01
    z[3,4,5]  R1412     8.3816125988960266e-02
    z[3,4,5]  R1413     2.5790938735008240e-01
    z[3,4,5]  R1414     2.0269152522087097e-01
    z[3,4,5]  R1415     -0.318645179271698
    z[3,4,5]  R1416     -1.2177570909261703e-01
    z[3,4,5]  R1417     3.5580408573150635e-01
    z[3,4,5]  R1418     1.9559279084205627e-01
    z[3,4,5]  R1419     -5.3090296685695648e-02
    z[3,4,5]  R1420     7.4570290744304657e-02
    z[3,4,5]  R1421     -3.9866459369659424e-01
    z[3,4,5]  R1422     6.7389182746410370e-02
    z[3,4,5]  R1423     3.8153558969497681e-02
    z[3,4,5]  R1424     5.0841666758060455e-02
    z[3,4,5]  R1425     1.0002262890338898e-02
    z[3,4,5]  R1426     0.109798364341259
    z[3,4,5]  R1427     -4.8818994313478470e-02
    z[3,4,5]  R1428     -3.1974723935127258e-01
    z[3,4,5]  R1429     7.0133045315742493e-02
    z[3,4,5]  R1430     -3.3949542045593262e-01
    z[3,4,5]  R1431     -3.2147404551506042e-01
    z[3,4,5]  R1432     -4.6553176641464233e-01
    z[3,4,5]  R1433     2.0283545553684235e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1332     -1
    z[3,4,6]  R1333     1
    z[3,4,6]  R1334     -4.8421375453472137e-02
    z[3,4,6]  R1335     -1.0789953172206879e-01
    z[3,4,6]  R1336     3.2823103666305542e-01
    z[3,4,6]  R1337     1.5453889966011047e-01
    z[3,4,6]  R1338     1.8215131759643555e-01
    z[3,4,6]  R1339     -9.3076303601264954e-03
    z[3,4,6]  R1340     1.8209001421928406e-01
    z[3,4,6]  R1341     -1.2016330659389496e-01
    z[3,4,6]  R1342     8.1099696457386017e-02
    z[3,4,6]  R1343     -1.9036976993083954e-01
    z[3,4,6]  R1344     3.7223890423774719e-01
    z[3,4,6]  R1345     9.8171653226017952e-03
    z[3,4,6]  R1346     -4.3109733611345291e-02
    z[3,4,6]  R1347     -2.2044392302632332e-02
    z[3,4,6]  R1348     -0.0145966662093997
    z[3,4,6]  R1349     2.6133781671524048e-01
    z[3,4,6]  R1350     -1.3080660998821259e-01
    z[3,4,6]  R1351     -2.1050852537155151e-01
    z[3,4,6]  R1352     -3.3424910902976990e-01
    z[3,4,6]  R1353     -5.7147359848022461e-01
    z[3,4,6]  R1354     3.5175263881683350e-01
    z[3,4,6]  R1355     -5.1904983818531036e-02
    z[3,4,6]  R1356     0.488119512796402
    z[3,4,6]  R1357     -1.0014699399471283e-01
    z[3,4,6]  R1358     -2.0374302566051483e-01
    z[3,4,6]  R1359     -8.9272432029247284e-02
    z[3,4,6]  R1360     -2.2940912842750549e-01
    z[3,4,6]  R1361     -5.7690918445587158e-01
    z[3,4,6]  R1362     -2.2818987071514130e-01
    z[3,4,6]  R1363     1.9642080366611481e-01
    z[3,4,6]  R1364     3.4517055749893188e-01
    z[3,4,6]  R1365     2.0465636253356934e-01
    z[3,4,6]  R1366     -1.7046001553535461e-01
    z[3,4,6]  R1367     -3.1872513890266418e-01
    z[3,4,6]  R1368     -5.1207724958658218e-02
    z[3,4,6]  R1369     -3.2695299386978149e-01
    z[3,4,6]  R1370     2.2473935782909393e-01
    z[3,4,6]  R1371     -1.7372079193592072e-01
    z[3,4,6]  R1372     8.6256787180900574e-02
    z[3,4,6]  R1373     -3.9381444454193115e-02
    z[3,4,6]  R1374     7.6236926019191742e-02
    z[3,4,6]  R1375     -2.3633965849876404e-01
    z[3,4,6]  R1376     3.9987966418266296e-01
    z[3,4,6]  R1377     -1.7006626725196838e-01
    z[3,4,6]  R1378     -3.1170496344566345e-01
    z[3,4,6]  R1379     -3.5321542620658875e-01
    z[3,4,6]  R1380     -2.2743065655231476e-01
    z[3,4,6]  R1381     1.2947093928232789e-03
    z[3,4,6]  R1382     2.2358534857630730e-02
    z[3,4,6]  R1383     -2.0223094522953033e-01
    z[3,4,6]  R1384     -3.4755849838256836e-01
    z[3,4,6]  R1385     1.5080761909484863e-01
    z[3,4,6]  R1386     -2.2129465639591217e-01
    z[3,4,6]  R1387     4.7135999798774719e-01
    z[3,4,6]  R1388     2.8967404365539551e-01
    z[3,4,6]  R1389     1.5623587369918823e-01
    z[3,4,6]  R1390     3.0056005716323853e-01
    z[3,4,6]  R1391     1.6511987149715424e-01
    z[3,4,6]  R1392     1.1102846264839172e-01
    z[3,4,6]  R1393     5.3668646141886711e-03
    z[3,4,6]  R1394     1.1176948994398117e-01
    z[3,4,6]  R1395     1.1305092275142670e-01
    z[3,4,6]  R1396     4.4450348615646362e-01
    z[3,4,6]  R1397     -4.2897281050682068e-01
    z[3,4,6]  R1398     -1.9016404449939728e-01
    z[3,4,6]  R1399     -3.6399850249290466e-01
    z[3,4,6]  R1400     -5.1832431554794312e-01
    z[3,4,6]  R1401     -4.5685482025146484e-01
    z[3,4,6]  R1402     7.9845957458019257e-02
    z[3,4,6]  R1403     1.7931368947029114e-01
    z[3,4,6]  R1404     3.4765779972076416e-01
    z[3,4,6]  R1405     -3.6506736278533936e-01
    z[3,4,6]  R1406     -9.8876990377902985e-02
    z[3,4,6]  R1407     -7.5220972299575806e-01
    z[3,4,6]  R1408     -2.4946087598800659e-01
    z[3,4,6]  R1409     -4.7301241755485535e-01
    z[3,4,6]  R1410     -7.1854597330093384e-01
    z[3,4,6]  R1411     -4.5263972878456116e-01
    z[3,4,6]  R1412     -2.1199119091033936e-01
    z[3,4,6]  R1413     -5.4631048440933228e-01
    z[3,4,6]  R1414     3.9625599980354309e-01
    z[3,4,6]  R1415     2.5869068503379822e-01
    z[3,4,6]  R1416     -0.459351122379303
    z[3,4,6]  R1417     -3.2972556352615356e-01
    z[3,4,6]  R1418     -4.8167926073074341e-01
    z[3,4,6]  R1419     -2.6300454139709473e-01
    z[3,4,6]  R1420     -5.5979293584823608e-01
    z[3,4,6]  R1421     1.9547837972640991e-01
    z[3,4,6]  R1422     -5.1672633737325668e-02
    z[3,4,6]  R1423     -2.5184908509254456e-01
    z[3,4,6]  R1424     -4.9857613444328308e-01
    z[3,4,6]  R1425     -1.8820254504680634e-01
    z[3,4,6]  R1426     -1.9410468637943268e-01
    z[3,4,6]  R1427     -2.8042781352996826e-01
    z[3,4,6]  R1428     -4.2756326496601105e-02
    z[3,4,6]  R1429     2.1045985817909241e-01
    z[3,4,6]  R1430     3.6888951063156128e-01
    z[3,4,6]  R1431     6.0197249054908752e-02
    z[3,4,6]  R1432     2.4023090302944183e-01
    z[3,4,6]  R1433     7.8073084354400635e-02
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1434     -1
    z[4,3,0]  R1435     1
    z[4,3,0]  R1448     1.1587698757648468e-01
    z[4,3,0]  R1449     3.8701277226209641e-02
    z[4,3,0]  R1450     -9.7453221678733826e-03
    z[4,3,0]  R1451     1.9839751720428467e-01
    z[4,3,0]  R1452     -5.3450185805559158e-02
    z[4,3,0]  R1453     -4.1370356082916260e-01
    z[4,3,0]  R1454     5.1985946483910084e-03
    z[4,3,0]  R1455     6.3221298158168793e-02
    z[4,3,0]  R1456     1.8728289008140564e-01
    z[4,3,0]  R1457     -1.7933090031147003e-01
    z[4,3,0]  R1458     -2.3720602691173553e-01
    z[4,3,0]  R1459     1.1222624778747559e-01
    z[4,3,0]  R1460     -0.077292300760746
    z[4,3,0]  R1461     2.3319798707962036e-01
    z[4,3,0]  R1462     1.2503399921115488e-04
    z[4,3,0]  R1463     1.3410587608814240e-01
    z[4,3,0]  R1464     3.0718800425529480e-01
    z[4,3,0]  R1465     -1.1665239185094833e-01
    z[4,3,0]  R1466     8.6510226130485535e-02
    z[4,3,0]  R1467     -8.5522763431072235e-02
    z[4,3,0]  R1468     -3.8181382417678833e-01
    z[4,3,0]  R1469     -3.1299063563346863e-01
    z[4,3,0]  R1470     -2.2579859197139740e-01
    z[4,3,0]  R1471     5.1869653165340424e-02
    z[4,3,0]  R1472     -3.9654752612113953e-01
    z[4,3,0]  R1473     -6.8331561982631683e-02
    z[4,3,0]  R1474     1.4130171388387680e-02
    z[4,3,0]  R1475     -0.374836266040802
    z[4,3,0]  R1476     -5.9481244534254074e-03
    z[4,3,0]  R1477     -3.9449077844619751e-01
    z[4,3,0]  R1478     -3.5857826471328735e-01
    z[4,3,0]  R1479     8.1744618713855743e-02
    z[4,3,0]  R1480     8.8852338492870331e-02
    z[4,3,0]  R1481     -3.2260206341743469e-01
    z[4,3,0]  R1482     1.7839437723159790e-01
    z[4,3,0]  R1483     -0.574947714805603
    z[4,3,0]  R1484     3.4821593761444092e-01
    z[4,3,0]  R1485     -7.2644799947738647e-02
    z[4,3,0]  R1486     7.4504047632217407e-01
    z[4,3,0]  R1487     1.6636660695075989e-01
    z[4,3,0]  R1488     3.4775093197822571e-02
    z[4,3,0]  R1489     -1.7973975837230682e-01
    z[4,3,0]  R1490     -2.3917232453823090e-01
    z[4,3,0]  R1491     -1.4337505400180817e-01
    z[4,3,0]  R1492     -3.0383253097534180e-01
    z[4,3,0]  R1493     -3.5776841640472412e-01
    z[4,3,0]  R1494     2.0762230455875397e-01
    z[4,3,0]  R1495     5.1076811552047729e-01
    z[4,3,0]  R1496     1.9453017413616180e-01
    z[4,3,0]  R1497     -2.9797112941741943e-01
    z[4,3,0]  R1498     -0.944106936454773
    z[4,3,0]  R1499     -8.9444696903228760e-01
    z[4,3,0]  R1500     -8.8479697704315186e-01
    z[4,3,0]  R1501     -8.3608752489089966e-01
    z[4,3,0]  R1502     -7.4958759546279907e-01
    z[4,3,0]  R1503     -6.0549592971801758e-01
    z[4,3,0]  R1504     8.9866951107978821e-02
    z[4,3,0]  R1505     -1.5696670114994049e-01
    z[4,3,0]  R1506     4.4755467772483826e-01
    z[4,3,0]  R1507     3.8049522042274475e-01
    z[4,3,0]  R1508     2.2003683447837830e-01
    z[4,3,0]  R1509     2.8103478252887726e-02
    z[4,3,0]  R1510     2.6788082718849182e-01
    z[4,3,0]  R1511     4.0804773569107056e-01
    z[4,3,0]  R1512     7.6667505502700806e-01
    z[4,3,0]  R1513     0.556808590888977
    z[4,3,0]  R1514     4.4196322560310364e-01
    z[4,3,0]  R1515     3.7991029024124146e-01
    z[4,3,0]  R1516     3.3493974804878235e-01
    z[4,3,0]  R1517     2.6604282855987549e-01
    z[4,3,0]  R1518     -1.7396806180477142e-01
    z[4,3,0]  R1519     7.4199743568897247e-02
    z[4,3,0]  R1520     -2.5420048832893372e-01
    z[4,3,0]  R1521     2.0277349278330803e-02
    z[4,3,0]  R1522     -1.5550833940505981e-01
    z[4,3,0]  R1523     1.4069461822509766e-01
    z[4,3,0]  R1524     1.8428291380405426e-01
    z[4,3,0]  R1525     7.2697833180427551e-02
    z[4,3,0]  R1526     6.1067931354045868e-02
    z[4,3,0]  R1527     -1.0487715899944305e-01
    z[4,3,0]  R1528     -4.9134048819541931e-01
    z[4,3,0]  R1529     -4.0034279227256775e-01
    z[4,3,0]  R1530     -5.8334946632385254e-01
    z[4,3,0]  R1531     -3.3326229453086853e-01
    z[4,3,0]  R1532     -3.1065317988395691e-01
    z[4,3,0]  R1533     -1.7757639288902283e-01
    z[4,3,0]  R1534     5.4894924163818359e-01
    z[4,3,0]  R1535     -2.0485103130340576e-01
    z[4,3,0]  R1536     -3.8280868530273438e-01
    z[4,3,0]  R1537     -5.7402960956096649e-02
    z[4,3,0]  R1538     -0.668807327747345
    z[4,3,0]  R1539     -4.1047197580337524e-01
    z[4,3,0]  R1540     -6.2148553133010864e-01
    z[4,3,0]  R1541     3.4815111756324768e-01
    z[4,3,0]  R1542     -1.1442486941814423e-01
    z[4,3,0]  R1543     -9.2298634350299835e-02
    z[4,3,0]  R1544     -2.4793858826160431e-01
    z[4,3,0]  R1545     1.5128245949745178e-01
    z[4,3,0]  R1546     7.7955538034439087e-01
    z[4,3,0]  R1547     8.5126173496246338e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1436     -1
    z[4,3,1]  R1437     1
    z[4,3,1]  R1448     5.1945990324020386e-01
    z[4,3,1]  R1449     4.3598660826683044e-01
    z[4,3,1]  R1450     2.7470833063125610e-01
    z[4,3,1]  R1451     2.9422539472579956e-01
    z[4,3,1]  R1452     5.3513032197952271e-01
    z[4,3,1]  R1453     5.2059924602508545e-01
    z[4,3,1]  R1454     8.5285681486129761e-01
    z[4,3,1]  R1455     8.5074758529663086e-01
    z[4,3,1]  R1456     8.1643897294998169e-01
    z[4,3,1]  R1457     7.6616877317428589e-01
    z[4,3,1]  R1458     -8.7570571899414062e-01
    z[4,3,1]  R1459     -0.948878824710846
    z[4,3,1]  R1460     -8.3460867404937744e-01
    z[4,3,1]  R1461     -0.800197958946228
    z[4,3,1]  R1462     -8.3948266506195068e-01
    z[4,3,1]  R1463     -7.5415897369384766e-01
    z[4,3,1]  R1464     -7.2628623247146606e-01
    z[4,3,1]  R1465     -7.4365448951721191e-01
    z[4,3,1]  R1466     -7.2204142808914185e-01
    z[4,3,1]  R1467     -4.2506304383277893e-01
    z[4,3,1]  R1468     0.69159334897995
    z[4,3,1]  R1469     0.718513011932373
    z[4,3,1]  R1470     5.8092606067657471e-01
    z[4,3,1]  R1471     6.1590307950973511e-01
    z[4,3,1]  R1472     6.2844419479370117e-01
    z[4,3,1]  R1473     5.1614028215408325e-01
    z[4,3,1]  R1474     5.3301292657852173e-01
    z[4,3,1]  R1475     5.4256129264831543e-01
    z[4,3,1]  R1476     4.7060114145278931e-01
    z[4,3,1]  R1477     5.1736724376678467e-01
    z[4,3,1]  R1478     8.1953680515289307e-01
    z[4,3,1]  R1479     7.3447358608245850e-01
    z[4,3,1]  R1480     6.4253956079483032e-01
    z[4,3,1]  R1481     6.2869960069656372e-01
    z[4,3,1]  R1482     6.3185513019561768e-01
    z[4,3,1]  R1483     7.6218783855438232e-01
    z[4,3,1]  R1484     6.7630988359451294e-01
    z[4,3,1]  R1485     -0.663023829460144
    z[4,3,1]  R1486     -1.7637096345424652e-01
    z[4,3,1]  R1487     -1.2277159839868546e-01
    z[4,3,1]  R1488     8.4047597646713257e-01
    z[4,3,1]  R1489     8.0599933862686157e-01
    z[4,3,1]  R1490     0.778223991394043
    z[4,3,1]  R1491     9.6594981849193573e-02
    z[4,3,1]  R1492     2.2723279893398285e-02
    z[4,3,1]  R1493     -2.1410322189331055e-01
    z[4,3,1]  R1494     1.2241020798683167e-02
    z[4,3,1]  R1495     -5.4259186983108521e-01
    z[4,3,1]  R1496     -0.0758294016122818
    z[4,3,1]  R1497     1.6085606068372726e-02
    z[4,3,1]  R1498     -1.4133305847644806e-01
    z[4,3,1]  R1499     3.1024524569511414e-01
    z[4,3,1]  R1500     -7.7348113059997559e-02
    z[4,3,1]  R1501     -2.5451722741127014e-01
    z[4,3,1]  R1502     -3.5656234622001648e-01
    z[4,3,1]  R1503     -1.1910539120435715e-01
    z[4,3,1]  R1504     8.5235631465911865e-01
    z[4,3,1]  R1505     0.825688362121582
    z[4,3,1]  R1506     8.4348762035369873e-01
    z[4,3,1]  R1507     8.3468645811080933e-01
    z[4,3,1]  R1508     -8.1150442361831665e-01
    z[4,3,1]  R1509     -5.7987397909164429e-01
    z[4,3,1]  R1510     -6.5155172348022461e-01
    z[4,3,1]  R1511     -6.5436708927154541e-01
    z[4,3,1]  R1512     -3.1652554869651794e-01
    z[4,3,1]  R1513     -3.0074384808540344e-01
    z[4,3,1]  R1514     -4.0133380889892578e-01
    z[4,3,1]  R1515     -2.6648142933845520e-01
    z[4,3,1]  R1516     -4.2979344725608826e-01
    z[4,3,1]  R1517     -2.3862951993942261e-01
    z[4,3,1]  R1518     1.6371791064739227e-01
    z[4,3,1]  R1519     1.5403643250465393e-01
    z[4,3,1]  R1520     -1.1247289367020130e-02
    z[4,3,1]  R1521     1.7395548522472382e-01
    z[4,3,1]  R1522     -6.5469431877136230e-01
    z[4,3,1]  R1523     -8.2501769065856934e-02
    z[4,3,1]  R1524     -5.5584597587585449e-01
    z[4,3,1]  R1525     6.4218886196613312e-02
    z[4,3,1]  R1526     -3.2696792483329773e-01
    z[4,3,1]  R1527     4.2401787638664246e-01
    z[4,3,1]  R1528     2.6551276445388794e-01
    z[4,3,1]  R1529     -5.3360808640718460e-02
    z[4,3,1]  R1530     -6.0729876160621643e-02
    z[4,3,1]  R1531     -2.1936267614364624e-01
    z[4,3,1]  R1532     5.2177053689956665e-01
    z[4,3,1]  R1533     -2.4402105808258057e-01
    z[4,3,1]  R1534     -7.2244131565093994e-01
    z[4,3,1]  R1535     -1.3527034223079681e-01
    z[4,3,1]  R1536     2.3988784849643707e-01
    z[4,3,1]  R1537     -8.2922744750976562e-01
    z[4,3,1]  R1538     -3.0286094546318054e-01
    z[4,3,1]  R1539     -3.9802485704421997e-01
    z[4,3,1]  R1540     5.1660817861557007e-01
    z[4,3,1]  R1541     -6.8225634098052979e-01
    z[4,3,1]  R1542     -5.0074762105941772e-01
    z[4,3,1]  R1543     -0.630085289478302
    z[4,3,1]  R1544     -3.1725892424583435e-01
    z[4,3,1]  R1545     -4.0940544009208679e-01
    z[4,3,1]  R1546     2.0677064359188080e-01
    z[4,3,1]  R1547     1.3145956397056580e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1438     -1
    z[4,3,2]  R1439     1
    z[4,3,2]  R1448     -2.3583377897739410e-01
    z[4,3,2]  R1449     -1.5753577649593353e-01
    z[4,3,2]  R1450     2.2737956047058105e-01
    z[4,3,2]  R1451     -3.5226836800575256e-02
    z[4,3,2]  R1452     -1.5581825375556946e-01
    z[4,3,2]  R1453     -2.1102492511272430e-01
    z[4,3,2]  R1454     9.6422888338565826e-02
    z[4,3,2]  R1455     -0.194339781999588
    z[4,3,2]  R1456     4.0524479001760483e-02
    z[4,3,2]  R1457     2.1498893201351166e-01
    z[4,3,2]  R1458     -2.4073255062103271e-01
    z[4,3,2]  R1459     1.7117829620838165e-01
    z[4,3,2]  R1460     -1.0943584889173508e-01
    z[4,3,2]  R1461     3.2340955734252930e-01
    z[4,3,2]  R1462     1.6987487673759460e-01
    z[4,3,2]  R1463     -3.1586271524429321e-01
    z[4,3,2]  R1464     -8.7423577904701233e-02
    z[4,3,2]  R1465     5.4338318295776844e-04
    z[4,3,2]  R1466     4.0635776519775391e-01
    z[4,3,2]  R1467     4.1774931550025940e-01
    z[4,3,2]  R1468     3.8258284330368042e-01
    z[4,3,2]  R1469     3.4474813938140869e-01
    z[4,3,2]  R1470     -5.6983286142349243e-01
    z[4,3,2]  R1471     -8.5677266120910645e-02
    z[4,3,2]  R1472     -4.5456889271736145e-01
    z[4,3,2]  R1473     -5.4782372713088989e-01
    z[4,3,2]  R1474     -4.2600205540657043e-01
    z[4,3,2]  R1475     -4.5178778469562531e-02
    z[4,3,2]  R1476     -7.2194474935531616e-01
    z[4,3,2]  R1477     -8.4986887872219086e-02
    z[4,3,2]  R1478     -0.00379387685097754
    z[4,3,2]  R1479     -2.7375376224517822e-01
    z[4,3,2]  R1480     -5.8329051733016968e-01
    z[4,3,2]  R1481     -1.1103716678917408e-02
    z[4,3,2]  R1482     -3.1555393338203430e-01
    z[4,3,2]  R1483     1.2540809810161591e-01
    z[4,3,2]  R1484     6.9144517183303833e-02
    z[4,3,2]  R1485     1.1344595253467560e-01
    z[4,3,2]  R1486     -5.4198831319808960e-01
    z[4,3,2]  R1487     6.1031565070152283e-02
    z[4,3,2]  R1488     -1.6788861155509949e-01
    z[4,3,2]  R1489     -4.6955174207687378e-01
    z[4,3,2]  R1490     4.6259054541587830e-01
    z[4,3,2]  R1491     8.8542439043521881e-02
    z[4,3,2]  R1492     2.9090738296508789e-01
    z[4,3,2]  R1493     -1.9310995936393738e-01
    z[4,3,2]  R1494     2.7238744497299194e-01
    z[4,3,2]  R1495     0.452673077583313
    z[4,3,2]  R1496     1.2094288133084774e-02
    z[4,3,2]  R1497     -1.0561206936836243e-01
    z[4,3,2]  R1498     3.1066054478287697e-02
    z[4,3,2]  R1499     -2.8208622243255377e-03
    z[4,3,2]  R1500     -6.7019328474998474e-02
    z[4,3,2]  R1501     1.4348384737968445e-01
    z[4,3,2]  R1502     2.6731422543525696e-01
    z[4,3,2]  R1503     -8.3356760442256927e-02
    z[4,3,2]  R1504     -5.5839867854956537e-05
    z[4,3,2]  R1505     1.4025759696960449e-01
    z[4,3,2]  R1506     1.1999390274286270e-01
    z[4,3,2]  R1507     1.0017056018114090e-02
    z[4,3,2]  R1508     -1.1276292800903320e-01
    z[4,3,2]  R1509     -2.7658042311668396e-01
    z[4,3,2]  R1510     3.2855155877768993e-03
    z[4,3,2]  R1511     -4.0102750062942505e-02
    z[4,3,2]  R1512     -1.1400407552719116e-01
    z[4,3,2]  R1513     -1.6668376326560974e-01
    z[4,3,2]  R1514     1.4053578674793243e-01
    z[4,3,2]  R1515     2.3021285235881805e-01
    z[4,3,2]  R1516     -1.4832855761051178e-01
    z[4,3,2]  R1517     1.3894286751747131e-01
    z[4,3,2]  R1518     -8.0853068828582764e-01
    z[4,3,2]  R1519     -8.9067792892456055e-01
    z[4,3,2]  R1520     -4.1614410281181335e-01
    z[4,3,2]  R1521     -4.1055321693420410e-01
    z[4,3,2]  R1522     5.7632780075073242e-01
    z[4,3,2]  R1523     -7.0586651563644409e-01
    z[4,3,2]  R1524     -2.3154844343662262e-01
    z[4,3,2]  R1525     5.5463171005249023e-01
    z[4,3,2]  R1526     -4.2904245853424072e-01
    z[4,3,2]  R1527     1.9134703278541565e-01
    z[4,3,2]  R1528     -5.7128328084945679e-01
    z[4,3,2]  R1529     -3.7148031592369080e-01
    z[4,3,2]  R1530     -5.6626230478286743e-01
    z[4,3,2]  R1531     -5.5301815271377563e-01
    z[4,3,2]  R1532     -5.7177132368087769e-01
    z[4,3,2]  R1533     -4.0159627795219421e-01
    z[4,3,2]  R1534     -1.7308506369590759e-01
    z[4,3,2]  R1535     -3.7613001465797424e-01
    z[4,3,2]  R1536     -0.646323025226593
    z[4,3,2]  R1537     4.9229413270950317e-01
    z[4,3,2]  R1538     -7.6841311529278755e-03
    z[4,3,2]  R1539     -7.0883341133594513e-02
    z[4,3,2]  R1540     -3.2401564717292786e-01
    z[4,3,2]  R1541     -4.4205355644226074e-01
    z[4,3,2]  R1542     -3.5247129201889038e-01
    z[4,3,2]  R1543     1.5784873068332672e-01
    z[4,3,2]  R1544     -5.9990704059600830e-01
    z[4,3,2]  R1545     -7.1209657192230225e-01
    z[4,3,2]  R1546     1.3143076002597809e-01
    z[4,3,2]  R1547     -2.8840396553277969e-02
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1440     -1
    z[4,3,3]  R1441     1
    z[4,3,3]  R1448     0.730543851852417
    z[4,3,3]  R1449     7.0127081871032715e-01
    z[4,3,3]  R1450     8.2396721839904785e-01
    z[4,3,3]  R1451     0.727130115032196
    z[4,3,3]  R1452     6.3442248106002808e-01
    z[4,3,3]  R1453     0.633794367313385
    z[4,3,3]  R1454     -3.9689075946807861e-01
    z[4,3,3]  R1455     1.0902449488639832e-01
    z[4,3,3]  R1456     1.2227544933557510e-01
    z[4,3,3]  R1457     4.8029428720474243e-01
    z[4,3,3]  R1458     -4.7331269830465317e-02
    z[4,3,3]  R1459     -1.4609293639659882e-01
    z[4,3,3]  R1460     -1.9677279889583588e-01
    z[4,3,3]  R1461     1.7926159780472517e-03
    z[4,3,3]  R1462     9.0469516813755035e-02
    z[4,3,3]  R1463     2.3210534453392029e-01
    z[4,3,3]  R1464     1.5827704966068268e-01
    z[4,3,3]  R1465     -8.2274377346038818e-02
    z[4,3,3]  R1466     -1.4462047256529331e-02
    z[4,3,3]  R1467     -7.4838304519653320e-01
    z[4,3,3]  R1468     2.4816274642944336e-01
    z[4,3,3]  R1469     2.2176474332809448e-02
    z[4,3,3]  R1470     -2.5665040593594313e-03
    z[4,3,3]  R1471     2.1752910688519478e-02
    z[4,3,3]  R1472     5.9062212705612183e-02
    z[4,3,3]  R1473     -2.1189042925834656e-01
    z[4,3,3]  R1474     0.0831940770149231
    z[4,3,3]  R1475     -4.1274357587099075e-02
    z[4,3,3]  R1476     -2.5362381339073181e-01
    z[4,3,3]  R1477     3.1121477484703064e-01
    z[4,3,3]  R1478     -4.0754970163106918e-02
    z[4,3,3]  R1479     -3.0387207865715027e-01
    z[4,3,3]  R1480     -9.3949548900127411e-02
    z[4,3,3]  R1481     -1.1556169390678406e-01
    z[4,3,3]  R1482     -3.5379728674888611e-01
    z[4,3,3]  R1483     -2.3951049894094467e-02
    z[4,3,3]  R1484     -2.1424324810504913e-01
    z[4,3,3]  R1485     5.6550878286361694e-01
    z[4,3,3]  R1486     -3.3582359552383423e-01
    z[4,3,3]  R1487     -9.1047853231430054e-01
    z[4,3,3]  R1488     -6.9805346429347992e-02
    z[4,3,3]  R1489     1.1960940808057785e-01
    z[4,3,3]  R1490     -2.4114339053630829e-01
    z[4,3,3]  R1491     -9.3121886253356934e-01
    z[4,3,3]  R1492     -7.8325563669204712e-01
    z[4,3,3]  R1493     -0.847061276435852
    z[4,3,3]  R1494     -7.1464049816131592e-01
    z[4,3,3]  R1495     1.1077910661697388e-01
    z[4,3,3]  R1496     -8.0553990602493286e-01
    z[4,3,3]  R1497     -8.6751186847686768e-01
    z[4,3,3]  R1498     -2.3871541023254395e-01
    z[4,3,3]  R1499     -2.9863205552101135e-01
    z[4,3,3]  R1500     -1.6798898577690125e-02
    z[4,3,3]  R1501     -2.6354414224624634e-01
    z[4,3,3]  R1502     -3.3292093873023987e-01
    z[4,3,3]  R1503     -1.7964872717857361e-01
    z[4,3,3]  R1504     -4.3329432606697083e-01
    z[4,3,3]  R1505     4.7001048922538757e-01
    z[4,3,3]  R1506     3.3752273768186569e-02
    z[4,3,3]  R1507     -1.3107106089591980e-01
    z[4,3,3]  R1508     3.4038993716239929e-01
    z[4,3,3]  R1509     7.3964673280715942e-01
    z[4,3,3]  R1510     5.3205049037933350e-01
    z[4,3,3]  R1511     2.7089712023735046e-01
    z[4,3,3]  R1512     2.5936564803123474e-01
    z[4,3,3]  R1513     4.3587756156921387e-01
    z[4,3,3]  R1514     -7.3502779006958008e-01
    z[4,3,3]  R1515     -7.5853610038757324e-01
    z[4,3,3]  R1516     -7.4429786205291748e-01
    z[4,3,3]  R1517     -6.6490846872329712e-01
    z[4,3,3]  R1518     -2.3528985679149628e-01
    z[4,3,3]  R1519     -4.0259385108947754e-01
    z[4,3,3]  R1520     -1.9214524328708649e-01
    z[4,3,3]  R1521     -4.7693881392478943e-01
    z[4,3,3]  R1522     1.9922161102294922e-01
    z[4,3,3]  R1523     -1.2619754672050476e-01
    z[4,3,3]  R1524     -3.2596865296363831e-01
    z[4,3,3]  R1525     -5.2830260992050171e-01
    z[4,3,3]  R1526     -2.3884449899196625e-01
    z[4,3,3]  R1527     1.5330067276954651e-01
    z[4,3,3]  R1528     -1.3977591693401337e-01
    z[4,3,3]  R1529     -5.2640640735626221e-01
    z[4,3,3]  R1530     1.1290020495653152e-01
    z[4,3,3]  R1531     -3.5654491186141968e-01
    z[4,3,3]  R1532     -0.0711822658777237
    z[4,3,3]  R1533     -0.726284384727478
    z[4,3,3]  R1534     8.2584097981452942e-02
    z[4,3,3]  R1535     -7.2395765781402588e-01
    z[4,3,3]  R1536     2.3945966362953186e-01
    z[4,3,3]  R1537     5.5998995900154114e-02
    z[4,3,3]  R1538     -5.6604892015457153e-01
    z[4,3,3]  R1539     -7.7647775411605835e-01
    z[4,3,3]  R1540     2.5465661287307739e-01
    z[4,3,3]  R1541     -1.8583337962627411e-01
    z[4,3,3]  R1542     5.5111092329025269e-01
    z[4,3,3]  R1543     2.2040309011936188e-01
    z[4,3,3]  R1544     4.0116113424301147e-01
    z[4,3,3]  R1545     -1.0231083631515503e-01
    z[4,3,3]  R1546     5.5638146400451660e-01
    z[4,3,3]  R1547     2.8883364796638489e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1442     -1
    z[4,3,4]  R1443     1
    z[4,3,4]  R1448     -8.1146813929080963e-02
    z[4,3,4]  R1449     -4.3037894368171692e-01
    z[4,3,4]  R1450     2.9538854956626892e-01
    z[4,3,4]  R1451     2.4446974694728851e-01
    z[4,3,4]  R1452     -1.2033727020025253e-01
    z[4,3,4]  R1453     1.5191417932510376e-01
    z[4,3,4]  R1454     7.2274312376976013e-02
    z[4,3,4]  R1455     -3.6287853121757507e-01
    z[4,3,4]  R1456     1.5929432213306427e-01
    z[4,3,4]  R1457     -3.2231506705284119e-01
    z[4,3,4]  R1458     3.0326032638549805e-01
    z[4,3,4]  R1459     8.3895117044448853e-02
    z[4,3,4]  R1460     -1.7281009256839752e-01
    z[4,3,4]  R1461     4.8168513923883438e-02
    z[4,3,4]  R1462     -3.4734839200973511e-01
    z[4,3,4]  R1463     1.6019767522811890e-01
    z[4,3,4]  R1464     -2.4893178045749664e-01
    z[4,3,4]  R1465     4.4497553259134293e-02
    z[4,3,4]  R1466     5.3775101900100708e-01
    z[4,3,4]  R1467     1.5182322263717651e-01
    z[4,3,4]  R1468     1.5464043617248535e-01
    z[4,3,4]  R1469     3.2749116420745850e-01
    z[4,3,4]  R1470     4.8573720455169678e-01
    z[4,3,4]  R1471     1.8877701461315155e-01
    z[4,3,4]  R1472     4.0514644980430603e-01
    z[4,3,4]  R1473     4.0021431446075439e-01
    z[4,3,4]  R1474     -9.5006980001926422e-02
    z[4,3,4]  R1475     6.3432060182094574e-02
    z[4,3,4]  R1476     -0.375505656003952
    z[4,3,4]  R1477     3.2811316847801208e-01
    z[4,3,4]  R1478     -1.7451224848628044e-03
    z[4,3,4]  R1479     3.4370237588882446e-01
    z[4,3,4]  R1480     -6.6038645803928375e-02
    z[4,3,4]  R1481     5.0186789035797119e-01
    z[4,3,4]  R1482     -2.7187541127204895e-01
    z[4,3,4]  R1483     -1.4624411240220070e-02
    z[4,3,4]  R1484     -2.2746595740318298e-01
    z[4,3,4]  R1485     1.5908056497573853e-01
    z[4,3,4]  R1486     8.2281278446316719e-03
    z[4,3,4]  R1487     2.4427349865436554e-01
    z[4,3,4]  R1488     9.0380340814590454e-02
    z[4,3,4]  R1489     -2.1852515637874603e-01
    z[4,3,4]  R1490     -1.2365867942571640e-01
    z[4,3,4]  R1491     1.1866585165262222e-01
    z[4,3,4]  R1492     3.2401621341705322e-01
    z[4,3,4]  R1493     1.4881283044815063e-01
    z[4,3,4]  R1494     3.4713208675384521e-01
    z[4,3,4]  R1495     -3.4721145033836365e-01
    z[4,3,4]  R1496     0.181483656167984
    z[4,3,4]  R1497     -3.1620559096336365e-01
    z[4,3,4]  R1498     1.6339996457099915e-01
    z[4,3,4]  R1499     -5.2320018410682678e-02
    z[4,3,4]  R1500     -2.7691149711608887e-01
    z[4,3,4]  R1501     -3.3400258421897888e-01
    z[4,3,4]  R1502     3.0865228176116943e-01
    z[4,3,4]  R1503     2.8320398926734924e-01
    z[4,3,4]  R1504     2.0661781728267670e-01
    z[4,3,4]  R1505     -1.7275722324848175e-01
    z[4,3,4]  R1506     -6.0702469199895859e-02
    z[4,3,4]  R1507     2.2721193730831146e-01
    z[4,3,4]  R1508     -1.2641771696507931e-02
    z[4,3,4]  R1509     -1.3777954876422882e-01
    z[4,3,4]  R1510     -4.0162146091461182e-01
    z[4,3,4]  R1511     -5.1921719312667847e-01
    z[4,3,4]  R1512     1.8441526591777802e-01
    z[4,3,4]  R1513     0.0917959213256836
    z[4,3,4]  R1514     -2.2069972753524780e-01
    z[4,3,4]  R1515     -2.4616606533527374e-01
    z[4,3,4]  R1516     4.3175943195819855e-02
    z[4,3,4]  R1517     -2.7231946587562561e-01
    z[4,3,4]  R1518     1.4991672337055206e-01
    z[4,3,4]  R1519     7.3038570582866669e-02
    z[4,3,4]  R1520     1.2004748731851578e-01
    z[4,3,4]  R1521     -1.6610343754291534e-01
    z[4,3,4]  R1522     7.4635609984397888e-02
    z[4,3,4]  R1523     -3.2716533541679382e-01
    z[4,3,4]  R1524     -5.2616512775421143e-01
    z[4,3,4]  R1525     -5.2414391189813614e-02
    z[4,3,4]  R1526     7.6712578535079956e-01
    z[4,3,4]  R1527     7.2057497501373291e-01
    z[4,3,4]  R1528     -2.1359895169734955e-01
    z[4,3,4]  R1529     2.2223877906799316e-01
    z[4,3,4]  R1530     -0.164543017745018
    z[4,3,4]  R1531     -3.8728281855583191e-01
    z[4,3,4]  R1532     3.3666431903839111e-01
    z[4,3,4]  R1533     -3.3305177092552185e-01
    z[4,3,4]  R1534     7.8389182686805725e-02
    z[4,3,4]  R1535     4.9128594994544983e-01
    z[4,3,4]  R1536     5.0390070676803589e-01
    z[4,3,4]  R1537     -2.4160590767860413e-01
    z[4,3,4]  R1538     3.5600054264068604e-01
    z[4,3,4]  R1539     3.9648368954658508e-02
    z[4,3,4]  R1540     1.3042362034320831e-01
    z[4,3,4]  R1541     -3.2231798768043518e-01
    z[4,3,4]  R1542     3.4890845417976379e-01
    z[4,3,4]  R1543     5.7207494974136353e-01
    z[4,3,4]  R1544     4.8841181397438049e-01
    z[4,3,4]  R1545     0.535327136516571
    z[4,3,4]  R1546     -0.0871153250336647
    z[4,3,4]  R1547     -3.4129226207733154e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1444     -1
    z[4,3,5]  R1445     1
    z[4,3,5]  R1448     6.3424748368561268e-03
    z[4,3,5]  R1449     2.8956970572471619e-01
    z[4,3,5]  R1450     2.3998151719570160e-01
    z[4,3,5]  R1451     2.4932898581027985e-01
    z[4,3,5]  R1452     -4.3083101511001587e-01
    z[4,3,5]  R1453     0.253202348947525
    z[4,3,5]  R1454     1.0113696753978729e-01
    z[4,3,5]  R1455     -2.5225368142127991e-01
    z[4,3,5]  R1456     -4.9402132630348206e-01
    z[4,3,5]  R1457     2.6839631609618664e-03
    z[4,3,5]  R1458     1.1054874956607819e-01
    z[4,3,5]  R1459     1.2872508168220520e-01
    z[4,3,5]  R1460     1.3896699249744415e-01
    z[4,3,5]  R1461     1.1986243724822998e-01
    z[4,3,5]  R1462     3.1845462322235107e-01
    z[4,3,5]  R1463     -3.1852710247039795e-01
    z[4,3,5]  R1464     -1.2174678593873978e-01
    z[4,3,5]  R1465     4.6465528011322021e-01
    z[4,3,5]  R1466     -1.0141479969024658e-01
    z[4,3,5]  R1467     1.4903669059276581e-01
    z[4,3,5]  R1468     1.5225917100906372e-01
    z[4,3,5]  R1469     1.6096018254756927e-01
    z[4,3,5]  R1470     -2.0274797081947327e-01
    z[4,3,5]  R1471     9.3289494514465332e-02
    z[4,3,5]  R1472     1.0635881125926971e-01
    z[4,3,5]  R1473     -3.0697991605848074e-03
    z[4,3,5]  R1474     4.4315528124570847e-02
    z[4,3,5]  R1475     5.9369522333145142e-01
    z[4,3,5]  R1476     8.3816125988960266e-02
    z[4,3,5]  R1477     2.5790938735008240e-01
    z[4,3,5]  R1478     2.0269152522087097e-01
    z[4,3,5]  R1479     -0.318645179271698
    z[4,3,5]  R1480     -1.2177570909261703e-01
    z[4,3,5]  R1481     3.5580408573150635e-01
    z[4,3,5]  R1482     1.9559279084205627e-01
    z[4,3,5]  R1483     -5.3090296685695648e-02
    z[4,3,5]  R1484     7.4570290744304657e-02
    z[4,3,5]  R1485     -3.9866459369659424e-01
    z[4,3,5]  R1486     6.7389182746410370e-02
    z[4,3,5]  R1487     3.8153558969497681e-02
    z[4,3,5]  R1488     5.0841666758060455e-02
    z[4,3,5]  R1489     1.0002262890338898e-02
    z[4,3,5]  R1490     0.109798364341259
    z[4,3,5]  R1491     -4.8818994313478470e-02
    z[4,3,5]  R1492     -3.1974723935127258e-01
    z[4,3,5]  R1493     7.0133045315742493e-02
    z[4,3,5]  R1494     -3.3949542045593262e-01
    z[4,3,5]  R1495     -3.2147404551506042e-01
    z[4,3,5]  R1496     -4.6553176641464233e-01
    z[4,3,5]  R1497     2.0283545553684235e-01
    z[4,3,5]  R1498     -4.1141159832477570e-02
    z[4,3,5]  R1499     -1.1985564604401588e-02
    z[4,3,5]  R1500     1.4819647371768951e-01
    z[4,3,5]  R1501     -1.0341908782720566e-01
    z[4,3,5]  R1502     -1.5589644201099873e-02
    z[4,3,5]  R1503     7.0687723159790039e-01
    z[4,3,5]  R1504     -4.2672500014305115e-02
    z[4,3,5]  R1505     9.3455202877521515e-02
    z[4,3,5]  R1506     -2.4984742701053619e-01
    z[4,3,5]  R1507     2.3103237152099609e-01
    z[4,3,5]  R1508     -1.6044294834136963e-01
    z[4,3,5]  R1509     1.4248742163181305e-01
    z[4,3,5]  R1510     2.3973587155342102e-01
    z[4,3,5]  R1511     -2.4542784690856934e-01
    z[4,3,5]  R1512     4.4444516301155090e-01
    z[4,3,5]  R1513     5.5228674411773682e-01
    z[4,3,5]  R1514     1.3328480720520020e-01
    z[4,3,5]  R1515     -2.2664764523506165e-01
    z[4,3,5]  R1516     1.1630005389451981e-01
    z[4,3,5]  R1517     1.0064236819744110e-01
    z[4,3,5]  R1518     -2.9604652523994446e-01
    z[4,3,5]  R1519     -8.5728786885738373e-02
    z[4,3,5]  R1520     -6.8737751245498657e-01
    z[4,3,5]  R1521     -7.3190432786941528e-01
    z[4,3,5]  R1522     -3.5814478993415833e-01
    z[4,3,5]  R1523     5.8670127391815186e-01
    z[4,3,5]  R1524     4.0954446792602539e-01
    z[4,3,5]  R1525     -2.6134172081947327e-01
    z[4,3,5]  R1526     -0.087669737637043
    z[4,3,5]  R1527     -4.3736183643341064e-01
    z[4,3,5]  R1528     -4.2121067643165588e-01
    z[4,3,5]  R1529     -0.574893593788147
    z[4,3,5]  R1530     -5.1622176170349121e-01
    z[4,3,5]  R1531     3.9533430337905884e-01
    z[4,3,5]  R1532     4.2813035845756531e-01
    z[4,3,5]  R1533     -4.8270203173160553e-02
    z[4,3,5]  R1534     2.8862106800079346e-01
    z[4,3,5]  R1535     -5.1075357943773270e-02
    z[4,3,5]  R1536     -2.4388688802719116e-01
    z[4,3,5]  R1537     6.0606010258197784e-02
    z[4,3,5]  R1538     -8.9180164039134979e-02
    z[4,3,5]  R1539     -0.0878542810678482
    z[4,3,5]  R1540     1.1024557054042816e-02
    z[4,3,5]  R1541     -2.2485619783401489e-01
    z[4,3,5]  R1542     -2.9883494973182678e-01
    z[4,3,5]  R1543     2.6258125901222229e-01
    z[4,3,5]  R1544     1.6365723311901093e-01
    z[4,3,5]  R1545     7.3313899338245392e-02
    z[4,3,5]  R1546     -1.2089667469263077e-01
    z[4,3,5]  R1547     -1.2820911407470703e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1446     -1
    z[4,3,6]  R1447     1
    z[4,3,6]  R1448     -3.4755849838256836e-01
    z[4,3,6]  R1449     1.5080761909484863e-01
    z[4,3,6]  R1450     -2.2129465639591217e-01
    z[4,3,6]  R1451     4.7135999798774719e-01
    z[4,3,6]  R1452     2.8967404365539551e-01
    z[4,3,6]  R1453     1.5623587369918823e-01
    z[4,3,6]  R1454     3.0056005716323853e-01
    z[4,3,6]  R1455     1.6511987149715424e-01
    z[4,3,6]  R1456     1.1102846264839172e-01
    z[4,3,6]  R1457     5.3668646141886711e-03
    z[4,3,6]  R1458     1.1176948994398117e-01
    z[4,3,6]  R1459     1.1305092275142670e-01
    z[4,3,6]  R1460     4.4450348615646362e-01
    z[4,3,6]  R1461     -4.2897281050682068e-01
    z[4,3,6]  R1462     -1.9016404449939728e-01
    z[4,3,6]  R1463     -3.6399850249290466e-01
    z[4,3,6]  R1464     -5.1832431554794312e-01
    z[4,3,6]  R1465     -4.5685482025146484e-01
    z[4,3,6]  R1466     7.9845957458019257e-02
    z[4,3,6]  R1467     1.7931368947029114e-01
    z[4,3,6]  R1468     3.4765779972076416e-01
    z[4,3,6]  R1469     -3.6506736278533936e-01
    z[4,3,6]  R1470     -9.8876990377902985e-02
    z[4,3,6]  R1471     -7.5220972299575806e-01
    z[4,3,6]  R1472     -2.4946087598800659e-01
    z[4,3,6]  R1473     -4.7301241755485535e-01
    z[4,3,6]  R1474     -7.1854597330093384e-01
    z[4,3,6]  R1475     -4.5263972878456116e-01
    z[4,3,6]  R1476     -2.1199119091033936e-01
    z[4,3,6]  R1477     -5.4631048440933228e-01
    z[4,3,6]  R1478     3.9625599980354309e-01
    z[4,3,6]  R1479     2.5869068503379822e-01
    z[4,3,6]  R1480     -0.459351122379303
    z[4,3,6]  R1481     -3.2972556352615356e-01
    z[4,3,6]  R1482     -4.8167926073074341e-01
    z[4,3,6]  R1483     -2.6300454139709473e-01
    z[4,3,6]  R1484     -5.5979293584823608e-01
    z[4,3,6]  R1485     1.9547837972640991e-01
    z[4,3,6]  R1486     -5.1672633737325668e-02
    z[4,3,6]  R1487     -2.5184908509254456e-01
    z[4,3,6]  R1488     -4.9857613444328308e-01
    z[4,3,6]  R1489     -1.8820254504680634e-01
    z[4,3,6]  R1490     -1.9410468637943268e-01
    z[4,3,6]  R1491     -2.8042781352996826e-01
    z[4,3,6]  R1492     -4.2756326496601105e-02
    z[4,3,6]  R1493     2.1045985817909241e-01
    z[4,3,6]  R1494     3.6888951063156128e-01
    z[4,3,6]  R1495     6.0197249054908752e-02
    z[4,3,6]  R1496     2.4023090302944183e-01
    z[4,3,6]  R1497     7.8073084354400635e-02
    z[4,3,6]  R1498     -4.8421375453472137e-02
    z[4,3,6]  R1499     -1.0789953172206879e-01
    z[4,3,6]  R1500     3.2823103666305542e-01
    z[4,3,6]  R1501     1.5453889966011047e-01
    z[4,3,6]  R1502     1.8215131759643555e-01
    z[4,3,6]  R1503     -9.3076303601264954e-03
    z[4,3,6]  R1504     1.8209001421928406e-01
    z[4,3,6]  R1505     -1.2016330659389496e-01
    z[4,3,6]  R1506     8.1099696457386017e-02
    z[4,3,6]  R1507     -1.9036976993083954e-01
    z[4,3,6]  R1508     3.7223890423774719e-01
    z[4,3,6]  R1509     9.8171653226017952e-03
    z[4,3,6]  R1510     -4.3109733611345291e-02
    z[4,3,6]  R1511     -2.2044392302632332e-02
    z[4,3,6]  R1512     -0.0145966662093997
    z[4,3,6]  R1513     2.6133781671524048e-01
    z[4,3,6]  R1514     -1.3080660998821259e-01
    z[4,3,6]  R1515     -2.1050852537155151e-01
    z[4,3,6]  R1516     -3.3424910902976990e-01
    z[4,3,6]  R1517     -5.7147359848022461e-01
    z[4,3,6]  R1518     3.5175263881683350e-01
    z[4,3,6]  R1519     -5.1904983818531036e-02
    z[4,3,6]  R1520     0.488119512796402
    z[4,3,6]  R1521     -1.0014699399471283e-01
    z[4,3,6]  R1522     -2.0374302566051483e-01
    z[4,3,6]  R1523     -8.9272432029247284e-02
    z[4,3,6]  R1524     -2.2940912842750549e-01
    z[4,3,6]  R1525     -5.7690918445587158e-01
    z[4,3,6]  R1526     -2.2818987071514130e-01
    z[4,3,6]  R1527     1.9642080366611481e-01
    z[4,3,6]  R1528     3.4517055749893188e-01
    z[4,3,6]  R1529     2.0465636253356934e-01
    z[4,3,6]  R1530     -1.7046001553535461e-01
    z[4,3,6]  R1531     -3.1872513890266418e-01
    z[4,3,6]  R1532     -5.1207724958658218e-02
    z[4,3,6]  R1533     -3.2695299386978149e-01
    z[4,3,6]  R1534     2.2473935782909393e-01
    z[4,3,6]  R1535     -1.7372079193592072e-01
    z[4,3,6]  R1536     8.6256787180900574e-02
    z[4,3,6]  R1537     -3.9381444454193115e-02
    z[4,3,6]  R1538     7.6236926019191742e-02
    z[4,3,6]  R1539     -2.3633965849876404e-01
    z[4,3,6]  R1540     3.9987966418266296e-01
    z[4,3,6]  R1541     -1.7006626725196838e-01
    z[4,3,6]  R1542     -3.1170496344566345e-01
    z[4,3,6]  R1543     -3.5321542620658875e-01
    z[4,3,6]  R1544     -2.2743065655231476e-01
    z[4,3,6]  R1545     1.2947093928232789e-03
    z[4,3,6]  R1546     2.2358534857630730e-02
    z[4,3,6]  R1547     -2.0223094522953033e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1612     -1
    z[4,5,0]  R1613     1
    z[4,5,0]  R1626     1.1587698757648468e-01
    z[4,5,0]  R1627     3.8701277226209641e-02
    z[4,5,0]  R1628     -9.7453221678733826e-03
    z[4,5,0]  R1629     1.9839751720428467e-01
    z[4,5,0]  R1630     -5.3450185805559158e-02
    z[4,5,0]  R1631     -4.1370356082916260e-01
    z[4,5,0]  R1632     5.1985946483910084e-03
    z[4,5,0]  R1633     6.3221298158168793e-02
    z[4,5,0]  R1634     1.8728289008140564e-01
    z[4,5,0]  R1635     -1.7933090031147003e-01
    z[4,5,0]  R1636     -2.3720602691173553e-01
    z[4,5,0]  R1637     1.1222624778747559e-01
    z[4,5,0]  R1638     -0.077292300760746
    z[4,5,0]  R1639     2.3319798707962036e-01
    z[4,5,0]  R1640     1.2503399921115488e-04
    z[4,5,0]  R1641     1.3410587608814240e-01
    z[4,5,0]  R1642     3.0718800425529480e-01
    z[4,5,0]  R1643     -1.1665239185094833e-01
    z[4,5,0]  R1644     8.6510226130485535e-02
    z[4,5,0]  R1645     -8.5522763431072235e-02
    z[4,5,0]  R1646     -3.8181382417678833e-01
    z[4,5,0]  R1647     -3.1299063563346863e-01
    z[4,5,0]  R1648     -2.2579859197139740e-01
    z[4,5,0]  R1649     5.1869653165340424e-02
    z[4,5,0]  R1650     -3.9654752612113953e-01
    z[4,5,0]  R1651     -6.8331561982631683e-02
    z[4,5,0]  R1652     1.4130171388387680e-02
    z[4,5,0]  R1653     -0.374836266040802
    z[4,5,0]  R1654     -5.9481244534254074e-03
    z[4,5,0]  R1655     -3.9449077844619751e-01
    z[4,5,0]  R1656     -3.5857826471328735e-01
    z[4,5,0]  R1657     8.1744618713855743e-02
    z[4,5,0]  R1658     8.8852338492870331e-02
    z[4,5,0]  R1659     -3.2260206341743469e-01
    z[4,5,0]  R1660     1.7839437723159790e-01
    z[4,5,0]  R1661     -0.574947714805603
    z[4,5,0]  R1662     3.4821593761444092e-01
    z[4,5,0]  R1663     -7.2644799947738647e-02
    z[4,5,0]  R1664     7.4504047632217407e-01
    z[4,5,0]  R1665     1.6636660695075989e-01
    z[4,5,0]  R1666     3.4775093197822571e-02
    z[4,5,0]  R1667     -1.7973975837230682e-01
    z[4,5,0]  R1668     -2.3917232453823090e-01
    z[4,5,0]  R1669     -1.4337505400180817e-01
    z[4,5,0]  R1670     -3.0383253097534180e-01
    z[4,5,0]  R1671     -3.5776841640472412e-01
    z[4,5,0]  R1672     2.0762230455875397e-01
    z[4,5,0]  R1673     5.1076811552047729e-01
    z[4,5,0]  R1674     1.9453017413616180e-01
    z[4,5,0]  R1675     -2.9797112941741943e-01
    z[4,5,0]  R1676     2.2690695524215698e-01
    z[4,5,0]  R1677     3.0239224433898926e-01
    z[4,5,0]  R1678     2.1081301569938660e-01
    z[4,5,0]  R1679     2.1362684667110443e-01
    z[4,5,0]  R1680     4.0902960300445557e-01
    z[4,5,0]  R1681     1.0302189737558365e-01
    z[4,5,0]  R1682     -3.3271512389183044e-01
    z[4,5,0]  R1683     -1.4525122940540314e-01
    z[4,5,0]  R1684     -9.3036937713623047e-01
    z[4,5,0]  R1685     -8.6827713251113892e-01
    z[4,5,0]  R1686     -2.0814840495586395e-01
    z[4,5,0]  R1687     1.1761409789323807e-01
    z[4,5,0]  R1688     -6.0667127370834351e-02
    z[4,5,0]  R1689     -1.8856215476989746e-01
    z[4,5,0]  R1690     -4.0643563866615295e-01
    z[4,5,0]  R1691     -6.8354494869709015e-03
    z[4,5,0]  R1692     -1.9492869079113007e-01
    z[4,5,0]  R1693     1.3939078897237778e-02
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1614     -1
    z[4,5,1]  R1615     1
    z[4,5,1]  R1626     5.1945990324020386e-01
    z[4,5,1]  R1627     4.3598660826683044e-01
    z[4,5,1]  R1628     2.7470833063125610e-01
    z[4,5,1]  R1629     2.9422539472579956e-01
    z[4,5,1]  R1630     5.3513032197952271e-01
    z[4,5,1]  R1631     5.2059924602508545e-01
    z[4,5,1]  R1632     8.5285681486129761e-01
    z[4,5,1]  R1633     8.5074758529663086e-01
    z[4,5,1]  R1634     8.1643897294998169e-01
    z[4,5,1]  R1635     7.6616877317428589e-01
    z[4,5,1]  R1636     -8.7570571899414062e-01
    z[4,5,1]  R1637     -0.948878824710846
    z[4,5,1]  R1638     -8.3460867404937744e-01
    z[4,5,1]  R1639     -0.800197958946228
    z[4,5,1]  R1640     -8.3948266506195068e-01
    z[4,5,1]  R1641     -7.5415897369384766e-01
    z[4,5,1]  R1642     -7.2628623247146606e-01
    z[4,5,1]  R1643     -7.4365448951721191e-01
    z[4,5,1]  R1644     -7.2204142808914185e-01
    z[4,5,1]  R1645     -4.2506304383277893e-01
    z[4,5,1]  R1646     0.69159334897995
    z[4,5,1]  R1647     0.718513011932373
    z[4,5,1]  R1648     5.8092606067657471e-01
    z[4,5,1]  R1649     6.1590307950973511e-01
    z[4,5,1]  R1650     6.2844419479370117e-01
    z[4,5,1]  R1651     5.1614028215408325e-01
    z[4,5,1]  R1652     5.3301292657852173e-01
    z[4,5,1]  R1653     5.4256129264831543e-01
    z[4,5,1]  R1654     4.7060114145278931e-01
    z[4,5,1]  R1655     5.1736724376678467e-01
    z[4,5,1]  R1656     8.1953680515289307e-01
    z[4,5,1]  R1657     7.3447358608245850e-01
    z[4,5,1]  R1658     6.4253956079483032e-01
    z[4,5,1]  R1659     6.2869960069656372e-01
    z[4,5,1]  R1660     6.3185513019561768e-01
    z[4,5,1]  R1661     7.6218783855438232e-01
    z[4,5,1]  R1662     6.7630988359451294e-01
    z[4,5,1]  R1663     -0.663023829460144
    z[4,5,1]  R1664     -1.7637096345424652e-01
    z[4,5,1]  R1665     -1.2277159839868546e-01
    z[4,5,1]  R1666     8.4047597646713257e-01
    z[4,5,1]  R1667     8.0599933862686157e-01
    z[4,5,1]  R1668     0.778223991394043
    z[4,5,1]  R1669     9.6594981849193573e-02
    z[4,5,1]  R1670     2.2723279893398285e-02
    z[4,5,1]  R1671     -2.1410322189331055e-01
    z[4,5,1]  R1672     1.2241020798683167e-02
    z[4,5,1]  R1673     -5.4259186983108521e-01
    z[4,5,1]  R1674     -0.0758294016122818
    z[4,5,1]  R1675     1.6085606068372726e-02
    z[4,5,1]  R1676     2.4850067496299744e-01
    z[4,5,1]  R1677     3.2145267724990845e-01
    z[4,5,1]  R1678     -5.1525926589965820e-01
    z[4,5,1]  R1679     -7.5340814888477325e-02
    z[4,5,1]  R1680     3.3706137537956238e-01
    z[4,5,1]  R1681     -5.8345835655927658e-02
    z[4,5,1]  R1682     1.7535819113254547e-01
    z[4,5,1]  R1683     2.6711516082286835e-02
    z[4,5,1]  R1684     -2.4517327547073364e-01
    z[4,5,1]  R1685     -2.8643208742141724e-01
    z[4,5,1]  R1686     7.9304700193461031e-05
    z[4,5,1]  R1687     -4.7462385147809982e-02
    z[4,5,1]  R1688     5.7649511843919754e-02
    z[4,5,1]  R1689     -2.1119147539138794e-01
    z[4,5,1]  R1690     -8.1869667768478394e-01
    z[4,5,1]  R1691     -8.4677189588546753e-01
    z[4,5,1]  R1692     -8.3407163619995117e-01
    z[4,5,1]  R1693     -8.1519466638565063e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1616     -1
    z[4,5,2]  R1617     1
    z[4,5,2]  R1626     -2.3583377897739410e-01
    z[4,5,2]  R1627     -1.5753577649593353e-01
    z[4,5,2]  R1628     2.2737956047058105e-01
    z[4,5,2]  R1629     -3.5226836800575256e-02
    z[4,5,2]  R1630     -1.5581825375556946e-01
    z[4,5,2]  R1631     -2.1102492511272430e-01
    z[4,5,2]  R1632     9.6422888338565826e-02
    z[4,5,2]  R1633     -0.194339781999588
    z[4,5,2]  R1634     4.0524479001760483e-02
    z[4,5,2]  R1635     2.1498893201351166e-01
    z[4,5,2]  R1636     -2.4073255062103271e-01
    z[4,5,2]  R1637     1.7117829620838165e-01
    z[4,5,2]  R1638     -1.0943584889173508e-01
    z[4,5,2]  R1639     3.2340955734252930e-01
    z[4,5,2]  R1640     1.6987487673759460e-01
    z[4,5,2]  R1641     -3.1586271524429321e-01
    z[4,5,2]  R1642     -8.7423577904701233e-02
    z[4,5,2]  R1643     5.4338318295776844e-04
    z[4,5,2]  R1644     4.0635776519775391e-01
    z[4,5,2]  R1645     4.1774931550025940e-01
    z[4,5,2]  R1646     3.8258284330368042e-01
    z[4,5,2]  R1647     3.4474813938140869e-01
    z[4,5,2]  R1648     -5.6983286142349243e-01
    z[4,5,2]  R1649     -8.5677266120910645e-02
    z[4,5,2]  R1650     -4.5456889271736145e-01
    z[4,5,2]  R1651     -5.4782372713088989e-01
    z[4,5,2]  R1652     -4.2600205540657043e-01
    z[4,5,2]  R1653     -4.5178778469562531e-02
    z[4,5,2]  R1654     -7.2194474935531616e-01
    z[4,5,2]  R1655     -8.4986887872219086e-02
    z[4,5,2]  R1656     -0.00379387685097754
    z[4,5,2]  R1657     -2.7375376224517822e-01
    z[4,5,2]  R1658     -5.8329051733016968e-01
    z[4,5,2]  R1659     -1.1103716678917408e-02
    z[4,5,2]  R1660     -3.1555393338203430e-01
    z[4,5,2]  R1661     1.2540809810161591e-01
    z[4,5,2]  R1662     6.9144517183303833e-02
    z[4,5,2]  R1663     1.1344595253467560e-01
    z[4,5,2]  R1664     -5.4198831319808960e-01
    z[4,5,2]  R1665     6.1031565070152283e-02
    z[4,5,2]  R1666     -1.6788861155509949e-01
    z[4,5,2]  R1667     -4.6955174207687378e-01
    z[4,5,2]  R1668     4.6259054541587830e-01
    z[4,5,2]  R1669     8.8542439043521881e-02
    z[4,5,2]  R1670     2.9090738296508789e-01
    z[4,5,2]  R1671     -1.9310995936393738e-01
    z[4,5,2]  R1672     2.7238744497299194e-01
    z[4,5,2]  R1673     0.452673077583313
    z[4,5,2]  R1674     1.2094288133084774e-02
    z[4,5,2]  R1675     -1.0561206936836243e-01
    z[4,5,2]  R1676     4.2421588301658630e-01
    z[4,5,2]  R1677     -4.7205638885498047e-01
    z[4,5,2]  R1678     -1.2448070943355560e-01
    z[4,5,2]  R1679     -1.4258812367916107e-01
    z[4,5,2]  R1680     -3.1568869948387146e-01
    z[4,5,2]  R1681     2.6243191957473755e-01
    z[4,5,2]  R1682     1.0560742020606995e-01
    z[4,5,2]  R1683     7.3650372028350830e-01
    z[4,5,2]  R1684     -1.1441224254667759e-02
    z[4,5,2]  R1685     -1.9136193394660950e-01
    z[4,5,2]  R1686     -1.8365412950515747e-01
    z[4,5,2]  R1687     2.9805976152420044e-01
    z[4,5,2]  R1688     4.9986642599105835e-01
    z[4,5,2]  R1689     1.8580672144889832e-01
    z[4,5,2]  R1690     -6.1617337167263031e-02
    z[4,5,2]  R1691     9.2227347195148468e-02
    z[4,5,2]  R1692     1.5809503197669983e-01
    z[4,5,2]  R1693     -1.2670049071311951e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1618     -1
    z[4,5,3]  R1619     1
    z[4,5,3]  R1626     0.730543851852417
    z[4,5,3]  R1627     7.0127081871032715e-01
    z[4,5,3]  R1628     8.2396721839904785e-01
    z[4,5,3]  R1629     0.727130115032196
    z[4,5,3]  R1630     6.3442248106002808e-01
    z[4,5,3]  R1631     0.633794367313385
    z[4,5,3]  R1632     -3.9689075946807861e-01
    z[4,5,3]  R1633     1.0902449488639832e-01
    z[4,5,3]  R1634     1.2227544933557510e-01
    z[4,5,3]  R1635     4.8029428720474243e-01
    z[4,5,3]  R1636     -4.7331269830465317e-02
    z[4,5,3]  R1637     -1.4609293639659882e-01
    z[4,5,3]  R1638     -1.9677279889583588e-01
    z[4,5,3]  R1639     1.7926159780472517e-03
    z[4,5,3]  R1640     9.0469516813755035e-02
    z[4,5,3]  R1641     2.3210534453392029e-01
    z[4,5,3]  R1642     1.5827704966068268e-01
    z[4,5,3]  R1643     -8.2274377346038818e-02
    z[4,5,3]  R1644     -1.4462047256529331e-02
    z[4,5,3]  R1645     -7.4838304519653320e-01
    z[4,5,3]  R1646     2.4816274642944336e-01
    z[4,5,3]  R1647     2.2176474332809448e-02
    z[4,5,3]  R1648     -2.5665040593594313e-03
    z[4,5,3]  R1649     2.1752910688519478e-02
    z[4,5,3]  R1650     5.9062212705612183e-02
    z[4,5,3]  R1651     -2.1189042925834656e-01
    z[4,5,3]  R1652     0.0831940770149231
    z[4,5,3]  R1653     -4.1274357587099075e-02
    z[4,5,3]  R1654     -2.5362381339073181e-01
    z[4,5,3]  R1655     3.1121477484703064e-01
    z[4,5,3]  R1656     -4.0754970163106918e-02
    z[4,5,3]  R1657     -3.0387207865715027e-01
    z[4,5,3]  R1658     -9.3949548900127411e-02
    z[4,5,3]  R1659     -1.1556169390678406e-01
    z[4,5,3]  R1660     -3.5379728674888611e-01
    z[4,5,3]  R1661     -2.3951049894094467e-02
    z[4,5,3]  R1662     -2.1424324810504913e-01
    z[4,5,3]  R1663     5.6550878286361694e-01
    z[4,5,3]  R1664     -3.3582359552383423e-01
    z[4,5,3]  R1665     -9.1047853231430054e-01
    z[4,5,3]  R1666     -6.9805346429347992e-02
    z[4,5,3]  R1667     1.1960940808057785e-01
    z[4,5,3]  R1668     -2.4114339053630829e-01
    z[4,5,3]  R1669     -9.3121886253356934e-01
    z[4,5,3]  R1670     -7.8325563669204712e-01
    z[4,5,3]  R1671     -0.847061276435852
    z[4,5,3]  R1672     -7.1464049816131592e-01
    z[4,5,3]  R1673     1.1077910661697388e-01
    z[4,5,3]  R1674     -8.0553990602493286e-01
    z[4,5,3]  R1675     -8.6751186847686768e-01
    z[4,5,3]  R1676     -4.9563711881637573e-01
    z[4,5,3]  R1677     4.2500126361846924e-01
    z[4,5,3]  R1678     -4.8035749793052673e-01
    z[4,5,3]  R1679     -3.9550641179084778e-01
    z[4,5,3]  R1680     4.9071967601776123e-01
    z[4,5,3]  R1681     8.5449254512786865e-01
    z[4,5,3]  R1682     5.2628409862518311e-01
    z[4,5,3]  R1683     5.7510995864868164e-01
    z[4,5,3]  R1684     -0.0466766357421875
    z[4,5,3]  R1685     -4.6105778892524540e-04
    z[4,5,3]  R1686     7.8190630674362183e-01
    z[4,5,3]  R1687     7.6712244749069214e-01
    z[4,5,3]  R1688     8.2034456729888916e-01
    z[4,5,3]  R1689     8.3577936887741089e-01
    z[4,5,3]  R1690     1.5298387408256531e-01
    z[4,5,3]  R1691     2.3793998360633850e-01
    z[4,5,3]  R1692     6.0946464538574219e-02
    z[4,5,3]  R1693     1.4294156432151794e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1620     -1
    z[4,5,4]  R1621     1
    z[4,5,4]  R1626     -8.1146813929080963e-02
    z[4,5,4]  R1627     -4.3037894368171692e-01
    z[4,5,4]  R1628     2.9538854956626892e-01
    z[4,5,4]  R1629     2.4446974694728851e-01
    z[4,5,4]  R1630     -1.2033727020025253e-01
    z[4,5,4]  R1631     1.5191417932510376e-01
    z[4,5,4]  R1632     7.2274312376976013e-02
    z[4,5,4]  R1633     -3.6287853121757507e-01
    z[4,5,4]  R1634     1.5929432213306427e-01
    z[4,5,4]  R1635     -3.2231506705284119e-01
    z[4,5,4]  R1636     3.0326032638549805e-01
    z[4,5,4]  R1637     8.3895117044448853e-02
    z[4,5,4]  R1638     -1.7281009256839752e-01
    z[4,5,4]  R1639     4.8168513923883438e-02
    z[4,5,4]  R1640     -3.4734839200973511e-01
    z[4,5,4]  R1641     1.6019767522811890e-01
    z[4,5,4]  R1642     -2.4893178045749664e-01
    z[4,5,4]  R1643     4.4497553259134293e-02
    z[4,5,4]  R1644     5.3775101900100708e-01
    z[4,5,4]  R1645     1.5182322263717651e-01
    z[4,5,4]  R1646     1.5464043617248535e-01
    z[4,5,4]  R1647     3.2749116420745850e-01
    z[4,5,4]  R1648     4.8573720455169678e-01
    z[4,5,4]  R1649     1.8877701461315155e-01
    z[4,5,4]  R1650     4.0514644980430603e-01
    z[4,5,4]  R1651     4.0021431446075439e-01
    z[4,5,4]  R1652     -9.5006980001926422e-02
    z[4,5,4]  R1653     6.3432060182094574e-02
    z[4,5,4]  R1654     -0.375505656003952
    z[4,5,4]  R1655     3.2811316847801208e-01
    z[4,5,4]  R1656     -1.7451224848628044e-03
    z[4,5,4]  R1657     3.4370237588882446e-01
    z[4,5,4]  R1658     -6.6038645803928375e-02
    z[4,5,4]  R1659     5.0186789035797119e-01
    z[4,5,4]  R1660     -2.7187541127204895e-01
    z[4,5,4]  R1661     -1.4624411240220070e-02
    z[4,5,4]  R1662     -2.2746595740318298e-01
    z[4,5,4]  R1663     1.5908056497573853e-01
    z[4,5,4]  R1664     8.2281278446316719e-03
    z[4,5,4]  R1665     2.4427349865436554e-01
    z[4,5,4]  R1666     9.0380340814590454e-02
    z[4,5,4]  R1667     -2.1852515637874603e-01
    z[4,5,4]  R1668     -1.2365867942571640e-01
    z[4,5,4]  R1669     1.1866585165262222e-01
    z[4,5,4]  R1670     3.2401621341705322e-01
    z[4,5,4]  R1671     1.4881283044815063e-01
    z[4,5,4]  R1672     3.4713208675384521e-01
    z[4,5,4]  R1673     -3.4721145033836365e-01
    z[4,5,4]  R1674     0.181483656167984
    z[4,5,4]  R1675     -3.1620559096336365e-01
    z[4,5,4]  R1676     1.9341827137395740e-03
    z[4,5,4]  R1677     -3.8472640514373779e-01
    z[4,5,4]  R1678     6.3935375213623047e-01
    z[4,5,4]  R1679     -2.3438097536563873e-01
    z[4,5,4]  R1680     1.7354603111743927e-01
    z[4,5,4]  R1681     -3.6505248397588730e-02
    z[4,5,4]  R1682     -2.9357659816741943e-01
    z[4,5,4]  R1683     -2.3593001067638397e-01
    z[4,5,4]  R1684     -2.1491923928260803e-01
    z[4,5,4]  R1685     1.8646484613418579e-01
    z[4,5,4]  R1686     4.0940508246421814e-01
    z[4,5,4]  R1687     2.5069794058799744e-01
    z[4,5,4]  R1688     1.8114280700683594e-01
    z[4,5,4]  R1689     4.1229769587516785e-01
    z[4,5,4]  R1690     -3.1224167346954346e-01
    z[4,5,4]  R1691     -4.1876533627510071e-01
    z[4,5,4]  R1692     -4.8623114824295044e-01
    z[4,5,4]  R1693     -4.5903232693672180e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1622     -1
    z[4,5,5]  R1623     1
    z[4,5,5]  R1626     6.3424748368561268e-03
    z[4,5,5]  R1627     2.8956970572471619e-01
    z[4,5,5]  R1628     2.3998151719570160e-01
    z[4,5,5]  R1629     2.4932898581027985e-01
    z[4,5,5]  R1630     -4.3083101511001587e-01
    z[4,5,5]  R1631     0.253202348947525
    z[4,5,5]  R1632     1.0113696753978729e-01
    z[4,5,5]  R1633     -2.5225368142127991e-01
    z[4,5,5]  R1634     -4.9402132630348206e-01
    z[4,5,5]  R1635     2.6839631609618664e-03
    z[4,5,5]  R1636     1.1054874956607819e-01
    z[4,5,5]  R1637     1.2872508168220520e-01
    z[4,5,5]  R1638     1.3896699249744415e-01
    z[4,5,5]  R1639     1.1986243724822998e-01
    z[4,5,5]  R1640     3.1845462322235107e-01
    z[4,5,5]  R1641     -3.1852710247039795e-01
    z[4,5,5]  R1642     -1.2174678593873978e-01
    z[4,5,5]  R1643     4.6465528011322021e-01
    z[4,5,5]  R1644     -1.0141479969024658e-01
    z[4,5,5]  R1645     1.4903669059276581e-01
    z[4,5,5]  R1646     1.5225917100906372e-01
    z[4,5,5]  R1647     1.6096018254756927e-01
    z[4,5,5]  R1648     -2.0274797081947327e-01
    z[4,5,5]  R1649     9.3289494514465332e-02
    z[4,5,5]  R1650     1.0635881125926971e-01
    z[4,5,5]  R1651     -3.0697991605848074e-03
    z[4,5,5]  R1652     4.4315528124570847e-02
    z[4,5,5]  R1653     5.9369522333145142e-01
    z[4,5,5]  R1654     8.3816125988960266e-02
    z[4,5,5]  R1655     2.5790938735008240e-01
    z[4,5,5]  R1656     2.0269152522087097e-01
    z[4,5,5]  R1657     -0.318645179271698
    z[4,5,5]  R1658     -1.2177570909261703e-01
    z[4,5,5]  R1659     3.5580408573150635e-01
    z[4,5,5]  R1660     1.9559279084205627e-01
    z[4,5,5]  R1661     -5.3090296685695648e-02
    z[4,5,5]  R1662     7.4570290744304657e-02
    z[4,5,5]  R1663     -3.9866459369659424e-01
    z[4,5,5]  R1664     6.7389182746410370e-02
    z[4,5,5]  R1665     3.8153558969497681e-02
    z[4,5,5]  R1666     5.0841666758060455e-02
    z[4,5,5]  R1667     1.0002262890338898e-02
    z[4,5,5]  R1668     0.109798364341259
    z[4,5,5]  R1669     -4.8818994313478470e-02
    z[4,5,5]  R1670     -3.1974723935127258e-01
    z[4,5,5]  R1671     7.0133045315742493e-02
    z[4,5,5]  R1672     -3.3949542045593262e-01
    z[4,5,5]  R1673     -3.2147404551506042e-01
    z[4,5,5]  R1674     -4.6553176641464233e-01
    z[4,5,5]  R1675     2.0283545553684235e-01
    z[4,5,5]  R1676     -6.4516419172286987e-01
    z[4,5,5]  R1677     4.8268601298332214e-01
    z[4,5,5]  R1678     1.6855491697788239e-01
    z[4,5,5]  R1679     2.1732540428638458e-01
    z[4,5,5]  R1680     -0.458787202835083
    z[4,5,5]  R1681     -3.8926395773887634e-01
    z[4,5,5]  R1682     -4.3972459435462952e-01
    z[4,5,5]  R1683     6.8293526768684387e-02
    z[4,5,5]  R1684     1.4766024053096771e-01
    z[4,5,5]  R1685     -3.0437666177749634e-01
    z[4,5,5]  R1686     -3.6676400899887085e-01
    z[4,5,5]  R1687     -1.2268547713756561e-01
    z[4,5,5]  R1688     -1.8348152935504913e-01
    z[4,5,5]  R1689     8.8123209774494171e-02
    z[4,5,5]  R1690     -1.1496735364198685e-01
    z[4,5,5]  R1691     -1.8946514464914799e-03
    z[4,5,5]  R1692     -6.5354225225746632e-03
    z[4,5,5]  R1693     -2.9177182912826538e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1624     -1
    z[4,5,6]  R1625     1
    z[4,5,6]  R1626     -3.4755849838256836e-01
    z[4,5,6]  R1627     1.5080761909484863e-01
    z[4,5,6]  R1628     -2.2129465639591217e-01
    z[4,5,6]  R1629     4.7135999798774719e-01
    z[4,5,6]  R1630     2.8967404365539551e-01
    z[4,5,6]  R1631     1.5623587369918823e-01
    z[4,5,6]  R1632     3.0056005716323853e-01
    z[4,5,6]  R1633     1.6511987149715424e-01
    z[4,5,6]  R1634     1.1102846264839172e-01
    z[4,5,6]  R1635     5.3668646141886711e-03
    z[4,5,6]  R1636     1.1176948994398117e-01
    z[4,5,6]  R1637     1.1305092275142670e-01
    z[4,5,6]  R1638     4.4450348615646362e-01
    z[4,5,6]  R1639     -4.2897281050682068e-01
    z[4,5,6]  R1640     -1.9016404449939728e-01
    z[4,5,6]  R1641     -3.6399850249290466e-01
    z[4,5,6]  R1642     -5.1832431554794312e-01
    z[4,5,6]  R1643     -4.5685482025146484e-01
    z[4,5,6]  R1644     7.9845957458019257e-02
    z[4,5,6]  R1645     1.7931368947029114e-01
    z[4,5,6]  R1646     3.4765779972076416e-01
    z[4,5,6]  R1647     -3.6506736278533936e-01
    z[4,5,6]  R1648     -9.8876990377902985e-02
    z[4,5,6]  R1649     -7.5220972299575806e-01
    z[4,5,6]  R1650     -2.4946087598800659e-01
    z[4,5,6]  R1651     -4.7301241755485535e-01
    z[4,5,6]  R1652     -7.1854597330093384e-01
    z[4,5,6]  R1653     -4.5263972878456116e-01
    z[4,5,6]  R1654     -2.1199119091033936e-01
    z[4,5,6]  R1655     -5.4631048440933228e-01
    z[4,5,6]  R1656     3.9625599980354309e-01
    z[4,5,6]  R1657     2.5869068503379822e-01
    z[4,5,6]  R1658     -0.459351122379303
    z[4,5,6]  R1659     -3.2972556352615356e-01
    z[4,5,6]  R1660     -4.8167926073074341e-01
    z[4,5,6]  R1661     -2.6300454139709473e-01
    z[4,5,6]  R1662     -5.5979293584823608e-01
    z[4,5,6]  R1663     1.9547837972640991e-01
    z[4,5,6]  R1664     -5.1672633737325668e-02
    z[4,5,6]  R1665     -2.5184908509254456e-01
    z[4,5,6]  R1666     -4.9857613444328308e-01
    z[4,5,6]  R1667     -1.8820254504680634e-01
    z[4,5,6]  R1668     -1.9410468637943268e-01
    z[4,5,6]  R1669     -2.8042781352996826e-01
    z[4,5,6]  R1670     -4.2756326496601105e-02
    z[4,5,6]  R1671     2.1045985817909241e-01
    z[4,5,6]  R1672     3.6888951063156128e-01
    z[4,5,6]  R1673     6.0197249054908752e-02
    z[4,5,6]  R1674     2.4023090302944183e-01
    z[4,5,6]  R1675     7.8073084354400635e-02
    z[4,5,6]  R1676     -2.1190728247165680e-01
    z[4,5,6]  R1677     -1.4409545063972473e-01
    z[4,5,6]  R1678     8.1505045294761658e-02
    z[4,5,6]  R1679     8.1839221715927124e-01
    z[4,5,6]  R1680     3.7150415778160095e-01
    z[4,5,6]  R1681     1.8464881181716919e-01
    z[4,5,6]  R1682     5.3933048248291016e-01
    z[4,5,6]  R1683     -2.1135868132114410e-01
    z[4,5,6]  R1684     -6.3240334391593933e-02
    z[4,5,6]  R1685     4.1932859458029270e-03
    z[4,5,6]  R1686     -9.7157590091228485e-02
    z[4,5,6]  R1687     4.7822231054306030e-01
    z[4,5,6]  R1688     -6.0714911669492722e-02
    z[4,5,6]  R1689     -9.5058217644691467e-02
    z[4,5,6]  R1690     -1.6319499909877777e-01
    z[4,5,6]  R1691     -2.0601308345794678e-01
    z[4,5,6]  R1692     0.0339912548661232
    z[4,5,6]  R1693     -5.4190486669540405e-02
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1694     -1
    z[5,4,0]  R1695     1
    z[5,4,0]  R1708     2.2690695524215698e-01
    z[5,4,0]  R1709     3.0239224433898926e-01
    z[5,4,0]  R1710     2.1081301569938660e-01
    z[5,4,0]  R1711     2.1362684667110443e-01
    z[5,4,0]  R1712     4.0902960300445557e-01
    z[5,4,0]  R1713     1.0302189737558365e-01
    z[5,4,0]  R1714     -3.3271512389183044e-01
    z[5,4,0]  R1715     -1.4525122940540314e-01
    z[5,4,0]  R1716     -9.3036937713623047e-01
    z[5,4,0]  R1717     -8.6827713251113892e-01
    z[5,4,0]  R1718     -2.0814840495586395e-01
    z[5,4,0]  R1719     1.1761409789323807e-01
    z[5,4,0]  R1720     -6.0667127370834351e-02
    z[5,4,0]  R1721     -1.8856215476989746e-01
    z[5,4,0]  R1722     -4.0643563866615295e-01
    z[5,4,0]  R1723     -6.8354494869709015e-03
    z[5,4,0]  R1724     -1.9492869079113007e-01
    z[5,4,0]  R1725     1.3939078897237778e-02
    z[5,4,0]  R1726     1.1587698757648468e-01
    z[5,4,0]  R1727     3.8701277226209641e-02
    z[5,4,0]  R1728     -9.7453221678733826e-03
    z[5,4,0]  R1729     1.9839751720428467e-01
    z[5,4,0]  R1730     -5.3450185805559158e-02
    z[5,4,0]  R1731     -4.1370356082916260e-01
    z[5,4,0]  R1732     5.1985946483910084e-03
    z[5,4,0]  R1733     6.3221298158168793e-02
    z[5,4,0]  R1734     1.8728289008140564e-01
    z[5,4,0]  R1735     -1.7933090031147003e-01
    z[5,4,0]  R1736     -2.3720602691173553e-01
    z[5,4,0]  R1737     1.1222624778747559e-01
    z[5,4,0]  R1738     -0.077292300760746
    z[5,4,0]  R1739     2.3319798707962036e-01
    z[5,4,0]  R1740     1.2503399921115488e-04
    z[5,4,0]  R1741     1.3410587608814240e-01
    z[5,4,0]  R1742     3.0718800425529480e-01
    z[5,4,0]  R1743     -1.1665239185094833e-01
    z[5,4,0]  R1744     8.6510226130485535e-02
    z[5,4,0]  R1745     -8.5522763431072235e-02
    z[5,4,0]  R1746     -3.8181382417678833e-01
    z[5,4,0]  R1747     -3.1299063563346863e-01
    z[5,4,0]  R1748     -2.2579859197139740e-01
    z[5,4,0]  R1749     5.1869653165340424e-02
    z[5,4,0]  R1750     -3.9654752612113953e-01
    z[5,4,0]  R1751     -6.8331561982631683e-02
    z[5,4,0]  R1752     1.4130171388387680e-02
    z[5,4,0]  R1753     -0.374836266040802
    z[5,4,0]  R1754     -5.9481244534254074e-03
    z[5,4,0]  R1755     -3.9449077844619751e-01
    z[5,4,0]  R1756     -3.5857826471328735e-01
    z[5,4,0]  R1757     8.1744618713855743e-02
    z[5,4,0]  R1758     8.8852338492870331e-02
    z[5,4,0]  R1759     -3.2260206341743469e-01
    z[5,4,0]  R1760     1.7839437723159790e-01
    z[5,4,0]  R1761     -0.574947714805603
    z[5,4,0]  R1762     3.4821593761444092e-01
    z[5,4,0]  R1763     -7.2644799947738647e-02
    z[5,4,0]  R1764     7.4504047632217407e-01
    z[5,4,0]  R1765     1.6636660695075989e-01
    z[5,4,0]  R1766     3.4775093197822571e-02
    z[5,4,0]  R1767     -1.7973975837230682e-01
    z[5,4,0]  R1768     -2.3917232453823090e-01
    z[5,4,0]  R1769     -1.4337505400180817e-01
    z[5,4,0]  R1770     -3.0383253097534180e-01
    z[5,4,0]  R1771     -3.5776841640472412e-01
    z[5,4,0]  R1772     2.0762230455875397e-01
    z[5,4,0]  R1773     5.1076811552047729e-01
    z[5,4,0]  R1774     1.9453017413616180e-01
    z[5,4,0]  R1775     -2.9797112941741943e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1696     -1
    z[5,4,1]  R1697     1
    z[5,4,1]  R1708     2.4850067496299744e-01
    z[5,4,1]  R1709     3.2145267724990845e-01
    z[5,4,1]  R1710     -5.1525926589965820e-01
    z[5,4,1]  R1711     -7.5340814888477325e-02
    z[5,4,1]  R1712     3.3706137537956238e-01
    z[5,4,1]  R1713     -5.8345835655927658e-02
    z[5,4,1]  R1714     1.7535819113254547e-01
    z[5,4,1]  R1715     2.6711516082286835e-02
    z[5,4,1]  R1716     -2.4517327547073364e-01
    z[5,4,1]  R1717     -2.8643208742141724e-01
    z[5,4,1]  R1718     7.9304700193461031e-05
    z[5,4,1]  R1719     -4.7462385147809982e-02
    z[5,4,1]  R1720     5.7649511843919754e-02
    z[5,4,1]  R1721     -2.1119147539138794e-01
    z[5,4,1]  R1722     -8.1869667768478394e-01
    z[5,4,1]  R1723     -8.4677189588546753e-01
    z[5,4,1]  R1724     -8.3407163619995117e-01
    z[5,4,1]  R1725     -8.1519466638565063e-01
    z[5,4,1]  R1726     5.1945990324020386e-01
    z[5,4,1]  R1727     4.3598660826683044e-01
    z[5,4,1]  R1728     2.7470833063125610e-01
    z[5,4,1]  R1729     2.9422539472579956e-01
    z[5,4,1]  R1730     5.3513032197952271e-01
    z[5,4,1]  R1731     5.2059924602508545e-01
    z[5,4,1]  R1732     8.5285681486129761e-01
    z[5,4,1]  R1733     8.5074758529663086e-01
    z[5,4,1]  R1734     8.1643897294998169e-01
    z[5,4,1]  R1735     7.6616877317428589e-01
    z[5,4,1]  R1736     -8.7570571899414062e-01
    z[5,4,1]  R1737     -0.948878824710846
    z[5,4,1]  R1738     -8.3460867404937744e-01
    z[5,4,1]  R1739     -0.800197958946228
    z[5,4,1]  R1740     -8.3948266506195068e-01
    z[5,4,1]  R1741     -7.5415897369384766e-01
    z[5,4,1]  R1742     -7.2628623247146606e-01
    z[5,4,1]  R1743     -7.4365448951721191e-01
    z[5,4,1]  R1744     -7.2204142808914185e-01
    z[5,4,1]  R1745     -4.2506304383277893e-01
    z[5,4,1]  R1746     0.69159334897995
    z[5,4,1]  R1747     0.718513011932373
    z[5,4,1]  R1748     5.8092606067657471e-01
    z[5,4,1]  R1749     6.1590307950973511e-01
    z[5,4,1]  R1750     6.2844419479370117e-01
    z[5,4,1]  R1751     5.1614028215408325e-01
    z[5,4,1]  R1752     5.3301292657852173e-01
    z[5,4,1]  R1753     5.4256129264831543e-01
    z[5,4,1]  R1754     4.7060114145278931e-01
    z[5,4,1]  R1755     5.1736724376678467e-01
    z[5,4,1]  R1756     8.1953680515289307e-01
    z[5,4,1]  R1757     7.3447358608245850e-01
    z[5,4,1]  R1758     6.4253956079483032e-01
    z[5,4,1]  R1759     6.2869960069656372e-01
    z[5,4,1]  R1760     6.3185513019561768e-01
    z[5,4,1]  R1761     7.6218783855438232e-01
    z[5,4,1]  R1762     6.7630988359451294e-01
    z[5,4,1]  R1763     -0.663023829460144
    z[5,4,1]  R1764     -1.7637096345424652e-01
    z[5,4,1]  R1765     -1.2277159839868546e-01
    z[5,4,1]  R1766     8.4047597646713257e-01
    z[5,4,1]  R1767     8.0599933862686157e-01
    z[5,4,1]  R1768     0.778223991394043
    z[5,4,1]  R1769     9.6594981849193573e-02
    z[5,4,1]  R1770     2.2723279893398285e-02
    z[5,4,1]  R1771     -2.1410322189331055e-01
    z[5,4,1]  R1772     1.2241020798683167e-02
    z[5,4,1]  R1773     -5.4259186983108521e-01
    z[5,4,1]  R1774     -0.0758294016122818
    z[5,4,1]  R1775     1.6085606068372726e-02
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1698     -1
    z[5,4,2]  R1699     1
    z[5,4,2]  R1708     4.2421588301658630e-01
    z[5,4,2]  R1709     -4.7205638885498047e-01
    z[5,4,2]  R1710     -1.2448070943355560e-01
    z[5,4,2]  R1711     -1.4258812367916107e-01
    z[5,4,2]  R1712     -3.1568869948387146e-01
    z[5,4,2]  R1713     2.6243191957473755e-01
    z[5,4,2]  R1714     1.0560742020606995e-01
    z[5,4,2]  R1715     7.3650372028350830e-01
    z[5,4,2]  R1716     -1.1441224254667759e-02
    z[5,4,2]  R1717     -1.9136193394660950e-01
    z[5,4,2]  R1718     -1.8365412950515747e-01
    z[5,4,2]  R1719     2.9805976152420044e-01
    z[5,4,2]  R1720     4.9986642599105835e-01
    z[5,4,2]  R1721     1.8580672144889832e-01
    z[5,4,2]  R1722     -6.1617337167263031e-02
    z[5,4,2]  R1723     9.2227347195148468e-02
    z[5,4,2]  R1724     1.5809503197669983e-01
    z[5,4,2]  R1725     -1.2670049071311951e-01
    z[5,4,2]  R1726     -2.3583377897739410e-01
    z[5,4,2]  R1727     -1.5753577649593353e-01
    z[5,4,2]  R1728     2.2737956047058105e-01
    z[5,4,2]  R1729     -3.5226836800575256e-02
    z[5,4,2]  R1730     -1.5581825375556946e-01
    z[5,4,2]  R1731     -2.1102492511272430e-01
    z[5,4,2]  R1732     9.6422888338565826e-02
    z[5,4,2]  R1733     -0.194339781999588
    z[5,4,2]  R1734     4.0524479001760483e-02
    z[5,4,2]  R1735     2.1498893201351166e-01
    z[5,4,2]  R1736     -2.4073255062103271e-01
    z[5,4,2]  R1737     1.7117829620838165e-01
    z[5,4,2]  R1738     -1.0943584889173508e-01
    z[5,4,2]  R1739     3.2340955734252930e-01
    z[5,4,2]  R1740     1.6987487673759460e-01
    z[5,4,2]  R1741     -3.1586271524429321e-01
    z[5,4,2]  R1742     -8.7423577904701233e-02
    z[5,4,2]  R1743     5.4338318295776844e-04
    z[5,4,2]  R1744     4.0635776519775391e-01
    z[5,4,2]  R1745     4.1774931550025940e-01
    z[5,4,2]  R1746     3.8258284330368042e-01
    z[5,4,2]  R1747     3.4474813938140869e-01
    z[5,4,2]  R1748     -5.6983286142349243e-01
    z[5,4,2]  R1749     -8.5677266120910645e-02
    z[5,4,2]  R1750     -4.5456889271736145e-01
    z[5,4,2]  R1751     -5.4782372713088989e-01
    z[5,4,2]  R1752     -4.2600205540657043e-01
    z[5,4,2]  R1753     -4.5178778469562531e-02
    z[5,4,2]  R1754     -7.2194474935531616e-01
    z[5,4,2]  R1755     -8.4986887872219086e-02
    z[5,4,2]  R1756     -0.00379387685097754
    z[5,4,2]  R1757     -2.7375376224517822e-01
    z[5,4,2]  R1758     -5.8329051733016968e-01
    z[5,4,2]  R1759     -1.1103716678917408e-02
    z[5,4,2]  R1760     -3.1555393338203430e-01
    z[5,4,2]  R1761     1.2540809810161591e-01
    z[5,4,2]  R1762     6.9144517183303833e-02
    z[5,4,2]  R1763     1.1344595253467560e-01
    z[5,4,2]  R1764     -5.4198831319808960e-01
    z[5,4,2]  R1765     6.1031565070152283e-02
    z[5,4,2]  R1766     -1.6788861155509949e-01
    z[5,4,2]  R1767     -4.6955174207687378e-01
    z[5,4,2]  R1768     4.6259054541587830e-01
    z[5,4,2]  R1769     8.8542439043521881e-02
    z[5,4,2]  R1770     2.9090738296508789e-01
    z[5,4,2]  R1771     -1.9310995936393738e-01
    z[5,4,2]  R1772     2.7238744497299194e-01
    z[5,4,2]  R1773     0.452673077583313
    z[5,4,2]  R1774     1.2094288133084774e-02
    z[5,4,2]  R1775     -1.0561206936836243e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1700     -1
    z[5,4,3]  R1701     1
    z[5,4,3]  R1708     -4.9563711881637573e-01
    z[5,4,3]  R1709     4.2500126361846924e-01
    z[5,4,3]  R1710     -4.8035749793052673e-01
    z[5,4,3]  R1711     -3.9550641179084778e-01
    z[5,4,3]  R1712     4.9071967601776123e-01
    z[5,4,3]  R1713     8.5449254512786865e-01
    z[5,4,3]  R1714     5.2628409862518311e-01
    z[5,4,3]  R1715     5.7510995864868164e-01
    z[5,4,3]  R1716     -0.0466766357421875
    z[5,4,3]  R1717     -4.6105778892524540e-04
    z[5,4,3]  R1718     7.8190630674362183e-01
    z[5,4,3]  R1719     7.6712244749069214e-01
    z[5,4,3]  R1720     8.2034456729888916e-01
    z[5,4,3]  R1721     8.3577936887741089e-01
    z[5,4,3]  R1722     1.5298387408256531e-01
    z[5,4,3]  R1723     2.3793998360633850e-01
    z[5,4,3]  R1724     6.0946464538574219e-02
    z[5,4,3]  R1725     1.4294156432151794e-01
    z[5,4,3]  R1726     0.730543851852417
    z[5,4,3]  R1727     7.0127081871032715e-01
    z[5,4,3]  R1728     8.2396721839904785e-01
    z[5,4,3]  R1729     0.727130115032196
    z[5,4,3]  R1730     6.3442248106002808e-01
    z[5,4,3]  R1731     0.633794367313385
    z[5,4,3]  R1732     -3.9689075946807861e-01
    z[5,4,3]  R1733     1.0902449488639832e-01
    z[5,4,3]  R1734     1.2227544933557510e-01
    z[5,4,3]  R1735     4.8029428720474243e-01
    z[5,4,3]  R1736     -4.7331269830465317e-02
    z[5,4,3]  R1737     -1.4609293639659882e-01
    z[5,4,3]  R1738     -1.9677279889583588e-01
    z[5,4,3]  R1739     1.7926159780472517e-03
    z[5,4,3]  R1740     9.0469516813755035e-02
    z[5,4,3]  R1741     2.3210534453392029e-01
    z[5,4,3]  R1742     1.5827704966068268e-01
    z[5,4,3]  R1743     -8.2274377346038818e-02
    z[5,4,3]  R1744     -1.4462047256529331e-02
    z[5,4,3]  R1745     -7.4838304519653320e-01
    z[5,4,3]  R1746     2.4816274642944336e-01
    z[5,4,3]  R1747     2.2176474332809448e-02
    z[5,4,3]  R1748     -2.5665040593594313e-03
    z[5,4,3]  R1749     2.1752910688519478e-02
    z[5,4,3]  R1750     5.9062212705612183e-02
    z[5,4,3]  R1751     -2.1189042925834656e-01
    z[5,4,3]  R1752     0.0831940770149231
    z[5,4,3]  R1753     -4.1274357587099075e-02
    z[5,4,3]  R1754     -2.5362381339073181e-01
    z[5,4,3]  R1755     3.1121477484703064e-01
    z[5,4,3]  R1756     -4.0754970163106918e-02
    z[5,4,3]  R1757     -3.0387207865715027e-01
    z[5,4,3]  R1758     -9.3949548900127411e-02
    z[5,4,3]  R1759     -1.1556169390678406e-01
    z[5,4,3]  R1760     -3.5379728674888611e-01
    z[5,4,3]  R1761     -2.3951049894094467e-02
    z[5,4,3]  R1762     -2.1424324810504913e-01
    z[5,4,3]  R1763     5.6550878286361694e-01
    z[5,4,3]  R1764     -3.3582359552383423e-01
    z[5,4,3]  R1765     -9.1047853231430054e-01
    z[5,4,3]  R1766     -6.9805346429347992e-02
    z[5,4,3]  R1767     1.1960940808057785e-01
    z[5,4,3]  R1768     -2.4114339053630829e-01
    z[5,4,3]  R1769     -9.3121886253356934e-01
    z[5,4,3]  R1770     -7.8325563669204712e-01
    z[5,4,3]  R1771     -0.847061276435852
    z[5,4,3]  R1772     -7.1464049816131592e-01
    z[5,4,3]  R1773     1.1077910661697388e-01
    z[5,4,3]  R1774     -8.0553990602493286e-01
    z[5,4,3]  R1775     -8.6751186847686768e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1702     -1
    z[5,4,4]  R1703     1
    z[5,4,4]  R1708     1.9341827137395740e-03
    z[5,4,4]  R1709     -3.8472640514373779e-01
    z[5,4,4]  R1710     6.3935375213623047e-01
    z[5,4,4]  R1711     -2.3438097536563873e-01
    z[5,4,4]  R1712     1.7354603111743927e-01
    z[5,4,4]  R1713     -3.6505248397588730e-02
    z[5,4,4]  R1714     -2.9357659816741943e-01
    z[5,4,4]  R1715     -2.3593001067638397e-01
    z[5,4,4]  R1716     -2.1491923928260803e-01
    z[5,4,4]  R1717     1.8646484613418579e-01
    z[5,4,4]  R1718     4.0940508246421814e-01
    z[5,4,4]  R1719     2.5069794058799744e-01
    z[5,4,4]  R1720     1.8114280700683594e-01
    z[5,4,4]  R1721     4.1229769587516785e-01
    z[5,4,4]  R1722     -3.1224167346954346e-01
    z[5,4,4]  R1723     -4.1876533627510071e-01
    z[5,4,4]  R1724     -4.8623114824295044e-01
    z[5,4,4]  R1725     -4.5903232693672180e-01
    z[5,4,4]  R1726     -8.1146813929080963e-02
    z[5,4,4]  R1727     -4.3037894368171692e-01
    z[5,4,4]  R1728     2.9538854956626892e-01
    z[5,4,4]  R1729     2.4446974694728851e-01
    z[5,4,4]  R1730     -1.2033727020025253e-01
    z[5,4,4]  R1731     1.5191417932510376e-01
    z[5,4,4]  R1732     7.2274312376976013e-02
    z[5,4,4]  R1733     -3.6287853121757507e-01
    z[5,4,4]  R1734     1.5929432213306427e-01
    z[5,4,4]  R1735     -3.2231506705284119e-01
    z[5,4,4]  R1736     3.0326032638549805e-01
    z[5,4,4]  R1737     8.3895117044448853e-02
    z[5,4,4]  R1738     -1.7281009256839752e-01
    z[5,4,4]  R1739     4.8168513923883438e-02
    z[5,4,4]  R1740     -3.4734839200973511e-01
    z[5,4,4]  R1741     1.6019767522811890e-01
    z[5,4,4]  R1742     -2.4893178045749664e-01
    z[5,4,4]  R1743     4.4497553259134293e-02
    z[5,4,4]  R1744     5.3775101900100708e-01
    z[5,4,4]  R1745     1.5182322263717651e-01
    z[5,4,4]  R1746     1.5464043617248535e-01
    z[5,4,4]  R1747     3.2749116420745850e-01
    z[5,4,4]  R1748     4.8573720455169678e-01
    z[5,4,4]  R1749     1.8877701461315155e-01
    z[5,4,4]  R1750     4.0514644980430603e-01
    z[5,4,4]  R1751     4.0021431446075439e-01
    z[5,4,4]  R1752     -9.5006980001926422e-02
    z[5,4,4]  R1753     6.3432060182094574e-02
    z[5,4,4]  R1754     -0.375505656003952
    z[5,4,4]  R1755     3.2811316847801208e-01
    z[5,4,4]  R1756     -1.7451224848628044e-03
    z[5,4,4]  R1757     3.4370237588882446e-01
    z[5,4,4]  R1758     -6.6038645803928375e-02
    z[5,4,4]  R1759     5.0186789035797119e-01
    z[5,4,4]  R1760     -2.7187541127204895e-01
    z[5,4,4]  R1761     -1.4624411240220070e-02
    z[5,4,4]  R1762     -2.2746595740318298e-01
    z[5,4,4]  R1763     1.5908056497573853e-01
    z[5,4,4]  R1764     8.2281278446316719e-03
    z[5,4,4]  R1765     2.4427349865436554e-01
    z[5,4,4]  R1766     9.0380340814590454e-02
    z[5,4,4]  R1767     -2.1852515637874603e-01
    z[5,4,4]  R1768     -1.2365867942571640e-01
    z[5,4,4]  R1769     1.1866585165262222e-01
    z[5,4,4]  R1770     3.2401621341705322e-01
    z[5,4,4]  R1771     1.4881283044815063e-01
    z[5,4,4]  R1772     3.4713208675384521e-01
    z[5,4,4]  R1773     -3.4721145033836365e-01
    z[5,4,4]  R1774     0.181483656167984
    z[5,4,4]  R1775     -3.1620559096336365e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1704     -1
    z[5,4,5]  R1705     1
    z[5,4,5]  R1708     -6.4516419172286987e-01
    z[5,4,5]  R1709     4.8268601298332214e-01
    z[5,4,5]  R1710     1.6855491697788239e-01
    z[5,4,5]  R1711     2.1732540428638458e-01
    z[5,4,5]  R1712     -0.458787202835083
    z[5,4,5]  R1713     -3.8926395773887634e-01
    z[5,4,5]  R1714     -4.3972459435462952e-01
    z[5,4,5]  R1715     6.8293526768684387e-02
    z[5,4,5]  R1716     1.4766024053096771e-01
    z[5,4,5]  R1717     -3.0437666177749634e-01
    z[5,4,5]  R1718     -3.6676400899887085e-01
    z[5,4,5]  R1719     -1.2268547713756561e-01
    z[5,4,5]  R1720     -1.8348152935504913e-01
    z[5,4,5]  R1721     8.8123209774494171e-02
    z[5,4,5]  R1722     -1.1496735364198685e-01
    z[5,4,5]  R1723     -1.8946514464914799e-03
    z[5,4,5]  R1724     -6.5354225225746632e-03
    z[5,4,5]  R1725     -2.9177182912826538e-01
    z[5,4,5]  R1726     6.3424748368561268e-03
    z[5,4,5]  R1727     2.8956970572471619e-01
    z[5,4,5]  R1728     2.3998151719570160e-01
    z[5,4,5]  R1729     2.4932898581027985e-01
    z[5,4,5]  R1730     -4.3083101511001587e-01
    z[5,4,5]  R1731     0.253202348947525
    z[5,4,5]  R1732     1.0113696753978729e-01
    z[5,4,5]  R1733     -2.5225368142127991e-01
    z[5,4,5]  R1734     -4.9402132630348206e-01
    z[5,4,5]  R1735     2.6839631609618664e-03
    z[5,4,5]  R1736     1.1054874956607819e-01
    z[5,4,5]  R1737     1.2872508168220520e-01
    z[5,4,5]  R1738     1.3896699249744415e-01
    z[5,4,5]  R1739     1.1986243724822998e-01
    z[5,4,5]  R1740     3.1845462322235107e-01
    z[5,4,5]  R1741     -3.1852710247039795e-01
    z[5,4,5]  R1742     -1.2174678593873978e-01
    z[5,4,5]  R1743     4.6465528011322021e-01
    z[5,4,5]  R1744     -1.0141479969024658e-01
    z[5,4,5]  R1745     1.4903669059276581e-01
    z[5,4,5]  R1746     1.5225917100906372e-01
    z[5,4,5]  R1747     1.6096018254756927e-01
    z[5,4,5]  R1748     -2.0274797081947327e-01
    z[5,4,5]  R1749     9.3289494514465332e-02
    z[5,4,5]  R1750     1.0635881125926971e-01
    z[5,4,5]  R1751     -3.0697991605848074e-03
    z[5,4,5]  R1752     4.4315528124570847e-02
    z[5,4,5]  R1753     5.9369522333145142e-01
    z[5,4,5]  R1754     8.3816125988960266e-02
    z[5,4,5]  R1755     2.5790938735008240e-01
    z[5,4,5]  R1756     2.0269152522087097e-01
    z[5,4,5]  R1757     -0.318645179271698
    z[5,4,5]  R1758     -1.2177570909261703e-01
    z[5,4,5]  R1759     3.5580408573150635e-01
    z[5,4,5]  R1760     1.9559279084205627e-01
    z[5,4,5]  R1761     -5.3090296685695648e-02
    z[5,4,5]  R1762     7.4570290744304657e-02
    z[5,4,5]  R1763     -3.9866459369659424e-01
    z[5,4,5]  R1764     6.7389182746410370e-02
    z[5,4,5]  R1765     3.8153558969497681e-02
    z[5,4,5]  R1766     5.0841666758060455e-02
    z[5,4,5]  R1767     1.0002262890338898e-02
    z[5,4,5]  R1768     0.109798364341259
    z[5,4,5]  R1769     -4.8818994313478470e-02
    z[5,4,5]  R1770     -3.1974723935127258e-01
    z[5,4,5]  R1771     7.0133045315742493e-02
    z[5,4,5]  R1772     -3.3949542045593262e-01
    z[5,4,5]  R1773     -3.2147404551506042e-01
    z[5,4,5]  R1774     -4.6553176641464233e-01
    z[5,4,5]  R1775     2.0283545553684235e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1706     -1
    z[5,4,6]  R1707     1
    z[5,4,6]  R1708     -2.1190728247165680e-01
    z[5,4,6]  R1709     -1.4409545063972473e-01
    z[5,4,6]  R1710     8.1505045294761658e-02
    z[5,4,6]  R1711     8.1839221715927124e-01
    z[5,4,6]  R1712     3.7150415778160095e-01
    z[5,4,6]  R1713     1.8464881181716919e-01
    z[5,4,6]  R1714     5.3933048248291016e-01
    z[5,4,6]  R1715     -2.1135868132114410e-01
    z[5,4,6]  R1716     -6.3240334391593933e-02
    z[5,4,6]  R1717     4.1932859458029270e-03
    z[5,4,6]  R1718     -9.7157590091228485e-02
    z[5,4,6]  R1719     4.7822231054306030e-01
    z[5,4,6]  R1720     -6.0714911669492722e-02
    z[5,4,6]  R1721     -9.5058217644691467e-02
    z[5,4,6]  R1722     -1.6319499909877777e-01
    z[5,4,6]  R1723     -2.0601308345794678e-01
    z[5,4,6]  R1724     0.0339912548661232
    z[5,4,6]  R1725     -5.4190486669540405e-02
    z[5,4,6]  R1726     -3.4755849838256836e-01
    z[5,4,6]  R1727     1.5080761909484863e-01
    z[5,4,6]  R1728     -2.2129465639591217e-01
    z[5,4,6]  R1729     4.7135999798774719e-01
    z[5,4,6]  R1730     2.8967404365539551e-01
    z[5,4,6]  R1731     1.5623587369918823e-01
    z[5,4,6]  R1732     3.0056005716323853e-01
    z[5,4,6]  R1733     1.6511987149715424e-01
    z[5,4,6]  R1734     1.1102846264839172e-01
    z[5,4,6]  R1735     5.3668646141886711e-03
    z[5,4,6]  R1736     1.1176948994398117e-01
    z[5,4,6]  R1737     1.1305092275142670e-01
    z[5,4,6]  R1738     4.4450348615646362e-01
    z[5,4,6]  R1739     -4.2897281050682068e-01
    z[5,4,6]  R1740     -1.9016404449939728e-01
    z[5,4,6]  R1741     -3.6399850249290466e-01
    z[5,4,6]  R1742     -5.1832431554794312e-01
    z[5,4,6]  R1743     -4.5685482025146484e-01
    z[5,4,6]  R1744     7.9845957458019257e-02
    z[5,4,6]  R1745     1.7931368947029114e-01
    z[5,4,6]  R1746     3.4765779972076416e-01
    z[5,4,6]  R1747     -3.6506736278533936e-01
    z[5,4,6]  R1748     -9.8876990377902985e-02
    z[5,4,6]  R1749     -7.5220972299575806e-01
    z[5,4,6]  R1750     -2.4946087598800659e-01
    z[5,4,6]  R1751     -4.7301241755485535e-01
    z[5,4,6]  R1752     -7.1854597330093384e-01
    z[5,4,6]  R1753     -4.5263972878456116e-01
    z[5,4,6]  R1754     -2.1199119091033936e-01
    z[5,4,6]  R1755     -5.4631048440933228e-01
    z[5,4,6]  R1756     3.9625599980354309e-01
    z[5,4,6]  R1757     2.5869068503379822e-01
    z[5,4,6]  R1758     -0.459351122379303
    z[5,4,6]  R1759     -3.2972556352615356e-01
    z[5,4,6]  R1760     -4.8167926073074341e-01
    z[5,4,6]  R1761     -2.6300454139709473e-01
    z[5,4,6]  R1762     -5.5979293584823608e-01
    z[5,4,6]  R1763     1.9547837972640991e-01
    z[5,4,6]  R1764     -5.1672633737325668e-02
    z[5,4,6]  R1765     -2.5184908509254456e-01
    z[5,4,6]  R1766     -4.9857613444328308e-01
    z[5,4,6]  R1767     -1.8820254504680634e-01
    z[5,4,6]  R1768     -1.9410468637943268e-01
    z[5,4,6]  R1769     -2.8042781352996826e-01
    z[5,4,6]  R1770     -4.2756326496601105e-02
    z[5,4,6]  R1771     2.1045985817909241e-01
    z[5,4,6]  R1772     3.6888951063156128e-01
    z[5,4,6]  R1773     6.0197249054908752e-02
    z[5,4,6]  R1774     2.4023090302944183e-01
    z[5,4,6]  R1775     7.8073084354400635e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1776     -1
    z[5,6,0]  R1777     1
    z[5,6,0]  R1790     2.2690695524215698e-01
    z[5,6,0]  R1791     3.0239224433898926e-01
    z[5,6,0]  R1792     2.1081301569938660e-01
    z[5,6,0]  R1793     2.1362684667110443e-01
    z[5,6,0]  R1794     4.0902960300445557e-01
    z[5,6,0]  R1795     1.0302189737558365e-01
    z[5,6,0]  R1796     -3.3271512389183044e-01
    z[5,6,0]  R1797     -1.4525122940540314e-01
    z[5,6,0]  R1798     -9.3036937713623047e-01
    z[5,6,0]  R1799     -8.6827713251113892e-01
    z[5,6,0]  R1800     -2.0814840495586395e-01
    z[5,6,0]  R1801     1.1761409789323807e-01
    z[5,6,0]  R1802     -6.0667127370834351e-02
    z[5,6,0]  R1803     -1.8856215476989746e-01
    z[5,6,0]  R1804     -4.0643563866615295e-01
    z[5,6,0]  R1805     -6.8354494869709015e-03
    z[5,6,0]  R1806     -1.9492869079113007e-01
    z[5,6,0]  R1807     1.3939078897237778e-02
    z[5,6,0]  R1808     3.7917536497116089e-01
    z[5,6,0]  R1809     2.5082227587699890e-01
    z[5,6,0]  R1810     4.6135523915290833e-01
    z[5,6,0]  R1811     2.4929250776767731e-01
    z[5,6,0]  R1812     2.0297257602214813e-01
    z[5,6,0]  R1813     -4.8453950881958008e-01
    z[5,6,0]  R1814     -4.7447955608367920e-01
    z[5,6,0]  R1815     -4.8622754216194153e-01
    z[5,6,0]  R1816     -6.0882955789566040e-01
    z[5,6,0]  R1817     -3.2798323035240173e-01
    z[5,6,0]  R1818     0.611726701259613
    z[5,6,0]  R1819     -1.4073152840137482e-01
    z[5,6,0]  R1820     1.6352796927094460e-02
    z[5,6,0]  R1821     3.0225786566734314e-01
    z[5,6,0]  R1822     3.3904369920492172e-02
    z[5,6,0]  R1823     3.6664927005767822e-01
    z[5,6,0]  R1824     -2.3543752729892731e-01
    z[5,6,0]  R1825     -4.1386967897415161e-01
    z[5,6,0]  R1826     1.4240473508834839e-01
    z[5,6,0]  R1827     -2.4127395451068878e-01
    z[5,6,0]  R1828     4.1634678840637207e-01
    z[5,6,0]  R1829     2.6002532243728638e-01
    z[5,6,0]  R1830     -6.0463231801986694e-01
    z[5,6,0]  R1831     4.1484346985816956e-01
    z[5,6,0]  R1832     4.3883144855499268e-01
    z[5,6,0]  R1833     -1.6103708744049072e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1778     -1
    z[5,6,1]  R1779     1
    z[5,6,1]  R1790     2.4850067496299744e-01
    z[5,6,1]  R1791     3.2145267724990845e-01
    z[5,6,1]  R1792     -5.1525926589965820e-01
    z[5,6,1]  R1793     -7.5340814888477325e-02
    z[5,6,1]  R1794     3.3706137537956238e-01
    z[5,6,1]  R1795     -5.8345835655927658e-02
    z[5,6,1]  R1796     1.7535819113254547e-01
    z[5,6,1]  R1797     2.6711516082286835e-02
    z[5,6,1]  R1798     -2.4517327547073364e-01
    z[5,6,1]  R1799     -2.8643208742141724e-01
    z[5,6,1]  R1800     7.9304700193461031e-05
    z[5,6,1]  R1801     -4.7462385147809982e-02
    z[5,6,1]  R1802     5.7649511843919754e-02
    z[5,6,1]  R1803     -2.1119147539138794e-01
    z[5,6,1]  R1804     -8.1869667768478394e-01
    z[5,6,1]  R1805     -8.4677189588546753e-01
    z[5,6,1]  R1806     -8.3407163619995117e-01
    z[5,6,1]  R1807     -8.1519466638565063e-01
    z[5,6,1]  R1808     3.3059012889862061e-01
    z[5,6,1]  R1809     2.6292881369590759e-01
    z[5,6,1]  R1810     1.2327650189399719e-01
    z[5,6,1]  R1811     5.6456193327903748e-02
    z[5,6,1]  R1812     -5.2283253520727158e-02
    z[5,6,1]  R1813     -8.1001192331314087e-01
    z[5,6,1]  R1814     -6.4875560998916626e-01
    z[5,6,1]  R1815     -0.633316159248352
    z[5,6,1]  R1816     -6.1103403568267822e-01
    z[5,6,1]  R1817     -6.8792277574539185e-01
    z[5,6,1]  R1818     -5.4759508371353149e-01
    z[5,6,1]  R1819     8.5497468709945679e-01
    z[5,6,1]  R1820     0.834886908531189
    z[5,6,1]  R1821     9.2395859956741333e-01
    z[5,6,1]  R1822     8.5465639829635620e-01
    z[5,6,1]  R1823     7.1587729454040527e-01
    z[5,6,1]  R1824     9.1652947664260864e-01
    z[5,6,1]  R1825     8.3058446645736694e-01
    z[5,6,1]  R1826     8.0805647373199463e-01
    z[5,6,1]  R1827     9.3558359146118164e-01
    z[5,6,1]  R1828     0.853506863117218
    z[5,6,1]  R1829     5.3388422727584839e-01
    z[5,6,1]  R1830     -2.7932587265968323e-01
    z[5,6,1]  R1831     2.8157082200050354e-01
    z[5,6,1]  R1832     -1.8062831461429596e-01
    z[5,6,1]  R1833     2.1448570489883423e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1780     -1
    z[5,6,2]  R1781     1
    z[5,6,2]  R1790     4.2421588301658630e-01
    z[5,6,2]  R1791     -4.7205638885498047e-01
    z[5,6,2]  R1792     -1.2448070943355560e-01
    z[5,6,2]  R1793     -1.4258812367916107e-01
    z[5,6,2]  R1794     -3.1568869948387146e-01
    z[5,6,2]  R1795     2.6243191957473755e-01
    z[5,6,2]  R1796     1.0560742020606995e-01
    z[5,6,2]  R1797     7.3650372028350830e-01
    z[5,6,2]  R1798     -1.1441224254667759e-02
    z[5,6,2]  R1799     -1.9136193394660950e-01
    z[5,6,2]  R1800     -1.8365412950515747e-01
    z[5,6,2]  R1801     2.9805976152420044e-01
    z[5,6,2]  R1802     4.9986642599105835e-01
    z[5,6,2]  R1803     1.8580672144889832e-01
    z[5,6,2]  R1804     -6.1617337167263031e-02
    z[5,6,2]  R1805     9.2227347195148468e-02
    z[5,6,2]  R1806     1.5809503197669983e-01
    z[5,6,2]  R1807     -1.2670049071311951e-01
    z[5,6,2]  R1808     -3.0896124243736267e-01
    z[5,6,2]  R1809     -6.4777895808219910e-02
    z[5,6,2]  R1810     -1.2366840243339539e-01
    z[5,6,2]  R1811     -3.0324435234069824e-01
    z[5,6,2]  R1812     5.5941653251647949e-01
    z[5,6,2]  R1813     -2.7511458843946457e-02
    z[5,6,2]  R1814     -1.3770723342895508e-01
    z[5,6,2]  R1815     1.5771174430847168e-01
    z[5,6,2]  R1816     1.3704569637775421e-01
    z[5,6,2]  R1817     1.0821133852005005e-01
    z[5,6,2]  R1818     -4.1420180350542068e-03
    z[5,6,2]  R1819     -1.4776925742626190e-01
    z[5,6,2]  R1820     9.8275601863861084e-02
    z[5,6,2]  R1821     1.2450519204139709e-01
    z[5,6,2]  R1822     -4.4256478548049927e-02
    z[5,6,2]  R1823     -6.4823113381862640e-02
    z[5,6,2]  R1824     -1.1903249472379684e-01
    z[5,6,2]  R1825     -3.3901998400688171e-01
    z[5,6,2]  R1826     -2.4882888793945312e-01
    z[5,6,2]  R1827     -1.4723014831542969e-01
    z[5,6,2]  R1828     1.4142517745494843e-01
    z[5,6,2]  R1829     3.9946746826171875e-01
    z[5,6,2]  R1830     -4.1601985692977905e-01
    z[5,6,2]  R1831     1.2957191094756126e-02
    z[5,6,2]  R1832     1.7368771135807037e-01
    z[5,6,2]  R1833     -7.9439365863800049e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1782     -1
    z[5,6,3]  R1783     1
    z[5,6,3]  R1790     -4.9563711881637573e-01
    z[5,6,3]  R1791     4.2500126361846924e-01
    z[5,6,3]  R1792     -4.8035749793052673e-01
    z[5,6,3]  R1793     -3.9550641179084778e-01
    z[5,6,3]  R1794     4.9071967601776123e-01
    z[5,6,3]  R1795     8.5449254512786865e-01
    z[5,6,3]  R1796     5.2628409862518311e-01
    z[5,6,3]  R1797     5.7510995864868164e-01
    z[5,6,3]  R1798     -0.0466766357421875
    z[5,6,3]  R1799     -4.6105778892524540e-04
    z[5,6,3]  R1800     7.8190630674362183e-01
    z[5,6,3]  R1801     7.6712244749069214e-01
    z[5,6,3]  R1802     8.2034456729888916e-01
    z[5,6,3]  R1803     8.3577936887741089e-01
    z[5,6,3]  R1804     1.5298387408256531e-01
    z[5,6,3]  R1805     2.3793998360633850e-01
    z[5,6,3]  R1806     6.0946464538574219e-02
    z[5,6,3]  R1807     1.4294156432151794e-01
    z[5,6,3]  R1808     -6.5172064304351807e-01
    z[5,6,3]  R1809     -1.6469325870275497e-02
    z[5,6,3]  R1810     4.4052770733833313e-01
    z[5,6,3]  R1811     -8.9372701942920685e-02
    z[5,6,3]  R1812     -1.1839209496974945e-01
    z[5,6,3]  R1813     2.5236532092094421e-01
    z[5,6,3]  R1814     2.7716401219367981e-01
    z[5,6,3]  R1815     6.8763040006160736e-02
    z[5,6,3]  R1816     -1.5068550407886505e-01
    z[5,6,3]  R1817     -2.8603699803352356e-01
    z[5,6,3]  R1818     -4.4781614094972610e-02
    z[5,6,3]  R1819     3.0488395690917969e-01
    z[5,6,3]  R1820     2.4808315932750702e-01
    z[5,6,3]  R1821     1.2578254938125610e-01
    z[5,6,3]  R1822     1.8240959942340851e-01
    z[5,6,3]  R1823     3.2359105348587036e-01
    z[5,6,3]  R1824     -0.0447562001645565
    z[5,6,3]  R1825     1.2680643796920776e-01
    z[5,6,3]  R1826     -1.5656933188438416e-01
    z[5,6,3]  R1827     1.3978891074657440e-01
    z[5,6,3]  R1828     2.1200279891490936e-01
    z[5,6,3]  R1829     3.5718372464179993e-01
    z[5,6,3]  R1830     -4.1226732730865479e-01
    z[5,6,3]  R1831     -8.3796960115432739e-01
    z[5,6,3]  R1832     -3.3264175057411194e-01
    z[5,6,3]  R1833     1.0389391332864761e-02
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1784     -1
    z[5,6,4]  R1785     1
    z[5,6,4]  R1790     1.9341827137395740e-03
    z[5,6,4]  R1791     -3.8472640514373779e-01
    z[5,6,4]  R1792     6.3935375213623047e-01
    z[5,6,4]  R1793     -2.3438097536563873e-01
    z[5,6,4]  R1794     1.7354603111743927e-01
    z[5,6,4]  R1795     -3.6505248397588730e-02
    z[5,6,4]  R1796     -2.9357659816741943e-01
    z[5,6,4]  R1797     -2.3593001067638397e-01
    z[5,6,4]  R1798     -2.1491923928260803e-01
    z[5,6,4]  R1799     1.8646484613418579e-01
    z[5,6,4]  R1800     4.0940508246421814e-01
    z[5,6,4]  R1801     2.5069794058799744e-01
    z[5,6,4]  R1802     1.8114280700683594e-01
    z[5,6,4]  R1803     4.1229769587516785e-01
    z[5,6,4]  R1804     -3.1224167346954346e-01
    z[5,6,4]  R1805     -4.1876533627510071e-01
    z[5,6,4]  R1806     -4.8623114824295044e-01
    z[5,6,4]  R1807     -4.5903232693672180e-01
    z[5,6,4]  R1808     -3.2583290338516235e-01
    z[5,6,4]  R1809     -2.7821826934814453e-01
    z[5,6,4]  R1810     6.7188933491706848e-02
    z[5,6,4]  R1811     4.7482779622077942e-01
    z[5,6,4]  R1812     -3.6745730042457581e-01
    z[5,6,4]  R1813     -7.8729726374149323e-02
    z[5,6,4]  R1814     2.8432884812355042e-01
    z[5,6,4]  R1815     -4.2871765792369843e-02
    z[5,6,4]  R1816     -2.2973024845123291e-01
    z[5,6,4]  R1817     -1.0809712857007980e-01
    z[5,6,4]  R1818     2.4782599508762360e-01
    z[5,6,4]  R1819     1.1179201304912567e-01
    z[5,6,4]  R1820     -1.4008018374443054e-01
    z[5,6,4]  R1821     -9.2467740178108215e-03
    z[5,6,4]  R1822     -1.9531685113906860e-01
    z[5,6,4]  R1823     2.9183301329612732e-01
    z[5,6,4]  R1824     -5.6745827198028564e-02
    z[5,6,4]  R1825     -1.0065872222185135e-02
    z[5,6,4]  R1826     -3.9776325225830078e-02
    z[5,6,4]  R1827     -1.1228875070810318e-01
    z[5,6,4]  R1828     1.0977048426866531e-01
    z[5,6,4]  R1829     -3.2281684875488281e-01
    z[5,6,4]  R1830     -2.0525366067886353e-01
    z[5,6,4]  R1831     -1.3405166566371918e-01
    z[5,6,4]  R1832     -2.4102728068828583e-01
    z[5,6,4]  R1833     4.5595857501029968e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1786     -1
    z[5,6,5]  R1787     1
    z[5,6,5]  R1790     -6.4516419172286987e-01
    z[5,6,5]  R1791     4.8268601298332214e-01
    z[5,6,5]  R1792     1.6855491697788239e-01
    z[5,6,5]  R1793     2.1732540428638458e-01
    z[5,6,5]  R1794     -0.458787202835083
    z[5,6,5]  R1795     -3.8926395773887634e-01
    z[5,6,5]  R1796     -4.3972459435462952e-01
    z[5,6,5]  R1797     6.8293526768684387e-02
    z[5,6,5]  R1798     1.4766024053096771e-01
    z[5,6,5]  R1799     -3.0437666177749634e-01
    z[5,6,5]  R1800     -3.6676400899887085e-01
    z[5,6,5]  R1801     -1.2268547713756561e-01
    z[5,6,5]  R1802     -1.8348152935504913e-01
    z[5,6,5]  R1803     8.8123209774494171e-02
    z[5,6,5]  R1804     -1.1496735364198685e-01
    z[5,6,5]  R1805     -1.8946514464914799e-03
    z[5,6,5]  R1806     -6.5354225225746632e-03
    z[5,6,5]  R1807     -2.9177182912826538e-01
    z[5,6,5]  R1808     -1.8530496954917908e-01
    z[5,6,5]  R1809     1.6553317010402679e-01
    z[5,6,5]  R1810     -0.708588719367981
    z[5,6,5]  R1811     -0.627094030380249
    z[5,6,5]  R1812     -3.9910188317298889e-01
    z[5,6,5]  R1813     -5.2411708980798721e-02
    z[5,6,5]  R1814     -3.1696256250143051e-02
    z[5,6,5]  R1815     2.5768628716468811e-01
    z[5,6,5]  R1816     -7.2195850312709808e-02
    z[5,6,5]  R1817     -4.4598728418350220e-01
    z[5,6,5]  R1818     4.9739050865173340e-01
    z[5,6,5]  R1819     3.0556204915046692e-01
    z[5,6,5]  R1820     4.5865449309349060e-01
    z[5,6,5]  R1821     1.3495285809040070e-01
    z[5,6,5]  R1822     1.6480810940265656e-01
    z[5,6,5]  R1823     3.9348602294921875e-01
    z[5,6,5]  R1824     -1.7372589558362961e-02
    z[5,6,5]  R1825     -8.6739644408226013e-02
    z[5,6,5]  R1826     4.2810970544815063e-01
    z[5,6,5]  R1827     -0.0961286723613739
    z[5,6,5]  R1828     8.7627187371253967e-02
    z[5,6,5]  R1829     3.2574450969696045e-01
    z[5,6,5]  R1830     3.7828603386878967e-01
    z[5,6,5]  R1831     -7.2894699871540070e-02
    z[5,6,5]  R1832     -5.5353248119354248e-01
    z[5,6,5]  R1833     2.0876155793666840e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1788     -1
    z[5,6,6]  R1789     1
    z[5,6,6]  R1790     -2.1190728247165680e-01
    z[5,6,6]  R1791     -1.4409545063972473e-01
    z[5,6,6]  R1792     8.1505045294761658e-02
    z[5,6,6]  R1793     8.1839221715927124e-01
    z[5,6,6]  R1794     3.7150415778160095e-01
    z[5,6,6]  R1795     1.8464881181716919e-01
    z[5,6,6]  R1796     5.3933048248291016e-01
    z[5,6,6]  R1797     -2.1135868132114410e-01
    z[5,6,6]  R1798     -6.3240334391593933e-02
    z[5,6,6]  R1799     4.1932859458029270e-03
    z[5,6,6]  R1800     -9.7157590091228485e-02
    z[5,6,6]  R1801     4.7822231054306030e-01
    z[5,6,6]  R1802     -6.0714911669492722e-02
    z[5,6,6]  R1803     -9.5058217644691467e-02
    z[5,6,6]  R1804     -1.6319499909877777e-01
    z[5,6,6]  R1805     -2.0601308345794678e-01
    z[5,6,6]  R1806     0.0339912548661232
    z[5,6,6]  R1807     -5.4190486669540405e-02
    z[5,6,6]  R1808     2.9365673661231995e-01
    z[5,6,6]  R1809     -8.7102377414703369e-01
    z[5,6,6]  R1810     2.3660773038864136e-01
    z[5,6,6]  R1811     -4.6477177739143372e-01
    z[5,6,6]  R1812     -5.7861721515655518e-01
    z[5,6,6]  R1813     1.8897494673728943e-01
    z[5,6,6]  R1814     -4.1994577646255493e-01
    z[5,6,6]  R1815     -5.1444333791732788e-01
    z[5,6,6]  R1816     -3.9558568596839905e-01
    z[5,6,6]  R1817     -3.3922377228736877e-01
    z[5,6,6]  R1818     1.2285137176513672e-01
    z[5,6,6]  R1819     -1.6898886859416962e-01
    z[5,6,6]  R1820     3.8814555853605270e-02
    z[5,6,6]  R1821     -7.2938792407512665e-02
    z[5,6,6]  R1822     0.409720242023468
    z[5,6,6]  R1823     -6.4630389213562012e-02
    z[5,6,6]  R1824     -2.9128888249397278e-01
    z[5,6,6]  R1825     1.4202875085175037e-02
    z[5,6,6]  R1826     2.3553293943405151e-01
    z[5,6,6]  R1827     5.8336459100246429e-02
    z[5,6,6]  R1828     -1.1622021347284317e-01
    z[5,6,6]  R1829     3.8714310526847839e-01
    z[5,6,6]  R1830     1.6772159934043884e-01
    z[5,6,6]  R1831     -1.5158607065677643e-01
    z[5,6,6]  R1832     5.1912426948547363e-01
    z[5,6,6]  R1833     2.1310560405254364e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R1834     -1
    z[6,5,0]  R1835     1
    z[6,5,0]  R1848     3.7917536497116089e-01
    z[6,5,0]  R1849     2.5082227587699890e-01
    z[6,5,0]  R1850     4.6135523915290833e-01
    z[6,5,0]  R1851     2.4929250776767731e-01
    z[6,5,0]  R1852     2.0297257602214813e-01
    z[6,5,0]  R1853     -4.8453950881958008e-01
    z[6,5,0]  R1854     -4.7447955608367920e-01
    z[6,5,0]  R1855     -4.8622754216194153e-01
    z[6,5,0]  R1856     -6.0882955789566040e-01
    z[6,5,0]  R1857     -3.2798323035240173e-01
    z[6,5,0]  R1858     0.611726701259613
    z[6,5,0]  R1859     -1.4073152840137482e-01
    z[6,5,0]  R1860     1.6352796927094460e-02
    z[6,5,0]  R1861     3.0225786566734314e-01
    z[6,5,0]  R1862     3.3904369920492172e-02
    z[6,5,0]  R1863     3.6664927005767822e-01
    z[6,5,0]  R1864     -2.3543752729892731e-01
    z[6,5,0]  R1865     -4.1386967897415161e-01
    z[6,5,0]  R1866     1.4240473508834839e-01
    z[6,5,0]  R1867     -2.4127395451068878e-01
    z[6,5,0]  R1868     4.1634678840637207e-01
    z[6,5,0]  R1869     2.6002532243728638e-01
    z[6,5,0]  R1870     -6.0463231801986694e-01
    z[6,5,0]  R1871     4.1484346985816956e-01
    z[6,5,0]  R1872     4.3883144855499268e-01
    z[6,5,0]  R1873     -1.6103708744049072e-01
    z[6,5,0]  R1874     2.2690695524215698e-01
    z[6,5,0]  R1875     3.0239224433898926e-01
    z[6,5,0]  R1876     2.1081301569938660e-01
    z[6,5,0]  R1877     2.1362684667110443e-01
    z[6,5,0]  R1878     4.0902960300445557e-01
    z[6,5,0]  R1879     1.0302189737558365e-01
    z[6,5,0]  R1880     -3.3271512389183044e-01
    z[6,5,0]  R1881     -1.4525122940540314e-01
    z[6,5,0]  R1882     -9.3036937713623047e-01
    z[6,5,0]  R1883     -8.6827713251113892e-01
    z[6,5,0]  R1884     -2.0814840495586395e-01
    z[6,5,0]  R1885     1.1761409789323807e-01
    z[6,5,0]  R1886     -6.0667127370834351e-02
    z[6,5,0]  R1887     -1.8856215476989746e-01
    z[6,5,0]  R1888     -4.0643563866615295e-01
    z[6,5,0]  R1889     -6.8354494869709015e-03
    z[6,5,0]  R1890     -1.9492869079113007e-01
    z[6,5,0]  R1891     1.3939078897237778e-02
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R1836     -1
    z[6,5,1]  R1837     1
    z[6,5,1]  R1848     3.3059012889862061e-01
    z[6,5,1]  R1849     2.6292881369590759e-01
    z[6,5,1]  R1850     1.2327650189399719e-01
    z[6,5,1]  R1851     5.6456193327903748e-02
    z[6,5,1]  R1852     -5.2283253520727158e-02
    z[6,5,1]  R1853     -8.1001192331314087e-01
    z[6,5,1]  R1854     -6.4875560998916626e-01
    z[6,5,1]  R1855     -0.633316159248352
    z[6,5,1]  R1856     -6.1103403568267822e-01
    z[6,5,1]  R1857     -6.8792277574539185e-01
    z[6,5,1]  R1858     -5.4759508371353149e-01
    z[6,5,1]  R1859     8.5497468709945679e-01
    z[6,5,1]  R1860     0.834886908531189
    z[6,5,1]  R1861     9.2395859956741333e-01
    z[6,5,1]  R1862     8.5465639829635620e-01
    z[6,5,1]  R1863     7.1587729454040527e-01
    z[6,5,1]  R1864     9.1652947664260864e-01
    z[6,5,1]  R1865     8.3058446645736694e-01
    z[6,5,1]  R1866     8.0805647373199463e-01
    z[6,5,1]  R1867     9.3558359146118164e-01
    z[6,5,1]  R1868     0.853506863117218
    z[6,5,1]  R1869     5.3388422727584839e-01
    z[6,5,1]  R1870     -2.7932587265968323e-01
    z[6,5,1]  R1871     2.8157082200050354e-01
    z[6,5,1]  R1872     -1.8062831461429596e-01
    z[6,5,1]  R1873     2.1448570489883423e-01
    z[6,5,1]  R1874     2.4850067496299744e-01
    z[6,5,1]  R1875     3.2145267724990845e-01
    z[6,5,1]  R1876     -5.1525926589965820e-01
    z[6,5,1]  R1877     -7.5340814888477325e-02
    z[6,5,1]  R1878     3.3706137537956238e-01
    z[6,5,1]  R1879     -5.8345835655927658e-02
    z[6,5,1]  R1880     1.7535819113254547e-01
    z[6,5,1]  R1881     2.6711516082286835e-02
    z[6,5,1]  R1882     -2.4517327547073364e-01
    z[6,5,1]  R1883     -2.8643208742141724e-01
    z[6,5,1]  R1884     7.9304700193461031e-05
    z[6,5,1]  R1885     -4.7462385147809982e-02
    z[6,5,1]  R1886     5.7649511843919754e-02
    z[6,5,1]  R1887     -2.1119147539138794e-01
    z[6,5,1]  R1888     -8.1869667768478394e-01
    z[6,5,1]  R1889     -8.4677189588546753e-01
    z[6,5,1]  R1890     -8.3407163619995117e-01
    z[6,5,1]  R1891     -8.1519466638565063e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R1838     -1
    z[6,5,2]  R1839     1
    z[6,5,2]  R1848     -3.0896124243736267e-01
    z[6,5,2]  R1849     -6.4777895808219910e-02
    z[6,5,2]  R1850     -1.2366840243339539e-01
    z[6,5,2]  R1851     -3.0324435234069824e-01
    z[6,5,2]  R1852     5.5941653251647949e-01
    z[6,5,2]  R1853     -2.7511458843946457e-02
    z[6,5,2]  R1854     -1.3770723342895508e-01
    z[6,5,2]  R1855     1.5771174430847168e-01
    z[6,5,2]  R1856     1.3704569637775421e-01
    z[6,5,2]  R1857     1.0821133852005005e-01
    z[6,5,2]  R1858     -4.1420180350542068e-03
    z[6,5,2]  R1859     -1.4776925742626190e-01
    z[6,5,2]  R1860     9.8275601863861084e-02
    z[6,5,2]  R1861     1.2450519204139709e-01
    z[6,5,2]  R1862     -4.4256478548049927e-02
    z[6,5,2]  R1863     -6.4823113381862640e-02
    z[6,5,2]  R1864     -1.1903249472379684e-01
    z[6,5,2]  R1865     -3.3901998400688171e-01
    z[6,5,2]  R1866     -2.4882888793945312e-01
    z[6,5,2]  R1867     -1.4723014831542969e-01
    z[6,5,2]  R1868     1.4142517745494843e-01
    z[6,5,2]  R1869     3.9946746826171875e-01
    z[6,5,2]  R1870     -4.1601985692977905e-01
    z[6,5,2]  R1871     1.2957191094756126e-02
    z[6,5,2]  R1872     1.7368771135807037e-01
    z[6,5,2]  R1873     -7.9439365863800049e-01
    z[6,5,2]  R1874     4.2421588301658630e-01
    z[6,5,2]  R1875     -4.7205638885498047e-01
    z[6,5,2]  R1876     -1.2448070943355560e-01
    z[6,5,2]  R1877     -1.4258812367916107e-01
    z[6,5,2]  R1878     -3.1568869948387146e-01
    z[6,5,2]  R1879     2.6243191957473755e-01
    z[6,5,2]  R1880     1.0560742020606995e-01
    z[6,5,2]  R1881     7.3650372028350830e-01
    z[6,5,2]  R1882     -1.1441224254667759e-02
    z[6,5,2]  R1883     -1.9136193394660950e-01
    z[6,5,2]  R1884     -1.8365412950515747e-01
    z[6,5,2]  R1885     2.9805976152420044e-01
    z[6,5,2]  R1886     4.9986642599105835e-01
    z[6,5,2]  R1887     1.8580672144889832e-01
    z[6,5,2]  R1888     -6.1617337167263031e-02
    z[6,5,2]  R1889     9.2227347195148468e-02
    z[6,5,2]  R1890     1.5809503197669983e-01
    z[6,5,2]  R1891     -1.2670049071311951e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R1840     -1
    z[6,5,3]  R1841     1
    z[6,5,3]  R1848     -6.5172064304351807e-01
    z[6,5,3]  R1849     -1.6469325870275497e-02
    z[6,5,3]  R1850     4.4052770733833313e-01
    z[6,5,3]  R1851     -8.9372701942920685e-02
    z[6,5,3]  R1852     -1.1839209496974945e-01
    z[6,5,3]  R1853     2.5236532092094421e-01
    z[6,5,3]  R1854     2.7716401219367981e-01
    z[6,5,3]  R1855     6.8763040006160736e-02
    z[6,5,3]  R1856     -1.5068550407886505e-01
    z[6,5,3]  R1857     -2.8603699803352356e-01
    z[6,5,3]  R1858     -4.4781614094972610e-02
    z[6,5,3]  R1859     3.0488395690917969e-01
    z[6,5,3]  R1860     2.4808315932750702e-01
    z[6,5,3]  R1861     1.2578254938125610e-01
    z[6,5,3]  R1862     1.8240959942340851e-01
    z[6,5,3]  R1863     3.2359105348587036e-01
    z[6,5,3]  R1864     -0.0447562001645565
    z[6,5,3]  R1865     1.2680643796920776e-01
    z[6,5,3]  R1866     -1.5656933188438416e-01
    z[6,5,3]  R1867     1.3978891074657440e-01
    z[6,5,3]  R1868     2.1200279891490936e-01
    z[6,5,3]  R1869     3.5718372464179993e-01
    z[6,5,3]  R1870     -4.1226732730865479e-01
    z[6,5,3]  R1871     -8.3796960115432739e-01
    z[6,5,3]  R1872     -3.3264175057411194e-01
    z[6,5,3]  R1873     1.0389391332864761e-02
    z[6,5,3]  R1874     -4.9563711881637573e-01
    z[6,5,3]  R1875     4.2500126361846924e-01
    z[6,5,3]  R1876     -4.8035749793052673e-01
    z[6,5,3]  R1877     -3.9550641179084778e-01
    z[6,5,3]  R1878     4.9071967601776123e-01
    z[6,5,3]  R1879     8.5449254512786865e-01
    z[6,5,3]  R1880     5.2628409862518311e-01
    z[6,5,3]  R1881     5.7510995864868164e-01
    z[6,5,3]  R1882     -0.0466766357421875
    z[6,5,3]  R1883     -4.6105778892524540e-04
    z[6,5,3]  R1884     7.8190630674362183e-01
    z[6,5,3]  R1885     7.6712244749069214e-01
    z[6,5,3]  R1886     8.2034456729888916e-01
    z[6,5,3]  R1887     8.3577936887741089e-01
    z[6,5,3]  R1888     1.5298387408256531e-01
    z[6,5,3]  R1889     2.3793998360633850e-01
    z[6,5,3]  R1890     6.0946464538574219e-02
    z[6,5,3]  R1891     1.4294156432151794e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R1842     -1
    z[6,5,4]  R1843     1
    z[6,5,4]  R1848     -3.2583290338516235e-01
    z[6,5,4]  R1849     -2.7821826934814453e-01
    z[6,5,4]  R1850     6.7188933491706848e-02
    z[6,5,4]  R1851     4.7482779622077942e-01
    z[6,5,4]  R1852     -3.6745730042457581e-01
    z[6,5,4]  R1853     -7.8729726374149323e-02
    z[6,5,4]  R1854     2.8432884812355042e-01
    z[6,5,4]  R1855     -4.2871765792369843e-02
    z[6,5,4]  R1856     -2.2973024845123291e-01
    z[6,5,4]  R1857     -1.0809712857007980e-01
    z[6,5,4]  R1858     2.4782599508762360e-01
    z[6,5,4]  R1859     1.1179201304912567e-01
    z[6,5,4]  R1860     -1.4008018374443054e-01
    z[6,5,4]  R1861     -9.2467740178108215e-03
    z[6,5,4]  R1862     -1.9531685113906860e-01
    z[6,5,4]  R1863     2.9183301329612732e-01
    z[6,5,4]  R1864     -5.6745827198028564e-02
    z[6,5,4]  R1865     -1.0065872222185135e-02
    z[6,5,4]  R1866     -3.9776325225830078e-02
    z[6,5,4]  R1867     -1.1228875070810318e-01
    z[6,5,4]  R1868     1.0977048426866531e-01
    z[6,5,4]  R1869     -3.2281684875488281e-01
    z[6,5,4]  R1870     -2.0525366067886353e-01
    z[6,5,4]  R1871     -1.3405166566371918e-01
    z[6,5,4]  R1872     -2.4102728068828583e-01
    z[6,5,4]  R1873     4.5595857501029968e-01
    z[6,5,4]  R1874     1.9341827137395740e-03
    z[6,5,4]  R1875     -3.8472640514373779e-01
    z[6,5,4]  R1876     6.3935375213623047e-01
    z[6,5,4]  R1877     -2.3438097536563873e-01
    z[6,5,4]  R1878     1.7354603111743927e-01
    z[6,5,4]  R1879     -3.6505248397588730e-02
    z[6,5,4]  R1880     -2.9357659816741943e-01
    z[6,5,4]  R1881     -2.3593001067638397e-01
    z[6,5,4]  R1882     -2.1491923928260803e-01
    z[6,5,4]  R1883     1.8646484613418579e-01
    z[6,5,4]  R1884     4.0940508246421814e-01
    z[6,5,4]  R1885     2.5069794058799744e-01
    z[6,5,4]  R1886     1.8114280700683594e-01
    z[6,5,4]  R1887     4.1229769587516785e-01
    z[6,5,4]  R1888     -3.1224167346954346e-01
    z[6,5,4]  R1889     -4.1876533627510071e-01
    z[6,5,4]  R1890     -4.8623114824295044e-01
    z[6,5,4]  R1891     -4.5903232693672180e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R1844     -1
    z[6,5,5]  R1845     1
    z[6,5,5]  R1848     -1.8530496954917908e-01
    z[6,5,5]  R1849     1.6553317010402679e-01
    z[6,5,5]  R1850     -0.708588719367981
    z[6,5,5]  R1851     -0.627094030380249
    z[6,5,5]  R1852     -3.9910188317298889e-01
    z[6,5,5]  R1853     -5.2411708980798721e-02
    z[6,5,5]  R1854     -3.1696256250143051e-02
    z[6,5,5]  R1855     2.5768628716468811e-01
    z[6,5,5]  R1856     -7.2195850312709808e-02
    z[6,5,5]  R1857     -4.4598728418350220e-01
    z[6,5,5]  R1858     4.9739050865173340e-01
    z[6,5,5]  R1859     3.0556204915046692e-01
    z[6,5,5]  R1860     4.5865449309349060e-01
    z[6,5,5]  R1861     1.3495285809040070e-01
    z[6,5,5]  R1862     1.6480810940265656e-01
    z[6,5,5]  R1863     3.9348602294921875e-01
    z[6,5,5]  R1864     -1.7372589558362961e-02
    z[6,5,5]  R1865     -8.6739644408226013e-02
    z[6,5,5]  R1866     4.2810970544815063e-01
    z[6,5,5]  R1867     -0.0961286723613739
    z[6,5,5]  R1868     8.7627187371253967e-02
    z[6,5,5]  R1869     3.2574450969696045e-01
    z[6,5,5]  R1870     3.7828603386878967e-01
    z[6,5,5]  R1871     -7.2894699871540070e-02
    z[6,5,5]  R1872     -5.5353248119354248e-01
    z[6,5,5]  R1873     2.0876155793666840e-01
    z[6,5,5]  R1874     -6.4516419172286987e-01
    z[6,5,5]  R1875     4.8268601298332214e-01
    z[6,5,5]  R1876     1.6855491697788239e-01
    z[6,5,5]  R1877     2.1732540428638458e-01
    z[6,5,5]  R1878     -0.458787202835083
    z[6,5,5]  R1879     -3.8926395773887634e-01
    z[6,5,5]  R1880     -4.3972459435462952e-01
    z[6,5,5]  R1881     6.8293526768684387e-02
    z[6,5,5]  R1882     1.4766024053096771e-01
    z[6,5,5]  R1883     -3.0437666177749634e-01
    z[6,5,5]  R1884     -3.6676400899887085e-01
    z[6,5,5]  R1885     -1.2268547713756561e-01
    z[6,5,5]  R1886     -1.8348152935504913e-01
    z[6,5,5]  R1887     8.8123209774494171e-02
    z[6,5,5]  R1888     -1.1496735364198685e-01
    z[6,5,5]  R1889     -1.8946514464914799e-03
    z[6,5,5]  R1890     -6.5354225225746632e-03
    z[6,5,5]  R1891     -2.9177182912826538e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R1846     -1
    z[6,5,6]  R1847     1
    z[6,5,6]  R1848     2.9365673661231995e-01
    z[6,5,6]  R1849     -8.7102377414703369e-01
    z[6,5,6]  R1850     2.3660773038864136e-01
    z[6,5,6]  R1851     -4.6477177739143372e-01
    z[6,5,6]  R1852     -5.7861721515655518e-01
    z[6,5,6]  R1853     1.8897494673728943e-01
    z[6,5,6]  R1854     -4.1994577646255493e-01
    z[6,5,6]  R1855     -5.1444333791732788e-01
    z[6,5,6]  R1856     -3.9558568596839905e-01
    z[6,5,6]  R1857     -3.3922377228736877e-01
    z[6,5,6]  R1858     1.2285137176513672e-01
    z[6,5,6]  R1859     -1.6898886859416962e-01
    z[6,5,6]  R1860     3.8814555853605270e-02
    z[6,5,6]  R1861     -7.2938792407512665e-02
    z[6,5,6]  R1862     0.409720242023468
    z[6,5,6]  R1863     -6.4630389213562012e-02
    z[6,5,6]  R1864     -2.9128888249397278e-01
    z[6,5,6]  R1865     1.4202875085175037e-02
    z[6,5,6]  R1866     2.3553293943405151e-01
    z[6,5,6]  R1867     5.8336459100246429e-02
    z[6,5,6]  R1868     -1.1622021347284317e-01
    z[6,5,6]  R1869     3.8714310526847839e-01
    z[6,5,6]  R1870     1.6772159934043884e-01
    z[6,5,6]  R1871     -1.5158607065677643e-01
    z[6,5,6]  R1872     5.1912426948547363e-01
    z[6,5,6]  R1873     2.1310560405254364e-01
    z[6,5,6]  R1874     -2.1190728247165680e-01
    z[6,5,6]  R1875     -1.4409545063972473e-01
    z[6,5,6]  R1876     8.1505045294761658e-02
    z[6,5,6]  R1877     8.1839221715927124e-01
    z[6,5,6]  R1878     3.7150415778160095e-01
    z[6,5,6]  R1879     1.8464881181716919e-01
    z[6,5,6]  R1880     5.3933048248291016e-01
    z[6,5,6]  R1881     -2.1135868132114410e-01
    z[6,5,6]  R1882     -6.3240334391593933e-02
    z[6,5,6]  R1883     4.1932859458029270e-03
    z[6,5,6]  R1884     -9.7157590091228485e-02
    z[6,5,6]  R1885     4.7822231054306030e-01
    z[6,5,6]  R1886     -6.0714911669492722e-02
    z[6,5,6]  R1887     -9.5058217644691467e-02
    z[6,5,6]  R1888     -1.6319499909877777e-01
    z[6,5,6]  R1889     -2.0601308345794678e-01
    z[6,5,6]  R1890     0.0339912548661232
    z[6,5,6]  R1891     -5.4190486669540405e-02
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R1892     -1
    z[6,7,0]  R1893     1
    z[6,7,0]  R1906     3.7917536497116089e-01
    z[6,7,0]  R1907     2.5082227587699890e-01
    z[6,7,0]  R1908     4.6135523915290833e-01
    z[6,7,0]  R1909     2.4929250776767731e-01
    z[6,7,0]  R1910     2.0297257602214813e-01
    z[6,7,0]  R1911     -4.8453950881958008e-01
    z[6,7,0]  R1912     -4.7447955608367920e-01
    z[6,7,0]  R1913     -4.8622754216194153e-01
    z[6,7,0]  R1914     -6.0882955789566040e-01
    z[6,7,0]  R1915     -3.2798323035240173e-01
    z[6,7,0]  R1916     0.611726701259613
    z[6,7,0]  R1917     -1.4073152840137482e-01
    z[6,7,0]  R1918     1.6352796927094460e-02
    z[6,7,0]  R1919     3.0225786566734314e-01
    z[6,7,0]  R1920     3.3904369920492172e-02
    z[6,7,0]  R1921     3.6664927005767822e-01
    z[6,7,0]  R1922     -2.3543752729892731e-01
    z[6,7,0]  R1923     -4.1386967897415161e-01
    z[6,7,0]  R1924     1.4240473508834839e-01
    z[6,7,0]  R1925     -2.4127395451068878e-01
    z[6,7,0]  R1926     4.1634678840637207e-01
    z[6,7,0]  R1927     2.6002532243728638e-01
    z[6,7,0]  R1928     -6.0463231801986694e-01
    z[6,7,0]  R1929     4.1484346985816956e-01
    z[6,7,0]  R1930     4.3883144855499268e-01
    z[6,7,0]  R1931     -1.6103708744049072e-01
    z[6,7,0]  R1932     -3.3000677824020386e-01
    z[6,7,0]  R1933     -1.9318053126335144e-01
    z[6,7,0]  R1934     4.9064305424690247e-01
    z[6,7,0]  R1935     5.5800050497055054e-01
    z[6,7,0]  R1936     -5.9474945068359375e-01
    z[6,7,0]  R1937     -7.7611696720123291e-01
    z[6,7,0]  R1938     4.3887776136398315e-01
    z[6,7,0]  R1939     6.3743138313293457e-01
    z[6,7,0]  R1940     -4.6591654419898987e-01
    z[6,7,0]  R1941     -2.5724855065345764e-01
    z[6,7,0]  R1942     -5.5511754751205444e-01
    z[6,7,0]  R1943     -4.3864867091178894e-01
    z[6,7,0]  R1944     -3.7472385168075562e-01
    z[6,7,0]  R1945     -2.4024071171879768e-02
    z[6,7,0]  R1946     -1.2539096176624298e-01
    z[6,7,0]  R1947     2.6647349819540977e-02
    z[6,7,0]  R1948     -1.1489200592041016e-01
    z[6,7,0]  R1949     7.2174452245235443e-02
    z[6,7,0]  R1950     3.5291427373886108e-01
    z[6,7,0]  R1951     1.0750346630811691e-01
    z[6,7,0]  R1952     -7.1135139465332031e-01
    z[6,7,0]  R1953     -3.4161310642957687e-02
    z[6,7,0]  R1954     3.7471893429756165e-01
    z[6,7,0]  R1955     4.9668571352958679e-01
    z[6,7,0]  R1956     0.684753954410553
    z[6,7,0]  R1957     -5.9296840429306030e-01
    z[6,7,0]  R1958     3.5663238167762756e-01
    z[6,7,0]  R1959     7.0555794239044189e-01
    z[6,7,0]  R1960     -2.3794497549533844e-01
    z[6,7,0]  R1961     8.1550484895706177e-01
    z[6,7,0]  R1962     -4.4572320580482483e-01
    z[6,7,0]  R1963     7.0636653900146484e-01
    z[6,7,0]  R1964     8.5536980628967285e-01
    z[6,7,0]  R1965     -3.6302644759416580e-02
    z[6,7,0]  R1966     4.8077669739723206e-01
    z[6,7,0]  R1967     4.7387238591909409e-03
    z[6,7,0]  R1968     -3.0232161283493042e-01
    z[6,7,0]  R1969     -5.8349866420030594e-02
    z[6,7,0]  R1970     5.1991915702819824e-01
    z[6,7,0]  R1971     2.0899994671344757e-01
    z[6,7,0]  R1972     9.2597460746765137e-01
    z[6,7,0]  R1973     -4.4014748930931091e-01
    z[6,7,0]  R1974     -1.8470740318298340e-01
    z[6,7,0]  R1975     -4.0540158748626709e-01
    z[6,7,0]  R1976     -9.2076942324638367e-02
    z[6,7,0]  R1977     -1.0966061055660248e-01
    z[6,7,0]  R1978     -2.7392736077308655e-01
    z[6,7,0]  R1979     0.1094965711236
    z[6,7,0]  R1980     -5.1310116052627563e-01
    z[6,7,0]  R1981     -3.0629462003707886e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R1894     -1
    z[6,7,1]  R1895     1
    z[6,7,1]  R1906     3.3059012889862061e-01
    z[6,7,1]  R1907     2.6292881369590759e-01
    z[6,7,1]  R1908     1.2327650189399719e-01
    z[6,7,1]  R1909     5.6456193327903748e-02
    z[6,7,1]  R1910     -5.2283253520727158e-02
    z[6,7,1]  R1911     -8.1001192331314087e-01
    z[6,7,1]  R1912     -6.4875560998916626e-01
    z[6,7,1]  R1913     -0.633316159248352
    z[6,7,1]  R1914     -6.1103403568267822e-01
    z[6,7,1]  R1915     -6.8792277574539185e-01
    z[6,7,1]  R1916     -5.4759508371353149e-01
    z[6,7,1]  R1917     8.5497468709945679e-01
    z[6,7,1]  R1918     0.834886908531189
    z[6,7,1]  R1919     9.2395859956741333e-01
    z[6,7,1]  R1920     8.5465639829635620e-01
    z[6,7,1]  R1921     7.1587729454040527e-01
    z[6,7,1]  R1922     9.1652947664260864e-01
    z[6,7,1]  R1923     8.3058446645736694e-01
    z[6,7,1]  R1924     8.0805647373199463e-01
    z[6,7,1]  R1925     9.3558359146118164e-01
    z[6,7,1]  R1926     0.853506863117218
    z[6,7,1]  R1927     5.3388422727584839e-01
    z[6,7,1]  R1928     -2.7932587265968323e-01
    z[6,7,1]  R1929     2.8157082200050354e-01
    z[6,7,1]  R1930     -1.8062831461429596e-01
    z[6,7,1]  R1931     2.1448570489883423e-01
    z[6,7,1]  R1932     -6.6300463676452637e-01
    z[6,7,1]  R1933     -2.9880064725875854e-01
    z[6,7,1]  R1934     -1.4812584221363068e-01
    z[6,7,1]  R1935     -4.7706909477710724e-02
    z[6,7,1]  R1936     -4.4924414157867432e-01
    z[6,7,1]  R1937     -2.1809792518615723e-01
    z[6,7,1]  R1938     -1.2928212061524391e-02
    z[6,7,1]  R1939     -1.7264668643474579e-01
    z[6,7,1]  R1940     -5.9217959642410278e-01
    z[6,7,1]  R1941     -0.657151460647583
    z[6,7,1]  R1942     3.5223123431205750e-01
    z[6,7,1]  R1943     6.1220955848693848e-01
    z[6,7,1]  R1944     2.0237313210964203e-01
    z[6,7,1]  R1945     8.1670624017715454e-01
    z[6,7,1]  R1946     8.9486467838287354e-01
    z[6,7,1]  R1947     8.2600003480911255e-01
    z[6,7,1]  R1948     0.843882143497467
    z[6,7,1]  R1949     7.5049263238906860e-01
    z[6,7,1]  R1950     7.9955446720123291e-01
    z[6,7,1]  R1951     7.8682017326354980e-01
    z[6,7,1]  R1952     1.5438741445541382e-01
    z[6,7,1]  R1953     -1.8111892044544220e-02
    z[6,7,1]  R1954     6.3355618715286255e-01
    z[6,7,1]  R1955     -7.0401608943939209e-01
    z[6,7,1]  R1956     -0.317990779876709
    z[6,7,1]  R1957     -9.9937207996845245e-02
    z[6,7,1]  R1958     1.9208516925573349e-02
    z[6,7,1]  R1959     -6.1492401361465454e-01
    z[6,7,1]  R1960     8.4363776445388794e-01
    z[6,7,1]  R1961     2.1581551432609558e-01
    z[6,7,1]  R1962     1.5701790153980255e-01
    z[6,7,1]  R1963     -2.6684790849685669e-01
    z[6,7,1]  R1964     1.1021289043128490e-02
    z[6,7,1]  R1965     -5.6431031227111816e-01
    z[6,7,1]  R1966     -4.5959058403968811e-01
    z[6,7,1]  R1967     -0.362327516078949
    z[6,7,1]  R1968     -4.4981494545936584e-01
    z[6,7,1]  R1969     -6.6127836704254150e-01
    z[6,7,1]  R1970     6.1683690547943115e-01
    z[6,7,1]  R1971     -4.4729864597320557e-01
    z[6,7,1]  R1972     7.0814952254295349e-02
    z[6,7,1]  R1973     -6.2575900554656982e-01
    z[6,7,1]  R1974     -2.5553995370864868e-01
    z[6,7,1]  R1975     1.3084186613559723e-01
    z[6,7,1]  R1976     0.917531430721283
    z[6,7,1]  R1977     8.5602718591690063e-01
    z[6,7,1]  R1978     7.6393014192581177e-01
    z[6,7,1]  R1979     8.8324540853500366e-01
    z[6,7,1]  R1980     2.7826756238937378e-01
    z[6,7,1]  R1981     0.284063458442688
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R1896     -1
    z[6,7,2]  R1897     1
    z[6,7,2]  R1906     -3.0896124243736267e-01
    z[6,7,2]  R1907     -6.4777895808219910e-02
    z[6,7,2]  R1908     -1.2366840243339539e-01
    z[6,7,2]  R1909     -3.0324435234069824e-01
    z[6,7,2]  R1910     5.5941653251647949e-01
    z[6,7,2]  R1911     -2.7511458843946457e-02
    z[6,7,2]  R1912     -1.3770723342895508e-01
    z[6,7,2]  R1913     1.5771174430847168e-01
    z[6,7,2]  R1914     1.3704569637775421e-01
    z[6,7,2]  R1915     1.0821133852005005e-01
    z[6,7,2]  R1916     -4.1420180350542068e-03
    z[6,7,2]  R1917     -1.4776925742626190e-01
    z[6,7,2]  R1918     9.8275601863861084e-02
    z[6,7,2]  R1919     1.2450519204139709e-01
    z[6,7,2]  R1920     -4.4256478548049927e-02
    z[6,7,2]  R1921     -6.4823113381862640e-02
    z[6,7,2]  R1922     -1.1903249472379684e-01
    z[6,7,2]  R1923     -3.3901998400688171e-01
    z[6,7,2]  R1924     -2.4882888793945312e-01
    z[6,7,2]  R1925     -1.4723014831542969e-01
    z[6,7,2]  R1926     1.4142517745494843e-01
    z[6,7,2]  R1927     3.9946746826171875e-01
    z[6,7,2]  R1928     -4.1601985692977905e-01
    z[6,7,2]  R1929     1.2957191094756126e-02
    z[6,7,2]  R1930     1.7368771135807037e-01
    z[6,7,2]  R1931     -7.9439365863800049e-01
    z[6,7,2]  R1932     5.8374935388565063e-01
    z[6,7,2]  R1933     8.0793273448944092e-01
    z[6,7,2]  R1934     -7.4482011795043945e-01
    z[6,7,2]  R1935     -4.6082508563995361e-01
    z[6,7,2]  R1936     -2.1176628768444061e-01
    z[6,7,2]  R1937     -8.0369219183921814e-02
    z[6,7,2]  R1938     -7.9732966423034668e-01
    z[6,7,2]  R1939     -4.7009339928627014e-01
    z[6,7,2]  R1940     -2.0089778304100037e-01
    z[6,7,2]  R1941     -3.6613121628761292e-01
    z[6,7,2]  R1942     1.0949367284774780e-01
    z[6,7,2]  R1943     1.8620106577873230e-01
    z[6,7,2]  R1944     -1.1659797281026840e-01
    z[6,7,2]  R1945     -1.3814368844032288e-01
    z[6,7,2]  R1946     -5.3273785859346390e-02
    z[6,7,2]  R1947     1.5876792371273041e-01
    z[6,7,2]  R1948     -1.3258361816406250e-01
    z[6,7,2]  R1949     -3.5112169384956360e-01
    z[6,7,2]  R1950     1.8139155209064484e-01
    z[6,7,2]  R1951     1.8230681121349335e-01
    z[6,7,2]  R1952     -7.3565311729907990e-02
    z[6,7,2]  R1953     -0.0978657677769661
    z[6,7,2]  R1954     -0.320696085691452
    z[6,7,2]  R1955     1.4854307286441326e-02
    z[6,7,2]  R1956     -5.3830850869417191e-02
    z[6,7,2]  R1957     9.4093732535839081e-02
    z[6,7,2]  R1958     3.3875682950019836e-01
    z[6,7,2]  R1959     9.6524387598037720e-02
    z[6,7,2]  R1960     -1.1402054876089096e-01
    z[6,7,2]  R1961     3.4367090463638306e-01
    z[6,7,2]  R1962     5.2205115556716919e-01
    z[6,7,2]  R1963     -4.3683147430419922e-01
    z[6,7,2]  R1964     -1.9336020573973656e-02
    z[6,7,2]  R1965     -3.9456307888031006e-01
    z[6,7,2]  R1966     1.4970616437494755e-02
    z[6,7,2]  R1967     -2.2499936819076538e-01
    z[6,7,2]  R1968     -3.0829888582229614e-01
    z[6,7,2]  R1969     -5.0885128974914551e-01
    z[6,7,2]  R1970     -1.9861342012882233e-01
    z[6,7,2]  R1971     1.7511947453022003e-01
    z[6,7,2]  R1972     -8.4100671112537384e-02
    z[6,7,2]  R1973     -3.9988321065902710e-01
    z[6,7,2]  R1974     -1.9476985931396484e-01
    z[6,7,2]  R1975     -1.7199251055717468e-01
    z[6,7,2]  R1976     9.7669489681720734e-02
    z[6,7,2]  R1977     9.2239312827587128e-02
    z[6,7,2]  R1978     2.9931798577308655e-01
    z[6,7,2]  R1979     2.7387386560440063e-01
    z[6,7,2]  R1980     -2.5816044211387634e-01
    z[6,7,2]  R1981     7.1744687855243683e-02
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R1898     -1
    z[6,7,3]  R1899     1
    z[6,7,3]  R1906     -6.5172064304351807e-01
    z[6,7,3]  R1907     -1.6469325870275497e-02
    z[6,7,3]  R1908     4.4052770733833313e-01
    z[6,7,3]  R1909     -8.9372701942920685e-02
    z[6,7,3]  R1910     -1.1839209496974945e-01
    z[6,7,3]  R1911     2.5236532092094421e-01
    z[6,7,3]  R1912     2.7716401219367981e-01
    z[6,7,3]  R1913     6.8763040006160736e-02
    z[6,7,3]  R1914     -1.5068550407886505e-01
    z[6,7,3]  R1915     -2.8603699803352356e-01
    z[6,7,3]  R1916     -4.4781614094972610e-02
    z[6,7,3]  R1917     3.0488395690917969e-01
    z[6,7,3]  R1918     2.4808315932750702e-01
    z[6,7,3]  R1919     1.2578254938125610e-01
    z[6,7,3]  R1920     1.8240959942340851e-01
    z[6,7,3]  R1921     3.2359105348587036e-01
    z[6,7,3]  R1922     -0.0447562001645565
    z[6,7,3]  R1923     1.2680643796920776e-01
    z[6,7,3]  R1924     -1.5656933188438416e-01
    z[6,7,3]  R1925     1.3978891074657440e-01
    z[6,7,3]  R1926     2.1200279891490936e-01
    z[6,7,3]  R1927     3.5718372464179993e-01
    z[6,7,3]  R1928     -4.1226732730865479e-01
    z[6,7,3]  R1929     -8.3796960115432739e-01
    z[6,7,3]  R1930     -3.3264175057411194e-01
    z[6,7,3]  R1931     1.0389391332864761e-02
    z[6,7,3]  R1932     -2.9626250267028809e-01
    z[6,7,3]  R1933     -2.2999028861522675e-01
    z[6,7,3]  R1934     7.5844698585569859e-03
    z[6,7,3]  R1935     1.7470827698707581e-01
    z[6,7,3]  R1936     -2.3054596781730652e-01
    z[6,7,3]  R1937     4.2941838502883911e-02
    z[6,7,3]  R1938     2.6938286423683167e-01
    z[6,7,3]  R1939     -1.8347822129726410e-01
    z[6,7,3]  R1940     2.2835057228803635e-02
    z[6,7,3]  R1941     -1.2176606059074402e-01
    z[6,7,3]  R1942     -3.1238058209419250e-01
    z[6,7,3]  R1943     -5.3936600685119629e-01
    z[6,7,3]  R1944     -4.5483273267745972e-01
    z[6,7,3]  R1945     2.3717571794986725e-01
    z[6,7,3]  R1946     2.7579271793365479e-01
    z[6,7,3]  R1947     4.7326812148094177e-01
    z[6,7,3]  R1948     2.3212619125843048e-01
    z[6,7,3]  R1949     2.2987088561058044e-01
    z[6,7,3]  R1950     1.3276745565235615e-02
    z[6,7,3]  R1951     1.1353657394647598e-01
    z[6,7,3]  R1952     -4.2610099911689758e-01
    z[6,7,3]  R1953     -0.831956684589386
    z[6,7,3]  R1954     -1.8074707686901093e-01
    z[6,7,3]  R1955     -6.4651817083358765e-02
    z[6,7,3]  R1956     5.5095356702804565e-01
    z[6,7,3]  R1957     4.2653241753578186e-01
    z[6,7,3]  R1958     -6.2758159637451172e-01
    z[6,7,3]  R1959     2.6210615038871765e-01
    z[6,7,3]  R1960     -2.9034152626991272e-01
    z[6,7,3]  R1961     3.8065189123153687e-01
    z[6,7,3]  R1962     -4.4731894135475159e-01
    z[6,7,3]  R1963     1.5225636959075928e-01
    z[6,7,3]  R1964     9.2400491237640381e-02
    z[6,7,3]  R1965     -5.3684246540069580e-01
    z[6,7,3]  R1966     -5.3731977939605713e-01
    z[6,7,3]  R1967     -4.2891547083854675e-01
    z[6,7,3]  R1968     -5.2493758499622345e-02
    z[6,7,3]  R1969     -1.6123464331030846e-02
    z[6,7,3]  R1970     4.0416544675827026e-01
    z[6,7,3]  R1971     -3.1007694080471992e-02
    z[6,7,3]  R1972     9.0601757168769836e-02
    z[6,7,3]  R1973     -1.4374026656150818e-01
    z[6,7,3]  R1974     -6.5655320882797241e-01
    z[6,7,3]  R1975     -7.1335101127624512e-01
    z[6,7,3]  R1976     2.9495763778686523e-01
    z[6,7,3]  R1977     1.6936121881008148e-01
    z[6,7,3]  R1978     4.0316984057426453e-01
    z[6,7,3]  R1979     7.5238578021526337e-02
    z[6,7,3]  R1980     0.525577962398529
    z[6,7,3]  R1981     5.8198040723800659e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R1900     -1
    z[6,7,4]  R1901     1
    z[6,7,4]  R1906     -3.2583290338516235e-01
    z[6,7,4]  R1907     -2.7821826934814453e-01
    z[6,7,4]  R1908     6.7188933491706848e-02
    z[6,7,4]  R1909     4.7482779622077942e-01
    z[6,7,4]  R1910     -3.6745730042457581e-01
    z[6,7,4]  R1911     -7.8729726374149323e-02
    z[6,7,4]  R1912     2.8432884812355042e-01
    z[6,7,4]  R1913     -4.2871765792369843e-02
    z[6,7,4]  R1914     -2.2973024845123291e-01
    z[6,7,4]  R1915     -1.0809712857007980e-01
    z[6,7,4]  R1916     2.4782599508762360e-01
    z[6,7,4]  R1917     1.1179201304912567e-01
    z[6,7,4]  R1918     -1.4008018374443054e-01
    z[6,7,4]  R1919     -9.2467740178108215e-03
    z[6,7,4]  R1920     -1.9531685113906860e-01
    z[6,7,4]  R1921     2.9183301329612732e-01
    z[6,7,4]  R1922     -5.6745827198028564e-02
    z[6,7,4]  R1923     -1.0065872222185135e-02
    z[6,7,4]  R1924     -3.9776325225830078e-02
    z[6,7,4]  R1925     -1.1228875070810318e-01
    z[6,7,4]  R1926     1.0977048426866531e-01
    z[6,7,4]  R1927     -3.2281684875488281e-01
    z[6,7,4]  R1928     -2.0525366067886353e-01
    z[6,7,4]  R1929     -1.3405166566371918e-01
    z[6,7,4]  R1930     -2.4102728068828583e-01
    z[6,7,4]  R1931     4.5595857501029968e-01
    z[6,7,4]  R1932     5.2010606974363327e-02
    z[6,7,4]  R1933     -4.9195386469364166e-02
    z[6,7,4]  R1934     -3.7985664606094360e-01
    z[6,7,4]  R1935     -3.5559251904487610e-01
    z[6,7,4]  R1936     -1.4419960975646973e-01
    z[6,7,4]  R1937     7.9924903810024261e-02
    z[6,7,4]  R1938     3.2121084630489349e-02
    z[6,7,4]  R1939     -2.4918870627880096e-01
    z[6,7,4]  R1940     4.4314138591289520e-02
    z[6,7,4]  R1941     0.00996498391032219
    z[6,7,4]  R1942     3.6694124341011047e-01
    z[6,7,4]  R1943     -9.8868340253829956e-02
    z[6,7,4]  R1944     3.3180806785821915e-02
    z[6,7,4]  R1945     -2.1452265977859497e-01
    z[6,7,4]  R1946     2.3530666530132294e-01
    z[6,7,4]  R1947     1.8888242542743683e-01
    z[6,7,4]  R1948     -1.1103283613920212e-01
    z[6,7,4]  R1949     -7.7681474387645721e-02
    z[6,7,4]  R1950     -3.5406225919723511e-01
    z[6,7,4]  R1951     -8.9405968785285950e-02
    z[6,7,4]  R1952     1.9480755925178528e-01
    z[6,7,4]  R1953     -3.7798702716827393e-01
    z[6,7,4]  R1954     -3.4833812713623047e-01
    z[6,7,4]  R1955     -3.1084150075912476e-02
    z[6,7,4]  R1956     2.5017036125063896e-02
    z[6,7,4]  R1957     5.4205763339996338e-01
    z[6,7,4]  R1958     -3.4216997027397156e-01
    z[6,7,4]  R1959     -1.6029420495033264e-01
    z[6,7,4]  R1960     -2.3251923918724060e-01
    z[6,7,4]  R1961     -6.6043063998222351e-02
    z[6,7,4]  R1962     2.3488023877143860e-01
    z[6,7,4]  R1963     -4.9218330532312393e-02
    z[6,7,4]  R1964     -4.6918958425521851e-01
    z[6,7,4]  R1965     -0.301287978887558
    z[6,7,4]  R1966     -4.6428516507148743e-01
    z[6,7,4]  R1967     4.8834286630153656e-02
    z[6,7,4]  R1968     4.9995416402816772e-01
    z[6,7,4]  R1969     3.2148233056068420e-01
    z[6,7,4]  R1970     -2.7205618098378181e-02
    z[6,7,4]  R1971     3.8036105036735535e-01
    z[6,7,4]  R1972     -2.8200012445449829e-01
    z[6,7,4]  R1973     3.2433885335922241e-01
    z[6,7,4]  R1974     -4.2623001337051392e-01
    z[6,7,4]  R1975     -3.2421517372131348e-01
    z[6,7,4]  R1976     -1.0389124974608421e-02
    z[6,7,4]  R1977     1.0767946392297745e-01
    z[6,7,4]  R1978     2.7785351872444153e-01
    z[6,7,4]  R1979     -0.157674640417099
    z[6,7,4]  R1980     -5.0214350223541260e-01
    z[6,7,4]  R1981     -0.654729962348938
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R1902     -1
    z[6,7,5]  R1903     1
    z[6,7,5]  R1906     -1.8530496954917908e-01
    z[6,7,5]  R1907     1.6553317010402679e-01
    z[6,7,5]  R1908     -0.708588719367981
    z[6,7,5]  R1909     -0.627094030380249
    z[6,7,5]  R1910     -3.9910188317298889e-01
    z[6,7,5]  R1911     -5.2411708980798721e-02
    z[6,7,5]  R1912     -3.1696256250143051e-02
    z[6,7,5]  R1913     2.5768628716468811e-01
    z[6,7,5]  R1914     -7.2195850312709808e-02
    z[6,7,5]  R1915     -4.4598728418350220e-01
    z[6,7,5]  R1916     4.9739050865173340e-01
    z[6,7,5]  R1917     3.0556204915046692e-01
    z[6,7,5]  R1918     4.5865449309349060e-01
    z[6,7,5]  R1919     1.3495285809040070e-01
    z[6,7,5]  R1920     1.6480810940265656e-01
    z[6,7,5]  R1921     3.9348602294921875e-01
    z[6,7,5]  R1922     -1.7372589558362961e-02
    z[6,7,5]  R1923     -8.6739644408226013e-02
    z[6,7,5]  R1924     4.2810970544815063e-01
    z[6,7,5]  R1925     -0.0961286723613739
    z[6,7,5]  R1926     8.7627187371253967e-02
    z[6,7,5]  R1927     3.2574450969696045e-01
    z[6,7,5]  R1928     3.7828603386878967e-01
    z[6,7,5]  R1929     -7.2894699871540070e-02
    z[6,7,5]  R1930     -5.5353248119354248e-01
    z[6,7,5]  R1931     2.0876155793666840e-01
    z[6,7,5]  R1932     9.0704366564750671e-02
    z[6,7,5]  R1933     -0.371353417634964
    z[6,7,5]  R1934     -8.5436321794986725e-02
    z[6,7,5]  R1935     -5.0231724977493286e-01
    z[6,7,5]  R1936     1.2283550947904587e-01
    z[6,7,5]  R1937     6.5591067075729370e-02
    z[6,7,5]  R1938     -1.9198393821716309e-01
    z[6,7,5]  R1939     4.0160372853279114e-01
    z[6,7,5]  R1940     -4.7288224101066589e-01
    z[6,7,5]  R1941     -5.7962954044342041e-01
    z[6,7,5]  R1942     0.0172764640301466
    z[6,7,5]  R1943     2.7332261204719543e-01
    z[6,7,5]  R1944     7.2685825824737549e-01
    z[6,7,5]  R1945     1.6292506456375122e-01
    z[6,7,5]  R1946     1.6098989173769951e-02
    z[6,7,5]  R1947     1.7929413914680481e-01
    z[6,7,5]  R1948     -3.2500532269477844e-01
    z[6,7,5]  R1949     4.8621863126754761e-01
    z[6,7,5]  R1950     2.1258804202079773e-01
    z[6,7,5]  R1951     5.5858159065246582e-01
    z[6,7,5]  R1952     -4.1165664792060852e-01
    z[6,7,5]  R1953     -3.1215471029281616e-01
    z[6,7,5]  R1954     4.4235071539878845e-01
    z[6,7,5]  R1955     -4.2363211512565613e-01
    z[6,7,5]  R1956     0.342980295419693
    z[6,7,5]  R1957     3.8639730215072632e-01
    z[6,7,5]  R1958     3.9249747991561890e-01
    z[6,7,5]  R1959     2.8783757239580154e-02
    z[6,7,5]  R1960     1.5860473737120628e-02
    z[6,7,5]  R1961     4.1492480784654617e-02
    z[6,7,5]  R1962     1.9243466854095459e-01
    z[6,7,5]  R1963     3.4419283270835876e-01
    z[6,7,5]  R1964     -1.6354827675968409e-03
    z[6,7,5]  R1965     3.7612563371658325e-01
    z[6,7,5]  R1966     -2.1952450275421143e-01
    z[6,7,5]  R1967     -6.0261303186416626e-01
    z[6,7,5]  R1968     -1.1767259798943996e-02
    z[6,7,5]  R1969     1.1409191787242889e-01
    z[6,7,5]  R1970     3.6852625012397766e-01
    z[6,7,5]  R1971     -2.3361924290657043e-01
    z[6,7,5]  R1972     -4.2329076677560806e-02
    z[6,7,5]  R1973     2.6129499077796936e-01
    z[6,7,5]  R1974     -4.6530234813690186e-01
    z[6,7,5]  R1975     4.0940031409263611e-01
    z[6,7,5]  R1976     9.7915731370449066e-02
    z[6,7,5]  R1977     4.4756886363029480e-01
    z[6,7,5]  R1978     -1.0332090407609940e-01
    z[6,7,5]  R1979     -3.1056505441665649e-01
    z[6,7,5]  R1980     -3.5141382366418839e-02
    z[6,7,5]  R1981     -2.0326366648077965e-02
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R1904     -1
    z[6,7,6]  R1905     1
    z[6,7,6]  R1906     2.9365673661231995e-01
    z[6,7,6]  R1907     -8.7102377414703369e-01
    z[6,7,6]  R1908     2.3660773038864136e-01
    z[6,7,6]  R1909     -4.6477177739143372e-01
    z[6,7,6]  R1910     -5.7861721515655518e-01
    z[6,7,6]  R1911     1.8897494673728943e-01
    z[6,7,6]  R1912     -4.1994577646255493e-01
    z[6,7,6]  R1913     -5.1444333791732788e-01
    z[6,7,6]  R1914     -3.9558568596839905e-01
    z[6,7,6]  R1915     -3.3922377228736877e-01
    z[6,7,6]  R1916     1.2285137176513672e-01
    z[6,7,6]  R1917     -1.6898886859416962e-01
    z[6,7,6]  R1918     3.8814555853605270e-02
    z[6,7,6]  R1919     -7.2938792407512665e-02
    z[6,7,6]  R1920     0.409720242023468
    z[6,7,6]  R1921     -6.4630389213562012e-02
    z[6,7,6]  R1922     -2.9128888249397278e-01
    z[6,7,6]  R1923     1.4202875085175037e-02
    z[6,7,6]  R1924     2.3553293943405151e-01
    z[6,7,6]  R1925     5.8336459100246429e-02
    z[6,7,6]  R1926     -1.1622021347284317e-01
    z[6,7,6]  R1927     3.8714310526847839e-01
    z[6,7,6]  R1928     1.6772159934043884e-01
    z[6,7,6]  R1929     -1.5158607065677643e-01
    z[6,7,6]  R1930     5.1912426948547363e-01
    z[6,7,6]  R1931     2.1310560405254364e-01
    z[6,7,6]  R1932     -1.0978800803422928e-01
    z[6,7,6]  R1933     -1.6560514271259308e-01
    z[6,7,6]  R1934     -1.7584989964962006e-01
    z[6,7,6]  R1935     -2.5437775254249573e-01
    z[6,7,6]  R1936     -5.5729198455810547e-01
    z[6,7,6]  R1937     -5.7539767026901245e-01
    z[6,7,6]  R1938     2.4703799188137054e-01
    z[6,7,6]  R1939     2.9298740625381470e-01
    z[6,7,6]  R1940     -4.0716385841369629e-01
    z[6,7,6]  R1941     -1.3048562407493591e-01
    z[6,7,6]  R1942     5.6856197118759155e-01
    z[6,7,6]  R1943     1.5073230862617493e-01
    z[6,7,6]  R1944     2.6217430830001831e-01
    z[6,7,6]  R1945     -4.2954996228218079e-01
    z[6,7,6]  R1946     2.2128300368785858e-01
    z[6,7,6]  R1947     9.7023620037361979e-04
    z[6,7,6]  R1948     -2.9196760058403015e-01
    z[6,7,6]  R1949     -1.1393678933382034e-01
    z[6,7,6]  R1950     -1.8036429584026337e-01
    z[6,7,6]  R1951     -0.0567796565592289
    z[6,7,6]  R1952     2.7524289488792419e-01
    z[6,7,6]  R1953     2.3761428892612457e-01
    z[6,7,6]  R1954     7.5254611670970917e-02
    z[6,7,6]  R1955     2.6987710595130920e-01
    z[6,7,6]  R1956     -7.2697363793849945e-02
    z[6,7,6]  R1957     -6.6993035376071930e-02
    z[6,7,6]  R1958     3.0445849895477295e-01
    z[6,7,6]  R1959     -1.3970334827899933e-01
    z[6,7,6]  R1960     -2.8291681408882141e-01
    z[6,7,6]  R1961     1.3887633383274078e-01
    z[6,7,6]  R1962     4.6026587486267090e-01
    z[6,7,6]  R1963     3.0812928080558777e-01
    z[6,7,6]  R1964     -1.9790825247764587e-01
    z[6,7,6]  R1965     -6.4118191599845886e-02
    z[6,7,6]  R1966     7.0299096405506134e-02
    z[6,7,6]  R1967     5.1824301481246948e-01
    z[6,7,6]  R1968     0.598641574382782
    z[6,7,6]  R1969     4.2865911126136780e-01
    z[6,7,6]  R1970     9.9234811961650848e-02
    z[6,7,6]  R1971     7.2481870651245117e-01
    z[6,7,6]  R1972     2.0238281786441803e-01
    z[6,7,6]  R1973     2.4628686904907227e-01
    z[6,7,6]  R1974     -1.8277524411678314e-01
    z[6,7,6]  R1975     -8.5760496556758881e-02
    z[6,7,6]  R1976     -2.0838232338428497e-01
    z[6,7,6]  R1977     7.8025534749031067e-02
    z[6,7,6]  R1978     -3.6871105432510376e-02
    z[6,7,6]  R1979     -7.6866008341312408e-02
    z[6,7,6]  R1980     2.5106236338615417e-01
    z[6,7,6]  R1981     2.2925668954849243e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R1982     -1
    z[7,6,0]  R1983     1
    z[7,6,0]  R1996     -3.3000677824020386e-01
    z[7,6,0]  R1997     -1.9318053126335144e-01
    z[7,6,0]  R1998     4.9064305424690247e-01
    z[7,6,0]  R1999     5.5800050497055054e-01
    z[7,6,0]  R2000     -5.9474945068359375e-01
    z[7,6,0]  R2001     -7.7611696720123291e-01
    z[7,6,0]  R2002     4.3887776136398315e-01
    z[7,6,0]  R2003     6.3743138313293457e-01
    z[7,6,0]  R2004     -4.6591654419898987e-01
    z[7,6,0]  R2005     -2.5724855065345764e-01
    z[7,6,0]  R2006     -5.5511754751205444e-01
    z[7,6,0]  R2007     -4.3864867091178894e-01
    z[7,6,0]  R2008     -3.7472385168075562e-01
    z[7,6,0]  R2009     -2.4024071171879768e-02
    z[7,6,0]  R2010     -1.2539096176624298e-01
    z[7,6,0]  R2011     2.6647349819540977e-02
    z[7,6,0]  R2012     -1.1489200592041016e-01
    z[7,6,0]  R2013     7.2174452245235443e-02
    z[7,6,0]  R2014     3.5291427373886108e-01
    z[7,6,0]  R2015     1.0750346630811691e-01
    z[7,6,0]  R2016     -7.1135139465332031e-01
    z[7,6,0]  R2017     -3.4161310642957687e-02
    z[7,6,0]  R2018     3.7471893429756165e-01
    z[7,6,0]  R2019     4.9668571352958679e-01
    z[7,6,0]  R2020     0.684753954410553
    z[7,6,0]  R2021     -5.9296840429306030e-01
    z[7,6,0]  R2022     3.5663238167762756e-01
    z[7,6,0]  R2023     7.0555794239044189e-01
    z[7,6,0]  R2024     -2.3794497549533844e-01
    z[7,6,0]  R2025     8.1550484895706177e-01
    z[7,6,0]  R2026     -4.4572320580482483e-01
    z[7,6,0]  R2027     7.0636653900146484e-01
    z[7,6,0]  R2028     8.5536980628967285e-01
    z[7,6,0]  R2029     -3.6302644759416580e-02
    z[7,6,0]  R2030     4.8077669739723206e-01
    z[7,6,0]  R2031     4.7387238591909409e-03
    z[7,6,0]  R2032     -3.0232161283493042e-01
    z[7,6,0]  R2033     -5.8349866420030594e-02
    z[7,6,0]  R2034     5.1991915702819824e-01
    z[7,6,0]  R2035     2.0899994671344757e-01
    z[7,6,0]  R2036     9.2597460746765137e-01
    z[7,6,0]  R2037     -4.4014748930931091e-01
    z[7,6,0]  R2038     -1.8470740318298340e-01
    z[7,6,0]  R2039     -4.0540158748626709e-01
    z[7,6,0]  R2040     -9.2076942324638367e-02
    z[7,6,0]  R2041     -1.0966061055660248e-01
    z[7,6,0]  R2042     -2.7392736077308655e-01
    z[7,6,0]  R2043     0.1094965711236
    z[7,6,0]  R2044     -5.1310116052627563e-01
    z[7,6,0]  R2045     -3.0629462003707886e-01
    z[7,6,0]  R2046     3.7917536497116089e-01
    z[7,6,0]  R2047     2.5082227587699890e-01
    z[7,6,0]  R2048     4.6135523915290833e-01
    z[7,6,0]  R2049     2.4929250776767731e-01
    z[7,6,0]  R2050     2.0297257602214813e-01
    z[7,6,0]  R2051     -4.8453950881958008e-01
    z[7,6,0]  R2052     -4.7447955608367920e-01
    z[7,6,0]  R2053     -4.8622754216194153e-01
    z[7,6,0]  R2054     -6.0882955789566040e-01
    z[7,6,0]  R2055     -3.2798323035240173e-01
    z[7,6,0]  R2056     0.611726701259613
    z[7,6,0]  R2057     -1.4073152840137482e-01
    z[7,6,0]  R2058     1.6352796927094460e-02
    z[7,6,0]  R2059     3.0225786566734314e-01
    z[7,6,0]  R2060     3.3904369920492172e-02
    z[7,6,0]  R2061     3.6664927005767822e-01
    z[7,6,0]  R2062     -2.3543752729892731e-01
    z[7,6,0]  R2063     -4.1386967897415161e-01
    z[7,6,0]  R2064     1.4240473508834839e-01
    z[7,6,0]  R2065     -2.4127395451068878e-01
    z[7,6,0]  R2066     4.1634678840637207e-01
    z[7,6,0]  R2067     2.6002532243728638e-01
    z[7,6,0]  R2068     -6.0463231801986694e-01
    z[7,6,0]  R2069     4.1484346985816956e-01
    z[7,6,0]  R2070     4.3883144855499268e-01
    z[7,6,0]  R2071     -1.6103708744049072e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R1984     -1
    z[7,6,1]  R1985     1
    z[7,6,1]  R1996     -6.6300463676452637e-01
    z[7,6,1]  R1997     -2.9880064725875854e-01
    z[7,6,1]  R1998     -1.4812584221363068e-01
    z[7,6,1]  R1999     -4.7706909477710724e-02
    z[7,6,1]  R2000     -4.4924414157867432e-01
    z[7,6,1]  R2001     -2.1809792518615723e-01
    z[7,6,1]  R2002     -1.2928212061524391e-02
    z[7,6,1]  R2003     -1.7264668643474579e-01
    z[7,6,1]  R2004     -5.9217959642410278e-01
    z[7,6,1]  R2005     -0.657151460647583
    z[7,6,1]  R2006     3.5223123431205750e-01
    z[7,6,1]  R2007     6.1220955848693848e-01
    z[7,6,1]  R2008     2.0237313210964203e-01
    z[7,6,1]  R2009     8.1670624017715454e-01
    z[7,6,1]  R2010     8.9486467838287354e-01
    z[7,6,1]  R2011     8.2600003480911255e-01
    z[7,6,1]  R2012     0.843882143497467
    z[7,6,1]  R2013     7.5049263238906860e-01
    z[7,6,1]  R2014     7.9955446720123291e-01
    z[7,6,1]  R2015     7.8682017326354980e-01
    z[7,6,1]  R2016     1.5438741445541382e-01
    z[7,6,1]  R2017     -1.8111892044544220e-02
    z[7,6,1]  R2018     6.3355618715286255e-01
    z[7,6,1]  R2019     -7.0401608943939209e-01
    z[7,6,1]  R2020     -0.317990779876709
    z[7,6,1]  R2021     -9.9937207996845245e-02
    z[7,6,1]  R2022     1.9208516925573349e-02
    z[7,6,1]  R2023     -6.1492401361465454e-01
    z[7,6,1]  R2024     8.4363776445388794e-01
    z[7,6,1]  R2025     2.1581551432609558e-01
    z[7,6,1]  R2026     1.5701790153980255e-01
    z[7,6,1]  R2027     -2.6684790849685669e-01
    z[7,6,1]  R2028     1.1021289043128490e-02
    z[7,6,1]  R2029     -5.6431031227111816e-01
    z[7,6,1]  R2030     -4.5959058403968811e-01
    z[7,6,1]  R2031     -0.362327516078949
    z[7,6,1]  R2032     -4.4981494545936584e-01
    z[7,6,1]  R2033     -6.6127836704254150e-01
    z[7,6,1]  R2034     6.1683690547943115e-01
    z[7,6,1]  R2035     -4.4729864597320557e-01
    z[7,6,1]  R2036     7.0814952254295349e-02
    z[7,6,1]  R2037     -6.2575900554656982e-01
    z[7,6,1]  R2038     -2.5553995370864868e-01
    z[7,6,1]  R2039     1.3084186613559723e-01
    z[7,6,1]  R2040     0.917531430721283
    z[7,6,1]  R2041     8.5602718591690063e-01
    z[7,6,1]  R2042     7.6393014192581177e-01
    z[7,6,1]  R2043     8.8324540853500366e-01
    z[7,6,1]  R2044     2.7826756238937378e-01
    z[7,6,1]  R2045     0.284063458442688
    z[7,6,1]  R2046     3.3059012889862061e-01
    z[7,6,1]  R2047     2.6292881369590759e-01
    z[7,6,1]  R2048     1.2327650189399719e-01
    z[7,6,1]  R2049     5.6456193327903748e-02
    z[7,6,1]  R2050     -5.2283253520727158e-02
    z[7,6,1]  R2051     -8.1001192331314087e-01
    z[7,6,1]  R2052     -6.4875560998916626e-01
    z[7,6,1]  R2053     -0.633316159248352
    z[7,6,1]  R2054     -6.1103403568267822e-01
    z[7,6,1]  R2055     -6.8792277574539185e-01
    z[7,6,1]  R2056     -5.4759508371353149e-01
    z[7,6,1]  R2057     8.5497468709945679e-01
    z[7,6,1]  R2058     0.834886908531189
    z[7,6,1]  R2059     9.2395859956741333e-01
    z[7,6,1]  R2060     8.5465639829635620e-01
    z[7,6,1]  R2061     7.1587729454040527e-01
    z[7,6,1]  R2062     9.1652947664260864e-01
    z[7,6,1]  R2063     8.3058446645736694e-01
    z[7,6,1]  R2064     8.0805647373199463e-01
    z[7,6,1]  R2065     9.3558359146118164e-01
    z[7,6,1]  R2066     0.853506863117218
    z[7,6,1]  R2067     5.3388422727584839e-01
    z[7,6,1]  R2068     -2.7932587265968323e-01
    z[7,6,1]  R2069     2.8157082200050354e-01
    z[7,6,1]  R2070     -1.8062831461429596e-01
    z[7,6,1]  R2071     2.1448570489883423e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R1986     -1
    z[7,6,2]  R1987     1
    z[7,6,2]  R1996     5.8374935388565063e-01
    z[7,6,2]  R1997     8.0793273448944092e-01
    z[7,6,2]  R1998     -7.4482011795043945e-01
    z[7,6,2]  R1999     -4.6082508563995361e-01
    z[7,6,2]  R2000     -2.1176628768444061e-01
    z[7,6,2]  R2001     -8.0369219183921814e-02
    z[7,6,2]  R2002     -7.9732966423034668e-01
    z[7,6,2]  R2003     -4.7009339928627014e-01
    z[7,6,2]  R2004     -2.0089778304100037e-01
    z[7,6,2]  R2005     -3.6613121628761292e-01
    z[7,6,2]  R2006     1.0949367284774780e-01
    z[7,6,2]  R2007     1.8620106577873230e-01
    z[7,6,2]  R2008     -1.1659797281026840e-01
    z[7,6,2]  R2009     -1.3814368844032288e-01
    z[7,6,2]  R2010     -5.3273785859346390e-02
    z[7,6,2]  R2011     1.5876792371273041e-01
    z[7,6,2]  R2012     -1.3258361816406250e-01
    z[7,6,2]  R2013     -3.5112169384956360e-01
    z[7,6,2]  R2014     1.8139155209064484e-01
    z[7,6,2]  R2015     1.8230681121349335e-01
    z[7,6,2]  R2016     -7.3565311729907990e-02
    z[7,6,2]  R2017     -0.0978657677769661
    z[7,6,2]  R2018     -0.320696085691452
    z[7,6,2]  R2019     1.4854307286441326e-02
    z[7,6,2]  R2020     -5.3830850869417191e-02
    z[7,6,2]  R2021     9.4093732535839081e-02
    z[7,6,2]  R2022     3.3875682950019836e-01
    z[7,6,2]  R2023     9.6524387598037720e-02
    z[7,6,2]  R2024     -1.1402054876089096e-01
    z[7,6,2]  R2025     3.4367090463638306e-01
    z[7,6,2]  R2026     5.2205115556716919e-01
    z[7,6,2]  R2027     -4.3683147430419922e-01
    z[7,6,2]  R2028     -1.9336020573973656e-02
    z[7,6,2]  R2029     -3.9456307888031006e-01
    z[7,6,2]  R2030     1.4970616437494755e-02
    z[7,6,2]  R2031     -2.2499936819076538e-01
    z[7,6,2]  R2032     -3.0829888582229614e-01
    z[7,6,2]  R2033     -5.0885128974914551e-01
    z[7,6,2]  R2034     -1.9861342012882233e-01
    z[7,6,2]  R2035     1.7511947453022003e-01
    z[7,6,2]  R2036     -8.4100671112537384e-02
    z[7,6,2]  R2037     -3.9988321065902710e-01
    z[7,6,2]  R2038     -1.9476985931396484e-01
    z[7,6,2]  R2039     -1.7199251055717468e-01
    z[7,6,2]  R2040     9.7669489681720734e-02
    z[7,6,2]  R2041     9.2239312827587128e-02
    z[7,6,2]  R2042     2.9931798577308655e-01
    z[7,6,2]  R2043     2.7387386560440063e-01
    z[7,6,2]  R2044     -2.5816044211387634e-01
    z[7,6,2]  R2045     7.1744687855243683e-02
    z[7,6,2]  R2046     -3.0896124243736267e-01
    z[7,6,2]  R2047     -6.4777895808219910e-02
    z[7,6,2]  R2048     -1.2366840243339539e-01
    z[7,6,2]  R2049     -3.0324435234069824e-01
    z[7,6,2]  R2050     5.5941653251647949e-01
    z[7,6,2]  R2051     -2.7511458843946457e-02
    z[7,6,2]  R2052     -1.3770723342895508e-01
    z[7,6,2]  R2053     1.5771174430847168e-01
    z[7,6,2]  R2054     1.3704569637775421e-01
    z[7,6,2]  R2055     1.0821133852005005e-01
    z[7,6,2]  R2056     -4.1420180350542068e-03
    z[7,6,2]  R2057     -1.4776925742626190e-01
    z[7,6,2]  R2058     9.8275601863861084e-02
    z[7,6,2]  R2059     1.2450519204139709e-01
    z[7,6,2]  R2060     -4.4256478548049927e-02
    z[7,6,2]  R2061     -6.4823113381862640e-02
    z[7,6,2]  R2062     -1.1903249472379684e-01
    z[7,6,2]  R2063     -3.3901998400688171e-01
    z[7,6,2]  R2064     -2.4882888793945312e-01
    z[7,6,2]  R2065     -1.4723014831542969e-01
    z[7,6,2]  R2066     1.4142517745494843e-01
    z[7,6,2]  R2067     3.9946746826171875e-01
    z[7,6,2]  R2068     -4.1601985692977905e-01
    z[7,6,2]  R2069     1.2957191094756126e-02
    z[7,6,2]  R2070     1.7368771135807037e-01
    z[7,6,2]  R2071     -7.9439365863800049e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R1988     -1
    z[7,6,3]  R1989     1
    z[7,6,3]  R1996     -2.9626250267028809e-01
    z[7,6,3]  R1997     -2.2999028861522675e-01
    z[7,6,3]  R1998     7.5844698585569859e-03
    z[7,6,3]  R1999     1.7470827698707581e-01
    z[7,6,3]  R2000     -2.3054596781730652e-01
    z[7,6,3]  R2001     4.2941838502883911e-02
    z[7,6,3]  R2002     2.6938286423683167e-01
    z[7,6,3]  R2003     -1.8347822129726410e-01
    z[7,6,3]  R2004     2.2835057228803635e-02
    z[7,6,3]  R2005     -1.2176606059074402e-01
    z[7,6,3]  R2006     -3.1238058209419250e-01
    z[7,6,3]  R2007     -5.3936600685119629e-01
    z[7,6,3]  R2008     -4.5483273267745972e-01
    z[7,6,3]  R2009     2.3717571794986725e-01
    z[7,6,3]  R2010     2.7579271793365479e-01
    z[7,6,3]  R2011     4.7326812148094177e-01
    z[7,6,3]  R2012     2.3212619125843048e-01
    z[7,6,3]  R2013     2.2987088561058044e-01
    z[7,6,3]  R2014     1.3276745565235615e-02
    z[7,6,3]  R2015     1.1353657394647598e-01
    z[7,6,3]  R2016     -4.2610099911689758e-01
    z[7,6,3]  R2017     -0.831956684589386
    z[7,6,3]  R2018     -1.8074707686901093e-01
    z[7,6,3]  R2019     -6.4651817083358765e-02
    z[7,6,3]  R2020     5.5095356702804565e-01
    z[7,6,3]  R2021     4.2653241753578186e-01
    z[7,6,3]  R2022     -6.2758159637451172e-01
    z[7,6,3]  R2023     2.6210615038871765e-01
    z[7,6,3]  R2024     -2.9034152626991272e-01
    z[7,6,3]  R2025     3.8065189123153687e-01
    z[7,6,3]  R2026     -4.4731894135475159e-01
    z[7,6,3]  R2027     1.5225636959075928e-01
    z[7,6,3]  R2028     9.2400491237640381e-02
    z[7,6,3]  R2029     -5.3684246540069580e-01
    z[7,6,3]  R2030     -5.3731977939605713e-01
    z[7,6,3]  R2031     -4.2891547083854675e-01
    z[7,6,3]  R2032     -5.2493758499622345e-02
    z[7,6,3]  R2033     -1.6123464331030846e-02
    z[7,6,3]  R2034     4.0416544675827026e-01
    z[7,6,3]  R2035     -3.1007694080471992e-02
    z[7,6,3]  R2036     9.0601757168769836e-02
    z[7,6,3]  R2037     -1.4374026656150818e-01
    z[7,6,3]  R2038     -6.5655320882797241e-01
    z[7,6,3]  R2039     -7.1335101127624512e-01
    z[7,6,3]  R2040     2.9495763778686523e-01
    z[7,6,3]  R2041     1.6936121881008148e-01
    z[7,6,3]  R2042     4.0316984057426453e-01
    z[7,6,3]  R2043     7.5238578021526337e-02
    z[7,6,3]  R2044     0.525577962398529
    z[7,6,3]  R2045     5.8198040723800659e-01
    z[7,6,3]  R2046     -6.5172064304351807e-01
    z[7,6,3]  R2047     -1.6469325870275497e-02
    z[7,6,3]  R2048     4.4052770733833313e-01
    z[7,6,3]  R2049     -8.9372701942920685e-02
    z[7,6,3]  R2050     -1.1839209496974945e-01
    z[7,6,3]  R2051     2.5236532092094421e-01
    z[7,6,3]  R2052     2.7716401219367981e-01
    z[7,6,3]  R2053     6.8763040006160736e-02
    z[7,6,3]  R2054     -1.5068550407886505e-01
    z[7,6,3]  R2055     -2.8603699803352356e-01
    z[7,6,3]  R2056     -4.4781614094972610e-02
    z[7,6,3]  R2057     3.0488395690917969e-01
    z[7,6,3]  R2058     2.4808315932750702e-01
    z[7,6,3]  R2059     1.2578254938125610e-01
    z[7,6,3]  R2060     1.8240959942340851e-01
    z[7,6,3]  R2061     3.2359105348587036e-01
    z[7,6,3]  R2062     -0.0447562001645565
    z[7,6,3]  R2063     1.2680643796920776e-01
    z[7,6,3]  R2064     -1.5656933188438416e-01
    z[7,6,3]  R2065     1.3978891074657440e-01
    z[7,6,3]  R2066     2.1200279891490936e-01
    z[7,6,3]  R2067     3.5718372464179993e-01
    z[7,6,3]  R2068     -4.1226732730865479e-01
    z[7,6,3]  R2069     -8.3796960115432739e-01
    z[7,6,3]  R2070     -3.3264175057411194e-01
    z[7,6,3]  R2071     1.0389391332864761e-02
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R1990     -1
    z[7,6,4]  R1991     1
    z[7,6,4]  R1996     5.2010606974363327e-02
    z[7,6,4]  R1997     -4.9195386469364166e-02
    z[7,6,4]  R1998     -3.7985664606094360e-01
    z[7,6,4]  R1999     -3.5559251904487610e-01
    z[7,6,4]  R2000     -1.4419960975646973e-01
    z[7,6,4]  R2001     7.9924903810024261e-02
    z[7,6,4]  R2002     3.2121084630489349e-02
    z[7,6,4]  R2003     -2.4918870627880096e-01
    z[7,6,4]  R2004     4.4314138591289520e-02
    z[7,6,4]  R2005     0.00996498391032219
    z[7,6,4]  R2006     3.6694124341011047e-01
    z[7,6,4]  R2007     -9.8868340253829956e-02
    z[7,6,4]  R2008     3.3180806785821915e-02
    z[7,6,4]  R2009     -2.1452265977859497e-01
    z[7,6,4]  R2010     2.3530666530132294e-01
    z[7,6,4]  R2011     1.8888242542743683e-01
    z[7,6,4]  R2012     -1.1103283613920212e-01
    z[7,6,4]  R2013     -7.7681474387645721e-02
    z[7,6,4]  R2014     -3.5406225919723511e-01
    z[7,6,4]  R2015     -8.9405968785285950e-02
    z[7,6,4]  R2016     1.9480755925178528e-01
    z[7,6,4]  R2017     -3.7798702716827393e-01
    z[7,6,4]  R2018     -3.4833812713623047e-01
    z[7,6,4]  R2019     -3.1084150075912476e-02
    z[7,6,4]  R2020     2.5017036125063896e-02
    z[7,6,4]  R2021     5.4205763339996338e-01
    z[7,6,4]  R2022     -3.4216997027397156e-01
    z[7,6,4]  R2023     -1.6029420495033264e-01
    z[7,6,4]  R2024     -2.3251923918724060e-01
    z[7,6,4]  R2025     -6.6043063998222351e-02
    z[7,6,4]  R2026     2.3488023877143860e-01
    z[7,6,4]  R2027     -4.9218330532312393e-02
    z[7,6,4]  R2028     -4.6918958425521851e-01
    z[7,6,4]  R2029     -0.301287978887558
    z[7,6,4]  R2030     -4.6428516507148743e-01
    z[7,6,4]  R2031     4.8834286630153656e-02
    z[7,6,4]  R2032     4.9995416402816772e-01
    z[7,6,4]  R2033     3.2148233056068420e-01
    z[7,6,4]  R2034     -2.7205618098378181e-02
    z[7,6,4]  R2035     3.8036105036735535e-01
    z[7,6,4]  R2036     -2.8200012445449829e-01
    z[7,6,4]  R2037     3.2433885335922241e-01
    z[7,6,4]  R2038     -4.2623001337051392e-01
    z[7,6,4]  R2039     -3.2421517372131348e-01
    z[7,6,4]  R2040     -1.0389124974608421e-02
    z[7,6,4]  R2041     1.0767946392297745e-01
    z[7,6,4]  R2042     2.7785351872444153e-01
    z[7,6,4]  R2043     -0.157674640417099
    z[7,6,4]  R2044     -5.0214350223541260e-01
    z[7,6,4]  R2045     -0.654729962348938
    z[7,6,4]  R2046     -3.2583290338516235e-01
    z[7,6,4]  R2047     -2.7821826934814453e-01
    z[7,6,4]  R2048     6.7188933491706848e-02
    z[7,6,4]  R2049     4.7482779622077942e-01
    z[7,6,4]  R2050     -3.6745730042457581e-01
    z[7,6,4]  R2051     -7.8729726374149323e-02
    z[7,6,4]  R2052     2.8432884812355042e-01
    z[7,6,4]  R2053     -4.2871765792369843e-02
    z[7,6,4]  R2054     -2.2973024845123291e-01
    z[7,6,4]  R2055     -1.0809712857007980e-01
    z[7,6,4]  R2056     2.4782599508762360e-01
    z[7,6,4]  R2057     1.1179201304912567e-01
    z[7,6,4]  R2058     -1.4008018374443054e-01
    z[7,6,4]  R2059     -9.2467740178108215e-03
    z[7,6,4]  R2060     -1.9531685113906860e-01
    z[7,6,4]  R2061     2.9183301329612732e-01
    z[7,6,4]  R2062     -5.6745827198028564e-02
    z[7,6,4]  R2063     -1.0065872222185135e-02
    z[7,6,4]  R2064     -3.9776325225830078e-02
    z[7,6,4]  R2065     -1.1228875070810318e-01
    z[7,6,4]  R2066     1.0977048426866531e-01
    z[7,6,4]  R2067     -3.2281684875488281e-01
    z[7,6,4]  R2068     -2.0525366067886353e-01
    z[7,6,4]  R2069     -1.3405166566371918e-01
    z[7,6,4]  R2070     -2.4102728068828583e-01
    z[7,6,4]  R2071     4.5595857501029968e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R1992     -1
    z[7,6,5]  R1993     1
    z[7,6,5]  R1996     9.0704366564750671e-02
    z[7,6,5]  R1997     -0.371353417634964
    z[7,6,5]  R1998     -8.5436321794986725e-02
    z[7,6,5]  R1999     -5.0231724977493286e-01
    z[7,6,5]  R2000     1.2283550947904587e-01
    z[7,6,5]  R2001     6.5591067075729370e-02
    z[7,6,5]  R2002     -1.9198393821716309e-01
    z[7,6,5]  R2003     4.0160372853279114e-01
    z[7,6,5]  R2004     -4.7288224101066589e-01
    z[7,6,5]  R2005     -5.7962954044342041e-01
    z[7,6,5]  R2006     0.0172764640301466
    z[7,6,5]  R2007     2.7332261204719543e-01
    z[7,6,5]  R2008     7.2685825824737549e-01
    z[7,6,5]  R2009     1.6292506456375122e-01
    z[7,6,5]  R2010     1.6098989173769951e-02
    z[7,6,5]  R2011     1.7929413914680481e-01
    z[7,6,5]  R2012     -3.2500532269477844e-01
    z[7,6,5]  R2013     4.8621863126754761e-01
    z[7,6,5]  R2014     2.1258804202079773e-01
    z[7,6,5]  R2015     5.5858159065246582e-01
    z[7,6,5]  R2016     -4.1165664792060852e-01
    z[7,6,5]  R2017     -3.1215471029281616e-01
    z[7,6,5]  R2018     4.4235071539878845e-01
    z[7,6,5]  R2019     -4.2363211512565613e-01
    z[7,6,5]  R2020     0.342980295419693
    z[7,6,5]  R2021     3.8639730215072632e-01
    z[7,6,5]  R2022     3.9249747991561890e-01
    z[7,6,5]  R2023     2.8783757239580154e-02
    z[7,6,5]  R2024     1.5860473737120628e-02
    z[7,6,5]  R2025     4.1492480784654617e-02
    z[7,6,5]  R2026     1.9243466854095459e-01
    z[7,6,5]  R2027     3.4419283270835876e-01
    z[7,6,5]  R2028     -1.6354827675968409e-03
    z[7,6,5]  R2029     3.7612563371658325e-01
    z[7,6,5]  R2030     -2.1952450275421143e-01
    z[7,6,5]  R2031     -6.0261303186416626e-01
    z[7,6,5]  R2032     -1.1767259798943996e-02
    z[7,6,5]  R2033     1.1409191787242889e-01
    z[7,6,5]  R2034     3.6852625012397766e-01
    z[7,6,5]  R2035     -2.3361924290657043e-01
    z[7,6,5]  R2036     -4.2329076677560806e-02
    z[7,6,5]  R2037     2.6129499077796936e-01
    z[7,6,5]  R2038     -4.6530234813690186e-01
    z[7,6,5]  R2039     4.0940031409263611e-01
    z[7,6,5]  R2040     9.7915731370449066e-02
    z[7,6,5]  R2041     4.4756886363029480e-01
    z[7,6,5]  R2042     -1.0332090407609940e-01
    z[7,6,5]  R2043     -3.1056505441665649e-01
    z[7,6,5]  R2044     -3.5141382366418839e-02
    z[7,6,5]  R2045     -2.0326366648077965e-02
    z[7,6,5]  R2046     -1.8530496954917908e-01
    z[7,6,5]  R2047     1.6553317010402679e-01
    z[7,6,5]  R2048     -0.708588719367981
    z[7,6,5]  R2049     -0.627094030380249
    z[7,6,5]  R2050     -3.9910188317298889e-01
    z[7,6,5]  R2051     -5.2411708980798721e-02
    z[7,6,5]  R2052     -3.1696256250143051e-02
    z[7,6,5]  R2053     2.5768628716468811e-01
    z[7,6,5]  R2054     -7.2195850312709808e-02
    z[7,6,5]  R2055     -4.4598728418350220e-01
    z[7,6,5]  R2056     4.9739050865173340e-01
    z[7,6,5]  R2057     3.0556204915046692e-01
    z[7,6,5]  R2058     4.5865449309349060e-01
    z[7,6,5]  R2059     1.3495285809040070e-01
    z[7,6,5]  R2060     1.6480810940265656e-01
    z[7,6,5]  R2061     3.9348602294921875e-01
    z[7,6,5]  R2062     -1.7372589558362961e-02
    z[7,6,5]  R2063     -8.6739644408226013e-02
    z[7,6,5]  R2064     4.2810970544815063e-01
    z[7,6,5]  R2065     -0.0961286723613739
    z[7,6,5]  R2066     8.7627187371253967e-02
    z[7,6,5]  R2067     3.2574450969696045e-01
    z[7,6,5]  R2068     3.7828603386878967e-01
    z[7,6,5]  R2069     -7.2894699871540070e-02
    z[7,6,5]  R2070     -5.5353248119354248e-01
    z[7,6,5]  R2071     2.0876155793666840e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R1994     -1
    z[7,6,6]  R1995     1
    z[7,6,6]  R1996     -1.0978800803422928e-01
    z[7,6,6]  R1997     -1.6560514271259308e-01
    z[7,6,6]  R1998     -1.7584989964962006e-01
    z[7,6,6]  R1999     -2.5437775254249573e-01
    z[7,6,6]  R2000     -5.5729198455810547e-01
    z[7,6,6]  R2001     -5.7539767026901245e-01
    z[7,6,6]  R2002     2.4703799188137054e-01
    z[7,6,6]  R2003     2.9298740625381470e-01
    z[7,6,6]  R2004     -4.0716385841369629e-01
    z[7,6,6]  R2005     -1.3048562407493591e-01
    z[7,6,6]  R2006     5.6856197118759155e-01
    z[7,6,6]  R2007     1.5073230862617493e-01
    z[7,6,6]  R2008     2.6217430830001831e-01
    z[7,6,6]  R2009     -4.2954996228218079e-01
    z[7,6,6]  R2010     2.2128300368785858e-01
    z[7,6,6]  R2011     9.7023620037361979e-04
    z[7,6,6]  R2012     -2.9196760058403015e-01
    z[7,6,6]  R2013     -1.1393678933382034e-01
    z[7,6,6]  R2014     -1.8036429584026337e-01
    z[7,6,6]  R2015     -0.0567796565592289
    z[7,6,6]  R2016     2.7524289488792419e-01
    z[7,6,6]  R2017     2.3761428892612457e-01
    z[7,6,6]  R2018     7.5254611670970917e-02
    z[7,6,6]  R2019     2.6987710595130920e-01
    z[7,6,6]  R2020     -7.2697363793849945e-02
    z[7,6,6]  R2021     -6.6993035376071930e-02
    z[7,6,6]  R2022     3.0445849895477295e-01
    z[7,6,6]  R2023     -1.3970334827899933e-01
    z[7,6,6]  R2024     -2.8291681408882141e-01
    z[7,6,6]  R2025     1.3887633383274078e-01
    z[7,6,6]  R2026     4.6026587486267090e-01
    z[7,6,6]  R2027     3.0812928080558777e-01
    z[7,6,6]  R2028     -1.9790825247764587e-01
    z[7,6,6]  R2029     -6.4118191599845886e-02
    z[7,6,6]  R2030     7.0299096405506134e-02
    z[7,6,6]  R2031     5.1824301481246948e-01
    z[7,6,6]  R2032     0.598641574382782
    z[7,6,6]  R2033     4.2865911126136780e-01
    z[7,6,6]  R2034     9.9234811961650848e-02
    z[7,6,6]  R2035     7.2481870651245117e-01
    z[7,6,6]  R2036     2.0238281786441803e-01
    z[7,6,6]  R2037     2.4628686904907227e-01
    z[7,6,6]  R2038     -1.8277524411678314e-01
    z[7,6,6]  R2039     -8.5760496556758881e-02
    z[7,6,6]  R2040     -2.0838232338428497e-01
    z[7,6,6]  R2041     7.8025534749031067e-02
    z[7,6,6]  R2042     -3.6871105432510376e-02
    z[7,6,6]  R2043     -7.6866008341312408e-02
    z[7,6,6]  R2044     2.5106236338615417e-01
    z[7,6,6]  R2045     2.2925668954849243e-01
    z[7,6,6]  R2046     2.9365673661231995e-01
    z[7,6,6]  R2047     -8.7102377414703369e-01
    z[7,6,6]  R2048     2.3660773038864136e-01
    z[7,6,6]  R2049     -4.6477177739143372e-01
    z[7,6,6]  R2050     -5.7861721515655518e-01
    z[7,6,6]  R2051     1.8897494673728943e-01
    z[7,6,6]  R2052     -4.1994577646255493e-01
    z[7,6,6]  R2053     -5.1444333791732788e-01
    z[7,6,6]  R2054     -3.9558568596839905e-01
    z[7,6,6]  R2055     -3.3922377228736877e-01
    z[7,6,6]  R2056     1.2285137176513672e-01
    z[7,6,6]  R2057     -1.6898886859416962e-01
    z[7,6,6]  R2058     3.8814555853605270e-02
    z[7,6,6]  R2059     -7.2938792407512665e-02
    z[7,6,6]  R2060     0.409720242023468
    z[7,6,6]  R2061     -6.4630389213562012e-02
    z[7,6,6]  R2062     -2.9128888249397278e-01
    z[7,6,6]  R2063     1.4202875085175037e-02
    z[7,6,6]  R2064     2.3553293943405151e-01
    z[7,6,6]  R2065     5.8336459100246429e-02
    z[7,6,6]  R2066     -1.1622021347284317e-01
    z[7,6,6]  R2067     3.8714310526847839e-01
    z[7,6,6]  R2068     1.6772159934043884e-01
    z[7,6,6]  R2069     -1.5158607065677643e-01
    z[7,6,6]  R2070     5.1912426948547363e-01
    z[7,6,6]  R2071     2.1310560405254364e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2072     -1
    z[7,8,0]  R2073     1
    z[7,8,0]  R2086     -3.3000677824020386e-01
    z[7,8,0]  R2087     -1.9318053126335144e-01
    z[7,8,0]  R2088     4.9064305424690247e-01
    z[7,8,0]  R2089     5.5800050497055054e-01
    z[7,8,0]  R2090     -5.9474945068359375e-01
    z[7,8,0]  R2091     -7.7611696720123291e-01
    z[7,8,0]  R2092     4.3887776136398315e-01
    z[7,8,0]  R2093     6.3743138313293457e-01
    z[7,8,0]  R2094     -4.6591654419898987e-01
    z[7,8,0]  R2095     -2.5724855065345764e-01
    z[7,8,0]  R2096     -5.5511754751205444e-01
    z[7,8,0]  R2097     -4.3864867091178894e-01
    z[7,8,0]  R2098     -3.7472385168075562e-01
    z[7,8,0]  R2099     -2.4024071171879768e-02
    z[7,8,0]  R2100     -1.2539096176624298e-01
    z[7,8,0]  R2101     2.6647349819540977e-02
    z[7,8,0]  R2102     -1.1489200592041016e-01
    z[7,8,0]  R2103     7.2174452245235443e-02
    z[7,8,0]  R2104     3.5291427373886108e-01
    z[7,8,0]  R2105     1.0750346630811691e-01
    z[7,8,0]  R2106     -7.1135139465332031e-01
    z[7,8,0]  R2107     -3.4161310642957687e-02
    z[7,8,0]  R2108     3.7471893429756165e-01
    z[7,8,0]  R2109     4.9668571352958679e-01
    z[7,8,0]  R2110     0.684753954410553
    z[7,8,0]  R2111     -5.9296840429306030e-01
    z[7,8,0]  R2112     3.5663238167762756e-01
    z[7,8,0]  R2113     7.0555794239044189e-01
    z[7,8,0]  R2114     -2.3794497549533844e-01
    z[7,8,0]  R2115     8.1550484895706177e-01
    z[7,8,0]  R2116     -4.4572320580482483e-01
    z[7,8,0]  R2117     7.0636653900146484e-01
    z[7,8,0]  R2118     8.5536980628967285e-01
    z[7,8,0]  R2119     -3.6302644759416580e-02
    z[7,8,0]  R2120     4.8077669739723206e-01
    z[7,8,0]  R2121     4.7387238591909409e-03
    z[7,8,0]  R2122     -3.0232161283493042e-01
    z[7,8,0]  R2123     -5.8349866420030594e-02
    z[7,8,0]  R2124     5.1991915702819824e-01
    z[7,8,0]  R2125     2.0899994671344757e-01
    z[7,8,0]  R2126     9.2597460746765137e-01
    z[7,8,0]  R2127     -4.4014748930931091e-01
    z[7,8,0]  R2128     -1.8470740318298340e-01
    z[7,8,0]  R2129     -4.0540158748626709e-01
    z[7,8,0]  R2130     -9.2076942324638367e-02
    z[7,8,0]  R2131     -1.0966061055660248e-01
    z[7,8,0]  R2132     -2.7392736077308655e-01
    z[7,8,0]  R2133     0.1094965711236
    z[7,8,0]  R2134     -5.1310116052627563e-01
    z[7,8,0]  R2135     -3.0629462003707886e-01
    z[7,8,0]  R2136     -8.5061663389205933e-01
    z[7,8,0]  R2137     -6.6478002071380615e-01
    z[7,8,0]  R2138     -6.8220239877700806e-01
    z[7,8,0]  R2139     -4.2338940501213074e-01
    z[7,8,0]  R2140     -5.4683411121368408e-01
    z[7,8,0]  R2141     3.4477461129426956e-02
    z[7,8,0]  R2142     -1.3178817927837372e-01
    z[7,8,0]  R2143     -1.1144463717937469e-01
    z[7,8,0]  R2144     6.1237372457981110e-02
    z[7,8,0]  R2145     1.2883530557155609e-01
    z[7,8,0]  R2146     7.5623080134391785e-02
    z[7,8,0]  R2147     2.0187151432037354e-01
    z[7,8,0]  R2148     8.8159903883934021e-02
    z[7,8,0]  R2149     1.7221964895725250e-01
    z[7,8,0]  R2150     -3.8590118288993835e-01
    z[7,8,0]  R2151     -2.1298557519912720e-01
    z[7,8,0]  R2152     -3.4787435084581375e-02
    z[7,8,0]  R2153     0.144593745470047
    z[7,8,0]  R2154     -1.7110320925712585e-01
    z[7,8,0]  R2155     -8.2352012395858765e-02
    z[7,8,0]  R2156     -7.3613594286143780e-03
    z[7,8,0]  R2157     2.2473397850990295e-01
    z[7,8,0]  R2158     -4.5772069692611694e-01
    z[7,8,0]  R2159     3.5058337450027466e-01
    z[7,8,0]  R2160     -2.9376265406608582e-01
    z[7,8,0]  R2161     -4.7494354844093323e-01
    z[7,8,0]  R2162     -5.0987863540649414e-01
    z[7,8,0]  R2163     1.2680661678314209e-01
    z[7,8,0]  R2164     -4.7340753674507141e-01
    z[7,8,0]  R2165     -5.9228497743606567e-01
    z[7,8,0]  R2166     2.2725613415241241e-01
    z[7,8,0]  R2167     1.6647150740027428e-02
    z[7,8,0]  R2168     6.6248111426830292e-02
    z[7,8,0]  R2169     4.9591418355703354e-02
    z[7,8,0]  R2170     2.3875980079174042e-01
    z[7,8,0]  R2171     -2.0266209542751312e-01
    z[7,8,0]  R2172     1.8510530889034271e-01
    z[7,8,0]  R2173     -9.6003741025924683e-02
    z[7,8,0]  R2174     6.1135566234588623e-01
    z[7,8,0]  R2175     -3.0051884055137634e-01
    z[7,8,0]  R2176     8.3354108035564423e-02
    z[7,8,0]  R2177     -9.0884536504745483e-02
    z[7,8,0]  R2178     -3.9024937152862549e-01
    z[7,8,0]  R2179     2.0824769139289856e-01
    z[7,8,0]  R2180     0.728653073310852
    z[7,8,0]  R2181     -1.0147596150636673e-01
    z[7,8,0]  R2182     4.1850557923316956e-01
    z[7,8,0]  R2183     7.3393404483795166e-01
    z[7,8,0]  R2184     7.3931068181991577e-01
    z[7,8,0]  R2185     7.7196583151817322e-02
    z[7,8,0]  R2186     -1.5070086717605591e-01
    z[7,8,0]  R2187     -5.3566700220108032e-01
    z[7,8,0]  R2188     2.7248108386993408e-01
    z[7,8,0]  R2189     2.2686022520065308e-01
    z[7,8,0]  R2190     -1.8101686239242554e-01
    z[7,8,0]  R2191     -0.244932159781456
    z[7,8,0]  R2192     -5.3288701921701431e-02
    z[7,8,0]  R2193     -4.9755790829658508e-01
    z[7,8,0]  R2194     1.4224074780941010e-01
    z[7,8,0]  R2195     -0.27867591381073
    z[7,8,0]  R2196     -2.4550264701247215e-02
    z[7,8,0]  R2197     2.1306996047496796e-01
    z[7,8,0]  R2198     0.0872528925538063
    z[7,8,0]  R2199     -5.5026117712259293e-02
    z[7,8,0]  R2200     2.8675207495689392e-01
    z[7,8,0]  R2201     7.4092823266983032e-01
    z[7,8,0]  R2202     1.2137080729007721e-01
    z[7,8,0]  R2203     -5.8641177415847778e-01
    z[7,8,0]  R2204     9.0669281780719757e-02
    z[7,8,0]  R2205     6.9981443881988525e-01
    z[7,8,0]  R2206     -2.6681980118155479e-02
    z[7,8,0]  R2207     -2.0519353449344635e-01
    z[7,8,0]  R2208     6.7276817560195923e-01
    z[7,8,0]  R2209     -2.2326491773128510e-01
    z[7,8,0]  R2210     -4.3854388594627380e-01
    z[7,8,0]  R2211     2.2516788914799690e-02
    z[7,8,0]  R2212     -0.459357351064682
    z[7,8,0]  R2213     -0.426647424697876
    z[7,8,0]  R2214     -2.2971516475081444e-02
    z[7,8,0]  R2215     2.5697913765907288e-01
    z[7,8,0]  R2216     -5.2027054131031036e-02
    z[7,8,0]  R2217     -4.7266975045204163e-02
    z[7,8,0]  R2218     5.9770947694778442e-01
    z[7,8,0]  R2219     3.8361188769340515e-01
    z[7,8,0]  R2220     2.3431569337844849e-01
    z[7,8,0]  R2221     5.1072686910629272e-02
    z[7,8,0]  R2222     -1.3900332152843475e-01
    z[7,8,0]  R2223     -1.7442011833190918e-01
    z[7,8,0]  R2224     -2.9155322909355164e-01
    z[7,8,0]  R2225     -3.0238136649131775e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2074     -1
    z[7,8,1]  R2075     1
    z[7,8,1]  R2086     -6.6300463676452637e-01
    z[7,8,1]  R2087     -2.9880064725875854e-01
    z[7,8,1]  R2088     -1.4812584221363068e-01
    z[7,8,1]  R2089     -4.7706909477710724e-02
    z[7,8,1]  R2090     -4.4924414157867432e-01
    z[7,8,1]  R2091     -2.1809792518615723e-01
    z[7,8,1]  R2092     -1.2928212061524391e-02
    z[7,8,1]  R2093     -1.7264668643474579e-01
    z[7,8,1]  R2094     -5.9217959642410278e-01
    z[7,8,1]  R2095     -0.657151460647583
    z[7,8,1]  R2096     3.5223123431205750e-01
    z[7,8,1]  R2097     6.1220955848693848e-01
    z[7,8,1]  R2098     2.0237313210964203e-01
    z[7,8,1]  R2099     8.1670624017715454e-01
    z[7,8,1]  R2100     8.9486467838287354e-01
    z[7,8,1]  R2101     8.2600003480911255e-01
    z[7,8,1]  R2102     0.843882143497467
    z[7,8,1]  R2103     7.5049263238906860e-01
    z[7,8,1]  R2104     7.9955446720123291e-01
    z[7,8,1]  R2105     7.8682017326354980e-01
    z[7,8,1]  R2106     1.5438741445541382e-01
    z[7,8,1]  R2107     -1.8111892044544220e-02
    z[7,8,1]  R2108     6.3355618715286255e-01
    z[7,8,1]  R2109     -7.0401608943939209e-01
    z[7,8,1]  R2110     -0.317990779876709
    z[7,8,1]  R2111     -9.9937207996845245e-02
    z[7,8,1]  R2112     1.9208516925573349e-02
    z[7,8,1]  R2113     -6.1492401361465454e-01
    z[7,8,1]  R2114     8.4363776445388794e-01
    z[7,8,1]  R2115     2.1581551432609558e-01
    z[7,8,1]  R2116     1.5701790153980255e-01
    z[7,8,1]  R2117     -2.6684790849685669e-01
    z[7,8,1]  R2118     1.1021289043128490e-02
    z[7,8,1]  R2119     -5.6431031227111816e-01
    z[7,8,1]  R2120     -4.5959058403968811e-01
    z[7,8,1]  R2121     -0.362327516078949
    z[7,8,1]  R2122     -4.4981494545936584e-01
    z[7,8,1]  R2123     -6.6127836704254150e-01
    z[7,8,1]  R2124     6.1683690547943115e-01
    z[7,8,1]  R2125     -4.4729864597320557e-01
    z[7,8,1]  R2126     7.0814952254295349e-02
    z[7,8,1]  R2127     -6.2575900554656982e-01
    z[7,8,1]  R2128     -2.5553995370864868e-01
    z[7,8,1]  R2129     1.3084186613559723e-01
    z[7,8,1]  R2130     0.917531430721283
    z[7,8,1]  R2131     8.5602718591690063e-01
    z[7,8,1]  R2132     7.6393014192581177e-01
    z[7,8,1]  R2133     8.8324540853500366e-01
    z[7,8,1]  R2134     2.7826756238937378e-01
    z[7,8,1]  R2135     0.284063458442688
    z[7,8,1]  R2136     -1.5238077938556671e-01
    z[7,8,1]  R2137     -4.9546480178833008e-01
    z[7,8,1]  R2138     -1.3301602005958557e-01
    z[7,8,1]  R2139     -3.3557718992233276e-01
    z[7,8,1]  R2140     -1.6564594209194183e-01
    z[7,8,1]  R2141     -9.8058469593524933e-02
    z[7,8,1]  R2142     1.6699803993105888e-02
    z[7,8,1]  R2143     -2.0967480540275574e-01
    z[7,8,1]  R2144     -3.4673564136028290e-02
    z[7,8,1]  R2145     4.7680456191301346e-02
    z[7,8,1]  R2146     8.7954843044281006e-01
    z[7,8,1]  R2147     7.4665105342864990e-01
    z[7,8,1]  R2148     7.5145530700683594e-01
    z[7,8,1]  R2149     0.565773069858551
    z[7,8,1]  R2150     5.5502235889434814e-01
    z[7,8,1]  R2151     6.4108473062515259e-01
    z[7,8,1]  R2152     -8.4837704896926880e-02
    z[7,8,1]  R2153     5.5654048919677734e-01
    z[7,8,1]  R2154     -5.7708561420440674e-01
    z[7,8,1]  R2155     6.4547479152679443e-01
    z[7,8,1]  R2156     7.9739069938659668e-01
    z[7,8,1]  R2157     7.3832303285598755e-01
    z[7,8,1]  R2158     6.4866358041763306e-01
    z[7,8,1]  R2159     6.1946231126785278e-01
    z[7,8,1]  R2160     7.0504951477050781e-01
    z[7,8,1]  R2161     6.8237692117691040e-01
    z[7,8,1]  R2162     5.7485276460647583e-01
    z[7,8,1]  R2163     0.730842649936676
    z[7,8,1]  R2164     7.4944311380386353e-01
    z[7,8,1]  R2165     5.7339757680892944e-01
    z[7,8,1]  R2166     8.4325706958770752e-01
    z[7,8,1]  R2167     6.8030416965484619e-01
    z[7,8,1]  R2168     -2.7212768793106079e-01
    z[7,8,1]  R2169     -6.3387066125869751e-02
    z[7,8,1]  R2170     2.7062773704528809e-02
    z[7,8,1]  R2171     2.5001174211502075e-01
    z[7,8,1]  R2172     -2.7819997072219849e-01
    z[7,8,1]  R2173     -4.0184023976325989e-01
    z[7,8,1]  R2174     -8.2699873019009829e-04
    z[7,8,1]  R2175     -9.4911180436611176e-02
    z[7,8,1]  R2176     6.2830311059951782e-01
    z[7,8,1]  R2177     6.0234630107879639e-01
    z[7,8,1]  R2178     6.5705102682113647e-01
    z[7,8,1]  R2179     3.5974937677383423e-01
    z[7,8,1]  R2180     9.5749676227569580e-02
    z[7,8,1]  R2181     -4.8531722277402878e-02
    z[7,8,1]  R2182     -3.8195803761482239e-01
    z[7,8,1]  R2183     7.5192131102085114e-02
    z[7,8,1]  R2184     1.3157719373703003e-01
    z[7,8,1]  R2185     -3.1927531957626343e-01
    z[7,8,1]  R2186     7.9016172885894775e-01
    z[7,8,1]  R2187     8.2258272171020508e-01
    z[7,8,1]  R2188     8.8666254281997681e-01
    z[7,8,1]  R2189     7.5900465250015259e-01
    z[7,8,1]  R2190     0.809294581413269
    z[7,8,1]  R2191     5.1300019025802612e-01
    z[7,8,1]  R2192     7.6782727241516113e-01
    z[7,8,1]  R2193     5.9720373153686523e-01
    z[7,8,1]  R2194     1.5615494549274445e-01
    z[7,8,1]  R2195     -1.3358376920223236e-01
    z[7,8,1]  R2196     3.1324383616447449e-01
    z[7,8,1]  R2197     7.7548390626907349e-01
    z[7,8,1]  R2198     1.7036555707454681e-01
    z[7,8,1]  R2199     -4.1772177815437317e-01
    z[7,8,1]  R2200     -0.253431499004364
    z[7,8,1]  R2201     2.1579198539257050e-01
    z[7,8,1]  R2202     1.3170754909515381e-01
    z[7,8,1]  R2203     -3.4229966998100281e-01
    z[7,8,1]  R2204     2.3952980339527130e-01
    z[7,8,1]  R2205     1.8633915483951569e-01
    z[7,8,1]  R2206     6.8395271897315979e-02
    z[7,8,1]  R2207     -5.6348246335983276e-01
    z[7,8,1]  R2208     2.7041158080101013e-01
    z[7,8,1]  R2209     -2.5729942321777344e-01
    z[7,8,1]  R2210     -0.0911824107170105
    z[7,8,1]  R2211     6.5456062555313110e-02
    z[7,8,1]  R2212     -1.0315380990505219e-01
    z[7,8,1]  R2213     -2.5617891550064087e-01
    z[7,8,1]  R2214     -2.3504646122455597e-01
    z[7,8,1]  R2215     -1.7841754853725433e-01
    z[7,8,1]  R2216     -1.6186280548572540e-01
    z[7,8,1]  R2217     8.3938315510749817e-02
    z[7,8,1]  R2218     1.8751224875450134e-01
    z[7,8,1]  R2219     4.7296587377786636e-02
    z[7,8,1]  R2220     -8.9162372052669525e-02
    z[7,8,1]  R2221     -9.0641617774963379e-01
    z[7,8,1]  R2222     -8.6645781993865967e-01
    z[7,8,1]  R2223     -8.3836305141448975e-01
    z[7,8,1]  R2224     -9.1352224349975586e-01
    z[7,8,1]  R2225     -8.3615368604660034e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2076     -1
    z[7,8,2]  R2077     1
    z[7,8,2]  R2086     5.8374935388565063e-01
    z[7,8,2]  R2087     8.0793273448944092e-01
    z[7,8,2]  R2088     -7.4482011795043945e-01
    z[7,8,2]  R2089     -4.6082508563995361e-01
    z[7,8,2]  R2090     -2.1176628768444061e-01
    z[7,8,2]  R2091     -8.0369219183921814e-02
    z[7,8,2]  R2092     -7.9732966423034668e-01
    z[7,8,2]  R2093     -4.7009339928627014e-01
    z[7,8,2]  R2094     -2.0089778304100037e-01
    z[7,8,2]  R2095     -3.6613121628761292e-01
    z[7,8,2]  R2096     1.0949367284774780e-01
    z[7,8,2]  R2097     1.8620106577873230e-01
    z[7,8,2]  R2098     -1.1659797281026840e-01
    z[7,8,2]  R2099     -1.3814368844032288e-01
    z[7,8,2]  R2100     -5.3273785859346390e-02
    z[7,8,2]  R2101     1.5876792371273041e-01
    z[7,8,2]  R2102     -1.3258361816406250e-01
    z[7,8,2]  R2103     -3.5112169384956360e-01
    z[7,8,2]  R2104     1.8139155209064484e-01
    z[7,8,2]  R2105     1.8230681121349335e-01
    z[7,8,2]  R2106     -7.3565311729907990e-02
    z[7,8,2]  R2107     -0.0978657677769661
    z[7,8,2]  R2108     -0.320696085691452
    z[7,8,2]  R2109     1.4854307286441326e-02
    z[7,8,2]  R2110     -5.3830850869417191e-02
    z[7,8,2]  R2111     9.4093732535839081e-02
    z[7,8,2]  R2112     3.3875682950019836e-01
    z[7,8,2]  R2113     9.6524387598037720e-02
    z[7,8,2]  R2114     -1.1402054876089096e-01
    z[7,8,2]  R2115     3.4367090463638306e-01
    z[7,8,2]  R2116     5.2205115556716919e-01
    z[7,8,2]  R2117     -4.3683147430419922e-01
    z[7,8,2]  R2118     -1.9336020573973656e-02
    z[7,8,2]  R2119     -3.9456307888031006e-01
    z[7,8,2]  R2120     1.4970616437494755e-02
    z[7,8,2]  R2121     -2.2499936819076538e-01
    z[7,8,2]  R2122     -3.0829888582229614e-01
    z[7,8,2]  R2123     -5.0885128974914551e-01
    z[7,8,2]  R2124     -1.9861342012882233e-01
    z[7,8,2]  R2125     1.7511947453022003e-01
    z[7,8,2]  R2126     -8.4100671112537384e-02
    z[7,8,2]  R2127     -3.9988321065902710e-01
    z[7,8,2]  R2128     -1.9476985931396484e-01
    z[7,8,2]  R2129     -1.7199251055717468e-01
    z[7,8,2]  R2130     9.7669489681720734e-02
    z[7,8,2]  R2131     9.2239312827587128e-02
    z[7,8,2]  R2132     2.9931798577308655e-01
    z[7,8,2]  R2133     2.7387386560440063e-01
    z[7,8,2]  R2134     -2.5816044211387634e-01
    z[7,8,2]  R2135     7.1744687855243683e-02
    z[7,8,2]  R2136     4.7955888509750366e-01
    z[7,8,2]  R2137     5.2574193477630615e-01
    z[7,8,2]  R2138     0.565449595451355
    z[7,8,2]  R2139     8.1553924083709717e-01
    z[7,8,2]  R2140     6.4739727973937988e-01
    z[7,8,2]  R2141     -3.7284132838249207e-01
    z[7,8,2]  R2142     -1.2426032125949860e-01
    z[7,8,2]  R2143     -1.4245571196079254e-01
    z[7,8,2]  R2144     -0.0619538351893425
    z[7,8,2]  R2145     1.6244810819625854e-01
    z[7,8,2]  R2146     -5.9567335993051529e-02
    z[7,8,2]  R2147     4.6708053350448608e-01
    z[7,8,2]  R2148     2.3357817530632019e-01
    z[7,8,2]  R2149     -2.5872397422790527e-01
    z[7,8,2]  R2150     -3.5164999961853027e-01
    z[7,8,2]  R2151     0.294384241104126
    z[7,8,2]  R2152     -3.7575873732566833e-01
    z[7,8,2]  R2153     -6.5847319364547729e-01
    z[7,8,2]  R2154     -2.9010412096977234e-01
    z[7,8,2]  R2155     -2.9292309284210205e-01
    z[7,8,2]  R2156     -0.102711021900177
    z[7,8,2]  R2157     -2.1386066079139709e-01
    z[7,8,2]  R2158     -0.245735302567482
    z[7,8,2]  R2159     -4.9894452095031738e-01
    z[7,8,2]  R2160     -1.9249689579010010e-01
    z[7,8,2]  R2161     2.5324749946594238e-01
    z[7,8,2]  R2162     -3.1486704945564270e-01
    z[7,8,2]  R2163     -2.2246772050857544e-01
    z[7,8,2]  R2164     3.6608977243304253e-03
    z[7,8,2]  R2165     -3.7173548340797424e-01
    z[7,8,2]  R2166     -1.9826452434062958e-01
    z[7,8,2]  R2167     3.0065628886222839e-01
    z[7,8,2]  R2168     -5.4874461889266968e-01
    z[7,8,2]  R2169     1.2436462938785553e-01
    z[7,8,2]  R2170     -2.1571689844131470e-01
    z[7,8,2]  R2171     6.0266986489295959e-02
    z[7,8,2]  R2172     1.3241645693778992e-01
    z[7,8,2]  R2173     -7.5738435983657837e-01
    z[7,8,2]  R2174     -4.2077675461769104e-01
    z[7,8,2]  R2175     -8.3095115423202515e-01
    z[7,8,2]  R2176     1.3665291666984558e-01
    z[7,8,2]  R2177     -4.5909079909324646e-01
    z[7,8,2]  R2178     9.8254293203353882e-02
    z[7,8,2]  R2179     -4.2626655101776123e-01
    z[7,8,2]  R2180     1.3493350148200989e-01
    z[7,8,2]  R2181     -3.0118385329842567e-02
    z[7,8,2]  R2182     -0.602405846118927
    z[7,8,2]  R2183     -3.7822088599205017e-01
    z[7,8,2]  R2184     -1.4436319470405579e-01
    z[7,8,2]  R2185     -0.777163565158844
    z[7,8,2]  R2186     -4.3973001837730408e-01
    z[7,8,2]  R2187     -6.8632923066616058e-02
    z[7,8,2]  R2188     3.4726104140281677e-01
    z[7,8,2]  R2189     1.0989388078451157e-01
    z[7,8,2]  R2190     2.4211842101067305e-03
    z[7,8,2]  R2191     9.6697226166725159e-02
    z[7,8,2]  R2192     2.7760079503059387e-01
    z[7,8,2]  R2193     -1.9307935237884521e-01
    z[7,8,2]  R2194     7.6088112592697144e-01
    z[7,8,2]  R2195     0.29134401679039
    z[7,8,2]  R2196     -2.4838103353977203e-01
    z[7,8,2]  R2197     1.2162237614393234e-01
    z[7,8,2]  R2198     8.0715399980545044e-01
    z[7,8,2]  R2199     -0.432815819978714
    z[7,8,2]  R2200     -8.0312824249267578e-01
    z[7,8,2]  R2201     -2.5108432769775391e-01
    z[7,8,2]  R2202     -2.9693427681922913e-01
    z[7,8,2]  R2203     -5.6551790237426758e-01
    z[7,8,2]  R2204     1.9435006380081177e-01
    z[7,8,2]  R2205     -1.7551237344741821e-01
    z[7,8,2]  R2206     -6.7357398569583893e-02
    z[7,8,2]  R2207     -5.7572543621063232e-01
    z[7,8,2]  R2208     -2.7424991130828857e-01
    z[7,8,2]  R2209     1.4285388588905334e-01
    z[7,8,2]  R2210     3.7022361159324646e-01
    z[7,8,2]  R2211     -6.6915291547775269e-01
    z[7,8,2]  R2212     1.1230655014514923e-01
    z[7,8,2]  R2213     -1.3322305679321289e-01
    z[7,8,2]  R2214     -6.1300748586654663e-01
    z[7,8,2]  R2215     2.2271849215030670e-01
    z[7,8,2]  R2216     -4.7684401273727417e-02
    z[7,8,2]  R2217     -1.5192721784114838e-01
    z[7,8,2]  R2218     -3.2909657806158066e-02
    z[7,8,2]  R2219     3.5245963931083679e-01
    z[7,8,2]  R2220     0.0596194826066494
    z[7,8,2]  R2221     -3.6621391773223877e-01
    z[7,8,2]  R2222     -3.6664634943008423e-01
    z[7,8,2]  R2223     -3.6266416311264038e-01
    z[7,8,2]  R2224     -1.9708488881587982e-01
    z[7,8,2]  R2225     -2.6363670825958252e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2078     -1
    z[7,8,3]  R2079     1
    z[7,8,3]  R2086     -2.9626250267028809e-01
    z[7,8,3]  R2087     -2.2999028861522675e-01
    z[7,8,3]  R2088     7.5844698585569859e-03
    z[7,8,3]  R2089     1.7470827698707581e-01
    z[7,8,3]  R2090     -2.3054596781730652e-01
    z[7,8,3]  R2091     4.2941838502883911e-02
    z[7,8,3]  R2092     2.6938286423683167e-01
    z[7,8,3]  R2093     -1.8347822129726410e-01
    z[7,8,3]  R2094     2.2835057228803635e-02
    z[7,8,3]  R2095     -1.2176606059074402e-01
    z[7,8,3]  R2096     -3.1238058209419250e-01
    z[7,8,3]  R2097     -5.3936600685119629e-01
    z[7,8,3]  R2098     -4.5483273267745972e-01
    z[7,8,3]  R2099     2.3717571794986725e-01
    z[7,8,3]  R2100     2.7579271793365479e-01
    z[7,8,3]  R2101     4.7326812148094177e-01
    z[7,8,3]  R2102     2.3212619125843048e-01
    z[7,8,3]  R2103     2.2987088561058044e-01
    z[7,8,3]  R2104     1.3276745565235615e-02
    z[7,8,3]  R2105     1.1353657394647598e-01
    z[7,8,3]  R2106     -4.2610099911689758e-01
    z[7,8,3]  R2107     -0.831956684589386
    z[7,8,3]  R2108     -1.8074707686901093e-01
    z[7,8,3]  R2109     -6.4651817083358765e-02
    z[7,8,3]  R2110     5.5095356702804565e-01
    z[7,8,3]  R2111     4.2653241753578186e-01
    z[7,8,3]  R2112     -6.2758159637451172e-01
    z[7,8,3]  R2113     2.6210615038871765e-01
    z[7,8,3]  R2114     -2.9034152626991272e-01
    z[7,8,3]  R2115     3.8065189123153687e-01
    z[7,8,3]  R2116     -4.4731894135475159e-01
    z[7,8,3]  R2117     1.5225636959075928e-01
    z[7,8,3]  R2118     9.2400491237640381e-02
    z[7,8,3]  R2119     -5.3684246540069580e-01
    z[7,8,3]  R2120     -5.3731977939605713e-01
    z[7,8,3]  R2121     -4.2891547083854675e-01
    z[7,8,3]  R2122     -5.2493758499622345e-02
    z[7,8,3]  R2123     -1.6123464331030846e-02
    z[7,8,3]  R2124     4.0416544675827026e-01
    z[7,8,3]  R2125     -3.1007694080471992e-02
    z[7,8,3]  R2126     9.0601757168769836e-02
    z[7,8,3]  R2127     -1.4374026656150818e-01
    z[7,8,3]  R2128     -6.5655320882797241e-01
    z[7,8,3]  R2129     -7.1335101127624512e-01
    z[7,8,3]  R2130     2.9495763778686523e-01
    z[7,8,3]  R2131     1.6936121881008148e-01
    z[7,8,3]  R2132     4.0316984057426453e-01
    z[7,8,3]  R2133     7.5238578021526337e-02
    z[7,8,3]  R2134     0.525577962398529
    z[7,8,3]  R2135     5.8198040723800659e-01
    z[7,8,3]  R2136     2.5020893663167953e-02
    z[7,8,3]  R2137     -2.0159909501671791e-02
    z[7,8,3]  R2138     -2.4972374737262726e-01
    z[7,8,3]  R2139     2.0682762563228607e-01
    z[7,8,3]  R2140     8.6605958640575409e-02
    z[7,8,3]  R2141     8.7584728002548218e-01
    z[7,8,3]  R2142     0.886455774307251
    z[7,8,3]  R2143     7.7952551841735840e-01
    z[7,8,3]  R2144     6.8842327594757080e-01
    z[7,8,3]  R2145     7.6254725456237793e-01
    z[7,8,3]  R2146     -2.1076574921607971e-01
    z[7,8,3]  R2147     1.7412135004997253e-01
    z[7,8,3]  R2148     2.5826262310147285e-02
    z[7,8,3]  R2149     1.6320027410984039e-01
    z[7,8,3]  R2150     2.8141847252845764e-01
    z[7,8,3]  R2151     3.7003250326961279e-03
    z[7,8,3]  R2152     -0.00538968201726675
    z[7,8,3]  R2153     2.6330480352044106e-02
    z[7,8,3]  R2154     -1.0333186388015747e-01
    z[7,8,3]  R2155     1.6312251985073090e-01
    z[7,8,3]  R2156     6.8231053650379181e-02
    z[7,8,3]  R2157     0.591113269329071
    z[7,8,3]  R2158     -1.8255592882633209e-01
    z[7,8,3]  R2159     0.0961490273475647
    z[7,8,3]  R2160     -1.9007220864295959e-01
    z[7,8,3]  R2161     2.4882838129997253e-01
    z[7,8,3]  R2162     2.1823190152645111e-01
    z[7,8,3]  R2163     -1.9260866940021515e-01
    z[7,8,3]  R2164     -0.00952579453587532
    z[7,8,3]  R2165     -2.9420253634452820e-01
    z[7,8,3]  R2166     1.9434593617916107e-01
    z[7,8,3]  R2167     -3.4812459349632263e-01
    z[7,8,3]  R2168     2.1785824000835419e-01
    z[7,8,3]  R2169     -6.4719247817993164e-01
    z[7,8,3]  R2170     -7.3756092786788940e-01
    z[7,8,3]  R2171     -8.5562056303024292e-01
    z[7,8,3]  R2172     -0.709907591342926
    z[7,8,3]  R2173     2.2079738974571228e-01
    z[7,8,3]  R2174     3.9861035346984863e-01
    z[7,8,3]  R2175     -8.2400523126125336e-02
    z[7,8,3]  R2176     4.2890876531600952e-01
    z[7,8,3]  R2177     -1.1907821148633957e-01
    z[7,8,3]  R2178     -3.1710562109947205e-01
    z[7,8,3]  R2179     4.3346762657165527e-01
    z[7,8,3]  R2180     5.7884871959686279e-01
    z[7,8,3]  R2181     -8.2855713367462158e-01
    z[7,8,3]  R2182     2.7887905016541481e-02
    z[7,8,3]  R2183     3.4898456931114197e-01
    z[7,8,3]  R2184     3.9520654082298279e-01
    z[7,8,3]  R2185     1.0373300313949585e-01
    z[7,8,3]  R2186     2.6181671023368835e-01
    z[7,8,3]  R2187     3.0752778053283691e-02
    z[7,8,3]  R2188     -1.0336022078990936e-01
    z[7,8,3]  R2189     -1.0176008194684982e-01
    z[7,8,3]  R2190     -1.9595865160226822e-02
    z[7,8,3]  R2191     5.7871639728546143e-01
    z[7,8,3]  R2192     4.3673789501190186e-01
    z[7,8,3]  R2193     2.7254721149802208e-02
    z[7,8,3]  R2194     -5.4215413331985474e-01
    z[7,8,3]  R2195     3.5157926380634308e-02
    z[7,8,3]  R2196     8.2601845264434814e-01
    z[7,8,3]  R2197     4.0940120816230774e-01
    z[7,8,3]  R2198     -4.6199521422386169e-01
    z[7,8,3]  R2199     3.7539044022560120e-01
    z[7,8,3]  R2200     9.1040439903736115e-02
    z[7,8,3]  R2201     4.2059344053268433e-01
    z[7,8,3]  R2202     -4.6221151947975159e-01
    z[7,8,3]  R2203     7.8479431569576263e-02
    z[7,8,3]  R2204     -0.835407018661499
    z[7,8,3]  R2205     4.3667939305305481e-01
    z[7,8,3]  R2206     8.7394517660140991e-01
    z[7,8,3]  R2207     3.2051730155944824e-01
    z[7,8,3]  R2208     4.9250802397727966e-01
    z[7,8,3]  R2209     -7.9185032844543457e-01
    z[7,8,3]  R2210     1.9741542637348175e-01
    z[7,8,3]  R2211     4.6691466122865677e-03
    z[7,8,3]  R2212     -4.7329258918762207e-01
    z[7,8,3]  R2213     -4.7493028640747070e-01
    z[7,8,3]  R2214     -3.6188460886478424e-02
    z[7,8,3]  R2215     -2.6878905296325684e-01
    z[7,8,3]  R2216     -6.1702221632003784e-01
    z[7,8,3]  R2217     -7.4480628967285156e-01
    z[7,8,3]  R2218     0.576059877872467
    z[7,8,3]  R2219     -4.5782437920570374e-01
    z[7,8,3]  R2220     5.5540060997009277e-01
    z[7,8,3]  R2221     -3.3231852576136589e-03
    z[7,8,3]  R2222     1.4756141602993011e-01
    z[7,8,3]  R2223     -2.0093291997909546e-01
    z[7,8,3]  R2224     -1.4315296709537506e-01
    z[7,8,3]  R2225     2.6009619235992432e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2080     -1
    z[7,8,4]  R2081     1
    z[7,8,4]  R2086     5.2010606974363327e-02
    z[7,8,4]  R2087     -4.9195386469364166e-02
    z[7,8,4]  R2088     -3.7985664606094360e-01
    z[7,8,4]  R2089     -3.5559251904487610e-01
    z[7,8,4]  R2090     -1.4419960975646973e-01
    z[7,8,4]  R2091     7.9924903810024261e-02
    z[7,8,4]  R2092     3.2121084630489349e-02
    z[7,8,4]  R2093     -2.4918870627880096e-01
    z[7,8,4]  R2094     4.4314138591289520e-02
    z[7,8,4]  R2095     0.00996498391032219
    z[7,8,4]  R2096     3.6694124341011047e-01
    z[7,8,4]  R2097     -9.8868340253829956e-02
    z[7,8,4]  R2098     3.3180806785821915e-02
    z[7,8,4]  R2099     -2.1452265977859497e-01
    z[7,8,4]  R2100     2.3530666530132294e-01
    z[7,8,4]  R2101     1.8888242542743683e-01
    z[7,8,4]  R2102     -1.1103283613920212e-01
    z[7,8,4]  R2103     -7.7681474387645721e-02
    z[7,8,4]  R2104     -3.5406225919723511e-01
    z[7,8,4]  R2105     -8.9405968785285950e-02
    z[7,8,4]  R2106     1.9480755925178528e-01
    z[7,8,4]  R2107     -3.7798702716827393e-01
    z[7,8,4]  R2108     -3.4833812713623047e-01
    z[7,8,4]  R2109     -3.1084150075912476e-02
    z[7,8,4]  R2110     2.5017036125063896e-02
    z[7,8,4]  R2111     5.4205763339996338e-01
    z[7,8,4]  R2112     -3.4216997027397156e-01
    z[7,8,4]  R2113     -1.6029420495033264e-01
    z[7,8,4]  R2114     -2.3251923918724060e-01
    z[7,8,4]  R2115     -6.6043063998222351e-02
    z[7,8,4]  R2116     2.3488023877143860e-01
    z[7,8,4]  R2117     -4.9218330532312393e-02
    z[7,8,4]  R2118     -4.6918958425521851e-01
    z[7,8,4]  R2119     -0.301287978887558
    z[7,8,4]  R2120     -4.6428516507148743e-01
    z[7,8,4]  R2121     4.8834286630153656e-02
    z[7,8,4]  R2122     4.9995416402816772e-01
    z[7,8,4]  R2123     3.2148233056068420e-01
    z[7,8,4]  R2124     -2.7205618098378181e-02
    z[7,8,4]  R2125     3.8036105036735535e-01
    z[7,8,4]  R2126     -2.8200012445449829e-01
    z[7,8,4]  R2127     3.2433885335922241e-01
    z[7,8,4]  R2128     -4.2623001337051392e-01
    z[7,8,4]  R2129     -3.2421517372131348e-01
    z[7,8,4]  R2130     -1.0389124974608421e-02
    z[7,8,4]  R2131     1.0767946392297745e-01
    z[7,8,4]  R2132     2.7785351872444153e-01
    z[7,8,4]  R2133     -0.157674640417099
    z[7,8,4]  R2134     -5.0214350223541260e-01
    z[7,8,4]  R2135     -0.654729962348938
    z[7,8,4]  R2136     -6.0702785849571228e-02
    z[7,8,4]  R2137     -1.6370341181755066e-01
    z[7,8,4]  R2138     -2.1409824490547180e-01
    z[7,8,4]  R2139     -1.0911155492067337e-02
    z[7,8,4]  R2140     -1.8714027106761932e-01
    z[7,8,4]  R2141     -2.6003894209861755e-01
    z[7,8,4]  R2142     4.6505674719810486e-02
    z[7,8,4]  R2143     -5.3447896242141724e-01
    z[7,8,4]  R2144     -0.631626546382904
    z[7,8,4]  R2145     -6.0656398534774780e-01
    z[7,8,4]  R2146     3.8101791869848967e-03
    z[7,8,4]  R2147     -1.3773700594902039e-01
    z[7,8,4]  R2148     -2.6488479971885681e-01
    z[7,8,4]  R2149     5.4444384574890137e-01
    z[7,8,4]  R2150     2.2349333763122559e-01
    z[7,8,4]  R2151     5.1280868053436279e-01
    z[7,8,4]  R2152     -4.9400264024734497e-01
    z[7,8,4]  R2153     2.6858943700790405e-01
    z[7,8,4]  R2154     -0.381608247756958
    z[7,8,4]  R2155     0.672268271446228
    z[7,8,4]  R2156     -4.3929553031921387e-01
    z[7,8,4]  R2157     6.3479013741016388e-02
    z[7,8,4]  R2158     -3.5290178656578064e-01
    z[7,8,4]  R2159     -2.2511450946331024e-01
    z[7,8,4]  R2160     2.7396363019943237e-01
    z[7,8,4]  R2161     -0.324464350938797
    z[7,8,4]  R2162     -4.2967510223388672e-01
    z[7,8,4]  R2163     2.7419865131378174e-01
    z[7,8,4]  R2164     3.5170897841453552e-01
    z[7,8,4]  R2165     -2.0574498921632767e-03
    z[7,8,4]  R2166     5.4170109331607819e-02
    z[7,8,4]  R2167     -5.3116941452026367e-01
    z[7,8,4]  R2168     -4.3936005234718323e-01
    z[7,8,4]  R2169     2.3174965381622314e-01
    z[7,8,4]  R2170     1.9797667860984802e-01
    z[7,8,4]  R2171     2.7299249172210693e-01
    z[7,8,4]  R2172     3.4672826528549194e-01
    z[7,8,4]  R2173     0.256306916475296
    z[7,8,4]  R2174     1.2066429853439331e-01
    z[7,8,4]  R2175     4.5660361647605896e-02
    z[7,8,4]  R2176     -6.1327022314071655e-01
    z[7,8,4]  R2177     5.9897321462631226e-01
    z[7,8,4]  R2178     4.8401924967765808e-01
    z[7,8,4]  R2179     8.9172385632991791e-02
    z[7,8,4]  R2180     1.9298788160085678e-02
    z[7,8,4]  R2181     9.8577544093132019e-02
    z[7,8,4]  R2182     -1.0599945485591888e-01
    z[7,8,4]  R2183     3.6982879042625427e-01
    z[7,8,4]  R2184     1.7723430693149567e-01
    z[7,8,4]  R2185     -4.5534770935773849e-02
    z[7,8,4]  R2186     -5.9796366840600967e-02
    z[7,8,4]  R2187     -1.6417492926120758e-01
    z[7,8,4]  R2188     -9.0975128114223480e-02
    z[7,8,4]  R2189     5.3408050537109375e-01
    z[7,8,4]  R2190     0.520047664642334
    z[7,8,4]  R2191     -5.3054285049438477e-01
    z[7,8,4]  R2192     -2.5470888614654541e-01
    z[7,8,4]  R2193     4.0219381451606750e-01
    z[7,8,4]  R2194     -3.1121345236897469e-02
    z[7,8,4]  R2195     3.2903265953063965e-01
    z[7,8,4]  R2196     -5.1761273294687271e-02
    z[7,8,4]  R2197     -3.8550980389118195e-02
    z[7,8,4]  R2198     -4.5182496309280396e-02
    z[7,8,4]  R2199     -3.6956712603569031e-01
    z[7,8,4]  R2200     -1.3292072713375092e-01
    z[7,8,4]  R2201     -1.8835441768169403e-01
    z[7,8,4]  R2202     5.5422937870025635e-01
    z[7,8,4]  R2203     -1.3107995688915253e-01
    z[7,8,4]  R2204     2.4477869272232056e-01
    z[7,8,4]  R2205     4.5653986930847168e-01
    z[7,8,4]  R2206     -1.4539791643619537e-01
    z[7,8,4]  R2207     -2.5600489974021912e-01
    z[7,8,4]  R2208     -2.0681457221508026e-01
    z[7,8,4]  R2209     4.1539192199707031e-01
    z[7,8,4]  R2210     -4.3201935291290283e-01
    z[7,8,4]  R2211     2.6885172724723816e-01
    z[7,8,4]  R2212     5.6846636533737183e-01
    z[7,8,4]  R2213     6.3694953918457031e-01
    z[7,8,4]  R2214     5.3225511312484741e-01
    z[7,8,4]  R2215     2.6034596562385559e-01
    z[7,8,4]  R2216     4.3744844198226929e-01
    z[7,8,4]  R2217     1.2768211960792542e-01
    z[7,8,4]  R2218     4.9454993009567261e-01
    z[7,8,4]  R2219     5.9390527009963989e-01
    z[7,8,4]  R2220     4.8084896802902222e-01
    z[7,8,4]  R2221     1.5543513000011444e-01
    z[7,8,4]  R2222     -1.1964630335569382e-02
    z[7,8,4]  R2223     2.3769660294055939e-01
    z[7,8,4]  R2224     -6.2905423343181610e-02
    z[7,8,4]  R2225     2.1035051345825195e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2082     -1
    z[7,8,5]  R2083     1
    z[7,8,5]  R2086     9.0704366564750671e-02
    z[7,8,5]  R2087     -0.371353417634964
    z[7,8,5]  R2088     -8.5436321794986725e-02
    z[7,8,5]  R2089     -5.0231724977493286e-01
    z[7,8,5]  R2090     1.2283550947904587e-01
    z[7,8,5]  R2091     6.5591067075729370e-02
    z[7,8,5]  R2092     -1.9198393821716309e-01
    z[7,8,5]  R2093     4.0160372853279114e-01
    z[7,8,5]  R2094     -4.7288224101066589e-01
    z[7,8,5]  R2095     -5.7962954044342041e-01
    z[7,8,5]  R2096     0.0172764640301466
    z[7,8,5]  R2097     2.7332261204719543e-01
    z[7,8,5]  R2098     7.2685825824737549e-01
    z[7,8,5]  R2099     1.6292506456375122e-01
    z[7,8,5]  R2100     1.6098989173769951e-02
    z[7,8,5]  R2101     1.7929413914680481e-01
    z[7,8,5]  R2102     -3.2500532269477844e-01
    z[7,8,5]  R2103     4.8621863126754761e-01
    z[7,8,5]  R2104     2.1258804202079773e-01
    z[7,8,5]  R2105     5.5858159065246582e-01
    z[7,8,5]  R2106     -4.1165664792060852e-01
    z[7,8,5]  R2107     -3.1215471029281616e-01
    z[7,8,5]  R2108     4.4235071539878845e-01
    z[7,8,5]  R2109     -4.2363211512565613e-01
    z[7,8,5]  R2110     0.342980295419693
    z[7,8,5]  R2111     3.8639730215072632e-01
    z[7,8,5]  R2112     3.9249747991561890e-01
    z[7,8,5]  R2113     2.8783757239580154e-02
    z[7,8,5]  R2114     1.5860473737120628e-02
    z[7,8,5]  R2115     4.1492480784654617e-02
    z[7,8,5]  R2116     1.9243466854095459e-01
    z[7,8,5]  R2117     3.4419283270835876e-01
    z[7,8,5]  R2118     -1.6354827675968409e-03
    z[7,8,5]  R2119     3.7612563371658325e-01
    z[7,8,5]  R2120     -2.1952450275421143e-01
    z[7,8,5]  R2121     -6.0261303186416626e-01
    z[7,8,5]  R2122     -1.1767259798943996e-02
    z[7,8,5]  R2123     1.1409191787242889e-01
    z[7,8,5]  R2124     3.6852625012397766e-01
    z[7,8,5]  R2125     -2.3361924290657043e-01
    z[7,8,5]  R2126     -4.2329076677560806e-02
    z[7,8,5]  R2127     2.6129499077796936e-01
    z[7,8,5]  R2128     -4.6530234813690186e-01
    z[7,8,5]  R2129     4.0940031409263611e-01
    z[7,8,5]  R2130     9.7915731370449066e-02
    z[7,8,5]  R2131     4.4756886363029480e-01
    z[7,8,5]  R2132     -1.0332090407609940e-01
    z[7,8,5]  R2133     -3.1056505441665649e-01
    z[7,8,5]  R2134     -3.5141382366418839e-02
    z[7,8,5]  R2135     -2.0326366648077965e-02
    z[7,8,5]  R2136     -1.3654959201812744e-01
    z[7,8,5]  R2137     -9.2440247535705566e-02
    z[7,8,5]  R2138     1.0115293785929680e-02
    z[7,8,5]  R2139     1.0998719371855259e-02
    z[7,8,5]  R2140     1.2060520052909851e-01
    z[7,8,5]  R2141     -9.4037890434265137e-02
    z[7,8,5]  R2142     -3.7226337194442749e-01
    z[7,8,5]  R2143     -1.7053464055061340e-01
    z[7,8,5]  R2144     -3.1147161126136780e-01
    z[7,8,5]  R2145     -2.4714589118957520e-02
    z[7,8,5]  R2146     -3.2154834270477295e-01
    z[7,8,5]  R2147     2.6955306529998779e-01
    z[7,8,5]  R2148     -5.3265053033828735e-01
    z[7,8,5]  R2149     1.7484933137893677e-01
    z[7,8,5]  R2150     1.6320532560348511e-01
    z[7,8,5]  R2151     -2.1414074301719666e-01
    z[7,8,5]  R2152     7.7239155769348145e-01
    z[7,8,5]  R2153     1.3511365652084351e-01
    z[7,8,5]  R2154     6.2932890653610229e-01
    z[7,8,5]  R2155     -2.1945912390947342e-02
    z[7,8,5]  R2156     3.3637553453445435e-01
    z[7,8,5]  R2157     6.4657934010028839e-02
    z[7,8,5]  R2158     3.4015449881553650e-01
    z[7,8,5]  R2159     -1.7019546031951904e-01
    z[7,8,5]  R2160     5.1290357112884521e-01
    z[7,8,5]  R2161     -2.0324380695819855e-01
    z[7,8,5]  R2162     -1.7839151620864868e-01
    z[7,8,5]  R2163     5.2952367067337036e-01
    z[7,8,5]  R2164     1.2697046995162964e-01
    z[7,8,5]  R2165     -2.0534142851829529e-01
    z[7,8,5]  R2166     3.8339513540267944e-01
    z[7,8,5]  R2167     -6.2285237014293671e-02
    z[7,8,5]  R2168     4.9384722113609314e-01
    z[7,8,5]  R2169     7.0507985353469849e-01
    z[7,8,5]  R2170     4.7425702214241028e-01
    z[7,8,5]  R2171     2.9225319623947144e-01
    z[7,8,5]  R2172     4.9426114559173584e-01
    z[7,8,5]  R2173     3.1892961263656616e-01
    z[7,8,5]  R2174     4.8496076464653015e-01
    z[7,8,5]  R2175     4.0534928441047668e-01
    z[7,8,5]  R2176     1.6330938786268234e-02
    z[7,8,5]  R2177     1.9894470274448395e-01
    z[7,8,5]  R2178     -1.7619448900222778e-01
    z[7,8,5]  R2179     -5.9015041589736938e-01
    z[7,8,5]  R2180     3.0861091613769531e-01
    z[7,8,5]  R2181     5.2670252323150635e-01
    z[7,8,5]  R2182     0.238073468208313
    z[7,8,5]  R2183     7.0517018437385559e-02
    z[7,8,5]  R2184     -4.1556927561759949e-01
    z[7,8,5]  R2185     1.5158849954605103e-01
    z[7,8,5]  R2186     -1.3737757503986359e-01
    z[7,8,5]  R2187     5.3427174687385559e-02
    z[7,8,5]  R2188     2.3475063499063253e-03
    z[7,8,5]  R2189     -2.4367213249206543e-01
    z[7,8,5]  R2190     -3.1883720308542252e-02
    z[7,8,5]  R2191     -0.221435084939003
    z[7,8,5]  R2192     -2.3268258571624756e-01
    z[7,8,5]  R2193     -4.3591648340225220e-01
    z[7,8,5]  R2194     9.1966040432453156e-02
    z[7,8,5]  R2195     8.3843415975570679e-01
    z[7,8,5]  R2196     -3.9317813515663147e-01
    z[7,8,5]  R2197     -4.1142249107360840e-01
    z[7,8,5]  R2198     1.2930651009082794e-01
    z[7,8,5]  R2199     5.8101141452789307e-01
    z[7,8,5]  R2200     4.9192342907190323e-02
    z[7,8,5]  R2201     3.4624036401510239e-02
    z[7,8,5]  R2202     5.9644037485122681e-01
    z[7,8,5]  R2203     4.2838081717491150e-01
    z[7,8,5]  R2204     3.7177410721778870e-01
    z[7,8,5]  R2205     -2.0003531873226166e-01
    z[7,8,5]  R2206     -4.4080230593681335e-01
    z[7,8,5]  R2207     0.372408926486969
    z[7,8,5]  R2208     6.6106610000133514e-02
    z[7,8,5]  R2209     2.1512353420257568e-01
    z[7,8,5]  R2210     -6.4128667116165161e-01
    z[7,8,5]  R2211     5.8276677131652832e-01
    z[7,8,5]  R2212     2.9139328002929688e-01
    z[7,8,5]  R2213     2.3616470396518707e-01
    z[7,8,5]  R2214     3.9361339807510376e-01
    z[7,8,5]  R2215     0.679141640663147
    z[7,8,5]  R2216     6.2278968095779419e-01
    z[7,8,5]  R2217     6.0777628421783447e-01
    z[7,8,5]  R2218     -1.0870582610368729e-01
    z[7,8,5]  R2219     3.1675449013710022e-01
    z[7,8,5]  R2220     4.4717827439308167e-01
    z[7,8,5]  R2221     2.5152226909995079e-02
    z[7,8,5]  R2222     -2.3318465054035187e-01
    z[7,8,5]  R2223     -1.5005064010620117e-01
    z[7,8,5]  R2224     1.3023109734058380e-01
    z[7,8,5]  R2225     -0.0937047228217125
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2084     -1
    z[7,8,6]  R2085     1
    z[7,8,6]  R2086     -1.0978800803422928e-01
    z[7,8,6]  R2087     -1.6560514271259308e-01
    z[7,8,6]  R2088     -1.7584989964962006e-01
    z[7,8,6]  R2089     -2.5437775254249573e-01
    z[7,8,6]  R2090     -5.5729198455810547e-01
    z[7,8,6]  R2091     -5.7539767026901245e-01
    z[7,8,6]  R2092     2.4703799188137054e-01
    z[7,8,6]  R2093     2.9298740625381470e-01
    z[7,8,6]  R2094     -4.0716385841369629e-01
    z[7,8,6]  R2095     -1.3048562407493591e-01
    z[7,8,6]  R2096     5.6856197118759155e-01
    z[7,8,6]  R2097     1.5073230862617493e-01
    z[7,8,6]  R2098     2.6217430830001831e-01
    z[7,8,6]  R2099     -4.2954996228218079e-01
    z[7,8,6]  R2100     2.2128300368785858e-01
    z[7,8,6]  R2101     9.7023620037361979e-04
    z[7,8,6]  R2102     -2.9196760058403015e-01
    z[7,8,6]  R2103     -1.1393678933382034e-01
    z[7,8,6]  R2104     -1.8036429584026337e-01
    z[7,8,6]  R2105     -0.0567796565592289
    z[7,8,6]  R2106     2.7524289488792419e-01
    z[7,8,6]  R2107     2.3761428892612457e-01
    z[7,8,6]  R2108     7.5254611670970917e-02
    z[7,8,6]  R2109     2.6987710595130920e-01
    z[7,8,6]  R2110     -7.2697363793849945e-02
    z[7,8,6]  R2111     -6.6993035376071930e-02
    z[7,8,6]  R2112     3.0445849895477295e-01
    z[7,8,6]  R2113     -1.3970334827899933e-01
    z[7,8,6]  R2114     -2.8291681408882141e-01
    z[7,8,6]  R2115     1.3887633383274078e-01
    z[7,8,6]  R2116     4.6026587486267090e-01
    z[7,8,6]  R2117     3.0812928080558777e-01
    z[7,8,6]  R2118     -1.9790825247764587e-01
    z[7,8,6]  R2119     -6.4118191599845886e-02
    z[7,8,6]  R2120     7.0299096405506134e-02
    z[7,8,6]  R2121     5.1824301481246948e-01
    z[7,8,6]  R2122     0.598641574382782
    z[7,8,6]  R2123     4.2865911126136780e-01
    z[7,8,6]  R2124     9.9234811961650848e-02
    z[7,8,6]  R2125     7.2481870651245117e-01
    z[7,8,6]  R2126     2.0238281786441803e-01
    z[7,8,6]  R2127     2.4628686904907227e-01
    z[7,8,6]  R2128     -1.8277524411678314e-01
    z[7,8,6]  R2129     -8.5760496556758881e-02
    z[7,8,6]  R2130     -2.0838232338428497e-01
    z[7,8,6]  R2131     7.8025534749031067e-02
    z[7,8,6]  R2132     -3.6871105432510376e-02
    z[7,8,6]  R2133     -7.6866008341312408e-02
    z[7,8,6]  R2134     2.5106236338615417e-01
    z[7,8,6]  R2135     2.2925668954849243e-01
    z[7,8,6]  R2136     -1.7260447144508362e-02
    z[7,8,6]  R2137     -2.0662035793066025e-02
    z[7,8,6]  R2138     2.9811248183250427e-01
    z[7,8,6]  R2139     -2.7274868916720152e-03
    z[7,8,6]  R2140     -4.4423291087150574e-01
    z[7,8,6]  R2141     8.1322342157363892e-02
    z[7,8,6]  R2142     -2.0091181993484497e-01
    z[7,8,6]  R2143     3.0219249427318573e-02
    z[7,8,6]  R2144     1.4600034058094025e-01
    z[7,8,6]  R2145     -6.8772301077842712e-02
    z[7,8,6]  R2146     2.6324397325515747e-01
    z[7,8,6]  R2147     -2.4828876554965973e-01
    z[7,8,6]  R2148     1.3578110933303833e-01
    z[7,8,6]  R2149     -4.7924673557281494e-01
    z[7,8,6]  R2150     -0.513411283493042
    z[7,8,6]  R2151     -3.8489320874214172e-01
    z[7,8,6]  R2152     -0.0986989438533783
    z[7,8,6]  R2153     3.8036710023880005e-01
    z[7,8,6]  R2154     -3.4328781068325043e-02
    z[7,8,6]  R2155     -1.0835714638233185e-01
    z[7,8,6]  R2156     2.0683281123638153e-01
    z[7,8,6]  R2157     3.1815614551305771e-02
    z[7,8,6]  R2158     1.8912982940673828e-01
    z[7,8,6]  R2159     -3.9436578750610352e-01
    z[7,8,6]  R2160     -7.2801060974597931e-02
    z[7,8,6]  R2161     -1.9014558196067810e-01
    z[7,8,6]  R2162     2.1530769765377045e-01
    z[7,8,6]  R2163     8.7286166846752167e-02
    z[7,8,6]  R2164     -2.7257224917411804e-01
    z[7,8,6]  R2165     2.3130492866039276e-01
    z[7,8,6]  R2166     1.0132461041212082e-01
    z[7,8,6]  R2167     1.9825181365013123e-01
    z[7,8,6]  R2168     3.6885300278663635e-01
    z[7,8,6]  R2169     -0.0913926288485527
    z[7,8,6]  R2170     2.9600170254707336e-01
    z[7,8,6]  R2171     2.7688222005963326e-02
    z[7,8,6]  R2172     -4.8201397061347961e-02
    z[7,8,6]  R2173     1.9878593087196350e-01
    z[7,8,6]  R2174     2.0137897133827209e-01
    z[7,8,6]  R2175     1.9239969551563263e-01
    z[7,8,6]  R2176     -1.3886536657810211e-01
    z[7,8,6]  R2177     7.5013726949691772e-02
    z[7,8,6]  R2178     -2.0114743709564209e-01
    z[7,8,6]  R2179     3.1841254234313965e-01
    z[7,8,6]  R2180     -1.0493180155754089e-01
    z[7,8,6]  R2181     1.1313805729150772e-01
    z[7,8,6]  R2182     4.9736884236335754e-01
    z[7,8,6]  R2183     2.2158469259738922e-01
    z[7,8,6]  R2184     2.3445343971252441e-01
    z[7,8,6]  R2185     -5.0230240821838379e-01
    z[7,8,6]  R2186     0.261868417263031
    z[7,8,6]  R2187     -3.0893087387084961e-02
    z[7,8,6]  R2188     -5.2927918732166290e-03
    z[7,8,6]  R2189     -7.3460757732391357e-02
    z[7,8,6]  R2190     -0.201044961810112
    z[7,8,6]  R2191     -4.5461758971214294e-02
    z[7,8,6]  R2192     -1.4415824413299561e-01
    z[7,8,6]  R2193     -7.7320039272308350e-02
    z[7,8,6]  R2194     -2.7034339308738708e-01
    z[7,8,6]  R2195     0.0845186710357666
    z[7,8,6]  R2196     2.7805145364254713e-03
    z[7,8,6]  R2197     8.3542689681053162e-03
    z[7,8,6]  R2198     -2.8224778175354004e-01
    z[7,8,6]  R2199     1.4170059561729431e-01
    z[7,8,6]  R2200     4.2444637417793274e-01
    z[7,8,6]  R2201     3.5754811763763428e-01
    z[7,8,6]  R2202     5.6581471115350723e-02
    z[7,8,6]  R2203     -1.1086313426494598e-01
    z[7,8,6]  R2204     2.4395607411861420e-02
    z[7,8,6]  R2205     0.0748407393693924
    z[7,8,6]  R2206     -1.0414259135723114e-01
    z[7,8,6]  R2207     -4.4331338256597519e-02
    z[7,8,6]  R2208     3.3066761493682861e-01
    z[7,8,6]  R2209     -1.3299232721328735e-01
    z[7,8,6]  R2210     -1.5949106216430664e-01
    z[7,8,6]  R2211     -3.6813411116600037e-01
    z[7,8,6]  R2212     -3.6560556292533875e-01
    z[7,8,6]  R2213     -2.1807946264743805e-01
    z[7,8,6]  R2214     -3.5904118418693542e-01
    z[7,8,6]  R2215     5.0126284360885620e-01
    z[7,8,6]  R2216     -9.4208948314189911e-02
    z[7,8,6]  R2217     1.6494569182395935e-01
    z[7,8,6]  R2218     -1.3512144982814789e-01
    z[7,8,6]  R2219     -2.5242233276367188e-01
    z[7,8,6]  R2220     -4.4038379192352295e-01
    z[7,8,6]  R2221     1.2994153797626495e-01
    z[7,8,6]  R2222     1.3858821988105774e-01
    z[7,8,6]  R2223     1.2574154138565063e-01
    z[7,8,6]  R2224     1.4876842498779297e-02
    z[7,8,6]  R2225     -0.138673335313797
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2226     -1
    z[8,7,0]  R2227     1
    z[8,7,0]  R2240     -8.5061663389205933e-01
    z[8,7,0]  R2241     -6.6478002071380615e-01
    z[8,7,0]  R2242     -6.8220239877700806e-01
    z[8,7,0]  R2243     -4.2338940501213074e-01
    z[8,7,0]  R2244     -5.4683411121368408e-01
    z[8,7,0]  R2245     3.4477461129426956e-02
    z[8,7,0]  R2246     -1.3178817927837372e-01
    z[8,7,0]  R2247     -1.1144463717937469e-01
    z[8,7,0]  R2248     6.1237372457981110e-02
    z[8,7,0]  R2249     1.2883530557155609e-01
    z[8,7,0]  R2250     7.5623080134391785e-02
    z[8,7,0]  R2251     2.0187151432037354e-01
    z[8,7,0]  R2252     8.8159903883934021e-02
    z[8,7,0]  R2253     1.7221964895725250e-01
    z[8,7,0]  R2254     -3.8590118288993835e-01
    z[8,7,0]  R2255     -2.1298557519912720e-01
    z[8,7,0]  R2256     -3.4787435084581375e-02
    z[8,7,0]  R2257     0.144593745470047
    z[8,7,0]  R2258     -1.7110320925712585e-01
    z[8,7,0]  R2259     -8.2352012395858765e-02
    z[8,7,0]  R2260     -7.3613594286143780e-03
    z[8,7,0]  R2261     2.2473397850990295e-01
    z[8,7,0]  R2262     -4.5772069692611694e-01
    z[8,7,0]  R2263     3.5058337450027466e-01
    z[8,7,0]  R2264     -2.9376265406608582e-01
    z[8,7,0]  R2265     -4.7494354844093323e-01
    z[8,7,0]  R2266     -5.0987863540649414e-01
    z[8,7,0]  R2267     1.2680661678314209e-01
    z[8,7,0]  R2268     -4.7340753674507141e-01
    z[8,7,0]  R2269     -5.9228497743606567e-01
    z[8,7,0]  R2270     2.2725613415241241e-01
    z[8,7,0]  R2271     1.6647150740027428e-02
    z[8,7,0]  R2272     6.6248111426830292e-02
    z[8,7,0]  R2273     4.9591418355703354e-02
    z[8,7,0]  R2274     2.3875980079174042e-01
    z[8,7,0]  R2275     -2.0266209542751312e-01
    z[8,7,0]  R2276     1.8510530889034271e-01
    z[8,7,0]  R2277     -9.6003741025924683e-02
    z[8,7,0]  R2278     6.1135566234588623e-01
    z[8,7,0]  R2279     -3.0051884055137634e-01
    z[8,7,0]  R2280     8.3354108035564423e-02
    z[8,7,0]  R2281     -9.0884536504745483e-02
    z[8,7,0]  R2282     -3.9024937152862549e-01
    z[8,7,0]  R2283     2.0824769139289856e-01
    z[8,7,0]  R2284     0.728653073310852
    z[8,7,0]  R2285     -1.0147596150636673e-01
    z[8,7,0]  R2286     4.1850557923316956e-01
    z[8,7,0]  R2287     7.3393404483795166e-01
    z[8,7,0]  R2288     7.3931068181991577e-01
    z[8,7,0]  R2289     7.7196583151817322e-02
    z[8,7,0]  R2290     -1.5070086717605591e-01
    z[8,7,0]  R2291     -5.3566700220108032e-01
    z[8,7,0]  R2292     2.7248108386993408e-01
    z[8,7,0]  R2293     2.2686022520065308e-01
    z[8,7,0]  R2294     -1.8101686239242554e-01
    z[8,7,0]  R2295     -0.244932159781456
    z[8,7,0]  R2296     -5.3288701921701431e-02
    z[8,7,0]  R2297     -4.9755790829658508e-01
    z[8,7,0]  R2298     1.4224074780941010e-01
    z[8,7,0]  R2299     -0.27867591381073
    z[8,7,0]  R2300     -2.4550264701247215e-02
    z[8,7,0]  R2301     2.1306996047496796e-01
    z[8,7,0]  R2302     0.0872528925538063
    z[8,7,0]  R2303     -5.5026117712259293e-02
    z[8,7,0]  R2304     2.8675207495689392e-01
    z[8,7,0]  R2305     7.4092823266983032e-01
    z[8,7,0]  R2306     1.2137080729007721e-01
    z[8,7,0]  R2307     -5.8641177415847778e-01
    z[8,7,0]  R2308     9.0669281780719757e-02
    z[8,7,0]  R2309     6.9981443881988525e-01
    z[8,7,0]  R2310     -2.6681980118155479e-02
    z[8,7,0]  R2311     -2.0519353449344635e-01
    z[8,7,0]  R2312     6.7276817560195923e-01
    z[8,7,0]  R2313     -2.2326491773128510e-01
    z[8,7,0]  R2314     -4.3854388594627380e-01
    z[8,7,0]  R2315     2.2516788914799690e-02
    z[8,7,0]  R2316     -0.459357351064682
    z[8,7,0]  R2317     -0.426647424697876
    z[8,7,0]  R2318     -2.2971516475081444e-02
    z[8,7,0]  R2319     2.5697913765907288e-01
    z[8,7,0]  R2320     -5.2027054131031036e-02
    z[8,7,0]  R2321     -4.7266975045204163e-02
    z[8,7,0]  R2322     5.9770947694778442e-01
    z[8,7,0]  R2323     3.8361188769340515e-01
    z[8,7,0]  R2324     2.3431569337844849e-01
    z[8,7,0]  R2325     5.1072686910629272e-02
    z[8,7,0]  R2326     -1.3900332152843475e-01
    z[8,7,0]  R2327     -1.7442011833190918e-01
    z[8,7,0]  R2328     -2.9155322909355164e-01
    z[8,7,0]  R2329     -3.0238136649131775e-01
    z[8,7,0]  R2330     -3.3000677824020386e-01
    z[8,7,0]  R2331     -1.9318053126335144e-01
    z[8,7,0]  R2332     4.9064305424690247e-01
    z[8,7,0]  R2333     5.5800050497055054e-01
    z[8,7,0]  R2334     -5.9474945068359375e-01
    z[8,7,0]  R2335     -7.7611696720123291e-01
    z[8,7,0]  R2336     4.3887776136398315e-01
    z[8,7,0]  R2337     6.3743138313293457e-01
    z[8,7,0]  R2338     -4.6591654419898987e-01
    z[8,7,0]  R2339     -2.5724855065345764e-01
    z[8,7,0]  R2340     -5.5511754751205444e-01
    z[8,7,0]  R2341     -4.3864867091178894e-01
    z[8,7,0]  R2342     -3.7472385168075562e-01
    z[8,7,0]  R2343     -2.4024071171879768e-02
    z[8,7,0]  R2344     -1.2539096176624298e-01
    z[8,7,0]  R2345     2.6647349819540977e-02
    z[8,7,0]  R2346     -1.1489200592041016e-01
    z[8,7,0]  R2347     7.2174452245235443e-02
    z[8,7,0]  R2348     3.5291427373886108e-01
    z[8,7,0]  R2349     1.0750346630811691e-01
    z[8,7,0]  R2350     -7.1135139465332031e-01
    z[8,7,0]  R2351     -3.4161310642957687e-02
    z[8,7,0]  R2352     3.7471893429756165e-01
    z[8,7,0]  R2353     4.9668571352958679e-01
    z[8,7,0]  R2354     0.684753954410553
    z[8,7,0]  R2355     -5.9296840429306030e-01
    z[8,7,0]  R2356     3.5663238167762756e-01
    z[8,7,0]  R2357     7.0555794239044189e-01
    z[8,7,0]  R2358     -2.3794497549533844e-01
    z[8,7,0]  R2359     8.1550484895706177e-01
    z[8,7,0]  R2360     -4.4572320580482483e-01
    z[8,7,0]  R2361     7.0636653900146484e-01
    z[8,7,0]  R2362     8.5536980628967285e-01
    z[8,7,0]  R2363     -3.6302644759416580e-02
    z[8,7,0]  R2364     4.8077669739723206e-01
    z[8,7,0]  R2365     4.7387238591909409e-03
    z[8,7,0]  R2366     -3.0232161283493042e-01
    z[8,7,0]  R2367     -5.8349866420030594e-02
    z[8,7,0]  R2368     5.1991915702819824e-01
    z[8,7,0]  R2369     2.0899994671344757e-01
    z[8,7,0]  R2370     9.2597460746765137e-01
    z[8,7,0]  R2371     -4.4014748930931091e-01
    z[8,7,0]  R2372     -1.8470740318298340e-01
    z[8,7,0]  R2373     -4.0540158748626709e-01
    z[8,7,0]  R2374     -9.2076942324638367e-02
    z[8,7,0]  R2375     -1.0966061055660248e-01
    z[8,7,0]  R2376     -2.7392736077308655e-01
    z[8,7,0]  R2377     0.1094965711236
    z[8,7,0]  R2378     -5.1310116052627563e-01
    z[8,7,0]  R2379     -3.0629462003707886e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2228     -1
    z[8,7,1]  R2229     1
    z[8,7,1]  R2240     -1.5238077938556671e-01
    z[8,7,1]  R2241     -4.9546480178833008e-01
    z[8,7,1]  R2242     -1.3301602005958557e-01
    z[8,7,1]  R2243     -3.3557718992233276e-01
    z[8,7,1]  R2244     -1.6564594209194183e-01
    z[8,7,1]  R2245     -9.8058469593524933e-02
    z[8,7,1]  R2246     1.6699803993105888e-02
    z[8,7,1]  R2247     -2.0967480540275574e-01
    z[8,7,1]  R2248     -3.4673564136028290e-02
    z[8,7,1]  R2249     4.7680456191301346e-02
    z[8,7,1]  R2250     8.7954843044281006e-01
    z[8,7,1]  R2251     7.4665105342864990e-01
    z[8,7,1]  R2252     7.5145530700683594e-01
    z[8,7,1]  R2253     0.565773069858551
    z[8,7,1]  R2254     5.5502235889434814e-01
    z[8,7,1]  R2255     6.4108473062515259e-01
    z[8,7,1]  R2256     -8.4837704896926880e-02
    z[8,7,1]  R2257     5.5654048919677734e-01
    z[8,7,1]  R2258     -5.7708561420440674e-01
    z[8,7,1]  R2259     6.4547479152679443e-01
    z[8,7,1]  R2260     7.9739069938659668e-01
    z[8,7,1]  R2261     7.3832303285598755e-01
    z[8,7,1]  R2262     6.4866358041763306e-01
    z[8,7,1]  R2263     6.1946231126785278e-01
    z[8,7,1]  R2264     7.0504951477050781e-01
    z[8,7,1]  R2265     6.8237692117691040e-01
    z[8,7,1]  R2266     5.7485276460647583e-01
    z[8,7,1]  R2267     0.730842649936676
    z[8,7,1]  R2268     7.4944311380386353e-01
    z[8,7,1]  R2269     5.7339757680892944e-01
    z[8,7,1]  R2270     8.4325706958770752e-01
    z[8,7,1]  R2271     6.8030416965484619e-01
    z[8,7,1]  R2272     -2.7212768793106079e-01
    z[8,7,1]  R2273     -6.3387066125869751e-02
    z[8,7,1]  R2274     2.7062773704528809e-02
    z[8,7,1]  R2275     2.5001174211502075e-01
    z[8,7,1]  R2276     -2.7819997072219849e-01
    z[8,7,1]  R2277     -4.0184023976325989e-01
    z[8,7,1]  R2278     -8.2699873019009829e-04
    z[8,7,1]  R2279     -9.4911180436611176e-02
    z[8,7,1]  R2280     6.2830311059951782e-01
    z[8,7,1]  R2281     6.0234630107879639e-01
    z[8,7,1]  R2282     6.5705102682113647e-01
    z[8,7,1]  R2283     3.5974937677383423e-01
    z[8,7,1]  R2284     9.5749676227569580e-02
    z[8,7,1]  R2285     -4.8531722277402878e-02
    z[8,7,1]  R2286     -3.8195803761482239e-01
    z[8,7,1]  R2287     7.5192131102085114e-02
    z[8,7,1]  R2288     1.3157719373703003e-01
    z[8,7,1]  R2289     -3.1927531957626343e-01
    z[8,7,1]  R2290     7.9016172885894775e-01
    z[8,7,1]  R2291     8.2258272171020508e-01
    z[8,7,1]  R2292     8.8666254281997681e-01
    z[8,7,1]  R2293     7.5900465250015259e-01
    z[8,7,1]  R2294     0.809294581413269
    z[8,7,1]  R2295     5.1300019025802612e-01
    z[8,7,1]  R2296     7.6782727241516113e-01
    z[8,7,1]  R2297     5.9720373153686523e-01
    z[8,7,1]  R2298     1.5615494549274445e-01
    z[8,7,1]  R2299     -1.3358376920223236e-01
    z[8,7,1]  R2300     3.1324383616447449e-01
    z[8,7,1]  R2301     7.7548390626907349e-01
    z[8,7,1]  R2302     1.7036555707454681e-01
    z[8,7,1]  R2303     -4.1772177815437317e-01
    z[8,7,1]  R2304     -0.253431499004364
    z[8,7,1]  R2305     2.1579198539257050e-01
    z[8,7,1]  R2306     1.3170754909515381e-01
    z[8,7,1]  R2307     -3.4229966998100281e-01
    z[8,7,1]  R2308     2.3952980339527130e-01
    z[8,7,1]  R2309     1.8633915483951569e-01
    z[8,7,1]  R2310     6.8395271897315979e-02
    z[8,7,1]  R2311     -5.6348246335983276e-01
    z[8,7,1]  R2312     2.7041158080101013e-01
    z[8,7,1]  R2313     -2.5729942321777344e-01
    z[8,7,1]  R2314     -0.0911824107170105
    z[8,7,1]  R2315     6.5456062555313110e-02
    z[8,7,1]  R2316     -1.0315380990505219e-01
    z[8,7,1]  R2317     -2.5617891550064087e-01
    z[8,7,1]  R2318     -2.3504646122455597e-01
    z[8,7,1]  R2319     -1.7841754853725433e-01
    z[8,7,1]  R2320     -1.6186280548572540e-01
    z[8,7,1]  R2321     8.3938315510749817e-02
    z[8,7,1]  R2322     1.8751224875450134e-01
    z[8,7,1]  R2323     4.7296587377786636e-02
    z[8,7,1]  R2324     -8.9162372052669525e-02
    z[8,7,1]  R2325     -9.0641617774963379e-01
    z[8,7,1]  R2326     -8.6645781993865967e-01
    z[8,7,1]  R2327     -8.3836305141448975e-01
    z[8,7,1]  R2328     -9.1352224349975586e-01
    z[8,7,1]  R2329     -8.3615368604660034e-01
    z[8,7,1]  R2330     -6.6300463676452637e-01
    z[8,7,1]  R2331     -2.9880064725875854e-01
    z[8,7,1]  R2332     -1.4812584221363068e-01
    z[8,7,1]  R2333     -4.7706909477710724e-02
    z[8,7,1]  R2334     -4.4924414157867432e-01
    z[8,7,1]  R2335     -2.1809792518615723e-01
    z[8,7,1]  R2336     -1.2928212061524391e-02
    z[8,7,1]  R2337     -1.7264668643474579e-01
    z[8,7,1]  R2338     -5.9217959642410278e-01
    z[8,7,1]  R2339     -0.657151460647583
    z[8,7,1]  R2340     3.5223123431205750e-01
    z[8,7,1]  R2341     6.1220955848693848e-01
    z[8,7,1]  R2342     2.0237313210964203e-01
    z[8,7,1]  R2343     8.1670624017715454e-01
    z[8,7,1]  R2344     8.9486467838287354e-01
    z[8,7,1]  R2345     8.2600003480911255e-01
    z[8,7,1]  R2346     0.843882143497467
    z[8,7,1]  R2347     7.5049263238906860e-01
    z[8,7,1]  R2348     7.9955446720123291e-01
    z[8,7,1]  R2349     7.8682017326354980e-01
    z[8,7,1]  R2350     1.5438741445541382e-01
    z[8,7,1]  R2351     -1.8111892044544220e-02
    z[8,7,1]  R2352     6.3355618715286255e-01
    z[8,7,1]  R2353     -7.0401608943939209e-01
    z[8,7,1]  R2354     -0.317990779876709
    z[8,7,1]  R2355     -9.9937207996845245e-02
    z[8,7,1]  R2356     1.9208516925573349e-02
    z[8,7,1]  R2357     -6.1492401361465454e-01
    z[8,7,1]  R2358     8.4363776445388794e-01
    z[8,7,1]  R2359     2.1581551432609558e-01
    z[8,7,1]  R2360     1.5701790153980255e-01
    z[8,7,1]  R2361     -2.6684790849685669e-01
    z[8,7,1]  R2362     1.1021289043128490e-02
    z[8,7,1]  R2363     -5.6431031227111816e-01
    z[8,7,1]  R2364     -4.5959058403968811e-01
    z[8,7,1]  R2365     -0.362327516078949
    z[8,7,1]  R2366     -4.4981494545936584e-01
    z[8,7,1]  R2367     -6.6127836704254150e-01
    z[8,7,1]  R2368     6.1683690547943115e-01
    z[8,7,1]  R2369     -4.4729864597320557e-01
    z[8,7,1]  R2370     7.0814952254295349e-02
    z[8,7,1]  R2371     -6.2575900554656982e-01
    z[8,7,1]  R2372     -2.5553995370864868e-01
    z[8,7,1]  R2373     1.3084186613559723e-01
    z[8,7,1]  R2374     0.917531430721283
    z[8,7,1]  R2375     8.5602718591690063e-01
    z[8,7,1]  R2376     7.6393014192581177e-01
    z[8,7,1]  R2377     8.8324540853500366e-01
    z[8,7,1]  R2378     2.7826756238937378e-01
    z[8,7,1]  R2379     0.284063458442688
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2230     -1
    z[8,7,2]  R2231     1
    z[8,7,2]  R2240     4.7955888509750366e-01
    z[8,7,2]  R2241     5.2574193477630615e-01
    z[8,7,2]  R2242     0.565449595451355
    z[8,7,2]  R2243     8.1553924083709717e-01
    z[8,7,2]  R2244     6.4739727973937988e-01
    z[8,7,2]  R2245     -3.7284132838249207e-01
    z[8,7,2]  R2246     -1.2426032125949860e-01
    z[8,7,2]  R2247     -1.4245571196079254e-01
    z[8,7,2]  R2248     -0.0619538351893425
    z[8,7,2]  R2249     1.6244810819625854e-01
    z[8,7,2]  R2250     -5.9567335993051529e-02
    z[8,7,2]  R2251     4.6708053350448608e-01
    z[8,7,2]  R2252     2.3357817530632019e-01
    z[8,7,2]  R2253     -2.5872397422790527e-01
    z[8,7,2]  R2254     -3.5164999961853027e-01
    z[8,7,2]  R2255     0.294384241104126
    z[8,7,2]  R2256     -3.7575873732566833e-01
    z[8,7,2]  R2257     -6.5847319364547729e-01
    z[8,7,2]  R2258     -2.9010412096977234e-01
    z[8,7,2]  R2259     -2.9292309284210205e-01
    z[8,7,2]  R2260     -0.102711021900177
    z[8,7,2]  R2261     -2.1386066079139709e-01
    z[8,7,2]  R2262     -0.245735302567482
    z[8,7,2]  R2263     -4.9894452095031738e-01
    z[8,7,2]  R2264     -1.9249689579010010e-01
    z[8,7,2]  R2265     2.5324749946594238e-01
    z[8,7,2]  R2266     -3.1486704945564270e-01
    z[8,7,2]  R2267     -2.2246772050857544e-01
    z[8,7,2]  R2268     3.6608977243304253e-03
    z[8,7,2]  R2269     -3.7173548340797424e-01
    z[8,7,2]  R2270     -1.9826452434062958e-01
    z[8,7,2]  R2271     3.0065628886222839e-01
    z[8,7,2]  R2272     -5.4874461889266968e-01
    z[8,7,2]  R2273     1.2436462938785553e-01
    z[8,7,2]  R2274     -2.1571689844131470e-01
    z[8,7,2]  R2275     6.0266986489295959e-02
    z[8,7,2]  R2276     1.3241645693778992e-01
    z[8,7,2]  R2277     -7.5738435983657837e-01
    z[8,7,2]  R2278     -4.2077675461769104e-01
    z[8,7,2]  R2279     -8.3095115423202515e-01
    z[8,7,2]  R2280     1.3665291666984558e-01
    z[8,7,2]  R2281     -4.5909079909324646e-01
    z[8,7,2]  R2282     9.8254293203353882e-02
    z[8,7,2]  R2283     -4.2626655101776123e-01
    z[8,7,2]  R2284     1.3493350148200989e-01
    z[8,7,2]  R2285     -3.0118385329842567e-02
    z[8,7,2]  R2286     -0.602405846118927
    z[8,7,2]  R2287     -3.7822088599205017e-01
    z[8,7,2]  R2288     -1.4436319470405579e-01
    z[8,7,2]  R2289     -0.777163565158844
    z[8,7,2]  R2290     -4.3973001837730408e-01
    z[8,7,2]  R2291     -6.8632923066616058e-02
    z[8,7,2]  R2292     3.4726104140281677e-01
    z[8,7,2]  R2293     1.0989388078451157e-01
    z[8,7,2]  R2294     2.4211842101067305e-03
    z[8,7,2]  R2295     9.6697226166725159e-02
    z[8,7,2]  R2296     2.7760079503059387e-01
    z[8,7,2]  R2297     -1.9307935237884521e-01
    z[8,7,2]  R2298     7.6088112592697144e-01
    z[8,7,2]  R2299     0.29134401679039
    z[8,7,2]  R2300     -2.4838103353977203e-01
    z[8,7,2]  R2301     1.2162237614393234e-01
    z[8,7,2]  R2302     8.0715399980545044e-01
    z[8,7,2]  R2303     -0.432815819978714
    z[8,7,2]  R2304     -8.0312824249267578e-01
    z[8,7,2]  R2305     -2.5108432769775391e-01
    z[8,7,2]  R2306     -2.9693427681922913e-01
    z[8,7,2]  R2307     -5.6551790237426758e-01
    z[8,7,2]  R2308     1.9435006380081177e-01
    z[8,7,2]  R2309     -1.7551237344741821e-01
    z[8,7,2]  R2310     -6.7357398569583893e-02
    z[8,7,2]  R2311     -5.7572543621063232e-01
    z[8,7,2]  R2312     -2.7424991130828857e-01
    z[8,7,2]  R2313     1.4285388588905334e-01
    z[8,7,2]  R2314     3.7022361159324646e-01
    z[8,7,2]  R2315     -6.6915291547775269e-01
    z[8,7,2]  R2316     1.1230655014514923e-01
    z[8,7,2]  R2317     -1.3322305679321289e-01
    z[8,7,2]  R2318     -6.1300748586654663e-01
    z[8,7,2]  R2319     2.2271849215030670e-01
    z[8,7,2]  R2320     -4.7684401273727417e-02
    z[8,7,2]  R2321     -1.5192721784114838e-01
    z[8,7,2]  R2322     -3.2909657806158066e-02
    z[8,7,2]  R2323     3.5245963931083679e-01
    z[8,7,2]  R2324     0.0596194826066494
    z[8,7,2]  R2325     -3.6621391773223877e-01
    z[8,7,2]  R2326     -3.6664634943008423e-01
    z[8,7,2]  R2327     -3.6266416311264038e-01
    z[8,7,2]  R2328     -1.9708488881587982e-01
    z[8,7,2]  R2329     -2.6363670825958252e-01
    z[8,7,2]  R2330     5.8374935388565063e-01
    z[8,7,2]  R2331     8.0793273448944092e-01
    z[8,7,2]  R2332     -7.4482011795043945e-01
    z[8,7,2]  R2333     -4.6082508563995361e-01
    z[8,7,2]  R2334     -2.1176628768444061e-01
    z[8,7,2]  R2335     -8.0369219183921814e-02
    z[8,7,2]  R2336     -7.9732966423034668e-01
    z[8,7,2]  R2337     -4.7009339928627014e-01
    z[8,7,2]  R2338     -2.0089778304100037e-01
    z[8,7,2]  R2339     -3.6613121628761292e-01
    z[8,7,2]  R2340     1.0949367284774780e-01
    z[8,7,2]  R2341     1.8620106577873230e-01
    z[8,7,2]  R2342     -1.1659797281026840e-01
    z[8,7,2]  R2343     -1.3814368844032288e-01
    z[8,7,2]  R2344     -5.3273785859346390e-02
    z[8,7,2]  R2345     1.5876792371273041e-01
    z[8,7,2]  R2346     -1.3258361816406250e-01
    z[8,7,2]  R2347     -3.5112169384956360e-01
    z[8,7,2]  R2348     1.8139155209064484e-01
    z[8,7,2]  R2349     1.8230681121349335e-01
    z[8,7,2]  R2350     -7.3565311729907990e-02
    z[8,7,2]  R2351     -0.0978657677769661
    z[8,7,2]  R2352     -0.320696085691452
    z[8,7,2]  R2353     1.4854307286441326e-02
    z[8,7,2]  R2354     -5.3830850869417191e-02
    z[8,7,2]  R2355     9.4093732535839081e-02
    z[8,7,2]  R2356     3.3875682950019836e-01
    z[8,7,2]  R2357     9.6524387598037720e-02
    z[8,7,2]  R2358     -1.1402054876089096e-01
    z[8,7,2]  R2359     3.4367090463638306e-01
    z[8,7,2]  R2360     5.2205115556716919e-01
    z[8,7,2]  R2361     -4.3683147430419922e-01
    z[8,7,2]  R2362     -1.9336020573973656e-02
    z[8,7,2]  R2363     -3.9456307888031006e-01
    z[8,7,2]  R2364     1.4970616437494755e-02
    z[8,7,2]  R2365     -2.2499936819076538e-01
    z[8,7,2]  R2366     -3.0829888582229614e-01
    z[8,7,2]  R2367     -5.0885128974914551e-01
    z[8,7,2]  R2368     -1.9861342012882233e-01
    z[8,7,2]  R2369     1.7511947453022003e-01
    z[8,7,2]  R2370     -8.4100671112537384e-02
    z[8,7,2]  R2371     -3.9988321065902710e-01
    z[8,7,2]  R2372     -1.9476985931396484e-01
    z[8,7,2]  R2373     -1.7199251055717468e-01
    z[8,7,2]  R2374     9.7669489681720734e-02
    z[8,7,2]  R2375     9.2239312827587128e-02
    z[8,7,2]  R2376     2.9931798577308655e-01
    z[8,7,2]  R2377     2.7387386560440063e-01
    z[8,7,2]  R2378     -2.5816044211387634e-01
    z[8,7,2]  R2379     7.1744687855243683e-02
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2232     -1
    z[8,7,3]  R2233     1
    z[8,7,3]  R2240     2.5020893663167953e-02
    z[8,7,3]  R2241     -2.0159909501671791e-02
    z[8,7,3]  R2242     -2.4972374737262726e-01
    z[8,7,3]  R2243     2.0682762563228607e-01
    z[8,7,3]  R2244     8.6605958640575409e-02
    z[8,7,3]  R2245     8.7584728002548218e-01
    z[8,7,3]  R2246     0.886455774307251
    z[8,7,3]  R2247     7.7952551841735840e-01
    z[8,7,3]  R2248     6.8842327594757080e-01
    z[8,7,3]  R2249     7.6254725456237793e-01
    z[8,7,3]  R2250     -2.1076574921607971e-01
    z[8,7,3]  R2251     1.7412135004997253e-01
    z[8,7,3]  R2252     2.5826262310147285e-02
    z[8,7,3]  R2253     1.6320027410984039e-01
    z[8,7,3]  R2254     2.8141847252845764e-01
    z[8,7,3]  R2255     3.7003250326961279e-03
    z[8,7,3]  R2256     -0.00538968201726675
    z[8,7,3]  R2257     2.6330480352044106e-02
    z[8,7,3]  R2258     -1.0333186388015747e-01
    z[8,7,3]  R2259     1.6312251985073090e-01
    z[8,7,3]  R2260     6.8231053650379181e-02
    z[8,7,3]  R2261     0.591113269329071
    z[8,7,3]  R2262     -1.8255592882633209e-01
    z[8,7,3]  R2263     0.0961490273475647
    z[8,7,3]  R2264     -1.9007220864295959e-01
    z[8,7,3]  R2265     2.4882838129997253e-01
    z[8,7,3]  R2266     2.1823190152645111e-01
    z[8,7,3]  R2267     -1.9260866940021515e-01
    z[8,7,3]  R2268     -0.00952579453587532
    z[8,7,3]  R2269     -2.9420253634452820e-01
    z[8,7,3]  R2270     1.9434593617916107e-01
    z[8,7,3]  R2271     -3.4812459349632263e-01
    z[8,7,3]  R2272     2.1785824000835419e-01
    z[8,7,3]  R2273     -6.4719247817993164e-01
    z[8,7,3]  R2274     -7.3756092786788940e-01
    z[8,7,3]  R2275     -8.5562056303024292e-01
    z[8,7,3]  R2276     -0.709907591342926
    z[8,7,3]  R2277     2.2079738974571228e-01
    z[8,7,3]  R2278     3.9861035346984863e-01
    z[8,7,3]  R2279     -8.2400523126125336e-02
    z[8,7,3]  R2280     4.2890876531600952e-01
    z[8,7,3]  R2281     -1.1907821148633957e-01
    z[8,7,3]  R2282     -3.1710562109947205e-01
    z[8,7,3]  R2283     4.3346762657165527e-01
    z[8,7,3]  R2284     5.7884871959686279e-01
    z[8,7,3]  R2285     -8.2855713367462158e-01
    z[8,7,3]  R2286     2.7887905016541481e-02
    z[8,7,3]  R2287     3.4898456931114197e-01
    z[8,7,3]  R2288     3.9520654082298279e-01
    z[8,7,3]  R2289     1.0373300313949585e-01
    z[8,7,3]  R2290     2.6181671023368835e-01
    z[8,7,3]  R2291     3.0752778053283691e-02
    z[8,7,3]  R2292     -1.0336022078990936e-01
    z[8,7,3]  R2293     -1.0176008194684982e-01
    z[8,7,3]  R2294     -1.9595865160226822e-02
    z[8,7,3]  R2295     5.7871639728546143e-01
    z[8,7,3]  R2296     4.3673789501190186e-01
    z[8,7,3]  R2297     2.7254721149802208e-02
    z[8,7,3]  R2298     -5.4215413331985474e-01
    z[8,7,3]  R2299     3.5157926380634308e-02
    z[8,7,3]  R2300     8.2601845264434814e-01
    z[8,7,3]  R2301     4.0940120816230774e-01
    z[8,7,3]  R2302     -4.6199521422386169e-01
    z[8,7,3]  R2303     3.7539044022560120e-01
    z[8,7,3]  R2304     9.1040439903736115e-02
    z[8,7,3]  R2305     4.2059344053268433e-01
    z[8,7,3]  R2306     -4.6221151947975159e-01
    z[8,7,3]  R2307     7.8479431569576263e-02
    z[8,7,3]  R2308     -0.835407018661499
    z[8,7,3]  R2309     4.3667939305305481e-01
    z[8,7,3]  R2310     8.7394517660140991e-01
    z[8,7,3]  R2311     3.2051730155944824e-01
    z[8,7,3]  R2312     4.9250802397727966e-01
    z[8,7,3]  R2313     -7.9185032844543457e-01
    z[8,7,3]  R2314     1.9741542637348175e-01
    z[8,7,3]  R2315     4.6691466122865677e-03
    z[8,7,3]  R2316     -4.7329258918762207e-01
    z[8,7,3]  R2317     -4.7493028640747070e-01
    z[8,7,3]  R2318     -3.6188460886478424e-02
    z[8,7,3]  R2319     -2.6878905296325684e-01
    z[8,7,3]  R2320     -6.1702221632003784e-01
    z[8,7,3]  R2321     -7.4480628967285156e-01
    z[8,7,3]  R2322     0.576059877872467
    z[8,7,3]  R2323     -4.5782437920570374e-01
    z[8,7,3]  R2324     5.5540060997009277e-01
    z[8,7,3]  R2325     -3.3231852576136589e-03
    z[8,7,3]  R2326     1.4756141602993011e-01
    z[8,7,3]  R2327     -2.0093291997909546e-01
    z[8,7,3]  R2328     -1.4315296709537506e-01
    z[8,7,3]  R2329     2.6009619235992432e-01
    z[8,7,3]  R2330     -2.9626250267028809e-01
    z[8,7,3]  R2331     -2.2999028861522675e-01
    z[8,7,3]  R2332     7.5844698585569859e-03
    z[8,7,3]  R2333     1.7470827698707581e-01
    z[8,7,3]  R2334     -2.3054596781730652e-01
    z[8,7,3]  R2335     4.2941838502883911e-02
    z[8,7,3]  R2336     2.6938286423683167e-01
    z[8,7,3]  R2337     -1.8347822129726410e-01
    z[8,7,3]  R2338     2.2835057228803635e-02
    z[8,7,3]  R2339     -1.2176606059074402e-01
    z[8,7,3]  R2340     -3.1238058209419250e-01
    z[8,7,3]  R2341     -5.3936600685119629e-01
    z[8,7,3]  R2342     -4.5483273267745972e-01
    z[8,7,3]  R2343     2.3717571794986725e-01
    z[8,7,3]  R2344     2.7579271793365479e-01
    z[8,7,3]  R2345     4.7326812148094177e-01
    z[8,7,3]  R2346     2.3212619125843048e-01
    z[8,7,3]  R2347     2.2987088561058044e-01
    z[8,7,3]  R2348     1.3276745565235615e-02
    z[8,7,3]  R2349     1.1353657394647598e-01
    z[8,7,3]  R2350     -4.2610099911689758e-01
    z[8,7,3]  R2351     -0.831956684589386
    z[8,7,3]  R2352     -1.8074707686901093e-01
    z[8,7,3]  R2353     -6.4651817083358765e-02
    z[8,7,3]  R2354     5.5095356702804565e-01
    z[8,7,3]  R2355     4.2653241753578186e-01
    z[8,7,3]  R2356     -6.2758159637451172e-01
    z[8,7,3]  R2357     2.6210615038871765e-01
    z[8,7,3]  R2358     -2.9034152626991272e-01
    z[8,7,3]  R2359     3.8065189123153687e-01
    z[8,7,3]  R2360     -4.4731894135475159e-01
    z[8,7,3]  R2361     1.5225636959075928e-01
    z[8,7,3]  R2362     9.2400491237640381e-02
    z[8,7,3]  R2363     -5.3684246540069580e-01
    z[8,7,3]  R2364     -5.3731977939605713e-01
    z[8,7,3]  R2365     -4.2891547083854675e-01
    z[8,7,3]  R2366     -5.2493758499622345e-02
    z[8,7,3]  R2367     -1.6123464331030846e-02
    z[8,7,3]  R2368     4.0416544675827026e-01
    z[8,7,3]  R2369     -3.1007694080471992e-02
    z[8,7,3]  R2370     9.0601757168769836e-02
    z[8,7,3]  R2371     -1.4374026656150818e-01
    z[8,7,3]  R2372     -6.5655320882797241e-01
    z[8,7,3]  R2373     -7.1335101127624512e-01
    z[8,7,3]  R2374     2.9495763778686523e-01
    z[8,7,3]  R2375     1.6936121881008148e-01
    z[8,7,3]  R2376     4.0316984057426453e-01
    z[8,7,3]  R2377     7.5238578021526337e-02
    z[8,7,3]  R2378     0.525577962398529
    z[8,7,3]  R2379     5.8198040723800659e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2234     -1
    z[8,7,4]  R2235     1
    z[8,7,4]  R2240     -6.0702785849571228e-02
    z[8,7,4]  R2241     -1.6370341181755066e-01
    z[8,7,4]  R2242     -2.1409824490547180e-01
    z[8,7,4]  R2243     -1.0911155492067337e-02
    z[8,7,4]  R2244     -1.8714027106761932e-01
    z[8,7,4]  R2245     -2.6003894209861755e-01
    z[8,7,4]  R2246     4.6505674719810486e-02
    z[8,7,4]  R2247     -5.3447896242141724e-01
    z[8,7,4]  R2248     -0.631626546382904
    z[8,7,4]  R2249     -6.0656398534774780e-01
    z[8,7,4]  R2250     3.8101791869848967e-03
    z[8,7,4]  R2251     -1.3773700594902039e-01
    z[8,7,4]  R2252     -2.6488479971885681e-01
    z[8,7,4]  R2253     5.4444384574890137e-01
    z[8,7,4]  R2254     2.2349333763122559e-01
    z[8,7,4]  R2255     5.1280868053436279e-01
    z[8,7,4]  R2256     -4.9400264024734497e-01
    z[8,7,4]  R2257     2.6858943700790405e-01
    z[8,7,4]  R2258     -0.381608247756958
    z[8,7,4]  R2259     0.672268271446228
    z[8,7,4]  R2260     -4.3929553031921387e-01
    z[8,7,4]  R2261     6.3479013741016388e-02
    z[8,7,4]  R2262     -3.5290178656578064e-01
    z[8,7,4]  R2263     -2.2511450946331024e-01
    z[8,7,4]  R2264     2.7396363019943237e-01
    z[8,7,4]  R2265     -0.324464350938797
    z[8,7,4]  R2266     -4.2967510223388672e-01
    z[8,7,4]  R2267     2.7419865131378174e-01
    z[8,7,4]  R2268     3.5170897841453552e-01
    z[8,7,4]  R2269     -2.0574498921632767e-03
    z[8,7,4]  R2270     5.4170109331607819e-02
    z[8,7,4]  R2271     -5.3116941452026367e-01
    z[8,7,4]  R2272     -4.3936005234718323e-01
    z[8,7,4]  R2273     2.3174965381622314e-01
    z[8,7,4]  R2274     1.9797667860984802e-01
    z[8,7,4]  R2275     2.7299249172210693e-01
    z[8,7,4]  R2276     3.4672826528549194e-01
    z[8,7,4]  R2277     0.256306916475296
    z[8,7,4]  R2278     1.2066429853439331e-01
    z[8,7,4]  R2279     4.5660361647605896e-02
    z[8,7,4]  R2280     -6.1327022314071655e-01
    z[8,7,4]  R2281     5.9897321462631226e-01
    z[8,7,4]  R2282     4.8401924967765808e-01
    z[8,7,4]  R2283     8.9172385632991791e-02
    z[8,7,4]  R2284     1.9298788160085678e-02
    z[8,7,4]  R2285     9.8577544093132019e-02
    z[8,7,4]  R2286     -1.0599945485591888e-01
    z[8,7,4]  R2287     3.6982879042625427e-01
    z[8,7,4]  R2288     1.7723430693149567e-01
    z[8,7,4]  R2289     -4.5534770935773849e-02
    z[8,7,4]  R2290     -5.9796366840600967e-02
    z[8,7,4]  R2291     -1.6417492926120758e-01
    z[8,7,4]  R2292     -9.0975128114223480e-02
    z[8,7,4]  R2293     5.3408050537109375e-01
    z[8,7,4]  R2294     0.520047664642334
    z[8,7,4]  R2295     -5.3054285049438477e-01
    z[8,7,4]  R2296     -2.5470888614654541e-01
    z[8,7,4]  R2297     4.0219381451606750e-01
    z[8,7,4]  R2298     -3.1121345236897469e-02
    z[8,7,4]  R2299     3.2903265953063965e-01
    z[8,7,4]  R2300     -5.1761273294687271e-02
    z[8,7,4]  R2301     -3.8550980389118195e-02
    z[8,7,4]  R2302     -4.5182496309280396e-02
    z[8,7,4]  R2303     -3.6956712603569031e-01
    z[8,7,4]  R2304     -1.3292072713375092e-01
    z[8,7,4]  R2305     -1.8835441768169403e-01
    z[8,7,4]  R2306     5.5422937870025635e-01
    z[8,7,4]  R2307     -1.3107995688915253e-01
    z[8,7,4]  R2308     2.4477869272232056e-01
    z[8,7,4]  R2309     4.5653986930847168e-01
    z[8,7,4]  R2310     -1.4539791643619537e-01
    z[8,7,4]  R2311     -2.5600489974021912e-01
    z[8,7,4]  R2312     -2.0681457221508026e-01
    z[8,7,4]  R2313     4.1539192199707031e-01
    z[8,7,4]  R2314     -4.3201935291290283e-01
    z[8,7,4]  R2315     2.6885172724723816e-01
    z[8,7,4]  R2316     5.6846636533737183e-01
    z[8,7,4]  R2317     6.3694953918457031e-01
    z[8,7,4]  R2318     5.3225511312484741e-01
    z[8,7,4]  R2319     2.6034596562385559e-01
    z[8,7,4]  R2320     4.3744844198226929e-01
    z[8,7,4]  R2321     1.2768211960792542e-01
    z[8,7,4]  R2322     4.9454993009567261e-01
    z[8,7,4]  R2323     5.9390527009963989e-01
    z[8,7,4]  R2324     4.8084896802902222e-01
    z[8,7,4]  R2325     1.5543513000011444e-01
    z[8,7,4]  R2326     -1.1964630335569382e-02
    z[8,7,4]  R2327     2.3769660294055939e-01
    z[8,7,4]  R2328     -6.2905423343181610e-02
    z[8,7,4]  R2329     2.1035051345825195e-01
    z[8,7,4]  R2330     5.2010606974363327e-02
    z[8,7,4]  R2331     -4.9195386469364166e-02
    z[8,7,4]  R2332     -3.7985664606094360e-01
    z[8,7,4]  R2333     -3.5559251904487610e-01
    z[8,7,4]  R2334     -1.4419960975646973e-01
    z[8,7,4]  R2335     7.9924903810024261e-02
    z[8,7,4]  R2336     3.2121084630489349e-02
    z[8,7,4]  R2337     -2.4918870627880096e-01
    z[8,7,4]  R2338     4.4314138591289520e-02
    z[8,7,4]  R2339     0.00996498391032219
    z[8,7,4]  R2340     3.6694124341011047e-01
    z[8,7,4]  R2341     -9.8868340253829956e-02
    z[8,7,4]  R2342     3.3180806785821915e-02
    z[8,7,4]  R2343     -2.1452265977859497e-01
    z[8,7,4]  R2344     2.3530666530132294e-01
    z[8,7,4]  R2345     1.8888242542743683e-01
    z[8,7,4]  R2346     -1.1103283613920212e-01
    z[8,7,4]  R2347     -7.7681474387645721e-02
    z[8,7,4]  R2348     -3.5406225919723511e-01
    z[8,7,4]  R2349     -8.9405968785285950e-02
    z[8,7,4]  R2350     1.9480755925178528e-01
    z[8,7,4]  R2351     -3.7798702716827393e-01
    z[8,7,4]  R2352     -3.4833812713623047e-01
    z[8,7,4]  R2353     -3.1084150075912476e-02
    z[8,7,4]  R2354     2.5017036125063896e-02
    z[8,7,4]  R2355     5.4205763339996338e-01
    z[8,7,4]  R2356     -3.4216997027397156e-01
    z[8,7,4]  R2357     -1.6029420495033264e-01
    z[8,7,4]  R2358     -2.3251923918724060e-01
    z[8,7,4]  R2359     -6.6043063998222351e-02
    z[8,7,4]  R2360     2.3488023877143860e-01
    z[8,7,4]  R2361     -4.9218330532312393e-02
    z[8,7,4]  R2362     -4.6918958425521851e-01
    z[8,7,4]  R2363     -0.301287978887558
    z[8,7,4]  R2364     -4.6428516507148743e-01
    z[8,7,4]  R2365     4.8834286630153656e-02
    z[8,7,4]  R2366     4.9995416402816772e-01
    z[8,7,4]  R2367     3.2148233056068420e-01
    z[8,7,4]  R2368     -2.7205618098378181e-02
    z[8,7,4]  R2369     3.8036105036735535e-01
    z[8,7,4]  R2370     -2.8200012445449829e-01
    z[8,7,4]  R2371     3.2433885335922241e-01
    z[8,7,4]  R2372     -4.2623001337051392e-01
    z[8,7,4]  R2373     -3.2421517372131348e-01
    z[8,7,4]  R2374     -1.0389124974608421e-02
    z[8,7,4]  R2375     1.0767946392297745e-01
    z[8,7,4]  R2376     2.7785351872444153e-01
    z[8,7,4]  R2377     -0.157674640417099
    z[8,7,4]  R2378     -5.0214350223541260e-01
    z[8,7,4]  R2379     -0.654729962348938
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2236     -1
    z[8,7,5]  R2237     1
    z[8,7,5]  R2240     -1.3654959201812744e-01
    z[8,7,5]  R2241     -9.2440247535705566e-02
    z[8,7,5]  R2242     1.0115293785929680e-02
    z[8,7,5]  R2243     1.0998719371855259e-02
    z[8,7,5]  R2244     1.2060520052909851e-01
    z[8,7,5]  R2245     -9.4037890434265137e-02
    z[8,7,5]  R2246     -3.7226337194442749e-01
    z[8,7,5]  R2247     -1.7053464055061340e-01
    z[8,7,5]  R2248     -3.1147161126136780e-01
    z[8,7,5]  R2249     -2.4714589118957520e-02
    z[8,7,5]  R2250     -3.2154834270477295e-01
    z[8,7,5]  R2251     2.6955306529998779e-01
    z[8,7,5]  R2252     -5.3265053033828735e-01
    z[8,7,5]  R2253     1.7484933137893677e-01
    z[8,7,5]  R2254     1.6320532560348511e-01
    z[8,7,5]  R2255     -2.1414074301719666e-01
    z[8,7,5]  R2256     7.7239155769348145e-01
    z[8,7,5]  R2257     1.3511365652084351e-01
    z[8,7,5]  R2258     6.2932890653610229e-01
    z[8,7,5]  R2259     -2.1945912390947342e-02
    z[8,7,5]  R2260     3.3637553453445435e-01
    z[8,7,5]  R2261     6.4657934010028839e-02
    z[8,7,5]  R2262     3.4015449881553650e-01
    z[8,7,5]  R2263     -1.7019546031951904e-01
    z[8,7,5]  R2264     5.1290357112884521e-01
    z[8,7,5]  R2265     -2.0324380695819855e-01
    z[8,7,5]  R2266     -1.7839151620864868e-01
    z[8,7,5]  R2267     5.2952367067337036e-01
    z[8,7,5]  R2268     1.2697046995162964e-01
    z[8,7,5]  R2269     -2.0534142851829529e-01
    z[8,7,5]  R2270     3.8339513540267944e-01
    z[8,7,5]  R2271     -6.2285237014293671e-02
    z[8,7,5]  R2272     4.9384722113609314e-01
    z[8,7,5]  R2273     7.0507985353469849e-01
    z[8,7,5]  R2274     4.7425702214241028e-01
    z[8,7,5]  R2275     2.9225319623947144e-01
    z[8,7,5]  R2276     4.9426114559173584e-01
    z[8,7,5]  R2277     3.1892961263656616e-01
    z[8,7,5]  R2278     4.8496076464653015e-01
    z[8,7,5]  R2279     4.0534928441047668e-01
    z[8,7,5]  R2280     1.6330938786268234e-02
    z[8,7,5]  R2281     1.9894470274448395e-01
    z[8,7,5]  R2282     -1.7619448900222778e-01
    z[8,7,5]  R2283     -5.9015041589736938e-01
    z[8,7,5]  R2284     3.0861091613769531e-01
    z[8,7,5]  R2285     5.2670252323150635e-01
    z[8,7,5]  R2286     0.238073468208313
    z[8,7,5]  R2287     7.0517018437385559e-02
    z[8,7,5]  R2288     -4.1556927561759949e-01
    z[8,7,5]  R2289     1.5158849954605103e-01
    z[8,7,5]  R2290     -1.3737757503986359e-01
    z[8,7,5]  R2291     5.3427174687385559e-02
    z[8,7,5]  R2292     2.3475063499063253e-03
    z[8,7,5]  R2293     -2.4367213249206543e-01
    z[8,7,5]  R2294     -3.1883720308542252e-02
    z[8,7,5]  R2295     -0.221435084939003
    z[8,7,5]  R2296     -2.3268258571624756e-01
    z[8,7,5]  R2297     -4.3591648340225220e-01
    z[8,7,5]  R2298     9.1966040432453156e-02
    z[8,7,5]  R2299     8.3843415975570679e-01
    z[8,7,5]  R2300     -3.9317813515663147e-01
    z[8,7,5]  R2301     -4.1142249107360840e-01
    z[8,7,5]  R2302     1.2930651009082794e-01
    z[8,7,5]  R2303     5.8101141452789307e-01
    z[8,7,5]  R2304     4.9192342907190323e-02
    z[8,7,5]  R2305     3.4624036401510239e-02
    z[8,7,5]  R2306     5.9644037485122681e-01
    z[8,7,5]  R2307     4.2838081717491150e-01
    z[8,7,5]  R2308     3.7177410721778870e-01
    z[8,7,5]  R2309     -2.0003531873226166e-01
    z[8,7,5]  R2310     -4.4080230593681335e-01
    z[8,7,5]  R2311     0.372408926486969
    z[8,7,5]  R2312     6.6106610000133514e-02
    z[8,7,5]  R2313     2.1512353420257568e-01
    z[8,7,5]  R2314     -6.4128667116165161e-01
    z[8,7,5]  R2315     5.8276677131652832e-01
    z[8,7,5]  R2316     2.9139328002929688e-01
    z[8,7,5]  R2317     2.3616470396518707e-01
    z[8,7,5]  R2318     3.9361339807510376e-01
    z[8,7,5]  R2319     0.679141640663147
    z[8,7,5]  R2320     6.2278968095779419e-01
    z[8,7,5]  R2321     6.0777628421783447e-01
    z[8,7,5]  R2322     -1.0870582610368729e-01
    z[8,7,5]  R2323     3.1675449013710022e-01
    z[8,7,5]  R2324     4.4717827439308167e-01
    z[8,7,5]  R2325     2.5152226909995079e-02
    z[8,7,5]  R2326     -2.3318465054035187e-01
    z[8,7,5]  R2327     -1.5005064010620117e-01
    z[8,7,5]  R2328     1.3023109734058380e-01
    z[8,7,5]  R2329     -0.0937047228217125
    z[8,7,5]  R2330     9.0704366564750671e-02
    z[8,7,5]  R2331     -0.371353417634964
    z[8,7,5]  R2332     -8.5436321794986725e-02
    z[8,7,5]  R2333     -5.0231724977493286e-01
    z[8,7,5]  R2334     1.2283550947904587e-01
    z[8,7,5]  R2335     6.5591067075729370e-02
    z[8,7,5]  R2336     -1.9198393821716309e-01
    z[8,7,5]  R2337     4.0160372853279114e-01
    z[8,7,5]  R2338     -4.7288224101066589e-01
    z[8,7,5]  R2339     -5.7962954044342041e-01
    z[8,7,5]  R2340     0.0172764640301466
    z[8,7,5]  R2341     2.7332261204719543e-01
    z[8,7,5]  R2342     7.2685825824737549e-01
    z[8,7,5]  R2343     1.6292506456375122e-01
    z[8,7,5]  R2344     1.6098989173769951e-02
    z[8,7,5]  R2345     1.7929413914680481e-01
    z[8,7,5]  R2346     -3.2500532269477844e-01
    z[8,7,5]  R2347     4.8621863126754761e-01
    z[8,7,5]  R2348     2.1258804202079773e-01
    z[8,7,5]  R2349     5.5858159065246582e-01
    z[8,7,5]  R2350     -4.1165664792060852e-01
    z[8,7,5]  R2351     -3.1215471029281616e-01
    z[8,7,5]  R2352     4.4235071539878845e-01
    z[8,7,5]  R2353     -4.2363211512565613e-01
    z[8,7,5]  R2354     0.342980295419693
    z[8,7,5]  R2355     3.8639730215072632e-01
    z[8,7,5]  R2356     3.9249747991561890e-01
    z[8,7,5]  R2357     2.8783757239580154e-02
    z[8,7,5]  R2358     1.5860473737120628e-02
    z[8,7,5]  R2359     4.1492480784654617e-02
    z[8,7,5]  R2360     1.9243466854095459e-01
    z[8,7,5]  R2361     3.4419283270835876e-01
    z[8,7,5]  R2362     -1.6354827675968409e-03
    z[8,7,5]  R2363     3.7612563371658325e-01
    z[8,7,5]  R2364     -2.1952450275421143e-01
    z[8,7,5]  R2365     -6.0261303186416626e-01
    z[8,7,5]  R2366     -1.1767259798943996e-02
    z[8,7,5]  R2367     1.1409191787242889e-01
    z[8,7,5]  R2368     3.6852625012397766e-01
    z[8,7,5]  R2369     -2.3361924290657043e-01
    z[8,7,5]  R2370     -4.2329076677560806e-02
    z[8,7,5]  R2371     2.6129499077796936e-01
    z[8,7,5]  R2372     -4.6530234813690186e-01
    z[8,7,5]  R2373     4.0940031409263611e-01
    z[8,7,5]  R2374     9.7915731370449066e-02
    z[8,7,5]  R2375     4.4756886363029480e-01
    z[8,7,5]  R2376     -1.0332090407609940e-01
    z[8,7,5]  R2377     -3.1056505441665649e-01
    z[8,7,5]  R2378     -3.5141382366418839e-02
    z[8,7,5]  R2379     -2.0326366648077965e-02
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2238     -1
    z[8,7,6]  R2239     1
    z[8,7,6]  R2240     -1.7260447144508362e-02
    z[8,7,6]  R2241     -2.0662035793066025e-02
    z[8,7,6]  R2242     2.9811248183250427e-01
    z[8,7,6]  R2243     -2.7274868916720152e-03
    z[8,7,6]  R2244     -4.4423291087150574e-01
    z[8,7,6]  R2245     8.1322342157363892e-02
    z[8,7,6]  R2246     -2.0091181993484497e-01
    z[8,7,6]  R2247     3.0219249427318573e-02
    z[8,7,6]  R2248     1.4600034058094025e-01
    z[8,7,6]  R2249     -6.8772301077842712e-02
    z[8,7,6]  R2250     2.6324397325515747e-01
    z[8,7,6]  R2251     -2.4828876554965973e-01
    z[8,7,6]  R2252     1.3578110933303833e-01
    z[8,7,6]  R2253     -4.7924673557281494e-01
    z[8,7,6]  R2254     -0.513411283493042
    z[8,7,6]  R2255     -3.8489320874214172e-01
    z[8,7,6]  R2256     -0.0986989438533783
    z[8,7,6]  R2257     3.8036710023880005e-01
    z[8,7,6]  R2258     -3.4328781068325043e-02
    z[8,7,6]  R2259     -1.0835714638233185e-01
    z[8,7,6]  R2260     2.0683281123638153e-01
    z[8,7,6]  R2261     3.1815614551305771e-02
    z[8,7,6]  R2262     1.8912982940673828e-01
    z[8,7,6]  R2263     -3.9436578750610352e-01
    z[8,7,6]  R2264     -7.2801060974597931e-02
    z[8,7,6]  R2265     -1.9014558196067810e-01
    z[8,7,6]  R2266     2.1530769765377045e-01
    z[8,7,6]  R2267     8.7286166846752167e-02
    z[8,7,6]  R2268     -2.7257224917411804e-01
    z[8,7,6]  R2269     2.3130492866039276e-01
    z[8,7,6]  R2270     1.0132461041212082e-01
    z[8,7,6]  R2271     1.9825181365013123e-01
    z[8,7,6]  R2272     3.6885300278663635e-01
    z[8,7,6]  R2273     -0.0913926288485527
    z[8,7,6]  R2274     2.9600170254707336e-01
    z[8,7,6]  R2275     2.7688222005963326e-02
    z[8,7,6]  R2276     -4.8201397061347961e-02
    z[8,7,6]  R2277     1.9878593087196350e-01
    z[8,7,6]  R2278     2.0137897133827209e-01
    z[8,7,6]  R2279     1.9239969551563263e-01
    z[8,7,6]  R2280     -1.3886536657810211e-01
    z[8,7,6]  R2281     7.5013726949691772e-02
    z[8,7,6]  R2282     -2.0114743709564209e-01
    z[8,7,6]  R2283     3.1841254234313965e-01
    z[8,7,6]  R2284     -1.0493180155754089e-01
    z[8,7,6]  R2285     1.1313805729150772e-01
    z[8,7,6]  R2286     4.9736884236335754e-01
    z[8,7,6]  R2287     2.2158469259738922e-01
    z[8,7,6]  R2288     2.3445343971252441e-01
    z[8,7,6]  R2289     -5.0230240821838379e-01
    z[8,7,6]  R2290     0.261868417263031
    z[8,7,6]  R2291     -3.0893087387084961e-02
    z[8,7,6]  R2292     -5.2927918732166290e-03
    z[8,7,6]  R2293     -7.3460757732391357e-02
    z[8,7,6]  R2294     -0.201044961810112
    z[8,7,6]  R2295     -4.5461758971214294e-02
    z[8,7,6]  R2296     -1.4415824413299561e-01
    z[8,7,6]  R2297     -7.7320039272308350e-02
    z[8,7,6]  R2298     -2.7034339308738708e-01
    z[8,7,6]  R2299     0.0845186710357666
    z[8,7,6]  R2300     2.7805145364254713e-03
    z[8,7,6]  R2301     8.3542689681053162e-03
    z[8,7,6]  R2302     -2.8224778175354004e-01
    z[8,7,6]  R2303     1.4170059561729431e-01
    z[8,7,6]  R2304     4.2444637417793274e-01
    z[8,7,6]  R2305     3.5754811763763428e-01
    z[8,7,6]  R2306     5.6581471115350723e-02
    z[8,7,6]  R2307     -1.1086313426494598e-01
    z[8,7,6]  R2308     2.4395607411861420e-02
    z[8,7,6]  R2309     0.0748407393693924
    z[8,7,6]  R2310     -1.0414259135723114e-01
    z[8,7,6]  R2311     -4.4331338256597519e-02
    z[8,7,6]  R2312     3.3066761493682861e-01
    z[8,7,6]  R2313     -1.3299232721328735e-01
    z[8,7,6]  R2314     -1.5949106216430664e-01
    z[8,7,6]  R2315     -3.6813411116600037e-01
    z[8,7,6]  R2316     -3.6560556292533875e-01
    z[8,7,6]  R2317     -2.1807946264743805e-01
    z[8,7,6]  R2318     -3.5904118418693542e-01
    z[8,7,6]  R2319     5.0126284360885620e-01
    z[8,7,6]  R2320     -9.4208948314189911e-02
    z[8,7,6]  R2321     1.6494569182395935e-01
    z[8,7,6]  R2322     -1.3512144982814789e-01
    z[8,7,6]  R2323     -2.5242233276367188e-01
    z[8,7,6]  R2324     -4.4038379192352295e-01
    z[8,7,6]  R2325     1.2994153797626495e-01
    z[8,7,6]  R2326     1.3858821988105774e-01
    z[8,7,6]  R2327     1.2574154138565063e-01
    z[8,7,6]  R2328     1.4876842498779297e-02
    z[8,7,6]  R2329     -0.138673335313797
    z[8,7,6]  R2330     -1.0978800803422928e-01
    z[8,7,6]  R2331     -1.6560514271259308e-01
    z[8,7,6]  R2332     -1.7584989964962006e-01
    z[8,7,6]  R2333     -2.5437775254249573e-01
    z[8,7,6]  R2334     -5.5729198455810547e-01
    z[8,7,6]  R2335     -5.7539767026901245e-01
    z[8,7,6]  R2336     2.4703799188137054e-01
    z[8,7,6]  R2337     2.9298740625381470e-01
    z[8,7,6]  R2338     -4.0716385841369629e-01
    z[8,7,6]  R2339     -1.3048562407493591e-01
    z[8,7,6]  R2340     5.6856197118759155e-01
    z[8,7,6]  R2341     1.5073230862617493e-01
    z[8,7,6]  R2342     2.6217430830001831e-01
    z[8,7,6]  R2343     -4.2954996228218079e-01
    z[8,7,6]  R2344     2.2128300368785858e-01
    z[8,7,6]  R2345     9.7023620037361979e-04
    z[8,7,6]  R2346     -2.9196760058403015e-01
    z[8,7,6]  R2347     -1.1393678933382034e-01
    z[8,7,6]  R2348     -1.8036429584026337e-01
    z[8,7,6]  R2349     -0.0567796565592289
    z[8,7,6]  R2350     2.7524289488792419e-01
    z[8,7,6]  R2351     2.3761428892612457e-01
    z[8,7,6]  R2352     7.5254611670970917e-02
    z[8,7,6]  R2353     2.6987710595130920e-01
    z[8,7,6]  R2354     -7.2697363793849945e-02
    z[8,7,6]  R2355     -6.6993035376071930e-02
    z[8,7,6]  R2356     3.0445849895477295e-01
    z[8,7,6]  R2357     -1.3970334827899933e-01
    z[8,7,6]  R2358     -2.8291681408882141e-01
    z[8,7,6]  R2359     1.3887633383274078e-01
    z[8,7,6]  R2360     4.6026587486267090e-01
    z[8,7,6]  R2361     3.0812928080558777e-01
    z[8,7,6]  R2362     -1.9790825247764587e-01
    z[8,7,6]  R2363     -6.4118191599845886e-02
    z[8,7,6]  R2364     7.0299096405506134e-02
    z[8,7,6]  R2365     5.1824301481246948e-01
    z[8,7,6]  R2366     0.598641574382782
    z[8,7,6]  R2367     4.2865911126136780e-01
    z[8,7,6]  R2368     9.9234811961650848e-02
    z[8,7,6]  R2369     7.2481870651245117e-01
    z[8,7,6]  R2370     2.0238281786441803e-01
    z[8,7,6]  R2371     2.4628686904907227e-01
    z[8,7,6]  R2372     -1.8277524411678314e-01
    z[8,7,6]  R2373     -8.5760496556758881e-02
    z[8,7,6]  R2374     -2.0838232338428497e-01
    z[8,7,6]  R2375     7.8025534749031067e-02
    z[8,7,6]  R2376     -3.6871105432510376e-02
    z[8,7,6]  R2377     -7.6866008341312408e-02
    z[8,7,6]  R2378     2.5106236338615417e-01
    z[8,7,6]  R2379     2.2925668954849243e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2380     -1
    z[8,9,0]  R2381     1
    z[8,9,0]  R2394     -8.5061663389205933e-01
    z[8,9,0]  R2395     -6.6478002071380615e-01
    z[8,9,0]  R2396     -6.8220239877700806e-01
    z[8,9,0]  R2397     -4.2338940501213074e-01
    z[8,9,0]  R2398     -5.4683411121368408e-01
    z[8,9,0]  R2399     3.4477461129426956e-02
    z[8,9,0]  R2400     -1.3178817927837372e-01
    z[8,9,0]  R2401     -1.1144463717937469e-01
    z[8,9,0]  R2402     6.1237372457981110e-02
    z[8,9,0]  R2403     1.2883530557155609e-01
    z[8,9,0]  R2404     7.5623080134391785e-02
    z[8,9,0]  R2405     2.0187151432037354e-01
    z[8,9,0]  R2406     8.8159903883934021e-02
    z[8,9,0]  R2407     1.7221964895725250e-01
    z[8,9,0]  R2408     -3.8590118288993835e-01
    z[8,9,0]  R2409     -2.1298557519912720e-01
    z[8,9,0]  R2410     -3.4787435084581375e-02
    z[8,9,0]  R2411     0.144593745470047
    z[8,9,0]  R2412     -1.7110320925712585e-01
    z[8,9,0]  R2413     -8.2352012395858765e-02
    z[8,9,0]  R2414     -7.3613594286143780e-03
    z[8,9,0]  R2415     2.2473397850990295e-01
    z[8,9,0]  R2416     -4.5772069692611694e-01
    z[8,9,0]  R2417     3.5058337450027466e-01
    z[8,9,0]  R2418     -2.9376265406608582e-01
    z[8,9,0]  R2419     -4.7494354844093323e-01
    z[8,9,0]  R2420     -5.0987863540649414e-01
    z[8,9,0]  R2421     1.2680661678314209e-01
    z[8,9,0]  R2422     -4.7340753674507141e-01
    z[8,9,0]  R2423     -5.9228497743606567e-01
    z[8,9,0]  R2424     2.2725613415241241e-01
    z[8,9,0]  R2425     1.6647150740027428e-02
    z[8,9,0]  R2426     6.6248111426830292e-02
    z[8,9,0]  R2427     4.9591418355703354e-02
    z[8,9,0]  R2428     2.3875980079174042e-01
    z[8,9,0]  R2429     -2.0266209542751312e-01
    z[8,9,0]  R2430     1.8510530889034271e-01
    z[8,9,0]  R2431     -9.6003741025924683e-02
    z[8,9,0]  R2432     6.1135566234588623e-01
    z[8,9,0]  R2433     -3.0051884055137634e-01
    z[8,9,0]  R2434     8.3354108035564423e-02
    z[8,9,0]  R2435     -9.0884536504745483e-02
    z[8,9,0]  R2436     -3.9024937152862549e-01
    z[8,9,0]  R2437     2.0824769139289856e-01
    z[8,9,0]  R2438     0.728653073310852
    z[8,9,0]  R2439     -1.0147596150636673e-01
    z[8,9,0]  R2440     4.1850557923316956e-01
    z[8,9,0]  R2441     7.3393404483795166e-01
    z[8,9,0]  R2442     7.3931068181991577e-01
    z[8,9,0]  R2443     7.7196583151817322e-02
    z[8,9,0]  R2444     -1.5070086717605591e-01
    z[8,9,0]  R2445     -5.3566700220108032e-01
    z[8,9,0]  R2446     2.7248108386993408e-01
    z[8,9,0]  R2447     2.2686022520065308e-01
    z[8,9,0]  R2448     -1.8101686239242554e-01
    z[8,9,0]  R2449     -0.244932159781456
    z[8,9,0]  R2450     -5.3288701921701431e-02
    z[8,9,0]  R2451     -4.9755790829658508e-01
    z[8,9,0]  R2452     1.4224074780941010e-01
    z[8,9,0]  R2453     -0.27867591381073
    z[8,9,0]  R2454     -2.4550264701247215e-02
    z[8,9,0]  R2455     2.1306996047496796e-01
    z[8,9,0]  R2456     0.0872528925538063
    z[8,9,0]  R2457     -5.5026117712259293e-02
    z[8,9,0]  R2458     2.8675207495689392e-01
    z[8,9,0]  R2459     7.4092823266983032e-01
    z[8,9,0]  R2460     1.2137080729007721e-01
    z[8,9,0]  R2461     -5.8641177415847778e-01
    z[8,9,0]  R2462     9.0669281780719757e-02
    z[8,9,0]  R2463     6.9981443881988525e-01
    z[8,9,0]  R2464     -2.6681980118155479e-02
    z[8,9,0]  R2465     -2.0519353449344635e-01
    z[8,9,0]  R2466     6.7276817560195923e-01
    z[8,9,0]  R2467     -2.2326491773128510e-01
    z[8,9,0]  R2468     -4.3854388594627380e-01
    z[8,9,0]  R2469     2.2516788914799690e-02
    z[8,9,0]  R2470     -0.459357351064682
    z[8,9,0]  R2471     -0.426647424697876
    z[8,9,0]  R2472     -2.2971516475081444e-02
    z[8,9,0]  R2473     2.5697913765907288e-01
    z[8,9,0]  R2474     -5.2027054131031036e-02
    z[8,9,0]  R2475     -4.7266975045204163e-02
    z[8,9,0]  R2476     5.9770947694778442e-01
    z[8,9,0]  R2477     3.8361188769340515e-01
    z[8,9,0]  R2478     2.3431569337844849e-01
    z[8,9,0]  R2479     5.1072686910629272e-02
    z[8,9,0]  R2480     -1.3900332152843475e-01
    z[8,9,0]  R2481     -1.7442011833190918e-01
    z[8,9,0]  R2482     -2.9155322909355164e-01
    z[8,9,0]  R2483     -3.0238136649131775e-01
    z[8,9,0]  R2484     -1.9803822040557861e-01
    z[8,9,0]  R2485     2.5238662958145142e-01
    z[8,9,0]  R2486     -1.1824974417686462e-01
    z[8,9,0]  R2487     9.9914371967315674e-02
    z[8,9,0]  R2488     2.4679099023342133e-01
    z[8,9,0]  R2489     3.8315400481224060e-02
    z[8,9,0]  R2490     -2.7499571442604065e-01
    z[8,9,0]  R2491     -3.7888471037149429e-02
    z[8,9,0]  R2492     -4.1742104291915894e-01
    z[8,9,0]  R2493     4.5252367854118347e-01
    z[8,9,0]  R2494     -2.2583612799644470e-01
    z[8,9,0]  R2495     -6.3919335603713989e-02
    z[8,9,0]  R2496     -6.7560482025146484e-01
    z[8,9,0]  R2497     -6.5368419885635376e-01
    z[8,9,0]  R2498     -9.0757891535758972e-02
    z[8,9,0]  R2499     4.4519278407096863e-01
    z[8,9,0]  R2500     3.5323637723922729e-01
    z[8,9,0]  R2501     -5.9289741516113281e-01
    z[8,9,0]  R2502     -1.8929685652256012e-01
    z[8,9,0]  R2503     1.3136033713817596e-01
    z[8,9,0]  R2504     2.3055012524127960e-01
    z[8,9,0]  R2505     1.2396096438169479e-01
    z[8,9,0]  R2506     4.2159575223922729e-01
    z[8,9,0]  R2507     -8.1610918045043945e-02
    z[8,9,0]  R2508     -2.1789768710732460e-02
    z[8,9,0]  R2509     -1.4977262914180756e-01
    z[8,9,0]  R2510     -1.1833619326353073e-01
    z[8,9,0]  R2511     -1.9463555514812469e-01
    z[8,9,0]  R2512     1.4824509620666504e-01
    z[8,9,0]  R2513     1.2747310101985931e-02
    z[8,9,0]  R2514     -5.1304832100868225e-02
    z[8,9,0]  R2515     6.9660387933254242e-02
    z[8,9,0]  R2516     -3.2370465993881226e-01
    z[8,9,0]  R2517     -1.6792871057987213e-01
    z[8,9,0]  R2518     1.7671565711498260e-01
    z[8,9,0]  R2519     6.2303312122821808e-02
    z[8,9,0]  R2520     -8.3578817546367645e-02
    z[8,9,0]  R2521     -3.5809274762868881e-02
    z[8,9,0]  R2522     0.321304053068161
    z[8,9,0]  R2523     -2.4650232493877411e-01
    z[8,9,0]  R2524     7.9818665981292725e-02
    z[8,9,0]  R2525     -1.3058078475296497e-02
    z[8,9,0]  R2526     -8.2875989377498627e-02
    z[8,9,0]  R2527     -1.0611154884099960e-01
    z[8,9,0]  R2528     4.4820201396942139e-01
    z[8,9,0]  R2529     1.6390676796436310e-01
    z[8,9,0]  R2530     -2.9395204037427902e-02
    z[8,9,0]  R2531     1.3103142380714417e-01
    z[8,9,0]  R2532     -2.9077364131808281e-02
    z[8,9,0]  R2533     -9.6925839781761169e-02
    z[8,9,0]  R2534     -1.0229860199615359e-03
    z[8,9,0]  R2535     0.0597953163087368
    z[8,9,0]  R2536     1.5860667824745178e-01
    z[8,9,0]  R2537     4.5685794949531555e-01
    z[8,9,0]  R2538     -1.3246141374111176e-01
    z[8,9,0]  R2539     1.3124756515026093e-01
    z[8,9,0]  R2540     -1.8175707757472992e-01
    z[8,9,0]  R2541     1.6447648406028748e-01
    z[8,9,0]  R2542     -6.8660169839859009e-02
    z[8,9,0]  R2543     1.8588909506797791e-01
    z[8,9,0]  R2544     4.0934991091489792e-02
    z[8,9,0]  R2545     8.4374286234378815e-02
    z[8,9,0]  R2546     -3.5348582267761230e-01
    z[8,9,0]  R2547     6.3521102070808411e-02
    z[8,9,0]  R2548     1.7299221456050873e-01
    z[8,9,0]  R2549     4.0706256031990051e-01
    z[8,9,0]  R2550     3.1329661607742310e-01
    z[8,9,0]  R2551     -2.1327106654644012e-01
    z[8,9,0]  R2552     -3.1297969818115234e-01
    z[8,9,0]  R2553     9.2750859260559082e-01
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2382     -1
    z[8,9,1]  R2383     1
    z[8,9,1]  R2394     -1.5238077938556671e-01
    z[8,9,1]  R2395     -4.9546480178833008e-01
    z[8,9,1]  R2396     -1.3301602005958557e-01
    z[8,9,1]  R2397     -3.3557718992233276e-01
    z[8,9,1]  R2398     -1.6564594209194183e-01
    z[8,9,1]  R2399     -9.8058469593524933e-02
    z[8,9,1]  R2400     1.6699803993105888e-02
    z[8,9,1]  R2401     -2.0967480540275574e-01
    z[8,9,1]  R2402     -3.4673564136028290e-02
    z[8,9,1]  R2403     4.7680456191301346e-02
    z[8,9,1]  R2404     8.7954843044281006e-01
    z[8,9,1]  R2405     7.4665105342864990e-01
    z[8,9,1]  R2406     7.5145530700683594e-01
    z[8,9,1]  R2407     0.565773069858551
    z[8,9,1]  R2408     5.5502235889434814e-01
    z[8,9,1]  R2409     6.4108473062515259e-01
    z[8,9,1]  R2410     -8.4837704896926880e-02
    z[8,9,1]  R2411     5.5654048919677734e-01
    z[8,9,1]  R2412     -5.7708561420440674e-01
    z[8,9,1]  R2413     6.4547479152679443e-01
    z[8,9,1]  R2414     7.9739069938659668e-01
    z[8,9,1]  R2415     7.3832303285598755e-01
    z[8,9,1]  R2416     6.4866358041763306e-01
    z[8,9,1]  R2417     6.1946231126785278e-01
    z[8,9,1]  R2418     7.0504951477050781e-01
    z[8,9,1]  R2419     6.8237692117691040e-01
    z[8,9,1]  R2420     5.7485276460647583e-01
    z[8,9,1]  R2421     0.730842649936676
    z[8,9,1]  R2422     7.4944311380386353e-01
    z[8,9,1]  R2423     5.7339757680892944e-01
    z[8,9,1]  R2424     8.4325706958770752e-01
    z[8,9,1]  R2425     6.8030416965484619e-01
    z[8,9,1]  R2426     -2.7212768793106079e-01
    z[8,9,1]  R2427     -6.3387066125869751e-02
    z[8,9,1]  R2428     2.7062773704528809e-02
    z[8,9,1]  R2429     2.5001174211502075e-01
    z[8,9,1]  R2430     -2.7819997072219849e-01
    z[8,9,1]  R2431     -4.0184023976325989e-01
    z[8,9,1]  R2432     -8.2699873019009829e-04
    z[8,9,1]  R2433     -9.4911180436611176e-02
    z[8,9,1]  R2434     6.2830311059951782e-01
    z[8,9,1]  R2435     6.0234630107879639e-01
    z[8,9,1]  R2436     6.5705102682113647e-01
    z[8,9,1]  R2437     3.5974937677383423e-01
    z[8,9,1]  R2438     9.5749676227569580e-02
    z[8,9,1]  R2439     -4.8531722277402878e-02
    z[8,9,1]  R2440     -3.8195803761482239e-01
    z[8,9,1]  R2441     7.5192131102085114e-02
    z[8,9,1]  R2442     1.3157719373703003e-01
    z[8,9,1]  R2443     -3.1927531957626343e-01
    z[8,9,1]  R2444     7.9016172885894775e-01
    z[8,9,1]  R2445     8.2258272171020508e-01
    z[8,9,1]  R2446     8.8666254281997681e-01
    z[8,9,1]  R2447     7.5900465250015259e-01
    z[8,9,1]  R2448     0.809294581413269
    z[8,9,1]  R2449     5.1300019025802612e-01
    z[8,9,1]  R2450     7.6782727241516113e-01
    z[8,9,1]  R2451     5.9720373153686523e-01
    z[8,9,1]  R2452     1.5615494549274445e-01
    z[8,9,1]  R2453     -1.3358376920223236e-01
    z[8,9,1]  R2454     3.1324383616447449e-01
    z[8,9,1]  R2455     7.7548390626907349e-01
    z[8,9,1]  R2456     1.7036555707454681e-01
    z[8,9,1]  R2457     -4.1772177815437317e-01
    z[8,9,1]  R2458     -0.253431499004364
    z[8,9,1]  R2459     2.1579198539257050e-01
    z[8,9,1]  R2460     1.3170754909515381e-01
    z[8,9,1]  R2461     -3.4229966998100281e-01
    z[8,9,1]  R2462     2.3952980339527130e-01
    z[8,9,1]  R2463     1.8633915483951569e-01
    z[8,9,1]  R2464     6.8395271897315979e-02
    z[8,9,1]  R2465     -5.6348246335983276e-01
    z[8,9,1]  R2466     2.7041158080101013e-01
    z[8,9,1]  R2467     -2.5729942321777344e-01
    z[8,9,1]  R2468     -0.0911824107170105
    z[8,9,1]  R2469     6.5456062555313110e-02
    z[8,9,1]  R2470     -1.0315380990505219e-01
    z[8,9,1]  R2471     -2.5617891550064087e-01
    z[8,9,1]  R2472     -2.3504646122455597e-01
    z[8,9,1]  R2473     -1.7841754853725433e-01
    z[8,9,1]  R2474     -1.6186280548572540e-01
    z[8,9,1]  R2475     8.3938315510749817e-02
    z[8,9,1]  R2476     1.8751224875450134e-01
    z[8,9,1]  R2477     4.7296587377786636e-02
    z[8,9,1]  R2478     -8.9162372052669525e-02
    z[8,9,1]  R2479     -9.0641617774963379e-01
    z[8,9,1]  R2480     -8.6645781993865967e-01
    z[8,9,1]  R2481     -8.3836305141448975e-01
    z[8,9,1]  R2482     -9.1352224349975586e-01
    z[8,9,1]  R2483     -8.3615368604660034e-01
    z[8,9,1]  R2484     -0.656193733215332
    z[8,9,1]  R2485     -6.1848628520965576e-01
    z[8,9,1]  R2486     -7.4918586015701294e-01
    z[8,9,1]  R2487     2.0149391144514084e-02
    z[8,9,1]  R2488     -2.6095548644661903e-02
    z[8,9,1]  R2489     0.0388895608484745
    z[8,9,1]  R2490     2.8341708704829216e-02
    z[8,9,1]  R2491     0.139244943857193
    z[8,9,1]  R2492     8.0143705010414124e-02
    z[8,9,1]  R2493     8.4198370575904846e-02
    z[8,9,1]  R2494     8.9956164360046387e-01
    z[8,9,1]  R2495     9.5434391498565674e-01
    z[8,9,1]  R2496     4.5133581757545471e-01
    z[8,9,1]  R2497     5.8734935522079468e-01
    z[8,9,1]  R2498     8.0117923021316528e-01
    z[8,9,1]  R2499     8.0742782354354858e-01
    z[8,9,1]  R2500     7.7990013360977173e-01
    z[8,9,1]  R2501     4.0210062265396118e-01
    z[8,9,1]  R2502     7.3686122894287109e-01
    z[8,9,1]  R2503     7.2755759954452515e-01
    z[8,9,1]  R2504     8.9741885662078857e-01
    z[8,9,1]  R2505     0.683401346206665
    z[8,9,1]  R2506     6.6133803129196167e-01
    z[8,9,1]  R2507     3.7302395701408386e-01
    z[8,9,1]  R2508     7.2715944051742554e-01
    z[8,9,1]  R2509     -7.9600110650062561e-02
    z[8,9,1]  R2510     -8.5365541279315948e-02
    z[8,9,1]  R2511     2.9185783863067627e-01
    z[8,9,1]  R2512     4.7772899270057678e-01
    z[8,9,1]  R2513     -2.7412655949592590e-01
    z[8,9,1]  R2514     0.836509644985199
    z[8,9,1]  R2515     -1.0116760432720184e-01
    z[8,9,1]  R2516     3.7425440549850464e-01
    z[8,9,1]  R2517     6.4585089683532715e-01
    z[8,9,1]  R2518     6.5990155935287476e-01
    z[8,9,1]  R2519     6.5809983015060425e-01
    z[8,9,1]  R2520     3.7371945381164551e-01
    z[8,9,1]  R2521     4.0544113516807556e-01
    z[8,9,1]  R2522     1.9971008598804474e-01
    z[8,9,1]  R2523     6.8549059331417084e-02
    z[8,9,1]  R2524     9.0633255243301392e-01
    z[8,9,1]  R2525     8.5411381721496582e-01
    z[8,9,1]  R2526     7.6084333658218384e-01
    z[8,9,1]  R2527     3.5391521453857422e-01
    z[8,9,1]  R2528     6.8245339393615723e-01
    z[8,9,1]  R2529     4.8359535634517670e-02
    z[8,9,1]  R2530     -4.0118005126714706e-03
    z[8,9,1]  R2531     3.0325686931610107e-01
    z[8,9,1]  R2532     -3.0065795779228210e-01
    z[8,9,1]  R2533     3.0287555418908596e-03
    z[8,9,1]  R2534     9.2261385917663574e-01
    z[8,9,1]  R2535     8.4715765714645386e-01
    z[8,9,1]  R2536     -4.4515966437757015e-03
    z[8,9,1]  R2537     6.7066210508346558e-01
    z[8,9,1]  R2538     1.9737848639488220e-01
    z[8,9,1]  R2539     2.5924494862556458e-01
    z[8,9,1]  R2540     2.1058626472949982e-02
    z[8,9,1]  R2541     3.7837183475494385e-01
    z[8,9,1]  R2542     8.6386218667030334e-02
    z[8,9,1]  R2543     -2.2493258118629456e-02
    z[8,9,1]  R2544     3.6461940407752991e-01
    z[8,9,1]  R2545     9.3463861942291260e-01
    z[8,9,1]  R2546     -6.1719310283660889e-01
    z[8,9,1]  R2547     7.5483016669750214e-02
    z[8,9,1]  R2548     1.4851692318916321e-01
    z[8,9,1]  R2549     1.9161993637681007e-02
    z[8,9,1]  R2550     4.6353090554475784e-02
    z[8,9,1]  R2551     -6.9504901766777039e-02
    z[8,9,1]  R2552     8.4414362907409668e-02
    z[8,9,1]  R2553     -3.2704740762710571e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2384     -1
    z[8,9,2]  R2385     1
    z[8,9,2]  R2394     4.7955888509750366e-01
    z[8,9,2]  R2395     5.2574193477630615e-01
    z[8,9,2]  R2396     0.565449595451355
    z[8,9,2]  R2397     8.1553924083709717e-01
    z[8,9,2]  R2398     6.4739727973937988e-01
    z[8,9,2]  R2399     -3.7284132838249207e-01
    z[8,9,2]  R2400     -1.2426032125949860e-01
    z[8,9,2]  R2401     -1.4245571196079254e-01
    z[8,9,2]  R2402     -0.0619538351893425
    z[8,9,2]  R2403     1.6244810819625854e-01
    z[8,9,2]  R2404     -5.9567335993051529e-02
    z[8,9,2]  R2405     4.6708053350448608e-01
    z[8,9,2]  R2406     2.3357817530632019e-01
    z[8,9,2]  R2407     -2.5872397422790527e-01
    z[8,9,2]  R2408     -3.5164999961853027e-01
    z[8,9,2]  R2409     0.294384241104126
    z[8,9,2]  R2410     -3.7575873732566833e-01
    z[8,9,2]  R2411     -6.5847319364547729e-01
    z[8,9,2]  R2412     -2.9010412096977234e-01
    z[8,9,2]  R2413     -2.9292309284210205e-01
    z[8,9,2]  R2414     -0.102711021900177
    z[8,9,2]  R2415     -2.1386066079139709e-01
    z[8,9,2]  R2416     -0.245735302567482
    z[8,9,2]  R2417     -4.9894452095031738e-01
    z[8,9,2]  R2418     -1.9249689579010010e-01
    z[8,9,2]  R2419     2.5324749946594238e-01
    z[8,9,2]  R2420     -3.1486704945564270e-01
    z[8,9,2]  R2421     -2.2246772050857544e-01
    z[8,9,2]  R2422     3.6608977243304253e-03
    z[8,9,2]  R2423     -3.7173548340797424e-01
    z[8,9,2]  R2424     -1.9826452434062958e-01
    z[8,9,2]  R2425     3.0065628886222839e-01
    z[8,9,2]  R2426     -5.4874461889266968e-01
    z[8,9,2]  R2427     1.2436462938785553e-01
    z[8,9,2]  R2428     -2.1571689844131470e-01
    z[8,9,2]  R2429     6.0266986489295959e-02
    z[8,9,2]  R2430     1.3241645693778992e-01
    z[8,9,2]  R2431     -7.5738435983657837e-01
    z[8,9,2]  R2432     -4.2077675461769104e-01
    z[8,9,2]  R2433     -8.3095115423202515e-01
    z[8,9,2]  R2434     1.3665291666984558e-01
    z[8,9,2]  R2435     -4.5909079909324646e-01
    z[8,9,2]  R2436     9.8254293203353882e-02
    z[8,9,2]  R2437     -4.2626655101776123e-01
    z[8,9,2]  R2438     1.3493350148200989e-01
    z[8,9,2]  R2439     -3.0118385329842567e-02
    z[8,9,2]  R2440     -0.602405846118927
    z[8,9,2]  R2441     -3.7822088599205017e-01
    z[8,9,2]  R2442     -1.4436319470405579e-01
    z[8,9,2]  R2443     -0.777163565158844
    z[8,9,2]  R2444     -4.3973001837730408e-01
    z[8,9,2]  R2445     -6.8632923066616058e-02
    z[8,9,2]  R2446     3.4726104140281677e-01
    z[8,9,2]  R2447     1.0989388078451157e-01
    z[8,9,2]  R2448     2.4211842101067305e-03
    z[8,9,2]  R2449     9.6697226166725159e-02
    z[8,9,2]  R2450     2.7760079503059387e-01
    z[8,9,2]  R2451     -1.9307935237884521e-01
    z[8,9,2]  R2452     7.6088112592697144e-01
    z[8,9,2]  R2453     0.29134401679039
    z[8,9,2]  R2454     -2.4838103353977203e-01
    z[8,9,2]  R2455     1.2162237614393234e-01
    z[8,9,2]  R2456     8.0715399980545044e-01
    z[8,9,2]  R2457     -0.432815819978714
    z[8,9,2]  R2458     -8.0312824249267578e-01
    z[8,9,2]  R2459     -2.5108432769775391e-01
    z[8,9,2]  R2460     -2.9693427681922913e-01
    z[8,9,2]  R2461     -5.6551790237426758e-01
    z[8,9,2]  R2462     1.9435006380081177e-01
    z[8,9,2]  R2463     -1.7551237344741821e-01
    z[8,9,2]  R2464     -6.7357398569583893e-02
    z[8,9,2]  R2465     -5.7572543621063232e-01
    z[8,9,2]  R2466     -2.7424991130828857e-01
    z[8,9,2]  R2467     1.4285388588905334e-01
    z[8,9,2]  R2468     3.7022361159324646e-01
    z[8,9,2]  R2469     -6.6915291547775269e-01
    z[8,9,2]  R2470     1.1230655014514923e-01
    z[8,9,2]  R2471     -1.3322305679321289e-01
    z[8,9,2]  R2472     -6.1300748586654663e-01
    z[8,9,2]  R2473     2.2271849215030670e-01
    z[8,9,2]  R2474     -4.7684401273727417e-02
    z[8,9,2]  R2475     -1.5192721784114838e-01
    z[8,9,2]  R2476     -3.2909657806158066e-02
    z[8,9,2]  R2477     3.5245963931083679e-01
    z[8,9,2]  R2478     0.0596194826066494
    z[8,9,2]  R2479     -3.6621391773223877e-01
    z[8,9,2]  R2480     -3.6664634943008423e-01
    z[8,9,2]  R2481     -3.6266416311264038e-01
    z[8,9,2]  R2482     -1.9708488881587982e-01
    z[8,9,2]  R2483     -2.6363670825958252e-01
    z[8,9,2]  R2484     6.0119831562042236e-01
    z[8,9,2]  R2485     6.5845674276351929e-01
    z[8,9,2]  R2486     -3.7292090058326721e-01
    z[8,9,2]  R2487     -1.6844037920236588e-02
    z[8,9,2]  R2488     0.208670973777771
    z[8,9,2]  R2489     5.1197123527526855e-01
    z[8,9,2]  R2490     2.3732237517833710e-01
    z[8,9,2]  R2491     2.5929355621337891e-01
    z[8,9,2]  R2492     -2.3566943407058716e-01
    z[8,9,2]  R2493     -1.7263881862163544e-01
    z[8,9,2]  R2494     -1.1932317912578583e-01
    z[8,9,2]  R2495     -4.7704420983791351e-02
    z[8,9,2]  R2496     1.5714508295059204e-01
    z[8,9,2]  R2497     3.1169608235359192e-01
    z[8,9,2]  R2498     -1.5421368181705475e-01
    z[8,9,2]  R2499     1.0783152282238007e-01
    z[8,9,2]  R2500     -3.2978415489196777e-01
    z[8,9,2]  R2501     -1.9020775333046913e-02
    z[8,9,2]  R2502     -0.388967901468277
    z[8,9,2]  R2503     -0.0613291971385479
    z[8,9,2]  R2504     2.5621551275253296e-01
    z[8,9,2]  R2505     3.0200770497322083e-01
    z[8,9,2]  R2506     2.6487665250897408e-02
    z[8,9,2]  R2507     5.3616754710674286e-02
    z[8,9,2]  R2508     2.7006408572196960e-01
    z[8,9,2]  R2509     -3.5139295458793640e-01
    z[8,9,2]  R2510     9.5755748450756073e-02
    z[8,9,2]  R2511     1.0427531599998474e-01
    z[8,9,2]  R2512     0.0639515370130539
    z[8,9,2]  R2513     -2.7095419168472290e-01
    z[8,9,2]  R2514     1.4329145848751068e-01
    z[8,9,2]  R2515     5.3386755287647247e-02
    z[8,9,2]  R2516     -2.5896275043487549e-01
    z[8,9,2]  R2517     -2.8887179493904114e-01
    z[8,9,2]  R2518     3.2635146379470825e-01
    z[8,9,2]  R2519     -5.0705488771200180e-02
    z[8,9,2]  R2520     2.8788352012634277e-01
    z[8,9,2]  R2521     -2.5966507196426392e-01
    z[8,9,2]  R2522     -1.2561090290546417e-02
    z[8,9,2]  R2523     3.4817758202552795e-01
    z[8,9,2]  R2524     1.0591665655374527e-01
    z[8,9,2]  R2525     -3.5850632190704346e-01
    z[8,9,2]  R2526     -4.2443636059761047e-01
    z[8,9,2]  R2527     5.0838928669691086e-02
    z[8,9,2]  R2528     1.2665954232215881e-01
    z[8,9,2]  R2529     1.7349500954151154e-01
    z[8,9,2]  R2530     3.4177505970001221e-01
    z[8,9,2]  R2531     -2.2517672181129456e-01
    z[8,9,2]  R2532     -3.2769733667373657e-01
    z[8,9,2]  R2533     7.5107440352439880e-02
    z[8,9,2]  R2534     -1.1293012648820877e-01
    z[8,9,2]  R2535     2.7016565203666687e-01
    z[8,9,2]  R2536     0.284115195274353
    z[8,9,2]  R2537     -2.3836031556129456e-01
    z[8,9,2]  R2538     -3.4947404265403748e-01
    z[8,9,2]  R2539     -1.2920296192169189e-01
    z[8,9,2]  R2540     -4.3436264991760254e-01
    z[8,9,2]  R2541     -2.1037213504314423e-01
    z[8,9,2]  R2542     4.2275067418813705e-02
    z[8,9,2]  R2543     -3.4015023708343506e-01
    z[8,9,2]  R2544     2.7779853343963623e-01
    z[8,9,2]  R2545     5.8591767447069287e-04
    z[8,9,2]  R2546     -2.4033807218074799e-01
    z[8,9,2]  R2547     -1.5402874350547791e-01
    z[8,9,2]  R2548     -7.2709627449512482e-02
    z[8,9,2]  R2549     -4.8643833398818970e-01
    z[8,9,2]  R2550     -4.1759368777275085e-01
    z[8,9,2]  R2551     -2.0346195995807648e-01
    z[8,9,2]  R2552     -1.0566321760416031e-01
    z[8,9,2]  R2553     -1.2967251241207123e-01
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2386     -1
    z[8,9,3]  R2387     1
    z[8,9,3]  R2394     2.5020893663167953e-02
    z[8,9,3]  R2395     -2.0159909501671791e-02
    z[8,9,3]  R2396     -2.4972374737262726e-01
    z[8,9,3]  R2397     2.0682762563228607e-01
    z[8,9,3]  R2398     8.6605958640575409e-02
    z[8,9,3]  R2399     8.7584728002548218e-01
    z[8,9,3]  R2400     0.886455774307251
    z[8,9,3]  R2401     7.7952551841735840e-01
    z[8,9,3]  R2402     6.8842327594757080e-01
    z[8,9,3]  R2403     7.6254725456237793e-01
    z[8,9,3]  R2404     -2.1076574921607971e-01
    z[8,9,3]  R2405     1.7412135004997253e-01
    z[8,9,3]  R2406     2.5826262310147285e-02
    z[8,9,3]  R2407     1.6320027410984039e-01
    z[8,9,3]  R2408     2.8141847252845764e-01
    z[8,9,3]  R2409     3.7003250326961279e-03
    z[8,9,3]  R2410     -0.00538968201726675
    z[8,9,3]  R2411     2.6330480352044106e-02
    z[8,9,3]  R2412     -1.0333186388015747e-01
    z[8,9,3]  R2413     1.6312251985073090e-01
    z[8,9,3]  R2414     6.8231053650379181e-02
    z[8,9,3]  R2415     0.591113269329071
    z[8,9,3]  R2416     -1.8255592882633209e-01
    z[8,9,3]  R2417     0.0961490273475647
    z[8,9,3]  R2418     -1.9007220864295959e-01
    z[8,9,3]  R2419     2.4882838129997253e-01
    z[8,9,3]  R2420     2.1823190152645111e-01
    z[8,9,3]  R2421     -1.9260866940021515e-01
    z[8,9,3]  R2422     -0.00952579453587532
    z[8,9,3]  R2423     -2.9420253634452820e-01
    z[8,9,3]  R2424     1.9434593617916107e-01
    z[8,9,3]  R2425     -3.4812459349632263e-01
    z[8,9,3]  R2426     2.1785824000835419e-01
    z[8,9,3]  R2427     -6.4719247817993164e-01
    z[8,9,3]  R2428     -7.3756092786788940e-01
    z[8,9,3]  R2429     -8.5562056303024292e-01
    z[8,9,3]  R2430     -0.709907591342926
    z[8,9,3]  R2431     2.2079738974571228e-01
    z[8,9,3]  R2432     3.9861035346984863e-01
    z[8,9,3]  R2433     -8.2400523126125336e-02
    z[8,9,3]  R2434     4.2890876531600952e-01
    z[8,9,3]  R2435     -1.1907821148633957e-01
    z[8,9,3]  R2436     -3.1710562109947205e-01
    z[8,9,3]  R2437     4.3346762657165527e-01
    z[8,9,3]  R2438     5.7884871959686279e-01
    z[8,9,3]  R2439     -8.2855713367462158e-01
    z[8,9,3]  R2440     2.7887905016541481e-02
    z[8,9,3]  R2441     3.4898456931114197e-01
    z[8,9,3]  R2442     3.9520654082298279e-01
    z[8,9,3]  R2443     1.0373300313949585e-01
    z[8,9,3]  R2444     2.6181671023368835e-01
    z[8,9,3]  R2445     3.0752778053283691e-02
    z[8,9,3]  R2446     -1.0336022078990936e-01
    z[8,9,3]  R2447     -1.0176008194684982e-01
    z[8,9,3]  R2448     -1.9595865160226822e-02
    z[8,9,3]  R2449     5.7871639728546143e-01
    z[8,9,3]  R2450     4.3673789501190186e-01
    z[8,9,3]  R2451     2.7254721149802208e-02
    z[8,9,3]  R2452     -5.4215413331985474e-01
    z[8,9,3]  R2453     3.5157926380634308e-02
    z[8,9,3]  R2454     8.2601845264434814e-01
    z[8,9,3]  R2455     4.0940120816230774e-01
    z[8,9,3]  R2456     -4.6199521422386169e-01
    z[8,9,3]  R2457     3.7539044022560120e-01
    z[8,9,3]  R2458     9.1040439903736115e-02
    z[8,9,3]  R2459     4.2059344053268433e-01
    z[8,9,3]  R2460     -4.6221151947975159e-01
    z[8,9,3]  R2461     7.8479431569576263e-02
    z[8,9,3]  R2462     -0.835407018661499
    z[8,9,3]  R2463     4.3667939305305481e-01
    z[8,9,3]  R2464     8.7394517660140991e-01
    z[8,9,3]  R2465     3.2051730155944824e-01
    z[8,9,3]  R2466     4.9250802397727966e-01
    z[8,9,3]  R2467     -7.9185032844543457e-01
    z[8,9,3]  R2468     1.9741542637348175e-01
    z[8,9,3]  R2469     4.6691466122865677e-03
    z[8,9,3]  R2470     -4.7329258918762207e-01
    z[8,9,3]  R2471     -4.7493028640747070e-01
    z[8,9,3]  R2472     -3.6188460886478424e-02
    z[8,9,3]  R2473     -2.6878905296325684e-01
    z[8,9,3]  R2474     -6.1702221632003784e-01
    z[8,9,3]  R2475     -7.4480628967285156e-01
    z[8,9,3]  R2476     0.576059877872467
    z[8,9,3]  R2477     -4.5782437920570374e-01
    z[8,9,3]  R2478     5.5540060997009277e-01
    z[8,9,3]  R2479     -3.3231852576136589e-03
    z[8,9,3]  R2480     1.4756141602993011e-01
    z[8,9,3]  R2481     -2.0093291997909546e-01
    z[8,9,3]  R2482     -1.4315296709537506e-01
    z[8,9,3]  R2483     2.6009619235992432e-01
    z[8,9,3]  R2484     2.6745793223381042e-01
    z[8,9,3]  R2485     2.1631832420825958e-01
    z[8,9,3]  R2486     4.9046754837036133e-01
    z[8,9,3]  R2487     8.1015920639038086e-01
    z[8,9,3]  R2488     8.7596577405929565e-01
    z[8,9,3]  R2489     6.1187815666198730e-01
    z[8,9,3]  R2490     6.0210049152374268e-01
    z[8,9,3]  R2491     5.6074738502502441e-01
    z[8,9,3]  R2492     4.2829075455665588e-01
    z[8,9,3]  R2493     8.7676249444484711e-02
    z[8,9,3]  R2494     3.2030718284659088e-04
    z[8,9,3]  R2495     -1.5726526081562042e-01
    z[8,9,3]  R2496     0.510026752948761
    z[8,9,3]  R2497     2.9189857840538025e-01
    z[8,9,3]  R2498     5.0670951604843140e-01
    z[8,9,3]  R2499     2.1482449956238270e-03
    z[8,9,3]  R2500     0.194418266415596
    z[8,9,3]  R2501     5.4579585790634155e-01
    z[8,9,3]  R2502     1.1006633937358856e-01
    z[8,9,3]  R2503     0.210173562169075
    z[8,9,3]  R2504     -1.1477672308683395e-01
    z[8,9,3]  R2505     1.6191175580024719e-01
    z[8,9,3]  R2506     7.8962184488773346e-02
    z[8,9,3]  R2507     7.9013293981552124e-01
    z[8,9,3]  R2508     5.6404348462820053e-02
    z[8,9,3]  R2509     -4.3802550435066223e-01
    z[8,9,3]  R2510     -4.9159732460975647e-01
    z[8,9,3]  R2511     3.3527228236198425e-01
    z[8,9,3]  R2512     0.500817060470581
    z[8,9,3]  R2513     -4.3633630871772766e-01
    z[8,9,3]  R2514     9.9438525736331940e-02
    z[8,9,3]  R2515     1.9843837618827820e-01
    z[8,9,3]  R2516     5.3493392467498779e-01
    z[8,9,3]  R2517     -1.0884377360343933e-01
    z[8,9,3]  R2518     4.5015761256217957e-01
    z[8,9,3]  R2519     1.1064665019512177e-01
    z[8,9,3]  R2520     5.5983585119247437e-01
    z[8,9,3]  R2521     6.4900976419448853e-01
    z[8,9,3]  R2522     -0.381475031375885
    z[8,9,3]  R2523     4.9845075607299805e-01
    z[8,9,3]  R2524     1.0783334076404572e-01
    z[8,9,3]  R2525     7.5359144248068333e-03
    z[8,9,3]  R2526     -1.3345412909984589e-01
    z[8,9,3]  R2527     8.1412959098815918e-01
    z[8,9,3]  R2528     4.1875693202018738e-01
    z[8,9,3]  R2529     7.2381514310836792e-01
    z[8,9,3]  R2530     0.524556577205658
    z[8,9,3]  R2531     -4.8285833001136780e-01
    z[8,9,3]  R2532     -6.8804478645324707e-01
    z[8,9,3]  R2533     -6.6409087181091309e-01
    z[8,9,3]  R2534     6.1818454414606094e-02
    z[8,9,3]  R2535     3.6368572711944580e-01
    z[8,9,3]  R2536     7.0382076501846313e-01
    z[8,9,3]  R2537     1.5992195904254913e-01
    z[8,9,3]  R2538     -6.0701805353164673e-01
    z[8,9,3]  R2539     -5.1418608427047729e-01
    z[8,9,3]  R2540     -0.731490433216095
    z[8,9,3]  R2541     5.5768400430679321e-01
    z[8,9,3]  R2542     2.6345852017402649e-01
    z[8,9,3]  R2543     -9.4710178673267365e-02
    z[8,9,3]  R2544     7.2435122728347778e-01
    z[8,9,3]  R2545     3.2289031893014908e-02
    z[8,9,3]  R2546     -3.7586545944213867e-01
    z[8,9,3]  R2547     5.9365427494049072e-01
    z[8,9,3]  R2548     -0.61862713098526
    z[8,9,3]  R2549     1.6522195935249329e-01
    z[8,9,3]  R2550     2.1658472716808319e-01
    z[8,9,3]  R2551     1.1529392749071121e-01
    z[8,9,3]  R2552     2.3029154539108276e-01
    z[8,9,3]  R2553     -3.3830992877483368e-02
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2388     -1
    z[8,9,4]  R2389     1
    z[8,9,4]  R2394     -6.0702785849571228e-02
    z[8,9,4]  R2395     -1.6370341181755066e-01
    z[8,9,4]  R2396     -2.1409824490547180e-01
    z[8,9,4]  R2397     -1.0911155492067337e-02
    z[8,9,4]  R2398     -1.8714027106761932e-01
    z[8,9,4]  R2399     -2.6003894209861755e-01
    z[8,9,4]  R2400     4.6505674719810486e-02
    z[8,9,4]  R2401     -5.3447896242141724e-01
    z[8,9,4]  R2402     -0.631626546382904
    z[8,9,4]  R2403     -6.0656398534774780e-01
    z[8,9,4]  R2404     3.8101791869848967e-03
    z[8,9,4]  R2405     -1.3773700594902039e-01
    z[8,9,4]  R2406     -2.6488479971885681e-01
    z[8,9,4]  R2407     5.4444384574890137e-01
    z[8,9,4]  R2408     2.2349333763122559e-01
    z[8,9,4]  R2409     5.1280868053436279e-01
    z[8,9,4]  R2410     -4.9400264024734497e-01
    z[8,9,4]  R2411     2.6858943700790405e-01
    z[8,9,4]  R2412     -0.381608247756958
    z[8,9,4]  R2413     0.672268271446228
    z[8,9,4]  R2414     -4.3929553031921387e-01
    z[8,9,4]  R2415     6.3479013741016388e-02
    z[8,9,4]  R2416     -3.5290178656578064e-01
    z[8,9,4]  R2417     -2.2511450946331024e-01
    z[8,9,4]  R2418     2.7396363019943237e-01
    z[8,9,4]  R2419     -0.324464350938797
    z[8,9,4]  R2420     -4.2967510223388672e-01
    z[8,9,4]  R2421     2.7419865131378174e-01
    z[8,9,4]  R2422     3.5170897841453552e-01
    z[8,9,4]  R2423     -2.0574498921632767e-03
    z[8,9,4]  R2424     5.4170109331607819e-02
    z[8,9,4]  R2425     -5.3116941452026367e-01
    z[8,9,4]  R2426     -4.3936005234718323e-01
    z[8,9,4]  R2427     2.3174965381622314e-01
    z[8,9,4]  R2428     1.9797667860984802e-01
    z[8,9,4]  R2429     2.7299249172210693e-01
    z[8,9,4]  R2430     3.4672826528549194e-01
    z[8,9,4]  R2431     0.256306916475296
    z[8,9,4]  R2432     1.2066429853439331e-01
    z[8,9,4]  R2433     4.5660361647605896e-02
    z[8,9,4]  R2434     -6.1327022314071655e-01
    z[8,9,4]  R2435     5.9897321462631226e-01
    z[8,9,4]  R2436     4.8401924967765808e-01
    z[8,9,4]  R2437     8.9172385632991791e-02
    z[8,9,4]  R2438     1.9298788160085678e-02
    z[8,9,4]  R2439     9.8577544093132019e-02
    z[8,9,4]  R2440     -1.0599945485591888e-01
    z[8,9,4]  R2441     3.6982879042625427e-01
    z[8,9,4]  R2442     1.7723430693149567e-01
    z[8,9,4]  R2443     -4.5534770935773849e-02
    z[8,9,4]  R2444     -5.9796366840600967e-02
    z[8,9,4]  R2445     -1.6417492926120758e-01
    z[8,9,4]  R2446     -9.0975128114223480e-02
    z[8,9,4]  R2447     5.3408050537109375e-01
    z[8,9,4]  R2448     0.520047664642334
    z[8,9,4]  R2449     -5.3054285049438477e-01
    z[8,9,4]  R2450     -2.5470888614654541e-01
    z[8,9,4]  R2451     4.0219381451606750e-01
    z[8,9,4]  R2452     -3.1121345236897469e-02
    z[8,9,4]  R2453     3.2903265953063965e-01
    z[8,9,4]  R2454     -5.1761273294687271e-02
    z[8,9,4]  R2455     -3.8550980389118195e-02
    z[8,9,4]  R2456     -4.5182496309280396e-02
    z[8,9,4]  R2457     -3.6956712603569031e-01
    z[8,9,4]  R2458     -1.3292072713375092e-01
    z[8,9,4]  R2459     -1.8835441768169403e-01
    z[8,9,4]  R2460     5.5422937870025635e-01
    z[8,9,4]  R2461     -1.3107995688915253e-01
    z[8,9,4]  R2462     2.4477869272232056e-01
    z[8,9,4]  R2463     4.5653986930847168e-01
    z[8,9,4]  R2464     -1.4539791643619537e-01
    z[8,9,4]  R2465     -2.5600489974021912e-01
    z[8,9,4]  R2466     -2.0681457221508026e-01
    z[8,9,4]  R2467     4.1539192199707031e-01
    z[8,9,4]  R2468     -4.3201935291290283e-01
    z[8,9,4]  R2469     2.6885172724723816e-01
    z[8,9,4]  R2470     5.6846636533737183e-01
    z[8,9,4]  R2471     6.3694953918457031e-01
    z[8,9,4]  R2472     5.3225511312484741e-01
    z[8,9,4]  R2473     2.6034596562385559e-01
    z[8,9,4]  R2474     4.3744844198226929e-01
    z[8,9,4]  R2475     1.2768211960792542e-01
    z[8,9,4]  R2476     4.9454993009567261e-01
    z[8,9,4]  R2477     5.9390527009963989e-01
    z[8,9,4]  R2478     4.8084896802902222e-01
    z[8,9,4]  R2479     1.5543513000011444e-01
    z[8,9,4]  R2480     -1.1964630335569382e-02
    z[8,9,4]  R2481     2.3769660294055939e-01
    z[8,9,4]  R2482     -6.2905423343181610e-02
    z[8,9,4]  R2483     2.1035051345825195e-01
    z[8,9,4]  R2484     -2.2025765478610992e-01
    z[8,9,4]  R2485     4.9540884792804718e-02
    z[8,9,4]  R2486     -1.9937008619308472e-01
    z[8,9,4]  R2487     1.5698830783367157e-01
    z[8,9,4]  R2488     -1.9919518381357193e-02
    z[8,9,4]  R2489     -5.7643294334411621e-01
    z[8,9,4]  R2490     -4.1490471363067627e-01
    z[8,9,4]  R2491     -6.8947827816009521e-01
    z[8,9,4]  R2492     8.0657035112380981e-02
    z[8,9,4]  R2493     -2.3938387632369995e-01
    z[8,9,4]  R2494     -2.5749403238296509e-01
    z[8,9,4]  R2495     -1.5698436647653580e-02
    z[8,9,4]  R2496     6.4038641750812531e-02
    z[8,9,4]  R2497     -6.4481054432690144e-03
    z[8,9,4]  R2498     1.4860455691814423e-01
    z[8,9,4]  R2499     2.1630044281482697e-01
    z[8,9,4]  R2500     -1.8657873570919037e-01
    z[8,9,4]  R2501     2.4084559082984924e-01
    z[8,9,4]  R2502     2.0764137804508209e-01
    z[8,9,4]  R2503     2.4053536355495453e-01
    z[8,9,4]  R2504     1.1786674708127975e-01
    z[8,9,4]  R2505     4.6568755060434341e-03
    z[8,9,4]  R2506     2.0146493613719940e-01
    z[8,9,4]  R2507     -4.7542190551757812e-01
    z[8,9,4]  R2508     1.6603556275367737e-01
    z[8,9,4]  R2509     0.263406902551651
    z[8,9,4]  R2510     2.3883616924285889e-01
    z[8,9,4]  R2511     -6.7056399583816528e-01
    z[8,9,4]  R2512     -2.4792028963565826e-01
    z[8,9,4]  R2513     4.6367591619491577e-01
    z[8,9,4]  R2514     2.2562585771083832e-01
    z[8,9,4]  R2515     4.4862195849418640e-01
    z[8,9,4]  R2516     -3.6542826890945435e-01
    z[8,9,4]  R2517     -3.4813615679740906e-01
    z[8,9,4]  R2518     1.0701561719179153e-01
    z[8,9,4]  R2519     -2.8643617033958435e-01
    z[8,9,4]  R2520     -6.4117950201034546e-01
    z[8,9,4]  R2521     -4.3757069110870361e-01
    z[8,9,4]  R2522     3.1786888837814331e-01
    z[8,9,4]  R2523     -3.4919813275337219e-01
    z[8,9,4]  R2524     5.7811133563518524e-02
    z[8,9,4]  R2525     2.5662171840667725e-01
    z[8,9,4]  R2526     -2.6620498299598694e-01
    z[8,9,4]  R2527     -5.4105542600154877e-02
    z[8,9,4]  R2528     -2.5736445188522339e-01
    z[8,9,4]  R2529     -4.0130594372749329e-01
    z[8,9,4]  R2530     -4.9146994948387146e-01
    z[8,9,4]  R2531     4.8633995652198792e-01
    z[8,9,4]  R2532     3.8258891552686691e-02
    z[8,9,4]  R2533     -4.3908131122589111e-01
    z[8,9,4]  R2534     3.5036456584930420e-01
    z[8,9,4]  R2535     3.3553251996636391e-03
    z[8,9,4]  R2536     -5.3329789638519287e-01
    z[8,9,4]  R2537     2.5605052709579468e-01
    z[8,9,4]  R2538     3.9515992999076843e-01
    z[8,9,4]  R2539     2.5869178771972656e-01
    z[8,9,4]  R2540     9.3507938086986542e-02
    z[8,9,4]  R2541     -0.154225692152977
    z[8,9,4]  R2542     -4.0393674373626709e-01
    z[8,9,4]  R2543     -6.1272329092025757e-01
    z[8,9,4]  R2544     2.5348857045173645e-01
    z[8,9,4]  R2545     -2.1339474618434906e-01
    z[8,9,4]  R2546     3.6196881532669067e-01
    z[8,9,4]  R2547     -2.2272971272468567e-01
    z[8,9,4]  R2548     5.5822777748107910e-01
    z[8,9,4]  R2549     -4.1396361589431763e-01
    z[8,9,4]  R2550     -1.0913689434528351e-01
    z[8,9,4]  R2551     -2.0239000022411346e-01
    z[8,9,4]  R2552     -5.0234001874923706e-01
    z[8,9,4]  R2553     1.0885780304670334e-01
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2390     -1
    z[8,9,5]  R2391     1
    z[8,9,5]  R2394     -1.3654959201812744e-01
    z[8,9,5]  R2395     -9.2440247535705566e-02
    z[8,9,5]  R2396     1.0115293785929680e-02
    z[8,9,5]  R2397     1.0998719371855259e-02
    z[8,9,5]  R2398     1.2060520052909851e-01
    z[8,9,5]  R2399     -9.4037890434265137e-02
    z[8,9,5]  R2400     -3.7226337194442749e-01
    z[8,9,5]  R2401     -1.7053464055061340e-01
    z[8,9,5]  R2402     -3.1147161126136780e-01
    z[8,9,5]  R2403     -2.4714589118957520e-02
    z[8,9,5]  R2404     -3.2154834270477295e-01
    z[8,9,5]  R2405     2.6955306529998779e-01
    z[8,9,5]  R2406     -5.3265053033828735e-01
    z[8,9,5]  R2407     1.7484933137893677e-01
    z[8,9,5]  R2408     1.6320532560348511e-01
    z[8,9,5]  R2409     -2.1414074301719666e-01
    z[8,9,5]  R2410     7.7239155769348145e-01
    z[8,9,5]  R2411     1.3511365652084351e-01
    z[8,9,5]  R2412     6.2932890653610229e-01
    z[8,9,5]  R2413     -2.1945912390947342e-02
    z[8,9,5]  R2414     3.3637553453445435e-01
    z[8,9,5]  R2415     6.4657934010028839e-02
    z[8,9,5]  R2416     3.4015449881553650e-01
    z[8,9,5]  R2417     -1.7019546031951904e-01
    z[8,9,5]  R2418     5.1290357112884521e-01
    z[8,9,5]  R2419     -2.0324380695819855e-01
    z[8,9,5]  R2420     -1.7839151620864868e-01
    z[8,9,5]  R2421     5.2952367067337036e-01
    z[8,9,5]  R2422     1.2697046995162964e-01
    z[8,9,5]  R2423     -2.0534142851829529e-01
    z[8,9,5]  R2424     3.8339513540267944e-01
    z[8,9,5]  R2425     -6.2285237014293671e-02
    z[8,9,5]  R2426     4.9384722113609314e-01
    z[8,9,5]  R2427     7.0507985353469849e-01
    z[8,9,5]  R2428     4.7425702214241028e-01
    z[8,9,5]  R2429     2.9225319623947144e-01
    z[8,9,5]  R2430     4.9426114559173584e-01
    z[8,9,5]  R2431     3.1892961263656616e-01
    z[8,9,5]  R2432     4.8496076464653015e-01
    z[8,9,5]  R2433     4.0534928441047668e-01
    z[8,9,5]  R2434     1.6330938786268234e-02
    z[8,9,5]  R2435     1.9894470274448395e-01
    z[8,9,5]  R2436     -1.7619448900222778e-01
    z[8,9,5]  R2437     -5.9015041589736938e-01
    z[8,9,5]  R2438     3.0861091613769531e-01
    z[8,9,5]  R2439     5.2670252323150635e-01
    z[8,9,5]  R2440     0.238073468208313
    z[8,9,5]  R2441     7.0517018437385559e-02
    z[8,9,5]  R2442     -4.1556927561759949e-01
    z[8,9,5]  R2443     1.5158849954605103e-01
    z[8,9,5]  R2444     -1.3737757503986359e-01
    z[8,9,5]  R2445     5.3427174687385559e-02
    z[8,9,5]  R2446     2.3475063499063253e-03
    z[8,9,5]  R2447     -2.4367213249206543e-01
    z[8,9,5]  R2448     -3.1883720308542252e-02
    z[8,9,5]  R2449     -0.221435084939003
    z[8,9,5]  R2450     -2.3268258571624756e-01
    z[8,9,5]  R2451     -4.3591648340225220e-01
    z[8,9,5]  R2452     9.1966040432453156e-02
    z[8,9,5]  R2453     8.3843415975570679e-01
    z[8,9,5]  R2454     -3.9317813515663147e-01
    z[8,9,5]  R2455     -4.1142249107360840e-01
    z[8,9,5]  R2456     1.2930651009082794e-01
    z[8,9,5]  R2457     5.8101141452789307e-01
    z[8,9,5]  R2458     4.9192342907190323e-02
    z[8,9,5]  R2459     3.4624036401510239e-02
    z[8,9,5]  R2460     5.9644037485122681e-01
    z[8,9,5]  R2461     4.2838081717491150e-01
    z[8,9,5]  R2462     3.7177410721778870e-01
    z[8,9,5]  R2463     -2.0003531873226166e-01
    z[8,9,5]  R2464     -4.4080230593681335e-01
    z[8,9,5]  R2465     0.372408926486969
    z[8,9,5]  R2466     6.6106610000133514e-02
    z[8,9,5]  R2467     2.1512353420257568e-01
    z[8,9,5]  R2468     -6.4128667116165161e-01
    z[8,9,5]  R2469     5.8276677131652832e-01
    z[8,9,5]  R2470     2.9139328002929688e-01
    z[8,9,5]  R2471     2.3616470396518707e-01
    z[8,9,5]  R2472     3.9361339807510376e-01
    z[8,9,5]  R2473     0.679141640663147
    z[8,9,5]  R2474     6.2278968095779419e-01
    z[8,9,5]  R2475     6.0777628421783447e-01
    z[8,9,5]  R2476     -1.0870582610368729e-01
    z[8,9,5]  R2477     3.1675449013710022e-01
    z[8,9,5]  R2478     4.4717827439308167e-01
    z[8,9,5]  R2479     2.5152226909995079e-02
    z[8,9,5]  R2480     -2.3318465054035187e-01
    z[8,9,5]  R2481     -1.5005064010620117e-01
    z[8,9,5]  R2482     1.3023109734058380e-01
    z[8,9,5]  R2483     -0.0937047228217125
    z[8,9,5]  R2484     -1.9467087090015411e-01
    z[8,9,5]  R2485     2.6567959785461426e-01
    z[8,9,5]  R2486     2.2427400574088097e-02
    z[8,9,5]  R2487     -5.4391944408416748e-01
    z[8,9,5]  R2488     -3.5637673735618591e-01
    z[8,9,5]  R2489     -4.8700369894504547e-02
    z[8,9,5]  R2490     -7.5534239411354065e-02
    z[8,9,5]  R2491     -3.2818788290023804e-01
    z[8,9,5]  R2492     -4.0075135231018066e-01
    z[8,9,5]  R2493     4.8053160309791565e-01
    z[8,9,5]  R2494     -1.5864242613315582e-01
    z[8,9,5]  R2495     -1.8162797391414642e-01
    z[8,9,5]  R2496     1.1702164262533188e-01
    z[8,9,5]  R2497     1.4710952341556549e-01
    z[8,9,5]  R2498     8.5905738174915314e-02
    z[8,9,5]  R2499     1.8779808282852173e-01
    z[8,9,5]  R2500     -1.3045580685138702e-01
    z[8,9,5]  R2501     1.2709461152553558e-01
    z[8,9,5]  R2502     -4.6299362182617188e-01
    z[8,9,5]  R2503     5.8834099769592285e-01
    z[8,9,5]  R2504     5.4942883551120758e-02
    z[8,9,5]  R2505     3.9418280124664307e-01
    z[8,9,5]  R2506     -0.301368772983551
    z[8,9,5]  R2507     -2.5309933349490166e-02
    z[8,9,5]  R2508     4.2968633770942688e-01
    z[8,9,5]  R2509     7.5681346654891968e-01
    z[8,9,5]  R2510     6.8053728342056274e-01
    z[8,9,5]  R2511     -5.4070943593978882e-01
    z[8,9,5]  R2512     -5.3338271379470825e-01
    z[8,9,5]  R2513     5.2292549610137939e-01
    z[8,9,5]  R2514     2.7252739667892456e-01
    z[8,9,5]  R2515     -4.6664139628410339e-01
    z[8,9,5]  R2516     -0.513565719127655
    z[8,9,5]  R2517     5.2712988853454590e-01
    z[8,9,5]  R2518     -4.5385599136352539e-01
    z[8,9,5]  R2519     5.8251172304153442e-01
    z[8,9,5]  R2520     -2.1387417614459991e-01
    z[8,9,5]  R2521     -1.5060220845043659e-02
    z[8,9,5]  R2522     6.8639487028121948e-01
    z[8,9,5]  R2523     -2.4893115460872650e-01
    z[8,9,5]  R2524     3.8159903883934021e-01
    z[8,9,5]  R2525     1.7658115923404694e-01
    z[8,9,5]  R2526     0.375962495803833
    z[8,9,5]  R2527     -2.2506140172481537e-01
    z[8,9,5]  R2528     -7.0776619017124176e-02
    z[8,9,5]  R2529     -4.2152115702629089e-01
    z[8,9,5]  R2530     -6.0033202171325684e-01
    z[8,9,5]  R2531     5.8392065763473511e-01
    z[8,9,5]  R2532     4.4555336236953735e-01
    z[8,9,5]  R2533     0.540216326713562
    z[8,9,5]  R2534     5.9696469455957413e-02
    z[8,9,5]  R2535     -2.3778945207595825e-01
    z[8,9,5]  R2536     -2.4003544449806213e-01
    z[8,9,5]  R2537     -4.2458108067512512e-01
    z[8,9,5]  R2538     5.4056447744369507e-01
    z[8,9,5]  R2539     7.1215301752090454e-01
    z[8,9,5]  R2540     4.3745765089988708e-01
    z[8,9,5]  R2541     -3.7895795702934265e-01
    z[8,9,5]  R2542     -8.3969587087631226e-01
    z[8,9,5]  R2543     6.5132617950439453e-01
    z[8,9,5]  R2544     -4.1937139630317688e-01
    z[8,9,5]  R2545     -1.4807693660259247e-01
    z[8,9,5]  R2546     0.404939204454422
    z[8,9,5]  R2547     -6.5721738338470459e-01
    z[8,9,5]  R2548     4.8852661252021790e-01
    z[8,9,5]  R2549     3.3111223578453064e-01
    z[8,9,5]  R2550     0.810812771320343
    z[8,9,5]  R2551     0.654262900352478
    z[8,9,5]  R2552     5.9761160612106323e-01
    z[8,9,5]  R2553     -2.4756550788879395e-02
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2392     -1
    z[8,9,6]  R2393     1
    z[8,9,6]  R2394     -1.7260447144508362e-02
    z[8,9,6]  R2395     -2.0662035793066025e-02
    z[8,9,6]  R2396     2.9811248183250427e-01
    z[8,9,6]  R2397     -2.7274868916720152e-03
    z[8,9,6]  R2398     -4.4423291087150574e-01
    z[8,9,6]  R2399     8.1322342157363892e-02
    z[8,9,6]  R2400     -2.0091181993484497e-01
    z[8,9,6]  R2401     3.0219249427318573e-02
    z[8,9,6]  R2402     1.4600034058094025e-01
    z[8,9,6]  R2403     -6.8772301077842712e-02
    z[8,9,6]  R2404     2.6324397325515747e-01
    z[8,9,6]  R2405     -2.4828876554965973e-01
    z[8,9,6]  R2406     1.3578110933303833e-01
    z[8,9,6]  R2407     -4.7924673557281494e-01
    z[8,9,6]  R2408     -0.513411283493042
    z[8,9,6]  R2409     -3.8489320874214172e-01
    z[8,9,6]  R2410     -0.0986989438533783
    z[8,9,6]  R2411     3.8036710023880005e-01
    z[8,9,6]  R2412     -3.4328781068325043e-02
    z[8,9,6]  R2413     -1.0835714638233185e-01
    z[8,9,6]  R2414     2.0683281123638153e-01
    z[8,9,6]  R2415     3.1815614551305771e-02
    z[8,9,6]  R2416     1.8912982940673828e-01
    z[8,9,6]  R2417     -3.9436578750610352e-01
    z[8,9,6]  R2418     -7.2801060974597931e-02
    z[8,9,6]  R2419     -1.9014558196067810e-01
    z[8,9,6]  R2420     2.1530769765377045e-01
    z[8,9,6]  R2421     8.7286166846752167e-02
    z[8,9,6]  R2422     -2.7257224917411804e-01
    z[8,9,6]  R2423     2.3130492866039276e-01
    z[8,9,6]  R2424     1.0132461041212082e-01
    z[8,9,6]  R2425     1.9825181365013123e-01
    z[8,9,6]  R2426     3.6885300278663635e-01
    z[8,9,6]  R2427     -0.0913926288485527
    z[8,9,6]  R2428     2.9600170254707336e-01
    z[8,9,6]  R2429     2.7688222005963326e-02
    z[8,9,6]  R2430     -4.8201397061347961e-02
    z[8,9,6]  R2431     1.9878593087196350e-01
    z[8,9,6]  R2432     2.0137897133827209e-01
    z[8,9,6]  R2433     1.9239969551563263e-01
    z[8,9,6]  R2434     -1.3886536657810211e-01
    z[8,9,6]  R2435     7.5013726949691772e-02
    z[8,9,6]  R2436     -2.0114743709564209e-01
    z[8,9,6]  R2437     3.1841254234313965e-01
    z[8,9,6]  R2438     -1.0493180155754089e-01
    z[8,9,6]  R2439     1.1313805729150772e-01
    z[8,9,6]  R2440     4.9736884236335754e-01
    z[8,9,6]  R2441     2.2158469259738922e-01
    z[8,9,6]  R2442     2.3445343971252441e-01
    z[8,9,6]  R2443     -5.0230240821838379e-01
    z[8,9,6]  R2444     0.261868417263031
    z[8,9,6]  R2445     -3.0893087387084961e-02
    z[8,9,6]  R2446     -5.2927918732166290e-03
    z[8,9,6]  R2447     -7.3460757732391357e-02
    z[8,9,6]  R2448     -0.201044961810112
    z[8,9,6]  R2449     -4.5461758971214294e-02
    z[8,9,6]  R2450     -1.4415824413299561e-01
    z[8,9,6]  R2451     -7.7320039272308350e-02
    z[8,9,6]  R2452     -2.7034339308738708e-01
    z[8,9,6]  R2453     0.0845186710357666
    z[8,9,6]  R2454     2.7805145364254713e-03
    z[8,9,6]  R2455     8.3542689681053162e-03
    z[8,9,6]  R2456     -2.8224778175354004e-01
    z[8,9,6]  R2457     1.4170059561729431e-01
    z[8,9,6]  R2458     4.2444637417793274e-01
    z[8,9,6]  R2459     3.5754811763763428e-01
    z[8,9,6]  R2460     5.6581471115350723e-02
    z[8,9,6]  R2461     -1.1086313426494598e-01
    z[8,9,6]  R2462     2.4395607411861420e-02
    z[8,9,6]  R2463     0.0748407393693924
    z[8,9,6]  R2464     -1.0414259135723114e-01
    z[8,9,6]  R2465     -4.4331338256597519e-02
    z[8,9,6]  R2466     3.3066761493682861e-01
    z[8,9,6]  R2467     -1.3299232721328735e-01
    z[8,9,6]  R2468     -1.5949106216430664e-01
    z[8,9,6]  R2469     -3.6813411116600037e-01
    z[8,9,6]  R2470     -3.6560556292533875e-01
    z[8,9,6]  R2471     -2.1807946264743805e-01
    z[8,9,6]  R2472     -3.5904118418693542e-01
    z[8,9,6]  R2473     5.0126284360885620e-01
    z[8,9,6]  R2474     -9.4208948314189911e-02
    z[8,9,6]  R2475     1.6494569182395935e-01
    z[8,9,6]  R2476     -1.3512144982814789e-01
    z[8,9,6]  R2477     -2.5242233276367188e-01
    z[8,9,6]  R2478     -4.4038379192352295e-01
    z[8,9,6]  R2479     1.2994153797626495e-01
    z[8,9,6]  R2480     1.3858821988105774e-01
    z[8,9,6]  R2481     1.2574154138565063e-01
    z[8,9,6]  R2482     1.4876842498779297e-02
    z[8,9,6]  R2483     -0.138673335313797
    z[8,9,6]  R2484     1.0395793616771698e-01
    z[8,9,6]  R2485     1.9415576010942459e-02
    z[8,9,6]  R2486     -6.9697767496109009e-02
    z[8,9,6]  R2487     1.1169490963220596e-01
    z[8,9,6]  R2488     -1.2352060526609421e-02
    z[8,9,6]  R2489     1.6082102060317993e-01
    z[8,9,6]  R2490     5.7173055410385132e-01
    z[8,9,6]  R2491     -1.2007039785385132e-01
    z[8,9,6]  R2492     6.4285027980804443e-01
    z[8,9,6]  R2493     6.8001949787139893e-01
    z[8,9,6]  R2494     1.8460302054882050e-01
    z[8,9,6]  R2495     -1.5779319405555725e-01
    z[8,9,6]  R2496     1.9296933710575104e-01
    z[8,9,6]  R2497     -1.5386903285980225e-01
    z[8,9,6]  R2498     1.9968789815902710e-01
    z[8,9,6]  R2499     -2.3701782524585724e-01
    z[8,9,6]  R2500     -2.6190373301506042e-01
    z[8,9,6]  R2501     -3.3819109201431274e-01
    z[8,9,6]  R2502     -1.7705438658595085e-02
    z[8,9,6]  R2503     -3.8312196731567383e-02
    z[8,9,6]  R2504     -2.1390339732170105e-01
    z[8,9,6]  R2505     4.9474292993545532e-01
    z[8,9,6]  R2506     4.9652910232543945e-01
    z[8,9,6]  R2507     1.8477691337466240e-02
    z[8,9,6]  R2508     4.2714181542396545e-01
    z[8,9,6]  R2509     1.1721289902925491e-01
    z[8,9,6]  R2510     4.5573955774307251e-01
    z[8,9,6]  R2511     -1.0785336047410965e-01
    z[8,9,6]  R2512     -3.8591352105140686e-01
    z[8,9,6]  R2513     -4.1525909304618835e-01
    z[8,9,6]  R2514     3.7685650587081909e-01
    z[8,9,6]  R2515     -7.2364950180053711e-01
    z[8,9,6]  R2516     6.8157516419887543e-02
    z[8,9,6]  R2517     -2.4559737741947174e-01
    z[8,9,6]  R2518     8.1955626606941223e-02
    z[8,9,6]  R2519     -3.5615113377571106e-01
    z[8,9,6]  R2520     1.4210730791091919e-02
    z[8,9,6]  R2521     -3.9242914319038391e-01
    z[8,9,6]  R2522     -3.7285405397415161e-01
    z[8,9,6]  R2523     0.617212176322937
    z[8,9,6]  R2524     -1.9595511257648468e-02
    z[8,9,6]  R2525     -2.1142356097698212e-01
    z[8,9,6]  R2526     -6.3874870538711548e-02
    z[8,9,6]  R2527     3.8014820218086243e-01
    z[8,9,6]  R2528     2.6594460010528564e-01
    z[8,9,6]  R2529     -2.7939301729202271e-01
    z[8,9,6]  R2530     7.2171583771705627e-02
    z[8,9,6]  R2531     -1.7181229591369629e-01
    z[8,9,6]  R2532     -3.5775211453437805e-01
    z[8,9,6]  R2533     -2.4354150891304016e-01
    z[8,9,6]  R2534     7.6739199459552765e-02
    z[8,9,6]  R2535     1.3014088571071625e-01
    z[8,9,6]  R2536     -2.3814998567104340e-01
    z[8,9,6]  R2537     1.1520184576511383e-01
    z[8,9,6]  R2538     6.7315578460693359e-02
    z[8,9,6]  R2539     -2.4576807022094727e-01
    z[8,9,6]  R2540     -0.206540048122406
    z[8,9,6]  R2541     -5.5418390035629272e-01
    z[8,9,6]  R2542     -2.1993513405323029e-01
    z[8,9,6]  R2543     2.0152269303798676e-01
    z[8,9,6]  R2544     -1.5294280648231506e-01
    z[8,9,6]  R2545     -2.2544318437576294e-01
    z[8,9,6]  R2546     -9.2782024294137955e-03
    z[8,9,6]  R2547     -3.6410698294639587e-01
    z[8,9,6]  R2548     -9.8761796951293945e-02
    z[8,9,6]  R2549     5.3759759664535522e-01
    z[8,9,6]  R2550     -9.5262423157691956e-02
    z[8,9,6]  R2551     6.5266633033752441e-01
    z[8,9,6]  R2552     4.7035521268844604e-01
    z[8,9,6]  R2553     4.8429798334836960e-02
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2554     -1
    z[9,8,0]  R2555     1
    z[9,8,0]  R2568     -1.9803822040557861e-01
    z[9,8,0]  R2569     2.5238662958145142e-01
    z[9,8,0]  R2570     -1.1824974417686462e-01
    z[9,8,0]  R2571     9.9914371967315674e-02
    z[9,8,0]  R2572     2.4679099023342133e-01
    z[9,8,0]  R2573     3.8315400481224060e-02
    z[9,8,0]  R2574     -2.7499571442604065e-01
    z[9,8,0]  R2575     -3.7888471037149429e-02
    z[9,8,0]  R2576     -4.1742104291915894e-01
    z[9,8,0]  R2577     4.5252367854118347e-01
    z[9,8,0]  R2578     -2.2583612799644470e-01
    z[9,8,0]  R2579     -6.3919335603713989e-02
    z[9,8,0]  R2580     -6.7560482025146484e-01
    z[9,8,0]  R2581     -6.5368419885635376e-01
    z[9,8,0]  R2582     -9.0757891535758972e-02
    z[9,8,0]  R2583     4.4519278407096863e-01
    z[9,8,0]  R2584     3.5323637723922729e-01
    z[9,8,0]  R2585     -5.9289741516113281e-01
    z[9,8,0]  R2586     -1.8929685652256012e-01
    z[9,8,0]  R2587     1.3136033713817596e-01
    z[9,8,0]  R2588     2.3055012524127960e-01
    z[9,8,0]  R2589     1.2396096438169479e-01
    z[9,8,0]  R2590     4.2159575223922729e-01
    z[9,8,0]  R2591     -8.1610918045043945e-02
    z[9,8,0]  R2592     -2.1789768710732460e-02
    z[9,8,0]  R2593     -1.4977262914180756e-01
    z[9,8,0]  R2594     -1.1833619326353073e-01
    z[9,8,0]  R2595     -1.9463555514812469e-01
    z[9,8,0]  R2596     1.4824509620666504e-01
    z[9,8,0]  R2597     1.2747310101985931e-02
    z[9,8,0]  R2598     -5.1304832100868225e-02
    z[9,8,0]  R2599     6.9660387933254242e-02
    z[9,8,0]  R2600     -3.2370465993881226e-01
    z[9,8,0]  R2601     -1.6792871057987213e-01
    z[9,8,0]  R2602     1.7671565711498260e-01
    z[9,8,0]  R2603     6.2303312122821808e-02
    z[9,8,0]  R2604     -8.3578817546367645e-02
    z[9,8,0]  R2605     -3.5809274762868881e-02
    z[9,8,0]  R2606     0.321304053068161
    z[9,8,0]  R2607     -2.4650232493877411e-01
    z[9,8,0]  R2608     7.9818665981292725e-02
    z[9,8,0]  R2609     -1.3058078475296497e-02
    z[9,8,0]  R2610     -8.2875989377498627e-02
    z[9,8,0]  R2611     -1.0611154884099960e-01
    z[9,8,0]  R2612     4.4820201396942139e-01
    z[9,8,0]  R2613     1.6390676796436310e-01
    z[9,8,0]  R2614     -2.9395204037427902e-02
    z[9,8,0]  R2615     1.3103142380714417e-01
    z[9,8,0]  R2616     -2.9077364131808281e-02
    z[9,8,0]  R2617     -9.6925839781761169e-02
    z[9,8,0]  R2618     -1.0229860199615359e-03
    z[9,8,0]  R2619     0.0597953163087368
    z[9,8,0]  R2620     1.5860667824745178e-01
    z[9,8,0]  R2621     4.5685794949531555e-01
    z[9,8,0]  R2622     -1.3246141374111176e-01
    z[9,8,0]  R2623     1.3124756515026093e-01
    z[9,8,0]  R2624     -1.8175707757472992e-01
    z[9,8,0]  R2625     1.6447648406028748e-01
    z[9,8,0]  R2626     -6.8660169839859009e-02
    z[9,8,0]  R2627     1.8588909506797791e-01
    z[9,8,0]  R2628     4.0934991091489792e-02
    z[9,8,0]  R2629     8.4374286234378815e-02
    z[9,8,0]  R2630     -3.5348582267761230e-01
    z[9,8,0]  R2631     6.3521102070808411e-02
    z[9,8,0]  R2632     1.7299221456050873e-01
    z[9,8,0]  R2633     4.0706256031990051e-01
    z[9,8,0]  R2634     3.1329661607742310e-01
    z[9,8,0]  R2635     -2.1327106654644012e-01
    z[9,8,0]  R2636     -3.1297969818115234e-01
    z[9,8,0]  R2637     9.2750859260559082e-01
    z[9,8,0]  R2638     -8.5061663389205933e-01
    z[9,8,0]  R2639     -6.6478002071380615e-01
    z[9,8,0]  R2640     -6.8220239877700806e-01
    z[9,8,0]  R2641     -4.2338940501213074e-01
    z[9,8,0]  R2642     -5.4683411121368408e-01
    z[9,8,0]  R2643     3.4477461129426956e-02
    z[9,8,0]  R2644     -1.3178817927837372e-01
    z[9,8,0]  R2645     -1.1144463717937469e-01
    z[9,8,0]  R2646     6.1237372457981110e-02
    z[9,8,0]  R2647     1.2883530557155609e-01
    z[9,8,0]  R2648     7.5623080134391785e-02
    z[9,8,0]  R2649     2.0187151432037354e-01
    z[9,8,0]  R2650     8.8159903883934021e-02
    z[9,8,0]  R2651     1.7221964895725250e-01
    z[9,8,0]  R2652     -3.8590118288993835e-01
    z[9,8,0]  R2653     -2.1298557519912720e-01
    z[9,8,0]  R2654     -3.4787435084581375e-02
    z[9,8,0]  R2655     0.144593745470047
    z[9,8,0]  R2656     -1.7110320925712585e-01
    z[9,8,0]  R2657     -8.2352012395858765e-02
    z[9,8,0]  R2658     -7.3613594286143780e-03
    z[9,8,0]  R2659     2.2473397850990295e-01
    z[9,8,0]  R2660     -4.5772069692611694e-01
    z[9,8,0]  R2661     3.5058337450027466e-01
    z[9,8,0]  R2662     -2.9376265406608582e-01
    z[9,8,0]  R2663     -4.7494354844093323e-01
    z[9,8,0]  R2664     -5.0987863540649414e-01
    z[9,8,0]  R2665     1.2680661678314209e-01
    z[9,8,0]  R2666     -4.7340753674507141e-01
    z[9,8,0]  R2667     -5.9228497743606567e-01
    z[9,8,0]  R2668     2.2725613415241241e-01
    z[9,8,0]  R2669     1.6647150740027428e-02
    z[9,8,0]  R2670     6.6248111426830292e-02
    z[9,8,0]  R2671     4.9591418355703354e-02
    z[9,8,0]  R2672     2.3875980079174042e-01
    z[9,8,0]  R2673     -2.0266209542751312e-01
    z[9,8,0]  R2674     1.8510530889034271e-01
    z[9,8,0]  R2675     -9.6003741025924683e-02
    z[9,8,0]  R2676     6.1135566234588623e-01
    z[9,8,0]  R2677     -3.0051884055137634e-01
    z[9,8,0]  R2678     8.3354108035564423e-02
    z[9,8,0]  R2679     -9.0884536504745483e-02
    z[9,8,0]  R2680     -3.9024937152862549e-01
    z[9,8,0]  R2681     2.0824769139289856e-01
    z[9,8,0]  R2682     0.728653073310852
    z[9,8,0]  R2683     -1.0147596150636673e-01
    z[9,8,0]  R2684     4.1850557923316956e-01
    z[9,8,0]  R2685     7.3393404483795166e-01
    z[9,8,0]  R2686     7.3931068181991577e-01
    z[9,8,0]  R2687     7.7196583151817322e-02
    z[9,8,0]  R2688     -1.5070086717605591e-01
    z[9,8,0]  R2689     -5.3566700220108032e-01
    z[9,8,0]  R2690     2.7248108386993408e-01
    z[9,8,0]  R2691     2.2686022520065308e-01
    z[9,8,0]  R2692     -1.8101686239242554e-01
    z[9,8,0]  R2693     -0.244932159781456
    z[9,8,0]  R2694     -5.3288701921701431e-02
    z[9,8,0]  R2695     -4.9755790829658508e-01
    z[9,8,0]  R2696     1.4224074780941010e-01
    z[9,8,0]  R2697     -0.27867591381073
    z[9,8,0]  R2698     -2.4550264701247215e-02
    z[9,8,0]  R2699     2.1306996047496796e-01
    z[9,8,0]  R2700     0.0872528925538063
    z[9,8,0]  R2701     -5.5026117712259293e-02
    z[9,8,0]  R2702     2.8675207495689392e-01
    z[9,8,0]  R2703     7.4092823266983032e-01
    z[9,8,0]  R2704     1.2137080729007721e-01
    z[9,8,0]  R2705     -5.8641177415847778e-01
    z[9,8,0]  R2706     9.0669281780719757e-02
    z[9,8,0]  R2707     6.9981443881988525e-01
    z[9,8,0]  R2708     -2.6681980118155479e-02
    z[9,8,0]  R2709     -2.0519353449344635e-01
    z[9,8,0]  R2710     6.7276817560195923e-01
    z[9,8,0]  R2711     -2.2326491773128510e-01
    z[9,8,0]  R2712     -4.3854388594627380e-01
    z[9,8,0]  R2713     2.2516788914799690e-02
    z[9,8,0]  R2714     -0.459357351064682
    z[9,8,0]  R2715     -0.426647424697876
    z[9,8,0]  R2716     -2.2971516475081444e-02
    z[9,8,0]  R2717     2.5697913765907288e-01
    z[9,8,0]  R2718     -5.2027054131031036e-02
    z[9,8,0]  R2719     -4.7266975045204163e-02
    z[9,8,0]  R2720     5.9770947694778442e-01
    z[9,8,0]  R2721     3.8361188769340515e-01
    z[9,8,0]  R2722     2.3431569337844849e-01
    z[9,8,0]  R2723     5.1072686910629272e-02
    z[9,8,0]  R2724     -1.3900332152843475e-01
    z[9,8,0]  R2725     -1.7442011833190918e-01
    z[9,8,0]  R2726     -2.9155322909355164e-01
    z[9,8,0]  R2727     -3.0238136649131775e-01
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2556     -1
    z[9,8,1]  R2557     1
    z[9,8,1]  R2568     -0.656193733215332
    z[9,8,1]  R2569     -6.1848628520965576e-01
    z[9,8,1]  R2570     -7.4918586015701294e-01
    z[9,8,1]  R2571     2.0149391144514084e-02
    z[9,8,1]  R2572     -2.6095548644661903e-02
    z[9,8,1]  R2573     0.0388895608484745
    z[9,8,1]  R2574     2.8341708704829216e-02
    z[9,8,1]  R2575     0.139244943857193
    z[9,8,1]  R2576     8.0143705010414124e-02
    z[9,8,1]  R2577     8.4198370575904846e-02
    z[9,8,1]  R2578     8.9956164360046387e-01
    z[9,8,1]  R2579     9.5434391498565674e-01
    z[9,8,1]  R2580     4.5133581757545471e-01
    z[9,8,1]  R2581     5.8734935522079468e-01
    z[9,8,1]  R2582     8.0117923021316528e-01
    z[9,8,1]  R2583     8.0742782354354858e-01
    z[9,8,1]  R2584     7.7990013360977173e-01
    z[9,8,1]  R2585     4.0210062265396118e-01
    z[9,8,1]  R2586     7.3686122894287109e-01
    z[9,8,1]  R2587     7.2755759954452515e-01
    z[9,8,1]  R2588     8.9741885662078857e-01
    z[9,8,1]  R2589     0.683401346206665
    z[9,8,1]  R2590     6.6133803129196167e-01
    z[9,8,1]  R2591     3.7302395701408386e-01
    z[9,8,1]  R2592     7.2715944051742554e-01
    z[9,8,1]  R2593     -7.9600110650062561e-02
    z[9,8,1]  R2594     -8.5365541279315948e-02
    z[9,8,1]  R2595     2.9185783863067627e-01
    z[9,8,1]  R2596     4.7772899270057678e-01
    z[9,8,1]  R2597     -2.7412655949592590e-01
    z[9,8,1]  R2598     0.836509644985199
    z[9,8,1]  R2599     -1.0116760432720184e-01
    z[9,8,1]  R2600     3.7425440549850464e-01
    z[9,8,1]  R2601     6.4585089683532715e-01
    z[9,8,1]  R2602     6.5990155935287476e-01
    z[9,8,1]  R2603     6.5809983015060425e-01
    z[9,8,1]  R2604     3.7371945381164551e-01
    z[9,8,1]  R2605     4.0544113516807556e-01
    z[9,8,1]  R2606     1.9971008598804474e-01
    z[9,8,1]  R2607     6.8549059331417084e-02
    z[9,8,1]  R2608     9.0633255243301392e-01
    z[9,8,1]  R2609     8.5411381721496582e-01
    z[9,8,1]  R2610     7.6084333658218384e-01
    z[9,8,1]  R2611     3.5391521453857422e-01
    z[9,8,1]  R2612     6.8245339393615723e-01
    z[9,8,1]  R2613     4.8359535634517670e-02
    z[9,8,1]  R2614     -4.0118005126714706e-03
    z[9,8,1]  R2615     3.0325686931610107e-01
    z[9,8,1]  R2616     -3.0065795779228210e-01
    z[9,8,1]  R2617     3.0287555418908596e-03
    z[9,8,1]  R2618     9.2261385917663574e-01
    z[9,8,1]  R2619     8.4715765714645386e-01
    z[9,8,1]  R2620     -4.4515966437757015e-03
    z[9,8,1]  R2621     6.7066210508346558e-01
    z[9,8,1]  R2622     1.9737848639488220e-01
    z[9,8,1]  R2623     2.5924494862556458e-01
    z[9,8,1]  R2624     2.1058626472949982e-02
    z[9,8,1]  R2625     3.7837183475494385e-01
    z[9,8,1]  R2626     8.6386218667030334e-02
    z[9,8,1]  R2627     -2.2493258118629456e-02
    z[9,8,1]  R2628     3.6461940407752991e-01
    z[9,8,1]  R2629     9.3463861942291260e-01
    z[9,8,1]  R2630     -6.1719310283660889e-01
    z[9,8,1]  R2631     7.5483016669750214e-02
    z[9,8,1]  R2632     1.4851692318916321e-01
    z[9,8,1]  R2633     1.9161993637681007e-02
    z[9,8,1]  R2634     4.6353090554475784e-02
    z[9,8,1]  R2635     -6.9504901766777039e-02
    z[9,8,1]  R2636     8.4414362907409668e-02
    z[9,8,1]  R2637     -3.2704740762710571e-01
    z[9,8,1]  R2638     -1.5238077938556671e-01
    z[9,8,1]  R2639     -4.9546480178833008e-01
    z[9,8,1]  R2640     -1.3301602005958557e-01
    z[9,8,1]  R2641     -3.3557718992233276e-01
    z[9,8,1]  R2642     -1.6564594209194183e-01
    z[9,8,1]  R2643     -9.8058469593524933e-02
    z[9,8,1]  R2644     1.6699803993105888e-02
    z[9,8,1]  R2645     -2.0967480540275574e-01
    z[9,8,1]  R2646     -3.4673564136028290e-02
    z[9,8,1]  R2647     4.7680456191301346e-02
    z[9,8,1]  R2648     8.7954843044281006e-01
    z[9,8,1]  R2649     7.4665105342864990e-01
    z[9,8,1]  R2650     7.5145530700683594e-01
    z[9,8,1]  R2651     0.565773069858551
    z[9,8,1]  R2652     5.5502235889434814e-01
    z[9,8,1]  R2653     6.4108473062515259e-01
    z[9,8,1]  R2654     -8.4837704896926880e-02
    z[9,8,1]  R2655     5.5654048919677734e-01
    z[9,8,1]  R2656     -5.7708561420440674e-01
    z[9,8,1]  R2657     6.4547479152679443e-01
    z[9,8,1]  R2658     7.9739069938659668e-01
    z[9,8,1]  R2659     7.3832303285598755e-01
    z[9,8,1]  R2660     6.4866358041763306e-01
    z[9,8,1]  R2661     6.1946231126785278e-01
    z[9,8,1]  R2662     7.0504951477050781e-01
    z[9,8,1]  R2663     6.8237692117691040e-01
    z[9,8,1]  R2664     5.7485276460647583e-01
    z[9,8,1]  R2665     0.730842649936676
    z[9,8,1]  R2666     7.4944311380386353e-01
    z[9,8,1]  R2667     5.7339757680892944e-01
    z[9,8,1]  R2668     8.4325706958770752e-01
    z[9,8,1]  R2669     6.8030416965484619e-01
    z[9,8,1]  R2670     -2.7212768793106079e-01
    z[9,8,1]  R2671     -6.3387066125869751e-02
    z[9,8,1]  R2672     2.7062773704528809e-02
    z[9,8,1]  R2673     2.5001174211502075e-01
    z[9,8,1]  R2674     -2.7819997072219849e-01
    z[9,8,1]  R2675     -4.0184023976325989e-01
    z[9,8,1]  R2676     -8.2699873019009829e-04
    z[9,8,1]  R2677     -9.4911180436611176e-02
    z[9,8,1]  R2678     6.2830311059951782e-01
    z[9,8,1]  R2679     6.0234630107879639e-01
    z[9,8,1]  R2680     6.5705102682113647e-01
    z[9,8,1]  R2681     3.5974937677383423e-01
    z[9,8,1]  R2682     9.5749676227569580e-02
    z[9,8,1]  R2683     -4.8531722277402878e-02
    z[9,8,1]  R2684     -3.8195803761482239e-01
    z[9,8,1]  R2685     7.5192131102085114e-02
    z[9,8,1]  R2686     1.3157719373703003e-01
    z[9,8,1]  R2687     -3.1927531957626343e-01
    z[9,8,1]  R2688     7.9016172885894775e-01
    z[9,8,1]  R2689     8.2258272171020508e-01
    z[9,8,1]  R2690     8.8666254281997681e-01
    z[9,8,1]  R2691     7.5900465250015259e-01
    z[9,8,1]  R2692     0.809294581413269
    z[9,8,1]  R2693     5.1300019025802612e-01
    z[9,8,1]  R2694     7.6782727241516113e-01
    z[9,8,1]  R2695     5.9720373153686523e-01
    z[9,8,1]  R2696     1.5615494549274445e-01
    z[9,8,1]  R2697     -1.3358376920223236e-01
    z[9,8,1]  R2698     3.1324383616447449e-01
    z[9,8,1]  R2699     7.7548390626907349e-01
    z[9,8,1]  R2700     1.7036555707454681e-01
    z[9,8,1]  R2701     -4.1772177815437317e-01
    z[9,8,1]  R2702     -0.253431499004364
    z[9,8,1]  R2703     2.1579198539257050e-01
    z[9,8,1]  R2704     1.3170754909515381e-01
    z[9,8,1]  R2705     -3.4229966998100281e-01
    z[9,8,1]  R2706     2.3952980339527130e-01
    z[9,8,1]  R2707     1.8633915483951569e-01
    z[9,8,1]  R2708     6.8395271897315979e-02
    z[9,8,1]  R2709     -5.6348246335983276e-01
    z[9,8,1]  R2710     2.7041158080101013e-01
    z[9,8,1]  R2711     -2.5729942321777344e-01
    z[9,8,1]  R2712     -0.0911824107170105
    z[9,8,1]  R2713     6.5456062555313110e-02
    z[9,8,1]  R2714     -1.0315380990505219e-01
    z[9,8,1]  R2715     -2.5617891550064087e-01
    z[9,8,1]  R2716     -2.3504646122455597e-01
    z[9,8,1]  R2717     -1.7841754853725433e-01
    z[9,8,1]  R2718     -1.6186280548572540e-01
    z[9,8,1]  R2719     8.3938315510749817e-02
    z[9,8,1]  R2720     1.8751224875450134e-01
    z[9,8,1]  R2721     4.7296587377786636e-02
    z[9,8,1]  R2722     -8.9162372052669525e-02
    z[9,8,1]  R2723     -9.0641617774963379e-01
    z[9,8,1]  R2724     -8.6645781993865967e-01
    z[9,8,1]  R2725     -8.3836305141448975e-01
    z[9,8,1]  R2726     -9.1352224349975586e-01
    z[9,8,1]  R2727     -8.3615368604660034e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2558     -1
    z[9,8,2]  R2559     1
    z[9,8,2]  R2568     6.0119831562042236e-01
    z[9,8,2]  R2569     6.5845674276351929e-01
    z[9,8,2]  R2570     -3.7292090058326721e-01
    z[9,8,2]  R2571     -1.6844037920236588e-02
    z[9,8,2]  R2572     0.208670973777771
    z[9,8,2]  R2573     5.1197123527526855e-01
    z[9,8,2]  R2574     2.3732237517833710e-01
    z[9,8,2]  R2575     2.5929355621337891e-01
    z[9,8,2]  R2576     -2.3566943407058716e-01
    z[9,8,2]  R2577     -1.7263881862163544e-01
    z[9,8,2]  R2578     -1.1932317912578583e-01
    z[9,8,2]  R2579     -4.7704420983791351e-02
    z[9,8,2]  R2580     1.5714508295059204e-01
    z[9,8,2]  R2581     3.1169608235359192e-01
    z[9,8,2]  R2582     -1.5421368181705475e-01
    z[9,8,2]  R2583     1.0783152282238007e-01
    z[9,8,2]  R2584     -3.2978415489196777e-01
    z[9,8,2]  R2585     -1.9020775333046913e-02
    z[9,8,2]  R2586     -0.388967901468277
    z[9,8,2]  R2587     -0.0613291971385479
    z[9,8,2]  R2588     2.5621551275253296e-01
    z[9,8,2]  R2589     3.0200770497322083e-01
    z[9,8,2]  R2590     2.6487665250897408e-02
    z[9,8,2]  R2591     5.3616754710674286e-02
    z[9,8,2]  R2592     2.7006408572196960e-01
    z[9,8,2]  R2593     -3.5139295458793640e-01
    z[9,8,2]  R2594     9.5755748450756073e-02
    z[9,8,2]  R2595     1.0427531599998474e-01
    z[9,8,2]  R2596     0.0639515370130539
    z[9,8,2]  R2597     -2.7095419168472290e-01
    z[9,8,2]  R2598     1.4329145848751068e-01
    z[9,8,2]  R2599     5.3386755287647247e-02
    z[9,8,2]  R2600     -2.5896275043487549e-01
    z[9,8,2]  R2601     -2.8887179493904114e-01
    z[9,8,2]  R2602     3.2635146379470825e-01
    z[9,8,2]  R2603     -5.0705488771200180e-02
    z[9,8,2]  R2604     2.8788352012634277e-01
    z[9,8,2]  R2605     -2.5966507196426392e-01
    z[9,8,2]  R2606     -1.2561090290546417e-02
    z[9,8,2]  R2607     3.4817758202552795e-01
    z[9,8,2]  R2608     1.0591665655374527e-01
    z[9,8,2]  R2609     -3.5850632190704346e-01
    z[9,8,2]  R2610     -4.2443636059761047e-01
    z[9,8,2]  R2611     5.0838928669691086e-02
    z[9,8,2]  R2612     1.2665954232215881e-01
    z[9,8,2]  R2613     1.7349500954151154e-01
    z[9,8,2]  R2614     3.4177505970001221e-01
    z[9,8,2]  R2615     -2.2517672181129456e-01
    z[9,8,2]  R2616     -3.2769733667373657e-01
    z[9,8,2]  R2617     7.5107440352439880e-02
    z[9,8,2]  R2618     -1.1293012648820877e-01
    z[9,8,2]  R2619     2.7016565203666687e-01
    z[9,8,2]  R2620     0.284115195274353
    z[9,8,2]  R2621     -2.3836031556129456e-01
    z[9,8,2]  R2622     -3.4947404265403748e-01
    z[9,8,2]  R2623     -1.2920296192169189e-01
    z[9,8,2]  R2624     -4.3436264991760254e-01
    z[9,8,2]  R2625     -2.1037213504314423e-01
    z[9,8,2]  R2626     4.2275067418813705e-02
    z[9,8,2]  R2627     -3.4015023708343506e-01
    z[9,8,2]  R2628     2.7779853343963623e-01
    z[9,8,2]  R2629     5.8591767447069287e-04
    z[9,8,2]  R2630     -2.4033807218074799e-01
    z[9,8,2]  R2631     -1.5402874350547791e-01
    z[9,8,2]  R2632     -7.2709627449512482e-02
    z[9,8,2]  R2633     -4.8643833398818970e-01
    z[9,8,2]  R2634     -4.1759368777275085e-01
    z[9,8,2]  R2635     -2.0346195995807648e-01
    z[9,8,2]  R2636     -1.0566321760416031e-01
    z[9,8,2]  R2637     -1.2967251241207123e-01
    z[9,8,2]  R2638     4.7955888509750366e-01
    z[9,8,2]  R2639     5.2574193477630615e-01
    z[9,8,2]  R2640     0.565449595451355
    z[9,8,2]  R2641     8.1553924083709717e-01
    z[9,8,2]  R2642     6.4739727973937988e-01
    z[9,8,2]  R2643     -3.7284132838249207e-01
    z[9,8,2]  R2644     -1.2426032125949860e-01
    z[9,8,2]  R2645     -1.4245571196079254e-01
    z[9,8,2]  R2646     -0.0619538351893425
    z[9,8,2]  R2647     1.6244810819625854e-01
    z[9,8,2]  R2648     -5.9567335993051529e-02
    z[9,8,2]  R2649     4.6708053350448608e-01
    z[9,8,2]  R2650     2.3357817530632019e-01
    z[9,8,2]  R2651     -2.5872397422790527e-01
    z[9,8,2]  R2652     -3.5164999961853027e-01
    z[9,8,2]  R2653     0.294384241104126
    z[9,8,2]  R2654     -3.7575873732566833e-01
    z[9,8,2]  R2655     -6.5847319364547729e-01
    z[9,8,2]  R2656     -2.9010412096977234e-01
    z[9,8,2]  R2657     -2.9292309284210205e-01
    z[9,8,2]  R2658     -0.102711021900177
    z[9,8,2]  R2659     -2.1386066079139709e-01
    z[9,8,2]  R2660     -0.245735302567482
    z[9,8,2]  R2661     -4.9894452095031738e-01
    z[9,8,2]  R2662     -1.9249689579010010e-01
    z[9,8,2]  R2663     2.5324749946594238e-01
    z[9,8,2]  R2664     -3.1486704945564270e-01
    z[9,8,2]  R2665     -2.2246772050857544e-01
    z[9,8,2]  R2666     3.6608977243304253e-03
    z[9,8,2]  R2667     -3.7173548340797424e-01
    z[9,8,2]  R2668     -1.9826452434062958e-01
    z[9,8,2]  R2669     3.0065628886222839e-01
    z[9,8,2]  R2670     -5.4874461889266968e-01
    z[9,8,2]  R2671     1.2436462938785553e-01
    z[9,8,2]  R2672     -2.1571689844131470e-01
    z[9,8,2]  R2673     6.0266986489295959e-02
    z[9,8,2]  R2674     1.3241645693778992e-01
    z[9,8,2]  R2675     -7.5738435983657837e-01
    z[9,8,2]  R2676     -4.2077675461769104e-01
    z[9,8,2]  R2677     -8.3095115423202515e-01
    z[9,8,2]  R2678     1.3665291666984558e-01
    z[9,8,2]  R2679     -4.5909079909324646e-01
    z[9,8,2]  R2680     9.8254293203353882e-02
    z[9,8,2]  R2681     -4.2626655101776123e-01
    z[9,8,2]  R2682     1.3493350148200989e-01
    z[9,8,2]  R2683     -3.0118385329842567e-02
    z[9,8,2]  R2684     -0.602405846118927
    z[9,8,2]  R2685     -3.7822088599205017e-01
    z[9,8,2]  R2686     -1.4436319470405579e-01
    z[9,8,2]  R2687     -0.777163565158844
    z[9,8,2]  R2688     -4.3973001837730408e-01
    z[9,8,2]  R2689     -6.8632923066616058e-02
    z[9,8,2]  R2690     3.4726104140281677e-01
    z[9,8,2]  R2691     1.0989388078451157e-01
    z[9,8,2]  R2692     2.4211842101067305e-03
    z[9,8,2]  R2693     9.6697226166725159e-02
    z[9,8,2]  R2694     2.7760079503059387e-01
    z[9,8,2]  R2695     -1.9307935237884521e-01
    z[9,8,2]  R2696     7.6088112592697144e-01
    z[9,8,2]  R2697     0.29134401679039
    z[9,8,2]  R2698     -2.4838103353977203e-01
    z[9,8,2]  R2699     1.2162237614393234e-01
    z[9,8,2]  R2700     8.0715399980545044e-01
    z[9,8,2]  R2701     -0.432815819978714
    z[9,8,2]  R2702     -8.0312824249267578e-01
    z[9,8,2]  R2703     -2.5108432769775391e-01
    z[9,8,2]  R2704     -2.9693427681922913e-01
    z[9,8,2]  R2705     -5.6551790237426758e-01
    z[9,8,2]  R2706     1.9435006380081177e-01
    z[9,8,2]  R2707     -1.7551237344741821e-01
    z[9,8,2]  R2708     -6.7357398569583893e-02
    z[9,8,2]  R2709     -5.7572543621063232e-01
    z[9,8,2]  R2710     -2.7424991130828857e-01
    z[9,8,2]  R2711     1.4285388588905334e-01
    z[9,8,2]  R2712     3.7022361159324646e-01
    z[9,8,2]  R2713     -6.6915291547775269e-01
    z[9,8,2]  R2714     1.1230655014514923e-01
    z[9,8,2]  R2715     -1.3322305679321289e-01
    z[9,8,2]  R2716     -6.1300748586654663e-01
    z[9,8,2]  R2717     2.2271849215030670e-01
    z[9,8,2]  R2718     -4.7684401273727417e-02
    z[9,8,2]  R2719     -1.5192721784114838e-01
    z[9,8,2]  R2720     -3.2909657806158066e-02
    z[9,8,2]  R2721     3.5245963931083679e-01
    z[9,8,2]  R2722     0.0596194826066494
    z[9,8,2]  R2723     -3.6621391773223877e-01
    z[9,8,2]  R2724     -3.6664634943008423e-01
    z[9,8,2]  R2725     -3.6266416311264038e-01
    z[9,8,2]  R2726     -1.9708488881587982e-01
    z[9,8,2]  R2727     -2.6363670825958252e-01
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2560     -1
    z[9,8,3]  R2561     1
    z[9,8,3]  R2568     2.6745793223381042e-01
    z[9,8,3]  R2569     2.1631832420825958e-01
    z[9,8,3]  R2570     4.9046754837036133e-01
    z[9,8,3]  R2571     8.1015920639038086e-01
    z[9,8,3]  R2572     8.7596577405929565e-01
    z[9,8,3]  R2573     6.1187815666198730e-01
    z[9,8,3]  R2574     6.0210049152374268e-01
    z[9,8,3]  R2575     5.6074738502502441e-01
    z[9,8,3]  R2576     4.2829075455665588e-01
    z[9,8,3]  R2577     8.7676249444484711e-02
    z[9,8,3]  R2578     3.2030718284659088e-04
    z[9,8,3]  R2579     -1.5726526081562042e-01
    z[9,8,3]  R2580     0.510026752948761
    z[9,8,3]  R2581     2.9189857840538025e-01
    z[9,8,3]  R2582     5.0670951604843140e-01
    z[9,8,3]  R2583     2.1482449956238270e-03
    z[9,8,3]  R2584     0.194418266415596
    z[9,8,3]  R2585     5.4579585790634155e-01
    z[9,8,3]  R2586     1.1006633937358856e-01
    z[9,8,3]  R2587     0.210173562169075
    z[9,8,3]  R2588     -1.1477672308683395e-01
    z[9,8,3]  R2589     1.6191175580024719e-01
    z[9,8,3]  R2590     7.8962184488773346e-02
    z[9,8,3]  R2591     7.9013293981552124e-01
    z[9,8,3]  R2592     5.6404348462820053e-02
    z[9,8,3]  R2593     -4.3802550435066223e-01
    z[9,8,3]  R2594     -4.9159732460975647e-01
    z[9,8,3]  R2595     3.3527228236198425e-01
    z[9,8,3]  R2596     0.500817060470581
    z[9,8,3]  R2597     -4.3633630871772766e-01
    z[9,8,3]  R2598     9.9438525736331940e-02
    z[9,8,3]  R2599     1.9843837618827820e-01
    z[9,8,3]  R2600     5.3493392467498779e-01
    z[9,8,3]  R2601     -1.0884377360343933e-01
    z[9,8,3]  R2602     4.5015761256217957e-01
    z[9,8,3]  R2603     1.1064665019512177e-01
    z[9,8,3]  R2604     5.5983585119247437e-01
    z[9,8,3]  R2605     6.4900976419448853e-01
    z[9,8,3]  R2606     -0.381475031375885
    z[9,8,3]  R2607     4.9845075607299805e-01
    z[9,8,3]  R2608     1.0783334076404572e-01
    z[9,8,3]  R2609     7.5359144248068333e-03
    z[9,8,3]  R2610     -1.3345412909984589e-01
    z[9,8,3]  R2611     8.1412959098815918e-01
    z[9,8,3]  R2612     4.1875693202018738e-01
    z[9,8,3]  R2613     7.2381514310836792e-01
    z[9,8,3]  R2614     0.524556577205658
    z[9,8,3]  R2615     -4.8285833001136780e-01
    z[9,8,3]  R2616     -6.8804478645324707e-01
    z[9,8,3]  R2617     -6.6409087181091309e-01
    z[9,8,3]  R2618     6.1818454414606094e-02
    z[9,8,3]  R2619     3.6368572711944580e-01
    z[9,8,3]  R2620     7.0382076501846313e-01
    z[9,8,3]  R2621     1.5992195904254913e-01
    z[9,8,3]  R2622     -6.0701805353164673e-01
    z[9,8,3]  R2623     -5.1418608427047729e-01
    z[9,8,3]  R2624     -0.731490433216095
    z[9,8,3]  R2625     5.5768400430679321e-01
    z[9,8,3]  R2626     2.6345852017402649e-01
    z[9,8,3]  R2627     -9.4710178673267365e-02
    z[9,8,3]  R2628     7.2435122728347778e-01
    z[9,8,3]  R2629     3.2289031893014908e-02
    z[9,8,3]  R2630     -3.7586545944213867e-01
    z[9,8,3]  R2631     5.9365427494049072e-01
    z[9,8,3]  R2632     -0.61862713098526
    z[9,8,3]  R2633     1.6522195935249329e-01
    z[9,8,3]  R2634     2.1658472716808319e-01
    z[9,8,3]  R2635     1.1529392749071121e-01
    z[9,8,3]  R2636     2.3029154539108276e-01
    z[9,8,3]  R2637     -3.3830992877483368e-02
    z[9,8,3]  R2638     2.5020893663167953e-02
    z[9,8,3]  R2639     -2.0159909501671791e-02
    z[9,8,3]  R2640     -2.4972374737262726e-01
    z[9,8,3]  R2641     2.0682762563228607e-01
    z[9,8,3]  R2642     8.6605958640575409e-02
    z[9,8,3]  R2643     8.7584728002548218e-01
    z[9,8,3]  R2644     0.886455774307251
    z[9,8,3]  R2645     7.7952551841735840e-01
    z[9,8,3]  R2646     6.8842327594757080e-01
    z[9,8,3]  R2647     7.6254725456237793e-01
    z[9,8,3]  R2648     -2.1076574921607971e-01
    z[9,8,3]  R2649     1.7412135004997253e-01
    z[9,8,3]  R2650     2.5826262310147285e-02
    z[9,8,3]  R2651     1.6320027410984039e-01
    z[9,8,3]  R2652     2.8141847252845764e-01
    z[9,8,3]  R2653     3.7003250326961279e-03
    z[9,8,3]  R2654     -0.00538968201726675
    z[9,8,3]  R2655     2.6330480352044106e-02
    z[9,8,3]  R2656     -1.0333186388015747e-01
    z[9,8,3]  R2657     1.6312251985073090e-01
    z[9,8,3]  R2658     6.8231053650379181e-02
    z[9,8,3]  R2659     0.591113269329071
    z[9,8,3]  R2660     -1.8255592882633209e-01
    z[9,8,3]  R2661     0.0961490273475647
    z[9,8,3]  R2662     -1.9007220864295959e-01
    z[9,8,3]  R2663     2.4882838129997253e-01
    z[9,8,3]  R2664     2.1823190152645111e-01
    z[9,8,3]  R2665     -1.9260866940021515e-01
    z[9,8,3]  R2666     -0.00952579453587532
    z[9,8,3]  R2667     -2.9420253634452820e-01
    z[9,8,3]  R2668     1.9434593617916107e-01
    z[9,8,3]  R2669     -3.4812459349632263e-01
    z[9,8,3]  R2670     2.1785824000835419e-01
    z[9,8,3]  R2671     -6.4719247817993164e-01
    z[9,8,3]  R2672     -7.3756092786788940e-01
    z[9,8,3]  R2673     -8.5562056303024292e-01
    z[9,8,3]  R2674     -0.709907591342926
    z[9,8,3]  R2675     2.2079738974571228e-01
    z[9,8,3]  R2676     3.9861035346984863e-01
    z[9,8,3]  R2677     -8.2400523126125336e-02
    z[9,8,3]  R2678     4.2890876531600952e-01
    z[9,8,3]  R2679     -1.1907821148633957e-01
    z[9,8,3]  R2680     -3.1710562109947205e-01
    z[9,8,3]  R2681     4.3346762657165527e-01
    z[9,8,3]  R2682     5.7884871959686279e-01
    z[9,8,3]  R2683     -8.2855713367462158e-01
    z[9,8,3]  R2684     2.7887905016541481e-02
    z[9,8,3]  R2685     3.4898456931114197e-01
    z[9,8,3]  R2686     3.9520654082298279e-01
    z[9,8,3]  R2687     1.0373300313949585e-01
    z[9,8,3]  R2688     2.6181671023368835e-01
    z[9,8,3]  R2689     3.0752778053283691e-02
    z[9,8,3]  R2690     -1.0336022078990936e-01
    z[9,8,3]  R2691     -1.0176008194684982e-01
    z[9,8,3]  R2692     -1.9595865160226822e-02
    z[9,8,3]  R2693     5.7871639728546143e-01
    z[9,8,3]  R2694     4.3673789501190186e-01
    z[9,8,3]  R2695     2.7254721149802208e-02
    z[9,8,3]  R2696     -5.4215413331985474e-01
    z[9,8,3]  R2697     3.5157926380634308e-02
    z[9,8,3]  R2698     8.2601845264434814e-01
    z[9,8,3]  R2699     4.0940120816230774e-01
    z[9,8,3]  R2700     -4.6199521422386169e-01
    z[9,8,3]  R2701     3.7539044022560120e-01
    z[9,8,3]  R2702     9.1040439903736115e-02
    z[9,8,3]  R2703     4.2059344053268433e-01
    z[9,8,3]  R2704     -4.6221151947975159e-01
    z[9,8,3]  R2705     7.8479431569576263e-02
    z[9,8,3]  R2706     -0.835407018661499
    z[9,8,3]  R2707     4.3667939305305481e-01
    z[9,8,3]  R2708     8.7394517660140991e-01
    z[9,8,3]  R2709     3.2051730155944824e-01
    z[9,8,3]  R2710     4.9250802397727966e-01
    z[9,8,3]  R2711     -7.9185032844543457e-01
    z[9,8,3]  R2712     1.9741542637348175e-01
    z[9,8,3]  R2713     4.6691466122865677e-03
    z[9,8,3]  R2714     -4.7329258918762207e-01
    z[9,8,3]  R2715     -4.7493028640747070e-01
    z[9,8,3]  R2716     -3.6188460886478424e-02
    z[9,8,3]  R2717     -2.6878905296325684e-01
    z[9,8,3]  R2718     -6.1702221632003784e-01
    z[9,8,3]  R2719     -7.4480628967285156e-01
    z[9,8,3]  R2720     0.576059877872467
    z[9,8,3]  R2721     -4.5782437920570374e-01
    z[9,8,3]  R2722     5.5540060997009277e-01
    z[9,8,3]  R2723     -3.3231852576136589e-03
    z[9,8,3]  R2724     1.4756141602993011e-01
    z[9,8,3]  R2725     -2.0093291997909546e-01
    z[9,8,3]  R2726     -1.4315296709537506e-01
    z[9,8,3]  R2727     2.6009619235992432e-01
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2562     -1
    z[9,8,4]  R2563     1
    z[9,8,4]  R2568     -2.2025765478610992e-01
    z[9,8,4]  R2569     4.9540884792804718e-02
    z[9,8,4]  R2570     -1.9937008619308472e-01
    z[9,8,4]  R2571     1.5698830783367157e-01
    z[9,8,4]  R2572     -1.9919518381357193e-02
    z[9,8,4]  R2573     -5.7643294334411621e-01
    z[9,8,4]  R2574     -4.1490471363067627e-01
    z[9,8,4]  R2575     -6.8947827816009521e-01
    z[9,8,4]  R2576     8.0657035112380981e-02
    z[9,8,4]  R2577     -2.3938387632369995e-01
    z[9,8,4]  R2578     -2.5749403238296509e-01
    z[9,8,4]  R2579     -1.5698436647653580e-02
    z[9,8,4]  R2580     6.4038641750812531e-02
    z[9,8,4]  R2581     -6.4481054432690144e-03
    z[9,8,4]  R2582     1.4860455691814423e-01
    z[9,8,4]  R2583     2.1630044281482697e-01
    z[9,8,4]  R2584     -1.8657873570919037e-01
    z[9,8,4]  R2585     2.4084559082984924e-01
    z[9,8,4]  R2586     2.0764137804508209e-01
    z[9,8,4]  R2587     2.4053536355495453e-01
    z[9,8,4]  R2588     1.1786674708127975e-01
    z[9,8,4]  R2589     4.6568755060434341e-03
    z[9,8,4]  R2590     2.0146493613719940e-01
    z[9,8,4]  R2591     -4.7542190551757812e-01
    z[9,8,4]  R2592     1.6603556275367737e-01
    z[9,8,4]  R2593     0.263406902551651
    z[9,8,4]  R2594     2.3883616924285889e-01
    z[9,8,4]  R2595     -6.7056399583816528e-01
    z[9,8,4]  R2596     -2.4792028963565826e-01
    z[9,8,4]  R2597     4.6367591619491577e-01
    z[9,8,4]  R2598     2.2562585771083832e-01
    z[9,8,4]  R2599     4.4862195849418640e-01
    z[9,8,4]  R2600     -3.6542826890945435e-01
    z[9,8,4]  R2601     -3.4813615679740906e-01
    z[9,8,4]  R2602     1.0701561719179153e-01
    z[9,8,4]  R2603     -2.8643617033958435e-01
    z[9,8,4]  R2604     -6.4117950201034546e-01
    z[9,8,4]  R2605     -4.3757069110870361e-01
    z[9,8,4]  R2606     3.1786888837814331e-01
    z[9,8,4]  R2607     -3.4919813275337219e-01
    z[9,8,4]  R2608     5.7811133563518524e-02
    z[9,8,4]  R2609     2.5662171840667725e-01
    z[9,8,4]  R2610     -2.6620498299598694e-01
    z[9,8,4]  R2611     -5.4105542600154877e-02
    z[9,8,4]  R2612     -2.5736445188522339e-01
    z[9,8,4]  R2613     -4.0130594372749329e-01
    z[9,8,4]  R2614     -4.9146994948387146e-01
    z[9,8,4]  R2615     4.8633995652198792e-01
    z[9,8,4]  R2616     3.8258891552686691e-02
    z[9,8,4]  R2617     -4.3908131122589111e-01
    z[9,8,4]  R2618     3.5036456584930420e-01
    z[9,8,4]  R2619     3.3553251996636391e-03
    z[9,8,4]  R2620     -5.3329789638519287e-01
    z[9,8,4]  R2621     2.5605052709579468e-01
    z[9,8,4]  R2622     3.9515992999076843e-01
    z[9,8,4]  R2623     2.5869178771972656e-01
    z[9,8,4]  R2624     9.3507938086986542e-02
    z[9,8,4]  R2625     -0.154225692152977
    z[9,8,4]  R2626     -4.0393674373626709e-01
    z[9,8,4]  R2627     -6.1272329092025757e-01
    z[9,8,4]  R2628     2.5348857045173645e-01
    z[9,8,4]  R2629     -2.1339474618434906e-01
    z[9,8,4]  R2630     3.6196881532669067e-01
    z[9,8,4]  R2631     -2.2272971272468567e-01
    z[9,8,4]  R2632     5.5822777748107910e-01
    z[9,8,4]  R2633     -4.1396361589431763e-01
    z[9,8,4]  R2634     -1.0913689434528351e-01
    z[9,8,4]  R2635     -2.0239000022411346e-01
    z[9,8,4]  R2636     -5.0234001874923706e-01
    z[9,8,4]  R2637     1.0885780304670334e-01
    z[9,8,4]  R2638     -6.0702785849571228e-02
    z[9,8,4]  R2639     -1.6370341181755066e-01
    z[9,8,4]  R2640     -2.1409824490547180e-01
    z[9,8,4]  R2641     -1.0911155492067337e-02
    z[9,8,4]  R2642     -1.8714027106761932e-01
    z[9,8,4]  R2643     -2.6003894209861755e-01
    z[9,8,4]  R2644     4.6505674719810486e-02
    z[9,8,4]  R2645     -5.3447896242141724e-01
    z[9,8,4]  R2646     -0.631626546382904
    z[9,8,4]  R2647     -6.0656398534774780e-01
    z[9,8,4]  R2648     3.8101791869848967e-03
    z[9,8,4]  R2649     -1.3773700594902039e-01
    z[9,8,4]  R2650     -2.6488479971885681e-01
    z[9,8,4]  R2651     5.4444384574890137e-01
    z[9,8,4]  R2652     2.2349333763122559e-01
    z[9,8,4]  R2653     5.1280868053436279e-01
    z[9,8,4]  R2654     -4.9400264024734497e-01
    z[9,8,4]  R2655     2.6858943700790405e-01
    z[9,8,4]  R2656     -0.381608247756958
    z[9,8,4]  R2657     0.672268271446228
    z[9,8,4]  R2658     -4.3929553031921387e-01
    z[9,8,4]  R2659     6.3479013741016388e-02
    z[9,8,4]  R2660     -3.5290178656578064e-01
    z[9,8,4]  R2661     -2.2511450946331024e-01
    z[9,8,4]  R2662     2.7396363019943237e-01
    z[9,8,4]  R2663     -0.324464350938797
    z[9,8,4]  R2664     -4.2967510223388672e-01
    z[9,8,4]  R2665     2.7419865131378174e-01
    z[9,8,4]  R2666     3.5170897841453552e-01
    z[9,8,4]  R2667     -2.0574498921632767e-03
    z[9,8,4]  R2668     5.4170109331607819e-02
    z[9,8,4]  R2669     -5.3116941452026367e-01
    z[9,8,4]  R2670     -4.3936005234718323e-01
    z[9,8,4]  R2671     2.3174965381622314e-01
    z[9,8,4]  R2672     1.9797667860984802e-01
    z[9,8,4]  R2673     2.7299249172210693e-01
    z[9,8,4]  R2674     3.4672826528549194e-01
    z[9,8,4]  R2675     0.256306916475296
    z[9,8,4]  R2676     1.2066429853439331e-01
    z[9,8,4]  R2677     4.5660361647605896e-02
    z[9,8,4]  R2678     -6.1327022314071655e-01
    z[9,8,4]  R2679     5.9897321462631226e-01
    z[9,8,4]  R2680     4.8401924967765808e-01
    z[9,8,4]  R2681     8.9172385632991791e-02
    z[9,8,4]  R2682     1.9298788160085678e-02
    z[9,8,4]  R2683     9.8577544093132019e-02
    z[9,8,4]  R2684     -1.0599945485591888e-01
    z[9,8,4]  R2685     3.6982879042625427e-01
    z[9,8,4]  R2686     1.7723430693149567e-01
    z[9,8,4]  R2687     -4.5534770935773849e-02
    z[9,8,4]  R2688     -5.9796366840600967e-02
    z[9,8,4]  R2689     -1.6417492926120758e-01
    z[9,8,4]  R2690     -9.0975128114223480e-02
    z[9,8,4]  R2691     5.3408050537109375e-01
    z[9,8,4]  R2692     0.520047664642334
    z[9,8,4]  R2693     -5.3054285049438477e-01
    z[9,8,4]  R2694     -2.5470888614654541e-01
    z[9,8,4]  R2695     4.0219381451606750e-01
    z[9,8,4]  R2696     -3.1121345236897469e-02
    z[9,8,4]  R2697     3.2903265953063965e-01
    z[9,8,4]  R2698     -5.1761273294687271e-02
    z[9,8,4]  R2699     -3.8550980389118195e-02
    z[9,8,4]  R2700     -4.5182496309280396e-02
    z[9,8,4]  R2701     -3.6956712603569031e-01
    z[9,8,4]  R2702     -1.3292072713375092e-01
    z[9,8,4]  R2703     -1.8835441768169403e-01
    z[9,8,4]  R2704     5.5422937870025635e-01
    z[9,8,4]  R2705     -1.3107995688915253e-01
    z[9,8,4]  R2706     2.4477869272232056e-01
    z[9,8,4]  R2707     4.5653986930847168e-01
    z[9,8,4]  R2708     -1.4539791643619537e-01
    z[9,8,4]  R2709     -2.5600489974021912e-01
    z[9,8,4]  R2710     -2.0681457221508026e-01
    z[9,8,4]  R2711     4.1539192199707031e-01
    z[9,8,4]  R2712     -4.3201935291290283e-01
    z[9,8,4]  R2713     2.6885172724723816e-01
    z[9,8,4]  R2714     5.6846636533737183e-01
    z[9,8,4]  R2715     6.3694953918457031e-01
    z[9,8,4]  R2716     5.3225511312484741e-01
    z[9,8,4]  R2717     2.6034596562385559e-01
    z[9,8,4]  R2718     4.3744844198226929e-01
    z[9,8,4]  R2719     1.2768211960792542e-01
    z[9,8,4]  R2720     4.9454993009567261e-01
    z[9,8,4]  R2721     5.9390527009963989e-01
    z[9,8,4]  R2722     4.8084896802902222e-01
    z[9,8,4]  R2723     1.5543513000011444e-01
    z[9,8,4]  R2724     -1.1964630335569382e-02
    z[9,8,4]  R2725     2.3769660294055939e-01
    z[9,8,4]  R2726     -6.2905423343181610e-02
    z[9,8,4]  R2727     2.1035051345825195e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2564     -1
    z[9,8,5]  R2565     1
    z[9,8,5]  R2568     -1.9467087090015411e-01
    z[9,8,5]  R2569     2.6567959785461426e-01
    z[9,8,5]  R2570     2.2427400574088097e-02
    z[9,8,5]  R2571     -5.4391944408416748e-01
    z[9,8,5]  R2572     -3.5637673735618591e-01
    z[9,8,5]  R2573     -4.8700369894504547e-02
    z[9,8,5]  R2574     -7.5534239411354065e-02
    z[9,8,5]  R2575     -3.2818788290023804e-01
    z[9,8,5]  R2576     -4.0075135231018066e-01
    z[9,8,5]  R2577     4.8053160309791565e-01
    z[9,8,5]  R2578     -1.5864242613315582e-01
    z[9,8,5]  R2579     -1.8162797391414642e-01
    z[9,8,5]  R2580     1.1702164262533188e-01
    z[9,8,5]  R2581     1.4710952341556549e-01
    z[9,8,5]  R2582     8.5905738174915314e-02
    z[9,8,5]  R2583     1.8779808282852173e-01
    z[9,8,5]  R2584     -1.3045580685138702e-01
    z[9,8,5]  R2585     1.2709461152553558e-01
    z[9,8,5]  R2586     -4.6299362182617188e-01
    z[9,8,5]  R2587     5.8834099769592285e-01
    z[9,8,5]  R2588     5.4942883551120758e-02
    z[9,8,5]  R2589     3.9418280124664307e-01
    z[9,8,5]  R2590     -0.301368772983551
    z[9,8,5]  R2591     -2.5309933349490166e-02
    z[9,8,5]  R2592     4.2968633770942688e-01
    z[9,8,5]  R2593     7.5681346654891968e-01
    z[9,8,5]  R2594     6.8053728342056274e-01
    z[9,8,5]  R2595     -5.4070943593978882e-01
    z[9,8,5]  R2596     -5.3338271379470825e-01
    z[9,8,5]  R2597     5.2292549610137939e-01
    z[9,8,5]  R2598     2.7252739667892456e-01
    z[9,8,5]  R2599     -4.6664139628410339e-01
    z[9,8,5]  R2600     -0.513565719127655
    z[9,8,5]  R2601     5.2712988853454590e-01
    z[9,8,5]  R2602     -4.5385599136352539e-01
    z[9,8,5]  R2603     5.8251172304153442e-01
    z[9,8,5]  R2604     -2.1387417614459991e-01
    z[9,8,5]  R2605     -1.5060220845043659e-02
    z[9,8,5]  R2606     6.8639487028121948e-01
    z[9,8,5]  R2607     -2.4893115460872650e-01
    z[9,8,5]  R2608     3.8159903883934021e-01
    z[9,8,5]  R2609     1.7658115923404694e-01
    z[9,8,5]  R2610     0.375962495803833
    z[9,8,5]  R2611     -2.2506140172481537e-01
    z[9,8,5]  R2612     -7.0776619017124176e-02
    z[9,8,5]  R2613     -4.2152115702629089e-01
    z[9,8,5]  R2614     -6.0033202171325684e-01
    z[9,8,5]  R2615     5.8392065763473511e-01
    z[9,8,5]  R2616     4.4555336236953735e-01
    z[9,8,5]  R2617     0.540216326713562
    z[9,8,5]  R2618     5.9696469455957413e-02
    z[9,8,5]  R2619     -2.3778945207595825e-01
    z[9,8,5]  R2620     -2.4003544449806213e-01
    z[9,8,5]  R2621     -4.2458108067512512e-01
    z[9,8,5]  R2622     5.4056447744369507e-01
    z[9,8,5]  R2623     7.1215301752090454e-01
    z[9,8,5]  R2624     4.3745765089988708e-01
    z[9,8,5]  R2625     -3.7895795702934265e-01
    z[9,8,5]  R2626     -8.3969587087631226e-01
    z[9,8,5]  R2627     6.5132617950439453e-01
    z[9,8,5]  R2628     -4.1937139630317688e-01
    z[9,8,5]  R2629     -1.4807693660259247e-01
    z[9,8,5]  R2630     0.404939204454422
    z[9,8,5]  R2631     -6.5721738338470459e-01
    z[9,8,5]  R2632     4.8852661252021790e-01
    z[9,8,5]  R2633     3.3111223578453064e-01
    z[9,8,5]  R2634     0.810812771320343
    z[9,8,5]  R2635     0.654262900352478
    z[9,8,5]  R2636     5.9761160612106323e-01
    z[9,8,5]  R2637     -2.4756550788879395e-02
    z[9,8,5]  R2638     -1.3654959201812744e-01
    z[9,8,5]  R2639     -9.2440247535705566e-02
    z[9,8,5]  R2640     1.0115293785929680e-02
    z[9,8,5]  R2641     1.0998719371855259e-02
    z[9,8,5]  R2642     1.2060520052909851e-01
    z[9,8,5]  R2643     -9.4037890434265137e-02
    z[9,8,5]  R2644     -3.7226337194442749e-01
    z[9,8,5]  R2645     -1.7053464055061340e-01
    z[9,8,5]  R2646     -3.1147161126136780e-01
    z[9,8,5]  R2647     -2.4714589118957520e-02
    z[9,8,5]  R2648     -3.2154834270477295e-01
    z[9,8,5]  R2649     2.6955306529998779e-01
    z[9,8,5]  R2650     -5.3265053033828735e-01
    z[9,8,5]  R2651     1.7484933137893677e-01
    z[9,8,5]  R2652     1.6320532560348511e-01
    z[9,8,5]  R2653     -2.1414074301719666e-01
    z[9,8,5]  R2654     7.7239155769348145e-01
    z[9,8,5]  R2655     1.3511365652084351e-01
    z[9,8,5]  R2656     6.2932890653610229e-01
    z[9,8,5]  R2657     -2.1945912390947342e-02
    z[9,8,5]  R2658     3.3637553453445435e-01
    z[9,8,5]  R2659     6.4657934010028839e-02
    z[9,8,5]  R2660     3.4015449881553650e-01
    z[9,8,5]  R2661     -1.7019546031951904e-01
    z[9,8,5]  R2662     5.1290357112884521e-01
    z[9,8,5]  R2663     -2.0324380695819855e-01
    z[9,8,5]  R2664     -1.7839151620864868e-01
    z[9,8,5]  R2665     5.2952367067337036e-01
    z[9,8,5]  R2666     1.2697046995162964e-01
    z[9,8,5]  R2667     -2.0534142851829529e-01
    z[9,8,5]  R2668     3.8339513540267944e-01
    z[9,8,5]  R2669     -6.2285237014293671e-02
    z[9,8,5]  R2670     4.9384722113609314e-01
    z[9,8,5]  R2671     7.0507985353469849e-01
    z[9,8,5]  R2672     4.7425702214241028e-01
    z[9,8,5]  R2673     2.9225319623947144e-01
    z[9,8,5]  R2674     4.9426114559173584e-01
    z[9,8,5]  R2675     3.1892961263656616e-01
    z[9,8,5]  R2676     4.8496076464653015e-01
    z[9,8,5]  R2677     4.0534928441047668e-01
    z[9,8,5]  R2678     1.6330938786268234e-02
    z[9,8,5]  R2679     1.9894470274448395e-01
    z[9,8,5]  R2680     -1.7619448900222778e-01
    z[9,8,5]  R2681     -5.9015041589736938e-01
    z[9,8,5]  R2682     3.0861091613769531e-01
    z[9,8,5]  R2683     5.2670252323150635e-01
    z[9,8,5]  R2684     0.238073468208313
    z[9,8,5]  R2685     7.0517018437385559e-02
    z[9,8,5]  R2686     -4.1556927561759949e-01
    z[9,8,5]  R2687     1.5158849954605103e-01
    z[9,8,5]  R2688     -1.3737757503986359e-01
    z[9,8,5]  R2689     5.3427174687385559e-02
    z[9,8,5]  R2690     2.3475063499063253e-03
    z[9,8,5]  R2691     -2.4367213249206543e-01
    z[9,8,5]  R2692     -3.1883720308542252e-02
    z[9,8,5]  R2693     -0.221435084939003
    z[9,8,5]  R2694     -2.3268258571624756e-01
    z[9,8,5]  R2695     -4.3591648340225220e-01
    z[9,8,5]  R2696     9.1966040432453156e-02
    z[9,8,5]  R2697     8.3843415975570679e-01
    z[9,8,5]  R2698     -3.9317813515663147e-01
    z[9,8,5]  R2699     -4.1142249107360840e-01
    z[9,8,5]  R2700     1.2930651009082794e-01
    z[9,8,5]  R2701     5.8101141452789307e-01
    z[9,8,5]  R2702     4.9192342907190323e-02
    z[9,8,5]  R2703     3.4624036401510239e-02
    z[9,8,5]  R2704     5.9644037485122681e-01
    z[9,8,5]  R2705     4.2838081717491150e-01
    z[9,8,5]  R2706     3.7177410721778870e-01
    z[9,8,5]  R2707     -2.0003531873226166e-01
    z[9,8,5]  R2708     -4.4080230593681335e-01
    z[9,8,5]  R2709     0.372408926486969
    z[9,8,5]  R2710     6.6106610000133514e-02
    z[9,8,5]  R2711     2.1512353420257568e-01
    z[9,8,5]  R2712     -6.4128667116165161e-01
    z[9,8,5]  R2713     5.8276677131652832e-01
    z[9,8,5]  R2714     2.9139328002929688e-01
    z[9,8,5]  R2715     2.3616470396518707e-01
    z[9,8,5]  R2716     3.9361339807510376e-01
    z[9,8,5]  R2717     0.679141640663147
    z[9,8,5]  R2718     6.2278968095779419e-01
    z[9,8,5]  R2719     6.0777628421783447e-01
    z[9,8,5]  R2720     -1.0870582610368729e-01
    z[9,8,5]  R2721     3.1675449013710022e-01
    z[9,8,5]  R2722     4.4717827439308167e-01
    z[9,8,5]  R2723     2.5152226909995079e-02
    z[9,8,5]  R2724     -2.3318465054035187e-01
    z[9,8,5]  R2725     -1.5005064010620117e-01
    z[9,8,5]  R2726     1.3023109734058380e-01
    z[9,8,5]  R2727     -0.0937047228217125
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2566     -1
    z[9,8,6]  R2567     1
    z[9,8,6]  R2568     1.0395793616771698e-01
    z[9,8,6]  R2569     1.9415576010942459e-02
    z[9,8,6]  R2570     -6.9697767496109009e-02
    z[9,8,6]  R2571     1.1169490963220596e-01
    z[9,8,6]  R2572     -1.2352060526609421e-02
    z[9,8,6]  R2573     1.6082102060317993e-01
    z[9,8,6]  R2574     5.7173055410385132e-01
    z[9,8,6]  R2575     -1.2007039785385132e-01
    z[9,8,6]  R2576     6.4285027980804443e-01
    z[9,8,6]  R2577     6.8001949787139893e-01
    z[9,8,6]  R2578     1.8460302054882050e-01
    z[9,8,6]  R2579     -1.5779319405555725e-01
    z[9,8,6]  R2580     1.9296933710575104e-01
    z[9,8,6]  R2581     -1.5386903285980225e-01
    z[9,8,6]  R2582     1.9968789815902710e-01
    z[9,8,6]  R2583     -2.3701782524585724e-01
    z[9,8,6]  R2584     -2.6190373301506042e-01
    z[9,8,6]  R2585     -3.3819109201431274e-01
    z[9,8,6]  R2586     -1.7705438658595085e-02
    z[9,8,6]  R2587     -3.8312196731567383e-02
    z[9,8,6]  R2588     -2.1390339732170105e-01
    z[9,8,6]  R2589     4.9474292993545532e-01
    z[9,8,6]  R2590     4.9652910232543945e-01
    z[9,8,6]  R2591     1.8477691337466240e-02
    z[9,8,6]  R2592     4.2714181542396545e-01
    z[9,8,6]  R2593     1.1721289902925491e-01
    z[9,8,6]  R2594     4.5573955774307251e-01
    z[9,8,6]  R2595     -1.0785336047410965e-01
    z[9,8,6]  R2596     -3.8591352105140686e-01
    z[9,8,6]  R2597     -4.1525909304618835e-01
    z[9,8,6]  R2598     3.7685650587081909e-01
    z[9,8,6]  R2599     -7.2364950180053711e-01
    z[9,8,6]  R2600     6.8157516419887543e-02
    z[9,8,6]  R2601     -2.4559737741947174e-01
    z[9,8,6]  R2602     8.1955626606941223e-02
    z[9,8,6]  R2603     -3.5615113377571106e-01
    z[9,8,6]  R2604     1.4210730791091919e-02
    z[9,8,6]  R2605     -3.9242914319038391e-01
    z[9,8,6]  R2606     -3.7285405397415161e-01
    z[9,8,6]  R2607     0.617212176322937
    z[9,8,6]  R2608     -1.9595511257648468e-02
    z[9,8,6]  R2609     -2.1142356097698212e-01
    z[9,8,6]  R2610     -6.3874870538711548e-02
    z[9,8,6]  R2611     3.8014820218086243e-01
    z[9,8,6]  R2612     2.6594460010528564e-01
    z[9,8,6]  R2613     -2.7939301729202271e-01
    z[9,8,6]  R2614     7.2171583771705627e-02
    z[9,8,6]  R2615     -1.7181229591369629e-01
    z[9,8,6]  R2616     -3.5775211453437805e-01
    z[9,8,6]  R2617     -2.4354150891304016e-01
    z[9,8,6]  R2618     7.6739199459552765e-02
    z[9,8,6]  R2619     1.3014088571071625e-01
    z[9,8,6]  R2620     -2.3814998567104340e-01
    z[9,8,6]  R2621     1.1520184576511383e-01
    z[9,8,6]  R2622     6.7315578460693359e-02
    z[9,8,6]  R2623     -2.4576807022094727e-01
    z[9,8,6]  R2624     -0.206540048122406
    z[9,8,6]  R2625     -5.5418390035629272e-01
    z[9,8,6]  R2626     -2.1993513405323029e-01
    z[9,8,6]  R2627     2.0152269303798676e-01
    z[9,8,6]  R2628     -1.5294280648231506e-01
    z[9,8,6]  R2629     -2.2544318437576294e-01
    z[9,8,6]  R2630     -9.2782024294137955e-03
    z[9,8,6]  R2631     -3.6410698294639587e-01
    z[9,8,6]  R2632     -9.8761796951293945e-02
    z[9,8,6]  R2633     5.3759759664535522e-01
    z[9,8,6]  R2634     -9.5262423157691956e-02
    z[9,8,6]  R2635     6.5266633033752441e-01
    z[9,8,6]  R2636     4.7035521268844604e-01
    z[9,8,6]  R2637     4.8429798334836960e-02
    z[9,8,6]  R2638     -1.7260447144508362e-02
    z[9,8,6]  R2639     -2.0662035793066025e-02
    z[9,8,6]  R2640     2.9811248183250427e-01
    z[9,8,6]  R2641     -2.7274868916720152e-03
    z[9,8,6]  R2642     -4.4423291087150574e-01
    z[9,8,6]  R2643     8.1322342157363892e-02
    z[9,8,6]  R2644     -2.0091181993484497e-01
    z[9,8,6]  R2645     3.0219249427318573e-02
    z[9,8,6]  R2646     1.4600034058094025e-01
    z[9,8,6]  R2647     -6.8772301077842712e-02
    z[9,8,6]  R2648     2.6324397325515747e-01
    z[9,8,6]  R2649     -2.4828876554965973e-01
    z[9,8,6]  R2650     1.3578110933303833e-01
    z[9,8,6]  R2651     -4.7924673557281494e-01
    z[9,8,6]  R2652     -0.513411283493042
    z[9,8,6]  R2653     -3.8489320874214172e-01
    z[9,8,6]  R2654     -0.0986989438533783
    z[9,8,6]  R2655     3.8036710023880005e-01
    z[9,8,6]  R2656     -3.4328781068325043e-02
    z[9,8,6]  R2657     -1.0835714638233185e-01
    z[9,8,6]  R2658     2.0683281123638153e-01
    z[9,8,6]  R2659     3.1815614551305771e-02
    z[9,8,6]  R2660     1.8912982940673828e-01
    z[9,8,6]  R2661     -3.9436578750610352e-01
    z[9,8,6]  R2662     -7.2801060974597931e-02
    z[9,8,6]  R2663     -1.9014558196067810e-01
    z[9,8,6]  R2664     2.1530769765377045e-01
    z[9,8,6]  R2665     8.7286166846752167e-02
    z[9,8,6]  R2666     -2.7257224917411804e-01
    z[9,8,6]  R2667     2.3130492866039276e-01
    z[9,8,6]  R2668     1.0132461041212082e-01
    z[9,8,6]  R2669     1.9825181365013123e-01
    z[9,8,6]  R2670     3.6885300278663635e-01
    z[9,8,6]  R2671     -0.0913926288485527
    z[9,8,6]  R2672     2.9600170254707336e-01
    z[9,8,6]  R2673     2.7688222005963326e-02
    z[9,8,6]  R2674     -4.8201397061347961e-02
    z[9,8,6]  R2675     1.9878593087196350e-01
    z[9,8,6]  R2676     2.0137897133827209e-01
    z[9,8,6]  R2677     1.9239969551563263e-01
    z[9,8,6]  R2678     -1.3886536657810211e-01
    z[9,8,6]  R2679     7.5013726949691772e-02
    z[9,8,6]  R2680     -2.0114743709564209e-01
    z[9,8,6]  R2681     3.1841254234313965e-01
    z[9,8,6]  R2682     -1.0493180155754089e-01
    z[9,8,6]  R2683     1.1313805729150772e-01
    z[9,8,6]  R2684     4.9736884236335754e-01
    z[9,8,6]  R2685     2.2158469259738922e-01
    z[9,8,6]  R2686     2.3445343971252441e-01
    z[9,8,6]  R2687     -5.0230240821838379e-01
    z[9,8,6]  R2688     0.261868417263031
    z[9,8,6]  R2689     -3.0893087387084961e-02
    z[9,8,6]  R2690     -5.2927918732166290e-03
    z[9,8,6]  R2691     -7.3460757732391357e-02
    z[9,8,6]  R2692     -0.201044961810112
    z[9,8,6]  R2693     -4.5461758971214294e-02
    z[9,8,6]  R2694     -1.4415824413299561e-01
    z[9,8,6]  R2695     -7.7320039272308350e-02
    z[9,8,6]  R2696     -2.7034339308738708e-01
    z[9,8,6]  R2697     0.0845186710357666
    z[9,8,6]  R2698     2.7805145364254713e-03
    z[9,8,6]  R2699     8.3542689681053162e-03
    z[9,8,6]  R2700     -2.8224778175354004e-01
    z[9,8,6]  R2701     1.4170059561729431e-01
    z[9,8,6]  R2702     4.2444637417793274e-01
    z[9,8,6]  R2703     3.5754811763763428e-01
    z[9,8,6]  R2704     5.6581471115350723e-02
    z[9,8,6]  R2705     -1.1086313426494598e-01
    z[9,8,6]  R2706     2.4395607411861420e-02
    z[9,8,6]  R2707     0.0748407393693924
    z[9,8,6]  R2708     -1.0414259135723114e-01
    z[9,8,6]  R2709     -4.4331338256597519e-02
    z[9,8,6]  R2710     3.3066761493682861e-01
    z[9,8,6]  R2711     -1.3299232721328735e-01
    z[9,8,6]  R2712     -1.5949106216430664e-01
    z[9,8,6]  R2713     -3.6813411116600037e-01
    z[9,8,6]  R2714     -3.6560556292533875e-01
    z[9,8,6]  R2715     -2.1807946264743805e-01
    z[9,8,6]  R2716     -3.5904118418693542e-01
    z[9,8,6]  R2717     5.0126284360885620e-01
    z[9,8,6]  R2718     -9.4208948314189911e-02
    z[9,8,6]  R2719     1.6494569182395935e-01
    z[9,8,6]  R2720     -1.3512144982814789e-01
    z[9,8,6]  R2721     -2.5242233276367188e-01
    z[9,8,6]  R2722     -4.4038379192352295e-01
    z[9,8,6]  R2723     1.2994153797626495e-01
    z[9,8,6]  R2724     1.3858821988105774e-01
    z[9,8,6]  R2725     1.2574154138565063e-01
    z[9,8,6]  R2726     1.4876842498779297e-02
    z[9,8,6]  R2727     -0.138673335313797
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R90       1
    RHS1      R91       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[10,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,8]
 BV BND1      phi[8,2]
 BV BND1      phi[2,9]
 BV BND1      phi[9,2]
 BV BND1      phi[2,11]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[10,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,11]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,8,0]
 FR BND1      z[2,8,1]
 FR BND1      z[2,8,2]
 FR BND1      z[2,8,3]
 FR BND1      z[2,8,4]
 FR BND1      z[2,8,5]
 FR BND1      z[2,8,6]
 FR BND1      z[8,2,0]
 FR BND1      z[8,2,1]
 FR BND1      z[8,2,2]
 FR BND1      z[8,2,3]
 FR BND1      z[8,2,4]
 FR BND1      z[8,2,5]
 FR BND1      z[8,2,6]
 FR BND1      z[2,9,0]
 FR BND1      z[2,9,1]
 FR BND1      z[2,9,2]
 FR BND1      z[2,9,3]
 FR BND1      z[2,9,4]
 FR BND1      z[2,9,5]
 FR BND1      z[2,9,6]
 FR BND1      z[9,2,0]
 FR BND1      z[9,2,1]
 FR BND1      z[9,2,2]
 FR BND1      z[9,2,3]
 FR BND1      z[9,2,4]
 FR BND1      z[9,2,5]
 FR BND1      z[9,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
ENDATA
