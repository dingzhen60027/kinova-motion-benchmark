NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -3.0999999046325684e+00
    phi[0,1]  R67       -2.2400000095367432e+00
    phi[0,1]  R68       -2.2400000095367432e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0999999046325684e+00
    phi[0,1]  R71       -2.5699999332427979e+00
    phi[0,1]  R72       -2.5699999332427979e+00
    phi[0,1]  R73       -3.0999999046325684e+00
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -2.0899999141693115e+00
    phi[0,1]  R76       -2.0899999141693115e+00
    phi[0,1]  R77       -3.0999999046325684e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       8.7840473651885986e-01
    phi[0,1]  R80       0.783260703086853
    phi[0,1]  R81       4.8817035555839539e-01
    phi[0,1]  R82       0.776328980922699
    phi[0,1]  R83       0.699201226234436
    phi[0,1]  R84       2.0405015945434570e+00
    phi[0,1]  R85       -1.5406283140182495e+00
    phi[0,1]  R86       -4.4540229439735413e-01
    phi[0,1]  R87       -1.1281495094299316e+00
    phi[0,1]  R88       -9.7329777479171753e-01
    phi[0,1]  R89       -1.7022237777709961e+00
    phi[0,1]  R90       -1.3846265077590942e+00
    phi[0,1]  R91       -2.6494035720825195e+00
    phi[0,1]  R92       -2.5338296890258789e+00
    phi[0,1]  R93       -2.2643523216247559e+00
    phi[0,1]  R94       -1.1791087388992310e+00
    phi[0,1]  R95       -8.7078946828842163e-01
    phi[0,1]  R96       -1.5259582996368408e+00
    phi[0,1]  R97       -1.1882147789001465e+00
    phi[0,1]  R98       -1.5377256870269775e+00
    phi[0,1]  R99       -2.9596942663192749e-01
    phi[0,1]  R100      -1.9427398443222046e+00
    phi[0,1]  R101      -1.1719689369201660e+00
    phi[0,1]  R102      -2.4589700698852539e+00
    phi[0,1]  R103      -1.5682832002639771e+00
    phi[0,1]  R104      -2.3374817371368408e+00
    phi[0,1]  R105      -9.0173596143722534e-01
    phi[0,1]  R106      -2.59667706489563
    phi[0,1]  R107      -8.4568995237350464e-01
    phi[0,1]  R108      -1.4351571798324585e+00
    phi[0,1]  R109      -1.0014551877975464e+00
    phi[0,1]  R110      -1.7354429960250854e+00
    phi[0,1]  R111      -8.1746423244476318e-01
    phi[0,1]  R112      -4.9246555566787720e-01
    phi[0,1]  R113      -9.5471024513244629e-01
    phi[0,1]  R114      -9.6287351846694946e-01
    phi[0,1]  R115      -2.1618366241455078e+00
    phi[0,1]  R116      -1.8801978826522827e+00
    phi[0,1]  R117      -2.2057211399078369e+00
    phi[0,1]  R118      -1.3484262228012085e+00
    phi[0,1]  R119      -1.7104336023330688e+00
    phi[0,1]  R120      -1.0084670782089233e+00
    phi[0,1]  R121      -1.6274725198745728e+00
    phi[0,1]  R122      -1.46377432346344
    phi[0,1]  R123      -1.4120930433273315e+00
    phi[0,1]  R124      -1.7198575735092163e+00
    phi[0,1]  R125      -1.4491840600967407e+00
    phi[0,1]  R126      -2.6039719581604004e+00
    phi[0,1]  R127      -1.3155206441879272e+00
    phi[0,1]  R128      -1.4334880113601685e+00
    phi[0,1]  R129      -1.1303063631057739e+00
    phi[0,1]  R130      -6.3134700059890747e-01
    phi[0,1]  R131      6.7325621843338013e-02
    phi[0,1]  R132      -1.3836517333984375e+00
    phi[0,1]  R133      -0.254042387008667
    phi[0,1]  R134      1.2097810506820679e+00
    phi[0,1]  R135      8.1906884908676147e-01
    phi[0,1]  R136      0.46077761054039
    phi[0,1]  R137      5.0619572401046753e-01
    phi[0,1]  R138      8.0361002683639526e-01
    phi[0,1]  R139      -2.3117508888244629e+00
    phi[0,1]  R140      -1.2184497117996216e+00
    phi[0,1]  R141      -7.7469551563262939e-01
    phi[0,1]  R142      -1.1844878196716309e+00
    phi[0,1]  R143      -1.5023105144500732e+00
    phi[0,1]  R144      -8.7362980842590332e-01
    phi[0,1]  R145      -2.7594611644744873e+00
    phi[0,1]  R146      -2.3393862247467041e+00
    phi[0,1]  R147      -7.2982954978942871e-01
    phi[0,1]  R148      -9.6188437938690186e-01
    phi[0,1]  R149      -1.8871104717254639e+00
    phi[0,1]  R150      2.8309831023216248e-01
    phi[0,1]  R151      2.6891720294952393e-01
    phi[0,1]  R152      5.3327775001525879e-01
    phi[0,1]  R153      -1.1115978658199310e-01
    phi[0,1]  R154      -5.8229851722717285e-01
    phi[0,1]  R155      -7.1007555723190308e-01
    phi[0,1]  R156      -3.3839082717895508e+00
    phi[0,1]  R157      -1.7192379236221313e+00
    phi[0,1]  R158      1.3804934024810791e+00
    phi[0,1]  R159      -0.318979948759079
    phi[0,1]  R160      -6.7665541172027588e-01
    phi[0,1]  R161      -2.4272031784057617e+00
    phi[0,1]  R162      -1.0015165805816650e+00
    phi[0,1]  R163      -8.0165904760360718e-01
    phi[0,1]  R164      1.7757655382156372e+00
    phi[0,1]  R165      -1.2809131145477295e+00
    phi[0,1]  R166      1.1830326318740845e+00
    phi[0,1]  R167      -0.814696729183197
    phi[0,1]  R168      1.6288137435913086e+00
    phi[0,1]  R169      -2.2790367603302
    phi[0,1]  R170      -2.1206333637237549e+00
    phi[0,1]  R171      1.0642091035842896e+00
    phi[0,1]  R172      -5.3938972949981689e-01
    phi[0,1]  R173      4.1915929317474365e-01
    phi[0,1]  R174      8.9000397920608521e-01
    phi[0,1]  R175      -3.7336080074310303e+00
    phi[0,1]  R176      1.7407737970352173e+00
    phi[0,1]  R177      -4.5078825950622559e+00
    phi[0,1]  R178      -8.2309186458587646e-01
    phi[0,1]  R179      -1.90565824508667
    phi[0,1]  R180      -9.3902751803398132e-02
    phi[0,1]  R181      -1.4781479835510254e+00
    phi[0,1]  R182      1.4731713533401489e+00
    phi[0,1]  R183      -1.2382079362869263e+00
    phi[0,1]  R184      -1.2756564617156982e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R185      -3.0999999046325684e+00
    phi[1,0]  R186      -3.0999999046325684e+00
    phi[1,0]  R187      -2.2400000095367432e+00
    phi[1,0]  R188      -2.2400000095367432e+00
    phi[1,0]  R189      -3.0999999046325684e+00
    phi[1,0]  R190      -3.0999999046325684e+00
    phi[1,0]  R191      -2.5699999332427979e+00
    phi[1,0]  R192      -2.5699999332427979e+00
    phi[1,0]  R193      -3.0999999046325684e+00
    phi[1,0]  R194      -3.0999999046325684e+00
    phi[1,0]  R195      -2.0899999141693115e+00
    phi[1,0]  R196      -2.0899999141693115e+00
    phi[1,0]  R197      -3.0999999046325684e+00
    phi[1,0]  R198      -3.0999999046325684e+00
    phi[1,0]  R199      -1.1303063631057739e+00
    phi[1,0]  R200      -6.3134700059890747e-01
    phi[1,0]  R201      6.7325621843338013e-02
    phi[1,0]  R202      -1.3836517333984375e+00
    phi[1,0]  R203      -0.254042387008667
    phi[1,0]  R204      1.2097810506820679e+00
    phi[1,0]  R205      8.1906884908676147e-01
    phi[1,0]  R206      0.46077761054039
    phi[1,0]  R207      5.0619572401046753e-01
    phi[1,0]  R208      8.0361002683639526e-01
    phi[1,0]  R209      -2.3117508888244629e+00
    phi[1,0]  R210      -1.2184497117996216e+00
    phi[1,0]  R211      -7.7469551563262939e-01
    phi[1,0]  R212      -1.1844878196716309e+00
    phi[1,0]  R213      -1.5023105144500732e+00
    phi[1,0]  R214      -8.7362980842590332e-01
    phi[1,0]  R215      -2.7594611644744873e+00
    phi[1,0]  R216      -2.3393862247467041e+00
    phi[1,0]  R217      -7.2982954978942871e-01
    phi[1,0]  R218      -9.6188437938690186e-01
    phi[1,0]  R219      -1.8871104717254639e+00
    phi[1,0]  R220      2.8309831023216248e-01
    phi[1,0]  R221      2.6891720294952393e-01
    phi[1,0]  R222      5.3327775001525879e-01
    phi[1,0]  R223      -1.1115978658199310e-01
    phi[1,0]  R224      -5.8229851722717285e-01
    phi[1,0]  R225      -7.1007555723190308e-01
    phi[1,0]  R226      -3.3839082717895508e+00
    phi[1,0]  R227      -1.7192379236221313e+00
    phi[1,0]  R228      1.3804934024810791e+00
    phi[1,0]  R229      -0.318979948759079
    phi[1,0]  R230      -6.7665541172027588e-01
    phi[1,0]  R231      -2.4272031784057617e+00
    phi[1,0]  R232      -1.0015165805816650e+00
    phi[1,0]  R233      -8.0165904760360718e-01
    phi[1,0]  R234      1.7757655382156372e+00
    phi[1,0]  R235      -1.2809131145477295e+00
    phi[1,0]  R236      1.1830326318740845e+00
    phi[1,0]  R237      -0.814696729183197
    phi[1,0]  R238      1.6288137435913086e+00
    phi[1,0]  R239      -2.2790367603302
    phi[1,0]  R240      -2.1206333637237549e+00
    phi[1,0]  R241      1.0642091035842896e+00
    phi[1,0]  R242      -5.3938972949981689e-01
    phi[1,0]  R243      4.1915929317474365e-01
    phi[1,0]  R244      8.9000397920608521e-01
    phi[1,0]  R245      -3.7336080074310303e+00
    phi[1,0]  R246      1.7407737970352173e+00
    phi[1,0]  R247      -4.5078825950622559e+00
    phi[1,0]  R248      -8.2309186458587646e-01
    phi[1,0]  R249      -1.90565824508667
    phi[1,0]  R250      -9.3902751803398132e-02
    phi[1,0]  R251      -1.4781479835510254e+00
    phi[1,0]  R252      1.4731713533401489e+00
    phi[1,0]  R253      -1.2382079362869263e+00
    phi[1,0]  R254      -1.2756564617156982e+00
    phi[1,0]  R255      8.7840473651885986e-01
    phi[1,0]  R256      0.783260703086853
    phi[1,0]  R257      4.8817035555839539e-01
    phi[1,0]  R258      0.776328980922699
    phi[1,0]  R259      0.699201226234436
    phi[1,0]  R260      2.0405015945434570e+00
    phi[1,0]  R261      -1.5406283140182495e+00
    phi[1,0]  R262      -4.4540229439735413e-01
    phi[1,0]  R263      -1.1281495094299316e+00
    phi[1,0]  R264      -9.7329777479171753e-01
    phi[1,0]  R265      -1.7022237777709961e+00
    phi[1,0]  R266      -1.3846265077590942e+00
    phi[1,0]  R267      -2.6494035720825195e+00
    phi[1,0]  R268      -2.5338296890258789e+00
    phi[1,0]  R269      -2.2643523216247559e+00
    phi[1,0]  R270      -1.1791087388992310e+00
    phi[1,0]  R271      -8.7078946828842163e-01
    phi[1,0]  R272      -1.5259582996368408e+00
    phi[1,0]  R273      -1.1882147789001465e+00
    phi[1,0]  R274      -1.5377256870269775e+00
    phi[1,0]  R275      -2.9596942663192749e-01
    phi[1,0]  R276      -1.9427398443222046e+00
    phi[1,0]  R277      -1.1719689369201660e+00
    phi[1,0]  R278      -2.4589700698852539e+00
    phi[1,0]  R279      -1.5682832002639771e+00
    phi[1,0]  R280      -2.3374817371368408e+00
    phi[1,0]  R281      -9.0173596143722534e-01
    phi[1,0]  R282      -2.59667706489563
    phi[1,0]  R283      -8.4568995237350464e-01
    phi[1,0]  R284      -1.4351571798324585e+00
    phi[1,0]  R285      -1.0014551877975464e+00
    phi[1,0]  R286      -1.7354429960250854e+00
    phi[1,0]  R287      -8.1746423244476318e-01
    phi[1,0]  R288      -4.9246555566787720e-01
    phi[1,0]  R289      -9.5471024513244629e-01
    phi[1,0]  R290      -9.6287351846694946e-01
    phi[1,0]  R291      -2.1618366241455078e+00
    phi[1,0]  R292      -1.8801978826522827e+00
    phi[1,0]  R293      -2.2057211399078369e+00
    phi[1,0]  R294      -1.3484262228012085e+00
    phi[1,0]  R295      -1.7104336023330688e+00
    phi[1,0]  R296      -1.0084670782089233e+00
    phi[1,0]  R297      -1.6274725198745728e+00
    phi[1,0]  R298      -1.46377432346344
    phi[1,0]  R299      -1.4120930433273315e+00
    phi[1,0]  R300      -1.7198575735092163e+00
    phi[1,0]  R301      -1.4491840600967407e+00
    phi[1,0]  R302      -2.6039719581604004e+00
    phi[1,0]  R303      -1.3155206441879272e+00
    phi[1,0]  R304      -1.4334880113601685e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R305      -3.0999999046325684e+00
    phi[0,3]  R306      -3.0999999046325684e+00
    phi[0,3]  R307      -2.2400000095367432e+00
    phi[0,3]  R308      -2.2400000095367432e+00
    phi[0,3]  R309      -3.0999999046325684e+00
    phi[0,3]  R310      -3.0999999046325684e+00
    phi[0,3]  R311      -2.5699999332427979e+00
    phi[0,3]  R312      -2.5699999332427979e+00
    phi[0,3]  R313      -3.0999999046325684e+00
    phi[0,3]  R314      -3.0999999046325684e+00
    phi[0,3]  R315      -2.0899999141693115e+00
    phi[0,3]  R316      -2.0899999141693115e+00
    phi[0,3]  R317      -3.0999999046325684e+00
    phi[0,3]  R318      -3.0999999046325684e+00
    phi[0,3]  R319      8.7840473651885986e-01
    phi[0,3]  R320      0.783260703086853
    phi[0,3]  R321      4.8817035555839539e-01
    phi[0,3]  R322      0.776328980922699
    phi[0,3]  R323      0.699201226234436
    phi[0,3]  R324      2.0405015945434570e+00
    phi[0,3]  R325      -1.5406283140182495e+00
    phi[0,3]  R326      -4.4540229439735413e-01
    phi[0,3]  R327      -1.1281495094299316e+00
    phi[0,3]  R328      -9.7329777479171753e-01
    phi[0,3]  R329      -1.7022237777709961e+00
    phi[0,3]  R330      -1.3846265077590942e+00
    phi[0,3]  R331      -2.6494035720825195e+00
    phi[0,3]  R332      -2.5338296890258789e+00
    phi[0,3]  R333      -2.2643523216247559e+00
    phi[0,3]  R334      -1.1791087388992310e+00
    phi[0,3]  R335      -8.7078946828842163e-01
    phi[0,3]  R336      -1.5259582996368408e+00
    phi[0,3]  R337      -1.1882147789001465e+00
    phi[0,3]  R338      -1.5377256870269775e+00
    phi[0,3]  R339      -2.9596942663192749e-01
    phi[0,3]  R340      -1.9427398443222046e+00
    phi[0,3]  R341      -1.1719689369201660e+00
    phi[0,3]  R342      -2.4589700698852539e+00
    phi[0,3]  R343      -1.5682832002639771e+00
    phi[0,3]  R344      -2.3374817371368408e+00
    phi[0,3]  R345      -9.0173596143722534e-01
    phi[0,3]  R346      -2.59667706489563
    phi[0,3]  R347      -8.4568995237350464e-01
    phi[0,3]  R348      -1.4351571798324585e+00
    phi[0,3]  R349      -1.0014551877975464e+00
    phi[0,3]  R350      -1.7354429960250854e+00
    phi[0,3]  R351      -8.1746423244476318e-01
    phi[0,3]  R352      -4.9246555566787720e-01
    phi[0,3]  R353      -9.5471024513244629e-01
    phi[0,3]  R354      -9.6287351846694946e-01
    phi[0,3]  R355      -2.1618366241455078e+00
    phi[0,3]  R356      -1.8801978826522827e+00
    phi[0,3]  R357      -2.2057211399078369e+00
    phi[0,3]  R358      -1.3484262228012085e+00
    phi[0,3]  R359      -1.7104336023330688e+00
    phi[0,3]  R360      -1.0084670782089233e+00
    phi[0,3]  R361      -1.6274725198745728e+00
    phi[0,3]  R362      -1.46377432346344
    phi[0,3]  R363      -1.4120930433273315e+00
    phi[0,3]  R364      -1.7198575735092163e+00
    phi[0,3]  R365      -1.4491840600967407e+00
    phi[0,3]  R366      -2.6039719581604004e+00
    phi[0,3]  R367      -1.3155206441879272e+00
    phi[0,3]  R368      -1.4334880113601685e+00
    phi[0,3]  R369      1.6829231977462769e+00
    phi[0,3]  R370      -1.5053712129592896e+00
    phi[0,3]  R371      9.9031043052673340e-01
    phi[0,3]  R372      -5.6779032945632935e-01
    phi[0,3]  R373      1.2070429325103760e+00
    phi[0,3]  R374      4.9847790598869324e-01
    phi[0,3]  R375      8.8094002008438110e-01
    phi[0,3]  R376      1.9085167348384857e-01
    phi[0,3]  R377      -6.6627782583236694e-01
    phi[0,3]  R378      7.0998094975948334e-02
    phi[0,3]  R379      -4.8487114906311035e-01
    phi[0,3]  R380      -8.7781077623367310e-01
    phi[0,3]  R381      -1.1795622855424881e-01
    phi[0,3]  R382      -6.9913744926452637e-02
    phi[0,3]  R383      -1.4811405912041664e-02
    phi[0,3]  R384      -5.0662606954574585e-01
    phi[0,3]  R385      6.2462252378463745e-01
    phi[0,3]  R386      -3.8169956207275391e+00
    phi[0,3]  R387      -3.7428457736968994e+00
    phi[0,3]  R388      -3.1563389301300049e+00
    phi[0,3]  R389      -8.7032037973403931e-01
    phi[0,3]  R390      -2.0241081714630127e+00
    phi[0,3]  R391      -2.1939568519592285e+00
    phi[0,3]  R392      -9.2286723852157593e-01
    phi[0,3]  R393      -1.8743215799331665e+00
    phi[0,3]  R394      -1.8652489185333252e+00
    phi[0,3]  R395      -2.4508533477783203e+00
    phi[0,3]  R396      -2.1589899063110352e+00
    phi[0,3]  R397      -3.2147843837738037e+00
    phi[0,3]  R398      -1.5911586284637451e+00
    phi[0,3]  R399      -1.6579966545104980e+00
    phi[0,3]  R400      1.8122951686382294e-01
    phi[0,3]  R401      -1.7603868246078491e+00
    phi[0,3]  R402      -1.5825827121734619e+00
    phi[0,3]  R403      -1.9421851634979248e+00
    phi[0,3]  R404      -9.4935840368270874e-01
    phi[0,3]  R405      4.0470549464225769e-01
    phi[0,3]  R406      -3.6109781265258789e-01
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R407      -3.0999999046325684e+00
    phi[3,0]  R408      -3.0999999046325684e+00
    phi[3,0]  R409      -2.2400000095367432e+00
    phi[3,0]  R410      -2.2400000095367432e+00
    phi[3,0]  R411      -3.0999999046325684e+00
    phi[3,0]  R412      -3.0999999046325684e+00
    phi[3,0]  R413      -2.5699999332427979e+00
    phi[3,0]  R414      -2.5699999332427979e+00
    phi[3,0]  R415      -3.0999999046325684e+00
    phi[3,0]  R416      -3.0999999046325684e+00
    phi[3,0]  R417      -2.0899999141693115e+00
    phi[3,0]  R418      -2.0899999141693115e+00
    phi[3,0]  R419      -3.0999999046325684e+00
    phi[3,0]  R420      -3.0999999046325684e+00
    phi[3,0]  R421      1.6829231977462769e+00
    phi[3,0]  R422      -1.5053712129592896e+00
    phi[3,0]  R423      9.9031043052673340e-01
    phi[3,0]  R424      -5.6779032945632935e-01
    phi[3,0]  R425      1.2070429325103760e+00
    phi[3,0]  R426      4.9847790598869324e-01
    phi[3,0]  R427      8.8094002008438110e-01
    phi[3,0]  R428      1.9085167348384857e-01
    phi[3,0]  R429      -6.6627782583236694e-01
    phi[3,0]  R430      7.0998094975948334e-02
    phi[3,0]  R431      -4.8487114906311035e-01
    phi[3,0]  R432      -8.7781077623367310e-01
    phi[3,0]  R433      -1.1795622855424881e-01
    phi[3,0]  R434      -6.9913744926452637e-02
    phi[3,0]  R435      -1.4811405912041664e-02
    phi[3,0]  R436      -5.0662606954574585e-01
    phi[3,0]  R437      6.2462252378463745e-01
    phi[3,0]  R438      -3.8169956207275391e+00
    phi[3,0]  R439      -3.7428457736968994e+00
    phi[3,0]  R440      -3.1563389301300049e+00
    phi[3,0]  R441      -8.7032037973403931e-01
    phi[3,0]  R442      -2.0241081714630127e+00
    phi[3,0]  R443      -2.1939568519592285e+00
    phi[3,0]  R444      -9.2286723852157593e-01
    phi[3,0]  R445      -1.8743215799331665e+00
    phi[3,0]  R446      -1.8652489185333252e+00
    phi[3,0]  R447      -2.4508533477783203e+00
    phi[3,0]  R448      -2.1589899063110352e+00
    phi[3,0]  R449      -3.2147843837738037e+00
    phi[3,0]  R450      -1.5911586284637451e+00
    phi[3,0]  R451      -1.6579966545104980e+00
    phi[3,0]  R452      1.8122951686382294e-01
    phi[3,0]  R453      -1.7603868246078491e+00
    phi[3,0]  R454      -1.5825827121734619e+00
    phi[3,0]  R455      -1.9421851634979248e+00
    phi[3,0]  R456      -9.4935840368270874e-01
    phi[3,0]  R457      4.0470549464225769e-01
    phi[3,0]  R458      -3.6109781265258789e-01
    phi[3,0]  R459      8.7840473651885986e-01
    phi[3,0]  R460      0.783260703086853
    phi[3,0]  R461      4.8817035555839539e-01
    phi[3,0]  R462      0.776328980922699
    phi[3,0]  R463      0.699201226234436
    phi[3,0]  R464      2.0405015945434570e+00
    phi[3,0]  R465      -1.5406283140182495e+00
    phi[3,0]  R466      -4.4540229439735413e-01
    phi[3,0]  R467      -1.1281495094299316e+00
    phi[3,0]  R468      -9.7329777479171753e-01
    phi[3,0]  R469      -1.7022237777709961e+00
    phi[3,0]  R470      -1.3846265077590942e+00
    phi[3,0]  R471      -2.6494035720825195e+00
    phi[3,0]  R472      -2.5338296890258789e+00
    phi[3,0]  R473      -2.2643523216247559e+00
    phi[3,0]  R474      -1.1791087388992310e+00
    phi[3,0]  R475      -8.7078946828842163e-01
    phi[3,0]  R476      -1.5259582996368408e+00
    phi[3,0]  R477      -1.1882147789001465e+00
    phi[3,0]  R478      -1.5377256870269775e+00
    phi[3,0]  R479      -2.9596942663192749e-01
    phi[3,0]  R480      -1.9427398443222046e+00
    phi[3,0]  R481      -1.1719689369201660e+00
    phi[3,0]  R482      -2.4589700698852539e+00
    phi[3,0]  R483      -1.5682832002639771e+00
    phi[3,0]  R484      -2.3374817371368408e+00
    phi[3,0]  R485      -9.0173596143722534e-01
    phi[3,0]  R486      -2.59667706489563
    phi[3,0]  R487      -8.4568995237350464e-01
    phi[3,0]  R488      -1.4351571798324585e+00
    phi[3,0]  R489      -1.0014551877975464e+00
    phi[3,0]  R490      -1.7354429960250854e+00
    phi[3,0]  R491      -8.1746423244476318e-01
    phi[3,0]  R492      -4.9246555566787720e-01
    phi[3,0]  R493      -9.5471024513244629e-01
    phi[3,0]  R494      -9.6287351846694946e-01
    phi[3,0]  R495      -2.1618366241455078e+00
    phi[3,0]  R496      -1.8801978826522827e+00
    phi[3,0]  R497      -2.2057211399078369e+00
    phi[3,0]  R498      -1.3484262228012085e+00
    phi[3,0]  R499      -1.7104336023330688e+00
    phi[3,0]  R500      -1.0084670782089233e+00
    phi[3,0]  R501      -1.6274725198745728e+00
    phi[3,0]  R502      -1.46377432346344
    phi[3,0]  R503      -1.4120930433273315e+00
    phi[3,0]  R504      -1.7198575735092163e+00
    phi[3,0]  R505      -1.4491840600967407e+00
    phi[3,0]  R506      -2.6039719581604004e+00
    phi[3,0]  R507      -1.3155206441879272e+00
    phi[3,0]  R508      -1.4334880113601685e+00
    phi[7,0]  R0        -1
    phi[7,0]  R2        -1.2390059515445182e+00
    phi[7,0]  R3        -1.2106165893173257e+00
    phi[7,0]  R4        1.8316182031440387e+00
    phi[7,0]  R5        -3.4264801752042828e-01
    phi[7,0]  R6        2.0970027805179234e+00
    phi[7,0]  R7        1.9819876604862823e+00
    phi[7,0]  R8        1.1948196548939838e+00
    phi[7,0]  R63       1
    phi[7,0]  R509      -1.8609939530880502e+00
    phi[7,0]  R510      -4.3390058561770868e+00
    phi[7,0]  R511      -1.0293834202194174e+00
    phi[7,0]  R512      -3.4506165988540687e+00
    phi[7,0]  R513      -4.9316181077766075e+00
    phi[7,0]  R514      -1.2683817014885297e+00
    phi[7,0]  R515      -2.2273519157223696e+00
    phi[7,0]  R516      -2.9126479507632261e+00
    phi[7,0]  R517      -5.1970026851504922e+00
    phi[7,0]  R518      -1.0029971241146449e+00
    phi[7,0]  R519      -4.0719875746555942e+00
    phi[7,0]  R520      -1.0801225368302925e-01
    phi[7,0]  R521      -4.2948195595265517e+00
    phi[7,0]  R522      -1.9051802497385846e+00
    phi[7,0]  R523      -1.6946417248209333e-02
    phi[7,0]  R524      -1.9452519067654883e-02
    phi[7,0]  R525      -7.7650333658636161e-02
    phi[7,0]  R526      -1.0371352643728482e-01
    phi[7,0]  R527      -1.0912944230886423e-01
    phi[7,0]  R528      -1.4226935116214889e-01
    phi[7,0]  R529      -1.5773049340369805e+00
    phi[7,0]  R530      -1.9495880453843677e+00
    phi[7,0]  R531      -2.1100856291883616e+00
    phi[7,0]  R532      -1.0820105026148976e+00
    phi[7,0]  R533      -2.5395903908506168e-01
    phi[7,0]  R534      -2.8875383134557531e-01
    phi[7,0]  R535      -2.9640689926538588e-01
    phi[7,0]  R536      -3.8925660032732790e-01
    phi[7,0]  R537      -1.6664810360286721e+00
    phi[7,0]  R538      -1.1152180357910639e+00
    phi[7,0]  R539      -7.3285228129252422e-01
    phi[7,0]  R540      -1.2904708060652250e+00
    phi[7,0]  R541      -7.1053629219584913e-01
    phi[7,0]  R542      -0.726201051430341
    phi[7,0]  R543      -3.8370264972684720e-01
    phi[7,0]  R544      -4.4836292573801950e-01
    phi[7,0]  R545      -1.8263831640575348e+00
    phi[7,0]  R546      -6.1245356299576237e-01
    phi[7,0]  R547      -6.7392165457604447e-01
    phi[7,0]  R548      -6.6933503268395866e-01
    phi[7,0]  R549      -7.0748262328905365e-01
    phi[7,0]  R550      -7.4709328880693993e-01
    phi[7,0]  R551      -1.6916218029659476e+00
    phi[7,0]  R552      -1.6120620536772794e+00
    phi[7,0]  R553      -3.4194954367849040e-01
    phi[7,0]  R554      -3.4256294582321178e-01
    phi[7,0]  R555      -3.8772184644478747e-01
    phi[7,0]  R556      -3.9300368651333878e-01
    phi[7,0]  R557      -1.1100123961825568e+00
    phi[7,0]  R558      -1.2117549069022533e+00
    phi[7,0]  R559      -7.6262793480512459e-01
    phi[7,0]  R560      -1.6169947317554532e+00
    phi[7,0]  R561      -2.1213507019988147e+00
    phi[7,0]  R562      -3.6008431122162827e+00
    phi[7,0]  R563      -2.6919990496936808e-01
    phi[7,0]  R564      -3.3457429367863079e-01
    phi[7,0]  R565      -1.0652805383722790e+00
    phi[7,0]  R566      -1.1274208349690551e+00
    phi[7,0]  R567      -1.0056088661063898e+00
    phi[7,0]  R568      -1.0289707662395435e+00
    phi[7,0]  R569      -1.0863597254596293e+00
    phi[7,0]  R570      -1.0874599290755818e+00
    phi[7,0]  R571      -1.1126454150380261e+00
    phi[7,0]  R572      -1.1183598461056075e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R573      -3.0999999046325684e+00
    phi[1,2]  R574      -3.0999999046325684e+00
    phi[1,2]  R575      -2.2400000095367432e+00
    phi[1,2]  R576      -2.2400000095367432e+00
    phi[1,2]  R577      -3.0999999046325684e+00
    phi[1,2]  R578      -3.0999999046325684e+00
    phi[1,2]  R579      -2.5699999332427979e+00
    phi[1,2]  R580      -2.5699999332427979e+00
    phi[1,2]  R581      -3.0999999046325684e+00
    phi[1,2]  R582      -3.0999999046325684e+00
    phi[1,2]  R583      -2.0899999141693115e+00
    phi[1,2]  R584      -2.0899999141693115e+00
    phi[1,2]  R585      -3.0999999046325684e+00
    phi[1,2]  R586      -3.0999999046325684e+00
    phi[1,2]  R587      -1.1303063631057739e+00
    phi[1,2]  R588      -6.3134700059890747e-01
    phi[1,2]  R589      6.7325621843338013e-02
    phi[1,2]  R590      -1.3836517333984375e+00
    phi[1,2]  R591      -0.254042387008667
    phi[1,2]  R592      1.2097810506820679e+00
    phi[1,2]  R593      8.1906884908676147e-01
    phi[1,2]  R594      0.46077761054039
    phi[1,2]  R595      5.0619572401046753e-01
    phi[1,2]  R596      8.0361002683639526e-01
    phi[1,2]  R597      -2.3117508888244629e+00
    phi[1,2]  R598      -1.2184497117996216e+00
    phi[1,2]  R599      -7.7469551563262939e-01
    phi[1,2]  R600      -1.1844878196716309e+00
    phi[1,2]  R601      -1.5023105144500732e+00
    phi[1,2]  R602      -8.7362980842590332e-01
    phi[1,2]  R603      -2.7594611644744873e+00
    phi[1,2]  R604      -2.3393862247467041e+00
    phi[1,2]  R605      -7.2982954978942871e-01
    phi[1,2]  R606      -9.6188437938690186e-01
    phi[1,2]  R607      -1.8871104717254639e+00
    phi[1,2]  R608      2.8309831023216248e-01
    phi[1,2]  R609      2.6891720294952393e-01
    phi[1,2]  R610      5.3327775001525879e-01
    phi[1,2]  R611      -1.1115978658199310e-01
    phi[1,2]  R612      -5.8229851722717285e-01
    phi[1,2]  R613      -7.1007555723190308e-01
    phi[1,2]  R614      -3.3839082717895508e+00
    phi[1,2]  R615      -1.7192379236221313e+00
    phi[1,2]  R616      1.3804934024810791e+00
    phi[1,2]  R617      -0.318979948759079
    phi[1,2]  R618      -6.7665541172027588e-01
    phi[1,2]  R619      -2.4272031784057617e+00
    phi[1,2]  R620      -1.0015165805816650e+00
    phi[1,2]  R621      -8.0165904760360718e-01
    phi[1,2]  R622      1.7757655382156372e+00
    phi[1,2]  R623      -1.2809131145477295e+00
    phi[1,2]  R624      1.1830326318740845e+00
    phi[1,2]  R625      -0.814696729183197
    phi[1,2]  R626      1.6288137435913086e+00
    phi[1,2]  R627      -2.2790367603302
    phi[1,2]  R628      -2.1206333637237549e+00
    phi[1,2]  R629      1.0642091035842896e+00
    phi[1,2]  R630      -5.3938972949981689e-01
    phi[1,2]  R631      4.1915929317474365e-01
    phi[1,2]  R632      8.9000397920608521e-01
    phi[1,2]  R633      -3.7336080074310303e+00
    phi[1,2]  R634      1.7407737970352173e+00
    phi[1,2]  R635      -4.5078825950622559e+00
    phi[1,2]  R636      -8.2309186458587646e-01
    phi[1,2]  R637      -1.90565824508667
    phi[1,2]  R638      -9.3902751803398132e-02
    phi[1,2]  R639      -1.4781479835510254e+00
    phi[1,2]  R640      1.4731713533401489e+00
    phi[1,2]  R641      -1.2382079362869263e+00
    phi[1,2]  R642      -1.2756564617156982e+00
    phi[1,2]  R643      3.4461038112640381e+00
    phi[1,2]  R644      4.9992385506629944e-01
    phi[1,2]  R645      4.5116774737834930e-02
    phi[1,2]  R646      -5.5196243524551392e-01
    phi[1,2]  R647      -4.5055025815963745e-01
    phi[1,2]  R648      -1.0857639312744141e+00
    phi[1,2]  R649      -6.7632061243057251e-01
    phi[1,2]  R650      -7.1292769908905029e-01
    phi[1,2]  R651      -1.9059193134307861e+00
    phi[1,2]  R652      1.0545358657836914e+00
    phi[1,2]  R653      1.9606584683060646e-03
    phi[1,2]  R654      -1.9717895984649658e+00
    phi[1,2]  R655      -2.3940012454986572e+00
    phi[1,2]  R656      -2.7874064445495605e+00
    phi[1,2]  R657      -1.8716061115264893e+00
    phi[1,2]  R658      4.0793079137802124e-01
    phi[1,2]  R659      -1.5426986217498779e+00
    phi[1,2]  R660      -1.24186372756958
    phi[1,2]  R661      -3.6987599730491638e-01
    phi[1,2]  R662      -1.8108935356140137e+00
    phi[1,2]  R663      -2.6380333900451660e+00
    phi[1,2]  R664      -2.1000483036041260e+00
    phi[1,2]  R665      9.4504594802856445e-02
    phi[1,2]  R666      -2.6152372360229492e-01
    phi[1,2]  R667      -1.9243885576725006e-01
    phi[1,2]  R668      -0.021955581381917
    phi[1,2]  R669      -2.5393602848052979e+00
    phi[1,2]  R670      -3.3495125770568848e+00
    phi[1,2]  R671      -3.5881495475769043e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R672      -3.0999999046325684e+00
    phi[2,1]  R673      -3.0999999046325684e+00
    phi[2,1]  R674      -2.2400000095367432e+00
    phi[2,1]  R675      -2.2400000095367432e+00
    phi[2,1]  R676      -3.0999999046325684e+00
    phi[2,1]  R677      -3.0999999046325684e+00
    phi[2,1]  R678      -2.5699999332427979e+00
    phi[2,1]  R679      -2.5699999332427979e+00
    phi[2,1]  R680      -3.0999999046325684e+00
    phi[2,1]  R681      -3.0999999046325684e+00
    phi[2,1]  R682      -2.0899999141693115e+00
    phi[2,1]  R683      -2.0899999141693115e+00
    phi[2,1]  R684      -3.0999999046325684e+00
    phi[2,1]  R685      -3.0999999046325684e+00
    phi[2,1]  R686      3.4461038112640381e+00
    phi[2,1]  R687      4.9992385506629944e-01
    phi[2,1]  R688      4.5116774737834930e-02
    phi[2,1]  R689      -5.5196243524551392e-01
    phi[2,1]  R690      -4.5055025815963745e-01
    phi[2,1]  R691      -1.0857639312744141e+00
    phi[2,1]  R692      -6.7632061243057251e-01
    phi[2,1]  R693      -7.1292769908905029e-01
    phi[2,1]  R694      -1.9059193134307861e+00
    phi[2,1]  R695      1.0545358657836914e+00
    phi[2,1]  R696      1.9606584683060646e-03
    phi[2,1]  R697      -1.9717895984649658e+00
    phi[2,1]  R698      -2.3940012454986572e+00
    phi[2,1]  R699      -2.7874064445495605e+00
    phi[2,1]  R700      -1.8716061115264893e+00
    phi[2,1]  R701      4.0793079137802124e-01
    phi[2,1]  R702      -1.5426986217498779e+00
    phi[2,1]  R703      -1.24186372756958
    phi[2,1]  R704      -3.6987599730491638e-01
    phi[2,1]  R705      -1.8108935356140137e+00
    phi[2,1]  R706      -2.6380333900451660e+00
    phi[2,1]  R707      -2.1000483036041260e+00
    phi[2,1]  R708      9.4504594802856445e-02
    phi[2,1]  R709      -2.6152372360229492e-01
    phi[2,1]  R710      -1.9243885576725006e-01
    phi[2,1]  R711      -0.021955581381917
    phi[2,1]  R712      -2.5393602848052979e+00
    phi[2,1]  R713      -3.3495125770568848e+00
    phi[2,1]  R714      -3.5881495475769043e+00
    phi[2,1]  R715      -1.1303063631057739e+00
    phi[2,1]  R716      -6.3134700059890747e-01
    phi[2,1]  R717      6.7325621843338013e-02
    phi[2,1]  R718      -1.3836517333984375e+00
    phi[2,1]  R719      -0.254042387008667
    phi[2,1]  R720      1.2097810506820679e+00
    phi[2,1]  R721      8.1906884908676147e-01
    phi[2,1]  R722      0.46077761054039
    phi[2,1]  R723      5.0619572401046753e-01
    phi[2,1]  R724      8.0361002683639526e-01
    phi[2,1]  R725      -2.3117508888244629e+00
    phi[2,1]  R726      -1.2184497117996216e+00
    phi[2,1]  R727      -7.7469551563262939e-01
    phi[2,1]  R728      -1.1844878196716309e+00
    phi[2,1]  R729      -1.5023105144500732e+00
    phi[2,1]  R730      -8.7362980842590332e-01
    phi[2,1]  R731      -2.7594611644744873e+00
    phi[2,1]  R732      -2.3393862247467041e+00
    phi[2,1]  R733      -7.2982954978942871e-01
    phi[2,1]  R734      -9.6188437938690186e-01
    phi[2,1]  R735      -1.8871104717254639e+00
    phi[2,1]  R736      2.8309831023216248e-01
    phi[2,1]  R737      2.6891720294952393e-01
    phi[2,1]  R738      5.3327775001525879e-01
    phi[2,1]  R739      -1.1115978658199310e-01
    phi[2,1]  R740      -5.8229851722717285e-01
    phi[2,1]  R741      -7.1007555723190308e-01
    phi[2,1]  R742      -3.3839082717895508e+00
    phi[2,1]  R743      -1.7192379236221313e+00
    phi[2,1]  R744      1.3804934024810791e+00
    phi[2,1]  R745      -0.318979948759079
    phi[2,1]  R746      -6.7665541172027588e-01
    phi[2,1]  R747      -2.4272031784057617e+00
    phi[2,1]  R748      -1.0015165805816650e+00
    phi[2,1]  R749      -8.0165904760360718e-01
    phi[2,1]  R750      1.7757655382156372e+00
    phi[2,1]  R751      -1.2809131145477295e+00
    phi[2,1]  R752      1.1830326318740845e+00
    phi[2,1]  R753      -0.814696729183197
    phi[2,1]  R754      1.6288137435913086e+00
    phi[2,1]  R755      -2.2790367603302
    phi[2,1]  R756      -2.1206333637237549e+00
    phi[2,1]  R757      1.0642091035842896e+00
    phi[2,1]  R758      -5.3938972949981689e-01
    phi[2,1]  R759      4.1915929317474365e-01
    phi[2,1]  R760      8.9000397920608521e-01
    phi[2,1]  R761      -3.7336080074310303e+00
    phi[2,1]  R762      1.7407737970352173e+00
    phi[2,1]  R763      -4.5078825950622559e+00
    phi[2,1]  R764      -8.2309186458587646e-01
    phi[2,1]  R765      -1.90565824508667
    phi[2,1]  R766      -9.3902751803398132e-02
    phi[2,1]  R767      -1.4781479835510254e+00
    phi[2,1]  R768      1.4731713533401489e+00
    phi[2,1]  R769      -1.2382079362869263e+00
    phi[2,1]  R770      -1.2756564617156982e+00
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R771      -3.0999999046325684e+00
    phi[1,3]  R772      -3.0999999046325684e+00
    phi[1,3]  R773      -2.2400000095367432e+00
    phi[1,3]  R774      -2.2400000095367432e+00
    phi[1,3]  R775      -3.0999999046325684e+00
    phi[1,3]  R776      -3.0999999046325684e+00
    phi[1,3]  R777      -2.5699999332427979e+00
    phi[1,3]  R778      -2.5699999332427979e+00
    phi[1,3]  R779      -3.0999999046325684e+00
    phi[1,3]  R780      -3.0999999046325684e+00
    phi[1,3]  R781      -2.0899999141693115e+00
    phi[1,3]  R782      -2.0899999141693115e+00
    phi[1,3]  R783      -3.0999999046325684e+00
    phi[1,3]  R784      -3.0999999046325684e+00
    phi[1,3]  R785      -1.1303063631057739e+00
    phi[1,3]  R786      -6.3134700059890747e-01
    phi[1,3]  R787      6.7325621843338013e-02
    phi[1,3]  R788      -1.3836517333984375e+00
    phi[1,3]  R789      -0.254042387008667
    phi[1,3]  R790      1.2097810506820679e+00
    phi[1,3]  R791      8.1906884908676147e-01
    phi[1,3]  R792      0.46077761054039
    phi[1,3]  R793      5.0619572401046753e-01
    phi[1,3]  R794      8.0361002683639526e-01
    phi[1,3]  R795      -2.3117508888244629e+00
    phi[1,3]  R796      -1.2184497117996216e+00
    phi[1,3]  R797      -7.7469551563262939e-01
    phi[1,3]  R798      -1.1844878196716309e+00
    phi[1,3]  R799      -1.5023105144500732e+00
    phi[1,3]  R800      -8.7362980842590332e-01
    phi[1,3]  R801      -2.7594611644744873e+00
    phi[1,3]  R802      -2.3393862247467041e+00
    phi[1,3]  R803      -7.2982954978942871e-01
    phi[1,3]  R804      -9.6188437938690186e-01
    phi[1,3]  R805      -1.8871104717254639e+00
    phi[1,3]  R806      2.8309831023216248e-01
    phi[1,3]  R807      2.6891720294952393e-01
    phi[1,3]  R808      5.3327775001525879e-01
    phi[1,3]  R809      -1.1115978658199310e-01
    phi[1,3]  R810      -5.8229851722717285e-01
    phi[1,3]  R811      -7.1007555723190308e-01
    phi[1,3]  R812      -3.3839082717895508e+00
    phi[1,3]  R813      -1.7192379236221313e+00
    phi[1,3]  R814      1.3804934024810791e+00
    phi[1,3]  R815      -0.318979948759079
    phi[1,3]  R816      -6.7665541172027588e-01
    phi[1,3]  R817      -2.4272031784057617e+00
    phi[1,3]  R818      -1.0015165805816650e+00
    phi[1,3]  R819      -8.0165904760360718e-01
    phi[1,3]  R820      1.7757655382156372e+00
    phi[1,3]  R821      -1.2809131145477295e+00
    phi[1,3]  R822      1.1830326318740845e+00
    phi[1,3]  R823      -0.814696729183197
    phi[1,3]  R824      1.6288137435913086e+00
    phi[1,3]  R825      -2.2790367603302
    phi[1,3]  R826      -2.1206333637237549e+00
    phi[1,3]  R827      1.0642091035842896e+00
    phi[1,3]  R828      -5.3938972949981689e-01
    phi[1,3]  R829      4.1915929317474365e-01
    phi[1,3]  R830      8.9000397920608521e-01
    phi[1,3]  R831      -3.7336080074310303e+00
    phi[1,3]  R832      1.7407737970352173e+00
    phi[1,3]  R833      -4.5078825950622559e+00
    phi[1,3]  R834      -8.2309186458587646e-01
    phi[1,3]  R835      -1.90565824508667
    phi[1,3]  R836      -9.3902751803398132e-02
    phi[1,3]  R837      -1.4781479835510254e+00
    phi[1,3]  R838      1.4731713533401489e+00
    phi[1,3]  R839      -1.2382079362869263e+00
    phi[1,3]  R840      -1.2756564617156982e+00
    phi[1,3]  R841      1.6829231977462769e+00
    phi[1,3]  R842      -1.5053712129592896e+00
    phi[1,3]  R843      9.9031043052673340e-01
    phi[1,3]  R844      -5.6779032945632935e-01
    phi[1,3]  R845      1.2070429325103760e+00
    phi[1,3]  R846      4.9847790598869324e-01
    phi[1,3]  R847      8.8094002008438110e-01
    phi[1,3]  R848      1.9085167348384857e-01
    phi[1,3]  R849      -6.6627782583236694e-01
    phi[1,3]  R850      7.0998094975948334e-02
    phi[1,3]  R851      -4.8487114906311035e-01
    phi[1,3]  R852      -8.7781077623367310e-01
    phi[1,3]  R853      -1.1795622855424881e-01
    phi[1,3]  R854      -6.9913744926452637e-02
    phi[1,3]  R855      -1.4811405912041664e-02
    phi[1,3]  R856      -5.0662606954574585e-01
    phi[1,3]  R857      6.2462252378463745e-01
    phi[1,3]  R858      -3.8169956207275391e+00
    phi[1,3]  R859      -3.7428457736968994e+00
    phi[1,3]  R860      -3.1563389301300049e+00
    phi[1,3]  R861      -8.7032037973403931e-01
    phi[1,3]  R862      -2.0241081714630127e+00
    phi[1,3]  R863      -2.1939568519592285e+00
    phi[1,3]  R864      -9.2286723852157593e-01
    phi[1,3]  R865      -1.8743215799331665e+00
    phi[1,3]  R866      -1.8652489185333252e+00
    phi[1,3]  R867      -2.4508533477783203e+00
    phi[1,3]  R868      -2.1589899063110352e+00
    phi[1,3]  R869      -3.2147843837738037e+00
    phi[1,3]  R870      -1.5911586284637451e+00
    phi[1,3]  R871      -1.6579966545104980e+00
    phi[1,3]  R872      1.8122951686382294e-01
    phi[1,3]  R873      -1.7603868246078491e+00
    phi[1,3]  R874      -1.5825827121734619e+00
    phi[1,3]  R875      -1.9421851634979248e+00
    phi[1,3]  R876      -9.4935840368270874e-01
    phi[1,3]  R877      4.0470549464225769e-01
    phi[1,3]  R878      -3.6109781265258789e-01
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R879      -3.0999999046325684e+00
    phi[3,1]  R880      -3.0999999046325684e+00
    phi[3,1]  R881      -2.2400000095367432e+00
    phi[3,1]  R882      -2.2400000095367432e+00
    phi[3,1]  R883      -3.0999999046325684e+00
    phi[3,1]  R884      -3.0999999046325684e+00
    phi[3,1]  R885      -2.5699999332427979e+00
    phi[3,1]  R886      -2.5699999332427979e+00
    phi[3,1]  R887      -3.0999999046325684e+00
    phi[3,1]  R888      -3.0999999046325684e+00
    phi[3,1]  R889      -2.0899999141693115e+00
    phi[3,1]  R890      -2.0899999141693115e+00
    phi[3,1]  R891      -3.0999999046325684e+00
    phi[3,1]  R892      -3.0999999046325684e+00
    phi[3,1]  R893      1.6829231977462769e+00
    phi[3,1]  R894      -1.5053712129592896e+00
    phi[3,1]  R895      9.9031043052673340e-01
    phi[3,1]  R896      -5.6779032945632935e-01
    phi[3,1]  R897      1.2070429325103760e+00
    phi[3,1]  R898      4.9847790598869324e-01
    phi[3,1]  R899      8.8094002008438110e-01
    phi[3,1]  R900      1.9085167348384857e-01
    phi[3,1]  R901      -6.6627782583236694e-01
    phi[3,1]  R902      7.0998094975948334e-02
    phi[3,1]  R903      -4.8487114906311035e-01
    phi[3,1]  R904      -8.7781077623367310e-01
    phi[3,1]  R905      -1.1795622855424881e-01
    phi[3,1]  R906      -6.9913744926452637e-02
    phi[3,1]  R907      -1.4811405912041664e-02
    phi[3,1]  R908      -5.0662606954574585e-01
    phi[3,1]  R909      6.2462252378463745e-01
    phi[3,1]  R910      -3.8169956207275391e+00
    phi[3,1]  R911      -3.7428457736968994e+00
    phi[3,1]  R912      -3.1563389301300049e+00
    phi[3,1]  R913      -8.7032037973403931e-01
    phi[3,1]  R914      -2.0241081714630127e+00
    phi[3,1]  R915      -2.1939568519592285e+00
    phi[3,1]  R916      -9.2286723852157593e-01
    phi[3,1]  R917      -1.8743215799331665e+00
    phi[3,1]  R918      -1.8652489185333252e+00
    phi[3,1]  R919      -2.4508533477783203e+00
    phi[3,1]  R920      -2.1589899063110352e+00
    phi[3,1]  R921      -3.2147843837738037e+00
    phi[3,1]  R922      -1.5911586284637451e+00
    phi[3,1]  R923      -1.6579966545104980e+00
    phi[3,1]  R924      1.8122951686382294e-01
    phi[3,1]  R925      -1.7603868246078491e+00
    phi[3,1]  R926      -1.5825827121734619e+00
    phi[3,1]  R927      -1.9421851634979248e+00
    phi[3,1]  R928      -9.4935840368270874e-01
    phi[3,1]  R929      4.0470549464225769e-01
    phi[3,1]  R930      -3.6109781265258789e-01
    phi[3,1]  R931      -1.1303063631057739e+00
    phi[3,1]  R932      -6.3134700059890747e-01
    phi[3,1]  R933      6.7325621843338013e-02
    phi[3,1]  R934      -1.3836517333984375e+00
    phi[3,1]  R935      -0.254042387008667
    phi[3,1]  R936      1.2097810506820679e+00
    phi[3,1]  R937      8.1906884908676147e-01
    phi[3,1]  R938      0.46077761054039
    phi[3,1]  R939      5.0619572401046753e-01
    phi[3,1]  R940      8.0361002683639526e-01
    phi[3,1]  R941      -2.3117508888244629e+00
    phi[3,1]  R942      -1.2184497117996216e+00
    phi[3,1]  R943      -7.7469551563262939e-01
    phi[3,1]  R944      -1.1844878196716309e+00
    phi[3,1]  R945      -1.5023105144500732e+00
    phi[3,1]  R946      -8.7362980842590332e-01
    phi[3,1]  R947      -2.7594611644744873e+00
    phi[3,1]  R948      -2.3393862247467041e+00
    phi[3,1]  R949      -7.2982954978942871e-01
    phi[3,1]  R950      -9.6188437938690186e-01
    phi[3,1]  R951      -1.8871104717254639e+00
    phi[3,1]  R952      2.8309831023216248e-01
    phi[3,1]  R953      2.6891720294952393e-01
    phi[3,1]  R954      5.3327775001525879e-01
    phi[3,1]  R955      -1.1115978658199310e-01
    phi[3,1]  R956      -5.8229851722717285e-01
    phi[3,1]  R957      -7.1007555723190308e-01
    phi[3,1]  R958      -3.3839082717895508e+00
    phi[3,1]  R959      -1.7192379236221313e+00
    phi[3,1]  R960      1.3804934024810791e+00
    phi[3,1]  R961      -0.318979948759079
    phi[3,1]  R962      -6.7665541172027588e-01
    phi[3,1]  R963      -2.4272031784057617e+00
    phi[3,1]  R964      -1.0015165805816650e+00
    phi[3,1]  R965      -8.0165904760360718e-01
    phi[3,1]  R966      1.7757655382156372e+00
    phi[3,1]  R967      -1.2809131145477295e+00
    phi[3,1]  R968      1.1830326318740845e+00
    phi[3,1]  R969      -0.814696729183197
    phi[3,1]  R970      1.6288137435913086e+00
    phi[3,1]  R971      -2.2790367603302
    phi[3,1]  R972      -2.1206333637237549e+00
    phi[3,1]  R973      1.0642091035842896e+00
    phi[3,1]  R974      -5.3938972949981689e-01
    phi[3,1]  R975      4.1915929317474365e-01
    phi[3,1]  R976      8.9000397920608521e-01
    phi[3,1]  R977      -3.7336080074310303e+00
    phi[3,1]  R978      1.7407737970352173e+00
    phi[3,1]  R979      -4.5078825950622559e+00
    phi[3,1]  R980      -8.2309186458587646e-01
    phi[3,1]  R981      -1.90565824508667
    phi[3,1]  R982      -9.3902751803398132e-02
    phi[3,1]  R983      -1.4781479835510254e+00
    phi[3,1]  R984      1.4731713533401489e+00
    phi[3,1]  R985      -1.2382079362869263e+00
    phi[3,1]  R986      -1.2756564617156982e+00
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R987      -3.0999999046325684e+00
    phi[1,4]  R988      -3.0999999046325684e+00
    phi[1,4]  R989      -2.2400000095367432e+00
    phi[1,4]  R990      -2.2400000095367432e+00
    phi[1,4]  R991      -3.0999999046325684e+00
    phi[1,4]  R992      -3.0999999046325684e+00
    phi[1,4]  R993      -2.5699999332427979e+00
    phi[1,4]  R994      -2.5699999332427979e+00
    phi[1,4]  R995      -3.0999999046325684e+00
    phi[1,4]  R996      -3.0999999046325684e+00
    phi[1,4]  R997      -2.0899999141693115e+00
    phi[1,4]  R998      -2.0899999141693115e+00
    phi[1,4]  R999      -3.0999999046325684e+00
    phi[1,4]  R1000     -3.0999999046325684e+00
    phi[1,4]  R1001     -1.1303063631057739e+00
    phi[1,4]  R1002     -6.3134700059890747e-01
    phi[1,4]  R1003     6.7325621843338013e-02
    phi[1,4]  R1004     -1.3836517333984375e+00
    phi[1,4]  R1005     -0.254042387008667
    phi[1,4]  R1006     1.2097810506820679e+00
    phi[1,4]  R1007     8.1906884908676147e-01
    phi[1,4]  R1008     0.46077761054039
    phi[1,4]  R1009     5.0619572401046753e-01
    phi[1,4]  R1010     8.0361002683639526e-01
    phi[1,4]  R1011     -2.3117508888244629e+00
    phi[1,4]  R1012     -1.2184497117996216e+00
    phi[1,4]  R1013     -7.7469551563262939e-01
    phi[1,4]  R1014     -1.1844878196716309e+00
    phi[1,4]  R1015     -1.5023105144500732e+00
    phi[1,4]  R1016     -8.7362980842590332e-01
    phi[1,4]  R1017     -2.7594611644744873e+00
    phi[1,4]  R1018     -2.3393862247467041e+00
    phi[1,4]  R1019     -7.2982954978942871e-01
    phi[1,4]  R1020     -9.6188437938690186e-01
    phi[1,4]  R1021     -1.8871104717254639e+00
    phi[1,4]  R1022     2.8309831023216248e-01
    phi[1,4]  R1023     2.6891720294952393e-01
    phi[1,4]  R1024     5.3327775001525879e-01
    phi[1,4]  R1025     -1.1115978658199310e-01
    phi[1,4]  R1026     -5.8229851722717285e-01
    phi[1,4]  R1027     -7.1007555723190308e-01
    phi[1,4]  R1028     -3.3839082717895508e+00
    phi[1,4]  R1029     -1.7192379236221313e+00
    phi[1,4]  R1030     1.3804934024810791e+00
    phi[1,4]  R1031     -0.318979948759079
    phi[1,4]  R1032     -6.7665541172027588e-01
    phi[1,4]  R1033     -2.4272031784057617e+00
    phi[1,4]  R1034     -1.0015165805816650e+00
    phi[1,4]  R1035     -8.0165904760360718e-01
    phi[1,4]  R1036     1.7757655382156372e+00
    phi[1,4]  R1037     -1.2809131145477295e+00
    phi[1,4]  R1038     1.1830326318740845e+00
    phi[1,4]  R1039     -0.814696729183197
    phi[1,4]  R1040     1.6288137435913086e+00
    phi[1,4]  R1041     -2.2790367603302
    phi[1,4]  R1042     -2.1206333637237549e+00
    phi[1,4]  R1043     1.0642091035842896e+00
    phi[1,4]  R1044     -5.3938972949981689e-01
    phi[1,4]  R1045     4.1915929317474365e-01
    phi[1,4]  R1046     8.9000397920608521e-01
    phi[1,4]  R1047     -3.7336080074310303e+00
    phi[1,4]  R1048     1.7407737970352173e+00
    phi[1,4]  R1049     -4.5078825950622559e+00
    phi[1,4]  R1050     -8.2309186458587646e-01
    phi[1,4]  R1051     -1.90565824508667
    phi[1,4]  R1052     -9.3902751803398132e-02
    phi[1,4]  R1053     -1.4781479835510254e+00
    phi[1,4]  R1054     1.4731713533401489e+00
    phi[1,4]  R1055     -1.2382079362869263e+00
    phi[1,4]  R1056     -1.2756564617156982e+00
    phi[1,4]  R1057     -1.9696003198623657e-01
    phi[1,4]  R1058     -9.3212914466857910e-01
    phi[1,4]  R1059     1.0913379192352295e+00
    phi[1,4]  R1060     1.1782114505767822e+00
    phi[1,4]  R1061     4.3235847353935242e-01
    phi[1,4]  R1062     2.1700556278228760e+00
    phi[1,4]  R1063     1.5522381067276
    phi[1,4]  R1064     -7.2675958275794983e-02
    phi[1,4]  R1065     5.5075001716613770e-01
    phi[1,4]  R1066     8.3547115325927734e-01
    phi[1,4]  R1067     -2.1702699661254883e+00
    phi[1,4]  R1068     -1.6632767915725708e+00
    phi[1,4]  R1069     -1.8399087190628052e+00
    phi[1,4]  R1070     -1.4419515132904053e+00
    phi[1,4]  R1071     -1.2011263370513916e+00
    phi[1,4]  R1072     0.277835488319397
    phi[1,4]  R1073     -2.97823166847229
    phi[1,4]  R1074     -3.3856742382049561e+00
    phi[1,4]  R1075     -1.5511336326599121e+00
    phi[1,4]  R1076     -5.4516983032226562e-01
    phi[1,4]  R1077     -1.8415642976760864e+00
    phi[1,4]  R1078     -2.3212623596191406e+00
    phi[1,4]  R1079     -2.0684318542480469e+00
    phi[1,4]  R1080     -2.5935132503509521e+00
    phi[1,4]  R1081     -1.5212699174880981e+00
    phi[1,4]  R1082     7.2242164611816406e-01
    phi[1,4]  R1083     0.906074583530426
    phi[1,4]  R1084     5.0859600305557251e-01
    phi[1,4]  R1085     9.5689713954925537e-01
    phi[1,4]  R1086     -1.7233482003211975e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1087     -3.0999999046325684e+00
    phi[4,1]  R1088     -3.0999999046325684e+00
    phi[4,1]  R1089     -2.2400000095367432e+00
    phi[4,1]  R1090     -2.2400000095367432e+00
    phi[4,1]  R1091     -3.0999999046325684e+00
    phi[4,1]  R1092     -3.0999999046325684e+00
    phi[4,1]  R1093     -2.5699999332427979e+00
    phi[4,1]  R1094     -2.5699999332427979e+00
    phi[4,1]  R1095     -3.0999999046325684e+00
    phi[4,1]  R1096     -3.0999999046325684e+00
    phi[4,1]  R1097     -2.0899999141693115e+00
    phi[4,1]  R1098     -2.0899999141693115e+00
    phi[4,1]  R1099     -3.0999999046325684e+00
    phi[4,1]  R1100     -3.0999999046325684e+00
    phi[4,1]  R1101     -1.9696003198623657e-01
    phi[4,1]  R1102     -9.3212914466857910e-01
    phi[4,1]  R1103     1.0913379192352295e+00
    phi[4,1]  R1104     1.1782114505767822e+00
    phi[4,1]  R1105     4.3235847353935242e-01
    phi[4,1]  R1106     2.1700556278228760e+00
    phi[4,1]  R1107     1.5522381067276
    phi[4,1]  R1108     -7.2675958275794983e-02
    phi[4,1]  R1109     5.5075001716613770e-01
    phi[4,1]  R1110     8.3547115325927734e-01
    phi[4,1]  R1111     -2.1702699661254883e+00
    phi[4,1]  R1112     -1.6632767915725708e+00
    phi[4,1]  R1113     -1.8399087190628052e+00
    phi[4,1]  R1114     -1.4419515132904053e+00
    phi[4,1]  R1115     -1.2011263370513916e+00
    phi[4,1]  R1116     0.277835488319397
    phi[4,1]  R1117     -2.97823166847229
    phi[4,1]  R1118     -3.3856742382049561e+00
    phi[4,1]  R1119     -1.5511336326599121e+00
    phi[4,1]  R1120     -5.4516983032226562e-01
    phi[4,1]  R1121     -1.8415642976760864e+00
    phi[4,1]  R1122     -2.3212623596191406e+00
    phi[4,1]  R1123     -2.0684318542480469e+00
    phi[4,1]  R1124     -2.5935132503509521e+00
    phi[4,1]  R1125     -1.5212699174880981e+00
    phi[4,1]  R1126     7.2242164611816406e-01
    phi[4,1]  R1127     0.906074583530426
    phi[4,1]  R1128     5.0859600305557251e-01
    phi[4,1]  R1129     9.5689713954925537e-01
    phi[4,1]  R1130     -1.7233482003211975e-01
    phi[4,1]  R1131     -1.1303063631057739e+00
    phi[4,1]  R1132     -6.3134700059890747e-01
    phi[4,1]  R1133     6.7325621843338013e-02
    phi[4,1]  R1134     -1.3836517333984375e+00
    phi[4,1]  R1135     -0.254042387008667
    phi[4,1]  R1136     1.2097810506820679e+00
    phi[4,1]  R1137     8.1906884908676147e-01
    phi[4,1]  R1138     0.46077761054039
    phi[4,1]  R1139     5.0619572401046753e-01
    phi[4,1]  R1140     8.0361002683639526e-01
    phi[4,1]  R1141     -2.3117508888244629e+00
    phi[4,1]  R1142     -1.2184497117996216e+00
    phi[4,1]  R1143     -7.7469551563262939e-01
    phi[4,1]  R1144     -1.1844878196716309e+00
    phi[4,1]  R1145     -1.5023105144500732e+00
    phi[4,1]  R1146     -8.7362980842590332e-01
    phi[4,1]  R1147     -2.7594611644744873e+00
    phi[4,1]  R1148     -2.3393862247467041e+00
    phi[4,1]  R1149     -7.2982954978942871e-01
    phi[4,1]  R1150     -9.6188437938690186e-01
    phi[4,1]  R1151     -1.8871104717254639e+00
    phi[4,1]  R1152     2.8309831023216248e-01
    phi[4,1]  R1153     2.6891720294952393e-01
    phi[4,1]  R1154     5.3327775001525879e-01
    phi[4,1]  R1155     -1.1115978658199310e-01
    phi[4,1]  R1156     -5.8229851722717285e-01
    phi[4,1]  R1157     -7.1007555723190308e-01
    phi[4,1]  R1158     -3.3839082717895508e+00
    phi[4,1]  R1159     -1.7192379236221313e+00
    phi[4,1]  R1160     1.3804934024810791e+00
    phi[4,1]  R1161     -0.318979948759079
    phi[4,1]  R1162     -6.7665541172027588e-01
    phi[4,1]  R1163     -2.4272031784057617e+00
    phi[4,1]  R1164     -1.0015165805816650e+00
    phi[4,1]  R1165     -8.0165904760360718e-01
    phi[4,1]  R1166     1.7757655382156372e+00
    phi[4,1]  R1167     -1.2809131145477295e+00
    phi[4,1]  R1168     1.1830326318740845e+00
    phi[4,1]  R1169     -0.814696729183197
    phi[4,1]  R1170     1.6288137435913086e+00
    phi[4,1]  R1171     -2.2790367603302
    phi[4,1]  R1172     -2.1206333637237549e+00
    phi[4,1]  R1173     1.0642091035842896e+00
    phi[4,1]  R1174     -5.3938972949981689e-01
    phi[4,1]  R1175     4.1915929317474365e-01
    phi[4,1]  R1176     8.9000397920608521e-01
    phi[4,1]  R1177     -3.7336080074310303e+00
    phi[4,1]  R1178     1.7407737970352173e+00
    phi[4,1]  R1179     -4.5078825950622559e+00
    phi[4,1]  R1180     -8.2309186458587646e-01
    phi[4,1]  R1181     -1.90565824508667
    phi[4,1]  R1182     -9.3902751803398132e-02
    phi[4,1]  R1183     -1.4781479835510254e+00
    phi[4,1]  R1184     1.4731713533401489e+00
    phi[4,1]  R1185     -1.2382079362869263e+00
    phi[4,1]  R1186     -1.2756564617156982e+00
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R1187     -3.0999999046325684e+00
    phi[1,5]  R1188     -3.0999999046325684e+00
    phi[1,5]  R1189     -2.2400000095367432e+00
    phi[1,5]  R1190     -2.2400000095367432e+00
    phi[1,5]  R1191     -3.0999999046325684e+00
    phi[1,5]  R1192     -3.0999999046325684e+00
    phi[1,5]  R1193     -2.5699999332427979e+00
    phi[1,5]  R1194     -2.5699999332427979e+00
    phi[1,5]  R1195     -3.0999999046325684e+00
    phi[1,5]  R1196     -3.0999999046325684e+00
    phi[1,5]  R1197     -2.0899999141693115e+00
    phi[1,5]  R1198     -2.0899999141693115e+00
    phi[1,5]  R1199     -3.0999999046325684e+00
    phi[1,5]  R1200     -3.0999999046325684e+00
    phi[1,5]  R1201     -1.1303063631057739e+00
    phi[1,5]  R1202     -6.3134700059890747e-01
    phi[1,5]  R1203     6.7325621843338013e-02
    phi[1,5]  R1204     -1.3836517333984375e+00
    phi[1,5]  R1205     -0.254042387008667
    phi[1,5]  R1206     1.2097810506820679e+00
    phi[1,5]  R1207     8.1906884908676147e-01
    phi[1,5]  R1208     0.46077761054039
    phi[1,5]  R1209     5.0619572401046753e-01
    phi[1,5]  R1210     8.0361002683639526e-01
    phi[1,5]  R1211     -2.3117508888244629e+00
    phi[1,5]  R1212     -1.2184497117996216e+00
    phi[1,5]  R1213     -7.7469551563262939e-01
    phi[1,5]  R1214     -1.1844878196716309e+00
    phi[1,5]  R1215     -1.5023105144500732e+00
    phi[1,5]  R1216     -8.7362980842590332e-01
    phi[1,5]  R1217     -2.7594611644744873e+00
    phi[1,5]  R1218     -2.3393862247467041e+00
    phi[1,5]  R1219     -7.2982954978942871e-01
    phi[1,5]  R1220     -9.6188437938690186e-01
    phi[1,5]  R1221     -1.8871104717254639e+00
    phi[1,5]  R1222     2.8309831023216248e-01
    phi[1,5]  R1223     2.6891720294952393e-01
    phi[1,5]  R1224     5.3327775001525879e-01
    phi[1,5]  R1225     -1.1115978658199310e-01
    phi[1,5]  R1226     -5.8229851722717285e-01
    phi[1,5]  R1227     -7.1007555723190308e-01
    phi[1,5]  R1228     -3.3839082717895508e+00
    phi[1,5]  R1229     -1.7192379236221313e+00
    phi[1,5]  R1230     1.3804934024810791e+00
    phi[1,5]  R1231     -0.318979948759079
    phi[1,5]  R1232     -6.7665541172027588e-01
    phi[1,5]  R1233     -2.4272031784057617e+00
    phi[1,5]  R1234     -1.0015165805816650e+00
    phi[1,5]  R1235     -8.0165904760360718e-01
    phi[1,5]  R1236     1.7757655382156372e+00
    phi[1,5]  R1237     -1.2809131145477295e+00
    phi[1,5]  R1238     1.1830326318740845e+00
    phi[1,5]  R1239     -0.814696729183197
    phi[1,5]  R1240     1.6288137435913086e+00
    phi[1,5]  R1241     -2.2790367603302
    phi[1,5]  R1242     -2.1206333637237549e+00
    phi[1,5]  R1243     1.0642091035842896e+00
    phi[1,5]  R1244     -5.3938972949981689e-01
    phi[1,5]  R1245     4.1915929317474365e-01
    phi[1,5]  R1246     8.9000397920608521e-01
    phi[1,5]  R1247     -3.7336080074310303e+00
    phi[1,5]  R1248     1.7407737970352173e+00
    phi[1,5]  R1249     -4.5078825950622559e+00
    phi[1,5]  R1250     -8.2309186458587646e-01
    phi[1,5]  R1251     -1.90565824508667
    phi[1,5]  R1252     -9.3902751803398132e-02
    phi[1,5]  R1253     -1.4781479835510254e+00
    phi[1,5]  R1254     1.4731713533401489e+00
    phi[1,5]  R1255     -1.2382079362869263e+00
    phi[1,5]  R1256     -1.2756564617156982e+00
    phi[1,5]  R1257     -6.3640981912612915e-01
    phi[1,5]  R1258     2.5880272388458252e+00
    phi[1,5]  R1259     2.6231596469879150e+00
    phi[1,5]  R1260     2.6645054817199707e+00
    phi[1,5]  R1261     2.7784593105316162e+00
    phi[1,5]  R1262     3.0919108390808105e+00
    phi[1,5]  R1263     2.3366715908050537e+00
    phi[1,5]  R1264     1.6047230958938599e+00
    phi[1,5]  R1265     2.8079228401184082e+00
    phi[1,5]  R1266     3.2592887878417969e+00
    phi[1,5]  R1267     -2.1449103355407715e+00
    phi[1,5]  R1268     -3.2058589458465576e+00
    phi[1,5]  R1269     -2.3394837379455566e+00
    phi[1,5]  R1270     -5.7962024211883545e-01
    phi[1,5]  R1271     -1.6185268163681030e+00
    phi[1,5]  R1272     -6.3051402568817139e-01
    phi[1,5]  R1273     -1.2105958461761475e+00
    phi[1,5]  R1274     -2.6354799270629883e+00
    phi[1,5]  R1275     -1.2961137294769287e-01
    phi[1,5]  R1276     -1.93434476852417
    phi[1,5]  R1277     -0.0989639163017273
    phi[1,5]  R1278     -7.5165349245071411e-01
    phi[1,5]  R1279     -8.8103270530700684e-01
    phi[1,5]  R1280     -8.5376471281051636e-02
    phi[1,5]  R1281     -1.1561900377273560e+00
    phi[1,5]  R1282     9.0916119515895844e-02
    phi[1,5]  R1283     -9.1831809282302856e-01
    phi[1,5]  R1284     -9.7034519910812378e-01
    phi[1,5]  R1285     -5.7880836725234985e-01
    phi[1,5]  R1286     -2.5016114711761475e+00
    phi[1,5]  R1287     1.3049411773681641e+00
    phi[1,5]  R1288     6.1048889160156250e-01
    phi[1,5]  R1289     -1.7441697120666504e+00
    phi[1,5]  R1290     -1.1380017995834351e+00
    phi[1,5]  R1291     -2.9301264882087708e-01
    phi[1,5]  R1292     -5.2002954483032227e-01
    phi[1,5]  R1293     -8.3248722553253174e-01
    phi[1,5]  R1294     -8.2074439525604248e-01
    phi[1,5]  R1295     2.1347159147262573e-01
    phi[1,5]  R1296     -5.6308156251907349e-01
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1297     -3.0999999046325684e+00
    phi[5,1]  R1298     -3.0999999046325684e+00
    phi[5,1]  R1299     -2.2400000095367432e+00
    phi[5,1]  R1300     -2.2400000095367432e+00
    phi[5,1]  R1301     -3.0999999046325684e+00
    phi[5,1]  R1302     -3.0999999046325684e+00
    phi[5,1]  R1303     -2.5699999332427979e+00
    phi[5,1]  R1304     -2.5699999332427979e+00
    phi[5,1]  R1305     -3.0999999046325684e+00
    phi[5,1]  R1306     -3.0999999046325684e+00
    phi[5,1]  R1307     -2.0899999141693115e+00
    phi[5,1]  R1308     -2.0899999141693115e+00
    phi[5,1]  R1309     -3.0999999046325684e+00
    phi[5,1]  R1310     -3.0999999046325684e+00
    phi[5,1]  R1311     -6.3640981912612915e-01
    phi[5,1]  R1312     2.5880272388458252e+00
    phi[5,1]  R1313     2.6231596469879150e+00
    phi[5,1]  R1314     2.6645054817199707e+00
    phi[5,1]  R1315     2.7784593105316162e+00
    phi[5,1]  R1316     3.0919108390808105e+00
    phi[5,1]  R1317     2.3366715908050537e+00
    phi[5,1]  R1318     1.6047230958938599e+00
    phi[5,1]  R1319     2.8079228401184082e+00
    phi[5,1]  R1320     3.2592887878417969e+00
    phi[5,1]  R1321     -2.1449103355407715e+00
    phi[5,1]  R1322     -3.2058589458465576e+00
    phi[5,1]  R1323     -2.3394837379455566e+00
    phi[5,1]  R1324     -5.7962024211883545e-01
    phi[5,1]  R1325     -1.6185268163681030e+00
    phi[5,1]  R1326     -6.3051402568817139e-01
    phi[5,1]  R1327     -1.2105958461761475e+00
    phi[5,1]  R1328     -2.6354799270629883e+00
    phi[5,1]  R1329     -1.2961137294769287e-01
    phi[5,1]  R1330     -1.93434476852417
    phi[5,1]  R1331     -0.0989639163017273
    phi[5,1]  R1332     -7.5165349245071411e-01
    phi[5,1]  R1333     -8.8103270530700684e-01
    phi[5,1]  R1334     -8.5376471281051636e-02
    phi[5,1]  R1335     -1.1561900377273560e+00
    phi[5,1]  R1336     9.0916119515895844e-02
    phi[5,1]  R1337     -9.1831809282302856e-01
    phi[5,1]  R1338     -9.7034519910812378e-01
    phi[5,1]  R1339     -5.7880836725234985e-01
    phi[5,1]  R1340     -2.5016114711761475e+00
    phi[5,1]  R1341     1.3049411773681641e+00
    phi[5,1]  R1342     6.1048889160156250e-01
    phi[5,1]  R1343     -1.7441697120666504e+00
    phi[5,1]  R1344     -1.1380017995834351e+00
    phi[5,1]  R1345     -2.9301264882087708e-01
    phi[5,1]  R1346     -5.2002954483032227e-01
    phi[5,1]  R1347     -8.3248722553253174e-01
    phi[5,1]  R1348     -8.2074439525604248e-01
    phi[5,1]  R1349     2.1347159147262573e-01
    phi[5,1]  R1350     -5.6308156251907349e-01
    phi[5,1]  R1351     -1.1303063631057739e+00
    phi[5,1]  R1352     -6.3134700059890747e-01
    phi[5,1]  R1353     6.7325621843338013e-02
    phi[5,1]  R1354     -1.3836517333984375e+00
    phi[5,1]  R1355     -0.254042387008667
    phi[5,1]  R1356     1.2097810506820679e+00
    phi[5,1]  R1357     8.1906884908676147e-01
    phi[5,1]  R1358     0.46077761054039
    phi[5,1]  R1359     5.0619572401046753e-01
    phi[5,1]  R1360     8.0361002683639526e-01
    phi[5,1]  R1361     -2.3117508888244629e+00
    phi[5,1]  R1362     -1.2184497117996216e+00
    phi[5,1]  R1363     -7.7469551563262939e-01
    phi[5,1]  R1364     -1.1844878196716309e+00
    phi[5,1]  R1365     -1.5023105144500732e+00
    phi[5,1]  R1366     -8.7362980842590332e-01
    phi[5,1]  R1367     -2.7594611644744873e+00
    phi[5,1]  R1368     -2.3393862247467041e+00
    phi[5,1]  R1369     -7.2982954978942871e-01
    phi[5,1]  R1370     -9.6188437938690186e-01
    phi[5,1]  R1371     -1.8871104717254639e+00
    phi[5,1]  R1372     2.8309831023216248e-01
    phi[5,1]  R1373     2.6891720294952393e-01
    phi[5,1]  R1374     5.3327775001525879e-01
    phi[5,1]  R1375     -1.1115978658199310e-01
    phi[5,1]  R1376     -5.8229851722717285e-01
    phi[5,1]  R1377     -7.1007555723190308e-01
    phi[5,1]  R1378     -3.3839082717895508e+00
    phi[5,1]  R1379     -1.7192379236221313e+00
    phi[5,1]  R1380     1.3804934024810791e+00
    phi[5,1]  R1381     -0.318979948759079
    phi[5,1]  R1382     -6.7665541172027588e-01
    phi[5,1]  R1383     -2.4272031784057617e+00
    phi[5,1]  R1384     -1.0015165805816650e+00
    phi[5,1]  R1385     -8.0165904760360718e-01
    phi[5,1]  R1386     1.7757655382156372e+00
    phi[5,1]  R1387     -1.2809131145477295e+00
    phi[5,1]  R1388     1.1830326318740845e+00
    phi[5,1]  R1389     -0.814696729183197
    phi[5,1]  R1390     1.6288137435913086e+00
    phi[5,1]  R1391     -2.2790367603302
    phi[5,1]  R1392     -2.1206333637237549e+00
    phi[5,1]  R1393     1.0642091035842896e+00
    phi[5,1]  R1394     -5.3938972949981689e-01
    phi[5,1]  R1395     4.1915929317474365e-01
    phi[5,1]  R1396     8.9000397920608521e-01
    phi[5,1]  R1397     -3.7336080074310303e+00
    phi[5,1]  R1398     1.7407737970352173e+00
    phi[5,1]  R1399     -4.5078825950622559e+00
    phi[5,1]  R1400     -8.2309186458587646e-01
    phi[5,1]  R1401     -1.90565824508667
    phi[5,1]  R1402     -9.3902751803398132e-02
    phi[5,1]  R1403     -1.4781479835510254e+00
    phi[5,1]  R1404     1.4731713533401489e+00
    phi[5,1]  R1405     -1.2382079362869263e+00
    phi[5,1]  R1406     -1.2756564617156982e+00
    phi[2,4]  R18       1
    phi[2,4]  R19       1
    phi[2,4]  R36       -1
    phi[2,4]  R1407     -3.0999999046325684e+00
    phi[2,4]  R1408     -3.0999999046325684e+00
    phi[2,4]  R1409     -2.2400000095367432e+00
    phi[2,4]  R1410     -2.2400000095367432e+00
    phi[2,4]  R1411     -3.0999999046325684e+00
    phi[2,4]  R1412     -3.0999999046325684e+00
    phi[2,4]  R1413     -2.5699999332427979e+00
    phi[2,4]  R1414     -2.5699999332427979e+00
    phi[2,4]  R1415     -3.0999999046325684e+00
    phi[2,4]  R1416     -3.0999999046325684e+00
    phi[2,4]  R1417     -2.0899999141693115e+00
    phi[2,4]  R1418     -2.0899999141693115e+00
    phi[2,4]  R1419     -3.0999999046325684e+00
    phi[2,4]  R1420     -3.0999999046325684e+00
    phi[2,4]  R1421     3.4461038112640381e+00
    phi[2,4]  R1422     4.9992385506629944e-01
    phi[2,4]  R1423     4.5116774737834930e-02
    phi[2,4]  R1424     -5.5196243524551392e-01
    phi[2,4]  R1425     -4.5055025815963745e-01
    phi[2,4]  R1426     -1.0857639312744141e+00
    phi[2,4]  R1427     -6.7632061243057251e-01
    phi[2,4]  R1428     -7.1292769908905029e-01
    phi[2,4]  R1429     -1.9059193134307861e+00
    phi[2,4]  R1430     1.0545358657836914e+00
    phi[2,4]  R1431     1.9606584683060646e-03
    phi[2,4]  R1432     -1.9717895984649658e+00
    phi[2,4]  R1433     -2.3940012454986572e+00
    phi[2,4]  R1434     -2.7874064445495605e+00
    phi[2,4]  R1435     -1.8716061115264893e+00
    phi[2,4]  R1436     4.0793079137802124e-01
    phi[2,4]  R1437     -1.5426986217498779e+00
    phi[2,4]  R1438     -1.24186372756958
    phi[2,4]  R1439     -3.6987599730491638e-01
    phi[2,4]  R1440     -1.8108935356140137e+00
    phi[2,4]  R1441     -2.6380333900451660e+00
    phi[2,4]  R1442     -2.1000483036041260e+00
    phi[2,4]  R1443     9.4504594802856445e-02
    phi[2,4]  R1444     -2.6152372360229492e-01
    phi[2,4]  R1445     -1.9243885576725006e-01
    phi[2,4]  R1446     -0.021955581381917
    phi[2,4]  R1447     -2.5393602848052979e+00
    phi[2,4]  R1448     -3.3495125770568848e+00
    phi[2,4]  R1449     -3.5881495475769043e+00
    phi[2,4]  R1450     -1.9696003198623657e-01
    phi[2,4]  R1451     -9.3212914466857910e-01
    phi[2,4]  R1452     1.0913379192352295e+00
    phi[2,4]  R1453     1.1782114505767822e+00
    phi[2,4]  R1454     4.3235847353935242e-01
    phi[2,4]  R1455     2.1700556278228760e+00
    phi[2,4]  R1456     1.5522381067276
    phi[2,4]  R1457     -7.2675958275794983e-02
    phi[2,4]  R1458     5.5075001716613770e-01
    phi[2,4]  R1459     8.3547115325927734e-01
    phi[2,4]  R1460     -2.1702699661254883e+00
    phi[2,4]  R1461     -1.6632767915725708e+00
    phi[2,4]  R1462     -1.8399087190628052e+00
    phi[2,4]  R1463     -1.4419515132904053e+00
    phi[2,4]  R1464     -1.2011263370513916e+00
    phi[2,4]  R1465     0.277835488319397
    phi[2,4]  R1466     -2.97823166847229
    phi[2,4]  R1467     -3.3856742382049561e+00
    phi[2,4]  R1468     -1.5511336326599121e+00
    phi[2,4]  R1469     -5.4516983032226562e-01
    phi[2,4]  R1470     -1.8415642976760864e+00
    phi[2,4]  R1471     -2.3212623596191406e+00
    phi[2,4]  R1472     -2.0684318542480469e+00
    phi[2,4]  R1473     -2.5935132503509521e+00
    phi[2,4]  R1474     -1.5212699174880981e+00
    phi[2,4]  R1475     7.2242164611816406e-01
    phi[2,4]  R1476     0.906074583530426
    phi[2,4]  R1477     5.0859600305557251e-01
    phi[2,4]  R1478     9.5689713954925537e-01
    phi[2,4]  R1479     -1.7233482003211975e-01
    phi[4,2]  R18       -1
    phi[4,2]  R36       1
    phi[4,2]  R37       1
    phi[4,2]  R1480     -3.0999999046325684e+00
    phi[4,2]  R1481     -3.0999999046325684e+00
    phi[4,2]  R1482     -2.2400000095367432e+00
    phi[4,2]  R1483     -2.2400000095367432e+00
    phi[4,2]  R1484     -3.0999999046325684e+00
    phi[4,2]  R1485     -3.0999999046325684e+00
    phi[4,2]  R1486     -2.5699999332427979e+00
    phi[4,2]  R1487     -2.5699999332427979e+00
    phi[4,2]  R1488     -3.0999999046325684e+00
    phi[4,2]  R1489     -3.0999999046325684e+00
    phi[4,2]  R1490     -2.0899999141693115e+00
    phi[4,2]  R1491     -2.0899999141693115e+00
    phi[4,2]  R1492     -3.0999999046325684e+00
    phi[4,2]  R1493     -3.0999999046325684e+00
    phi[4,2]  R1494     -1.9696003198623657e-01
    phi[4,2]  R1495     -9.3212914466857910e-01
    phi[4,2]  R1496     1.0913379192352295e+00
    phi[4,2]  R1497     1.1782114505767822e+00
    phi[4,2]  R1498     4.3235847353935242e-01
    phi[4,2]  R1499     2.1700556278228760e+00
    phi[4,2]  R1500     1.5522381067276
    phi[4,2]  R1501     -7.2675958275794983e-02
    phi[4,2]  R1502     5.5075001716613770e-01
    phi[4,2]  R1503     8.3547115325927734e-01
    phi[4,2]  R1504     -2.1702699661254883e+00
    phi[4,2]  R1505     -1.6632767915725708e+00
    phi[4,2]  R1506     -1.8399087190628052e+00
    phi[4,2]  R1507     -1.4419515132904053e+00
    phi[4,2]  R1508     -1.2011263370513916e+00
    phi[4,2]  R1509     0.277835488319397
    phi[4,2]  R1510     -2.97823166847229
    phi[4,2]  R1511     -3.3856742382049561e+00
    phi[4,2]  R1512     -1.5511336326599121e+00
    phi[4,2]  R1513     -5.4516983032226562e-01
    phi[4,2]  R1514     -1.8415642976760864e+00
    phi[4,2]  R1515     -2.3212623596191406e+00
    phi[4,2]  R1516     -2.0684318542480469e+00
    phi[4,2]  R1517     -2.5935132503509521e+00
    phi[4,2]  R1518     -1.5212699174880981e+00
    phi[4,2]  R1519     7.2242164611816406e-01
    phi[4,2]  R1520     0.906074583530426
    phi[4,2]  R1521     5.0859600305557251e-01
    phi[4,2]  R1522     9.5689713954925537e-01
    phi[4,2]  R1523     -1.7233482003211975e-01
    phi[4,2]  R1524     3.4461038112640381e+00
    phi[4,2]  R1525     4.9992385506629944e-01
    phi[4,2]  R1526     4.5116774737834930e-02
    phi[4,2]  R1527     -5.5196243524551392e-01
    phi[4,2]  R1528     -4.5055025815963745e-01
    phi[4,2]  R1529     -1.0857639312744141e+00
    phi[4,2]  R1530     -6.7632061243057251e-01
    phi[4,2]  R1531     -7.1292769908905029e-01
    phi[4,2]  R1532     -1.9059193134307861e+00
    phi[4,2]  R1533     1.0545358657836914e+00
    phi[4,2]  R1534     1.9606584683060646e-03
    phi[4,2]  R1535     -1.9717895984649658e+00
    phi[4,2]  R1536     -2.3940012454986572e+00
    phi[4,2]  R1537     -2.7874064445495605e+00
    phi[4,2]  R1538     -1.8716061115264893e+00
    phi[4,2]  R1539     4.0793079137802124e-01
    phi[4,2]  R1540     -1.5426986217498779e+00
    phi[4,2]  R1541     -1.24186372756958
    phi[4,2]  R1542     -3.6987599730491638e-01
    phi[4,2]  R1543     -1.8108935356140137e+00
    phi[4,2]  R1544     -2.6380333900451660e+00
    phi[4,2]  R1545     -2.1000483036041260e+00
    phi[4,2]  R1546     9.4504594802856445e-02
    phi[4,2]  R1547     -2.6152372360229492e-01
    phi[4,2]  R1548     -1.9243885576725006e-01
    phi[4,2]  R1549     -0.021955581381917
    phi[4,2]  R1550     -2.5393602848052979e+00
    phi[4,2]  R1551     -3.3495125770568848e+00
    phi[4,2]  R1552     -3.5881495475769043e+00
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1553     -3.0999999046325684e+00
    phi[2,5]  R1554     -3.0999999046325684e+00
    phi[2,5]  R1555     -2.2400000095367432e+00
    phi[2,5]  R1556     -2.2400000095367432e+00
    phi[2,5]  R1557     -3.0999999046325684e+00
    phi[2,5]  R1558     -3.0999999046325684e+00
    phi[2,5]  R1559     -2.5699999332427979e+00
    phi[2,5]  R1560     -2.5699999332427979e+00
    phi[2,5]  R1561     -3.0999999046325684e+00
    phi[2,5]  R1562     -3.0999999046325684e+00
    phi[2,5]  R1563     -2.0899999141693115e+00
    phi[2,5]  R1564     -2.0899999141693115e+00
    phi[2,5]  R1565     -3.0999999046325684e+00
    phi[2,5]  R1566     -3.0999999046325684e+00
    phi[2,5]  R1567     3.4461038112640381e+00
    phi[2,5]  R1568     4.9992385506629944e-01
    phi[2,5]  R1569     4.5116774737834930e-02
    phi[2,5]  R1570     -5.5196243524551392e-01
    phi[2,5]  R1571     -4.5055025815963745e-01
    phi[2,5]  R1572     -1.0857639312744141e+00
    phi[2,5]  R1573     -6.7632061243057251e-01
    phi[2,5]  R1574     -7.1292769908905029e-01
    phi[2,5]  R1575     -1.9059193134307861e+00
    phi[2,5]  R1576     1.0545358657836914e+00
    phi[2,5]  R1577     1.9606584683060646e-03
    phi[2,5]  R1578     -1.9717895984649658e+00
    phi[2,5]  R1579     -2.3940012454986572e+00
    phi[2,5]  R1580     -2.7874064445495605e+00
    phi[2,5]  R1581     -1.8716061115264893e+00
    phi[2,5]  R1582     4.0793079137802124e-01
    phi[2,5]  R1583     -1.5426986217498779e+00
    phi[2,5]  R1584     -1.24186372756958
    phi[2,5]  R1585     -3.6987599730491638e-01
    phi[2,5]  R1586     -1.8108935356140137e+00
    phi[2,5]  R1587     -2.6380333900451660e+00
    phi[2,5]  R1588     -2.1000483036041260e+00
    phi[2,5]  R1589     9.4504594802856445e-02
    phi[2,5]  R1590     -2.6152372360229492e-01
    phi[2,5]  R1591     -1.9243885576725006e-01
    phi[2,5]  R1592     -0.021955581381917
    phi[2,5]  R1593     -2.5393602848052979e+00
    phi[2,5]  R1594     -3.3495125770568848e+00
    phi[2,5]  R1595     -3.5881495475769043e+00
    phi[2,5]  R1596     -6.3640981912612915e-01
    phi[2,5]  R1597     2.5880272388458252e+00
    phi[2,5]  R1598     2.6231596469879150e+00
    phi[2,5]  R1599     2.6645054817199707e+00
    phi[2,5]  R1600     2.7784593105316162e+00
    phi[2,5]  R1601     3.0919108390808105e+00
    phi[2,5]  R1602     2.3366715908050537e+00
    phi[2,5]  R1603     1.6047230958938599e+00
    phi[2,5]  R1604     2.8079228401184082e+00
    phi[2,5]  R1605     3.2592887878417969e+00
    phi[2,5]  R1606     -2.1449103355407715e+00
    phi[2,5]  R1607     -3.2058589458465576e+00
    phi[2,5]  R1608     -2.3394837379455566e+00
    phi[2,5]  R1609     -5.7962024211883545e-01
    phi[2,5]  R1610     -1.6185268163681030e+00
    phi[2,5]  R1611     -6.3051402568817139e-01
    phi[2,5]  R1612     -1.2105958461761475e+00
    phi[2,5]  R1613     -2.6354799270629883e+00
    phi[2,5]  R1614     -1.2961137294769287e-01
    phi[2,5]  R1615     -1.93434476852417
    phi[2,5]  R1616     -0.0989639163017273
    phi[2,5]  R1617     -7.5165349245071411e-01
    phi[2,5]  R1618     -8.8103270530700684e-01
    phi[2,5]  R1619     -8.5376471281051636e-02
    phi[2,5]  R1620     -1.1561900377273560e+00
    phi[2,5]  R1621     9.0916119515895844e-02
    phi[2,5]  R1622     -9.1831809282302856e-01
    phi[2,5]  R1623     -9.7034519910812378e-01
    phi[2,5]  R1624     -5.7880836725234985e-01
    phi[2,5]  R1625     -2.5016114711761475e+00
    phi[2,5]  R1626     1.3049411773681641e+00
    phi[2,5]  R1627     6.1048889160156250e-01
    phi[2,5]  R1628     -1.7441697120666504e+00
    phi[2,5]  R1629     -1.1380017995834351e+00
    phi[2,5]  R1630     -2.9301264882087708e-01
    phi[2,5]  R1631     -5.2002954483032227e-01
    phi[2,5]  R1632     -8.3248722553253174e-01
    phi[2,5]  R1633     -8.2074439525604248e-01
    phi[2,5]  R1634     2.1347159147262573e-01
    phi[2,5]  R1635     -5.6308156251907349e-01
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1636     -3.0999999046325684e+00
    phi[5,2]  R1637     -3.0999999046325684e+00
    phi[5,2]  R1638     -2.2400000095367432e+00
    phi[5,2]  R1639     -2.2400000095367432e+00
    phi[5,2]  R1640     -3.0999999046325684e+00
    phi[5,2]  R1641     -3.0999999046325684e+00
    phi[5,2]  R1642     -2.5699999332427979e+00
    phi[5,2]  R1643     -2.5699999332427979e+00
    phi[5,2]  R1644     -3.0999999046325684e+00
    phi[5,2]  R1645     -3.0999999046325684e+00
    phi[5,2]  R1646     -2.0899999141693115e+00
    phi[5,2]  R1647     -2.0899999141693115e+00
    phi[5,2]  R1648     -3.0999999046325684e+00
    phi[5,2]  R1649     -3.0999999046325684e+00
    phi[5,2]  R1650     -6.3640981912612915e-01
    phi[5,2]  R1651     2.5880272388458252e+00
    phi[5,2]  R1652     2.6231596469879150e+00
    phi[5,2]  R1653     2.6645054817199707e+00
    phi[5,2]  R1654     2.7784593105316162e+00
    phi[5,2]  R1655     3.0919108390808105e+00
    phi[5,2]  R1656     2.3366715908050537e+00
    phi[5,2]  R1657     1.6047230958938599e+00
    phi[5,2]  R1658     2.8079228401184082e+00
    phi[5,2]  R1659     3.2592887878417969e+00
    phi[5,2]  R1660     -2.1449103355407715e+00
    phi[5,2]  R1661     -3.2058589458465576e+00
    phi[5,2]  R1662     -2.3394837379455566e+00
    phi[5,2]  R1663     -5.7962024211883545e-01
    phi[5,2]  R1664     -1.6185268163681030e+00
    phi[5,2]  R1665     -6.3051402568817139e-01
    phi[5,2]  R1666     -1.2105958461761475e+00
    phi[5,2]  R1667     -2.6354799270629883e+00
    phi[5,2]  R1668     -1.2961137294769287e-01
    phi[5,2]  R1669     -1.93434476852417
    phi[5,2]  R1670     -0.0989639163017273
    phi[5,2]  R1671     -7.5165349245071411e-01
    phi[5,2]  R1672     -8.8103270530700684e-01
    phi[5,2]  R1673     -8.5376471281051636e-02
    phi[5,2]  R1674     -1.1561900377273560e+00
    phi[5,2]  R1675     9.0916119515895844e-02
    phi[5,2]  R1676     -9.1831809282302856e-01
    phi[5,2]  R1677     -9.7034519910812378e-01
    phi[5,2]  R1678     -5.7880836725234985e-01
    phi[5,2]  R1679     -2.5016114711761475e+00
    phi[5,2]  R1680     1.3049411773681641e+00
    phi[5,2]  R1681     6.1048889160156250e-01
    phi[5,2]  R1682     -1.7441697120666504e+00
    phi[5,2]  R1683     -1.1380017995834351e+00
    phi[5,2]  R1684     -2.9301264882087708e-01
    phi[5,2]  R1685     -5.2002954483032227e-01
    phi[5,2]  R1686     -8.3248722553253174e-01
    phi[5,2]  R1687     -8.2074439525604248e-01
    phi[5,2]  R1688     2.1347159147262573e-01
    phi[5,2]  R1689     -5.6308156251907349e-01
    phi[5,2]  R1690     3.4461038112640381e+00
    phi[5,2]  R1691     4.9992385506629944e-01
    phi[5,2]  R1692     4.5116774737834930e-02
    phi[5,2]  R1693     -5.5196243524551392e-01
    phi[5,2]  R1694     -4.5055025815963745e-01
    phi[5,2]  R1695     -1.0857639312744141e+00
    phi[5,2]  R1696     -6.7632061243057251e-01
    phi[5,2]  R1697     -7.1292769908905029e-01
    phi[5,2]  R1698     -1.9059193134307861e+00
    phi[5,2]  R1699     1.0545358657836914e+00
    phi[5,2]  R1700     1.9606584683060646e-03
    phi[5,2]  R1701     -1.9717895984649658e+00
    phi[5,2]  R1702     -2.3940012454986572e+00
    phi[5,2]  R1703     -2.7874064445495605e+00
    phi[5,2]  R1704     -1.8716061115264893e+00
    phi[5,2]  R1705     4.0793079137802124e-01
    phi[5,2]  R1706     -1.5426986217498779e+00
    phi[5,2]  R1707     -1.24186372756958
    phi[5,2]  R1708     -3.6987599730491638e-01
    phi[5,2]  R1709     -1.8108935356140137e+00
    phi[5,2]  R1710     -2.6380333900451660e+00
    phi[5,2]  R1711     -2.1000483036041260e+00
    phi[5,2]  R1712     9.4504594802856445e-02
    phi[5,2]  R1713     -2.6152372360229492e-01
    phi[5,2]  R1714     -1.9243885576725006e-01
    phi[5,2]  R1715     -0.021955581381917
    phi[5,2]  R1716     -2.5393602848052979e+00
    phi[5,2]  R1717     -3.3495125770568848e+00
    phi[5,2]  R1718     -3.5881495475769043e+00
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1719     -3.0999999046325684e+00
    phi[2,6]  R1720     -3.0999999046325684e+00
    phi[2,6]  R1721     -2.2400000095367432e+00
    phi[2,6]  R1722     -2.2400000095367432e+00
    phi[2,6]  R1723     -3.0999999046325684e+00
    phi[2,6]  R1724     -3.0999999046325684e+00
    phi[2,6]  R1725     -2.5699999332427979e+00
    phi[2,6]  R1726     -2.5699999332427979e+00
    phi[2,6]  R1727     -3.0999999046325684e+00
    phi[2,6]  R1728     -3.0999999046325684e+00
    phi[2,6]  R1729     -2.0899999141693115e+00
    phi[2,6]  R1730     -2.0899999141693115e+00
    phi[2,6]  R1731     -3.0999999046325684e+00
    phi[2,6]  R1732     -3.0999999046325684e+00
    phi[2,6]  R1733     3.4461038112640381e+00
    phi[2,6]  R1734     4.9992385506629944e-01
    phi[2,6]  R1735     4.5116774737834930e-02
    phi[2,6]  R1736     -5.5196243524551392e-01
    phi[2,6]  R1737     -4.5055025815963745e-01
    phi[2,6]  R1738     -1.0857639312744141e+00
    phi[2,6]  R1739     -6.7632061243057251e-01
    phi[2,6]  R1740     -7.1292769908905029e-01
    phi[2,6]  R1741     -1.9059193134307861e+00
    phi[2,6]  R1742     1.0545358657836914e+00
    phi[2,6]  R1743     1.9606584683060646e-03
    phi[2,6]  R1744     -1.9717895984649658e+00
    phi[2,6]  R1745     -2.3940012454986572e+00
    phi[2,6]  R1746     -2.7874064445495605e+00
    phi[2,6]  R1747     -1.8716061115264893e+00
    phi[2,6]  R1748     4.0793079137802124e-01
    phi[2,6]  R1749     -1.5426986217498779e+00
    phi[2,6]  R1750     -1.24186372756958
    phi[2,6]  R1751     -3.6987599730491638e-01
    phi[2,6]  R1752     -1.8108935356140137e+00
    phi[2,6]  R1753     -2.6380333900451660e+00
    phi[2,6]  R1754     -2.1000483036041260e+00
    phi[2,6]  R1755     9.4504594802856445e-02
    phi[2,6]  R1756     -2.6152372360229492e-01
    phi[2,6]  R1757     -1.9243885576725006e-01
    phi[2,6]  R1758     -0.021955581381917
    phi[2,6]  R1759     -2.5393602848052979e+00
    phi[2,6]  R1760     -3.3495125770568848e+00
    phi[2,6]  R1761     -3.5881495475769043e+00
    phi[2,6]  R1762     3.7150695323944092e+00
    phi[2,6]  R1763     3.4160096645355225e+00
    phi[2,6]  R1764     3.2055947780609131e+00
    phi[2,6]  R1765     2.5350701808929443e+00
    phi[2,6]  R1766     1.3291240930557251e+00
    phi[2,6]  R1767     1.1946650743484497e+00
    phi[2,6]  R1768     -5.4589295387268066e-01
    phi[2,6]  R1769     1.4461125433444977e-01
    phi[2,6]  R1770     2.2654399275779724e-01
    phi[2,6]  R1771     1.0043439865112305e+00
    phi[2,6]  R1772     -1.2961395978927612e+00
    phi[2,6]  R1773     -1.9659836292266846e+00
    phi[2,6]  R1774     -1.7062138319015503e+00
    phi[2,6]  R1775     -2.1911044120788574e+00
    phi[2,6]  R1776     -2.9000551700592041e+00
    phi[2,6]  R1777     -1.6666140556335449e+00
    phi[2,6]  R1778     -1.6821141242980957e+00
    phi[2,6]  R1779     -1.8187531232833862e+00
    phi[2,6]  R1780     -3.8393962383270264e+00
    phi[2,6]  R1781     -2.0758419036865234e+00
    phi[2,6]  R1782     -1.5106359720230103e+00
    phi[2,6]  R1783     -2.5495128631591797e+00
    phi[2,6]  R1784     -2.98397159576416
    phi[2,6]  R1785     -8.6914956569671631e-01
    phi[2,6]  R1786     -3.1268823146820068e+00
    phi[2,6]  R1787     -1.12340247631073
    phi[2,6]  R1788     -9.2153137922286987e-01
    phi[2,6]  R1789     4.3196535110473633e-01
    phi[2,6]  R1790     -1.0877807140350342e+00
    phi[2,6]  R1791     -2.3510959148406982e+00
    phi[2,6]  R1792     -2.3011338710784912e+00
    phi[2,6]  R1793     -3.9914309978485107e-01
    phi[2,6]  R1794     -6.8474167585372925e-01
    phi[2,6]  R1795     -3.0490422248840332e+00
    phi[2,6]  R1796     -1.3222889900207520e+00
    phi[2,6]  R1797     -2.7262864112854004e+00
    phi[2,6]  R1798     -2.9492062330245972e-01
    phi[2,6]  R1799     -2.7539758682250977e+00
    phi[2,6]  R1800     -8.1586551666259766e-01
    phi[2,6]  R1801     -1.5702557563781738e+00
    phi[2,6]  R1802     -9.0640437602996826e-01
    phi[2,6]  R1803     -1.7569994926452637e+00
    phi[2,6]  R1804     -2.8827140331268311e+00
    phi[2,6]  R1805     -2.1204392910003662e+00
    phi[2,6]  R1806     -3.2224001884460449e+00
    phi[2,6]  R1807     -2.2973988056182861e+00
    phi[2,6]  R1808     -3.7001209259033203e+00
    phi[2,6]  R1809     -3.55043625831604
    phi[2,6]  R1810     -1.3864747285842896e+00
    phi[2,6]  R1811     1.6968119144439697e-01
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1812     -3.0999999046325684e+00
    phi[6,2]  R1813     -3.0999999046325684e+00
    phi[6,2]  R1814     -2.2400000095367432e+00
    phi[6,2]  R1815     -2.2400000095367432e+00
    phi[6,2]  R1816     -3.0999999046325684e+00
    phi[6,2]  R1817     -3.0999999046325684e+00
    phi[6,2]  R1818     -2.5699999332427979e+00
    phi[6,2]  R1819     -2.5699999332427979e+00
    phi[6,2]  R1820     -3.0999999046325684e+00
    phi[6,2]  R1821     -3.0999999046325684e+00
    phi[6,2]  R1822     -2.0899999141693115e+00
    phi[6,2]  R1823     -2.0899999141693115e+00
    phi[6,2]  R1824     -3.0999999046325684e+00
    phi[6,2]  R1825     -3.0999999046325684e+00
    phi[6,2]  R1826     3.7150695323944092e+00
    phi[6,2]  R1827     3.4160096645355225e+00
    phi[6,2]  R1828     3.2055947780609131e+00
    phi[6,2]  R1829     2.5350701808929443e+00
    phi[6,2]  R1830     1.3291240930557251e+00
    phi[6,2]  R1831     1.1946650743484497e+00
    phi[6,2]  R1832     -5.4589295387268066e-01
    phi[6,2]  R1833     1.4461125433444977e-01
    phi[6,2]  R1834     2.2654399275779724e-01
    phi[6,2]  R1835     1.0043439865112305e+00
    phi[6,2]  R1836     -1.2961395978927612e+00
    phi[6,2]  R1837     -1.9659836292266846e+00
    phi[6,2]  R1838     -1.7062138319015503e+00
    phi[6,2]  R1839     -2.1911044120788574e+00
    phi[6,2]  R1840     -2.9000551700592041e+00
    phi[6,2]  R1841     -1.6666140556335449e+00
    phi[6,2]  R1842     -1.6821141242980957e+00
    phi[6,2]  R1843     -1.8187531232833862e+00
    phi[6,2]  R1844     -3.8393962383270264e+00
    phi[6,2]  R1845     -2.0758419036865234e+00
    phi[6,2]  R1846     -1.5106359720230103e+00
    phi[6,2]  R1847     -2.5495128631591797e+00
    phi[6,2]  R1848     -2.98397159576416
    phi[6,2]  R1849     -8.6914956569671631e-01
    phi[6,2]  R1850     -3.1268823146820068e+00
    phi[6,2]  R1851     -1.12340247631073
    phi[6,2]  R1852     -9.2153137922286987e-01
    phi[6,2]  R1853     4.3196535110473633e-01
    phi[6,2]  R1854     -1.0877807140350342e+00
    phi[6,2]  R1855     -2.3510959148406982e+00
    phi[6,2]  R1856     -2.3011338710784912e+00
    phi[6,2]  R1857     -3.9914309978485107e-01
    phi[6,2]  R1858     -6.8474167585372925e-01
    phi[6,2]  R1859     -3.0490422248840332e+00
    phi[6,2]  R1860     -1.3222889900207520e+00
    phi[6,2]  R1861     -2.7262864112854004e+00
    phi[6,2]  R1862     -2.9492062330245972e-01
    phi[6,2]  R1863     -2.7539758682250977e+00
    phi[6,2]  R1864     -8.1586551666259766e-01
    phi[6,2]  R1865     -1.5702557563781738e+00
    phi[6,2]  R1866     -9.0640437602996826e-01
    phi[6,2]  R1867     -1.7569994926452637e+00
    phi[6,2]  R1868     -2.8827140331268311e+00
    phi[6,2]  R1869     -2.1204392910003662e+00
    phi[6,2]  R1870     -3.2224001884460449e+00
    phi[6,2]  R1871     -2.2973988056182861e+00
    phi[6,2]  R1872     -3.7001209259033203e+00
    phi[6,2]  R1873     -3.55043625831604
    phi[6,2]  R1874     -1.3864747285842896e+00
    phi[6,2]  R1875     1.6968119144439697e-01
    phi[6,2]  R1876     3.4461038112640381e+00
    phi[6,2]  R1877     4.9992385506629944e-01
    phi[6,2]  R1878     4.5116774737834930e-02
    phi[6,2]  R1879     -5.5196243524551392e-01
    phi[6,2]  R1880     -4.5055025815963745e-01
    phi[6,2]  R1881     -1.0857639312744141e+00
    phi[6,2]  R1882     -6.7632061243057251e-01
    phi[6,2]  R1883     -7.1292769908905029e-01
    phi[6,2]  R1884     -1.9059193134307861e+00
    phi[6,2]  R1885     1.0545358657836914e+00
    phi[6,2]  R1886     1.9606584683060646e-03
    phi[6,2]  R1887     -1.9717895984649658e+00
    phi[6,2]  R1888     -2.3940012454986572e+00
    phi[6,2]  R1889     -2.7874064445495605e+00
    phi[6,2]  R1890     -1.8716061115264893e+00
    phi[6,2]  R1891     4.0793079137802124e-01
    phi[6,2]  R1892     -1.5426986217498779e+00
    phi[6,2]  R1893     -1.24186372756958
    phi[6,2]  R1894     -3.6987599730491638e-01
    phi[6,2]  R1895     -1.8108935356140137e+00
    phi[6,2]  R1896     -2.6380333900451660e+00
    phi[6,2]  R1897     -2.1000483036041260e+00
    phi[6,2]  R1898     9.4504594802856445e-02
    phi[6,2]  R1899     -2.6152372360229492e-01
    phi[6,2]  R1900     -1.9243885576725006e-01
    phi[6,2]  R1901     -0.021955581381917
    phi[6,2]  R1902     -2.5393602848052979e+00
    phi[6,2]  R1903     -3.3495125770568848e+00
    phi[6,2]  R1904     -3.5881495475769043e+00
    phi[2,8]  R18       1
    phi[2,8]  R19       1
    phi[2,8]  R20       -2.1602087079093093e+00
    phi[2,8]  R21       1.9226046655518942e+00
    phi[2,8]  R22       1.2179550017651779e+00
    phi[2,8]  R23       2.5122989842980230e+00
    phi[2,8]  R24       -9.6567581015030379e-01
    phi[2,8]  R25       -0.560826583533435
    phi[2,8]  R26       1.1393602345807174e-01
    phi[2,8]  R64       -1
    phi[2,8]  R1905     -5.2602086125418772e+00
    phi[2,8]  R1906     -9.3979119672325906e-01
    phi[2,8]  R1907     -3.1739534398484892e-01
    phi[2,8]  R1908     -4.1626046750886374e+00
    phi[2,8]  R1909     -1.8820449028673905e+00
    phi[2,8]  R1910     -4.3179549063977465e+00
    phi[2,8]  R1911     -5.7700948944774844e-02
    phi[2,8]  R1912     -5.0822989175408209e+00
    phi[2,8]  R1913     -4.0656757147828717e+00
    phi[2,8]  R1914     -2.1343240944822646e+00
    phi[2,8]  R1915     -2.6508264977027465e+00
    phi[2,8]  R1916     -1.5291733306358766e+00
    phi[2,8]  R1917     -2.9860638811744966e+00
    phi[2,8]  R1918     -3.21393592809064
    phi[2,8]  R1919     -1.0828463629395380e-03
    phi[2,8]  R1920     -0.599236363303735
    phi[2,8]  R1921     -6.1232553437451975e-01
    phi[2,8]  R1922     -6.3298071676706957e-01
    phi[2,8]  R1923     -6.9372187734513846e-01
    phi[2,8]  R1924     -0.739470819526305
    phi[2,8]  R1925     -8.8708501987075006e-01
    phi[2,8]  R1926     -9.2838636817265852e-01
    phi[2,8]  R1927     -1.2137381672783838e+00
    phi[2,8]  R1928     -4.4700596124006120e-02
    phi[2,8]  R1929     -4.9692788269841560e-02
    phi[2,8]  R1930     -8.7299548807375271e-01
    phi[2,8]  R1931     -1.1003862080047513e+00
    phi[2,8]  R1932     -1.4272259633853184e+00
    phi[2,8]  R1933     -4.8036504241118494e-01
    phi[2,8]  R1934     -2.5885761126788176e-01
    phi[2,8]  R1935     -7.0514662688472485e-01
    phi[2,8]  R1936     -2.9808103608443060e-01
    phi[2,8]  R1937     -3.2618648096317537e-01
    phi[2,8]  R1938     -3.4072577824675210e-01
    phi[2,8]  R1939     -3.6645683958711039e-01
    phi[2,8]  R1940     -0.374087223799358
    phi[2,8]  R1941     -4.7691747416554842e-01
    phi[2,8]  R1942     -4.8267248427817550e-01
    phi[2,8]  R1943     -4.8352629915241252e-01
    phi[2,8]  R1944     -4.9694874000668854e-01
    phi[2,8]  R1945     -0.555867917380642
    phi[2,8]  R1946     -2.2954937054698830e+00
    phi[2,8]  R1947     -1.4080791597066535e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1948     -3.0999999046325684e+00
    phi[3,4]  R1949     -3.0999999046325684e+00
    phi[3,4]  R1950     -2.2400000095367432e+00
    phi[3,4]  R1951     -2.2400000095367432e+00
    phi[3,4]  R1952     -3.0999999046325684e+00
    phi[3,4]  R1953     -3.0999999046325684e+00
    phi[3,4]  R1954     -2.5699999332427979e+00
    phi[3,4]  R1955     -2.5699999332427979e+00
    phi[3,4]  R1956     -3.0999999046325684e+00
    phi[3,4]  R1957     -3.0999999046325684e+00
    phi[3,4]  R1958     -2.0899999141693115e+00
    phi[3,4]  R1959     -2.0899999141693115e+00
    phi[3,4]  R1960     -3.0999999046325684e+00
    phi[3,4]  R1961     -3.0999999046325684e+00
    phi[3,4]  R1962     1.6829231977462769e+00
    phi[3,4]  R1963     -1.5053712129592896e+00
    phi[3,4]  R1964     9.9031043052673340e-01
    phi[3,4]  R1965     -5.6779032945632935e-01
    phi[3,4]  R1966     1.2070429325103760e+00
    phi[3,4]  R1967     4.9847790598869324e-01
    phi[3,4]  R1968     8.8094002008438110e-01
    phi[3,4]  R1969     1.9085167348384857e-01
    phi[3,4]  R1970     -6.6627782583236694e-01
    phi[3,4]  R1971     7.0998094975948334e-02
    phi[3,4]  R1972     -4.8487114906311035e-01
    phi[3,4]  R1973     -8.7781077623367310e-01
    phi[3,4]  R1974     -1.1795622855424881e-01
    phi[3,4]  R1975     -6.9913744926452637e-02
    phi[3,4]  R1976     -1.4811405912041664e-02
    phi[3,4]  R1977     -5.0662606954574585e-01
    phi[3,4]  R1978     6.2462252378463745e-01
    phi[3,4]  R1979     -3.8169956207275391e+00
    phi[3,4]  R1980     -3.7428457736968994e+00
    phi[3,4]  R1981     -3.1563389301300049e+00
    phi[3,4]  R1982     -8.7032037973403931e-01
    phi[3,4]  R1983     -2.0241081714630127e+00
    phi[3,4]  R1984     -2.1939568519592285e+00
    phi[3,4]  R1985     -9.2286723852157593e-01
    phi[3,4]  R1986     -1.8743215799331665e+00
    phi[3,4]  R1987     -1.8652489185333252e+00
    phi[3,4]  R1988     -2.4508533477783203e+00
    phi[3,4]  R1989     -2.1589899063110352e+00
    phi[3,4]  R1990     -3.2147843837738037e+00
    phi[3,4]  R1991     -1.5911586284637451e+00
    phi[3,4]  R1992     -1.6579966545104980e+00
    phi[3,4]  R1993     1.8122951686382294e-01
    phi[3,4]  R1994     -1.7603868246078491e+00
    phi[3,4]  R1995     -1.5825827121734619e+00
    phi[3,4]  R1996     -1.9421851634979248e+00
    phi[3,4]  R1997     -9.4935840368270874e-01
    phi[3,4]  R1998     4.0470549464225769e-01
    phi[3,4]  R1999     -3.6109781265258789e-01
    phi[3,4]  R2000     -1.9696003198623657e-01
    phi[3,4]  R2001     -9.3212914466857910e-01
    phi[3,4]  R2002     1.0913379192352295e+00
    phi[3,4]  R2003     1.1782114505767822e+00
    phi[3,4]  R2004     4.3235847353935242e-01
    phi[3,4]  R2005     2.1700556278228760e+00
    phi[3,4]  R2006     1.5522381067276
    phi[3,4]  R2007     -7.2675958275794983e-02
    phi[3,4]  R2008     5.5075001716613770e-01
    phi[3,4]  R2009     8.3547115325927734e-01
    phi[3,4]  R2010     -2.1702699661254883e+00
    phi[3,4]  R2011     -1.6632767915725708e+00
    phi[3,4]  R2012     -1.8399087190628052e+00
    phi[3,4]  R2013     -1.4419515132904053e+00
    phi[3,4]  R2014     -1.2011263370513916e+00
    phi[3,4]  R2015     0.277835488319397
    phi[3,4]  R2016     -2.97823166847229
    phi[3,4]  R2017     -3.3856742382049561e+00
    phi[3,4]  R2018     -1.5511336326599121e+00
    phi[3,4]  R2019     -5.4516983032226562e-01
    phi[3,4]  R2020     -1.8415642976760864e+00
    phi[3,4]  R2021     -2.3212623596191406e+00
    phi[3,4]  R2022     -2.0684318542480469e+00
    phi[3,4]  R2023     -2.5935132503509521e+00
    phi[3,4]  R2024     -1.5212699174880981e+00
    phi[3,4]  R2025     7.2242164611816406e-01
    phi[3,4]  R2026     0.906074583530426
    phi[3,4]  R2027     5.0859600305557251e-01
    phi[3,4]  R2028     9.5689713954925537e-01
    phi[3,4]  R2029     -1.7233482003211975e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2030     -3.0999999046325684e+00
    phi[4,3]  R2031     -3.0999999046325684e+00
    phi[4,3]  R2032     -2.2400000095367432e+00
    phi[4,3]  R2033     -2.2400000095367432e+00
    phi[4,3]  R2034     -3.0999999046325684e+00
    phi[4,3]  R2035     -3.0999999046325684e+00
    phi[4,3]  R2036     -2.5699999332427979e+00
    phi[4,3]  R2037     -2.5699999332427979e+00
    phi[4,3]  R2038     -3.0999999046325684e+00
    phi[4,3]  R2039     -3.0999999046325684e+00
    phi[4,3]  R2040     -2.0899999141693115e+00
    phi[4,3]  R2041     -2.0899999141693115e+00
    phi[4,3]  R2042     -3.0999999046325684e+00
    phi[4,3]  R2043     -3.0999999046325684e+00
    phi[4,3]  R2044     -1.9696003198623657e-01
    phi[4,3]  R2045     -9.3212914466857910e-01
    phi[4,3]  R2046     1.0913379192352295e+00
    phi[4,3]  R2047     1.1782114505767822e+00
    phi[4,3]  R2048     4.3235847353935242e-01
    phi[4,3]  R2049     2.1700556278228760e+00
    phi[4,3]  R2050     1.5522381067276
    phi[4,3]  R2051     -7.2675958275794983e-02
    phi[4,3]  R2052     5.5075001716613770e-01
    phi[4,3]  R2053     8.3547115325927734e-01
    phi[4,3]  R2054     -2.1702699661254883e+00
    phi[4,3]  R2055     -1.6632767915725708e+00
    phi[4,3]  R2056     -1.8399087190628052e+00
    phi[4,3]  R2057     -1.4419515132904053e+00
    phi[4,3]  R2058     -1.2011263370513916e+00
    phi[4,3]  R2059     0.277835488319397
    phi[4,3]  R2060     -2.97823166847229
    phi[4,3]  R2061     -3.3856742382049561e+00
    phi[4,3]  R2062     -1.5511336326599121e+00
    phi[4,3]  R2063     -5.4516983032226562e-01
    phi[4,3]  R2064     -1.8415642976760864e+00
    phi[4,3]  R2065     -2.3212623596191406e+00
    phi[4,3]  R2066     -2.0684318542480469e+00
    phi[4,3]  R2067     -2.5935132503509521e+00
    phi[4,3]  R2068     -1.5212699174880981e+00
    phi[4,3]  R2069     7.2242164611816406e-01
    phi[4,3]  R2070     0.906074583530426
    phi[4,3]  R2071     5.0859600305557251e-01
    phi[4,3]  R2072     9.5689713954925537e-01
    phi[4,3]  R2073     -1.7233482003211975e-01
    phi[4,3]  R2074     1.6829231977462769e+00
    phi[4,3]  R2075     -1.5053712129592896e+00
    phi[4,3]  R2076     9.9031043052673340e-01
    phi[4,3]  R2077     -5.6779032945632935e-01
    phi[4,3]  R2078     1.2070429325103760e+00
    phi[4,3]  R2079     4.9847790598869324e-01
    phi[4,3]  R2080     8.8094002008438110e-01
    phi[4,3]  R2081     1.9085167348384857e-01
    phi[4,3]  R2082     -6.6627782583236694e-01
    phi[4,3]  R2083     7.0998094975948334e-02
    phi[4,3]  R2084     -4.8487114906311035e-01
    phi[4,3]  R2085     -8.7781077623367310e-01
    phi[4,3]  R2086     -1.1795622855424881e-01
    phi[4,3]  R2087     -6.9913744926452637e-02
    phi[4,3]  R2088     -1.4811405912041664e-02
    phi[4,3]  R2089     -5.0662606954574585e-01
    phi[4,3]  R2090     6.2462252378463745e-01
    phi[4,3]  R2091     -3.8169956207275391e+00
    phi[4,3]  R2092     -3.7428457736968994e+00
    phi[4,3]  R2093     -3.1563389301300049e+00
    phi[4,3]  R2094     -8.7032037973403931e-01
    phi[4,3]  R2095     -2.0241081714630127e+00
    phi[4,3]  R2096     -2.1939568519592285e+00
    phi[4,3]  R2097     -9.2286723852157593e-01
    phi[4,3]  R2098     -1.8743215799331665e+00
    phi[4,3]  R2099     -1.8652489185333252e+00
    phi[4,3]  R2100     -2.4508533477783203e+00
    phi[4,3]  R2101     -2.1589899063110352e+00
    phi[4,3]  R2102     -3.2147843837738037e+00
    phi[4,3]  R2103     -1.5911586284637451e+00
    phi[4,3]  R2104     -1.6579966545104980e+00
    phi[4,3]  R2105     1.8122951686382294e-01
    phi[4,3]  R2106     -1.7603868246078491e+00
    phi[4,3]  R2107     -1.5825827121734619e+00
    phi[4,3]  R2108     -1.9421851634979248e+00
    phi[4,3]  R2109     -9.4935840368270874e-01
    phi[4,3]  R2110     4.0470549464225769e-01
    phi[4,3]  R2111     -3.6109781265258789e-01
    phi[7,3]  R27       -1
    phi[7,3]  R29       -1.2390059515445182e+00
    phi[7,3]  R30       -1.2106165893173257e+00
    phi[7,3]  R31       1.8316182031440387e+00
    phi[7,3]  R32       -3.4264801752042828e-01
    phi[7,3]  R33       2.0970027805179234e+00
    phi[7,3]  R34       1.9819876604862823e+00
    phi[7,3]  R35       1.1948196548939838e+00
    phi[7,3]  R63       1
    phi[7,3]  R2112     -1.8609939530880502e+00
    phi[7,3]  R2113     -4.3390058561770868e+00
    phi[7,3]  R2114     -1.0293834202194174e+00
    phi[7,3]  R2115     -3.4506165988540687e+00
    phi[7,3]  R2116     -4.9316181077766075e+00
    phi[7,3]  R2117     -1.2683817014885297e+00
    phi[7,3]  R2118     -2.2273519157223696e+00
    phi[7,3]  R2119     -2.9126479507632261e+00
    phi[7,3]  R2120     -5.1970026851504922e+00
    phi[7,3]  R2121     -1.0029971241146449e+00
    phi[7,3]  R2122     -4.0719875746555942e+00
    phi[7,3]  R2123     -1.0801225368302925e-01
    phi[7,3]  R2124     -4.2948195595265517e+00
    phi[7,3]  R2125     -1.9051802497385846e+00
    phi[7,3]  R2126     -1.4653476503336593e-02
    phi[7,3]  R2127     -8.7487750749017046e-02
    phi[7,3]  R2128     -1.5210092417921106e-01
    phi[7,3]  R2129     -6.2005969259828220e-01
    phi[7,3]  R2130     -1.3964829957161284e+00
    phi[7,3]  R2131     -2.2540333414684866e+00
    phi[7,3]  R2132     -1.9082056677608104e+00
    phi[7,3]  R2133     -2.2303810902257921e+00
    phi[7,3]  R2134     -1.9223083012221489e+00
    phi[7,3]  R2135     -8.3868564024641079e-01
    phi[7,3]  R2136     -3.9356396579028408e-01
    phi[7,3]  R2137     -3.9398120724803209e-01
    phi[7,3]  R2138     -3.9431547538714767e-01
    phi[7,3]  R2139     -4.0449700242622239e-01
    phi[7,3]  R2140     -4.1021996806406524e-01
    phi[7,3]  R2141     -4.1701598247144822e-01
    phi[7,3]  R2142     -5.2964388508931859e-01
    phi[7,3]  R2143     -1.5044420468318132e+00
    phi[7,3]  R2144     -1.2382646459709403e+00
    phi[7,3]  R2145     -1.5048538909818903e+00
    phi[7,3]  R2146     -3.9121007724385254e-01
    phi[7,3]  R2147     -4.9663930609872864e-01
    phi[7,3]  R2148     -2.3789606806800361e+00
    phi[7,3]  R2149     -1.3594304816844613e+00
    phi[7,3]  R2150     -2.8053199947765957e+00
    phi[7,3]  R2151     -8.6659378408751220e-01
    phi[7,3]  R2152     -1.0062612975017120e+00
    phi[7,3]  R2153     -1.0928314560839765e+00
    phi[7,3]  R2154     -1.1047065938556764e+00
    phi[7,3]  R2155     -1.1420083354012109e+00
    phi[7,3]  R2156     -2.4046590414741797e-01
    phi[7,3]  R2157     -3.5002867127550830e-01
    phi[7,3]  R2158     -2.9355850834297166e+00
    phi[7,3]  R2159     -1.8462231097224109e+00
    phi[7,3]  R2160     -2.2388694101780895e+00
    phi[7,3]  R2161     -1.1609671935268295e+00
    phi[7,3]  R2162     -1.6356050889336511e+00
    phi[7,3]  R2163     -1.8929198348175393e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2164     -3.0999999046325684e+00
    phi[4,5]  R2165     -3.0999999046325684e+00
    phi[4,5]  R2166     -2.2400000095367432e+00
    phi[4,5]  R2167     -2.2400000095367432e+00
    phi[4,5]  R2168     -3.0999999046325684e+00
    phi[4,5]  R2169     -3.0999999046325684e+00
    phi[4,5]  R2170     -2.5699999332427979e+00
    phi[4,5]  R2171     -2.5699999332427979e+00
    phi[4,5]  R2172     -3.0999999046325684e+00
    phi[4,5]  R2173     -3.0999999046325684e+00
    phi[4,5]  R2174     -2.0899999141693115e+00
    phi[4,5]  R2175     -2.0899999141693115e+00
    phi[4,5]  R2176     -3.0999999046325684e+00
    phi[4,5]  R2177     -3.0999999046325684e+00
    phi[4,5]  R2178     -1.9696003198623657e-01
    phi[4,5]  R2179     -9.3212914466857910e-01
    phi[4,5]  R2180     1.0913379192352295e+00
    phi[4,5]  R2181     1.1782114505767822e+00
    phi[4,5]  R2182     4.3235847353935242e-01
    phi[4,5]  R2183     2.1700556278228760e+00
    phi[4,5]  R2184     1.5522381067276
    phi[4,5]  R2185     -7.2675958275794983e-02
    phi[4,5]  R2186     5.5075001716613770e-01
    phi[4,5]  R2187     8.3547115325927734e-01
    phi[4,5]  R2188     -2.1702699661254883e+00
    phi[4,5]  R2189     -1.6632767915725708e+00
    phi[4,5]  R2190     -1.8399087190628052e+00
    phi[4,5]  R2191     -1.4419515132904053e+00
    phi[4,5]  R2192     -1.2011263370513916e+00
    phi[4,5]  R2193     0.277835488319397
    phi[4,5]  R2194     -2.97823166847229
    phi[4,5]  R2195     -3.3856742382049561e+00
    phi[4,5]  R2196     -1.5511336326599121e+00
    phi[4,5]  R2197     -5.4516983032226562e-01
    phi[4,5]  R2198     -1.8415642976760864e+00
    phi[4,5]  R2199     -2.3212623596191406e+00
    phi[4,5]  R2200     -2.0684318542480469e+00
    phi[4,5]  R2201     -2.5935132503509521e+00
    phi[4,5]  R2202     -1.5212699174880981e+00
    phi[4,5]  R2203     7.2242164611816406e-01
    phi[4,5]  R2204     0.906074583530426
    phi[4,5]  R2205     5.0859600305557251e-01
    phi[4,5]  R2206     9.5689713954925537e-01
    phi[4,5]  R2207     -1.7233482003211975e-01
    phi[4,5]  R2208     -6.3640981912612915e-01
    phi[4,5]  R2209     2.5880272388458252e+00
    phi[4,5]  R2210     2.6231596469879150e+00
    phi[4,5]  R2211     2.6645054817199707e+00
    phi[4,5]  R2212     2.7784593105316162e+00
    phi[4,5]  R2213     3.0919108390808105e+00
    phi[4,5]  R2214     2.3366715908050537e+00
    phi[4,5]  R2215     1.6047230958938599e+00
    phi[4,5]  R2216     2.8079228401184082e+00
    phi[4,5]  R2217     3.2592887878417969e+00
    phi[4,5]  R2218     -2.1449103355407715e+00
    phi[4,5]  R2219     -3.2058589458465576e+00
    phi[4,5]  R2220     -2.3394837379455566e+00
    phi[4,5]  R2221     -5.7962024211883545e-01
    phi[4,5]  R2222     -1.6185268163681030e+00
    phi[4,5]  R2223     -6.3051402568817139e-01
    phi[4,5]  R2224     -1.2105958461761475e+00
    phi[4,5]  R2225     -2.6354799270629883e+00
    phi[4,5]  R2226     -1.2961137294769287e-01
    phi[4,5]  R2227     -1.93434476852417
    phi[4,5]  R2228     -0.0989639163017273
    phi[4,5]  R2229     -7.5165349245071411e-01
    phi[4,5]  R2230     -8.8103270530700684e-01
    phi[4,5]  R2231     -8.5376471281051636e-02
    phi[4,5]  R2232     -1.1561900377273560e+00
    phi[4,5]  R2233     9.0916119515895844e-02
    phi[4,5]  R2234     -9.1831809282302856e-01
    phi[4,5]  R2235     -9.7034519910812378e-01
    phi[4,5]  R2236     -5.7880836725234985e-01
    phi[4,5]  R2237     -2.5016114711761475e+00
    phi[4,5]  R2238     1.3049411773681641e+00
    phi[4,5]  R2239     6.1048889160156250e-01
    phi[4,5]  R2240     -1.7441697120666504e+00
    phi[4,5]  R2241     -1.1380017995834351e+00
    phi[4,5]  R2242     -2.9301264882087708e-01
    phi[4,5]  R2243     -5.2002954483032227e-01
    phi[4,5]  R2244     -8.3248722553253174e-01
    phi[4,5]  R2245     -8.2074439525604248e-01
    phi[4,5]  R2246     2.1347159147262573e-01
    phi[4,5]  R2247     -5.6308156251907349e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2248     -3.0999999046325684e+00
    phi[5,4]  R2249     -3.0999999046325684e+00
    phi[5,4]  R2250     -2.2400000095367432e+00
    phi[5,4]  R2251     -2.2400000095367432e+00
    phi[5,4]  R2252     -3.0999999046325684e+00
    phi[5,4]  R2253     -3.0999999046325684e+00
    phi[5,4]  R2254     -2.5699999332427979e+00
    phi[5,4]  R2255     -2.5699999332427979e+00
    phi[5,4]  R2256     -3.0999999046325684e+00
    phi[5,4]  R2257     -3.0999999046325684e+00
    phi[5,4]  R2258     -2.0899999141693115e+00
    phi[5,4]  R2259     -2.0899999141693115e+00
    phi[5,4]  R2260     -3.0999999046325684e+00
    phi[5,4]  R2261     -3.0999999046325684e+00
    phi[5,4]  R2262     -6.3640981912612915e-01
    phi[5,4]  R2263     2.5880272388458252e+00
    phi[5,4]  R2264     2.6231596469879150e+00
    phi[5,4]  R2265     2.6645054817199707e+00
    phi[5,4]  R2266     2.7784593105316162e+00
    phi[5,4]  R2267     3.0919108390808105e+00
    phi[5,4]  R2268     2.3366715908050537e+00
    phi[5,4]  R2269     1.6047230958938599e+00
    phi[5,4]  R2270     2.8079228401184082e+00
    phi[5,4]  R2271     3.2592887878417969e+00
    phi[5,4]  R2272     -2.1449103355407715e+00
    phi[5,4]  R2273     -3.2058589458465576e+00
    phi[5,4]  R2274     -2.3394837379455566e+00
    phi[5,4]  R2275     -5.7962024211883545e-01
    phi[5,4]  R2276     -1.6185268163681030e+00
    phi[5,4]  R2277     -6.3051402568817139e-01
    phi[5,4]  R2278     -1.2105958461761475e+00
    phi[5,4]  R2279     -2.6354799270629883e+00
    phi[5,4]  R2280     -1.2961137294769287e-01
    phi[5,4]  R2281     -1.93434476852417
    phi[5,4]  R2282     -0.0989639163017273
    phi[5,4]  R2283     -7.5165349245071411e-01
    phi[5,4]  R2284     -8.8103270530700684e-01
    phi[5,4]  R2285     -8.5376471281051636e-02
    phi[5,4]  R2286     -1.1561900377273560e+00
    phi[5,4]  R2287     9.0916119515895844e-02
    phi[5,4]  R2288     -9.1831809282302856e-01
    phi[5,4]  R2289     -9.7034519910812378e-01
    phi[5,4]  R2290     -5.7880836725234985e-01
    phi[5,4]  R2291     -2.5016114711761475e+00
    phi[5,4]  R2292     1.3049411773681641e+00
    phi[5,4]  R2293     6.1048889160156250e-01
    phi[5,4]  R2294     -1.7441697120666504e+00
    phi[5,4]  R2295     -1.1380017995834351e+00
    phi[5,4]  R2296     -2.9301264882087708e-01
    phi[5,4]  R2297     -5.2002954483032227e-01
    phi[5,4]  R2298     -8.3248722553253174e-01
    phi[5,4]  R2299     -8.2074439525604248e-01
    phi[5,4]  R2300     2.1347159147262573e-01
    phi[5,4]  R2301     -5.6308156251907349e-01
    phi[5,4]  R2302     -1.9696003198623657e-01
    phi[5,4]  R2303     -9.3212914466857910e-01
    phi[5,4]  R2304     1.0913379192352295e+00
    phi[5,4]  R2305     1.1782114505767822e+00
    phi[5,4]  R2306     4.3235847353935242e-01
    phi[5,4]  R2307     2.1700556278228760e+00
    phi[5,4]  R2308     1.5522381067276
    phi[5,4]  R2309     -7.2675958275794983e-02
    phi[5,4]  R2310     5.5075001716613770e-01
    phi[5,4]  R2311     8.3547115325927734e-01
    phi[5,4]  R2312     -2.1702699661254883e+00
    phi[5,4]  R2313     -1.6632767915725708e+00
    phi[5,4]  R2314     -1.8399087190628052e+00
    phi[5,4]  R2315     -1.4419515132904053e+00
    phi[5,4]  R2316     -1.2011263370513916e+00
    phi[5,4]  R2317     0.277835488319397
    phi[5,4]  R2318     -2.97823166847229
    phi[5,4]  R2319     -3.3856742382049561e+00
    phi[5,4]  R2320     -1.5511336326599121e+00
    phi[5,4]  R2321     -5.4516983032226562e-01
    phi[5,4]  R2322     -1.8415642976760864e+00
    phi[5,4]  R2323     -2.3212623596191406e+00
    phi[5,4]  R2324     -2.0684318542480469e+00
    phi[5,4]  R2325     -2.5935132503509521e+00
    phi[5,4]  R2326     -1.5212699174880981e+00
    phi[5,4]  R2327     7.2242164611816406e-01
    phi[5,4]  R2328     0.906074583530426
    phi[5,4]  R2329     5.0859600305557251e-01
    phi[5,4]  R2330     9.5689713954925537e-01
    phi[5,4]  R2331     -1.7233482003211975e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2332     -3.0999999046325684e+00
    phi[5,6]  R2333     -3.0999999046325684e+00
    phi[5,6]  R2334     -2.2400000095367432e+00
    phi[5,6]  R2335     -2.2400000095367432e+00
    phi[5,6]  R2336     -3.0999999046325684e+00
    phi[5,6]  R2337     -3.0999999046325684e+00
    phi[5,6]  R2338     -2.5699999332427979e+00
    phi[5,6]  R2339     -2.5699999332427979e+00
    phi[5,6]  R2340     -3.0999999046325684e+00
    phi[5,6]  R2341     -3.0999999046325684e+00
    phi[5,6]  R2342     -2.0899999141693115e+00
    phi[5,6]  R2343     -2.0899999141693115e+00
    phi[5,6]  R2344     -3.0999999046325684e+00
    phi[5,6]  R2345     -3.0999999046325684e+00
    phi[5,6]  R2346     -6.3640981912612915e-01
    phi[5,6]  R2347     2.5880272388458252e+00
    phi[5,6]  R2348     2.6231596469879150e+00
    phi[5,6]  R2349     2.6645054817199707e+00
    phi[5,6]  R2350     2.7784593105316162e+00
    phi[5,6]  R2351     3.0919108390808105e+00
    phi[5,6]  R2352     2.3366715908050537e+00
    phi[5,6]  R2353     1.6047230958938599e+00
    phi[5,6]  R2354     2.8079228401184082e+00
    phi[5,6]  R2355     3.2592887878417969e+00
    phi[5,6]  R2356     -2.1449103355407715e+00
    phi[5,6]  R2357     -3.2058589458465576e+00
    phi[5,6]  R2358     -2.3394837379455566e+00
    phi[5,6]  R2359     -5.7962024211883545e-01
    phi[5,6]  R2360     -1.6185268163681030e+00
    phi[5,6]  R2361     -6.3051402568817139e-01
    phi[5,6]  R2362     -1.2105958461761475e+00
    phi[5,6]  R2363     -2.6354799270629883e+00
    phi[5,6]  R2364     -1.2961137294769287e-01
    phi[5,6]  R2365     -1.93434476852417
    phi[5,6]  R2366     -0.0989639163017273
    phi[5,6]  R2367     -7.5165349245071411e-01
    phi[5,6]  R2368     -8.8103270530700684e-01
    phi[5,6]  R2369     -8.5376471281051636e-02
    phi[5,6]  R2370     -1.1561900377273560e+00
    phi[5,6]  R2371     9.0916119515895844e-02
    phi[5,6]  R2372     -9.1831809282302856e-01
    phi[5,6]  R2373     -9.7034519910812378e-01
    phi[5,6]  R2374     -5.7880836725234985e-01
    phi[5,6]  R2375     -2.5016114711761475e+00
    phi[5,6]  R2376     1.3049411773681641e+00
    phi[5,6]  R2377     6.1048889160156250e-01
    phi[5,6]  R2378     -1.7441697120666504e+00
    phi[5,6]  R2379     -1.1380017995834351e+00
    phi[5,6]  R2380     -2.9301264882087708e-01
    phi[5,6]  R2381     -5.2002954483032227e-01
    phi[5,6]  R2382     -8.3248722553253174e-01
    phi[5,6]  R2383     -8.2074439525604248e-01
    phi[5,6]  R2384     2.1347159147262573e-01
    phi[5,6]  R2385     -5.6308156251907349e-01
    phi[5,6]  R2386     3.7150695323944092e+00
    phi[5,6]  R2387     3.4160096645355225e+00
    phi[5,6]  R2388     3.2055947780609131e+00
    phi[5,6]  R2389     2.5350701808929443e+00
    phi[5,6]  R2390     1.3291240930557251e+00
    phi[5,6]  R2391     1.1946650743484497e+00
    phi[5,6]  R2392     -5.4589295387268066e-01
    phi[5,6]  R2393     1.4461125433444977e-01
    phi[5,6]  R2394     2.2654399275779724e-01
    phi[5,6]  R2395     1.0043439865112305e+00
    phi[5,6]  R2396     -1.2961395978927612e+00
    phi[5,6]  R2397     -1.9659836292266846e+00
    phi[5,6]  R2398     -1.7062138319015503e+00
    phi[5,6]  R2399     -2.1911044120788574e+00
    phi[5,6]  R2400     -2.9000551700592041e+00
    phi[5,6]  R2401     -1.6666140556335449e+00
    phi[5,6]  R2402     -1.6821141242980957e+00
    phi[5,6]  R2403     -1.8187531232833862e+00
    phi[5,6]  R2404     -3.8393962383270264e+00
    phi[5,6]  R2405     -2.0758419036865234e+00
    phi[5,6]  R2406     -1.5106359720230103e+00
    phi[5,6]  R2407     -2.5495128631591797e+00
    phi[5,6]  R2408     -2.98397159576416
    phi[5,6]  R2409     -8.6914956569671631e-01
    phi[5,6]  R2410     -3.1268823146820068e+00
    phi[5,6]  R2411     -1.12340247631073
    phi[5,6]  R2412     -9.2153137922286987e-01
    phi[5,6]  R2413     4.3196535110473633e-01
    phi[5,6]  R2414     -1.0877807140350342e+00
    phi[5,6]  R2415     -2.3510959148406982e+00
    phi[5,6]  R2416     -2.3011338710784912e+00
    phi[5,6]  R2417     -3.9914309978485107e-01
    phi[5,6]  R2418     -6.8474167585372925e-01
    phi[5,6]  R2419     -3.0490422248840332e+00
    phi[5,6]  R2420     -1.3222889900207520e+00
    phi[5,6]  R2421     -2.7262864112854004e+00
    phi[5,6]  R2422     -2.9492062330245972e-01
    phi[5,6]  R2423     -2.7539758682250977e+00
    phi[5,6]  R2424     -8.1586551666259766e-01
    phi[5,6]  R2425     -1.5702557563781738e+00
    phi[5,6]  R2426     -9.0640437602996826e-01
    phi[5,6]  R2427     -1.7569994926452637e+00
    phi[5,6]  R2428     -2.8827140331268311e+00
    phi[5,6]  R2429     -2.1204392910003662e+00
    phi[5,6]  R2430     -3.2224001884460449e+00
    phi[5,6]  R2431     -2.2973988056182861e+00
    phi[5,6]  R2432     -3.7001209259033203e+00
    phi[5,6]  R2433     -3.55043625831604
    phi[5,6]  R2434     -1.3864747285842896e+00
    phi[5,6]  R2435     1.6968119144439697e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2436     -3.0999999046325684e+00
    phi[6,5]  R2437     -3.0999999046325684e+00
    phi[6,5]  R2438     -2.2400000095367432e+00
    phi[6,5]  R2439     -2.2400000095367432e+00
    phi[6,5]  R2440     -3.0999999046325684e+00
    phi[6,5]  R2441     -3.0999999046325684e+00
    phi[6,5]  R2442     -2.5699999332427979e+00
    phi[6,5]  R2443     -2.5699999332427979e+00
    phi[6,5]  R2444     -3.0999999046325684e+00
    phi[6,5]  R2445     -3.0999999046325684e+00
    phi[6,5]  R2446     -2.0899999141693115e+00
    phi[6,5]  R2447     -2.0899999141693115e+00
    phi[6,5]  R2448     -3.0999999046325684e+00
    phi[6,5]  R2449     -3.0999999046325684e+00
    phi[6,5]  R2450     3.7150695323944092e+00
    phi[6,5]  R2451     3.4160096645355225e+00
    phi[6,5]  R2452     3.2055947780609131e+00
    phi[6,5]  R2453     2.5350701808929443e+00
    phi[6,5]  R2454     1.3291240930557251e+00
    phi[6,5]  R2455     1.1946650743484497e+00
    phi[6,5]  R2456     -5.4589295387268066e-01
    phi[6,5]  R2457     1.4461125433444977e-01
    phi[6,5]  R2458     2.2654399275779724e-01
    phi[6,5]  R2459     1.0043439865112305e+00
    phi[6,5]  R2460     -1.2961395978927612e+00
    phi[6,5]  R2461     -1.9659836292266846e+00
    phi[6,5]  R2462     -1.7062138319015503e+00
    phi[6,5]  R2463     -2.1911044120788574e+00
    phi[6,5]  R2464     -2.9000551700592041e+00
    phi[6,5]  R2465     -1.6666140556335449e+00
    phi[6,5]  R2466     -1.6821141242980957e+00
    phi[6,5]  R2467     -1.8187531232833862e+00
    phi[6,5]  R2468     -3.8393962383270264e+00
    phi[6,5]  R2469     -2.0758419036865234e+00
    phi[6,5]  R2470     -1.5106359720230103e+00
    phi[6,5]  R2471     -2.5495128631591797e+00
    phi[6,5]  R2472     -2.98397159576416
    phi[6,5]  R2473     -8.6914956569671631e-01
    phi[6,5]  R2474     -3.1268823146820068e+00
    phi[6,5]  R2475     -1.12340247631073
    phi[6,5]  R2476     -9.2153137922286987e-01
    phi[6,5]  R2477     4.3196535110473633e-01
    phi[6,5]  R2478     -1.0877807140350342e+00
    phi[6,5]  R2479     -2.3510959148406982e+00
    phi[6,5]  R2480     -2.3011338710784912e+00
    phi[6,5]  R2481     -3.9914309978485107e-01
    phi[6,5]  R2482     -6.8474167585372925e-01
    phi[6,5]  R2483     -3.0490422248840332e+00
    phi[6,5]  R2484     -1.3222889900207520e+00
    phi[6,5]  R2485     -2.7262864112854004e+00
    phi[6,5]  R2486     -2.9492062330245972e-01
    phi[6,5]  R2487     -2.7539758682250977e+00
    phi[6,5]  R2488     -8.1586551666259766e-01
    phi[6,5]  R2489     -1.5702557563781738e+00
    phi[6,5]  R2490     -9.0640437602996826e-01
    phi[6,5]  R2491     -1.7569994926452637e+00
    phi[6,5]  R2492     -2.8827140331268311e+00
    phi[6,5]  R2493     -2.1204392910003662e+00
    phi[6,5]  R2494     -3.2224001884460449e+00
    phi[6,5]  R2495     -2.2973988056182861e+00
    phi[6,5]  R2496     -3.7001209259033203e+00
    phi[6,5]  R2497     -3.55043625831604
    phi[6,5]  R2498     -1.3864747285842896e+00
    phi[6,5]  R2499     1.6968119144439697e-01
    phi[6,5]  R2500     -6.3640981912612915e-01
    phi[6,5]  R2501     2.5880272388458252e+00
    phi[6,5]  R2502     2.6231596469879150e+00
    phi[6,5]  R2503     2.6645054817199707e+00
    phi[6,5]  R2504     2.7784593105316162e+00
    phi[6,5]  R2505     3.0919108390808105e+00
    phi[6,5]  R2506     2.3366715908050537e+00
    phi[6,5]  R2507     1.6047230958938599e+00
    phi[6,5]  R2508     2.8079228401184082e+00
    phi[6,5]  R2509     3.2592887878417969e+00
    phi[6,5]  R2510     -2.1449103355407715e+00
    phi[6,5]  R2511     -3.2058589458465576e+00
    phi[6,5]  R2512     -2.3394837379455566e+00
    phi[6,5]  R2513     -5.7962024211883545e-01
    phi[6,5]  R2514     -1.6185268163681030e+00
    phi[6,5]  R2515     -6.3051402568817139e-01
    phi[6,5]  R2516     -1.2105958461761475e+00
    phi[6,5]  R2517     -2.6354799270629883e+00
    phi[6,5]  R2518     -1.2961137294769287e-01
    phi[6,5]  R2519     -1.93434476852417
    phi[6,5]  R2520     -0.0989639163017273
    phi[6,5]  R2521     -7.5165349245071411e-01
    phi[6,5]  R2522     -8.8103270530700684e-01
    phi[6,5]  R2523     -8.5376471281051636e-02
    phi[6,5]  R2524     -1.1561900377273560e+00
    phi[6,5]  R2525     9.0916119515895844e-02
    phi[6,5]  R2526     -9.1831809282302856e-01
    phi[6,5]  R2527     -9.7034519910812378e-01
    phi[6,5]  R2528     -5.7880836725234985e-01
    phi[6,5]  R2529     -2.5016114711761475e+00
    phi[6,5]  R2530     1.3049411773681641e+00
    phi[6,5]  R2531     6.1048889160156250e-01
    phi[6,5]  R2532     -1.7441697120666504e+00
    phi[6,5]  R2533     -1.1380017995834351e+00
    phi[6,5]  R2534     -2.9301264882087708e-01
    phi[6,5]  R2535     -5.2002954483032227e-01
    phi[6,5]  R2536     -8.3248722553253174e-01
    phi[6,5]  R2537     -8.2074439525604248e-01
    phi[6,5]  R2538     2.1347159147262573e-01
    phi[6,5]  R2539     -5.6308156251907349e-01
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R56       -2.1602087079093093e+00
    phi[6,8]  R57       1.9226046655518942e+00
    phi[6,8]  R58       1.2179550017651779e+00
    phi[6,8]  R59       2.5122989842980230e+00
    phi[6,8]  R60       -9.6567581015030379e-01
    phi[6,8]  R61       -0.560826583533435
    phi[6,8]  R62       1.1393602345807174e-01
    phi[6,8]  R64       -1
    phi[6,8]  R2540     -5.2602086125418772e+00
    phi[6,8]  R2541     -9.3979119672325906e-01
    phi[6,8]  R2542     -3.1739534398484892e-01
    phi[6,8]  R2543     -4.1626046750886374e+00
    phi[6,8]  R2544     -1.8820449028673905e+00
    phi[6,8]  R2545     -4.3179549063977465e+00
    phi[6,8]  R2546     -5.7700948944774844e-02
    phi[6,8]  R2547     -5.0822989175408209e+00
    phi[6,8]  R2548     -4.0656757147828717e+00
    phi[6,8]  R2549     -2.1343240944822646e+00
    phi[6,8]  R2550     -2.6508264977027465e+00
    phi[6,8]  R2551     -1.5291733306358766e+00
    phi[6,8]  R2552     -2.9860638811744966e+00
    phi[6,8]  R2553     -3.21393592809064
    phi[6,8]  R2554     -7.7213344712877330e-02
    phi[6,8]  R2555     -8.1752576063096161e-02
    phi[6,8]  R2556     -8.9250679626091678e-02
    phi[6,8]  R2557     -1.1774837262712534e-01
    phi[6,8]  R2558     -3.1171719657092578e-01
    phi[6,8]  R2559     -3.4842622913241694e-01
    phi[6,8]  R2560     -7.5625545241315084e-01
    phi[6,8]  R2561     -4.4322172323920461e-01
    phi[6,8]  R2562     -4.5325813424656758e-01
    phi[6,8]  R2563     -4.9266221308264857e-01
    phi[6,8]  R2564     -1.1802399661597396e-01
    phi[6,8]  R2565     -0.797978742783038
    phi[6,8]  R2566     -1.7929921477686395e-01
    phi[6,8]  R2567     -7.4276235183013073e-01
    phi[6,8]  R2568     -7.4318986876088777e-01
    phi[6,8]  R2569     -1.8672622325366173e-01
    phi[6,8]  R2570     -2.2773372818718562e-01
    phi[6,8]  R2571     -0.196799753000789
    phi[6,8]  R2572     -2.0016934175865808e-01
    phi[6,8]  R2573     -4.9786274466303837e-01
    phi[6,8]  R2574     -1.1066609697889618e-01
    phi[6,8]  R2575     -1.1489611262032318e-01
    phi[6,8]  R2576     -1.2238229288245206e-01
    phi[6,8]  R2577     -1.3449933576765427e-01
    phi[6,8]  R2578     -4.8252588478177305e-01
    phi[6,8]  R2579     -1.5917610007320027e-01
    phi[6,8]  R2580     -1.5847009754714121e+00
    phi[6,8]  R2581     -8.5093420465896674e-01
    phi[6,8]  R2582     -1.3355877917786125e+00
    phi[6,8]  R2583     -2.5657725977980395e-01
    phi[6,8]  R2584     -1.0098150117328064e-01
    phi[6,8]  R2585     -1.6554154601593341e-01
    phi[6,8]  R2586     -3.3814880313577378e-01
    phi[6,8]  R2587     -1.1305991989641513e+00
    phi[6,8]  R2588     -1.5281757322438496e+00
    phi[6,8]  R2589     -2.0346212781709694e-01
    phi[6,8]  R2590     -6.5947936463117807e-01
    phi[6,8]  R2591     -8.0977037145940867e-01
    phi[6,8]  R2592     -2.4878877462679727e-01
    phi[6,8]  R2593     -2.5021909983725132e-01
    phi[6,8]  R2594     -6.4320496088939560e-01
    phi[6,8]  R2595     -1.3674970323617885e-01
    phi[6,8]  R2596     -9.1941720326473941e-01
    phi[6,8]  R2597     -1.2229482442091735e+00
    phi[6,8]  R2598     -6.2222368305552278e-01
    phi[6,8]  R2599     -2.4195871393184731e-01
    phi[6,8]  R2600     -1.5104803294196190e+00
    phi[6,8]  R2601     -5.5233522535113888e-01
    phi[6,8]  R2602     -5.4898039599362192e-01
    phi[6,8]  R2603     -3.8256120879709965e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R65       -1
    z[0,1,0]  R66       1
    z[0,1,0]  R79       4.6167784929275513e-01
    z[0,1,0]  R80       7.8284525871276855e-01
    z[0,1,0]  R81       6.0020017623901367e-01
    z[0,1,0]  R82       9.0609920024871826e-01
    z[0,1,0]  R83       7.7066212892532349e-01
    z[0,1,0]  R84       7.3027622699737549e-01
    z[0,1,0]  R85       -2.1502149105072021e-01
    z[0,1,0]  R86       -1.9992746412754059e-01
    z[0,1,0]  R87       -2.9732275009155273e-01
    z[0,1,0]  R88       -4.4450685381889343e-01
    z[0,1,0]  R89       -4.3208426237106323e-01
    z[0,1,0]  R90       -0.336843878030777
    z[0,1,0]  R91       -4.0878662467002869e-01
    z[0,1,0]  R92       -5.3279228508472443e-02
    z[0,1,0]  R93       -4.5024999976158142e-01
    z[0,1,0]  R94       -0.411024808883667
    z[0,1,0]  R95       -4.4169384241104126e-01
    z[0,1,0]  R96       -3.6607587337493896e-01
    z[0,1,0]  R97       -0.486956387758255
    z[0,1,0]  R98       -5.4662817716598511e-01
    z[0,1,0]  R99       0.380811482667923
    z[0,1,0]  R100      2.3891361057758331e-01
    z[0,1,0]  R101      -3.3565676212310791e-01
    z[0,1,0]  R102      -0.596221923828125
    z[0,1,0]  R103      -4.5209968090057373e-01
    z[0,1,0]  R104      -6.1724567413330078e-01
    z[0,1,0]  R105      -4.4862964749336243e-01
    z[0,1,0]  R106      -3.4217828512191772e-01
    z[0,1,0]  R107      -8.4837317466735840e-01
    z[0,1,0]  R108      -7.1159183979034424e-01
    z[0,1,0]  R109      -3.8063347339630127e-02
    z[0,1,0]  R110      2.7389812469482422e-01
    z[0,1,0]  R111      4.2580771446228027e-01
    z[0,1,0]  R112      -0.0927567332983017
    z[0,1,0]  R113      -3.4944143891334534e-01
    z[0,1,0]  R114      -6.5495330095291138e-01
    z[0,1,0]  R115      -4.0727809071540833e-01
    z[0,1,0]  R116      -2.6227793097496033e-01
    z[0,1,0]  R117      -0.287907212972641
    z[0,1,0]  R118      -1.3133455812931061e-01
    z[0,1,0]  R119      3.1992402672767639e-01
    z[0,1,0]  R120      4.3874862790107727e-01
    z[0,1,0]  R121      -5.9243679046630859e-01
    z[0,1,0]  R122      -5.5101764202117920e-01
    z[0,1,0]  R123      -9.2834258079528809e-01
    z[0,1,0]  R124      -8.9895540475845337e-01
    z[0,1,0]  R125      -8.6350661516189575e-01
    z[0,1,0]  R126      -8.3183217048645020e-01
    z[0,1,0]  R127      -8.6382150650024414e-01
    z[0,1,0]  R128      -8.8438612222671509e-01
    z[0,1,0]  R129      -4.3973377346992493e-01
    z[0,1,0]  R130      -4.6908619999885559e-01
    z[0,1,0]  R131      -4.6749472618103027e-01
    z[0,1,0]  R132      -5.9391325712203979e-01
    z[0,1,0]  R133      -0.438795268535614
    z[0,1,0]  R134      6.8099820613861084e-01
    z[0,1,0]  R135      6.4077001810073853e-01
    z[0,1,0]  R136      7.4334591627120972e-01
    z[0,1,0]  R137      5.5163621902465820e-01
    z[0,1,0]  R138      6.8956816196441650e-01
    z[0,1,0]  R139      -4.7952553629875183e-01
    z[0,1,0]  R140      -0.32700115442276
    z[0,1,0]  R141      -2.9756346344947815e-01
    z[0,1,0]  R142      -3.4690535068511963e-01
    z[0,1,0]  R143      -2.8038537502288818e-01
    z[0,1,0]  R144      -4.4638866186141968e-01
    z[0,1,0]  R145      -4.1364064812660217e-01
    z[0,1,0]  R146      -0.2532939016819
    z[0,1,0]  R147      -2.7952659130096436e-01
    z[0,1,0]  R148      -2.2245080769062042e-01
    z[0,1,0]  R149      -3.7676227092742920e-01
    z[0,1,0]  R150      0.478341281414032
    z[0,1,0]  R151      0.676973283290863
    z[0,1,0]  R152      4.4680270552635193e-01
    z[0,1,0]  R153      6.4664644002914429e-01
    z[0,1,0]  R154      5.7975602149963379e-01
    z[0,1,0]  R155      0.586368203163147
    z[0,1,0]  R156      6.0991507768630981e-01
    z[0,1,0]  R157      0.332193523645401
    z[0,1,0]  R158      7.2198235988616943e-01
    z[0,1,0]  R159      1.0257675498723984e-01
    z[0,1,0]  R160      -2.2947709262371063e-01
    z[0,1,0]  R161      -3.6362317204475403e-01
    z[0,1,0]  R162      5.3756457567214966e-01
    z[0,1,0]  R163      -2.9505431652069092e-02
    z[0,1,0]  R164      4.5382156968116760e-01
    z[0,1,0]  R165      2.6670229434967041e-01
    z[0,1,0]  R166      7.3435842990875244e-01
    z[0,1,0]  R167      4.9293899536132812e-01
    z[0,1,0]  R168      6.9068127870559692e-01
    z[0,1,0]  R169      -5.4931193590164185e-01
    z[0,1,0]  R170      -3.8923683762550354e-01
    z[0,1,0]  R171      4.1136839985847473e-01
    z[0,1,0]  R172      -1.7706157639622688e-02
    z[0,1,0]  R173      1.2964147329330444e-01
    z[0,1,0]  R174      2.6234817504882812e-01
    z[0,1,0]  R175      4.7098869085311890e-01
    z[0,1,0]  R176      7.0320379734039307e-01
    z[0,1,0]  R177      4.5568275451660156e-01
    z[0,1,0]  R178      2.2768758237361908e-01
    z[0,1,0]  R179      -7.3867177963256836e-01
    z[0,1,0]  R180      -2.5451815128326416e-01
    z[0,1,0]  R181      -0.0896846279501915
    z[0,1,0]  R182      0.797221302986145
    z[0,1,0]  R183      -4.8959842324256897e-01
    z[0,1,0]  R184      -6.7485976219177246e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R67       -1
    z[0,1,1]  R68       1
    z[0,1,1]  R79       3.9054531604051590e-02
    z[0,1,1]  R80       3.7439472973346710e-02
    z[0,1,1]  R81       -1.7181976139545441e-01
    z[0,1,1]  R82       -2.4567259848117828e-01
    z[0,1,1]  R83       -6.6646635532379150e-02
    z[0,1,1]  R84       -2.4409869313240051e-01
    z[0,1,1]  R85       6.6869288682937622e-01
    z[0,1,1]  R86       0.641991376876831
    z[0,1,1]  R87       6.4558017253875732e-01
    z[0,1,1]  R88       7.9754006862640381e-01
    z[0,1,1]  R89       -8.5053634643554688e-01
    z[0,1,1]  R90       -0.809870183467865
    z[0,1,1]  R91       -0.618388831615448
    z[0,1,1]  R92       -5.5543613433837891e-01
    z[0,1,1]  R93       1.7742255330085754e-01
    z[0,1,1]  R94       3.6569207906723022e-01
    z[0,1,1]  R95       6.3491761684417725e-01
    z[0,1,1]  R96       2.7263557910919189e-01
    z[0,1,1]  R97       6.8682879209518433e-01
    z[0,1,1]  R98       4.4054615497589111e-01
    z[0,1,1]  R99       1.4553695917129517e-01
    z[0,1,1]  R100      -0.0651506707072258
    z[0,1,1]  R101      5.2055299282073975e-01
    z[0,1,1]  R102      4.6442502737045288e-01
    z[0,1,1]  R103      4.3314164876937866e-01
    z[0,1,1]  R104      1.7271231114864349e-01
    z[0,1,1]  R105      4.5343667268753052e-01
    z[0,1,1]  R106      3.5579410195350647e-01
    z[0,1,1]  R107      2.0928426086902618e-01
    z[0,1,1]  R108      4.4348591566085815e-01
    z[0,1,1]  R109      -7.8424614667892456e-01
    z[0,1,1]  R110      6.0361549258232117e-03
    z[0,1,1]  R111      5.5607044696807861e-01
    z[0,1,1]  R112      -6.6846656799316406e-01
    z[0,1,1]  R113      0.676803469657898
    z[0,1,1]  R114      5.2576822042465210e-01
    z[0,1,1]  R115      5.8075463771820068e-01
    z[0,1,1]  R116      3.6867663729935884e-03
    z[0,1,1]  R117      0.217891663312912
    z[0,1,1]  R118      1.5251954086124897e-02
    z[0,1,1]  R119      0.296316534280777
    z[0,1,1]  R120      2.5337365269660950e-01
    z[0,1,1]  R121      4.2025262117385864e-01
    z[0,1,1]  R122      0.671235203742981
    z[0,1,1]  R123      1.3216313719749451e-01
    z[0,1,1]  R124      1.7424921691417694e-01
    z[0,1,1]  R125      1.6426555812358856e-01
    z[0,1,1]  R126      0.107903391122818
    z[0,1,1]  R127      2.5297647714614868e-01
    z[0,1,1]  R128      2.3614084720611572e-01
    z[0,1,1]  R129      7.0582723617553711e-01
    z[0,1,1]  R130      7.4835884571075439e-01
    z[0,1,1]  R131      6.4602726697921753e-01
    z[0,1,1]  R132      4.0355780720710754e-01
    z[0,1,1]  R133      2.8929588198661804e-01
    z[0,1,1]  R134      -1.5599606931209564e-01
    z[0,1,1]  R135      -2.5938186049461365e-01
    z[0,1,1]  R136      -2.8838065266609192e-01
    z[0,1,1]  R137      -2.6488536596298218e-01
    z[0,1,1]  R138      -1.8207627534866333e-01
    z[0,1,1]  R139      -0.722950279712677
    z[0,1,1]  R140      -7.9297041893005371e-01
    z[0,1,1]  R141      -8.1031274795532227e-01
    z[0,1,1]  R142      -7.6446080207824707e-01
    z[0,1,1]  R143      -0.84675532579422
    z[0,1,1]  R144      -6.3792812824249268e-01
    z[0,1,1]  R145      -6.0679459571838379e-01
    z[0,1,1]  R146      -6.9677561521530151e-01
    z[0,1,1]  R147      -6.4049822092056274e-01
    z[0,1,1]  R148      -7.5996285676956177e-01
    z[0,1,1]  R149      3.1034144759178162e-01
    z[0,1,1]  R150      6.3583391904830933e-01
    z[0,1,1]  R151      0.596767783164978
    z[0,1,1]  R152      7.8609246015548706e-01
    z[0,1,1]  R153      5.6476938724517822e-01
    z[0,1,1]  R154      4.8868107795715332e-01
    z[0,1,1]  R155      3.9729556441307068e-01
    z[0,1,1]  R156      6.6568471491336823e-02
    z[0,1,1]  R157      -1.3944588601589203e-02
    z[0,1,1]  R158      1.3699467480182648e-01
    z[0,1,1]  R159      -7.8468644618988037e-01
    z[0,1,1]  R160      3.0972850322723389e-01
    z[0,1,1]  R161      2.8695744276046753e-01
    z[0,1,1]  R162      1.9082698225975037e-01
    z[0,1,1]  R163      4.2503336071968079e-01
    z[0,1,1]  R164      -9.7298972308635712e-02
    z[0,1,1]  R165      -1.1420476436614990e-01
    z[0,1,1]  R166      1.7754136025905609e-01
    z[0,1,1]  R167      -2.3391132056713104e-01
    z[0,1,1]  R168      2.2367011010646820e-01
    z[0,1,1]  R169      2.0922964811325073e-01
    z[0,1,1]  R170      3.7760722637176514e-01
    z[0,1,1]  R171      -3.3757331967353821e-01
    z[0,1,1]  R172      5.3565579652786255e-01
    z[0,1,1]  R173      5.6941163539886475e-01
    z[0,1,1]  R174      8.3352994918823242e-01
    z[0,1,1]  R175      3.5133186727762222e-02
    z[0,1,1]  R176      7.6741680502891541e-02
    z[0,1,1]  R177      -2.1169431507587433e-02
    z[0,1,1]  R178      -1.0548040270805359e-01
    z[0,1,1]  R179      3.7100705504417419e-01
    z[0,1,1]  R180      6.1308199167251587e-01
    z[0,1,1]  R181      3.0658674240112305e-01
    z[0,1,1]  R182      2.2164407372474670e-01
    z[0,1,1]  R183      7.7359803020954132e-02
    z[0,1,1]  R184      1.0380051285028458e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R69       -1
    z[0,1,2]  R70       1
    z[0,1,2]  R79       2.6861715316772461e-01
    z[0,1,2]  R80       1.8759402632713318e-01
    z[0,1,2]  R81       1.9993208348751068e-01
    z[0,1,2]  R82       1.0501673817634583e-01
    z[0,1,2]  R83       2.3561078310012817e-01
    z[0,1,2]  R84       7.7200238592922688e-03
    z[0,1,2]  R85       -4.9707639217376709e-01
    z[0,1,2]  R86       -6.7353487014770508e-01
    z[0,1,2]  R87       -5.8032989501953125e-01
    z[0,1,2]  R88       -2.3401589691638947e-01
    z[0,1,2]  R89       -0.0516057126224041
    z[0,1,2]  R90       -2.6388362050056458e-01
    z[0,1,2]  R91       -2.0872253924608231e-02
    z[0,1,2]  R92       -3.9774301648139954e-01
    z[0,1,2]  R93       -3.9278933405876160e-01
    z[0,1,2]  R94       -1.7736141383647919e-01
    z[0,1,2]  R95       1.3082201778888702e-01
    z[0,1,2]  R96       -2.7695167064666748e-01
    z[0,1,2]  R97       1.1234810948371887e-01
    z[0,1,2]  R98       -7.2845116257667542e-02
    z[0,1,2]  R99       -4.1306439042091370e-01
    z[0,1,2]  R100      -4.2743068933486938e-01
    z[0,1,2]  R101      -4.4957584142684937e-01
    z[0,1,2]  R102      -1.5730418264865875e-01
    z[0,1,2]  R103      -3.3564716577529907e-01
    z[0,1,2]  R104      -1.3083352148532867e-01
    z[0,1,2]  R105      -1.7925995588302612e-01
    z[0,1,2]  R106      -6.5206638537347317e-03
    z[0,1,2]  R107      -2.4681134521961212e-01
    z[0,1,2]  R108      2.3112552240490913e-02
    z[0,1,2]  R109      -2.1220695972442627e-01
    z[0,1,2]  R110      -3.7491649389266968e-01
    z[0,1,2]  R111      -2.3035834729671478e-01
    z[0,1,2]  R112      -3.4647712111473083e-01
    z[0,1,2]  R113      -1.5503384172916412e-01
    z[0,1,2]  R114      -4.0012553334236145e-01
    z[0,1,2]  R115      7.5143299996852875e-02
    z[0,1,2]  R116      -6.7475301027297974e-01
    z[0,1,2]  R117      -2.6001867651939392e-01
    z[0,1,2]  R118      -8.0907016992568970e-01
    z[0,1,2]  R119      -1.3702294230461121e-01
    z[0,1,2]  R120      -3.8953217864036560e-01
    z[0,1,2]  R121      -4.6181124448776245e-01
    z[0,1,2]  R122      -2.3660619556903839e-01
    z[0,1,2]  R123      -2.6832882314920425e-02
    z[0,1,2]  R124      2.9775089025497437e-01
    z[0,1,2]  R125      2.6385051012039185e-01
    z[0,1,2]  R126      3.8567009568214417e-01
    z[0,1,2]  R127      7.4455849826335907e-02
    z[0,1,2]  R128      8.8931880891323090e-02
    z[0,1,2]  R129      -0.229117289185524
    z[0,1,2]  R130      -2.6490619778633118e-01
    z[0,1,2]  R131      -4.8827031254768372e-01
    z[0,1,2]  R132      -5.6621521711349487e-01
    z[0,1,2]  R133      -1.5989576280117035e-01
    z[0,1,2]  R134      2.4967324733734131e-01
    z[0,1,2]  R135      3.6085703969001770e-01
    z[0,1,2]  R136      5.2071553468704224e-01
    z[0,1,2]  R137      1.2483359873294830e-01
    z[0,1,2]  R138      5.2010452747344971e-01
    z[0,1,2]  R139      -9.7651155665516853e-03
    z[0,1,2]  R140      -3.0187508463859558e-01
    z[0,1,2]  R141      -2.5007483363151550e-01
    z[0,1,2]  R142      -1.1067414283752441e-01
    z[0,1,2]  R143      -1.7438901960849762e-01
    z[0,1,2]  R144      -1.1787618696689606e-01
    z[0,1,2]  R145      4.9787878990173340e-02
    z[0,1,2]  R146      -2.6266448199748993e-02
    z[0,1,2]  R147      -0.0127011863514781
    z[0,1,2]  R148      1.0693140327930450e-01
    z[0,1,2]  R149      -2.6498275995254517e-01
    z[0,1,2]  R150      -3.5252094268798828e-01
    z[0,1,2]  R151      -2.2569186985492706e-01
    z[0,1,2]  R152      0.0648149698972702
    z[0,1,2]  R153      0.0210171639919281
    z[0,1,2]  R154      1.3366617262363434e-02
    z[0,1,2]  R155      -1.1218158155679703e-01
    z[0,1,2]  R156      9.2862747609615326e-02
    z[0,1,2]  R157      6.3014000654220581e-01
    z[0,1,2]  R158      2.3018909990787506e-01
    z[0,1,2]  R159      6.6623359918594360e-02
    z[0,1,2]  R160      1.4183364808559418e-01
    z[0,1,2]  R161      -2.5261448696255684e-02
    z[0,1,2]  R162      -0.235975444316864
    z[0,1,2]  R163      -8.3938531577587128e-02
    z[0,1,2]  R164      9.7031831741333008e-02
    z[0,1,2]  R165      5.5120289325714111e-01
    z[0,1,2]  R166      3.6256012320518494e-01
    z[0,1,2]  R167      0.472822368144989
    z[0,1,2]  R168      0.268179327249527
    z[0,1,2]  R169      -2.5414398312568665e-01
    z[0,1,2]  R170      1.1739699542522430e-01
    z[0,1,2]  R171      1.4202952384948730e-01
    z[0,1,2]  R172      -1.2348987907171249e-01
    z[0,1,2]  R173      -3.3790859580039978e-01
    z[0,1,2]  R174      -1.2669317424297333e-01
    z[0,1,2]  R175      -6.8267039954662323e-02
    z[0,1,2]  R176      2.3709677159786224e-01
    z[0,1,2]  R177      -3.4693825244903564e-01
    z[0,1,2]  R178      6.3916486501693726e-01
    z[0,1,2]  R179      -3.9355117082595825e-01
    z[0,1,2]  R180      -1.1480126529932022e-02
    z[0,1,2]  R181      1.7177364230155945e-01
    z[0,1,2]  R182      3.8163551688194275e-01
    z[0,1,2]  R183      3.4038397669792175e-01
    z[0,1,2]  R184      0.566510021686554
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R71       -1
    z[0,1,3]  R72       1
    z[0,1,3]  R79       -1.6876442730426788e-01
    z[0,1,3]  R80       5.1429289579391479e-01
    z[0,1,3]  R81       -8.7289996445178986e-02
    z[0,1,3]  R82       -2.4192532896995544e-01
    z[0,1,3]  R83       -4.4740411639213562e-01
    z[0,1,3]  R84       3.8083219528198242e-01
    z[0,1,3]  R85       -2.1674276888370514e-01
    z[0,1,3]  R86       1.8280692398548126e-01
    z[0,1,3]  R87       -2.6684349775314331e-01
    z[0,1,3]  R88       5.5397957563400269e-02
    z[0,1,3]  R89       -2.0918834209442139e-01
    z[0,1,3]  R90       2.2222478687763214e-01
    z[0,1,3]  R91       -4.6384656429290771e-01
    z[0,1,3]  R92       -0.0847087875008583
    z[0,1,3]  R93       -2.8722891211509705e-01
    z[0,1,3]  R94       5.7033807039260864e-02
    z[0,1,3]  R95       -6.4385481178760529e-02
    z[0,1,3]  R96       -1.3314920663833618e-01
    z[0,1,3]  R97       -3.4458611160516739e-02
    z[0,1,3]  R98       -7.0325643755495548e-03
    z[0,1,3]  R99       2.3071725666522980e-01
    z[0,1,3]  R100      -6.8104617297649384e-02
    z[0,1,3]  R101      -9.5689199864864349e-02
    z[0,1,3]  R102      -1.5826018154621124e-01
    z[0,1,3]  R103      3.8550609350204468e-01
    z[0,1,3]  R104      -1.1226285994052887e-01
    z[0,1,3]  R105      2.6194056868553162e-01
    z[0,1,3]  R106      -5.7582074403762817e-01
    z[0,1,3]  R107      7.0373013615608215e-02
    z[0,1,3]  R108      -4.8064935207366943e-01
    z[0,1,3]  R109      1.9869594275951385e-01
    z[0,1,3]  R110      -1.7554265260696411e-01
    z[0,1,3]  R111      1.9822651520371437e-03
    z[0,1,3]  R112      3.7127229571342468e-01
    z[0,1,3]  R113      -1.6969843208789825e-01
    z[0,1,3]  R114      2.9292061924934387e-01
    z[0,1,3]  R115      -5.5232882499694824e-01
    z[0,1,3]  R116      2.0609617233276367e-01
    z[0,1,3]  R117      -8.0671662092208862e-01
    z[0,1,3]  R118      -4.1146126389503479e-01
    z[0,1,3]  R119      -4.6740320324897766e-01
    z[0,1,3]  R120      1.6549223661422729e-01
    z[0,1,3]  R121      2.2901932895183563e-01
    z[0,1,3]  R122      8.8411066681146622e-03
    z[0,1,3]  R123      2.8512412309646606e-01
    z[0,1,3]  R124      1.3275374472141266e-01
    z[0,1,3]  R125      -6.2729187309741974e-02
    z[0,1,3]  R126      3.4456110000610352e-01
    z[0,1,3]  R127      2.3610265552997589e-01
    z[0,1,3]  R128      1.9028577953577042e-02
    z[0,1,3]  R129      -2.9019543528556824e-01
    z[0,1,3]  R130      5.7496611028909683e-02
    z[0,1,3]  R131      -7.3940992355346680e-02
    z[0,1,3]  R132      2.4332102388143539e-02
    z[0,1,3]  R133      -8.6339443922042847e-02
    z[0,1,3]  R134      0.651769757270813
    z[0,1,3]  R135      5.7279855012893677e-01
    z[0,1,3]  R136      2.7020815014839172e-01
    z[0,1,3]  R137      6.3380479812622070e-01
    z[0,1,3]  R138      3.6046424508094788e-01
    z[0,1,3]  R139      -0.477079302072525
    z[0,1,3]  R140      6.7505910992622375e-02
    z[0,1,3]  R141      2.5140070915222168e-01
    z[0,1,3]  R142      -1.8602685630321503e-01
    z[0,1,3]  R143      -2.1406927704811096e-01
    z[0,1,3]  R144      -2.8279563784599304e-01
    z[0,1,3]  R145      -0.0956747829914093
    z[0,1,3]  R146      -2.6482401415705681e-02
    z[0,1,3]  R147      -1.0606414824724197e-01
    z[0,1,3]  R148      1.4834043383598328e-01
    z[0,1,3]  R149      -3.7804111838340759e-01
    z[0,1,3]  R150      3.8450878858566284e-01
    z[0,1,3]  R151      0.0953054204583168
    z[0,1,3]  R152      1.9266439601778984e-02
    z[0,1,3]  R153      -3.2006785273551941e-01
    z[0,1,3]  R154      -3.1716409325599670e-01
    z[0,1,3]  R155      -2.4189472198486328e-01
    z[0,1,3]  R156      -4.9281543493270874e-01
    z[0,1,3]  R157      -4.6805629134178162e-01
    z[0,1,3]  R158      1.9967010244727135e-02
    z[0,1,3]  R159      -2.6093193888664246e-01
    z[0,1,3]  R160      -6.8618077039718628e-01
    z[0,1,3]  R161      -1.8147185444831848e-01
    z[0,1,3]  R162      -4.9503338336944580e-01
    z[0,1,3]  R163      -7.3967504501342773e-01
    z[0,1,3]  R164      5.1183837652206421e-01
    z[0,1,3]  R165      -4.9407193064689636e-01
    z[0,1,3]  R166      -1.5420243144035339e-01
    z[0,1,3]  R167      -5.0213855504989624e-01
    z[0,1,3]  R168      3.4624069929122925e-02
    z[0,1,3]  R169      -0.486905038356781
    z[0,1,3]  R170      -5.1858031749725342e-01
    z[0,1,3]  R171      7.9279178380966187e-01
    z[0,1,3]  R172      -6.5510874986648560e-01
    z[0,1,3]  R173      2.9931154847145081e-01
    z[0,1,3]  R174      2.2582674026489258e-01
    z[0,1,3]  R175      -0.532409131526947
    z[0,1,3]  R176      1.1730780452489853e-01
    z[0,1,3]  R177      -2.9757568240165710e-01
    z[0,1,3]  R178      -6.3120013475418091e-01
    z[0,1,3]  R179      -2.8670126199722290e-01
    z[0,1,3]  R180      -4.9086907505989075e-01
    z[0,1,3]  R181      -9.2673414945602417e-01
    z[0,1,3]  R182      3.7704259157180786e-02
    z[0,1,3]  R183      5.6681799888610840e-01
    z[0,1,3]  R184      2.9143935441970825e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R73       -1
    z[0,1,4]  R74       1
    z[0,1,4]  R79       1.1649116128683090e-01
    z[0,1,4]  R80       1.9057299196720123e-01
    z[0,1,4]  R81       2.0229449868202209e-01
    z[0,1,4]  R82       9.8868263885378838e-03
    z[0,1,4]  R83       -3.6068853735923767e-01
    z[0,1,4]  R84       -4.6930167078971863e-01
    z[0,1,4]  R85       3.1903919577598572e-01
    z[0,1,4]  R86       -9.6473604440689087e-02
    z[0,1,4]  R87       3.9080940186977386e-03
    z[0,1,4]  R88       2.9522275924682617e-01
    z[0,1,4]  R89       2.0334189757704735e-02
    z[0,1,4]  R90       2.8387141227722168e-01
    z[0,1,4]  R91       4.8437470197677612e-01
    z[0,1,4]  R92       6.2884253263473511e-01
    z[0,1,4]  R93       1.2406851351261139e-01
    z[0,1,4]  R94       -2.5360816717147827e-01
    z[0,1,4]  R95       -0.281288206577301
    z[0,1,4]  R96       -4.3320730328559875e-01
    z[0,1,4]  R97       2.9039615765213966e-02
    z[0,1,4]  R98       -2.8913456201553345e-01
    z[0,1,4]  R99       -5.8810006827116013e-02
    z[0,1,4]  R100      6.2225043773651123e-01
    z[0,1,4]  R101      -0.0938170999288559
    z[0,1,4]  R102      3.7507492303848267e-01
    z[0,1,4]  R103      4.4238457083702087e-01
    z[0,1,4]  R104      -1.0518613457679749e-01
    z[0,1,4]  R105      -3.6167246103286743e-01
    z[0,1,4]  R106      1.1317305266857147e-01
    z[0,1,4]  R107      -3.1123054027557373e-01
    z[0,1,4]  R108      -2.2253684699535370e-01
    z[0,1,4]  R109      -2.4853645265102386e-01
    z[0,1,4]  R110      4.9042135477066040e-01
    z[0,1,4]  R111      4.3059471249580383e-01
    z[0,1,4]  R112      -3.4301328659057617e-01
    z[0,1,4]  R113      -3.3631703257560730e-01
    z[0,1,4]  R114      -4.0257643908262253e-02
    z[0,1,4]  R115      2.7994525432586670e-01
    z[0,1,4]  R116      1.3417159020900726e-01
    z[0,1,4]  R117      -1.6669304668903351e-01
    z[0,1,4]  R118      -9.8640426993370056e-02
    z[0,1,4]  R119      5.5449718236923218e-01
    z[0,1,4]  R120      5.5251830816268921e-01
    z[0,1,4]  R121      1.8550334870815277e-01
    z[0,1,4]  R122      3.8085004687309265e-01
    z[0,1,4]  R123      -1.7400009930133820e-01
    z[0,1,4]  R124      -1.8838274478912354e-01
    z[0,1,4]  R125      -1.2845905125141144e-01
    z[0,1,4]  R126      1.1475032567977905e-01
    z[0,1,4]  R127      8.3073377609252930e-02
    z[0,1,4]  R128      -3.0021220445632935e-01
    z[0,1,4]  R129      3.8261204957962036e-01
    z[0,1,4]  R130      2.7791008353233337e-01
    z[0,1,4]  R131      -2.3422902822494507e-01
    z[0,1,4]  R132      1.0998079180717468e-01
    z[0,1,4]  R133      2.4276715517044067e-01
    z[0,1,4]  R134      -1.1566183716058731e-01
    z[0,1,4]  R135      2.1666100621223450e-01
    z[0,1,4]  R136      1.3682533800601959e-01
    z[0,1,4]  R137      1.9600607454776764e-01
    z[0,1,4]  R138      1.7497076094150543e-01
    z[0,1,4]  R139      1.1299677938222885e-01
    z[0,1,4]  R140      -2.8302571736276150e-03
    z[0,1,4]  R141      0.0761076956987381
    z[0,1,4]  R142      1.3485226035118103e-01
    z[0,1,4]  R143      -2.3401015996932983e-01
    z[0,1,4]  R144      -2.5529021024703979e-01
    z[0,1,4]  R145      0.527223527431488
    z[0,1,4]  R146      0.502944827079773
    z[0,1,4]  R147      -4.3249884247779846e-01
    z[0,1,4]  R148      -2.5453118607401848e-02
    z[0,1,4]  R149      -2.4937191605567932e-01
    z[0,1,4]  R150      2.9429266229271889e-02
    z[0,1,4]  R151      -3.4854507446289062e-01
    z[0,1,4]  R152      -2.5800922513008118e-01
    z[0,1,4]  R153      -3.9282381534576416e-01
    z[0,1,4]  R154      -2.5062489509582520e-01
    z[0,1,4]  R155      -1.2206542491912842e-01
    z[0,1,4]  R156      5.1436161994934082e-01
    z[0,1,4]  R157      4.3308654427528381e-01
    z[0,1,4]  R158      -3.2065966725349426e-01
    z[0,1,4]  R159      -5.4726237058639526e-01
    z[0,1,4]  R160      -6.7449599504470825e-02
    z[0,1,4]  R161      2.1403318643569946e-01
    z[0,1,4]  R162      -6.9757483899593353e-02
    z[0,1,4]  R163      -3.9082175493240356e-01
    z[0,1,4]  R164      -2.1698732674121857e-01
    z[0,1,4]  R165      0.505648136138916
    z[0,1,4]  R166      -3.4428441524505615e-01
    z[0,1,4]  R167      1.7090511322021484e-01
    z[0,1,4]  R168      -4.8727640509605408e-01
    z[0,1,4]  R169      -1.2089670449495316e-01
    z[0,1,4]  R170      0.221050426363945
    z[0,1,4]  R171      2.1512087434530258e-02
    z[0,1,4]  R172      -3.7427493929862976e-01
    z[0,1,4]  R173      2.4408282712101936e-02
    z[0,1,4]  R174      -3.5382375121116638e-01
    z[0,1,4]  R175      6.8781822919845581e-01
    z[0,1,4]  R176      -4.4453686475753784e-01
    z[0,1,4]  R177      6.4020842313766479e-01
    z[0,1,4]  R178      4.1498217731714249e-02
    z[0,1,4]  R179      1.1063133925199509e-01
    z[0,1,4]  R180      -9.9658809602260590e-02
    z[0,1,4]  R181      -0.0842304676771164
    z[0,1,4]  R182      -2.4974401295185089e-01
    z[0,1,4]  R183      -3.1321346759796143e-01
    z[0,1,4]  R184      -1.9275777041912079e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R75       -1
    z[0,1,5]  R76       1
    z[0,1,5]  R79       -7.4515056610107422e-01
    z[0,1,5]  R80       -2.1487425267696381e-01
    z[0,1,5]  R81       0.00630249222740531
    z[0,1,5]  R82       -2.1305792033672333e-01
    z[0,1,5]  R83       5.0106555223464966e-02
    z[0,1,5]  R84       -1.7384263873100281e-01
    z[0,1,5]  R85       1.6594673693180084e-01
    z[0,1,5]  R86       2.0208194851875305e-01
    z[0,1,5]  R87       2.1927194669842720e-02
    z[0,1,5]  R88       -1.9410748034715652e-02
    z[0,1,5]  R89       -1.5323872864246368e-01
    z[0,1,5]  R90       -1.7595407366752625e-01
    z[0,1,5]  R91       -1.3384682126343250e-02
    z[0,1,5]  R92       2.3417235910892487e-01
    z[0,1,5]  R93       5.7139742374420166e-01
    z[0,1,5]  R94       6.7183399200439453e-01
    z[0,1,5]  R95       4.9277597665786743e-01
    z[0,1,5]  R96       7.1126115322113037e-01
    z[0,1,5]  R97       4.1232302784919739e-01
    z[0,1,5]  R98       6.3492357730865479e-01
    z[0,1,5]  R99       3.4589615464210510e-01
    z[0,1,5]  R100      2.6017433404922485e-01
    z[0,1,5]  R101      5.0373071432113647e-01
    z[0,1,5]  R102      4.5085495710372925e-01
    z[0,1,5]  R103      3.8269010186195374e-01
    z[0,1,5]  R104      7.3813176155090332e-01
    z[0,1,5]  R105      5.6638425588607788e-01
    z[0,1,5]  R106      4.4393953680992126e-01
    z[0,1,5]  R107      -2.7090549468994141e-01
    z[0,1,5]  R108      -1.2551090121269226e-01
    z[0,1,5]  R109      4.4402226805686951e-01
    z[0,1,5]  R110      0.276623398065567
    z[0,1,5]  R111      5.0560760498046875e-01
    z[0,1,5]  R112      8.9275732636451721e-02
    z[0,1,5]  R113      4.5141872763633728e-01
    z[0,1,5]  R114      1.6238547861576080e-01
    z[0,1,5]  R115      1.7913152277469635e-01
    z[0,1,5]  R116      0.611366331577301
    z[0,1,5]  R117      3.3558952808380127e-01
    z[0,1,5]  R118      -2.5231644511222839e-01
    z[0,1,5]  R119      3.2803300023078918e-01
    z[0,1,5]  R120      4.8965471982955933e-01
    z[0,1,5]  R121      4.1253602504730225e-01
    z[0,1,5]  R122      1.4516760408878326e-01
    z[0,1,5]  R123      1.7920201644301414e-02
    z[0,1,5]  R124      -1.0084106028079987e-01
    z[0,1,5]  R125      -1.7986075580120087e-01
    z[0,1,5]  R126      -3.4360468387603760e-02
    z[0,1,5]  R127      -3.2862797379493713e-01
    z[0,1,5]  R128      -1.3820065557956696e-01
    z[0,1,5]  R129      -1.3069508969783783e-01
    z[0,1,5]  R130      4.7280009835958481e-02
    z[0,1,5]  R131      -2.4256812036037445e-01
    z[0,1,5]  R132      1.0398554056882858e-01
    z[0,1,5]  R133      -0.625950813293457
    z[0,1,5]  R134      1.0464450716972351e-01
    z[0,1,5]  R135      -1.2760579586029053e-01
    z[0,1,5]  R136      2.7487901970744133e-02
    z[0,1,5]  R137      -1.0926242172718048e-01
    z[0,1,5]  R138      -9.2612817883491516e-02
    z[0,1,5]  R139      6.8953827023506165e-02
    z[0,1,5]  R140      -2.0019227266311646e-01
    z[0,1,5]  R141      -3.3036354184150696e-01
    z[0,1,5]  R142      -4.7876381874084473e-01
    z[0,1,5]  R143      5.3922671824693680e-02
    z[0,1,5]  R144      -0.264121949672699
    z[0,1,5]  R145      4.1039773821830750e-01
    z[0,1,5]  R146      1.3205060362815857e-01
    z[0,1,5]  R147      0.194817915558815
    z[0,1,5]  R148      1.7538410425186157e-01
    z[0,1,5]  R149      6.4642357826232910e-01
    z[0,1,5]  R150      -2.8103792667388916e-01
    z[0,1,5]  R151      7.0109167136251926e-03
    z[0,1,5]  R152      2.3674240708351135e-01
    z[0,1,5]  R153      7.5311444699764252e-02
    z[0,1,5]  R154      -2.9498040676116943e-02
    z[0,1,5]  R155      -6.6754192113876343e-02
    z[0,1,5]  R156      3.2755106687545776e-01
    z[0,1,5]  R157      2.3541361093521118e-01
    z[0,1,5]  R158      -5.1162582635879517e-01
    z[0,1,5]  R159      -2.5592150166630745e-02
    z[0,1,5]  R160      -3.0405440926551819e-01
    z[0,1,5]  R161      8.3945882320404053e-01
    z[0,1,5]  R162      -6.0283303260803223e-01
    z[0,1,5]  R163      -5.3239960223436356e-02
    z[0,1,5]  R164      -6.1507624387741089e-01
    z[0,1,5]  R165      -3.1253370642662048e-01
    z[0,1,5]  R166      -3.9272478222846985e-01
    z[0,1,5]  R167      -3.5361361503601074e-01
    z[0,1,5]  R168      -3.8169774413108826e-01
    z[0,1,5]  R169      5.6845819950103760e-01
    z[0,1,5]  R170      5.1635706424713135e-01
    z[0,1,5]  R171      -1.0229671746492386e-01
    z[0,1,5]  R172      -5.7824570685625076e-02
    z[0,1,5]  R173      -2.8982567787170410e-01
    z[0,1,5]  R174      1.9826823472976685e-01
    z[0,1,5]  R175      9.6248477697372437e-02
    z[0,1,5]  R176      -4.8029392957687378e-01
    z[0,1,5]  R177      4.1570165753364563e-01
    z[0,1,5]  R178      -3.5506728291511536e-01
    z[0,1,5]  R179      2.5812932848930359e-01
    z[0,1,5]  R180      -2.9577055573463440e-01
    z[0,1,5]  R181      1.9396256655454636e-02
    z[0,1,5]  R182      -3.2449653744697571e-01
    z[0,1,5]  R183      4.2761421203613281e-01
    z[0,1,5]  R184      -1.7201507091522217e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R77       -1
    z[0,1,6]  R78       1
    z[0,1,6]  R79       3.4039998054504395e-01
    z[0,1,6]  R80       5.9781733900308609e-02
    z[0,1,6]  R81       -0.722275972366333
    z[0,1,6]  R82       5.9845127165317535e-02
    z[0,1,6]  R83       1.1553537100553513e-01
    z[0,1,6]  R84       -1.0749082267284393e-01
    z[0,1,6]  R85       2.8849408030509949e-01
    z[0,1,6]  R86       1.0326829552650452e-01
    z[0,1,6]  R87       2.9383847117424011e-01
    z[0,1,6]  R88       1.4483739435672760e-01
    z[0,1,6]  R89       1.3990125060081482e-01
    z[0,1,6]  R90       9.2209856957197189e-03
    z[0,1,6]  R91       -1.0074402205646038e-02
    z[0,1,6]  R92       2.7018001675605774e-01
    z[0,1,6]  R93       -4.3257862329483032e-01
    z[0,1,6]  R94       -3.8332757353782654e-01
    z[0,1,6]  R95       -2.4202281236648560e-01
    z[0,1,6]  R96       6.0550529509782791e-02
    z[0,1,6]  R97       -3.2630729675292969e-01
    z[0,1,6]  R98       1.2261397391557693e-01
    z[0,1,6]  R99       6.9774365425109863e-01
    z[0,1,6]  R100      5.4447591304779053e-01
    z[0,1,6]  R101      -3.7754201889038086e-01
    z[0,1,6]  R102      1.8731378018856049e-01
    z[0,1,6]  R103      -6.7560456693172455e-02
    z[0,1,6]  R104      5.9625748544931412e-02
    z[0,1,6]  R105      0.201944500207901
    z[0,1,6]  R106      4.6348896622657776e-01
    z[0,1,6]  R107      1.8456105142831802e-02
    z[0,1,6]  R108      -1.1119223199784756e-02
    z[0,1,6]  R109      -2.0017798244953156e-01
    z[0,1,6]  R110      6.6070586442947388e-01
    z[0,1,6]  R111      1.2391008436679840e-01
    z[0,1,6]  R112      4.0128645300865173e-01
    z[0,1,6]  R113      2.2384525835514069e-01
    z[0,1,6]  R114      1.4391423761844635e-01
    z[0,1,6]  R115      2.7509528398513794e-01
    z[0,1,6]  R116      -2.0410434901714325e-01
    z[0,1,6]  R117      -1.0403953492641449e-01
    z[0,1,6]  R118      -2.9194223880767822e-01
    z[0,1,6]  R119      3.9690226316452026e-01
    z[0,1,6]  R120      1.3834813237190247e-01
    z[0,1,6]  R121      4.5711182057857513e-02
    z[0,1,6]  R122      -1.5375925600528717e-01
    z[0,1,6]  R123      -8.9999385178089142e-02
    z[0,1,6]  R124      -9.7879678010940552e-02
    z[0,1,6]  R125      -3.2398992776870728e-01
    z[0,1,6]  R126      -1.2083017081022263e-01
    z[0,1,6]  R127      -1.1674593389034271e-01
    z[0,1,6]  R128      2.1118935942649841e-01
    z[0,1,6]  R129      9.0889401733875275e-02
    z[0,1,6]  R130      -2.5877895951271057e-01
    z[0,1,6]  R131      -8.0745331943035126e-02
    z[0,1,6]  R132      0.374576598405838
    z[0,1,6]  R133      -4.8989301919937134e-01
    z[0,1,6]  R134      2.0928401499986649e-02
    z[0,1,6]  R135      -2.4365289136767387e-02
    z[0,1,6]  R136      2.5289552286267281e-02
    z[0,1,6]  R137      3.9734715223312378e-01
    z[0,1,6]  R138      -2.2739601135253906e-01
    z[0,1,6]  R139      -0.0466383658349514
    z[0,1,6]  R140      3.5846567153930664e-01
    z[0,1,6]  R141      1.1906799674034119e-01
    z[0,1,6]  R142      3.1650140881538391e-02
    z[0,1,6]  R143      2.6548784971237183e-01
    z[0,1,6]  R144      -0.406181275844574
    z[0,1,6]  R145      5.1750767976045609e-02
    z[0,1,6]  R146      4.2256820201873779e-01
    z[0,1,6]  R147      -5.2460145950317383e-01
    z[0,1,6]  R148      -5.5509054660797119e-01
    z[0,1,6]  R149      2.6183506846427917e-01
    z[0,1,6]  R150      -1.2222281098365784e-01
    z[0,1,6]  R151      6.3423417508602142e-02
    z[0,1,6]  R152      2.3502789437770844e-01
    z[0,1,6]  R153      -0.00405834149569273
    z[0,1,6]  R154      -5.1050871610641479e-01
    z[0,1,6]  R155      0.63865065574646
    z[0,1,6]  R156      -1.4969493262469769e-02
    z[0,1,6]  R157      -1.7411597073078156e-01
    z[0,1,6]  R158      2.0495028793811798e-01
    z[0,1,6]  R159      3.2708659768104553e-02
    z[0,1,6]  R160      -5.1327300071716309e-01
    z[0,1,6]  R161      -3.6908425390720367e-02
    z[0,1,6]  R162      7.4787355959415436e-02
    z[0,1,6]  R163      3.2975021004676819e-01
    z[0,1,6]  R164      -2.9628169536590576e-01
    z[0,1,6]  R165      -1.2057397514581680e-01
    z[0,1,6]  R166      3.4699384123086929e-02
    z[0,1,6]  R167      0.268963485956192
    z[0,1,6]  R168      -1.2915319204330444e-01
    z[0,1,6]  R169      1.2269077450037003e-01
    z[0,1,6]  R170      -3.2819494605064392e-01
    z[0,1,6]  R171      -2.3916883766651154e-01
    z[0,1,6]  R172      3.5343545675277710e-01
    z[0,1,6]  R173      6.0876852273941040e-01
    z[0,1,6]  R174      6.9648787379264832e-02
    z[0,1,6]  R175      8.0360412597656250e-02
    z[0,1,6]  R176      -0.0366581492125988
    z[0,1,6]  R177      1.7690800130367279e-02
    z[0,1,6]  R178      4.7874860465526581e-02
    z[0,1,6]  R179      -2.7707897126674652e-02
    z[0,1,6]  R180      -4.6995177865028381e-01
    z[0,1,6]  R181      4.6346601098775864e-02
    z[0,1,6]  R182      2.3973459377884865e-02
    z[0,1,6]  R183      0.190284863114357
    z[0,1,6]  R184      2.4733503162860870e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R185      -1
    z[1,0,0]  R186      1
    z[1,0,0]  R199      -4.3973377346992493e-01
    z[1,0,0]  R200      -4.6908619999885559e-01
    z[1,0,0]  R201      -4.6749472618103027e-01
    z[1,0,0]  R202      -5.9391325712203979e-01
    z[1,0,0]  R203      -0.438795268535614
    z[1,0,0]  R204      6.8099820613861084e-01
    z[1,0,0]  R205      6.4077001810073853e-01
    z[1,0,0]  R206      7.4334591627120972e-01
    z[1,0,0]  R207      5.5163621902465820e-01
    z[1,0,0]  R208      6.8956816196441650e-01
    z[1,0,0]  R209      -4.7952553629875183e-01
    z[1,0,0]  R210      -0.32700115442276
    z[1,0,0]  R211      -2.9756346344947815e-01
    z[1,0,0]  R212      -3.4690535068511963e-01
    z[1,0,0]  R213      -2.8038537502288818e-01
    z[1,0,0]  R214      -4.4638866186141968e-01
    z[1,0,0]  R215      -4.1364064812660217e-01
    z[1,0,0]  R216      -0.2532939016819
    z[1,0,0]  R217      -2.7952659130096436e-01
    z[1,0,0]  R218      -2.2245080769062042e-01
    z[1,0,0]  R219      -3.7676227092742920e-01
    z[1,0,0]  R220      0.478341281414032
    z[1,0,0]  R221      0.676973283290863
    z[1,0,0]  R222      4.4680270552635193e-01
    z[1,0,0]  R223      6.4664644002914429e-01
    z[1,0,0]  R224      5.7975602149963379e-01
    z[1,0,0]  R225      0.586368203163147
    z[1,0,0]  R226      6.0991507768630981e-01
    z[1,0,0]  R227      0.332193523645401
    z[1,0,0]  R228      7.2198235988616943e-01
    z[1,0,0]  R229      1.0257675498723984e-01
    z[1,0,0]  R230      -2.2947709262371063e-01
    z[1,0,0]  R231      -3.6362317204475403e-01
    z[1,0,0]  R232      5.3756457567214966e-01
    z[1,0,0]  R233      -2.9505431652069092e-02
    z[1,0,0]  R234      4.5382156968116760e-01
    z[1,0,0]  R235      2.6670229434967041e-01
    z[1,0,0]  R236      7.3435842990875244e-01
    z[1,0,0]  R237      4.9293899536132812e-01
    z[1,0,0]  R238      6.9068127870559692e-01
    z[1,0,0]  R239      -5.4931193590164185e-01
    z[1,0,0]  R240      -3.8923683762550354e-01
    z[1,0,0]  R241      4.1136839985847473e-01
    z[1,0,0]  R242      -1.7706157639622688e-02
    z[1,0,0]  R243      1.2964147329330444e-01
    z[1,0,0]  R244      2.6234817504882812e-01
    z[1,0,0]  R245      4.7098869085311890e-01
    z[1,0,0]  R246      7.0320379734039307e-01
    z[1,0,0]  R247      4.5568275451660156e-01
    z[1,0,0]  R248      2.2768758237361908e-01
    z[1,0,0]  R249      -7.3867177963256836e-01
    z[1,0,0]  R250      -2.5451815128326416e-01
    z[1,0,0]  R251      -0.0896846279501915
    z[1,0,0]  R252      0.797221302986145
    z[1,0,0]  R253      -4.8959842324256897e-01
    z[1,0,0]  R254      -6.7485976219177246e-01
    z[1,0,0]  R255      4.6167784929275513e-01
    z[1,0,0]  R256      7.8284525871276855e-01
    z[1,0,0]  R257      6.0020017623901367e-01
    z[1,0,0]  R258      9.0609920024871826e-01
    z[1,0,0]  R259      7.7066212892532349e-01
    z[1,0,0]  R260      7.3027622699737549e-01
    z[1,0,0]  R261      -2.1502149105072021e-01
    z[1,0,0]  R262      -1.9992746412754059e-01
    z[1,0,0]  R263      -2.9732275009155273e-01
    z[1,0,0]  R264      -4.4450685381889343e-01
    z[1,0,0]  R265      -4.3208426237106323e-01
    z[1,0,0]  R266      -0.336843878030777
    z[1,0,0]  R267      -4.0878662467002869e-01
    z[1,0,0]  R268      -5.3279228508472443e-02
    z[1,0,0]  R269      -4.5024999976158142e-01
    z[1,0,0]  R270      -0.411024808883667
    z[1,0,0]  R271      -4.4169384241104126e-01
    z[1,0,0]  R272      -3.6607587337493896e-01
    z[1,0,0]  R273      -0.486956387758255
    z[1,0,0]  R274      -5.4662817716598511e-01
    z[1,0,0]  R275      0.380811482667923
    z[1,0,0]  R276      2.3891361057758331e-01
    z[1,0,0]  R277      -3.3565676212310791e-01
    z[1,0,0]  R278      -0.596221923828125
    z[1,0,0]  R279      -4.5209968090057373e-01
    z[1,0,0]  R280      -6.1724567413330078e-01
    z[1,0,0]  R281      -4.4862964749336243e-01
    z[1,0,0]  R282      -3.4217828512191772e-01
    z[1,0,0]  R283      -8.4837317466735840e-01
    z[1,0,0]  R284      -7.1159183979034424e-01
    z[1,0,0]  R285      -3.8063347339630127e-02
    z[1,0,0]  R286      2.7389812469482422e-01
    z[1,0,0]  R287      4.2580771446228027e-01
    z[1,0,0]  R288      -0.0927567332983017
    z[1,0,0]  R289      -3.4944143891334534e-01
    z[1,0,0]  R290      -6.5495330095291138e-01
    z[1,0,0]  R291      -4.0727809071540833e-01
    z[1,0,0]  R292      -2.6227793097496033e-01
    z[1,0,0]  R293      -0.287907212972641
    z[1,0,0]  R294      -1.3133455812931061e-01
    z[1,0,0]  R295      3.1992402672767639e-01
    z[1,0,0]  R296      4.3874862790107727e-01
    z[1,0,0]  R297      -5.9243679046630859e-01
    z[1,0,0]  R298      -5.5101764202117920e-01
    z[1,0,0]  R299      -9.2834258079528809e-01
    z[1,0,0]  R300      -8.9895540475845337e-01
    z[1,0,0]  R301      -8.6350661516189575e-01
    z[1,0,0]  R302      -8.3183217048645020e-01
    z[1,0,0]  R303      -8.6382150650024414e-01
    z[1,0,0]  R304      -8.8438612222671509e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R187      -1
    z[1,0,1]  R188      1
    z[1,0,1]  R199      7.0582723617553711e-01
    z[1,0,1]  R200      7.4835884571075439e-01
    z[1,0,1]  R201      6.4602726697921753e-01
    z[1,0,1]  R202      4.0355780720710754e-01
    z[1,0,1]  R203      2.8929588198661804e-01
    z[1,0,1]  R204      -1.5599606931209564e-01
    z[1,0,1]  R205      -2.5938186049461365e-01
    z[1,0,1]  R206      -2.8838065266609192e-01
    z[1,0,1]  R207      -2.6488536596298218e-01
    z[1,0,1]  R208      -1.8207627534866333e-01
    z[1,0,1]  R209      -0.722950279712677
    z[1,0,1]  R210      -7.9297041893005371e-01
    z[1,0,1]  R211      -8.1031274795532227e-01
    z[1,0,1]  R212      -7.6446080207824707e-01
    z[1,0,1]  R213      -0.84675532579422
    z[1,0,1]  R214      -6.3792812824249268e-01
    z[1,0,1]  R215      -6.0679459571838379e-01
    z[1,0,1]  R216      -6.9677561521530151e-01
    z[1,0,1]  R217      -6.4049822092056274e-01
    z[1,0,1]  R218      -7.5996285676956177e-01
    z[1,0,1]  R219      3.1034144759178162e-01
    z[1,0,1]  R220      6.3583391904830933e-01
    z[1,0,1]  R221      0.596767783164978
    z[1,0,1]  R222      7.8609246015548706e-01
    z[1,0,1]  R223      5.6476938724517822e-01
    z[1,0,1]  R224      4.8868107795715332e-01
    z[1,0,1]  R225      3.9729556441307068e-01
    z[1,0,1]  R226      6.6568471491336823e-02
    z[1,0,1]  R227      -1.3944588601589203e-02
    z[1,0,1]  R228      1.3699467480182648e-01
    z[1,0,1]  R229      -7.8468644618988037e-01
    z[1,0,1]  R230      3.0972850322723389e-01
    z[1,0,1]  R231      2.8695744276046753e-01
    z[1,0,1]  R232      1.9082698225975037e-01
    z[1,0,1]  R233      4.2503336071968079e-01
    z[1,0,1]  R234      -9.7298972308635712e-02
    z[1,0,1]  R235      -1.1420476436614990e-01
    z[1,0,1]  R236      1.7754136025905609e-01
    z[1,0,1]  R237      -2.3391132056713104e-01
    z[1,0,1]  R238      2.2367011010646820e-01
    z[1,0,1]  R239      2.0922964811325073e-01
    z[1,0,1]  R240      3.7760722637176514e-01
    z[1,0,1]  R241      -3.3757331967353821e-01
    z[1,0,1]  R242      5.3565579652786255e-01
    z[1,0,1]  R243      5.6941163539886475e-01
    z[1,0,1]  R244      8.3352994918823242e-01
    z[1,0,1]  R245      3.5133186727762222e-02
    z[1,0,1]  R246      7.6741680502891541e-02
    z[1,0,1]  R247      -2.1169431507587433e-02
    z[1,0,1]  R248      -1.0548040270805359e-01
    z[1,0,1]  R249      3.7100705504417419e-01
    z[1,0,1]  R250      6.1308199167251587e-01
    z[1,0,1]  R251      3.0658674240112305e-01
    z[1,0,1]  R252      2.2164407372474670e-01
    z[1,0,1]  R253      7.7359803020954132e-02
    z[1,0,1]  R254      1.0380051285028458e-01
    z[1,0,1]  R255      3.9054531604051590e-02
    z[1,0,1]  R256      3.7439472973346710e-02
    z[1,0,1]  R257      -1.7181976139545441e-01
    z[1,0,1]  R258      -2.4567259848117828e-01
    z[1,0,1]  R259      -6.6646635532379150e-02
    z[1,0,1]  R260      -2.4409869313240051e-01
    z[1,0,1]  R261      6.6869288682937622e-01
    z[1,0,1]  R262      0.641991376876831
    z[1,0,1]  R263      6.4558017253875732e-01
    z[1,0,1]  R264      7.9754006862640381e-01
    z[1,0,1]  R265      -8.5053634643554688e-01
    z[1,0,1]  R266      -0.809870183467865
    z[1,0,1]  R267      -0.618388831615448
    z[1,0,1]  R268      -5.5543613433837891e-01
    z[1,0,1]  R269      1.7742255330085754e-01
    z[1,0,1]  R270      3.6569207906723022e-01
    z[1,0,1]  R271      6.3491761684417725e-01
    z[1,0,1]  R272      2.7263557910919189e-01
    z[1,0,1]  R273      6.8682879209518433e-01
    z[1,0,1]  R274      4.4054615497589111e-01
    z[1,0,1]  R275      1.4553695917129517e-01
    z[1,0,1]  R276      -0.0651506707072258
    z[1,0,1]  R277      5.2055299282073975e-01
    z[1,0,1]  R278      4.6442502737045288e-01
    z[1,0,1]  R279      4.3314164876937866e-01
    z[1,0,1]  R280      1.7271231114864349e-01
    z[1,0,1]  R281      4.5343667268753052e-01
    z[1,0,1]  R282      3.5579410195350647e-01
    z[1,0,1]  R283      2.0928426086902618e-01
    z[1,0,1]  R284      4.4348591566085815e-01
    z[1,0,1]  R285      -7.8424614667892456e-01
    z[1,0,1]  R286      6.0361549258232117e-03
    z[1,0,1]  R287      5.5607044696807861e-01
    z[1,0,1]  R288      -6.6846656799316406e-01
    z[1,0,1]  R289      0.676803469657898
    z[1,0,1]  R290      5.2576822042465210e-01
    z[1,0,1]  R291      5.8075463771820068e-01
    z[1,0,1]  R292      3.6867663729935884e-03
    z[1,0,1]  R293      0.217891663312912
    z[1,0,1]  R294      1.5251954086124897e-02
    z[1,0,1]  R295      0.296316534280777
    z[1,0,1]  R296      2.5337365269660950e-01
    z[1,0,1]  R297      4.2025262117385864e-01
    z[1,0,1]  R298      0.671235203742981
    z[1,0,1]  R299      1.3216313719749451e-01
    z[1,0,1]  R300      1.7424921691417694e-01
    z[1,0,1]  R301      1.6426555812358856e-01
    z[1,0,1]  R302      0.107903391122818
    z[1,0,1]  R303      2.5297647714614868e-01
    z[1,0,1]  R304      2.3614084720611572e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R189      -1
    z[1,0,2]  R190      1
    z[1,0,2]  R199      -0.229117289185524
    z[1,0,2]  R200      -2.6490619778633118e-01
    z[1,0,2]  R201      -4.8827031254768372e-01
    z[1,0,2]  R202      -5.6621521711349487e-01
    z[1,0,2]  R203      -1.5989576280117035e-01
    z[1,0,2]  R204      2.4967324733734131e-01
    z[1,0,2]  R205      3.6085703969001770e-01
    z[1,0,2]  R206      5.2071553468704224e-01
    z[1,0,2]  R207      1.2483359873294830e-01
    z[1,0,2]  R208      5.2010452747344971e-01
    z[1,0,2]  R209      -9.7651155665516853e-03
    z[1,0,2]  R210      -3.0187508463859558e-01
    z[1,0,2]  R211      -2.5007483363151550e-01
    z[1,0,2]  R212      -1.1067414283752441e-01
    z[1,0,2]  R213      -1.7438901960849762e-01
    z[1,0,2]  R214      -1.1787618696689606e-01
    z[1,0,2]  R215      4.9787878990173340e-02
    z[1,0,2]  R216      -2.6266448199748993e-02
    z[1,0,2]  R217      -0.0127011863514781
    z[1,0,2]  R218      1.0693140327930450e-01
    z[1,0,2]  R219      -2.6498275995254517e-01
    z[1,0,2]  R220      -3.5252094268798828e-01
    z[1,0,2]  R221      -2.2569186985492706e-01
    z[1,0,2]  R222      0.0648149698972702
    z[1,0,2]  R223      0.0210171639919281
    z[1,0,2]  R224      1.3366617262363434e-02
    z[1,0,2]  R225      -1.1218158155679703e-01
    z[1,0,2]  R226      9.2862747609615326e-02
    z[1,0,2]  R227      6.3014000654220581e-01
    z[1,0,2]  R228      2.3018909990787506e-01
    z[1,0,2]  R229      6.6623359918594360e-02
    z[1,0,2]  R230      1.4183364808559418e-01
    z[1,0,2]  R231      -2.5261448696255684e-02
    z[1,0,2]  R232      -0.235975444316864
    z[1,0,2]  R233      -8.3938531577587128e-02
    z[1,0,2]  R234      9.7031831741333008e-02
    z[1,0,2]  R235      5.5120289325714111e-01
    z[1,0,2]  R236      3.6256012320518494e-01
    z[1,0,2]  R237      0.472822368144989
    z[1,0,2]  R238      0.268179327249527
    z[1,0,2]  R239      -2.5414398312568665e-01
    z[1,0,2]  R240      1.1739699542522430e-01
    z[1,0,2]  R241      1.4202952384948730e-01
    z[1,0,2]  R242      -1.2348987907171249e-01
    z[1,0,2]  R243      -3.3790859580039978e-01
    z[1,0,2]  R244      -1.2669317424297333e-01
    z[1,0,2]  R245      -6.8267039954662323e-02
    z[1,0,2]  R246      2.3709677159786224e-01
    z[1,0,2]  R247      -3.4693825244903564e-01
    z[1,0,2]  R248      6.3916486501693726e-01
    z[1,0,2]  R249      -3.9355117082595825e-01
    z[1,0,2]  R250      -1.1480126529932022e-02
    z[1,0,2]  R251      1.7177364230155945e-01
    z[1,0,2]  R252      3.8163551688194275e-01
    z[1,0,2]  R253      3.4038397669792175e-01
    z[1,0,2]  R254      0.566510021686554
    z[1,0,2]  R255      2.6861715316772461e-01
    z[1,0,2]  R256      1.8759402632713318e-01
    z[1,0,2]  R257      1.9993208348751068e-01
    z[1,0,2]  R258      1.0501673817634583e-01
    z[1,0,2]  R259      2.3561078310012817e-01
    z[1,0,2]  R260      7.7200238592922688e-03
    z[1,0,2]  R261      -4.9707639217376709e-01
    z[1,0,2]  R262      -6.7353487014770508e-01
    z[1,0,2]  R263      -5.8032989501953125e-01
    z[1,0,2]  R264      -2.3401589691638947e-01
    z[1,0,2]  R265      -0.0516057126224041
    z[1,0,2]  R266      -2.6388362050056458e-01
    z[1,0,2]  R267      -2.0872253924608231e-02
    z[1,0,2]  R268      -3.9774301648139954e-01
    z[1,0,2]  R269      -3.9278933405876160e-01
    z[1,0,2]  R270      -1.7736141383647919e-01
    z[1,0,2]  R271      1.3082201778888702e-01
    z[1,0,2]  R272      -2.7695167064666748e-01
    z[1,0,2]  R273      1.1234810948371887e-01
    z[1,0,2]  R274      -7.2845116257667542e-02
    z[1,0,2]  R275      -4.1306439042091370e-01
    z[1,0,2]  R276      -4.2743068933486938e-01
    z[1,0,2]  R277      -4.4957584142684937e-01
    z[1,0,2]  R278      -1.5730418264865875e-01
    z[1,0,2]  R279      -3.3564716577529907e-01
    z[1,0,2]  R280      -1.3083352148532867e-01
    z[1,0,2]  R281      -1.7925995588302612e-01
    z[1,0,2]  R282      -6.5206638537347317e-03
    z[1,0,2]  R283      -2.4681134521961212e-01
    z[1,0,2]  R284      2.3112552240490913e-02
    z[1,0,2]  R285      -2.1220695972442627e-01
    z[1,0,2]  R286      -3.7491649389266968e-01
    z[1,0,2]  R287      -2.3035834729671478e-01
    z[1,0,2]  R288      -3.4647712111473083e-01
    z[1,0,2]  R289      -1.5503384172916412e-01
    z[1,0,2]  R290      -4.0012553334236145e-01
    z[1,0,2]  R291      7.5143299996852875e-02
    z[1,0,2]  R292      -6.7475301027297974e-01
    z[1,0,2]  R293      -2.6001867651939392e-01
    z[1,0,2]  R294      -8.0907016992568970e-01
    z[1,0,2]  R295      -1.3702294230461121e-01
    z[1,0,2]  R296      -3.8953217864036560e-01
    z[1,0,2]  R297      -4.6181124448776245e-01
    z[1,0,2]  R298      -2.3660619556903839e-01
    z[1,0,2]  R299      -2.6832882314920425e-02
    z[1,0,2]  R300      2.9775089025497437e-01
    z[1,0,2]  R301      2.6385051012039185e-01
    z[1,0,2]  R302      3.8567009568214417e-01
    z[1,0,2]  R303      7.4455849826335907e-02
    z[1,0,2]  R304      8.8931880891323090e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R191      -1
    z[1,0,3]  R192      1
    z[1,0,3]  R199      -2.9019543528556824e-01
    z[1,0,3]  R200      5.7496611028909683e-02
    z[1,0,3]  R201      -7.3940992355346680e-02
    z[1,0,3]  R202      2.4332102388143539e-02
    z[1,0,3]  R203      -8.6339443922042847e-02
    z[1,0,3]  R204      0.651769757270813
    z[1,0,3]  R205      5.7279855012893677e-01
    z[1,0,3]  R206      2.7020815014839172e-01
    z[1,0,3]  R207      6.3380479812622070e-01
    z[1,0,3]  R208      3.6046424508094788e-01
    z[1,0,3]  R209      -0.477079302072525
    z[1,0,3]  R210      6.7505910992622375e-02
    z[1,0,3]  R211      2.5140070915222168e-01
    z[1,0,3]  R212      -1.8602685630321503e-01
    z[1,0,3]  R213      -2.1406927704811096e-01
    z[1,0,3]  R214      -2.8279563784599304e-01
    z[1,0,3]  R215      -0.0956747829914093
    z[1,0,3]  R216      -2.6482401415705681e-02
    z[1,0,3]  R217      -1.0606414824724197e-01
    z[1,0,3]  R218      1.4834043383598328e-01
    z[1,0,3]  R219      -3.7804111838340759e-01
    z[1,0,3]  R220      3.8450878858566284e-01
    z[1,0,3]  R221      0.0953054204583168
    z[1,0,3]  R222      1.9266439601778984e-02
    z[1,0,3]  R223      -3.2006785273551941e-01
    z[1,0,3]  R224      -3.1716409325599670e-01
    z[1,0,3]  R225      -2.4189472198486328e-01
    z[1,0,3]  R226      -4.9281543493270874e-01
    z[1,0,3]  R227      -4.6805629134178162e-01
    z[1,0,3]  R228      1.9967010244727135e-02
    z[1,0,3]  R229      -2.6093193888664246e-01
    z[1,0,3]  R230      -6.8618077039718628e-01
    z[1,0,3]  R231      -1.8147185444831848e-01
    z[1,0,3]  R232      -4.9503338336944580e-01
    z[1,0,3]  R233      -7.3967504501342773e-01
    z[1,0,3]  R234      5.1183837652206421e-01
    z[1,0,3]  R235      -4.9407193064689636e-01
    z[1,0,3]  R236      -1.5420243144035339e-01
    z[1,0,3]  R237      -5.0213855504989624e-01
    z[1,0,3]  R238      3.4624069929122925e-02
    z[1,0,3]  R239      -0.486905038356781
    z[1,0,3]  R240      -5.1858031749725342e-01
    z[1,0,3]  R241      7.9279178380966187e-01
    z[1,0,3]  R242      -6.5510874986648560e-01
    z[1,0,3]  R243      2.9931154847145081e-01
    z[1,0,3]  R244      2.2582674026489258e-01
    z[1,0,3]  R245      -0.532409131526947
    z[1,0,3]  R246      1.1730780452489853e-01
    z[1,0,3]  R247      -2.9757568240165710e-01
    z[1,0,3]  R248      -6.3120013475418091e-01
    z[1,0,3]  R249      -2.8670126199722290e-01
    z[1,0,3]  R250      -4.9086907505989075e-01
    z[1,0,3]  R251      -9.2673414945602417e-01
    z[1,0,3]  R252      3.7704259157180786e-02
    z[1,0,3]  R253      5.6681799888610840e-01
    z[1,0,3]  R254      2.9143935441970825e-01
    z[1,0,3]  R255      -1.6876442730426788e-01
    z[1,0,3]  R256      5.1429289579391479e-01
    z[1,0,3]  R257      -8.7289996445178986e-02
    z[1,0,3]  R258      -2.4192532896995544e-01
    z[1,0,3]  R259      -4.4740411639213562e-01
    z[1,0,3]  R260      3.8083219528198242e-01
    z[1,0,3]  R261      -2.1674276888370514e-01
    z[1,0,3]  R262      1.8280692398548126e-01
    z[1,0,3]  R263      -2.6684349775314331e-01
    z[1,0,3]  R264      5.5397957563400269e-02
    z[1,0,3]  R265      -2.0918834209442139e-01
    z[1,0,3]  R266      2.2222478687763214e-01
    z[1,0,3]  R267      -4.6384656429290771e-01
    z[1,0,3]  R268      -0.0847087875008583
    z[1,0,3]  R269      -2.8722891211509705e-01
    z[1,0,3]  R270      5.7033807039260864e-02
    z[1,0,3]  R271      -6.4385481178760529e-02
    z[1,0,3]  R272      -1.3314920663833618e-01
    z[1,0,3]  R273      -3.4458611160516739e-02
    z[1,0,3]  R274      -7.0325643755495548e-03
    z[1,0,3]  R275      2.3071725666522980e-01
    z[1,0,3]  R276      -6.8104617297649384e-02
    z[1,0,3]  R277      -9.5689199864864349e-02
    z[1,0,3]  R278      -1.5826018154621124e-01
    z[1,0,3]  R279      3.8550609350204468e-01
    z[1,0,3]  R280      -1.1226285994052887e-01
    z[1,0,3]  R281      2.6194056868553162e-01
    z[1,0,3]  R282      -5.7582074403762817e-01
    z[1,0,3]  R283      7.0373013615608215e-02
    z[1,0,3]  R284      -4.8064935207366943e-01
    z[1,0,3]  R285      1.9869594275951385e-01
    z[1,0,3]  R286      -1.7554265260696411e-01
    z[1,0,3]  R287      1.9822651520371437e-03
    z[1,0,3]  R288      3.7127229571342468e-01
    z[1,0,3]  R289      -1.6969843208789825e-01
    z[1,0,3]  R290      2.9292061924934387e-01
    z[1,0,3]  R291      -5.5232882499694824e-01
    z[1,0,3]  R292      2.0609617233276367e-01
    z[1,0,3]  R293      -8.0671662092208862e-01
    z[1,0,3]  R294      -4.1146126389503479e-01
    z[1,0,3]  R295      -4.6740320324897766e-01
    z[1,0,3]  R296      1.6549223661422729e-01
    z[1,0,3]  R297      2.2901932895183563e-01
    z[1,0,3]  R298      8.8411066681146622e-03
    z[1,0,3]  R299      2.8512412309646606e-01
    z[1,0,3]  R300      1.3275374472141266e-01
    z[1,0,3]  R301      -6.2729187309741974e-02
    z[1,0,3]  R302      3.4456110000610352e-01
    z[1,0,3]  R303      2.3610265552997589e-01
    z[1,0,3]  R304      1.9028577953577042e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R193      -1
    z[1,0,4]  R194      1
    z[1,0,4]  R199      3.8261204957962036e-01
    z[1,0,4]  R200      2.7791008353233337e-01
    z[1,0,4]  R201      -2.3422902822494507e-01
    z[1,0,4]  R202      1.0998079180717468e-01
    z[1,0,4]  R203      2.4276715517044067e-01
    z[1,0,4]  R204      -1.1566183716058731e-01
    z[1,0,4]  R205      2.1666100621223450e-01
    z[1,0,4]  R206      1.3682533800601959e-01
    z[1,0,4]  R207      1.9600607454776764e-01
    z[1,0,4]  R208      1.7497076094150543e-01
    z[1,0,4]  R209      1.1299677938222885e-01
    z[1,0,4]  R210      -2.8302571736276150e-03
    z[1,0,4]  R211      0.0761076956987381
    z[1,0,4]  R212      1.3485226035118103e-01
    z[1,0,4]  R213      -2.3401015996932983e-01
    z[1,0,4]  R214      -2.5529021024703979e-01
    z[1,0,4]  R215      0.527223527431488
    z[1,0,4]  R216      0.502944827079773
    z[1,0,4]  R217      -4.3249884247779846e-01
    z[1,0,4]  R218      -2.5453118607401848e-02
    z[1,0,4]  R219      -2.4937191605567932e-01
    z[1,0,4]  R220      2.9429266229271889e-02
    z[1,0,4]  R221      -3.4854507446289062e-01
    z[1,0,4]  R222      -2.5800922513008118e-01
    z[1,0,4]  R223      -3.9282381534576416e-01
    z[1,0,4]  R224      -2.5062489509582520e-01
    z[1,0,4]  R225      -1.2206542491912842e-01
    z[1,0,4]  R226      5.1436161994934082e-01
    z[1,0,4]  R227      4.3308654427528381e-01
    z[1,0,4]  R228      -3.2065966725349426e-01
    z[1,0,4]  R229      -5.4726237058639526e-01
    z[1,0,4]  R230      -6.7449599504470825e-02
    z[1,0,4]  R231      2.1403318643569946e-01
    z[1,0,4]  R232      -6.9757483899593353e-02
    z[1,0,4]  R233      -3.9082175493240356e-01
    z[1,0,4]  R234      -2.1698732674121857e-01
    z[1,0,4]  R235      0.505648136138916
    z[1,0,4]  R236      -3.4428441524505615e-01
    z[1,0,4]  R237      1.7090511322021484e-01
    z[1,0,4]  R238      -4.8727640509605408e-01
    z[1,0,4]  R239      -1.2089670449495316e-01
    z[1,0,4]  R240      0.221050426363945
    z[1,0,4]  R241      2.1512087434530258e-02
    z[1,0,4]  R242      -3.7427493929862976e-01
    z[1,0,4]  R243      2.4408282712101936e-02
    z[1,0,4]  R244      -3.5382375121116638e-01
    z[1,0,4]  R245      6.8781822919845581e-01
    z[1,0,4]  R246      -4.4453686475753784e-01
    z[1,0,4]  R247      6.4020842313766479e-01
    z[1,0,4]  R248      4.1498217731714249e-02
    z[1,0,4]  R249      1.1063133925199509e-01
    z[1,0,4]  R250      -9.9658809602260590e-02
    z[1,0,4]  R251      -0.0842304676771164
    z[1,0,4]  R252      -2.4974401295185089e-01
    z[1,0,4]  R253      -3.1321346759796143e-01
    z[1,0,4]  R254      -1.9275777041912079e-01
    z[1,0,4]  R255      1.1649116128683090e-01
    z[1,0,4]  R256      1.9057299196720123e-01
    z[1,0,4]  R257      2.0229449868202209e-01
    z[1,0,4]  R258      9.8868263885378838e-03
    z[1,0,4]  R259      -3.6068853735923767e-01
    z[1,0,4]  R260      -4.6930167078971863e-01
    z[1,0,4]  R261      3.1903919577598572e-01
    z[1,0,4]  R262      -9.6473604440689087e-02
    z[1,0,4]  R263      3.9080940186977386e-03
    z[1,0,4]  R264      2.9522275924682617e-01
    z[1,0,4]  R265      2.0334189757704735e-02
    z[1,0,4]  R266      2.8387141227722168e-01
    z[1,0,4]  R267      4.8437470197677612e-01
    z[1,0,4]  R268      6.2884253263473511e-01
    z[1,0,4]  R269      1.2406851351261139e-01
    z[1,0,4]  R270      -2.5360816717147827e-01
    z[1,0,4]  R271      -0.281288206577301
    z[1,0,4]  R272      -4.3320730328559875e-01
    z[1,0,4]  R273      2.9039615765213966e-02
    z[1,0,4]  R274      -2.8913456201553345e-01
    z[1,0,4]  R275      -5.8810006827116013e-02
    z[1,0,4]  R276      6.2225043773651123e-01
    z[1,0,4]  R277      -0.0938170999288559
    z[1,0,4]  R278      3.7507492303848267e-01
    z[1,0,4]  R279      4.4238457083702087e-01
    z[1,0,4]  R280      -1.0518613457679749e-01
    z[1,0,4]  R281      -3.6167246103286743e-01
    z[1,0,4]  R282      1.1317305266857147e-01
    z[1,0,4]  R283      -3.1123054027557373e-01
    z[1,0,4]  R284      -2.2253684699535370e-01
    z[1,0,4]  R285      -2.4853645265102386e-01
    z[1,0,4]  R286      4.9042135477066040e-01
    z[1,0,4]  R287      4.3059471249580383e-01
    z[1,0,4]  R288      -3.4301328659057617e-01
    z[1,0,4]  R289      -3.3631703257560730e-01
    z[1,0,4]  R290      -4.0257643908262253e-02
    z[1,0,4]  R291      2.7994525432586670e-01
    z[1,0,4]  R292      1.3417159020900726e-01
    z[1,0,4]  R293      -1.6669304668903351e-01
    z[1,0,4]  R294      -9.8640426993370056e-02
    z[1,0,4]  R295      5.5449718236923218e-01
    z[1,0,4]  R296      5.5251830816268921e-01
    z[1,0,4]  R297      1.8550334870815277e-01
    z[1,0,4]  R298      3.8085004687309265e-01
    z[1,0,4]  R299      -1.7400009930133820e-01
    z[1,0,4]  R300      -1.8838274478912354e-01
    z[1,0,4]  R301      -1.2845905125141144e-01
    z[1,0,4]  R302      1.1475032567977905e-01
    z[1,0,4]  R303      8.3073377609252930e-02
    z[1,0,4]  R304      -3.0021220445632935e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R195      -1
    z[1,0,5]  R196      1
    z[1,0,5]  R199      -1.3069508969783783e-01
    z[1,0,5]  R200      4.7280009835958481e-02
    z[1,0,5]  R201      -2.4256812036037445e-01
    z[1,0,5]  R202      1.0398554056882858e-01
    z[1,0,5]  R203      -0.625950813293457
    z[1,0,5]  R204      1.0464450716972351e-01
    z[1,0,5]  R205      -1.2760579586029053e-01
    z[1,0,5]  R206      2.7487901970744133e-02
    z[1,0,5]  R207      -1.0926242172718048e-01
    z[1,0,5]  R208      -9.2612817883491516e-02
    z[1,0,5]  R209      6.8953827023506165e-02
    z[1,0,5]  R210      -2.0019227266311646e-01
    z[1,0,5]  R211      -3.3036354184150696e-01
    z[1,0,5]  R212      -4.7876381874084473e-01
    z[1,0,5]  R213      5.3922671824693680e-02
    z[1,0,5]  R214      -0.264121949672699
    z[1,0,5]  R215      4.1039773821830750e-01
    z[1,0,5]  R216      1.3205060362815857e-01
    z[1,0,5]  R217      0.194817915558815
    z[1,0,5]  R218      1.7538410425186157e-01
    z[1,0,5]  R219      6.4642357826232910e-01
    z[1,0,5]  R220      -2.8103792667388916e-01
    z[1,0,5]  R221      7.0109167136251926e-03
    z[1,0,5]  R222      2.3674240708351135e-01
    z[1,0,5]  R223      7.5311444699764252e-02
    z[1,0,5]  R224      -2.9498040676116943e-02
    z[1,0,5]  R225      -6.6754192113876343e-02
    z[1,0,5]  R226      3.2755106687545776e-01
    z[1,0,5]  R227      2.3541361093521118e-01
    z[1,0,5]  R228      -5.1162582635879517e-01
    z[1,0,5]  R229      -2.5592150166630745e-02
    z[1,0,5]  R230      -3.0405440926551819e-01
    z[1,0,5]  R231      8.3945882320404053e-01
    z[1,0,5]  R232      -6.0283303260803223e-01
    z[1,0,5]  R233      -5.3239960223436356e-02
    z[1,0,5]  R234      -6.1507624387741089e-01
    z[1,0,5]  R235      -3.1253370642662048e-01
    z[1,0,5]  R236      -3.9272478222846985e-01
    z[1,0,5]  R237      -3.5361361503601074e-01
    z[1,0,5]  R238      -3.8169774413108826e-01
    z[1,0,5]  R239      5.6845819950103760e-01
    z[1,0,5]  R240      5.1635706424713135e-01
    z[1,0,5]  R241      -1.0229671746492386e-01
    z[1,0,5]  R242      -5.7824570685625076e-02
    z[1,0,5]  R243      -2.8982567787170410e-01
    z[1,0,5]  R244      1.9826823472976685e-01
    z[1,0,5]  R245      9.6248477697372437e-02
    z[1,0,5]  R246      -4.8029392957687378e-01
    z[1,0,5]  R247      4.1570165753364563e-01
    z[1,0,5]  R248      -3.5506728291511536e-01
    z[1,0,5]  R249      2.5812932848930359e-01
    z[1,0,5]  R250      -2.9577055573463440e-01
    z[1,0,5]  R251      1.9396256655454636e-02
    z[1,0,5]  R252      -3.2449653744697571e-01
    z[1,0,5]  R253      4.2761421203613281e-01
    z[1,0,5]  R254      -1.7201507091522217e-01
    z[1,0,5]  R255      -7.4515056610107422e-01
    z[1,0,5]  R256      -2.1487425267696381e-01
    z[1,0,5]  R257      0.00630249222740531
    z[1,0,5]  R258      -2.1305792033672333e-01
    z[1,0,5]  R259      5.0106555223464966e-02
    z[1,0,5]  R260      -1.7384263873100281e-01
    z[1,0,5]  R261      1.6594673693180084e-01
    z[1,0,5]  R262      2.0208194851875305e-01
    z[1,0,5]  R263      2.1927194669842720e-02
    z[1,0,5]  R264      -1.9410748034715652e-02
    z[1,0,5]  R265      -1.5323872864246368e-01
    z[1,0,5]  R266      -1.7595407366752625e-01
    z[1,0,5]  R267      -1.3384682126343250e-02
    z[1,0,5]  R268      2.3417235910892487e-01
    z[1,0,5]  R269      5.7139742374420166e-01
    z[1,0,5]  R270      6.7183399200439453e-01
    z[1,0,5]  R271      4.9277597665786743e-01
    z[1,0,5]  R272      7.1126115322113037e-01
    z[1,0,5]  R273      4.1232302784919739e-01
    z[1,0,5]  R274      6.3492357730865479e-01
    z[1,0,5]  R275      3.4589615464210510e-01
    z[1,0,5]  R276      2.6017433404922485e-01
    z[1,0,5]  R277      5.0373071432113647e-01
    z[1,0,5]  R278      4.5085495710372925e-01
    z[1,0,5]  R279      3.8269010186195374e-01
    z[1,0,5]  R280      7.3813176155090332e-01
    z[1,0,5]  R281      5.6638425588607788e-01
    z[1,0,5]  R282      4.4393953680992126e-01
    z[1,0,5]  R283      -2.7090549468994141e-01
    z[1,0,5]  R284      -1.2551090121269226e-01
    z[1,0,5]  R285      4.4402226805686951e-01
    z[1,0,5]  R286      0.276623398065567
    z[1,0,5]  R287      5.0560760498046875e-01
    z[1,0,5]  R288      8.9275732636451721e-02
    z[1,0,5]  R289      4.5141872763633728e-01
    z[1,0,5]  R290      1.6238547861576080e-01
    z[1,0,5]  R291      1.7913152277469635e-01
    z[1,0,5]  R292      0.611366331577301
    z[1,0,5]  R293      3.3558952808380127e-01
    z[1,0,5]  R294      -2.5231644511222839e-01
    z[1,0,5]  R295      3.2803300023078918e-01
    z[1,0,5]  R296      4.8965471982955933e-01
    z[1,0,5]  R297      4.1253602504730225e-01
    z[1,0,5]  R298      1.4516760408878326e-01
    z[1,0,5]  R299      1.7920201644301414e-02
    z[1,0,5]  R300      -1.0084106028079987e-01
    z[1,0,5]  R301      -1.7986075580120087e-01
    z[1,0,5]  R302      -3.4360468387603760e-02
    z[1,0,5]  R303      -3.2862797379493713e-01
    z[1,0,5]  R304      -1.3820065557956696e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R197      -1
    z[1,0,6]  R198      1
    z[1,0,6]  R199      9.0889401733875275e-02
    z[1,0,6]  R200      -2.5877895951271057e-01
    z[1,0,6]  R201      -8.0745331943035126e-02
    z[1,0,6]  R202      0.374576598405838
    z[1,0,6]  R203      -4.8989301919937134e-01
    z[1,0,6]  R204      2.0928401499986649e-02
    z[1,0,6]  R205      -2.4365289136767387e-02
    z[1,0,6]  R206      2.5289552286267281e-02
    z[1,0,6]  R207      3.9734715223312378e-01
    z[1,0,6]  R208      -2.2739601135253906e-01
    z[1,0,6]  R209      -0.0466383658349514
    z[1,0,6]  R210      3.5846567153930664e-01
    z[1,0,6]  R211      1.1906799674034119e-01
    z[1,0,6]  R212      3.1650140881538391e-02
    z[1,0,6]  R213      2.6548784971237183e-01
    z[1,0,6]  R214      -0.406181275844574
    z[1,0,6]  R215      5.1750767976045609e-02
    z[1,0,6]  R216      4.2256820201873779e-01
    z[1,0,6]  R217      -5.2460145950317383e-01
    z[1,0,6]  R218      -5.5509054660797119e-01
    z[1,0,6]  R219      2.6183506846427917e-01
    z[1,0,6]  R220      -1.2222281098365784e-01
    z[1,0,6]  R221      6.3423417508602142e-02
    z[1,0,6]  R222      2.3502789437770844e-01
    z[1,0,6]  R223      -0.00405834149569273
    z[1,0,6]  R224      -5.1050871610641479e-01
    z[1,0,6]  R225      0.63865065574646
    z[1,0,6]  R226      -1.4969493262469769e-02
    z[1,0,6]  R227      -1.7411597073078156e-01
    z[1,0,6]  R228      2.0495028793811798e-01
    z[1,0,6]  R229      3.2708659768104553e-02
    z[1,0,6]  R230      -5.1327300071716309e-01
    z[1,0,6]  R231      -3.6908425390720367e-02
    z[1,0,6]  R232      7.4787355959415436e-02
    z[1,0,6]  R233      3.2975021004676819e-01
    z[1,0,6]  R234      -2.9628169536590576e-01
    z[1,0,6]  R235      -1.2057397514581680e-01
    z[1,0,6]  R236      3.4699384123086929e-02
    z[1,0,6]  R237      0.268963485956192
    z[1,0,6]  R238      -1.2915319204330444e-01
    z[1,0,6]  R239      1.2269077450037003e-01
    z[1,0,6]  R240      -3.2819494605064392e-01
    z[1,0,6]  R241      -2.3916883766651154e-01
    z[1,0,6]  R242      3.5343545675277710e-01
    z[1,0,6]  R243      6.0876852273941040e-01
    z[1,0,6]  R244      6.9648787379264832e-02
    z[1,0,6]  R245      8.0360412597656250e-02
    z[1,0,6]  R246      -0.0366581492125988
    z[1,0,6]  R247      1.7690800130367279e-02
    z[1,0,6]  R248      4.7874860465526581e-02
    z[1,0,6]  R249      -2.7707897126674652e-02
    z[1,0,6]  R250      -4.6995177865028381e-01
    z[1,0,6]  R251      4.6346601098775864e-02
    z[1,0,6]  R252      2.3973459377884865e-02
    z[1,0,6]  R253      0.190284863114357
    z[1,0,6]  R254      2.4733503162860870e-01
    z[1,0,6]  R255      3.4039998054504395e-01
    z[1,0,6]  R256      5.9781733900308609e-02
    z[1,0,6]  R257      -0.722275972366333
    z[1,0,6]  R258      5.9845127165317535e-02
    z[1,0,6]  R259      1.1553537100553513e-01
    z[1,0,6]  R260      -1.0749082267284393e-01
    z[1,0,6]  R261      2.8849408030509949e-01
    z[1,0,6]  R262      1.0326829552650452e-01
    z[1,0,6]  R263      2.9383847117424011e-01
    z[1,0,6]  R264      1.4483739435672760e-01
    z[1,0,6]  R265      1.3990125060081482e-01
    z[1,0,6]  R266      9.2209856957197189e-03
    z[1,0,6]  R267      -1.0074402205646038e-02
    z[1,0,6]  R268      2.7018001675605774e-01
    z[1,0,6]  R269      -4.3257862329483032e-01
    z[1,0,6]  R270      -3.8332757353782654e-01
    z[1,0,6]  R271      -2.4202281236648560e-01
    z[1,0,6]  R272      6.0550529509782791e-02
    z[1,0,6]  R273      -3.2630729675292969e-01
    z[1,0,6]  R274      1.2261397391557693e-01
    z[1,0,6]  R275      6.9774365425109863e-01
    z[1,0,6]  R276      5.4447591304779053e-01
    z[1,0,6]  R277      -3.7754201889038086e-01
    z[1,0,6]  R278      1.8731378018856049e-01
    z[1,0,6]  R279      -6.7560456693172455e-02
    z[1,0,6]  R280      5.9625748544931412e-02
    z[1,0,6]  R281      0.201944500207901
    z[1,0,6]  R282      4.6348896622657776e-01
    z[1,0,6]  R283      1.8456105142831802e-02
    z[1,0,6]  R284      -1.1119223199784756e-02
    z[1,0,6]  R285      -2.0017798244953156e-01
    z[1,0,6]  R286      6.6070586442947388e-01
    z[1,0,6]  R287      1.2391008436679840e-01
    z[1,0,6]  R288      4.0128645300865173e-01
    z[1,0,6]  R289      2.2384525835514069e-01
    z[1,0,6]  R290      1.4391423761844635e-01
    z[1,0,6]  R291      2.7509528398513794e-01
    z[1,0,6]  R292      -2.0410434901714325e-01
    z[1,0,6]  R293      -1.0403953492641449e-01
    z[1,0,6]  R294      -2.9194223880767822e-01
    z[1,0,6]  R295      3.9690226316452026e-01
    z[1,0,6]  R296      1.3834813237190247e-01
    z[1,0,6]  R297      4.5711182057857513e-02
    z[1,0,6]  R298      -1.5375925600528717e-01
    z[1,0,6]  R299      -8.9999385178089142e-02
    z[1,0,6]  R300      -9.7879678010940552e-02
    z[1,0,6]  R301      -3.2398992776870728e-01
    z[1,0,6]  R302      -1.2083017081022263e-01
    z[1,0,6]  R303      -1.1674593389034271e-01
    z[1,0,6]  R304      2.1118935942649841e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R305      -1
    z[0,3,0]  R306      1
    z[0,3,0]  R319      4.6167784929275513e-01
    z[0,3,0]  R320      7.8284525871276855e-01
    z[0,3,0]  R321      6.0020017623901367e-01
    z[0,3,0]  R322      9.0609920024871826e-01
    z[0,3,0]  R323      7.7066212892532349e-01
    z[0,3,0]  R324      7.3027622699737549e-01
    z[0,3,0]  R325      -2.1502149105072021e-01
    z[0,3,0]  R326      -1.9992746412754059e-01
    z[0,3,0]  R327      -2.9732275009155273e-01
    z[0,3,0]  R328      -4.4450685381889343e-01
    z[0,3,0]  R329      -4.3208426237106323e-01
    z[0,3,0]  R330      -0.336843878030777
    z[0,3,0]  R331      -4.0878662467002869e-01
    z[0,3,0]  R332      -5.3279228508472443e-02
    z[0,3,0]  R333      -4.5024999976158142e-01
    z[0,3,0]  R334      -0.411024808883667
    z[0,3,0]  R335      -4.4169384241104126e-01
    z[0,3,0]  R336      -3.6607587337493896e-01
    z[0,3,0]  R337      -0.486956387758255
    z[0,3,0]  R338      -5.4662817716598511e-01
    z[0,3,0]  R339      0.380811482667923
    z[0,3,0]  R340      2.3891361057758331e-01
    z[0,3,0]  R341      -3.3565676212310791e-01
    z[0,3,0]  R342      -0.596221923828125
    z[0,3,0]  R343      -4.5209968090057373e-01
    z[0,3,0]  R344      -6.1724567413330078e-01
    z[0,3,0]  R345      -4.4862964749336243e-01
    z[0,3,0]  R346      -3.4217828512191772e-01
    z[0,3,0]  R347      -8.4837317466735840e-01
    z[0,3,0]  R348      -7.1159183979034424e-01
    z[0,3,0]  R349      -3.8063347339630127e-02
    z[0,3,0]  R350      2.7389812469482422e-01
    z[0,3,0]  R351      4.2580771446228027e-01
    z[0,3,0]  R352      -0.0927567332983017
    z[0,3,0]  R353      -3.4944143891334534e-01
    z[0,3,0]  R354      -6.5495330095291138e-01
    z[0,3,0]  R355      -4.0727809071540833e-01
    z[0,3,0]  R356      -2.6227793097496033e-01
    z[0,3,0]  R357      -0.287907212972641
    z[0,3,0]  R358      -1.3133455812931061e-01
    z[0,3,0]  R359      3.1992402672767639e-01
    z[0,3,0]  R360      4.3874862790107727e-01
    z[0,3,0]  R361      -5.9243679046630859e-01
    z[0,3,0]  R362      -5.5101764202117920e-01
    z[0,3,0]  R363      -9.2834258079528809e-01
    z[0,3,0]  R364      -8.9895540475845337e-01
    z[0,3,0]  R365      -8.6350661516189575e-01
    z[0,3,0]  R366      -8.3183217048645020e-01
    z[0,3,0]  R367      -8.6382150650024414e-01
    z[0,3,0]  R368      -8.8438612222671509e-01
    z[0,3,0]  R369      7.8155982494354248e-01
    z[0,3,0]  R370      1.0259279608726501e-01
    z[0,3,0]  R371      2.9779151082038879e-01
    z[0,3,0]  R372      -6.8223649263381958e-01
    z[0,3,0]  R373      -3.3380830287933350e-01
    z[0,3,0]  R374      -2.7980053424835205e-01
    z[0,3,0]  R375      -3.6434146761894226e-01
    z[0,3,0]  R376      -1.6419696807861328e-01
    z[0,3,0]  R377      -3.8544863462448120e-01
    z[0,3,0]  R378      -0.623007595539093
    z[0,3,0]  R379      -7.5105018913745880e-02
    z[0,3,0]  R380      -2.9878070577979088e-02
    z[0,3,0]  R381      -1.8481391668319702e-01
    z[0,3,0]  R382      -3.4994819760322571e-01
    z[0,3,0]  R383      -1.7089748382568359e-01
    z[0,3,0]  R384      -2.3380618542432785e-02
    z[0,3,0]  R385      3.0983725190162659e-01
    z[0,3,0]  R386      3.7620510905981064e-02
    z[0,3,0]  R387      -1.0741529613733292e-01
    z[0,3,0]  R388      1.2551528215408325e-01
    z[0,3,0]  R389      -2.1165297925472260e-01
    z[0,3,0]  R390      1.9318635761737823e-01
    z[0,3,0]  R391      -2.2988358512520790e-02
    z[0,3,0]  R392      2.6377752423286438e-01
    z[0,3,0]  R393      3.2029467821121216e-01
    z[0,3,0]  R394      -0.270953506231308
    z[0,3,0]  R395      -9.1509437561035156e-01
    z[0,3,0]  R396      -8.7610584497451782e-01
    z[0,3,0]  R397      -8.2335573434829712e-01
    z[0,3,0]  R398      -7.5604027509689331e-01
    z[0,3,0]  R399      -0.256926566362381
    z[0,3,0]  R400      3.0761915445327759e-01
    z[0,3,0]  R401      2.4368667975068092e-02
    z[0,3,0]  R402      -1.7191019654273987e-01
    z[0,3,0]  R403      3.1932809948921204e-01
    z[0,3,0]  R404      -0.70970618724823
    z[0,3,0]  R405      -4.7882348299026489e-02
    z[0,3,0]  R406      -4.7134313732385635e-02
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R307      -1
    z[0,3,1]  R308      1
    z[0,3,1]  R319      3.9054531604051590e-02
    z[0,3,1]  R320      3.7439472973346710e-02
    z[0,3,1]  R321      -1.7181976139545441e-01
    z[0,3,1]  R322      -2.4567259848117828e-01
    z[0,3,1]  R323      -6.6646635532379150e-02
    z[0,3,1]  R324      -2.4409869313240051e-01
    z[0,3,1]  R325      6.6869288682937622e-01
    z[0,3,1]  R326      0.641991376876831
    z[0,3,1]  R327      6.4558017253875732e-01
    z[0,3,1]  R328      7.9754006862640381e-01
    z[0,3,1]  R329      -8.5053634643554688e-01
    z[0,3,1]  R330      -0.809870183467865
    z[0,3,1]  R331      -0.618388831615448
    z[0,3,1]  R332      -5.5543613433837891e-01
    z[0,3,1]  R333      1.7742255330085754e-01
    z[0,3,1]  R334      3.6569207906723022e-01
    z[0,3,1]  R335      6.3491761684417725e-01
    z[0,3,1]  R336      2.7263557910919189e-01
    z[0,3,1]  R337      6.8682879209518433e-01
    z[0,3,1]  R338      4.4054615497589111e-01
    z[0,3,1]  R339      1.4553695917129517e-01
    z[0,3,1]  R340      -0.0651506707072258
    z[0,3,1]  R341      5.2055299282073975e-01
    z[0,3,1]  R342      4.6442502737045288e-01
    z[0,3,1]  R343      4.3314164876937866e-01
    z[0,3,1]  R344      1.7271231114864349e-01
    z[0,3,1]  R345      4.5343667268753052e-01
    z[0,3,1]  R346      3.5579410195350647e-01
    z[0,3,1]  R347      2.0928426086902618e-01
    z[0,3,1]  R348      4.4348591566085815e-01
    z[0,3,1]  R349      -7.8424614667892456e-01
    z[0,3,1]  R350      6.0361549258232117e-03
    z[0,3,1]  R351      5.5607044696807861e-01
    z[0,3,1]  R352      -6.6846656799316406e-01
    z[0,3,1]  R353      0.676803469657898
    z[0,3,1]  R354      5.2576822042465210e-01
    z[0,3,1]  R355      5.8075463771820068e-01
    z[0,3,1]  R356      3.6867663729935884e-03
    z[0,3,1]  R357      0.217891663312912
    z[0,3,1]  R358      1.5251954086124897e-02
    z[0,3,1]  R359      0.296316534280777
    z[0,3,1]  R360      2.5337365269660950e-01
    z[0,3,1]  R361      4.2025262117385864e-01
    z[0,3,1]  R362      0.671235203742981
    z[0,3,1]  R363      1.3216313719749451e-01
    z[0,3,1]  R364      1.7424921691417694e-01
    z[0,3,1]  R365      1.6426555812358856e-01
    z[0,3,1]  R366      0.107903391122818
    z[0,3,1]  R367      2.5297647714614868e-01
    z[0,3,1]  R368      2.3614084720611572e-01
    z[0,3,1]  R369      -1.7388090491294861e-02
    z[0,3,1]  R370      -3.0639293789863586e-01
    z[0,3,1]  R371      -2.3125894367694855e-01
    z[0,3,1]  R372      -2.1502365171909332e-01
    z[0,3,1]  R373      1.0191959142684937e-01
    z[0,3,1]  R374      3.8500636816024780e-01
    z[0,3,1]  R375      2.3486943542957306e-01
    z[0,3,1]  R376      0.492320716381073
    z[0,3,1]  R377      -1.7778109014034271e-01
    z[0,3,1]  R378      -3.3669683337211609e-01
    z[0,3,1]  R379      -0.718687117099762
    z[0,3,1]  R380      -2.8747299313545227e-01
    z[0,3,1]  R381      -7.5129759311676025e-01
    z[0,3,1]  R382      -7.0751869678497314e-01
    z[0,3,1]  R383      -6.9615596532821655e-01
    z[0,3,1]  R384      -6.8274384737014771e-01
    z[0,3,1]  R385      -4.2941969633102417e-01
    z[0,3,1]  R386      5.7843305170536041e-02
    z[0,3,1]  R387      0.267410010099411
    z[0,3,1]  R388      2.2924886643886566e-01
    z[0,3,1]  R389      -8.6893546581268311e-01
    z[0,3,1]  R390      -6.7153471708297729e-01
    z[0,3,1]  R391      0.466298371553421
    z[0,3,1]  R392      8.9918178319931030e-01
    z[0,3,1]  R393      2.1315771341323853e-01
    z[0,3,1]  R394      6.0820490121841431e-01
    z[0,3,1]  R395      1.7647847533226013e-01
    z[0,3,1]  R396      -3.6327905952930450e-02
    z[0,3,1]  R397      4.0621817111968994e-02
    z[0,3,1]  R398      2.8182867169380188e-01
    z[0,3,1]  R399      3.1204733252525330e-01
    z[0,3,1]  R400      -6.9999796152114868e-01
    z[0,3,1]  R401      6.9709378480911255e-01
    z[0,3,1]  R402      4.5377466082572937e-01
    z[0,3,1]  R403      0.0917489156126976
    z[0,3,1]  R404      4.4188103079795837e-01
    z[0,3,1]  R405      4.5328539609909058e-01
    z[0,3,1]  R406      4.9532383680343628e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R309      -1
    z[0,3,2]  R310      1
    z[0,3,2]  R319      2.6861715316772461e-01
    z[0,3,2]  R320      1.8759402632713318e-01
    z[0,3,2]  R321      1.9993208348751068e-01
    z[0,3,2]  R322      1.0501673817634583e-01
    z[0,3,2]  R323      2.3561078310012817e-01
    z[0,3,2]  R324      7.7200238592922688e-03
    z[0,3,2]  R325      -4.9707639217376709e-01
    z[0,3,2]  R326      -6.7353487014770508e-01
    z[0,3,2]  R327      -5.8032989501953125e-01
    z[0,3,2]  R328      -2.3401589691638947e-01
    z[0,3,2]  R329      -0.0516057126224041
    z[0,3,2]  R330      -2.6388362050056458e-01
    z[0,3,2]  R331      -2.0872253924608231e-02
    z[0,3,2]  R332      -3.9774301648139954e-01
    z[0,3,2]  R333      -3.9278933405876160e-01
    z[0,3,2]  R334      -1.7736141383647919e-01
    z[0,3,2]  R335      1.3082201778888702e-01
    z[0,3,2]  R336      -2.7695167064666748e-01
    z[0,3,2]  R337      1.1234810948371887e-01
    z[0,3,2]  R338      -7.2845116257667542e-02
    z[0,3,2]  R339      -4.1306439042091370e-01
    z[0,3,2]  R340      -4.2743068933486938e-01
    z[0,3,2]  R341      -4.4957584142684937e-01
    z[0,3,2]  R342      -1.5730418264865875e-01
    z[0,3,2]  R343      -3.3564716577529907e-01
    z[0,3,2]  R344      -1.3083352148532867e-01
    z[0,3,2]  R345      -1.7925995588302612e-01
    z[0,3,2]  R346      -6.5206638537347317e-03
    z[0,3,2]  R347      -2.4681134521961212e-01
    z[0,3,2]  R348      2.3112552240490913e-02
    z[0,3,2]  R349      -2.1220695972442627e-01
    z[0,3,2]  R350      -3.7491649389266968e-01
    z[0,3,2]  R351      -2.3035834729671478e-01
    z[0,3,2]  R352      -3.4647712111473083e-01
    z[0,3,2]  R353      -1.5503384172916412e-01
    z[0,3,2]  R354      -4.0012553334236145e-01
    z[0,3,2]  R355      7.5143299996852875e-02
    z[0,3,2]  R356      -6.7475301027297974e-01
    z[0,3,2]  R357      -2.6001867651939392e-01
    z[0,3,2]  R358      -8.0907016992568970e-01
    z[0,3,2]  R359      -1.3702294230461121e-01
    z[0,3,2]  R360      -3.8953217864036560e-01
    z[0,3,2]  R361      -4.6181124448776245e-01
    z[0,3,2]  R362      -2.3660619556903839e-01
    z[0,3,2]  R363      -2.6832882314920425e-02
    z[0,3,2]  R364      2.9775089025497437e-01
    z[0,3,2]  R365      2.6385051012039185e-01
    z[0,3,2]  R366      3.8567009568214417e-01
    z[0,3,2]  R367      7.4455849826335907e-02
    z[0,3,2]  R368      8.8931880891323090e-02
    z[0,3,2]  R369      1.0951692610979080e-01
    z[0,3,2]  R370      2.0774249732494354e-01
    z[0,3,2]  R371      1.5276065468788147e-01
    z[0,3,2]  R372      -5.8153885602951050e-01
    z[0,3,2]  R373      -7.0255053043365479e-01
    z[0,3,2]  R374      -7.0949810743331909e-01
    z[0,3,2]  R375      -7.4259728193283081e-01
    z[0,3,2]  R376      -8.2217389345169067e-01
    z[0,3,2]  R377      -8.1349629163742065e-01
    z[0,3,2]  R378      -3.9143708348274231e-01
    z[0,3,2]  R379      -6.0328418016433716e-01
    z[0,3,2]  R380      0.596624493598938
    z[0,3,2]  R381      -3.7396702170372009e-01
    z[0,3,2]  R382      -1.9479447603225708e-01
    z[0,3,2]  R383      -3.1045052409172058e-01
    z[0,3,2]  R384      -2.8534984588623047e-01
    z[0,3,2]  R385      -7.6795852184295654e-01
    z[0,3,2]  R386      -7.4868999421596527e-02
    z[0,3,2]  R387      2.5967352092266083e-02
    z[0,3,2]  R388      -3.5041561722755432e-01
    z[0,3,2]  R389      1.6584739089012146e-01
    z[0,3,2]  R390      -1.2550047039985657e-01
    z[0,3,2]  R391      5.0444994121789932e-02
    z[0,3,2]  R392      1.2987813353538513e-01
    z[0,3,2]  R393      -2.4401377141475677e-01
    z[0,3,2]  R394      6.6568940877914429e-01
    z[0,3,2]  R395      3.2851299643516541e-01
    z[0,3,2]  R396      1.8951553106307983e-01
    z[0,3,2]  R397      2.3056674003601074e-01
    z[0,3,2]  R398      -1.7282633483409882e-01
    z[0,3,2]  R399      8.4044122695922852e-01
    z[0,3,2]  R400      -4.4037258625030518e-01
    z[0,3,2]  R401      -1.7382787168025970e-01
    z[0,3,2]  R402      -2.4577982723712921e-01
    z[0,3,2]  R403      -4.2546781897544861e-01
    z[0,3,2]  R404      1.5264713205397129e-02
    z[0,3,2]  R405      -2.8176712989807129e-01
    z[0,3,2]  R406      2.4739317595958710e-03
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R311      -1
    z[0,3,3]  R312      1
    z[0,3,3]  R319      -1.6876442730426788e-01
    z[0,3,3]  R320      5.1429289579391479e-01
    z[0,3,3]  R321      -8.7289996445178986e-02
    z[0,3,3]  R322      -2.4192532896995544e-01
    z[0,3,3]  R323      -4.4740411639213562e-01
    z[0,3,3]  R324      3.8083219528198242e-01
    z[0,3,3]  R325      -2.1674276888370514e-01
    z[0,3,3]  R326      1.8280692398548126e-01
    z[0,3,3]  R327      -2.6684349775314331e-01
    z[0,3,3]  R328      5.5397957563400269e-02
    z[0,3,3]  R329      -2.0918834209442139e-01
    z[0,3,3]  R330      2.2222478687763214e-01
    z[0,3,3]  R331      -4.6384656429290771e-01
    z[0,3,3]  R332      -0.0847087875008583
    z[0,3,3]  R333      -2.8722891211509705e-01
    z[0,3,3]  R334      5.7033807039260864e-02
    z[0,3,3]  R335      -6.4385481178760529e-02
    z[0,3,3]  R336      -1.3314920663833618e-01
    z[0,3,3]  R337      -3.4458611160516739e-02
    z[0,3,3]  R338      -7.0325643755495548e-03
    z[0,3,3]  R339      2.3071725666522980e-01
    z[0,3,3]  R340      -6.8104617297649384e-02
    z[0,3,3]  R341      -9.5689199864864349e-02
    z[0,3,3]  R342      -1.5826018154621124e-01
    z[0,3,3]  R343      3.8550609350204468e-01
    z[0,3,3]  R344      -1.1226285994052887e-01
    z[0,3,3]  R345      2.6194056868553162e-01
    z[0,3,3]  R346      -5.7582074403762817e-01
    z[0,3,3]  R347      7.0373013615608215e-02
    z[0,3,3]  R348      -4.8064935207366943e-01
    z[0,3,3]  R349      1.9869594275951385e-01
    z[0,3,3]  R350      -1.7554265260696411e-01
    z[0,3,3]  R351      1.9822651520371437e-03
    z[0,3,3]  R352      3.7127229571342468e-01
    z[0,3,3]  R353      -1.6969843208789825e-01
    z[0,3,3]  R354      2.9292061924934387e-01
    z[0,3,3]  R355      -5.5232882499694824e-01
    z[0,3,3]  R356      2.0609617233276367e-01
    z[0,3,3]  R357      -8.0671662092208862e-01
    z[0,3,3]  R358      -4.1146126389503479e-01
    z[0,3,3]  R359      -4.6740320324897766e-01
    z[0,3,3]  R360      1.6549223661422729e-01
    z[0,3,3]  R361      2.2901932895183563e-01
    z[0,3,3]  R362      8.8411066681146622e-03
    z[0,3,3]  R363      2.8512412309646606e-01
    z[0,3,3]  R364      1.3275374472141266e-01
    z[0,3,3]  R365      -6.2729187309741974e-02
    z[0,3,3]  R366      3.4456110000610352e-01
    z[0,3,3]  R367      2.3610265552997589e-01
    z[0,3,3]  R368      1.9028577953577042e-02
    z[0,3,3]  R369      7.1820162236690521e-02
    z[0,3,3]  R370      -6.9875025749206543e-01
    z[0,3,3]  R371      -3.1949985027313232e-01
    z[0,3,3]  R372      -2.5845754891633987e-02
    z[0,3,3]  R373      1.2670738995075226e-01
    z[0,3,3]  R374      8.2595452666282654e-02
    z[0,3,3]  R375      7.8051716089248657e-02
    z[0,3,3]  R376      4.2187362909317017e-02
    z[0,3,3]  R377      -1.5487730503082275e-01
    z[0,3,3]  R378      -9.0489059686660767e-02
    z[0,3,3]  R379      2.5117591023445129e-01
    z[0,3,3]  R380      -3.9477947354316711e-01
    z[0,3,3]  R381      2.0609444379806519e-01
    z[0,3,3]  R382      0.452725350856781
    z[0,3,3]  R383      4.5630702376365662e-01
    z[0,3,3]  R384      6.1334747076034546e-01
    z[0,3,3]  R385      1.7385989427566528e-01
    z[0,3,3]  R386      -5.1712733507156372e-01
    z[0,3,3]  R387      -4.2898854613304138e-01
    z[0,3,3]  R388      -2.4088618159294128e-01
    z[0,3,3]  R389      2.0723941922187805e-01
    z[0,3,3]  R390      -2.8265175223350525e-01
    z[0,3,3]  R391      -8.5531359910964966e-01
    z[0,3,3]  R392      9.9095046520233154e-02
    z[0,3,3]  R393      -7.8946202993392944e-01
    z[0,3,3]  R394      -5.9033695608377457e-02
    z[0,3,3]  R395      3.0602285638451576e-02
    z[0,3,3]  R396      2.0207408070564270e-01
    z[0,3,3]  R397      4.4499572366476059e-02
    z[0,3,3]  R398      5.3708565235137939e-01
    z[0,3,3]  R399      -1.2076288461685181e-01
    z[0,3,3]  R400      -7.4476338922977448e-02
    z[0,3,3]  R401      -6.3618320226669312e-01
    z[0,3,3]  R402      -6.0746544599533081e-01
    z[0,3,3]  R403      -7.5059723854064941e-01
    z[0,3,3]  R404      4.6818497776985168e-01
    z[0,3,3]  R405      6.4250385761260986e-01
    z[0,3,3]  R406      7.8726017475128174e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R313      -1
    z[0,3,4]  R314      1
    z[0,3,4]  R319      1.1649116128683090e-01
    z[0,3,4]  R320      1.9057299196720123e-01
    z[0,3,4]  R321      2.0229449868202209e-01
    z[0,3,4]  R322      9.8868263885378838e-03
    z[0,3,4]  R323      -3.6068853735923767e-01
    z[0,3,4]  R324      -4.6930167078971863e-01
    z[0,3,4]  R325      3.1903919577598572e-01
    z[0,3,4]  R326      -9.6473604440689087e-02
    z[0,3,4]  R327      3.9080940186977386e-03
    z[0,3,4]  R328      2.9522275924682617e-01
    z[0,3,4]  R329      2.0334189757704735e-02
    z[0,3,4]  R330      2.8387141227722168e-01
    z[0,3,4]  R331      4.8437470197677612e-01
    z[0,3,4]  R332      6.2884253263473511e-01
    z[0,3,4]  R333      1.2406851351261139e-01
    z[0,3,4]  R334      -2.5360816717147827e-01
    z[0,3,4]  R335      -0.281288206577301
    z[0,3,4]  R336      -4.3320730328559875e-01
    z[0,3,4]  R337      2.9039615765213966e-02
    z[0,3,4]  R338      -2.8913456201553345e-01
    z[0,3,4]  R339      -5.8810006827116013e-02
    z[0,3,4]  R340      6.2225043773651123e-01
    z[0,3,4]  R341      -0.0938170999288559
    z[0,3,4]  R342      3.7507492303848267e-01
    z[0,3,4]  R343      4.4238457083702087e-01
    z[0,3,4]  R344      -1.0518613457679749e-01
    z[0,3,4]  R345      -3.6167246103286743e-01
    z[0,3,4]  R346      1.1317305266857147e-01
    z[0,3,4]  R347      -3.1123054027557373e-01
    z[0,3,4]  R348      -2.2253684699535370e-01
    z[0,3,4]  R349      -2.4853645265102386e-01
    z[0,3,4]  R350      4.9042135477066040e-01
    z[0,3,4]  R351      4.3059471249580383e-01
    z[0,3,4]  R352      -3.4301328659057617e-01
    z[0,3,4]  R353      -3.3631703257560730e-01
    z[0,3,4]  R354      -4.0257643908262253e-02
    z[0,3,4]  R355      2.7994525432586670e-01
    z[0,3,4]  R356      1.3417159020900726e-01
    z[0,3,4]  R357      -1.6669304668903351e-01
    z[0,3,4]  R358      -9.8640426993370056e-02
    z[0,3,4]  R359      5.5449718236923218e-01
    z[0,3,4]  R360      5.5251830816268921e-01
    z[0,3,4]  R361      1.8550334870815277e-01
    z[0,3,4]  R362      3.8085004687309265e-01
    z[0,3,4]  R363      -1.7400009930133820e-01
    z[0,3,4]  R364      -1.8838274478912354e-01
    z[0,3,4]  R365      -1.2845905125141144e-01
    z[0,3,4]  R366      1.1475032567977905e-01
    z[0,3,4]  R367      8.3073377609252930e-02
    z[0,3,4]  R368      -3.0021220445632935e-01
    z[0,3,4]  R369      1.5497450530529022e-01
    z[0,3,4]  R370      4.9810070544481277e-02
    z[0,3,4]  R371      -8.2780605554580688e-01
    z[0,3,4]  R372      -2.7678960561752319e-01
    z[0,3,4]  R373      -5.9021586179733276e-01
    z[0,3,4]  R374      -3.2592964172363281e-01
    z[0,3,4]  R375      -3.5340425372123718e-01
    z[0,3,4]  R376      -2.1101097762584686e-01
    z[0,3,4]  R377      -8.1960320472717285e-02
    z[0,3,4]  R378      -5.4664772748947144e-01
    z[0,3,4]  R379      1.3832703232765198e-01
    z[0,3,4]  R380      -1.6693617403507233e-01
    z[0,3,4]  R381      8.9001677930355072e-02
    z[0,3,4]  R382      -1.7687901854515076e-01
    z[0,3,4]  R383      -1.4729164540767670e-01
    z[0,3,4]  R384      -1.5474909543991089e-01
    z[0,3,4]  R385      -1.9208058714866638e-01
    z[0,3,4]  R386      7.8312915563583374e-01
    z[0,3,4]  R387      6.8898481130599976e-01
    z[0,3,4]  R388      6.6069936752319336e-01
    z[0,3,4]  R389      -2.2109439969062805e-01
    z[0,3,4]  R390      4.3592989444732666e-01
    z[0,3,4]  R391      -1.4450874924659729e-01
    z[0,3,4]  R392      0.0320991687476635
    z[0,3,4]  R393      -4.8460375517606735e-02
    z[0,3,4]  R394      2.4460107088088989e-01
    z[0,3,4]  R395      9.5805555582046509e-02
    z[0,3,4]  R396      1.2552116811275482e-01
    z[0,3,4]  R397      4.9232020974159241e-01
    z[0,3,4]  R398      1.6777239739894867e-01
    z[0,3,4]  R399      1.8751016259193420e-01
    z[0,3,4]  R400      -1.9941788911819458e-01
    z[0,3,4]  R401      -3.2221134752035141e-02
    z[0,3,4]  R402      -0.0489906370639801
    z[0,3,4]  R403      -2.7909772470593452e-02
    z[0,3,4]  R404      -2.1687658131122589e-01
    z[0,3,4]  R405      -5.3138142824172974e-01
    z[0,3,4]  R406      -1.9959336519241333e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R315      -1
    z[0,3,5]  R316      1
    z[0,3,5]  R319      -7.4515056610107422e-01
    z[0,3,5]  R320      -2.1487425267696381e-01
    z[0,3,5]  R321      0.00630249222740531
    z[0,3,5]  R322      -2.1305792033672333e-01
    z[0,3,5]  R323      5.0106555223464966e-02
    z[0,3,5]  R324      -1.7384263873100281e-01
    z[0,3,5]  R325      1.6594673693180084e-01
    z[0,3,5]  R326      2.0208194851875305e-01
    z[0,3,5]  R327      2.1927194669842720e-02
    z[0,3,5]  R328      -1.9410748034715652e-02
    z[0,3,5]  R329      -1.5323872864246368e-01
    z[0,3,5]  R330      -1.7595407366752625e-01
    z[0,3,5]  R331      -1.3384682126343250e-02
    z[0,3,5]  R332      2.3417235910892487e-01
    z[0,3,5]  R333      5.7139742374420166e-01
    z[0,3,5]  R334      6.7183399200439453e-01
    z[0,3,5]  R335      4.9277597665786743e-01
    z[0,3,5]  R336      7.1126115322113037e-01
    z[0,3,5]  R337      4.1232302784919739e-01
    z[0,3,5]  R338      6.3492357730865479e-01
    z[0,3,5]  R339      3.4589615464210510e-01
    z[0,3,5]  R340      2.6017433404922485e-01
    z[0,3,5]  R341      5.0373071432113647e-01
    z[0,3,5]  R342      4.5085495710372925e-01
    z[0,3,5]  R343      3.8269010186195374e-01
    z[0,3,5]  R344      7.3813176155090332e-01
    z[0,3,5]  R345      5.6638425588607788e-01
    z[0,3,5]  R346      4.4393953680992126e-01
    z[0,3,5]  R347      -2.7090549468994141e-01
    z[0,3,5]  R348      -1.2551090121269226e-01
    z[0,3,5]  R349      4.4402226805686951e-01
    z[0,3,5]  R350      0.276623398065567
    z[0,3,5]  R351      5.0560760498046875e-01
    z[0,3,5]  R352      8.9275732636451721e-02
    z[0,3,5]  R353      4.5141872763633728e-01
    z[0,3,5]  R354      1.6238547861576080e-01
    z[0,3,5]  R355      1.7913152277469635e-01
    z[0,3,5]  R356      0.611366331577301
    z[0,3,5]  R357      3.3558952808380127e-01
    z[0,3,5]  R358      -2.5231644511222839e-01
    z[0,3,5]  R359      3.2803300023078918e-01
    z[0,3,5]  R360      4.8965471982955933e-01
    z[0,3,5]  R361      4.1253602504730225e-01
    z[0,3,5]  R362      1.4516760408878326e-01
    z[0,3,5]  R363      1.7920201644301414e-02
    z[0,3,5]  R364      -1.0084106028079987e-01
    z[0,3,5]  R365      -1.7986075580120087e-01
    z[0,3,5]  R366      -3.4360468387603760e-02
    z[0,3,5]  R367      -3.2862797379493713e-01
    z[0,3,5]  R368      -1.3820065557956696e-01
    z[0,3,5]  R369      -5.8452707529067993e-01
    z[0,3,5]  R370      -1.2743914127349854e-01
    z[0,3,5]  R371      1.7452562227845192e-02
    z[0,3,5]  R372      8.7726123631000519e-02
    z[0,3,5]  R373      -1.3058429956436157e-01
    z[0,3,5]  R374      -7.9703167080879211e-02
    z[0,3,5]  R375      -3.2697755098342896e-01
    z[0,3,5]  R376      2.0583800971508026e-02
    z[0,3,5]  R377      4.2072642594575882e-02
    z[0,3,5]  R378      -1.1930692009627819e-02
    z[0,3,5]  R379      1.0244762152433395e-01
    z[0,3,5]  R380      -2.3369353264570236e-02
    z[0,3,5]  R381      -1.6928309202194214e-01
    z[0,3,5]  R382      -2.7417975664138794e-01
    z[0,3,5]  R383      3.0409688130021095e-02
    z[0,3,5]  R384      1.0035818442702293e-02
    z[0,3,5]  R385      2.0721469819545746e-01
    z[0,3,5]  R386      3.1202328205108643e-01
    z[0,3,5]  R387      2.7599191665649414e-01
    z[0,3,5]  R388      3.9503401517868042e-01
    z[0,3,5]  R389      -1.6550481319427490e-01
    z[0,3,5]  R390      3.0633789300918579e-01
    z[0,3,5]  R391      1.5955626964569092e-01
    z[0,3,5]  R392      2.4823763966560364e-01
    z[0,3,5]  R393      2.1159994602203369e-01
    z[0,3,5]  R394      -2.1541567146778107e-01
    z[0,3,5]  R395      -9.5731422305107117e-02
    z[0,3,5]  R396      -0.0866822898387909
    z[0,3,5]  R397      -7.0915900170803070e-02
    z[0,3,5]  R398      -2.4924285709857941e-02
    z[0,3,5]  R399      -8.8141247630119324e-02
    z[0,3,5]  R400      2.8659364581108093e-01
    z[0,3,5]  R401      0.0913451761007309
    z[0,3,5]  R402      -1.2837243080139160e-01
    z[0,3,5]  R403      3.7850487232208252e-01
    z[0,3,5]  R404      -8.4200866520404816e-02
    z[0,3,5]  R405      0.0953843742609024
    z[0,3,5]  R406      2.8075750917196274e-02
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R317      -1
    z[0,3,6]  R318      1
    z[0,3,6]  R319      3.4039998054504395e-01
    z[0,3,6]  R320      5.9781733900308609e-02
    z[0,3,6]  R321      -0.722275972366333
    z[0,3,6]  R322      5.9845127165317535e-02
    z[0,3,6]  R323      1.1553537100553513e-01
    z[0,3,6]  R324      -1.0749082267284393e-01
    z[0,3,6]  R325      2.8849408030509949e-01
    z[0,3,6]  R326      1.0326829552650452e-01
    z[0,3,6]  R327      2.9383847117424011e-01
    z[0,3,6]  R328      1.4483739435672760e-01
    z[0,3,6]  R329      1.3990125060081482e-01
    z[0,3,6]  R330      9.2209856957197189e-03
    z[0,3,6]  R331      -1.0074402205646038e-02
    z[0,3,6]  R332      2.7018001675605774e-01
    z[0,3,6]  R333      -4.3257862329483032e-01
    z[0,3,6]  R334      -3.8332757353782654e-01
    z[0,3,6]  R335      -2.4202281236648560e-01
    z[0,3,6]  R336      6.0550529509782791e-02
    z[0,3,6]  R337      -3.2630729675292969e-01
    z[0,3,6]  R338      1.2261397391557693e-01
    z[0,3,6]  R339      6.9774365425109863e-01
    z[0,3,6]  R340      5.4447591304779053e-01
    z[0,3,6]  R341      -3.7754201889038086e-01
    z[0,3,6]  R342      1.8731378018856049e-01
    z[0,3,6]  R343      -6.7560456693172455e-02
    z[0,3,6]  R344      5.9625748544931412e-02
    z[0,3,6]  R345      0.201944500207901
    z[0,3,6]  R346      4.6348896622657776e-01
    z[0,3,6]  R347      1.8456105142831802e-02
    z[0,3,6]  R348      -1.1119223199784756e-02
    z[0,3,6]  R349      -2.0017798244953156e-01
    z[0,3,6]  R350      6.6070586442947388e-01
    z[0,3,6]  R351      1.2391008436679840e-01
    z[0,3,6]  R352      4.0128645300865173e-01
    z[0,3,6]  R353      2.2384525835514069e-01
    z[0,3,6]  R354      1.4391423761844635e-01
    z[0,3,6]  R355      2.7509528398513794e-01
    z[0,3,6]  R356      -2.0410434901714325e-01
    z[0,3,6]  R357      -1.0403953492641449e-01
    z[0,3,6]  R358      -2.9194223880767822e-01
    z[0,3,6]  R359      3.9690226316452026e-01
    z[0,3,6]  R360      1.3834813237190247e-01
    z[0,3,6]  R361      4.5711182057857513e-02
    z[0,3,6]  R362      -1.5375925600528717e-01
    z[0,3,6]  R363      -8.9999385178089142e-02
    z[0,3,6]  R364      -9.7879678010940552e-02
    z[0,3,6]  R365      -3.2398992776870728e-01
    z[0,3,6]  R366      -1.2083017081022263e-01
    z[0,3,6]  R367      -1.1674593389034271e-01
    z[0,3,6]  R368      2.1118935942649841e-01
    z[0,3,6]  R369      -7.7593624591827393e-02
    z[0,3,6]  R370      5.8776468038558960e-01
    z[0,3,6]  R371      2.1646265685558319e-01
    z[0,3,6]  R372      2.5525358319282532e-01
    z[0,3,6]  R373      -5.6083530187606812e-02
    z[0,3,6]  R374      -3.8818728923797607e-01
    z[0,3,6]  R375      -1.5079762041568756e-01
    z[0,3,6]  R376      -8.9222088456153870e-02
    z[0,3,6]  R377      -3.5436192154884338e-01
    z[0,3,6]  R378      -1.9524197280406952e-01
    z[0,3,6]  R379      -1.4552305638790131e-01
    z[0,3,6]  R380      -6.1338496208190918e-01
    z[0,3,6]  R381      -4.2719018459320068e-01
    z[0,3,6]  R382      -1.6609518229961395e-01
    z[0,3,6]  R383      -3.9867994189262390e-01
    z[0,3,6]  R384      2.2725857794284821e-01
    z[0,3,6]  R385      1.4063820242881775e-01
    z[0,3,6]  R386      1.0753098130226135e-01
    z[0,3,6]  R387      4.2588347196578979e-01
    z[0,3,6]  R388      3.9786690473556519e-01
    z[0,3,6]  R389      -2.3114077746868134e-01
    z[0,3,6]  R390      -3.6359328031539917e-01
    z[0,3,6]  R391      -3.9879478514194489e-02
    z[0,3,6]  R392      1.8042442202568054e-01
    z[0,3,6]  R393      -3.4936955571174622e-01
    z[0,3,6]  R394      6.1725240200757980e-02
    z[0,3,6]  R395      -6.5246790647506714e-02
    z[0,3,6]  R396      -3.6207631230354309e-01
    z[0,3,6]  R397      -1.3373765349388123e-01
    z[0,3,6]  R398      4.3322015553712845e-02
    z[0,3,6]  R399      -2.6974296569824219e-01
    z[0,3,6]  R400      -3.0658626556396484e-01
    z[0,3,6]  R401      -2.6294332742691040e-01
    z[0,3,6]  R402      5.6234681606292725e-01
    z[0,3,6]  R403      3.3876877278089523e-02
    z[0,3,6]  R404      1.6584002971649170e-01
    z[0,3,6]  R405      9.2581234872341156e-02
    z[0,3,6]  R406      -3.0335170030593872e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R407      -1
    z[3,0,0]  R408      1
    z[3,0,0]  R421      7.8155982494354248e-01
    z[3,0,0]  R422      1.0259279608726501e-01
    z[3,0,0]  R423      2.9779151082038879e-01
    z[3,0,0]  R424      -6.8223649263381958e-01
    z[3,0,0]  R425      -3.3380830287933350e-01
    z[3,0,0]  R426      -2.7980053424835205e-01
    z[3,0,0]  R427      -3.6434146761894226e-01
    z[3,0,0]  R428      -1.6419696807861328e-01
    z[3,0,0]  R429      -3.8544863462448120e-01
    z[3,0,0]  R430      -0.623007595539093
    z[3,0,0]  R431      -7.5105018913745880e-02
    z[3,0,0]  R432      -2.9878070577979088e-02
    z[3,0,0]  R433      -1.8481391668319702e-01
    z[3,0,0]  R434      -3.4994819760322571e-01
    z[3,0,0]  R435      -1.7089748382568359e-01
    z[3,0,0]  R436      -2.3380618542432785e-02
    z[3,0,0]  R437      3.0983725190162659e-01
    z[3,0,0]  R438      3.7620510905981064e-02
    z[3,0,0]  R439      -1.0741529613733292e-01
    z[3,0,0]  R440      1.2551528215408325e-01
    z[3,0,0]  R441      -2.1165297925472260e-01
    z[3,0,0]  R442      1.9318635761737823e-01
    z[3,0,0]  R443      -2.2988358512520790e-02
    z[3,0,0]  R444      2.6377752423286438e-01
    z[3,0,0]  R445      3.2029467821121216e-01
    z[3,0,0]  R446      -0.270953506231308
    z[3,0,0]  R447      -9.1509437561035156e-01
    z[3,0,0]  R448      -8.7610584497451782e-01
    z[3,0,0]  R449      -8.2335573434829712e-01
    z[3,0,0]  R450      -7.5604027509689331e-01
    z[3,0,0]  R451      -0.256926566362381
    z[3,0,0]  R452      3.0761915445327759e-01
    z[3,0,0]  R453      2.4368667975068092e-02
    z[3,0,0]  R454      -1.7191019654273987e-01
    z[3,0,0]  R455      3.1932809948921204e-01
    z[3,0,0]  R456      -0.70970618724823
    z[3,0,0]  R457      -4.7882348299026489e-02
    z[3,0,0]  R458      -4.7134313732385635e-02
    z[3,0,0]  R459      4.6167784929275513e-01
    z[3,0,0]  R460      7.8284525871276855e-01
    z[3,0,0]  R461      6.0020017623901367e-01
    z[3,0,0]  R462      9.0609920024871826e-01
    z[3,0,0]  R463      7.7066212892532349e-01
    z[3,0,0]  R464      7.3027622699737549e-01
    z[3,0,0]  R465      -2.1502149105072021e-01
    z[3,0,0]  R466      -1.9992746412754059e-01
    z[3,0,0]  R467      -2.9732275009155273e-01
    z[3,0,0]  R468      -4.4450685381889343e-01
    z[3,0,0]  R469      -4.3208426237106323e-01
    z[3,0,0]  R470      -0.336843878030777
    z[3,0,0]  R471      -4.0878662467002869e-01
    z[3,0,0]  R472      -5.3279228508472443e-02
    z[3,0,0]  R473      -4.5024999976158142e-01
    z[3,0,0]  R474      -0.411024808883667
    z[3,0,0]  R475      -4.4169384241104126e-01
    z[3,0,0]  R476      -3.6607587337493896e-01
    z[3,0,0]  R477      -0.486956387758255
    z[3,0,0]  R478      -5.4662817716598511e-01
    z[3,0,0]  R479      0.380811482667923
    z[3,0,0]  R480      2.3891361057758331e-01
    z[3,0,0]  R481      -3.3565676212310791e-01
    z[3,0,0]  R482      -0.596221923828125
    z[3,0,0]  R483      -4.5209968090057373e-01
    z[3,0,0]  R484      -6.1724567413330078e-01
    z[3,0,0]  R485      -4.4862964749336243e-01
    z[3,0,0]  R486      -3.4217828512191772e-01
    z[3,0,0]  R487      -8.4837317466735840e-01
    z[3,0,0]  R488      -7.1159183979034424e-01
    z[3,0,0]  R489      -3.8063347339630127e-02
    z[3,0,0]  R490      2.7389812469482422e-01
    z[3,0,0]  R491      4.2580771446228027e-01
    z[3,0,0]  R492      -0.0927567332983017
    z[3,0,0]  R493      -3.4944143891334534e-01
    z[3,0,0]  R494      -6.5495330095291138e-01
    z[3,0,0]  R495      -4.0727809071540833e-01
    z[3,0,0]  R496      -2.6227793097496033e-01
    z[3,0,0]  R497      -0.287907212972641
    z[3,0,0]  R498      -1.3133455812931061e-01
    z[3,0,0]  R499      3.1992402672767639e-01
    z[3,0,0]  R500      4.3874862790107727e-01
    z[3,0,0]  R501      -5.9243679046630859e-01
    z[3,0,0]  R502      -5.5101764202117920e-01
    z[3,0,0]  R503      -9.2834258079528809e-01
    z[3,0,0]  R504      -8.9895540475845337e-01
    z[3,0,0]  R505      -8.6350661516189575e-01
    z[3,0,0]  R506      -8.3183217048645020e-01
    z[3,0,0]  R507      -8.6382150650024414e-01
    z[3,0,0]  R508      -8.8438612222671509e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R409      -1
    z[3,0,1]  R410      1
    z[3,0,1]  R421      -1.7388090491294861e-02
    z[3,0,1]  R422      -3.0639293789863586e-01
    z[3,0,1]  R423      -2.3125894367694855e-01
    z[3,0,1]  R424      -2.1502365171909332e-01
    z[3,0,1]  R425      1.0191959142684937e-01
    z[3,0,1]  R426      3.8500636816024780e-01
    z[3,0,1]  R427      2.3486943542957306e-01
    z[3,0,1]  R428      0.492320716381073
    z[3,0,1]  R429      -1.7778109014034271e-01
    z[3,0,1]  R430      -3.3669683337211609e-01
    z[3,0,1]  R431      -0.718687117099762
    z[3,0,1]  R432      -2.8747299313545227e-01
    z[3,0,1]  R433      -7.5129759311676025e-01
    z[3,0,1]  R434      -7.0751869678497314e-01
    z[3,0,1]  R435      -6.9615596532821655e-01
    z[3,0,1]  R436      -6.8274384737014771e-01
    z[3,0,1]  R437      -4.2941969633102417e-01
    z[3,0,1]  R438      5.7843305170536041e-02
    z[3,0,1]  R439      0.267410010099411
    z[3,0,1]  R440      2.2924886643886566e-01
    z[3,0,1]  R441      -8.6893546581268311e-01
    z[3,0,1]  R442      -6.7153471708297729e-01
    z[3,0,1]  R443      0.466298371553421
    z[3,0,1]  R444      8.9918178319931030e-01
    z[3,0,1]  R445      2.1315771341323853e-01
    z[3,0,1]  R446      6.0820490121841431e-01
    z[3,0,1]  R447      1.7647847533226013e-01
    z[3,0,1]  R448      -3.6327905952930450e-02
    z[3,0,1]  R449      4.0621817111968994e-02
    z[3,0,1]  R450      2.8182867169380188e-01
    z[3,0,1]  R451      3.1204733252525330e-01
    z[3,0,1]  R452      -6.9999796152114868e-01
    z[3,0,1]  R453      6.9709378480911255e-01
    z[3,0,1]  R454      4.5377466082572937e-01
    z[3,0,1]  R455      0.0917489156126976
    z[3,0,1]  R456      4.4188103079795837e-01
    z[3,0,1]  R457      4.5328539609909058e-01
    z[3,0,1]  R458      4.9532383680343628e-01
    z[3,0,1]  R459      3.9054531604051590e-02
    z[3,0,1]  R460      3.7439472973346710e-02
    z[3,0,1]  R461      -1.7181976139545441e-01
    z[3,0,1]  R462      -2.4567259848117828e-01
    z[3,0,1]  R463      -6.6646635532379150e-02
    z[3,0,1]  R464      -2.4409869313240051e-01
    z[3,0,1]  R465      6.6869288682937622e-01
    z[3,0,1]  R466      0.641991376876831
    z[3,0,1]  R467      6.4558017253875732e-01
    z[3,0,1]  R468      7.9754006862640381e-01
    z[3,0,1]  R469      -8.5053634643554688e-01
    z[3,0,1]  R470      -0.809870183467865
    z[3,0,1]  R471      -0.618388831615448
    z[3,0,1]  R472      -5.5543613433837891e-01
    z[3,0,1]  R473      1.7742255330085754e-01
    z[3,0,1]  R474      3.6569207906723022e-01
    z[3,0,1]  R475      6.3491761684417725e-01
    z[3,0,1]  R476      2.7263557910919189e-01
    z[3,0,1]  R477      6.8682879209518433e-01
    z[3,0,1]  R478      4.4054615497589111e-01
    z[3,0,1]  R479      1.4553695917129517e-01
    z[3,0,1]  R480      -0.0651506707072258
    z[3,0,1]  R481      5.2055299282073975e-01
    z[3,0,1]  R482      4.6442502737045288e-01
    z[3,0,1]  R483      4.3314164876937866e-01
    z[3,0,1]  R484      1.7271231114864349e-01
    z[3,0,1]  R485      4.5343667268753052e-01
    z[3,0,1]  R486      3.5579410195350647e-01
    z[3,0,1]  R487      2.0928426086902618e-01
    z[3,0,1]  R488      4.4348591566085815e-01
    z[3,0,1]  R489      -7.8424614667892456e-01
    z[3,0,1]  R490      6.0361549258232117e-03
    z[3,0,1]  R491      5.5607044696807861e-01
    z[3,0,1]  R492      -6.6846656799316406e-01
    z[3,0,1]  R493      0.676803469657898
    z[3,0,1]  R494      5.2576822042465210e-01
    z[3,0,1]  R495      5.8075463771820068e-01
    z[3,0,1]  R496      3.6867663729935884e-03
    z[3,0,1]  R497      0.217891663312912
    z[3,0,1]  R498      1.5251954086124897e-02
    z[3,0,1]  R499      0.296316534280777
    z[3,0,1]  R500      2.5337365269660950e-01
    z[3,0,1]  R501      4.2025262117385864e-01
    z[3,0,1]  R502      0.671235203742981
    z[3,0,1]  R503      1.3216313719749451e-01
    z[3,0,1]  R504      1.7424921691417694e-01
    z[3,0,1]  R505      1.6426555812358856e-01
    z[3,0,1]  R506      0.107903391122818
    z[3,0,1]  R507      2.5297647714614868e-01
    z[3,0,1]  R508      2.3614084720611572e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R411      -1
    z[3,0,2]  R412      1
    z[3,0,2]  R421      1.0951692610979080e-01
    z[3,0,2]  R422      2.0774249732494354e-01
    z[3,0,2]  R423      1.5276065468788147e-01
    z[3,0,2]  R424      -5.8153885602951050e-01
    z[3,0,2]  R425      -7.0255053043365479e-01
    z[3,0,2]  R426      -7.0949810743331909e-01
    z[3,0,2]  R427      -7.4259728193283081e-01
    z[3,0,2]  R428      -8.2217389345169067e-01
    z[3,0,2]  R429      -8.1349629163742065e-01
    z[3,0,2]  R430      -3.9143708348274231e-01
    z[3,0,2]  R431      -6.0328418016433716e-01
    z[3,0,2]  R432      0.596624493598938
    z[3,0,2]  R433      -3.7396702170372009e-01
    z[3,0,2]  R434      -1.9479447603225708e-01
    z[3,0,2]  R435      -3.1045052409172058e-01
    z[3,0,2]  R436      -2.8534984588623047e-01
    z[3,0,2]  R437      -7.6795852184295654e-01
    z[3,0,2]  R438      -7.4868999421596527e-02
    z[3,0,2]  R439      2.5967352092266083e-02
    z[3,0,2]  R440      -3.5041561722755432e-01
    z[3,0,2]  R441      1.6584739089012146e-01
    z[3,0,2]  R442      -1.2550047039985657e-01
    z[3,0,2]  R443      5.0444994121789932e-02
    z[3,0,2]  R444      1.2987813353538513e-01
    z[3,0,2]  R445      -2.4401377141475677e-01
    z[3,0,2]  R446      6.6568940877914429e-01
    z[3,0,2]  R447      3.2851299643516541e-01
    z[3,0,2]  R448      1.8951553106307983e-01
    z[3,0,2]  R449      2.3056674003601074e-01
    z[3,0,2]  R450      -1.7282633483409882e-01
    z[3,0,2]  R451      8.4044122695922852e-01
    z[3,0,2]  R452      -4.4037258625030518e-01
    z[3,0,2]  R453      -1.7382787168025970e-01
    z[3,0,2]  R454      -2.4577982723712921e-01
    z[3,0,2]  R455      -4.2546781897544861e-01
    z[3,0,2]  R456      1.5264713205397129e-02
    z[3,0,2]  R457      -2.8176712989807129e-01
    z[3,0,2]  R458      2.4739317595958710e-03
    z[3,0,2]  R459      2.6861715316772461e-01
    z[3,0,2]  R460      1.8759402632713318e-01
    z[3,0,2]  R461      1.9993208348751068e-01
    z[3,0,2]  R462      1.0501673817634583e-01
    z[3,0,2]  R463      2.3561078310012817e-01
    z[3,0,2]  R464      7.7200238592922688e-03
    z[3,0,2]  R465      -4.9707639217376709e-01
    z[3,0,2]  R466      -6.7353487014770508e-01
    z[3,0,2]  R467      -5.8032989501953125e-01
    z[3,0,2]  R468      -2.3401589691638947e-01
    z[3,0,2]  R469      -0.0516057126224041
    z[3,0,2]  R470      -2.6388362050056458e-01
    z[3,0,2]  R471      -2.0872253924608231e-02
    z[3,0,2]  R472      -3.9774301648139954e-01
    z[3,0,2]  R473      -3.9278933405876160e-01
    z[3,0,2]  R474      -1.7736141383647919e-01
    z[3,0,2]  R475      1.3082201778888702e-01
    z[3,0,2]  R476      -2.7695167064666748e-01
    z[3,0,2]  R477      1.1234810948371887e-01
    z[3,0,2]  R478      -7.2845116257667542e-02
    z[3,0,2]  R479      -4.1306439042091370e-01
    z[3,0,2]  R480      -4.2743068933486938e-01
    z[3,0,2]  R481      -4.4957584142684937e-01
    z[3,0,2]  R482      -1.5730418264865875e-01
    z[3,0,2]  R483      -3.3564716577529907e-01
    z[3,0,2]  R484      -1.3083352148532867e-01
    z[3,0,2]  R485      -1.7925995588302612e-01
    z[3,0,2]  R486      -6.5206638537347317e-03
    z[3,0,2]  R487      -2.4681134521961212e-01
    z[3,0,2]  R488      2.3112552240490913e-02
    z[3,0,2]  R489      -2.1220695972442627e-01
    z[3,0,2]  R490      -3.7491649389266968e-01
    z[3,0,2]  R491      -2.3035834729671478e-01
    z[3,0,2]  R492      -3.4647712111473083e-01
    z[3,0,2]  R493      -1.5503384172916412e-01
    z[3,0,2]  R494      -4.0012553334236145e-01
    z[3,0,2]  R495      7.5143299996852875e-02
    z[3,0,2]  R496      -6.7475301027297974e-01
    z[3,0,2]  R497      -2.6001867651939392e-01
    z[3,0,2]  R498      -8.0907016992568970e-01
    z[3,0,2]  R499      -1.3702294230461121e-01
    z[3,0,2]  R500      -3.8953217864036560e-01
    z[3,0,2]  R501      -4.6181124448776245e-01
    z[3,0,2]  R502      -2.3660619556903839e-01
    z[3,0,2]  R503      -2.6832882314920425e-02
    z[3,0,2]  R504      2.9775089025497437e-01
    z[3,0,2]  R505      2.6385051012039185e-01
    z[3,0,2]  R506      3.8567009568214417e-01
    z[3,0,2]  R507      7.4455849826335907e-02
    z[3,0,2]  R508      8.8931880891323090e-02
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R413      -1
    z[3,0,3]  R414      1
    z[3,0,3]  R421      7.1820162236690521e-02
    z[3,0,3]  R422      -6.9875025749206543e-01
    z[3,0,3]  R423      -3.1949985027313232e-01
    z[3,0,3]  R424      -2.5845754891633987e-02
    z[3,0,3]  R425      1.2670738995075226e-01
    z[3,0,3]  R426      8.2595452666282654e-02
    z[3,0,3]  R427      7.8051716089248657e-02
    z[3,0,3]  R428      4.2187362909317017e-02
    z[3,0,3]  R429      -1.5487730503082275e-01
    z[3,0,3]  R430      -9.0489059686660767e-02
    z[3,0,3]  R431      2.5117591023445129e-01
    z[3,0,3]  R432      -3.9477947354316711e-01
    z[3,0,3]  R433      2.0609444379806519e-01
    z[3,0,3]  R434      0.452725350856781
    z[3,0,3]  R435      4.5630702376365662e-01
    z[3,0,3]  R436      6.1334747076034546e-01
    z[3,0,3]  R437      1.7385989427566528e-01
    z[3,0,3]  R438      -5.1712733507156372e-01
    z[3,0,3]  R439      -4.2898854613304138e-01
    z[3,0,3]  R440      -2.4088618159294128e-01
    z[3,0,3]  R441      2.0723941922187805e-01
    z[3,0,3]  R442      -2.8265175223350525e-01
    z[3,0,3]  R443      -8.5531359910964966e-01
    z[3,0,3]  R444      9.9095046520233154e-02
    z[3,0,3]  R445      -7.8946202993392944e-01
    z[3,0,3]  R446      -5.9033695608377457e-02
    z[3,0,3]  R447      3.0602285638451576e-02
    z[3,0,3]  R448      2.0207408070564270e-01
    z[3,0,3]  R449      4.4499572366476059e-02
    z[3,0,3]  R450      5.3708565235137939e-01
    z[3,0,3]  R451      -1.2076288461685181e-01
    z[3,0,3]  R452      -7.4476338922977448e-02
    z[3,0,3]  R453      -6.3618320226669312e-01
    z[3,0,3]  R454      -6.0746544599533081e-01
    z[3,0,3]  R455      -7.5059723854064941e-01
    z[3,0,3]  R456      4.6818497776985168e-01
    z[3,0,3]  R457      6.4250385761260986e-01
    z[3,0,3]  R458      7.8726017475128174e-01
    z[3,0,3]  R459      -1.6876442730426788e-01
    z[3,0,3]  R460      5.1429289579391479e-01
    z[3,0,3]  R461      -8.7289996445178986e-02
    z[3,0,3]  R462      -2.4192532896995544e-01
    z[3,0,3]  R463      -4.4740411639213562e-01
    z[3,0,3]  R464      3.8083219528198242e-01
    z[3,0,3]  R465      -2.1674276888370514e-01
    z[3,0,3]  R466      1.8280692398548126e-01
    z[3,0,3]  R467      -2.6684349775314331e-01
    z[3,0,3]  R468      5.5397957563400269e-02
    z[3,0,3]  R469      -2.0918834209442139e-01
    z[3,0,3]  R470      2.2222478687763214e-01
    z[3,0,3]  R471      -4.6384656429290771e-01
    z[3,0,3]  R472      -0.0847087875008583
    z[3,0,3]  R473      -2.8722891211509705e-01
    z[3,0,3]  R474      5.7033807039260864e-02
    z[3,0,3]  R475      -6.4385481178760529e-02
    z[3,0,3]  R476      -1.3314920663833618e-01
    z[3,0,3]  R477      -3.4458611160516739e-02
    z[3,0,3]  R478      -7.0325643755495548e-03
    z[3,0,3]  R479      2.3071725666522980e-01
    z[3,0,3]  R480      -6.8104617297649384e-02
    z[3,0,3]  R481      -9.5689199864864349e-02
    z[3,0,3]  R482      -1.5826018154621124e-01
    z[3,0,3]  R483      3.8550609350204468e-01
    z[3,0,3]  R484      -1.1226285994052887e-01
    z[3,0,3]  R485      2.6194056868553162e-01
    z[3,0,3]  R486      -5.7582074403762817e-01
    z[3,0,3]  R487      7.0373013615608215e-02
    z[3,0,3]  R488      -4.8064935207366943e-01
    z[3,0,3]  R489      1.9869594275951385e-01
    z[3,0,3]  R490      -1.7554265260696411e-01
    z[3,0,3]  R491      1.9822651520371437e-03
    z[3,0,3]  R492      3.7127229571342468e-01
    z[3,0,3]  R493      -1.6969843208789825e-01
    z[3,0,3]  R494      2.9292061924934387e-01
    z[3,0,3]  R495      -5.5232882499694824e-01
    z[3,0,3]  R496      2.0609617233276367e-01
    z[3,0,3]  R497      -8.0671662092208862e-01
    z[3,0,3]  R498      -4.1146126389503479e-01
    z[3,0,3]  R499      -4.6740320324897766e-01
    z[3,0,3]  R500      1.6549223661422729e-01
    z[3,0,3]  R501      2.2901932895183563e-01
    z[3,0,3]  R502      8.8411066681146622e-03
    z[3,0,3]  R503      2.8512412309646606e-01
    z[3,0,3]  R504      1.3275374472141266e-01
    z[3,0,3]  R505      -6.2729187309741974e-02
    z[3,0,3]  R506      3.4456110000610352e-01
    z[3,0,3]  R507      2.3610265552997589e-01
    z[3,0,3]  R508      1.9028577953577042e-02
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R415      -1
    z[3,0,4]  R416      1
    z[3,0,4]  R421      1.5497450530529022e-01
    z[3,0,4]  R422      4.9810070544481277e-02
    z[3,0,4]  R423      -8.2780605554580688e-01
    z[3,0,4]  R424      -2.7678960561752319e-01
    z[3,0,4]  R425      -5.9021586179733276e-01
    z[3,0,4]  R426      -3.2592964172363281e-01
    z[3,0,4]  R427      -3.5340425372123718e-01
    z[3,0,4]  R428      -2.1101097762584686e-01
    z[3,0,4]  R429      -8.1960320472717285e-02
    z[3,0,4]  R430      -5.4664772748947144e-01
    z[3,0,4]  R431      1.3832703232765198e-01
    z[3,0,4]  R432      -1.6693617403507233e-01
    z[3,0,4]  R433      8.9001677930355072e-02
    z[3,0,4]  R434      -1.7687901854515076e-01
    z[3,0,4]  R435      -1.4729164540767670e-01
    z[3,0,4]  R436      -1.5474909543991089e-01
    z[3,0,4]  R437      -1.9208058714866638e-01
    z[3,0,4]  R438      7.8312915563583374e-01
    z[3,0,4]  R439      6.8898481130599976e-01
    z[3,0,4]  R440      6.6069936752319336e-01
    z[3,0,4]  R441      -2.2109439969062805e-01
    z[3,0,4]  R442      4.3592989444732666e-01
    z[3,0,4]  R443      -1.4450874924659729e-01
    z[3,0,4]  R444      0.0320991687476635
    z[3,0,4]  R445      -4.8460375517606735e-02
    z[3,0,4]  R446      2.4460107088088989e-01
    z[3,0,4]  R447      9.5805555582046509e-02
    z[3,0,4]  R448      1.2552116811275482e-01
    z[3,0,4]  R449      4.9232020974159241e-01
    z[3,0,4]  R450      1.6777239739894867e-01
    z[3,0,4]  R451      1.8751016259193420e-01
    z[3,0,4]  R452      -1.9941788911819458e-01
    z[3,0,4]  R453      -3.2221134752035141e-02
    z[3,0,4]  R454      -0.0489906370639801
    z[3,0,4]  R455      -2.7909772470593452e-02
    z[3,0,4]  R456      -2.1687658131122589e-01
    z[3,0,4]  R457      -5.3138142824172974e-01
    z[3,0,4]  R458      -1.9959336519241333e-01
    z[3,0,4]  R459      1.1649116128683090e-01
    z[3,0,4]  R460      1.9057299196720123e-01
    z[3,0,4]  R461      2.0229449868202209e-01
    z[3,0,4]  R462      9.8868263885378838e-03
    z[3,0,4]  R463      -3.6068853735923767e-01
    z[3,0,4]  R464      -4.6930167078971863e-01
    z[3,0,4]  R465      3.1903919577598572e-01
    z[3,0,4]  R466      -9.6473604440689087e-02
    z[3,0,4]  R467      3.9080940186977386e-03
    z[3,0,4]  R468      2.9522275924682617e-01
    z[3,0,4]  R469      2.0334189757704735e-02
    z[3,0,4]  R470      2.8387141227722168e-01
    z[3,0,4]  R471      4.8437470197677612e-01
    z[3,0,4]  R472      6.2884253263473511e-01
    z[3,0,4]  R473      1.2406851351261139e-01
    z[3,0,4]  R474      -2.5360816717147827e-01
    z[3,0,4]  R475      -0.281288206577301
    z[3,0,4]  R476      -4.3320730328559875e-01
    z[3,0,4]  R477      2.9039615765213966e-02
    z[3,0,4]  R478      -2.8913456201553345e-01
    z[3,0,4]  R479      -5.8810006827116013e-02
    z[3,0,4]  R480      6.2225043773651123e-01
    z[3,0,4]  R481      -0.0938170999288559
    z[3,0,4]  R482      3.7507492303848267e-01
    z[3,0,4]  R483      4.4238457083702087e-01
    z[3,0,4]  R484      -1.0518613457679749e-01
    z[3,0,4]  R485      -3.6167246103286743e-01
    z[3,0,4]  R486      1.1317305266857147e-01
    z[3,0,4]  R487      -3.1123054027557373e-01
    z[3,0,4]  R488      -2.2253684699535370e-01
    z[3,0,4]  R489      -2.4853645265102386e-01
    z[3,0,4]  R490      4.9042135477066040e-01
    z[3,0,4]  R491      4.3059471249580383e-01
    z[3,0,4]  R492      -3.4301328659057617e-01
    z[3,0,4]  R493      -3.3631703257560730e-01
    z[3,0,4]  R494      -4.0257643908262253e-02
    z[3,0,4]  R495      2.7994525432586670e-01
    z[3,0,4]  R496      1.3417159020900726e-01
    z[3,0,4]  R497      -1.6669304668903351e-01
    z[3,0,4]  R498      -9.8640426993370056e-02
    z[3,0,4]  R499      5.5449718236923218e-01
    z[3,0,4]  R500      5.5251830816268921e-01
    z[3,0,4]  R501      1.8550334870815277e-01
    z[3,0,4]  R502      3.8085004687309265e-01
    z[3,0,4]  R503      -1.7400009930133820e-01
    z[3,0,4]  R504      -1.8838274478912354e-01
    z[3,0,4]  R505      -1.2845905125141144e-01
    z[3,0,4]  R506      1.1475032567977905e-01
    z[3,0,4]  R507      8.3073377609252930e-02
    z[3,0,4]  R508      -3.0021220445632935e-01
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R417      -1
    z[3,0,5]  R418      1
    z[3,0,5]  R421      -5.8452707529067993e-01
    z[3,0,5]  R422      -1.2743914127349854e-01
    z[3,0,5]  R423      1.7452562227845192e-02
    z[3,0,5]  R424      8.7726123631000519e-02
    z[3,0,5]  R425      -1.3058429956436157e-01
    z[3,0,5]  R426      -7.9703167080879211e-02
    z[3,0,5]  R427      -3.2697755098342896e-01
    z[3,0,5]  R428      2.0583800971508026e-02
    z[3,0,5]  R429      4.2072642594575882e-02
    z[3,0,5]  R430      -1.1930692009627819e-02
    z[3,0,5]  R431      1.0244762152433395e-01
    z[3,0,5]  R432      -2.3369353264570236e-02
    z[3,0,5]  R433      -1.6928309202194214e-01
    z[3,0,5]  R434      -2.7417975664138794e-01
    z[3,0,5]  R435      3.0409688130021095e-02
    z[3,0,5]  R436      1.0035818442702293e-02
    z[3,0,5]  R437      2.0721469819545746e-01
    z[3,0,5]  R438      3.1202328205108643e-01
    z[3,0,5]  R439      2.7599191665649414e-01
    z[3,0,5]  R440      3.9503401517868042e-01
    z[3,0,5]  R441      -1.6550481319427490e-01
    z[3,0,5]  R442      3.0633789300918579e-01
    z[3,0,5]  R443      1.5955626964569092e-01
    z[3,0,5]  R444      2.4823763966560364e-01
    z[3,0,5]  R445      2.1159994602203369e-01
    z[3,0,5]  R446      -2.1541567146778107e-01
    z[3,0,5]  R447      -9.5731422305107117e-02
    z[3,0,5]  R448      -0.0866822898387909
    z[3,0,5]  R449      -7.0915900170803070e-02
    z[3,0,5]  R450      -2.4924285709857941e-02
    z[3,0,5]  R451      -8.8141247630119324e-02
    z[3,0,5]  R452      2.8659364581108093e-01
    z[3,0,5]  R453      0.0913451761007309
    z[3,0,5]  R454      -1.2837243080139160e-01
    z[3,0,5]  R455      3.7850487232208252e-01
    z[3,0,5]  R456      -8.4200866520404816e-02
    z[3,0,5]  R457      0.0953843742609024
    z[3,0,5]  R458      2.8075750917196274e-02
    z[3,0,5]  R459      -7.4515056610107422e-01
    z[3,0,5]  R460      -2.1487425267696381e-01
    z[3,0,5]  R461      0.00630249222740531
    z[3,0,5]  R462      -2.1305792033672333e-01
    z[3,0,5]  R463      5.0106555223464966e-02
    z[3,0,5]  R464      -1.7384263873100281e-01
    z[3,0,5]  R465      1.6594673693180084e-01
    z[3,0,5]  R466      2.0208194851875305e-01
    z[3,0,5]  R467      2.1927194669842720e-02
    z[3,0,5]  R468      -1.9410748034715652e-02
    z[3,0,5]  R469      -1.5323872864246368e-01
    z[3,0,5]  R470      -1.7595407366752625e-01
    z[3,0,5]  R471      -1.3384682126343250e-02
    z[3,0,5]  R472      2.3417235910892487e-01
    z[3,0,5]  R473      5.7139742374420166e-01
    z[3,0,5]  R474      6.7183399200439453e-01
    z[3,0,5]  R475      4.9277597665786743e-01
    z[3,0,5]  R476      7.1126115322113037e-01
    z[3,0,5]  R477      4.1232302784919739e-01
    z[3,0,5]  R478      6.3492357730865479e-01
    z[3,0,5]  R479      3.4589615464210510e-01
    z[3,0,5]  R480      2.6017433404922485e-01
    z[3,0,5]  R481      5.0373071432113647e-01
    z[3,0,5]  R482      4.5085495710372925e-01
    z[3,0,5]  R483      3.8269010186195374e-01
    z[3,0,5]  R484      7.3813176155090332e-01
    z[3,0,5]  R485      5.6638425588607788e-01
    z[3,0,5]  R486      4.4393953680992126e-01
    z[3,0,5]  R487      -2.7090549468994141e-01
    z[3,0,5]  R488      -1.2551090121269226e-01
    z[3,0,5]  R489      4.4402226805686951e-01
    z[3,0,5]  R490      0.276623398065567
    z[3,0,5]  R491      5.0560760498046875e-01
    z[3,0,5]  R492      8.9275732636451721e-02
    z[3,0,5]  R493      4.5141872763633728e-01
    z[3,0,5]  R494      1.6238547861576080e-01
    z[3,0,5]  R495      1.7913152277469635e-01
    z[3,0,5]  R496      0.611366331577301
    z[3,0,5]  R497      3.3558952808380127e-01
    z[3,0,5]  R498      -2.5231644511222839e-01
    z[3,0,5]  R499      3.2803300023078918e-01
    z[3,0,5]  R500      4.8965471982955933e-01
    z[3,0,5]  R501      4.1253602504730225e-01
    z[3,0,5]  R502      1.4516760408878326e-01
    z[3,0,5]  R503      1.7920201644301414e-02
    z[3,0,5]  R504      -1.0084106028079987e-01
    z[3,0,5]  R505      -1.7986075580120087e-01
    z[3,0,5]  R506      -3.4360468387603760e-02
    z[3,0,5]  R507      -3.2862797379493713e-01
    z[3,0,5]  R508      -1.3820065557956696e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R419      -1
    z[3,0,6]  R420      1
    z[3,0,6]  R421      -7.7593624591827393e-02
    z[3,0,6]  R422      5.8776468038558960e-01
    z[3,0,6]  R423      2.1646265685558319e-01
    z[3,0,6]  R424      2.5525358319282532e-01
    z[3,0,6]  R425      -5.6083530187606812e-02
    z[3,0,6]  R426      -3.8818728923797607e-01
    z[3,0,6]  R427      -1.5079762041568756e-01
    z[3,0,6]  R428      -8.9222088456153870e-02
    z[3,0,6]  R429      -3.5436192154884338e-01
    z[3,0,6]  R430      -1.9524197280406952e-01
    z[3,0,6]  R431      -1.4552305638790131e-01
    z[3,0,6]  R432      -6.1338496208190918e-01
    z[3,0,6]  R433      -4.2719018459320068e-01
    z[3,0,6]  R434      -1.6609518229961395e-01
    z[3,0,6]  R435      -3.9867994189262390e-01
    z[3,0,6]  R436      2.2725857794284821e-01
    z[3,0,6]  R437      1.4063820242881775e-01
    z[3,0,6]  R438      1.0753098130226135e-01
    z[3,0,6]  R439      4.2588347196578979e-01
    z[3,0,6]  R440      3.9786690473556519e-01
    z[3,0,6]  R441      -2.3114077746868134e-01
    z[3,0,6]  R442      -3.6359328031539917e-01
    z[3,0,6]  R443      -3.9879478514194489e-02
    z[3,0,6]  R444      1.8042442202568054e-01
    z[3,0,6]  R445      -3.4936955571174622e-01
    z[3,0,6]  R446      6.1725240200757980e-02
    z[3,0,6]  R447      -6.5246790647506714e-02
    z[3,0,6]  R448      -3.6207631230354309e-01
    z[3,0,6]  R449      -1.3373765349388123e-01
    z[3,0,6]  R450      4.3322015553712845e-02
    z[3,0,6]  R451      -2.6974296569824219e-01
    z[3,0,6]  R452      -3.0658626556396484e-01
    z[3,0,6]  R453      -2.6294332742691040e-01
    z[3,0,6]  R454      5.6234681606292725e-01
    z[3,0,6]  R455      3.3876877278089523e-02
    z[3,0,6]  R456      1.6584002971649170e-01
    z[3,0,6]  R457      9.2581234872341156e-02
    z[3,0,6]  R458      -3.0335170030593872e-01
    z[3,0,6]  R459      3.4039998054504395e-01
    z[3,0,6]  R460      5.9781733900308609e-02
    z[3,0,6]  R461      -0.722275972366333
    z[3,0,6]  R462      5.9845127165317535e-02
    z[3,0,6]  R463      1.1553537100553513e-01
    z[3,0,6]  R464      -1.0749082267284393e-01
    z[3,0,6]  R465      2.8849408030509949e-01
    z[3,0,6]  R466      1.0326829552650452e-01
    z[3,0,6]  R467      2.9383847117424011e-01
    z[3,0,6]  R468      1.4483739435672760e-01
    z[3,0,6]  R469      1.3990125060081482e-01
    z[3,0,6]  R470      9.2209856957197189e-03
    z[3,0,6]  R471      -1.0074402205646038e-02
    z[3,0,6]  R472      2.7018001675605774e-01
    z[3,0,6]  R473      -4.3257862329483032e-01
    z[3,0,6]  R474      -3.8332757353782654e-01
    z[3,0,6]  R475      -2.4202281236648560e-01
    z[3,0,6]  R476      6.0550529509782791e-02
    z[3,0,6]  R477      -3.2630729675292969e-01
    z[3,0,6]  R478      1.2261397391557693e-01
    z[3,0,6]  R479      6.9774365425109863e-01
    z[3,0,6]  R480      5.4447591304779053e-01
    z[3,0,6]  R481      -3.7754201889038086e-01
    z[3,0,6]  R482      1.8731378018856049e-01
    z[3,0,6]  R483      -6.7560456693172455e-02
    z[3,0,6]  R484      5.9625748544931412e-02
    z[3,0,6]  R485      0.201944500207901
    z[3,0,6]  R486      4.6348896622657776e-01
    z[3,0,6]  R487      1.8456105142831802e-02
    z[3,0,6]  R488      -1.1119223199784756e-02
    z[3,0,6]  R489      -2.0017798244953156e-01
    z[3,0,6]  R490      6.6070586442947388e-01
    z[3,0,6]  R491      1.2391008436679840e-01
    z[3,0,6]  R492      4.0128645300865173e-01
    z[3,0,6]  R493      2.2384525835514069e-01
    z[3,0,6]  R494      1.4391423761844635e-01
    z[3,0,6]  R495      2.7509528398513794e-01
    z[3,0,6]  R496      -2.0410434901714325e-01
    z[3,0,6]  R497      -1.0403953492641449e-01
    z[3,0,6]  R498      -2.9194223880767822e-01
    z[3,0,6]  R499      3.9690226316452026e-01
    z[3,0,6]  R500      1.3834813237190247e-01
    z[3,0,6]  R501      4.5711182057857513e-02
    z[3,0,6]  R502      -1.5375925600528717e-01
    z[3,0,6]  R503      -8.9999385178089142e-02
    z[3,0,6]  R504      -9.7879678010940552e-02
    z[3,0,6]  R505      -3.2398992776870728e-01
    z[3,0,6]  R506      -1.2083017081022263e-01
    z[3,0,6]  R507      -1.1674593389034271e-01
    z[3,0,6]  R508      2.1118935942649841e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R573      -1
    z[1,2,0]  R574      1
    z[1,2,0]  R587      -4.3973377346992493e-01
    z[1,2,0]  R588      -4.6908619999885559e-01
    z[1,2,0]  R589      -4.6749472618103027e-01
    z[1,2,0]  R590      -5.9391325712203979e-01
    z[1,2,0]  R591      -0.438795268535614
    z[1,2,0]  R592      6.8099820613861084e-01
    z[1,2,0]  R593      6.4077001810073853e-01
    z[1,2,0]  R594      7.4334591627120972e-01
    z[1,2,0]  R595      5.5163621902465820e-01
    z[1,2,0]  R596      6.8956816196441650e-01
    z[1,2,0]  R597      -4.7952553629875183e-01
    z[1,2,0]  R598      -0.32700115442276
    z[1,2,0]  R599      -2.9756346344947815e-01
    z[1,2,0]  R600      -3.4690535068511963e-01
    z[1,2,0]  R601      -2.8038537502288818e-01
    z[1,2,0]  R602      -4.4638866186141968e-01
    z[1,2,0]  R603      -4.1364064812660217e-01
    z[1,2,0]  R604      -0.2532939016819
    z[1,2,0]  R605      -2.7952659130096436e-01
    z[1,2,0]  R606      -2.2245080769062042e-01
    z[1,2,0]  R607      -3.7676227092742920e-01
    z[1,2,0]  R608      0.478341281414032
    z[1,2,0]  R609      0.676973283290863
    z[1,2,0]  R610      4.4680270552635193e-01
    z[1,2,0]  R611      6.4664644002914429e-01
    z[1,2,0]  R612      5.7975602149963379e-01
    z[1,2,0]  R613      0.586368203163147
    z[1,2,0]  R614      6.0991507768630981e-01
    z[1,2,0]  R615      0.332193523645401
    z[1,2,0]  R616      7.2198235988616943e-01
    z[1,2,0]  R617      1.0257675498723984e-01
    z[1,2,0]  R618      -2.2947709262371063e-01
    z[1,2,0]  R619      -3.6362317204475403e-01
    z[1,2,0]  R620      5.3756457567214966e-01
    z[1,2,0]  R621      -2.9505431652069092e-02
    z[1,2,0]  R622      4.5382156968116760e-01
    z[1,2,0]  R623      2.6670229434967041e-01
    z[1,2,0]  R624      7.3435842990875244e-01
    z[1,2,0]  R625      4.9293899536132812e-01
    z[1,2,0]  R626      6.9068127870559692e-01
    z[1,2,0]  R627      -5.4931193590164185e-01
    z[1,2,0]  R628      -3.8923683762550354e-01
    z[1,2,0]  R629      4.1136839985847473e-01
    z[1,2,0]  R630      -1.7706157639622688e-02
    z[1,2,0]  R631      1.2964147329330444e-01
    z[1,2,0]  R632      2.6234817504882812e-01
    z[1,2,0]  R633      4.7098869085311890e-01
    z[1,2,0]  R634      7.0320379734039307e-01
    z[1,2,0]  R635      4.5568275451660156e-01
    z[1,2,0]  R636      2.2768758237361908e-01
    z[1,2,0]  R637      -7.3867177963256836e-01
    z[1,2,0]  R638      -2.5451815128326416e-01
    z[1,2,0]  R639      -0.0896846279501915
    z[1,2,0]  R640      0.797221302986145
    z[1,2,0]  R641      -4.8959842324256897e-01
    z[1,2,0]  R642      -6.7485976219177246e-01
    z[1,2,0]  R643      -3.6661231517791748e-01
    z[1,2,0]  R644      1.6546562314033508e-01
    z[1,2,0]  R645      4.0289503335952759e-01
    z[1,2,0]  R646      2.0910868048667908e-01
    z[1,2,0]  R647      3.0914855003356934e-01
    z[1,2,0]  R648      1.6202406585216522e-01
    z[1,2,0]  R649      2.1579591929912567e-01
    z[1,2,0]  R650      1.1821023374795914e-01
    z[1,2,0]  R651      3.0235308408737183e-01
    z[1,2,0]  R652      -1.9415308535099030e-01
    z[1,2,0]  R653      -2.7080168947577477e-02
    z[1,2,0]  R654      -5.7811617851257324e-01
    z[1,2,0]  R655      -5.2692550420761108e-01
    z[1,2,0]  R656      -5.3425353765487671e-01
    z[1,2,0]  R657      -4.2574870586395264e-01
    z[1,2,0]  R658      4.0422007441520691e-01
    z[1,2,0]  R659      -5.1966708898544312e-01
    z[1,2,0]  R660      6.1865937709808350e-01
    z[1,2,0]  R661      3.4635260701179504e-01
    z[1,2,0]  R662      7.3169477283954620e-02
    z[1,2,0]  R663      3.3273005485534668e-01
    z[1,2,0]  R664      4.5836099982261658e-01
    z[1,2,0]  R665      2.7963202446699142e-02
    z[1,2,0]  R666      -1.6530632972717285e-01
    z[1,2,0]  R667      -1.1073750257492065e-01
    z[1,2,0]  R668      -2.1354803442955017e-01
    z[1,2,0]  R669      -0.153940349817276
    z[1,2,0]  R670      -1.7421080172061920e-01
    z[1,2,0]  R671      5.6375145912170410e-02
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R575      -1
    z[1,2,1]  R576      1
    z[1,2,1]  R587      7.0582723617553711e-01
    z[1,2,1]  R588      7.4835884571075439e-01
    z[1,2,1]  R589      6.4602726697921753e-01
    z[1,2,1]  R590      4.0355780720710754e-01
    z[1,2,1]  R591      2.8929588198661804e-01
    z[1,2,1]  R592      -1.5599606931209564e-01
    z[1,2,1]  R593      -2.5938186049461365e-01
    z[1,2,1]  R594      -2.8838065266609192e-01
    z[1,2,1]  R595      -2.6488536596298218e-01
    z[1,2,1]  R596      -1.8207627534866333e-01
    z[1,2,1]  R597      -0.722950279712677
    z[1,2,1]  R598      -7.9297041893005371e-01
    z[1,2,1]  R599      -8.1031274795532227e-01
    z[1,2,1]  R600      -7.6446080207824707e-01
    z[1,2,1]  R601      -0.84675532579422
    z[1,2,1]  R602      -6.3792812824249268e-01
    z[1,2,1]  R603      -6.0679459571838379e-01
    z[1,2,1]  R604      -6.9677561521530151e-01
    z[1,2,1]  R605      -6.4049822092056274e-01
    z[1,2,1]  R606      -7.5996285676956177e-01
    z[1,2,1]  R607      3.1034144759178162e-01
    z[1,2,1]  R608      6.3583391904830933e-01
    z[1,2,1]  R609      0.596767783164978
    z[1,2,1]  R610      7.8609246015548706e-01
    z[1,2,1]  R611      5.6476938724517822e-01
    z[1,2,1]  R612      4.8868107795715332e-01
    z[1,2,1]  R613      3.9729556441307068e-01
    z[1,2,1]  R614      6.6568471491336823e-02
    z[1,2,1]  R615      -1.3944588601589203e-02
    z[1,2,1]  R616      1.3699467480182648e-01
    z[1,2,1]  R617      -7.8468644618988037e-01
    z[1,2,1]  R618      3.0972850322723389e-01
    z[1,2,1]  R619      2.8695744276046753e-01
    z[1,2,1]  R620      1.9082698225975037e-01
    z[1,2,1]  R621      4.2503336071968079e-01
    z[1,2,1]  R622      -9.7298972308635712e-02
    z[1,2,1]  R623      -1.1420476436614990e-01
    z[1,2,1]  R624      1.7754136025905609e-01
    z[1,2,1]  R625      -2.3391132056713104e-01
    z[1,2,1]  R626      2.2367011010646820e-01
    z[1,2,1]  R627      2.0922964811325073e-01
    z[1,2,1]  R628      3.7760722637176514e-01
    z[1,2,1]  R629      -3.3757331967353821e-01
    z[1,2,1]  R630      5.3565579652786255e-01
    z[1,2,1]  R631      5.6941163539886475e-01
    z[1,2,1]  R632      8.3352994918823242e-01
    z[1,2,1]  R633      3.5133186727762222e-02
    z[1,2,1]  R634      7.6741680502891541e-02
    z[1,2,1]  R635      -2.1169431507587433e-02
    z[1,2,1]  R636      -1.0548040270805359e-01
    z[1,2,1]  R637      3.7100705504417419e-01
    z[1,2,1]  R638      6.1308199167251587e-01
    z[1,2,1]  R639      3.0658674240112305e-01
    z[1,2,1]  R640      2.2164407372474670e-01
    z[1,2,1]  R641      7.7359803020954132e-02
    z[1,2,1]  R642      1.0380051285028458e-01
    z[1,2,1]  R643      -1.3685827143490314e-02
    z[1,2,1]  R644      4.5579671859741211e-01
    z[1,2,1]  R645      5.3998893499374390e-01
    z[1,2,1]  R646      3.4333053231239319e-01
    z[1,2,1]  R647      2.7926534414291382e-01
    z[1,2,1]  R648      1.0566697455942631e-02
    z[1,2,1]  R649      1.1272235959768295e-01
    z[1,2,1]  R650      4.8577859997749329e-02
    z[1,2,1]  R651      -2.5733289122581482e-01
    z[1,2,1]  R652      1.6795553267002106e-01
    z[1,2,1]  R653      -3.2765606045722961e-01
    z[1,2,1]  R654      -6.9910669326782227e-01
    z[1,2,1]  R655      -7.0960718393325806e-01
    z[1,2,1]  R656      -7.0828872919082642e-01
    z[1,2,1]  R657      -7.4616920948028564e-01
    z[1,2,1]  R658      8.2627201080322266e-01
    z[1,2,1]  R659      -0.623083233833313
    z[1,2,1]  R660      5.8256733417510986e-01
    z[1,2,1]  R661      5.9217453002929688e-01
    z[1,2,1]  R662      -4.8929625749588013e-01
    z[1,2,1]  R663      -5.5335021018981934e-01
    z[1,2,1]  R664      -4.6199139952659607e-01
    z[1,2,1]  R665      0.621759831905365
    z[1,2,1]  R666      5.0254029035568237e-01
    z[1,2,1]  R667      4.4633430242538452e-01
    z[1,2,1]  R668      5.6274503469467163e-01
    z[1,2,1]  R669      -6.9187784194946289e-01
    z[1,2,1]  R670      2.4417115747928619e-01
    z[1,2,1]  R671      1.3327860832214355e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R577      -1
    z[1,2,2]  R578      1
    z[1,2,2]  R587      -0.229117289185524
    z[1,2,2]  R588      -2.6490619778633118e-01
    z[1,2,2]  R589      -4.8827031254768372e-01
    z[1,2,2]  R590      -5.6621521711349487e-01
    z[1,2,2]  R591      -1.5989576280117035e-01
    z[1,2,2]  R592      2.4967324733734131e-01
    z[1,2,2]  R593      3.6085703969001770e-01
    z[1,2,2]  R594      5.2071553468704224e-01
    z[1,2,2]  R595      1.2483359873294830e-01
    z[1,2,2]  R596      5.2010452747344971e-01
    z[1,2,2]  R597      -9.7651155665516853e-03
    z[1,2,2]  R598      -3.0187508463859558e-01
    z[1,2,2]  R599      -2.5007483363151550e-01
    z[1,2,2]  R600      -1.1067414283752441e-01
    z[1,2,2]  R601      -1.7438901960849762e-01
    z[1,2,2]  R602      -1.1787618696689606e-01
    z[1,2,2]  R603      4.9787878990173340e-02
    z[1,2,2]  R604      -2.6266448199748993e-02
    z[1,2,2]  R605      -0.0127011863514781
    z[1,2,2]  R606      1.0693140327930450e-01
    z[1,2,2]  R607      -2.6498275995254517e-01
    z[1,2,2]  R608      -3.5252094268798828e-01
    z[1,2,2]  R609      -2.2569186985492706e-01
    z[1,2,2]  R610      0.0648149698972702
    z[1,2,2]  R611      0.0210171639919281
    z[1,2,2]  R612      1.3366617262363434e-02
    z[1,2,2]  R613      -1.1218158155679703e-01
    z[1,2,2]  R614      9.2862747609615326e-02
    z[1,2,2]  R615      6.3014000654220581e-01
    z[1,2,2]  R616      2.3018909990787506e-01
    z[1,2,2]  R617      6.6623359918594360e-02
    z[1,2,2]  R618      1.4183364808559418e-01
    z[1,2,2]  R619      -2.5261448696255684e-02
    z[1,2,2]  R620      -0.235975444316864
    z[1,2,2]  R621      -8.3938531577587128e-02
    z[1,2,2]  R622      9.7031831741333008e-02
    z[1,2,2]  R623      5.5120289325714111e-01
    z[1,2,2]  R624      3.6256012320518494e-01
    z[1,2,2]  R625      0.472822368144989
    z[1,2,2]  R626      0.268179327249527
    z[1,2,2]  R627      -2.5414398312568665e-01
    z[1,2,2]  R628      1.1739699542522430e-01
    z[1,2,2]  R629      1.4202952384948730e-01
    z[1,2,2]  R630      -1.2348987907171249e-01
    z[1,2,2]  R631      -3.3790859580039978e-01
    z[1,2,2]  R632      -1.2669317424297333e-01
    z[1,2,2]  R633      -6.8267039954662323e-02
    z[1,2,2]  R634      2.3709677159786224e-01
    z[1,2,2]  R635      -3.4693825244903564e-01
    z[1,2,2]  R636      6.3916486501693726e-01
    z[1,2,2]  R637      -3.9355117082595825e-01
    z[1,2,2]  R638      -1.1480126529932022e-02
    z[1,2,2]  R639      1.7177364230155945e-01
    z[1,2,2]  R640      3.8163551688194275e-01
    z[1,2,2]  R641      3.4038397669792175e-01
    z[1,2,2]  R642      0.566510021686554
    z[1,2,2]  R643      2.1258221566677094e-01
    z[1,2,2]  R644      4.1581603884696960e-01
    z[1,2,2]  R645      3.2558149099349976e-01
    z[1,2,2]  R646      -2.8964450955390930e-01
    z[1,2,2]  R647      -3.0477553606033325e-01
    z[1,2,2]  R648      2.3961445689201355e-01
    z[1,2,2]  R649      7.6453518867492676e-01
    z[1,2,2]  R650      8.1429845094680786e-01
    z[1,2,2]  R651      3.0611777305603027e-01
    z[1,2,2]  R652      5.0546836853027344e-01
    z[1,2,2]  R653      5.2546513080596924e-01
    z[1,2,2]  R654      -2.5471404194831848e-01
    z[1,2,2]  R655      -1.9017027318477631e-01
    z[1,2,2]  R656      -2.2027122974395752e-01
    z[1,2,2]  R657      9.2856585979461670e-02
    z[1,2,2]  R658      -1.5305048227310181e-01
    z[1,2,2]  R659      1.3614802621304989e-02
    z[1,2,2]  R660      -1.2995676696300507e-01
    z[1,2,2]  R661      3.7700325250625610e-01
    z[1,2,2]  R662      -3.8925856351852417e-01
    z[1,2,2]  R663      -3.1161662936210632e-01
    z[1,2,2]  R664      -0.522205114364624
    z[1,2,2]  R665      -4.6922508627176285e-02
    z[1,2,2]  R666      -1.6904366016387939e-01
    z[1,2,2]  R667      -1.2624402344226837e-01
    z[1,2,2]  R668      1.2969402968883514e-01
    z[1,2,2]  R669      -5.3946632146835327e-01
    z[1,2,2]  R670      -1.3117274641990662e-01
    z[1,2,2]  R671      -9.6711240708827972e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R579      -1
    z[1,2,3]  R580      1
    z[1,2,3]  R587      -2.9019543528556824e-01
    z[1,2,3]  R588      5.7496611028909683e-02
    z[1,2,3]  R589      -7.3940992355346680e-02
    z[1,2,3]  R590      2.4332102388143539e-02
    z[1,2,3]  R591      -8.6339443922042847e-02
    z[1,2,3]  R592      0.651769757270813
    z[1,2,3]  R593      5.7279855012893677e-01
    z[1,2,3]  R594      2.7020815014839172e-01
    z[1,2,3]  R595      6.3380479812622070e-01
    z[1,2,3]  R596      3.6046424508094788e-01
    z[1,2,3]  R597      -0.477079302072525
    z[1,2,3]  R598      6.7505910992622375e-02
    z[1,2,3]  R599      2.5140070915222168e-01
    z[1,2,3]  R600      -1.8602685630321503e-01
    z[1,2,3]  R601      -2.1406927704811096e-01
    z[1,2,3]  R602      -2.8279563784599304e-01
    z[1,2,3]  R603      -0.0956747829914093
    z[1,2,3]  R604      -2.6482401415705681e-02
    z[1,2,3]  R605      -1.0606414824724197e-01
    z[1,2,3]  R606      1.4834043383598328e-01
    z[1,2,3]  R607      -3.7804111838340759e-01
    z[1,2,3]  R608      3.8450878858566284e-01
    z[1,2,3]  R609      0.0953054204583168
    z[1,2,3]  R610      1.9266439601778984e-02
    z[1,2,3]  R611      -3.2006785273551941e-01
    z[1,2,3]  R612      -3.1716409325599670e-01
    z[1,2,3]  R613      -2.4189472198486328e-01
    z[1,2,3]  R614      -4.9281543493270874e-01
    z[1,2,3]  R615      -4.6805629134178162e-01
    z[1,2,3]  R616      1.9967010244727135e-02
    z[1,2,3]  R617      -2.6093193888664246e-01
    z[1,2,3]  R618      -6.8618077039718628e-01
    z[1,2,3]  R619      -1.8147185444831848e-01
    z[1,2,3]  R620      -4.9503338336944580e-01
    z[1,2,3]  R621      -7.3967504501342773e-01
    z[1,2,3]  R622      5.1183837652206421e-01
    z[1,2,3]  R623      -4.9407193064689636e-01
    z[1,2,3]  R624      -1.5420243144035339e-01
    z[1,2,3]  R625      -5.0213855504989624e-01
    z[1,2,3]  R626      3.4624069929122925e-02
    z[1,2,3]  R627      -0.486905038356781
    z[1,2,3]  R628      -5.1858031749725342e-01
    z[1,2,3]  R629      7.9279178380966187e-01
    z[1,2,3]  R630      -6.5510874986648560e-01
    z[1,2,3]  R631      2.9931154847145081e-01
    z[1,2,3]  R632      2.2582674026489258e-01
    z[1,2,3]  R633      -0.532409131526947
    z[1,2,3]  R634      1.1730780452489853e-01
    z[1,2,3]  R635      -2.9757568240165710e-01
    z[1,2,3]  R636      -6.3120013475418091e-01
    z[1,2,3]  R637      -2.8670126199722290e-01
    z[1,2,3]  R638      -4.9086907505989075e-01
    z[1,2,3]  R639      -9.2673414945602417e-01
    z[1,2,3]  R640      3.7704259157180786e-02
    z[1,2,3]  R641      5.6681799888610840e-01
    z[1,2,3]  R642      2.9143935441970825e-01
    z[1,2,3]  R643      7.8052252531051636e-01
    z[1,2,3]  R644      3.9015822112560272e-02
    z[1,2,3]  R645      2.3934055864810944e-01
    z[1,2,3]  R646      2.1962981671094894e-02
    z[1,2,3]  R647      2.4569568037986755e-01
    z[1,2,3]  R648      9.2812865972518921e-02
    z[1,2,3]  R649      1.1253246106207371e-02
    z[1,2,3]  R650      8.0901905894279480e-03
    z[1,2,3]  R651      2.7741071581840515e-01
    z[1,2,3]  R652      -1.1258782446384430e-01
    z[1,2,3]  R653      1.5779989957809448e-01
    z[1,2,3]  R654      -3.0732131004333496e-01
    z[1,2,3]  R655      -2.5070270895957947e-01
    z[1,2,3]  R656      -1.9933721423149109e-01
    z[1,2,3]  R657      -2.9560244083404541e-01
    z[1,2,3]  R658      1.8660595640540123e-02
    z[1,2,3]  R659      -2.8148058056831360e-01
    z[1,2,3]  R660      -5.0522230565547943e-02
    z[1,2,3]  R661      -1.4186839759349823e-01
    z[1,2,3]  R662      -8.7280482053756714e-02
    z[1,2,3]  R663      1.5519383549690247e-01
    z[1,2,3]  R664      2.8961020708084106e-01
    z[1,2,3]  R665      -2.5664865970611572e-01
    z[1,2,3]  R666      -4.9873286485671997e-01
    z[1,2,3]  R667      -3.5075816512107849e-01
    z[1,2,3]  R668      -5.5897700786590576e-01
    z[1,2,3]  R669      -2.3413909971714020e-01
    z[1,2,3]  R670      -3.6581665277481079e-01
    z[1,2,3]  R671      -6.2053781747817993e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R581      -1
    z[1,2,4]  R582      1
    z[1,2,4]  R587      3.8261204957962036e-01
    z[1,2,4]  R588      2.7791008353233337e-01
    z[1,2,4]  R589      -2.3422902822494507e-01
    z[1,2,4]  R590      1.0998079180717468e-01
    z[1,2,4]  R591      2.4276715517044067e-01
    z[1,2,4]  R592      -1.1566183716058731e-01
    z[1,2,4]  R593      2.1666100621223450e-01
    z[1,2,4]  R594      1.3682533800601959e-01
    z[1,2,4]  R595      1.9600607454776764e-01
    z[1,2,4]  R596      1.7497076094150543e-01
    z[1,2,4]  R597      1.1299677938222885e-01
    z[1,2,4]  R598      -2.8302571736276150e-03
    z[1,2,4]  R599      0.0761076956987381
    z[1,2,4]  R600      1.3485226035118103e-01
    z[1,2,4]  R601      -2.3401015996932983e-01
    z[1,2,4]  R602      -2.5529021024703979e-01
    z[1,2,4]  R603      0.527223527431488
    z[1,2,4]  R604      0.502944827079773
    z[1,2,4]  R605      -4.3249884247779846e-01
    z[1,2,4]  R606      -2.5453118607401848e-02
    z[1,2,4]  R607      -2.4937191605567932e-01
    z[1,2,4]  R608      2.9429266229271889e-02
    z[1,2,4]  R609      -3.4854507446289062e-01
    z[1,2,4]  R610      -2.5800922513008118e-01
    z[1,2,4]  R611      -3.9282381534576416e-01
    z[1,2,4]  R612      -2.5062489509582520e-01
    z[1,2,4]  R613      -1.2206542491912842e-01
    z[1,2,4]  R614      5.1436161994934082e-01
    z[1,2,4]  R615      4.3308654427528381e-01
    z[1,2,4]  R616      -3.2065966725349426e-01
    z[1,2,4]  R617      -5.4726237058639526e-01
    z[1,2,4]  R618      -6.7449599504470825e-02
    z[1,2,4]  R619      2.1403318643569946e-01
    z[1,2,4]  R620      -6.9757483899593353e-02
    z[1,2,4]  R621      -3.9082175493240356e-01
    z[1,2,4]  R622      -2.1698732674121857e-01
    z[1,2,4]  R623      0.505648136138916
    z[1,2,4]  R624      -3.4428441524505615e-01
    z[1,2,4]  R625      1.7090511322021484e-01
    z[1,2,4]  R626      -4.8727640509605408e-01
    z[1,2,4]  R627      -1.2089670449495316e-01
    z[1,2,4]  R628      0.221050426363945
    z[1,2,4]  R629      2.1512087434530258e-02
    z[1,2,4]  R630      -3.7427493929862976e-01
    z[1,2,4]  R631      2.4408282712101936e-02
    z[1,2,4]  R632      -3.5382375121116638e-01
    z[1,2,4]  R633      6.8781822919845581e-01
    z[1,2,4]  R634      -4.4453686475753784e-01
    z[1,2,4]  R635      6.4020842313766479e-01
    z[1,2,4]  R636      4.1498217731714249e-02
    z[1,2,4]  R637      1.1063133925199509e-01
    z[1,2,4]  R638      -9.9658809602260590e-02
    z[1,2,4]  R639      -0.0842304676771164
    z[1,2,4]  R640      -2.4974401295185089e-01
    z[1,2,4]  R641      -3.1321346759796143e-01
    z[1,2,4]  R642      -1.9275777041912079e-01
    z[1,2,4]  R643      -2.5614660978317261e-01
    z[1,2,4]  R644      -0.000798138091340661
    z[1,2,4]  R645      5.5186992883682251e-01
    z[1,2,4]  R646      -1.3819648325443268e-01
    z[1,2,4]  R647      -1.6549403965473175e-01
    z[1,2,4]  R648      8.1146311759948730e-01
    z[1,2,4]  R649      2.5595462322235107e-01
    z[1,2,4]  R650      4.7331121563911438e-01
    z[1,2,4]  R651      2.3274032771587372e-01
    z[1,2,4]  R652      -4.3243950605392456e-01
    z[1,2,4]  R653      -2.6868479326367378e-02
    z[1,2,4]  R654      -8.4718890488147736e-02
    z[1,2,4]  R655      1.7959372699260712e-01
    z[1,2,4]  R656      3.3769440650939941e-01
    z[1,2,4]  R657      3.5924088954925537e-01
    z[1,2,4]  R658      -1.5597642958164215e-01
    z[1,2,4]  R659      9.0175405144691467e-02
    z[1,2,4]  R660      4.9020549654960632e-01
    z[1,2,4]  R661      5.0157213211059570e-01
    z[1,2,4]  R662      -3.6766156554222107e-01
    z[1,2,4]  R663      6.4462912082672119e-01
    z[1,2,4]  R664      5.4894257336854935e-02
    z[1,2,4]  R665      1.9418130815029144e-01
    z[1,2,4]  R666      2.1522257477045059e-02
    z[1,2,4]  R667      1.9847208261489868e-01
    z[1,2,4]  R668      1.3483066856861115e-01
    z[1,2,4]  R669      -2.4369807541370392e-01
    z[1,2,4]  R670      7.6184707880020142e-01
    z[1,2,4]  R671      5.7341301441192627e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R583      -1
    z[1,2,5]  R584      1
    z[1,2,5]  R587      -1.3069508969783783e-01
    z[1,2,5]  R588      4.7280009835958481e-02
    z[1,2,5]  R589      -2.4256812036037445e-01
    z[1,2,5]  R590      1.0398554056882858e-01
    z[1,2,5]  R591      -0.625950813293457
    z[1,2,5]  R592      1.0464450716972351e-01
    z[1,2,5]  R593      -1.2760579586029053e-01
    z[1,2,5]  R594      2.7487901970744133e-02
    z[1,2,5]  R595      -1.0926242172718048e-01
    z[1,2,5]  R596      -9.2612817883491516e-02
    z[1,2,5]  R597      6.8953827023506165e-02
    z[1,2,5]  R598      -2.0019227266311646e-01
    z[1,2,5]  R599      -3.3036354184150696e-01
    z[1,2,5]  R600      -4.7876381874084473e-01
    z[1,2,5]  R601      5.3922671824693680e-02
    z[1,2,5]  R602      -0.264121949672699
    z[1,2,5]  R603      4.1039773821830750e-01
    z[1,2,5]  R604      1.3205060362815857e-01
    z[1,2,5]  R605      0.194817915558815
    z[1,2,5]  R606      1.7538410425186157e-01
    z[1,2,5]  R607      6.4642357826232910e-01
    z[1,2,5]  R608      -2.8103792667388916e-01
    z[1,2,5]  R609      7.0109167136251926e-03
    z[1,2,5]  R610      2.3674240708351135e-01
    z[1,2,5]  R611      7.5311444699764252e-02
    z[1,2,5]  R612      -2.9498040676116943e-02
    z[1,2,5]  R613      -6.6754192113876343e-02
    z[1,2,5]  R614      3.2755106687545776e-01
    z[1,2,5]  R615      2.3541361093521118e-01
    z[1,2,5]  R616      -5.1162582635879517e-01
    z[1,2,5]  R617      -2.5592150166630745e-02
    z[1,2,5]  R618      -3.0405440926551819e-01
    z[1,2,5]  R619      8.3945882320404053e-01
    z[1,2,5]  R620      -6.0283303260803223e-01
    z[1,2,5]  R621      -5.3239960223436356e-02
    z[1,2,5]  R622      -6.1507624387741089e-01
    z[1,2,5]  R623      -3.1253370642662048e-01
    z[1,2,5]  R624      -3.9272478222846985e-01
    z[1,2,5]  R625      -3.5361361503601074e-01
    z[1,2,5]  R626      -3.8169774413108826e-01
    z[1,2,5]  R627      5.6845819950103760e-01
    z[1,2,5]  R628      5.1635706424713135e-01
    z[1,2,5]  R629      -1.0229671746492386e-01
    z[1,2,5]  R630      -5.7824570685625076e-02
    z[1,2,5]  R631      -2.8982567787170410e-01
    z[1,2,5]  R632      1.9826823472976685e-01
    z[1,2,5]  R633      9.6248477697372437e-02
    z[1,2,5]  R634      -4.8029392957687378e-01
    z[1,2,5]  R635      4.1570165753364563e-01
    z[1,2,5]  R636      -3.5506728291511536e-01
    z[1,2,5]  R637      2.5812932848930359e-01
    z[1,2,5]  R638      -2.9577055573463440e-01
    z[1,2,5]  R639      1.9396256655454636e-02
    z[1,2,5]  R640      -3.2449653744697571e-01
    z[1,2,5]  R641      4.2761421203613281e-01
    z[1,2,5]  R642      -1.7201507091522217e-01
    z[1,2,5]  R643      -3.8127186894416809e-01
    z[1,2,5]  R644      1.9546292722225189e-01
    z[1,2,5]  R645      1.2754661962389946e-02
    z[1,2,5]  R646      -2.3319636285305023e-01
    z[1,2,5]  R647      2.1404910087585449e-01
    z[1,2,5]  R648      -3.6159527301788330e-01
    z[1,2,5]  R649      4.9350535869598389e-01
    z[1,2,5]  R650      3.0156826972961426e-01
    z[1,2,5]  R651      0.588338315486908
    z[1,2,5]  R652      6.5808808803558350e-01
    z[1,2,5]  R653      7.5849437713623047e-01
    z[1,2,5]  R654      2.5602813810110092e-02
    z[1,2,5]  R655      -1.7964061116799712e-03
    z[1,2,5]  R656      9.3446910381317139e-02
    z[1,2,5]  R657      -1.8723461031913757e-01
    z[1,2,5]  R658      4.0902689099311829e-02
    z[1,2,5]  R659      7.3748230934143066e-02
    z[1,2,5]  R660      -2.8898175805807114e-02
    z[1,2,5]  R661      1.5492363274097443e-01
    z[1,2,5]  R662      -7.8078046441078186e-02
    z[1,2,5]  R663      -2.1046692132949829e-01
    z[1,2,5]  R664      -1.1115522682666779e-01
    z[1,2,5]  R665      -4.7295203804969788e-01
    z[1,2,5]  R666      -0.629519522190094
    z[1,2,5]  R667      -7.7274823188781738e-01
    z[1,2,5]  R668      -5.2689379453659058e-01
    z[1,2,5]  R669      1.8636273220181465e-02
    z[1,2,5]  R670      6.7329309880733490e-02
    z[1,2,5]  R671      4.7534830868244171e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R585      -1
    z[1,2,6]  R586      1
    z[1,2,6]  R587      9.0889401733875275e-02
    z[1,2,6]  R588      -2.5877895951271057e-01
    z[1,2,6]  R589      -8.0745331943035126e-02
    z[1,2,6]  R590      0.374576598405838
    z[1,2,6]  R591      -4.8989301919937134e-01
    z[1,2,6]  R592      2.0928401499986649e-02
    z[1,2,6]  R593      -2.4365289136767387e-02
    z[1,2,6]  R594      2.5289552286267281e-02
    z[1,2,6]  R595      3.9734715223312378e-01
    z[1,2,6]  R596      -2.2739601135253906e-01
    z[1,2,6]  R597      -0.0466383658349514
    z[1,2,6]  R598      3.5846567153930664e-01
    z[1,2,6]  R599      1.1906799674034119e-01
    z[1,2,6]  R600      3.1650140881538391e-02
    z[1,2,6]  R601      2.6548784971237183e-01
    z[1,2,6]  R602      -0.406181275844574
    z[1,2,6]  R603      5.1750767976045609e-02
    z[1,2,6]  R604      4.2256820201873779e-01
    z[1,2,6]  R605      -5.2460145950317383e-01
    z[1,2,6]  R606      -5.5509054660797119e-01
    z[1,2,6]  R607      2.6183506846427917e-01
    z[1,2,6]  R608      -1.2222281098365784e-01
    z[1,2,6]  R609      6.3423417508602142e-02
    z[1,2,6]  R610      2.3502789437770844e-01
    z[1,2,6]  R611      -0.00405834149569273
    z[1,2,6]  R612      -5.1050871610641479e-01
    z[1,2,6]  R613      0.63865065574646
    z[1,2,6]  R614      -1.4969493262469769e-02
    z[1,2,6]  R615      -1.7411597073078156e-01
    z[1,2,6]  R616      2.0495028793811798e-01
    z[1,2,6]  R617      3.2708659768104553e-02
    z[1,2,6]  R618      -5.1327300071716309e-01
    z[1,2,6]  R619      -3.6908425390720367e-02
    z[1,2,6]  R620      7.4787355959415436e-02
    z[1,2,6]  R621      3.2975021004676819e-01
    z[1,2,6]  R622      -2.9628169536590576e-01
    z[1,2,6]  R623      -1.2057397514581680e-01
    z[1,2,6]  R624      3.4699384123086929e-02
    z[1,2,6]  R625      0.268963485956192
    z[1,2,6]  R626      -1.2915319204330444e-01
    z[1,2,6]  R627      1.2269077450037003e-01
    z[1,2,6]  R628      -3.2819494605064392e-01
    z[1,2,6]  R629      -2.3916883766651154e-01
    z[1,2,6]  R630      3.5343545675277710e-01
    z[1,2,6]  R631      6.0876852273941040e-01
    z[1,2,6]  R632      6.9648787379264832e-02
    z[1,2,6]  R633      8.0360412597656250e-02
    z[1,2,6]  R634      -0.0366581492125988
    z[1,2,6]  R635      1.7690800130367279e-02
    z[1,2,6]  R636      4.7874860465526581e-02
    z[1,2,6]  R637      -2.7707897126674652e-02
    z[1,2,6]  R638      -4.6995177865028381e-01
    z[1,2,6]  R639      4.6346601098775864e-02
    z[1,2,6]  R640      2.3973459377884865e-02
    z[1,2,6]  R641      0.190284863114357
    z[1,2,6]  R642      2.4733503162860870e-01
    z[1,2,6]  R643      4.7085378319025040e-03
    z[1,2,6]  R644      7.4312782287597656e-01
    z[1,2,6]  R645      2.7942320704460144e-01
    z[1,2,6]  R646      -8.2495003938674927e-01
    z[1,2,6]  R647      7.7458268404006958e-01
    z[1,2,6]  R648      3.4406915307044983e-01
    z[1,2,6]  R649      2.1685181558132172e-01
    z[1,2,6]  R650      -7.4513129889965057e-02
    z[1,2,6]  R651      -5.2094870805740356e-01
    z[1,2,6]  R652      -2.1409682929515839e-01
    z[1,2,6]  R653      -1.2189421057701111e-01
    z[1,2,6]  R654      9.9363557994365692e-02
    z[1,2,6]  R655      -2.9586055874824524e-01
    z[1,2,6]  R656      -4.3308973312377930e-02
    z[1,2,6]  R657      -4.3077409267425537e-02
    z[1,2,6]  R658      -3.2265511155128479e-01
    z[1,2,6]  R659      4.9872463941574097e-01
    z[1,2,6]  R660      1.3152271509170532e-01
    z[1,2,6]  R661      3.0254775285720825e-01
    z[1,2,6]  R662      -6.7440646886825562e-01
    z[1,2,6]  R663      0.0453985333442688
    z[1,2,6]  R664      4.5224779844284058e-01
    z[1,2,6]  R665      5.3213948011398315e-01
    z[1,2,6]  R666      2.1461309492588043e-01
    z[1,2,6]  R667      -1.1411865800619125e-01
    z[1,2,6]  R668      1.1244162172079086e-01
    z[1,2,6]  R669      3.0335816740989685e-01
    z[1,2,6]  R670      -0.417203426361084
    z[1,2,6]  R671      -0.503563642501831
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R672      -1
    z[2,1,0]  R673      1
    z[2,1,0]  R686      -3.6661231517791748e-01
    z[2,1,0]  R687      1.6546562314033508e-01
    z[2,1,0]  R688      4.0289503335952759e-01
    z[2,1,0]  R689      2.0910868048667908e-01
    z[2,1,0]  R690      3.0914855003356934e-01
    z[2,1,0]  R691      1.6202406585216522e-01
    z[2,1,0]  R692      2.1579591929912567e-01
    z[2,1,0]  R693      1.1821023374795914e-01
    z[2,1,0]  R694      3.0235308408737183e-01
    z[2,1,0]  R695      -1.9415308535099030e-01
    z[2,1,0]  R696      -2.7080168947577477e-02
    z[2,1,0]  R697      -5.7811617851257324e-01
    z[2,1,0]  R698      -5.2692550420761108e-01
    z[2,1,0]  R699      -5.3425353765487671e-01
    z[2,1,0]  R700      -4.2574870586395264e-01
    z[2,1,0]  R701      4.0422007441520691e-01
    z[2,1,0]  R702      -5.1966708898544312e-01
    z[2,1,0]  R703      6.1865937709808350e-01
    z[2,1,0]  R704      3.4635260701179504e-01
    z[2,1,0]  R705      7.3169477283954620e-02
    z[2,1,0]  R706      3.3273005485534668e-01
    z[2,1,0]  R707      4.5836099982261658e-01
    z[2,1,0]  R708      2.7963202446699142e-02
    z[2,1,0]  R709      -1.6530632972717285e-01
    z[2,1,0]  R710      -1.1073750257492065e-01
    z[2,1,0]  R711      -2.1354803442955017e-01
    z[2,1,0]  R712      -0.153940349817276
    z[2,1,0]  R713      -1.7421080172061920e-01
    z[2,1,0]  R714      5.6375145912170410e-02
    z[2,1,0]  R715      -4.3973377346992493e-01
    z[2,1,0]  R716      -4.6908619999885559e-01
    z[2,1,0]  R717      -4.6749472618103027e-01
    z[2,1,0]  R718      -5.9391325712203979e-01
    z[2,1,0]  R719      -0.438795268535614
    z[2,1,0]  R720      6.8099820613861084e-01
    z[2,1,0]  R721      6.4077001810073853e-01
    z[2,1,0]  R722      7.4334591627120972e-01
    z[2,1,0]  R723      5.5163621902465820e-01
    z[2,1,0]  R724      6.8956816196441650e-01
    z[2,1,0]  R725      -4.7952553629875183e-01
    z[2,1,0]  R726      -0.32700115442276
    z[2,1,0]  R727      -2.9756346344947815e-01
    z[2,1,0]  R728      -3.4690535068511963e-01
    z[2,1,0]  R729      -2.8038537502288818e-01
    z[2,1,0]  R730      -4.4638866186141968e-01
    z[2,1,0]  R731      -4.1364064812660217e-01
    z[2,1,0]  R732      -0.2532939016819
    z[2,1,0]  R733      -2.7952659130096436e-01
    z[2,1,0]  R734      -2.2245080769062042e-01
    z[2,1,0]  R735      -3.7676227092742920e-01
    z[2,1,0]  R736      0.478341281414032
    z[2,1,0]  R737      0.676973283290863
    z[2,1,0]  R738      4.4680270552635193e-01
    z[2,1,0]  R739      6.4664644002914429e-01
    z[2,1,0]  R740      5.7975602149963379e-01
    z[2,1,0]  R741      0.586368203163147
    z[2,1,0]  R742      6.0991507768630981e-01
    z[2,1,0]  R743      0.332193523645401
    z[2,1,0]  R744      7.2198235988616943e-01
    z[2,1,0]  R745      1.0257675498723984e-01
    z[2,1,0]  R746      -2.2947709262371063e-01
    z[2,1,0]  R747      -3.6362317204475403e-01
    z[2,1,0]  R748      5.3756457567214966e-01
    z[2,1,0]  R749      -2.9505431652069092e-02
    z[2,1,0]  R750      4.5382156968116760e-01
    z[2,1,0]  R751      2.6670229434967041e-01
    z[2,1,0]  R752      7.3435842990875244e-01
    z[2,1,0]  R753      4.9293899536132812e-01
    z[2,1,0]  R754      6.9068127870559692e-01
    z[2,1,0]  R755      -5.4931193590164185e-01
    z[2,1,0]  R756      -3.8923683762550354e-01
    z[2,1,0]  R757      4.1136839985847473e-01
    z[2,1,0]  R758      -1.7706157639622688e-02
    z[2,1,0]  R759      1.2964147329330444e-01
    z[2,1,0]  R760      2.6234817504882812e-01
    z[2,1,0]  R761      4.7098869085311890e-01
    z[2,1,0]  R762      7.0320379734039307e-01
    z[2,1,0]  R763      4.5568275451660156e-01
    z[2,1,0]  R764      2.2768758237361908e-01
    z[2,1,0]  R765      -7.3867177963256836e-01
    z[2,1,0]  R766      -2.5451815128326416e-01
    z[2,1,0]  R767      -0.0896846279501915
    z[2,1,0]  R768      0.797221302986145
    z[2,1,0]  R769      -4.8959842324256897e-01
    z[2,1,0]  R770      -6.7485976219177246e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R674      -1
    z[2,1,1]  R675      1
    z[2,1,1]  R686      -1.3685827143490314e-02
    z[2,1,1]  R687      4.5579671859741211e-01
    z[2,1,1]  R688      5.3998893499374390e-01
    z[2,1,1]  R689      3.4333053231239319e-01
    z[2,1,1]  R690      2.7926534414291382e-01
    z[2,1,1]  R691      1.0566697455942631e-02
    z[2,1,1]  R692      1.1272235959768295e-01
    z[2,1,1]  R693      4.8577859997749329e-02
    z[2,1,1]  R694      -2.5733289122581482e-01
    z[2,1,1]  R695      1.6795553267002106e-01
    z[2,1,1]  R696      -3.2765606045722961e-01
    z[2,1,1]  R697      -6.9910669326782227e-01
    z[2,1,1]  R698      -7.0960718393325806e-01
    z[2,1,1]  R699      -7.0828872919082642e-01
    z[2,1,1]  R700      -7.4616920948028564e-01
    z[2,1,1]  R701      8.2627201080322266e-01
    z[2,1,1]  R702      -0.623083233833313
    z[2,1,1]  R703      5.8256733417510986e-01
    z[2,1,1]  R704      5.9217453002929688e-01
    z[2,1,1]  R705      -4.8929625749588013e-01
    z[2,1,1]  R706      -5.5335021018981934e-01
    z[2,1,1]  R707      -4.6199139952659607e-01
    z[2,1,1]  R708      0.621759831905365
    z[2,1,1]  R709      5.0254029035568237e-01
    z[2,1,1]  R710      4.4633430242538452e-01
    z[2,1,1]  R711      5.6274503469467163e-01
    z[2,1,1]  R712      -6.9187784194946289e-01
    z[2,1,1]  R713      2.4417115747928619e-01
    z[2,1,1]  R714      1.3327860832214355e-01
    z[2,1,1]  R715      7.0582723617553711e-01
    z[2,1,1]  R716      7.4835884571075439e-01
    z[2,1,1]  R717      6.4602726697921753e-01
    z[2,1,1]  R718      4.0355780720710754e-01
    z[2,1,1]  R719      2.8929588198661804e-01
    z[2,1,1]  R720      -1.5599606931209564e-01
    z[2,1,1]  R721      -2.5938186049461365e-01
    z[2,1,1]  R722      -2.8838065266609192e-01
    z[2,1,1]  R723      -2.6488536596298218e-01
    z[2,1,1]  R724      -1.8207627534866333e-01
    z[2,1,1]  R725      -0.722950279712677
    z[2,1,1]  R726      -7.9297041893005371e-01
    z[2,1,1]  R727      -8.1031274795532227e-01
    z[2,1,1]  R728      -7.6446080207824707e-01
    z[2,1,1]  R729      -0.84675532579422
    z[2,1,1]  R730      -6.3792812824249268e-01
    z[2,1,1]  R731      -6.0679459571838379e-01
    z[2,1,1]  R732      -6.9677561521530151e-01
    z[2,1,1]  R733      -6.4049822092056274e-01
    z[2,1,1]  R734      -7.5996285676956177e-01
    z[2,1,1]  R735      3.1034144759178162e-01
    z[2,1,1]  R736      6.3583391904830933e-01
    z[2,1,1]  R737      0.596767783164978
    z[2,1,1]  R738      7.8609246015548706e-01
    z[2,1,1]  R739      5.6476938724517822e-01
    z[2,1,1]  R740      4.8868107795715332e-01
    z[2,1,1]  R741      3.9729556441307068e-01
    z[2,1,1]  R742      6.6568471491336823e-02
    z[2,1,1]  R743      -1.3944588601589203e-02
    z[2,1,1]  R744      1.3699467480182648e-01
    z[2,1,1]  R745      -7.8468644618988037e-01
    z[2,1,1]  R746      3.0972850322723389e-01
    z[2,1,1]  R747      2.8695744276046753e-01
    z[2,1,1]  R748      1.9082698225975037e-01
    z[2,1,1]  R749      4.2503336071968079e-01
    z[2,1,1]  R750      -9.7298972308635712e-02
    z[2,1,1]  R751      -1.1420476436614990e-01
    z[2,1,1]  R752      1.7754136025905609e-01
    z[2,1,1]  R753      -2.3391132056713104e-01
    z[2,1,1]  R754      2.2367011010646820e-01
    z[2,1,1]  R755      2.0922964811325073e-01
    z[2,1,1]  R756      3.7760722637176514e-01
    z[2,1,1]  R757      -3.3757331967353821e-01
    z[2,1,1]  R758      5.3565579652786255e-01
    z[2,1,1]  R759      5.6941163539886475e-01
    z[2,1,1]  R760      8.3352994918823242e-01
    z[2,1,1]  R761      3.5133186727762222e-02
    z[2,1,1]  R762      7.6741680502891541e-02
    z[2,1,1]  R763      -2.1169431507587433e-02
    z[2,1,1]  R764      -1.0548040270805359e-01
    z[2,1,1]  R765      3.7100705504417419e-01
    z[2,1,1]  R766      6.1308199167251587e-01
    z[2,1,1]  R767      3.0658674240112305e-01
    z[2,1,1]  R768      2.2164407372474670e-01
    z[2,1,1]  R769      7.7359803020954132e-02
    z[2,1,1]  R770      1.0380051285028458e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R676      -1
    z[2,1,2]  R677      1
    z[2,1,2]  R686      2.1258221566677094e-01
    z[2,1,2]  R687      4.1581603884696960e-01
    z[2,1,2]  R688      3.2558149099349976e-01
    z[2,1,2]  R689      -2.8964450955390930e-01
    z[2,1,2]  R690      -3.0477553606033325e-01
    z[2,1,2]  R691      2.3961445689201355e-01
    z[2,1,2]  R692      7.6453518867492676e-01
    z[2,1,2]  R693      8.1429845094680786e-01
    z[2,1,2]  R694      3.0611777305603027e-01
    z[2,1,2]  R695      5.0546836853027344e-01
    z[2,1,2]  R696      5.2546513080596924e-01
    z[2,1,2]  R697      -2.5471404194831848e-01
    z[2,1,2]  R698      -1.9017027318477631e-01
    z[2,1,2]  R699      -2.2027122974395752e-01
    z[2,1,2]  R700      9.2856585979461670e-02
    z[2,1,2]  R701      -1.5305048227310181e-01
    z[2,1,2]  R702      1.3614802621304989e-02
    z[2,1,2]  R703      -1.2995676696300507e-01
    z[2,1,2]  R704      3.7700325250625610e-01
    z[2,1,2]  R705      -3.8925856351852417e-01
    z[2,1,2]  R706      -3.1161662936210632e-01
    z[2,1,2]  R707      -0.522205114364624
    z[2,1,2]  R708      -4.6922508627176285e-02
    z[2,1,2]  R709      -1.6904366016387939e-01
    z[2,1,2]  R710      -1.2624402344226837e-01
    z[2,1,2]  R711      1.2969402968883514e-01
    z[2,1,2]  R712      -5.3946632146835327e-01
    z[2,1,2]  R713      -1.3117274641990662e-01
    z[2,1,2]  R714      -9.6711240708827972e-02
    z[2,1,2]  R715      -0.229117289185524
    z[2,1,2]  R716      -2.6490619778633118e-01
    z[2,1,2]  R717      -4.8827031254768372e-01
    z[2,1,2]  R718      -5.6621521711349487e-01
    z[2,1,2]  R719      -1.5989576280117035e-01
    z[2,1,2]  R720      2.4967324733734131e-01
    z[2,1,2]  R721      3.6085703969001770e-01
    z[2,1,2]  R722      5.2071553468704224e-01
    z[2,1,2]  R723      1.2483359873294830e-01
    z[2,1,2]  R724      5.2010452747344971e-01
    z[2,1,2]  R725      -9.7651155665516853e-03
    z[2,1,2]  R726      -3.0187508463859558e-01
    z[2,1,2]  R727      -2.5007483363151550e-01
    z[2,1,2]  R728      -1.1067414283752441e-01
    z[2,1,2]  R729      -1.7438901960849762e-01
    z[2,1,2]  R730      -1.1787618696689606e-01
    z[2,1,2]  R731      4.9787878990173340e-02
    z[2,1,2]  R732      -2.6266448199748993e-02
    z[2,1,2]  R733      -0.0127011863514781
    z[2,1,2]  R734      1.0693140327930450e-01
    z[2,1,2]  R735      -2.6498275995254517e-01
    z[2,1,2]  R736      -3.5252094268798828e-01
    z[2,1,2]  R737      -2.2569186985492706e-01
    z[2,1,2]  R738      0.0648149698972702
    z[2,1,2]  R739      0.0210171639919281
    z[2,1,2]  R740      1.3366617262363434e-02
    z[2,1,2]  R741      -1.1218158155679703e-01
    z[2,1,2]  R742      9.2862747609615326e-02
    z[2,1,2]  R743      6.3014000654220581e-01
    z[2,1,2]  R744      2.3018909990787506e-01
    z[2,1,2]  R745      6.6623359918594360e-02
    z[2,1,2]  R746      1.4183364808559418e-01
    z[2,1,2]  R747      -2.5261448696255684e-02
    z[2,1,2]  R748      -0.235975444316864
    z[2,1,2]  R749      -8.3938531577587128e-02
    z[2,1,2]  R750      9.7031831741333008e-02
    z[2,1,2]  R751      5.5120289325714111e-01
    z[2,1,2]  R752      3.6256012320518494e-01
    z[2,1,2]  R753      0.472822368144989
    z[2,1,2]  R754      0.268179327249527
    z[2,1,2]  R755      -2.5414398312568665e-01
    z[2,1,2]  R756      1.1739699542522430e-01
    z[2,1,2]  R757      1.4202952384948730e-01
    z[2,1,2]  R758      -1.2348987907171249e-01
    z[2,1,2]  R759      -3.3790859580039978e-01
    z[2,1,2]  R760      -1.2669317424297333e-01
    z[2,1,2]  R761      -6.8267039954662323e-02
    z[2,1,2]  R762      2.3709677159786224e-01
    z[2,1,2]  R763      -3.4693825244903564e-01
    z[2,1,2]  R764      6.3916486501693726e-01
    z[2,1,2]  R765      -3.9355117082595825e-01
    z[2,1,2]  R766      -1.1480126529932022e-02
    z[2,1,2]  R767      1.7177364230155945e-01
    z[2,1,2]  R768      3.8163551688194275e-01
    z[2,1,2]  R769      3.4038397669792175e-01
    z[2,1,2]  R770      0.566510021686554
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R678      -1
    z[2,1,3]  R679      1
    z[2,1,3]  R686      7.8052252531051636e-01
    z[2,1,3]  R687      3.9015822112560272e-02
    z[2,1,3]  R688      2.3934055864810944e-01
    z[2,1,3]  R689      2.1962981671094894e-02
    z[2,1,3]  R690      2.4569568037986755e-01
    z[2,1,3]  R691      9.2812865972518921e-02
    z[2,1,3]  R692      1.1253246106207371e-02
    z[2,1,3]  R693      8.0901905894279480e-03
    z[2,1,3]  R694      2.7741071581840515e-01
    z[2,1,3]  R695      -1.1258782446384430e-01
    z[2,1,3]  R696      1.5779989957809448e-01
    z[2,1,3]  R697      -3.0732131004333496e-01
    z[2,1,3]  R698      -2.5070270895957947e-01
    z[2,1,3]  R699      -1.9933721423149109e-01
    z[2,1,3]  R700      -2.9560244083404541e-01
    z[2,1,3]  R701      1.8660595640540123e-02
    z[2,1,3]  R702      -2.8148058056831360e-01
    z[2,1,3]  R703      -5.0522230565547943e-02
    z[2,1,3]  R704      -1.4186839759349823e-01
    z[2,1,3]  R705      -8.7280482053756714e-02
    z[2,1,3]  R706      1.5519383549690247e-01
    z[2,1,3]  R707      2.8961020708084106e-01
    z[2,1,3]  R708      -2.5664865970611572e-01
    z[2,1,3]  R709      -4.9873286485671997e-01
    z[2,1,3]  R710      -3.5075816512107849e-01
    z[2,1,3]  R711      -5.5897700786590576e-01
    z[2,1,3]  R712      -2.3413909971714020e-01
    z[2,1,3]  R713      -3.6581665277481079e-01
    z[2,1,3]  R714      -6.2053781747817993e-01
    z[2,1,3]  R715      -2.9019543528556824e-01
    z[2,1,3]  R716      5.7496611028909683e-02
    z[2,1,3]  R717      -7.3940992355346680e-02
    z[2,1,3]  R718      2.4332102388143539e-02
    z[2,1,3]  R719      -8.6339443922042847e-02
    z[2,1,3]  R720      0.651769757270813
    z[2,1,3]  R721      5.7279855012893677e-01
    z[2,1,3]  R722      2.7020815014839172e-01
    z[2,1,3]  R723      6.3380479812622070e-01
    z[2,1,3]  R724      3.6046424508094788e-01
    z[2,1,3]  R725      -0.477079302072525
    z[2,1,3]  R726      6.7505910992622375e-02
    z[2,1,3]  R727      2.5140070915222168e-01
    z[2,1,3]  R728      -1.8602685630321503e-01
    z[2,1,3]  R729      -2.1406927704811096e-01
    z[2,1,3]  R730      -2.8279563784599304e-01
    z[2,1,3]  R731      -0.0956747829914093
    z[2,1,3]  R732      -2.6482401415705681e-02
    z[2,1,3]  R733      -1.0606414824724197e-01
    z[2,1,3]  R734      1.4834043383598328e-01
    z[2,1,3]  R735      -3.7804111838340759e-01
    z[2,1,3]  R736      3.8450878858566284e-01
    z[2,1,3]  R737      0.0953054204583168
    z[2,1,3]  R738      1.9266439601778984e-02
    z[2,1,3]  R739      -3.2006785273551941e-01
    z[2,1,3]  R740      -3.1716409325599670e-01
    z[2,1,3]  R741      -2.4189472198486328e-01
    z[2,1,3]  R742      -4.9281543493270874e-01
    z[2,1,3]  R743      -4.6805629134178162e-01
    z[2,1,3]  R744      1.9967010244727135e-02
    z[2,1,3]  R745      -2.6093193888664246e-01
    z[2,1,3]  R746      -6.8618077039718628e-01
    z[2,1,3]  R747      -1.8147185444831848e-01
    z[2,1,3]  R748      -4.9503338336944580e-01
    z[2,1,3]  R749      -7.3967504501342773e-01
    z[2,1,3]  R750      5.1183837652206421e-01
    z[2,1,3]  R751      -4.9407193064689636e-01
    z[2,1,3]  R752      -1.5420243144035339e-01
    z[2,1,3]  R753      -5.0213855504989624e-01
    z[2,1,3]  R754      3.4624069929122925e-02
    z[2,1,3]  R755      -0.486905038356781
    z[2,1,3]  R756      -5.1858031749725342e-01
    z[2,1,3]  R757      7.9279178380966187e-01
    z[2,1,3]  R758      -6.5510874986648560e-01
    z[2,1,3]  R759      2.9931154847145081e-01
    z[2,1,3]  R760      2.2582674026489258e-01
    z[2,1,3]  R761      -0.532409131526947
    z[2,1,3]  R762      1.1730780452489853e-01
    z[2,1,3]  R763      -2.9757568240165710e-01
    z[2,1,3]  R764      -6.3120013475418091e-01
    z[2,1,3]  R765      -2.8670126199722290e-01
    z[2,1,3]  R766      -4.9086907505989075e-01
    z[2,1,3]  R767      -9.2673414945602417e-01
    z[2,1,3]  R768      3.7704259157180786e-02
    z[2,1,3]  R769      5.6681799888610840e-01
    z[2,1,3]  R770      2.9143935441970825e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R680      -1
    z[2,1,4]  R681      1
    z[2,1,4]  R686      -2.5614660978317261e-01
    z[2,1,4]  R687      -0.000798138091340661
    z[2,1,4]  R688      5.5186992883682251e-01
    z[2,1,4]  R689      -1.3819648325443268e-01
    z[2,1,4]  R690      -1.6549403965473175e-01
    z[2,1,4]  R691      8.1146311759948730e-01
    z[2,1,4]  R692      2.5595462322235107e-01
    z[2,1,4]  R693      4.7331121563911438e-01
    z[2,1,4]  R694      2.3274032771587372e-01
    z[2,1,4]  R695      -4.3243950605392456e-01
    z[2,1,4]  R696      -2.6868479326367378e-02
    z[2,1,4]  R697      -8.4718890488147736e-02
    z[2,1,4]  R698      1.7959372699260712e-01
    z[2,1,4]  R699      3.3769440650939941e-01
    z[2,1,4]  R700      3.5924088954925537e-01
    z[2,1,4]  R701      -1.5597642958164215e-01
    z[2,1,4]  R702      9.0175405144691467e-02
    z[2,1,4]  R703      4.9020549654960632e-01
    z[2,1,4]  R704      5.0157213211059570e-01
    z[2,1,4]  R705      -3.6766156554222107e-01
    z[2,1,4]  R706      6.4462912082672119e-01
    z[2,1,4]  R707      5.4894257336854935e-02
    z[2,1,4]  R708      1.9418130815029144e-01
    z[2,1,4]  R709      2.1522257477045059e-02
    z[2,1,4]  R710      1.9847208261489868e-01
    z[2,1,4]  R711      1.3483066856861115e-01
    z[2,1,4]  R712      -2.4369807541370392e-01
    z[2,1,4]  R713      7.6184707880020142e-01
    z[2,1,4]  R714      5.7341301441192627e-01
    z[2,1,4]  R715      3.8261204957962036e-01
    z[2,1,4]  R716      2.7791008353233337e-01
    z[2,1,4]  R717      -2.3422902822494507e-01
    z[2,1,4]  R718      1.0998079180717468e-01
    z[2,1,4]  R719      2.4276715517044067e-01
    z[2,1,4]  R720      -1.1566183716058731e-01
    z[2,1,4]  R721      2.1666100621223450e-01
    z[2,1,4]  R722      1.3682533800601959e-01
    z[2,1,4]  R723      1.9600607454776764e-01
    z[2,1,4]  R724      1.7497076094150543e-01
    z[2,1,4]  R725      1.1299677938222885e-01
    z[2,1,4]  R726      -2.8302571736276150e-03
    z[2,1,4]  R727      0.0761076956987381
    z[2,1,4]  R728      1.3485226035118103e-01
    z[2,1,4]  R729      -2.3401015996932983e-01
    z[2,1,4]  R730      -2.5529021024703979e-01
    z[2,1,4]  R731      0.527223527431488
    z[2,1,4]  R732      0.502944827079773
    z[2,1,4]  R733      -4.3249884247779846e-01
    z[2,1,4]  R734      -2.5453118607401848e-02
    z[2,1,4]  R735      -2.4937191605567932e-01
    z[2,1,4]  R736      2.9429266229271889e-02
    z[2,1,4]  R737      -3.4854507446289062e-01
    z[2,1,4]  R738      -2.5800922513008118e-01
    z[2,1,4]  R739      -3.9282381534576416e-01
    z[2,1,4]  R740      -2.5062489509582520e-01
    z[2,1,4]  R741      -1.2206542491912842e-01
    z[2,1,4]  R742      5.1436161994934082e-01
    z[2,1,4]  R743      4.3308654427528381e-01
    z[2,1,4]  R744      -3.2065966725349426e-01
    z[2,1,4]  R745      -5.4726237058639526e-01
    z[2,1,4]  R746      -6.7449599504470825e-02
    z[2,1,4]  R747      2.1403318643569946e-01
    z[2,1,4]  R748      -6.9757483899593353e-02
    z[2,1,4]  R749      -3.9082175493240356e-01
    z[2,1,4]  R750      -2.1698732674121857e-01
    z[2,1,4]  R751      0.505648136138916
    z[2,1,4]  R752      -3.4428441524505615e-01
    z[2,1,4]  R753      1.7090511322021484e-01
    z[2,1,4]  R754      -4.8727640509605408e-01
    z[2,1,4]  R755      -1.2089670449495316e-01
    z[2,1,4]  R756      0.221050426363945
    z[2,1,4]  R757      2.1512087434530258e-02
    z[2,1,4]  R758      -3.7427493929862976e-01
    z[2,1,4]  R759      2.4408282712101936e-02
    z[2,1,4]  R760      -3.5382375121116638e-01
    z[2,1,4]  R761      6.8781822919845581e-01
    z[2,1,4]  R762      -4.4453686475753784e-01
    z[2,1,4]  R763      6.4020842313766479e-01
    z[2,1,4]  R764      4.1498217731714249e-02
    z[2,1,4]  R765      1.1063133925199509e-01
    z[2,1,4]  R766      -9.9658809602260590e-02
    z[2,1,4]  R767      -0.0842304676771164
    z[2,1,4]  R768      -2.4974401295185089e-01
    z[2,1,4]  R769      -3.1321346759796143e-01
    z[2,1,4]  R770      -1.9275777041912079e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R682      -1
    z[2,1,5]  R683      1
    z[2,1,5]  R686      -3.8127186894416809e-01
    z[2,1,5]  R687      1.9546292722225189e-01
    z[2,1,5]  R688      1.2754661962389946e-02
    z[2,1,5]  R689      -2.3319636285305023e-01
    z[2,1,5]  R690      2.1404910087585449e-01
    z[2,1,5]  R691      -3.6159527301788330e-01
    z[2,1,5]  R692      4.9350535869598389e-01
    z[2,1,5]  R693      3.0156826972961426e-01
    z[2,1,5]  R694      0.588338315486908
    z[2,1,5]  R695      6.5808808803558350e-01
    z[2,1,5]  R696      7.5849437713623047e-01
    z[2,1,5]  R697      2.5602813810110092e-02
    z[2,1,5]  R698      -1.7964061116799712e-03
    z[2,1,5]  R699      9.3446910381317139e-02
    z[2,1,5]  R700      -1.8723461031913757e-01
    z[2,1,5]  R701      4.0902689099311829e-02
    z[2,1,5]  R702      7.3748230934143066e-02
    z[2,1,5]  R703      -2.8898175805807114e-02
    z[2,1,5]  R704      1.5492363274097443e-01
    z[2,1,5]  R705      -7.8078046441078186e-02
    z[2,1,5]  R706      -2.1046692132949829e-01
    z[2,1,5]  R707      -1.1115522682666779e-01
    z[2,1,5]  R708      -4.7295203804969788e-01
    z[2,1,5]  R709      -0.629519522190094
    z[2,1,5]  R710      -7.7274823188781738e-01
    z[2,1,5]  R711      -5.2689379453659058e-01
    z[2,1,5]  R712      1.8636273220181465e-02
    z[2,1,5]  R713      6.7329309880733490e-02
    z[2,1,5]  R714      4.7534830868244171e-02
    z[2,1,5]  R715      -1.3069508969783783e-01
    z[2,1,5]  R716      4.7280009835958481e-02
    z[2,1,5]  R717      -2.4256812036037445e-01
    z[2,1,5]  R718      1.0398554056882858e-01
    z[2,1,5]  R719      -0.625950813293457
    z[2,1,5]  R720      1.0464450716972351e-01
    z[2,1,5]  R721      -1.2760579586029053e-01
    z[2,1,5]  R722      2.7487901970744133e-02
    z[2,1,5]  R723      -1.0926242172718048e-01
    z[2,1,5]  R724      -9.2612817883491516e-02
    z[2,1,5]  R725      6.8953827023506165e-02
    z[2,1,5]  R726      -2.0019227266311646e-01
    z[2,1,5]  R727      -3.3036354184150696e-01
    z[2,1,5]  R728      -4.7876381874084473e-01
    z[2,1,5]  R729      5.3922671824693680e-02
    z[2,1,5]  R730      -0.264121949672699
    z[2,1,5]  R731      4.1039773821830750e-01
    z[2,1,5]  R732      1.3205060362815857e-01
    z[2,1,5]  R733      0.194817915558815
    z[2,1,5]  R734      1.7538410425186157e-01
    z[2,1,5]  R735      6.4642357826232910e-01
    z[2,1,5]  R736      -2.8103792667388916e-01
    z[2,1,5]  R737      7.0109167136251926e-03
    z[2,1,5]  R738      2.3674240708351135e-01
    z[2,1,5]  R739      7.5311444699764252e-02
    z[2,1,5]  R740      -2.9498040676116943e-02
    z[2,1,5]  R741      -6.6754192113876343e-02
    z[2,1,5]  R742      3.2755106687545776e-01
    z[2,1,5]  R743      2.3541361093521118e-01
    z[2,1,5]  R744      -5.1162582635879517e-01
    z[2,1,5]  R745      -2.5592150166630745e-02
    z[2,1,5]  R746      -3.0405440926551819e-01
    z[2,1,5]  R747      8.3945882320404053e-01
    z[2,1,5]  R748      -6.0283303260803223e-01
    z[2,1,5]  R749      -5.3239960223436356e-02
    z[2,1,5]  R750      -6.1507624387741089e-01
    z[2,1,5]  R751      -3.1253370642662048e-01
    z[2,1,5]  R752      -3.9272478222846985e-01
    z[2,1,5]  R753      -3.5361361503601074e-01
    z[2,1,5]  R754      -3.8169774413108826e-01
    z[2,1,5]  R755      5.6845819950103760e-01
    z[2,1,5]  R756      5.1635706424713135e-01
    z[2,1,5]  R757      -1.0229671746492386e-01
    z[2,1,5]  R758      -5.7824570685625076e-02
    z[2,1,5]  R759      -2.8982567787170410e-01
    z[2,1,5]  R760      1.9826823472976685e-01
    z[2,1,5]  R761      9.6248477697372437e-02
    z[2,1,5]  R762      -4.8029392957687378e-01
    z[2,1,5]  R763      4.1570165753364563e-01
    z[2,1,5]  R764      -3.5506728291511536e-01
    z[2,1,5]  R765      2.5812932848930359e-01
    z[2,1,5]  R766      -2.9577055573463440e-01
    z[2,1,5]  R767      1.9396256655454636e-02
    z[2,1,5]  R768      -3.2449653744697571e-01
    z[2,1,5]  R769      4.2761421203613281e-01
    z[2,1,5]  R770      -1.7201507091522217e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R684      -1
    z[2,1,6]  R685      1
    z[2,1,6]  R686      4.7085378319025040e-03
    z[2,1,6]  R687      7.4312782287597656e-01
    z[2,1,6]  R688      2.7942320704460144e-01
    z[2,1,6]  R689      -8.2495003938674927e-01
    z[2,1,6]  R690      7.7458268404006958e-01
    z[2,1,6]  R691      3.4406915307044983e-01
    z[2,1,6]  R692      2.1685181558132172e-01
    z[2,1,6]  R693      -7.4513129889965057e-02
    z[2,1,6]  R694      -5.2094870805740356e-01
    z[2,1,6]  R695      -2.1409682929515839e-01
    z[2,1,6]  R696      -1.2189421057701111e-01
    z[2,1,6]  R697      9.9363557994365692e-02
    z[2,1,6]  R698      -2.9586055874824524e-01
    z[2,1,6]  R699      -4.3308973312377930e-02
    z[2,1,6]  R700      -4.3077409267425537e-02
    z[2,1,6]  R701      -3.2265511155128479e-01
    z[2,1,6]  R702      4.9872463941574097e-01
    z[2,1,6]  R703      1.3152271509170532e-01
    z[2,1,6]  R704      3.0254775285720825e-01
    z[2,1,6]  R705      -6.7440646886825562e-01
    z[2,1,6]  R706      0.0453985333442688
    z[2,1,6]  R707      4.5224779844284058e-01
    z[2,1,6]  R708      5.3213948011398315e-01
    z[2,1,6]  R709      2.1461309492588043e-01
    z[2,1,6]  R710      -1.1411865800619125e-01
    z[2,1,6]  R711      1.1244162172079086e-01
    z[2,1,6]  R712      3.0335816740989685e-01
    z[2,1,6]  R713      -0.417203426361084
    z[2,1,6]  R714      -0.503563642501831
    z[2,1,6]  R715      9.0889401733875275e-02
    z[2,1,6]  R716      -2.5877895951271057e-01
    z[2,1,6]  R717      -8.0745331943035126e-02
    z[2,1,6]  R718      0.374576598405838
    z[2,1,6]  R719      -4.8989301919937134e-01
    z[2,1,6]  R720      2.0928401499986649e-02
    z[2,1,6]  R721      -2.4365289136767387e-02
    z[2,1,6]  R722      2.5289552286267281e-02
    z[2,1,6]  R723      3.9734715223312378e-01
    z[2,1,6]  R724      -2.2739601135253906e-01
    z[2,1,6]  R725      -0.0466383658349514
    z[2,1,6]  R726      3.5846567153930664e-01
    z[2,1,6]  R727      1.1906799674034119e-01
    z[2,1,6]  R728      3.1650140881538391e-02
    z[2,1,6]  R729      2.6548784971237183e-01
    z[2,1,6]  R730      -0.406181275844574
    z[2,1,6]  R731      5.1750767976045609e-02
    z[2,1,6]  R732      4.2256820201873779e-01
    z[2,1,6]  R733      -5.2460145950317383e-01
    z[2,1,6]  R734      -5.5509054660797119e-01
    z[2,1,6]  R735      2.6183506846427917e-01
    z[2,1,6]  R736      -1.2222281098365784e-01
    z[2,1,6]  R737      6.3423417508602142e-02
    z[2,1,6]  R738      2.3502789437770844e-01
    z[2,1,6]  R739      -0.00405834149569273
    z[2,1,6]  R740      -5.1050871610641479e-01
    z[2,1,6]  R741      0.63865065574646
    z[2,1,6]  R742      -1.4969493262469769e-02
    z[2,1,6]  R743      -1.7411597073078156e-01
    z[2,1,6]  R744      2.0495028793811798e-01
    z[2,1,6]  R745      3.2708659768104553e-02
    z[2,1,6]  R746      -5.1327300071716309e-01
    z[2,1,6]  R747      -3.6908425390720367e-02
    z[2,1,6]  R748      7.4787355959415436e-02
    z[2,1,6]  R749      3.2975021004676819e-01
    z[2,1,6]  R750      -2.9628169536590576e-01
    z[2,1,6]  R751      -1.2057397514581680e-01
    z[2,1,6]  R752      3.4699384123086929e-02
    z[2,1,6]  R753      0.268963485956192
    z[2,1,6]  R754      -1.2915319204330444e-01
    z[2,1,6]  R755      1.2269077450037003e-01
    z[2,1,6]  R756      -3.2819494605064392e-01
    z[2,1,6]  R757      -2.3916883766651154e-01
    z[2,1,6]  R758      3.5343545675277710e-01
    z[2,1,6]  R759      6.0876852273941040e-01
    z[2,1,6]  R760      6.9648787379264832e-02
    z[2,1,6]  R761      8.0360412597656250e-02
    z[2,1,6]  R762      -0.0366581492125988
    z[2,1,6]  R763      1.7690800130367279e-02
    z[2,1,6]  R764      4.7874860465526581e-02
    z[2,1,6]  R765      -2.7707897126674652e-02
    z[2,1,6]  R766      -4.6995177865028381e-01
    z[2,1,6]  R767      4.6346601098775864e-02
    z[2,1,6]  R768      2.3973459377884865e-02
    z[2,1,6]  R769      0.190284863114357
    z[2,1,6]  R770      2.4733503162860870e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R771      -1
    z[1,3,0]  R772      1
    z[1,3,0]  R785      -4.3973377346992493e-01
    z[1,3,0]  R786      -4.6908619999885559e-01
    z[1,3,0]  R787      -4.6749472618103027e-01
    z[1,3,0]  R788      -5.9391325712203979e-01
    z[1,3,0]  R789      -0.438795268535614
    z[1,3,0]  R790      6.8099820613861084e-01
    z[1,3,0]  R791      6.4077001810073853e-01
    z[1,3,0]  R792      7.4334591627120972e-01
    z[1,3,0]  R793      5.5163621902465820e-01
    z[1,3,0]  R794      6.8956816196441650e-01
    z[1,3,0]  R795      -4.7952553629875183e-01
    z[1,3,0]  R796      -0.32700115442276
    z[1,3,0]  R797      -2.9756346344947815e-01
    z[1,3,0]  R798      -3.4690535068511963e-01
    z[1,3,0]  R799      -2.8038537502288818e-01
    z[1,3,0]  R800      -4.4638866186141968e-01
    z[1,3,0]  R801      -4.1364064812660217e-01
    z[1,3,0]  R802      -0.2532939016819
    z[1,3,0]  R803      -2.7952659130096436e-01
    z[1,3,0]  R804      -2.2245080769062042e-01
    z[1,3,0]  R805      -3.7676227092742920e-01
    z[1,3,0]  R806      0.478341281414032
    z[1,3,0]  R807      0.676973283290863
    z[1,3,0]  R808      4.4680270552635193e-01
    z[1,3,0]  R809      6.4664644002914429e-01
    z[1,3,0]  R810      5.7975602149963379e-01
    z[1,3,0]  R811      0.586368203163147
    z[1,3,0]  R812      6.0991507768630981e-01
    z[1,3,0]  R813      0.332193523645401
    z[1,3,0]  R814      7.2198235988616943e-01
    z[1,3,0]  R815      1.0257675498723984e-01
    z[1,3,0]  R816      -2.2947709262371063e-01
    z[1,3,0]  R817      -3.6362317204475403e-01
    z[1,3,0]  R818      5.3756457567214966e-01
    z[1,3,0]  R819      -2.9505431652069092e-02
    z[1,3,0]  R820      4.5382156968116760e-01
    z[1,3,0]  R821      2.6670229434967041e-01
    z[1,3,0]  R822      7.3435842990875244e-01
    z[1,3,0]  R823      4.9293899536132812e-01
    z[1,3,0]  R824      6.9068127870559692e-01
    z[1,3,0]  R825      -5.4931193590164185e-01
    z[1,3,0]  R826      -3.8923683762550354e-01
    z[1,3,0]  R827      4.1136839985847473e-01
    z[1,3,0]  R828      -1.7706157639622688e-02
    z[1,3,0]  R829      1.2964147329330444e-01
    z[1,3,0]  R830      2.6234817504882812e-01
    z[1,3,0]  R831      4.7098869085311890e-01
    z[1,3,0]  R832      7.0320379734039307e-01
    z[1,3,0]  R833      4.5568275451660156e-01
    z[1,3,0]  R834      2.2768758237361908e-01
    z[1,3,0]  R835      -7.3867177963256836e-01
    z[1,3,0]  R836      -2.5451815128326416e-01
    z[1,3,0]  R837      -0.0896846279501915
    z[1,3,0]  R838      0.797221302986145
    z[1,3,0]  R839      -4.8959842324256897e-01
    z[1,3,0]  R840      -6.7485976219177246e-01
    z[1,3,0]  R841      7.8155982494354248e-01
    z[1,3,0]  R842      1.0259279608726501e-01
    z[1,3,0]  R843      2.9779151082038879e-01
    z[1,3,0]  R844      -6.8223649263381958e-01
    z[1,3,0]  R845      -3.3380830287933350e-01
    z[1,3,0]  R846      -2.7980053424835205e-01
    z[1,3,0]  R847      -3.6434146761894226e-01
    z[1,3,0]  R848      -1.6419696807861328e-01
    z[1,3,0]  R849      -3.8544863462448120e-01
    z[1,3,0]  R850      -0.623007595539093
    z[1,3,0]  R851      -7.5105018913745880e-02
    z[1,3,0]  R852      -2.9878070577979088e-02
    z[1,3,0]  R853      -1.8481391668319702e-01
    z[1,3,0]  R854      -3.4994819760322571e-01
    z[1,3,0]  R855      -1.7089748382568359e-01
    z[1,3,0]  R856      -2.3380618542432785e-02
    z[1,3,0]  R857      3.0983725190162659e-01
    z[1,3,0]  R858      3.7620510905981064e-02
    z[1,3,0]  R859      -1.0741529613733292e-01
    z[1,3,0]  R860      1.2551528215408325e-01
    z[1,3,0]  R861      -2.1165297925472260e-01
    z[1,3,0]  R862      1.9318635761737823e-01
    z[1,3,0]  R863      -2.2988358512520790e-02
    z[1,3,0]  R864      2.6377752423286438e-01
    z[1,3,0]  R865      3.2029467821121216e-01
    z[1,3,0]  R866      -0.270953506231308
    z[1,3,0]  R867      -9.1509437561035156e-01
    z[1,3,0]  R868      -8.7610584497451782e-01
    z[1,3,0]  R869      -8.2335573434829712e-01
    z[1,3,0]  R870      -7.5604027509689331e-01
    z[1,3,0]  R871      -0.256926566362381
    z[1,3,0]  R872      3.0761915445327759e-01
    z[1,3,0]  R873      2.4368667975068092e-02
    z[1,3,0]  R874      -1.7191019654273987e-01
    z[1,3,0]  R875      3.1932809948921204e-01
    z[1,3,0]  R876      -0.70970618724823
    z[1,3,0]  R877      -4.7882348299026489e-02
    z[1,3,0]  R878      -4.7134313732385635e-02
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R773      -1
    z[1,3,1]  R774      1
    z[1,3,1]  R785      7.0582723617553711e-01
    z[1,3,1]  R786      7.4835884571075439e-01
    z[1,3,1]  R787      6.4602726697921753e-01
    z[1,3,1]  R788      4.0355780720710754e-01
    z[1,3,1]  R789      2.8929588198661804e-01
    z[1,3,1]  R790      -1.5599606931209564e-01
    z[1,3,1]  R791      -2.5938186049461365e-01
    z[1,3,1]  R792      -2.8838065266609192e-01
    z[1,3,1]  R793      -2.6488536596298218e-01
    z[1,3,1]  R794      -1.8207627534866333e-01
    z[1,3,1]  R795      -0.722950279712677
    z[1,3,1]  R796      -7.9297041893005371e-01
    z[1,3,1]  R797      -8.1031274795532227e-01
    z[1,3,1]  R798      -7.6446080207824707e-01
    z[1,3,1]  R799      -0.84675532579422
    z[1,3,1]  R800      -6.3792812824249268e-01
    z[1,3,1]  R801      -6.0679459571838379e-01
    z[1,3,1]  R802      -6.9677561521530151e-01
    z[1,3,1]  R803      -6.4049822092056274e-01
    z[1,3,1]  R804      -7.5996285676956177e-01
    z[1,3,1]  R805      3.1034144759178162e-01
    z[1,3,1]  R806      6.3583391904830933e-01
    z[1,3,1]  R807      0.596767783164978
    z[1,3,1]  R808      7.8609246015548706e-01
    z[1,3,1]  R809      5.6476938724517822e-01
    z[1,3,1]  R810      4.8868107795715332e-01
    z[1,3,1]  R811      3.9729556441307068e-01
    z[1,3,1]  R812      6.6568471491336823e-02
    z[1,3,1]  R813      -1.3944588601589203e-02
    z[1,3,1]  R814      1.3699467480182648e-01
    z[1,3,1]  R815      -7.8468644618988037e-01
    z[1,3,1]  R816      3.0972850322723389e-01
    z[1,3,1]  R817      2.8695744276046753e-01
    z[1,3,1]  R818      1.9082698225975037e-01
    z[1,3,1]  R819      4.2503336071968079e-01
    z[1,3,1]  R820      -9.7298972308635712e-02
    z[1,3,1]  R821      -1.1420476436614990e-01
    z[1,3,1]  R822      1.7754136025905609e-01
    z[1,3,1]  R823      -2.3391132056713104e-01
    z[1,3,1]  R824      2.2367011010646820e-01
    z[1,3,1]  R825      2.0922964811325073e-01
    z[1,3,1]  R826      3.7760722637176514e-01
    z[1,3,1]  R827      -3.3757331967353821e-01
    z[1,3,1]  R828      5.3565579652786255e-01
    z[1,3,1]  R829      5.6941163539886475e-01
    z[1,3,1]  R830      8.3352994918823242e-01
    z[1,3,1]  R831      3.5133186727762222e-02
    z[1,3,1]  R832      7.6741680502891541e-02
    z[1,3,1]  R833      -2.1169431507587433e-02
    z[1,3,1]  R834      -1.0548040270805359e-01
    z[1,3,1]  R835      3.7100705504417419e-01
    z[1,3,1]  R836      6.1308199167251587e-01
    z[1,3,1]  R837      3.0658674240112305e-01
    z[1,3,1]  R838      2.2164407372474670e-01
    z[1,3,1]  R839      7.7359803020954132e-02
    z[1,3,1]  R840      1.0380051285028458e-01
    z[1,3,1]  R841      -1.7388090491294861e-02
    z[1,3,1]  R842      -3.0639293789863586e-01
    z[1,3,1]  R843      -2.3125894367694855e-01
    z[1,3,1]  R844      -2.1502365171909332e-01
    z[1,3,1]  R845      1.0191959142684937e-01
    z[1,3,1]  R846      3.8500636816024780e-01
    z[1,3,1]  R847      2.3486943542957306e-01
    z[1,3,1]  R848      0.492320716381073
    z[1,3,1]  R849      -1.7778109014034271e-01
    z[1,3,1]  R850      -3.3669683337211609e-01
    z[1,3,1]  R851      -0.718687117099762
    z[1,3,1]  R852      -2.8747299313545227e-01
    z[1,3,1]  R853      -7.5129759311676025e-01
    z[1,3,1]  R854      -7.0751869678497314e-01
    z[1,3,1]  R855      -6.9615596532821655e-01
    z[1,3,1]  R856      -6.8274384737014771e-01
    z[1,3,1]  R857      -4.2941969633102417e-01
    z[1,3,1]  R858      5.7843305170536041e-02
    z[1,3,1]  R859      0.267410010099411
    z[1,3,1]  R860      2.2924886643886566e-01
    z[1,3,1]  R861      -8.6893546581268311e-01
    z[1,3,1]  R862      -6.7153471708297729e-01
    z[1,3,1]  R863      0.466298371553421
    z[1,3,1]  R864      8.9918178319931030e-01
    z[1,3,1]  R865      2.1315771341323853e-01
    z[1,3,1]  R866      6.0820490121841431e-01
    z[1,3,1]  R867      1.7647847533226013e-01
    z[1,3,1]  R868      -3.6327905952930450e-02
    z[1,3,1]  R869      4.0621817111968994e-02
    z[1,3,1]  R870      2.8182867169380188e-01
    z[1,3,1]  R871      3.1204733252525330e-01
    z[1,3,1]  R872      -6.9999796152114868e-01
    z[1,3,1]  R873      6.9709378480911255e-01
    z[1,3,1]  R874      4.5377466082572937e-01
    z[1,3,1]  R875      0.0917489156126976
    z[1,3,1]  R876      4.4188103079795837e-01
    z[1,3,1]  R877      4.5328539609909058e-01
    z[1,3,1]  R878      4.9532383680343628e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R775      -1
    z[1,3,2]  R776      1
    z[1,3,2]  R785      -0.229117289185524
    z[1,3,2]  R786      -2.6490619778633118e-01
    z[1,3,2]  R787      -4.8827031254768372e-01
    z[1,3,2]  R788      -5.6621521711349487e-01
    z[1,3,2]  R789      -1.5989576280117035e-01
    z[1,3,2]  R790      2.4967324733734131e-01
    z[1,3,2]  R791      3.6085703969001770e-01
    z[1,3,2]  R792      5.2071553468704224e-01
    z[1,3,2]  R793      1.2483359873294830e-01
    z[1,3,2]  R794      5.2010452747344971e-01
    z[1,3,2]  R795      -9.7651155665516853e-03
    z[1,3,2]  R796      -3.0187508463859558e-01
    z[1,3,2]  R797      -2.5007483363151550e-01
    z[1,3,2]  R798      -1.1067414283752441e-01
    z[1,3,2]  R799      -1.7438901960849762e-01
    z[1,3,2]  R800      -1.1787618696689606e-01
    z[1,3,2]  R801      4.9787878990173340e-02
    z[1,3,2]  R802      -2.6266448199748993e-02
    z[1,3,2]  R803      -0.0127011863514781
    z[1,3,2]  R804      1.0693140327930450e-01
    z[1,3,2]  R805      -2.6498275995254517e-01
    z[1,3,2]  R806      -3.5252094268798828e-01
    z[1,3,2]  R807      -2.2569186985492706e-01
    z[1,3,2]  R808      0.0648149698972702
    z[1,3,2]  R809      0.0210171639919281
    z[1,3,2]  R810      1.3366617262363434e-02
    z[1,3,2]  R811      -1.1218158155679703e-01
    z[1,3,2]  R812      9.2862747609615326e-02
    z[1,3,2]  R813      6.3014000654220581e-01
    z[1,3,2]  R814      2.3018909990787506e-01
    z[1,3,2]  R815      6.6623359918594360e-02
    z[1,3,2]  R816      1.4183364808559418e-01
    z[1,3,2]  R817      -2.5261448696255684e-02
    z[1,3,2]  R818      -0.235975444316864
    z[1,3,2]  R819      -8.3938531577587128e-02
    z[1,3,2]  R820      9.7031831741333008e-02
    z[1,3,2]  R821      5.5120289325714111e-01
    z[1,3,2]  R822      3.6256012320518494e-01
    z[1,3,2]  R823      0.472822368144989
    z[1,3,2]  R824      0.268179327249527
    z[1,3,2]  R825      -2.5414398312568665e-01
    z[1,3,2]  R826      1.1739699542522430e-01
    z[1,3,2]  R827      1.4202952384948730e-01
    z[1,3,2]  R828      -1.2348987907171249e-01
    z[1,3,2]  R829      -3.3790859580039978e-01
    z[1,3,2]  R830      -1.2669317424297333e-01
    z[1,3,2]  R831      -6.8267039954662323e-02
    z[1,3,2]  R832      2.3709677159786224e-01
    z[1,3,2]  R833      -3.4693825244903564e-01
    z[1,3,2]  R834      6.3916486501693726e-01
    z[1,3,2]  R835      -3.9355117082595825e-01
    z[1,3,2]  R836      -1.1480126529932022e-02
    z[1,3,2]  R837      1.7177364230155945e-01
    z[1,3,2]  R838      3.8163551688194275e-01
    z[1,3,2]  R839      3.4038397669792175e-01
    z[1,3,2]  R840      0.566510021686554
    z[1,3,2]  R841      1.0951692610979080e-01
    z[1,3,2]  R842      2.0774249732494354e-01
    z[1,3,2]  R843      1.5276065468788147e-01
    z[1,3,2]  R844      -5.8153885602951050e-01
    z[1,3,2]  R845      -7.0255053043365479e-01
    z[1,3,2]  R846      -7.0949810743331909e-01
    z[1,3,2]  R847      -7.4259728193283081e-01
    z[1,3,2]  R848      -8.2217389345169067e-01
    z[1,3,2]  R849      -8.1349629163742065e-01
    z[1,3,2]  R850      -3.9143708348274231e-01
    z[1,3,2]  R851      -6.0328418016433716e-01
    z[1,3,2]  R852      0.596624493598938
    z[1,3,2]  R853      -3.7396702170372009e-01
    z[1,3,2]  R854      -1.9479447603225708e-01
    z[1,3,2]  R855      -3.1045052409172058e-01
    z[1,3,2]  R856      -2.8534984588623047e-01
    z[1,3,2]  R857      -7.6795852184295654e-01
    z[1,3,2]  R858      -7.4868999421596527e-02
    z[1,3,2]  R859      2.5967352092266083e-02
    z[1,3,2]  R860      -3.5041561722755432e-01
    z[1,3,2]  R861      1.6584739089012146e-01
    z[1,3,2]  R862      -1.2550047039985657e-01
    z[1,3,2]  R863      5.0444994121789932e-02
    z[1,3,2]  R864      1.2987813353538513e-01
    z[1,3,2]  R865      -2.4401377141475677e-01
    z[1,3,2]  R866      6.6568940877914429e-01
    z[1,3,2]  R867      3.2851299643516541e-01
    z[1,3,2]  R868      1.8951553106307983e-01
    z[1,3,2]  R869      2.3056674003601074e-01
    z[1,3,2]  R870      -1.7282633483409882e-01
    z[1,3,2]  R871      8.4044122695922852e-01
    z[1,3,2]  R872      -4.4037258625030518e-01
    z[1,3,2]  R873      -1.7382787168025970e-01
    z[1,3,2]  R874      -2.4577982723712921e-01
    z[1,3,2]  R875      -4.2546781897544861e-01
    z[1,3,2]  R876      1.5264713205397129e-02
    z[1,3,2]  R877      -2.8176712989807129e-01
    z[1,3,2]  R878      2.4739317595958710e-03
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R777      -1
    z[1,3,3]  R778      1
    z[1,3,3]  R785      -2.9019543528556824e-01
    z[1,3,3]  R786      5.7496611028909683e-02
    z[1,3,3]  R787      -7.3940992355346680e-02
    z[1,3,3]  R788      2.4332102388143539e-02
    z[1,3,3]  R789      -8.6339443922042847e-02
    z[1,3,3]  R790      0.651769757270813
    z[1,3,3]  R791      5.7279855012893677e-01
    z[1,3,3]  R792      2.7020815014839172e-01
    z[1,3,3]  R793      6.3380479812622070e-01
    z[1,3,3]  R794      3.6046424508094788e-01
    z[1,3,3]  R795      -0.477079302072525
    z[1,3,3]  R796      6.7505910992622375e-02
    z[1,3,3]  R797      2.5140070915222168e-01
    z[1,3,3]  R798      -1.8602685630321503e-01
    z[1,3,3]  R799      -2.1406927704811096e-01
    z[1,3,3]  R800      -2.8279563784599304e-01
    z[1,3,3]  R801      -0.0956747829914093
    z[1,3,3]  R802      -2.6482401415705681e-02
    z[1,3,3]  R803      -1.0606414824724197e-01
    z[1,3,3]  R804      1.4834043383598328e-01
    z[1,3,3]  R805      -3.7804111838340759e-01
    z[1,3,3]  R806      3.8450878858566284e-01
    z[1,3,3]  R807      0.0953054204583168
    z[1,3,3]  R808      1.9266439601778984e-02
    z[1,3,3]  R809      -3.2006785273551941e-01
    z[1,3,3]  R810      -3.1716409325599670e-01
    z[1,3,3]  R811      -2.4189472198486328e-01
    z[1,3,3]  R812      -4.9281543493270874e-01
    z[1,3,3]  R813      -4.6805629134178162e-01
    z[1,3,3]  R814      1.9967010244727135e-02
    z[1,3,3]  R815      -2.6093193888664246e-01
    z[1,3,3]  R816      -6.8618077039718628e-01
    z[1,3,3]  R817      -1.8147185444831848e-01
    z[1,3,3]  R818      -4.9503338336944580e-01
    z[1,3,3]  R819      -7.3967504501342773e-01
    z[1,3,3]  R820      5.1183837652206421e-01
    z[1,3,3]  R821      -4.9407193064689636e-01
    z[1,3,3]  R822      -1.5420243144035339e-01
    z[1,3,3]  R823      -5.0213855504989624e-01
    z[1,3,3]  R824      3.4624069929122925e-02
    z[1,3,3]  R825      -0.486905038356781
    z[1,3,3]  R826      -5.1858031749725342e-01
    z[1,3,3]  R827      7.9279178380966187e-01
    z[1,3,3]  R828      -6.5510874986648560e-01
    z[1,3,3]  R829      2.9931154847145081e-01
    z[1,3,3]  R830      2.2582674026489258e-01
    z[1,3,3]  R831      -0.532409131526947
    z[1,3,3]  R832      1.1730780452489853e-01
    z[1,3,3]  R833      -2.9757568240165710e-01
    z[1,3,3]  R834      -6.3120013475418091e-01
    z[1,3,3]  R835      -2.8670126199722290e-01
    z[1,3,3]  R836      -4.9086907505989075e-01
    z[1,3,3]  R837      -9.2673414945602417e-01
    z[1,3,3]  R838      3.7704259157180786e-02
    z[1,3,3]  R839      5.6681799888610840e-01
    z[1,3,3]  R840      2.9143935441970825e-01
    z[1,3,3]  R841      7.1820162236690521e-02
    z[1,3,3]  R842      -6.9875025749206543e-01
    z[1,3,3]  R843      -3.1949985027313232e-01
    z[1,3,3]  R844      -2.5845754891633987e-02
    z[1,3,3]  R845      1.2670738995075226e-01
    z[1,3,3]  R846      8.2595452666282654e-02
    z[1,3,3]  R847      7.8051716089248657e-02
    z[1,3,3]  R848      4.2187362909317017e-02
    z[1,3,3]  R849      -1.5487730503082275e-01
    z[1,3,3]  R850      -9.0489059686660767e-02
    z[1,3,3]  R851      2.5117591023445129e-01
    z[1,3,3]  R852      -3.9477947354316711e-01
    z[1,3,3]  R853      2.0609444379806519e-01
    z[1,3,3]  R854      0.452725350856781
    z[1,3,3]  R855      4.5630702376365662e-01
    z[1,3,3]  R856      6.1334747076034546e-01
    z[1,3,3]  R857      1.7385989427566528e-01
    z[1,3,3]  R858      -5.1712733507156372e-01
    z[1,3,3]  R859      -4.2898854613304138e-01
    z[1,3,3]  R860      -2.4088618159294128e-01
    z[1,3,3]  R861      2.0723941922187805e-01
    z[1,3,3]  R862      -2.8265175223350525e-01
    z[1,3,3]  R863      -8.5531359910964966e-01
    z[1,3,3]  R864      9.9095046520233154e-02
    z[1,3,3]  R865      -7.8946202993392944e-01
    z[1,3,3]  R866      -5.9033695608377457e-02
    z[1,3,3]  R867      3.0602285638451576e-02
    z[1,3,3]  R868      2.0207408070564270e-01
    z[1,3,3]  R869      4.4499572366476059e-02
    z[1,3,3]  R870      5.3708565235137939e-01
    z[1,3,3]  R871      -1.2076288461685181e-01
    z[1,3,3]  R872      -7.4476338922977448e-02
    z[1,3,3]  R873      -6.3618320226669312e-01
    z[1,3,3]  R874      -6.0746544599533081e-01
    z[1,3,3]  R875      -7.5059723854064941e-01
    z[1,3,3]  R876      4.6818497776985168e-01
    z[1,3,3]  R877      6.4250385761260986e-01
    z[1,3,3]  R878      7.8726017475128174e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R779      -1
    z[1,3,4]  R780      1
    z[1,3,4]  R785      3.8261204957962036e-01
    z[1,3,4]  R786      2.7791008353233337e-01
    z[1,3,4]  R787      -2.3422902822494507e-01
    z[1,3,4]  R788      1.0998079180717468e-01
    z[1,3,4]  R789      2.4276715517044067e-01
    z[1,3,4]  R790      -1.1566183716058731e-01
    z[1,3,4]  R791      2.1666100621223450e-01
    z[1,3,4]  R792      1.3682533800601959e-01
    z[1,3,4]  R793      1.9600607454776764e-01
    z[1,3,4]  R794      1.7497076094150543e-01
    z[1,3,4]  R795      1.1299677938222885e-01
    z[1,3,4]  R796      -2.8302571736276150e-03
    z[1,3,4]  R797      0.0761076956987381
    z[1,3,4]  R798      1.3485226035118103e-01
    z[1,3,4]  R799      -2.3401015996932983e-01
    z[1,3,4]  R800      -2.5529021024703979e-01
    z[1,3,4]  R801      0.527223527431488
    z[1,3,4]  R802      0.502944827079773
    z[1,3,4]  R803      -4.3249884247779846e-01
    z[1,3,4]  R804      -2.5453118607401848e-02
    z[1,3,4]  R805      -2.4937191605567932e-01
    z[1,3,4]  R806      2.9429266229271889e-02
    z[1,3,4]  R807      -3.4854507446289062e-01
    z[1,3,4]  R808      -2.5800922513008118e-01
    z[1,3,4]  R809      -3.9282381534576416e-01
    z[1,3,4]  R810      -2.5062489509582520e-01
    z[1,3,4]  R811      -1.2206542491912842e-01
    z[1,3,4]  R812      5.1436161994934082e-01
    z[1,3,4]  R813      4.3308654427528381e-01
    z[1,3,4]  R814      -3.2065966725349426e-01
    z[1,3,4]  R815      -5.4726237058639526e-01
    z[1,3,4]  R816      -6.7449599504470825e-02
    z[1,3,4]  R817      2.1403318643569946e-01
    z[1,3,4]  R818      -6.9757483899593353e-02
    z[1,3,4]  R819      -3.9082175493240356e-01
    z[1,3,4]  R820      -2.1698732674121857e-01
    z[1,3,4]  R821      0.505648136138916
    z[1,3,4]  R822      -3.4428441524505615e-01
    z[1,3,4]  R823      1.7090511322021484e-01
    z[1,3,4]  R824      -4.8727640509605408e-01
    z[1,3,4]  R825      -1.2089670449495316e-01
    z[1,3,4]  R826      0.221050426363945
    z[1,3,4]  R827      2.1512087434530258e-02
    z[1,3,4]  R828      -3.7427493929862976e-01
    z[1,3,4]  R829      2.4408282712101936e-02
    z[1,3,4]  R830      -3.5382375121116638e-01
    z[1,3,4]  R831      6.8781822919845581e-01
    z[1,3,4]  R832      -4.4453686475753784e-01
    z[1,3,4]  R833      6.4020842313766479e-01
    z[1,3,4]  R834      4.1498217731714249e-02
    z[1,3,4]  R835      1.1063133925199509e-01
    z[1,3,4]  R836      -9.9658809602260590e-02
    z[1,3,4]  R837      -0.0842304676771164
    z[1,3,4]  R838      -2.4974401295185089e-01
    z[1,3,4]  R839      -3.1321346759796143e-01
    z[1,3,4]  R840      -1.9275777041912079e-01
    z[1,3,4]  R841      1.5497450530529022e-01
    z[1,3,4]  R842      4.9810070544481277e-02
    z[1,3,4]  R843      -8.2780605554580688e-01
    z[1,3,4]  R844      -2.7678960561752319e-01
    z[1,3,4]  R845      -5.9021586179733276e-01
    z[1,3,4]  R846      -3.2592964172363281e-01
    z[1,3,4]  R847      -3.5340425372123718e-01
    z[1,3,4]  R848      -2.1101097762584686e-01
    z[1,3,4]  R849      -8.1960320472717285e-02
    z[1,3,4]  R850      -5.4664772748947144e-01
    z[1,3,4]  R851      1.3832703232765198e-01
    z[1,3,4]  R852      -1.6693617403507233e-01
    z[1,3,4]  R853      8.9001677930355072e-02
    z[1,3,4]  R854      -1.7687901854515076e-01
    z[1,3,4]  R855      -1.4729164540767670e-01
    z[1,3,4]  R856      -1.5474909543991089e-01
    z[1,3,4]  R857      -1.9208058714866638e-01
    z[1,3,4]  R858      7.8312915563583374e-01
    z[1,3,4]  R859      6.8898481130599976e-01
    z[1,3,4]  R860      6.6069936752319336e-01
    z[1,3,4]  R861      -2.2109439969062805e-01
    z[1,3,4]  R862      4.3592989444732666e-01
    z[1,3,4]  R863      -1.4450874924659729e-01
    z[1,3,4]  R864      0.0320991687476635
    z[1,3,4]  R865      -4.8460375517606735e-02
    z[1,3,4]  R866      2.4460107088088989e-01
    z[1,3,4]  R867      9.5805555582046509e-02
    z[1,3,4]  R868      1.2552116811275482e-01
    z[1,3,4]  R869      4.9232020974159241e-01
    z[1,3,4]  R870      1.6777239739894867e-01
    z[1,3,4]  R871      1.8751016259193420e-01
    z[1,3,4]  R872      -1.9941788911819458e-01
    z[1,3,4]  R873      -3.2221134752035141e-02
    z[1,3,4]  R874      -0.0489906370639801
    z[1,3,4]  R875      -2.7909772470593452e-02
    z[1,3,4]  R876      -2.1687658131122589e-01
    z[1,3,4]  R877      -5.3138142824172974e-01
    z[1,3,4]  R878      -1.9959336519241333e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R781      -1
    z[1,3,5]  R782      1
    z[1,3,5]  R785      -1.3069508969783783e-01
    z[1,3,5]  R786      4.7280009835958481e-02
    z[1,3,5]  R787      -2.4256812036037445e-01
    z[1,3,5]  R788      1.0398554056882858e-01
    z[1,3,5]  R789      -0.625950813293457
    z[1,3,5]  R790      1.0464450716972351e-01
    z[1,3,5]  R791      -1.2760579586029053e-01
    z[1,3,5]  R792      2.7487901970744133e-02
    z[1,3,5]  R793      -1.0926242172718048e-01
    z[1,3,5]  R794      -9.2612817883491516e-02
    z[1,3,5]  R795      6.8953827023506165e-02
    z[1,3,5]  R796      -2.0019227266311646e-01
    z[1,3,5]  R797      -3.3036354184150696e-01
    z[1,3,5]  R798      -4.7876381874084473e-01
    z[1,3,5]  R799      5.3922671824693680e-02
    z[1,3,5]  R800      -0.264121949672699
    z[1,3,5]  R801      4.1039773821830750e-01
    z[1,3,5]  R802      1.3205060362815857e-01
    z[1,3,5]  R803      0.194817915558815
    z[1,3,5]  R804      1.7538410425186157e-01
    z[1,3,5]  R805      6.4642357826232910e-01
    z[1,3,5]  R806      -2.8103792667388916e-01
    z[1,3,5]  R807      7.0109167136251926e-03
    z[1,3,5]  R808      2.3674240708351135e-01
    z[1,3,5]  R809      7.5311444699764252e-02
    z[1,3,5]  R810      -2.9498040676116943e-02
    z[1,3,5]  R811      -6.6754192113876343e-02
    z[1,3,5]  R812      3.2755106687545776e-01
    z[1,3,5]  R813      2.3541361093521118e-01
    z[1,3,5]  R814      -5.1162582635879517e-01
    z[1,3,5]  R815      -2.5592150166630745e-02
    z[1,3,5]  R816      -3.0405440926551819e-01
    z[1,3,5]  R817      8.3945882320404053e-01
    z[1,3,5]  R818      -6.0283303260803223e-01
    z[1,3,5]  R819      -5.3239960223436356e-02
    z[1,3,5]  R820      -6.1507624387741089e-01
    z[1,3,5]  R821      -3.1253370642662048e-01
    z[1,3,5]  R822      -3.9272478222846985e-01
    z[1,3,5]  R823      -3.5361361503601074e-01
    z[1,3,5]  R824      -3.8169774413108826e-01
    z[1,3,5]  R825      5.6845819950103760e-01
    z[1,3,5]  R826      5.1635706424713135e-01
    z[1,3,5]  R827      -1.0229671746492386e-01
    z[1,3,5]  R828      -5.7824570685625076e-02
    z[1,3,5]  R829      -2.8982567787170410e-01
    z[1,3,5]  R830      1.9826823472976685e-01
    z[1,3,5]  R831      9.6248477697372437e-02
    z[1,3,5]  R832      -4.8029392957687378e-01
    z[1,3,5]  R833      4.1570165753364563e-01
    z[1,3,5]  R834      -3.5506728291511536e-01
    z[1,3,5]  R835      2.5812932848930359e-01
    z[1,3,5]  R836      -2.9577055573463440e-01
    z[1,3,5]  R837      1.9396256655454636e-02
    z[1,3,5]  R838      -3.2449653744697571e-01
    z[1,3,5]  R839      4.2761421203613281e-01
    z[1,3,5]  R840      -1.7201507091522217e-01
    z[1,3,5]  R841      -5.8452707529067993e-01
    z[1,3,5]  R842      -1.2743914127349854e-01
    z[1,3,5]  R843      1.7452562227845192e-02
    z[1,3,5]  R844      8.7726123631000519e-02
    z[1,3,5]  R845      -1.3058429956436157e-01
    z[1,3,5]  R846      -7.9703167080879211e-02
    z[1,3,5]  R847      -3.2697755098342896e-01
    z[1,3,5]  R848      2.0583800971508026e-02
    z[1,3,5]  R849      4.2072642594575882e-02
    z[1,3,5]  R850      -1.1930692009627819e-02
    z[1,3,5]  R851      1.0244762152433395e-01
    z[1,3,5]  R852      -2.3369353264570236e-02
    z[1,3,5]  R853      -1.6928309202194214e-01
    z[1,3,5]  R854      -2.7417975664138794e-01
    z[1,3,5]  R855      3.0409688130021095e-02
    z[1,3,5]  R856      1.0035818442702293e-02
    z[1,3,5]  R857      2.0721469819545746e-01
    z[1,3,5]  R858      3.1202328205108643e-01
    z[1,3,5]  R859      2.7599191665649414e-01
    z[1,3,5]  R860      3.9503401517868042e-01
    z[1,3,5]  R861      -1.6550481319427490e-01
    z[1,3,5]  R862      3.0633789300918579e-01
    z[1,3,5]  R863      1.5955626964569092e-01
    z[1,3,5]  R864      2.4823763966560364e-01
    z[1,3,5]  R865      2.1159994602203369e-01
    z[1,3,5]  R866      -2.1541567146778107e-01
    z[1,3,5]  R867      -9.5731422305107117e-02
    z[1,3,5]  R868      -0.0866822898387909
    z[1,3,5]  R869      -7.0915900170803070e-02
    z[1,3,5]  R870      -2.4924285709857941e-02
    z[1,3,5]  R871      -8.8141247630119324e-02
    z[1,3,5]  R872      2.8659364581108093e-01
    z[1,3,5]  R873      0.0913451761007309
    z[1,3,5]  R874      -1.2837243080139160e-01
    z[1,3,5]  R875      3.7850487232208252e-01
    z[1,3,5]  R876      -8.4200866520404816e-02
    z[1,3,5]  R877      0.0953843742609024
    z[1,3,5]  R878      2.8075750917196274e-02
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R783      -1
    z[1,3,6]  R784      1
    z[1,3,6]  R785      9.0889401733875275e-02
    z[1,3,6]  R786      -2.5877895951271057e-01
    z[1,3,6]  R787      -8.0745331943035126e-02
    z[1,3,6]  R788      0.374576598405838
    z[1,3,6]  R789      -4.8989301919937134e-01
    z[1,3,6]  R790      2.0928401499986649e-02
    z[1,3,6]  R791      -2.4365289136767387e-02
    z[1,3,6]  R792      2.5289552286267281e-02
    z[1,3,6]  R793      3.9734715223312378e-01
    z[1,3,6]  R794      -2.2739601135253906e-01
    z[1,3,6]  R795      -0.0466383658349514
    z[1,3,6]  R796      3.5846567153930664e-01
    z[1,3,6]  R797      1.1906799674034119e-01
    z[1,3,6]  R798      3.1650140881538391e-02
    z[1,3,6]  R799      2.6548784971237183e-01
    z[1,3,6]  R800      -0.406181275844574
    z[1,3,6]  R801      5.1750767976045609e-02
    z[1,3,6]  R802      4.2256820201873779e-01
    z[1,3,6]  R803      -5.2460145950317383e-01
    z[1,3,6]  R804      -5.5509054660797119e-01
    z[1,3,6]  R805      2.6183506846427917e-01
    z[1,3,6]  R806      -1.2222281098365784e-01
    z[1,3,6]  R807      6.3423417508602142e-02
    z[1,3,6]  R808      2.3502789437770844e-01
    z[1,3,6]  R809      -0.00405834149569273
    z[1,3,6]  R810      -5.1050871610641479e-01
    z[1,3,6]  R811      0.63865065574646
    z[1,3,6]  R812      -1.4969493262469769e-02
    z[1,3,6]  R813      -1.7411597073078156e-01
    z[1,3,6]  R814      2.0495028793811798e-01
    z[1,3,6]  R815      3.2708659768104553e-02
    z[1,3,6]  R816      -5.1327300071716309e-01
    z[1,3,6]  R817      -3.6908425390720367e-02
    z[1,3,6]  R818      7.4787355959415436e-02
    z[1,3,6]  R819      3.2975021004676819e-01
    z[1,3,6]  R820      -2.9628169536590576e-01
    z[1,3,6]  R821      -1.2057397514581680e-01
    z[1,3,6]  R822      3.4699384123086929e-02
    z[1,3,6]  R823      0.268963485956192
    z[1,3,6]  R824      -1.2915319204330444e-01
    z[1,3,6]  R825      1.2269077450037003e-01
    z[1,3,6]  R826      -3.2819494605064392e-01
    z[1,3,6]  R827      -2.3916883766651154e-01
    z[1,3,6]  R828      3.5343545675277710e-01
    z[1,3,6]  R829      6.0876852273941040e-01
    z[1,3,6]  R830      6.9648787379264832e-02
    z[1,3,6]  R831      8.0360412597656250e-02
    z[1,3,6]  R832      -0.0366581492125988
    z[1,3,6]  R833      1.7690800130367279e-02
    z[1,3,6]  R834      4.7874860465526581e-02
    z[1,3,6]  R835      -2.7707897126674652e-02
    z[1,3,6]  R836      -4.6995177865028381e-01
    z[1,3,6]  R837      4.6346601098775864e-02
    z[1,3,6]  R838      2.3973459377884865e-02
    z[1,3,6]  R839      0.190284863114357
    z[1,3,6]  R840      2.4733503162860870e-01
    z[1,3,6]  R841      -7.7593624591827393e-02
    z[1,3,6]  R842      5.8776468038558960e-01
    z[1,3,6]  R843      2.1646265685558319e-01
    z[1,3,6]  R844      2.5525358319282532e-01
    z[1,3,6]  R845      -5.6083530187606812e-02
    z[1,3,6]  R846      -3.8818728923797607e-01
    z[1,3,6]  R847      -1.5079762041568756e-01
    z[1,3,6]  R848      -8.9222088456153870e-02
    z[1,3,6]  R849      -3.5436192154884338e-01
    z[1,3,6]  R850      -1.9524197280406952e-01
    z[1,3,6]  R851      -1.4552305638790131e-01
    z[1,3,6]  R852      -6.1338496208190918e-01
    z[1,3,6]  R853      -4.2719018459320068e-01
    z[1,3,6]  R854      -1.6609518229961395e-01
    z[1,3,6]  R855      -3.9867994189262390e-01
    z[1,3,6]  R856      2.2725857794284821e-01
    z[1,3,6]  R857      1.4063820242881775e-01
    z[1,3,6]  R858      1.0753098130226135e-01
    z[1,3,6]  R859      4.2588347196578979e-01
    z[1,3,6]  R860      3.9786690473556519e-01
    z[1,3,6]  R861      -2.3114077746868134e-01
    z[1,3,6]  R862      -3.6359328031539917e-01
    z[1,3,6]  R863      -3.9879478514194489e-02
    z[1,3,6]  R864      1.8042442202568054e-01
    z[1,3,6]  R865      -3.4936955571174622e-01
    z[1,3,6]  R866      6.1725240200757980e-02
    z[1,3,6]  R867      -6.5246790647506714e-02
    z[1,3,6]  R868      -3.6207631230354309e-01
    z[1,3,6]  R869      -1.3373765349388123e-01
    z[1,3,6]  R870      4.3322015553712845e-02
    z[1,3,6]  R871      -2.6974296569824219e-01
    z[1,3,6]  R872      -3.0658626556396484e-01
    z[1,3,6]  R873      -2.6294332742691040e-01
    z[1,3,6]  R874      5.6234681606292725e-01
    z[1,3,6]  R875      3.3876877278089523e-02
    z[1,3,6]  R876      1.6584002971649170e-01
    z[1,3,6]  R877      9.2581234872341156e-02
    z[1,3,6]  R878      -3.0335170030593872e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R879      -1
    z[3,1,0]  R880      1
    z[3,1,0]  R893      7.8155982494354248e-01
    z[3,1,0]  R894      1.0259279608726501e-01
    z[3,1,0]  R895      2.9779151082038879e-01
    z[3,1,0]  R896      -6.8223649263381958e-01
    z[3,1,0]  R897      -3.3380830287933350e-01
    z[3,1,0]  R898      -2.7980053424835205e-01
    z[3,1,0]  R899      -3.6434146761894226e-01
    z[3,1,0]  R900      -1.6419696807861328e-01
    z[3,1,0]  R901      -3.8544863462448120e-01
    z[3,1,0]  R902      -0.623007595539093
    z[3,1,0]  R903      -7.5105018913745880e-02
    z[3,1,0]  R904      -2.9878070577979088e-02
    z[3,1,0]  R905      -1.8481391668319702e-01
    z[3,1,0]  R906      -3.4994819760322571e-01
    z[3,1,0]  R907      -1.7089748382568359e-01
    z[3,1,0]  R908      -2.3380618542432785e-02
    z[3,1,0]  R909      3.0983725190162659e-01
    z[3,1,0]  R910      3.7620510905981064e-02
    z[3,1,0]  R911      -1.0741529613733292e-01
    z[3,1,0]  R912      1.2551528215408325e-01
    z[3,1,0]  R913      -2.1165297925472260e-01
    z[3,1,0]  R914      1.9318635761737823e-01
    z[3,1,0]  R915      -2.2988358512520790e-02
    z[3,1,0]  R916      2.6377752423286438e-01
    z[3,1,0]  R917      3.2029467821121216e-01
    z[3,1,0]  R918      -0.270953506231308
    z[3,1,0]  R919      -9.1509437561035156e-01
    z[3,1,0]  R920      -8.7610584497451782e-01
    z[3,1,0]  R921      -8.2335573434829712e-01
    z[3,1,0]  R922      -7.5604027509689331e-01
    z[3,1,0]  R923      -0.256926566362381
    z[3,1,0]  R924      3.0761915445327759e-01
    z[3,1,0]  R925      2.4368667975068092e-02
    z[3,1,0]  R926      -1.7191019654273987e-01
    z[3,1,0]  R927      3.1932809948921204e-01
    z[3,1,0]  R928      -0.70970618724823
    z[3,1,0]  R929      -4.7882348299026489e-02
    z[3,1,0]  R930      -4.7134313732385635e-02
    z[3,1,0]  R931      -4.3973377346992493e-01
    z[3,1,0]  R932      -4.6908619999885559e-01
    z[3,1,0]  R933      -4.6749472618103027e-01
    z[3,1,0]  R934      -5.9391325712203979e-01
    z[3,1,0]  R935      -0.438795268535614
    z[3,1,0]  R936      6.8099820613861084e-01
    z[3,1,0]  R937      6.4077001810073853e-01
    z[3,1,0]  R938      7.4334591627120972e-01
    z[3,1,0]  R939      5.5163621902465820e-01
    z[3,1,0]  R940      6.8956816196441650e-01
    z[3,1,0]  R941      -4.7952553629875183e-01
    z[3,1,0]  R942      -0.32700115442276
    z[3,1,0]  R943      -2.9756346344947815e-01
    z[3,1,0]  R944      -3.4690535068511963e-01
    z[3,1,0]  R945      -2.8038537502288818e-01
    z[3,1,0]  R946      -4.4638866186141968e-01
    z[3,1,0]  R947      -4.1364064812660217e-01
    z[3,1,0]  R948      -0.2532939016819
    z[3,1,0]  R949      -2.7952659130096436e-01
    z[3,1,0]  R950      -2.2245080769062042e-01
    z[3,1,0]  R951      -3.7676227092742920e-01
    z[3,1,0]  R952      0.478341281414032
    z[3,1,0]  R953      0.676973283290863
    z[3,1,0]  R954      4.4680270552635193e-01
    z[3,1,0]  R955      6.4664644002914429e-01
    z[3,1,0]  R956      5.7975602149963379e-01
    z[3,1,0]  R957      0.586368203163147
    z[3,1,0]  R958      6.0991507768630981e-01
    z[3,1,0]  R959      0.332193523645401
    z[3,1,0]  R960      7.2198235988616943e-01
    z[3,1,0]  R961      1.0257675498723984e-01
    z[3,1,0]  R962      -2.2947709262371063e-01
    z[3,1,0]  R963      -3.6362317204475403e-01
    z[3,1,0]  R964      5.3756457567214966e-01
    z[3,1,0]  R965      -2.9505431652069092e-02
    z[3,1,0]  R966      4.5382156968116760e-01
    z[3,1,0]  R967      2.6670229434967041e-01
    z[3,1,0]  R968      7.3435842990875244e-01
    z[3,1,0]  R969      4.9293899536132812e-01
    z[3,1,0]  R970      6.9068127870559692e-01
    z[3,1,0]  R971      -5.4931193590164185e-01
    z[3,1,0]  R972      -3.8923683762550354e-01
    z[3,1,0]  R973      4.1136839985847473e-01
    z[3,1,0]  R974      -1.7706157639622688e-02
    z[3,1,0]  R975      1.2964147329330444e-01
    z[3,1,0]  R976      2.6234817504882812e-01
    z[3,1,0]  R977      4.7098869085311890e-01
    z[3,1,0]  R978      7.0320379734039307e-01
    z[3,1,0]  R979      4.5568275451660156e-01
    z[3,1,0]  R980      2.2768758237361908e-01
    z[3,1,0]  R981      -7.3867177963256836e-01
    z[3,1,0]  R982      -2.5451815128326416e-01
    z[3,1,0]  R983      -0.0896846279501915
    z[3,1,0]  R984      0.797221302986145
    z[3,1,0]  R985      -4.8959842324256897e-01
    z[3,1,0]  R986      -6.7485976219177246e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R881      -1
    z[3,1,1]  R882      1
    z[3,1,1]  R893      -1.7388090491294861e-02
    z[3,1,1]  R894      -3.0639293789863586e-01
    z[3,1,1]  R895      -2.3125894367694855e-01
    z[3,1,1]  R896      -2.1502365171909332e-01
    z[3,1,1]  R897      1.0191959142684937e-01
    z[3,1,1]  R898      3.8500636816024780e-01
    z[3,1,1]  R899      2.3486943542957306e-01
    z[3,1,1]  R900      0.492320716381073
    z[3,1,1]  R901      -1.7778109014034271e-01
    z[3,1,1]  R902      -3.3669683337211609e-01
    z[3,1,1]  R903      -0.718687117099762
    z[3,1,1]  R904      -2.8747299313545227e-01
    z[3,1,1]  R905      -7.5129759311676025e-01
    z[3,1,1]  R906      -7.0751869678497314e-01
    z[3,1,1]  R907      -6.9615596532821655e-01
    z[3,1,1]  R908      -6.8274384737014771e-01
    z[3,1,1]  R909      -4.2941969633102417e-01
    z[3,1,1]  R910      5.7843305170536041e-02
    z[3,1,1]  R911      0.267410010099411
    z[3,1,1]  R912      2.2924886643886566e-01
    z[3,1,1]  R913      -8.6893546581268311e-01
    z[3,1,1]  R914      -6.7153471708297729e-01
    z[3,1,1]  R915      0.466298371553421
    z[3,1,1]  R916      8.9918178319931030e-01
    z[3,1,1]  R917      2.1315771341323853e-01
    z[3,1,1]  R918      6.0820490121841431e-01
    z[3,1,1]  R919      1.7647847533226013e-01
    z[3,1,1]  R920      -3.6327905952930450e-02
    z[3,1,1]  R921      4.0621817111968994e-02
    z[3,1,1]  R922      2.8182867169380188e-01
    z[3,1,1]  R923      3.1204733252525330e-01
    z[3,1,1]  R924      -6.9999796152114868e-01
    z[3,1,1]  R925      6.9709378480911255e-01
    z[3,1,1]  R926      4.5377466082572937e-01
    z[3,1,1]  R927      0.0917489156126976
    z[3,1,1]  R928      4.4188103079795837e-01
    z[3,1,1]  R929      4.5328539609909058e-01
    z[3,1,1]  R930      4.9532383680343628e-01
    z[3,1,1]  R931      7.0582723617553711e-01
    z[3,1,1]  R932      7.4835884571075439e-01
    z[3,1,1]  R933      6.4602726697921753e-01
    z[3,1,1]  R934      4.0355780720710754e-01
    z[3,1,1]  R935      2.8929588198661804e-01
    z[3,1,1]  R936      -1.5599606931209564e-01
    z[3,1,1]  R937      -2.5938186049461365e-01
    z[3,1,1]  R938      -2.8838065266609192e-01
    z[3,1,1]  R939      -2.6488536596298218e-01
    z[3,1,1]  R940      -1.8207627534866333e-01
    z[3,1,1]  R941      -0.722950279712677
    z[3,1,1]  R942      -7.9297041893005371e-01
    z[3,1,1]  R943      -8.1031274795532227e-01
    z[3,1,1]  R944      -7.6446080207824707e-01
    z[3,1,1]  R945      -0.84675532579422
    z[3,1,1]  R946      -6.3792812824249268e-01
    z[3,1,1]  R947      -6.0679459571838379e-01
    z[3,1,1]  R948      -6.9677561521530151e-01
    z[3,1,1]  R949      -6.4049822092056274e-01
    z[3,1,1]  R950      -7.5996285676956177e-01
    z[3,1,1]  R951      3.1034144759178162e-01
    z[3,1,1]  R952      6.3583391904830933e-01
    z[3,1,1]  R953      0.596767783164978
    z[3,1,1]  R954      7.8609246015548706e-01
    z[3,1,1]  R955      5.6476938724517822e-01
    z[3,1,1]  R956      4.8868107795715332e-01
    z[3,1,1]  R957      3.9729556441307068e-01
    z[3,1,1]  R958      6.6568471491336823e-02
    z[3,1,1]  R959      -1.3944588601589203e-02
    z[3,1,1]  R960      1.3699467480182648e-01
    z[3,1,1]  R961      -7.8468644618988037e-01
    z[3,1,1]  R962      3.0972850322723389e-01
    z[3,1,1]  R963      2.8695744276046753e-01
    z[3,1,1]  R964      1.9082698225975037e-01
    z[3,1,1]  R965      4.2503336071968079e-01
    z[3,1,1]  R966      -9.7298972308635712e-02
    z[3,1,1]  R967      -1.1420476436614990e-01
    z[3,1,1]  R968      1.7754136025905609e-01
    z[3,1,1]  R969      -2.3391132056713104e-01
    z[3,1,1]  R970      2.2367011010646820e-01
    z[3,1,1]  R971      2.0922964811325073e-01
    z[3,1,1]  R972      3.7760722637176514e-01
    z[3,1,1]  R973      -3.3757331967353821e-01
    z[3,1,1]  R974      5.3565579652786255e-01
    z[3,1,1]  R975      5.6941163539886475e-01
    z[3,1,1]  R976      8.3352994918823242e-01
    z[3,1,1]  R977      3.5133186727762222e-02
    z[3,1,1]  R978      7.6741680502891541e-02
    z[3,1,1]  R979      -2.1169431507587433e-02
    z[3,1,1]  R980      -1.0548040270805359e-01
    z[3,1,1]  R981      3.7100705504417419e-01
    z[3,1,1]  R982      6.1308199167251587e-01
    z[3,1,1]  R983      3.0658674240112305e-01
    z[3,1,1]  R984      2.2164407372474670e-01
    z[3,1,1]  R985      7.7359803020954132e-02
    z[3,1,1]  R986      1.0380051285028458e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R883      -1
    z[3,1,2]  R884      1
    z[3,1,2]  R893      1.0951692610979080e-01
    z[3,1,2]  R894      2.0774249732494354e-01
    z[3,1,2]  R895      1.5276065468788147e-01
    z[3,1,2]  R896      -5.8153885602951050e-01
    z[3,1,2]  R897      -7.0255053043365479e-01
    z[3,1,2]  R898      -7.0949810743331909e-01
    z[3,1,2]  R899      -7.4259728193283081e-01
    z[3,1,2]  R900      -8.2217389345169067e-01
    z[3,1,2]  R901      -8.1349629163742065e-01
    z[3,1,2]  R902      -3.9143708348274231e-01
    z[3,1,2]  R903      -6.0328418016433716e-01
    z[3,1,2]  R904      0.596624493598938
    z[3,1,2]  R905      -3.7396702170372009e-01
    z[3,1,2]  R906      -1.9479447603225708e-01
    z[3,1,2]  R907      -3.1045052409172058e-01
    z[3,1,2]  R908      -2.8534984588623047e-01
    z[3,1,2]  R909      -7.6795852184295654e-01
    z[3,1,2]  R910      -7.4868999421596527e-02
    z[3,1,2]  R911      2.5967352092266083e-02
    z[3,1,2]  R912      -3.5041561722755432e-01
    z[3,1,2]  R913      1.6584739089012146e-01
    z[3,1,2]  R914      -1.2550047039985657e-01
    z[3,1,2]  R915      5.0444994121789932e-02
    z[3,1,2]  R916      1.2987813353538513e-01
    z[3,1,2]  R917      -2.4401377141475677e-01
    z[3,1,2]  R918      6.6568940877914429e-01
    z[3,1,2]  R919      3.2851299643516541e-01
    z[3,1,2]  R920      1.8951553106307983e-01
    z[3,1,2]  R921      2.3056674003601074e-01
    z[3,1,2]  R922      -1.7282633483409882e-01
    z[3,1,2]  R923      8.4044122695922852e-01
    z[3,1,2]  R924      -4.4037258625030518e-01
    z[3,1,2]  R925      -1.7382787168025970e-01
    z[3,1,2]  R926      -2.4577982723712921e-01
    z[3,1,2]  R927      -4.2546781897544861e-01
    z[3,1,2]  R928      1.5264713205397129e-02
    z[3,1,2]  R929      -2.8176712989807129e-01
    z[3,1,2]  R930      2.4739317595958710e-03
    z[3,1,2]  R931      -0.229117289185524
    z[3,1,2]  R932      -2.6490619778633118e-01
    z[3,1,2]  R933      -4.8827031254768372e-01
    z[3,1,2]  R934      -5.6621521711349487e-01
    z[3,1,2]  R935      -1.5989576280117035e-01
    z[3,1,2]  R936      2.4967324733734131e-01
    z[3,1,2]  R937      3.6085703969001770e-01
    z[3,1,2]  R938      5.2071553468704224e-01
    z[3,1,2]  R939      1.2483359873294830e-01
    z[3,1,2]  R940      5.2010452747344971e-01
    z[3,1,2]  R941      -9.7651155665516853e-03
    z[3,1,2]  R942      -3.0187508463859558e-01
    z[3,1,2]  R943      -2.5007483363151550e-01
    z[3,1,2]  R944      -1.1067414283752441e-01
    z[3,1,2]  R945      -1.7438901960849762e-01
    z[3,1,2]  R946      -1.1787618696689606e-01
    z[3,1,2]  R947      4.9787878990173340e-02
    z[3,1,2]  R948      -2.6266448199748993e-02
    z[3,1,2]  R949      -0.0127011863514781
    z[3,1,2]  R950      1.0693140327930450e-01
    z[3,1,2]  R951      -2.6498275995254517e-01
    z[3,1,2]  R952      -3.5252094268798828e-01
    z[3,1,2]  R953      -2.2569186985492706e-01
    z[3,1,2]  R954      0.0648149698972702
    z[3,1,2]  R955      0.0210171639919281
    z[3,1,2]  R956      1.3366617262363434e-02
    z[3,1,2]  R957      -1.1218158155679703e-01
    z[3,1,2]  R958      9.2862747609615326e-02
    z[3,1,2]  R959      6.3014000654220581e-01
    z[3,1,2]  R960      2.3018909990787506e-01
    z[3,1,2]  R961      6.6623359918594360e-02
    z[3,1,2]  R962      1.4183364808559418e-01
    z[3,1,2]  R963      -2.5261448696255684e-02
    z[3,1,2]  R964      -0.235975444316864
    z[3,1,2]  R965      -8.3938531577587128e-02
    z[3,1,2]  R966      9.7031831741333008e-02
    z[3,1,2]  R967      5.5120289325714111e-01
    z[3,1,2]  R968      3.6256012320518494e-01
    z[3,1,2]  R969      0.472822368144989
    z[3,1,2]  R970      0.268179327249527
    z[3,1,2]  R971      -2.5414398312568665e-01
    z[3,1,2]  R972      1.1739699542522430e-01
    z[3,1,2]  R973      1.4202952384948730e-01
    z[3,1,2]  R974      -1.2348987907171249e-01
    z[3,1,2]  R975      -3.3790859580039978e-01
    z[3,1,2]  R976      -1.2669317424297333e-01
    z[3,1,2]  R977      -6.8267039954662323e-02
    z[3,1,2]  R978      2.3709677159786224e-01
    z[3,1,2]  R979      -3.4693825244903564e-01
    z[3,1,2]  R980      6.3916486501693726e-01
    z[3,1,2]  R981      -3.9355117082595825e-01
    z[3,1,2]  R982      -1.1480126529932022e-02
    z[3,1,2]  R983      1.7177364230155945e-01
    z[3,1,2]  R984      3.8163551688194275e-01
    z[3,1,2]  R985      3.4038397669792175e-01
    z[3,1,2]  R986      0.566510021686554
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R885      -1
    z[3,1,3]  R886      1
    z[3,1,3]  R893      7.1820162236690521e-02
    z[3,1,3]  R894      -6.9875025749206543e-01
    z[3,1,3]  R895      -3.1949985027313232e-01
    z[3,1,3]  R896      -2.5845754891633987e-02
    z[3,1,3]  R897      1.2670738995075226e-01
    z[3,1,3]  R898      8.2595452666282654e-02
    z[3,1,3]  R899      7.8051716089248657e-02
    z[3,1,3]  R900      4.2187362909317017e-02
    z[3,1,3]  R901      -1.5487730503082275e-01
    z[3,1,3]  R902      -9.0489059686660767e-02
    z[3,1,3]  R903      2.5117591023445129e-01
    z[3,1,3]  R904      -3.9477947354316711e-01
    z[3,1,3]  R905      2.0609444379806519e-01
    z[3,1,3]  R906      0.452725350856781
    z[3,1,3]  R907      4.5630702376365662e-01
    z[3,1,3]  R908      6.1334747076034546e-01
    z[3,1,3]  R909      1.7385989427566528e-01
    z[3,1,3]  R910      -5.1712733507156372e-01
    z[3,1,3]  R911      -4.2898854613304138e-01
    z[3,1,3]  R912      -2.4088618159294128e-01
    z[3,1,3]  R913      2.0723941922187805e-01
    z[3,1,3]  R914      -2.8265175223350525e-01
    z[3,1,3]  R915      -8.5531359910964966e-01
    z[3,1,3]  R916      9.9095046520233154e-02
    z[3,1,3]  R917      -7.8946202993392944e-01
    z[3,1,3]  R918      -5.9033695608377457e-02
    z[3,1,3]  R919      3.0602285638451576e-02
    z[3,1,3]  R920      2.0207408070564270e-01
    z[3,1,3]  R921      4.4499572366476059e-02
    z[3,1,3]  R922      5.3708565235137939e-01
    z[3,1,3]  R923      -1.2076288461685181e-01
    z[3,1,3]  R924      -7.4476338922977448e-02
    z[3,1,3]  R925      -6.3618320226669312e-01
    z[3,1,3]  R926      -6.0746544599533081e-01
    z[3,1,3]  R927      -7.5059723854064941e-01
    z[3,1,3]  R928      4.6818497776985168e-01
    z[3,1,3]  R929      6.4250385761260986e-01
    z[3,1,3]  R930      7.8726017475128174e-01
    z[3,1,3]  R931      -2.9019543528556824e-01
    z[3,1,3]  R932      5.7496611028909683e-02
    z[3,1,3]  R933      -7.3940992355346680e-02
    z[3,1,3]  R934      2.4332102388143539e-02
    z[3,1,3]  R935      -8.6339443922042847e-02
    z[3,1,3]  R936      0.651769757270813
    z[3,1,3]  R937      5.7279855012893677e-01
    z[3,1,3]  R938      2.7020815014839172e-01
    z[3,1,3]  R939      6.3380479812622070e-01
    z[3,1,3]  R940      3.6046424508094788e-01
    z[3,1,3]  R941      -0.477079302072525
    z[3,1,3]  R942      6.7505910992622375e-02
    z[3,1,3]  R943      2.5140070915222168e-01
    z[3,1,3]  R944      -1.8602685630321503e-01
    z[3,1,3]  R945      -2.1406927704811096e-01
    z[3,1,3]  R946      -2.8279563784599304e-01
    z[3,1,3]  R947      -0.0956747829914093
    z[3,1,3]  R948      -2.6482401415705681e-02
    z[3,1,3]  R949      -1.0606414824724197e-01
    z[3,1,3]  R950      1.4834043383598328e-01
    z[3,1,3]  R951      -3.7804111838340759e-01
    z[3,1,3]  R952      3.8450878858566284e-01
    z[3,1,3]  R953      0.0953054204583168
    z[3,1,3]  R954      1.9266439601778984e-02
    z[3,1,3]  R955      -3.2006785273551941e-01
    z[3,1,3]  R956      -3.1716409325599670e-01
    z[3,1,3]  R957      -2.4189472198486328e-01
    z[3,1,3]  R958      -4.9281543493270874e-01
    z[3,1,3]  R959      -4.6805629134178162e-01
    z[3,1,3]  R960      1.9967010244727135e-02
    z[3,1,3]  R961      -2.6093193888664246e-01
    z[3,1,3]  R962      -6.8618077039718628e-01
    z[3,1,3]  R963      -1.8147185444831848e-01
    z[3,1,3]  R964      -4.9503338336944580e-01
    z[3,1,3]  R965      -7.3967504501342773e-01
    z[3,1,3]  R966      5.1183837652206421e-01
    z[3,1,3]  R967      -4.9407193064689636e-01
    z[3,1,3]  R968      -1.5420243144035339e-01
    z[3,1,3]  R969      -5.0213855504989624e-01
    z[3,1,3]  R970      3.4624069929122925e-02
    z[3,1,3]  R971      -0.486905038356781
    z[3,1,3]  R972      -5.1858031749725342e-01
    z[3,1,3]  R973      7.9279178380966187e-01
    z[3,1,3]  R974      -6.5510874986648560e-01
    z[3,1,3]  R975      2.9931154847145081e-01
    z[3,1,3]  R976      2.2582674026489258e-01
    z[3,1,3]  R977      -0.532409131526947
    z[3,1,3]  R978      1.1730780452489853e-01
    z[3,1,3]  R979      -2.9757568240165710e-01
    z[3,1,3]  R980      -6.3120013475418091e-01
    z[3,1,3]  R981      -2.8670126199722290e-01
    z[3,1,3]  R982      -4.9086907505989075e-01
    z[3,1,3]  R983      -9.2673414945602417e-01
    z[3,1,3]  R984      3.7704259157180786e-02
    z[3,1,3]  R985      5.6681799888610840e-01
    z[3,1,3]  R986      2.9143935441970825e-01
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R887      -1
    z[3,1,4]  R888      1
    z[3,1,4]  R893      1.5497450530529022e-01
    z[3,1,4]  R894      4.9810070544481277e-02
    z[3,1,4]  R895      -8.2780605554580688e-01
    z[3,1,4]  R896      -2.7678960561752319e-01
    z[3,1,4]  R897      -5.9021586179733276e-01
    z[3,1,4]  R898      -3.2592964172363281e-01
    z[3,1,4]  R899      -3.5340425372123718e-01
    z[3,1,4]  R900      -2.1101097762584686e-01
    z[3,1,4]  R901      -8.1960320472717285e-02
    z[3,1,4]  R902      -5.4664772748947144e-01
    z[3,1,4]  R903      1.3832703232765198e-01
    z[3,1,4]  R904      -1.6693617403507233e-01
    z[3,1,4]  R905      8.9001677930355072e-02
    z[3,1,4]  R906      -1.7687901854515076e-01
    z[3,1,4]  R907      -1.4729164540767670e-01
    z[3,1,4]  R908      -1.5474909543991089e-01
    z[3,1,4]  R909      -1.9208058714866638e-01
    z[3,1,4]  R910      7.8312915563583374e-01
    z[3,1,4]  R911      6.8898481130599976e-01
    z[3,1,4]  R912      6.6069936752319336e-01
    z[3,1,4]  R913      -2.2109439969062805e-01
    z[3,1,4]  R914      4.3592989444732666e-01
    z[3,1,4]  R915      -1.4450874924659729e-01
    z[3,1,4]  R916      0.0320991687476635
    z[3,1,4]  R917      -4.8460375517606735e-02
    z[3,1,4]  R918      2.4460107088088989e-01
    z[3,1,4]  R919      9.5805555582046509e-02
    z[3,1,4]  R920      1.2552116811275482e-01
    z[3,1,4]  R921      4.9232020974159241e-01
    z[3,1,4]  R922      1.6777239739894867e-01
    z[3,1,4]  R923      1.8751016259193420e-01
    z[3,1,4]  R924      -1.9941788911819458e-01
    z[3,1,4]  R925      -3.2221134752035141e-02
    z[3,1,4]  R926      -0.0489906370639801
    z[3,1,4]  R927      -2.7909772470593452e-02
    z[3,1,4]  R928      -2.1687658131122589e-01
    z[3,1,4]  R929      -5.3138142824172974e-01
    z[3,1,4]  R930      -1.9959336519241333e-01
    z[3,1,4]  R931      3.8261204957962036e-01
    z[3,1,4]  R932      2.7791008353233337e-01
    z[3,1,4]  R933      -2.3422902822494507e-01
    z[3,1,4]  R934      1.0998079180717468e-01
    z[3,1,4]  R935      2.4276715517044067e-01
    z[3,1,4]  R936      -1.1566183716058731e-01
    z[3,1,4]  R937      2.1666100621223450e-01
    z[3,1,4]  R938      1.3682533800601959e-01
    z[3,1,4]  R939      1.9600607454776764e-01
    z[3,1,4]  R940      1.7497076094150543e-01
    z[3,1,4]  R941      1.1299677938222885e-01
    z[3,1,4]  R942      -2.8302571736276150e-03
    z[3,1,4]  R943      0.0761076956987381
    z[3,1,4]  R944      1.3485226035118103e-01
    z[3,1,4]  R945      -2.3401015996932983e-01
    z[3,1,4]  R946      -2.5529021024703979e-01
    z[3,1,4]  R947      0.527223527431488
    z[3,1,4]  R948      0.502944827079773
    z[3,1,4]  R949      -4.3249884247779846e-01
    z[3,1,4]  R950      -2.5453118607401848e-02
    z[3,1,4]  R951      -2.4937191605567932e-01
    z[3,1,4]  R952      2.9429266229271889e-02
    z[3,1,4]  R953      -3.4854507446289062e-01
    z[3,1,4]  R954      -2.5800922513008118e-01
    z[3,1,4]  R955      -3.9282381534576416e-01
    z[3,1,4]  R956      -2.5062489509582520e-01
    z[3,1,4]  R957      -1.2206542491912842e-01
    z[3,1,4]  R958      5.1436161994934082e-01
    z[3,1,4]  R959      4.3308654427528381e-01
    z[3,1,4]  R960      -3.2065966725349426e-01
    z[3,1,4]  R961      -5.4726237058639526e-01
    z[3,1,4]  R962      -6.7449599504470825e-02
    z[3,1,4]  R963      2.1403318643569946e-01
    z[3,1,4]  R964      -6.9757483899593353e-02
    z[3,1,4]  R965      -3.9082175493240356e-01
    z[3,1,4]  R966      -2.1698732674121857e-01
    z[3,1,4]  R967      0.505648136138916
    z[3,1,4]  R968      -3.4428441524505615e-01
    z[3,1,4]  R969      1.7090511322021484e-01
    z[3,1,4]  R970      -4.8727640509605408e-01
    z[3,1,4]  R971      -1.2089670449495316e-01
    z[3,1,4]  R972      0.221050426363945
    z[3,1,4]  R973      2.1512087434530258e-02
    z[3,1,4]  R974      -3.7427493929862976e-01
    z[3,1,4]  R975      2.4408282712101936e-02
    z[3,1,4]  R976      -3.5382375121116638e-01
    z[3,1,4]  R977      6.8781822919845581e-01
    z[3,1,4]  R978      -4.4453686475753784e-01
    z[3,1,4]  R979      6.4020842313766479e-01
    z[3,1,4]  R980      4.1498217731714249e-02
    z[3,1,4]  R981      1.1063133925199509e-01
    z[3,1,4]  R982      -9.9658809602260590e-02
    z[3,1,4]  R983      -0.0842304676771164
    z[3,1,4]  R984      -2.4974401295185089e-01
    z[3,1,4]  R985      -3.1321346759796143e-01
    z[3,1,4]  R986      -1.9275777041912079e-01
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R889      -1
    z[3,1,5]  R890      1
    z[3,1,5]  R893      -5.8452707529067993e-01
    z[3,1,5]  R894      -1.2743914127349854e-01
    z[3,1,5]  R895      1.7452562227845192e-02
    z[3,1,5]  R896      8.7726123631000519e-02
    z[3,1,5]  R897      -1.3058429956436157e-01
    z[3,1,5]  R898      -7.9703167080879211e-02
    z[3,1,5]  R899      -3.2697755098342896e-01
    z[3,1,5]  R900      2.0583800971508026e-02
    z[3,1,5]  R901      4.2072642594575882e-02
    z[3,1,5]  R902      -1.1930692009627819e-02
    z[3,1,5]  R903      1.0244762152433395e-01
    z[3,1,5]  R904      -2.3369353264570236e-02
    z[3,1,5]  R905      -1.6928309202194214e-01
    z[3,1,5]  R906      -2.7417975664138794e-01
    z[3,1,5]  R907      3.0409688130021095e-02
    z[3,1,5]  R908      1.0035818442702293e-02
    z[3,1,5]  R909      2.0721469819545746e-01
    z[3,1,5]  R910      3.1202328205108643e-01
    z[3,1,5]  R911      2.7599191665649414e-01
    z[3,1,5]  R912      3.9503401517868042e-01
    z[3,1,5]  R913      -1.6550481319427490e-01
    z[3,1,5]  R914      3.0633789300918579e-01
    z[3,1,5]  R915      1.5955626964569092e-01
    z[3,1,5]  R916      2.4823763966560364e-01
    z[3,1,5]  R917      2.1159994602203369e-01
    z[3,1,5]  R918      -2.1541567146778107e-01
    z[3,1,5]  R919      -9.5731422305107117e-02
    z[3,1,5]  R920      -0.0866822898387909
    z[3,1,5]  R921      -7.0915900170803070e-02
    z[3,1,5]  R922      -2.4924285709857941e-02
    z[3,1,5]  R923      -8.8141247630119324e-02
    z[3,1,5]  R924      2.8659364581108093e-01
    z[3,1,5]  R925      0.0913451761007309
    z[3,1,5]  R926      -1.2837243080139160e-01
    z[3,1,5]  R927      3.7850487232208252e-01
    z[3,1,5]  R928      -8.4200866520404816e-02
    z[3,1,5]  R929      0.0953843742609024
    z[3,1,5]  R930      2.8075750917196274e-02
    z[3,1,5]  R931      -1.3069508969783783e-01
    z[3,1,5]  R932      4.7280009835958481e-02
    z[3,1,5]  R933      -2.4256812036037445e-01
    z[3,1,5]  R934      1.0398554056882858e-01
    z[3,1,5]  R935      -0.625950813293457
    z[3,1,5]  R936      1.0464450716972351e-01
    z[3,1,5]  R937      -1.2760579586029053e-01
    z[3,1,5]  R938      2.7487901970744133e-02
    z[3,1,5]  R939      -1.0926242172718048e-01
    z[3,1,5]  R940      -9.2612817883491516e-02
    z[3,1,5]  R941      6.8953827023506165e-02
    z[3,1,5]  R942      -2.0019227266311646e-01
    z[3,1,5]  R943      -3.3036354184150696e-01
    z[3,1,5]  R944      -4.7876381874084473e-01
    z[3,1,5]  R945      5.3922671824693680e-02
    z[3,1,5]  R946      -0.264121949672699
    z[3,1,5]  R947      4.1039773821830750e-01
    z[3,1,5]  R948      1.3205060362815857e-01
    z[3,1,5]  R949      0.194817915558815
    z[3,1,5]  R950      1.7538410425186157e-01
    z[3,1,5]  R951      6.4642357826232910e-01
    z[3,1,5]  R952      -2.8103792667388916e-01
    z[3,1,5]  R953      7.0109167136251926e-03
    z[3,1,5]  R954      2.3674240708351135e-01
    z[3,1,5]  R955      7.5311444699764252e-02
    z[3,1,5]  R956      -2.9498040676116943e-02
    z[3,1,5]  R957      -6.6754192113876343e-02
    z[3,1,5]  R958      3.2755106687545776e-01
    z[3,1,5]  R959      2.3541361093521118e-01
    z[3,1,5]  R960      -5.1162582635879517e-01
    z[3,1,5]  R961      -2.5592150166630745e-02
    z[3,1,5]  R962      -3.0405440926551819e-01
    z[3,1,5]  R963      8.3945882320404053e-01
    z[3,1,5]  R964      -6.0283303260803223e-01
    z[3,1,5]  R965      -5.3239960223436356e-02
    z[3,1,5]  R966      -6.1507624387741089e-01
    z[3,1,5]  R967      -3.1253370642662048e-01
    z[3,1,5]  R968      -3.9272478222846985e-01
    z[3,1,5]  R969      -3.5361361503601074e-01
    z[3,1,5]  R970      -3.8169774413108826e-01
    z[3,1,5]  R971      5.6845819950103760e-01
    z[3,1,5]  R972      5.1635706424713135e-01
    z[3,1,5]  R973      -1.0229671746492386e-01
    z[3,1,5]  R974      -5.7824570685625076e-02
    z[3,1,5]  R975      -2.8982567787170410e-01
    z[3,1,5]  R976      1.9826823472976685e-01
    z[3,1,5]  R977      9.6248477697372437e-02
    z[3,1,5]  R978      -4.8029392957687378e-01
    z[3,1,5]  R979      4.1570165753364563e-01
    z[3,1,5]  R980      -3.5506728291511536e-01
    z[3,1,5]  R981      2.5812932848930359e-01
    z[3,1,5]  R982      -2.9577055573463440e-01
    z[3,1,5]  R983      1.9396256655454636e-02
    z[3,1,5]  R984      -3.2449653744697571e-01
    z[3,1,5]  R985      4.2761421203613281e-01
    z[3,1,5]  R986      -1.7201507091522217e-01
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R891      -1
    z[3,1,6]  R892      1
    z[3,1,6]  R893      -7.7593624591827393e-02
    z[3,1,6]  R894      5.8776468038558960e-01
    z[3,1,6]  R895      2.1646265685558319e-01
    z[3,1,6]  R896      2.5525358319282532e-01
    z[3,1,6]  R897      -5.6083530187606812e-02
    z[3,1,6]  R898      -3.8818728923797607e-01
    z[3,1,6]  R899      -1.5079762041568756e-01
    z[3,1,6]  R900      -8.9222088456153870e-02
    z[3,1,6]  R901      -3.5436192154884338e-01
    z[3,1,6]  R902      -1.9524197280406952e-01
    z[3,1,6]  R903      -1.4552305638790131e-01
    z[3,1,6]  R904      -6.1338496208190918e-01
    z[3,1,6]  R905      -4.2719018459320068e-01
    z[3,1,6]  R906      -1.6609518229961395e-01
    z[3,1,6]  R907      -3.9867994189262390e-01
    z[3,1,6]  R908      2.2725857794284821e-01
    z[3,1,6]  R909      1.4063820242881775e-01
    z[3,1,6]  R910      1.0753098130226135e-01
    z[3,1,6]  R911      4.2588347196578979e-01
    z[3,1,6]  R912      3.9786690473556519e-01
    z[3,1,6]  R913      -2.3114077746868134e-01
    z[3,1,6]  R914      -3.6359328031539917e-01
    z[3,1,6]  R915      -3.9879478514194489e-02
    z[3,1,6]  R916      1.8042442202568054e-01
    z[3,1,6]  R917      -3.4936955571174622e-01
    z[3,1,6]  R918      6.1725240200757980e-02
    z[3,1,6]  R919      -6.5246790647506714e-02
    z[3,1,6]  R920      -3.6207631230354309e-01
    z[3,1,6]  R921      -1.3373765349388123e-01
    z[3,1,6]  R922      4.3322015553712845e-02
    z[3,1,6]  R923      -2.6974296569824219e-01
    z[3,1,6]  R924      -3.0658626556396484e-01
    z[3,1,6]  R925      -2.6294332742691040e-01
    z[3,1,6]  R926      5.6234681606292725e-01
    z[3,1,6]  R927      3.3876877278089523e-02
    z[3,1,6]  R928      1.6584002971649170e-01
    z[3,1,6]  R929      9.2581234872341156e-02
    z[3,1,6]  R930      -3.0335170030593872e-01
    z[3,1,6]  R931      9.0889401733875275e-02
    z[3,1,6]  R932      -2.5877895951271057e-01
    z[3,1,6]  R933      -8.0745331943035126e-02
    z[3,1,6]  R934      0.374576598405838
    z[3,1,6]  R935      -4.8989301919937134e-01
    z[3,1,6]  R936      2.0928401499986649e-02
    z[3,1,6]  R937      -2.4365289136767387e-02
    z[3,1,6]  R938      2.5289552286267281e-02
    z[3,1,6]  R939      3.9734715223312378e-01
    z[3,1,6]  R940      -2.2739601135253906e-01
    z[3,1,6]  R941      -0.0466383658349514
    z[3,1,6]  R942      3.5846567153930664e-01
    z[3,1,6]  R943      1.1906799674034119e-01
    z[3,1,6]  R944      3.1650140881538391e-02
    z[3,1,6]  R945      2.6548784971237183e-01
    z[3,1,6]  R946      -0.406181275844574
    z[3,1,6]  R947      5.1750767976045609e-02
    z[3,1,6]  R948      4.2256820201873779e-01
    z[3,1,6]  R949      -5.2460145950317383e-01
    z[3,1,6]  R950      -5.5509054660797119e-01
    z[3,1,6]  R951      2.6183506846427917e-01
    z[3,1,6]  R952      -1.2222281098365784e-01
    z[3,1,6]  R953      6.3423417508602142e-02
    z[3,1,6]  R954      2.3502789437770844e-01
    z[3,1,6]  R955      -0.00405834149569273
    z[3,1,6]  R956      -5.1050871610641479e-01
    z[3,1,6]  R957      0.63865065574646
    z[3,1,6]  R958      -1.4969493262469769e-02
    z[3,1,6]  R959      -1.7411597073078156e-01
    z[3,1,6]  R960      2.0495028793811798e-01
    z[3,1,6]  R961      3.2708659768104553e-02
    z[3,1,6]  R962      -5.1327300071716309e-01
    z[3,1,6]  R963      -3.6908425390720367e-02
    z[3,1,6]  R964      7.4787355959415436e-02
    z[3,1,6]  R965      3.2975021004676819e-01
    z[3,1,6]  R966      -2.9628169536590576e-01
    z[3,1,6]  R967      -1.2057397514581680e-01
    z[3,1,6]  R968      3.4699384123086929e-02
    z[3,1,6]  R969      0.268963485956192
    z[3,1,6]  R970      -1.2915319204330444e-01
    z[3,1,6]  R971      1.2269077450037003e-01
    z[3,1,6]  R972      -3.2819494605064392e-01
    z[3,1,6]  R973      -2.3916883766651154e-01
    z[3,1,6]  R974      3.5343545675277710e-01
    z[3,1,6]  R975      6.0876852273941040e-01
    z[3,1,6]  R976      6.9648787379264832e-02
    z[3,1,6]  R977      8.0360412597656250e-02
    z[3,1,6]  R978      -0.0366581492125988
    z[3,1,6]  R979      1.7690800130367279e-02
    z[3,1,6]  R980      4.7874860465526581e-02
    z[3,1,6]  R981      -2.7707897126674652e-02
    z[3,1,6]  R982      -4.6995177865028381e-01
    z[3,1,6]  R983      4.6346601098775864e-02
    z[3,1,6]  R984      2.3973459377884865e-02
    z[3,1,6]  R985      0.190284863114357
    z[3,1,6]  R986      2.4733503162860870e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R987      -1
    z[1,4,0]  R988      1
    z[1,4,0]  R1001     -4.3973377346992493e-01
    z[1,4,0]  R1002     -4.6908619999885559e-01
    z[1,4,0]  R1003     -4.6749472618103027e-01
    z[1,4,0]  R1004     -5.9391325712203979e-01
    z[1,4,0]  R1005     -0.438795268535614
    z[1,4,0]  R1006     6.8099820613861084e-01
    z[1,4,0]  R1007     6.4077001810073853e-01
    z[1,4,0]  R1008     7.4334591627120972e-01
    z[1,4,0]  R1009     5.5163621902465820e-01
    z[1,4,0]  R1010     6.8956816196441650e-01
    z[1,4,0]  R1011     -4.7952553629875183e-01
    z[1,4,0]  R1012     -0.32700115442276
    z[1,4,0]  R1013     -2.9756346344947815e-01
    z[1,4,0]  R1014     -3.4690535068511963e-01
    z[1,4,0]  R1015     -2.8038537502288818e-01
    z[1,4,0]  R1016     -4.4638866186141968e-01
    z[1,4,0]  R1017     -4.1364064812660217e-01
    z[1,4,0]  R1018     -0.2532939016819
    z[1,4,0]  R1019     -2.7952659130096436e-01
    z[1,4,0]  R1020     -2.2245080769062042e-01
    z[1,4,0]  R1021     -3.7676227092742920e-01
    z[1,4,0]  R1022     0.478341281414032
    z[1,4,0]  R1023     0.676973283290863
    z[1,4,0]  R1024     4.4680270552635193e-01
    z[1,4,0]  R1025     6.4664644002914429e-01
    z[1,4,0]  R1026     5.7975602149963379e-01
    z[1,4,0]  R1027     0.586368203163147
    z[1,4,0]  R1028     6.0991507768630981e-01
    z[1,4,0]  R1029     0.332193523645401
    z[1,4,0]  R1030     7.2198235988616943e-01
    z[1,4,0]  R1031     1.0257675498723984e-01
    z[1,4,0]  R1032     -2.2947709262371063e-01
    z[1,4,0]  R1033     -3.6362317204475403e-01
    z[1,4,0]  R1034     5.3756457567214966e-01
    z[1,4,0]  R1035     -2.9505431652069092e-02
    z[1,4,0]  R1036     4.5382156968116760e-01
    z[1,4,0]  R1037     2.6670229434967041e-01
    z[1,4,0]  R1038     7.3435842990875244e-01
    z[1,4,0]  R1039     4.9293899536132812e-01
    z[1,4,0]  R1040     6.9068127870559692e-01
    z[1,4,0]  R1041     -5.4931193590164185e-01
    z[1,4,0]  R1042     -3.8923683762550354e-01
    z[1,4,0]  R1043     4.1136839985847473e-01
    z[1,4,0]  R1044     -1.7706157639622688e-02
    z[1,4,0]  R1045     1.2964147329330444e-01
    z[1,4,0]  R1046     2.6234817504882812e-01
    z[1,4,0]  R1047     4.7098869085311890e-01
    z[1,4,0]  R1048     7.0320379734039307e-01
    z[1,4,0]  R1049     4.5568275451660156e-01
    z[1,4,0]  R1050     2.2768758237361908e-01
    z[1,4,0]  R1051     -7.3867177963256836e-01
    z[1,4,0]  R1052     -2.5451815128326416e-01
    z[1,4,0]  R1053     -0.0896846279501915
    z[1,4,0]  R1054     0.797221302986145
    z[1,4,0]  R1055     -4.8959842324256897e-01
    z[1,4,0]  R1056     -6.7485976219177246e-01
    z[1,4,0]  R1057     -4.5848438143730164e-01
    z[1,4,0]  R1058     -8.3330410718917847e-01
    z[1,4,0]  R1059     -3.8666200637817383e-01
    z[1,4,0]  R1060     -1.9907087087631226e-01
    z[1,4,0]  R1061     -4.4714611768722534e-01
    z[1,4,0]  R1062     1.3753038644790649e-01
    z[1,4,0]  R1063     3.7897473573684692e-01
    z[1,4,0]  R1064     6.2275505065917969e-01
    z[1,4,0]  R1065     6.7475163936614990e-01
    z[1,4,0]  R1066     5.7183831930160522e-01
    z[1,4,0]  R1067     7.6425084844231606e-03
    z[1,4,0]  R1068     1.7630884051322937e-01
    z[1,4,0]  R1069     5.3241960704326630e-02
    z[1,4,0]  R1070     -1.9779168069362640e-02
    z[1,4,0]  R1071     4.3267560005187988e-01
    z[1,4,0]  R1072     0.529718279838562
    z[1,4,0]  R1073     4.0345376729965210e-01
    z[1,4,0]  R1074     1.3535985350608826e-01
    z[1,4,0]  R1075     0.340166836977005
    z[1,4,0]  R1076     7.4405074119567871e-02
    z[1,4,0]  R1077     -1.9793882966041565e-01
    z[1,4,0]  R1078     -1.9118184223771095e-02
    z[1,4,0]  R1079     -2.7381128072738647e-01
    z[1,4,0]  R1080     -1.2327007949352264e-01
    z[1,4,0]  R1081     -3.6031207442283630e-01
    z[1,4,0]  R1082     0.573261022567749
    z[1,4,0]  R1083     8.0649471282958984e-01
    z[1,4,0]  R1084     3.2313579320907593e-01
    z[1,4,0]  R1085     6.6625958681106567e-01
    z[1,4,0]  R1086     1.7175951600074768e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R989      -1
    z[1,4,1]  R990      1
    z[1,4,1]  R1001     7.0582723617553711e-01
    z[1,4,1]  R1002     7.4835884571075439e-01
    z[1,4,1]  R1003     6.4602726697921753e-01
    z[1,4,1]  R1004     4.0355780720710754e-01
    z[1,4,1]  R1005     2.8929588198661804e-01
    z[1,4,1]  R1006     -1.5599606931209564e-01
    z[1,4,1]  R1007     -2.5938186049461365e-01
    z[1,4,1]  R1008     -2.8838065266609192e-01
    z[1,4,1]  R1009     -2.6488536596298218e-01
    z[1,4,1]  R1010     -1.8207627534866333e-01
    z[1,4,1]  R1011     -0.722950279712677
    z[1,4,1]  R1012     -7.9297041893005371e-01
    z[1,4,1]  R1013     -8.1031274795532227e-01
    z[1,4,1]  R1014     -7.6446080207824707e-01
    z[1,4,1]  R1015     -0.84675532579422
    z[1,4,1]  R1016     -6.3792812824249268e-01
    z[1,4,1]  R1017     -6.0679459571838379e-01
    z[1,4,1]  R1018     -6.9677561521530151e-01
    z[1,4,1]  R1019     -6.4049822092056274e-01
    z[1,4,1]  R1020     -7.5996285676956177e-01
    z[1,4,1]  R1021     3.1034144759178162e-01
    z[1,4,1]  R1022     6.3583391904830933e-01
    z[1,4,1]  R1023     0.596767783164978
    z[1,4,1]  R1024     7.8609246015548706e-01
    z[1,4,1]  R1025     5.6476938724517822e-01
    z[1,4,1]  R1026     4.8868107795715332e-01
    z[1,4,1]  R1027     3.9729556441307068e-01
    z[1,4,1]  R1028     6.6568471491336823e-02
    z[1,4,1]  R1029     -1.3944588601589203e-02
    z[1,4,1]  R1030     1.3699467480182648e-01
    z[1,4,1]  R1031     -7.8468644618988037e-01
    z[1,4,1]  R1032     3.0972850322723389e-01
    z[1,4,1]  R1033     2.8695744276046753e-01
    z[1,4,1]  R1034     1.9082698225975037e-01
    z[1,4,1]  R1035     4.2503336071968079e-01
    z[1,4,1]  R1036     -9.7298972308635712e-02
    z[1,4,1]  R1037     -1.1420476436614990e-01
    z[1,4,1]  R1038     1.7754136025905609e-01
    z[1,4,1]  R1039     -2.3391132056713104e-01
    z[1,4,1]  R1040     2.2367011010646820e-01
    z[1,4,1]  R1041     2.0922964811325073e-01
    z[1,4,1]  R1042     3.7760722637176514e-01
    z[1,4,1]  R1043     -3.3757331967353821e-01
    z[1,4,1]  R1044     5.3565579652786255e-01
    z[1,4,1]  R1045     5.6941163539886475e-01
    z[1,4,1]  R1046     8.3352994918823242e-01
    z[1,4,1]  R1047     3.5133186727762222e-02
    z[1,4,1]  R1048     7.6741680502891541e-02
    z[1,4,1]  R1049     -2.1169431507587433e-02
    z[1,4,1]  R1050     -1.0548040270805359e-01
    z[1,4,1]  R1051     3.7100705504417419e-01
    z[1,4,1]  R1052     6.1308199167251587e-01
    z[1,4,1]  R1053     3.0658674240112305e-01
    z[1,4,1]  R1054     2.2164407372474670e-01
    z[1,4,1]  R1055     7.7359803020954132e-02
    z[1,4,1]  R1056     1.0380051285028458e-01
    z[1,4,1]  R1057     5.8975040912628174e-01
    z[1,4,1]  R1058     -3.0199262499809265e-01
    z[1,4,1]  R1059     4.2183169722557068e-01
    z[1,4,1]  R1060     5.6619131565093994e-01
    z[1,4,1]  R1061     -0.187115877866745
    z[1,4,1]  R1062     -4.2707616090774536e-01
    z[1,4,1]  R1063     -0.341106116771698
    z[1,4,1]  R1064     -4.2832204699516296e-01
    z[1,4,1]  R1065     -0.382802814245224
    z[1,4,1]  R1066     -1.7089107632637024e-01
    z[1,4,1]  R1067     2.7923274040222168e-01
    z[1,4,1]  R1068     3.9075195789337158e-01
    z[1,4,1]  R1069     1.1419252306222916e-01
    z[1,4,1]  R1070     -8.4380501508712769e-01
    z[1,4,1]  R1071     7.0902770757675171e-01
    z[1,4,1]  R1072     -0.0634336769580841
    z[1,4,1]  R1073     -2.3554362356662750e-01
    z[1,4,1]  R1074     -2.5087940692901611e-01
    z[1,4,1]  R1075     6.6085916757583618e-01
    z[1,4,1]  R1076     -2.8801517561078072e-02
    z[1,4,1]  R1077     2.2513702511787415e-01
    z[1,4,1]  R1078     3.7106060981750488e-01
    z[1,4,1]  R1079     -8.3636589348316193e-02
    z[1,4,1]  R1080     -2.0240172743797302e-01
    z[1,4,1]  R1081     -2.1877533197402954e-01
    z[1,4,1]  R1082     -3.9691346883773804e-01
    z[1,4,1]  R1083     3.2836962491273880e-03
    z[1,4,1]  R1084     -1.2896490097045898e-01
    z[1,4,1]  R1085     -1.0529072955250740e-02
    z[1,4,1]  R1086     9.8508365452289581e-02
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R991      -1
    z[1,4,2]  R992      1
    z[1,4,2]  R1001     -0.229117289185524
    z[1,4,2]  R1002     -2.6490619778633118e-01
    z[1,4,2]  R1003     -4.8827031254768372e-01
    z[1,4,2]  R1004     -5.6621521711349487e-01
    z[1,4,2]  R1005     -1.5989576280117035e-01
    z[1,4,2]  R1006     2.4967324733734131e-01
    z[1,4,2]  R1007     3.6085703969001770e-01
    z[1,4,2]  R1008     5.2071553468704224e-01
    z[1,4,2]  R1009     1.2483359873294830e-01
    z[1,4,2]  R1010     5.2010452747344971e-01
    z[1,4,2]  R1011     -9.7651155665516853e-03
    z[1,4,2]  R1012     -3.0187508463859558e-01
    z[1,4,2]  R1013     -2.5007483363151550e-01
    z[1,4,2]  R1014     -1.1067414283752441e-01
    z[1,4,2]  R1015     -1.7438901960849762e-01
    z[1,4,2]  R1016     -1.1787618696689606e-01
    z[1,4,2]  R1017     4.9787878990173340e-02
    z[1,4,2]  R1018     -2.6266448199748993e-02
    z[1,4,2]  R1019     -0.0127011863514781
    z[1,4,2]  R1020     1.0693140327930450e-01
    z[1,4,2]  R1021     -2.6498275995254517e-01
    z[1,4,2]  R1022     -3.5252094268798828e-01
    z[1,4,2]  R1023     -2.2569186985492706e-01
    z[1,4,2]  R1024     0.0648149698972702
    z[1,4,2]  R1025     0.0210171639919281
    z[1,4,2]  R1026     1.3366617262363434e-02
    z[1,4,2]  R1027     -1.1218158155679703e-01
    z[1,4,2]  R1028     9.2862747609615326e-02
    z[1,4,2]  R1029     6.3014000654220581e-01
    z[1,4,2]  R1030     2.3018909990787506e-01
    z[1,4,2]  R1031     6.6623359918594360e-02
    z[1,4,2]  R1032     1.4183364808559418e-01
    z[1,4,2]  R1033     -2.5261448696255684e-02
    z[1,4,2]  R1034     -0.235975444316864
    z[1,4,2]  R1035     -8.3938531577587128e-02
    z[1,4,2]  R1036     9.7031831741333008e-02
    z[1,4,2]  R1037     5.5120289325714111e-01
    z[1,4,2]  R1038     3.6256012320518494e-01
    z[1,4,2]  R1039     0.472822368144989
    z[1,4,2]  R1040     0.268179327249527
    z[1,4,2]  R1041     -2.5414398312568665e-01
    z[1,4,2]  R1042     1.1739699542522430e-01
    z[1,4,2]  R1043     1.4202952384948730e-01
    z[1,4,2]  R1044     -1.2348987907171249e-01
    z[1,4,2]  R1045     -3.3790859580039978e-01
    z[1,4,2]  R1046     -1.2669317424297333e-01
    z[1,4,2]  R1047     -6.8267039954662323e-02
    z[1,4,2]  R1048     2.3709677159786224e-01
    z[1,4,2]  R1049     -3.4693825244903564e-01
    z[1,4,2]  R1050     6.3916486501693726e-01
    z[1,4,2]  R1051     -3.9355117082595825e-01
    z[1,4,2]  R1052     -1.1480126529932022e-02
    z[1,4,2]  R1053     1.7177364230155945e-01
    z[1,4,2]  R1054     3.8163551688194275e-01
    z[1,4,2]  R1055     3.4038397669792175e-01
    z[1,4,2]  R1056     0.566510021686554
    z[1,4,2]  R1057     -5.6937170028686523e-01
    z[1,4,2]  R1058     -3.3548864722251892e-01
    z[1,4,2]  R1059     -1.4437523484230042e-01
    z[1,4,2]  R1060     -1.9146996736526489e-01
    z[1,4,2]  R1061     -1.9056263566017151e-01
    z[1,4,2]  R1062     3.4245607256889343e-01
    z[1,4,2]  R1063     0.211964413523674
    z[1,4,2]  R1064     3.5854774713516235e-01
    z[1,4,2]  R1065     3.7747806310653687e-01
    z[1,4,2]  R1066     1.7277404665946960e-01
    z[1,4,2]  R1067     5.6270472705364227e-02
    z[1,4,2]  R1068     6.1175487935543060e-02
    z[1,4,2]  R1069     6.2633596360683441e-02
    z[1,4,2]  R1070     3.6473387479782104e-01
    z[1,4,2]  R1071     4.6586093306541443e-01
    z[1,4,2]  R1072     4.9473071098327637e-01
    z[1,4,2]  R1073     8.7779097259044647e-02
    z[1,4,2]  R1074     -8.1706777215003967e-02
    z[1,4,2]  R1075     5.5561274290084839e-01
    z[1,4,2]  R1076     0.90269535779953
    z[1,4,2]  R1077     -2.4621029198169708e-01
    z[1,4,2]  R1078     9.7653055563569069e-03
    z[1,4,2]  R1079     -4.4117063283920288e-02
    z[1,4,2]  R1080     -5.2991036325693130e-02
    z[1,4,2]  R1081     1.3464756309986115e-01
    z[1,4,2]  R1082     5.7754433155059814e-01
    z[1,4,2]  R1083     4.4476282596588135e-01
    z[1,4,2]  R1084     0.648669958114624
    z[1,4,2]  R1085     4.4346186518669128e-01
    z[1,4,2]  R1086     7.2225689888000488e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R993      -1
    z[1,4,3]  R994      1
    z[1,4,3]  R1001     -2.9019543528556824e-01
    z[1,4,3]  R1002     5.7496611028909683e-02
    z[1,4,3]  R1003     -7.3940992355346680e-02
    z[1,4,3]  R1004     2.4332102388143539e-02
    z[1,4,3]  R1005     -8.6339443922042847e-02
    z[1,4,3]  R1006     0.651769757270813
    z[1,4,3]  R1007     5.7279855012893677e-01
    z[1,4,3]  R1008     2.7020815014839172e-01
    z[1,4,3]  R1009     6.3380479812622070e-01
    z[1,4,3]  R1010     3.6046424508094788e-01
    z[1,4,3]  R1011     -0.477079302072525
    z[1,4,3]  R1012     6.7505910992622375e-02
    z[1,4,3]  R1013     2.5140070915222168e-01
    z[1,4,3]  R1014     -1.8602685630321503e-01
    z[1,4,3]  R1015     -2.1406927704811096e-01
    z[1,4,3]  R1016     -2.8279563784599304e-01
    z[1,4,3]  R1017     -0.0956747829914093
    z[1,4,3]  R1018     -2.6482401415705681e-02
    z[1,4,3]  R1019     -1.0606414824724197e-01
    z[1,4,3]  R1020     1.4834043383598328e-01
    z[1,4,3]  R1021     -3.7804111838340759e-01
    z[1,4,3]  R1022     3.8450878858566284e-01
    z[1,4,3]  R1023     0.0953054204583168
    z[1,4,3]  R1024     1.9266439601778984e-02
    z[1,4,3]  R1025     -3.2006785273551941e-01
    z[1,4,3]  R1026     -3.1716409325599670e-01
    z[1,4,3]  R1027     -2.4189472198486328e-01
    z[1,4,3]  R1028     -4.9281543493270874e-01
    z[1,4,3]  R1029     -4.6805629134178162e-01
    z[1,4,3]  R1030     1.9967010244727135e-02
    z[1,4,3]  R1031     -2.6093193888664246e-01
    z[1,4,3]  R1032     -6.8618077039718628e-01
    z[1,4,3]  R1033     -1.8147185444831848e-01
    z[1,4,3]  R1034     -4.9503338336944580e-01
    z[1,4,3]  R1035     -7.3967504501342773e-01
    z[1,4,3]  R1036     5.1183837652206421e-01
    z[1,4,3]  R1037     -4.9407193064689636e-01
    z[1,4,3]  R1038     -1.5420243144035339e-01
    z[1,4,3]  R1039     -5.0213855504989624e-01
    z[1,4,3]  R1040     3.4624069929122925e-02
    z[1,4,3]  R1041     -0.486905038356781
    z[1,4,3]  R1042     -5.1858031749725342e-01
    z[1,4,3]  R1043     7.9279178380966187e-01
    z[1,4,3]  R1044     -6.5510874986648560e-01
    z[1,4,3]  R1045     2.9931154847145081e-01
    z[1,4,3]  R1046     2.2582674026489258e-01
    z[1,4,3]  R1047     -0.532409131526947
    z[1,4,3]  R1048     1.1730780452489853e-01
    z[1,4,3]  R1049     -2.9757568240165710e-01
    z[1,4,3]  R1050     -6.3120013475418091e-01
    z[1,4,3]  R1051     -2.8670126199722290e-01
    z[1,4,3]  R1052     -4.9086907505989075e-01
    z[1,4,3]  R1053     -9.2673414945602417e-01
    z[1,4,3]  R1054     3.7704259157180786e-02
    z[1,4,3]  R1055     5.6681799888610840e-01
    z[1,4,3]  R1056     2.9143935441970825e-01
    z[1,4,3]  R1057     -1.3295269571244717e-02
    z[1,4,3]  R1058     8.1346770748496056e-03
    z[1,4,3]  R1059     6.1704171821475029e-04
    z[1,4,3]  R1060     5.4796808958053589e-01
    z[1,4,3]  R1061     -1.8601444363594055e-01
    z[1,4,3]  R1062     4.6598574519157410e-01
    z[1,4,3]  R1063     6.8456375598907471e-01
    z[1,4,3]  R1064     3.7912562489509583e-01
    z[1,4,3]  R1065     4.2051178216934204e-01
    z[1,4,3]  R1066     7.0381826162338257e-01
    z[1,4,3]  R1067     -5.6691038608551025e-01
    z[1,4,3]  R1068     -8.9019864797592163e-01
    z[1,4,3]  R1069     -9.4144827127456665e-01
    z[1,4,3]  R1070     -2.9299971461296082e-01
    z[1,4,3]  R1071     -6.8816497921943665e-02
    z[1,4,3]  R1072     -7.7888399362564087e-02
    z[1,4,3]  R1073     -2.6586738228797913e-01
    z[1,4,3]  R1074     -3.8229238986968994e-01
    z[1,4,3]  R1075     -0.0145845552906394
    z[1,4,3]  R1076     5.6325122714042664e-02
    z[1,4,3]  R1077     -3.5785429179668427e-02
    z[1,4,3]  R1078     -6.5327733755111694e-01
    z[1,4,3]  R1079     -9.4674319028854370e-01
    z[1,4,3]  R1080     -0.876287579536438
    z[1,4,3]  R1081     -7.8395682573318481e-01
    z[1,4,3]  R1082     2.2759279608726501e-01
    z[1,4,3]  R1083     2.2771029174327850e-01
    z[1,4,3]  R1084     -3.8415189832448959e-02
    z[1,4,3]  R1085     -1.0041257739067078e-01
    z[1,4,3]  R1086     7.9403042793273926e-02
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R995      -1
    z[1,4,4]  R996      1
    z[1,4,4]  R1001     3.8261204957962036e-01
    z[1,4,4]  R1002     2.7791008353233337e-01
    z[1,4,4]  R1003     -2.3422902822494507e-01
    z[1,4,4]  R1004     1.0998079180717468e-01
    z[1,4,4]  R1005     2.4276715517044067e-01
    z[1,4,4]  R1006     -1.1566183716058731e-01
    z[1,4,4]  R1007     2.1666100621223450e-01
    z[1,4,4]  R1008     1.3682533800601959e-01
    z[1,4,4]  R1009     1.9600607454776764e-01
    z[1,4,4]  R1010     1.7497076094150543e-01
    z[1,4,4]  R1011     1.1299677938222885e-01
    z[1,4,4]  R1012     -2.8302571736276150e-03
    z[1,4,4]  R1013     0.0761076956987381
    z[1,4,4]  R1014     1.3485226035118103e-01
    z[1,4,4]  R1015     -2.3401015996932983e-01
    z[1,4,4]  R1016     -2.5529021024703979e-01
    z[1,4,4]  R1017     0.527223527431488
    z[1,4,4]  R1018     0.502944827079773
    z[1,4,4]  R1019     -4.3249884247779846e-01
    z[1,4,4]  R1020     -2.5453118607401848e-02
    z[1,4,4]  R1021     -2.4937191605567932e-01
    z[1,4,4]  R1022     2.9429266229271889e-02
    z[1,4,4]  R1023     -3.4854507446289062e-01
    z[1,4,4]  R1024     -2.5800922513008118e-01
    z[1,4,4]  R1025     -3.9282381534576416e-01
    z[1,4,4]  R1026     -2.5062489509582520e-01
    z[1,4,4]  R1027     -1.2206542491912842e-01
    z[1,4,4]  R1028     5.1436161994934082e-01
    z[1,4,4]  R1029     4.3308654427528381e-01
    z[1,4,4]  R1030     -3.2065966725349426e-01
    z[1,4,4]  R1031     -5.4726237058639526e-01
    z[1,4,4]  R1032     -6.7449599504470825e-02
    z[1,4,4]  R1033     2.1403318643569946e-01
    z[1,4,4]  R1034     -6.9757483899593353e-02
    z[1,4,4]  R1035     -3.9082175493240356e-01
    z[1,4,4]  R1036     -2.1698732674121857e-01
    z[1,4,4]  R1037     0.505648136138916
    z[1,4,4]  R1038     -3.4428441524505615e-01
    z[1,4,4]  R1039     1.7090511322021484e-01
    z[1,4,4]  R1040     -4.8727640509605408e-01
    z[1,4,4]  R1041     -1.2089670449495316e-01
    z[1,4,4]  R1042     0.221050426363945
    z[1,4,4]  R1043     2.1512087434530258e-02
    z[1,4,4]  R1044     -3.7427493929862976e-01
    z[1,4,4]  R1045     2.4408282712101936e-02
    z[1,4,4]  R1046     -3.5382375121116638e-01
    z[1,4,4]  R1047     6.8781822919845581e-01
    z[1,4,4]  R1048     -4.4453686475753784e-01
    z[1,4,4]  R1049     6.4020842313766479e-01
    z[1,4,4]  R1050     4.1498217731714249e-02
    z[1,4,4]  R1051     1.1063133925199509e-01
    z[1,4,4]  R1052     -9.9658809602260590e-02
    z[1,4,4]  R1053     -0.0842304676771164
    z[1,4,4]  R1054     -2.4974401295185089e-01
    z[1,4,4]  R1055     -3.1321346759796143e-01
    z[1,4,4]  R1056     -1.9275777041912079e-01
    z[1,4,4]  R1057     8.1056252121925354e-02
    z[1,4,4]  R1058     0.142792746424675
    z[1,4,4]  R1059     -8.0507266521453857e-01
    z[1,4,4]  R1060     -3.9802014827728271e-01
    z[1,4,4]  R1061     -4.7465908527374268e-01
    z[1,4,4]  R1062     -0.537653386592865
    z[1,4,4]  R1063     1.2213263660669327e-01
    z[1,4,4]  R1064     3.2871001958847046e-01
    z[1,4,4]  R1065     2.1572580933570862e-01
    z[1,4,4]  R1066     2.4480944871902466e-01
    z[1,4,4]  R1067     2.8845849633216858e-01
    z[1,4,4]  R1068     -6.0820616781711578e-02
    z[1,4,4]  R1069     1.4904613792896271e-01
    z[1,4,4]  R1070     4.2433872818946838e-02
    z[1,4,4]  R1071     1.1020025610923767e-01
    z[1,4,4]  R1072     7.6562032103538513e-02
    z[1,4,4]  R1073     7.3388224840164185e-01
    z[1,4,4]  R1074     7.9327476024627686e-01
    z[1,4,4]  R1075     3.6913216114044189e-01
    z[1,4,4]  R1076     4.1980534791946411e-02
    z[1,4,4]  R1077     -2.2857272997498512e-02
    z[1,4,4]  R1078     -4.3017558753490448e-02
    z[1,4,4]  R1079     4.3811939656734467e-02
    z[1,4,4]  R1080     3.4191107749938965e-01
    z[1,4,4]  R1081     -3.9321768283843994e-01
    z[1,4,4]  R1082     -3.0978059768676758e-01
    z[1,4,4]  R1083     -2.4362166225910187e-01
    z[1,4,4]  R1084     -3.9132431149482727e-02
    z[1,4,4]  R1085     -1.7526191473007202e-01
    z[1,4,4]  R1086     1.3096977770328522e-01
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R997      -1
    z[1,4,5]  R998      1
    z[1,4,5]  R1001     -1.3069508969783783e-01
    z[1,4,5]  R1002     4.7280009835958481e-02
    z[1,4,5]  R1003     -2.4256812036037445e-01
    z[1,4,5]  R1004     1.0398554056882858e-01
    z[1,4,5]  R1005     -0.625950813293457
    z[1,4,5]  R1006     1.0464450716972351e-01
    z[1,4,5]  R1007     -1.2760579586029053e-01
    z[1,4,5]  R1008     2.7487901970744133e-02
    z[1,4,5]  R1009     -1.0926242172718048e-01
    z[1,4,5]  R1010     -9.2612817883491516e-02
    z[1,4,5]  R1011     6.8953827023506165e-02
    z[1,4,5]  R1012     -2.0019227266311646e-01
    z[1,4,5]  R1013     -3.3036354184150696e-01
    z[1,4,5]  R1014     -4.7876381874084473e-01
    z[1,4,5]  R1015     5.3922671824693680e-02
    z[1,4,5]  R1016     -0.264121949672699
    z[1,4,5]  R1017     4.1039773821830750e-01
    z[1,4,5]  R1018     1.3205060362815857e-01
    z[1,4,5]  R1019     0.194817915558815
    z[1,4,5]  R1020     1.7538410425186157e-01
    z[1,4,5]  R1021     6.4642357826232910e-01
    z[1,4,5]  R1022     -2.8103792667388916e-01
    z[1,4,5]  R1023     7.0109167136251926e-03
    z[1,4,5]  R1024     2.3674240708351135e-01
    z[1,4,5]  R1025     7.5311444699764252e-02
    z[1,4,5]  R1026     -2.9498040676116943e-02
    z[1,4,5]  R1027     -6.6754192113876343e-02
    z[1,4,5]  R1028     3.2755106687545776e-01
    z[1,4,5]  R1029     2.3541361093521118e-01
    z[1,4,5]  R1030     -5.1162582635879517e-01
    z[1,4,5]  R1031     -2.5592150166630745e-02
    z[1,4,5]  R1032     -3.0405440926551819e-01
    z[1,4,5]  R1033     8.3945882320404053e-01
    z[1,4,5]  R1034     -6.0283303260803223e-01
    z[1,4,5]  R1035     -5.3239960223436356e-02
    z[1,4,5]  R1036     -6.1507624387741089e-01
    z[1,4,5]  R1037     -3.1253370642662048e-01
    z[1,4,5]  R1038     -3.9272478222846985e-01
    z[1,4,5]  R1039     -3.5361361503601074e-01
    z[1,4,5]  R1040     -3.8169774413108826e-01
    z[1,4,5]  R1041     5.6845819950103760e-01
    z[1,4,5]  R1042     5.1635706424713135e-01
    z[1,4,5]  R1043     -1.0229671746492386e-01
    z[1,4,5]  R1044     -5.7824570685625076e-02
    z[1,4,5]  R1045     -2.8982567787170410e-01
    z[1,4,5]  R1046     1.9826823472976685e-01
    z[1,4,5]  R1047     9.6248477697372437e-02
    z[1,4,5]  R1048     -4.8029392957687378e-01
    z[1,4,5]  R1049     4.1570165753364563e-01
    z[1,4,5]  R1050     -3.5506728291511536e-01
    z[1,4,5]  R1051     2.5812932848930359e-01
    z[1,4,5]  R1052     -2.9577055573463440e-01
    z[1,4,5]  R1053     1.9396256655454636e-02
    z[1,4,5]  R1054     -3.2449653744697571e-01
    z[1,4,5]  R1055     4.2761421203613281e-01
    z[1,4,5]  R1056     -1.7201507091522217e-01
    z[1,4,5]  R1057     -3.2239374518394470e-01
    z[1,4,5]  R1058     -2.5660082697868347e-01
    z[1,4,5]  R1059     1.2339268811047077e-02
    z[1,4,5]  R1060     9.2138200998306274e-02
    z[1,4,5]  R1061     -2.4084170162677765e-01
    z[1,4,5]  R1062     -4.0667504072189331e-01
    z[1,4,5]  R1063     -4.5615375041961670e-01
    z[1,4,5]  R1064     -5.0682887434959412e-02
    z[1,4,5]  R1065     -5.3031824529170990e-02
    z[1,4,5]  R1066     -3.7292614579200745e-02
    z[1,4,5]  R1067     1.4203681051731110e-01
    z[1,4,5]  R1068     8.4373086690902710e-02
    z[1,4,5]  R1069     -2.2015558183193207e-01
    z[1,4,5]  R1070     2.3934745788574219e-01
    z[1,4,5]  R1071     1.6793370246887207e-01
    z[1,4,5]  R1072     -5.6633424758911133e-01
    z[1,4,5]  R1073     3.3496430516242981e-01
    z[1,4,5]  R1074     2.1169048547744751e-01
    z[1,4,5]  R1075     -4.8653557896614075e-02
    z[1,4,5]  R1076     -4.1244491934776306e-01
    z[1,4,5]  R1077     8.6037427186965942e-01
    z[1,4,5]  R1078     5.9718143939971924e-01
    z[1,4,5]  R1079     -1.2719912827014923e-01
    z[1,4,5]  R1080     -6.2453597784042358e-03
    z[1,4,5]  R1081     1.5146744251251221e-01
    z[1,4,5]  R1082     1.6857126355171204e-01
    z[1,4,5]  R1083     1.3088262081146240e-01
    z[1,4,5]  R1084     -6.7186409235000610e-01
    z[1,4,5]  R1085     -5.4155224561691284e-01
    z[1,4,5]  R1086     -5.8668041229248047e-01
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R999      -1
    z[1,4,6]  R1000     1
    z[1,4,6]  R1001     9.0889401733875275e-02
    z[1,4,6]  R1002     -2.5877895951271057e-01
    z[1,4,6]  R1003     -8.0745331943035126e-02
    z[1,4,6]  R1004     0.374576598405838
    z[1,4,6]  R1005     -4.8989301919937134e-01
    z[1,4,6]  R1006     2.0928401499986649e-02
    z[1,4,6]  R1007     -2.4365289136767387e-02
    z[1,4,6]  R1008     2.5289552286267281e-02
    z[1,4,6]  R1009     3.9734715223312378e-01
    z[1,4,6]  R1010     -2.2739601135253906e-01
    z[1,4,6]  R1011     -0.0466383658349514
    z[1,4,6]  R1012     3.5846567153930664e-01
    z[1,4,6]  R1013     1.1906799674034119e-01
    z[1,4,6]  R1014     3.1650140881538391e-02
    z[1,4,6]  R1015     2.6548784971237183e-01
    z[1,4,6]  R1016     -0.406181275844574
    z[1,4,6]  R1017     5.1750767976045609e-02
    z[1,4,6]  R1018     4.2256820201873779e-01
    z[1,4,6]  R1019     -5.2460145950317383e-01
    z[1,4,6]  R1020     -5.5509054660797119e-01
    z[1,4,6]  R1021     2.6183506846427917e-01
    z[1,4,6]  R1022     -1.2222281098365784e-01
    z[1,4,6]  R1023     6.3423417508602142e-02
    z[1,4,6]  R1024     2.3502789437770844e-01
    z[1,4,6]  R1025     -0.00405834149569273
    z[1,4,6]  R1026     -5.1050871610641479e-01
    z[1,4,6]  R1027     0.63865065574646
    z[1,4,6]  R1028     -1.4969493262469769e-02
    z[1,4,6]  R1029     -1.7411597073078156e-01
    z[1,4,6]  R1030     2.0495028793811798e-01
    z[1,4,6]  R1031     3.2708659768104553e-02
    z[1,4,6]  R1032     -5.1327300071716309e-01
    z[1,4,6]  R1033     -3.6908425390720367e-02
    z[1,4,6]  R1034     7.4787355959415436e-02
    z[1,4,6]  R1035     3.2975021004676819e-01
    z[1,4,6]  R1036     -2.9628169536590576e-01
    z[1,4,6]  R1037     -1.2057397514581680e-01
    z[1,4,6]  R1038     3.4699384123086929e-02
    z[1,4,6]  R1039     0.268963485956192
    z[1,4,6]  R1040     -1.2915319204330444e-01
    z[1,4,6]  R1041     1.2269077450037003e-01
    z[1,4,6]  R1042     -3.2819494605064392e-01
    z[1,4,6]  R1043     -2.3916883766651154e-01
    z[1,4,6]  R1044     3.5343545675277710e-01
    z[1,4,6]  R1045     6.0876852273941040e-01
    z[1,4,6]  R1046     6.9648787379264832e-02
    z[1,4,6]  R1047     8.0360412597656250e-02
    z[1,4,6]  R1048     -0.0366581492125988
    z[1,4,6]  R1049     1.7690800130367279e-02
    z[1,4,6]  R1050     4.7874860465526581e-02
    z[1,4,6]  R1051     -2.7707897126674652e-02
    z[1,4,6]  R1052     -4.6995177865028381e-01
    z[1,4,6]  R1053     4.6346601098775864e-02
    z[1,4,6]  R1054     2.3973459377884865e-02
    z[1,4,6]  R1055     0.190284863114357
    z[1,4,6]  R1056     2.4733503162860870e-01
    z[1,4,6]  R1057     8.4367677569389343e-02
    z[1,4,6]  R1058     -1.2470804899930954e-01
    z[1,4,6]  R1059     -5.8409009128808975e-02
    z[1,4,6]  R1060     -3.6872607469558716e-01
    z[1,4,6]  R1061     6.4095747470855713e-01
    z[1,4,6]  R1062     -9.9079899489879608e-02
    z[1,4,6]  R1063     5.8955080807209015e-02
    z[1,4,6]  R1064     -2.1402002871036530e-01
    z[1,4,6]  R1065     1.7176277935504913e-01
    z[1,4,6]  R1066     2.3929831385612488e-01
    z[1,4,6]  R1067     -7.0287567377090454e-01
    z[1,4,6]  R1068     -9.5990262925624847e-02
    z[1,4,6]  R1069     -1.5229627490043640e-01
    z[1,4,6]  R1070     9.8155051469802856e-02
    z[1,4,6]  R1071     2.1900594234466553e-01
    z[1,4,6]  R1072     -3.7142071127891541e-01
    z[1,4,6]  R1073     2.2928024828433990e-01
    z[1,4,6]  R1074     3.0301153659820557e-01
    z[1,4,6]  R1075     2.7891201898455620e-03
    z[1,4,6]  R1076     6.1072193086147308e-02
    z[1,4,6]  R1077     3.2782158255577087e-01
    z[1,4,6]  R1078     -2.7677747607231140e-01
    z[1,4,6]  R1079     4.0796067565679550e-02
    z[1,4,6]  R1080     2.3708198964595795e-01
    z[1,4,6]  R1081     -1.0968913137912750e-01
    z[1,4,6]  R1082     -0.0639939159154892
    z[1,4,6]  R1083     1.5299607813358307e-01
    z[1,4,6]  R1084     6.1401624232530594e-02
    z[1,4,6]  R1085     -1.5890444815158844e-01
    z[1,4,6]  R1086     -2.6737222075462341e-01
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1087     -1
    z[4,1,0]  R1088     1
    z[4,1,0]  R1101     -4.5848438143730164e-01
    z[4,1,0]  R1102     -8.3330410718917847e-01
    z[4,1,0]  R1103     -3.8666200637817383e-01
    z[4,1,0]  R1104     -1.9907087087631226e-01
    z[4,1,0]  R1105     -4.4714611768722534e-01
    z[4,1,0]  R1106     1.3753038644790649e-01
    z[4,1,0]  R1107     3.7897473573684692e-01
    z[4,1,0]  R1108     6.2275505065917969e-01
    z[4,1,0]  R1109     6.7475163936614990e-01
    z[4,1,0]  R1110     5.7183831930160522e-01
    z[4,1,0]  R1111     7.6425084844231606e-03
    z[4,1,0]  R1112     1.7630884051322937e-01
    z[4,1,0]  R1113     5.3241960704326630e-02
    z[4,1,0]  R1114     -1.9779168069362640e-02
    z[4,1,0]  R1115     4.3267560005187988e-01
    z[4,1,0]  R1116     0.529718279838562
    z[4,1,0]  R1117     4.0345376729965210e-01
    z[4,1,0]  R1118     1.3535985350608826e-01
    z[4,1,0]  R1119     0.340166836977005
    z[4,1,0]  R1120     7.4405074119567871e-02
    z[4,1,0]  R1121     -1.9793882966041565e-01
    z[4,1,0]  R1122     -1.9118184223771095e-02
    z[4,1,0]  R1123     -2.7381128072738647e-01
    z[4,1,0]  R1124     -1.2327007949352264e-01
    z[4,1,0]  R1125     -3.6031207442283630e-01
    z[4,1,0]  R1126     0.573261022567749
    z[4,1,0]  R1127     8.0649471282958984e-01
    z[4,1,0]  R1128     3.2313579320907593e-01
    z[4,1,0]  R1129     6.6625958681106567e-01
    z[4,1,0]  R1130     1.7175951600074768e-01
    z[4,1,0]  R1131     -4.3973377346992493e-01
    z[4,1,0]  R1132     -4.6908619999885559e-01
    z[4,1,0]  R1133     -4.6749472618103027e-01
    z[4,1,0]  R1134     -5.9391325712203979e-01
    z[4,1,0]  R1135     -0.438795268535614
    z[4,1,0]  R1136     6.8099820613861084e-01
    z[4,1,0]  R1137     6.4077001810073853e-01
    z[4,1,0]  R1138     7.4334591627120972e-01
    z[4,1,0]  R1139     5.5163621902465820e-01
    z[4,1,0]  R1140     6.8956816196441650e-01
    z[4,1,0]  R1141     -4.7952553629875183e-01
    z[4,1,0]  R1142     -0.32700115442276
    z[4,1,0]  R1143     -2.9756346344947815e-01
    z[4,1,0]  R1144     -3.4690535068511963e-01
    z[4,1,0]  R1145     -2.8038537502288818e-01
    z[4,1,0]  R1146     -4.4638866186141968e-01
    z[4,1,0]  R1147     -4.1364064812660217e-01
    z[4,1,0]  R1148     -0.2532939016819
    z[4,1,0]  R1149     -2.7952659130096436e-01
    z[4,1,0]  R1150     -2.2245080769062042e-01
    z[4,1,0]  R1151     -3.7676227092742920e-01
    z[4,1,0]  R1152     0.478341281414032
    z[4,1,0]  R1153     0.676973283290863
    z[4,1,0]  R1154     4.4680270552635193e-01
    z[4,1,0]  R1155     6.4664644002914429e-01
    z[4,1,0]  R1156     5.7975602149963379e-01
    z[4,1,0]  R1157     0.586368203163147
    z[4,1,0]  R1158     6.0991507768630981e-01
    z[4,1,0]  R1159     0.332193523645401
    z[4,1,0]  R1160     7.2198235988616943e-01
    z[4,1,0]  R1161     1.0257675498723984e-01
    z[4,1,0]  R1162     -2.2947709262371063e-01
    z[4,1,0]  R1163     -3.6362317204475403e-01
    z[4,1,0]  R1164     5.3756457567214966e-01
    z[4,1,0]  R1165     -2.9505431652069092e-02
    z[4,1,0]  R1166     4.5382156968116760e-01
    z[4,1,0]  R1167     2.6670229434967041e-01
    z[4,1,0]  R1168     7.3435842990875244e-01
    z[4,1,0]  R1169     4.9293899536132812e-01
    z[4,1,0]  R1170     6.9068127870559692e-01
    z[4,1,0]  R1171     -5.4931193590164185e-01
    z[4,1,0]  R1172     -3.8923683762550354e-01
    z[4,1,0]  R1173     4.1136839985847473e-01
    z[4,1,0]  R1174     -1.7706157639622688e-02
    z[4,1,0]  R1175     1.2964147329330444e-01
    z[4,1,0]  R1176     2.6234817504882812e-01
    z[4,1,0]  R1177     4.7098869085311890e-01
    z[4,1,0]  R1178     7.0320379734039307e-01
    z[4,1,0]  R1179     4.5568275451660156e-01
    z[4,1,0]  R1180     2.2768758237361908e-01
    z[4,1,0]  R1181     -7.3867177963256836e-01
    z[4,1,0]  R1182     -2.5451815128326416e-01
    z[4,1,0]  R1183     -0.0896846279501915
    z[4,1,0]  R1184     0.797221302986145
    z[4,1,0]  R1185     -4.8959842324256897e-01
    z[4,1,0]  R1186     -6.7485976219177246e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1089     -1
    z[4,1,1]  R1090     1
    z[4,1,1]  R1101     5.8975040912628174e-01
    z[4,1,1]  R1102     -3.0199262499809265e-01
    z[4,1,1]  R1103     4.2183169722557068e-01
    z[4,1,1]  R1104     5.6619131565093994e-01
    z[4,1,1]  R1105     -0.187115877866745
    z[4,1,1]  R1106     -4.2707616090774536e-01
    z[4,1,1]  R1107     -0.341106116771698
    z[4,1,1]  R1108     -4.2832204699516296e-01
    z[4,1,1]  R1109     -0.382802814245224
    z[4,1,1]  R1110     -1.7089107632637024e-01
    z[4,1,1]  R1111     2.7923274040222168e-01
    z[4,1,1]  R1112     3.9075195789337158e-01
    z[4,1,1]  R1113     1.1419252306222916e-01
    z[4,1,1]  R1114     -8.4380501508712769e-01
    z[4,1,1]  R1115     7.0902770757675171e-01
    z[4,1,1]  R1116     -0.0634336769580841
    z[4,1,1]  R1117     -2.3554362356662750e-01
    z[4,1,1]  R1118     -2.5087940692901611e-01
    z[4,1,1]  R1119     6.6085916757583618e-01
    z[4,1,1]  R1120     -2.8801517561078072e-02
    z[4,1,1]  R1121     2.2513702511787415e-01
    z[4,1,1]  R1122     3.7106060981750488e-01
    z[4,1,1]  R1123     -8.3636589348316193e-02
    z[4,1,1]  R1124     -2.0240172743797302e-01
    z[4,1,1]  R1125     -2.1877533197402954e-01
    z[4,1,1]  R1126     -3.9691346883773804e-01
    z[4,1,1]  R1127     3.2836962491273880e-03
    z[4,1,1]  R1128     -1.2896490097045898e-01
    z[4,1,1]  R1129     -1.0529072955250740e-02
    z[4,1,1]  R1130     9.8508365452289581e-02
    z[4,1,1]  R1131     7.0582723617553711e-01
    z[4,1,1]  R1132     7.4835884571075439e-01
    z[4,1,1]  R1133     6.4602726697921753e-01
    z[4,1,1]  R1134     4.0355780720710754e-01
    z[4,1,1]  R1135     2.8929588198661804e-01
    z[4,1,1]  R1136     -1.5599606931209564e-01
    z[4,1,1]  R1137     -2.5938186049461365e-01
    z[4,1,1]  R1138     -2.8838065266609192e-01
    z[4,1,1]  R1139     -2.6488536596298218e-01
    z[4,1,1]  R1140     -1.8207627534866333e-01
    z[4,1,1]  R1141     -0.722950279712677
    z[4,1,1]  R1142     -7.9297041893005371e-01
    z[4,1,1]  R1143     -8.1031274795532227e-01
    z[4,1,1]  R1144     -7.6446080207824707e-01
    z[4,1,1]  R1145     -0.84675532579422
    z[4,1,1]  R1146     -6.3792812824249268e-01
    z[4,1,1]  R1147     -6.0679459571838379e-01
    z[4,1,1]  R1148     -6.9677561521530151e-01
    z[4,1,1]  R1149     -6.4049822092056274e-01
    z[4,1,1]  R1150     -7.5996285676956177e-01
    z[4,1,1]  R1151     3.1034144759178162e-01
    z[4,1,1]  R1152     6.3583391904830933e-01
    z[4,1,1]  R1153     0.596767783164978
    z[4,1,1]  R1154     7.8609246015548706e-01
    z[4,1,1]  R1155     5.6476938724517822e-01
    z[4,1,1]  R1156     4.8868107795715332e-01
    z[4,1,1]  R1157     3.9729556441307068e-01
    z[4,1,1]  R1158     6.6568471491336823e-02
    z[4,1,1]  R1159     -1.3944588601589203e-02
    z[4,1,1]  R1160     1.3699467480182648e-01
    z[4,1,1]  R1161     -7.8468644618988037e-01
    z[4,1,1]  R1162     3.0972850322723389e-01
    z[4,1,1]  R1163     2.8695744276046753e-01
    z[4,1,1]  R1164     1.9082698225975037e-01
    z[4,1,1]  R1165     4.2503336071968079e-01
    z[4,1,1]  R1166     -9.7298972308635712e-02
    z[4,1,1]  R1167     -1.1420476436614990e-01
    z[4,1,1]  R1168     1.7754136025905609e-01
    z[4,1,1]  R1169     -2.3391132056713104e-01
    z[4,1,1]  R1170     2.2367011010646820e-01
    z[4,1,1]  R1171     2.0922964811325073e-01
    z[4,1,1]  R1172     3.7760722637176514e-01
    z[4,1,1]  R1173     -3.3757331967353821e-01
    z[4,1,1]  R1174     5.3565579652786255e-01
    z[4,1,1]  R1175     5.6941163539886475e-01
    z[4,1,1]  R1176     8.3352994918823242e-01
    z[4,1,1]  R1177     3.5133186727762222e-02
    z[4,1,1]  R1178     7.6741680502891541e-02
    z[4,1,1]  R1179     -2.1169431507587433e-02
    z[4,1,1]  R1180     -1.0548040270805359e-01
    z[4,1,1]  R1181     3.7100705504417419e-01
    z[4,1,1]  R1182     6.1308199167251587e-01
    z[4,1,1]  R1183     3.0658674240112305e-01
    z[4,1,1]  R1184     2.2164407372474670e-01
    z[4,1,1]  R1185     7.7359803020954132e-02
    z[4,1,1]  R1186     1.0380051285028458e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1091     -1
    z[4,1,2]  R1092     1
    z[4,1,2]  R1101     -5.6937170028686523e-01
    z[4,1,2]  R1102     -3.3548864722251892e-01
    z[4,1,2]  R1103     -1.4437523484230042e-01
    z[4,1,2]  R1104     -1.9146996736526489e-01
    z[4,1,2]  R1105     -1.9056263566017151e-01
    z[4,1,2]  R1106     3.4245607256889343e-01
    z[4,1,2]  R1107     0.211964413523674
    z[4,1,2]  R1108     3.5854774713516235e-01
    z[4,1,2]  R1109     3.7747806310653687e-01
    z[4,1,2]  R1110     1.7277404665946960e-01
    z[4,1,2]  R1111     5.6270472705364227e-02
    z[4,1,2]  R1112     6.1175487935543060e-02
    z[4,1,2]  R1113     6.2633596360683441e-02
    z[4,1,2]  R1114     3.6473387479782104e-01
    z[4,1,2]  R1115     4.6586093306541443e-01
    z[4,1,2]  R1116     4.9473071098327637e-01
    z[4,1,2]  R1117     8.7779097259044647e-02
    z[4,1,2]  R1118     -8.1706777215003967e-02
    z[4,1,2]  R1119     5.5561274290084839e-01
    z[4,1,2]  R1120     0.90269535779953
    z[4,1,2]  R1121     -2.4621029198169708e-01
    z[4,1,2]  R1122     9.7653055563569069e-03
    z[4,1,2]  R1123     -4.4117063283920288e-02
    z[4,1,2]  R1124     -5.2991036325693130e-02
    z[4,1,2]  R1125     1.3464756309986115e-01
    z[4,1,2]  R1126     5.7754433155059814e-01
    z[4,1,2]  R1127     4.4476282596588135e-01
    z[4,1,2]  R1128     0.648669958114624
    z[4,1,2]  R1129     4.4346186518669128e-01
    z[4,1,2]  R1130     7.2225689888000488e-01
    z[4,1,2]  R1131     -0.229117289185524
    z[4,1,2]  R1132     -2.6490619778633118e-01
    z[4,1,2]  R1133     -4.8827031254768372e-01
    z[4,1,2]  R1134     -5.6621521711349487e-01
    z[4,1,2]  R1135     -1.5989576280117035e-01
    z[4,1,2]  R1136     2.4967324733734131e-01
    z[4,1,2]  R1137     3.6085703969001770e-01
    z[4,1,2]  R1138     5.2071553468704224e-01
    z[4,1,2]  R1139     1.2483359873294830e-01
    z[4,1,2]  R1140     5.2010452747344971e-01
    z[4,1,2]  R1141     -9.7651155665516853e-03
    z[4,1,2]  R1142     -3.0187508463859558e-01
    z[4,1,2]  R1143     -2.5007483363151550e-01
    z[4,1,2]  R1144     -1.1067414283752441e-01
    z[4,1,2]  R1145     -1.7438901960849762e-01
    z[4,1,2]  R1146     -1.1787618696689606e-01
    z[4,1,2]  R1147     4.9787878990173340e-02
    z[4,1,2]  R1148     -2.6266448199748993e-02
    z[4,1,2]  R1149     -0.0127011863514781
    z[4,1,2]  R1150     1.0693140327930450e-01
    z[4,1,2]  R1151     -2.6498275995254517e-01
    z[4,1,2]  R1152     -3.5252094268798828e-01
    z[4,1,2]  R1153     -2.2569186985492706e-01
    z[4,1,2]  R1154     0.0648149698972702
    z[4,1,2]  R1155     0.0210171639919281
    z[4,1,2]  R1156     1.3366617262363434e-02
    z[4,1,2]  R1157     -1.1218158155679703e-01
    z[4,1,2]  R1158     9.2862747609615326e-02
    z[4,1,2]  R1159     6.3014000654220581e-01
    z[4,1,2]  R1160     2.3018909990787506e-01
    z[4,1,2]  R1161     6.6623359918594360e-02
    z[4,1,2]  R1162     1.4183364808559418e-01
    z[4,1,2]  R1163     -2.5261448696255684e-02
    z[4,1,2]  R1164     -0.235975444316864
    z[4,1,2]  R1165     -8.3938531577587128e-02
    z[4,1,2]  R1166     9.7031831741333008e-02
    z[4,1,2]  R1167     5.5120289325714111e-01
    z[4,1,2]  R1168     3.6256012320518494e-01
    z[4,1,2]  R1169     0.472822368144989
    z[4,1,2]  R1170     0.268179327249527
    z[4,1,2]  R1171     -2.5414398312568665e-01
    z[4,1,2]  R1172     1.1739699542522430e-01
    z[4,1,2]  R1173     1.4202952384948730e-01
    z[4,1,2]  R1174     -1.2348987907171249e-01
    z[4,1,2]  R1175     -3.3790859580039978e-01
    z[4,1,2]  R1176     -1.2669317424297333e-01
    z[4,1,2]  R1177     -6.8267039954662323e-02
    z[4,1,2]  R1178     2.3709677159786224e-01
    z[4,1,2]  R1179     -3.4693825244903564e-01
    z[4,1,2]  R1180     6.3916486501693726e-01
    z[4,1,2]  R1181     -3.9355117082595825e-01
    z[4,1,2]  R1182     -1.1480126529932022e-02
    z[4,1,2]  R1183     1.7177364230155945e-01
    z[4,1,2]  R1184     3.8163551688194275e-01
    z[4,1,2]  R1185     3.4038397669792175e-01
    z[4,1,2]  R1186     0.566510021686554
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1093     -1
    z[4,1,3]  R1094     1
    z[4,1,3]  R1101     -1.3295269571244717e-02
    z[4,1,3]  R1102     8.1346770748496056e-03
    z[4,1,3]  R1103     6.1704171821475029e-04
    z[4,1,3]  R1104     5.4796808958053589e-01
    z[4,1,3]  R1105     -1.8601444363594055e-01
    z[4,1,3]  R1106     4.6598574519157410e-01
    z[4,1,3]  R1107     6.8456375598907471e-01
    z[4,1,3]  R1108     3.7912562489509583e-01
    z[4,1,3]  R1109     4.2051178216934204e-01
    z[4,1,3]  R1110     7.0381826162338257e-01
    z[4,1,3]  R1111     -5.6691038608551025e-01
    z[4,1,3]  R1112     -8.9019864797592163e-01
    z[4,1,3]  R1113     -9.4144827127456665e-01
    z[4,1,3]  R1114     -2.9299971461296082e-01
    z[4,1,3]  R1115     -6.8816497921943665e-02
    z[4,1,3]  R1116     -7.7888399362564087e-02
    z[4,1,3]  R1117     -2.6586738228797913e-01
    z[4,1,3]  R1118     -3.8229238986968994e-01
    z[4,1,3]  R1119     -0.0145845552906394
    z[4,1,3]  R1120     5.6325122714042664e-02
    z[4,1,3]  R1121     -3.5785429179668427e-02
    z[4,1,3]  R1122     -6.5327733755111694e-01
    z[4,1,3]  R1123     -9.4674319028854370e-01
    z[4,1,3]  R1124     -0.876287579536438
    z[4,1,3]  R1125     -7.8395682573318481e-01
    z[4,1,3]  R1126     2.2759279608726501e-01
    z[4,1,3]  R1127     2.2771029174327850e-01
    z[4,1,3]  R1128     -3.8415189832448959e-02
    z[4,1,3]  R1129     -1.0041257739067078e-01
    z[4,1,3]  R1130     7.9403042793273926e-02
    z[4,1,3]  R1131     -2.9019543528556824e-01
    z[4,1,3]  R1132     5.7496611028909683e-02
    z[4,1,3]  R1133     -7.3940992355346680e-02
    z[4,1,3]  R1134     2.4332102388143539e-02
    z[4,1,3]  R1135     -8.6339443922042847e-02
    z[4,1,3]  R1136     0.651769757270813
    z[4,1,3]  R1137     5.7279855012893677e-01
    z[4,1,3]  R1138     2.7020815014839172e-01
    z[4,1,3]  R1139     6.3380479812622070e-01
    z[4,1,3]  R1140     3.6046424508094788e-01
    z[4,1,3]  R1141     -0.477079302072525
    z[4,1,3]  R1142     6.7505910992622375e-02
    z[4,1,3]  R1143     2.5140070915222168e-01
    z[4,1,3]  R1144     -1.8602685630321503e-01
    z[4,1,3]  R1145     -2.1406927704811096e-01
    z[4,1,3]  R1146     -2.8279563784599304e-01
    z[4,1,3]  R1147     -0.0956747829914093
    z[4,1,3]  R1148     -2.6482401415705681e-02
    z[4,1,3]  R1149     -1.0606414824724197e-01
    z[4,1,3]  R1150     1.4834043383598328e-01
    z[4,1,3]  R1151     -3.7804111838340759e-01
    z[4,1,3]  R1152     3.8450878858566284e-01
    z[4,1,3]  R1153     0.0953054204583168
    z[4,1,3]  R1154     1.9266439601778984e-02
    z[4,1,3]  R1155     -3.2006785273551941e-01
    z[4,1,3]  R1156     -3.1716409325599670e-01
    z[4,1,3]  R1157     -2.4189472198486328e-01
    z[4,1,3]  R1158     -4.9281543493270874e-01
    z[4,1,3]  R1159     -4.6805629134178162e-01
    z[4,1,3]  R1160     1.9967010244727135e-02
    z[4,1,3]  R1161     -2.6093193888664246e-01
    z[4,1,3]  R1162     -6.8618077039718628e-01
    z[4,1,3]  R1163     -1.8147185444831848e-01
    z[4,1,3]  R1164     -4.9503338336944580e-01
    z[4,1,3]  R1165     -7.3967504501342773e-01
    z[4,1,3]  R1166     5.1183837652206421e-01
    z[4,1,3]  R1167     -4.9407193064689636e-01
    z[4,1,3]  R1168     -1.5420243144035339e-01
    z[4,1,3]  R1169     -5.0213855504989624e-01
    z[4,1,3]  R1170     3.4624069929122925e-02
    z[4,1,3]  R1171     -0.486905038356781
    z[4,1,3]  R1172     -5.1858031749725342e-01
    z[4,1,3]  R1173     7.9279178380966187e-01
    z[4,1,3]  R1174     -6.5510874986648560e-01
    z[4,1,3]  R1175     2.9931154847145081e-01
    z[4,1,3]  R1176     2.2582674026489258e-01
    z[4,1,3]  R1177     -0.532409131526947
    z[4,1,3]  R1178     1.1730780452489853e-01
    z[4,1,3]  R1179     -2.9757568240165710e-01
    z[4,1,3]  R1180     -6.3120013475418091e-01
    z[4,1,3]  R1181     -2.8670126199722290e-01
    z[4,1,3]  R1182     -4.9086907505989075e-01
    z[4,1,3]  R1183     -9.2673414945602417e-01
    z[4,1,3]  R1184     3.7704259157180786e-02
    z[4,1,3]  R1185     5.6681799888610840e-01
    z[4,1,3]  R1186     2.9143935441970825e-01
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1095     -1
    z[4,1,4]  R1096     1
    z[4,1,4]  R1101     8.1056252121925354e-02
    z[4,1,4]  R1102     0.142792746424675
    z[4,1,4]  R1103     -8.0507266521453857e-01
    z[4,1,4]  R1104     -3.9802014827728271e-01
    z[4,1,4]  R1105     -4.7465908527374268e-01
    z[4,1,4]  R1106     -0.537653386592865
    z[4,1,4]  R1107     1.2213263660669327e-01
    z[4,1,4]  R1108     3.2871001958847046e-01
    z[4,1,4]  R1109     2.1572580933570862e-01
    z[4,1,4]  R1110     2.4480944871902466e-01
    z[4,1,4]  R1111     2.8845849633216858e-01
    z[4,1,4]  R1112     -6.0820616781711578e-02
    z[4,1,4]  R1113     1.4904613792896271e-01
    z[4,1,4]  R1114     4.2433872818946838e-02
    z[4,1,4]  R1115     1.1020025610923767e-01
    z[4,1,4]  R1116     7.6562032103538513e-02
    z[4,1,4]  R1117     7.3388224840164185e-01
    z[4,1,4]  R1118     7.9327476024627686e-01
    z[4,1,4]  R1119     3.6913216114044189e-01
    z[4,1,4]  R1120     4.1980534791946411e-02
    z[4,1,4]  R1121     -2.2857272997498512e-02
    z[4,1,4]  R1122     -4.3017558753490448e-02
    z[4,1,4]  R1123     4.3811939656734467e-02
    z[4,1,4]  R1124     3.4191107749938965e-01
    z[4,1,4]  R1125     -3.9321768283843994e-01
    z[4,1,4]  R1126     -3.0978059768676758e-01
    z[4,1,4]  R1127     -2.4362166225910187e-01
    z[4,1,4]  R1128     -3.9132431149482727e-02
    z[4,1,4]  R1129     -1.7526191473007202e-01
    z[4,1,4]  R1130     1.3096977770328522e-01
    z[4,1,4]  R1131     3.8261204957962036e-01
    z[4,1,4]  R1132     2.7791008353233337e-01
    z[4,1,4]  R1133     -2.3422902822494507e-01
    z[4,1,4]  R1134     1.0998079180717468e-01
    z[4,1,4]  R1135     2.4276715517044067e-01
    z[4,1,4]  R1136     -1.1566183716058731e-01
    z[4,1,4]  R1137     2.1666100621223450e-01
    z[4,1,4]  R1138     1.3682533800601959e-01
    z[4,1,4]  R1139     1.9600607454776764e-01
    z[4,1,4]  R1140     1.7497076094150543e-01
    z[4,1,4]  R1141     1.1299677938222885e-01
    z[4,1,4]  R1142     -2.8302571736276150e-03
    z[4,1,4]  R1143     0.0761076956987381
    z[4,1,4]  R1144     1.3485226035118103e-01
    z[4,1,4]  R1145     -2.3401015996932983e-01
    z[4,1,4]  R1146     -2.5529021024703979e-01
    z[4,1,4]  R1147     0.527223527431488
    z[4,1,4]  R1148     0.502944827079773
    z[4,1,4]  R1149     -4.3249884247779846e-01
    z[4,1,4]  R1150     -2.5453118607401848e-02
    z[4,1,4]  R1151     -2.4937191605567932e-01
    z[4,1,4]  R1152     2.9429266229271889e-02
    z[4,1,4]  R1153     -3.4854507446289062e-01
    z[4,1,4]  R1154     -2.5800922513008118e-01
    z[4,1,4]  R1155     -3.9282381534576416e-01
    z[4,1,4]  R1156     -2.5062489509582520e-01
    z[4,1,4]  R1157     -1.2206542491912842e-01
    z[4,1,4]  R1158     5.1436161994934082e-01
    z[4,1,4]  R1159     4.3308654427528381e-01
    z[4,1,4]  R1160     -3.2065966725349426e-01
    z[4,1,4]  R1161     -5.4726237058639526e-01
    z[4,1,4]  R1162     -6.7449599504470825e-02
    z[4,1,4]  R1163     2.1403318643569946e-01
    z[4,1,4]  R1164     -6.9757483899593353e-02
    z[4,1,4]  R1165     -3.9082175493240356e-01
    z[4,1,4]  R1166     -2.1698732674121857e-01
    z[4,1,4]  R1167     0.505648136138916
    z[4,1,4]  R1168     -3.4428441524505615e-01
    z[4,1,4]  R1169     1.7090511322021484e-01
    z[4,1,4]  R1170     -4.8727640509605408e-01
    z[4,1,4]  R1171     -1.2089670449495316e-01
    z[4,1,4]  R1172     0.221050426363945
    z[4,1,4]  R1173     2.1512087434530258e-02
    z[4,1,4]  R1174     -3.7427493929862976e-01
    z[4,1,4]  R1175     2.4408282712101936e-02
    z[4,1,4]  R1176     -3.5382375121116638e-01
    z[4,1,4]  R1177     6.8781822919845581e-01
    z[4,1,4]  R1178     -4.4453686475753784e-01
    z[4,1,4]  R1179     6.4020842313766479e-01
    z[4,1,4]  R1180     4.1498217731714249e-02
    z[4,1,4]  R1181     1.1063133925199509e-01
    z[4,1,4]  R1182     -9.9658809602260590e-02
    z[4,1,4]  R1183     -0.0842304676771164
    z[4,1,4]  R1184     -2.4974401295185089e-01
    z[4,1,4]  R1185     -3.1321346759796143e-01
    z[4,1,4]  R1186     -1.9275777041912079e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1097     -1
    z[4,1,5]  R1098     1
    z[4,1,5]  R1101     -3.2239374518394470e-01
    z[4,1,5]  R1102     -2.5660082697868347e-01
    z[4,1,5]  R1103     1.2339268811047077e-02
    z[4,1,5]  R1104     9.2138200998306274e-02
    z[4,1,5]  R1105     -2.4084170162677765e-01
    z[4,1,5]  R1106     -4.0667504072189331e-01
    z[4,1,5]  R1107     -4.5615375041961670e-01
    z[4,1,5]  R1108     -5.0682887434959412e-02
    z[4,1,5]  R1109     -5.3031824529170990e-02
    z[4,1,5]  R1110     -3.7292614579200745e-02
    z[4,1,5]  R1111     1.4203681051731110e-01
    z[4,1,5]  R1112     8.4373086690902710e-02
    z[4,1,5]  R1113     -2.2015558183193207e-01
    z[4,1,5]  R1114     2.3934745788574219e-01
    z[4,1,5]  R1115     1.6793370246887207e-01
    z[4,1,5]  R1116     -5.6633424758911133e-01
    z[4,1,5]  R1117     3.3496430516242981e-01
    z[4,1,5]  R1118     2.1169048547744751e-01
    z[4,1,5]  R1119     -4.8653557896614075e-02
    z[4,1,5]  R1120     -4.1244491934776306e-01
    z[4,1,5]  R1121     8.6037427186965942e-01
    z[4,1,5]  R1122     5.9718143939971924e-01
    z[4,1,5]  R1123     -1.2719912827014923e-01
    z[4,1,5]  R1124     -6.2453597784042358e-03
    z[4,1,5]  R1125     1.5146744251251221e-01
    z[4,1,5]  R1126     1.6857126355171204e-01
    z[4,1,5]  R1127     1.3088262081146240e-01
    z[4,1,5]  R1128     -6.7186409235000610e-01
    z[4,1,5]  R1129     -5.4155224561691284e-01
    z[4,1,5]  R1130     -5.8668041229248047e-01
    z[4,1,5]  R1131     -1.3069508969783783e-01
    z[4,1,5]  R1132     4.7280009835958481e-02
    z[4,1,5]  R1133     -2.4256812036037445e-01
    z[4,1,5]  R1134     1.0398554056882858e-01
    z[4,1,5]  R1135     -0.625950813293457
    z[4,1,5]  R1136     1.0464450716972351e-01
    z[4,1,5]  R1137     -1.2760579586029053e-01
    z[4,1,5]  R1138     2.7487901970744133e-02
    z[4,1,5]  R1139     -1.0926242172718048e-01
    z[4,1,5]  R1140     -9.2612817883491516e-02
    z[4,1,5]  R1141     6.8953827023506165e-02
    z[4,1,5]  R1142     -2.0019227266311646e-01
    z[4,1,5]  R1143     -3.3036354184150696e-01
    z[4,1,5]  R1144     -4.7876381874084473e-01
    z[4,1,5]  R1145     5.3922671824693680e-02
    z[4,1,5]  R1146     -0.264121949672699
    z[4,1,5]  R1147     4.1039773821830750e-01
    z[4,1,5]  R1148     1.3205060362815857e-01
    z[4,1,5]  R1149     0.194817915558815
    z[4,1,5]  R1150     1.7538410425186157e-01
    z[4,1,5]  R1151     6.4642357826232910e-01
    z[4,1,5]  R1152     -2.8103792667388916e-01
    z[4,1,5]  R1153     7.0109167136251926e-03
    z[4,1,5]  R1154     2.3674240708351135e-01
    z[4,1,5]  R1155     7.5311444699764252e-02
    z[4,1,5]  R1156     -2.9498040676116943e-02
    z[4,1,5]  R1157     -6.6754192113876343e-02
    z[4,1,5]  R1158     3.2755106687545776e-01
    z[4,1,5]  R1159     2.3541361093521118e-01
    z[4,1,5]  R1160     -5.1162582635879517e-01
    z[4,1,5]  R1161     -2.5592150166630745e-02
    z[4,1,5]  R1162     -3.0405440926551819e-01
    z[4,1,5]  R1163     8.3945882320404053e-01
    z[4,1,5]  R1164     -6.0283303260803223e-01
    z[4,1,5]  R1165     -5.3239960223436356e-02
    z[4,1,5]  R1166     -6.1507624387741089e-01
    z[4,1,5]  R1167     -3.1253370642662048e-01
    z[4,1,5]  R1168     -3.9272478222846985e-01
    z[4,1,5]  R1169     -3.5361361503601074e-01
    z[4,1,5]  R1170     -3.8169774413108826e-01
    z[4,1,5]  R1171     5.6845819950103760e-01
    z[4,1,5]  R1172     5.1635706424713135e-01
    z[4,1,5]  R1173     -1.0229671746492386e-01
    z[4,1,5]  R1174     -5.7824570685625076e-02
    z[4,1,5]  R1175     -2.8982567787170410e-01
    z[4,1,5]  R1176     1.9826823472976685e-01
    z[4,1,5]  R1177     9.6248477697372437e-02
    z[4,1,5]  R1178     -4.8029392957687378e-01
    z[4,1,5]  R1179     4.1570165753364563e-01
    z[4,1,5]  R1180     -3.5506728291511536e-01
    z[4,1,5]  R1181     2.5812932848930359e-01
    z[4,1,5]  R1182     -2.9577055573463440e-01
    z[4,1,5]  R1183     1.9396256655454636e-02
    z[4,1,5]  R1184     -3.2449653744697571e-01
    z[4,1,5]  R1185     4.2761421203613281e-01
    z[4,1,5]  R1186     -1.7201507091522217e-01
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1099     -1
    z[4,1,6]  R1100     1
    z[4,1,6]  R1101     8.4367677569389343e-02
    z[4,1,6]  R1102     -1.2470804899930954e-01
    z[4,1,6]  R1103     -5.8409009128808975e-02
    z[4,1,6]  R1104     -3.6872607469558716e-01
    z[4,1,6]  R1105     6.4095747470855713e-01
    z[4,1,6]  R1106     -9.9079899489879608e-02
    z[4,1,6]  R1107     5.8955080807209015e-02
    z[4,1,6]  R1108     -2.1402002871036530e-01
    z[4,1,6]  R1109     1.7176277935504913e-01
    z[4,1,6]  R1110     2.3929831385612488e-01
    z[4,1,6]  R1111     -7.0287567377090454e-01
    z[4,1,6]  R1112     -9.5990262925624847e-02
    z[4,1,6]  R1113     -1.5229627490043640e-01
    z[4,1,6]  R1114     9.8155051469802856e-02
    z[4,1,6]  R1115     2.1900594234466553e-01
    z[4,1,6]  R1116     -3.7142071127891541e-01
    z[4,1,6]  R1117     2.2928024828433990e-01
    z[4,1,6]  R1118     3.0301153659820557e-01
    z[4,1,6]  R1119     2.7891201898455620e-03
    z[4,1,6]  R1120     6.1072193086147308e-02
    z[4,1,6]  R1121     3.2782158255577087e-01
    z[4,1,6]  R1122     -2.7677747607231140e-01
    z[4,1,6]  R1123     4.0796067565679550e-02
    z[4,1,6]  R1124     2.3708198964595795e-01
    z[4,1,6]  R1125     -1.0968913137912750e-01
    z[4,1,6]  R1126     -0.0639939159154892
    z[4,1,6]  R1127     1.5299607813358307e-01
    z[4,1,6]  R1128     6.1401624232530594e-02
    z[4,1,6]  R1129     -1.5890444815158844e-01
    z[4,1,6]  R1130     -2.6737222075462341e-01
    z[4,1,6]  R1131     9.0889401733875275e-02
    z[4,1,6]  R1132     -2.5877895951271057e-01
    z[4,1,6]  R1133     -8.0745331943035126e-02
    z[4,1,6]  R1134     0.374576598405838
    z[4,1,6]  R1135     -4.8989301919937134e-01
    z[4,1,6]  R1136     2.0928401499986649e-02
    z[4,1,6]  R1137     -2.4365289136767387e-02
    z[4,1,6]  R1138     2.5289552286267281e-02
    z[4,1,6]  R1139     3.9734715223312378e-01
    z[4,1,6]  R1140     -2.2739601135253906e-01
    z[4,1,6]  R1141     -0.0466383658349514
    z[4,1,6]  R1142     3.5846567153930664e-01
    z[4,1,6]  R1143     1.1906799674034119e-01
    z[4,1,6]  R1144     3.1650140881538391e-02
    z[4,1,6]  R1145     2.6548784971237183e-01
    z[4,1,6]  R1146     -0.406181275844574
    z[4,1,6]  R1147     5.1750767976045609e-02
    z[4,1,6]  R1148     4.2256820201873779e-01
    z[4,1,6]  R1149     -5.2460145950317383e-01
    z[4,1,6]  R1150     -5.5509054660797119e-01
    z[4,1,6]  R1151     2.6183506846427917e-01
    z[4,1,6]  R1152     -1.2222281098365784e-01
    z[4,1,6]  R1153     6.3423417508602142e-02
    z[4,1,6]  R1154     2.3502789437770844e-01
    z[4,1,6]  R1155     -0.00405834149569273
    z[4,1,6]  R1156     -5.1050871610641479e-01
    z[4,1,6]  R1157     0.63865065574646
    z[4,1,6]  R1158     -1.4969493262469769e-02
    z[4,1,6]  R1159     -1.7411597073078156e-01
    z[4,1,6]  R1160     2.0495028793811798e-01
    z[4,1,6]  R1161     3.2708659768104553e-02
    z[4,1,6]  R1162     -5.1327300071716309e-01
    z[4,1,6]  R1163     -3.6908425390720367e-02
    z[4,1,6]  R1164     7.4787355959415436e-02
    z[4,1,6]  R1165     3.2975021004676819e-01
    z[4,1,6]  R1166     -2.9628169536590576e-01
    z[4,1,6]  R1167     -1.2057397514581680e-01
    z[4,1,6]  R1168     3.4699384123086929e-02
    z[4,1,6]  R1169     0.268963485956192
    z[4,1,6]  R1170     -1.2915319204330444e-01
    z[4,1,6]  R1171     1.2269077450037003e-01
    z[4,1,6]  R1172     -3.2819494605064392e-01
    z[4,1,6]  R1173     -2.3916883766651154e-01
    z[4,1,6]  R1174     3.5343545675277710e-01
    z[4,1,6]  R1175     6.0876852273941040e-01
    z[4,1,6]  R1176     6.9648787379264832e-02
    z[4,1,6]  R1177     8.0360412597656250e-02
    z[4,1,6]  R1178     -0.0366581492125988
    z[4,1,6]  R1179     1.7690800130367279e-02
    z[4,1,6]  R1180     4.7874860465526581e-02
    z[4,1,6]  R1181     -2.7707897126674652e-02
    z[4,1,6]  R1182     -4.6995177865028381e-01
    z[4,1,6]  R1183     4.6346601098775864e-02
    z[4,1,6]  R1184     2.3973459377884865e-02
    z[4,1,6]  R1185     0.190284863114357
    z[4,1,6]  R1186     2.4733503162860870e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R1187     -1
    z[1,5,0]  R1188     1
    z[1,5,0]  R1201     -4.3973377346992493e-01
    z[1,5,0]  R1202     -4.6908619999885559e-01
    z[1,5,0]  R1203     -4.6749472618103027e-01
    z[1,5,0]  R1204     -5.9391325712203979e-01
    z[1,5,0]  R1205     -0.438795268535614
    z[1,5,0]  R1206     6.8099820613861084e-01
    z[1,5,0]  R1207     6.4077001810073853e-01
    z[1,5,0]  R1208     7.4334591627120972e-01
    z[1,5,0]  R1209     5.5163621902465820e-01
    z[1,5,0]  R1210     6.8956816196441650e-01
    z[1,5,0]  R1211     -4.7952553629875183e-01
    z[1,5,0]  R1212     -0.32700115442276
    z[1,5,0]  R1213     -2.9756346344947815e-01
    z[1,5,0]  R1214     -3.4690535068511963e-01
    z[1,5,0]  R1215     -2.8038537502288818e-01
    z[1,5,0]  R1216     -4.4638866186141968e-01
    z[1,5,0]  R1217     -4.1364064812660217e-01
    z[1,5,0]  R1218     -0.2532939016819
    z[1,5,0]  R1219     -2.7952659130096436e-01
    z[1,5,0]  R1220     -2.2245080769062042e-01
    z[1,5,0]  R1221     -3.7676227092742920e-01
    z[1,5,0]  R1222     0.478341281414032
    z[1,5,0]  R1223     0.676973283290863
    z[1,5,0]  R1224     4.4680270552635193e-01
    z[1,5,0]  R1225     6.4664644002914429e-01
    z[1,5,0]  R1226     5.7975602149963379e-01
    z[1,5,0]  R1227     0.586368203163147
    z[1,5,0]  R1228     6.0991507768630981e-01
    z[1,5,0]  R1229     0.332193523645401
    z[1,5,0]  R1230     7.2198235988616943e-01
    z[1,5,0]  R1231     1.0257675498723984e-01
    z[1,5,0]  R1232     -2.2947709262371063e-01
    z[1,5,0]  R1233     -3.6362317204475403e-01
    z[1,5,0]  R1234     5.3756457567214966e-01
    z[1,5,0]  R1235     -2.9505431652069092e-02
    z[1,5,0]  R1236     4.5382156968116760e-01
    z[1,5,0]  R1237     2.6670229434967041e-01
    z[1,5,0]  R1238     7.3435842990875244e-01
    z[1,5,0]  R1239     4.9293899536132812e-01
    z[1,5,0]  R1240     6.9068127870559692e-01
    z[1,5,0]  R1241     -5.4931193590164185e-01
    z[1,5,0]  R1242     -3.8923683762550354e-01
    z[1,5,0]  R1243     4.1136839985847473e-01
    z[1,5,0]  R1244     -1.7706157639622688e-02
    z[1,5,0]  R1245     1.2964147329330444e-01
    z[1,5,0]  R1246     2.6234817504882812e-01
    z[1,5,0]  R1247     4.7098869085311890e-01
    z[1,5,0]  R1248     7.0320379734039307e-01
    z[1,5,0]  R1249     4.5568275451660156e-01
    z[1,5,0]  R1250     2.2768758237361908e-01
    z[1,5,0]  R1251     -7.3867177963256836e-01
    z[1,5,0]  R1252     -2.5451815128326416e-01
    z[1,5,0]  R1253     -0.0896846279501915
    z[1,5,0]  R1254     0.797221302986145
    z[1,5,0]  R1255     -4.8959842324256897e-01
    z[1,5,0]  R1256     -6.7485976219177246e-01
    z[1,5,0]  R1257     6.4163106679916382e-01
    z[1,5,0]  R1258     -4.7521561384201050e-01
    z[1,5,0]  R1259     3.3508926630020142e-02
    z[1,5,0]  R1260     -1.4299483597278595e-01
    z[1,5,0]  R1261     -1.6441199183464050e-01
    z[1,5,0]  R1262     -3.4808126091957092e-01
    z[1,5,0]  R1263     -4.0252998471260071e-01
    z[1,5,0]  R1264     -3.0971869826316833e-01
    z[1,5,0]  R1265     -3.2467669248580933e-01
    z[1,5,0]  R1266     -3.5864984989166260e-01
    z[1,5,0]  R1267     -5.7287907600402832e-01
    z[1,5,0]  R1268     -0.325132817029953
    z[1,5,0]  R1269     -4.0381217002868652e-01
    z[1,5,0]  R1270     -0.509609043598175
    z[1,5,0]  R1271     -5.1786619424819946e-01
    z[1,5,0]  R1272     6.9882661104202271e-01
    z[1,5,0]  R1273     -2.2907108068466187e-01
    z[1,5,0]  R1274     -2.9500603675842285e-01
    z[1,5,0]  R1275     5.8432853221893311e-01
    z[1,5,0]  R1276     4.8068276047706604e-01
    z[1,5,0]  R1277     -2.6974228024482727e-01
    z[1,5,0]  R1278     -4.0558192133903503e-01
    z[1,5,0]  R1279     4.4221732020378113e-01
    z[1,5,0]  R1280     4.6138077974319458e-01
    z[1,5,0]  R1281     3.5794076323509216e-01
    z[1,5,0]  R1282     2.1634428203105927e-01
    z[1,5,0]  R1283     -1.5749311447143555e-01
    z[1,5,0]  R1284     -1.0882386937737465e-02
    z[1,5,0]  R1285     2.3076352477073669e-01
    z[1,5,0]  R1286     4.3636098504066467e-01
    z[1,5,0]  R1287     1.2535629794001579e-02
    z[1,5,0]  R1288     3.6885414272546768e-02
    z[1,5,0]  R1289     5.5535793304443359e-01
    z[1,5,0]  R1290     -2.5221186876296997e-01
    z[1,5,0]  R1291     -3.3997863531112671e-02
    z[1,5,0]  R1292     6.9310680031776428e-02
    z[1,5,0]  R1293     -4.5445088297128677e-02
    z[1,5,0]  R1294     -1.1276463419198990e-01
    z[1,5,0]  R1295     1.2360639125108719e-01
    z[1,5,0]  R1296     2.7317786216735840e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R1189     -1
    z[1,5,1]  R1190     1
    z[1,5,1]  R1201     7.0582723617553711e-01
    z[1,5,1]  R1202     7.4835884571075439e-01
    z[1,5,1]  R1203     6.4602726697921753e-01
    z[1,5,1]  R1204     4.0355780720710754e-01
    z[1,5,1]  R1205     2.8929588198661804e-01
    z[1,5,1]  R1206     -1.5599606931209564e-01
    z[1,5,1]  R1207     -2.5938186049461365e-01
    z[1,5,1]  R1208     -2.8838065266609192e-01
    z[1,5,1]  R1209     -2.6488536596298218e-01
    z[1,5,1]  R1210     -1.8207627534866333e-01
    z[1,5,1]  R1211     -0.722950279712677
    z[1,5,1]  R1212     -7.9297041893005371e-01
    z[1,5,1]  R1213     -8.1031274795532227e-01
    z[1,5,1]  R1214     -7.6446080207824707e-01
    z[1,5,1]  R1215     -0.84675532579422
    z[1,5,1]  R1216     -6.3792812824249268e-01
    z[1,5,1]  R1217     -6.0679459571838379e-01
    z[1,5,1]  R1218     -6.9677561521530151e-01
    z[1,5,1]  R1219     -6.4049822092056274e-01
    z[1,5,1]  R1220     -7.5996285676956177e-01
    z[1,5,1]  R1221     3.1034144759178162e-01
    z[1,5,1]  R1222     6.3583391904830933e-01
    z[1,5,1]  R1223     0.596767783164978
    z[1,5,1]  R1224     7.8609246015548706e-01
    z[1,5,1]  R1225     5.6476938724517822e-01
    z[1,5,1]  R1226     4.8868107795715332e-01
    z[1,5,1]  R1227     3.9729556441307068e-01
    z[1,5,1]  R1228     6.6568471491336823e-02
    z[1,5,1]  R1229     -1.3944588601589203e-02
    z[1,5,1]  R1230     1.3699467480182648e-01
    z[1,5,1]  R1231     -7.8468644618988037e-01
    z[1,5,1]  R1232     3.0972850322723389e-01
    z[1,5,1]  R1233     2.8695744276046753e-01
    z[1,5,1]  R1234     1.9082698225975037e-01
    z[1,5,1]  R1235     4.2503336071968079e-01
    z[1,5,1]  R1236     -9.7298972308635712e-02
    z[1,5,1]  R1237     -1.1420476436614990e-01
    z[1,5,1]  R1238     1.7754136025905609e-01
    z[1,5,1]  R1239     -2.3391132056713104e-01
    z[1,5,1]  R1240     2.2367011010646820e-01
    z[1,5,1]  R1241     2.0922964811325073e-01
    z[1,5,1]  R1242     3.7760722637176514e-01
    z[1,5,1]  R1243     -3.3757331967353821e-01
    z[1,5,1]  R1244     5.3565579652786255e-01
    z[1,5,1]  R1245     5.6941163539886475e-01
    z[1,5,1]  R1246     8.3352994918823242e-01
    z[1,5,1]  R1247     3.5133186727762222e-02
    z[1,5,1]  R1248     7.6741680502891541e-02
    z[1,5,1]  R1249     -2.1169431507587433e-02
    z[1,5,1]  R1250     -1.0548040270805359e-01
    z[1,5,1]  R1251     3.7100705504417419e-01
    z[1,5,1]  R1252     6.1308199167251587e-01
    z[1,5,1]  R1253     3.0658674240112305e-01
    z[1,5,1]  R1254     2.2164407372474670e-01
    z[1,5,1]  R1255     7.7359803020954132e-02
    z[1,5,1]  R1256     1.0380051285028458e-01
    z[1,5,1]  R1257     -1.1289706081151962e-01
    z[1,5,1]  R1258     -9.2442803084850311e-02
    z[1,5,1]  R1259     -1.4126157760620117e-01
    z[1,5,1]  R1260     -1.2021017074584961e-01
    z[1,5,1]  R1261     -1.6279260814189911e-01
    z[1,5,1]  R1262     -5.1551878452301025e-02
    z[1,5,1]  R1263     -1.0261062532663345e-01
    z[1,5,1]  R1264     -1.5986080467700958e-01
    z[1,5,1]  R1265     -8.5229448974132538e-02
    z[1,5,1]  R1266     -3.2290231436491013e-02
    z[1,5,1]  R1267     -6.7437601089477539e-01
    z[1,5,1]  R1268     -7.6250630617141724e-01
    z[1,5,1]  R1269     -6.2576764822006226e-01
    z[1,5,1]  R1270     -5.9989112615585327e-01
    z[1,5,1]  R1271     -5.3688186407089233e-01
    z[1,5,1]  R1272     4.8928743600845337e-01
    z[1,5,1]  R1273     -6.5893191099166870e-01
    z[1,5,1]  R1274     -5.7101702690124512e-01
    z[1,5,1]  R1275     1.2074148654937744e-01
    z[1,5,1]  R1276     -2.0272694528102875e-01
    z[1,5,1]  R1277     -7.5885915756225586e-01
    z[1,5,1]  R1278     -5.0641649961471558e-01
    z[1,5,1]  R1279     -3.5411059856414795e-01
    z[1,5,1]  R1280     -2.8774434700608253e-02
    z[1,5,1]  R1281     -4.1485038399696350e-01
    z[1,5,1]  R1282     -4.4661924242973328e-01
    z[1,5,1]  R1283     -7.0320534706115723e-01
    z[1,5,1]  R1284     -4.5102778077125549e-01
    z[1,5,1]  R1285     2.3100256919860840e-01
    z[1,5,1]  R1286     -2.1505138278007507e-01
    z[1,5,1]  R1287     -6.3967871665954590e-01
    z[1,5,1]  R1288     -4.1408398747444153e-01
    z[1,5,1]  R1289     0.520452618598938
    z[1,5,1]  R1290     -2.9941666126251221e-01
    z[1,5,1]  R1291     7.7732527256011963e-01
    z[1,5,1]  R1292     7.9937362670898438e-01
    z[1,5,1]  R1293     7.7364301681518555e-01
    z[1,5,1]  R1294     7.2622382640838623e-01
    z[1,5,1]  R1295     9.0468436479568481e-01
    z[1,5,1]  R1296     8.6709374189376831e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R1191     -1
    z[1,5,2]  R1192     1
    z[1,5,2]  R1201     -0.229117289185524
    z[1,5,2]  R1202     -2.6490619778633118e-01
    z[1,5,2]  R1203     -4.8827031254768372e-01
    z[1,5,2]  R1204     -5.6621521711349487e-01
    z[1,5,2]  R1205     -1.5989576280117035e-01
    z[1,5,2]  R1206     2.4967324733734131e-01
    z[1,5,2]  R1207     3.6085703969001770e-01
    z[1,5,2]  R1208     5.2071553468704224e-01
    z[1,5,2]  R1209     1.2483359873294830e-01
    z[1,5,2]  R1210     5.2010452747344971e-01
    z[1,5,2]  R1211     -9.7651155665516853e-03
    z[1,5,2]  R1212     -3.0187508463859558e-01
    z[1,5,2]  R1213     -2.5007483363151550e-01
    z[1,5,2]  R1214     -1.1067414283752441e-01
    z[1,5,2]  R1215     -1.7438901960849762e-01
    z[1,5,2]  R1216     -1.1787618696689606e-01
    z[1,5,2]  R1217     4.9787878990173340e-02
    z[1,5,2]  R1218     -2.6266448199748993e-02
    z[1,5,2]  R1219     -0.0127011863514781
    z[1,5,2]  R1220     1.0693140327930450e-01
    z[1,5,2]  R1221     -2.6498275995254517e-01
    z[1,5,2]  R1222     -3.5252094268798828e-01
    z[1,5,2]  R1223     -2.2569186985492706e-01
    z[1,5,2]  R1224     0.0648149698972702
    z[1,5,2]  R1225     0.0210171639919281
    z[1,5,2]  R1226     1.3366617262363434e-02
    z[1,5,2]  R1227     -1.1218158155679703e-01
    z[1,5,2]  R1228     9.2862747609615326e-02
    z[1,5,2]  R1229     6.3014000654220581e-01
    z[1,5,2]  R1230     2.3018909990787506e-01
    z[1,5,2]  R1231     6.6623359918594360e-02
    z[1,5,2]  R1232     1.4183364808559418e-01
    z[1,5,2]  R1233     -2.5261448696255684e-02
    z[1,5,2]  R1234     -0.235975444316864
    z[1,5,2]  R1235     -8.3938531577587128e-02
    z[1,5,2]  R1236     9.7031831741333008e-02
    z[1,5,2]  R1237     5.5120289325714111e-01
    z[1,5,2]  R1238     3.6256012320518494e-01
    z[1,5,2]  R1239     0.472822368144989
    z[1,5,2]  R1240     0.268179327249527
    z[1,5,2]  R1241     -2.5414398312568665e-01
    z[1,5,2]  R1242     1.1739699542522430e-01
    z[1,5,2]  R1243     1.4202952384948730e-01
    z[1,5,2]  R1244     -1.2348987907171249e-01
    z[1,5,2]  R1245     -3.3790859580039978e-01
    z[1,5,2]  R1246     -1.2669317424297333e-01
    z[1,5,2]  R1247     -6.8267039954662323e-02
    z[1,5,2]  R1248     2.3709677159786224e-01
    z[1,5,2]  R1249     -3.4693825244903564e-01
    z[1,5,2]  R1250     6.3916486501693726e-01
    z[1,5,2]  R1251     -3.9355117082595825e-01
    z[1,5,2]  R1252     -1.1480126529932022e-02
    z[1,5,2]  R1253     1.7177364230155945e-01
    z[1,5,2]  R1254     3.8163551688194275e-01
    z[1,5,2]  R1255     3.4038397669792175e-01
    z[1,5,2]  R1256     0.566510021686554
    z[1,5,2]  R1257     1.0780003666877747e-01
    z[1,5,2]  R1258     7.3124116659164429e-01
    z[1,5,2]  R1259     5.7421612739562988e-01
    z[1,5,2]  R1260     7.2630625963211060e-01
    z[1,5,2]  R1261     8.1204974651336670e-01
    z[1,5,2]  R1262     7.5538033246994019e-01
    z[1,5,2]  R1263     5.9786844253540039e-01
    z[1,5,2]  R1264     2.2927477955818176e-01
    z[1,5,2]  R1265     4.9712011218070984e-01
    z[1,5,2]  R1266     6.6889148950576782e-01
    z[1,5,2]  R1267     -3.2046550512313843e-01
    z[1,5,2]  R1268     -3.7707009911537170e-01
    z[1,5,2]  R1269     -8.2286477088928223e-02
    z[1,5,2]  R1270     -1.0160498321056366e-01
    z[1,5,2]  R1271     -1.9210581481456757e-01
    z[1,5,2]  R1272     -8.3123147487640381e-02
    z[1,5,2]  R1273     1.7333178222179413e-01
    z[1,5,2]  R1274     -4.6031072735786438e-02
    z[1,5,2]  R1275     -1.3563394546508789e-01
    z[1,5,2]  R1276     -1.3572248630225658e-02
    z[1,5,2]  R1277     3.0794867873191833e-01
    z[1,5,2]  R1278     5.8678197860717773e-01
    z[1,5,2]  R1279     4.4368335604667664e-01
    z[1,5,2]  R1280     -1.2148012965917587e-01
    z[1,5,2]  R1281     -9.4842031598091125e-02
    z[1,5,2]  R1282     5.3951416164636612e-02
    z[1,5,2]  R1283     -2.4943840503692627e-01
    z[1,5,2]  R1284     3.0690962076187134e-01
    z[1,5,2]  R1285     -1.8194435536861420e-01
    z[1,5,2]  R1286     9.2556074261665344e-02
    z[1,5,2]  R1287     5.6087291240692139e-01
    z[1,5,2]  R1288     2.5920915603637695e-01
    z[1,5,2]  R1289     -5.2315410226583481e-02
    z[1,5,2]  R1290     -2.4299649894237518e-01
    z[1,5,2]  R1291     2.8462827205657959e-02
    z[1,5,2]  R1292     -7.9752728343009949e-02
    z[1,5,2]  R1293     -1.9546903669834137e-01
    z[1,5,2]  R1294     -1.6521067917346954e-01
    z[1,5,2]  R1295     2.1789493039250374e-02
    z[1,5,2]  R1296     -7.9349920153617859e-02
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R1193     -1
    z[1,5,3]  R1194     1
    z[1,5,3]  R1201     -2.9019543528556824e-01
    z[1,5,3]  R1202     5.7496611028909683e-02
    z[1,5,3]  R1203     -7.3940992355346680e-02
    z[1,5,3]  R1204     2.4332102388143539e-02
    z[1,5,3]  R1205     -8.6339443922042847e-02
    z[1,5,3]  R1206     0.651769757270813
    z[1,5,3]  R1207     5.7279855012893677e-01
    z[1,5,3]  R1208     2.7020815014839172e-01
    z[1,5,3]  R1209     6.3380479812622070e-01
    z[1,5,3]  R1210     3.6046424508094788e-01
    z[1,5,3]  R1211     -0.477079302072525
    z[1,5,3]  R1212     6.7505910992622375e-02
    z[1,5,3]  R1213     2.5140070915222168e-01
    z[1,5,3]  R1214     -1.8602685630321503e-01
    z[1,5,3]  R1215     -2.1406927704811096e-01
    z[1,5,3]  R1216     -2.8279563784599304e-01
    z[1,5,3]  R1217     -0.0956747829914093
    z[1,5,3]  R1218     -2.6482401415705681e-02
    z[1,5,3]  R1219     -1.0606414824724197e-01
    z[1,5,3]  R1220     1.4834043383598328e-01
    z[1,5,3]  R1221     -3.7804111838340759e-01
    z[1,5,3]  R1222     3.8450878858566284e-01
    z[1,5,3]  R1223     0.0953054204583168
    z[1,5,3]  R1224     1.9266439601778984e-02
    z[1,5,3]  R1225     -3.2006785273551941e-01
    z[1,5,3]  R1226     -3.1716409325599670e-01
    z[1,5,3]  R1227     -2.4189472198486328e-01
    z[1,5,3]  R1228     -4.9281543493270874e-01
    z[1,5,3]  R1229     -4.6805629134178162e-01
    z[1,5,3]  R1230     1.9967010244727135e-02
    z[1,5,3]  R1231     -2.6093193888664246e-01
    z[1,5,3]  R1232     -6.8618077039718628e-01
    z[1,5,3]  R1233     -1.8147185444831848e-01
    z[1,5,3]  R1234     -4.9503338336944580e-01
    z[1,5,3]  R1235     -7.3967504501342773e-01
    z[1,5,3]  R1236     5.1183837652206421e-01
    z[1,5,3]  R1237     -4.9407193064689636e-01
    z[1,5,3]  R1238     -1.5420243144035339e-01
    z[1,5,3]  R1239     -5.0213855504989624e-01
    z[1,5,3]  R1240     3.4624069929122925e-02
    z[1,5,3]  R1241     -0.486905038356781
    z[1,5,3]  R1242     -5.1858031749725342e-01
    z[1,5,3]  R1243     7.9279178380966187e-01
    z[1,5,3]  R1244     -6.5510874986648560e-01
    z[1,5,3]  R1245     2.9931154847145081e-01
    z[1,5,3]  R1246     2.2582674026489258e-01
    z[1,5,3]  R1247     -0.532409131526947
    z[1,5,3]  R1248     1.1730780452489853e-01
    z[1,5,3]  R1249     -2.9757568240165710e-01
    z[1,5,3]  R1250     -6.3120013475418091e-01
    z[1,5,3]  R1251     -2.8670126199722290e-01
    z[1,5,3]  R1252     -4.9086907505989075e-01
    z[1,5,3]  R1253     -9.2673414945602417e-01
    z[1,5,3]  R1254     3.7704259157180786e-02
    z[1,5,3]  R1255     5.6681799888610840e-01
    z[1,5,3]  R1256     2.9143935441970825e-01
    z[1,5,3]  R1257     4.9130353331565857e-01
    z[1,5,3]  R1258     2.1447099745273590e-01
    z[1,5,3]  R1259     7.4778348207473755e-01
    z[1,5,3]  R1260     6.0457760095596313e-01
    z[1,5,3]  R1261     4.8526278138160706e-01
    z[1,5,3]  R1262     2.9882353544235229e-01
    z[1,5,3]  R1263     5.4019653797149658e-01
    z[1,5,3]  R1264     8.5413151979446411e-01
    z[1,5,3]  R1265     7.6380604505538940e-01
    z[1,5,3]  R1266     4.9203363060951233e-01
    z[1,5,3]  R1267     -2.7736705541610718e-01
    z[1,5,3]  R1268     -3.2460939884185791e-01
    z[1,5,3]  R1269     -4.0017729997634888e-01
    z[1,5,3]  R1270     -2.8906232118606567e-01
    z[1,5,3]  R1271     -2.9647415876388550e-01
    z[1,5,3]  R1272     -2.8446659445762634e-01
    z[1,5,3]  R1273     -3.8580140471458435e-01
    z[1,5,3]  R1274     -3.5557079315185547e-01
    z[1,5,3]  R1275     1.0866206884384155e-01
    z[1,5,3]  R1276     3.1090116500854492e-01
    z[1,5,3]  R1277     3.7762907147407532e-01
    z[1,5,3]  R1278     -2.8737068176269531e-01
    z[1,5,3]  R1279     -0.482251912355423
    z[1,5,3]  R1280     3.8285559415817261e-01
    z[1,5,3]  R1281     1.4088337123394012e-01
    z[1,5,3]  R1282     6.6598147153854370e-01
    z[1,5,3]  R1283     4.8683908581733704e-01
    z[1,5,3]  R1284     -1.5552611090242863e-02
    z[1,5,3]  R1285     5.3134995698928833e-01
    z[1,5,3]  R1286     -0.692699134349823
    z[1,5,3]  R1287     3.4966096282005310e-01
    z[1,5,3]  R1288     7.6672458648681641e-01
    z[1,5,3]  R1289     -1.5139228105545044e-01
    z[1,5,3]  R1290     1.5158000588417053e-01
    z[1,5,3]  R1291     -3.5130608081817627e-01
    z[1,5,3]  R1292     -2.8890445828437805e-01
    z[1,5,3]  R1293     -3.2266542315483093e-01
    z[1,5,3]  R1294     -4.8203226923942566e-01
    z[1,5,3]  R1295     -1.9956551492214203e-01
    z[1,5,3]  R1296     -2.9325437545776367e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R1195     -1
    z[1,5,4]  R1196     1
    z[1,5,4]  R1201     3.8261204957962036e-01
    z[1,5,4]  R1202     2.7791008353233337e-01
    z[1,5,4]  R1203     -2.3422902822494507e-01
    z[1,5,4]  R1204     1.0998079180717468e-01
    z[1,5,4]  R1205     2.4276715517044067e-01
    z[1,5,4]  R1206     -1.1566183716058731e-01
    z[1,5,4]  R1207     2.1666100621223450e-01
    z[1,5,4]  R1208     1.3682533800601959e-01
    z[1,5,4]  R1209     1.9600607454776764e-01
    z[1,5,4]  R1210     1.7497076094150543e-01
    z[1,5,4]  R1211     1.1299677938222885e-01
    z[1,5,4]  R1212     -2.8302571736276150e-03
    z[1,5,4]  R1213     0.0761076956987381
    z[1,5,4]  R1214     1.3485226035118103e-01
    z[1,5,4]  R1215     -2.3401015996932983e-01
    z[1,5,4]  R1216     -2.5529021024703979e-01
    z[1,5,4]  R1217     0.527223527431488
    z[1,5,4]  R1218     0.502944827079773
    z[1,5,4]  R1219     -4.3249884247779846e-01
    z[1,5,4]  R1220     -2.5453118607401848e-02
    z[1,5,4]  R1221     -2.4937191605567932e-01
    z[1,5,4]  R1222     2.9429266229271889e-02
    z[1,5,4]  R1223     -3.4854507446289062e-01
    z[1,5,4]  R1224     -2.5800922513008118e-01
    z[1,5,4]  R1225     -3.9282381534576416e-01
    z[1,5,4]  R1226     -2.5062489509582520e-01
    z[1,5,4]  R1227     -1.2206542491912842e-01
    z[1,5,4]  R1228     5.1436161994934082e-01
    z[1,5,4]  R1229     4.3308654427528381e-01
    z[1,5,4]  R1230     -3.2065966725349426e-01
    z[1,5,4]  R1231     -5.4726237058639526e-01
    z[1,5,4]  R1232     -6.7449599504470825e-02
    z[1,5,4]  R1233     2.1403318643569946e-01
    z[1,5,4]  R1234     -6.9757483899593353e-02
    z[1,5,4]  R1235     -3.9082175493240356e-01
    z[1,5,4]  R1236     -2.1698732674121857e-01
    z[1,5,4]  R1237     0.505648136138916
    z[1,5,4]  R1238     -3.4428441524505615e-01
    z[1,5,4]  R1239     1.7090511322021484e-01
    z[1,5,4]  R1240     -4.8727640509605408e-01
    z[1,5,4]  R1241     -1.2089670449495316e-01
    z[1,5,4]  R1242     0.221050426363945
    z[1,5,4]  R1243     2.1512087434530258e-02
    z[1,5,4]  R1244     -3.7427493929862976e-01
    z[1,5,4]  R1245     2.4408282712101936e-02
    z[1,5,4]  R1246     -3.5382375121116638e-01
    z[1,5,4]  R1247     6.8781822919845581e-01
    z[1,5,4]  R1248     -4.4453686475753784e-01
    z[1,5,4]  R1249     6.4020842313766479e-01
    z[1,5,4]  R1250     4.1498217731714249e-02
    z[1,5,4]  R1251     1.1063133925199509e-01
    z[1,5,4]  R1252     -9.9658809602260590e-02
    z[1,5,4]  R1253     -0.0842304676771164
    z[1,5,4]  R1254     -2.4974401295185089e-01
    z[1,5,4]  R1255     -3.1321346759796143e-01
    z[1,5,4]  R1256     -1.9275777041912079e-01
    z[1,5,4]  R1257     -1.6896435990929604e-02
    z[1,5,4]  R1258     1.1893675476312637e-01
    z[1,5,4]  R1259     -2.3363986611366272e-01
    z[1,5,4]  R1260     5.6501183658838272e-02
    z[1,5,4]  R1261     9.9369265139102936e-02
    z[1,5,4]  R1262     -4.2273152619600296e-02
    z[1,5,4]  R1263     2.7650189399719238e-01
    z[1,5,4]  R1264     2.6277473568916321e-01
    z[1,5,4]  R1265     1.0319091379642487e-02
    z[1,5,4]  R1266     -2.1204583346843719e-01
    z[1,5,4]  R1267     -4.3894339352846146e-02
    z[1,5,4]  R1268     1.7493394017219543e-01
    z[1,5,4]  R1269     4.4317370653152466e-01
    z[1,5,4]  R1270     -4.9686712026596069e-01
    z[1,5,4]  R1271     -1.3466018438339233e-01
    z[1,5,4]  R1272     -2.9516938328742981e-01
    z[1,5,4]  R1273     -4.5699611306190491e-01
    z[1,5,4]  R1274     4.1366478800773621e-01
    z[1,5,4]  R1275     -6.9980108737945557e-01
    z[1,5,4]  R1276     6.1890256404876709e-01
    z[1,5,4]  R1277     1.2420323491096497e-01
    z[1,5,4]  R1278     2.1561962366104126e-01
    z[1,5,4]  R1279     -3.3257490396499634e-01
    z[1,5,4]  R1280     -6.7357122898101807e-01
    z[1,5,4]  R1281     -1.0187104344367981e-01
    z[1,5,4]  R1282     -3.2308768481016159e-02
    z[1,5,4]  R1283     -1.1614349484443665e-01
    z[1,5,4]  R1284     0.600644052028656
    z[1,5,4]  R1285     1.2698681652545929e-01
    z[1,5,4]  R1286     -1.6743943095207214e-01
    z[1,5,4]  R1287     -3.3669468760490417e-01
    z[1,5,4]  R1288     9.3967542052268982e-02
    z[1,5,4]  R1289     5.6981366872787476e-01
    z[1,5,4]  R1290     -6.8885219097137451e-01
    z[1,5,4]  R1291     3.9365351200103760e-01
    z[1,5,4]  R1292     4.3954676389694214e-01
    z[1,5,4]  R1293     3.0370175838470459e-01
    z[1,5,4]  R1294     2.0893611013889313e-01
    z[1,5,4]  R1295     2.5418680906295776e-01
    z[1,5,4]  R1296     2.1659302711486816e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R1197     -1
    z[1,5,5]  R1198     1
    z[1,5,5]  R1201     -1.3069508969783783e-01
    z[1,5,5]  R1202     4.7280009835958481e-02
    z[1,5,5]  R1203     -2.4256812036037445e-01
    z[1,5,5]  R1204     1.0398554056882858e-01
    z[1,5,5]  R1205     -0.625950813293457
    z[1,5,5]  R1206     1.0464450716972351e-01
    z[1,5,5]  R1207     -1.2760579586029053e-01
    z[1,5,5]  R1208     2.7487901970744133e-02
    z[1,5,5]  R1209     -1.0926242172718048e-01
    z[1,5,5]  R1210     -9.2612817883491516e-02
    z[1,5,5]  R1211     6.8953827023506165e-02
    z[1,5,5]  R1212     -2.0019227266311646e-01
    z[1,5,5]  R1213     -3.3036354184150696e-01
    z[1,5,5]  R1214     -4.7876381874084473e-01
    z[1,5,5]  R1215     5.3922671824693680e-02
    z[1,5,5]  R1216     -0.264121949672699
    z[1,5,5]  R1217     4.1039773821830750e-01
    z[1,5,5]  R1218     1.3205060362815857e-01
    z[1,5,5]  R1219     0.194817915558815
    z[1,5,5]  R1220     1.7538410425186157e-01
    z[1,5,5]  R1221     6.4642357826232910e-01
    z[1,5,5]  R1222     -2.8103792667388916e-01
    z[1,5,5]  R1223     7.0109167136251926e-03
    z[1,5,5]  R1224     2.3674240708351135e-01
    z[1,5,5]  R1225     7.5311444699764252e-02
    z[1,5,5]  R1226     -2.9498040676116943e-02
    z[1,5,5]  R1227     -6.6754192113876343e-02
    z[1,5,5]  R1228     3.2755106687545776e-01
    z[1,5,5]  R1229     2.3541361093521118e-01
    z[1,5,5]  R1230     -5.1162582635879517e-01
    z[1,5,5]  R1231     -2.5592150166630745e-02
    z[1,5,5]  R1232     -3.0405440926551819e-01
    z[1,5,5]  R1233     8.3945882320404053e-01
    z[1,5,5]  R1234     -6.0283303260803223e-01
    z[1,5,5]  R1235     -5.3239960223436356e-02
    z[1,5,5]  R1236     -6.1507624387741089e-01
    z[1,5,5]  R1237     -3.1253370642662048e-01
    z[1,5,5]  R1238     -3.9272478222846985e-01
    z[1,5,5]  R1239     -3.5361361503601074e-01
    z[1,5,5]  R1240     -3.8169774413108826e-01
    z[1,5,5]  R1241     5.6845819950103760e-01
    z[1,5,5]  R1242     5.1635706424713135e-01
    z[1,5,5]  R1243     -1.0229671746492386e-01
    z[1,5,5]  R1244     -5.7824570685625076e-02
    z[1,5,5]  R1245     -2.8982567787170410e-01
    z[1,5,5]  R1246     1.9826823472976685e-01
    z[1,5,5]  R1247     9.6248477697372437e-02
    z[1,5,5]  R1248     -4.8029392957687378e-01
    z[1,5,5]  R1249     4.1570165753364563e-01
    z[1,5,5]  R1250     -3.5506728291511536e-01
    z[1,5,5]  R1251     2.5812932848930359e-01
    z[1,5,5]  R1252     -2.9577055573463440e-01
    z[1,5,5]  R1253     1.9396256655454636e-02
    z[1,5,5]  R1254     -3.2449653744697571e-01
    z[1,5,5]  R1255     4.2761421203613281e-01
    z[1,5,5]  R1256     -1.7201507091522217e-01
    z[1,5,5]  R1257     -5.6757771968841553e-01
    z[1,5,5]  R1258     -4.1100424528121948e-01
    z[1,5,5]  R1259     -2.3790072649717331e-02
    z[1,5,5]  R1260     -1.7221823334693909e-01
    z[1,5,5]  R1261     -1.4542511105537415e-01
    z[1,5,5]  R1262     -3.0688026547431946e-01
    z[1,5,5]  R1263     -3.0909284949302673e-01
    z[1,5,5]  R1264     -1.3321830332279205e-01
    z[1,5,5]  R1265     -2.3807440698146820e-01
    z[1,5,5]  R1266     -3.6323902010917664e-01
    z[1,5,5]  R1267     7.4424915015697479e-02
    z[1,5,5]  R1268     1.8276399374008179e-01
    z[1,5,5]  R1269     6.3236460089683533e-02
    z[1,5,5]  R1270     -1.7125536501407623e-01
    z[1,5,5]  R1271     -2.3346212506294250e-01
    z[1,5,5]  R1272     1.9256035983562469e-01
    z[1,5,5]  R1273     1.5108166635036469e-01
    z[1,5,5]  R1274     -2.0481450483202934e-02
    z[1,5,5]  R1275     3.4916028380393982e-01
    z[1,5,5]  R1276     4.9116128683090210e-01
    z[1,5,5]  R1277     3.1380828469991684e-02
    z[1,5,5]  R1278     0.325045645236969
    z[1,5,5]  R1279     2.6756852865219116e-01
    z[1,5,5]  R1280     -1.1562506854534149e-01
    z[1,5,5]  R1281     5.1794809103012085e-01
    z[1,5,5]  R1282     4.0950044989585876e-01
    z[1,5,5]  R1283     2.6671406626701355e-01
    z[1,5,5]  R1284     2.3218253254890442e-01
    z[1,5,5]  R1285     5.9344559907913208e-02
    z[1,5,5]  R1286     -4.8516458272933960e-01
    z[1,5,5]  R1287     1.5722188353538513e-01
    z[1,5,5]  R1288     1.4611233770847321e-01
    z[1,5,5]  R1289     -1.0686865448951721e-01
    z[1,5,5]  R1290     5.3440326452255249e-01
    z[1,5,5]  R1291     -3.2610318064689636e-01
    z[1,5,5]  R1292     -1.9234703481197357e-01
    z[1,5,5]  R1293     -3.1847196817398071e-01
    z[1,5,5]  R1294     -3.6189454793930054e-01
    z[1,5,5]  R1295     -2.4750418961048126e-01
    z[1,5,5]  R1296     -1.3576509058475494e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R1199     -1
    z[1,5,6]  R1200     1
    z[1,5,6]  R1201     9.0889401733875275e-02
    z[1,5,6]  R1202     -2.5877895951271057e-01
    z[1,5,6]  R1203     -8.0745331943035126e-02
    z[1,5,6]  R1204     0.374576598405838
    z[1,5,6]  R1205     -4.8989301919937134e-01
    z[1,5,6]  R1206     2.0928401499986649e-02
    z[1,5,6]  R1207     -2.4365289136767387e-02
    z[1,5,6]  R1208     2.5289552286267281e-02
    z[1,5,6]  R1209     3.9734715223312378e-01
    z[1,5,6]  R1210     -2.2739601135253906e-01
    z[1,5,6]  R1211     -0.0466383658349514
    z[1,5,6]  R1212     3.5846567153930664e-01
    z[1,5,6]  R1213     1.1906799674034119e-01
    z[1,5,6]  R1214     3.1650140881538391e-02
    z[1,5,6]  R1215     2.6548784971237183e-01
    z[1,5,6]  R1216     -0.406181275844574
    z[1,5,6]  R1217     5.1750767976045609e-02
    z[1,5,6]  R1218     4.2256820201873779e-01
    z[1,5,6]  R1219     -5.2460145950317383e-01
    z[1,5,6]  R1220     -5.5509054660797119e-01
    z[1,5,6]  R1221     2.6183506846427917e-01
    z[1,5,6]  R1222     -1.2222281098365784e-01
    z[1,5,6]  R1223     6.3423417508602142e-02
    z[1,5,6]  R1224     2.3502789437770844e-01
    z[1,5,6]  R1225     -0.00405834149569273
    z[1,5,6]  R1226     -5.1050871610641479e-01
    z[1,5,6]  R1227     0.63865065574646
    z[1,5,6]  R1228     -1.4969493262469769e-02
    z[1,5,6]  R1229     -1.7411597073078156e-01
    z[1,5,6]  R1230     2.0495028793811798e-01
    z[1,5,6]  R1231     3.2708659768104553e-02
    z[1,5,6]  R1232     -5.1327300071716309e-01
    z[1,5,6]  R1233     -3.6908425390720367e-02
    z[1,5,6]  R1234     7.4787355959415436e-02
    z[1,5,6]  R1235     3.2975021004676819e-01
    z[1,5,6]  R1236     -2.9628169536590576e-01
    z[1,5,6]  R1237     -1.2057397514581680e-01
    z[1,5,6]  R1238     3.4699384123086929e-02
    z[1,5,6]  R1239     0.268963485956192
    z[1,5,6]  R1240     -1.2915319204330444e-01
    z[1,5,6]  R1241     1.2269077450037003e-01
    z[1,5,6]  R1242     -3.2819494605064392e-01
    z[1,5,6]  R1243     -2.3916883766651154e-01
    z[1,5,6]  R1244     3.5343545675277710e-01
    z[1,5,6]  R1245     6.0876852273941040e-01
    z[1,5,6]  R1246     6.9648787379264832e-02
    z[1,5,6]  R1247     8.0360412597656250e-02
    z[1,5,6]  R1248     -0.0366581492125988
    z[1,5,6]  R1249     1.7690800130367279e-02
    z[1,5,6]  R1250     4.7874860465526581e-02
    z[1,5,6]  R1251     -2.7707897126674652e-02
    z[1,5,6]  R1252     -4.6995177865028381e-01
    z[1,5,6]  R1253     4.6346601098775864e-02
    z[1,5,6]  R1254     2.3973459377884865e-02
    z[1,5,6]  R1255     0.190284863114357
    z[1,5,6]  R1256     2.4733503162860870e-01
    z[1,5,6]  R1257     -1.1574598029255867e-02
    z[1,5,6]  R1258     4.2924996465444565e-02
    z[1,5,6]  R1259     -1.8672055006027222e-01
    z[1,5,6]  R1260     -1.9802938401699066e-01
    z[1,5,6]  R1261     1.4331719279289246e-01
    z[1,5,6]  R1262     3.4687790274620056e-01
    z[1,5,6]  R1263     -7.8677006065845490e-02
    z[1,5,6]  R1264     -9.8048657178878784e-02
    z[1,5,6]  R1265     2.6403272058814764e-03
    z[1,5,6]  R1266     -6.2519580125808716e-02
    z[1,5,6]  R1267     1.7300352454185486e-01
    z[1,5,6]  R1268     -3.6265037953853607e-02
    z[1,5,6]  R1269     2.7934902906417847e-01
    z[1,5,6]  R1270     1.0170172154903412e-01
    z[1,5,6]  R1271     -4.9611786007881165e-01
    z[1,5,6]  R1272     2.4536505341529846e-01
    z[1,5,6]  R1273     -3.2058927416801453e-01
    z[1,5,6]  R1274     -5.3555899858474731e-01
    z[1,5,6]  R1275     4.6294897794723511e-02
    z[1,5,6]  R1276     -8.1990055739879608e-02
    z[1,5,6]  R1277     -3.1228914856910706e-01
    z[1,5,6]  R1278     2.0340059418231249e-03
    z[1,5,6]  R1279     -2.5967034697532654e-01
    z[1,5,6]  R1280     -3.9736205339431763e-01
    z[1,5,6]  R1281     6.2632775306701660e-01
    z[1,5,6]  R1282     3.7222284078598022e-01
    z[1,5,6]  R1283     3.1119233369827271e-01
    z[1,5,6]  R1284     5.3603923320770264e-01
    z[1,5,6]  R1285     -7.4719607830047607e-01
    z[1,5,6]  R1286     1.0734346508979797e-01
    z[1,5,6]  R1287     1.2542261183261871e-01
    z[1,5,6]  R1288     -3.7674814462661743e-01
    z[1,5,6]  R1289     -2.4277888238430023e-01
    z[1,5,6]  R1290     -6.7902550101280212e-02
    z[1,5,6]  R1291     -9.5274388790130615e-02
    z[1,5,6]  R1292     1.9019149243831635e-01
    z[1,5,6]  R1293     -2.5185507535934448e-01
    z[1,5,6]  R1294     -1.6003604233264923e-01
    z[1,5,6]  R1295     9.8591828718781471e-03
    z[1,5,6]  R1296     -1.2602771818637848e-01
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1297     -1
    z[5,1,0]  R1298     1
    z[5,1,0]  R1311     6.4163106679916382e-01
    z[5,1,0]  R1312     -4.7521561384201050e-01
    z[5,1,0]  R1313     3.3508926630020142e-02
    z[5,1,0]  R1314     -1.4299483597278595e-01
    z[5,1,0]  R1315     -1.6441199183464050e-01
    z[5,1,0]  R1316     -3.4808126091957092e-01
    z[5,1,0]  R1317     -4.0252998471260071e-01
    z[5,1,0]  R1318     -3.0971869826316833e-01
    z[5,1,0]  R1319     -3.2467669248580933e-01
    z[5,1,0]  R1320     -3.5864984989166260e-01
    z[5,1,0]  R1321     -5.7287907600402832e-01
    z[5,1,0]  R1322     -0.325132817029953
    z[5,1,0]  R1323     -4.0381217002868652e-01
    z[5,1,0]  R1324     -0.509609043598175
    z[5,1,0]  R1325     -5.1786619424819946e-01
    z[5,1,0]  R1326     6.9882661104202271e-01
    z[5,1,0]  R1327     -2.2907108068466187e-01
    z[5,1,0]  R1328     -2.9500603675842285e-01
    z[5,1,0]  R1329     5.8432853221893311e-01
    z[5,1,0]  R1330     4.8068276047706604e-01
    z[5,1,0]  R1331     -2.6974228024482727e-01
    z[5,1,0]  R1332     -4.0558192133903503e-01
    z[5,1,0]  R1333     4.4221732020378113e-01
    z[5,1,0]  R1334     4.6138077974319458e-01
    z[5,1,0]  R1335     3.5794076323509216e-01
    z[5,1,0]  R1336     2.1634428203105927e-01
    z[5,1,0]  R1337     -1.5749311447143555e-01
    z[5,1,0]  R1338     -1.0882386937737465e-02
    z[5,1,0]  R1339     2.3076352477073669e-01
    z[5,1,0]  R1340     4.3636098504066467e-01
    z[5,1,0]  R1341     1.2535629794001579e-02
    z[5,1,0]  R1342     3.6885414272546768e-02
    z[5,1,0]  R1343     5.5535793304443359e-01
    z[5,1,0]  R1344     -2.5221186876296997e-01
    z[5,1,0]  R1345     -3.3997863531112671e-02
    z[5,1,0]  R1346     6.9310680031776428e-02
    z[5,1,0]  R1347     -4.5445088297128677e-02
    z[5,1,0]  R1348     -1.1276463419198990e-01
    z[5,1,0]  R1349     1.2360639125108719e-01
    z[5,1,0]  R1350     2.7317786216735840e-01
    z[5,1,0]  R1351     -4.3973377346992493e-01
    z[5,1,0]  R1352     -4.6908619999885559e-01
    z[5,1,0]  R1353     -4.6749472618103027e-01
    z[5,1,0]  R1354     -5.9391325712203979e-01
    z[5,1,0]  R1355     -0.438795268535614
    z[5,1,0]  R1356     6.8099820613861084e-01
    z[5,1,0]  R1357     6.4077001810073853e-01
    z[5,1,0]  R1358     7.4334591627120972e-01
    z[5,1,0]  R1359     5.5163621902465820e-01
    z[5,1,0]  R1360     6.8956816196441650e-01
    z[5,1,0]  R1361     -4.7952553629875183e-01
    z[5,1,0]  R1362     -0.32700115442276
    z[5,1,0]  R1363     -2.9756346344947815e-01
    z[5,1,0]  R1364     -3.4690535068511963e-01
    z[5,1,0]  R1365     -2.8038537502288818e-01
    z[5,1,0]  R1366     -4.4638866186141968e-01
    z[5,1,0]  R1367     -4.1364064812660217e-01
    z[5,1,0]  R1368     -0.2532939016819
    z[5,1,0]  R1369     -2.7952659130096436e-01
    z[5,1,0]  R1370     -2.2245080769062042e-01
    z[5,1,0]  R1371     -3.7676227092742920e-01
    z[5,1,0]  R1372     0.478341281414032
    z[5,1,0]  R1373     0.676973283290863
    z[5,1,0]  R1374     4.4680270552635193e-01
    z[5,1,0]  R1375     6.4664644002914429e-01
    z[5,1,0]  R1376     5.7975602149963379e-01
    z[5,1,0]  R1377     0.586368203163147
    z[5,1,0]  R1378     6.0991507768630981e-01
    z[5,1,0]  R1379     0.332193523645401
    z[5,1,0]  R1380     7.2198235988616943e-01
    z[5,1,0]  R1381     1.0257675498723984e-01
    z[5,1,0]  R1382     -2.2947709262371063e-01
    z[5,1,0]  R1383     -3.6362317204475403e-01
    z[5,1,0]  R1384     5.3756457567214966e-01
    z[5,1,0]  R1385     -2.9505431652069092e-02
    z[5,1,0]  R1386     4.5382156968116760e-01
    z[5,1,0]  R1387     2.6670229434967041e-01
    z[5,1,0]  R1388     7.3435842990875244e-01
    z[5,1,0]  R1389     4.9293899536132812e-01
    z[5,1,0]  R1390     6.9068127870559692e-01
    z[5,1,0]  R1391     -5.4931193590164185e-01
    z[5,1,0]  R1392     -3.8923683762550354e-01
    z[5,1,0]  R1393     4.1136839985847473e-01
    z[5,1,0]  R1394     -1.7706157639622688e-02
    z[5,1,0]  R1395     1.2964147329330444e-01
    z[5,1,0]  R1396     2.6234817504882812e-01
    z[5,1,0]  R1397     4.7098869085311890e-01
    z[5,1,0]  R1398     7.0320379734039307e-01
    z[5,1,0]  R1399     4.5568275451660156e-01
    z[5,1,0]  R1400     2.2768758237361908e-01
    z[5,1,0]  R1401     -7.3867177963256836e-01
    z[5,1,0]  R1402     -2.5451815128326416e-01
    z[5,1,0]  R1403     -0.0896846279501915
    z[5,1,0]  R1404     0.797221302986145
    z[5,1,0]  R1405     -4.8959842324256897e-01
    z[5,1,0]  R1406     -6.7485976219177246e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1299     -1
    z[5,1,1]  R1300     1
    z[5,1,1]  R1311     -1.1289706081151962e-01
    z[5,1,1]  R1312     -9.2442803084850311e-02
    z[5,1,1]  R1313     -1.4126157760620117e-01
    z[5,1,1]  R1314     -1.2021017074584961e-01
    z[5,1,1]  R1315     -1.6279260814189911e-01
    z[5,1,1]  R1316     -5.1551878452301025e-02
    z[5,1,1]  R1317     -1.0261062532663345e-01
    z[5,1,1]  R1318     -1.5986080467700958e-01
    z[5,1,1]  R1319     -8.5229448974132538e-02
    z[5,1,1]  R1320     -3.2290231436491013e-02
    z[5,1,1]  R1321     -6.7437601089477539e-01
    z[5,1,1]  R1322     -7.6250630617141724e-01
    z[5,1,1]  R1323     -6.2576764822006226e-01
    z[5,1,1]  R1324     -5.9989112615585327e-01
    z[5,1,1]  R1325     -5.3688186407089233e-01
    z[5,1,1]  R1326     4.8928743600845337e-01
    z[5,1,1]  R1327     -6.5893191099166870e-01
    z[5,1,1]  R1328     -5.7101702690124512e-01
    z[5,1,1]  R1329     1.2074148654937744e-01
    z[5,1,1]  R1330     -2.0272694528102875e-01
    z[5,1,1]  R1331     -7.5885915756225586e-01
    z[5,1,1]  R1332     -5.0641649961471558e-01
    z[5,1,1]  R1333     -3.5411059856414795e-01
    z[5,1,1]  R1334     -2.8774434700608253e-02
    z[5,1,1]  R1335     -4.1485038399696350e-01
    z[5,1,1]  R1336     -4.4661924242973328e-01
    z[5,1,1]  R1337     -7.0320534706115723e-01
    z[5,1,1]  R1338     -4.5102778077125549e-01
    z[5,1,1]  R1339     2.3100256919860840e-01
    z[5,1,1]  R1340     -2.1505138278007507e-01
    z[5,1,1]  R1341     -6.3967871665954590e-01
    z[5,1,1]  R1342     -4.1408398747444153e-01
    z[5,1,1]  R1343     0.520452618598938
    z[5,1,1]  R1344     -2.9941666126251221e-01
    z[5,1,1]  R1345     7.7732527256011963e-01
    z[5,1,1]  R1346     7.9937362670898438e-01
    z[5,1,1]  R1347     7.7364301681518555e-01
    z[5,1,1]  R1348     7.2622382640838623e-01
    z[5,1,1]  R1349     9.0468436479568481e-01
    z[5,1,1]  R1350     8.6709374189376831e-01
    z[5,1,1]  R1351     7.0582723617553711e-01
    z[5,1,1]  R1352     7.4835884571075439e-01
    z[5,1,1]  R1353     6.4602726697921753e-01
    z[5,1,1]  R1354     4.0355780720710754e-01
    z[5,1,1]  R1355     2.8929588198661804e-01
    z[5,1,1]  R1356     -1.5599606931209564e-01
    z[5,1,1]  R1357     -2.5938186049461365e-01
    z[5,1,1]  R1358     -2.8838065266609192e-01
    z[5,1,1]  R1359     -2.6488536596298218e-01
    z[5,1,1]  R1360     -1.8207627534866333e-01
    z[5,1,1]  R1361     -0.722950279712677
    z[5,1,1]  R1362     -7.9297041893005371e-01
    z[5,1,1]  R1363     -8.1031274795532227e-01
    z[5,1,1]  R1364     -7.6446080207824707e-01
    z[5,1,1]  R1365     -0.84675532579422
    z[5,1,1]  R1366     -6.3792812824249268e-01
    z[5,1,1]  R1367     -6.0679459571838379e-01
    z[5,1,1]  R1368     -6.9677561521530151e-01
    z[5,1,1]  R1369     -6.4049822092056274e-01
    z[5,1,1]  R1370     -7.5996285676956177e-01
    z[5,1,1]  R1371     3.1034144759178162e-01
    z[5,1,1]  R1372     6.3583391904830933e-01
    z[5,1,1]  R1373     0.596767783164978
    z[5,1,1]  R1374     7.8609246015548706e-01
    z[5,1,1]  R1375     5.6476938724517822e-01
    z[5,1,1]  R1376     4.8868107795715332e-01
    z[5,1,1]  R1377     3.9729556441307068e-01
    z[5,1,1]  R1378     6.6568471491336823e-02
    z[5,1,1]  R1379     -1.3944588601589203e-02
    z[5,1,1]  R1380     1.3699467480182648e-01
    z[5,1,1]  R1381     -7.8468644618988037e-01
    z[5,1,1]  R1382     3.0972850322723389e-01
    z[5,1,1]  R1383     2.8695744276046753e-01
    z[5,1,1]  R1384     1.9082698225975037e-01
    z[5,1,1]  R1385     4.2503336071968079e-01
    z[5,1,1]  R1386     -9.7298972308635712e-02
    z[5,1,1]  R1387     -1.1420476436614990e-01
    z[5,1,1]  R1388     1.7754136025905609e-01
    z[5,1,1]  R1389     -2.3391132056713104e-01
    z[5,1,1]  R1390     2.2367011010646820e-01
    z[5,1,1]  R1391     2.0922964811325073e-01
    z[5,1,1]  R1392     3.7760722637176514e-01
    z[5,1,1]  R1393     -3.3757331967353821e-01
    z[5,1,1]  R1394     5.3565579652786255e-01
    z[5,1,1]  R1395     5.6941163539886475e-01
    z[5,1,1]  R1396     8.3352994918823242e-01
    z[5,1,1]  R1397     3.5133186727762222e-02
    z[5,1,1]  R1398     7.6741680502891541e-02
    z[5,1,1]  R1399     -2.1169431507587433e-02
    z[5,1,1]  R1400     -1.0548040270805359e-01
    z[5,1,1]  R1401     3.7100705504417419e-01
    z[5,1,1]  R1402     6.1308199167251587e-01
    z[5,1,1]  R1403     3.0658674240112305e-01
    z[5,1,1]  R1404     2.2164407372474670e-01
    z[5,1,1]  R1405     7.7359803020954132e-02
    z[5,1,1]  R1406     1.0380051285028458e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1301     -1
    z[5,1,2]  R1302     1
    z[5,1,2]  R1311     1.0780003666877747e-01
    z[5,1,2]  R1312     7.3124116659164429e-01
    z[5,1,2]  R1313     5.7421612739562988e-01
    z[5,1,2]  R1314     7.2630625963211060e-01
    z[5,1,2]  R1315     8.1204974651336670e-01
    z[5,1,2]  R1316     7.5538033246994019e-01
    z[5,1,2]  R1317     5.9786844253540039e-01
    z[5,1,2]  R1318     2.2927477955818176e-01
    z[5,1,2]  R1319     4.9712011218070984e-01
    z[5,1,2]  R1320     6.6889148950576782e-01
    z[5,1,2]  R1321     -3.2046550512313843e-01
    z[5,1,2]  R1322     -3.7707009911537170e-01
    z[5,1,2]  R1323     -8.2286477088928223e-02
    z[5,1,2]  R1324     -1.0160498321056366e-01
    z[5,1,2]  R1325     -1.9210581481456757e-01
    z[5,1,2]  R1326     -8.3123147487640381e-02
    z[5,1,2]  R1327     1.7333178222179413e-01
    z[5,1,2]  R1328     -4.6031072735786438e-02
    z[5,1,2]  R1329     -1.3563394546508789e-01
    z[5,1,2]  R1330     -1.3572248630225658e-02
    z[5,1,2]  R1331     3.0794867873191833e-01
    z[5,1,2]  R1332     5.8678197860717773e-01
    z[5,1,2]  R1333     4.4368335604667664e-01
    z[5,1,2]  R1334     -1.2148012965917587e-01
    z[5,1,2]  R1335     -9.4842031598091125e-02
    z[5,1,2]  R1336     5.3951416164636612e-02
    z[5,1,2]  R1337     -2.4943840503692627e-01
    z[5,1,2]  R1338     3.0690962076187134e-01
    z[5,1,2]  R1339     -1.8194435536861420e-01
    z[5,1,2]  R1340     9.2556074261665344e-02
    z[5,1,2]  R1341     5.6087291240692139e-01
    z[5,1,2]  R1342     2.5920915603637695e-01
    z[5,1,2]  R1343     -5.2315410226583481e-02
    z[5,1,2]  R1344     -2.4299649894237518e-01
    z[5,1,2]  R1345     2.8462827205657959e-02
    z[5,1,2]  R1346     -7.9752728343009949e-02
    z[5,1,2]  R1347     -1.9546903669834137e-01
    z[5,1,2]  R1348     -1.6521067917346954e-01
    z[5,1,2]  R1349     2.1789493039250374e-02
    z[5,1,2]  R1350     -7.9349920153617859e-02
    z[5,1,2]  R1351     -0.229117289185524
    z[5,1,2]  R1352     -2.6490619778633118e-01
    z[5,1,2]  R1353     -4.8827031254768372e-01
    z[5,1,2]  R1354     -5.6621521711349487e-01
    z[5,1,2]  R1355     -1.5989576280117035e-01
    z[5,1,2]  R1356     2.4967324733734131e-01
    z[5,1,2]  R1357     3.6085703969001770e-01
    z[5,1,2]  R1358     5.2071553468704224e-01
    z[5,1,2]  R1359     1.2483359873294830e-01
    z[5,1,2]  R1360     5.2010452747344971e-01
    z[5,1,2]  R1361     -9.7651155665516853e-03
    z[5,1,2]  R1362     -3.0187508463859558e-01
    z[5,1,2]  R1363     -2.5007483363151550e-01
    z[5,1,2]  R1364     -1.1067414283752441e-01
    z[5,1,2]  R1365     -1.7438901960849762e-01
    z[5,1,2]  R1366     -1.1787618696689606e-01
    z[5,1,2]  R1367     4.9787878990173340e-02
    z[5,1,2]  R1368     -2.6266448199748993e-02
    z[5,1,2]  R1369     -0.0127011863514781
    z[5,1,2]  R1370     1.0693140327930450e-01
    z[5,1,2]  R1371     -2.6498275995254517e-01
    z[5,1,2]  R1372     -3.5252094268798828e-01
    z[5,1,2]  R1373     -2.2569186985492706e-01
    z[5,1,2]  R1374     0.0648149698972702
    z[5,1,2]  R1375     0.0210171639919281
    z[5,1,2]  R1376     1.3366617262363434e-02
    z[5,1,2]  R1377     -1.1218158155679703e-01
    z[5,1,2]  R1378     9.2862747609615326e-02
    z[5,1,2]  R1379     6.3014000654220581e-01
    z[5,1,2]  R1380     2.3018909990787506e-01
    z[5,1,2]  R1381     6.6623359918594360e-02
    z[5,1,2]  R1382     1.4183364808559418e-01
    z[5,1,2]  R1383     -2.5261448696255684e-02
    z[5,1,2]  R1384     -0.235975444316864
    z[5,1,2]  R1385     -8.3938531577587128e-02
    z[5,1,2]  R1386     9.7031831741333008e-02
    z[5,1,2]  R1387     5.5120289325714111e-01
    z[5,1,2]  R1388     3.6256012320518494e-01
    z[5,1,2]  R1389     0.472822368144989
    z[5,1,2]  R1390     0.268179327249527
    z[5,1,2]  R1391     -2.5414398312568665e-01
    z[5,1,2]  R1392     1.1739699542522430e-01
    z[5,1,2]  R1393     1.4202952384948730e-01
    z[5,1,2]  R1394     -1.2348987907171249e-01
    z[5,1,2]  R1395     -3.3790859580039978e-01
    z[5,1,2]  R1396     -1.2669317424297333e-01
    z[5,1,2]  R1397     -6.8267039954662323e-02
    z[5,1,2]  R1398     2.3709677159786224e-01
    z[5,1,2]  R1399     -3.4693825244903564e-01
    z[5,1,2]  R1400     6.3916486501693726e-01
    z[5,1,2]  R1401     -3.9355117082595825e-01
    z[5,1,2]  R1402     -1.1480126529932022e-02
    z[5,1,2]  R1403     1.7177364230155945e-01
    z[5,1,2]  R1404     3.8163551688194275e-01
    z[5,1,2]  R1405     3.4038397669792175e-01
    z[5,1,2]  R1406     0.566510021686554
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1303     -1
    z[5,1,3]  R1304     1
    z[5,1,3]  R1311     4.9130353331565857e-01
    z[5,1,3]  R1312     2.1447099745273590e-01
    z[5,1,3]  R1313     7.4778348207473755e-01
    z[5,1,3]  R1314     6.0457760095596313e-01
    z[5,1,3]  R1315     4.8526278138160706e-01
    z[5,1,3]  R1316     2.9882353544235229e-01
    z[5,1,3]  R1317     5.4019653797149658e-01
    z[5,1,3]  R1318     8.5413151979446411e-01
    z[5,1,3]  R1319     7.6380604505538940e-01
    z[5,1,3]  R1320     4.9203363060951233e-01
    z[5,1,3]  R1321     -2.7736705541610718e-01
    z[5,1,3]  R1322     -3.2460939884185791e-01
    z[5,1,3]  R1323     -4.0017729997634888e-01
    z[5,1,3]  R1324     -2.8906232118606567e-01
    z[5,1,3]  R1325     -2.9647415876388550e-01
    z[5,1,3]  R1326     -2.8446659445762634e-01
    z[5,1,3]  R1327     -3.8580140471458435e-01
    z[5,1,3]  R1328     -3.5557079315185547e-01
    z[5,1,3]  R1329     1.0866206884384155e-01
    z[5,1,3]  R1330     3.1090116500854492e-01
    z[5,1,3]  R1331     3.7762907147407532e-01
    z[5,1,3]  R1332     -2.8737068176269531e-01
    z[5,1,3]  R1333     -0.482251912355423
    z[5,1,3]  R1334     3.8285559415817261e-01
    z[5,1,3]  R1335     1.4088337123394012e-01
    z[5,1,3]  R1336     6.6598147153854370e-01
    z[5,1,3]  R1337     4.8683908581733704e-01
    z[5,1,3]  R1338     -1.5552611090242863e-02
    z[5,1,3]  R1339     5.3134995698928833e-01
    z[5,1,3]  R1340     -0.692699134349823
    z[5,1,3]  R1341     3.4966096282005310e-01
    z[5,1,3]  R1342     7.6672458648681641e-01
    z[5,1,3]  R1343     -1.5139228105545044e-01
    z[5,1,3]  R1344     1.5158000588417053e-01
    z[5,1,3]  R1345     -3.5130608081817627e-01
    z[5,1,3]  R1346     -2.8890445828437805e-01
    z[5,1,3]  R1347     -3.2266542315483093e-01
    z[5,1,3]  R1348     -4.8203226923942566e-01
    z[5,1,3]  R1349     -1.9956551492214203e-01
    z[5,1,3]  R1350     -2.9325437545776367e-01
    z[5,1,3]  R1351     -2.9019543528556824e-01
    z[5,1,3]  R1352     5.7496611028909683e-02
    z[5,1,3]  R1353     -7.3940992355346680e-02
    z[5,1,3]  R1354     2.4332102388143539e-02
    z[5,1,3]  R1355     -8.6339443922042847e-02
    z[5,1,3]  R1356     0.651769757270813
    z[5,1,3]  R1357     5.7279855012893677e-01
    z[5,1,3]  R1358     2.7020815014839172e-01
    z[5,1,3]  R1359     6.3380479812622070e-01
    z[5,1,3]  R1360     3.6046424508094788e-01
    z[5,1,3]  R1361     -0.477079302072525
    z[5,1,3]  R1362     6.7505910992622375e-02
    z[5,1,3]  R1363     2.5140070915222168e-01
    z[5,1,3]  R1364     -1.8602685630321503e-01
    z[5,1,3]  R1365     -2.1406927704811096e-01
    z[5,1,3]  R1366     -2.8279563784599304e-01
    z[5,1,3]  R1367     -0.0956747829914093
    z[5,1,3]  R1368     -2.6482401415705681e-02
    z[5,1,3]  R1369     -1.0606414824724197e-01
    z[5,1,3]  R1370     1.4834043383598328e-01
    z[5,1,3]  R1371     -3.7804111838340759e-01
    z[5,1,3]  R1372     3.8450878858566284e-01
    z[5,1,3]  R1373     0.0953054204583168
    z[5,1,3]  R1374     1.9266439601778984e-02
    z[5,1,3]  R1375     -3.2006785273551941e-01
    z[5,1,3]  R1376     -3.1716409325599670e-01
    z[5,1,3]  R1377     -2.4189472198486328e-01
    z[5,1,3]  R1378     -4.9281543493270874e-01
    z[5,1,3]  R1379     -4.6805629134178162e-01
    z[5,1,3]  R1380     1.9967010244727135e-02
    z[5,1,3]  R1381     -2.6093193888664246e-01
    z[5,1,3]  R1382     -6.8618077039718628e-01
    z[5,1,3]  R1383     -1.8147185444831848e-01
    z[5,1,3]  R1384     -4.9503338336944580e-01
    z[5,1,3]  R1385     -7.3967504501342773e-01
    z[5,1,3]  R1386     5.1183837652206421e-01
    z[5,1,3]  R1387     -4.9407193064689636e-01
    z[5,1,3]  R1388     -1.5420243144035339e-01
    z[5,1,3]  R1389     -5.0213855504989624e-01
    z[5,1,3]  R1390     3.4624069929122925e-02
    z[5,1,3]  R1391     -0.486905038356781
    z[5,1,3]  R1392     -5.1858031749725342e-01
    z[5,1,3]  R1393     7.9279178380966187e-01
    z[5,1,3]  R1394     -6.5510874986648560e-01
    z[5,1,3]  R1395     2.9931154847145081e-01
    z[5,1,3]  R1396     2.2582674026489258e-01
    z[5,1,3]  R1397     -0.532409131526947
    z[5,1,3]  R1398     1.1730780452489853e-01
    z[5,1,3]  R1399     -2.9757568240165710e-01
    z[5,1,3]  R1400     -6.3120013475418091e-01
    z[5,1,3]  R1401     -2.8670126199722290e-01
    z[5,1,3]  R1402     -4.9086907505989075e-01
    z[5,1,3]  R1403     -9.2673414945602417e-01
    z[5,1,3]  R1404     3.7704259157180786e-02
    z[5,1,3]  R1405     5.6681799888610840e-01
    z[5,1,3]  R1406     2.9143935441970825e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1305     -1
    z[5,1,4]  R1306     1
    z[5,1,4]  R1311     -1.6896435990929604e-02
    z[5,1,4]  R1312     1.1893675476312637e-01
    z[5,1,4]  R1313     -2.3363986611366272e-01
    z[5,1,4]  R1314     5.6501183658838272e-02
    z[5,1,4]  R1315     9.9369265139102936e-02
    z[5,1,4]  R1316     -4.2273152619600296e-02
    z[5,1,4]  R1317     2.7650189399719238e-01
    z[5,1,4]  R1318     2.6277473568916321e-01
    z[5,1,4]  R1319     1.0319091379642487e-02
    z[5,1,4]  R1320     -2.1204583346843719e-01
    z[5,1,4]  R1321     -4.3894339352846146e-02
    z[5,1,4]  R1322     1.7493394017219543e-01
    z[5,1,4]  R1323     4.4317370653152466e-01
    z[5,1,4]  R1324     -4.9686712026596069e-01
    z[5,1,4]  R1325     -1.3466018438339233e-01
    z[5,1,4]  R1326     -2.9516938328742981e-01
    z[5,1,4]  R1327     -4.5699611306190491e-01
    z[5,1,4]  R1328     4.1366478800773621e-01
    z[5,1,4]  R1329     -6.9980108737945557e-01
    z[5,1,4]  R1330     6.1890256404876709e-01
    z[5,1,4]  R1331     1.2420323491096497e-01
    z[5,1,4]  R1332     2.1561962366104126e-01
    z[5,1,4]  R1333     -3.3257490396499634e-01
    z[5,1,4]  R1334     -6.7357122898101807e-01
    z[5,1,4]  R1335     -1.0187104344367981e-01
    z[5,1,4]  R1336     -3.2308768481016159e-02
    z[5,1,4]  R1337     -1.1614349484443665e-01
    z[5,1,4]  R1338     0.600644052028656
    z[5,1,4]  R1339     1.2698681652545929e-01
    z[5,1,4]  R1340     -1.6743943095207214e-01
    z[5,1,4]  R1341     -3.3669468760490417e-01
    z[5,1,4]  R1342     9.3967542052268982e-02
    z[5,1,4]  R1343     5.6981366872787476e-01
    z[5,1,4]  R1344     -6.8885219097137451e-01
    z[5,1,4]  R1345     3.9365351200103760e-01
    z[5,1,4]  R1346     4.3954676389694214e-01
    z[5,1,4]  R1347     3.0370175838470459e-01
    z[5,1,4]  R1348     2.0893611013889313e-01
    z[5,1,4]  R1349     2.5418680906295776e-01
    z[5,1,4]  R1350     2.1659302711486816e-01
    z[5,1,4]  R1351     3.8261204957962036e-01
    z[5,1,4]  R1352     2.7791008353233337e-01
    z[5,1,4]  R1353     -2.3422902822494507e-01
    z[5,1,4]  R1354     1.0998079180717468e-01
    z[5,1,4]  R1355     2.4276715517044067e-01
    z[5,1,4]  R1356     -1.1566183716058731e-01
    z[5,1,4]  R1357     2.1666100621223450e-01
    z[5,1,4]  R1358     1.3682533800601959e-01
    z[5,1,4]  R1359     1.9600607454776764e-01
    z[5,1,4]  R1360     1.7497076094150543e-01
    z[5,1,4]  R1361     1.1299677938222885e-01
    z[5,1,4]  R1362     -2.8302571736276150e-03
    z[5,1,4]  R1363     0.0761076956987381
    z[5,1,4]  R1364     1.3485226035118103e-01
    z[5,1,4]  R1365     -2.3401015996932983e-01
    z[5,1,4]  R1366     -2.5529021024703979e-01
    z[5,1,4]  R1367     0.527223527431488
    z[5,1,4]  R1368     0.502944827079773
    z[5,1,4]  R1369     -4.3249884247779846e-01
    z[5,1,4]  R1370     -2.5453118607401848e-02
    z[5,1,4]  R1371     -2.4937191605567932e-01
    z[5,1,4]  R1372     2.9429266229271889e-02
    z[5,1,4]  R1373     -3.4854507446289062e-01
    z[5,1,4]  R1374     -2.5800922513008118e-01
    z[5,1,4]  R1375     -3.9282381534576416e-01
    z[5,1,4]  R1376     -2.5062489509582520e-01
    z[5,1,4]  R1377     -1.2206542491912842e-01
    z[5,1,4]  R1378     5.1436161994934082e-01
    z[5,1,4]  R1379     4.3308654427528381e-01
    z[5,1,4]  R1380     -3.2065966725349426e-01
    z[5,1,4]  R1381     -5.4726237058639526e-01
    z[5,1,4]  R1382     -6.7449599504470825e-02
    z[5,1,4]  R1383     2.1403318643569946e-01
    z[5,1,4]  R1384     -6.9757483899593353e-02
    z[5,1,4]  R1385     -3.9082175493240356e-01
    z[5,1,4]  R1386     -2.1698732674121857e-01
    z[5,1,4]  R1387     0.505648136138916
    z[5,1,4]  R1388     -3.4428441524505615e-01
    z[5,1,4]  R1389     1.7090511322021484e-01
    z[5,1,4]  R1390     -4.8727640509605408e-01
    z[5,1,4]  R1391     -1.2089670449495316e-01
    z[5,1,4]  R1392     0.221050426363945
    z[5,1,4]  R1393     2.1512087434530258e-02
    z[5,1,4]  R1394     -3.7427493929862976e-01
    z[5,1,4]  R1395     2.4408282712101936e-02
    z[5,1,4]  R1396     -3.5382375121116638e-01
    z[5,1,4]  R1397     6.8781822919845581e-01
    z[5,1,4]  R1398     -4.4453686475753784e-01
    z[5,1,4]  R1399     6.4020842313766479e-01
    z[5,1,4]  R1400     4.1498217731714249e-02
    z[5,1,4]  R1401     1.1063133925199509e-01
    z[5,1,4]  R1402     -9.9658809602260590e-02
    z[5,1,4]  R1403     -0.0842304676771164
    z[5,1,4]  R1404     -2.4974401295185089e-01
    z[5,1,4]  R1405     -3.1321346759796143e-01
    z[5,1,4]  R1406     -1.9275777041912079e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1307     -1
    z[5,1,5]  R1308     1
    z[5,1,5]  R1311     -5.6757771968841553e-01
    z[5,1,5]  R1312     -4.1100424528121948e-01
    z[5,1,5]  R1313     -2.3790072649717331e-02
    z[5,1,5]  R1314     -1.7221823334693909e-01
    z[5,1,5]  R1315     -1.4542511105537415e-01
    z[5,1,5]  R1316     -3.0688026547431946e-01
    z[5,1,5]  R1317     -3.0909284949302673e-01
    z[5,1,5]  R1318     -1.3321830332279205e-01
    z[5,1,5]  R1319     -2.3807440698146820e-01
    z[5,1,5]  R1320     -3.6323902010917664e-01
    z[5,1,5]  R1321     7.4424915015697479e-02
    z[5,1,5]  R1322     1.8276399374008179e-01
    z[5,1,5]  R1323     6.3236460089683533e-02
    z[5,1,5]  R1324     -1.7125536501407623e-01
    z[5,1,5]  R1325     -2.3346212506294250e-01
    z[5,1,5]  R1326     1.9256035983562469e-01
    z[5,1,5]  R1327     1.5108166635036469e-01
    z[5,1,5]  R1328     -2.0481450483202934e-02
    z[5,1,5]  R1329     3.4916028380393982e-01
    z[5,1,5]  R1330     4.9116128683090210e-01
    z[5,1,5]  R1331     3.1380828469991684e-02
    z[5,1,5]  R1332     0.325045645236969
    z[5,1,5]  R1333     2.6756852865219116e-01
    z[5,1,5]  R1334     -1.1562506854534149e-01
    z[5,1,5]  R1335     5.1794809103012085e-01
    z[5,1,5]  R1336     4.0950044989585876e-01
    z[5,1,5]  R1337     2.6671406626701355e-01
    z[5,1,5]  R1338     2.3218253254890442e-01
    z[5,1,5]  R1339     5.9344559907913208e-02
    z[5,1,5]  R1340     -4.8516458272933960e-01
    z[5,1,5]  R1341     1.5722188353538513e-01
    z[5,1,5]  R1342     1.4611233770847321e-01
    z[5,1,5]  R1343     -1.0686865448951721e-01
    z[5,1,5]  R1344     5.3440326452255249e-01
    z[5,1,5]  R1345     -3.2610318064689636e-01
    z[5,1,5]  R1346     -1.9234703481197357e-01
    z[5,1,5]  R1347     -3.1847196817398071e-01
    z[5,1,5]  R1348     -3.6189454793930054e-01
    z[5,1,5]  R1349     -2.4750418961048126e-01
    z[5,1,5]  R1350     -1.3576509058475494e-01
    z[5,1,5]  R1351     -1.3069508969783783e-01
    z[5,1,5]  R1352     4.7280009835958481e-02
    z[5,1,5]  R1353     -2.4256812036037445e-01
    z[5,1,5]  R1354     1.0398554056882858e-01
    z[5,1,5]  R1355     -0.625950813293457
    z[5,1,5]  R1356     1.0464450716972351e-01
    z[5,1,5]  R1357     -1.2760579586029053e-01
    z[5,1,5]  R1358     2.7487901970744133e-02
    z[5,1,5]  R1359     -1.0926242172718048e-01
    z[5,1,5]  R1360     -9.2612817883491516e-02
    z[5,1,5]  R1361     6.8953827023506165e-02
    z[5,1,5]  R1362     -2.0019227266311646e-01
    z[5,1,5]  R1363     -3.3036354184150696e-01
    z[5,1,5]  R1364     -4.7876381874084473e-01
    z[5,1,5]  R1365     5.3922671824693680e-02
    z[5,1,5]  R1366     -0.264121949672699
    z[5,1,5]  R1367     4.1039773821830750e-01
    z[5,1,5]  R1368     1.3205060362815857e-01
    z[5,1,5]  R1369     0.194817915558815
    z[5,1,5]  R1370     1.7538410425186157e-01
    z[5,1,5]  R1371     6.4642357826232910e-01
    z[5,1,5]  R1372     -2.8103792667388916e-01
    z[5,1,5]  R1373     7.0109167136251926e-03
    z[5,1,5]  R1374     2.3674240708351135e-01
    z[5,1,5]  R1375     7.5311444699764252e-02
    z[5,1,5]  R1376     -2.9498040676116943e-02
    z[5,1,5]  R1377     -6.6754192113876343e-02
    z[5,1,5]  R1378     3.2755106687545776e-01
    z[5,1,5]  R1379     2.3541361093521118e-01
    z[5,1,5]  R1380     -5.1162582635879517e-01
    z[5,1,5]  R1381     -2.5592150166630745e-02
    z[5,1,5]  R1382     -3.0405440926551819e-01
    z[5,1,5]  R1383     8.3945882320404053e-01
    z[5,1,5]  R1384     -6.0283303260803223e-01
    z[5,1,5]  R1385     -5.3239960223436356e-02
    z[5,1,5]  R1386     -6.1507624387741089e-01
    z[5,1,5]  R1387     -3.1253370642662048e-01
    z[5,1,5]  R1388     -3.9272478222846985e-01
    z[5,1,5]  R1389     -3.5361361503601074e-01
    z[5,1,5]  R1390     -3.8169774413108826e-01
    z[5,1,5]  R1391     5.6845819950103760e-01
    z[5,1,5]  R1392     5.1635706424713135e-01
    z[5,1,5]  R1393     -1.0229671746492386e-01
    z[5,1,5]  R1394     -5.7824570685625076e-02
    z[5,1,5]  R1395     -2.8982567787170410e-01
    z[5,1,5]  R1396     1.9826823472976685e-01
    z[5,1,5]  R1397     9.6248477697372437e-02
    z[5,1,5]  R1398     -4.8029392957687378e-01
    z[5,1,5]  R1399     4.1570165753364563e-01
    z[5,1,5]  R1400     -3.5506728291511536e-01
    z[5,1,5]  R1401     2.5812932848930359e-01
    z[5,1,5]  R1402     -2.9577055573463440e-01
    z[5,1,5]  R1403     1.9396256655454636e-02
    z[5,1,5]  R1404     -3.2449653744697571e-01
    z[5,1,5]  R1405     4.2761421203613281e-01
    z[5,1,5]  R1406     -1.7201507091522217e-01
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1309     -1
    z[5,1,6]  R1310     1
    z[5,1,6]  R1311     -1.1574598029255867e-02
    z[5,1,6]  R1312     4.2924996465444565e-02
    z[5,1,6]  R1313     -1.8672055006027222e-01
    z[5,1,6]  R1314     -1.9802938401699066e-01
    z[5,1,6]  R1315     1.4331719279289246e-01
    z[5,1,6]  R1316     3.4687790274620056e-01
    z[5,1,6]  R1317     -7.8677006065845490e-02
    z[5,1,6]  R1318     -9.8048657178878784e-02
    z[5,1,6]  R1319     2.6403272058814764e-03
    z[5,1,6]  R1320     -6.2519580125808716e-02
    z[5,1,6]  R1321     1.7300352454185486e-01
    z[5,1,6]  R1322     -3.6265037953853607e-02
    z[5,1,6]  R1323     2.7934902906417847e-01
    z[5,1,6]  R1324     1.0170172154903412e-01
    z[5,1,6]  R1325     -4.9611786007881165e-01
    z[5,1,6]  R1326     2.4536505341529846e-01
    z[5,1,6]  R1327     -3.2058927416801453e-01
    z[5,1,6]  R1328     -5.3555899858474731e-01
    z[5,1,6]  R1329     4.6294897794723511e-02
    z[5,1,6]  R1330     -8.1990055739879608e-02
    z[5,1,6]  R1331     -3.1228914856910706e-01
    z[5,1,6]  R1332     2.0340059418231249e-03
    z[5,1,6]  R1333     -2.5967034697532654e-01
    z[5,1,6]  R1334     -3.9736205339431763e-01
    z[5,1,6]  R1335     6.2632775306701660e-01
    z[5,1,6]  R1336     3.7222284078598022e-01
    z[5,1,6]  R1337     3.1119233369827271e-01
    z[5,1,6]  R1338     5.3603923320770264e-01
    z[5,1,6]  R1339     -7.4719607830047607e-01
    z[5,1,6]  R1340     1.0734346508979797e-01
    z[5,1,6]  R1341     1.2542261183261871e-01
    z[5,1,6]  R1342     -3.7674814462661743e-01
    z[5,1,6]  R1343     -2.4277888238430023e-01
    z[5,1,6]  R1344     -6.7902550101280212e-02
    z[5,1,6]  R1345     -9.5274388790130615e-02
    z[5,1,6]  R1346     1.9019149243831635e-01
    z[5,1,6]  R1347     -2.5185507535934448e-01
    z[5,1,6]  R1348     -1.6003604233264923e-01
    z[5,1,6]  R1349     9.8591828718781471e-03
    z[5,1,6]  R1350     -1.2602771818637848e-01
    z[5,1,6]  R1351     9.0889401733875275e-02
    z[5,1,6]  R1352     -2.5877895951271057e-01
    z[5,1,6]  R1353     -8.0745331943035126e-02
    z[5,1,6]  R1354     0.374576598405838
    z[5,1,6]  R1355     -4.8989301919937134e-01
    z[5,1,6]  R1356     2.0928401499986649e-02
    z[5,1,6]  R1357     -2.4365289136767387e-02
    z[5,1,6]  R1358     2.5289552286267281e-02
    z[5,1,6]  R1359     3.9734715223312378e-01
    z[5,1,6]  R1360     -2.2739601135253906e-01
    z[5,1,6]  R1361     -0.0466383658349514
    z[5,1,6]  R1362     3.5846567153930664e-01
    z[5,1,6]  R1363     1.1906799674034119e-01
    z[5,1,6]  R1364     3.1650140881538391e-02
    z[5,1,6]  R1365     2.6548784971237183e-01
    z[5,1,6]  R1366     -0.406181275844574
    z[5,1,6]  R1367     5.1750767976045609e-02
    z[5,1,6]  R1368     4.2256820201873779e-01
    z[5,1,6]  R1369     -5.2460145950317383e-01
    z[5,1,6]  R1370     -5.5509054660797119e-01
    z[5,1,6]  R1371     2.6183506846427917e-01
    z[5,1,6]  R1372     -1.2222281098365784e-01
    z[5,1,6]  R1373     6.3423417508602142e-02
    z[5,1,6]  R1374     2.3502789437770844e-01
    z[5,1,6]  R1375     -0.00405834149569273
    z[5,1,6]  R1376     -5.1050871610641479e-01
    z[5,1,6]  R1377     0.63865065574646
    z[5,1,6]  R1378     -1.4969493262469769e-02
    z[5,1,6]  R1379     -1.7411597073078156e-01
    z[5,1,6]  R1380     2.0495028793811798e-01
    z[5,1,6]  R1381     3.2708659768104553e-02
    z[5,1,6]  R1382     -5.1327300071716309e-01
    z[5,1,6]  R1383     -3.6908425390720367e-02
    z[5,1,6]  R1384     7.4787355959415436e-02
    z[5,1,6]  R1385     3.2975021004676819e-01
    z[5,1,6]  R1386     -2.9628169536590576e-01
    z[5,1,6]  R1387     -1.2057397514581680e-01
    z[5,1,6]  R1388     3.4699384123086929e-02
    z[5,1,6]  R1389     0.268963485956192
    z[5,1,6]  R1390     -1.2915319204330444e-01
    z[5,1,6]  R1391     1.2269077450037003e-01
    z[5,1,6]  R1392     -3.2819494605064392e-01
    z[5,1,6]  R1393     -2.3916883766651154e-01
    z[5,1,6]  R1394     3.5343545675277710e-01
    z[5,1,6]  R1395     6.0876852273941040e-01
    z[5,1,6]  R1396     6.9648787379264832e-02
    z[5,1,6]  R1397     8.0360412597656250e-02
    z[5,1,6]  R1398     -0.0366581492125988
    z[5,1,6]  R1399     1.7690800130367279e-02
    z[5,1,6]  R1400     4.7874860465526581e-02
    z[5,1,6]  R1401     -2.7707897126674652e-02
    z[5,1,6]  R1402     -4.6995177865028381e-01
    z[5,1,6]  R1403     4.6346601098775864e-02
    z[5,1,6]  R1404     2.3973459377884865e-02
    z[5,1,6]  R1405     0.190284863114357
    z[5,1,6]  R1406     2.4733503162860870e-01
    z[2,4,0]  R20       -1
    z[2,4,0]  R38       1
    z[2,4,0]  R1407     -1
    z[2,4,0]  R1408     1
    z[2,4,0]  R1421     -3.6661231517791748e-01
    z[2,4,0]  R1422     1.6546562314033508e-01
    z[2,4,0]  R1423     4.0289503335952759e-01
    z[2,4,0]  R1424     2.0910868048667908e-01
    z[2,4,0]  R1425     3.0914855003356934e-01
    z[2,4,0]  R1426     1.6202406585216522e-01
    z[2,4,0]  R1427     2.1579591929912567e-01
    z[2,4,0]  R1428     1.1821023374795914e-01
    z[2,4,0]  R1429     3.0235308408737183e-01
    z[2,4,0]  R1430     -1.9415308535099030e-01
    z[2,4,0]  R1431     -2.7080168947577477e-02
    z[2,4,0]  R1432     -5.7811617851257324e-01
    z[2,4,0]  R1433     -5.2692550420761108e-01
    z[2,4,0]  R1434     -5.3425353765487671e-01
    z[2,4,0]  R1435     -4.2574870586395264e-01
    z[2,4,0]  R1436     4.0422007441520691e-01
    z[2,4,0]  R1437     -5.1966708898544312e-01
    z[2,4,0]  R1438     6.1865937709808350e-01
    z[2,4,0]  R1439     3.4635260701179504e-01
    z[2,4,0]  R1440     7.3169477283954620e-02
    z[2,4,0]  R1441     3.3273005485534668e-01
    z[2,4,0]  R1442     4.5836099982261658e-01
    z[2,4,0]  R1443     2.7963202446699142e-02
    z[2,4,0]  R1444     -1.6530632972717285e-01
    z[2,4,0]  R1445     -1.1073750257492065e-01
    z[2,4,0]  R1446     -2.1354803442955017e-01
    z[2,4,0]  R1447     -0.153940349817276
    z[2,4,0]  R1448     -1.7421080172061920e-01
    z[2,4,0]  R1449     5.6375145912170410e-02
    z[2,4,0]  R1450     -4.5848438143730164e-01
    z[2,4,0]  R1451     -8.3330410718917847e-01
    z[2,4,0]  R1452     -3.8666200637817383e-01
    z[2,4,0]  R1453     -1.9907087087631226e-01
    z[2,4,0]  R1454     -4.4714611768722534e-01
    z[2,4,0]  R1455     1.3753038644790649e-01
    z[2,4,0]  R1456     3.7897473573684692e-01
    z[2,4,0]  R1457     6.2275505065917969e-01
    z[2,4,0]  R1458     6.7475163936614990e-01
    z[2,4,0]  R1459     5.7183831930160522e-01
    z[2,4,0]  R1460     7.6425084844231606e-03
    z[2,4,0]  R1461     1.7630884051322937e-01
    z[2,4,0]  R1462     5.3241960704326630e-02
    z[2,4,0]  R1463     -1.9779168069362640e-02
    z[2,4,0]  R1464     4.3267560005187988e-01
    z[2,4,0]  R1465     0.529718279838562
    z[2,4,0]  R1466     4.0345376729965210e-01
    z[2,4,0]  R1467     1.3535985350608826e-01
    z[2,4,0]  R1468     0.340166836977005
    z[2,4,0]  R1469     7.4405074119567871e-02
    z[2,4,0]  R1470     -1.9793882966041565e-01
    z[2,4,0]  R1471     -1.9118184223771095e-02
    z[2,4,0]  R1472     -2.7381128072738647e-01
    z[2,4,0]  R1473     -1.2327007949352264e-01
    z[2,4,0]  R1474     -3.6031207442283630e-01
    z[2,4,0]  R1475     0.573261022567749
    z[2,4,0]  R1476     8.0649471282958984e-01
    z[2,4,0]  R1477     3.2313579320907593e-01
    z[2,4,0]  R1478     6.6625958681106567e-01
    z[2,4,0]  R1479     1.7175951600074768e-01
    z[2,4,1]  R21       -1
    z[2,4,1]  R39       1
    z[2,4,1]  R1409     -1
    z[2,4,1]  R1410     1
    z[2,4,1]  R1421     -1.3685827143490314e-02
    z[2,4,1]  R1422     4.5579671859741211e-01
    z[2,4,1]  R1423     5.3998893499374390e-01
    z[2,4,1]  R1424     3.4333053231239319e-01
    z[2,4,1]  R1425     2.7926534414291382e-01
    z[2,4,1]  R1426     1.0566697455942631e-02
    z[2,4,1]  R1427     1.1272235959768295e-01
    z[2,4,1]  R1428     4.8577859997749329e-02
    z[2,4,1]  R1429     -2.5733289122581482e-01
    z[2,4,1]  R1430     1.6795553267002106e-01
    z[2,4,1]  R1431     -3.2765606045722961e-01
    z[2,4,1]  R1432     -6.9910669326782227e-01
    z[2,4,1]  R1433     -7.0960718393325806e-01
    z[2,4,1]  R1434     -7.0828872919082642e-01
    z[2,4,1]  R1435     -7.4616920948028564e-01
    z[2,4,1]  R1436     8.2627201080322266e-01
    z[2,4,1]  R1437     -0.623083233833313
    z[2,4,1]  R1438     5.8256733417510986e-01
    z[2,4,1]  R1439     5.9217453002929688e-01
    z[2,4,1]  R1440     -4.8929625749588013e-01
    z[2,4,1]  R1441     -5.5335021018981934e-01
    z[2,4,1]  R1442     -4.6199139952659607e-01
    z[2,4,1]  R1443     0.621759831905365
    z[2,4,1]  R1444     5.0254029035568237e-01
    z[2,4,1]  R1445     4.4633430242538452e-01
    z[2,4,1]  R1446     5.6274503469467163e-01
    z[2,4,1]  R1447     -6.9187784194946289e-01
    z[2,4,1]  R1448     2.4417115747928619e-01
    z[2,4,1]  R1449     1.3327860832214355e-01
    z[2,4,1]  R1450     5.8975040912628174e-01
    z[2,4,1]  R1451     -3.0199262499809265e-01
    z[2,4,1]  R1452     4.2183169722557068e-01
    z[2,4,1]  R1453     5.6619131565093994e-01
    z[2,4,1]  R1454     -0.187115877866745
    z[2,4,1]  R1455     -4.2707616090774536e-01
    z[2,4,1]  R1456     -0.341106116771698
    z[2,4,1]  R1457     -4.2832204699516296e-01
    z[2,4,1]  R1458     -0.382802814245224
    z[2,4,1]  R1459     -1.7089107632637024e-01
    z[2,4,1]  R1460     2.7923274040222168e-01
    z[2,4,1]  R1461     3.9075195789337158e-01
    z[2,4,1]  R1462     1.1419252306222916e-01
    z[2,4,1]  R1463     -8.4380501508712769e-01
    z[2,4,1]  R1464     7.0902770757675171e-01
    z[2,4,1]  R1465     -0.0634336769580841
    z[2,4,1]  R1466     -2.3554362356662750e-01
    z[2,4,1]  R1467     -2.5087940692901611e-01
    z[2,4,1]  R1468     6.6085916757583618e-01
    z[2,4,1]  R1469     -2.8801517561078072e-02
    z[2,4,1]  R1470     2.2513702511787415e-01
    z[2,4,1]  R1471     3.7106060981750488e-01
    z[2,4,1]  R1472     -8.3636589348316193e-02
    z[2,4,1]  R1473     -2.0240172743797302e-01
    z[2,4,1]  R1474     -2.1877533197402954e-01
    z[2,4,1]  R1475     -3.9691346883773804e-01
    z[2,4,1]  R1476     3.2836962491273880e-03
    z[2,4,1]  R1477     -1.2896490097045898e-01
    z[2,4,1]  R1478     -1.0529072955250740e-02
    z[2,4,1]  R1479     9.8508365452289581e-02
    z[2,4,2]  R22       -1
    z[2,4,2]  R40       1
    z[2,4,2]  R1411     -1
    z[2,4,2]  R1412     1
    z[2,4,2]  R1421     2.1258221566677094e-01
    z[2,4,2]  R1422     4.1581603884696960e-01
    z[2,4,2]  R1423     3.2558149099349976e-01
    z[2,4,2]  R1424     -2.8964450955390930e-01
    z[2,4,2]  R1425     -3.0477553606033325e-01
    z[2,4,2]  R1426     2.3961445689201355e-01
    z[2,4,2]  R1427     7.6453518867492676e-01
    z[2,4,2]  R1428     8.1429845094680786e-01
    z[2,4,2]  R1429     3.0611777305603027e-01
    z[2,4,2]  R1430     5.0546836853027344e-01
    z[2,4,2]  R1431     5.2546513080596924e-01
    z[2,4,2]  R1432     -2.5471404194831848e-01
    z[2,4,2]  R1433     -1.9017027318477631e-01
    z[2,4,2]  R1434     -2.2027122974395752e-01
    z[2,4,2]  R1435     9.2856585979461670e-02
    z[2,4,2]  R1436     -1.5305048227310181e-01
    z[2,4,2]  R1437     1.3614802621304989e-02
    z[2,4,2]  R1438     -1.2995676696300507e-01
    z[2,4,2]  R1439     3.7700325250625610e-01
    z[2,4,2]  R1440     -3.8925856351852417e-01
    z[2,4,2]  R1441     -3.1161662936210632e-01
    z[2,4,2]  R1442     -0.522205114364624
    z[2,4,2]  R1443     -4.6922508627176285e-02
    z[2,4,2]  R1444     -1.6904366016387939e-01
    z[2,4,2]  R1445     -1.2624402344226837e-01
    z[2,4,2]  R1446     1.2969402968883514e-01
    z[2,4,2]  R1447     -5.3946632146835327e-01
    z[2,4,2]  R1448     -1.3117274641990662e-01
    z[2,4,2]  R1449     -9.6711240708827972e-02
    z[2,4,2]  R1450     -5.6937170028686523e-01
    z[2,4,2]  R1451     -3.3548864722251892e-01
    z[2,4,2]  R1452     -1.4437523484230042e-01
    z[2,4,2]  R1453     -1.9146996736526489e-01
    z[2,4,2]  R1454     -1.9056263566017151e-01
    z[2,4,2]  R1455     3.4245607256889343e-01
    z[2,4,2]  R1456     0.211964413523674
    z[2,4,2]  R1457     3.5854774713516235e-01
    z[2,4,2]  R1458     3.7747806310653687e-01
    z[2,4,2]  R1459     1.7277404665946960e-01
    z[2,4,2]  R1460     5.6270472705364227e-02
    z[2,4,2]  R1461     6.1175487935543060e-02
    z[2,4,2]  R1462     6.2633596360683441e-02
    z[2,4,2]  R1463     3.6473387479782104e-01
    z[2,4,2]  R1464     4.6586093306541443e-01
    z[2,4,2]  R1465     4.9473071098327637e-01
    z[2,4,2]  R1466     8.7779097259044647e-02
    z[2,4,2]  R1467     -8.1706777215003967e-02
    z[2,4,2]  R1468     5.5561274290084839e-01
    z[2,4,2]  R1469     0.90269535779953
    z[2,4,2]  R1470     -2.4621029198169708e-01
    z[2,4,2]  R1471     9.7653055563569069e-03
    z[2,4,2]  R1472     -4.4117063283920288e-02
    z[2,4,2]  R1473     -5.2991036325693130e-02
    z[2,4,2]  R1474     1.3464756309986115e-01
    z[2,4,2]  R1475     5.7754433155059814e-01
    z[2,4,2]  R1476     4.4476282596588135e-01
    z[2,4,2]  R1477     0.648669958114624
    z[2,4,2]  R1478     4.4346186518669128e-01
    z[2,4,2]  R1479     7.2225689888000488e-01
    z[2,4,3]  R23       -1
    z[2,4,3]  R41       1
    z[2,4,3]  R1413     -1
    z[2,4,3]  R1414     1
    z[2,4,3]  R1421     7.8052252531051636e-01
    z[2,4,3]  R1422     3.9015822112560272e-02
    z[2,4,3]  R1423     2.3934055864810944e-01
    z[2,4,3]  R1424     2.1962981671094894e-02
    z[2,4,3]  R1425     2.4569568037986755e-01
    z[2,4,3]  R1426     9.2812865972518921e-02
    z[2,4,3]  R1427     1.1253246106207371e-02
    z[2,4,3]  R1428     8.0901905894279480e-03
    z[2,4,3]  R1429     2.7741071581840515e-01
    z[2,4,3]  R1430     -1.1258782446384430e-01
    z[2,4,3]  R1431     1.5779989957809448e-01
    z[2,4,3]  R1432     -3.0732131004333496e-01
    z[2,4,3]  R1433     -2.5070270895957947e-01
    z[2,4,3]  R1434     -1.9933721423149109e-01
    z[2,4,3]  R1435     -2.9560244083404541e-01
    z[2,4,3]  R1436     1.8660595640540123e-02
    z[2,4,3]  R1437     -2.8148058056831360e-01
    z[2,4,3]  R1438     -5.0522230565547943e-02
    z[2,4,3]  R1439     -1.4186839759349823e-01
    z[2,4,3]  R1440     -8.7280482053756714e-02
    z[2,4,3]  R1441     1.5519383549690247e-01
    z[2,4,3]  R1442     2.8961020708084106e-01
    z[2,4,3]  R1443     -2.5664865970611572e-01
    z[2,4,3]  R1444     -4.9873286485671997e-01
    z[2,4,3]  R1445     -3.5075816512107849e-01
    z[2,4,3]  R1446     -5.5897700786590576e-01
    z[2,4,3]  R1447     -2.3413909971714020e-01
    z[2,4,3]  R1448     -3.6581665277481079e-01
    z[2,4,3]  R1449     -6.2053781747817993e-01
    z[2,4,3]  R1450     -1.3295269571244717e-02
    z[2,4,3]  R1451     8.1346770748496056e-03
    z[2,4,3]  R1452     6.1704171821475029e-04
    z[2,4,3]  R1453     5.4796808958053589e-01
    z[2,4,3]  R1454     -1.8601444363594055e-01
    z[2,4,3]  R1455     4.6598574519157410e-01
    z[2,4,3]  R1456     6.8456375598907471e-01
    z[2,4,3]  R1457     3.7912562489509583e-01
    z[2,4,3]  R1458     4.2051178216934204e-01
    z[2,4,3]  R1459     7.0381826162338257e-01
    z[2,4,3]  R1460     -5.6691038608551025e-01
    z[2,4,3]  R1461     -8.9019864797592163e-01
    z[2,4,3]  R1462     -9.4144827127456665e-01
    z[2,4,3]  R1463     -2.9299971461296082e-01
    z[2,4,3]  R1464     -6.8816497921943665e-02
    z[2,4,3]  R1465     -7.7888399362564087e-02
    z[2,4,3]  R1466     -2.6586738228797913e-01
    z[2,4,3]  R1467     -3.8229238986968994e-01
    z[2,4,3]  R1468     -0.0145845552906394
    z[2,4,3]  R1469     5.6325122714042664e-02
    z[2,4,3]  R1470     -3.5785429179668427e-02
    z[2,4,3]  R1471     -6.5327733755111694e-01
    z[2,4,3]  R1472     -9.4674319028854370e-01
    z[2,4,3]  R1473     -0.876287579536438
    z[2,4,3]  R1474     -7.8395682573318481e-01
    z[2,4,3]  R1475     2.2759279608726501e-01
    z[2,4,3]  R1476     2.2771029174327850e-01
    z[2,4,3]  R1477     -3.8415189832448959e-02
    z[2,4,3]  R1478     -1.0041257739067078e-01
    z[2,4,3]  R1479     7.9403042793273926e-02
    z[2,4,4]  R24       -1
    z[2,4,4]  R42       1
    z[2,4,4]  R1415     -1
    z[2,4,4]  R1416     1
    z[2,4,4]  R1421     -2.5614660978317261e-01
    z[2,4,4]  R1422     -0.000798138091340661
    z[2,4,4]  R1423     5.5186992883682251e-01
    z[2,4,4]  R1424     -1.3819648325443268e-01
    z[2,4,4]  R1425     -1.6549403965473175e-01
    z[2,4,4]  R1426     8.1146311759948730e-01
    z[2,4,4]  R1427     2.5595462322235107e-01
    z[2,4,4]  R1428     4.7331121563911438e-01
    z[2,4,4]  R1429     2.3274032771587372e-01
    z[2,4,4]  R1430     -4.3243950605392456e-01
    z[2,4,4]  R1431     -2.6868479326367378e-02
    z[2,4,4]  R1432     -8.4718890488147736e-02
    z[2,4,4]  R1433     1.7959372699260712e-01
    z[2,4,4]  R1434     3.3769440650939941e-01
    z[2,4,4]  R1435     3.5924088954925537e-01
    z[2,4,4]  R1436     -1.5597642958164215e-01
    z[2,4,4]  R1437     9.0175405144691467e-02
    z[2,4,4]  R1438     4.9020549654960632e-01
    z[2,4,4]  R1439     5.0157213211059570e-01
    z[2,4,4]  R1440     -3.6766156554222107e-01
    z[2,4,4]  R1441     6.4462912082672119e-01
    z[2,4,4]  R1442     5.4894257336854935e-02
    z[2,4,4]  R1443     1.9418130815029144e-01
    z[2,4,4]  R1444     2.1522257477045059e-02
    z[2,4,4]  R1445     1.9847208261489868e-01
    z[2,4,4]  R1446     1.3483066856861115e-01
    z[2,4,4]  R1447     -2.4369807541370392e-01
    z[2,4,4]  R1448     7.6184707880020142e-01
    z[2,4,4]  R1449     5.7341301441192627e-01
    z[2,4,4]  R1450     8.1056252121925354e-02
    z[2,4,4]  R1451     0.142792746424675
    z[2,4,4]  R1452     -8.0507266521453857e-01
    z[2,4,4]  R1453     -3.9802014827728271e-01
    z[2,4,4]  R1454     -4.7465908527374268e-01
    z[2,4,4]  R1455     -0.537653386592865
    z[2,4,4]  R1456     1.2213263660669327e-01
    z[2,4,4]  R1457     3.2871001958847046e-01
    z[2,4,4]  R1458     2.1572580933570862e-01
    z[2,4,4]  R1459     2.4480944871902466e-01
    z[2,4,4]  R1460     2.8845849633216858e-01
    z[2,4,4]  R1461     -6.0820616781711578e-02
    z[2,4,4]  R1462     1.4904613792896271e-01
    z[2,4,4]  R1463     4.2433872818946838e-02
    z[2,4,4]  R1464     1.1020025610923767e-01
    z[2,4,4]  R1465     7.6562032103538513e-02
    z[2,4,4]  R1466     7.3388224840164185e-01
    z[2,4,4]  R1467     7.9327476024627686e-01
    z[2,4,4]  R1468     3.6913216114044189e-01
    z[2,4,4]  R1469     4.1980534791946411e-02
    z[2,4,4]  R1470     -2.2857272997498512e-02
    z[2,4,4]  R1471     -4.3017558753490448e-02
    z[2,4,4]  R1472     4.3811939656734467e-02
    z[2,4,4]  R1473     3.4191107749938965e-01
    z[2,4,4]  R1474     -3.9321768283843994e-01
    z[2,4,4]  R1475     -3.0978059768676758e-01
    z[2,4,4]  R1476     -2.4362166225910187e-01
    z[2,4,4]  R1477     -3.9132431149482727e-02
    z[2,4,4]  R1478     -1.7526191473007202e-01
    z[2,4,4]  R1479     1.3096977770328522e-01
    z[2,4,5]  R25       -1
    z[2,4,5]  R43       1
    z[2,4,5]  R1417     -1
    z[2,4,5]  R1418     1
    z[2,4,5]  R1421     -3.8127186894416809e-01
    z[2,4,5]  R1422     1.9546292722225189e-01
    z[2,4,5]  R1423     1.2754661962389946e-02
    z[2,4,5]  R1424     -2.3319636285305023e-01
    z[2,4,5]  R1425     2.1404910087585449e-01
    z[2,4,5]  R1426     -3.6159527301788330e-01
    z[2,4,5]  R1427     4.9350535869598389e-01
    z[2,4,5]  R1428     3.0156826972961426e-01
    z[2,4,5]  R1429     0.588338315486908
    z[2,4,5]  R1430     6.5808808803558350e-01
    z[2,4,5]  R1431     7.5849437713623047e-01
    z[2,4,5]  R1432     2.5602813810110092e-02
    z[2,4,5]  R1433     -1.7964061116799712e-03
    z[2,4,5]  R1434     9.3446910381317139e-02
    z[2,4,5]  R1435     -1.8723461031913757e-01
    z[2,4,5]  R1436     4.0902689099311829e-02
    z[2,4,5]  R1437     7.3748230934143066e-02
    z[2,4,5]  R1438     -2.8898175805807114e-02
    z[2,4,5]  R1439     1.5492363274097443e-01
    z[2,4,5]  R1440     -7.8078046441078186e-02
    z[2,4,5]  R1441     -2.1046692132949829e-01
    z[2,4,5]  R1442     -1.1115522682666779e-01
    z[2,4,5]  R1443     -4.7295203804969788e-01
    z[2,4,5]  R1444     -0.629519522190094
    z[2,4,5]  R1445     -7.7274823188781738e-01
    z[2,4,5]  R1446     -5.2689379453659058e-01
    z[2,4,5]  R1447     1.8636273220181465e-02
    z[2,4,5]  R1448     6.7329309880733490e-02
    z[2,4,5]  R1449     4.7534830868244171e-02
    z[2,4,5]  R1450     -3.2239374518394470e-01
    z[2,4,5]  R1451     -2.5660082697868347e-01
    z[2,4,5]  R1452     1.2339268811047077e-02
    z[2,4,5]  R1453     9.2138200998306274e-02
    z[2,4,5]  R1454     -2.4084170162677765e-01
    z[2,4,5]  R1455     -4.0667504072189331e-01
    z[2,4,5]  R1456     -4.5615375041961670e-01
    z[2,4,5]  R1457     -5.0682887434959412e-02
    z[2,4,5]  R1458     -5.3031824529170990e-02
    z[2,4,5]  R1459     -3.7292614579200745e-02
    z[2,4,5]  R1460     1.4203681051731110e-01
    z[2,4,5]  R1461     8.4373086690902710e-02
    z[2,4,5]  R1462     -2.2015558183193207e-01
    z[2,4,5]  R1463     2.3934745788574219e-01
    z[2,4,5]  R1464     1.6793370246887207e-01
    z[2,4,5]  R1465     -5.6633424758911133e-01
    z[2,4,5]  R1466     3.3496430516242981e-01
    z[2,4,5]  R1467     2.1169048547744751e-01
    z[2,4,5]  R1468     -4.8653557896614075e-02
    z[2,4,5]  R1469     -4.1244491934776306e-01
    z[2,4,5]  R1470     8.6037427186965942e-01
    z[2,4,5]  R1471     5.9718143939971924e-01
    z[2,4,5]  R1472     -1.2719912827014923e-01
    z[2,4,5]  R1473     -6.2453597784042358e-03
    z[2,4,5]  R1474     1.5146744251251221e-01
    z[2,4,5]  R1475     1.6857126355171204e-01
    z[2,4,5]  R1476     1.3088262081146240e-01
    z[2,4,5]  R1477     -6.7186409235000610e-01
    z[2,4,5]  R1478     -5.4155224561691284e-01
    z[2,4,5]  R1479     -5.8668041229248047e-01
    z[2,4,6]  R26       -1
    z[2,4,6]  R44       1
    z[2,4,6]  R1419     -1
    z[2,4,6]  R1420     1
    z[2,4,6]  R1421     4.7085378319025040e-03
    z[2,4,6]  R1422     7.4312782287597656e-01
    z[2,4,6]  R1423     2.7942320704460144e-01
    z[2,4,6]  R1424     -8.2495003938674927e-01
    z[2,4,6]  R1425     7.7458268404006958e-01
    z[2,4,6]  R1426     3.4406915307044983e-01
    z[2,4,6]  R1427     2.1685181558132172e-01
    z[2,4,6]  R1428     -7.4513129889965057e-02
    z[2,4,6]  R1429     -5.2094870805740356e-01
    z[2,4,6]  R1430     -2.1409682929515839e-01
    z[2,4,6]  R1431     -1.2189421057701111e-01
    z[2,4,6]  R1432     9.9363557994365692e-02
    z[2,4,6]  R1433     -2.9586055874824524e-01
    z[2,4,6]  R1434     -4.3308973312377930e-02
    z[2,4,6]  R1435     -4.3077409267425537e-02
    z[2,4,6]  R1436     -3.2265511155128479e-01
    z[2,4,6]  R1437     4.9872463941574097e-01
    z[2,4,6]  R1438     1.3152271509170532e-01
    z[2,4,6]  R1439     3.0254775285720825e-01
    z[2,4,6]  R1440     -6.7440646886825562e-01
    z[2,4,6]  R1441     0.0453985333442688
    z[2,4,6]  R1442     4.5224779844284058e-01
    z[2,4,6]  R1443     5.3213948011398315e-01
    z[2,4,6]  R1444     2.1461309492588043e-01
    z[2,4,6]  R1445     -1.1411865800619125e-01
    z[2,4,6]  R1446     1.1244162172079086e-01
    z[2,4,6]  R1447     3.0335816740989685e-01
    z[2,4,6]  R1448     -0.417203426361084
    z[2,4,6]  R1449     -0.503563642501831
    z[2,4,6]  R1450     8.4367677569389343e-02
    z[2,4,6]  R1451     -1.2470804899930954e-01
    z[2,4,6]  R1452     -5.8409009128808975e-02
    z[2,4,6]  R1453     -3.6872607469558716e-01
    z[2,4,6]  R1454     6.4095747470855713e-01
    z[2,4,6]  R1455     -9.9079899489879608e-02
    z[2,4,6]  R1456     5.8955080807209015e-02
    z[2,4,6]  R1457     -2.1402002871036530e-01
    z[2,4,6]  R1458     1.7176277935504913e-01
    z[2,4,6]  R1459     2.3929831385612488e-01
    z[2,4,6]  R1460     -7.0287567377090454e-01
    z[2,4,6]  R1461     -9.5990262925624847e-02
    z[2,4,6]  R1462     -1.5229627490043640e-01
    z[2,4,6]  R1463     9.8155051469802856e-02
    z[2,4,6]  R1464     2.1900594234466553e-01
    z[2,4,6]  R1465     -3.7142071127891541e-01
    z[2,4,6]  R1466     2.2928024828433990e-01
    z[2,4,6]  R1467     3.0301153659820557e-01
    z[2,4,6]  R1468     2.7891201898455620e-03
    z[2,4,6]  R1469     6.1072193086147308e-02
    z[2,4,6]  R1470     3.2782158255577087e-01
    z[2,4,6]  R1471     -2.7677747607231140e-01
    z[2,4,6]  R1472     4.0796067565679550e-02
    z[2,4,6]  R1473     2.3708198964595795e-01
    z[2,4,6]  R1474     -1.0968913137912750e-01
    z[2,4,6]  R1475     -0.0639939159154892
    z[2,4,6]  R1476     1.5299607813358307e-01
    z[2,4,6]  R1477     6.1401624232530594e-02
    z[2,4,6]  R1478     -1.5890444815158844e-01
    z[2,4,6]  R1479     -2.6737222075462341e-01
    z[4,2,0]  R20       1
    z[4,2,0]  R38       -1
    z[4,2,0]  R1480     -1
    z[4,2,0]  R1481     1
    z[4,2,0]  R1494     -4.5848438143730164e-01
    z[4,2,0]  R1495     -8.3330410718917847e-01
    z[4,2,0]  R1496     -3.8666200637817383e-01
    z[4,2,0]  R1497     -1.9907087087631226e-01
    z[4,2,0]  R1498     -4.4714611768722534e-01
    z[4,2,0]  R1499     1.3753038644790649e-01
    z[4,2,0]  R1500     3.7897473573684692e-01
    z[4,2,0]  R1501     6.2275505065917969e-01
    z[4,2,0]  R1502     6.7475163936614990e-01
    z[4,2,0]  R1503     5.7183831930160522e-01
    z[4,2,0]  R1504     7.6425084844231606e-03
    z[4,2,0]  R1505     1.7630884051322937e-01
    z[4,2,0]  R1506     5.3241960704326630e-02
    z[4,2,0]  R1507     -1.9779168069362640e-02
    z[4,2,0]  R1508     4.3267560005187988e-01
    z[4,2,0]  R1509     0.529718279838562
    z[4,2,0]  R1510     4.0345376729965210e-01
    z[4,2,0]  R1511     1.3535985350608826e-01
    z[4,2,0]  R1512     0.340166836977005
    z[4,2,0]  R1513     7.4405074119567871e-02
    z[4,2,0]  R1514     -1.9793882966041565e-01
    z[4,2,0]  R1515     -1.9118184223771095e-02
    z[4,2,0]  R1516     -2.7381128072738647e-01
    z[4,2,0]  R1517     -1.2327007949352264e-01
    z[4,2,0]  R1518     -3.6031207442283630e-01
    z[4,2,0]  R1519     0.573261022567749
    z[4,2,0]  R1520     8.0649471282958984e-01
    z[4,2,0]  R1521     3.2313579320907593e-01
    z[4,2,0]  R1522     6.6625958681106567e-01
    z[4,2,0]  R1523     1.7175951600074768e-01
    z[4,2,0]  R1524     -3.6661231517791748e-01
    z[4,2,0]  R1525     1.6546562314033508e-01
    z[4,2,0]  R1526     4.0289503335952759e-01
    z[4,2,0]  R1527     2.0910868048667908e-01
    z[4,2,0]  R1528     3.0914855003356934e-01
    z[4,2,0]  R1529     1.6202406585216522e-01
    z[4,2,0]  R1530     2.1579591929912567e-01
    z[4,2,0]  R1531     1.1821023374795914e-01
    z[4,2,0]  R1532     3.0235308408737183e-01
    z[4,2,0]  R1533     -1.9415308535099030e-01
    z[4,2,0]  R1534     -2.7080168947577477e-02
    z[4,2,0]  R1535     -5.7811617851257324e-01
    z[4,2,0]  R1536     -5.2692550420761108e-01
    z[4,2,0]  R1537     -5.3425353765487671e-01
    z[4,2,0]  R1538     -4.2574870586395264e-01
    z[4,2,0]  R1539     4.0422007441520691e-01
    z[4,2,0]  R1540     -5.1966708898544312e-01
    z[4,2,0]  R1541     6.1865937709808350e-01
    z[4,2,0]  R1542     3.4635260701179504e-01
    z[4,2,0]  R1543     7.3169477283954620e-02
    z[4,2,0]  R1544     3.3273005485534668e-01
    z[4,2,0]  R1545     4.5836099982261658e-01
    z[4,2,0]  R1546     2.7963202446699142e-02
    z[4,2,0]  R1547     -1.6530632972717285e-01
    z[4,2,0]  R1548     -1.1073750257492065e-01
    z[4,2,0]  R1549     -2.1354803442955017e-01
    z[4,2,0]  R1550     -0.153940349817276
    z[4,2,0]  R1551     -1.7421080172061920e-01
    z[4,2,0]  R1552     5.6375145912170410e-02
    z[4,2,1]  R21       1
    z[4,2,1]  R39       -1
    z[4,2,1]  R1482     -1
    z[4,2,1]  R1483     1
    z[4,2,1]  R1494     5.8975040912628174e-01
    z[4,2,1]  R1495     -3.0199262499809265e-01
    z[4,2,1]  R1496     4.2183169722557068e-01
    z[4,2,1]  R1497     5.6619131565093994e-01
    z[4,2,1]  R1498     -0.187115877866745
    z[4,2,1]  R1499     -4.2707616090774536e-01
    z[4,2,1]  R1500     -0.341106116771698
    z[4,2,1]  R1501     -4.2832204699516296e-01
    z[4,2,1]  R1502     -0.382802814245224
    z[4,2,1]  R1503     -1.7089107632637024e-01
    z[4,2,1]  R1504     2.7923274040222168e-01
    z[4,2,1]  R1505     3.9075195789337158e-01
    z[4,2,1]  R1506     1.1419252306222916e-01
    z[4,2,1]  R1507     -8.4380501508712769e-01
    z[4,2,1]  R1508     7.0902770757675171e-01
    z[4,2,1]  R1509     -0.0634336769580841
    z[4,2,1]  R1510     -2.3554362356662750e-01
    z[4,2,1]  R1511     -2.5087940692901611e-01
    z[4,2,1]  R1512     6.6085916757583618e-01
    z[4,2,1]  R1513     -2.8801517561078072e-02
    z[4,2,1]  R1514     2.2513702511787415e-01
    z[4,2,1]  R1515     3.7106060981750488e-01
    z[4,2,1]  R1516     -8.3636589348316193e-02
    z[4,2,1]  R1517     -2.0240172743797302e-01
    z[4,2,1]  R1518     -2.1877533197402954e-01
    z[4,2,1]  R1519     -3.9691346883773804e-01
    z[4,2,1]  R1520     3.2836962491273880e-03
    z[4,2,1]  R1521     -1.2896490097045898e-01
    z[4,2,1]  R1522     -1.0529072955250740e-02
    z[4,2,1]  R1523     9.8508365452289581e-02
    z[4,2,1]  R1524     -1.3685827143490314e-02
    z[4,2,1]  R1525     4.5579671859741211e-01
    z[4,2,1]  R1526     5.3998893499374390e-01
    z[4,2,1]  R1527     3.4333053231239319e-01
    z[4,2,1]  R1528     2.7926534414291382e-01
    z[4,2,1]  R1529     1.0566697455942631e-02
    z[4,2,1]  R1530     1.1272235959768295e-01
    z[4,2,1]  R1531     4.8577859997749329e-02
    z[4,2,1]  R1532     -2.5733289122581482e-01
    z[4,2,1]  R1533     1.6795553267002106e-01
    z[4,2,1]  R1534     -3.2765606045722961e-01
    z[4,2,1]  R1535     -6.9910669326782227e-01
    z[4,2,1]  R1536     -7.0960718393325806e-01
    z[4,2,1]  R1537     -7.0828872919082642e-01
    z[4,2,1]  R1538     -7.4616920948028564e-01
    z[4,2,1]  R1539     8.2627201080322266e-01
    z[4,2,1]  R1540     -0.623083233833313
    z[4,2,1]  R1541     5.8256733417510986e-01
    z[4,2,1]  R1542     5.9217453002929688e-01
    z[4,2,1]  R1543     -4.8929625749588013e-01
    z[4,2,1]  R1544     -5.5335021018981934e-01
    z[4,2,1]  R1545     -4.6199139952659607e-01
    z[4,2,1]  R1546     0.621759831905365
    z[4,2,1]  R1547     5.0254029035568237e-01
    z[4,2,1]  R1548     4.4633430242538452e-01
    z[4,2,1]  R1549     5.6274503469467163e-01
    z[4,2,1]  R1550     -6.9187784194946289e-01
    z[4,2,1]  R1551     2.4417115747928619e-01
    z[4,2,1]  R1552     1.3327860832214355e-01
    z[4,2,2]  R22       1
    z[4,2,2]  R40       -1
    z[4,2,2]  R1484     -1
    z[4,2,2]  R1485     1
    z[4,2,2]  R1494     -5.6937170028686523e-01
    z[4,2,2]  R1495     -3.3548864722251892e-01
    z[4,2,2]  R1496     -1.4437523484230042e-01
    z[4,2,2]  R1497     -1.9146996736526489e-01
    z[4,2,2]  R1498     -1.9056263566017151e-01
    z[4,2,2]  R1499     3.4245607256889343e-01
    z[4,2,2]  R1500     0.211964413523674
    z[4,2,2]  R1501     3.5854774713516235e-01
    z[4,2,2]  R1502     3.7747806310653687e-01
    z[4,2,2]  R1503     1.7277404665946960e-01
    z[4,2,2]  R1504     5.6270472705364227e-02
    z[4,2,2]  R1505     6.1175487935543060e-02
    z[4,2,2]  R1506     6.2633596360683441e-02
    z[4,2,2]  R1507     3.6473387479782104e-01
    z[4,2,2]  R1508     4.6586093306541443e-01
    z[4,2,2]  R1509     4.9473071098327637e-01
    z[4,2,2]  R1510     8.7779097259044647e-02
    z[4,2,2]  R1511     -8.1706777215003967e-02
    z[4,2,2]  R1512     5.5561274290084839e-01
    z[4,2,2]  R1513     0.90269535779953
    z[4,2,2]  R1514     -2.4621029198169708e-01
    z[4,2,2]  R1515     9.7653055563569069e-03
    z[4,2,2]  R1516     -4.4117063283920288e-02
    z[4,2,2]  R1517     -5.2991036325693130e-02
    z[4,2,2]  R1518     1.3464756309986115e-01
    z[4,2,2]  R1519     5.7754433155059814e-01
    z[4,2,2]  R1520     4.4476282596588135e-01
    z[4,2,2]  R1521     0.648669958114624
    z[4,2,2]  R1522     4.4346186518669128e-01
    z[4,2,2]  R1523     7.2225689888000488e-01
    z[4,2,2]  R1524     2.1258221566677094e-01
    z[4,2,2]  R1525     4.1581603884696960e-01
    z[4,2,2]  R1526     3.2558149099349976e-01
    z[4,2,2]  R1527     -2.8964450955390930e-01
    z[4,2,2]  R1528     -3.0477553606033325e-01
    z[4,2,2]  R1529     2.3961445689201355e-01
    z[4,2,2]  R1530     7.6453518867492676e-01
    z[4,2,2]  R1531     8.1429845094680786e-01
    z[4,2,2]  R1532     3.0611777305603027e-01
    z[4,2,2]  R1533     5.0546836853027344e-01
    z[4,2,2]  R1534     5.2546513080596924e-01
    z[4,2,2]  R1535     -2.5471404194831848e-01
    z[4,2,2]  R1536     -1.9017027318477631e-01
    z[4,2,2]  R1537     -2.2027122974395752e-01
    z[4,2,2]  R1538     9.2856585979461670e-02
    z[4,2,2]  R1539     -1.5305048227310181e-01
    z[4,2,2]  R1540     1.3614802621304989e-02
    z[4,2,2]  R1541     -1.2995676696300507e-01
    z[4,2,2]  R1542     3.7700325250625610e-01
    z[4,2,2]  R1543     -3.8925856351852417e-01
    z[4,2,2]  R1544     -3.1161662936210632e-01
    z[4,2,2]  R1545     -0.522205114364624
    z[4,2,2]  R1546     -4.6922508627176285e-02
    z[4,2,2]  R1547     -1.6904366016387939e-01
    z[4,2,2]  R1548     -1.2624402344226837e-01
    z[4,2,2]  R1549     1.2969402968883514e-01
    z[4,2,2]  R1550     -5.3946632146835327e-01
    z[4,2,2]  R1551     -1.3117274641990662e-01
    z[4,2,2]  R1552     -9.6711240708827972e-02
    z[4,2,3]  R23       1
    z[4,2,3]  R41       -1
    z[4,2,3]  R1486     -1
    z[4,2,3]  R1487     1
    z[4,2,3]  R1494     -1.3295269571244717e-02
    z[4,2,3]  R1495     8.1346770748496056e-03
    z[4,2,3]  R1496     6.1704171821475029e-04
    z[4,2,3]  R1497     5.4796808958053589e-01
    z[4,2,3]  R1498     -1.8601444363594055e-01
    z[4,2,3]  R1499     4.6598574519157410e-01
    z[4,2,3]  R1500     6.8456375598907471e-01
    z[4,2,3]  R1501     3.7912562489509583e-01
    z[4,2,3]  R1502     4.2051178216934204e-01
    z[4,2,3]  R1503     7.0381826162338257e-01
    z[4,2,3]  R1504     -5.6691038608551025e-01
    z[4,2,3]  R1505     -8.9019864797592163e-01
    z[4,2,3]  R1506     -9.4144827127456665e-01
    z[4,2,3]  R1507     -2.9299971461296082e-01
    z[4,2,3]  R1508     -6.8816497921943665e-02
    z[4,2,3]  R1509     -7.7888399362564087e-02
    z[4,2,3]  R1510     -2.6586738228797913e-01
    z[4,2,3]  R1511     -3.8229238986968994e-01
    z[4,2,3]  R1512     -0.0145845552906394
    z[4,2,3]  R1513     5.6325122714042664e-02
    z[4,2,3]  R1514     -3.5785429179668427e-02
    z[4,2,3]  R1515     -6.5327733755111694e-01
    z[4,2,3]  R1516     -9.4674319028854370e-01
    z[4,2,3]  R1517     -0.876287579536438
    z[4,2,3]  R1518     -7.8395682573318481e-01
    z[4,2,3]  R1519     2.2759279608726501e-01
    z[4,2,3]  R1520     2.2771029174327850e-01
    z[4,2,3]  R1521     -3.8415189832448959e-02
    z[4,2,3]  R1522     -1.0041257739067078e-01
    z[4,2,3]  R1523     7.9403042793273926e-02
    z[4,2,3]  R1524     7.8052252531051636e-01
    z[4,2,3]  R1525     3.9015822112560272e-02
    z[4,2,3]  R1526     2.3934055864810944e-01
    z[4,2,3]  R1527     2.1962981671094894e-02
    z[4,2,3]  R1528     2.4569568037986755e-01
    z[4,2,3]  R1529     9.2812865972518921e-02
    z[4,2,3]  R1530     1.1253246106207371e-02
    z[4,2,3]  R1531     8.0901905894279480e-03
    z[4,2,3]  R1532     2.7741071581840515e-01
    z[4,2,3]  R1533     -1.1258782446384430e-01
    z[4,2,3]  R1534     1.5779989957809448e-01
    z[4,2,3]  R1535     -3.0732131004333496e-01
    z[4,2,3]  R1536     -2.5070270895957947e-01
    z[4,2,3]  R1537     -1.9933721423149109e-01
    z[4,2,3]  R1538     -2.9560244083404541e-01
    z[4,2,3]  R1539     1.8660595640540123e-02
    z[4,2,3]  R1540     -2.8148058056831360e-01
    z[4,2,3]  R1541     -5.0522230565547943e-02
    z[4,2,3]  R1542     -1.4186839759349823e-01
    z[4,2,3]  R1543     -8.7280482053756714e-02
    z[4,2,3]  R1544     1.5519383549690247e-01
    z[4,2,3]  R1545     2.8961020708084106e-01
    z[4,2,3]  R1546     -2.5664865970611572e-01
    z[4,2,3]  R1547     -4.9873286485671997e-01
    z[4,2,3]  R1548     -3.5075816512107849e-01
    z[4,2,3]  R1549     -5.5897700786590576e-01
    z[4,2,3]  R1550     -2.3413909971714020e-01
    z[4,2,3]  R1551     -3.6581665277481079e-01
    z[4,2,3]  R1552     -6.2053781747817993e-01
    z[4,2,4]  R24       1
    z[4,2,4]  R42       -1
    z[4,2,4]  R1488     -1
    z[4,2,4]  R1489     1
    z[4,2,4]  R1494     8.1056252121925354e-02
    z[4,2,4]  R1495     0.142792746424675
    z[4,2,4]  R1496     -8.0507266521453857e-01
    z[4,2,4]  R1497     -3.9802014827728271e-01
    z[4,2,4]  R1498     -4.7465908527374268e-01
    z[4,2,4]  R1499     -0.537653386592865
    z[4,2,4]  R1500     1.2213263660669327e-01
    z[4,2,4]  R1501     3.2871001958847046e-01
    z[4,2,4]  R1502     2.1572580933570862e-01
    z[4,2,4]  R1503     2.4480944871902466e-01
    z[4,2,4]  R1504     2.8845849633216858e-01
    z[4,2,4]  R1505     -6.0820616781711578e-02
    z[4,2,4]  R1506     1.4904613792896271e-01
    z[4,2,4]  R1507     4.2433872818946838e-02
    z[4,2,4]  R1508     1.1020025610923767e-01
    z[4,2,4]  R1509     7.6562032103538513e-02
    z[4,2,4]  R1510     7.3388224840164185e-01
    z[4,2,4]  R1511     7.9327476024627686e-01
    z[4,2,4]  R1512     3.6913216114044189e-01
    z[4,2,4]  R1513     4.1980534791946411e-02
    z[4,2,4]  R1514     -2.2857272997498512e-02
    z[4,2,4]  R1515     -4.3017558753490448e-02
    z[4,2,4]  R1516     4.3811939656734467e-02
    z[4,2,4]  R1517     3.4191107749938965e-01
    z[4,2,4]  R1518     -3.9321768283843994e-01
    z[4,2,4]  R1519     -3.0978059768676758e-01
    z[4,2,4]  R1520     -2.4362166225910187e-01
    z[4,2,4]  R1521     -3.9132431149482727e-02
    z[4,2,4]  R1522     -1.7526191473007202e-01
    z[4,2,4]  R1523     1.3096977770328522e-01
    z[4,2,4]  R1524     -2.5614660978317261e-01
    z[4,2,4]  R1525     -0.000798138091340661
    z[4,2,4]  R1526     5.5186992883682251e-01
    z[4,2,4]  R1527     -1.3819648325443268e-01
    z[4,2,4]  R1528     -1.6549403965473175e-01
    z[4,2,4]  R1529     8.1146311759948730e-01
    z[4,2,4]  R1530     2.5595462322235107e-01
    z[4,2,4]  R1531     4.7331121563911438e-01
    z[4,2,4]  R1532     2.3274032771587372e-01
    z[4,2,4]  R1533     -4.3243950605392456e-01
    z[4,2,4]  R1534     -2.6868479326367378e-02
    z[4,2,4]  R1535     -8.4718890488147736e-02
    z[4,2,4]  R1536     1.7959372699260712e-01
    z[4,2,4]  R1537     3.3769440650939941e-01
    z[4,2,4]  R1538     3.5924088954925537e-01
    z[4,2,4]  R1539     -1.5597642958164215e-01
    z[4,2,4]  R1540     9.0175405144691467e-02
    z[4,2,4]  R1541     4.9020549654960632e-01
    z[4,2,4]  R1542     5.0157213211059570e-01
    z[4,2,4]  R1543     -3.6766156554222107e-01
    z[4,2,4]  R1544     6.4462912082672119e-01
    z[4,2,4]  R1545     5.4894257336854935e-02
    z[4,2,4]  R1546     1.9418130815029144e-01
    z[4,2,4]  R1547     2.1522257477045059e-02
    z[4,2,4]  R1548     1.9847208261489868e-01
    z[4,2,4]  R1549     1.3483066856861115e-01
    z[4,2,4]  R1550     -2.4369807541370392e-01
    z[4,2,4]  R1551     7.6184707880020142e-01
    z[4,2,4]  R1552     5.7341301441192627e-01
    z[4,2,5]  R25       1
    z[4,2,5]  R43       -1
    z[4,2,5]  R1490     -1
    z[4,2,5]  R1491     1
    z[4,2,5]  R1494     -3.2239374518394470e-01
    z[4,2,5]  R1495     -2.5660082697868347e-01
    z[4,2,5]  R1496     1.2339268811047077e-02
    z[4,2,5]  R1497     9.2138200998306274e-02
    z[4,2,5]  R1498     -2.4084170162677765e-01
    z[4,2,5]  R1499     -4.0667504072189331e-01
    z[4,2,5]  R1500     -4.5615375041961670e-01
    z[4,2,5]  R1501     -5.0682887434959412e-02
    z[4,2,5]  R1502     -5.3031824529170990e-02
    z[4,2,5]  R1503     -3.7292614579200745e-02
    z[4,2,5]  R1504     1.4203681051731110e-01
    z[4,2,5]  R1505     8.4373086690902710e-02
    z[4,2,5]  R1506     -2.2015558183193207e-01
    z[4,2,5]  R1507     2.3934745788574219e-01
    z[4,2,5]  R1508     1.6793370246887207e-01
    z[4,2,5]  R1509     -5.6633424758911133e-01
    z[4,2,5]  R1510     3.3496430516242981e-01
    z[4,2,5]  R1511     2.1169048547744751e-01
    z[4,2,5]  R1512     -4.8653557896614075e-02
    z[4,2,5]  R1513     -4.1244491934776306e-01
    z[4,2,5]  R1514     8.6037427186965942e-01
    z[4,2,5]  R1515     5.9718143939971924e-01
    z[4,2,5]  R1516     -1.2719912827014923e-01
    z[4,2,5]  R1517     -6.2453597784042358e-03
    z[4,2,5]  R1518     1.5146744251251221e-01
    z[4,2,5]  R1519     1.6857126355171204e-01
    z[4,2,5]  R1520     1.3088262081146240e-01
    z[4,2,5]  R1521     -6.7186409235000610e-01
    z[4,2,5]  R1522     -5.4155224561691284e-01
    z[4,2,5]  R1523     -5.8668041229248047e-01
    z[4,2,5]  R1524     -3.8127186894416809e-01
    z[4,2,5]  R1525     1.9546292722225189e-01
    z[4,2,5]  R1526     1.2754661962389946e-02
    z[4,2,5]  R1527     -2.3319636285305023e-01
    z[4,2,5]  R1528     2.1404910087585449e-01
    z[4,2,5]  R1529     -3.6159527301788330e-01
    z[4,2,5]  R1530     4.9350535869598389e-01
    z[4,2,5]  R1531     3.0156826972961426e-01
    z[4,2,5]  R1532     0.588338315486908
    z[4,2,5]  R1533     6.5808808803558350e-01
    z[4,2,5]  R1534     7.5849437713623047e-01
    z[4,2,5]  R1535     2.5602813810110092e-02
    z[4,2,5]  R1536     -1.7964061116799712e-03
    z[4,2,5]  R1537     9.3446910381317139e-02
    z[4,2,5]  R1538     -1.8723461031913757e-01
    z[4,2,5]  R1539     4.0902689099311829e-02
    z[4,2,5]  R1540     7.3748230934143066e-02
    z[4,2,5]  R1541     -2.8898175805807114e-02
    z[4,2,5]  R1542     1.5492363274097443e-01
    z[4,2,5]  R1543     -7.8078046441078186e-02
    z[4,2,5]  R1544     -2.1046692132949829e-01
    z[4,2,5]  R1545     -1.1115522682666779e-01
    z[4,2,5]  R1546     -4.7295203804969788e-01
    z[4,2,5]  R1547     -0.629519522190094
    z[4,2,5]  R1548     -7.7274823188781738e-01
    z[4,2,5]  R1549     -5.2689379453659058e-01
    z[4,2,5]  R1550     1.8636273220181465e-02
    z[4,2,5]  R1551     6.7329309880733490e-02
    z[4,2,5]  R1552     4.7534830868244171e-02
    z[4,2,6]  R26       1
    z[4,2,6]  R44       -1
    z[4,2,6]  R1492     -1
    z[4,2,6]  R1493     1
    z[4,2,6]  R1494     8.4367677569389343e-02
    z[4,2,6]  R1495     -1.2470804899930954e-01
    z[4,2,6]  R1496     -5.8409009128808975e-02
    z[4,2,6]  R1497     -3.6872607469558716e-01
    z[4,2,6]  R1498     6.4095747470855713e-01
    z[4,2,6]  R1499     -9.9079899489879608e-02
    z[4,2,6]  R1500     5.8955080807209015e-02
    z[4,2,6]  R1501     -2.1402002871036530e-01
    z[4,2,6]  R1502     1.7176277935504913e-01
    z[4,2,6]  R1503     2.3929831385612488e-01
    z[4,2,6]  R1504     -7.0287567377090454e-01
    z[4,2,6]  R1505     -9.5990262925624847e-02
    z[4,2,6]  R1506     -1.5229627490043640e-01
    z[4,2,6]  R1507     9.8155051469802856e-02
    z[4,2,6]  R1508     2.1900594234466553e-01
    z[4,2,6]  R1509     -3.7142071127891541e-01
    z[4,2,6]  R1510     2.2928024828433990e-01
    z[4,2,6]  R1511     3.0301153659820557e-01
    z[4,2,6]  R1512     2.7891201898455620e-03
    z[4,2,6]  R1513     6.1072193086147308e-02
    z[4,2,6]  R1514     3.2782158255577087e-01
    z[4,2,6]  R1515     -2.7677747607231140e-01
    z[4,2,6]  R1516     4.0796067565679550e-02
    z[4,2,6]  R1517     2.3708198964595795e-01
    z[4,2,6]  R1518     -1.0968913137912750e-01
    z[4,2,6]  R1519     -0.0639939159154892
    z[4,2,6]  R1520     1.5299607813358307e-01
    z[4,2,6]  R1521     6.1401624232530594e-02
    z[4,2,6]  R1522     -1.5890444815158844e-01
    z[4,2,6]  R1523     -2.6737222075462341e-01
    z[4,2,6]  R1524     4.7085378319025040e-03
    z[4,2,6]  R1525     7.4312782287597656e-01
    z[4,2,6]  R1526     2.7942320704460144e-01
    z[4,2,6]  R1527     -8.2495003938674927e-01
    z[4,2,6]  R1528     7.7458268404006958e-01
    z[4,2,6]  R1529     3.4406915307044983e-01
    z[4,2,6]  R1530     2.1685181558132172e-01
    z[4,2,6]  R1531     -7.4513129889965057e-02
    z[4,2,6]  R1532     -5.2094870805740356e-01
    z[4,2,6]  R1533     -2.1409682929515839e-01
    z[4,2,6]  R1534     -1.2189421057701111e-01
    z[4,2,6]  R1535     9.9363557994365692e-02
    z[4,2,6]  R1536     -2.9586055874824524e-01
    z[4,2,6]  R1537     -4.3308973312377930e-02
    z[4,2,6]  R1538     -4.3077409267425537e-02
    z[4,2,6]  R1539     -3.2265511155128479e-01
    z[4,2,6]  R1540     4.9872463941574097e-01
    z[4,2,6]  R1541     1.3152271509170532e-01
    z[4,2,6]  R1542     3.0254775285720825e-01
    z[4,2,6]  R1543     -6.7440646886825562e-01
    z[4,2,6]  R1544     0.0453985333442688
    z[4,2,6]  R1545     4.5224779844284058e-01
    z[4,2,6]  R1546     5.3213948011398315e-01
    z[4,2,6]  R1547     2.1461309492588043e-01
    z[4,2,6]  R1548     -1.1411865800619125e-01
    z[4,2,6]  R1549     1.1244162172079086e-01
    z[4,2,6]  R1550     3.0335816740989685e-01
    z[4,2,6]  R1551     -0.417203426361084
    z[4,2,6]  R1552     -0.503563642501831
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1553     -1
    z[2,5,0]  R1554     1
    z[2,5,0]  R1567     -3.6661231517791748e-01
    z[2,5,0]  R1568     1.6546562314033508e-01
    z[2,5,0]  R1569     4.0289503335952759e-01
    z[2,5,0]  R1570     2.0910868048667908e-01
    z[2,5,0]  R1571     3.0914855003356934e-01
    z[2,5,0]  R1572     1.6202406585216522e-01
    z[2,5,0]  R1573     2.1579591929912567e-01
    z[2,5,0]  R1574     1.1821023374795914e-01
    z[2,5,0]  R1575     3.0235308408737183e-01
    z[2,5,0]  R1576     -1.9415308535099030e-01
    z[2,5,0]  R1577     -2.7080168947577477e-02
    z[2,5,0]  R1578     -5.7811617851257324e-01
    z[2,5,0]  R1579     -5.2692550420761108e-01
    z[2,5,0]  R1580     -5.3425353765487671e-01
    z[2,5,0]  R1581     -4.2574870586395264e-01
    z[2,5,0]  R1582     4.0422007441520691e-01
    z[2,5,0]  R1583     -5.1966708898544312e-01
    z[2,5,0]  R1584     6.1865937709808350e-01
    z[2,5,0]  R1585     3.4635260701179504e-01
    z[2,5,0]  R1586     7.3169477283954620e-02
    z[2,5,0]  R1587     3.3273005485534668e-01
    z[2,5,0]  R1588     4.5836099982261658e-01
    z[2,5,0]  R1589     2.7963202446699142e-02
    z[2,5,0]  R1590     -1.6530632972717285e-01
    z[2,5,0]  R1591     -1.1073750257492065e-01
    z[2,5,0]  R1592     -2.1354803442955017e-01
    z[2,5,0]  R1593     -0.153940349817276
    z[2,5,0]  R1594     -1.7421080172061920e-01
    z[2,5,0]  R1595     5.6375145912170410e-02
    z[2,5,0]  R1596     6.4163106679916382e-01
    z[2,5,0]  R1597     -4.7521561384201050e-01
    z[2,5,0]  R1598     3.3508926630020142e-02
    z[2,5,0]  R1599     -1.4299483597278595e-01
    z[2,5,0]  R1600     -1.6441199183464050e-01
    z[2,5,0]  R1601     -3.4808126091957092e-01
    z[2,5,0]  R1602     -4.0252998471260071e-01
    z[2,5,0]  R1603     -3.0971869826316833e-01
    z[2,5,0]  R1604     -3.2467669248580933e-01
    z[2,5,0]  R1605     -3.5864984989166260e-01
    z[2,5,0]  R1606     -5.7287907600402832e-01
    z[2,5,0]  R1607     -0.325132817029953
    z[2,5,0]  R1608     -4.0381217002868652e-01
    z[2,5,0]  R1609     -0.509609043598175
    z[2,5,0]  R1610     -5.1786619424819946e-01
    z[2,5,0]  R1611     6.9882661104202271e-01
    z[2,5,0]  R1612     -2.2907108068466187e-01
    z[2,5,0]  R1613     -2.9500603675842285e-01
    z[2,5,0]  R1614     5.8432853221893311e-01
    z[2,5,0]  R1615     4.8068276047706604e-01
    z[2,5,0]  R1616     -2.6974228024482727e-01
    z[2,5,0]  R1617     -4.0558192133903503e-01
    z[2,5,0]  R1618     4.4221732020378113e-01
    z[2,5,0]  R1619     4.6138077974319458e-01
    z[2,5,0]  R1620     3.5794076323509216e-01
    z[2,5,0]  R1621     2.1634428203105927e-01
    z[2,5,0]  R1622     -1.5749311447143555e-01
    z[2,5,0]  R1623     -1.0882386937737465e-02
    z[2,5,0]  R1624     2.3076352477073669e-01
    z[2,5,0]  R1625     4.3636098504066467e-01
    z[2,5,0]  R1626     1.2535629794001579e-02
    z[2,5,0]  R1627     3.6885414272546768e-02
    z[2,5,0]  R1628     5.5535793304443359e-01
    z[2,5,0]  R1629     -2.5221186876296997e-01
    z[2,5,0]  R1630     -3.3997863531112671e-02
    z[2,5,0]  R1631     6.9310680031776428e-02
    z[2,5,0]  R1632     -4.5445088297128677e-02
    z[2,5,0]  R1633     -1.1276463419198990e-01
    z[2,5,0]  R1634     1.2360639125108719e-01
    z[2,5,0]  R1635     2.7317786216735840e-01
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1555     -1
    z[2,5,1]  R1556     1
    z[2,5,1]  R1567     -1.3685827143490314e-02
    z[2,5,1]  R1568     4.5579671859741211e-01
    z[2,5,1]  R1569     5.3998893499374390e-01
    z[2,5,1]  R1570     3.4333053231239319e-01
    z[2,5,1]  R1571     2.7926534414291382e-01
    z[2,5,1]  R1572     1.0566697455942631e-02
    z[2,5,1]  R1573     1.1272235959768295e-01
    z[2,5,1]  R1574     4.8577859997749329e-02
    z[2,5,1]  R1575     -2.5733289122581482e-01
    z[2,5,1]  R1576     1.6795553267002106e-01
    z[2,5,1]  R1577     -3.2765606045722961e-01
    z[2,5,1]  R1578     -6.9910669326782227e-01
    z[2,5,1]  R1579     -7.0960718393325806e-01
    z[2,5,1]  R1580     -7.0828872919082642e-01
    z[2,5,1]  R1581     -7.4616920948028564e-01
    z[2,5,1]  R1582     8.2627201080322266e-01
    z[2,5,1]  R1583     -0.623083233833313
    z[2,5,1]  R1584     5.8256733417510986e-01
    z[2,5,1]  R1585     5.9217453002929688e-01
    z[2,5,1]  R1586     -4.8929625749588013e-01
    z[2,5,1]  R1587     -5.5335021018981934e-01
    z[2,5,1]  R1588     -4.6199139952659607e-01
    z[2,5,1]  R1589     0.621759831905365
    z[2,5,1]  R1590     5.0254029035568237e-01
    z[2,5,1]  R1591     4.4633430242538452e-01
    z[2,5,1]  R1592     5.6274503469467163e-01
    z[2,5,1]  R1593     -6.9187784194946289e-01
    z[2,5,1]  R1594     2.4417115747928619e-01
    z[2,5,1]  R1595     1.3327860832214355e-01
    z[2,5,1]  R1596     -1.1289706081151962e-01
    z[2,5,1]  R1597     -9.2442803084850311e-02
    z[2,5,1]  R1598     -1.4126157760620117e-01
    z[2,5,1]  R1599     -1.2021017074584961e-01
    z[2,5,1]  R1600     -1.6279260814189911e-01
    z[2,5,1]  R1601     -5.1551878452301025e-02
    z[2,5,1]  R1602     -1.0261062532663345e-01
    z[2,5,1]  R1603     -1.5986080467700958e-01
    z[2,5,1]  R1604     -8.5229448974132538e-02
    z[2,5,1]  R1605     -3.2290231436491013e-02
    z[2,5,1]  R1606     -6.7437601089477539e-01
    z[2,5,1]  R1607     -7.6250630617141724e-01
    z[2,5,1]  R1608     -6.2576764822006226e-01
    z[2,5,1]  R1609     -5.9989112615585327e-01
    z[2,5,1]  R1610     -5.3688186407089233e-01
    z[2,5,1]  R1611     4.8928743600845337e-01
    z[2,5,1]  R1612     -6.5893191099166870e-01
    z[2,5,1]  R1613     -5.7101702690124512e-01
    z[2,5,1]  R1614     1.2074148654937744e-01
    z[2,5,1]  R1615     -2.0272694528102875e-01
    z[2,5,1]  R1616     -7.5885915756225586e-01
    z[2,5,1]  R1617     -5.0641649961471558e-01
    z[2,5,1]  R1618     -3.5411059856414795e-01
    z[2,5,1]  R1619     -2.8774434700608253e-02
    z[2,5,1]  R1620     -4.1485038399696350e-01
    z[2,5,1]  R1621     -4.4661924242973328e-01
    z[2,5,1]  R1622     -7.0320534706115723e-01
    z[2,5,1]  R1623     -4.5102778077125549e-01
    z[2,5,1]  R1624     2.3100256919860840e-01
    z[2,5,1]  R1625     -2.1505138278007507e-01
    z[2,5,1]  R1626     -6.3967871665954590e-01
    z[2,5,1]  R1627     -4.1408398747444153e-01
    z[2,5,1]  R1628     0.520452618598938
    z[2,5,1]  R1629     -2.9941666126251221e-01
    z[2,5,1]  R1630     7.7732527256011963e-01
    z[2,5,1]  R1631     7.9937362670898438e-01
    z[2,5,1]  R1632     7.7364301681518555e-01
    z[2,5,1]  R1633     7.2622382640838623e-01
    z[2,5,1]  R1634     9.0468436479568481e-01
    z[2,5,1]  R1635     8.6709374189376831e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1557     -1
    z[2,5,2]  R1558     1
    z[2,5,2]  R1567     2.1258221566677094e-01
    z[2,5,2]  R1568     4.1581603884696960e-01
    z[2,5,2]  R1569     3.2558149099349976e-01
    z[2,5,2]  R1570     -2.8964450955390930e-01
    z[2,5,2]  R1571     -3.0477553606033325e-01
    z[2,5,2]  R1572     2.3961445689201355e-01
    z[2,5,2]  R1573     7.6453518867492676e-01
    z[2,5,2]  R1574     8.1429845094680786e-01
    z[2,5,2]  R1575     3.0611777305603027e-01
    z[2,5,2]  R1576     5.0546836853027344e-01
    z[2,5,2]  R1577     5.2546513080596924e-01
    z[2,5,2]  R1578     -2.5471404194831848e-01
    z[2,5,2]  R1579     -1.9017027318477631e-01
    z[2,5,2]  R1580     -2.2027122974395752e-01
    z[2,5,2]  R1581     9.2856585979461670e-02
    z[2,5,2]  R1582     -1.5305048227310181e-01
    z[2,5,2]  R1583     1.3614802621304989e-02
    z[2,5,2]  R1584     -1.2995676696300507e-01
    z[2,5,2]  R1585     3.7700325250625610e-01
    z[2,5,2]  R1586     -3.8925856351852417e-01
    z[2,5,2]  R1587     -3.1161662936210632e-01
    z[2,5,2]  R1588     -0.522205114364624
    z[2,5,2]  R1589     -4.6922508627176285e-02
    z[2,5,2]  R1590     -1.6904366016387939e-01
    z[2,5,2]  R1591     -1.2624402344226837e-01
    z[2,5,2]  R1592     1.2969402968883514e-01
    z[2,5,2]  R1593     -5.3946632146835327e-01
    z[2,5,2]  R1594     -1.3117274641990662e-01
    z[2,5,2]  R1595     -9.6711240708827972e-02
    z[2,5,2]  R1596     1.0780003666877747e-01
    z[2,5,2]  R1597     7.3124116659164429e-01
    z[2,5,2]  R1598     5.7421612739562988e-01
    z[2,5,2]  R1599     7.2630625963211060e-01
    z[2,5,2]  R1600     8.1204974651336670e-01
    z[2,5,2]  R1601     7.5538033246994019e-01
    z[2,5,2]  R1602     5.9786844253540039e-01
    z[2,5,2]  R1603     2.2927477955818176e-01
    z[2,5,2]  R1604     4.9712011218070984e-01
    z[2,5,2]  R1605     6.6889148950576782e-01
    z[2,5,2]  R1606     -3.2046550512313843e-01
    z[2,5,2]  R1607     -3.7707009911537170e-01
    z[2,5,2]  R1608     -8.2286477088928223e-02
    z[2,5,2]  R1609     -1.0160498321056366e-01
    z[2,5,2]  R1610     -1.9210581481456757e-01
    z[2,5,2]  R1611     -8.3123147487640381e-02
    z[2,5,2]  R1612     1.7333178222179413e-01
    z[2,5,2]  R1613     -4.6031072735786438e-02
    z[2,5,2]  R1614     -1.3563394546508789e-01
    z[2,5,2]  R1615     -1.3572248630225658e-02
    z[2,5,2]  R1616     3.0794867873191833e-01
    z[2,5,2]  R1617     5.8678197860717773e-01
    z[2,5,2]  R1618     4.4368335604667664e-01
    z[2,5,2]  R1619     -1.2148012965917587e-01
    z[2,5,2]  R1620     -9.4842031598091125e-02
    z[2,5,2]  R1621     5.3951416164636612e-02
    z[2,5,2]  R1622     -2.4943840503692627e-01
    z[2,5,2]  R1623     3.0690962076187134e-01
    z[2,5,2]  R1624     -1.8194435536861420e-01
    z[2,5,2]  R1625     9.2556074261665344e-02
    z[2,5,2]  R1626     5.6087291240692139e-01
    z[2,5,2]  R1627     2.5920915603637695e-01
    z[2,5,2]  R1628     -5.2315410226583481e-02
    z[2,5,2]  R1629     -2.4299649894237518e-01
    z[2,5,2]  R1630     2.8462827205657959e-02
    z[2,5,2]  R1631     -7.9752728343009949e-02
    z[2,5,2]  R1632     -1.9546903669834137e-01
    z[2,5,2]  R1633     -1.6521067917346954e-01
    z[2,5,2]  R1634     2.1789493039250374e-02
    z[2,5,2]  R1635     -7.9349920153617859e-02
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1559     -1
    z[2,5,3]  R1560     1
    z[2,5,3]  R1567     7.8052252531051636e-01
    z[2,5,3]  R1568     3.9015822112560272e-02
    z[2,5,3]  R1569     2.3934055864810944e-01
    z[2,5,3]  R1570     2.1962981671094894e-02
    z[2,5,3]  R1571     2.4569568037986755e-01
    z[2,5,3]  R1572     9.2812865972518921e-02
    z[2,5,3]  R1573     1.1253246106207371e-02
    z[2,5,3]  R1574     8.0901905894279480e-03
    z[2,5,3]  R1575     2.7741071581840515e-01
    z[2,5,3]  R1576     -1.1258782446384430e-01
    z[2,5,3]  R1577     1.5779989957809448e-01
    z[2,5,3]  R1578     -3.0732131004333496e-01
    z[2,5,3]  R1579     -2.5070270895957947e-01
    z[2,5,3]  R1580     -1.9933721423149109e-01
    z[2,5,3]  R1581     -2.9560244083404541e-01
    z[2,5,3]  R1582     1.8660595640540123e-02
    z[2,5,3]  R1583     -2.8148058056831360e-01
    z[2,5,3]  R1584     -5.0522230565547943e-02
    z[2,5,3]  R1585     -1.4186839759349823e-01
    z[2,5,3]  R1586     -8.7280482053756714e-02
    z[2,5,3]  R1587     1.5519383549690247e-01
    z[2,5,3]  R1588     2.8961020708084106e-01
    z[2,5,3]  R1589     -2.5664865970611572e-01
    z[2,5,3]  R1590     -4.9873286485671997e-01
    z[2,5,3]  R1591     -3.5075816512107849e-01
    z[2,5,3]  R1592     -5.5897700786590576e-01
    z[2,5,3]  R1593     -2.3413909971714020e-01
    z[2,5,3]  R1594     -3.6581665277481079e-01
    z[2,5,3]  R1595     -6.2053781747817993e-01
    z[2,5,3]  R1596     4.9130353331565857e-01
    z[2,5,3]  R1597     2.1447099745273590e-01
    z[2,5,3]  R1598     7.4778348207473755e-01
    z[2,5,3]  R1599     6.0457760095596313e-01
    z[2,5,3]  R1600     4.8526278138160706e-01
    z[2,5,3]  R1601     2.9882353544235229e-01
    z[2,5,3]  R1602     5.4019653797149658e-01
    z[2,5,3]  R1603     8.5413151979446411e-01
    z[2,5,3]  R1604     7.6380604505538940e-01
    z[2,5,3]  R1605     4.9203363060951233e-01
    z[2,5,3]  R1606     -2.7736705541610718e-01
    z[2,5,3]  R1607     -3.2460939884185791e-01
    z[2,5,3]  R1608     -4.0017729997634888e-01
    z[2,5,3]  R1609     -2.8906232118606567e-01
    z[2,5,3]  R1610     -2.9647415876388550e-01
    z[2,5,3]  R1611     -2.8446659445762634e-01
    z[2,5,3]  R1612     -3.8580140471458435e-01
    z[2,5,3]  R1613     -3.5557079315185547e-01
    z[2,5,3]  R1614     1.0866206884384155e-01
    z[2,5,3]  R1615     3.1090116500854492e-01
    z[2,5,3]  R1616     3.7762907147407532e-01
    z[2,5,3]  R1617     -2.8737068176269531e-01
    z[2,5,3]  R1618     -0.482251912355423
    z[2,5,3]  R1619     3.8285559415817261e-01
    z[2,5,3]  R1620     1.4088337123394012e-01
    z[2,5,3]  R1621     6.6598147153854370e-01
    z[2,5,3]  R1622     4.8683908581733704e-01
    z[2,5,3]  R1623     -1.5552611090242863e-02
    z[2,5,3]  R1624     5.3134995698928833e-01
    z[2,5,3]  R1625     -0.692699134349823
    z[2,5,3]  R1626     3.4966096282005310e-01
    z[2,5,3]  R1627     7.6672458648681641e-01
    z[2,5,3]  R1628     -1.5139228105545044e-01
    z[2,5,3]  R1629     1.5158000588417053e-01
    z[2,5,3]  R1630     -3.5130608081817627e-01
    z[2,5,3]  R1631     -2.8890445828437805e-01
    z[2,5,3]  R1632     -3.2266542315483093e-01
    z[2,5,3]  R1633     -4.8203226923942566e-01
    z[2,5,3]  R1634     -1.9956551492214203e-01
    z[2,5,3]  R1635     -2.9325437545776367e-01
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1561     -1
    z[2,5,4]  R1562     1
    z[2,5,4]  R1567     -2.5614660978317261e-01
    z[2,5,4]  R1568     -0.000798138091340661
    z[2,5,4]  R1569     5.5186992883682251e-01
    z[2,5,4]  R1570     -1.3819648325443268e-01
    z[2,5,4]  R1571     -1.6549403965473175e-01
    z[2,5,4]  R1572     8.1146311759948730e-01
    z[2,5,4]  R1573     2.5595462322235107e-01
    z[2,5,4]  R1574     4.7331121563911438e-01
    z[2,5,4]  R1575     2.3274032771587372e-01
    z[2,5,4]  R1576     -4.3243950605392456e-01
    z[2,5,4]  R1577     -2.6868479326367378e-02
    z[2,5,4]  R1578     -8.4718890488147736e-02
    z[2,5,4]  R1579     1.7959372699260712e-01
    z[2,5,4]  R1580     3.3769440650939941e-01
    z[2,5,4]  R1581     3.5924088954925537e-01
    z[2,5,4]  R1582     -1.5597642958164215e-01
    z[2,5,4]  R1583     9.0175405144691467e-02
    z[2,5,4]  R1584     4.9020549654960632e-01
    z[2,5,4]  R1585     5.0157213211059570e-01
    z[2,5,4]  R1586     -3.6766156554222107e-01
    z[2,5,4]  R1587     6.4462912082672119e-01
    z[2,5,4]  R1588     5.4894257336854935e-02
    z[2,5,4]  R1589     1.9418130815029144e-01
    z[2,5,4]  R1590     2.1522257477045059e-02
    z[2,5,4]  R1591     1.9847208261489868e-01
    z[2,5,4]  R1592     1.3483066856861115e-01
    z[2,5,4]  R1593     -2.4369807541370392e-01
    z[2,5,4]  R1594     7.6184707880020142e-01
    z[2,5,4]  R1595     5.7341301441192627e-01
    z[2,5,4]  R1596     -1.6896435990929604e-02
    z[2,5,4]  R1597     1.1893675476312637e-01
    z[2,5,4]  R1598     -2.3363986611366272e-01
    z[2,5,4]  R1599     5.6501183658838272e-02
    z[2,5,4]  R1600     9.9369265139102936e-02
    z[2,5,4]  R1601     -4.2273152619600296e-02
    z[2,5,4]  R1602     2.7650189399719238e-01
    z[2,5,4]  R1603     2.6277473568916321e-01
    z[2,5,4]  R1604     1.0319091379642487e-02
    z[2,5,4]  R1605     -2.1204583346843719e-01
    z[2,5,4]  R1606     -4.3894339352846146e-02
    z[2,5,4]  R1607     1.7493394017219543e-01
    z[2,5,4]  R1608     4.4317370653152466e-01
    z[2,5,4]  R1609     -4.9686712026596069e-01
    z[2,5,4]  R1610     -1.3466018438339233e-01
    z[2,5,4]  R1611     -2.9516938328742981e-01
    z[2,5,4]  R1612     -4.5699611306190491e-01
    z[2,5,4]  R1613     4.1366478800773621e-01
    z[2,5,4]  R1614     -6.9980108737945557e-01
    z[2,5,4]  R1615     6.1890256404876709e-01
    z[2,5,4]  R1616     1.2420323491096497e-01
    z[2,5,4]  R1617     2.1561962366104126e-01
    z[2,5,4]  R1618     -3.3257490396499634e-01
    z[2,5,4]  R1619     -6.7357122898101807e-01
    z[2,5,4]  R1620     -1.0187104344367981e-01
    z[2,5,4]  R1621     -3.2308768481016159e-02
    z[2,5,4]  R1622     -1.1614349484443665e-01
    z[2,5,4]  R1623     0.600644052028656
    z[2,5,4]  R1624     1.2698681652545929e-01
    z[2,5,4]  R1625     -1.6743943095207214e-01
    z[2,5,4]  R1626     -3.3669468760490417e-01
    z[2,5,4]  R1627     9.3967542052268982e-02
    z[2,5,4]  R1628     5.6981366872787476e-01
    z[2,5,4]  R1629     -6.8885219097137451e-01
    z[2,5,4]  R1630     3.9365351200103760e-01
    z[2,5,4]  R1631     4.3954676389694214e-01
    z[2,5,4]  R1632     3.0370175838470459e-01
    z[2,5,4]  R1633     2.0893611013889313e-01
    z[2,5,4]  R1634     2.5418680906295776e-01
    z[2,5,4]  R1635     2.1659302711486816e-01
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1563     -1
    z[2,5,5]  R1564     1
    z[2,5,5]  R1567     -3.8127186894416809e-01
    z[2,5,5]  R1568     1.9546292722225189e-01
    z[2,5,5]  R1569     1.2754661962389946e-02
    z[2,5,5]  R1570     -2.3319636285305023e-01
    z[2,5,5]  R1571     2.1404910087585449e-01
    z[2,5,5]  R1572     -3.6159527301788330e-01
    z[2,5,5]  R1573     4.9350535869598389e-01
    z[2,5,5]  R1574     3.0156826972961426e-01
    z[2,5,5]  R1575     0.588338315486908
    z[2,5,5]  R1576     6.5808808803558350e-01
    z[2,5,5]  R1577     7.5849437713623047e-01
    z[2,5,5]  R1578     2.5602813810110092e-02
    z[2,5,5]  R1579     -1.7964061116799712e-03
    z[2,5,5]  R1580     9.3446910381317139e-02
    z[2,5,5]  R1581     -1.8723461031913757e-01
    z[2,5,5]  R1582     4.0902689099311829e-02
    z[2,5,5]  R1583     7.3748230934143066e-02
    z[2,5,5]  R1584     -2.8898175805807114e-02
    z[2,5,5]  R1585     1.5492363274097443e-01
    z[2,5,5]  R1586     -7.8078046441078186e-02
    z[2,5,5]  R1587     -2.1046692132949829e-01
    z[2,5,5]  R1588     -1.1115522682666779e-01
    z[2,5,5]  R1589     -4.7295203804969788e-01
    z[2,5,5]  R1590     -0.629519522190094
    z[2,5,5]  R1591     -7.7274823188781738e-01
    z[2,5,5]  R1592     -5.2689379453659058e-01
    z[2,5,5]  R1593     1.8636273220181465e-02
    z[2,5,5]  R1594     6.7329309880733490e-02
    z[2,5,5]  R1595     4.7534830868244171e-02
    z[2,5,5]  R1596     -5.6757771968841553e-01
    z[2,5,5]  R1597     -4.1100424528121948e-01
    z[2,5,5]  R1598     -2.3790072649717331e-02
    z[2,5,5]  R1599     -1.7221823334693909e-01
    z[2,5,5]  R1600     -1.4542511105537415e-01
    z[2,5,5]  R1601     -3.0688026547431946e-01
    z[2,5,5]  R1602     -3.0909284949302673e-01
    z[2,5,5]  R1603     -1.3321830332279205e-01
    z[2,5,5]  R1604     -2.3807440698146820e-01
    z[2,5,5]  R1605     -3.6323902010917664e-01
    z[2,5,5]  R1606     7.4424915015697479e-02
    z[2,5,5]  R1607     1.8276399374008179e-01
    z[2,5,5]  R1608     6.3236460089683533e-02
    z[2,5,5]  R1609     -1.7125536501407623e-01
    z[2,5,5]  R1610     -2.3346212506294250e-01
    z[2,5,5]  R1611     1.9256035983562469e-01
    z[2,5,5]  R1612     1.5108166635036469e-01
    z[2,5,5]  R1613     -2.0481450483202934e-02
    z[2,5,5]  R1614     3.4916028380393982e-01
    z[2,5,5]  R1615     4.9116128683090210e-01
    z[2,5,5]  R1616     3.1380828469991684e-02
    z[2,5,5]  R1617     0.325045645236969
    z[2,5,5]  R1618     2.6756852865219116e-01
    z[2,5,5]  R1619     -1.1562506854534149e-01
    z[2,5,5]  R1620     5.1794809103012085e-01
    z[2,5,5]  R1621     4.0950044989585876e-01
    z[2,5,5]  R1622     2.6671406626701355e-01
    z[2,5,5]  R1623     2.3218253254890442e-01
    z[2,5,5]  R1624     5.9344559907913208e-02
    z[2,5,5]  R1625     -4.8516458272933960e-01
    z[2,5,5]  R1626     1.5722188353538513e-01
    z[2,5,5]  R1627     1.4611233770847321e-01
    z[2,5,5]  R1628     -1.0686865448951721e-01
    z[2,5,5]  R1629     5.3440326452255249e-01
    z[2,5,5]  R1630     -3.2610318064689636e-01
    z[2,5,5]  R1631     -1.9234703481197357e-01
    z[2,5,5]  R1632     -3.1847196817398071e-01
    z[2,5,5]  R1633     -3.6189454793930054e-01
    z[2,5,5]  R1634     -2.4750418961048126e-01
    z[2,5,5]  R1635     -1.3576509058475494e-01
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1565     -1
    z[2,5,6]  R1566     1
    z[2,5,6]  R1567     4.7085378319025040e-03
    z[2,5,6]  R1568     7.4312782287597656e-01
    z[2,5,6]  R1569     2.7942320704460144e-01
    z[2,5,6]  R1570     -8.2495003938674927e-01
    z[2,5,6]  R1571     7.7458268404006958e-01
    z[2,5,6]  R1572     3.4406915307044983e-01
    z[2,5,6]  R1573     2.1685181558132172e-01
    z[2,5,6]  R1574     -7.4513129889965057e-02
    z[2,5,6]  R1575     -5.2094870805740356e-01
    z[2,5,6]  R1576     -2.1409682929515839e-01
    z[2,5,6]  R1577     -1.2189421057701111e-01
    z[2,5,6]  R1578     9.9363557994365692e-02
    z[2,5,6]  R1579     -2.9586055874824524e-01
    z[2,5,6]  R1580     -4.3308973312377930e-02
    z[2,5,6]  R1581     -4.3077409267425537e-02
    z[2,5,6]  R1582     -3.2265511155128479e-01
    z[2,5,6]  R1583     4.9872463941574097e-01
    z[2,5,6]  R1584     1.3152271509170532e-01
    z[2,5,6]  R1585     3.0254775285720825e-01
    z[2,5,6]  R1586     -6.7440646886825562e-01
    z[2,5,6]  R1587     0.0453985333442688
    z[2,5,6]  R1588     4.5224779844284058e-01
    z[2,5,6]  R1589     5.3213948011398315e-01
    z[2,5,6]  R1590     2.1461309492588043e-01
    z[2,5,6]  R1591     -1.1411865800619125e-01
    z[2,5,6]  R1592     1.1244162172079086e-01
    z[2,5,6]  R1593     3.0335816740989685e-01
    z[2,5,6]  R1594     -0.417203426361084
    z[2,5,6]  R1595     -0.503563642501831
    z[2,5,6]  R1596     -1.1574598029255867e-02
    z[2,5,6]  R1597     4.2924996465444565e-02
    z[2,5,6]  R1598     -1.8672055006027222e-01
    z[2,5,6]  R1599     -1.9802938401699066e-01
    z[2,5,6]  R1600     1.4331719279289246e-01
    z[2,5,6]  R1601     3.4687790274620056e-01
    z[2,5,6]  R1602     -7.8677006065845490e-02
    z[2,5,6]  R1603     -9.8048657178878784e-02
    z[2,5,6]  R1604     2.6403272058814764e-03
    z[2,5,6]  R1605     -6.2519580125808716e-02
    z[2,5,6]  R1606     1.7300352454185486e-01
    z[2,5,6]  R1607     -3.6265037953853607e-02
    z[2,5,6]  R1608     2.7934902906417847e-01
    z[2,5,6]  R1609     1.0170172154903412e-01
    z[2,5,6]  R1610     -4.9611786007881165e-01
    z[2,5,6]  R1611     2.4536505341529846e-01
    z[2,5,6]  R1612     -3.2058927416801453e-01
    z[2,5,6]  R1613     -5.3555899858474731e-01
    z[2,5,6]  R1614     4.6294897794723511e-02
    z[2,5,6]  R1615     -8.1990055739879608e-02
    z[2,5,6]  R1616     -3.1228914856910706e-01
    z[2,5,6]  R1617     2.0340059418231249e-03
    z[2,5,6]  R1618     -2.5967034697532654e-01
    z[2,5,6]  R1619     -3.9736205339431763e-01
    z[2,5,6]  R1620     6.2632775306701660e-01
    z[2,5,6]  R1621     3.7222284078598022e-01
    z[2,5,6]  R1622     3.1119233369827271e-01
    z[2,5,6]  R1623     5.3603923320770264e-01
    z[2,5,6]  R1624     -7.4719607830047607e-01
    z[2,5,6]  R1625     1.0734346508979797e-01
    z[2,5,6]  R1626     1.2542261183261871e-01
    z[2,5,6]  R1627     -3.7674814462661743e-01
    z[2,5,6]  R1628     -2.4277888238430023e-01
    z[2,5,6]  R1629     -6.7902550101280212e-02
    z[2,5,6]  R1630     -9.5274388790130615e-02
    z[2,5,6]  R1631     1.9019149243831635e-01
    z[2,5,6]  R1632     -2.5185507535934448e-01
    z[2,5,6]  R1633     -1.6003604233264923e-01
    z[2,5,6]  R1634     9.8591828718781471e-03
    z[2,5,6]  R1635     -1.2602771818637848e-01
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1636     -1
    z[5,2,0]  R1637     1
    z[5,2,0]  R1650     6.4163106679916382e-01
    z[5,2,0]  R1651     -4.7521561384201050e-01
    z[5,2,0]  R1652     3.3508926630020142e-02
    z[5,2,0]  R1653     -1.4299483597278595e-01
    z[5,2,0]  R1654     -1.6441199183464050e-01
    z[5,2,0]  R1655     -3.4808126091957092e-01
    z[5,2,0]  R1656     -4.0252998471260071e-01
    z[5,2,0]  R1657     -3.0971869826316833e-01
    z[5,2,0]  R1658     -3.2467669248580933e-01
    z[5,2,0]  R1659     -3.5864984989166260e-01
    z[5,2,0]  R1660     -5.7287907600402832e-01
    z[5,2,0]  R1661     -0.325132817029953
    z[5,2,0]  R1662     -4.0381217002868652e-01
    z[5,2,0]  R1663     -0.509609043598175
    z[5,2,0]  R1664     -5.1786619424819946e-01
    z[5,2,0]  R1665     6.9882661104202271e-01
    z[5,2,0]  R1666     -2.2907108068466187e-01
    z[5,2,0]  R1667     -2.9500603675842285e-01
    z[5,2,0]  R1668     5.8432853221893311e-01
    z[5,2,0]  R1669     4.8068276047706604e-01
    z[5,2,0]  R1670     -2.6974228024482727e-01
    z[5,2,0]  R1671     -4.0558192133903503e-01
    z[5,2,0]  R1672     4.4221732020378113e-01
    z[5,2,0]  R1673     4.6138077974319458e-01
    z[5,2,0]  R1674     3.5794076323509216e-01
    z[5,2,0]  R1675     2.1634428203105927e-01
    z[5,2,0]  R1676     -1.5749311447143555e-01
    z[5,2,0]  R1677     -1.0882386937737465e-02
    z[5,2,0]  R1678     2.3076352477073669e-01
    z[5,2,0]  R1679     4.3636098504066467e-01
    z[5,2,0]  R1680     1.2535629794001579e-02
    z[5,2,0]  R1681     3.6885414272546768e-02
    z[5,2,0]  R1682     5.5535793304443359e-01
    z[5,2,0]  R1683     -2.5221186876296997e-01
    z[5,2,0]  R1684     -3.3997863531112671e-02
    z[5,2,0]  R1685     6.9310680031776428e-02
    z[5,2,0]  R1686     -4.5445088297128677e-02
    z[5,2,0]  R1687     -1.1276463419198990e-01
    z[5,2,0]  R1688     1.2360639125108719e-01
    z[5,2,0]  R1689     2.7317786216735840e-01
    z[5,2,0]  R1690     -3.6661231517791748e-01
    z[5,2,0]  R1691     1.6546562314033508e-01
    z[5,2,0]  R1692     4.0289503335952759e-01
    z[5,2,0]  R1693     2.0910868048667908e-01
    z[5,2,0]  R1694     3.0914855003356934e-01
    z[5,2,0]  R1695     1.6202406585216522e-01
    z[5,2,0]  R1696     2.1579591929912567e-01
    z[5,2,0]  R1697     1.1821023374795914e-01
    z[5,2,0]  R1698     3.0235308408737183e-01
    z[5,2,0]  R1699     -1.9415308535099030e-01
    z[5,2,0]  R1700     -2.7080168947577477e-02
    z[5,2,0]  R1701     -5.7811617851257324e-01
    z[5,2,0]  R1702     -5.2692550420761108e-01
    z[5,2,0]  R1703     -5.3425353765487671e-01
    z[5,2,0]  R1704     -4.2574870586395264e-01
    z[5,2,0]  R1705     4.0422007441520691e-01
    z[5,2,0]  R1706     -5.1966708898544312e-01
    z[5,2,0]  R1707     6.1865937709808350e-01
    z[5,2,0]  R1708     3.4635260701179504e-01
    z[5,2,0]  R1709     7.3169477283954620e-02
    z[5,2,0]  R1710     3.3273005485534668e-01
    z[5,2,0]  R1711     4.5836099982261658e-01
    z[5,2,0]  R1712     2.7963202446699142e-02
    z[5,2,0]  R1713     -1.6530632972717285e-01
    z[5,2,0]  R1714     -1.1073750257492065e-01
    z[5,2,0]  R1715     -2.1354803442955017e-01
    z[5,2,0]  R1716     -0.153940349817276
    z[5,2,0]  R1717     -1.7421080172061920e-01
    z[5,2,0]  R1718     5.6375145912170410e-02
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1638     -1
    z[5,2,1]  R1639     1
    z[5,2,1]  R1650     -1.1289706081151962e-01
    z[5,2,1]  R1651     -9.2442803084850311e-02
    z[5,2,1]  R1652     -1.4126157760620117e-01
    z[5,2,1]  R1653     -1.2021017074584961e-01
    z[5,2,1]  R1654     -1.6279260814189911e-01
    z[5,2,1]  R1655     -5.1551878452301025e-02
    z[5,2,1]  R1656     -1.0261062532663345e-01
    z[5,2,1]  R1657     -1.5986080467700958e-01
    z[5,2,1]  R1658     -8.5229448974132538e-02
    z[5,2,1]  R1659     -3.2290231436491013e-02
    z[5,2,1]  R1660     -6.7437601089477539e-01
    z[5,2,1]  R1661     -7.6250630617141724e-01
    z[5,2,1]  R1662     -6.2576764822006226e-01
    z[5,2,1]  R1663     -5.9989112615585327e-01
    z[5,2,1]  R1664     -5.3688186407089233e-01
    z[5,2,1]  R1665     4.8928743600845337e-01
    z[5,2,1]  R1666     -6.5893191099166870e-01
    z[5,2,1]  R1667     -5.7101702690124512e-01
    z[5,2,1]  R1668     1.2074148654937744e-01
    z[5,2,1]  R1669     -2.0272694528102875e-01
    z[5,2,1]  R1670     -7.5885915756225586e-01
    z[5,2,1]  R1671     -5.0641649961471558e-01
    z[5,2,1]  R1672     -3.5411059856414795e-01
    z[5,2,1]  R1673     -2.8774434700608253e-02
    z[5,2,1]  R1674     -4.1485038399696350e-01
    z[5,2,1]  R1675     -4.4661924242973328e-01
    z[5,2,1]  R1676     -7.0320534706115723e-01
    z[5,2,1]  R1677     -4.5102778077125549e-01
    z[5,2,1]  R1678     2.3100256919860840e-01
    z[5,2,1]  R1679     -2.1505138278007507e-01
    z[5,2,1]  R1680     -6.3967871665954590e-01
    z[5,2,1]  R1681     -4.1408398747444153e-01
    z[5,2,1]  R1682     0.520452618598938
    z[5,2,1]  R1683     -2.9941666126251221e-01
    z[5,2,1]  R1684     7.7732527256011963e-01
    z[5,2,1]  R1685     7.9937362670898438e-01
    z[5,2,1]  R1686     7.7364301681518555e-01
    z[5,2,1]  R1687     7.2622382640838623e-01
    z[5,2,1]  R1688     9.0468436479568481e-01
    z[5,2,1]  R1689     8.6709374189376831e-01
    z[5,2,1]  R1690     -1.3685827143490314e-02
    z[5,2,1]  R1691     4.5579671859741211e-01
    z[5,2,1]  R1692     5.3998893499374390e-01
    z[5,2,1]  R1693     3.4333053231239319e-01
    z[5,2,1]  R1694     2.7926534414291382e-01
    z[5,2,1]  R1695     1.0566697455942631e-02
    z[5,2,1]  R1696     1.1272235959768295e-01
    z[5,2,1]  R1697     4.8577859997749329e-02
    z[5,2,1]  R1698     -2.5733289122581482e-01
    z[5,2,1]  R1699     1.6795553267002106e-01
    z[5,2,1]  R1700     -3.2765606045722961e-01
    z[5,2,1]  R1701     -6.9910669326782227e-01
    z[5,2,1]  R1702     -7.0960718393325806e-01
    z[5,2,1]  R1703     -7.0828872919082642e-01
    z[5,2,1]  R1704     -7.4616920948028564e-01
    z[5,2,1]  R1705     8.2627201080322266e-01
    z[5,2,1]  R1706     -0.623083233833313
    z[5,2,1]  R1707     5.8256733417510986e-01
    z[5,2,1]  R1708     5.9217453002929688e-01
    z[5,2,1]  R1709     -4.8929625749588013e-01
    z[5,2,1]  R1710     -5.5335021018981934e-01
    z[5,2,1]  R1711     -4.6199139952659607e-01
    z[5,2,1]  R1712     0.621759831905365
    z[5,2,1]  R1713     5.0254029035568237e-01
    z[5,2,1]  R1714     4.4633430242538452e-01
    z[5,2,1]  R1715     5.6274503469467163e-01
    z[5,2,1]  R1716     -6.9187784194946289e-01
    z[5,2,1]  R1717     2.4417115747928619e-01
    z[5,2,1]  R1718     1.3327860832214355e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1640     -1
    z[5,2,2]  R1641     1
    z[5,2,2]  R1650     1.0780003666877747e-01
    z[5,2,2]  R1651     7.3124116659164429e-01
    z[5,2,2]  R1652     5.7421612739562988e-01
    z[5,2,2]  R1653     7.2630625963211060e-01
    z[5,2,2]  R1654     8.1204974651336670e-01
    z[5,2,2]  R1655     7.5538033246994019e-01
    z[5,2,2]  R1656     5.9786844253540039e-01
    z[5,2,2]  R1657     2.2927477955818176e-01
    z[5,2,2]  R1658     4.9712011218070984e-01
    z[5,2,2]  R1659     6.6889148950576782e-01
    z[5,2,2]  R1660     -3.2046550512313843e-01
    z[5,2,2]  R1661     -3.7707009911537170e-01
    z[5,2,2]  R1662     -8.2286477088928223e-02
    z[5,2,2]  R1663     -1.0160498321056366e-01
    z[5,2,2]  R1664     -1.9210581481456757e-01
    z[5,2,2]  R1665     -8.3123147487640381e-02
    z[5,2,2]  R1666     1.7333178222179413e-01
    z[5,2,2]  R1667     -4.6031072735786438e-02
    z[5,2,2]  R1668     -1.3563394546508789e-01
    z[5,2,2]  R1669     -1.3572248630225658e-02
    z[5,2,2]  R1670     3.0794867873191833e-01
    z[5,2,2]  R1671     5.8678197860717773e-01
    z[5,2,2]  R1672     4.4368335604667664e-01
    z[5,2,2]  R1673     -1.2148012965917587e-01
    z[5,2,2]  R1674     -9.4842031598091125e-02
    z[5,2,2]  R1675     5.3951416164636612e-02
    z[5,2,2]  R1676     -2.4943840503692627e-01
    z[5,2,2]  R1677     3.0690962076187134e-01
    z[5,2,2]  R1678     -1.8194435536861420e-01
    z[5,2,2]  R1679     9.2556074261665344e-02
    z[5,2,2]  R1680     5.6087291240692139e-01
    z[5,2,2]  R1681     2.5920915603637695e-01
    z[5,2,2]  R1682     -5.2315410226583481e-02
    z[5,2,2]  R1683     -2.4299649894237518e-01
    z[5,2,2]  R1684     2.8462827205657959e-02
    z[5,2,2]  R1685     -7.9752728343009949e-02
    z[5,2,2]  R1686     -1.9546903669834137e-01
    z[5,2,2]  R1687     -1.6521067917346954e-01
    z[5,2,2]  R1688     2.1789493039250374e-02
    z[5,2,2]  R1689     -7.9349920153617859e-02
    z[5,2,2]  R1690     2.1258221566677094e-01
    z[5,2,2]  R1691     4.1581603884696960e-01
    z[5,2,2]  R1692     3.2558149099349976e-01
    z[5,2,2]  R1693     -2.8964450955390930e-01
    z[5,2,2]  R1694     -3.0477553606033325e-01
    z[5,2,2]  R1695     2.3961445689201355e-01
    z[5,2,2]  R1696     7.6453518867492676e-01
    z[5,2,2]  R1697     8.1429845094680786e-01
    z[5,2,2]  R1698     3.0611777305603027e-01
    z[5,2,2]  R1699     5.0546836853027344e-01
    z[5,2,2]  R1700     5.2546513080596924e-01
    z[5,2,2]  R1701     -2.5471404194831848e-01
    z[5,2,2]  R1702     -1.9017027318477631e-01
    z[5,2,2]  R1703     -2.2027122974395752e-01
    z[5,2,2]  R1704     9.2856585979461670e-02
    z[5,2,2]  R1705     -1.5305048227310181e-01
    z[5,2,2]  R1706     1.3614802621304989e-02
    z[5,2,2]  R1707     -1.2995676696300507e-01
    z[5,2,2]  R1708     3.7700325250625610e-01
    z[5,2,2]  R1709     -3.8925856351852417e-01
    z[5,2,2]  R1710     -3.1161662936210632e-01
    z[5,2,2]  R1711     -0.522205114364624
    z[5,2,2]  R1712     -4.6922508627176285e-02
    z[5,2,2]  R1713     -1.6904366016387939e-01
    z[5,2,2]  R1714     -1.2624402344226837e-01
    z[5,2,2]  R1715     1.2969402968883514e-01
    z[5,2,2]  R1716     -5.3946632146835327e-01
    z[5,2,2]  R1717     -1.3117274641990662e-01
    z[5,2,2]  R1718     -9.6711240708827972e-02
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1642     -1
    z[5,2,3]  R1643     1
    z[5,2,3]  R1650     4.9130353331565857e-01
    z[5,2,3]  R1651     2.1447099745273590e-01
    z[5,2,3]  R1652     7.4778348207473755e-01
    z[5,2,3]  R1653     6.0457760095596313e-01
    z[5,2,3]  R1654     4.8526278138160706e-01
    z[5,2,3]  R1655     2.9882353544235229e-01
    z[5,2,3]  R1656     5.4019653797149658e-01
    z[5,2,3]  R1657     8.5413151979446411e-01
    z[5,2,3]  R1658     7.6380604505538940e-01
    z[5,2,3]  R1659     4.9203363060951233e-01
    z[5,2,3]  R1660     -2.7736705541610718e-01
    z[5,2,3]  R1661     -3.2460939884185791e-01
    z[5,2,3]  R1662     -4.0017729997634888e-01
    z[5,2,3]  R1663     -2.8906232118606567e-01
    z[5,2,3]  R1664     -2.9647415876388550e-01
    z[5,2,3]  R1665     -2.8446659445762634e-01
    z[5,2,3]  R1666     -3.8580140471458435e-01
    z[5,2,3]  R1667     -3.5557079315185547e-01
    z[5,2,3]  R1668     1.0866206884384155e-01
    z[5,2,3]  R1669     3.1090116500854492e-01
    z[5,2,3]  R1670     3.7762907147407532e-01
    z[5,2,3]  R1671     -2.8737068176269531e-01
    z[5,2,3]  R1672     -0.482251912355423
    z[5,2,3]  R1673     3.8285559415817261e-01
    z[5,2,3]  R1674     1.4088337123394012e-01
    z[5,2,3]  R1675     6.6598147153854370e-01
    z[5,2,3]  R1676     4.8683908581733704e-01
    z[5,2,3]  R1677     -1.5552611090242863e-02
    z[5,2,3]  R1678     5.3134995698928833e-01
    z[5,2,3]  R1679     -0.692699134349823
    z[5,2,3]  R1680     3.4966096282005310e-01
    z[5,2,3]  R1681     7.6672458648681641e-01
    z[5,2,3]  R1682     -1.5139228105545044e-01
    z[5,2,3]  R1683     1.5158000588417053e-01
    z[5,2,3]  R1684     -3.5130608081817627e-01
    z[5,2,3]  R1685     -2.8890445828437805e-01
    z[5,2,3]  R1686     -3.2266542315483093e-01
    z[5,2,3]  R1687     -4.8203226923942566e-01
    z[5,2,3]  R1688     -1.9956551492214203e-01
    z[5,2,3]  R1689     -2.9325437545776367e-01
    z[5,2,3]  R1690     7.8052252531051636e-01
    z[5,2,3]  R1691     3.9015822112560272e-02
    z[5,2,3]  R1692     2.3934055864810944e-01
    z[5,2,3]  R1693     2.1962981671094894e-02
    z[5,2,3]  R1694     2.4569568037986755e-01
    z[5,2,3]  R1695     9.2812865972518921e-02
    z[5,2,3]  R1696     1.1253246106207371e-02
    z[5,2,3]  R1697     8.0901905894279480e-03
    z[5,2,3]  R1698     2.7741071581840515e-01
    z[5,2,3]  R1699     -1.1258782446384430e-01
    z[5,2,3]  R1700     1.5779989957809448e-01
    z[5,2,3]  R1701     -3.0732131004333496e-01
    z[5,2,3]  R1702     -2.5070270895957947e-01
    z[5,2,3]  R1703     -1.9933721423149109e-01
    z[5,2,3]  R1704     -2.9560244083404541e-01
    z[5,2,3]  R1705     1.8660595640540123e-02
    z[5,2,3]  R1706     -2.8148058056831360e-01
    z[5,2,3]  R1707     -5.0522230565547943e-02
    z[5,2,3]  R1708     -1.4186839759349823e-01
    z[5,2,3]  R1709     -8.7280482053756714e-02
    z[5,2,3]  R1710     1.5519383549690247e-01
    z[5,2,3]  R1711     2.8961020708084106e-01
    z[5,2,3]  R1712     -2.5664865970611572e-01
    z[5,2,3]  R1713     -4.9873286485671997e-01
    z[5,2,3]  R1714     -3.5075816512107849e-01
    z[5,2,3]  R1715     -5.5897700786590576e-01
    z[5,2,3]  R1716     -2.3413909971714020e-01
    z[5,2,3]  R1717     -3.6581665277481079e-01
    z[5,2,3]  R1718     -6.2053781747817993e-01
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1644     -1
    z[5,2,4]  R1645     1
    z[5,2,4]  R1650     -1.6896435990929604e-02
    z[5,2,4]  R1651     1.1893675476312637e-01
    z[5,2,4]  R1652     -2.3363986611366272e-01
    z[5,2,4]  R1653     5.6501183658838272e-02
    z[5,2,4]  R1654     9.9369265139102936e-02
    z[5,2,4]  R1655     -4.2273152619600296e-02
    z[5,2,4]  R1656     2.7650189399719238e-01
    z[5,2,4]  R1657     2.6277473568916321e-01
    z[5,2,4]  R1658     1.0319091379642487e-02
    z[5,2,4]  R1659     -2.1204583346843719e-01
    z[5,2,4]  R1660     -4.3894339352846146e-02
    z[5,2,4]  R1661     1.7493394017219543e-01
    z[5,2,4]  R1662     4.4317370653152466e-01
    z[5,2,4]  R1663     -4.9686712026596069e-01
    z[5,2,4]  R1664     -1.3466018438339233e-01
    z[5,2,4]  R1665     -2.9516938328742981e-01
    z[5,2,4]  R1666     -4.5699611306190491e-01
    z[5,2,4]  R1667     4.1366478800773621e-01
    z[5,2,4]  R1668     -6.9980108737945557e-01
    z[5,2,4]  R1669     6.1890256404876709e-01
    z[5,2,4]  R1670     1.2420323491096497e-01
    z[5,2,4]  R1671     2.1561962366104126e-01
    z[5,2,4]  R1672     -3.3257490396499634e-01
    z[5,2,4]  R1673     -6.7357122898101807e-01
    z[5,2,4]  R1674     -1.0187104344367981e-01
    z[5,2,4]  R1675     -3.2308768481016159e-02
    z[5,2,4]  R1676     -1.1614349484443665e-01
    z[5,2,4]  R1677     0.600644052028656
    z[5,2,4]  R1678     1.2698681652545929e-01
    z[5,2,4]  R1679     -1.6743943095207214e-01
    z[5,2,4]  R1680     -3.3669468760490417e-01
    z[5,2,4]  R1681     9.3967542052268982e-02
    z[5,2,4]  R1682     5.6981366872787476e-01
    z[5,2,4]  R1683     -6.8885219097137451e-01
    z[5,2,4]  R1684     3.9365351200103760e-01
    z[5,2,4]  R1685     4.3954676389694214e-01
    z[5,2,4]  R1686     3.0370175838470459e-01
    z[5,2,4]  R1687     2.0893611013889313e-01
    z[5,2,4]  R1688     2.5418680906295776e-01
    z[5,2,4]  R1689     2.1659302711486816e-01
    z[5,2,4]  R1690     -2.5614660978317261e-01
    z[5,2,4]  R1691     -0.000798138091340661
    z[5,2,4]  R1692     5.5186992883682251e-01
    z[5,2,4]  R1693     -1.3819648325443268e-01
    z[5,2,4]  R1694     -1.6549403965473175e-01
    z[5,2,4]  R1695     8.1146311759948730e-01
    z[5,2,4]  R1696     2.5595462322235107e-01
    z[5,2,4]  R1697     4.7331121563911438e-01
    z[5,2,4]  R1698     2.3274032771587372e-01
    z[5,2,4]  R1699     -4.3243950605392456e-01
    z[5,2,4]  R1700     -2.6868479326367378e-02
    z[5,2,4]  R1701     -8.4718890488147736e-02
    z[5,2,4]  R1702     1.7959372699260712e-01
    z[5,2,4]  R1703     3.3769440650939941e-01
    z[5,2,4]  R1704     3.5924088954925537e-01
    z[5,2,4]  R1705     -1.5597642958164215e-01
    z[5,2,4]  R1706     9.0175405144691467e-02
    z[5,2,4]  R1707     4.9020549654960632e-01
    z[5,2,4]  R1708     5.0157213211059570e-01
    z[5,2,4]  R1709     -3.6766156554222107e-01
    z[5,2,4]  R1710     6.4462912082672119e-01
    z[5,2,4]  R1711     5.4894257336854935e-02
    z[5,2,4]  R1712     1.9418130815029144e-01
    z[5,2,4]  R1713     2.1522257477045059e-02
    z[5,2,4]  R1714     1.9847208261489868e-01
    z[5,2,4]  R1715     1.3483066856861115e-01
    z[5,2,4]  R1716     -2.4369807541370392e-01
    z[5,2,4]  R1717     7.6184707880020142e-01
    z[5,2,4]  R1718     5.7341301441192627e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1646     -1
    z[5,2,5]  R1647     1
    z[5,2,5]  R1650     -5.6757771968841553e-01
    z[5,2,5]  R1651     -4.1100424528121948e-01
    z[5,2,5]  R1652     -2.3790072649717331e-02
    z[5,2,5]  R1653     -1.7221823334693909e-01
    z[5,2,5]  R1654     -1.4542511105537415e-01
    z[5,2,5]  R1655     -3.0688026547431946e-01
    z[5,2,5]  R1656     -3.0909284949302673e-01
    z[5,2,5]  R1657     -1.3321830332279205e-01
    z[5,2,5]  R1658     -2.3807440698146820e-01
    z[5,2,5]  R1659     -3.6323902010917664e-01
    z[5,2,5]  R1660     7.4424915015697479e-02
    z[5,2,5]  R1661     1.8276399374008179e-01
    z[5,2,5]  R1662     6.3236460089683533e-02
    z[5,2,5]  R1663     -1.7125536501407623e-01
    z[5,2,5]  R1664     -2.3346212506294250e-01
    z[5,2,5]  R1665     1.9256035983562469e-01
    z[5,2,5]  R1666     1.5108166635036469e-01
    z[5,2,5]  R1667     -2.0481450483202934e-02
    z[5,2,5]  R1668     3.4916028380393982e-01
    z[5,2,5]  R1669     4.9116128683090210e-01
    z[5,2,5]  R1670     3.1380828469991684e-02
    z[5,2,5]  R1671     0.325045645236969
    z[5,2,5]  R1672     2.6756852865219116e-01
    z[5,2,5]  R1673     -1.1562506854534149e-01
    z[5,2,5]  R1674     5.1794809103012085e-01
    z[5,2,5]  R1675     4.0950044989585876e-01
    z[5,2,5]  R1676     2.6671406626701355e-01
    z[5,2,5]  R1677     2.3218253254890442e-01
    z[5,2,5]  R1678     5.9344559907913208e-02
    z[5,2,5]  R1679     -4.8516458272933960e-01
    z[5,2,5]  R1680     1.5722188353538513e-01
    z[5,2,5]  R1681     1.4611233770847321e-01
    z[5,2,5]  R1682     -1.0686865448951721e-01
    z[5,2,5]  R1683     5.3440326452255249e-01
    z[5,2,5]  R1684     -3.2610318064689636e-01
    z[5,2,5]  R1685     -1.9234703481197357e-01
    z[5,2,5]  R1686     -3.1847196817398071e-01
    z[5,2,5]  R1687     -3.6189454793930054e-01
    z[5,2,5]  R1688     -2.4750418961048126e-01
    z[5,2,5]  R1689     -1.3576509058475494e-01
    z[5,2,5]  R1690     -3.8127186894416809e-01
    z[5,2,5]  R1691     1.9546292722225189e-01
    z[5,2,5]  R1692     1.2754661962389946e-02
    z[5,2,5]  R1693     -2.3319636285305023e-01
    z[5,2,5]  R1694     2.1404910087585449e-01
    z[5,2,5]  R1695     -3.6159527301788330e-01
    z[5,2,5]  R1696     4.9350535869598389e-01
    z[5,2,5]  R1697     3.0156826972961426e-01
    z[5,2,5]  R1698     0.588338315486908
    z[5,2,5]  R1699     6.5808808803558350e-01
    z[5,2,5]  R1700     7.5849437713623047e-01
    z[5,2,5]  R1701     2.5602813810110092e-02
    z[5,2,5]  R1702     -1.7964061116799712e-03
    z[5,2,5]  R1703     9.3446910381317139e-02
    z[5,2,5]  R1704     -1.8723461031913757e-01
    z[5,2,5]  R1705     4.0902689099311829e-02
    z[5,2,5]  R1706     7.3748230934143066e-02
    z[5,2,5]  R1707     -2.8898175805807114e-02
    z[5,2,5]  R1708     1.5492363274097443e-01
    z[5,2,5]  R1709     -7.8078046441078186e-02
    z[5,2,5]  R1710     -2.1046692132949829e-01
    z[5,2,5]  R1711     -1.1115522682666779e-01
    z[5,2,5]  R1712     -4.7295203804969788e-01
    z[5,2,5]  R1713     -0.629519522190094
    z[5,2,5]  R1714     -7.7274823188781738e-01
    z[5,2,5]  R1715     -5.2689379453659058e-01
    z[5,2,5]  R1716     1.8636273220181465e-02
    z[5,2,5]  R1717     6.7329309880733490e-02
    z[5,2,5]  R1718     4.7534830868244171e-02
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1648     -1
    z[5,2,6]  R1649     1
    z[5,2,6]  R1650     -1.1574598029255867e-02
    z[5,2,6]  R1651     4.2924996465444565e-02
    z[5,2,6]  R1652     -1.8672055006027222e-01
    z[5,2,6]  R1653     -1.9802938401699066e-01
    z[5,2,6]  R1654     1.4331719279289246e-01
    z[5,2,6]  R1655     3.4687790274620056e-01
    z[5,2,6]  R1656     -7.8677006065845490e-02
    z[5,2,6]  R1657     -9.8048657178878784e-02
    z[5,2,6]  R1658     2.6403272058814764e-03
    z[5,2,6]  R1659     -6.2519580125808716e-02
    z[5,2,6]  R1660     1.7300352454185486e-01
    z[5,2,6]  R1661     -3.6265037953853607e-02
    z[5,2,6]  R1662     2.7934902906417847e-01
    z[5,2,6]  R1663     1.0170172154903412e-01
    z[5,2,6]  R1664     -4.9611786007881165e-01
    z[5,2,6]  R1665     2.4536505341529846e-01
    z[5,2,6]  R1666     -3.2058927416801453e-01
    z[5,2,6]  R1667     -5.3555899858474731e-01
    z[5,2,6]  R1668     4.6294897794723511e-02
    z[5,2,6]  R1669     -8.1990055739879608e-02
    z[5,2,6]  R1670     -3.1228914856910706e-01
    z[5,2,6]  R1671     2.0340059418231249e-03
    z[5,2,6]  R1672     -2.5967034697532654e-01
    z[5,2,6]  R1673     -3.9736205339431763e-01
    z[5,2,6]  R1674     6.2632775306701660e-01
    z[5,2,6]  R1675     3.7222284078598022e-01
    z[5,2,6]  R1676     3.1119233369827271e-01
    z[5,2,6]  R1677     5.3603923320770264e-01
    z[5,2,6]  R1678     -7.4719607830047607e-01
    z[5,2,6]  R1679     1.0734346508979797e-01
    z[5,2,6]  R1680     1.2542261183261871e-01
    z[5,2,6]  R1681     -3.7674814462661743e-01
    z[5,2,6]  R1682     -2.4277888238430023e-01
    z[5,2,6]  R1683     -6.7902550101280212e-02
    z[5,2,6]  R1684     -9.5274388790130615e-02
    z[5,2,6]  R1685     1.9019149243831635e-01
    z[5,2,6]  R1686     -2.5185507535934448e-01
    z[5,2,6]  R1687     -1.6003604233264923e-01
    z[5,2,6]  R1688     9.8591828718781471e-03
    z[5,2,6]  R1689     -1.2602771818637848e-01
    z[5,2,6]  R1690     4.7085378319025040e-03
    z[5,2,6]  R1691     7.4312782287597656e-01
    z[5,2,6]  R1692     2.7942320704460144e-01
    z[5,2,6]  R1693     -8.2495003938674927e-01
    z[5,2,6]  R1694     7.7458268404006958e-01
    z[5,2,6]  R1695     3.4406915307044983e-01
    z[5,2,6]  R1696     2.1685181558132172e-01
    z[5,2,6]  R1697     -7.4513129889965057e-02
    z[5,2,6]  R1698     -5.2094870805740356e-01
    z[5,2,6]  R1699     -2.1409682929515839e-01
    z[5,2,6]  R1700     -1.2189421057701111e-01
    z[5,2,6]  R1701     9.9363557994365692e-02
    z[5,2,6]  R1702     -2.9586055874824524e-01
    z[5,2,6]  R1703     -4.3308973312377930e-02
    z[5,2,6]  R1704     -4.3077409267425537e-02
    z[5,2,6]  R1705     -3.2265511155128479e-01
    z[5,2,6]  R1706     4.9872463941574097e-01
    z[5,2,6]  R1707     1.3152271509170532e-01
    z[5,2,6]  R1708     3.0254775285720825e-01
    z[5,2,6]  R1709     -6.7440646886825562e-01
    z[5,2,6]  R1710     0.0453985333442688
    z[5,2,6]  R1711     4.5224779844284058e-01
    z[5,2,6]  R1712     5.3213948011398315e-01
    z[5,2,6]  R1713     2.1461309492588043e-01
    z[5,2,6]  R1714     -1.1411865800619125e-01
    z[5,2,6]  R1715     1.1244162172079086e-01
    z[5,2,6]  R1716     3.0335816740989685e-01
    z[5,2,6]  R1717     -0.417203426361084
    z[5,2,6]  R1718     -0.503563642501831
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1719     -1
    z[2,6,0]  R1720     1
    z[2,6,0]  R1733     -3.6661231517791748e-01
    z[2,6,0]  R1734     1.6546562314033508e-01
    z[2,6,0]  R1735     4.0289503335952759e-01
    z[2,6,0]  R1736     2.0910868048667908e-01
    z[2,6,0]  R1737     3.0914855003356934e-01
    z[2,6,0]  R1738     1.6202406585216522e-01
    z[2,6,0]  R1739     2.1579591929912567e-01
    z[2,6,0]  R1740     1.1821023374795914e-01
    z[2,6,0]  R1741     3.0235308408737183e-01
    z[2,6,0]  R1742     -1.9415308535099030e-01
    z[2,6,0]  R1743     -2.7080168947577477e-02
    z[2,6,0]  R1744     -5.7811617851257324e-01
    z[2,6,0]  R1745     -5.2692550420761108e-01
    z[2,6,0]  R1746     -5.3425353765487671e-01
    z[2,6,0]  R1747     -4.2574870586395264e-01
    z[2,6,0]  R1748     4.0422007441520691e-01
    z[2,6,0]  R1749     -5.1966708898544312e-01
    z[2,6,0]  R1750     6.1865937709808350e-01
    z[2,6,0]  R1751     3.4635260701179504e-01
    z[2,6,0]  R1752     7.3169477283954620e-02
    z[2,6,0]  R1753     3.3273005485534668e-01
    z[2,6,0]  R1754     4.5836099982261658e-01
    z[2,6,0]  R1755     2.7963202446699142e-02
    z[2,6,0]  R1756     -1.6530632972717285e-01
    z[2,6,0]  R1757     -1.1073750257492065e-01
    z[2,6,0]  R1758     -2.1354803442955017e-01
    z[2,6,0]  R1759     -0.153940349817276
    z[2,6,0]  R1760     -1.7421080172061920e-01
    z[2,6,0]  R1761     5.6375145912170410e-02
    z[2,6,0]  R1762     -5.9604984521865845e-01
    z[2,6,0]  R1763     -5.9519636631011963e-01
    z[2,6,0]  R1764     -5.4555088281631470e-01
    z[2,6,0]  R1765     -9.0853029489517212e-01
    z[2,6,0]  R1766     2.1695900708436966e-02
    z[2,6,0]  R1767     1.8270808458328247e-01
    z[2,6,0]  R1768     4.5938470959663391e-01
    z[2,6,0]  R1769     2.2123923897743225e-01
    z[2,6,0]  R1770     2.5043913722038269e-01
    z[2,6,0]  R1771     1.3056947290897369e-01
    z[2,6,0]  R1772     9.0998277068138123e-02
    z[2,6,0]  R1773     8.4450000524520874e-01
    z[2,6,0]  R1774     -2.1525566279888153e-01
    z[2,6,0]  R1775     8.5323905944824219e-01
    z[2,6,0]  R1776     7.9332852363586426e-01
    z[2,6,0]  R1777     9.4393032789230347e-01
    z[2,6,0]  R1778     7.9634547233581543e-01
    z[2,6,0]  R1779     4.2133647203445435e-01
    z[2,6,0]  R1780     5.4325199127197266e-01
    z[2,6,0]  R1781     0.753872811794281
    z[2,6,0]  R1782     -6.5286658704280853e-02
    z[2,6,0]  R1783     1.0219974815845490e-01
    z[2,6,0]  R1784     -1.2452743202447891e-01
    z[2,6,0]  R1785     2.6733890175819397e-01
    z[2,6,0]  R1786     -9.9125787615776062e-02
    z[2,6,0]  R1787     -2.6458343863487244e-01
    z[2,6,0]  R1788     0.359305739402771
    z[2,6,0]  R1789     4.0368229150772095e-01
    z[2,6,0]  R1790     3.5545936226844788e-01
    z[2,6,0]  R1791     5.5241298675537109e-01
    z[2,6,0]  R1792     2.7959239482879639e-01
    z[2,6,0]  R1793     -1.3251301646232605e-01
    z[2,6,0]  R1794     -4.3608862161636353e-01
    z[2,6,0]  R1795     6.5889185667037964e-01
    z[2,6,0]  R1796     4.6117383241653442e-01
    z[2,6,0]  R1797     4.0184545516967773e-01
    z[2,6,0]  R1798     6.4642888307571411e-01
    z[2,6,0]  R1799     6.0211783647537231e-01
    z[2,6,0]  R1800     6.4304113388061523e-01
    z[2,6,0]  R1801     6.8500363826751709e-01
    z[2,6,0]  R1802     -4.5201104879379272e-01
    z[2,6,0]  R1803     -3.3013510704040527e-01
    z[2,6,0]  R1804     7.2771143913269043e-01
    z[2,6,0]  R1805     7.1268713474273682e-01
    z[2,6,0]  R1806     5.4694259166717529e-01
    z[2,6,0]  R1807     8.4359234571456909e-01
    z[2,6,0]  R1808     4.8151209950447083e-01
    z[2,6,0]  R1809     6.5796029567718506e-01
    z[2,6,0]  R1810     2.9971030354499817e-01
    z[2,6,0]  R1811     6.5436176955699921e-02
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1721     -1
    z[2,6,1]  R1722     1
    z[2,6,1]  R1733     -1.3685827143490314e-02
    z[2,6,1]  R1734     4.5579671859741211e-01
    z[2,6,1]  R1735     5.3998893499374390e-01
    z[2,6,1]  R1736     3.4333053231239319e-01
    z[2,6,1]  R1737     2.7926534414291382e-01
    z[2,6,1]  R1738     1.0566697455942631e-02
    z[2,6,1]  R1739     1.1272235959768295e-01
    z[2,6,1]  R1740     4.8577859997749329e-02
    z[2,6,1]  R1741     -2.5733289122581482e-01
    z[2,6,1]  R1742     1.6795553267002106e-01
    z[2,6,1]  R1743     -3.2765606045722961e-01
    z[2,6,1]  R1744     -6.9910669326782227e-01
    z[2,6,1]  R1745     -7.0960718393325806e-01
    z[2,6,1]  R1746     -7.0828872919082642e-01
    z[2,6,1]  R1747     -7.4616920948028564e-01
    z[2,6,1]  R1748     8.2627201080322266e-01
    z[2,6,1]  R1749     -0.623083233833313
    z[2,6,1]  R1750     5.8256733417510986e-01
    z[2,6,1]  R1751     5.9217453002929688e-01
    z[2,6,1]  R1752     -4.8929625749588013e-01
    z[2,6,1]  R1753     -5.5335021018981934e-01
    z[2,6,1]  R1754     -4.6199139952659607e-01
    z[2,6,1]  R1755     0.621759831905365
    z[2,6,1]  R1756     5.0254029035568237e-01
    z[2,6,1]  R1757     4.4633430242538452e-01
    z[2,6,1]  R1758     5.6274503469467163e-01
    z[2,6,1]  R1759     -6.9187784194946289e-01
    z[2,6,1]  R1760     2.4417115747928619e-01
    z[2,6,1]  R1761     1.3327860832214355e-01
    z[2,6,1]  R1762     0.276196151971817
    z[2,6,1]  R1763     2.2301610559225082e-02
    z[2,6,1]  R1764     -3.1388025730848312e-02
    z[2,6,1]  R1765     1.5112218260765076e-01
    z[2,6,1]  R1766     9.1509366035461426e-01
    z[2,6,1]  R1767     0.881537914276123
    z[2,6,1]  R1768     1.0335970669984818e-01
    z[2,6,1]  R1769     8.0878442525863647e-01
    z[2,6,1]  R1770     7.6376211643218994e-01
    z[2,6,1]  R1771     7.0217174291610718e-01
    z[2,6,1]  R1772     -7.9451489448547363e-01
    z[2,6,1]  R1773     1.0510198026895523e-01
    z[2,6,1]  R1774     -5.9090346097946167e-01
    z[2,6,1]  R1775     -1.1415301263332367e-01
    z[2,6,1]  R1776     -3.4486210346221924e-01
    z[2,6,1]  R1777     -1.0071279853582382e-01
    z[2,6,1]  R1778     -1.9674836099147797e-01
    z[2,6,1]  R1779     -0.521199107170105
    z[2,6,1]  R1780     -5.0083076953887939e-01
    z[2,6,1]  R1781     4.4286736845970154e-01
    z[2,6,1]  R1782     -9.1140103340148926e-01
    z[2,6,1]  R1783     -8.2444530725479126e-01
    z[2,6,1]  R1784     -7.8273254632949829e-01
    z[2,6,1]  R1785     -7.1847504377365112e-01
    z[2,6,1]  R1786     -7.4615907669067383e-01
    z[2,6,1]  R1787     -6.5173190832138062e-01
    z[2,6,1]  R1788     2.8385114669799805e-01
    z[2,6,1]  R1789     5.0374716520309448e-01
    z[2,6,1]  R1790     -0.191203311085701
    z[2,6,1]  R1791     -5.3746816702187061e-03
    z[2,6,1]  R1792     -9.3310713768005371e-01
    z[2,6,1]  R1793     -5.7585853338241577e-01
    z[2,6,1]  R1794     -6.1612749099731445e-01
    z[2,6,1]  R1795     -2.1015946567058563e-01
    z[2,6,1]  R1796     3.3841848373413086e-02
    z[2,6,1]  R1797     -4.7460398077964783e-01
    z[2,6,1]  R1798     4.4044005870819092e-01
    z[2,6,1]  R1799     8.6261585354804993e-02
    z[2,6,1]  R1800     4.5362392067909241e-01
    z[2,6,1]  R1801     4.5255038142204285e-01
    z[2,6,1]  R1802     -0.754883885383606
    z[2,6,1]  R1803     -7.4834233522415161e-01
    z[2,6,1]  R1804     -1.6699890792369843e-01
    z[2,6,1]  R1805     -0.0396428182721138
    z[2,6,1]  R1806     -1.9857594370841980e-01
    z[2,6,1]  R1807     2.6120641827583313e-01
    z[2,6,1]  R1808     1.9385293126106262e-01
    z[2,6,1]  R1809     1.2686505913734436e-01
    z[2,6,1]  R1810     2.9744756221771240e-01
    z[2,6,1]  R1811     8.9126682281494141e-01
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1723     -1
    z[2,6,2]  R1724     1
    z[2,6,2]  R1733     2.1258221566677094e-01
    z[2,6,2]  R1734     4.1581603884696960e-01
    z[2,6,2]  R1735     3.2558149099349976e-01
    z[2,6,2]  R1736     -2.8964450955390930e-01
    z[2,6,2]  R1737     -3.0477553606033325e-01
    z[2,6,2]  R1738     2.3961445689201355e-01
    z[2,6,2]  R1739     7.6453518867492676e-01
    z[2,6,2]  R1740     8.1429845094680786e-01
    z[2,6,2]  R1741     3.0611777305603027e-01
    z[2,6,2]  R1742     5.0546836853027344e-01
    z[2,6,2]  R1743     5.2546513080596924e-01
    z[2,6,2]  R1744     -2.5471404194831848e-01
    z[2,6,2]  R1745     -1.9017027318477631e-01
    z[2,6,2]  R1746     -2.2027122974395752e-01
    z[2,6,2]  R1747     9.2856585979461670e-02
    z[2,6,2]  R1748     -1.5305048227310181e-01
    z[2,6,2]  R1749     1.3614802621304989e-02
    z[2,6,2]  R1750     -1.2995676696300507e-01
    z[2,6,2]  R1751     3.7700325250625610e-01
    z[2,6,2]  R1752     -3.8925856351852417e-01
    z[2,6,2]  R1753     -3.1161662936210632e-01
    z[2,6,2]  R1754     -0.522205114364624
    z[2,6,2]  R1755     -4.6922508627176285e-02
    z[2,6,2]  R1756     -1.6904366016387939e-01
    z[2,6,2]  R1757     -1.2624402344226837e-01
    z[2,6,2]  R1758     1.2969402968883514e-01
    z[2,6,2]  R1759     -5.3946632146835327e-01
    z[2,6,2]  R1760     -1.3117274641990662e-01
    z[2,6,2]  R1761     -9.6711240708827972e-02
    z[2,6,2]  R1762     4.8773157596588135e-01
    z[2,6,2]  R1763     2.2447645664215088e-01
    z[2,6,2]  R1764     3.4056842327117920e-01
    z[2,6,2]  R1765     1.0006441920995712e-01
    z[2,6,2]  R1766     -7.9439111053943634e-02
    z[2,6,2]  R1767     -1.9052430987358093e-01
    z[2,6,2]  R1768     -5.7515446096658707e-03
    z[2,6,2]  R1769     -2.2354939579963684e-01
    z[2,6,2]  R1770     -5.0686992704868317e-02
    z[2,6,2]  R1771     -1.6932713985443115e-01
    z[2,6,2]  R1772     1.2727114558219910e-01
    z[2,6,2]  R1773     -2.3148582875728607e-01
    z[2,6,2]  R1774     -1.2812073528766632e-01
    z[2,6,2]  R1775     -1.6133835911750793e-01
    z[2,6,2]  R1776     -2.3383864760398865e-01
    z[2,6,2]  R1777     -0.0661177933216095
    z[2,6,2]  R1778     -1.2817256152629852e-01
    z[2,6,2]  R1779     1.7731526866555214e-02
    z[2,6,2]  R1780     -3.9519403129816055e-02
    z[2,6,2]  R1781     -1.8911775946617126e-01
    z[2,6,2]  R1782     -1.1916232854127884e-01
    z[2,6,2]  R1783     -7.4620373547077179e-02
    z[2,6,2]  R1784     -2.6734763383865356e-01
    z[2,6,2]  R1785     2.3613844811916351e-01
    z[2,6,2]  R1786     -0.0619661882519722
    z[2,6,2]  R1787     3.3399939537048340e-01
    z[2,6,2]  R1788     -5.9533727169036865e-01
    z[2,6,2]  R1789     -3.9430230855941772e-01
    z[2,6,2]  R1790     -5.0604969263076782e-01
    z[2,6,2]  R1791     -5.1947891712188721e-01
    z[2,6,2]  R1792     -1.0304950177669525e-02
    z[2,6,2]  R1793     3.6137357354164124e-01
    z[2,6,2]  R1794     1.4033210277557373e-01
    z[2,6,2]  R1795     -0.586410403251648
    z[2,6,2]  R1796     -4.8165100812911987e-01
    z[2,6,2]  R1797     1.6418717801570892e-01
    z[2,6,2]  R1798     -2.5007659196853638e-01
    z[2,6,2]  R1799     -3.9739865064620972e-01
    z[2,6,2]  R1800     -2.8848305344581604e-01
    z[2,6,2]  R1801     -4.4339919090270996e-01
    z[2,6,2]  R1802     9.7652688622474670e-02
    z[2,6,2]  R1803     1.1433774232864380e-01
    z[2,6,2]  R1804     -5.6149488687515259e-01
    z[2,6,2]  R1805     -4.7930890321731567e-01
    z[2,6,2]  R1806     -5.8779168128967285e-01
    z[2,6,2]  R1807     -1.1778302490711212e-01
    z[2,6,2]  R1808     -6.5734660625457764e-01
    z[2,6,2]  R1809     -4.9735471606254578e-01
    z[2,6,2]  R1810     -4.3005892634391785e-01
    z[2,6,2]  R1811     -1.5715565532445908e-02
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1725     -1
    z[2,6,3]  R1726     1
    z[2,6,3]  R1733     7.8052252531051636e-01
    z[2,6,3]  R1734     3.9015822112560272e-02
    z[2,6,3]  R1735     2.3934055864810944e-01
    z[2,6,3]  R1736     2.1962981671094894e-02
    z[2,6,3]  R1737     2.4569568037986755e-01
    z[2,6,3]  R1738     9.2812865972518921e-02
    z[2,6,3]  R1739     1.1253246106207371e-02
    z[2,6,3]  R1740     8.0901905894279480e-03
    z[2,6,3]  R1741     2.7741071581840515e-01
    z[2,6,3]  R1742     -1.1258782446384430e-01
    z[2,6,3]  R1743     1.5779989957809448e-01
    z[2,6,3]  R1744     -3.0732131004333496e-01
    z[2,6,3]  R1745     -2.5070270895957947e-01
    z[2,6,3]  R1746     -1.9933721423149109e-01
    z[2,6,3]  R1747     -2.9560244083404541e-01
    z[2,6,3]  R1748     1.8660595640540123e-02
    z[2,6,3]  R1749     -2.8148058056831360e-01
    z[2,6,3]  R1750     -5.0522230565547943e-02
    z[2,6,3]  R1751     -1.4186839759349823e-01
    z[2,6,3]  R1752     -8.7280482053756714e-02
    z[2,6,3]  R1753     1.5519383549690247e-01
    z[2,6,3]  R1754     2.8961020708084106e-01
    z[2,6,3]  R1755     -2.5664865970611572e-01
    z[2,6,3]  R1756     -4.9873286485671997e-01
    z[2,6,3]  R1757     -3.5075816512107849e-01
    z[2,6,3]  R1758     -5.5897700786590576e-01
    z[2,6,3]  R1759     -2.3413909971714020e-01
    z[2,6,3]  R1760     -3.6581665277481079e-01
    z[2,6,3]  R1761     -6.2053781747817993e-01
    z[2,6,3]  R1762     5.0965875387191772e-01
    z[2,6,3]  R1763     0.659257173538208
    z[2,6,3]  R1764     6.5231317281723022e-01
    z[2,6,3]  R1765     -2.9387019574642181e-02
    z[2,6,3]  R1766     -2.8190738521516323e-03
    z[2,6,3]  R1767     1.2896408140659332e-01
    z[2,6,3]  R1768     6.5814755856990814e-02
    z[2,6,3]  R1769     -1.6845270991325378e-02
    z[2,6,3]  R1770     -3.1805783510208130e-04
    z[2,6,3]  R1771     8.1102559342980385e-03
    z[2,6,3]  R1772     0.050968237221241
    z[2,6,3]  R1773     3.3115687966346741e-01
    z[2,6,3]  R1774     -3.3807581663131714e-01
    z[2,6,3]  R1775     0.274882048368454
    z[2,6,3]  R1776     2.7509680390357971e-01
    z[2,6,3]  R1777     2.9080143570899963e-01
    z[2,6,3]  R1778     4.2971488833427429e-01
    z[2,6,3]  R1779     -8.4945894777774811e-02
    z[2,6,3]  R1780     -0.509889543056488
    z[2,6,3]  R1781     -6.8869769573211670e-02
    z[2,6,3]  R1782     0.0910181850194931
    z[2,6,3]  R1783     1.2829015031456947e-02
    z[2,6,3]  R1784     -4.0507459640502930e-01
    z[2,6,3]  R1785     3.9797410368919373e-01
    z[2,6,3]  R1786     -4.0944054722785950e-01
    z[2,6,3]  R1787     -8.2941770553588867e-02
    z[2,6,3]  R1788     6.4459836483001709e-01
    z[2,6,3]  R1789     5.4118847846984863e-01
    z[2,6,3]  R1790     5.7443559169769287e-01
    z[2,6,3]  R1791     -3.1225383281707764e-02
    z[2,6,3]  R1792     6.6303342580795288e-02
    z[2,6,3]  R1793     -9.6390329301357269e-02
    z[2,6,3]  R1794     -0.134671151638031
    z[2,6,3]  R1795     2.1323148906230927e-01
    z[2,6,3]  R1796     7.3015308380126953e-01
    z[2,6,3]  R1797     -3.5643491148948669e-01
    z[2,6,3]  R1798     4.0695074200630188e-01
    z[2,6,3]  R1799     1.6109007596969604e-01
    z[2,6,3]  R1800     1.8732589483261108e-01
    z[2,6,3]  R1801     -1.0029952228069305e-01
    z[2,6,3]  R1802     -1.8509706482291222e-02
    z[2,6,3]  R1803     -3.7871259450912476e-01
    z[2,6,3]  R1804     2.9333943128585815e-01
    z[2,6,3]  R1805     4.7650942206382751e-01
    z[2,6,3]  R1806     -2.3655596375465393e-01
    z[2,6,3]  R1807     -2.9557985067367554e-01
    z[2,6,3]  R1808     -2.2809679806232452e-01
    z[2,6,3]  R1809     -5.1991522312164307e-01
    z[2,6,3]  R1810     1.1041344143450260e-02
    z[2,6,3]  R1811     -3.0342775583267212e-01
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1727     -1
    z[2,6,4]  R1728     1
    z[2,6,4]  R1733     -2.5614660978317261e-01
    z[2,6,4]  R1734     -0.000798138091340661
    z[2,6,4]  R1735     5.5186992883682251e-01
    z[2,6,4]  R1736     -1.3819648325443268e-01
    z[2,6,4]  R1737     -1.6549403965473175e-01
    z[2,6,4]  R1738     8.1146311759948730e-01
    z[2,6,4]  R1739     2.5595462322235107e-01
    z[2,6,4]  R1740     4.7331121563911438e-01
    z[2,6,4]  R1741     2.3274032771587372e-01
    z[2,6,4]  R1742     -4.3243950605392456e-01
    z[2,6,4]  R1743     -2.6868479326367378e-02
    z[2,6,4]  R1744     -8.4718890488147736e-02
    z[2,6,4]  R1745     1.7959372699260712e-01
    z[2,6,4]  R1746     3.3769440650939941e-01
    z[2,6,4]  R1747     3.5924088954925537e-01
    z[2,6,4]  R1748     -1.5597642958164215e-01
    z[2,6,4]  R1749     9.0175405144691467e-02
    z[2,6,4]  R1750     4.9020549654960632e-01
    z[2,6,4]  R1751     5.0157213211059570e-01
    z[2,6,4]  R1752     -3.6766156554222107e-01
    z[2,6,4]  R1753     6.4462912082672119e-01
    z[2,6,4]  R1754     5.4894257336854935e-02
    z[2,6,4]  R1755     1.9418130815029144e-01
    z[2,6,4]  R1756     2.1522257477045059e-02
    z[2,6,4]  R1757     1.9847208261489868e-01
    z[2,6,4]  R1758     1.3483066856861115e-01
    z[2,6,4]  R1759     -2.4369807541370392e-01
    z[2,6,4]  R1760     7.6184707880020142e-01
    z[2,6,4]  R1761     5.7341301441192627e-01
    z[2,6,4]  R1762     5.1909282803535461e-02
    z[2,6,4]  R1763     -2.5398629903793335e-01
    z[2,6,4]  R1764     -2.3089951276779175e-01
    z[2,6,4]  R1765     -3.5876947641372681e-01
    z[2,6,4]  R1766     -0.0959881991147995
    z[2,6,4]  R1767     -2.8585413098335266e-01
    z[2,6,4]  R1768     -4.2576059699058533e-01
    z[2,6,4]  R1769     1.4788508415222168e-01
    z[2,6,4]  R1770     3.0391144752502441e-01
    z[2,6,4]  R1771     -4.3358907103538513e-01
    z[2,6,4]  R1772     -2.6395526528358459e-01
    z[2,6,4]  R1773     2.3674128949642181e-01
    z[2,6,4]  R1774     2.9911085963249207e-02
    z[2,6,4]  R1775     1.9667085260152817e-02
    z[2,6,4]  R1776     1.6249762475490570e-01
    z[2,6,4]  R1777     -6.1553075909614563e-02
    z[2,6,4]  R1778     1.5981048345565796e-01
    z[2,6,4]  R1779     -1.3030655682086945e-01
    z[2,6,4]  R1780     3.1087738275527954e-01
    z[2,6,4]  R1781     4.1969907283782959e-01
    z[2,6,4]  R1782     -1.7897665500640869e-01
    z[2,6,4]  R1783     3.9696547389030457e-01
    z[2,6,4]  R1784     7.8738816082477570e-02
    z[2,6,4]  R1785     2.1400362253189087e-01
    z[2,6,4]  R1786     4.6166211366653442e-01
    z[2,6,4]  R1787     5.9847152233123779e-01
    z[2,6,4]  R1788     4.0785338729619980e-02
    z[2,6,4]  R1789     -3.1205436587333679e-01
    z[2,6,4]  R1790     -4.5826199650764465e-01
    z[2,6,4]  R1791     -1.8192663788795471e-01
    z[2,6,4]  R1792     -9.5630668103694916e-02
    z[2,6,4]  R1793     2.0256495103240013e-02
    z[2,6,4]  R1794     2.1458901464939117e-01
    z[2,6,4]  R1795     -1.4460344612598419e-01
    z[2,6,4]  R1796     1.3604256510734558e-01
    z[2,6,4]  R1797     3.8054218888282776e-01
    z[2,6,4]  R1798     -2.4202033877372742e-01
    z[2,6,4]  R1799     5.1111710071563721e-01
    z[2,6,4]  R1800     -1.0704553872346878e-01
    z[2,6,4]  R1801     -2.0238064229488373e-01
    z[2,6,4]  R1802     1.1939971148967743e-01
    z[2,6,4]  R1803     2.5957143306732178e-01
    z[2,6,4]  R1804     7.4490890838205814e-03
    z[2,6,4]  R1805     -4.4754702597856522e-02
    z[2,6,4]  R1806     -1.8876731395721436e-01
    z[2,6,4]  R1807     1.6481505706906319e-02
    z[2,6,4]  R1808     3.5699892044067383e-01
    z[2,6,4]  R1809     4.9457452259957790e-03
    z[2,6,4]  R1810     2.1581137180328369e-01
    z[2,6,4]  R1811     2.5845596194267273e-01
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1729     -1
    z[2,6,5]  R1730     1
    z[2,6,5]  R1733     -3.8127186894416809e-01
    z[2,6,5]  R1734     1.9546292722225189e-01
    z[2,6,5]  R1735     1.2754661962389946e-02
    z[2,6,5]  R1736     -2.3319636285305023e-01
    z[2,6,5]  R1737     2.1404910087585449e-01
    z[2,6,5]  R1738     -3.6159527301788330e-01
    z[2,6,5]  R1739     4.9350535869598389e-01
    z[2,6,5]  R1740     3.0156826972961426e-01
    z[2,6,5]  R1741     0.588338315486908
    z[2,6,5]  R1742     6.5808808803558350e-01
    z[2,6,5]  R1743     7.5849437713623047e-01
    z[2,6,5]  R1744     2.5602813810110092e-02
    z[2,6,5]  R1745     -1.7964061116799712e-03
    z[2,6,5]  R1746     9.3446910381317139e-02
    z[2,6,5]  R1747     -1.8723461031913757e-01
    z[2,6,5]  R1748     4.0902689099311829e-02
    z[2,6,5]  R1749     7.3748230934143066e-02
    z[2,6,5]  R1750     -2.8898175805807114e-02
    z[2,6,5]  R1751     1.5492363274097443e-01
    z[2,6,5]  R1752     -7.8078046441078186e-02
    z[2,6,5]  R1753     -2.1046692132949829e-01
    z[2,6,5]  R1754     -1.1115522682666779e-01
    z[2,6,5]  R1755     -4.7295203804969788e-01
    z[2,6,5]  R1756     -0.629519522190094
    z[2,6,5]  R1757     -7.7274823188781738e-01
    z[2,6,5]  R1758     -5.2689379453659058e-01
    z[2,6,5]  R1759     1.8636273220181465e-02
    z[2,6,5]  R1760     6.7329309880733490e-02
    z[2,6,5]  R1761     4.7534830868244171e-02
    z[2,6,5]  R1762     -2.5539833307266235e-01
    z[2,6,5]  R1763     7.1471042931079865e-02
    z[2,6,5]  R1764     1.1612446606159210e-01
    z[2,6,5]  R1765     -3.0692974105477333e-02
    z[2,6,5]  R1766     1.7688576877117157e-01
    z[2,6,5]  R1767     1.9736237823963165e-01
    z[2,6,5]  R1768     -7.6937347650527954e-01
    z[2,6,5]  R1769     1.4822122454643250e-01
    z[2,6,5]  R1770     -9.1586671769618988e-02
    z[2,6,5]  R1771     -2.5746437907218933e-01
    z[2,6,5]  R1772     -1.1757009476423264e-01
    z[2,6,5]  R1773     -2.1723946928977966e-01
    z[2,6,5]  R1774     -1.8353374302387238e-01
    z[2,6,5]  R1775     -3.0065011978149414e-01
    z[2,6,5]  R1776     -1.0003068484365940e-02
    z[2,6,5]  R1777     -7.0270299911499023e-02
    z[2,6,5]  R1778     2.5976386666297913e-01
    z[2,6,5]  R1779     -5.3589552640914917e-01
    z[2,6,5]  R1780     -2.5983822345733643e-01
    z[2,6,5]  R1781     -4.0476869791746140e-02
    z[2,6,5]  R1782     1.4154934883117676e-01
    z[2,6,5]  R1783     3.5965159535408020e-01
    z[2,6,5]  R1784     3.5309413075447083e-01
    z[2,6,5]  R1785     -1.8601374328136444e-01
    z[2,6,5]  R1786     -2.1937897801399231e-01
    z[2,6,5]  R1787     -1.6718253493309021e-01
    z[2,6,5]  R1788     -4.2517997324466705e-02
    z[2,6,5]  R1789     2.8758922591805458e-02
    z[2,6,5]  R1790     -2.0251670479774475e-01
    z[2,6,5]  R1791     6.2297517061233521e-01
    z[2,6,5]  R1792     4.8483829945325851e-02
    z[2,6,5]  R1793     -7.0186775922775269e-01
    z[2,6,5]  R1794     -3.9356565475463867e-01
    z[2,6,5]  R1795     2.5392500683665276e-02
    z[2,6,5]  R1796     -4.2466189712285995e-02
    z[2,6,5]  R1797     -5.4508411884307861e-01
    z[2,6,5]  R1798     1.8560223979875445e-03
    z[2,6,5]  R1799     3.8124760985374451e-01
    z[2,6,5]  R1800     4.3632471561431885e-01
    z[2,6,5]  R1801     2.3405356705188751e-01
    z[2,6,5]  R1802     -4.4823956489562988e-01
    z[2,6,5]  R1803     -2.5935393571853638e-01
    z[2,6,5]  R1804     1.9823490083217621e-01
    z[2,6,5]  R1805     -1.3387256860733032e-01
    z[2,6,5]  R1806     -6.7064121365547180e-02
    z[2,6,5]  R1807     -3.2198619842529297e-01
    z[2,6,5]  R1808     -3.4350180625915527e-01
    z[2,6,5]  R1809     -1.5017965435981750e-01
    z[2,6,5]  R1810     2.5003787875175476e-01
    z[2,6,5]  R1811     -5.9697788208723068e-02
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1731     -1
    z[2,6,6]  R1732     1
    z[2,6,6]  R1733     4.7085378319025040e-03
    z[2,6,6]  R1734     7.4312782287597656e-01
    z[2,6,6]  R1735     2.7942320704460144e-01
    z[2,6,6]  R1736     -8.2495003938674927e-01
    z[2,6,6]  R1737     7.7458268404006958e-01
    z[2,6,6]  R1738     3.4406915307044983e-01
    z[2,6,6]  R1739     2.1685181558132172e-01
    z[2,6,6]  R1740     -7.4513129889965057e-02
    z[2,6,6]  R1741     -5.2094870805740356e-01
    z[2,6,6]  R1742     -2.1409682929515839e-01
    z[2,6,6]  R1743     -1.2189421057701111e-01
    z[2,6,6]  R1744     9.9363557994365692e-02
    z[2,6,6]  R1745     -2.9586055874824524e-01
    z[2,6,6]  R1746     -4.3308973312377930e-02
    z[2,6,6]  R1747     -4.3077409267425537e-02
    z[2,6,6]  R1748     -3.2265511155128479e-01
    z[2,6,6]  R1749     4.9872463941574097e-01
    z[2,6,6]  R1750     1.3152271509170532e-01
    z[2,6,6]  R1751     3.0254775285720825e-01
    z[2,6,6]  R1752     -6.7440646886825562e-01
    z[2,6,6]  R1753     0.0453985333442688
    z[2,6,6]  R1754     4.5224779844284058e-01
    z[2,6,6]  R1755     5.3213948011398315e-01
    z[2,6,6]  R1756     2.1461309492588043e-01
    z[2,6,6]  R1757     -1.1411865800619125e-01
    z[2,6,6]  R1758     1.1244162172079086e-01
    z[2,6,6]  R1759     3.0335816740989685e-01
    z[2,6,6]  R1760     -0.417203426361084
    z[2,6,6]  R1761     -0.503563642501831
    z[2,6,6]  R1762     5.3695771843194962e-02
    z[2,6,6]  R1763     3.0102658271789551e-01
    z[2,6,6]  R1764     -3.0510690808296204e-01
    z[2,6,6]  R1765     -1.0583250969648361e-01
    z[2,6,6]  R1766     3.3957654237747192e-01
    z[2,6,6]  R1767     -1.2614670395851135e-01
    z[2,6,6]  R1768     2.6650611311197281e-02
    z[2,6,6]  R1769     4.5035898685455322e-01
    z[2,6,6]  R1770     0.500627875328064
    z[2,6,6]  R1771     4.5484250783920288e-01
    z[2,6,6]  R1772     -5.0810897350311279e-01
    z[2,6,6]  R1773     9.6349850296974182e-02
    z[2,6,6]  R1774     6.6272813081741333e-01
    z[2,6,6]  R1775     -2.5804024934768677e-01
    z[2,6,6]  R1776     -3.0795404314994812e-01
    z[2,6,6]  R1777     3.4476846456527710e-02
    z[2,6,6]  R1778     1.8172548711299896e-01
    z[2,6,6]  R1779     4.8901230096817017e-01
    z[2,6,6]  R1780     -1.6833323240280151e-01
    z[2,6,6]  R1781     -1.3133953511714935e-01
    z[2,6,6]  R1782     3.0088698863983154e-01
    z[2,6,6]  R1783     1.3107791543006897e-01
    z[2,6,6]  R1784     -7.3397949337959290e-02
    z[2,6,6]  R1785     3.4319078922271729e-01
    z[2,6,6]  R1786     2.6081087067723274e-02
    z[2,6,6]  R1787     2.6228204369544983e-02
    z[2,6,6]  R1788     1.3008902966976166e-01
    z[2,6,6]  R1789     1.9161215424537659e-01
    z[2,6,6]  R1790     3.1981957145035267e-03
    z[2,6,6]  R1791     -5.2745349705219269e-02
    z[2,6,6]  R1792     -1.8745927512645721e-01
    z[2,6,6]  R1793     1.3385285437107086e-01
    z[2,6,6]  R1794     4.3754053115844727e-01
    z[2,6,6]  R1795     -3.3285838365554810e-01
    z[2,6,6]  R1796     -2.7408143505454063e-02
    z[2,6,6]  R1797     1.3167731463909149e-01
    z[2,6,6]  R1798     -3.1846159696578979e-01
    z[2,6,6]  R1799     -1.9886401295661926e-01
    z[2,6,6]  R1800     -2.4611370265483856e-01
    z[2,6,6]  R1801     1.5351347625255585e-01
    z[2,6,6]  R1802     2.7978392317891121e-02
    z[2,6,6]  R1803     1.9964060187339783e-01
    z[2,6,6]  R1804     -4.3247118592262268e-02
    z[2,6,6]  R1805     -1.1739847064018250e-01
    z[2,6,6]  R1806     4.6886342763900757e-01
    z[2,6,6]  R1807     -1.2221318483352661e-01
    z[2,6,6]  R1808     3.1506296247243881e-02
    z[2,6,6]  R1809     1.0364209115505219e-01
    z[2,6,6]  R1810     7.2631442546844482e-01
    z[2,6,6]  R1811     -1.9667962193489075e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1812     -1
    z[6,2,0]  R1813     1
    z[6,2,0]  R1826     -5.9604984521865845e-01
    z[6,2,0]  R1827     -5.9519636631011963e-01
    z[6,2,0]  R1828     -5.4555088281631470e-01
    z[6,2,0]  R1829     -9.0853029489517212e-01
    z[6,2,0]  R1830     2.1695900708436966e-02
    z[6,2,0]  R1831     1.8270808458328247e-01
    z[6,2,0]  R1832     4.5938470959663391e-01
    z[6,2,0]  R1833     2.2123923897743225e-01
    z[6,2,0]  R1834     2.5043913722038269e-01
    z[6,2,0]  R1835     1.3056947290897369e-01
    z[6,2,0]  R1836     9.0998277068138123e-02
    z[6,2,0]  R1837     8.4450000524520874e-01
    z[6,2,0]  R1838     -2.1525566279888153e-01
    z[6,2,0]  R1839     8.5323905944824219e-01
    z[6,2,0]  R1840     7.9332852363586426e-01
    z[6,2,0]  R1841     9.4393032789230347e-01
    z[6,2,0]  R1842     7.9634547233581543e-01
    z[6,2,0]  R1843     4.2133647203445435e-01
    z[6,2,0]  R1844     5.4325199127197266e-01
    z[6,2,0]  R1845     0.753872811794281
    z[6,2,0]  R1846     -6.5286658704280853e-02
    z[6,2,0]  R1847     1.0219974815845490e-01
    z[6,2,0]  R1848     -1.2452743202447891e-01
    z[6,2,0]  R1849     2.6733890175819397e-01
    z[6,2,0]  R1850     -9.9125787615776062e-02
    z[6,2,0]  R1851     -2.6458343863487244e-01
    z[6,2,0]  R1852     0.359305739402771
    z[6,2,0]  R1853     4.0368229150772095e-01
    z[6,2,0]  R1854     3.5545936226844788e-01
    z[6,2,0]  R1855     5.5241298675537109e-01
    z[6,2,0]  R1856     2.7959239482879639e-01
    z[6,2,0]  R1857     -1.3251301646232605e-01
    z[6,2,0]  R1858     -4.3608862161636353e-01
    z[6,2,0]  R1859     6.5889185667037964e-01
    z[6,2,0]  R1860     4.6117383241653442e-01
    z[6,2,0]  R1861     4.0184545516967773e-01
    z[6,2,0]  R1862     6.4642888307571411e-01
    z[6,2,0]  R1863     6.0211783647537231e-01
    z[6,2,0]  R1864     6.4304113388061523e-01
    z[6,2,0]  R1865     6.8500363826751709e-01
    z[6,2,0]  R1866     -4.5201104879379272e-01
    z[6,2,0]  R1867     -3.3013510704040527e-01
    z[6,2,0]  R1868     7.2771143913269043e-01
    z[6,2,0]  R1869     7.1268713474273682e-01
    z[6,2,0]  R1870     5.4694259166717529e-01
    z[6,2,0]  R1871     8.4359234571456909e-01
    z[6,2,0]  R1872     4.8151209950447083e-01
    z[6,2,0]  R1873     6.5796029567718506e-01
    z[6,2,0]  R1874     2.9971030354499817e-01
    z[6,2,0]  R1875     6.5436176955699921e-02
    z[6,2,0]  R1876     -3.6661231517791748e-01
    z[6,2,0]  R1877     1.6546562314033508e-01
    z[6,2,0]  R1878     4.0289503335952759e-01
    z[6,2,0]  R1879     2.0910868048667908e-01
    z[6,2,0]  R1880     3.0914855003356934e-01
    z[6,2,0]  R1881     1.6202406585216522e-01
    z[6,2,0]  R1882     2.1579591929912567e-01
    z[6,2,0]  R1883     1.1821023374795914e-01
    z[6,2,0]  R1884     3.0235308408737183e-01
    z[6,2,0]  R1885     -1.9415308535099030e-01
    z[6,2,0]  R1886     -2.7080168947577477e-02
    z[6,2,0]  R1887     -5.7811617851257324e-01
    z[6,2,0]  R1888     -5.2692550420761108e-01
    z[6,2,0]  R1889     -5.3425353765487671e-01
    z[6,2,0]  R1890     -4.2574870586395264e-01
    z[6,2,0]  R1891     4.0422007441520691e-01
    z[6,2,0]  R1892     -5.1966708898544312e-01
    z[6,2,0]  R1893     6.1865937709808350e-01
    z[6,2,0]  R1894     3.4635260701179504e-01
    z[6,2,0]  R1895     7.3169477283954620e-02
    z[6,2,0]  R1896     3.3273005485534668e-01
    z[6,2,0]  R1897     4.5836099982261658e-01
    z[6,2,0]  R1898     2.7963202446699142e-02
    z[6,2,0]  R1899     -1.6530632972717285e-01
    z[6,2,0]  R1900     -1.1073750257492065e-01
    z[6,2,0]  R1901     -2.1354803442955017e-01
    z[6,2,0]  R1902     -0.153940349817276
    z[6,2,0]  R1903     -1.7421080172061920e-01
    z[6,2,0]  R1904     5.6375145912170410e-02
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1814     -1
    z[6,2,1]  R1815     1
    z[6,2,1]  R1826     0.276196151971817
    z[6,2,1]  R1827     2.2301610559225082e-02
    z[6,2,1]  R1828     -3.1388025730848312e-02
    z[6,2,1]  R1829     1.5112218260765076e-01
    z[6,2,1]  R1830     9.1509366035461426e-01
    z[6,2,1]  R1831     0.881537914276123
    z[6,2,1]  R1832     1.0335970669984818e-01
    z[6,2,1]  R1833     8.0878442525863647e-01
    z[6,2,1]  R1834     7.6376211643218994e-01
    z[6,2,1]  R1835     7.0217174291610718e-01
    z[6,2,1]  R1836     -7.9451489448547363e-01
    z[6,2,1]  R1837     1.0510198026895523e-01
    z[6,2,1]  R1838     -5.9090346097946167e-01
    z[6,2,1]  R1839     -1.1415301263332367e-01
    z[6,2,1]  R1840     -3.4486210346221924e-01
    z[6,2,1]  R1841     -1.0071279853582382e-01
    z[6,2,1]  R1842     -1.9674836099147797e-01
    z[6,2,1]  R1843     -0.521199107170105
    z[6,2,1]  R1844     -5.0083076953887939e-01
    z[6,2,1]  R1845     4.4286736845970154e-01
    z[6,2,1]  R1846     -9.1140103340148926e-01
    z[6,2,1]  R1847     -8.2444530725479126e-01
    z[6,2,1]  R1848     -7.8273254632949829e-01
    z[6,2,1]  R1849     -7.1847504377365112e-01
    z[6,2,1]  R1850     -7.4615907669067383e-01
    z[6,2,1]  R1851     -6.5173190832138062e-01
    z[6,2,1]  R1852     2.8385114669799805e-01
    z[6,2,1]  R1853     5.0374716520309448e-01
    z[6,2,1]  R1854     -0.191203311085701
    z[6,2,1]  R1855     -5.3746816702187061e-03
    z[6,2,1]  R1856     -9.3310713768005371e-01
    z[6,2,1]  R1857     -5.7585853338241577e-01
    z[6,2,1]  R1858     -6.1612749099731445e-01
    z[6,2,1]  R1859     -2.1015946567058563e-01
    z[6,2,1]  R1860     3.3841848373413086e-02
    z[6,2,1]  R1861     -4.7460398077964783e-01
    z[6,2,1]  R1862     4.4044005870819092e-01
    z[6,2,1]  R1863     8.6261585354804993e-02
    z[6,2,1]  R1864     4.5362392067909241e-01
    z[6,2,1]  R1865     4.5255038142204285e-01
    z[6,2,1]  R1866     -0.754883885383606
    z[6,2,1]  R1867     -7.4834233522415161e-01
    z[6,2,1]  R1868     -1.6699890792369843e-01
    z[6,2,1]  R1869     -0.0396428182721138
    z[6,2,1]  R1870     -1.9857594370841980e-01
    z[6,2,1]  R1871     2.6120641827583313e-01
    z[6,2,1]  R1872     1.9385293126106262e-01
    z[6,2,1]  R1873     1.2686505913734436e-01
    z[6,2,1]  R1874     2.9744756221771240e-01
    z[6,2,1]  R1875     8.9126682281494141e-01
    z[6,2,1]  R1876     -1.3685827143490314e-02
    z[6,2,1]  R1877     4.5579671859741211e-01
    z[6,2,1]  R1878     5.3998893499374390e-01
    z[6,2,1]  R1879     3.4333053231239319e-01
    z[6,2,1]  R1880     2.7926534414291382e-01
    z[6,2,1]  R1881     1.0566697455942631e-02
    z[6,2,1]  R1882     1.1272235959768295e-01
    z[6,2,1]  R1883     4.8577859997749329e-02
    z[6,2,1]  R1884     -2.5733289122581482e-01
    z[6,2,1]  R1885     1.6795553267002106e-01
    z[6,2,1]  R1886     -3.2765606045722961e-01
    z[6,2,1]  R1887     -6.9910669326782227e-01
    z[6,2,1]  R1888     -7.0960718393325806e-01
    z[6,2,1]  R1889     -7.0828872919082642e-01
    z[6,2,1]  R1890     -7.4616920948028564e-01
    z[6,2,1]  R1891     8.2627201080322266e-01
    z[6,2,1]  R1892     -0.623083233833313
    z[6,2,1]  R1893     5.8256733417510986e-01
    z[6,2,1]  R1894     5.9217453002929688e-01
    z[6,2,1]  R1895     -4.8929625749588013e-01
    z[6,2,1]  R1896     -5.5335021018981934e-01
    z[6,2,1]  R1897     -4.6199139952659607e-01
    z[6,2,1]  R1898     0.621759831905365
    z[6,2,1]  R1899     5.0254029035568237e-01
    z[6,2,1]  R1900     4.4633430242538452e-01
    z[6,2,1]  R1901     5.6274503469467163e-01
    z[6,2,1]  R1902     -6.9187784194946289e-01
    z[6,2,1]  R1903     2.4417115747928619e-01
    z[6,2,1]  R1904     1.3327860832214355e-01
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1816     -1
    z[6,2,2]  R1817     1
    z[6,2,2]  R1826     4.8773157596588135e-01
    z[6,2,2]  R1827     2.2447645664215088e-01
    z[6,2,2]  R1828     3.4056842327117920e-01
    z[6,2,2]  R1829     1.0006441920995712e-01
    z[6,2,2]  R1830     -7.9439111053943634e-02
    z[6,2,2]  R1831     -1.9052430987358093e-01
    z[6,2,2]  R1832     -5.7515446096658707e-03
    z[6,2,2]  R1833     -2.2354939579963684e-01
    z[6,2,2]  R1834     -5.0686992704868317e-02
    z[6,2,2]  R1835     -1.6932713985443115e-01
    z[6,2,2]  R1836     1.2727114558219910e-01
    z[6,2,2]  R1837     -2.3148582875728607e-01
    z[6,2,2]  R1838     -1.2812073528766632e-01
    z[6,2,2]  R1839     -1.6133835911750793e-01
    z[6,2,2]  R1840     -2.3383864760398865e-01
    z[6,2,2]  R1841     -0.0661177933216095
    z[6,2,2]  R1842     -1.2817256152629852e-01
    z[6,2,2]  R1843     1.7731526866555214e-02
    z[6,2,2]  R1844     -3.9519403129816055e-02
    z[6,2,2]  R1845     -1.8911775946617126e-01
    z[6,2,2]  R1846     -1.1916232854127884e-01
    z[6,2,2]  R1847     -7.4620373547077179e-02
    z[6,2,2]  R1848     -2.6734763383865356e-01
    z[6,2,2]  R1849     2.3613844811916351e-01
    z[6,2,2]  R1850     -0.0619661882519722
    z[6,2,2]  R1851     3.3399939537048340e-01
    z[6,2,2]  R1852     -5.9533727169036865e-01
    z[6,2,2]  R1853     -3.9430230855941772e-01
    z[6,2,2]  R1854     -5.0604969263076782e-01
    z[6,2,2]  R1855     -5.1947891712188721e-01
    z[6,2,2]  R1856     -1.0304950177669525e-02
    z[6,2,2]  R1857     3.6137357354164124e-01
    z[6,2,2]  R1858     1.4033210277557373e-01
    z[6,2,2]  R1859     -0.586410403251648
    z[6,2,2]  R1860     -4.8165100812911987e-01
    z[6,2,2]  R1861     1.6418717801570892e-01
    z[6,2,2]  R1862     -2.5007659196853638e-01
    z[6,2,2]  R1863     -3.9739865064620972e-01
    z[6,2,2]  R1864     -2.8848305344581604e-01
    z[6,2,2]  R1865     -4.4339919090270996e-01
    z[6,2,2]  R1866     9.7652688622474670e-02
    z[6,2,2]  R1867     1.1433774232864380e-01
    z[6,2,2]  R1868     -5.6149488687515259e-01
    z[6,2,2]  R1869     -4.7930890321731567e-01
    z[6,2,2]  R1870     -5.8779168128967285e-01
    z[6,2,2]  R1871     -1.1778302490711212e-01
    z[6,2,2]  R1872     -6.5734660625457764e-01
    z[6,2,2]  R1873     -4.9735471606254578e-01
    z[6,2,2]  R1874     -4.3005892634391785e-01
    z[6,2,2]  R1875     -1.5715565532445908e-02
    z[6,2,2]  R1876     2.1258221566677094e-01
    z[6,2,2]  R1877     4.1581603884696960e-01
    z[6,2,2]  R1878     3.2558149099349976e-01
    z[6,2,2]  R1879     -2.8964450955390930e-01
    z[6,2,2]  R1880     -3.0477553606033325e-01
    z[6,2,2]  R1881     2.3961445689201355e-01
    z[6,2,2]  R1882     7.6453518867492676e-01
    z[6,2,2]  R1883     8.1429845094680786e-01
    z[6,2,2]  R1884     3.0611777305603027e-01
    z[6,2,2]  R1885     5.0546836853027344e-01
    z[6,2,2]  R1886     5.2546513080596924e-01
    z[6,2,2]  R1887     -2.5471404194831848e-01
    z[6,2,2]  R1888     -1.9017027318477631e-01
    z[6,2,2]  R1889     -2.2027122974395752e-01
    z[6,2,2]  R1890     9.2856585979461670e-02
    z[6,2,2]  R1891     -1.5305048227310181e-01
    z[6,2,2]  R1892     1.3614802621304989e-02
    z[6,2,2]  R1893     -1.2995676696300507e-01
    z[6,2,2]  R1894     3.7700325250625610e-01
    z[6,2,2]  R1895     -3.8925856351852417e-01
    z[6,2,2]  R1896     -3.1161662936210632e-01
    z[6,2,2]  R1897     -0.522205114364624
    z[6,2,2]  R1898     -4.6922508627176285e-02
    z[6,2,2]  R1899     -1.6904366016387939e-01
    z[6,2,2]  R1900     -1.2624402344226837e-01
    z[6,2,2]  R1901     1.2969402968883514e-01
    z[6,2,2]  R1902     -5.3946632146835327e-01
    z[6,2,2]  R1903     -1.3117274641990662e-01
    z[6,2,2]  R1904     -9.6711240708827972e-02
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1818     -1
    z[6,2,3]  R1819     1
    z[6,2,3]  R1826     5.0965875387191772e-01
    z[6,2,3]  R1827     0.659257173538208
    z[6,2,3]  R1828     6.5231317281723022e-01
    z[6,2,3]  R1829     -2.9387019574642181e-02
    z[6,2,3]  R1830     -2.8190738521516323e-03
    z[6,2,3]  R1831     1.2896408140659332e-01
    z[6,2,3]  R1832     6.5814755856990814e-02
    z[6,2,3]  R1833     -1.6845270991325378e-02
    z[6,2,3]  R1834     -3.1805783510208130e-04
    z[6,2,3]  R1835     8.1102559342980385e-03
    z[6,2,3]  R1836     0.050968237221241
    z[6,2,3]  R1837     3.3115687966346741e-01
    z[6,2,3]  R1838     -3.3807581663131714e-01
    z[6,2,3]  R1839     0.274882048368454
    z[6,2,3]  R1840     2.7509680390357971e-01
    z[6,2,3]  R1841     2.9080143570899963e-01
    z[6,2,3]  R1842     4.2971488833427429e-01
    z[6,2,3]  R1843     -8.4945894777774811e-02
    z[6,2,3]  R1844     -0.509889543056488
    z[6,2,3]  R1845     -6.8869769573211670e-02
    z[6,2,3]  R1846     0.0910181850194931
    z[6,2,3]  R1847     1.2829015031456947e-02
    z[6,2,3]  R1848     -4.0507459640502930e-01
    z[6,2,3]  R1849     3.9797410368919373e-01
    z[6,2,3]  R1850     -4.0944054722785950e-01
    z[6,2,3]  R1851     -8.2941770553588867e-02
    z[6,2,3]  R1852     6.4459836483001709e-01
    z[6,2,3]  R1853     5.4118847846984863e-01
    z[6,2,3]  R1854     5.7443559169769287e-01
    z[6,2,3]  R1855     -3.1225383281707764e-02
    z[6,2,3]  R1856     6.6303342580795288e-02
    z[6,2,3]  R1857     -9.6390329301357269e-02
    z[6,2,3]  R1858     -0.134671151638031
    z[6,2,3]  R1859     2.1323148906230927e-01
    z[6,2,3]  R1860     7.3015308380126953e-01
    z[6,2,3]  R1861     -3.5643491148948669e-01
    z[6,2,3]  R1862     4.0695074200630188e-01
    z[6,2,3]  R1863     1.6109007596969604e-01
    z[6,2,3]  R1864     1.8732589483261108e-01
    z[6,2,3]  R1865     -1.0029952228069305e-01
    z[6,2,3]  R1866     -1.8509706482291222e-02
    z[6,2,3]  R1867     -3.7871259450912476e-01
    z[6,2,3]  R1868     2.9333943128585815e-01
    z[6,2,3]  R1869     4.7650942206382751e-01
    z[6,2,3]  R1870     -2.3655596375465393e-01
    z[6,2,3]  R1871     -2.9557985067367554e-01
    z[6,2,3]  R1872     -2.2809679806232452e-01
    z[6,2,3]  R1873     -5.1991522312164307e-01
    z[6,2,3]  R1874     1.1041344143450260e-02
    z[6,2,3]  R1875     -3.0342775583267212e-01
    z[6,2,3]  R1876     7.8052252531051636e-01
    z[6,2,3]  R1877     3.9015822112560272e-02
    z[6,2,3]  R1878     2.3934055864810944e-01
    z[6,2,3]  R1879     2.1962981671094894e-02
    z[6,2,3]  R1880     2.4569568037986755e-01
    z[6,2,3]  R1881     9.2812865972518921e-02
    z[6,2,3]  R1882     1.1253246106207371e-02
    z[6,2,3]  R1883     8.0901905894279480e-03
    z[6,2,3]  R1884     2.7741071581840515e-01
    z[6,2,3]  R1885     -1.1258782446384430e-01
    z[6,2,3]  R1886     1.5779989957809448e-01
    z[6,2,3]  R1887     -3.0732131004333496e-01
    z[6,2,3]  R1888     -2.5070270895957947e-01
    z[6,2,3]  R1889     -1.9933721423149109e-01
    z[6,2,3]  R1890     -2.9560244083404541e-01
    z[6,2,3]  R1891     1.8660595640540123e-02
    z[6,2,3]  R1892     -2.8148058056831360e-01
    z[6,2,3]  R1893     -5.0522230565547943e-02
    z[6,2,3]  R1894     -1.4186839759349823e-01
    z[6,2,3]  R1895     -8.7280482053756714e-02
    z[6,2,3]  R1896     1.5519383549690247e-01
    z[6,2,3]  R1897     2.8961020708084106e-01
    z[6,2,3]  R1898     -2.5664865970611572e-01
    z[6,2,3]  R1899     -4.9873286485671997e-01
    z[6,2,3]  R1900     -3.5075816512107849e-01
    z[6,2,3]  R1901     -5.5897700786590576e-01
    z[6,2,3]  R1902     -2.3413909971714020e-01
    z[6,2,3]  R1903     -3.6581665277481079e-01
    z[6,2,3]  R1904     -6.2053781747817993e-01
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1820     -1
    z[6,2,4]  R1821     1
    z[6,2,4]  R1826     5.1909282803535461e-02
    z[6,2,4]  R1827     -2.5398629903793335e-01
    z[6,2,4]  R1828     -2.3089951276779175e-01
    z[6,2,4]  R1829     -3.5876947641372681e-01
    z[6,2,4]  R1830     -0.0959881991147995
    z[6,2,4]  R1831     -2.8585413098335266e-01
    z[6,2,4]  R1832     -4.2576059699058533e-01
    z[6,2,4]  R1833     1.4788508415222168e-01
    z[6,2,4]  R1834     3.0391144752502441e-01
    z[6,2,4]  R1835     -4.3358907103538513e-01
    z[6,2,4]  R1836     -2.6395526528358459e-01
    z[6,2,4]  R1837     2.3674128949642181e-01
    z[6,2,4]  R1838     2.9911085963249207e-02
    z[6,2,4]  R1839     1.9667085260152817e-02
    z[6,2,4]  R1840     1.6249762475490570e-01
    z[6,2,4]  R1841     -6.1553075909614563e-02
    z[6,2,4]  R1842     1.5981048345565796e-01
    z[6,2,4]  R1843     -1.3030655682086945e-01
    z[6,2,4]  R1844     3.1087738275527954e-01
    z[6,2,4]  R1845     4.1969907283782959e-01
    z[6,2,4]  R1846     -1.7897665500640869e-01
    z[6,2,4]  R1847     3.9696547389030457e-01
    z[6,2,4]  R1848     7.8738816082477570e-02
    z[6,2,4]  R1849     2.1400362253189087e-01
    z[6,2,4]  R1850     4.6166211366653442e-01
    z[6,2,4]  R1851     5.9847152233123779e-01
    z[6,2,4]  R1852     4.0785338729619980e-02
    z[6,2,4]  R1853     -3.1205436587333679e-01
    z[6,2,4]  R1854     -4.5826199650764465e-01
    z[6,2,4]  R1855     -1.8192663788795471e-01
    z[6,2,4]  R1856     -9.5630668103694916e-02
    z[6,2,4]  R1857     2.0256495103240013e-02
    z[6,2,4]  R1858     2.1458901464939117e-01
    z[6,2,4]  R1859     -1.4460344612598419e-01
    z[6,2,4]  R1860     1.3604256510734558e-01
    z[6,2,4]  R1861     3.8054218888282776e-01
    z[6,2,4]  R1862     -2.4202033877372742e-01
    z[6,2,4]  R1863     5.1111710071563721e-01
    z[6,2,4]  R1864     -1.0704553872346878e-01
    z[6,2,4]  R1865     -2.0238064229488373e-01
    z[6,2,4]  R1866     1.1939971148967743e-01
    z[6,2,4]  R1867     2.5957143306732178e-01
    z[6,2,4]  R1868     7.4490890838205814e-03
    z[6,2,4]  R1869     -4.4754702597856522e-02
    z[6,2,4]  R1870     -1.8876731395721436e-01
    z[6,2,4]  R1871     1.6481505706906319e-02
    z[6,2,4]  R1872     3.5699892044067383e-01
    z[6,2,4]  R1873     4.9457452259957790e-03
    z[6,2,4]  R1874     2.1581137180328369e-01
    z[6,2,4]  R1875     2.5845596194267273e-01
    z[6,2,4]  R1876     -2.5614660978317261e-01
    z[6,2,4]  R1877     -0.000798138091340661
    z[6,2,4]  R1878     5.5186992883682251e-01
    z[6,2,4]  R1879     -1.3819648325443268e-01
    z[6,2,4]  R1880     -1.6549403965473175e-01
    z[6,2,4]  R1881     8.1146311759948730e-01
    z[6,2,4]  R1882     2.5595462322235107e-01
    z[6,2,4]  R1883     4.7331121563911438e-01
    z[6,2,4]  R1884     2.3274032771587372e-01
    z[6,2,4]  R1885     -4.3243950605392456e-01
    z[6,2,4]  R1886     -2.6868479326367378e-02
    z[6,2,4]  R1887     -8.4718890488147736e-02
    z[6,2,4]  R1888     1.7959372699260712e-01
    z[6,2,4]  R1889     3.3769440650939941e-01
    z[6,2,4]  R1890     3.5924088954925537e-01
    z[6,2,4]  R1891     -1.5597642958164215e-01
    z[6,2,4]  R1892     9.0175405144691467e-02
    z[6,2,4]  R1893     4.9020549654960632e-01
    z[6,2,4]  R1894     5.0157213211059570e-01
    z[6,2,4]  R1895     -3.6766156554222107e-01
    z[6,2,4]  R1896     6.4462912082672119e-01
    z[6,2,4]  R1897     5.4894257336854935e-02
    z[6,2,4]  R1898     1.9418130815029144e-01
    z[6,2,4]  R1899     2.1522257477045059e-02
    z[6,2,4]  R1900     1.9847208261489868e-01
    z[6,2,4]  R1901     1.3483066856861115e-01
    z[6,2,4]  R1902     -2.4369807541370392e-01
    z[6,2,4]  R1903     7.6184707880020142e-01
    z[6,2,4]  R1904     5.7341301441192627e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1822     -1
    z[6,2,5]  R1823     1
    z[6,2,5]  R1826     -2.5539833307266235e-01
    z[6,2,5]  R1827     7.1471042931079865e-02
    z[6,2,5]  R1828     1.1612446606159210e-01
    z[6,2,5]  R1829     -3.0692974105477333e-02
    z[6,2,5]  R1830     1.7688576877117157e-01
    z[6,2,5]  R1831     1.9736237823963165e-01
    z[6,2,5]  R1832     -7.6937347650527954e-01
    z[6,2,5]  R1833     1.4822122454643250e-01
    z[6,2,5]  R1834     -9.1586671769618988e-02
    z[6,2,5]  R1835     -2.5746437907218933e-01
    z[6,2,5]  R1836     -1.1757009476423264e-01
    z[6,2,5]  R1837     -2.1723946928977966e-01
    z[6,2,5]  R1838     -1.8353374302387238e-01
    z[6,2,5]  R1839     -3.0065011978149414e-01
    z[6,2,5]  R1840     -1.0003068484365940e-02
    z[6,2,5]  R1841     -7.0270299911499023e-02
    z[6,2,5]  R1842     2.5976386666297913e-01
    z[6,2,5]  R1843     -5.3589552640914917e-01
    z[6,2,5]  R1844     -2.5983822345733643e-01
    z[6,2,5]  R1845     -4.0476869791746140e-02
    z[6,2,5]  R1846     1.4154934883117676e-01
    z[6,2,5]  R1847     3.5965159535408020e-01
    z[6,2,5]  R1848     3.5309413075447083e-01
    z[6,2,5]  R1849     -1.8601374328136444e-01
    z[6,2,5]  R1850     -2.1937897801399231e-01
    z[6,2,5]  R1851     -1.6718253493309021e-01
    z[6,2,5]  R1852     -4.2517997324466705e-02
    z[6,2,5]  R1853     2.8758922591805458e-02
    z[6,2,5]  R1854     -2.0251670479774475e-01
    z[6,2,5]  R1855     6.2297517061233521e-01
    z[6,2,5]  R1856     4.8483829945325851e-02
    z[6,2,5]  R1857     -7.0186775922775269e-01
    z[6,2,5]  R1858     -3.9356565475463867e-01
    z[6,2,5]  R1859     2.5392500683665276e-02
    z[6,2,5]  R1860     -4.2466189712285995e-02
    z[6,2,5]  R1861     -5.4508411884307861e-01
    z[6,2,5]  R1862     1.8560223979875445e-03
    z[6,2,5]  R1863     3.8124760985374451e-01
    z[6,2,5]  R1864     4.3632471561431885e-01
    z[6,2,5]  R1865     2.3405356705188751e-01
    z[6,2,5]  R1866     -4.4823956489562988e-01
    z[6,2,5]  R1867     -2.5935393571853638e-01
    z[6,2,5]  R1868     1.9823490083217621e-01
    z[6,2,5]  R1869     -1.3387256860733032e-01
    z[6,2,5]  R1870     -6.7064121365547180e-02
    z[6,2,5]  R1871     -3.2198619842529297e-01
    z[6,2,5]  R1872     -3.4350180625915527e-01
    z[6,2,5]  R1873     -1.5017965435981750e-01
    z[6,2,5]  R1874     2.5003787875175476e-01
    z[6,2,5]  R1875     -5.9697788208723068e-02
    z[6,2,5]  R1876     -3.8127186894416809e-01
    z[6,2,5]  R1877     1.9546292722225189e-01
    z[6,2,5]  R1878     1.2754661962389946e-02
    z[6,2,5]  R1879     -2.3319636285305023e-01
    z[6,2,5]  R1880     2.1404910087585449e-01
    z[6,2,5]  R1881     -3.6159527301788330e-01
    z[6,2,5]  R1882     4.9350535869598389e-01
    z[6,2,5]  R1883     3.0156826972961426e-01
    z[6,2,5]  R1884     0.588338315486908
    z[6,2,5]  R1885     6.5808808803558350e-01
    z[6,2,5]  R1886     7.5849437713623047e-01
    z[6,2,5]  R1887     2.5602813810110092e-02
    z[6,2,5]  R1888     -1.7964061116799712e-03
    z[6,2,5]  R1889     9.3446910381317139e-02
    z[6,2,5]  R1890     -1.8723461031913757e-01
    z[6,2,5]  R1891     4.0902689099311829e-02
    z[6,2,5]  R1892     7.3748230934143066e-02
    z[6,2,5]  R1893     -2.8898175805807114e-02
    z[6,2,5]  R1894     1.5492363274097443e-01
    z[6,2,5]  R1895     -7.8078046441078186e-02
    z[6,2,5]  R1896     -2.1046692132949829e-01
    z[6,2,5]  R1897     -1.1115522682666779e-01
    z[6,2,5]  R1898     -4.7295203804969788e-01
    z[6,2,5]  R1899     -0.629519522190094
    z[6,2,5]  R1900     -7.7274823188781738e-01
    z[6,2,5]  R1901     -5.2689379453659058e-01
    z[6,2,5]  R1902     1.8636273220181465e-02
    z[6,2,5]  R1903     6.7329309880733490e-02
    z[6,2,5]  R1904     4.7534830868244171e-02
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1824     -1
    z[6,2,6]  R1825     1
    z[6,2,6]  R1826     5.3695771843194962e-02
    z[6,2,6]  R1827     3.0102658271789551e-01
    z[6,2,6]  R1828     -3.0510690808296204e-01
    z[6,2,6]  R1829     -1.0583250969648361e-01
    z[6,2,6]  R1830     3.3957654237747192e-01
    z[6,2,6]  R1831     -1.2614670395851135e-01
    z[6,2,6]  R1832     2.6650611311197281e-02
    z[6,2,6]  R1833     4.5035898685455322e-01
    z[6,2,6]  R1834     0.500627875328064
    z[6,2,6]  R1835     4.5484250783920288e-01
    z[6,2,6]  R1836     -5.0810897350311279e-01
    z[6,2,6]  R1837     9.6349850296974182e-02
    z[6,2,6]  R1838     6.6272813081741333e-01
    z[6,2,6]  R1839     -2.5804024934768677e-01
    z[6,2,6]  R1840     -3.0795404314994812e-01
    z[6,2,6]  R1841     3.4476846456527710e-02
    z[6,2,6]  R1842     1.8172548711299896e-01
    z[6,2,6]  R1843     4.8901230096817017e-01
    z[6,2,6]  R1844     -1.6833323240280151e-01
    z[6,2,6]  R1845     -1.3133953511714935e-01
    z[6,2,6]  R1846     3.0088698863983154e-01
    z[6,2,6]  R1847     1.3107791543006897e-01
    z[6,2,6]  R1848     -7.3397949337959290e-02
    z[6,2,6]  R1849     3.4319078922271729e-01
    z[6,2,6]  R1850     2.6081087067723274e-02
    z[6,2,6]  R1851     2.6228204369544983e-02
    z[6,2,6]  R1852     1.3008902966976166e-01
    z[6,2,6]  R1853     1.9161215424537659e-01
    z[6,2,6]  R1854     3.1981957145035267e-03
    z[6,2,6]  R1855     -5.2745349705219269e-02
    z[6,2,6]  R1856     -1.8745927512645721e-01
    z[6,2,6]  R1857     1.3385285437107086e-01
    z[6,2,6]  R1858     4.3754053115844727e-01
    z[6,2,6]  R1859     -3.3285838365554810e-01
    z[6,2,6]  R1860     -2.7408143505454063e-02
    z[6,2,6]  R1861     1.3167731463909149e-01
    z[6,2,6]  R1862     -3.1846159696578979e-01
    z[6,2,6]  R1863     -1.9886401295661926e-01
    z[6,2,6]  R1864     -2.4611370265483856e-01
    z[6,2,6]  R1865     1.5351347625255585e-01
    z[6,2,6]  R1866     2.7978392317891121e-02
    z[6,2,6]  R1867     1.9964060187339783e-01
    z[6,2,6]  R1868     -4.3247118592262268e-02
    z[6,2,6]  R1869     -1.1739847064018250e-01
    z[6,2,6]  R1870     4.6886342763900757e-01
    z[6,2,6]  R1871     -1.2221318483352661e-01
    z[6,2,6]  R1872     3.1506296247243881e-02
    z[6,2,6]  R1873     1.0364209115505219e-01
    z[6,2,6]  R1874     7.2631442546844482e-01
    z[6,2,6]  R1875     -1.9667962193489075e-01
    z[6,2,6]  R1876     4.7085378319025040e-03
    z[6,2,6]  R1877     7.4312782287597656e-01
    z[6,2,6]  R1878     2.7942320704460144e-01
    z[6,2,6]  R1879     -8.2495003938674927e-01
    z[6,2,6]  R1880     7.7458268404006958e-01
    z[6,2,6]  R1881     3.4406915307044983e-01
    z[6,2,6]  R1882     2.1685181558132172e-01
    z[6,2,6]  R1883     -7.4513129889965057e-02
    z[6,2,6]  R1884     -5.2094870805740356e-01
    z[6,2,6]  R1885     -2.1409682929515839e-01
    z[6,2,6]  R1886     -1.2189421057701111e-01
    z[6,2,6]  R1887     9.9363557994365692e-02
    z[6,2,6]  R1888     -2.9586055874824524e-01
    z[6,2,6]  R1889     -4.3308973312377930e-02
    z[6,2,6]  R1890     -4.3077409267425537e-02
    z[6,2,6]  R1891     -3.2265511155128479e-01
    z[6,2,6]  R1892     4.9872463941574097e-01
    z[6,2,6]  R1893     1.3152271509170532e-01
    z[6,2,6]  R1894     3.0254775285720825e-01
    z[6,2,6]  R1895     -6.7440646886825562e-01
    z[6,2,6]  R1896     0.0453985333442688
    z[6,2,6]  R1897     4.5224779844284058e-01
    z[6,2,6]  R1898     5.3213948011398315e-01
    z[6,2,6]  R1899     2.1461309492588043e-01
    z[6,2,6]  R1900     -1.1411865800619125e-01
    z[6,2,6]  R1901     1.1244162172079086e-01
    z[6,2,6]  R1902     3.0335816740989685e-01
    z[6,2,6]  R1903     -0.417203426361084
    z[6,2,6]  R1904     -0.503563642501831
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1948     -1
    z[3,4,0]  R1949     1
    z[3,4,0]  R1962     7.8155982494354248e-01
    z[3,4,0]  R1963     1.0259279608726501e-01
    z[3,4,0]  R1964     2.9779151082038879e-01
    z[3,4,0]  R1965     -6.8223649263381958e-01
    z[3,4,0]  R1966     -3.3380830287933350e-01
    z[3,4,0]  R1967     -2.7980053424835205e-01
    z[3,4,0]  R1968     -3.6434146761894226e-01
    z[3,4,0]  R1969     -1.6419696807861328e-01
    z[3,4,0]  R1970     -3.8544863462448120e-01
    z[3,4,0]  R1971     -0.623007595539093
    z[3,4,0]  R1972     -7.5105018913745880e-02
    z[3,4,0]  R1973     -2.9878070577979088e-02
    z[3,4,0]  R1974     -1.8481391668319702e-01
    z[3,4,0]  R1975     -3.4994819760322571e-01
    z[3,4,0]  R1976     -1.7089748382568359e-01
    z[3,4,0]  R1977     -2.3380618542432785e-02
    z[3,4,0]  R1978     3.0983725190162659e-01
    z[3,4,0]  R1979     3.7620510905981064e-02
    z[3,4,0]  R1980     -1.0741529613733292e-01
    z[3,4,0]  R1981     1.2551528215408325e-01
    z[3,4,0]  R1982     -2.1165297925472260e-01
    z[3,4,0]  R1983     1.9318635761737823e-01
    z[3,4,0]  R1984     -2.2988358512520790e-02
    z[3,4,0]  R1985     2.6377752423286438e-01
    z[3,4,0]  R1986     3.2029467821121216e-01
    z[3,4,0]  R1987     -0.270953506231308
    z[3,4,0]  R1988     -9.1509437561035156e-01
    z[3,4,0]  R1989     -8.7610584497451782e-01
    z[3,4,0]  R1990     -8.2335573434829712e-01
    z[3,4,0]  R1991     -7.5604027509689331e-01
    z[3,4,0]  R1992     -0.256926566362381
    z[3,4,0]  R1993     3.0761915445327759e-01
    z[3,4,0]  R1994     2.4368667975068092e-02
    z[3,4,0]  R1995     -1.7191019654273987e-01
    z[3,4,0]  R1996     3.1932809948921204e-01
    z[3,4,0]  R1997     -0.70970618724823
    z[3,4,0]  R1998     -4.7882348299026489e-02
    z[3,4,0]  R1999     -4.7134313732385635e-02
    z[3,4,0]  R2000     -4.5848438143730164e-01
    z[3,4,0]  R2001     -8.3330410718917847e-01
    z[3,4,0]  R2002     -3.8666200637817383e-01
    z[3,4,0]  R2003     -1.9907087087631226e-01
    z[3,4,0]  R2004     -4.4714611768722534e-01
    z[3,4,0]  R2005     1.3753038644790649e-01
    z[3,4,0]  R2006     3.7897473573684692e-01
    z[3,4,0]  R2007     6.2275505065917969e-01
    z[3,4,0]  R2008     6.7475163936614990e-01
    z[3,4,0]  R2009     5.7183831930160522e-01
    z[3,4,0]  R2010     7.6425084844231606e-03
    z[3,4,0]  R2011     1.7630884051322937e-01
    z[3,4,0]  R2012     5.3241960704326630e-02
    z[3,4,0]  R2013     -1.9779168069362640e-02
    z[3,4,0]  R2014     4.3267560005187988e-01
    z[3,4,0]  R2015     0.529718279838562
    z[3,4,0]  R2016     4.0345376729965210e-01
    z[3,4,0]  R2017     1.3535985350608826e-01
    z[3,4,0]  R2018     0.340166836977005
    z[3,4,0]  R2019     7.4405074119567871e-02
    z[3,4,0]  R2020     -1.9793882966041565e-01
    z[3,4,0]  R2021     -1.9118184223771095e-02
    z[3,4,0]  R2022     -2.7381128072738647e-01
    z[3,4,0]  R2023     -1.2327007949352264e-01
    z[3,4,0]  R2024     -3.6031207442283630e-01
    z[3,4,0]  R2025     0.573261022567749
    z[3,4,0]  R2026     8.0649471282958984e-01
    z[3,4,0]  R2027     3.2313579320907593e-01
    z[3,4,0]  R2028     6.6625958681106567e-01
    z[3,4,0]  R2029     1.7175951600074768e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1950     -1
    z[3,4,1]  R1951     1
    z[3,4,1]  R1962     -1.7388090491294861e-02
    z[3,4,1]  R1963     -3.0639293789863586e-01
    z[3,4,1]  R1964     -2.3125894367694855e-01
    z[3,4,1]  R1965     -2.1502365171909332e-01
    z[3,4,1]  R1966     1.0191959142684937e-01
    z[3,4,1]  R1967     3.8500636816024780e-01
    z[3,4,1]  R1968     2.3486943542957306e-01
    z[3,4,1]  R1969     0.492320716381073
    z[3,4,1]  R1970     -1.7778109014034271e-01
    z[3,4,1]  R1971     -3.3669683337211609e-01
    z[3,4,1]  R1972     -0.718687117099762
    z[3,4,1]  R1973     -2.8747299313545227e-01
    z[3,4,1]  R1974     -7.5129759311676025e-01
    z[3,4,1]  R1975     -7.0751869678497314e-01
    z[3,4,1]  R1976     -6.9615596532821655e-01
    z[3,4,1]  R1977     -6.8274384737014771e-01
    z[3,4,1]  R1978     -4.2941969633102417e-01
    z[3,4,1]  R1979     5.7843305170536041e-02
    z[3,4,1]  R1980     0.267410010099411
    z[3,4,1]  R1981     2.2924886643886566e-01
    z[3,4,1]  R1982     -8.6893546581268311e-01
    z[3,4,1]  R1983     -6.7153471708297729e-01
    z[3,4,1]  R1984     0.466298371553421
    z[3,4,1]  R1985     8.9918178319931030e-01
    z[3,4,1]  R1986     2.1315771341323853e-01
    z[3,4,1]  R1987     6.0820490121841431e-01
    z[3,4,1]  R1988     1.7647847533226013e-01
    z[3,4,1]  R1989     -3.6327905952930450e-02
    z[3,4,1]  R1990     4.0621817111968994e-02
    z[3,4,1]  R1991     2.8182867169380188e-01
    z[3,4,1]  R1992     3.1204733252525330e-01
    z[3,4,1]  R1993     -6.9999796152114868e-01
    z[3,4,1]  R1994     6.9709378480911255e-01
    z[3,4,1]  R1995     4.5377466082572937e-01
    z[3,4,1]  R1996     0.0917489156126976
    z[3,4,1]  R1997     4.4188103079795837e-01
    z[3,4,1]  R1998     4.5328539609909058e-01
    z[3,4,1]  R1999     4.9532383680343628e-01
    z[3,4,1]  R2000     5.8975040912628174e-01
    z[3,4,1]  R2001     -3.0199262499809265e-01
    z[3,4,1]  R2002     4.2183169722557068e-01
    z[3,4,1]  R2003     5.6619131565093994e-01
    z[3,4,1]  R2004     -0.187115877866745
    z[3,4,1]  R2005     -4.2707616090774536e-01
    z[3,4,1]  R2006     -0.341106116771698
    z[3,4,1]  R2007     -4.2832204699516296e-01
    z[3,4,1]  R2008     -0.382802814245224
    z[3,4,1]  R2009     -1.7089107632637024e-01
    z[3,4,1]  R2010     2.7923274040222168e-01
    z[3,4,1]  R2011     3.9075195789337158e-01
    z[3,4,1]  R2012     1.1419252306222916e-01
    z[3,4,1]  R2013     -8.4380501508712769e-01
    z[3,4,1]  R2014     7.0902770757675171e-01
    z[3,4,1]  R2015     -0.0634336769580841
    z[3,4,1]  R2016     -2.3554362356662750e-01
    z[3,4,1]  R2017     -2.5087940692901611e-01
    z[3,4,1]  R2018     6.6085916757583618e-01
    z[3,4,1]  R2019     -2.8801517561078072e-02
    z[3,4,1]  R2020     2.2513702511787415e-01
    z[3,4,1]  R2021     3.7106060981750488e-01
    z[3,4,1]  R2022     -8.3636589348316193e-02
    z[3,4,1]  R2023     -2.0240172743797302e-01
    z[3,4,1]  R2024     -2.1877533197402954e-01
    z[3,4,1]  R2025     -3.9691346883773804e-01
    z[3,4,1]  R2026     3.2836962491273880e-03
    z[3,4,1]  R2027     -1.2896490097045898e-01
    z[3,4,1]  R2028     -1.0529072955250740e-02
    z[3,4,1]  R2029     9.8508365452289581e-02
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1952     -1
    z[3,4,2]  R1953     1
    z[3,4,2]  R1962     1.0951692610979080e-01
    z[3,4,2]  R1963     2.0774249732494354e-01
    z[3,4,2]  R1964     1.5276065468788147e-01
    z[3,4,2]  R1965     -5.8153885602951050e-01
    z[3,4,2]  R1966     -7.0255053043365479e-01
    z[3,4,2]  R1967     -7.0949810743331909e-01
    z[3,4,2]  R1968     -7.4259728193283081e-01
    z[3,4,2]  R1969     -8.2217389345169067e-01
    z[3,4,2]  R1970     -8.1349629163742065e-01
    z[3,4,2]  R1971     -3.9143708348274231e-01
    z[3,4,2]  R1972     -6.0328418016433716e-01
    z[3,4,2]  R1973     0.596624493598938
    z[3,4,2]  R1974     -3.7396702170372009e-01
    z[3,4,2]  R1975     -1.9479447603225708e-01
    z[3,4,2]  R1976     -3.1045052409172058e-01
    z[3,4,2]  R1977     -2.8534984588623047e-01
    z[3,4,2]  R1978     -7.6795852184295654e-01
    z[3,4,2]  R1979     -7.4868999421596527e-02
    z[3,4,2]  R1980     2.5967352092266083e-02
    z[3,4,2]  R1981     -3.5041561722755432e-01
    z[3,4,2]  R1982     1.6584739089012146e-01
    z[3,4,2]  R1983     -1.2550047039985657e-01
    z[3,4,2]  R1984     5.0444994121789932e-02
    z[3,4,2]  R1985     1.2987813353538513e-01
    z[3,4,2]  R1986     -2.4401377141475677e-01
    z[3,4,2]  R1987     6.6568940877914429e-01
    z[3,4,2]  R1988     3.2851299643516541e-01
    z[3,4,2]  R1989     1.8951553106307983e-01
    z[3,4,2]  R1990     2.3056674003601074e-01
    z[3,4,2]  R1991     -1.7282633483409882e-01
    z[3,4,2]  R1992     8.4044122695922852e-01
    z[3,4,2]  R1993     -4.4037258625030518e-01
    z[3,4,2]  R1994     -1.7382787168025970e-01
    z[3,4,2]  R1995     -2.4577982723712921e-01
    z[3,4,2]  R1996     -4.2546781897544861e-01
    z[3,4,2]  R1997     1.5264713205397129e-02
    z[3,4,2]  R1998     -2.8176712989807129e-01
    z[3,4,2]  R1999     2.4739317595958710e-03
    z[3,4,2]  R2000     -5.6937170028686523e-01
    z[3,4,2]  R2001     -3.3548864722251892e-01
    z[3,4,2]  R2002     -1.4437523484230042e-01
    z[3,4,2]  R2003     -1.9146996736526489e-01
    z[3,4,2]  R2004     -1.9056263566017151e-01
    z[3,4,2]  R2005     3.4245607256889343e-01
    z[3,4,2]  R2006     0.211964413523674
    z[3,4,2]  R2007     3.5854774713516235e-01
    z[3,4,2]  R2008     3.7747806310653687e-01
    z[3,4,2]  R2009     1.7277404665946960e-01
    z[3,4,2]  R2010     5.6270472705364227e-02
    z[3,4,2]  R2011     6.1175487935543060e-02
    z[3,4,2]  R2012     6.2633596360683441e-02
    z[3,4,2]  R2013     3.6473387479782104e-01
    z[3,4,2]  R2014     4.6586093306541443e-01
    z[3,4,2]  R2015     4.9473071098327637e-01
    z[3,4,2]  R2016     8.7779097259044647e-02
    z[3,4,2]  R2017     -8.1706777215003967e-02
    z[3,4,2]  R2018     5.5561274290084839e-01
    z[3,4,2]  R2019     0.90269535779953
    z[3,4,2]  R2020     -2.4621029198169708e-01
    z[3,4,2]  R2021     9.7653055563569069e-03
    z[3,4,2]  R2022     -4.4117063283920288e-02
    z[3,4,2]  R2023     -5.2991036325693130e-02
    z[3,4,2]  R2024     1.3464756309986115e-01
    z[3,4,2]  R2025     5.7754433155059814e-01
    z[3,4,2]  R2026     4.4476282596588135e-01
    z[3,4,2]  R2027     0.648669958114624
    z[3,4,2]  R2028     4.4346186518669128e-01
    z[3,4,2]  R2029     7.2225689888000488e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1954     -1
    z[3,4,3]  R1955     1
    z[3,4,3]  R1962     7.1820162236690521e-02
    z[3,4,3]  R1963     -6.9875025749206543e-01
    z[3,4,3]  R1964     -3.1949985027313232e-01
    z[3,4,3]  R1965     -2.5845754891633987e-02
    z[3,4,3]  R1966     1.2670738995075226e-01
    z[3,4,3]  R1967     8.2595452666282654e-02
    z[3,4,3]  R1968     7.8051716089248657e-02
    z[3,4,3]  R1969     4.2187362909317017e-02
    z[3,4,3]  R1970     -1.5487730503082275e-01
    z[3,4,3]  R1971     -9.0489059686660767e-02
    z[3,4,3]  R1972     2.5117591023445129e-01
    z[3,4,3]  R1973     -3.9477947354316711e-01
    z[3,4,3]  R1974     2.0609444379806519e-01
    z[3,4,3]  R1975     0.452725350856781
    z[3,4,3]  R1976     4.5630702376365662e-01
    z[3,4,3]  R1977     6.1334747076034546e-01
    z[3,4,3]  R1978     1.7385989427566528e-01
    z[3,4,3]  R1979     -5.1712733507156372e-01
    z[3,4,3]  R1980     -4.2898854613304138e-01
    z[3,4,3]  R1981     -2.4088618159294128e-01
    z[3,4,3]  R1982     2.0723941922187805e-01
    z[3,4,3]  R1983     -2.8265175223350525e-01
    z[3,4,3]  R1984     -8.5531359910964966e-01
    z[3,4,3]  R1985     9.9095046520233154e-02
    z[3,4,3]  R1986     -7.8946202993392944e-01
    z[3,4,3]  R1987     -5.9033695608377457e-02
    z[3,4,3]  R1988     3.0602285638451576e-02
    z[3,4,3]  R1989     2.0207408070564270e-01
    z[3,4,3]  R1990     4.4499572366476059e-02
    z[3,4,3]  R1991     5.3708565235137939e-01
    z[3,4,3]  R1992     -1.2076288461685181e-01
    z[3,4,3]  R1993     -7.4476338922977448e-02
    z[3,4,3]  R1994     -6.3618320226669312e-01
    z[3,4,3]  R1995     -6.0746544599533081e-01
    z[3,4,3]  R1996     -7.5059723854064941e-01
    z[3,4,3]  R1997     4.6818497776985168e-01
    z[3,4,3]  R1998     6.4250385761260986e-01
    z[3,4,3]  R1999     7.8726017475128174e-01
    z[3,4,3]  R2000     -1.3295269571244717e-02
    z[3,4,3]  R2001     8.1346770748496056e-03
    z[3,4,3]  R2002     6.1704171821475029e-04
    z[3,4,3]  R2003     5.4796808958053589e-01
    z[3,4,3]  R2004     -1.8601444363594055e-01
    z[3,4,3]  R2005     4.6598574519157410e-01
    z[3,4,3]  R2006     6.8456375598907471e-01
    z[3,4,3]  R2007     3.7912562489509583e-01
    z[3,4,3]  R2008     4.2051178216934204e-01
    z[3,4,3]  R2009     7.0381826162338257e-01
    z[3,4,3]  R2010     -5.6691038608551025e-01
    z[3,4,3]  R2011     -8.9019864797592163e-01
    z[3,4,3]  R2012     -9.4144827127456665e-01
    z[3,4,3]  R2013     -2.9299971461296082e-01
    z[3,4,3]  R2014     -6.8816497921943665e-02
    z[3,4,3]  R2015     -7.7888399362564087e-02
    z[3,4,3]  R2016     -2.6586738228797913e-01
    z[3,4,3]  R2017     -3.8229238986968994e-01
    z[3,4,3]  R2018     -0.0145845552906394
    z[3,4,3]  R2019     5.6325122714042664e-02
    z[3,4,3]  R2020     -3.5785429179668427e-02
    z[3,4,3]  R2021     -6.5327733755111694e-01
    z[3,4,3]  R2022     -9.4674319028854370e-01
    z[3,4,3]  R2023     -0.876287579536438
    z[3,4,3]  R2024     -7.8395682573318481e-01
    z[3,4,3]  R2025     2.2759279608726501e-01
    z[3,4,3]  R2026     2.2771029174327850e-01
    z[3,4,3]  R2027     -3.8415189832448959e-02
    z[3,4,3]  R2028     -1.0041257739067078e-01
    z[3,4,3]  R2029     7.9403042793273926e-02
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1956     -1
    z[3,4,4]  R1957     1
    z[3,4,4]  R1962     1.5497450530529022e-01
    z[3,4,4]  R1963     4.9810070544481277e-02
    z[3,4,4]  R1964     -8.2780605554580688e-01
    z[3,4,4]  R1965     -2.7678960561752319e-01
    z[3,4,4]  R1966     -5.9021586179733276e-01
    z[3,4,4]  R1967     -3.2592964172363281e-01
    z[3,4,4]  R1968     -3.5340425372123718e-01
    z[3,4,4]  R1969     -2.1101097762584686e-01
    z[3,4,4]  R1970     -8.1960320472717285e-02
    z[3,4,4]  R1971     -5.4664772748947144e-01
    z[3,4,4]  R1972     1.3832703232765198e-01
    z[3,4,4]  R1973     -1.6693617403507233e-01
    z[3,4,4]  R1974     8.9001677930355072e-02
    z[3,4,4]  R1975     -1.7687901854515076e-01
    z[3,4,4]  R1976     -1.4729164540767670e-01
    z[3,4,4]  R1977     -1.5474909543991089e-01
    z[3,4,4]  R1978     -1.9208058714866638e-01
    z[3,4,4]  R1979     7.8312915563583374e-01
    z[3,4,4]  R1980     6.8898481130599976e-01
    z[3,4,4]  R1981     6.6069936752319336e-01
    z[3,4,4]  R1982     -2.2109439969062805e-01
    z[3,4,4]  R1983     4.3592989444732666e-01
    z[3,4,4]  R1984     -1.4450874924659729e-01
    z[3,4,4]  R1985     0.0320991687476635
    z[3,4,4]  R1986     -4.8460375517606735e-02
    z[3,4,4]  R1987     2.4460107088088989e-01
    z[3,4,4]  R1988     9.5805555582046509e-02
    z[3,4,4]  R1989     1.2552116811275482e-01
    z[3,4,4]  R1990     4.9232020974159241e-01
    z[3,4,4]  R1991     1.6777239739894867e-01
    z[3,4,4]  R1992     1.8751016259193420e-01
    z[3,4,4]  R1993     -1.9941788911819458e-01
    z[3,4,4]  R1994     -3.2221134752035141e-02
    z[3,4,4]  R1995     -0.0489906370639801
    z[3,4,4]  R1996     -2.7909772470593452e-02
    z[3,4,4]  R1997     -2.1687658131122589e-01
    z[3,4,4]  R1998     -5.3138142824172974e-01
    z[3,4,4]  R1999     -1.9959336519241333e-01
    z[3,4,4]  R2000     8.1056252121925354e-02
    z[3,4,4]  R2001     0.142792746424675
    z[3,4,4]  R2002     -8.0507266521453857e-01
    z[3,4,4]  R2003     -3.9802014827728271e-01
    z[3,4,4]  R2004     -4.7465908527374268e-01
    z[3,4,4]  R2005     -0.537653386592865
    z[3,4,4]  R2006     1.2213263660669327e-01
    z[3,4,4]  R2007     3.2871001958847046e-01
    z[3,4,4]  R2008     2.1572580933570862e-01
    z[3,4,4]  R2009     2.4480944871902466e-01
    z[3,4,4]  R2010     2.8845849633216858e-01
    z[3,4,4]  R2011     -6.0820616781711578e-02
    z[3,4,4]  R2012     1.4904613792896271e-01
    z[3,4,4]  R2013     4.2433872818946838e-02
    z[3,4,4]  R2014     1.1020025610923767e-01
    z[3,4,4]  R2015     7.6562032103538513e-02
    z[3,4,4]  R2016     7.3388224840164185e-01
    z[3,4,4]  R2017     7.9327476024627686e-01
    z[3,4,4]  R2018     3.6913216114044189e-01
    z[3,4,4]  R2019     4.1980534791946411e-02
    z[3,4,4]  R2020     -2.2857272997498512e-02
    z[3,4,4]  R2021     -4.3017558753490448e-02
    z[3,4,4]  R2022     4.3811939656734467e-02
    z[3,4,4]  R2023     3.4191107749938965e-01
    z[3,4,4]  R2024     -3.9321768283843994e-01
    z[3,4,4]  R2025     -3.0978059768676758e-01
    z[3,4,4]  R2026     -2.4362166225910187e-01
    z[3,4,4]  R2027     -3.9132431149482727e-02
    z[3,4,4]  R2028     -1.7526191473007202e-01
    z[3,4,4]  R2029     1.3096977770328522e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1958     -1
    z[3,4,5]  R1959     1
    z[3,4,5]  R1962     -5.8452707529067993e-01
    z[3,4,5]  R1963     -1.2743914127349854e-01
    z[3,4,5]  R1964     1.7452562227845192e-02
    z[3,4,5]  R1965     8.7726123631000519e-02
    z[3,4,5]  R1966     -1.3058429956436157e-01
    z[3,4,5]  R1967     -7.9703167080879211e-02
    z[3,4,5]  R1968     -3.2697755098342896e-01
    z[3,4,5]  R1969     2.0583800971508026e-02
    z[3,4,5]  R1970     4.2072642594575882e-02
    z[3,4,5]  R1971     -1.1930692009627819e-02
    z[3,4,5]  R1972     1.0244762152433395e-01
    z[3,4,5]  R1973     -2.3369353264570236e-02
    z[3,4,5]  R1974     -1.6928309202194214e-01
    z[3,4,5]  R1975     -2.7417975664138794e-01
    z[3,4,5]  R1976     3.0409688130021095e-02
    z[3,4,5]  R1977     1.0035818442702293e-02
    z[3,4,5]  R1978     2.0721469819545746e-01
    z[3,4,5]  R1979     3.1202328205108643e-01
    z[3,4,5]  R1980     2.7599191665649414e-01
    z[3,4,5]  R1981     3.9503401517868042e-01
    z[3,4,5]  R1982     -1.6550481319427490e-01
    z[3,4,5]  R1983     3.0633789300918579e-01
    z[3,4,5]  R1984     1.5955626964569092e-01
    z[3,4,5]  R1985     2.4823763966560364e-01
    z[3,4,5]  R1986     2.1159994602203369e-01
    z[3,4,5]  R1987     -2.1541567146778107e-01
    z[3,4,5]  R1988     -9.5731422305107117e-02
    z[3,4,5]  R1989     -0.0866822898387909
    z[3,4,5]  R1990     -7.0915900170803070e-02
    z[3,4,5]  R1991     -2.4924285709857941e-02
    z[3,4,5]  R1992     -8.8141247630119324e-02
    z[3,4,5]  R1993     2.8659364581108093e-01
    z[3,4,5]  R1994     0.0913451761007309
    z[3,4,5]  R1995     -1.2837243080139160e-01
    z[3,4,5]  R1996     3.7850487232208252e-01
    z[3,4,5]  R1997     -8.4200866520404816e-02
    z[3,4,5]  R1998     0.0953843742609024
    z[3,4,5]  R1999     2.8075750917196274e-02
    z[3,4,5]  R2000     -3.2239374518394470e-01
    z[3,4,5]  R2001     -2.5660082697868347e-01
    z[3,4,5]  R2002     1.2339268811047077e-02
    z[3,4,5]  R2003     9.2138200998306274e-02
    z[3,4,5]  R2004     -2.4084170162677765e-01
    z[3,4,5]  R2005     -4.0667504072189331e-01
    z[3,4,5]  R2006     -4.5615375041961670e-01
    z[3,4,5]  R2007     -5.0682887434959412e-02
    z[3,4,5]  R2008     -5.3031824529170990e-02
    z[3,4,5]  R2009     -3.7292614579200745e-02
    z[3,4,5]  R2010     1.4203681051731110e-01
    z[3,4,5]  R2011     8.4373086690902710e-02
    z[3,4,5]  R2012     -2.2015558183193207e-01
    z[3,4,5]  R2013     2.3934745788574219e-01
    z[3,4,5]  R2014     1.6793370246887207e-01
    z[3,4,5]  R2015     -5.6633424758911133e-01
    z[3,4,5]  R2016     3.3496430516242981e-01
    z[3,4,5]  R2017     2.1169048547744751e-01
    z[3,4,5]  R2018     -4.8653557896614075e-02
    z[3,4,5]  R2019     -4.1244491934776306e-01
    z[3,4,5]  R2020     8.6037427186965942e-01
    z[3,4,5]  R2021     5.9718143939971924e-01
    z[3,4,5]  R2022     -1.2719912827014923e-01
    z[3,4,5]  R2023     -6.2453597784042358e-03
    z[3,4,5]  R2024     1.5146744251251221e-01
    z[3,4,5]  R2025     1.6857126355171204e-01
    z[3,4,5]  R2026     1.3088262081146240e-01
    z[3,4,5]  R2027     -6.7186409235000610e-01
    z[3,4,5]  R2028     -5.4155224561691284e-01
    z[3,4,5]  R2029     -5.8668041229248047e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1960     -1
    z[3,4,6]  R1961     1
    z[3,4,6]  R1962     -7.7593624591827393e-02
    z[3,4,6]  R1963     5.8776468038558960e-01
    z[3,4,6]  R1964     2.1646265685558319e-01
    z[3,4,6]  R1965     2.5525358319282532e-01
    z[3,4,6]  R1966     -5.6083530187606812e-02
    z[3,4,6]  R1967     -3.8818728923797607e-01
    z[3,4,6]  R1968     -1.5079762041568756e-01
    z[3,4,6]  R1969     -8.9222088456153870e-02
    z[3,4,6]  R1970     -3.5436192154884338e-01
    z[3,4,6]  R1971     -1.9524197280406952e-01
    z[3,4,6]  R1972     -1.4552305638790131e-01
    z[3,4,6]  R1973     -6.1338496208190918e-01
    z[3,4,6]  R1974     -4.2719018459320068e-01
    z[3,4,6]  R1975     -1.6609518229961395e-01
    z[3,4,6]  R1976     -3.9867994189262390e-01
    z[3,4,6]  R1977     2.2725857794284821e-01
    z[3,4,6]  R1978     1.4063820242881775e-01
    z[3,4,6]  R1979     1.0753098130226135e-01
    z[3,4,6]  R1980     4.2588347196578979e-01
    z[3,4,6]  R1981     3.9786690473556519e-01
    z[3,4,6]  R1982     -2.3114077746868134e-01
    z[3,4,6]  R1983     -3.6359328031539917e-01
    z[3,4,6]  R1984     -3.9879478514194489e-02
    z[3,4,6]  R1985     1.8042442202568054e-01
    z[3,4,6]  R1986     -3.4936955571174622e-01
    z[3,4,6]  R1987     6.1725240200757980e-02
    z[3,4,6]  R1988     -6.5246790647506714e-02
    z[3,4,6]  R1989     -3.6207631230354309e-01
    z[3,4,6]  R1990     -1.3373765349388123e-01
    z[3,4,6]  R1991     4.3322015553712845e-02
    z[3,4,6]  R1992     -2.6974296569824219e-01
    z[3,4,6]  R1993     -3.0658626556396484e-01
    z[3,4,6]  R1994     -2.6294332742691040e-01
    z[3,4,6]  R1995     5.6234681606292725e-01
    z[3,4,6]  R1996     3.3876877278089523e-02
    z[3,4,6]  R1997     1.6584002971649170e-01
    z[3,4,6]  R1998     9.2581234872341156e-02
    z[3,4,6]  R1999     -3.0335170030593872e-01
    z[3,4,6]  R2000     8.4367677569389343e-02
    z[3,4,6]  R2001     -1.2470804899930954e-01
    z[3,4,6]  R2002     -5.8409009128808975e-02
    z[3,4,6]  R2003     -3.6872607469558716e-01
    z[3,4,6]  R2004     6.4095747470855713e-01
    z[3,4,6]  R2005     -9.9079899489879608e-02
    z[3,4,6]  R2006     5.8955080807209015e-02
    z[3,4,6]  R2007     -2.1402002871036530e-01
    z[3,4,6]  R2008     1.7176277935504913e-01
    z[3,4,6]  R2009     2.3929831385612488e-01
    z[3,4,6]  R2010     -7.0287567377090454e-01
    z[3,4,6]  R2011     -9.5990262925624847e-02
    z[3,4,6]  R2012     -1.5229627490043640e-01
    z[3,4,6]  R2013     9.8155051469802856e-02
    z[3,4,6]  R2014     2.1900594234466553e-01
    z[3,4,6]  R2015     -3.7142071127891541e-01
    z[3,4,6]  R2016     2.2928024828433990e-01
    z[3,4,6]  R2017     3.0301153659820557e-01
    z[3,4,6]  R2018     2.7891201898455620e-03
    z[3,4,6]  R2019     6.1072193086147308e-02
    z[3,4,6]  R2020     3.2782158255577087e-01
    z[3,4,6]  R2021     -2.7677747607231140e-01
    z[3,4,6]  R2022     4.0796067565679550e-02
    z[3,4,6]  R2023     2.3708198964595795e-01
    z[3,4,6]  R2024     -1.0968913137912750e-01
    z[3,4,6]  R2025     -0.0639939159154892
    z[3,4,6]  R2026     1.5299607813358307e-01
    z[3,4,6]  R2027     6.1401624232530594e-02
    z[3,4,6]  R2028     -1.5890444815158844e-01
    z[3,4,6]  R2029     -2.6737222075462341e-01
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2030     -1
    z[4,3,0]  R2031     1
    z[4,3,0]  R2044     -4.5848438143730164e-01
    z[4,3,0]  R2045     -8.3330410718917847e-01
    z[4,3,0]  R2046     -3.8666200637817383e-01
    z[4,3,0]  R2047     -1.9907087087631226e-01
    z[4,3,0]  R2048     -4.4714611768722534e-01
    z[4,3,0]  R2049     1.3753038644790649e-01
    z[4,3,0]  R2050     3.7897473573684692e-01
    z[4,3,0]  R2051     6.2275505065917969e-01
    z[4,3,0]  R2052     6.7475163936614990e-01
    z[4,3,0]  R2053     5.7183831930160522e-01
    z[4,3,0]  R2054     7.6425084844231606e-03
    z[4,3,0]  R2055     1.7630884051322937e-01
    z[4,3,0]  R2056     5.3241960704326630e-02
    z[4,3,0]  R2057     -1.9779168069362640e-02
    z[4,3,0]  R2058     4.3267560005187988e-01
    z[4,3,0]  R2059     0.529718279838562
    z[4,3,0]  R2060     4.0345376729965210e-01
    z[4,3,0]  R2061     1.3535985350608826e-01
    z[4,3,0]  R2062     0.340166836977005
    z[4,3,0]  R2063     7.4405074119567871e-02
    z[4,3,0]  R2064     -1.9793882966041565e-01
    z[4,3,0]  R2065     -1.9118184223771095e-02
    z[4,3,0]  R2066     -2.7381128072738647e-01
    z[4,3,0]  R2067     -1.2327007949352264e-01
    z[4,3,0]  R2068     -3.6031207442283630e-01
    z[4,3,0]  R2069     0.573261022567749
    z[4,3,0]  R2070     8.0649471282958984e-01
    z[4,3,0]  R2071     3.2313579320907593e-01
    z[4,3,0]  R2072     6.6625958681106567e-01
    z[4,3,0]  R2073     1.7175951600074768e-01
    z[4,3,0]  R2074     7.8155982494354248e-01
    z[4,3,0]  R2075     1.0259279608726501e-01
    z[4,3,0]  R2076     2.9779151082038879e-01
    z[4,3,0]  R2077     -6.8223649263381958e-01
    z[4,3,0]  R2078     -3.3380830287933350e-01
    z[4,3,0]  R2079     -2.7980053424835205e-01
    z[4,3,0]  R2080     -3.6434146761894226e-01
    z[4,3,0]  R2081     -1.6419696807861328e-01
    z[4,3,0]  R2082     -3.8544863462448120e-01
    z[4,3,0]  R2083     -0.623007595539093
    z[4,3,0]  R2084     -7.5105018913745880e-02
    z[4,3,0]  R2085     -2.9878070577979088e-02
    z[4,3,0]  R2086     -1.8481391668319702e-01
    z[4,3,0]  R2087     -3.4994819760322571e-01
    z[4,3,0]  R2088     -1.7089748382568359e-01
    z[4,3,0]  R2089     -2.3380618542432785e-02
    z[4,3,0]  R2090     3.0983725190162659e-01
    z[4,3,0]  R2091     3.7620510905981064e-02
    z[4,3,0]  R2092     -1.0741529613733292e-01
    z[4,3,0]  R2093     1.2551528215408325e-01
    z[4,3,0]  R2094     -2.1165297925472260e-01
    z[4,3,0]  R2095     1.9318635761737823e-01
    z[4,3,0]  R2096     -2.2988358512520790e-02
    z[4,3,0]  R2097     2.6377752423286438e-01
    z[4,3,0]  R2098     3.2029467821121216e-01
    z[4,3,0]  R2099     -0.270953506231308
    z[4,3,0]  R2100     -9.1509437561035156e-01
    z[4,3,0]  R2101     -8.7610584497451782e-01
    z[4,3,0]  R2102     -8.2335573434829712e-01
    z[4,3,0]  R2103     -7.5604027509689331e-01
    z[4,3,0]  R2104     -0.256926566362381
    z[4,3,0]  R2105     3.0761915445327759e-01
    z[4,3,0]  R2106     2.4368667975068092e-02
    z[4,3,0]  R2107     -1.7191019654273987e-01
    z[4,3,0]  R2108     3.1932809948921204e-01
    z[4,3,0]  R2109     -0.70970618724823
    z[4,3,0]  R2110     -4.7882348299026489e-02
    z[4,3,0]  R2111     -4.7134313732385635e-02
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2032     -1
    z[4,3,1]  R2033     1
    z[4,3,1]  R2044     5.8975040912628174e-01
    z[4,3,1]  R2045     -3.0199262499809265e-01
    z[4,3,1]  R2046     4.2183169722557068e-01
    z[4,3,1]  R2047     5.6619131565093994e-01
    z[4,3,1]  R2048     -0.187115877866745
    z[4,3,1]  R2049     -4.2707616090774536e-01
    z[4,3,1]  R2050     -0.341106116771698
    z[4,3,1]  R2051     -4.2832204699516296e-01
    z[4,3,1]  R2052     -0.382802814245224
    z[4,3,1]  R2053     -1.7089107632637024e-01
    z[4,3,1]  R2054     2.7923274040222168e-01
    z[4,3,1]  R2055     3.9075195789337158e-01
    z[4,3,1]  R2056     1.1419252306222916e-01
    z[4,3,1]  R2057     -8.4380501508712769e-01
    z[4,3,1]  R2058     7.0902770757675171e-01
    z[4,3,1]  R2059     -0.0634336769580841
    z[4,3,1]  R2060     -2.3554362356662750e-01
    z[4,3,1]  R2061     -2.5087940692901611e-01
    z[4,3,1]  R2062     6.6085916757583618e-01
    z[4,3,1]  R2063     -2.8801517561078072e-02
    z[4,3,1]  R2064     2.2513702511787415e-01
    z[4,3,1]  R2065     3.7106060981750488e-01
    z[4,3,1]  R2066     -8.3636589348316193e-02
    z[4,3,1]  R2067     -2.0240172743797302e-01
    z[4,3,1]  R2068     -2.1877533197402954e-01
    z[4,3,1]  R2069     -3.9691346883773804e-01
    z[4,3,1]  R2070     3.2836962491273880e-03
    z[4,3,1]  R2071     -1.2896490097045898e-01
    z[4,3,1]  R2072     -1.0529072955250740e-02
    z[4,3,1]  R2073     9.8508365452289581e-02
    z[4,3,1]  R2074     -1.7388090491294861e-02
    z[4,3,1]  R2075     -3.0639293789863586e-01
    z[4,3,1]  R2076     -2.3125894367694855e-01
    z[4,3,1]  R2077     -2.1502365171909332e-01
    z[4,3,1]  R2078     1.0191959142684937e-01
    z[4,3,1]  R2079     3.8500636816024780e-01
    z[4,3,1]  R2080     2.3486943542957306e-01
    z[4,3,1]  R2081     0.492320716381073
    z[4,3,1]  R2082     -1.7778109014034271e-01
    z[4,3,1]  R2083     -3.3669683337211609e-01
    z[4,3,1]  R2084     -0.718687117099762
    z[4,3,1]  R2085     -2.8747299313545227e-01
    z[4,3,1]  R2086     -7.5129759311676025e-01
    z[4,3,1]  R2087     -7.0751869678497314e-01
    z[4,3,1]  R2088     -6.9615596532821655e-01
    z[4,3,1]  R2089     -6.8274384737014771e-01
    z[4,3,1]  R2090     -4.2941969633102417e-01
    z[4,3,1]  R2091     5.7843305170536041e-02
    z[4,3,1]  R2092     0.267410010099411
    z[4,3,1]  R2093     2.2924886643886566e-01
    z[4,3,1]  R2094     -8.6893546581268311e-01
    z[4,3,1]  R2095     -6.7153471708297729e-01
    z[4,3,1]  R2096     0.466298371553421
    z[4,3,1]  R2097     8.9918178319931030e-01
    z[4,3,1]  R2098     2.1315771341323853e-01
    z[4,3,1]  R2099     6.0820490121841431e-01
    z[4,3,1]  R2100     1.7647847533226013e-01
    z[4,3,1]  R2101     -3.6327905952930450e-02
    z[4,3,1]  R2102     4.0621817111968994e-02
    z[4,3,1]  R2103     2.8182867169380188e-01
    z[4,3,1]  R2104     3.1204733252525330e-01
    z[4,3,1]  R2105     -6.9999796152114868e-01
    z[4,3,1]  R2106     6.9709378480911255e-01
    z[4,3,1]  R2107     4.5377466082572937e-01
    z[4,3,1]  R2108     0.0917489156126976
    z[4,3,1]  R2109     4.4188103079795837e-01
    z[4,3,1]  R2110     4.5328539609909058e-01
    z[4,3,1]  R2111     4.9532383680343628e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2034     -1
    z[4,3,2]  R2035     1
    z[4,3,2]  R2044     -5.6937170028686523e-01
    z[4,3,2]  R2045     -3.3548864722251892e-01
    z[4,3,2]  R2046     -1.4437523484230042e-01
    z[4,3,2]  R2047     -1.9146996736526489e-01
    z[4,3,2]  R2048     -1.9056263566017151e-01
    z[4,3,2]  R2049     3.4245607256889343e-01
    z[4,3,2]  R2050     0.211964413523674
    z[4,3,2]  R2051     3.5854774713516235e-01
    z[4,3,2]  R2052     3.7747806310653687e-01
    z[4,3,2]  R2053     1.7277404665946960e-01
    z[4,3,2]  R2054     5.6270472705364227e-02
    z[4,3,2]  R2055     6.1175487935543060e-02
    z[4,3,2]  R2056     6.2633596360683441e-02
    z[4,3,2]  R2057     3.6473387479782104e-01
    z[4,3,2]  R2058     4.6586093306541443e-01
    z[4,3,2]  R2059     4.9473071098327637e-01
    z[4,3,2]  R2060     8.7779097259044647e-02
    z[4,3,2]  R2061     -8.1706777215003967e-02
    z[4,3,2]  R2062     5.5561274290084839e-01
    z[4,3,2]  R2063     0.90269535779953
    z[4,3,2]  R2064     -2.4621029198169708e-01
    z[4,3,2]  R2065     9.7653055563569069e-03
    z[4,3,2]  R2066     -4.4117063283920288e-02
    z[4,3,2]  R2067     -5.2991036325693130e-02
    z[4,3,2]  R2068     1.3464756309986115e-01
    z[4,3,2]  R2069     5.7754433155059814e-01
    z[4,3,2]  R2070     4.4476282596588135e-01
    z[4,3,2]  R2071     0.648669958114624
    z[4,3,2]  R2072     4.4346186518669128e-01
    z[4,3,2]  R2073     7.2225689888000488e-01
    z[4,3,2]  R2074     1.0951692610979080e-01
    z[4,3,2]  R2075     2.0774249732494354e-01
    z[4,3,2]  R2076     1.5276065468788147e-01
    z[4,3,2]  R2077     -5.8153885602951050e-01
    z[4,3,2]  R2078     -7.0255053043365479e-01
    z[4,3,2]  R2079     -7.0949810743331909e-01
    z[4,3,2]  R2080     -7.4259728193283081e-01
    z[4,3,2]  R2081     -8.2217389345169067e-01
    z[4,3,2]  R2082     -8.1349629163742065e-01
    z[4,3,2]  R2083     -3.9143708348274231e-01
    z[4,3,2]  R2084     -6.0328418016433716e-01
    z[4,3,2]  R2085     0.596624493598938
    z[4,3,2]  R2086     -3.7396702170372009e-01
    z[4,3,2]  R2087     -1.9479447603225708e-01
    z[4,3,2]  R2088     -3.1045052409172058e-01
    z[4,3,2]  R2089     -2.8534984588623047e-01
    z[4,3,2]  R2090     -7.6795852184295654e-01
    z[4,3,2]  R2091     -7.4868999421596527e-02
    z[4,3,2]  R2092     2.5967352092266083e-02
    z[4,3,2]  R2093     -3.5041561722755432e-01
    z[4,3,2]  R2094     1.6584739089012146e-01
    z[4,3,2]  R2095     -1.2550047039985657e-01
    z[4,3,2]  R2096     5.0444994121789932e-02
    z[4,3,2]  R2097     1.2987813353538513e-01
    z[4,3,2]  R2098     -2.4401377141475677e-01
    z[4,3,2]  R2099     6.6568940877914429e-01
    z[4,3,2]  R2100     3.2851299643516541e-01
    z[4,3,2]  R2101     1.8951553106307983e-01
    z[4,3,2]  R2102     2.3056674003601074e-01
    z[4,3,2]  R2103     -1.7282633483409882e-01
    z[4,3,2]  R2104     8.4044122695922852e-01
    z[4,3,2]  R2105     -4.4037258625030518e-01
    z[4,3,2]  R2106     -1.7382787168025970e-01
    z[4,3,2]  R2107     -2.4577982723712921e-01
    z[4,3,2]  R2108     -4.2546781897544861e-01
    z[4,3,2]  R2109     1.5264713205397129e-02
    z[4,3,2]  R2110     -2.8176712989807129e-01
    z[4,3,2]  R2111     2.4739317595958710e-03
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2036     -1
    z[4,3,3]  R2037     1
    z[4,3,3]  R2044     -1.3295269571244717e-02
    z[4,3,3]  R2045     8.1346770748496056e-03
    z[4,3,3]  R2046     6.1704171821475029e-04
    z[4,3,3]  R2047     5.4796808958053589e-01
    z[4,3,3]  R2048     -1.8601444363594055e-01
    z[4,3,3]  R2049     4.6598574519157410e-01
    z[4,3,3]  R2050     6.8456375598907471e-01
    z[4,3,3]  R2051     3.7912562489509583e-01
    z[4,3,3]  R2052     4.2051178216934204e-01
    z[4,3,3]  R2053     7.0381826162338257e-01
    z[4,3,3]  R2054     -5.6691038608551025e-01
    z[4,3,3]  R2055     -8.9019864797592163e-01
    z[4,3,3]  R2056     -9.4144827127456665e-01
    z[4,3,3]  R2057     -2.9299971461296082e-01
    z[4,3,3]  R2058     -6.8816497921943665e-02
    z[4,3,3]  R2059     -7.7888399362564087e-02
    z[4,3,3]  R2060     -2.6586738228797913e-01
    z[4,3,3]  R2061     -3.8229238986968994e-01
    z[4,3,3]  R2062     -0.0145845552906394
    z[4,3,3]  R2063     5.6325122714042664e-02
    z[4,3,3]  R2064     -3.5785429179668427e-02
    z[4,3,3]  R2065     -6.5327733755111694e-01
    z[4,3,3]  R2066     -9.4674319028854370e-01
    z[4,3,3]  R2067     -0.876287579536438
    z[4,3,3]  R2068     -7.8395682573318481e-01
    z[4,3,3]  R2069     2.2759279608726501e-01
    z[4,3,3]  R2070     2.2771029174327850e-01
    z[4,3,3]  R2071     -3.8415189832448959e-02
    z[4,3,3]  R2072     -1.0041257739067078e-01
    z[4,3,3]  R2073     7.9403042793273926e-02
    z[4,3,3]  R2074     7.1820162236690521e-02
    z[4,3,3]  R2075     -6.9875025749206543e-01
    z[4,3,3]  R2076     -3.1949985027313232e-01
    z[4,3,3]  R2077     -2.5845754891633987e-02
    z[4,3,3]  R2078     1.2670738995075226e-01
    z[4,3,3]  R2079     8.2595452666282654e-02
    z[4,3,3]  R2080     7.8051716089248657e-02
    z[4,3,3]  R2081     4.2187362909317017e-02
    z[4,3,3]  R2082     -1.5487730503082275e-01
    z[4,3,3]  R2083     -9.0489059686660767e-02
    z[4,3,3]  R2084     2.5117591023445129e-01
    z[4,3,3]  R2085     -3.9477947354316711e-01
    z[4,3,3]  R2086     2.0609444379806519e-01
    z[4,3,3]  R2087     0.452725350856781
    z[4,3,3]  R2088     4.5630702376365662e-01
    z[4,3,3]  R2089     6.1334747076034546e-01
    z[4,3,3]  R2090     1.7385989427566528e-01
    z[4,3,3]  R2091     -5.1712733507156372e-01
    z[4,3,3]  R2092     -4.2898854613304138e-01
    z[4,3,3]  R2093     -2.4088618159294128e-01
    z[4,3,3]  R2094     2.0723941922187805e-01
    z[4,3,3]  R2095     -2.8265175223350525e-01
    z[4,3,3]  R2096     -8.5531359910964966e-01
    z[4,3,3]  R2097     9.9095046520233154e-02
    z[4,3,3]  R2098     -7.8946202993392944e-01
    z[4,3,3]  R2099     -5.9033695608377457e-02
    z[4,3,3]  R2100     3.0602285638451576e-02
    z[4,3,3]  R2101     2.0207408070564270e-01
    z[4,3,3]  R2102     4.4499572366476059e-02
    z[4,3,3]  R2103     5.3708565235137939e-01
    z[4,3,3]  R2104     -1.2076288461685181e-01
    z[4,3,3]  R2105     -7.4476338922977448e-02
    z[4,3,3]  R2106     -6.3618320226669312e-01
    z[4,3,3]  R2107     -6.0746544599533081e-01
    z[4,3,3]  R2108     -7.5059723854064941e-01
    z[4,3,3]  R2109     4.6818497776985168e-01
    z[4,3,3]  R2110     6.4250385761260986e-01
    z[4,3,3]  R2111     7.8726017475128174e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2038     -1
    z[4,3,4]  R2039     1
    z[4,3,4]  R2044     8.1056252121925354e-02
    z[4,3,4]  R2045     0.142792746424675
    z[4,3,4]  R2046     -8.0507266521453857e-01
    z[4,3,4]  R2047     -3.9802014827728271e-01
    z[4,3,4]  R2048     -4.7465908527374268e-01
    z[4,3,4]  R2049     -0.537653386592865
    z[4,3,4]  R2050     1.2213263660669327e-01
    z[4,3,4]  R2051     3.2871001958847046e-01
    z[4,3,4]  R2052     2.1572580933570862e-01
    z[4,3,4]  R2053     2.4480944871902466e-01
    z[4,3,4]  R2054     2.8845849633216858e-01
    z[4,3,4]  R2055     -6.0820616781711578e-02
    z[4,3,4]  R2056     1.4904613792896271e-01
    z[4,3,4]  R2057     4.2433872818946838e-02
    z[4,3,4]  R2058     1.1020025610923767e-01
    z[4,3,4]  R2059     7.6562032103538513e-02
    z[4,3,4]  R2060     7.3388224840164185e-01
    z[4,3,4]  R2061     7.9327476024627686e-01
    z[4,3,4]  R2062     3.6913216114044189e-01
    z[4,3,4]  R2063     4.1980534791946411e-02
    z[4,3,4]  R2064     -2.2857272997498512e-02
    z[4,3,4]  R2065     -4.3017558753490448e-02
    z[4,3,4]  R2066     4.3811939656734467e-02
    z[4,3,4]  R2067     3.4191107749938965e-01
    z[4,3,4]  R2068     -3.9321768283843994e-01
    z[4,3,4]  R2069     -3.0978059768676758e-01
    z[4,3,4]  R2070     -2.4362166225910187e-01
    z[4,3,4]  R2071     -3.9132431149482727e-02
    z[4,3,4]  R2072     -1.7526191473007202e-01
    z[4,3,4]  R2073     1.3096977770328522e-01
    z[4,3,4]  R2074     1.5497450530529022e-01
    z[4,3,4]  R2075     4.9810070544481277e-02
    z[4,3,4]  R2076     -8.2780605554580688e-01
    z[4,3,4]  R2077     -2.7678960561752319e-01
    z[4,3,4]  R2078     -5.9021586179733276e-01
    z[4,3,4]  R2079     -3.2592964172363281e-01
    z[4,3,4]  R2080     -3.5340425372123718e-01
    z[4,3,4]  R2081     -2.1101097762584686e-01
    z[4,3,4]  R2082     -8.1960320472717285e-02
    z[4,3,4]  R2083     -5.4664772748947144e-01
    z[4,3,4]  R2084     1.3832703232765198e-01
    z[4,3,4]  R2085     -1.6693617403507233e-01
    z[4,3,4]  R2086     8.9001677930355072e-02
    z[4,3,4]  R2087     -1.7687901854515076e-01
    z[4,3,4]  R2088     -1.4729164540767670e-01
    z[4,3,4]  R2089     -1.5474909543991089e-01
    z[4,3,4]  R2090     -1.9208058714866638e-01
    z[4,3,4]  R2091     7.8312915563583374e-01
    z[4,3,4]  R2092     6.8898481130599976e-01
    z[4,3,4]  R2093     6.6069936752319336e-01
    z[4,3,4]  R2094     -2.2109439969062805e-01
    z[4,3,4]  R2095     4.3592989444732666e-01
    z[4,3,4]  R2096     -1.4450874924659729e-01
    z[4,3,4]  R2097     0.0320991687476635
    z[4,3,4]  R2098     -4.8460375517606735e-02
    z[4,3,4]  R2099     2.4460107088088989e-01
    z[4,3,4]  R2100     9.5805555582046509e-02
    z[4,3,4]  R2101     1.2552116811275482e-01
    z[4,3,4]  R2102     4.9232020974159241e-01
    z[4,3,4]  R2103     1.6777239739894867e-01
    z[4,3,4]  R2104     1.8751016259193420e-01
    z[4,3,4]  R2105     -1.9941788911819458e-01
    z[4,3,4]  R2106     -3.2221134752035141e-02
    z[4,3,4]  R2107     -0.0489906370639801
    z[4,3,4]  R2108     -2.7909772470593452e-02
    z[4,3,4]  R2109     -2.1687658131122589e-01
    z[4,3,4]  R2110     -5.3138142824172974e-01
    z[4,3,4]  R2111     -1.9959336519241333e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2040     -1
    z[4,3,5]  R2041     1
    z[4,3,5]  R2044     -3.2239374518394470e-01
    z[4,3,5]  R2045     -2.5660082697868347e-01
    z[4,3,5]  R2046     1.2339268811047077e-02
    z[4,3,5]  R2047     9.2138200998306274e-02
    z[4,3,5]  R2048     -2.4084170162677765e-01
    z[4,3,5]  R2049     -4.0667504072189331e-01
    z[4,3,5]  R2050     -4.5615375041961670e-01
    z[4,3,5]  R2051     -5.0682887434959412e-02
    z[4,3,5]  R2052     -5.3031824529170990e-02
    z[4,3,5]  R2053     -3.7292614579200745e-02
    z[4,3,5]  R2054     1.4203681051731110e-01
    z[4,3,5]  R2055     8.4373086690902710e-02
    z[4,3,5]  R2056     -2.2015558183193207e-01
    z[4,3,5]  R2057     2.3934745788574219e-01
    z[4,3,5]  R2058     1.6793370246887207e-01
    z[4,3,5]  R2059     -5.6633424758911133e-01
    z[4,3,5]  R2060     3.3496430516242981e-01
    z[4,3,5]  R2061     2.1169048547744751e-01
    z[4,3,5]  R2062     -4.8653557896614075e-02
    z[4,3,5]  R2063     -4.1244491934776306e-01
    z[4,3,5]  R2064     8.6037427186965942e-01
    z[4,3,5]  R2065     5.9718143939971924e-01
    z[4,3,5]  R2066     -1.2719912827014923e-01
    z[4,3,5]  R2067     -6.2453597784042358e-03
    z[4,3,5]  R2068     1.5146744251251221e-01
    z[4,3,5]  R2069     1.6857126355171204e-01
    z[4,3,5]  R2070     1.3088262081146240e-01
    z[4,3,5]  R2071     -6.7186409235000610e-01
    z[4,3,5]  R2072     -5.4155224561691284e-01
    z[4,3,5]  R2073     -5.8668041229248047e-01
    z[4,3,5]  R2074     -5.8452707529067993e-01
    z[4,3,5]  R2075     -1.2743914127349854e-01
    z[4,3,5]  R2076     1.7452562227845192e-02
    z[4,3,5]  R2077     8.7726123631000519e-02
    z[4,3,5]  R2078     -1.3058429956436157e-01
    z[4,3,5]  R2079     -7.9703167080879211e-02
    z[4,3,5]  R2080     -3.2697755098342896e-01
    z[4,3,5]  R2081     2.0583800971508026e-02
    z[4,3,5]  R2082     4.2072642594575882e-02
    z[4,3,5]  R2083     -1.1930692009627819e-02
    z[4,3,5]  R2084     1.0244762152433395e-01
    z[4,3,5]  R2085     -2.3369353264570236e-02
    z[4,3,5]  R2086     -1.6928309202194214e-01
    z[4,3,5]  R2087     -2.7417975664138794e-01
    z[4,3,5]  R2088     3.0409688130021095e-02
    z[4,3,5]  R2089     1.0035818442702293e-02
    z[4,3,5]  R2090     2.0721469819545746e-01
    z[4,3,5]  R2091     3.1202328205108643e-01
    z[4,3,5]  R2092     2.7599191665649414e-01
    z[4,3,5]  R2093     3.9503401517868042e-01
    z[4,3,5]  R2094     -1.6550481319427490e-01
    z[4,3,5]  R2095     3.0633789300918579e-01
    z[4,3,5]  R2096     1.5955626964569092e-01
    z[4,3,5]  R2097     2.4823763966560364e-01
    z[4,3,5]  R2098     2.1159994602203369e-01
    z[4,3,5]  R2099     -2.1541567146778107e-01
    z[4,3,5]  R2100     -9.5731422305107117e-02
    z[4,3,5]  R2101     -0.0866822898387909
    z[4,3,5]  R2102     -7.0915900170803070e-02
    z[4,3,5]  R2103     -2.4924285709857941e-02
    z[4,3,5]  R2104     -8.8141247630119324e-02
    z[4,3,5]  R2105     2.8659364581108093e-01
    z[4,3,5]  R2106     0.0913451761007309
    z[4,3,5]  R2107     -1.2837243080139160e-01
    z[4,3,5]  R2108     3.7850487232208252e-01
    z[4,3,5]  R2109     -8.4200866520404816e-02
    z[4,3,5]  R2110     0.0953843742609024
    z[4,3,5]  R2111     2.8075750917196274e-02
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2042     -1
    z[4,3,6]  R2043     1
    z[4,3,6]  R2044     8.4367677569389343e-02
    z[4,3,6]  R2045     -1.2470804899930954e-01
    z[4,3,6]  R2046     -5.8409009128808975e-02
    z[4,3,6]  R2047     -3.6872607469558716e-01
    z[4,3,6]  R2048     6.4095747470855713e-01
    z[4,3,6]  R2049     -9.9079899489879608e-02
    z[4,3,6]  R2050     5.8955080807209015e-02
    z[4,3,6]  R2051     -2.1402002871036530e-01
    z[4,3,6]  R2052     1.7176277935504913e-01
    z[4,3,6]  R2053     2.3929831385612488e-01
    z[4,3,6]  R2054     -7.0287567377090454e-01
    z[4,3,6]  R2055     -9.5990262925624847e-02
    z[4,3,6]  R2056     -1.5229627490043640e-01
    z[4,3,6]  R2057     9.8155051469802856e-02
    z[4,3,6]  R2058     2.1900594234466553e-01
    z[4,3,6]  R2059     -3.7142071127891541e-01
    z[4,3,6]  R2060     2.2928024828433990e-01
    z[4,3,6]  R2061     3.0301153659820557e-01
    z[4,3,6]  R2062     2.7891201898455620e-03
    z[4,3,6]  R2063     6.1072193086147308e-02
    z[4,3,6]  R2064     3.2782158255577087e-01
    z[4,3,6]  R2065     -2.7677747607231140e-01
    z[4,3,6]  R2066     4.0796067565679550e-02
    z[4,3,6]  R2067     2.3708198964595795e-01
    z[4,3,6]  R2068     -1.0968913137912750e-01
    z[4,3,6]  R2069     -0.0639939159154892
    z[4,3,6]  R2070     1.5299607813358307e-01
    z[4,3,6]  R2071     6.1401624232530594e-02
    z[4,3,6]  R2072     -1.5890444815158844e-01
    z[4,3,6]  R2073     -2.6737222075462341e-01
    z[4,3,6]  R2074     -7.7593624591827393e-02
    z[4,3,6]  R2075     5.8776468038558960e-01
    z[4,3,6]  R2076     2.1646265685558319e-01
    z[4,3,6]  R2077     2.5525358319282532e-01
    z[4,3,6]  R2078     -5.6083530187606812e-02
    z[4,3,6]  R2079     -3.8818728923797607e-01
    z[4,3,6]  R2080     -1.5079762041568756e-01
    z[4,3,6]  R2081     -8.9222088456153870e-02
    z[4,3,6]  R2082     -3.5436192154884338e-01
    z[4,3,6]  R2083     -1.9524197280406952e-01
    z[4,3,6]  R2084     -1.4552305638790131e-01
    z[4,3,6]  R2085     -6.1338496208190918e-01
    z[4,3,6]  R2086     -4.2719018459320068e-01
    z[4,3,6]  R2087     -1.6609518229961395e-01
    z[4,3,6]  R2088     -3.9867994189262390e-01
    z[4,3,6]  R2089     2.2725857794284821e-01
    z[4,3,6]  R2090     1.4063820242881775e-01
    z[4,3,6]  R2091     1.0753098130226135e-01
    z[4,3,6]  R2092     4.2588347196578979e-01
    z[4,3,6]  R2093     3.9786690473556519e-01
    z[4,3,6]  R2094     -2.3114077746868134e-01
    z[4,3,6]  R2095     -3.6359328031539917e-01
    z[4,3,6]  R2096     -3.9879478514194489e-02
    z[4,3,6]  R2097     1.8042442202568054e-01
    z[4,3,6]  R2098     -3.4936955571174622e-01
    z[4,3,6]  R2099     6.1725240200757980e-02
    z[4,3,6]  R2100     -6.5246790647506714e-02
    z[4,3,6]  R2101     -3.6207631230354309e-01
    z[4,3,6]  R2102     -1.3373765349388123e-01
    z[4,3,6]  R2103     4.3322015553712845e-02
    z[4,3,6]  R2104     -2.6974296569824219e-01
    z[4,3,6]  R2105     -3.0658626556396484e-01
    z[4,3,6]  R2106     -2.6294332742691040e-01
    z[4,3,6]  R2107     5.6234681606292725e-01
    z[4,3,6]  R2108     3.3876877278089523e-02
    z[4,3,6]  R2109     1.6584002971649170e-01
    z[4,3,6]  R2110     9.2581234872341156e-02
    z[4,3,6]  R2111     -3.0335170030593872e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2164     -1
    z[4,5,0]  R2165     1
    z[4,5,0]  R2178     -4.5848438143730164e-01
    z[4,5,0]  R2179     -8.3330410718917847e-01
    z[4,5,0]  R2180     -3.8666200637817383e-01
    z[4,5,0]  R2181     -1.9907087087631226e-01
    z[4,5,0]  R2182     -4.4714611768722534e-01
    z[4,5,0]  R2183     1.3753038644790649e-01
    z[4,5,0]  R2184     3.7897473573684692e-01
    z[4,5,0]  R2185     6.2275505065917969e-01
    z[4,5,0]  R2186     6.7475163936614990e-01
    z[4,5,0]  R2187     5.7183831930160522e-01
    z[4,5,0]  R2188     7.6425084844231606e-03
    z[4,5,0]  R2189     1.7630884051322937e-01
    z[4,5,0]  R2190     5.3241960704326630e-02
    z[4,5,0]  R2191     -1.9779168069362640e-02
    z[4,5,0]  R2192     4.3267560005187988e-01
    z[4,5,0]  R2193     0.529718279838562
    z[4,5,0]  R2194     4.0345376729965210e-01
    z[4,5,0]  R2195     1.3535985350608826e-01
    z[4,5,0]  R2196     0.340166836977005
    z[4,5,0]  R2197     7.4405074119567871e-02
    z[4,5,0]  R2198     -1.9793882966041565e-01
    z[4,5,0]  R2199     -1.9118184223771095e-02
    z[4,5,0]  R2200     -2.7381128072738647e-01
    z[4,5,0]  R2201     -1.2327007949352264e-01
    z[4,5,0]  R2202     -3.6031207442283630e-01
    z[4,5,0]  R2203     0.573261022567749
    z[4,5,0]  R2204     8.0649471282958984e-01
    z[4,5,0]  R2205     3.2313579320907593e-01
    z[4,5,0]  R2206     6.6625958681106567e-01
    z[4,5,0]  R2207     1.7175951600074768e-01
    z[4,5,0]  R2208     6.4163106679916382e-01
    z[4,5,0]  R2209     -4.7521561384201050e-01
    z[4,5,0]  R2210     3.3508926630020142e-02
    z[4,5,0]  R2211     -1.4299483597278595e-01
    z[4,5,0]  R2212     -1.6441199183464050e-01
    z[4,5,0]  R2213     -3.4808126091957092e-01
    z[4,5,0]  R2214     -4.0252998471260071e-01
    z[4,5,0]  R2215     -3.0971869826316833e-01
    z[4,5,0]  R2216     -3.2467669248580933e-01
    z[4,5,0]  R2217     -3.5864984989166260e-01
    z[4,5,0]  R2218     -5.7287907600402832e-01
    z[4,5,0]  R2219     -0.325132817029953
    z[4,5,0]  R2220     -4.0381217002868652e-01
    z[4,5,0]  R2221     -0.509609043598175
    z[4,5,0]  R2222     -5.1786619424819946e-01
    z[4,5,0]  R2223     6.9882661104202271e-01
    z[4,5,0]  R2224     -2.2907108068466187e-01
    z[4,5,0]  R2225     -2.9500603675842285e-01
    z[4,5,0]  R2226     5.8432853221893311e-01
    z[4,5,0]  R2227     4.8068276047706604e-01
    z[4,5,0]  R2228     -2.6974228024482727e-01
    z[4,5,0]  R2229     -4.0558192133903503e-01
    z[4,5,0]  R2230     4.4221732020378113e-01
    z[4,5,0]  R2231     4.6138077974319458e-01
    z[4,5,0]  R2232     3.5794076323509216e-01
    z[4,5,0]  R2233     2.1634428203105927e-01
    z[4,5,0]  R2234     -1.5749311447143555e-01
    z[4,5,0]  R2235     -1.0882386937737465e-02
    z[4,5,0]  R2236     2.3076352477073669e-01
    z[4,5,0]  R2237     4.3636098504066467e-01
    z[4,5,0]  R2238     1.2535629794001579e-02
    z[4,5,0]  R2239     3.6885414272546768e-02
    z[4,5,0]  R2240     5.5535793304443359e-01
    z[4,5,0]  R2241     -2.5221186876296997e-01
    z[4,5,0]  R2242     -3.3997863531112671e-02
    z[4,5,0]  R2243     6.9310680031776428e-02
    z[4,5,0]  R2244     -4.5445088297128677e-02
    z[4,5,0]  R2245     -1.1276463419198990e-01
    z[4,5,0]  R2246     1.2360639125108719e-01
    z[4,5,0]  R2247     2.7317786216735840e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2166     -1
    z[4,5,1]  R2167     1
    z[4,5,1]  R2178     5.8975040912628174e-01
    z[4,5,1]  R2179     -3.0199262499809265e-01
    z[4,5,1]  R2180     4.2183169722557068e-01
    z[4,5,1]  R2181     5.6619131565093994e-01
    z[4,5,1]  R2182     -0.187115877866745
    z[4,5,1]  R2183     -4.2707616090774536e-01
    z[4,5,1]  R2184     -0.341106116771698
    z[4,5,1]  R2185     -4.2832204699516296e-01
    z[4,5,1]  R2186     -0.382802814245224
    z[4,5,1]  R2187     -1.7089107632637024e-01
    z[4,5,1]  R2188     2.7923274040222168e-01
    z[4,5,1]  R2189     3.9075195789337158e-01
    z[4,5,1]  R2190     1.1419252306222916e-01
    z[4,5,1]  R2191     -8.4380501508712769e-01
    z[4,5,1]  R2192     7.0902770757675171e-01
    z[4,5,1]  R2193     -0.0634336769580841
    z[4,5,1]  R2194     -2.3554362356662750e-01
    z[4,5,1]  R2195     -2.5087940692901611e-01
    z[4,5,1]  R2196     6.6085916757583618e-01
    z[4,5,1]  R2197     -2.8801517561078072e-02
    z[4,5,1]  R2198     2.2513702511787415e-01
    z[4,5,1]  R2199     3.7106060981750488e-01
    z[4,5,1]  R2200     -8.3636589348316193e-02
    z[4,5,1]  R2201     -2.0240172743797302e-01
    z[4,5,1]  R2202     -2.1877533197402954e-01
    z[4,5,1]  R2203     -3.9691346883773804e-01
    z[4,5,1]  R2204     3.2836962491273880e-03
    z[4,5,1]  R2205     -1.2896490097045898e-01
    z[4,5,1]  R2206     -1.0529072955250740e-02
    z[4,5,1]  R2207     9.8508365452289581e-02
    z[4,5,1]  R2208     -1.1289706081151962e-01
    z[4,5,1]  R2209     -9.2442803084850311e-02
    z[4,5,1]  R2210     -1.4126157760620117e-01
    z[4,5,1]  R2211     -1.2021017074584961e-01
    z[4,5,1]  R2212     -1.6279260814189911e-01
    z[4,5,1]  R2213     -5.1551878452301025e-02
    z[4,5,1]  R2214     -1.0261062532663345e-01
    z[4,5,1]  R2215     -1.5986080467700958e-01
    z[4,5,1]  R2216     -8.5229448974132538e-02
    z[4,5,1]  R2217     -3.2290231436491013e-02
    z[4,5,1]  R2218     -6.7437601089477539e-01
    z[4,5,1]  R2219     -7.6250630617141724e-01
    z[4,5,1]  R2220     -6.2576764822006226e-01
    z[4,5,1]  R2221     -5.9989112615585327e-01
    z[4,5,1]  R2222     -5.3688186407089233e-01
    z[4,5,1]  R2223     4.8928743600845337e-01
    z[4,5,1]  R2224     -6.5893191099166870e-01
    z[4,5,1]  R2225     -5.7101702690124512e-01
    z[4,5,1]  R2226     1.2074148654937744e-01
    z[4,5,1]  R2227     -2.0272694528102875e-01
    z[4,5,1]  R2228     -7.5885915756225586e-01
    z[4,5,1]  R2229     -5.0641649961471558e-01
    z[4,5,1]  R2230     -3.5411059856414795e-01
    z[4,5,1]  R2231     -2.8774434700608253e-02
    z[4,5,1]  R2232     -4.1485038399696350e-01
    z[4,5,1]  R2233     -4.4661924242973328e-01
    z[4,5,1]  R2234     -7.0320534706115723e-01
    z[4,5,1]  R2235     -4.5102778077125549e-01
    z[4,5,1]  R2236     2.3100256919860840e-01
    z[4,5,1]  R2237     -2.1505138278007507e-01
    z[4,5,1]  R2238     -6.3967871665954590e-01
    z[4,5,1]  R2239     -4.1408398747444153e-01
    z[4,5,1]  R2240     0.520452618598938
    z[4,5,1]  R2241     -2.9941666126251221e-01
    z[4,5,1]  R2242     7.7732527256011963e-01
    z[4,5,1]  R2243     7.9937362670898438e-01
    z[4,5,1]  R2244     7.7364301681518555e-01
    z[4,5,1]  R2245     7.2622382640838623e-01
    z[4,5,1]  R2246     9.0468436479568481e-01
    z[4,5,1]  R2247     8.6709374189376831e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2168     -1
    z[4,5,2]  R2169     1
    z[4,5,2]  R2178     -5.6937170028686523e-01
    z[4,5,2]  R2179     -3.3548864722251892e-01
    z[4,5,2]  R2180     -1.4437523484230042e-01
    z[4,5,2]  R2181     -1.9146996736526489e-01
    z[4,5,2]  R2182     -1.9056263566017151e-01
    z[4,5,2]  R2183     3.4245607256889343e-01
    z[4,5,2]  R2184     0.211964413523674
    z[4,5,2]  R2185     3.5854774713516235e-01
    z[4,5,2]  R2186     3.7747806310653687e-01
    z[4,5,2]  R2187     1.7277404665946960e-01
    z[4,5,2]  R2188     5.6270472705364227e-02
    z[4,5,2]  R2189     6.1175487935543060e-02
    z[4,5,2]  R2190     6.2633596360683441e-02
    z[4,5,2]  R2191     3.6473387479782104e-01
    z[4,5,2]  R2192     4.6586093306541443e-01
    z[4,5,2]  R2193     4.9473071098327637e-01
    z[4,5,2]  R2194     8.7779097259044647e-02
    z[4,5,2]  R2195     -8.1706777215003967e-02
    z[4,5,2]  R2196     5.5561274290084839e-01
    z[4,5,2]  R2197     0.90269535779953
    z[4,5,2]  R2198     -2.4621029198169708e-01
    z[4,5,2]  R2199     9.7653055563569069e-03
    z[4,5,2]  R2200     -4.4117063283920288e-02
    z[4,5,2]  R2201     -5.2991036325693130e-02
    z[4,5,2]  R2202     1.3464756309986115e-01
    z[4,5,2]  R2203     5.7754433155059814e-01
    z[4,5,2]  R2204     4.4476282596588135e-01
    z[4,5,2]  R2205     0.648669958114624
    z[4,5,2]  R2206     4.4346186518669128e-01
    z[4,5,2]  R2207     7.2225689888000488e-01
    z[4,5,2]  R2208     1.0780003666877747e-01
    z[4,5,2]  R2209     7.3124116659164429e-01
    z[4,5,2]  R2210     5.7421612739562988e-01
    z[4,5,2]  R2211     7.2630625963211060e-01
    z[4,5,2]  R2212     8.1204974651336670e-01
    z[4,5,2]  R2213     7.5538033246994019e-01
    z[4,5,2]  R2214     5.9786844253540039e-01
    z[4,5,2]  R2215     2.2927477955818176e-01
    z[4,5,2]  R2216     4.9712011218070984e-01
    z[4,5,2]  R2217     6.6889148950576782e-01
    z[4,5,2]  R2218     -3.2046550512313843e-01
    z[4,5,2]  R2219     -3.7707009911537170e-01
    z[4,5,2]  R2220     -8.2286477088928223e-02
    z[4,5,2]  R2221     -1.0160498321056366e-01
    z[4,5,2]  R2222     -1.9210581481456757e-01
    z[4,5,2]  R2223     -8.3123147487640381e-02
    z[4,5,2]  R2224     1.7333178222179413e-01
    z[4,5,2]  R2225     -4.6031072735786438e-02
    z[4,5,2]  R2226     -1.3563394546508789e-01
    z[4,5,2]  R2227     -1.3572248630225658e-02
    z[4,5,2]  R2228     3.0794867873191833e-01
    z[4,5,2]  R2229     5.8678197860717773e-01
    z[4,5,2]  R2230     4.4368335604667664e-01
    z[4,5,2]  R2231     -1.2148012965917587e-01
    z[4,5,2]  R2232     -9.4842031598091125e-02
    z[4,5,2]  R2233     5.3951416164636612e-02
    z[4,5,2]  R2234     -2.4943840503692627e-01
    z[4,5,2]  R2235     3.0690962076187134e-01
    z[4,5,2]  R2236     -1.8194435536861420e-01
    z[4,5,2]  R2237     9.2556074261665344e-02
    z[4,5,2]  R2238     5.6087291240692139e-01
    z[4,5,2]  R2239     2.5920915603637695e-01
    z[4,5,2]  R2240     -5.2315410226583481e-02
    z[4,5,2]  R2241     -2.4299649894237518e-01
    z[4,5,2]  R2242     2.8462827205657959e-02
    z[4,5,2]  R2243     -7.9752728343009949e-02
    z[4,5,2]  R2244     -1.9546903669834137e-01
    z[4,5,2]  R2245     -1.6521067917346954e-01
    z[4,5,2]  R2246     2.1789493039250374e-02
    z[4,5,2]  R2247     -7.9349920153617859e-02
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2170     -1
    z[4,5,3]  R2171     1
    z[4,5,3]  R2178     -1.3295269571244717e-02
    z[4,5,3]  R2179     8.1346770748496056e-03
    z[4,5,3]  R2180     6.1704171821475029e-04
    z[4,5,3]  R2181     5.4796808958053589e-01
    z[4,5,3]  R2182     -1.8601444363594055e-01
    z[4,5,3]  R2183     4.6598574519157410e-01
    z[4,5,3]  R2184     6.8456375598907471e-01
    z[4,5,3]  R2185     3.7912562489509583e-01
    z[4,5,3]  R2186     4.2051178216934204e-01
    z[4,5,3]  R2187     7.0381826162338257e-01
    z[4,5,3]  R2188     -5.6691038608551025e-01
    z[4,5,3]  R2189     -8.9019864797592163e-01
    z[4,5,3]  R2190     -9.4144827127456665e-01
    z[4,5,3]  R2191     -2.9299971461296082e-01
    z[4,5,3]  R2192     -6.8816497921943665e-02
    z[4,5,3]  R2193     -7.7888399362564087e-02
    z[4,5,3]  R2194     -2.6586738228797913e-01
    z[4,5,3]  R2195     -3.8229238986968994e-01
    z[4,5,3]  R2196     -0.0145845552906394
    z[4,5,3]  R2197     5.6325122714042664e-02
    z[4,5,3]  R2198     -3.5785429179668427e-02
    z[4,5,3]  R2199     -6.5327733755111694e-01
    z[4,5,3]  R2200     -9.4674319028854370e-01
    z[4,5,3]  R2201     -0.876287579536438
    z[4,5,3]  R2202     -7.8395682573318481e-01
    z[4,5,3]  R2203     2.2759279608726501e-01
    z[4,5,3]  R2204     2.2771029174327850e-01
    z[4,5,3]  R2205     -3.8415189832448959e-02
    z[4,5,3]  R2206     -1.0041257739067078e-01
    z[4,5,3]  R2207     7.9403042793273926e-02
    z[4,5,3]  R2208     4.9130353331565857e-01
    z[4,5,3]  R2209     2.1447099745273590e-01
    z[4,5,3]  R2210     7.4778348207473755e-01
    z[4,5,3]  R2211     6.0457760095596313e-01
    z[4,5,3]  R2212     4.8526278138160706e-01
    z[4,5,3]  R2213     2.9882353544235229e-01
    z[4,5,3]  R2214     5.4019653797149658e-01
    z[4,5,3]  R2215     8.5413151979446411e-01
    z[4,5,3]  R2216     7.6380604505538940e-01
    z[4,5,3]  R2217     4.9203363060951233e-01
    z[4,5,3]  R2218     -2.7736705541610718e-01
    z[4,5,3]  R2219     -3.2460939884185791e-01
    z[4,5,3]  R2220     -4.0017729997634888e-01
    z[4,5,3]  R2221     -2.8906232118606567e-01
    z[4,5,3]  R2222     -2.9647415876388550e-01
    z[4,5,3]  R2223     -2.8446659445762634e-01
    z[4,5,3]  R2224     -3.8580140471458435e-01
    z[4,5,3]  R2225     -3.5557079315185547e-01
    z[4,5,3]  R2226     1.0866206884384155e-01
    z[4,5,3]  R2227     3.1090116500854492e-01
    z[4,5,3]  R2228     3.7762907147407532e-01
    z[4,5,3]  R2229     -2.8737068176269531e-01
    z[4,5,3]  R2230     -0.482251912355423
    z[4,5,3]  R2231     3.8285559415817261e-01
    z[4,5,3]  R2232     1.4088337123394012e-01
    z[4,5,3]  R2233     6.6598147153854370e-01
    z[4,5,3]  R2234     4.8683908581733704e-01
    z[4,5,3]  R2235     -1.5552611090242863e-02
    z[4,5,3]  R2236     5.3134995698928833e-01
    z[4,5,3]  R2237     -0.692699134349823
    z[4,5,3]  R2238     3.4966096282005310e-01
    z[4,5,3]  R2239     7.6672458648681641e-01
    z[4,5,3]  R2240     -1.5139228105545044e-01
    z[4,5,3]  R2241     1.5158000588417053e-01
    z[4,5,3]  R2242     -3.5130608081817627e-01
    z[4,5,3]  R2243     -2.8890445828437805e-01
    z[4,5,3]  R2244     -3.2266542315483093e-01
    z[4,5,3]  R2245     -4.8203226923942566e-01
    z[4,5,3]  R2246     -1.9956551492214203e-01
    z[4,5,3]  R2247     -2.9325437545776367e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2172     -1
    z[4,5,4]  R2173     1
    z[4,5,4]  R2178     8.1056252121925354e-02
    z[4,5,4]  R2179     0.142792746424675
    z[4,5,4]  R2180     -8.0507266521453857e-01
    z[4,5,4]  R2181     -3.9802014827728271e-01
    z[4,5,4]  R2182     -4.7465908527374268e-01
    z[4,5,4]  R2183     -0.537653386592865
    z[4,5,4]  R2184     1.2213263660669327e-01
    z[4,5,4]  R2185     3.2871001958847046e-01
    z[4,5,4]  R2186     2.1572580933570862e-01
    z[4,5,4]  R2187     2.4480944871902466e-01
    z[4,5,4]  R2188     2.8845849633216858e-01
    z[4,5,4]  R2189     -6.0820616781711578e-02
    z[4,5,4]  R2190     1.4904613792896271e-01
    z[4,5,4]  R2191     4.2433872818946838e-02
    z[4,5,4]  R2192     1.1020025610923767e-01
    z[4,5,4]  R2193     7.6562032103538513e-02
    z[4,5,4]  R2194     7.3388224840164185e-01
    z[4,5,4]  R2195     7.9327476024627686e-01
    z[4,5,4]  R2196     3.6913216114044189e-01
    z[4,5,4]  R2197     4.1980534791946411e-02
    z[4,5,4]  R2198     -2.2857272997498512e-02
    z[4,5,4]  R2199     -4.3017558753490448e-02
    z[4,5,4]  R2200     4.3811939656734467e-02
    z[4,5,4]  R2201     3.4191107749938965e-01
    z[4,5,4]  R2202     -3.9321768283843994e-01
    z[4,5,4]  R2203     -3.0978059768676758e-01
    z[4,5,4]  R2204     -2.4362166225910187e-01
    z[4,5,4]  R2205     -3.9132431149482727e-02
    z[4,5,4]  R2206     -1.7526191473007202e-01
    z[4,5,4]  R2207     1.3096977770328522e-01
    z[4,5,4]  R2208     -1.6896435990929604e-02
    z[4,5,4]  R2209     1.1893675476312637e-01
    z[4,5,4]  R2210     -2.3363986611366272e-01
    z[4,5,4]  R2211     5.6501183658838272e-02
    z[4,5,4]  R2212     9.9369265139102936e-02
    z[4,5,4]  R2213     -4.2273152619600296e-02
    z[4,5,4]  R2214     2.7650189399719238e-01
    z[4,5,4]  R2215     2.6277473568916321e-01
    z[4,5,4]  R2216     1.0319091379642487e-02
    z[4,5,4]  R2217     -2.1204583346843719e-01
    z[4,5,4]  R2218     -4.3894339352846146e-02
    z[4,5,4]  R2219     1.7493394017219543e-01
    z[4,5,4]  R2220     4.4317370653152466e-01
    z[4,5,4]  R2221     -4.9686712026596069e-01
    z[4,5,4]  R2222     -1.3466018438339233e-01
    z[4,5,4]  R2223     -2.9516938328742981e-01
    z[4,5,4]  R2224     -4.5699611306190491e-01
    z[4,5,4]  R2225     4.1366478800773621e-01
    z[4,5,4]  R2226     -6.9980108737945557e-01
    z[4,5,4]  R2227     6.1890256404876709e-01
    z[4,5,4]  R2228     1.2420323491096497e-01
    z[4,5,4]  R2229     2.1561962366104126e-01
    z[4,5,4]  R2230     -3.3257490396499634e-01
    z[4,5,4]  R2231     -6.7357122898101807e-01
    z[4,5,4]  R2232     -1.0187104344367981e-01
    z[4,5,4]  R2233     -3.2308768481016159e-02
    z[4,5,4]  R2234     -1.1614349484443665e-01
    z[4,5,4]  R2235     0.600644052028656
    z[4,5,4]  R2236     1.2698681652545929e-01
    z[4,5,4]  R2237     -1.6743943095207214e-01
    z[4,5,4]  R2238     -3.3669468760490417e-01
    z[4,5,4]  R2239     9.3967542052268982e-02
    z[4,5,4]  R2240     5.6981366872787476e-01
    z[4,5,4]  R2241     -6.8885219097137451e-01
    z[4,5,4]  R2242     3.9365351200103760e-01
    z[4,5,4]  R2243     4.3954676389694214e-01
    z[4,5,4]  R2244     3.0370175838470459e-01
    z[4,5,4]  R2245     2.0893611013889313e-01
    z[4,5,4]  R2246     2.5418680906295776e-01
    z[4,5,4]  R2247     2.1659302711486816e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2174     -1
    z[4,5,5]  R2175     1
    z[4,5,5]  R2178     -3.2239374518394470e-01
    z[4,5,5]  R2179     -2.5660082697868347e-01
    z[4,5,5]  R2180     1.2339268811047077e-02
    z[4,5,5]  R2181     9.2138200998306274e-02
    z[4,5,5]  R2182     -2.4084170162677765e-01
    z[4,5,5]  R2183     -4.0667504072189331e-01
    z[4,5,5]  R2184     -4.5615375041961670e-01
    z[4,5,5]  R2185     -5.0682887434959412e-02
    z[4,5,5]  R2186     -5.3031824529170990e-02
    z[4,5,5]  R2187     -3.7292614579200745e-02
    z[4,5,5]  R2188     1.4203681051731110e-01
    z[4,5,5]  R2189     8.4373086690902710e-02
    z[4,5,5]  R2190     -2.2015558183193207e-01
    z[4,5,5]  R2191     2.3934745788574219e-01
    z[4,5,5]  R2192     1.6793370246887207e-01
    z[4,5,5]  R2193     -5.6633424758911133e-01
    z[4,5,5]  R2194     3.3496430516242981e-01
    z[4,5,5]  R2195     2.1169048547744751e-01
    z[4,5,5]  R2196     -4.8653557896614075e-02
    z[4,5,5]  R2197     -4.1244491934776306e-01
    z[4,5,5]  R2198     8.6037427186965942e-01
    z[4,5,5]  R2199     5.9718143939971924e-01
    z[4,5,5]  R2200     -1.2719912827014923e-01
    z[4,5,5]  R2201     -6.2453597784042358e-03
    z[4,5,5]  R2202     1.5146744251251221e-01
    z[4,5,5]  R2203     1.6857126355171204e-01
    z[4,5,5]  R2204     1.3088262081146240e-01
    z[4,5,5]  R2205     -6.7186409235000610e-01
    z[4,5,5]  R2206     -5.4155224561691284e-01
    z[4,5,5]  R2207     -5.8668041229248047e-01
    z[4,5,5]  R2208     -5.6757771968841553e-01
    z[4,5,5]  R2209     -4.1100424528121948e-01
    z[4,5,5]  R2210     -2.3790072649717331e-02
    z[4,5,5]  R2211     -1.7221823334693909e-01
    z[4,5,5]  R2212     -1.4542511105537415e-01
    z[4,5,5]  R2213     -3.0688026547431946e-01
    z[4,5,5]  R2214     -3.0909284949302673e-01
    z[4,5,5]  R2215     -1.3321830332279205e-01
    z[4,5,5]  R2216     -2.3807440698146820e-01
    z[4,5,5]  R2217     -3.6323902010917664e-01
    z[4,5,5]  R2218     7.4424915015697479e-02
    z[4,5,5]  R2219     1.8276399374008179e-01
    z[4,5,5]  R2220     6.3236460089683533e-02
    z[4,5,5]  R2221     -1.7125536501407623e-01
    z[4,5,5]  R2222     -2.3346212506294250e-01
    z[4,5,5]  R2223     1.9256035983562469e-01
    z[4,5,5]  R2224     1.5108166635036469e-01
    z[4,5,5]  R2225     -2.0481450483202934e-02
    z[4,5,5]  R2226     3.4916028380393982e-01
    z[4,5,5]  R2227     4.9116128683090210e-01
    z[4,5,5]  R2228     3.1380828469991684e-02
    z[4,5,5]  R2229     0.325045645236969
    z[4,5,5]  R2230     2.6756852865219116e-01
    z[4,5,5]  R2231     -1.1562506854534149e-01
    z[4,5,5]  R2232     5.1794809103012085e-01
    z[4,5,5]  R2233     4.0950044989585876e-01
    z[4,5,5]  R2234     2.6671406626701355e-01
    z[4,5,5]  R2235     2.3218253254890442e-01
    z[4,5,5]  R2236     5.9344559907913208e-02
    z[4,5,5]  R2237     -4.8516458272933960e-01
    z[4,5,5]  R2238     1.5722188353538513e-01
    z[4,5,5]  R2239     1.4611233770847321e-01
    z[4,5,5]  R2240     -1.0686865448951721e-01
    z[4,5,5]  R2241     5.3440326452255249e-01
    z[4,5,5]  R2242     -3.2610318064689636e-01
    z[4,5,5]  R2243     -1.9234703481197357e-01
    z[4,5,5]  R2244     -3.1847196817398071e-01
    z[4,5,5]  R2245     -3.6189454793930054e-01
    z[4,5,5]  R2246     -2.4750418961048126e-01
    z[4,5,5]  R2247     -1.3576509058475494e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2176     -1
    z[4,5,6]  R2177     1
    z[4,5,6]  R2178     8.4367677569389343e-02
    z[4,5,6]  R2179     -1.2470804899930954e-01
    z[4,5,6]  R2180     -5.8409009128808975e-02
    z[4,5,6]  R2181     -3.6872607469558716e-01
    z[4,5,6]  R2182     6.4095747470855713e-01
    z[4,5,6]  R2183     -9.9079899489879608e-02
    z[4,5,6]  R2184     5.8955080807209015e-02
    z[4,5,6]  R2185     -2.1402002871036530e-01
    z[4,5,6]  R2186     1.7176277935504913e-01
    z[4,5,6]  R2187     2.3929831385612488e-01
    z[4,5,6]  R2188     -7.0287567377090454e-01
    z[4,5,6]  R2189     -9.5990262925624847e-02
    z[4,5,6]  R2190     -1.5229627490043640e-01
    z[4,5,6]  R2191     9.8155051469802856e-02
    z[4,5,6]  R2192     2.1900594234466553e-01
    z[4,5,6]  R2193     -3.7142071127891541e-01
    z[4,5,6]  R2194     2.2928024828433990e-01
    z[4,5,6]  R2195     3.0301153659820557e-01
    z[4,5,6]  R2196     2.7891201898455620e-03
    z[4,5,6]  R2197     6.1072193086147308e-02
    z[4,5,6]  R2198     3.2782158255577087e-01
    z[4,5,6]  R2199     -2.7677747607231140e-01
    z[4,5,6]  R2200     4.0796067565679550e-02
    z[4,5,6]  R2201     2.3708198964595795e-01
    z[4,5,6]  R2202     -1.0968913137912750e-01
    z[4,5,6]  R2203     -0.0639939159154892
    z[4,5,6]  R2204     1.5299607813358307e-01
    z[4,5,6]  R2205     6.1401624232530594e-02
    z[4,5,6]  R2206     -1.5890444815158844e-01
    z[4,5,6]  R2207     -2.6737222075462341e-01
    z[4,5,6]  R2208     -1.1574598029255867e-02
    z[4,5,6]  R2209     4.2924996465444565e-02
    z[4,5,6]  R2210     -1.8672055006027222e-01
    z[4,5,6]  R2211     -1.9802938401699066e-01
    z[4,5,6]  R2212     1.4331719279289246e-01
    z[4,5,6]  R2213     3.4687790274620056e-01
    z[4,5,6]  R2214     -7.8677006065845490e-02
    z[4,5,6]  R2215     -9.8048657178878784e-02
    z[4,5,6]  R2216     2.6403272058814764e-03
    z[4,5,6]  R2217     -6.2519580125808716e-02
    z[4,5,6]  R2218     1.7300352454185486e-01
    z[4,5,6]  R2219     -3.6265037953853607e-02
    z[4,5,6]  R2220     2.7934902906417847e-01
    z[4,5,6]  R2221     1.0170172154903412e-01
    z[4,5,6]  R2222     -4.9611786007881165e-01
    z[4,5,6]  R2223     2.4536505341529846e-01
    z[4,5,6]  R2224     -3.2058927416801453e-01
    z[4,5,6]  R2225     -5.3555899858474731e-01
    z[4,5,6]  R2226     4.6294897794723511e-02
    z[4,5,6]  R2227     -8.1990055739879608e-02
    z[4,5,6]  R2228     -3.1228914856910706e-01
    z[4,5,6]  R2229     2.0340059418231249e-03
    z[4,5,6]  R2230     -2.5967034697532654e-01
    z[4,5,6]  R2231     -3.9736205339431763e-01
    z[4,5,6]  R2232     6.2632775306701660e-01
    z[4,5,6]  R2233     3.7222284078598022e-01
    z[4,5,6]  R2234     3.1119233369827271e-01
    z[4,5,6]  R2235     5.3603923320770264e-01
    z[4,5,6]  R2236     -7.4719607830047607e-01
    z[4,5,6]  R2237     1.0734346508979797e-01
    z[4,5,6]  R2238     1.2542261183261871e-01
    z[4,5,6]  R2239     -3.7674814462661743e-01
    z[4,5,6]  R2240     -2.4277888238430023e-01
    z[4,5,6]  R2241     -6.7902550101280212e-02
    z[4,5,6]  R2242     -9.5274388790130615e-02
    z[4,5,6]  R2243     1.9019149243831635e-01
    z[4,5,6]  R2244     -2.5185507535934448e-01
    z[4,5,6]  R2245     -1.6003604233264923e-01
    z[4,5,6]  R2246     9.8591828718781471e-03
    z[4,5,6]  R2247     -1.2602771818637848e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2248     -1
    z[5,4,0]  R2249     1
    z[5,4,0]  R2262     6.4163106679916382e-01
    z[5,4,0]  R2263     -4.7521561384201050e-01
    z[5,4,0]  R2264     3.3508926630020142e-02
    z[5,4,0]  R2265     -1.4299483597278595e-01
    z[5,4,0]  R2266     -1.6441199183464050e-01
    z[5,4,0]  R2267     -3.4808126091957092e-01
    z[5,4,0]  R2268     -4.0252998471260071e-01
    z[5,4,0]  R2269     -3.0971869826316833e-01
    z[5,4,0]  R2270     -3.2467669248580933e-01
    z[5,4,0]  R2271     -3.5864984989166260e-01
    z[5,4,0]  R2272     -5.7287907600402832e-01
    z[5,4,0]  R2273     -0.325132817029953
    z[5,4,0]  R2274     -4.0381217002868652e-01
    z[5,4,0]  R2275     -0.509609043598175
    z[5,4,0]  R2276     -5.1786619424819946e-01
    z[5,4,0]  R2277     6.9882661104202271e-01
    z[5,4,0]  R2278     -2.2907108068466187e-01
    z[5,4,0]  R2279     -2.9500603675842285e-01
    z[5,4,0]  R2280     5.8432853221893311e-01
    z[5,4,0]  R2281     4.8068276047706604e-01
    z[5,4,0]  R2282     -2.6974228024482727e-01
    z[5,4,0]  R2283     -4.0558192133903503e-01
    z[5,4,0]  R2284     4.4221732020378113e-01
    z[5,4,0]  R2285     4.6138077974319458e-01
    z[5,4,0]  R2286     3.5794076323509216e-01
    z[5,4,0]  R2287     2.1634428203105927e-01
    z[5,4,0]  R2288     -1.5749311447143555e-01
    z[5,4,0]  R2289     -1.0882386937737465e-02
    z[5,4,0]  R2290     2.3076352477073669e-01
    z[5,4,0]  R2291     4.3636098504066467e-01
    z[5,4,0]  R2292     1.2535629794001579e-02
    z[5,4,0]  R2293     3.6885414272546768e-02
    z[5,4,0]  R2294     5.5535793304443359e-01
    z[5,4,0]  R2295     -2.5221186876296997e-01
    z[5,4,0]  R2296     -3.3997863531112671e-02
    z[5,4,0]  R2297     6.9310680031776428e-02
    z[5,4,0]  R2298     -4.5445088297128677e-02
    z[5,4,0]  R2299     -1.1276463419198990e-01
    z[5,4,0]  R2300     1.2360639125108719e-01
    z[5,4,0]  R2301     2.7317786216735840e-01
    z[5,4,0]  R2302     -4.5848438143730164e-01
    z[5,4,0]  R2303     -8.3330410718917847e-01
    z[5,4,0]  R2304     -3.8666200637817383e-01
    z[5,4,0]  R2305     -1.9907087087631226e-01
    z[5,4,0]  R2306     -4.4714611768722534e-01
    z[5,4,0]  R2307     1.3753038644790649e-01
    z[5,4,0]  R2308     3.7897473573684692e-01
    z[5,4,0]  R2309     6.2275505065917969e-01
    z[5,4,0]  R2310     6.7475163936614990e-01
    z[5,4,0]  R2311     5.7183831930160522e-01
    z[5,4,0]  R2312     7.6425084844231606e-03
    z[5,4,0]  R2313     1.7630884051322937e-01
    z[5,4,0]  R2314     5.3241960704326630e-02
    z[5,4,0]  R2315     -1.9779168069362640e-02
    z[5,4,0]  R2316     4.3267560005187988e-01
    z[5,4,0]  R2317     0.529718279838562
    z[5,4,0]  R2318     4.0345376729965210e-01
    z[5,4,0]  R2319     1.3535985350608826e-01
    z[5,4,0]  R2320     0.340166836977005
    z[5,4,0]  R2321     7.4405074119567871e-02
    z[5,4,0]  R2322     -1.9793882966041565e-01
    z[5,4,0]  R2323     -1.9118184223771095e-02
    z[5,4,0]  R2324     -2.7381128072738647e-01
    z[5,4,0]  R2325     -1.2327007949352264e-01
    z[5,4,0]  R2326     -3.6031207442283630e-01
    z[5,4,0]  R2327     0.573261022567749
    z[5,4,0]  R2328     8.0649471282958984e-01
    z[5,4,0]  R2329     3.2313579320907593e-01
    z[5,4,0]  R2330     6.6625958681106567e-01
    z[5,4,0]  R2331     1.7175951600074768e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2250     -1
    z[5,4,1]  R2251     1
    z[5,4,1]  R2262     -1.1289706081151962e-01
    z[5,4,1]  R2263     -9.2442803084850311e-02
    z[5,4,1]  R2264     -1.4126157760620117e-01
    z[5,4,1]  R2265     -1.2021017074584961e-01
    z[5,4,1]  R2266     -1.6279260814189911e-01
    z[5,4,1]  R2267     -5.1551878452301025e-02
    z[5,4,1]  R2268     -1.0261062532663345e-01
    z[5,4,1]  R2269     -1.5986080467700958e-01
    z[5,4,1]  R2270     -8.5229448974132538e-02
    z[5,4,1]  R2271     -3.2290231436491013e-02
    z[5,4,1]  R2272     -6.7437601089477539e-01
    z[5,4,1]  R2273     -7.6250630617141724e-01
    z[5,4,1]  R2274     -6.2576764822006226e-01
    z[5,4,1]  R2275     -5.9989112615585327e-01
    z[5,4,1]  R2276     -5.3688186407089233e-01
    z[5,4,1]  R2277     4.8928743600845337e-01
    z[5,4,1]  R2278     -6.5893191099166870e-01
    z[5,4,1]  R2279     -5.7101702690124512e-01
    z[5,4,1]  R2280     1.2074148654937744e-01
    z[5,4,1]  R2281     -2.0272694528102875e-01
    z[5,4,1]  R2282     -7.5885915756225586e-01
    z[5,4,1]  R2283     -5.0641649961471558e-01
    z[5,4,1]  R2284     -3.5411059856414795e-01
    z[5,4,1]  R2285     -2.8774434700608253e-02
    z[5,4,1]  R2286     -4.1485038399696350e-01
    z[5,4,1]  R2287     -4.4661924242973328e-01
    z[5,4,1]  R2288     -7.0320534706115723e-01
    z[5,4,1]  R2289     -4.5102778077125549e-01
    z[5,4,1]  R2290     2.3100256919860840e-01
    z[5,4,1]  R2291     -2.1505138278007507e-01
    z[5,4,1]  R2292     -6.3967871665954590e-01
    z[5,4,1]  R2293     -4.1408398747444153e-01
    z[5,4,1]  R2294     0.520452618598938
    z[5,4,1]  R2295     -2.9941666126251221e-01
    z[5,4,1]  R2296     7.7732527256011963e-01
    z[5,4,1]  R2297     7.9937362670898438e-01
    z[5,4,1]  R2298     7.7364301681518555e-01
    z[5,4,1]  R2299     7.2622382640838623e-01
    z[5,4,1]  R2300     9.0468436479568481e-01
    z[5,4,1]  R2301     8.6709374189376831e-01
    z[5,4,1]  R2302     5.8975040912628174e-01
    z[5,4,1]  R2303     -3.0199262499809265e-01
    z[5,4,1]  R2304     4.2183169722557068e-01
    z[5,4,1]  R2305     5.6619131565093994e-01
    z[5,4,1]  R2306     -0.187115877866745
    z[5,4,1]  R2307     -4.2707616090774536e-01
    z[5,4,1]  R2308     -0.341106116771698
    z[5,4,1]  R2309     -4.2832204699516296e-01
    z[5,4,1]  R2310     -0.382802814245224
    z[5,4,1]  R2311     -1.7089107632637024e-01
    z[5,4,1]  R2312     2.7923274040222168e-01
    z[5,4,1]  R2313     3.9075195789337158e-01
    z[5,4,1]  R2314     1.1419252306222916e-01
    z[5,4,1]  R2315     -8.4380501508712769e-01
    z[5,4,1]  R2316     7.0902770757675171e-01
    z[5,4,1]  R2317     -0.0634336769580841
    z[5,4,1]  R2318     -2.3554362356662750e-01
    z[5,4,1]  R2319     -2.5087940692901611e-01
    z[5,4,1]  R2320     6.6085916757583618e-01
    z[5,4,1]  R2321     -2.8801517561078072e-02
    z[5,4,1]  R2322     2.2513702511787415e-01
    z[5,4,1]  R2323     3.7106060981750488e-01
    z[5,4,1]  R2324     -8.3636589348316193e-02
    z[5,4,1]  R2325     -2.0240172743797302e-01
    z[5,4,1]  R2326     -2.1877533197402954e-01
    z[5,4,1]  R2327     -3.9691346883773804e-01
    z[5,4,1]  R2328     3.2836962491273880e-03
    z[5,4,1]  R2329     -1.2896490097045898e-01
    z[5,4,1]  R2330     -1.0529072955250740e-02
    z[5,4,1]  R2331     9.8508365452289581e-02
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2252     -1
    z[5,4,2]  R2253     1
    z[5,4,2]  R2262     1.0780003666877747e-01
    z[5,4,2]  R2263     7.3124116659164429e-01
    z[5,4,2]  R2264     5.7421612739562988e-01
    z[5,4,2]  R2265     7.2630625963211060e-01
    z[5,4,2]  R2266     8.1204974651336670e-01
    z[5,4,2]  R2267     7.5538033246994019e-01
    z[5,4,2]  R2268     5.9786844253540039e-01
    z[5,4,2]  R2269     2.2927477955818176e-01
    z[5,4,2]  R2270     4.9712011218070984e-01
    z[5,4,2]  R2271     6.6889148950576782e-01
    z[5,4,2]  R2272     -3.2046550512313843e-01
    z[5,4,2]  R2273     -3.7707009911537170e-01
    z[5,4,2]  R2274     -8.2286477088928223e-02
    z[5,4,2]  R2275     -1.0160498321056366e-01
    z[5,4,2]  R2276     -1.9210581481456757e-01
    z[5,4,2]  R2277     -8.3123147487640381e-02
    z[5,4,2]  R2278     1.7333178222179413e-01
    z[5,4,2]  R2279     -4.6031072735786438e-02
    z[5,4,2]  R2280     -1.3563394546508789e-01
    z[5,4,2]  R2281     -1.3572248630225658e-02
    z[5,4,2]  R2282     3.0794867873191833e-01
    z[5,4,2]  R2283     5.8678197860717773e-01
    z[5,4,2]  R2284     4.4368335604667664e-01
    z[5,4,2]  R2285     -1.2148012965917587e-01
    z[5,4,2]  R2286     -9.4842031598091125e-02
    z[5,4,2]  R2287     5.3951416164636612e-02
    z[5,4,2]  R2288     -2.4943840503692627e-01
    z[5,4,2]  R2289     3.0690962076187134e-01
    z[5,4,2]  R2290     -1.8194435536861420e-01
    z[5,4,2]  R2291     9.2556074261665344e-02
    z[5,4,2]  R2292     5.6087291240692139e-01
    z[5,4,2]  R2293     2.5920915603637695e-01
    z[5,4,2]  R2294     -5.2315410226583481e-02
    z[5,4,2]  R2295     -2.4299649894237518e-01
    z[5,4,2]  R2296     2.8462827205657959e-02
    z[5,4,2]  R2297     -7.9752728343009949e-02
    z[5,4,2]  R2298     -1.9546903669834137e-01
    z[5,4,2]  R2299     -1.6521067917346954e-01
    z[5,4,2]  R2300     2.1789493039250374e-02
    z[5,4,2]  R2301     -7.9349920153617859e-02
    z[5,4,2]  R2302     -5.6937170028686523e-01
    z[5,4,2]  R2303     -3.3548864722251892e-01
    z[5,4,2]  R2304     -1.4437523484230042e-01
    z[5,4,2]  R2305     -1.9146996736526489e-01
    z[5,4,2]  R2306     -1.9056263566017151e-01
    z[5,4,2]  R2307     3.4245607256889343e-01
    z[5,4,2]  R2308     0.211964413523674
    z[5,4,2]  R2309     3.5854774713516235e-01
    z[5,4,2]  R2310     3.7747806310653687e-01
    z[5,4,2]  R2311     1.7277404665946960e-01
    z[5,4,2]  R2312     5.6270472705364227e-02
    z[5,4,2]  R2313     6.1175487935543060e-02
    z[5,4,2]  R2314     6.2633596360683441e-02
    z[5,4,2]  R2315     3.6473387479782104e-01
    z[5,4,2]  R2316     4.6586093306541443e-01
    z[5,4,2]  R2317     4.9473071098327637e-01
    z[5,4,2]  R2318     8.7779097259044647e-02
    z[5,4,2]  R2319     -8.1706777215003967e-02
    z[5,4,2]  R2320     5.5561274290084839e-01
    z[5,4,2]  R2321     0.90269535779953
    z[5,4,2]  R2322     -2.4621029198169708e-01
    z[5,4,2]  R2323     9.7653055563569069e-03
    z[5,4,2]  R2324     -4.4117063283920288e-02
    z[5,4,2]  R2325     -5.2991036325693130e-02
    z[5,4,2]  R2326     1.3464756309986115e-01
    z[5,4,2]  R2327     5.7754433155059814e-01
    z[5,4,2]  R2328     4.4476282596588135e-01
    z[5,4,2]  R2329     0.648669958114624
    z[5,4,2]  R2330     4.4346186518669128e-01
    z[5,4,2]  R2331     7.2225689888000488e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2254     -1
    z[5,4,3]  R2255     1
    z[5,4,3]  R2262     4.9130353331565857e-01
    z[5,4,3]  R2263     2.1447099745273590e-01
    z[5,4,3]  R2264     7.4778348207473755e-01
    z[5,4,3]  R2265     6.0457760095596313e-01
    z[5,4,3]  R2266     4.8526278138160706e-01
    z[5,4,3]  R2267     2.9882353544235229e-01
    z[5,4,3]  R2268     5.4019653797149658e-01
    z[5,4,3]  R2269     8.5413151979446411e-01
    z[5,4,3]  R2270     7.6380604505538940e-01
    z[5,4,3]  R2271     4.9203363060951233e-01
    z[5,4,3]  R2272     -2.7736705541610718e-01
    z[5,4,3]  R2273     -3.2460939884185791e-01
    z[5,4,3]  R2274     -4.0017729997634888e-01
    z[5,4,3]  R2275     -2.8906232118606567e-01
    z[5,4,3]  R2276     -2.9647415876388550e-01
    z[5,4,3]  R2277     -2.8446659445762634e-01
    z[5,4,3]  R2278     -3.8580140471458435e-01
    z[5,4,3]  R2279     -3.5557079315185547e-01
    z[5,4,3]  R2280     1.0866206884384155e-01
    z[5,4,3]  R2281     3.1090116500854492e-01
    z[5,4,3]  R2282     3.7762907147407532e-01
    z[5,4,3]  R2283     -2.8737068176269531e-01
    z[5,4,3]  R2284     -0.482251912355423
    z[5,4,3]  R2285     3.8285559415817261e-01
    z[5,4,3]  R2286     1.4088337123394012e-01
    z[5,4,3]  R2287     6.6598147153854370e-01
    z[5,4,3]  R2288     4.8683908581733704e-01
    z[5,4,3]  R2289     -1.5552611090242863e-02
    z[5,4,3]  R2290     5.3134995698928833e-01
    z[5,4,3]  R2291     -0.692699134349823
    z[5,4,3]  R2292     3.4966096282005310e-01
    z[5,4,3]  R2293     7.6672458648681641e-01
    z[5,4,3]  R2294     -1.5139228105545044e-01
    z[5,4,3]  R2295     1.5158000588417053e-01
    z[5,4,3]  R2296     -3.5130608081817627e-01
    z[5,4,3]  R2297     -2.8890445828437805e-01
    z[5,4,3]  R2298     -3.2266542315483093e-01
    z[5,4,3]  R2299     -4.8203226923942566e-01
    z[5,4,3]  R2300     -1.9956551492214203e-01
    z[5,4,3]  R2301     -2.9325437545776367e-01
    z[5,4,3]  R2302     -1.3295269571244717e-02
    z[5,4,3]  R2303     8.1346770748496056e-03
    z[5,4,3]  R2304     6.1704171821475029e-04
    z[5,4,3]  R2305     5.4796808958053589e-01
    z[5,4,3]  R2306     -1.8601444363594055e-01
    z[5,4,3]  R2307     4.6598574519157410e-01
    z[5,4,3]  R2308     6.8456375598907471e-01
    z[5,4,3]  R2309     3.7912562489509583e-01
    z[5,4,3]  R2310     4.2051178216934204e-01
    z[5,4,3]  R2311     7.0381826162338257e-01
    z[5,4,3]  R2312     -5.6691038608551025e-01
    z[5,4,3]  R2313     -8.9019864797592163e-01
    z[5,4,3]  R2314     -9.4144827127456665e-01
    z[5,4,3]  R2315     -2.9299971461296082e-01
    z[5,4,3]  R2316     -6.8816497921943665e-02
    z[5,4,3]  R2317     -7.7888399362564087e-02
    z[5,4,3]  R2318     -2.6586738228797913e-01
    z[5,4,3]  R2319     -3.8229238986968994e-01
    z[5,4,3]  R2320     -0.0145845552906394
    z[5,4,3]  R2321     5.6325122714042664e-02
    z[5,4,3]  R2322     -3.5785429179668427e-02
    z[5,4,3]  R2323     -6.5327733755111694e-01
    z[5,4,3]  R2324     -9.4674319028854370e-01
    z[5,4,3]  R2325     -0.876287579536438
    z[5,4,3]  R2326     -7.8395682573318481e-01
    z[5,4,3]  R2327     2.2759279608726501e-01
    z[5,4,3]  R2328     2.2771029174327850e-01
    z[5,4,3]  R2329     -3.8415189832448959e-02
    z[5,4,3]  R2330     -1.0041257739067078e-01
    z[5,4,3]  R2331     7.9403042793273926e-02
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2256     -1
    z[5,4,4]  R2257     1
    z[5,4,4]  R2262     -1.6896435990929604e-02
    z[5,4,4]  R2263     1.1893675476312637e-01
    z[5,4,4]  R2264     -2.3363986611366272e-01
    z[5,4,4]  R2265     5.6501183658838272e-02
    z[5,4,4]  R2266     9.9369265139102936e-02
    z[5,4,4]  R2267     -4.2273152619600296e-02
    z[5,4,4]  R2268     2.7650189399719238e-01
    z[5,4,4]  R2269     2.6277473568916321e-01
    z[5,4,4]  R2270     1.0319091379642487e-02
    z[5,4,4]  R2271     -2.1204583346843719e-01
    z[5,4,4]  R2272     -4.3894339352846146e-02
    z[5,4,4]  R2273     1.7493394017219543e-01
    z[5,4,4]  R2274     4.4317370653152466e-01
    z[5,4,4]  R2275     -4.9686712026596069e-01
    z[5,4,4]  R2276     -1.3466018438339233e-01
    z[5,4,4]  R2277     -2.9516938328742981e-01
    z[5,4,4]  R2278     -4.5699611306190491e-01
    z[5,4,4]  R2279     4.1366478800773621e-01
    z[5,4,4]  R2280     -6.9980108737945557e-01
    z[5,4,4]  R2281     6.1890256404876709e-01
    z[5,4,4]  R2282     1.2420323491096497e-01
    z[5,4,4]  R2283     2.1561962366104126e-01
    z[5,4,4]  R2284     -3.3257490396499634e-01
    z[5,4,4]  R2285     -6.7357122898101807e-01
    z[5,4,4]  R2286     -1.0187104344367981e-01
    z[5,4,4]  R2287     -3.2308768481016159e-02
    z[5,4,4]  R2288     -1.1614349484443665e-01
    z[5,4,4]  R2289     0.600644052028656
    z[5,4,4]  R2290     1.2698681652545929e-01
    z[5,4,4]  R2291     -1.6743943095207214e-01
    z[5,4,4]  R2292     -3.3669468760490417e-01
    z[5,4,4]  R2293     9.3967542052268982e-02
    z[5,4,4]  R2294     5.6981366872787476e-01
    z[5,4,4]  R2295     -6.8885219097137451e-01
    z[5,4,4]  R2296     3.9365351200103760e-01
    z[5,4,4]  R2297     4.3954676389694214e-01
    z[5,4,4]  R2298     3.0370175838470459e-01
    z[5,4,4]  R2299     2.0893611013889313e-01
    z[5,4,4]  R2300     2.5418680906295776e-01
    z[5,4,4]  R2301     2.1659302711486816e-01
    z[5,4,4]  R2302     8.1056252121925354e-02
    z[5,4,4]  R2303     0.142792746424675
    z[5,4,4]  R2304     -8.0507266521453857e-01
    z[5,4,4]  R2305     -3.9802014827728271e-01
    z[5,4,4]  R2306     -4.7465908527374268e-01
    z[5,4,4]  R2307     -0.537653386592865
    z[5,4,4]  R2308     1.2213263660669327e-01
    z[5,4,4]  R2309     3.2871001958847046e-01
    z[5,4,4]  R2310     2.1572580933570862e-01
    z[5,4,4]  R2311     2.4480944871902466e-01
    z[5,4,4]  R2312     2.8845849633216858e-01
    z[5,4,4]  R2313     -6.0820616781711578e-02
    z[5,4,4]  R2314     1.4904613792896271e-01
    z[5,4,4]  R2315     4.2433872818946838e-02
    z[5,4,4]  R2316     1.1020025610923767e-01
    z[5,4,4]  R2317     7.6562032103538513e-02
    z[5,4,4]  R2318     7.3388224840164185e-01
    z[5,4,4]  R2319     7.9327476024627686e-01
    z[5,4,4]  R2320     3.6913216114044189e-01
    z[5,4,4]  R2321     4.1980534791946411e-02
    z[5,4,4]  R2322     -2.2857272997498512e-02
    z[5,4,4]  R2323     -4.3017558753490448e-02
    z[5,4,4]  R2324     4.3811939656734467e-02
    z[5,4,4]  R2325     3.4191107749938965e-01
    z[5,4,4]  R2326     -3.9321768283843994e-01
    z[5,4,4]  R2327     -3.0978059768676758e-01
    z[5,4,4]  R2328     -2.4362166225910187e-01
    z[5,4,4]  R2329     -3.9132431149482727e-02
    z[5,4,4]  R2330     -1.7526191473007202e-01
    z[5,4,4]  R2331     1.3096977770328522e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2258     -1
    z[5,4,5]  R2259     1
    z[5,4,5]  R2262     -5.6757771968841553e-01
    z[5,4,5]  R2263     -4.1100424528121948e-01
    z[5,4,5]  R2264     -2.3790072649717331e-02
    z[5,4,5]  R2265     -1.7221823334693909e-01
    z[5,4,5]  R2266     -1.4542511105537415e-01
    z[5,4,5]  R2267     -3.0688026547431946e-01
    z[5,4,5]  R2268     -3.0909284949302673e-01
    z[5,4,5]  R2269     -1.3321830332279205e-01
    z[5,4,5]  R2270     -2.3807440698146820e-01
    z[5,4,5]  R2271     -3.6323902010917664e-01
    z[5,4,5]  R2272     7.4424915015697479e-02
    z[5,4,5]  R2273     1.8276399374008179e-01
    z[5,4,5]  R2274     6.3236460089683533e-02
    z[5,4,5]  R2275     -1.7125536501407623e-01
    z[5,4,5]  R2276     -2.3346212506294250e-01
    z[5,4,5]  R2277     1.9256035983562469e-01
    z[5,4,5]  R2278     1.5108166635036469e-01
    z[5,4,5]  R2279     -2.0481450483202934e-02
    z[5,4,5]  R2280     3.4916028380393982e-01
    z[5,4,5]  R2281     4.9116128683090210e-01
    z[5,4,5]  R2282     3.1380828469991684e-02
    z[5,4,5]  R2283     0.325045645236969
    z[5,4,5]  R2284     2.6756852865219116e-01
    z[5,4,5]  R2285     -1.1562506854534149e-01
    z[5,4,5]  R2286     5.1794809103012085e-01
    z[5,4,5]  R2287     4.0950044989585876e-01
    z[5,4,5]  R2288     2.6671406626701355e-01
    z[5,4,5]  R2289     2.3218253254890442e-01
    z[5,4,5]  R2290     5.9344559907913208e-02
    z[5,4,5]  R2291     -4.8516458272933960e-01
    z[5,4,5]  R2292     1.5722188353538513e-01
    z[5,4,5]  R2293     1.4611233770847321e-01
    z[5,4,5]  R2294     -1.0686865448951721e-01
    z[5,4,5]  R2295     5.3440326452255249e-01
    z[5,4,5]  R2296     -3.2610318064689636e-01
    z[5,4,5]  R2297     -1.9234703481197357e-01
    z[5,4,5]  R2298     -3.1847196817398071e-01
    z[5,4,5]  R2299     -3.6189454793930054e-01
    z[5,4,5]  R2300     -2.4750418961048126e-01
    z[5,4,5]  R2301     -1.3576509058475494e-01
    z[5,4,5]  R2302     -3.2239374518394470e-01
    z[5,4,5]  R2303     -2.5660082697868347e-01
    z[5,4,5]  R2304     1.2339268811047077e-02
    z[5,4,5]  R2305     9.2138200998306274e-02
    z[5,4,5]  R2306     -2.4084170162677765e-01
    z[5,4,5]  R2307     -4.0667504072189331e-01
    z[5,4,5]  R2308     -4.5615375041961670e-01
    z[5,4,5]  R2309     -5.0682887434959412e-02
    z[5,4,5]  R2310     -5.3031824529170990e-02
    z[5,4,5]  R2311     -3.7292614579200745e-02
    z[5,4,5]  R2312     1.4203681051731110e-01
    z[5,4,5]  R2313     8.4373086690902710e-02
    z[5,4,5]  R2314     -2.2015558183193207e-01
    z[5,4,5]  R2315     2.3934745788574219e-01
    z[5,4,5]  R2316     1.6793370246887207e-01
    z[5,4,5]  R2317     -5.6633424758911133e-01
    z[5,4,5]  R2318     3.3496430516242981e-01
    z[5,4,5]  R2319     2.1169048547744751e-01
    z[5,4,5]  R2320     -4.8653557896614075e-02
    z[5,4,5]  R2321     -4.1244491934776306e-01
    z[5,4,5]  R2322     8.6037427186965942e-01
    z[5,4,5]  R2323     5.9718143939971924e-01
    z[5,4,5]  R2324     -1.2719912827014923e-01
    z[5,4,5]  R2325     -6.2453597784042358e-03
    z[5,4,5]  R2326     1.5146744251251221e-01
    z[5,4,5]  R2327     1.6857126355171204e-01
    z[5,4,5]  R2328     1.3088262081146240e-01
    z[5,4,5]  R2329     -6.7186409235000610e-01
    z[5,4,5]  R2330     -5.4155224561691284e-01
    z[5,4,5]  R2331     -5.8668041229248047e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2260     -1
    z[5,4,6]  R2261     1
    z[5,4,6]  R2262     -1.1574598029255867e-02
    z[5,4,6]  R2263     4.2924996465444565e-02
    z[5,4,6]  R2264     -1.8672055006027222e-01
    z[5,4,6]  R2265     -1.9802938401699066e-01
    z[5,4,6]  R2266     1.4331719279289246e-01
    z[5,4,6]  R2267     3.4687790274620056e-01
    z[5,4,6]  R2268     -7.8677006065845490e-02
    z[5,4,6]  R2269     -9.8048657178878784e-02
    z[5,4,6]  R2270     2.6403272058814764e-03
    z[5,4,6]  R2271     -6.2519580125808716e-02
    z[5,4,6]  R2272     1.7300352454185486e-01
    z[5,4,6]  R2273     -3.6265037953853607e-02
    z[5,4,6]  R2274     2.7934902906417847e-01
    z[5,4,6]  R2275     1.0170172154903412e-01
    z[5,4,6]  R2276     -4.9611786007881165e-01
    z[5,4,6]  R2277     2.4536505341529846e-01
    z[5,4,6]  R2278     -3.2058927416801453e-01
    z[5,4,6]  R2279     -5.3555899858474731e-01
    z[5,4,6]  R2280     4.6294897794723511e-02
    z[5,4,6]  R2281     -8.1990055739879608e-02
    z[5,4,6]  R2282     -3.1228914856910706e-01
    z[5,4,6]  R2283     2.0340059418231249e-03
    z[5,4,6]  R2284     -2.5967034697532654e-01
    z[5,4,6]  R2285     -3.9736205339431763e-01
    z[5,4,6]  R2286     6.2632775306701660e-01
    z[5,4,6]  R2287     3.7222284078598022e-01
    z[5,4,6]  R2288     3.1119233369827271e-01
    z[5,4,6]  R2289     5.3603923320770264e-01
    z[5,4,6]  R2290     -7.4719607830047607e-01
    z[5,4,6]  R2291     1.0734346508979797e-01
    z[5,4,6]  R2292     1.2542261183261871e-01
    z[5,4,6]  R2293     -3.7674814462661743e-01
    z[5,4,6]  R2294     -2.4277888238430023e-01
    z[5,4,6]  R2295     -6.7902550101280212e-02
    z[5,4,6]  R2296     -9.5274388790130615e-02
    z[5,4,6]  R2297     1.9019149243831635e-01
    z[5,4,6]  R2298     -2.5185507535934448e-01
    z[5,4,6]  R2299     -1.6003604233264923e-01
    z[5,4,6]  R2300     9.8591828718781471e-03
    z[5,4,6]  R2301     -1.2602771818637848e-01
    z[5,4,6]  R2302     8.4367677569389343e-02
    z[5,4,6]  R2303     -1.2470804899930954e-01
    z[5,4,6]  R2304     -5.8409009128808975e-02
    z[5,4,6]  R2305     -3.6872607469558716e-01
    z[5,4,6]  R2306     6.4095747470855713e-01
    z[5,4,6]  R2307     -9.9079899489879608e-02
    z[5,4,6]  R2308     5.8955080807209015e-02
    z[5,4,6]  R2309     -2.1402002871036530e-01
    z[5,4,6]  R2310     1.7176277935504913e-01
    z[5,4,6]  R2311     2.3929831385612488e-01
    z[5,4,6]  R2312     -7.0287567377090454e-01
    z[5,4,6]  R2313     -9.5990262925624847e-02
    z[5,4,6]  R2314     -1.5229627490043640e-01
    z[5,4,6]  R2315     9.8155051469802856e-02
    z[5,4,6]  R2316     2.1900594234466553e-01
    z[5,4,6]  R2317     -3.7142071127891541e-01
    z[5,4,6]  R2318     2.2928024828433990e-01
    z[5,4,6]  R2319     3.0301153659820557e-01
    z[5,4,6]  R2320     2.7891201898455620e-03
    z[5,4,6]  R2321     6.1072193086147308e-02
    z[5,4,6]  R2322     3.2782158255577087e-01
    z[5,4,6]  R2323     -2.7677747607231140e-01
    z[5,4,6]  R2324     4.0796067565679550e-02
    z[5,4,6]  R2325     2.3708198964595795e-01
    z[5,4,6]  R2326     -1.0968913137912750e-01
    z[5,4,6]  R2327     -0.0639939159154892
    z[5,4,6]  R2328     1.5299607813358307e-01
    z[5,4,6]  R2329     6.1401624232530594e-02
    z[5,4,6]  R2330     -1.5890444815158844e-01
    z[5,4,6]  R2331     -2.6737222075462341e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2332     -1
    z[5,6,0]  R2333     1
    z[5,6,0]  R2346     6.4163106679916382e-01
    z[5,6,0]  R2347     -4.7521561384201050e-01
    z[5,6,0]  R2348     3.3508926630020142e-02
    z[5,6,0]  R2349     -1.4299483597278595e-01
    z[5,6,0]  R2350     -1.6441199183464050e-01
    z[5,6,0]  R2351     -3.4808126091957092e-01
    z[5,6,0]  R2352     -4.0252998471260071e-01
    z[5,6,0]  R2353     -3.0971869826316833e-01
    z[5,6,0]  R2354     -3.2467669248580933e-01
    z[5,6,0]  R2355     -3.5864984989166260e-01
    z[5,6,0]  R2356     -5.7287907600402832e-01
    z[5,6,0]  R2357     -0.325132817029953
    z[5,6,0]  R2358     -4.0381217002868652e-01
    z[5,6,0]  R2359     -0.509609043598175
    z[5,6,0]  R2360     -5.1786619424819946e-01
    z[5,6,0]  R2361     6.9882661104202271e-01
    z[5,6,0]  R2362     -2.2907108068466187e-01
    z[5,6,0]  R2363     -2.9500603675842285e-01
    z[5,6,0]  R2364     5.8432853221893311e-01
    z[5,6,0]  R2365     4.8068276047706604e-01
    z[5,6,0]  R2366     -2.6974228024482727e-01
    z[5,6,0]  R2367     -4.0558192133903503e-01
    z[5,6,0]  R2368     4.4221732020378113e-01
    z[5,6,0]  R2369     4.6138077974319458e-01
    z[5,6,0]  R2370     3.5794076323509216e-01
    z[5,6,0]  R2371     2.1634428203105927e-01
    z[5,6,0]  R2372     -1.5749311447143555e-01
    z[5,6,0]  R2373     -1.0882386937737465e-02
    z[5,6,0]  R2374     2.3076352477073669e-01
    z[5,6,0]  R2375     4.3636098504066467e-01
    z[5,6,0]  R2376     1.2535629794001579e-02
    z[5,6,0]  R2377     3.6885414272546768e-02
    z[5,6,0]  R2378     5.5535793304443359e-01
    z[5,6,0]  R2379     -2.5221186876296997e-01
    z[5,6,0]  R2380     -3.3997863531112671e-02
    z[5,6,0]  R2381     6.9310680031776428e-02
    z[5,6,0]  R2382     -4.5445088297128677e-02
    z[5,6,0]  R2383     -1.1276463419198990e-01
    z[5,6,0]  R2384     1.2360639125108719e-01
    z[5,6,0]  R2385     2.7317786216735840e-01
    z[5,6,0]  R2386     -5.9604984521865845e-01
    z[5,6,0]  R2387     -5.9519636631011963e-01
    z[5,6,0]  R2388     -5.4555088281631470e-01
    z[5,6,0]  R2389     -9.0853029489517212e-01
    z[5,6,0]  R2390     2.1695900708436966e-02
    z[5,6,0]  R2391     1.8270808458328247e-01
    z[5,6,0]  R2392     4.5938470959663391e-01
    z[5,6,0]  R2393     2.2123923897743225e-01
    z[5,6,0]  R2394     2.5043913722038269e-01
    z[5,6,0]  R2395     1.3056947290897369e-01
    z[5,6,0]  R2396     9.0998277068138123e-02
    z[5,6,0]  R2397     8.4450000524520874e-01
    z[5,6,0]  R2398     -2.1525566279888153e-01
    z[5,6,0]  R2399     8.5323905944824219e-01
    z[5,6,0]  R2400     7.9332852363586426e-01
    z[5,6,0]  R2401     9.4393032789230347e-01
    z[5,6,0]  R2402     7.9634547233581543e-01
    z[5,6,0]  R2403     4.2133647203445435e-01
    z[5,6,0]  R2404     5.4325199127197266e-01
    z[5,6,0]  R2405     0.753872811794281
    z[5,6,0]  R2406     -6.5286658704280853e-02
    z[5,6,0]  R2407     1.0219974815845490e-01
    z[5,6,0]  R2408     -1.2452743202447891e-01
    z[5,6,0]  R2409     2.6733890175819397e-01
    z[5,6,0]  R2410     -9.9125787615776062e-02
    z[5,6,0]  R2411     -2.6458343863487244e-01
    z[5,6,0]  R2412     0.359305739402771
    z[5,6,0]  R2413     4.0368229150772095e-01
    z[5,6,0]  R2414     3.5545936226844788e-01
    z[5,6,0]  R2415     5.5241298675537109e-01
    z[5,6,0]  R2416     2.7959239482879639e-01
    z[5,6,0]  R2417     -1.3251301646232605e-01
    z[5,6,0]  R2418     -4.3608862161636353e-01
    z[5,6,0]  R2419     6.5889185667037964e-01
    z[5,6,0]  R2420     4.6117383241653442e-01
    z[5,6,0]  R2421     4.0184545516967773e-01
    z[5,6,0]  R2422     6.4642888307571411e-01
    z[5,6,0]  R2423     6.0211783647537231e-01
    z[5,6,0]  R2424     6.4304113388061523e-01
    z[5,6,0]  R2425     6.8500363826751709e-01
    z[5,6,0]  R2426     -4.5201104879379272e-01
    z[5,6,0]  R2427     -3.3013510704040527e-01
    z[5,6,0]  R2428     7.2771143913269043e-01
    z[5,6,0]  R2429     7.1268713474273682e-01
    z[5,6,0]  R2430     5.4694259166717529e-01
    z[5,6,0]  R2431     8.4359234571456909e-01
    z[5,6,0]  R2432     4.8151209950447083e-01
    z[5,6,0]  R2433     6.5796029567718506e-01
    z[5,6,0]  R2434     2.9971030354499817e-01
    z[5,6,0]  R2435     6.5436176955699921e-02
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2334     -1
    z[5,6,1]  R2335     1
    z[5,6,1]  R2346     -1.1289706081151962e-01
    z[5,6,1]  R2347     -9.2442803084850311e-02
    z[5,6,1]  R2348     -1.4126157760620117e-01
    z[5,6,1]  R2349     -1.2021017074584961e-01
    z[5,6,1]  R2350     -1.6279260814189911e-01
    z[5,6,1]  R2351     -5.1551878452301025e-02
    z[5,6,1]  R2352     -1.0261062532663345e-01
    z[5,6,1]  R2353     -1.5986080467700958e-01
    z[5,6,1]  R2354     -8.5229448974132538e-02
    z[5,6,1]  R2355     -3.2290231436491013e-02
    z[5,6,1]  R2356     -6.7437601089477539e-01
    z[5,6,1]  R2357     -7.6250630617141724e-01
    z[5,6,1]  R2358     -6.2576764822006226e-01
    z[5,6,1]  R2359     -5.9989112615585327e-01
    z[5,6,1]  R2360     -5.3688186407089233e-01
    z[5,6,1]  R2361     4.8928743600845337e-01
    z[5,6,1]  R2362     -6.5893191099166870e-01
    z[5,6,1]  R2363     -5.7101702690124512e-01
    z[5,6,1]  R2364     1.2074148654937744e-01
    z[5,6,1]  R2365     -2.0272694528102875e-01
    z[5,6,1]  R2366     -7.5885915756225586e-01
    z[5,6,1]  R2367     -5.0641649961471558e-01
    z[5,6,1]  R2368     -3.5411059856414795e-01
    z[5,6,1]  R2369     -2.8774434700608253e-02
    z[5,6,1]  R2370     -4.1485038399696350e-01
    z[5,6,1]  R2371     -4.4661924242973328e-01
    z[5,6,1]  R2372     -7.0320534706115723e-01
    z[5,6,1]  R2373     -4.5102778077125549e-01
    z[5,6,1]  R2374     2.3100256919860840e-01
    z[5,6,1]  R2375     -2.1505138278007507e-01
    z[5,6,1]  R2376     -6.3967871665954590e-01
    z[5,6,1]  R2377     -4.1408398747444153e-01
    z[5,6,1]  R2378     0.520452618598938
    z[5,6,1]  R2379     -2.9941666126251221e-01
    z[5,6,1]  R2380     7.7732527256011963e-01
    z[5,6,1]  R2381     7.9937362670898438e-01
    z[5,6,1]  R2382     7.7364301681518555e-01
    z[5,6,1]  R2383     7.2622382640838623e-01
    z[5,6,1]  R2384     9.0468436479568481e-01
    z[5,6,1]  R2385     8.6709374189376831e-01
    z[5,6,1]  R2386     0.276196151971817
    z[5,6,1]  R2387     2.2301610559225082e-02
    z[5,6,1]  R2388     -3.1388025730848312e-02
    z[5,6,1]  R2389     1.5112218260765076e-01
    z[5,6,1]  R2390     9.1509366035461426e-01
    z[5,6,1]  R2391     0.881537914276123
    z[5,6,1]  R2392     1.0335970669984818e-01
    z[5,6,1]  R2393     8.0878442525863647e-01
    z[5,6,1]  R2394     7.6376211643218994e-01
    z[5,6,1]  R2395     7.0217174291610718e-01
    z[5,6,1]  R2396     -7.9451489448547363e-01
    z[5,6,1]  R2397     1.0510198026895523e-01
    z[5,6,1]  R2398     -5.9090346097946167e-01
    z[5,6,1]  R2399     -1.1415301263332367e-01
    z[5,6,1]  R2400     -3.4486210346221924e-01
    z[5,6,1]  R2401     -1.0071279853582382e-01
    z[5,6,1]  R2402     -1.9674836099147797e-01
    z[5,6,1]  R2403     -0.521199107170105
    z[5,6,1]  R2404     -5.0083076953887939e-01
    z[5,6,1]  R2405     4.4286736845970154e-01
    z[5,6,1]  R2406     -9.1140103340148926e-01
    z[5,6,1]  R2407     -8.2444530725479126e-01
    z[5,6,1]  R2408     -7.8273254632949829e-01
    z[5,6,1]  R2409     -7.1847504377365112e-01
    z[5,6,1]  R2410     -7.4615907669067383e-01
    z[5,6,1]  R2411     -6.5173190832138062e-01
    z[5,6,1]  R2412     2.8385114669799805e-01
    z[5,6,1]  R2413     5.0374716520309448e-01
    z[5,6,1]  R2414     -0.191203311085701
    z[5,6,1]  R2415     -5.3746816702187061e-03
    z[5,6,1]  R2416     -9.3310713768005371e-01
    z[5,6,1]  R2417     -5.7585853338241577e-01
    z[5,6,1]  R2418     -6.1612749099731445e-01
    z[5,6,1]  R2419     -2.1015946567058563e-01
    z[5,6,1]  R2420     3.3841848373413086e-02
    z[5,6,1]  R2421     -4.7460398077964783e-01
    z[5,6,1]  R2422     4.4044005870819092e-01
    z[5,6,1]  R2423     8.6261585354804993e-02
    z[5,6,1]  R2424     4.5362392067909241e-01
    z[5,6,1]  R2425     4.5255038142204285e-01
    z[5,6,1]  R2426     -0.754883885383606
    z[5,6,1]  R2427     -7.4834233522415161e-01
    z[5,6,1]  R2428     -1.6699890792369843e-01
    z[5,6,1]  R2429     -0.0396428182721138
    z[5,6,1]  R2430     -1.9857594370841980e-01
    z[5,6,1]  R2431     2.6120641827583313e-01
    z[5,6,1]  R2432     1.9385293126106262e-01
    z[5,6,1]  R2433     1.2686505913734436e-01
    z[5,6,1]  R2434     2.9744756221771240e-01
    z[5,6,1]  R2435     8.9126682281494141e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2336     -1
    z[5,6,2]  R2337     1
    z[5,6,2]  R2346     1.0780003666877747e-01
    z[5,6,2]  R2347     7.3124116659164429e-01
    z[5,6,2]  R2348     5.7421612739562988e-01
    z[5,6,2]  R2349     7.2630625963211060e-01
    z[5,6,2]  R2350     8.1204974651336670e-01
    z[5,6,2]  R2351     7.5538033246994019e-01
    z[5,6,2]  R2352     5.9786844253540039e-01
    z[5,6,2]  R2353     2.2927477955818176e-01
    z[5,6,2]  R2354     4.9712011218070984e-01
    z[5,6,2]  R2355     6.6889148950576782e-01
    z[5,6,2]  R2356     -3.2046550512313843e-01
    z[5,6,2]  R2357     -3.7707009911537170e-01
    z[5,6,2]  R2358     -8.2286477088928223e-02
    z[5,6,2]  R2359     -1.0160498321056366e-01
    z[5,6,2]  R2360     -1.9210581481456757e-01
    z[5,6,2]  R2361     -8.3123147487640381e-02
    z[5,6,2]  R2362     1.7333178222179413e-01
    z[5,6,2]  R2363     -4.6031072735786438e-02
    z[5,6,2]  R2364     -1.3563394546508789e-01
    z[5,6,2]  R2365     -1.3572248630225658e-02
    z[5,6,2]  R2366     3.0794867873191833e-01
    z[5,6,2]  R2367     5.8678197860717773e-01
    z[5,6,2]  R2368     4.4368335604667664e-01
    z[5,6,2]  R2369     -1.2148012965917587e-01
    z[5,6,2]  R2370     -9.4842031598091125e-02
    z[5,6,2]  R2371     5.3951416164636612e-02
    z[5,6,2]  R2372     -2.4943840503692627e-01
    z[5,6,2]  R2373     3.0690962076187134e-01
    z[5,6,2]  R2374     -1.8194435536861420e-01
    z[5,6,2]  R2375     9.2556074261665344e-02
    z[5,6,2]  R2376     5.6087291240692139e-01
    z[5,6,2]  R2377     2.5920915603637695e-01
    z[5,6,2]  R2378     -5.2315410226583481e-02
    z[5,6,2]  R2379     -2.4299649894237518e-01
    z[5,6,2]  R2380     2.8462827205657959e-02
    z[5,6,2]  R2381     -7.9752728343009949e-02
    z[5,6,2]  R2382     -1.9546903669834137e-01
    z[5,6,2]  R2383     -1.6521067917346954e-01
    z[5,6,2]  R2384     2.1789493039250374e-02
    z[5,6,2]  R2385     -7.9349920153617859e-02
    z[5,6,2]  R2386     4.8773157596588135e-01
    z[5,6,2]  R2387     2.2447645664215088e-01
    z[5,6,2]  R2388     3.4056842327117920e-01
    z[5,6,2]  R2389     1.0006441920995712e-01
    z[5,6,2]  R2390     -7.9439111053943634e-02
    z[5,6,2]  R2391     -1.9052430987358093e-01
    z[5,6,2]  R2392     -5.7515446096658707e-03
    z[5,6,2]  R2393     -2.2354939579963684e-01
    z[5,6,2]  R2394     -5.0686992704868317e-02
    z[5,6,2]  R2395     -1.6932713985443115e-01
    z[5,6,2]  R2396     1.2727114558219910e-01
    z[5,6,2]  R2397     -2.3148582875728607e-01
    z[5,6,2]  R2398     -1.2812073528766632e-01
    z[5,6,2]  R2399     -1.6133835911750793e-01
    z[5,6,2]  R2400     -2.3383864760398865e-01
    z[5,6,2]  R2401     -0.0661177933216095
    z[5,6,2]  R2402     -1.2817256152629852e-01
    z[5,6,2]  R2403     1.7731526866555214e-02
    z[5,6,2]  R2404     -3.9519403129816055e-02
    z[5,6,2]  R2405     -1.8911775946617126e-01
    z[5,6,2]  R2406     -1.1916232854127884e-01
    z[5,6,2]  R2407     -7.4620373547077179e-02
    z[5,6,2]  R2408     -2.6734763383865356e-01
    z[5,6,2]  R2409     2.3613844811916351e-01
    z[5,6,2]  R2410     -0.0619661882519722
    z[5,6,2]  R2411     3.3399939537048340e-01
    z[5,6,2]  R2412     -5.9533727169036865e-01
    z[5,6,2]  R2413     -3.9430230855941772e-01
    z[5,6,2]  R2414     -5.0604969263076782e-01
    z[5,6,2]  R2415     -5.1947891712188721e-01
    z[5,6,2]  R2416     -1.0304950177669525e-02
    z[5,6,2]  R2417     3.6137357354164124e-01
    z[5,6,2]  R2418     1.4033210277557373e-01
    z[5,6,2]  R2419     -0.586410403251648
    z[5,6,2]  R2420     -4.8165100812911987e-01
    z[5,6,2]  R2421     1.6418717801570892e-01
    z[5,6,2]  R2422     -2.5007659196853638e-01
    z[5,6,2]  R2423     -3.9739865064620972e-01
    z[5,6,2]  R2424     -2.8848305344581604e-01
    z[5,6,2]  R2425     -4.4339919090270996e-01
    z[5,6,2]  R2426     9.7652688622474670e-02
    z[5,6,2]  R2427     1.1433774232864380e-01
    z[5,6,2]  R2428     -5.6149488687515259e-01
    z[5,6,2]  R2429     -4.7930890321731567e-01
    z[5,6,2]  R2430     -5.8779168128967285e-01
    z[5,6,2]  R2431     -1.1778302490711212e-01
    z[5,6,2]  R2432     -6.5734660625457764e-01
    z[5,6,2]  R2433     -4.9735471606254578e-01
    z[5,6,2]  R2434     -4.3005892634391785e-01
    z[5,6,2]  R2435     -1.5715565532445908e-02
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2338     -1
    z[5,6,3]  R2339     1
    z[5,6,3]  R2346     4.9130353331565857e-01
    z[5,6,3]  R2347     2.1447099745273590e-01
    z[5,6,3]  R2348     7.4778348207473755e-01
    z[5,6,3]  R2349     6.0457760095596313e-01
    z[5,6,3]  R2350     4.8526278138160706e-01
    z[5,6,3]  R2351     2.9882353544235229e-01
    z[5,6,3]  R2352     5.4019653797149658e-01
    z[5,6,3]  R2353     8.5413151979446411e-01
    z[5,6,3]  R2354     7.6380604505538940e-01
    z[5,6,3]  R2355     4.9203363060951233e-01
    z[5,6,3]  R2356     -2.7736705541610718e-01
    z[5,6,3]  R2357     -3.2460939884185791e-01
    z[5,6,3]  R2358     -4.0017729997634888e-01
    z[5,6,3]  R2359     -2.8906232118606567e-01
    z[5,6,3]  R2360     -2.9647415876388550e-01
    z[5,6,3]  R2361     -2.8446659445762634e-01
    z[5,6,3]  R2362     -3.8580140471458435e-01
    z[5,6,3]  R2363     -3.5557079315185547e-01
    z[5,6,3]  R2364     1.0866206884384155e-01
    z[5,6,3]  R2365     3.1090116500854492e-01
    z[5,6,3]  R2366     3.7762907147407532e-01
    z[5,6,3]  R2367     -2.8737068176269531e-01
    z[5,6,3]  R2368     -0.482251912355423
    z[5,6,3]  R2369     3.8285559415817261e-01
    z[5,6,3]  R2370     1.4088337123394012e-01
    z[5,6,3]  R2371     6.6598147153854370e-01
    z[5,6,3]  R2372     4.8683908581733704e-01
    z[5,6,3]  R2373     -1.5552611090242863e-02
    z[5,6,3]  R2374     5.3134995698928833e-01
    z[5,6,3]  R2375     -0.692699134349823
    z[5,6,3]  R2376     3.4966096282005310e-01
    z[5,6,3]  R2377     7.6672458648681641e-01
    z[5,6,3]  R2378     -1.5139228105545044e-01
    z[5,6,3]  R2379     1.5158000588417053e-01
    z[5,6,3]  R2380     -3.5130608081817627e-01
    z[5,6,3]  R2381     -2.8890445828437805e-01
    z[5,6,3]  R2382     -3.2266542315483093e-01
    z[5,6,3]  R2383     -4.8203226923942566e-01
    z[5,6,3]  R2384     -1.9956551492214203e-01
    z[5,6,3]  R2385     -2.9325437545776367e-01
    z[5,6,3]  R2386     5.0965875387191772e-01
    z[5,6,3]  R2387     0.659257173538208
    z[5,6,3]  R2388     6.5231317281723022e-01
    z[5,6,3]  R2389     -2.9387019574642181e-02
    z[5,6,3]  R2390     -2.8190738521516323e-03
    z[5,6,3]  R2391     1.2896408140659332e-01
    z[5,6,3]  R2392     6.5814755856990814e-02
    z[5,6,3]  R2393     -1.6845270991325378e-02
    z[5,6,3]  R2394     -3.1805783510208130e-04
    z[5,6,3]  R2395     8.1102559342980385e-03
    z[5,6,3]  R2396     0.050968237221241
    z[5,6,3]  R2397     3.3115687966346741e-01
    z[5,6,3]  R2398     -3.3807581663131714e-01
    z[5,6,3]  R2399     0.274882048368454
    z[5,6,3]  R2400     2.7509680390357971e-01
    z[5,6,3]  R2401     2.9080143570899963e-01
    z[5,6,3]  R2402     4.2971488833427429e-01
    z[5,6,3]  R2403     -8.4945894777774811e-02
    z[5,6,3]  R2404     -0.509889543056488
    z[5,6,3]  R2405     -6.8869769573211670e-02
    z[5,6,3]  R2406     0.0910181850194931
    z[5,6,3]  R2407     1.2829015031456947e-02
    z[5,6,3]  R2408     -4.0507459640502930e-01
    z[5,6,3]  R2409     3.9797410368919373e-01
    z[5,6,3]  R2410     -4.0944054722785950e-01
    z[5,6,3]  R2411     -8.2941770553588867e-02
    z[5,6,3]  R2412     6.4459836483001709e-01
    z[5,6,3]  R2413     5.4118847846984863e-01
    z[5,6,3]  R2414     5.7443559169769287e-01
    z[5,6,3]  R2415     -3.1225383281707764e-02
    z[5,6,3]  R2416     6.6303342580795288e-02
    z[5,6,3]  R2417     -9.6390329301357269e-02
    z[5,6,3]  R2418     -0.134671151638031
    z[5,6,3]  R2419     2.1323148906230927e-01
    z[5,6,3]  R2420     7.3015308380126953e-01
    z[5,6,3]  R2421     -3.5643491148948669e-01
    z[5,6,3]  R2422     4.0695074200630188e-01
    z[5,6,3]  R2423     1.6109007596969604e-01
    z[5,6,3]  R2424     1.8732589483261108e-01
    z[5,6,3]  R2425     -1.0029952228069305e-01
    z[5,6,3]  R2426     -1.8509706482291222e-02
    z[5,6,3]  R2427     -3.7871259450912476e-01
    z[5,6,3]  R2428     2.9333943128585815e-01
    z[5,6,3]  R2429     4.7650942206382751e-01
    z[5,6,3]  R2430     -2.3655596375465393e-01
    z[5,6,3]  R2431     -2.9557985067367554e-01
    z[5,6,3]  R2432     -2.2809679806232452e-01
    z[5,6,3]  R2433     -5.1991522312164307e-01
    z[5,6,3]  R2434     1.1041344143450260e-02
    z[5,6,3]  R2435     -3.0342775583267212e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2340     -1
    z[5,6,4]  R2341     1
    z[5,6,4]  R2346     -1.6896435990929604e-02
    z[5,6,4]  R2347     1.1893675476312637e-01
    z[5,6,4]  R2348     -2.3363986611366272e-01
    z[5,6,4]  R2349     5.6501183658838272e-02
    z[5,6,4]  R2350     9.9369265139102936e-02
    z[5,6,4]  R2351     -4.2273152619600296e-02
    z[5,6,4]  R2352     2.7650189399719238e-01
    z[5,6,4]  R2353     2.6277473568916321e-01
    z[5,6,4]  R2354     1.0319091379642487e-02
    z[5,6,4]  R2355     -2.1204583346843719e-01
    z[5,6,4]  R2356     -4.3894339352846146e-02
    z[5,6,4]  R2357     1.7493394017219543e-01
    z[5,6,4]  R2358     4.4317370653152466e-01
    z[5,6,4]  R2359     -4.9686712026596069e-01
    z[5,6,4]  R2360     -1.3466018438339233e-01
    z[5,6,4]  R2361     -2.9516938328742981e-01
    z[5,6,4]  R2362     -4.5699611306190491e-01
    z[5,6,4]  R2363     4.1366478800773621e-01
    z[5,6,4]  R2364     -6.9980108737945557e-01
    z[5,6,4]  R2365     6.1890256404876709e-01
    z[5,6,4]  R2366     1.2420323491096497e-01
    z[5,6,4]  R2367     2.1561962366104126e-01
    z[5,6,4]  R2368     -3.3257490396499634e-01
    z[5,6,4]  R2369     -6.7357122898101807e-01
    z[5,6,4]  R2370     -1.0187104344367981e-01
    z[5,6,4]  R2371     -3.2308768481016159e-02
    z[5,6,4]  R2372     -1.1614349484443665e-01
    z[5,6,4]  R2373     0.600644052028656
    z[5,6,4]  R2374     1.2698681652545929e-01
    z[5,6,4]  R2375     -1.6743943095207214e-01
    z[5,6,4]  R2376     -3.3669468760490417e-01
    z[5,6,4]  R2377     9.3967542052268982e-02
    z[5,6,4]  R2378     5.6981366872787476e-01
    z[5,6,4]  R2379     -6.8885219097137451e-01
    z[5,6,4]  R2380     3.9365351200103760e-01
    z[5,6,4]  R2381     4.3954676389694214e-01
    z[5,6,4]  R2382     3.0370175838470459e-01
    z[5,6,4]  R2383     2.0893611013889313e-01
    z[5,6,4]  R2384     2.5418680906295776e-01
    z[5,6,4]  R2385     2.1659302711486816e-01
    z[5,6,4]  R2386     5.1909282803535461e-02
    z[5,6,4]  R2387     -2.5398629903793335e-01
    z[5,6,4]  R2388     -2.3089951276779175e-01
    z[5,6,4]  R2389     -3.5876947641372681e-01
    z[5,6,4]  R2390     -0.0959881991147995
    z[5,6,4]  R2391     -2.8585413098335266e-01
    z[5,6,4]  R2392     -4.2576059699058533e-01
    z[5,6,4]  R2393     1.4788508415222168e-01
    z[5,6,4]  R2394     3.0391144752502441e-01
    z[5,6,4]  R2395     -4.3358907103538513e-01
    z[5,6,4]  R2396     -2.6395526528358459e-01
    z[5,6,4]  R2397     2.3674128949642181e-01
    z[5,6,4]  R2398     2.9911085963249207e-02
    z[5,6,4]  R2399     1.9667085260152817e-02
    z[5,6,4]  R2400     1.6249762475490570e-01
    z[5,6,4]  R2401     -6.1553075909614563e-02
    z[5,6,4]  R2402     1.5981048345565796e-01
    z[5,6,4]  R2403     -1.3030655682086945e-01
    z[5,6,4]  R2404     3.1087738275527954e-01
    z[5,6,4]  R2405     4.1969907283782959e-01
    z[5,6,4]  R2406     -1.7897665500640869e-01
    z[5,6,4]  R2407     3.9696547389030457e-01
    z[5,6,4]  R2408     7.8738816082477570e-02
    z[5,6,4]  R2409     2.1400362253189087e-01
    z[5,6,4]  R2410     4.6166211366653442e-01
    z[5,6,4]  R2411     5.9847152233123779e-01
    z[5,6,4]  R2412     4.0785338729619980e-02
    z[5,6,4]  R2413     -3.1205436587333679e-01
    z[5,6,4]  R2414     -4.5826199650764465e-01
    z[5,6,4]  R2415     -1.8192663788795471e-01
    z[5,6,4]  R2416     -9.5630668103694916e-02
    z[5,6,4]  R2417     2.0256495103240013e-02
    z[5,6,4]  R2418     2.1458901464939117e-01
    z[5,6,4]  R2419     -1.4460344612598419e-01
    z[5,6,4]  R2420     1.3604256510734558e-01
    z[5,6,4]  R2421     3.8054218888282776e-01
    z[5,6,4]  R2422     -2.4202033877372742e-01
    z[5,6,4]  R2423     5.1111710071563721e-01
    z[5,6,4]  R2424     -1.0704553872346878e-01
    z[5,6,4]  R2425     -2.0238064229488373e-01
    z[5,6,4]  R2426     1.1939971148967743e-01
    z[5,6,4]  R2427     2.5957143306732178e-01
    z[5,6,4]  R2428     7.4490890838205814e-03
    z[5,6,4]  R2429     -4.4754702597856522e-02
    z[5,6,4]  R2430     -1.8876731395721436e-01
    z[5,6,4]  R2431     1.6481505706906319e-02
    z[5,6,4]  R2432     3.5699892044067383e-01
    z[5,6,4]  R2433     4.9457452259957790e-03
    z[5,6,4]  R2434     2.1581137180328369e-01
    z[5,6,4]  R2435     2.5845596194267273e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2342     -1
    z[5,6,5]  R2343     1
    z[5,6,5]  R2346     -5.6757771968841553e-01
    z[5,6,5]  R2347     -4.1100424528121948e-01
    z[5,6,5]  R2348     -2.3790072649717331e-02
    z[5,6,5]  R2349     -1.7221823334693909e-01
    z[5,6,5]  R2350     -1.4542511105537415e-01
    z[5,6,5]  R2351     -3.0688026547431946e-01
    z[5,6,5]  R2352     -3.0909284949302673e-01
    z[5,6,5]  R2353     -1.3321830332279205e-01
    z[5,6,5]  R2354     -2.3807440698146820e-01
    z[5,6,5]  R2355     -3.6323902010917664e-01
    z[5,6,5]  R2356     7.4424915015697479e-02
    z[5,6,5]  R2357     1.8276399374008179e-01
    z[5,6,5]  R2358     6.3236460089683533e-02
    z[5,6,5]  R2359     -1.7125536501407623e-01
    z[5,6,5]  R2360     -2.3346212506294250e-01
    z[5,6,5]  R2361     1.9256035983562469e-01
    z[5,6,5]  R2362     1.5108166635036469e-01
    z[5,6,5]  R2363     -2.0481450483202934e-02
    z[5,6,5]  R2364     3.4916028380393982e-01
    z[5,6,5]  R2365     4.9116128683090210e-01
    z[5,6,5]  R2366     3.1380828469991684e-02
    z[5,6,5]  R2367     0.325045645236969
    z[5,6,5]  R2368     2.6756852865219116e-01
    z[5,6,5]  R2369     -1.1562506854534149e-01
    z[5,6,5]  R2370     5.1794809103012085e-01
    z[5,6,5]  R2371     4.0950044989585876e-01
    z[5,6,5]  R2372     2.6671406626701355e-01
    z[5,6,5]  R2373     2.3218253254890442e-01
    z[5,6,5]  R2374     5.9344559907913208e-02
    z[5,6,5]  R2375     -4.8516458272933960e-01
    z[5,6,5]  R2376     1.5722188353538513e-01
    z[5,6,5]  R2377     1.4611233770847321e-01
    z[5,6,5]  R2378     -1.0686865448951721e-01
    z[5,6,5]  R2379     5.3440326452255249e-01
    z[5,6,5]  R2380     -3.2610318064689636e-01
    z[5,6,5]  R2381     -1.9234703481197357e-01
    z[5,6,5]  R2382     -3.1847196817398071e-01
    z[5,6,5]  R2383     -3.6189454793930054e-01
    z[5,6,5]  R2384     -2.4750418961048126e-01
    z[5,6,5]  R2385     -1.3576509058475494e-01
    z[5,6,5]  R2386     -2.5539833307266235e-01
    z[5,6,5]  R2387     7.1471042931079865e-02
    z[5,6,5]  R2388     1.1612446606159210e-01
    z[5,6,5]  R2389     -3.0692974105477333e-02
    z[5,6,5]  R2390     1.7688576877117157e-01
    z[5,6,5]  R2391     1.9736237823963165e-01
    z[5,6,5]  R2392     -7.6937347650527954e-01
    z[5,6,5]  R2393     1.4822122454643250e-01
    z[5,6,5]  R2394     -9.1586671769618988e-02
    z[5,6,5]  R2395     -2.5746437907218933e-01
    z[5,6,5]  R2396     -1.1757009476423264e-01
    z[5,6,5]  R2397     -2.1723946928977966e-01
    z[5,6,5]  R2398     -1.8353374302387238e-01
    z[5,6,5]  R2399     -3.0065011978149414e-01
    z[5,6,5]  R2400     -1.0003068484365940e-02
    z[5,6,5]  R2401     -7.0270299911499023e-02
    z[5,6,5]  R2402     2.5976386666297913e-01
    z[5,6,5]  R2403     -5.3589552640914917e-01
    z[5,6,5]  R2404     -2.5983822345733643e-01
    z[5,6,5]  R2405     -4.0476869791746140e-02
    z[5,6,5]  R2406     1.4154934883117676e-01
    z[5,6,5]  R2407     3.5965159535408020e-01
    z[5,6,5]  R2408     3.5309413075447083e-01
    z[5,6,5]  R2409     -1.8601374328136444e-01
    z[5,6,5]  R2410     -2.1937897801399231e-01
    z[5,6,5]  R2411     -1.6718253493309021e-01
    z[5,6,5]  R2412     -4.2517997324466705e-02
    z[5,6,5]  R2413     2.8758922591805458e-02
    z[5,6,5]  R2414     -2.0251670479774475e-01
    z[5,6,5]  R2415     6.2297517061233521e-01
    z[5,6,5]  R2416     4.8483829945325851e-02
    z[5,6,5]  R2417     -7.0186775922775269e-01
    z[5,6,5]  R2418     -3.9356565475463867e-01
    z[5,6,5]  R2419     2.5392500683665276e-02
    z[5,6,5]  R2420     -4.2466189712285995e-02
    z[5,6,5]  R2421     -5.4508411884307861e-01
    z[5,6,5]  R2422     1.8560223979875445e-03
    z[5,6,5]  R2423     3.8124760985374451e-01
    z[5,6,5]  R2424     4.3632471561431885e-01
    z[5,6,5]  R2425     2.3405356705188751e-01
    z[5,6,5]  R2426     -4.4823956489562988e-01
    z[5,6,5]  R2427     -2.5935393571853638e-01
    z[5,6,5]  R2428     1.9823490083217621e-01
    z[5,6,5]  R2429     -1.3387256860733032e-01
    z[5,6,5]  R2430     -6.7064121365547180e-02
    z[5,6,5]  R2431     -3.2198619842529297e-01
    z[5,6,5]  R2432     -3.4350180625915527e-01
    z[5,6,5]  R2433     -1.5017965435981750e-01
    z[5,6,5]  R2434     2.5003787875175476e-01
    z[5,6,5]  R2435     -5.9697788208723068e-02
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2344     -1
    z[5,6,6]  R2345     1
    z[5,6,6]  R2346     -1.1574598029255867e-02
    z[5,6,6]  R2347     4.2924996465444565e-02
    z[5,6,6]  R2348     -1.8672055006027222e-01
    z[5,6,6]  R2349     -1.9802938401699066e-01
    z[5,6,6]  R2350     1.4331719279289246e-01
    z[5,6,6]  R2351     3.4687790274620056e-01
    z[5,6,6]  R2352     -7.8677006065845490e-02
    z[5,6,6]  R2353     -9.8048657178878784e-02
    z[5,6,6]  R2354     2.6403272058814764e-03
    z[5,6,6]  R2355     -6.2519580125808716e-02
    z[5,6,6]  R2356     1.7300352454185486e-01
    z[5,6,6]  R2357     -3.6265037953853607e-02
    z[5,6,6]  R2358     2.7934902906417847e-01
    z[5,6,6]  R2359     1.0170172154903412e-01
    z[5,6,6]  R2360     -4.9611786007881165e-01
    z[5,6,6]  R2361     2.4536505341529846e-01
    z[5,6,6]  R2362     -3.2058927416801453e-01
    z[5,6,6]  R2363     -5.3555899858474731e-01
    z[5,6,6]  R2364     4.6294897794723511e-02
    z[5,6,6]  R2365     -8.1990055739879608e-02
    z[5,6,6]  R2366     -3.1228914856910706e-01
    z[5,6,6]  R2367     2.0340059418231249e-03
    z[5,6,6]  R2368     -2.5967034697532654e-01
    z[5,6,6]  R2369     -3.9736205339431763e-01
    z[5,6,6]  R2370     6.2632775306701660e-01
    z[5,6,6]  R2371     3.7222284078598022e-01
    z[5,6,6]  R2372     3.1119233369827271e-01
    z[5,6,6]  R2373     5.3603923320770264e-01
    z[5,6,6]  R2374     -7.4719607830047607e-01
    z[5,6,6]  R2375     1.0734346508979797e-01
    z[5,6,6]  R2376     1.2542261183261871e-01
    z[5,6,6]  R2377     -3.7674814462661743e-01
    z[5,6,6]  R2378     -2.4277888238430023e-01
    z[5,6,6]  R2379     -6.7902550101280212e-02
    z[5,6,6]  R2380     -9.5274388790130615e-02
    z[5,6,6]  R2381     1.9019149243831635e-01
    z[5,6,6]  R2382     -2.5185507535934448e-01
    z[5,6,6]  R2383     -1.6003604233264923e-01
    z[5,6,6]  R2384     9.8591828718781471e-03
    z[5,6,6]  R2385     -1.2602771818637848e-01
    z[5,6,6]  R2386     5.3695771843194962e-02
    z[5,6,6]  R2387     3.0102658271789551e-01
    z[5,6,6]  R2388     -3.0510690808296204e-01
    z[5,6,6]  R2389     -1.0583250969648361e-01
    z[5,6,6]  R2390     3.3957654237747192e-01
    z[5,6,6]  R2391     -1.2614670395851135e-01
    z[5,6,6]  R2392     2.6650611311197281e-02
    z[5,6,6]  R2393     4.5035898685455322e-01
    z[5,6,6]  R2394     0.500627875328064
    z[5,6,6]  R2395     4.5484250783920288e-01
    z[5,6,6]  R2396     -5.0810897350311279e-01
    z[5,6,6]  R2397     9.6349850296974182e-02
    z[5,6,6]  R2398     6.6272813081741333e-01
    z[5,6,6]  R2399     -2.5804024934768677e-01
    z[5,6,6]  R2400     -3.0795404314994812e-01
    z[5,6,6]  R2401     3.4476846456527710e-02
    z[5,6,6]  R2402     1.8172548711299896e-01
    z[5,6,6]  R2403     4.8901230096817017e-01
    z[5,6,6]  R2404     -1.6833323240280151e-01
    z[5,6,6]  R2405     -1.3133953511714935e-01
    z[5,6,6]  R2406     3.0088698863983154e-01
    z[5,6,6]  R2407     1.3107791543006897e-01
    z[5,6,6]  R2408     -7.3397949337959290e-02
    z[5,6,6]  R2409     3.4319078922271729e-01
    z[5,6,6]  R2410     2.6081087067723274e-02
    z[5,6,6]  R2411     2.6228204369544983e-02
    z[5,6,6]  R2412     1.3008902966976166e-01
    z[5,6,6]  R2413     1.9161215424537659e-01
    z[5,6,6]  R2414     3.1981957145035267e-03
    z[5,6,6]  R2415     -5.2745349705219269e-02
    z[5,6,6]  R2416     -1.8745927512645721e-01
    z[5,6,6]  R2417     1.3385285437107086e-01
    z[5,6,6]  R2418     4.3754053115844727e-01
    z[5,6,6]  R2419     -3.3285838365554810e-01
    z[5,6,6]  R2420     -2.7408143505454063e-02
    z[5,6,6]  R2421     1.3167731463909149e-01
    z[5,6,6]  R2422     -3.1846159696578979e-01
    z[5,6,6]  R2423     -1.9886401295661926e-01
    z[5,6,6]  R2424     -2.4611370265483856e-01
    z[5,6,6]  R2425     1.5351347625255585e-01
    z[5,6,6]  R2426     2.7978392317891121e-02
    z[5,6,6]  R2427     1.9964060187339783e-01
    z[5,6,6]  R2428     -4.3247118592262268e-02
    z[5,6,6]  R2429     -1.1739847064018250e-01
    z[5,6,6]  R2430     4.6886342763900757e-01
    z[5,6,6]  R2431     -1.2221318483352661e-01
    z[5,6,6]  R2432     3.1506296247243881e-02
    z[5,6,6]  R2433     1.0364209115505219e-01
    z[5,6,6]  R2434     7.2631442546844482e-01
    z[5,6,6]  R2435     -1.9667962193489075e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2436     -1
    z[6,5,0]  R2437     1
    z[6,5,0]  R2450     -5.9604984521865845e-01
    z[6,5,0]  R2451     -5.9519636631011963e-01
    z[6,5,0]  R2452     -5.4555088281631470e-01
    z[6,5,0]  R2453     -9.0853029489517212e-01
    z[6,5,0]  R2454     2.1695900708436966e-02
    z[6,5,0]  R2455     1.8270808458328247e-01
    z[6,5,0]  R2456     4.5938470959663391e-01
    z[6,5,0]  R2457     2.2123923897743225e-01
    z[6,5,0]  R2458     2.5043913722038269e-01
    z[6,5,0]  R2459     1.3056947290897369e-01
    z[6,5,0]  R2460     9.0998277068138123e-02
    z[6,5,0]  R2461     8.4450000524520874e-01
    z[6,5,0]  R2462     -2.1525566279888153e-01
    z[6,5,0]  R2463     8.5323905944824219e-01
    z[6,5,0]  R2464     7.9332852363586426e-01
    z[6,5,0]  R2465     9.4393032789230347e-01
    z[6,5,0]  R2466     7.9634547233581543e-01
    z[6,5,0]  R2467     4.2133647203445435e-01
    z[6,5,0]  R2468     5.4325199127197266e-01
    z[6,5,0]  R2469     0.753872811794281
    z[6,5,0]  R2470     -6.5286658704280853e-02
    z[6,5,0]  R2471     1.0219974815845490e-01
    z[6,5,0]  R2472     -1.2452743202447891e-01
    z[6,5,0]  R2473     2.6733890175819397e-01
    z[6,5,0]  R2474     -9.9125787615776062e-02
    z[6,5,0]  R2475     -2.6458343863487244e-01
    z[6,5,0]  R2476     0.359305739402771
    z[6,5,0]  R2477     4.0368229150772095e-01
    z[6,5,0]  R2478     3.5545936226844788e-01
    z[6,5,0]  R2479     5.5241298675537109e-01
    z[6,5,0]  R2480     2.7959239482879639e-01
    z[6,5,0]  R2481     -1.3251301646232605e-01
    z[6,5,0]  R2482     -4.3608862161636353e-01
    z[6,5,0]  R2483     6.5889185667037964e-01
    z[6,5,0]  R2484     4.6117383241653442e-01
    z[6,5,0]  R2485     4.0184545516967773e-01
    z[6,5,0]  R2486     6.4642888307571411e-01
    z[6,5,0]  R2487     6.0211783647537231e-01
    z[6,5,0]  R2488     6.4304113388061523e-01
    z[6,5,0]  R2489     6.8500363826751709e-01
    z[6,5,0]  R2490     -4.5201104879379272e-01
    z[6,5,0]  R2491     -3.3013510704040527e-01
    z[6,5,0]  R2492     7.2771143913269043e-01
    z[6,5,0]  R2493     7.1268713474273682e-01
    z[6,5,0]  R2494     5.4694259166717529e-01
    z[6,5,0]  R2495     8.4359234571456909e-01
    z[6,5,0]  R2496     4.8151209950447083e-01
    z[6,5,0]  R2497     6.5796029567718506e-01
    z[6,5,0]  R2498     2.9971030354499817e-01
    z[6,5,0]  R2499     6.5436176955699921e-02
    z[6,5,0]  R2500     6.4163106679916382e-01
    z[6,5,0]  R2501     -4.7521561384201050e-01
    z[6,5,0]  R2502     3.3508926630020142e-02
    z[6,5,0]  R2503     -1.4299483597278595e-01
    z[6,5,0]  R2504     -1.6441199183464050e-01
    z[6,5,0]  R2505     -3.4808126091957092e-01
    z[6,5,0]  R2506     -4.0252998471260071e-01
    z[6,5,0]  R2507     -3.0971869826316833e-01
    z[6,5,0]  R2508     -3.2467669248580933e-01
    z[6,5,0]  R2509     -3.5864984989166260e-01
    z[6,5,0]  R2510     -5.7287907600402832e-01
    z[6,5,0]  R2511     -0.325132817029953
    z[6,5,0]  R2512     -4.0381217002868652e-01
    z[6,5,0]  R2513     -0.509609043598175
    z[6,5,0]  R2514     -5.1786619424819946e-01
    z[6,5,0]  R2515     6.9882661104202271e-01
    z[6,5,0]  R2516     -2.2907108068466187e-01
    z[6,5,0]  R2517     -2.9500603675842285e-01
    z[6,5,0]  R2518     5.8432853221893311e-01
    z[6,5,0]  R2519     4.8068276047706604e-01
    z[6,5,0]  R2520     -2.6974228024482727e-01
    z[6,5,0]  R2521     -4.0558192133903503e-01
    z[6,5,0]  R2522     4.4221732020378113e-01
    z[6,5,0]  R2523     4.6138077974319458e-01
    z[6,5,0]  R2524     3.5794076323509216e-01
    z[6,5,0]  R2525     2.1634428203105927e-01
    z[6,5,0]  R2526     -1.5749311447143555e-01
    z[6,5,0]  R2527     -1.0882386937737465e-02
    z[6,5,0]  R2528     2.3076352477073669e-01
    z[6,5,0]  R2529     4.3636098504066467e-01
    z[6,5,0]  R2530     1.2535629794001579e-02
    z[6,5,0]  R2531     3.6885414272546768e-02
    z[6,5,0]  R2532     5.5535793304443359e-01
    z[6,5,0]  R2533     -2.5221186876296997e-01
    z[6,5,0]  R2534     -3.3997863531112671e-02
    z[6,5,0]  R2535     6.9310680031776428e-02
    z[6,5,0]  R2536     -4.5445088297128677e-02
    z[6,5,0]  R2537     -1.1276463419198990e-01
    z[6,5,0]  R2538     1.2360639125108719e-01
    z[6,5,0]  R2539     2.7317786216735840e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2438     -1
    z[6,5,1]  R2439     1
    z[6,5,1]  R2450     0.276196151971817
    z[6,5,1]  R2451     2.2301610559225082e-02
    z[6,5,1]  R2452     -3.1388025730848312e-02
    z[6,5,1]  R2453     1.5112218260765076e-01
    z[6,5,1]  R2454     9.1509366035461426e-01
    z[6,5,1]  R2455     0.881537914276123
    z[6,5,1]  R2456     1.0335970669984818e-01
    z[6,5,1]  R2457     8.0878442525863647e-01
    z[6,5,1]  R2458     7.6376211643218994e-01
    z[6,5,1]  R2459     7.0217174291610718e-01
    z[6,5,1]  R2460     -7.9451489448547363e-01
    z[6,5,1]  R2461     1.0510198026895523e-01
    z[6,5,1]  R2462     -5.9090346097946167e-01
    z[6,5,1]  R2463     -1.1415301263332367e-01
    z[6,5,1]  R2464     -3.4486210346221924e-01
    z[6,5,1]  R2465     -1.0071279853582382e-01
    z[6,5,1]  R2466     -1.9674836099147797e-01
    z[6,5,1]  R2467     -0.521199107170105
    z[6,5,1]  R2468     -5.0083076953887939e-01
    z[6,5,1]  R2469     4.4286736845970154e-01
    z[6,5,1]  R2470     -9.1140103340148926e-01
    z[6,5,1]  R2471     -8.2444530725479126e-01
    z[6,5,1]  R2472     -7.8273254632949829e-01
    z[6,5,1]  R2473     -7.1847504377365112e-01
    z[6,5,1]  R2474     -7.4615907669067383e-01
    z[6,5,1]  R2475     -6.5173190832138062e-01
    z[6,5,1]  R2476     2.8385114669799805e-01
    z[6,5,1]  R2477     5.0374716520309448e-01
    z[6,5,1]  R2478     -0.191203311085701
    z[6,5,1]  R2479     -5.3746816702187061e-03
    z[6,5,1]  R2480     -9.3310713768005371e-01
    z[6,5,1]  R2481     -5.7585853338241577e-01
    z[6,5,1]  R2482     -6.1612749099731445e-01
    z[6,5,1]  R2483     -2.1015946567058563e-01
    z[6,5,1]  R2484     3.3841848373413086e-02
    z[6,5,1]  R2485     -4.7460398077964783e-01
    z[6,5,1]  R2486     4.4044005870819092e-01
    z[6,5,1]  R2487     8.6261585354804993e-02
    z[6,5,1]  R2488     4.5362392067909241e-01
    z[6,5,1]  R2489     4.5255038142204285e-01
    z[6,5,1]  R2490     -0.754883885383606
    z[6,5,1]  R2491     -7.4834233522415161e-01
    z[6,5,1]  R2492     -1.6699890792369843e-01
    z[6,5,1]  R2493     -0.0396428182721138
    z[6,5,1]  R2494     -1.9857594370841980e-01
    z[6,5,1]  R2495     2.6120641827583313e-01
    z[6,5,1]  R2496     1.9385293126106262e-01
    z[6,5,1]  R2497     1.2686505913734436e-01
    z[6,5,1]  R2498     2.9744756221771240e-01
    z[6,5,1]  R2499     8.9126682281494141e-01
    z[6,5,1]  R2500     -1.1289706081151962e-01
    z[6,5,1]  R2501     -9.2442803084850311e-02
    z[6,5,1]  R2502     -1.4126157760620117e-01
    z[6,5,1]  R2503     -1.2021017074584961e-01
    z[6,5,1]  R2504     -1.6279260814189911e-01
    z[6,5,1]  R2505     -5.1551878452301025e-02
    z[6,5,1]  R2506     -1.0261062532663345e-01
    z[6,5,1]  R2507     -1.5986080467700958e-01
    z[6,5,1]  R2508     -8.5229448974132538e-02
    z[6,5,1]  R2509     -3.2290231436491013e-02
    z[6,5,1]  R2510     -6.7437601089477539e-01
    z[6,5,1]  R2511     -7.6250630617141724e-01
    z[6,5,1]  R2512     -6.2576764822006226e-01
    z[6,5,1]  R2513     -5.9989112615585327e-01
    z[6,5,1]  R2514     -5.3688186407089233e-01
    z[6,5,1]  R2515     4.8928743600845337e-01
    z[6,5,1]  R2516     -6.5893191099166870e-01
    z[6,5,1]  R2517     -5.7101702690124512e-01
    z[6,5,1]  R2518     1.2074148654937744e-01
    z[6,5,1]  R2519     -2.0272694528102875e-01
    z[6,5,1]  R2520     -7.5885915756225586e-01
    z[6,5,1]  R2521     -5.0641649961471558e-01
    z[6,5,1]  R2522     -3.5411059856414795e-01
    z[6,5,1]  R2523     -2.8774434700608253e-02
    z[6,5,1]  R2524     -4.1485038399696350e-01
    z[6,5,1]  R2525     -4.4661924242973328e-01
    z[6,5,1]  R2526     -7.0320534706115723e-01
    z[6,5,1]  R2527     -4.5102778077125549e-01
    z[6,5,1]  R2528     2.3100256919860840e-01
    z[6,5,1]  R2529     -2.1505138278007507e-01
    z[6,5,1]  R2530     -6.3967871665954590e-01
    z[6,5,1]  R2531     -4.1408398747444153e-01
    z[6,5,1]  R2532     0.520452618598938
    z[6,5,1]  R2533     -2.9941666126251221e-01
    z[6,5,1]  R2534     7.7732527256011963e-01
    z[6,5,1]  R2535     7.9937362670898438e-01
    z[6,5,1]  R2536     7.7364301681518555e-01
    z[6,5,1]  R2537     7.2622382640838623e-01
    z[6,5,1]  R2538     9.0468436479568481e-01
    z[6,5,1]  R2539     8.6709374189376831e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2440     -1
    z[6,5,2]  R2441     1
    z[6,5,2]  R2450     4.8773157596588135e-01
    z[6,5,2]  R2451     2.2447645664215088e-01
    z[6,5,2]  R2452     3.4056842327117920e-01
    z[6,5,2]  R2453     1.0006441920995712e-01
    z[6,5,2]  R2454     -7.9439111053943634e-02
    z[6,5,2]  R2455     -1.9052430987358093e-01
    z[6,5,2]  R2456     -5.7515446096658707e-03
    z[6,5,2]  R2457     -2.2354939579963684e-01
    z[6,5,2]  R2458     -5.0686992704868317e-02
    z[6,5,2]  R2459     -1.6932713985443115e-01
    z[6,5,2]  R2460     1.2727114558219910e-01
    z[6,5,2]  R2461     -2.3148582875728607e-01
    z[6,5,2]  R2462     -1.2812073528766632e-01
    z[6,5,2]  R2463     -1.6133835911750793e-01
    z[6,5,2]  R2464     -2.3383864760398865e-01
    z[6,5,2]  R2465     -0.0661177933216095
    z[6,5,2]  R2466     -1.2817256152629852e-01
    z[6,5,2]  R2467     1.7731526866555214e-02
    z[6,5,2]  R2468     -3.9519403129816055e-02
    z[6,5,2]  R2469     -1.8911775946617126e-01
    z[6,5,2]  R2470     -1.1916232854127884e-01
    z[6,5,2]  R2471     -7.4620373547077179e-02
    z[6,5,2]  R2472     -2.6734763383865356e-01
    z[6,5,2]  R2473     2.3613844811916351e-01
    z[6,5,2]  R2474     -0.0619661882519722
    z[6,5,2]  R2475     3.3399939537048340e-01
    z[6,5,2]  R2476     -5.9533727169036865e-01
    z[6,5,2]  R2477     -3.9430230855941772e-01
    z[6,5,2]  R2478     -5.0604969263076782e-01
    z[6,5,2]  R2479     -5.1947891712188721e-01
    z[6,5,2]  R2480     -1.0304950177669525e-02
    z[6,5,2]  R2481     3.6137357354164124e-01
    z[6,5,2]  R2482     1.4033210277557373e-01
    z[6,5,2]  R2483     -0.586410403251648
    z[6,5,2]  R2484     -4.8165100812911987e-01
    z[6,5,2]  R2485     1.6418717801570892e-01
    z[6,5,2]  R2486     -2.5007659196853638e-01
    z[6,5,2]  R2487     -3.9739865064620972e-01
    z[6,5,2]  R2488     -2.8848305344581604e-01
    z[6,5,2]  R2489     -4.4339919090270996e-01
    z[6,5,2]  R2490     9.7652688622474670e-02
    z[6,5,2]  R2491     1.1433774232864380e-01
    z[6,5,2]  R2492     -5.6149488687515259e-01
    z[6,5,2]  R2493     -4.7930890321731567e-01
    z[6,5,2]  R2494     -5.8779168128967285e-01
    z[6,5,2]  R2495     -1.1778302490711212e-01
    z[6,5,2]  R2496     -6.5734660625457764e-01
    z[6,5,2]  R2497     -4.9735471606254578e-01
    z[6,5,2]  R2498     -4.3005892634391785e-01
    z[6,5,2]  R2499     -1.5715565532445908e-02
    z[6,5,2]  R2500     1.0780003666877747e-01
    z[6,5,2]  R2501     7.3124116659164429e-01
    z[6,5,2]  R2502     5.7421612739562988e-01
    z[6,5,2]  R2503     7.2630625963211060e-01
    z[6,5,2]  R2504     8.1204974651336670e-01
    z[6,5,2]  R2505     7.5538033246994019e-01
    z[6,5,2]  R2506     5.9786844253540039e-01
    z[6,5,2]  R2507     2.2927477955818176e-01
    z[6,5,2]  R2508     4.9712011218070984e-01
    z[6,5,2]  R2509     6.6889148950576782e-01
    z[6,5,2]  R2510     -3.2046550512313843e-01
    z[6,5,2]  R2511     -3.7707009911537170e-01
    z[6,5,2]  R2512     -8.2286477088928223e-02
    z[6,5,2]  R2513     -1.0160498321056366e-01
    z[6,5,2]  R2514     -1.9210581481456757e-01
    z[6,5,2]  R2515     -8.3123147487640381e-02
    z[6,5,2]  R2516     1.7333178222179413e-01
    z[6,5,2]  R2517     -4.6031072735786438e-02
    z[6,5,2]  R2518     -1.3563394546508789e-01
    z[6,5,2]  R2519     -1.3572248630225658e-02
    z[6,5,2]  R2520     3.0794867873191833e-01
    z[6,5,2]  R2521     5.8678197860717773e-01
    z[6,5,2]  R2522     4.4368335604667664e-01
    z[6,5,2]  R2523     -1.2148012965917587e-01
    z[6,5,2]  R2524     -9.4842031598091125e-02
    z[6,5,2]  R2525     5.3951416164636612e-02
    z[6,5,2]  R2526     -2.4943840503692627e-01
    z[6,5,2]  R2527     3.0690962076187134e-01
    z[6,5,2]  R2528     -1.8194435536861420e-01
    z[6,5,2]  R2529     9.2556074261665344e-02
    z[6,5,2]  R2530     5.6087291240692139e-01
    z[6,5,2]  R2531     2.5920915603637695e-01
    z[6,5,2]  R2532     -5.2315410226583481e-02
    z[6,5,2]  R2533     -2.4299649894237518e-01
    z[6,5,2]  R2534     2.8462827205657959e-02
    z[6,5,2]  R2535     -7.9752728343009949e-02
    z[6,5,2]  R2536     -1.9546903669834137e-01
    z[6,5,2]  R2537     -1.6521067917346954e-01
    z[6,5,2]  R2538     2.1789493039250374e-02
    z[6,5,2]  R2539     -7.9349920153617859e-02
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2442     -1
    z[6,5,3]  R2443     1
    z[6,5,3]  R2450     5.0965875387191772e-01
    z[6,5,3]  R2451     0.659257173538208
    z[6,5,3]  R2452     6.5231317281723022e-01
    z[6,5,3]  R2453     -2.9387019574642181e-02
    z[6,5,3]  R2454     -2.8190738521516323e-03
    z[6,5,3]  R2455     1.2896408140659332e-01
    z[6,5,3]  R2456     6.5814755856990814e-02
    z[6,5,3]  R2457     -1.6845270991325378e-02
    z[6,5,3]  R2458     -3.1805783510208130e-04
    z[6,5,3]  R2459     8.1102559342980385e-03
    z[6,5,3]  R2460     0.050968237221241
    z[6,5,3]  R2461     3.3115687966346741e-01
    z[6,5,3]  R2462     -3.3807581663131714e-01
    z[6,5,3]  R2463     0.274882048368454
    z[6,5,3]  R2464     2.7509680390357971e-01
    z[6,5,3]  R2465     2.9080143570899963e-01
    z[6,5,3]  R2466     4.2971488833427429e-01
    z[6,5,3]  R2467     -8.4945894777774811e-02
    z[6,5,3]  R2468     -0.509889543056488
    z[6,5,3]  R2469     -6.8869769573211670e-02
    z[6,5,3]  R2470     0.0910181850194931
    z[6,5,3]  R2471     1.2829015031456947e-02
    z[6,5,3]  R2472     -4.0507459640502930e-01
    z[6,5,3]  R2473     3.9797410368919373e-01
    z[6,5,3]  R2474     -4.0944054722785950e-01
    z[6,5,3]  R2475     -8.2941770553588867e-02
    z[6,5,3]  R2476     6.4459836483001709e-01
    z[6,5,3]  R2477     5.4118847846984863e-01
    z[6,5,3]  R2478     5.7443559169769287e-01
    z[6,5,3]  R2479     -3.1225383281707764e-02
    z[6,5,3]  R2480     6.6303342580795288e-02
    z[6,5,3]  R2481     -9.6390329301357269e-02
    z[6,5,3]  R2482     -0.134671151638031
    z[6,5,3]  R2483     2.1323148906230927e-01
    z[6,5,3]  R2484     7.3015308380126953e-01
    z[6,5,3]  R2485     -3.5643491148948669e-01
    z[6,5,3]  R2486     4.0695074200630188e-01
    z[6,5,3]  R2487     1.6109007596969604e-01
    z[6,5,3]  R2488     1.8732589483261108e-01
    z[6,5,3]  R2489     -1.0029952228069305e-01
    z[6,5,3]  R2490     -1.8509706482291222e-02
    z[6,5,3]  R2491     -3.7871259450912476e-01
    z[6,5,3]  R2492     2.9333943128585815e-01
    z[6,5,3]  R2493     4.7650942206382751e-01
    z[6,5,3]  R2494     -2.3655596375465393e-01
    z[6,5,3]  R2495     -2.9557985067367554e-01
    z[6,5,3]  R2496     -2.2809679806232452e-01
    z[6,5,3]  R2497     -5.1991522312164307e-01
    z[6,5,3]  R2498     1.1041344143450260e-02
    z[6,5,3]  R2499     -3.0342775583267212e-01
    z[6,5,3]  R2500     4.9130353331565857e-01
    z[6,5,3]  R2501     2.1447099745273590e-01
    z[6,5,3]  R2502     7.4778348207473755e-01
    z[6,5,3]  R2503     6.0457760095596313e-01
    z[6,5,3]  R2504     4.8526278138160706e-01
    z[6,5,3]  R2505     2.9882353544235229e-01
    z[6,5,3]  R2506     5.4019653797149658e-01
    z[6,5,3]  R2507     8.5413151979446411e-01
    z[6,5,3]  R2508     7.6380604505538940e-01
    z[6,5,3]  R2509     4.9203363060951233e-01
    z[6,5,3]  R2510     -2.7736705541610718e-01
    z[6,5,3]  R2511     -3.2460939884185791e-01
    z[6,5,3]  R2512     -4.0017729997634888e-01
    z[6,5,3]  R2513     -2.8906232118606567e-01
    z[6,5,3]  R2514     -2.9647415876388550e-01
    z[6,5,3]  R2515     -2.8446659445762634e-01
    z[6,5,3]  R2516     -3.8580140471458435e-01
    z[6,5,3]  R2517     -3.5557079315185547e-01
    z[6,5,3]  R2518     1.0866206884384155e-01
    z[6,5,3]  R2519     3.1090116500854492e-01
    z[6,5,3]  R2520     3.7762907147407532e-01
    z[6,5,3]  R2521     -2.8737068176269531e-01
    z[6,5,3]  R2522     -0.482251912355423
    z[6,5,3]  R2523     3.8285559415817261e-01
    z[6,5,3]  R2524     1.4088337123394012e-01
    z[6,5,3]  R2525     6.6598147153854370e-01
    z[6,5,3]  R2526     4.8683908581733704e-01
    z[6,5,3]  R2527     -1.5552611090242863e-02
    z[6,5,3]  R2528     5.3134995698928833e-01
    z[6,5,3]  R2529     -0.692699134349823
    z[6,5,3]  R2530     3.4966096282005310e-01
    z[6,5,3]  R2531     7.6672458648681641e-01
    z[6,5,3]  R2532     -1.5139228105545044e-01
    z[6,5,3]  R2533     1.5158000588417053e-01
    z[6,5,3]  R2534     -3.5130608081817627e-01
    z[6,5,3]  R2535     -2.8890445828437805e-01
    z[6,5,3]  R2536     -3.2266542315483093e-01
    z[6,5,3]  R2537     -4.8203226923942566e-01
    z[6,5,3]  R2538     -1.9956551492214203e-01
    z[6,5,3]  R2539     -2.9325437545776367e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2444     -1
    z[6,5,4]  R2445     1
    z[6,5,4]  R2450     5.1909282803535461e-02
    z[6,5,4]  R2451     -2.5398629903793335e-01
    z[6,5,4]  R2452     -2.3089951276779175e-01
    z[6,5,4]  R2453     -3.5876947641372681e-01
    z[6,5,4]  R2454     -0.0959881991147995
    z[6,5,4]  R2455     -2.8585413098335266e-01
    z[6,5,4]  R2456     -4.2576059699058533e-01
    z[6,5,4]  R2457     1.4788508415222168e-01
    z[6,5,4]  R2458     3.0391144752502441e-01
    z[6,5,4]  R2459     -4.3358907103538513e-01
    z[6,5,4]  R2460     -2.6395526528358459e-01
    z[6,5,4]  R2461     2.3674128949642181e-01
    z[6,5,4]  R2462     2.9911085963249207e-02
    z[6,5,4]  R2463     1.9667085260152817e-02
    z[6,5,4]  R2464     1.6249762475490570e-01
    z[6,5,4]  R2465     -6.1553075909614563e-02
    z[6,5,4]  R2466     1.5981048345565796e-01
    z[6,5,4]  R2467     -1.3030655682086945e-01
    z[6,5,4]  R2468     3.1087738275527954e-01
    z[6,5,4]  R2469     4.1969907283782959e-01
    z[6,5,4]  R2470     -1.7897665500640869e-01
    z[6,5,4]  R2471     3.9696547389030457e-01
    z[6,5,4]  R2472     7.8738816082477570e-02
    z[6,5,4]  R2473     2.1400362253189087e-01
    z[6,5,4]  R2474     4.6166211366653442e-01
    z[6,5,4]  R2475     5.9847152233123779e-01
    z[6,5,4]  R2476     4.0785338729619980e-02
    z[6,5,4]  R2477     -3.1205436587333679e-01
    z[6,5,4]  R2478     -4.5826199650764465e-01
    z[6,5,4]  R2479     -1.8192663788795471e-01
    z[6,5,4]  R2480     -9.5630668103694916e-02
    z[6,5,4]  R2481     2.0256495103240013e-02
    z[6,5,4]  R2482     2.1458901464939117e-01
    z[6,5,4]  R2483     -1.4460344612598419e-01
    z[6,5,4]  R2484     1.3604256510734558e-01
    z[6,5,4]  R2485     3.8054218888282776e-01
    z[6,5,4]  R2486     -2.4202033877372742e-01
    z[6,5,4]  R2487     5.1111710071563721e-01
    z[6,5,4]  R2488     -1.0704553872346878e-01
    z[6,5,4]  R2489     -2.0238064229488373e-01
    z[6,5,4]  R2490     1.1939971148967743e-01
    z[6,5,4]  R2491     2.5957143306732178e-01
    z[6,5,4]  R2492     7.4490890838205814e-03
    z[6,5,4]  R2493     -4.4754702597856522e-02
    z[6,5,4]  R2494     -1.8876731395721436e-01
    z[6,5,4]  R2495     1.6481505706906319e-02
    z[6,5,4]  R2496     3.5699892044067383e-01
    z[6,5,4]  R2497     4.9457452259957790e-03
    z[6,5,4]  R2498     2.1581137180328369e-01
    z[6,5,4]  R2499     2.5845596194267273e-01
    z[6,5,4]  R2500     -1.6896435990929604e-02
    z[6,5,4]  R2501     1.1893675476312637e-01
    z[6,5,4]  R2502     -2.3363986611366272e-01
    z[6,5,4]  R2503     5.6501183658838272e-02
    z[6,5,4]  R2504     9.9369265139102936e-02
    z[6,5,4]  R2505     -4.2273152619600296e-02
    z[6,5,4]  R2506     2.7650189399719238e-01
    z[6,5,4]  R2507     2.6277473568916321e-01
    z[6,5,4]  R2508     1.0319091379642487e-02
    z[6,5,4]  R2509     -2.1204583346843719e-01
    z[6,5,4]  R2510     -4.3894339352846146e-02
    z[6,5,4]  R2511     1.7493394017219543e-01
    z[6,5,4]  R2512     4.4317370653152466e-01
    z[6,5,4]  R2513     -4.9686712026596069e-01
    z[6,5,4]  R2514     -1.3466018438339233e-01
    z[6,5,4]  R2515     -2.9516938328742981e-01
    z[6,5,4]  R2516     -4.5699611306190491e-01
    z[6,5,4]  R2517     4.1366478800773621e-01
    z[6,5,4]  R2518     -6.9980108737945557e-01
    z[6,5,4]  R2519     6.1890256404876709e-01
    z[6,5,4]  R2520     1.2420323491096497e-01
    z[6,5,4]  R2521     2.1561962366104126e-01
    z[6,5,4]  R2522     -3.3257490396499634e-01
    z[6,5,4]  R2523     -6.7357122898101807e-01
    z[6,5,4]  R2524     -1.0187104344367981e-01
    z[6,5,4]  R2525     -3.2308768481016159e-02
    z[6,5,4]  R2526     -1.1614349484443665e-01
    z[6,5,4]  R2527     0.600644052028656
    z[6,5,4]  R2528     1.2698681652545929e-01
    z[6,5,4]  R2529     -1.6743943095207214e-01
    z[6,5,4]  R2530     -3.3669468760490417e-01
    z[6,5,4]  R2531     9.3967542052268982e-02
    z[6,5,4]  R2532     5.6981366872787476e-01
    z[6,5,4]  R2533     -6.8885219097137451e-01
    z[6,5,4]  R2534     3.9365351200103760e-01
    z[6,5,4]  R2535     4.3954676389694214e-01
    z[6,5,4]  R2536     3.0370175838470459e-01
    z[6,5,4]  R2537     2.0893611013889313e-01
    z[6,5,4]  R2538     2.5418680906295776e-01
    z[6,5,4]  R2539     2.1659302711486816e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2446     -1
    z[6,5,5]  R2447     1
    z[6,5,5]  R2450     -2.5539833307266235e-01
    z[6,5,5]  R2451     7.1471042931079865e-02
    z[6,5,5]  R2452     1.1612446606159210e-01
    z[6,5,5]  R2453     -3.0692974105477333e-02
    z[6,5,5]  R2454     1.7688576877117157e-01
    z[6,5,5]  R2455     1.9736237823963165e-01
    z[6,5,5]  R2456     -7.6937347650527954e-01
    z[6,5,5]  R2457     1.4822122454643250e-01
    z[6,5,5]  R2458     -9.1586671769618988e-02
    z[6,5,5]  R2459     -2.5746437907218933e-01
    z[6,5,5]  R2460     -1.1757009476423264e-01
    z[6,5,5]  R2461     -2.1723946928977966e-01
    z[6,5,5]  R2462     -1.8353374302387238e-01
    z[6,5,5]  R2463     -3.0065011978149414e-01
    z[6,5,5]  R2464     -1.0003068484365940e-02
    z[6,5,5]  R2465     -7.0270299911499023e-02
    z[6,5,5]  R2466     2.5976386666297913e-01
    z[6,5,5]  R2467     -5.3589552640914917e-01
    z[6,5,5]  R2468     -2.5983822345733643e-01
    z[6,5,5]  R2469     -4.0476869791746140e-02
    z[6,5,5]  R2470     1.4154934883117676e-01
    z[6,5,5]  R2471     3.5965159535408020e-01
    z[6,5,5]  R2472     3.5309413075447083e-01
    z[6,5,5]  R2473     -1.8601374328136444e-01
    z[6,5,5]  R2474     -2.1937897801399231e-01
    z[6,5,5]  R2475     -1.6718253493309021e-01
    z[6,5,5]  R2476     -4.2517997324466705e-02
    z[6,5,5]  R2477     2.8758922591805458e-02
    z[6,5,5]  R2478     -2.0251670479774475e-01
    z[6,5,5]  R2479     6.2297517061233521e-01
    z[6,5,5]  R2480     4.8483829945325851e-02
    z[6,5,5]  R2481     -7.0186775922775269e-01
    z[6,5,5]  R2482     -3.9356565475463867e-01
    z[6,5,5]  R2483     2.5392500683665276e-02
    z[6,5,5]  R2484     -4.2466189712285995e-02
    z[6,5,5]  R2485     -5.4508411884307861e-01
    z[6,5,5]  R2486     1.8560223979875445e-03
    z[6,5,5]  R2487     3.8124760985374451e-01
    z[6,5,5]  R2488     4.3632471561431885e-01
    z[6,5,5]  R2489     2.3405356705188751e-01
    z[6,5,5]  R2490     -4.4823956489562988e-01
    z[6,5,5]  R2491     -2.5935393571853638e-01
    z[6,5,5]  R2492     1.9823490083217621e-01
    z[6,5,5]  R2493     -1.3387256860733032e-01
    z[6,5,5]  R2494     -6.7064121365547180e-02
    z[6,5,5]  R2495     -3.2198619842529297e-01
    z[6,5,5]  R2496     -3.4350180625915527e-01
    z[6,5,5]  R2497     -1.5017965435981750e-01
    z[6,5,5]  R2498     2.5003787875175476e-01
    z[6,5,5]  R2499     -5.9697788208723068e-02
    z[6,5,5]  R2500     -5.6757771968841553e-01
    z[6,5,5]  R2501     -4.1100424528121948e-01
    z[6,5,5]  R2502     -2.3790072649717331e-02
    z[6,5,5]  R2503     -1.7221823334693909e-01
    z[6,5,5]  R2504     -1.4542511105537415e-01
    z[6,5,5]  R2505     -3.0688026547431946e-01
    z[6,5,5]  R2506     -3.0909284949302673e-01
    z[6,5,5]  R2507     -1.3321830332279205e-01
    z[6,5,5]  R2508     -2.3807440698146820e-01
    z[6,5,5]  R2509     -3.6323902010917664e-01
    z[6,5,5]  R2510     7.4424915015697479e-02
    z[6,5,5]  R2511     1.8276399374008179e-01
    z[6,5,5]  R2512     6.3236460089683533e-02
    z[6,5,5]  R2513     -1.7125536501407623e-01
    z[6,5,5]  R2514     -2.3346212506294250e-01
    z[6,5,5]  R2515     1.9256035983562469e-01
    z[6,5,5]  R2516     1.5108166635036469e-01
    z[6,5,5]  R2517     -2.0481450483202934e-02
    z[6,5,5]  R2518     3.4916028380393982e-01
    z[6,5,5]  R2519     4.9116128683090210e-01
    z[6,5,5]  R2520     3.1380828469991684e-02
    z[6,5,5]  R2521     0.325045645236969
    z[6,5,5]  R2522     2.6756852865219116e-01
    z[6,5,5]  R2523     -1.1562506854534149e-01
    z[6,5,5]  R2524     5.1794809103012085e-01
    z[6,5,5]  R2525     4.0950044989585876e-01
    z[6,5,5]  R2526     2.6671406626701355e-01
    z[6,5,5]  R2527     2.3218253254890442e-01
    z[6,5,5]  R2528     5.9344559907913208e-02
    z[6,5,5]  R2529     -4.8516458272933960e-01
    z[6,5,5]  R2530     1.5722188353538513e-01
    z[6,5,5]  R2531     1.4611233770847321e-01
    z[6,5,5]  R2532     -1.0686865448951721e-01
    z[6,5,5]  R2533     5.3440326452255249e-01
    z[6,5,5]  R2534     -3.2610318064689636e-01
    z[6,5,5]  R2535     -1.9234703481197357e-01
    z[6,5,5]  R2536     -3.1847196817398071e-01
    z[6,5,5]  R2537     -3.6189454793930054e-01
    z[6,5,5]  R2538     -2.4750418961048126e-01
    z[6,5,5]  R2539     -1.3576509058475494e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2448     -1
    z[6,5,6]  R2449     1
    z[6,5,6]  R2450     5.3695771843194962e-02
    z[6,5,6]  R2451     3.0102658271789551e-01
    z[6,5,6]  R2452     -3.0510690808296204e-01
    z[6,5,6]  R2453     -1.0583250969648361e-01
    z[6,5,6]  R2454     3.3957654237747192e-01
    z[6,5,6]  R2455     -1.2614670395851135e-01
    z[6,5,6]  R2456     2.6650611311197281e-02
    z[6,5,6]  R2457     4.5035898685455322e-01
    z[6,5,6]  R2458     0.500627875328064
    z[6,5,6]  R2459     4.5484250783920288e-01
    z[6,5,6]  R2460     -5.0810897350311279e-01
    z[6,5,6]  R2461     9.6349850296974182e-02
    z[6,5,6]  R2462     6.6272813081741333e-01
    z[6,5,6]  R2463     -2.5804024934768677e-01
    z[6,5,6]  R2464     -3.0795404314994812e-01
    z[6,5,6]  R2465     3.4476846456527710e-02
    z[6,5,6]  R2466     1.8172548711299896e-01
    z[6,5,6]  R2467     4.8901230096817017e-01
    z[6,5,6]  R2468     -1.6833323240280151e-01
    z[6,5,6]  R2469     -1.3133953511714935e-01
    z[6,5,6]  R2470     3.0088698863983154e-01
    z[6,5,6]  R2471     1.3107791543006897e-01
    z[6,5,6]  R2472     -7.3397949337959290e-02
    z[6,5,6]  R2473     3.4319078922271729e-01
    z[6,5,6]  R2474     2.6081087067723274e-02
    z[6,5,6]  R2475     2.6228204369544983e-02
    z[6,5,6]  R2476     1.3008902966976166e-01
    z[6,5,6]  R2477     1.9161215424537659e-01
    z[6,5,6]  R2478     3.1981957145035267e-03
    z[6,5,6]  R2479     -5.2745349705219269e-02
    z[6,5,6]  R2480     -1.8745927512645721e-01
    z[6,5,6]  R2481     1.3385285437107086e-01
    z[6,5,6]  R2482     4.3754053115844727e-01
    z[6,5,6]  R2483     -3.3285838365554810e-01
    z[6,5,6]  R2484     -2.7408143505454063e-02
    z[6,5,6]  R2485     1.3167731463909149e-01
    z[6,5,6]  R2486     -3.1846159696578979e-01
    z[6,5,6]  R2487     -1.9886401295661926e-01
    z[6,5,6]  R2488     -2.4611370265483856e-01
    z[6,5,6]  R2489     1.5351347625255585e-01
    z[6,5,6]  R2490     2.7978392317891121e-02
    z[6,5,6]  R2491     1.9964060187339783e-01
    z[6,5,6]  R2492     -4.3247118592262268e-02
    z[6,5,6]  R2493     -1.1739847064018250e-01
    z[6,5,6]  R2494     4.6886342763900757e-01
    z[6,5,6]  R2495     -1.2221318483352661e-01
    z[6,5,6]  R2496     3.1506296247243881e-02
    z[6,5,6]  R2497     1.0364209115505219e-01
    z[6,5,6]  R2498     7.2631442546844482e-01
    z[6,5,6]  R2499     -1.9667962193489075e-01
    z[6,5,6]  R2500     -1.1574598029255867e-02
    z[6,5,6]  R2501     4.2924996465444565e-02
    z[6,5,6]  R2502     -1.8672055006027222e-01
    z[6,5,6]  R2503     -1.9802938401699066e-01
    z[6,5,6]  R2504     1.4331719279289246e-01
    z[6,5,6]  R2505     3.4687790274620056e-01
    z[6,5,6]  R2506     -7.8677006065845490e-02
    z[6,5,6]  R2507     -9.8048657178878784e-02
    z[6,5,6]  R2508     2.6403272058814764e-03
    z[6,5,6]  R2509     -6.2519580125808716e-02
    z[6,5,6]  R2510     1.7300352454185486e-01
    z[6,5,6]  R2511     -3.6265037953853607e-02
    z[6,5,6]  R2512     2.7934902906417847e-01
    z[6,5,6]  R2513     1.0170172154903412e-01
    z[6,5,6]  R2514     -4.9611786007881165e-01
    z[6,5,6]  R2515     2.4536505341529846e-01
    z[6,5,6]  R2516     -3.2058927416801453e-01
    z[6,5,6]  R2517     -5.3555899858474731e-01
    z[6,5,6]  R2518     4.6294897794723511e-02
    z[6,5,6]  R2519     -8.1990055739879608e-02
    z[6,5,6]  R2520     -3.1228914856910706e-01
    z[6,5,6]  R2521     2.0340059418231249e-03
    z[6,5,6]  R2522     -2.5967034697532654e-01
    z[6,5,6]  R2523     -3.9736205339431763e-01
    z[6,5,6]  R2524     6.2632775306701660e-01
    z[6,5,6]  R2525     3.7222284078598022e-01
    z[6,5,6]  R2526     3.1119233369827271e-01
    z[6,5,6]  R2527     5.3603923320770264e-01
    z[6,5,6]  R2528     -7.4719607830047607e-01
    z[6,5,6]  R2529     1.0734346508979797e-01
    z[6,5,6]  R2530     1.2542261183261871e-01
    z[6,5,6]  R2531     -3.7674814462661743e-01
    z[6,5,6]  R2532     -2.4277888238430023e-01
    z[6,5,6]  R2533     -6.7902550101280212e-02
    z[6,5,6]  R2534     -9.5274388790130615e-02
    z[6,5,6]  R2535     1.9019149243831635e-01
    z[6,5,6]  R2536     -2.5185507535934448e-01
    z[6,5,6]  R2537     -1.6003604233264923e-01
    z[6,5,6]  R2538     9.8591828718781471e-03
    z[6,5,6]  R2539     -1.2602771818637848e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R63       1
    RHS1      R64       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[7,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,4]
 BV BND1      phi[4,2]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[2,8]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[7,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,8]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,4,0]
 FR BND1      z[2,4,1]
 FR BND1      z[2,4,2]
 FR BND1      z[2,4,3]
 FR BND1      z[2,4,4]
 FR BND1      z[2,4,5]
 FR BND1      z[2,4,6]
 FR BND1      z[4,2,0]
 FR BND1      z[4,2,1]
 FR BND1      z[4,2,2]
 FR BND1      z[4,2,3]
 FR BND1      z[4,2,4]
 FR BND1      z[4,2,5]
 FR BND1      z[4,2,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
ENDATA
