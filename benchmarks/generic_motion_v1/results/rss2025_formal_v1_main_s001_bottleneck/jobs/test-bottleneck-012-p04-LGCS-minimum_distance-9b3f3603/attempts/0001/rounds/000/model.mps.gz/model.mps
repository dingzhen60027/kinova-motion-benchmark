NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       1.5858689546585083e+00
    phi[0,1]  R89       1.1684657335281372e+00
    phi[0,1]  R90       1.3575278520584106e+00
    phi[0,1]  R91       2.1852173805236816e+00
    phi[0,1]  R92       -2.5696772336959839e-01
    phi[0,1]  R93       5.0725191831588745e-01
    phi[0,1]  R94       1.6203590631484985e+00
    phi[0,1]  R95       1.9114496707916260e+00
    phi[0,1]  R96       1.6209852695465088e-01
    phi[0,1]  R97       -3.7236842513084412e-01
    phi[0,1]  R98       -2.12015438079834
    phi[0,1]  R99       -2.5332202911376953e+00
    phi[0,1]  R100      -1.0288975238800049e+00
    phi[0,1]  R101      -2.6653854846954346e+00
    phi[0,1]  R102      -1.0829408168792725e+00
    phi[0,1]  R103      -6.3550782203674316e-01
    phi[0,1]  R104      -3.1293160915374756e+00
    phi[0,1]  R105      -8.2462996244430542e-01
    phi[0,1]  R106      -1.0191112756729126e+00
    phi[0,1]  R107      -3.0711323022842407e-01
    phi[0,1]  R108      1.2179622650146484e+00
    phi[0,1]  R109      -1.1853488683700562e+00
    phi[0,1]  R110      -1.5073124170303345e+00
    phi[0,1]  R111      -1.8261901140213013e+00
    phi[0,1]  R112      -1.1090599298477173e+00
    phi[0,1]  R113      -1.7233176231384277e+00
    phi[0,1]  R114      2.4054361879825592e-01
    phi[0,1]  R115      -1.9817413091659546e+00
    phi[0,1]  R116      -1.7470769882202148e+00
    phi[0,1]  R117      -2.6441571712493896e+00
    phi[0,1]  R118      -1.3687599897384644e+00
    phi[0,1]  R119      -1.1500992774963379e+00
    phi[0,1]  R120      1.8906557559967041e-01
    phi[0,1]  R121      -6.2044852972030640e-01
    phi[0,1]  R122      -4.7617143392562866e-01
    phi[0,1]  R123      -2.8186285495758057e+00
    phi[0,1]  R124      -7.0342117547988892e-01
    phi[0,1]  R125      -2.0677556991577148e+00
    phi[0,1]  R126      7.6975691318511963e-01
    phi[0,1]  R127      -8.6671525239944458e-01
    phi[0,1]  R128      1.3283796310424805e+00
    phi[0,1]  R129      4.4072070717811584e-01
    phi[0,1]  R130      1.2819547653198242e+00
    phi[0,1]  R131      8.7914243340492249e-02
    phi[0,1]  R132      -0.544611930847168
    phi[0,1]  R133      6.4580613374710083e-01
    phi[0,1]  R134      1.4211711883544922e+00
    phi[0,1]  R135      -9.2589992284774780e-01
    phi[0,1]  R136      3.9668568968772888e-01
    phi[0,1]  R137      -1.5248523652553558e-01
    phi[0,1]  R138      -3.0745840072631836e+00
    phi[0,1]  R139      -1.1007326841354370e+00
    phi[0,1]  R140      -3.6320359706878662e+00
    phi[0,1]  R141      -3.2099831104278564e+00
    phi[0,1]  R142      6.2592077255249023e-01
    phi[0,1]  R143      -1.5818793326616287e-02
    phi[0,1]  R144      1.4549224376678467e+00
    phi[0,1]  R145      3.3274614810943604e-01
    phi[0,1]  R146      8.0706059932708740e-01
    phi[0,1]  R147      2.0571795105934143e-01
    phi[0,1]  R148      -8.8777565956115723e-01
    phi[0,1]  R149      -8.2806617021560669e-02
    phi[0,1]  R150      -3.0662536621093750e+00
    phi[0,1]  R151      9.2224901914596558e-01
    phi[0,1]  R152      -6.7909665405750275e-02
    phi[0,1]  R153      -1.7560343742370605e+00
    phi[0,1]  R154      -5.6961971521377563e-01
    phi[0,1]  R155      -2.7233130931854248e+00
    phi[0,1]  R156      1.2763316631317139e+00
    phi[0,1]  R157      -3.7004370689392090e+00
    phi[0,1]  R158      3.1837576627731323e-01
    phi[0,1]  R159      2.7808830142021179e-01
    phi[0,1]  R160      -3.2352179288864136e-01
    phi[0,1]  R161      -7.0442932844161987e-01
    phi[0,1]  R162      -0.592222273349762
    phi[0,1]  R163      -2.6170235872268677e-01
    phi[0,1]  R164      -1.2236419916152954e+00
    phi[0,1]  R165      -1.9905123710632324e+00
    phi[0,1]  R166      -0.61787348985672
    phi[0,1]  R167      -3.0949428081512451e+00
    phi[0,1]  R168      -2.0271360874176025e+00
    phi[0,1]  R169      -2.9319512844085693e+00
    phi[0,1]  R170      9.5726318657398224e-02
    phi[0,1]  R171      2.2170491516590118e-01
    phi[0,1]  R172      -5.4358851909637451e-01
    phi[0,1]  R173      -4.2365417480468750e+00
    phi[0,1]  R174      -3.6609203815460205e+00
    phi[0,1]  R175      -3.8620319366455078e+00
    phi[0,1]  R176      -3.21632981300354
    phi[0,1]  R177      -3.0204708576202393e+00
    phi[0,1]  R178      -0.0952332466840744
    phi[0,1]  R179      -9.7577132284641266e-02
    phi[0,1]  R180      -3.4782664775848389e+00
    phi[0,1]  R181      -2.1915462017059326e+00
    phi[0,1]  R182      4.5037499070167542e-01
    phi[0,1]  R183      -1.1935274600982666e+00
    phi[0,1]  R184      -3.2895629405975342e+00
    phi[0,1]  R185      5.0156213343143463e-02
    phi[0,1]  R186      -2.9610803127288818e+00
    phi[0,1]  R187      -1.8369605541229248e+00
    phi[0,1]  R188      -9.6318966150283813e-01
    phi[0,1]  R189      -3.0838625431060791e+00
    phi[0,1]  R190      -7.7979081869125366e-01
    phi[0,1]  R191      -8.9136604219675064e-03
    phi[0,1]  R192      -2.2690973281860352e+00
    phi[0,1]  R193      -2.3988385200500488e+00
    phi[0,1]  R194      -8.5080349445343018e-01
    phi[0,1]  R195      -5.4699756205081940e-02
    phi[0,1]  R196      -2.7444612979888916e+00
    phi[0,1]  R197      -1.2007137387990952e-01
    phi[0,1]  R198      -1.4884338378906250e+00
    phi[0,1]  R199      1.2772685289382935e+00
    phi[0,1]  R200      9.8391062021255493e-01
    phi[0,1]  R201      -3.2103290557861328e+00
    phi[0,1]  R202      -2.85830020904541
    phi[0,1]  R203      -2.9286408424377441e+00
    phi[0,1]  R204      3.2224914431571960e-01
    phi[0,1]  R205      5.9770929813385010e-01
    phi[0,1]  R206      -2.6930193901062012e+00
    phi[0,1]  R207      6.4129781723022461e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R208      -3.0999999046325684e+00
    phi[1,0]  R209      -3.0999999046325684e+00
    phi[1,0]  R210      -2.2400000095367432e+00
    phi[1,0]  R211      -2.2400000095367432e+00
    phi[1,0]  R212      -3.0999999046325684e+00
    phi[1,0]  R213      -3.0999999046325684e+00
    phi[1,0]  R214      -2.5699999332427979e+00
    phi[1,0]  R215      -2.5699999332427979e+00
    phi[1,0]  R216      -3.0999999046325684e+00
    phi[1,0]  R217      -3.0999999046325684e+00
    phi[1,0]  R218      -2.0899999141693115e+00
    phi[1,0]  R219      -2.0899999141693115e+00
    phi[1,0]  R220      -3.0999999046325684e+00
    phi[1,0]  R221      -3.0999999046325684e+00
    phi[1,0]  R222      1.3283796310424805e+00
    phi[1,0]  R223      4.4072070717811584e-01
    phi[1,0]  R224      1.2819547653198242e+00
    phi[1,0]  R225      8.7914243340492249e-02
    phi[1,0]  R226      -0.544611930847168
    phi[1,0]  R227      6.4580613374710083e-01
    phi[1,0]  R228      1.4211711883544922e+00
    phi[1,0]  R229      -9.2589992284774780e-01
    phi[1,0]  R230      3.9668568968772888e-01
    phi[1,0]  R231      -1.5248523652553558e-01
    phi[1,0]  R232      -3.0745840072631836e+00
    phi[1,0]  R233      -1.1007326841354370e+00
    phi[1,0]  R234      -3.6320359706878662e+00
    phi[1,0]  R235      -3.2099831104278564e+00
    phi[1,0]  R236      6.2592077255249023e-01
    phi[1,0]  R237      -1.5818793326616287e-02
    phi[1,0]  R238      1.4549224376678467e+00
    phi[1,0]  R239      3.3274614810943604e-01
    phi[1,0]  R240      8.0706059932708740e-01
    phi[1,0]  R241      2.0571795105934143e-01
    phi[1,0]  R242      -8.8777565956115723e-01
    phi[1,0]  R243      -8.2806617021560669e-02
    phi[1,0]  R244      -3.0662536621093750e+00
    phi[1,0]  R245      9.2224901914596558e-01
    phi[1,0]  R246      -6.7909665405750275e-02
    phi[1,0]  R247      -1.7560343742370605e+00
    phi[1,0]  R248      -5.6961971521377563e-01
    phi[1,0]  R249      -2.7233130931854248e+00
    phi[1,0]  R250      1.2763316631317139e+00
    phi[1,0]  R251      -3.7004370689392090e+00
    phi[1,0]  R252      3.1837576627731323e-01
    phi[1,0]  R253      2.7808830142021179e-01
    phi[1,0]  R254      -3.2352179288864136e-01
    phi[1,0]  R255      -7.0442932844161987e-01
    phi[1,0]  R256      -0.592222273349762
    phi[1,0]  R257      -2.6170235872268677e-01
    phi[1,0]  R258      -1.2236419916152954e+00
    phi[1,0]  R259      -1.9905123710632324e+00
    phi[1,0]  R260      -0.61787348985672
    phi[1,0]  R261      -3.0949428081512451e+00
    phi[1,0]  R262      -2.0271360874176025e+00
    phi[1,0]  R263      -2.9319512844085693e+00
    phi[1,0]  R264      9.5726318657398224e-02
    phi[1,0]  R265      2.2170491516590118e-01
    phi[1,0]  R266      -5.4358851909637451e-01
    phi[1,0]  R267      -4.2365417480468750e+00
    phi[1,0]  R268      -3.6609203815460205e+00
    phi[1,0]  R269      -3.8620319366455078e+00
    phi[1,0]  R270      -3.21632981300354
    phi[1,0]  R271      -3.0204708576202393e+00
    phi[1,0]  R272      -0.0952332466840744
    phi[1,0]  R273      -9.7577132284641266e-02
    phi[1,0]  R274      -3.4782664775848389e+00
    phi[1,0]  R275      -2.1915462017059326e+00
    phi[1,0]  R276      4.5037499070167542e-01
    phi[1,0]  R277      -1.1935274600982666e+00
    phi[1,0]  R278      -3.2895629405975342e+00
    phi[1,0]  R279      5.0156213343143463e-02
    phi[1,0]  R280      -2.9610803127288818e+00
    phi[1,0]  R281      -1.8369605541229248e+00
    phi[1,0]  R282      -9.6318966150283813e-01
    phi[1,0]  R283      -3.0838625431060791e+00
    phi[1,0]  R284      -7.7979081869125366e-01
    phi[1,0]  R285      -8.9136604219675064e-03
    phi[1,0]  R286      -2.2690973281860352e+00
    phi[1,0]  R287      -2.3988385200500488e+00
    phi[1,0]  R288      -8.5080349445343018e-01
    phi[1,0]  R289      -5.4699756205081940e-02
    phi[1,0]  R290      -2.7444612979888916e+00
    phi[1,0]  R291      -1.2007137387990952e-01
    phi[1,0]  R292      -1.4884338378906250e+00
    phi[1,0]  R293      1.2772685289382935e+00
    phi[1,0]  R294      9.8391062021255493e-01
    phi[1,0]  R295      -3.2103290557861328e+00
    phi[1,0]  R296      -2.85830020904541
    phi[1,0]  R297      -2.9286408424377441e+00
    phi[1,0]  R298      3.2224914431571960e-01
    phi[1,0]  R299      5.9770929813385010e-01
    phi[1,0]  R300      -2.6930193901062012e+00
    phi[1,0]  R301      6.4129781723022461e-01
    phi[1,0]  R302      1.5858689546585083e+00
    phi[1,0]  R303      1.1684657335281372e+00
    phi[1,0]  R304      1.3575278520584106e+00
    phi[1,0]  R305      2.1852173805236816e+00
    phi[1,0]  R306      -2.5696772336959839e-01
    phi[1,0]  R307      5.0725191831588745e-01
    phi[1,0]  R308      1.6203590631484985e+00
    phi[1,0]  R309      1.9114496707916260e+00
    phi[1,0]  R310      1.6209852695465088e-01
    phi[1,0]  R311      -3.7236842513084412e-01
    phi[1,0]  R312      -2.12015438079834
    phi[1,0]  R313      -2.5332202911376953e+00
    phi[1,0]  R314      -1.0288975238800049e+00
    phi[1,0]  R315      -2.6653854846954346e+00
    phi[1,0]  R316      -1.0829408168792725e+00
    phi[1,0]  R317      -6.3550782203674316e-01
    phi[1,0]  R318      -3.1293160915374756e+00
    phi[1,0]  R319      -8.2462996244430542e-01
    phi[1,0]  R320      -1.0191112756729126e+00
    phi[1,0]  R321      -3.0711323022842407e-01
    phi[1,0]  R322      1.2179622650146484e+00
    phi[1,0]  R323      -1.1853488683700562e+00
    phi[1,0]  R324      -1.5073124170303345e+00
    phi[1,0]  R325      -1.8261901140213013e+00
    phi[1,0]  R326      -1.1090599298477173e+00
    phi[1,0]  R327      -1.7233176231384277e+00
    phi[1,0]  R328      2.4054361879825592e-01
    phi[1,0]  R329      -1.9817413091659546e+00
    phi[1,0]  R330      -1.7470769882202148e+00
    phi[1,0]  R331      -2.6441571712493896e+00
    phi[1,0]  R332      -1.3687599897384644e+00
    phi[1,0]  R333      -1.1500992774963379e+00
    phi[1,0]  R334      1.8906557559967041e-01
    phi[1,0]  R335      -6.2044852972030640e-01
    phi[1,0]  R336      -4.7617143392562866e-01
    phi[1,0]  R337      -2.8186285495758057e+00
    phi[1,0]  R338      -7.0342117547988892e-01
    phi[1,0]  R339      -2.0677556991577148e+00
    phi[1,0]  R340      7.6975691318511963e-01
    phi[1,0]  R341      -8.6671525239944458e-01
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R342      -3.0999999046325684e+00
    phi[0,4]  R343      -3.0999999046325684e+00
    phi[0,4]  R344      -2.2400000095367432e+00
    phi[0,4]  R345      -2.2400000095367432e+00
    phi[0,4]  R346      -3.0999999046325684e+00
    phi[0,4]  R347      -3.0999999046325684e+00
    phi[0,4]  R348      -2.5699999332427979e+00
    phi[0,4]  R349      -2.5699999332427979e+00
    phi[0,4]  R350      -3.0999999046325684e+00
    phi[0,4]  R351      -3.0999999046325684e+00
    phi[0,4]  R352      -2.0899999141693115e+00
    phi[0,4]  R353      -2.0899999141693115e+00
    phi[0,4]  R354      -3.0999999046325684e+00
    phi[0,4]  R355      -3.0999999046325684e+00
    phi[0,4]  R356      1.5858689546585083e+00
    phi[0,4]  R357      1.1684657335281372e+00
    phi[0,4]  R358      1.3575278520584106e+00
    phi[0,4]  R359      2.1852173805236816e+00
    phi[0,4]  R360      -2.5696772336959839e-01
    phi[0,4]  R361      5.0725191831588745e-01
    phi[0,4]  R362      1.6203590631484985e+00
    phi[0,4]  R363      1.9114496707916260e+00
    phi[0,4]  R364      1.6209852695465088e-01
    phi[0,4]  R365      -3.7236842513084412e-01
    phi[0,4]  R366      -2.12015438079834
    phi[0,4]  R367      -2.5332202911376953e+00
    phi[0,4]  R368      -1.0288975238800049e+00
    phi[0,4]  R369      -2.6653854846954346e+00
    phi[0,4]  R370      -1.0829408168792725e+00
    phi[0,4]  R371      -6.3550782203674316e-01
    phi[0,4]  R372      -3.1293160915374756e+00
    phi[0,4]  R373      -8.2462996244430542e-01
    phi[0,4]  R374      -1.0191112756729126e+00
    phi[0,4]  R375      -3.0711323022842407e-01
    phi[0,4]  R376      1.2179622650146484e+00
    phi[0,4]  R377      -1.1853488683700562e+00
    phi[0,4]  R378      -1.5073124170303345e+00
    phi[0,4]  R379      -1.8261901140213013e+00
    phi[0,4]  R380      -1.1090599298477173e+00
    phi[0,4]  R381      -1.7233176231384277e+00
    phi[0,4]  R382      2.4054361879825592e-01
    phi[0,4]  R383      -1.9817413091659546e+00
    phi[0,4]  R384      -1.7470769882202148e+00
    phi[0,4]  R385      -2.6441571712493896e+00
    phi[0,4]  R386      -1.3687599897384644e+00
    phi[0,4]  R387      -1.1500992774963379e+00
    phi[0,4]  R388      1.8906557559967041e-01
    phi[0,4]  R389      -6.2044852972030640e-01
    phi[0,4]  R390      -4.7617143392562866e-01
    phi[0,4]  R391      -2.8186285495758057e+00
    phi[0,4]  R392      -7.0342117547988892e-01
    phi[0,4]  R393      -2.0677556991577148e+00
    phi[0,4]  R394      7.6975691318511963e-01
    phi[0,4]  R395      -8.6671525239944458e-01
    phi[0,4]  R396      7.4208229780197144e-01
    phi[0,4]  R397      1.2353112697601318e+00
    phi[0,4]  R398      1.0805889368057251e+00
    phi[0,4]  R399      -2.8001111745834351e-01
    phi[0,4]  R400      4.7244563698768616e-01
    phi[0,4]  R401      -4.0230318903923035e-01
    phi[0,4]  R402      -2.7459320425987244e-01
    phi[0,4]  R403      9.6068066358566284e-01
    phi[0,4]  R404      0.679744303226471
    phi[0,4]  R405      -1.4282848834991455e+00
    phi[0,4]  R406      -2.8279592990875244e+00
    phi[0,4]  R407      -3.4522879123687744e+00
    phi[0,4]  R408      -2.3174171447753906e+00
    phi[0,4]  R409      -2.2867567539215088e+00
    phi[0,4]  R410      -3.0382301807403564e+00
    phi[0,4]  R411      -2.4995086193084717e+00
    phi[0,4]  R412      -1.4328546524047852e+00
    phi[0,4]  R413      -2.0978443622589111e+00
    phi[0,4]  R414      -2.2625730037689209e+00
    phi[0,4]  R415      -2.0611398220062256e+00
    phi[0,4]  R416      -2.2320160865783691e+00
    phi[0,4]  R417      -2.1565473079681396e+00
    phi[0,4]  R418      -1.8378547430038452e+00
    phi[0,4]  R419      -1.0087265819311142e-01
    phi[0,4]  R420      -1.3328183889389038e+00
    phi[0,4]  R421      -1.2932187318801880e-01
    phi[0,4]  R422      -5.7320863008499146e-01
    phi[0,4]  R423      -2.9855039715766907e-01
    phi[0,4]  R424      -9.2081671953201294e-01
    phi[0,4]  R425      -4.9113976955413818e-01
    phi[0,4]  R426      8.8913470506668091e-02
    phi[0,4]  R427      -4.7009161114692688e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R428      -3.0999999046325684e+00
    phi[4,0]  R429      -3.0999999046325684e+00
    phi[4,0]  R430      -2.2400000095367432e+00
    phi[4,0]  R431      -2.2400000095367432e+00
    phi[4,0]  R432      -3.0999999046325684e+00
    phi[4,0]  R433      -3.0999999046325684e+00
    phi[4,0]  R434      -2.5699999332427979e+00
    phi[4,0]  R435      -2.5699999332427979e+00
    phi[4,0]  R436      -3.0999999046325684e+00
    phi[4,0]  R437      -3.0999999046325684e+00
    phi[4,0]  R438      -2.0899999141693115e+00
    phi[4,0]  R439      -2.0899999141693115e+00
    phi[4,0]  R440      -3.0999999046325684e+00
    phi[4,0]  R441      -3.0999999046325684e+00
    phi[4,0]  R442      7.4208229780197144e-01
    phi[4,0]  R443      1.2353112697601318e+00
    phi[4,0]  R444      1.0805889368057251e+00
    phi[4,0]  R445      -2.8001111745834351e-01
    phi[4,0]  R446      4.7244563698768616e-01
    phi[4,0]  R447      -4.0230318903923035e-01
    phi[4,0]  R448      -2.7459320425987244e-01
    phi[4,0]  R449      9.6068066358566284e-01
    phi[4,0]  R450      -2.5696772336959839e-01
    phi[4,0]  R451      0.679744303226471
    phi[4,0]  R452      -1.4282848834991455e+00
    phi[4,0]  R453      -2.8279592990875244e+00
    phi[4,0]  R454      -3.4522879123687744e+00
    phi[4,0]  R455      -2.3174171447753906e+00
    phi[4,0]  R456      -2.2867567539215088e+00
    phi[4,0]  R457      -3.0382301807403564e+00
    phi[4,0]  R458      -2.4995086193084717e+00
    phi[4,0]  R459      -1.4328546524047852e+00
    phi[4,0]  R460      -2.0978443622589111e+00
    phi[4,0]  R461      -2.2625730037689209e+00
    phi[4,0]  R462      -2.0611398220062256e+00
    phi[4,0]  R463      -2.2320160865783691e+00
    phi[4,0]  R464      -2.1565473079681396e+00
    phi[4,0]  R465      -1.8378547430038452e+00
    phi[4,0]  R466      -1.0087265819311142e-01
    phi[4,0]  R467      -1.3328183889389038e+00
    phi[4,0]  R468      -1.2932187318801880e-01
    phi[4,0]  R469      -5.7320863008499146e-01
    phi[4,0]  R470      -2.9855039715766907e-01
    phi[4,0]  R471      -9.2081671953201294e-01
    phi[4,0]  R472      -4.9113976955413818e-01
    phi[4,0]  R473      8.8913470506668091e-02
    phi[4,0]  R474      -4.7009161114692688e-01
    phi[4,0]  R475      1.5858689546585083e+00
    phi[4,0]  R476      1.1684657335281372e+00
    phi[4,0]  R477      1.3575278520584106e+00
    phi[4,0]  R478      2.1852173805236816e+00
    phi[4,0]  R479      5.0725191831588745e-01
    phi[4,0]  R480      1.6203590631484985e+00
    phi[4,0]  R481      1.9114496707916260e+00
    phi[4,0]  R482      1.6209852695465088e-01
    phi[4,0]  R483      -3.7236842513084412e-01
    phi[4,0]  R484      -2.12015438079834
    phi[4,0]  R485      -2.5332202911376953e+00
    phi[4,0]  R486      -1.0288975238800049e+00
    phi[4,0]  R487      -2.6653854846954346e+00
    phi[4,0]  R488      -1.0829408168792725e+00
    phi[4,0]  R489      -6.3550782203674316e-01
    phi[4,0]  R490      -3.1293160915374756e+00
    phi[4,0]  R491      -8.2462996244430542e-01
    phi[4,0]  R492      -1.0191112756729126e+00
    phi[4,0]  R493      -3.0711323022842407e-01
    phi[4,0]  R494      1.2179622650146484e+00
    phi[4,0]  R495      -1.1853488683700562e+00
    phi[4,0]  R496      -1.5073124170303345e+00
    phi[4,0]  R497      -1.8261901140213013e+00
    phi[4,0]  R498      -1.1090599298477173e+00
    phi[4,0]  R499      -1.7233176231384277e+00
    phi[4,0]  R500      2.4054361879825592e-01
    phi[4,0]  R501      -1.9817413091659546e+00
    phi[4,0]  R502      -1.7470769882202148e+00
    phi[4,0]  R503      -2.6441571712493896e+00
    phi[4,0]  R504      -1.3687599897384644e+00
    phi[4,0]  R505      -1.1500992774963379e+00
    phi[4,0]  R506      1.8906557559967041e-01
    phi[4,0]  R507      -6.2044852972030640e-01
    phi[4,0]  R508      -4.7617143392562866e-01
    phi[4,0]  R509      -2.8186285495758057e+00
    phi[4,0]  R510      -7.0342117547988892e-01
    phi[4,0]  R511      -2.0677556991577148e+00
    phi[4,0]  R512      7.6975691318511963e-01
    phi[4,0]  R513      -8.6671525239944458e-01
    phi[8,0]  R0        -1
    phi[8,0]  R2        -2.3950683327745272e+00
    phi[8,0]  R3        -3.9327308768290514e-01
    phi[8,0]  R4        2.0704273144097085e-01
    phi[8,0]  R5        -2.2641856685900184e+00
    phi[8,0]  R6        4.6311949829106247e-02
    phi[8,0]  R7        -9.8983765061484208e-02
    phi[8,0]  R8        1.4343729837825507e+00
    phi[8,0]  R72       1
    phi[8,0]  R514      -7.0493157185804112e-01
    phi[8,0]  R515      -5.4950682374070956e+00
    phi[8,0]  R516      -1.8467269218538380e+00
    phi[8,0]  R517      -2.6332730972196483e+00
    phi[8,0]  R518      -3.3070426360735392e+00
    phi[8,0]  R519      -2.8929571731915975e+00
    phi[8,0]  R520      -3.0581426465277950e-01
    phi[8,0]  R521      -4.8341856018328162e+00
    phi[8,0]  R522      -3.1463118544616746e+00
    phi[8,0]  R523      -3.0536879548034621e+00
    phi[8,0]  R524      -1.9910161491078273e+00
    phi[8,0]  R525      -2.1889836792307955e+00
    phi[8,0]  R526      -4.5343728884151187e+00
    phi[8,0]  R527      -1.6656269208500176e+00
    phi[8,0]  R528      -7.7837959700012727e-02
    phi[8,0]  R529      -7.9977800381712649e-02
    phi[8,0]  R530      -8.2413794538147789e-02
    phi[8,0]  R531      -9.3659509166415855e-02
    phi[8,0]  R532      -1.4781500356828342e-01
    phi[8,0]  R533      -2.1469736505960346e-01
    phi[8,0]  R534      -2.1765681368565803e-01
    phi[8,0]  R535      -2.7252198885222167e-01
    phi[8,0]  R536      -3.0896249116577418e-01
    phi[8,0]  R537      -3.2307829519522990e-01
    phi[8,0]  R538      -1.7609652931470876e-01
    phi[8,0]  R539      -1.8503544263700977e-01
    phi[8,0]  R540      -1.8783613714640401e-01
    phi[8,0]  R541      -1.8885580462883755e-01
    phi[8,0]  R542      -1.9285395924979465e-01
    phi[8,0]  R543      -2.0102753018898323e-01
    phi[8,0]  R544      -2.0350894434881539e-01
    phi[8,0]  R545      -2.3159770084979936e-01
    phi[8,0]  R546      -2.4098505845177454e-01
    phi[8,0]  R547      -2.4504977117818483e-01
    phi[8,0]  R548      -1.3356447276736927e-01
    phi[8,0]  R549      -1.5029767915050085e-01
    phi[8,0]  R550      -1.5875199172958543e-01
    phi[8,0]  R551      -1.6686136191109902e-01
    phi[8,0]  R552      -1.6825740267838440e-01
    phi[8,0]  R553      -1.7076146345918941e-01
    phi[8,0]  R554      -1.7112048826444137e-01
    phi[8,0]  R555      -0.174344228068813
    phi[8,0]  R556      -1.7484941753890793e-01
    phi[8,0]  R557      -1.7737880593907729e-01
    phi[8,0]  R558      -1.2248546087509449e-01
    phi[8,0]  R559      -1.2680903888287154e-01
    phi[8,0]  R560      -1.3671302693265353e-01
    phi[8,0]  R561      -1.3869891487771452e-01
    phi[8,0]  R562      -1.4844661086952937e-01
    phi[8,0]  R563      -1.5222466666899725e-01
    phi[8,0]  R564      -1.5913761394096992e-01
    phi[8,0]  R565      -1.6339060000593952e-01
    phi[8,0]  R566      -1.6396445504396417e-01
    phi[8,0]  R567      -1.6599103204317223e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R568      -3.0999999046325684e+00
    phi[1,2]  R569      -3.0999999046325684e+00
    phi[1,2]  R570      -2.2400000095367432e+00
    phi[1,2]  R571      -2.2400000095367432e+00
    phi[1,2]  R572      -3.0999999046325684e+00
    phi[1,2]  R573      -3.0999999046325684e+00
    phi[1,2]  R574      -2.5699999332427979e+00
    phi[1,2]  R575      -2.5699999332427979e+00
    phi[1,2]  R576      -3.0999999046325684e+00
    phi[1,2]  R577      -3.0999999046325684e+00
    phi[1,2]  R578      -2.0899999141693115e+00
    phi[1,2]  R579      -2.0899999141693115e+00
    phi[1,2]  R580      -3.0999999046325684e+00
    phi[1,2]  R581      -3.0999999046325684e+00
    phi[1,2]  R582      1.3283796310424805e+00
    phi[1,2]  R583      4.4072070717811584e-01
    phi[1,2]  R584      1.2819547653198242e+00
    phi[1,2]  R585      8.7914243340492249e-02
    phi[1,2]  R586      -0.544611930847168
    phi[1,2]  R587      6.4580613374710083e-01
    phi[1,2]  R588      1.4211711883544922e+00
    phi[1,2]  R589      -9.2589992284774780e-01
    phi[1,2]  R590      3.9668568968772888e-01
    phi[1,2]  R591      -1.5248523652553558e-01
    phi[1,2]  R592      -3.0745840072631836e+00
    phi[1,2]  R593      -1.1007326841354370e+00
    phi[1,2]  R594      -3.6320359706878662e+00
    phi[1,2]  R595      -3.2099831104278564e+00
    phi[1,2]  R596      6.2592077255249023e-01
    phi[1,2]  R597      -1.5818793326616287e-02
    phi[1,2]  R598      1.4549224376678467e+00
    phi[1,2]  R599      3.3274614810943604e-01
    phi[1,2]  R600      8.0706059932708740e-01
    phi[1,2]  R601      2.0571795105934143e-01
    phi[1,2]  R602      -8.8777565956115723e-01
    phi[1,2]  R603      -8.2806617021560669e-02
    phi[1,2]  R604      -3.0662536621093750e+00
    phi[1,2]  R605      9.2224901914596558e-01
    phi[1,2]  R606      -6.7909665405750275e-02
    phi[1,2]  R607      -1.7560343742370605e+00
    phi[1,2]  R608      -5.6961971521377563e-01
    phi[1,2]  R609      -2.7233130931854248e+00
    phi[1,2]  R610      1.2763316631317139e+00
    phi[1,2]  R611      -3.7004370689392090e+00
    phi[1,2]  R612      3.1837576627731323e-01
    phi[1,2]  R613      2.7808830142021179e-01
    phi[1,2]  R614      -3.2352179288864136e-01
    phi[1,2]  R615      -7.0442932844161987e-01
    phi[1,2]  R616      -0.592222273349762
    phi[1,2]  R617      -2.6170235872268677e-01
    phi[1,2]  R618      -1.2236419916152954e+00
    phi[1,2]  R619      -1.9905123710632324e+00
    phi[1,2]  R620      -0.61787348985672
    phi[1,2]  R621      -3.0949428081512451e+00
    phi[1,2]  R622      -2.0271360874176025e+00
    phi[1,2]  R623      -2.9319512844085693e+00
    phi[1,2]  R624      9.5726318657398224e-02
    phi[1,2]  R625      2.2170491516590118e-01
    phi[1,2]  R626      -5.4358851909637451e-01
    phi[1,2]  R627      -4.2365417480468750e+00
    phi[1,2]  R628      -3.6609203815460205e+00
    phi[1,2]  R629      -3.8620319366455078e+00
    phi[1,2]  R630      -3.21632981300354
    phi[1,2]  R631      -3.0204708576202393e+00
    phi[1,2]  R632      -0.0952332466840744
    phi[1,2]  R633      -9.7577132284641266e-02
    phi[1,2]  R634      -3.4782664775848389e+00
    phi[1,2]  R635      -2.1915462017059326e+00
    phi[1,2]  R636      4.5037499070167542e-01
    phi[1,2]  R637      -1.1935274600982666e+00
    phi[1,2]  R638      -3.2895629405975342e+00
    phi[1,2]  R639      5.0156213343143463e-02
    phi[1,2]  R640      -2.9610803127288818e+00
    phi[1,2]  R641      -1.8369605541229248e+00
    phi[1,2]  R642      -9.6318966150283813e-01
    phi[1,2]  R643      -3.0838625431060791e+00
    phi[1,2]  R644      -7.7979081869125366e-01
    phi[1,2]  R645      -8.9136604219675064e-03
    phi[1,2]  R646      -2.2690973281860352e+00
    phi[1,2]  R647      -2.3988385200500488e+00
    phi[1,2]  R648      -8.5080349445343018e-01
    phi[1,2]  R649      -5.4699756205081940e-02
    phi[1,2]  R650      -2.7444612979888916e+00
    phi[1,2]  R651      -1.2007137387990952e-01
    phi[1,2]  R652      -1.4884338378906250e+00
    phi[1,2]  R653      1.2772685289382935e+00
    phi[1,2]  R654      9.8391062021255493e-01
    phi[1,2]  R655      -3.2103290557861328e+00
    phi[1,2]  R656      -2.85830020904541
    phi[1,2]  R657      -2.9286408424377441e+00
    phi[1,2]  R658      3.2224914431571960e-01
    phi[1,2]  R659      5.9770929813385010e-01
    phi[1,2]  R660      -2.6930193901062012e+00
    phi[1,2]  R661      6.4129781723022461e-01
    phi[1,2]  R662      1.0040894746780396e+00
    phi[1,2]  R663      1.0424926280975342e+00
    phi[1,2]  R664      1.2362130880355835e+00
    phi[1,2]  R665      3.8740894198417664e-01
    phi[1,2]  R666      -0.850970447063446
    phi[1,2]  R667      5.0420272350311279e-01
    phi[1,2]  R668      -9.0375316143035889e-01
    phi[1,2]  R669      -3.7436237931251526e-01
    phi[1,2]  R670      -9.5088857412338257e-01
    phi[1,2]  R671      -1.2851665019989014e+00
    phi[1,2]  R672      2.9531556367874146e-01
    phi[1,2]  R673      -1.3479261100292206e-01
    phi[1,2]  R674      1.2790807485580444e+00
    phi[1,2]  R675      9.4388830661773682e-01
    phi[1,2]  R676      -9.1243433952331543e-01
    phi[1,2]  R677      3.2509616017341614e-01
    phi[1,2]  R678      3.8816168904304504e-01
    phi[1,2]  R679      -5.7167583703994751e-01
    phi[1,2]  R680      -1.4952082931995392e-01
    phi[1,2]  R681      -1.7827477455139160e+00
    phi[1,2]  R682      8.9002138376235962e-01
    phi[1,2]  R683      -7.0208579301834106e-01
    phi[1,2]  R684      -5.7080870866775513e-01
    phi[1,2]  R685      -8.1428664922714233e-01
    phi[1,2]  R686      -8.2421147823333740e-01
    phi[1,2]  R687      -1.2658849954605103e+00
    phi[1,2]  R688      -1.2451666593551636e+00
    phi[1,2]  R689      -8.7207537889480591e-01
    phi[1,2]  R690      -1.6020985841751099e+00
    phi[1,2]  R691      -2.4375607073307037e-01
    phi[1,2]  R692      0.434784859418869
    phi[1,2]  R693      -3.6390995979309082e-01
    phi[1,2]  R694      -0.801440417766571
    phi[1,2]  R695      -1.0052677392959595e+00
    phi[1,2]  R696      -1.8508706092834473e+00
    phi[1,2]  R697      -1.8160032033920288e+00
    phi[1,2]  R698      -1.0950264930725098e+00
    phi[1,2]  R699      -2.1402812004089355e+00
    phi[1,2]  R700      -1.9756182432174683e+00
    phi[1,2]  R701      -1.8388160467147827e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R702      -3.0999999046325684e+00
    phi[2,1]  R703      -3.0999999046325684e+00
    phi[2,1]  R704      -2.2400000095367432e+00
    phi[2,1]  R705      -2.2400000095367432e+00
    phi[2,1]  R706      -3.0999999046325684e+00
    phi[2,1]  R707      -3.0999999046325684e+00
    phi[2,1]  R708      -2.5699999332427979e+00
    phi[2,1]  R709      -2.5699999332427979e+00
    phi[2,1]  R710      -3.0999999046325684e+00
    phi[2,1]  R711      -3.0999999046325684e+00
    phi[2,1]  R712      -2.0899999141693115e+00
    phi[2,1]  R713      -2.0899999141693115e+00
    phi[2,1]  R714      -3.0999999046325684e+00
    phi[2,1]  R715      -3.0999999046325684e+00
    phi[2,1]  R716      1.0040894746780396e+00
    phi[2,1]  R717      1.0424926280975342e+00
    phi[2,1]  R718      1.2362130880355835e+00
    phi[2,1]  R719      3.8740894198417664e-01
    phi[2,1]  R720      -0.850970447063446
    phi[2,1]  R721      5.0420272350311279e-01
    phi[2,1]  R722      -9.0375316143035889e-01
    phi[2,1]  R723      -3.7436237931251526e-01
    phi[2,1]  R724      -9.5088857412338257e-01
    phi[2,1]  R725      -1.2851665019989014e+00
    phi[2,1]  R726      2.9531556367874146e-01
    phi[2,1]  R727      -1.3479261100292206e-01
    phi[2,1]  R728      1.2790807485580444e+00
    phi[2,1]  R729      9.4388830661773682e-01
    phi[2,1]  R730      -9.1243433952331543e-01
    phi[2,1]  R731      3.2509616017341614e-01
    phi[2,1]  R732      3.8816168904304504e-01
    phi[2,1]  R733      -5.7167583703994751e-01
    phi[2,1]  R734      -1.4952082931995392e-01
    phi[2,1]  R735      -1.7827477455139160e+00
    phi[2,1]  R736      8.9002138376235962e-01
    phi[2,1]  R737      -7.0208579301834106e-01
    phi[2,1]  R738      -5.7080870866775513e-01
    phi[2,1]  R739      -8.1428664922714233e-01
    phi[2,1]  R740      -8.2421147823333740e-01
    phi[2,1]  R741      -1.2658849954605103e+00
    phi[2,1]  R742      -1.2451666593551636e+00
    phi[2,1]  R743      -8.7207537889480591e-01
    phi[2,1]  R744      -1.6020985841751099e+00
    phi[2,1]  R745      -2.4375607073307037e-01
    phi[2,1]  R746      0.434784859418869
    phi[2,1]  R747      -3.6390995979309082e-01
    phi[2,1]  R748      -0.801440417766571
    phi[2,1]  R749      -1.0052677392959595e+00
    phi[2,1]  R750      -1.8508706092834473e+00
    phi[2,1]  R751      -1.8160032033920288e+00
    phi[2,1]  R752      -1.0950264930725098e+00
    phi[2,1]  R753      -2.1402812004089355e+00
    phi[2,1]  R754      -1.9756182432174683e+00
    phi[2,1]  R755      -1.8388160467147827e+00
    phi[2,1]  R756      1.3283796310424805e+00
    phi[2,1]  R757      4.4072070717811584e-01
    phi[2,1]  R758      1.2819547653198242e+00
    phi[2,1]  R759      8.7914243340492249e-02
    phi[2,1]  R760      -0.544611930847168
    phi[2,1]  R761      6.4580613374710083e-01
    phi[2,1]  R762      1.4211711883544922e+00
    phi[2,1]  R763      -9.2589992284774780e-01
    phi[2,1]  R764      3.9668568968772888e-01
    phi[2,1]  R765      -1.5248523652553558e-01
    phi[2,1]  R766      -3.0745840072631836e+00
    phi[2,1]  R767      -1.1007326841354370e+00
    phi[2,1]  R768      -3.6320359706878662e+00
    phi[2,1]  R769      -3.2099831104278564e+00
    phi[2,1]  R770      6.2592077255249023e-01
    phi[2,1]  R771      -1.5818793326616287e-02
    phi[2,1]  R772      1.4549224376678467e+00
    phi[2,1]  R773      3.3274614810943604e-01
    phi[2,1]  R774      8.0706059932708740e-01
    phi[2,1]  R775      2.0571795105934143e-01
    phi[2,1]  R776      -8.8777565956115723e-01
    phi[2,1]  R777      -8.2806617021560669e-02
    phi[2,1]  R778      -3.0662536621093750e+00
    phi[2,1]  R779      9.2224901914596558e-01
    phi[2,1]  R780      -6.7909665405750275e-02
    phi[2,1]  R781      -1.7560343742370605e+00
    phi[2,1]  R782      -5.6961971521377563e-01
    phi[2,1]  R783      -2.7233130931854248e+00
    phi[2,1]  R784      1.2763316631317139e+00
    phi[2,1]  R785      -3.7004370689392090e+00
    phi[2,1]  R786      3.1837576627731323e-01
    phi[2,1]  R787      2.7808830142021179e-01
    phi[2,1]  R788      -3.2352179288864136e-01
    phi[2,1]  R789      -7.0442932844161987e-01
    phi[2,1]  R790      -0.592222273349762
    phi[2,1]  R791      -2.6170235872268677e-01
    phi[2,1]  R792      -1.2236419916152954e+00
    phi[2,1]  R793      -1.9905123710632324e+00
    phi[2,1]  R794      -0.61787348985672
    phi[2,1]  R795      -3.0949428081512451e+00
    phi[2,1]  R796      -2.0271360874176025e+00
    phi[2,1]  R797      -2.9319512844085693e+00
    phi[2,1]  R798      9.5726318657398224e-02
    phi[2,1]  R799      2.2170491516590118e-01
    phi[2,1]  R800      -5.4358851909637451e-01
    phi[2,1]  R801      -4.2365417480468750e+00
    phi[2,1]  R802      -3.6609203815460205e+00
    phi[2,1]  R803      -3.8620319366455078e+00
    phi[2,1]  R804      -3.21632981300354
    phi[2,1]  R805      -3.0204708576202393e+00
    phi[2,1]  R806      -0.0952332466840744
    phi[2,1]  R807      -9.7577132284641266e-02
    phi[2,1]  R808      -3.4782664775848389e+00
    phi[2,1]  R809      -2.1915462017059326e+00
    phi[2,1]  R810      4.5037499070167542e-01
    phi[2,1]  R811      -1.1935274600982666e+00
    phi[2,1]  R812      -3.2895629405975342e+00
    phi[2,1]  R813      5.0156213343143463e-02
    phi[2,1]  R814      -2.9610803127288818e+00
    phi[2,1]  R815      -1.8369605541229248e+00
    phi[2,1]  R816      -9.6318966150283813e-01
    phi[2,1]  R817      -3.0838625431060791e+00
    phi[2,1]  R818      -7.7979081869125366e-01
    phi[2,1]  R819      -8.9136604219675064e-03
    phi[2,1]  R820      -2.2690973281860352e+00
    phi[2,1]  R821      -2.3988385200500488e+00
    phi[2,1]  R822      -8.5080349445343018e-01
    phi[2,1]  R823      -5.4699756205081940e-02
    phi[2,1]  R824      -2.7444612979888916e+00
    phi[2,1]  R825      -1.2007137387990952e-01
    phi[2,1]  R826      -1.4884338378906250e+00
    phi[2,1]  R827      1.2772685289382935e+00
    phi[2,1]  R828      9.8391062021255493e-01
    phi[2,1]  R829      -3.2103290557861328e+00
    phi[2,1]  R830      -2.85830020904541
    phi[2,1]  R831      -2.9286408424377441e+00
    phi[2,1]  R832      3.2224914431571960e-01
    phi[2,1]  R833      5.9770929813385010e-01
    phi[2,1]  R834      -2.6930193901062012e+00
    phi[2,1]  R835      6.4129781723022461e-01
    phi[1,3]  R9        1
    phi[1,3]  R10       1
    phi[1,3]  R27       -1
    phi[1,3]  R836      -3.0999999046325684e+00
    phi[1,3]  R837      -3.0999999046325684e+00
    phi[1,3]  R838      -2.2400000095367432e+00
    phi[1,3]  R839      -2.2400000095367432e+00
    phi[1,3]  R840      -3.0999999046325684e+00
    phi[1,3]  R841      -3.0999999046325684e+00
    phi[1,3]  R842      -2.5699999332427979e+00
    phi[1,3]  R843      -2.5699999332427979e+00
    phi[1,3]  R844      -3.0999999046325684e+00
    phi[1,3]  R845      -3.0999999046325684e+00
    phi[1,3]  R846      -2.0899999141693115e+00
    phi[1,3]  R847      -2.0899999141693115e+00
    phi[1,3]  R848      -3.0999999046325684e+00
    phi[1,3]  R849      -3.0999999046325684e+00
    phi[1,3]  R850      1.3283796310424805e+00
    phi[1,3]  R851      4.4072070717811584e-01
    phi[1,3]  R852      1.2819547653198242e+00
    phi[1,3]  R853      8.7914243340492249e-02
    phi[1,3]  R854      -0.544611930847168
    phi[1,3]  R855      6.4580613374710083e-01
    phi[1,3]  R856      1.4211711883544922e+00
    phi[1,3]  R857      -9.2589992284774780e-01
    phi[1,3]  R858      3.9668568968772888e-01
    phi[1,3]  R859      -1.5248523652553558e-01
    phi[1,3]  R860      -3.0745840072631836e+00
    phi[1,3]  R861      -1.1007326841354370e+00
    phi[1,3]  R862      -3.6320359706878662e+00
    phi[1,3]  R863      -3.2099831104278564e+00
    phi[1,3]  R864      6.2592077255249023e-01
    phi[1,3]  R865      -1.5818793326616287e-02
    phi[1,3]  R866      1.4549224376678467e+00
    phi[1,3]  R867      3.3274614810943604e-01
    phi[1,3]  R868      8.0706059932708740e-01
    phi[1,3]  R869      2.0571795105934143e-01
    phi[1,3]  R870      -8.8777565956115723e-01
    phi[1,3]  R871      -8.2806617021560669e-02
    phi[1,3]  R872      -3.0662536621093750e+00
    phi[1,3]  R873      9.2224901914596558e-01
    phi[1,3]  R874      -6.7909665405750275e-02
    phi[1,3]  R875      -1.7560343742370605e+00
    phi[1,3]  R876      -5.6961971521377563e-01
    phi[1,3]  R877      -2.7233130931854248e+00
    phi[1,3]  R878      1.2763316631317139e+00
    phi[1,3]  R879      -3.7004370689392090e+00
    phi[1,3]  R880      3.1837576627731323e-01
    phi[1,3]  R881      2.7808830142021179e-01
    phi[1,3]  R882      -3.2352179288864136e-01
    phi[1,3]  R883      -7.0442932844161987e-01
    phi[1,3]  R884      -0.592222273349762
    phi[1,3]  R885      -2.6170235872268677e-01
    phi[1,3]  R886      -1.2236419916152954e+00
    phi[1,3]  R887      -1.9905123710632324e+00
    phi[1,3]  R888      -0.61787348985672
    phi[1,3]  R889      -3.0949428081512451e+00
    phi[1,3]  R890      -2.0271360874176025e+00
    phi[1,3]  R891      -2.9319512844085693e+00
    phi[1,3]  R892      9.5726318657398224e-02
    phi[1,3]  R893      2.2170491516590118e-01
    phi[1,3]  R894      -5.4358851909637451e-01
    phi[1,3]  R895      -4.2365417480468750e+00
    phi[1,3]  R896      -3.6609203815460205e+00
    phi[1,3]  R897      -3.8620319366455078e+00
    phi[1,3]  R898      -3.21632981300354
    phi[1,3]  R899      -3.0204708576202393e+00
    phi[1,3]  R900      -0.0952332466840744
    phi[1,3]  R901      -9.7577132284641266e-02
    phi[1,3]  R902      -3.4782664775848389e+00
    phi[1,3]  R903      -2.1915462017059326e+00
    phi[1,3]  R904      4.5037499070167542e-01
    phi[1,3]  R905      -1.1935274600982666e+00
    phi[1,3]  R906      -3.2895629405975342e+00
    phi[1,3]  R907      5.0156213343143463e-02
    phi[1,3]  R908      -2.9610803127288818e+00
    phi[1,3]  R909      -1.8369605541229248e+00
    phi[1,3]  R910      -9.6318966150283813e-01
    phi[1,3]  R911      -3.0838625431060791e+00
    phi[1,3]  R912      -7.7979081869125366e-01
    phi[1,3]  R913      -8.9136604219675064e-03
    phi[1,3]  R914      -2.2690973281860352e+00
    phi[1,3]  R915      -2.3988385200500488e+00
    phi[1,3]  R916      -8.5080349445343018e-01
    phi[1,3]  R917      -5.4699756205081940e-02
    phi[1,3]  R918      -2.7444612979888916e+00
    phi[1,3]  R919      -1.2007137387990952e-01
    phi[1,3]  R920      -1.4884338378906250e+00
    phi[1,3]  R921      1.2772685289382935e+00
    phi[1,3]  R922      9.8391062021255493e-01
    phi[1,3]  R923      -3.2103290557861328e+00
    phi[1,3]  R924      -2.85830020904541
    phi[1,3]  R925      -2.9286408424377441e+00
    phi[1,3]  R926      3.2224914431571960e-01
    phi[1,3]  R927      5.9770929813385010e-01
    phi[1,3]  R928      -2.6930193901062012e+00
    phi[1,3]  R929      6.4129781723022461e-01
    phi[1,3]  R930      1.5600084066390991e+00
    phi[1,3]  R931      9.4336503744125366e-01
    phi[1,3]  R932      -1.3128930330276489e+00
    phi[1,3]  R933      4.1477048397064209e-01
    phi[1,3]  R934      1.0127704143524170e+00
    phi[1,3]  R935      1.2936652898788452e+00
    phi[1,3]  R936      1.4201967716217041e+00
    phi[1,3]  R937      -2.3890395164489746e+00
    phi[1,3]  R938      1.2943265438079834e+00
    phi[1,3]  R939      -1.6294374465942383e+00
    phi[1,3]  R940      -1.0394927263259888e+00
    phi[1,3]  R941      -1.4359424114227295e+00
    phi[1,3]  R942      -3.5764619708061218e-01
    phi[1,3]  R943      -2.5081818103790283e+00
    phi[1,3]  R944      -2.4175758361816406e+00
    phi[3,1]  R9        -1
    phi[3,1]  R27       1
    phi[3,1]  R28       1
    phi[3,1]  R945      -3.0999999046325684e+00
    phi[3,1]  R946      -3.0999999046325684e+00
    phi[3,1]  R947      -2.2400000095367432e+00
    phi[3,1]  R948      -2.2400000095367432e+00
    phi[3,1]  R949      -3.0999999046325684e+00
    phi[3,1]  R950      -3.0999999046325684e+00
    phi[3,1]  R951      -2.5699999332427979e+00
    phi[3,1]  R952      -2.5699999332427979e+00
    phi[3,1]  R953      -3.0999999046325684e+00
    phi[3,1]  R954      -3.0999999046325684e+00
    phi[3,1]  R955      -2.0899999141693115e+00
    phi[3,1]  R956      -2.0899999141693115e+00
    phi[3,1]  R957      -3.0999999046325684e+00
    phi[3,1]  R958      -3.0999999046325684e+00
    phi[3,1]  R959      1.5600084066390991e+00
    phi[3,1]  R960      9.4336503744125366e-01
    phi[3,1]  R961      -1.3128930330276489e+00
    phi[3,1]  R962      4.1477048397064209e-01
    phi[3,1]  R963      1.0127704143524170e+00
    phi[3,1]  R964      1.2936652898788452e+00
    phi[3,1]  R965      1.4201967716217041e+00
    phi[3,1]  R966      -2.3890395164489746e+00
    phi[3,1]  R967      1.2943265438079834e+00
    phi[3,1]  R968      -1.6294374465942383e+00
    phi[3,1]  R969      -1.0394927263259888e+00
    phi[3,1]  R970      -1.4359424114227295e+00
    phi[3,1]  R971      -3.5764619708061218e-01
    phi[3,1]  R972      -2.5081818103790283e+00
    phi[3,1]  R973      -2.4175758361816406e+00
    phi[3,1]  R974      1.3283796310424805e+00
    phi[3,1]  R975      4.4072070717811584e-01
    phi[3,1]  R976      1.2819547653198242e+00
    phi[3,1]  R977      8.7914243340492249e-02
    phi[3,1]  R978      -0.544611930847168
    phi[3,1]  R979      6.4580613374710083e-01
    phi[3,1]  R980      1.4211711883544922e+00
    phi[3,1]  R981      -9.2589992284774780e-01
    phi[3,1]  R982      3.9668568968772888e-01
    phi[3,1]  R983      -1.5248523652553558e-01
    phi[3,1]  R984      -3.0745840072631836e+00
    phi[3,1]  R985      -1.1007326841354370e+00
    phi[3,1]  R986      -3.6320359706878662e+00
    phi[3,1]  R987      -3.2099831104278564e+00
    phi[3,1]  R988      6.2592077255249023e-01
    phi[3,1]  R989      -1.5818793326616287e-02
    phi[3,1]  R990      1.4549224376678467e+00
    phi[3,1]  R991      3.3274614810943604e-01
    phi[3,1]  R992      8.0706059932708740e-01
    phi[3,1]  R993      2.0571795105934143e-01
    phi[3,1]  R994      -8.8777565956115723e-01
    phi[3,1]  R995      -8.2806617021560669e-02
    phi[3,1]  R996      -3.0662536621093750e+00
    phi[3,1]  R997      9.2224901914596558e-01
    phi[3,1]  R998      -6.7909665405750275e-02
    phi[3,1]  R999      -1.7560343742370605e+00
    phi[3,1]  R1000     -5.6961971521377563e-01
    phi[3,1]  R1001     -2.7233130931854248e+00
    phi[3,1]  R1002     1.2763316631317139e+00
    phi[3,1]  R1003     -3.7004370689392090e+00
    phi[3,1]  R1004     3.1837576627731323e-01
    phi[3,1]  R1005     2.7808830142021179e-01
    phi[3,1]  R1006     -3.2352179288864136e-01
    phi[3,1]  R1007     -7.0442932844161987e-01
    phi[3,1]  R1008     -0.592222273349762
    phi[3,1]  R1009     -2.6170235872268677e-01
    phi[3,1]  R1010     -1.2236419916152954e+00
    phi[3,1]  R1011     -1.9905123710632324e+00
    phi[3,1]  R1012     -0.61787348985672
    phi[3,1]  R1013     -3.0949428081512451e+00
    phi[3,1]  R1014     -2.0271360874176025e+00
    phi[3,1]  R1015     -2.9319512844085693e+00
    phi[3,1]  R1016     9.5726318657398224e-02
    phi[3,1]  R1017     2.2170491516590118e-01
    phi[3,1]  R1018     -5.4358851909637451e-01
    phi[3,1]  R1019     -4.2365417480468750e+00
    phi[3,1]  R1020     -3.6609203815460205e+00
    phi[3,1]  R1021     -3.8620319366455078e+00
    phi[3,1]  R1022     -3.21632981300354
    phi[3,1]  R1023     -3.0204708576202393e+00
    phi[3,1]  R1024     -0.0952332466840744
    phi[3,1]  R1025     -9.7577132284641266e-02
    phi[3,1]  R1026     -3.4782664775848389e+00
    phi[3,1]  R1027     -2.1915462017059326e+00
    phi[3,1]  R1028     4.5037499070167542e-01
    phi[3,1]  R1029     -1.1935274600982666e+00
    phi[3,1]  R1030     -3.2895629405975342e+00
    phi[3,1]  R1031     5.0156213343143463e-02
    phi[3,1]  R1032     -2.9610803127288818e+00
    phi[3,1]  R1033     -1.8369605541229248e+00
    phi[3,1]  R1034     -9.6318966150283813e-01
    phi[3,1]  R1035     -3.0838625431060791e+00
    phi[3,1]  R1036     -7.7979081869125366e-01
    phi[3,1]  R1037     -8.9136604219675064e-03
    phi[3,1]  R1038     -2.2690973281860352e+00
    phi[3,1]  R1039     -2.3988385200500488e+00
    phi[3,1]  R1040     -8.5080349445343018e-01
    phi[3,1]  R1041     -5.4699756205081940e-02
    phi[3,1]  R1042     -2.7444612979888916e+00
    phi[3,1]  R1043     -1.2007137387990952e-01
    phi[3,1]  R1044     -1.4884338378906250e+00
    phi[3,1]  R1045     1.2772685289382935e+00
    phi[3,1]  R1046     9.8391062021255493e-01
    phi[3,1]  R1047     -3.2103290557861328e+00
    phi[3,1]  R1048     -2.85830020904541
    phi[3,1]  R1049     -2.9286408424377441e+00
    phi[3,1]  R1050     3.2224914431571960e-01
    phi[3,1]  R1051     5.9770929813385010e-01
    phi[3,1]  R1052     -2.6930193901062012e+00
    phi[3,1]  R1053     6.4129781723022461e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1054     -3.0999999046325684e+00
    phi[2,3]  R1055     -3.0999999046325684e+00
    phi[2,3]  R1056     -2.2400000095367432e+00
    phi[2,3]  R1057     -2.2400000095367432e+00
    phi[2,3]  R1058     -3.0999999046325684e+00
    phi[2,3]  R1059     -3.0999999046325684e+00
    phi[2,3]  R1060     -2.5699999332427979e+00
    phi[2,3]  R1061     -2.5699999332427979e+00
    phi[2,3]  R1062     -3.0999999046325684e+00
    phi[2,3]  R1063     -3.0999999046325684e+00
    phi[2,3]  R1064     -2.0899999141693115e+00
    phi[2,3]  R1065     -2.0899999141693115e+00
    phi[2,3]  R1066     -3.0999999046325684e+00
    phi[2,3]  R1067     -3.0999999046325684e+00
    phi[2,3]  R1068     1.0040894746780396e+00
    phi[2,3]  R1069     1.0424926280975342e+00
    phi[2,3]  R1070     1.2362130880355835e+00
    phi[2,3]  R1071     3.8740894198417664e-01
    phi[2,3]  R1072     -0.850970447063446
    phi[2,3]  R1073     5.0420272350311279e-01
    phi[2,3]  R1074     -9.0375316143035889e-01
    phi[2,3]  R1075     -3.7436237931251526e-01
    phi[2,3]  R1076     -9.5088857412338257e-01
    phi[2,3]  R1077     -1.2851665019989014e+00
    phi[2,3]  R1078     2.9531556367874146e-01
    phi[2,3]  R1079     -1.3479261100292206e-01
    phi[2,3]  R1080     1.2790807485580444e+00
    phi[2,3]  R1081     9.4388830661773682e-01
    phi[2,3]  R1082     -9.1243433952331543e-01
    phi[2,3]  R1083     3.2509616017341614e-01
    phi[2,3]  R1084     3.8816168904304504e-01
    phi[2,3]  R1085     -5.7167583703994751e-01
    phi[2,3]  R1086     -1.4952082931995392e-01
    phi[2,3]  R1087     -1.7827477455139160e+00
    phi[2,3]  R1088     8.9002138376235962e-01
    phi[2,3]  R1089     -7.0208579301834106e-01
    phi[2,3]  R1090     -5.7080870866775513e-01
    phi[2,3]  R1091     -8.1428664922714233e-01
    phi[2,3]  R1092     -8.2421147823333740e-01
    phi[2,3]  R1093     -1.2658849954605103e+00
    phi[2,3]  R1094     -1.2451666593551636e+00
    phi[2,3]  R1095     -8.7207537889480591e-01
    phi[2,3]  R1096     -1.6020985841751099e+00
    phi[2,3]  R1097     -2.4375607073307037e-01
    phi[2,3]  R1098     0.434784859418869
    phi[2,3]  R1099     -3.6390995979309082e-01
    phi[2,3]  R1100     -0.801440417766571
    phi[2,3]  R1101     -1.0052677392959595e+00
    phi[2,3]  R1102     -1.8508706092834473e+00
    phi[2,3]  R1103     -1.8160032033920288e+00
    phi[2,3]  R1104     -1.0950264930725098e+00
    phi[2,3]  R1105     -2.1402812004089355e+00
    phi[2,3]  R1106     -1.9756182432174683e+00
    phi[2,3]  R1107     -1.8388160467147827e+00
    phi[2,3]  R1108     1.5600084066390991e+00
    phi[2,3]  R1109     9.4336503744125366e-01
    phi[2,3]  R1110     -1.3128930330276489e+00
    phi[2,3]  R1111     4.1477048397064209e-01
    phi[2,3]  R1112     1.0127704143524170e+00
    phi[2,3]  R1113     1.2936652898788452e+00
    phi[2,3]  R1114     1.4201967716217041e+00
    phi[2,3]  R1115     -2.3890395164489746e+00
    phi[2,3]  R1116     1.2943265438079834e+00
    phi[2,3]  R1117     -1.6294374465942383e+00
    phi[2,3]  R1118     -1.0394927263259888e+00
    phi[2,3]  R1119     -1.4359424114227295e+00
    phi[2,3]  R1120     -3.5764619708061218e-01
    phi[2,3]  R1121     -2.5081818103790283e+00
    phi[2,3]  R1122     -2.4175758361816406e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1123     -3.0999999046325684e+00
    phi[3,2]  R1124     -3.0999999046325684e+00
    phi[3,2]  R1125     -2.2400000095367432e+00
    phi[3,2]  R1126     -2.2400000095367432e+00
    phi[3,2]  R1127     -3.0999999046325684e+00
    phi[3,2]  R1128     -3.0999999046325684e+00
    phi[3,2]  R1129     -2.5699999332427979e+00
    phi[3,2]  R1130     -2.5699999332427979e+00
    phi[3,2]  R1131     -3.0999999046325684e+00
    phi[3,2]  R1132     -3.0999999046325684e+00
    phi[3,2]  R1133     -2.0899999141693115e+00
    phi[3,2]  R1134     -2.0899999141693115e+00
    phi[3,2]  R1135     -3.0999999046325684e+00
    phi[3,2]  R1136     -3.0999999046325684e+00
    phi[3,2]  R1137     1.5600084066390991e+00
    phi[3,2]  R1138     9.4336503744125366e-01
    phi[3,2]  R1139     -1.3128930330276489e+00
    phi[3,2]  R1140     4.1477048397064209e-01
    phi[3,2]  R1141     1.0127704143524170e+00
    phi[3,2]  R1142     1.2936652898788452e+00
    phi[3,2]  R1143     1.4201967716217041e+00
    phi[3,2]  R1144     -2.3890395164489746e+00
    phi[3,2]  R1145     1.2943265438079834e+00
    phi[3,2]  R1146     -1.6294374465942383e+00
    phi[3,2]  R1147     -1.0394927263259888e+00
    phi[3,2]  R1148     -1.4359424114227295e+00
    phi[3,2]  R1149     -3.5764619708061218e-01
    phi[3,2]  R1150     -2.5081818103790283e+00
    phi[3,2]  R1151     -2.4175758361816406e+00
    phi[3,2]  R1152     1.0040894746780396e+00
    phi[3,2]  R1153     1.0424926280975342e+00
    phi[3,2]  R1154     1.2362130880355835e+00
    phi[3,2]  R1155     3.8740894198417664e-01
    phi[3,2]  R1156     -0.850970447063446
    phi[3,2]  R1157     5.0420272350311279e-01
    phi[3,2]  R1158     -9.0375316143035889e-01
    phi[3,2]  R1159     -3.7436237931251526e-01
    phi[3,2]  R1160     -9.5088857412338257e-01
    phi[3,2]  R1161     -1.2851665019989014e+00
    phi[3,2]  R1162     2.9531556367874146e-01
    phi[3,2]  R1163     -1.3479261100292206e-01
    phi[3,2]  R1164     1.2790807485580444e+00
    phi[3,2]  R1165     9.4388830661773682e-01
    phi[3,2]  R1166     -9.1243433952331543e-01
    phi[3,2]  R1167     3.2509616017341614e-01
    phi[3,2]  R1168     3.8816168904304504e-01
    phi[3,2]  R1169     -5.7167583703994751e-01
    phi[3,2]  R1170     -1.4952082931995392e-01
    phi[3,2]  R1171     -1.7827477455139160e+00
    phi[3,2]  R1172     8.9002138376235962e-01
    phi[3,2]  R1173     -7.0208579301834106e-01
    phi[3,2]  R1174     -5.7080870866775513e-01
    phi[3,2]  R1175     -8.1428664922714233e-01
    phi[3,2]  R1176     -8.2421147823333740e-01
    phi[3,2]  R1177     -1.2658849954605103e+00
    phi[3,2]  R1178     -1.2451666593551636e+00
    phi[3,2]  R1179     -8.7207537889480591e-01
    phi[3,2]  R1180     -1.6020985841751099e+00
    phi[3,2]  R1181     -2.4375607073307037e-01
    phi[3,2]  R1182     0.434784859418869
    phi[3,2]  R1183     -3.6390995979309082e-01
    phi[3,2]  R1184     -0.801440417766571
    phi[3,2]  R1185     -1.0052677392959595e+00
    phi[3,2]  R1186     -1.8508706092834473e+00
    phi[3,2]  R1187     -1.8160032033920288e+00
    phi[3,2]  R1188     -1.0950264930725098e+00
    phi[3,2]  R1189     -2.1402812004089355e+00
    phi[3,2]  R1190     -1.9756182432174683e+00
    phi[3,2]  R1191     -1.8388160467147827e+00
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1192     -3.0999999046325684e+00
    phi[2,6]  R1193     -3.0999999046325684e+00
    phi[2,6]  R1194     -2.2400000095367432e+00
    phi[2,6]  R1195     -2.2400000095367432e+00
    phi[2,6]  R1196     -3.0999999046325684e+00
    phi[2,6]  R1197     -3.0999999046325684e+00
    phi[2,6]  R1198     -2.5699999332427979e+00
    phi[2,6]  R1199     -2.5699999332427979e+00
    phi[2,6]  R1200     -3.0999999046325684e+00
    phi[2,6]  R1201     -3.0999999046325684e+00
    phi[2,6]  R1202     -2.0899999141693115e+00
    phi[2,6]  R1203     -2.0899999141693115e+00
    phi[2,6]  R1204     -3.0999999046325684e+00
    phi[2,6]  R1205     -3.0999999046325684e+00
    phi[2,6]  R1206     1.0040894746780396e+00
    phi[2,6]  R1207     1.0424926280975342e+00
    phi[2,6]  R1208     1.2362130880355835e+00
    phi[2,6]  R1209     3.8740894198417664e-01
    phi[2,6]  R1210     -0.850970447063446
    phi[2,6]  R1211     5.0420272350311279e-01
    phi[2,6]  R1212     -9.0375316143035889e-01
    phi[2,6]  R1213     -3.7436237931251526e-01
    phi[2,6]  R1214     -9.5088857412338257e-01
    phi[2,6]  R1215     -1.2851665019989014e+00
    phi[2,6]  R1216     2.9531556367874146e-01
    phi[2,6]  R1217     -1.3479261100292206e-01
    phi[2,6]  R1218     1.2790807485580444e+00
    phi[2,6]  R1219     9.4388830661773682e-01
    phi[2,6]  R1220     -9.1243433952331543e-01
    phi[2,6]  R1221     3.2509616017341614e-01
    phi[2,6]  R1222     3.8816168904304504e-01
    phi[2,6]  R1223     -5.7167583703994751e-01
    phi[2,6]  R1224     -1.4952082931995392e-01
    phi[2,6]  R1225     -1.7827477455139160e+00
    phi[2,6]  R1226     8.9002138376235962e-01
    phi[2,6]  R1227     -7.0208579301834106e-01
    phi[2,6]  R1228     -5.7080870866775513e-01
    phi[2,6]  R1229     -8.1428664922714233e-01
    phi[2,6]  R1230     -8.2421147823333740e-01
    phi[2,6]  R1231     -1.2658849954605103e+00
    phi[2,6]  R1232     -1.2451666593551636e+00
    phi[2,6]  R1233     -8.7207537889480591e-01
    phi[2,6]  R1234     -1.6020985841751099e+00
    phi[2,6]  R1235     -2.4375607073307037e-01
    phi[2,6]  R1236     0.434784859418869
    phi[2,6]  R1237     -3.6390995979309082e-01
    phi[2,6]  R1238     -0.801440417766571
    phi[2,6]  R1239     -1.0052677392959595e+00
    phi[2,6]  R1240     -1.8508706092834473e+00
    phi[2,6]  R1241     -1.8160032033920288e+00
    phi[2,6]  R1242     -1.0950264930725098e+00
    phi[2,6]  R1243     -2.1402812004089355e+00
    phi[2,6]  R1244     -1.9756182432174683e+00
    phi[2,6]  R1245     -1.8388160467147827e+00
    phi[2,6]  R1246     0.917249321937561
    phi[2,6]  R1247     6.7110764980316162e-01
    phi[2,6]  R1248     6.9638466835021973e-01
    phi[2,6]  R1249     1.1149033308029175e+00
    phi[2,6]  R1250     7.5205254554748535e-01
    phi[2,6]  R1251     4.4133463501930237e-01
    phi[2,6]  R1252     1.1141712665557861e+00
    phi[2,6]  R1253     1.0362817049026489e+00
    phi[2,6]  R1254     7.4518150091171265e-01
    phi[2,6]  R1255     6.2080383300781250e-01
    phi[2,6]  R1256     -1.0984357595443726e+00
    phi[2,6]  R1257     -4.9764358997344971e-01
    phi[2,6]  R1258     -1.6419972181320190e+00
    phi[2,6]  R1259     -1.5035352706909180e+00
    phi[2,6]  R1260     -2.6824991703033447e+00
    phi[2,6]  R1261     -1.3900750875473022e+00
    phi[2,6]  R1262     -2.4424611032009125e-01
    phi[2,6]  R1263     -1.5501182079315186e+00
    phi[2,6]  R1264     -1.2427994012832642e+00
    phi[2,6]  R1265     -7.4001765251159668e-01
    phi[2,6]  R1266     -1.5559186935424805e+00
    phi[2,6]  R1267     -1.4434924125671387e+00
    phi[2,6]  R1268     -2.5029923915863037e+00
    phi[2,6]  R1269     -2.8726518154144287e+00
    phi[2,6]  R1270     -3.1387231349945068e+00
    phi[2,6]  R1271     -2.1342675685882568e+00
    phi[2,6]  R1272     -1.9238809347152710e+00
    phi[2,6]  R1273     -0.668778657913208
    phi[2,6]  R1274     -2.8994650840759277e+00
    phi[2,6]  R1275     -7.6136386394500732e-01
    phi[2,6]  R1276     -9.8096543550491333e-01
    phi[2,6]  R1277     -1.5009375810623169e+00
    phi[2,6]  R1278     -1.9809985160827637e+00
    phi[2,6]  R1279     -2.1637823581695557e+00
    phi[2,6]  R1280     -2.5295886993408203e+00
    phi[2,6]  R1281     -2.2102041244506836e+00
    phi[2,6]  R1282     -1.9405622482299805e+00
    phi[2,6]  R1283     -2.1831164360046387e+00
    phi[2,6]  R1284     -2.0480155944824219e+00
    phi[2,6]  R1285     -3.9362147450447083e-02
    phi[2,6]  R1286     -1.1552461385726929e+00
    phi[2,6]  R1287     -1.7038813829421997e+00
    phi[2,6]  R1288     -1.3765782117843628e+00
    phi[2,6]  R1289     -8.6234229803085327e-01
    phi[2,6]  R1290     -1.9150154590606689e+00
    phi[2,6]  R1291     -1.5264697074890137e+00
    phi[2,6]  R1292     -1.5208266973495483e+00
    phi[2,6]  R1293     -1.7068926095962524e+00
    phi[2,6]  R1294     1.9326537847518921e-01
    phi[2,6]  R1295     -2.9780147075653076e+00
    phi[2,6]  R1296     4.3472588062286377e-02
    phi[2,6]  R1297     -1.5105020999908447e+00
    phi[2,6]  R1298     -9.7373247146606445e-01
    phi[2,6]  R1299     -2.0487370491027832e+00
    phi[2,6]  R1300     -1.5901628732681274e+00
    phi[2,6]  R1301     -1.1715462207794189e+00
    phi[2,6]  R1302     -2.3735306262969971e+00
    phi[2,6]  R1303     -2.1843566894531250e+00
    phi[2,6]  R1304     1.9033473730087280e-01
    phi[2,6]  R1305     -5.0295501947402954e-01
    phi[2,6]  R1306     -1.0164351463317871e+00
    phi[2,6]  R1307     -8.5414963960647583e-01
    phi[2,6]  R1308     -2.5340640544891357e+00
    phi[2,6]  R1309     -2.6598623394966125e-01
    phi[2,6]  R1310     4.4882947206497192e-01
    phi[2,6]  R1311     -1.3391474485397339e+00
    phi[2,6]  R1312     -2.6511619091033936e+00
    phi[2,6]  R1313     -2.7533385753631592e+00
    phi[2,6]  R1314     -5.2383834123611450e-01
    phi[2,6]  R1315     -2.2017860412597656e+00
    phi[2,6]  R1316     -2.2278268337249756e+00
    phi[2,6]  R1317     -0.563535749912262
    phi[2,6]  R1318     -1.0979350805282593e+00
    phi[2,6]  R1319     7.7820581197738647e-01
    phi[2,6]  R1320     -1.9514373540878296e+00
    phi[2,6]  R1321     -1.2126215696334839e+00
    phi[2,6]  R1322     -4.3799281120300293e-01
    phi[2,6]  R1323     -2.1205651760101318e+00
    phi[2,6]  R1324     1.1333760023117065e+00
    phi[2,6]  R1325     -1.7122483253479004e-01
    phi[2,6]  R1326     1.2913167476654053e+00
    phi[2,6]  R1327     -1.9848085641860962e+00
    phi[2,6]  R1328     -5.4888319969177246e-01
    phi[2,6]  R1329     -1.2556456327438354e+00
    phi[2,6]  R1330     -2.8660969734191895e+00
    phi[2,6]  R1331     -2.1460925042629242e-01
    phi[2,6]  R1332     -1.28054940700531
    phi[2,6]  R1333     -1.2796907424926758e+00
    phi[2,6]  R1334     -9.5194809138774872e-02
    phi[2,6]  R1335     -4.9208766222000122e-01
    phi[2,6]  R1336     9.8959583044052124e-01
    phi[2,6]  R1337     -2.0442612171173096e+00
    phi[2,6]  R1338     -1.4554131031036377e+00
    phi[2,6]  R1339     -2.4189256131649017e-01
    phi[2,6]  R1340     -1.9648689031600952e+00
    phi[2,6]  R1341     -2.9148730635643005e-01
    phi[2,6]  R1342     -8.8934665918350220e-01
    phi[2,6]  R1343     -2.1878080368041992e+00
    phi[2,6]  R1344     -8.4650105237960815e-01
    phi[2,6]  R1345     -1.0171432495117188e+00
    phi[2,6]  R1346     -1.4771615266799927e+00
    phi[2,6]  R1347     -1.0705137252807617e+00
    phi[2,6]  R1348     -1.4200100898742676e+00
    phi[2,6]  R1349     -3.3985075354576111e-01
    phi[2,6]  R1350     -0.466865211725235
    phi[2,6]  R1351     -5.1214151084423065e-02
    phi[2,6]  R1352     -3.6568677425384521e-01
    phi[2,6]  R1353     -1.0456889867782593e+00
    phi[2,6]  R1354     -8.1152600049972534e-01
    phi[2,6]  R1355     -7.6313740015029907e-01
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1356     -3.0999999046325684e+00
    phi[6,2]  R1357     -3.0999999046325684e+00
    phi[6,2]  R1358     -2.2400000095367432e+00
    phi[6,2]  R1359     -2.2400000095367432e+00
    phi[6,2]  R1360     -3.0999999046325684e+00
    phi[6,2]  R1361     -3.0999999046325684e+00
    phi[6,2]  R1362     -2.5699999332427979e+00
    phi[6,2]  R1363     -2.5699999332427979e+00
    phi[6,2]  R1364     -3.0999999046325684e+00
    phi[6,2]  R1365     -3.0999999046325684e+00
    phi[6,2]  R1366     -2.0899999141693115e+00
    phi[6,2]  R1367     -2.0899999141693115e+00
    phi[6,2]  R1368     -3.0999999046325684e+00
    phi[6,2]  R1369     -3.0999999046325684e+00
    phi[6,2]  R1370     0.917249321937561
    phi[6,2]  R1371     6.7110764980316162e-01
    phi[6,2]  R1372     6.9638466835021973e-01
    phi[6,2]  R1373     1.1149033308029175e+00
    phi[6,2]  R1374     7.5205254554748535e-01
    phi[6,2]  R1375     4.4133463501930237e-01
    phi[6,2]  R1376     1.1141712665557861e+00
    phi[6,2]  R1377     1.0362817049026489e+00
    phi[6,2]  R1378     7.4518150091171265e-01
    phi[6,2]  R1379     6.2080383300781250e-01
    phi[6,2]  R1380     -1.0984357595443726e+00
    phi[6,2]  R1381     -4.9764358997344971e-01
    phi[6,2]  R1382     -1.6419972181320190e+00
    phi[6,2]  R1383     -1.5035352706909180e+00
    phi[6,2]  R1384     -2.6824991703033447e+00
    phi[6,2]  R1385     -1.3900750875473022e+00
    phi[6,2]  R1386     -2.4424611032009125e-01
    phi[6,2]  R1387     -1.5501182079315186e+00
    phi[6,2]  R1388     -1.2427994012832642e+00
    phi[6,2]  R1389     -7.4001765251159668e-01
    phi[6,2]  R1390     -1.5559186935424805e+00
    phi[6,2]  R1391     -1.4434924125671387e+00
    phi[6,2]  R1392     -2.5029923915863037e+00
    phi[6,2]  R1393     -2.8726518154144287e+00
    phi[6,2]  R1394     -3.1387231349945068e+00
    phi[6,2]  R1395     -2.1342675685882568e+00
    phi[6,2]  R1396     -1.9238809347152710e+00
    phi[6,2]  R1397     -0.668778657913208
    phi[6,2]  R1398     -2.8994650840759277e+00
    phi[6,2]  R1399     -7.6136386394500732e-01
    phi[6,2]  R1400     -9.8096543550491333e-01
    phi[6,2]  R1401     -1.5009375810623169e+00
    phi[6,2]  R1402     -1.9809985160827637e+00
    phi[6,2]  R1403     -2.1637823581695557e+00
    phi[6,2]  R1404     -2.5295886993408203e+00
    phi[6,2]  R1405     -2.2102041244506836e+00
    phi[6,2]  R1406     -1.9405622482299805e+00
    phi[6,2]  R1407     -2.1831164360046387e+00
    phi[6,2]  R1408     -2.0480155944824219e+00
    phi[6,2]  R1409     -3.9362147450447083e-02
    phi[6,2]  R1410     -1.1552461385726929e+00
    phi[6,2]  R1411     -1.7038813829421997e+00
    phi[6,2]  R1412     -1.3765782117843628e+00
    phi[6,2]  R1413     -8.6234229803085327e-01
    phi[6,2]  R1414     -1.9150154590606689e+00
    phi[6,2]  R1415     -1.5264697074890137e+00
    phi[6,2]  R1416     -1.5208266973495483e+00
    phi[6,2]  R1417     -1.7068926095962524e+00
    phi[6,2]  R1418     1.9326537847518921e-01
    phi[6,2]  R1419     -2.9780147075653076e+00
    phi[6,2]  R1420     4.3472588062286377e-02
    phi[6,2]  R1421     -1.5105020999908447e+00
    phi[6,2]  R1422     -9.7373247146606445e-01
    phi[6,2]  R1423     -2.0487370491027832e+00
    phi[6,2]  R1424     -1.5901628732681274e+00
    phi[6,2]  R1425     -1.1715462207794189e+00
    phi[6,2]  R1426     -2.3735306262969971e+00
    phi[6,2]  R1427     -2.1843566894531250e+00
    phi[6,2]  R1428     1.9033473730087280e-01
    phi[6,2]  R1429     -5.0295501947402954e-01
    phi[6,2]  R1430     -1.0164351463317871e+00
    phi[6,2]  R1431     -8.5414963960647583e-01
    phi[6,2]  R1432     -2.5340640544891357e+00
    phi[6,2]  R1433     -2.6598623394966125e-01
    phi[6,2]  R1434     4.4882947206497192e-01
    phi[6,2]  R1435     -1.3391474485397339e+00
    phi[6,2]  R1436     -2.6511619091033936e+00
    phi[6,2]  R1437     -2.7533385753631592e+00
    phi[6,2]  R1438     -5.2383834123611450e-01
    phi[6,2]  R1439     -2.2017860412597656e+00
    phi[6,2]  R1440     -2.2278268337249756e+00
    phi[6,2]  R1441     -0.563535749912262
    phi[6,2]  R1442     -1.0979350805282593e+00
    phi[6,2]  R1443     7.7820581197738647e-01
    phi[6,2]  R1444     -1.9514373540878296e+00
    phi[6,2]  R1445     -1.2126215696334839e+00
    phi[6,2]  R1446     -4.3799281120300293e-01
    phi[6,2]  R1447     -2.1205651760101318e+00
    phi[6,2]  R1448     1.1333760023117065e+00
    phi[6,2]  R1449     -1.7122483253479004e-01
    phi[6,2]  R1450     1.2913167476654053e+00
    phi[6,2]  R1451     -1.9848085641860962e+00
    phi[6,2]  R1452     -5.4888319969177246e-01
    phi[6,2]  R1453     -1.2556456327438354e+00
    phi[6,2]  R1454     -2.8660969734191895e+00
    phi[6,2]  R1455     -2.1460925042629242e-01
    phi[6,2]  R1456     -1.28054940700531
    phi[6,2]  R1457     -1.2796907424926758e+00
    phi[6,2]  R1458     -9.5194809138774872e-02
    phi[6,2]  R1459     -4.9208766222000122e-01
    phi[6,2]  R1460     9.8959583044052124e-01
    phi[6,2]  R1461     -2.0442612171173096e+00
    phi[6,2]  R1462     -1.4554131031036377e+00
    phi[6,2]  R1463     -2.4189256131649017e-01
    phi[6,2]  R1464     -1.9648689031600952e+00
    phi[6,2]  R1465     -2.9148730635643005e-01
    phi[6,2]  R1466     -8.8934665918350220e-01
    phi[6,2]  R1467     -2.1878080368041992e+00
    phi[6,2]  R1468     -8.4650105237960815e-01
    phi[6,2]  R1469     -1.0171432495117188e+00
    phi[6,2]  R1470     -1.4771615266799927e+00
    phi[6,2]  R1471     -1.0705137252807617e+00
    phi[6,2]  R1472     -1.4200100898742676e+00
    phi[6,2]  R1473     -3.3985075354576111e-01
    phi[6,2]  R1474     -0.466865211725235
    phi[6,2]  R1475     -5.1214151084423065e-02
    phi[6,2]  R1476     -3.6568677425384521e-01
    phi[6,2]  R1477     -1.0456889867782593e+00
    phi[6,2]  R1478     -8.1152600049972534e-01
    phi[6,2]  R1479     -7.6313740015029907e-01
    phi[6,2]  R1480     1.0040894746780396e+00
    phi[6,2]  R1481     1.0424926280975342e+00
    phi[6,2]  R1482     1.2362130880355835e+00
    phi[6,2]  R1483     3.8740894198417664e-01
    phi[6,2]  R1484     -0.850970447063446
    phi[6,2]  R1485     5.0420272350311279e-01
    phi[6,2]  R1486     -9.0375316143035889e-01
    phi[6,2]  R1487     -3.7436237931251526e-01
    phi[6,2]  R1488     -9.5088857412338257e-01
    phi[6,2]  R1489     -1.2851665019989014e+00
    phi[6,2]  R1490     2.9531556367874146e-01
    phi[6,2]  R1491     -1.3479261100292206e-01
    phi[6,2]  R1492     1.2790807485580444e+00
    phi[6,2]  R1493     9.4388830661773682e-01
    phi[6,2]  R1494     -9.1243433952331543e-01
    phi[6,2]  R1495     3.2509616017341614e-01
    phi[6,2]  R1496     3.8816168904304504e-01
    phi[6,2]  R1497     -5.7167583703994751e-01
    phi[6,2]  R1498     -1.4952082931995392e-01
    phi[6,2]  R1499     -1.7827477455139160e+00
    phi[6,2]  R1500     8.9002138376235962e-01
    phi[6,2]  R1501     -7.0208579301834106e-01
    phi[6,2]  R1502     -5.7080870866775513e-01
    phi[6,2]  R1503     -8.1428664922714233e-01
    phi[6,2]  R1504     -8.2421147823333740e-01
    phi[6,2]  R1505     -1.2658849954605103e+00
    phi[6,2]  R1506     -1.2451666593551636e+00
    phi[6,2]  R1507     -8.7207537889480591e-01
    phi[6,2]  R1508     -1.6020985841751099e+00
    phi[6,2]  R1509     -2.4375607073307037e-01
    phi[6,2]  R1510     0.434784859418869
    phi[6,2]  R1511     -3.6390995979309082e-01
    phi[6,2]  R1512     -0.801440417766571
    phi[6,2]  R1513     -1.0052677392959595e+00
    phi[6,2]  R1514     -1.8508706092834473e+00
    phi[6,2]  R1515     -1.8160032033920288e+00
    phi[6,2]  R1516     -1.0950264930725098e+00
    phi[6,2]  R1517     -2.1402812004089355e+00
    phi[6,2]  R1518     -1.9756182432174683e+00
    phi[6,2]  R1519     -1.8388160467147827e+00
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1520     -3.0999999046325684e+00
    phi[3,6]  R1521     -3.0999999046325684e+00
    phi[3,6]  R1522     -2.2400000095367432e+00
    phi[3,6]  R1523     -2.2400000095367432e+00
    phi[3,6]  R1524     -3.0999999046325684e+00
    phi[3,6]  R1525     -3.0999999046325684e+00
    phi[3,6]  R1526     -2.5699999332427979e+00
    phi[3,6]  R1527     -2.5699999332427979e+00
    phi[3,6]  R1528     -3.0999999046325684e+00
    phi[3,6]  R1529     -3.0999999046325684e+00
    phi[3,6]  R1530     -2.0899999141693115e+00
    phi[3,6]  R1531     -2.0899999141693115e+00
    phi[3,6]  R1532     -3.0999999046325684e+00
    phi[3,6]  R1533     -3.0999999046325684e+00
    phi[3,6]  R1534     1.5600084066390991e+00
    phi[3,6]  R1535     9.4336503744125366e-01
    phi[3,6]  R1536     -1.3128930330276489e+00
    phi[3,6]  R1537     4.1477048397064209e-01
    phi[3,6]  R1538     1.0127704143524170e+00
    phi[3,6]  R1539     1.2936652898788452e+00
    phi[3,6]  R1540     1.4201967716217041e+00
    phi[3,6]  R1541     -2.3890395164489746e+00
    phi[3,6]  R1542     1.2943265438079834e+00
    phi[3,6]  R1543     -1.6294374465942383e+00
    phi[3,6]  R1544     -1.0394927263259888e+00
    phi[3,6]  R1545     -1.4359424114227295e+00
    phi[3,6]  R1546     -3.5764619708061218e-01
    phi[3,6]  R1547     -2.5081818103790283e+00
    phi[3,6]  R1548     -2.4175758361816406e+00
    phi[3,6]  R1549     0.917249321937561
    phi[3,6]  R1550     6.7110764980316162e-01
    phi[3,6]  R1551     6.9638466835021973e-01
    phi[3,6]  R1552     1.1149033308029175e+00
    phi[3,6]  R1553     7.5205254554748535e-01
    phi[3,6]  R1554     4.4133463501930237e-01
    phi[3,6]  R1555     1.1141712665557861e+00
    phi[3,6]  R1556     1.0362817049026489e+00
    phi[3,6]  R1557     7.4518150091171265e-01
    phi[3,6]  R1558     6.2080383300781250e-01
    phi[3,6]  R1559     -1.0984357595443726e+00
    phi[3,6]  R1560     -4.9764358997344971e-01
    phi[3,6]  R1561     -1.6419972181320190e+00
    phi[3,6]  R1562     -1.5035352706909180e+00
    phi[3,6]  R1563     -2.6824991703033447e+00
    phi[3,6]  R1564     -1.3900750875473022e+00
    phi[3,6]  R1565     -2.4424611032009125e-01
    phi[3,6]  R1566     -1.5501182079315186e+00
    phi[3,6]  R1567     -1.2427994012832642e+00
    phi[3,6]  R1568     -7.4001765251159668e-01
    phi[3,6]  R1569     -1.5559186935424805e+00
    phi[3,6]  R1570     -1.4434924125671387e+00
    phi[3,6]  R1571     -2.5029923915863037e+00
    phi[3,6]  R1572     -2.8726518154144287e+00
    phi[3,6]  R1573     -3.1387231349945068e+00
    phi[3,6]  R1574     -2.1342675685882568e+00
    phi[3,6]  R1575     -1.9238809347152710e+00
    phi[3,6]  R1576     -0.668778657913208
    phi[3,6]  R1577     -2.8994650840759277e+00
    phi[3,6]  R1578     -7.6136386394500732e-01
    phi[3,6]  R1579     -9.8096543550491333e-01
    phi[3,6]  R1580     -1.5009375810623169e+00
    phi[3,6]  R1581     -1.9809985160827637e+00
    phi[3,6]  R1582     -2.1637823581695557e+00
    phi[3,6]  R1583     -2.5295886993408203e+00
    phi[3,6]  R1584     -2.2102041244506836e+00
    phi[3,6]  R1585     -1.9405622482299805e+00
    phi[3,6]  R1586     -2.1831164360046387e+00
    phi[3,6]  R1587     -2.0480155944824219e+00
    phi[3,6]  R1588     -3.9362147450447083e-02
    phi[3,6]  R1589     -1.1552461385726929e+00
    phi[3,6]  R1590     -1.7038813829421997e+00
    phi[3,6]  R1591     -1.3765782117843628e+00
    phi[3,6]  R1592     -8.6234229803085327e-01
    phi[3,6]  R1593     -1.9150154590606689e+00
    phi[3,6]  R1594     -1.5264697074890137e+00
    phi[3,6]  R1595     -1.5208266973495483e+00
    phi[3,6]  R1596     -1.7068926095962524e+00
    phi[3,6]  R1597     1.9326537847518921e-01
    phi[3,6]  R1598     -2.9780147075653076e+00
    phi[3,6]  R1599     4.3472588062286377e-02
    phi[3,6]  R1600     -1.5105020999908447e+00
    phi[3,6]  R1601     -9.7373247146606445e-01
    phi[3,6]  R1602     -2.0487370491027832e+00
    phi[3,6]  R1603     -1.5901628732681274e+00
    phi[3,6]  R1604     -1.1715462207794189e+00
    phi[3,6]  R1605     -2.3735306262969971e+00
    phi[3,6]  R1606     -2.1843566894531250e+00
    phi[3,6]  R1607     1.9033473730087280e-01
    phi[3,6]  R1608     -5.0295501947402954e-01
    phi[3,6]  R1609     -1.0164351463317871e+00
    phi[3,6]  R1610     -8.5414963960647583e-01
    phi[3,6]  R1611     -2.5340640544891357e+00
    phi[3,6]  R1612     -2.6598623394966125e-01
    phi[3,6]  R1613     4.4882947206497192e-01
    phi[3,6]  R1614     -1.3391474485397339e+00
    phi[3,6]  R1615     -2.6511619091033936e+00
    phi[3,6]  R1616     -2.7533385753631592e+00
    phi[3,6]  R1617     -5.2383834123611450e-01
    phi[3,6]  R1618     -2.2017860412597656e+00
    phi[3,6]  R1619     -2.2278268337249756e+00
    phi[3,6]  R1620     -0.563535749912262
    phi[3,6]  R1621     -1.0979350805282593e+00
    phi[3,6]  R1622     7.7820581197738647e-01
    phi[3,6]  R1623     -1.9514373540878296e+00
    phi[3,6]  R1624     -1.2126215696334839e+00
    phi[3,6]  R1625     -4.3799281120300293e-01
    phi[3,6]  R1626     -2.1205651760101318e+00
    phi[3,6]  R1627     1.1333760023117065e+00
    phi[3,6]  R1628     -1.7122483253479004e-01
    phi[3,6]  R1629     1.2913167476654053e+00
    phi[3,6]  R1630     -1.9848085641860962e+00
    phi[3,6]  R1631     -5.4888319969177246e-01
    phi[3,6]  R1632     -1.2556456327438354e+00
    phi[3,6]  R1633     -2.8660969734191895e+00
    phi[3,6]  R1634     -2.1460925042629242e-01
    phi[3,6]  R1635     -1.28054940700531
    phi[3,6]  R1636     -1.2796907424926758e+00
    phi[3,6]  R1637     -9.5194809138774872e-02
    phi[3,6]  R1638     -4.9208766222000122e-01
    phi[3,6]  R1639     9.8959583044052124e-01
    phi[3,6]  R1640     -2.0442612171173096e+00
    phi[3,6]  R1641     -1.4554131031036377e+00
    phi[3,6]  R1642     -2.4189256131649017e-01
    phi[3,6]  R1643     -1.9648689031600952e+00
    phi[3,6]  R1644     -2.9148730635643005e-01
    phi[3,6]  R1645     -8.8934665918350220e-01
    phi[3,6]  R1646     -2.1878080368041992e+00
    phi[3,6]  R1647     -8.4650105237960815e-01
    phi[3,6]  R1648     -1.0171432495117188e+00
    phi[3,6]  R1649     -1.4771615266799927e+00
    phi[3,6]  R1650     -1.0705137252807617e+00
    phi[3,6]  R1651     -1.4200100898742676e+00
    phi[3,6]  R1652     -3.3985075354576111e-01
    phi[3,6]  R1653     -0.466865211725235
    phi[3,6]  R1654     -5.1214151084423065e-02
    phi[3,6]  R1655     -3.6568677425384521e-01
    phi[3,6]  R1656     -1.0456889867782593e+00
    phi[3,6]  R1657     -8.1152600049972534e-01
    phi[3,6]  R1658     -7.6313740015029907e-01
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1659     -3.0999999046325684e+00
    phi[6,3]  R1660     -3.0999999046325684e+00
    phi[6,3]  R1661     -2.2400000095367432e+00
    phi[6,3]  R1662     -2.2400000095367432e+00
    phi[6,3]  R1663     -3.0999999046325684e+00
    phi[6,3]  R1664     -3.0999999046325684e+00
    phi[6,3]  R1665     -2.5699999332427979e+00
    phi[6,3]  R1666     -2.5699999332427979e+00
    phi[6,3]  R1667     -3.0999999046325684e+00
    phi[6,3]  R1668     -3.0999999046325684e+00
    phi[6,3]  R1669     -2.0899999141693115e+00
    phi[6,3]  R1670     -2.0899999141693115e+00
    phi[6,3]  R1671     -3.0999999046325684e+00
    phi[6,3]  R1672     -3.0999999046325684e+00
    phi[6,3]  R1673     0.917249321937561
    phi[6,3]  R1674     6.7110764980316162e-01
    phi[6,3]  R1675     6.9638466835021973e-01
    phi[6,3]  R1676     1.1149033308029175e+00
    phi[6,3]  R1677     7.5205254554748535e-01
    phi[6,3]  R1678     4.4133463501930237e-01
    phi[6,3]  R1679     1.1141712665557861e+00
    phi[6,3]  R1680     1.0362817049026489e+00
    phi[6,3]  R1681     7.4518150091171265e-01
    phi[6,3]  R1682     6.2080383300781250e-01
    phi[6,3]  R1683     -1.0984357595443726e+00
    phi[6,3]  R1684     -4.9764358997344971e-01
    phi[6,3]  R1685     -1.6419972181320190e+00
    phi[6,3]  R1686     -1.5035352706909180e+00
    phi[6,3]  R1687     -2.6824991703033447e+00
    phi[6,3]  R1688     -1.3900750875473022e+00
    phi[6,3]  R1689     -2.4424611032009125e-01
    phi[6,3]  R1690     -1.5501182079315186e+00
    phi[6,3]  R1691     -1.2427994012832642e+00
    phi[6,3]  R1692     -7.4001765251159668e-01
    phi[6,3]  R1693     -1.5559186935424805e+00
    phi[6,3]  R1694     -1.4434924125671387e+00
    phi[6,3]  R1695     -2.5029923915863037e+00
    phi[6,3]  R1696     -2.8726518154144287e+00
    phi[6,3]  R1697     -3.1387231349945068e+00
    phi[6,3]  R1698     -2.1342675685882568e+00
    phi[6,3]  R1699     -1.9238809347152710e+00
    phi[6,3]  R1700     -0.668778657913208
    phi[6,3]  R1701     -2.8994650840759277e+00
    phi[6,3]  R1702     -7.6136386394500732e-01
    phi[6,3]  R1703     -9.8096543550491333e-01
    phi[6,3]  R1704     -1.5009375810623169e+00
    phi[6,3]  R1705     -1.9809985160827637e+00
    phi[6,3]  R1706     -2.1637823581695557e+00
    phi[6,3]  R1707     -2.5295886993408203e+00
    phi[6,3]  R1708     -2.2102041244506836e+00
    phi[6,3]  R1709     -1.9405622482299805e+00
    phi[6,3]  R1710     -2.1831164360046387e+00
    phi[6,3]  R1711     -2.0480155944824219e+00
    phi[6,3]  R1712     -3.9362147450447083e-02
    phi[6,3]  R1713     -1.1552461385726929e+00
    phi[6,3]  R1714     -1.7038813829421997e+00
    phi[6,3]  R1715     -1.3765782117843628e+00
    phi[6,3]  R1716     -8.6234229803085327e-01
    phi[6,3]  R1717     -1.9150154590606689e+00
    phi[6,3]  R1718     -1.5264697074890137e+00
    phi[6,3]  R1719     -1.5208266973495483e+00
    phi[6,3]  R1720     -1.7068926095962524e+00
    phi[6,3]  R1721     1.9326537847518921e-01
    phi[6,3]  R1722     -2.9780147075653076e+00
    phi[6,3]  R1723     4.3472588062286377e-02
    phi[6,3]  R1724     -1.5105020999908447e+00
    phi[6,3]  R1725     -9.7373247146606445e-01
    phi[6,3]  R1726     -2.0487370491027832e+00
    phi[6,3]  R1727     -1.5901628732681274e+00
    phi[6,3]  R1728     -1.1715462207794189e+00
    phi[6,3]  R1729     -2.3735306262969971e+00
    phi[6,3]  R1730     -2.1843566894531250e+00
    phi[6,3]  R1731     1.9033473730087280e-01
    phi[6,3]  R1732     -5.0295501947402954e-01
    phi[6,3]  R1733     -1.0164351463317871e+00
    phi[6,3]  R1734     -8.5414963960647583e-01
    phi[6,3]  R1735     -2.5340640544891357e+00
    phi[6,3]  R1736     -2.6598623394966125e-01
    phi[6,3]  R1737     4.4882947206497192e-01
    phi[6,3]  R1738     -1.3391474485397339e+00
    phi[6,3]  R1739     -2.6511619091033936e+00
    phi[6,3]  R1740     -2.7533385753631592e+00
    phi[6,3]  R1741     -5.2383834123611450e-01
    phi[6,3]  R1742     -2.2017860412597656e+00
    phi[6,3]  R1743     -2.2278268337249756e+00
    phi[6,3]  R1744     -0.563535749912262
    phi[6,3]  R1745     -1.0979350805282593e+00
    phi[6,3]  R1746     7.7820581197738647e-01
    phi[6,3]  R1747     -1.9514373540878296e+00
    phi[6,3]  R1748     -1.2126215696334839e+00
    phi[6,3]  R1749     -4.3799281120300293e-01
    phi[6,3]  R1750     -2.1205651760101318e+00
    phi[6,3]  R1751     1.1333760023117065e+00
    phi[6,3]  R1752     -1.7122483253479004e-01
    phi[6,3]  R1753     1.2913167476654053e+00
    phi[6,3]  R1754     -1.9848085641860962e+00
    phi[6,3]  R1755     -5.4888319969177246e-01
    phi[6,3]  R1756     -1.2556456327438354e+00
    phi[6,3]  R1757     -2.8660969734191895e+00
    phi[6,3]  R1758     -2.1460925042629242e-01
    phi[6,3]  R1759     -1.28054940700531
    phi[6,3]  R1760     -1.2796907424926758e+00
    phi[6,3]  R1761     -9.5194809138774872e-02
    phi[6,3]  R1762     -4.9208766222000122e-01
    phi[6,3]  R1763     9.8959583044052124e-01
    phi[6,3]  R1764     -2.0442612171173096e+00
    phi[6,3]  R1765     -1.4554131031036377e+00
    phi[6,3]  R1766     -2.4189256131649017e-01
    phi[6,3]  R1767     -1.9648689031600952e+00
    phi[6,3]  R1768     -2.9148730635643005e-01
    phi[6,3]  R1769     -8.8934665918350220e-01
    phi[6,3]  R1770     -2.1878080368041992e+00
    phi[6,3]  R1771     -8.4650105237960815e-01
    phi[6,3]  R1772     -1.0171432495117188e+00
    phi[6,3]  R1773     -1.4771615266799927e+00
    phi[6,3]  R1774     -1.0705137252807617e+00
    phi[6,3]  R1775     -1.4200100898742676e+00
    phi[6,3]  R1776     -3.3985075354576111e-01
    phi[6,3]  R1777     -0.466865211725235
    phi[6,3]  R1778     -5.1214151084423065e-02
    phi[6,3]  R1779     -3.6568677425384521e-01
    phi[6,3]  R1780     -1.0456889867782593e+00
    phi[6,3]  R1781     -8.1152600049972534e-01
    phi[6,3]  R1782     -7.6313740015029907e-01
    phi[6,3]  R1783     1.5600084066390991e+00
    phi[6,3]  R1784     9.4336503744125366e-01
    phi[6,3]  R1785     -1.3128930330276489e+00
    phi[6,3]  R1786     4.1477048397064209e-01
    phi[6,3]  R1787     1.0127704143524170e+00
    phi[6,3]  R1788     1.2936652898788452e+00
    phi[6,3]  R1789     1.4201967716217041e+00
    phi[6,3]  R1790     -2.3890395164489746e+00
    phi[6,3]  R1791     1.2943265438079834e+00
    phi[6,3]  R1792     -1.6294374465942383e+00
    phi[6,3]  R1793     -1.0394927263259888e+00
    phi[6,3]  R1794     -1.4359424114227295e+00
    phi[6,3]  R1795     -3.5764619708061218e-01
    phi[6,3]  R1796     -2.5081818103790283e+00
    phi[6,3]  R1797     -2.4175758361816406e+00
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1798     -3.0999999046325684e+00
    phi[3,7]  R1799     -3.0999999046325684e+00
    phi[3,7]  R1800     -2.2400000095367432e+00
    phi[3,7]  R1801     -2.2400000095367432e+00
    phi[3,7]  R1802     -3.0999999046325684e+00
    phi[3,7]  R1803     -3.0999999046325684e+00
    phi[3,7]  R1804     -2.5699999332427979e+00
    phi[3,7]  R1805     -2.5699999332427979e+00
    phi[3,7]  R1806     -3.0999999046325684e+00
    phi[3,7]  R1807     -3.0999999046325684e+00
    phi[3,7]  R1808     -2.0899999141693115e+00
    phi[3,7]  R1809     -2.0899999141693115e+00
    phi[3,7]  R1810     -3.0999999046325684e+00
    phi[3,7]  R1811     -3.0999999046325684e+00
    phi[3,7]  R1812     1.5600084066390991e+00
    phi[3,7]  R1813     9.4336503744125366e-01
    phi[3,7]  R1814     -1.3128930330276489e+00
    phi[3,7]  R1815     4.1477048397064209e-01
    phi[3,7]  R1816     1.0127704143524170e+00
    phi[3,7]  R1817     1.2936652898788452e+00
    phi[3,7]  R1818     1.4201967716217041e+00
    phi[3,7]  R1819     -2.3890395164489746e+00
    phi[3,7]  R1820     1.2943265438079834e+00
    phi[3,7]  R1821     -1.6294374465942383e+00
    phi[3,7]  R1822     -1.0394927263259888e+00
    phi[3,7]  R1823     -1.4359424114227295e+00
    phi[3,7]  R1824     -3.5764619708061218e-01
    phi[3,7]  R1825     -2.5081818103790283e+00
    phi[3,7]  R1826     -2.4175758361816406e+00
    phi[3,7]  R1827     1.9113900661468506e+00
    phi[3,7]  R1828     -4.4643613696098328e-01
    phi[3,7]  R1829     1.5567475557327271e+00
    phi[3,7]  R1830     -8.0506467819213867e-01
    phi[3,7]  R1831     -2.05782413482666
    phi[3,7]  R1832     4.9165353178977966e-02
    phi[3,7]  R1833     -2.3159313201904297e-01
    phi[3,7]  R1834     1.6770650148391724e+00
    phi[3,7]  R1835     1.0318716764450073e+00
    phi[3,7]  R1836     5.9837931394577026e-01
    phi[3,7]  R1837     -1.6408749818801880e+00
    phi[3,7]  R1838     -2.3867704868316650e+00
    phi[3,7]  R1839     -1.0487056970596313e+00
    phi[3,7]  R1840     -7.6988494396209717e-01
    phi[3,7]  R1841     -1.1640688180923462e+00
    phi[3,7]  R1842     3.7339350581169128e-01
    phi[3,7]  R1843     3.4295046329498291e-01
    phi[3,7]  R1844     6.9483411312103271e-01
    phi[3,7]  R1845     -1.7111821174621582e+00
    phi[3,7]  R1846     -2.7399511337280273e+00
    phi[3,7]  R1847     -1.8742944002151489e+00
    phi[3,7]  R1848     -4.7991326451301575e-01
    phi[3,7]  R1849     -2.2946956157684326e+00
    phi[3,7]  R1850     -9.3676692247390747e-01
    phi[3,7]  R1851     -7.6284325122833252e-01
    phi[3,7]  R1852     4.4161331653594971e-01
    phi[3,7]  R1853     -1.8225845694541931e-01
    phi[3,7]  R1854     1.0741157084703445e-01
    phi[3,7]  R1855     1.8629150390625
    phi[3,7]  R1856     1.4589640498161316e-01
    phi[3,7]  R1857     -2.3330132961273193e+00
    phi[3,7]  R1858     8.1520879268646240e-01
    phi[3,7]  R1859     -7.8551101684570312e-01
    phi[3,7]  R1860     9.7357380390167236e-01
    phi[3,7]  R1861     -9.1778314113616943e-01
    phi[3,7]  R1862     1.3279888033866882e-01
    phi[3,7]  R1863     -6.7593210935592651e-01
    phi[3,7]  R1864     8.3452498912811279e-01
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1865     -3.0999999046325684e+00
    phi[7,3]  R1866     -3.0999999046325684e+00
    phi[7,3]  R1867     -2.2400000095367432e+00
    phi[7,3]  R1868     -2.2400000095367432e+00
    phi[7,3]  R1869     -3.0999999046325684e+00
    phi[7,3]  R1870     -3.0999999046325684e+00
    phi[7,3]  R1871     -2.5699999332427979e+00
    phi[7,3]  R1872     -2.5699999332427979e+00
    phi[7,3]  R1873     -3.0999999046325684e+00
    phi[7,3]  R1874     -3.0999999046325684e+00
    phi[7,3]  R1875     -2.0899999141693115e+00
    phi[7,3]  R1876     -2.0899999141693115e+00
    phi[7,3]  R1877     -3.0999999046325684e+00
    phi[7,3]  R1878     -3.0999999046325684e+00
    phi[7,3]  R1879     1.9113900661468506e+00
    phi[7,3]  R1880     -4.4643613696098328e-01
    phi[7,3]  R1881     1.5567475557327271e+00
    phi[7,3]  R1882     -8.0506467819213867e-01
    phi[7,3]  R1883     -2.05782413482666
    phi[7,3]  R1884     4.9165353178977966e-02
    phi[7,3]  R1885     -2.3159313201904297e-01
    phi[7,3]  R1886     1.6770650148391724e+00
    phi[7,3]  R1887     1.0318716764450073e+00
    phi[7,3]  R1888     5.9837931394577026e-01
    phi[7,3]  R1889     -1.6408749818801880e+00
    phi[7,3]  R1890     -2.3867704868316650e+00
    phi[7,3]  R1891     -1.0487056970596313e+00
    phi[7,3]  R1892     -7.6988494396209717e-01
    phi[7,3]  R1893     -1.1640688180923462e+00
    phi[7,3]  R1894     3.7339350581169128e-01
    phi[7,3]  R1895     3.4295046329498291e-01
    phi[7,3]  R1896     6.9483411312103271e-01
    phi[7,3]  R1897     -1.7111821174621582e+00
    phi[7,3]  R1898     -2.7399511337280273e+00
    phi[7,3]  R1899     -1.8742944002151489e+00
    phi[7,3]  R1900     -4.7991326451301575e-01
    phi[7,3]  R1901     -2.2946956157684326e+00
    phi[7,3]  R1902     -9.3676692247390747e-01
    phi[7,3]  R1903     -7.6284325122833252e-01
    phi[7,3]  R1904     4.4161331653594971e-01
    phi[7,3]  R1905     -1.8225845694541931e-01
    phi[7,3]  R1906     1.0741157084703445e-01
    phi[7,3]  R1907     1.8629150390625
    phi[7,3]  R1908     1.4589640498161316e-01
    phi[7,3]  R1909     -2.3330132961273193e+00
    phi[7,3]  R1910     8.1520879268646240e-01
    phi[7,3]  R1911     -7.8551101684570312e-01
    phi[7,3]  R1912     9.7357380390167236e-01
    phi[7,3]  R1913     -9.1778314113616943e-01
    phi[7,3]  R1914     1.3279888033866882e-01
    phi[7,3]  R1915     -6.7593210935592651e-01
    phi[7,3]  R1916     8.3452498912811279e-01
    phi[7,3]  R1917     1.5600084066390991e+00
    phi[7,3]  R1918     9.4336503744125366e-01
    phi[7,3]  R1919     -1.3128930330276489e+00
    phi[7,3]  R1920     4.1477048397064209e-01
    phi[7,3]  R1921     1.0127704143524170e+00
    phi[7,3]  R1922     1.2936652898788452e+00
    phi[7,3]  R1923     1.4201967716217041e+00
    phi[7,3]  R1924     -2.3890395164489746e+00
    phi[7,3]  R1925     1.2943265438079834e+00
    phi[7,3]  R1926     -1.6294374465942383e+00
    phi[7,3]  R1927     -1.0394927263259888e+00
    phi[7,3]  R1928     -1.4359424114227295e+00
    phi[7,3]  R1929     -3.5764619708061218e-01
    phi[7,3]  R1930     -2.5081818103790283e+00
    phi[7,3]  R1931     -2.4175758361816406e+00
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R29       -2.7733368486840955e+00
    phi[3,9]  R30       9.8669403480810658e-01
    phi[3,9]  R31       -3.3438466390740818e-01
    phi[3,9]  R32       1.4409000075495051e+00
    phi[3,9]  R33       -1.3666156194665757e+00
    phi[3,9]  R34       -9.5796932988997030e-01
    phi[3,9]  R35       1.7753088012792446e+00
    phi[3,9]  R73       -1
    phi[3,9]  R1932     -5.8733367533166643e+00
    phi[3,9]  R1933     -3.2666305594847289e-01
    phi[3,9]  R1934     -1.2533059747286366e+00
    phi[3,9]  R1935     -3.2266940443448497e+00
    phi[3,9]  R1936     -3.4343845685399765e+00
    phi[3,9]  R1937     -2.76561524072516
    phi[3,9]  R1938     -1.1290999256932928e+00
    phi[3,9]  R1939     -4.0108999407923029e+00
    phi[3,9]  R1940     -4.4666155240991436e+00
    phi[3,9]  R1941     -1.7333842851659926e+00
    phi[3,9]  R1942     -3.0479692440592818e+00
    phi[3,9]  R1943     -1.1320305842793412e+00
    phi[3,9]  R1944     -1.3246911033533237e+00
    phi[3,9]  R1945     -4.8753087059118130e+00
    phi[3,9]  R1946     -4.4467002703167946e-02
    phi[3,9]  R1947     -4.6771955843537949e-01
    phi[3,9]  R1948     -8.0668460325434621e-02
    phi[3,9]  R1949     -5.0104530901299293e-01
    phi[3,9]  R1950     -1.0289305531839368e+00
    phi[3,9]  R1951     -0.0944855822763293
    phi[3,9]  R1952     -9.9055841149508828e-02
    phi[3,9]  R1953     -1.0162094020540335e-01
    phi[3,9]  R1954     -1.0534548793947485e-01
    phi[3,9]  R1955     -1.1213255642341391e-01
    phi[3,9]  R1956     -1.6247785428440187e-01
    phi[3,9]  R1957     -2.9113739263811267e-01
    phi[3,9]  R1958     -3.8067799583913364e-01
    phi[3,9]  R1959     -5.7001341708023778e-01
    phi[3,9]  R1960     -6.1581983129094087e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1961     -3.0999999046325684e+00
    phi[4,5]  R1962     -3.0999999046325684e+00
    phi[4,5]  R1963     -2.2400000095367432e+00
    phi[4,5]  R1964     -2.2400000095367432e+00
    phi[4,5]  R1965     -3.0999999046325684e+00
    phi[4,5]  R1966     -3.0999999046325684e+00
    phi[4,5]  R1967     -2.5699999332427979e+00
    phi[4,5]  R1968     -2.5699999332427979e+00
    phi[4,5]  R1969     -3.0999999046325684e+00
    phi[4,5]  R1970     -3.0999999046325684e+00
    phi[4,5]  R1971     -2.0899999141693115e+00
    phi[4,5]  R1972     -2.0899999141693115e+00
    phi[4,5]  R1973     -3.0999999046325684e+00
    phi[4,5]  R1974     -3.0999999046325684e+00
    phi[4,5]  R1975     7.4208229780197144e-01
    phi[4,5]  R1976     1.2353112697601318e+00
    phi[4,5]  R1977     1.0805889368057251e+00
    phi[4,5]  R1978     -2.8001111745834351e-01
    phi[4,5]  R1979     4.7244563698768616e-01
    phi[4,5]  R1980     -4.0230318903923035e-01
    phi[4,5]  R1981     -2.7459320425987244e-01
    phi[4,5]  R1982     9.6068066358566284e-01
    phi[4,5]  R1983     -2.5696772336959839e-01
    phi[4,5]  R1984     0.679744303226471
    phi[4,5]  R1985     -1.4282848834991455e+00
    phi[4,5]  R1986     -2.8279592990875244e+00
    phi[4,5]  R1987     -3.4522879123687744e+00
    phi[4,5]  R1988     -2.3174171447753906e+00
    phi[4,5]  R1989     -2.2867567539215088e+00
    phi[4,5]  R1990     -3.0382301807403564e+00
    phi[4,5]  R1991     -2.4995086193084717e+00
    phi[4,5]  R1992     -1.4328546524047852e+00
    phi[4,5]  R1993     -2.0978443622589111e+00
    phi[4,5]  R1994     -2.2625730037689209e+00
    phi[4,5]  R1995     -2.0611398220062256e+00
    phi[4,5]  R1996     -2.2320160865783691e+00
    phi[4,5]  R1997     -2.1565473079681396e+00
    phi[4,5]  R1998     -1.8378547430038452e+00
    phi[4,5]  R1999     -1.0087265819311142e-01
    phi[4,5]  R2000     -1.3328183889389038e+00
    phi[4,5]  R2001     -1.2932187318801880e-01
    phi[4,5]  R2002     -5.7320863008499146e-01
    phi[4,5]  R2003     -2.9855039715766907e-01
    phi[4,5]  R2004     -9.2081671953201294e-01
    phi[4,5]  R2005     -4.9113976955413818e-01
    phi[4,5]  R2006     8.8913470506668091e-02
    phi[4,5]  R2007     -4.7009161114692688e-01
    phi[4,5]  R2008     2.8243336826562881e-02
    phi[4,5]  R2009     -4.6940857172012329e-01
    phi[4,5]  R2010     3.6304861307144165e-01
    phi[4,5]  R2011     -0.0803549736738205
    phi[4,5]  R2012     -3.2739752531051636e-01
    phi[4,5]  R2013     -5.0264859199523926e-01
    phi[4,5]  R2014     -2.0441831648349762e-01
    phi[4,5]  R2015     -7.1983647346496582e-01
    phi[4,5]  R2016     -1.0586068630218506e+00
    phi[4,5]  R2017     -6.7323338985443115e-01
    phi[4,5]  R2018     -1.2447824478149414e+00
    phi[4,5]  R2019     -1.0662146806716919e+00
    phi[4,5]  R2020     -5.6166529655456543e-01
    phi[4,5]  R2021     1.9712753593921661e-01
    phi[4,5]  R2022     -4.0019401907920837e-01
    phi[4,5]  R2023     2.9765906929969788e-01
    phi[4,5]  R2024     -9.3194484710693359e-01
    phi[4,5]  R2025     2.2462518513202667e-01
    phi[4,5]  R2026     -4.2797064781188965e-01
    phi[4,5]  R2027     -7.8576493263244629e-01
    phi[4,5]  R2028     -1.0599888563156128e+00
    phi[4,5]  R2029     -8.3726471662521362e-01
    phi[4,5]  R2030     -5.3349649906158447e-01
    phi[4,5]  R2031     -0.657221257686615
    phi[4,5]  R2032     -2.7885931730270386e-01
    phi[4,5]  R2033     -2.3064607381820679e-01
    phi[4,5]  R2034     -0.0705157220363617
    phi[4,5]  R2035     -2.1996141970157623e-01
    phi[4,5]  R2036     -2.0231057703495026e-01
    phi[4,5]  R2037     -6.8045955896377563e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2038     -3.0999999046325684e+00
    phi[5,4]  R2039     -3.0999999046325684e+00
    phi[5,4]  R2040     -2.2400000095367432e+00
    phi[5,4]  R2041     -2.2400000095367432e+00
    phi[5,4]  R2042     -3.0999999046325684e+00
    phi[5,4]  R2043     -3.0999999046325684e+00
    phi[5,4]  R2044     -2.5699999332427979e+00
    phi[5,4]  R2045     -2.5699999332427979e+00
    phi[5,4]  R2046     -3.0999999046325684e+00
    phi[5,4]  R2047     -3.0999999046325684e+00
    phi[5,4]  R2048     -2.0899999141693115e+00
    phi[5,4]  R2049     -2.0899999141693115e+00
    phi[5,4]  R2050     -3.0999999046325684e+00
    phi[5,4]  R2051     -3.0999999046325684e+00
    phi[5,4]  R2052     2.8243336826562881e-02
    phi[5,4]  R2053     -4.6940857172012329e-01
    phi[5,4]  R2054     3.6304861307144165e-01
    phi[5,4]  R2055     -0.0803549736738205
    phi[5,4]  R2056     -3.2739752531051636e-01
    phi[5,4]  R2057     -5.0264859199523926e-01
    phi[5,4]  R2058     -2.0441831648349762e-01
    phi[5,4]  R2059     -7.1983647346496582e-01
    phi[5,4]  R2060     -1.0586068630218506e+00
    phi[5,4]  R2061     -6.7323338985443115e-01
    phi[5,4]  R2062     -1.2447824478149414e+00
    phi[5,4]  R2063     -1.0662146806716919e+00
    phi[5,4]  R2064     -5.6166529655456543e-01
    phi[5,4]  R2065     1.9712753593921661e-01
    phi[5,4]  R2066     -4.0019401907920837e-01
    phi[5,4]  R2067     2.9765906929969788e-01
    phi[5,4]  R2068     -9.3194484710693359e-01
    phi[5,4]  R2069     2.2462518513202667e-01
    phi[5,4]  R2070     -4.2797064781188965e-01
    phi[5,4]  R2071     -7.8576493263244629e-01
    phi[5,4]  R2072     -1.0599888563156128e+00
    phi[5,4]  R2073     -8.3726471662521362e-01
    phi[5,4]  R2074     -5.3349649906158447e-01
    phi[5,4]  R2075     -0.657221257686615
    phi[5,4]  R2076     -2.7885931730270386e-01
    phi[5,4]  R2077     -2.3064607381820679e-01
    phi[5,4]  R2078     -0.0705157220363617
    phi[5,4]  R2079     -2.1996141970157623e-01
    phi[5,4]  R2080     -2.0231057703495026e-01
    phi[5,4]  R2081     -6.8045955896377563e-01
    phi[5,4]  R2082     7.4208229780197144e-01
    phi[5,4]  R2083     1.2353112697601318e+00
    phi[5,4]  R2084     1.0805889368057251e+00
    phi[5,4]  R2085     -2.8001111745834351e-01
    phi[5,4]  R2086     4.7244563698768616e-01
    phi[5,4]  R2087     -4.0230318903923035e-01
    phi[5,4]  R2088     -2.7459320425987244e-01
    phi[5,4]  R2089     9.6068066358566284e-01
    phi[5,4]  R2090     -2.5696772336959839e-01
    phi[5,4]  R2091     0.679744303226471
    phi[5,4]  R2092     -1.4282848834991455e+00
    phi[5,4]  R2093     -2.8279592990875244e+00
    phi[5,4]  R2094     -3.4522879123687744e+00
    phi[5,4]  R2095     -2.3174171447753906e+00
    phi[5,4]  R2096     -2.2867567539215088e+00
    phi[5,4]  R2097     -3.0382301807403564e+00
    phi[5,4]  R2098     -2.4995086193084717e+00
    phi[5,4]  R2099     -1.4328546524047852e+00
    phi[5,4]  R2100     -2.0978443622589111e+00
    phi[5,4]  R2101     -2.2625730037689209e+00
    phi[5,4]  R2102     -2.0611398220062256e+00
    phi[5,4]  R2103     -2.2320160865783691e+00
    phi[5,4]  R2104     -2.1565473079681396e+00
    phi[5,4]  R2105     -1.8378547430038452e+00
    phi[5,4]  R2106     -1.0087265819311142e-01
    phi[5,4]  R2107     -1.3328183889389038e+00
    phi[5,4]  R2108     -1.2932187318801880e-01
    phi[5,4]  R2109     -5.7320863008499146e-01
    phi[5,4]  R2110     -2.9855039715766907e-01
    phi[5,4]  R2111     -9.2081671953201294e-01
    phi[5,4]  R2112     -4.9113976955413818e-01
    phi[5,4]  R2113     8.8913470506668091e-02
    phi[5,4]  R2114     -4.7009161114692688e-01
    phi[8,4]  R36       -1
    phi[8,4]  R38       -2.3950683327745272e+00
    phi[8,4]  R39       -3.9327308768290514e-01
    phi[8,4]  R40       2.0704273144097085e-01
    phi[8,4]  R41       -2.2641856685900184e+00
    phi[8,4]  R42       4.6311949829106247e-02
    phi[8,4]  R43       -9.8983765061484208e-02
    phi[8,4]  R44       1.4343729837825507e+00
    phi[8,4]  R72       1
    phi[8,4]  R2115     -7.0493157185804112e-01
    phi[8,4]  R2116     -5.4950682374070956e+00
    phi[8,4]  R2117     -1.8467269218538380e+00
    phi[8,4]  R2118     -2.6332730972196483e+00
    phi[8,4]  R2119     -3.3070426360735392e+00
    phi[8,4]  R2120     -2.8929571731915975e+00
    phi[8,4]  R2121     -3.0581426465277950e-01
    phi[8,4]  R2122     -4.8341856018328162e+00
    phi[8,4]  R2123     -3.1463118544616746e+00
    phi[8,4]  R2124     -3.0536879548034621e+00
    phi[8,4]  R2125     -1.9910161491078273e+00
    phi[8,4]  R2126     -2.1889836792307955e+00
    phi[8,4]  R2127     -4.5343728884151187e+00
    phi[8,4]  R2128     -1.6656269208500176e+00
    phi[8,4]  R2129     -5.2874103546934892e-02
    phi[8,4]  R2130     -5.5590477440510710e-02
    phi[8,4]  R2131     -6.2615591382207292e-02
    phi[8,4]  R2132     -6.7961397983681615e-02
    phi[8,4]  R2133     -6.8321238229572590e-02
    phi[8,4]  R2134     -6.8790037168584561e-02
    phi[8,4]  R2135     -6.9993292484608449e-02
    phi[8,4]  R2136     -7.1772130639753184e-02
    phi[8,4]  R2137     -1.4781500356828342e-01
    phi[8,4]  R2138     -1.4957805522234946e-01
    phi[8,4]  R2139     -1.5110511544061289e-01
    phi[8,4]  R2140     -1.7784971834145846e-01
    phi[8,4]  R2141     -1.8620858784972638e-01
    phi[8,4]  R2142     -1.9359780309332475e-01
    phi[8,4]  R2143     -1.9613334507071212e-01
    phi[8,4]  R2144     -2.0331759605148125e-01
    phi[8,4]  R2145     -2.1069456991298852e-01
    phi[8,4]  R2146     -2.1561120108295340e-01
    phi[8,4]  R2147     -2.1883841356833211e-01
    phi[8,4]  R2148     -2.2452042872020561e-01
    phi[8,4]  R2149     -1.1829965797023556e-01
    phi[8,4]  R2150     -1.3247925541902283e-01
    phi[8,4]  R2151     -1.3603648679102731e-01
    phi[8,4]  R2152     -1.3961616830829926e-01
    phi[8,4]  R2153     -1.4374740144706555e-01
    phi[8,4]  R2154     -1.4437026695185207e-01
    phi[8,4]  R2155     -1.5361934615784087e-01
    phi[8,4]  R2156     -1.6744676118867652e-01
    phi[8,4]  R2157     -1.7387953168635950e-01
    phi[8,4]  R2158     -1.8010279162209064e-01
    phi[8,4]  R2159     -8.3603649034260763e-02
    phi[8,4]  R2160     -2.4774025367154218e-01
    phi[8,4]  R2161     -7.1337848054725517e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2162     -3.0999999046325684e+00
    phi[5,6]  R2163     -3.0999999046325684e+00
    phi[5,6]  R2164     -2.2400000095367432e+00
    phi[5,6]  R2165     -2.2400000095367432e+00
    phi[5,6]  R2166     -3.0999999046325684e+00
    phi[5,6]  R2167     -3.0999999046325684e+00
    phi[5,6]  R2168     -2.5699999332427979e+00
    phi[5,6]  R2169     -2.5699999332427979e+00
    phi[5,6]  R2170     -3.0999999046325684e+00
    phi[5,6]  R2171     -3.0999999046325684e+00
    phi[5,6]  R2172     -2.0899999141693115e+00
    phi[5,6]  R2173     -2.0899999141693115e+00
    phi[5,6]  R2174     -3.0999999046325684e+00
    phi[5,6]  R2175     -3.0999999046325684e+00
    phi[5,6]  R2176     2.8243336826562881e-02
    phi[5,6]  R2177     -4.6940857172012329e-01
    phi[5,6]  R2178     3.6304861307144165e-01
    phi[5,6]  R2179     -0.0803549736738205
    phi[5,6]  R2180     -3.2739752531051636e-01
    phi[5,6]  R2181     -5.0264859199523926e-01
    phi[5,6]  R2182     -2.0441831648349762e-01
    phi[5,6]  R2183     -7.1983647346496582e-01
    phi[5,6]  R2184     -1.0586068630218506e+00
    phi[5,6]  R2185     -6.7323338985443115e-01
    phi[5,6]  R2186     -1.2447824478149414e+00
    phi[5,6]  R2187     -1.0662146806716919e+00
    phi[5,6]  R2188     -5.6166529655456543e-01
    phi[5,6]  R2189     1.9712753593921661e-01
    phi[5,6]  R2190     -4.0019401907920837e-01
    phi[5,6]  R2191     2.9765906929969788e-01
    phi[5,6]  R2192     -9.3194484710693359e-01
    phi[5,6]  R2193     2.2462518513202667e-01
    phi[5,6]  R2194     -4.2797064781188965e-01
    phi[5,6]  R2195     -7.8576493263244629e-01
    phi[5,6]  R2196     -1.0599888563156128e+00
    phi[5,6]  R2197     -8.3726471662521362e-01
    phi[5,6]  R2198     -5.3349649906158447e-01
    phi[5,6]  R2199     -0.657221257686615
    phi[5,6]  R2200     -2.7885931730270386e-01
    phi[5,6]  R2201     -2.3064607381820679e-01
    phi[5,6]  R2202     -0.0705157220363617
    phi[5,6]  R2203     -2.1996141970157623e-01
    phi[5,6]  R2204     -2.0231057703495026e-01
    phi[5,6]  R2205     -6.8045955896377563e-01
    phi[5,6]  R2206     0.917249321937561
    phi[5,6]  R2207     6.7110764980316162e-01
    phi[5,6]  R2208     6.9638466835021973e-01
    phi[5,6]  R2209     1.1149033308029175e+00
    phi[5,6]  R2210     7.5205254554748535e-01
    phi[5,6]  R2211     4.4133463501930237e-01
    phi[5,6]  R2212     1.1141712665557861e+00
    phi[5,6]  R2213     1.0362817049026489e+00
    phi[5,6]  R2214     7.4518150091171265e-01
    phi[5,6]  R2215     6.2080383300781250e-01
    phi[5,6]  R2216     -1.0984357595443726e+00
    phi[5,6]  R2217     -4.9764358997344971e-01
    phi[5,6]  R2218     -1.6419972181320190e+00
    phi[5,6]  R2219     -1.5035352706909180e+00
    phi[5,6]  R2220     -2.6824991703033447e+00
    phi[5,6]  R2221     -1.3900750875473022e+00
    phi[5,6]  R2222     -2.4424611032009125e-01
    phi[5,6]  R2223     -1.5501182079315186e+00
    phi[5,6]  R2224     -1.2427994012832642e+00
    phi[5,6]  R2225     -7.4001765251159668e-01
    phi[5,6]  R2226     -1.5559186935424805e+00
    phi[5,6]  R2227     -1.4434924125671387e+00
    phi[5,6]  R2228     -2.5029923915863037e+00
    phi[5,6]  R2229     -2.8726518154144287e+00
    phi[5,6]  R2230     -3.1387231349945068e+00
    phi[5,6]  R2231     -2.1342675685882568e+00
    phi[5,6]  R2232     -1.9238809347152710e+00
    phi[5,6]  R2233     -0.668778657913208
    phi[5,6]  R2234     -2.8994650840759277e+00
    phi[5,6]  R2235     -7.6136386394500732e-01
    phi[5,6]  R2236     -9.8096543550491333e-01
    phi[5,6]  R2237     -1.5009375810623169e+00
    phi[5,6]  R2238     -1.9809985160827637e+00
    phi[5,6]  R2239     -2.1637823581695557e+00
    phi[5,6]  R2240     -2.5295886993408203e+00
    phi[5,6]  R2241     -2.2102041244506836e+00
    phi[5,6]  R2242     -1.9405622482299805e+00
    phi[5,6]  R2243     -2.1831164360046387e+00
    phi[5,6]  R2244     -2.0480155944824219e+00
    phi[5,6]  R2245     -3.9362147450447083e-02
    phi[5,6]  R2246     -1.1552461385726929e+00
    phi[5,6]  R2247     -1.7038813829421997e+00
    phi[5,6]  R2248     -1.3765782117843628e+00
    phi[5,6]  R2249     -8.6234229803085327e-01
    phi[5,6]  R2250     -1.9150154590606689e+00
    phi[5,6]  R2251     -1.5264697074890137e+00
    phi[5,6]  R2252     -1.5208266973495483e+00
    phi[5,6]  R2253     -1.7068926095962524e+00
    phi[5,6]  R2254     1.9326537847518921e-01
    phi[5,6]  R2255     -2.9780147075653076e+00
    phi[5,6]  R2256     4.3472588062286377e-02
    phi[5,6]  R2257     -1.5105020999908447e+00
    phi[5,6]  R2258     -9.7373247146606445e-01
    phi[5,6]  R2259     -2.0487370491027832e+00
    phi[5,6]  R2260     -1.5901628732681274e+00
    phi[5,6]  R2261     -1.1715462207794189e+00
    phi[5,6]  R2262     -2.3735306262969971e+00
    phi[5,6]  R2263     -2.1843566894531250e+00
    phi[5,6]  R2264     1.9033473730087280e-01
    phi[5,6]  R2265     -5.0295501947402954e-01
    phi[5,6]  R2266     -1.0164351463317871e+00
    phi[5,6]  R2267     -8.5414963960647583e-01
    phi[5,6]  R2268     -2.5340640544891357e+00
    phi[5,6]  R2269     -2.6598623394966125e-01
    phi[5,6]  R2270     4.4882947206497192e-01
    phi[5,6]  R2271     -1.3391474485397339e+00
    phi[5,6]  R2272     -2.6511619091033936e+00
    phi[5,6]  R2273     -2.7533385753631592e+00
    phi[5,6]  R2274     -5.2383834123611450e-01
    phi[5,6]  R2275     -2.2017860412597656e+00
    phi[5,6]  R2276     -2.2278268337249756e+00
    phi[5,6]  R2277     -0.563535749912262
    phi[5,6]  R2278     -1.0979350805282593e+00
    phi[5,6]  R2279     7.7820581197738647e-01
    phi[5,6]  R2280     -1.9514373540878296e+00
    phi[5,6]  R2281     -1.2126215696334839e+00
    phi[5,6]  R2282     -4.3799281120300293e-01
    phi[5,6]  R2283     -2.1205651760101318e+00
    phi[5,6]  R2284     1.1333760023117065e+00
    phi[5,6]  R2285     -1.7122483253479004e-01
    phi[5,6]  R2286     1.2913167476654053e+00
    phi[5,6]  R2287     -1.9848085641860962e+00
    phi[5,6]  R2288     -5.4888319969177246e-01
    phi[5,6]  R2289     -1.2556456327438354e+00
    phi[5,6]  R2290     -2.8660969734191895e+00
    phi[5,6]  R2291     -2.1460925042629242e-01
    phi[5,6]  R2292     -1.28054940700531
    phi[5,6]  R2293     -1.2796907424926758e+00
    phi[5,6]  R2294     -9.5194809138774872e-02
    phi[5,6]  R2295     -4.9208766222000122e-01
    phi[5,6]  R2296     9.8959583044052124e-01
    phi[5,6]  R2297     -2.0442612171173096e+00
    phi[5,6]  R2298     -1.4554131031036377e+00
    phi[5,6]  R2299     -2.4189256131649017e-01
    phi[5,6]  R2300     -1.9648689031600952e+00
    phi[5,6]  R2301     -2.9148730635643005e-01
    phi[5,6]  R2302     -8.8934665918350220e-01
    phi[5,6]  R2303     -2.1878080368041992e+00
    phi[5,6]  R2304     -8.4650105237960815e-01
    phi[5,6]  R2305     -1.0171432495117188e+00
    phi[5,6]  R2306     -1.4771615266799927e+00
    phi[5,6]  R2307     -1.0705137252807617e+00
    phi[5,6]  R2308     -1.4200100898742676e+00
    phi[5,6]  R2309     -3.3985075354576111e-01
    phi[5,6]  R2310     -0.466865211725235
    phi[5,6]  R2311     -5.1214151084423065e-02
    phi[5,6]  R2312     -3.6568677425384521e-01
    phi[5,6]  R2313     -1.0456889867782593e+00
    phi[5,6]  R2314     -8.1152600049972534e-01
    phi[5,6]  R2315     -7.6313740015029907e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2316     -3.0999999046325684e+00
    phi[6,5]  R2317     -3.0999999046325684e+00
    phi[6,5]  R2318     -2.2400000095367432e+00
    phi[6,5]  R2319     -2.2400000095367432e+00
    phi[6,5]  R2320     -3.0999999046325684e+00
    phi[6,5]  R2321     -3.0999999046325684e+00
    phi[6,5]  R2322     -2.5699999332427979e+00
    phi[6,5]  R2323     -2.5699999332427979e+00
    phi[6,5]  R2324     -3.0999999046325684e+00
    phi[6,5]  R2325     -3.0999999046325684e+00
    phi[6,5]  R2326     -2.0899999141693115e+00
    phi[6,5]  R2327     -2.0899999141693115e+00
    phi[6,5]  R2328     -3.0999999046325684e+00
    phi[6,5]  R2329     -3.0999999046325684e+00
    phi[6,5]  R2330     0.917249321937561
    phi[6,5]  R2331     6.7110764980316162e-01
    phi[6,5]  R2332     6.9638466835021973e-01
    phi[6,5]  R2333     1.1149033308029175e+00
    phi[6,5]  R2334     7.5205254554748535e-01
    phi[6,5]  R2335     4.4133463501930237e-01
    phi[6,5]  R2336     1.1141712665557861e+00
    phi[6,5]  R2337     1.0362817049026489e+00
    phi[6,5]  R2338     7.4518150091171265e-01
    phi[6,5]  R2339     6.2080383300781250e-01
    phi[6,5]  R2340     -1.0984357595443726e+00
    phi[6,5]  R2341     -4.9764358997344971e-01
    phi[6,5]  R2342     -1.6419972181320190e+00
    phi[6,5]  R2343     -1.5035352706909180e+00
    phi[6,5]  R2344     -2.6824991703033447e+00
    phi[6,5]  R2345     -1.3900750875473022e+00
    phi[6,5]  R2346     -2.4424611032009125e-01
    phi[6,5]  R2347     -1.5501182079315186e+00
    phi[6,5]  R2348     -1.2427994012832642e+00
    phi[6,5]  R2349     -7.4001765251159668e-01
    phi[6,5]  R2350     -1.5559186935424805e+00
    phi[6,5]  R2351     -1.4434924125671387e+00
    phi[6,5]  R2352     -2.5029923915863037e+00
    phi[6,5]  R2353     -2.8726518154144287e+00
    phi[6,5]  R2354     -3.1387231349945068e+00
    phi[6,5]  R2355     -2.1342675685882568e+00
    phi[6,5]  R2356     -1.9238809347152710e+00
    phi[6,5]  R2357     -0.668778657913208
    phi[6,5]  R2358     -2.8994650840759277e+00
    phi[6,5]  R2359     -7.6136386394500732e-01
    phi[6,5]  R2360     -9.8096543550491333e-01
    phi[6,5]  R2361     -1.5009375810623169e+00
    phi[6,5]  R2362     -1.9809985160827637e+00
    phi[6,5]  R2363     -2.1637823581695557e+00
    phi[6,5]  R2364     -2.5295886993408203e+00
    phi[6,5]  R2365     -2.2102041244506836e+00
    phi[6,5]  R2366     -1.9405622482299805e+00
    phi[6,5]  R2367     -2.1831164360046387e+00
    phi[6,5]  R2368     -2.0480155944824219e+00
    phi[6,5]  R2369     -3.9362147450447083e-02
    phi[6,5]  R2370     -1.1552461385726929e+00
    phi[6,5]  R2371     -1.7038813829421997e+00
    phi[6,5]  R2372     -1.3765782117843628e+00
    phi[6,5]  R2373     -8.6234229803085327e-01
    phi[6,5]  R2374     -1.9150154590606689e+00
    phi[6,5]  R2375     -1.5264697074890137e+00
    phi[6,5]  R2376     -1.5208266973495483e+00
    phi[6,5]  R2377     -1.7068926095962524e+00
    phi[6,5]  R2378     1.9326537847518921e-01
    phi[6,5]  R2379     -2.9780147075653076e+00
    phi[6,5]  R2380     4.3472588062286377e-02
    phi[6,5]  R2381     -1.5105020999908447e+00
    phi[6,5]  R2382     -9.7373247146606445e-01
    phi[6,5]  R2383     -2.0487370491027832e+00
    phi[6,5]  R2384     -1.5901628732681274e+00
    phi[6,5]  R2385     -1.1715462207794189e+00
    phi[6,5]  R2386     -2.3735306262969971e+00
    phi[6,5]  R2387     -2.1843566894531250e+00
    phi[6,5]  R2388     1.9033473730087280e-01
    phi[6,5]  R2389     -5.0295501947402954e-01
    phi[6,5]  R2390     -1.0164351463317871e+00
    phi[6,5]  R2391     -8.5414963960647583e-01
    phi[6,5]  R2392     -2.5340640544891357e+00
    phi[6,5]  R2393     -2.6598623394966125e-01
    phi[6,5]  R2394     4.4882947206497192e-01
    phi[6,5]  R2395     -1.3391474485397339e+00
    phi[6,5]  R2396     -2.6511619091033936e+00
    phi[6,5]  R2397     -2.7533385753631592e+00
    phi[6,5]  R2398     -5.2383834123611450e-01
    phi[6,5]  R2399     -2.2017860412597656e+00
    phi[6,5]  R2400     -2.2278268337249756e+00
    phi[6,5]  R2401     -0.563535749912262
    phi[6,5]  R2402     -1.0979350805282593e+00
    phi[6,5]  R2403     7.7820581197738647e-01
    phi[6,5]  R2404     -1.9514373540878296e+00
    phi[6,5]  R2405     -1.2126215696334839e+00
    phi[6,5]  R2406     -4.3799281120300293e-01
    phi[6,5]  R2407     -2.1205651760101318e+00
    phi[6,5]  R2408     1.1333760023117065e+00
    phi[6,5]  R2409     -1.7122483253479004e-01
    phi[6,5]  R2410     1.2913167476654053e+00
    phi[6,5]  R2411     -1.9848085641860962e+00
    phi[6,5]  R2412     -5.4888319969177246e-01
    phi[6,5]  R2413     -1.2556456327438354e+00
    phi[6,5]  R2414     -2.8660969734191895e+00
    phi[6,5]  R2415     -2.1460925042629242e-01
    phi[6,5]  R2416     -1.28054940700531
    phi[6,5]  R2417     -1.2796907424926758e+00
    phi[6,5]  R2418     -9.5194809138774872e-02
    phi[6,5]  R2419     -4.9208766222000122e-01
    phi[6,5]  R2420     9.8959583044052124e-01
    phi[6,5]  R2421     -2.0442612171173096e+00
    phi[6,5]  R2422     -1.4554131031036377e+00
    phi[6,5]  R2423     -2.4189256131649017e-01
    phi[6,5]  R2424     -1.9648689031600952e+00
    phi[6,5]  R2425     -2.9148730635643005e-01
    phi[6,5]  R2426     -8.8934665918350220e-01
    phi[6,5]  R2427     -2.1878080368041992e+00
    phi[6,5]  R2428     -8.4650105237960815e-01
    phi[6,5]  R2429     -1.0171432495117188e+00
    phi[6,5]  R2430     -1.4771615266799927e+00
    phi[6,5]  R2431     -1.0705137252807617e+00
    phi[6,5]  R2432     -1.4200100898742676e+00
    phi[6,5]  R2433     -3.3985075354576111e-01
    phi[6,5]  R2434     -0.466865211725235
    phi[6,5]  R2435     -5.1214151084423065e-02
    phi[6,5]  R2436     -3.6568677425384521e-01
    phi[6,5]  R2437     -1.0456889867782593e+00
    phi[6,5]  R2438     -8.1152600049972534e-01
    phi[6,5]  R2439     -7.6313740015029907e-01
    phi[6,5]  R2440     2.8243336826562881e-02
    phi[6,5]  R2441     -4.6940857172012329e-01
    phi[6,5]  R2442     3.6304861307144165e-01
    phi[6,5]  R2443     -0.0803549736738205
    phi[6,5]  R2444     -3.2739752531051636e-01
    phi[6,5]  R2445     -5.0264859199523926e-01
    phi[6,5]  R2446     -2.0441831648349762e-01
    phi[6,5]  R2447     -7.1983647346496582e-01
    phi[6,5]  R2448     -1.0586068630218506e+00
    phi[6,5]  R2449     -6.7323338985443115e-01
    phi[6,5]  R2450     -1.2447824478149414e+00
    phi[6,5]  R2451     -1.0662146806716919e+00
    phi[6,5]  R2452     -5.6166529655456543e-01
    phi[6,5]  R2453     1.9712753593921661e-01
    phi[6,5]  R2454     -4.0019401907920837e-01
    phi[6,5]  R2455     2.9765906929969788e-01
    phi[6,5]  R2456     -9.3194484710693359e-01
    phi[6,5]  R2457     2.2462518513202667e-01
    phi[6,5]  R2458     -4.2797064781188965e-01
    phi[6,5]  R2459     -7.8576493263244629e-01
    phi[6,5]  R2460     -1.0599888563156128e+00
    phi[6,5]  R2461     -8.3726471662521362e-01
    phi[6,5]  R2462     -5.3349649906158447e-01
    phi[6,5]  R2463     -0.657221257686615
    phi[6,5]  R2464     -2.7885931730270386e-01
    phi[6,5]  R2465     -2.3064607381820679e-01
    phi[6,5]  R2466     -0.0705157220363617
    phi[6,5]  R2467     -2.1996141970157623e-01
    phi[6,5]  R2468     -2.0231057703495026e-01
    phi[6,5]  R2469     -6.8045955896377563e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2470     -3.0999999046325684e+00
    phi[6,7]  R2471     -3.0999999046325684e+00
    phi[6,7]  R2472     -2.2400000095367432e+00
    phi[6,7]  R2473     -2.2400000095367432e+00
    phi[6,7]  R2474     -3.0999999046325684e+00
    phi[6,7]  R2475     -3.0999999046325684e+00
    phi[6,7]  R2476     -2.5699999332427979e+00
    phi[6,7]  R2477     -2.5699999332427979e+00
    phi[6,7]  R2478     -3.0999999046325684e+00
    phi[6,7]  R2479     -3.0999999046325684e+00
    phi[6,7]  R2480     -2.0899999141693115e+00
    phi[6,7]  R2481     -2.0899999141693115e+00
    phi[6,7]  R2482     -3.0999999046325684e+00
    phi[6,7]  R2483     -3.0999999046325684e+00
    phi[6,7]  R2484     0.917249321937561
    phi[6,7]  R2485     6.7110764980316162e-01
    phi[6,7]  R2486     6.9638466835021973e-01
    phi[6,7]  R2487     1.1149033308029175e+00
    phi[6,7]  R2488     7.5205254554748535e-01
    phi[6,7]  R2489     4.4133463501930237e-01
    phi[6,7]  R2490     1.1141712665557861e+00
    phi[6,7]  R2491     1.0362817049026489e+00
    phi[6,7]  R2492     7.4518150091171265e-01
    phi[6,7]  R2493     6.2080383300781250e-01
    phi[6,7]  R2494     -1.0984357595443726e+00
    phi[6,7]  R2495     -4.9764358997344971e-01
    phi[6,7]  R2496     -1.6419972181320190e+00
    phi[6,7]  R2497     -1.5035352706909180e+00
    phi[6,7]  R2498     -2.6824991703033447e+00
    phi[6,7]  R2499     -1.3900750875473022e+00
    phi[6,7]  R2500     -2.4424611032009125e-01
    phi[6,7]  R2501     -1.5501182079315186e+00
    phi[6,7]  R2502     -1.2427994012832642e+00
    phi[6,7]  R2503     -7.4001765251159668e-01
    phi[6,7]  R2504     -1.5559186935424805e+00
    phi[6,7]  R2505     -1.4434924125671387e+00
    phi[6,7]  R2506     -2.5029923915863037e+00
    phi[6,7]  R2507     -2.8726518154144287e+00
    phi[6,7]  R2508     -3.1387231349945068e+00
    phi[6,7]  R2509     -2.1342675685882568e+00
    phi[6,7]  R2510     -1.9238809347152710e+00
    phi[6,7]  R2511     -0.668778657913208
    phi[6,7]  R2512     -2.8994650840759277e+00
    phi[6,7]  R2513     -7.6136386394500732e-01
    phi[6,7]  R2514     -9.8096543550491333e-01
    phi[6,7]  R2515     -1.5009375810623169e+00
    phi[6,7]  R2516     -1.9809985160827637e+00
    phi[6,7]  R2517     -2.1637823581695557e+00
    phi[6,7]  R2518     -2.5295886993408203e+00
    phi[6,7]  R2519     -2.2102041244506836e+00
    phi[6,7]  R2520     -1.9405622482299805e+00
    phi[6,7]  R2521     -2.1831164360046387e+00
    phi[6,7]  R2522     -2.0480155944824219e+00
    phi[6,7]  R2523     -3.9362147450447083e-02
    phi[6,7]  R2524     -1.1552461385726929e+00
    phi[6,7]  R2525     -1.7038813829421997e+00
    phi[6,7]  R2526     -1.3765782117843628e+00
    phi[6,7]  R2527     -8.6234229803085327e-01
    phi[6,7]  R2528     -1.9150154590606689e+00
    phi[6,7]  R2529     -1.5264697074890137e+00
    phi[6,7]  R2530     -1.5208266973495483e+00
    phi[6,7]  R2531     -1.7068926095962524e+00
    phi[6,7]  R2532     1.9326537847518921e-01
    phi[6,7]  R2533     -2.9780147075653076e+00
    phi[6,7]  R2534     4.3472588062286377e-02
    phi[6,7]  R2535     -1.5105020999908447e+00
    phi[6,7]  R2536     -9.7373247146606445e-01
    phi[6,7]  R2537     -2.0487370491027832e+00
    phi[6,7]  R2538     -1.5901628732681274e+00
    phi[6,7]  R2539     -1.1715462207794189e+00
    phi[6,7]  R2540     -2.3735306262969971e+00
    phi[6,7]  R2541     -2.1843566894531250e+00
    phi[6,7]  R2542     1.9033473730087280e-01
    phi[6,7]  R2543     -5.0295501947402954e-01
    phi[6,7]  R2544     -1.0164351463317871e+00
    phi[6,7]  R2545     -8.5414963960647583e-01
    phi[6,7]  R2546     -2.5340640544891357e+00
    phi[6,7]  R2547     -2.6598623394966125e-01
    phi[6,7]  R2548     4.4882947206497192e-01
    phi[6,7]  R2549     -1.3391474485397339e+00
    phi[6,7]  R2550     -2.6511619091033936e+00
    phi[6,7]  R2551     -2.7533385753631592e+00
    phi[6,7]  R2552     -5.2383834123611450e-01
    phi[6,7]  R2553     -2.2017860412597656e+00
    phi[6,7]  R2554     -2.2278268337249756e+00
    phi[6,7]  R2555     -0.563535749912262
    phi[6,7]  R2556     -1.0979350805282593e+00
    phi[6,7]  R2557     7.7820581197738647e-01
    phi[6,7]  R2558     -1.9514373540878296e+00
    phi[6,7]  R2559     -1.2126215696334839e+00
    phi[6,7]  R2560     -4.3799281120300293e-01
    phi[6,7]  R2561     -2.1205651760101318e+00
    phi[6,7]  R2562     1.1333760023117065e+00
    phi[6,7]  R2563     -1.7122483253479004e-01
    phi[6,7]  R2564     1.2913167476654053e+00
    phi[6,7]  R2565     -1.9848085641860962e+00
    phi[6,7]  R2566     -5.4888319969177246e-01
    phi[6,7]  R2567     -1.2556456327438354e+00
    phi[6,7]  R2568     -2.8660969734191895e+00
    phi[6,7]  R2569     -2.1460925042629242e-01
    phi[6,7]  R2570     -1.28054940700531
    phi[6,7]  R2571     -1.2796907424926758e+00
    phi[6,7]  R2572     -9.5194809138774872e-02
    phi[6,7]  R2573     -4.9208766222000122e-01
    phi[6,7]  R2574     9.8959583044052124e-01
    phi[6,7]  R2575     -2.0442612171173096e+00
    phi[6,7]  R2576     -1.4554131031036377e+00
    phi[6,7]  R2577     -2.4189256131649017e-01
    phi[6,7]  R2578     -1.9648689031600952e+00
    phi[6,7]  R2579     -2.9148730635643005e-01
    phi[6,7]  R2580     -8.8934665918350220e-01
    phi[6,7]  R2581     -2.1878080368041992e+00
    phi[6,7]  R2582     -8.4650105237960815e-01
    phi[6,7]  R2583     -1.0171432495117188e+00
    phi[6,7]  R2584     -1.4771615266799927e+00
    phi[6,7]  R2585     -1.0705137252807617e+00
    phi[6,7]  R2586     -1.4200100898742676e+00
    phi[6,7]  R2587     -3.3985075354576111e-01
    phi[6,7]  R2588     -0.466865211725235
    phi[6,7]  R2589     -5.1214151084423065e-02
    phi[6,7]  R2590     -3.6568677425384521e-01
    phi[6,7]  R2591     -1.0456889867782593e+00
    phi[6,7]  R2592     -8.1152600049972534e-01
    phi[6,7]  R2593     -7.6313740015029907e-01
    phi[6,7]  R2594     1.9113900661468506e+00
    phi[6,7]  R2595     -4.4643613696098328e-01
    phi[6,7]  R2596     1.5567475557327271e+00
    phi[6,7]  R2597     -8.0506467819213867e-01
    phi[6,7]  R2598     -2.05782413482666
    phi[6,7]  R2599     4.9165353178977966e-02
    phi[6,7]  R2600     -2.3159313201904297e-01
    phi[6,7]  R2601     1.6770650148391724e+00
    phi[6,7]  R2602     1.0318716764450073e+00
    phi[6,7]  R2603     5.9837931394577026e-01
    phi[6,7]  R2604     -1.6408749818801880e+00
    phi[6,7]  R2605     -2.3867704868316650e+00
    phi[6,7]  R2606     -1.0487056970596313e+00
    phi[6,7]  R2607     -7.6988494396209717e-01
    phi[6,7]  R2608     -1.1640688180923462e+00
    phi[6,7]  R2609     3.7339350581169128e-01
    phi[6,7]  R2610     3.4295046329498291e-01
    phi[6,7]  R2611     6.9483411312103271e-01
    phi[6,7]  R2612     -1.7111821174621582e+00
    phi[6,7]  R2613     -2.7399511337280273e+00
    phi[6,7]  R2614     -1.8742944002151489e+00
    phi[6,7]  R2615     -4.7991326451301575e-01
    phi[6,7]  R2616     -2.2946956157684326e+00
    phi[6,7]  R2617     -9.3676692247390747e-01
    phi[6,7]  R2618     -7.6284325122833252e-01
    phi[6,7]  R2619     4.4161331653594971e-01
    phi[6,7]  R2620     -1.8225845694541931e-01
    phi[6,7]  R2621     1.0741157084703445e-01
    phi[6,7]  R2622     1.8629150390625
    phi[6,7]  R2623     1.4589640498161316e-01
    phi[6,7]  R2624     -2.3330132961273193e+00
    phi[6,7]  R2625     8.1520879268646240e-01
    phi[6,7]  R2626     -7.8551101684570312e-01
    phi[6,7]  R2627     9.7357380390167236e-01
    phi[6,7]  R2628     -9.1778314113616943e-01
    phi[6,7]  R2629     1.3279888033866882e-01
    phi[6,7]  R2630     -6.7593210935592651e-01
    phi[6,7]  R2631     8.3452498912811279e-01
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2632     -3.0999999046325684e+00
    phi[7,6]  R2633     -3.0999999046325684e+00
    phi[7,6]  R2634     -2.2400000095367432e+00
    phi[7,6]  R2635     -2.2400000095367432e+00
    phi[7,6]  R2636     -3.0999999046325684e+00
    phi[7,6]  R2637     -3.0999999046325684e+00
    phi[7,6]  R2638     -2.5699999332427979e+00
    phi[7,6]  R2639     -2.5699999332427979e+00
    phi[7,6]  R2640     -3.0999999046325684e+00
    phi[7,6]  R2641     -3.0999999046325684e+00
    phi[7,6]  R2642     -2.0899999141693115e+00
    phi[7,6]  R2643     -2.0899999141693115e+00
    phi[7,6]  R2644     -3.0999999046325684e+00
    phi[7,6]  R2645     -3.0999999046325684e+00
    phi[7,6]  R2646     1.9113900661468506e+00
    phi[7,6]  R2647     -4.4643613696098328e-01
    phi[7,6]  R2648     1.5567475557327271e+00
    phi[7,6]  R2649     -8.0506467819213867e-01
    phi[7,6]  R2650     -2.05782413482666
    phi[7,6]  R2651     4.9165353178977966e-02
    phi[7,6]  R2652     -2.3159313201904297e-01
    phi[7,6]  R2653     1.6770650148391724e+00
    phi[7,6]  R2654     1.0318716764450073e+00
    phi[7,6]  R2655     5.9837931394577026e-01
    phi[7,6]  R2656     -1.6408749818801880e+00
    phi[7,6]  R2657     -2.3867704868316650e+00
    phi[7,6]  R2658     -1.0487056970596313e+00
    phi[7,6]  R2659     -7.6988494396209717e-01
    phi[7,6]  R2660     -1.1640688180923462e+00
    phi[7,6]  R2661     3.7339350581169128e-01
    phi[7,6]  R2662     3.4295046329498291e-01
    phi[7,6]  R2663     6.9483411312103271e-01
    phi[7,6]  R2664     -1.7111821174621582e+00
    phi[7,6]  R2665     -2.7399511337280273e+00
    phi[7,6]  R2666     -1.8742944002151489e+00
    phi[7,6]  R2667     -4.7991326451301575e-01
    phi[7,6]  R2668     -2.2946956157684326e+00
    phi[7,6]  R2669     -9.3676692247390747e-01
    phi[7,6]  R2670     -7.6284325122833252e-01
    phi[7,6]  R2671     4.4161331653594971e-01
    phi[7,6]  R2672     -1.8225845694541931e-01
    phi[7,6]  R2673     1.0741157084703445e-01
    phi[7,6]  R2674     1.8629150390625
    phi[7,6]  R2675     1.4589640498161316e-01
    phi[7,6]  R2676     -2.3330132961273193e+00
    phi[7,6]  R2677     8.1520879268646240e-01
    phi[7,6]  R2678     -7.8551101684570312e-01
    phi[7,6]  R2679     9.7357380390167236e-01
    phi[7,6]  R2680     -9.1778314113616943e-01
    phi[7,6]  R2681     1.3279888033866882e-01
    phi[7,6]  R2682     -6.7593210935592651e-01
    phi[7,6]  R2683     8.3452498912811279e-01
    phi[7,6]  R2684     0.917249321937561
    phi[7,6]  R2685     6.7110764980316162e-01
    phi[7,6]  R2686     6.9638466835021973e-01
    phi[7,6]  R2687     1.1149033308029175e+00
    phi[7,6]  R2688     7.5205254554748535e-01
    phi[7,6]  R2689     4.4133463501930237e-01
    phi[7,6]  R2690     1.1141712665557861e+00
    phi[7,6]  R2691     1.0362817049026489e+00
    phi[7,6]  R2692     7.4518150091171265e-01
    phi[7,6]  R2693     6.2080383300781250e-01
    phi[7,6]  R2694     -1.0984357595443726e+00
    phi[7,6]  R2695     -4.9764358997344971e-01
    phi[7,6]  R2696     -1.6419972181320190e+00
    phi[7,6]  R2697     -1.5035352706909180e+00
    phi[7,6]  R2698     -2.6824991703033447e+00
    phi[7,6]  R2699     -1.3900750875473022e+00
    phi[7,6]  R2700     -2.4424611032009125e-01
    phi[7,6]  R2701     -1.5501182079315186e+00
    phi[7,6]  R2702     -1.2427994012832642e+00
    phi[7,6]  R2703     -7.4001765251159668e-01
    phi[7,6]  R2704     -1.5559186935424805e+00
    phi[7,6]  R2705     -1.4434924125671387e+00
    phi[7,6]  R2706     -2.5029923915863037e+00
    phi[7,6]  R2707     -2.8726518154144287e+00
    phi[7,6]  R2708     -3.1387231349945068e+00
    phi[7,6]  R2709     -2.1342675685882568e+00
    phi[7,6]  R2710     -1.9238809347152710e+00
    phi[7,6]  R2711     -0.668778657913208
    phi[7,6]  R2712     -2.8994650840759277e+00
    phi[7,6]  R2713     -7.6136386394500732e-01
    phi[7,6]  R2714     -9.8096543550491333e-01
    phi[7,6]  R2715     -1.5009375810623169e+00
    phi[7,6]  R2716     -1.9809985160827637e+00
    phi[7,6]  R2717     -2.1637823581695557e+00
    phi[7,6]  R2718     -2.5295886993408203e+00
    phi[7,6]  R2719     -2.2102041244506836e+00
    phi[7,6]  R2720     -1.9405622482299805e+00
    phi[7,6]  R2721     -2.1831164360046387e+00
    phi[7,6]  R2722     -2.0480155944824219e+00
    phi[7,6]  R2723     -3.9362147450447083e-02
    phi[7,6]  R2724     -1.1552461385726929e+00
    phi[7,6]  R2725     -1.7038813829421997e+00
    phi[7,6]  R2726     -1.3765782117843628e+00
    phi[7,6]  R2727     -8.6234229803085327e-01
    phi[7,6]  R2728     -1.9150154590606689e+00
    phi[7,6]  R2729     -1.5264697074890137e+00
    phi[7,6]  R2730     -1.5208266973495483e+00
    phi[7,6]  R2731     -1.7068926095962524e+00
    phi[7,6]  R2732     1.9326537847518921e-01
    phi[7,6]  R2733     -2.9780147075653076e+00
    phi[7,6]  R2734     4.3472588062286377e-02
    phi[7,6]  R2735     -1.5105020999908447e+00
    phi[7,6]  R2736     -9.7373247146606445e-01
    phi[7,6]  R2737     -2.0487370491027832e+00
    phi[7,6]  R2738     -1.5901628732681274e+00
    phi[7,6]  R2739     -1.1715462207794189e+00
    phi[7,6]  R2740     -2.3735306262969971e+00
    phi[7,6]  R2741     -2.1843566894531250e+00
    phi[7,6]  R2742     1.9033473730087280e-01
    phi[7,6]  R2743     -5.0295501947402954e-01
    phi[7,6]  R2744     -1.0164351463317871e+00
    phi[7,6]  R2745     -8.5414963960647583e-01
    phi[7,6]  R2746     -2.5340640544891357e+00
    phi[7,6]  R2747     -2.6598623394966125e-01
    phi[7,6]  R2748     4.4882947206497192e-01
    phi[7,6]  R2749     -1.3391474485397339e+00
    phi[7,6]  R2750     -2.6511619091033936e+00
    phi[7,6]  R2751     -2.7533385753631592e+00
    phi[7,6]  R2752     -5.2383834123611450e-01
    phi[7,6]  R2753     -2.2017860412597656e+00
    phi[7,6]  R2754     -2.2278268337249756e+00
    phi[7,6]  R2755     -0.563535749912262
    phi[7,6]  R2756     -1.0979350805282593e+00
    phi[7,6]  R2757     7.7820581197738647e-01
    phi[7,6]  R2758     -1.9514373540878296e+00
    phi[7,6]  R2759     -1.2126215696334839e+00
    phi[7,6]  R2760     -4.3799281120300293e-01
    phi[7,6]  R2761     -2.1205651760101318e+00
    phi[7,6]  R2762     1.1333760023117065e+00
    phi[7,6]  R2763     -1.7122483253479004e-01
    phi[7,6]  R2764     1.2913167476654053e+00
    phi[7,6]  R2765     -1.9848085641860962e+00
    phi[7,6]  R2766     -5.4888319969177246e-01
    phi[7,6]  R2767     -1.2556456327438354e+00
    phi[7,6]  R2768     -2.8660969734191895e+00
    phi[7,6]  R2769     -2.1460925042629242e-01
    phi[7,6]  R2770     -1.28054940700531
    phi[7,6]  R2771     -1.2796907424926758e+00
    phi[7,6]  R2772     -9.5194809138774872e-02
    phi[7,6]  R2773     -4.9208766222000122e-01
    phi[7,6]  R2774     9.8959583044052124e-01
    phi[7,6]  R2775     -2.0442612171173096e+00
    phi[7,6]  R2776     -1.4554131031036377e+00
    phi[7,6]  R2777     -2.4189256131649017e-01
    phi[7,6]  R2778     -1.9648689031600952e+00
    phi[7,6]  R2779     -2.9148730635643005e-01
    phi[7,6]  R2780     -8.8934665918350220e-01
    phi[7,6]  R2781     -2.1878080368041992e+00
    phi[7,6]  R2782     -8.4650105237960815e-01
    phi[7,6]  R2783     -1.0171432495117188e+00
    phi[7,6]  R2784     -1.4771615266799927e+00
    phi[7,6]  R2785     -1.0705137252807617e+00
    phi[7,6]  R2786     -1.4200100898742676e+00
    phi[7,6]  R2787     -3.3985075354576111e-01
    phi[7,6]  R2788     -0.466865211725235
    phi[7,6]  R2789     -5.1214151084423065e-02
    phi[7,6]  R2790     -3.6568677425384521e-01
    phi[7,6]  R2791     -1.0456889867782593e+00
    phi[7,6]  R2792     -8.1152600049972534e-01
    phi[7,6]  R2793     -7.6313740015029907e-01
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       -2.7733368486840955e+00
    phi[7,9]  R66       9.8669403480810658e-01
    phi[7,9]  R67       -3.3438466390740818e-01
    phi[7,9]  R68       1.4409000075495051e+00
    phi[7,9]  R69       -1.3666156194665757e+00
    phi[7,9]  R70       -9.5796932988997030e-01
    phi[7,9]  R71       1.7753088012792446e+00
    phi[7,9]  R73       -1
    phi[7,9]  R2794     -5.8733367533166643e+00
    phi[7,9]  R2795     -3.2666305594847289e-01
    phi[7,9]  R2796     -1.2533059747286366e+00
    phi[7,9]  R2797     -3.2266940443448497e+00
    phi[7,9]  R2798     -3.4343845685399765e+00
    phi[7,9]  R2799     -2.76561524072516
    phi[7,9]  R2800     -1.1290999256932928e+00
    phi[7,9]  R2801     -4.0108999407923029e+00
    phi[7,9]  R2802     -4.4666155240991436e+00
    phi[7,9]  R2803     -1.7333842851659926e+00
    phi[7,9]  R2804     -3.0479692440592818e+00
    phi[7,9]  R2805     -1.1320305842793412e+00
    phi[7,9]  R2806     -1.3246911033533237e+00
    phi[7,9]  R2807     -4.8753087059118130e+00
    phi[7,9]  R2808     -4.0311077744314527e-02
    phi[7,9]  R2809     -1.0213196112692413e-01
    phi[7,9]  R2810     -1.0588901337863210e-01
    phi[7,9]  R2811     -1.3131733926624745e-01
    phi[7,9]  R2812     -1.3642621515478437e-01
    phi[7,9]  R2813     -1.4806947730778097e-01
    phi[7,9]  R2814     -2.1426221558106939e-01
    phi[7,9]  R2815     -2.2670519358422614e-01
    phi[7,9]  R2816     -2.3151651658221661e-01
    phi[7,9]  R2817     -3.2995916154316540e-01
    phi[7,9]  R2818     -2.5178791696852132e-01
    phi[7,9]  R2819     -2.7865604088326723e-01
    phi[7,9]  R2820     -3.6619008204120029e-01
    phi[7,9]  R2821     -3.7854169152248535e-01
    phi[7,9]  R2822     -4.0319246300262035e-01
    phi[7,9]  R2823     -1.5056485466725160e+00
    phi[7,9]  R2824     -1.4746183441300107e+00
    phi[7,9]  R2825     -1.5350144594578490e+00
    phi[7,9]  R2826     -8.0667875919271825e-02
    phi[7,9]  R2827     -1.1171893471580230e-01
    phi[7,9]  R2828     -1.5264415638845796e-01
    phi[7,9]  R2829     -1.9519891059337025e-01
    phi[7,9]  R2830     -2.0000790144345038e-01
    phi[7,9]  R2831     -2.1374684074482297e-01
    phi[7,9]  R2832     -2.1641773415952770e-01
    phi[7,9]  R2833     -2.2795362634736560e-01
    phi[7,9]  R2834     -2.3276549460180290e-01
    phi[7,9]  R2835     -0.239186259822737
    phi[7,9]  R2836     -0.119820117638326
    phi[7,9]  R2837     -1.3546504508294044e-01
    phi[7,9]  R2838     -1.8086818477772404e-01
    phi[7,9]  R2839     -1.8585928243046856e-01
    phi[7,9]  R2840     -2.0808685609513311e-01
    phi[7,9]  R2841     -2.1134262615382138e-01
    phi[7,9]  R2842     -2.2700524462164196e-01
    phi[7,9]  R2843     -2.2774202043105868e-01
    phi[7,9]  R2844     -2.3426109972593961e-01
    phi[7,9]  R2845     -1.4301574480010917e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       -1.6187654435634613e-01
    z[0,1,0]  R89       -3.6669820547103882e-02
    z[0,1,0]  R90       -6.5070308744907379e-02
    z[0,1,0]  R91       1.7870430648326874e-01
    z[0,1,0]  R92       1.3694921135902405e-01
    z[0,1,0]  R93       2.3822438716888428e-01
    z[0,1,0]  R94       5.6398135423660278e-01
    z[0,1,0]  R95       3.0818325281143188e-01
    z[0,1,0]  R96       3.5258715506643057e-03
    z[0,1,0]  R97       1.5639305114746094e-01
    z[0,1,0]  R98       -3.8188499212265015e-01
    z[0,1,0]  R99       -4.6533294022083282e-02
    z[0,1,0]  R100      1.2883096933364868e-01
    z[0,1,0]  R101      -9.1774207353591919e-01
    z[0,1,0]  R102      3.3866548538208008e-01
    z[0,1,0]  R103      -8.9019075036048889e-02
    z[0,1,0]  R104      -3.7917357683181763e-01
    z[0,1,0]  R105      -3.8839015364646912e-01
    z[0,1,0]  R106      -5.3715944290161133e-01
    z[0,1,0]  R107      -1.0944569483399391e-02
    z[0,1,0]  R108      1.0832799226045609e-01
    z[0,1,0]  R109      4.0233525633811951e-01
    z[0,1,0]  R110      -4.0792047977447510e-01
    z[0,1,0]  R111      -4.5169967412948608e-01
    z[0,1,0]  R112      -3.2847154140472412e-01
    z[0,1,0]  R113      -2.6780608296394348e-01
    z[0,1,0]  R114      -2.0311391353607178e-01
    z[0,1,0]  R115      5.9570875018835068e-02
    z[0,1,0]  R116      -3.3729523420333862e-02
    z[0,1,0]  R117      -2.7376219630241394e-01
    z[0,1,0]  R118      -0.838451623916626
    z[0,1,0]  R119      1.3518887758255005e-01
    z[0,1,0]  R120      -3.1528422236442566e-01
    z[0,1,0]  R121      0.504865825176239
    z[0,1,0]  R122      1.3343152403831482e-01
    z[0,1,0]  R123      -3.4083083271980286e-01
    z[0,1,0]  R124      1.1983264237642288e-01
    z[0,1,0]  R125      -2.2848868370056152e-01
    z[0,1,0]  R126      5.3196984529495239e-01
    z[0,1,0]  R127      -5.1326394081115723e-01
    z[0,1,0]  R128      -1.8504685163497925e-01
    z[0,1,0]  R129      -4.1042396426200867e-01
    z[0,1,0]  R130      -3.6015835404396057e-01
    z[0,1,0]  R131      -3.9248549938201904e-01
    z[0,1,0]  R132      -5.3533172607421875e-01
    z[0,1,0]  R133      -5.1385068893432617e-01
    z[0,1,0]  R134      -0.294125497341156
    z[0,1,0]  R135      -4.9046209454536438e-01
    z[0,1,0]  R136      -1.8783503770828247e-01
    z[0,1,0]  R137      -2.4487075209617615e-01
    z[0,1,0]  R138      -3.0964162945747375e-01
    z[0,1,0]  R139      -5.7068222761154175e-01
    z[0,1,0]  R140      -4.5240543782711029e-02
    z[0,1,0]  R141      -1.3260327279567719e-01
    z[0,1,0]  R142      5.0913608074188232e-01
    z[0,1,0]  R143      4.3723034858703613e-01
    z[0,1,0]  R144      3.8654750585556030e-01
    z[0,1,0]  R145      5.7518702745437622e-01
    z[0,1,0]  R146      5.7469648122787476e-01
    z[0,1,0]  R147      2.2413673996925354e-01
    z[0,1,0]  R148      -7.6443636417388916e-01
    z[0,1,0]  R149      -6.9400042295455933e-01
    z[0,1,0]  R150      -8.3020389080047607e-01
    z[0,1,0]  R151      -3.9931410551071167e-01
    z[0,1,0]  R152      -7.2825539112091064e-01
    z[0,1,0]  R153      -7.0837658643722534e-01
    z[0,1,0]  R154      -3.4922859072685242e-01
    z[0,1,0]  R155      1.9114144146442413e-01
    z[0,1,0]  R156      3.2021217048168182e-02
    z[0,1,0]  R157      -3.1742650270462036e-01
    z[0,1,0]  R158      -6.5962892770767212e-01
    z[0,1,0]  R159      -4.2270287871360779e-01
    z[0,1,0]  R160      -7.2531211376190186e-01
    z[0,1,0]  R161      -5.7918995618820190e-01
    z[0,1,0]  R162      -7.6002550125122070e-01
    z[0,1,0]  R163      -1.7553168535232544e-01
    z[0,1,0]  R164      -7.1153730154037476e-01
    z[0,1,0]  R165      -4.8035293817520142e-01
    z[0,1,0]  R166      -3.8778927922248840e-01
    z[0,1,0]  R167      -3.6483600735664368e-02
    z[0,1,0]  R168      -8.2963532209396362e-01
    z[0,1,0]  R169      -6.8737351894378662e-01
    z[0,1,0]  R170      -7.1367490291595459e-01
    z[0,1,0]  R171      -2.0795506238937378e-01
    z[0,1,0]  R172      -3.9442569017410278e-01
    z[0,1,0]  R173      -2.4038979411125183e-01
    z[0,1,0]  R174      3.4578088670969009e-02
    z[0,1,0]  R175      -1.9409339129924774e-01
    z[0,1,0]  R176      -1.0027784854173660e-01
    z[0,1,0]  R177      7.5281602330505848e-03
    z[0,1,0]  R178      -7.5817912817001343e-01
    z[0,1,0]  R179      -0.585847795009613
    z[0,1,0]  R180      -1.7512808740139008e-01
    z[0,1,0]  R181      5.4685866832733154e-01
    z[0,1,0]  R182      5.0207936763763428e-01
    z[0,1,0]  R183      -3.2939542084932327e-02
    z[0,1,0]  R184      -1.2607021629810333e-01
    z[0,1,0]  R185      8.6718820035457611e-02
    z[0,1,0]  R186      -3.6362364888191223e-01
    z[0,1,0]  R187      4.5727172493934631e-01
    z[0,1,0]  R188      -7.9709625244140625e-01
    z[0,1,0]  R189      1.0934278368949890e-01
    z[0,1,0]  R190      -1.5613633394241333e-01
    z[0,1,0]  R191      6.6998727619647980e-02
    z[0,1,0]  R192      -2.7986937761306763e-01
    z[0,1,0]  R193      2.3405288159847260e-01
    z[0,1,0]  R194      -1.4988117851316929e-02
    z[0,1,0]  R195      0.00427770521491766
    z[0,1,0]  R196      2.8082564473152161e-01
    z[0,1,0]  R197      4.0474772453308105e-01
    z[0,1,0]  R198      -0.840641438961029
    z[0,1,0]  R199      -5.1673197746276855e-01
    z[0,1,0]  R200      4.7091841697692871e-01
    z[0,1,0]  R201      -2.8321981430053711e-01
    z[0,1,0]  R202      1.2995104491710663e-01
    z[0,1,0]  R203      1.8130710721015930e-01
    z[0,1,0]  R204      3.1230497360229492e-01
    z[0,1,0]  R205      1.9165314733982086e-01
    z[0,1,0]  R206      1.5388001501560211e-01
    z[0,1,0]  R207      5.1341748237609863e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       -7.8761085867881775e-02
    z[0,1,1]  R89       -2.9952749609947205e-01
    z[0,1,1]  R90       -3.9784133434295654e-01
    z[0,1,1]  R91       -1.2140488624572754e-01
    z[0,1,1]  R92       -7.0837664604187012e-01
    z[0,1,1]  R93       0.528520941734314
    z[0,1,1]  R94       5.2718675136566162e-01
    z[0,1,1]  R95       4.5138993859291077e-01
    z[0,1,1]  R96       9.3922424316406250e-01
    z[0,1,1]  R97       -0.400981068611145
    z[0,1,1]  R98       -7.0057755708694458e-01
    z[0,1,1]  R99       -4.9933272600173950e-01
    z[0,1,1]  R100      -5.5525845289230347e-01
    z[0,1,1]  R101      2.0030984282493591e-01
    z[0,1,1]  R102      -5.9063273668289185e-01
    z[0,1,1]  R103      -5.9684383869171143e-01
    z[0,1,1]  R104      -3.4544280171394348e-01
    z[0,1,1]  R105      6.2092536687850952e-01
    z[0,1,1]  R106      4.1224548220634460e-01
    z[0,1,1]  R107      6.7911767959594727e-01
    z[0,1,1]  R108      8.9026141166687012e-01
    z[0,1,1]  R109      -5.8368378877639771e-01
    z[0,1,1]  R110      -0.6959268450737
    z[0,1,1]  R111      -7.2642713785171509e-01
    z[0,1,1]  R112      -0.923673152923584
    z[0,1,1]  R113      -0.658703088760376
    z[0,1,1]  R114      6.7406189441680908e-01
    z[0,1,1]  R115      -4.1646924614906311e-01
    z[0,1,1]  R116      -5.3340089321136475e-01
    z[0,1,1]  R117      -5.9226626157760620e-01
    z[0,1,1]  R118      -3.8199466466903687e-01
    z[0,1,1]  R119      -8.0890589952468872e-01
    z[0,1,1]  R120      -6.1422210931777954e-01
    z[0,1,1]  R121      -6.5959709882736206e-01
    z[0,1,1]  R122      -6.6213244199752808e-01
    z[0,1,1]  R123      -5.8613014221191406e-01
    z[0,1,1]  R124      -8.6710357666015625e-01
    z[0,1,1]  R125      -7.5010299682617188e-01
    z[0,1,1]  R126      -8.1494438648223877e-01
    z[0,1,1]  R127      6.7133855819702148e-01
    z[0,1,1]  R128      -1.7523691058158875e-01
    z[0,1,1]  R129      -1.6719432175159454e-01
    z[0,1,1]  R130      3.8764795660972595e-01
    z[0,1,1]  R131      -6.0433227568864822e-02
    z[0,1,1]  R132      -6.9771325588226318e-01
    z[0,1,1]  R133      -2.4238368868827820e-01
    z[0,1,1]  R134      4.1101232171058655e-01
    z[0,1,1]  R135      -3.6673498153686523e-01
    z[0,1,1]  R136      5.7936519384384155e-01
    z[0,1,1]  R137      2.9406782984733582e-01
    z[0,1,1]  R138      -4.9336525797843933e-01
    z[0,1,1]  R139      2.2819752991199493e-01
    z[0,1,1]  R140      -5.3672146797180176e-01
    z[0,1,1]  R141      -8.8703013956546783e-02
    z[0,1,1]  R142      -3.6340686678886414e-01
    z[0,1,1]  R143      -7.6629793643951416e-01
    z[0,1,1]  R144      -1.9543415307998657e-01
    z[0,1,1]  R145      -5.2890110015869141e-01
    z[0,1,1]  R146      -4.1696822643280029e-01
    z[0,1,1]  R147      -4.6006512641906738e-01
    z[0,1,1]  R148      -0.0542781837284565
    z[0,1,1]  R149      2.6327449083328247e-01
    z[0,1,1]  R150      -9.6835397183895111e-02
    z[0,1,1]  R151      3.1895977258682251e-01
    z[0,1,1]  R152      -1.4942237176001072e-02
    z[0,1,1]  R153      1.4007595181465149e-01
    z[0,1,1]  R154      3.7733522057533264e-01
    z[0,1,1]  R155      2.2731362283229828e-01
    z[0,1,1]  R156      0.656013011932373
    z[0,1,1]  R157      -1.2028472125530243e-01
    z[0,1,1]  R158      -2.0583732426166534e-01
    z[0,1,1]  R159      0.0802420824766159
    z[0,1,1]  R160      0.226536363363266
    z[0,1,1]  R161      -7.4536859989166260e-02
    z[0,1,1]  R162      -7.2944097220897675e-02
    z[0,1,1]  R163      5.7489979267120361e-01
    z[0,1,1]  R164      -0.541951596736908
    z[0,1,1]  R165      -7.5490123033523560e-01
    z[0,1,1]  R166      6.7670869827270508e-01
    z[0,1,1]  R167      -6.3960880041122437e-01
    z[0,1,1]  R168      -3.2839035987854004e-01
    z[0,1,1]  R169      1.5256562270224094e-02
    z[0,1,1]  R170      -2.3919717967510223e-01
    z[0,1,1]  R171      6.7518049478530884e-01
    z[0,1,1]  R172      -6.7618393898010254e-01
    z[0,1,1]  R173      1.4976819977164268e-02
    z[0,1,1]  R174      9.9239133298397064e-02
    z[0,1,1]  R175      5.8465201407670975e-02
    z[0,1,1]  R176      -3.6602858453989029e-02
    z[0,1,1]  R177      -3.7773722410202026e-01
    z[0,1,1]  R178      -2.3643411695957184e-01
    z[0,1,1]  R179      3.9748489856719971e-01
    z[0,1,1]  R180      -0.0962492972612381
    z[0,1,1]  R181      -7.2016052901744843e-02
    z[0,1,1]  R182      -7.8580141067504883e-01
    z[0,1,1]  R183      -7.4929273128509521e-01
    z[0,1,1]  R184      5.3999584913253784e-01
    z[0,1,1]  R185      -0.459747314453125
    z[0,1,1]  R186      -5.8260124921798706e-01
    z[0,1,1]  R187      1.2367238849401474e-01
    z[0,1,1]  R188      -4.4082650542259216e-01
    z[0,1,1]  R189      -1.9293196499347687e-01
    z[0,1,1]  R190      1.0183781385421753e-02
    z[0,1,1]  R191      -8.0275171995162964e-01
    z[0,1,1]  R192      -7.8943598270416260e-01
    z[0,1,1]  R193      2.6834788918495178e-01
    z[0,1,1]  R194      -6.6552299261093140e-01
    z[0,1,1]  R195      -6.2895292043685913e-01
    z[0,1,1]  R196      -1.6427399218082428e-01
    z[0,1,1]  R197      -7.1306502819061279e-01
    z[0,1,1]  R198      -1.2277639657258987e-01
    z[0,1,1]  R199      5.0446885824203491e-01
    z[0,1,1]  R200      6.5233653783798218e-01
    z[0,1,1]  R201      -7.5898337364196777e-01
    z[0,1,1]  R202      -1.4968656003475189e-01
    z[0,1,1]  R203      3.3593121170997620e-01
    z[0,1,1]  R204      -0.62202388048172
    z[0,1,1]  R205      -8.9839559793472290e-01
    z[0,1,1]  R206      -3.7316444516181946e-01
    z[0,1,1]  R207      -7.5438439846038818e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       -3.6971929669380188e-01
    z[0,1,2]  R89       -1.4951153099536896e-01
    z[0,1,2]  R90       -5.9516811370849609e-01
    z[0,1,2]  R91       -1.1265303939580917e-01
    z[0,1,2]  R92       -4.7889359295368195e-02
    z[0,1,2]  R93       -6.6632813215255737e-01
    z[0,1,2]  R94       -5.1571035385131836e-01
    z[0,1,2]  R95       -5.1994717121124268e-01
    z[0,1,2]  R96       -3.0188050866127014e-01
    z[0,1,2]  R97       2.6512312889099121e-01
    z[0,1,2]  R98       1.0790812969207764e-01
    z[0,1,2]  R99       1.8355131149291992e-01
    z[0,1,2]  R100      1.8166385591030121e-01
    z[0,1,2]  R101      4.2296975851058960e-02
    z[0,1,2]  R102      -2.4945567548274994e-01
    z[0,1,2]  R103      3.7572573870420456e-02
    z[0,1,2]  R104      -4.1270256042480469e-01
    z[0,1,2]  R105      5.4423063993453979e-01
    z[0,1,2]  R106      6.5377593040466309e-01
    z[0,1,2]  R107      4.7492194175720215e-01
    z[0,1,2]  R108      2.7741983532905579e-01
    z[0,1,2]  R109      -1.7960971593856812e-01
    z[0,1,2]  R110      -1.1927965283393860e-01
    z[0,1,2]  R111      -3.2968902587890625e-01
    z[0,1,2]  R112      1.1441857367753983e-01
    z[0,1,2]  R113      -8.5632979869842529e-02
    z[0,1,2]  R114      2.1599149703979492e-01
    z[0,1,2]  R115      1.5880663692951202e-01
    z[0,1,2]  R116      3.3363479375839233e-01
    z[0,1,2]  R117      -2.5188761949539185e-01
    z[0,1,2]  R118      1.3133817911148071e-01
    z[0,1,2]  R119      5.8052893728017807e-03
    z[0,1,2]  R120      3.3413541316986084e-01
    z[0,1,2]  R121      8.8722974061965942e-02
    z[0,1,2]  R122      4.6535611152648926e-02
    z[0,1,2]  R123      -2.3692335188388824e-01
    z[0,1,2]  R124      -1.0424795560538769e-02
    z[0,1,2]  R125      -7.4031185358762741e-03
    z[0,1,2]  R126      5.6204706430435181e-02
    z[0,1,2]  R127      -0.398944228887558
    z[0,1,2]  R128      -7.0025521516799927e-01
    z[0,1,2]  R129      -7.6836895942687988e-01
    z[0,1,2]  R130      -0.0929165631532669
    z[0,1,2]  R131      -4.3553096055984497e-01
    z[0,1,2]  R132      1.8740169703960419e-01
    z[0,1,2]  R133      -3.3837187290191650e-01
    z[0,1,2]  R134      -7.1238033473491669e-02
    z[0,1,2]  R135      -5.3833943605422974e-01
    z[0,1,2]  R136      -5.2186346054077148e-01
    z[0,1,2]  R137      -8.6485099792480469e-01
    z[0,1,2]  R138      -3.9744108915328979e-01
    z[0,1,2]  R139      1.5725603699684143e-01
    z[0,1,2]  R140      2.7716800570487976e-01
    z[0,1,2]  R141      -3.1933054327964783e-01
    z[0,1,2]  R142      3.9546927809715271e-01
    z[0,1,2]  R143      -1.5717601776123047e-01
    z[0,1,2]  R144      3.7255945801734924e-01
    z[0,1,2]  R145      5.3710758686065674e-01
    z[0,1,2]  R146      4.6185827255249023e-01
    z[0,1,2]  R147      6.3423448801040649e-01
    z[0,1,2]  R148      -2.0403549075126648e-01
    z[0,1,2]  R149      -2.6846387982368469e-01
    z[0,1,2]  R150      -9.0720631182193756e-02
    z[0,1,2]  R151      -2.8542402386665344e-01
    z[0,1,2]  R152      -1.1157270520925522e-01
    z[0,1,2]  R153      1.3022735714912415e-01
    z[0,1,2]  R154      -1.3916942477226257e-01
    z[0,1,2]  R155      2.6455676555633545e-01
    z[0,1,2]  R156      -4.4667381048202515e-01
    z[0,1,2]  R157      4.6143519878387451e-01
    z[0,1,2]  R158      -4.1570979356765747e-01
    z[0,1,2]  R159      -0.739593505859375
    z[0,1,2]  R160      -3.4730136394500732e-01
    z[0,1,2]  R161      -2.1545560657978058e-01
    z[0,1,2]  R162      -1.1575036495923996e-01
    z[0,1,2]  R163      -4.0366676449775696e-01
    z[0,1,2]  R164      -3.9089929312467575e-02
    z[0,1,2]  R165      -3.6604872345924377e-01
    z[0,1,2]  R166      -5.3441685438156128e-01
    z[0,1,2]  R167      -1.4731751382350922e-01
    z[0,1,2]  R168      6.4919173717498779e-02
    z[0,1,2]  R169      -4.3855801224708557e-01
    z[0,1,2]  R170      7.6549343764781952e-02
    z[0,1,2]  R171      -4.3491214513778687e-01
    z[0,1,2]  R172      -2.6849663257598877e-01
    z[0,1,2]  R173      2.1794764697551727e-01
    z[0,1,2]  R174      4.1993027925491333e-01
    z[0,1,2]  R175      -2.7109694480895996e-01
    z[0,1,2]  R176      2.2073593735694885e-01
    z[0,1,2]  R177      4.9149698019027710e-01
    z[0,1,2]  R178      -0.0428561195731163
    z[0,1,2]  R179      -5.2748352289199829e-01
    z[0,1,2]  R180      2.3536044359207153e-01
    z[0,1,2]  R181      -1.1757723242044449e-01
    z[0,1,2]  R182      2.0246763527393341e-01
    z[0,1,2]  R183      3.1087455153465271e-01
    z[0,1,2]  R184      7.8904800117015839e-02
    z[0,1,2]  R185      -2.2650142014026642e-01
    z[0,1,2]  R186      6.4786237478256226e-01
    z[0,1,2]  R187      -0.54561448097229
    z[0,1,2]  R188      -0.0861566811800003
    z[0,1,2]  R189      -1.2679979205131531e-01
    z[0,1,2]  R190      -5.7672321796417236e-01
    z[0,1,2]  R191      1.9212525337934494e-02
    z[0,1,2]  R192      3.5149121284484863e-01
    z[0,1,2]  R193      -2.0834234356880188e-01
    z[0,1,2]  R194      1.1803038418292999e-01
    z[0,1,2]  R195      -1.1426251381635666e-01
    z[0,1,2]  R196      -3.3169126510620117e-01
    z[0,1,2]  R197      -5.3151518106460571e-02
    z[0,1,2]  R198      -3.6207896471023560e-01
    z[0,1,2]  R199      -1.8947304785251617e-01
    z[0,1,2]  R200      -3.4503698348999023e-01
    z[0,1,2]  R201      1.6016542911529541e-01
    z[0,1,2]  R202      -2.2463127970695496e-01
    z[0,1,2]  R203      -2.0017072558403015e-01
    z[0,1,2]  R204      0.338600754737854
    z[0,1,2]  R205      -8.5146024823188782e-02
    z[0,1,2]  R206      -8.3877243101596832e-02
    z[0,1,2]  R207      -1.3389788568019867e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       7.6794660091400146e-01
    z[0,1,3]  R89       8.6472308635711670e-01
    z[0,1,3]  R90       6.8713134527206421e-01
    z[0,1,3]  R91       8.3261716365814209e-01
    z[0,1,3]  R92       -8.1853784620761871e-02
    z[0,1,3]  R93       1.8095223605632782e-01
    z[0,1,3]  R94       1.5081661939620972e-01
    z[0,1,3]  R95       1.3063374161720276e-01
    z[0,1,3]  R96       -5.1535878330469131e-02
    z[0,1,3]  R97       -1.6649590106680989e-03
    z[0,1,3]  R98       -3.1473204493522644e-01
    z[0,1,3]  R99       -4.4716751575469971e-01
    z[0,1,3]  R100      -4.9315184354782104e-01
    z[0,1,3]  R101      -0.00214373623020947
    z[0,1,3]  R102      -4.7881555557250977e-01
    z[0,1,3]  R103      -3.6441421508789062e-01
    z[0,1,3]  R104      -0.595511257648468
    z[0,1,3]  R105      1.8446531891822815e-01
    z[0,1,3]  R106      1.0180281102657318e-01
    z[0,1,3]  R107      4.6506009995937347e-02
    z[0,1,3]  R108      3.1403493881225586e-01
    z[0,1,3]  R109      -5.7860243320465088e-01
    z[0,1,3]  R110      -1.7366696894168854e-01
    z[0,1,3]  R111      -3.0290535092353821e-01
    z[0,1,3]  R112      9.2141412198543549e-02
    z[0,1,3]  R113      -8.1208914518356323e-02
    z[0,1,3]  R114      0.468307226896286
    z[0,1,3]  R115      -8.7096989154815674e-01
    z[0,1,3]  R116      -6.8640893697738647e-01
    z[0,1,3]  R117      -4.5225679874420166e-01
    z[0,1,3]  R118      3.1594225764274597e-01
    z[0,1,3]  R119      -3.9615079760551453e-01
    z[0,1,3]  R120      4.6801942586898804e-01
    z[0,1,3]  R121      -0.521098256111145
    z[0,1,3]  R122      -4.0949147939682007e-01
    z[0,1,3]  R123      -6.4126449823379517e-01
    z[0,1,3]  R124      -2.7795603871345520e-01
    z[0,1,3]  R125      -5.4370927810668945e-01
    z[0,1,3]  R126      8.0922648310661316e-02
    z[0,1,3]  R127      2.1831846237182617e-01
    z[0,1,3]  R128      3.6499090492725372e-02
    z[0,1,3]  R129      4.2380407452583313e-01
    z[0,1,3]  R130      5.0820440053939819e-01
    z[0,1,3]  R131      6.3960433006286621e-01
    z[0,1,3]  R132      3.3650997281074524e-01
    z[0,1,3]  R133      1.9221606850624084e-01
    z[0,1,3]  R134      2.6353740692138672e-01
    z[0,1,3]  R135      2.3746763169765472e-01
    z[0,1,3]  R136      5.3477507829666138e-01
    z[0,1,3]  R137      1.0930994898080826e-01
    z[0,1,3]  R138      -4.6457889676094055e-01
    z[0,1,3]  R139      5.0418758392333984e-01
    z[0,1,3]  R140      -4.6074721217155457e-01
    z[0,1,3]  R141      -3.0038896203041077e-01
    z[0,1,3]  R142      3.4020888805389404e-01
    z[0,1,3]  R143      -3.1392174959182739e-01
    z[0,1,3]  R144      1.8635661900043488e-01
    z[0,1,3]  R145      0.0696042999625206
    z[0,1,3]  R146      3.8880702853202820e-01
    z[0,1,3]  R147      2.0800997316837311e-01
    z[0,1,3]  R148      4.0330576896667480e-01
    z[0,1,3]  R149      1.7856582999229431e-02
    z[0,1,3]  R150      1.0562287271022797e-01
    z[0,1,3]  R151      5.0042307376861572e-01
    z[0,1,3]  R152      -1.2341390550136566e-01
    z[0,1,3]  R153      4.5411249995231628e-01
    z[0,1,3]  R154      -4.3373328447341919e-01
    z[0,1,3]  R155      -7.0228505134582520e-01
    z[0,1,3]  R156      2.5343433022499084e-02
    z[0,1,3]  R157      -0.541547417640686
    z[0,1,3]  R158      -2.4376621469855309e-02
    z[0,1,3]  R159      4.8547735810279846e-01
    z[0,1,3]  R160      5.0373876094818115e-01
    z[0,1,3]  R161      2.6542711257934570e-01
    z[0,1,3]  R162      5.8216649293899536e-01
    z[0,1,3]  R163      7.7554568648338318e-02
    z[0,1,3]  R164      1.7386291921138763e-01
    z[0,1,3]  R165      1.5898482874035835e-02
    z[0,1,3]  R166      2.1585205197334290e-01
    z[0,1,3]  R167      -5.3929954767227173e-01
    z[0,1,3]  R168      2.8598424792289734e-01
    z[0,1,3]  R169      5.7795327156782150e-02
    z[0,1,3]  R170      5.7174623012542725e-01
    z[0,1,3]  R171      -3.3884122967720032e-01
    z[0,1,3]  R172      2.6786521077156067e-01
    z[0,1,3]  R173      -4.5454555749893188e-01
    z[0,1,3]  R174      -0.686290979385376
    z[0,1,3]  R175      -6.2507015466690063e-01
    z[0,1,3]  R176      -7.8475004434585571e-01
    z[0,1,3]  R177      -6.1852329969406128e-01
    z[0,1,3]  R178      5.2582442760467529e-01
    z[0,1,3]  R179      -6.0382641851902008e-02
    z[0,1,3]  R180      -7.2278821468353271e-01
    z[0,1,3]  R181      -5.0711852312088013e-01
    z[0,1,3]  R182      1.3981281220912933e-01
    z[0,1,3]  R183      -3.8838258385658264e-01
    z[0,1,3]  R184      -4.6801382303237915e-01
    z[0,1,3]  R185      -1.5272186696529388e-01
    z[0,1,3]  R186      -1.5562401711940765e-01
    z[0,1,3]  R187      -3.8897407054901123e-01
    z[0,1,3]  R188      3.3179691433906555e-01
    z[0,1,3]  R189      -7.4050635099411011e-01
    z[0,1,3]  R190      -7.1543955802917480e-01
    z[0,1,3]  R191      -1.6899734735488892e-01
    z[0,1,3]  R192      -2.9901450872421265e-01
    z[0,1,3]  R193      -6.2989783287048340e-01
    z[0,1,3]  R194      -3.0583354830741882e-01
    z[0,1,3]  R195      -9.0693213045597076e-02
    z[0,1,3]  R196      -3.6551168560981750e-01
    z[0,1,3]  R197      -2.0487499237060547e-01
    z[0,1,3]  R198      2.2473834455013275e-01
    z[0,1,3]  R199      3.9176097512245178e-01
    z[0,1,3]  R200      3.1831261515617371e-01
    z[0,1,3]  R201      -3.2946917414665222e-01
    z[0,1,3]  R202      -7.1472346782684326e-01
    z[0,1,3]  R203      -5.3426802158355713e-01
    z[0,1,3]  R204      9.2764936387538910e-02
    z[0,1,3]  R205      3.5665526986122131e-01
    z[0,1,3]  R206      -1.0075378417968750e-01
    z[0,1,3]  R207      6.7626923322677612e-02
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       1.7630153894424438e-01
    z[0,1,4]  R89       2.0615678280591965e-02
    z[0,1,4]  R90       -5.3882561624050140e-02
    z[0,1,4]  R91       -3.4775489568710327e-01
    z[0,1,4]  R92       1.8391543626785278e-01
    z[0,1,4]  R93       8.7523169815540314e-02
    z[0,1,4]  R94       -1.9205805659294128e-01
    z[0,1,4]  R95       -2.2817084193229675e-01
    z[0,1,4]  R96       7.6746948063373566e-02
    z[0,1,4]  R97       -7.9487639665603638e-01
    z[0,1,4]  R98       -1.9228808581829071e-01
    z[0,1,4]  R99       -4.0037795901298523e-02
    z[0,1,4]  R100      -5.6105995178222656e-01
    z[0,1,4]  R101      1.7563469707965851e-01
    z[0,1,4]  R102      -1.1404889822006226e-01
    z[0,1,4]  R103      -2.6967343688011169e-01
    z[0,1,4]  R104      -1.2300878018140793e-01
    z[0,1,4]  R105      -1.4413508772850037e-01
    z[0,1,4]  R106      -1.5676420927047729e-01
    z[0,1,4]  R107      -2.6545768976211548e-01
    z[0,1,4]  R108      -5.4726146161556244e-02
    z[0,1,4]  R109      1.1502062529325485e-01
    z[0,1,4]  R110      -0.417994886636734
    z[0,1,4]  R111      1.1842245608568192e-01
    z[0,1,4]  R112      -3.3896487206220627e-02
    z[0,1,4]  R113      4.2852178215980530e-01
    z[0,1,4]  R114      -1.8425248563289642e-01
    z[0,1,4]  R115      0.0907006487250328
    z[0,1,4]  R116      1.2825265526771545e-01
    z[0,1,4]  R117      3.4871110320091248e-01
    z[0,1,4]  R118      4.1849788278341293e-02
    z[0,1,4]  R119      2.3414996266365051e-01
    z[0,1,4]  R120      -2.6232752203941345e-01
    z[0,1,4]  R121      1.7692150548100471e-02
    z[0,1,4]  R122      -4.1604474186897278e-01
    z[0,1,4]  R123      2.2725290060043335e-01
    z[0,1,4]  R124      -2.0647144317626953e-01
    z[0,1,4]  R125      -5.9597671031951904e-02
    z[0,1,4]  R126      -1.4784540235996246e-01
    z[0,1,4]  R127      1.7358088493347168e-01
    z[0,1,4]  R128      -6.5206247568130493e-01
    z[0,1,4]  R129      -1.2586151063442230e-01
    z[0,1,4]  R130      -3.7285369634628296e-01
    z[0,1,4]  R131      2.2079035639762878e-01
    z[0,1,4]  R132      -4.1671305894851685e-02
    z[0,1,4]  R133      -3.0649396777153015e-01
    z[0,1,4]  R134      -7.3452973365783691e-01
    z[0,1,4]  R135      2.4466475844383240e-01
    z[0,1,4]  R136      7.3377601802349091e-02
    z[0,1,4]  R137      1.7693807184696198e-01
    z[0,1,4]  R138      4.6062642335891724e-01
    z[0,1,4]  R139      -1.2591026723384857e-01
    z[0,1,4]  R140      3.6756515502929688e-01
    z[0,1,4]  R141      0.665052592754364
    z[0,1,4]  R142      2.8749847412109375e-01
    z[0,1,4]  R143      -3.1212879344820976e-02
    z[0,1,4]  R144      -3.7841506302356720e-02
    z[0,1,4]  R145      0.0452711246907711
    z[0,1,4]  R146      0.0777883306145668
    z[0,1,4]  R147      1.3398057222366333e-01
    z[0,1,4]  R148      2.4681188166141510e-01
    z[0,1,4]  R149      -0.088363416492939
    z[0,1,4]  R150      4.5156961679458618e-01
    z[0,1,4]  R151      8.8034041225910187e-02
    z[0,1,4]  R152      -6.2480556964874268e-01
    z[0,1,4]  R153      1.5076331794261932e-01
    z[0,1,4]  R154      -6.4340668916702271e-01
    z[0,1,4]  R155      5.3378814458847046e-01
    z[0,1,4]  R156      -0.409236341714859
    z[0,1,4]  R157      5.5659556388854980e-01
    z[0,1,4]  R158      -3.8463276624679565e-01
    z[0,1,4]  R159      9.5938645303249359e-02
    z[0,1,4]  R160      -6.6198281943798065e-02
    z[0,1,4]  R161      -3.8781216740608215e-01
    z[0,1,4]  R162      -1.2392628192901611e-01
    z[0,1,4]  R163      -3.0565986037254333e-01
    z[0,1,4]  R164      -1.7183527350425720e-01
    z[0,1,4]  R165      1.3652063906192780e-01
    z[0,1,4]  R166      0.0509721003472805
    z[0,1,4]  R167      5.2445590496063232e-01
    z[0,1,4]  R168      2.2199855744838715e-01
    z[0,1,4]  R169      4.9800035357475281e-01
    z[0,1,4]  R170      -1.5305636823177338e-01
    z[0,1,4]  R171      -4.0015062689781189e-01
    z[0,1,4]  R172      -6.5390810370445251e-02
    z[0,1,4]  R173      7.4854081869125366e-01
    z[0,1,4]  R174      4.7155517339706421e-01
    z[0,1,4]  R175      4.6287944912910461e-01
    z[0,1,4]  R176      0.389067679643631
    z[0,1,4]  R177      4.6220120787620544e-01
    z[0,1,4]  R178      -7.2527617216110229e-02
    z[0,1,4]  R179      -4.4467210769653320e-01
    z[0,1,4]  R180      5.6296974420547485e-01
    z[0,1,4]  R181      0.647429883480072
    z[0,1,4]  R182      5.5801492184400558e-02
    z[0,1,4]  R183      -1.7731563746929169e-01
    z[0,1,4]  R184      4.2421564459800720e-01
    z[0,1,4]  R185      1.9498154520988464e-01
    z[0,1,4]  R186      2.2781883180141449e-01
    z[0,1,4]  R187      3.9964246749877930e-01
    z[0,1,4]  R188      3.9224009960889816e-02
    z[0,1,4]  R189      5.6126755475997925e-01
    z[0,1,4]  R190      -3.1642830371856689e-01
    z[0,1,4]  R191      -6.5407925285398960e-03
    z[0,1,4]  R192      1.5727029740810394e-01
    z[0,1,4]  R193      6.1651289463043213e-01
    z[0,1,4]  R194      1.0274988412857056e-01
    z[0,1,4]  R195      1.2560781836509705e-01
    z[0,1,4]  R196      6.3737088441848755e-01
    z[0,1,4]  R197      1.9057793915271759e-01
    z[0,1,4]  R198      7.5338676571846008e-02
    z[0,1,4]  R199      -4.2842742800712585e-01
    z[0,1,4]  R200      -3.0310210585594177e-01
    z[0,1,4]  R201      2.1609136462211609e-01
    z[0,1,4]  R202      2.2000500559806824e-01
    z[0,1,4]  R203      4.0507584810256958e-01
    z[0,1,4]  R204      1.6546308994293213e-01
    z[0,1,4]  R205      -1.2892046570777893e-01
    z[0,1,4]  R206      2.7788332104682922e-01
    z[0,1,4]  R207      -2.9304352402687073e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       -4.0228480100631714e-01
    z[0,1,5]  R89       -4.9198146909475327e-02
    z[0,1,5]  R90       0.0792975053191185
    z[0,1,5]  R91       3.5304924845695496e-01
    z[0,1,5]  R92       -6.5776187181472778e-01
    z[0,1,5]  R93       4.4054705649614334e-02
    z[0,1,5]  R94       2.4234344065189362e-01
    z[0,1,5]  R95       1.3407555222511292e-01
    z[0,1,5]  R96       -7.7068924903869629e-02
    z[0,1,5]  R97       -3.0042329430580139e-01
    z[0,1,5]  R98       4.6157476305961609e-01
    z[0,1,5]  R99       1.4561282098293304e-01
    z[0,1,5]  R100      2.6443246006965637e-01
    z[0,1,5]  R101      1.5825580060482025e-01
    z[0,1,5]  R102      3.4886786341667175e-01
    z[0,1,5]  R103      3.4347385168075562e-01
    z[0,1,5]  R104      -1.1962272226810455e-01
    z[0,1,5]  R105      2.8796166181564331e-01
    z[0,1,5]  R106      2.3559895157814026e-01
    z[0,1,5]  R107      0.419750839471817
    z[0,1,5]  R108      -1.1206749081611633e-01
    z[0,1,5]  R109      -4.7659579664468765e-02
    z[0,1,5]  R110      -3.0286622047424316e-01
    z[0,1,5]  R111      0.0425645150244236
    z[0,1,5]  R112      1.2710003554821014e-01
    z[0,1,5]  R113      -4.5915731787681580e-01
    z[0,1,5]  R114      3.4163451194763184e-01
    z[0,1,5]  R115      -7.2502300143241882e-02
    z[0,1,5]  R116      -2.2156614065170288e-01
    z[0,1,5]  R117      -1.5522105991840363e-01
    z[0,1,5]  R118      9.7653217613697052e-02
    z[0,1,5]  R119      -3.3456695079803467e-01
    z[0,1,5]  R120      2.8733128309249878e-01
    z[0,1,5]  R121      -0.0755414143204689
    z[0,1,5]  R122      -2.2821240127086639e-01
    z[0,1,5]  R123      1.7036728560924530e-02
    z[0,1,5]  R124      3.3079183101654053e-01
    z[0,1,5]  R125      2.7705633640289307e-01
    z[0,1,5]  R126      -5.7150825858116150e-02
    z[0,1,5]  R127      0.0494406558573246
    z[0,1,5]  R128      3.2446511089801788e-02
    z[0,1,5]  R129      -6.5567381680011749e-02
    z[0,1,5]  R130      -0.365255743265152
    z[0,1,5]  R131      -3.6753949522972107e-01
    z[0,1,5]  R132      -2.3557227849960327e-01
    z[0,1,5]  R133      -0.622138261795044
    z[0,1,5]  R134      -3.6611225455999374e-02
    z[0,1,5]  R135      -5.2739516831934452e-03
    z[0,1,5]  R136      -2.3253858089447021e-01
    z[0,1,5]  R137      -2.0286414027214050e-01
    z[0,1,5]  R138      -1.3849419355392456e-01
    z[0,1,5]  R139      5.6229633092880249e-01
    z[0,1,5]  R140      3.6926373839378357e-01
    z[0,1,5]  R141      4.5246917009353638e-01
    z[0,1,5]  R142      -5.0347644090652466e-01
    z[0,1,5]  R143      -3.1183698773384094e-01
    z[0,1,5]  R144      -7.9829913377761841e-01
    z[0,1,5]  R145      -2.9537272453308105e-01
    z[0,1,5]  R146      -2.8188723325729370e-01
    z[0,1,5]  R147      -4.9727156758308411e-01
    z[0,1,5]  R148      -3.7695422768592834e-01
    z[0,1,5]  R149      -4.3837973475456238e-01
    z[0,1,5]  R150      3.8149955216795206e-03
    z[0,1,5]  R151      -6.0314124822616577e-01
    z[0,1,5]  R152      -7.2073573246598244e-03
    z[0,1,5]  R153      4.4679322838783264e-01
    z[0,1,5]  R154      3.0278950929641724e-01
    z[0,1,5]  R155      2.2949904203414917e-02
    z[0,1,5]  R156      -2.5269734859466553e-01
    z[0,1,5]  R157      6.4644269645214081e-02
    z[0,1,5]  R158      -2.2468364238739014e-01
    z[0,1,5]  R159      -6.4025238156318665e-02
    z[0,1,5]  R160      1.6272965073585510e-01
    z[0,1,5]  R161      6.2386733293533325e-01
    z[0,1,5]  R162      1.6510689258575439e-01
    z[0,1,5]  R163      4.6994745731353760e-01
    z[0,1,5]  R164      2.7037739753723145e-01
    z[0,1,5]  R165      2.1190980076789856e-01
    z[0,1,5]  R166      2.1083962917327881e-01
    z[0,1,5]  R167      4.1137434542179108e-02
    z[0,1,5]  R168      -1.3605177402496338e-01
    z[0,1,5]  R169      2.8889194130897522e-01
    z[0,1,5]  R170      -1.4131484925746918e-01
    z[0,1,5]  R171      -1.2616080045700073e-01
    z[0,1,5]  R172      -2.4881792068481445e-01
    z[0,1,5]  R173      3.5429760813713074e-01
    z[0,1,5]  R174      2.5861939787864685e-01
    z[0,1,5]  R175      4.7179350256919861e-01
    z[0,1,5]  R176      -2.3139877617359161e-01
    z[0,1,5]  R177      -9.0957731008529663e-02
    z[0,1,5]  R178      -2.6501569151878357e-01
    z[0,1,5]  R179      1.3838236033916473e-01
    z[0,1,5]  R180      -1.9547903910279274e-02
    z[0,1,5]  R181      7.4831224977970123e-02
    z[0,1,5]  R182      -2.5719344615936279e-01
    z[0,1,5]  R183      -2.8230378031730652e-01
    z[0,1,5]  R184      5.3210198879241943e-01
    z[0,1,5]  R185      -0.801838755607605
    z[0,1,5]  R186      1.8001425266265869e-01
    z[0,1,5]  R187      3.5701093077659607e-01
    z[0,1,5]  R188      -1.5142035484313965e-01
    z[0,1,5]  R189      -1.2355160713195801e-01
    z[0,1,5]  R190      2.4428399279713631e-02
    z[0,1,5]  R191      -4.5424187183380127e-01
    z[0,1,5]  R192      -2.0846258103847504e-01
    z[0,1,5]  R193      -7.1001998148858547e-03
    z[0,1,5]  R194      -6.4996105432510376e-01
    z[0,1,5]  R195      -7.5318956375122070e-01
    z[0,1,5]  R196      4.7404772043228149e-01
    z[0,1,5]  R197      -4.9066326022148132e-01
    z[0,1,5]  R198      -1.1694166809320450e-01
    z[0,1,5]  R199      -0.314789742231369
    z[0,1,5]  R200      -6.6570803523063660e-02
    z[0,1,5]  R201      2.5973695516586304e-01
    z[0,1,5]  R202      5.7863587141036987e-01
    z[0,1,5]  R203      6.0070103406906128e-01
    z[0,1,5]  R204      -5.5635792016983032e-01
    z[0,1,5]  R205      -5.2710570394992828e-02
    z[0,1,5]  R206      8.5005831718444824e-01
    z[0,1,5]  R207      8.9964523911476135e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       -2.1964305639266968e-01
    z[0,1,6]  R89       0.368772953748703
    z[0,1,6]  R90       -0.0438428670167923
    z[0,1,6]  R91       4.2500838637351990e-02
    z[0,1,6]  R92       -6.3074447214603424e-02
    z[0,1,6]  R93       4.2139852046966553e-01
    z[0,1,6]  R94       1.4028424024581909e-01
    z[0,1,6]  R95       -5.8636319637298584e-01
    z[0,1,6]  R96       -1.1057946830987930e-01
    z[0,1,6]  R97       1.4959900081157684e-01
    z[0,1,6]  R98       5.1269207149744034e-02
    z[0,1,6]  R99       0.701459527015686
    z[0,1,6]  R100      -1.1906879395246506e-01
    z[0,1,6]  R101      2.4482533335685730e-01
    z[0,1,6]  R102      3.3203959465026855e-01
    z[0,1,6]  R103      -5.5762499570846558e-01
    z[0,1,6]  R104      4.2719867825508118e-01
    z[0,1,6]  R105      1.7231778800487518e-01
    z[0,1,6]  R106      -1.5376813709735870e-01
    z[0,1,6]  R107      2.5358861684799194e-01
    z[0,1,6]  R108      -6.7570067942142487e-02
    z[0,1,6]  R109      3.3896601200103760e-01
    z[0,1,6]  R110      -1.9608934223651886e-01
    z[0,1,6]  R111      -2.2801077365875244e-01
    z[0,1,6]  R112      -7.0265331305563450e-03
    z[0,1,6]  R113      2.9326745867729187e-01
    z[0,1,6]  R114      2.9624024033546448e-01
    z[0,1,6]  R115      -1.6035377979278564e-01
    z[0,1,6]  R116      -2.5755795836448669e-01
    z[0,1,6]  R117      4.0074729919433594e-01
    z[0,1,6]  R118      -1.5073859691619873e-01
    z[0,1,6]  R119      6.0538213700056076e-02
    z[0,1,6]  R120      -2.0313425362110138e-01
    z[0,1,6]  R121      1.5686756372451782e-01
    z[0,1,6]  R122      -3.8568595051765442e-01
    z[0,1,6]  R123      1.4490982890129089e-01
    z[0,1,6]  R124      -6.5950877964496613e-02
    z[0,1,6]  R125      -0.0956641435623169
    z[0,1,6]  R126      1.3431945443153381e-01
    z[0,1,6]  R127      2.1557042002677917e-01
    z[0,1,6]  R128      1.3085016608238220e-01
    z[0,1,6]  R129      1.1600548774003983e-01
    z[0,1,6]  R130      4.2506250739097595e-01
    z[0,1,6]  R131      2.4431201815605164e-01
    z[0,1,6]  R132      -1.4500702917575836e-01
    z[0,1,6]  R133      2.1159036457538605e-01
    z[0,1,6]  R134      3.5938540101051331e-01
    z[0,1,6]  R135      -4.6782839298248291e-01
    z[0,1,6]  R136      -1.0615862160921097e-01
    z[0,1,6]  R137      -1.4555260539054871e-01
    z[0,1,6]  R138      2.3571690917015076e-01
    z[0,1,6]  R139      1.0621951520442963e-01
    z[0,1,6]  R140      3.8641107082366943e-01
    z[0,1,6]  R141      -3.6785754561424255e-01
    z[0,1,6]  R142      2.0828416571021080e-02
    z[0,1,6]  R143      -1.2216480448842049e-02
    z[0,1,6]  R144      1.1993527412414551e-02
    z[0,1,6]  R145      8.2460641860961914e-02
    z[0,1,6]  R146      2.1416340768337250e-01
    z[0,1,6]  R147      -1.6538253426551819e-01
    z[0,1,6]  R148      -7.3446303606033325e-02
    z[0,1,6]  R149      -4.2032524943351746e-01
    z[0,1,6]  R150      2.7940708398818970e-01
    z[0,1,6]  R151      -1.8813130259513855e-01
    z[0,1,6]  R152      -2.2651143372058868e-01
    z[0,1,6]  R153      -1.8179714679718018e-01
    z[0,1,6]  R154      1.5003718435764313e-01
    z[0,1,6]  R155      -2.5128149986267090e-01
    z[0,1,6]  R156      3.7031254172325134e-01
    z[0,1,6]  R157      -2.5416231155395508e-01
    z[0,1,6]  R158      -3.8818377256393433e-01
    z[0,1,6]  R159      -1.3745276629924774e-01
    z[0,1,6]  R160      -1.3179273903369904e-01
    z[0,1,6]  R161      5.0018224865198135e-02
    z[0,1,6]  R162      1.4868189394474030e-01
    z[0,1,6]  R163      3.9425730705261230e-01
    z[0,1,6]  R164      -2.5615498423576355e-01
    z[0,1,6]  R165      3.9963837713003159e-02
    z[0,1,6]  R166      1.1153426021337509e-01
    z[0,1,6]  R167      1.6635512933135033e-02
    z[0,1,6]  R168      2.2376313805580139e-01
    z[0,1,6]  R169      1.2190598063170910e-02
    z[0,1,6]  R170      -2.3938070237636566e-01
    z[0,1,6]  R171      1.4452320337295532e-01
    z[0,1,6]  R172      4.2092159390449524e-01
    z[0,1,6]  R173      -4.5116588473320007e-02
    z[0,1,6]  R174      2.2884733974933624e-01
    z[0,1,6]  R175      2.4053448438644409e-01
    z[0,1,6]  R176      3.4515008330345154e-01
    z[0,1,6]  R177      -1.0589775443077087e-01
    z[0,1,6]  R178      -1.2426482141017914e-01
    z[0,1,6]  R179      -4.4793472625315189e-03
    z[0,1,6]  R180      -2.5481733679771423e-01
    z[0,1,6]  R181      -7.5411156285554171e-04
    z[0,1,6]  R182      -2.5086278095841408e-02
    z[0,1,6]  R183      2.8081163763999939e-01
    z[0,1,6]  R184      -6.4469978213310242e-02
    z[0,1,6]  R185      -1.5975619852542877e-01
    z[0,1,6]  R186      1.0130092501640320e-02
    z[0,1,6]  R187      1.9859719276428223e-01
    z[0,1,6]  R188      -1.6831737756729126e-01
    z[0,1,6]  R189      2.3686951398849487e-01
    z[0,1,6]  R190      -1.7415709793567657e-01
    z[0,1,6]  R191      -3.4028398990631104e-01
    z[0,1,6]  R192      1.3159666955471039e-01
    z[0,1,6]  R193      -2.2998319566249847e-01
    z[0,1,6]  R194      1.2799315154552460e-01
    z[0,1,6]  R195      -6.8501620553433895e-03
    z[0,1,6]  R196      -1.3989374041557312e-01
    z[0,1,6]  R197      -0.0764738917350769
    z[0,1,6]  R198      2.7800747752189636e-01
    z[0,1,6]  R199      8.0497294664382935e-02
    z[0,1,6]  R200      1.8978126347064972e-01
    z[0,1,6]  R201      3.0881896615028381e-01
    z[0,1,6]  R202      -1.2726396322250366e-01
    z[0,1,6]  R203      6.1962187290191650e-02
    z[0,1,6]  R204      -2.3533812165260315e-01
    z[0,1,6]  R205      -4.7985520213842392e-02
    z[0,1,6]  R206      1.4164811372756958e-01
    z[0,1,6]  R207      2.2546948492527008e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R208      -1
    z[1,0,0]  R209      1
    z[1,0,0]  R222      -1.8504685163497925e-01
    z[1,0,0]  R223      -4.1042396426200867e-01
    z[1,0,0]  R224      -3.6015835404396057e-01
    z[1,0,0]  R225      -3.9248549938201904e-01
    z[1,0,0]  R226      -5.3533172607421875e-01
    z[1,0,0]  R227      -5.1385068893432617e-01
    z[1,0,0]  R228      -0.294125497341156
    z[1,0,0]  R229      -4.9046209454536438e-01
    z[1,0,0]  R230      -1.8783503770828247e-01
    z[1,0,0]  R231      -2.4487075209617615e-01
    z[1,0,0]  R232      -3.0964162945747375e-01
    z[1,0,0]  R233      -5.7068222761154175e-01
    z[1,0,0]  R234      -4.5240543782711029e-02
    z[1,0,0]  R235      -1.3260327279567719e-01
    z[1,0,0]  R236      5.0913608074188232e-01
    z[1,0,0]  R237      4.3723034858703613e-01
    z[1,0,0]  R238      3.8654750585556030e-01
    z[1,0,0]  R239      5.7518702745437622e-01
    z[1,0,0]  R240      5.7469648122787476e-01
    z[1,0,0]  R241      2.2413673996925354e-01
    z[1,0,0]  R242      -7.6443636417388916e-01
    z[1,0,0]  R243      -6.9400042295455933e-01
    z[1,0,0]  R244      -8.3020389080047607e-01
    z[1,0,0]  R245      -3.9931410551071167e-01
    z[1,0,0]  R246      -7.2825539112091064e-01
    z[1,0,0]  R247      -7.0837658643722534e-01
    z[1,0,0]  R248      -3.4922859072685242e-01
    z[1,0,0]  R249      1.9114144146442413e-01
    z[1,0,0]  R250      3.2021217048168182e-02
    z[1,0,0]  R251      -3.1742650270462036e-01
    z[1,0,0]  R252      -6.5962892770767212e-01
    z[1,0,0]  R253      -4.2270287871360779e-01
    z[1,0,0]  R254      -7.2531211376190186e-01
    z[1,0,0]  R255      -5.7918995618820190e-01
    z[1,0,0]  R256      -7.6002550125122070e-01
    z[1,0,0]  R257      -1.7553168535232544e-01
    z[1,0,0]  R258      -7.1153730154037476e-01
    z[1,0,0]  R259      -4.8035293817520142e-01
    z[1,0,0]  R260      -3.8778927922248840e-01
    z[1,0,0]  R261      -3.6483600735664368e-02
    z[1,0,0]  R262      -8.2963532209396362e-01
    z[1,0,0]  R263      -6.8737351894378662e-01
    z[1,0,0]  R264      -7.1367490291595459e-01
    z[1,0,0]  R265      -2.0795506238937378e-01
    z[1,0,0]  R266      -3.9442569017410278e-01
    z[1,0,0]  R267      -2.4038979411125183e-01
    z[1,0,0]  R268      3.4578088670969009e-02
    z[1,0,0]  R269      -1.9409339129924774e-01
    z[1,0,0]  R270      -1.0027784854173660e-01
    z[1,0,0]  R271      7.5281602330505848e-03
    z[1,0,0]  R272      -7.5817912817001343e-01
    z[1,0,0]  R273      -0.585847795009613
    z[1,0,0]  R274      -1.7512808740139008e-01
    z[1,0,0]  R275      5.4685866832733154e-01
    z[1,0,0]  R276      5.0207936763763428e-01
    z[1,0,0]  R277      -3.2939542084932327e-02
    z[1,0,0]  R278      -1.2607021629810333e-01
    z[1,0,0]  R279      8.6718820035457611e-02
    z[1,0,0]  R280      -3.6362364888191223e-01
    z[1,0,0]  R281      4.5727172493934631e-01
    z[1,0,0]  R282      -7.9709625244140625e-01
    z[1,0,0]  R283      1.0934278368949890e-01
    z[1,0,0]  R284      -1.5613633394241333e-01
    z[1,0,0]  R285      6.6998727619647980e-02
    z[1,0,0]  R286      -2.7986937761306763e-01
    z[1,0,0]  R287      2.3405288159847260e-01
    z[1,0,0]  R288      -1.4988117851316929e-02
    z[1,0,0]  R289      0.00427770521491766
    z[1,0,0]  R290      2.8082564473152161e-01
    z[1,0,0]  R291      4.0474772453308105e-01
    z[1,0,0]  R292      -0.840641438961029
    z[1,0,0]  R293      -5.1673197746276855e-01
    z[1,0,0]  R294      4.7091841697692871e-01
    z[1,0,0]  R295      -2.8321981430053711e-01
    z[1,0,0]  R296      1.2995104491710663e-01
    z[1,0,0]  R297      1.8130710721015930e-01
    z[1,0,0]  R298      3.1230497360229492e-01
    z[1,0,0]  R299      1.9165314733982086e-01
    z[1,0,0]  R300      1.5388001501560211e-01
    z[1,0,0]  R301      5.1341748237609863e-01
    z[1,0,0]  R302      -1.6187654435634613e-01
    z[1,0,0]  R303      -3.6669820547103882e-02
    z[1,0,0]  R304      -6.5070308744907379e-02
    z[1,0,0]  R305      1.7870430648326874e-01
    z[1,0,0]  R306      1.3694921135902405e-01
    z[1,0,0]  R307      2.3822438716888428e-01
    z[1,0,0]  R308      5.6398135423660278e-01
    z[1,0,0]  R309      3.0818325281143188e-01
    z[1,0,0]  R310      3.5258715506643057e-03
    z[1,0,0]  R311      1.5639305114746094e-01
    z[1,0,0]  R312      -3.8188499212265015e-01
    z[1,0,0]  R313      -4.6533294022083282e-02
    z[1,0,0]  R314      1.2883096933364868e-01
    z[1,0,0]  R315      -9.1774207353591919e-01
    z[1,0,0]  R316      3.3866548538208008e-01
    z[1,0,0]  R317      -8.9019075036048889e-02
    z[1,0,0]  R318      -3.7917357683181763e-01
    z[1,0,0]  R319      -3.8839015364646912e-01
    z[1,0,0]  R320      -5.3715944290161133e-01
    z[1,0,0]  R321      -1.0944569483399391e-02
    z[1,0,0]  R322      1.0832799226045609e-01
    z[1,0,0]  R323      4.0233525633811951e-01
    z[1,0,0]  R324      -4.0792047977447510e-01
    z[1,0,0]  R325      -4.5169967412948608e-01
    z[1,0,0]  R326      -3.2847154140472412e-01
    z[1,0,0]  R327      -2.6780608296394348e-01
    z[1,0,0]  R328      -2.0311391353607178e-01
    z[1,0,0]  R329      5.9570875018835068e-02
    z[1,0,0]  R330      -3.3729523420333862e-02
    z[1,0,0]  R331      -2.7376219630241394e-01
    z[1,0,0]  R332      -0.838451623916626
    z[1,0,0]  R333      1.3518887758255005e-01
    z[1,0,0]  R334      -3.1528422236442566e-01
    z[1,0,0]  R335      0.504865825176239
    z[1,0,0]  R336      1.3343152403831482e-01
    z[1,0,0]  R337      -3.4083083271980286e-01
    z[1,0,0]  R338      1.1983264237642288e-01
    z[1,0,0]  R339      -2.2848868370056152e-01
    z[1,0,0]  R340      5.3196984529495239e-01
    z[1,0,0]  R341      -5.1326394081115723e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R210      -1
    z[1,0,1]  R211      1
    z[1,0,1]  R222      -1.7523691058158875e-01
    z[1,0,1]  R223      -1.6719432175159454e-01
    z[1,0,1]  R224      3.8764795660972595e-01
    z[1,0,1]  R225      -6.0433227568864822e-02
    z[1,0,1]  R226      -6.9771325588226318e-01
    z[1,0,1]  R227      -2.4238368868827820e-01
    z[1,0,1]  R228      4.1101232171058655e-01
    z[1,0,1]  R229      -3.6673498153686523e-01
    z[1,0,1]  R230      5.7936519384384155e-01
    z[1,0,1]  R231      2.9406782984733582e-01
    z[1,0,1]  R232      -4.9336525797843933e-01
    z[1,0,1]  R233      2.2819752991199493e-01
    z[1,0,1]  R234      -5.3672146797180176e-01
    z[1,0,1]  R235      -8.8703013956546783e-02
    z[1,0,1]  R236      -3.6340686678886414e-01
    z[1,0,1]  R237      -7.6629793643951416e-01
    z[1,0,1]  R238      -1.9543415307998657e-01
    z[1,0,1]  R239      -5.2890110015869141e-01
    z[1,0,1]  R240      -4.1696822643280029e-01
    z[1,0,1]  R241      -4.6006512641906738e-01
    z[1,0,1]  R242      -0.0542781837284565
    z[1,0,1]  R243      2.6327449083328247e-01
    z[1,0,1]  R244      -9.6835397183895111e-02
    z[1,0,1]  R245      3.1895977258682251e-01
    z[1,0,1]  R246      -1.4942237176001072e-02
    z[1,0,1]  R247      1.4007595181465149e-01
    z[1,0,1]  R248      3.7733522057533264e-01
    z[1,0,1]  R249      2.2731362283229828e-01
    z[1,0,1]  R250      0.656013011932373
    z[1,0,1]  R251      -1.2028472125530243e-01
    z[1,0,1]  R252      -2.0583732426166534e-01
    z[1,0,1]  R253      0.0802420824766159
    z[1,0,1]  R254      0.226536363363266
    z[1,0,1]  R255      -7.4536859989166260e-02
    z[1,0,1]  R256      -7.2944097220897675e-02
    z[1,0,1]  R257      5.7489979267120361e-01
    z[1,0,1]  R258      -0.541951596736908
    z[1,0,1]  R259      -7.5490123033523560e-01
    z[1,0,1]  R260      6.7670869827270508e-01
    z[1,0,1]  R261      -6.3960880041122437e-01
    z[1,0,1]  R262      -3.2839035987854004e-01
    z[1,0,1]  R263      1.5256562270224094e-02
    z[1,0,1]  R264      -2.3919717967510223e-01
    z[1,0,1]  R265      6.7518049478530884e-01
    z[1,0,1]  R266      -6.7618393898010254e-01
    z[1,0,1]  R267      1.4976819977164268e-02
    z[1,0,1]  R268      9.9239133298397064e-02
    z[1,0,1]  R269      5.8465201407670975e-02
    z[1,0,1]  R270      -3.6602858453989029e-02
    z[1,0,1]  R271      -3.7773722410202026e-01
    z[1,0,1]  R272      -2.3643411695957184e-01
    z[1,0,1]  R273      3.9748489856719971e-01
    z[1,0,1]  R274      -0.0962492972612381
    z[1,0,1]  R275      -7.2016052901744843e-02
    z[1,0,1]  R276      -7.8580141067504883e-01
    z[1,0,1]  R277      -7.4929273128509521e-01
    z[1,0,1]  R278      5.3999584913253784e-01
    z[1,0,1]  R279      -0.459747314453125
    z[1,0,1]  R280      -5.8260124921798706e-01
    z[1,0,1]  R281      1.2367238849401474e-01
    z[1,0,1]  R282      -4.4082650542259216e-01
    z[1,0,1]  R283      -1.9293196499347687e-01
    z[1,0,1]  R284      1.0183781385421753e-02
    z[1,0,1]  R285      -8.0275171995162964e-01
    z[1,0,1]  R286      -7.8943598270416260e-01
    z[1,0,1]  R287      2.6834788918495178e-01
    z[1,0,1]  R288      -6.6552299261093140e-01
    z[1,0,1]  R289      -6.2895292043685913e-01
    z[1,0,1]  R290      -1.6427399218082428e-01
    z[1,0,1]  R291      -7.1306502819061279e-01
    z[1,0,1]  R292      -1.2277639657258987e-01
    z[1,0,1]  R293      5.0446885824203491e-01
    z[1,0,1]  R294      6.5233653783798218e-01
    z[1,0,1]  R295      -7.5898337364196777e-01
    z[1,0,1]  R296      -1.4968656003475189e-01
    z[1,0,1]  R297      3.3593121170997620e-01
    z[1,0,1]  R298      -0.62202388048172
    z[1,0,1]  R299      -8.9839559793472290e-01
    z[1,0,1]  R300      -3.7316444516181946e-01
    z[1,0,1]  R301      -7.5438439846038818e-01
    z[1,0,1]  R302      -7.8761085867881775e-02
    z[1,0,1]  R303      -2.9952749609947205e-01
    z[1,0,1]  R304      -3.9784133434295654e-01
    z[1,0,1]  R305      -1.2140488624572754e-01
    z[1,0,1]  R306      -7.0837664604187012e-01
    z[1,0,1]  R307      0.528520941734314
    z[1,0,1]  R308      5.2718675136566162e-01
    z[1,0,1]  R309      4.5138993859291077e-01
    z[1,0,1]  R310      9.3922424316406250e-01
    z[1,0,1]  R311      -0.400981068611145
    z[1,0,1]  R312      -7.0057755708694458e-01
    z[1,0,1]  R313      -4.9933272600173950e-01
    z[1,0,1]  R314      -5.5525845289230347e-01
    z[1,0,1]  R315      2.0030984282493591e-01
    z[1,0,1]  R316      -5.9063273668289185e-01
    z[1,0,1]  R317      -5.9684383869171143e-01
    z[1,0,1]  R318      -3.4544280171394348e-01
    z[1,0,1]  R319      6.2092536687850952e-01
    z[1,0,1]  R320      4.1224548220634460e-01
    z[1,0,1]  R321      6.7911767959594727e-01
    z[1,0,1]  R322      8.9026141166687012e-01
    z[1,0,1]  R323      -5.8368378877639771e-01
    z[1,0,1]  R324      -0.6959268450737
    z[1,0,1]  R325      -7.2642713785171509e-01
    z[1,0,1]  R326      -0.923673152923584
    z[1,0,1]  R327      -0.658703088760376
    z[1,0,1]  R328      6.7406189441680908e-01
    z[1,0,1]  R329      -4.1646924614906311e-01
    z[1,0,1]  R330      -5.3340089321136475e-01
    z[1,0,1]  R331      -5.9226626157760620e-01
    z[1,0,1]  R332      -3.8199466466903687e-01
    z[1,0,1]  R333      -8.0890589952468872e-01
    z[1,0,1]  R334      -6.1422210931777954e-01
    z[1,0,1]  R335      -6.5959709882736206e-01
    z[1,0,1]  R336      -6.6213244199752808e-01
    z[1,0,1]  R337      -5.8613014221191406e-01
    z[1,0,1]  R338      -8.6710357666015625e-01
    z[1,0,1]  R339      -7.5010299682617188e-01
    z[1,0,1]  R340      -8.1494438648223877e-01
    z[1,0,1]  R341      6.7133855819702148e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R212      -1
    z[1,0,2]  R213      1
    z[1,0,2]  R222      -7.0025521516799927e-01
    z[1,0,2]  R223      -7.6836895942687988e-01
    z[1,0,2]  R224      -0.0929165631532669
    z[1,0,2]  R225      -4.3553096055984497e-01
    z[1,0,2]  R226      1.8740169703960419e-01
    z[1,0,2]  R227      -3.3837187290191650e-01
    z[1,0,2]  R228      -7.1238033473491669e-02
    z[1,0,2]  R229      -5.3833943605422974e-01
    z[1,0,2]  R230      -5.2186346054077148e-01
    z[1,0,2]  R231      -8.6485099792480469e-01
    z[1,0,2]  R232      -3.9744108915328979e-01
    z[1,0,2]  R233      1.5725603699684143e-01
    z[1,0,2]  R234      2.7716800570487976e-01
    z[1,0,2]  R235      -3.1933054327964783e-01
    z[1,0,2]  R236      3.9546927809715271e-01
    z[1,0,2]  R237      -1.5717601776123047e-01
    z[1,0,2]  R238      3.7255945801734924e-01
    z[1,0,2]  R239      5.3710758686065674e-01
    z[1,0,2]  R240      4.6185827255249023e-01
    z[1,0,2]  R241      6.3423448801040649e-01
    z[1,0,2]  R242      -2.0403549075126648e-01
    z[1,0,2]  R243      -2.6846387982368469e-01
    z[1,0,2]  R244      -9.0720631182193756e-02
    z[1,0,2]  R245      -2.8542402386665344e-01
    z[1,0,2]  R246      -1.1157270520925522e-01
    z[1,0,2]  R247      1.3022735714912415e-01
    z[1,0,2]  R248      -1.3916942477226257e-01
    z[1,0,2]  R249      2.6455676555633545e-01
    z[1,0,2]  R250      -4.4667381048202515e-01
    z[1,0,2]  R251      4.6143519878387451e-01
    z[1,0,2]  R252      -4.1570979356765747e-01
    z[1,0,2]  R253      -0.739593505859375
    z[1,0,2]  R254      -3.4730136394500732e-01
    z[1,0,2]  R255      -2.1545560657978058e-01
    z[1,0,2]  R256      -1.1575036495923996e-01
    z[1,0,2]  R257      -4.0366676449775696e-01
    z[1,0,2]  R258      -3.9089929312467575e-02
    z[1,0,2]  R259      -3.6604872345924377e-01
    z[1,0,2]  R260      -5.3441685438156128e-01
    z[1,0,2]  R261      -1.4731751382350922e-01
    z[1,0,2]  R262      6.4919173717498779e-02
    z[1,0,2]  R263      -4.3855801224708557e-01
    z[1,0,2]  R264      7.6549343764781952e-02
    z[1,0,2]  R265      -4.3491214513778687e-01
    z[1,0,2]  R266      -2.6849663257598877e-01
    z[1,0,2]  R267      2.1794764697551727e-01
    z[1,0,2]  R268      4.1993027925491333e-01
    z[1,0,2]  R269      -2.7109694480895996e-01
    z[1,0,2]  R270      2.2073593735694885e-01
    z[1,0,2]  R271      4.9149698019027710e-01
    z[1,0,2]  R272      -0.0428561195731163
    z[1,0,2]  R273      -5.2748352289199829e-01
    z[1,0,2]  R274      2.3536044359207153e-01
    z[1,0,2]  R275      -1.1757723242044449e-01
    z[1,0,2]  R276      2.0246763527393341e-01
    z[1,0,2]  R277      3.1087455153465271e-01
    z[1,0,2]  R278      7.8904800117015839e-02
    z[1,0,2]  R279      -2.2650142014026642e-01
    z[1,0,2]  R280      6.4786237478256226e-01
    z[1,0,2]  R281      -0.54561448097229
    z[1,0,2]  R282      -0.0861566811800003
    z[1,0,2]  R283      -1.2679979205131531e-01
    z[1,0,2]  R284      -5.7672321796417236e-01
    z[1,0,2]  R285      1.9212525337934494e-02
    z[1,0,2]  R286      3.5149121284484863e-01
    z[1,0,2]  R287      -2.0834234356880188e-01
    z[1,0,2]  R288      1.1803038418292999e-01
    z[1,0,2]  R289      -1.1426251381635666e-01
    z[1,0,2]  R290      -3.3169126510620117e-01
    z[1,0,2]  R291      -5.3151518106460571e-02
    z[1,0,2]  R292      -3.6207896471023560e-01
    z[1,0,2]  R293      -1.8947304785251617e-01
    z[1,0,2]  R294      -3.4503698348999023e-01
    z[1,0,2]  R295      1.6016542911529541e-01
    z[1,0,2]  R296      -2.2463127970695496e-01
    z[1,0,2]  R297      -2.0017072558403015e-01
    z[1,0,2]  R298      0.338600754737854
    z[1,0,2]  R299      -8.5146024823188782e-02
    z[1,0,2]  R300      -8.3877243101596832e-02
    z[1,0,2]  R301      -1.3389788568019867e-01
    z[1,0,2]  R302      -3.6971929669380188e-01
    z[1,0,2]  R303      -1.4951153099536896e-01
    z[1,0,2]  R304      -5.9516811370849609e-01
    z[1,0,2]  R305      -1.1265303939580917e-01
    z[1,0,2]  R306      -4.7889359295368195e-02
    z[1,0,2]  R307      -6.6632813215255737e-01
    z[1,0,2]  R308      -5.1571035385131836e-01
    z[1,0,2]  R309      -5.1994717121124268e-01
    z[1,0,2]  R310      -3.0188050866127014e-01
    z[1,0,2]  R311      2.6512312889099121e-01
    z[1,0,2]  R312      1.0790812969207764e-01
    z[1,0,2]  R313      1.8355131149291992e-01
    z[1,0,2]  R314      1.8166385591030121e-01
    z[1,0,2]  R315      4.2296975851058960e-02
    z[1,0,2]  R316      -2.4945567548274994e-01
    z[1,0,2]  R317      3.7572573870420456e-02
    z[1,0,2]  R318      -4.1270256042480469e-01
    z[1,0,2]  R319      5.4423063993453979e-01
    z[1,0,2]  R320      6.5377593040466309e-01
    z[1,0,2]  R321      4.7492194175720215e-01
    z[1,0,2]  R322      2.7741983532905579e-01
    z[1,0,2]  R323      -1.7960971593856812e-01
    z[1,0,2]  R324      -1.1927965283393860e-01
    z[1,0,2]  R325      -3.2968902587890625e-01
    z[1,0,2]  R326      1.1441857367753983e-01
    z[1,0,2]  R327      -8.5632979869842529e-02
    z[1,0,2]  R328      2.1599149703979492e-01
    z[1,0,2]  R329      1.5880663692951202e-01
    z[1,0,2]  R330      3.3363479375839233e-01
    z[1,0,2]  R331      -2.5188761949539185e-01
    z[1,0,2]  R332      1.3133817911148071e-01
    z[1,0,2]  R333      5.8052893728017807e-03
    z[1,0,2]  R334      3.3413541316986084e-01
    z[1,0,2]  R335      8.8722974061965942e-02
    z[1,0,2]  R336      4.6535611152648926e-02
    z[1,0,2]  R337      -2.3692335188388824e-01
    z[1,0,2]  R338      -1.0424795560538769e-02
    z[1,0,2]  R339      -7.4031185358762741e-03
    z[1,0,2]  R340      5.6204706430435181e-02
    z[1,0,2]  R341      -0.398944228887558
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R214      -1
    z[1,0,3]  R215      1
    z[1,0,3]  R222      3.6499090492725372e-02
    z[1,0,3]  R223      4.2380407452583313e-01
    z[1,0,3]  R224      5.0820440053939819e-01
    z[1,0,3]  R225      6.3960433006286621e-01
    z[1,0,3]  R226      3.3650997281074524e-01
    z[1,0,3]  R227      1.9221606850624084e-01
    z[1,0,3]  R228      2.6353740692138672e-01
    z[1,0,3]  R229      2.3746763169765472e-01
    z[1,0,3]  R230      5.3477507829666138e-01
    z[1,0,3]  R231      1.0930994898080826e-01
    z[1,0,3]  R232      -4.6457889676094055e-01
    z[1,0,3]  R233      5.0418758392333984e-01
    z[1,0,3]  R234      -4.6074721217155457e-01
    z[1,0,3]  R235      -3.0038896203041077e-01
    z[1,0,3]  R236      3.4020888805389404e-01
    z[1,0,3]  R237      -3.1392174959182739e-01
    z[1,0,3]  R238      1.8635661900043488e-01
    z[1,0,3]  R239      0.0696042999625206
    z[1,0,3]  R240      3.8880702853202820e-01
    z[1,0,3]  R241      2.0800997316837311e-01
    z[1,0,3]  R242      4.0330576896667480e-01
    z[1,0,3]  R243      1.7856582999229431e-02
    z[1,0,3]  R244      1.0562287271022797e-01
    z[1,0,3]  R245      5.0042307376861572e-01
    z[1,0,3]  R246      -1.2341390550136566e-01
    z[1,0,3]  R247      4.5411249995231628e-01
    z[1,0,3]  R248      -4.3373328447341919e-01
    z[1,0,3]  R249      -7.0228505134582520e-01
    z[1,0,3]  R250      2.5343433022499084e-02
    z[1,0,3]  R251      -0.541547417640686
    z[1,0,3]  R252      -2.4376621469855309e-02
    z[1,0,3]  R253      4.8547735810279846e-01
    z[1,0,3]  R254      5.0373876094818115e-01
    z[1,0,3]  R255      2.6542711257934570e-01
    z[1,0,3]  R256      5.8216649293899536e-01
    z[1,0,3]  R257      7.7554568648338318e-02
    z[1,0,3]  R258      1.7386291921138763e-01
    z[1,0,3]  R259      1.5898482874035835e-02
    z[1,0,3]  R260      2.1585205197334290e-01
    z[1,0,3]  R261      -5.3929954767227173e-01
    z[1,0,3]  R262      2.8598424792289734e-01
    z[1,0,3]  R263      5.7795327156782150e-02
    z[1,0,3]  R264      5.7174623012542725e-01
    z[1,0,3]  R265      -3.3884122967720032e-01
    z[1,0,3]  R266      2.6786521077156067e-01
    z[1,0,3]  R267      -4.5454555749893188e-01
    z[1,0,3]  R268      -0.686290979385376
    z[1,0,3]  R269      -6.2507015466690063e-01
    z[1,0,3]  R270      -7.8475004434585571e-01
    z[1,0,3]  R271      -6.1852329969406128e-01
    z[1,0,3]  R272      5.2582442760467529e-01
    z[1,0,3]  R273      -6.0382641851902008e-02
    z[1,0,3]  R274      -7.2278821468353271e-01
    z[1,0,3]  R275      -5.0711852312088013e-01
    z[1,0,3]  R276      1.3981281220912933e-01
    z[1,0,3]  R277      -3.8838258385658264e-01
    z[1,0,3]  R278      -4.6801382303237915e-01
    z[1,0,3]  R279      -1.5272186696529388e-01
    z[1,0,3]  R280      -1.5562401711940765e-01
    z[1,0,3]  R281      -3.8897407054901123e-01
    z[1,0,3]  R282      3.3179691433906555e-01
    z[1,0,3]  R283      -7.4050635099411011e-01
    z[1,0,3]  R284      -7.1543955802917480e-01
    z[1,0,3]  R285      -1.6899734735488892e-01
    z[1,0,3]  R286      -2.9901450872421265e-01
    z[1,0,3]  R287      -6.2989783287048340e-01
    z[1,0,3]  R288      -3.0583354830741882e-01
    z[1,0,3]  R289      -9.0693213045597076e-02
    z[1,0,3]  R290      -3.6551168560981750e-01
    z[1,0,3]  R291      -2.0487499237060547e-01
    z[1,0,3]  R292      2.2473834455013275e-01
    z[1,0,3]  R293      3.9176097512245178e-01
    z[1,0,3]  R294      3.1831261515617371e-01
    z[1,0,3]  R295      -3.2946917414665222e-01
    z[1,0,3]  R296      -7.1472346782684326e-01
    z[1,0,3]  R297      -5.3426802158355713e-01
    z[1,0,3]  R298      9.2764936387538910e-02
    z[1,0,3]  R299      3.5665526986122131e-01
    z[1,0,3]  R300      -1.0075378417968750e-01
    z[1,0,3]  R301      6.7626923322677612e-02
    z[1,0,3]  R302      7.6794660091400146e-01
    z[1,0,3]  R303      8.6472308635711670e-01
    z[1,0,3]  R304      6.8713134527206421e-01
    z[1,0,3]  R305      8.3261716365814209e-01
    z[1,0,3]  R306      -8.1853784620761871e-02
    z[1,0,3]  R307      1.8095223605632782e-01
    z[1,0,3]  R308      1.5081661939620972e-01
    z[1,0,3]  R309      1.3063374161720276e-01
    z[1,0,3]  R310      -5.1535878330469131e-02
    z[1,0,3]  R311      -1.6649590106680989e-03
    z[1,0,3]  R312      -3.1473204493522644e-01
    z[1,0,3]  R313      -4.4716751575469971e-01
    z[1,0,3]  R314      -4.9315184354782104e-01
    z[1,0,3]  R315      -0.00214373623020947
    z[1,0,3]  R316      -4.7881555557250977e-01
    z[1,0,3]  R317      -3.6441421508789062e-01
    z[1,0,3]  R318      -0.595511257648468
    z[1,0,3]  R319      1.8446531891822815e-01
    z[1,0,3]  R320      1.0180281102657318e-01
    z[1,0,3]  R321      4.6506009995937347e-02
    z[1,0,3]  R322      3.1403493881225586e-01
    z[1,0,3]  R323      -5.7860243320465088e-01
    z[1,0,3]  R324      -1.7366696894168854e-01
    z[1,0,3]  R325      -3.0290535092353821e-01
    z[1,0,3]  R326      9.2141412198543549e-02
    z[1,0,3]  R327      -8.1208914518356323e-02
    z[1,0,3]  R328      0.468307226896286
    z[1,0,3]  R329      -8.7096989154815674e-01
    z[1,0,3]  R330      -6.8640893697738647e-01
    z[1,0,3]  R331      -4.5225679874420166e-01
    z[1,0,3]  R332      3.1594225764274597e-01
    z[1,0,3]  R333      -3.9615079760551453e-01
    z[1,0,3]  R334      4.6801942586898804e-01
    z[1,0,3]  R335      -0.521098256111145
    z[1,0,3]  R336      -4.0949147939682007e-01
    z[1,0,3]  R337      -6.4126449823379517e-01
    z[1,0,3]  R338      -2.7795603871345520e-01
    z[1,0,3]  R339      -5.4370927810668945e-01
    z[1,0,3]  R340      8.0922648310661316e-02
    z[1,0,3]  R341      2.1831846237182617e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R216      -1
    z[1,0,4]  R217      1
    z[1,0,4]  R222      -6.5206247568130493e-01
    z[1,0,4]  R223      -1.2586151063442230e-01
    z[1,0,4]  R224      -3.7285369634628296e-01
    z[1,0,4]  R225      2.2079035639762878e-01
    z[1,0,4]  R226      -4.1671305894851685e-02
    z[1,0,4]  R227      -3.0649396777153015e-01
    z[1,0,4]  R228      -7.3452973365783691e-01
    z[1,0,4]  R229      2.4466475844383240e-01
    z[1,0,4]  R230      7.3377601802349091e-02
    z[1,0,4]  R231      1.7693807184696198e-01
    z[1,0,4]  R232      4.6062642335891724e-01
    z[1,0,4]  R233      -1.2591026723384857e-01
    z[1,0,4]  R234      3.6756515502929688e-01
    z[1,0,4]  R235      0.665052592754364
    z[1,0,4]  R236      2.8749847412109375e-01
    z[1,0,4]  R237      -3.1212879344820976e-02
    z[1,0,4]  R238      -3.7841506302356720e-02
    z[1,0,4]  R239      0.0452711246907711
    z[1,0,4]  R240      0.0777883306145668
    z[1,0,4]  R241      1.3398057222366333e-01
    z[1,0,4]  R242      2.4681188166141510e-01
    z[1,0,4]  R243      -0.088363416492939
    z[1,0,4]  R244      4.5156961679458618e-01
    z[1,0,4]  R245      8.8034041225910187e-02
    z[1,0,4]  R246      -6.2480556964874268e-01
    z[1,0,4]  R247      1.5076331794261932e-01
    z[1,0,4]  R248      -6.4340668916702271e-01
    z[1,0,4]  R249      5.3378814458847046e-01
    z[1,0,4]  R250      -0.409236341714859
    z[1,0,4]  R251      5.5659556388854980e-01
    z[1,0,4]  R252      -3.8463276624679565e-01
    z[1,0,4]  R253      9.5938645303249359e-02
    z[1,0,4]  R254      -6.6198281943798065e-02
    z[1,0,4]  R255      -3.8781216740608215e-01
    z[1,0,4]  R256      -1.2392628192901611e-01
    z[1,0,4]  R257      -3.0565986037254333e-01
    z[1,0,4]  R258      -1.7183527350425720e-01
    z[1,0,4]  R259      1.3652063906192780e-01
    z[1,0,4]  R260      0.0509721003472805
    z[1,0,4]  R261      5.2445590496063232e-01
    z[1,0,4]  R262      2.2199855744838715e-01
    z[1,0,4]  R263      4.9800035357475281e-01
    z[1,0,4]  R264      -1.5305636823177338e-01
    z[1,0,4]  R265      -4.0015062689781189e-01
    z[1,0,4]  R266      -6.5390810370445251e-02
    z[1,0,4]  R267      7.4854081869125366e-01
    z[1,0,4]  R268      4.7155517339706421e-01
    z[1,0,4]  R269      4.6287944912910461e-01
    z[1,0,4]  R270      0.389067679643631
    z[1,0,4]  R271      4.6220120787620544e-01
    z[1,0,4]  R272      -7.2527617216110229e-02
    z[1,0,4]  R273      -4.4467210769653320e-01
    z[1,0,4]  R274      5.6296974420547485e-01
    z[1,0,4]  R275      0.647429883480072
    z[1,0,4]  R276      5.5801492184400558e-02
    z[1,0,4]  R277      -1.7731563746929169e-01
    z[1,0,4]  R278      4.2421564459800720e-01
    z[1,0,4]  R279      1.9498154520988464e-01
    z[1,0,4]  R280      2.2781883180141449e-01
    z[1,0,4]  R281      3.9964246749877930e-01
    z[1,0,4]  R282      3.9224009960889816e-02
    z[1,0,4]  R283      5.6126755475997925e-01
    z[1,0,4]  R284      -3.1642830371856689e-01
    z[1,0,4]  R285      -6.5407925285398960e-03
    z[1,0,4]  R286      1.5727029740810394e-01
    z[1,0,4]  R287      6.1651289463043213e-01
    z[1,0,4]  R288      1.0274988412857056e-01
    z[1,0,4]  R289      1.2560781836509705e-01
    z[1,0,4]  R290      6.3737088441848755e-01
    z[1,0,4]  R291      1.9057793915271759e-01
    z[1,0,4]  R292      7.5338676571846008e-02
    z[1,0,4]  R293      -4.2842742800712585e-01
    z[1,0,4]  R294      -3.0310210585594177e-01
    z[1,0,4]  R295      2.1609136462211609e-01
    z[1,0,4]  R296      2.2000500559806824e-01
    z[1,0,4]  R297      4.0507584810256958e-01
    z[1,0,4]  R298      1.6546308994293213e-01
    z[1,0,4]  R299      -1.2892046570777893e-01
    z[1,0,4]  R300      2.7788332104682922e-01
    z[1,0,4]  R301      -2.9304352402687073e-01
    z[1,0,4]  R302      1.7630153894424438e-01
    z[1,0,4]  R303      2.0615678280591965e-02
    z[1,0,4]  R304      -5.3882561624050140e-02
    z[1,0,4]  R305      -3.4775489568710327e-01
    z[1,0,4]  R306      1.8391543626785278e-01
    z[1,0,4]  R307      8.7523169815540314e-02
    z[1,0,4]  R308      -1.9205805659294128e-01
    z[1,0,4]  R309      -2.2817084193229675e-01
    z[1,0,4]  R310      7.6746948063373566e-02
    z[1,0,4]  R311      -7.9487639665603638e-01
    z[1,0,4]  R312      -1.9228808581829071e-01
    z[1,0,4]  R313      -4.0037795901298523e-02
    z[1,0,4]  R314      -5.6105995178222656e-01
    z[1,0,4]  R315      1.7563469707965851e-01
    z[1,0,4]  R316      -1.1404889822006226e-01
    z[1,0,4]  R317      -2.6967343688011169e-01
    z[1,0,4]  R318      -1.2300878018140793e-01
    z[1,0,4]  R319      -1.4413508772850037e-01
    z[1,0,4]  R320      -1.5676420927047729e-01
    z[1,0,4]  R321      -2.6545768976211548e-01
    z[1,0,4]  R322      -5.4726146161556244e-02
    z[1,0,4]  R323      1.1502062529325485e-01
    z[1,0,4]  R324      -0.417994886636734
    z[1,0,4]  R325      1.1842245608568192e-01
    z[1,0,4]  R326      -3.3896487206220627e-02
    z[1,0,4]  R327      4.2852178215980530e-01
    z[1,0,4]  R328      -1.8425248563289642e-01
    z[1,0,4]  R329      0.0907006487250328
    z[1,0,4]  R330      1.2825265526771545e-01
    z[1,0,4]  R331      3.4871110320091248e-01
    z[1,0,4]  R332      4.1849788278341293e-02
    z[1,0,4]  R333      2.3414996266365051e-01
    z[1,0,4]  R334      -2.6232752203941345e-01
    z[1,0,4]  R335      1.7692150548100471e-02
    z[1,0,4]  R336      -4.1604474186897278e-01
    z[1,0,4]  R337      2.2725290060043335e-01
    z[1,0,4]  R338      -2.0647144317626953e-01
    z[1,0,4]  R339      -5.9597671031951904e-02
    z[1,0,4]  R340      -1.4784540235996246e-01
    z[1,0,4]  R341      1.7358088493347168e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R218      -1
    z[1,0,5]  R219      1
    z[1,0,5]  R222      3.2446511089801788e-02
    z[1,0,5]  R223      -6.5567381680011749e-02
    z[1,0,5]  R224      -0.365255743265152
    z[1,0,5]  R225      -3.6753949522972107e-01
    z[1,0,5]  R226      -2.3557227849960327e-01
    z[1,0,5]  R227      -0.622138261795044
    z[1,0,5]  R228      -3.6611225455999374e-02
    z[1,0,5]  R229      -5.2739516831934452e-03
    z[1,0,5]  R230      -2.3253858089447021e-01
    z[1,0,5]  R231      -2.0286414027214050e-01
    z[1,0,5]  R232      -1.3849419355392456e-01
    z[1,0,5]  R233      5.6229633092880249e-01
    z[1,0,5]  R234      3.6926373839378357e-01
    z[1,0,5]  R235      4.5246917009353638e-01
    z[1,0,5]  R236      -5.0347644090652466e-01
    z[1,0,5]  R237      -3.1183698773384094e-01
    z[1,0,5]  R238      -7.9829913377761841e-01
    z[1,0,5]  R239      -2.9537272453308105e-01
    z[1,0,5]  R240      -2.8188723325729370e-01
    z[1,0,5]  R241      -4.9727156758308411e-01
    z[1,0,5]  R242      -3.7695422768592834e-01
    z[1,0,5]  R243      -4.3837973475456238e-01
    z[1,0,5]  R244      3.8149955216795206e-03
    z[1,0,5]  R245      -6.0314124822616577e-01
    z[1,0,5]  R246      -7.2073573246598244e-03
    z[1,0,5]  R247      4.4679322838783264e-01
    z[1,0,5]  R248      3.0278950929641724e-01
    z[1,0,5]  R249      2.2949904203414917e-02
    z[1,0,5]  R250      -2.5269734859466553e-01
    z[1,0,5]  R251      6.4644269645214081e-02
    z[1,0,5]  R252      -2.2468364238739014e-01
    z[1,0,5]  R253      -6.4025238156318665e-02
    z[1,0,5]  R254      1.6272965073585510e-01
    z[1,0,5]  R255      6.2386733293533325e-01
    z[1,0,5]  R256      1.6510689258575439e-01
    z[1,0,5]  R257      4.6994745731353760e-01
    z[1,0,5]  R258      2.7037739753723145e-01
    z[1,0,5]  R259      2.1190980076789856e-01
    z[1,0,5]  R260      2.1083962917327881e-01
    z[1,0,5]  R261      4.1137434542179108e-02
    z[1,0,5]  R262      -1.3605177402496338e-01
    z[1,0,5]  R263      2.8889194130897522e-01
    z[1,0,5]  R264      -1.4131484925746918e-01
    z[1,0,5]  R265      -1.2616080045700073e-01
    z[1,0,5]  R266      -2.4881792068481445e-01
    z[1,0,5]  R267      3.5429760813713074e-01
    z[1,0,5]  R268      2.5861939787864685e-01
    z[1,0,5]  R269      4.7179350256919861e-01
    z[1,0,5]  R270      -2.3139877617359161e-01
    z[1,0,5]  R271      -9.0957731008529663e-02
    z[1,0,5]  R272      -2.6501569151878357e-01
    z[1,0,5]  R273      1.3838236033916473e-01
    z[1,0,5]  R274      -1.9547903910279274e-02
    z[1,0,5]  R275      7.4831224977970123e-02
    z[1,0,5]  R276      -2.5719344615936279e-01
    z[1,0,5]  R277      -2.8230378031730652e-01
    z[1,0,5]  R278      5.3210198879241943e-01
    z[1,0,5]  R279      -0.801838755607605
    z[1,0,5]  R280      1.8001425266265869e-01
    z[1,0,5]  R281      3.5701093077659607e-01
    z[1,0,5]  R282      -1.5142035484313965e-01
    z[1,0,5]  R283      -1.2355160713195801e-01
    z[1,0,5]  R284      2.4428399279713631e-02
    z[1,0,5]  R285      -4.5424187183380127e-01
    z[1,0,5]  R286      -2.0846258103847504e-01
    z[1,0,5]  R287      -7.1001998148858547e-03
    z[1,0,5]  R288      -6.4996105432510376e-01
    z[1,0,5]  R289      -7.5318956375122070e-01
    z[1,0,5]  R290      4.7404772043228149e-01
    z[1,0,5]  R291      -4.9066326022148132e-01
    z[1,0,5]  R292      -1.1694166809320450e-01
    z[1,0,5]  R293      -0.314789742231369
    z[1,0,5]  R294      -6.6570803523063660e-02
    z[1,0,5]  R295      2.5973695516586304e-01
    z[1,0,5]  R296      5.7863587141036987e-01
    z[1,0,5]  R297      6.0070103406906128e-01
    z[1,0,5]  R298      -5.5635792016983032e-01
    z[1,0,5]  R299      -5.2710570394992828e-02
    z[1,0,5]  R300      8.5005831718444824e-01
    z[1,0,5]  R301      8.9964523911476135e-02
    z[1,0,5]  R302      -4.0228480100631714e-01
    z[1,0,5]  R303      -4.9198146909475327e-02
    z[1,0,5]  R304      0.0792975053191185
    z[1,0,5]  R305      3.5304924845695496e-01
    z[1,0,5]  R306      -6.5776187181472778e-01
    z[1,0,5]  R307      4.4054705649614334e-02
    z[1,0,5]  R308      2.4234344065189362e-01
    z[1,0,5]  R309      1.3407555222511292e-01
    z[1,0,5]  R310      -7.7068924903869629e-02
    z[1,0,5]  R311      -3.0042329430580139e-01
    z[1,0,5]  R312      4.6157476305961609e-01
    z[1,0,5]  R313      1.4561282098293304e-01
    z[1,0,5]  R314      2.6443246006965637e-01
    z[1,0,5]  R315      1.5825580060482025e-01
    z[1,0,5]  R316      3.4886786341667175e-01
    z[1,0,5]  R317      3.4347385168075562e-01
    z[1,0,5]  R318      -1.1962272226810455e-01
    z[1,0,5]  R319      2.8796166181564331e-01
    z[1,0,5]  R320      2.3559895157814026e-01
    z[1,0,5]  R321      0.419750839471817
    z[1,0,5]  R322      -1.1206749081611633e-01
    z[1,0,5]  R323      -4.7659579664468765e-02
    z[1,0,5]  R324      -3.0286622047424316e-01
    z[1,0,5]  R325      0.0425645150244236
    z[1,0,5]  R326      1.2710003554821014e-01
    z[1,0,5]  R327      -4.5915731787681580e-01
    z[1,0,5]  R328      3.4163451194763184e-01
    z[1,0,5]  R329      -7.2502300143241882e-02
    z[1,0,5]  R330      -2.2156614065170288e-01
    z[1,0,5]  R331      -1.5522105991840363e-01
    z[1,0,5]  R332      9.7653217613697052e-02
    z[1,0,5]  R333      -3.3456695079803467e-01
    z[1,0,5]  R334      2.8733128309249878e-01
    z[1,0,5]  R335      -0.0755414143204689
    z[1,0,5]  R336      -2.2821240127086639e-01
    z[1,0,5]  R337      1.7036728560924530e-02
    z[1,0,5]  R338      3.3079183101654053e-01
    z[1,0,5]  R339      2.7705633640289307e-01
    z[1,0,5]  R340      -5.7150825858116150e-02
    z[1,0,5]  R341      0.0494406558573246
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R220      -1
    z[1,0,6]  R221      1
    z[1,0,6]  R222      1.3085016608238220e-01
    z[1,0,6]  R223      1.1600548774003983e-01
    z[1,0,6]  R224      4.2506250739097595e-01
    z[1,0,6]  R225      2.4431201815605164e-01
    z[1,0,6]  R226      -1.4500702917575836e-01
    z[1,0,6]  R227      2.1159036457538605e-01
    z[1,0,6]  R228      3.5938540101051331e-01
    z[1,0,6]  R229      -4.6782839298248291e-01
    z[1,0,6]  R230      -1.0615862160921097e-01
    z[1,0,6]  R231      -1.4555260539054871e-01
    z[1,0,6]  R232      2.3571690917015076e-01
    z[1,0,6]  R233      1.0621951520442963e-01
    z[1,0,6]  R234      3.8641107082366943e-01
    z[1,0,6]  R235      -3.6785754561424255e-01
    z[1,0,6]  R236      2.0828416571021080e-02
    z[1,0,6]  R237      -1.2216480448842049e-02
    z[1,0,6]  R238      1.1993527412414551e-02
    z[1,0,6]  R239      8.2460641860961914e-02
    z[1,0,6]  R240      2.1416340768337250e-01
    z[1,0,6]  R241      -1.6538253426551819e-01
    z[1,0,6]  R242      -7.3446303606033325e-02
    z[1,0,6]  R243      -4.2032524943351746e-01
    z[1,0,6]  R244      2.7940708398818970e-01
    z[1,0,6]  R245      -1.8813130259513855e-01
    z[1,0,6]  R246      -2.2651143372058868e-01
    z[1,0,6]  R247      -1.8179714679718018e-01
    z[1,0,6]  R248      1.5003718435764313e-01
    z[1,0,6]  R249      -2.5128149986267090e-01
    z[1,0,6]  R250      3.7031254172325134e-01
    z[1,0,6]  R251      -2.5416231155395508e-01
    z[1,0,6]  R252      -3.8818377256393433e-01
    z[1,0,6]  R253      -1.3745276629924774e-01
    z[1,0,6]  R254      -1.3179273903369904e-01
    z[1,0,6]  R255      5.0018224865198135e-02
    z[1,0,6]  R256      1.4868189394474030e-01
    z[1,0,6]  R257      3.9425730705261230e-01
    z[1,0,6]  R258      -2.5615498423576355e-01
    z[1,0,6]  R259      3.9963837713003159e-02
    z[1,0,6]  R260      1.1153426021337509e-01
    z[1,0,6]  R261      1.6635512933135033e-02
    z[1,0,6]  R262      2.2376313805580139e-01
    z[1,0,6]  R263      1.2190598063170910e-02
    z[1,0,6]  R264      -2.3938070237636566e-01
    z[1,0,6]  R265      1.4452320337295532e-01
    z[1,0,6]  R266      4.2092159390449524e-01
    z[1,0,6]  R267      -4.5116588473320007e-02
    z[1,0,6]  R268      2.2884733974933624e-01
    z[1,0,6]  R269      2.4053448438644409e-01
    z[1,0,6]  R270      3.4515008330345154e-01
    z[1,0,6]  R271      -1.0589775443077087e-01
    z[1,0,6]  R272      -1.2426482141017914e-01
    z[1,0,6]  R273      -4.4793472625315189e-03
    z[1,0,6]  R274      -2.5481733679771423e-01
    z[1,0,6]  R275      -7.5411156285554171e-04
    z[1,0,6]  R276      -2.5086278095841408e-02
    z[1,0,6]  R277      2.8081163763999939e-01
    z[1,0,6]  R278      -6.4469978213310242e-02
    z[1,0,6]  R279      -1.5975619852542877e-01
    z[1,0,6]  R280      1.0130092501640320e-02
    z[1,0,6]  R281      1.9859719276428223e-01
    z[1,0,6]  R282      -1.6831737756729126e-01
    z[1,0,6]  R283      2.3686951398849487e-01
    z[1,0,6]  R284      -1.7415709793567657e-01
    z[1,0,6]  R285      -3.4028398990631104e-01
    z[1,0,6]  R286      1.3159666955471039e-01
    z[1,0,6]  R287      -2.2998319566249847e-01
    z[1,0,6]  R288      1.2799315154552460e-01
    z[1,0,6]  R289      -6.8501620553433895e-03
    z[1,0,6]  R290      -1.3989374041557312e-01
    z[1,0,6]  R291      -0.0764738917350769
    z[1,0,6]  R292      2.7800747752189636e-01
    z[1,0,6]  R293      8.0497294664382935e-02
    z[1,0,6]  R294      1.8978126347064972e-01
    z[1,0,6]  R295      3.0881896615028381e-01
    z[1,0,6]  R296      -1.2726396322250366e-01
    z[1,0,6]  R297      6.1962187290191650e-02
    z[1,0,6]  R298      -2.3533812165260315e-01
    z[1,0,6]  R299      -4.7985520213842392e-02
    z[1,0,6]  R300      1.4164811372756958e-01
    z[1,0,6]  R301      2.2546948492527008e-01
    z[1,0,6]  R302      -2.1964305639266968e-01
    z[1,0,6]  R303      0.368772953748703
    z[1,0,6]  R304      -0.0438428670167923
    z[1,0,6]  R305      4.2500838637351990e-02
    z[1,0,6]  R306      -6.3074447214603424e-02
    z[1,0,6]  R307      4.2139852046966553e-01
    z[1,0,6]  R308      1.4028424024581909e-01
    z[1,0,6]  R309      -5.8636319637298584e-01
    z[1,0,6]  R310      -1.1057946830987930e-01
    z[1,0,6]  R311      1.4959900081157684e-01
    z[1,0,6]  R312      5.1269207149744034e-02
    z[1,0,6]  R313      0.701459527015686
    z[1,0,6]  R314      -1.1906879395246506e-01
    z[1,0,6]  R315      2.4482533335685730e-01
    z[1,0,6]  R316      3.3203959465026855e-01
    z[1,0,6]  R317      -5.5762499570846558e-01
    z[1,0,6]  R318      4.2719867825508118e-01
    z[1,0,6]  R319      1.7231778800487518e-01
    z[1,0,6]  R320      -1.5376813709735870e-01
    z[1,0,6]  R321      2.5358861684799194e-01
    z[1,0,6]  R322      -6.7570067942142487e-02
    z[1,0,6]  R323      3.3896601200103760e-01
    z[1,0,6]  R324      -1.9608934223651886e-01
    z[1,0,6]  R325      -2.2801077365875244e-01
    z[1,0,6]  R326      -7.0265331305563450e-03
    z[1,0,6]  R327      2.9326745867729187e-01
    z[1,0,6]  R328      2.9624024033546448e-01
    z[1,0,6]  R329      -1.6035377979278564e-01
    z[1,0,6]  R330      -2.5755795836448669e-01
    z[1,0,6]  R331      4.0074729919433594e-01
    z[1,0,6]  R332      -1.5073859691619873e-01
    z[1,0,6]  R333      6.0538213700056076e-02
    z[1,0,6]  R334      -2.0313425362110138e-01
    z[1,0,6]  R335      1.5686756372451782e-01
    z[1,0,6]  R336      -3.8568595051765442e-01
    z[1,0,6]  R337      1.4490982890129089e-01
    z[1,0,6]  R338      -6.5950877964496613e-02
    z[1,0,6]  R339      -0.0956641435623169
    z[1,0,6]  R340      1.3431945443153381e-01
    z[1,0,6]  R341      2.1557042002677917e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R342      -1
    z[0,4,0]  R343      1
    z[0,4,0]  R356      -1.6187654435634613e-01
    z[0,4,0]  R357      -3.6669820547103882e-02
    z[0,4,0]  R358      -6.5070308744907379e-02
    z[0,4,0]  R359      1.7870430648326874e-01
    z[0,4,0]  R360      1.3694921135902405e-01
    z[0,4,0]  R361      2.3822438716888428e-01
    z[0,4,0]  R362      5.6398135423660278e-01
    z[0,4,0]  R363      3.0818325281143188e-01
    z[0,4,0]  R364      3.5258715506643057e-03
    z[0,4,0]  R365      1.5639305114746094e-01
    z[0,4,0]  R366      -3.8188499212265015e-01
    z[0,4,0]  R367      -4.6533294022083282e-02
    z[0,4,0]  R368      1.2883096933364868e-01
    z[0,4,0]  R369      -9.1774207353591919e-01
    z[0,4,0]  R370      3.3866548538208008e-01
    z[0,4,0]  R371      -8.9019075036048889e-02
    z[0,4,0]  R372      -3.7917357683181763e-01
    z[0,4,0]  R373      -3.8839015364646912e-01
    z[0,4,0]  R374      -5.3715944290161133e-01
    z[0,4,0]  R375      -1.0944569483399391e-02
    z[0,4,0]  R376      1.0832799226045609e-01
    z[0,4,0]  R377      4.0233525633811951e-01
    z[0,4,0]  R378      -4.0792047977447510e-01
    z[0,4,0]  R379      -4.5169967412948608e-01
    z[0,4,0]  R380      -3.2847154140472412e-01
    z[0,4,0]  R381      -2.6780608296394348e-01
    z[0,4,0]  R382      -2.0311391353607178e-01
    z[0,4,0]  R383      5.9570875018835068e-02
    z[0,4,0]  R384      -3.3729523420333862e-02
    z[0,4,0]  R385      -2.7376219630241394e-01
    z[0,4,0]  R386      -0.838451623916626
    z[0,4,0]  R387      1.3518887758255005e-01
    z[0,4,0]  R388      -3.1528422236442566e-01
    z[0,4,0]  R389      0.504865825176239
    z[0,4,0]  R390      1.3343152403831482e-01
    z[0,4,0]  R391      -3.4083083271980286e-01
    z[0,4,0]  R392      1.1983264237642288e-01
    z[0,4,0]  R393      -2.2848868370056152e-01
    z[0,4,0]  R394      5.3196984529495239e-01
    z[0,4,0]  R395      -5.1326394081115723e-01
    z[0,4,0]  R396      -3.3462586998939514e-01
    z[0,4,0]  R397      -1.8386751413345337e-01
    z[0,4,0]  R398      -3.9521700143814087e-01
    z[0,4,0]  R399      -2.3452313244342804e-01
    z[0,4,0]  R400      -2.2922654449939728e-01
    z[0,4,0]  R401      -1.8005660176277161e-01
    z[0,4,0]  R402      -8.4693320095539093e-02
    z[0,4,0]  R403      1.8776130676269531e-01
    z[0,4,0]  R404      4.2758950591087341e-01
    z[0,4,0]  R405      -4.0578305721282959e-01
    z[0,4,0]  R406      -4.7967612743377686e-01
    z[0,4,0]  R407      -4.0851479768753052e-01
    z[0,4,0]  R408      -5.3752940893173218e-01
    z[0,4,0]  R409      5.3640712052583694e-02
    z[0,4,0]  R410      -2.6883631944656372e-01
    z[0,4,0]  R411      -5.7874453067779541e-01
    z[0,4,0]  R412      1.5037380158901215e-01
    z[0,4,0]  R413      -9.9909491837024689e-02
    z[0,4,0]  R414      -4.3336942791938782e-01
    z[0,4,0]  R415      -1.9610394537448883e-01
    z[0,4,0]  R416      -3.5530373454093933e-02
    z[0,4,0]  R417      -1.0527639091014862e-01
    z[0,4,0]  R418      8.7870702147483826e-02
    z[0,4,0]  R419      -7.0698693394660950e-02
    z[0,4,0]  R420      2.8746232390403748e-01
    z[0,4,0]  R421      2.2877755761146545e-01
    z[0,4,0]  R422      2.9575052857398987e-01
    z[0,4,0]  R423      1.5770190954208374e-01
    z[0,4,0]  R424      1.7726863920688629e-01
    z[0,4,0]  R425      -3.2168358564376831e-02
    z[0,4,0]  R426      0.100483737885952
    z[0,4,0]  R427      0.355254590511322
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R344      -1
    z[0,4,1]  R345      1
    z[0,4,1]  R356      -7.8761085867881775e-02
    z[0,4,1]  R357      -2.9952749609947205e-01
    z[0,4,1]  R358      -3.9784133434295654e-01
    z[0,4,1]  R359      -1.2140488624572754e-01
    z[0,4,1]  R360      -7.0837664604187012e-01
    z[0,4,1]  R361      0.528520941734314
    z[0,4,1]  R362      5.2718675136566162e-01
    z[0,4,1]  R363      4.5138993859291077e-01
    z[0,4,1]  R364      9.3922424316406250e-01
    z[0,4,1]  R365      -0.400981068611145
    z[0,4,1]  R366      -7.0057755708694458e-01
    z[0,4,1]  R367      -4.9933272600173950e-01
    z[0,4,1]  R368      -5.5525845289230347e-01
    z[0,4,1]  R369      2.0030984282493591e-01
    z[0,4,1]  R370      -5.9063273668289185e-01
    z[0,4,1]  R371      -5.9684383869171143e-01
    z[0,4,1]  R372      -3.4544280171394348e-01
    z[0,4,1]  R373      6.2092536687850952e-01
    z[0,4,1]  R374      4.1224548220634460e-01
    z[0,4,1]  R375      6.7911767959594727e-01
    z[0,4,1]  R376      8.9026141166687012e-01
    z[0,4,1]  R377      -5.8368378877639771e-01
    z[0,4,1]  R378      -0.6959268450737
    z[0,4,1]  R379      -7.2642713785171509e-01
    z[0,4,1]  R380      -0.923673152923584
    z[0,4,1]  R381      -0.658703088760376
    z[0,4,1]  R382      6.7406189441680908e-01
    z[0,4,1]  R383      -4.1646924614906311e-01
    z[0,4,1]  R384      -5.3340089321136475e-01
    z[0,4,1]  R385      -5.9226626157760620e-01
    z[0,4,1]  R386      -3.8199466466903687e-01
    z[0,4,1]  R387      -8.0890589952468872e-01
    z[0,4,1]  R388      -6.1422210931777954e-01
    z[0,4,1]  R389      -6.5959709882736206e-01
    z[0,4,1]  R390      -6.6213244199752808e-01
    z[0,4,1]  R391      -5.8613014221191406e-01
    z[0,4,1]  R392      -8.6710357666015625e-01
    z[0,4,1]  R393      -7.5010299682617188e-01
    z[0,4,1]  R394      -8.1494438648223877e-01
    z[0,4,1]  R395      6.7133855819702148e-01
    z[0,4,1]  R396      3.8000056147575378e-01
    z[0,4,1]  R397      -1.9344460964202881e-01
    z[0,4,1]  R398      -5.0770647823810577e-02
    z[0,4,1]  R399      -1.6699281334877014e-01
    z[0,4,1]  R400      -3.1540206074714661e-01
    z[0,4,1]  R401      -2.5305259227752686e-01
    z[0,4,1]  R402      4.4007140398025513e-01
    z[0,4,1]  R403      -1.3627345860004425e-01
    z[0,4,1]  R404      -6.7598110437393188e-01
    z[0,4,1]  R405      4.9739986658096313e-01
    z[0,4,1]  R406      -5.7361096143722534e-01
    z[0,4,1]  R407      -3.8349729776382446e-01
    z[0,4,1]  R408      -4.3888527154922485e-01
    z[0,4,1]  R409      -0.254909485578537
    z[0,4,1]  R410      -2.1825772523880005e-01
    z[0,4,1]  R411      -0.502673864364624
    z[0,4,1]  R412      -4.8204681277275085e-01
    z[0,4,1]  R413      -4.0451011061668396e-01
    z[0,4,1]  R414      -3.0568674206733704e-01
    z[0,4,1]  R415      -7.8370010852813721e-01
    z[0,4,1]  R416      -6.6754847764968872e-01
    z[0,4,1]  R417      -6.5499776601791382e-01
    z[0,4,1]  R418      -6.1614960432052612e-01
    z[0,4,1]  R419      -0.886188268661499
    z[0,4,1]  R420      -7.0449334383010864e-01
    z[0,4,1]  R421      -8.5056900978088379e-01
    z[0,4,1]  R422      -7.7175575494766235e-01
    z[0,4,1]  R423      -7.2972613573074341e-01
    z[0,4,1]  R424      -5.1401132345199585e-01
    z[0,4,1]  R425      4.5769292116165161e-01
    z[0,4,1]  R426      -4.6682092547416687e-01
    z[0,4,1]  R427      4.2010107636451721e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R346      -1
    z[0,4,2]  R347      1
    z[0,4,2]  R356      -3.6971929669380188e-01
    z[0,4,2]  R357      -1.4951153099536896e-01
    z[0,4,2]  R358      -5.9516811370849609e-01
    z[0,4,2]  R359      -1.1265303939580917e-01
    z[0,4,2]  R360      -4.7889359295368195e-02
    z[0,4,2]  R361      -6.6632813215255737e-01
    z[0,4,2]  R362      -5.1571035385131836e-01
    z[0,4,2]  R363      -5.1994717121124268e-01
    z[0,4,2]  R364      -3.0188050866127014e-01
    z[0,4,2]  R365      2.6512312889099121e-01
    z[0,4,2]  R366      1.0790812969207764e-01
    z[0,4,2]  R367      1.8355131149291992e-01
    z[0,4,2]  R368      1.8166385591030121e-01
    z[0,4,2]  R369      4.2296975851058960e-02
    z[0,4,2]  R370      -2.4945567548274994e-01
    z[0,4,2]  R371      3.7572573870420456e-02
    z[0,4,2]  R372      -4.1270256042480469e-01
    z[0,4,2]  R373      5.4423063993453979e-01
    z[0,4,2]  R374      6.5377593040466309e-01
    z[0,4,2]  R375      4.7492194175720215e-01
    z[0,4,2]  R376      2.7741983532905579e-01
    z[0,4,2]  R377      -1.7960971593856812e-01
    z[0,4,2]  R378      -1.1927965283393860e-01
    z[0,4,2]  R379      -3.2968902587890625e-01
    z[0,4,2]  R380      1.1441857367753983e-01
    z[0,4,2]  R381      -8.5632979869842529e-02
    z[0,4,2]  R382      2.1599149703979492e-01
    z[0,4,2]  R383      1.5880663692951202e-01
    z[0,4,2]  R384      3.3363479375839233e-01
    z[0,4,2]  R385      -2.5188761949539185e-01
    z[0,4,2]  R386      1.3133817911148071e-01
    z[0,4,2]  R387      5.8052893728017807e-03
    z[0,4,2]  R388      3.3413541316986084e-01
    z[0,4,2]  R389      8.8722974061965942e-02
    z[0,4,2]  R390      4.6535611152648926e-02
    z[0,4,2]  R391      -2.3692335188388824e-01
    z[0,4,2]  R392      -1.0424795560538769e-02
    z[0,4,2]  R393      -7.4031185358762741e-03
    z[0,4,2]  R394      5.6204706430435181e-02
    z[0,4,2]  R395      -0.398944228887558
    z[0,4,2]  R396      -2.3803240060806274e-01
    z[0,4,2]  R397      -0.604768693447113
    z[0,4,2]  R398      2.7401563525199890e-01
    z[0,4,2]  R399      -5.3405463695526123e-01
    z[0,4,2]  R400      -4.3609780073165894e-01
    z[0,4,2]  R401      -0.746088445186615
    z[0,4,2]  R402      -7.9301851987838745e-01
    z[0,4,2]  R403      -5.0941503047943115e-01
    z[0,4,2]  R404      3.0989333987236023e-01
    z[0,4,2]  R405      4.1016179323196411e-01
    z[0,4,2]  R406      2.2047109901905060e-01
    z[0,4,2]  R407      1.9793987274169922e-01
    z[0,4,2]  R408      2.1866784989833832e-01
    z[0,4,2]  R409      -1.5877494215965271e-01
    z[0,4,2]  R410      -6.7958123981952667e-02
    z[0,4,2]  R411      4.6555814146995544e-01
    z[0,4,2]  R412      4.3209385871887207e-01
    z[0,4,2]  R413      5.6076145172119141e-01
    z[0,4,2]  R414      2.6527991890907288e-01
    z[0,4,2]  R415      1.3881656527519226e-01
    z[0,4,2]  R416      1.2538301944732666e-01
    z[0,4,2]  R417      -1.1175126768648624e-02
    z[0,4,2]  R418      -3.6341828107833862e-01
    z[0,4,2]  R419      -1.0333603620529175e-01
    z[0,4,2]  R420      8.0590806901454926e-03
    z[0,4,2]  R421      1.1250586062669754e-01
    z[0,4,2]  R422      3.1465390324592590e-01
    z[0,4,2]  R423      1.7359924316406250e-01
    z[0,4,2]  R424      -4.0520984679460526e-02
    z[0,4,2]  R425      3.7315767258405685e-02
    z[0,4,2]  R426      6.2014883756637573e-01
    z[0,4,2]  R427      6.1589145660400391e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R348      -1
    z[0,4,3]  R349      1
    z[0,4,3]  R356      7.6794660091400146e-01
    z[0,4,3]  R357      8.6472308635711670e-01
    z[0,4,3]  R358      6.8713134527206421e-01
    z[0,4,3]  R359      8.3261716365814209e-01
    z[0,4,3]  R360      -8.1853784620761871e-02
    z[0,4,3]  R361      1.8095223605632782e-01
    z[0,4,3]  R362      1.5081661939620972e-01
    z[0,4,3]  R363      1.3063374161720276e-01
    z[0,4,3]  R364      -5.1535878330469131e-02
    z[0,4,3]  R365      -1.6649590106680989e-03
    z[0,4,3]  R366      -3.1473204493522644e-01
    z[0,4,3]  R367      -4.4716751575469971e-01
    z[0,4,3]  R368      -4.9315184354782104e-01
    z[0,4,3]  R369      -0.00214373623020947
    z[0,4,3]  R370      -4.7881555557250977e-01
    z[0,4,3]  R371      -3.6441421508789062e-01
    z[0,4,3]  R372      -0.595511257648468
    z[0,4,3]  R373      1.8446531891822815e-01
    z[0,4,3]  R374      1.0180281102657318e-01
    z[0,4,3]  R375      4.6506009995937347e-02
    z[0,4,3]  R376      3.1403493881225586e-01
    z[0,4,3]  R377      -5.7860243320465088e-01
    z[0,4,3]  R378      -1.7366696894168854e-01
    z[0,4,3]  R379      -3.0290535092353821e-01
    z[0,4,3]  R380      9.2141412198543549e-02
    z[0,4,3]  R381      -8.1208914518356323e-02
    z[0,4,3]  R382      0.468307226896286
    z[0,4,3]  R383      -8.7096989154815674e-01
    z[0,4,3]  R384      -6.8640893697738647e-01
    z[0,4,3]  R385      -4.5225679874420166e-01
    z[0,4,3]  R386      3.1594225764274597e-01
    z[0,4,3]  R387      -3.9615079760551453e-01
    z[0,4,3]  R388      4.6801942586898804e-01
    z[0,4,3]  R389      -0.521098256111145
    z[0,4,3]  R390      -4.0949147939682007e-01
    z[0,4,3]  R391      -6.4126449823379517e-01
    z[0,4,3]  R392      -2.7795603871345520e-01
    z[0,4,3]  R393      -5.4370927810668945e-01
    z[0,4,3]  R394      8.0922648310661316e-02
    z[0,4,3]  R395      2.1831846237182617e-01
    z[0,4,3]  R396      6.0357111692428589e-01
    z[0,4,3]  R397      6.0565865039825439e-01
    z[0,4,3]  R398      5.6753265857696533e-01
    z[0,4,3]  R399      3.5742005705833435e-01
    z[0,4,3]  R400      6.9856691360473633e-01
    z[0,4,3]  R401      -2.1257533226162195e-03
    z[0,4,3]  R402      -1.0303667932748795e-01
    z[0,4,3]  R403      4.2567637562751770e-01
    z[0,4,3]  R404      -2.2696793079376221e-02
    z[0,4,3]  R405      -1.1700502038002014e-01
    z[0,4,3]  R406      -3.2574126124382019e-01
    z[0,4,3]  R407      -6.5682113170623779e-01
    z[0,4,3]  R408      -4.3825656175613403e-01
    z[0,4,3]  R409      -9.3386447429656982e-01
    z[0,4,3]  R410      -8.6636233329772949e-01
    z[0,4,3]  R411      -1.7136411368846893e-01
    z[0,4,3]  R412      -4.0631026029586792e-01
    z[0,4,3]  R413      -6.3331335783004761e-01
    z[0,4,3]  R414      -0.537703275680542
    z[0,4,3]  R415      -5.1382768154144287e-01
    z[0,4,3]  R416      -4.6713244915008545e-01
    z[0,4,3]  R417      -6.0241687297821045e-01
    z[0,4,3]  R418      -5.1698893308639526e-01
    z[0,4,3]  R419      5.8623269200325012e-02
    z[0,4,3]  R420      -3.8728532195091248e-01
    z[0,4,3]  R421      -1.6162315011024475e-01
    z[0,4,3]  R422      -0.192413792014122
    z[0,4,3]  R423      -3.7569716572761536e-01
    z[0,4,3]  R424      -7.0126241445541382e-01
    z[0,4,3]  R425      2.3726058006286621e-01
    z[0,4,3]  R426      4.2315709590911865e-01
    z[0,4,3]  R427      -3.2375445961952209e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R350      -1
    z[0,4,4]  R351      1
    z[0,4,4]  R356      1.7630153894424438e-01
    z[0,4,4]  R357      2.0615678280591965e-02
    z[0,4,4]  R358      -5.3882561624050140e-02
    z[0,4,4]  R359      -3.4775489568710327e-01
    z[0,4,4]  R360      1.8391543626785278e-01
    z[0,4,4]  R361      8.7523169815540314e-02
    z[0,4,4]  R362      -1.9205805659294128e-01
    z[0,4,4]  R363      -2.2817084193229675e-01
    z[0,4,4]  R364      7.6746948063373566e-02
    z[0,4,4]  R365      -7.9487639665603638e-01
    z[0,4,4]  R366      -1.9228808581829071e-01
    z[0,4,4]  R367      -4.0037795901298523e-02
    z[0,4,4]  R368      -5.6105995178222656e-01
    z[0,4,4]  R369      1.7563469707965851e-01
    z[0,4,4]  R370      -1.1404889822006226e-01
    z[0,4,4]  R371      -2.6967343688011169e-01
    z[0,4,4]  R372      -1.2300878018140793e-01
    z[0,4,4]  R373      -1.4413508772850037e-01
    z[0,4,4]  R374      -1.5676420927047729e-01
    z[0,4,4]  R375      -2.6545768976211548e-01
    z[0,4,4]  R376      -5.4726146161556244e-02
    z[0,4,4]  R377      1.1502062529325485e-01
    z[0,4,4]  R378      -0.417994886636734
    z[0,4,4]  R379      1.1842245608568192e-01
    z[0,4,4]  R380      -3.3896487206220627e-02
    z[0,4,4]  R381      4.2852178215980530e-01
    z[0,4,4]  R382      -1.8425248563289642e-01
    z[0,4,4]  R383      0.0907006487250328
    z[0,4,4]  R384      1.2825265526771545e-01
    z[0,4,4]  R385      3.4871110320091248e-01
    z[0,4,4]  R386      4.1849788278341293e-02
    z[0,4,4]  R387      2.3414996266365051e-01
    z[0,4,4]  R388      -2.6232752203941345e-01
    z[0,4,4]  R389      1.7692150548100471e-02
    z[0,4,4]  R390      -4.1604474186897278e-01
    z[0,4,4]  R391      2.2725290060043335e-01
    z[0,4,4]  R392      -2.0647144317626953e-01
    z[0,4,4]  R393      -5.9597671031951904e-02
    z[0,4,4]  R394      -1.4784540235996246e-01
    z[0,4,4]  R395      1.7358088493347168e-01
    z[0,4,4]  R396      -0.136503204703331
    z[0,4,4]  R397      -3.5392385721206665e-01
    z[0,4,4]  R398      -1.2165436148643494e-01
    z[0,4,4]  R399      2.4295400083065033e-01
    z[0,4,4]  R400      1.8292248249053955e-01
    z[0,4,4]  R401      0.0803111121058464
    z[0,4,4]  R402      -2.9412344098091125e-01
    z[0,4,4]  R403      -4.7645080089569092e-01
    z[0,4,4]  R404      -2.0362272858619690e-01
    z[0,4,4]  R405      6.3021337985992432e-01
    z[0,4,4]  R406      -3.9791175723075867e-01
    z[0,4,4]  R407      1.8500414490699768e-01
    z[0,4,4]  R408      -3.1702926754951477e-01
    z[0,4,4]  R409      -1.8385635316371918e-01
    z[0,4,4]  R410      -1.8522606790065765e-01
    z[0,4,4]  R411      3.2720991969108582e-01
    z[0,4,4]  R412      4.2710778117179871e-01
    z[0,4,4]  R413      -9.9936813116073608e-02
    z[0,4,4]  R414      4.9798506498336792e-01
    z[0,4,4]  R415      -4.6888455748558044e-02
    z[0,4,4]  R416      2.5393700599670410e-01
    z[0,4,4]  R417      4.1427984833717346e-01
    z[0,4,4]  R418      2.0255523920059204e-01
    z[0,4,4]  R419      2.9631167650222778e-01
    z[0,4,4]  R420      -8.9310482144355774e-03
    z[0,4,4]  R421      -2.7383950352668762e-01
    z[0,4,4]  R422      3.7135148048400879e-01
    z[0,4,4]  R423      1.0403730720281601e-01
    z[0,4,4]  R424      1.2953507900238037e-01
    z[0,4,4]  R425      1.4764599502086639e-01
    z[0,4,4]  R426      -1.5081711113452911e-01
    z[0,4,4]  R427      -4.2096090316772461e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R352      -1
    z[0,4,5]  R353      1
    z[0,4,5]  R356      -4.0228480100631714e-01
    z[0,4,5]  R357      -4.9198146909475327e-02
    z[0,4,5]  R358      0.0792975053191185
    z[0,4,5]  R359      3.5304924845695496e-01
    z[0,4,5]  R360      -6.5776187181472778e-01
    z[0,4,5]  R361      4.4054705649614334e-02
    z[0,4,5]  R362      2.4234344065189362e-01
    z[0,4,5]  R363      1.3407555222511292e-01
    z[0,4,5]  R364      -7.7068924903869629e-02
    z[0,4,5]  R365      -3.0042329430580139e-01
    z[0,4,5]  R366      4.6157476305961609e-01
    z[0,4,5]  R367      1.4561282098293304e-01
    z[0,4,5]  R368      2.6443246006965637e-01
    z[0,4,5]  R369      1.5825580060482025e-01
    z[0,4,5]  R370      3.4886786341667175e-01
    z[0,4,5]  R371      3.4347385168075562e-01
    z[0,4,5]  R372      -1.1962272226810455e-01
    z[0,4,5]  R373      2.8796166181564331e-01
    z[0,4,5]  R374      2.3559895157814026e-01
    z[0,4,5]  R375      0.419750839471817
    z[0,4,5]  R376      -1.1206749081611633e-01
    z[0,4,5]  R377      -4.7659579664468765e-02
    z[0,4,5]  R378      -3.0286622047424316e-01
    z[0,4,5]  R379      0.0425645150244236
    z[0,4,5]  R380      1.2710003554821014e-01
    z[0,4,5]  R381      -4.5915731787681580e-01
    z[0,4,5]  R382      3.4163451194763184e-01
    z[0,4,5]  R383      -7.2502300143241882e-02
    z[0,4,5]  R384      -2.2156614065170288e-01
    z[0,4,5]  R385      -1.5522105991840363e-01
    z[0,4,5]  R386      9.7653217613697052e-02
    z[0,4,5]  R387      -3.3456695079803467e-01
    z[0,4,5]  R388      2.8733128309249878e-01
    z[0,4,5]  R389      -0.0755414143204689
    z[0,4,5]  R390      -2.2821240127086639e-01
    z[0,4,5]  R391      1.7036728560924530e-02
    z[0,4,5]  R392      3.3079183101654053e-01
    z[0,4,5]  R393      2.7705633640289307e-01
    z[0,4,5]  R394      -5.7150825858116150e-02
    z[0,4,5]  R395      0.0494406558573246
    z[0,4,5]  R396      -5.4863101243972778e-01
    z[0,4,5]  R397      -1.5581648051738739e-01
    z[0,4,5]  R398      2.8255107998847961e-01
    z[0,4,5]  R399      0.547233521938324
    z[0,4,5]  R400      -2.1732759475708008e-01
    z[0,4,5]  R401      5.8345657587051392e-01
    z[0,4,5]  R402      2.5110721588134766e-01
    z[0,4,5]  R403      3.9948937296867371e-01
    z[0,4,5]  R404      -4.4543027877807617e-01
    z[0,4,5]  R405      3.4748513251543045e-02
    z[0,4,5]  R406      -6.3901171088218689e-02
    z[0,4,5]  R407      0.0547671839594841
    z[0,4,5]  R408      -3.2210844755172729e-01
    z[0,4,5]  R409      1.5378751559183002e-03
    z[0,4,5]  R410      -2.8517019748687744e-01
    z[0,4,5]  R411      -2.0629416406154633e-01
    z[0,4,5]  R412      3.6738982796669006e-01
    z[0,4,5]  R413      0.316733181476593
    z[0,4,5]  R414      -1.4620324969291687e-01
    z[0,4,5]  R415      -2.4634061753749847e-01
    z[0,4,5]  R416      -2.4586874246597290e-01
    z[0,4,5]  R417      1.2412620335817337e-01
    z[0,4,5]  R418      -1.6672298312187195e-01
    z[0,4,5]  R419      -1.2884598970413208e-01
    z[0,4,5]  R420      1.0271816700696945e-01
    z[0,4,5]  R421      3.1391736865043640e-01
    z[0,4,5]  R422      2.5652840733528137e-02
    z[0,4,5]  R423      2.3053072392940521e-01
    z[0,4,5]  R424      1.1248376965522766e-01
    z[0,4,5]  R425      3.8957402110099792e-01
    z[0,4,5]  R426      1.6114808619022369e-01
    z[0,4,5]  R427      1.8642856180667877e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R354      -1
    z[0,4,6]  R355      1
    z[0,4,6]  R356      -2.1964305639266968e-01
    z[0,4,6]  R357      0.368772953748703
    z[0,4,6]  R358      -0.0438428670167923
    z[0,4,6]  R359      4.2500838637351990e-02
    z[0,4,6]  R360      -6.3074447214603424e-02
    z[0,4,6]  R361      4.2139852046966553e-01
    z[0,4,6]  R362      1.4028424024581909e-01
    z[0,4,6]  R363      -5.8636319637298584e-01
    z[0,4,6]  R364      -1.1057946830987930e-01
    z[0,4,6]  R365      1.4959900081157684e-01
    z[0,4,6]  R366      5.1269207149744034e-02
    z[0,4,6]  R367      0.701459527015686
    z[0,4,6]  R368      -1.1906879395246506e-01
    z[0,4,6]  R369      2.4482533335685730e-01
    z[0,4,6]  R370      3.3203959465026855e-01
    z[0,4,6]  R371      -5.5762499570846558e-01
    z[0,4,6]  R372      4.2719867825508118e-01
    z[0,4,6]  R373      1.7231778800487518e-01
    z[0,4,6]  R374      -1.5376813709735870e-01
    z[0,4,6]  R375      2.5358861684799194e-01
    z[0,4,6]  R376      -6.7570067942142487e-02
    z[0,4,6]  R377      3.3896601200103760e-01
    z[0,4,6]  R378      -1.9608934223651886e-01
    z[0,4,6]  R379      -2.2801077365875244e-01
    z[0,4,6]  R380      -7.0265331305563450e-03
    z[0,4,6]  R381      2.9326745867729187e-01
    z[0,4,6]  R382      2.9624024033546448e-01
    z[0,4,6]  R383      -1.6035377979278564e-01
    z[0,4,6]  R384      -2.5755795836448669e-01
    z[0,4,6]  R385      4.0074729919433594e-01
    z[0,4,6]  R386      -1.5073859691619873e-01
    z[0,4,6]  R387      6.0538213700056076e-02
    z[0,4,6]  R388      -2.0313425362110138e-01
    z[0,4,6]  R389      1.5686756372451782e-01
    z[0,4,6]  R390      -3.8568595051765442e-01
    z[0,4,6]  R391      1.4490982890129089e-01
    z[0,4,6]  R392      -6.5950877964496613e-02
    z[0,4,6]  R393      -0.0956641435623169
    z[0,4,6]  R394      1.3431945443153381e-01
    z[0,4,6]  R395      2.1557042002677917e-01
    z[0,4,6]  R396      -5.5123817175626755e-02
    z[0,4,6]  R397      -2.1601729094982147e-01
    z[0,4,6]  R398      -5.9111166000366211e-01
    z[0,4,6]  R399      3.8165113329887390e-01
    z[0,4,6]  R400      2.9850912094116211e-01
    z[0,4,6]  R401      4.4890460558235645e-03
    z[0,4,6]  R402      1.0052711516618729e-01
    z[0,4,6]  R403      3.4478133916854858e-01
    z[0,4,6]  R404      -1.5426431596279144e-01
    z[0,4,6]  R405      8.7373800575733185e-02
    z[0,4,6]  R406      3.5178017616271973e-01
    z[0,4,6]  R407      4.2216736078262329e-01
    z[0,4,6]  R408      -2.7257287502288818e-01
    z[0,4,6]  R409      3.2031521201133728e-02
    z[0,4,6]  R410      9.6217900514602661e-02
    z[0,4,6]  R411      1.2899653613567352e-01
    z[0,4,6]  R412      2.7537092566490173e-01
    z[0,4,6]  R413      -2.3304922506213188e-02
    z[0,4,6]  R414      -2.9980620741844177e-01
    z[0,4,6]  R415      -3.4443486481904984e-02
    z[0,4,6]  R416      4.4073525071144104e-01
    z[0,4,6]  R417      9.9140271544456482e-02
    z[0,4,6]  R418      3.8008275628089905e-01
    z[0,4,6]  R419      -3.0191898345947266e-01
    z[0,4,6]  R420      5.1026362180709839e-01
    z[0,4,6]  R421      -1.0900168120861053e-01
    z[0,4,6]  R422      2.0575378835201263e-01
    z[0,4,6]  R423      -4.5538637042045593e-01
    z[0,4,6]  R424      -4.2605799436569214e-01
    z[0,4,6]  R425      7.4714791774749756e-01
    z[0,4,6]  R426      3.9952522516250610e-01
    z[0,4,6]  R427      -3.4733321517705917e-02
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R428      -1
    z[4,0,0]  R429      1
    z[4,0,0]  R442      -3.3462586998939514e-01
    z[4,0,0]  R443      -1.8386751413345337e-01
    z[4,0,0]  R444      -3.9521700143814087e-01
    z[4,0,0]  R445      -2.3452313244342804e-01
    z[4,0,0]  R446      -2.2922654449939728e-01
    z[4,0,0]  R447      -1.8005660176277161e-01
    z[4,0,0]  R448      -8.4693320095539093e-02
    z[4,0,0]  R449      1.8776130676269531e-01
    z[4,0,0]  R450      1.3694921135902405e-01
    z[4,0,0]  R451      4.2758950591087341e-01
    z[4,0,0]  R452      -4.0578305721282959e-01
    z[4,0,0]  R453      -4.7967612743377686e-01
    z[4,0,0]  R454      -4.0851479768753052e-01
    z[4,0,0]  R455      -5.3752940893173218e-01
    z[4,0,0]  R456      5.3640712052583694e-02
    z[4,0,0]  R457      -2.6883631944656372e-01
    z[4,0,0]  R458      -5.7874453067779541e-01
    z[4,0,0]  R459      1.5037380158901215e-01
    z[4,0,0]  R460      -9.9909491837024689e-02
    z[4,0,0]  R461      -4.3336942791938782e-01
    z[4,0,0]  R462      -1.9610394537448883e-01
    z[4,0,0]  R463      -3.5530373454093933e-02
    z[4,0,0]  R464      -1.0527639091014862e-01
    z[4,0,0]  R465      8.7870702147483826e-02
    z[4,0,0]  R466      -7.0698693394660950e-02
    z[4,0,0]  R467      2.8746232390403748e-01
    z[4,0,0]  R468      2.2877755761146545e-01
    z[4,0,0]  R469      2.9575052857398987e-01
    z[4,0,0]  R470      1.5770190954208374e-01
    z[4,0,0]  R471      1.7726863920688629e-01
    z[4,0,0]  R472      -3.2168358564376831e-02
    z[4,0,0]  R473      0.100483737885952
    z[4,0,0]  R474      0.355254590511322
    z[4,0,0]  R475      -1.6187654435634613e-01
    z[4,0,0]  R476      -3.6669820547103882e-02
    z[4,0,0]  R477      -6.5070308744907379e-02
    z[4,0,0]  R478      1.7870430648326874e-01
    z[4,0,0]  R479      2.3822438716888428e-01
    z[4,0,0]  R480      5.6398135423660278e-01
    z[4,0,0]  R481      3.0818325281143188e-01
    z[4,0,0]  R482      3.5258715506643057e-03
    z[4,0,0]  R483      1.5639305114746094e-01
    z[4,0,0]  R484      -3.8188499212265015e-01
    z[4,0,0]  R485      -4.6533294022083282e-02
    z[4,0,0]  R486      1.2883096933364868e-01
    z[4,0,0]  R487      -9.1774207353591919e-01
    z[4,0,0]  R488      3.3866548538208008e-01
    z[4,0,0]  R489      -8.9019075036048889e-02
    z[4,0,0]  R490      -3.7917357683181763e-01
    z[4,0,0]  R491      -3.8839015364646912e-01
    z[4,0,0]  R492      -5.3715944290161133e-01
    z[4,0,0]  R493      -1.0944569483399391e-02
    z[4,0,0]  R494      1.0832799226045609e-01
    z[4,0,0]  R495      4.0233525633811951e-01
    z[4,0,0]  R496      -4.0792047977447510e-01
    z[4,0,0]  R497      -4.5169967412948608e-01
    z[4,0,0]  R498      -3.2847154140472412e-01
    z[4,0,0]  R499      -2.6780608296394348e-01
    z[4,0,0]  R500      -2.0311391353607178e-01
    z[4,0,0]  R501      5.9570875018835068e-02
    z[4,0,0]  R502      -3.3729523420333862e-02
    z[4,0,0]  R503      -2.7376219630241394e-01
    z[4,0,0]  R504      -0.838451623916626
    z[4,0,0]  R505      1.3518887758255005e-01
    z[4,0,0]  R506      -3.1528422236442566e-01
    z[4,0,0]  R507      0.504865825176239
    z[4,0,0]  R508      1.3343152403831482e-01
    z[4,0,0]  R509      -3.4083083271980286e-01
    z[4,0,0]  R510      1.1983264237642288e-01
    z[4,0,0]  R511      -2.2848868370056152e-01
    z[4,0,0]  R512      5.3196984529495239e-01
    z[4,0,0]  R513      -5.1326394081115723e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R430      -1
    z[4,0,1]  R431      1
    z[4,0,1]  R442      3.8000056147575378e-01
    z[4,0,1]  R443      -1.9344460964202881e-01
    z[4,0,1]  R444      -5.0770647823810577e-02
    z[4,0,1]  R445      -1.6699281334877014e-01
    z[4,0,1]  R446      -3.1540206074714661e-01
    z[4,0,1]  R447      -2.5305259227752686e-01
    z[4,0,1]  R448      4.4007140398025513e-01
    z[4,0,1]  R449      -1.3627345860004425e-01
    z[4,0,1]  R450      -7.0837664604187012e-01
    z[4,0,1]  R451      -6.7598110437393188e-01
    z[4,0,1]  R452      4.9739986658096313e-01
    z[4,0,1]  R453      -5.7361096143722534e-01
    z[4,0,1]  R454      -3.8349729776382446e-01
    z[4,0,1]  R455      -4.3888527154922485e-01
    z[4,0,1]  R456      -0.254909485578537
    z[4,0,1]  R457      -2.1825772523880005e-01
    z[4,0,1]  R458      -0.502673864364624
    z[4,0,1]  R459      -4.8204681277275085e-01
    z[4,0,1]  R460      -4.0451011061668396e-01
    z[4,0,1]  R461      -3.0568674206733704e-01
    z[4,0,1]  R462      -7.8370010852813721e-01
    z[4,0,1]  R463      -6.6754847764968872e-01
    z[4,0,1]  R464      -6.5499776601791382e-01
    z[4,0,1]  R465      -6.1614960432052612e-01
    z[4,0,1]  R466      -0.886188268661499
    z[4,0,1]  R467      -7.0449334383010864e-01
    z[4,0,1]  R468      -8.5056900978088379e-01
    z[4,0,1]  R469      -7.7175575494766235e-01
    z[4,0,1]  R470      -7.2972613573074341e-01
    z[4,0,1]  R471      -5.1401132345199585e-01
    z[4,0,1]  R472      4.5769292116165161e-01
    z[4,0,1]  R473      -4.6682092547416687e-01
    z[4,0,1]  R474      4.2010107636451721e-01
    z[4,0,1]  R475      -7.8761085867881775e-02
    z[4,0,1]  R476      -2.9952749609947205e-01
    z[4,0,1]  R477      -3.9784133434295654e-01
    z[4,0,1]  R478      -1.2140488624572754e-01
    z[4,0,1]  R479      0.528520941734314
    z[4,0,1]  R480      5.2718675136566162e-01
    z[4,0,1]  R481      4.5138993859291077e-01
    z[4,0,1]  R482      9.3922424316406250e-01
    z[4,0,1]  R483      -0.400981068611145
    z[4,0,1]  R484      -7.0057755708694458e-01
    z[4,0,1]  R485      -4.9933272600173950e-01
    z[4,0,1]  R486      -5.5525845289230347e-01
    z[4,0,1]  R487      2.0030984282493591e-01
    z[4,0,1]  R488      -5.9063273668289185e-01
    z[4,0,1]  R489      -5.9684383869171143e-01
    z[4,0,1]  R490      -3.4544280171394348e-01
    z[4,0,1]  R491      6.2092536687850952e-01
    z[4,0,1]  R492      4.1224548220634460e-01
    z[4,0,1]  R493      6.7911767959594727e-01
    z[4,0,1]  R494      8.9026141166687012e-01
    z[4,0,1]  R495      -5.8368378877639771e-01
    z[4,0,1]  R496      -0.6959268450737
    z[4,0,1]  R497      -7.2642713785171509e-01
    z[4,0,1]  R498      -0.923673152923584
    z[4,0,1]  R499      -0.658703088760376
    z[4,0,1]  R500      6.7406189441680908e-01
    z[4,0,1]  R501      -4.1646924614906311e-01
    z[4,0,1]  R502      -5.3340089321136475e-01
    z[4,0,1]  R503      -5.9226626157760620e-01
    z[4,0,1]  R504      -3.8199466466903687e-01
    z[4,0,1]  R505      -8.0890589952468872e-01
    z[4,0,1]  R506      -6.1422210931777954e-01
    z[4,0,1]  R507      -6.5959709882736206e-01
    z[4,0,1]  R508      -6.6213244199752808e-01
    z[4,0,1]  R509      -5.8613014221191406e-01
    z[4,0,1]  R510      -8.6710357666015625e-01
    z[4,0,1]  R511      -7.5010299682617188e-01
    z[4,0,1]  R512      -8.1494438648223877e-01
    z[4,0,1]  R513      6.7133855819702148e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R432      -1
    z[4,0,2]  R433      1
    z[4,0,2]  R442      -2.3803240060806274e-01
    z[4,0,2]  R443      -0.604768693447113
    z[4,0,2]  R444      2.7401563525199890e-01
    z[4,0,2]  R445      -5.3405463695526123e-01
    z[4,0,2]  R446      -4.3609780073165894e-01
    z[4,0,2]  R447      -0.746088445186615
    z[4,0,2]  R448      -7.9301851987838745e-01
    z[4,0,2]  R449      -5.0941503047943115e-01
    z[4,0,2]  R450      -4.7889359295368195e-02
    z[4,0,2]  R451      3.0989333987236023e-01
    z[4,0,2]  R452      4.1016179323196411e-01
    z[4,0,2]  R453      2.2047109901905060e-01
    z[4,0,2]  R454      1.9793987274169922e-01
    z[4,0,2]  R455      2.1866784989833832e-01
    z[4,0,2]  R456      -1.5877494215965271e-01
    z[4,0,2]  R457      -6.7958123981952667e-02
    z[4,0,2]  R458      4.6555814146995544e-01
    z[4,0,2]  R459      4.3209385871887207e-01
    z[4,0,2]  R460      5.6076145172119141e-01
    z[4,0,2]  R461      2.6527991890907288e-01
    z[4,0,2]  R462      1.3881656527519226e-01
    z[4,0,2]  R463      1.2538301944732666e-01
    z[4,0,2]  R464      -1.1175126768648624e-02
    z[4,0,2]  R465      -3.6341828107833862e-01
    z[4,0,2]  R466      -1.0333603620529175e-01
    z[4,0,2]  R467      8.0590806901454926e-03
    z[4,0,2]  R468      1.1250586062669754e-01
    z[4,0,2]  R469      3.1465390324592590e-01
    z[4,0,2]  R470      1.7359924316406250e-01
    z[4,0,2]  R471      -4.0520984679460526e-02
    z[4,0,2]  R472      3.7315767258405685e-02
    z[4,0,2]  R473      6.2014883756637573e-01
    z[4,0,2]  R474      6.1589145660400391e-01
    z[4,0,2]  R475      -3.6971929669380188e-01
    z[4,0,2]  R476      -1.4951153099536896e-01
    z[4,0,2]  R477      -5.9516811370849609e-01
    z[4,0,2]  R478      -1.1265303939580917e-01
    z[4,0,2]  R479      -6.6632813215255737e-01
    z[4,0,2]  R480      -5.1571035385131836e-01
    z[4,0,2]  R481      -5.1994717121124268e-01
    z[4,0,2]  R482      -3.0188050866127014e-01
    z[4,0,2]  R483      2.6512312889099121e-01
    z[4,0,2]  R484      1.0790812969207764e-01
    z[4,0,2]  R485      1.8355131149291992e-01
    z[4,0,2]  R486      1.8166385591030121e-01
    z[4,0,2]  R487      4.2296975851058960e-02
    z[4,0,2]  R488      -2.4945567548274994e-01
    z[4,0,2]  R489      3.7572573870420456e-02
    z[4,0,2]  R490      -4.1270256042480469e-01
    z[4,0,2]  R491      5.4423063993453979e-01
    z[4,0,2]  R492      6.5377593040466309e-01
    z[4,0,2]  R493      4.7492194175720215e-01
    z[4,0,2]  R494      2.7741983532905579e-01
    z[4,0,2]  R495      -1.7960971593856812e-01
    z[4,0,2]  R496      -1.1927965283393860e-01
    z[4,0,2]  R497      -3.2968902587890625e-01
    z[4,0,2]  R498      1.1441857367753983e-01
    z[4,0,2]  R499      -8.5632979869842529e-02
    z[4,0,2]  R500      2.1599149703979492e-01
    z[4,0,2]  R501      1.5880663692951202e-01
    z[4,0,2]  R502      3.3363479375839233e-01
    z[4,0,2]  R503      -2.5188761949539185e-01
    z[4,0,2]  R504      1.3133817911148071e-01
    z[4,0,2]  R505      5.8052893728017807e-03
    z[4,0,2]  R506      3.3413541316986084e-01
    z[4,0,2]  R507      8.8722974061965942e-02
    z[4,0,2]  R508      4.6535611152648926e-02
    z[4,0,2]  R509      -2.3692335188388824e-01
    z[4,0,2]  R510      -1.0424795560538769e-02
    z[4,0,2]  R511      -7.4031185358762741e-03
    z[4,0,2]  R512      5.6204706430435181e-02
    z[4,0,2]  R513      -0.398944228887558
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R434      -1
    z[4,0,3]  R435      1
    z[4,0,3]  R442      6.0357111692428589e-01
    z[4,0,3]  R443      6.0565865039825439e-01
    z[4,0,3]  R444      5.6753265857696533e-01
    z[4,0,3]  R445      3.5742005705833435e-01
    z[4,0,3]  R446      6.9856691360473633e-01
    z[4,0,3]  R447      -2.1257533226162195e-03
    z[4,0,3]  R448      -1.0303667932748795e-01
    z[4,0,3]  R449      4.2567637562751770e-01
    z[4,0,3]  R450      -8.1853784620761871e-02
    z[4,0,3]  R451      -2.2696793079376221e-02
    z[4,0,3]  R452      -1.1700502038002014e-01
    z[4,0,3]  R453      -3.2574126124382019e-01
    z[4,0,3]  R454      -6.5682113170623779e-01
    z[4,0,3]  R455      -4.3825656175613403e-01
    z[4,0,3]  R456      -9.3386447429656982e-01
    z[4,0,3]  R457      -8.6636233329772949e-01
    z[4,0,3]  R458      -1.7136411368846893e-01
    z[4,0,3]  R459      -4.0631026029586792e-01
    z[4,0,3]  R460      -6.3331335783004761e-01
    z[4,0,3]  R461      -0.537703275680542
    z[4,0,3]  R462      -5.1382768154144287e-01
    z[4,0,3]  R463      -4.6713244915008545e-01
    z[4,0,3]  R464      -6.0241687297821045e-01
    z[4,0,3]  R465      -5.1698893308639526e-01
    z[4,0,3]  R466      5.8623269200325012e-02
    z[4,0,3]  R467      -3.8728532195091248e-01
    z[4,0,3]  R468      -1.6162315011024475e-01
    z[4,0,3]  R469      -0.192413792014122
    z[4,0,3]  R470      -3.7569716572761536e-01
    z[4,0,3]  R471      -7.0126241445541382e-01
    z[4,0,3]  R472      2.3726058006286621e-01
    z[4,0,3]  R473      4.2315709590911865e-01
    z[4,0,3]  R474      -3.2375445961952209e-01
    z[4,0,3]  R475      7.6794660091400146e-01
    z[4,0,3]  R476      8.6472308635711670e-01
    z[4,0,3]  R477      6.8713134527206421e-01
    z[4,0,3]  R478      8.3261716365814209e-01
    z[4,0,3]  R479      1.8095223605632782e-01
    z[4,0,3]  R480      1.5081661939620972e-01
    z[4,0,3]  R481      1.3063374161720276e-01
    z[4,0,3]  R482      -5.1535878330469131e-02
    z[4,0,3]  R483      -1.6649590106680989e-03
    z[4,0,3]  R484      -3.1473204493522644e-01
    z[4,0,3]  R485      -4.4716751575469971e-01
    z[4,0,3]  R486      -4.9315184354782104e-01
    z[4,0,3]  R487      -0.00214373623020947
    z[4,0,3]  R488      -4.7881555557250977e-01
    z[4,0,3]  R489      -3.6441421508789062e-01
    z[4,0,3]  R490      -0.595511257648468
    z[4,0,3]  R491      1.8446531891822815e-01
    z[4,0,3]  R492      1.0180281102657318e-01
    z[4,0,3]  R493      4.6506009995937347e-02
    z[4,0,3]  R494      3.1403493881225586e-01
    z[4,0,3]  R495      -5.7860243320465088e-01
    z[4,0,3]  R496      -1.7366696894168854e-01
    z[4,0,3]  R497      -3.0290535092353821e-01
    z[4,0,3]  R498      9.2141412198543549e-02
    z[4,0,3]  R499      -8.1208914518356323e-02
    z[4,0,3]  R500      0.468307226896286
    z[4,0,3]  R501      -8.7096989154815674e-01
    z[4,0,3]  R502      -6.8640893697738647e-01
    z[4,0,3]  R503      -4.5225679874420166e-01
    z[4,0,3]  R504      3.1594225764274597e-01
    z[4,0,3]  R505      -3.9615079760551453e-01
    z[4,0,3]  R506      4.6801942586898804e-01
    z[4,0,3]  R507      -0.521098256111145
    z[4,0,3]  R508      -4.0949147939682007e-01
    z[4,0,3]  R509      -6.4126449823379517e-01
    z[4,0,3]  R510      -2.7795603871345520e-01
    z[4,0,3]  R511      -5.4370927810668945e-01
    z[4,0,3]  R512      8.0922648310661316e-02
    z[4,0,3]  R513      2.1831846237182617e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R436      -1
    z[4,0,4]  R437      1
    z[4,0,4]  R442      -0.136503204703331
    z[4,0,4]  R443      -3.5392385721206665e-01
    z[4,0,4]  R444      -1.2165436148643494e-01
    z[4,0,4]  R445      2.4295400083065033e-01
    z[4,0,4]  R446      1.8292248249053955e-01
    z[4,0,4]  R447      0.0803111121058464
    z[4,0,4]  R448      -2.9412344098091125e-01
    z[4,0,4]  R449      -4.7645080089569092e-01
    z[4,0,4]  R450      1.8391543626785278e-01
    z[4,0,4]  R451      -2.0362272858619690e-01
    z[4,0,4]  R452      6.3021337985992432e-01
    z[4,0,4]  R453      -3.9791175723075867e-01
    z[4,0,4]  R454      1.8500414490699768e-01
    z[4,0,4]  R455      -3.1702926754951477e-01
    z[4,0,4]  R456      -1.8385635316371918e-01
    z[4,0,4]  R457      -1.8522606790065765e-01
    z[4,0,4]  R458      3.2720991969108582e-01
    z[4,0,4]  R459      4.2710778117179871e-01
    z[4,0,4]  R460      -9.9936813116073608e-02
    z[4,0,4]  R461      4.9798506498336792e-01
    z[4,0,4]  R462      -4.6888455748558044e-02
    z[4,0,4]  R463      2.5393700599670410e-01
    z[4,0,4]  R464      4.1427984833717346e-01
    z[4,0,4]  R465      2.0255523920059204e-01
    z[4,0,4]  R466      2.9631167650222778e-01
    z[4,0,4]  R467      -8.9310482144355774e-03
    z[4,0,4]  R468      -2.7383950352668762e-01
    z[4,0,4]  R469      3.7135148048400879e-01
    z[4,0,4]  R470      1.0403730720281601e-01
    z[4,0,4]  R471      1.2953507900238037e-01
    z[4,0,4]  R472      1.4764599502086639e-01
    z[4,0,4]  R473      -1.5081711113452911e-01
    z[4,0,4]  R474      -4.2096090316772461e-01
    z[4,0,4]  R475      1.7630153894424438e-01
    z[4,0,4]  R476      2.0615678280591965e-02
    z[4,0,4]  R477      -5.3882561624050140e-02
    z[4,0,4]  R478      -3.4775489568710327e-01
    z[4,0,4]  R479      8.7523169815540314e-02
    z[4,0,4]  R480      -1.9205805659294128e-01
    z[4,0,4]  R481      -2.2817084193229675e-01
    z[4,0,4]  R482      7.6746948063373566e-02
    z[4,0,4]  R483      -7.9487639665603638e-01
    z[4,0,4]  R484      -1.9228808581829071e-01
    z[4,0,4]  R485      -4.0037795901298523e-02
    z[4,0,4]  R486      -5.6105995178222656e-01
    z[4,0,4]  R487      1.7563469707965851e-01
    z[4,0,4]  R488      -1.1404889822006226e-01
    z[4,0,4]  R489      -2.6967343688011169e-01
    z[4,0,4]  R490      -1.2300878018140793e-01
    z[4,0,4]  R491      -1.4413508772850037e-01
    z[4,0,4]  R492      -1.5676420927047729e-01
    z[4,0,4]  R493      -2.6545768976211548e-01
    z[4,0,4]  R494      -5.4726146161556244e-02
    z[4,0,4]  R495      1.1502062529325485e-01
    z[4,0,4]  R496      -0.417994886636734
    z[4,0,4]  R497      1.1842245608568192e-01
    z[4,0,4]  R498      -3.3896487206220627e-02
    z[4,0,4]  R499      4.2852178215980530e-01
    z[4,0,4]  R500      -1.8425248563289642e-01
    z[4,0,4]  R501      0.0907006487250328
    z[4,0,4]  R502      1.2825265526771545e-01
    z[4,0,4]  R503      3.4871110320091248e-01
    z[4,0,4]  R504      4.1849788278341293e-02
    z[4,0,4]  R505      2.3414996266365051e-01
    z[4,0,4]  R506      -2.6232752203941345e-01
    z[4,0,4]  R507      1.7692150548100471e-02
    z[4,0,4]  R508      -4.1604474186897278e-01
    z[4,0,4]  R509      2.2725290060043335e-01
    z[4,0,4]  R510      -2.0647144317626953e-01
    z[4,0,4]  R511      -5.9597671031951904e-02
    z[4,0,4]  R512      -1.4784540235996246e-01
    z[4,0,4]  R513      1.7358088493347168e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R438      -1
    z[4,0,5]  R439      1
    z[4,0,5]  R442      -5.4863101243972778e-01
    z[4,0,5]  R443      -1.5581648051738739e-01
    z[4,0,5]  R444      2.8255107998847961e-01
    z[4,0,5]  R445      0.547233521938324
    z[4,0,5]  R446      -2.1732759475708008e-01
    z[4,0,5]  R447      5.8345657587051392e-01
    z[4,0,5]  R448      2.5110721588134766e-01
    z[4,0,5]  R449      3.9948937296867371e-01
    z[4,0,5]  R450      -6.5776187181472778e-01
    z[4,0,5]  R451      -4.4543027877807617e-01
    z[4,0,5]  R452      3.4748513251543045e-02
    z[4,0,5]  R453      -6.3901171088218689e-02
    z[4,0,5]  R454      0.0547671839594841
    z[4,0,5]  R455      -3.2210844755172729e-01
    z[4,0,5]  R456      1.5378751559183002e-03
    z[4,0,5]  R457      -2.8517019748687744e-01
    z[4,0,5]  R458      -2.0629416406154633e-01
    z[4,0,5]  R459      3.6738982796669006e-01
    z[4,0,5]  R460      0.316733181476593
    z[4,0,5]  R461      -1.4620324969291687e-01
    z[4,0,5]  R462      -2.4634061753749847e-01
    z[4,0,5]  R463      -2.4586874246597290e-01
    z[4,0,5]  R464      1.2412620335817337e-01
    z[4,0,5]  R465      -1.6672298312187195e-01
    z[4,0,5]  R466      -1.2884598970413208e-01
    z[4,0,5]  R467      1.0271816700696945e-01
    z[4,0,5]  R468      3.1391736865043640e-01
    z[4,0,5]  R469      2.5652840733528137e-02
    z[4,0,5]  R470      2.3053072392940521e-01
    z[4,0,5]  R471      1.1248376965522766e-01
    z[4,0,5]  R472      3.8957402110099792e-01
    z[4,0,5]  R473      1.6114808619022369e-01
    z[4,0,5]  R474      1.8642856180667877e-01
    z[4,0,5]  R475      -4.0228480100631714e-01
    z[4,0,5]  R476      -4.9198146909475327e-02
    z[4,0,5]  R477      0.0792975053191185
    z[4,0,5]  R478      3.5304924845695496e-01
    z[4,0,5]  R479      4.4054705649614334e-02
    z[4,0,5]  R480      2.4234344065189362e-01
    z[4,0,5]  R481      1.3407555222511292e-01
    z[4,0,5]  R482      -7.7068924903869629e-02
    z[4,0,5]  R483      -3.0042329430580139e-01
    z[4,0,5]  R484      4.6157476305961609e-01
    z[4,0,5]  R485      1.4561282098293304e-01
    z[4,0,5]  R486      2.6443246006965637e-01
    z[4,0,5]  R487      1.5825580060482025e-01
    z[4,0,5]  R488      3.4886786341667175e-01
    z[4,0,5]  R489      3.4347385168075562e-01
    z[4,0,5]  R490      -1.1962272226810455e-01
    z[4,0,5]  R491      2.8796166181564331e-01
    z[4,0,5]  R492      2.3559895157814026e-01
    z[4,0,5]  R493      0.419750839471817
    z[4,0,5]  R494      -1.1206749081611633e-01
    z[4,0,5]  R495      -4.7659579664468765e-02
    z[4,0,5]  R496      -3.0286622047424316e-01
    z[4,0,5]  R497      0.0425645150244236
    z[4,0,5]  R498      1.2710003554821014e-01
    z[4,0,5]  R499      -4.5915731787681580e-01
    z[4,0,5]  R500      3.4163451194763184e-01
    z[4,0,5]  R501      -7.2502300143241882e-02
    z[4,0,5]  R502      -2.2156614065170288e-01
    z[4,0,5]  R503      -1.5522105991840363e-01
    z[4,0,5]  R504      9.7653217613697052e-02
    z[4,0,5]  R505      -3.3456695079803467e-01
    z[4,0,5]  R506      2.8733128309249878e-01
    z[4,0,5]  R507      -0.0755414143204689
    z[4,0,5]  R508      -2.2821240127086639e-01
    z[4,0,5]  R509      1.7036728560924530e-02
    z[4,0,5]  R510      3.3079183101654053e-01
    z[4,0,5]  R511      2.7705633640289307e-01
    z[4,0,5]  R512      -5.7150825858116150e-02
    z[4,0,5]  R513      0.0494406558573246
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R440      -1
    z[4,0,6]  R441      1
    z[4,0,6]  R442      -5.5123817175626755e-02
    z[4,0,6]  R443      -2.1601729094982147e-01
    z[4,0,6]  R444      -5.9111166000366211e-01
    z[4,0,6]  R445      3.8165113329887390e-01
    z[4,0,6]  R446      2.9850912094116211e-01
    z[4,0,6]  R447      4.4890460558235645e-03
    z[4,0,6]  R448      1.0052711516618729e-01
    z[4,0,6]  R449      3.4478133916854858e-01
    z[4,0,6]  R450      -6.3074447214603424e-02
    z[4,0,6]  R451      -1.5426431596279144e-01
    z[4,0,6]  R452      8.7373800575733185e-02
    z[4,0,6]  R453      3.5178017616271973e-01
    z[4,0,6]  R454      4.2216736078262329e-01
    z[4,0,6]  R455      -2.7257287502288818e-01
    z[4,0,6]  R456      3.2031521201133728e-02
    z[4,0,6]  R457      9.6217900514602661e-02
    z[4,0,6]  R458      1.2899653613567352e-01
    z[4,0,6]  R459      2.7537092566490173e-01
    z[4,0,6]  R460      -2.3304922506213188e-02
    z[4,0,6]  R461      -2.9980620741844177e-01
    z[4,0,6]  R462      -3.4443486481904984e-02
    z[4,0,6]  R463      4.4073525071144104e-01
    z[4,0,6]  R464      9.9140271544456482e-02
    z[4,0,6]  R465      3.8008275628089905e-01
    z[4,0,6]  R466      -3.0191898345947266e-01
    z[4,0,6]  R467      5.1026362180709839e-01
    z[4,0,6]  R468      -1.0900168120861053e-01
    z[4,0,6]  R469      2.0575378835201263e-01
    z[4,0,6]  R470      -4.5538637042045593e-01
    z[4,0,6]  R471      -4.2605799436569214e-01
    z[4,0,6]  R472      7.4714791774749756e-01
    z[4,0,6]  R473      3.9952522516250610e-01
    z[4,0,6]  R474      -3.4733321517705917e-02
    z[4,0,6]  R475      -2.1964305639266968e-01
    z[4,0,6]  R476      0.368772953748703
    z[4,0,6]  R477      -0.0438428670167923
    z[4,0,6]  R478      4.2500838637351990e-02
    z[4,0,6]  R479      4.2139852046966553e-01
    z[4,0,6]  R480      1.4028424024581909e-01
    z[4,0,6]  R481      -5.8636319637298584e-01
    z[4,0,6]  R482      -1.1057946830987930e-01
    z[4,0,6]  R483      1.4959900081157684e-01
    z[4,0,6]  R484      5.1269207149744034e-02
    z[4,0,6]  R485      0.701459527015686
    z[4,0,6]  R486      -1.1906879395246506e-01
    z[4,0,6]  R487      2.4482533335685730e-01
    z[4,0,6]  R488      3.3203959465026855e-01
    z[4,0,6]  R489      -5.5762499570846558e-01
    z[4,0,6]  R490      4.2719867825508118e-01
    z[4,0,6]  R491      1.7231778800487518e-01
    z[4,0,6]  R492      -1.5376813709735870e-01
    z[4,0,6]  R493      2.5358861684799194e-01
    z[4,0,6]  R494      -6.7570067942142487e-02
    z[4,0,6]  R495      3.3896601200103760e-01
    z[4,0,6]  R496      -1.9608934223651886e-01
    z[4,0,6]  R497      -2.2801077365875244e-01
    z[4,0,6]  R498      -7.0265331305563450e-03
    z[4,0,6]  R499      2.9326745867729187e-01
    z[4,0,6]  R500      2.9624024033546448e-01
    z[4,0,6]  R501      -1.6035377979278564e-01
    z[4,0,6]  R502      -2.5755795836448669e-01
    z[4,0,6]  R503      4.0074729919433594e-01
    z[4,0,6]  R504      -1.5073859691619873e-01
    z[4,0,6]  R505      6.0538213700056076e-02
    z[4,0,6]  R506      -2.0313425362110138e-01
    z[4,0,6]  R507      1.5686756372451782e-01
    z[4,0,6]  R508      -3.8568595051765442e-01
    z[4,0,6]  R509      1.4490982890129089e-01
    z[4,0,6]  R510      -6.5950877964496613e-02
    z[4,0,6]  R511      -0.0956641435623169
    z[4,0,6]  R512      1.3431945443153381e-01
    z[4,0,6]  R513      2.1557042002677917e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R568      -1
    z[1,2,0]  R569      1
    z[1,2,0]  R582      -1.8504685163497925e-01
    z[1,2,0]  R583      -4.1042396426200867e-01
    z[1,2,0]  R584      -3.6015835404396057e-01
    z[1,2,0]  R585      -3.9248549938201904e-01
    z[1,2,0]  R586      -5.3533172607421875e-01
    z[1,2,0]  R587      -5.1385068893432617e-01
    z[1,2,0]  R588      -0.294125497341156
    z[1,2,0]  R589      -4.9046209454536438e-01
    z[1,2,0]  R590      -1.8783503770828247e-01
    z[1,2,0]  R591      -2.4487075209617615e-01
    z[1,2,0]  R592      -3.0964162945747375e-01
    z[1,2,0]  R593      -5.7068222761154175e-01
    z[1,2,0]  R594      -4.5240543782711029e-02
    z[1,2,0]  R595      -1.3260327279567719e-01
    z[1,2,0]  R596      5.0913608074188232e-01
    z[1,2,0]  R597      4.3723034858703613e-01
    z[1,2,0]  R598      3.8654750585556030e-01
    z[1,2,0]  R599      5.7518702745437622e-01
    z[1,2,0]  R600      5.7469648122787476e-01
    z[1,2,0]  R601      2.2413673996925354e-01
    z[1,2,0]  R602      -7.6443636417388916e-01
    z[1,2,0]  R603      -6.9400042295455933e-01
    z[1,2,0]  R604      -8.3020389080047607e-01
    z[1,2,0]  R605      -3.9931410551071167e-01
    z[1,2,0]  R606      -7.2825539112091064e-01
    z[1,2,0]  R607      -7.0837658643722534e-01
    z[1,2,0]  R608      -3.4922859072685242e-01
    z[1,2,0]  R609      1.9114144146442413e-01
    z[1,2,0]  R610      3.2021217048168182e-02
    z[1,2,0]  R611      -3.1742650270462036e-01
    z[1,2,0]  R612      -6.5962892770767212e-01
    z[1,2,0]  R613      -4.2270287871360779e-01
    z[1,2,0]  R614      -7.2531211376190186e-01
    z[1,2,0]  R615      -5.7918995618820190e-01
    z[1,2,0]  R616      -7.6002550125122070e-01
    z[1,2,0]  R617      -1.7553168535232544e-01
    z[1,2,0]  R618      -7.1153730154037476e-01
    z[1,2,0]  R619      -4.8035293817520142e-01
    z[1,2,0]  R620      -3.8778927922248840e-01
    z[1,2,0]  R621      -3.6483600735664368e-02
    z[1,2,0]  R622      -8.2963532209396362e-01
    z[1,2,0]  R623      -6.8737351894378662e-01
    z[1,2,0]  R624      -7.1367490291595459e-01
    z[1,2,0]  R625      -2.0795506238937378e-01
    z[1,2,0]  R626      -3.9442569017410278e-01
    z[1,2,0]  R627      -2.4038979411125183e-01
    z[1,2,0]  R628      3.4578088670969009e-02
    z[1,2,0]  R629      -1.9409339129924774e-01
    z[1,2,0]  R630      -1.0027784854173660e-01
    z[1,2,0]  R631      7.5281602330505848e-03
    z[1,2,0]  R632      -7.5817912817001343e-01
    z[1,2,0]  R633      -0.585847795009613
    z[1,2,0]  R634      -1.7512808740139008e-01
    z[1,2,0]  R635      5.4685866832733154e-01
    z[1,2,0]  R636      5.0207936763763428e-01
    z[1,2,0]  R637      -3.2939542084932327e-02
    z[1,2,0]  R638      -1.2607021629810333e-01
    z[1,2,0]  R639      8.6718820035457611e-02
    z[1,2,0]  R640      -3.6362364888191223e-01
    z[1,2,0]  R641      4.5727172493934631e-01
    z[1,2,0]  R642      -7.9709625244140625e-01
    z[1,2,0]  R643      1.0934278368949890e-01
    z[1,2,0]  R644      -1.5613633394241333e-01
    z[1,2,0]  R645      6.6998727619647980e-02
    z[1,2,0]  R646      -2.7986937761306763e-01
    z[1,2,0]  R647      2.3405288159847260e-01
    z[1,2,0]  R648      -1.4988117851316929e-02
    z[1,2,0]  R649      0.00427770521491766
    z[1,2,0]  R650      2.8082564473152161e-01
    z[1,2,0]  R651      4.0474772453308105e-01
    z[1,2,0]  R652      -0.840641438961029
    z[1,2,0]  R653      -5.1673197746276855e-01
    z[1,2,0]  R654      4.7091841697692871e-01
    z[1,2,0]  R655      -2.8321981430053711e-01
    z[1,2,0]  R656      1.2995104491710663e-01
    z[1,2,0]  R657      1.8130710721015930e-01
    z[1,2,0]  R658      3.1230497360229492e-01
    z[1,2,0]  R659      1.9165314733982086e-01
    z[1,2,0]  R660      1.5388001501560211e-01
    z[1,2,0]  R661      5.1341748237609863e-01
    z[1,2,0]  R662      -3.4547504782676697e-01
    z[1,2,0]  R663      1.3561316765844822e-02
    z[1,2,0]  R664      -3.6145329475402832e-01
    z[1,2,0]  R665      -4.5829087495803833e-01
    z[1,2,0]  R666      -0.684083104133606
    z[1,2,0]  R667      5.8577132225036621e-01
    z[1,2,0]  R668      4.8948177695274353e-01
    z[1,2,0]  R669      2.9152107238769531e-01
    z[1,2,0]  R670      1.1649436503648758e-01
    z[1,2,0]  R671      3.7414813041687012e-01
    z[1,2,0]  R672      -1.0246091336011887e-01
    z[1,2,0]  R673      9.4595164060592651e-02
    z[1,2,0]  R674      1.6218294203281403e-01
    z[1,2,0]  R675      -1.3031384348869324e-01
    z[1,2,0]  R676      -4.1496995836496353e-02
    z[1,2,0]  R677      1.2153500691056252e-02
    z[1,2,0]  R678      -1.2515839934349060e-01
    z[1,2,0]  R679      7.1756877005100250e-02
    z[1,2,0]  R680      -4.0827151387929916e-02
    z[1,2,0]  R681      6.3087129592895508e-01
    z[1,2,0]  R682      2.6328464969992638e-02
    z[1,2,0]  R683      6.7273631691932678e-02
    z[1,2,0]  R684      3.0740952491760254e-01
    z[1,2,0]  R685      2.2847460210323334e-01
    z[1,2,0]  R686      0.571487545967102
    z[1,2,0]  R687      3.7006980180740356e-01
    z[1,2,0]  R688      3.5615384578704834e-01
    z[1,2,0]  R689      1.8936680257320404e-01
    z[1,2,0]  R690      2.8686422109603882e-01
    z[1,2,0]  R691      4.6804994344711304e-01
    z[1,2,0]  R692      2.7180549502372742e-01
    z[1,2,0]  R693      2.5965690612792969e-01
    z[1,2,0]  R694      4.5168903470039368e-01
    z[1,2,0]  R695      4.7862139344215393e-01
    z[1,2,0]  R696      5.2210897207260132e-01
    z[1,2,0]  R697      2.0533682405948639e-01
    z[1,2,0]  R698      4.0825748443603516e-01
    z[1,2,0]  R699      2.0486554503440857e-01
    z[1,2,0]  R700      6.4479327201843262e-01
    z[1,2,0]  R701      6.4287084341049194e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R570      -1
    z[1,2,1]  R571      1
    z[1,2,1]  R582      -1.7523691058158875e-01
    z[1,2,1]  R583      -1.6719432175159454e-01
    z[1,2,1]  R584      3.8764795660972595e-01
    z[1,2,1]  R585      -6.0433227568864822e-02
    z[1,2,1]  R586      -6.9771325588226318e-01
    z[1,2,1]  R587      -2.4238368868827820e-01
    z[1,2,1]  R588      4.1101232171058655e-01
    z[1,2,1]  R589      -3.6673498153686523e-01
    z[1,2,1]  R590      5.7936519384384155e-01
    z[1,2,1]  R591      2.9406782984733582e-01
    z[1,2,1]  R592      -4.9336525797843933e-01
    z[1,2,1]  R593      2.2819752991199493e-01
    z[1,2,1]  R594      -5.3672146797180176e-01
    z[1,2,1]  R595      -8.8703013956546783e-02
    z[1,2,1]  R596      -3.6340686678886414e-01
    z[1,2,1]  R597      -7.6629793643951416e-01
    z[1,2,1]  R598      -1.9543415307998657e-01
    z[1,2,1]  R599      -5.2890110015869141e-01
    z[1,2,1]  R600      -4.1696822643280029e-01
    z[1,2,1]  R601      -4.6006512641906738e-01
    z[1,2,1]  R602      -0.0542781837284565
    z[1,2,1]  R603      2.6327449083328247e-01
    z[1,2,1]  R604      -9.6835397183895111e-02
    z[1,2,1]  R605      3.1895977258682251e-01
    z[1,2,1]  R606      -1.4942237176001072e-02
    z[1,2,1]  R607      1.4007595181465149e-01
    z[1,2,1]  R608      3.7733522057533264e-01
    z[1,2,1]  R609      2.2731362283229828e-01
    z[1,2,1]  R610      0.656013011932373
    z[1,2,1]  R611      -1.2028472125530243e-01
    z[1,2,1]  R612      -2.0583732426166534e-01
    z[1,2,1]  R613      0.0802420824766159
    z[1,2,1]  R614      0.226536363363266
    z[1,2,1]  R615      -7.4536859989166260e-02
    z[1,2,1]  R616      -7.2944097220897675e-02
    z[1,2,1]  R617      5.7489979267120361e-01
    z[1,2,1]  R618      -0.541951596736908
    z[1,2,1]  R619      -7.5490123033523560e-01
    z[1,2,1]  R620      6.7670869827270508e-01
    z[1,2,1]  R621      -6.3960880041122437e-01
    z[1,2,1]  R622      -3.2839035987854004e-01
    z[1,2,1]  R623      1.5256562270224094e-02
    z[1,2,1]  R624      -2.3919717967510223e-01
    z[1,2,1]  R625      6.7518049478530884e-01
    z[1,2,1]  R626      -6.7618393898010254e-01
    z[1,2,1]  R627      1.4976819977164268e-02
    z[1,2,1]  R628      9.9239133298397064e-02
    z[1,2,1]  R629      5.8465201407670975e-02
    z[1,2,1]  R630      -3.6602858453989029e-02
    z[1,2,1]  R631      -3.7773722410202026e-01
    z[1,2,1]  R632      -2.3643411695957184e-01
    z[1,2,1]  R633      3.9748489856719971e-01
    z[1,2,1]  R634      -0.0962492972612381
    z[1,2,1]  R635      -7.2016052901744843e-02
    z[1,2,1]  R636      -7.8580141067504883e-01
    z[1,2,1]  R637      -7.4929273128509521e-01
    z[1,2,1]  R638      5.3999584913253784e-01
    z[1,2,1]  R639      -0.459747314453125
    z[1,2,1]  R640      -5.8260124921798706e-01
    z[1,2,1]  R641      1.2367238849401474e-01
    z[1,2,1]  R642      -4.4082650542259216e-01
    z[1,2,1]  R643      -1.9293196499347687e-01
    z[1,2,1]  R644      1.0183781385421753e-02
    z[1,2,1]  R645      -8.0275171995162964e-01
    z[1,2,1]  R646      -7.8943598270416260e-01
    z[1,2,1]  R647      2.6834788918495178e-01
    z[1,2,1]  R648      -6.6552299261093140e-01
    z[1,2,1]  R649      -6.2895292043685913e-01
    z[1,2,1]  R650      -1.6427399218082428e-01
    z[1,2,1]  R651      -7.1306502819061279e-01
    z[1,2,1]  R652      -1.2277639657258987e-01
    z[1,2,1]  R653      5.0446885824203491e-01
    z[1,2,1]  R654      6.5233653783798218e-01
    z[1,2,1]  R655      -7.5898337364196777e-01
    z[1,2,1]  R656      -1.4968656003475189e-01
    z[1,2,1]  R657      3.3593121170997620e-01
    z[1,2,1]  R658      -0.62202388048172
    z[1,2,1]  R659      -8.9839559793472290e-01
    z[1,2,1]  R660      -3.7316444516181946e-01
    z[1,2,1]  R661      -7.5438439846038818e-01
    z[1,2,1]  R662      -0.750278890132904
    z[1,2,1]  R663      -0.671106219291687
    z[1,2,1]  R664      -4.1270947456359863e-01
    z[1,2,1]  R665      -6.1707812547683716e-01
    z[1,2,1]  R666      -4.1638168692588806e-01
    z[1,2,1]  R667      4.6346348524093628e-01
    z[1,2,1]  R668      7.7009522914886475e-01
    z[1,2,1]  R669      8.3872324228286743e-01
    z[1,2,1]  R670      8.4543758630752563e-01
    z[1,2,1]  R671      8.6298817396163940e-01
    z[1,2,1]  R672      7.5134354829788208e-01
    z[1,2,1]  R673      8.3110558986663818e-01
    z[1,2,1]  R674      4.9972397089004517e-01
    z[1,2,1]  R675      4.6165066957473755e-01
    z[1,2,1]  R676      6.3231056928634644e-01
    z[1,2,1]  R677      5.7388871908187866e-01
    z[1,2,1]  R678      5.6774681806564331e-01
    z[1,2,1]  R679      9.4949412345886230e-01
    z[1,2,1]  R680      9.1691529750823975e-01
    z[1,2,1]  R681      6.8674588203430176e-01
    z[1,2,1]  R682      4.5204082131385803e-01
    z[1,2,1]  R683      9.4661259651184082e-01
    z[1,2,1]  R684      9.0046483278274536e-01
    z[1,2,1]  R685      8.4820568561553955e-01
    z[1,2,1]  R686      7.4543327093124390e-01
    z[1,2,1]  R687      8.3941560983657837e-01
    z[1,2,1]  R688      7.7500838041305542e-01
    z[1,2,1]  R689      8.1515860557556152e-01
    z[1,2,1]  R690      7.6194858551025391e-01
    z[1,2,1]  R691      0.707585871219635
    z[1,2,1]  R692      6.5791672468185425e-01
    z[1,2,1]  R693      5.4883909225463867e-01
    z[1,2,1]  R694      8.3625626564025879e-01
    z[1,2,1]  R695      7.5414651632308960e-01
    z[1,2,1]  R696      6.9773238897323608e-01
    z[1,2,1]  R697      0.78978431224823
    z[1,2,1]  R698      6.9925773143768311e-01
    z[1,2,1]  R699      7.4881255626678467e-01
    z[1,2,1]  R700      9.1009914875030518e-02
    z[1,2,1]  R701      8.7913438677787781e-02
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R572      -1
    z[1,2,2]  R573      1
    z[1,2,2]  R582      -7.0025521516799927e-01
    z[1,2,2]  R583      -7.6836895942687988e-01
    z[1,2,2]  R584      -0.0929165631532669
    z[1,2,2]  R585      -4.3553096055984497e-01
    z[1,2,2]  R586      1.8740169703960419e-01
    z[1,2,2]  R587      -3.3837187290191650e-01
    z[1,2,2]  R588      -7.1238033473491669e-02
    z[1,2,2]  R589      -5.3833943605422974e-01
    z[1,2,2]  R590      -5.2186346054077148e-01
    z[1,2,2]  R591      -8.6485099792480469e-01
    z[1,2,2]  R592      -3.9744108915328979e-01
    z[1,2,2]  R593      1.5725603699684143e-01
    z[1,2,2]  R594      2.7716800570487976e-01
    z[1,2,2]  R595      -3.1933054327964783e-01
    z[1,2,2]  R596      3.9546927809715271e-01
    z[1,2,2]  R597      -1.5717601776123047e-01
    z[1,2,2]  R598      3.7255945801734924e-01
    z[1,2,2]  R599      5.3710758686065674e-01
    z[1,2,2]  R600      4.6185827255249023e-01
    z[1,2,2]  R601      6.3423448801040649e-01
    z[1,2,2]  R602      -2.0403549075126648e-01
    z[1,2,2]  R603      -2.6846387982368469e-01
    z[1,2,2]  R604      -9.0720631182193756e-02
    z[1,2,2]  R605      -2.8542402386665344e-01
    z[1,2,2]  R606      -1.1157270520925522e-01
    z[1,2,2]  R607      1.3022735714912415e-01
    z[1,2,2]  R608      -1.3916942477226257e-01
    z[1,2,2]  R609      2.6455676555633545e-01
    z[1,2,2]  R610      -4.4667381048202515e-01
    z[1,2,2]  R611      4.6143519878387451e-01
    z[1,2,2]  R612      -4.1570979356765747e-01
    z[1,2,2]  R613      -0.739593505859375
    z[1,2,2]  R614      -3.4730136394500732e-01
    z[1,2,2]  R615      -2.1545560657978058e-01
    z[1,2,2]  R616      -1.1575036495923996e-01
    z[1,2,2]  R617      -4.0366676449775696e-01
    z[1,2,2]  R618      -3.9089929312467575e-02
    z[1,2,2]  R619      -3.6604872345924377e-01
    z[1,2,2]  R620      -5.3441685438156128e-01
    z[1,2,2]  R621      -1.4731751382350922e-01
    z[1,2,2]  R622      6.4919173717498779e-02
    z[1,2,2]  R623      -4.3855801224708557e-01
    z[1,2,2]  R624      7.6549343764781952e-02
    z[1,2,2]  R625      -4.3491214513778687e-01
    z[1,2,2]  R626      -2.6849663257598877e-01
    z[1,2,2]  R627      2.1794764697551727e-01
    z[1,2,2]  R628      4.1993027925491333e-01
    z[1,2,2]  R629      -2.7109694480895996e-01
    z[1,2,2]  R630      2.2073593735694885e-01
    z[1,2,2]  R631      4.9149698019027710e-01
    z[1,2,2]  R632      -0.0428561195731163
    z[1,2,2]  R633      -5.2748352289199829e-01
    z[1,2,2]  R634      2.3536044359207153e-01
    z[1,2,2]  R635      -1.1757723242044449e-01
    z[1,2,2]  R636      2.0246763527393341e-01
    z[1,2,2]  R637      3.1087455153465271e-01
    z[1,2,2]  R638      7.8904800117015839e-02
    z[1,2,2]  R639      -2.2650142014026642e-01
    z[1,2,2]  R640      6.4786237478256226e-01
    z[1,2,2]  R641      -0.54561448097229
    z[1,2,2]  R642      -0.0861566811800003
    z[1,2,2]  R643      -1.2679979205131531e-01
    z[1,2,2]  R644      -5.7672321796417236e-01
    z[1,2,2]  R645      1.9212525337934494e-02
    z[1,2,2]  R646      3.5149121284484863e-01
    z[1,2,2]  R647      -2.0834234356880188e-01
    z[1,2,2]  R648      1.1803038418292999e-01
    z[1,2,2]  R649      -1.1426251381635666e-01
    z[1,2,2]  R650      -3.3169126510620117e-01
    z[1,2,2]  R651      -5.3151518106460571e-02
    z[1,2,2]  R652      -3.6207896471023560e-01
    z[1,2,2]  R653      -1.8947304785251617e-01
    z[1,2,2]  R654      -3.4503698348999023e-01
    z[1,2,2]  R655      1.6016542911529541e-01
    z[1,2,2]  R656      -2.2463127970695496e-01
    z[1,2,2]  R657      -2.0017072558403015e-01
    z[1,2,2]  R658      0.338600754737854
    z[1,2,2]  R659      -8.5146024823188782e-02
    z[1,2,2]  R660      -8.3877243101596832e-02
    z[1,2,2]  R661      -1.3389788568019867e-01
    z[1,2,2]  R662      -5.0815820693969727e-01
    z[1,2,2]  R663      -4.2302456498146057e-01
    z[1,2,2]  R664      -1.7271538078784943e-01
    z[1,2,2]  R665      3.6518442630767822e-01
    z[1,2,2]  R666      4.5311173796653748e-01
    z[1,2,2]  R667      -5.6003034114837646e-01
    z[1,2,2]  R668      1.2632903642952442e-02
    z[1,2,2]  R669      2.2631423175334930e-01
    z[1,2,2]  R670      0.0645333081483841
    z[1,2,2]  R671      2.3833848536014557e-01
    z[1,2,2]  R672      -5.6410312652587891e-01
    z[1,2,2]  R673      -4.5141422748565674e-01
    z[1,2,2]  R674      -3.5690742731094360e-01
    z[1,2,2]  R675      -4.5796698331832886e-01
    z[1,2,2]  R676      -6.8271929025650024e-01
    z[1,2,2]  R677      -6.9360530376434326e-01
    z[1,2,2]  R678      -5.2525812387466431e-01
    z[1,2,2]  R679      1.9719203934073448e-02
    z[1,2,2]  R680      6.9385424256324768e-02
    z[1,2,2]  R681      -5.6376541033387184e-03
    z[1,2,2]  R682      -2.7912083268165588e-01
    z[1,2,2]  R683      2.6320907473564148e-01
    z[1,2,2]  R684      5.5256552994251251e-02
    z[1,2,2]  R685      3.1515088677406311e-01
    z[1,2,2]  R686      1.2877109646797180e-01
    z[1,2,2]  R687      -2.0384170114994049e-01
    z[1,2,2]  R688      1.8829772248864174e-02
    z[1,2,2]  R689      3.6813059449195862e-01
    z[1,2,2]  R690      4.3131643533706665e-01
    z[1,2,2]  R691      1.9450370222330093e-02
    z[1,2,2]  R692      -6.0998445749282837e-01
    z[1,2,2]  R693      -6.5625613927841187e-01
    z[1,2,2]  R694      -1.3309018313884735e-01
    z[1,2,2]  R695      2.6949909329414368e-01
    z[1,2,2]  R696      -8.9618965983390808e-02
    z[1,2,2]  R697      5.2157271653413773e-02
    z[1,2,2]  R698      7.9599849879741669e-02
    z[1,2,2]  R699      1.7099264264106750e-01
    z[1,2,2]  R700      6.9347119331359863e-01
    z[1,2,2]  R701      3.5757419466972351e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R574      -1
    z[1,2,3]  R575      1
    z[1,2,3]  R582      3.6499090492725372e-02
    z[1,2,3]  R583      4.2380407452583313e-01
    z[1,2,3]  R584      5.0820440053939819e-01
    z[1,2,3]  R585      6.3960433006286621e-01
    z[1,2,3]  R586      3.3650997281074524e-01
    z[1,2,3]  R587      1.9221606850624084e-01
    z[1,2,3]  R588      2.6353740692138672e-01
    z[1,2,3]  R589      2.3746763169765472e-01
    z[1,2,3]  R590      5.3477507829666138e-01
    z[1,2,3]  R591      1.0930994898080826e-01
    z[1,2,3]  R592      -4.6457889676094055e-01
    z[1,2,3]  R593      5.0418758392333984e-01
    z[1,2,3]  R594      -4.6074721217155457e-01
    z[1,2,3]  R595      -3.0038896203041077e-01
    z[1,2,3]  R596      3.4020888805389404e-01
    z[1,2,3]  R597      -3.1392174959182739e-01
    z[1,2,3]  R598      1.8635661900043488e-01
    z[1,2,3]  R599      0.0696042999625206
    z[1,2,3]  R600      3.8880702853202820e-01
    z[1,2,3]  R601      2.0800997316837311e-01
    z[1,2,3]  R602      4.0330576896667480e-01
    z[1,2,3]  R603      1.7856582999229431e-02
    z[1,2,3]  R604      1.0562287271022797e-01
    z[1,2,3]  R605      5.0042307376861572e-01
    z[1,2,3]  R606      -1.2341390550136566e-01
    z[1,2,3]  R607      4.5411249995231628e-01
    z[1,2,3]  R608      -4.3373328447341919e-01
    z[1,2,3]  R609      -7.0228505134582520e-01
    z[1,2,3]  R610      2.5343433022499084e-02
    z[1,2,3]  R611      -0.541547417640686
    z[1,2,3]  R612      -2.4376621469855309e-02
    z[1,2,3]  R613      4.8547735810279846e-01
    z[1,2,3]  R614      5.0373876094818115e-01
    z[1,2,3]  R615      2.6542711257934570e-01
    z[1,2,3]  R616      5.8216649293899536e-01
    z[1,2,3]  R617      7.7554568648338318e-02
    z[1,2,3]  R618      1.7386291921138763e-01
    z[1,2,3]  R619      1.5898482874035835e-02
    z[1,2,3]  R620      2.1585205197334290e-01
    z[1,2,3]  R621      -5.3929954767227173e-01
    z[1,2,3]  R622      2.8598424792289734e-01
    z[1,2,3]  R623      5.7795327156782150e-02
    z[1,2,3]  R624      5.7174623012542725e-01
    z[1,2,3]  R625      -3.3884122967720032e-01
    z[1,2,3]  R626      2.6786521077156067e-01
    z[1,2,3]  R627      -4.5454555749893188e-01
    z[1,2,3]  R628      -0.686290979385376
    z[1,2,3]  R629      -6.2507015466690063e-01
    z[1,2,3]  R630      -7.8475004434585571e-01
    z[1,2,3]  R631      -6.1852329969406128e-01
    z[1,2,3]  R632      5.2582442760467529e-01
    z[1,2,3]  R633      -6.0382641851902008e-02
    z[1,2,3]  R634      -7.2278821468353271e-01
    z[1,2,3]  R635      -5.0711852312088013e-01
    z[1,2,3]  R636      1.3981281220912933e-01
    z[1,2,3]  R637      -3.8838258385658264e-01
    z[1,2,3]  R638      -4.6801382303237915e-01
    z[1,2,3]  R639      -1.5272186696529388e-01
    z[1,2,3]  R640      -1.5562401711940765e-01
    z[1,2,3]  R641      -3.8897407054901123e-01
    z[1,2,3]  R642      3.3179691433906555e-01
    z[1,2,3]  R643      -7.4050635099411011e-01
    z[1,2,3]  R644      -7.1543955802917480e-01
    z[1,2,3]  R645      -1.6899734735488892e-01
    z[1,2,3]  R646      -2.9901450872421265e-01
    z[1,2,3]  R647      -6.2989783287048340e-01
    z[1,2,3]  R648      -3.0583354830741882e-01
    z[1,2,3]  R649      -9.0693213045597076e-02
    z[1,2,3]  R650      -3.6551168560981750e-01
    z[1,2,3]  R651      -2.0487499237060547e-01
    z[1,2,3]  R652      2.2473834455013275e-01
    z[1,2,3]  R653      3.9176097512245178e-01
    z[1,2,3]  R654      3.1831261515617371e-01
    z[1,2,3]  R655      -3.2946917414665222e-01
    z[1,2,3]  R656      -7.1472346782684326e-01
    z[1,2,3]  R657      -5.3426802158355713e-01
    z[1,2,3]  R658      9.2764936387538910e-02
    z[1,2,3]  R659      3.5665526986122131e-01
    z[1,2,3]  R660      -1.0075378417968750e-01
    z[1,2,3]  R661      6.7626923322677612e-02
    z[1,2,3]  R662      -2.5656517595052719e-02
    z[1,2,3]  R663      1.0290110856294632e-01
    z[1,2,3]  R664      -3.7951406836509705e-01
    z[1,2,3]  R665      1.5847012400627136e-01
    z[1,2,3]  R666      -9.5752961933612823e-02
    z[1,2,3]  R667      1.2112659215927124e-01
    z[1,2,3]  R668      -2.8817000985145569e-01
    z[1,2,3]  R669      -1.2101585045456886e-02
    z[1,2,3]  R670      -3.5101306438446045e-01
    z[1,2,3]  R671      2.6030080392956734e-02
    z[1,2,3]  R672      2.0595878362655640e-01
    z[1,2,3]  R673      2.9962339997291565e-01
    z[1,2,3]  R674      3.5861894488334656e-01
    z[1,2,3]  R675      7.0065456628799438e-01
    z[1,2,3]  R676      -2.4264791607856750e-01
    z[1,2,3]  R677      -1.7299422621726990e-01
    z[1,2,3]  R678      -1.3633483648300171e-01
    z[1,2,3]  R679      2.0767839252948761e-01
    z[1,2,3]  R680      -6.9356516178231686e-05
    z[1,2,3]  R681      -1.2251529842615128e-01
    z[1,2,3]  R682      8.1395357847213745e-01
    z[1,2,3]  R683      1.0558506101369858e-01
    z[1,2,3]  R684      -1.3593651354312897e-01
    z[1,2,3]  R685      2.8788870573043823e-01
    z[1,2,3]  R686      2.0491313934326172e-01
    z[1,2,3]  R687      -1.5126244723796844e-01
    z[1,2,3]  R688      2.3018684983253479e-01
    z[1,2,3]  R689      3.3910858631134033e-01
    z[1,2,3]  R690      0.0849059447646141
    z[1,2,3]  R691      2.1504996716976166e-01
    z[1,2,3]  R692      3.2789698243141174e-01
    z[1,2,3]  R693      6.5549522638320923e-02
    z[1,2,3]  R694      -2.1718624234199524e-01
    z[1,2,3]  R695      -2.5616735219955444e-02
    z[1,2,3]  R696      -3.9837455749511719e-01
    z[1,2,3]  R697      3.6927703768014908e-02
    z[1,2,3]  R698      3.8007974624633789e-01
    z[1,2,3]  R699      -5.1780611276626587e-01
    z[1,2,3]  R700      -0.0729045420885086
    z[1,2,3]  R701      -1.4556339383125305e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R576      -1
    z[1,2,4]  R577      1
    z[1,2,4]  R582      -6.5206247568130493e-01
    z[1,2,4]  R583      -1.2586151063442230e-01
    z[1,2,4]  R584      -3.7285369634628296e-01
    z[1,2,4]  R585      2.2079035639762878e-01
    z[1,2,4]  R586      -4.1671305894851685e-02
    z[1,2,4]  R587      -3.0649396777153015e-01
    z[1,2,4]  R588      -7.3452973365783691e-01
    z[1,2,4]  R589      2.4466475844383240e-01
    z[1,2,4]  R590      7.3377601802349091e-02
    z[1,2,4]  R591      1.7693807184696198e-01
    z[1,2,4]  R592      4.6062642335891724e-01
    z[1,2,4]  R593      -1.2591026723384857e-01
    z[1,2,4]  R594      3.6756515502929688e-01
    z[1,2,4]  R595      0.665052592754364
    z[1,2,4]  R596      2.8749847412109375e-01
    z[1,2,4]  R597      -3.1212879344820976e-02
    z[1,2,4]  R598      -3.7841506302356720e-02
    z[1,2,4]  R599      0.0452711246907711
    z[1,2,4]  R600      0.0777883306145668
    z[1,2,4]  R601      1.3398057222366333e-01
    z[1,2,4]  R602      2.4681188166141510e-01
    z[1,2,4]  R603      -0.088363416492939
    z[1,2,4]  R604      4.5156961679458618e-01
    z[1,2,4]  R605      8.8034041225910187e-02
    z[1,2,4]  R606      -6.2480556964874268e-01
    z[1,2,4]  R607      1.5076331794261932e-01
    z[1,2,4]  R608      -6.4340668916702271e-01
    z[1,2,4]  R609      5.3378814458847046e-01
    z[1,2,4]  R610      -0.409236341714859
    z[1,2,4]  R611      5.5659556388854980e-01
    z[1,2,4]  R612      -3.8463276624679565e-01
    z[1,2,4]  R613      9.5938645303249359e-02
    z[1,2,4]  R614      -6.6198281943798065e-02
    z[1,2,4]  R615      -3.8781216740608215e-01
    z[1,2,4]  R616      -1.2392628192901611e-01
    z[1,2,4]  R617      -3.0565986037254333e-01
    z[1,2,4]  R618      -1.7183527350425720e-01
    z[1,2,4]  R619      1.3652063906192780e-01
    z[1,2,4]  R620      0.0509721003472805
    z[1,2,4]  R621      5.2445590496063232e-01
    z[1,2,4]  R622      2.2199855744838715e-01
    z[1,2,4]  R623      4.9800035357475281e-01
    z[1,2,4]  R624      -1.5305636823177338e-01
    z[1,2,4]  R625      -4.0015062689781189e-01
    z[1,2,4]  R626      -6.5390810370445251e-02
    z[1,2,4]  R627      7.4854081869125366e-01
    z[1,2,4]  R628      4.7155517339706421e-01
    z[1,2,4]  R629      4.6287944912910461e-01
    z[1,2,4]  R630      0.389067679643631
    z[1,2,4]  R631      4.6220120787620544e-01
    z[1,2,4]  R632      -7.2527617216110229e-02
    z[1,2,4]  R633      -4.4467210769653320e-01
    z[1,2,4]  R634      5.6296974420547485e-01
    z[1,2,4]  R635      0.647429883480072
    z[1,2,4]  R636      5.5801492184400558e-02
    z[1,2,4]  R637      -1.7731563746929169e-01
    z[1,2,4]  R638      4.2421564459800720e-01
    z[1,2,4]  R639      1.9498154520988464e-01
    z[1,2,4]  R640      2.2781883180141449e-01
    z[1,2,4]  R641      3.9964246749877930e-01
    z[1,2,4]  R642      3.9224009960889816e-02
    z[1,2,4]  R643      5.6126755475997925e-01
    z[1,2,4]  R644      -3.1642830371856689e-01
    z[1,2,4]  R645      -6.5407925285398960e-03
    z[1,2,4]  R646      1.5727029740810394e-01
    z[1,2,4]  R647      6.1651289463043213e-01
    z[1,2,4]  R648      1.0274988412857056e-01
    z[1,2,4]  R649      1.2560781836509705e-01
    z[1,2,4]  R650      6.3737088441848755e-01
    z[1,2,4]  R651      1.9057793915271759e-01
    z[1,2,4]  R652      7.5338676571846008e-02
    z[1,2,4]  R653      -4.2842742800712585e-01
    z[1,2,4]  R654      -3.0310210585594177e-01
    z[1,2,4]  R655      2.1609136462211609e-01
    z[1,2,4]  R656      2.2000500559806824e-01
    z[1,2,4]  R657      4.0507584810256958e-01
    z[1,2,4]  R658      1.6546308994293213e-01
    z[1,2,4]  R659      -1.2892046570777893e-01
    z[1,2,4]  R660      2.7788332104682922e-01
    z[1,2,4]  R661      -2.9304352402687073e-01
    z[1,2,4]  R662      -1.5438847243785858e-01
    z[1,2,4]  R663      -7.6973032264504582e-05
    z[1,2,4]  R664      -3.3534789085388184e-01
    z[1,2,4]  R665      -4.2755752801895142e-01
    z[1,2,4]  R666      2.4388051033020020e-01
    z[1,2,4]  R667      -2.8327324986457825e-01
    z[1,2,4]  R668      -3.8198661059141159e-02
    z[1,2,4]  R669      -3.8981625437736511e-01
    z[1,2,4]  R670      -1.3761992752552032e-01
    z[1,2,4]  R671      1.5958875417709351e-01
    z[1,2,4]  R672      -1.5392169356346130e-01
    z[1,2,4]  R673      3.6746963858604431e-02
    z[1,2,4]  R674      -0.658660352230072
    z[1,2,4]  R675      1.4881216920912266e-02
    z[1,2,4]  R676      2.4512492120265961e-01
    z[1,2,4]  R677      -4.6883486211299896e-02
    z[1,2,4]  R678      -2.8469032049179077e-01
    z[1,2,4]  R679      1.4053110778331757e-01
    z[1,2,4]  R680      -9.3117050826549530e-02
    z[1,2,4]  R681      2.6159879565238953e-01
    z[1,2,4]  R682      -2.2049877047538757e-01
    z[1,2,4]  R683      -5.9276461601257324e-02
    z[1,2,4]  R684      -0.257587730884552
    z[1,2,4]  R685      -1.1354881525039673e-01
    z[1,2,4]  R686      -7.5281903147697449e-02
    z[1,2,4]  R687      2.9876199364662170e-01
    z[1,2,4]  R688      6.2722176313400269e-02
    z[1,2,4]  R689      1.0926172882318497e-01
    z[1,2,4]  R690      2.9511335492134094e-01
    z[1,2,4]  R691      -7.2376020252704620e-02
    z[1,2,4]  R692      -2.0937213674187660e-02
    z[1,2,4]  R693      -1.9255377352237701e-01
    z[1,2,4]  R694      2.1501084789633751e-02
    z[1,2,4]  R695      -8.2156062126159668e-03
    z[1,2,4]  R696      2.2068174183368683e-01
    z[1,2,4]  R697      3.2346978783607483e-01
    z[1,2,4]  R698      3.5036367177963257e-01
    z[1,2,4]  R699      2.9226174950599670e-01
    z[1,2,4]  R700      -5.6999187916517258e-02
    z[1,2,4]  R701      2.0588155090808868e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R578      -1
    z[1,2,5]  R579      1
    z[1,2,5]  R582      3.2446511089801788e-02
    z[1,2,5]  R583      -6.5567381680011749e-02
    z[1,2,5]  R584      -0.365255743265152
    z[1,2,5]  R585      -3.6753949522972107e-01
    z[1,2,5]  R586      -2.3557227849960327e-01
    z[1,2,5]  R587      -0.622138261795044
    z[1,2,5]  R588      -3.6611225455999374e-02
    z[1,2,5]  R589      -5.2739516831934452e-03
    z[1,2,5]  R590      -2.3253858089447021e-01
    z[1,2,5]  R591      -2.0286414027214050e-01
    z[1,2,5]  R592      -1.3849419355392456e-01
    z[1,2,5]  R593      5.6229633092880249e-01
    z[1,2,5]  R594      3.6926373839378357e-01
    z[1,2,5]  R595      4.5246917009353638e-01
    z[1,2,5]  R596      -5.0347644090652466e-01
    z[1,2,5]  R597      -3.1183698773384094e-01
    z[1,2,5]  R598      -7.9829913377761841e-01
    z[1,2,5]  R599      -2.9537272453308105e-01
    z[1,2,5]  R600      -2.8188723325729370e-01
    z[1,2,5]  R601      -4.9727156758308411e-01
    z[1,2,5]  R602      -3.7695422768592834e-01
    z[1,2,5]  R603      -4.3837973475456238e-01
    z[1,2,5]  R604      3.8149955216795206e-03
    z[1,2,5]  R605      -6.0314124822616577e-01
    z[1,2,5]  R606      -7.2073573246598244e-03
    z[1,2,5]  R607      4.4679322838783264e-01
    z[1,2,5]  R608      3.0278950929641724e-01
    z[1,2,5]  R609      2.2949904203414917e-02
    z[1,2,5]  R610      -2.5269734859466553e-01
    z[1,2,5]  R611      6.4644269645214081e-02
    z[1,2,5]  R612      -2.2468364238739014e-01
    z[1,2,5]  R613      -6.4025238156318665e-02
    z[1,2,5]  R614      1.6272965073585510e-01
    z[1,2,5]  R615      6.2386733293533325e-01
    z[1,2,5]  R616      1.6510689258575439e-01
    z[1,2,5]  R617      4.6994745731353760e-01
    z[1,2,5]  R618      2.7037739753723145e-01
    z[1,2,5]  R619      2.1190980076789856e-01
    z[1,2,5]  R620      2.1083962917327881e-01
    z[1,2,5]  R621      4.1137434542179108e-02
    z[1,2,5]  R622      -1.3605177402496338e-01
    z[1,2,5]  R623      2.8889194130897522e-01
    z[1,2,5]  R624      -1.4131484925746918e-01
    z[1,2,5]  R625      -1.2616080045700073e-01
    z[1,2,5]  R626      -2.4881792068481445e-01
    z[1,2,5]  R627      3.5429760813713074e-01
    z[1,2,5]  R628      2.5861939787864685e-01
    z[1,2,5]  R629      4.7179350256919861e-01
    z[1,2,5]  R630      -2.3139877617359161e-01
    z[1,2,5]  R631      -9.0957731008529663e-02
    z[1,2,5]  R632      -2.6501569151878357e-01
    z[1,2,5]  R633      1.3838236033916473e-01
    z[1,2,5]  R634      -1.9547903910279274e-02
    z[1,2,5]  R635      7.4831224977970123e-02
    z[1,2,5]  R636      -2.5719344615936279e-01
    z[1,2,5]  R637      -2.8230378031730652e-01
    z[1,2,5]  R638      5.3210198879241943e-01
    z[1,2,5]  R639      -0.801838755607605
    z[1,2,5]  R640      1.8001425266265869e-01
    z[1,2,5]  R641      3.5701093077659607e-01
    z[1,2,5]  R642      -1.5142035484313965e-01
    z[1,2,5]  R643      -1.2355160713195801e-01
    z[1,2,5]  R644      2.4428399279713631e-02
    z[1,2,5]  R645      -4.5424187183380127e-01
    z[1,2,5]  R646      -2.0846258103847504e-01
    z[1,2,5]  R647      -7.1001998148858547e-03
    z[1,2,5]  R648      -6.4996105432510376e-01
    z[1,2,5]  R649      -7.5318956375122070e-01
    z[1,2,5]  R650      4.7404772043228149e-01
    z[1,2,5]  R651      -4.9066326022148132e-01
    z[1,2,5]  R652      -1.1694166809320450e-01
    z[1,2,5]  R653      -0.314789742231369
    z[1,2,5]  R654      -6.6570803523063660e-02
    z[1,2,5]  R655      2.5973695516586304e-01
    z[1,2,5]  R656      5.7863587141036987e-01
    z[1,2,5]  R657      6.0070103406906128e-01
    z[1,2,5]  R658      -5.5635792016983032e-01
    z[1,2,5]  R659      -5.2710570394992828e-02
    z[1,2,5]  R660      8.5005831718444824e-01
    z[1,2,5]  R661      8.9964523911476135e-02
    z[1,2,5]  R662      -1.0144112259149551e-01
    z[1,2,5]  R663      -0.460526704788208
    z[1,2,5]  R664      -6.2519145011901855e-01
    z[1,2,5]  R665      2.1900166571140289e-01
    z[1,2,5]  R666      9.5428600907325745e-02
    z[1,2,5]  R667      -1.0198953002691269e-01
    z[1,2,5]  R668      -1.9380992650985718e-01
    z[1,2,5]  R669      -6.1036027967929840e-02
    z[1,2,5]  R670      -2.1970821544528008e-02
    z[1,2,5]  R671      -9.4059586524963379e-02
    z[1,2,5]  R672      -1.6372489929199219e-01
    z[1,2,5]  R673      4.2902618646621704e-02
    z[1,2,5]  R674      5.2850235253572464e-02
    z[1,2,5]  R675      -1.5487061440944672e-01
    z[1,2,5]  R676      -9.9672386422753334e-03
    z[1,2,5]  R677      -1.5553395450115204e-01
    z[1,2,5]  R678      4.0574066340923309e-02
    z[1,2,5]  R679      -0.122328020632267
    z[1,2,5]  R680      -3.4870034456253052e-01
    z[1,2,5]  R681      1.8090550601482391e-01
    z[1,2,5]  R682      -5.0910115242004395e-02
    z[1,2,5]  R683      -1.6325891017913818e-02
    z[1,2,5]  R684      0.0240008644759655
    z[1,2,5]  R685      1.7423366010189056e-01
    z[1,2,5]  R686      7.4190340936183929e-02
    z[1,2,5]  R687      -3.4981764853000641e-02
    z[1,2,5]  R688      4.1195428371429443e-01
    z[1,2,5]  R689      -1.1364228278398514e-01
    z[1,2,5]  R690      -8.9100472629070282e-02
    z[1,2,5]  R691      -3.0492374300956726e-01
    z[1,2,5]  R692      -1.1079335212707520e-01
    z[1,2,5]  R693      5.3455509245395660e-02
    z[1,2,5]  R694      -1.5185537934303284e-01
    z[1,2,5]  R695      -1.5557087957859039e-01
    z[1,2,5]  R696      1.5664680302143097e-01
    z[1,2,5]  R697      3.6281082034111023e-01
    z[1,2,5]  R698      -9.8257049918174744e-02
    z[1,2,5]  R699      3.9560042321681976e-02
    z[1,2,5]  R700      -1.9892990589141846e-01
    z[1,2,5]  R701      -5.1982551813125610e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R580      -1
    z[1,2,6]  R581      1
    z[1,2,6]  R582      1.3085016608238220e-01
    z[1,2,6]  R583      1.1600548774003983e-01
    z[1,2,6]  R584      4.2506250739097595e-01
    z[1,2,6]  R585      2.4431201815605164e-01
    z[1,2,6]  R586      -1.4500702917575836e-01
    z[1,2,6]  R587      2.1159036457538605e-01
    z[1,2,6]  R588      3.5938540101051331e-01
    z[1,2,6]  R589      -4.6782839298248291e-01
    z[1,2,6]  R590      -1.0615862160921097e-01
    z[1,2,6]  R591      -1.4555260539054871e-01
    z[1,2,6]  R592      2.3571690917015076e-01
    z[1,2,6]  R593      1.0621951520442963e-01
    z[1,2,6]  R594      3.8641107082366943e-01
    z[1,2,6]  R595      -3.6785754561424255e-01
    z[1,2,6]  R596      2.0828416571021080e-02
    z[1,2,6]  R597      -1.2216480448842049e-02
    z[1,2,6]  R598      1.1993527412414551e-02
    z[1,2,6]  R599      8.2460641860961914e-02
    z[1,2,6]  R600      2.1416340768337250e-01
    z[1,2,6]  R601      -1.6538253426551819e-01
    z[1,2,6]  R602      -7.3446303606033325e-02
    z[1,2,6]  R603      -4.2032524943351746e-01
    z[1,2,6]  R604      2.7940708398818970e-01
    z[1,2,6]  R605      -1.8813130259513855e-01
    z[1,2,6]  R606      -2.2651143372058868e-01
    z[1,2,6]  R607      -1.8179714679718018e-01
    z[1,2,6]  R608      1.5003718435764313e-01
    z[1,2,6]  R609      -2.5128149986267090e-01
    z[1,2,6]  R610      3.7031254172325134e-01
    z[1,2,6]  R611      -2.5416231155395508e-01
    z[1,2,6]  R612      -3.8818377256393433e-01
    z[1,2,6]  R613      -1.3745276629924774e-01
    z[1,2,6]  R614      -1.3179273903369904e-01
    z[1,2,6]  R615      5.0018224865198135e-02
    z[1,2,6]  R616      1.4868189394474030e-01
    z[1,2,6]  R617      3.9425730705261230e-01
    z[1,2,6]  R618      -2.5615498423576355e-01
    z[1,2,6]  R619      3.9963837713003159e-02
    z[1,2,6]  R620      1.1153426021337509e-01
    z[1,2,6]  R621      1.6635512933135033e-02
    z[1,2,6]  R622      2.2376313805580139e-01
    z[1,2,6]  R623      1.2190598063170910e-02
    z[1,2,6]  R624      -2.3938070237636566e-01
    z[1,2,6]  R625      1.4452320337295532e-01
    z[1,2,6]  R626      4.2092159390449524e-01
    z[1,2,6]  R627      -4.5116588473320007e-02
    z[1,2,6]  R628      2.2884733974933624e-01
    z[1,2,6]  R629      2.4053448438644409e-01
    z[1,2,6]  R630      3.4515008330345154e-01
    z[1,2,6]  R631      -1.0589775443077087e-01
    z[1,2,6]  R632      -1.2426482141017914e-01
    z[1,2,6]  R633      -4.4793472625315189e-03
    z[1,2,6]  R634      -2.5481733679771423e-01
    z[1,2,6]  R635      -7.5411156285554171e-04
    z[1,2,6]  R636      -2.5086278095841408e-02
    z[1,2,6]  R637      2.8081163763999939e-01
    z[1,2,6]  R638      -6.4469978213310242e-02
    z[1,2,6]  R639      -1.5975619852542877e-01
    z[1,2,6]  R640      1.0130092501640320e-02
    z[1,2,6]  R641      1.9859719276428223e-01
    z[1,2,6]  R642      -1.6831737756729126e-01
    z[1,2,6]  R643      2.3686951398849487e-01
    z[1,2,6]  R644      -1.7415709793567657e-01
    z[1,2,6]  R645      -3.4028398990631104e-01
    z[1,2,6]  R646      1.3159666955471039e-01
    z[1,2,6]  R647      -2.2998319566249847e-01
    z[1,2,6]  R648      1.2799315154552460e-01
    z[1,2,6]  R649      -6.8501620553433895e-03
    z[1,2,6]  R650      -1.3989374041557312e-01
    z[1,2,6]  R651      -0.0764738917350769
    z[1,2,6]  R652      2.7800747752189636e-01
    z[1,2,6]  R653      8.0497294664382935e-02
    z[1,2,6]  R654      1.8978126347064972e-01
    z[1,2,6]  R655      3.0881896615028381e-01
    z[1,2,6]  R656      -1.2726396322250366e-01
    z[1,2,6]  R657      6.1962187290191650e-02
    z[1,2,6]  R658      -2.3533812165260315e-01
    z[1,2,6]  R659      -4.7985520213842392e-02
    z[1,2,6]  R660      1.4164811372756958e-01
    z[1,2,6]  R661      2.2546948492527008e-01
    z[1,2,6]  R662      1.5722465515136719e-01
    z[1,2,6]  R663      -3.8445958495140076e-01
    z[1,2,6]  R664      -0.14777772128582
    z[1,2,6]  R665      1.4122481644153595e-01
    z[1,2,6]  R666      2.7494275569915771e-01
    z[1,2,6]  R667      -1.5206019580364227e-01
    z[1,2,6]  R668      -2.1245667338371277e-01
    z[1,2,6]  R669      -6.7172899842262268e-02
    z[1,2,6]  R670      3.5336604714393616e-01
    z[1,2,6]  R671      1.5318599343299866e-01
    z[1,2,6]  R672      -1.1770993471145630e-01
    z[1,2,6]  R673      5.9793557971715927e-02
    z[1,2,6]  R674      1.7707526683807373e-01
    z[1,2,6]  R675      2.1222686767578125e-01
    z[1,2,6]  R676      1.1529105901718140e-01
    z[1,2,6]  R677      3.6482852697372437e-01
    z[1,2,6]  R678      0.533686101436615
    z[1,2,6]  R679      1.2279906868934631e-01
    z[1,2,6]  R680      1.5007475018501282e-01
    z[1,2,6]  R681      -1.1907586455345154e-01
    z[1,2,6]  R682      -5.7666312903165817e-02
    z[1,2,6]  R683      1.2325332313776016e-01
    z[1,2,6]  R684      7.8757822513580322e-02
    z[1,2,6]  R685      5.3811889141798019e-02
    z[1,2,6]  R686      -2.1906213462352753e-01
    z[1,2,6]  R687      5.9291366487741470e-02
    z[1,2,6]  R688      2.1339060366153717e-01
    z[1,2,6]  R689      -1.5584947168827057e-01
    z[1,2,6]  R690      -2.2106464207172394e-01
    z[1,2,6]  R691      -3.6798080801963806e-01
    z[1,2,6]  R692      -3.0925212427973747e-02
    z[1,2,6]  R693      -3.9553830027580261e-01
    z[1,2,6]  R694      -9.0814061462879181e-02
    z[1,2,6]  R695      -3.2346379756927490e-01
    z[1,2,6]  R696      2.4477085098624229e-02
    z[1,2,6]  R697      3.0615216493606567e-01
    z[1,2,6]  R698      -2.4730274081230164e-01
    z[1,2,6]  R699      1.1387012898921967e-01
    z[1,2,6]  R700      2.1660865843296051e-01
    z[1,2,6]  R701      3.4254112839698792e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R702      -1
    z[2,1,0]  R703      1
    z[2,1,0]  R716      -3.4547504782676697e-01
    z[2,1,0]  R717      1.3561316765844822e-02
    z[2,1,0]  R718      -3.6145329475402832e-01
    z[2,1,0]  R719      -4.5829087495803833e-01
    z[2,1,0]  R720      -0.684083104133606
    z[2,1,0]  R721      5.8577132225036621e-01
    z[2,1,0]  R722      4.8948177695274353e-01
    z[2,1,0]  R723      2.9152107238769531e-01
    z[2,1,0]  R724      1.1649436503648758e-01
    z[2,1,0]  R725      3.7414813041687012e-01
    z[2,1,0]  R726      -1.0246091336011887e-01
    z[2,1,0]  R727      9.4595164060592651e-02
    z[2,1,0]  R728      1.6218294203281403e-01
    z[2,1,0]  R729      -1.3031384348869324e-01
    z[2,1,0]  R730      -4.1496995836496353e-02
    z[2,1,0]  R731      1.2153500691056252e-02
    z[2,1,0]  R732      -1.2515839934349060e-01
    z[2,1,0]  R733      7.1756877005100250e-02
    z[2,1,0]  R734      -4.0827151387929916e-02
    z[2,1,0]  R735      6.3087129592895508e-01
    z[2,1,0]  R736      2.6328464969992638e-02
    z[2,1,0]  R737      6.7273631691932678e-02
    z[2,1,0]  R738      3.0740952491760254e-01
    z[2,1,0]  R739      2.2847460210323334e-01
    z[2,1,0]  R740      0.571487545967102
    z[2,1,0]  R741      3.7006980180740356e-01
    z[2,1,0]  R742      3.5615384578704834e-01
    z[2,1,0]  R743      1.8936680257320404e-01
    z[2,1,0]  R744      2.8686422109603882e-01
    z[2,1,0]  R745      4.6804994344711304e-01
    z[2,1,0]  R746      2.7180549502372742e-01
    z[2,1,0]  R747      2.5965690612792969e-01
    z[2,1,0]  R748      4.5168903470039368e-01
    z[2,1,0]  R749      4.7862139344215393e-01
    z[2,1,0]  R750      5.2210897207260132e-01
    z[2,1,0]  R751      2.0533682405948639e-01
    z[2,1,0]  R752      4.0825748443603516e-01
    z[2,1,0]  R753      2.0486554503440857e-01
    z[2,1,0]  R754      6.4479327201843262e-01
    z[2,1,0]  R755      6.4287084341049194e-01
    z[2,1,0]  R756      -1.8504685163497925e-01
    z[2,1,0]  R757      -4.1042396426200867e-01
    z[2,1,0]  R758      -3.6015835404396057e-01
    z[2,1,0]  R759      -3.9248549938201904e-01
    z[2,1,0]  R760      -5.3533172607421875e-01
    z[2,1,0]  R761      -5.1385068893432617e-01
    z[2,1,0]  R762      -0.294125497341156
    z[2,1,0]  R763      -4.9046209454536438e-01
    z[2,1,0]  R764      -1.8783503770828247e-01
    z[2,1,0]  R765      -2.4487075209617615e-01
    z[2,1,0]  R766      -3.0964162945747375e-01
    z[2,1,0]  R767      -5.7068222761154175e-01
    z[2,1,0]  R768      -4.5240543782711029e-02
    z[2,1,0]  R769      -1.3260327279567719e-01
    z[2,1,0]  R770      5.0913608074188232e-01
    z[2,1,0]  R771      4.3723034858703613e-01
    z[2,1,0]  R772      3.8654750585556030e-01
    z[2,1,0]  R773      5.7518702745437622e-01
    z[2,1,0]  R774      5.7469648122787476e-01
    z[2,1,0]  R775      2.2413673996925354e-01
    z[2,1,0]  R776      -7.6443636417388916e-01
    z[2,1,0]  R777      -6.9400042295455933e-01
    z[2,1,0]  R778      -8.3020389080047607e-01
    z[2,1,0]  R779      -3.9931410551071167e-01
    z[2,1,0]  R780      -7.2825539112091064e-01
    z[2,1,0]  R781      -7.0837658643722534e-01
    z[2,1,0]  R782      -3.4922859072685242e-01
    z[2,1,0]  R783      1.9114144146442413e-01
    z[2,1,0]  R784      3.2021217048168182e-02
    z[2,1,0]  R785      -3.1742650270462036e-01
    z[2,1,0]  R786      -6.5962892770767212e-01
    z[2,1,0]  R787      -4.2270287871360779e-01
    z[2,1,0]  R788      -7.2531211376190186e-01
    z[2,1,0]  R789      -5.7918995618820190e-01
    z[2,1,0]  R790      -7.6002550125122070e-01
    z[2,1,0]  R791      -1.7553168535232544e-01
    z[2,1,0]  R792      -7.1153730154037476e-01
    z[2,1,0]  R793      -4.8035293817520142e-01
    z[2,1,0]  R794      -3.8778927922248840e-01
    z[2,1,0]  R795      -3.6483600735664368e-02
    z[2,1,0]  R796      -8.2963532209396362e-01
    z[2,1,0]  R797      -6.8737351894378662e-01
    z[2,1,0]  R798      -7.1367490291595459e-01
    z[2,1,0]  R799      -2.0795506238937378e-01
    z[2,1,0]  R800      -3.9442569017410278e-01
    z[2,1,0]  R801      -2.4038979411125183e-01
    z[2,1,0]  R802      3.4578088670969009e-02
    z[2,1,0]  R803      -1.9409339129924774e-01
    z[2,1,0]  R804      -1.0027784854173660e-01
    z[2,1,0]  R805      7.5281602330505848e-03
    z[2,1,0]  R806      -7.5817912817001343e-01
    z[2,1,0]  R807      -0.585847795009613
    z[2,1,0]  R808      -1.7512808740139008e-01
    z[2,1,0]  R809      5.4685866832733154e-01
    z[2,1,0]  R810      5.0207936763763428e-01
    z[2,1,0]  R811      -3.2939542084932327e-02
    z[2,1,0]  R812      -1.2607021629810333e-01
    z[2,1,0]  R813      8.6718820035457611e-02
    z[2,1,0]  R814      -3.6362364888191223e-01
    z[2,1,0]  R815      4.5727172493934631e-01
    z[2,1,0]  R816      -7.9709625244140625e-01
    z[2,1,0]  R817      1.0934278368949890e-01
    z[2,1,0]  R818      -1.5613633394241333e-01
    z[2,1,0]  R819      6.6998727619647980e-02
    z[2,1,0]  R820      -2.7986937761306763e-01
    z[2,1,0]  R821      2.3405288159847260e-01
    z[2,1,0]  R822      -1.4988117851316929e-02
    z[2,1,0]  R823      0.00427770521491766
    z[2,1,0]  R824      2.8082564473152161e-01
    z[2,1,0]  R825      4.0474772453308105e-01
    z[2,1,0]  R826      -0.840641438961029
    z[2,1,0]  R827      -5.1673197746276855e-01
    z[2,1,0]  R828      4.7091841697692871e-01
    z[2,1,0]  R829      -2.8321981430053711e-01
    z[2,1,0]  R830      1.2995104491710663e-01
    z[2,1,0]  R831      1.8130710721015930e-01
    z[2,1,0]  R832      3.1230497360229492e-01
    z[2,1,0]  R833      1.9165314733982086e-01
    z[2,1,0]  R834      1.5388001501560211e-01
    z[2,1,0]  R835      5.1341748237609863e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R704      -1
    z[2,1,1]  R705      1
    z[2,1,1]  R716      -0.750278890132904
    z[2,1,1]  R717      -0.671106219291687
    z[2,1,1]  R718      -4.1270947456359863e-01
    z[2,1,1]  R719      -6.1707812547683716e-01
    z[2,1,1]  R720      -4.1638168692588806e-01
    z[2,1,1]  R721      4.6346348524093628e-01
    z[2,1,1]  R722      7.7009522914886475e-01
    z[2,1,1]  R723      8.3872324228286743e-01
    z[2,1,1]  R724      8.4543758630752563e-01
    z[2,1,1]  R725      8.6298817396163940e-01
    z[2,1,1]  R726      7.5134354829788208e-01
    z[2,1,1]  R727      8.3110558986663818e-01
    z[2,1,1]  R728      4.9972397089004517e-01
    z[2,1,1]  R729      4.6165066957473755e-01
    z[2,1,1]  R730      6.3231056928634644e-01
    z[2,1,1]  R731      5.7388871908187866e-01
    z[2,1,1]  R732      5.6774681806564331e-01
    z[2,1,1]  R733      9.4949412345886230e-01
    z[2,1,1]  R734      9.1691529750823975e-01
    z[2,1,1]  R735      6.8674588203430176e-01
    z[2,1,1]  R736      4.5204082131385803e-01
    z[2,1,1]  R737      9.4661259651184082e-01
    z[2,1,1]  R738      9.0046483278274536e-01
    z[2,1,1]  R739      8.4820568561553955e-01
    z[2,1,1]  R740      7.4543327093124390e-01
    z[2,1,1]  R741      8.3941560983657837e-01
    z[2,1,1]  R742      7.7500838041305542e-01
    z[2,1,1]  R743      8.1515860557556152e-01
    z[2,1,1]  R744      7.6194858551025391e-01
    z[2,1,1]  R745      0.707585871219635
    z[2,1,1]  R746      6.5791672468185425e-01
    z[2,1,1]  R747      5.4883909225463867e-01
    z[2,1,1]  R748      8.3625626564025879e-01
    z[2,1,1]  R749      7.5414651632308960e-01
    z[2,1,1]  R750      6.9773238897323608e-01
    z[2,1,1]  R751      0.78978431224823
    z[2,1,1]  R752      6.9925773143768311e-01
    z[2,1,1]  R753      7.4881255626678467e-01
    z[2,1,1]  R754      9.1009914875030518e-02
    z[2,1,1]  R755      8.7913438677787781e-02
    z[2,1,1]  R756      -1.7523691058158875e-01
    z[2,1,1]  R757      -1.6719432175159454e-01
    z[2,1,1]  R758      3.8764795660972595e-01
    z[2,1,1]  R759      -6.0433227568864822e-02
    z[2,1,1]  R760      -6.9771325588226318e-01
    z[2,1,1]  R761      -2.4238368868827820e-01
    z[2,1,1]  R762      4.1101232171058655e-01
    z[2,1,1]  R763      -3.6673498153686523e-01
    z[2,1,1]  R764      5.7936519384384155e-01
    z[2,1,1]  R765      2.9406782984733582e-01
    z[2,1,1]  R766      -4.9336525797843933e-01
    z[2,1,1]  R767      2.2819752991199493e-01
    z[2,1,1]  R768      -5.3672146797180176e-01
    z[2,1,1]  R769      -8.8703013956546783e-02
    z[2,1,1]  R770      -3.6340686678886414e-01
    z[2,1,1]  R771      -7.6629793643951416e-01
    z[2,1,1]  R772      -1.9543415307998657e-01
    z[2,1,1]  R773      -5.2890110015869141e-01
    z[2,1,1]  R774      -4.1696822643280029e-01
    z[2,1,1]  R775      -4.6006512641906738e-01
    z[2,1,1]  R776      -0.0542781837284565
    z[2,1,1]  R777      2.6327449083328247e-01
    z[2,1,1]  R778      -9.6835397183895111e-02
    z[2,1,1]  R779      3.1895977258682251e-01
    z[2,1,1]  R780      -1.4942237176001072e-02
    z[2,1,1]  R781      1.4007595181465149e-01
    z[2,1,1]  R782      3.7733522057533264e-01
    z[2,1,1]  R783      2.2731362283229828e-01
    z[2,1,1]  R784      0.656013011932373
    z[2,1,1]  R785      -1.2028472125530243e-01
    z[2,1,1]  R786      -2.0583732426166534e-01
    z[2,1,1]  R787      0.0802420824766159
    z[2,1,1]  R788      0.226536363363266
    z[2,1,1]  R789      -7.4536859989166260e-02
    z[2,1,1]  R790      -7.2944097220897675e-02
    z[2,1,1]  R791      5.7489979267120361e-01
    z[2,1,1]  R792      -0.541951596736908
    z[2,1,1]  R793      -7.5490123033523560e-01
    z[2,1,1]  R794      6.7670869827270508e-01
    z[2,1,1]  R795      -6.3960880041122437e-01
    z[2,1,1]  R796      -3.2839035987854004e-01
    z[2,1,1]  R797      1.5256562270224094e-02
    z[2,1,1]  R798      -2.3919717967510223e-01
    z[2,1,1]  R799      6.7518049478530884e-01
    z[2,1,1]  R800      -6.7618393898010254e-01
    z[2,1,1]  R801      1.4976819977164268e-02
    z[2,1,1]  R802      9.9239133298397064e-02
    z[2,1,1]  R803      5.8465201407670975e-02
    z[2,1,1]  R804      -3.6602858453989029e-02
    z[2,1,1]  R805      -3.7773722410202026e-01
    z[2,1,1]  R806      -2.3643411695957184e-01
    z[2,1,1]  R807      3.9748489856719971e-01
    z[2,1,1]  R808      -0.0962492972612381
    z[2,1,1]  R809      -7.2016052901744843e-02
    z[2,1,1]  R810      -7.8580141067504883e-01
    z[2,1,1]  R811      -7.4929273128509521e-01
    z[2,1,1]  R812      5.3999584913253784e-01
    z[2,1,1]  R813      -0.459747314453125
    z[2,1,1]  R814      -5.8260124921798706e-01
    z[2,1,1]  R815      1.2367238849401474e-01
    z[2,1,1]  R816      -4.4082650542259216e-01
    z[2,1,1]  R817      -1.9293196499347687e-01
    z[2,1,1]  R818      1.0183781385421753e-02
    z[2,1,1]  R819      -8.0275171995162964e-01
    z[2,1,1]  R820      -7.8943598270416260e-01
    z[2,1,1]  R821      2.6834788918495178e-01
    z[2,1,1]  R822      -6.6552299261093140e-01
    z[2,1,1]  R823      -6.2895292043685913e-01
    z[2,1,1]  R824      -1.6427399218082428e-01
    z[2,1,1]  R825      -7.1306502819061279e-01
    z[2,1,1]  R826      -1.2277639657258987e-01
    z[2,1,1]  R827      5.0446885824203491e-01
    z[2,1,1]  R828      6.5233653783798218e-01
    z[2,1,1]  R829      -7.5898337364196777e-01
    z[2,1,1]  R830      -1.4968656003475189e-01
    z[2,1,1]  R831      3.3593121170997620e-01
    z[2,1,1]  R832      -0.62202388048172
    z[2,1,1]  R833      -8.9839559793472290e-01
    z[2,1,1]  R834      -3.7316444516181946e-01
    z[2,1,1]  R835      -7.5438439846038818e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R706      -1
    z[2,1,2]  R707      1
    z[2,1,2]  R716      -5.0815820693969727e-01
    z[2,1,2]  R717      -4.2302456498146057e-01
    z[2,1,2]  R718      -1.7271538078784943e-01
    z[2,1,2]  R719      3.6518442630767822e-01
    z[2,1,2]  R720      4.5311173796653748e-01
    z[2,1,2]  R721      -5.6003034114837646e-01
    z[2,1,2]  R722      1.2632903642952442e-02
    z[2,1,2]  R723      2.2631423175334930e-01
    z[2,1,2]  R724      0.0645333081483841
    z[2,1,2]  R725      2.3833848536014557e-01
    z[2,1,2]  R726      -5.6410312652587891e-01
    z[2,1,2]  R727      -4.5141422748565674e-01
    z[2,1,2]  R728      -3.5690742731094360e-01
    z[2,1,2]  R729      -4.5796698331832886e-01
    z[2,1,2]  R730      -6.8271929025650024e-01
    z[2,1,2]  R731      -6.9360530376434326e-01
    z[2,1,2]  R732      -5.2525812387466431e-01
    z[2,1,2]  R733      1.9719203934073448e-02
    z[2,1,2]  R734      6.9385424256324768e-02
    z[2,1,2]  R735      -5.6376541033387184e-03
    z[2,1,2]  R736      -2.7912083268165588e-01
    z[2,1,2]  R737      2.6320907473564148e-01
    z[2,1,2]  R738      5.5256552994251251e-02
    z[2,1,2]  R739      3.1515088677406311e-01
    z[2,1,2]  R740      1.2877109646797180e-01
    z[2,1,2]  R741      -2.0384170114994049e-01
    z[2,1,2]  R742      1.8829772248864174e-02
    z[2,1,2]  R743      3.6813059449195862e-01
    z[2,1,2]  R744      4.3131643533706665e-01
    z[2,1,2]  R745      1.9450370222330093e-02
    z[2,1,2]  R746      -6.0998445749282837e-01
    z[2,1,2]  R747      -6.5625613927841187e-01
    z[2,1,2]  R748      -1.3309018313884735e-01
    z[2,1,2]  R749      2.6949909329414368e-01
    z[2,1,2]  R750      -8.9618965983390808e-02
    z[2,1,2]  R751      5.2157271653413773e-02
    z[2,1,2]  R752      7.9599849879741669e-02
    z[2,1,2]  R753      1.7099264264106750e-01
    z[2,1,2]  R754      6.9347119331359863e-01
    z[2,1,2]  R755      3.5757419466972351e-01
    z[2,1,2]  R756      -7.0025521516799927e-01
    z[2,1,2]  R757      -7.6836895942687988e-01
    z[2,1,2]  R758      -0.0929165631532669
    z[2,1,2]  R759      -4.3553096055984497e-01
    z[2,1,2]  R760      1.8740169703960419e-01
    z[2,1,2]  R761      -3.3837187290191650e-01
    z[2,1,2]  R762      -7.1238033473491669e-02
    z[2,1,2]  R763      -5.3833943605422974e-01
    z[2,1,2]  R764      -5.2186346054077148e-01
    z[2,1,2]  R765      -8.6485099792480469e-01
    z[2,1,2]  R766      -3.9744108915328979e-01
    z[2,1,2]  R767      1.5725603699684143e-01
    z[2,1,2]  R768      2.7716800570487976e-01
    z[2,1,2]  R769      -3.1933054327964783e-01
    z[2,1,2]  R770      3.9546927809715271e-01
    z[2,1,2]  R771      -1.5717601776123047e-01
    z[2,1,2]  R772      3.7255945801734924e-01
    z[2,1,2]  R773      5.3710758686065674e-01
    z[2,1,2]  R774      4.6185827255249023e-01
    z[2,1,2]  R775      6.3423448801040649e-01
    z[2,1,2]  R776      -2.0403549075126648e-01
    z[2,1,2]  R777      -2.6846387982368469e-01
    z[2,1,2]  R778      -9.0720631182193756e-02
    z[2,1,2]  R779      -2.8542402386665344e-01
    z[2,1,2]  R780      -1.1157270520925522e-01
    z[2,1,2]  R781      1.3022735714912415e-01
    z[2,1,2]  R782      -1.3916942477226257e-01
    z[2,1,2]  R783      2.6455676555633545e-01
    z[2,1,2]  R784      -4.4667381048202515e-01
    z[2,1,2]  R785      4.6143519878387451e-01
    z[2,1,2]  R786      -4.1570979356765747e-01
    z[2,1,2]  R787      -0.739593505859375
    z[2,1,2]  R788      -3.4730136394500732e-01
    z[2,1,2]  R789      -2.1545560657978058e-01
    z[2,1,2]  R790      -1.1575036495923996e-01
    z[2,1,2]  R791      -4.0366676449775696e-01
    z[2,1,2]  R792      -3.9089929312467575e-02
    z[2,1,2]  R793      -3.6604872345924377e-01
    z[2,1,2]  R794      -5.3441685438156128e-01
    z[2,1,2]  R795      -1.4731751382350922e-01
    z[2,1,2]  R796      6.4919173717498779e-02
    z[2,1,2]  R797      -4.3855801224708557e-01
    z[2,1,2]  R798      7.6549343764781952e-02
    z[2,1,2]  R799      -4.3491214513778687e-01
    z[2,1,2]  R800      -2.6849663257598877e-01
    z[2,1,2]  R801      2.1794764697551727e-01
    z[2,1,2]  R802      4.1993027925491333e-01
    z[2,1,2]  R803      -2.7109694480895996e-01
    z[2,1,2]  R804      2.2073593735694885e-01
    z[2,1,2]  R805      4.9149698019027710e-01
    z[2,1,2]  R806      -0.0428561195731163
    z[2,1,2]  R807      -5.2748352289199829e-01
    z[2,1,2]  R808      2.3536044359207153e-01
    z[2,1,2]  R809      -1.1757723242044449e-01
    z[2,1,2]  R810      2.0246763527393341e-01
    z[2,1,2]  R811      3.1087455153465271e-01
    z[2,1,2]  R812      7.8904800117015839e-02
    z[2,1,2]  R813      -2.2650142014026642e-01
    z[2,1,2]  R814      6.4786237478256226e-01
    z[2,1,2]  R815      -0.54561448097229
    z[2,1,2]  R816      -0.0861566811800003
    z[2,1,2]  R817      -1.2679979205131531e-01
    z[2,1,2]  R818      -5.7672321796417236e-01
    z[2,1,2]  R819      1.9212525337934494e-02
    z[2,1,2]  R820      3.5149121284484863e-01
    z[2,1,2]  R821      -2.0834234356880188e-01
    z[2,1,2]  R822      1.1803038418292999e-01
    z[2,1,2]  R823      -1.1426251381635666e-01
    z[2,1,2]  R824      -3.3169126510620117e-01
    z[2,1,2]  R825      -5.3151518106460571e-02
    z[2,1,2]  R826      -3.6207896471023560e-01
    z[2,1,2]  R827      -1.8947304785251617e-01
    z[2,1,2]  R828      -3.4503698348999023e-01
    z[2,1,2]  R829      1.6016542911529541e-01
    z[2,1,2]  R830      -2.2463127970695496e-01
    z[2,1,2]  R831      -2.0017072558403015e-01
    z[2,1,2]  R832      0.338600754737854
    z[2,1,2]  R833      -8.5146024823188782e-02
    z[2,1,2]  R834      -8.3877243101596832e-02
    z[2,1,2]  R835      -1.3389788568019867e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R708      -1
    z[2,1,3]  R709      1
    z[2,1,3]  R716      -2.5656517595052719e-02
    z[2,1,3]  R717      1.0290110856294632e-01
    z[2,1,3]  R718      -3.7951406836509705e-01
    z[2,1,3]  R719      1.5847012400627136e-01
    z[2,1,3]  R720      -9.5752961933612823e-02
    z[2,1,3]  R721      1.2112659215927124e-01
    z[2,1,3]  R722      -2.8817000985145569e-01
    z[2,1,3]  R723      -1.2101585045456886e-02
    z[2,1,3]  R724      -3.5101306438446045e-01
    z[2,1,3]  R725      2.6030080392956734e-02
    z[2,1,3]  R726      2.0595878362655640e-01
    z[2,1,3]  R727      2.9962339997291565e-01
    z[2,1,3]  R728      3.5861894488334656e-01
    z[2,1,3]  R729      7.0065456628799438e-01
    z[2,1,3]  R730      -2.4264791607856750e-01
    z[2,1,3]  R731      -1.7299422621726990e-01
    z[2,1,3]  R732      -1.3633483648300171e-01
    z[2,1,3]  R733      2.0767839252948761e-01
    z[2,1,3]  R734      -6.9356516178231686e-05
    z[2,1,3]  R735      -1.2251529842615128e-01
    z[2,1,3]  R736      8.1395357847213745e-01
    z[2,1,3]  R737      1.0558506101369858e-01
    z[2,1,3]  R738      -1.3593651354312897e-01
    z[2,1,3]  R739      2.8788870573043823e-01
    z[2,1,3]  R740      2.0491313934326172e-01
    z[2,1,3]  R741      -1.5126244723796844e-01
    z[2,1,3]  R742      2.3018684983253479e-01
    z[2,1,3]  R743      3.3910858631134033e-01
    z[2,1,3]  R744      0.0849059447646141
    z[2,1,3]  R745      2.1504996716976166e-01
    z[2,1,3]  R746      3.2789698243141174e-01
    z[2,1,3]  R747      6.5549522638320923e-02
    z[2,1,3]  R748      -2.1718624234199524e-01
    z[2,1,3]  R749      -2.5616735219955444e-02
    z[2,1,3]  R750      -3.9837455749511719e-01
    z[2,1,3]  R751      3.6927703768014908e-02
    z[2,1,3]  R752      3.8007974624633789e-01
    z[2,1,3]  R753      -5.1780611276626587e-01
    z[2,1,3]  R754      -0.0729045420885086
    z[2,1,3]  R755      -1.4556339383125305e-01
    z[2,1,3]  R756      3.6499090492725372e-02
    z[2,1,3]  R757      4.2380407452583313e-01
    z[2,1,3]  R758      5.0820440053939819e-01
    z[2,1,3]  R759      6.3960433006286621e-01
    z[2,1,3]  R760      3.3650997281074524e-01
    z[2,1,3]  R761      1.9221606850624084e-01
    z[2,1,3]  R762      2.6353740692138672e-01
    z[2,1,3]  R763      2.3746763169765472e-01
    z[2,1,3]  R764      5.3477507829666138e-01
    z[2,1,3]  R765      1.0930994898080826e-01
    z[2,1,3]  R766      -4.6457889676094055e-01
    z[2,1,3]  R767      5.0418758392333984e-01
    z[2,1,3]  R768      -4.6074721217155457e-01
    z[2,1,3]  R769      -3.0038896203041077e-01
    z[2,1,3]  R770      3.4020888805389404e-01
    z[2,1,3]  R771      -3.1392174959182739e-01
    z[2,1,3]  R772      1.8635661900043488e-01
    z[2,1,3]  R773      0.0696042999625206
    z[2,1,3]  R774      3.8880702853202820e-01
    z[2,1,3]  R775      2.0800997316837311e-01
    z[2,1,3]  R776      4.0330576896667480e-01
    z[2,1,3]  R777      1.7856582999229431e-02
    z[2,1,3]  R778      1.0562287271022797e-01
    z[2,1,3]  R779      5.0042307376861572e-01
    z[2,1,3]  R780      -1.2341390550136566e-01
    z[2,1,3]  R781      4.5411249995231628e-01
    z[2,1,3]  R782      -4.3373328447341919e-01
    z[2,1,3]  R783      -7.0228505134582520e-01
    z[2,1,3]  R784      2.5343433022499084e-02
    z[2,1,3]  R785      -0.541547417640686
    z[2,1,3]  R786      -2.4376621469855309e-02
    z[2,1,3]  R787      4.8547735810279846e-01
    z[2,1,3]  R788      5.0373876094818115e-01
    z[2,1,3]  R789      2.6542711257934570e-01
    z[2,1,3]  R790      5.8216649293899536e-01
    z[2,1,3]  R791      7.7554568648338318e-02
    z[2,1,3]  R792      1.7386291921138763e-01
    z[2,1,3]  R793      1.5898482874035835e-02
    z[2,1,3]  R794      2.1585205197334290e-01
    z[2,1,3]  R795      -5.3929954767227173e-01
    z[2,1,3]  R796      2.8598424792289734e-01
    z[2,1,3]  R797      5.7795327156782150e-02
    z[2,1,3]  R798      5.7174623012542725e-01
    z[2,1,3]  R799      -3.3884122967720032e-01
    z[2,1,3]  R800      2.6786521077156067e-01
    z[2,1,3]  R801      -4.5454555749893188e-01
    z[2,1,3]  R802      -0.686290979385376
    z[2,1,3]  R803      -6.2507015466690063e-01
    z[2,1,3]  R804      -7.8475004434585571e-01
    z[2,1,3]  R805      -6.1852329969406128e-01
    z[2,1,3]  R806      5.2582442760467529e-01
    z[2,1,3]  R807      -6.0382641851902008e-02
    z[2,1,3]  R808      -7.2278821468353271e-01
    z[2,1,3]  R809      -5.0711852312088013e-01
    z[2,1,3]  R810      1.3981281220912933e-01
    z[2,1,3]  R811      -3.8838258385658264e-01
    z[2,1,3]  R812      -4.6801382303237915e-01
    z[2,1,3]  R813      -1.5272186696529388e-01
    z[2,1,3]  R814      -1.5562401711940765e-01
    z[2,1,3]  R815      -3.8897407054901123e-01
    z[2,1,3]  R816      3.3179691433906555e-01
    z[2,1,3]  R817      -7.4050635099411011e-01
    z[2,1,3]  R818      -7.1543955802917480e-01
    z[2,1,3]  R819      -1.6899734735488892e-01
    z[2,1,3]  R820      -2.9901450872421265e-01
    z[2,1,3]  R821      -6.2989783287048340e-01
    z[2,1,3]  R822      -3.0583354830741882e-01
    z[2,1,3]  R823      -9.0693213045597076e-02
    z[2,1,3]  R824      -3.6551168560981750e-01
    z[2,1,3]  R825      -2.0487499237060547e-01
    z[2,1,3]  R826      2.2473834455013275e-01
    z[2,1,3]  R827      3.9176097512245178e-01
    z[2,1,3]  R828      3.1831261515617371e-01
    z[2,1,3]  R829      -3.2946917414665222e-01
    z[2,1,3]  R830      -7.1472346782684326e-01
    z[2,1,3]  R831      -5.3426802158355713e-01
    z[2,1,3]  R832      9.2764936387538910e-02
    z[2,1,3]  R833      3.5665526986122131e-01
    z[2,1,3]  R834      -1.0075378417968750e-01
    z[2,1,3]  R835      6.7626923322677612e-02
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R710      -1
    z[2,1,4]  R711      1
    z[2,1,4]  R716      -1.5438847243785858e-01
    z[2,1,4]  R717      -7.6973032264504582e-05
    z[2,1,4]  R718      -3.3534789085388184e-01
    z[2,1,4]  R719      -4.2755752801895142e-01
    z[2,1,4]  R720      2.4388051033020020e-01
    z[2,1,4]  R721      -2.8327324986457825e-01
    z[2,1,4]  R722      -3.8198661059141159e-02
    z[2,1,4]  R723      -3.8981625437736511e-01
    z[2,1,4]  R724      -1.3761992752552032e-01
    z[2,1,4]  R725      1.5958875417709351e-01
    z[2,1,4]  R726      -1.5392169356346130e-01
    z[2,1,4]  R727      3.6746963858604431e-02
    z[2,1,4]  R728      -0.658660352230072
    z[2,1,4]  R729      1.4881216920912266e-02
    z[2,1,4]  R730      2.4512492120265961e-01
    z[2,1,4]  R731      -4.6883486211299896e-02
    z[2,1,4]  R732      -2.8469032049179077e-01
    z[2,1,4]  R733      1.4053110778331757e-01
    z[2,1,4]  R734      -9.3117050826549530e-02
    z[2,1,4]  R735      2.6159879565238953e-01
    z[2,1,4]  R736      -2.2049877047538757e-01
    z[2,1,4]  R737      -5.9276461601257324e-02
    z[2,1,4]  R738      -0.257587730884552
    z[2,1,4]  R739      -1.1354881525039673e-01
    z[2,1,4]  R740      -7.5281903147697449e-02
    z[2,1,4]  R741      2.9876199364662170e-01
    z[2,1,4]  R742      6.2722176313400269e-02
    z[2,1,4]  R743      1.0926172882318497e-01
    z[2,1,4]  R744      2.9511335492134094e-01
    z[2,1,4]  R745      -7.2376020252704620e-02
    z[2,1,4]  R746      -2.0937213674187660e-02
    z[2,1,4]  R747      -1.9255377352237701e-01
    z[2,1,4]  R748      2.1501084789633751e-02
    z[2,1,4]  R749      -8.2156062126159668e-03
    z[2,1,4]  R750      2.2068174183368683e-01
    z[2,1,4]  R751      3.2346978783607483e-01
    z[2,1,4]  R752      3.5036367177963257e-01
    z[2,1,4]  R753      2.9226174950599670e-01
    z[2,1,4]  R754      -5.6999187916517258e-02
    z[2,1,4]  R755      2.0588155090808868e-01
    z[2,1,4]  R756      -6.5206247568130493e-01
    z[2,1,4]  R757      -1.2586151063442230e-01
    z[2,1,4]  R758      -3.7285369634628296e-01
    z[2,1,4]  R759      2.2079035639762878e-01
    z[2,1,4]  R760      -4.1671305894851685e-02
    z[2,1,4]  R761      -3.0649396777153015e-01
    z[2,1,4]  R762      -7.3452973365783691e-01
    z[2,1,4]  R763      2.4466475844383240e-01
    z[2,1,4]  R764      7.3377601802349091e-02
    z[2,1,4]  R765      1.7693807184696198e-01
    z[2,1,4]  R766      4.6062642335891724e-01
    z[2,1,4]  R767      -1.2591026723384857e-01
    z[2,1,4]  R768      3.6756515502929688e-01
    z[2,1,4]  R769      0.665052592754364
    z[2,1,4]  R770      2.8749847412109375e-01
    z[2,1,4]  R771      -3.1212879344820976e-02
    z[2,1,4]  R772      -3.7841506302356720e-02
    z[2,1,4]  R773      0.0452711246907711
    z[2,1,4]  R774      0.0777883306145668
    z[2,1,4]  R775      1.3398057222366333e-01
    z[2,1,4]  R776      2.4681188166141510e-01
    z[2,1,4]  R777      -0.088363416492939
    z[2,1,4]  R778      4.5156961679458618e-01
    z[2,1,4]  R779      8.8034041225910187e-02
    z[2,1,4]  R780      -6.2480556964874268e-01
    z[2,1,4]  R781      1.5076331794261932e-01
    z[2,1,4]  R782      -6.4340668916702271e-01
    z[2,1,4]  R783      5.3378814458847046e-01
    z[2,1,4]  R784      -0.409236341714859
    z[2,1,4]  R785      5.5659556388854980e-01
    z[2,1,4]  R786      -3.8463276624679565e-01
    z[2,1,4]  R787      9.5938645303249359e-02
    z[2,1,4]  R788      -6.6198281943798065e-02
    z[2,1,4]  R789      -3.8781216740608215e-01
    z[2,1,4]  R790      -1.2392628192901611e-01
    z[2,1,4]  R791      -3.0565986037254333e-01
    z[2,1,4]  R792      -1.7183527350425720e-01
    z[2,1,4]  R793      1.3652063906192780e-01
    z[2,1,4]  R794      0.0509721003472805
    z[2,1,4]  R795      5.2445590496063232e-01
    z[2,1,4]  R796      2.2199855744838715e-01
    z[2,1,4]  R797      4.9800035357475281e-01
    z[2,1,4]  R798      -1.5305636823177338e-01
    z[2,1,4]  R799      -4.0015062689781189e-01
    z[2,1,4]  R800      -6.5390810370445251e-02
    z[2,1,4]  R801      7.4854081869125366e-01
    z[2,1,4]  R802      4.7155517339706421e-01
    z[2,1,4]  R803      4.6287944912910461e-01
    z[2,1,4]  R804      0.389067679643631
    z[2,1,4]  R805      4.6220120787620544e-01
    z[2,1,4]  R806      -7.2527617216110229e-02
    z[2,1,4]  R807      -4.4467210769653320e-01
    z[2,1,4]  R808      5.6296974420547485e-01
    z[2,1,4]  R809      0.647429883480072
    z[2,1,4]  R810      5.5801492184400558e-02
    z[2,1,4]  R811      -1.7731563746929169e-01
    z[2,1,4]  R812      4.2421564459800720e-01
    z[2,1,4]  R813      1.9498154520988464e-01
    z[2,1,4]  R814      2.2781883180141449e-01
    z[2,1,4]  R815      3.9964246749877930e-01
    z[2,1,4]  R816      3.9224009960889816e-02
    z[2,1,4]  R817      5.6126755475997925e-01
    z[2,1,4]  R818      -3.1642830371856689e-01
    z[2,1,4]  R819      -6.5407925285398960e-03
    z[2,1,4]  R820      1.5727029740810394e-01
    z[2,1,4]  R821      6.1651289463043213e-01
    z[2,1,4]  R822      1.0274988412857056e-01
    z[2,1,4]  R823      1.2560781836509705e-01
    z[2,1,4]  R824      6.3737088441848755e-01
    z[2,1,4]  R825      1.9057793915271759e-01
    z[2,1,4]  R826      7.5338676571846008e-02
    z[2,1,4]  R827      -4.2842742800712585e-01
    z[2,1,4]  R828      -3.0310210585594177e-01
    z[2,1,4]  R829      2.1609136462211609e-01
    z[2,1,4]  R830      2.2000500559806824e-01
    z[2,1,4]  R831      4.0507584810256958e-01
    z[2,1,4]  R832      1.6546308994293213e-01
    z[2,1,4]  R833      -1.2892046570777893e-01
    z[2,1,4]  R834      2.7788332104682922e-01
    z[2,1,4]  R835      -2.9304352402687073e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R712      -1
    z[2,1,5]  R713      1
    z[2,1,5]  R716      -1.0144112259149551e-01
    z[2,1,5]  R717      -0.460526704788208
    z[2,1,5]  R718      -6.2519145011901855e-01
    z[2,1,5]  R719      2.1900166571140289e-01
    z[2,1,5]  R720      9.5428600907325745e-02
    z[2,1,5]  R721      -1.0198953002691269e-01
    z[2,1,5]  R722      -1.9380992650985718e-01
    z[2,1,5]  R723      -6.1036027967929840e-02
    z[2,1,5]  R724      -2.1970821544528008e-02
    z[2,1,5]  R725      -9.4059586524963379e-02
    z[2,1,5]  R726      -1.6372489929199219e-01
    z[2,1,5]  R727      4.2902618646621704e-02
    z[2,1,5]  R728      5.2850235253572464e-02
    z[2,1,5]  R729      -1.5487061440944672e-01
    z[2,1,5]  R730      -9.9672386422753334e-03
    z[2,1,5]  R731      -1.5553395450115204e-01
    z[2,1,5]  R732      4.0574066340923309e-02
    z[2,1,5]  R733      -0.122328020632267
    z[2,1,5]  R734      -3.4870034456253052e-01
    z[2,1,5]  R735      1.8090550601482391e-01
    z[2,1,5]  R736      -5.0910115242004395e-02
    z[2,1,5]  R737      -1.6325891017913818e-02
    z[2,1,5]  R738      0.0240008644759655
    z[2,1,5]  R739      1.7423366010189056e-01
    z[2,1,5]  R740      7.4190340936183929e-02
    z[2,1,5]  R741      -3.4981764853000641e-02
    z[2,1,5]  R742      4.1195428371429443e-01
    z[2,1,5]  R743      -1.1364228278398514e-01
    z[2,1,5]  R744      -8.9100472629070282e-02
    z[2,1,5]  R745      -3.0492374300956726e-01
    z[2,1,5]  R746      -1.1079335212707520e-01
    z[2,1,5]  R747      5.3455509245395660e-02
    z[2,1,5]  R748      -1.5185537934303284e-01
    z[2,1,5]  R749      -1.5557087957859039e-01
    z[2,1,5]  R750      1.5664680302143097e-01
    z[2,1,5]  R751      3.6281082034111023e-01
    z[2,1,5]  R752      -9.8257049918174744e-02
    z[2,1,5]  R753      3.9560042321681976e-02
    z[2,1,5]  R754      -1.9892990589141846e-01
    z[2,1,5]  R755      -5.1982551813125610e-01
    z[2,1,5]  R756      3.2446511089801788e-02
    z[2,1,5]  R757      -6.5567381680011749e-02
    z[2,1,5]  R758      -0.365255743265152
    z[2,1,5]  R759      -3.6753949522972107e-01
    z[2,1,5]  R760      -2.3557227849960327e-01
    z[2,1,5]  R761      -0.622138261795044
    z[2,1,5]  R762      -3.6611225455999374e-02
    z[2,1,5]  R763      -5.2739516831934452e-03
    z[2,1,5]  R764      -2.3253858089447021e-01
    z[2,1,5]  R765      -2.0286414027214050e-01
    z[2,1,5]  R766      -1.3849419355392456e-01
    z[2,1,5]  R767      5.6229633092880249e-01
    z[2,1,5]  R768      3.6926373839378357e-01
    z[2,1,5]  R769      4.5246917009353638e-01
    z[2,1,5]  R770      -5.0347644090652466e-01
    z[2,1,5]  R771      -3.1183698773384094e-01
    z[2,1,5]  R772      -7.9829913377761841e-01
    z[2,1,5]  R773      -2.9537272453308105e-01
    z[2,1,5]  R774      -2.8188723325729370e-01
    z[2,1,5]  R775      -4.9727156758308411e-01
    z[2,1,5]  R776      -3.7695422768592834e-01
    z[2,1,5]  R777      -4.3837973475456238e-01
    z[2,1,5]  R778      3.8149955216795206e-03
    z[2,1,5]  R779      -6.0314124822616577e-01
    z[2,1,5]  R780      -7.2073573246598244e-03
    z[2,1,5]  R781      4.4679322838783264e-01
    z[2,1,5]  R782      3.0278950929641724e-01
    z[2,1,5]  R783      2.2949904203414917e-02
    z[2,1,5]  R784      -2.5269734859466553e-01
    z[2,1,5]  R785      6.4644269645214081e-02
    z[2,1,5]  R786      -2.2468364238739014e-01
    z[2,1,5]  R787      -6.4025238156318665e-02
    z[2,1,5]  R788      1.6272965073585510e-01
    z[2,1,5]  R789      6.2386733293533325e-01
    z[2,1,5]  R790      1.6510689258575439e-01
    z[2,1,5]  R791      4.6994745731353760e-01
    z[2,1,5]  R792      2.7037739753723145e-01
    z[2,1,5]  R793      2.1190980076789856e-01
    z[2,1,5]  R794      2.1083962917327881e-01
    z[2,1,5]  R795      4.1137434542179108e-02
    z[2,1,5]  R796      -1.3605177402496338e-01
    z[2,1,5]  R797      2.8889194130897522e-01
    z[2,1,5]  R798      -1.4131484925746918e-01
    z[2,1,5]  R799      -1.2616080045700073e-01
    z[2,1,5]  R800      -2.4881792068481445e-01
    z[2,1,5]  R801      3.5429760813713074e-01
    z[2,1,5]  R802      2.5861939787864685e-01
    z[2,1,5]  R803      4.7179350256919861e-01
    z[2,1,5]  R804      -2.3139877617359161e-01
    z[2,1,5]  R805      -9.0957731008529663e-02
    z[2,1,5]  R806      -2.6501569151878357e-01
    z[2,1,5]  R807      1.3838236033916473e-01
    z[2,1,5]  R808      -1.9547903910279274e-02
    z[2,1,5]  R809      7.4831224977970123e-02
    z[2,1,5]  R810      -2.5719344615936279e-01
    z[2,1,5]  R811      -2.8230378031730652e-01
    z[2,1,5]  R812      5.3210198879241943e-01
    z[2,1,5]  R813      -0.801838755607605
    z[2,1,5]  R814      1.8001425266265869e-01
    z[2,1,5]  R815      3.5701093077659607e-01
    z[2,1,5]  R816      -1.5142035484313965e-01
    z[2,1,5]  R817      -1.2355160713195801e-01
    z[2,1,5]  R818      2.4428399279713631e-02
    z[2,1,5]  R819      -4.5424187183380127e-01
    z[2,1,5]  R820      -2.0846258103847504e-01
    z[2,1,5]  R821      -7.1001998148858547e-03
    z[2,1,5]  R822      -6.4996105432510376e-01
    z[2,1,5]  R823      -7.5318956375122070e-01
    z[2,1,5]  R824      4.7404772043228149e-01
    z[2,1,5]  R825      -4.9066326022148132e-01
    z[2,1,5]  R826      -1.1694166809320450e-01
    z[2,1,5]  R827      -0.314789742231369
    z[2,1,5]  R828      -6.6570803523063660e-02
    z[2,1,5]  R829      2.5973695516586304e-01
    z[2,1,5]  R830      5.7863587141036987e-01
    z[2,1,5]  R831      6.0070103406906128e-01
    z[2,1,5]  R832      -5.5635792016983032e-01
    z[2,1,5]  R833      -5.2710570394992828e-02
    z[2,1,5]  R834      8.5005831718444824e-01
    z[2,1,5]  R835      8.9964523911476135e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R714      -1
    z[2,1,6]  R715      1
    z[2,1,6]  R716      1.5722465515136719e-01
    z[2,1,6]  R717      -3.8445958495140076e-01
    z[2,1,6]  R718      -0.14777772128582
    z[2,1,6]  R719      1.4122481644153595e-01
    z[2,1,6]  R720      2.7494275569915771e-01
    z[2,1,6]  R721      -1.5206019580364227e-01
    z[2,1,6]  R722      -2.1245667338371277e-01
    z[2,1,6]  R723      -6.7172899842262268e-02
    z[2,1,6]  R724      3.5336604714393616e-01
    z[2,1,6]  R725      1.5318599343299866e-01
    z[2,1,6]  R726      -1.1770993471145630e-01
    z[2,1,6]  R727      5.9793557971715927e-02
    z[2,1,6]  R728      1.7707526683807373e-01
    z[2,1,6]  R729      2.1222686767578125e-01
    z[2,1,6]  R730      1.1529105901718140e-01
    z[2,1,6]  R731      3.6482852697372437e-01
    z[2,1,6]  R732      0.533686101436615
    z[2,1,6]  R733      1.2279906868934631e-01
    z[2,1,6]  R734      1.5007475018501282e-01
    z[2,1,6]  R735      -1.1907586455345154e-01
    z[2,1,6]  R736      -5.7666312903165817e-02
    z[2,1,6]  R737      1.2325332313776016e-01
    z[2,1,6]  R738      7.8757822513580322e-02
    z[2,1,6]  R739      5.3811889141798019e-02
    z[2,1,6]  R740      -2.1906213462352753e-01
    z[2,1,6]  R741      5.9291366487741470e-02
    z[2,1,6]  R742      2.1339060366153717e-01
    z[2,1,6]  R743      -1.5584947168827057e-01
    z[2,1,6]  R744      -2.2106464207172394e-01
    z[2,1,6]  R745      -3.6798080801963806e-01
    z[2,1,6]  R746      -3.0925212427973747e-02
    z[2,1,6]  R747      -3.9553830027580261e-01
    z[2,1,6]  R748      -9.0814061462879181e-02
    z[2,1,6]  R749      -3.2346379756927490e-01
    z[2,1,6]  R750      2.4477085098624229e-02
    z[2,1,6]  R751      3.0615216493606567e-01
    z[2,1,6]  R752      -2.4730274081230164e-01
    z[2,1,6]  R753      1.1387012898921967e-01
    z[2,1,6]  R754      2.1660865843296051e-01
    z[2,1,6]  R755      3.4254112839698792e-01
    z[2,1,6]  R756      1.3085016608238220e-01
    z[2,1,6]  R757      1.1600548774003983e-01
    z[2,1,6]  R758      4.2506250739097595e-01
    z[2,1,6]  R759      2.4431201815605164e-01
    z[2,1,6]  R760      -1.4500702917575836e-01
    z[2,1,6]  R761      2.1159036457538605e-01
    z[2,1,6]  R762      3.5938540101051331e-01
    z[2,1,6]  R763      -4.6782839298248291e-01
    z[2,1,6]  R764      -1.0615862160921097e-01
    z[2,1,6]  R765      -1.4555260539054871e-01
    z[2,1,6]  R766      2.3571690917015076e-01
    z[2,1,6]  R767      1.0621951520442963e-01
    z[2,1,6]  R768      3.8641107082366943e-01
    z[2,1,6]  R769      -3.6785754561424255e-01
    z[2,1,6]  R770      2.0828416571021080e-02
    z[2,1,6]  R771      -1.2216480448842049e-02
    z[2,1,6]  R772      1.1993527412414551e-02
    z[2,1,6]  R773      8.2460641860961914e-02
    z[2,1,6]  R774      2.1416340768337250e-01
    z[2,1,6]  R775      -1.6538253426551819e-01
    z[2,1,6]  R776      -7.3446303606033325e-02
    z[2,1,6]  R777      -4.2032524943351746e-01
    z[2,1,6]  R778      2.7940708398818970e-01
    z[2,1,6]  R779      -1.8813130259513855e-01
    z[2,1,6]  R780      -2.2651143372058868e-01
    z[2,1,6]  R781      -1.8179714679718018e-01
    z[2,1,6]  R782      1.5003718435764313e-01
    z[2,1,6]  R783      -2.5128149986267090e-01
    z[2,1,6]  R784      3.7031254172325134e-01
    z[2,1,6]  R785      -2.5416231155395508e-01
    z[2,1,6]  R786      -3.8818377256393433e-01
    z[2,1,6]  R787      -1.3745276629924774e-01
    z[2,1,6]  R788      -1.3179273903369904e-01
    z[2,1,6]  R789      5.0018224865198135e-02
    z[2,1,6]  R790      1.4868189394474030e-01
    z[2,1,6]  R791      3.9425730705261230e-01
    z[2,1,6]  R792      -2.5615498423576355e-01
    z[2,1,6]  R793      3.9963837713003159e-02
    z[2,1,6]  R794      1.1153426021337509e-01
    z[2,1,6]  R795      1.6635512933135033e-02
    z[2,1,6]  R796      2.2376313805580139e-01
    z[2,1,6]  R797      1.2190598063170910e-02
    z[2,1,6]  R798      -2.3938070237636566e-01
    z[2,1,6]  R799      1.4452320337295532e-01
    z[2,1,6]  R800      4.2092159390449524e-01
    z[2,1,6]  R801      -4.5116588473320007e-02
    z[2,1,6]  R802      2.2884733974933624e-01
    z[2,1,6]  R803      2.4053448438644409e-01
    z[2,1,6]  R804      3.4515008330345154e-01
    z[2,1,6]  R805      -1.0589775443077087e-01
    z[2,1,6]  R806      -1.2426482141017914e-01
    z[2,1,6]  R807      -4.4793472625315189e-03
    z[2,1,6]  R808      -2.5481733679771423e-01
    z[2,1,6]  R809      -7.5411156285554171e-04
    z[2,1,6]  R810      -2.5086278095841408e-02
    z[2,1,6]  R811      2.8081163763999939e-01
    z[2,1,6]  R812      -6.4469978213310242e-02
    z[2,1,6]  R813      -1.5975619852542877e-01
    z[2,1,6]  R814      1.0130092501640320e-02
    z[2,1,6]  R815      1.9859719276428223e-01
    z[2,1,6]  R816      -1.6831737756729126e-01
    z[2,1,6]  R817      2.3686951398849487e-01
    z[2,1,6]  R818      -1.7415709793567657e-01
    z[2,1,6]  R819      -3.4028398990631104e-01
    z[2,1,6]  R820      1.3159666955471039e-01
    z[2,1,6]  R821      -2.2998319566249847e-01
    z[2,1,6]  R822      1.2799315154552460e-01
    z[2,1,6]  R823      -6.8501620553433895e-03
    z[2,1,6]  R824      -1.3989374041557312e-01
    z[2,1,6]  R825      -0.0764738917350769
    z[2,1,6]  R826      2.7800747752189636e-01
    z[2,1,6]  R827      8.0497294664382935e-02
    z[2,1,6]  R828      1.8978126347064972e-01
    z[2,1,6]  R829      3.0881896615028381e-01
    z[2,1,6]  R830      -1.2726396322250366e-01
    z[2,1,6]  R831      6.1962187290191650e-02
    z[2,1,6]  R832      -2.3533812165260315e-01
    z[2,1,6]  R833      -4.7985520213842392e-02
    z[2,1,6]  R834      1.4164811372756958e-01
    z[2,1,6]  R835      2.2546948492527008e-01
    z[1,3,0]  R11       -1
    z[1,3,0]  R29       1
    z[1,3,0]  R836      -1
    z[1,3,0]  R837      1
    z[1,3,0]  R850      -1.8504685163497925e-01
    z[1,3,0]  R851      -4.1042396426200867e-01
    z[1,3,0]  R852      -3.6015835404396057e-01
    z[1,3,0]  R853      -3.9248549938201904e-01
    z[1,3,0]  R854      -5.3533172607421875e-01
    z[1,3,0]  R855      -5.1385068893432617e-01
    z[1,3,0]  R856      -0.294125497341156
    z[1,3,0]  R857      -4.9046209454536438e-01
    z[1,3,0]  R858      -1.8783503770828247e-01
    z[1,3,0]  R859      -2.4487075209617615e-01
    z[1,3,0]  R860      -3.0964162945747375e-01
    z[1,3,0]  R861      -5.7068222761154175e-01
    z[1,3,0]  R862      -4.5240543782711029e-02
    z[1,3,0]  R863      -1.3260327279567719e-01
    z[1,3,0]  R864      5.0913608074188232e-01
    z[1,3,0]  R865      4.3723034858703613e-01
    z[1,3,0]  R866      3.8654750585556030e-01
    z[1,3,0]  R867      5.7518702745437622e-01
    z[1,3,0]  R868      5.7469648122787476e-01
    z[1,3,0]  R869      2.2413673996925354e-01
    z[1,3,0]  R870      -7.6443636417388916e-01
    z[1,3,0]  R871      -6.9400042295455933e-01
    z[1,3,0]  R872      -8.3020389080047607e-01
    z[1,3,0]  R873      -3.9931410551071167e-01
    z[1,3,0]  R874      -7.2825539112091064e-01
    z[1,3,0]  R875      -7.0837658643722534e-01
    z[1,3,0]  R876      -3.4922859072685242e-01
    z[1,3,0]  R877      1.9114144146442413e-01
    z[1,3,0]  R878      3.2021217048168182e-02
    z[1,3,0]  R879      -3.1742650270462036e-01
    z[1,3,0]  R880      -6.5962892770767212e-01
    z[1,3,0]  R881      -4.2270287871360779e-01
    z[1,3,0]  R882      -7.2531211376190186e-01
    z[1,3,0]  R883      -5.7918995618820190e-01
    z[1,3,0]  R884      -7.6002550125122070e-01
    z[1,3,0]  R885      -1.7553168535232544e-01
    z[1,3,0]  R886      -7.1153730154037476e-01
    z[1,3,0]  R887      -4.8035293817520142e-01
    z[1,3,0]  R888      -3.8778927922248840e-01
    z[1,3,0]  R889      -3.6483600735664368e-02
    z[1,3,0]  R890      -8.2963532209396362e-01
    z[1,3,0]  R891      -6.8737351894378662e-01
    z[1,3,0]  R892      -7.1367490291595459e-01
    z[1,3,0]  R893      -2.0795506238937378e-01
    z[1,3,0]  R894      -3.9442569017410278e-01
    z[1,3,0]  R895      -2.4038979411125183e-01
    z[1,3,0]  R896      3.4578088670969009e-02
    z[1,3,0]  R897      -1.9409339129924774e-01
    z[1,3,0]  R898      -1.0027784854173660e-01
    z[1,3,0]  R899      7.5281602330505848e-03
    z[1,3,0]  R900      -7.5817912817001343e-01
    z[1,3,0]  R901      -0.585847795009613
    z[1,3,0]  R902      -1.7512808740139008e-01
    z[1,3,0]  R903      5.4685866832733154e-01
    z[1,3,0]  R904      5.0207936763763428e-01
    z[1,3,0]  R905      -3.2939542084932327e-02
    z[1,3,0]  R906      -1.2607021629810333e-01
    z[1,3,0]  R907      8.6718820035457611e-02
    z[1,3,0]  R908      -3.6362364888191223e-01
    z[1,3,0]  R909      4.5727172493934631e-01
    z[1,3,0]  R910      -7.9709625244140625e-01
    z[1,3,0]  R911      1.0934278368949890e-01
    z[1,3,0]  R912      -1.5613633394241333e-01
    z[1,3,0]  R913      6.6998727619647980e-02
    z[1,3,0]  R914      -2.7986937761306763e-01
    z[1,3,0]  R915      2.3405288159847260e-01
    z[1,3,0]  R916      -1.4988117851316929e-02
    z[1,3,0]  R917      0.00427770521491766
    z[1,3,0]  R918      2.8082564473152161e-01
    z[1,3,0]  R919      4.0474772453308105e-01
    z[1,3,0]  R920      -0.840641438961029
    z[1,3,0]  R921      -5.1673197746276855e-01
    z[1,3,0]  R922      4.7091841697692871e-01
    z[1,3,0]  R923      -2.8321981430053711e-01
    z[1,3,0]  R924      1.2995104491710663e-01
    z[1,3,0]  R925      1.8130710721015930e-01
    z[1,3,0]  R926      3.1230497360229492e-01
    z[1,3,0]  R927      1.9165314733982086e-01
    z[1,3,0]  R928      1.5388001501560211e-01
    z[1,3,0]  R929      5.1341748237609863e-01
    z[1,3,0]  R930      -4.3774202822532970e-06
    z[1,3,0]  R931      -5.0196421146392822e-01
    z[1,3,0]  R932      9.2960394918918610e-02
    z[1,3,0]  R933      -5.4913395643234253e-01
    z[1,3,0]  R934      -4.6438139677047729e-01
    z[1,3,0]  R935      -3.6235442757606506e-01
    z[1,3,0]  R936      1.7734211683273315e-01
    z[1,3,0]  R937      1.1243292689323425e-01
    z[1,3,0]  R938      -5.2351492643356323e-01
    z[1,3,0]  R939      3.2991003245115280e-03
    z[1,3,0]  R940      3.1800916790962219e-01
    z[1,3,0]  R941      3.3361810445785522e-01
    z[1,3,0]  R942      3.0185526609420776e-01
    z[1,3,0]  R943      3.6144572496414185e-01
    z[1,3,0]  R944      1.7125104367733002e-01
    z[1,3,1]  R12       -1
    z[1,3,1]  R30       1
    z[1,3,1]  R838      -1
    z[1,3,1]  R839      1
    z[1,3,1]  R850      -1.7523691058158875e-01
    z[1,3,1]  R851      -1.6719432175159454e-01
    z[1,3,1]  R852      3.8764795660972595e-01
    z[1,3,1]  R853      -6.0433227568864822e-02
    z[1,3,1]  R854      -6.9771325588226318e-01
    z[1,3,1]  R855      -2.4238368868827820e-01
    z[1,3,1]  R856      4.1101232171058655e-01
    z[1,3,1]  R857      -3.6673498153686523e-01
    z[1,3,1]  R858      5.7936519384384155e-01
    z[1,3,1]  R859      2.9406782984733582e-01
    z[1,3,1]  R860      -4.9336525797843933e-01
    z[1,3,1]  R861      2.2819752991199493e-01
    z[1,3,1]  R862      -5.3672146797180176e-01
    z[1,3,1]  R863      -8.8703013956546783e-02
    z[1,3,1]  R864      -3.6340686678886414e-01
    z[1,3,1]  R865      -7.6629793643951416e-01
    z[1,3,1]  R866      -1.9543415307998657e-01
    z[1,3,1]  R867      -5.2890110015869141e-01
    z[1,3,1]  R868      -4.1696822643280029e-01
    z[1,3,1]  R869      -4.6006512641906738e-01
    z[1,3,1]  R870      -0.0542781837284565
    z[1,3,1]  R871      2.6327449083328247e-01
    z[1,3,1]  R872      -9.6835397183895111e-02
    z[1,3,1]  R873      3.1895977258682251e-01
    z[1,3,1]  R874      -1.4942237176001072e-02
    z[1,3,1]  R875      1.4007595181465149e-01
    z[1,3,1]  R876      3.7733522057533264e-01
    z[1,3,1]  R877      2.2731362283229828e-01
    z[1,3,1]  R878      0.656013011932373
    z[1,3,1]  R879      -1.2028472125530243e-01
    z[1,3,1]  R880      -2.0583732426166534e-01
    z[1,3,1]  R881      0.0802420824766159
    z[1,3,1]  R882      0.226536363363266
    z[1,3,1]  R883      -7.4536859989166260e-02
    z[1,3,1]  R884      -7.2944097220897675e-02
    z[1,3,1]  R885      5.7489979267120361e-01
    z[1,3,1]  R886      -0.541951596736908
    z[1,3,1]  R887      -7.5490123033523560e-01
    z[1,3,1]  R888      6.7670869827270508e-01
    z[1,3,1]  R889      -6.3960880041122437e-01
    z[1,3,1]  R890      -3.2839035987854004e-01
    z[1,3,1]  R891      1.5256562270224094e-02
    z[1,3,1]  R892      -2.3919717967510223e-01
    z[1,3,1]  R893      6.7518049478530884e-01
    z[1,3,1]  R894      -6.7618393898010254e-01
    z[1,3,1]  R895      1.4976819977164268e-02
    z[1,3,1]  R896      9.9239133298397064e-02
    z[1,3,1]  R897      5.8465201407670975e-02
    z[1,3,1]  R898      -3.6602858453989029e-02
    z[1,3,1]  R899      -3.7773722410202026e-01
    z[1,3,1]  R900      -2.3643411695957184e-01
    z[1,3,1]  R901      3.9748489856719971e-01
    z[1,3,1]  R902      -0.0962492972612381
    z[1,3,1]  R903      -7.2016052901744843e-02
    z[1,3,1]  R904      -7.8580141067504883e-01
    z[1,3,1]  R905      -7.4929273128509521e-01
    z[1,3,1]  R906      5.3999584913253784e-01
    z[1,3,1]  R907      -0.459747314453125
    z[1,3,1]  R908      -5.8260124921798706e-01
    z[1,3,1]  R909      1.2367238849401474e-01
    z[1,3,1]  R910      -4.4082650542259216e-01
    z[1,3,1]  R911      -1.9293196499347687e-01
    z[1,3,1]  R912      1.0183781385421753e-02
    z[1,3,1]  R913      -8.0275171995162964e-01
    z[1,3,1]  R914      -7.8943598270416260e-01
    z[1,3,1]  R915      2.6834788918495178e-01
    z[1,3,1]  R916      -6.6552299261093140e-01
    z[1,3,1]  R917      -6.2895292043685913e-01
    z[1,3,1]  R918      -1.6427399218082428e-01
    z[1,3,1]  R919      -7.1306502819061279e-01
    z[1,3,1]  R920      -1.2277639657258987e-01
    z[1,3,1]  R921      5.0446885824203491e-01
    z[1,3,1]  R922      6.5233653783798218e-01
    z[1,3,1]  R923      -7.5898337364196777e-01
    z[1,3,1]  R924      -1.4968656003475189e-01
    z[1,3,1]  R925      3.3593121170997620e-01
    z[1,3,1]  R926      -0.62202388048172
    z[1,3,1]  R927      -8.9839559793472290e-01
    z[1,3,1]  R928      -3.7316444516181946e-01
    z[1,3,1]  R929      -7.5438439846038818e-01
    z[1,3,1]  R930      1.1947839707136154e-01
    z[1,3,1]  R931      -0.65839684009552
    z[1,3,1]  R932      -0.691955029964447
    z[1,3,1]  R933      -5.5208396911621094e-01
    z[1,3,1]  R934      -0.626633882522583
    z[1,3,1]  R935      -4.1933557391166687e-01
    z[1,3,1]  R936      0.064608134329319
    z[1,3,1]  R937      -3.9330857992172241e-01
    z[1,3,1]  R938      -0.666795015335083
    z[1,3,1]  R939      -4.9973803758621216e-01
    z[1,3,1]  R940      0.822810173034668
    z[1,3,1]  R941      6.9742277264595032e-02
    z[1,3,1]  R942      4.6270421147346497e-01
    z[1,3,1]  R943      -0.0831177830696106
    z[1,3,1]  R944      -5.0423705577850342e-01
    z[1,3,2]  R13       -1
    z[1,3,2]  R31       1
    z[1,3,2]  R840      -1
    z[1,3,2]  R841      1
    z[1,3,2]  R850      -7.0025521516799927e-01
    z[1,3,2]  R851      -7.6836895942687988e-01
    z[1,3,2]  R852      -0.0929165631532669
    z[1,3,2]  R853      -4.3553096055984497e-01
    z[1,3,2]  R854      1.8740169703960419e-01
    z[1,3,2]  R855      -3.3837187290191650e-01
    z[1,3,2]  R856      -7.1238033473491669e-02
    z[1,3,2]  R857      -5.3833943605422974e-01
    z[1,3,2]  R858      -5.2186346054077148e-01
    z[1,3,2]  R859      -8.6485099792480469e-01
    z[1,3,2]  R860      -3.9744108915328979e-01
    z[1,3,2]  R861      1.5725603699684143e-01
    z[1,3,2]  R862      2.7716800570487976e-01
    z[1,3,2]  R863      -3.1933054327964783e-01
    z[1,3,2]  R864      3.9546927809715271e-01
    z[1,3,2]  R865      -1.5717601776123047e-01
    z[1,3,2]  R866      3.7255945801734924e-01
    z[1,3,2]  R867      5.3710758686065674e-01
    z[1,3,2]  R868      4.6185827255249023e-01
    z[1,3,2]  R869      6.3423448801040649e-01
    z[1,3,2]  R870      -2.0403549075126648e-01
    z[1,3,2]  R871      -2.6846387982368469e-01
    z[1,3,2]  R872      -9.0720631182193756e-02
    z[1,3,2]  R873      -2.8542402386665344e-01
    z[1,3,2]  R874      -1.1157270520925522e-01
    z[1,3,2]  R875      1.3022735714912415e-01
    z[1,3,2]  R876      -1.3916942477226257e-01
    z[1,3,2]  R877      2.6455676555633545e-01
    z[1,3,2]  R878      -4.4667381048202515e-01
    z[1,3,2]  R879      4.6143519878387451e-01
    z[1,3,2]  R880      -4.1570979356765747e-01
    z[1,3,2]  R881      -0.739593505859375
    z[1,3,2]  R882      -3.4730136394500732e-01
    z[1,3,2]  R883      -2.1545560657978058e-01
    z[1,3,2]  R884      -1.1575036495923996e-01
    z[1,3,2]  R885      -4.0366676449775696e-01
    z[1,3,2]  R886      -3.9089929312467575e-02
    z[1,3,2]  R887      -3.6604872345924377e-01
    z[1,3,2]  R888      -5.3441685438156128e-01
    z[1,3,2]  R889      -1.4731751382350922e-01
    z[1,3,2]  R890      6.4919173717498779e-02
    z[1,3,2]  R891      -4.3855801224708557e-01
    z[1,3,2]  R892      7.6549343764781952e-02
    z[1,3,2]  R893      -4.3491214513778687e-01
    z[1,3,2]  R894      -2.6849663257598877e-01
    z[1,3,2]  R895      2.1794764697551727e-01
    z[1,3,2]  R896      4.1993027925491333e-01
    z[1,3,2]  R897      -2.7109694480895996e-01
    z[1,3,2]  R898      2.2073593735694885e-01
    z[1,3,2]  R899      4.9149698019027710e-01
    z[1,3,2]  R900      -0.0428561195731163
    z[1,3,2]  R901      -5.2748352289199829e-01
    z[1,3,2]  R902      2.3536044359207153e-01
    z[1,3,2]  R903      -1.1757723242044449e-01
    z[1,3,2]  R904      2.0246763527393341e-01
    z[1,3,2]  R905      3.1087455153465271e-01
    z[1,3,2]  R906      7.8904800117015839e-02
    z[1,3,2]  R907      -2.2650142014026642e-01
    z[1,3,2]  R908      6.4786237478256226e-01
    z[1,3,2]  R909      -0.54561448097229
    z[1,3,2]  R910      -0.0861566811800003
    z[1,3,2]  R911      -1.2679979205131531e-01
    z[1,3,2]  R912      -5.7672321796417236e-01
    z[1,3,2]  R913      1.9212525337934494e-02
    z[1,3,2]  R914      3.5149121284484863e-01
    z[1,3,2]  R915      -2.0834234356880188e-01
    z[1,3,2]  R916      1.1803038418292999e-01
    z[1,3,2]  R917      -1.1426251381635666e-01
    z[1,3,2]  R918      -3.3169126510620117e-01
    z[1,3,2]  R919      -5.3151518106460571e-02
    z[1,3,2]  R920      -3.6207896471023560e-01
    z[1,3,2]  R921      -1.8947304785251617e-01
    z[1,3,2]  R922      -3.4503698348999023e-01
    z[1,3,2]  R923      1.6016542911529541e-01
    z[1,3,2]  R924      -2.2463127970695496e-01
    z[1,3,2]  R925      -2.0017072558403015e-01
    z[1,3,2]  R926      0.338600754737854
    z[1,3,2]  R927      -8.5146024823188782e-02
    z[1,3,2]  R928      -8.3877243101596832e-02
    z[1,3,2]  R929      -1.3389788568019867e-01
    z[1,3,2]  R930      -5.0464099645614624e-01
    z[1,3,2]  R931      -4.3756082653999329e-01
    z[1,3,2]  R932      -4.2218956351280212e-01
    z[1,3,2]  R933      -3.9870855212211609e-01
    z[1,3,2]  R934      -2.4444781243801117e-01
    z[1,3,2]  R935      -7.1697455644607544e-01
    z[1,3,2]  R936      -4.2742338031530380e-02
    z[1,3,2]  R937      2.9280850291252136e-01
    z[1,3,2]  R938      -3.2561093568801880e-01
    z[1,3,2]  R939      7.9545283317565918e-01
    z[1,3,2]  R940      3.1671860814094543e-01
    z[1,3,2]  R941      1.6957861185073853e-01
    z[1,3,2]  R942      3.2461118698120117e-01
    z[1,3,2]  R943      2.1251462399959564e-01
    z[1,3,2]  R944      4.9290871247649193e-03
    z[1,3,3]  R14       -1
    z[1,3,3]  R32       1
    z[1,3,3]  R842      -1
    z[1,3,3]  R843      1
    z[1,3,3]  R850      3.6499090492725372e-02
    z[1,3,3]  R851      4.2380407452583313e-01
    z[1,3,3]  R852      5.0820440053939819e-01
    z[1,3,3]  R853      6.3960433006286621e-01
    z[1,3,3]  R854      3.3650997281074524e-01
    z[1,3,3]  R855      1.9221606850624084e-01
    z[1,3,3]  R856      2.6353740692138672e-01
    z[1,3,3]  R857      2.3746763169765472e-01
    z[1,3,3]  R858      5.3477507829666138e-01
    z[1,3,3]  R859      1.0930994898080826e-01
    z[1,3,3]  R860      -4.6457889676094055e-01
    z[1,3,3]  R861      5.0418758392333984e-01
    z[1,3,3]  R862      -4.6074721217155457e-01
    z[1,3,3]  R863      -3.0038896203041077e-01
    z[1,3,3]  R864      3.4020888805389404e-01
    z[1,3,3]  R865      -3.1392174959182739e-01
    z[1,3,3]  R866      1.8635661900043488e-01
    z[1,3,3]  R867      0.0696042999625206
    z[1,3,3]  R868      3.8880702853202820e-01
    z[1,3,3]  R869      2.0800997316837311e-01
    z[1,3,3]  R870      4.0330576896667480e-01
    z[1,3,3]  R871      1.7856582999229431e-02
    z[1,3,3]  R872      1.0562287271022797e-01
    z[1,3,3]  R873      5.0042307376861572e-01
    z[1,3,3]  R874      -1.2341390550136566e-01
    z[1,3,3]  R875      4.5411249995231628e-01
    z[1,3,3]  R876      -4.3373328447341919e-01
    z[1,3,3]  R877      -7.0228505134582520e-01
    z[1,3,3]  R878      2.5343433022499084e-02
    z[1,3,3]  R879      -0.541547417640686
    z[1,3,3]  R880      -2.4376621469855309e-02
    z[1,3,3]  R881      4.8547735810279846e-01
    z[1,3,3]  R882      5.0373876094818115e-01
    z[1,3,3]  R883      2.6542711257934570e-01
    z[1,3,3]  R884      5.8216649293899536e-01
    z[1,3,3]  R885      7.7554568648338318e-02
    z[1,3,3]  R886      1.7386291921138763e-01
    z[1,3,3]  R887      1.5898482874035835e-02
    z[1,3,3]  R888      2.1585205197334290e-01
    z[1,3,3]  R889      -5.3929954767227173e-01
    z[1,3,3]  R890      2.8598424792289734e-01
    z[1,3,3]  R891      5.7795327156782150e-02
    z[1,3,3]  R892      5.7174623012542725e-01
    z[1,3,3]  R893      -3.3884122967720032e-01
    z[1,3,3]  R894      2.6786521077156067e-01
    z[1,3,3]  R895      -4.5454555749893188e-01
    z[1,3,3]  R896      -0.686290979385376
    z[1,3,3]  R897      -6.2507015466690063e-01
    z[1,3,3]  R898      -7.8475004434585571e-01
    z[1,3,3]  R899      -6.1852329969406128e-01
    z[1,3,3]  R900      5.2582442760467529e-01
    z[1,3,3]  R901      -6.0382641851902008e-02
    z[1,3,3]  R902      -7.2278821468353271e-01
    z[1,3,3]  R903      -5.0711852312088013e-01
    z[1,3,3]  R904      1.3981281220912933e-01
    z[1,3,3]  R905      -3.8838258385658264e-01
    z[1,3,3]  R906      -4.6801382303237915e-01
    z[1,3,3]  R907      -1.5272186696529388e-01
    z[1,3,3]  R908      -1.5562401711940765e-01
    z[1,3,3]  R909      -3.8897407054901123e-01
    z[1,3,3]  R910      3.3179691433906555e-01
    z[1,3,3]  R911      -7.4050635099411011e-01
    z[1,3,3]  R912      -7.1543955802917480e-01
    z[1,3,3]  R913      -1.6899734735488892e-01
    z[1,3,3]  R914      -2.9901450872421265e-01
    z[1,3,3]  R915      -6.2989783287048340e-01
    z[1,3,3]  R916      -3.0583354830741882e-01
    z[1,3,3]  R917      -9.0693213045597076e-02
    z[1,3,3]  R918      -3.6551168560981750e-01
    z[1,3,3]  R919      -2.0487499237060547e-01
    z[1,3,3]  R920      2.2473834455013275e-01
    z[1,3,3]  R921      3.9176097512245178e-01
    z[1,3,3]  R922      3.1831261515617371e-01
    z[1,3,3]  R923      -3.2946917414665222e-01
    z[1,3,3]  R924      -7.1472346782684326e-01
    z[1,3,3]  R925      -5.3426802158355713e-01
    z[1,3,3]  R926      9.2764936387538910e-02
    z[1,3,3]  R927      3.5665526986122131e-01
    z[1,3,3]  R928      -1.0075378417968750e-01
    z[1,3,3]  R929      6.7626923322677612e-02
    z[1,3,3]  R930      5.6319665908813477e-01
    z[1,3,3]  R931      -1.0369183868169785e-01
    z[1,3,3]  R932      -5.2761048078536987e-01
    z[1,3,3]  R933      -4.3900772929191589e-02
    z[1,3,3]  R934      1.8475079536437988e-01
    z[1,3,3]  R935      3.5118627548217773e-01
    z[1,3,3]  R936      3.1219440698623657e-01
    z[1,3,3]  R937      -2.4333126842975616e-01
    z[1,3,3]  R938      7.5939163565635681e-02
    z[1,3,3]  R939      -1.5298357605934143e-01
    z[1,3,3]  R940      7.3067627847194672e-02
    z[1,3,3]  R941      5.9623247385025024e-01
    z[1,3,3]  R942      -4.7412705421447754e-01
    z[1,3,3]  R943      -0.594360888004303
    z[1,3,3]  R944      -2.1659563481807709e-01
    z[1,3,4]  R15       -1
    z[1,3,4]  R33       1
    z[1,3,4]  R844      -1
    z[1,3,4]  R845      1
    z[1,3,4]  R850      -6.5206247568130493e-01
    z[1,3,4]  R851      -1.2586151063442230e-01
    z[1,3,4]  R852      -3.7285369634628296e-01
    z[1,3,4]  R853      2.2079035639762878e-01
    z[1,3,4]  R854      -4.1671305894851685e-02
    z[1,3,4]  R855      -3.0649396777153015e-01
    z[1,3,4]  R856      -7.3452973365783691e-01
    z[1,3,4]  R857      2.4466475844383240e-01
    z[1,3,4]  R858      7.3377601802349091e-02
    z[1,3,4]  R859      1.7693807184696198e-01
    z[1,3,4]  R860      4.6062642335891724e-01
    z[1,3,4]  R861      -1.2591026723384857e-01
    z[1,3,4]  R862      3.6756515502929688e-01
    z[1,3,4]  R863      0.665052592754364
    z[1,3,4]  R864      2.8749847412109375e-01
    z[1,3,4]  R865      -3.1212879344820976e-02
    z[1,3,4]  R866      -3.7841506302356720e-02
    z[1,3,4]  R867      0.0452711246907711
    z[1,3,4]  R868      0.0777883306145668
    z[1,3,4]  R869      1.3398057222366333e-01
    z[1,3,4]  R870      2.4681188166141510e-01
    z[1,3,4]  R871      -0.088363416492939
    z[1,3,4]  R872      4.5156961679458618e-01
    z[1,3,4]  R873      8.8034041225910187e-02
    z[1,3,4]  R874      -6.2480556964874268e-01
    z[1,3,4]  R875      1.5076331794261932e-01
    z[1,3,4]  R876      -6.4340668916702271e-01
    z[1,3,4]  R877      5.3378814458847046e-01
    z[1,3,4]  R878      -0.409236341714859
    z[1,3,4]  R879      5.5659556388854980e-01
    z[1,3,4]  R880      -3.8463276624679565e-01
    z[1,3,4]  R881      9.5938645303249359e-02
    z[1,3,4]  R882      -6.6198281943798065e-02
    z[1,3,4]  R883      -3.8781216740608215e-01
    z[1,3,4]  R884      -1.2392628192901611e-01
    z[1,3,4]  R885      -3.0565986037254333e-01
    z[1,3,4]  R886      -1.7183527350425720e-01
    z[1,3,4]  R887      1.3652063906192780e-01
    z[1,3,4]  R888      0.0509721003472805
    z[1,3,4]  R889      5.2445590496063232e-01
    z[1,3,4]  R890      2.2199855744838715e-01
    z[1,3,4]  R891      4.9800035357475281e-01
    z[1,3,4]  R892      -1.5305636823177338e-01
    z[1,3,4]  R893      -4.0015062689781189e-01
    z[1,3,4]  R894      -6.5390810370445251e-02
    z[1,3,4]  R895      7.4854081869125366e-01
    z[1,3,4]  R896      4.7155517339706421e-01
    z[1,3,4]  R897      4.6287944912910461e-01
    z[1,3,4]  R898      0.389067679643631
    z[1,3,4]  R899      4.6220120787620544e-01
    z[1,3,4]  R900      -7.2527617216110229e-02
    z[1,3,4]  R901      -4.4467210769653320e-01
    z[1,3,4]  R902      5.6296974420547485e-01
    z[1,3,4]  R903      0.647429883480072
    z[1,3,4]  R904      5.5801492184400558e-02
    z[1,3,4]  R905      -1.7731563746929169e-01
    z[1,3,4]  R906      4.2421564459800720e-01
    z[1,3,4]  R907      1.9498154520988464e-01
    z[1,3,4]  R908      2.2781883180141449e-01
    z[1,3,4]  R909      3.9964246749877930e-01
    z[1,3,4]  R910      3.9224009960889816e-02
    z[1,3,4]  R911      5.6126755475997925e-01
    z[1,3,4]  R912      -3.1642830371856689e-01
    z[1,3,4]  R913      -6.5407925285398960e-03
    z[1,3,4]  R914      1.5727029740810394e-01
    z[1,3,4]  R915      6.1651289463043213e-01
    z[1,3,4]  R916      1.0274988412857056e-01
    z[1,3,4]  R917      1.2560781836509705e-01
    z[1,3,4]  R918      6.3737088441848755e-01
    z[1,3,4]  R919      1.9057793915271759e-01
    z[1,3,4]  R920      7.5338676571846008e-02
    z[1,3,4]  R921      -4.2842742800712585e-01
    z[1,3,4]  R922      -3.0310210585594177e-01
    z[1,3,4]  R923      2.1609136462211609e-01
    z[1,3,4]  R924      2.2000500559806824e-01
    z[1,3,4]  R925      4.0507584810256958e-01
    z[1,3,4]  R926      1.6546308994293213e-01
    z[1,3,4]  R927      -1.2892046570777893e-01
    z[1,3,4]  R928      2.7788332104682922e-01
    z[1,3,4]  R929      -2.9304352402687073e-01
    z[1,3,4]  R930      1.7180059850215912e-01
    z[1,3,4]  R931      -0.290390282869339
    z[1,3,4]  R932      -1.2788760662078857e-01
    z[1,3,4]  R933      3.1648221611976624e-01
    z[1,3,4]  R934      2.4286733940243721e-02
    z[1,3,4]  R935      -1.8562752008438110e-01
    z[1,3,4]  R936      -8.5928475856781006e-01
    z[1,3,4]  R937      3.1024357676506042e-01
    z[1,3,4]  R938      -3.6562168598175049e-01
    z[1,3,4]  R939      -1.3181759975850582e-02
    z[1,3,4]  R940      2.3730356991291046e-01
    z[1,3,4]  R941      4.6288302540779114e-01
    z[1,3,4]  R942      -1.7594926059246063e-01
    z[1,3,4]  R943      2.8487956523895264e-01
    z[1,3,4]  R944      5.3741383552551270e-01
    z[1,3,5]  R16       -1
    z[1,3,5]  R34       1
    z[1,3,5]  R846      -1
    z[1,3,5]  R847      1
    z[1,3,5]  R850      3.2446511089801788e-02
    z[1,3,5]  R851      -6.5567381680011749e-02
    z[1,3,5]  R852      -0.365255743265152
    z[1,3,5]  R853      -3.6753949522972107e-01
    z[1,3,5]  R854      -2.3557227849960327e-01
    z[1,3,5]  R855      -0.622138261795044
    z[1,3,5]  R856      -3.6611225455999374e-02
    z[1,3,5]  R857      -5.2739516831934452e-03
    z[1,3,5]  R858      -2.3253858089447021e-01
    z[1,3,5]  R859      -2.0286414027214050e-01
    z[1,3,5]  R860      -1.3849419355392456e-01
    z[1,3,5]  R861      5.6229633092880249e-01
    z[1,3,5]  R862      3.6926373839378357e-01
    z[1,3,5]  R863      4.5246917009353638e-01
    z[1,3,5]  R864      -5.0347644090652466e-01
    z[1,3,5]  R865      -3.1183698773384094e-01
    z[1,3,5]  R866      -7.9829913377761841e-01
    z[1,3,5]  R867      -2.9537272453308105e-01
    z[1,3,5]  R868      -2.8188723325729370e-01
    z[1,3,5]  R869      -4.9727156758308411e-01
    z[1,3,5]  R870      -3.7695422768592834e-01
    z[1,3,5]  R871      -4.3837973475456238e-01
    z[1,3,5]  R872      3.8149955216795206e-03
    z[1,3,5]  R873      -6.0314124822616577e-01
    z[1,3,5]  R874      -7.2073573246598244e-03
    z[1,3,5]  R875      4.4679322838783264e-01
    z[1,3,5]  R876      3.0278950929641724e-01
    z[1,3,5]  R877      2.2949904203414917e-02
    z[1,3,5]  R878      -2.5269734859466553e-01
    z[1,3,5]  R879      6.4644269645214081e-02
    z[1,3,5]  R880      -2.2468364238739014e-01
    z[1,3,5]  R881      -6.4025238156318665e-02
    z[1,3,5]  R882      1.6272965073585510e-01
    z[1,3,5]  R883      6.2386733293533325e-01
    z[1,3,5]  R884      1.6510689258575439e-01
    z[1,3,5]  R885      4.6994745731353760e-01
    z[1,3,5]  R886      2.7037739753723145e-01
    z[1,3,5]  R887      2.1190980076789856e-01
    z[1,3,5]  R888      2.1083962917327881e-01
    z[1,3,5]  R889      4.1137434542179108e-02
    z[1,3,5]  R890      -1.3605177402496338e-01
    z[1,3,5]  R891      2.8889194130897522e-01
    z[1,3,5]  R892      -1.4131484925746918e-01
    z[1,3,5]  R893      -1.2616080045700073e-01
    z[1,3,5]  R894      -2.4881792068481445e-01
    z[1,3,5]  R895      3.5429760813713074e-01
    z[1,3,5]  R896      2.5861939787864685e-01
    z[1,3,5]  R897      4.7179350256919861e-01
    z[1,3,5]  R898      -2.3139877617359161e-01
    z[1,3,5]  R899      -9.0957731008529663e-02
    z[1,3,5]  R900      -2.6501569151878357e-01
    z[1,3,5]  R901      1.3838236033916473e-01
    z[1,3,5]  R902      -1.9547903910279274e-02
    z[1,3,5]  R903      7.4831224977970123e-02
    z[1,3,5]  R904      -2.5719344615936279e-01
    z[1,3,5]  R905      -2.8230378031730652e-01
    z[1,3,5]  R906      5.3210198879241943e-01
    z[1,3,5]  R907      -0.801838755607605
    z[1,3,5]  R908      1.8001425266265869e-01
    z[1,3,5]  R909      3.5701093077659607e-01
    z[1,3,5]  R910      -1.5142035484313965e-01
    z[1,3,5]  R911      -1.2355160713195801e-01
    z[1,3,5]  R912      2.4428399279713631e-02
    z[1,3,5]  R913      -4.5424187183380127e-01
    z[1,3,5]  R914      -2.0846258103847504e-01
    z[1,3,5]  R915      -7.1001998148858547e-03
    z[1,3,5]  R916      -6.4996105432510376e-01
    z[1,3,5]  R917      -7.5318956375122070e-01
    z[1,3,5]  R918      4.7404772043228149e-01
    z[1,3,5]  R919      -4.9066326022148132e-01
    z[1,3,5]  R920      -1.1694166809320450e-01
    z[1,3,5]  R921      -0.314789742231369
    z[1,3,5]  R922      -6.6570803523063660e-02
    z[1,3,5]  R923      2.5973695516586304e-01
    z[1,3,5]  R924      5.7863587141036987e-01
    z[1,3,5]  R925      6.0070103406906128e-01
    z[1,3,5]  R926      -5.5635792016983032e-01
    z[1,3,5]  R927      -5.2710570394992828e-02
    z[1,3,5]  R928      8.5005831718444824e-01
    z[1,3,5]  R929      8.9964523911476135e-02
    z[1,3,5]  R930      -6.1394846439361572e-01
    z[1,3,5]  R931      2.0823361352086067e-02
    z[1,3,5]  R932      -1.9786822795867920e-01
    z[1,3,5]  R933      -3.6314314603805542e-01
    z[1,3,5]  R934      -3.8083171844482422e-01
    z[1,3,5]  R935      1.3971579074859619e-01
    z[1,3,5]  R936      2.1009135246276855e-01
    z[1,3,5]  R937      -4.3233373761177063e-01
    z[1,3,5]  R938      -1.3284134864807129e-01
    z[1,3,5]  R939      2.7037004474550486e-03
    z[1,3,5]  R940      0.0669000968337059
    z[1,3,5]  R941      5.3333175182342529e-01
    z[1,3,5]  R942      -5.1613062620162964e-01
    z[1,3,5]  R943      3.9667895436286926e-01
    z[1,3,5]  R944      4.8298445343971252e-01
    z[1,3,6]  R17       -1
    z[1,3,6]  R35       1
    z[1,3,6]  R848      -1
    z[1,3,6]  R849      1
    z[1,3,6]  R850      1.3085016608238220e-01
    z[1,3,6]  R851      1.1600548774003983e-01
    z[1,3,6]  R852      4.2506250739097595e-01
    z[1,3,6]  R853      2.4431201815605164e-01
    z[1,3,6]  R854      -1.4500702917575836e-01
    z[1,3,6]  R855      2.1159036457538605e-01
    z[1,3,6]  R856      3.5938540101051331e-01
    z[1,3,6]  R857      -4.6782839298248291e-01
    z[1,3,6]  R858      -1.0615862160921097e-01
    z[1,3,6]  R859      -1.4555260539054871e-01
    z[1,3,6]  R860      2.3571690917015076e-01
    z[1,3,6]  R861      1.0621951520442963e-01
    z[1,3,6]  R862      3.8641107082366943e-01
    z[1,3,6]  R863      -3.6785754561424255e-01
    z[1,3,6]  R864      2.0828416571021080e-02
    z[1,3,6]  R865      -1.2216480448842049e-02
    z[1,3,6]  R866      1.1993527412414551e-02
    z[1,3,6]  R867      8.2460641860961914e-02
    z[1,3,6]  R868      2.1416340768337250e-01
    z[1,3,6]  R869      -1.6538253426551819e-01
    z[1,3,6]  R870      -7.3446303606033325e-02
    z[1,3,6]  R871      -4.2032524943351746e-01
    z[1,3,6]  R872      2.7940708398818970e-01
    z[1,3,6]  R873      -1.8813130259513855e-01
    z[1,3,6]  R874      -2.2651143372058868e-01
    z[1,3,6]  R875      -1.8179714679718018e-01
    z[1,3,6]  R876      1.5003718435764313e-01
    z[1,3,6]  R877      -2.5128149986267090e-01
    z[1,3,6]  R878      3.7031254172325134e-01
    z[1,3,6]  R879      -2.5416231155395508e-01
    z[1,3,6]  R880      -3.8818377256393433e-01
    z[1,3,6]  R881      -1.3745276629924774e-01
    z[1,3,6]  R882      -1.3179273903369904e-01
    z[1,3,6]  R883      5.0018224865198135e-02
    z[1,3,6]  R884      1.4868189394474030e-01
    z[1,3,6]  R885      3.9425730705261230e-01
    z[1,3,6]  R886      -2.5615498423576355e-01
    z[1,3,6]  R887      3.9963837713003159e-02
    z[1,3,6]  R888      1.1153426021337509e-01
    z[1,3,6]  R889      1.6635512933135033e-02
    z[1,3,6]  R890      2.2376313805580139e-01
    z[1,3,6]  R891      1.2190598063170910e-02
    z[1,3,6]  R892      -2.3938070237636566e-01
    z[1,3,6]  R893      1.4452320337295532e-01
    z[1,3,6]  R894      4.2092159390449524e-01
    z[1,3,6]  R895      -4.5116588473320007e-02
    z[1,3,6]  R896      2.2884733974933624e-01
    z[1,3,6]  R897      2.4053448438644409e-01
    z[1,3,6]  R898      3.4515008330345154e-01
    z[1,3,6]  R899      -1.0589775443077087e-01
    z[1,3,6]  R900      -1.2426482141017914e-01
    z[1,3,6]  R901      -4.4793472625315189e-03
    z[1,3,6]  R902      -2.5481733679771423e-01
    z[1,3,6]  R903      -7.5411156285554171e-04
    z[1,3,6]  R904      -2.5086278095841408e-02
    z[1,3,6]  R905      2.8081163763999939e-01
    z[1,3,6]  R906      -6.4469978213310242e-02
    z[1,3,6]  R907      -1.5975619852542877e-01
    z[1,3,6]  R908      1.0130092501640320e-02
    z[1,3,6]  R909      1.9859719276428223e-01
    z[1,3,6]  R910      -1.6831737756729126e-01
    z[1,3,6]  R911      2.3686951398849487e-01
    z[1,3,6]  R912      -1.7415709793567657e-01
    z[1,3,6]  R913      -3.4028398990631104e-01
    z[1,3,6]  R914      1.3159666955471039e-01
    z[1,3,6]  R915      -2.2998319566249847e-01
    z[1,3,6]  R916      1.2799315154552460e-01
    z[1,3,6]  R917      -6.8501620553433895e-03
    z[1,3,6]  R918      -1.3989374041557312e-01
    z[1,3,6]  R919      -0.0764738917350769
    z[1,3,6]  R920      2.7800747752189636e-01
    z[1,3,6]  R921      8.0497294664382935e-02
    z[1,3,6]  R922      1.8978126347064972e-01
    z[1,3,6]  R923      3.0881896615028381e-01
    z[1,3,6]  R924      -1.2726396322250366e-01
    z[1,3,6]  R925      6.1962187290191650e-02
    z[1,3,6]  R926      -2.3533812165260315e-01
    z[1,3,6]  R927      -4.7985520213842392e-02
    z[1,3,6]  R928      1.4164811372756958e-01
    z[1,3,6]  R929      2.2546948492527008e-01
    z[1,3,6]  R930      8.6160756647586823e-02
    z[1,3,6]  R931      1.6605402529239655e-01
    z[1,3,6]  R932      -2.0802492275834084e-02
    z[1,3,6]  R933      -2.6933647692203522e-02
    z[1,3,6]  R934      3.9008951187133789e-01
    z[1,3,6]  R935      -3.8659039884805679e-02
    z[1,3,6]  R936      2.8735810518264771e-01
    z[1,3,6]  R937      -6.3604766130447388e-01
    z[1,3,6]  R938      -1.3491220772266388e-01
    z[1,3,6]  R939      -3.0646494030952454e-01
    z[1,3,6]  R940      -2.3540496826171875e-01
    z[1,3,6]  R941      2.9689380899071693e-02
    z[1,3,6]  R942      2.5936502218246460e-01
    z[1,3,6]  R943      4.7487938404083252e-01
    z[1,3,6]  R944      3.8391733169555664e-01
    z[3,1,0]  R11       1
    z[3,1,0]  R29       -1
    z[3,1,0]  R945      -1
    z[3,1,0]  R946      1
    z[3,1,0]  R959      -4.3774202822532970e-06
    z[3,1,0]  R960      -5.0196421146392822e-01
    z[3,1,0]  R961      9.2960394918918610e-02
    z[3,1,0]  R962      -5.4913395643234253e-01
    z[3,1,0]  R963      -4.6438139677047729e-01
    z[3,1,0]  R964      -3.6235442757606506e-01
    z[3,1,0]  R965      1.7734211683273315e-01
    z[3,1,0]  R966      1.1243292689323425e-01
    z[3,1,0]  R967      -5.2351492643356323e-01
    z[3,1,0]  R968      3.2991003245115280e-03
    z[3,1,0]  R969      3.1800916790962219e-01
    z[3,1,0]  R970      3.3361810445785522e-01
    z[3,1,0]  R971      3.0185526609420776e-01
    z[3,1,0]  R972      3.6144572496414185e-01
    z[3,1,0]  R973      1.7125104367733002e-01
    z[3,1,0]  R974      -1.8504685163497925e-01
    z[3,1,0]  R975      -4.1042396426200867e-01
    z[3,1,0]  R976      -3.6015835404396057e-01
    z[3,1,0]  R977      -3.9248549938201904e-01
    z[3,1,0]  R978      -5.3533172607421875e-01
    z[3,1,0]  R979      -5.1385068893432617e-01
    z[3,1,0]  R980      -0.294125497341156
    z[3,1,0]  R981      -4.9046209454536438e-01
    z[3,1,0]  R982      -1.8783503770828247e-01
    z[3,1,0]  R983      -2.4487075209617615e-01
    z[3,1,0]  R984      -3.0964162945747375e-01
    z[3,1,0]  R985      -5.7068222761154175e-01
    z[3,1,0]  R986      -4.5240543782711029e-02
    z[3,1,0]  R987      -1.3260327279567719e-01
    z[3,1,0]  R988      5.0913608074188232e-01
    z[3,1,0]  R989      4.3723034858703613e-01
    z[3,1,0]  R990      3.8654750585556030e-01
    z[3,1,0]  R991      5.7518702745437622e-01
    z[3,1,0]  R992      5.7469648122787476e-01
    z[3,1,0]  R993      2.2413673996925354e-01
    z[3,1,0]  R994      -7.6443636417388916e-01
    z[3,1,0]  R995      -6.9400042295455933e-01
    z[3,1,0]  R996      -8.3020389080047607e-01
    z[3,1,0]  R997      -3.9931410551071167e-01
    z[3,1,0]  R998      -7.2825539112091064e-01
    z[3,1,0]  R999      -7.0837658643722534e-01
    z[3,1,0]  R1000     -3.4922859072685242e-01
    z[3,1,0]  R1001     1.9114144146442413e-01
    z[3,1,0]  R1002     3.2021217048168182e-02
    z[3,1,0]  R1003     -3.1742650270462036e-01
    z[3,1,0]  R1004     -6.5962892770767212e-01
    z[3,1,0]  R1005     -4.2270287871360779e-01
    z[3,1,0]  R1006     -7.2531211376190186e-01
    z[3,1,0]  R1007     -5.7918995618820190e-01
    z[3,1,0]  R1008     -7.6002550125122070e-01
    z[3,1,0]  R1009     -1.7553168535232544e-01
    z[3,1,0]  R1010     -7.1153730154037476e-01
    z[3,1,0]  R1011     -4.8035293817520142e-01
    z[3,1,0]  R1012     -3.8778927922248840e-01
    z[3,1,0]  R1013     -3.6483600735664368e-02
    z[3,1,0]  R1014     -8.2963532209396362e-01
    z[3,1,0]  R1015     -6.8737351894378662e-01
    z[3,1,0]  R1016     -7.1367490291595459e-01
    z[3,1,0]  R1017     -2.0795506238937378e-01
    z[3,1,0]  R1018     -3.9442569017410278e-01
    z[3,1,0]  R1019     -2.4038979411125183e-01
    z[3,1,0]  R1020     3.4578088670969009e-02
    z[3,1,0]  R1021     -1.9409339129924774e-01
    z[3,1,0]  R1022     -1.0027784854173660e-01
    z[3,1,0]  R1023     7.5281602330505848e-03
    z[3,1,0]  R1024     -7.5817912817001343e-01
    z[3,1,0]  R1025     -0.585847795009613
    z[3,1,0]  R1026     -1.7512808740139008e-01
    z[3,1,0]  R1027     5.4685866832733154e-01
    z[3,1,0]  R1028     5.0207936763763428e-01
    z[3,1,0]  R1029     -3.2939542084932327e-02
    z[3,1,0]  R1030     -1.2607021629810333e-01
    z[3,1,0]  R1031     8.6718820035457611e-02
    z[3,1,0]  R1032     -3.6362364888191223e-01
    z[3,1,0]  R1033     4.5727172493934631e-01
    z[3,1,0]  R1034     -7.9709625244140625e-01
    z[3,1,0]  R1035     1.0934278368949890e-01
    z[3,1,0]  R1036     -1.5613633394241333e-01
    z[3,1,0]  R1037     6.6998727619647980e-02
    z[3,1,0]  R1038     -2.7986937761306763e-01
    z[3,1,0]  R1039     2.3405288159847260e-01
    z[3,1,0]  R1040     -1.4988117851316929e-02
    z[3,1,0]  R1041     0.00427770521491766
    z[3,1,0]  R1042     2.8082564473152161e-01
    z[3,1,0]  R1043     4.0474772453308105e-01
    z[3,1,0]  R1044     -0.840641438961029
    z[3,1,0]  R1045     -5.1673197746276855e-01
    z[3,1,0]  R1046     4.7091841697692871e-01
    z[3,1,0]  R1047     -2.8321981430053711e-01
    z[3,1,0]  R1048     1.2995104491710663e-01
    z[3,1,0]  R1049     1.8130710721015930e-01
    z[3,1,0]  R1050     3.1230497360229492e-01
    z[3,1,0]  R1051     1.9165314733982086e-01
    z[3,1,0]  R1052     1.5388001501560211e-01
    z[3,1,0]  R1053     5.1341748237609863e-01
    z[3,1,1]  R12       1
    z[3,1,1]  R30       -1
    z[3,1,1]  R947      -1
    z[3,1,1]  R948      1
    z[3,1,1]  R959      1.1947839707136154e-01
    z[3,1,1]  R960      -0.65839684009552
    z[3,1,1]  R961      -0.691955029964447
    z[3,1,1]  R962      -5.5208396911621094e-01
    z[3,1,1]  R963      -0.626633882522583
    z[3,1,1]  R964      -4.1933557391166687e-01
    z[3,1,1]  R965      0.064608134329319
    z[3,1,1]  R966      -3.9330857992172241e-01
    z[3,1,1]  R967      -0.666795015335083
    z[3,1,1]  R968      -4.9973803758621216e-01
    z[3,1,1]  R969      0.822810173034668
    z[3,1,1]  R970      6.9742277264595032e-02
    z[3,1,1]  R971      4.6270421147346497e-01
    z[3,1,1]  R972      -0.0831177830696106
    z[3,1,1]  R973      -5.0423705577850342e-01
    z[3,1,1]  R974      -1.7523691058158875e-01
    z[3,1,1]  R975      -1.6719432175159454e-01
    z[3,1,1]  R976      3.8764795660972595e-01
    z[3,1,1]  R977      -6.0433227568864822e-02
    z[3,1,1]  R978      -6.9771325588226318e-01
    z[3,1,1]  R979      -2.4238368868827820e-01
    z[3,1,1]  R980      4.1101232171058655e-01
    z[3,1,1]  R981      -3.6673498153686523e-01
    z[3,1,1]  R982      5.7936519384384155e-01
    z[3,1,1]  R983      2.9406782984733582e-01
    z[3,1,1]  R984      -4.9336525797843933e-01
    z[3,1,1]  R985      2.2819752991199493e-01
    z[3,1,1]  R986      -5.3672146797180176e-01
    z[3,1,1]  R987      -8.8703013956546783e-02
    z[3,1,1]  R988      -3.6340686678886414e-01
    z[3,1,1]  R989      -7.6629793643951416e-01
    z[3,1,1]  R990      -1.9543415307998657e-01
    z[3,1,1]  R991      -5.2890110015869141e-01
    z[3,1,1]  R992      -4.1696822643280029e-01
    z[3,1,1]  R993      -4.6006512641906738e-01
    z[3,1,1]  R994      -0.0542781837284565
    z[3,1,1]  R995      2.6327449083328247e-01
    z[3,1,1]  R996      -9.6835397183895111e-02
    z[3,1,1]  R997      3.1895977258682251e-01
    z[3,1,1]  R998      -1.4942237176001072e-02
    z[3,1,1]  R999      1.4007595181465149e-01
    z[3,1,1]  R1000     3.7733522057533264e-01
    z[3,1,1]  R1001     2.2731362283229828e-01
    z[3,1,1]  R1002     0.656013011932373
    z[3,1,1]  R1003     -1.2028472125530243e-01
    z[3,1,1]  R1004     -2.0583732426166534e-01
    z[3,1,1]  R1005     0.0802420824766159
    z[3,1,1]  R1006     0.226536363363266
    z[3,1,1]  R1007     -7.4536859989166260e-02
    z[3,1,1]  R1008     -7.2944097220897675e-02
    z[3,1,1]  R1009     5.7489979267120361e-01
    z[3,1,1]  R1010     -0.541951596736908
    z[3,1,1]  R1011     -7.5490123033523560e-01
    z[3,1,1]  R1012     6.7670869827270508e-01
    z[3,1,1]  R1013     -6.3960880041122437e-01
    z[3,1,1]  R1014     -3.2839035987854004e-01
    z[3,1,1]  R1015     1.5256562270224094e-02
    z[3,1,1]  R1016     -2.3919717967510223e-01
    z[3,1,1]  R1017     6.7518049478530884e-01
    z[3,1,1]  R1018     -6.7618393898010254e-01
    z[3,1,1]  R1019     1.4976819977164268e-02
    z[3,1,1]  R1020     9.9239133298397064e-02
    z[3,1,1]  R1021     5.8465201407670975e-02
    z[3,1,1]  R1022     -3.6602858453989029e-02
    z[3,1,1]  R1023     -3.7773722410202026e-01
    z[3,1,1]  R1024     -2.3643411695957184e-01
    z[3,1,1]  R1025     3.9748489856719971e-01
    z[3,1,1]  R1026     -0.0962492972612381
    z[3,1,1]  R1027     -7.2016052901744843e-02
    z[3,1,1]  R1028     -7.8580141067504883e-01
    z[3,1,1]  R1029     -7.4929273128509521e-01
    z[3,1,1]  R1030     5.3999584913253784e-01
    z[3,1,1]  R1031     -0.459747314453125
    z[3,1,1]  R1032     -5.8260124921798706e-01
    z[3,1,1]  R1033     1.2367238849401474e-01
    z[3,1,1]  R1034     -4.4082650542259216e-01
    z[3,1,1]  R1035     -1.9293196499347687e-01
    z[3,1,1]  R1036     1.0183781385421753e-02
    z[3,1,1]  R1037     -8.0275171995162964e-01
    z[3,1,1]  R1038     -7.8943598270416260e-01
    z[3,1,1]  R1039     2.6834788918495178e-01
    z[3,1,1]  R1040     -6.6552299261093140e-01
    z[3,1,1]  R1041     -6.2895292043685913e-01
    z[3,1,1]  R1042     -1.6427399218082428e-01
    z[3,1,1]  R1043     -7.1306502819061279e-01
    z[3,1,1]  R1044     -1.2277639657258987e-01
    z[3,1,1]  R1045     5.0446885824203491e-01
    z[3,1,1]  R1046     6.5233653783798218e-01
    z[3,1,1]  R1047     -7.5898337364196777e-01
    z[3,1,1]  R1048     -1.4968656003475189e-01
    z[3,1,1]  R1049     3.3593121170997620e-01
    z[3,1,1]  R1050     -0.62202388048172
    z[3,1,1]  R1051     -8.9839559793472290e-01
    z[3,1,1]  R1052     -3.7316444516181946e-01
    z[3,1,1]  R1053     -7.5438439846038818e-01
    z[3,1,2]  R13       1
    z[3,1,2]  R31       -1
    z[3,1,2]  R949      -1
    z[3,1,2]  R950      1
    z[3,1,2]  R959      -5.0464099645614624e-01
    z[3,1,2]  R960      -4.3756082653999329e-01
    z[3,1,2]  R961      -4.2218956351280212e-01
    z[3,1,2]  R962      -3.9870855212211609e-01
    z[3,1,2]  R963      -2.4444781243801117e-01
    z[3,1,2]  R964      -7.1697455644607544e-01
    z[3,1,2]  R965      -4.2742338031530380e-02
    z[3,1,2]  R966      2.9280850291252136e-01
    z[3,1,2]  R967      -3.2561093568801880e-01
    z[3,1,2]  R968      7.9545283317565918e-01
    z[3,1,2]  R969      3.1671860814094543e-01
    z[3,1,2]  R970      1.6957861185073853e-01
    z[3,1,2]  R971      3.2461118698120117e-01
    z[3,1,2]  R972      2.1251462399959564e-01
    z[3,1,2]  R973      4.9290871247649193e-03
    z[3,1,2]  R974      -7.0025521516799927e-01
    z[3,1,2]  R975      -7.6836895942687988e-01
    z[3,1,2]  R976      -0.0929165631532669
    z[3,1,2]  R977      -4.3553096055984497e-01
    z[3,1,2]  R978      1.8740169703960419e-01
    z[3,1,2]  R979      -3.3837187290191650e-01
    z[3,1,2]  R980      -7.1238033473491669e-02
    z[3,1,2]  R981      -5.3833943605422974e-01
    z[3,1,2]  R982      -5.2186346054077148e-01
    z[3,1,2]  R983      -8.6485099792480469e-01
    z[3,1,2]  R984      -3.9744108915328979e-01
    z[3,1,2]  R985      1.5725603699684143e-01
    z[3,1,2]  R986      2.7716800570487976e-01
    z[3,1,2]  R987      -3.1933054327964783e-01
    z[3,1,2]  R988      3.9546927809715271e-01
    z[3,1,2]  R989      -1.5717601776123047e-01
    z[3,1,2]  R990      3.7255945801734924e-01
    z[3,1,2]  R991      5.3710758686065674e-01
    z[3,1,2]  R992      4.6185827255249023e-01
    z[3,1,2]  R993      6.3423448801040649e-01
    z[3,1,2]  R994      -2.0403549075126648e-01
    z[3,1,2]  R995      -2.6846387982368469e-01
    z[3,1,2]  R996      -9.0720631182193756e-02
    z[3,1,2]  R997      -2.8542402386665344e-01
    z[3,1,2]  R998      -1.1157270520925522e-01
    z[3,1,2]  R999      1.3022735714912415e-01
    z[3,1,2]  R1000     -1.3916942477226257e-01
    z[3,1,2]  R1001     2.6455676555633545e-01
    z[3,1,2]  R1002     -4.4667381048202515e-01
    z[3,1,2]  R1003     4.6143519878387451e-01
    z[3,1,2]  R1004     -4.1570979356765747e-01
    z[3,1,2]  R1005     -0.739593505859375
    z[3,1,2]  R1006     -3.4730136394500732e-01
    z[3,1,2]  R1007     -2.1545560657978058e-01
    z[3,1,2]  R1008     -1.1575036495923996e-01
    z[3,1,2]  R1009     -4.0366676449775696e-01
    z[3,1,2]  R1010     -3.9089929312467575e-02
    z[3,1,2]  R1011     -3.6604872345924377e-01
    z[3,1,2]  R1012     -5.3441685438156128e-01
    z[3,1,2]  R1013     -1.4731751382350922e-01
    z[3,1,2]  R1014     6.4919173717498779e-02
    z[3,1,2]  R1015     -4.3855801224708557e-01
    z[3,1,2]  R1016     7.6549343764781952e-02
    z[3,1,2]  R1017     -4.3491214513778687e-01
    z[3,1,2]  R1018     -2.6849663257598877e-01
    z[3,1,2]  R1019     2.1794764697551727e-01
    z[3,1,2]  R1020     4.1993027925491333e-01
    z[3,1,2]  R1021     -2.7109694480895996e-01
    z[3,1,2]  R1022     2.2073593735694885e-01
    z[3,1,2]  R1023     4.9149698019027710e-01
    z[3,1,2]  R1024     -0.0428561195731163
    z[3,1,2]  R1025     -5.2748352289199829e-01
    z[3,1,2]  R1026     2.3536044359207153e-01
    z[3,1,2]  R1027     -1.1757723242044449e-01
    z[3,1,2]  R1028     2.0246763527393341e-01
    z[3,1,2]  R1029     3.1087455153465271e-01
    z[3,1,2]  R1030     7.8904800117015839e-02
    z[3,1,2]  R1031     -2.2650142014026642e-01
    z[3,1,2]  R1032     6.4786237478256226e-01
    z[3,1,2]  R1033     -0.54561448097229
    z[3,1,2]  R1034     -0.0861566811800003
    z[3,1,2]  R1035     -1.2679979205131531e-01
    z[3,1,2]  R1036     -5.7672321796417236e-01
    z[3,1,2]  R1037     1.9212525337934494e-02
    z[3,1,2]  R1038     3.5149121284484863e-01
    z[3,1,2]  R1039     -2.0834234356880188e-01
    z[3,1,2]  R1040     1.1803038418292999e-01
    z[3,1,2]  R1041     -1.1426251381635666e-01
    z[3,1,2]  R1042     -3.3169126510620117e-01
    z[3,1,2]  R1043     -5.3151518106460571e-02
    z[3,1,2]  R1044     -3.6207896471023560e-01
    z[3,1,2]  R1045     -1.8947304785251617e-01
    z[3,1,2]  R1046     -3.4503698348999023e-01
    z[3,1,2]  R1047     1.6016542911529541e-01
    z[3,1,2]  R1048     -2.2463127970695496e-01
    z[3,1,2]  R1049     -2.0017072558403015e-01
    z[3,1,2]  R1050     0.338600754737854
    z[3,1,2]  R1051     -8.5146024823188782e-02
    z[3,1,2]  R1052     -8.3877243101596832e-02
    z[3,1,2]  R1053     -1.3389788568019867e-01
    z[3,1,3]  R14       1
    z[3,1,3]  R32       -1
    z[3,1,3]  R951      -1
    z[3,1,3]  R952      1
    z[3,1,3]  R959      5.6319665908813477e-01
    z[3,1,3]  R960      -1.0369183868169785e-01
    z[3,1,3]  R961      -5.2761048078536987e-01
    z[3,1,3]  R962      -4.3900772929191589e-02
    z[3,1,3]  R963      1.8475079536437988e-01
    z[3,1,3]  R964      3.5118627548217773e-01
    z[3,1,3]  R965      3.1219440698623657e-01
    z[3,1,3]  R966      -2.4333126842975616e-01
    z[3,1,3]  R967      7.5939163565635681e-02
    z[3,1,3]  R968      -1.5298357605934143e-01
    z[3,1,3]  R969      7.3067627847194672e-02
    z[3,1,3]  R970      5.9623247385025024e-01
    z[3,1,3]  R971      -4.7412705421447754e-01
    z[3,1,3]  R972      -0.594360888004303
    z[3,1,3]  R973      -2.1659563481807709e-01
    z[3,1,3]  R974      3.6499090492725372e-02
    z[3,1,3]  R975      4.2380407452583313e-01
    z[3,1,3]  R976      5.0820440053939819e-01
    z[3,1,3]  R977      6.3960433006286621e-01
    z[3,1,3]  R978      3.3650997281074524e-01
    z[3,1,3]  R979      1.9221606850624084e-01
    z[3,1,3]  R980      2.6353740692138672e-01
    z[3,1,3]  R981      2.3746763169765472e-01
    z[3,1,3]  R982      5.3477507829666138e-01
    z[3,1,3]  R983      1.0930994898080826e-01
    z[3,1,3]  R984      -4.6457889676094055e-01
    z[3,1,3]  R985      5.0418758392333984e-01
    z[3,1,3]  R986      -4.6074721217155457e-01
    z[3,1,3]  R987      -3.0038896203041077e-01
    z[3,1,3]  R988      3.4020888805389404e-01
    z[3,1,3]  R989      -3.1392174959182739e-01
    z[3,1,3]  R990      1.8635661900043488e-01
    z[3,1,3]  R991      0.0696042999625206
    z[3,1,3]  R992      3.8880702853202820e-01
    z[3,1,3]  R993      2.0800997316837311e-01
    z[3,1,3]  R994      4.0330576896667480e-01
    z[3,1,3]  R995      1.7856582999229431e-02
    z[3,1,3]  R996      1.0562287271022797e-01
    z[3,1,3]  R997      5.0042307376861572e-01
    z[3,1,3]  R998      -1.2341390550136566e-01
    z[3,1,3]  R999      4.5411249995231628e-01
    z[3,1,3]  R1000     -4.3373328447341919e-01
    z[3,1,3]  R1001     -7.0228505134582520e-01
    z[3,1,3]  R1002     2.5343433022499084e-02
    z[3,1,3]  R1003     -0.541547417640686
    z[3,1,3]  R1004     -2.4376621469855309e-02
    z[3,1,3]  R1005     4.8547735810279846e-01
    z[3,1,3]  R1006     5.0373876094818115e-01
    z[3,1,3]  R1007     2.6542711257934570e-01
    z[3,1,3]  R1008     5.8216649293899536e-01
    z[3,1,3]  R1009     7.7554568648338318e-02
    z[3,1,3]  R1010     1.7386291921138763e-01
    z[3,1,3]  R1011     1.5898482874035835e-02
    z[3,1,3]  R1012     2.1585205197334290e-01
    z[3,1,3]  R1013     -5.3929954767227173e-01
    z[3,1,3]  R1014     2.8598424792289734e-01
    z[3,1,3]  R1015     5.7795327156782150e-02
    z[3,1,3]  R1016     5.7174623012542725e-01
    z[3,1,3]  R1017     -3.3884122967720032e-01
    z[3,1,3]  R1018     2.6786521077156067e-01
    z[3,1,3]  R1019     -4.5454555749893188e-01
    z[3,1,3]  R1020     -0.686290979385376
    z[3,1,3]  R1021     -6.2507015466690063e-01
    z[3,1,3]  R1022     -7.8475004434585571e-01
    z[3,1,3]  R1023     -6.1852329969406128e-01
    z[3,1,3]  R1024     5.2582442760467529e-01
    z[3,1,3]  R1025     -6.0382641851902008e-02
    z[3,1,3]  R1026     -7.2278821468353271e-01
    z[3,1,3]  R1027     -5.0711852312088013e-01
    z[3,1,3]  R1028     1.3981281220912933e-01
    z[3,1,3]  R1029     -3.8838258385658264e-01
    z[3,1,3]  R1030     -4.6801382303237915e-01
    z[3,1,3]  R1031     -1.5272186696529388e-01
    z[3,1,3]  R1032     -1.5562401711940765e-01
    z[3,1,3]  R1033     -3.8897407054901123e-01
    z[3,1,3]  R1034     3.3179691433906555e-01
    z[3,1,3]  R1035     -7.4050635099411011e-01
    z[3,1,3]  R1036     -7.1543955802917480e-01
    z[3,1,3]  R1037     -1.6899734735488892e-01
    z[3,1,3]  R1038     -2.9901450872421265e-01
    z[3,1,3]  R1039     -6.2989783287048340e-01
    z[3,1,3]  R1040     -3.0583354830741882e-01
    z[3,1,3]  R1041     -9.0693213045597076e-02
    z[3,1,3]  R1042     -3.6551168560981750e-01
    z[3,1,3]  R1043     -2.0487499237060547e-01
    z[3,1,3]  R1044     2.2473834455013275e-01
    z[3,1,3]  R1045     3.9176097512245178e-01
    z[3,1,3]  R1046     3.1831261515617371e-01
    z[3,1,3]  R1047     -3.2946917414665222e-01
    z[3,1,3]  R1048     -7.1472346782684326e-01
    z[3,1,3]  R1049     -5.3426802158355713e-01
    z[3,1,3]  R1050     9.2764936387538910e-02
    z[3,1,3]  R1051     3.5665526986122131e-01
    z[3,1,3]  R1052     -1.0075378417968750e-01
    z[3,1,3]  R1053     6.7626923322677612e-02
    z[3,1,4]  R15       1
    z[3,1,4]  R33       -1
    z[3,1,4]  R953      -1
    z[3,1,4]  R954      1
    z[3,1,4]  R959      1.7180059850215912e-01
    z[3,1,4]  R960      -0.290390282869339
    z[3,1,4]  R961      -1.2788760662078857e-01
    z[3,1,4]  R962      3.1648221611976624e-01
    z[3,1,4]  R963      2.4286733940243721e-02
    z[3,1,4]  R964      -1.8562752008438110e-01
    z[3,1,4]  R965      -8.5928475856781006e-01
    z[3,1,4]  R966      3.1024357676506042e-01
    z[3,1,4]  R967      -3.6562168598175049e-01
    z[3,1,4]  R968      -1.3181759975850582e-02
    z[3,1,4]  R969      2.3730356991291046e-01
    z[3,1,4]  R970      4.6288302540779114e-01
    z[3,1,4]  R971      -1.7594926059246063e-01
    z[3,1,4]  R972      2.8487956523895264e-01
    z[3,1,4]  R973      5.3741383552551270e-01
    z[3,1,4]  R974      -6.5206247568130493e-01
    z[3,1,4]  R975      -1.2586151063442230e-01
    z[3,1,4]  R976      -3.7285369634628296e-01
    z[3,1,4]  R977      2.2079035639762878e-01
    z[3,1,4]  R978      -4.1671305894851685e-02
    z[3,1,4]  R979      -3.0649396777153015e-01
    z[3,1,4]  R980      -7.3452973365783691e-01
    z[3,1,4]  R981      2.4466475844383240e-01
    z[3,1,4]  R982      7.3377601802349091e-02
    z[3,1,4]  R983      1.7693807184696198e-01
    z[3,1,4]  R984      4.6062642335891724e-01
    z[3,1,4]  R985      -1.2591026723384857e-01
    z[3,1,4]  R986      3.6756515502929688e-01
    z[3,1,4]  R987      0.665052592754364
    z[3,1,4]  R988      2.8749847412109375e-01
    z[3,1,4]  R989      -3.1212879344820976e-02
    z[3,1,4]  R990      -3.7841506302356720e-02
    z[3,1,4]  R991      0.0452711246907711
    z[3,1,4]  R992      0.0777883306145668
    z[3,1,4]  R993      1.3398057222366333e-01
    z[3,1,4]  R994      2.4681188166141510e-01
    z[3,1,4]  R995      -0.088363416492939
    z[3,1,4]  R996      4.5156961679458618e-01
    z[3,1,4]  R997      8.8034041225910187e-02
    z[3,1,4]  R998      -6.2480556964874268e-01
    z[3,1,4]  R999      1.5076331794261932e-01
    z[3,1,4]  R1000     -6.4340668916702271e-01
    z[3,1,4]  R1001     5.3378814458847046e-01
    z[3,1,4]  R1002     -0.409236341714859
    z[3,1,4]  R1003     5.5659556388854980e-01
    z[3,1,4]  R1004     -3.8463276624679565e-01
    z[3,1,4]  R1005     9.5938645303249359e-02
    z[3,1,4]  R1006     -6.6198281943798065e-02
    z[3,1,4]  R1007     -3.8781216740608215e-01
    z[3,1,4]  R1008     -1.2392628192901611e-01
    z[3,1,4]  R1009     -3.0565986037254333e-01
    z[3,1,4]  R1010     -1.7183527350425720e-01
    z[3,1,4]  R1011     1.3652063906192780e-01
    z[3,1,4]  R1012     0.0509721003472805
    z[3,1,4]  R1013     5.2445590496063232e-01
    z[3,1,4]  R1014     2.2199855744838715e-01
    z[3,1,4]  R1015     4.9800035357475281e-01
    z[3,1,4]  R1016     -1.5305636823177338e-01
    z[3,1,4]  R1017     -4.0015062689781189e-01
    z[3,1,4]  R1018     -6.5390810370445251e-02
    z[3,1,4]  R1019     7.4854081869125366e-01
    z[3,1,4]  R1020     4.7155517339706421e-01
    z[3,1,4]  R1021     4.6287944912910461e-01
    z[3,1,4]  R1022     0.389067679643631
    z[3,1,4]  R1023     4.6220120787620544e-01
    z[3,1,4]  R1024     -7.2527617216110229e-02
    z[3,1,4]  R1025     -4.4467210769653320e-01
    z[3,1,4]  R1026     5.6296974420547485e-01
    z[3,1,4]  R1027     0.647429883480072
    z[3,1,4]  R1028     5.5801492184400558e-02
    z[3,1,4]  R1029     -1.7731563746929169e-01
    z[3,1,4]  R1030     4.2421564459800720e-01
    z[3,1,4]  R1031     1.9498154520988464e-01
    z[3,1,4]  R1032     2.2781883180141449e-01
    z[3,1,4]  R1033     3.9964246749877930e-01
    z[3,1,4]  R1034     3.9224009960889816e-02
    z[3,1,4]  R1035     5.6126755475997925e-01
    z[3,1,4]  R1036     -3.1642830371856689e-01
    z[3,1,4]  R1037     -6.5407925285398960e-03
    z[3,1,4]  R1038     1.5727029740810394e-01
    z[3,1,4]  R1039     6.1651289463043213e-01
    z[3,1,4]  R1040     1.0274988412857056e-01
    z[3,1,4]  R1041     1.2560781836509705e-01
    z[3,1,4]  R1042     6.3737088441848755e-01
    z[3,1,4]  R1043     1.9057793915271759e-01
    z[3,1,4]  R1044     7.5338676571846008e-02
    z[3,1,4]  R1045     -4.2842742800712585e-01
    z[3,1,4]  R1046     -3.0310210585594177e-01
    z[3,1,4]  R1047     2.1609136462211609e-01
    z[3,1,4]  R1048     2.2000500559806824e-01
    z[3,1,4]  R1049     4.0507584810256958e-01
    z[3,1,4]  R1050     1.6546308994293213e-01
    z[3,1,4]  R1051     -1.2892046570777893e-01
    z[3,1,4]  R1052     2.7788332104682922e-01
    z[3,1,4]  R1053     -2.9304352402687073e-01
    z[3,1,5]  R16       1
    z[3,1,5]  R34       -1
    z[3,1,5]  R955      -1
    z[3,1,5]  R956      1
    z[3,1,5]  R959      -6.1394846439361572e-01
    z[3,1,5]  R960      2.0823361352086067e-02
    z[3,1,5]  R961      -1.9786822795867920e-01
    z[3,1,5]  R962      -3.6314314603805542e-01
    z[3,1,5]  R963      -3.8083171844482422e-01
    z[3,1,5]  R964      1.3971579074859619e-01
    z[3,1,5]  R965      2.1009135246276855e-01
    z[3,1,5]  R966      -4.3233373761177063e-01
    z[3,1,5]  R967      -1.3284134864807129e-01
    z[3,1,5]  R968      2.7037004474550486e-03
    z[3,1,5]  R969      0.0669000968337059
    z[3,1,5]  R970      5.3333175182342529e-01
    z[3,1,5]  R971      -5.1613062620162964e-01
    z[3,1,5]  R972      3.9667895436286926e-01
    z[3,1,5]  R973      4.8298445343971252e-01
    z[3,1,5]  R974      3.2446511089801788e-02
    z[3,1,5]  R975      -6.5567381680011749e-02
    z[3,1,5]  R976      -0.365255743265152
    z[3,1,5]  R977      -3.6753949522972107e-01
    z[3,1,5]  R978      -2.3557227849960327e-01
    z[3,1,5]  R979      -0.622138261795044
    z[3,1,5]  R980      -3.6611225455999374e-02
    z[3,1,5]  R981      -5.2739516831934452e-03
    z[3,1,5]  R982      -2.3253858089447021e-01
    z[3,1,5]  R983      -2.0286414027214050e-01
    z[3,1,5]  R984      -1.3849419355392456e-01
    z[3,1,5]  R985      5.6229633092880249e-01
    z[3,1,5]  R986      3.6926373839378357e-01
    z[3,1,5]  R987      4.5246917009353638e-01
    z[3,1,5]  R988      -5.0347644090652466e-01
    z[3,1,5]  R989      -3.1183698773384094e-01
    z[3,1,5]  R990      -7.9829913377761841e-01
    z[3,1,5]  R991      -2.9537272453308105e-01
    z[3,1,5]  R992      -2.8188723325729370e-01
    z[3,1,5]  R993      -4.9727156758308411e-01
    z[3,1,5]  R994      -3.7695422768592834e-01
    z[3,1,5]  R995      -4.3837973475456238e-01
    z[3,1,5]  R996      3.8149955216795206e-03
    z[3,1,5]  R997      -6.0314124822616577e-01
    z[3,1,5]  R998      -7.2073573246598244e-03
    z[3,1,5]  R999      4.4679322838783264e-01
    z[3,1,5]  R1000     3.0278950929641724e-01
    z[3,1,5]  R1001     2.2949904203414917e-02
    z[3,1,5]  R1002     -2.5269734859466553e-01
    z[3,1,5]  R1003     6.4644269645214081e-02
    z[3,1,5]  R1004     -2.2468364238739014e-01
    z[3,1,5]  R1005     -6.4025238156318665e-02
    z[3,1,5]  R1006     1.6272965073585510e-01
    z[3,1,5]  R1007     6.2386733293533325e-01
    z[3,1,5]  R1008     1.6510689258575439e-01
    z[3,1,5]  R1009     4.6994745731353760e-01
    z[3,1,5]  R1010     2.7037739753723145e-01
    z[3,1,5]  R1011     2.1190980076789856e-01
    z[3,1,5]  R1012     2.1083962917327881e-01
    z[3,1,5]  R1013     4.1137434542179108e-02
    z[3,1,5]  R1014     -1.3605177402496338e-01
    z[3,1,5]  R1015     2.8889194130897522e-01
    z[3,1,5]  R1016     -1.4131484925746918e-01
    z[3,1,5]  R1017     -1.2616080045700073e-01
    z[3,1,5]  R1018     -2.4881792068481445e-01
    z[3,1,5]  R1019     3.5429760813713074e-01
    z[3,1,5]  R1020     2.5861939787864685e-01
    z[3,1,5]  R1021     4.7179350256919861e-01
    z[3,1,5]  R1022     -2.3139877617359161e-01
    z[3,1,5]  R1023     -9.0957731008529663e-02
    z[3,1,5]  R1024     -2.6501569151878357e-01
    z[3,1,5]  R1025     1.3838236033916473e-01
    z[3,1,5]  R1026     -1.9547903910279274e-02
    z[3,1,5]  R1027     7.4831224977970123e-02
    z[3,1,5]  R1028     -2.5719344615936279e-01
    z[3,1,5]  R1029     -2.8230378031730652e-01
    z[3,1,5]  R1030     5.3210198879241943e-01
    z[3,1,5]  R1031     -0.801838755607605
    z[3,1,5]  R1032     1.8001425266265869e-01
    z[3,1,5]  R1033     3.5701093077659607e-01
    z[3,1,5]  R1034     -1.5142035484313965e-01
    z[3,1,5]  R1035     -1.2355160713195801e-01
    z[3,1,5]  R1036     2.4428399279713631e-02
    z[3,1,5]  R1037     -4.5424187183380127e-01
    z[3,1,5]  R1038     -2.0846258103847504e-01
    z[3,1,5]  R1039     -7.1001998148858547e-03
    z[3,1,5]  R1040     -6.4996105432510376e-01
    z[3,1,5]  R1041     -7.5318956375122070e-01
    z[3,1,5]  R1042     4.7404772043228149e-01
    z[3,1,5]  R1043     -4.9066326022148132e-01
    z[3,1,5]  R1044     -1.1694166809320450e-01
    z[3,1,5]  R1045     -0.314789742231369
    z[3,1,5]  R1046     -6.6570803523063660e-02
    z[3,1,5]  R1047     2.5973695516586304e-01
    z[3,1,5]  R1048     5.7863587141036987e-01
    z[3,1,5]  R1049     6.0070103406906128e-01
    z[3,1,5]  R1050     -5.5635792016983032e-01
    z[3,1,5]  R1051     -5.2710570394992828e-02
    z[3,1,5]  R1052     8.5005831718444824e-01
    z[3,1,5]  R1053     8.9964523911476135e-02
    z[3,1,6]  R17       1
    z[3,1,6]  R35       -1
    z[3,1,6]  R957      -1
    z[3,1,6]  R958      1
    z[3,1,6]  R959      8.6160756647586823e-02
    z[3,1,6]  R960      1.6605402529239655e-01
    z[3,1,6]  R961      -2.0802492275834084e-02
    z[3,1,6]  R962      -2.6933647692203522e-02
    z[3,1,6]  R963      3.9008951187133789e-01
    z[3,1,6]  R964      -3.8659039884805679e-02
    z[3,1,6]  R965      2.8735810518264771e-01
    z[3,1,6]  R966      -6.3604766130447388e-01
    z[3,1,6]  R967      -1.3491220772266388e-01
    z[3,1,6]  R968      -3.0646494030952454e-01
    z[3,1,6]  R969      -2.3540496826171875e-01
    z[3,1,6]  R970      2.9689380899071693e-02
    z[3,1,6]  R971      2.5936502218246460e-01
    z[3,1,6]  R972      4.7487938404083252e-01
    z[3,1,6]  R973      3.8391733169555664e-01
    z[3,1,6]  R974      1.3085016608238220e-01
    z[3,1,6]  R975      1.1600548774003983e-01
    z[3,1,6]  R976      4.2506250739097595e-01
    z[3,1,6]  R977      2.4431201815605164e-01
    z[3,1,6]  R978      -1.4500702917575836e-01
    z[3,1,6]  R979      2.1159036457538605e-01
    z[3,1,6]  R980      3.5938540101051331e-01
    z[3,1,6]  R981      -4.6782839298248291e-01
    z[3,1,6]  R982      -1.0615862160921097e-01
    z[3,1,6]  R983      -1.4555260539054871e-01
    z[3,1,6]  R984      2.3571690917015076e-01
    z[3,1,6]  R985      1.0621951520442963e-01
    z[3,1,6]  R986      3.8641107082366943e-01
    z[3,1,6]  R987      -3.6785754561424255e-01
    z[3,1,6]  R988      2.0828416571021080e-02
    z[3,1,6]  R989      -1.2216480448842049e-02
    z[3,1,6]  R990      1.1993527412414551e-02
    z[3,1,6]  R991      8.2460641860961914e-02
    z[3,1,6]  R992      2.1416340768337250e-01
    z[3,1,6]  R993      -1.6538253426551819e-01
    z[3,1,6]  R994      -7.3446303606033325e-02
    z[3,1,6]  R995      -4.2032524943351746e-01
    z[3,1,6]  R996      2.7940708398818970e-01
    z[3,1,6]  R997      -1.8813130259513855e-01
    z[3,1,6]  R998      -2.2651143372058868e-01
    z[3,1,6]  R999      -1.8179714679718018e-01
    z[3,1,6]  R1000     1.5003718435764313e-01
    z[3,1,6]  R1001     -2.5128149986267090e-01
    z[3,1,6]  R1002     3.7031254172325134e-01
    z[3,1,6]  R1003     -2.5416231155395508e-01
    z[3,1,6]  R1004     -3.8818377256393433e-01
    z[3,1,6]  R1005     -1.3745276629924774e-01
    z[3,1,6]  R1006     -1.3179273903369904e-01
    z[3,1,6]  R1007     5.0018224865198135e-02
    z[3,1,6]  R1008     1.4868189394474030e-01
    z[3,1,6]  R1009     3.9425730705261230e-01
    z[3,1,6]  R1010     -2.5615498423576355e-01
    z[3,1,6]  R1011     3.9963837713003159e-02
    z[3,1,6]  R1012     1.1153426021337509e-01
    z[3,1,6]  R1013     1.6635512933135033e-02
    z[3,1,6]  R1014     2.2376313805580139e-01
    z[3,1,6]  R1015     1.2190598063170910e-02
    z[3,1,6]  R1016     -2.3938070237636566e-01
    z[3,1,6]  R1017     1.4452320337295532e-01
    z[3,1,6]  R1018     4.2092159390449524e-01
    z[3,1,6]  R1019     -4.5116588473320007e-02
    z[3,1,6]  R1020     2.2884733974933624e-01
    z[3,1,6]  R1021     2.4053448438644409e-01
    z[3,1,6]  R1022     3.4515008330345154e-01
    z[3,1,6]  R1023     -1.0589775443077087e-01
    z[3,1,6]  R1024     -1.2426482141017914e-01
    z[3,1,6]  R1025     -4.4793472625315189e-03
    z[3,1,6]  R1026     -2.5481733679771423e-01
    z[3,1,6]  R1027     -7.5411156285554171e-04
    z[3,1,6]  R1028     -2.5086278095841408e-02
    z[3,1,6]  R1029     2.8081163763999939e-01
    z[3,1,6]  R1030     -6.4469978213310242e-02
    z[3,1,6]  R1031     -1.5975619852542877e-01
    z[3,1,6]  R1032     1.0130092501640320e-02
    z[3,1,6]  R1033     1.9859719276428223e-01
    z[3,1,6]  R1034     -1.6831737756729126e-01
    z[3,1,6]  R1035     2.3686951398849487e-01
    z[3,1,6]  R1036     -1.7415709793567657e-01
    z[3,1,6]  R1037     -3.4028398990631104e-01
    z[3,1,6]  R1038     1.3159666955471039e-01
    z[3,1,6]  R1039     -2.2998319566249847e-01
    z[3,1,6]  R1040     1.2799315154552460e-01
    z[3,1,6]  R1041     -6.8501620553433895e-03
    z[3,1,6]  R1042     -1.3989374041557312e-01
    z[3,1,6]  R1043     -0.0764738917350769
    z[3,1,6]  R1044     2.7800747752189636e-01
    z[3,1,6]  R1045     8.0497294664382935e-02
    z[3,1,6]  R1046     1.8978126347064972e-01
    z[3,1,6]  R1047     3.0881896615028381e-01
    z[3,1,6]  R1048     -1.2726396322250366e-01
    z[3,1,6]  R1049     6.1962187290191650e-02
    z[3,1,6]  R1050     -2.3533812165260315e-01
    z[3,1,6]  R1051     -4.7985520213842392e-02
    z[3,1,6]  R1052     1.4164811372756958e-01
    z[3,1,6]  R1053     2.2546948492527008e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1054     -1
    z[2,3,0]  R1055     1
    z[2,3,0]  R1068     -3.4547504782676697e-01
    z[2,3,0]  R1069     1.3561316765844822e-02
    z[2,3,0]  R1070     -3.6145329475402832e-01
    z[2,3,0]  R1071     -4.5829087495803833e-01
    z[2,3,0]  R1072     -0.684083104133606
    z[2,3,0]  R1073     5.8577132225036621e-01
    z[2,3,0]  R1074     4.8948177695274353e-01
    z[2,3,0]  R1075     2.9152107238769531e-01
    z[2,3,0]  R1076     1.1649436503648758e-01
    z[2,3,0]  R1077     3.7414813041687012e-01
    z[2,3,0]  R1078     -1.0246091336011887e-01
    z[2,3,0]  R1079     9.4595164060592651e-02
    z[2,3,0]  R1080     1.6218294203281403e-01
    z[2,3,0]  R1081     -1.3031384348869324e-01
    z[2,3,0]  R1082     -4.1496995836496353e-02
    z[2,3,0]  R1083     1.2153500691056252e-02
    z[2,3,0]  R1084     -1.2515839934349060e-01
    z[2,3,0]  R1085     7.1756877005100250e-02
    z[2,3,0]  R1086     -4.0827151387929916e-02
    z[2,3,0]  R1087     6.3087129592895508e-01
    z[2,3,0]  R1088     2.6328464969992638e-02
    z[2,3,0]  R1089     6.7273631691932678e-02
    z[2,3,0]  R1090     3.0740952491760254e-01
    z[2,3,0]  R1091     2.2847460210323334e-01
    z[2,3,0]  R1092     0.571487545967102
    z[2,3,0]  R1093     3.7006980180740356e-01
    z[2,3,0]  R1094     3.5615384578704834e-01
    z[2,3,0]  R1095     1.8936680257320404e-01
    z[2,3,0]  R1096     2.8686422109603882e-01
    z[2,3,0]  R1097     4.6804994344711304e-01
    z[2,3,0]  R1098     2.7180549502372742e-01
    z[2,3,0]  R1099     2.5965690612792969e-01
    z[2,3,0]  R1100     4.5168903470039368e-01
    z[2,3,0]  R1101     4.7862139344215393e-01
    z[2,3,0]  R1102     5.2210897207260132e-01
    z[2,3,0]  R1103     2.0533682405948639e-01
    z[2,3,0]  R1104     4.0825748443603516e-01
    z[2,3,0]  R1105     2.0486554503440857e-01
    z[2,3,0]  R1106     6.4479327201843262e-01
    z[2,3,0]  R1107     6.4287084341049194e-01
    z[2,3,0]  R1108     -4.3774202822532970e-06
    z[2,3,0]  R1109     -5.0196421146392822e-01
    z[2,3,0]  R1110     9.2960394918918610e-02
    z[2,3,0]  R1111     -5.4913395643234253e-01
    z[2,3,0]  R1112     -4.6438139677047729e-01
    z[2,3,0]  R1113     -3.6235442757606506e-01
    z[2,3,0]  R1114     1.7734211683273315e-01
    z[2,3,0]  R1115     1.1243292689323425e-01
    z[2,3,0]  R1116     -5.2351492643356323e-01
    z[2,3,0]  R1117     3.2991003245115280e-03
    z[2,3,0]  R1118     3.1800916790962219e-01
    z[2,3,0]  R1119     3.3361810445785522e-01
    z[2,3,0]  R1120     3.0185526609420776e-01
    z[2,3,0]  R1121     3.6144572496414185e-01
    z[2,3,0]  R1122     1.7125104367733002e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1056     -1
    z[2,3,1]  R1057     1
    z[2,3,1]  R1068     -0.750278890132904
    z[2,3,1]  R1069     -0.671106219291687
    z[2,3,1]  R1070     -4.1270947456359863e-01
    z[2,3,1]  R1071     -6.1707812547683716e-01
    z[2,3,1]  R1072     -4.1638168692588806e-01
    z[2,3,1]  R1073     4.6346348524093628e-01
    z[2,3,1]  R1074     7.7009522914886475e-01
    z[2,3,1]  R1075     8.3872324228286743e-01
    z[2,3,1]  R1076     8.4543758630752563e-01
    z[2,3,1]  R1077     8.6298817396163940e-01
    z[2,3,1]  R1078     7.5134354829788208e-01
    z[2,3,1]  R1079     8.3110558986663818e-01
    z[2,3,1]  R1080     4.9972397089004517e-01
    z[2,3,1]  R1081     4.6165066957473755e-01
    z[2,3,1]  R1082     6.3231056928634644e-01
    z[2,3,1]  R1083     5.7388871908187866e-01
    z[2,3,1]  R1084     5.6774681806564331e-01
    z[2,3,1]  R1085     9.4949412345886230e-01
    z[2,3,1]  R1086     9.1691529750823975e-01
    z[2,3,1]  R1087     6.8674588203430176e-01
    z[2,3,1]  R1088     4.5204082131385803e-01
    z[2,3,1]  R1089     9.4661259651184082e-01
    z[2,3,1]  R1090     9.0046483278274536e-01
    z[2,3,1]  R1091     8.4820568561553955e-01
    z[2,3,1]  R1092     7.4543327093124390e-01
    z[2,3,1]  R1093     8.3941560983657837e-01
    z[2,3,1]  R1094     7.7500838041305542e-01
    z[2,3,1]  R1095     8.1515860557556152e-01
    z[2,3,1]  R1096     7.6194858551025391e-01
    z[2,3,1]  R1097     0.707585871219635
    z[2,3,1]  R1098     6.5791672468185425e-01
    z[2,3,1]  R1099     5.4883909225463867e-01
    z[2,3,1]  R1100     8.3625626564025879e-01
    z[2,3,1]  R1101     7.5414651632308960e-01
    z[2,3,1]  R1102     6.9773238897323608e-01
    z[2,3,1]  R1103     0.78978431224823
    z[2,3,1]  R1104     6.9925773143768311e-01
    z[2,3,1]  R1105     7.4881255626678467e-01
    z[2,3,1]  R1106     9.1009914875030518e-02
    z[2,3,1]  R1107     8.7913438677787781e-02
    z[2,3,1]  R1108     1.1947839707136154e-01
    z[2,3,1]  R1109     -0.65839684009552
    z[2,3,1]  R1110     -0.691955029964447
    z[2,3,1]  R1111     -5.5208396911621094e-01
    z[2,3,1]  R1112     -0.626633882522583
    z[2,3,1]  R1113     -4.1933557391166687e-01
    z[2,3,1]  R1114     0.064608134329319
    z[2,3,1]  R1115     -3.9330857992172241e-01
    z[2,3,1]  R1116     -0.666795015335083
    z[2,3,1]  R1117     -4.9973803758621216e-01
    z[2,3,1]  R1118     0.822810173034668
    z[2,3,1]  R1119     6.9742277264595032e-02
    z[2,3,1]  R1120     4.6270421147346497e-01
    z[2,3,1]  R1121     -0.0831177830696106
    z[2,3,1]  R1122     -5.0423705577850342e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1058     -1
    z[2,3,2]  R1059     1
    z[2,3,2]  R1068     -5.0815820693969727e-01
    z[2,3,2]  R1069     -4.2302456498146057e-01
    z[2,3,2]  R1070     -1.7271538078784943e-01
    z[2,3,2]  R1071     3.6518442630767822e-01
    z[2,3,2]  R1072     4.5311173796653748e-01
    z[2,3,2]  R1073     -5.6003034114837646e-01
    z[2,3,2]  R1074     1.2632903642952442e-02
    z[2,3,2]  R1075     2.2631423175334930e-01
    z[2,3,2]  R1076     0.0645333081483841
    z[2,3,2]  R1077     2.3833848536014557e-01
    z[2,3,2]  R1078     -5.6410312652587891e-01
    z[2,3,2]  R1079     -4.5141422748565674e-01
    z[2,3,2]  R1080     -3.5690742731094360e-01
    z[2,3,2]  R1081     -4.5796698331832886e-01
    z[2,3,2]  R1082     -6.8271929025650024e-01
    z[2,3,2]  R1083     -6.9360530376434326e-01
    z[2,3,2]  R1084     -5.2525812387466431e-01
    z[2,3,2]  R1085     1.9719203934073448e-02
    z[2,3,2]  R1086     6.9385424256324768e-02
    z[2,3,2]  R1087     -5.6376541033387184e-03
    z[2,3,2]  R1088     -2.7912083268165588e-01
    z[2,3,2]  R1089     2.6320907473564148e-01
    z[2,3,2]  R1090     5.5256552994251251e-02
    z[2,3,2]  R1091     3.1515088677406311e-01
    z[2,3,2]  R1092     1.2877109646797180e-01
    z[2,3,2]  R1093     -2.0384170114994049e-01
    z[2,3,2]  R1094     1.8829772248864174e-02
    z[2,3,2]  R1095     3.6813059449195862e-01
    z[2,3,2]  R1096     4.3131643533706665e-01
    z[2,3,2]  R1097     1.9450370222330093e-02
    z[2,3,2]  R1098     -6.0998445749282837e-01
    z[2,3,2]  R1099     -6.5625613927841187e-01
    z[2,3,2]  R1100     -1.3309018313884735e-01
    z[2,3,2]  R1101     2.6949909329414368e-01
    z[2,3,2]  R1102     -8.9618965983390808e-02
    z[2,3,2]  R1103     5.2157271653413773e-02
    z[2,3,2]  R1104     7.9599849879741669e-02
    z[2,3,2]  R1105     1.7099264264106750e-01
    z[2,3,2]  R1106     6.9347119331359863e-01
    z[2,3,2]  R1107     3.5757419466972351e-01
    z[2,3,2]  R1108     -5.0464099645614624e-01
    z[2,3,2]  R1109     -4.3756082653999329e-01
    z[2,3,2]  R1110     -4.2218956351280212e-01
    z[2,3,2]  R1111     -3.9870855212211609e-01
    z[2,3,2]  R1112     -2.4444781243801117e-01
    z[2,3,2]  R1113     -7.1697455644607544e-01
    z[2,3,2]  R1114     -4.2742338031530380e-02
    z[2,3,2]  R1115     2.9280850291252136e-01
    z[2,3,2]  R1116     -3.2561093568801880e-01
    z[2,3,2]  R1117     7.9545283317565918e-01
    z[2,3,2]  R1118     3.1671860814094543e-01
    z[2,3,2]  R1119     1.6957861185073853e-01
    z[2,3,2]  R1120     3.2461118698120117e-01
    z[2,3,2]  R1121     2.1251462399959564e-01
    z[2,3,2]  R1122     4.9290871247649193e-03
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1060     -1
    z[2,3,3]  R1061     1
    z[2,3,3]  R1068     -2.5656517595052719e-02
    z[2,3,3]  R1069     1.0290110856294632e-01
    z[2,3,3]  R1070     -3.7951406836509705e-01
    z[2,3,3]  R1071     1.5847012400627136e-01
    z[2,3,3]  R1072     -9.5752961933612823e-02
    z[2,3,3]  R1073     1.2112659215927124e-01
    z[2,3,3]  R1074     -2.8817000985145569e-01
    z[2,3,3]  R1075     -1.2101585045456886e-02
    z[2,3,3]  R1076     -3.5101306438446045e-01
    z[2,3,3]  R1077     2.6030080392956734e-02
    z[2,3,3]  R1078     2.0595878362655640e-01
    z[2,3,3]  R1079     2.9962339997291565e-01
    z[2,3,3]  R1080     3.5861894488334656e-01
    z[2,3,3]  R1081     7.0065456628799438e-01
    z[2,3,3]  R1082     -2.4264791607856750e-01
    z[2,3,3]  R1083     -1.7299422621726990e-01
    z[2,3,3]  R1084     -1.3633483648300171e-01
    z[2,3,3]  R1085     2.0767839252948761e-01
    z[2,3,3]  R1086     -6.9356516178231686e-05
    z[2,3,3]  R1087     -1.2251529842615128e-01
    z[2,3,3]  R1088     8.1395357847213745e-01
    z[2,3,3]  R1089     1.0558506101369858e-01
    z[2,3,3]  R1090     -1.3593651354312897e-01
    z[2,3,3]  R1091     2.8788870573043823e-01
    z[2,3,3]  R1092     2.0491313934326172e-01
    z[2,3,3]  R1093     -1.5126244723796844e-01
    z[2,3,3]  R1094     2.3018684983253479e-01
    z[2,3,3]  R1095     3.3910858631134033e-01
    z[2,3,3]  R1096     0.0849059447646141
    z[2,3,3]  R1097     2.1504996716976166e-01
    z[2,3,3]  R1098     3.2789698243141174e-01
    z[2,3,3]  R1099     6.5549522638320923e-02
    z[2,3,3]  R1100     -2.1718624234199524e-01
    z[2,3,3]  R1101     -2.5616735219955444e-02
    z[2,3,3]  R1102     -3.9837455749511719e-01
    z[2,3,3]  R1103     3.6927703768014908e-02
    z[2,3,3]  R1104     3.8007974624633789e-01
    z[2,3,3]  R1105     -5.1780611276626587e-01
    z[2,3,3]  R1106     -0.0729045420885086
    z[2,3,3]  R1107     -1.4556339383125305e-01
    z[2,3,3]  R1108     5.6319665908813477e-01
    z[2,3,3]  R1109     -1.0369183868169785e-01
    z[2,3,3]  R1110     -5.2761048078536987e-01
    z[2,3,3]  R1111     -4.3900772929191589e-02
    z[2,3,3]  R1112     1.8475079536437988e-01
    z[2,3,3]  R1113     3.5118627548217773e-01
    z[2,3,3]  R1114     3.1219440698623657e-01
    z[2,3,3]  R1115     -2.4333126842975616e-01
    z[2,3,3]  R1116     7.5939163565635681e-02
    z[2,3,3]  R1117     -1.5298357605934143e-01
    z[2,3,3]  R1118     7.3067627847194672e-02
    z[2,3,3]  R1119     5.9623247385025024e-01
    z[2,3,3]  R1120     -4.7412705421447754e-01
    z[2,3,3]  R1121     -0.594360888004303
    z[2,3,3]  R1122     -2.1659563481807709e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1062     -1
    z[2,3,4]  R1063     1
    z[2,3,4]  R1068     -1.5438847243785858e-01
    z[2,3,4]  R1069     -7.6973032264504582e-05
    z[2,3,4]  R1070     -3.3534789085388184e-01
    z[2,3,4]  R1071     -4.2755752801895142e-01
    z[2,3,4]  R1072     2.4388051033020020e-01
    z[2,3,4]  R1073     -2.8327324986457825e-01
    z[2,3,4]  R1074     -3.8198661059141159e-02
    z[2,3,4]  R1075     -3.8981625437736511e-01
    z[2,3,4]  R1076     -1.3761992752552032e-01
    z[2,3,4]  R1077     1.5958875417709351e-01
    z[2,3,4]  R1078     -1.5392169356346130e-01
    z[2,3,4]  R1079     3.6746963858604431e-02
    z[2,3,4]  R1080     -0.658660352230072
    z[2,3,4]  R1081     1.4881216920912266e-02
    z[2,3,4]  R1082     2.4512492120265961e-01
    z[2,3,4]  R1083     -4.6883486211299896e-02
    z[2,3,4]  R1084     -2.8469032049179077e-01
    z[2,3,4]  R1085     1.4053110778331757e-01
    z[2,3,4]  R1086     -9.3117050826549530e-02
    z[2,3,4]  R1087     2.6159879565238953e-01
    z[2,3,4]  R1088     -2.2049877047538757e-01
    z[2,3,4]  R1089     -5.9276461601257324e-02
    z[2,3,4]  R1090     -0.257587730884552
    z[2,3,4]  R1091     -1.1354881525039673e-01
    z[2,3,4]  R1092     -7.5281903147697449e-02
    z[2,3,4]  R1093     2.9876199364662170e-01
    z[2,3,4]  R1094     6.2722176313400269e-02
    z[2,3,4]  R1095     1.0926172882318497e-01
    z[2,3,4]  R1096     2.9511335492134094e-01
    z[2,3,4]  R1097     -7.2376020252704620e-02
    z[2,3,4]  R1098     -2.0937213674187660e-02
    z[2,3,4]  R1099     -1.9255377352237701e-01
    z[2,3,4]  R1100     2.1501084789633751e-02
    z[2,3,4]  R1101     -8.2156062126159668e-03
    z[2,3,4]  R1102     2.2068174183368683e-01
    z[2,3,4]  R1103     3.2346978783607483e-01
    z[2,3,4]  R1104     3.5036367177963257e-01
    z[2,3,4]  R1105     2.9226174950599670e-01
    z[2,3,4]  R1106     -5.6999187916517258e-02
    z[2,3,4]  R1107     2.0588155090808868e-01
    z[2,3,4]  R1108     1.7180059850215912e-01
    z[2,3,4]  R1109     -0.290390282869339
    z[2,3,4]  R1110     -1.2788760662078857e-01
    z[2,3,4]  R1111     3.1648221611976624e-01
    z[2,3,4]  R1112     2.4286733940243721e-02
    z[2,3,4]  R1113     -1.8562752008438110e-01
    z[2,3,4]  R1114     -8.5928475856781006e-01
    z[2,3,4]  R1115     3.1024357676506042e-01
    z[2,3,4]  R1116     -3.6562168598175049e-01
    z[2,3,4]  R1117     -1.3181759975850582e-02
    z[2,3,4]  R1118     2.3730356991291046e-01
    z[2,3,4]  R1119     4.6288302540779114e-01
    z[2,3,4]  R1120     -1.7594926059246063e-01
    z[2,3,4]  R1121     2.8487956523895264e-01
    z[2,3,4]  R1122     5.3741383552551270e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1064     -1
    z[2,3,5]  R1065     1
    z[2,3,5]  R1068     -1.0144112259149551e-01
    z[2,3,5]  R1069     -0.460526704788208
    z[2,3,5]  R1070     -6.2519145011901855e-01
    z[2,3,5]  R1071     2.1900166571140289e-01
    z[2,3,5]  R1072     9.5428600907325745e-02
    z[2,3,5]  R1073     -1.0198953002691269e-01
    z[2,3,5]  R1074     -1.9380992650985718e-01
    z[2,3,5]  R1075     -6.1036027967929840e-02
    z[2,3,5]  R1076     -2.1970821544528008e-02
    z[2,3,5]  R1077     -9.4059586524963379e-02
    z[2,3,5]  R1078     -1.6372489929199219e-01
    z[2,3,5]  R1079     4.2902618646621704e-02
    z[2,3,5]  R1080     5.2850235253572464e-02
    z[2,3,5]  R1081     -1.5487061440944672e-01
    z[2,3,5]  R1082     -9.9672386422753334e-03
    z[2,3,5]  R1083     -1.5553395450115204e-01
    z[2,3,5]  R1084     4.0574066340923309e-02
    z[2,3,5]  R1085     -0.122328020632267
    z[2,3,5]  R1086     -3.4870034456253052e-01
    z[2,3,5]  R1087     1.8090550601482391e-01
    z[2,3,5]  R1088     -5.0910115242004395e-02
    z[2,3,5]  R1089     -1.6325891017913818e-02
    z[2,3,5]  R1090     0.0240008644759655
    z[2,3,5]  R1091     1.7423366010189056e-01
    z[2,3,5]  R1092     7.4190340936183929e-02
    z[2,3,5]  R1093     -3.4981764853000641e-02
    z[2,3,5]  R1094     4.1195428371429443e-01
    z[2,3,5]  R1095     -1.1364228278398514e-01
    z[2,3,5]  R1096     -8.9100472629070282e-02
    z[2,3,5]  R1097     -3.0492374300956726e-01
    z[2,3,5]  R1098     -1.1079335212707520e-01
    z[2,3,5]  R1099     5.3455509245395660e-02
    z[2,3,5]  R1100     -1.5185537934303284e-01
    z[2,3,5]  R1101     -1.5557087957859039e-01
    z[2,3,5]  R1102     1.5664680302143097e-01
    z[2,3,5]  R1103     3.6281082034111023e-01
    z[2,3,5]  R1104     -9.8257049918174744e-02
    z[2,3,5]  R1105     3.9560042321681976e-02
    z[2,3,5]  R1106     -1.9892990589141846e-01
    z[2,3,5]  R1107     -5.1982551813125610e-01
    z[2,3,5]  R1108     -6.1394846439361572e-01
    z[2,3,5]  R1109     2.0823361352086067e-02
    z[2,3,5]  R1110     -1.9786822795867920e-01
    z[2,3,5]  R1111     -3.6314314603805542e-01
    z[2,3,5]  R1112     -3.8083171844482422e-01
    z[2,3,5]  R1113     1.3971579074859619e-01
    z[2,3,5]  R1114     2.1009135246276855e-01
    z[2,3,5]  R1115     -4.3233373761177063e-01
    z[2,3,5]  R1116     -1.3284134864807129e-01
    z[2,3,5]  R1117     2.7037004474550486e-03
    z[2,3,5]  R1118     0.0669000968337059
    z[2,3,5]  R1119     5.3333175182342529e-01
    z[2,3,5]  R1120     -5.1613062620162964e-01
    z[2,3,5]  R1121     3.9667895436286926e-01
    z[2,3,5]  R1122     4.8298445343971252e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1066     -1
    z[2,3,6]  R1067     1
    z[2,3,6]  R1068     1.5722465515136719e-01
    z[2,3,6]  R1069     -3.8445958495140076e-01
    z[2,3,6]  R1070     -0.14777772128582
    z[2,3,6]  R1071     1.4122481644153595e-01
    z[2,3,6]  R1072     2.7494275569915771e-01
    z[2,3,6]  R1073     -1.5206019580364227e-01
    z[2,3,6]  R1074     -2.1245667338371277e-01
    z[2,3,6]  R1075     -6.7172899842262268e-02
    z[2,3,6]  R1076     3.5336604714393616e-01
    z[2,3,6]  R1077     1.5318599343299866e-01
    z[2,3,6]  R1078     -1.1770993471145630e-01
    z[2,3,6]  R1079     5.9793557971715927e-02
    z[2,3,6]  R1080     1.7707526683807373e-01
    z[2,3,6]  R1081     2.1222686767578125e-01
    z[2,3,6]  R1082     1.1529105901718140e-01
    z[2,3,6]  R1083     3.6482852697372437e-01
    z[2,3,6]  R1084     0.533686101436615
    z[2,3,6]  R1085     1.2279906868934631e-01
    z[2,3,6]  R1086     1.5007475018501282e-01
    z[2,3,6]  R1087     -1.1907586455345154e-01
    z[2,3,6]  R1088     -5.7666312903165817e-02
    z[2,3,6]  R1089     1.2325332313776016e-01
    z[2,3,6]  R1090     7.8757822513580322e-02
    z[2,3,6]  R1091     5.3811889141798019e-02
    z[2,3,6]  R1092     -2.1906213462352753e-01
    z[2,3,6]  R1093     5.9291366487741470e-02
    z[2,3,6]  R1094     2.1339060366153717e-01
    z[2,3,6]  R1095     -1.5584947168827057e-01
    z[2,3,6]  R1096     -2.2106464207172394e-01
    z[2,3,6]  R1097     -3.6798080801963806e-01
    z[2,3,6]  R1098     -3.0925212427973747e-02
    z[2,3,6]  R1099     -3.9553830027580261e-01
    z[2,3,6]  R1100     -9.0814061462879181e-02
    z[2,3,6]  R1101     -3.2346379756927490e-01
    z[2,3,6]  R1102     2.4477085098624229e-02
    z[2,3,6]  R1103     3.0615216493606567e-01
    z[2,3,6]  R1104     -2.4730274081230164e-01
    z[2,3,6]  R1105     1.1387012898921967e-01
    z[2,3,6]  R1106     2.1660865843296051e-01
    z[2,3,6]  R1107     3.4254112839698792e-01
    z[2,3,6]  R1108     8.6160756647586823e-02
    z[2,3,6]  R1109     1.6605402529239655e-01
    z[2,3,6]  R1110     -2.0802492275834084e-02
    z[2,3,6]  R1111     -2.6933647692203522e-02
    z[2,3,6]  R1112     3.9008951187133789e-01
    z[2,3,6]  R1113     -3.8659039884805679e-02
    z[2,3,6]  R1114     2.8735810518264771e-01
    z[2,3,6]  R1115     -6.3604766130447388e-01
    z[2,3,6]  R1116     -1.3491220772266388e-01
    z[2,3,6]  R1117     -3.0646494030952454e-01
    z[2,3,6]  R1118     -2.3540496826171875e-01
    z[2,3,6]  R1119     2.9689380899071693e-02
    z[2,3,6]  R1120     2.5936502218246460e-01
    z[2,3,6]  R1121     4.7487938404083252e-01
    z[2,3,6]  R1122     3.8391733169555664e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1123     -1
    z[3,2,0]  R1124     1
    z[3,2,0]  R1137     -4.3774202822532970e-06
    z[3,2,0]  R1138     -5.0196421146392822e-01
    z[3,2,0]  R1139     9.2960394918918610e-02
    z[3,2,0]  R1140     -5.4913395643234253e-01
    z[3,2,0]  R1141     -4.6438139677047729e-01
    z[3,2,0]  R1142     -3.6235442757606506e-01
    z[3,2,0]  R1143     1.7734211683273315e-01
    z[3,2,0]  R1144     1.1243292689323425e-01
    z[3,2,0]  R1145     -5.2351492643356323e-01
    z[3,2,0]  R1146     3.2991003245115280e-03
    z[3,2,0]  R1147     3.1800916790962219e-01
    z[3,2,0]  R1148     3.3361810445785522e-01
    z[3,2,0]  R1149     3.0185526609420776e-01
    z[3,2,0]  R1150     3.6144572496414185e-01
    z[3,2,0]  R1151     1.7125104367733002e-01
    z[3,2,0]  R1152     -3.4547504782676697e-01
    z[3,2,0]  R1153     1.3561316765844822e-02
    z[3,2,0]  R1154     -3.6145329475402832e-01
    z[3,2,0]  R1155     -4.5829087495803833e-01
    z[3,2,0]  R1156     -0.684083104133606
    z[3,2,0]  R1157     5.8577132225036621e-01
    z[3,2,0]  R1158     4.8948177695274353e-01
    z[3,2,0]  R1159     2.9152107238769531e-01
    z[3,2,0]  R1160     1.1649436503648758e-01
    z[3,2,0]  R1161     3.7414813041687012e-01
    z[3,2,0]  R1162     -1.0246091336011887e-01
    z[3,2,0]  R1163     9.4595164060592651e-02
    z[3,2,0]  R1164     1.6218294203281403e-01
    z[3,2,0]  R1165     -1.3031384348869324e-01
    z[3,2,0]  R1166     -4.1496995836496353e-02
    z[3,2,0]  R1167     1.2153500691056252e-02
    z[3,2,0]  R1168     -1.2515839934349060e-01
    z[3,2,0]  R1169     7.1756877005100250e-02
    z[3,2,0]  R1170     -4.0827151387929916e-02
    z[3,2,0]  R1171     6.3087129592895508e-01
    z[3,2,0]  R1172     2.6328464969992638e-02
    z[3,2,0]  R1173     6.7273631691932678e-02
    z[3,2,0]  R1174     3.0740952491760254e-01
    z[3,2,0]  R1175     2.2847460210323334e-01
    z[3,2,0]  R1176     0.571487545967102
    z[3,2,0]  R1177     3.7006980180740356e-01
    z[3,2,0]  R1178     3.5615384578704834e-01
    z[3,2,0]  R1179     1.8936680257320404e-01
    z[3,2,0]  R1180     2.8686422109603882e-01
    z[3,2,0]  R1181     4.6804994344711304e-01
    z[3,2,0]  R1182     2.7180549502372742e-01
    z[3,2,0]  R1183     2.5965690612792969e-01
    z[3,2,0]  R1184     4.5168903470039368e-01
    z[3,2,0]  R1185     4.7862139344215393e-01
    z[3,2,0]  R1186     5.2210897207260132e-01
    z[3,2,0]  R1187     2.0533682405948639e-01
    z[3,2,0]  R1188     4.0825748443603516e-01
    z[3,2,0]  R1189     2.0486554503440857e-01
    z[3,2,0]  R1190     6.4479327201843262e-01
    z[3,2,0]  R1191     6.4287084341049194e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1125     -1
    z[3,2,1]  R1126     1
    z[3,2,1]  R1137     1.1947839707136154e-01
    z[3,2,1]  R1138     -0.65839684009552
    z[3,2,1]  R1139     -0.691955029964447
    z[3,2,1]  R1140     -5.5208396911621094e-01
    z[3,2,1]  R1141     -0.626633882522583
    z[3,2,1]  R1142     -4.1933557391166687e-01
    z[3,2,1]  R1143     0.064608134329319
    z[3,2,1]  R1144     -3.9330857992172241e-01
    z[3,2,1]  R1145     -0.666795015335083
    z[3,2,1]  R1146     -4.9973803758621216e-01
    z[3,2,1]  R1147     0.822810173034668
    z[3,2,1]  R1148     6.9742277264595032e-02
    z[3,2,1]  R1149     4.6270421147346497e-01
    z[3,2,1]  R1150     -0.0831177830696106
    z[3,2,1]  R1151     -5.0423705577850342e-01
    z[3,2,1]  R1152     -0.750278890132904
    z[3,2,1]  R1153     -0.671106219291687
    z[3,2,1]  R1154     -4.1270947456359863e-01
    z[3,2,1]  R1155     -6.1707812547683716e-01
    z[3,2,1]  R1156     -4.1638168692588806e-01
    z[3,2,1]  R1157     4.6346348524093628e-01
    z[3,2,1]  R1158     7.7009522914886475e-01
    z[3,2,1]  R1159     8.3872324228286743e-01
    z[3,2,1]  R1160     8.4543758630752563e-01
    z[3,2,1]  R1161     8.6298817396163940e-01
    z[3,2,1]  R1162     7.5134354829788208e-01
    z[3,2,1]  R1163     8.3110558986663818e-01
    z[3,2,1]  R1164     4.9972397089004517e-01
    z[3,2,1]  R1165     4.6165066957473755e-01
    z[3,2,1]  R1166     6.3231056928634644e-01
    z[3,2,1]  R1167     5.7388871908187866e-01
    z[3,2,1]  R1168     5.6774681806564331e-01
    z[3,2,1]  R1169     9.4949412345886230e-01
    z[3,2,1]  R1170     9.1691529750823975e-01
    z[3,2,1]  R1171     6.8674588203430176e-01
    z[3,2,1]  R1172     4.5204082131385803e-01
    z[3,2,1]  R1173     9.4661259651184082e-01
    z[3,2,1]  R1174     9.0046483278274536e-01
    z[3,2,1]  R1175     8.4820568561553955e-01
    z[3,2,1]  R1176     7.4543327093124390e-01
    z[3,2,1]  R1177     8.3941560983657837e-01
    z[3,2,1]  R1178     7.7500838041305542e-01
    z[3,2,1]  R1179     8.1515860557556152e-01
    z[3,2,1]  R1180     7.6194858551025391e-01
    z[3,2,1]  R1181     0.707585871219635
    z[3,2,1]  R1182     6.5791672468185425e-01
    z[3,2,1]  R1183     5.4883909225463867e-01
    z[3,2,1]  R1184     8.3625626564025879e-01
    z[3,2,1]  R1185     7.5414651632308960e-01
    z[3,2,1]  R1186     6.9773238897323608e-01
    z[3,2,1]  R1187     0.78978431224823
    z[3,2,1]  R1188     6.9925773143768311e-01
    z[3,2,1]  R1189     7.4881255626678467e-01
    z[3,2,1]  R1190     9.1009914875030518e-02
    z[3,2,1]  R1191     8.7913438677787781e-02
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1127     -1
    z[3,2,2]  R1128     1
    z[3,2,2]  R1137     -5.0464099645614624e-01
    z[3,2,2]  R1138     -4.3756082653999329e-01
    z[3,2,2]  R1139     -4.2218956351280212e-01
    z[3,2,2]  R1140     -3.9870855212211609e-01
    z[3,2,2]  R1141     -2.4444781243801117e-01
    z[3,2,2]  R1142     -7.1697455644607544e-01
    z[3,2,2]  R1143     -4.2742338031530380e-02
    z[3,2,2]  R1144     2.9280850291252136e-01
    z[3,2,2]  R1145     -3.2561093568801880e-01
    z[3,2,2]  R1146     7.9545283317565918e-01
    z[3,2,2]  R1147     3.1671860814094543e-01
    z[3,2,2]  R1148     1.6957861185073853e-01
    z[3,2,2]  R1149     3.2461118698120117e-01
    z[3,2,2]  R1150     2.1251462399959564e-01
    z[3,2,2]  R1151     4.9290871247649193e-03
    z[3,2,2]  R1152     -5.0815820693969727e-01
    z[3,2,2]  R1153     -4.2302456498146057e-01
    z[3,2,2]  R1154     -1.7271538078784943e-01
    z[3,2,2]  R1155     3.6518442630767822e-01
    z[3,2,2]  R1156     4.5311173796653748e-01
    z[3,2,2]  R1157     -5.6003034114837646e-01
    z[3,2,2]  R1158     1.2632903642952442e-02
    z[3,2,2]  R1159     2.2631423175334930e-01
    z[3,2,2]  R1160     0.0645333081483841
    z[3,2,2]  R1161     2.3833848536014557e-01
    z[3,2,2]  R1162     -5.6410312652587891e-01
    z[3,2,2]  R1163     -4.5141422748565674e-01
    z[3,2,2]  R1164     -3.5690742731094360e-01
    z[3,2,2]  R1165     -4.5796698331832886e-01
    z[3,2,2]  R1166     -6.8271929025650024e-01
    z[3,2,2]  R1167     -6.9360530376434326e-01
    z[3,2,2]  R1168     -5.2525812387466431e-01
    z[3,2,2]  R1169     1.9719203934073448e-02
    z[3,2,2]  R1170     6.9385424256324768e-02
    z[3,2,2]  R1171     -5.6376541033387184e-03
    z[3,2,2]  R1172     -2.7912083268165588e-01
    z[3,2,2]  R1173     2.6320907473564148e-01
    z[3,2,2]  R1174     5.5256552994251251e-02
    z[3,2,2]  R1175     3.1515088677406311e-01
    z[3,2,2]  R1176     1.2877109646797180e-01
    z[3,2,2]  R1177     -2.0384170114994049e-01
    z[3,2,2]  R1178     1.8829772248864174e-02
    z[3,2,2]  R1179     3.6813059449195862e-01
    z[3,2,2]  R1180     4.3131643533706665e-01
    z[3,2,2]  R1181     1.9450370222330093e-02
    z[3,2,2]  R1182     -6.0998445749282837e-01
    z[3,2,2]  R1183     -6.5625613927841187e-01
    z[3,2,2]  R1184     -1.3309018313884735e-01
    z[3,2,2]  R1185     2.6949909329414368e-01
    z[3,2,2]  R1186     -8.9618965983390808e-02
    z[3,2,2]  R1187     5.2157271653413773e-02
    z[3,2,2]  R1188     7.9599849879741669e-02
    z[3,2,2]  R1189     1.7099264264106750e-01
    z[3,2,2]  R1190     6.9347119331359863e-01
    z[3,2,2]  R1191     3.5757419466972351e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1129     -1
    z[3,2,3]  R1130     1
    z[3,2,3]  R1137     5.6319665908813477e-01
    z[3,2,3]  R1138     -1.0369183868169785e-01
    z[3,2,3]  R1139     -5.2761048078536987e-01
    z[3,2,3]  R1140     -4.3900772929191589e-02
    z[3,2,3]  R1141     1.8475079536437988e-01
    z[3,2,3]  R1142     3.5118627548217773e-01
    z[3,2,3]  R1143     3.1219440698623657e-01
    z[3,2,3]  R1144     -2.4333126842975616e-01
    z[3,2,3]  R1145     7.5939163565635681e-02
    z[3,2,3]  R1146     -1.5298357605934143e-01
    z[3,2,3]  R1147     7.3067627847194672e-02
    z[3,2,3]  R1148     5.9623247385025024e-01
    z[3,2,3]  R1149     -4.7412705421447754e-01
    z[3,2,3]  R1150     -0.594360888004303
    z[3,2,3]  R1151     -2.1659563481807709e-01
    z[3,2,3]  R1152     -2.5656517595052719e-02
    z[3,2,3]  R1153     1.0290110856294632e-01
    z[3,2,3]  R1154     -3.7951406836509705e-01
    z[3,2,3]  R1155     1.5847012400627136e-01
    z[3,2,3]  R1156     -9.5752961933612823e-02
    z[3,2,3]  R1157     1.2112659215927124e-01
    z[3,2,3]  R1158     -2.8817000985145569e-01
    z[3,2,3]  R1159     -1.2101585045456886e-02
    z[3,2,3]  R1160     -3.5101306438446045e-01
    z[3,2,3]  R1161     2.6030080392956734e-02
    z[3,2,3]  R1162     2.0595878362655640e-01
    z[3,2,3]  R1163     2.9962339997291565e-01
    z[3,2,3]  R1164     3.5861894488334656e-01
    z[3,2,3]  R1165     7.0065456628799438e-01
    z[3,2,3]  R1166     -2.4264791607856750e-01
    z[3,2,3]  R1167     -1.7299422621726990e-01
    z[3,2,3]  R1168     -1.3633483648300171e-01
    z[3,2,3]  R1169     2.0767839252948761e-01
    z[3,2,3]  R1170     -6.9356516178231686e-05
    z[3,2,3]  R1171     -1.2251529842615128e-01
    z[3,2,3]  R1172     8.1395357847213745e-01
    z[3,2,3]  R1173     1.0558506101369858e-01
    z[3,2,3]  R1174     -1.3593651354312897e-01
    z[3,2,3]  R1175     2.8788870573043823e-01
    z[3,2,3]  R1176     2.0491313934326172e-01
    z[3,2,3]  R1177     -1.5126244723796844e-01
    z[3,2,3]  R1178     2.3018684983253479e-01
    z[3,2,3]  R1179     3.3910858631134033e-01
    z[3,2,3]  R1180     0.0849059447646141
    z[3,2,3]  R1181     2.1504996716976166e-01
    z[3,2,3]  R1182     3.2789698243141174e-01
    z[3,2,3]  R1183     6.5549522638320923e-02
    z[3,2,3]  R1184     -2.1718624234199524e-01
    z[3,2,3]  R1185     -2.5616735219955444e-02
    z[3,2,3]  R1186     -3.9837455749511719e-01
    z[3,2,3]  R1187     3.6927703768014908e-02
    z[3,2,3]  R1188     3.8007974624633789e-01
    z[3,2,3]  R1189     -5.1780611276626587e-01
    z[3,2,3]  R1190     -0.0729045420885086
    z[3,2,3]  R1191     -1.4556339383125305e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1131     -1
    z[3,2,4]  R1132     1
    z[3,2,4]  R1137     1.7180059850215912e-01
    z[3,2,4]  R1138     -0.290390282869339
    z[3,2,4]  R1139     -1.2788760662078857e-01
    z[3,2,4]  R1140     3.1648221611976624e-01
    z[3,2,4]  R1141     2.4286733940243721e-02
    z[3,2,4]  R1142     -1.8562752008438110e-01
    z[3,2,4]  R1143     -8.5928475856781006e-01
    z[3,2,4]  R1144     3.1024357676506042e-01
    z[3,2,4]  R1145     -3.6562168598175049e-01
    z[3,2,4]  R1146     -1.3181759975850582e-02
    z[3,2,4]  R1147     2.3730356991291046e-01
    z[3,2,4]  R1148     4.6288302540779114e-01
    z[3,2,4]  R1149     -1.7594926059246063e-01
    z[3,2,4]  R1150     2.8487956523895264e-01
    z[3,2,4]  R1151     5.3741383552551270e-01
    z[3,2,4]  R1152     -1.5438847243785858e-01
    z[3,2,4]  R1153     -7.6973032264504582e-05
    z[3,2,4]  R1154     -3.3534789085388184e-01
    z[3,2,4]  R1155     -4.2755752801895142e-01
    z[3,2,4]  R1156     2.4388051033020020e-01
    z[3,2,4]  R1157     -2.8327324986457825e-01
    z[3,2,4]  R1158     -3.8198661059141159e-02
    z[3,2,4]  R1159     -3.8981625437736511e-01
    z[3,2,4]  R1160     -1.3761992752552032e-01
    z[3,2,4]  R1161     1.5958875417709351e-01
    z[3,2,4]  R1162     -1.5392169356346130e-01
    z[3,2,4]  R1163     3.6746963858604431e-02
    z[3,2,4]  R1164     -0.658660352230072
    z[3,2,4]  R1165     1.4881216920912266e-02
    z[3,2,4]  R1166     2.4512492120265961e-01
    z[3,2,4]  R1167     -4.6883486211299896e-02
    z[3,2,4]  R1168     -2.8469032049179077e-01
    z[3,2,4]  R1169     1.4053110778331757e-01
    z[3,2,4]  R1170     -9.3117050826549530e-02
    z[3,2,4]  R1171     2.6159879565238953e-01
    z[3,2,4]  R1172     -2.2049877047538757e-01
    z[3,2,4]  R1173     -5.9276461601257324e-02
    z[3,2,4]  R1174     -0.257587730884552
    z[3,2,4]  R1175     -1.1354881525039673e-01
    z[3,2,4]  R1176     -7.5281903147697449e-02
    z[3,2,4]  R1177     2.9876199364662170e-01
    z[3,2,4]  R1178     6.2722176313400269e-02
    z[3,2,4]  R1179     1.0926172882318497e-01
    z[3,2,4]  R1180     2.9511335492134094e-01
    z[3,2,4]  R1181     -7.2376020252704620e-02
    z[3,2,4]  R1182     -2.0937213674187660e-02
    z[3,2,4]  R1183     -1.9255377352237701e-01
    z[3,2,4]  R1184     2.1501084789633751e-02
    z[3,2,4]  R1185     -8.2156062126159668e-03
    z[3,2,4]  R1186     2.2068174183368683e-01
    z[3,2,4]  R1187     3.2346978783607483e-01
    z[3,2,4]  R1188     3.5036367177963257e-01
    z[3,2,4]  R1189     2.9226174950599670e-01
    z[3,2,4]  R1190     -5.6999187916517258e-02
    z[3,2,4]  R1191     2.0588155090808868e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1133     -1
    z[3,2,5]  R1134     1
    z[3,2,5]  R1137     -6.1394846439361572e-01
    z[3,2,5]  R1138     2.0823361352086067e-02
    z[3,2,5]  R1139     -1.9786822795867920e-01
    z[3,2,5]  R1140     -3.6314314603805542e-01
    z[3,2,5]  R1141     -3.8083171844482422e-01
    z[3,2,5]  R1142     1.3971579074859619e-01
    z[3,2,5]  R1143     2.1009135246276855e-01
    z[3,2,5]  R1144     -4.3233373761177063e-01
    z[3,2,5]  R1145     -1.3284134864807129e-01
    z[3,2,5]  R1146     2.7037004474550486e-03
    z[3,2,5]  R1147     0.0669000968337059
    z[3,2,5]  R1148     5.3333175182342529e-01
    z[3,2,5]  R1149     -5.1613062620162964e-01
    z[3,2,5]  R1150     3.9667895436286926e-01
    z[3,2,5]  R1151     4.8298445343971252e-01
    z[3,2,5]  R1152     -1.0144112259149551e-01
    z[3,2,5]  R1153     -0.460526704788208
    z[3,2,5]  R1154     -6.2519145011901855e-01
    z[3,2,5]  R1155     2.1900166571140289e-01
    z[3,2,5]  R1156     9.5428600907325745e-02
    z[3,2,5]  R1157     -1.0198953002691269e-01
    z[3,2,5]  R1158     -1.9380992650985718e-01
    z[3,2,5]  R1159     -6.1036027967929840e-02
    z[3,2,5]  R1160     -2.1970821544528008e-02
    z[3,2,5]  R1161     -9.4059586524963379e-02
    z[3,2,5]  R1162     -1.6372489929199219e-01
    z[3,2,5]  R1163     4.2902618646621704e-02
    z[3,2,5]  R1164     5.2850235253572464e-02
    z[3,2,5]  R1165     -1.5487061440944672e-01
    z[3,2,5]  R1166     -9.9672386422753334e-03
    z[3,2,5]  R1167     -1.5553395450115204e-01
    z[3,2,5]  R1168     4.0574066340923309e-02
    z[3,2,5]  R1169     -0.122328020632267
    z[3,2,5]  R1170     -3.4870034456253052e-01
    z[3,2,5]  R1171     1.8090550601482391e-01
    z[3,2,5]  R1172     -5.0910115242004395e-02
    z[3,2,5]  R1173     -1.6325891017913818e-02
    z[3,2,5]  R1174     0.0240008644759655
    z[3,2,5]  R1175     1.7423366010189056e-01
    z[3,2,5]  R1176     7.4190340936183929e-02
    z[3,2,5]  R1177     -3.4981764853000641e-02
    z[3,2,5]  R1178     4.1195428371429443e-01
    z[3,2,5]  R1179     -1.1364228278398514e-01
    z[3,2,5]  R1180     -8.9100472629070282e-02
    z[3,2,5]  R1181     -3.0492374300956726e-01
    z[3,2,5]  R1182     -1.1079335212707520e-01
    z[3,2,5]  R1183     5.3455509245395660e-02
    z[3,2,5]  R1184     -1.5185537934303284e-01
    z[3,2,5]  R1185     -1.5557087957859039e-01
    z[3,2,5]  R1186     1.5664680302143097e-01
    z[3,2,5]  R1187     3.6281082034111023e-01
    z[3,2,5]  R1188     -9.8257049918174744e-02
    z[3,2,5]  R1189     3.9560042321681976e-02
    z[3,2,5]  R1190     -1.9892990589141846e-01
    z[3,2,5]  R1191     -5.1982551813125610e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1135     -1
    z[3,2,6]  R1136     1
    z[3,2,6]  R1137     8.6160756647586823e-02
    z[3,2,6]  R1138     1.6605402529239655e-01
    z[3,2,6]  R1139     -2.0802492275834084e-02
    z[3,2,6]  R1140     -2.6933647692203522e-02
    z[3,2,6]  R1141     3.9008951187133789e-01
    z[3,2,6]  R1142     -3.8659039884805679e-02
    z[3,2,6]  R1143     2.8735810518264771e-01
    z[3,2,6]  R1144     -6.3604766130447388e-01
    z[3,2,6]  R1145     -1.3491220772266388e-01
    z[3,2,6]  R1146     -3.0646494030952454e-01
    z[3,2,6]  R1147     -2.3540496826171875e-01
    z[3,2,6]  R1148     2.9689380899071693e-02
    z[3,2,6]  R1149     2.5936502218246460e-01
    z[3,2,6]  R1150     4.7487938404083252e-01
    z[3,2,6]  R1151     3.8391733169555664e-01
    z[3,2,6]  R1152     1.5722465515136719e-01
    z[3,2,6]  R1153     -3.8445958495140076e-01
    z[3,2,6]  R1154     -0.14777772128582
    z[3,2,6]  R1155     1.4122481644153595e-01
    z[3,2,6]  R1156     2.7494275569915771e-01
    z[3,2,6]  R1157     -1.5206019580364227e-01
    z[3,2,6]  R1158     -2.1245667338371277e-01
    z[3,2,6]  R1159     -6.7172899842262268e-02
    z[3,2,6]  R1160     3.5336604714393616e-01
    z[3,2,6]  R1161     1.5318599343299866e-01
    z[3,2,6]  R1162     -1.1770993471145630e-01
    z[3,2,6]  R1163     5.9793557971715927e-02
    z[3,2,6]  R1164     1.7707526683807373e-01
    z[3,2,6]  R1165     2.1222686767578125e-01
    z[3,2,6]  R1166     1.1529105901718140e-01
    z[3,2,6]  R1167     3.6482852697372437e-01
    z[3,2,6]  R1168     0.533686101436615
    z[3,2,6]  R1169     1.2279906868934631e-01
    z[3,2,6]  R1170     1.5007475018501282e-01
    z[3,2,6]  R1171     -1.1907586455345154e-01
    z[3,2,6]  R1172     -5.7666312903165817e-02
    z[3,2,6]  R1173     1.2325332313776016e-01
    z[3,2,6]  R1174     7.8757822513580322e-02
    z[3,2,6]  R1175     5.3811889141798019e-02
    z[3,2,6]  R1176     -2.1906213462352753e-01
    z[3,2,6]  R1177     5.9291366487741470e-02
    z[3,2,6]  R1178     2.1339060366153717e-01
    z[3,2,6]  R1179     -1.5584947168827057e-01
    z[3,2,6]  R1180     -2.2106464207172394e-01
    z[3,2,6]  R1181     -3.6798080801963806e-01
    z[3,2,6]  R1182     -3.0925212427973747e-02
    z[3,2,6]  R1183     -3.9553830027580261e-01
    z[3,2,6]  R1184     -9.0814061462879181e-02
    z[3,2,6]  R1185     -3.2346379756927490e-01
    z[3,2,6]  R1186     2.4477085098624229e-02
    z[3,2,6]  R1187     3.0615216493606567e-01
    z[3,2,6]  R1188     -2.4730274081230164e-01
    z[3,2,6]  R1189     1.1387012898921967e-01
    z[3,2,6]  R1190     2.1660865843296051e-01
    z[3,2,6]  R1191     3.4254112839698792e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1192     -1
    z[2,6,0]  R1193     1
    z[2,6,0]  R1206     -3.4547504782676697e-01
    z[2,6,0]  R1207     1.3561316765844822e-02
    z[2,6,0]  R1208     -3.6145329475402832e-01
    z[2,6,0]  R1209     -4.5829087495803833e-01
    z[2,6,0]  R1210     -0.684083104133606
    z[2,6,0]  R1211     5.8577132225036621e-01
    z[2,6,0]  R1212     4.8948177695274353e-01
    z[2,6,0]  R1213     2.9152107238769531e-01
    z[2,6,0]  R1214     1.1649436503648758e-01
    z[2,6,0]  R1215     3.7414813041687012e-01
    z[2,6,0]  R1216     -1.0246091336011887e-01
    z[2,6,0]  R1217     9.4595164060592651e-02
    z[2,6,0]  R1218     1.6218294203281403e-01
    z[2,6,0]  R1219     -1.3031384348869324e-01
    z[2,6,0]  R1220     -4.1496995836496353e-02
    z[2,6,0]  R1221     1.2153500691056252e-02
    z[2,6,0]  R1222     -1.2515839934349060e-01
    z[2,6,0]  R1223     7.1756877005100250e-02
    z[2,6,0]  R1224     -4.0827151387929916e-02
    z[2,6,0]  R1225     6.3087129592895508e-01
    z[2,6,0]  R1226     2.6328464969992638e-02
    z[2,6,0]  R1227     6.7273631691932678e-02
    z[2,6,0]  R1228     3.0740952491760254e-01
    z[2,6,0]  R1229     2.2847460210323334e-01
    z[2,6,0]  R1230     0.571487545967102
    z[2,6,0]  R1231     3.7006980180740356e-01
    z[2,6,0]  R1232     3.5615384578704834e-01
    z[2,6,0]  R1233     1.8936680257320404e-01
    z[2,6,0]  R1234     2.8686422109603882e-01
    z[2,6,0]  R1235     4.6804994344711304e-01
    z[2,6,0]  R1236     2.7180549502372742e-01
    z[2,6,0]  R1237     2.5965690612792969e-01
    z[2,6,0]  R1238     4.5168903470039368e-01
    z[2,6,0]  R1239     4.7862139344215393e-01
    z[2,6,0]  R1240     5.2210897207260132e-01
    z[2,6,0]  R1241     2.0533682405948639e-01
    z[2,6,0]  R1242     4.0825748443603516e-01
    z[2,6,0]  R1243     2.0486554503440857e-01
    z[2,6,0]  R1244     6.4479327201843262e-01
    z[2,6,0]  R1245     6.4287084341049194e-01
    z[2,6,0]  R1246     -8.7384122610092163e-01
    z[2,6,0]  R1247     -8.8748365640640259e-01
    z[2,6,0]  R1248     -9.4941294193267822e-01
    z[2,6,0]  R1249     -8.5786253213882446e-01
    z[2,6,0]  R1250     -9.1623759269714355e-01
    z[2,6,0]  R1251     -7.2450643777847290e-01
    z[2,6,0]  R1252     -9.3621307611465454e-01
    z[2,6,0]  R1253     -0.96856290102005
    z[2,6,0]  R1254     -8.3268773555755615e-01
    z[2,6,0]  R1255     -8.0606764554977417e-01
    z[2,6,0]  R1256     2.0103774964809418e-01
    z[2,6,0]  R1257     2.1778398752212524e-01
    z[2,6,0]  R1258     1.9404245913028717e-01
    z[2,6,0]  R1259     -0.0822681114077568
    z[2,6,0]  R1260     -2.5601822417229414e-03
    z[2,6,0]  R1261     2.5686609745025635e-01
    z[2,6,0]  R1262     2.3033238947391510e-01
    z[2,6,0]  R1263     3.1332874298095703e-01
    z[2,6,0]  R1264     -1.5054904855787754e-02
    z[2,6,0]  R1265     1.5797884762287140e-01
    z[2,6,0]  R1266     8.2420194149017334e-01
    z[2,6,0]  R1267     4.1432134807109833e-02
    z[2,6,0]  R1268     0.51854008436203
    z[2,6,0]  R1269     7.2541677951812744e-01
    z[2,6,0]  R1270     5.0932067632675171e-01
    z[2,6,0]  R1271     5.2500754594802856e-01
    z[2,6,0]  R1272     3.7646532058715820e-01
    z[2,6,0]  R1273     7.7187612652778625e-02
    z[2,6,0]  R1274     5.5519080162048340e-01
    z[2,6,0]  R1275     1.7107808589935303e-01
    z[2,6,0]  R1276     5.8747440576553345e-01
    z[2,6,0]  R1277     0.787808895111084
    z[2,6,0]  R1278     -1.2902888655662537e-01
    z[2,6,0]  R1279     7.3995554447174072e-01
    z[2,6,0]  R1280     1.4056351780891418e-01
    z[2,6,0]  R1281     6.9226735830307007e-01
    z[2,6,0]  R1282     2.5577588006854057e-02
    z[2,6,0]  R1283     8.1297689676284790e-01
    z[2,6,0]  R1284     5.6801873445510864e-01
    z[2,6,0]  R1285     -2.2160109877586365e-01
    z[2,6,0]  R1286     -1.0260418057441711e-03
    z[2,6,0]  R1287     3.2716092467308044e-01
    z[2,6,0]  R1288     4.2324984073638916e-01
    z[2,6,0]  R1289     4.8220828175544739e-02
    z[2,6,0]  R1290     0.618370532989502
    z[2,6,0]  R1291     5.8190727233886719e-01
    z[2,6,0]  R1292     3.2456271350383759e-02
    z[2,6,0]  R1293     -2.7239865064620972e-01
    z[2,6,0]  R1294     -3.8483291864395142e-01
    z[2,6,0]  R1295     7.6029294729232788e-01
    z[2,6,0]  R1296     -7.7624571323394775e-01
    z[2,6,0]  R1297     7.8828144073486328e-01
    z[2,6,0]  R1298     6.0670781135559082e-01
    z[2,6,0]  R1299     1.2974782288074493e-01
    z[2,6,0]  R1300     4.8424193263053894e-01
    z[2,6,0]  R1301     5.4049581289291382e-01
    z[2,6,0]  R1302     5.2734637260437012e-01
    z[2,6,0]  R1303     5.1648199558258057e-01
    z[2,6,0]  R1304     -3.5389885306358337e-01
    z[2,6,0]  R1305     0.0541507862508297
    z[2,6,0]  R1306     4.1410472989082336e-01
    z[2,6,0]  R1307     1.3840852305293083e-02
    z[2,6,0]  R1308     8.0886858701705933e-01
    z[2,6,0]  R1309     -4.1802600026130676e-01
    z[2,6,0]  R1310     -4.2783138155937195e-01
    z[2,6,0]  R1311     4.6446800231933594e-01
    z[2,6,0]  R1312     7.1531379222869873e-01
    z[2,6,0]  R1313     5.2551430463790894e-01
    z[2,6,0]  R1314     -3.5186198353767395e-01
    z[2,6,0]  R1315     7.0942497253417969e-01
    z[2,6,0]  R1316     8.9145672321319580e-01
    z[2,6,0]  R1317     4.3067368865013123e-01
    z[2,6,0]  R1318     -2.3954921960830688e-01
    z[2,6,0]  R1319     -5.8236384391784668e-01
    z[2,6,0]  R1320     6.2779515981674194e-01
    z[2,6,0]  R1321     5.2663028240203857e-01
    z[2,6,0]  R1322     4.8508965969085693e-01
    z[2,6,0]  R1323     8.4526282548904419e-01
    z[2,6,0]  R1324     -4.7784465551376343e-01
    z[2,6,0]  R1325     1.4369764365255833e-02
    z[2,6,0]  R1326     -7.4734479188919067e-01
    z[2,6,0]  R1327     6.1633431911468506e-01
    z[2,6,0]  R1328     0.401021271944046
    z[2,6,0]  R1329     4.8296386003494263e-01
    z[2,6,0]  R1330     0.680448055267334
    z[2,6,0]  R1331     -3.7621328234672546e-01
    z[2,6,0]  R1332     1.2038894742727280e-01
    z[2,6,0]  R1333     -1.7895002383738756e-04
    z[2,6,0]  R1334     -8.2989625632762909e-02
    z[2,6,0]  R1335     -2.8991684317588806e-02
    z[2,6,0]  R1336     -0.743486762046814
    z[2,6,0]  R1337     7.0977705717086792e-01
    z[2,6,0]  R1338     5.7753592729568481e-01
    z[2,6,0]  R1339     4.3028134107589722e-01
    z[2,6,0]  R1340     1.7088226974010468e-01
    z[2,6,0]  R1341     6.7804497666656971e-03
    z[2,6,0]  R1342     -6.1569139361381531e-02
    z[2,6,0]  R1343     3.5309992730617523e-02
    z[2,6,0]  R1344     -1.1695101112127304e-01
    z[2,6,0]  R1345     -4.5996751636266708e-02
    z[2,6,0]  R1346     7.2832182049751282e-03
    z[2,6,0]  R1347     6.1436778306961060e-01
    z[2,6,0]  R1348     5.5816221237182617e-01
    z[2,6,0]  R1349     -4.5648229122161865e-01
    z[2,6,0]  R1350     -3.2614029943943024e-02
    z[2,6,0]  R1351     -2.6928958296775818e-01
    z[2,6,0]  R1352     -1.3647805154323578e-01
    z[2,6,0]  R1353     2.3611165583133698e-02
    z[2,6,0]  R1354     -6.7060112953186035e-02
    z[2,6,0]  R1355     -0.0773346871137619
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1194     -1
    z[2,6,1]  R1195     1
    z[2,6,1]  R1206     -0.750278890132904
    z[2,6,1]  R1207     -0.671106219291687
    z[2,6,1]  R1208     -4.1270947456359863e-01
    z[2,6,1]  R1209     -6.1707812547683716e-01
    z[2,6,1]  R1210     -4.1638168692588806e-01
    z[2,6,1]  R1211     4.6346348524093628e-01
    z[2,6,1]  R1212     7.7009522914886475e-01
    z[2,6,1]  R1213     8.3872324228286743e-01
    z[2,6,1]  R1214     8.4543758630752563e-01
    z[2,6,1]  R1215     8.6298817396163940e-01
    z[2,6,1]  R1216     7.5134354829788208e-01
    z[2,6,1]  R1217     8.3110558986663818e-01
    z[2,6,1]  R1218     4.9972397089004517e-01
    z[2,6,1]  R1219     4.6165066957473755e-01
    z[2,6,1]  R1220     6.3231056928634644e-01
    z[2,6,1]  R1221     5.7388871908187866e-01
    z[2,6,1]  R1222     5.6774681806564331e-01
    z[2,6,1]  R1223     9.4949412345886230e-01
    z[2,6,1]  R1224     9.1691529750823975e-01
    z[2,6,1]  R1225     6.8674588203430176e-01
    z[2,6,1]  R1226     4.5204082131385803e-01
    z[2,6,1]  R1227     9.4661259651184082e-01
    z[2,6,1]  R1228     9.0046483278274536e-01
    z[2,6,1]  R1229     8.4820568561553955e-01
    z[2,6,1]  R1230     7.4543327093124390e-01
    z[2,6,1]  R1231     8.3941560983657837e-01
    z[2,6,1]  R1232     7.7500838041305542e-01
    z[2,6,1]  R1233     8.1515860557556152e-01
    z[2,6,1]  R1234     7.6194858551025391e-01
    z[2,6,1]  R1235     0.707585871219635
    z[2,6,1]  R1236     6.5791672468185425e-01
    z[2,6,1]  R1237     5.4883909225463867e-01
    z[2,6,1]  R1238     8.3625626564025879e-01
    z[2,6,1]  R1239     7.5414651632308960e-01
    z[2,6,1]  R1240     6.9773238897323608e-01
    z[2,6,1]  R1241     0.78978431224823
    z[2,6,1]  R1242     6.9925773143768311e-01
    z[2,6,1]  R1243     7.4881255626678467e-01
    z[2,6,1]  R1244     9.1009914875030518e-02
    z[2,6,1]  R1245     8.7913438677787781e-02
    z[2,6,1]  R1246     -3.8983193039894104e-01
    z[2,6,1]  R1247     -3.6499857902526855e-01
    z[2,6,1]  R1248     -2.1544776856899261e-02
    z[2,6,1]  R1249     -6.8940952420234680e-02
    z[2,6,1]  R1250     -1.2151963263750076e-01
    z[2,6,1]  R1251     -5.3895201534032822e-02
    z[2,6,1]  R1252     3.3995623234659433e-03
    z[2,6,1]  R1253     -6.3452741596847773e-04
    z[2,6,1]  R1254     2.7241089940071106e-01
    z[2,6,1]  R1255     -2.8118479251861572e-01
    z[2,6,1]  R1256     -5.0241601467132568e-01
    z[2,6,1]  R1257     -1.9956082105636597e-01
    z[2,6,1]  R1258     -5.9879440069198608e-01
    z[2,6,1]  R1259     -7.0977377891540527e-01
    z[2,6,1]  R1260     -4.8572760820388794e-01
    z[2,6,1]  R1261     -5.2118331193923950e-01
    z[2,6,1]  R1262     -6.8679213523864746e-02
    z[2,6,1]  R1263     -5.8934754133224487e-01
    z[2,6,1]  R1264     -4.0870368480682373e-01
    z[2,6,1]  R1265     -5.2850800752639771e-01
    z[2,6,1]  R1266     -3.1171565875411034e-02
    z[2,6,1]  R1267     -9.5037811994552612e-01
    z[2,6,1]  R1268     3.0611717700958252e-01
    z[2,6,1]  R1269     1.5424132347106934e-01
    z[2,6,1]  R1270     -9.2823922634124756e-02
    z[2,6,1]  R1271     3.5708022117614746e-01
    z[2,6,1]  R1272     -5.2102571725845337e-01
    z[2,6,1]  R1273     6.6686397790908813e-01
    z[2,6,1]  R1274     -1.4312581717967987e-01
    z[2,6,1]  R1275     6.0229659080505371e-01
    z[2,6,1]  R1276     -3.4938564896583557e-01
    z[2,6,1]  R1277     1.5225054323673248e-01
    z[2,6,1]  R1278     -7.8362977504730225e-01
    z[2,6,1]  R1279     0.045985147356987
    z[2,6,1]  R1280     -8.9270532131195068e-01
    z[2,6,1]  R1281     1.0074172914028168e-01
    z[2,6,1]  R1282     -6.3061875104904175e-01
    z[2,6,1]  R1283     -3.0362397432327271e-01
    z[2,6,1]  R1284     1.2596595287322998e-01
    z[2,6,1]  R1285     -5.5027091503143311e-01
    z[2,6,1]  R1286     -7.6516550779342651e-01
    z[2,6,1]  R1287     -8.8505178689956665e-01
    z[2,6,1]  R1288     -5.2559173107147217e-01
    z[2,6,1]  R1289     -0.89644455909729
    z[2,6,1]  R1290     2.1496775746345520e-01
    z[2,6,1]  R1291     -2.3313325643539429e-01
    z[2,6,1]  R1292     -7.7686858177185059e-01
    z[2,6,1]  R1293     -5.5272829532623291e-01
    z[2,6,1]  R1294     -1.3243253529071808e-01
    z[2,6,1]  R1295     -3.7105970084667206e-02
    z[2,6,1]  R1296     -2.6720070838928223e-01
    z[2,6,1]  R1297     -3.0520877242088318e-01
    z[2,6,1]  R1298     -4.4281157851219177e-01
    z[2,6,1]  R1299     -4.7522720694541931e-01
    z[2,6,1]  R1300     -1.7094098031520844e-01
    z[2,6,1]  R1301     -1.9637905061244965e-01
    z[2,6,1]  R1302     -4.5808512717485428e-02
    z[2,6,1]  R1303     2.2161212563514709e-01
    z[2,6,1]  R1304     7.5454115867614746e-01
    z[2,6,1]  R1305     8.6229842901229858e-01
    z[2,6,1]  R1306     -2.6137259602546692e-01
    z[2,6,1]  R1307     -6.7997843027114868e-01
    z[2,6,1]  R1308     1.7777520418167114e-01
    z[2,6,1]  R1309     -6.4122051000595093e-01
    z[2,6,1]  R1310     -0.055446557700634
    z[2,6,1]  R1311     -2.7222353219985962e-01
    z[2,6,1]  R1312     -2.6235067844390869e-01
    z[2,6,1]  R1313     -1.5870186686515808e-01
    z[2,6,1]  R1314     1.6907547414302826e-01
    z[2,6,1]  R1315     2.0996022969484329e-02
    z[2,6,1]  R1316     -1.4200265705585480e-01
    z[2,6,1]  R1317     -3.0012896656990051e-01
    z[2,6,1]  R1318     -7.6789957284927368e-01
    z[2,6,1]  R1319     -5.6674383580684662e-02
    z[2,6,1]  R1320     -1.9198960065841675e-01
    z[2,6,1]  R1321     -1.4512595720589161e-02
    z[2,6,1]  R1322     3.6846555769443512e-02
    z[2,6,1]  R1323     2.8690424561500549e-01
    z[2,6,1]  R1324     4.8175626993179321e-01
    z[2,6,1]  R1325     7.9874765872955322e-01
    z[2,6,1]  R1326     -1.4394551515579224e-02
    z[2,6,1]  R1327     -3.0781856179237366e-01
    z[2,6,1]  R1328     -2.7524015307426453e-01
    z[2,6,1]  R1329     -2.0112356543540955e-01
    z[2,6,1]  R1330     1.0570946335792542e-01
    z[2,6,1]  R1331     -1.8369263410568237e-01
    z[2,6,1]  R1332     5.2311939001083374e-01
    z[2,6,1]  R1333     7.2564291954040527e-01
    z[2,6,1]  R1334     7.3291534185409546e-01
    z[2,6,1]  R1335     8.1506699323654175e-01
    z[2,6,1]  R1336     9.3010291457176208e-02
    z[2,6,1]  R1337     -1.8123178184032440e-01
    z[2,6,1]  R1338     -0.145138680934906
    z[2,6,1]  R1339     -2.4333159625530243e-01
    z[2,6,1]  R1340     -4.8579236865043640e-01
    z[2,6,1]  R1341     6.5936404466629028e-01
    z[2,6,1]  R1342     6.2111669778823853e-01
    z[2,6,1]  R1343     0.584827721118927
    z[2,6,1]  R1344     8.8545787334442139e-01
    z[2,6,1]  R1345     8.1723350286483765e-01
    z[2,6,1]  R1346     -4.9319869279861450e-01
    z[2,6,1]  R1347     -1.6294093430042267e-01
    z[2,6,1]  R1348     -5.0169759988784790e-01
    z[2,6,1]  R1349     -3.1170082092285156e-01
    z[2,6,1]  R1350     9.1450905799865723e-01
    z[2,6,1]  R1351     8.0454438924789429e-01
    z[2,6,1]  R1352     0.808972954750061
    z[2,6,1]  R1353     6.4437693357467651e-01
    z[2,6,1]  R1354     6.1878538131713867e-01
    z[2,6,1]  R1355     0.753345787525177
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1196     -1
    z[2,6,2]  R1197     1
    z[2,6,2]  R1206     -5.0815820693969727e-01
    z[2,6,2]  R1207     -4.2302456498146057e-01
    z[2,6,2]  R1208     -1.7271538078784943e-01
    z[2,6,2]  R1209     3.6518442630767822e-01
    z[2,6,2]  R1210     4.5311173796653748e-01
    z[2,6,2]  R1211     -5.6003034114837646e-01
    z[2,6,2]  R1212     1.2632903642952442e-02
    z[2,6,2]  R1213     2.2631423175334930e-01
    z[2,6,2]  R1214     0.0645333081483841
    z[2,6,2]  R1215     2.3833848536014557e-01
    z[2,6,2]  R1216     -5.6410312652587891e-01
    z[2,6,2]  R1217     -4.5141422748565674e-01
    z[2,6,2]  R1218     -3.5690742731094360e-01
    z[2,6,2]  R1219     -4.5796698331832886e-01
    z[2,6,2]  R1220     -6.8271929025650024e-01
    z[2,6,2]  R1221     -6.9360530376434326e-01
    z[2,6,2]  R1222     -5.2525812387466431e-01
    z[2,6,2]  R1223     1.9719203934073448e-02
    z[2,6,2]  R1224     6.9385424256324768e-02
    z[2,6,2]  R1225     -5.6376541033387184e-03
    z[2,6,2]  R1226     -2.7912083268165588e-01
    z[2,6,2]  R1227     2.6320907473564148e-01
    z[2,6,2]  R1228     5.5256552994251251e-02
    z[2,6,2]  R1229     3.1515088677406311e-01
    z[2,6,2]  R1230     1.2877109646797180e-01
    z[2,6,2]  R1231     -2.0384170114994049e-01
    z[2,6,2]  R1232     1.8829772248864174e-02
    z[2,6,2]  R1233     3.6813059449195862e-01
    z[2,6,2]  R1234     4.3131643533706665e-01
    z[2,6,2]  R1235     1.9450370222330093e-02
    z[2,6,2]  R1236     -6.0998445749282837e-01
    z[2,6,2]  R1237     -6.5625613927841187e-01
    z[2,6,2]  R1238     -1.3309018313884735e-01
    z[2,6,2]  R1239     2.6949909329414368e-01
    z[2,6,2]  R1240     -8.9618965983390808e-02
    z[2,6,2]  R1241     5.2157271653413773e-02
    z[2,6,2]  R1242     7.9599849879741669e-02
    z[2,6,2]  R1243     1.7099264264106750e-01
    z[2,6,2]  R1244     6.9347119331359863e-01
    z[2,6,2]  R1245     3.5757419466972351e-01
    z[2,6,2]  R1246     -1.7520034313201904e-01
    z[2,6,2]  R1247     -1.1685901880264282e-01
    z[2,6,2]  R1248     -1.6333484649658203e-01
    z[2,6,2]  R1249     -2.6785880327224731e-01
    z[2,6,2]  R1250     -1.8257641792297363e-01
    z[2,6,2]  R1251     -5.3789663314819336e-01
    z[2,6,2]  R1252     -1.7760933935642242e-01
    z[2,6,2]  R1253     -1.7945638298988342e-01
    z[2,6,2]  R1254     -3.8195076584815979e-01
    z[2,6,2]  R1255     -0.0339924618601799
    z[2,6,2]  R1256     2.8260305523872375e-01
    z[2,6,2]  R1257     7.1075963973999023e-01
    z[2,6,2]  R1258     6.8378818035125732e-01
    z[2,6,2]  R1259     5.4878199100494385e-01
    z[2,6,2]  R1260     4.9439480900764465e-01
    z[2,6,2]  R1261     6.2343740463256836e-01
    z[2,6,2]  R1262     5.0190275907516479e-01
    z[2,6,2]  R1263     4.8393711447715759e-01
    z[2,6,2]  R1264     3.8058194518089294e-01
    z[2,6,2]  R1265     4.3565174937248230e-01
    z[2,6,2]  R1266     3.2944139838218689e-01
    z[2,6,2]  R1267     -1.5970049798488617e-01
    z[2,6,2]  R1268     6.8351435661315918e-01
    z[2,6,2]  R1269     2.4656991660594940e-01
    z[2,6,2]  R1270     1.1712289601564407e-01
    z[2,6,2]  R1271     6.8361848592758179e-01
    z[2,6,2]  R1272     -1.3215051591396332e-01
    z[2,6,2]  R1273     -6.0098522901535034e-01
    z[2,6,2]  R1274     4.9145266413688660e-01
    z[2,6,2]  R1275     -0.706415057182312
    z[2,6,2]  R1276     3.1549575924873352e-01
    z[2,6,2]  R1277     3.8917210698127747e-01
    z[2,6,2]  R1278     4.1174092888832092e-01
    z[2,6,2]  R1279     3.1450986862182617e-01
    z[2,6,2]  R1280     4.2288318276405334e-02
    z[2,6,2]  R1281     6.3316076993942261e-01
    z[2,6,2]  R1282     2.1973705291748047e-01
    z[2,6,2]  R1283     -5.7728279381990433e-02
    z[2,6,2]  R1284     7.7076196670532227e-01
    z[2,6,2]  R1285     2.6455268263816833e-01
    z[2,6,2]  R1286     4.2389449477195740e-01
    z[2,6,2]  R1287     2.2439652681350708e-01
    z[2,6,2]  R1288     6.4922392368316650e-01
    z[2,6,2]  R1289     1.6333243250846863e-01
    z[2,6,2]  R1290     5.4032075405120850e-01
    z[2,6,2]  R1291     -1.8255543708801270e-01
    z[2,6,2]  R1292     3.0196553096175194e-02
    z[2,6,2]  R1293     0.215520977973938
    z[2,6,2]  R1294     -6.1001914739608765e-01
    z[2,6,2]  R1295     8.8725559413433075e-02
    z[2,6,2]  R1296     -2.3672574758529663e-01
    z[2,6,2]  R1297     2.5989213585853577e-01
    z[2,6,2]  R1298     1.6411387920379639e-01
    z[2,6,2]  R1299     2.8355222940444946e-01
    z[2,6,2]  R1300     9.0234234929084778e-02
    z[2,6,2]  R1301     -1.9573102891445160e-01
    z[2,6,2]  R1302     4.8574164509773254e-01
    z[2,6,2]  R1303     6.5591341257095337e-01
    z[2,6,2]  R1304     -3.4801873564720154e-01
    z[2,6,2]  R1305     -4.6952879428863525e-01
    z[2,6,2]  R1306     6.7564022541046143e-01
    z[2,6,2]  R1307     1.2817643582820892e-03
    z[2,6,2]  R1308     4.2216774821281433e-01
    z[2,6,2]  R1309     1.5791609883308411e-01
    z[2,6,2]  R1310     -7.6735556125640869e-01
    z[2,6,2]  R1311     2.5689122080802917e-01
    z[2,6,2]  R1312     0.395819753408432
    z[2,6,2]  R1313     2.0394693315029144e-01
    z[2,6,2]  R1314     -6.5956008434295654e-01
    z[2,6,2]  R1315     0.0963897705078125
    z[2,6,2]  R1316     2.1616187691688538e-01
    z[2,6,2]  R1317     3.8360023498535156e-01
    z[2,6,2]  R1318     0.522737979888916
    z[2,6,2]  R1319     -5.8665275573730469e-01
    z[2,6,2]  R1320     0.257693350315094
    z[2,6,2]  R1321     5.1851803064346313e-01
    z[2,6,2]  R1322     3.2036128640174866e-01
    z[2,6,2]  R1323     3.1420376896858215e-01
    z[2,6,2]  R1324     -4.5502316951751709e-01
    z[2,6,2]  R1325     -4.5573037862777710e-01
    z[2,6,2]  R1326     -6.1263483762741089e-01
    z[2,6,2]  R1327     3.7518495321273804e-01
    z[2,6,2]  R1328     4.6717628836631775e-01
    z[2,6,2]  R1329     2.9142412543296814e-01
    z[2,6,2]  R1330     3.8473892211914062e-01
    z[2,6,2]  R1331     4.9168238043785095e-01
    z[2,6,2]  R1332     -8.2693254947662354e-01
    z[2,6,2]  R1333     -3.9073020219802856e-01
    z[2,6,2]  R1334     -0.315792053937912
    z[2,6,2]  R1335     -1.5693803131580353e-01
    z[2,6,2]  R1336     -0.431908518075943
    z[2,6,2]  R1337     4.6711099147796631e-01
    z[2,6,2]  R1338     5.1746422052383423e-01
    z[2,6,2]  R1339     1.6701912879943848e-01
    z[2,6,2]  R1340     2.2287330031394958e-01
    z[2,6,2]  R1341     -6.4267307519912720e-01
    z[2,6,2]  R1342     -5.4743212461471558e-01
    z[2,6,2]  R1343     -5.9905093908309937e-01
    z[2,6,2]  R1344     3.9783951640129089e-01
    z[2,6,2]  R1345     5.3042483329772949e-01
    z[2,6,2]  R1346     6.0604417324066162e-01
    z[2,6,2]  R1347     1.0132411122322083e-01
    z[2,6,2]  R1348     2.7886566519737244e-01
    z[2,6,2]  R1349     -4.7770851850509644e-01
    z[2,6,2]  R1350     -3.4008646011352539e-01
    z[2,6,2]  R1351     3.9407119154930115e-01
    z[2,6,2]  R1352     4.1896224021911621e-01
    z[2,6,2]  R1353     5.4252862930297852e-01
    z[2,6,2]  R1354     5.3949481248855591e-01
    z[2,6,2]  R1355     3.8305473327636719e-01
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1198     -1
    z[2,6,3]  R1199     1
    z[2,6,3]  R1206     -2.5656517595052719e-02
    z[2,6,3]  R1207     1.0290110856294632e-01
    z[2,6,3]  R1208     -3.7951406836509705e-01
    z[2,6,3]  R1209     1.5847012400627136e-01
    z[2,6,3]  R1210     -9.5752961933612823e-02
    z[2,6,3]  R1211     1.2112659215927124e-01
    z[2,6,3]  R1212     -2.8817000985145569e-01
    z[2,6,3]  R1213     -1.2101585045456886e-02
    z[2,6,3]  R1214     -3.5101306438446045e-01
    z[2,6,3]  R1215     2.6030080392956734e-02
    z[2,6,3]  R1216     2.0595878362655640e-01
    z[2,6,3]  R1217     2.9962339997291565e-01
    z[2,6,3]  R1218     3.5861894488334656e-01
    z[2,6,3]  R1219     7.0065456628799438e-01
    z[2,6,3]  R1220     -2.4264791607856750e-01
    z[2,6,3]  R1221     -1.7299422621726990e-01
    z[2,6,3]  R1222     -1.3633483648300171e-01
    z[2,6,3]  R1223     2.0767839252948761e-01
    z[2,6,3]  R1224     -6.9356516178231686e-05
    z[2,6,3]  R1225     -1.2251529842615128e-01
    z[2,6,3]  R1226     8.1395357847213745e-01
    z[2,6,3]  R1227     1.0558506101369858e-01
    z[2,6,3]  R1228     -1.3593651354312897e-01
    z[2,6,3]  R1229     2.8788870573043823e-01
    z[2,6,3]  R1230     2.0491313934326172e-01
    z[2,6,3]  R1231     -1.5126244723796844e-01
    z[2,6,3]  R1232     2.3018684983253479e-01
    z[2,6,3]  R1233     3.3910858631134033e-01
    z[2,6,3]  R1234     0.0849059447646141
    z[2,6,3]  R1235     2.1504996716976166e-01
    z[2,6,3]  R1236     3.2789698243141174e-01
    z[2,6,3]  R1237     6.5549522638320923e-02
    z[2,6,3]  R1238     -2.1718624234199524e-01
    z[2,6,3]  R1239     -2.5616735219955444e-02
    z[2,6,3]  R1240     -3.9837455749511719e-01
    z[2,6,3]  R1241     3.6927703768014908e-02
    z[2,6,3]  R1242     3.8007974624633789e-01
    z[2,6,3]  R1243     -5.1780611276626587e-01
    z[2,6,3]  R1244     -0.0729045420885086
    z[2,6,3]  R1245     -1.4556339383125305e-01
    z[2,6,3]  R1246     1.9722686707973480e-01
    z[2,6,3]  R1247     -1.7805849015712738e-01
    z[2,6,3]  R1248     -1.3938149809837341e-01
    z[2,6,3]  R1249     3.1448623538017273e-01
    z[2,6,3]  R1250     0.00422905758023262
    z[2,6,3]  R1251     3.0133891850709915e-02
    z[2,6,3]  R1252     -5.1916502416133881e-02
    z[2,6,3]  R1253     -4.8395209014415741e-02
    z[2,6,3]  R1254     -7.3296025395393372e-02
    z[2,6,3]  R1255     2.6381894946098328e-01
    z[2,6,3]  R1256     -3.9144456386566162e-01
    z[2,6,3]  R1257     2.1493844687938690e-01
    z[2,6,3]  R1258     -3.2905817031860352e-02
    z[2,6,3]  R1259     1.3282246887683868e-01
    z[2,6,3]  R1260     -4.2959639430046082e-01
    z[2,6,3]  R1261     -2.6216539740562439e-01
    z[2,6,3]  R1262     -1.5089030377566814e-02
    z[2,6,3]  R1263     2.9635429382324219e-01
    z[2,6,3]  R1264     -3.1604444980621338e-01
    z[2,6,3]  R1265     2.2651587426662445e-01
    z[2,6,3]  R1266     1.9076961278915405e-01
    z[2,6,3]  R1267     -1.6248348355293274e-01
    z[2,6,3]  R1268     -3.2762053608894348e-01
    z[2,6,3]  R1269     -9.8815739154815674e-02
    z[2,6,3]  R1270     4.4113656878471375e-01
    z[2,6,3]  R1271     1.8524500727653503e-01
    z[2,6,3]  R1272     2.6893270015716553e-01
    z[2,6,3]  R1273     -8.2504920661449432e-02
    z[2,6,3]  R1274     -3.0172142386436462e-01
    z[2,6,3]  R1275     2.6870843768119812e-01
    z[2,6,3]  R1276     2.9335431754589081e-02
    z[2,6,3]  R1277     1.2446004152297974e-01
    z[2,6,3]  R1278     -0.279773473739624
    z[2,6,3]  R1279     1.1687626689672470e-01
    z[2,6,3]  R1280     1.3141964375972748e-01
    z[2,6,3]  R1281     -3.0197307467460632e-01
    z[2,6,3]  R1282     -0.718078076839447
    z[2,6,3]  R1283     -2.2317622601985931e-01
    z[2,6,3]  R1284     -7.3442630469799042e-02
    z[2,6,3]  R1285     -1.9902646541595459e-01
    z[2,6,3]  R1286     -3.9294418692588806e-01
    z[2,6,3]  R1287     -1.0631754249334335e-01
    z[2,6,3]  R1288     8.6140096187591553e-02
    z[2,6,3]  R1289     -0.0592268705368042
    z[2,6,3]  R1290     1.1346279084682465e-01
    z[2,6,3]  R1291     5.5354988574981689e-01
    z[2,6,3]  R1292     -2.1806603670120239e-01
    z[2,6,3]  R1293     1.3416700065135956e-01
    z[2,6,3]  R1294     -4.5715585350990295e-01
    z[2,6,3]  R1295     -2.9148977249860764e-02
    z[2,6,3]  R1296     -2.1368084847927094e-01
    z[2,6,3]  R1297     -1.3163023628294468e-02
    z[2,6,3]  R1298     5.4514998197555542e-01
    z[2,6,3]  R1299     -1.0321961343288422e-01
    z[2,6,3]  R1300     5.3564912080764771e-01
    z[2,6,3]  R1301     2.9216277599334717e-01
    z[2,6,3]  R1302     3.0592599511146545e-01
    z[2,6,3]  R1303     1.5349418856203556e-02
    z[2,6,3]  R1304     -1.7554216086864471e-01
    z[2,6,3]  R1305     1.0113058984279633e-01
    z[2,6,3]  R1306     4.0966841578483582e-01
    z[2,6,3]  R1307     -3.4179797768592834e-01
    z[2,6,3]  R1308     -2.9593538492918015e-03
    z[2,6,3]  R1309     -1.8164904788136482e-02
    z[2,6,3]  R1310     -3.0162784457206726e-01
    z[2,6,3]  R1311     2.2983743250370026e-01
    z[2,6,3]  R1312     2.0392403006553650e-01
    z[2,6,3]  R1313     3.1509986519813538e-01
    z[2,6,3]  R1314     -4.8180431127548218e-01
    z[2,6,3]  R1315     4.9940237402915955e-01
    z[2,6,3]  R1316     0.303492933511734
    z[2,6,3]  R1317     0.298991322517395
    z[2,6,3]  R1318     -9.7847640514373779e-02
    z[2,6,3]  R1319     -3.3750689029693604e-01
    z[2,6,3]  R1320     3.1253427267074585e-01
    z[2,6,3]  R1321     1.9220243394374847e-01
    z[2,6,3]  R1322     1.3646423816680908e-01
    z[2,6,3]  R1323     -2.2059574723243713e-01
    z[2,6,3]  R1324     1.5589003264904022e-01
    z[2,6,3]  R1325     3.3723658323287964e-01
    z[2,6,3]  R1326     5.4800111800432205e-02
    z[2,6,3]  R1327     1.9486233592033386e-01
    z[2,6,3]  R1328     1.5734905004501343e-01
    z[2,6,3]  R1329     -6.4490497112274170e-02
    z[2,6,3]  R1330     -0.0396580696105957
    z[2,6,3]  R1331     6.9540542364120483e-01
    z[2,6,3]  R1332     7.5495615601539612e-02
    z[2,6,3]  R1333     3.2061886787414551e-01
    z[2,6,3]  R1334     4.6656790375709534e-01
    z[2,6,3]  R1335     0.474361777305603
    z[2,6,3]  R1336     -3.0580973625183105e-01
    z[2,6,3]  R1337     4.5167854428291321e-01
    z[2,6,3]  R1338     -3.4414285421371460e-01
    z[2,6,3]  R1339     2.4899591505527496e-01
    z[2,6,3]  R1340     -7.5129413604736328e-01
    z[2,6,3]  R1341     3.4967169165611267e-01
    z[2,6,3]  R1342     4.1893583536148071e-01
    z[2,6,3]  R1343     -2.6354610919952393e-01
    z[2,6,3]  R1344     1.5516200102865696e-02
    z[2,6,3]  R1345     1.0314907878637314e-01
    z[2,6,3]  R1346     -0.500938892364502
    z[2,6,3]  R1347     1.9754789769649506e-01
    z[2,6,3]  R1348     2.4601487815380096e-01
    z[2,6,3]  R1349     -6.2834209203720093e-01
    z[2,6,3]  R1350     9.7366660833358765e-02
    z[2,6,3]  R1351     2.8921690583229065e-01
    z[2,6,3]  R1352     1.8290439248085022e-01
    z[2,6,3]  R1353     1.8155736848711967e-02
    z[2,6,3]  R1354     -1.2649394571781158e-01
    z[2,6,3]  R1355     -3.0813655257225037e-01
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1200     -1
    z[2,6,4]  R1201     1
    z[2,6,4]  R1206     -1.5438847243785858e-01
    z[2,6,4]  R1207     -7.6973032264504582e-05
    z[2,6,4]  R1208     -3.3534789085388184e-01
    z[2,6,4]  R1209     -4.2755752801895142e-01
    z[2,6,4]  R1210     2.4388051033020020e-01
    z[2,6,4]  R1211     -2.8327324986457825e-01
    z[2,6,4]  R1212     -3.8198661059141159e-02
    z[2,6,4]  R1213     -3.8981625437736511e-01
    z[2,6,4]  R1214     -1.3761992752552032e-01
    z[2,6,4]  R1215     1.5958875417709351e-01
    z[2,6,4]  R1216     -1.5392169356346130e-01
    z[2,6,4]  R1217     3.6746963858604431e-02
    z[2,6,4]  R1218     -0.658660352230072
    z[2,6,4]  R1219     1.4881216920912266e-02
    z[2,6,4]  R1220     2.4512492120265961e-01
    z[2,6,4]  R1221     -4.6883486211299896e-02
    z[2,6,4]  R1222     -2.8469032049179077e-01
    z[2,6,4]  R1223     1.4053110778331757e-01
    z[2,6,4]  R1224     -9.3117050826549530e-02
    z[2,6,4]  R1225     2.6159879565238953e-01
    z[2,6,4]  R1226     -2.2049877047538757e-01
    z[2,6,4]  R1227     -5.9276461601257324e-02
    z[2,6,4]  R1228     -0.257587730884552
    z[2,6,4]  R1229     -1.1354881525039673e-01
    z[2,6,4]  R1230     -7.5281903147697449e-02
    z[2,6,4]  R1231     2.9876199364662170e-01
    z[2,6,4]  R1232     6.2722176313400269e-02
    z[2,6,4]  R1233     1.0926172882318497e-01
    z[2,6,4]  R1234     2.9511335492134094e-01
    z[2,6,4]  R1235     -7.2376020252704620e-02
    z[2,6,4]  R1236     -2.0937213674187660e-02
    z[2,6,4]  R1237     -1.9255377352237701e-01
    z[2,6,4]  R1238     2.1501084789633751e-02
    z[2,6,4]  R1239     -8.2156062126159668e-03
    z[2,6,4]  R1240     2.2068174183368683e-01
    z[2,6,4]  R1241     3.2346978783607483e-01
    z[2,6,4]  R1242     3.5036367177963257e-01
    z[2,6,4]  R1243     2.9226174950599670e-01
    z[2,6,4]  R1244     -5.6999187916517258e-02
    z[2,6,4]  R1245     2.0588155090808868e-01
    z[2,6,4]  R1246     2.5442723184823990e-02
    z[2,6,4]  R1247     1.5681026875972748e-01
    z[2,6,4]  R1248     9.9835090339183807e-02
    z[2,6,4]  R1249     2.4434188008308411e-01
    z[2,6,4]  R1250     -3.4472875297069550e-02
    z[2,6,4]  R1251     3.6078128218650818e-01
    z[2,6,4]  R1252     2.0710060000419617e-01
    z[2,6,4]  R1253     4.5984137803316116e-02
    z[2,6,4]  R1254     2.6967635750770569e-01
    z[2,6,4]  R1255     3.3857962489128113e-01
    z[2,6,4]  R1256     1.8772387504577637e-01
    z[2,6,4]  R1257     -6.4913578331470490e-02
    z[2,6,4]  R1258     3.2985430955886841e-01
    z[2,6,4]  R1259     3.9232546091079712e-01
    z[2,6,4]  R1260     3.3945900201797485e-01
    z[2,6,4]  R1261     1.2313283234834671e-01
    z[2,6,4]  R1262     -4.2394474148750305e-01
    z[2,6,4]  R1263     3.2723551988601685e-01
    z[2,6,4]  R1264     5.8565360307693481e-01
    z[2,6,4]  R1265     2.8684270381927490e-01
    z[2,6,4]  R1266     -3.7396547198295593e-01
    z[2,6,4]  R1267     -1.7767411470413208e-01
    z[2,6,4]  R1268     2.1423611044883728e-01
    z[2,6,4]  R1269     4.1241145133972168e-01
    z[2,6,4]  R1270     -8.4720002487301826e-03
    z[2,6,4]  R1271     -2.1629419177770615e-02
    z[2,6,4]  R1272     -5.6049692630767822e-01
    z[2,6,4]  R1273     -4.1762074828147888e-01
    z[2,6,4]  R1274     -0.309527724981308
    z[2,6,4]  R1275     -1.8898989260196686e-01
    z[2,6,4]  R1276     -4.7102957963943481e-01
    z[2,6,4]  R1277     1.1562176048755646e-01
    z[2,6,4]  R1278     3.6604840308427811e-02
    z[2,6,4]  R1279     4.4977459311485291e-01
    z[2,6,4]  R1280     3.2556807994842529e-01
    z[2,6,4]  R1281     -3.6292336881160736e-02
    z[2,6,4]  R1282     2.5714278221130371e-02
    z[2,6,4]  R1283     -3.8738265633583069e-01
    z[2,6,4]  R1284     2.2139152884483337e-01
    z[2,6,4]  R1285     -3.5999670624732971e-01
    z[2,6,4]  R1286     -1.6703774034976959e-01
    z[2,6,4]  R1287     6.3023701310157776e-02
    z[2,6,4]  R1288     -3.0715823173522949e-02
    z[2,6,4]  R1289     -3.0421710014343262e-01
    z[2,6,4]  R1290     2.1932624280452728e-01
    z[2,6,4]  R1291     -1.7460497096180916e-02
    z[2,6,4]  R1292     4.3190225958824158e-01
    z[2,6,4]  R1293     0.67954021692276
    z[2,6,4]  R1294     -4.0179529786109924e-01
    z[2,6,4]  R1295     -1.0678673535585403e-01
    z[2,6,4]  R1296     2.9650720953941345e-01
    z[2,6,4]  R1297     -3.4526339173316956e-01
    z[2,6,4]  R1298     -1.7809841036796570e-01
    z[2,6,4]  R1299     6.9740664958953857e-01
    z[2,6,4]  R1300     3.9971670508384705e-01
    z[2,6,4]  R1301     -1.9026480615139008e-01
    z[2,6,4]  R1302     -1.3448676466941833e-01
    z[2,6,4]  R1303     -2.5099346041679382e-01
    z[2,6,4]  R1304     -3.4589907526969910e-01
    z[2,6,4]  R1305     -6.4240492880344391e-02
    z[2,6,4]  R1306     -8.8118426501750946e-02
    z[2,6,4]  R1307     4.5130811631679535e-02
    z[2,6,4]  R1308     -7.5812175869941711e-02
    z[2,6,4]  R1309     4.6922618150711060e-01
    z[2,6,4]  R1310     -2.1081276237964630e-01
    z[2,6,4]  R1311     -5.4514068365097046e-01
    z[2,6,4]  R1312     3.0137148499488831e-01
    z[2,6,4]  R1313     2.5732040405273438e-01
    z[2,6,4]  R1314     -2.0544733107089996e-01
    z[2,6,4]  R1315     4.3823051452636719e-01
    z[2,6,4]  R1316     1.1673387885093689e-01
    z[2,6,4]  R1317     -4.8256742954254150e-01
    z[2,6,4]  R1318     2.4360392987728119e-01
    z[2,6,4]  R1319     -3.2086694240570068e-01
    z[2,6,4]  R1320     4.6117997169494629e-01
    z[2,6,4]  R1321     3.9515700936317444e-01
    z[2,6,4]  R1322     4.5218691229820251e-02
    z[2,6,4]  R1323     -1.8601721525192261e-01
    z[2,6,4]  R1324     -3.0061137676239014e-01
    z[2,6,4]  R1325     1.4628148078918457e-01
    z[2,6,4]  R1326     -4.4163670390844345e-02
    z[2,6,4]  R1327     2.9067862033843994e-01
    z[2,6,4]  R1328     -4.5216238498687744e-01
    z[2,6,4]  R1329     -0.154743030667305
    z[2,6,4]  R1330     -2.7844479680061340e-01
    z[2,6,4]  R1331     -1.9415840506553650e-01
    z[2,6,4]  R1332     1.0383749753236771e-01
    z[2,6,4]  R1333     1.2211102247238159e-01
    z[2,6,4]  R1334     -2.6020416617393494e-01
    z[2,6,4]  R1335     -5.8943405747413635e-02
    z[2,6,4]  R1336     -3.0825346708297729e-01
    z[2,6,4]  R1337     3.0930081382393837e-02
    z[2,6,4]  R1338     -1.2759761512279510e-01
    z[2,6,4]  R1339     -6.0336075723171234e-02
    z[2,6,4]  R1340     1.0239310562610626e-01
    z[2,6,4]  R1341     -8.9971348643302917e-03
    z[2,6,4]  R1342     -2.2755637764930725e-03
    z[2,6,4]  R1343     -2.7343245223164558e-02
    z[2,6,4]  R1344     2.0597030222415924e-01
    z[2,6,4]  R1345     -1.0387220233678818e-01
    z[2,6,4]  R1346     2.8337278962135315e-01
    z[2,6,4]  R1347     1.1322257667779922e-01
    z[2,6,4]  R1348     2.7698168158531189e-01
    z[2,6,4]  R1349     -5.7650644332170486e-02
    z[2,6,4]  R1350     -7.6792903244495392e-02
    z[2,6,4]  R1351     -6.1464175581932068e-02
    z[2,6,4]  R1352     -2.8007525205612183e-01
    z[2,6,4]  R1353     -1.7160907387733459e-01
    z[2,6,4]  R1354     -1.3729830272495747e-02
    z[2,6,4]  R1355     -1.3171419501304626e-01
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1202     -1
    z[2,6,5]  R1203     1
    z[2,6,5]  R1206     -1.0144112259149551e-01
    z[2,6,5]  R1207     -0.460526704788208
    z[2,6,5]  R1208     -6.2519145011901855e-01
    z[2,6,5]  R1209     2.1900166571140289e-01
    z[2,6,5]  R1210     9.5428600907325745e-02
    z[2,6,5]  R1211     -1.0198953002691269e-01
    z[2,6,5]  R1212     -1.9380992650985718e-01
    z[2,6,5]  R1213     -6.1036027967929840e-02
    z[2,6,5]  R1214     -2.1970821544528008e-02
    z[2,6,5]  R1215     -9.4059586524963379e-02
    z[2,6,5]  R1216     -1.6372489929199219e-01
    z[2,6,5]  R1217     4.2902618646621704e-02
    z[2,6,5]  R1218     5.2850235253572464e-02
    z[2,6,5]  R1219     -1.5487061440944672e-01
    z[2,6,5]  R1220     -9.9672386422753334e-03
    z[2,6,5]  R1221     -1.5553395450115204e-01
    z[2,6,5]  R1222     4.0574066340923309e-02
    z[2,6,5]  R1223     -0.122328020632267
    z[2,6,5]  R1224     -3.4870034456253052e-01
    z[2,6,5]  R1225     1.8090550601482391e-01
    z[2,6,5]  R1226     -5.0910115242004395e-02
    z[2,6,5]  R1227     -1.6325891017913818e-02
    z[2,6,5]  R1228     0.0240008644759655
    z[2,6,5]  R1229     1.7423366010189056e-01
    z[2,6,5]  R1230     7.4190340936183929e-02
    z[2,6,5]  R1231     -3.4981764853000641e-02
    z[2,6,5]  R1232     4.1195428371429443e-01
    z[2,6,5]  R1233     -1.1364228278398514e-01
    z[2,6,5]  R1234     -8.9100472629070282e-02
    z[2,6,5]  R1235     -3.0492374300956726e-01
    z[2,6,5]  R1236     -1.1079335212707520e-01
    z[2,6,5]  R1237     5.3455509245395660e-02
    z[2,6,5]  R1238     -1.5185537934303284e-01
    z[2,6,5]  R1239     -1.5557087957859039e-01
    z[2,6,5]  R1240     1.5664680302143097e-01
    z[2,6,5]  R1241     3.6281082034111023e-01
    z[2,6,5]  R1242     -9.8257049918174744e-02
    z[2,6,5]  R1243     3.9560042321681976e-02
    z[2,6,5]  R1244     -1.9892990589141846e-01
    z[2,6,5]  R1245     -5.1982551813125610e-01
    z[2,6,5]  R1246     1.8363554030656815e-02
    z[2,6,5]  R1247     -9.5805518329143524e-02
    z[2,6,5]  R1248     1.2756167352199554e-01
    z[2,6,5]  R1249     -5.5215455591678619e-02
    z[2,6,5]  R1250     1.4253821969032288e-01
    z[2,6,5]  R1251     1.5330988168716431e-01
    z[2,6,5]  R1252     -1.7740002274513245e-01
    z[2,6,5]  R1253     6.8646006286144257e-02
    z[2,6,5]  R1254     9.1301478445529938e-02
    z[2,6,5]  R1255     1.0748646408319473e-01
    z[2,6,5]  R1256     -6.3528245687484741e-01
    z[2,6,5]  R1257     -5.5146205425262451e-01
    z[2,6,5]  R1258     -1.5791727602481842e-01
    z[2,6,5]  R1259     1.1527353525161743e-01
    z[2,6,5]  R1260     -1.3519582152366638e-01
    z[2,6,5]  R1261     -4.2881774902343750e-01
    z[2,6,5]  R1262     -6.6672730445861816e-01
    z[2,6,5]  R1263     -3.4675487875938416e-01
    z[2,6,5]  R1264     -3.6504715681076050e-01
    z[2,6,5]  R1265     -6.0960131883621216e-01
    z[2,6,5]  R1266     -1.7386928200721741e-01
    z[2,6,5]  R1267     6.6571027040481567e-02
    z[2,6,5]  R1268     8.7013505399227142e-02
    z[2,6,5]  R1269     2.4824562668800354e-01
    z[2,6,5]  R1270     3.5148376226425171e-01
    z[2,6,5]  R1271     2.2151772677898407e-01
    z[2,6,5]  R1272     1.1689832806587219e-01
    z[2,6,5]  R1273     2.1122368052601814e-02
    z[2,6,5]  R1274     4.5777830481529236e-01
    z[2,6,5]  R1275     1.2328056618571281e-02
    z[2,6,5]  R1276     -0.448505699634552
    z[2,6,5]  R1277     -3.6816036701202393e-01
    z[2,6,5]  R1278     2.8279694914817810e-01
    z[2,6,5]  R1279     -5.4161384701728821e-02
    z[2,6,5]  R1280     1.2324440479278564e-01
    z[2,6,5]  R1281     -1.0633645206689835e-01
    z[2,6,5]  R1282     2.5598341599106789e-02
    z[2,6,5]  R1283     -2.3073397576808929e-02
    z[2,6,5]  R1284     -1.0603081434965134e-01
    z[2,6,5]  R1285     -6.0287380218505859e-01
    z[2,6,5]  R1286     -2.1796286106109619e-01
    z[2,6,5]  R1287     -1.5515540540218353e-01
    z[2,6,5]  R1288     -3.2942584156990051e-01
    z[2,6,5]  R1289     -2.4291633069515228e-01
    z[2,6,5]  R1290     -0.422921746969223
    z[2,6,5]  R1291     -4.3859258294105530e-01
    z[2,6,5]  R1292     -1.4036697149276733e-01
    z[2,6,5]  R1293     -1.4414627850055695e-01
    z[2,6,5]  R1294     -2.9180753231048584e-01
    z[2,6,5]  R1295     0.622606098651886
    z[2,6,5]  R1296     2.4356535077095032e-01
    z[2,6,5]  R1297     -3.0759337544441223e-01
    z[2,6,5]  R1298     -2.7960723638534546e-01
    z[2,6,5]  R1299     -0.421384334564209
    z[2,6,5]  R1300     -5.0109249353408813e-01
    z[2,6,5]  R1301     -6.7544782161712646e-01
    z[2,6,5]  R1302     5.5559748411178589e-01
    z[2,6,5]  R1303     3.2968875765800476e-01
    z[2,6,5]  R1304     4.8926264047622681e-02
    z[2,6,5]  R1305     1.0916931927204132e-01
    z[2,6,5]  R1306     -2.5254514813423157e-01
    z[2,6,5]  R1307     -6.4476072788238525e-01
    z[2,6,5]  R1308     3.6030894517898560e-01
    z[2,6,5]  R1309     -4.0189573168754578e-01
    z[2,6,5]  R1310     -2.4131463468074799e-01
    z[2,6,5]  R1311     -2.2471027076244354e-01
    z[2,6,5]  R1312     0.314242959022522
    z[2,6,5]  R1313     -3.2006821036338806e-01
    z[2,6,5]  R1314     -3.0427744984626770e-01
    z[2,6,5]  R1315     1.2288712710142136e-01
    z[2,6,5]  R1316     9.0067885816097260e-02
    z[2,6,5]  R1317     -4.1855999827384949e-01
    z[2,6,5]  R1318     -5.1251932978630066e-02
    z[2,6,5]  R1319     -3.1081253290176392e-01
    z[2,6,5]  R1320     -4.3841204047203064e-01
    z[2,6,5]  R1321     -4.6696880459785461e-01
    z[2,6,5]  R1322     -7.8776758909225464e-01
    z[2,6,5]  R1323     -0.0409141406416893
    z[2,6,5]  R1324     -4.1150298714637756e-01
    z[2,6,5]  R1325     -4.4737223535776138e-02
    z[2,6,5]  R1326     -2.4522005021572113e-01
    z[2,6,5]  R1327     -4.9179011583328247e-01
    z[2,6,5]  R1328     -4.9940440058708191e-01
    z[2,6,5]  R1329     -7.4444037675857544e-01
    z[2,6,5]  R1330     1.4940799772739410e-01
    z[2,6,5]  R1331     2.4619838595390320e-01
    z[2,6,5]  R1332     -1.0064287483692169e-01
    z[2,6,5]  R1333     4.2561632394790649e-01
    z[2,6,5]  R1334     9.8149076104164124e-02
    z[2,6,5]  R1335     1.9988100230693817e-01
    z[2,6,5]  R1336     -2.0188757777214050e-01
    z[2,6,5]  R1337     1.4005610346794128e-01
    z[2,6,5]  R1338     -0.479707807302475
    z[2,6,5]  R1339     -8.0626225471496582e-01
    z[2,6,5]  R1340     -1.2126793712377548e-01
    z[2,6,5]  R1341     1.4181299507617950e-01
    z[2,6,5]  R1342     1.1308369040489197e-01
    z[2,6,5]  R1343     4.5485013723373413e-01
    z[2,6,5]  R1344     -2.9244298115372658e-02
    z[2,6,5]  R1345     1.4941900968551636e-01
    z[2,6,5]  R1346     -2.0874448120594025e-01
    z[2,6,5]  R1347     -7.2684699296951294e-01
    z[2,6,5]  R1348     -3.9484921097755432e-01
    z[2,6,5]  R1349     -1.2284660339355469e-01
    z[2,6,5]  R1350     1.7613308131694794e-01
    z[2,6,5]  R1351     -1.5199208259582520e-01
    z[2,6,5]  R1352     -0.0385298952460289
    z[2,6,5]  R1353     -3.2177552580833435e-02
    z[2,6,5]  R1354     -2.9607942700386047e-01
    z[2,6,5]  R1355     -3.6532118916511536e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1204     -1
    z[2,6,6]  R1205     1
    z[2,6,6]  R1206     1.5722465515136719e-01
    z[2,6,6]  R1207     -3.8445958495140076e-01
    z[2,6,6]  R1208     -0.14777772128582
    z[2,6,6]  R1209     1.4122481644153595e-01
    z[2,6,6]  R1210     2.7494275569915771e-01
    z[2,6,6]  R1211     -1.5206019580364227e-01
    z[2,6,6]  R1212     -2.1245667338371277e-01
    z[2,6,6]  R1213     -6.7172899842262268e-02
    z[2,6,6]  R1214     3.5336604714393616e-01
    z[2,6,6]  R1215     1.5318599343299866e-01
    z[2,6,6]  R1216     -1.1770993471145630e-01
    z[2,6,6]  R1217     5.9793557971715927e-02
    z[2,6,6]  R1218     1.7707526683807373e-01
    z[2,6,6]  R1219     2.1222686767578125e-01
    z[2,6,6]  R1220     1.1529105901718140e-01
    z[2,6,6]  R1221     3.6482852697372437e-01
    z[2,6,6]  R1222     0.533686101436615
    z[2,6,6]  R1223     1.2279906868934631e-01
    z[2,6,6]  R1224     1.5007475018501282e-01
    z[2,6,6]  R1225     -1.1907586455345154e-01
    z[2,6,6]  R1226     -5.7666312903165817e-02
    z[2,6,6]  R1227     1.2325332313776016e-01
    z[2,6,6]  R1228     7.8757822513580322e-02
    z[2,6,6]  R1229     5.3811889141798019e-02
    z[2,6,6]  R1230     -2.1906213462352753e-01
    z[2,6,6]  R1231     5.9291366487741470e-02
    z[2,6,6]  R1232     2.1339060366153717e-01
    z[2,6,6]  R1233     -1.5584947168827057e-01
    z[2,6,6]  R1234     -2.2106464207172394e-01
    z[2,6,6]  R1235     -3.6798080801963806e-01
    z[2,6,6]  R1236     -3.0925212427973747e-02
    z[2,6,6]  R1237     -3.9553830027580261e-01
    z[2,6,6]  R1238     -9.0814061462879181e-02
    z[2,6,6]  R1239     -3.2346379756927490e-01
    z[2,6,6]  R1240     2.4477085098624229e-02
    z[2,6,6]  R1241     3.0615216493606567e-01
    z[2,6,6]  R1242     -2.4730274081230164e-01
    z[2,6,6]  R1243     1.1387012898921967e-01
    z[2,6,6]  R1244     2.1660865843296051e-01
    z[2,6,6]  R1245     3.4254112839698792e-01
    z[2,6,6]  R1246     -1.1770492047071457e-01
    z[2,6,6]  R1247     -4.4261552393436432e-03
    z[2,6,6]  R1248     -1.6064360737800598e-01
    z[2,6,6]  R1249     -1.6098898649215698e-01
    z[2,6,6]  R1250     -0.301470011472702
    z[2,6,6]  R1251     1.6815978288650513e-01
    z[2,6,6]  R1252     -1.2203180789947510e-01
    z[2,6,6]  R1253     1.4321976900100708e-01
    z[2,6,6]  R1254     -1.0164518840610981e-02
    z[2,6,6]  R1255     2.7247878909111023e-01
    z[2,6,6]  R1256     1.8773525953292847e-01
    z[2,6,6]  R1257     -2.3031197488307953e-01
    z[2,6,6]  R1258     3.7443738430738449e-02
    z[2,6,6]  R1259     -5.8671992272138596e-02
    z[2,6,6]  R1260     -4.4896829128265381e-01
    z[2,6,6]  R1261     0.0770488902926445
    z[2,6,6]  R1262     -2.5659623742103577e-01
    z[2,6,6]  R1263     -7.1774378418922424e-02
    z[2,6,6]  R1264     3.3430272340774536e-01
    z[2,6,6]  R1265     2.6974827051162720e-02
    z[2,6,6]  R1266     -6.8659879267215729e-02
    z[2,6,6]  R1267     8.4615841507911682e-02
    z[2,6,6]  R1268     9.7019389271736145e-02
    z[2,6,6]  R1269     3.8433033227920532e-01
    z[2,6,6]  R1270     -6.3249057531356812e-01
    z[2,6,6]  R1271     -2.1371269226074219e-01
    z[2,6,6]  R1272     -4.1133394837379456e-01
    z[2,6,6]  R1273     -0.0805663913488388
    z[2,6,6]  R1274     1.8261478841304779e-01
    z[2,6,6]  R1275     -2.9590731486678123e-02
    z[2,6,6]  R1276     -9.6845522522926331e-02
    z[2,6,6]  R1277     2.0080134272575378e-01
    z[2,6,6]  R1278     -2.0039488375186920e-01
    z[2,6,6]  R1279     3.6406585574150085e-01
    z[2,6,6]  R1280     -2.0754756033420563e-01
    z[2,6,6]  R1281     0.0768914446234703
    z[2,6,6]  R1282     1.9086304306983948e-01
    z[2,6,6]  R1283     2.0770902931690216e-01
    z[2,6,6]  R1284     4.1985239833593369e-02
    z[2,6,6]  R1285     -2.1316848695278168e-01
    z[2,6,6]  R1286     -7.0847973227500916e-02
    z[2,6,6]  R1287     1.4123211801052094e-01
    z[2,6,6]  R1288     -7.8969992697238922e-02
    z[2,6,6]  R1289     -1.1099644750356674e-01
    z[2,6,6]  R1290     -1.9904676079750061e-01
    z[2,6,6]  R1291     -2.7316769957542419e-01
    z[2,6,6]  R1292     3.7511962652206421e-01
    z[2,6,6]  R1293     -2.7071639895439148e-01
    z[2,6,6]  R1294     0.0816039890050888
    z[2,6,6]  R1295     1.1319984495639801e-01
    z[2,6,6]  R1296     2.7768164873123169e-01
    z[2,6,6]  R1297     6.2627747654914856e-02
    z[2,6,6]  R1298     -0.0424545481801033
    z[2,6,6]  R1299     -4.8246022313833237e-02
    z[2,6,6]  R1300     -1.7423997819423676e-01
    z[2,6,6]  R1301     -2.3064975440502167e-01
    z[2,6,6]  R1302     -2.5198507308959961e-01
    z[2,6,6]  R1303     -2.8632849454879761e-01
    z[2,6,6]  R1304     -1.7734473943710327e-01
    z[2,6,6]  R1305     0.0823395624756813
    z[2,6,6]  R1306     -2.5365290045738220e-01
    z[2,6,6]  R1307     5.3452465683221817e-02
    z[2,6,6]  R1308     1.7981614917516708e-02
    z[2,6,6]  R1309     8.4437653422355652e-02
    z[2,6,6]  R1310     1.7719270288944244e-01
    z[2,6,6]  R1311     -4.9363183975219727e-01
    z[2,6,6]  R1312     1.7795109748840332e-01
    z[2,6,6]  R1313     -6.2378573417663574e-01
    z[2,6,6]  R1314     -2.1367833018302917e-01
    z[2,6,6]  R1315     1.7445491254329681e-01
    z[2,6,6]  R1316     1.5673954784870148e-01
    z[2,6,6]  R1317     -0.282549113035202
    z[2,6,6]  R1318     -9.0264402329921722e-02
    z[2,6,6]  R1319     2.8157643973827362e-03
    z[2,6,6]  R1320     -6.1274436302483082e-03
    z[2,6,6]  R1321     2.0600537955760956e-01
    z[2,6,6]  R1322     1.3947731256484985e-01
    z[2,6,6]  R1323     1.3983491063117981e-01
    z[2,6,6]  R1324     -2.2028565406799316e-01
    z[2,6,6]  R1325     1.3029728829860687e-01
    z[2,6,6]  R1326     -2.9339674860239029e-02
    z[2,6,6]  R1327     -1.4245378971099854e-01
    z[2,6,6]  R1328     -0.257985919713974
    z[2,6,6]  R1329     -2.4304588139057159e-01
    z[2,6,6]  R1330     -5.2570408582687378e-01
    z[2,6,6]  R1331     3.2696448266506195e-02
    z[2,6,6]  R1332     -3.7743654102087021e-02
    z[2,6,6]  R1333     -0.148038849234581
    z[2,6,6]  R1334     -2.4738231301307678e-01
    z[2,6,6]  R1335     -2.0432794094085693e-01
    z[2,6,6]  R1336     -1.5077529847621918e-01
    z[2,6,6]  R1337     -1.4350248873233795e-01
    z[2,6,6]  R1338     1.1306065320968628e-01
    z[2,6,6]  R1339     1.0979101061820984e-01
    z[2,6,6]  R1340     3.0902945995330811e-01
    z[2,6,6]  R1341     0.0984988585114479
    z[2,6,6]  R1342     -3.4991574287414551e-01
    z[2,6,6]  R1343     -1.4413505792617798e-01
    z[2,6,6]  R1344     2.2152608260512352e-02
    z[2,6,6]  R1345     -7.0057488977909088e-02
    z[2,6,6]  R1346     1.2082371860742569e-01
    z[2,6,6]  R1347     7.4731156229972839e-02
    z[2,6,6]  R1348     0.2565937936306
    z[2,6,6]  R1349     2.3028762638568878e-01
    z[2,6,6]  R1350     -2.3457955569028854e-02
    z[2,6,6]  R1351     1.1988984793424606e-01
    z[2,6,6]  R1352     1.9500355422496796e-01
    z[2,6,6]  R1353     5.0898820161819458e-01
    z[2,6,6]  R1354     4.6658405661582947e-01
    z[2,6,6]  R1355     1.8439665436744690e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1356     -1
    z[6,2,0]  R1357     1
    z[6,2,0]  R1370     -8.7384122610092163e-01
    z[6,2,0]  R1371     -8.8748365640640259e-01
    z[6,2,0]  R1372     -9.4941294193267822e-01
    z[6,2,0]  R1373     -8.5786253213882446e-01
    z[6,2,0]  R1374     -9.1623759269714355e-01
    z[6,2,0]  R1375     -7.2450643777847290e-01
    z[6,2,0]  R1376     -9.3621307611465454e-01
    z[6,2,0]  R1377     -0.96856290102005
    z[6,2,0]  R1378     -8.3268773555755615e-01
    z[6,2,0]  R1379     -8.0606764554977417e-01
    z[6,2,0]  R1380     2.0103774964809418e-01
    z[6,2,0]  R1381     2.1778398752212524e-01
    z[6,2,0]  R1382     1.9404245913028717e-01
    z[6,2,0]  R1383     -0.0822681114077568
    z[6,2,0]  R1384     -2.5601822417229414e-03
    z[6,2,0]  R1385     2.5686609745025635e-01
    z[6,2,0]  R1386     2.3033238947391510e-01
    z[6,2,0]  R1387     3.1332874298095703e-01
    z[6,2,0]  R1388     -1.5054904855787754e-02
    z[6,2,0]  R1389     1.5797884762287140e-01
    z[6,2,0]  R1390     8.2420194149017334e-01
    z[6,2,0]  R1391     4.1432134807109833e-02
    z[6,2,0]  R1392     0.51854008436203
    z[6,2,0]  R1393     7.2541677951812744e-01
    z[6,2,0]  R1394     5.0932067632675171e-01
    z[6,2,0]  R1395     5.2500754594802856e-01
    z[6,2,0]  R1396     3.7646532058715820e-01
    z[6,2,0]  R1397     7.7187612652778625e-02
    z[6,2,0]  R1398     5.5519080162048340e-01
    z[6,2,0]  R1399     1.7107808589935303e-01
    z[6,2,0]  R1400     5.8747440576553345e-01
    z[6,2,0]  R1401     0.787808895111084
    z[6,2,0]  R1402     -1.2902888655662537e-01
    z[6,2,0]  R1403     7.3995554447174072e-01
    z[6,2,0]  R1404     1.4056351780891418e-01
    z[6,2,0]  R1405     6.9226735830307007e-01
    z[6,2,0]  R1406     2.5577588006854057e-02
    z[6,2,0]  R1407     8.1297689676284790e-01
    z[6,2,0]  R1408     5.6801873445510864e-01
    z[6,2,0]  R1409     -2.2160109877586365e-01
    z[6,2,0]  R1410     -1.0260418057441711e-03
    z[6,2,0]  R1411     3.2716092467308044e-01
    z[6,2,0]  R1412     4.2324984073638916e-01
    z[6,2,0]  R1413     4.8220828175544739e-02
    z[6,2,0]  R1414     0.618370532989502
    z[6,2,0]  R1415     5.8190727233886719e-01
    z[6,2,0]  R1416     3.2456271350383759e-02
    z[6,2,0]  R1417     -2.7239865064620972e-01
    z[6,2,0]  R1418     -3.8483291864395142e-01
    z[6,2,0]  R1419     7.6029294729232788e-01
    z[6,2,0]  R1420     -7.7624571323394775e-01
    z[6,2,0]  R1421     7.8828144073486328e-01
    z[6,2,0]  R1422     6.0670781135559082e-01
    z[6,2,0]  R1423     1.2974782288074493e-01
    z[6,2,0]  R1424     4.8424193263053894e-01
    z[6,2,0]  R1425     5.4049581289291382e-01
    z[6,2,0]  R1426     5.2734637260437012e-01
    z[6,2,0]  R1427     5.1648199558258057e-01
    z[6,2,0]  R1428     -3.5389885306358337e-01
    z[6,2,0]  R1429     0.0541507862508297
    z[6,2,0]  R1430     4.1410472989082336e-01
    z[6,2,0]  R1431     1.3840852305293083e-02
    z[6,2,0]  R1432     8.0886858701705933e-01
    z[6,2,0]  R1433     -4.1802600026130676e-01
    z[6,2,0]  R1434     -4.2783138155937195e-01
    z[6,2,0]  R1435     4.6446800231933594e-01
    z[6,2,0]  R1436     7.1531379222869873e-01
    z[6,2,0]  R1437     5.2551430463790894e-01
    z[6,2,0]  R1438     -3.5186198353767395e-01
    z[6,2,0]  R1439     7.0942497253417969e-01
    z[6,2,0]  R1440     8.9145672321319580e-01
    z[6,2,0]  R1441     4.3067368865013123e-01
    z[6,2,0]  R1442     -2.3954921960830688e-01
    z[6,2,0]  R1443     -5.8236384391784668e-01
    z[6,2,0]  R1444     6.2779515981674194e-01
    z[6,2,0]  R1445     5.2663028240203857e-01
    z[6,2,0]  R1446     4.8508965969085693e-01
    z[6,2,0]  R1447     8.4526282548904419e-01
    z[6,2,0]  R1448     -4.7784465551376343e-01
    z[6,2,0]  R1449     1.4369764365255833e-02
    z[6,2,0]  R1450     -7.4734479188919067e-01
    z[6,2,0]  R1451     6.1633431911468506e-01
    z[6,2,0]  R1452     0.401021271944046
    z[6,2,0]  R1453     4.8296386003494263e-01
    z[6,2,0]  R1454     0.680448055267334
    z[6,2,0]  R1455     -3.7621328234672546e-01
    z[6,2,0]  R1456     1.2038894742727280e-01
    z[6,2,0]  R1457     -1.7895002383738756e-04
    z[6,2,0]  R1458     -8.2989625632762909e-02
    z[6,2,0]  R1459     -2.8991684317588806e-02
    z[6,2,0]  R1460     -0.743486762046814
    z[6,2,0]  R1461     7.0977705717086792e-01
    z[6,2,0]  R1462     5.7753592729568481e-01
    z[6,2,0]  R1463     4.3028134107589722e-01
    z[6,2,0]  R1464     1.7088226974010468e-01
    z[6,2,0]  R1465     6.7804497666656971e-03
    z[6,2,0]  R1466     -6.1569139361381531e-02
    z[6,2,0]  R1467     3.5309992730617523e-02
    z[6,2,0]  R1468     -1.1695101112127304e-01
    z[6,2,0]  R1469     -4.5996751636266708e-02
    z[6,2,0]  R1470     7.2832182049751282e-03
    z[6,2,0]  R1471     6.1436778306961060e-01
    z[6,2,0]  R1472     5.5816221237182617e-01
    z[6,2,0]  R1473     -4.5648229122161865e-01
    z[6,2,0]  R1474     -3.2614029943943024e-02
    z[6,2,0]  R1475     -2.6928958296775818e-01
    z[6,2,0]  R1476     -1.3647805154323578e-01
    z[6,2,0]  R1477     2.3611165583133698e-02
    z[6,2,0]  R1478     -6.7060112953186035e-02
    z[6,2,0]  R1479     -0.0773346871137619
    z[6,2,0]  R1480     -3.4547504782676697e-01
    z[6,2,0]  R1481     1.3561316765844822e-02
    z[6,2,0]  R1482     -3.6145329475402832e-01
    z[6,2,0]  R1483     -4.5829087495803833e-01
    z[6,2,0]  R1484     -0.684083104133606
    z[6,2,0]  R1485     5.8577132225036621e-01
    z[6,2,0]  R1486     4.8948177695274353e-01
    z[6,2,0]  R1487     2.9152107238769531e-01
    z[6,2,0]  R1488     1.1649436503648758e-01
    z[6,2,0]  R1489     3.7414813041687012e-01
    z[6,2,0]  R1490     -1.0246091336011887e-01
    z[6,2,0]  R1491     9.4595164060592651e-02
    z[6,2,0]  R1492     1.6218294203281403e-01
    z[6,2,0]  R1493     -1.3031384348869324e-01
    z[6,2,0]  R1494     -4.1496995836496353e-02
    z[6,2,0]  R1495     1.2153500691056252e-02
    z[6,2,0]  R1496     -1.2515839934349060e-01
    z[6,2,0]  R1497     7.1756877005100250e-02
    z[6,2,0]  R1498     -4.0827151387929916e-02
    z[6,2,0]  R1499     6.3087129592895508e-01
    z[6,2,0]  R1500     2.6328464969992638e-02
    z[6,2,0]  R1501     6.7273631691932678e-02
    z[6,2,0]  R1502     3.0740952491760254e-01
    z[6,2,0]  R1503     2.2847460210323334e-01
    z[6,2,0]  R1504     0.571487545967102
    z[6,2,0]  R1505     3.7006980180740356e-01
    z[6,2,0]  R1506     3.5615384578704834e-01
    z[6,2,0]  R1507     1.8936680257320404e-01
    z[6,2,0]  R1508     2.8686422109603882e-01
    z[6,2,0]  R1509     4.6804994344711304e-01
    z[6,2,0]  R1510     2.7180549502372742e-01
    z[6,2,0]  R1511     2.5965690612792969e-01
    z[6,2,0]  R1512     4.5168903470039368e-01
    z[6,2,0]  R1513     4.7862139344215393e-01
    z[6,2,0]  R1514     5.2210897207260132e-01
    z[6,2,0]  R1515     2.0533682405948639e-01
    z[6,2,0]  R1516     4.0825748443603516e-01
    z[6,2,0]  R1517     2.0486554503440857e-01
    z[6,2,0]  R1518     6.4479327201843262e-01
    z[6,2,0]  R1519     6.4287084341049194e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1358     -1
    z[6,2,1]  R1359     1
    z[6,2,1]  R1370     -3.8983193039894104e-01
    z[6,2,1]  R1371     -3.6499857902526855e-01
    z[6,2,1]  R1372     -2.1544776856899261e-02
    z[6,2,1]  R1373     -6.8940952420234680e-02
    z[6,2,1]  R1374     -1.2151963263750076e-01
    z[6,2,1]  R1375     -5.3895201534032822e-02
    z[6,2,1]  R1376     3.3995623234659433e-03
    z[6,2,1]  R1377     -6.3452741596847773e-04
    z[6,2,1]  R1378     2.7241089940071106e-01
    z[6,2,1]  R1379     -2.8118479251861572e-01
    z[6,2,1]  R1380     -5.0241601467132568e-01
    z[6,2,1]  R1381     -1.9956082105636597e-01
    z[6,2,1]  R1382     -5.9879440069198608e-01
    z[6,2,1]  R1383     -7.0977377891540527e-01
    z[6,2,1]  R1384     -4.8572760820388794e-01
    z[6,2,1]  R1385     -5.2118331193923950e-01
    z[6,2,1]  R1386     -6.8679213523864746e-02
    z[6,2,1]  R1387     -5.8934754133224487e-01
    z[6,2,1]  R1388     -4.0870368480682373e-01
    z[6,2,1]  R1389     -5.2850800752639771e-01
    z[6,2,1]  R1390     -3.1171565875411034e-02
    z[6,2,1]  R1391     -9.5037811994552612e-01
    z[6,2,1]  R1392     3.0611717700958252e-01
    z[6,2,1]  R1393     1.5424132347106934e-01
    z[6,2,1]  R1394     -9.2823922634124756e-02
    z[6,2,1]  R1395     3.5708022117614746e-01
    z[6,2,1]  R1396     -5.2102571725845337e-01
    z[6,2,1]  R1397     6.6686397790908813e-01
    z[6,2,1]  R1398     -1.4312581717967987e-01
    z[6,2,1]  R1399     6.0229659080505371e-01
    z[6,2,1]  R1400     -3.4938564896583557e-01
    z[6,2,1]  R1401     1.5225054323673248e-01
    z[6,2,1]  R1402     -7.8362977504730225e-01
    z[6,2,1]  R1403     0.045985147356987
    z[6,2,1]  R1404     -8.9270532131195068e-01
    z[6,2,1]  R1405     1.0074172914028168e-01
    z[6,2,1]  R1406     -6.3061875104904175e-01
    z[6,2,1]  R1407     -3.0362397432327271e-01
    z[6,2,1]  R1408     1.2596595287322998e-01
    z[6,2,1]  R1409     -5.5027091503143311e-01
    z[6,2,1]  R1410     -7.6516550779342651e-01
    z[6,2,1]  R1411     -8.8505178689956665e-01
    z[6,2,1]  R1412     -5.2559173107147217e-01
    z[6,2,1]  R1413     -0.89644455909729
    z[6,2,1]  R1414     2.1496775746345520e-01
    z[6,2,1]  R1415     -2.3313325643539429e-01
    z[6,2,1]  R1416     -7.7686858177185059e-01
    z[6,2,1]  R1417     -5.5272829532623291e-01
    z[6,2,1]  R1418     -1.3243253529071808e-01
    z[6,2,1]  R1419     -3.7105970084667206e-02
    z[6,2,1]  R1420     -2.6720070838928223e-01
    z[6,2,1]  R1421     -3.0520877242088318e-01
    z[6,2,1]  R1422     -4.4281157851219177e-01
    z[6,2,1]  R1423     -4.7522720694541931e-01
    z[6,2,1]  R1424     -1.7094098031520844e-01
    z[6,2,1]  R1425     -1.9637905061244965e-01
    z[6,2,1]  R1426     -4.5808512717485428e-02
    z[6,2,1]  R1427     2.2161212563514709e-01
    z[6,2,1]  R1428     7.5454115867614746e-01
    z[6,2,1]  R1429     8.6229842901229858e-01
    z[6,2,1]  R1430     -2.6137259602546692e-01
    z[6,2,1]  R1431     -6.7997843027114868e-01
    z[6,2,1]  R1432     1.7777520418167114e-01
    z[6,2,1]  R1433     -6.4122051000595093e-01
    z[6,2,1]  R1434     -0.055446557700634
    z[6,2,1]  R1435     -2.7222353219985962e-01
    z[6,2,1]  R1436     -2.6235067844390869e-01
    z[6,2,1]  R1437     -1.5870186686515808e-01
    z[6,2,1]  R1438     1.6907547414302826e-01
    z[6,2,1]  R1439     2.0996022969484329e-02
    z[6,2,1]  R1440     -1.4200265705585480e-01
    z[6,2,1]  R1441     -3.0012896656990051e-01
    z[6,2,1]  R1442     -7.6789957284927368e-01
    z[6,2,1]  R1443     -5.6674383580684662e-02
    z[6,2,1]  R1444     -1.9198960065841675e-01
    z[6,2,1]  R1445     -1.4512595720589161e-02
    z[6,2,1]  R1446     3.6846555769443512e-02
    z[6,2,1]  R1447     2.8690424561500549e-01
    z[6,2,1]  R1448     4.8175626993179321e-01
    z[6,2,1]  R1449     7.9874765872955322e-01
    z[6,2,1]  R1450     -1.4394551515579224e-02
    z[6,2,1]  R1451     -3.0781856179237366e-01
    z[6,2,1]  R1452     -2.7524015307426453e-01
    z[6,2,1]  R1453     -2.0112356543540955e-01
    z[6,2,1]  R1454     1.0570946335792542e-01
    z[6,2,1]  R1455     -1.8369263410568237e-01
    z[6,2,1]  R1456     5.2311939001083374e-01
    z[6,2,1]  R1457     7.2564291954040527e-01
    z[6,2,1]  R1458     7.3291534185409546e-01
    z[6,2,1]  R1459     8.1506699323654175e-01
    z[6,2,1]  R1460     9.3010291457176208e-02
    z[6,2,1]  R1461     -1.8123178184032440e-01
    z[6,2,1]  R1462     -0.145138680934906
    z[6,2,1]  R1463     -2.4333159625530243e-01
    z[6,2,1]  R1464     -4.8579236865043640e-01
    z[6,2,1]  R1465     6.5936404466629028e-01
    z[6,2,1]  R1466     6.2111669778823853e-01
    z[6,2,1]  R1467     0.584827721118927
    z[6,2,1]  R1468     8.8545787334442139e-01
    z[6,2,1]  R1469     8.1723350286483765e-01
    z[6,2,1]  R1470     -4.9319869279861450e-01
    z[6,2,1]  R1471     -1.6294093430042267e-01
    z[6,2,1]  R1472     -5.0169759988784790e-01
    z[6,2,1]  R1473     -3.1170082092285156e-01
    z[6,2,1]  R1474     9.1450905799865723e-01
    z[6,2,1]  R1475     8.0454438924789429e-01
    z[6,2,1]  R1476     0.808972954750061
    z[6,2,1]  R1477     6.4437693357467651e-01
    z[6,2,1]  R1478     6.1878538131713867e-01
    z[6,2,1]  R1479     0.753345787525177
    z[6,2,1]  R1480     -0.750278890132904
    z[6,2,1]  R1481     -0.671106219291687
    z[6,2,1]  R1482     -4.1270947456359863e-01
    z[6,2,1]  R1483     -6.1707812547683716e-01
    z[6,2,1]  R1484     -4.1638168692588806e-01
    z[6,2,1]  R1485     4.6346348524093628e-01
    z[6,2,1]  R1486     7.7009522914886475e-01
    z[6,2,1]  R1487     8.3872324228286743e-01
    z[6,2,1]  R1488     8.4543758630752563e-01
    z[6,2,1]  R1489     8.6298817396163940e-01
    z[6,2,1]  R1490     7.5134354829788208e-01
    z[6,2,1]  R1491     8.3110558986663818e-01
    z[6,2,1]  R1492     4.9972397089004517e-01
    z[6,2,1]  R1493     4.6165066957473755e-01
    z[6,2,1]  R1494     6.3231056928634644e-01
    z[6,2,1]  R1495     5.7388871908187866e-01
    z[6,2,1]  R1496     5.6774681806564331e-01
    z[6,2,1]  R1497     9.4949412345886230e-01
    z[6,2,1]  R1498     9.1691529750823975e-01
    z[6,2,1]  R1499     6.8674588203430176e-01
    z[6,2,1]  R1500     4.5204082131385803e-01
    z[6,2,1]  R1501     9.4661259651184082e-01
    z[6,2,1]  R1502     9.0046483278274536e-01
    z[6,2,1]  R1503     8.4820568561553955e-01
    z[6,2,1]  R1504     7.4543327093124390e-01
    z[6,2,1]  R1505     8.3941560983657837e-01
    z[6,2,1]  R1506     7.7500838041305542e-01
    z[6,2,1]  R1507     8.1515860557556152e-01
    z[6,2,1]  R1508     7.6194858551025391e-01
    z[6,2,1]  R1509     0.707585871219635
    z[6,2,1]  R1510     6.5791672468185425e-01
    z[6,2,1]  R1511     5.4883909225463867e-01
    z[6,2,1]  R1512     8.3625626564025879e-01
    z[6,2,1]  R1513     7.5414651632308960e-01
    z[6,2,1]  R1514     6.9773238897323608e-01
    z[6,2,1]  R1515     0.78978431224823
    z[6,2,1]  R1516     6.9925773143768311e-01
    z[6,2,1]  R1517     7.4881255626678467e-01
    z[6,2,1]  R1518     9.1009914875030518e-02
    z[6,2,1]  R1519     8.7913438677787781e-02
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1360     -1
    z[6,2,2]  R1361     1
    z[6,2,2]  R1370     -1.7520034313201904e-01
    z[6,2,2]  R1371     -1.1685901880264282e-01
    z[6,2,2]  R1372     -1.6333484649658203e-01
    z[6,2,2]  R1373     -2.6785880327224731e-01
    z[6,2,2]  R1374     -1.8257641792297363e-01
    z[6,2,2]  R1375     -5.3789663314819336e-01
    z[6,2,2]  R1376     -1.7760933935642242e-01
    z[6,2,2]  R1377     -1.7945638298988342e-01
    z[6,2,2]  R1378     -3.8195076584815979e-01
    z[6,2,2]  R1379     -0.0339924618601799
    z[6,2,2]  R1380     2.8260305523872375e-01
    z[6,2,2]  R1381     7.1075963973999023e-01
    z[6,2,2]  R1382     6.8378818035125732e-01
    z[6,2,2]  R1383     5.4878199100494385e-01
    z[6,2,2]  R1384     4.9439480900764465e-01
    z[6,2,2]  R1385     6.2343740463256836e-01
    z[6,2,2]  R1386     5.0190275907516479e-01
    z[6,2,2]  R1387     4.8393711447715759e-01
    z[6,2,2]  R1388     3.8058194518089294e-01
    z[6,2,2]  R1389     4.3565174937248230e-01
    z[6,2,2]  R1390     3.2944139838218689e-01
    z[6,2,2]  R1391     -1.5970049798488617e-01
    z[6,2,2]  R1392     6.8351435661315918e-01
    z[6,2,2]  R1393     2.4656991660594940e-01
    z[6,2,2]  R1394     1.1712289601564407e-01
    z[6,2,2]  R1395     6.8361848592758179e-01
    z[6,2,2]  R1396     -1.3215051591396332e-01
    z[6,2,2]  R1397     -6.0098522901535034e-01
    z[6,2,2]  R1398     4.9145266413688660e-01
    z[6,2,2]  R1399     -0.706415057182312
    z[6,2,2]  R1400     3.1549575924873352e-01
    z[6,2,2]  R1401     3.8917210698127747e-01
    z[6,2,2]  R1402     4.1174092888832092e-01
    z[6,2,2]  R1403     3.1450986862182617e-01
    z[6,2,2]  R1404     4.2288318276405334e-02
    z[6,2,2]  R1405     6.3316076993942261e-01
    z[6,2,2]  R1406     2.1973705291748047e-01
    z[6,2,2]  R1407     -5.7728279381990433e-02
    z[6,2,2]  R1408     7.7076196670532227e-01
    z[6,2,2]  R1409     2.6455268263816833e-01
    z[6,2,2]  R1410     4.2389449477195740e-01
    z[6,2,2]  R1411     2.2439652681350708e-01
    z[6,2,2]  R1412     6.4922392368316650e-01
    z[6,2,2]  R1413     1.6333243250846863e-01
    z[6,2,2]  R1414     5.4032075405120850e-01
    z[6,2,2]  R1415     -1.8255543708801270e-01
    z[6,2,2]  R1416     3.0196553096175194e-02
    z[6,2,2]  R1417     0.215520977973938
    z[6,2,2]  R1418     -6.1001914739608765e-01
    z[6,2,2]  R1419     8.8725559413433075e-02
    z[6,2,2]  R1420     -2.3672574758529663e-01
    z[6,2,2]  R1421     2.5989213585853577e-01
    z[6,2,2]  R1422     1.6411387920379639e-01
    z[6,2,2]  R1423     2.8355222940444946e-01
    z[6,2,2]  R1424     9.0234234929084778e-02
    z[6,2,2]  R1425     -1.9573102891445160e-01
    z[6,2,2]  R1426     4.8574164509773254e-01
    z[6,2,2]  R1427     6.5591341257095337e-01
    z[6,2,2]  R1428     -3.4801873564720154e-01
    z[6,2,2]  R1429     -4.6952879428863525e-01
    z[6,2,2]  R1430     6.7564022541046143e-01
    z[6,2,2]  R1431     1.2817643582820892e-03
    z[6,2,2]  R1432     4.2216774821281433e-01
    z[6,2,2]  R1433     1.5791609883308411e-01
    z[6,2,2]  R1434     -7.6735556125640869e-01
    z[6,2,2]  R1435     2.5689122080802917e-01
    z[6,2,2]  R1436     0.395819753408432
    z[6,2,2]  R1437     2.0394693315029144e-01
    z[6,2,2]  R1438     -6.5956008434295654e-01
    z[6,2,2]  R1439     0.0963897705078125
    z[6,2,2]  R1440     2.1616187691688538e-01
    z[6,2,2]  R1441     3.8360023498535156e-01
    z[6,2,2]  R1442     0.522737979888916
    z[6,2,2]  R1443     -5.8665275573730469e-01
    z[6,2,2]  R1444     0.257693350315094
    z[6,2,2]  R1445     5.1851803064346313e-01
    z[6,2,2]  R1446     3.2036128640174866e-01
    z[6,2,2]  R1447     3.1420376896858215e-01
    z[6,2,2]  R1448     -4.5502316951751709e-01
    z[6,2,2]  R1449     -4.5573037862777710e-01
    z[6,2,2]  R1450     -6.1263483762741089e-01
    z[6,2,2]  R1451     3.7518495321273804e-01
    z[6,2,2]  R1452     4.6717628836631775e-01
    z[6,2,2]  R1453     2.9142412543296814e-01
    z[6,2,2]  R1454     3.8473892211914062e-01
    z[6,2,2]  R1455     4.9168238043785095e-01
    z[6,2,2]  R1456     -8.2693254947662354e-01
    z[6,2,2]  R1457     -3.9073020219802856e-01
    z[6,2,2]  R1458     -0.315792053937912
    z[6,2,2]  R1459     -1.5693803131580353e-01
    z[6,2,2]  R1460     -0.431908518075943
    z[6,2,2]  R1461     4.6711099147796631e-01
    z[6,2,2]  R1462     5.1746422052383423e-01
    z[6,2,2]  R1463     1.6701912879943848e-01
    z[6,2,2]  R1464     2.2287330031394958e-01
    z[6,2,2]  R1465     -6.4267307519912720e-01
    z[6,2,2]  R1466     -5.4743212461471558e-01
    z[6,2,2]  R1467     -5.9905093908309937e-01
    z[6,2,2]  R1468     3.9783951640129089e-01
    z[6,2,2]  R1469     5.3042483329772949e-01
    z[6,2,2]  R1470     6.0604417324066162e-01
    z[6,2,2]  R1471     1.0132411122322083e-01
    z[6,2,2]  R1472     2.7886566519737244e-01
    z[6,2,2]  R1473     -4.7770851850509644e-01
    z[6,2,2]  R1474     -3.4008646011352539e-01
    z[6,2,2]  R1475     3.9407119154930115e-01
    z[6,2,2]  R1476     4.1896224021911621e-01
    z[6,2,2]  R1477     5.4252862930297852e-01
    z[6,2,2]  R1478     5.3949481248855591e-01
    z[6,2,2]  R1479     3.8305473327636719e-01
    z[6,2,2]  R1480     -5.0815820693969727e-01
    z[6,2,2]  R1481     -4.2302456498146057e-01
    z[6,2,2]  R1482     -1.7271538078784943e-01
    z[6,2,2]  R1483     3.6518442630767822e-01
    z[6,2,2]  R1484     4.5311173796653748e-01
    z[6,2,2]  R1485     -5.6003034114837646e-01
    z[6,2,2]  R1486     1.2632903642952442e-02
    z[6,2,2]  R1487     2.2631423175334930e-01
    z[6,2,2]  R1488     0.0645333081483841
    z[6,2,2]  R1489     2.3833848536014557e-01
    z[6,2,2]  R1490     -5.6410312652587891e-01
    z[6,2,2]  R1491     -4.5141422748565674e-01
    z[6,2,2]  R1492     -3.5690742731094360e-01
    z[6,2,2]  R1493     -4.5796698331832886e-01
    z[6,2,2]  R1494     -6.8271929025650024e-01
    z[6,2,2]  R1495     -6.9360530376434326e-01
    z[6,2,2]  R1496     -5.2525812387466431e-01
    z[6,2,2]  R1497     1.9719203934073448e-02
    z[6,2,2]  R1498     6.9385424256324768e-02
    z[6,2,2]  R1499     -5.6376541033387184e-03
    z[6,2,2]  R1500     -2.7912083268165588e-01
    z[6,2,2]  R1501     2.6320907473564148e-01
    z[6,2,2]  R1502     5.5256552994251251e-02
    z[6,2,2]  R1503     3.1515088677406311e-01
    z[6,2,2]  R1504     1.2877109646797180e-01
    z[6,2,2]  R1505     -2.0384170114994049e-01
    z[6,2,2]  R1506     1.8829772248864174e-02
    z[6,2,2]  R1507     3.6813059449195862e-01
    z[6,2,2]  R1508     4.3131643533706665e-01
    z[6,2,2]  R1509     1.9450370222330093e-02
    z[6,2,2]  R1510     -6.0998445749282837e-01
    z[6,2,2]  R1511     -6.5625613927841187e-01
    z[6,2,2]  R1512     -1.3309018313884735e-01
    z[6,2,2]  R1513     2.6949909329414368e-01
    z[6,2,2]  R1514     -8.9618965983390808e-02
    z[6,2,2]  R1515     5.2157271653413773e-02
    z[6,2,2]  R1516     7.9599849879741669e-02
    z[6,2,2]  R1517     1.7099264264106750e-01
    z[6,2,2]  R1518     6.9347119331359863e-01
    z[6,2,2]  R1519     3.5757419466972351e-01
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1362     -1
    z[6,2,3]  R1363     1
    z[6,2,3]  R1370     1.9722686707973480e-01
    z[6,2,3]  R1371     -1.7805849015712738e-01
    z[6,2,3]  R1372     -1.3938149809837341e-01
    z[6,2,3]  R1373     3.1448623538017273e-01
    z[6,2,3]  R1374     0.00422905758023262
    z[6,2,3]  R1375     3.0133891850709915e-02
    z[6,2,3]  R1376     -5.1916502416133881e-02
    z[6,2,3]  R1377     -4.8395209014415741e-02
    z[6,2,3]  R1378     -7.3296025395393372e-02
    z[6,2,3]  R1379     2.6381894946098328e-01
    z[6,2,3]  R1380     -3.9144456386566162e-01
    z[6,2,3]  R1381     2.1493844687938690e-01
    z[6,2,3]  R1382     -3.2905817031860352e-02
    z[6,2,3]  R1383     1.3282246887683868e-01
    z[6,2,3]  R1384     -4.2959639430046082e-01
    z[6,2,3]  R1385     -2.6216539740562439e-01
    z[6,2,3]  R1386     -1.5089030377566814e-02
    z[6,2,3]  R1387     2.9635429382324219e-01
    z[6,2,3]  R1388     -3.1604444980621338e-01
    z[6,2,3]  R1389     2.2651587426662445e-01
    z[6,2,3]  R1390     1.9076961278915405e-01
    z[6,2,3]  R1391     -1.6248348355293274e-01
    z[6,2,3]  R1392     -3.2762053608894348e-01
    z[6,2,3]  R1393     -9.8815739154815674e-02
    z[6,2,3]  R1394     4.4113656878471375e-01
    z[6,2,3]  R1395     1.8524500727653503e-01
    z[6,2,3]  R1396     2.6893270015716553e-01
    z[6,2,3]  R1397     -8.2504920661449432e-02
    z[6,2,3]  R1398     -3.0172142386436462e-01
    z[6,2,3]  R1399     2.6870843768119812e-01
    z[6,2,3]  R1400     2.9335431754589081e-02
    z[6,2,3]  R1401     1.2446004152297974e-01
    z[6,2,3]  R1402     -0.279773473739624
    z[6,2,3]  R1403     1.1687626689672470e-01
    z[6,2,3]  R1404     1.3141964375972748e-01
    z[6,2,3]  R1405     -3.0197307467460632e-01
    z[6,2,3]  R1406     -0.718078076839447
    z[6,2,3]  R1407     -2.2317622601985931e-01
    z[6,2,3]  R1408     -7.3442630469799042e-02
    z[6,2,3]  R1409     -1.9902646541595459e-01
    z[6,2,3]  R1410     -3.9294418692588806e-01
    z[6,2,3]  R1411     -1.0631754249334335e-01
    z[6,2,3]  R1412     8.6140096187591553e-02
    z[6,2,3]  R1413     -0.0592268705368042
    z[6,2,3]  R1414     1.1346279084682465e-01
    z[6,2,3]  R1415     5.5354988574981689e-01
    z[6,2,3]  R1416     -2.1806603670120239e-01
    z[6,2,3]  R1417     1.3416700065135956e-01
    z[6,2,3]  R1418     -4.5715585350990295e-01
    z[6,2,3]  R1419     -2.9148977249860764e-02
    z[6,2,3]  R1420     -2.1368084847927094e-01
    z[6,2,3]  R1421     -1.3163023628294468e-02
    z[6,2,3]  R1422     5.4514998197555542e-01
    z[6,2,3]  R1423     -1.0321961343288422e-01
    z[6,2,3]  R1424     5.3564912080764771e-01
    z[6,2,3]  R1425     2.9216277599334717e-01
    z[6,2,3]  R1426     3.0592599511146545e-01
    z[6,2,3]  R1427     1.5349418856203556e-02
    z[6,2,3]  R1428     -1.7554216086864471e-01
    z[6,2,3]  R1429     1.0113058984279633e-01
    z[6,2,3]  R1430     4.0966841578483582e-01
    z[6,2,3]  R1431     -3.4179797768592834e-01
    z[6,2,3]  R1432     -2.9593538492918015e-03
    z[6,2,3]  R1433     -1.8164904788136482e-02
    z[6,2,3]  R1434     -3.0162784457206726e-01
    z[6,2,3]  R1435     2.2983743250370026e-01
    z[6,2,3]  R1436     2.0392403006553650e-01
    z[6,2,3]  R1437     3.1509986519813538e-01
    z[6,2,3]  R1438     -4.8180431127548218e-01
    z[6,2,3]  R1439     4.9940237402915955e-01
    z[6,2,3]  R1440     0.303492933511734
    z[6,2,3]  R1441     0.298991322517395
    z[6,2,3]  R1442     -9.7847640514373779e-02
    z[6,2,3]  R1443     -3.3750689029693604e-01
    z[6,2,3]  R1444     3.1253427267074585e-01
    z[6,2,3]  R1445     1.9220243394374847e-01
    z[6,2,3]  R1446     1.3646423816680908e-01
    z[6,2,3]  R1447     -2.2059574723243713e-01
    z[6,2,3]  R1448     1.5589003264904022e-01
    z[6,2,3]  R1449     3.3723658323287964e-01
    z[6,2,3]  R1450     5.4800111800432205e-02
    z[6,2,3]  R1451     1.9486233592033386e-01
    z[6,2,3]  R1452     1.5734905004501343e-01
    z[6,2,3]  R1453     -6.4490497112274170e-02
    z[6,2,3]  R1454     -0.0396580696105957
    z[6,2,3]  R1455     6.9540542364120483e-01
    z[6,2,3]  R1456     7.5495615601539612e-02
    z[6,2,3]  R1457     3.2061886787414551e-01
    z[6,2,3]  R1458     4.6656790375709534e-01
    z[6,2,3]  R1459     0.474361777305603
    z[6,2,3]  R1460     -3.0580973625183105e-01
    z[6,2,3]  R1461     4.5167854428291321e-01
    z[6,2,3]  R1462     -3.4414285421371460e-01
    z[6,2,3]  R1463     2.4899591505527496e-01
    z[6,2,3]  R1464     -7.5129413604736328e-01
    z[6,2,3]  R1465     3.4967169165611267e-01
    z[6,2,3]  R1466     4.1893583536148071e-01
    z[6,2,3]  R1467     -2.6354610919952393e-01
    z[6,2,3]  R1468     1.5516200102865696e-02
    z[6,2,3]  R1469     1.0314907878637314e-01
    z[6,2,3]  R1470     -0.500938892364502
    z[6,2,3]  R1471     1.9754789769649506e-01
    z[6,2,3]  R1472     2.4601487815380096e-01
    z[6,2,3]  R1473     -6.2834209203720093e-01
    z[6,2,3]  R1474     9.7366660833358765e-02
    z[6,2,3]  R1475     2.8921690583229065e-01
    z[6,2,3]  R1476     1.8290439248085022e-01
    z[6,2,3]  R1477     1.8155736848711967e-02
    z[6,2,3]  R1478     -1.2649394571781158e-01
    z[6,2,3]  R1479     -3.0813655257225037e-01
    z[6,2,3]  R1480     -2.5656517595052719e-02
    z[6,2,3]  R1481     1.0290110856294632e-01
    z[6,2,3]  R1482     -3.7951406836509705e-01
    z[6,2,3]  R1483     1.5847012400627136e-01
    z[6,2,3]  R1484     -9.5752961933612823e-02
    z[6,2,3]  R1485     1.2112659215927124e-01
    z[6,2,3]  R1486     -2.8817000985145569e-01
    z[6,2,3]  R1487     -1.2101585045456886e-02
    z[6,2,3]  R1488     -3.5101306438446045e-01
    z[6,2,3]  R1489     2.6030080392956734e-02
    z[6,2,3]  R1490     2.0595878362655640e-01
    z[6,2,3]  R1491     2.9962339997291565e-01
    z[6,2,3]  R1492     3.5861894488334656e-01
    z[6,2,3]  R1493     7.0065456628799438e-01
    z[6,2,3]  R1494     -2.4264791607856750e-01
    z[6,2,3]  R1495     -1.7299422621726990e-01
    z[6,2,3]  R1496     -1.3633483648300171e-01
    z[6,2,3]  R1497     2.0767839252948761e-01
    z[6,2,3]  R1498     -6.9356516178231686e-05
    z[6,2,3]  R1499     -1.2251529842615128e-01
    z[6,2,3]  R1500     8.1395357847213745e-01
    z[6,2,3]  R1501     1.0558506101369858e-01
    z[6,2,3]  R1502     -1.3593651354312897e-01
    z[6,2,3]  R1503     2.8788870573043823e-01
    z[6,2,3]  R1504     2.0491313934326172e-01
    z[6,2,3]  R1505     -1.5126244723796844e-01
    z[6,2,3]  R1506     2.3018684983253479e-01
    z[6,2,3]  R1507     3.3910858631134033e-01
    z[6,2,3]  R1508     0.0849059447646141
    z[6,2,3]  R1509     2.1504996716976166e-01
    z[6,2,3]  R1510     3.2789698243141174e-01
    z[6,2,3]  R1511     6.5549522638320923e-02
    z[6,2,3]  R1512     -2.1718624234199524e-01
    z[6,2,3]  R1513     -2.5616735219955444e-02
    z[6,2,3]  R1514     -3.9837455749511719e-01
    z[6,2,3]  R1515     3.6927703768014908e-02
    z[6,2,3]  R1516     3.8007974624633789e-01
    z[6,2,3]  R1517     -5.1780611276626587e-01
    z[6,2,3]  R1518     -0.0729045420885086
    z[6,2,3]  R1519     -1.4556339383125305e-01
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1364     -1
    z[6,2,4]  R1365     1
    z[6,2,4]  R1370     2.5442723184823990e-02
    z[6,2,4]  R1371     1.5681026875972748e-01
    z[6,2,4]  R1372     9.9835090339183807e-02
    z[6,2,4]  R1373     2.4434188008308411e-01
    z[6,2,4]  R1374     -3.4472875297069550e-02
    z[6,2,4]  R1375     3.6078128218650818e-01
    z[6,2,4]  R1376     2.0710060000419617e-01
    z[6,2,4]  R1377     4.5984137803316116e-02
    z[6,2,4]  R1378     2.6967635750770569e-01
    z[6,2,4]  R1379     3.3857962489128113e-01
    z[6,2,4]  R1380     1.8772387504577637e-01
    z[6,2,4]  R1381     -6.4913578331470490e-02
    z[6,2,4]  R1382     3.2985430955886841e-01
    z[6,2,4]  R1383     3.9232546091079712e-01
    z[6,2,4]  R1384     3.3945900201797485e-01
    z[6,2,4]  R1385     1.2313283234834671e-01
    z[6,2,4]  R1386     -4.2394474148750305e-01
    z[6,2,4]  R1387     3.2723551988601685e-01
    z[6,2,4]  R1388     5.8565360307693481e-01
    z[6,2,4]  R1389     2.8684270381927490e-01
    z[6,2,4]  R1390     -3.7396547198295593e-01
    z[6,2,4]  R1391     -1.7767411470413208e-01
    z[6,2,4]  R1392     2.1423611044883728e-01
    z[6,2,4]  R1393     4.1241145133972168e-01
    z[6,2,4]  R1394     -8.4720002487301826e-03
    z[6,2,4]  R1395     -2.1629419177770615e-02
    z[6,2,4]  R1396     -5.6049692630767822e-01
    z[6,2,4]  R1397     -4.1762074828147888e-01
    z[6,2,4]  R1398     -0.309527724981308
    z[6,2,4]  R1399     -1.8898989260196686e-01
    z[6,2,4]  R1400     -4.7102957963943481e-01
    z[6,2,4]  R1401     1.1562176048755646e-01
    z[6,2,4]  R1402     3.6604840308427811e-02
    z[6,2,4]  R1403     4.4977459311485291e-01
    z[6,2,4]  R1404     3.2556807994842529e-01
    z[6,2,4]  R1405     -3.6292336881160736e-02
    z[6,2,4]  R1406     2.5714278221130371e-02
    z[6,2,4]  R1407     -3.8738265633583069e-01
    z[6,2,4]  R1408     2.2139152884483337e-01
    z[6,2,4]  R1409     -3.5999670624732971e-01
    z[6,2,4]  R1410     -1.6703774034976959e-01
    z[6,2,4]  R1411     6.3023701310157776e-02
    z[6,2,4]  R1412     -3.0715823173522949e-02
    z[6,2,4]  R1413     -3.0421710014343262e-01
    z[6,2,4]  R1414     2.1932624280452728e-01
    z[6,2,4]  R1415     -1.7460497096180916e-02
    z[6,2,4]  R1416     4.3190225958824158e-01
    z[6,2,4]  R1417     0.67954021692276
    z[6,2,4]  R1418     -4.0179529786109924e-01
    z[6,2,4]  R1419     -1.0678673535585403e-01
    z[6,2,4]  R1420     2.9650720953941345e-01
    z[6,2,4]  R1421     -3.4526339173316956e-01
    z[6,2,4]  R1422     -1.7809841036796570e-01
    z[6,2,4]  R1423     6.9740664958953857e-01
    z[6,2,4]  R1424     3.9971670508384705e-01
    z[6,2,4]  R1425     -1.9026480615139008e-01
    z[6,2,4]  R1426     -1.3448676466941833e-01
    z[6,2,4]  R1427     -2.5099346041679382e-01
    z[6,2,4]  R1428     -3.4589907526969910e-01
    z[6,2,4]  R1429     -6.4240492880344391e-02
    z[6,2,4]  R1430     -8.8118426501750946e-02
    z[6,2,4]  R1431     4.5130811631679535e-02
    z[6,2,4]  R1432     -7.5812175869941711e-02
    z[6,2,4]  R1433     4.6922618150711060e-01
    z[6,2,4]  R1434     -2.1081276237964630e-01
    z[6,2,4]  R1435     -5.4514068365097046e-01
    z[6,2,4]  R1436     3.0137148499488831e-01
    z[6,2,4]  R1437     2.5732040405273438e-01
    z[6,2,4]  R1438     -2.0544733107089996e-01
    z[6,2,4]  R1439     4.3823051452636719e-01
    z[6,2,4]  R1440     1.1673387885093689e-01
    z[6,2,4]  R1441     -4.8256742954254150e-01
    z[6,2,4]  R1442     2.4360392987728119e-01
    z[6,2,4]  R1443     -3.2086694240570068e-01
    z[6,2,4]  R1444     4.6117997169494629e-01
    z[6,2,4]  R1445     3.9515700936317444e-01
    z[6,2,4]  R1446     4.5218691229820251e-02
    z[6,2,4]  R1447     -1.8601721525192261e-01
    z[6,2,4]  R1448     -3.0061137676239014e-01
    z[6,2,4]  R1449     1.4628148078918457e-01
    z[6,2,4]  R1450     -4.4163670390844345e-02
    z[6,2,4]  R1451     2.9067862033843994e-01
    z[6,2,4]  R1452     -4.5216238498687744e-01
    z[6,2,4]  R1453     -0.154743030667305
    z[6,2,4]  R1454     -2.7844479680061340e-01
    z[6,2,4]  R1455     -1.9415840506553650e-01
    z[6,2,4]  R1456     1.0383749753236771e-01
    z[6,2,4]  R1457     1.2211102247238159e-01
    z[6,2,4]  R1458     -2.6020416617393494e-01
    z[6,2,4]  R1459     -5.8943405747413635e-02
    z[6,2,4]  R1460     -3.0825346708297729e-01
    z[6,2,4]  R1461     3.0930081382393837e-02
    z[6,2,4]  R1462     -1.2759761512279510e-01
    z[6,2,4]  R1463     -6.0336075723171234e-02
    z[6,2,4]  R1464     1.0239310562610626e-01
    z[6,2,4]  R1465     -8.9971348643302917e-03
    z[6,2,4]  R1466     -2.2755637764930725e-03
    z[6,2,4]  R1467     -2.7343245223164558e-02
    z[6,2,4]  R1468     2.0597030222415924e-01
    z[6,2,4]  R1469     -1.0387220233678818e-01
    z[6,2,4]  R1470     2.8337278962135315e-01
    z[6,2,4]  R1471     1.1322257667779922e-01
    z[6,2,4]  R1472     2.7698168158531189e-01
    z[6,2,4]  R1473     -5.7650644332170486e-02
    z[6,2,4]  R1474     -7.6792903244495392e-02
    z[6,2,4]  R1475     -6.1464175581932068e-02
    z[6,2,4]  R1476     -2.8007525205612183e-01
    z[6,2,4]  R1477     -1.7160907387733459e-01
    z[6,2,4]  R1478     -1.3729830272495747e-02
    z[6,2,4]  R1479     -1.3171419501304626e-01
    z[6,2,4]  R1480     -1.5438847243785858e-01
    z[6,2,4]  R1481     -7.6973032264504582e-05
    z[6,2,4]  R1482     -3.3534789085388184e-01
    z[6,2,4]  R1483     -4.2755752801895142e-01
    z[6,2,4]  R1484     2.4388051033020020e-01
    z[6,2,4]  R1485     -2.8327324986457825e-01
    z[6,2,4]  R1486     -3.8198661059141159e-02
    z[6,2,4]  R1487     -3.8981625437736511e-01
    z[6,2,4]  R1488     -1.3761992752552032e-01
    z[6,2,4]  R1489     1.5958875417709351e-01
    z[6,2,4]  R1490     -1.5392169356346130e-01
    z[6,2,4]  R1491     3.6746963858604431e-02
    z[6,2,4]  R1492     -0.658660352230072
    z[6,2,4]  R1493     1.4881216920912266e-02
    z[6,2,4]  R1494     2.4512492120265961e-01
    z[6,2,4]  R1495     -4.6883486211299896e-02
    z[6,2,4]  R1496     -2.8469032049179077e-01
    z[6,2,4]  R1497     1.4053110778331757e-01
    z[6,2,4]  R1498     -9.3117050826549530e-02
    z[6,2,4]  R1499     2.6159879565238953e-01
    z[6,2,4]  R1500     -2.2049877047538757e-01
    z[6,2,4]  R1501     -5.9276461601257324e-02
    z[6,2,4]  R1502     -0.257587730884552
    z[6,2,4]  R1503     -1.1354881525039673e-01
    z[6,2,4]  R1504     -7.5281903147697449e-02
    z[6,2,4]  R1505     2.9876199364662170e-01
    z[6,2,4]  R1506     6.2722176313400269e-02
    z[6,2,4]  R1507     1.0926172882318497e-01
    z[6,2,4]  R1508     2.9511335492134094e-01
    z[6,2,4]  R1509     -7.2376020252704620e-02
    z[6,2,4]  R1510     -2.0937213674187660e-02
    z[6,2,4]  R1511     -1.9255377352237701e-01
    z[6,2,4]  R1512     2.1501084789633751e-02
    z[6,2,4]  R1513     -8.2156062126159668e-03
    z[6,2,4]  R1514     2.2068174183368683e-01
    z[6,2,4]  R1515     3.2346978783607483e-01
    z[6,2,4]  R1516     3.5036367177963257e-01
    z[6,2,4]  R1517     2.9226174950599670e-01
    z[6,2,4]  R1518     -5.6999187916517258e-02
    z[6,2,4]  R1519     2.0588155090808868e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1366     -1
    z[6,2,5]  R1367     1
    z[6,2,5]  R1370     1.8363554030656815e-02
    z[6,2,5]  R1371     -9.5805518329143524e-02
    z[6,2,5]  R1372     1.2756167352199554e-01
    z[6,2,5]  R1373     -5.5215455591678619e-02
    z[6,2,5]  R1374     1.4253821969032288e-01
    z[6,2,5]  R1375     1.5330988168716431e-01
    z[6,2,5]  R1376     -1.7740002274513245e-01
    z[6,2,5]  R1377     6.8646006286144257e-02
    z[6,2,5]  R1378     9.1301478445529938e-02
    z[6,2,5]  R1379     1.0748646408319473e-01
    z[6,2,5]  R1380     -6.3528245687484741e-01
    z[6,2,5]  R1381     -5.5146205425262451e-01
    z[6,2,5]  R1382     -1.5791727602481842e-01
    z[6,2,5]  R1383     1.1527353525161743e-01
    z[6,2,5]  R1384     -1.3519582152366638e-01
    z[6,2,5]  R1385     -4.2881774902343750e-01
    z[6,2,5]  R1386     -6.6672730445861816e-01
    z[6,2,5]  R1387     -3.4675487875938416e-01
    z[6,2,5]  R1388     -3.6504715681076050e-01
    z[6,2,5]  R1389     -6.0960131883621216e-01
    z[6,2,5]  R1390     -1.7386928200721741e-01
    z[6,2,5]  R1391     6.6571027040481567e-02
    z[6,2,5]  R1392     8.7013505399227142e-02
    z[6,2,5]  R1393     2.4824562668800354e-01
    z[6,2,5]  R1394     3.5148376226425171e-01
    z[6,2,5]  R1395     2.2151772677898407e-01
    z[6,2,5]  R1396     1.1689832806587219e-01
    z[6,2,5]  R1397     2.1122368052601814e-02
    z[6,2,5]  R1398     4.5777830481529236e-01
    z[6,2,5]  R1399     1.2328056618571281e-02
    z[6,2,5]  R1400     -0.448505699634552
    z[6,2,5]  R1401     -3.6816036701202393e-01
    z[6,2,5]  R1402     2.8279694914817810e-01
    z[6,2,5]  R1403     -5.4161384701728821e-02
    z[6,2,5]  R1404     1.2324440479278564e-01
    z[6,2,5]  R1405     -1.0633645206689835e-01
    z[6,2,5]  R1406     2.5598341599106789e-02
    z[6,2,5]  R1407     -2.3073397576808929e-02
    z[6,2,5]  R1408     -1.0603081434965134e-01
    z[6,2,5]  R1409     -6.0287380218505859e-01
    z[6,2,5]  R1410     -2.1796286106109619e-01
    z[6,2,5]  R1411     -1.5515540540218353e-01
    z[6,2,5]  R1412     -3.2942584156990051e-01
    z[6,2,5]  R1413     -2.4291633069515228e-01
    z[6,2,5]  R1414     -0.422921746969223
    z[6,2,5]  R1415     -4.3859258294105530e-01
    z[6,2,5]  R1416     -1.4036697149276733e-01
    z[6,2,5]  R1417     -1.4414627850055695e-01
    z[6,2,5]  R1418     -2.9180753231048584e-01
    z[6,2,5]  R1419     0.622606098651886
    z[6,2,5]  R1420     2.4356535077095032e-01
    z[6,2,5]  R1421     -3.0759337544441223e-01
    z[6,2,5]  R1422     -2.7960723638534546e-01
    z[6,2,5]  R1423     -0.421384334564209
    z[6,2,5]  R1424     -5.0109249353408813e-01
    z[6,2,5]  R1425     -6.7544782161712646e-01
    z[6,2,5]  R1426     5.5559748411178589e-01
    z[6,2,5]  R1427     3.2968875765800476e-01
    z[6,2,5]  R1428     4.8926264047622681e-02
    z[6,2,5]  R1429     1.0916931927204132e-01
    z[6,2,5]  R1430     -2.5254514813423157e-01
    z[6,2,5]  R1431     -6.4476072788238525e-01
    z[6,2,5]  R1432     3.6030894517898560e-01
    z[6,2,5]  R1433     -4.0189573168754578e-01
    z[6,2,5]  R1434     -2.4131463468074799e-01
    z[6,2,5]  R1435     -2.2471027076244354e-01
    z[6,2,5]  R1436     0.314242959022522
    z[6,2,5]  R1437     -3.2006821036338806e-01
    z[6,2,5]  R1438     -3.0427744984626770e-01
    z[6,2,5]  R1439     1.2288712710142136e-01
    z[6,2,5]  R1440     9.0067885816097260e-02
    z[6,2,5]  R1441     -4.1855999827384949e-01
    z[6,2,5]  R1442     -5.1251932978630066e-02
    z[6,2,5]  R1443     -3.1081253290176392e-01
    z[6,2,5]  R1444     -4.3841204047203064e-01
    z[6,2,5]  R1445     -4.6696880459785461e-01
    z[6,2,5]  R1446     -7.8776758909225464e-01
    z[6,2,5]  R1447     -0.0409141406416893
    z[6,2,5]  R1448     -4.1150298714637756e-01
    z[6,2,5]  R1449     -4.4737223535776138e-02
    z[6,2,5]  R1450     -2.4522005021572113e-01
    z[6,2,5]  R1451     -4.9179011583328247e-01
    z[6,2,5]  R1452     -4.9940440058708191e-01
    z[6,2,5]  R1453     -7.4444037675857544e-01
    z[6,2,5]  R1454     1.4940799772739410e-01
    z[6,2,5]  R1455     2.4619838595390320e-01
    z[6,2,5]  R1456     -1.0064287483692169e-01
    z[6,2,5]  R1457     4.2561632394790649e-01
    z[6,2,5]  R1458     9.8149076104164124e-02
    z[6,2,5]  R1459     1.9988100230693817e-01
    z[6,2,5]  R1460     -2.0188757777214050e-01
    z[6,2,5]  R1461     1.4005610346794128e-01
    z[6,2,5]  R1462     -0.479707807302475
    z[6,2,5]  R1463     -8.0626225471496582e-01
    z[6,2,5]  R1464     -1.2126793712377548e-01
    z[6,2,5]  R1465     1.4181299507617950e-01
    z[6,2,5]  R1466     1.1308369040489197e-01
    z[6,2,5]  R1467     4.5485013723373413e-01
    z[6,2,5]  R1468     -2.9244298115372658e-02
    z[6,2,5]  R1469     1.4941900968551636e-01
    z[6,2,5]  R1470     -2.0874448120594025e-01
    z[6,2,5]  R1471     -7.2684699296951294e-01
    z[6,2,5]  R1472     -3.9484921097755432e-01
    z[6,2,5]  R1473     -1.2284660339355469e-01
    z[6,2,5]  R1474     1.7613308131694794e-01
    z[6,2,5]  R1475     -1.5199208259582520e-01
    z[6,2,5]  R1476     -0.0385298952460289
    z[6,2,5]  R1477     -3.2177552580833435e-02
    z[6,2,5]  R1478     -2.9607942700386047e-01
    z[6,2,5]  R1479     -3.6532118916511536e-01
    z[6,2,5]  R1480     -1.0144112259149551e-01
    z[6,2,5]  R1481     -0.460526704788208
    z[6,2,5]  R1482     -6.2519145011901855e-01
    z[6,2,5]  R1483     2.1900166571140289e-01
    z[6,2,5]  R1484     9.5428600907325745e-02
    z[6,2,5]  R1485     -1.0198953002691269e-01
    z[6,2,5]  R1486     -1.9380992650985718e-01
    z[6,2,5]  R1487     -6.1036027967929840e-02
    z[6,2,5]  R1488     -2.1970821544528008e-02
    z[6,2,5]  R1489     -9.4059586524963379e-02
    z[6,2,5]  R1490     -1.6372489929199219e-01
    z[6,2,5]  R1491     4.2902618646621704e-02
    z[6,2,5]  R1492     5.2850235253572464e-02
    z[6,2,5]  R1493     -1.5487061440944672e-01
    z[6,2,5]  R1494     -9.9672386422753334e-03
    z[6,2,5]  R1495     -1.5553395450115204e-01
    z[6,2,5]  R1496     4.0574066340923309e-02
    z[6,2,5]  R1497     -0.122328020632267
    z[6,2,5]  R1498     -3.4870034456253052e-01
    z[6,2,5]  R1499     1.8090550601482391e-01
    z[6,2,5]  R1500     -5.0910115242004395e-02
    z[6,2,5]  R1501     -1.6325891017913818e-02
    z[6,2,5]  R1502     0.0240008644759655
    z[6,2,5]  R1503     1.7423366010189056e-01
    z[6,2,5]  R1504     7.4190340936183929e-02
    z[6,2,5]  R1505     -3.4981764853000641e-02
    z[6,2,5]  R1506     4.1195428371429443e-01
    z[6,2,5]  R1507     -1.1364228278398514e-01
    z[6,2,5]  R1508     -8.9100472629070282e-02
    z[6,2,5]  R1509     -3.0492374300956726e-01
    z[6,2,5]  R1510     -1.1079335212707520e-01
    z[6,2,5]  R1511     5.3455509245395660e-02
    z[6,2,5]  R1512     -1.5185537934303284e-01
    z[6,2,5]  R1513     -1.5557087957859039e-01
    z[6,2,5]  R1514     1.5664680302143097e-01
    z[6,2,5]  R1515     3.6281082034111023e-01
    z[6,2,5]  R1516     -9.8257049918174744e-02
    z[6,2,5]  R1517     3.9560042321681976e-02
    z[6,2,5]  R1518     -1.9892990589141846e-01
    z[6,2,5]  R1519     -5.1982551813125610e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1368     -1
    z[6,2,6]  R1369     1
    z[6,2,6]  R1370     -1.1770492047071457e-01
    z[6,2,6]  R1371     -4.4261552393436432e-03
    z[6,2,6]  R1372     -1.6064360737800598e-01
    z[6,2,6]  R1373     -1.6098898649215698e-01
    z[6,2,6]  R1374     -0.301470011472702
    z[6,2,6]  R1375     1.6815978288650513e-01
    z[6,2,6]  R1376     -1.2203180789947510e-01
    z[6,2,6]  R1377     1.4321976900100708e-01
    z[6,2,6]  R1378     -1.0164518840610981e-02
    z[6,2,6]  R1379     2.7247878909111023e-01
    z[6,2,6]  R1380     1.8773525953292847e-01
    z[6,2,6]  R1381     -2.3031197488307953e-01
    z[6,2,6]  R1382     3.7443738430738449e-02
    z[6,2,6]  R1383     -5.8671992272138596e-02
    z[6,2,6]  R1384     -4.4896829128265381e-01
    z[6,2,6]  R1385     0.0770488902926445
    z[6,2,6]  R1386     -2.5659623742103577e-01
    z[6,2,6]  R1387     -7.1774378418922424e-02
    z[6,2,6]  R1388     3.3430272340774536e-01
    z[6,2,6]  R1389     2.6974827051162720e-02
    z[6,2,6]  R1390     -6.8659879267215729e-02
    z[6,2,6]  R1391     8.4615841507911682e-02
    z[6,2,6]  R1392     9.7019389271736145e-02
    z[6,2,6]  R1393     3.8433033227920532e-01
    z[6,2,6]  R1394     -6.3249057531356812e-01
    z[6,2,6]  R1395     -2.1371269226074219e-01
    z[6,2,6]  R1396     -4.1133394837379456e-01
    z[6,2,6]  R1397     -0.0805663913488388
    z[6,2,6]  R1398     1.8261478841304779e-01
    z[6,2,6]  R1399     -2.9590731486678123e-02
    z[6,2,6]  R1400     -9.6845522522926331e-02
    z[6,2,6]  R1401     2.0080134272575378e-01
    z[6,2,6]  R1402     -2.0039488375186920e-01
    z[6,2,6]  R1403     3.6406585574150085e-01
    z[6,2,6]  R1404     -2.0754756033420563e-01
    z[6,2,6]  R1405     0.0768914446234703
    z[6,2,6]  R1406     1.9086304306983948e-01
    z[6,2,6]  R1407     2.0770902931690216e-01
    z[6,2,6]  R1408     4.1985239833593369e-02
    z[6,2,6]  R1409     -2.1316848695278168e-01
    z[6,2,6]  R1410     -7.0847973227500916e-02
    z[6,2,6]  R1411     1.4123211801052094e-01
    z[6,2,6]  R1412     -7.8969992697238922e-02
    z[6,2,6]  R1413     -1.1099644750356674e-01
    z[6,2,6]  R1414     -1.9904676079750061e-01
    z[6,2,6]  R1415     -2.7316769957542419e-01
    z[6,2,6]  R1416     3.7511962652206421e-01
    z[6,2,6]  R1417     -2.7071639895439148e-01
    z[6,2,6]  R1418     0.0816039890050888
    z[6,2,6]  R1419     1.1319984495639801e-01
    z[6,2,6]  R1420     2.7768164873123169e-01
    z[6,2,6]  R1421     6.2627747654914856e-02
    z[6,2,6]  R1422     -0.0424545481801033
    z[6,2,6]  R1423     -4.8246022313833237e-02
    z[6,2,6]  R1424     -1.7423997819423676e-01
    z[6,2,6]  R1425     -2.3064975440502167e-01
    z[6,2,6]  R1426     -2.5198507308959961e-01
    z[6,2,6]  R1427     -2.8632849454879761e-01
    z[6,2,6]  R1428     -1.7734473943710327e-01
    z[6,2,6]  R1429     0.0823395624756813
    z[6,2,6]  R1430     -2.5365290045738220e-01
    z[6,2,6]  R1431     5.3452465683221817e-02
    z[6,2,6]  R1432     1.7981614917516708e-02
    z[6,2,6]  R1433     8.4437653422355652e-02
    z[6,2,6]  R1434     1.7719270288944244e-01
    z[6,2,6]  R1435     -4.9363183975219727e-01
    z[6,2,6]  R1436     1.7795109748840332e-01
    z[6,2,6]  R1437     -6.2378573417663574e-01
    z[6,2,6]  R1438     -2.1367833018302917e-01
    z[6,2,6]  R1439     1.7445491254329681e-01
    z[6,2,6]  R1440     1.5673954784870148e-01
    z[6,2,6]  R1441     -0.282549113035202
    z[6,2,6]  R1442     -9.0264402329921722e-02
    z[6,2,6]  R1443     2.8157643973827362e-03
    z[6,2,6]  R1444     -6.1274436302483082e-03
    z[6,2,6]  R1445     2.0600537955760956e-01
    z[6,2,6]  R1446     1.3947731256484985e-01
    z[6,2,6]  R1447     1.3983491063117981e-01
    z[6,2,6]  R1448     -2.2028565406799316e-01
    z[6,2,6]  R1449     1.3029728829860687e-01
    z[6,2,6]  R1450     -2.9339674860239029e-02
    z[6,2,6]  R1451     -1.4245378971099854e-01
    z[6,2,6]  R1452     -0.257985919713974
    z[6,2,6]  R1453     -2.4304588139057159e-01
    z[6,2,6]  R1454     -5.2570408582687378e-01
    z[6,2,6]  R1455     3.2696448266506195e-02
    z[6,2,6]  R1456     -3.7743654102087021e-02
    z[6,2,6]  R1457     -0.148038849234581
    z[6,2,6]  R1458     -2.4738231301307678e-01
    z[6,2,6]  R1459     -2.0432794094085693e-01
    z[6,2,6]  R1460     -1.5077529847621918e-01
    z[6,2,6]  R1461     -1.4350248873233795e-01
    z[6,2,6]  R1462     1.1306065320968628e-01
    z[6,2,6]  R1463     1.0979101061820984e-01
    z[6,2,6]  R1464     3.0902945995330811e-01
    z[6,2,6]  R1465     0.0984988585114479
    z[6,2,6]  R1466     -3.4991574287414551e-01
    z[6,2,6]  R1467     -1.4413505792617798e-01
    z[6,2,6]  R1468     2.2152608260512352e-02
    z[6,2,6]  R1469     -7.0057488977909088e-02
    z[6,2,6]  R1470     1.2082371860742569e-01
    z[6,2,6]  R1471     7.4731156229972839e-02
    z[6,2,6]  R1472     0.2565937936306
    z[6,2,6]  R1473     2.3028762638568878e-01
    z[6,2,6]  R1474     -2.3457955569028854e-02
    z[6,2,6]  R1475     1.1988984793424606e-01
    z[6,2,6]  R1476     1.9500355422496796e-01
    z[6,2,6]  R1477     5.0898820161819458e-01
    z[6,2,6]  R1478     4.6658405661582947e-01
    z[6,2,6]  R1479     1.8439665436744690e-01
    z[6,2,6]  R1480     1.5722465515136719e-01
    z[6,2,6]  R1481     -3.8445958495140076e-01
    z[6,2,6]  R1482     -0.14777772128582
    z[6,2,6]  R1483     1.4122481644153595e-01
    z[6,2,6]  R1484     2.7494275569915771e-01
    z[6,2,6]  R1485     -1.5206019580364227e-01
    z[6,2,6]  R1486     -2.1245667338371277e-01
    z[6,2,6]  R1487     -6.7172899842262268e-02
    z[6,2,6]  R1488     3.5336604714393616e-01
    z[6,2,6]  R1489     1.5318599343299866e-01
    z[6,2,6]  R1490     -1.1770993471145630e-01
    z[6,2,6]  R1491     5.9793557971715927e-02
    z[6,2,6]  R1492     1.7707526683807373e-01
    z[6,2,6]  R1493     2.1222686767578125e-01
    z[6,2,6]  R1494     1.1529105901718140e-01
    z[6,2,6]  R1495     3.6482852697372437e-01
    z[6,2,6]  R1496     0.533686101436615
    z[6,2,6]  R1497     1.2279906868934631e-01
    z[6,2,6]  R1498     1.5007475018501282e-01
    z[6,2,6]  R1499     -1.1907586455345154e-01
    z[6,2,6]  R1500     -5.7666312903165817e-02
    z[6,2,6]  R1501     1.2325332313776016e-01
    z[6,2,6]  R1502     7.8757822513580322e-02
    z[6,2,6]  R1503     5.3811889141798019e-02
    z[6,2,6]  R1504     -2.1906213462352753e-01
    z[6,2,6]  R1505     5.9291366487741470e-02
    z[6,2,6]  R1506     2.1339060366153717e-01
    z[6,2,6]  R1507     -1.5584947168827057e-01
    z[6,2,6]  R1508     -2.2106464207172394e-01
    z[6,2,6]  R1509     -3.6798080801963806e-01
    z[6,2,6]  R1510     -3.0925212427973747e-02
    z[6,2,6]  R1511     -3.9553830027580261e-01
    z[6,2,6]  R1512     -9.0814061462879181e-02
    z[6,2,6]  R1513     -3.2346379756927490e-01
    z[6,2,6]  R1514     2.4477085098624229e-02
    z[6,2,6]  R1515     3.0615216493606567e-01
    z[6,2,6]  R1516     -2.4730274081230164e-01
    z[6,2,6]  R1517     1.1387012898921967e-01
    z[6,2,6]  R1518     2.1660865843296051e-01
    z[6,2,6]  R1519     3.4254112839698792e-01
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1520     -1
    z[3,6,0]  R1521     1
    z[3,6,0]  R1534     -4.3774202822532970e-06
    z[3,6,0]  R1535     -5.0196421146392822e-01
    z[3,6,0]  R1536     9.2960394918918610e-02
    z[3,6,0]  R1537     -5.4913395643234253e-01
    z[3,6,0]  R1538     -4.6438139677047729e-01
    z[3,6,0]  R1539     -3.6235442757606506e-01
    z[3,6,0]  R1540     1.7734211683273315e-01
    z[3,6,0]  R1541     1.1243292689323425e-01
    z[3,6,0]  R1542     -5.2351492643356323e-01
    z[3,6,0]  R1543     3.2991003245115280e-03
    z[3,6,0]  R1544     3.1800916790962219e-01
    z[3,6,0]  R1545     3.3361810445785522e-01
    z[3,6,0]  R1546     3.0185526609420776e-01
    z[3,6,0]  R1547     3.6144572496414185e-01
    z[3,6,0]  R1548     1.7125104367733002e-01
    z[3,6,0]  R1549     -8.7384122610092163e-01
    z[3,6,0]  R1550     -8.8748365640640259e-01
    z[3,6,0]  R1551     -9.4941294193267822e-01
    z[3,6,0]  R1552     -8.5786253213882446e-01
    z[3,6,0]  R1553     -9.1623759269714355e-01
    z[3,6,0]  R1554     -7.2450643777847290e-01
    z[3,6,0]  R1555     -9.3621307611465454e-01
    z[3,6,0]  R1556     -0.96856290102005
    z[3,6,0]  R1557     -8.3268773555755615e-01
    z[3,6,0]  R1558     -8.0606764554977417e-01
    z[3,6,0]  R1559     2.0103774964809418e-01
    z[3,6,0]  R1560     2.1778398752212524e-01
    z[3,6,0]  R1561     1.9404245913028717e-01
    z[3,6,0]  R1562     -0.0822681114077568
    z[3,6,0]  R1563     -2.5601822417229414e-03
    z[3,6,0]  R1564     2.5686609745025635e-01
    z[3,6,0]  R1565     2.3033238947391510e-01
    z[3,6,0]  R1566     3.1332874298095703e-01
    z[3,6,0]  R1567     -1.5054904855787754e-02
    z[3,6,0]  R1568     1.5797884762287140e-01
    z[3,6,0]  R1569     8.2420194149017334e-01
    z[3,6,0]  R1570     4.1432134807109833e-02
    z[3,6,0]  R1571     0.51854008436203
    z[3,6,0]  R1572     7.2541677951812744e-01
    z[3,6,0]  R1573     5.0932067632675171e-01
    z[3,6,0]  R1574     5.2500754594802856e-01
    z[3,6,0]  R1575     3.7646532058715820e-01
    z[3,6,0]  R1576     7.7187612652778625e-02
    z[3,6,0]  R1577     5.5519080162048340e-01
    z[3,6,0]  R1578     1.7107808589935303e-01
    z[3,6,0]  R1579     5.8747440576553345e-01
    z[3,6,0]  R1580     0.787808895111084
    z[3,6,0]  R1581     -1.2902888655662537e-01
    z[3,6,0]  R1582     7.3995554447174072e-01
    z[3,6,0]  R1583     1.4056351780891418e-01
    z[3,6,0]  R1584     6.9226735830307007e-01
    z[3,6,0]  R1585     2.5577588006854057e-02
    z[3,6,0]  R1586     8.1297689676284790e-01
    z[3,6,0]  R1587     5.6801873445510864e-01
    z[3,6,0]  R1588     -2.2160109877586365e-01
    z[3,6,0]  R1589     -1.0260418057441711e-03
    z[3,6,0]  R1590     3.2716092467308044e-01
    z[3,6,0]  R1591     4.2324984073638916e-01
    z[3,6,0]  R1592     4.8220828175544739e-02
    z[3,6,0]  R1593     0.618370532989502
    z[3,6,0]  R1594     5.8190727233886719e-01
    z[3,6,0]  R1595     3.2456271350383759e-02
    z[3,6,0]  R1596     -2.7239865064620972e-01
    z[3,6,0]  R1597     -3.8483291864395142e-01
    z[3,6,0]  R1598     7.6029294729232788e-01
    z[3,6,0]  R1599     -7.7624571323394775e-01
    z[3,6,0]  R1600     7.8828144073486328e-01
    z[3,6,0]  R1601     6.0670781135559082e-01
    z[3,6,0]  R1602     1.2974782288074493e-01
    z[3,6,0]  R1603     4.8424193263053894e-01
    z[3,6,0]  R1604     5.4049581289291382e-01
    z[3,6,0]  R1605     5.2734637260437012e-01
    z[3,6,0]  R1606     5.1648199558258057e-01
    z[3,6,0]  R1607     -3.5389885306358337e-01
    z[3,6,0]  R1608     0.0541507862508297
    z[3,6,0]  R1609     4.1410472989082336e-01
    z[3,6,0]  R1610     1.3840852305293083e-02
    z[3,6,0]  R1611     8.0886858701705933e-01
    z[3,6,0]  R1612     -4.1802600026130676e-01
    z[3,6,0]  R1613     -4.2783138155937195e-01
    z[3,6,0]  R1614     4.6446800231933594e-01
    z[3,6,0]  R1615     7.1531379222869873e-01
    z[3,6,0]  R1616     5.2551430463790894e-01
    z[3,6,0]  R1617     -3.5186198353767395e-01
    z[3,6,0]  R1618     7.0942497253417969e-01
    z[3,6,0]  R1619     8.9145672321319580e-01
    z[3,6,0]  R1620     4.3067368865013123e-01
    z[3,6,0]  R1621     -2.3954921960830688e-01
    z[3,6,0]  R1622     -5.8236384391784668e-01
    z[3,6,0]  R1623     6.2779515981674194e-01
    z[3,6,0]  R1624     5.2663028240203857e-01
    z[3,6,0]  R1625     4.8508965969085693e-01
    z[3,6,0]  R1626     8.4526282548904419e-01
    z[3,6,0]  R1627     -4.7784465551376343e-01
    z[3,6,0]  R1628     1.4369764365255833e-02
    z[3,6,0]  R1629     -7.4734479188919067e-01
    z[3,6,0]  R1630     6.1633431911468506e-01
    z[3,6,0]  R1631     0.401021271944046
    z[3,6,0]  R1632     4.8296386003494263e-01
    z[3,6,0]  R1633     0.680448055267334
    z[3,6,0]  R1634     -3.7621328234672546e-01
    z[3,6,0]  R1635     1.2038894742727280e-01
    z[3,6,0]  R1636     -1.7895002383738756e-04
    z[3,6,0]  R1637     -8.2989625632762909e-02
    z[3,6,0]  R1638     -2.8991684317588806e-02
    z[3,6,0]  R1639     -0.743486762046814
    z[3,6,0]  R1640     7.0977705717086792e-01
    z[3,6,0]  R1641     5.7753592729568481e-01
    z[3,6,0]  R1642     4.3028134107589722e-01
    z[3,6,0]  R1643     1.7088226974010468e-01
    z[3,6,0]  R1644     6.7804497666656971e-03
    z[3,6,0]  R1645     -6.1569139361381531e-02
    z[3,6,0]  R1646     3.5309992730617523e-02
    z[3,6,0]  R1647     -1.1695101112127304e-01
    z[3,6,0]  R1648     -4.5996751636266708e-02
    z[3,6,0]  R1649     7.2832182049751282e-03
    z[3,6,0]  R1650     6.1436778306961060e-01
    z[3,6,0]  R1651     5.5816221237182617e-01
    z[3,6,0]  R1652     -4.5648229122161865e-01
    z[3,6,0]  R1653     -3.2614029943943024e-02
    z[3,6,0]  R1654     -2.6928958296775818e-01
    z[3,6,0]  R1655     -1.3647805154323578e-01
    z[3,6,0]  R1656     2.3611165583133698e-02
    z[3,6,0]  R1657     -6.7060112953186035e-02
    z[3,6,0]  R1658     -0.0773346871137619
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1522     -1
    z[3,6,1]  R1523     1
    z[3,6,1]  R1534     1.1947839707136154e-01
    z[3,6,1]  R1535     -0.65839684009552
    z[3,6,1]  R1536     -0.691955029964447
    z[3,6,1]  R1537     -5.5208396911621094e-01
    z[3,6,1]  R1538     -0.626633882522583
    z[3,6,1]  R1539     -4.1933557391166687e-01
    z[3,6,1]  R1540     0.064608134329319
    z[3,6,1]  R1541     -3.9330857992172241e-01
    z[3,6,1]  R1542     -0.666795015335083
    z[3,6,1]  R1543     -4.9973803758621216e-01
    z[3,6,1]  R1544     0.822810173034668
    z[3,6,1]  R1545     6.9742277264595032e-02
    z[3,6,1]  R1546     4.6270421147346497e-01
    z[3,6,1]  R1547     -0.0831177830696106
    z[3,6,1]  R1548     -5.0423705577850342e-01
    z[3,6,1]  R1549     -3.8983193039894104e-01
    z[3,6,1]  R1550     -3.6499857902526855e-01
    z[3,6,1]  R1551     -2.1544776856899261e-02
    z[3,6,1]  R1552     -6.8940952420234680e-02
    z[3,6,1]  R1553     -1.2151963263750076e-01
    z[3,6,1]  R1554     -5.3895201534032822e-02
    z[3,6,1]  R1555     3.3995623234659433e-03
    z[3,6,1]  R1556     -6.3452741596847773e-04
    z[3,6,1]  R1557     2.7241089940071106e-01
    z[3,6,1]  R1558     -2.8118479251861572e-01
    z[3,6,1]  R1559     -5.0241601467132568e-01
    z[3,6,1]  R1560     -1.9956082105636597e-01
    z[3,6,1]  R1561     -5.9879440069198608e-01
    z[3,6,1]  R1562     -7.0977377891540527e-01
    z[3,6,1]  R1563     -4.8572760820388794e-01
    z[3,6,1]  R1564     -5.2118331193923950e-01
    z[3,6,1]  R1565     -6.8679213523864746e-02
    z[3,6,1]  R1566     -5.8934754133224487e-01
    z[3,6,1]  R1567     -4.0870368480682373e-01
    z[3,6,1]  R1568     -5.2850800752639771e-01
    z[3,6,1]  R1569     -3.1171565875411034e-02
    z[3,6,1]  R1570     -9.5037811994552612e-01
    z[3,6,1]  R1571     3.0611717700958252e-01
    z[3,6,1]  R1572     1.5424132347106934e-01
    z[3,6,1]  R1573     -9.2823922634124756e-02
    z[3,6,1]  R1574     3.5708022117614746e-01
    z[3,6,1]  R1575     -5.2102571725845337e-01
    z[3,6,1]  R1576     6.6686397790908813e-01
    z[3,6,1]  R1577     -1.4312581717967987e-01
    z[3,6,1]  R1578     6.0229659080505371e-01
    z[3,6,1]  R1579     -3.4938564896583557e-01
    z[3,6,1]  R1580     1.5225054323673248e-01
    z[3,6,1]  R1581     -7.8362977504730225e-01
    z[3,6,1]  R1582     0.045985147356987
    z[3,6,1]  R1583     -8.9270532131195068e-01
    z[3,6,1]  R1584     1.0074172914028168e-01
    z[3,6,1]  R1585     -6.3061875104904175e-01
    z[3,6,1]  R1586     -3.0362397432327271e-01
    z[3,6,1]  R1587     1.2596595287322998e-01
    z[3,6,1]  R1588     -5.5027091503143311e-01
    z[3,6,1]  R1589     -7.6516550779342651e-01
    z[3,6,1]  R1590     -8.8505178689956665e-01
    z[3,6,1]  R1591     -5.2559173107147217e-01
    z[3,6,1]  R1592     -0.89644455909729
    z[3,6,1]  R1593     2.1496775746345520e-01
    z[3,6,1]  R1594     -2.3313325643539429e-01
    z[3,6,1]  R1595     -7.7686858177185059e-01
    z[3,6,1]  R1596     -5.5272829532623291e-01
    z[3,6,1]  R1597     -1.3243253529071808e-01
    z[3,6,1]  R1598     -3.7105970084667206e-02
    z[3,6,1]  R1599     -2.6720070838928223e-01
    z[3,6,1]  R1600     -3.0520877242088318e-01
    z[3,6,1]  R1601     -4.4281157851219177e-01
    z[3,6,1]  R1602     -4.7522720694541931e-01
    z[3,6,1]  R1603     -1.7094098031520844e-01
    z[3,6,1]  R1604     -1.9637905061244965e-01
    z[3,6,1]  R1605     -4.5808512717485428e-02
    z[3,6,1]  R1606     2.2161212563514709e-01
    z[3,6,1]  R1607     7.5454115867614746e-01
    z[3,6,1]  R1608     8.6229842901229858e-01
    z[3,6,1]  R1609     -2.6137259602546692e-01
    z[3,6,1]  R1610     -6.7997843027114868e-01
    z[3,6,1]  R1611     1.7777520418167114e-01
    z[3,6,1]  R1612     -6.4122051000595093e-01
    z[3,6,1]  R1613     -0.055446557700634
    z[3,6,1]  R1614     -2.7222353219985962e-01
    z[3,6,1]  R1615     -2.6235067844390869e-01
    z[3,6,1]  R1616     -1.5870186686515808e-01
    z[3,6,1]  R1617     1.6907547414302826e-01
    z[3,6,1]  R1618     2.0996022969484329e-02
    z[3,6,1]  R1619     -1.4200265705585480e-01
    z[3,6,1]  R1620     -3.0012896656990051e-01
    z[3,6,1]  R1621     -7.6789957284927368e-01
    z[3,6,1]  R1622     -5.6674383580684662e-02
    z[3,6,1]  R1623     -1.9198960065841675e-01
    z[3,6,1]  R1624     -1.4512595720589161e-02
    z[3,6,1]  R1625     3.6846555769443512e-02
    z[3,6,1]  R1626     2.8690424561500549e-01
    z[3,6,1]  R1627     4.8175626993179321e-01
    z[3,6,1]  R1628     7.9874765872955322e-01
    z[3,6,1]  R1629     -1.4394551515579224e-02
    z[3,6,1]  R1630     -3.0781856179237366e-01
    z[3,6,1]  R1631     -2.7524015307426453e-01
    z[3,6,1]  R1632     -2.0112356543540955e-01
    z[3,6,1]  R1633     1.0570946335792542e-01
    z[3,6,1]  R1634     -1.8369263410568237e-01
    z[3,6,1]  R1635     5.2311939001083374e-01
    z[3,6,1]  R1636     7.2564291954040527e-01
    z[3,6,1]  R1637     7.3291534185409546e-01
    z[3,6,1]  R1638     8.1506699323654175e-01
    z[3,6,1]  R1639     9.3010291457176208e-02
    z[3,6,1]  R1640     -1.8123178184032440e-01
    z[3,6,1]  R1641     -0.145138680934906
    z[3,6,1]  R1642     -2.4333159625530243e-01
    z[3,6,1]  R1643     -4.8579236865043640e-01
    z[3,6,1]  R1644     6.5936404466629028e-01
    z[3,6,1]  R1645     6.2111669778823853e-01
    z[3,6,1]  R1646     0.584827721118927
    z[3,6,1]  R1647     8.8545787334442139e-01
    z[3,6,1]  R1648     8.1723350286483765e-01
    z[3,6,1]  R1649     -4.9319869279861450e-01
    z[3,6,1]  R1650     -1.6294093430042267e-01
    z[3,6,1]  R1651     -5.0169759988784790e-01
    z[3,6,1]  R1652     -3.1170082092285156e-01
    z[3,6,1]  R1653     9.1450905799865723e-01
    z[3,6,1]  R1654     8.0454438924789429e-01
    z[3,6,1]  R1655     0.808972954750061
    z[3,6,1]  R1656     6.4437693357467651e-01
    z[3,6,1]  R1657     6.1878538131713867e-01
    z[3,6,1]  R1658     0.753345787525177
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1524     -1
    z[3,6,2]  R1525     1
    z[3,6,2]  R1534     -5.0464099645614624e-01
    z[3,6,2]  R1535     -4.3756082653999329e-01
    z[3,6,2]  R1536     -4.2218956351280212e-01
    z[3,6,2]  R1537     -3.9870855212211609e-01
    z[3,6,2]  R1538     -2.4444781243801117e-01
    z[3,6,2]  R1539     -7.1697455644607544e-01
    z[3,6,2]  R1540     -4.2742338031530380e-02
    z[3,6,2]  R1541     2.9280850291252136e-01
    z[3,6,2]  R1542     -3.2561093568801880e-01
    z[3,6,2]  R1543     7.9545283317565918e-01
    z[3,6,2]  R1544     3.1671860814094543e-01
    z[3,6,2]  R1545     1.6957861185073853e-01
    z[3,6,2]  R1546     3.2461118698120117e-01
    z[3,6,2]  R1547     2.1251462399959564e-01
    z[3,6,2]  R1548     4.9290871247649193e-03
    z[3,6,2]  R1549     -1.7520034313201904e-01
    z[3,6,2]  R1550     -1.1685901880264282e-01
    z[3,6,2]  R1551     -1.6333484649658203e-01
    z[3,6,2]  R1552     -2.6785880327224731e-01
    z[3,6,2]  R1553     -1.8257641792297363e-01
    z[3,6,2]  R1554     -5.3789663314819336e-01
    z[3,6,2]  R1555     -1.7760933935642242e-01
    z[3,6,2]  R1556     -1.7945638298988342e-01
    z[3,6,2]  R1557     -3.8195076584815979e-01
    z[3,6,2]  R1558     -0.0339924618601799
    z[3,6,2]  R1559     2.8260305523872375e-01
    z[3,6,2]  R1560     7.1075963973999023e-01
    z[3,6,2]  R1561     6.8378818035125732e-01
    z[3,6,2]  R1562     5.4878199100494385e-01
    z[3,6,2]  R1563     4.9439480900764465e-01
    z[3,6,2]  R1564     6.2343740463256836e-01
    z[3,6,2]  R1565     5.0190275907516479e-01
    z[3,6,2]  R1566     4.8393711447715759e-01
    z[3,6,2]  R1567     3.8058194518089294e-01
    z[3,6,2]  R1568     4.3565174937248230e-01
    z[3,6,2]  R1569     3.2944139838218689e-01
    z[3,6,2]  R1570     -1.5970049798488617e-01
    z[3,6,2]  R1571     6.8351435661315918e-01
    z[3,6,2]  R1572     2.4656991660594940e-01
    z[3,6,2]  R1573     1.1712289601564407e-01
    z[3,6,2]  R1574     6.8361848592758179e-01
    z[3,6,2]  R1575     -1.3215051591396332e-01
    z[3,6,2]  R1576     -6.0098522901535034e-01
    z[3,6,2]  R1577     4.9145266413688660e-01
    z[3,6,2]  R1578     -0.706415057182312
    z[3,6,2]  R1579     3.1549575924873352e-01
    z[3,6,2]  R1580     3.8917210698127747e-01
    z[3,6,2]  R1581     4.1174092888832092e-01
    z[3,6,2]  R1582     3.1450986862182617e-01
    z[3,6,2]  R1583     4.2288318276405334e-02
    z[3,6,2]  R1584     6.3316076993942261e-01
    z[3,6,2]  R1585     2.1973705291748047e-01
    z[3,6,2]  R1586     -5.7728279381990433e-02
    z[3,6,2]  R1587     7.7076196670532227e-01
    z[3,6,2]  R1588     2.6455268263816833e-01
    z[3,6,2]  R1589     4.2389449477195740e-01
    z[3,6,2]  R1590     2.2439652681350708e-01
    z[3,6,2]  R1591     6.4922392368316650e-01
    z[3,6,2]  R1592     1.6333243250846863e-01
    z[3,6,2]  R1593     5.4032075405120850e-01
    z[3,6,2]  R1594     -1.8255543708801270e-01
    z[3,6,2]  R1595     3.0196553096175194e-02
    z[3,6,2]  R1596     0.215520977973938
    z[3,6,2]  R1597     -6.1001914739608765e-01
    z[3,6,2]  R1598     8.8725559413433075e-02
    z[3,6,2]  R1599     -2.3672574758529663e-01
    z[3,6,2]  R1600     2.5989213585853577e-01
    z[3,6,2]  R1601     1.6411387920379639e-01
    z[3,6,2]  R1602     2.8355222940444946e-01
    z[3,6,2]  R1603     9.0234234929084778e-02
    z[3,6,2]  R1604     -1.9573102891445160e-01
    z[3,6,2]  R1605     4.8574164509773254e-01
    z[3,6,2]  R1606     6.5591341257095337e-01
    z[3,6,2]  R1607     -3.4801873564720154e-01
    z[3,6,2]  R1608     -4.6952879428863525e-01
    z[3,6,2]  R1609     6.7564022541046143e-01
    z[3,6,2]  R1610     1.2817643582820892e-03
    z[3,6,2]  R1611     4.2216774821281433e-01
    z[3,6,2]  R1612     1.5791609883308411e-01
    z[3,6,2]  R1613     -7.6735556125640869e-01
    z[3,6,2]  R1614     2.5689122080802917e-01
    z[3,6,2]  R1615     0.395819753408432
    z[3,6,2]  R1616     2.0394693315029144e-01
    z[3,6,2]  R1617     -6.5956008434295654e-01
    z[3,6,2]  R1618     0.0963897705078125
    z[3,6,2]  R1619     2.1616187691688538e-01
    z[3,6,2]  R1620     3.8360023498535156e-01
    z[3,6,2]  R1621     0.522737979888916
    z[3,6,2]  R1622     -5.8665275573730469e-01
    z[3,6,2]  R1623     0.257693350315094
    z[3,6,2]  R1624     5.1851803064346313e-01
    z[3,6,2]  R1625     3.2036128640174866e-01
    z[3,6,2]  R1626     3.1420376896858215e-01
    z[3,6,2]  R1627     -4.5502316951751709e-01
    z[3,6,2]  R1628     -4.5573037862777710e-01
    z[3,6,2]  R1629     -6.1263483762741089e-01
    z[3,6,2]  R1630     3.7518495321273804e-01
    z[3,6,2]  R1631     4.6717628836631775e-01
    z[3,6,2]  R1632     2.9142412543296814e-01
    z[3,6,2]  R1633     3.8473892211914062e-01
    z[3,6,2]  R1634     4.9168238043785095e-01
    z[3,6,2]  R1635     -8.2693254947662354e-01
    z[3,6,2]  R1636     -3.9073020219802856e-01
    z[3,6,2]  R1637     -0.315792053937912
    z[3,6,2]  R1638     -1.5693803131580353e-01
    z[3,6,2]  R1639     -0.431908518075943
    z[3,6,2]  R1640     4.6711099147796631e-01
    z[3,6,2]  R1641     5.1746422052383423e-01
    z[3,6,2]  R1642     1.6701912879943848e-01
    z[3,6,2]  R1643     2.2287330031394958e-01
    z[3,6,2]  R1644     -6.4267307519912720e-01
    z[3,6,2]  R1645     -5.4743212461471558e-01
    z[3,6,2]  R1646     -5.9905093908309937e-01
    z[3,6,2]  R1647     3.9783951640129089e-01
    z[3,6,2]  R1648     5.3042483329772949e-01
    z[3,6,2]  R1649     6.0604417324066162e-01
    z[3,6,2]  R1650     1.0132411122322083e-01
    z[3,6,2]  R1651     2.7886566519737244e-01
    z[3,6,2]  R1652     -4.7770851850509644e-01
    z[3,6,2]  R1653     -3.4008646011352539e-01
    z[3,6,2]  R1654     3.9407119154930115e-01
    z[3,6,2]  R1655     4.1896224021911621e-01
    z[3,6,2]  R1656     5.4252862930297852e-01
    z[3,6,2]  R1657     5.3949481248855591e-01
    z[3,6,2]  R1658     3.8305473327636719e-01
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1526     -1
    z[3,6,3]  R1527     1
    z[3,6,3]  R1534     5.6319665908813477e-01
    z[3,6,3]  R1535     -1.0369183868169785e-01
    z[3,6,3]  R1536     -5.2761048078536987e-01
    z[3,6,3]  R1537     -4.3900772929191589e-02
    z[3,6,3]  R1538     1.8475079536437988e-01
    z[3,6,3]  R1539     3.5118627548217773e-01
    z[3,6,3]  R1540     3.1219440698623657e-01
    z[3,6,3]  R1541     -2.4333126842975616e-01
    z[3,6,3]  R1542     7.5939163565635681e-02
    z[3,6,3]  R1543     -1.5298357605934143e-01
    z[3,6,3]  R1544     7.3067627847194672e-02
    z[3,6,3]  R1545     5.9623247385025024e-01
    z[3,6,3]  R1546     -4.7412705421447754e-01
    z[3,6,3]  R1547     -0.594360888004303
    z[3,6,3]  R1548     -2.1659563481807709e-01
    z[3,6,3]  R1549     1.9722686707973480e-01
    z[3,6,3]  R1550     -1.7805849015712738e-01
    z[3,6,3]  R1551     -1.3938149809837341e-01
    z[3,6,3]  R1552     3.1448623538017273e-01
    z[3,6,3]  R1553     0.00422905758023262
    z[3,6,3]  R1554     3.0133891850709915e-02
    z[3,6,3]  R1555     -5.1916502416133881e-02
    z[3,6,3]  R1556     -4.8395209014415741e-02
    z[3,6,3]  R1557     -7.3296025395393372e-02
    z[3,6,3]  R1558     2.6381894946098328e-01
    z[3,6,3]  R1559     -3.9144456386566162e-01
    z[3,6,3]  R1560     2.1493844687938690e-01
    z[3,6,3]  R1561     -3.2905817031860352e-02
    z[3,6,3]  R1562     1.3282246887683868e-01
    z[3,6,3]  R1563     -4.2959639430046082e-01
    z[3,6,3]  R1564     -2.6216539740562439e-01
    z[3,6,3]  R1565     -1.5089030377566814e-02
    z[3,6,3]  R1566     2.9635429382324219e-01
    z[3,6,3]  R1567     -3.1604444980621338e-01
    z[3,6,3]  R1568     2.2651587426662445e-01
    z[3,6,3]  R1569     1.9076961278915405e-01
    z[3,6,3]  R1570     -1.6248348355293274e-01
    z[3,6,3]  R1571     -3.2762053608894348e-01
    z[3,6,3]  R1572     -9.8815739154815674e-02
    z[3,6,3]  R1573     4.4113656878471375e-01
    z[3,6,3]  R1574     1.8524500727653503e-01
    z[3,6,3]  R1575     2.6893270015716553e-01
    z[3,6,3]  R1576     -8.2504920661449432e-02
    z[3,6,3]  R1577     -3.0172142386436462e-01
    z[3,6,3]  R1578     2.6870843768119812e-01
    z[3,6,3]  R1579     2.9335431754589081e-02
    z[3,6,3]  R1580     1.2446004152297974e-01
    z[3,6,3]  R1581     -0.279773473739624
    z[3,6,3]  R1582     1.1687626689672470e-01
    z[3,6,3]  R1583     1.3141964375972748e-01
    z[3,6,3]  R1584     -3.0197307467460632e-01
    z[3,6,3]  R1585     -0.718078076839447
    z[3,6,3]  R1586     -2.2317622601985931e-01
    z[3,6,3]  R1587     -7.3442630469799042e-02
    z[3,6,3]  R1588     -1.9902646541595459e-01
    z[3,6,3]  R1589     -3.9294418692588806e-01
    z[3,6,3]  R1590     -1.0631754249334335e-01
    z[3,6,3]  R1591     8.6140096187591553e-02
    z[3,6,3]  R1592     -0.0592268705368042
    z[3,6,3]  R1593     1.1346279084682465e-01
    z[3,6,3]  R1594     5.5354988574981689e-01
    z[3,6,3]  R1595     -2.1806603670120239e-01
    z[3,6,3]  R1596     1.3416700065135956e-01
    z[3,6,3]  R1597     -4.5715585350990295e-01
    z[3,6,3]  R1598     -2.9148977249860764e-02
    z[3,6,3]  R1599     -2.1368084847927094e-01
    z[3,6,3]  R1600     -1.3163023628294468e-02
    z[3,6,3]  R1601     5.4514998197555542e-01
    z[3,6,3]  R1602     -1.0321961343288422e-01
    z[3,6,3]  R1603     5.3564912080764771e-01
    z[3,6,3]  R1604     2.9216277599334717e-01
    z[3,6,3]  R1605     3.0592599511146545e-01
    z[3,6,3]  R1606     1.5349418856203556e-02
    z[3,6,3]  R1607     -1.7554216086864471e-01
    z[3,6,3]  R1608     1.0113058984279633e-01
    z[3,6,3]  R1609     4.0966841578483582e-01
    z[3,6,3]  R1610     -3.4179797768592834e-01
    z[3,6,3]  R1611     -2.9593538492918015e-03
    z[3,6,3]  R1612     -1.8164904788136482e-02
    z[3,6,3]  R1613     -3.0162784457206726e-01
    z[3,6,3]  R1614     2.2983743250370026e-01
    z[3,6,3]  R1615     2.0392403006553650e-01
    z[3,6,3]  R1616     3.1509986519813538e-01
    z[3,6,3]  R1617     -4.8180431127548218e-01
    z[3,6,3]  R1618     4.9940237402915955e-01
    z[3,6,3]  R1619     0.303492933511734
    z[3,6,3]  R1620     0.298991322517395
    z[3,6,3]  R1621     -9.7847640514373779e-02
    z[3,6,3]  R1622     -3.3750689029693604e-01
    z[3,6,3]  R1623     3.1253427267074585e-01
    z[3,6,3]  R1624     1.9220243394374847e-01
    z[3,6,3]  R1625     1.3646423816680908e-01
    z[3,6,3]  R1626     -2.2059574723243713e-01
    z[3,6,3]  R1627     1.5589003264904022e-01
    z[3,6,3]  R1628     3.3723658323287964e-01
    z[3,6,3]  R1629     5.4800111800432205e-02
    z[3,6,3]  R1630     1.9486233592033386e-01
    z[3,6,3]  R1631     1.5734905004501343e-01
    z[3,6,3]  R1632     -6.4490497112274170e-02
    z[3,6,3]  R1633     -0.0396580696105957
    z[3,6,3]  R1634     6.9540542364120483e-01
    z[3,6,3]  R1635     7.5495615601539612e-02
    z[3,6,3]  R1636     3.2061886787414551e-01
    z[3,6,3]  R1637     4.6656790375709534e-01
    z[3,6,3]  R1638     0.474361777305603
    z[3,6,3]  R1639     -3.0580973625183105e-01
    z[3,6,3]  R1640     4.5167854428291321e-01
    z[3,6,3]  R1641     -3.4414285421371460e-01
    z[3,6,3]  R1642     2.4899591505527496e-01
    z[3,6,3]  R1643     -7.5129413604736328e-01
    z[3,6,3]  R1644     3.4967169165611267e-01
    z[3,6,3]  R1645     4.1893583536148071e-01
    z[3,6,3]  R1646     -2.6354610919952393e-01
    z[3,6,3]  R1647     1.5516200102865696e-02
    z[3,6,3]  R1648     1.0314907878637314e-01
    z[3,6,3]  R1649     -0.500938892364502
    z[3,6,3]  R1650     1.9754789769649506e-01
    z[3,6,3]  R1651     2.4601487815380096e-01
    z[3,6,3]  R1652     -6.2834209203720093e-01
    z[3,6,3]  R1653     9.7366660833358765e-02
    z[3,6,3]  R1654     2.8921690583229065e-01
    z[3,6,3]  R1655     1.8290439248085022e-01
    z[3,6,3]  R1656     1.8155736848711967e-02
    z[3,6,3]  R1657     -1.2649394571781158e-01
    z[3,6,3]  R1658     -3.0813655257225037e-01
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1528     -1
    z[3,6,4]  R1529     1
    z[3,6,4]  R1534     1.7180059850215912e-01
    z[3,6,4]  R1535     -0.290390282869339
    z[3,6,4]  R1536     -1.2788760662078857e-01
    z[3,6,4]  R1537     3.1648221611976624e-01
    z[3,6,4]  R1538     2.4286733940243721e-02
    z[3,6,4]  R1539     -1.8562752008438110e-01
    z[3,6,4]  R1540     -8.5928475856781006e-01
    z[3,6,4]  R1541     3.1024357676506042e-01
    z[3,6,4]  R1542     -3.6562168598175049e-01
    z[3,6,4]  R1543     -1.3181759975850582e-02
    z[3,6,4]  R1544     2.3730356991291046e-01
    z[3,6,4]  R1545     4.6288302540779114e-01
    z[3,6,4]  R1546     -1.7594926059246063e-01
    z[3,6,4]  R1547     2.8487956523895264e-01
    z[3,6,4]  R1548     5.3741383552551270e-01
    z[3,6,4]  R1549     2.5442723184823990e-02
    z[3,6,4]  R1550     1.5681026875972748e-01
    z[3,6,4]  R1551     9.9835090339183807e-02
    z[3,6,4]  R1552     2.4434188008308411e-01
    z[3,6,4]  R1553     -3.4472875297069550e-02
    z[3,6,4]  R1554     3.6078128218650818e-01
    z[3,6,4]  R1555     2.0710060000419617e-01
    z[3,6,4]  R1556     4.5984137803316116e-02
    z[3,6,4]  R1557     2.6967635750770569e-01
    z[3,6,4]  R1558     3.3857962489128113e-01
    z[3,6,4]  R1559     1.8772387504577637e-01
    z[3,6,4]  R1560     -6.4913578331470490e-02
    z[3,6,4]  R1561     3.2985430955886841e-01
    z[3,6,4]  R1562     3.9232546091079712e-01
    z[3,6,4]  R1563     3.3945900201797485e-01
    z[3,6,4]  R1564     1.2313283234834671e-01
    z[3,6,4]  R1565     -4.2394474148750305e-01
    z[3,6,4]  R1566     3.2723551988601685e-01
    z[3,6,4]  R1567     5.8565360307693481e-01
    z[3,6,4]  R1568     2.8684270381927490e-01
    z[3,6,4]  R1569     -3.7396547198295593e-01
    z[3,6,4]  R1570     -1.7767411470413208e-01
    z[3,6,4]  R1571     2.1423611044883728e-01
    z[3,6,4]  R1572     4.1241145133972168e-01
    z[3,6,4]  R1573     -8.4720002487301826e-03
    z[3,6,4]  R1574     -2.1629419177770615e-02
    z[3,6,4]  R1575     -5.6049692630767822e-01
    z[3,6,4]  R1576     -4.1762074828147888e-01
    z[3,6,4]  R1577     -0.309527724981308
    z[3,6,4]  R1578     -1.8898989260196686e-01
    z[3,6,4]  R1579     -4.7102957963943481e-01
    z[3,6,4]  R1580     1.1562176048755646e-01
    z[3,6,4]  R1581     3.6604840308427811e-02
    z[3,6,4]  R1582     4.4977459311485291e-01
    z[3,6,4]  R1583     3.2556807994842529e-01
    z[3,6,4]  R1584     -3.6292336881160736e-02
    z[3,6,4]  R1585     2.5714278221130371e-02
    z[3,6,4]  R1586     -3.8738265633583069e-01
    z[3,6,4]  R1587     2.2139152884483337e-01
    z[3,6,4]  R1588     -3.5999670624732971e-01
    z[3,6,4]  R1589     -1.6703774034976959e-01
    z[3,6,4]  R1590     6.3023701310157776e-02
    z[3,6,4]  R1591     -3.0715823173522949e-02
    z[3,6,4]  R1592     -3.0421710014343262e-01
    z[3,6,4]  R1593     2.1932624280452728e-01
    z[3,6,4]  R1594     -1.7460497096180916e-02
    z[3,6,4]  R1595     4.3190225958824158e-01
    z[3,6,4]  R1596     0.67954021692276
    z[3,6,4]  R1597     -4.0179529786109924e-01
    z[3,6,4]  R1598     -1.0678673535585403e-01
    z[3,6,4]  R1599     2.9650720953941345e-01
    z[3,6,4]  R1600     -3.4526339173316956e-01
    z[3,6,4]  R1601     -1.7809841036796570e-01
    z[3,6,4]  R1602     6.9740664958953857e-01
    z[3,6,4]  R1603     3.9971670508384705e-01
    z[3,6,4]  R1604     -1.9026480615139008e-01
    z[3,6,4]  R1605     -1.3448676466941833e-01
    z[3,6,4]  R1606     -2.5099346041679382e-01
    z[3,6,4]  R1607     -3.4589907526969910e-01
    z[3,6,4]  R1608     -6.4240492880344391e-02
    z[3,6,4]  R1609     -8.8118426501750946e-02
    z[3,6,4]  R1610     4.5130811631679535e-02
    z[3,6,4]  R1611     -7.5812175869941711e-02
    z[3,6,4]  R1612     4.6922618150711060e-01
    z[3,6,4]  R1613     -2.1081276237964630e-01
    z[3,6,4]  R1614     -5.4514068365097046e-01
    z[3,6,4]  R1615     3.0137148499488831e-01
    z[3,6,4]  R1616     2.5732040405273438e-01
    z[3,6,4]  R1617     -2.0544733107089996e-01
    z[3,6,4]  R1618     4.3823051452636719e-01
    z[3,6,4]  R1619     1.1673387885093689e-01
    z[3,6,4]  R1620     -4.8256742954254150e-01
    z[3,6,4]  R1621     2.4360392987728119e-01
    z[3,6,4]  R1622     -3.2086694240570068e-01
    z[3,6,4]  R1623     4.6117997169494629e-01
    z[3,6,4]  R1624     3.9515700936317444e-01
    z[3,6,4]  R1625     4.5218691229820251e-02
    z[3,6,4]  R1626     -1.8601721525192261e-01
    z[3,6,4]  R1627     -3.0061137676239014e-01
    z[3,6,4]  R1628     1.4628148078918457e-01
    z[3,6,4]  R1629     -4.4163670390844345e-02
    z[3,6,4]  R1630     2.9067862033843994e-01
    z[3,6,4]  R1631     -4.5216238498687744e-01
    z[3,6,4]  R1632     -0.154743030667305
    z[3,6,4]  R1633     -2.7844479680061340e-01
    z[3,6,4]  R1634     -1.9415840506553650e-01
    z[3,6,4]  R1635     1.0383749753236771e-01
    z[3,6,4]  R1636     1.2211102247238159e-01
    z[3,6,4]  R1637     -2.6020416617393494e-01
    z[3,6,4]  R1638     -5.8943405747413635e-02
    z[3,6,4]  R1639     -3.0825346708297729e-01
    z[3,6,4]  R1640     3.0930081382393837e-02
    z[3,6,4]  R1641     -1.2759761512279510e-01
    z[3,6,4]  R1642     -6.0336075723171234e-02
    z[3,6,4]  R1643     1.0239310562610626e-01
    z[3,6,4]  R1644     -8.9971348643302917e-03
    z[3,6,4]  R1645     -2.2755637764930725e-03
    z[3,6,4]  R1646     -2.7343245223164558e-02
    z[3,6,4]  R1647     2.0597030222415924e-01
    z[3,6,4]  R1648     -1.0387220233678818e-01
    z[3,6,4]  R1649     2.8337278962135315e-01
    z[3,6,4]  R1650     1.1322257667779922e-01
    z[3,6,4]  R1651     2.7698168158531189e-01
    z[3,6,4]  R1652     -5.7650644332170486e-02
    z[3,6,4]  R1653     -7.6792903244495392e-02
    z[3,6,4]  R1654     -6.1464175581932068e-02
    z[3,6,4]  R1655     -2.8007525205612183e-01
    z[3,6,4]  R1656     -1.7160907387733459e-01
    z[3,6,4]  R1657     -1.3729830272495747e-02
    z[3,6,4]  R1658     -1.3171419501304626e-01
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1530     -1
    z[3,6,5]  R1531     1
    z[3,6,5]  R1534     -6.1394846439361572e-01
    z[3,6,5]  R1535     2.0823361352086067e-02
    z[3,6,5]  R1536     -1.9786822795867920e-01
    z[3,6,5]  R1537     -3.6314314603805542e-01
    z[3,6,5]  R1538     -3.8083171844482422e-01
    z[3,6,5]  R1539     1.3971579074859619e-01
    z[3,6,5]  R1540     2.1009135246276855e-01
    z[3,6,5]  R1541     -4.3233373761177063e-01
    z[3,6,5]  R1542     -1.3284134864807129e-01
    z[3,6,5]  R1543     2.7037004474550486e-03
    z[3,6,5]  R1544     0.0669000968337059
    z[3,6,5]  R1545     5.3333175182342529e-01
    z[3,6,5]  R1546     -5.1613062620162964e-01
    z[3,6,5]  R1547     3.9667895436286926e-01
    z[3,6,5]  R1548     4.8298445343971252e-01
    z[3,6,5]  R1549     1.8363554030656815e-02
    z[3,6,5]  R1550     -9.5805518329143524e-02
    z[3,6,5]  R1551     1.2756167352199554e-01
    z[3,6,5]  R1552     -5.5215455591678619e-02
    z[3,6,5]  R1553     1.4253821969032288e-01
    z[3,6,5]  R1554     1.5330988168716431e-01
    z[3,6,5]  R1555     -1.7740002274513245e-01
    z[3,6,5]  R1556     6.8646006286144257e-02
    z[3,6,5]  R1557     9.1301478445529938e-02
    z[3,6,5]  R1558     1.0748646408319473e-01
    z[3,6,5]  R1559     -6.3528245687484741e-01
    z[3,6,5]  R1560     -5.5146205425262451e-01
    z[3,6,5]  R1561     -1.5791727602481842e-01
    z[3,6,5]  R1562     1.1527353525161743e-01
    z[3,6,5]  R1563     -1.3519582152366638e-01
    z[3,6,5]  R1564     -4.2881774902343750e-01
    z[3,6,5]  R1565     -6.6672730445861816e-01
    z[3,6,5]  R1566     -3.4675487875938416e-01
    z[3,6,5]  R1567     -3.6504715681076050e-01
    z[3,6,5]  R1568     -6.0960131883621216e-01
    z[3,6,5]  R1569     -1.7386928200721741e-01
    z[3,6,5]  R1570     6.6571027040481567e-02
    z[3,6,5]  R1571     8.7013505399227142e-02
    z[3,6,5]  R1572     2.4824562668800354e-01
    z[3,6,5]  R1573     3.5148376226425171e-01
    z[3,6,5]  R1574     2.2151772677898407e-01
    z[3,6,5]  R1575     1.1689832806587219e-01
    z[3,6,5]  R1576     2.1122368052601814e-02
    z[3,6,5]  R1577     4.5777830481529236e-01
    z[3,6,5]  R1578     1.2328056618571281e-02
    z[3,6,5]  R1579     -0.448505699634552
    z[3,6,5]  R1580     -3.6816036701202393e-01
    z[3,6,5]  R1581     2.8279694914817810e-01
    z[3,6,5]  R1582     -5.4161384701728821e-02
    z[3,6,5]  R1583     1.2324440479278564e-01
    z[3,6,5]  R1584     -1.0633645206689835e-01
    z[3,6,5]  R1585     2.5598341599106789e-02
    z[3,6,5]  R1586     -2.3073397576808929e-02
    z[3,6,5]  R1587     -1.0603081434965134e-01
    z[3,6,5]  R1588     -6.0287380218505859e-01
    z[3,6,5]  R1589     -2.1796286106109619e-01
    z[3,6,5]  R1590     -1.5515540540218353e-01
    z[3,6,5]  R1591     -3.2942584156990051e-01
    z[3,6,5]  R1592     -2.4291633069515228e-01
    z[3,6,5]  R1593     -0.422921746969223
    z[3,6,5]  R1594     -4.3859258294105530e-01
    z[3,6,5]  R1595     -1.4036697149276733e-01
    z[3,6,5]  R1596     -1.4414627850055695e-01
    z[3,6,5]  R1597     -2.9180753231048584e-01
    z[3,6,5]  R1598     0.622606098651886
    z[3,6,5]  R1599     2.4356535077095032e-01
    z[3,6,5]  R1600     -3.0759337544441223e-01
    z[3,6,5]  R1601     -2.7960723638534546e-01
    z[3,6,5]  R1602     -0.421384334564209
    z[3,6,5]  R1603     -5.0109249353408813e-01
    z[3,6,5]  R1604     -6.7544782161712646e-01
    z[3,6,5]  R1605     5.5559748411178589e-01
    z[3,6,5]  R1606     3.2968875765800476e-01
    z[3,6,5]  R1607     4.8926264047622681e-02
    z[3,6,5]  R1608     1.0916931927204132e-01
    z[3,6,5]  R1609     -2.5254514813423157e-01
    z[3,6,5]  R1610     -6.4476072788238525e-01
    z[3,6,5]  R1611     3.6030894517898560e-01
    z[3,6,5]  R1612     -4.0189573168754578e-01
    z[3,6,5]  R1613     -2.4131463468074799e-01
    z[3,6,5]  R1614     -2.2471027076244354e-01
    z[3,6,5]  R1615     0.314242959022522
    z[3,6,5]  R1616     -3.2006821036338806e-01
    z[3,6,5]  R1617     -3.0427744984626770e-01
    z[3,6,5]  R1618     1.2288712710142136e-01
    z[3,6,5]  R1619     9.0067885816097260e-02
    z[3,6,5]  R1620     -4.1855999827384949e-01
    z[3,6,5]  R1621     -5.1251932978630066e-02
    z[3,6,5]  R1622     -3.1081253290176392e-01
    z[3,6,5]  R1623     -4.3841204047203064e-01
    z[3,6,5]  R1624     -4.6696880459785461e-01
    z[3,6,5]  R1625     -7.8776758909225464e-01
    z[3,6,5]  R1626     -0.0409141406416893
    z[3,6,5]  R1627     -4.1150298714637756e-01
    z[3,6,5]  R1628     -4.4737223535776138e-02
    z[3,6,5]  R1629     -2.4522005021572113e-01
    z[3,6,5]  R1630     -4.9179011583328247e-01
    z[3,6,5]  R1631     -4.9940440058708191e-01
    z[3,6,5]  R1632     -7.4444037675857544e-01
    z[3,6,5]  R1633     1.4940799772739410e-01
    z[3,6,5]  R1634     2.4619838595390320e-01
    z[3,6,5]  R1635     -1.0064287483692169e-01
    z[3,6,5]  R1636     4.2561632394790649e-01
    z[3,6,5]  R1637     9.8149076104164124e-02
    z[3,6,5]  R1638     1.9988100230693817e-01
    z[3,6,5]  R1639     -2.0188757777214050e-01
    z[3,6,5]  R1640     1.4005610346794128e-01
    z[3,6,5]  R1641     -0.479707807302475
    z[3,6,5]  R1642     -8.0626225471496582e-01
    z[3,6,5]  R1643     -1.2126793712377548e-01
    z[3,6,5]  R1644     1.4181299507617950e-01
    z[3,6,5]  R1645     1.1308369040489197e-01
    z[3,6,5]  R1646     4.5485013723373413e-01
    z[3,6,5]  R1647     -2.9244298115372658e-02
    z[3,6,5]  R1648     1.4941900968551636e-01
    z[3,6,5]  R1649     -2.0874448120594025e-01
    z[3,6,5]  R1650     -7.2684699296951294e-01
    z[3,6,5]  R1651     -3.9484921097755432e-01
    z[3,6,5]  R1652     -1.2284660339355469e-01
    z[3,6,5]  R1653     1.7613308131694794e-01
    z[3,6,5]  R1654     -1.5199208259582520e-01
    z[3,6,5]  R1655     -0.0385298952460289
    z[3,6,5]  R1656     -3.2177552580833435e-02
    z[3,6,5]  R1657     -2.9607942700386047e-01
    z[3,6,5]  R1658     -3.6532118916511536e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1532     -1
    z[3,6,6]  R1533     1
    z[3,6,6]  R1534     8.6160756647586823e-02
    z[3,6,6]  R1535     1.6605402529239655e-01
    z[3,6,6]  R1536     -2.0802492275834084e-02
    z[3,6,6]  R1537     -2.6933647692203522e-02
    z[3,6,6]  R1538     3.9008951187133789e-01
    z[3,6,6]  R1539     -3.8659039884805679e-02
    z[3,6,6]  R1540     2.8735810518264771e-01
    z[3,6,6]  R1541     -6.3604766130447388e-01
    z[3,6,6]  R1542     -1.3491220772266388e-01
    z[3,6,6]  R1543     -3.0646494030952454e-01
    z[3,6,6]  R1544     -2.3540496826171875e-01
    z[3,6,6]  R1545     2.9689380899071693e-02
    z[3,6,6]  R1546     2.5936502218246460e-01
    z[3,6,6]  R1547     4.7487938404083252e-01
    z[3,6,6]  R1548     3.8391733169555664e-01
    z[3,6,6]  R1549     -1.1770492047071457e-01
    z[3,6,6]  R1550     -4.4261552393436432e-03
    z[3,6,6]  R1551     -1.6064360737800598e-01
    z[3,6,6]  R1552     -1.6098898649215698e-01
    z[3,6,6]  R1553     -0.301470011472702
    z[3,6,6]  R1554     1.6815978288650513e-01
    z[3,6,6]  R1555     -1.2203180789947510e-01
    z[3,6,6]  R1556     1.4321976900100708e-01
    z[3,6,6]  R1557     -1.0164518840610981e-02
    z[3,6,6]  R1558     2.7247878909111023e-01
    z[3,6,6]  R1559     1.8773525953292847e-01
    z[3,6,6]  R1560     -2.3031197488307953e-01
    z[3,6,6]  R1561     3.7443738430738449e-02
    z[3,6,6]  R1562     -5.8671992272138596e-02
    z[3,6,6]  R1563     -4.4896829128265381e-01
    z[3,6,6]  R1564     0.0770488902926445
    z[3,6,6]  R1565     -2.5659623742103577e-01
    z[3,6,6]  R1566     -7.1774378418922424e-02
    z[3,6,6]  R1567     3.3430272340774536e-01
    z[3,6,6]  R1568     2.6974827051162720e-02
    z[3,6,6]  R1569     -6.8659879267215729e-02
    z[3,6,6]  R1570     8.4615841507911682e-02
    z[3,6,6]  R1571     9.7019389271736145e-02
    z[3,6,6]  R1572     3.8433033227920532e-01
    z[3,6,6]  R1573     -6.3249057531356812e-01
    z[3,6,6]  R1574     -2.1371269226074219e-01
    z[3,6,6]  R1575     -4.1133394837379456e-01
    z[3,6,6]  R1576     -0.0805663913488388
    z[3,6,6]  R1577     1.8261478841304779e-01
    z[3,6,6]  R1578     -2.9590731486678123e-02
    z[3,6,6]  R1579     -9.6845522522926331e-02
    z[3,6,6]  R1580     2.0080134272575378e-01
    z[3,6,6]  R1581     -2.0039488375186920e-01
    z[3,6,6]  R1582     3.6406585574150085e-01
    z[3,6,6]  R1583     -2.0754756033420563e-01
    z[3,6,6]  R1584     0.0768914446234703
    z[3,6,6]  R1585     1.9086304306983948e-01
    z[3,6,6]  R1586     2.0770902931690216e-01
    z[3,6,6]  R1587     4.1985239833593369e-02
    z[3,6,6]  R1588     -2.1316848695278168e-01
    z[3,6,6]  R1589     -7.0847973227500916e-02
    z[3,6,6]  R1590     1.4123211801052094e-01
    z[3,6,6]  R1591     -7.8969992697238922e-02
    z[3,6,6]  R1592     -1.1099644750356674e-01
    z[3,6,6]  R1593     -1.9904676079750061e-01
    z[3,6,6]  R1594     -2.7316769957542419e-01
    z[3,6,6]  R1595     3.7511962652206421e-01
    z[3,6,6]  R1596     -2.7071639895439148e-01
    z[3,6,6]  R1597     0.0816039890050888
    z[3,6,6]  R1598     1.1319984495639801e-01
    z[3,6,6]  R1599     2.7768164873123169e-01
    z[3,6,6]  R1600     6.2627747654914856e-02
    z[3,6,6]  R1601     -0.0424545481801033
    z[3,6,6]  R1602     -4.8246022313833237e-02
    z[3,6,6]  R1603     -1.7423997819423676e-01
    z[3,6,6]  R1604     -2.3064975440502167e-01
    z[3,6,6]  R1605     -2.5198507308959961e-01
    z[3,6,6]  R1606     -2.8632849454879761e-01
    z[3,6,6]  R1607     -1.7734473943710327e-01
    z[3,6,6]  R1608     0.0823395624756813
    z[3,6,6]  R1609     -2.5365290045738220e-01
    z[3,6,6]  R1610     5.3452465683221817e-02
    z[3,6,6]  R1611     1.7981614917516708e-02
    z[3,6,6]  R1612     8.4437653422355652e-02
    z[3,6,6]  R1613     1.7719270288944244e-01
    z[3,6,6]  R1614     -4.9363183975219727e-01
    z[3,6,6]  R1615     1.7795109748840332e-01
    z[3,6,6]  R1616     -6.2378573417663574e-01
    z[3,6,6]  R1617     -2.1367833018302917e-01
    z[3,6,6]  R1618     1.7445491254329681e-01
    z[3,6,6]  R1619     1.5673954784870148e-01
    z[3,6,6]  R1620     -0.282549113035202
    z[3,6,6]  R1621     -9.0264402329921722e-02
    z[3,6,6]  R1622     2.8157643973827362e-03
    z[3,6,6]  R1623     -6.1274436302483082e-03
    z[3,6,6]  R1624     2.0600537955760956e-01
    z[3,6,6]  R1625     1.3947731256484985e-01
    z[3,6,6]  R1626     1.3983491063117981e-01
    z[3,6,6]  R1627     -2.2028565406799316e-01
    z[3,6,6]  R1628     1.3029728829860687e-01
    z[3,6,6]  R1629     -2.9339674860239029e-02
    z[3,6,6]  R1630     -1.4245378971099854e-01
    z[3,6,6]  R1631     -0.257985919713974
    z[3,6,6]  R1632     -2.4304588139057159e-01
    z[3,6,6]  R1633     -5.2570408582687378e-01
    z[3,6,6]  R1634     3.2696448266506195e-02
    z[3,6,6]  R1635     -3.7743654102087021e-02
    z[3,6,6]  R1636     -0.148038849234581
    z[3,6,6]  R1637     -2.4738231301307678e-01
    z[3,6,6]  R1638     -2.0432794094085693e-01
    z[3,6,6]  R1639     -1.5077529847621918e-01
    z[3,6,6]  R1640     -1.4350248873233795e-01
    z[3,6,6]  R1641     1.1306065320968628e-01
    z[3,6,6]  R1642     1.0979101061820984e-01
    z[3,6,6]  R1643     3.0902945995330811e-01
    z[3,6,6]  R1644     0.0984988585114479
    z[3,6,6]  R1645     -3.4991574287414551e-01
    z[3,6,6]  R1646     -1.4413505792617798e-01
    z[3,6,6]  R1647     2.2152608260512352e-02
    z[3,6,6]  R1648     -7.0057488977909088e-02
    z[3,6,6]  R1649     1.2082371860742569e-01
    z[3,6,6]  R1650     7.4731156229972839e-02
    z[3,6,6]  R1651     0.2565937936306
    z[3,6,6]  R1652     2.3028762638568878e-01
    z[3,6,6]  R1653     -2.3457955569028854e-02
    z[3,6,6]  R1654     1.1988984793424606e-01
    z[3,6,6]  R1655     1.9500355422496796e-01
    z[3,6,6]  R1656     5.0898820161819458e-01
    z[3,6,6]  R1657     4.6658405661582947e-01
    z[3,6,6]  R1658     1.8439665436744690e-01
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1659     -1
    z[6,3,0]  R1660     1
    z[6,3,0]  R1673     -8.7384122610092163e-01
    z[6,3,0]  R1674     -8.8748365640640259e-01
    z[6,3,0]  R1675     -9.4941294193267822e-01
    z[6,3,0]  R1676     -8.5786253213882446e-01
    z[6,3,0]  R1677     -9.1623759269714355e-01
    z[6,3,0]  R1678     -7.2450643777847290e-01
    z[6,3,0]  R1679     -9.3621307611465454e-01
    z[6,3,0]  R1680     -0.96856290102005
    z[6,3,0]  R1681     -8.3268773555755615e-01
    z[6,3,0]  R1682     -8.0606764554977417e-01
    z[6,3,0]  R1683     2.0103774964809418e-01
    z[6,3,0]  R1684     2.1778398752212524e-01
    z[6,3,0]  R1685     1.9404245913028717e-01
    z[6,3,0]  R1686     -0.0822681114077568
    z[6,3,0]  R1687     -2.5601822417229414e-03
    z[6,3,0]  R1688     2.5686609745025635e-01
    z[6,3,0]  R1689     2.3033238947391510e-01
    z[6,3,0]  R1690     3.1332874298095703e-01
    z[6,3,0]  R1691     -1.5054904855787754e-02
    z[6,3,0]  R1692     1.5797884762287140e-01
    z[6,3,0]  R1693     8.2420194149017334e-01
    z[6,3,0]  R1694     4.1432134807109833e-02
    z[6,3,0]  R1695     0.51854008436203
    z[6,3,0]  R1696     7.2541677951812744e-01
    z[6,3,0]  R1697     5.0932067632675171e-01
    z[6,3,0]  R1698     5.2500754594802856e-01
    z[6,3,0]  R1699     3.7646532058715820e-01
    z[6,3,0]  R1700     7.7187612652778625e-02
    z[6,3,0]  R1701     5.5519080162048340e-01
    z[6,3,0]  R1702     1.7107808589935303e-01
    z[6,3,0]  R1703     5.8747440576553345e-01
    z[6,3,0]  R1704     0.787808895111084
    z[6,3,0]  R1705     -1.2902888655662537e-01
    z[6,3,0]  R1706     7.3995554447174072e-01
    z[6,3,0]  R1707     1.4056351780891418e-01
    z[6,3,0]  R1708     6.9226735830307007e-01
    z[6,3,0]  R1709     2.5577588006854057e-02
    z[6,3,0]  R1710     8.1297689676284790e-01
    z[6,3,0]  R1711     5.6801873445510864e-01
    z[6,3,0]  R1712     -2.2160109877586365e-01
    z[6,3,0]  R1713     -1.0260418057441711e-03
    z[6,3,0]  R1714     3.2716092467308044e-01
    z[6,3,0]  R1715     4.2324984073638916e-01
    z[6,3,0]  R1716     4.8220828175544739e-02
    z[6,3,0]  R1717     0.618370532989502
    z[6,3,0]  R1718     5.8190727233886719e-01
    z[6,3,0]  R1719     3.2456271350383759e-02
    z[6,3,0]  R1720     -2.7239865064620972e-01
    z[6,3,0]  R1721     -3.8483291864395142e-01
    z[6,3,0]  R1722     7.6029294729232788e-01
    z[6,3,0]  R1723     -7.7624571323394775e-01
    z[6,3,0]  R1724     7.8828144073486328e-01
    z[6,3,0]  R1725     6.0670781135559082e-01
    z[6,3,0]  R1726     1.2974782288074493e-01
    z[6,3,0]  R1727     4.8424193263053894e-01
    z[6,3,0]  R1728     5.4049581289291382e-01
    z[6,3,0]  R1729     5.2734637260437012e-01
    z[6,3,0]  R1730     5.1648199558258057e-01
    z[6,3,0]  R1731     -3.5389885306358337e-01
    z[6,3,0]  R1732     0.0541507862508297
    z[6,3,0]  R1733     4.1410472989082336e-01
    z[6,3,0]  R1734     1.3840852305293083e-02
    z[6,3,0]  R1735     8.0886858701705933e-01
    z[6,3,0]  R1736     -4.1802600026130676e-01
    z[6,3,0]  R1737     -4.2783138155937195e-01
    z[6,3,0]  R1738     4.6446800231933594e-01
    z[6,3,0]  R1739     7.1531379222869873e-01
    z[6,3,0]  R1740     5.2551430463790894e-01
    z[6,3,0]  R1741     -3.5186198353767395e-01
    z[6,3,0]  R1742     7.0942497253417969e-01
    z[6,3,0]  R1743     8.9145672321319580e-01
    z[6,3,0]  R1744     4.3067368865013123e-01
    z[6,3,0]  R1745     -2.3954921960830688e-01
    z[6,3,0]  R1746     -5.8236384391784668e-01
    z[6,3,0]  R1747     6.2779515981674194e-01
    z[6,3,0]  R1748     5.2663028240203857e-01
    z[6,3,0]  R1749     4.8508965969085693e-01
    z[6,3,0]  R1750     8.4526282548904419e-01
    z[6,3,0]  R1751     -4.7784465551376343e-01
    z[6,3,0]  R1752     1.4369764365255833e-02
    z[6,3,0]  R1753     -7.4734479188919067e-01
    z[6,3,0]  R1754     6.1633431911468506e-01
    z[6,3,0]  R1755     0.401021271944046
    z[6,3,0]  R1756     4.8296386003494263e-01
    z[6,3,0]  R1757     0.680448055267334
    z[6,3,0]  R1758     -3.7621328234672546e-01
    z[6,3,0]  R1759     1.2038894742727280e-01
    z[6,3,0]  R1760     -1.7895002383738756e-04
    z[6,3,0]  R1761     -8.2989625632762909e-02
    z[6,3,0]  R1762     -2.8991684317588806e-02
    z[6,3,0]  R1763     -0.743486762046814
    z[6,3,0]  R1764     7.0977705717086792e-01
    z[6,3,0]  R1765     5.7753592729568481e-01
    z[6,3,0]  R1766     4.3028134107589722e-01
    z[6,3,0]  R1767     1.7088226974010468e-01
    z[6,3,0]  R1768     6.7804497666656971e-03
    z[6,3,0]  R1769     -6.1569139361381531e-02
    z[6,3,0]  R1770     3.5309992730617523e-02
    z[6,3,0]  R1771     -1.1695101112127304e-01
    z[6,3,0]  R1772     -4.5996751636266708e-02
    z[6,3,0]  R1773     7.2832182049751282e-03
    z[6,3,0]  R1774     6.1436778306961060e-01
    z[6,3,0]  R1775     5.5816221237182617e-01
    z[6,3,0]  R1776     -4.5648229122161865e-01
    z[6,3,0]  R1777     -3.2614029943943024e-02
    z[6,3,0]  R1778     -2.6928958296775818e-01
    z[6,3,0]  R1779     -1.3647805154323578e-01
    z[6,3,0]  R1780     2.3611165583133698e-02
    z[6,3,0]  R1781     -6.7060112953186035e-02
    z[6,3,0]  R1782     -0.0773346871137619
    z[6,3,0]  R1783     -4.3774202822532970e-06
    z[6,3,0]  R1784     -5.0196421146392822e-01
    z[6,3,0]  R1785     9.2960394918918610e-02
    z[6,3,0]  R1786     -5.4913395643234253e-01
    z[6,3,0]  R1787     -4.6438139677047729e-01
    z[6,3,0]  R1788     -3.6235442757606506e-01
    z[6,3,0]  R1789     1.7734211683273315e-01
    z[6,3,0]  R1790     1.1243292689323425e-01
    z[6,3,0]  R1791     -5.2351492643356323e-01
    z[6,3,0]  R1792     3.2991003245115280e-03
    z[6,3,0]  R1793     3.1800916790962219e-01
    z[6,3,0]  R1794     3.3361810445785522e-01
    z[6,3,0]  R1795     3.0185526609420776e-01
    z[6,3,0]  R1796     3.6144572496414185e-01
    z[6,3,0]  R1797     1.7125104367733002e-01
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1661     -1
    z[6,3,1]  R1662     1
    z[6,3,1]  R1673     -3.8983193039894104e-01
    z[6,3,1]  R1674     -3.6499857902526855e-01
    z[6,3,1]  R1675     -2.1544776856899261e-02
    z[6,3,1]  R1676     -6.8940952420234680e-02
    z[6,3,1]  R1677     -1.2151963263750076e-01
    z[6,3,1]  R1678     -5.3895201534032822e-02
    z[6,3,1]  R1679     3.3995623234659433e-03
    z[6,3,1]  R1680     -6.3452741596847773e-04
    z[6,3,1]  R1681     2.7241089940071106e-01
    z[6,3,1]  R1682     -2.8118479251861572e-01
    z[6,3,1]  R1683     -5.0241601467132568e-01
    z[6,3,1]  R1684     -1.9956082105636597e-01
    z[6,3,1]  R1685     -5.9879440069198608e-01
    z[6,3,1]  R1686     -7.0977377891540527e-01
    z[6,3,1]  R1687     -4.8572760820388794e-01
    z[6,3,1]  R1688     -5.2118331193923950e-01
    z[6,3,1]  R1689     -6.8679213523864746e-02
    z[6,3,1]  R1690     -5.8934754133224487e-01
    z[6,3,1]  R1691     -4.0870368480682373e-01
    z[6,3,1]  R1692     -5.2850800752639771e-01
    z[6,3,1]  R1693     -3.1171565875411034e-02
    z[6,3,1]  R1694     -9.5037811994552612e-01
    z[6,3,1]  R1695     3.0611717700958252e-01
    z[6,3,1]  R1696     1.5424132347106934e-01
    z[6,3,1]  R1697     -9.2823922634124756e-02
    z[6,3,1]  R1698     3.5708022117614746e-01
    z[6,3,1]  R1699     -5.2102571725845337e-01
    z[6,3,1]  R1700     6.6686397790908813e-01
    z[6,3,1]  R1701     -1.4312581717967987e-01
    z[6,3,1]  R1702     6.0229659080505371e-01
    z[6,3,1]  R1703     -3.4938564896583557e-01
    z[6,3,1]  R1704     1.5225054323673248e-01
    z[6,3,1]  R1705     -7.8362977504730225e-01
    z[6,3,1]  R1706     0.045985147356987
    z[6,3,1]  R1707     -8.9270532131195068e-01
    z[6,3,1]  R1708     1.0074172914028168e-01
    z[6,3,1]  R1709     -6.3061875104904175e-01
    z[6,3,1]  R1710     -3.0362397432327271e-01
    z[6,3,1]  R1711     1.2596595287322998e-01
    z[6,3,1]  R1712     -5.5027091503143311e-01
    z[6,3,1]  R1713     -7.6516550779342651e-01
    z[6,3,1]  R1714     -8.8505178689956665e-01
    z[6,3,1]  R1715     -5.2559173107147217e-01
    z[6,3,1]  R1716     -0.89644455909729
    z[6,3,1]  R1717     2.1496775746345520e-01
    z[6,3,1]  R1718     -2.3313325643539429e-01
    z[6,3,1]  R1719     -7.7686858177185059e-01
    z[6,3,1]  R1720     -5.5272829532623291e-01
    z[6,3,1]  R1721     -1.3243253529071808e-01
    z[6,3,1]  R1722     -3.7105970084667206e-02
    z[6,3,1]  R1723     -2.6720070838928223e-01
    z[6,3,1]  R1724     -3.0520877242088318e-01
    z[6,3,1]  R1725     -4.4281157851219177e-01
    z[6,3,1]  R1726     -4.7522720694541931e-01
    z[6,3,1]  R1727     -1.7094098031520844e-01
    z[6,3,1]  R1728     -1.9637905061244965e-01
    z[6,3,1]  R1729     -4.5808512717485428e-02
    z[6,3,1]  R1730     2.2161212563514709e-01
    z[6,3,1]  R1731     7.5454115867614746e-01
    z[6,3,1]  R1732     8.6229842901229858e-01
    z[6,3,1]  R1733     -2.6137259602546692e-01
    z[6,3,1]  R1734     -6.7997843027114868e-01
    z[6,3,1]  R1735     1.7777520418167114e-01
    z[6,3,1]  R1736     -6.4122051000595093e-01
    z[6,3,1]  R1737     -0.055446557700634
    z[6,3,1]  R1738     -2.7222353219985962e-01
    z[6,3,1]  R1739     -2.6235067844390869e-01
    z[6,3,1]  R1740     -1.5870186686515808e-01
    z[6,3,1]  R1741     1.6907547414302826e-01
    z[6,3,1]  R1742     2.0996022969484329e-02
    z[6,3,1]  R1743     -1.4200265705585480e-01
    z[6,3,1]  R1744     -3.0012896656990051e-01
    z[6,3,1]  R1745     -7.6789957284927368e-01
    z[6,3,1]  R1746     -5.6674383580684662e-02
    z[6,3,1]  R1747     -1.9198960065841675e-01
    z[6,3,1]  R1748     -1.4512595720589161e-02
    z[6,3,1]  R1749     3.6846555769443512e-02
    z[6,3,1]  R1750     2.8690424561500549e-01
    z[6,3,1]  R1751     4.8175626993179321e-01
    z[6,3,1]  R1752     7.9874765872955322e-01
    z[6,3,1]  R1753     -1.4394551515579224e-02
    z[6,3,1]  R1754     -3.0781856179237366e-01
    z[6,3,1]  R1755     -2.7524015307426453e-01
    z[6,3,1]  R1756     -2.0112356543540955e-01
    z[6,3,1]  R1757     1.0570946335792542e-01
    z[6,3,1]  R1758     -1.8369263410568237e-01
    z[6,3,1]  R1759     5.2311939001083374e-01
    z[6,3,1]  R1760     7.2564291954040527e-01
    z[6,3,1]  R1761     7.3291534185409546e-01
    z[6,3,1]  R1762     8.1506699323654175e-01
    z[6,3,1]  R1763     9.3010291457176208e-02
    z[6,3,1]  R1764     -1.8123178184032440e-01
    z[6,3,1]  R1765     -0.145138680934906
    z[6,3,1]  R1766     -2.4333159625530243e-01
    z[6,3,1]  R1767     -4.8579236865043640e-01
    z[6,3,1]  R1768     6.5936404466629028e-01
    z[6,3,1]  R1769     6.2111669778823853e-01
    z[6,3,1]  R1770     0.584827721118927
    z[6,3,1]  R1771     8.8545787334442139e-01
    z[6,3,1]  R1772     8.1723350286483765e-01
    z[6,3,1]  R1773     -4.9319869279861450e-01
    z[6,3,1]  R1774     -1.6294093430042267e-01
    z[6,3,1]  R1775     -5.0169759988784790e-01
    z[6,3,1]  R1776     -3.1170082092285156e-01
    z[6,3,1]  R1777     9.1450905799865723e-01
    z[6,3,1]  R1778     8.0454438924789429e-01
    z[6,3,1]  R1779     0.808972954750061
    z[6,3,1]  R1780     6.4437693357467651e-01
    z[6,3,1]  R1781     6.1878538131713867e-01
    z[6,3,1]  R1782     0.753345787525177
    z[6,3,1]  R1783     1.1947839707136154e-01
    z[6,3,1]  R1784     -0.65839684009552
    z[6,3,1]  R1785     -0.691955029964447
    z[6,3,1]  R1786     -5.5208396911621094e-01
    z[6,3,1]  R1787     -0.626633882522583
    z[6,3,1]  R1788     -4.1933557391166687e-01
    z[6,3,1]  R1789     0.064608134329319
    z[6,3,1]  R1790     -3.9330857992172241e-01
    z[6,3,1]  R1791     -0.666795015335083
    z[6,3,1]  R1792     -4.9973803758621216e-01
    z[6,3,1]  R1793     0.822810173034668
    z[6,3,1]  R1794     6.9742277264595032e-02
    z[6,3,1]  R1795     4.6270421147346497e-01
    z[6,3,1]  R1796     -0.0831177830696106
    z[6,3,1]  R1797     -5.0423705577850342e-01
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1663     -1
    z[6,3,2]  R1664     1
    z[6,3,2]  R1673     -1.7520034313201904e-01
    z[6,3,2]  R1674     -1.1685901880264282e-01
    z[6,3,2]  R1675     -1.6333484649658203e-01
    z[6,3,2]  R1676     -2.6785880327224731e-01
    z[6,3,2]  R1677     -1.8257641792297363e-01
    z[6,3,2]  R1678     -5.3789663314819336e-01
    z[6,3,2]  R1679     -1.7760933935642242e-01
    z[6,3,2]  R1680     -1.7945638298988342e-01
    z[6,3,2]  R1681     -3.8195076584815979e-01
    z[6,3,2]  R1682     -0.0339924618601799
    z[6,3,2]  R1683     2.8260305523872375e-01
    z[6,3,2]  R1684     7.1075963973999023e-01
    z[6,3,2]  R1685     6.8378818035125732e-01
    z[6,3,2]  R1686     5.4878199100494385e-01
    z[6,3,2]  R1687     4.9439480900764465e-01
    z[6,3,2]  R1688     6.2343740463256836e-01
    z[6,3,2]  R1689     5.0190275907516479e-01
    z[6,3,2]  R1690     4.8393711447715759e-01
    z[6,3,2]  R1691     3.8058194518089294e-01
    z[6,3,2]  R1692     4.3565174937248230e-01
    z[6,3,2]  R1693     3.2944139838218689e-01
    z[6,3,2]  R1694     -1.5970049798488617e-01
    z[6,3,2]  R1695     6.8351435661315918e-01
    z[6,3,2]  R1696     2.4656991660594940e-01
    z[6,3,2]  R1697     1.1712289601564407e-01
    z[6,3,2]  R1698     6.8361848592758179e-01
    z[6,3,2]  R1699     -1.3215051591396332e-01
    z[6,3,2]  R1700     -6.0098522901535034e-01
    z[6,3,2]  R1701     4.9145266413688660e-01
    z[6,3,2]  R1702     -0.706415057182312
    z[6,3,2]  R1703     3.1549575924873352e-01
    z[6,3,2]  R1704     3.8917210698127747e-01
    z[6,3,2]  R1705     4.1174092888832092e-01
    z[6,3,2]  R1706     3.1450986862182617e-01
    z[6,3,2]  R1707     4.2288318276405334e-02
    z[6,3,2]  R1708     6.3316076993942261e-01
    z[6,3,2]  R1709     2.1973705291748047e-01
    z[6,3,2]  R1710     -5.7728279381990433e-02
    z[6,3,2]  R1711     7.7076196670532227e-01
    z[6,3,2]  R1712     2.6455268263816833e-01
    z[6,3,2]  R1713     4.2389449477195740e-01
    z[6,3,2]  R1714     2.2439652681350708e-01
    z[6,3,2]  R1715     6.4922392368316650e-01
    z[6,3,2]  R1716     1.6333243250846863e-01
    z[6,3,2]  R1717     5.4032075405120850e-01
    z[6,3,2]  R1718     -1.8255543708801270e-01
    z[6,3,2]  R1719     3.0196553096175194e-02
    z[6,3,2]  R1720     0.215520977973938
    z[6,3,2]  R1721     -6.1001914739608765e-01
    z[6,3,2]  R1722     8.8725559413433075e-02
    z[6,3,2]  R1723     -2.3672574758529663e-01
    z[6,3,2]  R1724     2.5989213585853577e-01
    z[6,3,2]  R1725     1.6411387920379639e-01
    z[6,3,2]  R1726     2.8355222940444946e-01
    z[6,3,2]  R1727     9.0234234929084778e-02
    z[6,3,2]  R1728     -1.9573102891445160e-01
    z[6,3,2]  R1729     4.8574164509773254e-01
    z[6,3,2]  R1730     6.5591341257095337e-01
    z[6,3,2]  R1731     -3.4801873564720154e-01
    z[6,3,2]  R1732     -4.6952879428863525e-01
    z[6,3,2]  R1733     6.7564022541046143e-01
    z[6,3,2]  R1734     1.2817643582820892e-03
    z[6,3,2]  R1735     4.2216774821281433e-01
    z[6,3,2]  R1736     1.5791609883308411e-01
    z[6,3,2]  R1737     -7.6735556125640869e-01
    z[6,3,2]  R1738     2.5689122080802917e-01
    z[6,3,2]  R1739     0.395819753408432
    z[6,3,2]  R1740     2.0394693315029144e-01
    z[6,3,2]  R1741     -6.5956008434295654e-01
    z[6,3,2]  R1742     0.0963897705078125
    z[6,3,2]  R1743     2.1616187691688538e-01
    z[6,3,2]  R1744     3.8360023498535156e-01
    z[6,3,2]  R1745     0.522737979888916
    z[6,3,2]  R1746     -5.8665275573730469e-01
    z[6,3,2]  R1747     0.257693350315094
    z[6,3,2]  R1748     5.1851803064346313e-01
    z[6,3,2]  R1749     3.2036128640174866e-01
    z[6,3,2]  R1750     3.1420376896858215e-01
    z[6,3,2]  R1751     -4.5502316951751709e-01
    z[6,3,2]  R1752     -4.5573037862777710e-01
    z[6,3,2]  R1753     -6.1263483762741089e-01
    z[6,3,2]  R1754     3.7518495321273804e-01
    z[6,3,2]  R1755     4.6717628836631775e-01
    z[6,3,2]  R1756     2.9142412543296814e-01
    z[6,3,2]  R1757     3.8473892211914062e-01
    z[6,3,2]  R1758     4.9168238043785095e-01
    z[6,3,2]  R1759     -8.2693254947662354e-01
    z[6,3,2]  R1760     -3.9073020219802856e-01
    z[6,3,2]  R1761     -0.315792053937912
    z[6,3,2]  R1762     -1.5693803131580353e-01
    z[6,3,2]  R1763     -0.431908518075943
    z[6,3,2]  R1764     4.6711099147796631e-01
    z[6,3,2]  R1765     5.1746422052383423e-01
    z[6,3,2]  R1766     1.6701912879943848e-01
    z[6,3,2]  R1767     2.2287330031394958e-01
    z[6,3,2]  R1768     -6.4267307519912720e-01
    z[6,3,2]  R1769     -5.4743212461471558e-01
    z[6,3,2]  R1770     -5.9905093908309937e-01
    z[6,3,2]  R1771     3.9783951640129089e-01
    z[6,3,2]  R1772     5.3042483329772949e-01
    z[6,3,2]  R1773     6.0604417324066162e-01
    z[6,3,2]  R1774     1.0132411122322083e-01
    z[6,3,2]  R1775     2.7886566519737244e-01
    z[6,3,2]  R1776     -4.7770851850509644e-01
    z[6,3,2]  R1777     -3.4008646011352539e-01
    z[6,3,2]  R1778     3.9407119154930115e-01
    z[6,3,2]  R1779     4.1896224021911621e-01
    z[6,3,2]  R1780     5.4252862930297852e-01
    z[6,3,2]  R1781     5.3949481248855591e-01
    z[6,3,2]  R1782     3.8305473327636719e-01
    z[6,3,2]  R1783     -5.0464099645614624e-01
    z[6,3,2]  R1784     -4.3756082653999329e-01
    z[6,3,2]  R1785     -4.2218956351280212e-01
    z[6,3,2]  R1786     -3.9870855212211609e-01
    z[6,3,2]  R1787     -2.4444781243801117e-01
    z[6,3,2]  R1788     -7.1697455644607544e-01
    z[6,3,2]  R1789     -4.2742338031530380e-02
    z[6,3,2]  R1790     2.9280850291252136e-01
    z[6,3,2]  R1791     -3.2561093568801880e-01
    z[6,3,2]  R1792     7.9545283317565918e-01
    z[6,3,2]  R1793     3.1671860814094543e-01
    z[6,3,2]  R1794     1.6957861185073853e-01
    z[6,3,2]  R1795     3.2461118698120117e-01
    z[6,3,2]  R1796     2.1251462399959564e-01
    z[6,3,2]  R1797     4.9290871247649193e-03
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1665     -1
    z[6,3,3]  R1666     1
    z[6,3,3]  R1673     1.9722686707973480e-01
    z[6,3,3]  R1674     -1.7805849015712738e-01
    z[6,3,3]  R1675     -1.3938149809837341e-01
    z[6,3,3]  R1676     3.1448623538017273e-01
    z[6,3,3]  R1677     0.00422905758023262
    z[6,3,3]  R1678     3.0133891850709915e-02
    z[6,3,3]  R1679     -5.1916502416133881e-02
    z[6,3,3]  R1680     -4.8395209014415741e-02
    z[6,3,3]  R1681     -7.3296025395393372e-02
    z[6,3,3]  R1682     2.6381894946098328e-01
    z[6,3,3]  R1683     -3.9144456386566162e-01
    z[6,3,3]  R1684     2.1493844687938690e-01
    z[6,3,3]  R1685     -3.2905817031860352e-02
    z[6,3,3]  R1686     1.3282246887683868e-01
    z[6,3,3]  R1687     -4.2959639430046082e-01
    z[6,3,3]  R1688     -2.6216539740562439e-01
    z[6,3,3]  R1689     -1.5089030377566814e-02
    z[6,3,3]  R1690     2.9635429382324219e-01
    z[6,3,3]  R1691     -3.1604444980621338e-01
    z[6,3,3]  R1692     2.2651587426662445e-01
    z[6,3,3]  R1693     1.9076961278915405e-01
    z[6,3,3]  R1694     -1.6248348355293274e-01
    z[6,3,3]  R1695     -3.2762053608894348e-01
    z[6,3,3]  R1696     -9.8815739154815674e-02
    z[6,3,3]  R1697     4.4113656878471375e-01
    z[6,3,3]  R1698     1.8524500727653503e-01
    z[6,3,3]  R1699     2.6893270015716553e-01
    z[6,3,3]  R1700     -8.2504920661449432e-02
    z[6,3,3]  R1701     -3.0172142386436462e-01
    z[6,3,3]  R1702     2.6870843768119812e-01
    z[6,3,3]  R1703     2.9335431754589081e-02
    z[6,3,3]  R1704     1.2446004152297974e-01
    z[6,3,3]  R1705     -0.279773473739624
    z[6,3,3]  R1706     1.1687626689672470e-01
    z[6,3,3]  R1707     1.3141964375972748e-01
    z[6,3,3]  R1708     -3.0197307467460632e-01
    z[6,3,3]  R1709     -0.718078076839447
    z[6,3,3]  R1710     -2.2317622601985931e-01
    z[6,3,3]  R1711     -7.3442630469799042e-02
    z[6,3,3]  R1712     -1.9902646541595459e-01
    z[6,3,3]  R1713     -3.9294418692588806e-01
    z[6,3,3]  R1714     -1.0631754249334335e-01
    z[6,3,3]  R1715     8.6140096187591553e-02
    z[6,3,3]  R1716     -0.0592268705368042
    z[6,3,3]  R1717     1.1346279084682465e-01
    z[6,3,3]  R1718     5.5354988574981689e-01
    z[6,3,3]  R1719     -2.1806603670120239e-01
    z[6,3,3]  R1720     1.3416700065135956e-01
    z[6,3,3]  R1721     -4.5715585350990295e-01
    z[6,3,3]  R1722     -2.9148977249860764e-02
    z[6,3,3]  R1723     -2.1368084847927094e-01
    z[6,3,3]  R1724     -1.3163023628294468e-02
    z[6,3,3]  R1725     5.4514998197555542e-01
    z[6,3,3]  R1726     -1.0321961343288422e-01
    z[6,3,3]  R1727     5.3564912080764771e-01
    z[6,3,3]  R1728     2.9216277599334717e-01
    z[6,3,3]  R1729     3.0592599511146545e-01
    z[6,3,3]  R1730     1.5349418856203556e-02
    z[6,3,3]  R1731     -1.7554216086864471e-01
    z[6,3,3]  R1732     1.0113058984279633e-01
    z[6,3,3]  R1733     4.0966841578483582e-01
    z[6,3,3]  R1734     -3.4179797768592834e-01
    z[6,3,3]  R1735     -2.9593538492918015e-03
    z[6,3,3]  R1736     -1.8164904788136482e-02
    z[6,3,3]  R1737     -3.0162784457206726e-01
    z[6,3,3]  R1738     2.2983743250370026e-01
    z[6,3,3]  R1739     2.0392403006553650e-01
    z[6,3,3]  R1740     3.1509986519813538e-01
    z[6,3,3]  R1741     -4.8180431127548218e-01
    z[6,3,3]  R1742     4.9940237402915955e-01
    z[6,3,3]  R1743     0.303492933511734
    z[6,3,3]  R1744     0.298991322517395
    z[6,3,3]  R1745     -9.7847640514373779e-02
    z[6,3,3]  R1746     -3.3750689029693604e-01
    z[6,3,3]  R1747     3.1253427267074585e-01
    z[6,3,3]  R1748     1.9220243394374847e-01
    z[6,3,3]  R1749     1.3646423816680908e-01
    z[6,3,3]  R1750     -2.2059574723243713e-01
    z[6,3,3]  R1751     1.5589003264904022e-01
    z[6,3,3]  R1752     3.3723658323287964e-01
    z[6,3,3]  R1753     5.4800111800432205e-02
    z[6,3,3]  R1754     1.9486233592033386e-01
    z[6,3,3]  R1755     1.5734905004501343e-01
    z[6,3,3]  R1756     -6.4490497112274170e-02
    z[6,3,3]  R1757     -0.0396580696105957
    z[6,3,3]  R1758     6.9540542364120483e-01
    z[6,3,3]  R1759     7.5495615601539612e-02
    z[6,3,3]  R1760     3.2061886787414551e-01
    z[6,3,3]  R1761     4.6656790375709534e-01
    z[6,3,3]  R1762     0.474361777305603
    z[6,3,3]  R1763     -3.0580973625183105e-01
    z[6,3,3]  R1764     4.5167854428291321e-01
    z[6,3,3]  R1765     -3.4414285421371460e-01
    z[6,3,3]  R1766     2.4899591505527496e-01
    z[6,3,3]  R1767     -7.5129413604736328e-01
    z[6,3,3]  R1768     3.4967169165611267e-01
    z[6,3,3]  R1769     4.1893583536148071e-01
    z[6,3,3]  R1770     -2.6354610919952393e-01
    z[6,3,3]  R1771     1.5516200102865696e-02
    z[6,3,3]  R1772     1.0314907878637314e-01
    z[6,3,3]  R1773     -0.500938892364502
    z[6,3,3]  R1774     1.9754789769649506e-01
    z[6,3,3]  R1775     2.4601487815380096e-01
    z[6,3,3]  R1776     -6.2834209203720093e-01
    z[6,3,3]  R1777     9.7366660833358765e-02
    z[6,3,3]  R1778     2.8921690583229065e-01
    z[6,3,3]  R1779     1.8290439248085022e-01
    z[6,3,3]  R1780     1.8155736848711967e-02
    z[6,3,3]  R1781     -1.2649394571781158e-01
    z[6,3,3]  R1782     -3.0813655257225037e-01
    z[6,3,3]  R1783     5.6319665908813477e-01
    z[6,3,3]  R1784     -1.0369183868169785e-01
    z[6,3,3]  R1785     -5.2761048078536987e-01
    z[6,3,3]  R1786     -4.3900772929191589e-02
    z[6,3,3]  R1787     1.8475079536437988e-01
    z[6,3,3]  R1788     3.5118627548217773e-01
    z[6,3,3]  R1789     3.1219440698623657e-01
    z[6,3,3]  R1790     -2.4333126842975616e-01
    z[6,3,3]  R1791     7.5939163565635681e-02
    z[6,3,3]  R1792     -1.5298357605934143e-01
    z[6,3,3]  R1793     7.3067627847194672e-02
    z[6,3,3]  R1794     5.9623247385025024e-01
    z[6,3,3]  R1795     -4.7412705421447754e-01
    z[6,3,3]  R1796     -0.594360888004303
    z[6,3,3]  R1797     -2.1659563481807709e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1667     -1
    z[6,3,4]  R1668     1
    z[6,3,4]  R1673     2.5442723184823990e-02
    z[6,3,4]  R1674     1.5681026875972748e-01
    z[6,3,4]  R1675     9.9835090339183807e-02
    z[6,3,4]  R1676     2.4434188008308411e-01
    z[6,3,4]  R1677     -3.4472875297069550e-02
    z[6,3,4]  R1678     3.6078128218650818e-01
    z[6,3,4]  R1679     2.0710060000419617e-01
    z[6,3,4]  R1680     4.5984137803316116e-02
    z[6,3,4]  R1681     2.6967635750770569e-01
    z[6,3,4]  R1682     3.3857962489128113e-01
    z[6,3,4]  R1683     1.8772387504577637e-01
    z[6,3,4]  R1684     -6.4913578331470490e-02
    z[6,3,4]  R1685     3.2985430955886841e-01
    z[6,3,4]  R1686     3.9232546091079712e-01
    z[6,3,4]  R1687     3.3945900201797485e-01
    z[6,3,4]  R1688     1.2313283234834671e-01
    z[6,3,4]  R1689     -4.2394474148750305e-01
    z[6,3,4]  R1690     3.2723551988601685e-01
    z[6,3,4]  R1691     5.8565360307693481e-01
    z[6,3,4]  R1692     2.8684270381927490e-01
    z[6,3,4]  R1693     -3.7396547198295593e-01
    z[6,3,4]  R1694     -1.7767411470413208e-01
    z[6,3,4]  R1695     2.1423611044883728e-01
    z[6,3,4]  R1696     4.1241145133972168e-01
    z[6,3,4]  R1697     -8.4720002487301826e-03
    z[6,3,4]  R1698     -2.1629419177770615e-02
    z[6,3,4]  R1699     -5.6049692630767822e-01
    z[6,3,4]  R1700     -4.1762074828147888e-01
    z[6,3,4]  R1701     -0.309527724981308
    z[6,3,4]  R1702     -1.8898989260196686e-01
    z[6,3,4]  R1703     -4.7102957963943481e-01
    z[6,3,4]  R1704     1.1562176048755646e-01
    z[6,3,4]  R1705     3.6604840308427811e-02
    z[6,3,4]  R1706     4.4977459311485291e-01
    z[6,3,4]  R1707     3.2556807994842529e-01
    z[6,3,4]  R1708     -3.6292336881160736e-02
    z[6,3,4]  R1709     2.5714278221130371e-02
    z[6,3,4]  R1710     -3.8738265633583069e-01
    z[6,3,4]  R1711     2.2139152884483337e-01
    z[6,3,4]  R1712     -3.5999670624732971e-01
    z[6,3,4]  R1713     -1.6703774034976959e-01
    z[6,3,4]  R1714     6.3023701310157776e-02
    z[6,3,4]  R1715     -3.0715823173522949e-02
    z[6,3,4]  R1716     -3.0421710014343262e-01
    z[6,3,4]  R1717     2.1932624280452728e-01
    z[6,3,4]  R1718     -1.7460497096180916e-02
    z[6,3,4]  R1719     4.3190225958824158e-01
    z[6,3,4]  R1720     0.67954021692276
    z[6,3,4]  R1721     -4.0179529786109924e-01
    z[6,3,4]  R1722     -1.0678673535585403e-01
    z[6,3,4]  R1723     2.9650720953941345e-01
    z[6,3,4]  R1724     -3.4526339173316956e-01
    z[6,3,4]  R1725     -1.7809841036796570e-01
    z[6,3,4]  R1726     6.9740664958953857e-01
    z[6,3,4]  R1727     3.9971670508384705e-01
    z[6,3,4]  R1728     -1.9026480615139008e-01
    z[6,3,4]  R1729     -1.3448676466941833e-01
    z[6,3,4]  R1730     -2.5099346041679382e-01
    z[6,3,4]  R1731     -3.4589907526969910e-01
    z[6,3,4]  R1732     -6.4240492880344391e-02
    z[6,3,4]  R1733     -8.8118426501750946e-02
    z[6,3,4]  R1734     4.5130811631679535e-02
    z[6,3,4]  R1735     -7.5812175869941711e-02
    z[6,3,4]  R1736     4.6922618150711060e-01
    z[6,3,4]  R1737     -2.1081276237964630e-01
    z[6,3,4]  R1738     -5.4514068365097046e-01
    z[6,3,4]  R1739     3.0137148499488831e-01
    z[6,3,4]  R1740     2.5732040405273438e-01
    z[6,3,4]  R1741     -2.0544733107089996e-01
    z[6,3,4]  R1742     4.3823051452636719e-01
    z[6,3,4]  R1743     1.1673387885093689e-01
    z[6,3,4]  R1744     -4.8256742954254150e-01
    z[6,3,4]  R1745     2.4360392987728119e-01
    z[6,3,4]  R1746     -3.2086694240570068e-01
    z[6,3,4]  R1747     4.6117997169494629e-01
    z[6,3,4]  R1748     3.9515700936317444e-01
    z[6,3,4]  R1749     4.5218691229820251e-02
    z[6,3,4]  R1750     -1.8601721525192261e-01
    z[6,3,4]  R1751     -3.0061137676239014e-01
    z[6,3,4]  R1752     1.4628148078918457e-01
    z[6,3,4]  R1753     -4.4163670390844345e-02
    z[6,3,4]  R1754     2.9067862033843994e-01
    z[6,3,4]  R1755     -4.5216238498687744e-01
    z[6,3,4]  R1756     -0.154743030667305
    z[6,3,4]  R1757     -2.7844479680061340e-01
    z[6,3,4]  R1758     -1.9415840506553650e-01
    z[6,3,4]  R1759     1.0383749753236771e-01
    z[6,3,4]  R1760     1.2211102247238159e-01
    z[6,3,4]  R1761     -2.6020416617393494e-01
    z[6,3,4]  R1762     -5.8943405747413635e-02
    z[6,3,4]  R1763     -3.0825346708297729e-01
    z[6,3,4]  R1764     3.0930081382393837e-02
    z[6,3,4]  R1765     -1.2759761512279510e-01
    z[6,3,4]  R1766     -6.0336075723171234e-02
    z[6,3,4]  R1767     1.0239310562610626e-01
    z[6,3,4]  R1768     -8.9971348643302917e-03
    z[6,3,4]  R1769     -2.2755637764930725e-03
    z[6,3,4]  R1770     -2.7343245223164558e-02
    z[6,3,4]  R1771     2.0597030222415924e-01
    z[6,3,4]  R1772     -1.0387220233678818e-01
    z[6,3,4]  R1773     2.8337278962135315e-01
    z[6,3,4]  R1774     1.1322257667779922e-01
    z[6,3,4]  R1775     2.7698168158531189e-01
    z[6,3,4]  R1776     -5.7650644332170486e-02
    z[6,3,4]  R1777     -7.6792903244495392e-02
    z[6,3,4]  R1778     -6.1464175581932068e-02
    z[6,3,4]  R1779     -2.8007525205612183e-01
    z[6,3,4]  R1780     -1.7160907387733459e-01
    z[6,3,4]  R1781     -1.3729830272495747e-02
    z[6,3,4]  R1782     -1.3171419501304626e-01
    z[6,3,4]  R1783     1.7180059850215912e-01
    z[6,3,4]  R1784     -0.290390282869339
    z[6,3,4]  R1785     -1.2788760662078857e-01
    z[6,3,4]  R1786     3.1648221611976624e-01
    z[6,3,4]  R1787     2.4286733940243721e-02
    z[6,3,4]  R1788     -1.8562752008438110e-01
    z[6,3,4]  R1789     -8.5928475856781006e-01
    z[6,3,4]  R1790     3.1024357676506042e-01
    z[6,3,4]  R1791     -3.6562168598175049e-01
    z[6,3,4]  R1792     -1.3181759975850582e-02
    z[6,3,4]  R1793     2.3730356991291046e-01
    z[6,3,4]  R1794     4.6288302540779114e-01
    z[6,3,4]  R1795     -1.7594926059246063e-01
    z[6,3,4]  R1796     2.8487956523895264e-01
    z[6,3,4]  R1797     5.3741383552551270e-01
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1669     -1
    z[6,3,5]  R1670     1
    z[6,3,5]  R1673     1.8363554030656815e-02
    z[6,3,5]  R1674     -9.5805518329143524e-02
    z[6,3,5]  R1675     1.2756167352199554e-01
    z[6,3,5]  R1676     -5.5215455591678619e-02
    z[6,3,5]  R1677     1.4253821969032288e-01
    z[6,3,5]  R1678     1.5330988168716431e-01
    z[6,3,5]  R1679     -1.7740002274513245e-01
    z[6,3,5]  R1680     6.8646006286144257e-02
    z[6,3,5]  R1681     9.1301478445529938e-02
    z[6,3,5]  R1682     1.0748646408319473e-01
    z[6,3,5]  R1683     -6.3528245687484741e-01
    z[6,3,5]  R1684     -5.5146205425262451e-01
    z[6,3,5]  R1685     -1.5791727602481842e-01
    z[6,3,5]  R1686     1.1527353525161743e-01
    z[6,3,5]  R1687     -1.3519582152366638e-01
    z[6,3,5]  R1688     -4.2881774902343750e-01
    z[6,3,5]  R1689     -6.6672730445861816e-01
    z[6,3,5]  R1690     -3.4675487875938416e-01
    z[6,3,5]  R1691     -3.6504715681076050e-01
    z[6,3,5]  R1692     -6.0960131883621216e-01
    z[6,3,5]  R1693     -1.7386928200721741e-01
    z[6,3,5]  R1694     6.6571027040481567e-02
    z[6,3,5]  R1695     8.7013505399227142e-02
    z[6,3,5]  R1696     2.4824562668800354e-01
    z[6,3,5]  R1697     3.5148376226425171e-01
    z[6,3,5]  R1698     2.2151772677898407e-01
    z[6,3,5]  R1699     1.1689832806587219e-01
    z[6,3,5]  R1700     2.1122368052601814e-02
    z[6,3,5]  R1701     4.5777830481529236e-01
    z[6,3,5]  R1702     1.2328056618571281e-02
    z[6,3,5]  R1703     -0.448505699634552
    z[6,3,5]  R1704     -3.6816036701202393e-01
    z[6,3,5]  R1705     2.8279694914817810e-01
    z[6,3,5]  R1706     -5.4161384701728821e-02
    z[6,3,5]  R1707     1.2324440479278564e-01
    z[6,3,5]  R1708     -1.0633645206689835e-01
    z[6,3,5]  R1709     2.5598341599106789e-02
    z[6,3,5]  R1710     -2.3073397576808929e-02
    z[6,3,5]  R1711     -1.0603081434965134e-01
    z[6,3,5]  R1712     -6.0287380218505859e-01
    z[6,3,5]  R1713     -2.1796286106109619e-01
    z[6,3,5]  R1714     -1.5515540540218353e-01
    z[6,3,5]  R1715     -3.2942584156990051e-01
    z[6,3,5]  R1716     -2.4291633069515228e-01
    z[6,3,5]  R1717     -0.422921746969223
    z[6,3,5]  R1718     -4.3859258294105530e-01
    z[6,3,5]  R1719     -1.4036697149276733e-01
    z[6,3,5]  R1720     -1.4414627850055695e-01
    z[6,3,5]  R1721     -2.9180753231048584e-01
    z[6,3,5]  R1722     0.622606098651886
    z[6,3,5]  R1723     2.4356535077095032e-01
    z[6,3,5]  R1724     -3.0759337544441223e-01
    z[6,3,5]  R1725     -2.7960723638534546e-01
    z[6,3,5]  R1726     -0.421384334564209
    z[6,3,5]  R1727     -5.0109249353408813e-01
    z[6,3,5]  R1728     -6.7544782161712646e-01
    z[6,3,5]  R1729     5.5559748411178589e-01
    z[6,3,5]  R1730     3.2968875765800476e-01
    z[6,3,5]  R1731     4.8926264047622681e-02
    z[6,3,5]  R1732     1.0916931927204132e-01
    z[6,3,5]  R1733     -2.5254514813423157e-01
    z[6,3,5]  R1734     -6.4476072788238525e-01
    z[6,3,5]  R1735     3.6030894517898560e-01
    z[6,3,5]  R1736     -4.0189573168754578e-01
    z[6,3,5]  R1737     -2.4131463468074799e-01
    z[6,3,5]  R1738     -2.2471027076244354e-01
    z[6,3,5]  R1739     0.314242959022522
    z[6,3,5]  R1740     -3.2006821036338806e-01
    z[6,3,5]  R1741     -3.0427744984626770e-01
    z[6,3,5]  R1742     1.2288712710142136e-01
    z[6,3,5]  R1743     9.0067885816097260e-02
    z[6,3,5]  R1744     -4.1855999827384949e-01
    z[6,3,5]  R1745     -5.1251932978630066e-02
    z[6,3,5]  R1746     -3.1081253290176392e-01
    z[6,3,5]  R1747     -4.3841204047203064e-01
    z[6,3,5]  R1748     -4.6696880459785461e-01
    z[6,3,5]  R1749     -7.8776758909225464e-01
    z[6,3,5]  R1750     -0.0409141406416893
    z[6,3,5]  R1751     -4.1150298714637756e-01
    z[6,3,5]  R1752     -4.4737223535776138e-02
    z[6,3,5]  R1753     -2.4522005021572113e-01
    z[6,3,5]  R1754     -4.9179011583328247e-01
    z[6,3,5]  R1755     -4.9940440058708191e-01
    z[6,3,5]  R1756     -7.4444037675857544e-01
    z[6,3,5]  R1757     1.4940799772739410e-01
    z[6,3,5]  R1758     2.4619838595390320e-01
    z[6,3,5]  R1759     -1.0064287483692169e-01
    z[6,3,5]  R1760     4.2561632394790649e-01
    z[6,3,5]  R1761     9.8149076104164124e-02
    z[6,3,5]  R1762     1.9988100230693817e-01
    z[6,3,5]  R1763     -2.0188757777214050e-01
    z[6,3,5]  R1764     1.4005610346794128e-01
    z[6,3,5]  R1765     -0.479707807302475
    z[6,3,5]  R1766     -8.0626225471496582e-01
    z[6,3,5]  R1767     -1.2126793712377548e-01
    z[6,3,5]  R1768     1.4181299507617950e-01
    z[6,3,5]  R1769     1.1308369040489197e-01
    z[6,3,5]  R1770     4.5485013723373413e-01
    z[6,3,5]  R1771     -2.9244298115372658e-02
    z[6,3,5]  R1772     1.4941900968551636e-01
    z[6,3,5]  R1773     -2.0874448120594025e-01
    z[6,3,5]  R1774     -7.2684699296951294e-01
    z[6,3,5]  R1775     -3.9484921097755432e-01
    z[6,3,5]  R1776     -1.2284660339355469e-01
    z[6,3,5]  R1777     1.7613308131694794e-01
    z[6,3,5]  R1778     -1.5199208259582520e-01
    z[6,3,5]  R1779     -0.0385298952460289
    z[6,3,5]  R1780     -3.2177552580833435e-02
    z[6,3,5]  R1781     -2.9607942700386047e-01
    z[6,3,5]  R1782     -3.6532118916511536e-01
    z[6,3,5]  R1783     -6.1394846439361572e-01
    z[6,3,5]  R1784     2.0823361352086067e-02
    z[6,3,5]  R1785     -1.9786822795867920e-01
    z[6,3,5]  R1786     -3.6314314603805542e-01
    z[6,3,5]  R1787     -3.8083171844482422e-01
    z[6,3,5]  R1788     1.3971579074859619e-01
    z[6,3,5]  R1789     2.1009135246276855e-01
    z[6,3,5]  R1790     -4.3233373761177063e-01
    z[6,3,5]  R1791     -1.3284134864807129e-01
    z[6,3,5]  R1792     2.7037004474550486e-03
    z[6,3,5]  R1793     0.0669000968337059
    z[6,3,5]  R1794     5.3333175182342529e-01
    z[6,3,5]  R1795     -5.1613062620162964e-01
    z[6,3,5]  R1796     3.9667895436286926e-01
    z[6,3,5]  R1797     4.8298445343971252e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1671     -1
    z[6,3,6]  R1672     1
    z[6,3,6]  R1673     -1.1770492047071457e-01
    z[6,3,6]  R1674     -4.4261552393436432e-03
    z[6,3,6]  R1675     -1.6064360737800598e-01
    z[6,3,6]  R1676     -1.6098898649215698e-01
    z[6,3,6]  R1677     -0.301470011472702
    z[6,3,6]  R1678     1.6815978288650513e-01
    z[6,3,6]  R1679     -1.2203180789947510e-01
    z[6,3,6]  R1680     1.4321976900100708e-01
    z[6,3,6]  R1681     -1.0164518840610981e-02
    z[6,3,6]  R1682     2.7247878909111023e-01
    z[6,3,6]  R1683     1.8773525953292847e-01
    z[6,3,6]  R1684     -2.3031197488307953e-01
    z[6,3,6]  R1685     3.7443738430738449e-02
    z[6,3,6]  R1686     -5.8671992272138596e-02
    z[6,3,6]  R1687     -4.4896829128265381e-01
    z[6,3,6]  R1688     0.0770488902926445
    z[6,3,6]  R1689     -2.5659623742103577e-01
    z[6,3,6]  R1690     -7.1774378418922424e-02
    z[6,3,6]  R1691     3.3430272340774536e-01
    z[6,3,6]  R1692     2.6974827051162720e-02
    z[6,3,6]  R1693     -6.8659879267215729e-02
    z[6,3,6]  R1694     8.4615841507911682e-02
    z[6,3,6]  R1695     9.7019389271736145e-02
    z[6,3,6]  R1696     3.8433033227920532e-01
    z[6,3,6]  R1697     -6.3249057531356812e-01
    z[6,3,6]  R1698     -2.1371269226074219e-01
    z[6,3,6]  R1699     -4.1133394837379456e-01
    z[6,3,6]  R1700     -0.0805663913488388
    z[6,3,6]  R1701     1.8261478841304779e-01
    z[6,3,6]  R1702     -2.9590731486678123e-02
    z[6,3,6]  R1703     -9.6845522522926331e-02
    z[6,3,6]  R1704     2.0080134272575378e-01
    z[6,3,6]  R1705     -2.0039488375186920e-01
    z[6,3,6]  R1706     3.6406585574150085e-01
    z[6,3,6]  R1707     -2.0754756033420563e-01
    z[6,3,6]  R1708     0.0768914446234703
    z[6,3,6]  R1709     1.9086304306983948e-01
    z[6,3,6]  R1710     2.0770902931690216e-01
    z[6,3,6]  R1711     4.1985239833593369e-02
    z[6,3,6]  R1712     -2.1316848695278168e-01
    z[6,3,6]  R1713     -7.0847973227500916e-02
    z[6,3,6]  R1714     1.4123211801052094e-01
    z[6,3,6]  R1715     -7.8969992697238922e-02
    z[6,3,6]  R1716     -1.1099644750356674e-01
    z[6,3,6]  R1717     -1.9904676079750061e-01
    z[6,3,6]  R1718     -2.7316769957542419e-01
    z[6,3,6]  R1719     3.7511962652206421e-01
    z[6,3,6]  R1720     -2.7071639895439148e-01
    z[6,3,6]  R1721     0.0816039890050888
    z[6,3,6]  R1722     1.1319984495639801e-01
    z[6,3,6]  R1723     2.7768164873123169e-01
    z[6,3,6]  R1724     6.2627747654914856e-02
    z[6,3,6]  R1725     -0.0424545481801033
    z[6,3,6]  R1726     -4.8246022313833237e-02
    z[6,3,6]  R1727     -1.7423997819423676e-01
    z[6,3,6]  R1728     -2.3064975440502167e-01
    z[6,3,6]  R1729     -2.5198507308959961e-01
    z[6,3,6]  R1730     -2.8632849454879761e-01
    z[6,3,6]  R1731     -1.7734473943710327e-01
    z[6,3,6]  R1732     0.0823395624756813
    z[6,3,6]  R1733     -2.5365290045738220e-01
    z[6,3,6]  R1734     5.3452465683221817e-02
    z[6,3,6]  R1735     1.7981614917516708e-02
    z[6,3,6]  R1736     8.4437653422355652e-02
    z[6,3,6]  R1737     1.7719270288944244e-01
    z[6,3,6]  R1738     -4.9363183975219727e-01
    z[6,3,6]  R1739     1.7795109748840332e-01
    z[6,3,6]  R1740     -6.2378573417663574e-01
    z[6,3,6]  R1741     -2.1367833018302917e-01
    z[6,3,6]  R1742     1.7445491254329681e-01
    z[6,3,6]  R1743     1.5673954784870148e-01
    z[6,3,6]  R1744     -0.282549113035202
    z[6,3,6]  R1745     -9.0264402329921722e-02
    z[6,3,6]  R1746     2.8157643973827362e-03
    z[6,3,6]  R1747     -6.1274436302483082e-03
    z[6,3,6]  R1748     2.0600537955760956e-01
    z[6,3,6]  R1749     1.3947731256484985e-01
    z[6,3,6]  R1750     1.3983491063117981e-01
    z[6,3,6]  R1751     -2.2028565406799316e-01
    z[6,3,6]  R1752     1.3029728829860687e-01
    z[6,3,6]  R1753     -2.9339674860239029e-02
    z[6,3,6]  R1754     -1.4245378971099854e-01
    z[6,3,6]  R1755     -0.257985919713974
    z[6,3,6]  R1756     -2.4304588139057159e-01
    z[6,3,6]  R1757     -5.2570408582687378e-01
    z[6,3,6]  R1758     3.2696448266506195e-02
    z[6,3,6]  R1759     -3.7743654102087021e-02
    z[6,3,6]  R1760     -0.148038849234581
    z[6,3,6]  R1761     -2.4738231301307678e-01
    z[6,3,6]  R1762     -2.0432794094085693e-01
    z[6,3,6]  R1763     -1.5077529847621918e-01
    z[6,3,6]  R1764     -1.4350248873233795e-01
    z[6,3,6]  R1765     1.1306065320968628e-01
    z[6,3,6]  R1766     1.0979101061820984e-01
    z[6,3,6]  R1767     3.0902945995330811e-01
    z[6,3,6]  R1768     0.0984988585114479
    z[6,3,6]  R1769     -3.4991574287414551e-01
    z[6,3,6]  R1770     -1.4413505792617798e-01
    z[6,3,6]  R1771     2.2152608260512352e-02
    z[6,3,6]  R1772     -7.0057488977909088e-02
    z[6,3,6]  R1773     1.2082371860742569e-01
    z[6,3,6]  R1774     7.4731156229972839e-02
    z[6,3,6]  R1775     0.2565937936306
    z[6,3,6]  R1776     2.3028762638568878e-01
    z[6,3,6]  R1777     -2.3457955569028854e-02
    z[6,3,6]  R1778     1.1988984793424606e-01
    z[6,3,6]  R1779     1.9500355422496796e-01
    z[6,3,6]  R1780     5.0898820161819458e-01
    z[6,3,6]  R1781     4.6658405661582947e-01
    z[6,3,6]  R1782     1.8439665436744690e-01
    z[6,3,6]  R1783     8.6160756647586823e-02
    z[6,3,6]  R1784     1.6605402529239655e-01
    z[6,3,6]  R1785     -2.0802492275834084e-02
    z[6,3,6]  R1786     -2.6933647692203522e-02
    z[6,3,6]  R1787     3.9008951187133789e-01
    z[6,3,6]  R1788     -3.8659039884805679e-02
    z[6,3,6]  R1789     2.8735810518264771e-01
    z[6,3,6]  R1790     -6.3604766130447388e-01
    z[6,3,6]  R1791     -1.3491220772266388e-01
    z[6,3,6]  R1792     -3.0646494030952454e-01
    z[6,3,6]  R1793     -2.3540496826171875e-01
    z[6,3,6]  R1794     2.9689380899071693e-02
    z[6,3,6]  R1795     2.5936502218246460e-01
    z[6,3,6]  R1796     4.7487938404083252e-01
    z[6,3,6]  R1797     3.8391733169555664e-01
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1798     -1
    z[3,7,0]  R1799     1
    z[3,7,0]  R1812     -4.3774202822532970e-06
    z[3,7,0]  R1813     -5.0196421146392822e-01
    z[3,7,0]  R1814     9.2960394918918610e-02
    z[3,7,0]  R1815     -5.4913395643234253e-01
    z[3,7,0]  R1816     -4.6438139677047729e-01
    z[3,7,0]  R1817     -3.6235442757606506e-01
    z[3,7,0]  R1818     1.7734211683273315e-01
    z[3,7,0]  R1819     1.1243292689323425e-01
    z[3,7,0]  R1820     -5.2351492643356323e-01
    z[3,7,0]  R1821     3.2991003245115280e-03
    z[3,7,0]  R1822     3.1800916790962219e-01
    z[3,7,0]  R1823     3.3361810445785522e-01
    z[3,7,0]  R1824     3.0185526609420776e-01
    z[3,7,0]  R1825     3.6144572496414185e-01
    z[3,7,0]  R1826     1.7125104367733002e-01
    z[3,7,0]  R1827     -9.5497183501720428e-02
    z[3,7,0]  R1828     3.0647508800029755e-02
    z[3,7,0]  R1829     -6.5438938140869141e-01
    z[3,7,0]  R1830     1.0101261734962463e-01
    z[3,7,0]  R1831     3.2455902546644211e-02
    z[3,7,0]  R1832     -2.4471038579940796e-01
    z[3,7,0]  R1833     -4.3175509572029114e-01
    z[3,7,0]  R1834     -1.8281176686286926e-01
    z[3,7,0]  R1835     -1.3119821250438690e-01
    z[3,7,0]  R1836     -3.5663988441228867e-02
    z[3,7,0]  R1837     3.1553596258163452e-01
    z[3,7,0]  R1838     4.3720972537994385e-01
    z[3,7,0]  R1839     3.4140643477439880e-01
    z[3,7,0]  R1840     4.8278063535690308e-01
    z[3,7,0]  R1841     5.6979817152023315e-01
    z[3,7,0]  R1842     -6.2885993719100952e-01
    z[3,7,0]  R1843     -7.5865501165390015e-01
    z[3,7,0]  R1844     -5.0260728597640991e-01
    z[3,7,0]  R1845     8.9063942432403564e-02
    z[3,7,0]  R1846     6.8356573581695557e-01
    z[3,7,0]  R1847     1.5766522288322449e-01
    z[3,7,0]  R1848     6.4233458042144775e-01
    z[3,7,0]  R1849     4.1580140590667725e-01
    z[3,7,0]  R1850     5.6499028205871582e-01
    z[3,7,0]  R1851     0.414422869682312
    z[3,7,0]  R1852     1.7025206238031387e-02
    z[3,7,0]  R1853     4.7953811287879944e-01
    z[3,7,0]  R1854     4.0981176495552063e-01
    z[3,7,0]  R1855     -2.5155130028724670e-01
    z[3,7,0]  R1856     -1.0096784681081772e-01
    z[3,7,0]  R1857     -1.2372843176126480e-01
    z[3,7,0]  R1858     -7.0284180343151093e-02
    z[3,7,0]  R1859     4.9607205390930176e-01
    z[3,7,0]  R1860     1.1852400004863739e-01
    z[3,7,0]  R1861     -1.3189294934272766e-01
    z[3,7,0]  R1862     2.2762393951416016e-01
    z[3,7,0]  R1863     1.8111190199851990e-01
    z[3,7,0]  R1864     -8.5589081048965454e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1800     -1
    z[3,7,1]  R1801     1
    z[3,7,1]  R1812     1.1947839707136154e-01
    z[3,7,1]  R1813     -0.65839684009552
    z[3,7,1]  R1814     -0.691955029964447
    z[3,7,1]  R1815     -5.5208396911621094e-01
    z[3,7,1]  R1816     -0.626633882522583
    z[3,7,1]  R1817     -4.1933557391166687e-01
    z[3,7,1]  R1818     0.064608134329319
    z[3,7,1]  R1819     -3.9330857992172241e-01
    z[3,7,1]  R1820     -0.666795015335083
    z[3,7,1]  R1821     -4.9973803758621216e-01
    z[3,7,1]  R1822     0.822810173034668
    z[3,7,1]  R1823     6.9742277264595032e-02
    z[3,7,1]  R1824     4.6270421147346497e-01
    z[3,7,1]  R1825     -0.0831177830696106
    z[3,7,1]  R1826     -5.0423705577850342e-01
    z[3,7,1]  R1827     -3.4604340791702271e-01
    z[3,7,1]  R1828     -3.2077878713607788e-01
    z[3,7,1]  R1829     -4.2159634828567505e-01
    z[3,7,1]  R1830     -3.9484176039695740e-01
    z[3,7,1]  R1831     -3.1864890456199646e-01
    z[3,7,1]  R1832     -2.7003687620162964e-01
    z[3,7,1]  R1833     -5.0405979156494141e-01
    z[3,7,1]  R1834     7.4345552921295166e-01
    z[3,7,1]  R1835     6.9006556272506714e-01
    z[3,7,1]  R1836     3.8838860392570496e-01
    z[3,7,1]  R1837     4.5317673683166504e-01
    z[3,7,1]  R1838     3.0732971429824829e-01
    z[3,7,1]  R1839     5.2750808000564575e-01
    z[3,7,1]  R1840     6.0210186243057251e-01
    z[3,7,1]  R1841     4.3000218272209167e-01
    z[3,7,1]  R1842     3.1987950205802917e-01
    z[3,7,1]  R1843     3.3580586314201355e-01
    z[3,7,1]  R1844     2.4285274744033813e-01
    z[3,7,1]  R1845     -4.6651086211204529e-01
    z[3,7,1]  R1846     -0.539271891117096
    z[3,7,1]  R1847     -1.4057770371437073e-01
    z[3,7,1]  R1848     0.567960798740387
    z[3,7,1]  R1849     -0.228984072804451
    z[3,7,1]  R1850     7.9121059179306030e-01
    z[3,7,1]  R1851     5.5430847406387329e-01
    z[3,7,1]  R1852     5.5086892843246460e-01
    z[3,7,1]  R1853     6.2954002618789673e-01
    z[3,7,1]  R1854     5.6699329614639282e-01
    z[3,7,1]  R1855     2.1715676784515381e-01
    z[3,7,1]  R1856     3.0918952822685242e-01
    z[3,7,1]  R1857     -4.7771230340003967e-01
    z[3,7,1]  R1858     6.6895473003387451e-01
    z[3,7,1]  R1859     7.5023949146270752e-01
    z[3,7,1]  R1860     8.2526785135269165e-01
    z[3,7,1]  R1861     1.5270633995532990e-01
    z[3,7,1]  R1862     8.2591497898101807e-01
    z[3,7,1]  R1863     3.5667210817337036e-01
    z[3,7,1]  R1864     1.1318787187337875e-01
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1802     -1
    z[3,7,2]  R1803     1
    z[3,7,2]  R1812     -5.0464099645614624e-01
    z[3,7,2]  R1813     -4.3756082653999329e-01
    z[3,7,2]  R1814     -4.2218956351280212e-01
    z[3,7,2]  R1815     -3.9870855212211609e-01
    z[3,7,2]  R1816     -2.4444781243801117e-01
    z[3,7,2]  R1817     -7.1697455644607544e-01
    z[3,7,2]  R1818     -4.2742338031530380e-02
    z[3,7,2]  R1819     2.9280850291252136e-01
    z[3,7,2]  R1820     -3.2561093568801880e-01
    z[3,7,2]  R1821     7.9545283317565918e-01
    z[3,7,2]  R1822     3.1671860814094543e-01
    z[3,7,2]  R1823     1.6957861185073853e-01
    z[3,7,2]  R1824     3.2461118698120117e-01
    z[3,7,2]  R1825     2.1251462399959564e-01
    z[3,7,2]  R1826     4.9290871247649193e-03
    z[3,7,2]  R1827     -2.1354725956916809e-01
    z[3,7,2]  R1828     3.7155240774154663e-01
    z[3,7,2]  R1829     0.336379736661911
    z[3,7,2]  R1830     1.4622454345226288e-01
    z[3,7,2]  R1831     2.6254877448081970e-01
    z[3,7,2]  R1832     5.0766289234161377e-01
    z[3,7,2]  R1833     2.3617684841156006e-01
    z[3,7,2]  R1834     5.2378600835800171e-01
    z[3,7,2]  R1835     5.5961215496063232e-01
    z[3,7,2]  R1836     5.8387947082519531e-01
    z[3,7,2]  R1837     1.4334578812122345e-01
    z[3,7,2]  R1838     9.1534264385700226e-02
    z[3,7,2]  R1839     2.4795642122626305e-02
    z[3,7,2]  R1840     -1.6446989774703979e-01
    z[3,7,2]  R1841     -3.1073245406150818e-01
    z[3,7,2]  R1842     -6.8830925226211548e-01
    z[3,7,2]  R1843     -3.5474994778633118e-01
    z[3,7,2]  R1844     -6.5949332714080811e-01
    z[3,7,2]  R1845     6.3296836614608765e-01
    z[3,7,2]  R1846     -5.7502470910549164e-02
    z[3,7,2]  R1847     -1.7588475719094276e-02
    z[3,7,2]  R1848     -1.5407618880271912e-01
    z[3,7,2]  R1849     -3.3088666200637817e-01
    z[3,7,2]  R1850     4.6474966220557690e-03
    z[3,7,2]  R1851     1.6201306879520416e-01
    z[3,7,2]  R1852     0.319915235042572
    z[3,7,2]  R1853     -2.0948900282382965e-01
    z[3,7,2]  R1854     -1.2064448557794094e-02
    z[3,7,2]  R1855     6.1238389462232590e-02
    z[3,7,2]  R1856     6.6069457679986954e-03
    z[3,7,2]  R1857     -1.0454404167830944e-02
    z[3,7,2]  R1858     4.7001782059669495e-01
    z[3,7,2]  R1859     4.0012022852897644e-01
    z[3,7,2]  R1860     2.1673339605331421e-01
    z[3,7,2]  R1861     3.2546713948249817e-01
    z[3,7,2]  R1862     3.2212135195732117e-01
    z[3,7,2]  R1863     2.7594748139381409e-01
    z[3,7,2]  R1864     -4.1854715347290039e-01
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1804     -1
    z[3,7,3]  R1805     1
    z[3,7,3]  R1812     5.6319665908813477e-01
    z[3,7,3]  R1813     -1.0369183868169785e-01
    z[3,7,3]  R1814     -5.2761048078536987e-01
    z[3,7,3]  R1815     -4.3900772929191589e-02
    z[3,7,3]  R1816     1.8475079536437988e-01
    z[3,7,3]  R1817     3.5118627548217773e-01
    z[3,7,3]  R1818     3.1219440698623657e-01
    z[3,7,3]  R1819     -2.4333126842975616e-01
    z[3,7,3]  R1820     7.5939163565635681e-02
    z[3,7,3]  R1821     -1.5298357605934143e-01
    z[3,7,3]  R1822     7.3067627847194672e-02
    z[3,7,3]  R1823     5.9623247385025024e-01
    z[3,7,3]  R1824     -4.7412705421447754e-01
    z[3,7,3]  R1825     -0.594360888004303
    z[3,7,3]  R1826     -2.1659563481807709e-01
    z[3,7,3]  R1827     8.2620793581008911e-01
    z[3,7,3]  R1828     -1.2785139679908752e-01
    z[3,7,3]  R1829     -3.4935075044631958e-01
    z[3,7,3]  R1830     -2.9280295968055725e-01
    z[3,7,3]  R1831     -2.8917145729064941e-01
    z[3,7,3]  R1832     -3.9025139808654785e-01
    z[3,7,3]  R1833     1.1600656062364578e-01
    z[3,7,3]  R1834     1.1536002904176712e-01
    z[3,7,3]  R1835     1.1884523183107376e-01
    z[3,7,3]  R1836     2.1242666244506836e-01
    z[3,7,3]  R1837     4.3413969874382019e-01
    z[3,7,3]  R1838     3.3604815602302551e-01
    z[3,7,3]  R1839     9.0555511415004730e-02
    z[3,7,3]  R1840     -1.8992717564105988e-01
    z[3,7,3]  R1841     1.6848176717758179e-01
    z[3,7,3]  R1842     -1.2528951466083527e-01
    z[3,7,3]  R1843     4.6882618218660355e-02
    z[3,7,3]  R1844     -1.0609063506126404e-01
    z[3,7,3]  R1845     -3.6784434318542480e-01
    z[3,7,3]  R1846     -2.0180073380470276e-01
    z[3,7,3]  R1847     -9.5994293689727783e-01
    z[3,7,3]  R1848     3.4489190578460693e-01
    z[3,7,3]  R1849     0.0662183165550232
    z[3,7,3]  R1850     5.9517048299312592e-02
    z[3,7,3]  R1851     3.3371126651763916e-01
    z[3,7,3]  R1852     3.9141643047332764e-01
    z[3,7,3]  R1853     2.3797918856143951e-01
    z[3,7,3]  R1854     2.6741623878479004e-01
    z[3,7,3]  R1855     3.1077753752470016e-02
    z[3,7,3]  R1856     -1.4447696506977081e-01
    z[3,7,3]  R1857     -3.1387850642204285e-01
    z[3,7,3]  R1858     3.9956855773925781e-01
    z[3,7,3]  R1859     1.7371344566345215e-01
    z[3,7,3]  R1860     3.0642119050025940e-01
    z[3,7,3]  R1861     3.9904779195785522e-01
    z[3,7,3]  R1862     4.9581699073314667e-02
    z[3,7,3]  R1863     5.8728528022766113e-01
    z[3,7,3]  R1864     -4.5279961079359055e-02
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1806     -1
    z[3,7,4]  R1807     1
    z[3,7,4]  R1812     1.7180059850215912e-01
    z[3,7,4]  R1813     -0.290390282869339
    z[3,7,4]  R1814     -1.2788760662078857e-01
    z[3,7,4]  R1815     3.1648221611976624e-01
    z[3,7,4]  R1816     2.4286733940243721e-02
    z[3,7,4]  R1817     -1.8562752008438110e-01
    z[3,7,4]  R1818     -8.5928475856781006e-01
    z[3,7,4]  R1819     3.1024357676506042e-01
    z[3,7,4]  R1820     -3.6562168598175049e-01
    z[3,7,4]  R1821     -1.3181759975850582e-02
    z[3,7,4]  R1822     2.3730356991291046e-01
    z[3,7,4]  R1823     4.6288302540779114e-01
    z[3,7,4]  R1824     -1.7594926059246063e-01
    z[3,7,4]  R1825     2.8487956523895264e-01
    z[3,7,4]  R1826     5.3741383552551270e-01
    z[3,7,4]  R1827     -3.1051984429359436e-01
    z[3,7,4]  R1828     6.0188418626785278e-01
    z[3,7,4]  R1829     -1.4745886623859406e-01
    z[3,7,4]  R1830     -4.6099311113357544e-01
    z[3,7,4]  R1831     6.8539303541183472e-01
    z[3,7,4]  R1832     1.8325036764144897e-01
    z[3,7,4]  R1833     6.8210393190383911e-01
    z[3,7,4]  R1834     -2.5741992518305779e-02
    z[3,7,4]  R1835     1.1290936172008514e-01
    z[3,7,4]  R1836     -0.592860758304596
    z[3,7,4]  R1837     2.8637340664863586e-01
    z[3,7,4]  R1838     1.8847092986106873e-01
    z[3,7,4]  R1839     -5.0618678331375122e-01
    z[3,7,4]  R1840     -5.3477054834365845e-01
    z[3,7,4]  R1841     2.1060076355934143e-01
    z[3,7,4]  R1842     7.1448874659836292e-03
    z[3,7,4]  R1843     -3.9999313652515411e-02
    z[3,7,4]  R1844     3.6102943122386932e-02
    z[3,7,4]  R1845     1.8114270269870758e-01
    z[3,7,4]  R1846     2.2137662768363953e-01
    z[3,7,4]  R1847     -1.6119654476642609e-01
    z[3,7,4]  R1848     7.2562344372272491e-02
    z[3,7,4]  R1849     7.1863633394241333e-01
    z[3,7,4]  R1850     1.9115528464317322e-01
    z[3,7,4]  R1851     5.5096572637557983e-01
    z[3,7,4]  R1852     -4.3163388967514038e-01
    z[3,7,4]  R1853     -1.8582014739513397e-01
    z[3,7,4]  R1854     -4.3526330590248108e-01
    z[3,7,4]  R1855     9.7522474825382233e-02
    z[3,7,4]  R1856     -0.558796226978302
    z[3,7,4]  R1857     -3.6174062639474869e-02
    z[3,7,4]  R1858     3.4133863449096680e-01
    z[3,7,4]  R1859     2.3872828111052513e-02
    z[3,7,4]  R1860     -1.8965993821620941e-01
    z[3,7,4]  R1861     3.4512110054492950e-02
    z[3,7,4]  R1862     2.4022670090198517e-01
    z[3,7,4]  R1863     9.3611087650060654e-03
    z[3,7,4]  R1864     1.6803732514381409e-01
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1808     -1
    z[3,7,5]  R1809     1
    z[3,7,5]  R1812     -6.1394846439361572e-01
    z[3,7,5]  R1813     2.0823361352086067e-02
    z[3,7,5]  R1814     -1.9786822795867920e-01
    z[3,7,5]  R1815     -3.6314314603805542e-01
    z[3,7,5]  R1816     -3.8083171844482422e-01
    z[3,7,5]  R1817     1.3971579074859619e-01
    z[3,7,5]  R1818     2.1009135246276855e-01
    z[3,7,5]  R1819     -4.3233373761177063e-01
    z[3,7,5]  R1820     -1.3284134864807129e-01
    z[3,7,5]  R1821     2.7037004474550486e-03
    z[3,7,5]  R1822     0.0669000968337059
    z[3,7,5]  R1823     5.3333175182342529e-01
    z[3,7,5]  R1824     -5.1613062620162964e-01
    z[3,7,5]  R1825     3.9667895436286926e-01
    z[3,7,5]  R1826     4.8298445343971252e-01
    z[3,7,5]  R1827     -1.9773536920547485e-01
    z[3,7,5]  R1828     -4.3851515650749207e-01
    z[3,7,5]  R1829     -2.9622310400009155e-01
    z[3,7,5]  R1830     -0.588651180267334
    z[3,7,5]  R1831     4.7824871540069580e-01
    z[3,7,5]  R1832     2.8403592109680176e-01
    z[3,7,5]  R1833     -1.5754656493663788e-01
    z[3,7,5]  R1834     -2.9139408469200134e-01
    z[3,7,5]  R1835     2.2504577040672302e-01
    z[3,7,5]  R1836     -0.0945129320025444
    z[3,7,5]  R1837     2.0391296595335007e-02
    z[3,7,5]  R1838     5.7642799615859985e-01
    z[3,7,5]  R1839     4.6518808603286743e-01
    z[3,7,5]  R1840     2.3237279057502747e-01
    z[3,7,5]  R1841     -5.5580466985702515e-01
    z[3,7,5]  R1842     0.0278362687677145
    z[3,7,5]  R1843     2.2809931635856628e-01
    z[3,7,5]  R1844     2.1465249359607697e-01
    z[3,7,5]  R1845     -4.1360697150230408e-01
    z[3,7,5]  R1846     2.0990513265132904e-01
    z[3,7,5]  R1847     7.3872774839401245e-02
    z[3,7,5]  R1848     9.8390288650989532e-02
    z[3,7,5]  R1849     -3.4756880998611450e-01
    z[3,7,5]  R1850     -7.5938858091831207e-02
    z[3,7,5]  R1851     9.4430379569530487e-02
    z[3,7,5]  R1852     4.3317312002182007e-01
    z[3,7,5]  R1853     -4.4979268312454224e-01
    z[3,7,5]  R1854     4.5299929380416870e-01
    z[3,7,5]  R1855     -9.2040526866912842e-01
    z[3,7,5]  R1856     -3.4115061163902283e-01
    z[3,7,5]  R1857     4.6103116869926453e-01
    z[3,7,5]  R1858     -2.2435872256755829e-01
    z[3,7,5]  R1859     1.6398425941588357e-05
    z[3,7,5]  R1860     -3.3011871576309204e-01
    z[3,7,5]  R1861     2.0022456347942352e-01
    z[3,7,5]  R1862     2.5162905454635620e-02
    z[3,7,5]  R1863     5.9163635969161987e-01
    z[3,7,5]  R1864     2.0850417017936707e-01
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1810     -1
    z[3,7,6]  R1811     1
    z[3,7,6]  R1812     8.6160756647586823e-02
    z[3,7,6]  R1813     1.6605402529239655e-01
    z[3,7,6]  R1814     -2.0802492275834084e-02
    z[3,7,6]  R1815     -2.6933647692203522e-02
    z[3,7,6]  R1816     3.9008951187133789e-01
    z[3,7,6]  R1817     -3.8659039884805679e-02
    z[3,7,6]  R1818     2.8735810518264771e-01
    z[3,7,6]  R1819     -6.3604766130447388e-01
    z[3,7,6]  R1820     -1.3491220772266388e-01
    z[3,7,6]  R1821     -3.0646494030952454e-01
    z[3,7,6]  R1822     -2.3540496826171875e-01
    z[3,7,6]  R1823     2.9689380899071693e-02
    z[3,7,6]  R1824     2.5936502218246460e-01
    z[3,7,6]  R1825     4.7487938404083252e-01
    z[3,7,6]  R1826     3.8391733169555664e-01
    z[3,7,6]  R1827     8.5967361927032471e-02
    z[3,7,6]  R1828     4.3267118930816650e-01
    z[3,7,6]  R1829     2.2212950885295868e-01
    z[3,7,6]  R1830     -4.0958082675933838e-01
    z[3,7,6]  R1831     2.1534173190593719e-01
    z[3,7,6]  R1832     0.585595428943634
    z[3,7,6]  R1833     -1.3694108463823795e-02
    z[3,7,6]  R1834     2.0154589414596558e-01
    z[3,7,6]  R1835     3.4045910835266113e-01
    z[3,7,6]  R1836     -3.1847360730171204e-01
    z[3,7,6]  R1837     -6.3530862331390381e-01
    z[3,7,6]  R1838     -4.7465628385543823e-01
    z[3,7,6]  R1839     -3.5176226496696472e-01
    z[3,7,6]  R1840     3.6010544747114182e-02
    z[3,7,6]  R1841     -1.1052598804235458e-01
    z[3,7,6]  R1842     -1.0917614400386810e-01
    z[3,7,6]  R1843     -3.6055833101272583e-01
    z[3,7,6]  R1844     4.4140985608100891e-01
    z[3,7,6]  R1845     -1.8599297106266022e-01
    z[3,7,6]  R1846     3.2376810908317566e-01
    z[3,7,6]  R1847     4.6240020543336868e-02
    z[3,7,6]  R1848     3.2740023732185364e-01
    z[3,7,6]  R1849     -1.5350070595741272e-01
    z[3,7,6]  R1850     9.4344235956668854e-02
    z[3,7,6]  R1851     2.6627802848815918e-01
    z[3,7,6]  R1852     -2.5836843252182007e-01
    z[3,7,6]  R1853     -1.9068348407745361e-01
    z[3,7,6]  R1854     2.1036484837532043e-01
    z[3,7,6]  R1855     1.6790562868118286e-01
    z[3,7,6]  R1856     -6.6682326793670654e-01
    z[3,7,6]  R1857     -6.6632938385009766e-01
    z[3,7,6]  R1858     -1.1788893491029739e-02
    z[3,7,6]  R1859     -1.4518619515001774e-02
    z[3,7,6]  R1860     -1.3808824121952057e-01
    z[3,7,6]  R1861     -8.0798274278640747e-01
    z[3,7,6]  R1862     0.318573534488678
    z[3,7,6]  R1863     -2.6231896877288818e-01
    z[3,7,6]  R1864     7.5478866696357727e-02
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1865     -1
    z[7,3,0]  R1866     1
    z[7,3,0]  R1879     -9.5497183501720428e-02
    z[7,3,0]  R1880     3.0647508800029755e-02
    z[7,3,0]  R1881     -6.5438938140869141e-01
    z[7,3,0]  R1882     1.0101261734962463e-01
    z[7,3,0]  R1883     3.2455902546644211e-02
    z[7,3,0]  R1884     -2.4471038579940796e-01
    z[7,3,0]  R1885     -4.3175509572029114e-01
    z[7,3,0]  R1886     -1.8281176686286926e-01
    z[7,3,0]  R1887     -1.3119821250438690e-01
    z[7,3,0]  R1888     -3.5663988441228867e-02
    z[7,3,0]  R1889     3.1553596258163452e-01
    z[7,3,0]  R1890     4.3720972537994385e-01
    z[7,3,0]  R1891     3.4140643477439880e-01
    z[7,3,0]  R1892     4.8278063535690308e-01
    z[7,3,0]  R1893     5.6979817152023315e-01
    z[7,3,0]  R1894     -6.2885993719100952e-01
    z[7,3,0]  R1895     -7.5865501165390015e-01
    z[7,3,0]  R1896     -5.0260728597640991e-01
    z[7,3,0]  R1897     8.9063942432403564e-02
    z[7,3,0]  R1898     6.8356573581695557e-01
    z[7,3,0]  R1899     1.5766522288322449e-01
    z[7,3,0]  R1900     6.4233458042144775e-01
    z[7,3,0]  R1901     4.1580140590667725e-01
    z[7,3,0]  R1902     5.6499028205871582e-01
    z[7,3,0]  R1903     0.414422869682312
    z[7,3,0]  R1904     1.7025206238031387e-02
    z[7,3,0]  R1905     4.7953811287879944e-01
    z[7,3,0]  R1906     4.0981176495552063e-01
    z[7,3,0]  R1907     -2.5155130028724670e-01
    z[7,3,0]  R1908     -1.0096784681081772e-01
    z[7,3,0]  R1909     -1.2372843176126480e-01
    z[7,3,0]  R1910     -7.0284180343151093e-02
    z[7,3,0]  R1911     4.9607205390930176e-01
    z[7,3,0]  R1912     1.1852400004863739e-01
    z[7,3,0]  R1913     -1.3189294934272766e-01
    z[7,3,0]  R1914     2.2762393951416016e-01
    z[7,3,0]  R1915     1.8111190199851990e-01
    z[7,3,0]  R1916     -8.5589081048965454e-01
    z[7,3,0]  R1917     -4.3774202822532970e-06
    z[7,3,0]  R1918     -5.0196421146392822e-01
    z[7,3,0]  R1919     9.2960394918918610e-02
    z[7,3,0]  R1920     -5.4913395643234253e-01
    z[7,3,0]  R1921     -4.6438139677047729e-01
    z[7,3,0]  R1922     -3.6235442757606506e-01
    z[7,3,0]  R1923     1.7734211683273315e-01
    z[7,3,0]  R1924     1.1243292689323425e-01
    z[7,3,0]  R1925     -5.2351492643356323e-01
    z[7,3,0]  R1926     3.2991003245115280e-03
    z[7,3,0]  R1927     3.1800916790962219e-01
    z[7,3,0]  R1928     3.3361810445785522e-01
    z[7,3,0]  R1929     3.0185526609420776e-01
    z[7,3,0]  R1930     3.6144572496414185e-01
    z[7,3,0]  R1931     1.7125104367733002e-01
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1867     -1
    z[7,3,1]  R1868     1
    z[7,3,1]  R1879     -3.4604340791702271e-01
    z[7,3,1]  R1880     -3.2077878713607788e-01
    z[7,3,1]  R1881     -4.2159634828567505e-01
    z[7,3,1]  R1882     -3.9484176039695740e-01
    z[7,3,1]  R1883     -3.1864890456199646e-01
    z[7,3,1]  R1884     -2.7003687620162964e-01
    z[7,3,1]  R1885     -5.0405979156494141e-01
    z[7,3,1]  R1886     7.4345552921295166e-01
    z[7,3,1]  R1887     6.9006556272506714e-01
    z[7,3,1]  R1888     3.8838860392570496e-01
    z[7,3,1]  R1889     4.5317673683166504e-01
    z[7,3,1]  R1890     3.0732971429824829e-01
    z[7,3,1]  R1891     5.2750808000564575e-01
    z[7,3,1]  R1892     6.0210186243057251e-01
    z[7,3,1]  R1893     4.3000218272209167e-01
    z[7,3,1]  R1894     3.1987950205802917e-01
    z[7,3,1]  R1895     3.3580586314201355e-01
    z[7,3,1]  R1896     2.4285274744033813e-01
    z[7,3,1]  R1897     -4.6651086211204529e-01
    z[7,3,1]  R1898     -0.539271891117096
    z[7,3,1]  R1899     -1.4057770371437073e-01
    z[7,3,1]  R1900     0.567960798740387
    z[7,3,1]  R1901     -0.228984072804451
    z[7,3,1]  R1902     7.9121059179306030e-01
    z[7,3,1]  R1903     5.5430847406387329e-01
    z[7,3,1]  R1904     5.5086892843246460e-01
    z[7,3,1]  R1905     6.2954002618789673e-01
    z[7,3,1]  R1906     5.6699329614639282e-01
    z[7,3,1]  R1907     2.1715676784515381e-01
    z[7,3,1]  R1908     3.0918952822685242e-01
    z[7,3,1]  R1909     -4.7771230340003967e-01
    z[7,3,1]  R1910     6.6895473003387451e-01
    z[7,3,1]  R1911     7.5023949146270752e-01
    z[7,3,1]  R1912     8.2526785135269165e-01
    z[7,3,1]  R1913     1.5270633995532990e-01
    z[7,3,1]  R1914     8.2591497898101807e-01
    z[7,3,1]  R1915     3.5667210817337036e-01
    z[7,3,1]  R1916     1.1318787187337875e-01
    z[7,3,1]  R1917     1.1947839707136154e-01
    z[7,3,1]  R1918     -0.65839684009552
    z[7,3,1]  R1919     -0.691955029964447
    z[7,3,1]  R1920     -5.5208396911621094e-01
    z[7,3,1]  R1921     -0.626633882522583
    z[7,3,1]  R1922     -4.1933557391166687e-01
    z[7,3,1]  R1923     0.064608134329319
    z[7,3,1]  R1924     -3.9330857992172241e-01
    z[7,3,1]  R1925     -0.666795015335083
    z[7,3,1]  R1926     -4.9973803758621216e-01
    z[7,3,1]  R1927     0.822810173034668
    z[7,3,1]  R1928     6.9742277264595032e-02
    z[7,3,1]  R1929     4.6270421147346497e-01
    z[7,3,1]  R1930     -0.0831177830696106
    z[7,3,1]  R1931     -5.0423705577850342e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1869     -1
    z[7,3,2]  R1870     1
    z[7,3,2]  R1879     -2.1354725956916809e-01
    z[7,3,2]  R1880     3.7155240774154663e-01
    z[7,3,2]  R1881     0.336379736661911
    z[7,3,2]  R1882     1.4622454345226288e-01
    z[7,3,2]  R1883     2.6254877448081970e-01
    z[7,3,2]  R1884     5.0766289234161377e-01
    z[7,3,2]  R1885     2.3617684841156006e-01
    z[7,3,2]  R1886     5.2378600835800171e-01
    z[7,3,2]  R1887     5.5961215496063232e-01
    z[7,3,2]  R1888     5.8387947082519531e-01
    z[7,3,2]  R1889     1.4334578812122345e-01
    z[7,3,2]  R1890     9.1534264385700226e-02
    z[7,3,2]  R1891     2.4795642122626305e-02
    z[7,3,2]  R1892     -1.6446989774703979e-01
    z[7,3,2]  R1893     -3.1073245406150818e-01
    z[7,3,2]  R1894     -6.8830925226211548e-01
    z[7,3,2]  R1895     -3.5474994778633118e-01
    z[7,3,2]  R1896     -6.5949332714080811e-01
    z[7,3,2]  R1897     6.3296836614608765e-01
    z[7,3,2]  R1898     -5.7502470910549164e-02
    z[7,3,2]  R1899     -1.7588475719094276e-02
    z[7,3,2]  R1900     -1.5407618880271912e-01
    z[7,3,2]  R1901     -3.3088666200637817e-01
    z[7,3,2]  R1902     4.6474966220557690e-03
    z[7,3,2]  R1903     1.6201306879520416e-01
    z[7,3,2]  R1904     0.319915235042572
    z[7,3,2]  R1905     -2.0948900282382965e-01
    z[7,3,2]  R1906     -1.2064448557794094e-02
    z[7,3,2]  R1907     6.1238389462232590e-02
    z[7,3,2]  R1908     6.6069457679986954e-03
    z[7,3,2]  R1909     -1.0454404167830944e-02
    z[7,3,2]  R1910     4.7001782059669495e-01
    z[7,3,2]  R1911     4.0012022852897644e-01
    z[7,3,2]  R1912     2.1673339605331421e-01
    z[7,3,2]  R1913     3.2546713948249817e-01
    z[7,3,2]  R1914     3.2212135195732117e-01
    z[7,3,2]  R1915     2.7594748139381409e-01
    z[7,3,2]  R1916     -4.1854715347290039e-01
    z[7,3,2]  R1917     -5.0464099645614624e-01
    z[7,3,2]  R1918     -4.3756082653999329e-01
    z[7,3,2]  R1919     -4.2218956351280212e-01
    z[7,3,2]  R1920     -3.9870855212211609e-01
    z[7,3,2]  R1921     -2.4444781243801117e-01
    z[7,3,2]  R1922     -7.1697455644607544e-01
    z[7,3,2]  R1923     -4.2742338031530380e-02
    z[7,3,2]  R1924     2.9280850291252136e-01
    z[7,3,2]  R1925     -3.2561093568801880e-01
    z[7,3,2]  R1926     7.9545283317565918e-01
    z[7,3,2]  R1927     3.1671860814094543e-01
    z[7,3,2]  R1928     1.6957861185073853e-01
    z[7,3,2]  R1929     3.2461118698120117e-01
    z[7,3,2]  R1930     2.1251462399959564e-01
    z[7,3,2]  R1931     4.9290871247649193e-03
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1871     -1
    z[7,3,3]  R1872     1
    z[7,3,3]  R1879     8.2620793581008911e-01
    z[7,3,3]  R1880     -1.2785139679908752e-01
    z[7,3,3]  R1881     -3.4935075044631958e-01
    z[7,3,3]  R1882     -2.9280295968055725e-01
    z[7,3,3]  R1883     -2.8917145729064941e-01
    z[7,3,3]  R1884     -3.9025139808654785e-01
    z[7,3,3]  R1885     1.1600656062364578e-01
    z[7,3,3]  R1886     1.1536002904176712e-01
    z[7,3,3]  R1887     1.1884523183107376e-01
    z[7,3,3]  R1888     2.1242666244506836e-01
    z[7,3,3]  R1889     4.3413969874382019e-01
    z[7,3,3]  R1890     3.3604815602302551e-01
    z[7,3,3]  R1891     9.0555511415004730e-02
    z[7,3,3]  R1892     -1.8992717564105988e-01
    z[7,3,3]  R1893     1.6848176717758179e-01
    z[7,3,3]  R1894     -1.2528951466083527e-01
    z[7,3,3]  R1895     4.6882618218660355e-02
    z[7,3,3]  R1896     -1.0609063506126404e-01
    z[7,3,3]  R1897     -3.6784434318542480e-01
    z[7,3,3]  R1898     -2.0180073380470276e-01
    z[7,3,3]  R1899     -9.5994293689727783e-01
    z[7,3,3]  R1900     3.4489190578460693e-01
    z[7,3,3]  R1901     0.0662183165550232
    z[7,3,3]  R1902     5.9517048299312592e-02
    z[7,3,3]  R1903     3.3371126651763916e-01
    z[7,3,3]  R1904     3.9141643047332764e-01
    z[7,3,3]  R1905     2.3797918856143951e-01
    z[7,3,3]  R1906     2.6741623878479004e-01
    z[7,3,3]  R1907     3.1077753752470016e-02
    z[7,3,3]  R1908     -1.4447696506977081e-01
    z[7,3,3]  R1909     -3.1387850642204285e-01
    z[7,3,3]  R1910     3.9956855773925781e-01
    z[7,3,3]  R1911     1.7371344566345215e-01
    z[7,3,3]  R1912     3.0642119050025940e-01
    z[7,3,3]  R1913     3.9904779195785522e-01
    z[7,3,3]  R1914     4.9581699073314667e-02
    z[7,3,3]  R1915     5.8728528022766113e-01
    z[7,3,3]  R1916     -4.5279961079359055e-02
    z[7,3,3]  R1917     5.6319665908813477e-01
    z[7,3,3]  R1918     -1.0369183868169785e-01
    z[7,3,3]  R1919     -5.2761048078536987e-01
    z[7,3,3]  R1920     -4.3900772929191589e-02
    z[7,3,3]  R1921     1.8475079536437988e-01
    z[7,3,3]  R1922     3.5118627548217773e-01
    z[7,3,3]  R1923     3.1219440698623657e-01
    z[7,3,3]  R1924     -2.4333126842975616e-01
    z[7,3,3]  R1925     7.5939163565635681e-02
    z[7,3,3]  R1926     -1.5298357605934143e-01
    z[7,3,3]  R1927     7.3067627847194672e-02
    z[7,3,3]  R1928     5.9623247385025024e-01
    z[7,3,3]  R1929     -4.7412705421447754e-01
    z[7,3,3]  R1930     -0.594360888004303
    z[7,3,3]  R1931     -2.1659563481807709e-01
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1873     -1
    z[7,3,4]  R1874     1
    z[7,3,4]  R1879     -3.1051984429359436e-01
    z[7,3,4]  R1880     6.0188418626785278e-01
    z[7,3,4]  R1881     -1.4745886623859406e-01
    z[7,3,4]  R1882     -4.6099311113357544e-01
    z[7,3,4]  R1883     6.8539303541183472e-01
    z[7,3,4]  R1884     1.8325036764144897e-01
    z[7,3,4]  R1885     6.8210393190383911e-01
    z[7,3,4]  R1886     -2.5741992518305779e-02
    z[7,3,4]  R1887     1.1290936172008514e-01
    z[7,3,4]  R1888     -0.592860758304596
    z[7,3,4]  R1889     2.8637340664863586e-01
    z[7,3,4]  R1890     1.8847092986106873e-01
    z[7,3,4]  R1891     -5.0618678331375122e-01
    z[7,3,4]  R1892     -5.3477054834365845e-01
    z[7,3,4]  R1893     2.1060076355934143e-01
    z[7,3,4]  R1894     7.1448874659836292e-03
    z[7,3,4]  R1895     -3.9999313652515411e-02
    z[7,3,4]  R1896     3.6102943122386932e-02
    z[7,3,4]  R1897     1.8114270269870758e-01
    z[7,3,4]  R1898     2.2137662768363953e-01
    z[7,3,4]  R1899     -1.6119654476642609e-01
    z[7,3,4]  R1900     7.2562344372272491e-02
    z[7,3,4]  R1901     7.1863633394241333e-01
    z[7,3,4]  R1902     1.9115528464317322e-01
    z[7,3,4]  R1903     5.5096572637557983e-01
    z[7,3,4]  R1904     -4.3163388967514038e-01
    z[7,3,4]  R1905     -1.8582014739513397e-01
    z[7,3,4]  R1906     -4.3526330590248108e-01
    z[7,3,4]  R1907     9.7522474825382233e-02
    z[7,3,4]  R1908     -0.558796226978302
    z[7,3,4]  R1909     -3.6174062639474869e-02
    z[7,3,4]  R1910     3.4133863449096680e-01
    z[7,3,4]  R1911     2.3872828111052513e-02
    z[7,3,4]  R1912     -1.8965993821620941e-01
    z[7,3,4]  R1913     3.4512110054492950e-02
    z[7,3,4]  R1914     2.4022670090198517e-01
    z[7,3,4]  R1915     9.3611087650060654e-03
    z[7,3,4]  R1916     1.6803732514381409e-01
    z[7,3,4]  R1917     1.7180059850215912e-01
    z[7,3,4]  R1918     -0.290390282869339
    z[7,3,4]  R1919     -1.2788760662078857e-01
    z[7,3,4]  R1920     3.1648221611976624e-01
    z[7,3,4]  R1921     2.4286733940243721e-02
    z[7,3,4]  R1922     -1.8562752008438110e-01
    z[7,3,4]  R1923     -8.5928475856781006e-01
    z[7,3,4]  R1924     3.1024357676506042e-01
    z[7,3,4]  R1925     -3.6562168598175049e-01
    z[7,3,4]  R1926     -1.3181759975850582e-02
    z[7,3,4]  R1927     2.3730356991291046e-01
    z[7,3,4]  R1928     4.6288302540779114e-01
    z[7,3,4]  R1929     -1.7594926059246063e-01
    z[7,3,4]  R1930     2.8487956523895264e-01
    z[7,3,4]  R1931     5.3741383552551270e-01
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1875     -1
    z[7,3,5]  R1876     1
    z[7,3,5]  R1879     -1.9773536920547485e-01
    z[7,3,5]  R1880     -4.3851515650749207e-01
    z[7,3,5]  R1881     -2.9622310400009155e-01
    z[7,3,5]  R1882     -0.588651180267334
    z[7,3,5]  R1883     4.7824871540069580e-01
    z[7,3,5]  R1884     2.8403592109680176e-01
    z[7,3,5]  R1885     -1.5754656493663788e-01
    z[7,3,5]  R1886     -2.9139408469200134e-01
    z[7,3,5]  R1887     2.2504577040672302e-01
    z[7,3,5]  R1888     -0.0945129320025444
    z[7,3,5]  R1889     2.0391296595335007e-02
    z[7,3,5]  R1890     5.7642799615859985e-01
    z[7,3,5]  R1891     4.6518808603286743e-01
    z[7,3,5]  R1892     2.3237279057502747e-01
    z[7,3,5]  R1893     -5.5580466985702515e-01
    z[7,3,5]  R1894     0.0278362687677145
    z[7,3,5]  R1895     2.2809931635856628e-01
    z[7,3,5]  R1896     2.1465249359607697e-01
    z[7,3,5]  R1897     -4.1360697150230408e-01
    z[7,3,5]  R1898     2.0990513265132904e-01
    z[7,3,5]  R1899     7.3872774839401245e-02
    z[7,3,5]  R1900     9.8390288650989532e-02
    z[7,3,5]  R1901     -3.4756880998611450e-01
    z[7,3,5]  R1902     -7.5938858091831207e-02
    z[7,3,5]  R1903     9.4430379569530487e-02
    z[7,3,5]  R1904     4.3317312002182007e-01
    z[7,3,5]  R1905     -4.4979268312454224e-01
    z[7,3,5]  R1906     4.5299929380416870e-01
    z[7,3,5]  R1907     -9.2040526866912842e-01
    z[7,3,5]  R1908     -3.4115061163902283e-01
    z[7,3,5]  R1909     4.6103116869926453e-01
    z[7,3,5]  R1910     -2.2435872256755829e-01
    z[7,3,5]  R1911     1.6398425941588357e-05
    z[7,3,5]  R1912     -3.3011871576309204e-01
    z[7,3,5]  R1913     2.0022456347942352e-01
    z[7,3,5]  R1914     2.5162905454635620e-02
    z[7,3,5]  R1915     5.9163635969161987e-01
    z[7,3,5]  R1916     2.0850417017936707e-01
    z[7,3,5]  R1917     -6.1394846439361572e-01
    z[7,3,5]  R1918     2.0823361352086067e-02
    z[7,3,5]  R1919     -1.9786822795867920e-01
    z[7,3,5]  R1920     -3.6314314603805542e-01
    z[7,3,5]  R1921     -3.8083171844482422e-01
    z[7,3,5]  R1922     1.3971579074859619e-01
    z[7,3,5]  R1923     2.1009135246276855e-01
    z[7,3,5]  R1924     -4.3233373761177063e-01
    z[7,3,5]  R1925     -1.3284134864807129e-01
    z[7,3,5]  R1926     2.7037004474550486e-03
    z[7,3,5]  R1927     0.0669000968337059
    z[7,3,5]  R1928     5.3333175182342529e-01
    z[7,3,5]  R1929     -5.1613062620162964e-01
    z[7,3,5]  R1930     3.9667895436286926e-01
    z[7,3,5]  R1931     4.8298445343971252e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1877     -1
    z[7,3,6]  R1878     1
    z[7,3,6]  R1879     8.5967361927032471e-02
    z[7,3,6]  R1880     4.3267118930816650e-01
    z[7,3,6]  R1881     2.2212950885295868e-01
    z[7,3,6]  R1882     -4.0958082675933838e-01
    z[7,3,6]  R1883     2.1534173190593719e-01
    z[7,3,6]  R1884     0.585595428943634
    z[7,3,6]  R1885     -1.3694108463823795e-02
    z[7,3,6]  R1886     2.0154589414596558e-01
    z[7,3,6]  R1887     3.4045910835266113e-01
    z[7,3,6]  R1888     -3.1847360730171204e-01
    z[7,3,6]  R1889     -6.3530862331390381e-01
    z[7,3,6]  R1890     -4.7465628385543823e-01
    z[7,3,6]  R1891     -3.5176226496696472e-01
    z[7,3,6]  R1892     3.6010544747114182e-02
    z[7,3,6]  R1893     -1.1052598804235458e-01
    z[7,3,6]  R1894     -1.0917614400386810e-01
    z[7,3,6]  R1895     -3.6055833101272583e-01
    z[7,3,6]  R1896     4.4140985608100891e-01
    z[7,3,6]  R1897     -1.8599297106266022e-01
    z[7,3,6]  R1898     3.2376810908317566e-01
    z[7,3,6]  R1899     4.6240020543336868e-02
    z[7,3,6]  R1900     3.2740023732185364e-01
    z[7,3,6]  R1901     -1.5350070595741272e-01
    z[7,3,6]  R1902     9.4344235956668854e-02
    z[7,3,6]  R1903     2.6627802848815918e-01
    z[7,3,6]  R1904     -2.5836843252182007e-01
    z[7,3,6]  R1905     -1.9068348407745361e-01
    z[7,3,6]  R1906     2.1036484837532043e-01
    z[7,3,6]  R1907     1.6790562868118286e-01
    z[7,3,6]  R1908     -6.6682326793670654e-01
    z[7,3,6]  R1909     -6.6632938385009766e-01
    z[7,3,6]  R1910     -1.1788893491029739e-02
    z[7,3,6]  R1911     -1.4518619515001774e-02
    z[7,3,6]  R1912     -1.3808824121952057e-01
    z[7,3,6]  R1913     -8.0798274278640747e-01
    z[7,3,6]  R1914     0.318573534488678
    z[7,3,6]  R1915     -2.6231896877288818e-01
    z[7,3,6]  R1916     7.5478866696357727e-02
    z[7,3,6]  R1917     8.6160756647586823e-02
    z[7,3,6]  R1918     1.6605402529239655e-01
    z[7,3,6]  R1919     -2.0802492275834084e-02
    z[7,3,6]  R1920     -2.6933647692203522e-02
    z[7,3,6]  R1921     3.9008951187133789e-01
    z[7,3,6]  R1922     -3.8659039884805679e-02
    z[7,3,6]  R1923     2.8735810518264771e-01
    z[7,3,6]  R1924     -6.3604766130447388e-01
    z[7,3,6]  R1925     -1.3491220772266388e-01
    z[7,3,6]  R1926     -3.0646494030952454e-01
    z[7,3,6]  R1927     -2.3540496826171875e-01
    z[7,3,6]  R1928     2.9689380899071693e-02
    z[7,3,6]  R1929     2.5936502218246460e-01
    z[7,3,6]  R1930     4.7487938404083252e-01
    z[7,3,6]  R1931     3.8391733169555664e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1961     -1
    z[4,5,0]  R1962     1
    z[4,5,0]  R1975     -3.3462586998939514e-01
    z[4,5,0]  R1976     -1.8386751413345337e-01
    z[4,5,0]  R1977     -3.9521700143814087e-01
    z[4,5,0]  R1978     -2.3452313244342804e-01
    z[4,5,0]  R1979     -2.2922654449939728e-01
    z[4,5,0]  R1980     -1.8005660176277161e-01
    z[4,5,0]  R1981     -8.4693320095539093e-02
    z[4,5,0]  R1982     1.8776130676269531e-01
    z[4,5,0]  R1983     1.3694921135902405e-01
    z[4,5,0]  R1984     4.2758950591087341e-01
    z[4,5,0]  R1985     -4.0578305721282959e-01
    z[4,5,0]  R1986     -4.7967612743377686e-01
    z[4,5,0]  R1987     -4.0851479768753052e-01
    z[4,5,0]  R1988     -5.3752940893173218e-01
    z[4,5,0]  R1989     5.3640712052583694e-02
    z[4,5,0]  R1990     -2.6883631944656372e-01
    z[4,5,0]  R1991     -5.7874453067779541e-01
    z[4,5,0]  R1992     1.5037380158901215e-01
    z[4,5,0]  R1993     -9.9909491837024689e-02
    z[4,5,0]  R1994     -4.3336942791938782e-01
    z[4,5,0]  R1995     -1.9610394537448883e-01
    z[4,5,0]  R1996     -3.5530373454093933e-02
    z[4,5,0]  R1997     -1.0527639091014862e-01
    z[4,5,0]  R1998     8.7870702147483826e-02
    z[4,5,0]  R1999     -7.0698693394660950e-02
    z[4,5,0]  R2000     2.8746232390403748e-01
    z[4,5,0]  R2001     2.2877755761146545e-01
    z[4,5,0]  R2002     2.9575052857398987e-01
    z[4,5,0]  R2003     1.5770190954208374e-01
    z[4,5,0]  R2004     1.7726863920688629e-01
    z[4,5,0]  R2005     -3.2168358564376831e-02
    z[4,5,0]  R2006     0.100483737885952
    z[4,5,0]  R2007     0.355254590511322
    z[4,5,0]  R2008     -1.4013829827308655e-01
    z[4,5,0]  R2009     -2.1680450439453125e-01
    z[4,5,0]  R2010     -5.3905218839645386e-01
    z[4,5,0]  R2011     4.9205985665321350e-01
    z[4,5,0]  R2012     3.9730939269065857e-01
    z[4,5,0]  R2013     5.3545570373535156e-01
    z[4,5,0]  R2014     3.9797511696815491e-01
    z[4,5,0]  R2015     4.7793468832969666e-01
    z[4,5,0]  R2016     5.0514614582061768e-01
    z[4,5,0]  R2017     5.3256362676620483e-01
    z[4,5,0]  R2018     -1.5803965926170349e-01
    z[4,5,0]  R2019     -2.6606826111674309e-02
    z[4,5,0]  R2020     -1.0368255898356438e-02
    z[4,5,0]  R2021     1.1904559284448624e-01
    z[4,5,0]  R2022     1.7774741351604462e-01
    z[4,5,0]  R2023     -1.5899810194969177e-01
    z[4,5,0]  R2024     5.0254738330841064e-01
    z[4,5,0]  R2025     9.1045953333377838e-02
    z[4,5,0]  R2026     -0.510917067527771
    z[4,5,0]  R2027     -4.8073145747184753e-01
    z[4,5,0]  R2028     6.4875298738479614e-01
    z[4,5,0]  R2029     4.3376949429512024e-01
    z[4,5,0]  R2030     4.7673863172531128e-01
    z[4,5,0]  R2031     5.3648990392684937e-01
    z[4,5,0]  R2032     5.0994259119033813e-01
    z[4,5,0]  R2033     5.7621508836746216e-01
    z[4,5,0]  R2034     4.2194086313247681e-01
    z[4,5,0]  R2035     5.3625619411468506e-01
    z[4,5,0]  R2036     4.2689137160778046e-02
    z[4,5,0]  R2037     -9.4247311353683472e-02
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1963     -1
    z[4,5,1]  R1964     1
    z[4,5,1]  R1975     3.8000056147575378e-01
    z[4,5,1]  R1976     -1.9344460964202881e-01
    z[4,5,1]  R1977     -5.0770647823810577e-02
    z[4,5,1]  R1978     -1.6699281334877014e-01
    z[4,5,1]  R1979     -3.1540206074714661e-01
    z[4,5,1]  R1980     -2.5305259227752686e-01
    z[4,5,1]  R1981     4.4007140398025513e-01
    z[4,5,1]  R1982     -1.3627345860004425e-01
    z[4,5,1]  R1983     -7.0837664604187012e-01
    z[4,5,1]  R1984     -6.7598110437393188e-01
    z[4,5,1]  R1985     4.9739986658096313e-01
    z[4,5,1]  R1986     -5.7361096143722534e-01
    z[4,5,1]  R1987     -3.8349729776382446e-01
    z[4,5,1]  R1988     -4.3888527154922485e-01
    z[4,5,1]  R1989     -0.254909485578537
    z[4,5,1]  R1990     -2.1825772523880005e-01
    z[4,5,1]  R1991     -0.502673864364624
    z[4,5,1]  R1992     -4.8204681277275085e-01
    z[4,5,1]  R1993     -4.0451011061668396e-01
    z[4,5,1]  R1994     -3.0568674206733704e-01
    z[4,5,1]  R1995     -7.8370010852813721e-01
    z[4,5,1]  R1996     -6.6754847764968872e-01
    z[4,5,1]  R1997     -6.5499776601791382e-01
    z[4,5,1]  R1998     -6.1614960432052612e-01
    z[4,5,1]  R1999     -0.886188268661499
    z[4,5,1]  R2000     -7.0449334383010864e-01
    z[4,5,1]  R2001     -8.5056900978088379e-01
    z[4,5,1]  R2002     -7.7175575494766235e-01
    z[4,5,1]  R2003     -7.2972613573074341e-01
    z[4,5,1]  R2004     -5.1401132345199585e-01
    z[4,5,1]  R2005     4.5769292116165161e-01
    z[4,5,1]  R2006     -4.6682092547416687e-01
    z[4,5,1]  R2007     4.2010107636451721e-01
    z[4,5,1]  R2008     -8.1982904672622681e-01
    z[4,5,1]  R2009     -2.2912929952144623e-01
    z[4,5,1]  R2010     -3.9167895913124084e-01
    z[4,5,1]  R2011     4.6158227324485779e-01
    z[4,5,1]  R2012     6.3057202100753784e-01
    z[4,5,1]  R2013     4.6942472457885742e-01
    z[4,5,1]  R2014     4.7702306509017944e-01
    z[4,5,1]  R2015     4.2926475405693054e-01
    z[4,5,1]  R2016     4.4876602292060852e-01
    z[4,5,1]  R2017     3.6234620213508606e-01
    z[4,5,1]  R2018     1.2943477928638458e-01
    z[4,5,1]  R2019     -6.0232721269130707e-02
    z[4,5,1]  R2020     9.3906730413436890e-01
    z[4,5,1]  R2021     0.767741858959198
    z[4,5,1]  R2022     7.5549668073654175e-01
    z[4,5,1]  R2023     5.7971423864364624e-01
    z[4,5,1]  R2024     4.6100342273712158e-01
    z[4,5,1]  R2025     7.0692896842956543e-01
    z[4,5,1]  R2026     4.7931188344955444e-01
    z[4,5,1]  R2027     6.4421904087066650e-01
    z[4,5,1]  R2028     7.3177880048751831e-01
    z[4,5,1]  R2029     8.4226936101913452e-01
    z[4,5,1]  R2030     8.3228170871734619e-01
    z[4,5,1]  R2031     7.5504338741302490e-01
    z[4,5,1]  R2032     7.6662635803222656e-01
    z[4,5,1]  R2033     6.8480169773101807e-01
    z[4,5,1]  R2034     8.0933910608291626e-01
    z[4,5,1]  R2035     6.9874179363250732e-01
    z[4,5,1]  R2036     7.6158493757247925e-01
    z[4,5,1]  R2037     6.6127419471740723e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1965     -1
    z[4,5,2]  R1966     1
    z[4,5,2]  R1975     -2.3803240060806274e-01
    z[4,5,2]  R1976     -0.604768693447113
    z[4,5,2]  R1977     2.7401563525199890e-01
    z[4,5,2]  R1978     -5.3405463695526123e-01
    z[4,5,2]  R1979     -4.3609780073165894e-01
    z[4,5,2]  R1980     -0.746088445186615
    z[4,5,2]  R1981     -7.9301851987838745e-01
    z[4,5,2]  R1982     -5.0941503047943115e-01
    z[4,5,2]  R1983     -4.7889359295368195e-02
    z[4,5,2]  R1984     3.0989333987236023e-01
    z[4,5,2]  R1985     4.1016179323196411e-01
    z[4,5,2]  R1986     2.2047109901905060e-01
    z[4,5,2]  R1987     1.9793987274169922e-01
    z[4,5,2]  R1988     2.1866784989833832e-01
    z[4,5,2]  R1989     -1.5877494215965271e-01
    z[4,5,2]  R1990     -6.7958123981952667e-02
    z[4,5,2]  R1991     4.6555814146995544e-01
    z[4,5,2]  R1992     4.3209385871887207e-01
    z[4,5,2]  R1993     5.6076145172119141e-01
    z[4,5,2]  R1994     2.6527991890907288e-01
    z[4,5,2]  R1995     1.3881656527519226e-01
    z[4,5,2]  R1996     1.2538301944732666e-01
    z[4,5,2]  R1997     -1.1175126768648624e-02
    z[4,5,2]  R1998     -3.6341828107833862e-01
    z[4,5,2]  R1999     -1.0333603620529175e-01
    z[4,5,2]  R2000     8.0590806901454926e-03
    z[4,5,2]  R2001     1.1250586062669754e-01
    z[4,5,2]  R2002     3.1465390324592590e-01
    z[4,5,2]  R2003     1.7359924316406250e-01
    z[4,5,2]  R2004     -4.0520984679460526e-02
    z[4,5,2]  R2005     3.7315767258405685e-02
    z[4,5,2]  R2006     6.2014883756637573e-01
    z[4,5,2]  R2007     6.1589145660400391e-01
    z[4,5,2]  R2008     -3.5748252272605896e-01
    z[4,5,2]  R2009     -3.6852023005485535e-01
    z[4,5,2]  R2010     4.9215239286422729e-01
    z[4,5,2]  R2011     2.5748586654663086e-01
    z[4,5,2]  R2012     -6.4546324312686920e-02
    z[4,5,2]  R2013     -1.7670178413391113e-01
    z[4,5,2]  R2014     -6.9458144903182983e-01
    z[4,5,2]  R2015     4.8162847757339478e-01
    z[4,5,2]  R2016     -4.8755022883415222e-01
    z[4,5,2]  R2017     1.5100403130054474e-01
    z[4,5,2]  R2018     2.8145718574523926e-01
    z[4,5,2]  R2019     2.6563405990600586e-01
    z[4,5,2]  R2020     -1.6246227920055389e-01
    z[4,5,2]  R2021     1.0238543152809143e-01
    z[4,5,2]  R2022     -0.0772957056760788
    z[4,5,2]  R2023     -3.6308398842811584e-01
    z[4,5,2]  R2024     1.7393574118614197e-01
    z[4,5,2]  R2025     -2.4055273830890656e-01
    z[4,5,2]  R2026     -5.8491069078445435e-01
    z[4,5,2]  R2027     -4.0013724565505981e-01
    z[4,5,2]  R2028     3.0864465981721878e-02
    z[4,5,2]  R2029     4.3979067355394363e-02
    z[4,5,2]  R2030     -2.0543819665908813e-01
    z[4,5,2]  R2031     -1.1190900579094887e-02
    z[4,5,2]  R2032     2.6367226243019104e-01
    z[4,5,2]  R2033     -5.7455807924270630e-02
    z[4,5,2]  R2034     -2.1146422252058983e-02
    z[4,5,2]  R2035     -3.4737319219857454e-03
    z[4,5,2]  R2036     -5.0904309749603271e-01
    z[4,5,2]  R2037     -6.3758021593093872e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1967     -1
    z[4,5,3]  R1968     1
    z[4,5,3]  R1975     6.0357111692428589e-01
    z[4,5,3]  R1976     6.0565865039825439e-01
    z[4,5,3]  R1977     5.6753265857696533e-01
    z[4,5,3]  R1978     3.5742005705833435e-01
    z[4,5,3]  R1979     6.9856691360473633e-01
    z[4,5,3]  R1980     -2.1257533226162195e-03
    z[4,5,3]  R1981     -1.0303667932748795e-01
    z[4,5,3]  R1982     4.2567637562751770e-01
    z[4,5,3]  R1983     -8.1853784620761871e-02
    z[4,5,3]  R1984     -2.2696793079376221e-02
    z[4,5,3]  R1985     -1.1700502038002014e-01
    z[4,5,3]  R1986     -3.2574126124382019e-01
    z[4,5,3]  R1987     -6.5682113170623779e-01
    z[4,5,3]  R1988     -4.3825656175613403e-01
    z[4,5,3]  R1989     -9.3386447429656982e-01
    z[4,5,3]  R1990     -8.6636233329772949e-01
    z[4,5,3]  R1991     -1.7136411368846893e-01
    z[4,5,3]  R1992     -4.0631026029586792e-01
    z[4,5,3]  R1993     -6.3331335783004761e-01
    z[4,5,3]  R1994     -0.537703275680542
    z[4,5,3]  R1995     -5.1382768154144287e-01
    z[4,5,3]  R1996     -4.6713244915008545e-01
    z[4,5,3]  R1997     -6.0241687297821045e-01
    z[4,5,3]  R1998     -5.1698893308639526e-01
    z[4,5,3]  R1999     5.8623269200325012e-02
    z[4,5,3]  R2000     -3.8728532195091248e-01
    z[4,5,3]  R2001     -1.6162315011024475e-01
    z[4,5,3]  R2002     -0.192413792014122
    z[4,5,3]  R2003     -3.7569716572761536e-01
    z[4,5,3]  R2004     -7.0126241445541382e-01
    z[4,5,3]  R2005     2.3726058006286621e-01
    z[4,5,3]  R2006     4.2315709590911865e-01
    z[4,5,3]  R2007     -3.2375445961952209e-01
    z[4,5,3]  R2008     -3.0484458804130554e-01
    z[4,5,3]  R2009     3.0258995294570923e-01
    z[4,5,3]  R2010     2.6740673184394836e-01
    z[4,5,3]  R2011     -1.4441390335559845e-01
    z[4,5,3]  R2012     2.0342398434877396e-02
    z[4,5,3]  R2013     4.3444547057151794e-01
    z[4,5,3]  R2014     1.4450505375862122e-01
    z[4,5,3]  R2015     1.3760606944561005e-01
    z[4,5,3]  R2016     7.1704357862472534e-02
    z[4,5,3]  R2017     1.3513167202472687e-01
    z[4,5,3]  R2018     -0.828399121761322
    z[4,5,3]  R2019     -1.9924451410770416e-01
    z[4,5,3]  R2020     2.5086668133735657e-01
    z[4,5,3]  R2021     -1.1031280271708965e-02
    z[4,5,3]  R2022     1.5580029785633087e-01
    z[4,5,3]  R2023     6.5932929515838623e-01
    z[4,5,3]  R2024     3.1311213970184326e-01
    z[4,5,3]  R2025     2.7446320652961731e-01
    z[4,5,3]  R2026     1.5342476963996887e-01
    z[4,5,3]  R2027     -1.2894946336746216e-01
    z[4,5,3]  R2028     -1.0152570903301239e-01
    z[4,5,3]  R2029     3.4143622964620590e-02
    z[4,5,3]  R2030     4.4309478253126144e-02
    z[4,5,3]  R2031     -1.4164656400680542e-02
    z[4,5,3]  R2032     7.2648137807846069e-02
    z[4,5,3]  R2033     -4.9537453800439835e-02
    z[4,5,3]  R2034     0.332329660654068
    z[4,5,3]  R2035     4.5039889216423035e-01
    z[4,5,3]  R2036     2.8907701373100281e-01
    z[4,5,3]  R2037     1.0043850168585777e-02
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1969     -1
    z[4,5,4]  R1970     1
    z[4,5,4]  R1975     -0.136503204703331
    z[4,5,4]  R1976     -3.5392385721206665e-01
    z[4,5,4]  R1977     -1.2165436148643494e-01
    z[4,5,4]  R1978     2.4295400083065033e-01
    z[4,5,4]  R1979     1.8292248249053955e-01
    z[4,5,4]  R1980     0.0803111121058464
    z[4,5,4]  R1981     -2.9412344098091125e-01
    z[4,5,4]  R1982     -4.7645080089569092e-01
    z[4,5,4]  R1983     1.8391543626785278e-01
    z[4,5,4]  R1984     -2.0362272858619690e-01
    z[4,5,4]  R1985     6.3021337985992432e-01
    z[4,5,4]  R1986     -3.9791175723075867e-01
    z[4,5,4]  R1987     1.8500414490699768e-01
    z[4,5,4]  R1988     -3.1702926754951477e-01
    z[4,5,4]  R1989     -1.8385635316371918e-01
    z[4,5,4]  R1990     -1.8522606790065765e-01
    z[4,5,4]  R1991     3.2720991969108582e-01
    z[4,5,4]  R1992     4.2710778117179871e-01
    z[4,5,4]  R1993     -9.9936813116073608e-02
    z[4,5,4]  R1994     4.9798506498336792e-01
    z[4,5,4]  R1995     -4.6888455748558044e-02
    z[4,5,4]  R1996     2.5393700599670410e-01
    z[4,5,4]  R1997     4.1427984833717346e-01
    z[4,5,4]  R1998     2.0255523920059204e-01
    z[4,5,4]  R1999     2.9631167650222778e-01
    z[4,5,4]  R2000     -8.9310482144355774e-03
    z[4,5,4]  R2001     -2.7383950352668762e-01
    z[4,5,4]  R2002     3.7135148048400879e-01
    z[4,5,4]  R2003     1.0403730720281601e-01
    z[4,5,4]  R2004     1.2953507900238037e-01
    z[4,5,4]  R2005     1.4764599502086639e-01
    z[4,5,4]  R2006     -1.5081711113452911e-01
    z[4,5,4]  R2007     -4.2096090316772461e-01
    z[4,5,4]  R2008     -5.1058534532785416e-02
    z[4,5,4]  R2009     0.531574547290802
    z[4,5,4]  R2010     2.7152130007743835e-01
    z[4,5,4]  R2011     -3.3534345030784607e-01
    z[4,5,4]  R2012     -1.8669579923152924e-01
    z[4,5,4]  R2013     1.6961827874183655e-01
    z[4,5,4]  R2014     -3.1581020355224609e-01
    z[4,5,4]  R2015     1.9509436190128326e-01
    z[4,5,4]  R2016     1.2445946782827377e-01
    z[4,5,4]  R2017     2.5597405433654785e-01
    z[4,5,4]  R2018     1.2232623249292374e-01
    z[4,5,4]  R2019     4.0399497747421265e-01
    z[4,5,4]  R2020     3.1204903498291969e-02
    z[4,5,4]  R2021     -5.0547176599502563e-01
    z[4,5,4]  R2022     -4.9647606909275055e-02
    z[4,5,4]  R2023     -1.7314553260803223e-01
    z[4,5,4]  R2024     4.5614200830459595e-01
    z[4,5,4]  R2025     -5.0045979022979736e-01
    z[4,5,4]  R2026     -1.6497291624546051e-01
    z[4,5,4]  R2027     -1.6790528595447540e-01
    z[4,5,4]  R2028     1.5428660809993744e-01
    z[4,5,4]  R2029     1.2442489713430405e-01
    z[4,5,4]  R2030     -1.4730221033096313e-01
    z[4,5,4]  R2031     2.1390931680798531e-02
    z[4,5,4]  R2032     -1.4637741446495056e-01
    z[4,5,4]  R2033     -3.1215709447860718e-01
    z[4,5,4]  R2034     -1.3079211115837097e-01
    z[4,5,4]  R2035     4.3404512107372284e-02
    z[4,5,4]  R2036     -0.203762024641037
    z[4,5,4]  R2037     -1.7515948414802551e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1971     -1
    z[4,5,5]  R1972     1
    z[4,5,5]  R1975     -5.4863101243972778e-01
    z[4,5,5]  R1976     -1.5581648051738739e-01
    z[4,5,5]  R1977     2.8255107998847961e-01
    z[4,5,5]  R1978     0.547233521938324
    z[4,5,5]  R1979     -2.1732759475708008e-01
    z[4,5,5]  R1980     5.8345657587051392e-01
    z[4,5,5]  R1981     2.5110721588134766e-01
    z[4,5,5]  R1982     3.9948937296867371e-01
    z[4,5,5]  R1983     -6.5776187181472778e-01
    z[4,5,5]  R1984     -4.4543027877807617e-01
    z[4,5,5]  R1985     3.4748513251543045e-02
    z[4,5,5]  R1986     -6.3901171088218689e-02
    z[4,5,5]  R1987     0.0547671839594841
    z[4,5,5]  R1988     -3.2210844755172729e-01
    z[4,5,5]  R1989     1.5378751559183002e-03
    z[4,5,5]  R1990     -2.8517019748687744e-01
    z[4,5,5]  R1991     -2.0629416406154633e-01
    z[4,5,5]  R1992     3.6738982796669006e-01
    z[4,5,5]  R1993     0.316733181476593
    z[4,5,5]  R1994     -1.4620324969291687e-01
    z[4,5,5]  R1995     -2.4634061753749847e-01
    z[4,5,5]  R1996     -2.4586874246597290e-01
    z[4,5,5]  R1997     1.2412620335817337e-01
    z[4,5,5]  R1998     -1.6672298312187195e-01
    z[4,5,5]  R1999     -1.2884598970413208e-01
    z[4,5,5]  R2000     1.0271816700696945e-01
    z[4,5,5]  R2001     3.1391736865043640e-01
    z[4,5,5]  R2002     2.5652840733528137e-02
    z[4,5,5]  R2003     2.3053072392940521e-01
    z[4,5,5]  R2004     1.1248376965522766e-01
    z[4,5,5]  R2005     3.8957402110099792e-01
    z[4,5,5]  R2006     1.6114808619022369e-01
    z[4,5,5]  R2007     1.8642856180667877e-01
    z[4,5,5]  R2008     -2.3808676004409790e-01
    z[4,5,5]  R2009     3.9120021462440491e-01
    z[4,5,5]  R2010     5.1130358129739761e-02
    z[4,5,5]  R2011     -5.8744996786117554e-01
    z[4,5,5]  R2012     -0.635794460773468
    z[4,5,5]  R2013     -3.6425021290779114e-01
    z[4,5,5]  R2014     -1.0354480147361755e-01
    z[4,5,5]  R2015     -1.9417276978492737e-01
    z[4,5,5]  R2016     -1.1577197909355164e-01
    z[4,5,5]  R2017     -5.5306226015090942e-01
    z[4,5,5]  R2018     4.1811850666999817e-01
    z[4,5,5]  R2019     4.9402302503585815e-01
    z[4,5,5]  R2020     0.091541588306427
    z[4,5,5]  R2021     -7.0513077080249786e-02
    z[4,5,5]  R2022     -5.9386390447616577e-01
    z[4,5,5]  R2023     -0.101526640355587
    z[4,5,5]  R2024     -4.2905488610267639e-01
    z[4,5,5]  R2025     2.7670687437057495e-01
    z[4,5,5]  R2026     2.5069864466786385e-02
    z[4,5,5]  R2027     -1.7510496079921722e-01
    z[4,5,5]  R2028     -4.3672375380992889e-02
    z[4,5,5]  R2029     1.1781078577041626e-01
    z[4,5,5]  R2030     1.1512167006731033e-01
    z[4,5,5]  R2031     -1.6194142401218414e-01
    z[4,5,5]  R2032     -2.0817534625530243e-01
    z[4,5,5]  R2033     -0.283462256193161
    z[4,5,5]  R2034     -7.9871386289596558e-02
    z[4,5,5]  R2035     -1.1518055945634842e-01
    z[4,5,5]  R2036     -0.13038270175457
    z[4,5,5]  R2037     2.5660738348960876e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1973     -1
    z[4,5,6]  R1974     1
    z[4,5,6]  R1975     -5.5123817175626755e-02
    z[4,5,6]  R1976     -2.1601729094982147e-01
    z[4,5,6]  R1977     -5.9111166000366211e-01
    z[4,5,6]  R1978     3.8165113329887390e-01
    z[4,5,6]  R1979     2.9850912094116211e-01
    z[4,5,6]  R1980     4.4890460558235645e-03
    z[4,5,6]  R1981     1.0052711516618729e-01
    z[4,5,6]  R1982     3.4478133916854858e-01
    z[4,5,6]  R1983     -6.3074447214603424e-02
    z[4,5,6]  R1984     -1.5426431596279144e-01
    z[4,5,6]  R1985     8.7373800575733185e-02
    z[4,5,6]  R1986     3.5178017616271973e-01
    z[4,5,6]  R1987     4.2216736078262329e-01
    z[4,5,6]  R1988     -2.7257287502288818e-01
    z[4,5,6]  R1989     3.2031521201133728e-02
    z[4,5,6]  R1990     9.6217900514602661e-02
    z[4,5,6]  R1991     1.2899653613567352e-01
    z[4,5,6]  R1992     2.7537092566490173e-01
    z[4,5,6]  R1993     -2.3304922506213188e-02
    z[4,5,6]  R1994     -2.9980620741844177e-01
    z[4,5,6]  R1995     -3.4443486481904984e-02
    z[4,5,6]  R1996     4.4073525071144104e-01
    z[4,5,6]  R1997     9.9140271544456482e-02
    z[4,5,6]  R1998     3.8008275628089905e-01
    z[4,5,6]  R1999     -3.0191898345947266e-01
    z[4,5,6]  R2000     5.1026362180709839e-01
    z[4,5,6]  R2001     -1.0900168120861053e-01
    z[4,5,6]  R2002     2.0575378835201263e-01
    z[4,5,6]  R2003     -4.5538637042045593e-01
    z[4,5,6]  R2004     -4.2605799436569214e-01
    z[4,5,6]  R2005     7.4714791774749756e-01
    z[4,5,6]  R2006     3.9952522516250610e-01
    z[4,5,6]  R2007     -3.4733321517705917e-02
    z[4,5,6]  R2008     1.6800431907176971e-01
    z[4,5,6]  R2009     -4.8735892772674561e-01
    z[4,5,6]  R2010     -4.0737181901931763e-01
    z[4,5,6]  R2011     1.0580208152532578e-02
    z[4,5,6]  R2012     2.9227675870060921e-02
    z[4,5,6]  R2013     3.3393511176109314e-01
    z[4,5,6]  R2014     1.6795925796031952e-02
    z[4,5,6]  R2015     5.1053303480148315e-01
    z[4,5,6]  R2016     5.2124512195587158e-01
    z[4,5,6]  R2017     -4.1547316312789917e-01
    z[4,5,6]  R2018     -5.4954618215560913e-02
    z[4,5,6]  R2019     0.691472053527832
    z[4,5,6]  R2020     -0.139152392745018
    z[4,5,6]  R2021     -3.5400897264480591e-01
    z[4,5,6]  R2022     -1.1064770072698593e-01
    z[4,5,6]  R2023     1.7837829887866974e-01
    z[4,5,6]  R2024     1.2031418085098267e-01
    z[4,5,6]  R2025     1.7815624177455902e-01
    z[4,5,6]  R2026     3.4017577767372131e-01
    z[4,5,6]  R2027     3.4392920136451721e-01
    z[4,5,6]  R2028     8.1533983349800110e-02
    z[4,5,6]  R2029     -2.6450985670089722e-01
    z[4,5,6]  R2030     3.0140694230794907e-02
    z[4,5,6]  R2031     -3.3923369646072388e-01
    z[4,5,6]  R2032     1.1259863525629044e-01
    z[4,5,6]  R2033     1.2439736723899841e-01
    z[4,5,6]  R2034     -1.8044370412826538e-01
    z[4,5,6]  R2035     0.0785333588719368
    z[4,5,6]  R2036     1.3021877408027649e-01
    z[4,5,6]  R2037     2.2515854239463806e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2038     -1
    z[5,4,0]  R2039     1
    z[5,4,0]  R2052     -1.4013829827308655e-01
    z[5,4,0]  R2053     -2.1680450439453125e-01
    z[5,4,0]  R2054     -5.3905218839645386e-01
    z[5,4,0]  R2055     4.9205985665321350e-01
    z[5,4,0]  R2056     3.9730939269065857e-01
    z[5,4,0]  R2057     5.3545570373535156e-01
    z[5,4,0]  R2058     3.9797511696815491e-01
    z[5,4,0]  R2059     4.7793468832969666e-01
    z[5,4,0]  R2060     5.0514614582061768e-01
    z[5,4,0]  R2061     5.3256362676620483e-01
    z[5,4,0]  R2062     -1.5803965926170349e-01
    z[5,4,0]  R2063     -2.6606826111674309e-02
    z[5,4,0]  R2064     -1.0368255898356438e-02
    z[5,4,0]  R2065     1.1904559284448624e-01
    z[5,4,0]  R2066     1.7774741351604462e-01
    z[5,4,0]  R2067     -1.5899810194969177e-01
    z[5,4,0]  R2068     5.0254738330841064e-01
    z[5,4,0]  R2069     9.1045953333377838e-02
    z[5,4,0]  R2070     -0.510917067527771
    z[5,4,0]  R2071     -4.8073145747184753e-01
    z[5,4,0]  R2072     6.4875298738479614e-01
    z[5,4,0]  R2073     4.3376949429512024e-01
    z[5,4,0]  R2074     4.7673863172531128e-01
    z[5,4,0]  R2075     5.3648990392684937e-01
    z[5,4,0]  R2076     5.0994259119033813e-01
    z[5,4,0]  R2077     5.7621508836746216e-01
    z[5,4,0]  R2078     4.2194086313247681e-01
    z[5,4,0]  R2079     5.3625619411468506e-01
    z[5,4,0]  R2080     4.2689137160778046e-02
    z[5,4,0]  R2081     -9.4247311353683472e-02
    z[5,4,0]  R2082     -3.3462586998939514e-01
    z[5,4,0]  R2083     -1.8386751413345337e-01
    z[5,4,0]  R2084     -3.9521700143814087e-01
    z[5,4,0]  R2085     -2.3452313244342804e-01
    z[5,4,0]  R2086     -2.2922654449939728e-01
    z[5,4,0]  R2087     -1.8005660176277161e-01
    z[5,4,0]  R2088     -8.4693320095539093e-02
    z[5,4,0]  R2089     1.8776130676269531e-01
    z[5,4,0]  R2090     1.3694921135902405e-01
    z[5,4,0]  R2091     4.2758950591087341e-01
    z[5,4,0]  R2092     -4.0578305721282959e-01
    z[5,4,0]  R2093     -4.7967612743377686e-01
    z[5,4,0]  R2094     -4.0851479768753052e-01
    z[5,4,0]  R2095     -5.3752940893173218e-01
    z[5,4,0]  R2096     5.3640712052583694e-02
    z[5,4,0]  R2097     -2.6883631944656372e-01
    z[5,4,0]  R2098     -5.7874453067779541e-01
    z[5,4,0]  R2099     1.5037380158901215e-01
    z[5,4,0]  R2100     -9.9909491837024689e-02
    z[5,4,0]  R2101     -4.3336942791938782e-01
    z[5,4,0]  R2102     -1.9610394537448883e-01
    z[5,4,0]  R2103     -3.5530373454093933e-02
    z[5,4,0]  R2104     -1.0527639091014862e-01
    z[5,4,0]  R2105     8.7870702147483826e-02
    z[5,4,0]  R2106     -7.0698693394660950e-02
    z[5,4,0]  R2107     2.8746232390403748e-01
    z[5,4,0]  R2108     2.2877755761146545e-01
    z[5,4,0]  R2109     2.9575052857398987e-01
    z[5,4,0]  R2110     1.5770190954208374e-01
    z[5,4,0]  R2111     1.7726863920688629e-01
    z[5,4,0]  R2112     -3.2168358564376831e-02
    z[5,4,0]  R2113     0.100483737885952
    z[5,4,0]  R2114     0.355254590511322
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2040     -1
    z[5,4,1]  R2041     1
    z[5,4,1]  R2052     -8.1982904672622681e-01
    z[5,4,1]  R2053     -2.2912929952144623e-01
    z[5,4,1]  R2054     -3.9167895913124084e-01
    z[5,4,1]  R2055     4.6158227324485779e-01
    z[5,4,1]  R2056     6.3057202100753784e-01
    z[5,4,1]  R2057     4.6942472457885742e-01
    z[5,4,1]  R2058     4.7702306509017944e-01
    z[5,4,1]  R2059     4.2926475405693054e-01
    z[5,4,1]  R2060     4.4876602292060852e-01
    z[5,4,1]  R2061     3.6234620213508606e-01
    z[5,4,1]  R2062     1.2943477928638458e-01
    z[5,4,1]  R2063     -6.0232721269130707e-02
    z[5,4,1]  R2064     9.3906730413436890e-01
    z[5,4,1]  R2065     0.767741858959198
    z[5,4,1]  R2066     7.5549668073654175e-01
    z[5,4,1]  R2067     5.7971423864364624e-01
    z[5,4,1]  R2068     4.6100342273712158e-01
    z[5,4,1]  R2069     7.0692896842956543e-01
    z[5,4,1]  R2070     4.7931188344955444e-01
    z[5,4,1]  R2071     6.4421904087066650e-01
    z[5,4,1]  R2072     7.3177880048751831e-01
    z[5,4,1]  R2073     8.4226936101913452e-01
    z[5,4,1]  R2074     8.3228170871734619e-01
    z[5,4,1]  R2075     7.5504338741302490e-01
    z[5,4,1]  R2076     7.6662635803222656e-01
    z[5,4,1]  R2077     6.8480169773101807e-01
    z[5,4,1]  R2078     8.0933910608291626e-01
    z[5,4,1]  R2079     6.9874179363250732e-01
    z[5,4,1]  R2080     7.6158493757247925e-01
    z[5,4,1]  R2081     6.6127419471740723e-01
    z[5,4,1]  R2082     3.8000056147575378e-01
    z[5,4,1]  R2083     -1.9344460964202881e-01
    z[5,4,1]  R2084     -5.0770647823810577e-02
    z[5,4,1]  R2085     -1.6699281334877014e-01
    z[5,4,1]  R2086     -3.1540206074714661e-01
    z[5,4,1]  R2087     -2.5305259227752686e-01
    z[5,4,1]  R2088     4.4007140398025513e-01
    z[5,4,1]  R2089     -1.3627345860004425e-01
    z[5,4,1]  R2090     -7.0837664604187012e-01
    z[5,4,1]  R2091     -6.7598110437393188e-01
    z[5,4,1]  R2092     4.9739986658096313e-01
    z[5,4,1]  R2093     -5.7361096143722534e-01
    z[5,4,1]  R2094     -3.8349729776382446e-01
    z[5,4,1]  R2095     -4.3888527154922485e-01
    z[5,4,1]  R2096     -0.254909485578537
    z[5,4,1]  R2097     -2.1825772523880005e-01
    z[5,4,1]  R2098     -0.502673864364624
    z[5,4,1]  R2099     -4.8204681277275085e-01
    z[5,4,1]  R2100     -4.0451011061668396e-01
    z[5,4,1]  R2101     -3.0568674206733704e-01
    z[5,4,1]  R2102     -7.8370010852813721e-01
    z[5,4,1]  R2103     -6.6754847764968872e-01
    z[5,4,1]  R2104     -6.5499776601791382e-01
    z[5,4,1]  R2105     -6.1614960432052612e-01
    z[5,4,1]  R2106     -0.886188268661499
    z[5,4,1]  R2107     -7.0449334383010864e-01
    z[5,4,1]  R2108     -8.5056900978088379e-01
    z[5,4,1]  R2109     -7.7175575494766235e-01
    z[5,4,1]  R2110     -7.2972613573074341e-01
    z[5,4,1]  R2111     -5.1401132345199585e-01
    z[5,4,1]  R2112     4.5769292116165161e-01
    z[5,4,1]  R2113     -4.6682092547416687e-01
    z[5,4,1]  R2114     4.2010107636451721e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2042     -1
    z[5,4,2]  R2043     1
    z[5,4,2]  R2052     -3.5748252272605896e-01
    z[5,4,2]  R2053     -3.6852023005485535e-01
    z[5,4,2]  R2054     4.9215239286422729e-01
    z[5,4,2]  R2055     2.5748586654663086e-01
    z[5,4,2]  R2056     -6.4546324312686920e-02
    z[5,4,2]  R2057     -1.7670178413391113e-01
    z[5,4,2]  R2058     -6.9458144903182983e-01
    z[5,4,2]  R2059     4.8162847757339478e-01
    z[5,4,2]  R2060     -4.8755022883415222e-01
    z[5,4,2]  R2061     1.5100403130054474e-01
    z[5,4,2]  R2062     2.8145718574523926e-01
    z[5,4,2]  R2063     2.6563405990600586e-01
    z[5,4,2]  R2064     -1.6246227920055389e-01
    z[5,4,2]  R2065     1.0238543152809143e-01
    z[5,4,2]  R2066     -0.0772957056760788
    z[5,4,2]  R2067     -3.6308398842811584e-01
    z[5,4,2]  R2068     1.7393574118614197e-01
    z[5,4,2]  R2069     -2.4055273830890656e-01
    z[5,4,2]  R2070     -5.8491069078445435e-01
    z[5,4,2]  R2071     -4.0013724565505981e-01
    z[5,4,2]  R2072     3.0864465981721878e-02
    z[5,4,2]  R2073     4.3979067355394363e-02
    z[5,4,2]  R2074     -2.0543819665908813e-01
    z[5,4,2]  R2075     -1.1190900579094887e-02
    z[5,4,2]  R2076     2.6367226243019104e-01
    z[5,4,2]  R2077     -5.7455807924270630e-02
    z[5,4,2]  R2078     -2.1146422252058983e-02
    z[5,4,2]  R2079     -3.4737319219857454e-03
    z[5,4,2]  R2080     -5.0904309749603271e-01
    z[5,4,2]  R2081     -6.3758021593093872e-01
    z[5,4,2]  R2082     -2.3803240060806274e-01
    z[5,4,2]  R2083     -0.604768693447113
    z[5,4,2]  R2084     2.7401563525199890e-01
    z[5,4,2]  R2085     -5.3405463695526123e-01
    z[5,4,2]  R2086     -4.3609780073165894e-01
    z[5,4,2]  R2087     -0.746088445186615
    z[5,4,2]  R2088     -7.9301851987838745e-01
    z[5,4,2]  R2089     -5.0941503047943115e-01
    z[5,4,2]  R2090     -4.7889359295368195e-02
    z[5,4,2]  R2091     3.0989333987236023e-01
    z[5,4,2]  R2092     4.1016179323196411e-01
    z[5,4,2]  R2093     2.2047109901905060e-01
    z[5,4,2]  R2094     1.9793987274169922e-01
    z[5,4,2]  R2095     2.1866784989833832e-01
    z[5,4,2]  R2096     -1.5877494215965271e-01
    z[5,4,2]  R2097     -6.7958123981952667e-02
    z[5,4,2]  R2098     4.6555814146995544e-01
    z[5,4,2]  R2099     4.3209385871887207e-01
    z[5,4,2]  R2100     5.6076145172119141e-01
    z[5,4,2]  R2101     2.6527991890907288e-01
    z[5,4,2]  R2102     1.3881656527519226e-01
    z[5,4,2]  R2103     1.2538301944732666e-01
    z[5,4,2]  R2104     -1.1175126768648624e-02
    z[5,4,2]  R2105     -3.6341828107833862e-01
    z[5,4,2]  R2106     -1.0333603620529175e-01
    z[5,4,2]  R2107     8.0590806901454926e-03
    z[5,4,2]  R2108     1.1250586062669754e-01
    z[5,4,2]  R2109     3.1465390324592590e-01
    z[5,4,2]  R2110     1.7359924316406250e-01
    z[5,4,2]  R2111     -4.0520984679460526e-02
    z[5,4,2]  R2112     3.7315767258405685e-02
    z[5,4,2]  R2113     6.2014883756637573e-01
    z[5,4,2]  R2114     6.1589145660400391e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2044     -1
    z[5,4,3]  R2045     1
    z[5,4,3]  R2052     -3.0484458804130554e-01
    z[5,4,3]  R2053     3.0258995294570923e-01
    z[5,4,3]  R2054     2.6740673184394836e-01
    z[5,4,3]  R2055     -1.4441390335559845e-01
    z[5,4,3]  R2056     2.0342398434877396e-02
    z[5,4,3]  R2057     4.3444547057151794e-01
    z[5,4,3]  R2058     1.4450505375862122e-01
    z[5,4,3]  R2059     1.3760606944561005e-01
    z[5,4,3]  R2060     7.1704357862472534e-02
    z[5,4,3]  R2061     1.3513167202472687e-01
    z[5,4,3]  R2062     -0.828399121761322
    z[5,4,3]  R2063     -1.9924451410770416e-01
    z[5,4,3]  R2064     2.5086668133735657e-01
    z[5,4,3]  R2065     -1.1031280271708965e-02
    z[5,4,3]  R2066     1.5580029785633087e-01
    z[5,4,3]  R2067     6.5932929515838623e-01
    z[5,4,3]  R2068     3.1311213970184326e-01
    z[5,4,3]  R2069     2.7446320652961731e-01
    z[5,4,3]  R2070     1.5342476963996887e-01
    z[5,4,3]  R2071     -1.2894946336746216e-01
    z[5,4,3]  R2072     -1.0152570903301239e-01
    z[5,4,3]  R2073     3.4143622964620590e-02
    z[5,4,3]  R2074     4.4309478253126144e-02
    z[5,4,3]  R2075     -1.4164656400680542e-02
    z[5,4,3]  R2076     7.2648137807846069e-02
    z[5,4,3]  R2077     -4.9537453800439835e-02
    z[5,4,3]  R2078     0.332329660654068
    z[5,4,3]  R2079     4.5039889216423035e-01
    z[5,4,3]  R2080     2.8907701373100281e-01
    z[5,4,3]  R2081     1.0043850168585777e-02
    z[5,4,3]  R2082     6.0357111692428589e-01
    z[5,4,3]  R2083     6.0565865039825439e-01
    z[5,4,3]  R2084     5.6753265857696533e-01
    z[5,4,3]  R2085     3.5742005705833435e-01
    z[5,4,3]  R2086     6.9856691360473633e-01
    z[5,4,3]  R2087     -2.1257533226162195e-03
    z[5,4,3]  R2088     -1.0303667932748795e-01
    z[5,4,3]  R2089     4.2567637562751770e-01
    z[5,4,3]  R2090     -8.1853784620761871e-02
    z[5,4,3]  R2091     -2.2696793079376221e-02
    z[5,4,3]  R2092     -1.1700502038002014e-01
    z[5,4,3]  R2093     -3.2574126124382019e-01
    z[5,4,3]  R2094     -6.5682113170623779e-01
    z[5,4,3]  R2095     -4.3825656175613403e-01
    z[5,4,3]  R2096     -9.3386447429656982e-01
    z[5,4,3]  R2097     -8.6636233329772949e-01
    z[5,4,3]  R2098     -1.7136411368846893e-01
    z[5,4,3]  R2099     -4.0631026029586792e-01
    z[5,4,3]  R2100     -6.3331335783004761e-01
    z[5,4,3]  R2101     -0.537703275680542
    z[5,4,3]  R2102     -5.1382768154144287e-01
    z[5,4,3]  R2103     -4.6713244915008545e-01
    z[5,4,3]  R2104     -6.0241687297821045e-01
    z[5,4,3]  R2105     -5.1698893308639526e-01
    z[5,4,3]  R2106     5.8623269200325012e-02
    z[5,4,3]  R2107     -3.8728532195091248e-01
    z[5,4,3]  R2108     -1.6162315011024475e-01
    z[5,4,3]  R2109     -0.192413792014122
    z[5,4,3]  R2110     -3.7569716572761536e-01
    z[5,4,3]  R2111     -7.0126241445541382e-01
    z[5,4,3]  R2112     2.3726058006286621e-01
    z[5,4,3]  R2113     4.2315709590911865e-01
    z[5,4,3]  R2114     -3.2375445961952209e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2046     -1
    z[5,4,4]  R2047     1
    z[5,4,4]  R2052     -5.1058534532785416e-02
    z[5,4,4]  R2053     0.531574547290802
    z[5,4,4]  R2054     2.7152130007743835e-01
    z[5,4,4]  R2055     -3.3534345030784607e-01
    z[5,4,4]  R2056     -1.8669579923152924e-01
    z[5,4,4]  R2057     1.6961827874183655e-01
    z[5,4,4]  R2058     -3.1581020355224609e-01
    z[5,4,4]  R2059     1.9509436190128326e-01
    z[5,4,4]  R2060     1.2445946782827377e-01
    z[5,4,4]  R2061     2.5597405433654785e-01
    z[5,4,4]  R2062     1.2232623249292374e-01
    z[5,4,4]  R2063     4.0399497747421265e-01
    z[5,4,4]  R2064     3.1204903498291969e-02
    z[5,4,4]  R2065     -5.0547176599502563e-01
    z[5,4,4]  R2066     -4.9647606909275055e-02
    z[5,4,4]  R2067     -1.7314553260803223e-01
    z[5,4,4]  R2068     4.5614200830459595e-01
    z[5,4,4]  R2069     -5.0045979022979736e-01
    z[5,4,4]  R2070     -1.6497291624546051e-01
    z[5,4,4]  R2071     -1.6790528595447540e-01
    z[5,4,4]  R2072     1.5428660809993744e-01
    z[5,4,4]  R2073     1.2442489713430405e-01
    z[5,4,4]  R2074     -1.4730221033096313e-01
    z[5,4,4]  R2075     2.1390931680798531e-02
    z[5,4,4]  R2076     -1.4637741446495056e-01
    z[5,4,4]  R2077     -3.1215709447860718e-01
    z[5,4,4]  R2078     -1.3079211115837097e-01
    z[5,4,4]  R2079     4.3404512107372284e-02
    z[5,4,4]  R2080     -0.203762024641037
    z[5,4,4]  R2081     -1.7515948414802551e-01
    z[5,4,4]  R2082     -0.136503204703331
    z[5,4,4]  R2083     -3.5392385721206665e-01
    z[5,4,4]  R2084     -1.2165436148643494e-01
    z[5,4,4]  R2085     2.4295400083065033e-01
    z[5,4,4]  R2086     1.8292248249053955e-01
    z[5,4,4]  R2087     0.0803111121058464
    z[5,4,4]  R2088     -2.9412344098091125e-01
    z[5,4,4]  R2089     -4.7645080089569092e-01
    z[5,4,4]  R2090     1.8391543626785278e-01
    z[5,4,4]  R2091     -2.0362272858619690e-01
    z[5,4,4]  R2092     6.3021337985992432e-01
    z[5,4,4]  R2093     -3.9791175723075867e-01
    z[5,4,4]  R2094     1.8500414490699768e-01
    z[5,4,4]  R2095     -3.1702926754951477e-01
    z[5,4,4]  R2096     -1.8385635316371918e-01
    z[5,4,4]  R2097     -1.8522606790065765e-01
    z[5,4,4]  R2098     3.2720991969108582e-01
    z[5,4,4]  R2099     4.2710778117179871e-01
    z[5,4,4]  R2100     -9.9936813116073608e-02
    z[5,4,4]  R2101     4.9798506498336792e-01
    z[5,4,4]  R2102     -4.6888455748558044e-02
    z[5,4,4]  R2103     2.5393700599670410e-01
    z[5,4,4]  R2104     4.1427984833717346e-01
    z[5,4,4]  R2105     2.0255523920059204e-01
    z[5,4,4]  R2106     2.9631167650222778e-01
    z[5,4,4]  R2107     -8.9310482144355774e-03
    z[5,4,4]  R2108     -2.7383950352668762e-01
    z[5,4,4]  R2109     3.7135148048400879e-01
    z[5,4,4]  R2110     1.0403730720281601e-01
    z[5,4,4]  R2111     1.2953507900238037e-01
    z[5,4,4]  R2112     1.4764599502086639e-01
    z[5,4,4]  R2113     -1.5081711113452911e-01
    z[5,4,4]  R2114     -4.2096090316772461e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2048     -1
    z[5,4,5]  R2049     1
    z[5,4,5]  R2052     -2.3808676004409790e-01
    z[5,4,5]  R2053     3.9120021462440491e-01
    z[5,4,5]  R2054     5.1130358129739761e-02
    z[5,4,5]  R2055     -5.8744996786117554e-01
    z[5,4,5]  R2056     -0.635794460773468
    z[5,4,5]  R2057     -3.6425021290779114e-01
    z[5,4,5]  R2058     -1.0354480147361755e-01
    z[5,4,5]  R2059     -1.9417276978492737e-01
    z[5,4,5]  R2060     -1.1577197909355164e-01
    z[5,4,5]  R2061     -5.5306226015090942e-01
    z[5,4,5]  R2062     4.1811850666999817e-01
    z[5,4,5]  R2063     4.9402302503585815e-01
    z[5,4,5]  R2064     0.091541588306427
    z[5,4,5]  R2065     -7.0513077080249786e-02
    z[5,4,5]  R2066     -5.9386390447616577e-01
    z[5,4,5]  R2067     -0.101526640355587
    z[5,4,5]  R2068     -4.2905488610267639e-01
    z[5,4,5]  R2069     2.7670687437057495e-01
    z[5,4,5]  R2070     2.5069864466786385e-02
    z[5,4,5]  R2071     -1.7510496079921722e-01
    z[5,4,5]  R2072     -4.3672375380992889e-02
    z[5,4,5]  R2073     1.1781078577041626e-01
    z[5,4,5]  R2074     1.1512167006731033e-01
    z[5,4,5]  R2075     -1.6194142401218414e-01
    z[5,4,5]  R2076     -2.0817534625530243e-01
    z[5,4,5]  R2077     -0.283462256193161
    z[5,4,5]  R2078     -7.9871386289596558e-02
    z[5,4,5]  R2079     -1.1518055945634842e-01
    z[5,4,5]  R2080     -0.13038270175457
    z[5,4,5]  R2081     2.5660738348960876e-01
    z[5,4,5]  R2082     -5.4863101243972778e-01
    z[5,4,5]  R2083     -1.5581648051738739e-01
    z[5,4,5]  R2084     2.8255107998847961e-01
    z[5,4,5]  R2085     0.547233521938324
    z[5,4,5]  R2086     -2.1732759475708008e-01
    z[5,4,5]  R2087     5.8345657587051392e-01
    z[5,4,5]  R2088     2.5110721588134766e-01
    z[5,4,5]  R2089     3.9948937296867371e-01
    z[5,4,5]  R2090     -6.5776187181472778e-01
    z[5,4,5]  R2091     -4.4543027877807617e-01
    z[5,4,5]  R2092     3.4748513251543045e-02
    z[5,4,5]  R2093     -6.3901171088218689e-02
    z[5,4,5]  R2094     0.0547671839594841
    z[5,4,5]  R2095     -3.2210844755172729e-01
    z[5,4,5]  R2096     1.5378751559183002e-03
    z[5,4,5]  R2097     -2.8517019748687744e-01
    z[5,4,5]  R2098     -2.0629416406154633e-01
    z[5,4,5]  R2099     3.6738982796669006e-01
    z[5,4,5]  R2100     0.316733181476593
    z[5,4,5]  R2101     -1.4620324969291687e-01
    z[5,4,5]  R2102     -2.4634061753749847e-01
    z[5,4,5]  R2103     -2.4586874246597290e-01
    z[5,4,5]  R2104     1.2412620335817337e-01
    z[5,4,5]  R2105     -1.6672298312187195e-01
    z[5,4,5]  R2106     -1.2884598970413208e-01
    z[5,4,5]  R2107     1.0271816700696945e-01
    z[5,4,5]  R2108     3.1391736865043640e-01
    z[5,4,5]  R2109     2.5652840733528137e-02
    z[5,4,5]  R2110     2.3053072392940521e-01
    z[5,4,5]  R2111     1.1248376965522766e-01
    z[5,4,5]  R2112     3.8957402110099792e-01
    z[5,4,5]  R2113     1.6114808619022369e-01
    z[5,4,5]  R2114     1.8642856180667877e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2050     -1
    z[5,4,6]  R2051     1
    z[5,4,6]  R2052     1.6800431907176971e-01
    z[5,4,6]  R2053     -4.8735892772674561e-01
    z[5,4,6]  R2054     -4.0737181901931763e-01
    z[5,4,6]  R2055     1.0580208152532578e-02
    z[5,4,6]  R2056     2.9227675870060921e-02
    z[5,4,6]  R2057     3.3393511176109314e-01
    z[5,4,6]  R2058     1.6795925796031952e-02
    z[5,4,6]  R2059     5.1053303480148315e-01
    z[5,4,6]  R2060     5.2124512195587158e-01
    z[5,4,6]  R2061     -4.1547316312789917e-01
    z[5,4,6]  R2062     -5.4954618215560913e-02
    z[5,4,6]  R2063     0.691472053527832
    z[5,4,6]  R2064     -0.139152392745018
    z[5,4,6]  R2065     -3.5400897264480591e-01
    z[5,4,6]  R2066     -1.1064770072698593e-01
    z[5,4,6]  R2067     1.7837829887866974e-01
    z[5,4,6]  R2068     1.2031418085098267e-01
    z[5,4,6]  R2069     1.7815624177455902e-01
    z[5,4,6]  R2070     3.4017577767372131e-01
    z[5,4,6]  R2071     3.4392920136451721e-01
    z[5,4,6]  R2072     8.1533983349800110e-02
    z[5,4,6]  R2073     -2.6450985670089722e-01
    z[5,4,6]  R2074     3.0140694230794907e-02
    z[5,4,6]  R2075     -3.3923369646072388e-01
    z[5,4,6]  R2076     1.1259863525629044e-01
    z[5,4,6]  R2077     1.2439736723899841e-01
    z[5,4,6]  R2078     -1.8044370412826538e-01
    z[5,4,6]  R2079     0.0785333588719368
    z[5,4,6]  R2080     1.3021877408027649e-01
    z[5,4,6]  R2081     2.2515854239463806e-01
    z[5,4,6]  R2082     -5.5123817175626755e-02
    z[5,4,6]  R2083     -2.1601729094982147e-01
    z[5,4,6]  R2084     -5.9111166000366211e-01
    z[5,4,6]  R2085     3.8165113329887390e-01
    z[5,4,6]  R2086     2.9850912094116211e-01
    z[5,4,6]  R2087     4.4890460558235645e-03
    z[5,4,6]  R2088     1.0052711516618729e-01
    z[5,4,6]  R2089     3.4478133916854858e-01
    z[5,4,6]  R2090     -6.3074447214603424e-02
    z[5,4,6]  R2091     -1.5426431596279144e-01
    z[5,4,6]  R2092     8.7373800575733185e-02
    z[5,4,6]  R2093     3.5178017616271973e-01
    z[5,4,6]  R2094     4.2216736078262329e-01
    z[5,4,6]  R2095     -2.7257287502288818e-01
    z[5,4,6]  R2096     3.2031521201133728e-02
    z[5,4,6]  R2097     9.6217900514602661e-02
    z[5,4,6]  R2098     1.2899653613567352e-01
    z[5,4,6]  R2099     2.7537092566490173e-01
    z[5,4,6]  R2100     -2.3304922506213188e-02
    z[5,4,6]  R2101     -2.9980620741844177e-01
    z[5,4,6]  R2102     -3.4443486481904984e-02
    z[5,4,6]  R2103     4.4073525071144104e-01
    z[5,4,6]  R2104     9.9140271544456482e-02
    z[5,4,6]  R2105     3.8008275628089905e-01
    z[5,4,6]  R2106     -3.0191898345947266e-01
    z[5,4,6]  R2107     5.1026362180709839e-01
    z[5,4,6]  R2108     -1.0900168120861053e-01
    z[5,4,6]  R2109     2.0575378835201263e-01
    z[5,4,6]  R2110     -4.5538637042045593e-01
    z[5,4,6]  R2111     -4.2605799436569214e-01
    z[5,4,6]  R2112     7.4714791774749756e-01
    z[5,4,6]  R2113     3.9952522516250610e-01
    z[5,4,6]  R2114     -3.4733321517705917e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2162     -1
    z[5,6,0]  R2163     1
    z[5,6,0]  R2176     -1.4013829827308655e-01
    z[5,6,0]  R2177     -2.1680450439453125e-01
    z[5,6,0]  R2178     -5.3905218839645386e-01
    z[5,6,0]  R2179     4.9205985665321350e-01
    z[5,6,0]  R2180     3.9730939269065857e-01
    z[5,6,0]  R2181     5.3545570373535156e-01
    z[5,6,0]  R2182     3.9797511696815491e-01
    z[5,6,0]  R2183     4.7793468832969666e-01
    z[5,6,0]  R2184     5.0514614582061768e-01
    z[5,6,0]  R2185     5.3256362676620483e-01
    z[5,6,0]  R2186     -1.5803965926170349e-01
    z[5,6,0]  R2187     -2.6606826111674309e-02
    z[5,6,0]  R2188     -1.0368255898356438e-02
    z[5,6,0]  R2189     1.1904559284448624e-01
    z[5,6,0]  R2190     1.7774741351604462e-01
    z[5,6,0]  R2191     -1.5899810194969177e-01
    z[5,6,0]  R2192     5.0254738330841064e-01
    z[5,6,0]  R2193     9.1045953333377838e-02
    z[5,6,0]  R2194     -0.510917067527771
    z[5,6,0]  R2195     -4.8073145747184753e-01
    z[5,6,0]  R2196     6.4875298738479614e-01
    z[5,6,0]  R2197     4.3376949429512024e-01
    z[5,6,0]  R2198     4.7673863172531128e-01
    z[5,6,0]  R2199     5.3648990392684937e-01
    z[5,6,0]  R2200     5.0994259119033813e-01
    z[5,6,0]  R2201     5.7621508836746216e-01
    z[5,6,0]  R2202     4.2194086313247681e-01
    z[5,6,0]  R2203     5.3625619411468506e-01
    z[5,6,0]  R2204     4.2689137160778046e-02
    z[5,6,0]  R2205     -9.4247311353683472e-02
    z[5,6,0]  R2206     -8.7384122610092163e-01
    z[5,6,0]  R2207     -8.8748365640640259e-01
    z[5,6,0]  R2208     -9.4941294193267822e-01
    z[5,6,0]  R2209     -8.5786253213882446e-01
    z[5,6,0]  R2210     -9.1623759269714355e-01
    z[5,6,0]  R2211     -7.2450643777847290e-01
    z[5,6,0]  R2212     -9.3621307611465454e-01
    z[5,6,0]  R2213     -0.96856290102005
    z[5,6,0]  R2214     -8.3268773555755615e-01
    z[5,6,0]  R2215     -8.0606764554977417e-01
    z[5,6,0]  R2216     2.0103774964809418e-01
    z[5,6,0]  R2217     2.1778398752212524e-01
    z[5,6,0]  R2218     1.9404245913028717e-01
    z[5,6,0]  R2219     -0.0822681114077568
    z[5,6,0]  R2220     -2.5601822417229414e-03
    z[5,6,0]  R2221     2.5686609745025635e-01
    z[5,6,0]  R2222     2.3033238947391510e-01
    z[5,6,0]  R2223     3.1332874298095703e-01
    z[5,6,0]  R2224     -1.5054904855787754e-02
    z[5,6,0]  R2225     1.5797884762287140e-01
    z[5,6,0]  R2226     8.2420194149017334e-01
    z[5,6,0]  R2227     4.1432134807109833e-02
    z[5,6,0]  R2228     0.51854008436203
    z[5,6,0]  R2229     7.2541677951812744e-01
    z[5,6,0]  R2230     5.0932067632675171e-01
    z[5,6,0]  R2231     5.2500754594802856e-01
    z[5,6,0]  R2232     3.7646532058715820e-01
    z[5,6,0]  R2233     7.7187612652778625e-02
    z[5,6,0]  R2234     5.5519080162048340e-01
    z[5,6,0]  R2235     1.7107808589935303e-01
    z[5,6,0]  R2236     5.8747440576553345e-01
    z[5,6,0]  R2237     0.787808895111084
    z[5,6,0]  R2238     -1.2902888655662537e-01
    z[5,6,0]  R2239     7.3995554447174072e-01
    z[5,6,0]  R2240     1.4056351780891418e-01
    z[5,6,0]  R2241     6.9226735830307007e-01
    z[5,6,0]  R2242     2.5577588006854057e-02
    z[5,6,0]  R2243     8.1297689676284790e-01
    z[5,6,0]  R2244     5.6801873445510864e-01
    z[5,6,0]  R2245     -2.2160109877586365e-01
    z[5,6,0]  R2246     -1.0260418057441711e-03
    z[5,6,0]  R2247     3.2716092467308044e-01
    z[5,6,0]  R2248     4.2324984073638916e-01
    z[5,6,0]  R2249     4.8220828175544739e-02
    z[5,6,0]  R2250     0.618370532989502
    z[5,6,0]  R2251     5.8190727233886719e-01
    z[5,6,0]  R2252     3.2456271350383759e-02
    z[5,6,0]  R2253     -2.7239865064620972e-01
    z[5,6,0]  R2254     -3.8483291864395142e-01
    z[5,6,0]  R2255     7.6029294729232788e-01
    z[5,6,0]  R2256     -7.7624571323394775e-01
    z[5,6,0]  R2257     7.8828144073486328e-01
    z[5,6,0]  R2258     6.0670781135559082e-01
    z[5,6,0]  R2259     1.2974782288074493e-01
    z[5,6,0]  R2260     4.8424193263053894e-01
    z[5,6,0]  R2261     5.4049581289291382e-01
    z[5,6,0]  R2262     5.2734637260437012e-01
    z[5,6,0]  R2263     5.1648199558258057e-01
    z[5,6,0]  R2264     -3.5389885306358337e-01
    z[5,6,0]  R2265     0.0541507862508297
    z[5,6,0]  R2266     4.1410472989082336e-01
    z[5,6,0]  R2267     1.3840852305293083e-02
    z[5,6,0]  R2268     8.0886858701705933e-01
    z[5,6,0]  R2269     -4.1802600026130676e-01
    z[5,6,0]  R2270     -4.2783138155937195e-01
    z[5,6,0]  R2271     4.6446800231933594e-01
    z[5,6,0]  R2272     7.1531379222869873e-01
    z[5,6,0]  R2273     5.2551430463790894e-01
    z[5,6,0]  R2274     -3.5186198353767395e-01
    z[5,6,0]  R2275     7.0942497253417969e-01
    z[5,6,0]  R2276     8.9145672321319580e-01
    z[5,6,0]  R2277     4.3067368865013123e-01
    z[5,6,0]  R2278     -2.3954921960830688e-01
    z[5,6,0]  R2279     -5.8236384391784668e-01
    z[5,6,0]  R2280     6.2779515981674194e-01
    z[5,6,0]  R2281     5.2663028240203857e-01
    z[5,6,0]  R2282     4.8508965969085693e-01
    z[5,6,0]  R2283     8.4526282548904419e-01
    z[5,6,0]  R2284     -4.7784465551376343e-01
    z[5,6,0]  R2285     1.4369764365255833e-02
    z[5,6,0]  R2286     -7.4734479188919067e-01
    z[5,6,0]  R2287     6.1633431911468506e-01
    z[5,6,0]  R2288     0.401021271944046
    z[5,6,0]  R2289     4.8296386003494263e-01
    z[5,6,0]  R2290     0.680448055267334
    z[5,6,0]  R2291     -3.7621328234672546e-01
    z[5,6,0]  R2292     1.2038894742727280e-01
    z[5,6,0]  R2293     -1.7895002383738756e-04
    z[5,6,0]  R2294     -8.2989625632762909e-02
    z[5,6,0]  R2295     -2.8991684317588806e-02
    z[5,6,0]  R2296     -0.743486762046814
    z[5,6,0]  R2297     7.0977705717086792e-01
    z[5,6,0]  R2298     5.7753592729568481e-01
    z[5,6,0]  R2299     4.3028134107589722e-01
    z[5,6,0]  R2300     1.7088226974010468e-01
    z[5,6,0]  R2301     6.7804497666656971e-03
    z[5,6,0]  R2302     -6.1569139361381531e-02
    z[5,6,0]  R2303     3.5309992730617523e-02
    z[5,6,0]  R2304     -1.1695101112127304e-01
    z[5,6,0]  R2305     -4.5996751636266708e-02
    z[5,6,0]  R2306     7.2832182049751282e-03
    z[5,6,0]  R2307     6.1436778306961060e-01
    z[5,6,0]  R2308     5.5816221237182617e-01
    z[5,6,0]  R2309     -4.5648229122161865e-01
    z[5,6,0]  R2310     -3.2614029943943024e-02
    z[5,6,0]  R2311     -2.6928958296775818e-01
    z[5,6,0]  R2312     -1.3647805154323578e-01
    z[5,6,0]  R2313     2.3611165583133698e-02
    z[5,6,0]  R2314     -6.7060112953186035e-02
    z[5,6,0]  R2315     -0.0773346871137619
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2164     -1
    z[5,6,1]  R2165     1
    z[5,6,1]  R2176     -8.1982904672622681e-01
    z[5,6,1]  R2177     -2.2912929952144623e-01
    z[5,6,1]  R2178     -3.9167895913124084e-01
    z[5,6,1]  R2179     4.6158227324485779e-01
    z[5,6,1]  R2180     6.3057202100753784e-01
    z[5,6,1]  R2181     4.6942472457885742e-01
    z[5,6,1]  R2182     4.7702306509017944e-01
    z[5,6,1]  R2183     4.2926475405693054e-01
    z[5,6,1]  R2184     4.4876602292060852e-01
    z[5,6,1]  R2185     3.6234620213508606e-01
    z[5,6,1]  R2186     1.2943477928638458e-01
    z[5,6,1]  R2187     -6.0232721269130707e-02
    z[5,6,1]  R2188     9.3906730413436890e-01
    z[5,6,1]  R2189     0.767741858959198
    z[5,6,1]  R2190     7.5549668073654175e-01
    z[5,6,1]  R2191     5.7971423864364624e-01
    z[5,6,1]  R2192     4.6100342273712158e-01
    z[5,6,1]  R2193     7.0692896842956543e-01
    z[5,6,1]  R2194     4.7931188344955444e-01
    z[5,6,1]  R2195     6.4421904087066650e-01
    z[5,6,1]  R2196     7.3177880048751831e-01
    z[5,6,1]  R2197     8.4226936101913452e-01
    z[5,6,1]  R2198     8.3228170871734619e-01
    z[5,6,1]  R2199     7.5504338741302490e-01
    z[5,6,1]  R2200     7.6662635803222656e-01
    z[5,6,1]  R2201     6.8480169773101807e-01
    z[5,6,1]  R2202     8.0933910608291626e-01
    z[5,6,1]  R2203     6.9874179363250732e-01
    z[5,6,1]  R2204     7.6158493757247925e-01
    z[5,6,1]  R2205     6.6127419471740723e-01
    z[5,6,1]  R2206     -3.8983193039894104e-01
    z[5,6,1]  R2207     -3.6499857902526855e-01
    z[5,6,1]  R2208     -2.1544776856899261e-02
    z[5,6,1]  R2209     -6.8940952420234680e-02
    z[5,6,1]  R2210     -1.2151963263750076e-01
    z[5,6,1]  R2211     -5.3895201534032822e-02
    z[5,6,1]  R2212     3.3995623234659433e-03
    z[5,6,1]  R2213     -6.3452741596847773e-04
    z[5,6,1]  R2214     2.7241089940071106e-01
    z[5,6,1]  R2215     -2.8118479251861572e-01
    z[5,6,1]  R2216     -5.0241601467132568e-01
    z[5,6,1]  R2217     -1.9956082105636597e-01
    z[5,6,1]  R2218     -5.9879440069198608e-01
    z[5,6,1]  R2219     -7.0977377891540527e-01
    z[5,6,1]  R2220     -4.8572760820388794e-01
    z[5,6,1]  R2221     -5.2118331193923950e-01
    z[5,6,1]  R2222     -6.8679213523864746e-02
    z[5,6,1]  R2223     -5.8934754133224487e-01
    z[5,6,1]  R2224     -4.0870368480682373e-01
    z[5,6,1]  R2225     -5.2850800752639771e-01
    z[5,6,1]  R2226     -3.1171565875411034e-02
    z[5,6,1]  R2227     -9.5037811994552612e-01
    z[5,6,1]  R2228     3.0611717700958252e-01
    z[5,6,1]  R2229     1.5424132347106934e-01
    z[5,6,1]  R2230     -9.2823922634124756e-02
    z[5,6,1]  R2231     3.5708022117614746e-01
    z[5,6,1]  R2232     -5.2102571725845337e-01
    z[5,6,1]  R2233     6.6686397790908813e-01
    z[5,6,1]  R2234     -1.4312581717967987e-01
    z[5,6,1]  R2235     6.0229659080505371e-01
    z[5,6,1]  R2236     -3.4938564896583557e-01
    z[5,6,1]  R2237     1.5225054323673248e-01
    z[5,6,1]  R2238     -7.8362977504730225e-01
    z[5,6,1]  R2239     0.045985147356987
    z[5,6,1]  R2240     -8.9270532131195068e-01
    z[5,6,1]  R2241     1.0074172914028168e-01
    z[5,6,1]  R2242     -6.3061875104904175e-01
    z[5,6,1]  R2243     -3.0362397432327271e-01
    z[5,6,1]  R2244     1.2596595287322998e-01
    z[5,6,1]  R2245     -5.5027091503143311e-01
    z[5,6,1]  R2246     -7.6516550779342651e-01
    z[5,6,1]  R2247     -8.8505178689956665e-01
    z[5,6,1]  R2248     -5.2559173107147217e-01
    z[5,6,1]  R2249     -0.89644455909729
    z[5,6,1]  R2250     2.1496775746345520e-01
    z[5,6,1]  R2251     -2.3313325643539429e-01
    z[5,6,1]  R2252     -7.7686858177185059e-01
    z[5,6,1]  R2253     -5.5272829532623291e-01
    z[5,6,1]  R2254     -1.3243253529071808e-01
    z[5,6,1]  R2255     -3.7105970084667206e-02
    z[5,6,1]  R2256     -2.6720070838928223e-01
    z[5,6,1]  R2257     -3.0520877242088318e-01
    z[5,6,1]  R2258     -4.4281157851219177e-01
    z[5,6,1]  R2259     -4.7522720694541931e-01
    z[5,6,1]  R2260     -1.7094098031520844e-01
    z[5,6,1]  R2261     -1.9637905061244965e-01
    z[5,6,1]  R2262     -4.5808512717485428e-02
    z[5,6,1]  R2263     2.2161212563514709e-01
    z[5,6,1]  R2264     7.5454115867614746e-01
    z[5,6,1]  R2265     8.6229842901229858e-01
    z[5,6,1]  R2266     -2.6137259602546692e-01
    z[5,6,1]  R2267     -6.7997843027114868e-01
    z[5,6,1]  R2268     1.7777520418167114e-01
    z[5,6,1]  R2269     -6.4122051000595093e-01
    z[5,6,1]  R2270     -0.055446557700634
    z[5,6,1]  R2271     -2.7222353219985962e-01
    z[5,6,1]  R2272     -2.6235067844390869e-01
    z[5,6,1]  R2273     -1.5870186686515808e-01
    z[5,6,1]  R2274     1.6907547414302826e-01
    z[5,6,1]  R2275     2.0996022969484329e-02
    z[5,6,1]  R2276     -1.4200265705585480e-01
    z[5,6,1]  R2277     -3.0012896656990051e-01
    z[5,6,1]  R2278     -7.6789957284927368e-01
    z[5,6,1]  R2279     -5.6674383580684662e-02
    z[5,6,1]  R2280     -1.9198960065841675e-01
    z[5,6,1]  R2281     -1.4512595720589161e-02
    z[5,6,1]  R2282     3.6846555769443512e-02
    z[5,6,1]  R2283     2.8690424561500549e-01
    z[5,6,1]  R2284     4.8175626993179321e-01
    z[5,6,1]  R2285     7.9874765872955322e-01
    z[5,6,1]  R2286     -1.4394551515579224e-02
    z[5,6,1]  R2287     -3.0781856179237366e-01
    z[5,6,1]  R2288     -2.7524015307426453e-01
    z[5,6,1]  R2289     -2.0112356543540955e-01
    z[5,6,1]  R2290     1.0570946335792542e-01
    z[5,6,1]  R2291     -1.8369263410568237e-01
    z[5,6,1]  R2292     5.2311939001083374e-01
    z[5,6,1]  R2293     7.2564291954040527e-01
    z[5,6,1]  R2294     7.3291534185409546e-01
    z[5,6,1]  R2295     8.1506699323654175e-01
    z[5,6,1]  R2296     9.3010291457176208e-02
    z[5,6,1]  R2297     -1.8123178184032440e-01
    z[5,6,1]  R2298     -0.145138680934906
    z[5,6,1]  R2299     -2.4333159625530243e-01
    z[5,6,1]  R2300     -4.8579236865043640e-01
    z[5,6,1]  R2301     6.5936404466629028e-01
    z[5,6,1]  R2302     6.2111669778823853e-01
    z[5,6,1]  R2303     0.584827721118927
    z[5,6,1]  R2304     8.8545787334442139e-01
    z[5,6,1]  R2305     8.1723350286483765e-01
    z[5,6,1]  R2306     -4.9319869279861450e-01
    z[5,6,1]  R2307     -1.6294093430042267e-01
    z[5,6,1]  R2308     -5.0169759988784790e-01
    z[5,6,1]  R2309     -3.1170082092285156e-01
    z[5,6,1]  R2310     9.1450905799865723e-01
    z[5,6,1]  R2311     8.0454438924789429e-01
    z[5,6,1]  R2312     0.808972954750061
    z[5,6,1]  R2313     6.4437693357467651e-01
    z[5,6,1]  R2314     6.1878538131713867e-01
    z[5,6,1]  R2315     0.753345787525177
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2166     -1
    z[5,6,2]  R2167     1
    z[5,6,2]  R2176     -3.5748252272605896e-01
    z[5,6,2]  R2177     -3.6852023005485535e-01
    z[5,6,2]  R2178     4.9215239286422729e-01
    z[5,6,2]  R2179     2.5748586654663086e-01
    z[5,6,2]  R2180     -6.4546324312686920e-02
    z[5,6,2]  R2181     -1.7670178413391113e-01
    z[5,6,2]  R2182     -6.9458144903182983e-01
    z[5,6,2]  R2183     4.8162847757339478e-01
    z[5,6,2]  R2184     -4.8755022883415222e-01
    z[5,6,2]  R2185     1.5100403130054474e-01
    z[5,6,2]  R2186     2.8145718574523926e-01
    z[5,6,2]  R2187     2.6563405990600586e-01
    z[5,6,2]  R2188     -1.6246227920055389e-01
    z[5,6,2]  R2189     1.0238543152809143e-01
    z[5,6,2]  R2190     -0.0772957056760788
    z[5,6,2]  R2191     -3.6308398842811584e-01
    z[5,6,2]  R2192     1.7393574118614197e-01
    z[5,6,2]  R2193     -2.4055273830890656e-01
    z[5,6,2]  R2194     -5.8491069078445435e-01
    z[5,6,2]  R2195     -4.0013724565505981e-01
    z[5,6,2]  R2196     3.0864465981721878e-02
    z[5,6,2]  R2197     4.3979067355394363e-02
    z[5,6,2]  R2198     -2.0543819665908813e-01
    z[5,6,2]  R2199     -1.1190900579094887e-02
    z[5,6,2]  R2200     2.6367226243019104e-01
    z[5,6,2]  R2201     -5.7455807924270630e-02
    z[5,6,2]  R2202     -2.1146422252058983e-02
    z[5,6,2]  R2203     -3.4737319219857454e-03
    z[5,6,2]  R2204     -5.0904309749603271e-01
    z[5,6,2]  R2205     -6.3758021593093872e-01
    z[5,6,2]  R2206     -1.7520034313201904e-01
    z[5,6,2]  R2207     -1.1685901880264282e-01
    z[5,6,2]  R2208     -1.6333484649658203e-01
    z[5,6,2]  R2209     -2.6785880327224731e-01
    z[5,6,2]  R2210     -1.8257641792297363e-01
    z[5,6,2]  R2211     -5.3789663314819336e-01
    z[5,6,2]  R2212     -1.7760933935642242e-01
    z[5,6,2]  R2213     -1.7945638298988342e-01
    z[5,6,2]  R2214     -3.8195076584815979e-01
    z[5,6,2]  R2215     -0.0339924618601799
    z[5,6,2]  R2216     2.8260305523872375e-01
    z[5,6,2]  R2217     7.1075963973999023e-01
    z[5,6,2]  R2218     6.8378818035125732e-01
    z[5,6,2]  R2219     5.4878199100494385e-01
    z[5,6,2]  R2220     4.9439480900764465e-01
    z[5,6,2]  R2221     6.2343740463256836e-01
    z[5,6,2]  R2222     5.0190275907516479e-01
    z[5,6,2]  R2223     4.8393711447715759e-01
    z[5,6,2]  R2224     3.8058194518089294e-01
    z[5,6,2]  R2225     4.3565174937248230e-01
    z[5,6,2]  R2226     3.2944139838218689e-01
    z[5,6,2]  R2227     -1.5970049798488617e-01
    z[5,6,2]  R2228     6.8351435661315918e-01
    z[5,6,2]  R2229     2.4656991660594940e-01
    z[5,6,2]  R2230     1.1712289601564407e-01
    z[5,6,2]  R2231     6.8361848592758179e-01
    z[5,6,2]  R2232     -1.3215051591396332e-01
    z[5,6,2]  R2233     -6.0098522901535034e-01
    z[5,6,2]  R2234     4.9145266413688660e-01
    z[5,6,2]  R2235     -0.706415057182312
    z[5,6,2]  R2236     3.1549575924873352e-01
    z[5,6,2]  R2237     3.8917210698127747e-01
    z[5,6,2]  R2238     4.1174092888832092e-01
    z[5,6,2]  R2239     3.1450986862182617e-01
    z[5,6,2]  R2240     4.2288318276405334e-02
    z[5,6,2]  R2241     6.3316076993942261e-01
    z[5,6,2]  R2242     2.1973705291748047e-01
    z[5,6,2]  R2243     -5.7728279381990433e-02
    z[5,6,2]  R2244     7.7076196670532227e-01
    z[5,6,2]  R2245     2.6455268263816833e-01
    z[5,6,2]  R2246     4.2389449477195740e-01
    z[5,6,2]  R2247     2.2439652681350708e-01
    z[5,6,2]  R2248     6.4922392368316650e-01
    z[5,6,2]  R2249     1.6333243250846863e-01
    z[5,6,2]  R2250     5.4032075405120850e-01
    z[5,6,2]  R2251     -1.8255543708801270e-01
    z[5,6,2]  R2252     3.0196553096175194e-02
    z[5,6,2]  R2253     0.215520977973938
    z[5,6,2]  R2254     -6.1001914739608765e-01
    z[5,6,2]  R2255     8.8725559413433075e-02
    z[5,6,2]  R2256     -2.3672574758529663e-01
    z[5,6,2]  R2257     2.5989213585853577e-01
    z[5,6,2]  R2258     1.6411387920379639e-01
    z[5,6,2]  R2259     2.8355222940444946e-01
    z[5,6,2]  R2260     9.0234234929084778e-02
    z[5,6,2]  R2261     -1.9573102891445160e-01
    z[5,6,2]  R2262     4.8574164509773254e-01
    z[5,6,2]  R2263     6.5591341257095337e-01
    z[5,6,2]  R2264     -3.4801873564720154e-01
    z[5,6,2]  R2265     -4.6952879428863525e-01
    z[5,6,2]  R2266     6.7564022541046143e-01
    z[5,6,2]  R2267     1.2817643582820892e-03
    z[5,6,2]  R2268     4.2216774821281433e-01
    z[5,6,2]  R2269     1.5791609883308411e-01
    z[5,6,2]  R2270     -7.6735556125640869e-01
    z[5,6,2]  R2271     2.5689122080802917e-01
    z[5,6,2]  R2272     0.395819753408432
    z[5,6,2]  R2273     2.0394693315029144e-01
    z[5,6,2]  R2274     -6.5956008434295654e-01
    z[5,6,2]  R2275     0.0963897705078125
    z[5,6,2]  R2276     2.1616187691688538e-01
    z[5,6,2]  R2277     3.8360023498535156e-01
    z[5,6,2]  R2278     0.522737979888916
    z[5,6,2]  R2279     -5.8665275573730469e-01
    z[5,6,2]  R2280     0.257693350315094
    z[5,6,2]  R2281     5.1851803064346313e-01
    z[5,6,2]  R2282     3.2036128640174866e-01
    z[5,6,2]  R2283     3.1420376896858215e-01
    z[5,6,2]  R2284     -4.5502316951751709e-01
    z[5,6,2]  R2285     -4.5573037862777710e-01
    z[5,6,2]  R2286     -6.1263483762741089e-01
    z[5,6,2]  R2287     3.7518495321273804e-01
    z[5,6,2]  R2288     4.6717628836631775e-01
    z[5,6,2]  R2289     2.9142412543296814e-01
    z[5,6,2]  R2290     3.8473892211914062e-01
    z[5,6,2]  R2291     4.9168238043785095e-01
    z[5,6,2]  R2292     -8.2693254947662354e-01
    z[5,6,2]  R2293     -3.9073020219802856e-01
    z[5,6,2]  R2294     -0.315792053937912
    z[5,6,2]  R2295     -1.5693803131580353e-01
    z[5,6,2]  R2296     -0.431908518075943
    z[5,6,2]  R2297     4.6711099147796631e-01
    z[5,6,2]  R2298     5.1746422052383423e-01
    z[5,6,2]  R2299     1.6701912879943848e-01
    z[5,6,2]  R2300     2.2287330031394958e-01
    z[5,6,2]  R2301     -6.4267307519912720e-01
    z[5,6,2]  R2302     -5.4743212461471558e-01
    z[5,6,2]  R2303     -5.9905093908309937e-01
    z[5,6,2]  R2304     3.9783951640129089e-01
    z[5,6,2]  R2305     5.3042483329772949e-01
    z[5,6,2]  R2306     6.0604417324066162e-01
    z[5,6,2]  R2307     1.0132411122322083e-01
    z[5,6,2]  R2308     2.7886566519737244e-01
    z[5,6,2]  R2309     -4.7770851850509644e-01
    z[5,6,2]  R2310     -3.4008646011352539e-01
    z[5,6,2]  R2311     3.9407119154930115e-01
    z[5,6,2]  R2312     4.1896224021911621e-01
    z[5,6,2]  R2313     5.4252862930297852e-01
    z[5,6,2]  R2314     5.3949481248855591e-01
    z[5,6,2]  R2315     3.8305473327636719e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2168     -1
    z[5,6,3]  R2169     1
    z[5,6,3]  R2176     -3.0484458804130554e-01
    z[5,6,3]  R2177     3.0258995294570923e-01
    z[5,6,3]  R2178     2.6740673184394836e-01
    z[5,6,3]  R2179     -1.4441390335559845e-01
    z[5,6,3]  R2180     2.0342398434877396e-02
    z[5,6,3]  R2181     4.3444547057151794e-01
    z[5,6,3]  R2182     1.4450505375862122e-01
    z[5,6,3]  R2183     1.3760606944561005e-01
    z[5,6,3]  R2184     7.1704357862472534e-02
    z[5,6,3]  R2185     1.3513167202472687e-01
    z[5,6,3]  R2186     -0.828399121761322
    z[5,6,3]  R2187     -1.9924451410770416e-01
    z[5,6,3]  R2188     2.5086668133735657e-01
    z[5,6,3]  R2189     -1.1031280271708965e-02
    z[5,6,3]  R2190     1.5580029785633087e-01
    z[5,6,3]  R2191     6.5932929515838623e-01
    z[5,6,3]  R2192     3.1311213970184326e-01
    z[5,6,3]  R2193     2.7446320652961731e-01
    z[5,6,3]  R2194     1.5342476963996887e-01
    z[5,6,3]  R2195     -1.2894946336746216e-01
    z[5,6,3]  R2196     -1.0152570903301239e-01
    z[5,6,3]  R2197     3.4143622964620590e-02
    z[5,6,3]  R2198     4.4309478253126144e-02
    z[5,6,3]  R2199     -1.4164656400680542e-02
    z[5,6,3]  R2200     7.2648137807846069e-02
    z[5,6,3]  R2201     -4.9537453800439835e-02
    z[5,6,3]  R2202     0.332329660654068
    z[5,6,3]  R2203     4.5039889216423035e-01
    z[5,6,3]  R2204     2.8907701373100281e-01
    z[5,6,3]  R2205     1.0043850168585777e-02
    z[5,6,3]  R2206     1.9722686707973480e-01
    z[5,6,3]  R2207     -1.7805849015712738e-01
    z[5,6,3]  R2208     -1.3938149809837341e-01
    z[5,6,3]  R2209     3.1448623538017273e-01
    z[5,6,3]  R2210     0.00422905758023262
    z[5,6,3]  R2211     3.0133891850709915e-02
    z[5,6,3]  R2212     -5.1916502416133881e-02
    z[5,6,3]  R2213     -4.8395209014415741e-02
    z[5,6,3]  R2214     -7.3296025395393372e-02
    z[5,6,3]  R2215     2.6381894946098328e-01
    z[5,6,3]  R2216     -3.9144456386566162e-01
    z[5,6,3]  R2217     2.1493844687938690e-01
    z[5,6,3]  R2218     -3.2905817031860352e-02
    z[5,6,3]  R2219     1.3282246887683868e-01
    z[5,6,3]  R2220     -4.2959639430046082e-01
    z[5,6,3]  R2221     -2.6216539740562439e-01
    z[5,6,3]  R2222     -1.5089030377566814e-02
    z[5,6,3]  R2223     2.9635429382324219e-01
    z[5,6,3]  R2224     -3.1604444980621338e-01
    z[5,6,3]  R2225     2.2651587426662445e-01
    z[5,6,3]  R2226     1.9076961278915405e-01
    z[5,6,3]  R2227     -1.6248348355293274e-01
    z[5,6,3]  R2228     -3.2762053608894348e-01
    z[5,6,3]  R2229     -9.8815739154815674e-02
    z[5,6,3]  R2230     4.4113656878471375e-01
    z[5,6,3]  R2231     1.8524500727653503e-01
    z[5,6,3]  R2232     2.6893270015716553e-01
    z[5,6,3]  R2233     -8.2504920661449432e-02
    z[5,6,3]  R2234     -3.0172142386436462e-01
    z[5,6,3]  R2235     2.6870843768119812e-01
    z[5,6,3]  R2236     2.9335431754589081e-02
    z[5,6,3]  R2237     1.2446004152297974e-01
    z[5,6,3]  R2238     -0.279773473739624
    z[5,6,3]  R2239     1.1687626689672470e-01
    z[5,6,3]  R2240     1.3141964375972748e-01
    z[5,6,3]  R2241     -3.0197307467460632e-01
    z[5,6,3]  R2242     -0.718078076839447
    z[5,6,3]  R2243     -2.2317622601985931e-01
    z[5,6,3]  R2244     -7.3442630469799042e-02
    z[5,6,3]  R2245     -1.9902646541595459e-01
    z[5,6,3]  R2246     -3.9294418692588806e-01
    z[5,6,3]  R2247     -1.0631754249334335e-01
    z[5,6,3]  R2248     8.6140096187591553e-02
    z[5,6,3]  R2249     -0.0592268705368042
    z[5,6,3]  R2250     1.1346279084682465e-01
    z[5,6,3]  R2251     5.5354988574981689e-01
    z[5,6,3]  R2252     -2.1806603670120239e-01
    z[5,6,3]  R2253     1.3416700065135956e-01
    z[5,6,3]  R2254     -4.5715585350990295e-01
    z[5,6,3]  R2255     -2.9148977249860764e-02
    z[5,6,3]  R2256     -2.1368084847927094e-01
    z[5,6,3]  R2257     -1.3163023628294468e-02
    z[5,6,3]  R2258     5.4514998197555542e-01
    z[5,6,3]  R2259     -1.0321961343288422e-01
    z[5,6,3]  R2260     5.3564912080764771e-01
    z[5,6,3]  R2261     2.9216277599334717e-01
    z[5,6,3]  R2262     3.0592599511146545e-01
    z[5,6,3]  R2263     1.5349418856203556e-02
    z[5,6,3]  R2264     -1.7554216086864471e-01
    z[5,6,3]  R2265     1.0113058984279633e-01
    z[5,6,3]  R2266     4.0966841578483582e-01
    z[5,6,3]  R2267     -3.4179797768592834e-01
    z[5,6,3]  R2268     -2.9593538492918015e-03
    z[5,6,3]  R2269     -1.8164904788136482e-02
    z[5,6,3]  R2270     -3.0162784457206726e-01
    z[5,6,3]  R2271     2.2983743250370026e-01
    z[5,6,3]  R2272     2.0392403006553650e-01
    z[5,6,3]  R2273     3.1509986519813538e-01
    z[5,6,3]  R2274     -4.8180431127548218e-01
    z[5,6,3]  R2275     4.9940237402915955e-01
    z[5,6,3]  R2276     0.303492933511734
    z[5,6,3]  R2277     0.298991322517395
    z[5,6,3]  R2278     -9.7847640514373779e-02
    z[5,6,3]  R2279     -3.3750689029693604e-01
    z[5,6,3]  R2280     3.1253427267074585e-01
    z[5,6,3]  R2281     1.9220243394374847e-01
    z[5,6,3]  R2282     1.3646423816680908e-01
    z[5,6,3]  R2283     -2.2059574723243713e-01
    z[5,6,3]  R2284     1.5589003264904022e-01
    z[5,6,3]  R2285     3.3723658323287964e-01
    z[5,6,3]  R2286     5.4800111800432205e-02
    z[5,6,3]  R2287     1.9486233592033386e-01
    z[5,6,3]  R2288     1.5734905004501343e-01
    z[5,6,3]  R2289     -6.4490497112274170e-02
    z[5,6,3]  R2290     -0.0396580696105957
    z[5,6,3]  R2291     6.9540542364120483e-01
    z[5,6,3]  R2292     7.5495615601539612e-02
    z[5,6,3]  R2293     3.2061886787414551e-01
    z[5,6,3]  R2294     4.6656790375709534e-01
    z[5,6,3]  R2295     0.474361777305603
    z[5,6,3]  R2296     -3.0580973625183105e-01
    z[5,6,3]  R2297     4.5167854428291321e-01
    z[5,6,3]  R2298     -3.4414285421371460e-01
    z[5,6,3]  R2299     2.4899591505527496e-01
    z[5,6,3]  R2300     -7.5129413604736328e-01
    z[5,6,3]  R2301     3.4967169165611267e-01
    z[5,6,3]  R2302     4.1893583536148071e-01
    z[5,6,3]  R2303     -2.6354610919952393e-01
    z[5,6,3]  R2304     1.5516200102865696e-02
    z[5,6,3]  R2305     1.0314907878637314e-01
    z[5,6,3]  R2306     -0.500938892364502
    z[5,6,3]  R2307     1.9754789769649506e-01
    z[5,6,3]  R2308     2.4601487815380096e-01
    z[5,6,3]  R2309     -6.2834209203720093e-01
    z[5,6,3]  R2310     9.7366660833358765e-02
    z[5,6,3]  R2311     2.8921690583229065e-01
    z[5,6,3]  R2312     1.8290439248085022e-01
    z[5,6,3]  R2313     1.8155736848711967e-02
    z[5,6,3]  R2314     -1.2649394571781158e-01
    z[5,6,3]  R2315     -3.0813655257225037e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2170     -1
    z[5,6,4]  R2171     1
    z[5,6,4]  R2176     -5.1058534532785416e-02
    z[5,6,4]  R2177     0.531574547290802
    z[5,6,4]  R2178     2.7152130007743835e-01
    z[5,6,4]  R2179     -3.3534345030784607e-01
    z[5,6,4]  R2180     -1.8669579923152924e-01
    z[5,6,4]  R2181     1.6961827874183655e-01
    z[5,6,4]  R2182     -3.1581020355224609e-01
    z[5,6,4]  R2183     1.9509436190128326e-01
    z[5,6,4]  R2184     1.2445946782827377e-01
    z[5,6,4]  R2185     2.5597405433654785e-01
    z[5,6,4]  R2186     1.2232623249292374e-01
    z[5,6,4]  R2187     4.0399497747421265e-01
    z[5,6,4]  R2188     3.1204903498291969e-02
    z[5,6,4]  R2189     -5.0547176599502563e-01
    z[5,6,4]  R2190     -4.9647606909275055e-02
    z[5,6,4]  R2191     -1.7314553260803223e-01
    z[5,6,4]  R2192     4.5614200830459595e-01
    z[5,6,4]  R2193     -5.0045979022979736e-01
    z[5,6,4]  R2194     -1.6497291624546051e-01
    z[5,6,4]  R2195     -1.6790528595447540e-01
    z[5,6,4]  R2196     1.5428660809993744e-01
    z[5,6,4]  R2197     1.2442489713430405e-01
    z[5,6,4]  R2198     -1.4730221033096313e-01
    z[5,6,4]  R2199     2.1390931680798531e-02
    z[5,6,4]  R2200     -1.4637741446495056e-01
    z[5,6,4]  R2201     -3.1215709447860718e-01
    z[5,6,4]  R2202     -1.3079211115837097e-01
    z[5,6,4]  R2203     4.3404512107372284e-02
    z[5,6,4]  R2204     -0.203762024641037
    z[5,6,4]  R2205     -1.7515948414802551e-01
    z[5,6,4]  R2206     2.5442723184823990e-02
    z[5,6,4]  R2207     1.5681026875972748e-01
    z[5,6,4]  R2208     9.9835090339183807e-02
    z[5,6,4]  R2209     2.4434188008308411e-01
    z[5,6,4]  R2210     -3.4472875297069550e-02
    z[5,6,4]  R2211     3.6078128218650818e-01
    z[5,6,4]  R2212     2.0710060000419617e-01
    z[5,6,4]  R2213     4.5984137803316116e-02
    z[5,6,4]  R2214     2.6967635750770569e-01
    z[5,6,4]  R2215     3.3857962489128113e-01
    z[5,6,4]  R2216     1.8772387504577637e-01
    z[5,6,4]  R2217     -6.4913578331470490e-02
    z[5,6,4]  R2218     3.2985430955886841e-01
    z[5,6,4]  R2219     3.9232546091079712e-01
    z[5,6,4]  R2220     3.3945900201797485e-01
    z[5,6,4]  R2221     1.2313283234834671e-01
    z[5,6,4]  R2222     -4.2394474148750305e-01
    z[5,6,4]  R2223     3.2723551988601685e-01
    z[5,6,4]  R2224     5.8565360307693481e-01
    z[5,6,4]  R2225     2.8684270381927490e-01
    z[5,6,4]  R2226     -3.7396547198295593e-01
    z[5,6,4]  R2227     -1.7767411470413208e-01
    z[5,6,4]  R2228     2.1423611044883728e-01
    z[5,6,4]  R2229     4.1241145133972168e-01
    z[5,6,4]  R2230     -8.4720002487301826e-03
    z[5,6,4]  R2231     -2.1629419177770615e-02
    z[5,6,4]  R2232     -5.6049692630767822e-01
    z[5,6,4]  R2233     -4.1762074828147888e-01
    z[5,6,4]  R2234     -0.309527724981308
    z[5,6,4]  R2235     -1.8898989260196686e-01
    z[5,6,4]  R2236     -4.7102957963943481e-01
    z[5,6,4]  R2237     1.1562176048755646e-01
    z[5,6,4]  R2238     3.6604840308427811e-02
    z[5,6,4]  R2239     4.4977459311485291e-01
    z[5,6,4]  R2240     3.2556807994842529e-01
    z[5,6,4]  R2241     -3.6292336881160736e-02
    z[5,6,4]  R2242     2.5714278221130371e-02
    z[5,6,4]  R2243     -3.8738265633583069e-01
    z[5,6,4]  R2244     2.2139152884483337e-01
    z[5,6,4]  R2245     -3.5999670624732971e-01
    z[5,6,4]  R2246     -1.6703774034976959e-01
    z[5,6,4]  R2247     6.3023701310157776e-02
    z[5,6,4]  R2248     -3.0715823173522949e-02
    z[5,6,4]  R2249     -3.0421710014343262e-01
    z[5,6,4]  R2250     2.1932624280452728e-01
    z[5,6,4]  R2251     -1.7460497096180916e-02
    z[5,6,4]  R2252     4.3190225958824158e-01
    z[5,6,4]  R2253     0.67954021692276
    z[5,6,4]  R2254     -4.0179529786109924e-01
    z[5,6,4]  R2255     -1.0678673535585403e-01
    z[5,6,4]  R2256     2.9650720953941345e-01
    z[5,6,4]  R2257     -3.4526339173316956e-01
    z[5,6,4]  R2258     -1.7809841036796570e-01
    z[5,6,4]  R2259     6.9740664958953857e-01
    z[5,6,4]  R2260     3.9971670508384705e-01
    z[5,6,4]  R2261     -1.9026480615139008e-01
    z[5,6,4]  R2262     -1.3448676466941833e-01
    z[5,6,4]  R2263     -2.5099346041679382e-01
    z[5,6,4]  R2264     -3.4589907526969910e-01
    z[5,6,4]  R2265     -6.4240492880344391e-02
    z[5,6,4]  R2266     -8.8118426501750946e-02
    z[5,6,4]  R2267     4.5130811631679535e-02
    z[5,6,4]  R2268     -7.5812175869941711e-02
    z[5,6,4]  R2269     4.6922618150711060e-01
    z[5,6,4]  R2270     -2.1081276237964630e-01
    z[5,6,4]  R2271     -5.4514068365097046e-01
    z[5,6,4]  R2272     3.0137148499488831e-01
    z[5,6,4]  R2273     2.5732040405273438e-01
    z[5,6,4]  R2274     -2.0544733107089996e-01
    z[5,6,4]  R2275     4.3823051452636719e-01
    z[5,6,4]  R2276     1.1673387885093689e-01
    z[5,6,4]  R2277     -4.8256742954254150e-01
    z[5,6,4]  R2278     2.4360392987728119e-01
    z[5,6,4]  R2279     -3.2086694240570068e-01
    z[5,6,4]  R2280     4.6117997169494629e-01
    z[5,6,4]  R2281     3.9515700936317444e-01
    z[5,6,4]  R2282     4.5218691229820251e-02
    z[5,6,4]  R2283     -1.8601721525192261e-01
    z[5,6,4]  R2284     -3.0061137676239014e-01
    z[5,6,4]  R2285     1.4628148078918457e-01
    z[5,6,4]  R2286     -4.4163670390844345e-02
    z[5,6,4]  R2287     2.9067862033843994e-01
    z[5,6,4]  R2288     -4.5216238498687744e-01
    z[5,6,4]  R2289     -0.154743030667305
    z[5,6,4]  R2290     -2.7844479680061340e-01
    z[5,6,4]  R2291     -1.9415840506553650e-01
    z[5,6,4]  R2292     1.0383749753236771e-01
    z[5,6,4]  R2293     1.2211102247238159e-01
    z[5,6,4]  R2294     -2.6020416617393494e-01
    z[5,6,4]  R2295     -5.8943405747413635e-02
    z[5,6,4]  R2296     -3.0825346708297729e-01
    z[5,6,4]  R2297     3.0930081382393837e-02
    z[5,6,4]  R2298     -1.2759761512279510e-01
    z[5,6,4]  R2299     -6.0336075723171234e-02
    z[5,6,4]  R2300     1.0239310562610626e-01
    z[5,6,4]  R2301     -8.9971348643302917e-03
    z[5,6,4]  R2302     -2.2755637764930725e-03
    z[5,6,4]  R2303     -2.7343245223164558e-02
    z[5,6,4]  R2304     2.0597030222415924e-01
    z[5,6,4]  R2305     -1.0387220233678818e-01
    z[5,6,4]  R2306     2.8337278962135315e-01
    z[5,6,4]  R2307     1.1322257667779922e-01
    z[5,6,4]  R2308     2.7698168158531189e-01
    z[5,6,4]  R2309     -5.7650644332170486e-02
    z[5,6,4]  R2310     -7.6792903244495392e-02
    z[5,6,4]  R2311     -6.1464175581932068e-02
    z[5,6,4]  R2312     -2.8007525205612183e-01
    z[5,6,4]  R2313     -1.7160907387733459e-01
    z[5,6,4]  R2314     -1.3729830272495747e-02
    z[5,6,4]  R2315     -1.3171419501304626e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2172     -1
    z[5,6,5]  R2173     1
    z[5,6,5]  R2176     -2.3808676004409790e-01
    z[5,6,5]  R2177     3.9120021462440491e-01
    z[5,6,5]  R2178     5.1130358129739761e-02
    z[5,6,5]  R2179     -5.8744996786117554e-01
    z[5,6,5]  R2180     -0.635794460773468
    z[5,6,5]  R2181     -3.6425021290779114e-01
    z[5,6,5]  R2182     -1.0354480147361755e-01
    z[5,6,5]  R2183     -1.9417276978492737e-01
    z[5,6,5]  R2184     -1.1577197909355164e-01
    z[5,6,5]  R2185     -5.5306226015090942e-01
    z[5,6,5]  R2186     4.1811850666999817e-01
    z[5,6,5]  R2187     4.9402302503585815e-01
    z[5,6,5]  R2188     0.091541588306427
    z[5,6,5]  R2189     -7.0513077080249786e-02
    z[5,6,5]  R2190     -5.9386390447616577e-01
    z[5,6,5]  R2191     -0.101526640355587
    z[5,6,5]  R2192     -4.2905488610267639e-01
    z[5,6,5]  R2193     2.7670687437057495e-01
    z[5,6,5]  R2194     2.5069864466786385e-02
    z[5,6,5]  R2195     -1.7510496079921722e-01
    z[5,6,5]  R2196     -4.3672375380992889e-02
    z[5,6,5]  R2197     1.1781078577041626e-01
    z[5,6,5]  R2198     1.1512167006731033e-01
    z[5,6,5]  R2199     -1.6194142401218414e-01
    z[5,6,5]  R2200     -2.0817534625530243e-01
    z[5,6,5]  R2201     -0.283462256193161
    z[5,6,5]  R2202     -7.9871386289596558e-02
    z[5,6,5]  R2203     -1.1518055945634842e-01
    z[5,6,5]  R2204     -0.13038270175457
    z[5,6,5]  R2205     2.5660738348960876e-01
    z[5,6,5]  R2206     1.8363554030656815e-02
    z[5,6,5]  R2207     -9.5805518329143524e-02
    z[5,6,5]  R2208     1.2756167352199554e-01
    z[5,6,5]  R2209     -5.5215455591678619e-02
    z[5,6,5]  R2210     1.4253821969032288e-01
    z[5,6,5]  R2211     1.5330988168716431e-01
    z[5,6,5]  R2212     -1.7740002274513245e-01
    z[5,6,5]  R2213     6.8646006286144257e-02
    z[5,6,5]  R2214     9.1301478445529938e-02
    z[5,6,5]  R2215     1.0748646408319473e-01
    z[5,6,5]  R2216     -6.3528245687484741e-01
    z[5,6,5]  R2217     -5.5146205425262451e-01
    z[5,6,5]  R2218     -1.5791727602481842e-01
    z[5,6,5]  R2219     1.1527353525161743e-01
    z[5,6,5]  R2220     -1.3519582152366638e-01
    z[5,6,5]  R2221     -4.2881774902343750e-01
    z[5,6,5]  R2222     -6.6672730445861816e-01
    z[5,6,5]  R2223     -3.4675487875938416e-01
    z[5,6,5]  R2224     -3.6504715681076050e-01
    z[5,6,5]  R2225     -6.0960131883621216e-01
    z[5,6,5]  R2226     -1.7386928200721741e-01
    z[5,6,5]  R2227     6.6571027040481567e-02
    z[5,6,5]  R2228     8.7013505399227142e-02
    z[5,6,5]  R2229     2.4824562668800354e-01
    z[5,6,5]  R2230     3.5148376226425171e-01
    z[5,6,5]  R2231     2.2151772677898407e-01
    z[5,6,5]  R2232     1.1689832806587219e-01
    z[5,6,5]  R2233     2.1122368052601814e-02
    z[5,6,5]  R2234     4.5777830481529236e-01
    z[5,6,5]  R2235     1.2328056618571281e-02
    z[5,6,5]  R2236     -0.448505699634552
    z[5,6,5]  R2237     -3.6816036701202393e-01
    z[5,6,5]  R2238     2.8279694914817810e-01
    z[5,6,5]  R2239     -5.4161384701728821e-02
    z[5,6,5]  R2240     1.2324440479278564e-01
    z[5,6,5]  R2241     -1.0633645206689835e-01
    z[5,6,5]  R2242     2.5598341599106789e-02
    z[5,6,5]  R2243     -2.3073397576808929e-02
    z[5,6,5]  R2244     -1.0603081434965134e-01
    z[5,6,5]  R2245     -6.0287380218505859e-01
    z[5,6,5]  R2246     -2.1796286106109619e-01
    z[5,6,5]  R2247     -1.5515540540218353e-01
    z[5,6,5]  R2248     -3.2942584156990051e-01
    z[5,6,5]  R2249     -2.4291633069515228e-01
    z[5,6,5]  R2250     -0.422921746969223
    z[5,6,5]  R2251     -4.3859258294105530e-01
    z[5,6,5]  R2252     -1.4036697149276733e-01
    z[5,6,5]  R2253     -1.4414627850055695e-01
    z[5,6,5]  R2254     -2.9180753231048584e-01
    z[5,6,5]  R2255     0.622606098651886
    z[5,6,5]  R2256     2.4356535077095032e-01
    z[5,6,5]  R2257     -3.0759337544441223e-01
    z[5,6,5]  R2258     -2.7960723638534546e-01
    z[5,6,5]  R2259     -0.421384334564209
    z[5,6,5]  R2260     -5.0109249353408813e-01
    z[5,6,5]  R2261     -6.7544782161712646e-01
    z[5,6,5]  R2262     5.5559748411178589e-01
    z[5,6,5]  R2263     3.2968875765800476e-01
    z[5,6,5]  R2264     4.8926264047622681e-02
    z[5,6,5]  R2265     1.0916931927204132e-01
    z[5,6,5]  R2266     -2.5254514813423157e-01
    z[5,6,5]  R2267     -6.4476072788238525e-01
    z[5,6,5]  R2268     3.6030894517898560e-01
    z[5,6,5]  R2269     -4.0189573168754578e-01
    z[5,6,5]  R2270     -2.4131463468074799e-01
    z[5,6,5]  R2271     -2.2471027076244354e-01
    z[5,6,5]  R2272     0.314242959022522
    z[5,6,5]  R2273     -3.2006821036338806e-01
    z[5,6,5]  R2274     -3.0427744984626770e-01
    z[5,6,5]  R2275     1.2288712710142136e-01
    z[5,6,5]  R2276     9.0067885816097260e-02
    z[5,6,5]  R2277     -4.1855999827384949e-01
    z[5,6,5]  R2278     -5.1251932978630066e-02
    z[5,6,5]  R2279     -3.1081253290176392e-01
    z[5,6,5]  R2280     -4.3841204047203064e-01
    z[5,6,5]  R2281     -4.6696880459785461e-01
    z[5,6,5]  R2282     -7.8776758909225464e-01
    z[5,6,5]  R2283     -0.0409141406416893
    z[5,6,5]  R2284     -4.1150298714637756e-01
    z[5,6,5]  R2285     -4.4737223535776138e-02
    z[5,6,5]  R2286     -2.4522005021572113e-01
    z[5,6,5]  R2287     -4.9179011583328247e-01
    z[5,6,5]  R2288     -4.9940440058708191e-01
    z[5,6,5]  R2289     -7.4444037675857544e-01
    z[5,6,5]  R2290     1.4940799772739410e-01
    z[5,6,5]  R2291     2.4619838595390320e-01
    z[5,6,5]  R2292     -1.0064287483692169e-01
    z[5,6,5]  R2293     4.2561632394790649e-01
    z[5,6,5]  R2294     9.8149076104164124e-02
    z[5,6,5]  R2295     1.9988100230693817e-01
    z[5,6,5]  R2296     -2.0188757777214050e-01
    z[5,6,5]  R2297     1.4005610346794128e-01
    z[5,6,5]  R2298     -0.479707807302475
    z[5,6,5]  R2299     -8.0626225471496582e-01
    z[5,6,5]  R2300     -1.2126793712377548e-01
    z[5,6,5]  R2301     1.4181299507617950e-01
    z[5,6,5]  R2302     1.1308369040489197e-01
    z[5,6,5]  R2303     4.5485013723373413e-01
    z[5,6,5]  R2304     -2.9244298115372658e-02
    z[5,6,5]  R2305     1.4941900968551636e-01
    z[5,6,5]  R2306     -2.0874448120594025e-01
    z[5,6,5]  R2307     -7.2684699296951294e-01
    z[5,6,5]  R2308     -3.9484921097755432e-01
    z[5,6,5]  R2309     -1.2284660339355469e-01
    z[5,6,5]  R2310     1.7613308131694794e-01
    z[5,6,5]  R2311     -1.5199208259582520e-01
    z[5,6,5]  R2312     -0.0385298952460289
    z[5,6,5]  R2313     -3.2177552580833435e-02
    z[5,6,5]  R2314     -2.9607942700386047e-01
    z[5,6,5]  R2315     -3.6532118916511536e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2174     -1
    z[5,6,6]  R2175     1
    z[5,6,6]  R2176     1.6800431907176971e-01
    z[5,6,6]  R2177     -4.8735892772674561e-01
    z[5,6,6]  R2178     -4.0737181901931763e-01
    z[5,6,6]  R2179     1.0580208152532578e-02
    z[5,6,6]  R2180     2.9227675870060921e-02
    z[5,6,6]  R2181     3.3393511176109314e-01
    z[5,6,6]  R2182     1.6795925796031952e-02
    z[5,6,6]  R2183     5.1053303480148315e-01
    z[5,6,6]  R2184     5.2124512195587158e-01
    z[5,6,6]  R2185     -4.1547316312789917e-01
    z[5,6,6]  R2186     -5.4954618215560913e-02
    z[5,6,6]  R2187     0.691472053527832
    z[5,6,6]  R2188     -0.139152392745018
    z[5,6,6]  R2189     -3.5400897264480591e-01
    z[5,6,6]  R2190     -1.1064770072698593e-01
    z[5,6,6]  R2191     1.7837829887866974e-01
    z[5,6,6]  R2192     1.2031418085098267e-01
    z[5,6,6]  R2193     1.7815624177455902e-01
    z[5,6,6]  R2194     3.4017577767372131e-01
    z[5,6,6]  R2195     3.4392920136451721e-01
    z[5,6,6]  R2196     8.1533983349800110e-02
    z[5,6,6]  R2197     -2.6450985670089722e-01
    z[5,6,6]  R2198     3.0140694230794907e-02
    z[5,6,6]  R2199     -3.3923369646072388e-01
    z[5,6,6]  R2200     1.1259863525629044e-01
    z[5,6,6]  R2201     1.2439736723899841e-01
    z[5,6,6]  R2202     -1.8044370412826538e-01
    z[5,6,6]  R2203     0.0785333588719368
    z[5,6,6]  R2204     1.3021877408027649e-01
    z[5,6,6]  R2205     2.2515854239463806e-01
    z[5,6,6]  R2206     -1.1770492047071457e-01
    z[5,6,6]  R2207     -4.4261552393436432e-03
    z[5,6,6]  R2208     -1.6064360737800598e-01
    z[5,6,6]  R2209     -1.6098898649215698e-01
    z[5,6,6]  R2210     -0.301470011472702
    z[5,6,6]  R2211     1.6815978288650513e-01
    z[5,6,6]  R2212     -1.2203180789947510e-01
    z[5,6,6]  R2213     1.4321976900100708e-01
    z[5,6,6]  R2214     -1.0164518840610981e-02
    z[5,6,6]  R2215     2.7247878909111023e-01
    z[5,6,6]  R2216     1.8773525953292847e-01
    z[5,6,6]  R2217     -2.3031197488307953e-01
    z[5,6,6]  R2218     3.7443738430738449e-02
    z[5,6,6]  R2219     -5.8671992272138596e-02
    z[5,6,6]  R2220     -4.4896829128265381e-01
    z[5,6,6]  R2221     0.0770488902926445
    z[5,6,6]  R2222     -2.5659623742103577e-01
    z[5,6,6]  R2223     -7.1774378418922424e-02
    z[5,6,6]  R2224     3.3430272340774536e-01
    z[5,6,6]  R2225     2.6974827051162720e-02
    z[5,6,6]  R2226     -6.8659879267215729e-02
    z[5,6,6]  R2227     8.4615841507911682e-02
    z[5,6,6]  R2228     9.7019389271736145e-02
    z[5,6,6]  R2229     3.8433033227920532e-01
    z[5,6,6]  R2230     -6.3249057531356812e-01
    z[5,6,6]  R2231     -2.1371269226074219e-01
    z[5,6,6]  R2232     -4.1133394837379456e-01
    z[5,6,6]  R2233     -0.0805663913488388
    z[5,6,6]  R2234     1.8261478841304779e-01
    z[5,6,6]  R2235     -2.9590731486678123e-02
    z[5,6,6]  R2236     -9.6845522522926331e-02
    z[5,6,6]  R2237     2.0080134272575378e-01
    z[5,6,6]  R2238     -2.0039488375186920e-01
    z[5,6,6]  R2239     3.6406585574150085e-01
    z[5,6,6]  R2240     -2.0754756033420563e-01
    z[5,6,6]  R2241     0.0768914446234703
    z[5,6,6]  R2242     1.9086304306983948e-01
    z[5,6,6]  R2243     2.0770902931690216e-01
    z[5,6,6]  R2244     4.1985239833593369e-02
    z[5,6,6]  R2245     -2.1316848695278168e-01
    z[5,6,6]  R2246     -7.0847973227500916e-02
    z[5,6,6]  R2247     1.4123211801052094e-01
    z[5,6,6]  R2248     -7.8969992697238922e-02
    z[5,6,6]  R2249     -1.1099644750356674e-01
    z[5,6,6]  R2250     -1.9904676079750061e-01
    z[5,6,6]  R2251     -2.7316769957542419e-01
    z[5,6,6]  R2252     3.7511962652206421e-01
    z[5,6,6]  R2253     -2.7071639895439148e-01
    z[5,6,6]  R2254     0.0816039890050888
    z[5,6,6]  R2255     1.1319984495639801e-01
    z[5,6,6]  R2256     2.7768164873123169e-01
    z[5,6,6]  R2257     6.2627747654914856e-02
    z[5,6,6]  R2258     -0.0424545481801033
    z[5,6,6]  R2259     -4.8246022313833237e-02
    z[5,6,6]  R2260     -1.7423997819423676e-01
    z[5,6,6]  R2261     -2.3064975440502167e-01
    z[5,6,6]  R2262     -2.5198507308959961e-01
    z[5,6,6]  R2263     -2.8632849454879761e-01
    z[5,6,6]  R2264     -1.7734473943710327e-01
    z[5,6,6]  R2265     0.0823395624756813
    z[5,6,6]  R2266     -2.5365290045738220e-01
    z[5,6,6]  R2267     5.3452465683221817e-02
    z[5,6,6]  R2268     1.7981614917516708e-02
    z[5,6,6]  R2269     8.4437653422355652e-02
    z[5,6,6]  R2270     1.7719270288944244e-01
    z[5,6,6]  R2271     -4.9363183975219727e-01
    z[5,6,6]  R2272     1.7795109748840332e-01
    z[5,6,6]  R2273     -6.2378573417663574e-01
    z[5,6,6]  R2274     -2.1367833018302917e-01
    z[5,6,6]  R2275     1.7445491254329681e-01
    z[5,6,6]  R2276     1.5673954784870148e-01
    z[5,6,6]  R2277     -0.282549113035202
    z[5,6,6]  R2278     -9.0264402329921722e-02
    z[5,6,6]  R2279     2.8157643973827362e-03
    z[5,6,6]  R2280     -6.1274436302483082e-03
    z[5,6,6]  R2281     2.0600537955760956e-01
    z[5,6,6]  R2282     1.3947731256484985e-01
    z[5,6,6]  R2283     1.3983491063117981e-01
    z[5,6,6]  R2284     -2.2028565406799316e-01
    z[5,6,6]  R2285     1.3029728829860687e-01
    z[5,6,6]  R2286     -2.9339674860239029e-02
    z[5,6,6]  R2287     -1.4245378971099854e-01
    z[5,6,6]  R2288     -0.257985919713974
    z[5,6,6]  R2289     -2.4304588139057159e-01
    z[5,6,6]  R2290     -5.2570408582687378e-01
    z[5,6,6]  R2291     3.2696448266506195e-02
    z[5,6,6]  R2292     -3.7743654102087021e-02
    z[5,6,6]  R2293     -0.148038849234581
    z[5,6,6]  R2294     -2.4738231301307678e-01
    z[5,6,6]  R2295     -2.0432794094085693e-01
    z[5,6,6]  R2296     -1.5077529847621918e-01
    z[5,6,6]  R2297     -1.4350248873233795e-01
    z[5,6,6]  R2298     1.1306065320968628e-01
    z[5,6,6]  R2299     1.0979101061820984e-01
    z[5,6,6]  R2300     3.0902945995330811e-01
    z[5,6,6]  R2301     0.0984988585114479
    z[5,6,6]  R2302     -3.4991574287414551e-01
    z[5,6,6]  R2303     -1.4413505792617798e-01
    z[5,6,6]  R2304     2.2152608260512352e-02
    z[5,6,6]  R2305     -7.0057488977909088e-02
    z[5,6,6]  R2306     1.2082371860742569e-01
    z[5,6,6]  R2307     7.4731156229972839e-02
    z[5,6,6]  R2308     0.2565937936306
    z[5,6,6]  R2309     2.3028762638568878e-01
    z[5,6,6]  R2310     -2.3457955569028854e-02
    z[5,6,6]  R2311     1.1988984793424606e-01
    z[5,6,6]  R2312     1.9500355422496796e-01
    z[5,6,6]  R2313     5.0898820161819458e-01
    z[5,6,6]  R2314     4.6658405661582947e-01
    z[5,6,6]  R2315     1.8439665436744690e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2316     -1
    z[6,5,0]  R2317     1
    z[6,5,0]  R2330     -8.7384122610092163e-01
    z[6,5,0]  R2331     -8.8748365640640259e-01
    z[6,5,0]  R2332     -9.4941294193267822e-01
    z[6,5,0]  R2333     -8.5786253213882446e-01
    z[6,5,0]  R2334     -9.1623759269714355e-01
    z[6,5,0]  R2335     -7.2450643777847290e-01
    z[6,5,0]  R2336     -9.3621307611465454e-01
    z[6,5,0]  R2337     -0.96856290102005
    z[6,5,0]  R2338     -8.3268773555755615e-01
    z[6,5,0]  R2339     -8.0606764554977417e-01
    z[6,5,0]  R2340     2.0103774964809418e-01
    z[6,5,0]  R2341     2.1778398752212524e-01
    z[6,5,0]  R2342     1.9404245913028717e-01
    z[6,5,0]  R2343     -0.0822681114077568
    z[6,5,0]  R2344     -2.5601822417229414e-03
    z[6,5,0]  R2345     2.5686609745025635e-01
    z[6,5,0]  R2346     2.3033238947391510e-01
    z[6,5,0]  R2347     3.1332874298095703e-01
    z[6,5,0]  R2348     -1.5054904855787754e-02
    z[6,5,0]  R2349     1.5797884762287140e-01
    z[6,5,0]  R2350     8.2420194149017334e-01
    z[6,5,0]  R2351     4.1432134807109833e-02
    z[6,5,0]  R2352     0.51854008436203
    z[6,5,0]  R2353     7.2541677951812744e-01
    z[6,5,0]  R2354     5.0932067632675171e-01
    z[6,5,0]  R2355     5.2500754594802856e-01
    z[6,5,0]  R2356     3.7646532058715820e-01
    z[6,5,0]  R2357     7.7187612652778625e-02
    z[6,5,0]  R2358     5.5519080162048340e-01
    z[6,5,0]  R2359     1.7107808589935303e-01
    z[6,5,0]  R2360     5.8747440576553345e-01
    z[6,5,0]  R2361     0.787808895111084
    z[6,5,0]  R2362     -1.2902888655662537e-01
    z[6,5,0]  R2363     7.3995554447174072e-01
    z[6,5,0]  R2364     1.4056351780891418e-01
    z[6,5,0]  R2365     6.9226735830307007e-01
    z[6,5,0]  R2366     2.5577588006854057e-02
    z[6,5,0]  R2367     8.1297689676284790e-01
    z[6,5,0]  R2368     5.6801873445510864e-01
    z[6,5,0]  R2369     -2.2160109877586365e-01
    z[6,5,0]  R2370     -1.0260418057441711e-03
    z[6,5,0]  R2371     3.2716092467308044e-01
    z[6,5,0]  R2372     4.2324984073638916e-01
    z[6,5,0]  R2373     4.8220828175544739e-02
    z[6,5,0]  R2374     0.618370532989502
    z[6,5,0]  R2375     5.8190727233886719e-01
    z[6,5,0]  R2376     3.2456271350383759e-02
    z[6,5,0]  R2377     -2.7239865064620972e-01
    z[6,5,0]  R2378     -3.8483291864395142e-01
    z[6,5,0]  R2379     7.6029294729232788e-01
    z[6,5,0]  R2380     -7.7624571323394775e-01
    z[6,5,0]  R2381     7.8828144073486328e-01
    z[6,5,0]  R2382     6.0670781135559082e-01
    z[6,5,0]  R2383     1.2974782288074493e-01
    z[6,5,0]  R2384     4.8424193263053894e-01
    z[6,5,0]  R2385     5.4049581289291382e-01
    z[6,5,0]  R2386     5.2734637260437012e-01
    z[6,5,0]  R2387     5.1648199558258057e-01
    z[6,5,0]  R2388     -3.5389885306358337e-01
    z[6,5,0]  R2389     0.0541507862508297
    z[6,5,0]  R2390     4.1410472989082336e-01
    z[6,5,0]  R2391     1.3840852305293083e-02
    z[6,5,0]  R2392     8.0886858701705933e-01
    z[6,5,0]  R2393     -4.1802600026130676e-01
    z[6,5,0]  R2394     -4.2783138155937195e-01
    z[6,5,0]  R2395     4.6446800231933594e-01
    z[6,5,0]  R2396     7.1531379222869873e-01
    z[6,5,0]  R2397     5.2551430463790894e-01
    z[6,5,0]  R2398     -3.5186198353767395e-01
    z[6,5,0]  R2399     7.0942497253417969e-01
    z[6,5,0]  R2400     8.9145672321319580e-01
    z[6,5,0]  R2401     4.3067368865013123e-01
    z[6,5,0]  R2402     -2.3954921960830688e-01
    z[6,5,0]  R2403     -5.8236384391784668e-01
    z[6,5,0]  R2404     6.2779515981674194e-01
    z[6,5,0]  R2405     5.2663028240203857e-01
    z[6,5,0]  R2406     4.8508965969085693e-01
    z[6,5,0]  R2407     8.4526282548904419e-01
    z[6,5,0]  R2408     -4.7784465551376343e-01
    z[6,5,0]  R2409     1.4369764365255833e-02
    z[6,5,0]  R2410     -7.4734479188919067e-01
    z[6,5,0]  R2411     6.1633431911468506e-01
    z[6,5,0]  R2412     0.401021271944046
    z[6,5,0]  R2413     4.8296386003494263e-01
    z[6,5,0]  R2414     0.680448055267334
    z[6,5,0]  R2415     -3.7621328234672546e-01
    z[6,5,0]  R2416     1.2038894742727280e-01
    z[6,5,0]  R2417     -1.7895002383738756e-04
    z[6,5,0]  R2418     -8.2989625632762909e-02
    z[6,5,0]  R2419     -2.8991684317588806e-02
    z[6,5,0]  R2420     -0.743486762046814
    z[6,5,0]  R2421     7.0977705717086792e-01
    z[6,5,0]  R2422     5.7753592729568481e-01
    z[6,5,0]  R2423     4.3028134107589722e-01
    z[6,5,0]  R2424     1.7088226974010468e-01
    z[6,5,0]  R2425     6.7804497666656971e-03
    z[6,5,0]  R2426     -6.1569139361381531e-02
    z[6,5,0]  R2427     3.5309992730617523e-02
    z[6,5,0]  R2428     -1.1695101112127304e-01
    z[6,5,0]  R2429     -4.5996751636266708e-02
    z[6,5,0]  R2430     7.2832182049751282e-03
    z[6,5,0]  R2431     6.1436778306961060e-01
    z[6,5,0]  R2432     5.5816221237182617e-01
    z[6,5,0]  R2433     -4.5648229122161865e-01
    z[6,5,0]  R2434     -3.2614029943943024e-02
    z[6,5,0]  R2435     -2.6928958296775818e-01
    z[6,5,0]  R2436     -1.3647805154323578e-01
    z[6,5,0]  R2437     2.3611165583133698e-02
    z[6,5,0]  R2438     -6.7060112953186035e-02
    z[6,5,0]  R2439     -0.0773346871137619
    z[6,5,0]  R2440     -1.4013829827308655e-01
    z[6,5,0]  R2441     -2.1680450439453125e-01
    z[6,5,0]  R2442     -5.3905218839645386e-01
    z[6,5,0]  R2443     4.9205985665321350e-01
    z[6,5,0]  R2444     3.9730939269065857e-01
    z[6,5,0]  R2445     5.3545570373535156e-01
    z[6,5,0]  R2446     3.9797511696815491e-01
    z[6,5,0]  R2447     4.7793468832969666e-01
    z[6,5,0]  R2448     5.0514614582061768e-01
    z[6,5,0]  R2449     5.3256362676620483e-01
    z[6,5,0]  R2450     -1.5803965926170349e-01
    z[6,5,0]  R2451     -2.6606826111674309e-02
    z[6,5,0]  R2452     -1.0368255898356438e-02
    z[6,5,0]  R2453     1.1904559284448624e-01
    z[6,5,0]  R2454     1.7774741351604462e-01
    z[6,5,0]  R2455     -1.5899810194969177e-01
    z[6,5,0]  R2456     5.0254738330841064e-01
    z[6,5,0]  R2457     9.1045953333377838e-02
    z[6,5,0]  R2458     -0.510917067527771
    z[6,5,0]  R2459     -4.8073145747184753e-01
    z[6,5,0]  R2460     6.4875298738479614e-01
    z[6,5,0]  R2461     4.3376949429512024e-01
    z[6,5,0]  R2462     4.7673863172531128e-01
    z[6,5,0]  R2463     5.3648990392684937e-01
    z[6,5,0]  R2464     5.0994259119033813e-01
    z[6,5,0]  R2465     5.7621508836746216e-01
    z[6,5,0]  R2466     4.2194086313247681e-01
    z[6,5,0]  R2467     5.3625619411468506e-01
    z[6,5,0]  R2468     4.2689137160778046e-02
    z[6,5,0]  R2469     -9.4247311353683472e-02
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2318     -1
    z[6,5,1]  R2319     1
    z[6,5,1]  R2330     -3.8983193039894104e-01
    z[6,5,1]  R2331     -3.6499857902526855e-01
    z[6,5,1]  R2332     -2.1544776856899261e-02
    z[6,5,1]  R2333     -6.8940952420234680e-02
    z[6,5,1]  R2334     -1.2151963263750076e-01
    z[6,5,1]  R2335     -5.3895201534032822e-02
    z[6,5,1]  R2336     3.3995623234659433e-03
    z[6,5,1]  R2337     -6.3452741596847773e-04
    z[6,5,1]  R2338     2.7241089940071106e-01
    z[6,5,1]  R2339     -2.8118479251861572e-01
    z[6,5,1]  R2340     -5.0241601467132568e-01
    z[6,5,1]  R2341     -1.9956082105636597e-01
    z[6,5,1]  R2342     -5.9879440069198608e-01
    z[6,5,1]  R2343     -7.0977377891540527e-01
    z[6,5,1]  R2344     -4.8572760820388794e-01
    z[6,5,1]  R2345     -5.2118331193923950e-01
    z[6,5,1]  R2346     -6.8679213523864746e-02
    z[6,5,1]  R2347     -5.8934754133224487e-01
    z[6,5,1]  R2348     -4.0870368480682373e-01
    z[6,5,1]  R2349     -5.2850800752639771e-01
    z[6,5,1]  R2350     -3.1171565875411034e-02
    z[6,5,1]  R2351     -9.5037811994552612e-01
    z[6,5,1]  R2352     3.0611717700958252e-01
    z[6,5,1]  R2353     1.5424132347106934e-01
    z[6,5,1]  R2354     -9.2823922634124756e-02
    z[6,5,1]  R2355     3.5708022117614746e-01
    z[6,5,1]  R2356     -5.2102571725845337e-01
    z[6,5,1]  R2357     6.6686397790908813e-01
    z[6,5,1]  R2358     -1.4312581717967987e-01
    z[6,5,1]  R2359     6.0229659080505371e-01
    z[6,5,1]  R2360     -3.4938564896583557e-01
    z[6,5,1]  R2361     1.5225054323673248e-01
    z[6,5,1]  R2362     -7.8362977504730225e-01
    z[6,5,1]  R2363     0.045985147356987
    z[6,5,1]  R2364     -8.9270532131195068e-01
    z[6,5,1]  R2365     1.0074172914028168e-01
    z[6,5,1]  R2366     -6.3061875104904175e-01
    z[6,5,1]  R2367     -3.0362397432327271e-01
    z[6,5,1]  R2368     1.2596595287322998e-01
    z[6,5,1]  R2369     -5.5027091503143311e-01
    z[6,5,1]  R2370     -7.6516550779342651e-01
    z[6,5,1]  R2371     -8.8505178689956665e-01
    z[6,5,1]  R2372     -5.2559173107147217e-01
    z[6,5,1]  R2373     -0.89644455909729
    z[6,5,1]  R2374     2.1496775746345520e-01
    z[6,5,1]  R2375     -2.3313325643539429e-01
    z[6,5,1]  R2376     -7.7686858177185059e-01
    z[6,5,1]  R2377     -5.5272829532623291e-01
    z[6,5,1]  R2378     -1.3243253529071808e-01
    z[6,5,1]  R2379     -3.7105970084667206e-02
    z[6,5,1]  R2380     -2.6720070838928223e-01
    z[6,5,1]  R2381     -3.0520877242088318e-01
    z[6,5,1]  R2382     -4.4281157851219177e-01
    z[6,5,1]  R2383     -4.7522720694541931e-01
    z[6,5,1]  R2384     -1.7094098031520844e-01
    z[6,5,1]  R2385     -1.9637905061244965e-01
    z[6,5,1]  R2386     -4.5808512717485428e-02
    z[6,5,1]  R2387     2.2161212563514709e-01
    z[6,5,1]  R2388     7.5454115867614746e-01
    z[6,5,1]  R2389     8.6229842901229858e-01
    z[6,5,1]  R2390     -2.6137259602546692e-01
    z[6,5,1]  R2391     -6.7997843027114868e-01
    z[6,5,1]  R2392     1.7777520418167114e-01
    z[6,5,1]  R2393     -6.4122051000595093e-01
    z[6,5,1]  R2394     -0.055446557700634
    z[6,5,1]  R2395     -2.7222353219985962e-01
    z[6,5,1]  R2396     -2.6235067844390869e-01
    z[6,5,1]  R2397     -1.5870186686515808e-01
    z[6,5,1]  R2398     1.6907547414302826e-01
    z[6,5,1]  R2399     2.0996022969484329e-02
    z[6,5,1]  R2400     -1.4200265705585480e-01
    z[6,5,1]  R2401     -3.0012896656990051e-01
    z[6,5,1]  R2402     -7.6789957284927368e-01
    z[6,5,1]  R2403     -5.6674383580684662e-02
    z[6,5,1]  R2404     -1.9198960065841675e-01
    z[6,5,1]  R2405     -1.4512595720589161e-02
    z[6,5,1]  R2406     3.6846555769443512e-02
    z[6,5,1]  R2407     2.8690424561500549e-01
    z[6,5,1]  R2408     4.8175626993179321e-01
    z[6,5,1]  R2409     7.9874765872955322e-01
    z[6,5,1]  R2410     -1.4394551515579224e-02
    z[6,5,1]  R2411     -3.0781856179237366e-01
    z[6,5,1]  R2412     -2.7524015307426453e-01
    z[6,5,1]  R2413     -2.0112356543540955e-01
    z[6,5,1]  R2414     1.0570946335792542e-01
    z[6,5,1]  R2415     -1.8369263410568237e-01
    z[6,5,1]  R2416     5.2311939001083374e-01
    z[6,5,1]  R2417     7.2564291954040527e-01
    z[6,5,1]  R2418     7.3291534185409546e-01
    z[6,5,1]  R2419     8.1506699323654175e-01
    z[6,5,1]  R2420     9.3010291457176208e-02
    z[6,5,1]  R2421     -1.8123178184032440e-01
    z[6,5,1]  R2422     -0.145138680934906
    z[6,5,1]  R2423     -2.4333159625530243e-01
    z[6,5,1]  R2424     -4.8579236865043640e-01
    z[6,5,1]  R2425     6.5936404466629028e-01
    z[6,5,1]  R2426     6.2111669778823853e-01
    z[6,5,1]  R2427     0.584827721118927
    z[6,5,1]  R2428     8.8545787334442139e-01
    z[6,5,1]  R2429     8.1723350286483765e-01
    z[6,5,1]  R2430     -4.9319869279861450e-01
    z[6,5,1]  R2431     -1.6294093430042267e-01
    z[6,5,1]  R2432     -5.0169759988784790e-01
    z[6,5,1]  R2433     -3.1170082092285156e-01
    z[6,5,1]  R2434     9.1450905799865723e-01
    z[6,5,1]  R2435     8.0454438924789429e-01
    z[6,5,1]  R2436     0.808972954750061
    z[6,5,1]  R2437     6.4437693357467651e-01
    z[6,5,1]  R2438     6.1878538131713867e-01
    z[6,5,1]  R2439     0.753345787525177
    z[6,5,1]  R2440     -8.1982904672622681e-01
    z[6,5,1]  R2441     -2.2912929952144623e-01
    z[6,5,1]  R2442     -3.9167895913124084e-01
    z[6,5,1]  R2443     4.6158227324485779e-01
    z[6,5,1]  R2444     6.3057202100753784e-01
    z[6,5,1]  R2445     4.6942472457885742e-01
    z[6,5,1]  R2446     4.7702306509017944e-01
    z[6,5,1]  R2447     4.2926475405693054e-01
    z[6,5,1]  R2448     4.4876602292060852e-01
    z[6,5,1]  R2449     3.6234620213508606e-01
    z[6,5,1]  R2450     1.2943477928638458e-01
    z[6,5,1]  R2451     -6.0232721269130707e-02
    z[6,5,1]  R2452     9.3906730413436890e-01
    z[6,5,1]  R2453     0.767741858959198
    z[6,5,1]  R2454     7.5549668073654175e-01
    z[6,5,1]  R2455     5.7971423864364624e-01
    z[6,5,1]  R2456     4.6100342273712158e-01
    z[6,5,1]  R2457     7.0692896842956543e-01
    z[6,5,1]  R2458     4.7931188344955444e-01
    z[6,5,1]  R2459     6.4421904087066650e-01
    z[6,5,1]  R2460     7.3177880048751831e-01
    z[6,5,1]  R2461     8.4226936101913452e-01
    z[6,5,1]  R2462     8.3228170871734619e-01
    z[6,5,1]  R2463     7.5504338741302490e-01
    z[6,5,1]  R2464     7.6662635803222656e-01
    z[6,5,1]  R2465     6.8480169773101807e-01
    z[6,5,1]  R2466     8.0933910608291626e-01
    z[6,5,1]  R2467     6.9874179363250732e-01
    z[6,5,1]  R2468     7.6158493757247925e-01
    z[6,5,1]  R2469     6.6127419471740723e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2320     -1
    z[6,5,2]  R2321     1
    z[6,5,2]  R2330     -1.7520034313201904e-01
    z[6,5,2]  R2331     -1.1685901880264282e-01
    z[6,5,2]  R2332     -1.6333484649658203e-01
    z[6,5,2]  R2333     -2.6785880327224731e-01
    z[6,5,2]  R2334     -1.8257641792297363e-01
    z[6,5,2]  R2335     -5.3789663314819336e-01
    z[6,5,2]  R2336     -1.7760933935642242e-01
    z[6,5,2]  R2337     -1.7945638298988342e-01
    z[6,5,2]  R2338     -3.8195076584815979e-01
    z[6,5,2]  R2339     -0.0339924618601799
    z[6,5,2]  R2340     2.8260305523872375e-01
    z[6,5,2]  R2341     7.1075963973999023e-01
    z[6,5,2]  R2342     6.8378818035125732e-01
    z[6,5,2]  R2343     5.4878199100494385e-01
    z[6,5,2]  R2344     4.9439480900764465e-01
    z[6,5,2]  R2345     6.2343740463256836e-01
    z[6,5,2]  R2346     5.0190275907516479e-01
    z[6,5,2]  R2347     4.8393711447715759e-01
    z[6,5,2]  R2348     3.8058194518089294e-01
    z[6,5,2]  R2349     4.3565174937248230e-01
    z[6,5,2]  R2350     3.2944139838218689e-01
    z[6,5,2]  R2351     -1.5970049798488617e-01
    z[6,5,2]  R2352     6.8351435661315918e-01
    z[6,5,2]  R2353     2.4656991660594940e-01
    z[6,5,2]  R2354     1.1712289601564407e-01
    z[6,5,2]  R2355     6.8361848592758179e-01
    z[6,5,2]  R2356     -1.3215051591396332e-01
    z[6,5,2]  R2357     -6.0098522901535034e-01
    z[6,5,2]  R2358     4.9145266413688660e-01
    z[6,5,2]  R2359     -0.706415057182312
    z[6,5,2]  R2360     3.1549575924873352e-01
    z[6,5,2]  R2361     3.8917210698127747e-01
    z[6,5,2]  R2362     4.1174092888832092e-01
    z[6,5,2]  R2363     3.1450986862182617e-01
    z[6,5,2]  R2364     4.2288318276405334e-02
    z[6,5,2]  R2365     6.3316076993942261e-01
    z[6,5,2]  R2366     2.1973705291748047e-01
    z[6,5,2]  R2367     -5.7728279381990433e-02
    z[6,5,2]  R2368     7.7076196670532227e-01
    z[6,5,2]  R2369     2.6455268263816833e-01
    z[6,5,2]  R2370     4.2389449477195740e-01
    z[6,5,2]  R2371     2.2439652681350708e-01
    z[6,5,2]  R2372     6.4922392368316650e-01
    z[6,5,2]  R2373     1.6333243250846863e-01
    z[6,5,2]  R2374     5.4032075405120850e-01
    z[6,5,2]  R2375     -1.8255543708801270e-01
    z[6,5,2]  R2376     3.0196553096175194e-02
    z[6,5,2]  R2377     0.215520977973938
    z[6,5,2]  R2378     -6.1001914739608765e-01
    z[6,5,2]  R2379     8.8725559413433075e-02
    z[6,5,2]  R2380     -2.3672574758529663e-01
    z[6,5,2]  R2381     2.5989213585853577e-01
    z[6,5,2]  R2382     1.6411387920379639e-01
    z[6,5,2]  R2383     2.8355222940444946e-01
    z[6,5,2]  R2384     9.0234234929084778e-02
    z[6,5,2]  R2385     -1.9573102891445160e-01
    z[6,5,2]  R2386     4.8574164509773254e-01
    z[6,5,2]  R2387     6.5591341257095337e-01
    z[6,5,2]  R2388     -3.4801873564720154e-01
    z[6,5,2]  R2389     -4.6952879428863525e-01
    z[6,5,2]  R2390     6.7564022541046143e-01
    z[6,5,2]  R2391     1.2817643582820892e-03
    z[6,5,2]  R2392     4.2216774821281433e-01
    z[6,5,2]  R2393     1.5791609883308411e-01
    z[6,5,2]  R2394     -7.6735556125640869e-01
    z[6,5,2]  R2395     2.5689122080802917e-01
    z[6,5,2]  R2396     0.395819753408432
    z[6,5,2]  R2397     2.0394693315029144e-01
    z[6,5,2]  R2398     -6.5956008434295654e-01
    z[6,5,2]  R2399     0.0963897705078125
    z[6,5,2]  R2400     2.1616187691688538e-01
    z[6,5,2]  R2401     3.8360023498535156e-01
    z[6,5,2]  R2402     0.522737979888916
    z[6,5,2]  R2403     -5.8665275573730469e-01
    z[6,5,2]  R2404     0.257693350315094
    z[6,5,2]  R2405     5.1851803064346313e-01
    z[6,5,2]  R2406     3.2036128640174866e-01
    z[6,5,2]  R2407     3.1420376896858215e-01
    z[6,5,2]  R2408     -4.5502316951751709e-01
    z[6,5,2]  R2409     -4.5573037862777710e-01
    z[6,5,2]  R2410     -6.1263483762741089e-01
    z[6,5,2]  R2411     3.7518495321273804e-01
    z[6,5,2]  R2412     4.6717628836631775e-01
    z[6,5,2]  R2413     2.9142412543296814e-01
    z[6,5,2]  R2414     3.8473892211914062e-01
    z[6,5,2]  R2415     4.9168238043785095e-01
    z[6,5,2]  R2416     -8.2693254947662354e-01
    z[6,5,2]  R2417     -3.9073020219802856e-01
    z[6,5,2]  R2418     -0.315792053937912
    z[6,5,2]  R2419     -1.5693803131580353e-01
    z[6,5,2]  R2420     -0.431908518075943
    z[6,5,2]  R2421     4.6711099147796631e-01
    z[6,5,2]  R2422     5.1746422052383423e-01
    z[6,5,2]  R2423     1.6701912879943848e-01
    z[6,5,2]  R2424     2.2287330031394958e-01
    z[6,5,2]  R2425     -6.4267307519912720e-01
    z[6,5,2]  R2426     -5.4743212461471558e-01
    z[6,5,2]  R2427     -5.9905093908309937e-01
    z[6,5,2]  R2428     3.9783951640129089e-01
    z[6,5,2]  R2429     5.3042483329772949e-01
    z[6,5,2]  R2430     6.0604417324066162e-01
    z[6,5,2]  R2431     1.0132411122322083e-01
    z[6,5,2]  R2432     2.7886566519737244e-01
    z[6,5,2]  R2433     -4.7770851850509644e-01
    z[6,5,2]  R2434     -3.4008646011352539e-01
    z[6,5,2]  R2435     3.9407119154930115e-01
    z[6,5,2]  R2436     4.1896224021911621e-01
    z[6,5,2]  R2437     5.4252862930297852e-01
    z[6,5,2]  R2438     5.3949481248855591e-01
    z[6,5,2]  R2439     3.8305473327636719e-01
    z[6,5,2]  R2440     -3.5748252272605896e-01
    z[6,5,2]  R2441     -3.6852023005485535e-01
    z[6,5,2]  R2442     4.9215239286422729e-01
    z[6,5,2]  R2443     2.5748586654663086e-01
    z[6,5,2]  R2444     -6.4546324312686920e-02
    z[6,5,2]  R2445     -1.7670178413391113e-01
    z[6,5,2]  R2446     -6.9458144903182983e-01
    z[6,5,2]  R2447     4.8162847757339478e-01
    z[6,5,2]  R2448     -4.8755022883415222e-01
    z[6,5,2]  R2449     1.5100403130054474e-01
    z[6,5,2]  R2450     2.8145718574523926e-01
    z[6,5,2]  R2451     2.6563405990600586e-01
    z[6,5,2]  R2452     -1.6246227920055389e-01
    z[6,5,2]  R2453     1.0238543152809143e-01
    z[6,5,2]  R2454     -0.0772957056760788
    z[6,5,2]  R2455     -3.6308398842811584e-01
    z[6,5,2]  R2456     1.7393574118614197e-01
    z[6,5,2]  R2457     -2.4055273830890656e-01
    z[6,5,2]  R2458     -5.8491069078445435e-01
    z[6,5,2]  R2459     -4.0013724565505981e-01
    z[6,5,2]  R2460     3.0864465981721878e-02
    z[6,5,2]  R2461     4.3979067355394363e-02
    z[6,5,2]  R2462     -2.0543819665908813e-01
    z[6,5,2]  R2463     -1.1190900579094887e-02
    z[6,5,2]  R2464     2.6367226243019104e-01
    z[6,5,2]  R2465     -5.7455807924270630e-02
    z[6,5,2]  R2466     -2.1146422252058983e-02
    z[6,5,2]  R2467     -3.4737319219857454e-03
    z[6,5,2]  R2468     -5.0904309749603271e-01
    z[6,5,2]  R2469     -6.3758021593093872e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2322     -1
    z[6,5,3]  R2323     1
    z[6,5,3]  R2330     1.9722686707973480e-01
    z[6,5,3]  R2331     -1.7805849015712738e-01
    z[6,5,3]  R2332     -1.3938149809837341e-01
    z[6,5,3]  R2333     3.1448623538017273e-01
    z[6,5,3]  R2334     0.00422905758023262
    z[6,5,3]  R2335     3.0133891850709915e-02
    z[6,5,3]  R2336     -5.1916502416133881e-02
    z[6,5,3]  R2337     -4.8395209014415741e-02
    z[6,5,3]  R2338     -7.3296025395393372e-02
    z[6,5,3]  R2339     2.6381894946098328e-01
    z[6,5,3]  R2340     -3.9144456386566162e-01
    z[6,5,3]  R2341     2.1493844687938690e-01
    z[6,5,3]  R2342     -3.2905817031860352e-02
    z[6,5,3]  R2343     1.3282246887683868e-01
    z[6,5,3]  R2344     -4.2959639430046082e-01
    z[6,5,3]  R2345     -2.6216539740562439e-01
    z[6,5,3]  R2346     -1.5089030377566814e-02
    z[6,5,3]  R2347     2.9635429382324219e-01
    z[6,5,3]  R2348     -3.1604444980621338e-01
    z[6,5,3]  R2349     2.2651587426662445e-01
    z[6,5,3]  R2350     1.9076961278915405e-01
    z[6,5,3]  R2351     -1.6248348355293274e-01
    z[6,5,3]  R2352     -3.2762053608894348e-01
    z[6,5,3]  R2353     -9.8815739154815674e-02
    z[6,5,3]  R2354     4.4113656878471375e-01
    z[6,5,3]  R2355     1.8524500727653503e-01
    z[6,5,3]  R2356     2.6893270015716553e-01
    z[6,5,3]  R2357     -8.2504920661449432e-02
    z[6,5,3]  R2358     -3.0172142386436462e-01
    z[6,5,3]  R2359     2.6870843768119812e-01
    z[6,5,3]  R2360     2.9335431754589081e-02
    z[6,5,3]  R2361     1.2446004152297974e-01
    z[6,5,3]  R2362     -0.279773473739624
    z[6,5,3]  R2363     1.1687626689672470e-01
    z[6,5,3]  R2364     1.3141964375972748e-01
    z[6,5,3]  R2365     -3.0197307467460632e-01
    z[6,5,3]  R2366     -0.718078076839447
    z[6,5,3]  R2367     -2.2317622601985931e-01
    z[6,5,3]  R2368     -7.3442630469799042e-02
    z[6,5,3]  R2369     -1.9902646541595459e-01
    z[6,5,3]  R2370     -3.9294418692588806e-01
    z[6,5,3]  R2371     -1.0631754249334335e-01
    z[6,5,3]  R2372     8.6140096187591553e-02
    z[6,5,3]  R2373     -0.0592268705368042
    z[6,5,3]  R2374     1.1346279084682465e-01
    z[6,5,3]  R2375     5.5354988574981689e-01
    z[6,5,3]  R2376     -2.1806603670120239e-01
    z[6,5,3]  R2377     1.3416700065135956e-01
    z[6,5,3]  R2378     -4.5715585350990295e-01
    z[6,5,3]  R2379     -2.9148977249860764e-02
    z[6,5,3]  R2380     -2.1368084847927094e-01
    z[6,5,3]  R2381     -1.3163023628294468e-02
    z[6,5,3]  R2382     5.4514998197555542e-01
    z[6,5,3]  R2383     -1.0321961343288422e-01
    z[6,5,3]  R2384     5.3564912080764771e-01
    z[6,5,3]  R2385     2.9216277599334717e-01
    z[6,5,3]  R2386     3.0592599511146545e-01
    z[6,5,3]  R2387     1.5349418856203556e-02
    z[6,5,3]  R2388     -1.7554216086864471e-01
    z[6,5,3]  R2389     1.0113058984279633e-01
    z[6,5,3]  R2390     4.0966841578483582e-01
    z[6,5,3]  R2391     -3.4179797768592834e-01
    z[6,5,3]  R2392     -2.9593538492918015e-03
    z[6,5,3]  R2393     -1.8164904788136482e-02
    z[6,5,3]  R2394     -3.0162784457206726e-01
    z[6,5,3]  R2395     2.2983743250370026e-01
    z[6,5,3]  R2396     2.0392403006553650e-01
    z[6,5,3]  R2397     3.1509986519813538e-01
    z[6,5,3]  R2398     -4.8180431127548218e-01
    z[6,5,3]  R2399     4.9940237402915955e-01
    z[6,5,3]  R2400     0.303492933511734
    z[6,5,3]  R2401     0.298991322517395
    z[6,5,3]  R2402     -9.7847640514373779e-02
    z[6,5,3]  R2403     -3.3750689029693604e-01
    z[6,5,3]  R2404     3.1253427267074585e-01
    z[6,5,3]  R2405     1.9220243394374847e-01
    z[6,5,3]  R2406     1.3646423816680908e-01
    z[6,5,3]  R2407     -2.2059574723243713e-01
    z[6,5,3]  R2408     1.5589003264904022e-01
    z[6,5,3]  R2409     3.3723658323287964e-01
    z[6,5,3]  R2410     5.4800111800432205e-02
    z[6,5,3]  R2411     1.9486233592033386e-01
    z[6,5,3]  R2412     1.5734905004501343e-01
    z[6,5,3]  R2413     -6.4490497112274170e-02
    z[6,5,3]  R2414     -0.0396580696105957
    z[6,5,3]  R2415     6.9540542364120483e-01
    z[6,5,3]  R2416     7.5495615601539612e-02
    z[6,5,3]  R2417     3.2061886787414551e-01
    z[6,5,3]  R2418     4.6656790375709534e-01
    z[6,5,3]  R2419     0.474361777305603
    z[6,5,3]  R2420     -3.0580973625183105e-01
    z[6,5,3]  R2421     4.5167854428291321e-01
    z[6,5,3]  R2422     -3.4414285421371460e-01
    z[6,5,3]  R2423     2.4899591505527496e-01
    z[6,5,3]  R2424     -7.5129413604736328e-01
    z[6,5,3]  R2425     3.4967169165611267e-01
    z[6,5,3]  R2426     4.1893583536148071e-01
    z[6,5,3]  R2427     -2.6354610919952393e-01
    z[6,5,3]  R2428     1.5516200102865696e-02
    z[6,5,3]  R2429     1.0314907878637314e-01
    z[6,5,3]  R2430     -0.500938892364502
    z[6,5,3]  R2431     1.9754789769649506e-01
    z[6,5,3]  R2432     2.4601487815380096e-01
    z[6,5,3]  R2433     -6.2834209203720093e-01
    z[6,5,3]  R2434     9.7366660833358765e-02
    z[6,5,3]  R2435     2.8921690583229065e-01
    z[6,5,3]  R2436     1.8290439248085022e-01
    z[6,5,3]  R2437     1.8155736848711967e-02
    z[6,5,3]  R2438     -1.2649394571781158e-01
    z[6,5,3]  R2439     -3.0813655257225037e-01
    z[6,5,3]  R2440     -3.0484458804130554e-01
    z[6,5,3]  R2441     3.0258995294570923e-01
    z[6,5,3]  R2442     2.6740673184394836e-01
    z[6,5,3]  R2443     -1.4441390335559845e-01
    z[6,5,3]  R2444     2.0342398434877396e-02
    z[6,5,3]  R2445     4.3444547057151794e-01
    z[6,5,3]  R2446     1.4450505375862122e-01
    z[6,5,3]  R2447     1.3760606944561005e-01
    z[6,5,3]  R2448     7.1704357862472534e-02
    z[6,5,3]  R2449     1.3513167202472687e-01
    z[6,5,3]  R2450     -0.828399121761322
    z[6,5,3]  R2451     -1.9924451410770416e-01
    z[6,5,3]  R2452     2.5086668133735657e-01
    z[6,5,3]  R2453     -1.1031280271708965e-02
    z[6,5,3]  R2454     1.5580029785633087e-01
    z[6,5,3]  R2455     6.5932929515838623e-01
    z[6,5,3]  R2456     3.1311213970184326e-01
    z[6,5,3]  R2457     2.7446320652961731e-01
    z[6,5,3]  R2458     1.5342476963996887e-01
    z[6,5,3]  R2459     -1.2894946336746216e-01
    z[6,5,3]  R2460     -1.0152570903301239e-01
    z[6,5,3]  R2461     3.4143622964620590e-02
    z[6,5,3]  R2462     4.4309478253126144e-02
    z[6,5,3]  R2463     -1.4164656400680542e-02
    z[6,5,3]  R2464     7.2648137807846069e-02
    z[6,5,3]  R2465     -4.9537453800439835e-02
    z[6,5,3]  R2466     0.332329660654068
    z[6,5,3]  R2467     4.5039889216423035e-01
    z[6,5,3]  R2468     2.8907701373100281e-01
    z[6,5,3]  R2469     1.0043850168585777e-02
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2324     -1
    z[6,5,4]  R2325     1
    z[6,5,4]  R2330     2.5442723184823990e-02
    z[6,5,4]  R2331     1.5681026875972748e-01
    z[6,5,4]  R2332     9.9835090339183807e-02
    z[6,5,4]  R2333     2.4434188008308411e-01
    z[6,5,4]  R2334     -3.4472875297069550e-02
    z[6,5,4]  R2335     3.6078128218650818e-01
    z[6,5,4]  R2336     2.0710060000419617e-01
    z[6,5,4]  R2337     4.5984137803316116e-02
    z[6,5,4]  R2338     2.6967635750770569e-01
    z[6,5,4]  R2339     3.3857962489128113e-01
    z[6,5,4]  R2340     1.8772387504577637e-01
    z[6,5,4]  R2341     -6.4913578331470490e-02
    z[6,5,4]  R2342     3.2985430955886841e-01
    z[6,5,4]  R2343     3.9232546091079712e-01
    z[6,5,4]  R2344     3.3945900201797485e-01
    z[6,5,4]  R2345     1.2313283234834671e-01
    z[6,5,4]  R2346     -4.2394474148750305e-01
    z[6,5,4]  R2347     3.2723551988601685e-01
    z[6,5,4]  R2348     5.8565360307693481e-01
    z[6,5,4]  R2349     2.8684270381927490e-01
    z[6,5,4]  R2350     -3.7396547198295593e-01
    z[6,5,4]  R2351     -1.7767411470413208e-01
    z[6,5,4]  R2352     2.1423611044883728e-01
    z[6,5,4]  R2353     4.1241145133972168e-01
    z[6,5,4]  R2354     -8.4720002487301826e-03
    z[6,5,4]  R2355     -2.1629419177770615e-02
    z[6,5,4]  R2356     -5.6049692630767822e-01
    z[6,5,4]  R2357     -4.1762074828147888e-01
    z[6,5,4]  R2358     -0.309527724981308
    z[6,5,4]  R2359     -1.8898989260196686e-01
    z[6,5,4]  R2360     -4.7102957963943481e-01
    z[6,5,4]  R2361     1.1562176048755646e-01
    z[6,5,4]  R2362     3.6604840308427811e-02
    z[6,5,4]  R2363     4.4977459311485291e-01
    z[6,5,4]  R2364     3.2556807994842529e-01
    z[6,5,4]  R2365     -3.6292336881160736e-02
    z[6,5,4]  R2366     2.5714278221130371e-02
    z[6,5,4]  R2367     -3.8738265633583069e-01
    z[6,5,4]  R2368     2.2139152884483337e-01
    z[6,5,4]  R2369     -3.5999670624732971e-01
    z[6,5,4]  R2370     -1.6703774034976959e-01
    z[6,5,4]  R2371     6.3023701310157776e-02
    z[6,5,4]  R2372     -3.0715823173522949e-02
    z[6,5,4]  R2373     -3.0421710014343262e-01
    z[6,5,4]  R2374     2.1932624280452728e-01
    z[6,5,4]  R2375     -1.7460497096180916e-02
    z[6,5,4]  R2376     4.3190225958824158e-01
    z[6,5,4]  R2377     0.67954021692276
    z[6,5,4]  R2378     -4.0179529786109924e-01
    z[6,5,4]  R2379     -1.0678673535585403e-01
    z[6,5,4]  R2380     2.9650720953941345e-01
    z[6,5,4]  R2381     -3.4526339173316956e-01
    z[6,5,4]  R2382     -1.7809841036796570e-01
    z[6,5,4]  R2383     6.9740664958953857e-01
    z[6,5,4]  R2384     3.9971670508384705e-01
    z[6,5,4]  R2385     -1.9026480615139008e-01
    z[6,5,4]  R2386     -1.3448676466941833e-01
    z[6,5,4]  R2387     -2.5099346041679382e-01
    z[6,5,4]  R2388     -3.4589907526969910e-01
    z[6,5,4]  R2389     -6.4240492880344391e-02
    z[6,5,4]  R2390     -8.8118426501750946e-02
    z[6,5,4]  R2391     4.5130811631679535e-02
    z[6,5,4]  R2392     -7.5812175869941711e-02
    z[6,5,4]  R2393     4.6922618150711060e-01
    z[6,5,4]  R2394     -2.1081276237964630e-01
    z[6,5,4]  R2395     -5.4514068365097046e-01
    z[6,5,4]  R2396     3.0137148499488831e-01
    z[6,5,4]  R2397     2.5732040405273438e-01
    z[6,5,4]  R2398     -2.0544733107089996e-01
    z[6,5,4]  R2399     4.3823051452636719e-01
    z[6,5,4]  R2400     1.1673387885093689e-01
    z[6,5,4]  R2401     -4.8256742954254150e-01
    z[6,5,4]  R2402     2.4360392987728119e-01
    z[6,5,4]  R2403     -3.2086694240570068e-01
    z[6,5,4]  R2404     4.6117997169494629e-01
    z[6,5,4]  R2405     3.9515700936317444e-01
    z[6,5,4]  R2406     4.5218691229820251e-02
    z[6,5,4]  R2407     -1.8601721525192261e-01
    z[6,5,4]  R2408     -3.0061137676239014e-01
    z[6,5,4]  R2409     1.4628148078918457e-01
    z[6,5,4]  R2410     -4.4163670390844345e-02
    z[6,5,4]  R2411     2.9067862033843994e-01
    z[6,5,4]  R2412     -4.5216238498687744e-01
    z[6,5,4]  R2413     -0.154743030667305
    z[6,5,4]  R2414     -2.7844479680061340e-01
    z[6,5,4]  R2415     -1.9415840506553650e-01
    z[6,5,4]  R2416     1.0383749753236771e-01
    z[6,5,4]  R2417     1.2211102247238159e-01
    z[6,5,4]  R2418     -2.6020416617393494e-01
    z[6,5,4]  R2419     -5.8943405747413635e-02
    z[6,5,4]  R2420     -3.0825346708297729e-01
    z[6,5,4]  R2421     3.0930081382393837e-02
    z[6,5,4]  R2422     -1.2759761512279510e-01
    z[6,5,4]  R2423     -6.0336075723171234e-02
    z[6,5,4]  R2424     1.0239310562610626e-01
    z[6,5,4]  R2425     -8.9971348643302917e-03
    z[6,5,4]  R2426     -2.2755637764930725e-03
    z[6,5,4]  R2427     -2.7343245223164558e-02
    z[6,5,4]  R2428     2.0597030222415924e-01
    z[6,5,4]  R2429     -1.0387220233678818e-01
    z[6,5,4]  R2430     2.8337278962135315e-01
    z[6,5,4]  R2431     1.1322257667779922e-01
    z[6,5,4]  R2432     2.7698168158531189e-01
    z[6,5,4]  R2433     -5.7650644332170486e-02
    z[6,5,4]  R2434     -7.6792903244495392e-02
    z[6,5,4]  R2435     -6.1464175581932068e-02
    z[6,5,4]  R2436     -2.8007525205612183e-01
    z[6,5,4]  R2437     -1.7160907387733459e-01
    z[6,5,4]  R2438     -1.3729830272495747e-02
    z[6,5,4]  R2439     -1.3171419501304626e-01
    z[6,5,4]  R2440     -5.1058534532785416e-02
    z[6,5,4]  R2441     0.531574547290802
    z[6,5,4]  R2442     2.7152130007743835e-01
    z[6,5,4]  R2443     -3.3534345030784607e-01
    z[6,5,4]  R2444     -1.8669579923152924e-01
    z[6,5,4]  R2445     1.6961827874183655e-01
    z[6,5,4]  R2446     -3.1581020355224609e-01
    z[6,5,4]  R2447     1.9509436190128326e-01
    z[6,5,4]  R2448     1.2445946782827377e-01
    z[6,5,4]  R2449     2.5597405433654785e-01
    z[6,5,4]  R2450     1.2232623249292374e-01
    z[6,5,4]  R2451     4.0399497747421265e-01
    z[6,5,4]  R2452     3.1204903498291969e-02
    z[6,5,4]  R2453     -5.0547176599502563e-01
    z[6,5,4]  R2454     -4.9647606909275055e-02
    z[6,5,4]  R2455     -1.7314553260803223e-01
    z[6,5,4]  R2456     4.5614200830459595e-01
    z[6,5,4]  R2457     -5.0045979022979736e-01
    z[6,5,4]  R2458     -1.6497291624546051e-01
    z[6,5,4]  R2459     -1.6790528595447540e-01
    z[6,5,4]  R2460     1.5428660809993744e-01
    z[6,5,4]  R2461     1.2442489713430405e-01
    z[6,5,4]  R2462     -1.4730221033096313e-01
    z[6,5,4]  R2463     2.1390931680798531e-02
    z[6,5,4]  R2464     -1.4637741446495056e-01
    z[6,5,4]  R2465     -3.1215709447860718e-01
    z[6,5,4]  R2466     -1.3079211115837097e-01
    z[6,5,4]  R2467     4.3404512107372284e-02
    z[6,5,4]  R2468     -0.203762024641037
    z[6,5,4]  R2469     -1.7515948414802551e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2326     -1
    z[6,5,5]  R2327     1
    z[6,5,5]  R2330     1.8363554030656815e-02
    z[6,5,5]  R2331     -9.5805518329143524e-02
    z[6,5,5]  R2332     1.2756167352199554e-01
    z[6,5,5]  R2333     -5.5215455591678619e-02
    z[6,5,5]  R2334     1.4253821969032288e-01
    z[6,5,5]  R2335     1.5330988168716431e-01
    z[6,5,5]  R2336     -1.7740002274513245e-01
    z[6,5,5]  R2337     6.8646006286144257e-02
    z[6,5,5]  R2338     9.1301478445529938e-02
    z[6,5,5]  R2339     1.0748646408319473e-01
    z[6,5,5]  R2340     -6.3528245687484741e-01
    z[6,5,5]  R2341     -5.5146205425262451e-01
    z[6,5,5]  R2342     -1.5791727602481842e-01
    z[6,5,5]  R2343     1.1527353525161743e-01
    z[6,5,5]  R2344     -1.3519582152366638e-01
    z[6,5,5]  R2345     -4.2881774902343750e-01
    z[6,5,5]  R2346     -6.6672730445861816e-01
    z[6,5,5]  R2347     -3.4675487875938416e-01
    z[6,5,5]  R2348     -3.6504715681076050e-01
    z[6,5,5]  R2349     -6.0960131883621216e-01
    z[6,5,5]  R2350     -1.7386928200721741e-01
    z[6,5,5]  R2351     6.6571027040481567e-02
    z[6,5,5]  R2352     8.7013505399227142e-02
    z[6,5,5]  R2353     2.4824562668800354e-01
    z[6,5,5]  R2354     3.5148376226425171e-01
    z[6,5,5]  R2355     2.2151772677898407e-01
    z[6,5,5]  R2356     1.1689832806587219e-01
    z[6,5,5]  R2357     2.1122368052601814e-02
    z[6,5,5]  R2358     4.5777830481529236e-01
    z[6,5,5]  R2359     1.2328056618571281e-02
    z[6,5,5]  R2360     -0.448505699634552
    z[6,5,5]  R2361     -3.6816036701202393e-01
    z[6,5,5]  R2362     2.8279694914817810e-01
    z[6,5,5]  R2363     -5.4161384701728821e-02
    z[6,5,5]  R2364     1.2324440479278564e-01
    z[6,5,5]  R2365     -1.0633645206689835e-01
    z[6,5,5]  R2366     2.5598341599106789e-02
    z[6,5,5]  R2367     -2.3073397576808929e-02
    z[6,5,5]  R2368     -1.0603081434965134e-01
    z[6,5,5]  R2369     -6.0287380218505859e-01
    z[6,5,5]  R2370     -2.1796286106109619e-01
    z[6,5,5]  R2371     -1.5515540540218353e-01
    z[6,5,5]  R2372     -3.2942584156990051e-01
    z[6,5,5]  R2373     -2.4291633069515228e-01
    z[6,5,5]  R2374     -0.422921746969223
    z[6,5,5]  R2375     -4.3859258294105530e-01
    z[6,5,5]  R2376     -1.4036697149276733e-01
    z[6,5,5]  R2377     -1.4414627850055695e-01
    z[6,5,5]  R2378     -2.9180753231048584e-01
    z[6,5,5]  R2379     0.622606098651886
    z[6,5,5]  R2380     2.4356535077095032e-01
    z[6,5,5]  R2381     -3.0759337544441223e-01
    z[6,5,5]  R2382     -2.7960723638534546e-01
    z[6,5,5]  R2383     -0.421384334564209
    z[6,5,5]  R2384     -5.0109249353408813e-01
    z[6,5,5]  R2385     -6.7544782161712646e-01
    z[6,5,5]  R2386     5.5559748411178589e-01
    z[6,5,5]  R2387     3.2968875765800476e-01
    z[6,5,5]  R2388     4.8926264047622681e-02
    z[6,5,5]  R2389     1.0916931927204132e-01
    z[6,5,5]  R2390     -2.5254514813423157e-01
    z[6,5,5]  R2391     -6.4476072788238525e-01
    z[6,5,5]  R2392     3.6030894517898560e-01
    z[6,5,5]  R2393     -4.0189573168754578e-01
    z[6,5,5]  R2394     -2.4131463468074799e-01
    z[6,5,5]  R2395     -2.2471027076244354e-01
    z[6,5,5]  R2396     0.314242959022522
    z[6,5,5]  R2397     -3.2006821036338806e-01
    z[6,5,5]  R2398     -3.0427744984626770e-01
    z[6,5,5]  R2399     1.2288712710142136e-01
    z[6,5,5]  R2400     9.0067885816097260e-02
    z[6,5,5]  R2401     -4.1855999827384949e-01
    z[6,5,5]  R2402     -5.1251932978630066e-02
    z[6,5,5]  R2403     -3.1081253290176392e-01
    z[6,5,5]  R2404     -4.3841204047203064e-01
    z[6,5,5]  R2405     -4.6696880459785461e-01
    z[6,5,5]  R2406     -7.8776758909225464e-01
    z[6,5,5]  R2407     -0.0409141406416893
    z[6,5,5]  R2408     -4.1150298714637756e-01
    z[6,5,5]  R2409     -4.4737223535776138e-02
    z[6,5,5]  R2410     -2.4522005021572113e-01
    z[6,5,5]  R2411     -4.9179011583328247e-01
    z[6,5,5]  R2412     -4.9940440058708191e-01
    z[6,5,5]  R2413     -7.4444037675857544e-01
    z[6,5,5]  R2414     1.4940799772739410e-01
    z[6,5,5]  R2415     2.4619838595390320e-01
    z[6,5,5]  R2416     -1.0064287483692169e-01
    z[6,5,5]  R2417     4.2561632394790649e-01
    z[6,5,5]  R2418     9.8149076104164124e-02
    z[6,5,5]  R2419     1.9988100230693817e-01
    z[6,5,5]  R2420     -2.0188757777214050e-01
    z[6,5,5]  R2421     1.4005610346794128e-01
    z[6,5,5]  R2422     -0.479707807302475
    z[6,5,5]  R2423     -8.0626225471496582e-01
    z[6,5,5]  R2424     -1.2126793712377548e-01
    z[6,5,5]  R2425     1.4181299507617950e-01
    z[6,5,5]  R2426     1.1308369040489197e-01
    z[6,5,5]  R2427     4.5485013723373413e-01
    z[6,5,5]  R2428     -2.9244298115372658e-02
    z[6,5,5]  R2429     1.4941900968551636e-01
    z[6,5,5]  R2430     -2.0874448120594025e-01
    z[6,5,5]  R2431     -7.2684699296951294e-01
    z[6,5,5]  R2432     -3.9484921097755432e-01
    z[6,5,5]  R2433     -1.2284660339355469e-01
    z[6,5,5]  R2434     1.7613308131694794e-01
    z[6,5,5]  R2435     -1.5199208259582520e-01
    z[6,5,5]  R2436     -0.0385298952460289
    z[6,5,5]  R2437     -3.2177552580833435e-02
    z[6,5,5]  R2438     -2.9607942700386047e-01
    z[6,5,5]  R2439     -3.6532118916511536e-01
    z[6,5,5]  R2440     -2.3808676004409790e-01
    z[6,5,5]  R2441     3.9120021462440491e-01
    z[6,5,5]  R2442     5.1130358129739761e-02
    z[6,5,5]  R2443     -5.8744996786117554e-01
    z[6,5,5]  R2444     -0.635794460773468
    z[6,5,5]  R2445     -3.6425021290779114e-01
    z[6,5,5]  R2446     -1.0354480147361755e-01
    z[6,5,5]  R2447     -1.9417276978492737e-01
    z[6,5,5]  R2448     -1.1577197909355164e-01
    z[6,5,5]  R2449     -5.5306226015090942e-01
    z[6,5,5]  R2450     4.1811850666999817e-01
    z[6,5,5]  R2451     4.9402302503585815e-01
    z[6,5,5]  R2452     0.091541588306427
    z[6,5,5]  R2453     -7.0513077080249786e-02
    z[6,5,5]  R2454     -5.9386390447616577e-01
    z[6,5,5]  R2455     -0.101526640355587
    z[6,5,5]  R2456     -4.2905488610267639e-01
    z[6,5,5]  R2457     2.7670687437057495e-01
    z[6,5,5]  R2458     2.5069864466786385e-02
    z[6,5,5]  R2459     -1.7510496079921722e-01
    z[6,5,5]  R2460     -4.3672375380992889e-02
    z[6,5,5]  R2461     1.1781078577041626e-01
    z[6,5,5]  R2462     1.1512167006731033e-01
    z[6,5,5]  R2463     -1.6194142401218414e-01
    z[6,5,5]  R2464     -2.0817534625530243e-01
    z[6,5,5]  R2465     -0.283462256193161
    z[6,5,5]  R2466     -7.9871386289596558e-02
    z[6,5,5]  R2467     -1.1518055945634842e-01
    z[6,5,5]  R2468     -0.13038270175457
    z[6,5,5]  R2469     2.5660738348960876e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2328     -1
    z[6,5,6]  R2329     1
    z[6,5,6]  R2330     -1.1770492047071457e-01
    z[6,5,6]  R2331     -4.4261552393436432e-03
    z[6,5,6]  R2332     -1.6064360737800598e-01
    z[6,5,6]  R2333     -1.6098898649215698e-01
    z[6,5,6]  R2334     -0.301470011472702
    z[6,5,6]  R2335     1.6815978288650513e-01
    z[6,5,6]  R2336     -1.2203180789947510e-01
    z[6,5,6]  R2337     1.4321976900100708e-01
    z[6,5,6]  R2338     -1.0164518840610981e-02
    z[6,5,6]  R2339     2.7247878909111023e-01
    z[6,5,6]  R2340     1.8773525953292847e-01
    z[6,5,6]  R2341     -2.3031197488307953e-01
    z[6,5,6]  R2342     3.7443738430738449e-02
    z[6,5,6]  R2343     -5.8671992272138596e-02
    z[6,5,6]  R2344     -4.4896829128265381e-01
    z[6,5,6]  R2345     0.0770488902926445
    z[6,5,6]  R2346     -2.5659623742103577e-01
    z[6,5,6]  R2347     -7.1774378418922424e-02
    z[6,5,6]  R2348     3.3430272340774536e-01
    z[6,5,6]  R2349     2.6974827051162720e-02
    z[6,5,6]  R2350     -6.8659879267215729e-02
    z[6,5,6]  R2351     8.4615841507911682e-02
    z[6,5,6]  R2352     9.7019389271736145e-02
    z[6,5,6]  R2353     3.8433033227920532e-01
    z[6,5,6]  R2354     -6.3249057531356812e-01
    z[6,5,6]  R2355     -2.1371269226074219e-01
    z[6,5,6]  R2356     -4.1133394837379456e-01
    z[6,5,6]  R2357     -0.0805663913488388
    z[6,5,6]  R2358     1.8261478841304779e-01
    z[6,5,6]  R2359     -2.9590731486678123e-02
    z[6,5,6]  R2360     -9.6845522522926331e-02
    z[6,5,6]  R2361     2.0080134272575378e-01
    z[6,5,6]  R2362     -2.0039488375186920e-01
    z[6,5,6]  R2363     3.6406585574150085e-01
    z[6,5,6]  R2364     -2.0754756033420563e-01
    z[6,5,6]  R2365     0.0768914446234703
    z[6,5,6]  R2366     1.9086304306983948e-01
    z[6,5,6]  R2367     2.0770902931690216e-01
    z[6,5,6]  R2368     4.1985239833593369e-02
    z[6,5,6]  R2369     -2.1316848695278168e-01
    z[6,5,6]  R2370     -7.0847973227500916e-02
    z[6,5,6]  R2371     1.4123211801052094e-01
    z[6,5,6]  R2372     -7.8969992697238922e-02
    z[6,5,6]  R2373     -1.1099644750356674e-01
    z[6,5,6]  R2374     -1.9904676079750061e-01
    z[6,5,6]  R2375     -2.7316769957542419e-01
    z[6,5,6]  R2376     3.7511962652206421e-01
    z[6,5,6]  R2377     -2.7071639895439148e-01
    z[6,5,6]  R2378     0.0816039890050888
    z[6,5,6]  R2379     1.1319984495639801e-01
    z[6,5,6]  R2380     2.7768164873123169e-01
    z[6,5,6]  R2381     6.2627747654914856e-02
    z[6,5,6]  R2382     -0.0424545481801033
    z[6,5,6]  R2383     -4.8246022313833237e-02
    z[6,5,6]  R2384     -1.7423997819423676e-01
    z[6,5,6]  R2385     -2.3064975440502167e-01
    z[6,5,6]  R2386     -2.5198507308959961e-01
    z[6,5,6]  R2387     -2.8632849454879761e-01
    z[6,5,6]  R2388     -1.7734473943710327e-01
    z[6,5,6]  R2389     0.0823395624756813
    z[6,5,6]  R2390     -2.5365290045738220e-01
    z[6,5,6]  R2391     5.3452465683221817e-02
    z[6,5,6]  R2392     1.7981614917516708e-02
    z[6,5,6]  R2393     8.4437653422355652e-02
    z[6,5,6]  R2394     1.7719270288944244e-01
    z[6,5,6]  R2395     -4.9363183975219727e-01
    z[6,5,6]  R2396     1.7795109748840332e-01
    z[6,5,6]  R2397     -6.2378573417663574e-01
    z[6,5,6]  R2398     -2.1367833018302917e-01
    z[6,5,6]  R2399     1.7445491254329681e-01
    z[6,5,6]  R2400     1.5673954784870148e-01
    z[6,5,6]  R2401     -0.282549113035202
    z[6,5,6]  R2402     -9.0264402329921722e-02
    z[6,5,6]  R2403     2.8157643973827362e-03
    z[6,5,6]  R2404     -6.1274436302483082e-03
    z[6,5,6]  R2405     2.0600537955760956e-01
    z[6,5,6]  R2406     1.3947731256484985e-01
    z[6,5,6]  R2407     1.3983491063117981e-01
    z[6,5,6]  R2408     -2.2028565406799316e-01
    z[6,5,6]  R2409     1.3029728829860687e-01
    z[6,5,6]  R2410     -2.9339674860239029e-02
    z[6,5,6]  R2411     -1.4245378971099854e-01
    z[6,5,6]  R2412     -0.257985919713974
    z[6,5,6]  R2413     -2.4304588139057159e-01
    z[6,5,6]  R2414     -5.2570408582687378e-01
    z[6,5,6]  R2415     3.2696448266506195e-02
    z[6,5,6]  R2416     -3.7743654102087021e-02
    z[6,5,6]  R2417     -0.148038849234581
    z[6,5,6]  R2418     -2.4738231301307678e-01
    z[6,5,6]  R2419     -2.0432794094085693e-01
    z[6,5,6]  R2420     -1.5077529847621918e-01
    z[6,5,6]  R2421     -1.4350248873233795e-01
    z[6,5,6]  R2422     1.1306065320968628e-01
    z[6,5,6]  R2423     1.0979101061820984e-01
    z[6,5,6]  R2424     3.0902945995330811e-01
    z[6,5,6]  R2425     0.0984988585114479
    z[6,5,6]  R2426     -3.4991574287414551e-01
    z[6,5,6]  R2427     -1.4413505792617798e-01
    z[6,5,6]  R2428     2.2152608260512352e-02
    z[6,5,6]  R2429     -7.0057488977909088e-02
    z[6,5,6]  R2430     1.2082371860742569e-01
    z[6,5,6]  R2431     7.4731156229972839e-02
    z[6,5,6]  R2432     0.2565937936306
    z[6,5,6]  R2433     2.3028762638568878e-01
    z[6,5,6]  R2434     -2.3457955569028854e-02
    z[6,5,6]  R2435     1.1988984793424606e-01
    z[6,5,6]  R2436     1.9500355422496796e-01
    z[6,5,6]  R2437     5.0898820161819458e-01
    z[6,5,6]  R2438     4.6658405661582947e-01
    z[6,5,6]  R2439     1.8439665436744690e-01
    z[6,5,6]  R2440     1.6800431907176971e-01
    z[6,5,6]  R2441     -4.8735892772674561e-01
    z[6,5,6]  R2442     -4.0737181901931763e-01
    z[6,5,6]  R2443     1.0580208152532578e-02
    z[6,5,6]  R2444     2.9227675870060921e-02
    z[6,5,6]  R2445     3.3393511176109314e-01
    z[6,5,6]  R2446     1.6795925796031952e-02
    z[6,5,6]  R2447     5.1053303480148315e-01
    z[6,5,6]  R2448     5.2124512195587158e-01
    z[6,5,6]  R2449     -4.1547316312789917e-01
    z[6,5,6]  R2450     -5.4954618215560913e-02
    z[6,5,6]  R2451     0.691472053527832
    z[6,5,6]  R2452     -0.139152392745018
    z[6,5,6]  R2453     -3.5400897264480591e-01
    z[6,5,6]  R2454     -1.1064770072698593e-01
    z[6,5,6]  R2455     1.7837829887866974e-01
    z[6,5,6]  R2456     1.2031418085098267e-01
    z[6,5,6]  R2457     1.7815624177455902e-01
    z[6,5,6]  R2458     3.4017577767372131e-01
    z[6,5,6]  R2459     3.4392920136451721e-01
    z[6,5,6]  R2460     8.1533983349800110e-02
    z[6,5,6]  R2461     -2.6450985670089722e-01
    z[6,5,6]  R2462     3.0140694230794907e-02
    z[6,5,6]  R2463     -3.3923369646072388e-01
    z[6,5,6]  R2464     1.1259863525629044e-01
    z[6,5,6]  R2465     1.2439736723899841e-01
    z[6,5,6]  R2466     -1.8044370412826538e-01
    z[6,5,6]  R2467     0.0785333588719368
    z[6,5,6]  R2468     1.3021877408027649e-01
    z[6,5,6]  R2469     2.2515854239463806e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2470     -1
    z[6,7,0]  R2471     1
    z[6,7,0]  R2484     -8.7384122610092163e-01
    z[6,7,0]  R2485     -8.8748365640640259e-01
    z[6,7,0]  R2486     -9.4941294193267822e-01
    z[6,7,0]  R2487     -8.5786253213882446e-01
    z[6,7,0]  R2488     -9.1623759269714355e-01
    z[6,7,0]  R2489     -7.2450643777847290e-01
    z[6,7,0]  R2490     -9.3621307611465454e-01
    z[6,7,0]  R2491     -0.96856290102005
    z[6,7,0]  R2492     -8.3268773555755615e-01
    z[6,7,0]  R2493     -8.0606764554977417e-01
    z[6,7,0]  R2494     2.0103774964809418e-01
    z[6,7,0]  R2495     2.1778398752212524e-01
    z[6,7,0]  R2496     1.9404245913028717e-01
    z[6,7,0]  R2497     -0.0822681114077568
    z[6,7,0]  R2498     -2.5601822417229414e-03
    z[6,7,0]  R2499     2.5686609745025635e-01
    z[6,7,0]  R2500     2.3033238947391510e-01
    z[6,7,0]  R2501     3.1332874298095703e-01
    z[6,7,0]  R2502     -1.5054904855787754e-02
    z[6,7,0]  R2503     1.5797884762287140e-01
    z[6,7,0]  R2504     8.2420194149017334e-01
    z[6,7,0]  R2505     4.1432134807109833e-02
    z[6,7,0]  R2506     0.51854008436203
    z[6,7,0]  R2507     7.2541677951812744e-01
    z[6,7,0]  R2508     5.0932067632675171e-01
    z[6,7,0]  R2509     5.2500754594802856e-01
    z[6,7,0]  R2510     3.7646532058715820e-01
    z[6,7,0]  R2511     7.7187612652778625e-02
    z[6,7,0]  R2512     5.5519080162048340e-01
    z[6,7,0]  R2513     1.7107808589935303e-01
    z[6,7,0]  R2514     5.8747440576553345e-01
    z[6,7,0]  R2515     0.787808895111084
    z[6,7,0]  R2516     -1.2902888655662537e-01
    z[6,7,0]  R2517     7.3995554447174072e-01
    z[6,7,0]  R2518     1.4056351780891418e-01
    z[6,7,0]  R2519     6.9226735830307007e-01
    z[6,7,0]  R2520     2.5577588006854057e-02
    z[6,7,0]  R2521     8.1297689676284790e-01
    z[6,7,0]  R2522     5.6801873445510864e-01
    z[6,7,0]  R2523     -2.2160109877586365e-01
    z[6,7,0]  R2524     -1.0260418057441711e-03
    z[6,7,0]  R2525     3.2716092467308044e-01
    z[6,7,0]  R2526     4.2324984073638916e-01
    z[6,7,0]  R2527     4.8220828175544739e-02
    z[6,7,0]  R2528     0.618370532989502
    z[6,7,0]  R2529     5.8190727233886719e-01
    z[6,7,0]  R2530     3.2456271350383759e-02
    z[6,7,0]  R2531     -2.7239865064620972e-01
    z[6,7,0]  R2532     -3.8483291864395142e-01
    z[6,7,0]  R2533     7.6029294729232788e-01
    z[6,7,0]  R2534     -7.7624571323394775e-01
    z[6,7,0]  R2535     7.8828144073486328e-01
    z[6,7,0]  R2536     6.0670781135559082e-01
    z[6,7,0]  R2537     1.2974782288074493e-01
    z[6,7,0]  R2538     4.8424193263053894e-01
    z[6,7,0]  R2539     5.4049581289291382e-01
    z[6,7,0]  R2540     5.2734637260437012e-01
    z[6,7,0]  R2541     5.1648199558258057e-01
    z[6,7,0]  R2542     -3.5389885306358337e-01
    z[6,7,0]  R2543     0.0541507862508297
    z[6,7,0]  R2544     4.1410472989082336e-01
    z[6,7,0]  R2545     1.3840852305293083e-02
    z[6,7,0]  R2546     8.0886858701705933e-01
    z[6,7,0]  R2547     -4.1802600026130676e-01
    z[6,7,0]  R2548     -4.2783138155937195e-01
    z[6,7,0]  R2549     4.6446800231933594e-01
    z[6,7,0]  R2550     7.1531379222869873e-01
    z[6,7,0]  R2551     5.2551430463790894e-01
    z[6,7,0]  R2552     -3.5186198353767395e-01
    z[6,7,0]  R2553     7.0942497253417969e-01
    z[6,7,0]  R2554     8.9145672321319580e-01
    z[6,7,0]  R2555     4.3067368865013123e-01
    z[6,7,0]  R2556     -2.3954921960830688e-01
    z[6,7,0]  R2557     -5.8236384391784668e-01
    z[6,7,0]  R2558     6.2779515981674194e-01
    z[6,7,0]  R2559     5.2663028240203857e-01
    z[6,7,0]  R2560     4.8508965969085693e-01
    z[6,7,0]  R2561     8.4526282548904419e-01
    z[6,7,0]  R2562     -4.7784465551376343e-01
    z[6,7,0]  R2563     1.4369764365255833e-02
    z[6,7,0]  R2564     -7.4734479188919067e-01
    z[6,7,0]  R2565     6.1633431911468506e-01
    z[6,7,0]  R2566     0.401021271944046
    z[6,7,0]  R2567     4.8296386003494263e-01
    z[6,7,0]  R2568     0.680448055267334
    z[6,7,0]  R2569     -3.7621328234672546e-01
    z[6,7,0]  R2570     1.2038894742727280e-01
    z[6,7,0]  R2571     -1.7895002383738756e-04
    z[6,7,0]  R2572     -8.2989625632762909e-02
    z[6,7,0]  R2573     -2.8991684317588806e-02
    z[6,7,0]  R2574     -0.743486762046814
    z[6,7,0]  R2575     7.0977705717086792e-01
    z[6,7,0]  R2576     5.7753592729568481e-01
    z[6,7,0]  R2577     4.3028134107589722e-01
    z[6,7,0]  R2578     1.7088226974010468e-01
    z[6,7,0]  R2579     6.7804497666656971e-03
    z[6,7,0]  R2580     -6.1569139361381531e-02
    z[6,7,0]  R2581     3.5309992730617523e-02
    z[6,7,0]  R2582     -1.1695101112127304e-01
    z[6,7,0]  R2583     -4.5996751636266708e-02
    z[6,7,0]  R2584     7.2832182049751282e-03
    z[6,7,0]  R2585     6.1436778306961060e-01
    z[6,7,0]  R2586     5.5816221237182617e-01
    z[6,7,0]  R2587     -4.5648229122161865e-01
    z[6,7,0]  R2588     -3.2614029943943024e-02
    z[6,7,0]  R2589     -2.6928958296775818e-01
    z[6,7,0]  R2590     -1.3647805154323578e-01
    z[6,7,0]  R2591     2.3611165583133698e-02
    z[6,7,0]  R2592     -6.7060112953186035e-02
    z[6,7,0]  R2593     -0.0773346871137619
    z[6,7,0]  R2594     -9.5497183501720428e-02
    z[6,7,0]  R2595     3.0647508800029755e-02
    z[6,7,0]  R2596     -6.5438938140869141e-01
    z[6,7,0]  R2597     1.0101261734962463e-01
    z[6,7,0]  R2598     3.2455902546644211e-02
    z[6,7,0]  R2599     -2.4471038579940796e-01
    z[6,7,0]  R2600     -4.3175509572029114e-01
    z[6,7,0]  R2601     -1.8281176686286926e-01
    z[6,7,0]  R2602     -1.3119821250438690e-01
    z[6,7,0]  R2603     -3.5663988441228867e-02
    z[6,7,0]  R2604     3.1553596258163452e-01
    z[6,7,0]  R2605     4.3720972537994385e-01
    z[6,7,0]  R2606     3.4140643477439880e-01
    z[6,7,0]  R2607     4.8278063535690308e-01
    z[6,7,0]  R2608     5.6979817152023315e-01
    z[6,7,0]  R2609     -6.2885993719100952e-01
    z[6,7,0]  R2610     -7.5865501165390015e-01
    z[6,7,0]  R2611     -5.0260728597640991e-01
    z[6,7,0]  R2612     8.9063942432403564e-02
    z[6,7,0]  R2613     6.8356573581695557e-01
    z[6,7,0]  R2614     1.5766522288322449e-01
    z[6,7,0]  R2615     6.4233458042144775e-01
    z[6,7,0]  R2616     4.1580140590667725e-01
    z[6,7,0]  R2617     5.6499028205871582e-01
    z[6,7,0]  R2618     0.414422869682312
    z[6,7,0]  R2619     1.7025206238031387e-02
    z[6,7,0]  R2620     4.7953811287879944e-01
    z[6,7,0]  R2621     4.0981176495552063e-01
    z[6,7,0]  R2622     -2.5155130028724670e-01
    z[6,7,0]  R2623     -1.0096784681081772e-01
    z[6,7,0]  R2624     -1.2372843176126480e-01
    z[6,7,0]  R2625     -7.0284180343151093e-02
    z[6,7,0]  R2626     4.9607205390930176e-01
    z[6,7,0]  R2627     1.1852400004863739e-01
    z[6,7,0]  R2628     -1.3189294934272766e-01
    z[6,7,0]  R2629     2.2762393951416016e-01
    z[6,7,0]  R2630     1.8111190199851990e-01
    z[6,7,0]  R2631     -8.5589081048965454e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2472     -1
    z[6,7,1]  R2473     1
    z[6,7,1]  R2484     -3.8983193039894104e-01
    z[6,7,1]  R2485     -3.6499857902526855e-01
    z[6,7,1]  R2486     -2.1544776856899261e-02
    z[6,7,1]  R2487     -6.8940952420234680e-02
    z[6,7,1]  R2488     -1.2151963263750076e-01
    z[6,7,1]  R2489     -5.3895201534032822e-02
    z[6,7,1]  R2490     3.3995623234659433e-03
    z[6,7,1]  R2491     -6.3452741596847773e-04
    z[6,7,1]  R2492     2.7241089940071106e-01
    z[6,7,1]  R2493     -2.8118479251861572e-01
    z[6,7,1]  R2494     -5.0241601467132568e-01
    z[6,7,1]  R2495     -1.9956082105636597e-01
    z[6,7,1]  R2496     -5.9879440069198608e-01
    z[6,7,1]  R2497     -7.0977377891540527e-01
    z[6,7,1]  R2498     -4.8572760820388794e-01
    z[6,7,1]  R2499     -5.2118331193923950e-01
    z[6,7,1]  R2500     -6.8679213523864746e-02
    z[6,7,1]  R2501     -5.8934754133224487e-01
    z[6,7,1]  R2502     -4.0870368480682373e-01
    z[6,7,1]  R2503     -5.2850800752639771e-01
    z[6,7,1]  R2504     -3.1171565875411034e-02
    z[6,7,1]  R2505     -9.5037811994552612e-01
    z[6,7,1]  R2506     3.0611717700958252e-01
    z[6,7,1]  R2507     1.5424132347106934e-01
    z[6,7,1]  R2508     -9.2823922634124756e-02
    z[6,7,1]  R2509     3.5708022117614746e-01
    z[6,7,1]  R2510     -5.2102571725845337e-01
    z[6,7,1]  R2511     6.6686397790908813e-01
    z[6,7,1]  R2512     -1.4312581717967987e-01
    z[6,7,1]  R2513     6.0229659080505371e-01
    z[6,7,1]  R2514     -3.4938564896583557e-01
    z[6,7,1]  R2515     1.5225054323673248e-01
    z[6,7,1]  R2516     -7.8362977504730225e-01
    z[6,7,1]  R2517     0.045985147356987
    z[6,7,1]  R2518     -8.9270532131195068e-01
    z[6,7,1]  R2519     1.0074172914028168e-01
    z[6,7,1]  R2520     -6.3061875104904175e-01
    z[6,7,1]  R2521     -3.0362397432327271e-01
    z[6,7,1]  R2522     1.2596595287322998e-01
    z[6,7,1]  R2523     -5.5027091503143311e-01
    z[6,7,1]  R2524     -7.6516550779342651e-01
    z[6,7,1]  R2525     -8.8505178689956665e-01
    z[6,7,1]  R2526     -5.2559173107147217e-01
    z[6,7,1]  R2527     -0.89644455909729
    z[6,7,1]  R2528     2.1496775746345520e-01
    z[6,7,1]  R2529     -2.3313325643539429e-01
    z[6,7,1]  R2530     -7.7686858177185059e-01
    z[6,7,1]  R2531     -5.5272829532623291e-01
    z[6,7,1]  R2532     -1.3243253529071808e-01
    z[6,7,1]  R2533     -3.7105970084667206e-02
    z[6,7,1]  R2534     -2.6720070838928223e-01
    z[6,7,1]  R2535     -3.0520877242088318e-01
    z[6,7,1]  R2536     -4.4281157851219177e-01
    z[6,7,1]  R2537     -4.7522720694541931e-01
    z[6,7,1]  R2538     -1.7094098031520844e-01
    z[6,7,1]  R2539     -1.9637905061244965e-01
    z[6,7,1]  R2540     -4.5808512717485428e-02
    z[6,7,1]  R2541     2.2161212563514709e-01
    z[6,7,1]  R2542     7.5454115867614746e-01
    z[6,7,1]  R2543     8.6229842901229858e-01
    z[6,7,1]  R2544     -2.6137259602546692e-01
    z[6,7,1]  R2545     -6.7997843027114868e-01
    z[6,7,1]  R2546     1.7777520418167114e-01
    z[6,7,1]  R2547     -6.4122051000595093e-01
    z[6,7,1]  R2548     -0.055446557700634
    z[6,7,1]  R2549     -2.7222353219985962e-01
    z[6,7,1]  R2550     -2.6235067844390869e-01
    z[6,7,1]  R2551     -1.5870186686515808e-01
    z[6,7,1]  R2552     1.6907547414302826e-01
    z[6,7,1]  R2553     2.0996022969484329e-02
    z[6,7,1]  R2554     -1.4200265705585480e-01
    z[6,7,1]  R2555     -3.0012896656990051e-01
    z[6,7,1]  R2556     -7.6789957284927368e-01
    z[6,7,1]  R2557     -5.6674383580684662e-02
    z[6,7,1]  R2558     -1.9198960065841675e-01
    z[6,7,1]  R2559     -1.4512595720589161e-02
    z[6,7,1]  R2560     3.6846555769443512e-02
    z[6,7,1]  R2561     2.8690424561500549e-01
    z[6,7,1]  R2562     4.8175626993179321e-01
    z[6,7,1]  R2563     7.9874765872955322e-01
    z[6,7,1]  R2564     -1.4394551515579224e-02
    z[6,7,1]  R2565     -3.0781856179237366e-01
    z[6,7,1]  R2566     -2.7524015307426453e-01
    z[6,7,1]  R2567     -2.0112356543540955e-01
    z[6,7,1]  R2568     1.0570946335792542e-01
    z[6,7,1]  R2569     -1.8369263410568237e-01
    z[6,7,1]  R2570     5.2311939001083374e-01
    z[6,7,1]  R2571     7.2564291954040527e-01
    z[6,7,1]  R2572     7.3291534185409546e-01
    z[6,7,1]  R2573     8.1506699323654175e-01
    z[6,7,1]  R2574     9.3010291457176208e-02
    z[6,7,1]  R2575     -1.8123178184032440e-01
    z[6,7,1]  R2576     -0.145138680934906
    z[6,7,1]  R2577     -2.4333159625530243e-01
    z[6,7,1]  R2578     -4.8579236865043640e-01
    z[6,7,1]  R2579     6.5936404466629028e-01
    z[6,7,1]  R2580     6.2111669778823853e-01
    z[6,7,1]  R2581     0.584827721118927
    z[6,7,1]  R2582     8.8545787334442139e-01
    z[6,7,1]  R2583     8.1723350286483765e-01
    z[6,7,1]  R2584     -4.9319869279861450e-01
    z[6,7,1]  R2585     -1.6294093430042267e-01
    z[6,7,1]  R2586     -5.0169759988784790e-01
    z[6,7,1]  R2587     -3.1170082092285156e-01
    z[6,7,1]  R2588     9.1450905799865723e-01
    z[6,7,1]  R2589     8.0454438924789429e-01
    z[6,7,1]  R2590     0.808972954750061
    z[6,7,1]  R2591     6.4437693357467651e-01
    z[6,7,1]  R2592     6.1878538131713867e-01
    z[6,7,1]  R2593     0.753345787525177
    z[6,7,1]  R2594     -3.4604340791702271e-01
    z[6,7,1]  R2595     -3.2077878713607788e-01
    z[6,7,1]  R2596     -4.2159634828567505e-01
    z[6,7,1]  R2597     -3.9484176039695740e-01
    z[6,7,1]  R2598     -3.1864890456199646e-01
    z[6,7,1]  R2599     -2.7003687620162964e-01
    z[6,7,1]  R2600     -5.0405979156494141e-01
    z[6,7,1]  R2601     7.4345552921295166e-01
    z[6,7,1]  R2602     6.9006556272506714e-01
    z[6,7,1]  R2603     3.8838860392570496e-01
    z[6,7,1]  R2604     4.5317673683166504e-01
    z[6,7,1]  R2605     3.0732971429824829e-01
    z[6,7,1]  R2606     5.2750808000564575e-01
    z[6,7,1]  R2607     6.0210186243057251e-01
    z[6,7,1]  R2608     4.3000218272209167e-01
    z[6,7,1]  R2609     3.1987950205802917e-01
    z[6,7,1]  R2610     3.3580586314201355e-01
    z[6,7,1]  R2611     2.4285274744033813e-01
    z[6,7,1]  R2612     -4.6651086211204529e-01
    z[6,7,1]  R2613     -0.539271891117096
    z[6,7,1]  R2614     -1.4057770371437073e-01
    z[6,7,1]  R2615     0.567960798740387
    z[6,7,1]  R2616     -0.228984072804451
    z[6,7,1]  R2617     7.9121059179306030e-01
    z[6,7,1]  R2618     5.5430847406387329e-01
    z[6,7,1]  R2619     5.5086892843246460e-01
    z[6,7,1]  R2620     6.2954002618789673e-01
    z[6,7,1]  R2621     5.6699329614639282e-01
    z[6,7,1]  R2622     2.1715676784515381e-01
    z[6,7,1]  R2623     3.0918952822685242e-01
    z[6,7,1]  R2624     -4.7771230340003967e-01
    z[6,7,1]  R2625     6.6895473003387451e-01
    z[6,7,1]  R2626     7.5023949146270752e-01
    z[6,7,1]  R2627     8.2526785135269165e-01
    z[6,7,1]  R2628     1.5270633995532990e-01
    z[6,7,1]  R2629     8.2591497898101807e-01
    z[6,7,1]  R2630     3.5667210817337036e-01
    z[6,7,1]  R2631     1.1318787187337875e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2474     -1
    z[6,7,2]  R2475     1
    z[6,7,2]  R2484     -1.7520034313201904e-01
    z[6,7,2]  R2485     -1.1685901880264282e-01
    z[6,7,2]  R2486     -1.6333484649658203e-01
    z[6,7,2]  R2487     -2.6785880327224731e-01
    z[6,7,2]  R2488     -1.8257641792297363e-01
    z[6,7,2]  R2489     -5.3789663314819336e-01
    z[6,7,2]  R2490     -1.7760933935642242e-01
    z[6,7,2]  R2491     -1.7945638298988342e-01
    z[6,7,2]  R2492     -3.8195076584815979e-01
    z[6,7,2]  R2493     -0.0339924618601799
    z[6,7,2]  R2494     2.8260305523872375e-01
    z[6,7,2]  R2495     7.1075963973999023e-01
    z[6,7,2]  R2496     6.8378818035125732e-01
    z[6,7,2]  R2497     5.4878199100494385e-01
    z[6,7,2]  R2498     4.9439480900764465e-01
    z[6,7,2]  R2499     6.2343740463256836e-01
    z[6,7,2]  R2500     5.0190275907516479e-01
    z[6,7,2]  R2501     4.8393711447715759e-01
    z[6,7,2]  R2502     3.8058194518089294e-01
    z[6,7,2]  R2503     4.3565174937248230e-01
    z[6,7,2]  R2504     3.2944139838218689e-01
    z[6,7,2]  R2505     -1.5970049798488617e-01
    z[6,7,2]  R2506     6.8351435661315918e-01
    z[6,7,2]  R2507     2.4656991660594940e-01
    z[6,7,2]  R2508     1.1712289601564407e-01
    z[6,7,2]  R2509     6.8361848592758179e-01
    z[6,7,2]  R2510     -1.3215051591396332e-01
    z[6,7,2]  R2511     -6.0098522901535034e-01
    z[6,7,2]  R2512     4.9145266413688660e-01
    z[6,7,2]  R2513     -0.706415057182312
    z[6,7,2]  R2514     3.1549575924873352e-01
    z[6,7,2]  R2515     3.8917210698127747e-01
    z[6,7,2]  R2516     4.1174092888832092e-01
    z[6,7,2]  R2517     3.1450986862182617e-01
    z[6,7,2]  R2518     4.2288318276405334e-02
    z[6,7,2]  R2519     6.3316076993942261e-01
    z[6,7,2]  R2520     2.1973705291748047e-01
    z[6,7,2]  R2521     -5.7728279381990433e-02
    z[6,7,2]  R2522     7.7076196670532227e-01
    z[6,7,2]  R2523     2.6455268263816833e-01
    z[6,7,2]  R2524     4.2389449477195740e-01
    z[6,7,2]  R2525     2.2439652681350708e-01
    z[6,7,2]  R2526     6.4922392368316650e-01
    z[6,7,2]  R2527     1.6333243250846863e-01
    z[6,7,2]  R2528     5.4032075405120850e-01
    z[6,7,2]  R2529     -1.8255543708801270e-01
    z[6,7,2]  R2530     3.0196553096175194e-02
    z[6,7,2]  R2531     0.215520977973938
    z[6,7,2]  R2532     -6.1001914739608765e-01
    z[6,7,2]  R2533     8.8725559413433075e-02
    z[6,7,2]  R2534     -2.3672574758529663e-01
    z[6,7,2]  R2535     2.5989213585853577e-01
    z[6,7,2]  R2536     1.6411387920379639e-01
    z[6,7,2]  R2537     2.8355222940444946e-01
    z[6,7,2]  R2538     9.0234234929084778e-02
    z[6,7,2]  R2539     -1.9573102891445160e-01
    z[6,7,2]  R2540     4.8574164509773254e-01
    z[6,7,2]  R2541     6.5591341257095337e-01
    z[6,7,2]  R2542     -3.4801873564720154e-01
    z[6,7,2]  R2543     -4.6952879428863525e-01
    z[6,7,2]  R2544     6.7564022541046143e-01
    z[6,7,2]  R2545     1.2817643582820892e-03
    z[6,7,2]  R2546     4.2216774821281433e-01
    z[6,7,2]  R2547     1.5791609883308411e-01
    z[6,7,2]  R2548     -7.6735556125640869e-01
    z[6,7,2]  R2549     2.5689122080802917e-01
    z[6,7,2]  R2550     0.395819753408432
    z[6,7,2]  R2551     2.0394693315029144e-01
    z[6,7,2]  R2552     -6.5956008434295654e-01
    z[6,7,2]  R2553     0.0963897705078125
    z[6,7,2]  R2554     2.1616187691688538e-01
    z[6,7,2]  R2555     3.8360023498535156e-01
    z[6,7,2]  R2556     0.522737979888916
    z[6,7,2]  R2557     -5.8665275573730469e-01
    z[6,7,2]  R2558     0.257693350315094
    z[6,7,2]  R2559     5.1851803064346313e-01
    z[6,7,2]  R2560     3.2036128640174866e-01
    z[6,7,2]  R2561     3.1420376896858215e-01
    z[6,7,2]  R2562     -4.5502316951751709e-01
    z[6,7,2]  R2563     -4.5573037862777710e-01
    z[6,7,2]  R2564     -6.1263483762741089e-01
    z[6,7,2]  R2565     3.7518495321273804e-01
    z[6,7,2]  R2566     4.6717628836631775e-01
    z[6,7,2]  R2567     2.9142412543296814e-01
    z[6,7,2]  R2568     3.8473892211914062e-01
    z[6,7,2]  R2569     4.9168238043785095e-01
    z[6,7,2]  R2570     -8.2693254947662354e-01
    z[6,7,2]  R2571     -3.9073020219802856e-01
    z[6,7,2]  R2572     -0.315792053937912
    z[6,7,2]  R2573     -1.5693803131580353e-01
    z[6,7,2]  R2574     -0.431908518075943
    z[6,7,2]  R2575     4.6711099147796631e-01
    z[6,7,2]  R2576     5.1746422052383423e-01
    z[6,7,2]  R2577     1.6701912879943848e-01
    z[6,7,2]  R2578     2.2287330031394958e-01
    z[6,7,2]  R2579     -6.4267307519912720e-01
    z[6,7,2]  R2580     -5.4743212461471558e-01
    z[6,7,2]  R2581     -5.9905093908309937e-01
    z[6,7,2]  R2582     3.9783951640129089e-01
    z[6,7,2]  R2583     5.3042483329772949e-01
    z[6,7,2]  R2584     6.0604417324066162e-01
    z[6,7,2]  R2585     1.0132411122322083e-01
    z[6,7,2]  R2586     2.7886566519737244e-01
    z[6,7,2]  R2587     -4.7770851850509644e-01
    z[6,7,2]  R2588     -3.4008646011352539e-01
    z[6,7,2]  R2589     3.9407119154930115e-01
    z[6,7,2]  R2590     4.1896224021911621e-01
    z[6,7,2]  R2591     5.4252862930297852e-01
    z[6,7,2]  R2592     5.3949481248855591e-01
    z[6,7,2]  R2593     3.8305473327636719e-01
    z[6,7,2]  R2594     -2.1354725956916809e-01
    z[6,7,2]  R2595     3.7155240774154663e-01
    z[6,7,2]  R2596     0.336379736661911
    z[6,7,2]  R2597     1.4622454345226288e-01
    z[6,7,2]  R2598     2.6254877448081970e-01
    z[6,7,2]  R2599     5.0766289234161377e-01
    z[6,7,2]  R2600     2.3617684841156006e-01
    z[6,7,2]  R2601     5.2378600835800171e-01
    z[6,7,2]  R2602     5.5961215496063232e-01
    z[6,7,2]  R2603     5.8387947082519531e-01
    z[6,7,2]  R2604     1.4334578812122345e-01
    z[6,7,2]  R2605     9.1534264385700226e-02
    z[6,7,2]  R2606     2.4795642122626305e-02
    z[6,7,2]  R2607     -1.6446989774703979e-01
    z[6,7,2]  R2608     -3.1073245406150818e-01
    z[6,7,2]  R2609     -6.8830925226211548e-01
    z[6,7,2]  R2610     -3.5474994778633118e-01
    z[6,7,2]  R2611     -6.5949332714080811e-01
    z[6,7,2]  R2612     6.3296836614608765e-01
    z[6,7,2]  R2613     -5.7502470910549164e-02
    z[6,7,2]  R2614     -1.7588475719094276e-02
    z[6,7,2]  R2615     -1.5407618880271912e-01
    z[6,7,2]  R2616     -3.3088666200637817e-01
    z[6,7,2]  R2617     4.6474966220557690e-03
    z[6,7,2]  R2618     1.6201306879520416e-01
    z[6,7,2]  R2619     0.319915235042572
    z[6,7,2]  R2620     -2.0948900282382965e-01
    z[6,7,2]  R2621     -1.2064448557794094e-02
    z[6,7,2]  R2622     6.1238389462232590e-02
    z[6,7,2]  R2623     6.6069457679986954e-03
    z[6,7,2]  R2624     -1.0454404167830944e-02
    z[6,7,2]  R2625     4.7001782059669495e-01
    z[6,7,2]  R2626     4.0012022852897644e-01
    z[6,7,2]  R2627     2.1673339605331421e-01
    z[6,7,2]  R2628     3.2546713948249817e-01
    z[6,7,2]  R2629     3.2212135195732117e-01
    z[6,7,2]  R2630     2.7594748139381409e-01
    z[6,7,2]  R2631     -4.1854715347290039e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2476     -1
    z[6,7,3]  R2477     1
    z[6,7,3]  R2484     1.9722686707973480e-01
    z[6,7,3]  R2485     -1.7805849015712738e-01
    z[6,7,3]  R2486     -1.3938149809837341e-01
    z[6,7,3]  R2487     3.1448623538017273e-01
    z[6,7,3]  R2488     0.00422905758023262
    z[6,7,3]  R2489     3.0133891850709915e-02
    z[6,7,3]  R2490     -5.1916502416133881e-02
    z[6,7,3]  R2491     -4.8395209014415741e-02
    z[6,7,3]  R2492     -7.3296025395393372e-02
    z[6,7,3]  R2493     2.6381894946098328e-01
    z[6,7,3]  R2494     -3.9144456386566162e-01
    z[6,7,3]  R2495     2.1493844687938690e-01
    z[6,7,3]  R2496     -3.2905817031860352e-02
    z[6,7,3]  R2497     1.3282246887683868e-01
    z[6,7,3]  R2498     -4.2959639430046082e-01
    z[6,7,3]  R2499     -2.6216539740562439e-01
    z[6,7,3]  R2500     -1.5089030377566814e-02
    z[6,7,3]  R2501     2.9635429382324219e-01
    z[6,7,3]  R2502     -3.1604444980621338e-01
    z[6,7,3]  R2503     2.2651587426662445e-01
    z[6,7,3]  R2504     1.9076961278915405e-01
    z[6,7,3]  R2505     -1.6248348355293274e-01
    z[6,7,3]  R2506     -3.2762053608894348e-01
    z[6,7,3]  R2507     -9.8815739154815674e-02
    z[6,7,3]  R2508     4.4113656878471375e-01
    z[6,7,3]  R2509     1.8524500727653503e-01
    z[6,7,3]  R2510     2.6893270015716553e-01
    z[6,7,3]  R2511     -8.2504920661449432e-02
    z[6,7,3]  R2512     -3.0172142386436462e-01
    z[6,7,3]  R2513     2.6870843768119812e-01
    z[6,7,3]  R2514     2.9335431754589081e-02
    z[6,7,3]  R2515     1.2446004152297974e-01
    z[6,7,3]  R2516     -0.279773473739624
    z[6,7,3]  R2517     1.1687626689672470e-01
    z[6,7,3]  R2518     1.3141964375972748e-01
    z[6,7,3]  R2519     -3.0197307467460632e-01
    z[6,7,3]  R2520     -0.718078076839447
    z[6,7,3]  R2521     -2.2317622601985931e-01
    z[6,7,3]  R2522     -7.3442630469799042e-02
    z[6,7,3]  R2523     -1.9902646541595459e-01
    z[6,7,3]  R2524     -3.9294418692588806e-01
    z[6,7,3]  R2525     -1.0631754249334335e-01
    z[6,7,3]  R2526     8.6140096187591553e-02
    z[6,7,3]  R2527     -0.0592268705368042
    z[6,7,3]  R2528     1.1346279084682465e-01
    z[6,7,3]  R2529     5.5354988574981689e-01
    z[6,7,3]  R2530     -2.1806603670120239e-01
    z[6,7,3]  R2531     1.3416700065135956e-01
    z[6,7,3]  R2532     -4.5715585350990295e-01
    z[6,7,3]  R2533     -2.9148977249860764e-02
    z[6,7,3]  R2534     -2.1368084847927094e-01
    z[6,7,3]  R2535     -1.3163023628294468e-02
    z[6,7,3]  R2536     5.4514998197555542e-01
    z[6,7,3]  R2537     -1.0321961343288422e-01
    z[6,7,3]  R2538     5.3564912080764771e-01
    z[6,7,3]  R2539     2.9216277599334717e-01
    z[6,7,3]  R2540     3.0592599511146545e-01
    z[6,7,3]  R2541     1.5349418856203556e-02
    z[6,7,3]  R2542     -1.7554216086864471e-01
    z[6,7,3]  R2543     1.0113058984279633e-01
    z[6,7,3]  R2544     4.0966841578483582e-01
    z[6,7,3]  R2545     -3.4179797768592834e-01
    z[6,7,3]  R2546     -2.9593538492918015e-03
    z[6,7,3]  R2547     -1.8164904788136482e-02
    z[6,7,3]  R2548     -3.0162784457206726e-01
    z[6,7,3]  R2549     2.2983743250370026e-01
    z[6,7,3]  R2550     2.0392403006553650e-01
    z[6,7,3]  R2551     3.1509986519813538e-01
    z[6,7,3]  R2552     -4.8180431127548218e-01
    z[6,7,3]  R2553     4.9940237402915955e-01
    z[6,7,3]  R2554     0.303492933511734
    z[6,7,3]  R2555     0.298991322517395
    z[6,7,3]  R2556     -9.7847640514373779e-02
    z[6,7,3]  R2557     -3.3750689029693604e-01
    z[6,7,3]  R2558     3.1253427267074585e-01
    z[6,7,3]  R2559     1.9220243394374847e-01
    z[6,7,3]  R2560     1.3646423816680908e-01
    z[6,7,3]  R2561     -2.2059574723243713e-01
    z[6,7,3]  R2562     1.5589003264904022e-01
    z[6,7,3]  R2563     3.3723658323287964e-01
    z[6,7,3]  R2564     5.4800111800432205e-02
    z[6,7,3]  R2565     1.9486233592033386e-01
    z[6,7,3]  R2566     1.5734905004501343e-01
    z[6,7,3]  R2567     -6.4490497112274170e-02
    z[6,7,3]  R2568     -0.0396580696105957
    z[6,7,3]  R2569     6.9540542364120483e-01
    z[6,7,3]  R2570     7.5495615601539612e-02
    z[6,7,3]  R2571     3.2061886787414551e-01
    z[6,7,3]  R2572     4.6656790375709534e-01
    z[6,7,3]  R2573     0.474361777305603
    z[6,7,3]  R2574     -3.0580973625183105e-01
    z[6,7,3]  R2575     4.5167854428291321e-01
    z[6,7,3]  R2576     -3.4414285421371460e-01
    z[6,7,3]  R2577     2.4899591505527496e-01
    z[6,7,3]  R2578     -7.5129413604736328e-01
    z[6,7,3]  R2579     3.4967169165611267e-01
    z[6,7,3]  R2580     4.1893583536148071e-01
    z[6,7,3]  R2581     -2.6354610919952393e-01
    z[6,7,3]  R2582     1.5516200102865696e-02
    z[6,7,3]  R2583     1.0314907878637314e-01
    z[6,7,3]  R2584     -0.500938892364502
    z[6,7,3]  R2585     1.9754789769649506e-01
    z[6,7,3]  R2586     2.4601487815380096e-01
    z[6,7,3]  R2587     -6.2834209203720093e-01
    z[6,7,3]  R2588     9.7366660833358765e-02
    z[6,7,3]  R2589     2.8921690583229065e-01
    z[6,7,3]  R2590     1.8290439248085022e-01
    z[6,7,3]  R2591     1.8155736848711967e-02
    z[6,7,3]  R2592     -1.2649394571781158e-01
    z[6,7,3]  R2593     -3.0813655257225037e-01
    z[6,7,3]  R2594     8.2620793581008911e-01
    z[6,7,3]  R2595     -1.2785139679908752e-01
    z[6,7,3]  R2596     -3.4935075044631958e-01
    z[6,7,3]  R2597     -2.9280295968055725e-01
    z[6,7,3]  R2598     -2.8917145729064941e-01
    z[6,7,3]  R2599     -3.9025139808654785e-01
    z[6,7,3]  R2600     1.1600656062364578e-01
    z[6,7,3]  R2601     1.1536002904176712e-01
    z[6,7,3]  R2602     1.1884523183107376e-01
    z[6,7,3]  R2603     2.1242666244506836e-01
    z[6,7,3]  R2604     4.3413969874382019e-01
    z[6,7,3]  R2605     3.3604815602302551e-01
    z[6,7,3]  R2606     9.0555511415004730e-02
    z[6,7,3]  R2607     -1.8992717564105988e-01
    z[6,7,3]  R2608     1.6848176717758179e-01
    z[6,7,3]  R2609     -1.2528951466083527e-01
    z[6,7,3]  R2610     4.6882618218660355e-02
    z[6,7,3]  R2611     -1.0609063506126404e-01
    z[6,7,3]  R2612     -3.6784434318542480e-01
    z[6,7,3]  R2613     -2.0180073380470276e-01
    z[6,7,3]  R2614     -9.5994293689727783e-01
    z[6,7,3]  R2615     3.4489190578460693e-01
    z[6,7,3]  R2616     0.0662183165550232
    z[6,7,3]  R2617     5.9517048299312592e-02
    z[6,7,3]  R2618     3.3371126651763916e-01
    z[6,7,3]  R2619     3.9141643047332764e-01
    z[6,7,3]  R2620     2.3797918856143951e-01
    z[6,7,3]  R2621     2.6741623878479004e-01
    z[6,7,3]  R2622     3.1077753752470016e-02
    z[6,7,3]  R2623     -1.4447696506977081e-01
    z[6,7,3]  R2624     -3.1387850642204285e-01
    z[6,7,3]  R2625     3.9956855773925781e-01
    z[6,7,3]  R2626     1.7371344566345215e-01
    z[6,7,3]  R2627     3.0642119050025940e-01
    z[6,7,3]  R2628     3.9904779195785522e-01
    z[6,7,3]  R2629     4.9581699073314667e-02
    z[6,7,3]  R2630     5.8728528022766113e-01
    z[6,7,3]  R2631     -4.5279961079359055e-02
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2478     -1
    z[6,7,4]  R2479     1
    z[6,7,4]  R2484     2.5442723184823990e-02
    z[6,7,4]  R2485     1.5681026875972748e-01
    z[6,7,4]  R2486     9.9835090339183807e-02
    z[6,7,4]  R2487     2.4434188008308411e-01
    z[6,7,4]  R2488     -3.4472875297069550e-02
    z[6,7,4]  R2489     3.6078128218650818e-01
    z[6,7,4]  R2490     2.0710060000419617e-01
    z[6,7,4]  R2491     4.5984137803316116e-02
    z[6,7,4]  R2492     2.6967635750770569e-01
    z[6,7,4]  R2493     3.3857962489128113e-01
    z[6,7,4]  R2494     1.8772387504577637e-01
    z[6,7,4]  R2495     -6.4913578331470490e-02
    z[6,7,4]  R2496     3.2985430955886841e-01
    z[6,7,4]  R2497     3.9232546091079712e-01
    z[6,7,4]  R2498     3.3945900201797485e-01
    z[6,7,4]  R2499     1.2313283234834671e-01
    z[6,7,4]  R2500     -4.2394474148750305e-01
    z[6,7,4]  R2501     3.2723551988601685e-01
    z[6,7,4]  R2502     5.8565360307693481e-01
    z[6,7,4]  R2503     2.8684270381927490e-01
    z[6,7,4]  R2504     -3.7396547198295593e-01
    z[6,7,4]  R2505     -1.7767411470413208e-01
    z[6,7,4]  R2506     2.1423611044883728e-01
    z[6,7,4]  R2507     4.1241145133972168e-01
    z[6,7,4]  R2508     -8.4720002487301826e-03
    z[6,7,4]  R2509     -2.1629419177770615e-02
    z[6,7,4]  R2510     -5.6049692630767822e-01
    z[6,7,4]  R2511     -4.1762074828147888e-01
    z[6,7,4]  R2512     -0.309527724981308
    z[6,7,4]  R2513     -1.8898989260196686e-01
    z[6,7,4]  R2514     -4.7102957963943481e-01
    z[6,7,4]  R2515     1.1562176048755646e-01
    z[6,7,4]  R2516     3.6604840308427811e-02
    z[6,7,4]  R2517     4.4977459311485291e-01
    z[6,7,4]  R2518     3.2556807994842529e-01
    z[6,7,4]  R2519     -3.6292336881160736e-02
    z[6,7,4]  R2520     2.5714278221130371e-02
    z[6,7,4]  R2521     -3.8738265633583069e-01
    z[6,7,4]  R2522     2.2139152884483337e-01
    z[6,7,4]  R2523     -3.5999670624732971e-01
    z[6,7,4]  R2524     -1.6703774034976959e-01
    z[6,7,4]  R2525     6.3023701310157776e-02
    z[6,7,4]  R2526     -3.0715823173522949e-02
    z[6,7,4]  R2527     -3.0421710014343262e-01
    z[6,7,4]  R2528     2.1932624280452728e-01
    z[6,7,4]  R2529     -1.7460497096180916e-02
    z[6,7,4]  R2530     4.3190225958824158e-01
    z[6,7,4]  R2531     0.67954021692276
    z[6,7,4]  R2532     -4.0179529786109924e-01
    z[6,7,4]  R2533     -1.0678673535585403e-01
    z[6,7,4]  R2534     2.9650720953941345e-01
    z[6,7,4]  R2535     -3.4526339173316956e-01
    z[6,7,4]  R2536     -1.7809841036796570e-01
    z[6,7,4]  R2537     6.9740664958953857e-01
    z[6,7,4]  R2538     3.9971670508384705e-01
    z[6,7,4]  R2539     -1.9026480615139008e-01
    z[6,7,4]  R2540     -1.3448676466941833e-01
    z[6,7,4]  R2541     -2.5099346041679382e-01
    z[6,7,4]  R2542     -3.4589907526969910e-01
    z[6,7,4]  R2543     -6.4240492880344391e-02
    z[6,7,4]  R2544     -8.8118426501750946e-02
    z[6,7,4]  R2545     4.5130811631679535e-02
    z[6,7,4]  R2546     -7.5812175869941711e-02
    z[6,7,4]  R2547     4.6922618150711060e-01
    z[6,7,4]  R2548     -2.1081276237964630e-01
    z[6,7,4]  R2549     -5.4514068365097046e-01
    z[6,7,4]  R2550     3.0137148499488831e-01
    z[6,7,4]  R2551     2.5732040405273438e-01
    z[6,7,4]  R2552     -2.0544733107089996e-01
    z[6,7,4]  R2553     4.3823051452636719e-01
    z[6,7,4]  R2554     1.1673387885093689e-01
    z[6,7,4]  R2555     -4.8256742954254150e-01
    z[6,7,4]  R2556     2.4360392987728119e-01
    z[6,7,4]  R2557     -3.2086694240570068e-01
    z[6,7,4]  R2558     4.6117997169494629e-01
    z[6,7,4]  R2559     3.9515700936317444e-01
    z[6,7,4]  R2560     4.5218691229820251e-02
    z[6,7,4]  R2561     -1.8601721525192261e-01
    z[6,7,4]  R2562     -3.0061137676239014e-01
    z[6,7,4]  R2563     1.4628148078918457e-01
    z[6,7,4]  R2564     -4.4163670390844345e-02
    z[6,7,4]  R2565     2.9067862033843994e-01
    z[6,7,4]  R2566     -4.5216238498687744e-01
    z[6,7,4]  R2567     -0.154743030667305
    z[6,7,4]  R2568     -2.7844479680061340e-01
    z[6,7,4]  R2569     -1.9415840506553650e-01
    z[6,7,4]  R2570     1.0383749753236771e-01
    z[6,7,4]  R2571     1.2211102247238159e-01
    z[6,7,4]  R2572     -2.6020416617393494e-01
    z[6,7,4]  R2573     -5.8943405747413635e-02
    z[6,7,4]  R2574     -3.0825346708297729e-01
    z[6,7,4]  R2575     3.0930081382393837e-02
    z[6,7,4]  R2576     -1.2759761512279510e-01
    z[6,7,4]  R2577     -6.0336075723171234e-02
    z[6,7,4]  R2578     1.0239310562610626e-01
    z[6,7,4]  R2579     -8.9971348643302917e-03
    z[6,7,4]  R2580     -2.2755637764930725e-03
    z[6,7,4]  R2581     -2.7343245223164558e-02
    z[6,7,4]  R2582     2.0597030222415924e-01
    z[6,7,4]  R2583     -1.0387220233678818e-01
    z[6,7,4]  R2584     2.8337278962135315e-01
    z[6,7,4]  R2585     1.1322257667779922e-01
    z[6,7,4]  R2586     2.7698168158531189e-01
    z[6,7,4]  R2587     -5.7650644332170486e-02
    z[6,7,4]  R2588     -7.6792903244495392e-02
    z[6,7,4]  R2589     -6.1464175581932068e-02
    z[6,7,4]  R2590     -2.8007525205612183e-01
    z[6,7,4]  R2591     -1.7160907387733459e-01
    z[6,7,4]  R2592     -1.3729830272495747e-02
    z[6,7,4]  R2593     -1.3171419501304626e-01
    z[6,7,4]  R2594     -3.1051984429359436e-01
    z[6,7,4]  R2595     6.0188418626785278e-01
    z[6,7,4]  R2596     -1.4745886623859406e-01
    z[6,7,4]  R2597     -4.6099311113357544e-01
    z[6,7,4]  R2598     6.8539303541183472e-01
    z[6,7,4]  R2599     1.8325036764144897e-01
    z[6,7,4]  R2600     6.8210393190383911e-01
    z[6,7,4]  R2601     -2.5741992518305779e-02
    z[6,7,4]  R2602     1.1290936172008514e-01
    z[6,7,4]  R2603     -0.592860758304596
    z[6,7,4]  R2604     2.8637340664863586e-01
    z[6,7,4]  R2605     1.8847092986106873e-01
    z[6,7,4]  R2606     -5.0618678331375122e-01
    z[6,7,4]  R2607     -5.3477054834365845e-01
    z[6,7,4]  R2608     2.1060076355934143e-01
    z[6,7,4]  R2609     7.1448874659836292e-03
    z[6,7,4]  R2610     -3.9999313652515411e-02
    z[6,7,4]  R2611     3.6102943122386932e-02
    z[6,7,4]  R2612     1.8114270269870758e-01
    z[6,7,4]  R2613     2.2137662768363953e-01
    z[6,7,4]  R2614     -1.6119654476642609e-01
    z[6,7,4]  R2615     7.2562344372272491e-02
    z[6,7,4]  R2616     7.1863633394241333e-01
    z[6,7,4]  R2617     1.9115528464317322e-01
    z[6,7,4]  R2618     5.5096572637557983e-01
    z[6,7,4]  R2619     -4.3163388967514038e-01
    z[6,7,4]  R2620     -1.8582014739513397e-01
    z[6,7,4]  R2621     -4.3526330590248108e-01
    z[6,7,4]  R2622     9.7522474825382233e-02
    z[6,7,4]  R2623     -0.558796226978302
    z[6,7,4]  R2624     -3.6174062639474869e-02
    z[6,7,4]  R2625     3.4133863449096680e-01
    z[6,7,4]  R2626     2.3872828111052513e-02
    z[6,7,4]  R2627     -1.8965993821620941e-01
    z[6,7,4]  R2628     3.4512110054492950e-02
    z[6,7,4]  R2629     2.4022670090198517e-01
    z[6,7,4]  R2630     9.3611087650060654e-03
    z[6,7,4]  R2631     1.6803732514381409e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2480     -1
    z[6,7,5]  R2481     1
    z[6,7,5]  R2484     1.8363554030656815e-02
    z[6,7,5]  R2485     -9.5805518329143524e-02
    z[6,7,5]  R2486     1.2756167352199554e-01
    z[6,7,5]  R2487     -5.5215455591678619e-02
    z[6,7,5]  R2488     1.4253821969032288e-01
    z[6,7,5]  R2489     1.5330988168716431e-01
    z[6,7,5]  R2490     -1.7740002274513245e-01
    z[6,7,5]  R2491     6.8646006286144257e-02
    z[6,7,5]  R2492     9.1301478445529938e-02
    z[6,7,5]  R2493     1.0748646408319473e-01
    z[6,7,5]  R2494     -6.3528245687484741e-01
    z[6,7,5]  R2495     -5.5146205425262451e-01
    z[6,7,5]  R2496     -1.5791727602481842e-01
    z[6,7,5]  R2497     1.1527353525161743e-01
    z[6,7,5]  R2498     -1.3519582152366638e-01
    z[6,7,5]  R2499     -4.2881774902343750e-01
    z[6,7,5]  R2500     -6.6672730445861816e-01
    z[6,7,5]  R2501     -3.4675487875938416e-01
    z[6,7,5]  R2502     -3.6504715681076050e-01
    z[6,7,5]  R2503     -6.0960131883621216e-01
    z[6,7,5]  R2504     -1.7386928200721741e-01
    z[6,7,5]  R2505     6.6571027040481567e-02
    z[6,7,5]  R2506     8.7013505399227142e-02
    z[6,7,5]  R2507     2.4824562668800354e-01
    z[6,7,5]  R2508     3.5148376226425171e-01
    z[6,7,5]  R2509     2.2151772677898407e-01
    z[6,7,5]  R2510     1.1689832806587219e-01
    z[6,7,5]  R2511     2.1122368052601814e-02
    z[6,7,5]  R2512     4.5777830481529236e-01
    z[6,7,5]  R2513     1.2328056618571281e-02
    z[6,7,5]  R2514     -0.448505699634552
    z[6,7,5]  R2515     -3.6816036701202393e-01
    z[6,7,5]  R2516     2.8279694914817810e-01
    z[6,7,5]  R2517     -5.4161384701728821e-02
    z[6,7,5]  R2518     1.2324440479278564e-01
    z[6,7,5]  R2519     -1.0633645206689835e-01
    z[6,7,5]  R2520     2.5598341599106789e-02
    z[6,7,5]  R2521     -2.3073397576808929e-02
    z[6,7,5]  R2522     -1.0603081434965134e-01
    z[6,7,5]  R2523     -6.0287380218505859e-01
    z[6,7,5]  R2524     -2.1796286106109619e-01
    z[6,7,5]  R2525     -1.5515540540218353e-01
    z[6,7,5]  R2526     -3.2942584156990051e-01
    z[6,7,5]  R2527     -2.4291633069515228e-01
    z[6,7,5]  R2528     -0.422921746969223
    z[6,7,5]  R2529     -4.3859258294105530e-01
    z[6,7,5]  R2530     -1.4036697149276733e-01
    z[6,7,5]  R2531     -1.4414627850055695e-01
    z[6,7,5]  R2532     -2.9180753231048584e-01
    z[6,7,5]  R2533     0.622606098651886
    z[6,7,5]  R2534     2.4356535077095032e-01
    z[6,7,5]  R2535     -3.0759337544441223e-01
    z[6,7,5]  R2536     -2.7960723638534546e-01
    z[6,7,5]  R2537     -0.421384334564209
    z[6,7,5]  R2538     -5.0109249353408813e-01
    z[6,7,5]  R2539     -6.7544782161712646e-01
    z[6,7,5]  R2540     5.5559748411178589e-01
    z[6,7,5]  R2541     3.2968875765800476e-01
    z[6,7,5]  R2542     4.8926264047622681e-02
    z[6,7,5]  R2543     1.0916931927204132e-01
    z[6,7,5]  R2544     -2.5254514813423157e-01
    z[6,7,5]  R2545     -6.4476072788238525e-01
    z[6,7,5]  R2546     3.6030894517898560e-01
    z[6,7,5]  R2547     -4.0189573168754578e-01
    z[6,7,5]  R2548     -2.4131463468074799e-01
    z[6,7,5]  R2549     -2.2471027076244354e-01
    z[6,7,5]  R2550     0.314242959022522
    z[6,7,5]  R2551     -3.2006821036338806e-01
    z[6,7,5]  R2552     -3.0427744984626770e-01
    z[6,7,5]  R2553     1.2288712710142136e-01
    z[6,7,5]  R2554     9.0067885816097260e-02
    z[6,7,5]  R2555     -4.1855999827384949e-01
    z[6,7,5]  R2556     -5.1251932978630066e-02
    z[6,7,5]  R2557     -3.1081253290176392e-01
    z[6,7,5]  R2558     -4.3841204047203064e-01
    z[6,7,5]  R2559     -4.6696880459785461e-01
    z[6,7,5]  R2560     -7.8776758909225464e-01
    z[6,7,5]  R2561     -0.0409141406416893
    z[6,7,5]  R2562     -4.1150298714637756e-01
    z[6,7,5]  R2563     -4.4737223535776138e-02
    z[6,7,5]  R2564     -2.4522005021572113e-01
    z[6,7,5]  R2565     -4.9179011583328247e-01
    z[6,7,5]  R2566     -4.9940440058708191e-01
    z[6,7,5]  R2567     -7.4444037675857544e-01
    z[6,7,5]  R2568     1.4940799772739410e-01
    z[6,7,5]  R2569     2.4619838595390320e-01
    z[6,7,5]  R2570     -1.0064287483692169e-01
    z[6,7,5]  R2571     4.2561632394790649e-01
    z[6,7,5]  R2572     9.8149076104164124e-02
    z[6,7,5]  R2573     1.9988100230693817e-01
    z[6,7,5]  R2574     -2.0188757777214050e-01
    z[6,7,5]  R2575     1.4005610346794128e-01
    z[6,7,5]  R2576     -0.479707807302475
    z[6,7,5]  R2577     -8.0626225471496582e-01
    z[6,7,5]  R2578     -1.2126793712377548e-01
    z[6,7,5]  R2579     1.4181299507617950e-01
    z[6,7,5]  R2580     1.1308369040489197e-01
    z[6,7,5]  R2581     4.5485013723373413e-01
    z[6,7,5]  R2582     -2.9244298115372658e-02
    z[6,7,5]  R2583     1.4941900968551636e-01
    z[6,7,5]  R2584     -2.0874448120594025e-01
    z[6,7,5]  R2585     -7.2684699296951294e-01
    z[6,7,5]  R2586     -3.9484921097755432e-01
    z[6,7,5]  R2587     -1.2284660339355469e-01
    z[6,7,5]  R2588     1.7613308131694794e-01
    z[6,7,5]  R2589     -1.5199208259582520e-01
    z[6,7,5]  R2590     -0.0385298952460289
    z[6,7,5]  R2591     -3.2177552580833435e-02
    z[6,7,5]  R2592     -2.9607942700386047e-01
    z[6,7,5]  R2593     -3.6532118916511536e-01
    z[6,7,5]  R2594     -1.9773536920547485e-01
    z[6,7,5]  R2595     -4.3851515650749207e-01
    z[6,7,5]  R2596     -2.9622310400009155e-01
    z[6,7,5]  R2597     -0.588651180267334
    z[6,7,5]  R2598     4.7824871540069580e-01
    z[6,7,5]  R2599     2.8403592109680176e-01
    z[6,7,5]  R2600     -1.5754656493663788e-01
    z[6,7,5]  R2601     -2.9139408469200134e-01
    z[6,7,5]  R2602     2.2504577040672302e-01
    z[6,7,5]  R2603     -0.0945129320025444
    z[6,7,5]  R2604     2.0391296595335007e-02
    z[6,7,5]  R2605     5.7642799615859985e-01
    z[6,7,5]  R2606     4.6518808603286743e-01
    z[6,7,5]  R2607     2.3237279057502747e-01
    z[6,7,5]  R2608     -5.5580466985702515e-01
    z[6,7,5]  R2609     0.0278362687677145
    z[6,7,5]  R2610     2.2809931635856628e-01
    z[6,7,5]  R2611     2.1465249359607697e-01
    z[6,7,5]  R2612     -4.1360697150230408e-01
    z[6,7,5]  R2613     2.0990513265132904e-01
    z[6,7,5]  R2614     7.3872774839401245e-02
    z[6,7,5]  R2615     9.8390288650989532e-02
    z[6,7,5]  R2616     -3.4756880998611450e-01
    z[6,7,5]  R2617     -7.5938858091831207e-02
    z[6,7,5]  R2618     9.4430379569530487e-02
    z[6,7,5]  R2619     4.3317312002182007e-01
    z[6,7,5]  R2620     -4.4979268312454224e-01
    z[6,7,5]  R2621     4.5299929380416870e-01
    z[6,7,5]  R2622     -9.2040526866912842e-01
    z[6,7,5]  R2623     -3.4115061163902283e-01
    z[6,7,5]  R2624     4.6103116869926453e-01
    z[6,7,5]  R2625     -2.2435872256755829e-01
    z[6,7,5]  R2626     1.6398425941588357e-05
    z[6,7,5]  R2627     -3.3011871576309204e-01
    z[6,7,5]  R2628     2.0022456347942352e-01
    z[6,7,5]  R2629     2.5162905454635620e-02
    z[6,7,5]  R2630     5.9163635969161987e-01
    z[6,7,5]  R2631     2.0850417017936707e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2482     -1
    z[6,7,6]  R2483     1
    z[6,7,6]  R2484     -1.1770492047071457e-01
    z[6,7,6]  R2485     -4.4261552393436432e-03
    z[6,7,6]  R2486     -1.6064360737800598e-01
    z[6,7,6]  R2487     -1.6098898649215698e-01
    z[6,7,6]  R2488     -0.301470011472702
    z[6,7,6]  R2489     1.6815978288650513e-01
    z[6,7,6]  R2490     -1.2203180789947510e-01
    z[6,7,6]  R2491     1.4321976900100708e-01
    z[6,7,6]  R2492     -1.0164518840610981e-02
    z[6,7,6]  R2493     2.7247878909111023e-01
    z[6,7,6]  R2494     1.8773525953292847e-01
    z[6,7,6]  R2495     -2.3031197488307953e-01
    z[6,7,6]  R2496     3.7443738430738449e-02
    z[6,7,6]  R2497     -5.8671992272138596e-02
    z[6,7,6]  R2498     -4.4896829128265381e-01
    z[6,7,6]  R2499     0.0770488902926445
    z[6,7,6]  R2500     -2.5659623742103577e-01
    z[6,7,6]  R2501     -7.1774378418922424e-02
    z[6,7,6]  R2502     3.3430272340774536e-01
    z[6,7,6]  R2503     2.6974827051162720e-02
    z[6,7,6]  R2504     -6.8659879267215729e-02
    z[6,7,6]  R2505     8.4615841507911682e-02
    z[6,7,6]  R2506     9.7019389271736145e-02
    z[6,7,6]  R2507     3.8433033227920532e-01
    z[6,7,6]  R2508     -6.3249057531356812e-01
    z[6,7,6]  R2509     -2.1371269226074219e-01
    z[6,7,6]  R2510     -4.1133394837379456e-01
    z[6,7,6]  R2511     -0.0805663913488388
    z[6,7,6]  R2512     1.8261478841304779e-01
    z[6,7,6]  R2513     -2.9590731486678123e-02
    z[6,7,6]  R2514     -9.6845522522926331e-02
    z[6,7,6]  R2515     2.0080134272575378e-01
    z[6,7,6]  R2516     -2.0039488375186920e-01
    z[6,7,6]  R2517     3.6406585574150085e-01
    z[6,7,6]  R2518     -2.0754756033420563e-01
    z[6,7,6]  R2519     0.0768914446234703
    z[6,7,6]  R2520     1.9086304306983948e-01
    z[6,7,6]  R2521     2.0770902931690216e-01
    z[6,7,6]  R2522     4.1985239833593369e-02
    z[6,7,6]  R2523     -2.1316848695278168e-01
    z[6,7,6]  R2524     -7.0847973227500916e-02
    z[6,7,6]  R2525     1.4123211801052094e-01
    z[6,7,6]  R2526     -7.8969992697238922e-02
    z[6,7,6]  R2527     -1.1099644750356674e-01
    z[6,7,6]  R2528     -1.9904676079750061e-01
    z[6,7,6]  R2529     -2.7316769957542419e-01
    z[6,7,6]  R2530     3.7511962652206421e-01
    z[6,7,6]  R2531     -2.7071639895439148e-01
    z[6,7,6]  R2532     0.0816039890050888
    z[6,7,6]  R2533     1.1319984495639801e-01
    z[6,7,6]  R2534     2.7768164873123169e-01
    z[6,7,6]  R2535     6.2627747654914856e-02
    z[6,7,6]  R2536     -0.0424545481801033
    z[6,7,6]  R2537     -4.8246022313833237e-02
    z[6,7,6]  R2538     -1.7423997819423676e-01
    z[6,7,6]  R2539     -2.3064975440502167e-01
    z[6,7,6]  R2540     -2.5198507308959961e-01
    z[6,7,6]  R2541     -2.8632849454879761e-01
    z[6,7,6]  R2542     -1.7734473943710327e-01
    z[6,7,6]  R2543     0.0823395624756813
    z[6,7,6]  R2544     -2.5365290045738220e-01
    z[6,7,6]  R2545     5.3452465683221817e-02
    z[6,7,6]  R2546     1.7981614917516708e-02
    z[6,7,6]  R2547     8.4437653422355652e-02
    z[6,7,6]  R2548     1.7719270288944244e-01
    z[6,7,6]  R2549     -4.9363183975219727e-01
    z[6,7,6]  R2550     1.7795109748840332e-01
    z[6,7,6]  R2551     -6.2378573417663574e-01
    z[6,7,6]  R2552     -2.1367833018302917e-01
    z[6,7,6]  R2553     1.7445491254329681e-01
    z[6,7,6]  R2554     1.5673954784870148e-01
    z[6,7,6]  R2555     -0.282549113035202
    z[6,7,6]  R2556     -9.0264402329921722e-02
    z[6,7,6]  R2557     2.8157643973827362e-03
    z[6,7,6]  R2558     -6.1274436302483082e-03
    z[6,7,6]  R2559     2.0600537955760956e-01
    z[6,7,6]  R2560     1.3947731256484985e-01
    z[6,7,6]  R2561     1.3983491063117981e-01
    z[6,7,6]  R2562     -2.2028565406799316e-01
    z[6,7,6]  R2563     1.3029728829860687e-01
    z[6,7,6]  R2564     -2.9339674860239029e-02
    z[6,7,6]  R2565     -1.4245378971099854e-01
    z[6,7,6]  R2566     -0.257985919713974
    z[6,7,6]  R2567     -2.4304588139057159e-01
    z[6,7,6]  R2568     -5.2570408582687378e-01
    z[6,7,6]  R2569     3.2696448266506195e-02
    z[6,7,6]  R2570     -3.7743654102087021e-02
    z[6,7,6]  R2571     -0.148038849234581
    z[6,7,6]  R2572     -2.4738231301307678e-01
    z[6,7,6]  R2573     -2.0432794094085693e-01
    z[6,7,6]  R2574     -1.5077529847621918e-01
    z[6,7,6]  R2575     -1.4350248873233795e-01
    z[6,7,6]  R2576     1.1306065320968628e-01
    z[6,7,6]  R2577     1.0979101061820984e-01
    z[6,7,6]  R2578     3.0902945995330811e-01
    z[6,7,6]  R2579     0.0984988585114479
    z[6,7,6]  R2580     -3.4991574287414551e-01
    z[6,7,6]  R2581     -1.4413505792617798e-01
    z[6,7,6]  R2582     2.2152608260512352e-02
    z[6,7,6]  R2583     -7.0057488977909088e-02
    z[6,7,6]  R2584     1.2082371860742569e-01
    z[6,7,6]  R2585     7.4731156229972839e-02
    z[6,7,6]  R2586     0.2565937936306
    z[6,7,6]  R2587     2.3028762638568878e-01
    z[6,7,6]  R2588     -2.3457955569028854e-02
    z[6,7,6]  R2589     1.1988984793424606e-01
    z[6,7,6]  R2590     1.9500355422496796e-01
    z[6,7,6]  R2591     5.0898820161819458e-01
    z[6,7,6]  R2592     4.6658405661582947e-01
    z[6,7,6]  R2593     1.8439665436744690e-01
    z[6,7,6]  R2594     8.5967361927032471e-02
    z[6,7,6]  R2595     4.3267118930816650e-01
    z[6,7,6]  R2596     2.2212950885295868e-01
    z[6,7,6]  R2597     -4.0958082675933838e-01
    z[6,7,6]  R2598     2.1534173190593719e-01
    z[6,7,6]  R2599     0.585595428943634
    z[6,7,6]  R2600     -1.3694108463823795e-02
    z[6,7,6]  R2601     2.0154589414596558e-01
    z[6,7,6]  R2602     3.4045910835266113e-01
    z[6,7,6]  R2603     -3.1847360730171204e-01
    z[6,7,6]  R2604     -6.3530862331390381e-01
    z[6,7,6]  R2605     -4.7465628385543823e-01
    z[6,7,6]  R2606     -3.5176226496696472e-01
    z[6,7,6]  R2607     3.6010544747114182e-02
    z[6,7,6]  R2608     -1.1052598804235458e-01
    z[6,7,6]  R2609     -1.0917614400386810e-01
    z[6,7,6]  R2610     -3.6055833101272583e-01
    z[6,7,6]  R2611     4.4140985608100891e-01
    z[6,7,6]  R2612     -1.8599297106266022e-01
    z[6,7,6]  R2613     3.2376810908317566e-01
    z[6,7,6]  R2614     4.6240020543336868e-02
    z[6,7,6]  R2615     3.2740023732185364e-01
    z[6,7,6]  R2616     -1.5350070595741272e-01
    z[6,7,6]  R2617     9.4344235956668854e-02
    z[6,7,6]  R2618     2.6627802848815918e-01
    z[6,7,6]  R2619     -2.5836843252182007e-01
    z[6,7,6]  R2620     -1.9068348407745361e-01
    z[6,7,6]  R2621     2.1036484837532043e-01
    z[6,7,6]  R2622     1.6790562868118286e-01
    z[6,7,6]  R2623     -6.6682326793670654e-01
    z[6,7,6]  R2624     -6.6632938385009766e-01
    z[6,7,6]  R2625     -1.1788893491029739e-02
    z[6,7,6]  R2626     -1.4518619515001774e-02
    z[6,7,6]  R2627     -1.3808824121952057e-01
    z[6,7,6]  R2628     -8.0798274278640747e-01
    z[6,7,6]  R2629     0.318573534488678
    z[6,7,6]  R2630     -2.6231896877288818e-01
    z[6,7,6]  R2631     7.5478866696357727e-02
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2632     -1
    z[7,6,0]  R2633     1
    z[7,6,0]  R2646     -9.5497183501720428e-02
    z[7,6,0]  R2647     3.0647508800029755e-02
    z[7,6,0]  R2648     -6.5438938140869141e-01
    z[7,6,0]  R2649     1.0101261734962463e-01
    z[7,6,0]  R2650     3.2455902546644211e-02
    z[7,6,0]  R2651     -2.4471038579940796e-01
    z[7,6,0]  R2652     -4.3175509572029114e-01
    z[7,6,0]  R2653     -1.8281176686286926e-01
    z[7,6,0]  R2654     -1.3119821250438690e-01
    z[7,6,0]  R2655     -3.5663988441228867e-02
    z[7,6,0]  R2656     3.1553596258163452e-01
    z[7,6,0]  R2657     4.3720972537994385e-01
    z[7,6,0]  R2658     3.4140643477439880e-01
    z[7,6,0]  R2659     4.8278063535690308e-01
    z[7,6,0]  R2660     5.6979817152023315e-01
    z[7,6,0]  R2661     -6.2885993719100952e-01
    z[7,6,0]  R2662     -7.5865501165390015e-01
    z[7,6,0]  R2663     -5.0260728597640991e-01
    z[7,6,0]  R2664     8.9063942432403564e-02
    z[7,6,0]  R2665     6.8356573581695557e-01
    z[7,6,0]  R2666     1.5766522288322449e-01
    z[7,6,0]  R2667     6.4233458042144775e-01
    z[7,6,0]  R2668     4.1580140590667725e-01
    z[7,6,0]  R2669     5.6499028205871582e-01
    z[7,6,0]  R2670     0.414422869682312
    z[7,6,0]  R2671     1.7025206238031387e-02
    z[7,6,0]  R2672     4.7953811287879944e-01
    z[7,6,0]  R2673     4.0981176495552063e-01
    z[7,6,0]  R2674     -2.5155130028724670e-01
    z[7,6,0]  R2675     -1.0096784681081772e-01
    z[7,6,0]  R2676     -1.2372843176126480e-01
    z[7,6,0]  R2677     -7.0284180343151093e-02
    z[7,6,0]  R2678     4.9607205390930176e-01
    z[7,6,0]  R2679     1.1852400004863739e-01
    z[7,6,0]  R2680     -1.3189294934272766e-01
    z[7,6,0]  R2681     2.2762393951416016e-01
    z[7,6,0]  R2682     1.8111190199851990e-01
    z[7,6,0]  R2683     -8.5589081048965454e-01
    z[7,6,0]  R2684     -8.7384122610092163e-01
    z[7,6,0]  R2685     -8.8748365640640259e-01
    z[7,6,0]  R2686     -9.4941294193267822e-01
    z[7,6,0]  R2687     -8.5786253213882446e-01
    z[7,6,0]  R2688     -9.1623759269714355e-01
    z[7,6,0]  R2689     -7.2450643777847290e-01
    z[7,6,0]  R2690     -9.3621307611465454e-01
    z[7,6,0]  R2691     -0.96856290102005
    z[7,6,0]  R2692     -8.3268773555755615e-01
    z[7,6,0]  R2693     -8.0606764554977417e-01
    z[7,6,0]  R2694     2.0103774964809418e-01
    z[7,6,0]  R2695     2.1778398752212524e-01
    z[7,6,0]  R2696     1.9404245913028717e-01
    z[7,6,0]  R2697     -0.0822681114077568
    z[7,6,0]  R2698     -2.5601822417229414e-03
    z[7,6,0]  R2699     2.5686609745025635e-01
    z[7,6,0]  R2700     2.3033238947391510e-01
    z[7,6,0]  R2701     3.1332874298095703e-01
    z[7,6,0]  R2702     -1.5054904855787754e-02
    z[7,6,0]  R2703     1.5797884762287140e-01
    z[7,6,0]  R2704     8.2420194149017334e-01
    z[7,6,0]  R2705     4.1432134807109833e-02
    z[7,6,0]  R2706     0.51854008436203
    z[7,6,0]  R2707     7.2541677951812744e-01
    z[7,6,0]  R2708     5.0932067632675171e-01
    z[7,6,0]  R2709     5.2500754594802856e-01
    z[7,6,0]  R2710     3.7646532058715820e-01
    z[7,6,0]  R2711     7.7187612652778625e-02
    z[7,6,0]  R2712     5.5519080162048340e-01
    z[7,6,0]  R2713     1.7107808589935303e-01
    z[7,6,0]  R2714     5.8747440576553345e-01
    z[7,6,0]  R2715     0.787808895111084
    z[7,6,0]  R2716     -1.2902888655662537e-01
    z[7,6,0]  R2717     7.3995554447174072e-01
    z[7,6,0]  R2718     1.4056351780891418e-01
    z[7,6,0]  R2719     6.9226735830307007e-01
    z[7,6,0]  R2720     2.5577588006854057e-02
    z[7,6,0]  R2721     8.1297689676284790e-01
    z[7,6,0]  R2722     5.6801873445510864e-01
    z[7,6,0]  R2723     -2.2160109877586365e-01
    z[7,6,0]  R2724     -1.0260418057441711e-03
    z[7,6,0]  R2725     3.2716092467308044e-01
    z[7,6,0]  R2726     4.2324984073638916e-01
    z[7,6,0]  R2727     4.8220828175544739e-02
    z[7,6,0]  R2728     0.618370532989502
    z[7,6,0]  R2729     5.8190727233886719e-01
    z[7,6,0]  R2730     3.2456271350383759e-02
    z[7,6,0]  R2731     -2.7239865064620972e-01
    z[7,6,0]  R2732     -3.8483291864395142e-01
    z[7,6,0]  R2733     7.6029294729232788e-01
    z[7,6,0]  R2734     -7.7624571323394775e-01
    z[7,6,0]  R2735     7.8828144073486328e-01
    z[7,6,0]  R2736     6.0670781135559082e-01
    z[7,6,0]  R2737     1.2974782288074493e-01
    z[7,6,0]  R2738     4.8424193263053894e-01
    z[7,6,0]  R2739     5.4049581289291382e-01
    z[7,6,0]  R2740     5.2734637260437012e-01
    z[7,6,0]  R2741     5.1648199558258057e-01
    z[7,6,0]  R2742     -3.5389885306358337e-01
    z[7,6,0]  R2743     0.0541507862508297
    z[7,6,0]  R2744     4.1410472989082336e-01
    z[7,6,0]  R2745     1.3840852305293083e-02
    z[7,6,0]  R2746     8.0886858701705933e-01
    z[7,6,0]  R2747     -4.1802600026130676e-01
    z[7,6,0]  R2748     -4.2783138155937195e-01
    z[7,6,0]  R2749     4.6446800231933594e-01
    z[7,6,0]  R2750     7.1531379222869873e-01
    z[7,6,0]  R2751     5.2551430463790894e-01
    z[7,6,0]  R2752     -3.5186198353767395e-01
    z[7,6,0]  R2753     7.0942497253417969e-01
    z[7,6,0]  R2754     8.9145672321319580e-01
    z[7,6,0]  R2755     4.3067368865013123e-01
    z[7,6,0]  R2756     -2.3954921960830688e-01
    z[7,6,0]  R2757     -5.8236384391784668e-01
    z[7,6,0]  R2758     6.2779515981674194e-01
    z[7,6,0]  R2759     5.2663028240203857e-01
    z[7,6,0]  R2760     4.8508965969085693e-01
    z[7,6,0]  R2761     8.4526282548904419e-01
    z[7,6,0]  R2762     -4.7784465551376343e-01
    z[7,6,0]  R2763     1.4369764365255833e-02
    z[7,6,0]  R2764     -7.4734479188919067e-01
    z[7,6,0]  R2765     6.1633431911468506e-01
    z[7,6,0]  R2766     0.401021271944046
    z[7,6,0]  R2767     4.8296386003494263e-01
    z[7,6,0]  R2768     0.680448055267334
    z[7,6,0]  R2769     -3.7621328234672546e-01
    z[7,6,0]  R2770     1.2038894742727280e-01
    z[7,6,0]  R2771     -1.7895002383738756e-04
    z[7,6,0]  R2772     -8.2989625632762909e-02
    z[7,6,0]  R2773     -2.8991684317588806e-02
    z[7,6,0]  R2774     -0.743486762046814
    z[7,6,0]  R2775     7.0977705717086792e-01
    z[7,6,0]  R2776     5.7753592729568481e-01
    z[7,6,0]  R2777     4.3028134107589722e-01
    z[7,6,0]  R2778     1.7088226974010468e-01
    z[7,6,0]  R2779     6.7804497666656971e-03
    z[7,6,0]  R2780     -6.1569139361381531e-02
    z[7,6,0]  R2781     3.5309992730617523e-02
    z[7,6,0]  R2782     -1.1695101112127304e-01
    z[7,6,0]  R2783     -4.5996751636266708e-02
    z[7,6,0]  R2784     7.2832182049751282e-03
    z[7,6,0]  R2785     6.1436778306961060e-01
    z[7,6,0]  R2786     5.5816221237182617e-01
    z[7,6,0]  R2787     -4.5648229122161865e-01
    z[7,6,0]  R2788     -3.2614029943943024e-02
    z[7,6,0]  R2789     -2.6928958296775818e-01
    z[7,6,0]  R2790     -1.3647805154323578e-01
    z[7,6,0]  R2791     2.3611165583133698e-02
    z[7,6,0]  R2792     -6.7060112953186035e-02
    z[7,6,0]  R2793     -0.0773346871137619
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2634     -1
    z[7,6,1]  R2635     1
    z[7,6,1]  R2646     -3.4604340791702271e-01
    z[7,6,1]  R2647     -3.2077878713607788e-01
    z[7,6,1]  R2648     -4.2159634828567505e-01
    z[7,6,1]  R2649     -3.9484176039695740e-01
    z[7,6,1]  R2650     -3.1864890456199646e-01
    z[7,6,1]  R2651     -2.7003687620162964e-01
    z[7,6,1]  R2652     -5.0405979156494141e-01
    z[7,6,1]  R2653     7.4345552921295166e-01
    z[7,6,1]  R2654     6.9006556272506714e-01
    z[7,6,1]  R2655     3.8838860392570496e-01
    z[7,6,1]  R2656     4.5317673683166504e-01
    z[7,6,1]  R2657     3.0732971429824829e-01
    z[7,6,1]  R2658     5.2750808000564575e-01
    z[7,6,1]  R2659     6.0210186243057251e-01
    z[7,6,1]  R2660     4.3000218272209167e-01
    z[7,6,1]  R2661     3.1987950205802917e-01
    z[7,6,1]  R2662     3.3580586314201355e-01
    z[7,6,1]  R2663     2.4285274744033813e-01
    z[7,6,1]  R2664     -4.6651086211204529e-01
    z[7,6,1]  R2665     -0.539271891117096
    z[7,6,1]  R2666     -1.4057770371437073e-01
    z[7,6,1]  R2667     0.567960798740387
    z[7,6,1]  R2668     -0.228984072804451
    z[7,6,1]  R2669     7.9121059179306030e-01
    z[7,6,1]  R2670     5.5430847406387329e-01
    z[7,6,1]  R2671     5.5086892843246460e-01
    z[7,6,1]  R2672     6.2954002618789673e-01
    z[7,6,1]  R2673     5.6699329614639282e-01
    z[7,6,1]  R2674     2.1715676784515381e-01
    z[7,6,1]  R2675     3.0918952822685242e-01
    z[7,6,1]  R2676     -4.7771230340003967e-01
    z[7,6,1]  R2677     6.6895473003387451e-01
    z[7,6,1]  R2678     7.5023949146270752e-01
    z[7,6,1]  R2679     8.2526785135269165e-01
    z[7,6,1]  R2680     1.5270633995532990e-01
    z[7,6,1]  R2681     8.2591497898101807e-01
    z[7,6,1]  R2682     3.5667210817337036e-01
    z[7,6,1]  R2683     1.1318787187337875e-01
    z[7,6,1]  R2684     -3.8983193039894104e-01
    z[7,6,1]  R2685     -3.6499857902526855e-01
    z[7,6,1]  R2686     -2.1544776856899261e-02
    z[7,6,1]  R2687     -6.8940952420234680e-02
    z[7,6,1]  R2688     -1.2151963263750076e-01
    z[7,6,1]  R2689     -5.3895201534032822e-02
    z[7,6,1]  R2690     3.3995623234659433e-03
    z[7,6,1]  R2691     -6.3452741596847773e-04
    z[7,6,1]  R2692     2.7241089940071106e-01
    z[7,6,1]  R2693     -2.8118479251861572e-01
    z[7,6,1]  R2694     -5.0241601467132568e-01
    z[7,6,1]  R2695     -1.9956082105636597e-01
    z[7,6,1]  R2696     -5.9879440069198608e-01
    z[7,6,1]  R2697     -7.0977377891540527e-01
    z[7,6,1]  R2698     -4.8572760820388794e-01
    z[7,6,1]  R2699     -5.2118331193923950e-01
    z[7,6,1]  R2700     -6.8679213523864746e-02
    z[7,6,1]  R2701     -5.8934754133224487e-01
    z[7,6,1]  R2702     -4.0870368480682373e-01
    z[7,6,1]  R2703     -5.2850800752639771e-01
    z[7,6,1]  R2704     -3.1171565875411034e-02
    z[7,6,1]  R2705     -9.5037811994552612e-01
    z[7,6,1]  R2706     3.0611717700958252e-01
    z[7,6,1]  R2707     1.5424132347106934e-01
    z[7,6,1]  R2708     -9.2823922634124756e-02
    z[7,6,1]  R2709     3.5708022117614746e-01
    z[7,6,1]  R2710     -5.2102571725845337e-01
    z[7,6,1]  R2711     6.6686397790908813e-01
    z[7,6,1]  R2712     -1.4312581717967987e-01
    z[7,6,1]  R2713     6.0229659080505371e-01
    z[7,6,1]  R2714     -3.4938564896583557e-01
    z[7,6,1]  R2715     1.5225054323673248e-01
    z[7,6,1]  R2716     -7.8362977504730225e-01
    z[7,6,1]  R2717     0.045985147356987
    z[7,6,1]  R2718     -8.9270532131195068e-01
    z[7,6,1]  R2719     1.0074172914028168e-01
    z[7,6,1]  R2720     -6.3061875104904175e-01
    z[7,6,1]  R2721     -3.0362397432327271e-01
    z[7,6,1]  R2722     1.2596595287322998e-01
    z[7,6,1]  R2723     -5.5027091503143311e-01
    z[7,6,1]  R2724     -7.6516550779342651e-01
    z[7,6,1]  R2725     -8.8505178689956665e-01
    z[7,6,1]  R2726     -5.2559173107147217e-01
    z[7,6,1]  R2727     -0.89644455909729
    z[7,6,1]  R2728     2.1496775746345520e-01
    z[7,6,1]  R2729     -2.3313325643539429e-01
    z[7,6,1]  R2730     -7.7686858177185059e-01
    z[7,6,1]  R2731     -5.5272829532623291e-01
    z[7,6,1]  R2732     -1.3243253529071808e-01
    z[7,6,1]  R2733     -3.7105970084667206e-02
    z[7,6,1]  R2734     -2.6720070838928223e-01
    z[7,6,1]  R2735     -3.0520877242088318e-01
    z[7,6,1]  R2736     -4.4281157851219177e-01
    z[7,6,1]  R2737     -4.7522720694541931e-01
    z[7,6,1]  R2738     -1.7094098031520844e-01
    z[7,6,1]  R2739     -1.9637905061244965e-01
    z[7,6,1]  R2740     -4.5808512717485428e-02
    z[7,6,1]  R2741     2.2161212563514709e-01
    z[7,6,1]  R2742     7.5454115867614746e-01
    z[7,6,1]  R2743     8.6229842901229858e-01
    z[7,6,1]  R2744     -2.6137259602546692e-01
    z[7,6,1]  R2745     -6.7997843027114868e-01
    z[7,6,1]  R2746     1.7777520418167114e-01
    z[7,6,1]  R2747     -6.4122051000595093e-01
    z[7,6,1]  R2748     -0.055446557700634
    z[7,6,1]  R2749     -2.7222353219985962e-01
    z[7,6,1]  R2750     -2.6235067844390869e-01
    z[7,6,1]  R2751     -1.5870186686515808e-01
    z[7,6,1]  R2752     1.6907547414302826e-01
    z[7,6,1]  R2753     2.0996022969484329e-02
    z[7,6,1]  R2754     -1.4200265705585480e-01
    z[7,6,1]  R2755     -3.0012896656990051e-01
    z[7,6,1]  R2756     -7.6789957284927368e-01
    z[7,6,1]  R2757     -5.6674383580684662e-02
    z[7,6,1]  R2758     -1.9198960065841675e-01
    z[7,6,1]  R2759     -1.4512595720589161e-02
    z[7,6,1]  R2760     3.6846555769443512e-02
    z[7,6,1]  R2761     2.8690424561500549e-01
    z[7,6,1]  R2762     4.8175626993179321e-01
    z[7,6,1]  R2763     7.9874765872955322e-01
    z[7,6,1]  R2764     -1.4394551515579224e-02
    z[7,6,1]  R2765     -3.0781856179237366e-01
    z[7,6,1]  R2766     -2.7524015307426453e-01
    z[7,6,1]  R2767     -2.0112356543540955e-01
    z[7,6,1]  R2768     1.0570946335792542e-01
    z[7,6,1]  R2769     -1.8369263410568237e-01
    z[7,6,1]  R2770     5.2311939001083374e-01
    z[7,6,1]  R2771     7.2564291954040527e-01
    z[7,6,1]  R2772     7.3291534185409546e-01
    z[7,6,1]  R2773     8.1506699323654175e-01
    z[7,6,1]  R2774     9.3010291457176208e-02
    z[7,6,1]  R2775     -1.8123178184032440e-01
    z[7,6,1]  R2776     -0.145138680934906
    z[7,6,1]  R2777     -2.4333159625530243e-01
    z[7,6,1]  R2778     -4.8579236865043640e-01
    z[7,6,1]  R2779     6.5936404466629028e-01
    z[7,6,1]  R2780     6.2111669778823853e-01
    z[7,6,1]  R2781     0.584827721118927
    z[7,6,1]  R2782     8.8545787334442139e-01
    z[7,6,1]  R2783     8.1723350286483765e-01
    z[7,6,1]  R2784     -4.9319869279861450e-01
    z[7,6,1]  R2785     -1.6294093430042267e-01
    z[7,6,1]  R2786     -5.0169759988784790e-01
    z[7,6,1]  R2787     -3.1170082092285156e-01
    z[7,6,1]  R2788     9.1450905799865723e-01
    z[7,6,1]  R2789     8.0454438924789429e-01
    z[7,6,1]  R2790     0.808972954750061
    z[7,6,1]  R2791     6.4437693357467651e-01
    z[7,6,1]  R2792     6.1878538131713867e-01
    z[7,6,1]  R2793     0.753345787525177
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2636     -1
    z[7,6,2]  R2637     1
    z[7,6,2]  R2646     -2.1354725956916809e-01
    z[7,6,2]  R2647     3.7155240774154663e-01
    z[7,6,2]  R2648     0.336379736661911
    z[7,6,2]  R2649     1.4622454345226288e-01
    z[7,6,2]  R2650     2.6254877448081970e-01
    z[7,6,2]  R2651     5.0766289234161377e-01
    z[7,6,2]  R2652     2.3617684841156006e-01
    z[7,6,2]  R2653     5.2378600835800171e-01
    z[7,6,2]  R2654     5.5961215496063232e-01
    z[7,6,2]  R2655     5.8387947082519531e-01
    z[7,6,2]  R2656     1.4334578812122345e-01
    z[7,6,2]  R2657     9.1534264385700226e-02
    z[7,6,2]  R2658     2.4795642122626305e-02
    z[7,6,2]  R2659     -1.6446989774703979e-01
    z[7,6,2]  R2660     -3.1073245406150818e-01
    z[7,6,2]  R2661     -6.8830925226211548e-01
    z[7,6,2]  R2662     -3.5474994778633118e-01
    z[7,6,2]  R2663     -6.5949332714080811e-01
    z[7,6,2]  R2664     6.3296836614608765e-01
    z[7,6,2]  R2665     -5.7502470910549164e-02
    z[7,6,2]  R2666     -1.7588475719094276e-02
    z[7,6,2]  R2667     -1.5407618880271912e-01
    z[7,6,2]  R2668     -3.3088666200637817e-01
    z[7,6,2]  R2669     4.6474966220557690e-03
    z[7,6,2]  R2670     1.6201306879520416e-01
    z[7,6,2]  R2671     0.319915235042572
    z[7,6,2]  R2672     -2.0948900282382965e-01
    z[7,6,2]  R2673     -1.2064448557794094e-02
    z[7,6,2]  R2674     6.1238389462232590e-02
    z[7,6,2]  R2675     6.6069457679986954e-03
    z[7,6,2]  R2676     -1.0454404167830944e-02
    z[7,6,2]  R2677     4.7001782059669495e-01
    z[7,6,2]  R2678     4.0012022852897644e-01
    z[7,6,2]  R2679     2.1673339605331421e-01
    z[7,6,2]  R2680     3.2546713948249817e-01
    z[7,6,2]  R2681     3.2212135195732117e-01
    z[7,6,2]  R2682     2.7594748139381409e-01
    z[7,6,2]  R2683     -4.1854715347290039e-01
    z[7,6,2]  R2684     -1.7520034313201904e-01
    z[7,6,2]  R2685     -1.1685901880264282e-01
    z[7,6,2]  R2686     -1.6333484649658203e-01
    z[7,6,2]  R2687     -2.6785880327224731e-01
    z[7,6,2]  R2688     -1.8257641792297363e-01
    z[7,6,2]  R2689     -5.3789663314819336e-01
    z[7,6,2]  R2690     -1.7760933935642242e-01
    z[7,6,2]  R2691     -1.7945638298988342e-01
    z[7,6,2]  R2692     -3.8195076584815979e-01
    z[7,6,2]  R2693     -0.0339924618601799
    z[7,6,2]  R2694     2.8260305523872375e-01
    z[7,6,2]  R2695     7.1075963973999023e-01
    z[7,6,2]  R2696     6.8378818035125732e-01
    z[7,6,2]  R2697     5.4878199100494385e-01
    z[7,6,2]  R2698     4.9439480900764465e-01
    z[7,6,2]  R2699     6.2343740463256836e-01
    z[7,6,2]  R2700     5.0190275907516479e-01
    z[7,6,2]  R2701     4.8393711447715759e-01
    z[7,6,2]  R2702     3.8058194518089294e-01
    z[7,6,2]  R2703     4.3565174937248230e-01
    z[7,6,2]  R2704     3.2944139838218689e-01
    z[7,6,2]  R2705     -1.5970049798488617e-01
    z[7,6,2]  R2706     6.8351435661315918e-01
    z[7,6,2]  R2707     2.4656991660594940e-01
    z[7,6,2]  R2708     1.1712289601564407e-01
    z[7,6,2]  R2709     6.8361848592758179e-01
    z[7,6,2]  R2710     -1.3215051591396332e-01
    z[7,6,2]  R2711     -6.0098522901535034e-01
    z[7,6,2]  R2712     4.9145266413688660e-01
    z[7,6,2]  R2713     -0.706415057182312
    z[7,6,2]  R2714     3.1549575924873352e-01
    z[7,6,2]  R2715     3.8917210698127747e-01
    z[7,6,2]  R2716     4.1174092888832092e-01
    z[7,6,2]  R2717     3.1450986862182617e-01
    z[7,6,2]  R2718     4.2288318276405334e-02
    z[7,6,2]  R2719     6.3316076993942261e-01
    z[7,6,2]  R2720     2.1973705291748047e-01
    z[7,6,2]  R2721     -5.7728279381990433e-02
    z[7,6,2]  R2722     7.7076196670532227e-01
    z[7,6,2]  R2723     2.6455268263816833e-01
    z[7,6,2]  R2724     4.2389449477195740e-01
    z[7,6,2]  R2725     2.2439652681350708e-01
    z[7,6,2]  R2726     6.4922392368316650e-01
    z[7,6,2]  R2727     1.6333243250846863e-01
    z[7,6,2]  R2728     5.4032075405120850e-01
    z[7,6,2]  R2729     -1.8255543708801270e-01
    z[7,6,2]  R2730     3.0196553096175194e-02
    z[7,6,2]  R2731     0.215520977973938
    z[7,6,2]  R2732     -6.1001914739608765e-01
    z[7,6,2]  R2733     8.8725559413433075e-02
    z[7,6,2]  R2734     -2.3672574758529663e-01
    z[7,6,2]  R2735     2.5989213585853577e-01
    z[7,6,2]  R2736     1.6411387920379639e-01
    z[7,6,2]  R2737     2.8355222940444946e-01
    z[7,6,2]  R2738     9.0234234929084778e-02
    z[7,6,2]  R2739     -1.9573102891445160e-01
    z[7,6,2]  R2740     4.8574164509773254e-01
    z[7,6,2]  R2741     6.5591341257095337e-01
    z[7,6,2]  R2742     -3.4801873564720154e-01
    z[7,6,2]  R2743     -4.6952879428863525e-01
    z[7,6,2]  R2744     6.7564022541046143e-01
    z[7,6,2]  R2745     1.2817643582820892e-03
    z[7,6,2]  R2746     4.2216774821281433e-01
    z[7,6,2]  R2747     1.5791609883308411e-01
    z[7,6,2]  R2748     -7.6735556125640869e-01
    z[7,6,2]  R2749     2.5689122080802917e-01
    z[7,6,2]  R2750     0.395819753408432
    z[7,6,2]  R2751     2.0394693315029144e-01
    z[7,6,2]  R2752     -6.5956008434295654e-01
    z[7,6,2]  R2753     0.0963897705078125
    z[7,6,2]  R2754     2.1616187691688538e-01
    z[7,6,2]  R2755     3.8360023498535156e-01
    z[7,6,2]  R2756     0.522737979888916
    z[7,6,2]  R2757     -5.8665275573730469e-01
    z[7,6,2]  R2758     0.257693350315094
    z[7,6,2]  R2759     5.1851803064346313e-01
    z[7,6,2]  R2760     3.2036128640174866e-01
    z[7,6,2]  R2761     3.1420376896858215e-01
    z[7,6,2]  R2762     -4.5502316951751709e-01
    z[7,6,2]  R2763     -4.5573037862777710e-01
    z[7,6,2]  R2764     -6.1263483762741089e-01
    z[7,6,2]  R2765     3.7518495321273804e-01
    z[7,6,2]  R2766     4.6717628836631775e-01
    z[7,6,2]  R2767     2.9142412543296814e-01
    z[7,6,2]  R2768     3.8473892211914062e-01
    z[7,6,2]  R2769     4.9168238043785095e-01
    z[7,6,2]  R2770     -8.2693254947662354e-01
    z[7,6,2]  R2771     -3.9073020219802856e-01
    z[7,6,2]  R2772     -0.315792053937912
    z[7,6,2]  R2773     -1.5693803131580353e-01
    z[7,6,2]  R2774     -0.431908518075943
    z[7,6,2]  R2775     4.6711099147796631e-01
    z[7,6,2]  R2776     5.1746422052383423e-01
    z[7,6,2]  R2777     1.6701912879943848e-01
    z[7,6,2]  R2778     2.2287330031394958e-01
    z[7,6,2]  R2779     -6.4267307519912720e-01
    z[7,6,2]  R2780     -5.4743212461471558e-01
    z[7,6,2]  R2781     -5.9905093908309937e-01
    z[7,6,2]  R2782     3.9783951640129089e-01
    z[7,6,2]  R2783     5.3042483329772949e-01
    z[7,6,2]  R2784     6.0604417324066162e-01
    z[7,6,2]  R2785     1.0132411122322083e-01
    z[7,6,2]  R2786     2.7886566519737244e-01
    z[7,6,2]  R2787     -4.7770851850509644e-01
    z[7,6,2]  R2788     -3.4008646011352539e-01
    z[7,6,2]  R2789     3.9407119154930115e-01
    z[7,6,2]  R2790     4.1896224021911621e-01
    z[7,6,2]  R2791     5.4252862930297852e-01
    z[7,6,2]  R2792     5.3949481248855591e-01
    z[7,6,2]  R2793     3.8305473327636719e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2638     -1
    z[7,6,3]  R2639     1
    z[7,6,3]  R2646     8.2620793581008911e-01
    z[7,6,3]  R2647     -1.2785139679908752e-01
    z[7,6,3]  R2648     -3.4935075044631958e-01
    z[7,6,3]  R2649     -2.9280295968055725e-01
    z[7,6,3]  R2650     -2.8917145729064941e-01
    z[7,6,3]  R2651     -3.9025139808654785e-01
    z[7,6,3]  R2652     1.1600656062364578e-01
    z[7,6,3]  R2653     1.1536002904176712e-01
    z[7,6,3]  R2654     1.1884523183107376e-01
    z[7,6,3]  R2655     2.1242666244506836e-01
    z[7,6,3]  R2656     4.3413969874382019e-01
    z[7,6,3]  R2657     3.3604815602302551e-01
    z[7,6,3]  R2658     9.0555511415004730e-02
    z[7,6,3]  R2659     -1.8992717564105988e-01
    z[7,6,3]  R2660     1.6848176717758179e-01
    z[7,6,3]  R2661     -1.2528951466083527e-01
    z[7,6,3]  R2662     4.6882618218660355e-02
    z[7,6,3]  R2663     -1.0609063506126404e-01
    z[7,6,3]  R2664     -3.6784434318542480e-01
    z[7,6,3]  R2665     -2.0180073380470276e-01
    z[7,6,3]  R2666     -9.5994293689727783e-01
    z[7,6,3]  R2667     3.4489190578460693e-01
    z[7,6,3]  R2668     0.0662183165550232
    z[7,6,3]  R2669     5.9517048299312592e-02
    z[7,6,3]  R2670     3.3371126651763916e-01
    z[7,6,3]  R2671     3.9141643047332764e-01
    z[7,6,3]  R2672     2.3797918856143951e-01
    z[7,6,3]  R2673     2.6741623878479004e-01
    z[7,6,3]  R2674     3.1077753752470016e-02
    z[7,6,3]  R2675     -1.4447696506977081e-01
    z[7,6,3]  R2676     -3.1387850642204285e-01
    z[7,6,3]  R2677     3.9956855773925781e-01
    z[7,6,3]  R2678     1.7371344566345215e-01
    z[7,6,3]  R2679     3.0642119050025940e-01
    z[7,6,3]  R2680     3.9904779195785522e-01
    z[7,6,3]  R2681     4.9581699073314667e-02
    z[7,6,3]  R2682     5.8728528022766113e-01
    z[7,6,3]  R2683     -4.5279961079359055e-02
    z[7,6,3]  R2684     1.9722686707973480e-01
    z[7,6,3]  R2685     -1.7805849015712738e-01
    z[7,6,3]  R2686     -1.3938149809837341e-01
    z[7,6,3]  R2687     3.1448623538017273e-01
    z[7,6,3]  R2688     0.00422905758023262
    z[7,6,3]  R2689     3.0133891850709915e-02
    z[7,6,3]  R2690     -5.1916502416133881e-02
    z[7,6,3]  R2691     -4.8395209014415741e-02
    z[7,6,3]  R2692     -7.3296025395393372e-02
    z[7,6,3]  R2693     2.6381894946098328e-01
    z[7,6,3]  R2694     -3.9144456386566162e-01
    z[7,6,3]  R2695     2.1493844687938690e-01
    z[7,6,3]  R2696     -3.2905817031860352e-02
    z[7,6,3]  R2697     1.3282246887683868e-01
    z[7,6,3]  R2698     -4.2959639430046082e-01
    z[7,6,3]  R2699     -2.6216539740562439e-01
    z[7,6,3]  R2700     -1.5089030377566814e-02
    z[7,6,3]  R2701     2.9635429382324219e-01
    z[7,6,3]  R2702     -3.1604444980621338e-01
    z[7,6,3]  R2703     2.2651587426662445e-01
    z[7,6,3]  R2704     1.9076961278915405e-01
    z[7,6,3]  R2705     -1.6248348355293274e-01
    z[7,6,3]  R2706     -3.2762053608894348e-01
    z[7,6,3]  R2707     -9.8815739154815674e-02
    z[7,6,3]  R2708     4.4113656878471375e-01
    z[7,6,3]  R2709     1.8524500727653503e-01
    z[7,6,3]  R2710     2.6893270015716553e-01
    z[7,6,3]  R2711     -8.2504920661449432e-02
    z[7,6,3]  R2712     -3.0172142386436462e-01
    z[7,6,3]  R2713     2.6870843768119812e-01
    z[7,6,3]  R2714     2.9335431754589081e-02
    z[7,6,3]  R2715     1.2446004152297974e-01
    z[7,6,3]  R2716     -0.279773473739624
    z[7,6,3]  R2717     1.1687626689672470e-01
    z[7,6,3]  R2718     1.3141964375972748e-01
    z[7,6,3]  R2719     -3.0197307467460632e-01
    z[7,6,3]  R2720     -0.718078076839447
    z[7,6,3]  R2721     -2.2317622601985931e-01
    z[7,6,3]  R2722     -7.3442630469799042e-02
    z[7,6,3]  R2723     -1.9902646541595459e-01
    z[7,6,3]  R2724     -3.9294418692588806e-01
    z[7,6,3]  R2725     -1.0631754249334335e-01
    z[7,6,3]  R2726     8.6140096187591553e-02
    z[7,6,3]  R2727     -0.0592268705368042
    z[7,6,3]  R2728     1.1346279084682465e-01
    z[7,6,3]  R2729     5.5354988574981689e-01
    z[7,6,3]  R2730     -2.1806603670120239e-01
    z[7,6,3]  R2731     1.3416700065135956e-01
    z[7,6,3]  R2732     -4.5715585350990295e-01
    z[7,6,3]  R2733     -2.9148977249860764e-02
    z[7,6,3]  R2734     -2.1368084847927094e-01
    z[7,6,3]  R2735     -1.3163023628294468e-02
    z[7,6,3]  R2736     5.4514998197555542e-01
    z[7,6,3]  R2737     -1.0321961343288422e-01
    z[7,6,3]  R2738     5.3564912080764771e-01
    z[7,6,3]  R2739     2.9216277599334717e-01
    z[7,6,3]  R2740     3.0592599511146545e-01
    z[7,6,3]  R2741     1.5349418856203556e-02
    z[7,6,3]  R2742     -1.7554216086864471e-01
    z[7,6,3]  R2743     1.0113058984279633e-01
    z[7,6,3]  R2744     4.0966841578483582e-01
    z[7,6,3]  R2745     -3.4179797768592834e-01
    z[7,6,3]  R2746     -2.9593538492918015e-03
    z[7,6,3]  R2747     -1.8164904788136482e-02
    z[7,6,3]  R2748     -3.0162784457206726e-01
    z[7,6,3]  R2749     2.2983743250370026e-01
    z[7,6,3]  R2750     2.0392403006553650e-01
    z[7,6,3]  R2751     3.1509986519813538e-01
    z[7,6,3]  R2752     -4.8180431127548218e-01
    z[7,6,3]  R2753     4.9940237402915955e-01
    z[7,6,3]  R2754     0.303492933511734
    z[7,6,3]  R2755     0.298991322517395
    z[7,6,3]  R2756     -9.7847640514373779e-02
    z[7,6,3]  R2757     -3.3750689029693604e-01
    z[7,6,3]  R2758     3.1253427267074585e-01
    z[7,6,3]  R2759     1.9220243394374847e-01
    z[7,6,3]  R2760     1.3646423816680908e-01
    z[7,6,3]  R2761     -2.2059574723243713e-01
    z[7,6,3]  R2762     1.5589003264904022e-01
    z[7,6,3]  R2763     3.3723658323287964e-01
    z[7,6,3]  R2764     5.4800111800432205e-02
    z[7,6,3]  R2765     1.9486233592033386e-01
    z[7,6,3]  R2766     1.5734905004501343e-01
    z[7,6,3]  R2767     -6.4490497112274170e-02
    z[7,6,3]  R2768     -0.0396580696105957
    z[7,6,3]  R2769     6.9540542364120483e-01
    z[7,6,3]  R2770     7.5495615601539612e-02
    z[7,6,3]  R2771     3.2061886787414551e-01
    z[7,6,3]  R2772     4.6656790375709534e-01
    z[7,6,3]  R2773     0.474361777305603
    z[7,6,3]  R2774     -3.0580973625183105e-01
    z[7,6,3]  R2775     4.5167854428291321e-01
    z[7,6,3]  R2776     -3.4414285421371460e-01
    z[7,6,3]  R2777     2.4899591505527496e-01
    z[7,6,3]  R2778     -7.5129413604736328e-01
    z[7,6,3]  R2779     3.4967169165611267e-01
    z[7,6,3]  R2780     4.1893583536148071e-01
    z[7,6,3]  R2781     -2.6354610919952393e-01
    z[7,6,3]  R2782     1.5516200102865696e-02
    z[7,6,3]  R2783     1.0314907878637314e-01
    z[7,6,3]  R2784     -0.500938892364502
    z[7,6,3]  R2785     1.9754789769649506e-01
    z[7,6,3]  R2786     2.4601487815380096e-01
    z[7,6,3]  R2787     -6.2834209203720093e-01
    z[7,6,3]  R2788     9.7366660833358765e-02
    z[7,6,3]  R2789     2.8921690583229065e-01
    z[7,6,3]  R2790     1.8290439248085022e-01
    z[7,6,3]  R2791     1.8155736848711967e-02
    z[7,6,3]  R2792     -1.2649394571781158e-01
    z[7,6,3]  R2793     -3.0813655257225037e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2640     -1
    z[7,6,4]  R2641     1
    z[7,6,4]  R2646     -3.1051984429359436e-01
    z[7,6,4]  R2647     6.0188418626785278e-01
    z[7,6,4]  R2648     -1.4745886623859406e-01
    z[7,6,4]  R2649     -4.6099311113357544e-01
    z[7,6,4]  R2650     6.8539303541183472e-01
    z[7,6,4]  R2651     1.8325036764144897e-01
    z[7,6,4]  R2652     6.8210393190383911e-01
    z[7,6,4]  R2653     -2.5741992518305779e-02
    z[7,6,4]  R2654     1.1290936172008514e-01
    z[7,6,4]  R2655     -0.592860758304596
    z[7,6,4]  R2656     2.8637340664863586e-01
    z[7,6,4]  R2657     1.8847092986106873e-01
    z[7,6,4]  R2658     -5.0618678331375122e-01
    z[7,6,4]  R2659     -5.3477054834365845e-01
    z[7,6,4]  R2660     2.1060076355934143e-01
    z[7,6,4]  R2661     7.1448874659836292e-03
    z[7,6,4]  R2662     -3.9999313652515411e-02
    z[7,6,4]  R2663     3.6102943122386932e-02
    z[7,6,4]  R2664     1.8114270269870758e-01
    z[7,6,4]  R2665     2.2137662768363953e-01
    z[7,6,4]  R2666     -1.6119654476642609e-01
    z[7,6,4]  R2667     7.2562344372272491e-02
    z[7,6,4]  R2668     7.1863633394241333e-01
    z[7,6,4]  R2669     1.9115528464317322e-01
    z[7,6,4]  R2670     5.5096572637557983e-01
    z[7,6,4]  R2671     -4.3163388967514038e-01
    z[7,6,4]  R2672     -1.8582014739513397e-01
    z[7,6,4]  R2673     -4.3526330590248108e-01
    z[7,6,4]  R2674     9.7522474825382233e-02
    z[7,6,4]  R2675     -0.558796226978302
    z[7,6,4]  R2676     -3.6174062639474869e-02
    z[7,6,4]  R2677     3.4133863449096680e-01
    z[7,6,4]  R2678     2.3872828111052513e-02
    z[7,6,4]  R2679     -1.8965993821620941e-01
    z[7,6,4]  R2680     3.4512110054492950e-02
    z[7,6,4]  R2681     2.4022670090198517e-01
    z[7,6,4]  R2682     9.3611087650060654e-03
    z[7,6,4]  R2683     1.6803732514381409e-01
    z[7,6,4]  R2684     2.5442723184823990e-02
    z[7,6,4]  R2685     1.5681026875972748e-01
    z[7,6,4]  R2686     9.9835090339183807e-02
    z[7,6,4]  R2687     2.4434188008308411e-01
    z[7,6,4]  R2688     -3.4472875297069550e-02
    z[7,6,4]  R2689     3.6078128218650818e-01
    z[7,6,4]  R2690     2.0710060000419617e-01
    z[7,6,4]  R2691     4.5984137803316116e-02
    z[7,6,4]  R2692     2.6967635750770569e-01
    z[7,6,4]  R2693     3.3857962489128113e-01
    z[7,6,4]  R2694     1.8772387504577637e-01
    z[7,6,4]  R2695     -6.4913578331470490e-02
    z[7,6,4]  R2696     3.2985430955886841e-01
    z[7,6,4]  R2697     3.9232546091079712e-01
    z[7,6,4]  R2698     3.3945900201797485e-01
    z[7,6,4]  R2699     1.2313283234834671e-01
    z[7,6,4]  R2700     -4.2394474148750305e-01
    z[7,6,4]  R2701     3.2723551988601685e-01
    z[7,6,4]  R2702     5.8565360307693481e-01
    z[7,6,4]  R2703     2.8684270381927490e-01
    z[7,6,4]  R2704     -3.7396547198295593e-01
    z[7,6,4]  R2705     -1.7767411470413208e-01
    z[7,6,4]  R2706     2.1423611044883728e-01
    z[7,6,4]  R2707     4.1241145133972168e-01
    z[7,6,4]  R2708     -8.4720002487301826e-03
    z[7,6,4]  R2709     -2.1629419177770615e-02
    z[7,6,4]  R2710     -5.6049692630767822e-01
    z[7,6,4]  R2711     -4.1762074828147888e-01
    z[7,6,4]  R2712     -0.309527724981308
    z[7,6,4]  R2713     -1.8898989260196686e-01
    z[7,6,4]  R2714     -4.7102957963943481e-01
    z[7,6,4]  R2715     1.1562176048755646e-01
    z[7,6,4]  R2716     3.6604840308427811e-02
    z[7,6,4]  R2717     4.4977459311485291e-01
    z[7,6,4]  R2718     3.2556807994842529e-01
    z[7,6,4]  R2719     -3.6292336881160736e-02
    z[7,6,4]  R2720     2.5714278221130371e-02
    z[7,6,4]  R2721     -3.8738265633583069e-01
    z[7,6,4]  R2722     2.2139152884483337e-01
    z[7,6,4]  R2723     -3.5999670624732971e-01
    z[7,6,4]  R2724     -1.6703774034976959e-01
    z[7,6,4]  R2725     6.3023701310157776e-02
    z[7,6,4]  R2726     -3.0715823173522949e-02
    z[7,6,4]  R2727     -3.0421710014343262e-01
    z[7,6,4]  R2728     2.1932624280452728e-01
    z[7,6,4]  R2729     -1.7460497096180916e-02
    z[7,6,4]  R2730     4.3190225958824158e-01
    z[7,6,4]  R2731     0.67954021692276
    z[7,6,4]  R2732     -4.0179529786109924e-01
    z[7,6,4]  R2733     -1.0678673535585403e-01
    z[7,6,4]  R2734     2.9650720953941345e-01
    z[7,6,4]  R2735     -3.4526339173316956e-01
    z[7,6,4]  R2736     -1.7809841036796570e-01
    z[7,6,4]  R2737     6.9740664958953857e-01
    z[7,6,4]  R2738     3.9971670508384705e-01
    z[7,6,4]  R2739     -1.9026480615139008e-01
    z[7,6,4]  R2740     -1.3448676466941833e-01
    z[7,6,4]  R2741     -2.5099346041679382e-01
    z[7,6,4]  R2742     -3.4589907526969910e-01
    z[7,6,4]  R2743     -6.4240492880344391e-02
    z[7,6,4]  R2744     -8.8118426501750946e-02
    z[7,6,4]  R2745     4.5130811631679535e-02
    z[7,6,4]  R2746     -7.5812175869941711e-02
    z[7,6,4]  R2747     4.6922618150711060e-01
    z[7,6,4]  R2748     -2.1081276237964630e-01
    z[7,6,4]  R2749     -5.4514068365097046e-01
    z[7,6,4]  R2750     3.0137148499488831e-01
    z[7,6,4]  R2751     2.5732040405273438e-01
    z[7,6,4]  R2752     -2.0544733107089996e-01
    z[7,6,4]  R2753     4.3823051452636719e-01
    z[7,6,4]  R2754     1.1673387885093689e-01
    z[7,6,4]  R2755     -4.8256742954254150e-01
    z[7,6,4]  R2756     2.4360392987728119e-01
    z[7,6,4]  R2757     -3.2086694240570068e-01
    z[7,6,4]  R2758     4.6117997169494629e-01
    z[7,6,4]  R2759     3.9515700936317444e-01
    z[7,6,4]  R2760     4.5218691229820251e-02
    z[7,6,4]  R2761     -1.8601721525192261e-01
    z[7,6,4]  R2762     -3.0061137676239014e-01
    z[7,6,4]  R2763     1.4628148078918457e-01
    z[7,6,4]  R2764     -4.4163670390844345e-02
    z[7,6,4]  R2765     2.9067862033843994e-01
    z[7,6,4]  R2766     -4.5216238498687744e-01
    z[7,6,4]  R2767     -0.154743030667305
    z[7,6,4]  R2768     -2.7844479680061340e-01
    z[7,6,4]  R2769     -1.9415840506553650e-01
    z[7,6,4]  R2770     1.0383749753236771e-01
    z[7,6,4]  R2771     1.2211102247238159e-01
    z[7,6,4]  R2772     -2.6020416617393494e-01
    z[7,6,4]  R2773     -5.8943405747413635e-02
    z[7,6,4]  R2774     -3.0825346708297729e-01
    z[7,6,4]  R2775     3.0930081382393837e-02
    z[7,6,4]  R2776     -1.2759761512279510e-01
    z[7,6,4]  R2777     -6.0336075723171234e-02
    z[7,6,4]  R2778     1.0239310562610626e-01
    z[7,6,4]  R2779     -8.9971348643302917e-03
    z[7,6,4]  R2780     -2.2755637764930725e-03
    z[7,6,4]  R2781     -2.7343245223164558e-02
    z[7,6,4]  R2782     2.0597030222415924e-01
    z[7,6,4]  R2783     -1.0387220233678818e-01
    z[7,6,4]  R2784     2.8337278962135315e-01
    z[7,6,4]  R2785     1.1322257667779922e-01
    z[7,6,4]  R2786     2.7698168158531189e-01
    z[7,6,4]  R2787     -5.7650644332170486e-02
    z[7,6,4]  R2788     -7.6792903244495392e-02
    z[7,6,4]  R2789     -6.1464175581932068e-02
    z[7,6,4]  R2790     -2.8007525205612183e-01
    z[7,6,4]  R2791     -1.7160907387733459e-01
    z[7,6,4]  R2792     -1.3729830272495747e-02
    z[7,6,4]  R2793     -1.3171419501304626e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2642     -1
    z[7,6,5]  R2643     1
    z[7,6,5]  R2646     -1.9773536920547485e-01
    z[7,6,5]  R2647     -4.3851515650749207e-01
    z[7,6,5]  R2648     -2.9622310400009155e-01
    z[7,6,5]  R2649     -0.588651180267334
    z[7,6,5]  R2650     4.7824871540069580e-01
    z[7,6,5]  R2651     2.8403592109680176e-01
    z[7,6,5]  R2652     -1.5754656493663788e-01
    z[7,6,5]  R2653     -2.9139408469200134e-01
    z[7,6,5]  R2654     2.2504577040672302e-01
    z[7,6,5]  R2655     -0.0945129320025444
    z[7,6,5]  R2656     2.0391296595335007e-02
    z[7,6,5]  R2657     5.7642799615859985e-01
    z[7,6,5]  R2658     4.6518808603286743e-01
    z[7,6,5]  R2659     2.3237279057502747e-01
    z[7,6,5]  R2660     -5.5580466985702515e-01
    z[7,6,5]  R2661     0.0278362687677145
    z[7,6,5]  R2662     2.2809931635856628e-01
    z[7,6,5]  R2663     2.1465249359607697e-01
    z[7,6,5]  R2664     -4.1360697150230408e-01
    z[7,6,5]  R2665     2.0990513265132904e-01
    z[7,6,5]  R2666     7.3872774839401245e-02
    z[7,6,5]  R2667     9.8390288650989532e-02
    z[7,6,5]  R2668     -3.4756880998611450e-01
    z[7,6,5]  R2669     -7.5938858091831207e-02
    z[7,6,5]  R2670     9.4430379569530487e-02
    z[7,6,5]  R2671     4.3317312002182007e-01
    z[7,6,5]  R2672     -4.4979268312454224e-01
    z[7,6,5]  R2673     4.5299929380416870e-01
    z[7,6,5]  R2674     -9.2040526866912842e-01
    z[7,6,5]  R2675     -3.4115061163902283e-01
    z[7,6,5]  R2676     4.6103116869926453e-01
    z[7,6,5]  R2677     -2.2435872256755829e-01
    z[7,6,5]  R2678     1.6398425941588357e-05
    z[7,6,5]  R2679     -3.3011871576309204e-01
    z[7,6,5]  R2680     2.0022456347942352e-01
    z[7,6,5]  R2681     2.5162905454635620e-02
    z[7,6,5]  R2682     5.9163635969161987e-01
    z[7,6,5]  R2683     2.0850417017936707e-01
    z[7,6,5]  R2684     1.8363554030656815e-02
    z[7,6,5]  R2685     -9.5805518329143524e-02
    z[7,6,5]  R2686     1.2756167352199554e-01
    z[7,6,5]  R2687     -5.5215455591678619e-02
    z[7,6,5]  R2688     1.4253821969032288e-01
    z[7,6,5]  R2689     1.5330988168716431e-01
    z[7,6,5]  R2690     -1.7740002274513245e-01
    z[7,6,5]  R2691     6.8646006286144257e-02
    z[7,6,5]  R2692     9.1301478445529938e-02
    z[7,6,5]  R2693     1.0748646408319473e-01
    z[7,6,5]  R2694     -6.3528245687484741e-01
    z[7,6,5]  R2695     -5.5146205425262451e-01
    z[7,6,5]  R2696     -1.5791727602481842e-01
    z[7,6,5]  R2697     1.1527353525161743e-01
    z[7,6,5]  R2698     -1.3519582152366638e-01
    z[7,6,5]  R2699     -4.2881774902343750e-01
    z[7,6,5]  R2700     -6.6672730445861816e-01
    z[7,6,5]  R2701     -3.4675487875938416e-01
    z[7,6,5]  R2702     -3.6504715681076050e-01
    z[7,6,5]  R2703     -6.0960131883621216e-01
    z[7,6,5]  R2704     -1.7386928200721741e-01
    z[7,6,5]  R2705     6.6571027040481567e-02
    z[7,6,5]  R2706     8.7013505399227142e-02
    z[7,6,5]  R2707     2.4824562668800354e-01
    z[7,6,5]  R2708     3.5148376226425171e-01
    z[7,6,5]  R2709     2.2151772677898407e-01
    z[7,6,5]  R2710     1.1689832806587219e-01
    z[7,6,5]  R2711     2.1122368052601814e-02
    z[7,6,5]  R2712     4.5777830481529236e-01
    z[7,6,5]  R2713     1.2328056618571281e-02
    z[7,6,5]  R2714     -0.448505699634552
    z[7,6,5]  R2715     -3.6816036701202393e-01
    z[7,6,5]  R2716     2.8279694914817810e-01
    z[7,6,5]  R2717     -5.4161384701728821e-02
    z[7,6,5]  R2718     1.2324440479278564e-01
    z[7,6,5]  R2719     -1.0633645206689835e-01
    z[7,6,5]  R2720     2.5598341599106789e-02
    z[7,6,5]  R2721     -2.3073397576808929e-02
    z[7,6,5]  R2722     -1.0603081434965134e-01
    z[7,6,5]  R2723     -6.0287380218505859e-01
    z[7,6,5]  R2724     -2.1796286106109619e-01
    z[7,6,5]  R2725     -1.5515540540218353e-01
    z[7,6,5]  R2726     -3.2942584156990051e-01
    z[7,6,5]  R2727     -2.4291633069515228e-01
    z[7,6,5]  R2728     -0.422921746969223
    z[7,6,5]  R2729     -4.3859258294105530e-01
    z[7,6,5]  R2730     -1.4036697149276733e-01
    z[7,6,5]  R2731     -1.4414627850055695e-01
    z[7,6,5]  R2732     -2.9180753231048584e-01
    z[7,6,5]  R2733     0.622606098651886
    z[7,6,5]  R2734     2.4356535077095032e-01
    z[7,6,5]  R2735     -3.0759337544441223e-01
    z[7,6,5]  R2736     -2.7960723638534546e-01
    z[7,6,5]  R2737     -0.421384334564209
    z[7,6,5]  R2738     -5.0109249353408813e-01
    z[7,6,5]  R2739     -6.7544782161712646e-01
    z[7,6,5]  R2740     5.5559748411178589e-01
    z[7,6,5]  R2741     3.2968875765800476e-01
    z[7,6,5]  R2742     4.8926264047622681e-02
    z[7,6,5]  R2743     1.0916931927204132e-01
    z[7,6,5]  R2744     -2.5254514813423157e-01
    z[7,6,5]  R2745     -6.4476072788238525e-01
    z[7,6,5]  R2746     3.6030894517898560e-01
    z[7,6,5]  R2747     -4.0189573168754578e-01
    z[7,6,5]  R2748     -2.4131463468074799e-01
    z[7,6,5]  R2749     -2.2471027076244354e-01
    z[7,6,5]  R2750     0.314242959022522
    z[7,6,5]  R2751     -3.2006821036338806e-01
    z[7,6,5]  R2752     -3.0427744984626770e-01
    z[7,6,5]  R2753     1.2288712710142136e-01
    z[7,6,5]  R2754     9.0067885816097260e-02
    z[7,6,5]  R2755     -4.1855999827384949e-01
    z[7,6,5]  R2756     -5.1251932978630066e-02
    z[7,6,5]  R2757     -3.1081253290176392e-01
    z[7,6,5]  R2758     -4.3841204047203064e-01
    z[7,6,5]  R2759     -4.6696880459785461e-01
    z[7,6,5]  R2760     -7.8776758909225464e-01
    z[7,6,5]  R2761     -0.0409141406416893
    z[7,6,5]  R2762     -4.1150298714637756e-01
    z[7,6,5]  R2763     -4.4737223535776138e-02
    z[7,6,5]  R2764     -2.4522005021572113e-01
    z[7,6,5]  R2765     -4.9179011583328247e-01
    z[7,6,5]  R2766     -4.9940440058708191e-01
    z[7,6,5]  R2767     -7.4444037675857544e-01
    z[7,6,5]  R2768     1.4940799772739410e-01
    z[7,6,5]  R2769     2.4619838595390320e-01
    z[7,6,5]  R2770     -1.0064287483692169e-01
    z[7,6,5]  R2771     4.2561632394790649e-01
    z[7,6,5]  R2772     9.8149076104164124e-02
    z[7,6,5]  R2773     1.9988100230693817e-01
    z[7,6,5]  R2774     -2.0188757777214050e-01
    z[7,6,5]  R2775     1.4005610346794128e-01
    z[7,6,5]  R2776     -0.479707807302475
    z[7,6,5]  R2777     -8.0626225471496582e-01
    z[7,6,5]  R2778     -1.2126793712377548e-01
    z[7,6,5]  R2779     1.4181299507617950e-01
    z[7,6,5]  R2780     1.1308369040489197e-01
    z[7,6,5]  R2781     4.5485013723373413e-01
    z[7,6,5]  R2782     -2.9244298115372658e-02
    z[7,6,5]  R2783     1.4941900968551636e-01
    z[7,6,5]  R2784     -2.0874448120594025e-01
    z[7,6,5]  R2785     -7.2684699296951294e-01
    z[7,6,5]  R2786     -3.9484921097755432e-01
    z[7,6,5]  R2787     -1.2284660339355469e-01
    z[7,6,5]  R2788     1.7613308131694794e-01
    z[7,6,5]  R2789     -1.5199208259582520e-01
    z[7,6,5]  R2790     -0.0385298952460289
    z[7,6,5]  R2791     -3.2177552580833435e-02
    z[7,6,5]  R2792     -2.9607942700386047e-01
    z[7,6,5]  R2793     -3.6532118916511536e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2644     -1
    z[7,6,6]  R2645     1
    z[7,6,6]  R2646     8.5967361927032471e-02
    z[7,6,6]  R2647     4.3267118930816650e-01
    z[7,6,6]  R2648     2.2212950885295868e-01
    z[7,6,6]  R2649     -4.0958082675933838e-01
    z[7,6,6]  R2650     2.1534173190593719e-01
    z[7,6,6]  R2651     0.585595428943634
    z[7,6,6]  R2652     -1.3694108463823795e-02
    z[7,6,6]  R2653     2.0154589414596558e-01
    z[7,6,6]  R2654     3.4045910835266113e-01
    z[7,6,6]  R2655     -3.1847360730171204e-01
    z[7,6,6]  R2656     -6.3530862331390381e-01
    z[7,6,6]  R2657     -4.7465628385543823e-01
    z[7,6,6]  R2658     -3.5176226496696472e-01
    z[7,6,6]  R2659     3.6010544747114182e-02
    z[7,6,6]  R2660     -1.1052598804235458e-01
    z[7,6,6]  R2661     -1.0917614400386810e-01
    z[7,6,6]  R2662     -3.6055833101272583e-01
    z[7,6,6]  R2663     4.4140985608100891e-01
    z[7,6,6]  R2664     -1.8599297106266022e-01
    z[7,6,6]  R2665     3.2376810908317566e-01
    z[7,6,6]  R2666     4.6240020543336868e-02
    z[7,6,6]  R2667     3.2740023732185364e-01
    z[7,6,6]  R2668     -1.5350070595741272e-01
    z[7,6,6]  R2669     9.4344235956668854e-02
    z[7,6,6]  R2670     2.6627802848815918e-01
    z[7,6,6]  R2671     -2.5836843252182007e-01
    z[7,6,6]  R2672     -1.9068348407745361e-01
    z[7,6,6]  R2673     2.1036484837532043e-01
    z[7,6,6]  R2674     1.6790562868118286e-01
    z[7,6,6]  R2675     -6.6682326793670654e-01
    z[7,6,6]  R2676     -6.6632938385009766e-01
    z[7,6,6]  R2677     -1.1788893491029739e-02
    z[7,6,6]  R2678     -1.4518619515001774e-02
    z[7,6,6]  R2679     -1.3808824121952057e-01
    z[7,6,6]  R2680     -8.0798274278640747e-01
    z[7,6,6]  R2681     0.318573534488678
    z[7,6,6]  R2682     -2.6231896877288818e-01
    z[7,6,6]  R2683     7.5478866696357727e-02
    z[7,6,6]  R2684     -1.1770492047071457e-01
    z[7,6,6]  R2685     -4.4261552393436432e-03
    z[7,6,6]  R2686     -1.6064360737800598e-01
    z[7,6,6]  R2687     -1.6098898649215698e-01
    z[7,6,6]  R2688     -0.301470011472702
    z[7,6,6]  R2689     1.6815978288650513e-01
    z[7,6,6]  R2690     -1.2203180789947510e-01
    z[7,6,6]  R2691     1.4321976900100708e-01
    z[7,6,6]  R2692     -1.0164518840610981e-02
    z[7,6,6]  R2693     2.7247878909111023e-01
    z[7,6,6]  R2694     1.8773525953292847e-01
    z[7,6,6]  R2695     -2.3031197488307953e-01
    z[7,6,6]  R2696     3.7443738430738449e-02
    z[7,6,6]  R2697     -5.8671992272138596e-02
    z[7,6,6]  R2698     -4.4896829128265381e-01
    z[7,6,6]  R2699     0.0770488902926445
    z[7,6,6]  R2700     -2.5659623742103577e-01
    z[7,6,6]  R2701     -7.1774378418922424e-02
    z[7,6,6]  R2702     3.3430272340774536e-01
    z[7,6,6]  R2703     2.6974827051162720e-02
    z[7,6,6]  R2704     -6.8659879267215729e-02
    z[7,6,6]  R2705     8.4615841507911682e-02
    z[7,6,6]  R2706     9.7019389271736145e-02
    z[7,6,6]  R2707     3.8433033227920532e-01
    z[7,6,6]  R2708     -6.3249057531356812e-01
    z[7,6,6]  R2709     -2.1371269226074219e-01
    z[7,6,6]  R2710     -4.1133394837379456e-01
    z[7,6,6]  R2711     -0.0805663913488388
    z[7,6,6]  R2712     1.8261478841304779e-01
    z[7,6,6]  R2713     -2.9590731486678123e-02
    z[7,6,6]  R2714     -9.6845522522926331e-02
    z[7,6,6]  R2715     2.0080134272575378e-01
    z[7,6,6]  R2716     -2.0039488375186920e-01
    z[7,6,6]  R2717     3.6406585574150085e-01
    z[7,6,6]  R2718     -2.0754756033420563e-01
    z[7,6,6]  R2719     0.0768914446234703
    z[7,6,6]  R2720     1.9086304306983948e-01
    z[7,6,6]  R2721     2.0770902931690216e-01
    z[7,6,6]  R2722     4.1985239833593369e-02
    z[7,6,6]  R2723     -2.1316848695278168e-01
    z[7,6,6]  R2724     -7.0847973227500916e-02
    z[7,6,6]  R2725     1.4123211801052094e-01
    z[7,6,6]  R2726     -7.8969992697238922e-02
    z[7,6,6]  R2727     -1.1099644750356674e-01
    z[7,6,6]  R2728     -1.9904676079750061e-01
    z[7,6,6]  R2729     -2.7316769957542419e-01
    z[7,6,6]  R2730     3.7511962652206421e-01
    z[7,6,6]  R2731     -2.7071639895439148e-01
    z[7,6,6]  R2732     0.0816039890050888
    z[7,6,6]  R2733     1.1319984495639801e-01
    z[7,6,6]  R2734     2.7768164873123169e-01
    z[7,6,6]  R2735     6.2627747654914856e-02
    z[7,6,6]  R2736     -0.0424545481801033
    z[7,6,6]  R2737     -4.8246022313833237e-02
    z[7,6,6]  R2738     -1.7423997819423676e-01
    z[7,6,6]  R2739     -2.3064975440502167e-01
    z[7,6,6]  R2740     -2.5198507308959961e-01
    z[7,6,6]  R2741     -2.8632849454879761e-01
    z[7,6,6]  R2742     -1.7734473943710327e-01
    z[7,6,6]  R2743     0.0823395624756813
    z[7,6,6]  R2744     -2.5365290045738220e-01
    z[7,6,6]  R2745     5.3452465683221817e-02
    z[7,6,6]  R2746     1.7981614917516708e-02
    z[7,6,6]  R2747     8.4437653422355652e-02
    z[7,6,6]  R2748     1.7719270288944244e-01
    z[7,6,6]  R2749     -4.9363183975219727e-01
    z[7,6,6]  R2750     1.7795109748840332e-01
    z[7,6,6]  R2751     -6.2378573417663574e-01
    z[7,6,6]  R2752     -2.1367833018302917e-01
    z[7,6,6]  R2753     1.7445491254329681e-01
    z[7,6,6]  R2754     1.5673954784870148e-01
    z[7,6,6]  R2755     -0.282549113035202
    z[7,6,6]  R2756     -9.0264402329921722e-02
    z[7,6,6]  R2757     2.8157643973827362e-03
    z[7,6,6]  R2758     -6.1274436302483082e-03
    z[7,6,6]  R2759     2.0600537955760956e-01
    z[7,6,6]  R2760     1.3947731256484985e-01
    z[7,6,6]  R2761     1.3983491063117981e-01
    z[7,6,6]  R2762     -2.2028565406799316e-01
    z[7,6,6]  R2763     1.3029728829860687e-01
    z[7,6,6]  R2764     -2.9339674860239029e-02
    z[7,6,6]  R2765     -1.4245378971099854e-01
    z[7,6,6]  R2766     -0.257985919713974
    z[7,6,6]  R2767     -2.4304588139057159e-01
    z[7,6,6]  R2768     -5.2570408582687378e-01
    z[7,6,6]  R2769     3.2696448266506195e-02
    z[7,6,6]  R2770     -3.7743654102087021e-02
    z[7,6,6]  R2771     -0.148038849234581
    z[7,6,6]  R2772     -2.4738231301307678e-01
    z[7,6,6]  R2773     -2.0432794094085693e-01
    z[7,6,6]  R2774     -1.5077529847621918e-01
    z[7,6,6]  R2775     -1.4350248873233795e-01
    z[7,6,6]  R2776     1.1306065320968628e-01
    z[7,6,6]  R2777     1.0979101061820984e-01
    z[7,6,6]  R2778     3.0902945995330811e-01
    z[7,6,6]  R2779     0.0984988585114479
    z[7,6,6]  R2780     -3.4991574287414551e-01
    z[7,6,6]  R2781     -1.4413505792617798e-01
    z[7,6,6]  R2782     2.2152608260512352e-02
    z[7,6,6]  R2783     -7.0057488977909088e-02
    z[7,6,6]  R2784     1.2082371860742569e-01
    z[7,6,6]  R2785     7.4731156229972839e-02
    z[7,6,6]  R2786     0.2565937936306
    z[7,6,6]  R2787     2.3028762638568878e-01
    z[7,6,6]  R2788     -2.3457955569028854e-02
    z[7,6,6]  R2789     1.1988984793424606e-01
    z[7,6,6]  R2790     1.9500355422496796e-01
    z[7,6,6]  R2791     5.0898820161819458e-01
    z[7,6,6]  R2792     4.6658405661582947e-01
    z[7,6,6]  R2793     1.8439665436744690e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,3]
 BV BND1      phi[3,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,9]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[8,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,3,0]
 FR BND1      z[1,3,1]
 FR BND1      z[1,3,2]
 FR BND1      z[1,3,3]
 FR BND1      z[1,3,4]
 FR BND1      z[1,3,5]
 FR BND1      z[1,3,6]
 FR BND1      z[3,1,0]
 FR BND1      z[3,1,1]
 FR BND1      z[3,1,2]
 FR BND1      z[3,1,3]
 FR BND1      z[3,1,4]
 FR BND1      z[3,1,5]
 FR BND1      z[3,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
