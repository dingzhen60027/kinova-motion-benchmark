NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 L  R91     
 E  R92     
 E  R93     
 E  R94     
 E  R95     
 E  R96     
 E  R97     
 E  R98     
 E  R99     
 E  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
 L  qc10    
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -3.0999999046325684e+00
    phi[0,1]  R103      -2.2400000095367432e+00
    phi[0,1]  R104      -2.2400000095367432e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      -3.0999999046325684e+00
    phi[0,1]  R107      -2.5699999332427979e+00
    phi[0,1]  R108      -2.5699999332427979e+00
    phi[0,1]  R109      -3.0999999046325684e+00
    phi[0,1]  R110      -3.0999999046325684e+00
    phi[0,1]  R111      -2.0899999141693115e+00
    phi[0,1]  R112      -2.0899999141693115e+00
    phi[0,1]  R113      -3.0999999046325684e+00
    phi[0,1]  R114      -3.0999999046325684e+00
    phi[0,1]  R115      -2.1948951482772827e-01
    phi[0,1]  R116      3.8127106428146362e-01
    phi[0,1]  R117      4.5087870955467224e-01
    phi[0,1]  R118      8.4535408020019531e-01
    phi[0,1]  R119      -1.0518914461135864e+00
    phi[0,1]  R120      -1.4924558997154236e-01
    phi[0,1]  R121      -0.811653196811676
    phi[0,1]  R122      -9.6806889772415161e-01
    phi[0,1]  R123      -4.3553823232650757e-01
    phi[0,1]  R124      2.2030051052570343e-01
    phi[0,1]  R125      -1.1702115535736084e+00
    phi[0,1]  R126      -1.2668842077255249e+00
    phi[0,1]  R127      -2.1376707553863525e+00
    phi[0,1]  R128      -1.8195823431015015e+00
    phi[0,1]  R129      -2.7108309268951416e+00
    phi[0,1]  R130      -1.7746373414993286e+00
    phi[0,1]  R131      -1.5230154991149902e+00
    phi[0,1]  R132      -1.7706049680709839e+00
    phi[0,1]  R133      -1.4631687402725220e+00
    phi[0,1]  R134      -1.4899804592132568e+00
    phi[0,1]  R135      -1.3121581077575684e+00
    phi[0,1]  R136      -5.6514465808868408e-01
    phi[0,1]  R137      -1.4165538549423218e+00
    phi[0,1]  R138      -1.3899122476577759e+00
    phi[0,1]  R139      -1.3972704410552979e+00
    phi[0,1]  R140      -1.3021285533905029e+00
    phi[0,1]  R141      -8.7903779745101929e-01
    phi[0,1]  R142      -1.6624507904052734e+00
    phi[0,1]  R143      -2.2197632789611816e+00
    phi[0,1]  R144      -1.8832582235336304e+00
    phi[0,1]  R145      -1.1975284814834595e+00
    phi[0,1]  R146      3.4225676208734512e-02
    phi[0,1]  R147      -8.4309369325637817e-01
    phi[0,1]  R148      -1.6528390645980835e+00
    phi[0,1]  R149      -3.0537894368171692e-01
    phi[0,1]  R150      -9.0089541673660278e-01
    phi[0,1]  R151      -1.3017466068267822e+00
    phi[0,1]  R152      -1.3003400564193726e+00
    phi[0,1]  R153      -1.9370923042297363e+00
    phi[0,1]  R154      -1.8130618333816528e+00
    phi[0,1]  R155      -1.2519774436950684e+00
    phi[0,1]  R156      -6.0285472869873047e-01
    phi[0,1]  R157      -2.7024433016777039e-01
    phi[0,1]  R158      -2.9015231132507324e-01
    phi[0,1]  R159      -1.0284395217895508e+00
    phi[0,1]  R160      -1.3257403373718262e+00
    phi[0,1]  R161      -1.6234004497528076e+00
    phi[0,1]  R162      -1.6399219036102295e+00
    phi[0,1]  R163      -1.0824191570281982e+00
    phi[0,1]  R164      -5.2295017242431641e-01
    phi[0,1]  R165      -5.4910612106323242e-01
    phi[0,1]  R166      -7.2183507680892944e-01
    phi[0,1]  R167      -1.3820582628250122e+00
    phi[0,1]  R168      -1.2896230220794678e+00
    phi[0,1]  R169      -1.3335368633270264e+00
    phi[0,1]  R170      -2.9823825359344482e+00
    phi[0,1]  R171      -2.5500571727752686e+00
    phi[0,1]  R172      -2.08294677734375
    phi[0,1]  R173      -2.0980064868927
    phi[0,1]  R174      -2.7004737854003906e+00
    phi[0,1]  R175      0.998393177986145
    phi[0,1]  R176      1.5726968050003052e+00
    phi[0,1]  R177      1.3959608078002930e+00
    phi[0,1]  R178      1.4580178260803223e+00
    phi[0,1]  R179      1.4834202527999878e+00
    phi[0,1]  R180      2.3353576660156250e+00
    phi[0,1]  R181      1.6139698028564453e+00
    phi[0,1]  R182      -8.1244844198226929e-01
    phi[0,1]  R183      -7.1971946954727173e-01
    phi[0,1]  R184      -8.6621528863906860e-01
    phi[0,1]  R185      -2.8808181285858154e+00
    phi[0,1]  R186      -2.4075033664703369e+00
    phi[0,1]  R187      -2.2332315444946289e+00
    phi[0,1]  R188      -2.8296663761138916e+00
    phi[0,1]  R189      2.5750610232353210e-01
    phi[0,1]  R190      2.9572030901908875e-01
    phi[0,1]  R191      -1.4443837404251099e+00
    phi[0,1]  R192      -2.0776166915893555e+00
    phi[0,1]  R193      -1.6136032342910767e+00
    phi[0,1]  R194      -1.5708523988723755e+00
    phi[0,1]  R195      -2.4225173890590668e-01
    phi[0,1]  R196      1.6645736992359161e-01
    phi[0,1]  R197      -5.3139519691467285e-01
    phi[0,1]  R198      -8.6472785472869873e-01
    phi[0,1]  R199      1.4526431560516357e+00
    phi[0,1]  R200      -2.2268426418304443e+00
    phi[0,1]  R201      -3.1882812976837158e+00
    phi[0,1]  R202      -2.7107527256011963e+00
    phi[0,1]  R203      -2.0113573074340820e+00
    phi[0,1]  R204      -1.8521090745925903e+00
    phi[0,1]  R205      3.2449603080749512e-01
    phi[0,1]  R206      -0.74664306640625
    phi[0,1]  R207      4.3388321995735168e-01
    phi[0,1]  R208      -1.3133707046508789e+00
    phi[0,1]  R209      -2.5456299781799316e+00
    phi[0,1]  R210      -8.4660679101943970e-01
    phi[0,1]  R211      -2.4424536228179932e+00
    phi[0,1]  R212      -1.8643260002136230e+00
    phi[0,1]  R213      -2.1859447956085205e+00
    phi[0,1]  R214      -2.0287697315216064e+00
    phi[0,1]  R215      -7.3748081922531128e-01
    phi[0,1]  R216      -1.8229624629020691e-01
    phi[0,1]  R217      -9.0701466798782349e-01
    phi[0,1]  R218      1.7623475790023804e+00
    phi[0,1]  R219      -1.0663537979125977e+00
    phi[0,1]  R220      -2.5011084079742432e+00
    phi[0,1]  R221      -1.9758449792861938e+00
    phi[0,1]  R222      -2.3810656070709229e+00
    phi[0,1]  R223      -2.0810465812683105e+00
    phi[0,1]  R224      -1.3830730915069580e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R225      -3.0999999046325684e+00
    phi[1,0]  R226      -3.0999999046325684e+00
    phi[1,0]  R227      -2.2400000095367432e+00
    phi[1,0]  R228      -2.2400000095367432e+00
    phi[1,0]  R229      -3.0999999046325684e+00
    phi[1,0]  R230      -3.0999999046325684e+00
    phi[1,0]  R231      -2.5699999332427979e+00
    phi[1,0]  R232      -2.5699999332427979e+00
    phi[1,0]  R233      -3.0999999046325684e+00
    phi[1,0]  R234      -3.0999999046325684e+00
    phi[1,0]  R235      -2.0899999141693115e+00
    phi[1,0]  R236      -2.0899999141693115e+00
    phi[1,0]  R237      -3.0999999046325684e+00
    phi[1,0]  R238      -3.0999999046325684e+00
    phi[1,0]  R239      0.998393177986145
    phi[1,0]  R240      1.5726968050003052e+00
    phi[1,0]  R241      1.3959608078002930e+00
    phi[1,0]  R242      1.4580178260803223e+00
    phi[1,0]  R243      1.4834202527999878e+00
    phi[1,0]  R244      2.3353576660156250e+00
    phi[1,0]  R245      1.6139698028564453e+00
    phi[1,0]  R246      -8.1244844198226929e-01
    phi[1,0]  R247      -7.1971946954727173e-01
    phi[1,0]  R248      -8.6621528863906860e-01
    phi[1,0]  R249      -2.8808181285858154e+00
    phi[1,0]  R250      -2.4075033664703369e+00
    phi[1,0]  R251      -2.2332315444946289e+00
    phi[1,0]  R252      -2.8296663761138916e+00
    phi[1,0]  R253      2.5750610232353210e-01
    phi[1,0]  R254      2.9572030901908875e-01
    phi[1,0]  R255      -1.4443837404251099e+00
    phi[1,0]  R256      -2.0776166915893555e+00
    phi[1,0]  R257      -1.6136032342910767e+00
    phi[1,0]  R258      -1.5708523988723755e+00
    phi[1,0]  R259      -2.4225173890590668e-01
    phi[1,0]  R260      1.6645736992359161e-01
    phi[1,0]  R261      -5.3139519691467285e-01
    phi[1,0]  R262      -8.6472785472869873e-01
    phi[1,0]  R263      1.4526431560516357e+00
    phi[1,0]  R264      -2.2268426418304443e+00
    phi[1,0]  R265      -3.1882812976837158e+00
    phi[1,0]  R266      -2.7107527256011963e+00
    phi[1,0]  R267      -2.0113573074340820e+00
    phi[1,0]  R268      -1.8521090745925903e+00
    phi[1,0]  R269      3.2449603080749512e-01
    phi[1,0]  R270      -0.74664306640625
    phi[1,0]  R271      4.3388321995735168e-01
    phi[1,0]  R272      -1.3133707046508789e+00
    phi[1,0]  R273      -2.5456299781799316e+00
    phi[1,0]  R274      -8.4660679101943970e-01
    phi[1,0]  R275      -2.4424536228179932e+00
    phi[1,0]  R276      -1.8643260002136230e+00
    phi[1,0]  R277      -2.1859447956085205e+00
    phi[1,0]  R278      -2.0287697315216064e+00
    phi[1,0]  R279      -7.3748081922531128e-01
    phi[1,0]  R280      -1.8229624629020691e-01
    phi[1,0]  R281      -9.0701466798782349e-01
    phi[1,0]  R282      1.7623475790023804e+00
    phi[1,0]  R283      -1.0663537979125977e+00
    phi[1,0]  R284      -2.5011084079742432e+00
    phi[1,0]  R285      -1.9758449792861938e+00
    phi[1,0]  R286      -2.3810656070709229e+00
    phi[1,0]  R287      -2.0810465812683105e+00
    phi[1,0]  R288      -1.3830730915069580e+00
    phi[1,0]  R289      -2.1948951482772827e-01
    phi[1,0]  R290      3.8127106428146362e-01
    phi[1,0]  R291      4.5087870955467224e-01
    phi[1,0]  R292      8.4535408020019531e-01
    phi[1,0]  R293      -1.0518914461135864e+00
    phi[1,0]  R294      -1.4924558997154236e-01
    phi[1,0]  R295      -0.811653196811676
    phi[1,0]  R296      -9.6806889772415161e-01
    phi[1,0]  R297      -4.3553823232650757e-01
    phi[1,0]  R298      2.2030051052570343e-01
    phi[1,0]  R299      -1.1702115535736084e+00
    phi[1,0]  R300      -1.2668842077255249e+00
    phi[1,0]  R301      -2.1376707553863525e+00
    phi[1,0]  R302      -1.8195823431015015e+00
    phi[1,0]  R303      -2.7108309268951416e+00
    phi[1,0]  R304      -1.7746373414993286e+00
    phi[1,0]  R305      -1.5230154991149902e+00
    phi[1,0]  R306      -1.7706049680709839e+00
    phi[1,0]  R307      -1.4631687402725220e+00
    phi[1,0]  R308      -1.4899804592132568e+00
    phi[1,0]  R309      -1.3121581077575684e+00
    phi[1,0]  R310      -5.6514465808868408e-01
    phi[1,0]  R311      -1.4165538549423218e+00
    phi[1,0]  R312      -1.3899122476577759e+00
    phi[1,0]  R313      -1.3972704410552979e+00
    phi[1,0]  R314      -1.3021285533905029e+00
    phi[1,0]  R315      -8.7903779745101929e-01
    phi[1,0]  R316      -1.6624507904052734e+00
    phi[1,0]  R317      -2.2197632789611816e+00
    phi[1,0]  R318      -1.8832582235336304e+00
    phi[1,0]  R319      -1.1975284814834595e+00
    phi[1,0]  R320      3.4225676208734512e-02
    phi[1,0]  R321      -8.4309369325637817e-01
    phi[1,0]  R322      -1.6528390645980835e+00
    phi[1,0]  R323      -3.0537894368171692e-01
    phi[1,0]  R324      -9.0089541673660278e-01
    phi[1,0]  R325      -1.3017466068267822e+00
    phi[1,0]  R326      -1.3003400564193726e+00
    phi[1,0]  R327      -1.9370923042297363e+00
    phi[1,0]  R328      -1.8130618333816528e+00
    phi[1,0]  R329      -1.2519774436950684e+00
    phi[1,0]  R330      -6.0285472869873047e-01
    phi[1,0]  R331      -2.7024433016777039e-01
    phi[1,0]  R332      -2.9015231132507324e-01
    phi[1,0]  R333      -1.0284395217895508e+00
    phi[1,0]  R334      -1.3257403373718262e+00
    phi[1,0]  R335      -1.6234004497528076e+00
    phi[1,0]  R336      -1.6399219036102295e+00
    phi[1,0]  R337      -1.0824191570281982e+00
    phi[1,0]  R338      -5.2295017242431641e-01
    phi[1,0]  R339      -5.4910612106323242e-01
    phi[1,0]  R340      -7.2183507680892944e-01
    phi[1,0]  R341      -1.3820582628250122e+00
    phi[1,0]  R342      -1.2896230220794678e+00
    phi[1,0]  R343      -1.3335368633270264e+00
    phi[1,0]  R344      -2.9823825359344482e+00
    phi[1,0]  R345      -2.5500571727752686e+00
    phi[1,0]  R346      -2.08294677734375
    phi[1,0]  R347      -2.0980064868927
    phi[1,0]  R348      -2.7004737854003906e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R349      -3.0999999046325684e+00
    phi[0,4]  R350      -3.0999999046325684e+00
    phi[0,4]  R351      -2.2400000095367432e+00
    phi[0,4]  R352      -2.2400000095367432e+00
    phi[0,4]  R353      -3.0999999046325684e+00
    phi[0,4]  R354      -3.0999999046325684e+00
    phi[0,4]  R355      -2.5699999332427979e+00
    phi[0,4]  R356      -2.5699999332427979e+00
    phi[0,4]  R357      -3.0999999046325684e+00
    phi[0,4]  R358      -3.0999999046325684e+00
    phi[0,4]  R359      -2.0899999141693115e+00
    phi[0,4]  R360      -2.0899999141693115e+00
    phi[0,4]  R361      -3.0999999046325684e+00
    phi[0,4]  R362      -3.0999999046325684e+00
    phi[0,4]  R363      -2.1948951482772827e-01
    phi[0,4]  R364      3.8127106428146362e-01
    phi[0,4]  R365      4.5087870955467224e-01
    phi[0,4]  R366      8.4535408020019531e-01
    phi[0,4]  R367      -1.0518914461135864e+00
    phi[0,4]  R368      -1.4924558997154236e-01
    phi[0,4]  R369      -0.811653196811676
    phi[0,4]  R370      -9.6806889772415161e-01
    phi[0,4]  R371      -4.3553823232650757e-01
    phi[0,4]  R372      2.2030051052570343e-01
    phi[0,4]  R373      -1.1702115535736084e+00
    phi[0,4]  R374      -1.2668842077255249e+00
    phi[0,4]  R375      -2.1376707553863525e+00
    phi[0,4]  R376      -1.8195823431015015e+00
    phi[0,4]  R377      -2.7108309268951416e+00
    phi[0,4]  R378      -1.7746373414993286e+00
    phi[0,4]  R379      -1.5230154991149902e+00
    phi[0,4]  R380      -1.7706049680709839e+00
    phi[0,4]  R381      -1.4631687402725220e+00
    phi[0,4]  R382      -1.4899804592132568e+00
    phi[0,4]  R383      -1.3121581077575684e+00
    phi[0,4]  R384      -5.6514465808868408e-01
    phi[0,4]  R385      -1.4165538549423218e+00
    phi[0,4]  R386      -1.3899122476577759e+00
    phi[0,4]  R387      -1.3972704410552979e+00
    phi[0,4]  R388      -1.3021285533905029e+00
    phi[0,4]  R389      -8.7903779745101929e-01
    phi[0,4]  R390      -1.6624507904052734e+00
    phi[0,4]  R391      -2.2197632789611816e+00
    phi[0,4]  R392      -1.8832582235336304e+00
    phi[0,4]  R393      -1.1975284814834595e+00
    phi[0,4]  R394      3.4225676208734512e-02
    phi[0,4]  R395      -8.4309369325637817e-01
    phi[0,4]  R396      -1.6528390645980835e+00
    phi[0,4]  R397      -3.0537894368171692e-01
    phi[0,4]  R398      -9.0089541673660278e-01
    phi[0,4]  R399      -1.3017466068267822e+00
    phi[0,4]  R400      -1.3003400564193726e+00
    phi[0,4]  R401      -1.9370923042297363e+00
    phi[0,4]  R402      -1.8130618333816528e+00
    phi[0,4]  R403      -1.2519774436950684e+00
    phi[0,4]  R404      -6.0285472869873047e-01
    phi[0,4]  R405      -2.7024433016777039e-01
    phi[0,4]  R406      -2.9015231132507324e-01
    phi[0,4]  R407      -1.0284395217895508e+00
    phi[0,4]  R408      -1.3257403373718262e+00
    phi[0,4]  R409      -1.6234004497528076e+00
    phi[0,4]  R410      -1.6399219036102295e+00
    phi[0,4]  R411      -1.0824191570281982e+00
    phi[0,4]  R412      -5.2295017242431641e-01
    phi[0,4]  R413      -5.4910612106323242e-01
    phi[0,4]  R414      -7.2183507680892944e-01
    phi[0,4]  R415      -1.3820582628250122e+00
    phi[0,4]  R416      -1.2896230220794678e+00
    phi[0,4]  R417      -1.3335368633270264e+00
    phi[0,4]  R418      -2.9823825359344482e+00
    phi[0,4]  R419      -2.5500571727752686e+00
    phi[0,4]  R420      -2.08294677734375
    phi[0,4]  R421      -2.0980064868927
    phi[0,4]  R422      -2.7004737854003906e+00
    phi[0,4]  R423      6.8718397617340088e-01
    phi[0,4]  R424      2.1385915279388428e+00
    phi[0,4]  R425      6.9518762826919556e-01
    phi[0,4]  R426      8.8087493181228638e-01
    phi[0,4]  R427      6.4752191305160522e-01
    phi[0,4]  R428      3.6792182922363281e-01
    phi[0,4]  R429      1.4422966241836548e+00
    phi[0,4]  R430      -1.7382947206497192e+00
    phi[0,4]  R431      2.6721981167793274e-01
    phi[0,4]  R432      2.0653177052736282e-02
    phi[0,4]  R433      -9.3247991800308228e-01
    phi[0,4]  R434      -3.2377424240112305e+00
    phi[0,4]  R435      -1.3001575469970703e+00
    phi[0,4]  R436      -3.4299058914184570e+00
    phi[0,4]  R437      -2.4514722824096680e+00
    phi[0,4]  R438      -1.3005512952804565e+00
    phi[0,4]  R439      -2.8537175655364990e+00
    phi[0,4]  R440      -1.9666780233383179e+00
    phi[0,4]  R441      -3.7003839015960693e+00
    phi[0,4]  R442      -2.3483183383941650e+00
    phi[0,4]  R443      -1.6626055240631104e+00
    phi[0,4]  R444      -2.1448037028312683e-01
    phi[0,4]  R445      -1.5593667030334473e+00
    phi[0,4]  R446      -1.2732055187225342e+00
    phi[0,4]  R447      -2.9742330312728882e-01
    phi[0,4]  R448      -6.4270585775375366e-01
    phi[0,4]  R449      -2.8861966133117676e+00
    phi[0,4]  R450      -8.6732476949691772e-01
    phi[0,4]  R451      -7.1418327093124390e-01
    phi[0,4]  R452      8.4753161668777466e-01
    phi[0,4]  R453      -1.5988796949386597e+00
    phi[0,4]  R454      -1.3026838302612305e+00
    phi[0,4]  R455      -1.3014854192733765e+00
    phi[0,4]  R456      1.2574446201324463e-01
    phi[0,4]  R457      -1.5422412157058716e+00
    phi[0,4]  R458      2.3134428262710571e-01
    phi[0,4]  R459      6.3230311870574951e-01
    phi[0,4]  R460      8.3675122261047363e-01
    phi[0,4]  R461      1.2212105840444565e-01
    phi[0,4]  R462      1.3016896247863770e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R463      -3.0999999046325684e+00
    phi[4,0]  R464      -3.0999999046325684e+00
    phi[4,0]  R465      -2.2400000095367432e+00
    phi[4,0]  R466      -2.2400000095367432e+00
    phi[4,0]  R467      -3.0999999046325684e+00
    phi[4,0]  R468      -3.0999999046325684e+00
    phi[4,0]  R469      -2.5699999332427979e+00
    phi[4,0]  R470      -2.5699999332427979e+00
    phi[4,0]  R471      -3.0999999046325684e+00
    phi[4,0]  R472      -3.0999999046325684e+00
    phi[4,0]  R473      -2.0899999141693115e+00
    phi[4,0]  R474      -2.0899999141693115e+00
    phi[4,0]  R475      -3.0999999046325684e+00
    phi[4,0]  R476      -3.0999999046325684e+00
    phi[4,0]  R477      6.8718397617340088e-01
    phi[4,0]  R478      2.1385915279388428e+00
    phi[4,0]  R479      6.9518762826919556e-01
    phi[4,0]  R480      8.8087493181228638e-01
    phi[4,0]  R481      6.4752191305160522e-01
    phi[4,0]  R482      3.6792182922363281e-01
    phi[4,0]  R483      1.4422966241836548e+00
    phi[4,0]  R484      -1.7382947206497192e+00
    phi[4,0]  R485      2.6721981167793274e-01
    phi[4,0]  R486      2.0653177052736282e-02
    phi[4,0]  R487      -9.3247991800308228e-01
    phi[4,0]  R488      -3.2377424240112305e+00
    phi[4,0]  R489      -1.3001575469970703e+00
    phi[4,0]  R490      -3.4299058914184570e+00
    phi[4,0]  R491      -2.4514722824096680e+00
    phi[4,0]  R492      -1.3005512952804565e+00
    phi[4,0]  R493      -2.8537175655364990e+00
    phi[4,0]  R494      -1.9666780233383179e+00
    phi[4,0]  R495      -3.7003839015960693e+00
    phi[4,0]  R496      -2.3483183383941650e+00
    phi[4,0]  R497      -1.6626055240631104e+00
    phi[4,0]  R498      -2.1448037028312683e-01
    phi[4,0]  R499      -1.5593667030334473e+00
    phi[4,0]  R500      -1.2732055187225342e+00
    phi[4,0]  R501      -2.9742330312728882e-01
    phi[4,0]  R502      -6.4270585775375366e-01
    phi[4,0]  R503      -2.8861966133117676e+00
    phi[4,0]  R504      -8.6732476949691772e-01
    phi[4,0]  R505      -7.1418327093124390e-01
    phi[4,0]  R506      8.4753161668777466e-01
    phi[4,0]  R507      -1.5988796949386597e+00
    phi[4,0]  R508      -1.3026838302612305e+00
    phi[4,0]  R509      -1.3014854192733765e+00
    phi[4,0]  R510      1.2574446201324463e-01
    phi[4,0]  R511      -1.5422412157058716e+00
    phi[4,0]  R512      2.3134428262710571e-01
    phi[4,0]  R513      6.3230311870574951e-01
    phi[4,0]  R514      8.3675122261047363e-01
    phi[4,0]  R515      1.2212105840444565e-01
    phi[4,0]  R516      1.3016896247863770e+00
    phi[4,0]  R517      -2.1948951482772827e-01
    phi[4,0]  R518      3.8127106428146362e-01
    phi[4,0]  R519      4.5087870955467224e-01
    phi[4,0]  R520      8.4535408020019531e-01
    phi[4,0]  R521      -1.0518914461135864e+00
    phi[4,0]  R522      -1.4924558997154236e-01
    phi[4,0]  R523      -0.811653196811676
    phi[4,0]  R524      -9.6806889772415161e-01
    phi[4,0]  R525      -4.3553823232650757e-01
    phi[4,0]  R526      2.2030051052570343e-01
    phi[4,0]  R527      -1.1702115535736084e+00
    phi[4,0]  R528      -1.2668842077255249e+00
    phi[4,0]  R529      -2.1376707553863525e+00
    phi[4,0]  R530      -1.8195823431015015e+00
    phi[4,0]  R531      -2.7108309268951416e+00
    phi[4,0]  R532      -1.7746373414993286e+00
    phi[4,0]  R533      -1.5230154991149902e+00
    phi[4,0]  R534      -1.7706049680709839e+00
    phi[4,0]  R535      -1.4631687402725220e+00
    phi[4,0]  R536      -1.4899804592132568e+00
    phi[4,0]  R537      -1.3121581077575684e+00
    phi[4,0]  R538      -5.6514465808868408e-01
    phi[4,0]  R539      -1.4165538549423218e+00
    phi[4,0]  R540      -1.3899122476577759e+00
    phi[4,0]  R541      -1.3972704410552979e+00
    phi[4,0]  R542      -1.3021285533905029e+00
    phi[4,0]  R543      -8.7903779745101929e-01
    phi[4,0]  R544      -1.6624507904052734e+00
    phi[4,0]  R545      -2.2197632789611816e+00
    phi[4,0]  R546      -1.8832582235336304e+00
    phi[4,0]  R547      -1.1975284814834595e+00
    phi[4,0]  R548      3.4225676208734512e-02
    phi[4,0]  R549      -8.4309369325637817e-01
    phi[4,0]  R550      -1.6528390645980835e+00
    phi[4,0]  R551      -3.0537894368171692e-01
    phi[4,0]  R552      -9.0089541673660278e-01
    phi[4,0]  R553      -1.3017466068267822e+00
    phi[4,0]  R554      -1.3003400564193726e+00
    phi[4,0]  R555      -1.9370923042297363e+00
    phi[4,0]  R556      -1.8130618333816528e+00
    phi[4,0]  R557      -1.2519774436950684e+00
    phi[4,0]  R558      -6.0285472869873047e-01
    phi[4,0]  R559      -2.7024433016777039e-01
    phi[4,0]  R560      -2.9015231132507324e-01
    phi[4,0]  R561      -1.0284395217895508e+00
    phi[4,0]  R562      -1.3257403373718262e+00
    phi[4,0]  R563      -1.6234004497528076e+00
    phi[4,0]  R564      -1.6399219036102295e+00
    phi[4,0]  R565      -1.0824191570281982e+00
    phi[4,0]  R566      -5.2295017242431641e-01
    phi[4,0]  R567      -5.4910612106323242e-01
    phi[4,0]  R568      -7.2183507680892944e-01
    phi[4,0]  R569      -1.3820582628250122e+00
    phi[4,0]  R570      -1.2896230220794678e+00
    phi[4,0]  R571      -1.3335368633270264e+00
    phi[4,0]  R572      -2.9823825359344482e+00
    phi[4,0]  R573      -2.5500571727752686e+00
    phi[4,0]  R574      -2.08294677734375
    phi[4,0]  R575      -2.0980064868927
    phi[4,0]  R576      -2.7004737854003906e+00
    phi[11,0]  R0        -1
    phi[11,0]  R2        -1.0876942707822710e+00
    phi[11,0]  R3        -1.3864910604887788e+00
    phi[11,0]  R4        -8.0873759611484930e-01
    phi[11,0]  R5        1.7029626216183824e+00
    phi[11,0]  R6        1.5535340012573573e+00
    phi[11,0]  R7        1.2092606776728023e+00
    phi[11,0]  R8        -8.6802718594208583e-01
    phi[11,0]  R99       1
    phi[11,0]  R577      -2.0123056338502971e+00
    phi[11,0]  R578      -4.18769417541484
    phi[11,0]  R579      -8.5350894904796437e-01
    phi[11,0]  R580      -3.6264910700255220e+00
    phi[11,0]  R581      -2.2912623085177191e+00
    phi[11,0]  R582      -3.9087375007474177e+00
    phi[11,0]  R583      -4.2729625548611807e+00
    phi[11,0]  R584      -8.6703731162441544e-01
    phi[11,0]  R585      -4.6535339058899261e+00
    phi[11,0]  R586      -1.5464659033752111e+00
    phi[11,0]  R587      -3.2992605918421138e+00
    phi[11,0]  R588      -8.8073923649650920e-01
    phi[11,0]  R589      -2.2319727186904825e+00
    phi[11,0]  R590      -3.9680270905746542e+00
    phi[11,0]  R591      -1.4379929281484771e-01
    phi[11,0]  R592      -1.5920228430497829e-01
    phi[11,0]  R593      -1.6933981136472487e-01
    phi[11,0]  R594      -1.9000656057881238e-01
    phi[11,0]  R595      -5.9552274549909812e-01
    phi[11,0]  R596      -8.1363711521495974e-01
    phi[11,0]  R597      -1.6770566186431637e+00
    phi[11,0]  R598      -2.0329963377682119e+00
    phi[11,0]  R599      -1.3550562608721997e+00
    phi[11,0]  R600      -2.7647511795151469e-01
    phi[11,0]  R601      -3.7694343975175559e-01
    phi[11,0]  R602      -5.1086628670804646e-01
    phi[11,0]  R603      -6.1578603293162182e-01
    phi[11,0]  R604      -6.2636240461833448e-01
    phi[11,0]  R605      -6.2958161290164982e-01
    phi[11,0]  R606      -6.6446200946180811e-01
    phi[11,0]  R607      -0.684002792489306
    phi[11,0]  R608      -7.0864033466312426e-01
    phi[11,0]  R609      -7.4029795978556323e-01
    phi[11,0]  R610      -7.4696007887971083e-01
    phi[11,0]  R611      -3.3156906298633926e-01
    phi[11,0]  R612      -3.9261940584833743e-01
    phi[11,0]  R613      -4.6973060051857451e-01
    phi[11,0]  R614      -5.0181388296355056e-01
    phi[11,0]  R615      -5.3275720382136738e-01
    phi[11,0]  R616      -6.0033167079756256e-01
    phi[11,0]  R617      -6.3356828995771908e-01
    phi[11,0]  R618      -6.5141059367163745e-01
    phi[11,0]  R619      -7.3239879313378009e-01
    phi[11,0]  R620      -8.0463633165348836e-01
    phi[11,0]  R621      -3.6914135993641062e-01
    phi[11,0]  R622      -4.0403183024833145e-01
    phi[11,0]  R623      -4.4458694404291543e-01
    phi[11,0]  R624      -4.4877065463772392e-01
    phi[11,0]  R625      -4.5327033688951179e-01
    phi[11,0]  R626      -5.0765397419583014e-01
    phi[11,0]  R627      -5.4248366854995167e-01
    phi[11,0]  R628      -5.7085749416933729e-01
    phi[11,0]  R629      -5.8158105473933142e-01
    phi[11,0]  R630      -5.9113324394011446e-01
    phi[11,0]  R631      -2.9365194092106439e-01
    phi[11,0]  R632      -3.0378903662259726e-01
    phi[11,0]  R633      -3.0421457053839412e-01
    phi[11,0]  R634      -3.2533130983755776e-01
    phi[11,0]  R635      -4.6060973371083824e-01
    phi[11,0]  R636      -4.9165059052682158e-01
    phi[11,0]  R637      -5.6328600469313139e-01
    phi[11,0]  R638      -5.7555781351859348e-01
    phi[11,0]  R639      -6.3578605785519526e-01
    phi[11,0]  R640      -7.9215038065840826e-01
    phi[11,0]  R641      -2.2311674359992217e-01
    phi[11,0]  R642      -2.6297682312530923e-01
    phi[11,0]  R643      -3.3188380075414603e-01
    phi[11,0]  R644      -5.1205054210258372e-01
    phi[11,0]  R645      -0.586730666699606
    phi[11,0]  R646      -6.9754338071865174e-01
    phi[11,0]  R647      -8.1846551213712160e-01
    phi[11,0]  R648      -8.3314754963100390e-01
    phi[11,0]  R649      -1.0478128245556178e+00
    phi[11,0]  R650      -1.0571714745310952e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R651      -3.0999999046325684e+00
    phi[1,2]  R652      -3.0999999046325684e+00
    phi[1,2]  R653      -2.2400000095367432e+00
    phi[1,2]  R654      -2.2400000095367432e+00
    phi[1,2]  R655      -3.0999999046325684e+00
    phi[1,2]  R656      -3.0999999046325684e+00
    phi[1,2]  R657      -2.5699999332427979e+00
    phi[1,2]  R658      -2.5699999332427979e+00
    phi[1,2]  R659      -3.0999999046325684e+00
    phi[1,2]  R660      -3.0999999046325684e+00
    phi[1,2]  R661      -2.0899999141693115e+00
    phi[1,2]  R662      -2.0899999141693115e+00
    phi[1,2]  R663      -3.0999999046325684e+00
    phi[1,2]  R664      -3.0999999046325684e+00
    phi[1,2]  R665      0.998393177986145
    phi[1,2]  R666      1.5726968050003052e+00
    phi[1,2]  R667      1.3959608078002930e+00
    phi[1,2]  R668      1.4580178260803223e+00
    phi[1,2]  R669      1.4834202527999878e+00
    phi[1,2]  R670      2.3353576660156250e+00
    phi[1,2]  R671      1.6139698028564453e+00
    phi[1,2]  R672      -8.1244844198226929e-01
    phi[1,2]  R673      -7.1971946954727173e-01
    phi[1,2]  R674      -8.6621528863906860e-01
    phi[1,2]  R675      -2.8808181285858154e+00
    phi[1,2]  R676      -2.4075033664703369e+00
    phi[1,2]  R677      -2.2332315444946289e+00
    phi[1,2]  R678      -2.8296663761138916e+00
    phi[1,2]  R679      2.5750610232353210e-01
    phi[1,2]  R680      2.9572030901908875e-01
    phi[1,2]  R681      -1.4443837404251099e+00
    phi[1,2]  R682      -2.0776166915893555e+00
    phi[1,2]  R683      -1.6136032342910767e+00
    phi[1,2]  R684      -1.5708523988723755e+00
    phi[1,2]  R685      -2.4225173890590668e-01
    phi[1,2]  R686      1.6645736992359161e-01
    phi[1,2]  R687      -5.3139519691467285e-01
    phi[1,2]  R688      -8.6472785472869873e-01
    phi[1,2]  R689      1.4526431560516357e+00
    phi[1,2]  R690      -2.2268426418304443e+00
    phi[1,2]  R691      -3.1882812976837158e+00
    phi[1,2]  R692      -2.7107527256011963e+00
    phi[1,2]  R693      -2.0113573074340820e+00
    phi[1,2]  R694      -1.8521090745925903e+00
    phi[1,2]  R695      3.2449603080749512e-01
    phi[1,2]  R696      -0.74664306640625
    phi[1,2]  R697      4.3388321995735168e-01
    phi[1,2]  R698      -1.3133707046508789e+00
    phi[1,2]  R699      -2.5456299781799316e+00
    phi[1,2]  R700      -8.4660679101943970e-01
    phi[1,2]  R701      -2.4424536228179932e+00
    phi[1,2]  R702      -1.8643260002136230e+00
    phi[1,2]  R703      -2.1859447956085205e+00
    phi[1,2]  R704      -2.0287697315216064e+00
    phi[1,2]  R705      -7.3748081922531128e-01
    phi[1,2]  R706      -1.8229624629020691e-01
    phi[1,2]  R707      -9.0701466798782349e-01
    phi[1,2]  R708      1.7623475790023804e+00
    phi[1,2]  R709      -1.0663537979125977e+00
    phi[1,2]  R710      -2.5011084079742432e+00
    phi[1,2]  R711      -1.9758449792861938e+00
    phi[1,2]  R712      -2.3810656070709229e+00
    phi[1,2]  R713      -2.0810465812683105e+00
    phi[1,2]  R714      -1.3830730915069580e+00
    phi[1,2]  R715      1.9726645946502686e+00
    phi[1,2]  R716      1.8604798316955566e+00
    phi[1,2]  R717      2.4337649345397949e+00
    phi[1,2]  R718      2.1396627426147461e+00
    phi[1,2]  R719      2.7631921768188477e+00
    phi[1,2]  R720      2.3974528312683105e+00
    phi[1,2]  R721      2.5888528823852539e+00
    phi[1,2]  R722      1.8842095136642456e+00
    phi[1,2]  R723      2.4802374839782715e+00
    phi[1,2]  R724      2.2263290882110596e+00
    phi[1,2]  R725      -3.2448613643646240e+00
    phi[1,2]  R726      -2.2085428237915039e+00
    phi[1,2]  R727      -2.2802715301513672e+00
    phi[1,2]  R728      -3.1885154247283936e+00
    phi[1,2]  R729      -2.7944211959838867e+00
    phi[1,2]  R730      -2.2405292987823486e+00
    phi[1,2]  R731      -3.9019858837127686e+00
    phi[1,2]  R732      -2.2846310138702393e+00
    phi[1,2]  R733      -2.2150826454162598e+00
    phi[1,2]  R734      -1.6864511966705322e+00
    phi[1,2]  R735      -1.6877774000167847e+00
    phi[1,2]  R736      -1.2098628282546997e+00
    phi[1,2]  R737      -2.1782221794128418e+00
    phi[1,2]  R738      -1.9762146472930908e+00
    phi[1,2]  R739      -2.0041620731353760e+00
    phi[1,2]  R740      -1.7144851684570312e+00
    phi[1,2]  R741      -3.4222214221954346e+00
    phi[1,2]  R742      -2.3233988285064697e+00
    phi[1,2]  R743      -1.1272107362747192e+00
    phi[1,2]  R744      -1.05417001247406
    phi[1,2]  R745      -2.1424033641815186e+00
    phi[1,2]  R746      -2.3262803554534912e+00
    phi[1,2]  R747      1.7356351613998413e+00
    phi[1,2]  R748      -1.7954158782958984e+00
    phi[1,2]  R749      2.1489887237548828e+00
    phi[1,2]  R750      -1.2473982572555542e+00
    phi[1,2]  R751      1.0409188270568848e+00
    phi[1,2]  R752      -1.3474553823471069e+00
    phi[1,2]  R753      -4.0992081165313721e-01
    phi[1,2]  R754      7.4367415904998779e-01
    phi[1,2]  R755      2.8224570751190186e+00
    phi[1,2]  R756      3.0024294853210449e+00
    phi[1,2]  R757      -1.1527781486511230e+00
    phi[1,2]  R758      -8.0709469318389893e-01
    phi[1,2]  R759      1.2216894626617432e+00
    phi[1,2]  R760      -2.8090901374816895e+00
    phi[1,2]  R761      -1.4056240320205688e+00
    phi[1,2]  R762      1.8050426244735718e+00
    phi[1,2]  R763      1.6530294418334961e+00
    phi[1,2]  R764      -1.6570930480957031e+00
    phi[1,2]  R765      2.3004133701324463e+00
    phi[1,2]  R766      -1.1170434951782227e+00
    phi[1,2]  R767      1.6174712181091309e+00
    phi[1,2]  R768      -1.9546442031860352e+00
    phi[1,2]  R769      5.9695506095886230e-01
    phi[1,2]  R770      -1.5379874706268311e+00
    phi[1,2]  R771      8.0217711627483368e-02
    phi[1,2]  R772      -2.3345034122467041e+00
    phi[1,2]  R773      -1.2938904762268066e+00
    phi[1,2]  R774      -0.0697346180677414
    phi[1,2]  R775      -2.0384807586669922e+00
    phi[1,2]  R776      2.5508012771606445e+00
    phi[1,2]  R777      -2.9807372093200684e+00
    phi[1,2]  R778      1.6916140317916870e+00
    phi[1,2]  R779      -3.4535737037658691e+00
    phi[1,2]  R780      -2.1824295520782471e+00
    phi[1,2]  R781      -7.9791349172592163e-01
    phi[1,2]  R782      -8.0982875823974609e-01
    phi[1,2]  R783      3.2894369959831238e-01
    phi[1,2]  R784      -6.9238132238388062e-01
    phi[1,2]  R785      1.5342128276824951e+00
    phi[1,2]  R786      -8.6259663105010986e-01
    phi[1,2]  R787      1.3764312267303467e+00
    phi[1,2]  R788      8.2337492704391479e-01
    phi[1,2]  R789      -1.1054385900497437e+00
    phi[1,2]  R790      -2.5875790119171143e+00
    phi[1,2]  R791      -3.1252326965332031e+00
    phi[1,2]  R792      -1.9712796211242676e+00
    phi[1,2]  R793      -1.4752852916717529e+00
    phi[1,2]  R794      9.5281016826629639e-01
    phi[1,2]  R795      2.7158682346343994e+00
    phi[1,2]  R796      -1.1227324008941650e+00
    phi[1,2]  R797      -2.5368649959564209e+00
    phi[1,2]  R798      2.7073416113853455e-01
    phi[1,2]  R799      -1.8868306875228882e+00
    phi[1,2]  R800      1.2134937942028046e-01
    phi[1,2]  R801      -2.0222475528717041e+00
    phi[1,2]  R802      -2.1279733180999756e+00
    phi[1,2]  R803      -1.4288482069969177e-01
    phi[1,2]  R804      -1.0307883024215698e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R805      -3.0999999046325684e+00
    phi[2,1]  R806      -3.0999999046325684e+00
    phi[2,1]  R807      -2.2400000095367432e+00
    phi[2,1]  R808      -2.2400000095367432e+00
    phi[2,1]  R809      -3.0999999046325684e+00
    phi[2,1]  R810      -3.0999999046325684e+00
    phi[2,1]  R811      -2.5699999332427979e+00
    phi[2,1]  R812      -2.5699999332427979e+00
    phi[2,1]  R813      -3.0999999046325684e+00
    phi[2,1]  R814      -3.0999999046325684e+00
    phi[2,1]  R815      -2.0899999141693115e+00
    phi[2,1]  R816      -2.0899999141693115e+00
    phi[2,1]  R817      -3.0999999046325684e+00
    phi[2,1]  R818      -3.0999999046325684e+00
    phi[2,1]  R819      1.9726645946502686e+00
    phi[2,1]  R820      1.8604798316955566e+00
    phi[2,1]  R821      2.4337649345397949e+00
    phi[2,1]  R822      2.1396627426147461e+00
    phi[2,1]  R823      2.7631921768188477e+00
    phi[2,1]  R824      2.3974528312683105e+00
    phi[2,1]  R825      2.5888528823852539e+00
    phi[2,1]  R826      1.8842095136642456e+00
    phi[2,1]  R827      2.4802374839782715e+00
    phi[2,1]  R828      2.2263290882110596e+00
    phi[2,1]  R829      -3.2448613643646240e+00
    phi[2,1]  R830      -2.2085428237915039e+00
    phi[2,1]  R831      -2.2802715301513672e+00
    phi[2,1]  R832      -3.1885154247283936e+00
    phi[2,1]  R833      -2.7944211959838867e+00
    phi[2,1]  R834      -2.2405292987823486e+00
    phi[2,1]  R835      -3.9019858837127686e+00
    phi[2,1]  R836      -2.2846310138702393e+00
    phi[2,1]  R837      -2.2150826454162598e+00
    phi[2,1]  R838      -1.6864511966705322e+00
    phi[2,1]  R839      -1.6877774000167847e+00
    phi[2,1]  R840      -1.2098628282546997e+00
    phi[2,1]  R841      -2.1782221794128418e+00
    phi[2,1]  R842      -1.9762146472930908e+00
    phi[2,1]  R843      -2.0041620731353760e+00
    phi[2,1]  R844      -1.7144851684570312e+00
    phi[2,1]  R845      -3.4222214221954346e+00
    phi[2,1]  R846      -2.3233988285064697e+00
    phi[2,1]  R847      -1.1272107362747192e+00
    phi[2,1]  R848      -1.05417001247406
    phi[2,1]  R849      -2.1424033641815186e+00
    phi[2,1]  R850      -2.3262803554534912e+00
    phi[2,1]  R851      1.7356351613998413e+00
    phi[2,1]  R852      -1.7954158782958984e+00
    phi[2,1]  R853      2.1489887237548828e+00
    phi[2,1]  R854      -1.2473982572555542e+00
    phi[2,1]  R855      1.0409188270568848e+00
    phi[2,1]  R856      -1.3474553823471069e+00
    phi[2,1]  R857      -4.0992081165313721e-01
    phi[2,1]  R858      7.4367415904998779e-01
    phi[2,1]  R859      2.8224570751190186e+00
    phi[2,1]  R860      3.0024294853210449e+00
    phi[2,1]  R861      -1.1527781486511230e+00
    phi[2,1]  R862      -8.0709469318389893e-01
    phi[2,1]  R863      1.2216894626617432e+00
    phi[2,1]  R864      -2.8090901374816895e+00
    phi[2,1]  R865      -1.4056240320205688e+00
    phi[2,1]  R866      1.8050426244735718e+00
    phi[2,1]  R867      1.6530294418334961e+00
    phi[2,1]  R868      -1.6570930480957031e+00
    phi[2,1]  R869      2.3004133701324463e+00
    phi[2,1]  R870      -1.1170434951782227e+00
    phi[2,1]  R871      1.6174712181091309e+00
    phi[2,1]  R872      -1.9546442031860352e+00
    phi[2,1]  R873      5.9695506095886230e-01
    phi[2,1]  R874      -1.5379874706268311e+00
    phi[2,1]  R875      8.0217711627483368e-02
    phi[2,1]  R876      -2.3345034122467041e+00
    phi[2,1]  R877      -1.2938904762268066e+00
    phi[2,1]  R878      -0.0697346180677414
    phi[2,1]  R879      -2.0384807586669922e+00
    phi[2,1]  R880      2.5508012771606445e+00
    phi[2,1]  R881      -2.9807372093200684e+00
    phi[2,1]  R882      1.6916140317916870e+00
    phi[2,1]  R883      -3.4535737037658691e+00
    phi[2,1]  R884      -2.1824295520782471e+00
    phi[2,1]  R885      -7.9791349172592163e-01
    phi[2,1]  R886      -8.0982875823974609e-01
    phi[2,1]  R887      3.2894369959831238e-01
    phi[2,1]  R888      -6.9238132238388062e-01
    phi[2,1]  R889      1.5342128276824951e+00
    phi[2,1]  R890      -8.6259663105010986e-01
    phi[2,1]  R891      1.3764312267303467e+00
    phi[2,1]  R892      8.2337492704391479e-01
    phi[2,1]  R893      -1.1054385900497437e+00
    phi[2,1]  R894      -2.5875790119171143e+00
    phi[2,1]  R895      -3.1252326965332031e+00
    phi[2,1]  R896      -1.9712796211242676e+00
    phi[2,1]  R897      -1.4752852916717529e+00
    phi[2,1]  R898      9.5281016826629639e-01
    phi[2,1]  R899      2.7158682346343994e+00
    phi[2,1]  R900      -1.1227324008941650e+00
    phi[2,1]  R901      -2.5368649959564209e+00
    phi[2,1]  R902      2.7073416113853455e-01
    phi[2,1]  R903      -1.8868306875228882e+00
    phi[2,1]  R904      1.2134937942028046e-01
    phi[2,1]  R905      -2.0222475528717041e+00
    phi[2,1]  R906      -2.1279733180999756e+00
    phi[2,1]  R907      -1.4288482069969177e-01
    phi[2,1]  R908      -1.0307883024215698e+00
    phi[2,1]  R909      0.998393177986145
    phi[2,1]  R910      1.5726968050003052e+00
    phi[2,1]  R911      1.3959608078002930e+00
    phi[2,1]  R912      1.4580178260803223e+00
    phi[2,1]  R913      1.4834202527999878e+00
    phi[2,1]  R914      2.3353576660156250e+00
    phi[2,1]  R915      1.6139698028564453e+00
    phi[2,1]  R916      -8.1244844198226929e-01
    phi[2,1]  R917      -7.1971946954727173e-01
    phi[2,1]  R918      -8.6621528863906860e-01
    phi[2,1]  R919      -2.8808181285858154e+00
    phi[2,1]  R920      -2.4075033664703369e+00
    phi[2,1]  R921      -2.2332315444946289e+00
    phi[2,1]  R922      -2.8296663761138916e+00
    phi[2,1]  R923      2.5750610232353210e-01
    phi[2,1]  R924      2.9572030901908875e-01
    phi[2,1]  R925      -1.4443837404251099e+00
    phi[2,1]  R926      -2.0776166915893555e+00
    phi[2,1]  R927      -1.6136032342910767e+00
    phi[2,1]  R928      -1.5708523988723755e+00
    phi[2,1]  R929      -2.4225173890590668e-01
    phi[2,1]  R930      1.6645736992359161e-01
    phi[2,1]  R931      -5.3139519691467285e-01
    phi[2,1]  R932      -8.6472785472869873e-01
    phi[2,1]  R933      1.4526431560516357e+00
    phi[2,1]  R934      -2.2268426418304443e+00
    phi[2,1]  R935      -3.1882812976837158e+00
    phi[2,1]  R936      -2.7107527256011963e+00
    phi[2,1]  R937      -2.0113573074340820e+00
    phi[2,1]  R938      -1.8521090745925903e+00
    phi[2,1]  R939      3.2449603080749512e-01
    phi[2,1]  R940      -0.74664306640625
    phi[2,1]  R941      4.3388321995735168e-01
    phi[2,1]  R942      -1.3133707046508789e+00
    phi[2,1]  R943      -2.5456299781799316e+00
    phi[2,1]  R944      -8.4660679101943970e-01
    phi[2,1]  R945      -2.4424536228179932e+00
    phi[2,1]  R946      -1.8643260002136230e+00
    phi[2,1]  R947      -2.1859447956085205e+00
    phi[2,1]  R948      -2.0287697315216064e+00
    phi[2,1]  R949      -7.3748081922531128e-01
    phi[2,1]  R950      -1.8229624629020691e-01
    phi[2,1]  R951      -9.0701466798782349e-01
    phi[2,1]  R952      1.7623475790023804e+00
    phi[2,1]  R953      -1.0663537979125977e+00
    phi[2,1]  R954      -2.5011084079742432e+00
    phi[2,1]  R955      -1.9758449792861938e+00
    phi[2,1]  R956      -2.3810656070709229e+00
    phi[2,1]  R957      -2.0810465812683105e+00
    phi[2,1]  R958      -1.3830730915069580e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R959      -3.0999999046325684e+00
    phi[2,3]  R960      -3.0999999046325684e+00
    phi[2,3]  R961      -2.2400000095367432e+00
    phi[2,3]  R962      -2.2400000095367432e+00
    phi[2,3]  R963      -3.0999999046325684e+00
    phi[2,3]  R964      -3.0999999046325684e+00
    phi[2,3]  R965      -2.5699999332427979e+00
    phi[2,3]  R966      -2.5699999332427979e+00
    phi[2,3]  R967      -3.0999999046325684e+00
    phi[2,3]  R968      -3.0999999046325684e+00
    phi[2,3]  R969      -2.0899999141693115e+00
    phi[2,3]  R970      -2.0899999141693115e+00
    phi[2,3]  R971      -3.0999999046325684e+00
    phi[2,3]  R972      -3.0999999046325684e+00
    phi[2,3]  R973      1.9726645946502686e+00
    phi[2,3]  R974      1.8604798316955566e+00
    phi[2,3]  R975      2.4337649345397949e+00
    phi[2,3]  R976      2.1396627426147461e+00
    phi[2,3]  R977      2.7631921768188477e+00
    phi[2,3]  R978      2.3974528312683105e+00
    phi[2,3]  R979      2.5888528823852539e+00
    phi[2,3]  R980      1.8842095136642456e+00
    phi[2,3]  R981      2.4802374839782715e+00
    phi[2,3]  R982      2.2263290882110596e+00
    phi[2,3]  R983      -3.2448613643646240e+00
    phi[2,3]  R984      -2.2085428237915039e+00
    phi[2,3]  R985      -2.2802715301513672e+00
    phi[2,3]  R986      -3.1885154247283936e+00
    phi[2,3]  R987      -2.7944211959838867e+00
    phi[2,3]  R988      -2.2405292987823486e+00
    phi[2,3]  R989      -3.9019858837127686e+00
    phi[2,3]  R990      -2.2846310138702393e+00
    phi[2,3]  R991      -2.2150826454162598e+00
    phi[2,3]  R992      -1.6864511966705322e+00
    phi[2,3]  R993      -1.6877774000167847e+00
    phi[2,3]  R994      -1.2098628282546997e+00
    phi[2,3]  R995      -2.1782221794128418e+00
    phi[2,3]  R996      -1.9762146472930908e+00
    phi[2,3]  R997      -2.0041620731353760e+00
    phi[2,3]  R998      -1.7144851684570312e+00
    phi[2,3]  R999      -3.4222214221954346e+00
    phi[2,3]  R1000     -2.3233988285064697e+00
    phi[2,3]  R1001     -1.1272107362747192e+00
    phi[2,3]  R1002     -1.05417001247406
    phi[2,3]  R1003     -2.1424033641815186e+00
    phi[2,3]  R1004     -2.3262803554534912e+00
    phi[2,3]  R1005     1.7356351613998413e+00
    phi[2,3]  R1006     -1.7954158782958984e+00
    phi[2,3]  R1007     2.1489887237548828e+00
    phi[2,3]  R1008     -1.2473982572555542e+00
    phi[2,3]  R1009     1.0409188270568848e+00
    phi[2,3]  R1010     -1.3474553823471069e+00
    phi[2,3]  R1011     -4.0992081165313721e-01
    phi[2,3]  R1012     7.4367415904998779e-01
    phi[2,3]  R1013     2.8224570751190186e+00
    phi[2,3]  R1014     3.0024294853210449e+00
    phi[2,3]  R1015     -1.1527781486511230e+00
    phi[2,3]  R1016     -8.0709469318389893e-01
    phi[2,3]  R1017     1.2216894626617432e+00
    phi[2,3]  R1018     -2.8090901374816895e+00
    phi[2,3]  R1019     -1.4056240320205688e+00
    phi[2,3]  R1020     1.8050426244735718e+00
    phi[2,3]  R1021     1.6530294418334961e+00
    phi[2,3]  R1022     -1.6570930480957031e+00
    phi[2,3]  R1023     2.3004133701324463e+00
    phi[2,3]  R1024     -1.1170434951782227e+00
    phi[2,3]  R1025     1.6174712181091309e+00
    phi[2,3]  R1026     -1.9546442031860352e+00
    phi[2,3]  R1027     5.9695506095886230e-01
    phi[2,3]  R1028     -1.5379874706268311e+00
    phi[2,3]  R1029     8.0217711627483368e-02
    phi[2,3]  R1030     -2.3345034122467041e+00
    phi[2,3]  R1031     -1.2938904762268066e+00
    phi[2,3]  R1032     -0.0697346180677414
    phi[2,3]  R1033     -2.0384807586669922e+00
    phi[2,3]  R1034     2.5508012771606445e+00
    phi[2,3]  R1035     -2.9807372093200684e+00
    phi[2,3]  R1036     1.6916140317916870e+00
    phi[2,3]  R1037     -3.4535737037658691e+00
    phi[2,3]  R1038     -2.1824295520782471e+00
    phi[2,3]  R1039     -7.9791349172592163e-01
    phi[2,3]  R1040     -8.0982875823974609e-01
    phi[2,3]  R1041     3.2894369959831238e-01
    phi[2,3]  R1042     -6.9238132238388062e-01
    phi[2,3]  R1043     1.5342128276824951e+00
    phi[2,3]  R1044     -8.6259663105010986e-01
    phi[2,3]  R1045     1.3764312267303467e+00
    phi[2,3]  R1046     8.2337492704391479e-01
    phi[2,3]  R1047     -1.1054385900497437e+00
    phi[2,3]  R1048     -2.5875790119171143e+00
    phi[2,3]  R1049     -3.1252326965332031e+00
    phi[2,3]  R1050     -1.9712796211242676e+00
    phi[2,3]  R1051     -1.4752852916717529e+00
    phi[2,3]  R1052     9.5281016826629639e-01
    phi[2,3]  R1053     2.7158682346343994e+00
    phi[2,3]  R1054     -1.1227324008941650e+00
    phi[2,3]  R1055     -2.5368649959564209e+00
    phi[2,3]  R1056     2.7073416113853455e-01
    phi[2,3]  R1057     -1.8868306875228882e+00
    phi[2,3]  R1058     1.2134937942028046e-01
    phi[2,3]  R1059     -2.0222475528717041e+00
    phi[2,3]  R1060     -2.1279733180999756e+00
    phi[2,3]  R1061     -1.4288482069969177e-01
    phi[2,3]  R1062     -1.0307883024215698e+00
    phi[2,3]  R1063     0.682270048509034
    phi[2,3]  R1064     1.6301953792572021e+00
    phi[2,3]  R1065     2.4280086408212940e+00
    phi[2,3]  R1066     1.85371732711792
    phi[2,3]  R1067     8.3064395189285278e-01
    phi[2,3]  R1068     -1.6890417337417603e+00
    phi[2,3]  R1069     1.6244244575500488e+00
    phi[2,3]  R1070     1.3833212852478027e-01
    phi[2,3]  R1071     -1.2938052415847778e+00
    phi[2,3]  R1072     4.7077560424804688e-01
    phi[2,3]  R1073     -2.5367214679718018e+00
    phi[2,3]  R1074     -3.5966901779174805e+00
    phi[2,3]  R1075     -2.6237609386444092e+00
    phi[2,3]  R1076     -3.1710565090179443e+00
    phi[2,3]  R1077     -2.1854300498962402e+00
    phi[2,3]  R1078     -2.4231557846069336e+00
    phi[2,3]  R1079     -2.6395745277404785e+00
    phi[2,3]  R1080     -5.8699674904346466e-02
    phi[2,3]  R1081     -2.2481372356414795e+00
    phi[2,3]  R1082     -1.4937937259674072e+00
    phi[2,3]  R1083     -1.3759787082672119e+00
    phi[2,3]  R1084     -4.7226530313491821e-01
    phi[2,3]  R1085     -1.9111098051071167e+00
    phi[2,3]  R1086     -2.4730424880981445e+00
    phi[2,3]  R1087     -2.4188549518585205e+00
    phi[2,3]  R1088     -2.8335824012756348e+00
    phi[2,3]  R1089     -2.4559917449951172e+00
    phi[2,3]  R1090     -2.1814482212066650e+00
    phi[2,3]  R1091     -2.8965513706207275e+00
    phi[2,3]  R1092     -2.5799529552459717e+00
    phi[2,3]  R1093     -1.5517382621765137e+00
    phi[2,3]  R1094     -2.2106435298919678e+00
    phi[2,3]  R1095     -2.5730376243591309e+00
    phi[2,3]  R1096     -9.8869937658309937e-01
    phi[2,3]  R1097     -1.5317547321319580e+00
    phi[2,3]  R1098     -1.7015953063964844e+00
    phi[2,3]  R1099     -2.0936355590820312e+00
    phi[2,3]  R1100     -2.0742316246032715e+00
    phi[2,3]  R1101     -1.1329267024993896e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1102     -3.0999999046325684e+00
    phi[3,2]  R1103     -3.0999999046325684e+00
    phi[3,2]  R1104     -2.2400000095367432e+00
    phi[3,2]  R1105     -2.2400000095367432e+00
    phi[3,2]  R1106     -3.0999999046325684e+00
    phi[3,2]  R1107     -3.0999999046325684e+00
    phi[3,2]  R1108     -2.5699999332427979e+00
    phi[3,2]  R1109     -2.5699999332427979e+00
    phi[3,2]  R1110     -3.0999999046325684e+00
    phi[3,2]  R1111     -3.0999999046325684e+00
    phi[3,2]  R1112     -2.0899999141693115e+00
    phi[3,2]  R1113     -2.0899999141693115e+00
    phi[3,2]  R1114     -3.0999999046325684e+00
    phi[3,2]  R1115     -3.0999999046325684e+00
    phi[3,2]  R1116     0.682270048509034
    phi[3,2]  R1117     1.6301953792572021e+00
    phi[3,2]  R1118     2.4280086408212940e+00
    phi[3,2]  R1119     1.85371732711792
    phi[3,2]  R1120     8.3064395189285278e-01
    phi[3,2]  R1121     -1.6890417337417603e+00
    phi[3,2]  R1122     1.6244244575500488e+00
    phi[3,2]  R1123     1.3833212852478027e-01
    phi[3,2]  R1124     -1.2938052415847778e+00
    phi[3,2]  R1125     4.7077560424804688e-01
    phi[3,2]  R1126     -2.5367214679718018e+00
    phi[3,2]  R1127     -3.5966901779174805e+00
    phi[3,2]  R1128     -2.6237609386444092e+00
    phi[3,2]  R1129     -3.1710565090179443e+00
    phi[3,2]  R1130     -2.1854300498962402e+00
    phi[3,2]  R1131     -2.4231557846069336e+00
    phi[3,2]  R1132     -2.6395745277404785e+00
    phi[3,2]  R1133     -5.8699674904346466e-02
    phi[3,2]  R1134     -2.2481372356414795e+00
    phi[3,2]  R1135     -1.4937937259674072e+00
    phi[3,2]  R1136     -1.3759787082672119e+00
    phi[3,2]  R1137     -4.7226530313491821e-01
    phi[3,2]  R1138     -1.9111098051071167e+00
    phi[3,2]  R1139     -2.4730424880981445e+00
    phi[3,2]  R1140     -2.4188549518585205e+00
    phi[3,2]  R1141     -2.8335824012756348e+00
    phi[3,2]  R1142     -2.4559917449951172e+00
    phi[3,2]  R1143     -2.1814482212066650e+00
    phi[3,2]  R1144     -2.8965513706207275e+00
    phi[3,2]  R1145     -2.5799529552459717e+00
    phi[3,2]  R1146     -1.5517382621765137e+00
    phi[3,2]  R1147     -2.2106435298919678e+00
    phi[3,2]  R1148     -2.5730376243591309e+00
    phi[3,2]  R1149     -9.8869937658309937e-01
    phi[3,2]  R1150     -1.5317547321319580e+00
    phi[3,2]  R1151     -1.7015953063964844e+00
    phi[3,2]  R1152     -2.0936355590820312e+00
    phi[3,2]  R1153     -2.0742316246032715e+00
    phi[3,2]  R1154     -1.1329267024993896e+00
    phi[3,2]  R1155     1.9726645946502686e+00
    phi[3,2]  R1156     1.8604798316955566e+00
    phi[3,2]  R1157     2.4337649345397949e+00
    phi[3,2]  R1158     2.1396627426147461e+00
    phi[3,2]  R1159     2.7631921768188477e+00
    phi[3,2]  R1160     2.3974528312683105e+00
    phi[3,2]  R1161     2.5888528823852539e+00
    phi[3,2]  R1162     1.8842095136642456e+00
    phi[3,2]  R1163     2.4802374839782715e+00
    phi[3,2]  R1164     2.2263290882110596e+00
    phi[3,2]  R1165     -3.2448613643646240e+00
    phi[3,2]  R1166     -2.2085428237915039e+00
    phi[3,2]  R1167     -2.2802715301513672e+00
    phi[3,2]  R1168     -3.1885154247283936e+00
    phi[3,2]  R1169     -2.7944211959838867e+00
    phi[3,2]  R1170     -2.2405292987823486e+00
    phi[3,2]  R1171     -3.9019858837127686e+00
    phi[3,2]  R1172     -2.2846310138702393e+00
    phi[3,2]  R1173     -2.2150826454162598e+00
    phi[3,2]  R1174     -1.6864511966705322e+00
    phi[3,2]  R1175     -1.6877774000167847e+00
    phi[3,2]  R1176     -1.2098628282546997e+00
    phi[3,2]  R1177     -2.1782221794128418e+00
    phi[3,2]  R1178     -1.9762146472930908e+00
    phi[3,2]  R1179     -2.0041620731353760e+00
    phi[3,2]  R1180     -1.7144851684570312e+00
    phi[3,2]  R1181     -3.4222214221954346e+00
    phi[3,2]  R1182     -2.3233988285064697e+00
    phi[3,2]  R1183     -1.1272107362747192e+00
    phi[3,2]  R1184     -1.05417001247406
    phi[3,2]  R1185     -2.1424033641815186e+00
    phi[3,2]  R1186     -2.3262803554534912e+00
    phi[3,2]  R1187     1.7356351613998413e+00
    phi[3,2]  R1188     -1.7954158782958984e+00
    phi[3,2]  R1189     2.1489887237548828e+00
    phi[3,2]  R1190     -1.2473982572555542e+00
    phi[3,2]  R1191     1.0409188270568848e+00
    phi[3,2]  R1192     -1.3474553823471069e+00
    phi[3,2]  R1193     -4.0992081165313721e-01
    phi[3,2]  R1194     7.4367415904998779e-01
    phi[3,2]  R1195     2.8224570751190186e+00
    phi[3,2]  R1196     3.0024294853210449e+00
    phi[3,2]  R1197     -1.1527781486511230e+00
    phi[3,2]  R1198     -8.0709469318389893e-01
    phi[3,2]  R1199     1.2216894626617432e+00
    phi[3,2]  R1200     -2.8090901374816895e+00
    phi[3,2]  R1201     -1.4056240320205688e+00
    phi[3,2]  R1202     1.8050426244735718e+00
    phi[3,2]  R1203     1.6530294418334961e+00
    phi[3,2]  R1204     -1.6570930480957031e+00
    phi[3,2]  R1205     2.3004133701324463e+00
    phi[3,2]  R1206     -1.1170434951782227e+00
    phi[3,2]  R1207     1.6174712181091309e+00
    phi[3,2]  R1208     -1.9546442031860352e+00
    phi[3,2]  R1209     5.9695506095886230e-01
    phi[3,2]  R1210     -1.5379874706268311e+00
    phi[3,2]  R1211     8.0217711627483368e-02
    phi[3,2]  R1212     -2.3345034122467041e+00
    phi[3,2]  R1213     -1.2938904762268066e+00
    phi[3,2]  R1214     -0.0697346180677414
    phi[3,2]  R1215     -2.0384807586669922e+00
    phi[3,2]  R1216     2.5508012771606445e+00
    phi[3,2]  R1217     -2.9807372093200684e+00
    phi[3,2]  R1218     1.6916140317916870e+00
    phi[3,2]  R1219     -3.4535737037658691e+00
    phi[3,2]  R1220     -2.1824295520782471e+00
    phi[3,2]  R1221     -7.9791349172592163e-01
    phi[3,2]  R1222     -8.0982875823974609e-01
    phi[3,2]  R1223     3.2894369959831238e-01
    phi[3,2]  R1224     -6.9238132238388062e-01
    phi[3,2]  R1225     1.5342128276824951e+00
    phi[3,2]  R1226     -8.6259663105010986e-01
    phi[3,2]  R1227     1.3764312267303467e+00
    phi[3,2]  R1228     8.2337492704391479e-01
    phi[3,2]  R1229     -1.1054385900497437e+00
    phi[3,2]  R1230     -2.5875790119171143e+00
    phi[3,2]  R1231     -3.1252326965332031e+00
    phi[3,2]  R1232     -1.9712796211242676e+00
    phi[3,2]  R1233     -1.4752852916717529e+00
    phi[3,2]  R1234     9.5281016826629639e-01
    phi[3,2]  R1235     2.7158682346343994e+00
    phi[3,2]  R1236     -1.1227324008941650e+00
    phi[3,2]  R1237     -2.5368649959564209e+00
    phi[3,2]  R1238     2.7073416113853455e-01
    phi[3,2]  R1239     -1.8868306875228882e+00
    phi[3,2]  R1240     1.2134937942028046e-01
    phi[3,2]  R1241     -2.0222475528717041e+00
    phi[3,2]  R1242     -2.1279733180999756e+00
    phi[3,2]  R1243     -1.4288482069969177e-01
    phi[3,2]  R1244     -1.0307883024215698e+00
    phi[3,10]  R27       1
    phi[3,10]  R28       1
    phi[3,10]  R90       -1
    phi[3,10]  R1245     -3.0999999046325684e+00
    phi[3,10]  R1246     -3.0999999046325684e+00
    phi[3,10]  R1247     -2.2400000095367432e+00
    phi[3,10]  R1248     -2.2400000095367432e+00
    phi[3,10]  R1249     -3.0999999046325684e+00
    phi[3,10]  R1250     -3.0999999046325684e+00
    phi[3,10]  R1251     -2.5699999332427979e+00
    phi[3,10]  R1252     -2.5699999332427979e+00
    phi[3,10]  R1253     -3.0999999046325684e+00
    phi[3,10]  R1254     -3.0999999046325684e+00
    phi[3,10]  R1255     -2.0899999141693115e+00
    phi[3,10]  R1256     -2.0899999141693115e+00
    phi[3,10]  R1257     -3.0999999046325684e+00
    phi[3,10]  R1258     -3.0999999046325684e+00
    phi[3,10]  R1259     0.682270048509034
    phi[3,10]  R1260     1.6301953792572021e+00
    phi[3,10]  R1261     2.4280086408212940e+00
    phi[3,10]  R1262     1.85371732711792
    phi[3,10]  R1263     8.3064395189285278e-01
    phi[3,10]  R1264     -1.6890417337417603e+00
    phi[3,10]  R1265     1.6244244575500488e+00
    phi[3,10]  R1266     1.3833212852478027e-01
    phi[3,10]  R1267     -1.2938052415847778e+00
    phi[3,10]  R1268     4.7077560424804688e-01
    phi[3,10]  R1269     -2.5367214679718018e+00
    phi[3,10]  R1270     -3.5966901779174805e+00
    phi[3,10]  R1271     -2.6237609386444092e+00
    phi[3,10]  R1272     -3.1710565090179443e+00
    phi[3,10]  R1273     -2.1854300498962402e+00
    phi[3,10]  R1274     -2.4231557846069336e+00
    phi[3,10]  R1275     -2.6395745277404785e+00
    phi[3,10]  R1276     -5.8699674904346466e-02
    phi[3,10]  R1277     -2.2481372356414795e+00
    phi[3,10]  R1278     -1.4937937259674072e+00
    phi[3,10]  R1279     -1.3759787082672119e+00
    phi[3,10]  R1280     -4.7226530313491821e-01
    phi[3,10]  R1281     -1.9111098051071167e+00
    phi[3,10]  R1282     -2.4730424880981445e+00
    phi[3,10]  R1283     -2.4188549518585205e+00
    phi[3,10]  R1284     -2.8335824012756348e+00
    phi[3,10]  R1285     -2.4559917449951172e+00
    phi[3,10]  R1286     -2.1814482212066650e+00
    phi[3,10]  R1287     -2.8965513706207275e+00
    phi[3,10]  R1288     -2.5799529552459717e+00
    phi[3,10]  R1289     -1.5517382621765137e+00
    phi[3,10]  R1290     -2.2106435298919678e+00
    phi[3,10]  R1291     -2.5730376243591309e+00
    phi[3,10]  R1292     -9.8869937658309937e-01
    phi[3,10]  R1293     -1.5317547321319580e+00
    phi[3,10]  R1294     -1.7015953063964844e+00
    phi[3,10]  R1295     -2.0936355590820312e+00
    phi[3,10]  R1296     -2.0742316246032715e+00
    phi[3,10]  R1297     -1.1329267024993896e+00
    phi[3,10]  R1298     1.7403774261474609e+00
    phi[3,10]  R1299     7.3694744217316011e-01
    phi[3,10]  R1300     1.2157616615295410e+00
    phi[3,10]  R1301     2.2519853115081787e+00
    phi[3,10]  R1302     1.2167718410491943e+00
    phi[3,10]  R1303     1.1877001523971558e+00
    phi[3,10]  R1304     2.8831294178962708e-01
    phi[3,10]  R1305     8.8821685314178467e-01
    phi[3,10]  R1306     -3.3819119930267334e+00
    phi[3,10]  R1307     -1.9029613733291626e+00
    phi[3,10]  R1308     -2.3586440086364746e+00
    phi[3,10]  R1309     -1.4233530759811401e+00
    phi[3,10]  R1310     -2.1625223159790039e+00
    phi[3,10]  R1311     -1.3798239827156067e-01
    phi[3,10]  R1312     -7.4420952796936035e-01
    phi[3,10]  R1313     7.0488780736923218e-01
    phi[3,10]  R1314     -2.3711254596710205e+00
    phi[3,10]  R1315     -2.4104197025299072e+00
    phi[3,10]  R1316     -1.9223589897155762e+00
    phi[3,10]  R1317     -1.1683126688003540e+00
    phi[3,10]  R1318     -1.2077102661132812e+00
    phi[3,10]  R1319     -1.5435159206390381e-01
    phi[3,10]  R1320     9.5046776533126831e-01
    phi[3,10]  R1321     -6.8478327989578247e-01
    phi[3,10]  R1322     3.1802105903625488e-01
    phi[3,10]  R1323     3.8363108038902283e-01
    phi[3,10]  R1324     2.8353765606880188e-01
    phi[3,10]  R1325     -3.1203091144561768e+00
    phi[3,10]  R1326     5.8886861801147461e-01
    phi[3,10]  R1327     -1.5656492710113525e+00
    phi[3,10]  R1328     -1.3199291229248047e+00
    phi[3,10]  R1329     -5.0755888223648071e-01
    phi[3,10]  R1330     -1.2539684772491455e+00
    phi[3,10]  R1331     -6.6878181695938110e-01
    phi[3,10]  R1332     -5.6963956356048584e-01
    phi[3,10]  R1333     6.7136961221694946e-01
    phi[3,10]  R1334     -1.5048220157623291e+00
    phi[3,10]  R1335     -9.6198284626007080e-01
    phi[10,3]  R27       -1
    phi[10,3]  R90       1
    phi[10,3]  R91       1
    phi[10,3]  R1336     -3.0999999046325684e+00
    phi[10,3]  R1337     -3.0999999046325684e+00
    phi[10,3]  R1338     -2.2400000095367432e+00
    phi[10,3]  R1339     -2.2400000095367432e+00
    phi[10,3]  R1340     -3.0999999046325684e+00
    phi[10,3]  R1341     -3.0999999046325684e+00
    phi[10,3]  R1342     -2.5699999332427979e+00
    phi[10,3]  R1343     -2.5699999332427979e+00
    phi[10,3]  R1344     -3.0999999046325684e+00
    phi[10,3]  R1345     -3.0999999046325684e+00
    phi[10,3]  R1346     -2.0899999141693115e+00
    phi[10,3]  R1347     -2.0899999141693115e+00
    phi[10,3]  R1348     -3.0999999046325684e+00
    phi[10,3]  R1349     -3.0999999046325684e+00
    phi[10,3]  R1350     1.7403774261474609e+00
    phi[10,3]  R1351     7.3694744217316011e-01
    phi[10,3]  R1352     1.2157616615295410e+00
    phi[10,3]  R1353     2.2519853115081787e+00
    phi[10,3]  R1354     1.2167718410491943e+00
    phi[10,3]  R1355     1.1877001523971558e+00
    phi[10,3]  R1356     2.8831294178962708e-01
    phi[10,3]  R1357     8.8821685314178467e-01
    phi[10,3]  R1358     -3.3819119930267334e+00
    phi[10,3]  R1359     -1.9029613733291626e+00
    phi[10,3]  R1360     -2.3586440086364746e+00
    phi[10,3]  R1361     -1.4233530759811401e+00
    phi[10,3]  R1362     -2.1625223159790039e+00
    phi[10,3]  R1363     -1.3798239827156067e-01
    phi[10,3]  R1364     -7.4420952796936035e-01
    phi[10,3]  R1365     7.0488780736923218e-01
    phi[10,3]  R1366     -2.3711254596710205e+00
    phi[10,3]  R1367     -2.4104197025299072e+00
    phi[10,3]  R1368     -1.9223589897155762e+00
    phi[10,3]  R1369     -1.1683126688003540e+00
    phi[10,3]  R1370     -1.2077102661132812e+00
    phi[10,3]  R1371     -1.5435159206390381e-01
    phi[10,3]  R1372     9.5046776533126831e-01
    phi[10,3]  R1373     -6.8478327989578247e-01
    phi[10,3]  R1374     3.1802105903625488e-01
    phi[10,3]  R1375     3.8363108038902283e-01
    phi[10,3]  R1376     2.8353765606880188e-01
    phi[10,3]  R1377     -3.1203091144561768e+00
    phi[10,3]  R1378     5.8886861801147461e-01
    phi[10,3]  R1379     -1.5656492710113525e+00
    phi[10,3]  R1380     -1.3199291229248047e+00
    phi[10,3]  R1381     -5.0755888223648071e-01
    phi[10,3]  R1382     -1.2539684772491455e+00
    phi[10,3]  R1383     -6.6878181695938110e-01
    phi[10,3]  R1384     -5.6963956356048584e-01
    phi[10,3]  R1385     6.7136961221694946e-01
    phi[10,3]  R1386     -1.5048220157623291e+00
    phi[10,3]  R1387     -9.6198284626007080e-01
    phi[10,3]  R1388     0.682270048509034
    phi[10,3]  R1389     1.6301953792572021e+00
    phi[10,3]  R1390     2.4280086408212940e+00
    phi[10,3]  R1391     1.85371732711792
    phi[10,3]  R1392     8.3064395189285278e-01
    phi[10,3]  R1393     -1.6890417337417603e+00
    phi[10,3]  R1394     1.6244244575500488e+00
    phi[10,3]  R1395     1.3833212852478027e-01
    phi[10,3]  R1396     -1.2938052415847778e+00
    phi[10,3]  R1397     4.7077560424804688e-01
    phi[10,3]  R1398     -2.5367214679718018e+00
    phi[10,3]  R1399     -3.5966901779174805e+00
    phi[10,3]  R1400     -2.6237609386444092e+00
    phi[10,3]  R1401     -3.1710565090179443e+00
    phi[10,3]  R1402     -2.1854300498962402e+00
    phi[10,3]  R1403     -2.4231557846069336e+00
    phi[10,3]  R1404     -2.6395745277404785e+00
    phi[10,3]  R1405     -5.8699674904346466e-02
    phi[10,3]  R1406     -2.2481372356414795e+00
    phi[10,3]  R1407     -1.4937937259674072e+00
    phi[10,3]  R1408     -1.3759787082672119e+00
    phi[10,3]  R1409     -4.7226530313491821e-01
    phi[10,3]  R1410     -1.9111098051071167e+00
    phi[10,3]  R1411     -2.4730424880981445e+00
    phi[10,3]  R1412     -2.4188549518585205e+00
    phi[10,3]  R1413     -2.8335824012756348e+00
    phi[10,3]  R1414     -2.4559917449951172e+00
    phi[10,3]  R1415     -2.1814482212066650e+00
    phi[10,3]  R1416     -2.8965513706207275e+00
    phi[10,3]  R1417     -2.5799529552459717e+00
    phi[10,3]  R1418     -1.5517382621765137e+00
    phi[10,3]  R1419     -2.2106435298919678e+00
    phi[10,3]  R1420     -2.5730376243591309e+00
    phi[10,3]  R1421     -9.8869937658309937e-01
    phi[10,3]  R1422     -1.5317547321319580e+00
    phi[10,3]  R1423     -1.7015953063964844e+00
    phi[10,3]  R1424     -2.0936355590820312e+00
    phi[10,3]  R1425     -2.0742316246032715e+00
    phi[10,3]  R1426     -1.1329267024993896e+00
    phi[3,12]  R27       1
    phi[3,12]  R28       1
    phi[3,12]  R29       -2.3659294656801513e+00
    phi[3,12]  R30       1.61396413869553
    phi[3,12]  R31       7.2004346022925292e-01
    phi[3,12]  R32       -1.1164516108306279e+00
    phi[3,12]  R33       -1.6949008548941715e+00
    phi[3,12]  R34       4.8224095273947909e-01
    phi[3,12]  R35       -6.2122488005295651e-01
    phi[3,12]  R100      -1
    phi[3,12]  R1427     -5.46592937031272
    phi[3,12]  R1428     -7.3407043895241708e-01
    phi[3,12]  R1429     -6.2603587084121326e-01
    phi[3,12]  R1430     -3.8539641482322731e+00
    phi[3,12]  R1431     -2.3799564444033154e+00
    phi[3,12]  R1432     -3.8200433648618213e+00
    phi[3,12]  R1433     -3.6864515440734258e+00
    phi[3,12]  R1434     -1.45354832241217
    phi[3,12]  R1435     -4.79490075952674
    phi[3,12]  R1436     -1.4050990497383968e+00
    phi[3,12]  R1437     -1.6077589614298324e+00
    phi[3,12]  R1438     -2.5722408669087908e+00
    phi[3,12]  R1439     -3.7212247846855249e+00
    phi[3,12]  R1440     -2.4787750245796119e+00
    phi[3,12]  R1441     -9.29561623230768e-08
    phi[3,12]  R1442     -6.7265640169011931e-08
    phi[3,12]  R1443     -3.4240644541938536e-08
    phi[3,12]  R1444     -0.00823476086823094
    phi[3,12]  R1445     -1.0922271328297928e-02
    phi[3,12]  R1446     -2.0787536397728705e+00
    phi[3,12]  R1447     -8.1229889454864157e-01
    phi[3,12]  R1448     -1.4807132214810110e+00
    phi[3,12]  R1449     -1.4557581500405918e+00
    phi[3,12]  R1450     -1.6163573956615096e-01
    phi[3,12]  R1451     -1.0217775504176232e+00
    phi[3,12]  R1452     -1.0182922830811525e+00
    phi[3,12]  R1453     -6.8294978652697913e-01
    phi[3,12]  R1454     -3.4945908649154589e-01
    phi[3,12]  R1455     -2.5389185806831693e-01
    phi[3,12]  R1456     -3.3395624333024143e-01
    phi[3,12]  R1457     -2.6102337434969103e-01
    phi[3,12]  R1458     -0.328144204502016
    phi[3,12]  R1459     -5.2393047796545233e-01
    phi[3,12]  R1460     -1.29272149408092
    phi[3,12]  R1461     -1.6184974337791473e+00
    phi[3,12]  R1462     -4.0462496988359731e-01
    phi[3,12]  R1463     -4.6910971894158782e-01
    phi[3,12]  R1464     -4.4371516043961146e-01
    phi[3,12]  R1465     -3.1870571695011840e-01
    phi[3,12]  R1466     -3.1971656436742135e-01
    phi[3,12]  R1467     -1.2269371367158721e+00
    phi[3,12]  R1468     -3.2833155528722036e-01
    phi[3,12]  R1469     -3.3318263948355842e-01
    phi[3,12]  R1470     -1.0523250356304972e+00
    phi[3,12]  R1471     -5.3253240201676810e-01
    phi[3,12]  R1472     -7.3799179447586871e-01
    phi[3,12]  R1473     -1.7792000000483128e+00
    phi[3,12]  R1474     -2.4313436779122122e-01
    phi[3,12]  R1475     -3.2208234582916995e-01
    phi[3,12]  R1476     -3.2908772461991065e-01
    phi[3,12]  R1477     -3.3459681304874023e-01
    phi[3,12]  R1478     -3.6038401144646315e-01
    phi[3,12]  R1479     -3.6741463067336311e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1480     -3.0999999046325684e+00
    phi[4,5]  R1481     -3.0999999046325684e+00
    phi[4,5]  R1482     -2.2400000095367432e+00
    phi[4,5]  R1483     -2.2400000095367432e+00
    phi[4,5]  R1484     -3.0999999046325684e+00
    phi[4,5]  R1485     -3.0999999046325684e+00
    phi[4,5]  R1486     -2.5699999332427979e+00
    phi[4,5]  R1487     -2.5699999332427979e+00
    phi[4,5]  R1488     -3.0999999046325684e+00
    phi[4,5]  R1489     -3.0999999046325684e+00
    phi[4,5]  R1490     -2.0899999141693115e+00
    phi[4,5]  R1491     -2.0899999141693115e+00
    phi[4,5]  R1492     -3.0999999046325684e+00
    phi[4,5]  R1493     -3.0999999046325684e+00
    phi[4,5]  R1494     6.8718397617340088e-01
    phi[4,5]  R1495     2.1385915279388428e+00
    phi[4,5]  R1496     6.9518762826919556e-01
    phi[4,5]  R1497     8.8087493181228638e-01
    phi[4,5]  R1498     6.4752191305160522e-01
    phi[4,5]  R1499     3.6792182922363281e-01
    phi[4,5]  R1500     1.4422966241836548e+00
    phi[4,5]  R1501     -1.7382947206497192e+00
    phi[4,5]  R1502     2.6721981167793274e-01
    phi[4,5]  R1503     2.0653177052736282e-02
    phi[4,5]  R1504     -9.3247991800308228e-01
    phi[4,5]  R1505     -3.2377424240112305e+00
    phi[4,5]  R1506     -1.3001575469970703e+00
    phi[4,5]  R1507     -3.4299058914184570e+00
    phi[4,5]  R1508     -2.4514722824096680e+00
    phi[4,5]  R1509     -1.3005512952804565e+00
    phi[4,5]  R1510     -2.8537175655364990e+00
    phi[4,5]  R1511     -1.9666780233383179e+00
    phi[4,5]  R1512     -3.7003839015960693e+00
    phi[4,5]  R1513     -2.3483183383941650e+00
    phi[4,5]  R1514     -1.6626055240631104e+00
    phi[4,5]  R1515     -2.1448037028312683e-01
    phi[4,5]  R1516     -1.5593667030334473e+00
    phi[4,5]  R1517     -1.2732055187225342e+00
    phi[4,5]  R1518     -2.9742330312728882e-01
    phi[4,5]  R1519     -6.4270585775375366e-01
    phi[4,5]  R1520     -2.8861966133117676e+00
    phi[4,5]  R1521     -8.6732476949691772e-01
    phi[4,5]  R1522     -7.1418327093124390e-01
    phi[4,5]  R1523     8.4753161668777466e-01
    phi[4,5]  R1524     -1.5988796949386597e+00
    phi[4,5]  R1525     -1.3026838302612305e+00
    phi[4,5]  R1526     -1.3014854192733765e+00
    phi[4,5]  R1527     1.2574446201324463e-01
    phi[4,5]  R1528     -1.5422412157058716e+00
    phi[4,5]  R1529     2.3134428262710571e-01
    phi[4,5]  R1530     6.3230311870574951e-01
    phi[4,5]  R1531     8.3675122261047363e-01
    phi[4,5]  R1532     1.2212105840444565e-01
    phi[4,5]  R1533     1.3016896247863770e+00
    phi[4,5]  R1534     1.8649223446846008e-01
    phi[4,5]  R1535     2.1933400630950928e+00
    phi[4,5]  R1536     1.8134841918945312e+00
    phi[4,5]  R1537     3.7258749008178711e+00
    phi[4,5]  R1538     1.7429764270782471e+00
    phi[4,5]  R1539     -5.8580398559570312e-01
    phi[4,5]  R1540     -3.3902924060821533e+00
    phi[4,5]  R1541     9.3005174398422241e-01
    phi[4,5]  R1542     -2.4210202693939209e+00
    phi[4,5]  R1543     -9.1783213615417480e-01
    phi[4,5]  R1544     -1.2872171401977539e+00
    phi[4,5]  R1545     -7.1942037343978882e-01
    phi[4,5]  R1546     -2.5371129512786865e+00
    phi[4,5]  R1547     -2.9636917114257812e+00
    phi[4,5]  R1548     -2.0776042938232422e+00
    phi[4,5]  R1549     -1.1963371038436890e+00
    phi[4,5]  R1550     -1.4105409383773804e+00
    phi[4,5]  R1551     -2.3222486972808838e+00
    phi[4,5]  R1552     -1.2640994787216187e+00
    phi[4,5]  R1553     -1.8846763372421265e+00
    phi[4,5]  R1554     -2.2352957725524902e+00
    phi[4,5]  R1555     -1.7084631919860840e+00
    phi[4,5]  R1556     -1.2250980138778687e+00
    phi[4,5]  R1557     2.8561696410179138e-01
    phi[4,5]  R1558     -7.9859215021133423e-01
    phi[4,5]  R1559     -5.5025297403335571e-01
    phi[4,5]  R1560     -1.0222491025924683e+00
    phi[4,5]  R1561     -1.1748281717300415e+00
    phi[4,5]  R1562     -2.1220145225524902e+00
    phi[4,5]  R1563     -8.3233064413070679e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1564     -3.0999999046325684e+00
    phi[5,4]  R1565     -3.0999999046325684e+00
    phi[5,4]  R1566     -2.2400000095367432e+00
    phi[5,4]  R1567     -2.2400000095367432e+00
    phi[5,4]  R1568     -3.0999999046325684e+00
    phi[5,4]  R1569     -3.0999999046325684e+00
    phi[5,4]  R1570     -2.5699999332427979e+00
    phi[5,4]  R1571     -2.5699999332427979e+00
    phi[5,4]  R1572     -3.0999999046325684e+00
    phi[5,4]  R1573     -3.0999999046325684e+00
    phi[5,4]  R1574     -2.0899999141693115e+00
    phi[5,4]  R1575     -2.0899999141693115e+00
    phi[5,4]  R1576     -3.0999999046325684e+00
    phi[5,4]  R1577     -3.0999999046325684e+00
    phi[5,4]  R1578     1.8649223446846008e-01
    phi[5,4]  R1579     2.1933400630950928e+00
    phi[5,4]  R1580     1.8134841918945312e+00
    phi[5,4]  R1581     3.7258749008178711e+00
    phi[5,4]  R1582     1.7429764270782471e+00
    phi[5,4]  R1583     -5.8580398559570312e-01
    phi[5,4]  R1584     -3.3902924060821533e+00
    phi[5,4]  R1585     9.3005174398422241e-01
    phi[5,4]  R1586     -2.4210202693939209e+00
    phi[5,4]  R1587     -9.1783213615417480e-01
    phi[5,4]  R1588     -1.2872171401977539e+00
    phi[5,4]  R1589     -7.1942037343978882e-01
    phi[5,4]  R1590     -2.5371129512786865e+00
    phi[5,4]  R1591     -2.9636917114257812e+00
    phi[5,4]  R1592     -2.0776042938232422e+00
    phi[5,4]  R1593     -1.1963371038436890e+00
    phi[5,4]  R1594     -1.4105409383773804e+00
    phi[5,4]  R1595     -2.3222486972808838e+00
    phi[5,4]  R1596     -1.2640994787216187e+00
    phi[5,4]  R1597     -1.8846763372421265e+00
    phi[5,4]  R1598     -2.2352957725524902e+00
    phi[5,4]  R1599     -1.7084631919860840e+00
    phi[5,4]  R1600     -1.2250980138778687e+00
    phi[5,4]  R1601     2.8561696410179138e-01
    phi[5,4]  R1602     -7.9859215021133423e-01
    phi[5,4]  R1603     -5.5025297403335571e-01
    phi[5,4]  R1604     -1.0222491025924683e+00
    phi[5,4]  R1605     -1.1748281717300415e+00
    phi[5,4]  R1606     -2.1220145225524902e+00
    phi[5,4]  R1607     -8.3233064413070679e-01
    phi[5,4]  R1608     6.8718397617340088e-01
    phi[5,4]  R1609     2.1385915279388428e+00
    phi[5,4]  R1610     6.9518762826919556e-01
    phi[5,4]  R1611     8.8087493181228638e-01
    phi[5,4]  R1612     6.4752191305160522e-01
    phi[5,4]  R1613     3.6792182922363281e-01
    phi[5,4]  R1614     1.4422966241836548e+00
    phi[5,4]  R1615     -1.7382947206497192e+00
    phi[5,4]  R1616     2.6721981167793274e-01
    phi[5,4]  R1617     2.0653177052736282e-02
    phi[5,4]  R1618     -9.3247991800308228e-01
    phi[5,4]  R1619     -3.2377424240112305e+00
    phi[5,4]  R1620     -1.3001575469970703e+00
    phi[5,4]  R1621     -3.4299058914184570e+00
    phi[5,4]  R1622     -2.4514722824096680e+00
    phi[5,4]  R1623     -1.3005512952804565e+00
    phi[5,4]  R1624     -2.8537175655364990e+00
    phi[5,4]  R1625     -1.9666780233383179e+00
    phi[5,4]  R1626     -3.7003839015960693e+00
    phi[5,4]  R1627     -2.3483183383941650e+00
    phi[5,4]  R1628     -1.6626055240631104e+00
    phi[5,4]  R1629     -2.1448037028312683e-01
    phi[5,4]  R1630     -1.5593667030334473e+00
    phi[5,4]  R1631     -1.2732055187225342e+00
    phi[5,4]  R1632     -2.9742330312728882e-01
    phi[5,4]  R1633     -6.4270585775375366e-01
    phi[5,4]  R1634     -2.8861966133117676e+00
    phi[5,4]  R1635     -8.6732476949691772e-01
    phi[5,4]  R1636     -7.1418327093124390e-01
    phi[5,4]  R1637     8.4753161668777466e-01
    phi[5,4]  R1638     -1.5988796949386597e+00
    phi[5,4]  R1639     -1.3026838302612305e+00
    phi[5,4]  R1640     -1.3014854192733765e+00
    phi[5,4]  R1641     1.2574446201324463e-01
    phi[5,4]  R1642     -1.5422412157058716e+00
    phi[5,4]  R1643     2.3134428262710571e-01
    phi[5,4]  R1644     6.3230311870574951e-01
    phi[5,4]  R1645     8.3675122261047363e-01
    phi[5,4]  R1646     1.2212105840444565e-01
    phi[5,4]  R1647     1.3016896247863770e+00
    phi[11,4]  R36       -1
    phi[11,4]  R38       -1.0876942707822710e+00
    phi[11,4]  R39       -1.3864910604887788e+00
    phi[11,4]  R40       -8.0873759611484930e-01
    phi[11,4]  R41       1.7029626216183824e+00
    phi[11,4]  R42       1.5535340012573573e+00
    phi[11,4]  R43       1.2092606776728023e+00
    phi[11,4]  R44       -8.6802718594208583e-01
    phi[11,4]  R99       1
    phi[11,4]  R1648     -2.0123056338502971e+00
    phi[11,4]  R1649     -4.18769417541484
    phi[11,4]  R1650     -8.5350894904796437e-01
    phi[11,4]  R1651     -3.6264910700255220e+00
    phi[11,4]  R1652     -2.2912623085177191e+00
    phi[11,4]  R1653     -3.9087375007474177e+00
    phi[11,4]  R1654     -4.2729625548611807e+00
    phi[11,4]  R1655     -8.6703731162441544e-01
    phi[11,4]  R1656     -4.6535339058899261e+00
    phi[11,4]  R1657     -1.5464659033752111e+00
    phi[11,4]  R1658     -3.2992605918421138e+00
    phi[11,4]  R1659     -8.8073923649650920e-01
    phi[11,4]  R1660     -2.2319727186904825e+00
    phi[11,4]  R1661     -3.9680270905746542e+00
    phi[11,4]  R1662     -1.1492887197791268e-01
    phi[11,4]  R1663     -1.2708066713696686e-01
    phi[11,4]  R1664     -1.5472686457664031e-01
    phi[11,4]  R1665     -1.7322812867312520e-01
    phi[11,4]  R1666     -1.8487804992361745e-01
    phi[11,4]  R1667     -2.0713471029243580e-01
    phi[11,4]  R1668     -2.9660523295268693e-01
    phi[11,4]  R1669     -3.0263012327936645e-01
    phi[11,4]  R1670     -9.1697101924789992e-01
    phi[11,4]  R1671     -6.6169094343716550e-01
    phi[11,4]  R1672     -3.3108663563592478e-01
    phi[11,4]  R1673     -8.6748086822997816e-01
    phi[11,4]  R1674     -6.2567869814187560e-01
    phi[11,4]  R1675     -1.1724410904771974e+00
    phi[11,4]  R1676     -4.1467758091223850e-01
    phi[11,4]  R1677     -4.3399582915296842e-01
    phi[11,4]  R1678     -1.4621575071081472e+00
    phi[11,4]  R1679     -4.4266438143791342e-01
    phi[11,4]  R1680     -1.3041457724041026e+00
    phi[11,4]  R1681     -8.2780256738640334e-01
    phi[11,4]  R1682     -2.8965250579198765e-01
    phi[11,4]  R1683     -3.8828555880517213e-01
    phi[11,4]  R1684     -0.398076161313478
    phi[11,4]  R1685     -4.0732864888552456e-01
    phi[11,4]  R1686     -0.458974073174739
    phi[11,4]  R1687     -8.5889490548089509e-01
    phi[11,4]  R1688     -2.0909317488390542e+00
    phi[11,4]  R1689     -5.6125552787424571e-01
    phi[11,4]  R1690     -0.618865403700302
    phi[11,4]  R1691     -8.1743945375245319e-01
    phi[11,4]  R1692     -1.5980253154345925e-01
    phi[11,4]  R1693     -2.5226106824148720e-01
    phi[11,4]  R1694     -2.7854899162840008e-01
    phi[11,4]  R1695     -3.1183969021285390e-01
    phi[11,4]  R1696     -1.3361817705508146e+00
    phi[11,4]  R1697     -0.60104504812878
    phi[11,4]  R1698     -7.5007036647320713e-01
    phi[11,4]  R1699     -7.9147361412196027e-01
    phi[11,4]  R1700     -8.1156542265006870e-01
    phi[11,4]  R1701     -8.3715973360070350e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1702     -3.0999999046325684e+00
    phi[5,6]  R1703     -3.0999999046325684e+00
    phi[5,6]  R1704     -2.2400000095367432e+00
    phi[5,6]  R1705     -2.2400000095367432e+00
    phi[5,6]  R1706     -3.0999999046325684e+00
    phi[5,6]  R1707     -3.0999999046325684e+00
    phi[5,6]  R1708     -2.5699999332427979e+00
    phi[5,6]  R1709     -2.5699999332427979e+00
    phi[5,6]  R1710     -3.0999999046325684e+00
    phi[5,6]  R1711     -3.0999999046325684e+00
    phi[5,6]  R1712     -2.0899999141693115e+00
    phi[5,6]  R1713     -2.0899999141693115e+00
    phi[5,6]  R1714     -3.0999999046325684e+00
    phi[5,6]  R1715     -3.0999999046325684e+00
    phi[5,6]  R1716     1.8649223446846008e-01
    phi[5,6]  R1717     2.1933400630950928e+00
    phi[5,6]  R1718     1.8134841918945312e+00
    phi[5,6]  R1719     3.7258749008178711e+00
    phi[5,6]  R1720     1.7429764270782471e+00
    phi[5,6]  R1721     -5.8580398559570312e-01
    phi[5,6]  R1722     -3.3902924060821533e+00
    phi[5,6]  R1723     9.3005174398422241e-01
    phi[5,6]  R1724     -2.4210202693939209e+00
    phi[5,6]  R1725     -9.1783213615417480e-01
    phi[5,6]  R1726     -1.2872171401977539e+00
    phi[5,6]  R1727     -7.1942037343978882e-01
    phi[5,6]  R1728     -2.5371129512786865e+00
    phi[5,6]  R1729     -2.9636917114257812e+00
    phi[5,6]  R1730     -2.0776042938232422e+00
    phi[5,6]  R1731     -1.1963371038436890e+00
    phi[5,6]  R1732     -1.4105409383773804e+00
    phi[5,6]  R1733     -2.3222486972808838e+00
    phi[5,6]  R1734     -1.2640994787216187e+00
    phi[5,6]  R1735     -1.8846763372421265e+00
    phi[5,6]  R1736     -2.2352957725524902e+00
    phi[5,6]  R1737     -1.7084631919860840e+00
    phi[5,6]  R1738     -1.2250980138778687e+00
    phi[5,6]  R1739     2.8561696410179138e-01
    phi[5,6]  R1740     -7.9859215021133423e-01
    phi[5,6]  R1741     -5.5025297403335571e-01
    phi[5,6]  R1742     -1.0222491025924683e+00
    phi[5,6]  R1743     -1.1748281717300415e+00
    phi[5,6]  R1744     -2.1220145225524902e+00
    phi[5,6]  R1745     -8.3233064413070679e-01
    phi[5,6]  R1746     4.6758142113685608e-01
    phi[5,6]  R1747     1.9361279010772705e+00
    phi[5,6]  R1748     1.9357725977897644e-01
    phi[5,6]  R1749     2.4240903854370117e+00
    phi[5,6]  R1750     -7.3627167940139771e-01
    phi[5,6]  R1751     -2.7017000317573547e-01
    phi[5,6]  R1752     -2.6191404461860657e-01
    phi[5,6]  R1753     1.0005730390548706e+00
    phi[5,6]  R1754     7.2080451250076294e-01
    phi[5,6]  R1755     -1.1659599095582962e-01
    phi[5,6]  R1756     -2.3821082115173340e+00
    phi[5,6]  R1757     -1.1491557359695435e+00
    phi[5,6]  R1758     -5.1121783256530762e-01
    phi[5,6]  R1759     -7.9473519325256348e-01
    phi[5,6]  R1760     -1.3403720855712891e+00
    phi[5,6]  R1761     -1.2952812016010284e-01
    phi[5,6]  R1762     -4.9288272857666016e-01
    phi[5,6]  R1763     -0.776736855506897
    phi[5,6]  R1764     -1.3343678712844849e+00
    phi[5,6]  R1765     -5.2720528841018677e-01
    phi[5,6]  R1766     -1.8961359262466431e+00
    phi[5,6]  R1767     -0.0777873620390892
    phi[5,6]  R1768     -2.2916192188858986e-02
    phi[5,6]  R1769     -3.6812925338745117e-01
    phi[5,6]  R1770     -7.4747240543365479e-01
    phi[5,6]  R1771     -2.4280178546905518e+00
    phi[5,6]  R1772     -1.0568945407867432e+00
    phi[5,6]  R1773     -4.5507332682609558e-01
    phi[5,6]  R1774     -6.2923830747604370e-01
    phi[5,6]  R1775     -3.9400303363800049e-01
    phi[5,6]  R1776     -5.2687156200408936e-01
    phi[5,6]  R1777     -8.3737695217132568e-01
    phi[5,6]  R1778     -5.9903395175933838e-01
    phi[5,6]  R1779     -1.0130881071090698e+00
    phi[5,6]  R1780     -1.7318416833877563e+00
    phi[5,6]  R1781     -1.2064383029937744e+00
    phi[5,6]  R1782     -2.1826109886169434e+00
    phi[5,6]  R1783     -1.6034749746322632e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R1784     -3.0999999046325684e+00
    phi[6,5]  R1785     -3.0999999046325684e+00
    phi[6,5]  R1786     -2.2400000095367432e+00
    phi[6,5]  R1787     -2.2400000095367432e+00
    phi[6,5]  R1788     -3.0999999046325684e+00
    phi[6,5]  R1789     -3.0999999046325684e+00
    phi[6,5]  R1790     -2.5699999332427979e+00
    phi[6,5]  R1791     -2.5699999332427979e+00
    phi[6,5]  R1792     -3.0999999046325684e+00
    phi[6,5]  R1793     -3.0999999046325684e+00
    phi[6,5]  R1794     -2.0899999141693115e+00
    phi[6,5]  R1795     -2.0899999141693115e+00
    phi[6,5]  R1796     -3.0999999046325684e+00
    phi[6,5]  R1797     -3.0999999046325684e+00
    phi[6,5]  R1798     4.6758142113685608e-01
    phi[6,5]  R1799     1.9361279010772705e+00
    phi[6,5]  R1800     1.9357725977897644e-01
    phi[6,5]  R1801     2.4240903854370117e+00
    phi[6,5]  R1802     -7.3627167940139771e-01
    phi[6,5]  R1803     -2.7017000317573547e-01
    phi[6,5]  R1804     -2.6191404461860657e-01
    phi[6,5]  R1805     1.0005730390548706e+00
    phi[6,5]  R1806     7.2080451250076294e-01
    phi[6,5]  R1807     -1.1659599095582962e-01
    phi[6,5]  R1808     -2.3821082115173340e+00
    phi[6,5]  R1809     -1.1491557359695435e+00
    phi[6,5]  R1810     -5.1121783256530762e-01
    phi[6,5]  R1811     -7.9473519325256348e-01
    phi[6,5]  R1812     -1.3403720855712891e+00
    phi[6,5]  R1813     -1.2952812016010284e-01
    phi[6,5]  R1814     -4.9288272857666016e-01
    phi[6,5]  R1815     -0.776736855506897
    phi[6,5]  R1816     -1.3343678712844849e+00
    phi[6,5]  R1817     -5.2720528841018677e-01
    phi[6,5]  R1818     -1.8961359262466431e+00
    phi[6,5]  R1819     -0.0777873620390892
    phi[6,5]  R1820     -2.2916192188858986e-02
    phi[6,5]  R1821     -3.6812925338745117e-01
    phi[6,5]  R1822     -7.4747240543365479e-01
    phi[6,5]  R1823     -2.4280178546905518e+00
    phi[6,5]  R1824     -1.0568945407867432e+00
    phi[6,5]  R1825     -4.5507332682609558e-01
    phi[6,5]  R1826     -6.2923830747604370e-01
    phi[6,5]  R1827     -3.9400303363800049e-01
    phi[6,5]  R1828     -5.2687156200408936e-01
    phi[6,5]  R1829     -8.3737695217132568e-01
    phi[6,5]  R1830     -5.9903395175933838e-01
    phi[6,5]  R1831     -1.0130881071090698e+00
    phi[6,5]  R1832     -1.7318416833877563e+00
    phi[6,5]  R1833     -1.2064383029937744e+00
    phi[6,5]  R1834     -2.1826109886169434e+00
    phi[6,5]  R1835     -1.6034749746322632e+00
    phi[6,5]  R1836     1.8649223446846008e-01
    phi[6,5]  R1837     2.1933400630950928e+00
    phi[6,5]  R1838     1.8134841918945312e+00
    phi[6,5]  R1839     3.7258749008178711e+00
    phi[6,5]  R1840     1.7429764270782471e+00
    phi[6,5]  R1841     -5.8580398559570312e-01
    phi[6,5]  R1842     -3.3902924060821533e+00
    phi[6,5]  R1843     9.3005174398422241e-01
    phi[6,5]  R1844     -2.4210202693939209e+00
    phi[6,5]  R1845     -9.1783213615417480e-01
    phi[6,5]  R1846     -1.2872171401977539e+00
    phi[6,5]  R1847     -7.1942037343978882e-01
    phi[6,5]  R1848     -2.5371129512786865e+00
    phi[6,5]  R1849     -2.9636917114257812e+00
    phi[6,5]  R1850     -2.0776042938232422e+00
    phi[6,5]  R1851     -1.1963371038436890e+00
    phi[6,5]  R1852     -1.4105409383773804e+00
    phi[6,5]  R1853     -2.3222486972808838e+00
    phi[6,5]  R1854     -1.2640994787216187e+00
    phi[6,5]  R1855     -1.8846763372421265e+00
    phi[6,5]  R1856     -2.2352957725524902e+00
    phi[6,5]  R1857     -1.7084631919860840e+00
    phi[6,5]  R1858     -1.2250980138778687e+00
    phi[6,5]  R1859     2.8561696410179138e-01
    phi[6,5]  R1860     -7.9859215021133423e-01
    phi[6,5]  R1861     -5.5025297403335571e-01
    phi[6,5]  R1862     -1.0222491025924683e+00
    phi[6,5]  R1863     -1.1748281717300415e+00
    phi[6,5]  R1864     -2.1220145225524902e+00
    phi[6,5]  R1865     -8.3233064413070679e-01
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R1866     -3.0999999046325684e+00
    phi[6,7]  R1867     -3.0999999046325684e+00
    phi[6,7]  R1868     -2.2400000095367432e+00
    phi[6,7]  R1869     -2.2400000095367432e+00
    phi[6,7]  R1870     -3.0999999046325684e+00
    phi[6,7]  R1871     -3.0999999046325684e+00
    phi[6,7]  R1872     -2.5699999332427979e+00
    phi[6,7]  R1873     -2.5699999332427979e+00
    phi[6,7]  R1874     -3.0999999046325684e+00
    phi[6,7]  R1875     -3.0999999046325684e+00
    phi[6,7]  R1876     -2.0899999141693115e+00
    phi[6,7]  R1877     -2.0899999141693115e+00
    phi[6,7]  R1878     -3.0999999046325684e+00
    phi[6,7]  R1879     -3.0999999046325684e+00
    phi[6,7]  R1880     4.6758142113685608e-01
    phi[6,7]  R1881     1.9361279010772705e+00
    phi[6,7]  R1882     1.9357725977897644e-01
    phi[6,7]  R1883     2.4240903854370117e+00
    phi[6,7]  R1884     -7.3627167940139771e-01
    phi[6,7]  R1885     -2.7017000317573547e-01
    phi[6,7]  R1886     -2.6191404461860657e-01
    phi[6,7]  R1887     1.0005730390548706e+00
    phi[6,7]  R1888     7.2080451250076294e-01
    phi[6,7]  R1889     -1.1659599095582962e-01
    phi[6,7]  R1890     -2.3821082115173340e+00
    phi[6,7]  R1891     -1.1491557359695435e+00
    phi[6,7]  R1892     -5.1121783256530762e-01
    phi[6,7]  R1893     -7.9473519325256348e-01
    phi[6,7]  R1894     -1.3403720855712891e+00
    phi[6,7]  R1895     -1.2952812016010284e-01
    phi[6,7]  R1896     -4.9288272857666016e-01
    phi[6,7]  R1897     -0.776736855506897
    phi[6,7]  R1898     -1.3343678712844849e+00
    phi[6,7]  R1899     -5.2720528841018677e-01
    phi[6,7]  R1900     -1.8961359262466431e+00
    phi[6,7]  R1901     -0.0777873620390892
    phi[6,7]  R1902     -2.2916192188858986e-02
    phi[6,7]  R1903     -3.6812925338745117e-01
    phi[6,7]  R1904     -7.4747240543365479e-01
    phi[6,7]  R1905     -2.4280178546905518e+00
    phi[6,7]  R1906     -1.0568945407867432e+00
    phi[6,7]  R1907     -4.5507332682609558e-01
    phi[6,7]  R1908     -6.2923830747604370e-01
    phi[6,7]  R1909     -3.9400303363800049e-01
    phi[6,7]  R1910     -5.2687156200408936e-01
    phi[6,7]  R1911     -8.3737695217132568e-01
    phi[6,7]  R1912     -5.9903395175933838e-01
    phi[6,7]  R1913     -1.0130881071090698e+00
    phi[6,7]  R1914     -1.7318416833877563e+00
    phi[6,7]  R1915     -1.2064383029937744e+00
    phi[6,7]  R1916     -2.1826109886169434e+00
    phi[6,7]  R1917     -1.6034749746322632e+00
    phi[6,7]  R1918     -6.1685013771057129e-01
    phi[6,7]  R1919     1.4144872426986694e+00
    phi[6,7]  R1920     -7.5196194648742676e-01
    phi[6,7]  R1921     1.4564585685729980e+00
    phi[6,7]  R1922     7.6643365621566772e-01
    phi[6,7]  R1923     -3.0269971489906311e-01
    phi[6,7]  R1924     1.1105386018753052e+00
    phi[6,7]  R1925     -7.9036182165145874e-01
    phi[6,7]  R1926     6.1171513795852661e-01
    phi[6,7]  R1927     9.1192859411239624e-01
    phi[6,7]  R1928     -2.8638365268707275e+00
    phi[6,7]  R1929     -1.1253089904785156e+00
    phi[6,7]  R1930     -2.3314754962921143e+00
    phi[6,7]  R1931     -2.2390687465667725e+00
    phi[6,7]  R1932     -2.3384370803833008e+00
    phi[6,7]  R1933     -3.9566904306411743e-01
    phi[6,7]  R1934     -4.4806835055351257e-01
    phi[6,7]  R1935     -2.2889468669891357e+00
    phi[6,7]  R1936     -1.1804261207580566e+00
    phi[6,7]  R1937     -1.0262691974639893e+00
    phi[6,7]  R1938     -1.0059151649475098e+00
    phi[6,7]  R1939     -2.6930320262908936e+00
    phi[6,7]  R1940     5.6183889508247375e-02
    phi[6,7]  R1941     -1.7226728200912476e+00
    phi[6,7]  R1942     -1.7682511806488037e+00
    phi[6,7]  R1943     -8.4816688299179077e-01
    phi[6,7]  R1944     -5.0368195772171021e-01
    phi[6,7]  R1945     -2.4494180679321289e+00
    phi[6,7]  R1946     -1.1244152784347534e+00
    phi[6,7]  R1947     -2.3437099456787109e+00
    phi[6,7]  R1948     4.0334999561309814e-01
    phi[6,7]  R1949     -2.8559441566467285e+00
    phi[6,7]  R1950     -2.1663545072078705e-01
    phi[6,7]  R1951     -3.1723725795745850e+00
    phi[6,7]  R1952     -1.9240913391113281e+00
    phi[6,7]  R1953     -7.1077972650527954e-01
    phi[6,7]  R1954     -2.3431305885314941e+00
    phi[6,7]  R1955     -3.0200660228729248e+00
    phi[6,7]  R1956     -3.2857364416122437e-01
    phi[6,7]  R1957     1.3216899633407593e+00
    phi[6,7]  R1958     -3.3601028919219971e+00
    phi[6,7]  R1959     -1.0426707565784454e-01
    phi[6,7]  R1960     -9.0682965517044067e-01
    phi[6,7]  R1961     1.2012583017349243e+00
    phi[6,7]  R1962     -1.3241972923278809e+00
    phi[6,7]  R1963     -2.1097319126129150e+00
    phi[6,7]  R1964     -1.5406352281570435e+00
    phi[6,7]  R1965     4.2611175775527954e-01
    phi[6,7]  R1966     5.1778036355972290e-01
    phi[6,7]  R1967     -7.6649761199951172e-01
    phi[6,7]  R1968     4.4748440384864807e-01
    phi[6,7]  R1969     -8.2046234607696533e-01
    phi[6,7]  R1970     -6.3693886995315552e-01
    phi[6,7]  R1971     -2.3349419236183167e-01
    phi[6,7]  R1972     -1.1899421215057373e+00
    phi[6,7]  R1973     5.6128787994384766e-01
    phi[6,7]  R1974     -2.5173203945159912e+00
    phi[6,7]  R1975     -1.4446017742156982e+00
    phi[6,7]  R1976     -2.2528026103973389e+00
    phi[6,7]  R1977     3.3554109930992126e-01
    phi[6,7]  R1978     -0.994368314743042
    phi[6,7]  R1979     -1.1885038614273071e+00
    phi[6,7]  R1980     -9.0113610029220581e-01
    phi[6,7]  R1981     2.0278060436248779e+00
    phi[6,7]  R1982     -3.2576233148574829e-01
    phi[6,7]  R1983     -5.7222908735275269e-01
    phi[6,7]  R1984     1.5810085833072662e-01
    phi[6,7]  R1985     1.0311184078454971e-01
    phi[6,7]  R1986     -1.2292855232954025e-01
    phi[6,7]  R1987     -3.7774808704853058e-02
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R1988     -3.0999999046325684e+00
    phi[7,6]  R1989     -3.0999999046325684e+00
    phi[7,6]  R1990     -2.2400000095367432e+00
    phi[7,6]  R1991     -2.2400000095367432e+00
    phi[7,6]  R1992     -3.0999999046325684e+00
    phi[7,6]  R1993     -3.0999999046325684e+00
    phi[7,6]  R1994     -2.5699999332427979e+00
    phi[7,6]  R1995     -2.5699999332427979e+00
    phi[7,6]  R1996     -3.0999999046325684e+00
    phi[7,6]  R1997     -3.0999999046325684e+00
    phi[7,6]  R1998     -2.0899999141693115e+00
    phi[7,6]  R1999     -2.0899999141693115e+00
    phi[7,6]  R2000     -3.0999999046325684e+00
    phi[7,6]  R2001     -3.0999999046325684e+00
    phi[7,6]  R2002     -6.1685013771057129e-01
    phi[7,6]  R2003     1.4144872426986694e+00
    phi[7,6]  R2004     -7.5196194648742676e-01
    phi[7,6]  R2005     1.4564585685729980e+00
    phi[7,6]  R2006     7.6643365621566772e-01
    phi[7,6]  R2007     -3.0269971489906311e-01
    phi[7,6]  R2008     1.1105386018753052e+00
    phi[7,6]  R2009     -7.9036182165145874e-01
    phi[7,6]  R2010     6.1171513795852661e-01
    phi[7,6]  R2011     9.1192859411239624e-01
    phi[7,6]  R2012     -2.8638365268707275e+00
    phi[7,6]  R2013     -1.1253089904785156e+00
    phi[7,6]  R2014     -2.3314754962921143e+00
    phi[7,6]  R2015     -2.2390687465667725e+00
    phi[7,6]  R2016     -2.3384370803833008e+00
    phi[7,6]  R2017     -3.9566904306411743e-01
    phi[7,6]  R2018     -4.4806835055351257e-01
    phi[7,6]  R2019     -2.2889468669891357e+00
    phi[7,6]  R2020     -1.1804261207580566e+00
    phi[7,6]  R2021     -1.0262691974639893e+00
    phi[7,6]  R2022     -1.0059151649475098e+00
    phi[7,6]  R2023     -2.6930320262908936e+00
    phi[7,6]  R2024     5.6183889508247375e-02
    phi[7,6]  R2025     -1.7226728200912476e+00
    phi[7,6]  R2026     -1.7682511806488037e+00
    phi[7,6]  R2027     -8.4816688299179077e-01
    phi[7,6]  R2028     -5.0368195772171021e-01
    phi[7,6]  R2029     -2.4494180679321289e+00
    phi[7,6]  R2030     -1.1244152784347534e+00
    phi[7,6]  R2031     -2.3437099456787109e+00
    phi[7,6]  R2032     4.0334999561309814e-01
    phi[7,6]  R2033     -2.8559441566467285e+00
    phi[7,6]  R2034     -2.1663545072078705e-01
    phi[7,6]  R2035     -3.1723725795745850e+00
    phi[7,6]  R2036     -1.9240913391113281e+00
    phi[7,6]  R2037     -7.1077972650527954e-01
    phi[7,6]  R2038     -2.3431305885314941e+00
    phi[7,6]  R2039     -3.0200660228729248e+00
    phi[7,6]  R2040     -3.2857364416122437e-01
    phi[7,6]  R2041     1.3216899633407593e+00
    phi[7,6]  R2042     -3.3601028919219971e+00
    phi[7,6]  R2043     -1.0426707565784454e-01
    phi[7,6]  R2044     -9.0682965517044067e-01
    phi[7,6]  R2045     1.2012583017349243e+00
    phi[7,6]  R2046     -1.3241972923278809e+00
    phi[7,6]  R2047     -2.1097319126129150e+00
    phi[7,6]  R2048     -1.5406352281570435e+00
    phi[7,6]  R2049     4.2611175775527954e-01
    phi[7,6]  R2050     5.1778036355972290e-01
    phi[7,6]  R2051     -7.6649761199951172e-01
    phi[7,6]  R2052     4.4748440384864807e-01
    phi[7,6]  R2053     -8.2046234607696533e-01
    phi[7,6]  R2054     -6.3693886995315552e-01
    phi[7,6]  R2055     -2.3349419236183167e-01
    phi[7,6]  R2056     -1.1899421215057373e+00
    phi[7,6]  R2057     5.6128787994384766e-01
    phi[7,6]  R2058     -2.5173203945159912e+00
    phi[7,6]  R2059     -1.4446017742156982e+00
    phi[7,6]  R2060     -2.2528026103973389e+00
    phi[7,6]  R2061     3.3554109930992126e-01
    phi[7,6]  R2062     -0.994368314743042
    phi[7,6]  R2063     -1.1885038614273071e+00
    phi[7,6]  R2064     -9.0113610029220581e-01
    phi[7,6]  R2065     2.0278060436248779e+00
    phi[7,6]  R2066     -3.2576233148574829e-01
    phi[7,6]  R2067     -5.7222908735275269e-01
    phi[7,6]  R2068     1.5810085833072662e-01
    phi[7,6]  R2069     1.0311184078454971e-01
    phi[7,6]  R2070     -1.2292855232954025e-01
    phi[7,6]  R2071     -3.7774808704853058e-02
    phi[7,6]  R2072     4.6758142113685608e-01
    phi[7,6]  R2073     1.9361279010772705e+00
    phi[7,6]  R2074     1.9357725977897644e-01
    phi[7,6]  R2075     2.4240903854370117e+00
    phi[7,6]  R2076     -7.3627167940139771e-01
    phi[7,6]  R2077     -2.7017000317573547e-01
    phi[7,6]  R2078     -2.6191404461860657e-01
    phi[7,6]  R2079     1.0005730390548706e+00
    phi[7,6]  R2080     7.2080451250076294e-01
    phi[7,6]  R2081     -1.1659599095582962e-01
    phi[7,6]  R2082     -2.3821082115173340e+00
    phi[7,6]  R2083     -1.1491557359695435e+00
    phi[7,6]  R2084     -5.1121783256530762e-01
    phi[7,6]  R2085     -7.9473519325256348e-01
    phi[7,6]  R2086     -1.3403720855712891e+00
    phi[7,6]  R2087     -1.2952812016010284e-01
    phi[7,6]  R2088     -4.9288272857666016e-01
    phi[7,6]  R2089     -0.776736855506897
    phi[7,6]  R2090     -1.3343678712844849e+00
    phi[7,6]  R2091     -5.2720528841018677e-01
    phi[7,6]  R2092     -1.8961359262466431e+00
    phi[7,6]  R2093     -0.0777873620390892
    phi[7,6]  R2094     -2.2916192188858986e-02
    phi[7,6]  R2095     -3.6812925338745117e-01
    phi[7,6]  R2096     -7.4747240543365479e-01
    phi[7,6]  R2097     -2.4280178546905518e+00
    phi[7,6]  R2098     -1.0568945407867432e+00
    phi[7,6]  R2099     -4.5507332682609558e-01
    phi[7,6]  R2100     -6.2923830747604370e-01
    phi[7,6]  R2101     -3.9400303363800049e-01
    phi[7,6]  R2102     -5.2687156200408936e-01
    phi[7,6]  R2103     -8.3737695217132568e-01
    phi[7,6]  R2104     -5.9903395175933838e-01
    phi[7,6]  R2105     -1.0130881071090698e+00
    phi[7,6]  R2106     -1.7318416833877563e+00
    phi[7,6]  R2107     -1.2064383029937744e+00
    phi[7,6]  R2108     -2.1826109886169434e+00
    phi[7,6]  R2109     -1.6034749746322632e+00
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2110     -3.0999999046325684e+00
    phi[7,8]  R2111     -3.0999999046325684e+00
    phi[7,8]  R2112     -2.2400000095367432e+00
    phi[7,8]  R2113     -2.2400000095367432e+00
    phi[7,8]  R2114     -3.0999999046325684e+00
    phi[7,8]  R2115     -3.0999999046325684e+00
    phi[7,8]  R2116     -2.5699999332427979e+00
    phi[7,8]  R2117     -2.5699999332427979e+00
    phi[7,8]  R2118     -3.0999999046325684e+00
    phi[7,8]  R2119     -3.0999999046325684e+00
    phi[7,8]  R2120     -2.0899999141693115e+00
    phi[7,8]  R2121     -2.0899999141693115e+00
    phi[7,8]  R2122     -3.0999999046325684e+00
    phi[7,8]  R2123     -3.0999999046325684e+00
    phi[7,8]  R2124     -6.1685013771057129e-01
    phi[7,8]  R2125     1.4144872426986694e+00
    phi[7,8]  R2126     -7.5196194648742676e-01
    phi[7,8]  R2127     1.4564585685729980e+00
    phi[7,8]  R2128     7.6643365621566772e-01
    phi[7,8]  R2129     -3.0269971489906311e-01
    phi[7,8]  R2130     1.1105386018753052e+00
    phi[7,8]  R2131     -7.9036182165145874e-01
    phi[7,8]  R2132     6.1171513795852661e-01
    phi[7,8]  R2133     9.1192859411239624e-01
    phi[7,8]  R2134     -2.8638365268707275e+00
    phi[7,8]  R2135     -1.1253089904785156e+00
    phi[7,8]  R2136     -2.3314754962921143e+00
    phi[7,8]  R2137     -2.2390687465667725e+00
    phi[7,8]  R2138     -2.3384370803833008e+00
    phi[7,8]  R2139     -3.9566904306411743e-01
    phi[7,8]  R2140     -4.4806835055351257e-01
    phi[7,8]  R2141     -2.2889468669891357e+00
    phi[7,8]  R2142     -1.1804261207580566e+00
    phi[7,8]  R2143     -1.0262691974639893e+00
    phi[7,8]  R2144     -1.0059151649475098e+00
    phi[7,8]  R2145     -2.6930320262908936e+00
    phi[7,8]  R2146     5.6183889508247375e-02
    phi[7,8]  R2147     -1.7226728200912476e+00
    phi[7,8]  R2148     -1.7682511806488037e+00
    phi[7,8]  R2149     -8.4816688299179077e-01
    phi[7,8]  R2150     -5.0368195772171021e-01
    phi[7,8]  R2151     -2.4494180679321289e+00
    phi[7,8]  R2152     -1.1244152784347534e+00
    phi[7,8]  R2153     -2.3437099456787109e+00
    phi[7,8]  R2154     4.0334999561309814e-01
    phi[7,8]  R2155     -2.8559441566467285e+00
    phi[7,8]  R2156     -2.1663545072078705e-01
    phi[7,8]  R2157     -3.1723725795745850e+00
    phi[7,8]  R2158     -1.9240913391113281e+00
    phi[7,8]  R2159     -7.1077972650527954e-01
    phi[7,8]  R2160     -2.3431305885314941e+00
    phi[7,8]  R2161     -3.0200660228729248e+00
    phi[7,8]  R2162     -3.2857364416122437e-01
    phi[7,8]  R2163     1.3216899633407593e+00
    phi[7,8]  R2164     -3.3601028919219971e+00
    phi[7,8]  R2165     -1.0426707565784454e-01
    phi[7,8]  R2166     -9.0682965517044067e-01
    phi[7,8]  R2167     1.2012583017349243e+00
    phi[7,8]  R2168     -1.3241972923278809e+00
    phi[7,8]  R2169     -2.1097319126129150e+00
    phi[7,8]  R2170     -1.5406352281570435e+00
    phi[7,8]  R2171     4.2611175775527954e-01
    phi[7,8]  R2172     5.1778036355972290e-01
    phi[7,8]  R2173     -7.6649761199951172e-01
    phi[7,8]  R2174     4.4748440384864807e-01
    phi[7,8]  R2175     -8.2046234607696533e-01
    phi[7,8]  R2176     -6.3693886995315552e-01
    phi[7,8]  R2177     -2.3349419236183167e-01
    phi[7,8]  R2178     -1.1899421215057373e+00
    phi[7,8]  R2179     5.6128787994384766e-01
    phi[7,8]  R2180     -2.5173203945159912e+00
    phi[7,8]  R2181     -1.4446017742156982e+00
    phi[7,8]  R2182     -2.2528026103973389e+00
    phi[7,8]  R2183     3.3554109930992126e-01
    phi[7,8]  R2184     -0.994368314743042
    phi[7,8]  R2185     -1.1885038614273071e+00
    phi[7,8]  R2186     -9.0113610029220581e-01
    phi[7,8]  R2187     2.0278060436248779e+00
    phi[7,8]  R2188     -3.2576233148574829e-01
    phi[7,8]  R2189     -5.7222908735275269e-01
    phi[7,8]  R2190     1.5810085833072662e-01
    phi[7,8]  R2191     1.0311184078454971e-01
    phi[7,8]  R2192     -1.2292855232954025e-01
    phi[7,8]  R2193     -3.7774808704853058e-02
    phi[7,8]  R2194     8.7145978212356567e-01
    phi[7,8]  R2195     2.1154117584228516e+00
    phi[7,8]  R2196     1.7478047609329224e+00
    phi[7,8]  R2197     1.3386188447475433e-01
    phi[7,8]  R2198     -3.6015155911445618e-01
    phi[7,8]  R2199     3.7751667499542236e+00
    phi[7,8]  R2200     3.5628824234008789e+00
    phi[7,8]  R2201     3.3277089595794678e+00
    phi[7,8]  R2202     3.5359358787536621e+00
    phi[7,8]  R2203     2.9439554214477539e+00
    phi[7,8]  R2204     -4.4793000817298889e-01
    phi[7,8]  R2205     -7.7650171518325806e-01
    phi[7,8]  R2206     -1.8235387802124023e+00
    phi[7,8]  R2207     -4.9361801147460938e-01
    phi[7,8]  R2208     -3.5418576002120972e-01
    phi[7,8]  R2209     -7.4726527929306030e-01
    phi[7,8]  R2210     -8.1580692529678345e-01
    phi[7,8]  R2211     -1.3776556253433228e+00
    phi[7,8]  R2212     -2.4553632736206055e+00
    phi[7,8]  R2213     -1.4620923995971680e+00
    phi[7,8]  R2214     -4.0435609817504883e+00
    phi[7,8]  R2215     -2.4936897754669189e+00
    phi[7,8]  R2216     -3.2504351139068604e+00
    phi[7,8]  R2217     -3.9771280288696289e+00
    phi[7,8]  R2218     -2.3059816360473633e+00
    phi[7,8]  R2219     -2.9706027507781982e+00
    phi[7,8]  R2220     -2.1016631126403809e+00
    phi[7,8]  R2221     -1.2959960699081421e+00
    phi[7,8]  R2222     3.8297086954116821e-01
    phi[7,8]  R2223     -2.5768103599548340e+00
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2224     -3.0999999046325684e+00
    phi[8,7]  R2225     -3.0999999046325684e+00
    phi[8,7]  R2226     -2.2400000095367432e+00
    phi[8,7]  R2227     -2.2400000095367432e+00
    phi[8,7]  R2228     -3.0999999046325684e+00
    phi[8,7]  R2229     -3.0999999046325684e+00
    phi[8,7]  R2230     -2.5699999332427979e+00
    phi[8,7]  R2231     -2.5699999332427979e+00
    phi[8,7]  R2232     -3.0999999046325684e+00
    phi[8,7]  R2233     -3.0999999046325684e+00
    phi[8,7]  R2234     -2.0899999141693115e+00
    phi[8,7]  R2235     -2.0899999141693115e+00
    phi[8,7]  R2236     -3.0999999046325684e+00
    phi[8,7]  R2237     -3.0999999046325684e+00
    phi[8,7]  R2238     8.7145978212356567e-01
    phi[8,7]  R2239     2.1154117584228516e+00
    phi[8,7]  R2240     1.7478047609329224e+00
    phi[8,7]  R2241     1.3386188447475433e-01
    phi[8,7]  R2242     -3.6015155911445618e-01
    phi[8,7]  R2243     3.7751667499542236e+00
    phi[8,7]  R2244     3.5628824234008789e+00
    phi[8,7]  R2245     3.3277089595794678e+00
    phi[8,7]  R2246     3.5359358787536621e+00
    phi[8,7]  R2247     2.9439554214477539e+00
    phi[8,7]  R2248     -4.4793000817298889e-01
    phi[8,7]  R2249     -7.7650171518325806e-01
    phi[8,7]  R2250     -1.8235387802124023e+00
    phi[8,7]  R2251     -4.9361801147460938e-01
    phi[8,7]  R2252     -3.5418576002120972e-01
    phi[8,7]  R2253     -7.4726527929306030e-01
    phi[8,7]  R2254     -8.1580692529678345e-01
    phi[8,7]  R2255     -1.3776556253433228e+00
    phi[8,7]  R2256     -2.4553632736206055e+00
    phi[8,7]  R2257     -1.4620923995971680e+00
    phi[8,7]  R2258     -4.0435609817504883e+00
    phi[8,7]  R2259     -2.4936897754669189e+00
    phi[8,7]  R2260     -3.2504351139068604e+00
    phi[8,7]  R2261     -3.9771280288696289e+00
    phi[8,7]  R2262     -2.3059816360473633e+00
    phi[8,7]  R2263     -2.9706027507781982e+00
    phi[8,7]  R2264     -2.1016631126403809e+00
    phi[8,7]  R2265     -1.2959960699081421e+00
    phi[8,7]  R2266     3.8297086954116821e-01
    phi[8,7]  R2267     -2.5768103599548340e+00
    phi[8,7]  R2268     -6.1685013771057129e-01
    phi[8,7]  R2269     1.4144872426986694e+00
    phi[8,7]  R2270     -7.5196194648742676e-01
    phi[8,7]  R2271     1.4564585685729980e+00
    phi[8,7]  R2272     7.6643365621566772e-01
    phi[8,7]  R2273     -3.0269971489906311e-01
    phi[8,7]  R2274     1.1105386018753052e+00
    phi[8,7]  R2275     -7.9036182165145874e-01
    phi[8,7]  R2276     6.1171513795852661e-01
    phi[8,7]  R2277     9.1192859411239624e-01
    phi[8,7]  R2278     -2.8638365268707275e+00
    phi[8,7]  R2279     -1.1253089904785156e+00
    phi[8,7]  R2280     -2.3314754962921143e+00
    phi[8,7]  R2281     -2.2390687465667725e+00
    phi[8,7]  R2282     -2.3384370803833008e+00
    phi[8,7]  R2283     -3.9566904306411743e-01
    phi[8,7]  R2284     -4.4806835055351257e-01
    phi[8,7]  R2285     -2.2889468669891357e+00
    phi[8,7]  R2286     -1.1804261207580566e+00
    phi[8,7]  R2287     -1.0262691974639893e+00
    phi[8,7]  R2288     -1.0059151649475098e+00
    phi[8,7]  R2289     -2.6930320262908936e+00
    phi[8,7]  R2290     5.6183889508247375e-02
    phi[8,7]  R2291     -1.7226728200912476e+00
    phi[8,7]  R2292     -1.7682511806488037e+00
    phi[8,7]  R2293     -8.4816688299179077e-01
    phi[8,7]  R2294     -5.0368195772171021e-01
    phi[8,7]  R2295     -2.4494180679321289e+00
    phi[8,7]  R2296     -1.1244152784347534e+00
    phi[8,7]  R2297     -2.3437099456787109e+00
    phi[8,7]  R2298     4.0334999561309814e-01
    phi[8,7]  R2299     -2.8559441566467285e+00
    phi[8,7]  R2300     -2.1663545072078705e-01
    phi[8,7]  R2301     -3.1723725795745850e+00
    phi[8,7]  R2302     -1.9240913391113281e+00
    phi[8,7]  R2303     -7.1077972650527954e-01
    phi[8,7]  R2304     -2.3431305885314941e+00
    phi[8,7]  R2305     -3.0200660228729248e+00
    phi[8,7]  R2306     -3.2857364416122437e-01
    phi[8,7]  R2307     1.3216899633407593e+00
    phi[8,7]  R2308     -3.3601028919219971e+00
    phi[8,7]  R2309     -1.0426707565784454e-01
    phi[8,7]  R2310     -9.0682965517044067e-01
    phi[8,7]  R2311     1.2012583017349243e+00
    phi[8,7]  R2312     -1.3241972923278809e+00
    phi[8,7]  R2313     -2.1097319126129150e+00
    phi[8,7]  R2314     -1.5406352281570435e+00
    phi[8,7]  R2315     4.2611175775527954e-01
    phi[8,7]  R2316     5.1778036355972290e-01
    phi[8,7]  R2317     -7.6649761199951172e-01
    phi[8,7]  R2318     4.4748440384864807e-01
    phi[8,7]  R2319     -8.2046234607696533e-01
    phi[8,7]  R2320     -6.3693886995315552e-01
    phi[8,7]  R2321     -2.3349419236183167e-01
    phi[8,7]  R2322     -1.1899421215057373e+00
    phi[8,7]  R2323     5.6128787994384766e-01
    phi[8,7]  R2324     -2.5173203945159912e+00
    phi[8,7]  R2325     -1.4446017742156982e+00
    phi[8,7]  R2326     -2.2528026103973389e+00
    phi[8,7]  R2327     3.3554109930992126e-01
    phi[8,7]  R2328     -0.994368314743042
    phi[8,7]  R2329     -1.1885038614273071e+00
    phi[8,7]  R2330     -9.0113610029220581e-01
    phi[8,7]  R2331     2.0278060436248779e+00
    phi[8,7]  R2332     -3.2576233148574829e-01
    phi[8,7]  R2333     -5.7222908735275269e-01
    phi[8,7]  R2334     1.5810085833072662e-01
    phi[8,7]  R2335     1.0311184078454971e-01
    phi[8,7]  R2336     -1.2292855232954025e-01
    phi[8,7]  R2337     -3.7774808704853058e-02
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2338     -3.0999999046325684e+00
    phi[8,9]  R2339     -3.0999999046325684e+00
    phi[8,9]  R2340     -2.2400000095367432e+00
    phi[8,9]  R2341     -2.2400000095367432e+00
    phi[8,9]  R2342     -3.0999999046325684e+00
    phi[8,9]  R2343     -3.0999999046325684e+00
    phi[8,9]  R2344     -2.5699999332427979e+00
    phi[8,9]  R2345     -2.5699999332427979e+00
    phi[8,9]  R2346     -3.0999999046325684e+00
    phi[8,9]  R2347     -3.0999999046325684e+00
    phi[8,9]  R2348     -2.0899999141693115e+00
    phi[8,9]  R2349     -2.0899999141693115e+00
    phi[8,9]  R2350     -3.0999999046325684e+00
    phi[8,9]  R2351     -3.0999999046325684e+00
    phi[8,9]  R2352     8.7145978212356567e-01
    phi[8,9]  R2353     2.1154117584228516e+00
    phi[8,9]  R2354     1.7478047609329224e+00
    phi[8,9]  R2355     1.3386188447475433e-01
    phi[8,9]  R2356     -3.6015155911445618e-01
    phi[8,9]  R2357     3.7751667499542236e+00
    phi[8,9]  R2358     3.5628824234008789e+00
    phi[8,9]  R2359     3.3277089595794678e+00
    phi[8,9]  R2360     3.5359358787536621e+00
    phi[8,9]  R2361     2.9439554214477539e+00
    phi[8,9]  R2362     -4.4793000817298889e-01
    phi[8,9]  R2363     -7.7650171518325806e-01
    phi[8,9]  R2364     -1.8235387802124023e+00
    phi[8,9]  R2365     -4.9361801147460938e-01
    phi[8,9]  R2366     -3.5418576002120972e-01
    phi[8,9]  R2367     -7.4726527929306030e-01
    phi[8,9]  R2368     -8.1580692529678345e-01
    phi[8,9]  R2369     -1.3776556253433228e+00
    phi[8,9]  R2370     -2.4553632736206055e+00
    phi[8,9]  R2371     -1.4620923995971680e+00
    phi[8,9]  R2372     -4.0435609817504883e+00
    phi[8,9]  R2373     -2.4936897754669189e+00
    phi[8,9]  R2374     -3.2504351139068604e+00
    phi[8,9]  R2375     -3.9771280288696289e+00
    phi[8,9]  R2376     -2.3059816360473633e+00
    phi[8,9]  R2377     -2.9706027507781982e+00
    phi[8,9]  R2378     -2.1016631126403809e+00
    phi[8,9]  R2379     -1.2959960699081421e+00
    phi[8,9]  R2380     3.8297086954116821e-01
    phi[8,9]  R2381     -2.5768103599548340e+00
    phi[8,9]  R2382     -9.3677736818790436e-02
    phi[8,9]  R2383     -1.8854149580001831e+00
    phi[8,9]  R2384     8.9243566989898682e-01
    phi[8,9]  R2385     2.4900376796722412e+00
    phi[8,9]  R2386     -1.8020079135894775e+00
    phi[8,9]  R2387     -2.3056626319885254e+00
    phi[8,9]  R2388     1.5208888053894043e+00
    phi[8,9]  R2389     2.1525177955627441e+00
    phi[8,9]  R2390     2.7482552528381348e+00
    phi[8,9]  R2391     7.7873212099075317e-01
    phi[8,9]  R2392     -3.1902894973754883e+00
    phi[8,9]  R2393     -1.0839865207672119e+00
    phi[8,9]  R2394     -5.8644634485244751e-01
    phi[8,9]  R2395     -1.2926633358001709e+00
    phi[8,9]  R2396     -1.9248092174530029e+00
    phi[8,9]  R2397     -7.8954733908176422e-02
    phi[8,9]  R2398     -8.4277969598770142e-01
    phi[8,9]  R2399     9.9171346426010132e-01
    phi[8,9]  R2400     7.0498740673065186e-01
    phi[8,9]  R2401     1.6435724496841431e+00
    phi[8,9]  R2402     1.0065134763717651e+00
    phi[8,9]  R2403     6.7602896690368652e-01
    phi[8,9]  R2404     -1.8759627342224121e+00
    phi[8,9]  R2405     -9.0613913536071777e-01
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2406     -3.0999999046325684e+00
    phi[9,8]  R2407     -3.0999999046325684e+00
    phi[9,8]  R2408     -2.2400000095367432e+00
    phi[9,8]  R2409     -2.2400000095367432e+00
    phi[9,8]  R2410     -3.0999999046325684e+00
    phi[9,8]  R2411     -3.0999999046325684e+00
    phi[9,8]  R2412     -2.5699999332427979e+00
    phi[9,8]  R2413     -2.5699999332427979e+00
    phi[9,8]  R2414     -3.0999999046325684e+00
    phi[9,8]  R2415     -3.0999999046325684e+00
    phi[9,8]  R2416     -2.0899999141693115e+00
    phi[9,8]  R2417     -2.0899999141693115e+00
    phi[9,8]  R2418     -3.0999999046325684e+00
    phi[9,8]  R2419     -3.0999999046325684e+00
    phi[9,8]  R2420     -9.3677736818790436e-02
    phi[9,8]  R2421     -1.8854149580001831e+00
    phi[9,8]  R2422     8.9243566989898682e-01
    phi[9,8]  R2423     2.4900376796722412e+00
    phi[9,8]  R2424     -1.8020079135894775e+00
    phi[9,8]  R2425     -2.3056626319885254e+00
    phi[9,8]  R2426     1.5208888053894043e+00
    phi[9,8]  R2427     2.1525177955627441e+00
    phi[9,8]  R2428     2.7482552528381348e+00
    phi[9,8]  R2429     7.7873212099075317e-01
    phi[9,8]  R2430     -3.1902894973754883e+00
    phi[9,8]  R2431     -1.0839865207672119e+00
    phi[9,8]  R2432     -5.8644634485244751e-01
    phi[9,8]  R2433     -1.2926633358001709e+00
    phi[9,8]  R2434     -1.9248092174530029e+00
    phi[9,8]  R2435     -7.8954733908176422e-02
    phi[9,8]  R2436     -8.4277969598770142e-01
    phi[9,8]  R2437     9.9171346426010132e-01
    phi[9,8]  R2438     7.0498740673065186e-01
    phi[9,8]  R2439     1.6435724496841431e+00
    phi[9,8]  R2440     1.0065134763717651e+00
    phi[9,8]  R2441     6.7602896690368652e-01
    phi[9,8]  R2442     -1.8759627342224121e+00
    phi[9,8]  R2443     -9.0613913536071777e-01
    phi[9,8]  R2444     8.7145978212356567e-01
    phi[9,8]  R2445     2.1154117584228516e+00
    phi[9,8]  R2446     1.7478047609329224e+00
    phi[9,8]  R2447     1.3386188447475433e-01
    phi[9,8]  R2448     -3.6015155911445618e-01
    phi[9,8]  R2449     3.7751667499542236e+00
    phi[9,8]  R2450     3.5628824234008789e+00
    phi[9,8]  R2451     3.3277089595794678e+00
    phi[9,8]  R2452     3.5359358787536621e+00
    phi[9,8]  R2453     2.9439554214477539e+00
    phi[9,8]  R2454     -4.4793000817298889e-01
    phi[9,8]  R2455     -7.7650171518325806e-01
    phi[9,8]  R2456     -1.8235387802124023e+00
    phi[9,8]  R2457     -4.9361801147460938e-01
    phi[9,8]  R2458     -3.5418576002120972e-01
    phi[9,8]  R2459     -7.4726527929306030e-01
    phi[9,8]  R2460     -8.1580692529678345e-01
    phi[9,8]  R2461     -1.3776556253433228e+00
    phi[9,8]  R2462     -2.4553632736206055e+00
    phi[9,8]  R2463     -1.4620923995971680e+00
    phi[9,8]  R2464     -4.0435609817504883e+00
    phi[9,8]  R2465     -2.4936897754669189e+00
    phi[9,8]  R2466     -3.2504351139068604e+00
    phi[9,8]  R2467     -3.9771280288696289e+00
    phi[9,8]  R2468     -2.3059816360473633e+00
    phi[9,8]  R2469     -2.9706027507781982e+00
    phi[9,8]  R2470     -2.1016631126403809e+00
    phi[9,8]  R2471     -1.2959960699081421e+00
    phi[9,8]  R2472     3.8297086954116821e-01
    phi[9,8]  R2473     -2.5768103599548340e+00
    phi[9,10]  R81       1
    phi[9,10]  R82       1
    phi[9,10]  R90       -1
    phi[9,10]  R2474     -3.0999999046325684e+00
    phi[9,10]  R2475     -3.0999999046325684e+00
    phi[9,10]  R2476     -2.2400000095367432e+00
    phi[9,10]  R2477     -2.2400000095367432e+00
    phi[9,10]  R2478     -3.0999999046325684e+00
    phi[9,10]  R2479     -3.0999999046325684e+00
    phi[9,10]  R2480     -2.5699999332427979e+00
    phi[9,10]  R2481     -2.5699999332427979e+00
    phi[9,10]  R2482     -3.0999999046325684e+00
    phi[9,10]  R2483     -3.0999999046325684e+00
    phi[9,10]  R2484     -2.0899999141693115e+00
    phi[9,10]  R2485     -2.0899999141693115e+00
    phi[9,10]  R2486     -3.0999999046325684e+00
    phi[9,10]  R2487     -3.0999999046325684e+00
    phi[9,10]  R2488     -9.3677736818790436e-02
    phi[9,10]  R2489     -1.8854149580001831e+00
    phi[9,10]  R2490     8.9243566989898682e-01
    phi[9,10]  R2491     2.4900376796722412e+00
    phi[9,10]  R2492     -1.8020079135894775e+00
    phi[9,10]  R2493     -2.3056626319885254e+00
    phi[9,10]  R2494     1.5208888053894043e+00
    phi[9,10]  R2495     2.1525177955627441e+00
    phi[9,10]  R2496     2.7482552528381348e+00
    phi[9,10]  R2497     7.7873212099075317e-01
    phi[9,10]  R2498     -3.1902894973754883e+00
    phi[9,10]  R2499     -1.0839865207672119e+00
    phi[9,10]  R2500     -5.8644634485244751e-01
    phi[9,10]  R2501     -1.2926633358001709e+00
    phi[9,10]  R2502     -1.9248092174530029e+00
    phi[9,10]  R2503     -7.8954733908176422e-02
    phi[9,10]  R2504     -8.4277969598770142e-01
    phi[9,10]  R2505     9.9171346426010132e-01
    phi[9,10]  R2506     7.0498740673065186e-01
    phi[9,10]  R2507     1.6435724496841431e+00
    phi[9,10]  R2508     1.0065134763717651e+00
    phi[9,10]  R2509     6.7602896690368652e-01
    phi[9,10]  R2510     -1.8759627342224121e+00
    phi[9,10]  R2511     -9.0613913536071777e-01
    phi[9,10]  R2512     1.7403774261474609e+00
    phi[9,10]  R2513     7.3694744217316011e-01
    phi[9,10]  R2514     1.2157616615295410e+00
    phi[9,10]  R2515     2.2519853115081787e+00
    phi[9,10]  R2516     1.2167718410491943e+00
    phi[9,10]  R2517     1.1877001523971558e+00
    phi[9,10]  R2518     2.8831294178962708e-01
    phi[9,10]  R2519     8.8821685314178467e-01
    phi[9,10]  R2520     -3.3819119930267334e+00
    phi[9,10]  R2521     -1.9029613733291626e+00
    phi[9,10]  R2522     -2.3586440086364746e+00
    phi[9,10]  R2523     -1.4233530759811401e+00
    phi[9,10]  R2524     -2.1625223159790039e+00
    phi[9,10]  R2525     -1.3798239827156067e-01
    phi[9,10]  R2526     -7.4420952796936035e-01
    phi[9,10]  R2527     7.0488780736923218e-01
    phi[9,10]  R2528     -2.3711254596710205e+00
    phi[9,10]  R2529     -2.4104197025299072e+00
    phi[9,10]  R2530     -1.9223589897155762e+00
    phi[9,10]  R2531     -1.1683126688003540e+00
    phi[9,10]  R2532     -1.2077102661132812e+00
    phi[9,10]  R2533     -1.5435159206390381e-01
    phi[9,10]  R2534     9.5046776533126831e-01
    phi[9,10]  R2535     -6.8478327989578247e-01
    phi[9,10]  R2536     3.1802105903625488e-01
    phi[9,10]  R2537     3.8363108038902283e-01
    phi[9,10]  R2538     2.8353765606880188e-01
    phi[9,10]  R2539     -3.1203091144561768e+00
    phi[9,10]  R2540     5.8886861801147461e-01
    phi[9,10]  R2541     -1.5656492710113525e+00
    phi[9,10]  R2542     -1.3199291229248047e+00
    phi[9,10]  R2543     -5.0755888223648071e-01
    phi[9,10]  R2544     -1.2539684772491455e+00
    phi[9,10]  R2545     -6.6878181695938110e-01
    phi[9,10]  R2546     -5.6963956356048584e-01
    phi[9,10]  R2547     6.7136961221694946e-01
    phi[9,10]  R2548     -1.5048220157623291e+00
    phi[9,10]  R2549     -9.6198284626007080e-01
    phi[10,9]  R81       -1
    phi[10,9]  R90       1
    phi[10,9]  R91       1
    phi[10,9]  R2550     -3.0999999046325684e+00
    phi[10,9]  R2551     -3.0999999046325684e+00
    phi[10,9]  R2552     -2.2400000095367432e+00
    phi[10,9]  R2553     -2.2400000095367432e+00
    phi[10,9]  R2554     -3.0999999046325684e+00
    phi[10,9]  R2555     -3.0999999046325684e+00
    phi[10,9]  R2556     -2.5699999332427979e+00
    phi[10,9]  R2557     -2.5699999332427979e+00
    phi[10,9]  R2558     -3.0999999046325684e+00
    phi[10,9]  R2559     -3.0999999046325684e+00
    phi[10,9]  R2560     -2.0899999141693115e+00
    phi[10,9]  R2561     -2.0899999141693115e+00
    phi[10,9]  R2562     -3.0999999046325684e+00
    phi[10,9]  R2563     -3.0999999046325684e+00
    phi[10,9]  R2564     1.7403774261474609e+00
    phi[10,9]  R2565     7.3694744217316011e-01
    phi[10,9]  R2566     1.2157616615295410e+00
    phi[10,9]  R2567     2.2519853115081787e+00
    phi[10,9]  R2568     1.2167718410491943e+00
    phi[10,9]  R2569     1.1877001523971558e+00
    phi[10,9]  R2570     2.8831294178962708e-01
    phi[10,9]  R2571     8.8821685314178467e-01
    phi[10,9]  R2572     -3.3819119930267334e+00
    phi[10,9]  R2573     -1.9029613733291626e+00
    phi[10,9]  R2574     -2.3586440086364746e+00
    phi[10,9]  R2575     -1.4233530759811401e+00
    phi[10,9]  R2576     -2.1625223159790039e+00
    phi[10,9]  R2577     -1.3798239827156067e-01
    phi[10,9]  R2578     -7.4420952796936035e-01
    phi[10,9]  R2579     7.0488780736923218e-01
    phi[10,9]  R2580     -2.3711254596710205e+00
    phi[10,9]  R2581     -2.4104197025299072e+00
    phi[10,9]  R2582     -1.9223589897155762e+00
    phi[10,9]  R2583     -1.1683126688003540e+00
    phi[10,9]  R2584     -1.2077102661132812e+00
    phi[10,9]  R2585     -1.5435159206390381e-01
    phi[10,9]  R2586     9.5046776533126831e-01
    phi[10,9]  R2587     -6.8478327989578247e-01
    phi[10,9]  R2588     3.1802105903625488e-01
    phi[10,9]  R2589     3.8363108038902283e-01
    phi[10,9]  R2590     2.8353765606880188e-01
    phi[10,9]  R2591     -3.1203091144561768e+00
    phi[10,9]  R2592     5.8886861801147461e-01
    phi[10,9]  R2593     -1.5656492710113525e+00
    phi[10,9]  R2594     -1.3199291229248047e+00
    phi[10,9]  R2595     -5.0755888223648071e-01
    phi[10,9]  R2596     -1.2539684772491455e+00
    phi[10,9]  R2597     -6.6878181695938110e-01
    phi[10,9]  R2598     -5.6963956356048584e-01
    phi[10,9]  R2599     6.7136961221694946e-01
    phi[10,9]  R2600     -1.5048220157623291e+00
    phi[10,9]  R2601     -9.6198284626007080e-01
    phi[10,9]  R2602     -9.3677736818790436e-02
    phi[10,9]  R2603     -1.8854149580001831e+00
    phi[10,9]  R2604     8.9243566989898682e-01
    phi[10,9]  R2605     2.4900376796722412e+00
    phi[10,9]  R2606     -1.8020079135894775e+00
    phi[10,9]  R2607     -2.3056626319885254e+00
    phi[10,9]  R2608     1.5208888053894043e+00
    phi[10,9]  R2609     2.1525177955627441e+00
    phi[10,9]  R2610     2.7482552528381348e+00
    phi[10,9]  R2611     7.7873212099075317e-01
    phi[10,9]  R2612     -3.1902894973754883e+00
    phi[10,9]  R2613     -1.0839865207672119e+00
    phi[10,9]  R2614     -5.8644634485244751e-01
    phi[10,9]  R2615     -1.2926633358001709e+00
    phi[10,9]  R2616     -1.9248092174530029e+00
    phi[10,9]  R2617     -7.8954733908176422e-02
    phi[10,9]  R2618     -8.4277969598770142e-01
    phi[10,9]  R2619     9.9171346426010132e-01
    phi[10,9]  R2620     7.0498740673065186e-01
    phi[10,9]  R2621     1.6435724496841431e+00
    phi[10,9]  R2622     1.0065134763717651e+00
    phi[10,9]  R2623     6.7602896690368652e-01
    phi[10,9]  R2624     -1.8759627342224121e+00
    phi[10,9]  R2625     -9.0613913536071777e-01
    phi[10,12]  R90       1
    phi[10,12]  R91       1
    phi[10,12]  R92       -2.3659294656801513e+00
    phi[10,12]  R93       1.61396413869553
    phi[10,12]  R94       7.2004346022925292e-01
    phi[10,12]  R95       -1.1164516108306279e+00
    phi[10,12]  R96       -1.6949008548941715e+00
    phi[10,12]  R97       4.8224095273947909e-01
    phi[10,12]  R98       -6.2122488005295651e-01
    phi[10,12]  R100      -1
    phi[10,12]  R2626     -5.46592937031272
    phi[10,12]  R2627     -7.3407043895241708e-01
    phi[10,12]  R2628     -6.2603587084121326e-01
    phi[10,12]  R2629     -3.8539641482322731e+00
    phi[10,12]  R2630     -2.3799564444033154e+00
    phi[10,12]  R2631     -3.8200433648618213e+00
    phi[10,12]  R2632     -3.6864515440734258e+00
    phi[10,12]  R2633     -1.45354832241217
    phi[10,12]  R2634     -4.79490075952674
    phi[10,12]  R2635     -1.4050990497383968e+00
    phi[10,12]  R2636     -1.6077589614298324e+00
    phi[10,12]  R2637     -2.5722408669087908e+00
    phi[10,12]  R2638     -3.7212247846855249e+00
    phi[10,12]  R2639     -2.4787750245796119e+00
    phi[10,12]  R2640     -2.7624390996905390e-07
    phi[10,12]  R2641     -4.1838750464151531e-08
    phi[10,12]  R2642     -6.2365841080638251e-03
    phi[10,12]  R2643     -1.3828958990387274e-02
    phi[10,12]  R2644     -1.7424223694436858e-02
    phi[10,12]  R2645     -2.1471694268660135e-02
    phi[10,12]  R2646     -1.0755837623481703e+00
    phi[10,12]  R2647     -2.9145222646925606e-01
    phi[10,12]  R2648     -1.3993656663240124e+00
    phi[10,12]  R2649     -5.5235840093807553e-01
    phi[10,12]  R2650     -5.8376258639213274e-01
    phi[10,12]  R2651     -7.3368220389931260e-01
    phi[10,12]  R2652     -1.0745250465743306e-01
    phi[10,12]  R2653     -8.3345555314046593e-01
    phi[10,12]  R2654     -1.3132936092012848e-01
    phi[10,12]  R2655     -2.9115557975461148e-01
    phi[10,12]  R2656     -0.247793757227325
    phi[10,12]  R2657     -2.4992211453261071e-01
    phi[10,12]  R2658     -8.5579865663306887e-01
    phi[10,12]  R2659     -1.2735224195843995e+00
    phi[10,12]  R2660     -1.3150614870732427e+00
    phi[10,12]  R2661     -1.1274205558564852e+00
    phi[10,12]  R2662     -1.3972292451601009e-01
    phi[10,12]  R2663     -1.4165015803955860e-01
    phi[10,12]  R2664     -1.4233246782533959e-01
    phi[10,12]  R2665     -1.4393330521339587e-01
    phi[10,12]  R2666     -1.4730479841271588e-01
    phi[10,12]  R2667     -1.2309178385445374e+00
    phi[10,12]  R2668     -8.7335767618664661e-01
    phi[10,12]  R2669     -1.2390460998973585e-01
    phi[10,12]  R2670     -4.6062077582281835e-01
    phi[10,12]  R2671     -5.3634375848754157e-01
    phi[10,12]  R2672     -1.9701597398201260e+00
    phi[10,12]  R2673     -8.5487411029350757e-01
    phi[10,12]  R2674     -2.2191999078631608e-01
    phi[10,12]  R2675     -2.3255371557829352e-01
    phi[10,12]  R2676     -2.3811126987610076e-01
    phi[10,12]  R2677     -0.242974201261701
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R101      -1
    z[0,1,0]  R102      1
    z[0,1,0]  R115      3.1476408243179321e-01
    z[0,1,0]  R116      1.1834477074444294e-02
    z[0,1,0]  R117      1.3257554173469543e-01
    z[0,1,0]  R118      -1.2430892139673233e-01
    z[0,1,0]  R119      1.1401630938053131e-01
    z[0,1,0]  R120      -3.0118885636329651e-01
    z[0,1,0]  R121      1.2912358343601227e-01
    z[0,1,0]  R122      0.0815248116850853
    z[0,1,0]  R123      0.00552970077842474
    z[0,1,0]  R124      -2.7339807152748108e-01
    z[0,1,0]  R125      2.0762410759925842e-01
    z[0,1,0]  R126      4.2255121469497681e-01
    z[0,1,0]  R127      4.4009661674499512e-01
    z[0,1,0]  R128      3.1443512439727783e-01
    z[0,1,0]  R129      2.3042079806327820e-01
    z[0,1,0]  R130      2.1689118444919586e-01
    z[0,1,0]  R131      2.7959862351417542e-01
    z[0,1,0]  R132      1.5870036184787750e-01
    z[0,1,0]  R133      -2.6550387963652611e-02
    z[0,1,0]  R134      2.9034525156021118e-01
    z[0,1,0]  R135      1.8654049932956696e-01
    z[0,1,0]  R136      1.3500507175922394e-01
    z[0,1,0]  R137      3.1808316707611084e-01
    z[0,1,0]  R138      5.0692677497863770e-02
    z[0,1,0]  R139      1.0992458462715149e-01
    z[0,1,0]  R140      2.7017506957054138e-01
    z[0,1,0]  R141      -4.9938973970711231e-03
    z[0,1,0]  R142      4.2471197247505188e-01
    z[0,1,0]  R143      5.2590274810791016e-01
    z[0,1,0]  R144      -5.6573790311813354e-01
    z[0,1,0]  R145      1.9393743574619293e-01
    z[0,1,0]  R146      -2.4671745300292969e-01
    z[0,1,0]  R147      3.4560826420783997e-01
    z[0,1,0]  R148      5.4048734903335571e-01
    z[0,1,0]  R149      2.2684301435947418e-01
    z[0,1,0]  R150      -9.2979431152343750e-02
    z[0,1,0]  R151      2.9443603754043579e-01
    z[0,1,0]  R152      2.5760591030120850e-01
    z[0,1,0]  R153      4.3460544943809509e-01
    z[0,1,0]  R154      4.8872253298759460e-01
    z[0,1,0]  R155      2.8493699431419373e-01
    z[0,1,0]  R156      2.9913905262947083e-01
    z[0,1,0]  R157      9.7009025514125824e-02
    z[0,1,0]  R158      2.1449652314186096e-01
    z[0,1,0]  R159      3.9007715880870819e-02
    z[0,1,0]  R160      1.5334767103195190e-01
    z[0,1,0]  R161      1.1028088629245758e-01
    z[0,1,0]  R162      2.6020860671997070e-01
    z[0,1,0]  R163      3.3218407630920410e-01
    z[0,1,0]  R164      -2.6661536097526550e-01
    z[0,1,0]  R165      2.1714812517166138e-01
    z[0,1,0]  R166      0.345803439617157
    z[0,1,0]  R167      4.3573182821273804e-01
    z[0,1,0]  R168      -1.0542362183332443e-01
    z[0,1,0]  R169      2.4109083414077759e-01
    z[0,1,0]  R170      -6.7017450928688049e-02
    z[0,1,0]  R171      -5.8976024389266968e-01
    z[0,1,0]  R172      -7.3654323816299438e-01
    z[0,1,0]  R173      -0.987890362739563
    z[0,1,0]  R174      -9.8002976179122925e-01
    z[0,1,0]  R175      -6.2199658155441284e-01
    z[0,1,0]  R176      -7.7160531282424927e-01
    z[0,1,0]  R177      -6.1112409830093384e-01
    z[0,1,0]  R178      -5.7374322414398193e-01
    z[0,1,0]  R179      -5.2528560161590576e-01
    z[0,1,0]  R180      -8.7464380264282227e-01
    z[0,1,0]  R181      -5.4201090335845947e-01
    z[0,1,0]  R182      -2.1386312320828438e-02
    z[0,1,0]  R183      1.2156501412391663e-01
    z[0,1,0]  R184      1.3759654760360718e-01
    z[0,1,0]  R185      6.9021439552307129e-01
    z[0,1,0]  R186      6.7544519901275635e-01
    z[0,1,0]  R187      7.3569852113723755e-01
    z[0,1,0]  R188      0.664685845375061
    z[0,1,0]  R189      -2.3322585038840771e-03
    z[0,1,0]  R190      6.6784366965293884e-02
    z[0,1,0]  R191      6.6822940111160278e-01
    z[0,1,0]  R192      6.3409155607223511e-01
    z[0,1,0]  R193      4.4640770554542542e-01
    z[0,1,0]  R194      6.4137673377990723e-01
    z[0,1,0]  R195      -1.9552423059940338e-01
    z[0,1,0]  R196      5.3327847272157669e-02
    z[0,1,0]  R197      2.4283061921596527e-01
    z[0,1,0]  R198      3.8440009951591492e-01
    z[0,1,0]  R199      -0.611303985118866
    z[0,1,0]  R200      8.9155435562133789e-01
    z[0,1,0]  R201      8.8695609569549561e-01
    z[0,1,0]  R202      7.9040008783340454e-01
    z[0,1,0]  R203      6.4192199707031250e-01
    z[0,1,0]  R204      6.2508374452590942e-01
    z[0,1,0]  R205      -1.5975123643875122e-01
    z[0,1,0]  R206      -1.1772423982620239e-01
    z[0,1,0]  R207      -1.3354407250881195e-01
    z[0,1,0]  R208      1.4820756018161774e-01
    z[0,1,0]  R209      9.3772947788238525e-01
    z[0,1,0]  R210      9.2041648924350739e-02
    z[0,1,0]  R211      6.9201219081878662e-01
    z[0,1,0]  R212      6.9072407484054565e-01
    z[0,1,0]  R213      7.1573674678802490e-01
    z[0,1,0]  R214      7.0400011539459229e-01
    z[0,1,0]  R215      2.2227536141872406e-01
    z[0,1,0]  R216      -1.6008595004677773e-02
    z[0,1,0]  R217      7.2454451583325863e-04
    z[0,1,0]  R218      -6.6037839651107788e-01
    z[0,1,0]  R219      -3.7577390670776367e-02
    z[0,1,0]  R220      8.5246467590332031e-01
    z[0,1,0]  R221      5.9630334377288818e-01
    z[0,1,0]  R222      0.791899561882019
    z[0,1,0]  R223      6.8710917234420776e-01
    z[0,1,0]  R224      4.8072680830955505e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R103      -1
    z[0,1,1]  R104      1
    z[0,1,1]  R115      -4.7224882245063782e-01
    z[0,1,1]  R116      -2.4031297862529755e-01
    z[0,1,1]  R117      -2.0794327557086945e-01
    z[0,1,1]  R118      -3.4598127007484436e-01
    z[0,1,1]  R119      5.5871063470840454e-01
    z[0,1,1]  R120      7.0682919025421143e-01
    z[0,1,1]  R121      6.6753733158111572e-01
    z[0,1,1]  R122      6.7683684825897217e-01
    z[0,1,1]  R123      6.3754743337631226e-01
    z[0,1,1]  R124      6.4540684223175049e-01
    z[0,1,1]  R125      -0.778492271900177
    z[0,1,1]  R126      -3.0248472094535828e-01
    z[0,1,1]  R127      -4.3819853663444519e-01
    z[0,1,1]  R128      -5.4060494899749756e-01
    z[0,1,1]  R129      -3.1929239630699158e-01
    z[0,1,1]  R130      1.3646772503852844e-01
    z[0,1,1]  R131      -6.1155194044113159e-01
    z[0,1,1]  R132      -4.6387916803359985e-01
    z[0,1,1]  R133      1.4054952561855316e-01
    z[0,1,1]  R134      1.6642354428768158e-01
    z[0,1,1]  R135      -6.7393893003463745e-01
    z[0,1,1]  R136      -7.0036292076110840e-01
    z[0,1,1]  R137      1.9068409502506256e-01
    z[0,1,1]  R138      4.6137449145317078e-01
    z[0,1,1]  R139      9.2815555632114410e-02
    z[0,1,1]  R140      3.2422453165054321e-01
    z[0,1,1]  R141      5.9280145168304443e-01
    z[0,1,1]  R142      4.1457760334014893e-01
    z[0,1,1]  R143      2.7077442500740290e-03
    z[0,1,1]  R144      5.5666033178567886e-02
    z[0,1,1]  R145      -6.5842044353485107e-01
    z[0,1,1]  R146      -6.2879538536071777e-01
    z[0,1,1]  R147      -3.1122279167175293e-01
    z[0,1,1]  R148      -6.0055327415466309e-01
    z[0,1,1]  R149      -5.8931209146976471e-02
    z[0,1,1]  R150      4.4835764169692993e-01
    z[0,1,1]  R151      3.6925879120826721e-01
    z[0,1,1]  R152      5.8967101573944092e-01
    z[0,1,1]  R153      -4.6464672684669495e-01
    z[0,1,1]  R154      -6.7998088896274567e-02
    z[0,1,1]  R155      -6.7847508192062378e-01
    z[0,1,1]  R156      -2.8258800506591797e-01
    z[0,1,1]  R157      -6.5462303161621094e-01
    z[0,1,1]  R158      -4.6346828341484070e-01
    z[0,1,1]  R159      6.7375797033309937e-01
    z[0,1,1]  R160      3.4614190459251404e-01
    z[0,1,1]  R161      2.5714039802551270e-01
    z[0,1,1]  R162      1.0153875499963760e-01
    z[0,1,1]  R163      6.2827038764953613e-01
    z[0,1,1]  R164      -2.1211676299571991e-01
    z[0,1,1]  R165      -8.8083219528198242e-01
    z[0,1,1]  R166      -0.313417911529541
    z[0,1,1]  R167      -5.1397383213043213e-01
    z[0,1,1]  R168      2.3133784532546997e-01
    z[0,1,1]  R169      4.7853112220764160e-01
    z[0,1,1]  R170      5.7889532297849655e-02
    z[0,1,1]  R171      -2.1392008662223816e-01
    z[0,1,1]  R172      -1.7244511842727661e-01
    z[0,1,1]  R173      -2.4840043857693672e-02
    z[0,1,1]  R174      -2.9768494889140129e-02
    z[0,1,1]  R175      -2.0145726203918457e-01
    z[0,1,1]  R176      -1.3858614861965179e-01
    z[0,1,1]  R177      -1.5970183908939362e-01
    z[0,1,1]  R178      8.3782915025949478e-03
    z[0,1,1]  R179      4.0934570133686066e-02
    z[0,1,1]  R180      -9.1613650321960449e-02
    z[0,1,1]  R181      -1.4009492099285126e-01
    z[0,1,1]  R182      7.5207066535949707e-01
    z[0,1,1]  R183      6.4621657133102417e-01
    z[0,1,1]  R184      0.71770840883255
    z[0,1,1]  R185      -9.5428124070167542e-02
    z[0,1,1]  R186      -3.6532577872276306e-01
    z[0,1,1]  R187      8.3413898944854736e-02
    z[0,1,1]  R188      -2.2163519263267517e-01
    z[0,1,1]  R189      4.8962447047233582e-01
    z[0,1,1]  R190      5.0277554988861084e-01
    z[0,1,1]  R191      -0.0774131491780281
    z[0,1,1]  R192      0.064273901283741
    z[0,1,1]  R193      4.0270447731018066e-01
    z[0,1,1]  R194      1.2772740423679352e-01
    z[0,1,1]  R195      5.3760612010955811e-01
    z[0,1,1]  R196      7.2069692611694336e-01
    z[0,1,1]  R197      6.8426930904388428e-01
    z[0,1,1]  R198      5.3322786092758179e-01
    z[0,1,1]  R199      2.6189538836479187e-01
    z[0,1,1]  R200      0.014797936193645
    z[0,1,1]  R201      -1.6544732451438904e-01
    z[0,1,1]  R202      -2.5596803426742554e-01
    z[0,1,1]  R203      6.4962941408157349e-01
    z[0,1,1]  R204      4.7971582412719727e-01
    z[0,1,1]  R205      8.3265745639801025e-01
    z[0,1,1]  R206      6.2543904781341553e-01
    z[0,1,1]  R207      9.3071424961090088e-01
    z[0,1,1]  R208      4.6321552991867065e-01
    z[0,1,1]  R209      -4.0591447614133358e-03
    z[0,1,1]  R210      8.1888866424560547e-01
    z[0,1,1]  R211      -1.4921982586383820e-01
    z[0,1,1]  R212      5.6284815073013306e-03
    z[0,1,1]  R213      -2.1217767149209976e-02
    z[0,1,1]  R214      -2.6838175952434540e-02
    z[0,1,1]  R215      0.801459550857544
    z[0,1,1]  R216      6.8712121248245239e-01
    z[0,1,1]  R217      5.8725732564926147e-01
    z[0,1,1]  R218      3.1341657042503357e-01
    z[0,1,1]  R219      7.8473997116088867e-01
    z[0,1,1]  R220      4.4005259871482849e-02
    z[0,1,1]  R221      6.6212427616119385e-01
    z[0,1,1]  R222      1.6940084099769592e-01
    z[0,1,1]  R223      -7.1493655443191528e-02
    z[0,1,1]  R224      2.8783044219017029e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R105      -1
    z[0,1,2]  R106      1
    z[0,1,2]  R115      -6.7709732055664062e-01
    z[0,1,2]  R116      -5.5931544303894043e-01
    z[0,1,2]  R117      -4.7623512148857117e-01
    z[0,1,2]  R118      -2.7966102957725525e-01
    z[0,1,2]  R119      3.9050617814064026e-01
    z[0,1,2]  R120      -2.7524825185537338e-02
    z[0,1,2]  R121      -4.5265871286392212e-01
    z[0,1,2]  R122      0.696992039680481
    z[0,1,2]  R123      6.8835991621017456e-01
    z[0,1,2]  R124      1.3943623006343842e-01
    z[0,1,2]  R125      4.0785029530525208e-01
    z[0,1,2]  R126      3.3817109465599060e-01
    z[0,1,2]  R127      -8.9949861168861389e-02
    z[0,1,2]  R128      3.8095393776893616e-01
    z[0,1,2]  R129      -2.3638767004013062e-01
    z[0,1,2]  R130      -5.5201715230941772e-01
    z[0,1,2]  R131      3.5935759544372559e-01
    z[0,1,2]  R132      9.2700138688087463e-02
    z[0,1,2]  R133      -4.1532891988754272e-01
    z[0,1,2]  R134      -8.6719177663326263e-02
    z[0,1,2]  R135      -2.1706743538379669e-01
    z[0,1,2]  R136      5.7647567987442017e-01
    z[0,1,2]  R137      -3.3014762401580811e-01
    z[0,1,2]  R138      2.4113105237483978e-01
    z[0,1,2]  R139      -1.4318852126598358e-01
    z[0,1,2]  R140      -1.9453892111778259e-01
    z[0,1,2]  R141      -5.7668900489807129e-01
    z[0,1,2]  R142      -3.8162443041801453e-01
    z[0,1,2]  R143      -2.1659135818481445e-01
    z[0,1,2]  R144      6.6283047199249268e-01
    z[0,1,2]  R145      -2.3630486801266670e-02
    z[0,1,2]  R146      5.6355726718902588e-01
    z[0,1,2]  R147      3.0008363723754883e-01
    z[0,1,2]  R148      2.7569776773452759e-01
    z[0,1,2]  R149      2.0158074796199799e-01
    z[0,1,2]  R150      -2.8335064649581909e-01
    z[0,1,2]  R151      -5.1285256631672382e-03
    z[0,1,2]  R152      -1.0086107999086380e-01
    z[0,1,2]  R153      2.3099692165851593e-01
    z[0,1,2]  R154      -2.0253235101699829e-01
    z[0,1,2]  R155      -1.6746936365962029e-02
    z[0,1,2]  R156      1.9643746316432953e-01
    z[0,1,2]  R157      4.2900389432907104e-01
    z[0,1,2]  R158      5.2339839935302734e-01
    z[0,1,2]  R159      -0.21449014544487
    z[0,1,2]  R160      1.7569062113761902e-01
    z[0,1,2]  R161      -6.8381972610950470e-02
    z[0,1,2]  R162      -6.5031272172927856e-01
    z[0,1,2]  R163      -3.7023526430130005e-01
    z[0,1,2]  R164      -3.1954258680343628e-01
    z[0,1,2]  R165      2.5137832760810852e-01
    z[0,1,2]  R166      -1.1959065450355411e-03
    z[0,1,2]  R167      1.4534640312194824e-01
    z[0,1,2]  R168      -0.0912170559167862
    z[0,1,2]  R169      -0.371814101934433
    z[0,1,2]  R170      -6.8299013376235962e-01
    z[0,1,2]  R171      5.8048951625823975e-01
    z[0,1,2]  R172      0.465663880109787
    z[0,1,2]  R173      -5.1258202642202377e-02
    z[0,1,2]  R174      -5.8532193303108215e-02
    z[0,1,2]  R175      6.6310310363769531e-01
    z[0,1,2]  R176      4.5696407556533813e-01
    z[0,1,2]  R177      5.2851074934005737e-01
    z[0,1,2]  R178      5.6326884031295776e-01
    z[0,1,2]  R179      5.3494328260421753e-01
    z[0,1,2]  R180      -7.5360685586929321e-02
    z[0,1,2]  R181      3.4298107028007507e-01
    z[0,1,2]  R182      4.1973754763603210e-01
    z[0,1,2]  R183      -4.4399318099021912e-01
    z[0,1,2]  R184      3.3908709883689880e-01
    z[0,1,2]  R185      5.7380594313144684e-02
    z[0,1,2]  R186      3.3685940504074097e-01
    z[0,1,2]  R187      2.5801190733909607e-01
    z[0,1,2]  R188      -4.4733984395861626e-03
    z[0,1,2]  R189      -2.9572960734367371e-01
    z[0,1,2]  R190      -5.0286841392517090e-01
    z[0,1,2]  R191      7.3213323950767517e-02
    z[0,1,2]  R192      8.4472872316837311e-02
    z[0,1,2]  R193      -4.3464282155036926e-01
    z[0,1,2]  R194      -2.4279408156871796e-01
    z[0,1,2]  R195      -1.1018589884042740e-01
    z[0,1,2]  R196      -4.4181886315345764e-01
    z[0,1,2]  R197      -2.2919611632823944e-01
    z[0,1,2]  R198      -3.0812227725982666e-01
    z[0,1,2]  R199      -5.5857181549072266e-01
    z[0,1,2]  R200      -2.5917384028434753e-01
    z[0,1,2]  R201      2.4740447103977203e-01
    z[0,1,2]  R202      4.0581369400024414e-01
    z[0,1,2]  R203      -3.3495220541954041e-01
    z[0,1,2]  R204      -1.5745951235294342e-01
    z[0,1,2]  R205      2.1437798440456390e-01
    z[0,1,2]  R206      2.3800905793905258e-02
    z[0,1,2]  R207      -1.0439261794090271e-01
    z[0,1,2]  R208      5.1642164587974548e-02
    z[0,1,2]  R209      -7.0118896663188934e-02
    z[0,1,2]  R210      -1.0057786852121353e-01
    z[0,1,2]  R211      3.1586521863937378e-01
    z[0,1,2]  R212      0.470030277967453
    z[0,1,2]  R213      4.2068770527839661e-01
    z[0,1,2]  R214      3.3026865124702454e-01
    z[0,1,2]  R215      -2.4304631352424622e-01
    z[0,1,2]  R216      -6.7676077596843243e-03
    z[0,1,2]  R217      2.8672695159912109e-01
    z[0,1,2]  R218      -0.595943033695221
    z[0,1,2]  R219      1.6902524232864380e-01
    z[0,1,2]  R220      1.3917480409145355e-01
    z[0,1,2]  R221      2.8864562511444092e-01
    z[0,1,2]  R222      -2.4658817052841187e-01
    z[0,1,2]  R223      -1.4873377978801727e-01
    z[0,1,2]  R224      -6.7196351289749146e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R107      -1
    z[0,1,3]  R108      1
    z[0,1,3]  R115      -3.2873129844665527e-01
    z[0,1,3]  R116      -0.733726978302002
    z[0,1,3]  R117      -7.6104903221130371e-01
    z[0,1,3]  R118      -7.4617242813110352e-01
    z[0,1,3]  R119      0.475638747215271
    z[0,1,3]  R120      4.3652123212814331e-01
    z[0,1,3]  R121      3.4440883994102478e-01
    z[0,1,3]  R122      1.3607767224311829e-01
    z[0,1,3]  R123      1.0278584063053131e-01
    z[0,1,3]  R124      3.9048039913177490e-01
    z[0,1,3]  R125      -5.9694103896617889e-02
    z[0,1,3]  R126      -2.0197047293186188e-01
    z[0,1,3]  R127      3.4902864694595337e-01
    z[0,1,3]  R128      6.2709289789199829e-01
    z[0,1,3]  R129      0.418600857257843
    z[0,1,3]  R130      7.2785001993179321e-01
    z[0,1,3]  R131      3.2883867621421814e-01
    z[0,1,3]  R132      6.9586968421936035e-01
    z[0,1,3]  R133      6.2062078714370728e-01
    z[0,1,3]  R134      5.2678108215332031e-01
    z[0,1,3]  R135      1.3882192969322205e-01
    z[0,1,3]  R136      -1.5066896378993988e-01
    z[0,1,3]  R137      7.5012910366058350e-01
    z[0,1,3]  R138      7.8611761331558228e-01
    z[0,1,3]  R139      9.0270715951919556e-01
    z[0,1,3]  R140      6.0128235816955566e-01
    z[0,1,3]  R141      4.2609906196594238e-01
    z[0,1,3]  R142      4.9116230010986328e-01
    z[0,1,3]  R143      1.6706845164299011e-01
    z[0,1,3]  R144      1.0112817585468292e-01
    z[0,1,3]  R145      6.3369296491146088e-02
    z[0,1,3]  R146      -3.8978171348571777e-01
    z[0,1,3]  R147      -0.453967809677124
    z[0,1,3]  R148      6.1738364398479462e-02
    z[0,1,3]  R149      -0.57023686170578
    z[0,1,3]  R150      6.7957216501235962e-01
    z[0,1,3]  R151      6.1126774549484253e-01
    z[0,1,3]  R152      5.6640797853469849e-01
    z[0,1,3]  R153      0.608462393283844
    z[0,1,3]  R154      1.1857683956623077e-01
    z[0,1,3]  R155      3.2778579741716385e-02
    z[0,1,3]  R156      -4.7456124424934387e-01
    z[0,1,3]  R157      -3.6379012465476990e-01
    z[0,1,3]  R158      -0.5050048828125
    z[0,1,3]  R159      5.2811121940612793e-01
    z[0,1,3]  R160      0.809747040271759
    z[0,1,3]  R161      8.0221188068389893e-01
    z[0,1,3]  R162      6.6269218921661377e-01
    z[0,1,3]  R163      2.0073968172073364e-01
    z[0,1,3]  R164      1.8094581365585327e-01
    z[0,1,3]  R165      -0.281004399061203
    z[0,1,3]  R166      -3.3632898330688477e-01
    z[0,1,3]  R167      -1.0761009156703949e-01
    z[0,1,3]  R168      8.3399015665054321e-01
    z[0,1,3]  R169      4.2006936669349670e-01
    z[0,1,3]  R170      3.5046222805976868e-01
    z[0,1,3]  R171      0.442080557346344
    z[0,1,3]  R172      -1.2345826253294945e-03
    z[0,1,3]  R173      -1.2382607907056808e-02
    z[0,1,3]  R174      6.5527997910976410e-02
    z[0,1,3]  R175      3.1341338157653809e-01
    z[0,1,3]  R176      1.8908197060227394e-02
    z[0,1,3]  R177      -2.8964955708943307e-04
    z[0,1,3]  R178      3.0754616856575012e-01
    z[0,1,3]  R179      3.8061305880546570e-02
    z[0,1,3]  R180      -3.1138685345649719e-01
    z[0,1,3]  R181      -4.8708185553550720e-01
    z[0,1,3]  R182      0.396223783493042
    z[0,1,3]  R183      3.7728673219680786e-01
    z[0,1,3]  R184      2.6664876937866211e-01
    z[0,1,3]  R185      1.9758765399456024e-01
    z[0,1,3]  R186      -0.316006600856781
    z[0,1,3]  R187      1.4382773637771606e-01
    z[0,1,3]  R188      -1.5714384615421295e-02
    z[0,1,3]  R189      2.4181540310382843e-01
    z[0,1,3]  R190      3.9540793746709824e-02
    z[0,1,3]  R191      -3.6043757200241089e-01
    z[0,1,3]  R192      2.8433763980865479e-01
    z[0,1,3]  R193      5.7649207115173340e-01
    z[0,1,3]  R194      6.8747989833354950e-02
    z[0,1,3]  R195      7.4214011430740356e-01
    z[0,1,3]  R196      0.188423752784729
    z[0,1,3]  R197      6.4205802977085114e-02
    z[0,1,3]  R198      3.9703199267387390e-01
    z[0,1,3]  R199      2.2820882499217987e-01
    z[0,1,3]  R200      -3.6426779627799988e-01
    z[0,1,3]  R201      1.6558444499969482e-01
    z[0,1,3]  R202      -1.1350209265947342e-01
    z[0,1,3]  R203      1.5309593081474304e-01
    z[0,1,3]  R204      3.5759216547012329e-01
    z[0,1,3]  R205      -3.8059153594076633e-03
    z[0,1,3]  R206      5.3418916463851929e-01
    z[0,1,3]  R207      -1.7636317014694214e-01
    z[0,1,3]  R208      8.4341269731521606e-01
    z[0,1,3]  R209      -1.9268985092639923e-01
    z[0,1,3]  R210      -7.5990550220012665e-02
    z[0,1,3]  R211      2.1354450285434723e-01
    z[0,1,3]  R212      8.6045213043689728e-02
    z[0,1,3]  R213      2.6764717698097229e-01
    z[0,1,3]  R214      1.8788765370845795e-01
    z[0,1,3]  R215      3.0778220295906067e-01
    z[0,1,3]  R216      5.2945107221603394e-01
    z[0,1,3]  R217      0.535443902015686
    z[0,1,3]  R218      2.5708773732185364e-01
    z[0,1,3]  R219      2.3309373855590820e-01
    z[0,1,3]  R220      2.1342009305953979e-01
    z[0,1,3]  R221      -2.1970469970256090e-03
    z[0,1,3]  R222      3.6637461185455322e-01
    z[0,1,3]  R223      -3.9038904011249542e-02
    z[0,1,3]  R224      2.3746024072170258e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R109      -1
    z[0,1,4]  R110      1
    z[0,1,4]  R115      -2.6802113652229309e-01
    z[0,1,4]  R116      1.7432524263858795e-01
    z[0,1,4]  R117      -6.8752519786357880e-02
    z[0,1,4]  R118      -3.9033463597297668e-01
    z[0,1,4]  R119      4.9266198277473450e-01
    z[0,1,4]  R120      -1.7084105312824249e-01
    z[0,1,4]  R121      -3.3883661031723022e-01
    z[0,1,4]  R122      1.4941658079624176e-01
    z[0,1,4]  R123      -7.3917366564273834e-02
    z[0,1,4]  R124      -4.3934765458106995e-01
    z[0,1,4]  R125      3.7126722931861877e-01
    z[0,1,4]  R126      5.6894296407699585e-01
    z[0,1,4]  R127      6.3153481483459473e-01
    z[0,1,4]  R128      -1.7366793751716614e-01
    z[0,1,4]  R129      7.6386392116546631e-01
    z[0,1,4]  R130      1.6112732887268066e-01
    z[0,1,4]  R131      -2.0611390471458435e-01
    z[0,1,4]  R132      -0.188913494348526
    z[0,1,4]  R133      1.7132754623889923e-01
    z[0,1,4]  R134      -1.2172131240367889e-01
    z[0,1,4]  R135      3.9444428682327271e-01
    z[0,1,4]  R136      -2.2004060447216034e-01
    z[0,1,4]  R137      -2.3218648135662079e-01
    z[0,1,4]  R138      3.1064242124557495e-01
    z[0,1,4]  R139      -3.3445060253143311e-01
    z[0,1,4]  R140      -1.5926298499107361e-01
    z[0,1,4]  R141      8.7141036987304688e-02
    z[0,1,4]  R142      0.296341210603714
    z[0,1,4]  R143      7.4925500154495239e-01
    z[0,1,4]  R144      1.8090118467807770e-01
    z[0,1,4]  R145      3.0383455753326416e-01
    z[0,1,4]  R146      -0.0531565397977829
    z[0,1,4]  R147      5.7140409946441650e-01
    z[0,1,4]  R148      3.6725696921348572e-01
    z[0,1,4]  R149      3.3065325021743774e-01
    z[0,1,4]  R150      -6.5303169190883636e-02
    z[0,1,4]  R151      -8.1225261092185974e-02
    z[0,1,4]  R152      1.7698067426681519e-01
    z[0,1,4]  R153      -4.6776652336120605e-02
    z[0,1,4]  R154      7.3799538612365723e-01
    z[0,1,4]  R155      3.8734894990921021e-01
    z[0,1,4]  R156      5.4858493804931641e-01
    z[0,1,4]  R157      -8.4407530725002289e-02
    z[0,1,4]  R158      1.1459092050790787e-01
    z[0,1,4]  R159      4.1720294952392578e-01
    z[0,1,4]  R160      -7.5405344367027283e-02
    z[0,1,4]  R161      2.6427078247070312e-01
    z[0,1,4]  R162      0.0963180661201477
    z[0,1,4]  R163      2.5586834549903870e-01
    z[0,1,4]  R164      -4.5942026376724243e-01
    z[0,1,4]  R165      -6.8166360259056091e-02
    z[0,1,4]  R166      4.4260111451148987e-01
    z[0,1,4]  R167      6.5229707956314087e-01
    z[0,1,4]  R168      1.1829110234975815e-01
    z[0,1,4]  R169      3.7259614467620850e-01
    z[0,1,4]  R170      5.0123053789138794e-01
    z[0,1,4]  R171      1.3138134777545929e-01
    z[0,1,4]  R172      8.4607228636741638e-02
    z[0,1,4]  R173      3.5175226628780365e-02
    z[0,1,4]  R174      1.3092462718486786e-01
    z[0,1,4]  R175      1.1300813406705856e-01
    z[0,1,4]  R176      -3.8642933964729309e-01
    z[0,1,4]  R177      -9.0079814195632935e-02
    z[0,1,4]  R178      8.8150732219219208e-02
    z[0,1,4]  R179      -4.5742020010948181e-01
    z[0,1,4]  R180      1.4216986298561096e-01
    z[0,1,4]  R181      -2.6787242293357849e-01
    z[0,1,4]  R182      2.8083220124244690e-01
    z[0,1,4]  R183      -2.5144872069358826e-01
    z[0,1,4]  R184      -4.9075558781623840e-01
    z[0,1,4]  R185      -3.1574136018753052e-01
    z[0,1,4]  R186      2.3854206502437592e-01
    z[0,1,4]  R187      -3.1173032522201538e-01
    z[0,1,4]  R188      -5.2692997269332409e-03
    z[0,1,4]  R189      4.7481562942266464e-02
    z[0,1,4]  R190      3.9055937528610229e-01
    z[0,1,4]  R191      4.8122027516365051e-01
    z[0,1,4]  R192      2.7622234076261520e-02
    z[0,1,4]  R193      -2.9486179351806641e-01
    z[0,1,4]  R194      5.7679307460784912e-01
    z[0,1,4]  R195      -3.2303687930107117e-01
    z[0,1,4]  R196      1.0006729513406754e-01
    z[0,1,4]  R197      5.4100728034973145e-01
    z[0,1,4]  R198      -1.3723669946193695e-01
    z[0,1,4]  R199      -1.0526290535926819e-01
    z[0,1,4]  R200      -3.9644420146942139e-02
    z[0,1,4]  R201      4.3470472097396851e-02
    z[0,1,4]  R202      -5.1383804529905319e-02
    z[0,1,4]  R203      6.0614768415689468e-02
    z[0,1,4]  R204      3.7498101592063904e-01
    z[0,1,4]  R205      1.7336109280586243e-01
    z[0,1,4]  R206      1.0989484935998917e-01
    z[0,1,4]  R207      5.6798119097948074e-02
    z[0,1,4]  R208      -2.0531460642814636e-01
    z[0,1,4]  R209      -3.3285968005657196e-02
    z[0,1,4]  R210      6.1925571411848068e-02
    z[0,1,4]  R211      4.8588532209396362e-01
    z[0,1,4]  R212      -1.5737848356366158e-02
    z[0,1,4]  R213      2.6537817716598511e-01
    z[0,1,4]  R214      3.6819440126419067e-01
    z[0,1,4]  R215      -0.259318470954895
    z[0,1,4]  R216      -2.8912758827209473e-01
    z[0,1,4]  R217      -1.5906599164009094e-01
    z[0,1,4]  R218      1.1754310876131058e-01
    z[0,1,4]  R219      -3.7735603749752045e-02
    z[0,1,4]  R220      7.8367955982685089e-02
    z[0,1,4]  R221      2.9110535979270935e-01
    z[0,1,4]  R222      3.1753537058830261e-01
    z[0,1,4]  R223      0.500487744808197
    z[0,1,4]  R224      2.1694320440292358e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R111      -1
    z[0,1,5]  R112      1
    z[0,1,5]  R115      1.9301900267601013e-01
    z[0,1,5]  R116      -2.4098545312881470e-01
    z[0,1,5]  R117      -4.5655433088541031e-02
    z[0,1,5]  R118      1.6269695758819580e-01
    z[0,1,5]  R119      1.8156847357749939e-01
    z[0,1,5]  R120      -1.2440264225006104e-01
    z[0,1,5]  R121      3.8067273795604706e-02
    z[0,1,5]  R122      -1.4498769305646420e-02
    z[0,1,5]  R123      2.9701495170593262e-01
    z[0,1,5]  R124      3.2781437039375305e-01
    z[0,1,5]  R125      -2.1783377975225449e-02
    z[0,1,5]  R126      4.9483588337898254e-01
    z[0,1,5]  R127      -2.7746891975402832e-01
    z[0,1,5]  R128      1.7879074811935425e-01
    z[0,1,5]  R129      -1.7395861446857452e-01
    z[0,1,5]  R130      -2.4008019268512726e-01
    z[0,1,5]  R131      -8.0920957028865814e-02
    z[0,1,5]  R132      1.4321397244930267e-01
    z[0,1,5]  R133      -6.2634360790252686e-01
    z[0,1,5]  R134      -1.2070432305335999e-01
    z[0,1,5]  R135      -3.4617307782173157e-01
    z[0,1,5]  R136      1.6461527347564697e-01
    z[0,1,5]  R137      3.6235302686691284e-01
    z[0,1,5]  R138      -8.5086993873119354e-02
    z[0,1,5]  R139      -1.1541321873664856e-01
    z[0,1,5]  R140      -2.9033929109573364e-02
    z[0,1,5]  R141      -3.2463672757148743e-01
    z[0,1,5]  R142      7.1673125028610229e-02
    z[0,1,5]  R143      2.3574155569076538e-01
    z[0,1,5]  R144      2.5926193594932556e-01
    z[0,1,5]  R145      -5.9350800514221191e-01
    z[0,1,5]  R146      -2.5583109259605408e-01
    z[0,1,5]  R147      4.0099734067916870e-01
    z[0,1,5]  R148      2.0111124217510223e-01
    z[0,1,5]  R149      6.6006970405578613e-01
    z[0,1,5]  R150      -4.5121449232101440e-01
    z[0,1,5]  R151      1.1117789149284363e-01
    z[0,1,5]  R152      8.4612101316452026e-02
    z[0,1,5]  R153      4.2945347726345062e-02
    z[0,1,5]  R154      -1.4339463412761688e-01
    z[0,1,5]  R155      1.0627873986959457e-01
    z[0,1,5]  R156      4.5774596929550171e-01
    z[0,1,5]  R157      -1.2302209436893463e-01
    z[0,1,5]  R158      0.358801931142807
    z[0,1,5]  R159      -1.9983839988708496e-01
    z[0,1,5]  R160      7.5674583204090595e-03
    z[0,1,5]  R161      7.5133427977561951e-02
    z[0,1,5]  R162      -1.2881948053836823e-01
    z[0,1,5]  R163      5.0045740604400635e-01
    z[0,1,5]  R164      -7.1160256862640381e-01
    z[0,1,5]  R165      -1.7666870728135109e-02
    z[0,1,5]  R166      0.540652334690094
    z[0,1,5]  R167      -1.1436444520950317e-01
    z[0,1,5]  R168      -3.8335829973220825e-01
    z[0,1,5]  R169      3.3776876330375671e-01
    z[0,1,5]  R170      2.2240476682782173e-02
    z[0,1,5]  R171      2.3721010982990265e-01
    z[0,1,5]  R172      4.4234889745712280e-01
    z[0,1,5]  R173      -1.3516525924205780e-01
    z[0,1,5]  R174      1.0247895121574402e-01
    z[0,1,5]  R175      6.3202202320098877e-02
    z[0,1,5]  R176      -6.3467338681221008e-02
    z[0,1,5]  R177      4.1443473100662231e-01
    z[0,1,5]  R178      3.7782818078994751e-01
    z[0,1,5]  R179      0.377505898475647
    z[0,1,5]  R180      -2.6834335923194885e-01
    z[0,1,5]  R181      -1.7452286183834076e-01
    z[0,1,5]  R182      -0.137746199965477
    z[0,1,5]  R183      1.7691782116889954e-01
    z[0,1,5]  R184      1.9589868187904358e-01
    z[0,1,5]  R185      -2.4177654087543488e-01
    z[0,1,5]  R186      -1.7560409009456635e-01
    z[0,1,5]  R187      -3.9284974336624146e-02
    z[0,1,5]  R188      -6.4603704214096069e-01
    z[0,1,5]  R189      1.7294013500213623e-01
    z[0,1,5]  R190      4.0715911984443665e-01
    z[0,1,5]  R191      3.3415222167968750e-01
    z[0,1,5]  R192      5.5208194255828857e-01
    z[0,1,5]  R193      4.7968883067369461e-02
    z[0,1,5]  R194      3.6822766065597534e-01
    z[0,1,5]  R195      -6.7715913057327271e-02
    z[0,1,5]  R196      3.0593699216842651e-01
    z[0,1,5]  R197      3.3995765447616577e-01
    z[0,1,5]  R198      3.4642115235328674e-01
    z[0,1,5]  R199      1.9710119068622589e-01
    z[0,1,5]  R200      5.4594278335571289e-02
    z[0,1,5]  R201      -2.0859143137931824e-01
    z[0,1,5]  R202      -2.2770951036363840e-03
    z[0,1,5]  R203      -1.1156143993139267e-01
    z[0,1,5]  R204      1.8164552748203278e-01
    z[0,1,5]  R205      4.3474078178405762e-01
    z[0,1,5]  R206      -6.3863977789878845e-02
    z[0,1,5]  R207      2.6505815982818604e-01
    z[0,1,5]  R208      -7.5593672692775726e-02
    z[0,1,5]  R209      -1.3024614751338959e-01
    z[0,1,5]  R210      -2.6933519169688225e-02
    z[0,1,5]  R211      -1.9698639214038849e-01
    z[0,1,5]  R212      4.6172770857810974e-01
    z[0,1,5]  R213      2.6775002479553223e-01
    z[0,1,5]  R214      4.6697062253952026e-01
    z[0,1,5]  R215      2.8888288140296936e-01
    z[0,1,5]  R216      2.0357848703861237e-01
    z[0,1,5]  R217      2.0439730584621429e-01
    z[0,1,5]  R218      5.7083507999777794e-03
    z[0,1,5]  R219      -4.3179920315742493e-01
    z[0,1,5]  R220      4.1979452967643738e-01
    z[0,1,5]  R221      1.8119035661220551e-01
    z[0,1,5]  R222      2.1958269178867340e-01
    z[0,1,5]  R223      2.7326586842536926e-01
    z[0,1,5]  R224      2.7693191170692444e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R113      -1
    z[0,1,6]  R114      1
    z[0,1,6]  R115      4.7831159085035324e-02
    z[0,1,6]  R116      4.9570590257644653e-02
    z[0,1,6]  R117      -3.5549479722976685e-01
    z[0,1,6]  R118      2.2589640319347382e-01
    z[0,1,6]  R119      1.4294235408306122e-01
    z[0,1,6]  R120      0.416781485080719
    z[0,1,6]  R121      3.1296077370643616e-01
    z[0,1,6]  R122      -9.1624319553375244e-02
    z[0,1,6]  R123      -1.2416333705186844e-01
    z[0,1,6]  R124      1.9051942229270935e-01
    z[0,1,6]  R125      2.0645286142826080e-01
    z[0,1,6]  R126      7.9013511538505554e-02
    z[0,1,6]  R127      -9.2519924044609070e-02
    z[0,1,6]  R128      -9.1535985469818115e-02
    z[0,1,6]  R129      -1.0156561620533466e-02
    z[0,1,6]  R130      1.2745884060859680e-01
    z[0,1,6]  R131      -5.1139497756958008e-01
    z[0,1,6]  R132      4.5891612768173218e-01
    z[0,1,6]  R133      1.4600753784179688e-02
    z[0,1,6]  R134      -0.757362961769104
    z[0,1,6]  R135      4.1133561730384827e-01
    z[0,1,6]  R136      -2.4642260372638702e-01
    z[0,1,6]  R137      7.4573710560798645e-02
    z[0,1,6]  R138      -6.8557456135749817e-02
    z[0,1,6]  R139      -1.3689902424812317e-01
    z[0,1,6]  R140      -6.2951588630676270e-01
    z[0,1,6]  R141      -1.4645232260227203e-01
    z[0,1,6]  R142      -4.0977105498313904e-01
    z[0,1,6]  R143      -1.7787131667137146e-01
    z[0,1,6]  R144      -3.5683155059814453e-01
    z[0,1,6]  R145      -2.8236427903175354e-01
    z[0,1,6]  R146      7.7105000615119934e-02
    z[0,1,6]  R147      1.6026712954044342e-02
    z[0,1,6]  R148      -3.0342203378677368e-01
    z[0,1,6]  R149      1.8504323065280914e-01
    z[0,1,6]  R150      -2.0091125369071960e-01
    z[0,1,6]  R151      -6.1993765830993652e-01
    z[0,1,6]  R152      -4.6524727344512939e-01
    z[0,1,6]  R153      -4.0939357876777649e-01
    z[0,1,6]  R154      -3.6911708116531372e-01
    z[0,1,6]  R155      5.4386872053146362e-01
    z[0,1,6]  R156      2.3745955526828766e-01
    z[0,1,6]  R157      -4.7266405820846558e-01
    z[0,1,6]  R158      -2.6142436265945435e-01
    z[0,1,6]  R159      -7.5015507638454437e-02
    z[0,1,6]  R160      -4.0542531013488770e-01
    z[0,1,6]  R161      4.4498637318611145e-01
    z[0,1,6]  R162      1.8450500071048737e-01
    z[0,1,6]  R163      -4.0413599461317062e-02
    z[0,1,6]  R164      -1.7784436047077179e-01
    z[0,1,6]  R165      -1.7282395064830780e-01
    z[0,1,6]  R166      4.2528787255287170e-01
    z[0,1,6]  R167      -2.7329921722412109e-01
    z[0,1,6]  R168      2.6561632752418518e-01
    z[0,1,6]  R169      3.8113471865653992e-01
    z[0,1,6]  R170      -0.38875612616539
    z[0,1,6]  R171      -2.2092990577220917e-02
    z[0,1,6]  R172      8.9952535927295685e-02
    z[0,1,6]  R173      -3.4177824854850769e-02
    z[0,1,6]  R174      -5.7379838079214096e-02
    z[0,1,6]  R175      1.3355225324630737e-01
    z[0,1,6]  R176      1.5129385888576508e-01
    z[0,1,6]  R177      3.7660121917724609e-01
    z[0,1,6]  R178      -3.2919198274612427e-01
    z[0,1,6]  R179      -2.8817105293273926e-01
    z[0,1,6]  R180      -1.7816795408725739e-01
    z[0,1,6]  R181      -4.7906059026718140e-01
    z[0,1,6]  R182      -5.4024152457714081e-02
    z[0,1,6]  R183      3.6554688215255737e-01
    z[0,1,6]  R184      2.5745324790477753e-02
    z[0,1,6]  R185      5.6037104129791260e-01
    z[0,1,6]  R186      3.3051070570945740e-01
    z[0,1,6]  R187      -0.515571653842926
    z[0,1,6]  R188      3.0234414339065552e-01
    z[0,1,6]  R189      -0.762999951839447
    z[0,1,6]  R190      -4.1231209039688110e-01
    z[0,1,6]  R191      -2.6262232661247253e-01
    z[0,1,6]  R192      4.4749930500984192e-01
    z[0,1,6]  R193      -1.6747350990772247e-01
    z[0,1,6]  R194      -2.0090888440608978e-01
    z[0,1,6]  R195      -2.9980879276990891e-02
    z[0,1,6]  R196      -3.7872657179832458e-01
    z[0,1,6]  R197      -8.8856205344200134e-02
    z[0,1,6]  R198      -4.2010641098022461e-01
    z[0,1,6]  R199      3.7908756732940674e-01
    z[0,1,6]  R200      2.2304451093077660e-02
    z[0,1,6]  R201      2.2783493995666504e-01
    z[0,1,6]  R202      3.5991007089614868e-01
    z[0,1,6]  R203      -1.1902172863483429e-01
    z[0,1,6]  R204      -2.2993825376033783e-01
    z[0,1,6]  R205      1.2702395021915436e-01
    z[0,1,6]  R206      5.4119038581848145e-01
    z[0,1,6]  R207      2.1290307864546776e-02
    z[0,1,6]  R208      -3.9817806333303452e-02
    z[0,1,6]  R209      -2.4602632224559784e-01
    z[0,1,6]  R210      0.54817795753479
    z[0,1,6]  R211      -2.8034329414367676e-01
    z[0,1,6]  R212      -2.8477391600608826e-01
    z[0,1,6]  R213      -3.1071197986602783e-01
    z[0,1,6]  R214      -7.5204953551292419e-02
    z[0,1,6]  R215      6.1281401664018631e-02
    z[0,1,6]  R216      -3.4957808256149292e-01
    z[0,1,6]  R217      4.6811914443969727e-01
    z[0,1,6]  R218      -1.7486895620822906e-01
    z[0,1,6]  R219      3.3465558290481567e-01
    z[0,1,6]  R220      1.5518032014369965e-01
    z[0,1,6]  R221      7.1556642651557922e-02
    z[0,1,6]  R222      1.0816410183906555e-02
    z[0,1,6]  R223      4.1708725690841675e-01
    z[0,1,6]  R224      2.3318928480148315e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R225      -1
    z[1,0,0]  R226      1
    z[1,0,0]  R239      -6.2199658155441284e-01
    z[1,0,0]  R240      -7.7160531282424927e-01
    z[1,0,0]  R241      -6.1112409830093384e-01
    z[1,0,0]  R242      -5.7374322414398193e-01
    z[1,0,0]  R243      -5.2528560161590576e-01
    z[1,0,0]  R244      -8.7464380264282227e-01
    z[1,0,0]  R245      -5.4201090335845947e-01
    z[1,0,0]  R246      -2.1386312320828438e-02
    z[1,0,0]  R247      1.2156501412391663e-01
    z[1,0,0]  R248      1.3759654760360718e-01
    z[1,0,0]  R249      6.9021439552307129e-01
    z[1,0,0]  R250      6.7544519901275635e-01
    z[1,0,0]  R251      7.3569852113723755e-01
    z[1,0,0]  R252      0.664685845375061
    z[1,0,0]  R253      -2.3322585038840771e-03
    z[1,0,0]  R254      6.6784366965293884e-02
    z[1,0,0]  R255      6.6822940111160278e-01
    z[1,0,0]  R256      6.3409155607223511e-01
    z[1,0,0]  R257      4.4640770554542542e-01
    z[1,0,0]  R258      6.4137673377990723e-01
    z[1,0,0]  R259      -1.9552423059940338e-01
    z[1,0,0]  R260      5.3327847272157669e-02
    z[1,0,0]  R261      2.4283061921596527e-01
    z[1,0,0]  R262      3.8440009951591492e-01
    z[1,0,0]  R263      -0.611303985118866
    z[1,0,0]  R264      8.9155435562133789e-01
    z[1,0,0]  R265      8.8695609569549561e-01
    z[1,0,0]  R266      7.9040008783340454e-01
    z[1,0,0]  R267      6.4192199707031250e-01
    z[1,0,0]  R268      6.2508374452590942e-01
    z[1,0,0]  R269      -1.5975123643875122e-01
    z[1,0,0]  R270      -1.1772423982620239e-01
    z[1,0,0]  R271      -1.3354407250881195e-01
    z[1,0,0]  R272      1.4820756018161774e-01
    z[1,0,0]  R273      9.3772947788238525e-01
    z[1,0,0]  R274      9.2041648924350739e-02
    z[1,0,0]  R275      6.9201219081878662e-01
    z[1,0,0]  R276      6.9072407484054565e-01
    z[1,0,0]  R277      7.1573674678802490e-01
    z[1,0,0]  R278      7.0400011539459229e-01
    z[1,0,0]  R279      2.2227536141872406e-01
    z[1,0,0]  R280      -1.6008595004677773e-02
    z[1,0,0]  R281      7.2454451583325863e-04
    z[1,0,0]  R282      -6.6037839651107788e-01
    z[1,0,0]  R283      -3.7577390670776367e-02
    z[1,0,0]  R284      8.5246467590332031e-01
    z[1,0,0]  R285      5.9630334377288818e-01
    z[1,0,0]  R286      0.791899561882019
    z[1,0,0]  R287      6.8710917234420776e-01
    z[1,0,0]  R288      4.8072680830955505e-01
    z[1,0,0]  R289      3.1476408243179321e-01
    z[1,0,0]  R290      1.1834477074444294e-02
    z[1,0,0]  R291      1.3257554173469543e-01
    z[1,0,0]  R292      -1.2430892139673233e-01
    z[1,0,0]  R293      1.1401630938053131e-01
    z[1,0,0]  R294      -3.0118885636329651e-01
    z[1,0,0]  R295      1.2912358343601227e-01
    z[1,0,0]  R296      0.0815248116850853
    z[1,0,0]  R297      0.00552970077842474
    z[1,0,0]  R298      -2.7339807152748108e-01
    z[1,0,0]  R299      2.0762410759925842e-01
    z[1,0,0]  R300      4.2255121469497681e-01
    z[1,0,0]  R301      4.4009661674499512e-01
    z[1,0,0]  R302      3.1443512439727783e-01
    z[1,0,0]  R303      2.3042079806327820e-01
    z[1,0,0]  R304      2.1689118444919586e-01
    z[1,0,0]  R305      2.7959862351417542e-01
    z[1,0,0]  R306      1.5870036184787750e-01
    z[1,0,0]  R307      -2.6550387963652611e-02
    z[1,0,0]  R308      2.9034525156021118e-01
    z[1,0,0]  R309      1.8654049932956696e-01
    z[1,0,0]  R310      1.3500507175922394e-01
    z[1,0,0]  R311      3.1808316707611084e-01
    z[1,0,0]  R312      5.0692677497863770e-02
    z[1,0,0]  R313      1.0992458462715149e-01
    z[1,0,0]  R314      2.7017506957054138e-01
    z[1,0,0]  R315      -4.9938973970711231e-03
    z[1,0,0]  R316      4.2471197247505188e-01
    z[1,0,0]  R317      5.2590274810791016e-01
    z[1,0,0]  R318      -5.6573790311813354e-01
    z[1,0,0]  R319      1.9393743574619293e-01
    z[1,0,0]  R320      -2.4671745300292969e-01
    z[1,0,0]  R321      3.4560826420783997e-01
    z[1,0,0]  R322      5.4048734903335571e-01
    z[1,0,0]  R323      2.2684301435947418e-01
    z[1,0,0]  R324      -9.2979431152343750e-02
    z[1,0,0]  R325      2.9443603754043579e-01
    z[1,0,0]  R326      2.5760591030120850e-01
    z[1,0,0]  R327      4.3460544943809509e-01
    z[1,0,0]  R328      4.8872253298759460e-01
    z[1,0,0]  R329      2.8493699431419373e-01
    z[1,0,0]  R330      2.9913905262947083e-01
    z[1,0,0]  R331      9.7009025514125824e-02
    z[1,0,0]  R332      2.1449652314186096e-01
    z[1,0,0]  R333      3.9007715880870819e-02
    z[1,0,0]  R334      1.5334767103195190e-01
    z[1,0,0]  R335      1.1028088629245758e-01
    z[1,0,0]  R336      2.6020860671997070e-01
    z[1,0,0]  R337      3.3218407630920410e-01
    z[1,0,0]  R338      -2.6661536097526550e-01
    z[1,0,0]  R339      2.1714812517166138e-01
    z[1,0,0]  R340      0.345803439617157
    z[1,0,0]  R341      4.3573182821273804e-01
    z[1,0,0]  R342      -1.0542362183332443e-01
    z[1,0,0]  R343      2.4109083414077759e-01
    z[1,0,0]  R344      -6.7017450928688049e-02
    z[1,0,0]  R345      -5.8976024389266968e-01
    z[1,0,0]  R346      -7.3654323816299438e-01
    z[1,0,0]  R347      -0.987890362739563
    z[1,0,0]  R348      -9.8002976179122925e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R227      -1
    z[1,0,1]  R228      1
    z[1,0,1]  R239      -2.0145726203918457e-01
    z[1,0,1]  R240      -1.3858614861965179e-01
    z[1,0,1]  R241      -1.5970183908939362e-01
    z[1,0,1]  R242      8.3782915025949478e-03
    z[1,0,1]  R243      4.0934570133686066e-02
    z[1,0,1]  R244      -9.1613650321960449e-02
    z[1,0,1]  R245      -1.4009492099285126e-01
    z[1,0,1]  R246      7.5207066535949707e-01
    z[1,0,1]  R247      6.4621657133102417e-01
    z[1,0,1]  R248      0.71770840883255
    z[1,0,1]  R249      -9.5428124070167542e-02
    z[1,0,1]  R250      -3.6532577872276306e-01
    z[1,0,1]  R251      8.3413898944854736e-02
    z[1,0,1]  R252      -2.2163519263267517e-01
    z[1,0,1]  R253      4.8962447047233582e-01
    z[1,0,1]  R254      5.0277554988861084e-01
    z[1,0,1]  R255      -0.0774131491780281
    z[1,0,1]  R256      0.064273901283741
    z[1,0,1]  R257      4.0270447731018066e-01
    z[1,0,1]  R258      1.2772740423679352e-01
    z[1,0,1]  R259      5.3760612010955811e-01
    z[1,0,1]  R260      7.2069692611694336e-01
    z[1,0,1]  R261      6.8426930904388428e-01
    z[1,0,1]  R262      5.3322786092758179e-01
    z[1,0,1]  R263      2.6189538836479187e-01
    z[1,0,1]  R264      0.014797936193645
    z[1,0,1]  R265      -1.6544732451438904e-01
    z[1,0,1]  R266      -2.5596803426742554e-01
    z[1,0,1]  R267      6.4962941408157349e-01
    z[1,0,1]  R268      4.7971582412719727e-01
    z[1,0,1]  R269      8.3265745639801025e-01
    z[1,0,1]  R270      6.2543904781341553e-01
    z[1,0,1]  R271      9.3071424961090088e-01
    z[1,0,1]  R272      4.6321552991867065e-01
    z[1,0,1]  R273      -4.0591447614133358e-03
    z[1,0,1]  R274      8.1888866424560547e-01
    z[1,0,1]  R275      -1.4921982586383820e-01
    z[1,0,1]  R276      5.6284815073013306e-03
    z[1,0,1]  R277      -2.1217767149209976e-02
    z[1,0,1]  R278      -2.6838175952434540e-02
    z[1,0,1]  R279      0.801459550857544
    z[1,0,1]  R280      6.8712121248245239e-01
    z[1,0,1]  R281      5.8725732564926147e-01
    z[1,0,1]  R282      3.1341657042503357e-01
    z[1,0,1]  R283      7.8473997116088867e-01
    z[1,0,1]  R284      4.4005259871482849e-02
    z[1,0,1]  R285      6.6212427616119385e-01
    z[1,0,1]  R286      1.6940084099769592e-01
    z[1,0,1]  R287      -7.1493655443191528e-02
    z[1,0,1]  R288      2.8783044219017029e-01
    z[1,0,1]  R289      -4.7224882245063782e-01
    z[1,0,1]  R290      -2.4031297862529755e-01
    z[1,0,1]  R291      -2.0794327557086945e-01
    z[1,0,1]  R292      -3.4598127007484436e-01
    z[1,0,1]  R293      5.5871063470840454e-01
    z[1,0,1]  R294      7.0682919025421143e-01
    z[1,0,1]  R295      6.6753733158111572e-01
    z[1,0,1]  R296      6.7683684825897217e-01
    z[1,0,1]  R297      6.3754743337631226e-01
    z[1,0,1]  R298      6.4540684223175049e-01
    z[1,0,1]  R299      -0.778492271900177
    z[1,0,1]  R300      -3.0248472094535828e-01
    z[1,0,1]  R301      -4.3819853663444519e-01
    z[1,0,1]  R302      -5.4060494899749756e-01
    z[1,0,1]  R303      -3.1929239630699158e-01
    z[1,0,1]  R304      1.3646772503852844e-01
    z[1,0,1]  R305      -6.1155194044113159e-01
    z[1,0,1]  R306      -4.6387916803359985e-01
    z[1,0,1]  R307      1.4054952561855316e-01
    z[1,0,1]  R308      1.6642354428768158e-01
    z[1,0,1]  R309      -6.7393893003463745e-01
    z[1,0,1]  R310      -7.0036292076110840e-01
    z[1,0,1]  R311      1.9068409502506256e-01
    z[1,0,1]  R312      4.6137449145317078e-01
    z[1,0,1]  R313      9.2815555632114410e-02
    z[1,0,1]  R314      3.2422453165054321e-01
    z[1,0,1]  R315      5.9280145168304443e-01
    z[1,0,1]  R316      4.1457760334014893e-01
    z[1,0,1]  R317      2.7077442500740290e-03
    z[1,0,1]  R318      5.5666033178567886e-02
    z[1,0,1]  R319      -6.5842044353485107e-01
    z[1,0,1]  R320      -6.2879538536071777e-01
    z[1,0,1]  R321      -3.1122279167175293e-01
    z[1,0,1]  R322      -6.0055327415466309e-01
    z[1,0,1]  R323      -5.8931209146976471e-02
    z[1,0,1]  R324      4.4835764169692993e-01
    z[1,0,1]  R325      3.6925879120826721e-01
    z[1,0,1]  R326      5.8967101573944092e-01
    z[1,0,1]  R327      -4.6464672684669495e-01
    z[1,0,1]  R328      -6.7998088896274567e-02
    z[1,0,1]  R329      -6.7847508192062378e-01
    z[1,0,1]  R330      -2.8258800506591797e-01
    z[1,0,1]  R331      -6.5462303161621094e-01
    z[1,0,1]  R332      -4.6346828341484070e-01
    z[1,0,1]  R333      6.7375797033309937e-01
    z[1,0,1]  R334      3.4614190459251404e-01
    z[1,0,1]  R335      2.5714039802551270e-01
    z[1,0,1]  R336      1.0153875499963760e-01
    z[1,0,1]  R337      6.2827038764953613e-01
    z[1,0,1]  R338      -2.1211676299571991e-01
    z[1,0,1]  R339      -8.8083219528198242e-01
    z[1,0,1]  R340      -0.313417911529541
    z[1,0,1]  R341      -5.1397383213043213e-01
    z[1,0,1]  R342      2.3133784532546997e-01
    z[1,0,1]  R343      4.7853112220764160e-01
    z[1,0,1]  R344      5.7889532297849655e-02
    z[1,0,1]  R345      -2.1392008662223816e-01
    z[1,0,1]  R346      -1.7244511842727661e-01
    z[1,0,1]  R347      -2.4840043857693672e-02
    z[1,0,1]  R348      -2.9768494889140129e-02
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R229      -1
    z[1,0,2]  R230      1
    z[1,0,2]  R239      6.6310310363769531e-01
    z[1,0,2]  R240      4.5696407556533813e-01
    z[1,0,2]  R241      5.2851074934005737e-01
    z[1,0,2]  R242      5.6326884031295776e-01
    z[1,0,2]  R243      5.3494328260421753e-01
    z[1,0,2]  R244      -7.5360685586929321e-02
    z[1,0,2]  R245      3.4298107028007507e-01
    z[1,0,2]  R246      4.1973754763603210e-01
    z[1,0,2]  R247      -4.4399318099021912e-01
    z[1,0,2]  R248      3.3908709883689880e-01
    z[1,0,2]  R249      5.7380594313144684e-02
    z[1,0,2]  R250      3.3685940504074097e-01
    z[1,0,2]  R251      2.5801190733909607e-01
    z[1,0,2]  R252      -4.4733984395861626e-03
    z[1,0,2]  R253      -2.9572960734367371e-01
    z[1,0,2]  R254      -5.0286841392517090e-01
    z[1,0,2]  R255      7.3213323950767517e-02
    z[1,0,2]  R256      8.4472872316837311e-02
    z[1,0,2]  R257      -4.3464282155036926e-01
    z[1,0,2]  R258      -2.4279408156871796e-01
    z[1,0,2]  R259      -1.1018589884042740e-01
    z[1,0,2]  R260      -4.4181886315345764e-01
    z[1,0,2]  R261      -2.2919611632823944e-01
    z[1,0,2]  R262      -3.0812227725982666e-01
    z[1,0,2]  R263      -5.5857181549072266e-01
    z[1,0,2]  R264      -2.5917384028434753e-01
    z[1,0,2]  R265      2.4740447103977203e-01
    z[1,0,2]  R266      4.0581369400024414e-01
    z[1,0,2]  R267      -3.3495220541954041e-01
    z[1,0,2]  R268      -1.5745951235294342e-01
    z[1,0,2]  R269      2.1437798440456390e-01
    z[1,0,2]  R270      2.3800905793905258e-02
    z[1,0,2]  R271      -1.0439261794090271e-01
    z[1,0,2]  R272      5.1642164587974548e-02
    z[1,0,2]  R273      -7.0118896663188934e-02
    z[1,0,2]  R274      -1.0057786852121353e-01
    z[1,0,2]  R275      3.1586521863937378e-01
    z[1,0,2]  R276      0.470030277967453
    z[1,0,2]  R277      4.2068770527839661e-01
    z[1,0,2]  R278      3.3026865124702454e-01
    z[1,0,2]  R279      -2.4304631352424622e-01
    z[1,0,2]  R280      -6.7676077596843243e-03
    z[1,0,2]  R281      2.8672695159912109e-01
    z[1,0,2]  R282      -0.595943033695221
    z[1,0,2]  R283      1.6902524232864380e-01
    z[1,0,2]  R284      1.3917480409145355e-01
    z[1,0,2]  R285      2.8864562511444092e-01
    z[1,0,2]  R286      -2.4658817052841187e-01
    z[1,0,2]  R287      -1.4873377978801727e-01
    z[1,0,2]  R288      -6.7196351289749146e-01
    z[1,0,2]  R289      -6.7709732055664062e-01
    z[1,0,2]  R290      -5.5931544303894043e-01
    z[1,0,2]  R291      -4.7623512148857117e-01
    z[1,0,2]  R292      -2.7966102957725525e-01
    z[1,0,2]  R293      3.9050617814064026e-01
    z[1,0,2]  R294      -2.7524825185537338e-02
    z[1,0,2]  R295      -4.5265871286392212e-01
    z[1,0,2]  R296      0.696992039680481
    z[1,0,2]  R297      6.8835991621017456e-01
    z[1,0,2]  R298      1.3943623006343842e-01
    z[1,0,2]  R299      4.0785029530525208e-01
    z[1,0,2]  R300      3.3817109465599060e-01
    z[1,0,2]  R301      -8.9949861168861389e-02
    z[1,0,2]  R302      3.8095393776893616e-01
    z[1,0,2]  R303      -2.3638767004013062e-01
    z[1,0,2]  R304      -5.5201715230941772e-01
    z[1,0,2]  R305      3.5935759544372559e-01
    z[1,0,2]  R306      9.2700138688087463e-02
    z[1,0,2]  R307      -4.1532891988754272e-01
    z[1,0,2]  R308      -8.6719177663326263e-02
    z[1,0,2]  R309      -2.1706743538379669e-01
    z[1,0,2]  R310      5.7647567987442017e-01
    z[1,0,2]  R311      -3.3014762401580811e-01
    z[1,0,2]  R312      2.4113105237483978e-01
    z[1,0,2]  R313      -1.4318852126598358e-01
    z[1,0,2]  R314      -1.9453892111778259e-01
    z[1,0,2]  R315      -5.7668900489807129e-01
    z[1,0,2]  R316      -3.8162443041801453e-01
    z[1,0,2]  R317      -2.1659135818481445e-01
    z[1,0,2]  R318      6.6283047199249268e-01
    z[1,0,2]  R319      -2.3630486801266670e-02
    z[1,0,2]  R320      5.6355726718902588e-01
    z[1,0,2]  R321      3.0008363723754883e-01
    z[1,0,2]  R322      2.7569776773452759e-01
    z[1,0,2]  R323      2.0158074796199799e-01
    z[1,0,2]  R324      -2.8335064649581909e-01
    z[1,0,2]  R325      -5.1285256631672382e-03
    z[1,0,2]  R326      -1.0086107999086380e-01
    z[1,0,2]  R327      2.3099692165851593e-01
    z[1,0,2]  R328      -2.0253235101699829e-01
    z[1,0,2]  R329      -1.6746936365962029e-02
    z[1,0,2]  R330      1.9643746316432953e-01
    z[1,0,2]  R331      4.2900389432907104e-01
    z[1,0,2]  R332      5.2339839935302734e-01
    z[1,0,2]  R333      -0.21449014544487
    z[1,0,2]  R334      1.7569062113761902e-01
    z[1,0,2]  R335      -6.8381972610950470e-02
    z[1,0,2]  R336      -6.5031272172927856e-01
    z[1,0,2]  R337      -3.7023526430130005e-01
    z[1,0,2]  R338      -3.1954258680343628e-01
    z[1,0,2]  R339      2.5137832760810852e-01
    z[1,0,2]  R340      -1.1959065450355411e-03
    z[1,0,2]  R341      1.4534640312194824e-01
    z[1,0,2]  R342      -0.0912170559167862
    z[1,0,2]  R343      -0.371814101934433
    z[1,0,2]  R344      -6.8299013376235962e-01
    z[1,0,2]  R345      5.8048951625823975e-01
    z[1,0,2]  R346      0.465663880109787
    z[1,0,2]  R347      -5.1258202642202377e-02
    z[1,0,2]  R348      -5.8532193303108215e-02
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R231      -1
    z[1,0,3]  R232      1
    z[1,0,3]  R239      3.1341338157653809e-01
    z[1,0,3]  R240      1.8908197060227394e-02
    z[1,0,3]  R241      -2.8964955708943307e-04
    z[1,0,3]  R242      3.0754616856575012e-01
    z[1,0,3]  R243      3.8061305880546570e-02
    z[1,0,3]  R244      -3.1138685345649719e-01
    z[1,0,3]  R245      -4.8708185553550720e-01
    z[1,0,3]  R246      0.396223783493042
    z[1,0,3]  R247      3.7728673219680786e-01
    z[1,0,3]  R248      2.6664876937866211e-01
    z[1,0,3]  R249      1.9758765399456024e-01
    z[1,0,3]  R250      -0.316006600856781
    z[1,0,3]  R251      1.4382773637771606e-01
    z[1,0,3]  R252      -1.5714384615421295e-02
    z[1,0,3]  R253      2.4181540310382843e-01
    z[1,0,3]  R254      3.9540793746709824e-02
    z[1,0,3]  R255      -3.6043757200241089e-01
    z[1,0,3]  R256      2.8433763980865479e-01
    z[1,0,3]  R257      5.7649207115173340e-01
    z[1,0,3]  R258      6.8747989833354950e-02
    z[1,0,3]  R259      7.4214011430740356e-01
    z[1,0,3]  R260      0.188423752784729
    z[1,0,3]  R261      6.4205802977085114e-02
    z[1,0,3]  R262      3.9703199267387390e-01
    z[1,0,3]  R263      2.2820882499217987e-01
    z[1,0,3]  R264      -3.6426779627799988e-01
    z[1,0,3]  R265      1.6558444499969482e-01
    z[1,0,3]  R266      -1.1350209265947342e-01
    z[1,0,3]  R267      1.5309593081474304e-01
    z[1,0,3]  R268      3.5759216547012329e-01
    z[1,0,3]  R269      -3.8059153594076633e-03
    z[1,0,3]  R270      5.3418916463851929e-01
    z[1,0,3]  R271      -1.7636317014694214e-01
    z[1,0,3]  R272      8.4341269731521606e-01
    z[1,0,3]  R273      -1.9268985092639923e-01
    z[1,0,3]  R274      -7.5990550220012665e-02
    z[1,0,3]  R275      2.1354450285434723e-01
    z[1,0,3]  R276      8.6045213043689728e-02
    z[1,0,3]  R277      2.6764717698097229e-01
    z[1,0,3]  R278      1.8788765370845795e-01
    z[1,0,3]  R279      3.0778220295906067e-01
    z[1,0,3]  R280      5.2945107221603394e-01
    z[1,0,3]  R281      0.535443902015686
    z[1,0,3]  R282      2.5708773732185364e-01
    z[1,0,3]  R283      2.3309373855590820e-01
    z[1,0,3]  R284      2.1342009305953979e-01
    z[1,0,3]  R285      -2.1970469970256090e-03
    z[1,0,3]  R286      3.6637461185455322e-01
    z[1,0,3]  R287      -3.9038904011249542e-02
    z[1,0,3]  R288      2.3746024072170258e-01
    z[1,0,3]  R289      -3.2873129844665527e-01
    z[1,0,3]  R290      -0.733726978302002
    z[1,0,3]  R291      -7.6104903221130371e-01
    z[1,0,3]  R292      -7.4617242813110352e-01
    z[1,0,3]  R293      0.475638747215271
    z[1,0,3]  R294      4.3652123212814331e-01
    z[1,0,3]  R295      3.4440883994102478e-01
    z[1,0,3]  R296      1.3607767224311829e-01
    z[1,0,3]  R297      1.0278584063053131e-01
    z[1,0,3]  R298      3.9048039913177490e-01
    z[1,0,3]  R299      -5.9694103896617889e-02
    z[1,0,3]  R300      -2.0197047293186188e-01
    z[1,0,3]  R301      3.4902864694595337e-01
    z[1,0,3]  R302      6.2709289789199829e-01
    z[1,0,3]  R303      0.418600857257843
    z[1,0,3]  R304      7.2785001993179321e-01
    z[1,0,3]  R305      3.2883867621421814e-01
    z[1,0,3]  R306      6.9586968421936035e-01
    z[1,0,3]  R307      6.2062078714370728e-01
    z[1,0,3]  R308      5.2678108215332031e-01
    z[1,0,3]  R309      1.3882192969322205e-01
    z[1,0,3]  R310      -1.5066896378993988e-01
    z[1,0,3]  R311      7.5012910366058350e-01
    z[1,0,3]  R312      7.8611761331558228e-01
    z[1,0,3]  R313      9.0270715951919556e-01
    z[1,0,3]  R314      6.0128235816955566e-01
    z[1,0,3]  R315      4.2609906196594238e-01
    z[1,0,3]  R316      4.9116230010986328e-01
    z[1,0,3]  R317      1.6706845164299011e-01
    z[1,0,3]  R318      1.0112817585468292e-01
    z[1,0,3]  R319      6.3369296491146088e-02
    z[1,0,3]  R320      -3.8978171348571777e-01
    z[1,0,3]  R321      -0.453967809677124
    z[1,0,3]  R322      6.1738364398479462e-02
    z[1,0,3]  R323      -0.57023686170578
    z[1,0,3]  R324      6.7957216501235962e-01
    z[1,0,3]  R325      6.1126774549484253e-01
    z[1,0,3]  R326      5.6640797853469849e-01
    z[1,0,3]  R327      0.608462393283844
    z[1,0,3]  R328      1.1857683956623077e-01
    z[1,0,3]  R329      3.2778579741716385e-02
    z[1,0,3]  R330      -4.7456124424934387e-01
    z[1,0,3]  R331      -3.6379012465476990e-01
    z[1,0,3]  R332      -0.5050048828125
    z[1,0,3]  R333      5.2811121940612793e-01
    z[1,0,3]  R334      0.809747040271759
    z[1,0,3]  R335      8.0221188068389893e-01
    z[1,0,3]  R336      6.6269218921661377e-01
    z[1,0,3]  R337      2.0073968172073364e-01
    z[1,0,3]  R338      1.8094581365585327e-01
    z[1,0,3]  R339      -0.281004399061203
    z[1,0,3]  R340      -3.3632898330688477e-01
    z[1,0,3]  R341      -1.0761009156703949e-01
    z[1,0,3]  R342      8.3399015665054321e-01
    z[1,0,3]  R343      4.2006936669349670e-01
    z[1,0,3]  R344      3.5046222805976868e-01
    z[1,0,3]  R345      0.442080557346344
    z[1,0,3]  R346      -1.2345826253294945e-03
    z[1,0,3]  R347      -1.2382607907056808e-02
    z[1,0,3]  R348      6.5527997910976410e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R233      -1
    z[1,0,4]  R234      1
    z[1,0,4]  R239      1.1300813406705856e-01
    z[1,0,4]  R240      -3.8642933964729309e-01
    z[1,0,4]  R241      -9.0079814195632935e-02
    z[1,0,4]  R242      8.8150732219219208e-02
    z[1,0,4]  R243      -4.5742020010948181e-01
    z[1,0,4]  R244      1.4216986298561096e-01
    z[1,0,4]  R245      -2.6787242293357849e-01
    z[1,0,4]  R246      2.8083220124244690e-01
    z[1,0,4]  R247      -2.5144872069358826e-01
    z[1,0,4]  R248      -4.9075558781623840e-01
    z[1,0,4]  R249      -3.1574136018753052e-01
    z[1,0,4]  R250      2.3854206502437592e-01
    z[1,0,4]  R251      -3.1173032522201538e-01
    z[1,0,4]  R252      -5.2692997269332409e-03
    z[1,0,4]  R253      4.7481562942266464e-02
    z[1,0,4]  R254      3.9055937528610229e-01
    z[1,0,4]  R255      4.8122027516365051e-01
    z[1,0,4]  R256      2.7622234076261520e-02
    z[1,0,4]  R257      -2.9486179351806641e-01
    z[1,0,4]  R258      5.7679307460784912e-01
    z[1,0,4]  R259      -3.2303687930107117e-01
    z[1,0,4]  R260      1.0006729513406754e-01
    z[1,0,4]  R261      5.4100728034973145e-01
    z[1,0,4]  R262      -1.3723669946193695e-01
    z[1,0,4]  R263      -1.0526290535926819e-01
    z[1,0,4]  R264      -3.9644420146942139e-02
    z[1,0,4]  R265      4.3470472097396851e-02
    z[1,0,4]  R266      -5.1383804529905319e-02
    z[1,0,4]  R267      6.0614768415689468e-02
    z[1,0,4]  R268      3.7498101592063904e-01
    z[1,0,4]  R269      1.7336109280586243e-01
    z[1,0,4]  R270      1.0989484935998917e-01
    z[1,0,4]  R271      5.6798119097948074e-02
    z[1,0,4]  R272      -2.0531460642814636e-01
    z[1,0,4]  R273      -3.3285968005657196e-02
    z[1,0,4]  R274      6.1925571411848068e-02
    z[1,0,4]  R275      4.8588532209396362e-01
    z[1,0,4]  R276      -1.5737848356366158e-02
    z[1,0,4]  R277      2.6537817716598511e-01
    z[1,0,4]  R278      3.6819440126419067e-01
    z[1,0,4]  R279      -0.259318470954895
    z[1,0,4]  R280      -2.8912758827209473e-01
    z[1,0,4]  R281      -1.5906599164009094e-01
    z[1,0,4]  R282      1.1754310876131058e-01
    z[1,0,4]  R283      -3.7735603749752045e-02
    z[1,0,4]  R284      7.8367955982685089e-02
    z[1,0,4]  R285      2.9110535979270935e-01
    z[1,0,4]  R286      3.1753537058830261e-01
    z[1,0,4]  R287      0.500487744808197
    z[1,0,4]  R288      2.1694320440292358e-01
    z[1,0,4]  R289      -2.6802113652229309e-01
    z[1,0,4]  R290      1.7432524263858795e-01
    z[1,0,4]  R291      -6.8752519786357880e-02
    z[1,0,4]  R292      -3.9033463597297668e-01
    z[1,0,4]  R293      4.9266198277473450e-01
    z[1,0,4]  R294      -1.7084105312824249e-01
    z[1,0,4]  R295      -3.3883661031723022e-01
    z[1,0,4]  R296      1.4941658079624176e-01
    z[1,0,4]  R297      -7.3917366564273834e-02
    z[1,0,4]  R298      -4.3934765458106995e-01
    z[1,0,4]  R299      3.7126722931861877e-01
    z[1,0,4]  R300      5.6894296407699585e-01
    z[1,0,4]  R301      6.3153481483459473e-01
    z[1,0,4]  R302      -1.7366793751716614e-01
    z[1,0,4]  R303      7.6386392116546631e-01
    z[1,0,4]  R304      1.6112732887268066e-01
    z[1,0,4]  R305      -2.0611390471458435e-01
    z[1,0,4]  R306      -0.188913494348526
    z[1,0,4]  R307      1.7132754623889923e-01
    z[1,0,4]  R308      -1.2172131240367889e-01
    z[1,0,4]  R309      3.9444428682327271e-01
    z[1,0,4]  R310      -2.2004060447216034e-01
    z[1,0,4]  R311      -2.3218648135662079e-01
    z[1,0,4]  R312      3.1064242124557495e-01
    z[1,0,4]  R313      -3.3445060253143311e-01
    z[1,0,4]  R314      -1.5926298499107361e-01
    z[1,0,4]  R315      8.7141036987304688e-02
    z[1,0,4]  R316      0.296341210603714
    z[1,0,4]  R317      7.4925500154495239e-01
    z[1,0,4]  R318      1.8090118467807770e-01
    z[1,0,4]  R319      3.0383455753326416e-01
    z[1,0,4]  R320      -0.0531565397977829
    z[1,0,4]  R321      5.7140409946441650e-01
    z[1,0,4]  R322      3.6725696921348572e-01
    z[1,0,4]  R323      3.3065325021743774e-01
    z[1,0,4]  R324      -6.5303169190883636e-02
    z[1,0,4]  R325      -8.1225261092185974e-02
    z[1,0,4]  R326      1.7698067426681519e-01
    z[1,0,4]  R327      -4.6776652336120605e-02
    z[1,0,4]  R328      7.3799538612365723e-01
    z[1,0,4]  R329      3.8734894990921021e-01
    z[1,0,4]  R330      5.4858493804931641e-01
    z[1,0,4]  R331      -8.4407530725002289e-02
    z[1,0,4]  R332      1.1459092050790787e-01
    z[1,0,4]  R333      4.1720294952392578e-01
    z[1,0,4]  R334      -7.5405344367027283e-02
    z[1,0,4]  R335      2.6427078247070312e-01
    z[1,0,4]  R336      0.0963180661201477
    z[1,0,4]  R337      2.5586834549903870e-01
    z[1,0,4]  R338      -4.5942026376724243e-01
    z[1,0,4]  R339      -6.8166360259056091e-02
    z[1,0,4]  R340      4.4260111451148987e-01
    z[1,0,4]  R341      6.5229707956314087e-01
    z[1,0,4]  R342      1.1829110234975815e-01
    z[1,0,4]  R343      3.7259614467620850e-01
    z[1,0,4]  R344      5.0123053789138794e-01
    z[1,0,4]  R345      1.3138134777545929e-01
    z[1,0,4]  R346      8.4607228636741638e-02
    z[1,0,4]  R347      3.5175226628780365e-02
    z[1,0,4]  R348      1.3092462718486786e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R235      -1
    z[1,0,5]  R236      1
    z[1,0,5]  R239      6.3202202320098877e-02
    z[1,0,5]  R240      -6.3467338681221008e-02
    z[1,0,5]  R241      4.1443473100662231e-01
    z[1,0,5]  R242      3.7782818078994751e-01
    z[1,0,5]  R243      0.377505898475647
    z[1,0,5]  R244      -2.6834335923194885e-01
    z[1,0,5]  R245      -1.7452286183834076e-01
    z[1,0,5]  R246      -0.137746199965477
    z[1,0,5]  R247      1.7691782116889954e-01
    z[1,0,5]  R248      1.9589868187904358e-01
    z[1,0,5]  R249      -2.4177654087543488e-01
    z[1,0,5]  R250      -1.7560409009456635e-01
    z[1,0,5]  R251      -3.9284974336624146e-02
    z[1,0,5]  R252      -6.4603704214096069e-01
    z[1,0,5]  R253      1.7294013500213623e-01
    z[1,0,5]  R254      4.0715911984443665e-01
    z[1,0,5]  R255      3.3415222167968750e-01
    z[1,0,5]  R256      5.5208194255828857e-01
    z[1,0,5]  R257      4.7968883067369461e-02
    z[1,0,5]  R258      3.6822766065597534e-01
    z[1,0,5]  R259      -6.7715913057327271e-02
    z[1,0,5]  R260      3.0593699216842651e-01
    z[1,0,5]  R261      3.3995765447616577e-01
    z[1,0,5]  R262      3.4642115235328674e-01
    z[1,0,5]  R263      1.9710119068622589e-01
    z[1,0,5]  R264      5.4594278335571289e-02
    z[1,0,5]  R265      -2.0859143137931824e-01
    z[1,0,5]  R266      -2.2770951036363840e-03
    z[1,0,5]  R267      -1.1156143993139267e-01
    z[1,0,5]  R268      1.8164552748203278e-01
    z[1,0,5]  R269      4.3474078178405762e-01
    z[1,0,5]  R270      -6.3863977789878845e-02
    z[1,0,5]  R271      2.6505815982818604e-01
    z[1,0,5]  R272      -7.5593672692775726e-02
    z[1,0,5]  R273      -1.3024614751338959e-01
    z[1,0,5]  R274      -2.6933519169688225e-02
    z[1,0,5]  R275      -1.9698639214038849e-01
    z[1,0,5]  R276      4.6172770857810974e-01
    z[1,0,5]  R277      2.6775002479553223e-01
    z[1,0,5]  R278      4.6697062253952026e-01
    z[1,0,5]  R279      2.8888288140296936e-01
    z[1,0,5]  R280      2.0357848703861237e-01
    z[1,0,5]  R281      2.0439730584621429e-01
    z[1,0,5]  R282      5.7083507999777794e-03
    z[1,0,5]  R283      -4.3179920315742493e-01
    z[1,0,5]  R284      4.1979452967643738e-01
    z[1,0,5]  R285      1.8119035661220551e-01
    z[1,0,5]  R286      2.1958269178867340e-01
    z[1,0,5]  R287      2.7326586842536926e-01
    z[1,0,5]  R288      2.7693191170692444e-01
    z[1,0,5]  R289      1.9301900267601013e-01
    z[1,0,5]  R290      -2.4098545312881470e-01
    z[1,0,5]  R291      -4.5655433088541031e-02
    z[1,0,5]  R292      1.6269695758819580e-01
    z[1,0,5]  R293      1.8156847357749939e-01
    z[1,0,5]  R294      -1.2440264225006104e-01
    z[1,0,5]  R295      3.8067273795604706e-02
    z[1,0,5]  R296      -1.4498769305646420e-02
    z[1,0,5]  R297      2.9701495170593262e-01
    z[1,0,5]  R298      3.2781437039375305e-01
    z[1,0,5]  R299      -2.1783377975225449e-02
    z[1,0,5]  R300      4.9483588337898254e-01
    z[1,0,5]  R301      -2.7746891975402832e-01
    z[1,0,5]  R302      1.7879074811935425e-01
    z[1,0,5]  R303      -1.7395861446857452e-01
    z[1,0,5]  R304      -2.4008019268512726e-01
    z[1,0,5]  R305      -8.0920957028865814e-02
    z[1,0,5]  R306      1.4321397244930267e-01
    z[1,0,5]  R307      -6.2634360790252686e-01
    z[1,0,5]  R308      -1.2070432305335999e-01
    z[1,0,5]  R309      -3.4617307782173157e-01
    z[1,0,5]  R310      1.6461527347564697e-01
    z[1,0,5]  R311      3.6235302686691284e-01
    z[1,0,5]  R312      -8.5086993873119354e-02
    z[1,0,5]  R313      -1.1541321873664856e-01
    z[1,0,5]  R314      -2.9033929109573364e-02
    z[1,0,5]  R315      -3.2463672757148743e-01
    z[1,0,5]  R316      7.1673125028610229e-02
    z[1,0,5]  R317      2.3574155569076538e-01
    z[1,0,5]  R318      2.5926193594932556e-01
    z[1,0,5]  R319      -5.9350800514221191e-01
    z[1,0,5]  R320      -2.5583109259605408e-01
    z[1,0,5]  R321      4.0099734067916870e-01
    z[1,0,5]  R322      2.0111124217510223e-01
    z[1,0,5]  R323      6.6006970405578613e-01
    z[1,0,5]  R324      -4.5121449232101440e-01
    z[1,0,5]  R325      1.1117789149284363e-01
    z[1,0,5]  R326      8.4612101316452026e-02
    z[1,0,5]  R327      4.2945347726345062e-02
    z[1,0,5]  R328      -1.4339463412761688e-01
    z[1,0,5]  R329      1.0627873986959457e-01
    z[1,0,5]  R330      4.5774596929550171e-01
    z[1,0,5]  R331      -1.2302209436893463e-01
    z[1,0,5]  R332      0.358801931142807
    z[1,0,5]  R333      -1.9983839988708496e-01
    z[1,0,5]  R334      7.5674583204090595e-03
    z[1,0,5]  R335      7.5133427977561951e-02
    z[1,0,5]  R336      -1.2881948053836823e-01
    z[1,0,5]  R337      5.0045740604400635e-01
    z[1,0,5]  R338      -7.1160256862640381e-01
    z[1,0,5]  R339      -1.7666870728135109e-02
    z[1,0,5]  R340      0.540652334690094
    z[1,0,5]  R341      -1.1436444520950317e-01
    z[1,0,5]  R342      -3.8335829973220825e-01
    z[1,0,5]  R343      3.3776876330375671e-01
    z[1,0,5]  R344      2.2240476682782173e-02
    z[1,0,5]  R345      2.3721010982990265e-01
    z[1,0,5]  R346      4.4234889745712280e-01
    z[1,0,5]  R347      -1.3516525924205780e-01
    z[1,0,5]  R348      1.0247895121574402e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R237      -1
    z[1,0,6]  R238      1
    z[1,0,6]  R239      1.3355225324630737e-01
    z[1,0,6]  R240      1.5129385888576508e-01
    z[1,0,6]  R241      3.7660121917724609e-01
    z[1,0,6]  R242      -3.2919198274612427e-01
    z[1,0,6]  R243      -2.8817105293273926e-01
    z[1,0,6]  R244      -1.7816795408725739e-01
    z[1,0,6]  R245      -4.7906059026718140e-01
    z[1,0,6]  R246      -5.4024152457714081e-02
    z[1,0,6]  R247      3.6554688215255737e-01
    z[1,0,6]  R248      2.5745324790477753e-02
    z[1,0,6]  R249      5.6037104129791260e-01
    z[1,0,6]  R250      3.3051070570945740e-01
    z[1,0,6]  R251      -0.515571653842926
    z[1,0,6]  R252      3.0234414339065552e-01
    z[1,0,6]  R253      -0.762999951839447
    z[1,0,6]  R254      -4.1231209039688110e-01
    z[1,0,6]  R255      -2.6262232661247253e-01
    z[1,0,6]  R256      4.4749930500984192e-01
    z[1,0,6]  R257      -1.6747350990772247e-01
    z[1,0,6]  R258      -2.0090888440608978e-01
    z[1,0,6]  R259      -2.9980879276990891e-02
    z[1,0,6]  R260      -3.7872657179832458e-01
    z[1,0,6]  R261      -8.8856205344200134e-02
    z[1,0,6]  R262      -4.2010641098022461e-01
    z[1,0,6]  R263      3.7908756732940674e-01
    z[1,0,6]  R264      2.2304451093077660e-02
    z[1,0,6]  R265      2.2783493995666504e-01
    z[1,0,6]  R266      3.5991007089614868e-01
    z[1,0,6]  R267      -1.1902172863483429e-01
    z[1,0,6]  R268      -2.2993825376033783e-01
    z[1,0,6]  R269      1.2702395021915436e-01
    z[1,0,6]  R270      5.4119038581848145e-01
    z[1,0,6]  R271      2.1290307864546776e-02
    z[1,0,6]  R272      -3.9817806333303452e-02
    z[1,0,6]  R273      -2.4602632224559784e-01
    z[1,0,6]  R274      0.54817795753479
    z[1,0,6]  R275      -2.8034329414367676e-01
    z[1,0,6]  R276      -2.8477391600608826e-01
    z[1,0,6]  R277      -3.1071197986602783e-01
    z[1,0,6]  R278      -7.5204953551292419e-02
    z[1,0,6]  R279      6.1281401664018631e-02
    z[1,0,6]  R280      -3.4957808256149292e-01
    z[1,0,6]  R281      4.6811914443969727e-01
    z[1,0,6]  R282      -1.7486895620822906e-01
    z[1,0,6]  R283      3.3465558290481567e-01
    z[1,0,6]  R284      1.5518032014369965e-01
    z[1,0,6]  R285      7.1556642651557922e-02
    z[1,0,6]  R286      1.0816410183906555e-02
    z[1,0,6]  R287      4.1708725690841675e-01
    z[1,0,6]  R288      2.3318928480148315e-01
    z[1,0,6]  R289      4.7831159085035324e-02
    z[1,0,6]  R290      4.9570590257644653e-02
    z[1,0,6]  R291      -3.5549479722976685e-01
    z[1,0,6]  R292      2.2589640319347382e-01
    z[1,0,6]  R293      1.4294235408306122e-01
    z[1,0,6]  R294      0.416781485080719
    z[1,0,6]  R295      3.1296077370643616e-01
    z[1,0,6]  R296      -9.1624319553375244e-02
    z[1,0,6]  R297      -1.2416333705186844e-01
    z[1,0,6]  R298      1.9051942229270935e-01
    z[1,0,6]  R299      2.0645286142826080e-01
    z[1,0,6]  R300      7.9013511538505554e-02
    z[1,0,6]  R301      -9.2519924044609070e-02
    z[1,0,6]  R302      -9.1535985469818115e-02
    z[1,0,6]  R303      -1.0156561620533466e-02
    z[1,0,6]  R304      1.2745884060859680e-01
    z[1,0,6]  R305      -5.1139497756958008e-01
    z[1,0,6]  R306      4.5891612768173218e-01
    z[1,0,6]  R307      1.4600753784179688e-02
    z[1,0,6]  R308      -0.757362961769104
    z[1,0,6]  R309      4.1133561730384827e-01
    z[1,0,6]  R310      -2.4642260372638702e-01
    z[1,0,6]  R311      7.4573710560798645e-02
    z[1,0,6]  R312      -6.8557456135749817e-02
    z[1,0,6]  R313      -1.3689902424812317e-01
    z[1,0,6]  R314      -6.2951588630676270e-01
    z[1,0,6]  R315      -1.4645232260227203e-01
    z[1,0,6]  R316      -4.0977105498313904e-01
    z[1,0,6]  R317      -1.7787131667137146e-01
    z[1,0,6]  R318      -3.5683155059814453e-01
    z[1,0,6]  R319      -2.8236427903175354e-01
    z[1,0,6]  R320      7.7105000615119934e-02
    z[1,0,6]  R321      1.6026712954044342e-02
    z[1,0,6]  R322      -3.0342203378677368e-01
    z[1,0,6]  R323      1.8504323065280914e-01
    z[1,0,6]  R324      -2.0091125369071960e-01
    z[1,0,6]  R325      -6.1993765830993652e-01
    z[1,0,6]  R326      -4.6524727344512939e-01
    z[1,0,6]  R327      -4.0939357876777649e-01
    z[1,0,6]  R328      -3.6911708116531372e-01
    z[1,0,6]  R329      5.4386872053146362e-01
    z[1,0,6]  R330      2.3745955526828766e-01
    z[1,0,6]  R331      -4.7266405820846558e-01
    z[1,0,6]  R332      -2.6142436265945435e-01
    z[1,0,6]  R333      -7.5015507638454437e-02
    z[1,0,6]  R334      -4.0542531013488770e-01
    z[1,0,6]  R335      4.4498637318611145e-01
    z[1,0,6]  R336      1.8450500071048737e-01
    z[1,0,6]  R337      -4.0413599461317062e-02
    z[1,0,6]  R338      -1.7784436047077179e-01
    z[1,0,6]  R339      -1.7282395064830780e-01
    z[1,0,6]  R340      4.2528787255287170e-01
    z[1,0,6]  R341      -2.7329921722412109e-01
    z[1,0,6]  R342      2.6561632752418518e-01
    z[1,0,6]  R343      3.8113471865653992e-01
    z[1,0,6]  R344      -0.38875612616539
    z[1,0,6]  R345      -2.2092990577220917e-02
    z[1,0,6]  R346      8.9952535927295685e-02
    z[1,0,6]  R347      -3.4177824854850769e-02
    z[1,0,6]  R348      -5.7379838079214096e-02
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R349      -1
    z[0,4,0]  R350      1
    z[0,4,0]  R363      3.1476408243179321e-01
    z[0,4,0]  R364      1.1834477074444294e-02
    z[0,4,0]  R365      1.3257554173469543e-01
    z[0,4,0]  R366      -1.2430892139673233e-01
    z[0,4,0]  R367      1.1401630938053131e-01
    z[0,4,0]  R368      -3.0118885636329651e-01
    z[0,4,0]  R369      1.2912358343601227e-01
    z[0,4,0]  R370      0.0815248116850853
    z[0,4,0]  R371      0.00552970077842474
    z[0,4,0]  R372      -2.7339807152748108e-01
    z[0,4,0]  R373      2.0762410759925842e-01
    z[0,4,0]  R374      4.2255121469497681e-01
    z[0,4,0]  R375      4.4009661674499512e-01
    z[0,4,0]  R376      3.1443512439727783e-01
    z[0,4,0]  R377      2.3042079806327820e-01
    z[0,4,0]  R378      2.1689118444919586e-01
    z[0,4,0]  R379      2.7959862351417542e-01
    z[0,4,0]  R380      1.5870036184787750e-01
    z[0,4,0]  R381      -2.6550387963652611e-02
    z[0,4,0]  R382      2.9034525156021118e-01
    z[0,4,0]  R383      1.8654049932956696e-01
    z[0,4,0]  R384      1.3500507175922394e-01
    z[0,4,0]  R385      3.1808316707611084e-01
    z[0,4,0]  R386      5.0692677497863770e-02
    z[0,4,0]  R387      1.0992458462715149e-01
    z[0,4,0]  R388      2.7017506957054138e-01
    z[0,4,0]  R389      -4.9938973970711231e-03
    z[0,4,0]  R390      4.2471197247505188e-01
    z[0,4,0]  R391      5.2590274810791016e-01
    z[0,4,0]  R392      -5.6573790311813354e-01
    z[0,4,0]  R393      1.9393743574619293e-01
    z[0,4,0]  R394      -2.4671745300292969e-01
    z[0,4,0]  R395      3.4560826420783997e-01
    z[0,4,0]  R396      5.4048734903335571e-01
    z[0,4,0]  R397      2.2684301435947418e-01
    z[0,4,0]  R398      -9.2979431152343750e-02
    z[0,4,0]  R399      2.9443603754043579e-01
    z[0,4,0]  R400      2.5760591030120850e-01
    z[0,4,0]  R401      4.3460544943809509e-01
    z[0,4,0]  R402      4.8872253298759460e-01
    z[0,4,0]  R403      2.8493699431419373e-01
    z[0,4,0]  R404      2.9913905262947083e-01
    z[0,4,0]  R405      9.7009025514125824e-02
    z[0,4,0]  R406      2.1449652314186096e-01
    z[0,4,0]  R407      3.9007715880870819e-02
    z[0,4,0]  R408      1.5334767103195190e-01
    z[0,4,0]  R409      1.1028088629245758e-01
    z[0,4,0]  R410      2.6020860671997070e-01
    z[0,4,0]  R411      3.3218407630920410e-01
    z[0,4,0]  R412      -2.6661536097526550e-01
    z[0,4,0]  R413      2.1714812517166138e-01
    z[0,4,0]  R414      0.345803439617157
    z[0,4,0]  R415      4.3573182821273804e-01
    z[0,4,0]  R416      -1.0542362183332443e-01
    z[0,4,0]  R417      2.4109083414077759e-01
    z[0,4,0]  R418      -6.7017450928688049e-02
    z[0,4,0]  R419      -5.8976024389266968e-01
    z[0,4,0]  R420      -7.3654323816299438e-01
    z[0,4,0]  R421      -0.987890362739563
    z[0,4,0]  R422      -9.8002976179122925e-01
    z[0,4,0]  R423      0.623869776725769
    z[0,4,0]  R424      4.7124966979026794e-01
    z[0,4,0]  R425      4.6075388789176941e-01
    z[0,4,0]  R426      7.0568728446960449e-01
    z[0,4,0]  R427      -2.4869777262210846e-02
    z[0,4,0]  R428      4.6758797764778137e-01
    z[0,4,0]  R429      7.2842091321945190e-01
    z[0,4,0]  R430      2.3502270877361298e-01
    z[0,4,0]  R431      -6.4959675073623657e-01
    z[0,4,0]  R432      -0.434550940990448
    z[0,4,0]  R433      2.4478635191917419e-01
    z[0,4,0]  R434      -8.0743575096130371e-01
    z[0,4,0]  R435      -7.8418093919754028e-01
    z[0,4,0]  R436      -7.4264776706695557e-01
    z[0,4,0]  R437      -8.1033289432525635e-01
    z[0,4,0]  R438      -0.653953492641449
    z[0,4,0]  R439      -7.7817159891128540e-01
    z[0,4,0]  R440      -6.3129687309265137e-01
    z[0,4,0]  R441      -7.2030091285705566e-01
    z[0,4,0]  R442      -0.704049825668335
    z[0,4,0]  R443      3.6099374294281006e-01
    z[0,4,0]  R444      -5.8742411434650421e-02
    z[0,4,0]  R445      -3.2005450129508972e-01
    z[0,4,0]  R446      -1.5671141445636749e-01
    z[0,4,0]  R447      -6.1302137374877930e-01
    z[0,4,0]  R448      -0.726642370223999
    z[0,4,0]  R449      -5.1202350854873657e-01
    z[0,4,0]  R450      -7.6954758167266846e-01
    z[0,4,0]  R451      -4.6727684140205383e-01
    z[0,4,0]  R452      0.0233807023614645
    z[0,4,0]  R453      -3.0041972175240517e-02
    z[0,4,0]  R454      5.7197922468185425e-01
    z[0,4,0]  R455      1.9715158268809319e-02
    z[0,4,0]  R456      2.7033057808876038e-01
    z[0,4,0]  R457      -7.3233973979949951e-01
    z[0,4,0]  R458      -6.9386434555053711e-01
    z[0,4,0]  R459      -2.8363242745399475e-01
    z[0,4,0]  R460      -6.0388818383216858e-02
    z[0,4,0]  R461      -3.2891729474067688e-01
    z[0,4,0]  R462      -1.4320007525384426e-02
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R351      -1
    z[0,4,1]  R352      1
    z[0,4,1]  R363      -4.7224882245063782e-01
    z[0,4,1]  R364      -2.4031297862529755e-01
    z[0,4,1]  R365      -2.0794327557086945e-01
    z[0,4,1]  R366      -3.4598127007484436e-01
    z[0,4,1]  R367      5.5871063470840454e-01
    z[0,4,1]  R368      7.0682919025421143e-01
    z[0,4,1]  R369      6.6753733158111572e-01
    z[0,4,1]  R370      6.7683684825897217e-01
    z[0,4,1]  R371      6.3754743337631226e-01
    z[0,4,1]  R372      6.4540684223175049e-01
    z[0,4,1]  R373      -0.778492271900177
    z[0,4,1]  R374      -3.0248472094535828e-01
    z[0,4,1]  R375      -4.3819853663444519e-01
    z[0,4,1]  R376      -5.4060494899749756e-01
    z[0,4,1]  R377      -3.1929239630699158e-01
    z[0,4,1]  R378      1.3646772503852844e-01
    z[0,4,1]  R379      -6.1155194044113159e-01
    z[0,4,1]  R380      -4.6387916803359985e-01
    z[0,4,1]  R381      1.4054952561855316e-01
    z[0,4,1]  R382      1.6642354428768158e-01
    z[0,4,1]  R383      -6.7393893003463745e-01
    z[0,4,1]  R384      -7.0036292076110840e-01
    z[0,4,1]  R385      1.9068409502506256e-01
    z[0,4,1]  R386      4.6137449145317078e-01
    z[0,4,1]  R387      9.2815555632114410e-02
    z[0,4,1]  R388      3.2422453165054321e-01
    z[0,4,1]  R389      5.9280145168304443e-01
    z[0,4,1]  R390      4.1457760334014893e-01
    z[0,4,1]  R391      2.7077442500740290e-03
    z[0,4,1]  R392      5.5666033178567886e-02
    z[0,4,1]  R393      -6.5842044353485107e-01
    z[0,4,1]  R394      -6.2879538536071777e-01
    z[0,4,1]  R395      -3.1122279167175293e-01
    z[0,4,1]  R396      -6.0055327415466309e-01
    z[0,4,1]  R397      -5.8931209146976471e-02
    z[0,4,1]  R398      4.4835764169692993e-01
    z[0,4,1]  R399      3.6925879120826721e-01
    z[0,4,1]  R400      5.8967101573944092e-01
    z[0,4,1]  R401      -4.6464672684669495e-01
    z[0,4,1]  R402      -6.7998088896274567e-02
    z[0,4,1]  R403      -6.7847508192062378e-01
    z[0,4,1]  R404      -2.8258800506591797e-01
    z[0,4,1]  R405      -6.5462303161621094e-01
    z[0,4,1]  R406      -4.6346828341484070e-01
    z[0,4,1]  R407      6.7375797033309937e-01
    z[0,4,1]  R408      3.4614190459251404e-01
    z[0,4,1]  R409      2.5714039802551270e-01
    z[0,4,1]  R410      1.0153875499963760e-01
    z[0,4,1]  R411      6.2827038764953613e-01
    z[0,4,1]  R412      -2.1211676299571991e-01
    z[0,4,1]  R413      -8.8083219528198242e-01
    z[0,4,1]  R414      -0.313417911529541
    z[0,4,1]  R415      -5.1397383213043213e-01
    z[0,4,1]  R416      2.3133784532546997e-01
    z[0,4,1]  R417      4.7853112220764160e-01
    z[0,4,1]  R418      5.7889532297849655e-02
    z[0,4,1]  R419      -2.1392008662223816e-01
    z[0,4,1]  R420      -1.7244511842727661e-01
    z[0,4,1]  R421      -2.4840043857693672e-02
    z[0,4,1]  R422      -2.9768494889140129e-02
    z[0,4,1]  R423      -5.7879839092493057e-02
    z[0,4,1]  R424      4.7663533687591553e-01
    z[0,4,1]  R425      0.136986643075943
    z[0,4,1]  R426      1.8455080687999725e-02
    z[0,4,1]  R427      -2.4925504624843597e-01
    z[0,4,1]  R428      -0.396010160446167
    z[0,4,1]  R429      -2.4161192774772644e-01
    z[0,4,1]  R430      -5.0455331802368164e-01
    z[0,4,1]  R431      4.0426418185234070e-02
    z[0,4,1]  R432      1.4261446893215179e-02
    z[0,4,1]  R433      5.0589561462402344e-01
    z[0,4,1]  R434      -2.0128647983074188e-01
    z[0,4,1]  R435      2.4805758893489838e-01
    z[0,4,1]  R436      -2.9874911904335022e-01
    z[0,4,1]  R437      -3.4483054280281067e-01
    z[0,4,1]  R438      -0.194259375333786
    z[0,4,1]  R439      4.3170002102851868e-01
    z[0,4,1]  R440      -4.1876286268234253e-01
    z[0,4,1]  R441      2.0251957699656487e-02
    z[0,4,1]  R442      2.1078389883041382e-01
    z[0,4,1]  R443      -7.9293411970138550e-01
    z[0,4,1]  R444      -6.3022160530090332e-01
    z[0,4,1]  R445      2.5774213671684265e-01
    z[0,4,1]  R446      2.0051020383834839e-01
    z[0,4,1]  R447      -1.8618722259998322e-01
    z[0,4,1]  R448      2.9486516118049622e-01
    z[0,4,1]  R449      -1.8806587159633636e-01
    z[0,4,1]  R450      1.0639753937721252e-01
    z[0,4,1]  R451      -1.5282559394836426e-01
    z[0,4,1]  R452      3.2981187105178833e-01
    z[0,4,1]  R453      8.7636457756161690e-03
    z[0,4,1]  R454      -6.4705663919448853e-01
    z[0,4,1]  R455      -5.9205174446105957e-01
    z[0,4,1]  R456      -7.0185905694961548e-01
    z[0,4,1]  R457      1.9007739424705505e-01
    z[0,4,1]  R458      9.9332444369792938e-03
    z[0,4,1]  R459      4.6222010254859924e-01
    z[0,4,1]  R460      4.4346556067466736e-01
    z[0,4,1]  R461      6.3291823863983154e-01
    z[0,4,1]  R462      6.4614170789718628e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R353      -1
    z[0,4,2]  R354      1
    z[0,4,2]  R363      -6.7709732055664062e-01
    z[0,4,2]  R364      -5.5931544303894043e-01
    z[0,4,2]  R365      -4.7623512148857117e-01
    z[0,4,2]  R366      -2.7966102957725525e-01
    z[0,4,2]  R367      3.9050617814064026e-01
    z[0,4,2]  R368      -2.7524825185537338e-02
    z[0,4,2]  R369      -4.5265871286392212e-01
    z[0,4,2]  R370      0.696992039680481
    z[0,4,2]  R371      6.8835991621017456e-01
    z[0,4,2]  R372      1.3943623006343842e-01
    z[0,4,2]  R373      4.0785029530525208e-01
    z[0,4,2]  R374      3.3817109465599060e-01
    z[0,4,2]  R375      -8.9949861168861389e-02
    z[0,4,2]  R376      3.8095393776893616e-01
    z[0,4,2]  R377      -2.3638767004013062e-01
    z[0,4,2]  R378      -5.5201715230941772e-01
    z[0,4,2]  R379      3.5935759544372559e-01
    z[0,4,2]  R380      9.2700138688087463e-02
    z[0,4,2]  R381      -4.1532891988754272e-01
    z[0,4,2]  R382      -8.6719177663326263e-02
    z[0,4,2]  R383      -2.1706743538379669e-01
    z[0,4,2]  R384      5.7647567987442017e-01
    z[0,4,2]  R385      -3.3014762401580811e-01
    z[0,4,2]  R386      2.4113105237483978e-01
    z[0,4,2]  R387      -1.4318852126598358e-01
    z[0,4,2]  R388      -1.9453892111778259e-01
    z[0,4,2]  R389      -5.7668900489807129e-01
    z[0,4,2]  R390      -3.8162443041801453e-01
    z[0,4,2]  R391      -2.1659135818481445e-01
    z[0,4,2]  R392      6.6283047199249268e-01
    z[0,4,2]  R393      -2.3630486801266670e-02
    z[0,4,2]  R394      5.6355726718902588e-01
    z[0,4,2]  R395      3.0008363723754883e-01
    z[0,4,2]  R396      2.7569776773452759e-01
    z[0,4,2]  R397      2.0158074796199799e-01
    z[0,4,2]  R398      -2.8335064649581909e-01
    z[0,4,2]  R399      -5.1285256631672382e-03
    z[0,4,2]  R400      -1.0086107999086380e-01
    z[0,4,2]  R401      2.3099692165851593e-01
    z[0,4,2]  R402      -2.0253235101699829e-01
    z[0,4,2]  R403      -1.6746936365962029e-02
    z[0,4,2]  R404      1.9643746316432953e-01
    z[0,4,2]  R405      4.2900389432907104e-01
    z[0,4,2]  R406      5.2339839935302734e-01
    z[0,4,2]  R407      -0.21449014544487
    z[0,4,2]  R408      1.7569062113761902e-01
    z[0,4,2]  R409      -6.8381972610950470e-02
    z[0,4,2]  R410      -6.5031272172927856e-01
    z[0,4,2]  R411      -3.7023526430130005e-01
    z[0,4,2]  R412      -3.1954258680343628e-01
    z[0,4,2]  R413      2.5137832760810852e-01
    z[0,4,2]  R414      -1.1959065450355411e-03
    z[0,4,2]  R415      1.4534640312194824e-01
    z[0,4,2]  R416      -0.0912170559167862
    z[0,4,2]  R417      -0.371814101934433
    z[0,4,2]  R418      -6.8299013376235962e-01
    z[0,4,2]  R419      5.8048951625823975e-01
    z[0,4,2]  R420      0.465663880109787
    z[0,4,2]  R421      -5.1258202642202377e-02
    z[0,4,2]  R422      -5.8532193303108215e-02
    z[0,4,2]  R423      -0.253171443939209
    z[0,4,2]  R424      -0.256808340549469
    z[0,4,2]  R425      -6.0175049304962158e-01
    z[0,4,2]  R426      -5.7989460229873657e-01
    z[0,4,2]  R427      -5.1363348960876465e-01
    z[0,4,2]  R428      -6.0305446386337280e-01
    z[0,4,2]  R429      2.6512950658798218e-01
    z[0,4,2]  R430      -4.9417650699615479e-01
    z[0,4,2]  R431      5.0010327249765396e-02
    z[0,4,2]  R432      5.4412502050399780e-01
    z[0,4,2]  R433      0.260545551776886
    z[0,4,2]  R434      -3.0604428052902222e-01
    z[0,4,2]  R435      -4.4277977943420410e-01
    z[0,4,2]  R436      1.6066820919513702e-01
    z[0,4,2]  R437      -2.6069043204188347e-02
    z[0,4,2]  R438      4.4048935174942017e-01
    z[0,4,2]  R439      -1.8304710090160370e-01
    z[0,4,2]  R440      0.511961817741394
    z[0,4,2]  R441      -2.6515352725982666e-01
    z[0,4,2]  R442      -3.3389872312545776e-01
    z[0,4,2]  R443      -3.9977619051933289e-01
    z[0,4,2]  R444      -2.2786787152290344e-01
    z[0,4,2]  R445      -2.3326057195663452e-01
    z[0,4,2]  R446      -7.6868957281112671e-01
    z[0,4,2]  R447      3.6510381102561951e-01
    z[0,4,2]  R448      -1.0599025338888168e-01
    z[0,4,2]  R449      -3.5606861114501953e-01
    z[0,4,2]  R450      3.6365887522697449e-01
    z[0,4,2]  R451      -0.0385645292699337
    z[0,4,2]  R452      8.1564372777938843e-01
    z[0,4,2]  R453      -4.6448025107383728e-01
    z[0,4,2]  R454      -3.2947650551795959e-01
    z[0,4,2]  R455      -5.5192488431930542e-01
    z[0,4,2]  R456      8.3687156438827515e-02
    z[0,4,2]  R457      7.0837266743183136e-02
    z[0,4,2]  R458      4.0494126081466675e-01
    z[0,4,2]  R459      7.1850842237472534e-01
    z[0,4,2]  R460      8.5093015432357788e-01
    z[0,4,2]  R461      5.2036416530609131e-01
    z[0,4,2]  R462      6.1346948146820068e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R355      -1
    z[0,4,3]  R356      1
    z[0,4,3]  R363      -3.2873129844665527e-01
    z[0,4,3]  R364      -0.733726978302002
    z[0,4,3]  R365      -7.6104903221130371e-01
    z[0,4,3]  R366      -7.4617242813110352e-01
    z[0,4,3]  R367      0.475638747215271
    z[0,4,3]  R368      4.3652123212814331e-01
    z[0,4,3]  R369      3.4440883994102478e-01
    z[0,4,3]  R370      1.3607767224311829e-01
    z[0,4,3]  R371      1.0278584063053131e-01
    z[0,4,3]  R372      3.9048039913177490e-01
    z[0,4,3]  R373      -5.9694103896617889e-02
    z[0,4,3]  R374      -2.0197047293186188e-01
    z[0,4,3]  R375      3.4902864694595337e-01
    z[0,4,3]  R376      6.2709289789199829e-01
    z[0,4,3]  R377      0.418600857257843
    z[0,4,3]  R378      7.2785001993179321e-01
    z[0,4,3]  R379      3.2883867621421814e-01
    z[0,4,3]  R380      6.9586968421936035e-01
    z[0,4,3]  R381      6.2062078714370728e-01
    z[0,4,3]  R382      5.2678108215332031e-01
    z[0,4,3]  R383      1.3882192969322205e-01
    z[0,4,3]  R384      -1.5066896378993988e-01
    z[0,4,3]  R385      7.5012910366058350e-01
    z[0,4,3]  R386      7.8611761331558228e-01
    z[0,4,3]  R387      9.0270715951919556e-01
    z[0,4,3]  R388      6.0128235816955566e-01
    z[0,4,3]  R389      4.2609906196594238e-01
    z[0,4,3]  R390      4.9116230010986328e-01
    z[0,4,3]  R391      1.6706845164299011e-01
    z[0,4,3]  R392      1.0112817585468292e-01
    z[0,4,3]  R393      6.3369296491146088e-02
    z[0,4,3]  R394      -3.8978171348571777e-01
    z[0,4,3]  R395      -0.453967809677124
    z[0,4,3]  R396      6.1738364398479462e-02
    z[0,4,3]  R397      -0.57023686170578
    z[0,4,3]  R398      6.7957216501235962e-01
    z[0,4,3]  R399      6.1126774549484253e-01
    z[0,4,3]  R400      5.6640797853469849e-01
    z[0,4,3]  R401      0.608462393283844
    z[0,4,3]  R402      1.1857683956623077e-01
    z[0,4,3]  R403      3.2778579741716385e-02
    z[0,4,3]  R404      -4.7456124424934387e-01
    z[0,4,3]  R405      -3.6379012465476990e-01
    z[0,4,3]  R406      -0.5050048828125
    z[0,4,3]  R407      5.2811121940612793e-01
    z[0,4,3]  R408      0.809747040271759
    z[0,4,3]  R409      8.0221188068389893e-01
    z[0,4,3]  R410      6.6269218921661377e-01
    z[0,4,3]  R411      2.0073968172073364e-01
    z[0,4,3]  R412      1.8094581365585327e-01
    z[0,4,3]  R413      -0.281004399061203
    z[0,4,3]  R414      -3.3632898330688477e-01
    z[0,4,3]  R415      -1.0761009156703949e-01
    z[0,4,3]  R416      8.3399015665054321e-01
    z[0,4,3]  R417      4.2006936669349670e-01
    z[0,4,3]  R418      3.5046222805976868e-01
    z[0,4,3]  R419      0.442080557346344
    z[0,4,3]  R420      -1.2345826253294945e-03
    z[0,4,3]  R421      -1.2382607907056808e-02
    z[0,4,3]  R422      6.5527997910976410e-02
    z[0,4,3]  R423      1.2492491304874420e-01
    z[0,4,3]  R424      -2.2062879800796509e-01
    z[0,4,3]  R425      2.6165612041950226e-02
    z[0,4,3]  R426      -3.9458128809928894e-01
    z[0,4,3]  R427      -1.7055764794349670e-02
    z[0,4,3]  R428      -3.6346483230590820e-01
    z[0,4,3]  R429      -5.4058402776718140e-01
    z[0,4,3]  R430      -2.5114113092422485e-01
    z[0,4,3]  R431      -6.9336640834808350e-01
    z[0,4,3]  R432      0.0930207222700119
    z[0,4,3]  R433      7.2303497791290283e-01
    z[0,4,3]  R434      3.0968725681304932e-01
    z[0,4,3]  R435      0.0782003104686737
    z[0,4,3]  R436      4.2925807833671570e-01
    z[0,4,3]  R437      2.4197527766227722e-01
    z[0,4,3]  R438      8.6328610777854919e-02
    z[0,4,3]  R439      1.4247921109199524e-01
    z[0,4,3]  R440      6.5046057105064392e-02
    z[0,4,3]  R441      0.437688410282135
    z[0,4,3]  R442      6.1790838837623596e-02
    z[0,4,3]  R443      1.7396517097949982e-02
    z[0,4,3]  R444      -6.1151021718978882e-01
    z[0,4,3]  R445      7.5240248441696167e-01
    z[0,4,3]  R446      1.4732128381729126e-01
    z[0,4,3]  R447      -3.4460049867630005e-01
    z[0,4,3]  R448      2.1453826129436493e-01
    z[0,4,3]  R449      -6.2274432182312012e-01
    z[0,4,3]  R450      2.8538236021995544e-01
    z[0,4,3]  R451      -6.9842666387557983e-01
    z[0,4,3]  R452      1.2472738325595856e-01
    z[0,4,3]  R453      7.7994906902313232e-01
    z[0,4,3]  R454      -9.5606915652751923e-02
    z[0,4,3]  R455      -2.6460930705070496e-01
    z[0,4,3]  R456      -6.1491703987121582e-01
    z[0,4,3]  R457      -5.0796729326248169e-01
    z[0,4,3]  R458      -5.5004650354385376e-01
    z[0,4,3]  R459      1.3698703050613403e-01
    z[0,4,3]  R460      3.0471283942461014e-02
    z[0,4,3]  R461      7.1395240724086761e-02
    z[0,4,3]  R462      -1.2433141469955444e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R357      -1
    z[0,4,4]  R358      1
    z[0,4,4]  R363      -2.6802113652229309e-01
    z[0,4,4]  R364      1.7432524263858795e-01
    z[0,4,4]  R365      -6.8752519786357880e-02
    z[0,4,4]  R366      -3.9033463597297668e-01
    z[0,4,4]  R367      4.9266198277473450e-01
    z[0,4,4]  R368      -1.7084105312824249e-01
    z[0,4,4]  R369      -3.3883661031723022e-01
    z[0,4,4]  R370      1.4941658079624176e-01
    z[0,4,4]  R371      -7.3917366564273834e-02
    z[0,4,4]  R372      -4.3934765458106995e-01
    z[0,4,4]  R373      3.7126722931861877e-01
    z[0,4,4]  R374      5.6894296407699585e-01
    z[0,4,4]  R375      6.3153481483459473e-01
    z[0,4,4]  R376      -1.7366793751716614e-01
    z[0,4,4]  R377      7.6386392116546631e-01
    z[0,4,4]  R378      1.6112732887268066e-01
    z[0,4,4]  R379      -2.0611390471458435e-01
    z[0,4,4]  R380      -0.188913494348526
    z[0,4,4]  R381      1.7132754623889923e-01
    z[0,4,4]  R382      -1.2172131240367889e-01
    z[0,4,4]  R383      3.9444428682327271e-01
    z[0,4,4]  R384      -2.2004060447216034e-01
    z[0,4,4]  R385      -2.3218648135662079e-01
    z[0,4,4]  R386      3.1064242124557495e-01
    z[0,4,4]  R387      -3.3445060253143311e-01
    z[0,4,4]  R388      -1.5926298499107361e-01
    z[0,4,4]  R389      8.7141036987304688e-02
    z[0,4,4]  R390      0.296341210603714
    z[0,4,4]  R391      7.4925500154495239e-01
    z[0,4,4]  R392      1.8090118467807770e-01
    z[0,4,4]  R393      3.0383455753326416e-01
    z[0,4,4]  R394      -0.0531565397977829
    z[0,4,4]  R395      5.7140409946441650e-01
    z[0,4,4]  R396      3.6725696921348572e-01
    z[0,4,4]  R397      3.3065325021743774e-01
    z[0,4,4]  R398      -6.5303169190883636e-02
    z[0,4,4]  R399      -8.1225261092185974e-02
    z[0,4,4]  R400      1.7698067426681519e-01
    z[0,4,4]  R401      -4.6776652336120605e-02
    z[0,4,4]  R402      7.3799538612365723e-01
    z[0,4,4]  R403      3.8734894990921021e-01
    z[0,4,4]  R404      5.4858493804931641e-01
    z[0,4,4]  R405      -8.4407530725002289e-02
    z[0,4,4]  R406      1.1459092050790787e-01
    z[0,4,4]  R407      4.1720294952392578e-01
    z[0,4,4]  R408      -7.5405344367027283e-02
    z[0,4,4]  R409      2.6427078247070312e-01
    z[0,4,4]  R410      0.0963180661201477
    z[0,4,4]  R411      2.5586834549903870e-01
    z[0,4,4]  R412      -4.5942026376724243e-01
    z[0,4,4]  R413      -6.8166360259056091e-02
    z[0,4,4]  R414      4.4260111451148987e-01
    z[0,4,4]  R415      6.5229707956314087e-01
    z[0,4,4]  R416      1.1829110234975815e-01
    z[0,4,4]  R417      3.7259614467620850e-01
    z[0,4,4]  R418      5.0123053789138794e-01
    z[0,4,4]  R419      1.3138134777545929e-01
    z[0,4,4]  R420      8.4607228636741638e-02
    z[0,4,4]  R421      3.5175226628780365e-02
    z[0,4,4]  R422      1.3092462718486786e-01
    z[0,4,4]  R423      1.3428099453449249e-01
    z[0,4,4]  R424      -5.0115477293729782e-02
    z[0,4,4]  R425      -6.0040223598480225e-01
    z[0,4,4]  R426      2.4425039067864418e-02
    z[0,4,4]  R427      -6.1566889286041260e-01
    z[0,4,4]  R428      -3.2677662372589111e-01
    z[0,4,4]  R429      -8.8102911831811070e-04
    z[0,4,4]  R430      4.9350139498710632e-01
    z[0,4,4]  R431      -1.6764195263385773e-01
    z[0,4,4]  R432      5.2765417844057083e-02
    z[0,4,4]  R433      2.9596433043479919e-01
    z[0,4,4]  R434      1.2117193639278412e-01
    z[0,4,4]  R435      -5.5758882313966751e-02
    z[0,4,4]  R436      0.349113792181015
    z[0,4,4]  R437      -4.4087474234402180e-03
    z[0,4,4]  R438      -3.5065639019012451e-01
    z[0,4,4]  R439      3.4546020627021790e-01
    z[0,4,4]  R440      3.5722330212593079e-02
    z[0,4,4]  R441      4.6186572313308716e-01
    z[0,4,4]  R442      1.2337285280227661e-01
    z[0,4,4]  R443      -6.2775298953056335e-02
    z[0,4,4]  R444      1.9002555310726166e-01
    z[0,4,4]  R445      2.0022791624069214e-01
    z[0,4,4]  R446      3.3235016465187073e-01
    z[0,4,4]  R447      3.2712128758430481e-01
    z[0,4,4]  R448      -1.9327478110790253e-01
    z[0,4,4]  R449      3.2679072022438049e-01
    z[0,4,4]  R450      0.0372639000415802
    z[0,4,4]  R451      1.5612757205963135e-01
    z[0,4,4]  R452      -4.4850343465805054e-01
    z[0,4,4]  R453      1.7781293392181396e-01
    z[0,4,4]  R454      8.8864214718341827e-02
    z[0,4,4]  R455      4.1311812400817871e-01
    z[0,4,4]  R456      6.5062172710895538e-02
    z[0,4,4]  R457      4.6158386394381523e-03
    z[0,4,4]  R458      -1.8049257993698120e-01
    z[0,4,4]  R459      -2.6640057563781738e-01
    z[0,4,4]  R460      -2.5441393256187439e-01
    z[0,4,4]  R461      -1.5200361609458923e-01
    z[0,4,4]  R462      -4.0366733074188232e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R359      -1
    z[0,4,5]  R360      1
    z[0,4,5]  R363      1.9301900267601013e-01
    z[0,4,5]  R364      -2.4098545312881470e-01
    z[0,4,5]  R365      -4.5655433088541031e-02
    z[0,4,5]  R366      1.6269695758819580e-01
    z[0,4,5]  R367      1.8156847357749939e-01
    z[0,4,5]  R368      -1.2440264225006104e-01
    z[0,4,5]  R369      3.8067273795604706e-02
    z[0,4,5]  R370      -1.4498769305646420e-02
    z[0,4,5]  R371      2.9701495170593262e-01
    z[0,4,5]  R372      3.2781437039375305e-01
    z[0,4,5]  R373      -2.1783377975225449e-02
    z[0,4,5]  R374      4.9483588337898254e-01
    z[0,4,5]  R375      -2.7746891975402832e-01
    z[0,4,5]  R376      1.7879074811935425e-01
    z[0,4,5]  R377      -1.7395861446857452e-01
    z[0,4,5]  R378      -2.4008019268512726e-01
    z[0,4,5]  R379      -8.0920957028865814e-02
    z[0,4,5]  R380      1.4321397244930267e-01
    z[0,4,5]  R381      -6.2634360790252686e-01
    z[0,4,5]  R382      -1.2070432305335999e-01
    z[0,4,5]  R383      -3.4617307782173157e-01
    z[0,4,5]  R384      1.6461527347564697e-01
    z[0,4,5]  R385      3.6235302686691284e-01
    z[0,4,5]  R386      -8.5086993873119354e-02
    z[0,4,5]  R387      -1.1541321873664856e-01
    z[0,4,5]  R388      -2.9033929109573364e-02
    z[0,4,5]  R389      -3.2463672757148743e-01
    z[0,4,5]  R390      7.1673125028610229e-02
    z[0,4,5]  R391      2.3574155569076538e-01
    z[0,4,5]  R392      2.5926193594932556e-01
    z[0,4,5]  R393      -5.9350800514221191e-01
    z[0,4,5]  R394      -2.5583109259605408e-01
    z[0,4,5]  R395      4.0099734067916870e-01
    z[0,4,5]  R396      2.0111124217510223e-01
    z[0,4,5]  R397      6.6006970405578613e-01
    z[0,4,5]  R398      -4.5121449232101440e-01
    z[0,4,5]  R399      1.1117789149284363e-01
    z[0,4,5]  R400      8.4612101316452026e-02
    z[0,4,5]  R401      4.2945347726345062e-02
    z[0,4,5]  R402      -1.4339463412761688e-01
    z[0,4,5]  R403      1.0627873986959457e-01
    z[0,4,5]  R404      4.5774596929550171e-01
    z[0,4,5]  R405      -1.2302209436893463e-01
    z[0,4,5]  R406      0.358801931142807
    z[0,4,5]  R407      -1.9983839988708496e-01
    z[0,4,5]  R408      7.5674583204090595e-03
    z[0,4,5]  R409      7.5133427977561951e-02
    z[0,4,5]  R410      -1.2881948053836823e-01
    z[0,4,5]  R411      5.0045740604400635e-01
    z[0,4,5]  R412      -7.1160256862640381e-01
    z[0,4,5]  R413      -1.7666870728135109e-02
    z[0,4,5]  R414      0.540652334690094
    z[0,4,5]  R415      -1.1436444520950317e-01
    z[0,4,5]  R416      -3.8335829973220825e-01
    z[0,4,5]  R417      3.3776876330375671e-01
    z[0,4,5]  R418      2.2240476682782173e-02
    z[0,4,5]  R419      2.3721010982990265e-01
    z[0,4,5]  R420      4.4234889745712280e-01
    z[0,4,5]  R421      -1.3516525924205780e-01
    z[0,4,5]  R422      1.0247895121574402e-01
    z[0,4,5]  R423      -7.1296584606170654e-01
    z[0,4,5]  R424      -6.5558588504791260e-01
    z[0,4,5]  R425      5.1895566284656525e-02
    z[0,4,5]  R426      -0.0933489054441452
    z[0,4,5]  R427      -5.4180312156677246e-01
    z[0,4,5]  R428      0.0987154096364975
    z[0,4,5]  R429      3.5888131707906723e-02
    z[0,4,5]  R430      3.3192914724349976e-01
    z[0,4,5]  R431      -2.4730521440505981e-01
    z[0,4,5]  R432      -7.0260518789291382e-01
    z[0,4,5]  R433      2.0185057073831558e-02
    z[0,4,5]  R434      2.9615047574043274e-01
    z[0,4,5]  R435      4.6754315495491028e-02
    z[0,4,5]  R436      -1.4542146027088165e-01
    z[0,4,5]  R437      3.5263496637344360e-01
    z[0,4,5]  R438      4.4210180640220642e-01
    z[0,4,5]  R439      1.8660034239292145e-01
    z[0,4,5]  R440      3.9712288975715637e-01
    z[0,4,5]  R441      2.1152688190340996e-02
    z[0,4,5]  R442      5.3880882263183594e-01
    z[0,4,5]  R443      2.0857958495616913e-01
    z[0,4,5]  R444      -3.1896722316741943e-01
    z[0,4,5]  R445      -3.0509606003761292e-01
    z[0,4,5]  R446      -1.3022434897720814e-02
    z[0,4,5]  R447      -3.6757189035415649e-01
    z[0,4,5]  R448      -5.2152538299560547e-01
    z[0,4,5]  R449      -0.00387446372769773
    z[0,4,5]  R450      -3.5772538185119629e-01
    z[0,4,5]  R451      4.2368492484092712e-01
    z[0,4,5]  R452      3.1375296413898468e-02
    z[0,4,5]  R453      -3.2512894272804260e-01
    z[0,4,5]  R454      2.9254025220870972e-01
    z[0,4,5]  R455      -1.3117742538452148e-01
    z[0,4,5]  R456      -1.7303550243377686e-01
    z[0,4,5]  R457      3.7424415349960327e-01
    z[0,4,5]  R458      6.4648225903511047e-02
    z[0,4,5]  R459      -1.1710131540894508e-02
    z[0,4,5]  R460      -8.1055760383605957e-02
    z[0,4,5]  R461      3.1751343607902527e-01
    z[0,4,5]  R462      1.3374280929565430e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R361      -1
    z[0,4,6]  R362      1
    z[0,4,6]  R363      4.7831159085035324e-02
    z[0,4,6]  R364      4.9570590257644653e-02
    z[0,4,6]  R365      -3.5549479722976685e-01
    z[0,4,6]  R366      2.2589640319347382e-01
    z[0,4,6]  R367      1.4294235408306122e-01
    z[0,4,6]  R368      0.416781485080719
    z[0,4,6]  R369      3.1296077370643616e-01
    z[0,4,6]  R370      -9.1624319553375244e-02
    z[0,4,6]  R371      -1.2416333705186844e-01
    z[0,4,6]  R372      1.9051942229270935e-01
    z[0,4,6]  R373      2.0645286142826080e-01
    z[0,4,6]  R374      7.9013511538505554e-02
    z[0,4,6]  R375      -9.2519924044609070e-02
    z[0,4,6]  R376      -9.1535985469818115e-02
    z[0,4,6]  R377      -1.0156561620533466e-02
    z[0,4,6]  R378      1.2745884060859680e-01
    z[0,4,6]  R379      -5.1139497756958008e-01
    z[0,4,6]  R380      4.5891612768173218e-01
    z[0,4,6]  R381      1.4600753784179688e-02
    z[0,4,6]  R382      -0.757362961769104
    z[0,4,6]  R383      4.1133561730384827e-01
    z[0,4,6]  R384      -2.4642260372638702e-01
    z[0,4,6]  R385      7.4573710560798645e-02
    z[0,4,6]  R386      -6.8557456135749817e-02
    z[0,4,6]  R387      -1.3689902424812317e-01
    z[0,4,6]  R388      -6.2951588630676270e-01
    z[0,4,6]  R389      -1.4645232260227203e-01
    z[0,4,6]  R390      -4.0977105498313904e-01
    z[0,4,6]  R391      -1.7787131667137146e-01
    z[0,4,6]  R392      -3.5683155059814453e-01
    z[0,4,6]  R393      -2.8236427903175354e-01
    z[0,4,6]  R394      7.7105000615119934e-02
    z[0,4,6]  R395      1.6026712954044342e-02
    z[0,4,6]  R396      -3.0342203378677368e-01
    z[0,4,6]  R397      1.8504323065280914e-01
    z[0,4,6]  R398      -2.0091125369071960e-01
    z[0,4,6]  R399      -6.1993765830993652e-01
    z[0,4,6]  R400      -4.6524727344512939e-01
    z[0,4,6]  R401      -4.0939357876777649e-01
    z[0,4,6]  R402      -3.6911708116531372e-01
    z[0,4,6]  R403      5.4386872053146362e-01
    z[0,4,6]  R404      2.3745955526828766e-01
    z[0,4,6]  R405      -4.7266405820846558e-01
    z[0,4,6]  R406      -2.6142436265945435e-01
    z[0,4,6]  R407      -7.5015507638454437e-02
    z[0,4,6]  R408      -4.0542531013488770e-01
    z[0,4,6]  R409      4.4498637318611145e-01
    z[0,4,6]  R410      1.8450500071048737e-01
    z[0,4,6]  R411      -4.0413599461317062e-02
    z[0,4,6]  R412      -1.7784436047077179e-01
    z[0,4,6]  R413      -1.7282395064830780e-01
    z[0,4,6]  R414      4.2528787255287170e-01
    z[0,4,6]  R415      -2.7329921722412109e-01
    z[0,4,6]  R416      2.6561632752418518e-01
    z[0,4,6]  R417      3.8113471865653992e-01
    z[0,4,6]  R418      -0.38875612616539
    z[0,4,6]  R419      -2.2092990577220917e-02
    z[0,4,6]  R420      8.9952535927295685e-02
    z[0,4,6]  R421      -3.4177824854850769e-02
    z[0,4,6]  R422      -5.7379838079214096e-02
    z[0,4,6]  R423      -3.7183862179517746e-02
    z[0,4,6]  R424      6.1730358749628067e-02
    z[0,4,6]  R425      -2.0730726420879364e-01
    z[0,4,6]  R426      -1.9549399614334106e-02
    z[0,4,6]  R427      -2.3333156481385231e-02
    z[0,4,6]  R428      1.1058200150728226e-01
    z[0,4,6]  R429      2.1728603541851044e-01
    z[0,4,6]  R430      1.7084307968616486e-01
    z[0,4,6]  R431      0.0621943362057209
    z[0,4,6]  R432      9.8989777266979218e-02
    z[0,4,6]  R433      -7.4050143361091614e-02
    z[0,4,6]  R434      1.2479652464389801e-01
    z[0,4,6]  R435      3.4068095684051514e-01
    z[0,4,6]  R436      -7.8221470117568970e-02
    z[0,4,6]  R437      2.0211410522460938e-01
    z[0,4,6]  R438      -1.2128803133964539e-01
    z[0,4,6]  R439      1.0726608335971832e-02
    z[0,4,6]  R440      -2.7989331632852554e-02
    z[0,4,6]  R441      7.1495153009891510e-02
    z[0,4,6]  R442      1.9758987426757812e-01
    z[0,4,6]  R443      -0.182672381401062
    z[0,4,6]  R444      1.8881724774837494e-01
    z[0,4,6]  R445      2.7827912569046021e-01
    z[0,4,6]  R446      4.6046045422554016e-01
    z[0,4,6]  R447      3.0882257223129272e-01
    z[0,4,6]  R448      1.3579729199409485e-01
    z[0,4,6]  R449      -2.8471130132675171e-01
    z[0,4,6]  R450      2.3114760220050812e-01
    z[0,4,6]  R451      2.5519579648971558e-01
    z[0,4,6]  R452      8.7783776223659515e-02
    z[0,4,6]  R453      1.9398948550224304e-01
    z[0,4,6]  R454      -2.0732876658439636e-01
    z[0,4,6]  R455      2.9423266649246216e-01
    z[0,4,6]  R456      -1.2253300100564957e-01
    z[0,4,6]  R457      -1.5627020597457886e-01
    z[0,4,6]  R458      1.2315811216831207e-01
    z[0,4,6]  R459      3.1587821245193481e-01
    z[0,4,6]  R460      -5.8175154030323029e-02
    z[0,4,6]  R461      3.0237710475921631e-01
    z[0,4,6]  R462      9.8276712000370026e-02
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R463      -1
    z[4,0,0]  R464      1
    z[4,0,0]  R477      0.623869776725769
    z[4,0,0]  R478      4.7124966979026794e-01
    z[4,0,0]  R479      4.6075388789176941e-01
    z[4,0,0]  R480      7.0568728446960449e-01
    z[4,0,0]  R481      -2.4869777262210846e-02
    z[4,0,0]  R482      4.6758797764778137e-01
    z[4,0,0]  R483      7.2842091321945190e-01
    z[4,0,0]  R484      2.3502270877361298e-01
    z[4,0,0]  R485      -6.4959675073623657e-01
    z[4,0,0]  R486      -0.434550940990448
    z[4,0,0]  R487      2.4478635191917419e-01
    z[4,0,0]  R488      -8.0743575096130371e-01
    z[4,0,0]  R489      -7.8418093919754028e-01
    z[4,0,0]  R490      -7.4264776706695557e-01
    z[4,0,0]  R491      -8.1033289432525635e-01
    z[4,0,0]  R492      -0.653953492641449
    z[4,0,0]  R493      -7.7817159891128540e-01
    z[4,0,0]  R494      -6.3129687309265137e-01
    z[4,0,0]  R495      -7.2030091285705566e-01
    z[4,0,0]  R496      -0.704049825668335
    z[4,0,0]  R497      3.6099374294281006e-01
    z[4,0,0]  R498      -5.8742411434650421e-02
    z[4,0,0]  R499      -3.2005450129508972e-01
    z[4,0,0]  R500      -1.5671141445636749e-01
    z[4,0,0]  R501      -6.1302137374877930e-01
    z[4,0,0]  R502      -0.726642370223999
    z[4,0,0]  R503      -5.1202350854873657e-01
    z[4,0,0]  R504      -7.6954758167266846e-01
    z[4,0,0]  R505      -4.6727684140205383e-01
    z[4,0,0]  R506      0.0233807023614645
    z[4,0,0]  R507      -3.0041972175240517e-02
    z[4,0,0]  R508      5.7197922468185425e-01
    z[4,0,0]  R509      1.9715158268809319e-02
    z[4,0,0]  R510      2.7033057808876038e-01
    z[4,0,0]  R511      -7.3233973979949951e-01
    z[4,0,0]  R512      -6.9386434555053711e-01
    z[4,0,0]  R513      -2.8363242745399475e-01
    z[4,0,0]  R514      -6.0388818383216858e-02
    z[4,0,0]  R515      -3.2891729474067688e-01
    z[4,0,0]  R516      -1.4320007525384426e-02
    z[4,0,0]  R517      3.1476408243179321e-01
    z[4,0,0]  R518      1.1834477074444294e-02
    z[4,0,0]  R519      1.3257554173469543e-01
    z[4,0,0]  R520      -1.2430892139673233e-01
    z[4,0,0]  R521      1.1401630938053131e-01
    z[4,0,0]  R522      -3.0118885636329651e-01
    z[4,0,0]  R523      1.2912358343601227e-01
    z[4,0,0]  R524      0.0815248116850853
    z[4,0,0]  R525      0.00552970077842474
    z[4,0,0]  R526      -2.7339807152748108e-01
    z[4,0,0]  R527      2.0762410759925842e-01
    z[4,0,0]  R528      4.2255121469497681e-01
    z[4,0,0]  R529      4.4009661674499512e-01
    z[4,0,0]  R530      3.1443512439727783e-01
    z[4,0,0]  R531      2.3042079806327820e-01
    z[4,0,0]  R532      2.1689118444919586e-01
    z[4,0,0]  R533      2.7959862351417542e-01
    z[4,0,0]  R534      1.5870036184787750e-01
    z[4,0,0]  R535      -2.6550387963652611e-02
    z[4,0,0]  R536      2.9034525156021118e-01
    z[4,0,0]  R537      1.8654049932956696e-01
    z[4,0,0]  R538      1.3500507175922394e-01
    z[4,0,0]  R539      3.1808316707611084e-01
    z[4,0,0]  R540      5.0692677497863770e-02
    z[4,0,0]  R541      1.0992458462715149e-01
    z[4,0,0]  R542      2.7017506957054138e-01
    z[4,0,0]  R543      -4.9938973970711231e-03
    z[4,0,0]  R544      4.2471197247505188e-01
    z[4,0,0]  R545      5.2590274810791016e-01
    z[4,0,0]  R546      -5.6573790311813354e-01
    z[4,0,0]  R547      1.9393743574619293e-01
    z[4,0,0]  R548      -2.4671745300292969e-01
    z[4,0,0]  R549      3.4560826420783997e-01
    z[4,0,0]  R550      5.4048734903335571e-01
    z[4,0,0]  R551      2.2684301435947418e-01
    z[4,0,0]  R552      -9.2979431152343750e-02
    z[4,0,0]  R553      2.9443603754043579e-01
    z[4,0,0]  R554      2.5760591030120850e-01
    z[4,0,0]  R555      4.3460544943809509e-01
    z[4,0,0]  R556      4.8872253298759460e-01
    z[4,0,0]  R557      2.8493699431419373e-01
    z[4,0,0]  R558      2.9913905262947083e-01
    z[4,0,0]  R559      9.7009025514125824e-02
    z[4,0,0]  R560      2.1449652314186096e-01
    z[4,0,0]  R561      3.9007715880870819e-02
    z[4,0,0]  R562      1.5334767103195190e-01
    z[4,0,0]  R563      1.1028088629245758e-01
    z[4,0,0]  R564      2.6020860671997070e-01
    z[4,0,0]  R565      3.3218407630920410e-01
    z[4,0,0]  R566      -2.6661536097526550e-01
    z[4,0,0]  R567      2.1714812517166138e-01
    z[4,0,0]  R568      0.345803439617157
    z[4,0,0]  R569      4.3573182821273804e-01
    z[4,0,0]  R570      -1.0542362183332443e-01
    z[4,0,0]  R571      2.4109083414077759e-01
    z[4,0,0]  R572      -6.7017450928688049e-02
    z[4,0,0]  R573      -5.8976024389266968e-01
    z[4,0,0]  R574      -7.3654323816299438e-01
    z[4,0,0]  R575      -0.987890362739563
    z[4,0,0]  R576      -9.8002976179122925e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R465      -1
    z[4,0,1]  R466      1
    z[4,0,1]  R477      -5.7879839092493057e-02
    z[4,0,1]  R478      4.7663533687591553e-01
    z[4,0,1]  R479      0.136986643075943
    z[4,0,1]  R480      1.8455080687999725e-02
    z[4,0,1]  R481      -2.4925504624843597e-01
    z[4,0,1]  R482      -0.396010160446167
    z[4,0,1]  R483      -2.4161192774772644e-01
    z[4,0,1]  R484      -5.0455331802368164e-01
    z[4,0,1]  R485      4.0426418185234070e-02
    z[4,0,1]  R486      1.4261446893215179e-02
    z[4,0,1]  R487      5.0589561462402344e-01
    z[4,0,1]  R488      -2.0128647983074188e-01
    z[4,0,1]  R489      2.4805758893489838e-01
    z[4,0,1]  R490      -2.9874911904335022e-01
    z[4,0,1]  R491      -3.4483054280281067e-01
    z[4,0,1]  R492      -0.194259375333786
    z[4,0,1]  R493      4.3170002102851868e-01
    z[4,0,1]  R494      -4.1876286268234253e-01
    z[4,0,1]  R495      2.0251957699656487e-02
    z[4,0,1]  R496      2.1078389883041382e-01
    z[4,0,1]  R497      -7.9293411970138550e-01
    z[4,0,1]  R498      -6.3022160530090332e-01
    z[4,0,1]  R499      2.5774213671684265e-01
    z[4,0,1]  R500      2.0051020383834839e-01
    z[4,0,1]  R501      -1.8618722259998322e-01
    z[4,0,1]  R502      2.9486516118049622e-01
    z[4,0,1]  R503      -1.8806587159633636e-01
    z[4,0,1]  R504      1.0639753937721252e-01
    z[4,0,1]  R505      -1.5282559394836426e-01
    z[4,0,1]  R506      3.2981187105178833e-01
    z[4,0,1]  R507      8.7636457756161690e-03
    z[4,0,1]  R508      -6.4705663919448853e-01
    z[4,0,1]  R509      -5.9205174446105957e-01
    z[4,0,1]  R510      -7.0185905694961548e-01
    z[4,0,1]  R511      1.9007739424705505e-01
    z[4,0,1]  R512      9.9332444369792938e-03
    z[4,0,1]  R513      4.6222010254859924e-01
    z[4,0,1]  R514      4.4346556067466736e-01
    z[4,0,1]  R515      6.3291823863983154e-01
    z[4,0,1]  R516      6.4614170789718628e-01
    z[4,0,1]  R517      -4.7224882245063782e-01
    z[4,0,1]  R518      -2.4031297862529755e-01
    z[4,0,1]  R519      -2.0794327557086945e-01
    z[4,0,1]  R520      -3.4598127007484436e-01
    z[4,0,1]  R521      5.5871063470840454e-01
    z[4,0,1]  R522      7.0682919025421143e-01
    z[4,0,1]  R523      6.6753733158111572e-01
    z[4,0,1]  R524      6.7683684825897217e-01
    z[4,0,1]  R525      6.3754743337631226e-01
    z[4,0,1]  R526      6.4540684223175049e-01
    z[4,0,1]  R527      -0.778492271900177
    z[4,0,1]  R528      -3.0248472094535828e-01
    z[4,0,1]  R529      -4.3819853663444519e-01
    z[4,0,1]  R530      -5.4060494899749756e-01
    z[4,0,1]  R531      -3.1929239630699158e-01
    z[4,0,1]  R532      1.3646772503852844e-01
    z[4,0,1]  R533      -6.1155194044113159e-01
    z[4,0,1]  R534      -4.6387916803359985e-01
    z[4,0,1]  R535      1.4054952561855316e-01
    z[4,0,1]  R536      1.6642354428768158e-01
    z[4,0,1]  R537      -6.7393893003463745e-01
    z[4,0,1]  R538      -7.0036292076110840e-01
    z[4,0,1]  R539      1.9068409502506256e-01
    z[4,0,1]  R540      4.6137449145317078e-01
    z[4,0,1]  R541      9.2815555632114410e-02
    z[4,0,1]  R542      3.2422453165054321e-01
    z[4,0,1]  R543      5.9280145168304443e-01
    z[4,0,1]  R544      4.1457760334014893e-01
    z[4,0,1]  R545      2.7077442500740290e-03
    z[4,0,1]  R546      5.5666033178567886e-02
    z[4,0,1]  R547      -6.5842044353485107e-01
    z[4,0,1]  R548      -6.2879538536071777e-01
    z[4,0,1]  R549      -3.1122279167175293e-01
    z[4,0,1]  R550      -6.0055327415466309e-01
    z[4,0,1]  R551      -5.8931209146976471e-02
    z[4,0,1]  R552      4.4835764169692993e-01
    z[4,0,1]  R553      3.6925879120826721e-01
    z[4,0,1]  R554      5.8967101573944092e-01
    z[4,0,1]  R555      -4.6464672684669495e-01
    z[4,0,1]  R556      -6.7998088896274567e-02
    z[4,0,1]  R557      -6.7847508192062378e-01
    z[4,0,1]  R558      -2.8258800506591797e-01
    z[4,0,1]  R559      -6.5462303161621094e-01
    z[4,0,1]  R560      -4.6346828341484070e-01
    z[4,0,1]  R561      6.7375797033309937e-01
    z[4,0,1]  R562      3.4614190459251404e-01
    z[4,0,1]  R563      2.5714039802551270e-01
    z[4,0,1]  R564      1.0153875499963760e-01
    z[4,0,1]  R565      6.2827038764953613e-01
    z[4,0,1]  R566      -2.1211676299571991e-01
    z[4,0,1]  R567      -8.8083219528198242e-01
    z[4,0,1]  R568      -0.313417911529541
    z[4,0,1]  R569      -5.1397383213043213e-01
    z[4,0,1]  R570      2.3133784532546997e-01
    z[4,0,1]  R571      4.7853112220764160e-01
    z[4,0,1]  R572      5.7889532297849655e-02
    z[4,0,1]  R573      -2.1392008662223816e-01
    z[4,0,1]  R574      -1.7244511842727661e-01
    z[4,0,1]  R575      -2.4840043857693672e-02
    z[4,0,1]  R576      -2.9768494889140129e-02
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R467      -1
    z[4,0,2]  R468      1
    z[4,0,2]  R477      -0.253171443939209
    z[4,0,2]  R478      -0.256808340549469
    z[4,0,2]  R479      -6.0175049304962158e-01
    z[4,0,2]  R480      -5.7989460229873657e-01
    z[4,0,2]  R481      -5.1363348960876465e-01
    z[4,0,2]  R482      -6.0305446386337280e-01
    z[4,0,2]  R483      2.6512950658798218e-01
    z[4,0,2]  R484      -4.9417650699615479e-01
    z[4,0,2]  R485      5.0010327249765396e-02
    z[4,0,2]  R486      5.4412502050399780e-01
    z[4,0,2]  R487      0.260545551776886
    z[4,0,2]  R488      -3.0604428052902222e-01
    z[4,0,2]  R489      -4.4277977943420410e-01
    z[4,0,2]  R490      1.6066820919513702e-01
    z[4,0,2]  R491      -2.6069043204188347e-02
    z[4,0,2]  R492      4.4048935174942017e-01
    z[4,0,2]  R493      -1.8304710090160370e-01
    z[4,0,2]  R494      0.511961817741394
    z[4,0,2]  R495      -2.6515352725982666e-01
    z[4,0,2]  R496      -3.3389872312545776e-01
    z[4,0,2]  R497      -3.9977619051933289e-01
    z[4,0,2]  R498      -2.2786787152290344e-01
    z[4,0,2]  R499      -2.3326057195663452e-01
    z[4,0,2]  R500      -7.6868957281112671e-01
    z[4,0,2]  R501      3.6510381102561951e-01
    z[4,0,2]  R502      -1.0599025338888168e-01
    z[4,0,2]  R503      -3.5606861114501953e-01
    z[4,0,2]  R504      3.6365887522697449e-01
    z[4,0,2]  R505      -0.0385645292699337
    z[4,0,2]  R506      8.1564372777938843e-01
    z[4,0,2]  R507      -4.6448025107383728e-01
    z[4,0,2]  R508      -3.2947650551795959e-01
    z[4,0,2]  R509      -5.5192488431930542e-01
    z[4,0,2]  R510      8.3687156438827515e-02
    z[4,0,2]  R511      7.0837266743183136e-02
    z[4,0,2]  R512      4.0494126081466675e-01
    z[4,0,2]  R513      7.1850842237472534e-01
    z[4,0,2]  R514      8.5093015432357788e-01
    z[4,0,2]  R515      5.2036416530609131e-01
    z[4,0,2]  R516      6.1346948146820068e-01
    z[4,0,2]  R517      -6.7709732055664062e-01
    z[4,0,2]  R518      -5.5931544303894043e-01
    z[4,0,2]  R519      -4.7623512148857117e-01
    z[4,0,2]  R520      -2.7966102957725525e-01
    z[4,0,2]  R521      3.9050617814064026e-01
    z[4,0,2]  R522      -2.7524825185537338e-02
    z[4,0,2]  R523      -4.5265871286392212e-01
    z[4,0,2]  R524      0.696992039680481
    z[4,0,2]  R525      6.8835991621017456e-01
    z[4,0,2]  R526      1.3943623006343842e-01
    z[4,0,2]  R527      4.0785029530525208e-01
    z[4,0,2]  R528      3.3817109465599060e-01
    z[4,0,2]  R529      -8.9949861168861389e-02
    z[4,0,2]  R530      3.8095393776893616e-01
    z[4,0,2]  R531      -2.3638767004013062e-01
    z[4,0,2]  R532      -5.5201715230941772e-01
    z[4,0,2]  R533      3.5935759544372559e-01
    z[4,0,2]  R534      9.2700138688087463e-02
    z[4,0,2]  R535      -4.1532891988754272e-01
    z[4,0,2]  R536      -8.6719177663326263e-02
    z[4,0,2]  R537      -2.1706743538379669e-01
    z[4,0,2]  R538      5.7647567987442017e-01
    z[4,0,2]  R539      -3.3014762401580811e-01
    z[4,0,2]  R540      2.4113105237483978e-01
    z[4,0,2]  R541      -1.4318852126598358e-01
    z[4,0,2]  R542      -1.9453892111778259e-01
    z[4,0,2]  R543      -5.7668900489807129e-01
    z[4,0,2]  R544      -3.8162443041801453e-01
    z[4,0,2]  R545      -2.1659135818481445e-01
    z[4,0,2]  R546      6.6283047199249268e-01
    z[4,0,2]  R547      -2.3630486801266670e-02
    z[4,0,2]  R548      5.6355726718902588e-01
    z[4,0,2]  R549      3.0008363723754883e-01
    z[4,0,2]  R550      2.7569776773452759e-01
    z[4,0,2]  R551      2.0158074796199799e-01
    z[4,0,2]  R552      -2.8335064649581909e-01
    z[4,0,2]  R553      -5.1285256631672382e-03
    z[4,0,2]  R554      -1.0086107999086380e-01
    z[4,0,2]  R555      2.3099692165851593e-01
    z[4,0,2]  R556      -2.0253235101699829e-01
    z[4,0,2]  R557      -1.6746936365962029e-02
    z[4,0,2]  R558      1.9643746316432953e-01
    z[4,0,2]  R559      4.2900389432907104e-01
    z[4,0,2]  R560      5.2339839935302734e-01
    z[4,0,2]  R561      -0.21449014544487
    z[4,0,2]  R562      1.7569062113761902e-01
    z[4,0,2]  R563      -6.8381972610950470e-02
    z[4,0,2]  R564      -6.5031272172927856e-01
    z[4,0,2]  R565      -3.7023526430130005e-01
    z[4,0,2]  R566      -3.1954258680343628e-01
    z[4,0,2]  R567      2.5137832760810852e-01
    z[4,0,2]  R568      -1.1959065450355411e-03
    z[4,0,2]  R569      1.4534640312194824e-01
    z[4,0,2]  R570      -0.0912170559167862
    z[4,0,2]  R571      -0.371814101934433
    z[4,0,2]  R572      -6.8299013376235962e-01
    z[4,0,2]  R573      5.8048951625823975e-01
    z[4,0,2]  R574      0.465663880109787
    z[4,0,2]  R575      -5.1258202642202377e-02
    z[4,0,2]  R576      -5.8532193303108215e-02
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R469      -1
    z[4,0,3]  R470      1
    z[4,0,3]  R477      1.2492491304874420e-01
    z[4,0,3]  R478      -2.2062879800796509e-01
    z[4,0,3]  R479      2.6165612041950226e-02
    z[4,0,3]  R480      -3.9458128809928894e-01
    z[4,0,3]  R481      -1.7055764794349670e-02
    z[4,0,3]  R482      -3.6346483230590820e-01
    z[4,0,3]  R483      -5.4058402776718140e-01
    z[4,0,3]  R484      -2.5114113092422485e-01
    z[4,0,3]  R485      -6.9336640834808350e-01
    z[4,0,3]  R486      0.0930207222700119
    z[4,0,3]  R487      7.2303497791290283e-01
    z[4,0,3]  R488      3.0968725681304932e-01
    z[4,0,3]  R489      0.0782003104686737
    z[4,0,3]  R490      4.2925807833671570e-01
    z[4,0,3]  R491      2.4197527766227722e-01
    z[4,0,3]  R492      8.6328610777854919e-02
    z[4,0,3]  R493      1.4247921109199524e-01
    z[4,0,3]  R494      6.5046057105064392e-02
    z[4,0,3]  R495      0.437688410282135
    z[4,0,3]  R496      6.1790838837623596e-02
    z[4,0,3]  R497      1.7396517097949982e-02
    z[4,0,3]  R498      -6.1151021718978882e-01
    z[4,0,3]  R499      7.5240248441696167e-01
    z[4,0,3]  R500      1.4732128381729126e-01
    z[4,0,3]  R501      -3.4460049867630005e-01
    z[4,0,3]  R502      2.1453826129436493e-01
    z[4,0,3]  R503      -6.2274432182312012e-01
    z[4,0,3]  R504      2.8538236021995544e-01
    z[4,0,3]  R505      -6.9842666387557983e-01
    z[4,0,3]  R506      1.2472738325595856e-01
    z[4,0,3]  R507      7.7994906902313232e-01
    z[4,0,3]  R508      -9.5606915652751923e-02
    z[4,0,3]  R509      -2.6460930705070496e-01
    z[4,0,3]  R510      -6.1491703987121582e-01
    z[4,0,3]  R511      -5.0796729326248169e-01
    z[4,0,3]  R512      -5.5004650354385376e-01
    z[4,0,3]  R513      1.3698703050613403e-01
    z[4,0,3]  R514      3.0471283942461014e-02
    z[4,0,3]  R515      7.1395240724086761e-02
    z[4,0,3]  R516      -1.2433141469955444e-01
    z[4,0,3]  R517      -3.2873129844665527e-01
    z[4,0,3]  R518      -0.733726978302002
    z[4,0,3]  R519      -7.6104903221130371e-01
    z[4,0,3]  R520      -7.4617242813110352e-01
    z[4,0,3]  R521      0.475638747215271
    z[4,0,3]  R522      4.3652123212814331e-01
    z[4,0,3]  R523      3.4440883994102478e-01
    z[4,0,3]  R524      1.3607767224311829e-01
    z[4,0,3]  R525      1.0278584063053131e-01
    z[4,0,3]  R526      3.9048039913177490e-01
    z[4,0,3]  R527      -5.9694103896617889e-02
    z[4,0,3]  R528      -2.0197047293186188e-01
    z[4,0,3]  R529      3.4902864694595337e-01
    z[4,0,3]  R530      6.2709289789199829e-01
    z[4,0,3]  R531      0.418600857257843
    z[4,0,3]  R532      7.2785001993179321e-01
    z[4,0,3]  R533      3.2883867621421814e-01
    z[4,0,3]  R534      6.9586968421936035e-01
    z[4,0,3]  R535      6.2062078714370728e-01
    z[4,0,3]  R536      5.2678108215332031e-01
    z[4,0,3]  R537      1.3882192969322205e-01
    z[4,0,3]  R538      -1.5066896378993988e-01
    z[4,0,3]  R539      7.5012910366058350e-01
    z[4,0,3]  R540      7.8611761331558228e-01
    z[4,0,3]  R541      9.0270715951919556e-01
    z[4,0,3]  R542      6.0128235816955566e-01
    z[4,0,3]  R543      4.2609906196594238e-01
    z[4,0,3]  R544      4.9116230010986328e-01
    z[4,0,3]  R545      1.6706845164299011e-01
    z[4,0,3]  R546      1.0112817585468292e-01
    z[4,0,3]  R547      6.3369296491146088e-02
    z[4,0,3]  R548      -3.8978171348571777e-01
    z[4,0,3]  R549      -0.453967809677124
    z[4,0,3]  R550      6.1738364398479462e-02
    z[4,0,3]  R551      -0.57023686170578
    z[4,0,3]  R552      6.7957216501235962e-01
    z[4,0,3]  R553      6.1126774549484253e-01
    z[4,0,3]  R554      5.6640797853469849e-01
    z[4,0,3]  R555      0.608462393283844
    z[4,0,3]  R556      1.1857683956623077e-01
    z[4,0,3]  R557      3.2778579741716385e-02
    z[4,0,3]  R558      -4.7456124424934387e-01
    z[4,0,3]  R559      -3.6379012465476990e-01
    z[4,0,3]  R560      -0.5050048828125
    z[4,0,3]  R561      5.2811121940612793e-01
    z[4,0,3]  R562      0.809747040271759
    z[4,0,3]  R563      8.0221188068389893e-01
    z[4,0,3]  R564      6.6269218921661377e-01
    z[4,0,3]  R565      2.0073968172073364e-01
    z[4,0,3]  R566      1.8094581365585327e-01
    z[4,0,3]  R567      -0.281004399061203
    z[4,0,3]  R568      -3.3632898330688477e-01
    z[4,0,3]  R569      -1.0761009156703949e-01
    z[4,0,3]  R570      8.3399015665054321e-01
    z[4,0,3]  R571      4.2006936669349670e-01
    z[4,0,3]  R572      3.5046222805976868e-01
    z[4,0,3]  R573      0.442080557346344
    z[4,0,3]  R574      -1.2345826253294945e-03
    z[4,0,3]  R575      -1.2382607907056808e-02
    z[4,0,3]  R576      6.5527997910976410e-02
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R471      -1
    z[4,0,4]  R472      1
    z[4,0,4]  R477      1.3428099453449249e-01
    z[4,0,4]  R478      -5.0115477293729782e-02
    z[4,0,4]  R479      -6.0040223598480225e-01
    z[4,0,4]  R480      2.4425039067864418e-02
    z[4,0,4]  R481      -6.1566889286041260e-01
    z[4,0,4]  R482      -3.2677662372589111e-01
    z[4,0,4]  R483      -8.8102911831811070e-04
    z[4,0,4]  R484      4.9350139498710632e-01
    z[4,0,4]  R485      -1.6764195263385773e-01
    z[4,0,4]  R486      5.2765417844057083e-02
    z[4,0,4]  R487      2.9596433043479919e-01
    z[4,0,4]  R488      1.2117193639278412e-01
    z[4,0,4]  R489      -5.5758882313966751e-02
    z[4,0,4]  R490      0.349113792181015
    z[4,0,4]  R491      -4.4087474234402180e-03
    z[4,0,4]  R492      -3.5065639019012451e-01
    z[4,0,4]  R493      3.4546020627021790e-01
    z[4,0,4]  R494      3.5722330212593079e-02
    z[4,0,4]  R495      4.6186572313308716e-01
    z[4,0,4]  R496      1.2337285280227661e-01
    z[4,0,4]  R497      -6.2775298953056335e-02
    z[4,0,4]  R498      1.9002555310726166e-01
    z[4,0,4]  R499      2.0022791624069214e-01
    z[4,0,4]  R500      3.3235016465187073e-01
    z[4,0,4]  R501      3.2712128758430481e-01
    z[4,0,4]  R502      -1.9327478110790253e-01
    z[4,0,4]  R503      3.2679072022438049e-01
    z[4,0,4]  R504      0.0372639000415802
    z[4,0,4]  R505      1.5612757205963135e-01
    z[4,0,4]  R506      -4.4850343465805054e-01
    z[4,0,4]  R507      1.7781293392181396e-01
    z[4,0,4]  R508      8.8864214718341827e-02
    z[4,0,4]  R509      4.1311812400817871e-01
    z[4,0,4]  R510      6.5062172710895538e-02
    z[4,0,4]  R511      4.6158386394381523e-03
    z[4,0,4]  R512      -1.8049257993698120e-01
    z[4,0,4]  R513      -2.6640057563781738e-01
    z[4,0,4]  R514      -2.5441393256187439e-01
    z[4,0,4]  R515      -1.5200361609458923e-01
    z[4,0,4]  R516      -4.0366733074188232e-01
    z[4,0,4]  R517      -2.6802113652229309e-01
    z[4,0,4]  R518      1.7432524263858795e-01
    z[4,0,4]  R519      -6.8752519786357880e-02
    z[4,0,4]  R520      -3.9033463597297668e-01
    z[4,0,4]  R521      4.9266198277473450e-01
    z[4,0,4]  R522      -1.7084105312824249e-01
    z[4,0,4]  R523      -3.3883661031723022e-01
    z[4,0,4]  R524      1.4941658079624176e-01
    z[4,0,4]  R525      -7.3917366564273834e-02
    z[4,0,4]  R526      -4.3934765458106995e-01
    z[4,0,4]  R527      3.7126722931861877e-01
    z[4,0,4]  R528      5.6894296407699585e-01
    z[4,0,4]  R529      6.3153481483459473e-01
    z[4,0,4]  R530      -1.7366793751716614e-01
    z[4,0,4]  R531      7.6386392116546631e-01
    z[4,0,4]  R532      1.6112732887268066e-01
    z[4,0,4]  R533      -2.0611390471458435e-01
    z[4,0,4]  R534      -0.188913494348526
    z[4,0,4]  R535      1.7132754623889923e-01
    z[4,0,4]  R536      -1.2172131240367889e-01
    z[4,0,4]  R537      3.9444428682327271e-01
    z[4,0,4]  R538      -2.2004060447216034e-01
    z[4,0,4]  R539      -2.3218648135662079e-01
    z[4,0,4]  R540      3.1064242124557495e-01
    z[4,0,4]  R541      -3.3445060253143311e-01
    z[4,0,4]  R542      -1.5926298499107361e-01
    z[4,0,4]  R543      8.7141036987304688e-02
    z[4,0,4]  R544      0.296341210603714
    z[4,0,4]  R545      7.4925500154495239e-01
    z[4,0,4]  R546      1.8090118467807770e-01
    z[4,0,4]  R547      3.0383455753326416e-01
    z[4,0,4]  R548      -0.0531565397977829
    z[4,0,4]  R549      5.7140409946441650e-01
    z[4,0,4]  R550      3.6725696921348572e-01
    z[4,0,4]  R551      3.3065325021743774e-01
    z[4,0,4]  R552      -6.5303169190883636e-02
    z[4,0,4]  R553      -8.1225261092185974e-02
    z[4,0,4]  R554      1.7698067426681519e-01
    z[4,0,4]  R555      -4.6776652336120605e-02
    z[4,0,4]  R556      7.3799538612365723e-01
    z[4,0,4]  R557      3.8734894990921021e-01
    z[4,0,4]  R558      5.4858493804931641e-01
    z[4,0,4]  R559      -8.4407530725002289e-02
    z[4,0,4]  R560      1.1459092050790787e-01
    z[4,0,4]  R561      4.1720294952392578e-01
    z[4,0,4]  R562      -7.5405344367027283e-02
    z[4,0,4]  R563      2.6427078247070312e-01
    z[4,0,4]  R564      0.0963180661201477
    z[4,0,4]  R565      2.5586834549903870e-01
    z[4,0,4]  R566      -4.5942026376724243e-01
    z[4,0,4]  R567      -6.8166360259056091e-02
    z[4,0,4]  R568      4.4260111451148987e-01
    z[4,0,4]  R569      6.5229707956314087e-01
    z[4,0,4]  R570      1.1829110234975815e-01
    z[4,0,4]  R571      3.7259614467620850e-01
    z[4,0,4]  R572      5.0123053789138794e-01
    z[4,0,4]  R573      1.3138134777545929e-01
    z[4,0,4]  R574      8.4607228636741638e-02
    z[4,0,4]  R575      3.5175226628780365e-02
    z[4,0,4]  R576      1.3092462718486786e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R473      -1
    z[4,0,5]  R474      1
    z[4,0,5]  R477      -7.1296584606170654e-01
    z[4,0,5]  R478      -6.5558588504791260e-01
    z[4,0,5]  R479      5.1895566284656525e-02
    z[4,0,5]  R480      -0.0933489054441452
    z[4,0,5]  R481      -5.4180312156677246e-01
    z[4,0,5]  R482      0.0987154096364975
    z[4,0,5]  R483      3.5888131707906723e-02
    z[4,0,5]  R484      3.3192914724349976e-01
    z[4,0,5]  R485      -2.4730521440505981e-01
    z[4,0,5]  R486      -7.0260518789291382e-01
    z[4,0,5]  R487      2.0185057073831558e-02
    z[4,0,5]  R488      2.9615047574043274e-01
    z[4,0,5]  R489      4.6754315495491028e-02
    z[4,0,5]  R490      -1.4542146027088165e-01
    z[4,0,5]  R491      3.5263496637344360e-01
    z[4,0,5]  R492      4.4210180640220642e-01
    z[4,0,5]  R493      1.8660034239292145e-01
    z[4,0,5]  R494      3.9712288975715637e-01
    z[4,0,5]  R495      2.1152688190340996e-02
    z[4,0,5]  R496      5.3880882263183594e-01
    z[4,0,5]  R497      2.0857958495616913e-01
    z[4,0,5]  R498      -3.1896722316741943e-01
    z[4,0,5]  R499      -3.0509606003761292e-01
    z[4,0,5]  R500      -1.3022434897720814e-02
    z[4,0,5]  R501      -3.6757189035415649e-01
    z[4,0,5]  R502      -5.2152538299560547e-01
    z[4,0,5]  R503      -0.00387446372769773
    z[4,0,5]  R504      -3.5772538185119629e-01
    z[4,0,5]  R505      4.2368492484092712e-01
    z[4,0,5]  R506      3.1375296413898468e-02
    z[4,0,5]  R507      -3.2512894272804260e-01
    z[4,0,5]  R508      2.9254025220870972e-01
    z[4,0,5]  R509      -1.3117742538452148e-01
    z[4,0,5]  R510      -1.7303550243377686e-01
    z[4,0,5]  R511      3.7424415349960327e-01
    z[4,0,5]  R512      6.4648225903511047e-02
    z[4,0,5]  R513      -1.1710131540894508e-02
    z[4,0,5]  R514      -8.1055760383605957e-02
    z[4,0,5]  R515      3.1751343607902527e-01
    z[4,0,5]  R516      1.3374280929565430e-01
    z[4,0,5]  R517      1.9301900267601013e-01
    z[4,0,5]  R518      -2.4098545312881470e-01
    z[4,0,5]  R519      -4.5655433088541031e-02
    z[4,0,5]  R520      1.6269695758819580e-01
    z[4,0,5]  R521      1.8156847357749939e-01
    z[4,0,5]  R522      -1.2440264225006104e-01
    z[4,0,5]  R523      3.8067273795604706e-02
    z[4,0,5]  R524      -1.4498769305646420e-02
    z[4,0,5]  R525      2.9701495170593262e-01
    z[4,0,5]  R526      3.2781437039375305e-01
    z[4,0,5]  R527      -2.1783377975225449e-02
    z[4,0,5]  R528      4.9483588337898254e-01
    z[4,0,5]  R529      -2.7746891975402832e-01
    z[4,0,5]  R530      1.7879074811935425e-01
    z[4,0,5]  R531      -1.7395861446857452e-01
    z[4,0,5]  R532      -2.4008019268512726e-01
    z[4,0,5]  R533      -8.0920957028865814e-02
    z[4,0,5]  R534      1.4321397244930267e-01
    z[4,0,5]  R535      -6.2634360790252686e-01
    z[4,0,5]  R536      -1.2070432305335999e-01
    z[4,0,5]  R537      -3.4617307782173157e-01
    z[4,0,5]  R538      1.6461527347564697e-01
    z[4,0,5]  R539      3.6235302686691284e-01
    z[4,0,5]  R540      -8.5086993873119354e-02
    z[4,0,5]  R541      -1.1541321873664856e-01
    z[4,0,5]  R542      -2.9033929109573364e-02
    z[4,0,5]  R543      -3.2463672757148743e-01
    z[4,0,5]  R544      7.1673125028610229e-02
    z[4,0,5]  R545      2.3574155569076538e-01
    z[4,0,5]  R546      2.5926193594932556e-01
    z[4,0,5]  R547      -5.9350800514221191e-01
    z[4,0,5]  R548      -2.5583109259605408e-01
    z[4,0,5]  R549      4.0099734067916870e-01
    z[4,0,5]  R550      2.0111124217510223e-01
    z[4,0,5]  R551      6.6006970405578613e-01
    z[4,0,5]  R552      -4.5121449232101440e-01
    z[4,0,5]  R553      1.1117789149284363e-01
    z[4,0,5]  R554      8.4612101316452026e-02
    z[4,0,5]  R555      4.2945347726345062e-02
    z[4,0,5]  R556      -1.4339463412761688e-01
    z[4,0,5]  R557      1.0627873986959457e-01
    z[4,0,5]  R558      4.5774596929550171e-01
    z[4,0,5]  R559      -1.2302209436893463e-01
    z[4,0,5]  R560      0.358801931142807
    z[4,0,5]  R561      -1.9983839988708496e-01
    z[4,0,5]  R562      7.5674583204090595e-03
    z[4,0,5]  R563      7.5133427977561951e-02
    z[4,0,5]  R564      -1.2881948053836823e-01
    z[4,0,5]  R565      5.0045740604400635e-01
    z[4,0,5]  R566      -7.1160256862640381e-01
    z[4,0,5]  R567      -1.7666870728135109e-02
    z[4,0,5]  R568      0.540652334690094
    z[4,0,5]  R569      -1.1436444520950317e-01
    z[4,0,5]  R570      -3.8335829973220825e-01
    z[4,0,5]  R571      3.3776876330375671e-01
    z[4,0,5]  R572      2.2240476682782173e-02
    z[4,0,5]  R573      2.3721010982990265e-01
    z[4,0,5]  R574      4.4234889745712280e-01
    z[4,0,5]  R575      -1.3516525924205780e-01
    z[4,0,5]  R576      1.0247895121574402e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R475      -1
    z[4,0,6]  R476      1
    z[4,0,6]  R477      -3.7183862179517746e-02
    z[4,0,6]  R478      6.1730358749628067e-02
    z[4,0,6]  R479      -2.0730726420879364e-01
    z[4,0,6]  R480      -1.9549399614334106e-02
    z[4,0,6]  R481      -2.3333156481385231e-02
    z[4,0,6]  R482      1.1058200150728226e-01
    z[4,0,6]  R483      2.1728603541851044e-01
    z[4,0,6]  R484      1.7084307968616486e-01
    z[4,0,6]  R485      0.0621943362057209
    z[4,0,6]  R486      9.8989777266979218e-02
    z[4,0,6]  R487      -7.4050143361091614e-02
    z[4,0,6]  R488      1.2479652464389801e-01
    z[4,0,6]  R489      3.4068095684051514e-01
    z[4,0,6]  R490      -7.8221470117568970e-02
    z[4,0,6]  R491      2.0211410522460938e-01
    z[4,0,6]  R492      -1.2128803133964539e-01
    z[4,0,6]  R493      1.0726608335971832e-02
    z[4,0,6]  R494      -2.7989331632852554e-02
    z[4,0,6]  R495      7.1495153009891510e-02
    z[4,0,6]  R496      1.9758987426757812e-01
    z[4,0,6]  R497      -0.182672381401062
    z[4,0,6]  R498      1.8881724774837494e-01
    z[4,0,6]  R499      2.7827912569046021e-01
    z[4,0,6]  R500      4.6046045422554016e-01
    z[4,0,6]  R501      3.0882257223129272e-01
    z[4,0,6]  R502      1.3579729199409485e-01
    z[4,0,6]  R503      -2.8471130132675171e-01
    z[4,0,6]  R504      2.3114760220050812e-01
    z[4,0,6]  R505      2.5519579648971558e-01
    z[4,0,6]  R506      8.7783776223659515e-02
    z[4,0,6]  R507      1.9398948550224304e-01
    z[4,0,6]  R508      -2.0732876658439636e-01
    z[4,0,6]  R509      2.9423266649246216e-01
    z[4,0,6]  R510      -1.2253300100564957e-01
    z[4,0,6]  R511      -1.5627020597457886e-01
    z[4,0,6]  R512      1.2315811216831207e-01
    z[4,0,6]  R513      3.1587821245193481e-01
    z[4,0,6]  R514      -5.8175154030323029e-02
    z[4,0,6]  R515      3.0237710475921631e-01
    z[4,0,6]  R516      9.8276712000370026e-02
    z[4,0,6]  R517      4.7831159085035324e-02
    z[4,0,6]  R518      4.9570590257644653e-02
    z[4,0,6]  R519      -3.5549479722976685e-01
    z[4,0,6]  R520      2.2589640319347382e-01
    z[4,0,6]  R521      1.4294235408306122e-01
    z[4,0,6]  R522      0.416781485080719
    z[4,0,6]  R523      3.1296077370643616e-01
    z[4,0,6]  R524      -9.1624319553375244e-02
    z[4,0,6]  R525      -1.2416333705186844e-01
    z[4,0,6]  R526      1.9051942229270935e-01
    z[4,0,6]  R527      2.0645286142826080e-01
    z[4,0,6]  R528      7.9013511538505554e-02
    z[4,0,6]  R529      -9.2519924044609070e-02
    z[4,0,6]  R530      -9.1535985469818115e-02
    z[4,0,6]  R531      -1.0156561620533466e-02
    z[4,0,6]  R532      1.2745884060859680e-01
    z[4,0,6]  R533      -5.1139497756958008e-01
    z[4,0,6]  R534      4.5891612768173218e-01
    z[4,0,6]  R535      1.4600753784179688e-02
    z[4,0,6]  R536      -0.757362961769104
    z[4,0,6]  R537      4.1133561730384827e-01
    z[4,0,6]  R538      -2.4642260372638702e-01
    z[4,0,6]  R539      7.4573710560798645e-02
    z[4,0,6]  R540      -6.8557456135749817e-02
    z[4,0,6]  R541      -1.3689902424812317e-01
    z[4,0,6]  R542      -6.2951588630676270e-01
    z[4,0,6]  R543      -1.4645232260227203e-01
    z[4,0,6]  R544      -4.0977105498313904e-01
    z[4,0,6]  R545      -1.7787131667137146e-01
    z[4,0,6]  R546      -3.5683155059814453e-01
    z[4,0,6]  R547      -2.8236427903175354e-01
    z[4,0,6]  R548      7.7105000615119934e-02
    z[4,0,6]  R549      1.6026712954044342e-02
    z[4,0,6]  R550      -3.0342203378677368e-01
    z[4,0,6]  R551      1.8504323065280914e-01
    z[4,0,6]  R552      -2.0091125369071960e-01
    z[4,0,6]  R553      -6.1993765830993652e-01
    z[4,0,6]  R554      -4.6524727344512939e-01
    z[4,0,6]  R555      -4.0939357876777649e-01
    z[4,0,6]  R556      -3.6911708116531372e-01
    z[4,0,6]  R557      5.4386872053146362e-01
    z[4,0,6]  R558      2.3745955526828766e-01
    z[4,0,6]  R559      -4.7266405820846558e-01
    z[4,0,6]  R560      -2.6142436265945435e-01
    z[4,0,6]  R561      -7.5015507638454437e-02
    z[4,0,6]  R562      -4.0542531013488770e-01
    z[4,0,6]  R563      4.4498637318611145e-01
    z[4,0,6]  R564      1.8450500071048737e-01
    z[4,0,6]  R565      -4.0413599461317062e-02
    z[4,0,6]  R566      -1.7784436047077179e-01
    z[4,0,6]  R567      -1.7282395064830780e-01
    z[4,0,6]  R568      4.2528787255287170e-01
    z[4,0,6]  R569      -2.7329921722412109e-01
    z[4,0,6]  R570      2.6561632752418518e-01
    z[4,0,6]  R571      3.8113471865653992e-01
    z[4,0,6]  R572      -0.38875612616539
    z[4,0,6]  R573      -2.2092990577220917e-02
    z[4,0,6]  R574      8.9952535927295685e-02
    z[4,0,6]  R575      -3.4177824854850769e-02
    z[4,0,6]  R576      -5.7379838079214096e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R651      -1
    z[1,2,0]  R652      1
    z[1,2,0]  R665      -6.2199658155441284e-01
    z[1,2,0]  R666      -7.7160531282424927e-01
    z[1,2,0]  R667      -6.1112409830093384e-01
    z[1,2,0]  R668      -5.7374322414398193e-01
    z[1,2,0]  R669      -5.2528560161590576e-01
    z[1,2,0]  R670      -8.7464380264282227e-01
    z[1,2,0]  R671      -5.4201090335845947e-01
    z[1,2,0]  R672      -2.1386312320828438e-02
    z[1,2,0]  R673      1.2156501412391663e-01
    z[1,2,0]  R674      1.3759654760360718e-01
    z[1,2,0]  R675      6.9021439552307129e-01
    z[1,2,0]  R676      6.7544519901275635e-01
    z[1,2,0]  R677      7.3569852113723755e-01
    z[1,2,0]  R678      0.664685845375061
    z[1,2,0]  R679      -2.3322585038840771e-03
    z[1,2,0]  R680      6.6784366965293884e-02
    z[1,2,0]  R681      6.6822940111160278e-01
    z[1,2,0]  R682      6.3409155607223511e-01
    z[1,2,0]  R683      4.4640770554542542e-01
    z[1,2,0]  R684      6.4137673377990723e-01
    z[1,2,0]  R685      -1.9552423059940338e-01
    z[1,2,0]  R686      5.3327847272157669e-02
    z[1,2,0]  R687      2.4283061921596527e-01
    z[1,2,0]  R688      3.8440009951591492e-01
    z[1,2,0]  R689      -0.611303985118866
    z[1,2,0]  R690      8.9155435562133789e-01
    z[1,2,0]  R691      8.8695609569549561e-01
    z[1,2,0]  R692      7.9040008783340454e-01
    z[1,2,0]  R693      6.4192199707031250e-01
    z[1,2,0]  R694      6.2508374452590942e-01
    z[1,2,0]  R695      -1.5975123643875122e-01
    z[1,2,0]  R696      -1.1772423982620239e-01
    z[1,2,0]  R697      -1.3354407250881195e-01
    z[1,2,0]  R698      1.4820756018161774e-01
    z[1,2,0]  R699      9.3772947788238525e-01
    z[1,2,0]  R700      9.2041648924350739e-02
    z[1,2,0]  R701      6.9201219081878662e-01
    z[1,2,0]  R702      6.9072407484054565e-01
    z[1,2,0]  R703      7.1573674678802490e-01
    z[1,2,0]  R704      7.0400011539459229e-01
    z[1,2,0]  R705      2.2227536141872406e-01
    z[1,2,0]  R706      -1.6008595004677773e-02
    z[1,2,0]  R707      7.2454451583325863e-04
    z[1,2,0]  R708      -6.6037839651107788e-01
    z[1,2,0]  R709      -3.7577390670776367e-02
    z[1,2,0]  R710      8.5246467590332031e-01
    z[1,2,0]  R711      5.9630334377288818e-01
    z[1,2,0]  R712      0.791899561882019
    z[1,2,0]  R713      6.8710917234420776e-01
    z[1,2,0]  R714      4.8072680830955505e-01
    z[1,2,0]  R715      -3.9254170656204224e-01
    z[1,2,0]  R716      -2.3913398385047913e-01
    z[1,2,0]  R717      -4.2164230346679688e-01
    z[1,2,0]  R718      -4.6761247515678406e-01
    z[1,2,0]  R719      -6.8008285760879517e-01
    z[1,2,0]  R720      -6.4544725418090820e-01
    z[1,2,0]  R721      -9.2244094610214233e-01
    z[1,2,0]  R722      -4.7562113404273987e-01
    z[1,2,0]  R723      -5.7857674360275269e-01
    z[1,2,0]  R724      -0.748253583908081
    z[1,2,0]  R725      5.2099150419235229e-01
    z[1,2,0]  R726      5.5208230018615723e-01
    z[1,2,0]  R727      4.7966101765632629e-01
    z[1,2,0]  R728      5.6979340314865112e-01
    z[1,2,0]  R729      0.41551673412323
    z[1,2,0]  R730      3.0027130246162415e-01
    z[1,2,0]  R731      5.6916791200637817e-01
    z[1,2,0]  R732      3.7578943371772766e-01
    z[1,2,0]  R733      2.2402296960353851e-01
    z[1,2,0]  R734      3.7969928979873657e-01
    z[1,2,0]  R735      2.6223802566528320e-01
    z[1,2,0]  R736      3.6775204539299011e-01
    z[1,2,0]  R737      -2.1203437820076942e-02
    z[1,2,0]  R738      -1.3206343166530132e-02
    z[1,2,0]  R739      2.8164750337600708e-01
    z[1,2,0]  R740      -8.9676812291145325e-02
    z[1,2,0]  R741      6.2856757640838623e-01
    z[1,2,0]  R742      3.4075993299484253e-01
    z[1,2,0]  R743      -1.3045547902584076e-01
    z[1,2,0]  R744      -3.4689339995384216e-01
    z[1,2,0]  R745      3.5286378860473633e-01
    z[1,2,0]  R746      3.8080233335494995e-01
    z[1,2,0]  R747      -0.586037814617157
    z[1,2,0]  R748      -0.0869353786110878
    z[1,2,0]  R749      -7.7154916524887085e-01
    z[1,2,0]  R750      5.7940429449081421e-01
    z[1,2,0]  R751      -6.0262113809585571e-01
    z[1,2,0]  R752      -9.5427431166172028e-02
    z[1,2,0]  R753      -3.0859872698783875e-01
    z[1,2,0]  R754      -5.2074217796325684e-01
    z[1,2,0]  R755      -9.4161635637283325e-01
    z[1,2,0]  R756      -8.1056392192840576e-01
    z[1,2,0]  R757      3.9836764335632324e-01
    z[1,2,0]  R758      7.0478290319442749e-02
    z[1,2,0]  R759      -5.9895825386047363e-01
    z[1,2,0]  R760      2.6351484656333923e-01
    z[1,2,0]  R761      -1.5788662433624268e-01
    z[1,2,0]  R762      -6.1514323949813843e-01
    z[1,2,0]  R763      -3.8206470012664795e-01
    z[1,2,0]  R764      -1.1098635941743851e-01
    z[1,2,0]  R765      -6.7380934953689575e-01
    z[1,2,0]  R766      0.543727457523346
    z[1,2,0]  R767      -7.9898262023925781e-01
    z[1,2,0]  R768      7.9587094485759735e-02
    z[1,2,0]  R769      -5.8735519647598267e-01
    z[1,2,0]  R770      -1.9871200621128082e-01
    z[1,2,0]  R771      -5.9651982784271240e-01
    z[1,2,0]  R772      1.5138798952102661e-01
    z[1,2,0]  R773      -1.5813054144382477e-01
    z[1,2,0]  R774      -4.7670900821685791e-01
    z[1,2,0]  R775      3.3887746930122375e-01
    z[1,2,0]  R776      -8.8683640956878662e-01
    z[1,2,0]  R777      3.9698880910873413e-01
    z[1,2,0]  R778      -5.4121297597885132e-01
    z[1,2,0]  R779      2.5448048114776611e-01
    z[1,2,0]  R780      1.7015197873115540e-01
    z[1,2,0]  R781      -3.7779429554939270e-01
    z[1,2,0]  R782      -4.4674339890480042e-01
    z[1,2,0]  R783      -3.5545790195465088e-01
    z[1,2,0]  R784      6.5151005983352661e-01
    z[1,2,0]  R785      -6.8009203672409058e-01
    z[1,2,0]  R786      3.2066974788904190e-02
    z[1,2,0]  R787      -7.2874939441680908e-01
    z[1,2,0]  R788      -5.9182637929916382e-01
    z[1,2,0]  R789      -2.6132553815841675e-01
    z[1,2,0]  R790      2.8182464838027954e-01
    z[1,2,0]  R791      2.1349306404590607e-01
    z[1,2,0]  R792      -9.1540098190307617e-02
    z[1,2,0]  R793      -5.4024338722229004e-02
    z[1,2,0]  R794      3.6885675042867661e-02
    z[1,2,0]  R795      -8.9066106081008911e-01
    z[1,2,0]  R796      4.4937521219253540e-01
    z[1,2,0]  R797      0.754943311214447
    z[1,2,0]  R798      -5.8507156372070312e-01
    z[1,2,0]  R799      2.8378924727439880e-01
    z[1,2,0]  R800      7.8624807298183441e-02
    z[1,2,0]  R801      1.2666773796081543e-01
    z[1,2,0]  R802      9.6525497734546661e-02
    z[1,2,0]  R803      -1.7874591052532196e-01
    z[1,2,0]  R804      -1.5020088851451874e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R653      -1
    z[1,2,1]  R654      1
    z[1,2,1]  R665      -2.0145726203918457e-01
    z[1,2,1]  R666      -1.3858614861965179e-01
    z[1,2,1]  R667      -1.5970183908939362e-01
    z[1,2,1]  R668      8.3782915025949478e-03
    z[1,2,1]  R669      4.0934570133686066e-02
    z[1,2,1]  R670      -9.1613650321960449e-02
    z[1,2,1]  R671      -1.4009492099285126e-01
    z[1,2,1]  R672      7.5207066535949707e-01
    z[1,2,1]  R673      6.4621657133102417e-01
    z[1,2,1]  R674      0.71770840883255
    z[1,2,1]  R675      -9.5428124070167542e-02
    z[1,2,1]  R676      -3.6532577872276306e-01
    z[1,2,1]  R677      8.3413898944854736e-02
    z[1,2,1]  R678      -2.2163519263267517e-01
    z[1,2,1]  R679      4.8962447047233582e-01
    z[1,2,1]  R680      5.0277554988861084e-01
    z[1,2,1]  R681      -0.0774131491780281
    z[1,2,1]  R682      0.064273901283741
    z[1,2,1]  R683      4.0270447731018066e-01
    z[1,2,1]  R684      1.2772740423679352e-01
    z[1,2,1]  R685      5.3760612010955811e-01
    z[1,2,1]  R686      7.2069692611694336e-01
    z[1,2,1]  R687      6.8426930904388428e-01
    z[1,2,1]  R688      5.3322786092758179e-01
    z[1,2,1]  R689      2.6189538836479187e-01
    z[1,2,1]  R690      0.014797936193645
    z[1,2,1]  R691      -1.6544732451438904e-01
    z[1,2,1]  R692      -2.5596803426742554e-01
    z[1,2,1]  R693      6.4962941408157349e-01
    z[1,2,1]  R694      4.7971582412719727e-01
    z[1,2,1]  R695      8.3265745639801025e-01
    z[1,2,1]  R696      6.2543904781341553e-01
    z[1,2,1]  R697      9.3071424961090088e-01
    z[1,2,1]  R698      4.6321552991867065e-01
    z[1,2,1]  R699      -4.0591447614133358e-03
    z[1,2,1]  R700      8.1888866424560547e-01
    z[1,2,1]  R701      -1.4921982586383820e-01
    z[1,2,1]  R702      5.6284815073013306e-03
    z[1,2,1]  R703      -2.1217767149209976e-02
    z[1,2,1]  R704      -2.6838175952434540e-02
    z[1,2,1]  R705      0.801459550857544
    z[1,2,1]  R706      6.8712121248245239e-01
    z[1,2,1]  R707      5.8725732564926147e-01
    z[1,2,1]  R708      3.1341657042503357e-01
    z[1,2,1]  R709      7.8473997116088867e-01
    z[1,2,1]  R710      4.4005259871482849e-02
    z[1,2,1]  R711      6.6212427616119385e-01
    z[1,2,1]  R712      1.6940084099769592e-01
    z[1,2,1]  R713      -7.1493655443191528e-02
    z[1,2,1]  R714      2.8783044219017029e-01
    z[1,2,1]  R715      8.6168175935745239e-01
    z[1,2,1]  R716      9.5194482803344727e-01
    z[1,2,1]  R717      8.3967870473861694e-01
    z[1,2,1]  R718      7.5791954994201660e-01
    z[1,2,1]  R719      6.5164351463317871e-01
    z[1,2,1]  R720      0.60193932056427
    z[1,2,1]  R721      1.8296839296817780e-01
    z[1,2,1]  R722      7.0275247097015381e-01
    z[1,2,1]  R723      6.4181548357009888e-01
    z[1,2,1]  R724      6.2443137168884277e-01
    z[1,2,1]  R725      -0.166351318359375
    z[1,2,1]  R726      1.9614227116107941e-01
    z[1,2,1]  R727      1.2256369739770889e-01
    z[1,2,1]  R728      -6.2041327357292175e-02
    z[1,2,1]  R729      -3.0906911939382553e-02
    z[1,2,1]  R730      1.1112090200185776e-01
    z[1,2,1]  R731      -3.3025091886520386e-01
    z[1,2,1]  R732      -2.3501524329185486e-01
    z[1,2,1]  R733      -8.1570070981979370e-01
    z[1,2,1]  R734      -1.1152768507599831e-02
    z[1,2,1]  R735      4.8224860429763794e-01
    z[1,2,1]  R736      2.8804332017898560e-01
    z[1,2,1]  R737      -0.904996395111084
    z[1,2,1]  R738      -8.0651009082794189e-01
    z[1,2,1]  R739      -7.4384588003158569e-01
    z[1,2,1]  R740      -6.9912791252136230e-01
    z[1,2,1]  R741      -7.4209755659103394e-01
    z[1,2,1]  R742      -7.4391418695449829e-01
    z[1,2,1]  R743      -8.3136105537414551e-01
    z[1,2,1]  R744      -7.9074168205261230e-01
    z[1,2,1]  R745      3.5440880060195923e-01
    z[1,2,1]  R746      -1.8497738242149353e-01
    z[1,2,1]  R747      3.6687543988227844e-01
    z[1,2,1]  R748      -8.6033952236175537e-01
    z[1,2,1]  R749      -0.104481041431427
    z[1,2,1]  R750      5.4912644624710083e-01
    z[1,2,1]  R751      -2.0457734167575836e-01
    z[1,2,1]  R752      -8.8429284095764160e-01
    z[1,2,1]  R753      -7.8451168537139893e-01
    z[1,2,1]  R754      -0.317264199256897
    z[1,2,1]  R755      0.0891835018992424
    z[1,2,1]  R756      3.3691781759262085e-01
    z[1,2,1]  R757      4.4969987869262695e-01
    z[1,2,1]  R758      2.7287730574607849e-01
    z[1,2,1]  R759      1.3377930968999863e-02
    z[1,2,1]  R760      -9.3052148818969727e-01
    z[1,2,1]  R761      -8.7759679555892944e-01
    z[1,2,1]  R762      9.5067918300628662e-02
    z[1,2,1]  R763      4.3363296985626221e-01
    z[1,2,1]  R764      -8.2585883140563965e-01
    z[1,2,1]  R765      2.8689932823181152e-01
    z[1,2,1]  R766      5.7964378595352173e-01
    z[1,2,1]  R767      3.8527809083461761e-02
    z[1,2,1]  R768      -2.5478392839431763e-01
    z[1,2,1]  R769      0.0353827103972435
    z[1,2,1]  R770      -9.1124457120895386e-01
    z[1,2,1]  R771      -0.662040114402771
    z[1,2,1]  R772      -7.8357911109924316e-01
    z[1,2,1]  R773      -7.6083678007125854e-01
    z[1,2,1]  R774      -4.1661381721496582e-01
    z[1,2,1]  R775      -1.3202227652072906e-02
    z[1,2,1]  R776      2.2526440024375916e-01
    z[1,2,1]  R777      -4.9321573227643967e-02
    z[1,2,1]  R778      3.2392221689224243e-01
    z[1,2,1]  R779      -8.1055295467376709e-01
    z[1,2,1]  R780      -7.8756111860275269e-01
    z[1,2,1]  R781      -7.8263121843338013e-01
    z[1,2,1]  R782      -7.6649588346481323e-01
    z[1,2,1]  R783      -3.5260787606239319e-01
    z[1,2,1]  R784      6.2596333026885986e-01
    z[1,2,1]  R785      3.2141822576522827e-01
    z[1,2,1]  R786      3.8521626591682434e-01
    z[1,2,1]  R787      -5.0963733345270157e-02
    z[1,2,1]  R788      -2.4608006700873375e-02
    z[1,2,1]  R789      -8.7529158592224121e-01
    z[1,2,1]  R790      -8.6956137418746948e-01
    z[1,2,1]  R791      -8.2586467266082764e-01
    z[1,2,1]  R792      -8.3300560712814331e-01
    z[1,2,1]  R793      -9.1836810111999512e-01
    z[1,2,1]  R794      5.6905514001846313e-01
    z[1,2,1]  R795      3.3987060189247131e-01
    z[1,2,1]  R796      5.3938800096511841e-01
    z[1,2,1]  R797      1.8245634436607361e-01
    z[1,2,1]  R798      -5.8379560708999634e-01
    z[1,2,1]  R799      -0.758469820022583
    z[1,2,1]  R800      0.500398576259613
    z[1,2,1]  R801      -4.0672817826271057e-01
    z[1,2,1]  R802      -2.7699694037437439e-01
    z[1,2,1]  R803      -1.3899168372154236e-01
    z[1,2,1]  R804      -2.8170236945152283e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R655      -1
    z[1,2,2]  R656      1
    z[1,2,2]  R665      6.6310310363769531e-01
    z[1,2,2]  R666      4.5696407556533813e-01
    z[1,2,2]  R667      5.2851074934005737e-01
    z[1,2,2]  R668      5.6326884031295776e-01
    z[1,2,2]  R669      5.3494328260421753e-01
    z[1,2,2]  R670      -7.5360685586929321e-02
    z[1,2,2]  R671      3.4298107028007507e-01
    z[1,2,2]  R672      4.1973754763603210e-01
    z[1,2,2]  R673      -4.4399318099021912e-01
    z[1,2,2]  R674      3.3908709883689880e-01
    z[1,2,2]  R675      5.7380594313144684e-02
    z[1,2,2]  R676      3.3685940504074097e-01
    z[1,2,2]  R677      2.5801190733909607e-01
    z[1,2,2]  R678      -4.4733984395861626e-03
    z[1,2,2]  R679      -2.9572960734367371e-01
    z[1,2,2]  R680      -5.0286841392517090e-01
    z[1,2,2]  R681      7.3213323950767517e-02
    z[1,2,2]  R682      8.4472872316837311e-02
    z[1,2,2]  R683      -4.3464282155036926e-01
    z[1,2,2]  R684      -2.4279408156871796e-01
    z[1,2,2]  R685      -1.1018589884042740e-01
    z[1,2,2]  R686      -4.4181886315345764e-01
    z[1,2,2]  R687      -2.2919611632823944e-01
    z[1,2,2]  R688      -3.0812227725982666e-01
    z[1,2,2]  R689      -5.5857181549072266e-01
    z[1,2,2]  R690      -2.5917384028434753e-01
    z[1,2,2]  R691      2.4740447103977203e-01
    z[1,2,2]  R692      4.0581369400024414e-01
    z[1,2,2]  R693      -3.3495220541954041e-01
    z[1,2,2]  R694      -1.5745951235294342e-01
    z[1,2,2]  R695      2.1437798440456390e-01
    z[1,2,2]  R696      2.3800905793905258e-02
    z[1,2,2]  R697      -1.0439261794090271e-01
    z[1,2,2]  R698      5.1642164587974548e-02
    z[1,2,2]  R699      -7.0118896663188934e-02
    z[1,2,2]  R700      -1.0057786852121353e-01
    z[1,2,2]  R701      3.1586521863937378e-01
    z[1,2,2]  R702      0.470030277967453
    z[1,2,2]  R703      4.2068770527839661e-01
    z[1,2,2]  R704      3.3026865124702454e-01
    z[1,2,2]  R705      -2.4304631352424622e-01
    z[1,2,2]  R706      -6.7676077596843243e-03
    z[1,2,2]  R707      2.8672695159912109e-01
    z[1,2,2]  R708      -0.595943033695221
    z[1,2,2]  R709      1.6902524232864380e-01
    z[1,2,2]  R710      1.3917480409145355e-01
    z[1,2,2]  R711      2.8864562511444092e-01
    z[1,2,2]  R712      -2.4658817052841187e-01
    z[1,2,2]  R713      -1.4873377978801727e-01
    z[1,2,2]  R714      -6.7196351289749146e-01
    z[1,2,2]  R715      -4.6933200210332870e-02
    z[1,2,2]  R716      -1.1756887659430504e-02
    z[1,2,2]  R717      0.148001566529274
    z[1,2,2]  R718      1.7065636813640594e-01
    z[1,2,2]  R719      -1.1008264124393463e-01
    z[1,2,2]  R720      1.7419527471065521e-01
    z[1,2,2]  R721      2.6829114556312561e-01
    z[1,2,2]  R722      3.6461880803108215e-01
    z[1,2,2]  R723      1.4063043892383575e-01
    z[1,2,2]  R724      -0.0342351458966732
    z[1,2,2]  R725      2.0866812765598297e-01
    z[1,2,2]  R726      3.6729472875595093e-01
    z[1,2,2]  R727      3.6069635301828384e-02
    z[1,2,2]  R728      -5.5398438125848770e-02
    z[1,2,2]  R729      3.2442143559455872e-01
    z[1,2,2]  R730      5.2716922014951706e-02
    z[1,2,2]  R731      -1.0509991645812988e-01
    z[1,2,2]  R732      1.1707766354084015e-01
    z[1,2,2]  R733      -4.1049256920814514e-01
    z[1,2,2]  R734      -3.7668108940124512e-02
    z[1,2,2]  R735      -3.5654169321060181e-01
    z[1,2,2]  R736      -0.135230153799057
    z[1,2,2]  R737      1.7250137403607368e-02
    z[1,2,2]  R738      -1.4609888195991516e-01
    z[1,2,2]  R739      -6.6297873854637146e-02
    z[1,2,2]  R740      2.2318531572818756e-01
    z[1,2,2]  R741      3.1908690929412842e-02
    z[1,2,2]  R742      7.6484262943267822e-02
    z[1,2,2]  R743      6.1499748378992081e-02
    z[1,2,2]  R744      2.4359221756458282e-01
    z[1,2,2]  R745      1.7425008118152618e-01
    z[1,2,2]  R746      -1.3354432582855225e-01
    z[1,2,2]  R747      -1.3887584209442139e-01
    z[1,2,2]  R748      -3.9314043521881104e-01
    z[1,2,2]  R749      1.2395108491182327e-01
    z[1,2,2]  R750      1.6706761717796326e-01
    z[1,2,2]  R751      4.9057373404502869e-01
    z[1,2,2]  R752      2.4277816712856293e-01
    z[1,2,2]  R753      -1.8345075845718384e-01
    z[1,2,2]  R754      5.1877623796463013e-01
    z[1,2,2]  R755      0.0737726092338562
    z[1,2,2]  R756      4.3167144060134888e-02
    z[1,2,2]  R757      6.4395293593406677e-02
    z[1,2,2]  R758      2.7652397751808167e-01
    z[1,2,2]  R759      6.4655095338821411e-01
    z[1,2,2]  R760      1.6862362623214722e-01
    z[1,2,2]  R761      -2.0928969606757164e-02
    z[1,2,2]  R762      1.7930777370929718e-01
    z[1,2,2]  R763      3.1241157650947571e-01
    z[1,2,2]  R764      -1.7183783650398254e-01
    z[1,2,2]  R765      3.9254274964332581e-01
    z[1,2,2]  R766      2.8326365351676941e-01
    z[1,2,2]  R767      4.5729362964630127e-01
    z[1,2,2]  R768      1.0710256546735764e-01
    z[1,2,2]  R769      2.5877770781517029e-01
    z[1,2,2]  R770      2.4274586141109467e-01
    z[1,2,2]  R771      4.1924878954887390e-01
    z[1,2,2]  R772      -3.1090310215950012e-01
    z[1,2,2]  R773      4.1387838125228882e-01
    z[1,2,2]  R774      2.2290448844432831e-01
    z[1,2,2]  R775      1.3754753768444061e-01
    z[1,2,2]  R776      -2.9798170551657677e-02
    z[1,2,2]  R777      -2.5615268945693970e-01
    z[1,2,2]  R778      3.2194903492927551e-01
    z[1,2,2]  R779      -0.251189261674881
    z[1,2,2]  R780      -1.7484319210052490e-01
    z[1,2,2]  R781      -1.2572652101516724e-01
    z[1,2,2]  R782      1.7241321504116058e-02
    z[1,2,2]  R783      7.6796674728393555e-01
    z[1,2,2]  R784      -7.9537652432918549e-02
    z[1,2,2]  R785      3.1214842200279236e-01
    z[1,2,2]  R786      -4.9438709020614624e-01
    z[1,2,2]  R787      0.512950599193573
    z[1,2,2]  R788      3.3939656615257263e-01
    z[1,2,2]  R789      6.9249749183654785e-02
    z[1,2,2]  R790      -2.1348603069782257e-01
    z[1,2,2]  R791      -0.0791369378566742
    z[1,2,2]  R792      2.7444148436188698e-02
    z[1,2,2]  R793      -2.9958806931972504e-02
    z[1,2,2]  R794      -6.3811767101287842e-01
    z[1,2,2]  R795      2.1972709894180298e-01
    z[1,2,2]  R796      2.5459833443164825e-02
    z[1,2,2]  R797      5.6263640522956848e-02
    z[1,2,2]  R798      3.9968156814575195e-01
    z[1,2,2]  R799      -1.6684535145759583e-01
    z[1,2,2]  R800      -6.5829616785049438e-01
    z[1,2,2]  R801      -4.8338127136230469e-01
    z[1,2,2]  R802      -6.8979966640472412e-01
    z[1,2,2]  R803      5.9844231605529785e-01
    z[1,2,2]  R804      -6.1854153871536255e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R657      -1
    z[1,2,3]  R658      1
    z[1,2,3]  R665      3.1341338157653809e-01
    z[1,2,3]  R666      1.8908197060227394e-02
    z[1,2,3]  R667      -2.8964955708943307e-04
    z[1,2,3]  R668      3.0754616856575012e-01
    z[1,2,3]  R669      3.8061305880546570e-02
    z[1,2,3]  R670      -3.1138685345649719e-01
    z[1,2,3]  R671      -4.8708185553550720e-01
    z[1,2,3]  R672      0.396223783493042
    z[1,2,3]  R673      3.7728673219680786e-01
    z[1,2,3]  R674      2.6664876937866211e-01
    z[1,2,3]  R675      1.9758765399456024e-01
    z[1,2,3]  R676      -0.316006600856781
    z[1,2,3]  R677      1.4382773637771606e-01
    z[1,2,3]  R678      -1.5714384615421295e-02
    z[1,2,3]  R679      2.4181540310382843e-01
    z[1,2,3]  R680      3.9540793746709824e-02
    z[1,2,3]  R681      -3.6043757200241089e-01
    z[1,2,3]  R682      2.8433763980865479e-01
    z[1,2,3]  R683      5.7649207115173340e-01
    z[1,2,3]  R684      6.8747989833354950e-02
    z[1,2,3]  R685      7.4214011430740356e-01
    z[1,2,3]  R686      0.188423752784729
    z[1,2,3]  R687      6.4205802977085114e-02
    z[1,2,3]  R688      3.9703199267387390e-01
    z[1,2,3]  R689      2.2820882499217987e-01
    z[1,2,3]  R690      -3.6426779627799988e-01
    z[1,2,3]  R691      1.6558444499969482e-01
    z[1,2,3]  R692      -1.1350209265947342e-01
    z[1,2,3]  R693      1.5309593081474304e-01
    z[1,2,3]  R694      3.5759216547012329e-01
    z[1,2,3]  R695      -3.8059153594076633e-03
    z[1,2,3]  R696      5.3418916463851929e-01
    z[1,2,3]  R697      -1.7636317014694214e-01
    z[1,2,3]  R698      8.4341269731521606e-01
    z[1,2,3]  R699      -1.9268985092639923e-01
    z[1,2,3]  R700      -7.5990550220012665e-02
    z[1,2,3]  R701      2.1354450285434723e-01
    z[1,2,3]  R702      8.6045213043689728e-02
    z[1,2,3]  R703      2.6764717698097229e-01
    z[1,2,3]  R704      1.8788765370845795e-01
    z[1,2,3]  R705      3.0778220295906067e-01
    z[1,2,3]  R706      5.2945107221603394e-01
    z[1,2,3]  R707      0.535443902015686
    z[1,2,3]  R708      2.5708773732185364e-01
    z[1,2,3]  R709      2.3309373855590820e-01
    z[1,2,3]  R710      2.1342009305953979e-01
    z[1,2,3]  R711      -2.1970469970256090e-03
    z[1,2,3]  R712      3.6637461185455322e-01
    z[1,2,3]  R713      -3.9038904011249542e-02
    z[1,2,3]  R714      2.3746024072170258e-01
    z[1,2,3]  R715      2.5789457559585571e-01
    z[1,2,3]  R716      7.6679818332195282e-02
    z[1,2,3]  R717      7.4222676455974579e-02
    z[1,2,3]  R718      6.7925274372100830e-02
    z[1,2,3]  R719      4.2619869112968445e-02
    z[1,2,3]  R720      1.5018087625503540e-01
    z[1,2,3]  R721      -2.2287322208285332e-02
    z[1,2,3]  R722      1.7334936559200287e-01
    z[1,2,3]  R723      1.5530005097389221e-01
    z[1,2,3]  R724      0.0453343540430069
    z[1,2,3]  R725      6.0690528154373169e-01
    z[1,2,3]  R726      5.7045966386795044e-01
    z[1,2,3]  R727      5.9706658124923706e-01
    z[1,2,3]  R728      6.5926498174667358e-01
    z[1,2,3]  R729      5.5603188276290894e-01
    z[1,2,3]  R730      5.6152331829071045e-01
    z[1,2,3]  R731      6.3624918460845947e-01
    z[1,2,3]  R732      4.3104144930839539e-01
    z[1,2,3]  R733      -1.4310272037982941e-01
    z[1,2,3]  R734      3.2803124189376831e-01
    z[1,2,3]  R735      6.1675232648849487e-01
    z[1,2,3]  R736      4.8381385207176208e-01
    z[1,2,3]  R737      1.1437595635652542e-01
    z[1,2,3]  R738      4.5385140925645828e-02
    z[1,2,3]  R739      -4.7429639101028442e-01
    z[1,2,3]  R740      -1.3199462555348873e-02
    z[1,2,3]  R741      2.3878661915659904e-02
    z[1,2,3]  R742      -1.5798424184322357e-01
    z[1,2,3]  R743      -1.9470445811748505e-01
    z[1,2,3]  R744      2.4173672497272491e-01
    z[1,2,3]  R745      6.5899646282196045e-01
    z[1,2,3]  R746      7.6095026731491089e-01
    z[1,2,3]  R747      -7.1903415024280548e-02
    z[1,2,3]  R748      7.1365468204021454e-02
    z[1,2,3]  R749      -2.8981423377990723e-01
    z[1,2,3]  R750      3.6298626661300659e-01
    z[1,2,3]  R751      1.3017773628234863e-01
    z[1,2,3]  R752      -1.4988839626312256e-01
    z[1,2,3]  R753      -3.9614096283912659e-01
    z[1,2,3]  R754      -3.0419471859931946e-01
    z[1,2,3]  R755      -2.1315976977348328e-01
    z[1,2,3]  R756      -2.4674201011657715e-01
    z[1,2,3]  R757      6.0045200586318970e-01
    z[1,2,3]  R758      0.831079363822937
    z[1,2,3]  R759      2.4031335115432739e-01
    z[1,2,3]  R760      1.3446410000324249e-01
    z[1,2,3]  R761      1.8834297358989716e-01
    z[1,2,3]  R762      -4.5580846071243286e-01
    z[1,2,3]  R763      -4.4311785697937012e-01
    z[1,2,3]  R764      3.0654057860374451e-01
    z[1,2,3]  R765      -3.5950881242752075e-01
    z[1,2,3]  R766      4.5377832651138306e-01
    z[1,2,3]  R767      1.6288067400455475e-01
    z[1,2,3]  R768      7.8887414932250977e-01
    z[1,2,3]  R769      6.0306102037429810e-01
    z[1,2,3]  R770      2.2944065928459167e-01
    z[1,2,3]  R771      1.3756365515291691e-02
    z[1,2,3]  R772      1.4490705728530884e-01
    z[1,2,3]  R773      9.3097344040870667e-02
    z[1,2,3]  R774      -8.0060526728630066e-02
    z[1,2,3]  R775      7.7907508611679077e-01
    z[1,2,3]  R776      7.3133997619152069e-02
    z[1,2,3]  R777      7.1731686592102051e-01
    z[1,2,3]  R778      -1.1281068623065948e-01
    z[1,2,3]  R779      4.0450257062911987e-01
    z[1,2,3]  R780      0.00385760678909719
    z[1,2,3]  R781      -8.1982992589473724e-02
    z[1,2,3]  R782      1.7649991810321808e-01
    z[1,2,3]  R783      -2.6585987210273743e-01
    z[1,2,3]  R784      -2.9219236969947815e-01
    z[1,2,3]  R785      4.7909659147262573e-01
    z[1,2,3]  R786      6.0675078630447388e-01
    z[1,2,3]  R787      7.6968587934970856e-02
    z[1,2,3]  R788      5.7475709915161133e-01
    z[1,2,3]  R789      -1.0565434396266937e-01
    z[1,2,3]  R790      -7.3891326785087585e-02
    z[1,2,3]  R791      4.7077399492263794e-01
    z[1,2,3]  R792      3.1705811619758606e-01
    z[1,2,3]  R793      -3.5898125171661377e-01
    z[1,2,3]  R794      -4.4451120495796204e-01
    z[1,2,3]  R795      1.5172217041254044e-02
    z[1,2,3]  R796      6.6756260395050049e-01
    z[1,2,3]  R797      4.9172133207321167e-01
    z[1,2,3]  R798      1.4260038733482361e-01
    z[1,2,3]  R799      -4.7486531734466553e-01
    z[1,2,3]  R800      -3.3216324448585510e-01
    z[1,2,3]  R801      -2.8205469250679016e-01
    z[1,2,3]  R802      -5.6749057024717331e-02
    z[1,2,3]  R803      -1.0599813610315323e-01
    z[1,2,3]  R804      -1.9939118623733521e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R659      -1
    z[1,2,4]  R660      1
    z[1,2,4]  R665      1.1300813406705856e-01
    z[1,2,4]  R666      -3.8642933964729309e-01
    z[1,2,4]  R667      -9.0079814195632935e-02
    z[1,2,4]  R668      8.8150732219219208e-02
    z[1,2,4]  R669      -4.5742020010948181e-01
    z[1,2,4]  R670      1.4216986298561096e-01
    z[1,2,4]  R671      -2.6787242293357849e-01
    z[1,2,4]  R672      2.8083220124244690e-01
    z[1,2,4]  R673      -2.5144872069358826e-01
    z[1,2,4]  R674      -4.9075558781623840e-01
    z[1,2,4]  R675      -3.1574136018753052e-01
    z[1,2,4]  R676      2.3854206502437592e-01
    z[1,2,4]  R677      -3.1173032522201538e-01
    z[1,2,4]  R678      -5.2692997269332409e-03
    z[1,2,4]  R679      4.7481562942266464e-02
    z[1,2,4]  R680      3.9055937528610229e-01
    z[1,2,4]  R681      4.8122027516365051e-01
    z[1,2,4]  R682      2.7622234076261520e-02
    z[1,2,4]  R683      -2.9486179351806641e-01
    z[1,2,4]  R684      5.7679307460784912e-01
    z[1,2,4]  R685      -3.2303687930107117e-01
    z[1,2,4]  R686      1.0006729513406754e-01
    z[1,2,4]  R687      5.4100728034973145e-01
    z[1,2,4]  R688      -1.3723669946193695e-01
    z[1,2,4]  R689      -1.0526290535926819e-01
    z[1,2,4]  R690      -3.9644420146942139e-02
    z[1,2,4]  R691      4.3470472097396851e-02
    z[1,2,4]  R692      -5.1383804529905319e-02
    z[1,2,4]  R693      6.0614768415689468e-02
    z[1,2,4]  R694      3.7498101592063904e-01
    z[1,2,4]  R695      1.7336109280586243e-01
    z[1,2,4]  R696      1.0989484935998917e-01
    z[1,2,4]  R697      5.6798119097948074e-02
    z[1,2,4]  R698      -2.0531460642814636e-01
    z[1,2,4]  R699      -3.3285968005657196e-02
    z[1,2,4]  R700      6.1925571411848068e-02
    z[1,2,4]  R701      4.8588532209396362e-01
    z[1,2,4]  R702      -1.5737848356366158e-02
    z[1,2,4]  R703      2.6537817716598511e-01
    z[1,2,4]  R704      3.6819440126419067e-01
    z[1,2,4]  R705      -0.259318470954895
    z[1,2,4]  R706      -2.8912758827209473e-01
    z[1,2,4]  R707      -1.5906599164009094e-01
    z[1,2,4]  R708      1.1754310876131058e-01
    z[1,2,4]  R709      -3.7735603749752045e-02
    z[1,2,4]  R710      7.8367955982685089e-02
    z[1,2,4]  R711      2.9110535979270935e-01
    z[1,2,4]  R712      3.1753537058830261e-01
    z[1,2,4]  R713      0.500487744808197
    z[1,2,4]  R714      2.1694320440292358e-01
    z[1,2,4]  R715      -1.1496312171220779e-01
    z[1,2,4]  R716      6.1036888509988785e-02
    z[1,2,4]  R717      1.1571945995092392e-01
    z[1,2,4]  R718      -3.8888859748840332e-01
    z[1,2,4]  R719      -1.1638686805963516e-01
    z[1,2,4]  R720      -2.9812756180763245e-01
    z[1,2,4]  R721      -1.9319224357604980e-01
    z[1,2,4]  R722      1.6015812754631042e-01
    z[1,2,4]  R723      4.2423516511917114e-01
    z[1,2,4]  R724      -1.7063283594325185e-03
    z[1,2,4]  R725      -3.7976670265197754e-01
    z[1,2,4]  R726      -5.4631937295198441e-02
    z[1,2,4]  R727      -4.7857353091239929e-01
    z[1,2,4]  R728      1.5906213223934174e-01
    z[1,2,4]  R729      1.1276460252702236e-02
    z[1,2,4]  R730      5.0584155321121216e-01
    z[1,2,4]  R731      2.3941858112812042e-01
    z[1,2,4]  R732      -0.562581479549408
    z[1,2,4]  R733      8.6790435016155243e-02
    z[1,2,4]  R734      -1.2445009499788284e-01
    z[1,2,4]  R735      4.0344062447547913e-01
    z[1,2,4]  R736      -2.3010616004467010e-01
    z[1,2,4]  R737      -2.1427439153194427e-01
    z[1,2,4]  R738      -5.6533205509185791e-01
    z[1,2,4]  R739      -1.5597687661647797e-01
    z[1,2,4]  R740      -4.6064171195030212e-01
    z[1,2,4]  R741      -6.3801310956478119e-02
    z[1,2,4]  R742      5.2818089723587036e-01
    z[1,2,4]  R743      4.9443128705024719e-01
    z[1,2,4]  R744      -2.1657621860504150e-01
    z[1,2,4]  R745      -1.7721369862556458e-02
    z[1,2,4]  R746      3.4907300025224686e-02
    z[1,2,4]  R747      -1.4428691565990448e-01
    z[1,2,4]  R748      5.3972166031599045e-02
    z[1,2,4]  R749      3.9959940314292908e-01
    z[1,2,4]  R750      -4.4225663878023624e-03
    z[1,2,4]  R751      5.6520360708236694e-01
    z[1,2,4]  R752      2.9839816689491272e-01
    z[1,2,4]  R753      -1.2828929722309113e-01
    z[1,2,4]  R754      2.1192553639411926e-01
    z[1,2,4]  R755      8.9194908738136292e-02
    z[1,2,4]  R756      3.6870828270912170e-01
    z[1,2,4]  R757      -3.1754696369171143e-01
    z[1,2,4]  R758      2.1599155664443970e-01
    z[1,2,4]  R759      3.5281282663345337e-01
    z[1,2,4]  R760      -0.0717427060008049
    z[1,2,4]  R761      1.4988392591476440e-01
    z[1,2,4]  R762      1.9288735091686249e-01
    z[1,2,4]  R763      -3.0036326497793198e-02
    z[1,2,4]  R764      -2.2175274789333344e-02
    z[1,2,4]  R765      -5.9873346239328384e-02
    z[1,2,4]  R766      1.8889187276363373e-01
    z[1,2,4]  R767      -2.0365279912948608e-01
    z[1,2,4]  R768      -5.0281536579132080e-01
    z[1,2,4]  R769      -7.1040540933609009e-02
    z[1,2,4]  R770      7.4606128036975861e-02
    z[1,2,4]  R771      2.8247093781828880e-02
    z[1,2,4]  R772      8.0307433381676674e-04
    z[1,2,4]  R773      -8.1252768635749817e-02
    z[1,2,4]  R774      -6.5929013490676880e-01
    z[1,2,4]  R775      -3.4355142712593079e-01
    z[1,2,4]  R776      1.5855866670608521e-01
    z[1,2,4]  R777      4.9937221407890320e-01
    z[1,2,4]  R778      2.7032768726348877e-01
    z[1,2,4]  R779      9.5205254852771759e-02
    z[1,2,4]  R780      2.9664269089698792e-01
    z[1,2,4]  R781      -3.3074134588241577e-01
    z[1,2,4]  R782      -3.5192474722862244e-01
    z[1,2,4]  R783      -2.4802875518798828e-01
    z[1,2,4]  R784      -1.7932142317295074e-01
    z[1,2,4]  R785      -1.3013717532157898e-01
    z[1,2,4]  R786      -2.1842719614505768e-01
    z[1,2,4]  R787      -3.3131629228591919e-01
    z[1,2,4]  R788      3.6168730258941650e-01
    z[1,2,4]  R789      7.0028595626354218e-02
    z[1,2,4]  R790      3.1607393175363541e-02
    z[1,2,4]  R791      -3.6443449556827545e-02
    z[1,2,4]  R792      -7.0717319846153259e-02
    z[1,2,4]  R793      -8.0152988433837891e-02
    z[1,2,4]  R794      -9.5381431281566620e-02
    z[1,2,4]  R795      -8.0028679221868515e-03
    z[1,2,4]  R796      -4.6683689579367638e-03
    z[1,2,4]  R797      2.3104159533977509e-01
    z[1,2,4]  R798      -4.9141305498778820e-04
    z[1,2,4]  R799      2.8214901685714722e-01
    z[1,2,4]  R800      1.9687581062316895e-01
    z[1,2,4]  R801      6.2029594182968140e-01
    z[1,2,4]  R802      6.0424196720123291e-01
    z[1,2,4]  R803      -3.1634208559989929e-01
    z[1,2,4]  R804      6.7752408981323242e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R661      -1
    z[1,2,5]  R662      1
    z[1,2,5]  R665      6.3202202320098877e-02
    z[1,2,5]  R666      -6.3467338681221008e-02
    z[1,2,5]  R667      4.1443473100662231e-01
    z[1,2,5]  R668      3.7782818078994751e-01
    z[1,2,5]  R669      0.377505898475647
    z[1,2,5]  R670      -2.6834335923194885e-01
    z[1,2,5]  R671      -1.7452286183834076e-01
    z[1,2,5]  R672      -0.137746199965477
    z[1,2,5]  R673      1.7691782116889954e-01
    z[1,2,5]  R674      1.9589868187904358e-01
    z[1,2,5]  R675      -2.4177654087543488e-01
    z[1,2,5]  R676      -1.7560409009456635e-01
    z[1,2,5]  R677      -3.9284974336624146e-02
    z[1,2,5]  R678      -6.4603704214096069e-01
    z[1,2,5]  R679      1.7294013500213623e-01
    z[1,2,5]  R680      4.0715911984443665e-01
    z[1,2,5]  R681      3.3415222167968750e-01
    z[1,2,5]  R682      5.5208194255828857e-01
    z[1,2,5]  R683      4.7968883067369461e-02
    z[1,2,5]  R684      3.6822766065597534e-01
    z[1,2,5]  R685      -6.7715913057327271e-02
    z[1,2,5]  R686      3.0593699216842651e-01
    z[1,2,5]  R687      3.3995765447616577e-01
    z[1,2,5]  R688      3.4642115235328674e-01
    z[1,2,5]  R689      1.9710119068622589e-01
    z[1,2,5]  R690      5.4594278335571289e-02
    z[1,2,5]  R691      -2.0859143137931824e-01
    z[1,2,5]  R692      -2.2770951036363840e-03
    z[1,2,5]  R693      -1.1156143993139267e-01
    z[1,2,5]  R694      1.8164552748203278e-01
    z[1,2,5]  R695      4.3474078178405762e-01
    z[1,2,5]  R696      -6.3863977789878845e-02
    z[1,2,5]  R697      2.6505815982818604e-01
    z[1,2,5]  R698      -7.5593672692775726e-02
    z[1,2,5]  R699      -1.3024614751338959e-01
    z[1,2,5]  R700      -2.6933519169688225e-02
    z[1,2,5]  R701      -1.9698639214038849e-01
    z[1,2,5]  R702      4.6172770857810974e-01
    z[1,2,5]  R703      2.6775002479553223e-01
    z[1,2,5]  R704      4.6697062253952026e-01
    z[1,2,5]  R705      2.8888288140296936e-01
    z[1,2,5]  R706      2.0357848703861237e-01
    z[1,2,5]  R707      2.0439730584621429e-01
    z[1,2,5]  R708      5.7083507999777794e-03
    z[1,2,5]  R709      -4.3179920315742493e-01
    z[1,2,5]  R710      4.1979452967643738e-01
    z[1,2,5]  R711      1.8119035661220551e-01
    z[1,2,5]  R712      2.1958269178867340e-01
    z[1,2,5]  R713      2.7326586842536926e-01
    z[1,2,5]  R714      2.7693191170692444e-01
    z[1,2,5]  R715      0.0596165657043457
    z[1,2,5]  R716      -1.5421052277088165e-01
    z[1,2,5]  R717      2.5916749238967896e-01
    z[1,2,5]  R718      3.5540476441383362e-02
    z[1,2,5]  R719      2.4593852460384369e-01
    z[1,2,5]  R720      2.6339060068130493e-01
    z[1,2,5]  R721      -3.1690327450633049e-03
    z[1,2,5]  R722      -2.6576307415962219e-01
    z[1,2,5]  R723      7.5584337115287781e-02
    z[1,2,5]  R724      -1.3800999522209167e-01
    z[1,2,5]  R725      -2.3829996585845947e-01
    z[1,2,5]  R726      -4.3946501612663269e-01
    z[1,2,5]  R727      -3.5648146271705627e-01
    z[1,2,5]  R728      -4.4333106279373169e-01
    z[1,2,5]  R729      -1.6065049916505814e-02
    z[1,2,5]  R730      1.9907447695732117e-01
    z[1,2,5]  R731      1.5110961161553860e-02
    z[1,2,5]  R732      4.7820255160331726e-01
    z[1,2,5]  R733      3.8310371339321136e-02
    z[1,2,5]  R734      8.0996805429458618e-01
    z[1,2,5]  R735      -1.6127489507198334e-01
    z[1,2,5]  R736      0.690273106098175
    z[1,2,5]  R737      -3.0313533544540405e-01
    z[1,2,5]  R738      7.4939350597560406e-03
    z[1,2,5]  R739      0.0902993455529213
    z[1,2,5]  R740      -4.8316949605941772e-01
    z[1,2,5]  R741      1.0509271919727325e-01
    z[1,2,5]  R742      -1.3863454759120941e-01
    z[1,2,5]  R743      -5.6824021041393280e-02
    z[1,2,5]  R744      2.8457471728324890e-01
    z[1,2,5]  R745      -7.8652210533618927e-02
    z[1,2,5]  R746      1.3941408693790436e-01
    z[1,2,5]  R747      -5.6810826063156128e-01
    z[1,2,5]  R748      2.0864079892635345e-01
    z[1,2,5]  R749      3.5150960087776184e-01
    z[1,2,5]  R750      3.6750671267509460e-01
    z[1,2,5]  R751      8.7569728493690491e-02
    z[1,2,5]  R752      5.7715136557817459e-02
    z[1,2,5]  R753      2.7905693650245667e-01
    z[1,2,5]  R754      -3.2278639078140259e-01
    z[1,2,5]  R755      2.1576821804046631e-01
    z[1,2,5]  R756      1.7159767448902130e-01
    z[1,2,5]  R757      4.1267678141593933e-01
    z[1,2,5]  R758      -1.2315607070922852e-01
    z[1,2,5]  R759      -7.2828345000743866e-02
    z[1,2,5]  R760      1.3304447755217552e-02
    z[1,2,5]  R761      3.5721620917320251e-01
    z[1,2,5]  R762      -5.7846039533615112e-01
    z[1,2,5]  R763      -5.3011399507522583e-01
    z[1,2,5]  R764      2.8076618909835815e-01
    z[1,2,5]  R765      -2.3221983015537262e-01
    z[1,2,5]  R766      1.2673947215080261e-01
    z[1,2,5]  R767      -2.8106454014778137e-01
    z[1,2,5]  R768      1.4398138225078583e-01
    z[1,2,5]  R769      -2.9013365507125854e-01
    z[1,2,5]  R770      1.1404684931039810e-01
    z[1,2,5]  R771      -0.0963074192404747
    z[1,2,5]  R772      -1.9495855271816254e-01
    z[1,2,5]  R773      2.8034153580665588e-01
    z[1,2,5]  R774      -0.323823481798172
    z[1,2,5]  R775      3.7357372045516968e-01
    z[1,2,5]  R776      -5.8438368141651154e-02
    z[1,2,5]  R777      -7.9122297465801239e-02
    z[1,2,5]  R778      -6.4036726951599121e-01
    z[1,2,5]  R779      -1.8583790957927704e-01
    z[1,2,5]  R780      -3.2547211647033691e-01
    z[1,2,5]  R781      -2.4672269821166992e-01
    z[1,2,5]  R782      -1.0942756384611130e-01
    z[1,2,5]  R783      8.1528417766094208e-02
    z[1,2,5]  R784      2.4342155456542969e-01
    z[1,2,5]  R785      -2.1648842096328735e-01
    z[1,2,5]  R786      -1.0613638907670975e-01
    z[1,2,5]  R787      -6.7212902009487152e-02
    z[1,2,5]  R788      2.4922121316194534e-02
    z[1,2,5]  R789      -3.5402163863182068e-01
    z[1,2,5]  R790      -2.4613919854164124e-01
    z[1,2,5]  R791      -1.1041836440563202e-01
    z[1,2,5]  R792      -0.289393812417984
    z[1,2,5]  R793      -1.6315674409270287e-02
    z[1,2,5]  R794      9.6302941441535950e-02
    z[1,2,5]  R795      -1.8625985085964203e-01
    z[1,2,5]  R796      1.9237220287322998e-01
    z[1,2,5]  R797      -2.5953933596611023e-01
    z[1,2,5]  R798      2.0789082348346710e-01
    z[1,2,5]  R799      2.5498500093817711e-02
    z[1,2,5]  R800      3.3535334467887878e-01
    z[1,2,5]  R801      -2.5545755028724670e-01
    z[1,2,5]  R802      -2.6062300801277161e-01
    z[1,2,5]  R803      -3.4602773189544678e-01
    z[1,2,5]  R804      8.0022260546684265e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R663      -1
    z[1,2,6]  R664      1
    z[1,2,6]  R665      1.3355225324630737e-01
    z[1,2,6]  R666      1.5129385888576508e-01
    z[1,2,6]  R667      3.7660121917724609e-01
    z[1,2,6]  R668      -3.2919198274612427e-01
    z[1,2,6]  R669      -2.8817105293273926e-01
    z[1,2,6]  R670      -1.7816795408725739e-01
    z[1,2,6]  R671      -4.7906059026718140e-01
    z[1,2,6]  R672      -5.4024152457714081e-02
    z[1,2,6]  R673      3.6554688215255737e-01
    z[1,2,6]  R674      2.5745324790477753e-02
    z[1,2,6]  R675      5.6037104129791260e-01
    z[1,2,6]  R676      3.3051070570945740e-01
    z[1,2,6]  R677      -0.515571653842926
    z[1,2,6]  R678      3.0234414339065552e-01
    z[1,2,6]  R679      -0.762999951839447
    z[1,2,6]  R680      -4.1231209039688110e-01
    z[1,2,6]  R681      -2.6262232661247253e-01
    z[1,2,6]  R682      4.4749930500984192e-01
    z[1,2,6]  R683      -1.6747350990772247e-01
    z[1,2,6]  R684      -2.0090888440608978e-01
    z[1,2,6]  R685      -2.9980879276990891e-02
    z[1,2,6]  R686      -3.7872657179832458e-01
    z[1,2,6]  R687      -8.8856205344200134e-02
    z[1,2,6]  R688      -4.2010641098022461e-01
    z[1,2,6]  R689      3.7908756732940674e-01
    z[1,2,6]  R690      2.2304451093077660e-02
    z[1,2,6]  R691      2.2783493995666504e-01
    z[1,2,6]  R692      3.5991007089614868e-01
    z[1,2,6]  R693      -1.1902172863483429e-01
    z[1,2,6]  R694      -2.2993825376033783e-01
    z[1,2,6]  R695      1.2702395021915436e-01
    z[1,2,6]  R696      5.4119038581848145e-01
    z[1,2,6]  R697      2.1290307864546776e-02
    z[1,2,6]  R698      -3.9817806333303452e-02
    z[1,2,6]  R699      -2.4602632224559784e-01
    z[1,2,6]  R700      0.54817795753479
    z[1,2,6]  R701      -2.8034329414367676e-01
    z[1,2,6]  R702      -2.8477391600608826e-01
    z[1,2,6]  R703      -3.1071197986602783e-01
    z[1,2,6]  R704      -7.5204953551292419e-02
    z[1,2,6]  R705      6.1281401664018631e-02
    z[1,2,6]  R706      -3.4957808256149292e-01
    z[1,2,6]  R707      4.6811914443969727e-01
    z[1,2,6]  R708      -1.7486895620822906e-01
    z[1,2,6]  R709      3.3465558290481567e-01
    z[1,2,6]  R710      1.5518032014369965e-01
    z[1,2,6]  R711      7.1556642651557922e-02
    z[1,2,6]  R712      1.0816410183906555e-02
    z[1,2,6]  R713      4.1708725690841675e-01
    z[1,2,6]  R714      2.3318928480148315e-01
    z[1,2,6]  R715      -1.3391232490539551e-01
    z[1,2,6]  R716      -5.5602509528398514e-02
    z[1,2,6]  R717      9.5840133726596832e-02
    z[1,2,6]  R718      1.4374126493930817e-01
    z[1,2,6]  R719      -1.5773972868919373e-01
    z[1,2,6]  R720      0.0995691567659378
    z[1,2,6]  R721      -7.6256953179836273e-02
    z[1,2,6]  R722      1.4368730783462524e-01
    z[1,2,6]  R723      -1.5407225489616394e-01
    z[1,2,6]  R724      1.6710811853408813e-01
    z[1,2,6]  R725      2.9666331410408020e-01
    z[1,2,6]  R726      1.7016613855957985e-02
    z[1,2,6]  R727      -2.0249038934707642e-01
    z[1,2,6]  R728      -1.0928864032030106e-01
    z[1,2,6]  R729      6.4154869318008423e-01
    z[1,2,6]  R730      5.3281837701797485e-01
    z[1,2,6]  R731      3.0589789152145386e-01
    z[1,2,6]  R732      2.4263255298137665e-01
    z[1,2,6]  R733      -2.9404631257057190e-01
    z[1,2,6]  R734      2.7412512898445129e-01
    z[1,2,6]  R735      4.8868253827095032e-02
    z[1,2,6]  R736      8.0984615487977862e-04
    z[1,2,6]  R737      -1.7131294310092926e-01
    z[1,2,6]  R738      -7.9409822821617126e-02
    z[1,2,6]  R739      3.2485806941986084e-01
    z[1,2,6]  R740      8.6883746087551117e-02
    z[1,2,6]  R741      1.9362498819828033e-01
    z[1,2,6]  R742      3.8350574672222137e-02
    z[1,2,6]  R743      -0.0493636429309845
    z[1,2,6]  R744      9.3438185751438141e-02
    z[1,2,6]  R745      5.2796018123626709e-01
    z[1,2,6]  R746      -4.5082005858421326e-01
    z[1,2,6]  R747      -3.9235156774520874e-01
    z[1,2,6]  R748      -2.1485263109207153e-01
    z[1,2,6]  R749      1.0583304613828659e-01
    z[1,2,6]  R750      2.6076692342758179e-01
    z[1,2,6]  R751      0.101309634745121
    z[1,2,6]  R752      1.8745566904544830e-01
    z[1,2,6]  R753      6.6299118101596832e-02
    z[1,2,6]  R754      3.4264308214187622e-01
    z[1,2,6]  R755      3.6983732134103775e-03
    z[1,2,6]  R756      -3.6549825221300125e-02
    z[1,2,6]  R757      5.6970596313476562e-02
    z[1,2,6]  R758      -3.0264276266098022e-01
    z[1,2,6]  R759      1.8844233453273773e-01
    z[1,2,6]  R760      1.1336199194192886e-01
    z[1,2,6]  R761      -1.3753518462181091e-01
    z[1,2,6]  R762      2.8746657073497772e-02
    z[1,2,6]  R763      3.0018597841262817e-01
    z[1,2,6]  R764      -3.2065957784652710e-01
    z[1,2,6]  R765      3.5046026110649109e-01
    z[1,2,6]  R766      1.7457805573940277e-01
    z[1,2,6]  R767      6.3427664339542389e-02
    z[1,2,6]  R768      -1.4630000293254852e-01
    z[1,2,6]  R769      -3.6590874195098877e-01
    z[1,2,6]  R770      2.3407968692481518e-03
    z[1,2,6]  R771      1.4083732664585114e-01
    z[1,2,6]  R772      -4.5543056726455688e-01
    z[1,2,6]  R773      3.6189281940460205e-01
    z[1,2,6]  R774      5.9667207300662994e-02
    z[1,2,6]  R775      3.9056394249200821e-02
    z[1,2,6]  R776      -3.5774940252304077e-01
    z[1,2,6]  R777      6.4626209437847137e-02
    z[1,2,6]  R778      -5.1362957805395126e-02
    z[1,2,6]  R779      -8.9024573564529419e-02
    z[1,2,6]  R780      -3.5536146163940430e-01
    z[1,2,6]  R781      -2.2796842455863953e-01
    z[1,2,6]  R782      -2.1361030638217926e-01
    z[1,2,6]  R783      1.4386756718158722e-01
    z[1,2,6]  R784      -2.4325957521796227e-02
    z[1,2,6]  R785      -2.0830747485160828e-01
    z[1,2,6]  R786      -4.2313057184219360e-01
    z[1,2,6]  R787      2.8809100389480591e-01
    z[1,2,6]  R788      -2.6862871646881104e-01
    z[1,2,6]  R789      -1.3921138644218445e-01
    z[1,2,6]  R790      -2.2763611376285553e-01
    z[1,2,6]  R791      -1.7594610154628754e-01
    z[1,2,6]  R792      -3.2816660404205322e-01
    z[1,2,6]  R793      1.3124649226665497e-01
    z[1,2,6]  R794      -2.2728709876537323e-01
    z[1,2,6]  R795      -8.9128427207469940e-02
    z[1,2,6]  R796      -1.5429088473320007e-01
    z[1,2,6]  R797      -1.7627786099910736e-01
    z[1,2,6]  R798      -3.0590042471885681e-01
    z[1,2,6]  R799      1.0293000936508179e-01
    z[1,2,6]  R800      2.2025278210639954e-01
    z[1,2,6]  R801      2.3513735830783844e-01
    z[1,2,6]  R802      4.3343797326087952e-02
    z[1,2,6]  R803      -5.9962904453277588e-01
    z[1,2,6]  R804      1.0144189745187759e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R805      -1
    z[2,1,0]  R806      1
    z[2,1,0]  R819      -3.9254170656204224e-01
    z[2,1,0]  R820      -2.3913398385047913e-01
    z[2,1,0]  R821      -4.2164230346679688e-01
    z[2,1,0]  R822      -4.6761247515678406e-01
    z[2,1,0]  R823      -6.8008285760879517e-01
    z[2,1,0]  R824      -6.4544725418090820e-01
    z[2,1,0]  R825      -9.2244094610214233e-01
    z[2,1,0]  R826      -4.7562113404273987e-01
    z[2,1,0]  R827      -5.7857674360275269e-01
    z[2,1,0]  R828      -0.748253583908081
    z[2,1,0]  R829      5.2099150419235229e-01
    z[2,1,0]  R830      5.5208230018615723e-01
    z[2,1,0]  R831      4.7966101765632629e-01
    z[2,1,0]  R832      5.6979340314865112e-01
    z[2,1,0]  R833      0.41551673412323
    z[2,1,0]  R834      3.0027130246162415e-01
    z[2,1,0]  R835      5.6916791200637817e-01
    z[2,1,0]  R836      3.7578943371772766e-01
    z[2,1,0]  R837      2.2402296960353851e-01
    z[2,1,0]  R838      3.7969928979873657e-01
    z[2,1,0]  R839      2.6223802566528320e-01
    z[2,1,0]  R840      3.6775204539299011e-01
    z[2,1,0]  R841      -2.1203437820076942e-02
    z[2,1,0]  R842      -1.3206343166530132e-02
    z[2,1,0]  R843      2.8164750337600708e-01
    z[2,1,0]  R844      -8.9676812291145325e-02
    z[2,1,0]  R845      6.2856757640838623e-01
    z[2,1,0]  R846      3.4075993299484253e-01
    z[2,1,0]  R847      -1.3045547902584076e-01
    z[2,1,0]  R848      -3.4689339995384216e-01
    z[2,1,0]  R849      3.5286378860473633e-01
    z[2,1,0]  R850      3.8080233335494995e-01
    z[2,1,0]  R851      -0.586037814617157
    z[2,1,0]  R852      -0.0869353786110878
    z[2,1,0]  R853      -7.7154916524887085e-01
    z[2,1,0]  R854      5.7940429449081421e-01
    z[2,1,0]  R855      -6.0262113809585571e-01
    z[2,1,0]  R856      -9.5427431166172028e-02
    z[2,1,0]  R857      -3.0859872698783875e-01
    z[2,1,0]  R858      -5.2074217796325684e-01
    z[2,1,0]  R859      -9.4161635637283325e-01
    z[2,1,0]  R860      -8.1056392192840576e-01
    z[2,1,0]  R861      3.9836764335632324e-01
    z[2,1,0]  R862      7.0478290319442749e-02
    z[2,1,0]  R863      -5.9895825386047363e-01
    z[2,1,0]  R864      2.6351484656333923e-01
    z[2,1,0]  R865      -1.5788662433624268e-01
    z[2,1,0]  R866      -6.1514323949813843e-01
    z[2,1,0]  R867      -3.8206470012664795e-01
    z[2,1,0]  R868      -1.1098635941743851e-01
    z[2,1,0]  R869      -6.7380934953689575e-01
    z[2,1,0]  R870      0.543727457523346
    z[2,1,0]  R871      -7.9898262023925781e-01
    z[2,1,0]  R872      7.9587094485759735e-02
    z[2,1,0]  R873      -5.8735519647598267e-01
    z[2,1,0]  R874      -1.9871200621128082e-01
    z[2,1,0]  R875      -5.9651982784271240e-01
    z[2,1,0]  R876      1.5138798952102661e-01
    z[2,1,0]  R877      -1.5813054144382477e-01
    z[2,1,0]  R878      -4.7670900821685791e-01
    z[2,1,0]  R879      3.3887746930122375e-01
    z[2,1,0]  R880      -8.8683640956878662e-01
    z[2,1,0]  R881      3.9698880910873413e-01
    z[2,1,0]  R882      -5.4121297597885132e-01
    z[2,1,0]  R883      2.5448048114776611e-01
    z[2,1,0]  R884      1.7015197873115540e-01
    z[2,1,0]  R885      -3.7779429554939270e-01
    z[2,1,0]  R886      -4.4674339890480042e-01
    z[2,1,0]  R887      -3.5545790195465088e-01
    z[2,1,0]  R888      6.5151005983352661e-01
    z[2,1,0]  R889      -6.8009203672409058e-01
    z[2,1,0]  R890      3.2066974788904190e-02
    z[2,1,0]  R891      -7.2874939441680908e-01
    z[2,1,0]  R892      -5.9182637929916382e-01
    z[2,1,0]  R893      -2.6132553815841675e-01
    z[2,1,0]  R894      2.8182464838027954e-01
    z[2,1,0]  R895      2.1349306404590607e-01
    z[2,1,0]  R896      -9.1540098190307617e-02
    z[2,1,0]  R897      -5.4024338722229004e-02
    z[2,1,0]  R898      3.6885675042867661e-02
    z[2,1,0]  R899      -8.9066106081008911e-01
    z[2,1,0]  R900      4.4937521219253540e-01
    z[2,1,0]  R901      0.754943311214447
    z[2,1,0]  R902      -5.8507156372070312e-01
    z[2,1,0]  R903      2.8378924727439880e-01
    z[2,1,0]  R904      7.8624807298183441e-02
    z[2,1,0]  R905      1.2666773796081543e-01
    z[2,1,0]  R906      9.6525497734546661e-02
    z[2,1,0]  R907      -1.7874591052532196e-01
    z[2,1,0]  R908      -1.5020088851451874e-01
    z[2,1,0]  R909      -6.2199658155441284e-01
    z[2,1,0]  R910      -7.7160531282424927e-01
    z[2,1,0]  R911      -6.1112409830093384e-01
    z[2,1,0]  R912      -5.7374322414398193e-01
    z[2,1,0]  R913      -5.2528560161590576e-01
    z[2,1,0]  R914      -8.7464380264282227e-01
    z[2,1,0]  R915      -5.4201090335845947e-01
    z[2,1,0]  R916      -2.1386312320828438e-02
    z[2,1,0]  R917      1.2156501412391663e-01
    z[2,1,0]  R918      1.3759654760360718e-01
    z[2,1,0]  R919      6.9021439552307129e-01
    z[2,1,0]  R920      6.7544519901275635e-01
    z[2,1,0]  R921      7.3569852113723755e-01
    z[2,1,0]  R922      0.664685845375061
    z[2,1,0]  R923      -2.3322585038840771e-03
    z[2,1,0]  R924      6.6784366965293884e-02
    z[2,1,0]  R925      6.6822940111160278e-01
    z[2,1,0]  R926      6.3409155607223511e-01
    z[2,1,0]  R927      4.4640770554542542e-01
    z[2,1,0]  R928      6.4137673377990723e-01
    z[2,1,0]  R929      -1.9552423059940338e-01
    z[2,1,0]  R930      5.3327847272157669e-02
    z[2,1,0]  R931      2.4283061921596527e-01
    z[2,1,0]  R932      3.8440009951591492e-01
    z[2,1,0]  R933      -0.611303985118866
    z[2,1,0]  R934      8.9155435562133789e-01
    z[2,1,0]  R935      8.8695609569549561e-01
    z[2,1,0]  R936      7.9040008783340454e-01
    z[2,1,0]  R937      6.4192199707031250e-01
    z[2,1,0]  R938      6.2508374452590942e-01
    z[2,1,0]  R939      -1.5975123643875122e-01
    z[2,1,0]  R940      -1.1772423982620239e-01
    z[2,1,0]  R941      -1.3354407250881195e-01
    z[2,1,0]  R942      1.4820756018161774e-01
    z[2,1,0]  R943      9.3772947788238525e-01
    z[2,1,0]  R944      9.2041648924350739e-02
    z[2,1,0]  R945      6.9201219081878662e-01
    z[2,1,0]  R946      6.9072407484054565e-01
    z[2,1,0]  R947      7.1573674678802490e-01
    z[2,1,0]  R948      7.0400011539459229e-01
    z[2,1,0]  R949      2.2227536141872406e-01
    z[2,1,0]  R950      -1.6008595004677773e-02
    z[2,1,0]  R951      7.2454451583325863e-04
    z[2,1,0]  R952      -6.6037839651107788e-01
    z[2,1,0]  R953      -3.7577390670776367e-02
    z[2,1,0]  R954      8.5246467590332031e-01
    z[2,1,0]  R955      5.9630334377288818e-01
    z[2,1,0]  R956      0.791899561882019
    z[2,1,0]  R957      6.8710917234420776e-01
    z[2,1,0]  R958      4.8072680830955505e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R807      -1
    z[2,1,1]  R808      1
    z[2,1,1]  R819      8.6168175935745239e-01
    z[2,1,1]  R820      9.5194482803344727e-01
    z[2,1,1]  R821      8.3967870473861694e-01
    z[2,1,1]  R822      7.5791954994201660e-01
    z[2,1,1]  R823      6.5164351463317871e-01
    z[2,1,1]  R824      0.60193932056427
    z[2,1,1]  R825      1.8296839296817780e-01
    z[2,1,1]  R826      7.0275247097015381e-01
    z[2,1,1]  R827      6.4181548357009888e-01
    z[2,1,1]  R828      6.2443137168884277e-01
    z[2,1,1]  R829      -0.166351318359375
    z[2,1,1]  R830      1.9614227116107941e-01
    z[2,1,1]  R831      1.2256369739770889e-01
    z[2,1,1]  R832      -6.2041327357292175e-02
    z[2,1,1]  R833      -3.0906911939382553e-02
    z[2,1,1]  R834      1.1112090200185776e-01
    z[2,1,1]  R835      -3.3025091886520386e-01
    z[2,1,1]  R836      -2.3501524329185486e-01
    z[2,1,1]  R837      -8.1570070981979370e-01
    z[2,1,1]  R838      -1.1152768507599831e-02
    z[2,1,1]  R839      4.8224860429763794e-01
    z[2,1,1]  R840      2.8804332017898560e-01
    z[2,1,1]  R841      -0.904996395111084
    z[2,1,1]  R842      -8.0651009082794189e-01
    z[2,1,1]  R843      -7.4384588003158569e-01
    z[2,1,1]  R844      -6.9912791252136230e-01
    z[2,1,1]  R845      -7.4209755659103394e-01
    z[2,1,1]  R846      -7.4391418695449829e-01
    z[2,1,1]  R847      -8.3136105537414551e-01
    z[2,1,1]  R848      -7.9074168205261230e-01
    z[2,1,1]  R849      3.5440880060195923e-01
    z[2,1,1]  R850      -1.8497738242149353e-01
    z[2,1,1]  R851      3.6687543988227844e-01
    z[2,1,1]  R852      -8.6033952236175537e-01
    z[2,1,1]  R853      -0.104481041431427
    z[2,1,1]  R854      5.4912644624710083e-01
    z[2,1,1]  R855      -2.0457734167575836e-01
    z[2,1,1]  R856      -8.8429284095764160e-01
    z[2,1,1]  R857      -7.8451168537139893e-01
    z[2,1,1]  R858      -0.317264199256897
    z[2,1,1]  R859      0.0891835018992424
    z[2,1,1]  R860      3.3691781759262085e-01
    z[2,1,1]  R861      4.4969987869262695e-01
    z[2,1,1]  R862      2.7287730574607849e-01
    z[2,1,1]  R863      1.3377930968999863e-02
    z[2,1,1]  R864      -9.3052148818969727e-01
    z[2,1,1]  R865      -8.7759679555892944e-01
    z[2,1,1]  R866      9.5067918300628662e-02
    z[2,1,1]  R867      4.3363296985626221e-01
    z[2,1,1]  R868      -8.2585883140563965e-01
    z[2,1,1]  R869      2.8689932823181152e-01
    z[2,1,1]  R870      5.7964378595352173e-01
    z[2,1,1]  R871      3.8527809083461761e-02
    z[2,1,1]  R872      -2.5478392839431763e-01
    z[2,1,1]  R873      0.0353827103972435
    z[2,1,1]  R874      -9.1124457120895386e-01
    z[2,1,1]  R875      -0.662040114402771
    z[2,1,1]  R876      -7.8357911109924316e-01
    z[2,1,1]  R877      -7.6083678007125854e-01
    z[2,1,1]  R878      -4.1661381721496582e-01
    z[2,1,1]  R879      -1.3202227652072906e-02
    z[2,1,1]  R880      2.2526440024375916e-01
    z[2,1,1]  R881      -4.9321573227643967e-02
    z[2,1,1]  R882      3.2392221689224243e-01
    z[2,1,1]  R883      -8.1055295467376709e-01
    z[2,1,1]  R884      -7.8756111860275269e-01
    z[2,1,1]  R885      -7.8263121843338013e-01
    z[2,1,1]  R886      -7.6649588346481323e-01
    z[2,1,1]  R887      -3.5260787606239319e-01
    z[2,1,1]  R888      6.2596333026885986e-01
    z[2,1,1]  R889      3.2141822576522827e-01
    z[2,1,1]  R890      3.8521626591682434e-01
    z[2,1,1]  R891      -5.0963733345270157e-02
    z[2,1,1]  R892      -2.4608006700873375e-02
    z[2,1,1]  R893      -8.7529158592224121e-01
    z[2,1,1]  R894      -8.6956137418746948e-01
    z[2,1,1]  R895      -8.2586467266082764e-01
    z[2,1,1]  R896      -8.3300560712814331e-01
    z[2,1,1]  R897      -9.1836810111999512e-01
    z[2,1,1]  R898      5.6905514001846313e-01
    z[2,1,1]  R899      3.3987060189247131e-01
    z[2,1,1]  R900      5.3938800096511841e-01
    z[2,1,1]  R901      1.8245634436607361e-01
    z[2,1,1]  R902      -5.8379560708999634e-01
    z[2,1,1]  R903      -0.758469820022583
    z[2,1,1]  R904      0.500398576259613
    z[2,1,1]  R905      -4.0672817826271057e-01
    z[2,1,1]  R906      -2.7699694037437439e-01
    z[2,1,1]  R907      -1.3899168372154236e-01
    z[2,1,1]  R908      -2.8170236945152283e-01
    z[2,1,1]  R909      -2.0145726203918457e-01
    z[2,1,1]  R910      -1.3858614861965179e-01
    z[2,1,1]  R911      -1.5970183908939362e-01
    z[2,1,1]  R912      8.3782915025949478e-03
    z[2,1,1]  R913      4.0934570133686066e-02
    z[2,1,1]  R914      -9.1613650321960449e-02
    z[2,1,1]  R915      -1.4009492099285126e-01
    z[2,1,1]  R916      7.5207066535949707e-01
    z[2,1,1]  R917      6.4621657133102417e-01
    z[2,1,1]  R918      0.71770840883255
    z[2,1,1]  R919      -9.5428124070167542e-02
    z[2,1,1]  R920      -3.6532577872276306e-01
    z[2,1,1]  R921      8.3413898944854736e-02
    z[2,1,1]  R922      -2.2163519263267517e-01
    z[2,1,1]  R923      4.8962447047233582e-01
    z[2,1,1]  R924      5.0277554988861084e-01
    z[2,1,1]  R925      -0.0774131491780281
    z[2,1,1]  R926      0.064273901283741
    z[2,1,1]  R927      4.0270447731018066e-01
    z[2,1,1]  R928      1.2772740423679352e-01
    z[2,1,1]  R929      5.3760612010955811e-01
    z[2,1,1]  R930      7.2069692611694336e-01
    z[2,1,1]  R931      6.8426930904388428e-01
    z[2,1,1]  R932      5.3322786092758179e-01
    z[2,1,1]  R933      2.6189538836479187e-01
    z[2,1,1]  R934      0.014797936193645
    z[2,1,1]  R935      -1.6544732451438904e-01
    z[2,1,1]  R936      -2.5596803426742554e-01
    z[2,1,1]  R937      6.4962941408157349e-01
    z[2,1,1]  R938      4.7971582412719727e-01
    z[2,1,1]  R939      8.3265745639801025e-01
    z[2,1,1]  R940      6.2543904781341553e-01
    z[2,1,1]  R941      9.3071424961090088e-01
    z[2,1,1]  R942      4.6321552991867065e-01
    z[2,1,1]  R943      -4.0591447614133358e-03
    z[2,1,1]  R944      8.1888866424560547e-01
    z[2,1,1]  R945      -1.4921982586383820e-01
    z[2,1,1]  R946      5.6284815073013306e-03
    z[2,1,1]  R947      -2.1217767149209976e-02
    z[2,1,1]  R948      -2.6838175952434540e-02
    z[2,1,1]  R949      0.801459550857544
    z[2,1,1]  R950      6.8712121248245239e-01
    z[2,1,1]  R951      5.8725732564926147e-01
    z[2,1,1]  R952      3.1341657042503357e-01
    z[2,1,1]  R953      7.8473997116088867e-01
    z[2,1,1]  R954      4.4005259871482849e-02
    z[2,1,1]  R955      6.6212427616119385e-01
    z[2,1,1]  R956      1.6940084099769592e-01
    z[2,1,1]  R957      -7.1493655443191528e-02
    z[2,1,1]  R958      2.8783044219017029e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R809      -1
    z[2,1,2]  R810      1
    z[2,1,2]  R819      -4.6933200210332870e-02
    z[2,1,2]  R820      -1.1756887659430504e-02
    z[2,1,2]  R821      0.148001566529274
    z[2,1,2]  R822      1.7065636813640594e-01
    z[2,1,2]  R823      -1.1008264124393463e-01
    z[2,1,2]  R824      1.7419527471065521e-01
    z[2,1,2]  R825      2.6829114556312561e-01
    z[2,1,2]  R826      3.6461880803108215e-01
    z[2,1,2]  R827      1.4063043892383575e-01
    z[2,1,2]  R828      -0.0342351458966732
    z[2,1,2]  R829      2.0866812765598297e-01
    z[2,1,2]  R830      3.6729472875595093e-01
    z[2,1,2]  R831      3.6069635301828384e-02
    z[2,1,2]  R832      -5.5398438125848770e-02
    z[2,1,2]  R833      3.2442143559455872e-01
    z[2,1,2]  R834      5.2716922014951706e-02
    z[2,1,2]  R835      -1.0509991645812988e-01
    z[2,1,2]  R836      1.1707766354084015e-01
    z[2,1,2]  R837      -4.1049256920814514e-01
    z[2,1,2]  R838      -3.7668108940124512e-02
    z[2,1,2]  R839      -3.5654169321060181e-01
    z[2,1,2]  R840      -0.135230153799057
    z[2,1,2]  R841      1.7250137403607368e-02
    z[2,1,2]  R842      -1.4609888195991516e-01
    z[2,1,2]  R843      -6.6297873854637146e-02
    z[2,1,2]  R844      2.2318531572818756e-01
    z[2,1,2]  R845      3.1908690929412842e-02
    z[2,1,2]  R846      7.6484262943267822e-02
    z[2,1,2]  R847      6.1499748378992081e-02
    z[2,1,2]  R848      2.4359221756458282e-01
    z[2,1,2]  R849      1.7425008118152618e-01
    z[2,1,2]  R850      -1.3354432582855225e-01
    z[2,1,2]  R851      -1.3887584209442139e-01
    z[2,1,2]  R852      -3.9314043521881104e-01
    z[2,1,2]  R853      1.2395108491182327e-01
    z[2,1,2]  R854      1.6706761717796326e-01
    z[2,1,2]  R855      4.9057373404502869e-01
    z[2,1,2]  R856      2.4277816712856293e-01
    z[2,1,2]  R857      -1.8345075845718384e-01
    z[2,1,2]  R858      5.1877623796463013e-01
    z[2,1,2]  R859      0.0737726092338562
    z[2,1,2]  R860      4.3167144060134888e-02
    z[2,1,2]  R861      6.4395293593406677e-02
    z[2,1,2]  R862      2.7652397751808167e-01
    z[2,1,2]  R863      6.4655095338821411e-01
    z[2,1,2]  R864      1.6862362623214722e-01
    z[2,1,2]  R865      -2.0928969606757164e-02
    z[2,1,2]  R866      1.7930777370929718e-01
    z[2,1,2]  R867      3.1241157650947571e-01
    z[2,1,2]  R868      -1.7183783650398254e-01
    z[2,1,2]  R869      3.9254274964332581e-01
    z[2,1,2]  R870      2.8326365351676941e-01
    z[2,1,2]  R871      4.5729362964630127e-01
    z[2,1,2]  R872      1.0710256546735764e-01
    z[2,1,2]  R873      2.5877770781517029e-01
    z[2,1,2]  R874      2.4274586141109467e-01
    z[2,1,2]  R875      4.1924878954887390e-01
    z[2,1,2]  R876      -3.1090310215950012e-01
    z[2,1,2]  R877      4.1387838125228882e-01
    z[2,1,2]  R878      2.2290448844432831e-01
    z[2,1,2]  R879      1.3754753768444061e-01
    z[2,1,2]  R880      -2.9798170551657677e-02
    z[2,1,2]  R881      -2.5615268945693970e-01
    z[2,1,2]  R882      3.2194903492927551e-01
    z[2,1,2]  R883      -0.251189261674881
    z[2,1,2]  R884      -1.7484319210052490e-01
    z[2,1,2]  R885      -1.2572652101516724e-01
    z[2,1,2]  R886      1.7241321504116058e-02
    z[2,1,2]  R887      7.6796674728393555e-01
    z[2,1,2]  R888      -7.9537652432918549e-02
    z[2,1,2]  R889      3.1214842200279236e-01
    z[2,1,2]  R890      -4.9438709020614624e-01
    z[2,1,2]  R891      0.512950599193573
    z[2,1,2]  R892      3.3939656615257263e-01
    z[2,1,2]  R893      6.9249749183654785e-02
    z[2,1,2]  R894      -2.1348603069782257e-01
    z[2,1,2]  R895      -0.0791369378566742
    z[2,1,2]  R896      2.7444148436188698e-02
    z[2,1,2]  R897      -2.9958806931972504e-02
    z[2,1,2]  R898      -6.3811767101287842e-01
    z[2,1,2]  R899      2.1972709894180298e-01
    z[2,1,2]  R900      2.5459833443164825e-02
    z[2,1,2]  R901      5.6263640522956848e-02
    z[2,1,2]  R902      3.9968156814575195e-01
    z[2,1,2]  R903      -1.6684535145759583e-01
    z[2,1,2]  R904      -6.5829616785049438e-01
    z[2,1,2]  R905      -4.8338127136230469e-01
    z[2,1,2]  R906      -6.8979966640472412e-01
    z[2,1,2]  R907      5.9844231605529785e-01
    z[2,1,2]  R908      -6.1854153871536255e-01
    z[2,1,2]  R909      6.6310310363769531e-01
    z[2,1,2]  R910      4.5696407556533813e-01
    z[2,1,2]  R911      5.2851074934005737e-01
    z[2,1,2]  R912      5.6326884031295776e-01
    z[2,1,2]  R913      5.3494328260421753e-01
    z[2,1,2]  R914      -7.5360685586929321e-02
    z[2,1,2]  R915      3.4298107028007507e-01
    z[2,1,2]  R916      4.1973754763603210e-01
    z[2,1,2]  R917      -4.4399318099021912e-01
    z[2,1,2]  R918      3.3908709883689880e-01
    z[2,1,2]  R919      5.7380594313144684e-02
    z[2,1,2]  R920      3.3685940504074097e-01
    z[2,1,2]  R921      2.5801190733909607e-01
    z[2,1,2]  R922      -4.4733984395861626e-03
    z[2,1,2]  R923      -2.9572960734367371e-01
    z[2,1,2]  R924      -5.0286841392517090e-01
    z[2,1,2]  R925      7.3213323950767517e-02
    z[2,1,2]  R926      8.4472872316837311e-02
    z[2,1,2]  R927      -4.3464282155036926e-01
    z[2,1,2]  R928      -2.4279408156871796e-01
    z[2,1,2]  R929      -1.1018589884042740e-01
    z[2,1,2]  R930      -4.4181886315345764e-01
    z[2,1,2]  R931      -2.2919611632823944e-01
    z[2,1,2]  R932      -3.0812227725982666e-01
    z[2,1,2]  R933      -5.5857181549072266e-01
    z[2,1,2]  R934      -2.5917384028434753e-01
    z[2,1,2]  R935      2.4740447103977203e-01
    z[2,1,2]  R936      4.0581369400024414e-01
    z[2,1,2]  R937      -3.3495220541954041e-01
    z[2,1,2]  R938      -1.5745951235294342e-01
    z[2,1,2]  R939      2.1437798440456390e-01
    z[2,1,2]  R940      2.3800905793905258e-02
    z[2,1,2]  R941      -1.0439261794090271e-01
    z[2,1,2]  R942      5.1642164587974548e-02
    z[2,1,2]  R943      -7.0118896663188934e-02
    z[2,1,2]  R944      -1.0057786852121353e-01
    z[2,1,2]  R945      3.1586521863937378e-01
    z[2,1,2]  R946      0.470030277967453
    z[2,1,2]  R947      4.2068770527839661e-01
    z[2,1,2]  R948      3.3026865124702454e-01
    z[2,1,2]  R949      -2.4304631352424622e-01
    z[2,1,2]  R950      -6.7676077596843243e-03
    z[2,1,2]  R951      2.8672695159912109e-01
    z[2,1,2]  R952      -0.595943033695221
    z[2,1,2]  R953      1.6902524232864380e-01
    z[2,1,2]  R954      1.3917480409145355e-01
    z[2,1,2]  R955      2.8864562511444092e-01
    z[2,1,2]  R956      -2.4658817052841187e-01
    z[2,1,2]  R957      -1.4873377978801727e-01
    z[2,1,2]  R958      -6.7196351289749146e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R811      -1
    z[2,1,3]  R812      1
    z[2,1,3]  R819      2.5789457559585571e-01
    z[2,1,3]  R820      7.6679818332195282e-02
    z[2,1,3]  R821      7.4222676455974579e-02
    z[2,1,3]  R822      6.7925274372100830e-02
    z[2,1,3]  R823      4.2619869112968445e-02
    z[2,1,3]  R824      1.5018087625503540e-01
    z[2,1,3]  R825      -2.2287322208285332e-02
    z[2,1,3]  R826      1.7334936559200287e-01
    z[2,1,3]  R827      1.5530005097389221e-01
    z[2,1,3]  R828      0.0453343540430069
    z[2,1,3]  R829      6.0690528154373169e-01
    z[2,1,3]  R830      5.7045966386795044e-01
    z[2,1,3]  R831      5.9706658124923706e-01
    z[2,1,3]  R832      6.5926498174667358e-01
    z[2,1,3]  R833      5.5603188276290894e-01
    z[2,1,3]  R834      5.6152331829071045e-01
    z[2,1,3]  R835      6.3624918460845947e-01
    z[2,1,3]  R836      4.3104144930839539e-01
    z[2,1,3]  R837      -1.4310272037982941e-01
    z[2,1,3]  R838      3.2803124189376831e-01
    z[2,1,3]  R839      6.1675232648849487e-01
    z[2,1,3]  R840      4.8381385207176208e-01
    z[2,1,3]  R841      1.1437595635652542e-01
    z[2,1,3]  R842      4.5385140925645828e-02
    z[2,1,3]  R843      -4.7429639101028442e-01
    z[2,1,3]  R844      -1.3199462555348873e-02
    z[2,1,3]  R845      2.3878661915659904e-02
    z[2,1,3]  R846      -1.5798424184322357e-01
    z[2,1,3]  R847      -1.9470445811748505e-01
    z[2,1,3]  R848      2.4173672497272491e-01
    z[2,1,3]  R849      6.5899646282196045e-01
    z[2,1,3]  R850      7.6095026731491089e-01
    z[2,1,3]  R851      -7.1903415024280548e-02
    z[2,1,3]  R852      7.1365468204021454e-02
    z[2,1,3]  R853      -2.8981423377990723e-01
    z[2,1,3]  R854      3.6298626661300659e-01
    z[2,1,3]  R855      1.3017773628234863e-01
    z[2,1,3]  R856      -1.4988839626312256e-01
    z[2,1,3]  R857      -3.9614096283912659e-01
    z[2,1,3]  R858      -3.0419471859931946e-01
    z[2,1,3]  R859      -2.1315976977348328e-01
    z[2,1,3]  R860      -2.4674201011657715e-01
    z[2,1,3]  R861      6.0045200586318970e-01
    z[2,1,3]  R862      0.831079363822937
    z[2,1,3]  R863      2.4031335115432739e-01
    z[2,1,3]  R864      1.3446410000324249e-01
    z[2,1,3]  R865      1.8834297358989716e-01
    z[2,1,3]  R866      -4.5580846071243286e-01
    z[2,1,3]  R867      -4.4311785697937012e-01
    z[2,1,3]  R868      3.0654057860374451e-01
    z[2,1,3]  R869      -3.5950881242752075e-01
    z[2,1,3]  R870      4.5377832651138306e-01
    z[2,1,3]  R871      1.6288067400455475e-01
    z[2,1,3]  R872      7.8887414932250977e-01
    z[2,1,3]  R873      6.0306102037429810e-01
    z[2,1,3]  R874      2.2944065928459167e-01
    z[2,1,3]  R875      1.3756365515291691e-02
    z[2,1,3]  R876      1.4490705728530884e-01
    z[2,1,3]  R877      9.3097344040870667e-02
    z[2,1,3]  R878      -8.0060526728630066e-02
    z[2,1,3]  R879      7.7907508611679077e-01
    z[2,1,3]  R880      7.3133997619152069e-02
    z[2,1,3]  R881      7.1731686592102051e-01
    z[2,1,3]  R882      -1.1281068623065948e-01
    z[2,1,3]  R883      4.0450257062911987e-01
    z[2,1,3]  R884      0.00385760678909719
    z[2,1,3]  R885      -8.1982992589473724e-02
    z[2,1,3]  R886      1.7649991810321808e-01
    z[2,1,3]  R887      -2.6585987210273743e-01
    z[2,1,3]  R888      -2.9219236969947815e-01
    z[2,1,3]  R889      4.7909659147262573e-01
    z[2,1,3]  R890      6.0675078630447388e-01
    z[2,1,3]  R891      7.6968587934970856e-02
    z[2,1,3]  R892      5.7475709915161133e-01
    z[2,1,3]  R893      -1.0565434396266937e-01
    z[2,1,3]  R894      -7.3891326785087585e-02
    z[2,1,3]  R895      4.7077399492263794e-01
    z[2,1,3]  R896      3.1705811619758606e-01
    z[2,1,3]  R897      -3.5898125171661377e-01
    z[2,1,3]  R898      -4.4451120495796204e-01
    z[2,1,3]  R899      1.5172217041254044e-02
    z[2,1,3]  R900      6.6756260395050049e-01
    z[2,1,3]  R901      4.9172133207321167e-01
    z[2,1,3]  R902      1.4260038733482361e-01
    z[2,1,3]  R903      -4.7486531734466553e-01
    z[2,1,3]  R904      -3.3216324448585510e-01
    z[2,1,3]  R905      -2.8205469250679016e-01
    z[2,1,3]  R906      -5.6749057024717331e-02
    z[2,1,3]  R907      -1.0599813610315323e-01
    z[2,1,3]  R908      -1.9939118623733521e-01
    z[2,1,3]  R909      3.1341338157653809e-01
    z[2,1,3]  R910      1.8908197060227394e-02
    z[2,1,3]  R911      -2.8964955708943307e-04
    z[2,1,3]  R912      3.0754616856575012e-01
    z[2,1,3]  R913      3.8061305880546570e-02
    z[2,1,3]  R914      -3.1138685345649719e-01
    z[2,1,3]  R915      -4.8708185553550720e-01
    z[2,1,3]  R916      0.396223783493042
    z[2,1,3]  R917      3.7728673219680786e-01
    z[2,1,3]  R918      2.6664876937866211e-01
    z[2,1,3]  R919      1.9758765399456024e-01
    z[2,1,3]  R920      -0.316006600856781
    z[2,1,3]  R921      1.4382773637771606e-01
    z[2,1,3]  R922      -1.5714384615421295e-02
    z[2,1,3]  R923      2.4181540310382843e-01
    z[2,1,3]  R924      3.9540793746709824e-02
    z[2,1,3]  R925      -3.6043757200241089e-01
    z[2,1,3]  R926      2.8433763980865479e-01
    z[2,1,3]  R927      5.7649207115173340e-01
    z[2,1,3]  R928      6.8747989833354950e-02
    z[2,1,3]  R929      7.4214011430740356e-01
    z[2,1,3]  R930      0.188423752784729
    z[2,1,3]  R931      6.4205802977085114e-02
    z[2,1,3]  R932      3.9703199267387390e-01
    z[2,1,3]  R933      2.2820882499217987e-01
    z[2,1,3]  R934      -3.6426779627799988e-01
    z[2,1,3]  R935      1.6558444499969482e-01
    z[2,1,3]  R936      -1.1350209265947342e-01
    z[2,1,3]  R937      1.5309593081474304e-01
    z[2,1,3]  R938      3.5759216547012329e-01
    z[2,1,3]  R939      -3.8059153594076633e-03
    z[2,1,3]  R940      5.3418916463851929e-01
    z[2,1,3]  R941      -1.7636317014694214e-01
    z[2,1,3]  R942      8.4341269731521606e-01
    z[2,1,3]  R943      -1.9268985092639923e-01
    z[2,1,3]  R944      -7.5990550220012665e-02
    z[2,1,3]  R945      2.1354450285434723e-01
    z[2,1,3]  R946      8.6045213043689728e-02
    z[2,1,3]  R947      2.6764717698097229e-01
    z[2,1,3]  R948      1.8788765370845795e-01
    z[2,1,3]  R949      3.0778220295906067e-01
    z[2,1,3]  R950      5.2945107221603394e-01
    z[2,1,3]  R951      0.535443902015686
    z[2,1,3]  R952      2.5708773732185364e-01
    z[2,1,3]  R953      2.3309373855590820e-01
    z[2,1,3]  R954      2.1342009305953979e-01
    z[2,1,3]  R955      -2.1970469970256090e-03
    z[2,1,3]  R956      3.6637461185455322e-01
    z[2,1,3]  R957      -3.9038904011249542e-02
    z[2,1,3]  R958      2.3746024072170258e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R813      -1
    z[2,1,4]  R814      1
    z[2,1,4]  R819      -1.1496312171220779e-01
    z[2,1,4]  R820      6.1036888509988785e-02
    z[2,1,4]  R821      1.1571945995092392e-01
    z[2,1,4]  R822      -3.8888859748840332e-01
    z[2,1,4]  R823      -1.1638686805963516e-01
    z[2,1,4]  R824      -2.9812756180763245e-01
    z[2,1,4]  R825      -1.9319224357604980e-01
    z[2,1,4]  R826      1.6015812754631042e-01
    z[2,1,4]  R827      4.2423516511917114e-01
    z[2,1,4]  R828      -1.7063283594325185e-03
    z[2,1,4]  R829      -3.7976670265197754e-01
    z[2,1,4]  R830      -5.4631937295198441e-02
    z[2,1,4]  R831      -4.7857353091239929e-01
    z[2,1,4]  R832      1.5906213223934174e-01
    z[2,1,4]  R833      1.1276460252702236e-02
    z[2,1,4]  R834      5.0584155321121216e-01
    z[2,1,4]  R835      2.3941858112812042e-01
    z[2,1,4]  R836      -0.562581479549408
    z[2,1,4]  R837      8.6790435016155243e-02
    z[2,1,4]  R838      -1.2445009499788284e-01
    z[2,1,4]  R839      4.0344062447547913e-01
    z[2,1,4]  R840      -2.3010616004467010e-01
    z[2,1,4]  R841      -2.1427439153194427e-01
    z[2,1,4]  R842      -5.6533205509185791e-01
    z[2,1,4]  R843      -1.5597687661647797e-01
    z[2,1,4]  R844      -4.6064171195030212e-01
    z[2,1,4]  R845      -6.3801310956478119e-02
    z[2,1,4]  R846      5.2818089723587036e-01
    z[2,1,4]  R847      4.9443128705024719e-01
    z[2,1,4]  R848      -2.1657621860504150e-01
    z[2,1,4]  R849      -1.7721369862556458e-02
    z[2,1,4]  R850      3.4907300025224686e-02
    z[2,1,4]  R851      -1.4428691565990448e-01
    z[2,1,4]  R852      5.3972166031599045e-02
    z[2,1,4]  R853      3.9959940314292908e-01
    z[2,1,4]  R854      -4.4225663878023624e-03
    z[2,1,4]  R855      5.6520360708236694e-01
    z[2,1,4]  R856      2.9839816689491272e-01
    z[2,1,4]  R857      -1.2828929722309113e-01
    z[2,1,4]  R858      2.1192553639411926e-01
    z[2,1,4]  R859      8.9194908738136292e-02
    z[2,1,4]  R860      3.6870828270912170e-01
    z[2,1,4]  R861      -3.1754696369171143e-01
    z[2,1,4]  R862      2.1599155664443970e-01
    z[2,1,4]  R863      3.5281282663345337e-01
    z[2,1,4]  R864      -0.0717427060008049
    z[2,1,4]  R865      1.4988392591476440e-01
    z[2,1,4]  R866      1.9288735091686249e-01
    z[2,1,4]  R867      -3.0036326497793198e-02
    z[2,1,4]  R868      -2.2175274789333344e-02
    z[2,1,4]  R869      -5.9873346239328384e-02
    z[2,1,4]  R870      1.8889187276363373e-01
    z[2,1,4]  R871      -2.0365279912948608e-01
    z[2,1,4]  R872      -5.0281536579132080e-01
    z[2,1,4]  R873      -7.1040540933609009e-02
    z[2,1,4]  R874      7.4606128036975861e-02
    z[2,1,4]  R875      2.8247093781828880e-02
    z[2,1,4]  R876      8.0307433381676674e-04
    z[2,1,4]  R877      -8.1252768635749817e-02
    z[2,1,4]  R878      -6.5929013490676880e-01
    z[2,1,4]  R879      -3.4355142712593079e-01
    z[2,1,4]  R880      1.5855866670608521e-01
    z[2,1,4]  R881      4.9937221407890320e-01
    z[2,1,4]  R882      2.7032768726348877e-01
    z[2,1,4]  R883      9.5205254852771759e-02
    z[2,1,4]  R884      2.9664269089698792e-01
    z[2,1,4]  R885      -3.3074134588241577e-01
    z[2,1,4]  R886      -3.5192474722862244e-01
    z[2,1,4]  R887      -2.4802875518798828e-01
    z[2,1,4]  R888      -1.7932142317295074e-01
    z[2,1,4]  R889      -1.3013717532157898e-01
    z[2,1,4]  R890      -2.1842719614505768e-01
    z[2,1,4]  R891      -3.3131629228591919e-01
    z[2,1,4]  R892      3.6168730258941650e-01
    z[2,1,4]  R893      7.0028595626354218e-02
    z[2,1,4]  R894      3.1607393175363541e-02
    z[2,1,4]  R895      -3.6443449556827545e-02
    z[2,1,4]  R896      -7.0717319846153259e-02
    z[2,1,4]  R897      -8.0152988433837891e-02
    z[2,1,4]  R898      -9.5381431281566620e-02
    z[2,1,4]  R899      -8.0028679221868515e-03
    z[2,1,4]  R900      -4.6683689579367638e-03
    z[2,1,4]  R901      2.3104159533977509e-01
    z[2,1,4]  R902      -4.9141305498778820e-04
    z[2,1,4]  R903      2.8214901685714722e-01
    z[2,1,4]  R904      1.9687581062316895e-01
    z[2,1,4]  R905      6.2029594182968140e-01
    z[2,1,4]  R906      6.0424196720123291e-01
    z[2,1,4]  R907      -3.1634208559989929e-01
    z[2,1,4]  R908      6.7752408981323242e-01
    z[2,1,4]  R909      1.1300813406705856e-01
    z[2,1,4]  R910      -3.8642933964729309e-01
    z[2,1,4]  R911      -9.0079814195632935e-02
    z[2,1,4]  R912      8.8150732219219208e-02
    z[2,1,4]  R913      -4.5742020010948181e-01
    z[2,1,4]  R914      1.4216986298561096e-01
    z[2,1,4]  R915      -2.6787242293357849e-01
    z[2,1,4]  R916      2.8083220124244690e-01
    z[2,1,4]  R917      -2.5144872069358826e-01
    z[2,1,4]  R918      -4.9075558781623840e-01
    z[2,1,4]  R919      -3.1574136018753052e-01
    z[2,1,4]  R920      2.3854206502437592e-01
    z[2,1,4]  R921      -3.1173032522201538e-01
    z[2,1,4]  R922      -5.2692997269332409e-03
    z[2,1,4]  R923      4.7481562942266464e-02
    z[2,1,4]  R924      3.9055937528610229e-01
    z[2,1,4]  R925      4.8122027516365051e-01
    z[2,1,4]  R926      2.7622234076261520e-02
    z[2,1,4]  R927      -2.9486179351806641e-01
    z[2,1,4]  R928      5.7679307460784912e-01
    z[2,1,4]  R929      -3.2303687930107117e-01
    z[2,1,4]  R930      1.0006729513406754e-01
    z[2,1,4]  R931      5.4100728034973145e-01
    z[2,1,4]  R932      -1.3723669946193695e-01
    z[2,1,4]  R933      -1.0526290535926819e-01
    z[2,1,4]  R934      -3.9644420146942139e-02
    z[2,1,4]  R935      4.3470472097396851e-02
    z[2,1,4]  R936      -5.1383804529905319e-02
    z[2,1,4]  R937      6.0614768415689468e-02
    z[2,1,4]  R938      3.7498101592063904e-01
    z[2,1,4]  R939      1.7336109280586243e-01
    z[2,1,4]  R940      1.0989484935998917e-01
    z[2,1,4]  R941      5.6798119097948074e-02
    z[2,1,4]  R942      -2.0531460642814636e-01
    z[2,1,4]  R943      -3.3285968005657196e-02
    z[2,1,4]  R944      6.1925571411848068e-02
    z[2,1,4]  R945      4.8588532209396362e-01
    z[2,1,4]  R946      -1.5737848356366158e-02
    z[2,1,4]  R947      2.6537817716598511e-01
    z[2,1,4]  R948      3.6819440126419067e-01
    z[2,1,4]  R949      -0.259318470954895
    z[2,1,4]  R950      -2.8912758827209473e-01
    z[2,1,4]  R951      -1.5906599164009094e-01
    z[2,1,4]  R952      1.1754310876131058e-01
    z[2,1,4]  R953      -3.7735603749752045e-02
    z[2,1,4]  R954      7.8367955982685089e-02
    z[2,1,4]  R955      2.9110535979270935e-01
    z[2,1,4]  R956      3.1753537058830261e-01
    z[2,1,4]  R957      0.500487744808197
    z[2,1,4]  R958      2.1694320440292358e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R815      -1
    z[2,1,5]  R816      1
    z[2,1,5]  R819      0.0596165657043457
    z[2,1,5]  R820      -1.5421052277088165e-01
    z[2,1,5]  R821      2.5916749238967896e-01
    z[2,1,5]  R822      3.5540476441383362e-02
    z[2,1,5]  R823      2.4593852460384369e-01
    z[2,1,5]  R824      2.6339060068130493e-01
    z[2,1,5]  R825      -3.1690327450633049e-03
    z[2,1,5]  R826      -2.6576307415962219e-01
    z[2,1,5]  R827      7.5584337115287781e-02
    z[2,1,5]  R828      -1.3800999522209167e-01
    z[2,1,5]  R829      -2.3829996585845947e-01
    z[2,1,5]  R830      -4.3946501612663269e-01
    z[2,1,5]  R831      -3.5648146271705627e-01
    z[2,1,5]  R832      -4.4333106279373169e-01
    z[2,1,5]  R833      -1.6065049916505814e-02
    z[2,1,5]  R834      1.9907447695732117e-01
    z[2,1,5]  R835      1.5110961161553860e-02
    z[2,1,5]  R836      4.7820255160331726e-01
    z[2,1,5]  R837      3.8310371339321136e-02
    z[2,1,5]  R838      8.0996805429458618e-01
    z[2,1,5]  R839      -1.6127489507198334e-01
    z[2,1,5]  R840      0.690273106098175
    z[2,1,5]  R841      -3.0313533544540405e-01
    z[2,1,5]  R842      7.4939350597560406e-03
    z[2,1,5]  R843      0.0902993455529213
    z[2,1,5]  R844      -4.8316949605941772e-01
    z[2,1,5]  R845      1.0509271919727325e-01
    z[2,1,5]  R846      -1.3863454759120941e-01
    z[2,1,5]  R847      -5.6824021041393280e-02
    z[2,1,5]  R848      2.8457471728324890e-01
    z[2,1,5]  R849      -7.8652210533618927e-02
    z[2,1,5]  R850      1.3941408693790436e-01
    z[2,1,5]  R851      -5.6810826063156128e-01
    z[2,1,5]  R852      2.0864079892635345e-01
    z[2,1,5]  R853      3.5150960087776184e-01
    z[2,1,5]  R854      3.6750671267509460e-01
    z[2,1,5]  R855      8.7569728493690491e-02
    z[2,1,5]  R856      5.7715136557817459e-02
    z[2,1,5]  R857      2.7905693650245667e-01
    z[2,1,5]  R858      -3.2278639078140259e-01
    z[2,1,5]  R859      2.1576821804046631e-01
    z[2,1,5]  R860      1.7159767448902130e-01
    z[2,1,5]  R861      4.1267678141593933e-01
    z[2,1,5]  R862      -1.2315607070922852e-01
    z[2,1,5]  R863      -7.2828345000743866e-02
    z[2,1,5]  R864      1.3304447755217552e-02
    z[2,1,5]  R865      3.5721620917320251e-01
    z[2,1,5]  R866      -5.7846039533615112e-01
    z[2,1,5]  R867      -5.3011399507522583e-01
    z[2,1,5]  R868      2.8076618909835815e-01
    z[2,1,5]  R869      -2.3221983015537262e-01
    z[2,1,5]  R870      1.2673947215080261e-01
    z[2,1,5]  R871      -2.8106454014778137e-01
    z[2,1,5]  R872      1.4398138225078583e-01
    z[2,1,5]  R873      -2.9013365507125854e-01
    z[2,1,5]  R874      1.1404684931039810e-01
    z[2,1,5]  R875      -0.0963074192404747
    z[2,1,5]  R876      -1.9495855271816254e-01
    z[2,1,5]  R877      2.8034153580665588e-01
    z[2,1,5]  R878      -0.323823481798172
    z[2,1,5]  R879      3.7357372045516968e-01
    z[2,1,5]  R880      -5.8438368141651154e-02
    z[2,1,5]  R881      -7.9122297465801239e-02
    z[2,1,5]  R882      -6.4036726951599121e-01
    z[2,1,5]  R883      -1.8583790957927704e-01
    z[2,1,5]  R884      -3.2547211647033691e-01
    z[2,1,5]  R885      -2.4672269821166992e-01
    z[2,1,5]  R886      -1.0942756384611130e-01
    z[2,1,5]  R887      8.1528417766094208e-02
    z[2,1,5]  R888      2.4342155456542969e-01
    z[2,1,5]  R889      -2.1648842096328735e-01
    z[2,1,5]  R890      -1.0613638907670975e-01
    z[2,1,5]  R891      -6.7212902009487152e-02
    z[2,1,5]  R892      2.4922121316194534e-02
    z[2,1,5]  R893      -3.5402163863182068e-01
    z[2,1,5]  R894      -2.4613919854164124e-01
    z[2,1,5]  R895      -1.1041836440563202e-01
    z[2,1,5]  R896      -0.289393812417984
    z[2,1,5]  R897      -1.6315674409270287e-02
    z[2,1,5]  R898      9.6302941441535950e-02
    z[2,1,5]  R899      -1.8625985085964203e-01
    z[2,1,5]  R900      1.9237220287322998e-01
    z[2,1,5]  R901      -2.5953933596611023e-01
    z[2,1,5]  R902      2.0789082348346710e-01
    z[2,1,5]  R903      2.5498500093817711e-02
    z[2,1,5]  R904      3.3535334467887878e-01
    z[2,1,5]  R905      -2.5545755028724670e-01
    z[2,1,5]  R906      -2.6062300801277161e-01
    z[2,1,5]  R907      -3.4602773189544678e-01
    z[2,1,5]  R908      8.0022260546684265e-02
    z[2,1,5]  R909      6.3202202320098877e-02
    z[2,1,5]  R910      -6.3467338681221008e-02
    z[2,1,5]  R911      4.1443473100662231e-01
    z[2,1,5]  R912      3.7782818078994751e-01
    z[2,1,5]  R913      0.377505898475647
    z[2,1,5]  R914      -2.6834335923194885e-01
    z[2,1,5]  R915      -1.7452286183834076e-01
    z[2,1,5]  R916      -0.137746199965477
    z[2,1,5]  R917      1.7691782116889954e-01
    z[2,1,5]  R918      1.9589868187904358e-01
    z[2,1,5]  R919      -2.4177654087543488e-01
    z[2,1,5]  R920      -1.7560409009456635e-01
    z[2,1,5]  R921      -3.9284974336624146e-02
    z[2,1,5]  R922      -6.4603704214096069e-01
    z[2,1,5]  R923      1.7294013500213623e-01
    z[2,1,5]  R924      4.0715911984443665e-01
    z[2,1,5]  R925      3.3415222167968750e-01
    z[2,1,5]  R926      5.5208194255828857e-01
    z[2,1,5]  R927      4.7968883067369461e-02
    z[2,1,5]  R928      3.6822766065597534e-01
    z[2,1,5]  R929      -6.7715913057327271e-02
    z[2,1,5]  R930      3.0593699216842651e-01
    z[2,1,5]  R931      3.3995765447616577e-01
    z[2,1,5]  R932      3.4642115235328674e-01
    z[2,1,5]  R933      1.9710119068622589e-01
    z[2,1,5]  R934      5.4594278335571289e-02
    z[2,1,5]  R935      -2.0859143137931824e-01
    z[2,1,5]  R936      -2.2770951036363840e-03
    z[2,1,5]  R937      -1.1156143993139267e-01
    z[2,1,5]  R938      1.8164552748203278e-01
    z[2,1,5]  R939      4.3474078178405762e-01
    z[2,1,5]  R940      -6.3863977789878845e-02
    z[2,1,5]  R941      2.6505815982818604e-01
    z[2,1,5]  R942      -7.5593672692775726e-02
    z[2,1,5]  R943      -1.3024614751338959e-01
    z[2,1,5]  R944      -2.6933519169688225e-02
    z[2,1,5]  R945      -1.9698639214038849e-01
    z[2,1,5]  R946      4.6172770857810974e-01
    z[2,1,5]  R947      2.6775002479553223e-01
    z[2,1,5]  R948      4.6697062253952026e-01
    z[2,1,5]  R949      2.8888288140296936e-01
    z[2,1,5]  R950      2.0357848703861237e-01
    z[2,1,5]  R951      2.0439730584621429e-01
    z[2,1,5]  R952      5.7083507999777794e-03
    z[2,1,5]  R953      -4.3179920315742493e-01
    z[2,1,5]  R954      4.1979452967643738e-01
    z[2,1,5]  R955      1.8119035661220551e-01
    z[2,1,5]  R956      2.1958269178867340e-01
    z[2,1,5]  R957      2.7326586842536926e-01
    z[2,1,5]  R958      2.7693191170692444e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R817      -1
    z[2,1,6]  R818      1
    z[2,1,6]  R819      -1.3391232490539551e-01
    z[2,1,6]  R820      -5.5602509528398514e-02
    z[2,1,6]  R821      9.5840133726596832e-02
    z[2,1,6]  R822      1.4374126493930817e-01
    z[2,1,6]  R823      -1.5773972868919373e-01
    z[2,1,6]  R824      0.0995691567659378
    z[2,1,6]  R825      -7.6256953179836273e-02
    z[2,1,6]  R826      1.4368730783462524e-01
    z[2,1,6]  R827      -1.5407225489616394e-01
    z[2,1,6]  R828      1.6710811853408813e-01
    z[2,1,6]  R829      2.9666331410408020e-01
    z[2,1,6]  R830      1.7016613855957985e-02
    z[2,1,6]  R831      -2.0249038934707642e-01
    z[2,1,6]  R832      -1.0928864032030106e-01
    z[2,1,6]  R833      6.4154869318008423e-01
    z[2,1,6]  R834      5.3281837701797485e-01
    z[2,1,6]  R835      3.0589789152145386e-01
    z[2,1,6]  R836      2.4263255298137665e-01
    z[2,1,6]  R837      -2.9404631257057190e-01
    z[2,1,6]  R838      2.7412512898445129e-01
    z[2,1,6]  R839      4.8868253827095032e-02
    z[2,1,6]  R840      8.0984615487977862e-04
    z[2,1,6]  R841      -1.7131294310092926e-01
    z[2,1,6]  R842      -7.9409822821617126e-02
    z[2,1,6]  R843      3.2485806941986084e-01
    z[2,1,6]  R844      8.6883746087551117e-02
    z[2,1,6]  R845      1.9362498819828033e-01
    z[2,1,6]  R846      3.8350574672222137e-02
    z[2,1,6]  R847      -0.0493636429309845
    z[2,1,6]  R848      9.3438185751438141e-02
    z[2,1,6]  R849      5.2796018123626709e-01
    z[2,1,6]  R850      -4.5082005858421326e-01
    z[2,1,6]  R851      -3.9235156774520874e-01
    z[2,1,6]  R852      -2.1485263109207153e-01
    z[2,1,6]  R853      1.0583304613828659e-01
    z[2,1,6]  R854      2.6076692342758179e-01
    z[2,1,6]  R855      0.101309634745121
    z[2,1,6]  R856      1.8745566904544830e-01
    z[2,1,6]  R857      6.6299118101596832e-02
    z[2,1,6]  R858      3.4264308214187622e-01
    z[2,1,6]  R859      3.6983732134103775e-03
    z[2,1,6]  R860      -3.6549825221300125e-02
    z[2,1,6]  R861      5.6970596313476562e-02
    z[2,1,6]  R862      -3.0264276266098022e-01
    z[2,1,6]  R863      1.8844233453273773e-01
    z[2,1,6]  R864      1.1336199194192886e-01
    z[2,1,6]  R865      -1.3753518462181091e-01
    z[2,1,6]  R866      2.8746657073497772e-02
    z[2,1,6]  R867      3.0018597841262817e-01
    z[2,1,6]  R868      -3.2065957784652710e-01
    z[2,1,6]  R869      3.5046026110649109e-01
    z[2,1,6]  R870      1.7457805573940277e-01
    z[2,1,6]  R871      6.3427664339542389e-02
    z[2,1,6]  R872      -1.4630000293254852e-01
    z[2,1,6]  R873      -3.6590874195098877e-01
    z[2,1,6]  R874      2.3407968692481518e-03
    z[2,1,6]  R875      1.4083732664585114e-01
    z[2,1,6]  R876      -4.5543056726455688e-01
    z[2,1,6]  R877      3.6189281940460205e-01
    z[2,1,6]  R878      5.9667207300662994e-02
    z[2,1,6]  R879      3.9056394249200821e-02
    z[2,1,6]  R880      -3.5774940252304077e-01
    z[2,1,6]  R881      6.4626209437847137e-02
    z[2,1,6]  R882      -5.1362957805395126e-02
    z[2,1,6]  R883      -8.9024573564529419e-02
    z[2,1,6]  R884      -3.5536146163940430e-01
    z[2,1,6]  R885      -2.2796842455863953e-01
    z[2,1,6]  R886      -2.1361030638217926e-01
    z[2,1,6]  R887      1.4386756718158722e-01
    z[2,1,6]  R888      -2.4325957521796227e-02
    z[2,1,6]  R889      -2.0830747485160828e-01
    z[2,1,6]  R890      -4.2313057184219360e-01
    z[2,1,6]  R891      2.8809100389480591e-01
    z[2,1,6]  R892      -2.6862871646881104e-01
    z[2,1,6]  R893      -1.3921138644218445e-01
    z[2,1,6]  R894      -2.2763611376285553e-01
    z[2,1,6]  R895      -1.7594610154628754e-01
    z[2,1,6]  R896      -3.2816660404205322e-01
    z[2,1,6]  R897      1.3124649226665497e-01
    z[2,1,6]  R898      -2.2728709876537323e-01
    z[2,1,6]  R899      -8.9128427207469940e-02
    z[2,1,6]  R900      -1.5429088473320007e-01
    z[2,1,6]  R901      -1.7627786099910736e-01
    z[2,1,6]  R902      -3.0590042471885681e-01
    z[2,1,6]  R903      1.0293000936508179e-01
    z[2,1,6]  R904      2.2025278210639954e-01
    z[2,1,6]  R905      2.3513735830783844e-01
    z[2,1,6]  R906      4.3343797326087952e-02
    z[2,1,6]  R907      -5.9962904453277588e-01
    z[2,1,6]  R908      1.0144189745187759e-01
    z[2,1,6]  R909      1.3355225324630737e-01
    z[2,1,6]  R910      1.5129385888576508e-01
    z[2,1,6]  R911      3.7660121917724609e-01
    z[2,1,6]  R912      -3.2919198274612427e-01
    z[2,1,6]  R913      -2.8817105293273926e-01
    z[2,1,6]  R914      -1.7816795408725739e-01
    z[2,1,6]  R915      -4.7906059026718140e-01
    z[2,1,6]  R916      -5.4024152457714081e-02
    z[2,1,6]  R917      3.6554688215255737e-01
    z[2,1,6]  R918      2.5745324790477753e-02
    z[2,1,6]  R919      5.6037104129791260e-01
    z[2,1,6]  R920      3.3051070570945740e-01
    z[2,1,6]  R921      -0.515571653842926
    z[2,1,6]  R922      3.0234414339065552e-01
    z[2,1,6]  R923      -0.762999951839447
    z[2,1,6]  R924      -4.1231209039688110e-01
    z[2,1,6]  R925      -2.6262232661247253e-01
    z[2,1,6]  R926      4.4749930500984192e-01
    z[2,1,6]  R927      -1.6747350990772247e-01
    z[2,1,6]  R928      -2.0090888440608978e-01
    z[2,1,6]  R929      -2.9980879276990891e-02
    z[2,1,6]  R930      -3.7872657179832458e-01
    z[2,1,6]  R931      -8.8856205344200134e-02
    z[2,1,6]  R932      -4.2010641098022461e-01
    z[2,1,6]  R933      3.7908756732940674e-01
    z[2,1,6]  R934      2.2304451093077660e-02
    z[2,1,6]  R935      2.2783493995666504e-01
    z[2,1,6]  R936      3.5991007089614868e-01
    z[2,1,6]  R937      -1.1902172863483429e-01
    z[2,1,6]  R938      -2.2993825376033783e-01
    z[2,1,6]  R939      1.2702395021915436e-01
    z[2,1,6]  R940      5.4119038581848145e-01
    z[2,1,6]  R941      2.1290307864546776e-02
    z[2,1,6]  R942      -3.9817806333303452e-02
    z[2,1,6]  R943      -2.4602632224559784e-01
    z[2,1,6]  R944      0.54817795753479
    z[2,1,6]  R945      -2.8034329414367676e-01
    z[2,1,6]  R946      -2.8477391600608826e-01
    z[2,1,6]  R947      -3.1071197986602783e-01
    z[2,1,6]  R948      -7.5204953551292419e-02
    z[2,1,6]  R949      6.1281401664018631e-02
    z[2,1,6]  R950      -3.4957808256149292e-01
    z[2,1,6]  R951      4.6811914443969727e-01
    z[2,1,6]  R952      -1.7486895620822906e-01
    z[2,1,6]  R953      3.3465558290481567e-01
    z[2,1,6]  R954      1.5518032014369965e-01
    z[2,1,6]  R955      7.1556642651557922e-02
    z[2,1,6]  R956      1.0816410183906555e-02
    z[2,1,6]  R957      4.1708725690841675e-01
    z[2,1,6]  R958      2.3318928480148315e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R959      -1
    z[2,3,0]  R960      1
    z[2,3,0]  R973      -3.9254170656204224e-01
    z[2,3,0]  R974      -2.3913398385047913e-01
    z[2,3,0]  R975      -4.2164230346679688e-01
    z[2,3,0]  R976      -4.6761247515678406e-01
    z[2,3,0]  R977      -6.8008285760879517e-01
    z[2,3,0]  R978      -6.4544725418090820e-01
    z[2,3,0]  R979      -9.2244094610214233e-01
    z[2,3,0]  R980      -4.7562113404273987e-01
    z[2,3,0]  R981      -5.7857674360275269e-01
    z[2,3,0]  R982      -0.748253583908081
    z[2,3,0]  R983      5.2099150419235229e-01
    z[2,3,0]  R984      5.5208230018615723e-01
    z[2,3,0]  R985      4.7966101765632629e-01
    z[2,3,0]  R986      5.6979340314865112e-01
    z[2,3,0]  R987      0.41551673412323
    z[2,3,0]  R988      3.0027130246162415e-01
    z[2,3,0]  R989      5.6916791200637817e-01
    z[2,3,0]  R990      3.7578943371772766e-01
    z[2,3,0]  R991      2.2402296960353851e-01
    z[2,3,0]  R992      3.7969928979873657e-01
    z[2,3,0]  R993      2.6223802566528320e-01
    z[2,3,0]  R994      3.6775204539299011e-01
    z[2,3,0]  R995      -2.1203437820076942e-02
    z[2,3,0]  R996      -1.3206343166530132e-02
    z[2,3,0]  R997      2.8164750337600708e-01
    z[2,3,0]  R998      -8.9676812291145325e-02
    z[2,3,0]  R999      6.2856757640838623e-01
    z[2,3,0]  R1000     3.4075993299484253e-01
    z[2,3,0]  R1001     -1.3045547902584076e-01
    z[2,3,0]  R1002     -3.4689339995384216e-01
    z[2,3,0]  R1003     3.5286378860473633e-01
    z[2,3,0]  R1004     3.8080233335494995e-01
    z[2,3,0]  R1005     -0.586037814617157
    z[2,3,0]  R1006     -0.0869353786110878
    z[2,3,0]  R1007     -7.7154916524887085e-01
    z[2,3,0]  R1008     5.7940429449081421e-01
    z[2,3,0]  R1009     -6.0262113809585571e-01
    z[2,3,0]  R1010     -9.5427431166172028e-02
    z[2,3,0]  R1011     -3.0859872698783875e-01
    z[2,3,0]  R1012     -5.2074217796325684e-01
    z[2,3,0]  R1013     -9.4161635637283325e-01
    z[2,3,0]  R1014     -8.1056392192840576e-01
    z[2,3,0]  R1015     3.9836764335632324e-01
    z[2,3,0]  R1016     7.0478290319442749e-02
    z[2,3,0]  R1017     -5.9895825386047363e-01
    z[2,3,0]  R1018     2.6351484656333923e-01
    z[2,3,0]  R1019     -1.5788662433624268e-01
    z[2,3,0]  R1020     -6.1514323949813843e-01
    z[2,3,0]  R1021     -3.8206470012664795e-01
    z[2,3,0]  R1022     -1.1098635941743851e-01
    z[2,3,0]  R1023     -6.7380934953689575e-01
    z[2,3,0]  R1024     0.543727457523346
    z[2,3,0]  R1025     -7.9898262023925781e-01
    z[2,3,0]  R1026     7.9587094485759735e-02
    z[2,3,0]  R1027     -5.8735519647598267e-01
    z[2,3,0]  R1028     -1.9871200621128082e-01
    z[2,3,0]  R1029     -5.9651982784271240e-01
    z[2,3,0]  R1030     1.5138798952102661e-01
    z[2,3,0]  R1031     -1.5813054144382477e-01
    z[2,3,0]  R1032     -4.7670900821685791e-01
    z[2,3,0]  R1033     3.3887746930122375e-01
    z[2,3,0]  R1034     -8.8683640956878662e-01
    z[2,3,0]  R1035     3.9698880910873413e-01
    z[2,3,0]  R1036     -5.4121297597885132e-01
    z[2,3,0]  R1037     2.5448048114776611e-01
    z[2,3,0]  R1038     1.7015197873115540e-01
    z[2,3,0]  R1039     -3.7779429554939270e-01
    z[2,3,0]  R1040     -4.4674339890480042e-01
    z[2,3,0]  R1041     -3.5545790195465088e-01
    z[2,3,0]  R1042     6.5151005983352661e-01
    z[2,3,0]  R1043     -6.8009203672409058e-01
    z[2,3,0]  R1044     3.2066974788904190e-02
    z[2,3,0]  R1045     -7.2874939441680908e-01
    z[2,3,0]  R1046     -5.9182637929916382e-01
    z[2,3,0]  R1047     -2.6132553815841675e-01
    z[2,3,0]  R1048     2.8182464838027954e-01
    z[2,3,0]  R1049     2.1349306404590607e-01
    z[2,3,0]  R1050     -9.1540098190307617e-02
    z[2,3,0]  R1051     -5.4024338722229004e-02
    z[2,3,0]  R1052     3.6885675042867661e-02
    z[2,3,0]  R1053     -8.9066106081008911e-01
    z[2,3,0]  R1054     4.4937521219253540e-01
    z[2,3,0]  R1055     0.754943311214447
    z[2,3,0]  R1056     -5.8507156372070312e-01
    z[2,3,0]  R1057     2.8378924727439880e-01
    z[2,3,0]  R1058     7.8624807298183441e-02
    z[2,3,0]  R1059     1.2666773796081543e-01
    z[2,3,0]  R1060     9.6525497734546661e-02
    z[2,3,0]  R1061     -1.7874591052532196e-01
    z[2,3,0]  R1062     -1.5020088851451874e-01
    z[2,3,0]  R1063     -5.4492527246475220e-01
    z[2,3,0]  R1064     -2.1534349024295807e-01
    z[2,3,0]  R1065     -4.7673907876014709e-01
    z[2,3,0]  R1066     -9.1472655534744263e-01
    z[2,3,0]  R1067     -4.9899551272392273e-01
    z[2,3,0]  R1068     1.7937442660331726e-01
    z[2,3,0]  R1069     8.3233872428536415e-03
    z[2,3,0]  R1070     -1.1779731512069702e-01
    z[2,3,0]  R1071     7.5718045234680176e-02
    z[2,3,0]  R1072     4.3023101985454559e-02
    z[2,3,0]  R1073     2.5510627031326294e-01
    z[2,3,0]  R1074     0.611352801322937
    z[2,3,0]  R1075     6.4501678943634033e-01
    z[2,3,0]  R1076     5.7139158248901367e-01
    z[2,3,0]  R1077     5.8158326148986816e-01
    z[2,3,0]  R1078     3.6221036314964294e-01
    z[2,3,0]  R1079     2.8853756189346313e-01
    z[2,3,0]  R1080     3.1469497084617615e-01
    z[2,3,0]  R1081     2.6581883430480957e-01
    z[2,3,0]  R1082     5.8376115560531616e-01
    z[2,3,0]  R1083     3.7380585074424744e-01
    z[2,3,0]  R1084     4.8549342155456543e-01
    z[2,3,0]  R1085     6.9221824407577515e-01
    z[2,3,0]  R1086     2.0233023166656494e-01
    z[2,3,0]  R1087     1.2574322521686554e-01
    z[2,3,0]  R1088     2.5684067606925964e-01
    z[2,3,0]  R1089     1.1671365052461624e-01
    z[2,3,0]  R1090     2.3870217800140381e-01
    z[2,3,0]  R1091     1.5381184220314026e-01
    z[2,3,0]  R1092     5.1420134305953979e-01
    z[2,3,0]  R1093     2.2655582427978516e-01
    z[2,3,0]  R1094     0.283189594745636
    z[2,3,0]  R1095     2.7601400017738342e-01
    z[2,3,0]  R1096     3.5650694370269775e-01
    z[2,3,0]  R1097     2.8758205473423004e-02
    z[2,3,0]  R1098     2.2294494509696960e-01
    z[2,3,0]  R1099     2.8574812412261963e-01
    z[2,3,0]  R1100     -5.9725034981966019e-02
    z[2,3,0]  R1101     -0.0819258838891983
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R961      -1
    z[2,3,1]  R962      1
    z[2,3,1]  R973      8.6168175935745239e-01
    z[2,3,1]  R974      9.5194482803344727e-01
    z[2,3,1]  R975      8.3967870473861694e-01
    z[2,3,1]  R976      7.5791954994201660e-01
    z[2,3,1]  R977      6.5164351463317871e-01
    z[2,3,1]  R978      0.60193932056427
    z[2,3,1]  R979      1.8296839296817780e-01
    z[2,3,1]  R980      7.0275247097015381e-01
    z[2,3,1]  R981      6.4181548357009888e-01
    z[2,3,1]  R982      6.2443137168884277e-01
    z[2,3,1]  R983      -0.166351318359375
    z[2,3,1]  R984      1.9614227116107941e-01
    z[2,3,1]  R985      1.2256369739770889e-01
    z[2,3,1]  R986      -6.2041327357292175e-02
    z[2,3,1]  R987      -3.0906911939382553e-02
    z[2,3,1]  R988      1.1112090200185776e-01
    z[2,3,1]  R989      -3.3025091886520386e-01
    z[2,3,1]  R990      -2.3501524329185486e-01
    z[2,3,1]  R991      -8.1570070981979370e-01
    z[2,3,1]  R992      -1.1152768507599831e-02
    z[2,3,1]  R993      4.8224860429763794e-01
    z[2,3,1]  R994      2.8804332017898560e-01
    z[2,3,1]  R995      -0.904996395111084
    z[2,3,1]  R996      -8.0651009082794189e-01
    z[2,3,1]  R997      -7.4384588003158569e-01
    z[2,3,1]  R998      -6.9912791252136230e-01
    z[2,3,1]  R999      -7.4209755659103394e-01
    z[2,3,1]  R1000     -7.4391418695449829e-01
    z[2,3,1]  R1001     -8.3136105537414551e-01
    z[2,3,1]  R1002     -7.9074168205261230e-01
    z[2,3,1]  R1003     3.5440880060195923e-01
    z[2,3,1]  R1004     -1.8497738242149353e-01
    z[2,3,1]  R1005     3.6687543988227844e-01
    z[2,3,1]  R1006     -8.6033952236175537e-01
    z[2,3,1]  R1007     -0.104481041431427
    z[2,3,1]  R1008     5.4912644624710083e-01
    z[2,3,1]  R1009     -2.0457734167575836e-01
    z[2,3,1]  R1010     -8.8429284095764160e-01
    z[2,3,1]  R1011     -7.8451168537139893e-01
    z[2,3,1]  R1012     -0.317264199256897
    z[2,3,1]  R1013     0.0891835018992424
    z[2,3,1]  R1014     3.3691781759262085e-01
    z[2,3,1]  R1015     4.4969987869262695e-01
    z[2,3,1]  R1016     2.7287730574607849e-01
    z[2,3,1]  R1017     1.3377930968999863e-02
    z[2,3,1]  R1018     -9.3052148818969727e-01
    z[2,3,1]  R1019     -8.7759679555892944e-01
    z[2,3,1]  R1020     9.5067918300628662e-02
    z[2,3,1]  R1021     4.3363296985626221e-01
    z[2,3,1]  R1022     -8.2585883140563965e-01
    z[2,3,1]  R1023     2.8689932823181152e-01
    z[2,3,1]  R1024     5.7964378595352173e-01
    z[2,3,1]  R1025     3.8527809083461761e-02
    z[2,3,1]  R1026     -2.5478392839431763e-01
    z[2,3,1]  R1027     0.0353827103972435
    z[2,3,1]  R1028     -9.1124457120895386e-01
    z[2,3,1]  R1029     -0.662040114402771
    z[2,3,1]  R1030     -7.8357911109924316e-01
    z[2,3,1]  R1031     -7.6083678007125854e-01
    z[2,3,1]  R1032     -4.1661381721496582e-01
    z[2,3,1]  R1033     -1.3202227652072906e-02
    z[2,3,1]  R1034     2.2526440024375916e-01
    z[2,3,1]  R1035     -4.9321573227643967e-02
    z[2,3,1]  R1036     3.2392221689224243e-01
    z[2,3,1]  R1037     -8.1055295467376709e-01
    z[2,3,1]  R1038     -7.8756111860275269e-01
    z[2,3,1]  R1039     -7.8263121843338013e-01
    z[2,3,1]  R1040     -7.6649588346481323e-01
    z[2,3,1]  R1041     -3.5260787606239319e-01
    z[2,3,1]  R1042     6.2596333026885986e-01
    z[2,3,1]  R1043     3.2141822576522827e-01
    z[2,3,1]  R1044     3.8521626591682434e-01
    z[2,3,1]  R1045     -5.0963733345270157e-02
    z[2,3,1]  R1046     -2.4608006700873375e-02
    z[2,3,1]  R1047     -8.7529158592224121e-01
    z[2,3,1]  R1048     -8.6956137418746948e-01
    z[2,3,1]  R1049     -8.2586467266082764e-01
    z[2,3,1]  R1050     -8.3300560712814331e-01
    z[2,3,1]  R1051     -9.1836810111999512e-01
    z[2,3,1]  R1052     5.6905514001846313e-01
    z[2,3,1]  R1053     3.3987060189247131e-01
    z[2,3,1]  R1054     5.3938800096511841e-01
    z[2,3,1]  R1055     1.8245634436607361e-01
    z[2,3,1]  R1056     -5.8379560708999634e-01
    z[2,3,1]  R1057     -0.758469820022583
    z[2,3,1]  R1058     0.500398576259613
    z[2,3,1]  R1059     -4.0672817826271057e-01
    z[2,3,1]  R1060     -2.7699694037437439e-01
    z[2,3,1]  R1061     -1.3899168372154236e-01
    z[2,3,1]  R1062     -2.8170236945152283e-01
    z[2,3,1]  R1063     4.3278518319129944e-01
    z[2,3,1]  R1064     5.2865236997604370e-01
    z[2,3,1]  R1065     3.2280489802360535e-02
    z[2,3,1]  R1066     -1.0213023424148560e-01
    z[2,3,1]  R1067     3.5205683112144470e-01
    z[2,3,1]  R1068     0.0873582735657692
    z[2,3,1]  R1069     3.0650734901428223e-01
    z[2,3,1]  R1070     -1.1546940356492996e-01
    z[2,3,1]  R1071     -8.3069734275341034e-02
    z[2,3,1]  R1072     2.9835087060928345e-01
    z[2,3,1]  R1073     -0.0591592937707901
    z[2,3,1]  R1074     -6.5233409404754639e-02
    z[2,3,1]  R1075     -1.7246234416961670e-01
    z[2,3,1]  R1076     5.4489899426698685e-02
    z[2,3,1]  R1077     -7.5519219040870667e-02
    z[2,3,1]  R1078     -2.4127402901649475e-01
    z[2,3,1]  R1079     -6.4986400306224823e-02
    z[2,3,1]  R1080     6.6145914793014526e-01
    z[2,3,1]  R1081     -8.6502122879028320e-01
    z[2,3,1]  R1082     2.5387245416641235e-01
    z[2,3,1]  R1083     3.3545008301734924e-01
    z[2,3,1]  R1084     0.605156421661377
    z[2,3,1]  R1085     1.9629713892936707e-01
    z[2,3,1]  R1086     -0.922296404838562
    z[2,3,1]  R1087     -9.0870171785354614e-01
    z[2,3,1]  R1088     -9.0678805112838745e-01
    z[2,3,1]  R1089     -9.0038394927978516e-01
    z[2,3,1]  R1090     -8.7704312801361084e-01
    z[2,3,1]  R1091     -8.8701063394546509e-01
    z[2,3,1]  R1092     1.3998055458068848e-01
    z[2,3,1]  R1093     4.0884265303611755e-01
    z[2,3,1]  R1094     2.9602622613310814e-02
    z[2,3,1]  R1095     2.5092095136642456e-02
    z[2,3,1]  R1096     4.8419770598411560e-01
    z[2,3,1]  R1097     -0.950893223285675
    z[2,3,1]  R1098     -8.8206022977828979e-01
    z[2,3,1]  R1099     -8.9106363058090210e-01
    z[2,3,1]  R1100     -7.3857551813125610e-01
    z[2,3,1]  R1101     -6.0511809587478638e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R963      -1
    z[2,3,2]  R964      1
    z[2,3,2]  R973      -4.6933200210332870e-02
    z[2,3,2]  R974      -1.1756887659430504e-02
    z[2,3,2]  R975      0.148001566529274
    z[2,3,2]  R976      1.7065636813640594e-01
    z[2,3,2]  R977      -1.1008264124393463e-01
    z[2,3,2]  R978      1.7419527471065521e-01
    z[2,3,2]  R979      2.6829114556312561e-01
    z[2,3,2]  R980      3.6461880803108215e-01
    z[2,3,2]  R981      1.4063043892383575e-01
    z[2,3,2]  R982      -0.0342351458966732
    z[2,3,2]  R983      2.0866812765598297e-01
    z[2,3,2]  R984      3.6729472875595093e-01
    z[2,3,2]  R985      3.6069635301828384e-02
    z[2,3,2]  R986      -5.5398438125848770e-02
    z[2,3,2]  R987      3.2442143559455872e-01
    z[2,3,2]  R988      5.2716922014951706e-02
    z[2,3,2]  R989      -1.0509991645812988e-01
    z[2,3,2]  R990      1.1707766354084015e-01
    z[2,3,2]  R991      -4.1049256920814514e-01
    z[2,3,2]  R992      -3.7668108940124512e-02
    z[2,3,2]  R993      -3.5654169321060181e-01
    z[2,3,2]  R994      -0.135230153799057
    z[2,3,2]  R995      1.7250137403607368e-02
    z[2,3,2]  R996      -1.4609888195991516e-01
    z[2,3,2]  R997      -6.6297873854637146e-02
    z[2,3,2]  R998      2.2318531572818756e-01
    z[2,3,2]  R999      3.1908690929412842e-02
    z[2,3,2]  R1000     7.6484262943267822e-02
    z[2,3,2]  R1001     6.1499748378992081e-02
    z[2,3,2]  R1002     2.4359221756458282e-01
    z[2,3,2]  R1003     1.7425008118152618e-01
    z[2,3,2]  R1004     -1.3354432582855225e-01
    z[2,3,2]  R1005     -1.3887584209442139e-01
    z[2,3,2]  R1006     -3.9314043521881104e-01
    z[2,3,2]  R1007     1.2395108491182327e-01
    z[2,3,2]  R1008     1.6706761717796326e-01
    z[2,3,2]  R1009     4.9057373404502869e-01
    z[2,3,2]  R1010     2.4277816712856293e-01
    z[2,3,2]  R1011     -1.8345075845718384e-01
    z[2,3,2]  R1012     5.1877623796463013e-01
    z[2,3,2]  R1013     0.0737726092338562
    z[2,3,2]  R1014     4.3167144060134888e-02
    z[2,3,2]  R1015     6.4395293593406677e-02
    z[2,3,2]  R1016     2.7652397751808167e-01
    z[2,3,2]  R1017     6.4655095338821411e-01
    z[2,3,2]  R1018     1.6862362623214722e-01
    z[2,3,2]  R1019     -2.0928969606757164e-02
    z[2,3,2]  R1020     1.7930777370929718e-01
    z[2,3,2]  R1021     3.1241157650947571e-01
    z[2,3,2]  R1022     -1.7183783650398254e-01
    z[2,3,2]  R1023     3.9254274964332581e-01
    z[2,3,2]  R1024     2.8326365351676941e-01
    z[2,3,2]  R1025     4.5729362964630127e-01
    z[2,3,2]  R1026     1.0710256546735764e-01
    z[2,3,2]  R1027     2.5877770781517029e-01
    z[2,3,2]  R1028     2.4274586141109467e-01
    z[2,3,2]  R1029     4.1924878954887390e-01
    z[2,3,2]  R1030     -3.1090310215950012e-01
    z[2,3,2]  R1031     4.1387838125228882e-01
    z[2,3,2]  R1032     2.2290448844432831e-01
    z[2,3,2]  R1033     1.3754753768444061e-01
    z[2,3,2]  R1034     -2.9798170551657677e-02
    z[2,3,2]  R1035     -2.5615268945693970e-01
    z[2,3,2]  R1036     3.2194903492927551e-01
    z[2,3,2]  R1037     -0.251189261674881
    z[2,3,2]  R1038     -1.7484319210052490e-01
    z[2,3,2]  R1039     -1.2572652101516724e-01
    z[2,3,2]  R1040     1.7241321504116058e-02
    z[2,3,2]  R1041     7.6796674728393555e-01
    z[2,3,2]  R1042     -7.9537652432918549e-02
    z[2,3,2]  R1043     3.1214842200279236e-01
    z[2,3,2]  R1044     -4.9438709020614624e-01
    z[2,3,2]  R1045     0.512950599193573
    z[2,3,2]  R1046     3.3939656615257263e-01
    z[2,3,2]  R1047     6.9249749183654785e-02
    z[2,3,2]  R1048     -2.1348603069782257e-01
    z[2,3,2]  R1049     -0.0791369378566742
    z[2,3,2]  R1050     2.7444148436188698e-02
    z[2,3,2]  R1051     -2.9958806931972504e-02
    z[2,3,2]  R1052     -6.3811767101287842e-01
    z[2,3,2]  R1053     2.1972709894180298e-01
    z[2,3,2]  R1054     2.5459833443164825e-02
    z[2,3,2]  R1055     5.6263640522956848e-02
    z[2,3,2]  R1056     3.9968156814575195e-01
    z[2,3,2]  R1057     -1.6684535145759583e-01
    z[2,3,2]  R1058     -6.5829616785049438e-01
    z[2,3,2]  R1059     -4.8338127136230469e-01
    z[2,3,2]  R1060     -6.8979966640472412e-01
    z[2,3,2]  R1061     5.9844231605529785e-01
    z[2,3,2]  R1062     -6.1854153871536255e-01
    z[2,3,2]  R1063     4.4297706335783005e-02
    z[2,3,2]  R1064     -1.0253424942493439e-01
    z[2,3,2]  R1065     3.4196120500564575e-01
    z[2,3,2]  R1066     1.9986394047737122e-01
    z[2,3,2]  R1067     -8.1668362021446228e-02
    z[2,3,2]  R1068     2.2891965508460999e-01
    z[2,3,2]  R1069     5.2468216419219971e-01
    z[2,3,2]  R1070     -3.9801257848739624e-01
    z[2,3,2]  R1071     -4.8457396030426025e-01
    z[2,3,2]  R1072     -6.3851737976074219e-01
    z[2,3,2]  R1073     -3.4500178694725037e-01
    z[2,3,2]  R1074     -3.0746594071388245e-02
    z[2,3,2]  R1075     0.0672302395105362
    z[2,3,2]  R1076     -1.6945162415504456e-01
    z[2,3,2]  R1077     3.5668212175369263e-01
    z[2,3,2]  R1078     4.5615750551223755e-01
    z[2,3,2]  R1079     1.0421478748321533e-01
    z[2,3,2]  R1080     2.2317555546760559e-01
    z[2,3,2]  R1081     1.8342211842536926e-01
    z[2,3,2]  R1082     3.2977712154388428e-01
    z[2,3,2]  R1083     2.5324460864067078e-01
    z[2,3,2]  R1084     2.0797833800315857e-01
    z[2,3,2]  R1085     5.5952745676040649e-01
    z[2,3,2]  R1086     -1.7250286042690277e-01
    z[2,3,2]  R1087     1.0942266322672367e-02
    z[2,3,2]  R1088     -9.7748890519142151e-02
    z[2,3,2]  R1089     -1.1095040291547775e-01
    z[2,3,2]  R1090     8.1540994346141815e-02
    z[2,3,2]  R1091     1.9990071654319763e-02
    z[2,3,2]  R1092     3.3385327458381653e-01
    z[2,3,2]  R1093     -6.5134182572364807e-02
    z[2,3,2]  R1094     4.1693288087844849e-01
    z[2,3,2]  R1095     -3.3540013432502747e-01
    z[2,3,2]  R1096     3.5556885600090027e-01
    z[2,3,2]  R1097     -1.6824441030621529e-02
    z[2,3,2]  R1098     1.4960496127605438e-01
    z[2,3,2]  R1099     3.2649624347686768e-01
    z[2,3,2]  R1100     -5.8190923929214478e-01
    z[2,3,2]  R1101     -5.5336314439773560e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R965      -1
    z[2,3,3]  R966      1
    z[2,3,3]  R973      2.5789457559585571e-01
    z[2,3,3]  R974      7.6679818332195282e-02
    z[2,3,3]  R975      7.4222676455974579e-02
    z[2,3,3]  R976      6.7925274372100830e-02
    z[2,3,3]  R977      4.2619869112968445e-02
    z[2,3,3]  R978      1.5018087625503540e-01
    z[2,3,3]  R979      -2.2287322208285332e-02
    z[2,3,3]  R980      1.7334936559200287e-01
    z[2,3,3]  R981      1.5530005097389221e-01
    z[2,3,3]  R982      0.0453343540430069
    z[2,3,3]  R983      6.0690528154373169e-01
    z[2,3,3]  R984      5.7045966386795044e-01
    z[2,3,3]  R985      5.9706658124923706e-01
    z[2,3,3]  R986      6.5926498174667358e-01
    z[2,3,3]  R987      5.5603188276290894e-01
    z[2,3,3]  R988      5.6152331829071045e-01
    z[2,3,3]  R989      6.3624918460845947e-01
    z[2,3,3]  R990      4.3104144930839539e-01
    z[2,3,3]  R991      -1.4310272037982941e-01
    z[2,3,3]  R992      3.2803124189376831e-01
    z[2,3,3]  R993      6.1675232648849487e-01
    z[2,3,3]  R994      4.8381385207176208e-01
    z[2,3,3]  R995      1.1437595635652542e-01
    z[2,3,3]  R996      4.5385140925645828e-02
    z[2,3,3]  R997      -4.7429639101028442e-01
    z[2,3,3]  R998      -1.3199462555348873e-02
    z[2,3,3]  R999      2.3878661915659904e-02
    z[2,3,3]  R1000     -1.5798424184322357e-01
    z[2,3,3]  R1001     -1.9470445811748505e-01
    z[2,3,3]  R1002     2.4173672497272491e-01
    z[2,3,3]  R1003     6.5899646282196045e-01
    z[2,3,3]  R1004     7.6095026731491089e-01
    z[2,3,3]  R1005     -7.1903415024280548e-02
    z[2,3,3]  R1006     7.1365468204021454e-02
    z[2,3,3]  R1007     -2.8981423377990723e-01
    z[2,3,3]  R1008     3.6298626661300659e-01
    z[2,3,3]  R1009     1.3017773628234863e-01
    z[2,3,3]  R1010     -1.4988839626312256e-01
    z[2,3,3]  R1011     -3.9614096283912659e-01
    z[2,3,3]  R1012     -3.0419471859931946e-01
    z[2,3,3]  R1013     -2.1315976977348328e-01
    z[2,3,3]  R1014     -2.4674201011657715e-01
    z[2,3,3]  R1015     6.0045200586318970e-01
    z[2,3,3]  R1016     0.831079363822937
    z[2,3,3]  R1017     2.4031335115432739e-01
    z[2,3,3]  R1018     1.3446410000324249e-01
    z[2,3,3]  R1019     1.8834297358989716e-01
    z[2,3,3]  R1020     -4.5580846071243286e-01
    z[2,3,3]  R1021     -4.4311785697937012e-01
    z[2,3,3]  R1022     3.0654057860374451e-01
    z[2,3,3]  R1023     -3.5950881242752075e-01
    z[2,3,3]  R1024     4.5377832651138306e-01
    z[2,3,3]  R1025     1.6288067400455475e-01
    z[2,3,3]  R1026     7.8887414932250977e-01
    z[2,3,3]  R1027     6.0306102037429810e-01
    z[2,3,3]  R1028     2.2944065928459167e-01
    z[2,3,3]  R1029     1.3756365515291691e-02
    z[2,3,3]  R1030     1.4490705728530884e-01
    z[2,3,3]  R1031     9.3097344040870667e-02
    z[2,3,3]  R1032     -8.0060526728630066e-02
    z[2,3,3]  R1033     7.7907508611679077e-01
    z[2,3,3]  R1034     7.3133997619152069e-02
    z[2,3,3]  R1035     7.1731686592102051e-01
    z[2,3,3]  R1036     -1.1281068623065948e-01
    z[2,3,3]  R1037     4.0450257062911987e-01
    z[2,3,3]  R1038     0.00385760678909719
    z[2,3,3]  R1039     -8.1982992589473724e-02
    z[2,3,3]  R1040     1.7649991810321808e-01
    z[2,3,3]  R1041     -2.6585987210273743e-01
    z[2,3,3]  R1042     -2.9219236969947815e-01
    z[2,3,3]  R1043     4.7909659147262573e-01
    z[2,3,3]  R1044     6.0675078630447388e-01
    z[2,3,3]  R1045     7.6968587934970856e-02
    z[2,3,3]  R1046     5.7475709915161133e-01
    z[2,3,3]  R1047     -1.0565434396266937e-01
    z[2,3,3]  R1048     -7.3891326785087585e-02
    z[2,3,3]  R1049     4.7077399492263794e-01
    z[2,3,3]  R1050     3.1705811619758606e-01
    z[2,3,3]  R1051     -3.5898125171661377e-01
    z[2,3,3]  R1052     -4.4451120495796204e-01
    z[2,3,3]  R1053     1.5172217041254044e-02
    z[2,3,3]  R1054     6.6756260395050049e-01
    z[2,3,3]  R1055     4.9172133207321167e-01
    z[2,3,3]  R1056     1.4260038733482361e-01
    z[2,3,3]  R1057     -4.7486531734466553e-01
    z[2,3,3]  R1058     -3.3216324448585510e-01
    z[2,3,3]  R1059     -2.8205469250679016e-01
    z[2,3,3]  R1060     -5.6749057024717331e-02
    z[2,3,3]  R1061     -1.0599813610315323e-01
    z[2,3,3]  R1062     -1.9939118623733521e-01
    z[2,3,3]  R1063     3.3893135190010071e-01
    z[2,3,3]  R1064     1.7238068580627441e-01
    z[2,3,3]  R1065     -8.0694389343261719e-01
    z[2,3,3]  R1066     2.2265070676803589e-01
    z[2,3,3]  R1067     -1.2656930088996887e-01
    z[2,3,3]  R1068     4.0449026226997375e-01
    z[2,3,3]  R1069     -0.569337010383606
    z[2,3,3]  R1070     -6.4385145902633667e-01
    z[2,3,3]  R1071     1.1762108653783798e-02
    z[2,3,3]  R1072     -2.0890416204929352e-01
    z[2,3,3]  R1073     0.820968508720398
    z[2,3,3]  R1074     6.7245924472808838e-01
    z[2,3,3]  R1075     6.3162380456924438e-01
    z[2,3,3]  R1076     7.0842069387435913e-01
    z[2,3,3]  R1077     6.5730887651443481e-01
    z[2,3,3]  R1078     7.4381065368652344e-01
    z[2,3,3]  R1079     8.7322556972503662e-01
    z[2,3,3]  R1080     2.5221675634384155e-01
    z[2,3,3]  R1081     -2.6172018051147461e-01
    z[2,3,3]  R1082     3.6002656817436218e-01
    z[2,3,3]  R1083     3.9744228124618530e-01
    z[2,3,3]  R1084     2.2856892645359039e-01
    z[2,3,3]  R1085     3.2866531610488892e-01
    z[2,3,3]  R1086     -1.9448810815811157e-01
    z[2,3,3]  R1087     -1.3624049723148346e-01
    z[2,3,3]  R1088     1.0560864955186844e-01
    z[2,3,3]  R1089     8.2533389329910278e-02
    z[2,3,3]  R1090     3.7692766636610031e-02
    z[2,3,3]  R1091     1.9963359832763672e-01
    z[2,3,3]  R1092     6.4280843734741211e-01
    z[2,3,3]  R1093     7.4181818962097168e-01
    z[2,3,3]  R1094     8.2144778966903687e-01
    z[2,3,3]  R1095     6.5293055772781372e-01
    z[2,3,3]  R1096     6.0793638229370117e-01
    z[2,3,3]  R1097     -2.7843394875526428e-01
    z[2,3,3]  R1098     -1.4027177821844816e-03
    z[2,3,3]  R1099     -1.1982208490371704e-01
    z[2,3,3]  R1100     -1.3696564733982086e-01
    z[2,3,3]  R1101     -4.2138215899467468e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R967      -1
    z[2,3,4]  R968      1
    z[2,3,4]  R973      -1.1496312171220779e-01
    z[2,3,4]  R974      6.1036888509988785e-02
    z[2,3,4]  R975      1.1571945995092392e-01
    z[2,3,4]  R976      -3.8888859748840332e-01
    z[2,3,4]  R977      -1.1638686805963516e-01
    z[2,3,4]  R978      -2.9812756180763245e-01
    z[2,3,4]  R979      -1.9319224357604980e-01
    z[2,3,4]  R980      1.6015812754631042e-01
    z[2,3,4]  R981      4.2423516511917114e-01
    z[2,3,4]  R982      -1.7063283594325185e-03
    z[2,3,4]  R983      -3.7976670265197754e-01
    z[2,3,4]  R984      -5.4631937295198441e-02
    z[2,3,4]  R985      -4.7857353091239929e-01
    z[2,3,4]  R986      1.5906213223934174e-01
    z[2,3,4]  R987      1.1276460252702236e-02
    z[2,3,4]  R988      5.0584155321121216e-01
    z[2,3,4]  R989      2.3941858112812042e-01
    z[2,3,4]  R990      -0.562581479549408
    z[2,3,4]  R991      8.6790435016155243e-02
    z[2,3,4]  R992      -1.2445009499788284e-01
    z[2,3,4]  R993      4.0344062447547913e-01
    z[2,3,4]  R994      -2.3010616004467010e-01
    z[2,3,4]  R995      -2.1427439153194427e-01
    z[2,3,4]  R996      -5.6533205509185791e-01
    z[2,3,4]  R997      -1.5597687661647797e-01
    z[2,3,4]  R998      -4.6064171195030212e-01
    z[2,3,4]  R999      -6.3801310956478119e-02
    z[2,3,4]  R1000     5.2818089723587036e-01
    z[2,3,4]  R1001     4.9443128705024719e-01
    z[2,3,4]  R1002     -2.1657621860504150e-01
    z[2,3,4]  R1003     -1.7721369862556458e-02
    z[2,3,4]  R1004     3.4907300025224686e-02
    z[2,3,4]  R1005     -1.4428691565990448e-01
    z[2,3,4]  R1006     5.3972166031599045e-02
    z[2,3,4]  R1007     3.9959940314292908e-01
    z[2,3,4]  R1008     -4.4225663878023624e-03
    z[2,3,4]  R1009     5.6520360708236694e-01
    z[2,3,4]  R1010     2.9839816689491272e-01
    z[2,3,4]  R1011     -1.2828929722309113e-01
    z[2,3,4]  R1012     2.1192553639411926e-01
    z[2,3,4]  R1013     8.9194908738136292e-02
    z[2,3,4]  R1014     3.6870828270912170e-01
    z[2,3,4]  R1015     -3.1754696369171143e-01
    z[2,3,4]  R1016     2.1599155664443970e-01
    z[2,3,4]  R1017     3.5281282663345337e-01
    z[2,3,4]  R1018     -0.0717427060008049
    z[2,3,4]  R1019     1.4988392591476440e-01
    z[2,3,4]  R1020     1.9288735091686249e-01
    z[2,3,4]  R1021     -3.0036326497793198e-02
    z[2,3,4]  R1022     -2.2175274789333344e-02
    z[2,3,4]  R1023     -5.9873346239328384e-02
    z[2,3,4]  R1024     1.8889187276363373e-01
    z[2,3,4]  R1025     -2.0365279912948608e-01
    z[2,3,4]  R1026     -5.0281536579132080e-01
    z[2,3,4]  R1027     -7.1040540933609009e-02
    z[2,3,4]  R1028     7.4606128036975861e-02
    z[2,3,4]  R1029     2.8247093781828880e-02
    z[2,3,4]  R1030     8.0307433381676674e-04
    z[2,3,4]  R1031     -8.1252768635749817e-02
    z[2,3,4]  R1032     -6.5929013490676880e-01
    z[2,3,4]  R1033     -3.4355142712593079e-01
    z[2,3,4]  R1034     1.5855866670608521e-01
    z[2,3,4]  R1035     4.9937221407890320e-01
    z[2,3,4]  R1036     2.7032768726348877e-01
    z[2,3,4]  R1037     9.5205254852771759e-02
    z[2,3,4]  R1038     2.9664269089698792e-01
    z[2,3,4]  R1039     -3.3074134588241577e-01
    z[2,3,4]  R1040     -3.5192474722862244e-01
    z[2,3,4]  R1041     -2.4802875518798828e-01
    z[2,3,4]  R1042     -1.7932142317295074e-01
    z[2,3,4]  R1043     -1.3013717532157898e-01
    z[2,3,4]  R1044     -2.1842719614505768e-01
    z[2,3,4]  R1045     -3.3131629228591919e-01
    z[2,3,4]  R1046     3.6168730258941650e-01
    z[2,3,4]  R1047     7.0028595626354218e-02
    z[2,3,4]  R1048     3.1607393175363541e-02
    z[2,3,4]  R1049     -3.6443449556827545e-02
    z[2,3,4]  R1050     -7.0717319846153259e-02
    z[2,3,4]  R1051     -8.0152988433837891e-02
    z[2,3,4]  R1052     -9.5381431281566620e-02
    z[2,3,4]  R1053     -8.0028679221868515e-03
    z[2,3,4]  R1054     -4.6683689579367638e-03
    z[2,3,4]  R1055     2.3104159533977509e-01
    z[2,3,4]  R1056     -4.9141305498778820e-04
    z[2,3,4]  R1057     2.8214901685714722e-01
    z[2,3,4]  R1058     1.9687581062316895e-01
    z[2,3,4]  R1059     6.2029594182968140e-01
    z[2,3,4]  R1060     6.0424196720123291e-01
    z[2,3,4]  R1061     -3.1634208559989929e-01
    z[2,3,4]  R1062     6.7752408981323242e-01
    z[2,3,4]  R1063     6.1544120311737061e-01
    z[2,3,4]  R1064     -1.6038011014461517e-01
    z[2,3,4]  R1065     -4.4960159808397293e-02
    z[2,3,4]  R1066     3.2772939652204514e-02
    z[2,3,4]  R1067     2.4203942716121674e-01
    z[2,3,4]  R1068     -7.1600514650344849e-01
    z[2,3,4]  R1069     -4.7515761852264404e-01
    z[2,3,4]  R1070     -4.7687861323356628e-01
    z[2,3,4]  R1071     -1.4801302552223206e-01
    z[2,3,4]  R1072     -8.6326800286769867e-02
    z[2,3,4]  R1073     -1.1482661962509155e-01
    z[2,3,4]  R1074     -7.4615702033042908e-03
    z[2,3,4]  R1075     -1.4398986101150513e-01
    z[2,3,4]  R1076     3.1648358702659607e-01
    z[2,3,4]  R1077     8.5796646773815155e-02
    z[2,3,4]  R1078     1.6937313973903656e-01
    z[2,3,4]  R1079     3.5484090447425842e-01
    z[2,3,4]  R1080     -5.3575527854263783e-03
    z[2,3,4]  R1081     -5.2903532981872559e-02
    z[2,3,4]  R1082     -5.3471463918685913e-01
    z[2,3,4]  R1083     -0.59151291847229
    z[2,3,4]  R1084     -7.9646848142147064e-02
    z[2,3,4]  R1085     -0.0201775711029768
    z[2,3,4]  R1086     4.5154165476560593e-02
    z[2,3,4]  R1087     1.6619296371936798e-01
    z[2,3,4]  R1088     1.6266991198062897e-01
    z[2,3,4]  R1089     -3.7581852078437805e-01
    z[2,3,4]  R1090     -2.7733482420444489e-03
    z[2,3,4]  R1091     2.2970676422119141e-01
    z[2,3,4]  R1092     -1.4652857184410095e-01
    z[2,3,4]  R1093     1.3311018049716949e-01
    z[2,3,4]  R1094     2.1338362246751785e-02
    z[2,3,4]  R1095     -4.9263462424278259e-01
    z[2,3,4]  R1096     1.3779577612876892e-01
    z[2,3,4]  R1097     -3.4126002341508865e-02
    z[2,3,4]  R1098     -1.0386031121015549e-01
    z[2,3,4]  R1099     -1.1333167552947998e-02
    z[2,3,4]  R1100     1.8678863346576691e-01
    z[2,3,4]  R1101     1.9302532076835632e-02
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R969      -1
    z[2,3,5]  R970      1
    z[2,3,5]  R973      0.0596165657043457
    z[2,3,5]  R974      -1.5421052277088165e-01
    z[2,3,5]  R975      2.5916749238967896e-01
    z[2,3,5]  R976      3.5540476441383362e-02
    z[2,3,5]  R977      2.4593852460384369e-01
    z[2,3,5]  R978      2.6339060068130493e-01
    z[2,3,5]  R979      -3.1690327450633049e-03
    z[2,3,5]  R980      -2.6576307415962219e-01
    z[2,3,5]  R981      7.5584337115287781e-02
    z[2,3,5]  R982      -1.3800999522209167e-01
    z[2,3,5]  R983      -2.3829996585845947e-01
    z[2,3,5]  R984      -4.3946501612663269e-01
    z[2,3,5]  R985      -3.5648146271705627e-01
    z[2,3,5]  R986      -4.4333106279373169e-01
    z[2,3,5]  R987      -1.6065049916505814e-02
    z[2,3,5]  R988      1.9907447695732117e-01
    z[2,3,5]  R989      1.5110961161553860e-02
    z[2,3,5]  R990      4.7820255160331726e-01
    z[2,3,5]  R991      3.8310371339321136e-02
    z[2,3,5]  R992      8.0996805429458618e-01
    z[2,3,5]  R993      -1.6127489507198334e-01
    z[2,3,5]  R994      0.690273106098175
    z[2,3,5]  R995      -3.0313533544540405e-01
    z[2,3,5]  R996      7.4939350597560406e-03
    z[2,3,5]  R997      0.0902993455529213
    z[2,3,5]  R998      -4.8316949605941772e-01
    z[2,3,5]  R999      1.0509271919727325e-01
    z[2,3,5]  R1000     -1.3863454759120941e-01
    z[2,3,5]  R1001     -5.6824021041393280e-02
    z[2,3,5]  R1002     2.8457471728324890e-01
    z[2,3,5]  R1003     -7.8652210533618927e-02
    z[2,3,5]  R1004     1.3941408693790436e-01
    z[2,3,5]  R1005     -5.6810826063156128e-01
    z[2,3,5]  R1006     2.0864079892635345e-01
    z[2,3,5]  R1007     3.5150960087776184e-01
    z[2,3,5]  R1008     3.6750671267509460e-01
    z[2,3,5]  R1009     8.7569728493690491e-02
    z[2,3,5]  R1010     5.7715136557817459e-02
    z[2,3,5]  R1011     2.7905693650245667e-01
    z[2,3,5]  R1012     -3.2278639078140259e-01
    z[2,3,5]  R1013     2.1576821804046631e-01
    z[2,3,5]  R1014     1.7159767448902130e-01
    z[2,3,5]  R1015     4.1267678141593933e-01
    z[2,3,5]  R1016     -1.2315607070922852e-01
    z[2,3,5]  R1017     -7.2828345000743866e-02
    z[2,3,5]  R1018     1.3304447755217552e-02
    z[2,3,5]  R1019     3.5721620917320251e-01
    z[2,3,5]  R1020     -5.7846039533615112e-01
    z[2,3,5]  R1021     -5.3011399507522583e-01
    z[2,3,5]  R1022     2.8076618909835815e-01
    z[2,3,5]  R1023     -2.3221983015537262e-01
    z[2,3,5]  R1024     1.2673947215080261e-01
    z[2,3,5]  R1025     -2.8106454014778137e-01
    z[2,3,5]  R1026     1.4398138225078583e-01
    z[2,3,5]  R1027     -2.9013365507125854e-01
    z[2,3,5]  R1028     1.1404684931039810e-01
    z[2,3,5]  R1029     -0.0963074192404747
    z[2,3,5]  R1030     -1.9495855271816254e-01
    z[2,3,5]  R1031     2.8034153580665588e-01
    z[2,3,5]  R1032     -0.323823481798172
    z[2,3,5]  R1033     3.7357372045516968e-01
    z[2,3,5]  R1034     -5.8438368141651154e-02
    z[2,3,5]  R1035     -7.9122297465801239e-02
    z[2,3,5]  R1036     -6.4036726951599121e-01
    z[2,3,5]  R1037     -1.8583790957927704e-01
    z[2,3,5]  R1038     -3.2547211647033691e-01
    z[2,3,5]  R1039     -2.4672269821166992e-01
    z[2,3,5]  R1040     -1.0942756384611130e-01
    z[2,3,5]  R1041     8.1528417766094208e-02
    z[2,3,5]  R1042     2.4342155456542969e-01
    z[2,3,5]  R1043     -2.1648842096328735e-01
    z[2,3,5]  R1044     -1.0613638907670975e-01
    z[2,3,5]  R1045     -6.7212902009487152e-02
    z[2,3,5]  R1046     2.4922121316194534e-02
    z[2,3,5]  R1047     -3.5402163863182068e-01
    z[2,3,5]  R1048     -2.4613919854164124e-01
    z[2,3,5]  R1049     -1.1041836440563202e-01
    z[2,3,5]  R1050     -0.289393812417984
    z[2,3,5]  R1051     -1.6315674409270287e-02
    z[2,3,5]  R1052     9.6302941441535950e-02
    z[2,3,5]  R1053     -1.8625985085964203e-01
    z[2,3,5]  R1054     1.9237220287322998e-01
    z[2,3,5]  R1055     -2.5953933596611023e-01
    z[2,3,5]  R1056     2.0789082348346710e-01
    z[2,3,5]  R1057     2.5498500093817711e-02
    z[2,3,5]  R1058     3.3535334467887878e-01
    z[2,3,5]  R1059     -2.5545755028724670e-01
    z[2,3,5]  R1060     -2.6062300801277161e-01
    z[2,3,5]  R1061     -3.4602773189544678e-01
    z[2,3,5]  R1062     8.0022260546684265e-02
    z[2,3,5]  R1063     1.3929626345634460e-01
    z[2,3,5]  R1064     -3.5279604792594910e-01
    z[2,3,5]  R1065     3.8220237940549850e-02
    z[2,3,5]  R1066     2.1354711055755615e-01
    z[2,3,5]  R1067     -4.0999558568000793e-01
    z[2,3,5]  R1068     8.4200963377952576e-02
    z[2,3,5]  R1069     2.8404369950294495e-01
    z[2,3,5]  R1070     3.8109812140464783e-01
    z[2,3,5]  R1071     7.8728175163269043e-01
    z[2,3,5]  R1072     6.7090344429016113e-01
    z[2,3,5]  R1073     3.5295647382736206e-01
    z[2,3,5]  R1074     -2.4163994938135147e-02
    z[2,3,5]  R1075     2.7940610051155090e-01
    z[2,3,5]  R1076     2.9542475938796997e-02
    z[2,3,5]  R1077     2.8805750608444214e-01
    z[2,3,5]  R1078     -1.4151780307292938e-01
    z[2,3,5]  R1079     -5.8375686407089233e-02
    z[2,3,5]  R1080     5.0904947519302368e-01
    z[2,3,5]  R1081     -2.0721639692783356e-01
    z[2,3,5]  R1082     2.2999155521392822e-01
    z[2,3,5]  R1083     1.7055776715278625e-01
    z[2,3,5]  R1084     4.8161312937736511e-01
    z[2,3,5]  R1085     -1.8148081004619598e-01
    z[2,3,5]  R1086     0.072996124625206
    z[2,3,5]  R1087     -1.3415264897048473e-02
    z[2,3,5]  R1088     2.1625134348869324e-01
    z[2,3,5]  R1089     0.118670254945755
    z[2,3,5]  R1090     -0.221003919839859
    z[2,3,5]  R1091     -3.0883875489234924e-01
    z[2,3,5]  R1092     -1.3896717131137848e-01
    z[2,3,5]  R1093     3.2583504915237427e-01
    z[2,3,5]  R1094     -8.8345922529697418e-02
    z[2,3,5]  R1095     2.5804251432418823e-01
    z[2,3,5]  R1096     2.5488847494125366e-01
    z[2,3,5]  R1097     -0.0645069107413292
    z[2,3,5]  R1098     2.2342254221439362e-01
    z[2,3,5]  R1099     5.1044980064034462e-03
    z[2,3,5]  R1100     -2.3616391420364380e-01
    z[2,3,5]  R1101     -3.1501868367195129e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R971      -1
    z[2,3,6]  R972      1
    z[2,3,6]  R973      -1.3391232490539551e-01
    z[2,3,6]  R974      -5.5602509528398514e-02
    z[2,3,6]  R975      9.5840133726596832e-02
    z[2,3,6]  R976      1.4374126493930817e-01
    z[2,3,6]  R977      -1.5773972868919373e-01
    z[2,3,6]  R978      0.0995691567659378
    z[2,3,6]  R979      -7.6256953179836273e-02
    z[2,3,6]  R980      1.4368730783462524e-01
    z[2,3,6]  R981      -1.5407225489616394e-01
    z[2,3,6]  R982      1.6710811853408813e-01
    z[2,3,6]  R983      2.9666331410408020e-01
    z[2,3,6]  R984      1.7016613855957985e-02
    z[2,3,6]  R985      -2.0249038934707642e-01
    z[2,3,6]  R986      -1.0928864032030106e-01
    z[2,3,6]  R987      6.4154869318008423e-01
    z[2,3,6]  R988      5.3281837701797485e-01
    z[2,3,6]  R989      3.0589789152145386e-01
    z[2,3,6]  R990      2.4263255298137665e-01
    z[2,3,6]  R991      -2.9404631257057190e-01
    z[2,3,6]  R992      2.7412512898445129e-01
    z[2,3,6]  R993      4.8868253827095032e-02
    z[2,3,6]  R994      8.0984615487977862e-04
    z[2,3,6]  R995      -1.7131294310092926e-01
    z[2,3,6]  R996      -7.9409822821617126e-02
    z[2,3,6]  R997      3.2485806941986084e-01
    z[2,3,6]  R998      8.6883746087551117e-02
    z[2,3,6]  R999      1.9362498819828033e-01
    z[2,3,6]  R1000     3.8350574672222137e-02
    z[2,3,6]  R1001     -0.0493636429309845
    z[2,3,6]  R1002     9.3438185751438141e-02
    z[2,3,6]  R1003     5.2796018123626709e-01
    z[2,3,6]  R1004     -4.5082005858421326e-01
    z[2,3,6]  R1005     -3.9235156774520874e-01
    z[2,3,6]  R1006     -2.1485263109207153e-01
    z[2,3,6]  R1007     1.0583304613828659e-01
    z[2,3,6]  R1008     2.6076692342758179e-01
    z[2,3,6]  R1009     0.101309634745121
    z[2,3,6]  R1010     1.8745566904544830e-01
    z[2,3,6]  R1011     6.6299118101596832e-02
    z[2,3,6]  R1012     3.4264308214187622e-01
    z[2,3,6]  R1013     3.6983732134103775e-03
    z[2,3,6]  R1014     -3.6549825221300125e-02
    z[2,3,6]  R1015     5.6970596313476562e-02
    z[2,3,6]  R1016     -3.0264276266098022e-01
    z[2,3,6]  R1017     1.8844233453273773e-01
    z[2,3,6]  R1018     1.1336199194192886e-01
    z[2,3,6]  R1019     -1.3753518462181091e-01
    z[2,3,6]  R1020     2.8746657073497772e-02
    z[2,3,6]  R1021     3.0018597841262817e-01
    z[2,3,6]  R1022     -3.2065957784652710e-01
    z[2,3,6]  R1023     3.5046026110649109e-01
    z[2,3,6]  R1024     1.7457805573940277e-01
    z[2,3,6]  R1025     6.3427664339542389e-02
    z[2,3,6]  R1026     -1.4630000293254852e-01
    z[2,3,6]  R1027     -3.6590874195098877e-01
    z[2,3,6]  R1028     2.3407968692481518e-03
    z[2,3,6]  R1029     1.4083732664585114e-01
    z[2,3,6]  R1030     -4.5543056726455688e-01
    z[2,3,6]  R1031     3.6189281940460205e-01
    z[2,3,6]  R1032     5.9667207300662994e-02
    z[2,3,6]  R1033     3.9056394249200821e-02
    z[2,3,6]  R1034     -3.5774940252304077e-01
    z[2,3,6]  R1035     6.4626209437847137e-02
    z[2,3,6]  R1036     -5.1362957805395126e-02
    z[2,3,6]  R1037     -8.9024573564529419e-02
    z[2,3,6]  R1038     -3.5536146163940430e-01
    z[2,3,6]  R1039     -2.2796842455863953e-01
    z[2,3,6]  R1040     -2.1361030638217926e-01
    z[2,3,6]  R1041     1.4386756718158722e-01
    z[2,3,6]  R1042     -2.4325957521796227e-02
    z[2,3,6]  R1043     -2.0830747485160828e-01
    z[2,3,6]  R1044     -4.2313057184219360e-01
    z[2,3,6]  R1045     2.8809100389480591e-01
    z[2,3,6]  R1046     -2.6862871646881104e-01
    z[2,3,6]  R1047     -1.3921138644218445e-01
    z[2,3,6]  R1048     -2.2763611376285553e-01
    z[2,3,6]  R1049     -1.7594610154628754e-01
    z[2,3,6]  R1050     -3.2816660404205322e-01
    z[2,3,6]  R1051     1.3124649226665497e-01
    z[2,3,6]  R1052     -2.2728709876537323e-01
    z[2,3,6]  R1053     -8.9128427207469940e-02
    z[2,3,6]  R1054     -1.5429088473320007e-01
    z[2,3,6]  R1055     -1.7627786099910736e-01
    z[2,3,6]  R1056     -3.0590042471885681e-01
    z[2,3,6]  R1057     1.0293000936508179e-01
    z[2,3,6]  R1058     2.2025278210639954e-01
    z[2,3,6]  R1059     2.3513735830783844e-01
    z[2,3,6]  R1060     4.3343797326087952e-02
    z[2,3,6]  R1061     -5.9962904453277588e-01
    z[2,3,6]  R1062     1.0144189745187759e-01
    z[2,3,6]  R1063     -2.7296485379338264e-02
    z[2,3,6]  R1064     -6.9551318883895874e-01
    z[2,3,6]  R1065     -9.9850669503211975e-03
    z[2,3,6]  R1066     1.2903241813182831e-01
    z[2,3,6]  R1067     0.614565372467041
    z[2,3,6]  R1068     4.7373369336128235e-01
    z[2,3,6]  R1069     -9.6105104312300682e-03
    z[2,3,6]  R1070     -1.6487258672714233e-01
    z[2,3,6]  R1071     -3.3270925283432007e-01
    z[2,3,6]  R1072     -1.5050514601171017e-02
    z[2,3,6]  R1073     2.5339301675558090e-02
    z[2,3,6]  R1074     4.1012936830520630e-01
    z[2,3,6]  R1075     -2.2790496051311493e-01
    z[2,3,6]  R1076     1.9731713831424713e-01
    z[2,3,6]  R1077     -8.0265142023563385e-02
    z[2,3,6]  R1078     -2.3283023387193680e-02
    z[2,3,6]  R1079     9.9094063043594360e-02
    z[2,3,6]  R1080     3.0142712593078613e-01
    z[2,3,6]  R1081     1.8220894038677216e-01
    z[2,3,6]  R1082     1.3260385394096375e-01
    z[2,3,6]  R1083     3.8297748565673828e-01
    z[2,3,6]  R1084     2.5355115532875061e-01
    z[2,3,6]  R1085     1.6693432629108429e-01
    z[2,3,6]  R1086     1.8298017978668213e-01
    z[2,3,6]  R1087     3.3461713790893555e-01
    z[2,3,6]  R1088     1.3354423642158508e-01
    z[2,3,6]  R1089     3.5253062844276428e-02
    z[2,3,6]  R1090     -3.4190145134925842e-01
    z[2,3,6]  R1091     3.3973187208175659e-02
    z[2,3,6]  R1092     3.8801971077919006e-01
    z[2,3,6]  R1093     3.2108667492866516e-01
    z[2,3,6]  R1094     2.4911326169967651e-01
    z[2,3,6]  R1095     2.7404436469078064e-01
    z[2,3,6]  R1096     2.4183419346809387e-01
    z[2,3,6]  R1097     -1.0881573706865311e-01
    z[2,3,6]  R1098     -2.9862526059150696e-01
    z[2,3,6]  R1099     0.0569380484521389
    z[2,3,6]  R1100     -5.3832545876502991e-02
    z[2,3,6]  R1101     -2.0913438498973846e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1102     -1
    z[3,2,0]  R1103     1
    z[3,2,0]  R1116     -5.4492527246475220e-01
    z[3,2,0]  R1117     -2.1534349024295807e-01
    z[3,2,0]  R1118     -4.7673907876014709e-01
    z[3,2,0]  R1119     -9.1472655534744263e-01
    z[3,2,0]  R1120     -4.9899551272392273e-01
    z[3,2,0]  R1121     1.7937442660331726e-01
    z[3,2,0]  R1122     8.3233872428536415e-03
    z[3,2,0]  R1123     -1.1779731512069702e-01
    z[3,2,0]  R1124     7.5718045234680176e-02
    z[3,2,0]  R1125     4.3023101985454559e-02
    z[3,2,0]  R1126     2.5510627031326294e-01
    z[3,2,0]  R1127     0.611352801322937
    z[3,2,0]  R1128     6.4501678943634033e-01
    z[3,2,0]  R1129     5.7139158248901367e-01
    z[3,2,0]  R1130     5.8158326148986816e-01
    z[3,2,0]  R1131     3.6221036314964294e-01
    z[3,2,0]  R1132     2.8853756189346313e-01
    z[3,2,0]  R1133     3.1469497084617615e-01
    z[3,2,0]  R1134     2.6581883430480957e-01
    z[3,2,0]  R1135     5.8376115560531616e-01
    z[3,2,0]  R1136     3.7380585074424744e-01
    z[3,2,0]  R1137     4.8549342155456543e-01
    z[3,2,0]  R1138     6.9221824407577515e-01
    z[3,2,0]  R1139     2.0233023166656494e-01
    z[3,2,0]  R1140     1.2574322521686554e-01
    z[3,2,0]  R1141     2.5684067606925964e-01
    z[3,2,0]  R1142     1.1671365052461624e-01
    z[3,2,0]  R1143     2.3870217800140381e-01
    z[3,2,0]  R1144     1.5381184220314026e-01
    z[3,2,0]  R1145     5.1420134305953979e-01
    z[3,2,0]  R1146     2.2655582427978516e-01
    z[3,2,0]  R1147     0.283189594745636
    z[3,2,0]  R1148     2.7601400017738342e-01
    z[3,2,0]  R1149     3.5650694370269775e-01
    z[3,2,0]  R1150     2.8758205473423004e-02
    z[3,2,0]  R1151     2.2294494509696960e-01
    z[3,2,0]  R1152     2.8574812412261963e-01
    z[3,2,0]  R1153     -5.9725034981966019e-02
    z[3,2,0]  R1154     -0.0819258838891983
    z[3,2,0]  R1155     -3.9254170656204224e-01
    z[3,2,0]  R1156     -2.3913398385047913e-01
    z[3,2,0]  R1157     -4.2164230346679688e-01
    z[3,2,0]  R1158     -4.6761247515678406e-01
    z[3,2,0]  R1159     -6.8008285760879517e-01
    z[3,2,0]  R1160     -6.4544725418090820e-01
    z[3,2,0]  R1161     -9.2244094610214233e-01
    z[3,2,0]  R1162     -4.7562113404273987e-01
    z[3,2,0]  R1163     -5.7857674360275269e-01
    z[3,2,0]  R1164     -0.748253583908081
    z[3,2,0]  R1165     5.2099150419235229e-01
    z[3,2,0]  R1166     5.5208230018615723e-01
    z[3,2,0]  R1167     4.7966101765632629e-01
    z[3,2,0]  R1168     5.6979340314865112e-01
    z[3,2,0]  R1169     0.41551673412323
    z[3,2,0]  R1170     3.0027130246162415e-01
    z[3,2,0]  R1171     5.6916791200637817e-01
    z[3,2,0]  R1172     3.7578943371772766e-01
    z[3,2,0]  R1173     2.2402296960353851e-01
    z[3,2,0]  R1174     3.7969928979873657e-01
    z[3,2,0]  R1175     2.6223802566528320e-01
    z[3,2,0]  R1176     3.6775204539299011e-01
    z[3,2,0]  R1177     -2.1203437820076942e-02
    z[3,2,0]  R1178     -1.3206343166530132e-02
    z[3,2,0]  R1179     2.8164750337600708e-01
    z[3,2,0]  R1180     -8.9676812291145325e-02
    z[3,2,0]  R1181     6.2856757640838623e-01
    z[3,2,0]  R1182     3.4075993299484253e-01
    z[3,2,0]  R1183     -1.3045547902584076e-01
    z[3,2,0]  R1184     -3.4689339995384216e-01
    z[3,2,0]  R1185     3.5286378860473633e-01
    z[3,2,0]  R1186     3.8080233335494995e-01
    z[3,2,0]  R1187     -0.586037814617157
    z[3,2,0]  R1188     -0.0869353786110878
    z[3,2,0]  R1189     -7.7154916524887085e-01
    z[3,2,0]  R1190     5.7940429449081421e-01
    z[3,2,0]  R1191     -6.0262113809585571e-01
    z[3,2,0]  R1192     -9.5427431166172028e-02
    z[3,2,0]  R1193     -3.0859872698783875e-01
    z[3,2,0]  R1194     -5.2074217796325684e-01
    z[3,2,0]  R1195     -9.4161635637283325e-01
    z[3,2,0]  R1196     -8.1056392192840576e-01
    z[3,2,0]  R1197     3.9836764335632324e-01
    z[3,2,0]  R1198     7.0478290319442749e-02
    z[3,2,0]  R1199     -5.9895825386047363e-01
    z[3,2,0]  R1200     2.6351484656333923e-01
    z[3,2,0]  R1201     -1.5788662433624268e-01
    z[3,2,0]  R1202     -6.1514323949813843e-01
    z[3,2,0]  R1203     -3.8206470012664795e-01
    z[3,2,0]  R1204     -1.1098635941743851e-01
    z[3,2,0]  R1205     -6.7380934953689575e-01
    z[3,2,0]  R1206     0.543727457523346
    z[3,2,0]  R1207     -7.9898262023925781e-01
    z[3,2,0]  R1208     7.9587094485759735e-02
    z[3,2,0]  R1209     -5.8735519647598267e-01
    z[3,2,0]  R1210     -1.9871200621128082e-01
    z[3,2,0]  R1211     -5.9651982784271240e-01
    z[3,2,0]  R1212     1.5138798952102661e-01
    z[3,2,0]  R1213     -1.5813054144382477e-01
    z[3,2,0]  R1214     -4.7670900821685791e-01
    z[3,2,0]  R1215     3.3887746930122375e-01
    z[3,2,0]  R1216     -8.8683640956878662e-01
    z[3,2,0]  R1217     3.9698880910873413e-01
    z[3,2,0]  R1218     -5.4121297597885132e-01
    z[3,2,0]  R1219     2.5448048114776611e-01
    z[3,2,0]  R1220     1.7015197873115540e-01
    z[3,2,0]  R1221     -3.7779429554939270e-01
    z[3,2,0]  R1222     -4.4674339890480042e-01
    z[3,2,0]  R1223     -3.5545790195465088e-01
    z[3,2,0]  R1224     6.5151005983352661e-01
    z[3,2,0]  R1225     -6.8009203672409058e-01
    z[3,2,0]  R1226     3.2066974788904190e-02
    z[3,2,0]  R1227     -7.2874939441680908e-01
    z[3,2,0]  R1228     -5.9182637929916382e-01
    z[3,2,0]  R1229     -2.6132553815841675e-01
    z[3,2,0]  R1230     2.8182464838027954e-01
    z[3,2,0]  R1231     2.1349306404590607e-01
    z[3,2,0]  R1232     -9.1540098190307617e-02
    z[3,2,0]  R1233     -5.4024338722229004e-02
    z[3,2,0]  R1234     3.6885675042867661e-02
    z[3,2,0]  R1235     -8.9066106081008911e-01
    z[3,2,0]  R1236     4.4937521219253540e-01
    z[3,2,0]  R1237     0.754943311214447
    z[3,2,0]  R1238     -5.8507156372070312e-01
    z[3,2,0]  R1239     2.8378924727439880e-01
    z[3,2,0]  R1240     7.8624807298183441e-02
    z[3,2,0]  R1241     1.2666773796081543e-01
    z[3,2,0]  R1242     9.6525497734546661e-02
    z[3,2,0]  R1243     -1.7874591052532196e-01
    z[3,2,0]  R1244     -1.5020088851451874e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1104     -1
    z[3,2,1]  R1105     1
    z[3,2,1]  R1116     4.3278518319129944e-01
    z[3,2,1]  R1117     5.2865236997604370e-01
    z[3,2,1]  R1118     3.2280489802360535e-02
    z[3,2,1]  R1119     -1.0213023424148560e-01
    z[3,2,1]  R1120     3.5205683112144470e-01
    z[3,2,1]  R1121     0.0873582735657692
    z[3,2,1]  R1122     3.0650734901428223e-01
    z[3,2,1]  R1123     -1.1546940356492996e-01
    z[3,2,1]  R1124     -8.3069734275341034e-02
    z[3,2,1]  R1125     2.9835087060928345e-01
    z[3,2,1]  R1126     -0.0591592937707901
    z[3,2,1]  R1127     -6.5233409404754639e-02
    z[3,2,1]  R1128     -1.7246234416961670e-01
    z[3,2,1]  R1129     5.4489899426698685e-02
    z[3,2,1]  R1130     -7.5519219040870667e-02
    z[3,2,1]  R1131     -2.4127402901649475e-01
    z[3,2,1]  R1132     -6.4986400306224823e-02
    z[3,2,1]  R1133     6.6145914793014526e-01
    z[3,2,1]  R1134     -8.6502122879028320e-01
    z[3,2,1]  R1135     2.5387245416641235e-01
    z[3,2,1]  R1136     3.3545008301734924e-01
    z[3,2,1]  R1137     0.605156421661377
    z[3,2,1]  R1138     1.9629713892936707e-01
    z[3,2,1]  R1139     -0.922296404838562
    z[3,2,1]  R1140     -9.0870171785354614e-01
    z[3,2,1]  R1141     -9.0678805112838745e-01
    z[3,2,1]  R1142     -9.0038394927978516e-01
    z[3,2,1]  R1143     -8.7704312801361084e-01
    z[3,2,1]  R1144     -8.8701063394546509e-01
    z[3,2,1]  R1145     1.3998055458068848e-01
    z[3,2,1]  R1146     4.0884265303611755e-01
    z[3,2,1]  R1147     2.9602622613310814e-02
    z[3,2,1]  R1148     2.5092095136642456e-02
    z[3,2,1]  R1149     4.8419770598411560e-01
    z[3,2,1]  R1150     -0.950893223285675
    z[3,2,1]  R1151     -8.8206022977828979e-01
    z[3,2,1]  R1152     -8.9106363058090210e-01
    z[3,2,1]  R1153     -7.3857551813125610e-01
    z[3,2,1]  R1154     -6.0511809587478638e-01
    z[3,2,1]  R1155     8.6168175935745239e-01
    z[3,2,1]  R1156     9.5194482803344727e-01
    z[3,2,1]  R1157     8.3967870473861694e-01
    z[3,2,1]  R1158     7.5791954994201660e-01
    z[3,2,1]  R1159     6.5164351463317871e-01
    z[3,2,1]  R1160     0.60193932056427
    z[3,2,1]  R1161     1.8296839296817780e-01
    z[3,2,1]  R1162     7.0275247097015381e-01
    z[3,2,1]  R1163     6.4181548357009888e-01
    z[3,2,1]  R1164     6.2443137168884277e-01
    z[3,2,1]  R1165     -0.166351318359375
    z[3,2,1]  R1166     1.9614227116107941e-01
    z[3,2,1]  R1167     1.2256369739770889e-01
    z[3,2,1]  R1168     -6.2041327357292175e-02
    z[3,2,1]  R1169     -3.0906911939382553e-02
    z[3,2,1]  R1170     1.1112090200185776e-01
    z[3,2,1]  R1171     -3.3025091886520386e-01
    z[3,2,1]  R1172     -2.3501524329185486e-01
    z[3,2,1]  R1173     -8.1570070981979370e-01
    z[3,2,1]  R1174     -1.1152768507599831e-02
    z[3,2,1]  R1175     4.8224860429763794e-01
    z[3,2,1]  R1176     2.8804332017898560e-01
    z[3,2,1]  R1177     -0.904996395111084
    z[3,2,1]  R1178     -8.0651009082794189e-01
    z[3,2,1]  R1179     -7.4384588003158569e-01
    z[3,2,1]  R1180     -6.9912791252136230e-01
    z[3,2,1]  R1181     -7.4209755659103394e-01
    z[3,2,1]  R1182     -7.4391418695449829e-01
    z[3,2,1]  R1183     -8.3136105537414551e-01
    z[3,2,1]  R1184     -7.9074168205261230e-01
    z[3,2,1]  R1185     3.5440880060195923e-01
    z[3,2,1]  R1186     -1.8497738242149353e-01
    z[3,2,1]  R1187     3.6687543988227844e-01
    z[3,2,1]  R1188     -8.6033952236175537e-01
    z[3,2,1]  R1189     -0.104481041431427
    z[3,2,1]  R1190     5.4912644624710083e-01
    z[3,2,1]  R1191     -2.0457734167575836e-01
    z[3,2,1]  R1192     -8.8429284095764160e-01
    z[3,2,1]  R1193     -7.8451168537139893e-01
    z[3,2,1]  R1194     -0.317264199256897
    z[3,2,1]  R1195     0.0891835018992424
    z[3,2,1]  R1196     3.3691781759262085e-01
    z[3,2,1]  R1197     4.4969987869262695e-01
    z[3,2,1]  R1198     2.7287730574607849e-01
    z[3,2,1]  R1199     1.3377930968999863e-02
    z[3,2,1]  R1200     -9.3052148818969727e-01
    z[3,2,1]  R1201     -8.7759679555892944e-01
    z[3,2,1]  R1202     9.5067918300628662e-02
    z[3,2,1]  R1203     4.3363296985626221e-01
    z[3,2,1]  R1204     -8.2585883140563965e-01
    z[3,2,1]  R1205     2.8689932823181152e-01
    z[3,2,1]  R1206     5.7964378595352173e-01
    z[3,2,1]  R1207     3.8527809083461761e-02
    z[3,2,1]  R1208     -2.5478392839431763e-01
    z[3,2,1]  R1209     0.0353827103972435
    z[3,2,1]  R1210     -9.1124457120895386e-01
    z[3,2,1]  R1211     -0.662040114402771
    z[3,2,1]  R1212     -7.8357911109924316e-01
    z[3,2,1]  R1213     -7.6083678007125854e-01
    z[3,2,1]  R1214     -4.1661381721496582e-01
    z[3,2,1]  R1215     -1.3202227652072906e-02
    z[3,2,1]  R1216     2.2526440024375916e-01
    z[3,2,1]  R1217     -4.9321573227643967e-02
    z[3,2,1]  R1218     3.2392221689224243e-01
    z[3,2,1]  R1219     -8.1055295467376709e-01
    z[3,2,1]  R1220     -7.8756111860275269e-01
    z[3,2,1]  R1221     -7.8263121843338013e-01
    z[3,2,1]  R1222     -7.6649588346481323e-01
    z[3,2,1]  R1223     -3.5260787606239319e-01
    z[3,2,1]  R1224     6.2596333026885986e-01
    z[3,2,1]  R1225     3.2141822576522827e-01
    z[3,2,1]  R1226     3.8521626591682434e-01
    z[3,2,1]  R1227     -5.0963733345270157e-02
    z[3,2,1]  R1228     -2.4608006700873375e-02
    z[3,2,1]  R1229     -8.7529158592224121e-01
    z[3,2,1]  R1230     -8.6956137418746948e-01
    z[3,2,1]  R1231     -8.2586467266082764e-01
    z[3,2,1]  R1232     -8.3300560712814331e-01
    z[3,2,1]  R1233     -9.1836810111999512e-01
    z[3,2,1]  R1234     5.6905514001846313e-01
    z[3,2,1]  R1235     3.3987060189247131e-01
    z[3,2,1]  R1236     5.3938800096511841e-01
    z[3,2,1]  R1237     1.8245634436607361e-01
    z[3,2,1]  R1238     -5.8379560708999634e-01
    z[3,2,1]  R1239     -0.758469820022583
    z[3,2,1]  R1240     0.500398576259613
    z[3,2,1]  R1241     -4.0672817826271057e-01
    z[3,2,1]  R1242     -2.7699694037437439e-01
    z[3,2,1]  R1243     -1.3899168372154236e-01
    z[3,2,1]  R1244     -2.8170236945152283e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1106     -1
    z[3,2,2]  R1107     1
    z[3,2,2]  R1116     4.4297706335783005e-02
    z[3,2,2]  R1117     -1.0253424942493439e-01
    z[3,2,2]  R1118     3.4196120500564575e-01
    z[3,2,2]  R1119     1.9986394047737122e-01
    z[3,2,2]  R1120     -8.1668362021446228e-02
    z[3,2,2]  R1121     2.2891965508460999e-01
    z[3,2,2]  R1122     5.2468216419219971e-01
    z[3,2,2]  R1123     -3.9801257848739624e-01
    z[3,2,2]  R1124     -4.8457396030426025e-01
    z[3,2,2]  R1125     -6.3851737976074219e-01
    z[3,2,2]  R1126     -3.4500178694725037e-01
    z[3,2,2]  R1127     -3.0746594071388245e-02
    z[3,2,2]  R1128     0.0672302395105362
    z[3,2,2]  R1129     -1.6945162415504456e-01
    z[3,2,2]  R1130     3.5668212175369263e-01
    z[3,2,2]  R1131     4.5615750551223755e-01
    z[3,2,2]  R1132     1.0421478748321533e-01
    z[3,2,2]  R1133     2.2317555546760559e-01
    z[3,2,2]  R1134     1.8342211842536926e-01
    z[3,2,2]  R1135     3.2977712154388428e-01
    z[3,2,2]  R1136     2.5324460864067078e-01
    z[3,2,2]  R1137     2.0797833800315857e-01
    z[3,2,2]  R1138     5.5952745676040649e-01
    z[3,2,2]  R1139     -1.7250286042690277e-01
    z[3,2,2]  R1140     1.0942266322672367e-02
    z[3,2,2]  R1141     -9.7748890519142151e-02
    z[3,2,2]  R1142     -1.1095040291547775e-01
    z[3,2,2]  R1143     8.1540994346141815e-02
    z[3,2,2]  R1144     1.9990071654319763e-02
    z[3,2,2]  R1145     3.3385327458381653e-01
    z[3,2,2]  R1146     -6.5134182572364807e-02
    z[3,2,2]  R1147     4.1693288087844849e-01
    z[3,2,2]  R1148     -3.3540013432502747e-01
    z[3,2,2]  R1149     3.5556885600090027e-01
    z[3,2,2]  R1150     -1.6824441030621529e-02
    z[3,2,2]  R1151     1.4960496127605438e-01
    z[3,2,2]  R1152     3.2649624347686768e-01
    z[3,2,2]  R1153     -5.8190923929214478e-01
    z[3,2,2]  R1154     -5.5336314439773560e-01
    z[3,2,2]  R1155     -4.6933200210332870e-02
    z[3,2,2]  R1156     -1.1756887659430504e-02
    z[3,2,2]  R1157     0.148001566529274
    z[3,2,2]  R1158     1.7065636813640594e-01
    z[3,2,2]  R1159     -1.1008264124393463e-01
    z[3,2,2]  R1160     1.7419527471065521e-01
    z[3,2,2]  R1161     2.6829114556312561e-01
    z[3,2,2]  R1162     3.6461880803108215e-01
    z[3,2,2]  R1163     1.4063043892383575e-01
    z[3,2,2]  R1164     -0.0342351458966732
    z[3,2,2]  R1165     2.0866812765598297e-01
    z[3,2,2]  R1166     3.6729472875595093e-01
    z[3,2,2]  R1167     3.6069635301828384e-02
    z[3,2,2]  R1168     -5.5398438125848770e-02
    z[3,2,2]  R1169     3.2442143559455872e-01
    z[3,2,2]  R1170     5.2716922014951706e-02
    z[3,2,2]  R1171     -1.0509991645812988e-01
    z[3,2,2]  R1172     1.1707766354084015e-01
    z[3,2,2]  R1173     -4.1049256920814514e-01
    z[3,2,2]  R1174     -3.7668108940124512e-02
    z[3,2,2]  R1175     -3.5654169321060181e-01
    z[3,2,2]  R1176     -0.135230153799057
    z[3,2,2]  R1177     1.7250137403607368e-02
    z[3,2,2]  R1178     -1.4609888195991516e-01
    z[3,2,2]  R1179     -6.6297873854637146e-02
    z[3,2,2]  R1180     2.2318531572818756e-01
    z[3,2,2]  R1181     3.1908690929412842e-02
    z[3,2,2]  R1182     7.6484262943267822e-02
    z[3,2,2]  R1183     6.1499748378992081e-02
    z[3,2,2]  R1184     2.4359221756458282e-01
    z[3,2,2]  R1185     1.7425008118152618e-01
    z[3,2,2]  R1186     -1.3354432582855225e-01
    z[3,2,2]  R1187     -1.3887584209442139e-01
    z[3,2,2]  R1188     -3.9314043521881104e-01
    z[3,2,2]  R1189     1.2395108491182327e-01
    z[3,2,2]  R1190     1.6706761717796326e-01
    z[3,2,2]  R1191     4.9057373404502869e-01
    z[3,2,2]  R1192     2.4277816712856293e-01
    z[3,2,2]  R1193     -1.8345075845718384e-01
    z[3,2,2]  R1194     5.1877623796463013e-01
    z[3,2,2]  R1195     0.0737726092338562
    z[3,2,2]  R1196     4.3167144060134888e-02
    z[3,2,2]  R1197     6.4395293593406677e-02
    z[3,2,2]  R1198     2.7652397751808167e-01
    z[3,2,2]  R1199     6.4655095338821411e-01
    z[3,2,2]  R1200     1.6862362623214722e-01
    z[3,2,2]  R1201     -2.0928969606757164e-02
    z[3,2,2]  R1202     1.7930777370929718e-01
    z[3,2,2]  R1203     3.1241157650947571e-01
    z[3,2,2]  R1204     -1.7183783650398254e-01
    z[3,2,2]  R1205     3.9254274964332581e-01
    z[3,2,2]  R1206     2.8326365351676941e-01
    z[3,2,2]  R1207     4.5729362964630127e-01
    z[3,2,2]  R1208     1.0710256546735764e-01
    z[3,2,2]  R1209     2.5877770781517029e-01
    z[3,2,2]  R1210     2.4274586141109467e-01
    z[3,2,2]  R1211     4.1924878954887390e-01
    z[3,2,2]  R1212     -3.1090310215950012e-01
    z[3,2,2]  R1213     4.1387838125228882e-01
    z[3,2,2]  R1214     2.2290448844432831e-01
    z[3,2,2]  R1215     1.3754753768444061e-01
    z[3,2,2]  R1216     -2.9798170551657677e-02
    z[3,2,2]  R1217     -2.5615268945693970e-01
    z[3,2,2]  R1218     3.2194903492927551e-01
    z[3,2,2]  R1219     -0.251189261674881
    z[3,2,2]  R1220     -1.7484319210052490e-01
    z[3,2,2]  R1221     -1.2572652101516724e-01
    z[3,2,2]  R1222     1.7241321504116058e-02
    z[3,2,2]  R1223     7.6796674728393555e-01
    z[3,2,2]  R1224     -7.9537652432918549e-02
    z[3,2,2]  R1225     3.1214842200279236e-01
    z[3,2,2]  R1226     -4.9438709020614624e-01
    z[3,2,2]  R1227     0.512950599193573
    z[3,2,2]  R1228     3.3939656615257263e-01
    z[3,2,2]  R1229     6.9249749183654785e-02
    z[3,2,2]  R1230     -2.1348603069782257e-01
    z[3,2,2]  R1231     -0.0791369378566742
    z[3,2,2]  R1232     2.7444148436188698e-02
    z[3,2,2]  R1233     -2.9958806931972504e-02
    z[3,2,2]  R1234     -6.3811767101287842e-01
    z[3,2,2]  R1235     2.1972709894180298e-01
    z[3,2,2]  R1236     2.5459833443164825e-02
    z[3,2,2]  R1237     5.6263640522956848e-02
    z[3,2,2]  R1238     3.9968156814575195e-01
    z[3,2,2]  R1239     -1.6684535145759583e-01
    z[3,2,2]  R1240     -6.5829616785049438e-01
    z[3,2,2]  R1241     -4.8338127136230469e-01
    z[3,2,2]  R1242     -6.8979966640472412e-01
    z[3,2,2]  R1243     5.9844231605529785e-01
    z[3,2,2]  R1244     -6.1854153871536255e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1108     -1
    z[3,2,3]  R1109     1
    z[3,2,3]  R1116     3.3893135190010071e-01
    z[3,2,3]  R1117     1.7238068580627441e-01
    z[3,2,3]  R1118     -8.0694389343261719e-01
    z[3,2,3]  R1119     2.2265070676803589e-01
    z[3,2,3]  R1120     -1.2656930088996887e-01
    z[3,2,3]  R1121     4.0449026226997375e-01
    z[3,2,3]  R1122     -0.569337010383606
    z[3,2,3]  R1123     -6.4385145902633667e-01
    z[3,2,3]  R1124     1.1762108653783798e-02
    z[3,2,3]  R1125     -2.0890416204929352e-01
    z[3,2,3]  R1126     0.820968508720398
    z[3,2,3]  R1127     6.7245924472808838e-01
    z[3,2,3]  R1128     6.3162380456924438e-01
    z[3,2,3]  R1129     7.0842069387435913e-01
    z[3,2,3]  R1130     6.5730887651443481e-01
    z[3,2,3]  R1131     7.4381065368652344e-01
    z[3,2,3]  R1132     8.7322556972503662e-01
    z[3,2,3]  R1133     2.5221675634384155e-01
    z[3,2,3]  R1134     -2.6172018051147461e-01
    z[3,2,3]  R1135     3.6002656817436218e-01
    z[3,2,3]  R1136     3.9744228124618530e-01
    z[3,2,3]  R1137     2.2856892645359039e-01
    z[3,2,3]  R1138     3.2866531610488892e-01
    z[3,2,3]  R1139     -1.9448810815811157e-01
    z[3,2,3]  R1140     -1.3624049723148346e-01
    z[3,2,3]  R1141     1.0560864955186844e-01
    z[3,2,3]  R1142     8.2533389329910278e-02
    z[3,2,3]  R1143     3.7692766636610031e-02
    z[3,2,3]  R1144     1.9963359832763672e-01
    z[3,2,3]  R1145     6.4280843734741211e-01
    z[3,2,3]  R1146     7.4181818962097168e-01
    z[3,2,3]  R1147     8.2144778966903687e-01
    z[3,2,3]  R1148     6.5293055772781372e-01
    z[3,2,3]  R1149     6.0793638229370117e-01
    z[3,2,3]  R1150     -2.7843394875526428e-01
    z[3,2,3]  R1151     -1.4027177821844816e-03
    z[3,2,3]  R1152     -1.1982208490371704e-01
    z[3,2,3]  R1153     -1.3696564733982086e-01
    z[3,2,3]  R1154     -4.2138215899467468e-01
    z[3,2,3]  R1155     2.5789457559585571e-01
    z[3,2,3]  R1156     7.6679818332195282e-02
    z[3,2,3]  R1157     7.4222676455974579e-02
    z[3,2,3]  R1158     6.7925274372100830e-02
    z[3,2,3]  R1159     4.2619869112968445e-02
    z[3,2,3]  R1160     1.5018087625503540e-01
    z[3,2,3]  R1161     -2.2287322208285332e-02
    z[3,2,3]  R1162     1.7334936559200287e-01
    z[3,2,3]  R1163     1.5530005097389221e-01
    z[3,2,3]  R1164     0.0453343540430069
    z[3,2,3]  R1165     6.0690528154373169e-01
    z[3,2,3]  R1166     5.7045966386795044e-01
    z[3,2,3]  R1167     5.9706658124923706e-01
    z[3,2,3]  R1168     6.5926498174667358e-01
    z[3,2,3]  R1169     5.5603188276290894e-01
    z[3,2,3]  R1170     5.6152331829071045e-01
    z[3,2,3]  R1171     6.3624918460845947e-01
    z[3,2,3]  R1172     4.3104144930839539e-01
    z[3,2,3]  R1173     -1.4310272037982941e-01
    z[3,2,3]  R1174     3.2803124189376831e-01
    z[3,2,3]  R1175     6.1675232648849487e-01
    z[3,2,3]  R1176     4.8381385207176208e-01
    z[3,2,3]  R1177     1.1437595635652542e-01
    z[3,2,3]  R1178     4.5385140925645828e-02
    z[3,2,3]  R1179     -4.7429639101028442e-01
    z[3,2,3]  R1180     -1.3199462555348873e-02
    z[3,2,3]  R1181     2.3878661915659904e-02
    z[3,2,3]  R1182     -1.5798424184322357e-01
    z[3,2,3]  R1183     -1.9470445811748505e-01
    z[3,2,3]  R1184     2.4173672497272491e-01
    z[3,2,3]  R1185     6.5899646282196045e-01
    z[3,2,3]  R1186     7.6095026731491089e-01
    z[3,2,3]  R1187     -7.1903415024280548e-02
    z[3,2,3]  R1188     7.1365468204021454e-02
    z[3,2,3]  R1189     -2.8981423377990723e-01
    z[3,2,3]  R1190     3.6298626661300659e-01
    z[3,2,3]  R1191     1.3017773628234863e-01
    z[3,2,3]  R1192     -1.4988839626312256e-01
    z[3,2,3]  R1193     -3.9614096283912659e-01
    z[3,2,3]  R1194     -3.0419471859931946e-01
    z[3,2,3]  R1195     -2.1315976977348328e-01
    z[3,2,3]  R1196     -2.4674201011657715e-01
    z[3,2,3]  R1197     6.0045200586318970e-01
    z[3,2,3]  R1198     0.831079363822937
    z[3,2,3]  R1199     2.4031335115432739e-01
    z[3,2,3]  R1200     1.3446410000324249e-01
    z[3,2,3]  R1201     1.8834297358989716e-01
    z[3,2,3]  R1202     -4.5580846071243286e-01
    z[3,2,3]  R1203     -4.4311785697937012e-01
    z[3,2,3]  R1204     3.0654057860374451e-01
    z[3,2,3]  R1205     -3.5950881242752075e-01
    z[3,2,3]  R1206     4.5377832651138306e-01
    z[3,2,3]  R1207     1.6288067400455475e-01
    z[3,2,3]  R1208     7.8887414932250977e-01
    z[3,2,3]  R1209     6.0306102037429810e-01
    z[3,2,3]  R1210     2.2944065928459167e-01
    z[3,2,3]  R1211     1.3756365515291691e-02
    z[3,2,3]  R1212     1.4490705728530884e-01
    z[3,2,3]  R1213     9.3097344040870667e-02
    z[3,2,3]  R1214     -8.0060526728630066e-02
    z[3,2,3]  R1215     7.7907508611679077e-01
    z[3,2,3]  R1216     7.3133997619152069e-02
    z[3,2,3]  R1217     7.1731686592102051e-01
    z[3,2,3]  R1218     -1.1281068623065948e-01
    z[3,2,3]  R1219     4.0450257062911987e-01
    z[3,2,3]  R1220     0.00385760678909719
    z[3,2,3]  R1221     -8.1982992589473724e-02
    z[3,2,3]  R1222     1.7649991810321808e-01
    z[3,2,3]  R1223     -2.6585987210273743e-01
    z[3,2,3]  R1224     -2.9219236969947815e-01
    z[3,2,3]  R1225     4.7909659147262573e-01
    z[3,2,3]  R1226     6.0675078630447388e-01
    z[3,2,3]  R1227     7.6968587934970856e-02
    z[3,2,3]  R1228     5.7475709915161133e-01
    z[3,2,3]  R1229     -1.0565434396266937e-01
    z[3,2,3]  R1230     -7.3891326785087585e-02
    z[3,2,3]  R1231     4.7077399492263794e-01
    z[3,2,3]  R1232     3.1705811619758606e-01
    z[3,2,3]  R1233     -3.5898125171661377e-01
    z[3,2,3]  R1234     -4.4451120495796204e-01
    z[3,2,3]  R1235     1.5172217041254044e-02
    z[3,2,3]  R1236     6.6756260395050049e-01
    z[3,2,3]  R1237     4.9172133207321167e-01
    z[3,2,3]  R1238     1.4260038733482361e-01
    z[3,2,3]  R1239     -4.7486531734466553e-01
    z[3,2,3]  R1240     -3.3216324448585510e-01
    z[3,2,3]  R1241     -2.8205469250679016e-01
    z[3,2,3]  R1242     -5.6749057024717331e-02
    z[3,2,3]  R1243     -1.0599813610315323e-01
    z[3,2,3]  R1244     -1.9939118623733521e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1110     -1
    z[3,2,4]  R1111     1
    z[3,2,4]  R1116     6.1544120311737061e-01
    z[3,2,4]  R1117     -1.6038011014461517e-01
    z[3,2,4]  R1118     -4.4960159808397293e-02
    z[3,2,4]  R1119     3.2772939652204514e-02
    z[3,2,4]  R1120     2.4203942716121674e-01
    z[3,2,4]  R1121     -7.1600514650344849e-01
    z[3,2,4]  R1122     -4.7515761852264404e-01
    z[3,2,4]  R1123     -4.7687861323356628e-01
    z[3,2,4]  R1124     -1.4801302552223206e-01
    z[3,2,4]  R1125     -8.6326800286769867e-02
    z[3,2,4]  R1126     -1.1482661962509155e-01
    z[3,2,4]  R1127     -7.4615702033042908e-03
    z[3,2,4]  R1128     -1.4398986101150513e-01
    z[3,2,4]  R1129     3.1648358702659607e-01
    z[3,2,4]  R1130     8.5796646773815155e-02
    z[3,2,4]  R1131     1.6937313973903656e-01
    z[3,2,4]  R1132     3.5484090447425842e-01
    z[3,2,4]  R1133     -5.3575527854263783e-03
    z[3,2,4]  R1134     -5.2903532981872559e-02
    z[3,2,4]  R1135     -5.3471463918685913e-01
    z[3,2,4]  R1136     -0.59151291847229
    z[3,2,4]  R1137     -7.9646848142147064e-02
    z[3,2,4]  R1138     -0.0201775711029768
    z[3,2,4]  R1139     4.5154165476560593e-02
    z[3,2,4]  R1140     1.6619296371936798e-01
    z[3,2,4]  R1141     1.6266991198062897e-01
    z[3,2,4]  R1142     -3.7581852078437805e-01
    z[3,2,4]  R1143     -2.7733482420444489e-03
    z[3,2,4]  R1144     2.2970676422119141e-01
    z[3,2,4]  R1145     -1.4652857184410095e-01
    z[3,2,4]  R1146     1.3311018049716949e-01
    z[3,2,4]  R1147     2.1338362246751785e-02
    z[3,2,4]  R1148     -4.9263462424278259e-01
    z[3,2,4]  R1149     1.3779577612876892e-01
    z[3,2,4]  R1150     -3.4126002341508865e-02
    z[3,2,4]  R1151     -1.0386031121015549e-01
    z[3,2,4]  R1152     -1.1333167552947998e-02
    z[3,2,4]  R1153     1.8678863346576691e-01
    z[3,2,4]  R1154     1.9302532076835632e-02
    z[3,2,4]  R1155     -1.1496312171220779e-01
    z[3,2,4]  R1156     6.1036888509988785e-02
    z[3,2,4]  R1157     1.1571945995092392e-01
    z[3,2,4]  R1158     -3.8888859748840332e-01
    z[3,2,4]  R1159     -1.1638686805963516e-01
    z[3,2,4]  R1160     -2.9812756180763245e-01
    z[3,2,4]  R1161     -1.9319224357604980e-01
    z[3,2,4]  R1162     1.6015812754631042e-01
    z[3,2,4]  R1163     4.2423516511917114e-01
    z[3,2,4]  R1164     -1.7063283594325185e-03
    z[3,2,4]  R1165     -3.7976670265197754e-01
    z[3,2,4]  R1166     -5.4631937295198441e-02
    z[3,2,4]  R1167     -4.7857353091239929e-01
    z[3,2,4]  R1168     1.5906213223934174e-01
    z[3,2,4]  R1169     1.1276460252702236e-02
    z[3,2,4]  R1170     5.0584155321121216e-01
    z[3,2,4]  R1171     2.3941858112812042e-01
    z[3,2,4]  R1172     -0.562581479549408
    z[3,2,4]  R1173     8.6790435016155243e-02
    z[3,2,4]  R1174     -1.2445009499788284e-01
    z[3,2,4]  R1175     4.0344062447547913e-01
    z[3,2,4]  R1176     -2.3010616004467010e-01
    z[3,2,4]  R1177     -2.1427439153194427e-01
    z[3,2,4]  R1178     -5.6533205509185791e-01
    z[3,2,4]  R1179     -1.5597687661647797e-01
    z[3,2,4]  R1180     -4.6064171195030212e-01
    z[3,2,4]  R1181     -6.3801310956478119e-02
    z[3,2,4]  R1182     5.2818089723587036e-01
    z[3,2,4]  R1183     4.9443128705024719e-01
    z[3,2,4]  R1184     -2.1657621860504150e-01
    z[3,2,4]  R1185     -1.7721369862556458e-02
    z[3,2,4]  R1186     3.4907300025224686e-02
    z[3,2,4]  R1187     -1.4428691565990448e-01
    z[3,2,4]  R1188     5.3972166031599045e-02
    z[3,2,4]  R1189     3.9959940314292908e-01
    z[3,2,4]  R1190     -4.4225663878023624e-03
    z[3,2,4]  R1191     5.6520360708236694e-01
    z[3,2,4]  R1192     2.9839816689491272e-01
    z[3,2,4]  R1193     -1.2828929722309113e-01
    z[3,2,4]  R1194     2.1192553639411926e-01
    z[3,2,4]  R1195     8.9194908738136292e-02
    z[3,2,4]  R1196     3.6870828270912170e-01
    z[3,2,4]  R1197     -3.1754696369171143e-01
    z[3,2,4]  R1198     2.1599155664443970e-01
    z[3,2,4]  R1199     3.5281282663345337e-01
    z[3,2,4]  R1200     -0.0717427060008049
    z[3,2,4]  R1201     1.4988392591476440e-01
    z[3,2,4]  R1202     1.9288735091686249e-01
    z[3,2,4]  R1203     -3.0036326497793198e-02
    z[3,2,4]  R1204     -2.2175274789333344e-02
    z[3,2,4]  R1205     -5.9873346239328384e-02
    z[3,2,4]  R1206     1.8889187276363373e-01
    z[3,2,4]  R1207     -2.0365279912948608e-01
    z[3,2,4]  R1208     -5.0281536579132080e-01
    z[3,2,4]  R1209     -7.1040540933609009e-02
    z[3,2,4]  R1210     7.4606128036975861e-02
    z[3,2,4]  R1211     2.8247093781828880e-02
    z[3,2,4]  R1212     8.0307433381676674e-04
    z[3,2,4]  R1213     -8.1252768635749817e-02
    z[3,2,4]  R1214     -6.5929013490676880e-01
    z[3,2,4]  R1215     -3.4355142712593079e-01
    z[3,2,4]  R1216     1.5855866670608521e-01
    z[3,2,4]  R1217     4.9937221407890320e-01
    z[3,2,4]  R1218     2.7032768726348877e-01
    z[3,2,4]  R1219     9.5205254852771759e-02
    z[3,2,4]  R1220     2.9664269089698792e-01
    z[3,2,4]  R1221     -3.3074134588241577e-01
    z[3,2,4]  R1222     -3.5192474722862244e-01
    z[3,2,4]  R1223     -2.4802875518798828e-01
    z[3,2,4]  R1224     -1.7932142317295074e-01
    z[3,2,4]  R1225     -1.3013717532157898e-01
    z[3,2,4]  R1226     -2.1842719614505768e-01
    z[3,2,4]  R1227     -3.3131629228591919e-01
    z[3,2,4]  R1228     3.6168730258941650e-01
    z[3,2,4]  R1229     7.0028595626354218e-02
    z[3,2,4]  R1230     3.1607393175363541e-02
    z[3,2,4]  R1231     -3.6443449556827545e-02
    z[3,2,4]  R1232     -7.0717319846153259e-02
    z[3,2,4]  R1233     -8.0152988433837891e-02
    z[3,2,4]  R1234     -9.5381431281566620e-02
    z[3,2,4]  R1235     -8.0028679221868515e-03
    z[3,2,4]  R1236     -4.6683689579367638e-03
    z[3,2,4]  R1237     2.3104159533977509e-01
    z[3,2,4]  R1238     -4.9141305498778820e-04
    z[3,2,4]  R1239     2.8214901685714722e-01
    z[3,2,4]  R1240     1.9687581062316895e-01
    z[3,2,4]  R1241     6.2029594182968140e-01
    z[3,2,4]  R1242     6.0424196720123291e-01
    z[3,2,4]  R1243     -3.1634208559989929e-01
    z[3,2,4]  R1244     6.7752408981323242e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1112     -1
    z[3,2,5]  R1113     1
    z[3,2,5]  R1116     1.3929626345634460e-01
    z[3,2,5]  R1117     -3.5279604792594910e-01
    z[3,2,5]  R1118     3.8220237940549850e-02
    z[3,2,5]  R1119     2.1354711055755615e-01
    z[3,2,5]  R1120     -4.0999558568000793e-01
    z[3,2,5]  R1121     8.4200963377952576e-02
    z[3,2,5]  R1122     2.8404369950294495e-01
    z[3,2,5]  R1123     3.8109812140464783e-01
    z[3,2,5]  R1124     7.8728175163269043e-01
    z[3,2,5]  R1125     6.7090344429016113e-01
    z[3,2,5]  R1126     3.5295647382736206e-01
    z[3,2,5]  R1127     -2.4163994938135147e-02
    z[3,2,5]  R1128     2.7940610051155090e-01
    z[3,2,5]  R1129     2.9542475938796997e-02
    z[3,2,5]  R1130     2.8805750608444214e-01
    z[3,2,5]  R1131     -1.4151780307292938e-01
    z[3,2,5]  R1132     -5.8375686407089233e-02
    z[3,2,5]  R1133     5.0904947519302368e-01
    z[3,2,5]  R1134     -2.0721639692783356e-01
    z[3,2,5]  R1135     2.2999155521392822e-01
    z[3,2,5]  R1136     1.7055776715278625e-01
    z[3,2,5]  R1137     4.8161312937736511e-01
    z[3,2,5]  R1138     -1.8148081004619598e-01
    z[3,2,5]  R1139     0.072996124625206
    z[3,2,5]  R1140     -1.3415264897048473e-02
    z[3,2,5]  R1141     2.1625134348869324e-01
    z[3,2,5]  R1142     0.118670254945755
    z[3,2,5]  R1143     -0.221003919839859
    z[3,2,5]  R1144     -3.0883875489234924e-01
    z[3,2,5]  R1145     -1.3896717131137848e-01
    z[3,2,5]  R1146     3.2583504915237427e-01
    z[3,2,5]  R1147     -8.8345922529697418e-02
    z[3,2,5]  R1148     2.5804251432418823e-01
    z[3,2,5]  R1149     2.5488847494125366e-01
    z[3,2,5]  R1150     -0.0645069107413292
    z[3,2,5]  R1151     2.2342254221439362e-01
    z[3,2,5]  R1152     5.1044980064034462e-03
    z[3,2,5]  R1153     -2.3616391420364380e-01
    z[3,2,5]  R1154     -3.1501868367195129e-01
    z[3,2,5]  R1155     0.0596165657043457
    z[3,2,5]  R1156     -1.5421052277088165e-01
    z[3,2,5]  R1157     2.5916749238967896e-01
    z[3,2,5]  R1158     3.5540476441383362e-02
    z[3,2,5]  R1159     2.4593852460384369e-01
    z[3,2,5]  R1160     2.6339060068130493e-01
    z[3,2,5]  R1161     -3.1690327450633049e-03
    z[3,2,5]  R1162     -2.6576307415962219e-01
    z[3,2,5]  R1163     7.5584337115287781e-02
    z[3,2,5]  R1164     -1.3800999522209167e-01
    z[3,2,5]  R1165     -2.3829996585845947e-01
    z[3,2,5]  R1166     -4.3946501612663269e-01
    z[3,2,5]  R1167     -3.5648146271705627e-01
    z[3,2,5]  R1168     -4.4333106279373169e-01
    z[3,2,5]  R1169     -1.6065049916505814e-02
    z[3,2,5]  R1170     1.9907447695732117e-01
    z[3,2,5]  R1171     1.5110961161553860e-02
    z[3,2,5]  R1172     4.7820255160331726e-01
    z[3,2,5]  R1173     3.8310371339321136e-02
    z[3,2,5]  R1174     8.0996805429458618e-01
    z[3,2,5]  R1175     -1.6127489507198334e-01
    z[3,2,5]  R1176     0.690273106098175
    z[3,2,5]  R1177     -3.0313533544540405e-01
    z[3,2,5]  R1178     7.4939350597560406e-03
    z[3,2,5]  R1179     0.0902993455529213
    z[3,2,5]  R1180     -4.8316949605941772e-01
    z[3,2,5]  R1181     1.0509271919727325e-01
    z[3,2,5]  R1182     -1.3863454759120941e-01
    z[3,2,5]  R1183     -5.6824021041393280e-02
    z[3,2,5]  R1184     2.8457471728324890e-01
    z[3,2,5]  R1185     -7.8652210533618927e-02
    z[3,2,5]  R1186     1.3941408693790436e-01
    z[3,2,5]  R1187     -5.6810826063156128e-01
    z[3,2,5]  R1188     2.0864079892635345e-01
    z[3,2,5]  R1189     3.5150960087776184e-01
    z[3,2,5]  R1190     3.6750671267509460e-01
    z[3,2,5]  R1191     8.7569728493690491e-02
    z[3,2,5]  R1192     5.7715136557817459e-02
    z[3,2,5]  R1193     2.7905693650245667e-01
    z[3,2,5]  R1194     -3.2278639078140259e-01
    z[3,2,5]  R1195     2.1576821804046631e-01
    z[3,2,5]  R1196     1.7159767448902130e-01
    z[3,2,5]  R1197     4.1267678141593933e-01
    z[3,2,5]  R1198     -1.2315607070922852e-01
    z[3,2,5]  R1199     -7.2828345000743866e-02
    z[3,2,5]  R1200     1.3304447755217552e-02
    z[3,2,5]  R1201     3.5721620917320251e-01
    z[3,2,5]  R1202     -5.7846039533615112e-01
    z[3,2,5]  R1203     -5.3011399507522583e-01
    z[3,2,5]  R1204     2.8076618909835815e-01
    z[3,2,5]  R1205     -2.3221983015537262e-01
    z[3,2,5]  R1206     1.2673947215080261e-01
    z[3,2,5]  R1207     -2.8106454014778137e-01
    z[3,2,5]  R1208     1.4398138225078583e-01
    z[3,2,5]  R1209     -2.9013365507125854e-01
    z[3,2,5]  R1210     1.1404684931039810e-01
    z[3,2,5]  R1211     -0.0963074192404747
    z[3,2,5]  R1212     -1.9495855271816254e-01
    z[3,2,5]  R1213     2.8034153580665588e-01
    z[3,2,5]  R1214     -0.323823481798172
    z[3,2,5]  R1215     3.7357372045516968e-01
    z[3,2,5]  R1216     -5.8438368141651154e-02
    z[3,2,5]  R1217     -7.9122297465801239e-02
    z[3,2,5]  R1218     -6.4036726951599121e-01
    z[3,2,5]  R1219     -1.8583790957927704e-01
    z[3,2,5]  R1220     -3.2547211647033691e-01
    z[3,2,5]  R1221     -2.4672269821166992e-01
    z[3,2,5]  R1222     -1.0942756384611130e-01
    z[3,2,5]  R1223     8.1528417766094208e-02
    z[3,2,5]  R1224     2.4342155456542969e-01
    z[3,2,5]  R1225     -2.1648842096328735e-01
    z[3,2,5]  R1226     -1.0613638907670975e-01
    z[3,2,5]  R1227     -6.7212902009487152e-02
    z[3,2,5]  R1228     2.4922121316194534e-02
    z[3,2,5]  R1229     -3.5402163863182068e-01
    z[3,2,5]  R1230     -2.4613919854164124e-01
    z[3,2,5]  R1231     -1.1041836440563202e-01
    z[3,2,5]  R1232     -0.289393812417984
    z[3,2,5]  R1233     -1.6315674409270287e-02
    z[3,2,5]  R1234     9.6302941441535950e-02
    z[3,2,5]  R1235     -1.8625985085964203e-01
    z[3,2,5]  R1236     1.9237220287322998e-01
    z[3,2,5]  R1237     -2.5953933596611023e-01
    z[3,2,5]  R1238     2.0789082348346710e-01
    z[3,2,5]  R1239     2.5498500093817711e-02
    z[3,2,5]  R1240     3.3535334467887878e-01
    z[3,2,5]  R1241     -2.5545755028724670e-01
    z[3,2,5]  R1242     -2.6062300801277161e-01
    z[3,2,5]  R1243     -3.4602773189544678e-01
    z[3,2,5]  R1244     8.0022260546684265e-02
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1114     -1
    z[3,2,6]  R1115     1
    z[3,2,6]  R1116     -2.7296485379338264e-02
    z[3,2,6]  R1117     -6.9551318883895874e-01
    z[3,2,6]  R1118     -9.9850669503211975e-03
    z[3,2,6]  R1119     1.2903241813182831e-01
    z[3,2,6]  R1120     0.614565372467041
    z[3,2,6]  R1121     4.7373369336128235e-01
    z[3,2,6]  R1122     -9.6105104312300682e-03
    z[3,2,6]  R1123     -1.6487258672714233e-01
    z[3,2,6]  R1124     -3.3270925283432007e-01
    z[3,2,6]  R1125     -1.5050514601171017e-02
    z[3,2,6]  R1126     2.5339301675558090e-02
    z[3,2,6]  R1127     4.1012936830520630e-01
    z[3,2,6]  R1128     -2.2790496051311493e-01
    z[3,2,6]  R1129     1.9731713831424713e-01
    z[3,2,6]  R1130     -8.0265142023563385e-02
    z[3,2,6]  R1131     -2.3283023387193680e-02
    z[3,2,6]  R1132     9.9094063043594360e-02
    z[3,2,6]  R1133     3.0142712593078613e-01
    z[3,2,6]  R1134     1.8220894038677216e-01
    z[3,2,6]  R1135     1.3260385394096375e-01
    z[3,2,6]  R1136     3.8297748565673828e-01
    z[3,2,6]  R1137     2.5355115532875061e-01
    z[3,2,6]  R1138     1.6693432629108429e-01
    z[3,2,6]  R1139     1.8298017978668213e-01
    z[3,2,6]  R1140     3.3461713790893555e-01
    z[3,2,6]  R1141     1.3354423642158508e-01
    z[3,2,6]  R1142     3.5253062844276428e-02
    z[3,2,6]  R1143     -3.4190145134925842e-01
    z[3,2,6]  R1144     3.3973187208175659e-02
    z[3,2,6]  R1145     3.8801971077919006e-01
    z[3,2,6]  R1146     3.2108667492866516e-01
    z[3,2,6]  R1147     2.4911326169967651e-01
    z[3,2,6]  R1148     2.7404436469078064e-01
    z[3,2,6]  R1149     2.4183419346809387e-01
    z[3,2,6]  R1150     -1.0881573706865311e-01
    z[3,2,6]  R1151     -2.9862526059150696e-01
    z[3,2,6]  R1152     0.0569380484521389
    z[3,2,6]  R1153     -5.3832545876502991e-02
    z[3,2,6]  R1154     -2.0913438498973846e-01
    z[3,2,6]  R1155     -1.3391232490539551e-01
    z[3,2,6]  R1156     -5.5602509528398514e-02
    z[3,2,6]  R1157     9.5840133726596832e-02
    z[3,2,6]  R1158     1.4374126493930817e-01
    z[3,2,6]  R1159     -1.5773972868919373e-01
    z[3,2,6]  R1160     0.0995691567659378
    z[3,2,6]  R1161     -7.6256953179836273e-02
    z[3,2,6]  R1162     1.4368730783462524e-01
    z[3,2,6]  R1163     -1.5407225489616394e-01
    z[3,2,6]  R1164     1.6710811853408813e-01
    z[3,2,6]  R1165     2.9666331410408020e-01
    z[3,2,6]  R1166     1.7016613855957985e-02
    z[3,2,6]  R1167     -2.0249038934707642e-01
    z[3,2,6]  R1168     -1.0928864032030106e-01
    z[3,2,6]  R1169     6.4154869318008423e-01
    z[3,2,6]  R1170     5.3281837701797485e-01
    z[3,2,6]  R1171     3.0589789152145386e-01
    z[3,2,6]  R1172     2.4263255298137665e-01
    z[3,2,6]  R1173     -2.9404631257057190e-01
    z[3,2,6]  R1174     2.7412512898445129e-01
    z[3,2,6]  R1175     4.8868253827095032e-02
    z[3,2,6]  R1176     8.0984615487977862e-04
    z[3,2,6]  R1177     -1.7131294310092926e-01
    z[3,2,6]  R1178     -7.9409822821617126e-02
    z[3,2,6]  R1179     3.2485806941986084e-01
    z[3,2,6]  R1180     8.6883746087551117e-02
    z[3,2,6]  R1181     1.9362498819828033e-01
    z[3,2,6]  R1182     3.8350574672222137e-02
    z[3,2,6]  R1183     -0.0493636429309845
    z[3,2,6]  R1184     9.3438185751438141e-02
    z[3,2,6]  R1185     5.2796018123626709e-01
    z[3,2,6]  R1186     -4.5082005858421326e-01
    z[3,2,6]  R1187     -3.9235156774520874e-01
    z[3,2,6]  R1188     -2.1485263109207153e-01
    z[3,2,6]  R1189     1.0583304613828659e-01
    z[3,2,6]  R1190     2.6076692342758179e-01
    z[3,2,6]  R1191     0.101309634745121
    z[3,2,6]  R1192     1.8745566904544830e-01
    z[3,2,6]  R1193     6.6299118101596832e-02
    z[3,2,6]  R1194     3.4264308214187622e-01
    z[3,2,6]  R1195     3.6983732134103775e-03
    z[3,2,6]  R1196     -3.6549825221300125e-02
    z[3,2,6]  R1197     5.6970596313476562e-02
    z[3,2,6]  R1198     -3.0264276266098022e-01
    z[3,2,6]  R1199     1.8844233453273773e-01
    z[3,2,6]  R1200     1.1336199194192886e-01
    z[3,2,6]  R1201     -1.3753518462181091e-01
    z[3,2,6]  R1202     2.8746657073497772e-02
    z[3,2,6]  R1203     3.0018597841262817e-01
    z[3,2,6]  R1204     -3.2065957784652710e-01
    z[3,2,6]  R1205     3.5046026110649109e-01
    z[3,2,6]  R1206     1.7457805573940277e-01
    z[3,2,6]  R1207     6.3427664339542389e-02
    z[3,2,6]  R1208     -1.4630000293254852e-01
    z[3,2,6]  R1209     -3.6590874195098877e-01
    z[3,2,6]  R1210     2.3407968692481518e-03
    z[3,2,6]  R1211     1.4083732664585114e-01
    z[3,2,6]  R1212     -4.5543056726455688e-01
    z[3,2,6]  R1213     3.6189281940460205e-01
    z[3,2,6]  R1214     5.9667207300662994e-02
    z[3,2,6]  R1215     3.9056394249200821e-02
    z[3,2,6]  R1216     -3.5774940252304077e-01
    z[3,2,6]  R1217     6.4626209437847137e-02
    z[3,2,6]  R1218     -5.1362957805395126e-02
    z[3,2,6]  R1219     -8.9024573564529419e-02
    z[3,2,6]  R1220     -3.5536146163940430e-01
    z[3,2,6]  R1221     -2.2796842455863953e-01
    z[3,2,6]  R1222     -2.1361030638217926e-01
    z[3,2,6]  R1223     1.4386756718158722e-01
    z[3,2,6]  R1224     -2.4325957521796227e-02
    z[3,2,6]  R1225     -2.0830747485160828e-01
    z[3,2,6]  R1226     -4.2313057184219360e-01
    z[3,2,6]  R1227     2.8809100389480591e-01
    z[3,2,6]  R1228     -2.6862871646881104e-01
    z[3,2,6]  R1229     -1.3921138644218445e-01
    z[3,2,6]  R1230     -2.2763611376285553e-01
    z[3,2,6]  R1231     -1.7594610154628754e-01
    z[3,2,6]  R1232     -3.2816660404205322e-01
    z[3,2,6]  R1233     1.3124649226665497e-01
    z[3,2,6]  R1234     -2.2728709876537323e-01
    z[3,2,6]  R1235     -8.9128427207469940e-02
    z[3,2,6]  R1236     -1.5429088473320007e-01
    z[3,2,6]  R1237     -1.7627786099910736e-01
    z[3,2,6]  R1238     -3.0590042471885681e-01
    z[3,2,6]  R1239     1.0293000936508179e-01
    z[3,2,6]  R1240     2.2025278210639954e-01
    z[3,2,6]  R1241     2.3513735830783844e-01
    z[3,2,6]  R1242     4.3343797326087952e-02
    z[3,2,6]  R1243     -5.9962904453277588e-01
    z[3,2,6]  R1244     1.0144189745187759e-01
    z[3,10,0]  R29       -1
    z[3,10,0]  R92       1
    z[3,10,0]  R1245     -1
    z[3,10,0]  R1246     1
    z[3,10,0]  R1259     -5.4492527246475220e-01
    z[3,10,0]  R1260     -2.1534349024295807e-01
    z[3,10,0]  R1261     -4.7673907876014709e-01
    z[3,10,0]  R1262     -9.1472655534744263e-01
    z[3,10,0]  R1263     -4.9899551272392273e-01
    z[3,10,0]  R1264     1.7937442660331726e-01
    z[3,10,0]  R1265     8.3233872428536415e-03
    z[3,10,0]  R1266     -1.1779731512069702e-01
    z[3,10,0]  R1267     7.5718045234680176e-02
    z[3,10,0]  R1268     4.3023101985454559e-02
    z[3,10,0]  R1269     2.5510627031326294e-01
    z[3,10,0]  R1270     0.611352801322937
    z[3,10,0]  R1271     6.4501678943634033e-01
    z[3,10,0]  R1272     5.7139158248901367e-01
    z[3,10,0]  R1273     5.8158326148986816e-01
    z[3,10,0]  R1274     3.6221036314964294e-01
    z[3,10,0]  R1275     2.8853756189346313e-01
    z[3,10,0]  R1276     3.1469497084617615e-01
    z[3,10,0]  R1277     2.6581883430480957e-01
    z[3,10,0]  R1278     5.8376115560531616e-01
    z[3,10,0]  R1279     3.7380585074424744e-01
    z[3,10,0]  R1280     4.8549342155456543e-01
    z[3,10,0]  R1281     6.9221824407577515e-01
    z[3,10,0]  R1282     2.0233023166656494e-01
    z[3,10,0]  R1283     1.2574322521686554e-01
    z[3,10,0]  R1284     2.5684067606925964e-01
    z[3,10,0]  R1285     1.1671365052461624e-01
    z[3,10,0]  R1286     2.3870217800140381e-01
    z[3,10,0]  R1287     1.5381184220314026e-01
    z[3,10,0]  R1288     5.1420134305953979e-01
    z[3,10,0]  R1289     2.2655582427978516e-01
    z[3,10,0]  R1290     0.283189594745636
    z[3,10,0]  R1291     2.7601400017738342e-01
    z[3,10,0]  R1292     3.5650694370269775e-01
    z[3,10,0]  R1293     2.8758205473423004e-02
    z[3,10,0]  R1294     2.2294494509696960e-01
    z[3,10,0]  R1295     2.8574812412261963e-01
    z[3,10,0]  R1296     -5.9725034981966019e-02
    z[3,10,0]  R1297     -0.0819258838891983
    z[3,10,0]  R1298     -6.6838681697845459e-01
    z[3,10,0]  R1299     -3.3950451016426086e-01
    z[3,10,0]  R1300     1.0117264464497566e-02
    z[3,10,0]  R1301     -0.0162187647074461
    z[3,10,0]  R1302     -8.2763278484344482e-01
    z[3,10,0]  R1303     -2.7650287747383118e-01
    z[3,10,0]  R1304     2.9769884422421455e-02
    z[3,10,0]  R1305     -1.5378569066524506e-01
    z[3,10,0]  R1306     5.0816637277603149e-01
    z[3,10,0]  R1307     4.3544137477874756e-01
    z[3,10,0]  R1308     2.2410778701305389e-01
    z[3,10,0]  R1309     1.3578887283802032e-01
    z[3,10,0]  R1310     2.4790754914283752e-01
    z[3,10,0]  R1311     4.4172096252441406e-01
    z[3,10,0]  R1312     6.0829824209213257e-01
    z[3,10,0]  R1313     3.7431082129478455e-01
    z[3,10,0]  R1314     2.1239463984966278e-01
    z[3,10,0]  R1315     2.1339268982410431e-01
    z[3,10,0]  R1316     0.872349202632904
    z[3,10,0]  R1317     5.4281413555145264e-01
    z[3,10,0]  R1318     6.7251950502395630e-01
    z[3,10,0]  R1319     4.9651819467544556e-01
    z[3,10,0]  R1320     4.6507778763771057e-01
    z[3,10,0]  R1321     7.3322528600692749e-01
    z[3,10,0]  R1322     3.9651879668235779e-01
    z[3,10,0]  R1323     5.5991929769515991e-01
    z[3,10,0]  R1324     4.7536960244178772e-01
    z[3,10,0]  R1325     7.4354261159896851e-01
    z[3,10,0]  R1326     1.3204505667090416e-02
    z[3,10,0]  R1327     7.8628438711166382e-01
    z[3,10,0]  R1328     7.2115379571914673e-01
    z[3,10,0]  R1329     2.7202799916267395e-01
    z[3,10,0]  R1330     4.1065916419029236e-01
    z[3,10,0]  R1331     0.0442354753613472
    z[3,10,0]  R1332     7.0270322263240814e-02
    z[3,10,0]  R1333     -1.0864923149347305e-01
    z[3,10,0]  R1334     1.6413313150405884e-01
    z[3,10,0]  R1335     0.278475821018219
    z[3,10,1]  R30       -1
    z[3,10,1]  R93       1
    z[3,10,1]  R1247     -1
    z[3,10,1]  R1248     1
    z[3,10,1]  R1259     4.3278518319129944e-01
    z[3,10,1]  R1260     5.2865236997604370e-01
    z[3,10,1]  R1261     3.2280489802360535e-02
    z[3,10,1]  R1262     -1.0213023424148560e-01
    z[3,10,1]  R1263     3.5205683112144470e-01
    z[3,10,1]  R1264     0.0873582735657692
    z[3,10,1]  R1265     3.0650734901428223e-01
    z[3,10,1]  R1266     -1.1546940356492996e-01
    z[3,10,1]  R1267     -8.3069734275341034e-02
    z[3,10,1]  R1268     2.9835087060928345e-01
    z[3,10,1]  R1269     -0.0591592937707901
    z[3,10,1]  R1270     -6.5233409404754639e-02
    z[3,10,1]  R1271     -1.7246234416961670e-01
    z[3,10,1]  R1272     5.4489899426698685e-02
    z[3,10,1]  R1273     -7.5519219040870667e-02
    z[3,10,1]  R1274     -2.4127402901649475e-01
    z[3,10,1]  R1275     -6.4986400306224823e-02
    z[3,10,1]  R1276     6.6145914793014526e-01
    z[3,10,1]  R1277     -8.6502122879028320e-01
    z[3,10,1]  R1278     2.5387245416641235e-01
    z[3,10,1]  R1279     3.3545008301734924e-01
    z[3,10,1]  R1280     0.605156421661377
    z[3,10,1]  R1281     1.9629713892936707e-01
    z[3,10,1]  R1282     -0.922296404838562
    z[3,10,1]  R1283     -9.0870171785354614e-01
    z[3,10,1]  R1284     -9.0678805112838745e-01
    z[3,10,1]  R1285     -9.0038394927978516e-01
    z[3,10,1]  R1286     -8.7704312801361084e-01
    z[3,10,1]  R1287     -8.8701063394546509e-01
    z[3,10,1]  R1288     1.3998055458068848e-01
    z[3,10,1]  R1289     4.0884265303611755e-01
    z[3,10,1]  R1290     2.9602622613310814e-02
    z[3,10,1]  R1291     2.5092095136642456e-02
    z[3,10,1]  R1292     4.8419770598411560e-01
    z[3,10,1]  R1293     -0.950893223285675
    z[3,10,1]  R1294     -8.8206022977828979e-01
    z[3,10,1]  R1295     -8.9106363058090210e-01
    z[3,10,1]  R1296     -7.3857551813125610e-01
    z[3,10,1]  R1297     -6.0511809587478638e-01
    z[3,10,1]  R1298     2.0451097190380096e-01
    z[3,10,1]  R1299     1.6970364749431610e-01
    z[3,10,1]  R1300     3.8651180267333984e-01
    z[3,10,1]  R1301     1.6717033088207245e-01
    z[3,10,1]  R1302     -0.0672031044960022
    z[3,10,1]  R1303     7.9678946733474731e-01
    z[3,10,1]  R1304     -8.5240013897418976e-02
    z[3,10,1]  R1305     -4.0651056915521622e-02
    z[3,10,1]  R1306     -3.5425412654876709e-01
    z[3,10,1]  R1307     3.7549253553152084e-02
    z[3,10,1]  R1308     -8.6507505178451538e-01
    z[3,10,1]  R1309     -5.4049581289291382e-01
    z[3,10,1]  R1310     -6.9356161355972290e-01
    z[3,10,1]  R1311     5.0812023878097534e-01
    z[3,10,1]  R1312     4.7119516134262085e-01
    z[3,10,1]  R1313     4.1220748424530029e-01
    z[3,10,1]  R1314     -1.0398972034454346e-01
    z[3,10,1]  R1315     -2.1055282652378082e-01
    z[3,10,1]  R1316     3.2922258973121643e-01
    z[3,10,1]  R1317     4.6399402618408203e-01
    z[3,10,1]  R1318     4.1465952992439270e-01
    z[3,10,1]  R1319     4.4240096211433411e-01
    z[3,10,1]  R1320     4.7214484214782715e-01
    z[3,10,1]  R1321     3.2677003741264343e-01
    z[3,10,1]  R1322     5.5083340406417847e-01
    z[3,10,1]  R1323     3.9904680848121643e-01
    z[3,10,1]  R1324     3.9580282568931580e-01
    z[3,10,1]  R1325     2.7318182587623596e-01
    z[3,10,1]  R1326     -5.3048763424158096e-02
    z[3,10,1]  R1327     4.3427705764770508e-01
    z[3,10,1]  R1328     3.6531442403793335e-01
    z[3,10,1]  R1329     -3.5306805372238159e-01
    z[3,10,1]  R1330     4.4144666194915771e-01
    z[3,10,1]  R1331     -1.1707927286624908e-01
    z[3,10,1]  R1332     -5.4121665656566620e-02
    z[3,10,1]  R1333     1.4069433510303497e-01
    z[3,10,1]  R1334     -0.326238214969635
    z[3,10,1]  R1335     -2.7720254659652710e-01
    z[3,10,2]  R31       -1
    z[3,10,2]  R94       1
    z[3,10,2]  R1249     -1
    z[3,10,2]  R1250     1
    z[3,10,2]  R1259     4.4297706335783005e-02
    z[3,10,2]  R1260     -1.0253424942493439e-01
    z[3,10,2]  R1261     3.4196120500564575e-01
    z[3,10,2]  R1262     1.9986394047737122e-01
    z[3,10,2]  R1263     -8.1668362021446228e-02
    z[3,10,2]  R1264     2.2891965508460999e-01
    z[3,10,2]  R1265     5.2468216419219971e-01
    z[3,10,2]  R1266     -3.9801257848739624e-01
    z[3,10,2]  R1267     -4.8457396030426025e-01
    z[3,10,2]  R1268     -6.3851737976074219e-01
    z[3,10,2]  R1269     -3.4500178694725037e-01
    z[3,10,2]  R1270     -3.0746594071388245e-02
    z[3,10,2]  R1271     0.0672302395105362
    z[3,10,2]  R1272     -1.6945162415504456e-01
    z[3,10,2]  R1273     3.5668212175369263e-01
    z[3,10,2]  R1274     4.5615750551223755e-01
    z[3,10,2]  R1275     1.0421478748321533e-01
    z[3,10,2]  R1276     2.2317555546760559e-01
    z[3,10,2]  R1277     1.8342211842536926e-01
    z[3,10,2]  R1278     3.2977712154388428e-01
    z[3,10,2]  R1279     2.5324460864067078e-01
    z[3,10,2]  R1280     2.0797833800315857e-01
    z[3,10,2]  R1281     5.5952745676040649e-01
    z[3,10,2]  R1282     -1.7250286042690277e-01
    z[3,10,2]  R1283     1.0942266322672367e-02
    z[3,10,2]  R1284     -9.7748890519142151e-02
    z[3,10,2]  R1285     -1.1095040291547775e-01
    z[3,10,2]  R1286     8.1540994346141815e-02
    z[3,10,2]  R1287     1.9990071654319763e-02
    z[3,10,2]  R1288     3.3385327458381653e-01
    z[3,10,2]  R1289     -6.5134182572364807e-02
    z[3,10,2]  R1290     4.1693288087844849e-01
    z[3,10,2]  R1291     -3.3540013432502747e-01
    z[3,10,2]  R1292     3.5556885600090027e-01
    z[3,10,2]  R1293     -1.6824441030621529e-02
    z[3,10,2]  R1294     1.4960496127605438e-01
    z[3,10,2]  R1295     3.2649624347686768e-01
    z[3,10,2]  R1296     -5.8190923929214478e-01
    z[3,10,2]  R1297     -5.5336314439773560e-01
    z[3,10,2]  R1298     1.8299490213394165e-01
    z[3,10,2]  R1299     3.7958872318267822e-01
    z[3,10,2]  R1300     -2.9160553216934204e-01
    z[3,10,2]  R1301     4.5660424232482910e-01
    z[3,10,2]  R1302     -0.388187050819397
    z[3,10,2]  R1303     -1.8965774774551392e-01
    z[3,10,2]  R1304     -1.1527680605649948e-01
    z[3,10,2]  R1305     7.1668088436126709e-01
    z[3,10,2]  R1306     -0.758916437625885
    z[3,10,2]  R1307     -5.8375918865203857e-01
    z[3,10,2]  R1308     -3.4515988826751709e-01
    z[3,10,2]  R1309     -4.1553407907485962e-01
    z[3,10,2]  R1310     -4.1028726100921631e-01
    z[3,10,2]  R1311     3.8359567523002625e-01
    z[3,10,2]  R1312     4.1494885087013245e-01
    z[3,10,2]  R1313     4.8236930370330811e-01
    z[3,10,2]  R1314     1.4560346305370331e-01
    z[3,10,2]  R1315     1.9953136146068573e-01
    z[3,10,2]  R1316     0.0757877379655838
    z[3,10,2]  R1317     1.2136624753475189e-01
    z[3,10,2]  R1318     -2.0224972069263458e-01
    z[3,10,2]  R1319     2.4038438498973846e-01
    z[3,10,2]  R1320     5.5548596382141113e-01
    z[3,10,2]  R1321     4.1592600941658020e-01
    z[3,10,2]  R1322     1.9032983481884003e-01
    z[3,10,2]  R1323     2.3802405595779419e-01
    z[3,10,2]  R1324     4.3518039584159851e-01
    z[3,10,2]  R1325     -0.337252676486969
    z[3,10,2]  R1326     -2.8646349906921387e-01
    z[3,10,2]  R1327     -0.155140221118927
    z[3,10,2]  R1328     4.3472087383270264e-01
    z[3,10,2]  R1329     -1.0040885210037231e-01
    z[3,10,2]  R1330     -2.0830640196800232e-01
    z[3,10,2]  R1331     -3.1272897124290466e-01
    z[3,10,2]  R1332     6.0756152868270874e-01
    z[3,10,2]  R1333     6.9988787174224854e-01
    z[3,10,2]  R1334     5.0023770332336426e-01
    z[3,10,2]  R1335     6.8567067384719849e-01
    z[3,10,3]  R32       -1
    z[3,10,3]  R95       1
    z[3,10,3]  R1251     -1
    z[3,10,3]  R1252     1
    z[3,10,3]  R1259     3.3893135190010071e-01
    z[3,10,3]  R1260     1.7238068580627441e-01
    z[3,10,3]  R1261     -8.0694389343261719e-01
    z[3,10,3]  R1262     2.2265070676803589e-01
    z[3,10,3]  R1263     -1.2656930088996887e-01
    z[3,10,3]  R1264     4.0449026226997375e-01
    z[3,10,3]  R1265     -0.569337010383606
    z[3,10,3]  R1266     -6.4385145902633667e-01
    z[3,10,3]  R1267     1.1762108653783798e-02
    z[3,10,3]  R1268     -2.0890416204929352e-01
    z[3,10,3]  R1269     0.820968508720398
    z[3,10,3]  R1270     6.7245924472808838e-01
    z[3,10,3]  R1271     6.3162380456924438e-01
    z[3,10,3]  R1272     7.0842069387435913e-01
    z[3,10,3]  R1273     6.5730887651443481e-01
    z[3,10,3]  R1274     7.4381065368652344e-01
    z[3,10,3]  R1275     8.7322556972503662e-01
    z[3,10,3]  R1276     2.5221675634384155e-01
    z[3,10,3]  R1277     -2.6172018051147461e-01
    z[3,10,3]  R1278     3.6002656817436218e-01
    z[3,10,3]  R1279     3.9744228124618530e-01
    z[3,10,3]  R1280     2.2856892645359039e-01
    z[3,10,3]  R1281     3.2866531610488892e-01
    z[3,10,3]  R1282     -1.9448810815811157e-01
    z[3,10,3]  R1283     -1.3624049723148346e-01
    z[3,10,3]  R1284     1.0560864955186844e-01
    z[3,10,3]  R1285     8.2533389329910278e-02
    z[3,10,3]  R1286     3.7692766636610031e-02
    z[3,10,3]  R1287     1.9963359832763672e-01
    z[3,10,3]  R1288     6.4280843734741211e-01
    z[3,10,3]  R1289     7.4181818962097168e-01
    z[3,10,3]  R1290     8.2144778966903687e-01
    z[3,10,3]  R1291     6.5293055772781372e-01
    z[3,10,3]  R1292     6.0793638229370117e-01
    z[3,10,3]  R1293     -2.7843394875526428e-01
    z[3,10,3]  R1294     -1.4027177821844816e-03
    z[3,10,3]  R1295     -1.1982208490371704e-01
    z[3,10,3]  R1296     -1.3696564733982086e-01
    z[3,10,3]  R1297     -4.2138215899467468e-01
    z[3,10,3]  R1298     -1.4703287184238434e-01
    z[3,10,3]  R1299     0.344155490398407
    z[3,10,3]  R1300     -7.7896326780319214e-01
    z[3,10,3]  R1301     -4.1236785054206848e-01
    z[3,10,3]  R1302     2.8863430023193359e-01
    z[3,10,3]  R1303     1.2976673245429993e-01
    z[3,10,3]  R1304     -2.0462699234485626e-01
    z[3,10,3]  R1305     1.9002115726470947e-01
    z[3,10,3]  R1306     -1.8746571242809296e-01
    z[3,10,3]  R1307     -7.2501905262470245e-02
    z[3,10,3]  R1308     -1.8766152858734131e-01
    z[3,10,3]  R1309     -4.7987371683120728e-01
    z[3,10,3]  R1310     -2.8874301910400391e-01
    z[3,10,3]  R1311     2.1433551609516144e-01
    z[3,10,3]  R1312     3.0487281084060669e-01
    z[3,10,3]  R1313     -3.9902785420417786e-01
    z[3,10,3]  R1314     7.7159124612808228e-01
    z[3,10,3]  R1315     8.8653421401977539e-01
    z[3,10,3]  R1316     -1.8677787482738495e-01
    z[3,10,3]  R1317     1.6629297286272049e-02
    z[3,10,3]  R1318     -4.0363001823425293e-01
    z[3,10,3]  R1319     -6.6593624651432037e-02
    z[3,10,3]  R1320     -2.3678421974182129e-01
    z[3,10,3]  R1321     -1.3033494353294373e-01
    z[3,10,3]  R1322     -9.6394300460815430e-02
    z[3,10,3]  R1323     -3.9456138014793396e-01
    z[3,10,3]  R1324     2.7258358895778656e-02
    z[3,10,3]  R1325     0.352216899394989
    z[3,10,3]  R1326     -6.2394142150878906e-01
    z[3,10,3]  R1327     -2.7145397663116455e-01
    z[3,10,3]  R1328     3.0579817295074463e-01
    z[3,10,3]  R1329     -3.1357815861701965e-01
    z[3,10,3]  R1330     2.1988305449485779e-01
    z[3,10,3]  R1331     -1.7302658408880234e-02
    z[3,10,3]  R1332     0.519877016544342
    z[3,10,3]  R1333     5.3139919042587280e-01
    z[3,10,3]  R1334     0.700632631778717
    z[3,10,3]  R1335     4.6535894274711609e-01
    z[3,10,4]  R33       -1
    z[3,10,4]  R96       1
    z[3,10,4]  R1253     -1
    z[3,10,4]  R1254     1
    z[3,10,4]  R1259     6.1544120311737061e-01
    z[3,10,4]  R1260     -1.6038011014461517e-01
    z[3,10,4]  R1261     -4.4960159808397293e-02
    z[3,10,4]  R1262     3.2772939652204514e-02
    z[3,10,4]  R1263     2.4203942716121674e-01
    z[3,10,4]  R1264     -7.1600514650344849e-01
    z[3,10,4]  R1265     -4.7515761852264404e-01
    z[3,10,4]  R1266     -4.7687861323356628e-01
    z[3,10,4]  R1267     -1.4801302552223206e-01
    z[3,10,4]  R1268     -8.6326800286769867e-02
    z[3,10,4]  R1269     -1.1482661962509155e-01
    z[3,10,4]  R1270     -7.4615702033042908e-03
    z[3,10,4]  R1271     -1.4398986101150513e-01
    z[3,10,4]  R1272     3.1648358702659607e-01
    z[3,10,4]  R1273     8.5796646773815155e-02
    z[3,10,4]  R1274     1.6937313973903656e-01
    z[3,10,4]  R1275     3.5484090447425842e-01
    z[3,10,4]  R1276     -5.3575527854263783e-03
    z[3,10,4]  R1277     -5.2903532981872559e-02
    z[3,10,4]  R1278     -5.3471463918685913e-01
    z[3,10,4]  R1279     -0.59151291847229
    z[3,10,4]  R1280     -7.9646848142147064e-02
    z[3,10,4]  R1281     -0.0201775711029768
    z[3,10,4]  R1282     4.5154165476560593e-02
    z[3,10,4]  R1283     1.6619296371936798e-01
    z[3,10,4]  R1284     1.6266991198062897e-01
    z[3,10,4]  R1285     -3.7581852078437805e-01
    z[3,10,4]  R1286     -2.7733482420444489e-03
    z[3,10,4]  R1287     2.2970676422119141e-01
    z[3,10,4]  R1288     -1.4652857184410095e-01
    z[3,10,4]  R1289     1.3311018049716949e-01
    z[3,10,4]  R1290     2.1338362246751785e-02
    z[3,10,4]  R1291     -4.9263462424278259e-01
    z[3,10,4]  R1292     1.3779577612876892e-01
    z[3,10,4]  R1293     -3.4126002341508865e-02
    z[3,10,4]  R1294     -1.0386031121015549e-01
    z[3,10,4]  R1295     -1.1333167552947998e-02
    z[3,10,4]  R1296     1.8678863346576691e-01
    z[3,10,4]  R1297     1.9302532076835632e-02
    z[3,10,4]  R1298     2.2983600199222565e-01
    z[3,10,4]  R1299     2.8720948100090027e-01
    z[3,10,4]  R1300     1.3539366424083710e-01
    z[3,10,4]  R1301     -7.3919445276260376e-01
    z[3,10,4]  R1302     -1.0036127269268036e-01
    z[3,10,4]  R1303     1.3280834257602692e-01
    z[3,10,4]  R1304     -0.706744372844696
    z[3,10,4]  R1305     -1.8327893316745758e-01
    z[3,10,4]  R1306     -6.9730438292026520e-02
    z[3,10,4]  R1307     -2.1937829256057739e-01
    z[3,10,4]  R1308     -7.9963423311710358e-02
    z[3,10,4]  R1309     -2.9370233416557312e-01
    z[3,10,4]  R1310     1.1862007901072502e-02
    z[3,10,4]  R1311     -2.9073095321655273e-01
    z[3,10,4]  R1312     5.1163870841264725e-02
    z[3,10,4]  R1313     -5.2366904914379120e-02
    z[3,10,4]  R1314     5.1369827985763550e-01
    z[3,10,4]  R1315     2.8623512387275696e-01
    z[3,10,4]  R1316     -4.3542243540287018e-02
    z[3,10,4]  R1317     -4.9253765493631363e-02
    z[3,10,4]  R1318     -3.7257453799247742e-01
    z[3,10,4]  R1319     -6.8323785066604614e-01
    z[3,10,4]  R1320     -4.4237226247787476e-01
    z[3,10,4]  R1321     -2.4362699687480927e-01
    z[3,10,4]  R1322     4.4362466782331467e-02
    z[3,10,4]  R1323     -4.6004977822303772e-01
    z[3,10,4]  R1324     -5.4237610101699829e-01
    z[3,10,4]  R1325     6.8480938673019409e-02
    z[3,10,4]  R1326     -7.0628547668457031e-01
    z[3,10,4]  R1327     2.0449408888816833e-01
    z[3,10,4]  R1328     -1.8453244864940643e-01
    z[3,10,4]  R1329     -6.0103225708007812e-01
    z[3,10,4]  R1330     -0.672758936882019
    z[3,10,4]  R1331     -1.7281450331211090e-01
    z[3,10,4]  R1332     0.0520535483956337
    z[3,10,4]  R1333     -1.3552919030189514e-01
    z[3,10,4]  R1334     -8.4265895187854767e-02
    z[3,10,4]  R1335     -2.3378261923789978e-01
    z[3,10,5]  R34       -1
    z[3,10,5]  R97       1
    z[3,10,5]  R1255     -1
    z[3,10,5]  R1256     1
    z[3,10,5]  R1259     1.3929626345634460e-01
    z[3,10,5]  R1260     -3.5279604792594910e-01
    z[3,10,5]  R1261     3.8220237940549850e-02
    z[3,10,5]  R1262     2.1354711055755615e-01
    z[3,10,5]  R1263     -4.0999558568000793e-01
    z[3,10,5]  R1264     8.4200963377952576e-02
    z[3,10,5]  R1265     2.8404369950294495e-01
    z[3,10,5]  R1266     3.8109812140464783e-01
    z[3,10,5]  R1267     7.8728175163269043e-01
    z[3,10,5]  R1268     6.7090344429016113e-01
    z[3,10,5]  R1269     3.5295647382736206e-01
    z[3,10,5]  R1270     -2.4163994938135147e-02
    z[3,10,5]  R1271     2.7940610051155090e-01
    z[3,10,5]  R1272     2.9542475938796997e-02
    z[3,10,5]  R1273     2.8805750608444214e-01
    z[3,10,5]  R1274     -1.4151780307292938e-01
    z[3,10,5]  R1275     -5.8375686407089233e-02
    z[3,10,5]  R1276     5.0904947519302368e-01
    z[3,10,5]  R1277     -2.0721639692783356e-01
    z[3,10,5]  R1278     2.2999155521392822e-01
    z[3,10,5]  R1279     1.7055776715278625e-01
    z[3,10,5]  R1280     4.8161312937736511e-01
    z[3,10,5]  R1281     -1.8148081004619598e-01
    z[3,10,5]  R1282     0.072996124625206
    z[3,10,5]  R1283     -1.3415264897048473e-02
    z[3,10,5]  R1284     2.1625134348869324e-01
    z[3,10,5]  R1285     0.118670254945755
    z[3,10,5]  R1286     -0.221003919839859
    z[3,10,5]  R1287     -3.0883875489234924e-01
    z[3,10,5]  R1288     -1.3896717131137848e-01
    z[3,10,5]  R1289     3.2583504915237427e-01
    z[3,10,5]  R1290     -8.8345922529697418e-02
    z[3,10,5]  R1291     2.5804251432418823e-01
    z[3,10,5]  R1292     2.5488847494125366e-01
    z[3,10,5]  R1293     -0.0645069107413292
    z[3,10,5]  R1294     2.2342254221439362e-01
    z[3,10,5]  R1295     5.1044980064034462e-03
    z[3,10,5]  R1296     -2.3616391420364380e-01
    z[3,10,5]  R1297     -3.1501868367195129e-01
    z[3,10,5]  R1298     4.3534699082374573e-01
    z[3,10,5]  R1299     -3.0110970139503479e-01
    z[3,10,5]  R1300     -7.4945211410522461e-02
    z[3,10,5]  R1301     -2.1428455412387848e-01
    z[3,10,5]  R1302     -2.2916541993618011e-01
    z[3,10,5]  R1303     0.117099329829216
    z[3,10,5]  R1304     -2.9089614748954773e-01
    z[3,10,5]  R1305     6.2324327230453491e-01
    z[3,10,5]  R1306     1.7301371321082115e-02
    z[3,10,5]  R1307     -0.616300642490387
    z[3,10,5]  R1308     -1.0651084035634995e-01
    z[3,10,5]  R1309     0.0874929204583168
    z[3,10,5]  R1310     -2.5583449006080627e-01
    z[3,10,5]  R1311     1.8713390827178955e-01
    z[3,10,5]  R1312     -7.1029275655746460e-02
    z[3,10,5]  R1313     5.2788585424423218e-01
    z[3,10,5]  R1314     2.3108594119548798e-01
    z[3,10,5]  R1315     4.7886174172163010e-02
    z[3,10,5]  R1316     2.9599308967590332e-01
    z[3,10,5]  R1317     0.613882303237915
    z[3,10,5]  R1318     1.8186467885971069e-01
    z[3,10,5]  R1319     1.5288820862770081e-01
    z[3,10,5]  R1320     0.002495281631127
    z[3,10,5]  R1321     1.7671933397650719e-02
    z[3,10,5]  R1322     -1.7113471031188965e-01
    z[3,10,5]  R1323     -3.1766149401664734e-01
    z[3,10,5]  R1324     -2.5111809372901917e-01
    z[3,10,5]  R1325     -7.8134298324584961e-02
    z[3,10,5]  R1326     -1.5438029170036316e-01
    z[3,10,5]  R1327     -2.3001509904861450e-01
    z[3,10,5]  R1328     1.1281652748584747e-01
    z[3,10,5]  R1329     -4.9397316575050354e-01
    z[3,10,5]  R1330     1.1745315045118332e-01
    z[3,10,5]  R1331     -3.0929425358772278e-01
    z[3,10,5]  R1332     5.5347144603729248e-01
    z[3,10,5]  R1333     3.9725202322006226e-01
    z[3,10,5]  R1334     2.0519931614398956e-01
    z[3,10,5]  R1335     2.6762205362319946e-01
    z[3,10,6]  R35       -1
    z[3,10,6]  R98       1
    z[3,10,6]  R1257     -1
    z[3,10,6]  R1258     1
    z[3,10,6]  R1259     -2.7296485379338264e-02
    z[3,10,6]  R1260     -6.9551318883895874e-01
    z[3,10,6]  R1261     -9.9850669503211975e-03
    z[3,10,6]  R1262     1.2903241813182831e-01
    z[3,10,6]  R1263     0.614565372467041
    z[3,10,6]  R1264     4.7373369336128235e-01
    z[3,10,6]  R1265     -9.6105104312300682e-03
    z[3,10,6]  R1266     -1.6487258672714233e-01
    z[3,10,6]  R1267     -3.3270925283432007e-01
    z[3,10,6]  R1268     -1.5050514601171017e-02
    z[3,10,6]  R1269     2.5339301675558090e-02
    z[3,10,6]  R1270     4.1012936830520630e-01
    z[3,10,6]  R1271     -2.2790496051311493e-01
    z[3,10,6]  R1272     1.9731713831424713e-01
    z[3,10,6]  R1273     -8.0265142023563385e-02
    z[3,10,6]  R1274     -2.3283023387193680e-02
    z[3,10,6]  R1275     9.9094063043594360e-02
    z[3,10,6]  R1276     3.0142712593078613e-01
    z[3,10,6]  R1277     1.8220894038677216e-01
    z[3,10,6]  R1278     1.3260385394096375e-01
    z[3,10,6]  R1279     3.8297748565673828e-01
    z[3,10,6]  R1280     2.5355115532875061e-01
    z[3,10,6]  R1281     1.6693432629108429e-01
    z[3,10,6]  R1282     1.8298017978668213e-01
    z[3,10,6]  R1283     3.3461713790893555e-01
    z[3,10,6]  R1284     1.3354423642158508e-01
    z[3,10,6]  R1285     3.5253062844276428e-02
    z[3,10,6]  R1286     -3.4190145134925842e-01
    z[3,10,6]  R1287     3.3973187208175659e-02
    z[3,10,6]  R1288     3.8801971077919006e-01
    z[3,10,6]  R1289     3.2108667492866516e-01
    z[3,10,6]  R1290     2.4911326169967651e-01
    z[3,10,6]  R1291     2.7404436469078064e-01
    z[3,10,6]  R1292     2.4183419346809387e-01
    z[3,10,6]  R1293     -1.0881573706865311e-01
    z[3,10,6]  R1294     -2.9862526059150696e-01
    z[3,10,6]  R1295     0.0569380484521389
    z[3,10,6]  R1296     -5.3832545876502991e-02
    z[3,10,6]  R1297     -2.0913438498973846e-01
    z[3,10,6]  R1298     4.6257647871971130e-01
    z[3,10,6]  R1299     -6.4826726913452148e-01
    z[3,10,6]  R1300     -3.6707019805908203e-01
    z[3,10,6]  R1301     -3.0498981475830078e-02
    z[3,10,6]  R1302     1.1798144131898880e-01
    z[3,10,6]  R1303     4.5223093032836914e-01
    z[3,10,6]  R1304     -0.593783438205719
    z[3,10,6]  R1305     5.4171487689018250e-02
    z[3,10,6]  R1306     -3.4121882636100054e-03
    z[3,10,6]  R1307     1.8707311153411865e-01
    z[3,10,6]  R1308     -1.7125976085662842e-01
    z[3,10,6]  R1309     4.3881905078887939e-01
    z[3,10,6]  R1310     3.7445154786109924e-01
    z[3,10,6]  R1311     -4.8380523920059204e-01
    z[3,10,6]  R1312     -3.6763486266136169e-01
    z[3,10,6]  R1313     -1.2910179793834686e-01
    z[3,10,6]  R1314     -1.0116583108901978e-01
    z[3,10,6]  R1315     1.2317669577896595e-02
    z[3,10,6]  R1316     2.1949866786599159e-02
    z[3,10,6]  R1317     -0.309481143951416
    z[3,10,6]  R1318     -0.00813719630241394
    z[3,10,6]  R1319     7.3095001280307770e-02
    z[3,10,6]  R1320     -2.1239452064037323e-02
    z[3,10,6]  R1321     3.2550552487373352e-01
    z[3,10,6]  R1322     -6.8013453483581543e-01
    z[3,10,6]  R1323     4.8612061887979507e-02
    z[3,10,6]  R1324     0.264587938785553
    z[3,10,6]  R1325     -0.352030485868454
    z[3,10,6]  R1326     5.4543163627386093e-02
    z[3,10,6]  R1327     2.6071846485137939e-02
    z[3,10,6]  R1328     1.3117910921573639e-01
    z[3,10,6]  R1329     -2.9611018300056458e-01
    z[3,10,6]  R1330     -2.7989998459815979e-01
    z[3,10,6]  R1331     -8.7218630313873291e-01
    z[3,10,6]  R1332     2.0902042090892792e-01
    z[3,10,6]  R1333     -1.4140348136425018e-01
    z[3,10,6]  R1334     2.7622020244598389e-01
    z[3,10,6]  R1335     1.8064013123512268e-01
    z[10,3,0]  R29       1
    z[10,3,0]  R92       -1
    z[10,3,0]  R1336     -1
    z[10,3,0]  R1337     1
    z[10,3,0]  R1350     -6.6838681697845459e-01
    z[10,3,0]  R1351     -3.3950451016426086e-01
    z[10,3,0]  R1352     1.0117264464497566e-02
    z[10,3,0]  R1353     -0.0162187647074461
    z[10,3,0]  R1354     -8.2763278484344482e-01
    z[10,3,0]  R1355     -2.7650287747383118e-01
    z[10,3,0]  R1356     2.9769884422421455e-02
    z[10,3,0]  R1357     -1.5378569066524506e-01
    z[10,3,0]  R1358     5.0816637277603149e-01
    z[10,3,0]  R1359     4.3544137477874756e-01
    z[10,3,0]  R1360     2.2410778701305389e-01
    z[10,3,0]  R1361     1.3578887283802032e-01
    z[10,3,0]  R1362     2.4790754914283752e-01
    z[10,3,0]  R1363     4.4172096252441406e-01
    z[10,3,0]  R1364     6.0829824209213257e-01
    z[10,3,0]  R1365     3.7431082129478455e-01
    z[10,3,0]  R1366     2.1239463984966278e-01
    z[10,3,0]  R1367     2.1339268982410431e-01
    z[10,3,0]  R1368     0.872349202632904
    z[10,3,0]  R1369     5.4281413555145264e-01
    z[10,3,0]  R1370     6.7251950502395630e-01
    z[10,3,0]  R1371     4.9651819467544556e-01
    z[10,3,0]  R1372     4.6507778763771057e-01
    z[10,3,0]  R1373     7.3322528600692749e-01
    z[10,3,0]  R1374     3.9651879668235779e-01
    z[10,3,0]  R1375     5.5991929769515991e-01
    z[10,3,0]  R1376     4.7536960244178772e-01
    z[10,3,0]  R1377     7.4354261159896851e-01
    z[10,3,0]  R1378     1.3204505667090416e-02
    z[10,3,0]  R1379     7.8628438711166382e-01
    z[10,3,0]  R1380     7.2115379571914673e-01
    z[10,3,0]  R1381     2.7202799916267395e-01
    z[10,3,0]  R1382     4.1065916419029236e-01
    z[10,3,0]  R1383     0.0442354753613472
    z[10,3,0]  R1384     7.0270322263240814e-02
    z[10,3,0]  R1385     -1.0864923149347305e-01
    z[10,3,0]  R1386     1.6413313150405884e-01
    z[10,3,0]  R1387     0.278475821018219
    z[10,3,0]  R1388     -5.4492527246475220e-01
    z[10,3,0]  R1389     -2.1534349024295807e-01
    z[10,3,0]  R1390     -4.7673907876014709e-01
    z[10,3,0]  R1391     -9.1472655534744263e-01
    z[10,3,0]  R1392     -4.9899551272392273e-01
    z[10,3,0]  R1393     1.7937442660331726e-01
    z[10,3,0]  R1394     8.3233872428536415e-03
    z[10,3,0]  R1395     -1.1779731512069702e-01
    z[10,3,0]  R1396     7.5718045234680176e-02
    z[10,3,0]  R1397     4.3023101985454559e-02
    z[10,3,0]  R1398     2.5510627031326294e-01
    z[10,3,0]  R1399     0.611352801322937
    z[10,3,0]  R1400     6.4501678943634033e-01
    z[10,3,0]  R1401     5.7139158248901367e-01
    z[10,3,0]  R1402     5.8158326148986816e-01
    z[10,3,0]  R1403     3.6221036314964294e-01
    z[10,3,0]  R1404     2.8853756189346313e-01
    z[10,3,0]  R1405     3.1469497084617615e-01
    z[10,3,0]  R1406     2.6581883430480957e-01
    z[10,3,0]  R1407     5.8376115560531616e-01
    z[10,3,0]  R1408     3.7380585074424744e-01
    z[10,3,0]  R1409     4.8549342155456543e-01
    z[10,3,0]  R1410     6.9221824407577515e-01
    z[10,3,0]  R1411     2.0233023166656494e-01
    z[10,3,0]  R1412     1.2574322521686554e-01
    z[10,3,0]  R1413     2.5684067606925964e-01
    z[10,3,0]  R1414     1.1671365052461624e-01
    z[10,3,0]  R1415     2.3870217800140381e-01
    z[10,3,0]  R1416     1.5381184220314026e-01
    z[10,3,0]  R1417     5.1420134305953979e-01
    z[10,3,0]  R1418     2.2655582427978516e-01
    z[10,3,0]  R1419     0.283189594745636
    z[10,3,0]  R1420     2.7601400017738342e-01
    z[10,3,0]  R1421     3.5650694370269775e-01
    z[10,3,0]  R1422     2.8758205473423004e-02
    z[10,3,0]  R1423     2.2294494509696960e-01
    z[10,3,0]  R1424     2.8574812412261963e-01
    z[10,3,0]  R1425     -5.9725034981966019e-02
    z[10,3,0]  R1426     -0.0819258838891983
    z[10,3,1]  R30       1
    z[10,3,1]  R93       -1
    z[10,3,1]  R1338     -1
    z[10,3,1]  R1339     1
    z[10,3,1]  R1350     2.0451097190380096e-01
    z[10,3,1]  R1351     1.6970364749431610e-01
    z[10,3,1]  R1352     3.8651180267333984e-01
    z[10,3,1]  R1353     1.6717033088207245e-01
    z[10,3,1]  R1354     -0.0672031044960022
    z[10,3,1]  R1355     7.9678946733474731e-01
    z[10,3,1]  R1356     -8.5240013897418976e-02
    z[10,3,1]  R1357     -4.0651056915521622e-02
    z[10,3,1]  R1358     -3.5425412654876709e-01
    z[10,3,1]  R1359     3.7549253553152084e-02
    z[10,3,1]  R1360     -8.6507505178451538e-01
    z[10,3,1]  R1361     -5.4049581289291382e-01
    z[10,3,1]  R1362     -6.9356161355972290e-01
    z[10,3,1]  R1363     5.0812023878097534e-01
    z[10,3,1]  R1364     4.7119516134262085e-01
    z[10,3,1]  R1365     4.1220748424530029e-01
    z[10,3,1]  R1366     -1.0398972034454346e-01
    z[10,3,1]  R1367     -2.1055282652378082e-01
    z[10,3,1]  R1368     3.2922258973121643e-01
    z[10,3,1]  R1369     4.6399402618408203e-01
    z[10,3,1]  R1370     4.1465952992439270e-01
    z[10,3,1]  R1371     4.4240096211433411e-01
    z[10,3,1]  R1372     4.7214484214782715e-01
    z[10,3,1]  R1373     3.2677003741264343e-01
    z[10,3,1]  R1374     5.5083340406417847e-01
    z[10,3,1]  R1375     3.9904680848121643e-01
    z[10,3,1]  R1376     3.9580282568931580e-01
    z[10,3,1]  R1377     2.7318182587623596e-01
    z[10,3,1]  R1378     -5.3048763424158096e-02
    z[10,3,1]  R1379     4.3427705764770508e-01
    z[10,3,1]  R1380     3.6531442403793335e-01
    z[10,3,1]  R1381     -3.5306805372238159e-01
    z[10,3,1]  R1382     4.4144666194915771e-01
    z[10,3,1]  R1383     -1.1707927286624908e-01
    z[10,3,1]  R1384     -5.4121665656566620e-02
    z[10,3,1]  R1385     1.4069433510303497e-01
    z[10,3,1]  R1386     -0.326238214969635
    z[10,3,1]  R1387     -2.7720254659652710e-01
    z[10,3,1]  R1388     4.3278518319129944e-01
    z[10,3,1]  R1389     5.2865236997604370e-01
    z[10,3,1]  R1390     3.2280489802360535e-02
    z[10,3,1]  R1391     -1.0213023424148560e-01
    z[10,3,1]  R1392     3.5205683112144470e-01
    z[10,3,1]  R1393     0.0873582735657692
    z[10,3,1]  R1394     3.0650734901428223e-01
    z[10,3,1]  R1395     -1.1546940356492996e-01
    z[10,3,1]  R1396     -8.3069734275341034e-02
    z[10,3,1]  R1397     2.9835087060928345e-01
    z[10,3,1]  R1398     -0.0591592937707901
    z[10,3,1]  R1399     -6.5233409404754639e-02
    z[10,3,1]  R1400     -1.7246234416961670e-01
    z[10,3,1]  R1401     5.4489899426698685e-02
    z[10,3,1]  R1402     -7.5519219040870667e-02
    z[10,3,1]  R1403     -2.4127402901649475e-01
    z[10,3,1]  R1404     -6.4986400306224823e-02
    z[10,3,1]  R1405     6.6145914793014526e-01
    z[10,3,1]  R1406     -8.6502122879028320e-01
    z[10,3,1]  R1407     2.5387245416641235e-01
    z[10,3,1]  R1408     3.3545008301734924e-01
    z[10,3,1]  R1409     0.605156421661377
    z[10,3,1]  R1410     1.9629713892936707e-01
    z[10,3,1]  R1411     -0.922296404838562
    z[10,3,1]  R1412     -9.0870171785354614e-01
    z[10,3,1]  R1413     -9.0678805112838745e-01
    z[10,3,1]  R1414     -9.0038394927978516e-01
    z[10,3,1]  R1415     -8.7704312801361084e-01
    z[10,3,1]  R1416     -8.8701063394546509e-01
    z[10,3,1]  R1417     1.3998055458068848e-01
    z[10,3,1]  R1418     4.0884265303611755e-01
    z[10,3,1]  R1419     2.9602622613310814e-02
    z[10,3,1]  R1420     2.5092095136642456e-02
    z[10,3,1]  R1421     4.8419770598411560e-01
    z[10,3,1]  R1422     -0.950893223285675
    z[10,3,1]  R1423     -8.8206022977828979e-01
    z[10,3,1]  R1424     -8.9106363058090210e-01
    z[10,3,1]  R1425     -7.3857551813125610e-01
    z[10,3,1]  R1426     -6.0511809587478638e-01
    z[10,3,2]  R31       1
    z[10,3,2]  R94       -1
    z[10,3,2]  R1340     -1
    z[10,3,2]  R1341     1
    z[10,3,2]  R1350     1.8299490213394165e-01
    z[10,3,2]  R1351     3.7958872318267822e-01
    z[10,3,2]  R1352     -2.9160553216934204e-01
    z[10,3,2]  R1353     4.5660424232482910e-01
    z[10,3,2]  R1354     -0.388187050819397
    z[10,3,2]  R1355     -1.8965774774551392e-01
    z[10,3,2]  R1356     -1.1527680605649948e-01
    z[10,3,2]  R1357     7.1668088436126709e-01
    z[10,3,2]  R1358     -0.758916437625885
    z[10,3,2]  R1359     -5.8375918865203857e-01
    z[10,3,2]  R1360     -3.4515988826751709e-01
    z[10,3,2]  R1361     -4.1553407907485962e-01
    z[10,3,2]  R1362     -4.1028726100921631e-01
    z[10,3,2]  R1363     3.8359567523002625e-01
    z[10,3,2]  R1364     4.1494885087013245e-01
    z[10,3,2]  R1365     4.8236930370330811e-01
    z[10,3,2]  R1366     1.4560346305370331e-01
    z[10,3,2]  R1367     1.9953136146068573e-01
    z[10,3,2]  R1368     0.0757877379655838
    z[10,3,2]  R1369     1.2136624753475189e-01
    z[10,3,2]  R1370     -2.0224972069263458e-01
    z[10,3,2]  R1371     2.4038438498973846e-01
    z[10,3,2]  R1372     5.5548596382141113e-01
    z[10,3,2]  R1373     4.1592600941658020e-01
    z[10,3,2]  R1374     1.9032983481884003e-01
    z[10,3,2]  R1375     2.3802405595779419e-01
    z[10,3,2]  R1376     4.3518039584159851e-01
    z[10,3,2]  R1377     -0.337252676486969
    z[10,3,2]  R1378     -2.8646349906921387e-01
    z[10,3,2]  R1379     -0.155140221118927
    z[10,3,2]  R1380     4.3472087383270264e-01
    z[10,3,2]  R1381     -1.0040885210037231e-01
    z[10,3,2]  R1382     -2.0830640196800232e-01
    z[10,3,2]  R1383     -3.1272897124290466e-01
    z[10,3,2]  R1384     6.0756152868270874e-01
    z[10,3,2]  R1385     6.9988787174224854e-01
    z[10,3,2]  R1386     5.0023770332336426e-01
    z[10,3,2]  R1387     6.8567067384719849e-01
    z[10,3,2]  R1388     4.4297706335783005e-02
    z[10,3,2]  R1389     -1.0253424942493439e-01
    z[10,3,2]  R1390     3.4196120500564575e-01
    z[10,3,2]  R1391     1.9986394047737122e-01
    z[10,3,2]  R1392     -8.1668362021446228e-02
    z[10,3,2]  R1393     2.2891965508460999e-01
    z[10,3,2]  R1394     5.2468216419219971e-01
    z[10,3,2]  R1395     -3.9801257848739624e-01
    z[10,3,2]  R1396     -4.8457396030426025e-01
    z[10,3,2]  R1397     -6.3851737976074219e-01
    z[10,3,2]  R1398     -3.4500178694725037e-01
    z[10,3,2]  R1399     -3.0746594071388245e-02
    z[10,3,2]  R1400     0.0672302395105362
    z[10,3,2]  R1401     -1.6945162415504456e-01
    z[10,3,2]  R1402     3.5668212175369263e-01
    z[10,3,2]  R1403     4.5615750551223755e-01
    z[10,3,2]  R1404     1.0421478748321533e-01
    z[10,3,2]  R1405     2.2317555546760559e-01
    z[10,3,2]  R1406     1.8342211842536926e-01
    z[10,3,2]  R1407     3.2977712154388428e-01
    z[10,3,2]  R1408     2.5324460864067078e-01
    z[10,3,2]  R1409     2.0797833800315857e-01
    z[10,3,2]  R1410     5.5952745676040649e-01
    z[10,3,2]  R1411     -1.7250286042690277e-01
    z[10,3,2]  R1412     1.0942266322672367e-02
    z[10,3,2]  R1413     -9.7748890519142151e-02
    z[10,3,2]  R1414     -1.1095040291547775e-01
    z[10,3,2]  R1415     8.1540994346141815e-02
    z[10,3,2]  R1416     1.9990071654319763e-02
    z[10,3,2]  R1417     3.3385327458381653e-01
    z[10,3,2]  R1418     -6.5134182572364807e-02
    z[10,3,2]  R1419     4.1693288087844849e-01
    z[10,3,2]  R1420     -3.3540013432502747e-01
    z[10,3,2]  R1421     3.5556885600090027e-01
    z[10,3,2]  R1422     -1.6824441030621529e-02
    z[10,3,2]  R1423     1.4960496127605438e-01
    z[10,3,2]  R1424     3.2649624347686768e-01
    z[10,3,2]  R1425     -5.8190923929214478e-01
    z[10,3,2]  R1426     -5.5336314439773560e-01
    z[10,3,3]  R32       1
    z[10,3,3]  R95       -1
    z[10,3,3]  R1342     -1
    z[10,3,3]  R1343     1
    z[10,3,3]  R1350     -1.4703287184238434e-01
    z[10,3,3]  R1351     0.344155490398407
    z[10,3,3]  R1352     -7.7896326780319214e-01
    z[10,3,3]  R1353     -4.1236785054206848e-01
    z[10,3,3]  R1354     2.8863430023193359e-01
    z[10,3,3]  R1355     1.2976673245429993e-01
    z[10,3,3]  R1356     -2.0462699234485626e-01
    z[10,3,3]  R1357     1.9002115726470947e-01
    z[10,3,3]  R1358     -1.8746571242809296e-01
    z[10,3,3]  R1359     -7.2501905262470245e-02
    z[10,3,3]  R1360     -1.8766152858734131e-01
    z[10,3,3]  R1361     -4.7987371683120728e-01
    z[10,3,3]  R1362     -2.8874301910400391e-01
    z[10,3,3]  R1363     2.1433551609516144e-01
    z[10,3,3]  R1364     3.0487281084060669e-01
    z[10,3,3]  R1365     -3.9902785420417786e-01
    z[10,3,3]  R1366     7.7159124612808228e-01
    z[10,3,3]  R1367     8.8653421401977539e-01
    z[10,3,3]  R1368     -1.8677787482738495e-01
    z[10,3,3]  R1369     1.6629297286272049e-02
    z[10,3,3]  R1370     -4.0363001823425293e-01
    z[10,3,3]  R1371     -6.6593624651432037e-02
    z[10,3,3]  R1372     -2.3678421974182129e-01
    z[10,3,3]  R1373     -1.3033494353294373e-01
    z[10,3,3]  R1374     -9.6394300460815430e-02
    z[10,3,3]  R1375     -3.9456138014793396e-01
    z[10,3,3]  R1376     2.7258358895778656e-02
    z[10,3,3]  R1377     0.352216899394989
    z[10,3,3]  R1378     -6.2394142150878906e-01
    z[10,3,3]  R1379     -2.7145397663116455e-01
    z[10,3,3]  R1380     3.0579817295074463e-01
    z[10,3,3]  R1381     -3.1357815861701965e-01
    z[10,3,3]  R1382     2.1988305449485779e-01
    z[10,3,3]  R1383     -1.7302658408880234e-02
    z[10,3,3]  R1384     0.519877016544342
    z[10,3,3]  R1385     5.3139919042587280e-01
    z[10,3,3]  R1386     0.700632631778717
    z[10,3,3]  R1387     4.6535894274711609e-01
    z[10,3,3]  R1388     3.3893135190010071e-01
    z[10,3,3]  R1389     1.7238068580627441e-01
    z[10,3,3]  R1390     -8.0694389343261719e-01
    z[10,3,3]  R1391     2.2265070676803589e-01
    z[10,3,3]  R1392     -1.2656930088996887e-01
    z[10,3,3]  R1393     4.0449026226997375e-01
    z[10,3,3]  R1394     -0.569337010383606
    z[10,3,3]  R1395     -6.4385145902633667e-01
    z[10,3,3]  R1396     1.1762108653783798e-02
    z[10,3,3]  R1397     -2.0890416204929352e-01
    z[10,3,3]  R1398     0.820968508720398
    z[10,3,3]  R1399     6.7245924472808838e-01
    z[10,3,3]  R1400     6.3162380456924438e-01
    z[10,3,3]  R1401     7.0842069387435913e-01
    z[10,3,3]  R1402     6.5730887651443481e-01
    z[10,3,3]  R1403     7.4381065368652344e-01
    z[10,3,3]  R1404     8.7322556972503662e-01
    z[10,3,3]  R1405     2.5221675634384155e-01
    z[10,3,3]  R1406     -2.6172018051147461e-01
    z[10,3,3]  R1407     3.6002656817436218e-01
    z[10,3,3]  R1408     3.9744228124618530e-01
    z[10,3,3]  R1409     2.2856892645359039e-01
    z[10,3,3]  R1410     3.2866531610488892e-01
    z[10,3,3]  R1411     -1.9448810815811157e-01
    z[10,3,3]  R1412     -1.3624049723148346e-01
    z[10,3,3]  R1413     1.0560864955186844e-01
    z[10,3,3]  R1414     8.2533389329910278e-02
    z[10,3,3]  R1415     3.7692766636610031e-02
    z[10,3,3]  R1416     1.9963359832763672e-01
    z[10,3,3]  R1417     6.4280843734741211e-01
    z[10,3,3]  R1418     7.4181818962097168e-01
    z[10,3,3]  R1419     8.2144778966903687e-01
    z[10,3,3]  R1420     6.5293055772781372e-01
    z[10,3,3]  R1421     6.0793638229370117e-01
    z[10,3,3]  R1422     -2.7843394875526428e-01
    z[10,3,3]  R1423     -1.4027177821844816e-03
    z[10,3,3]  R1424     -1.1982208490371704e-01
    z[10,3,3]  R1425     -1.3696564733982086e-01
    z[10,3,3]  R1426     -4.2138215899467468e-01
    z[10,3,4]  R33       1
    z[10,3,4]  R96       -1
    z[10,3,4]  R1344     -1
    z[10,3,4]  R1345     1
    z[10,3,4]  R1350     2.2983600199222565e-01
    z[10,3,4]  R1351     2.8720948100090027e-01
    z[10,3,4]  R1352     1.3539366424083710e-01
    z[10,3,4]  R1353     -7.3919445276260376e-01
    z[10,3,4]  R1354     -1.0036127269268036e-01
    z[10,3,4]  R1355     1.3280834257602692e-01
    z[10,3,4]  R1356     -0.706744372844696
    z[10,3,4]  R1357     -1.8327893316745758e-01
    z[10,3,4]  R1358     -6.9730438292026520e-02
    z[10,3,4]  R1359     -2.1937829256057739e-01
    z[10,3,4]  R1360     -7.9963423311710358e-02
    z[10,3,4]  R1361     -2.9370233416557312e-01
    z[10,3,4]  R1362     1.1862007901072502e-02
    z[10,3,4]  R1363     -2.9073095321655273e-01
    z[10,3,4]  R1364     5.1163870841264725e-02
    z[10,3,4]  R1365     -5.2366904914379120e-02
    z[10,3,4]  R1366     5.1369827985763550e-01
    z[10,3,4]  R1367     2.8623512387275696e-01
    z[10,3,4]  R1368     -4.3542243540287018e-02
    z[10,3,4]  R1369     -4.9253765493631363e-02
    z[10,3,4]  R1370     -3.7257453799247742e-01
    z[10,3,4]  R1371     -6.8323785066604614e-01
    z[10,3,4]  R1372     -4.4237226247787476e-01
    z[10,3,4]  R1373     -2.4362699687480927e-01
    z[10,3,4]  R1374     4.4362466782331467e-02
    z[10,3,4]  R1375     -4.6004977822303772e-01
    z[10,3,4]  R1376     -5.4237610101699829e-01
    z[10,3,4]  R1377     6.8480938673019409e-02
    z[10,3,4]  R1378     -7.0628547668457031e-01
    z[10,3,4]  R1379     2.0449408888816833e-01
    z[10,3,4]  R1380     -1.8453244864940643e-01
    z[10,3,4]  R1381     -6.0103225708007812e-01
    z[10,3,4]  R1382     -0.672758936882019
    z[10,3,4]  R1383     -1.7281450331211090e-01
    z[10,3,4]  R1384     0.0520535483956337
    z[10,3,4]  R1385     -1.3552919030189514e-01
    z[10,3,4]  R1386     -8.4265895187854767e-02
    z[10,3,4]  R1387     -2.3378261923789978e-01
    z[10,3,4]  R1388     6.1544120311737061e-01
    z[10,3,4]  R1389     -1.6038011014461517e-01
    z[10,3,4]  R1390     -4.4960159808397293e-02
    z[10,3,4]  R1391     3.2772939652204514e-02
    z[10,3,4]  R1392     2.4203942716121674e-01
    z[10,3,4]  R1393     -7.1600514650344849e-01
    z[10,3,4]  R1394     -4.7515761852264404e-01
    z[10,3,4]  R1395     -4.7687861323356628e-01
    z[10,3,4]  R1396     -1.4801302552223206e-01
    z[10,3,4]  R1397     -8.6326800286769867e-02
    z[10,3,4]  R1398     -1.1482661962509155e-01
    z[10,3,4]  R1399     -7.4615702033042908e-03
    z[10,3,4]  R1400     -1.4398986101150513e-01
    z[10,3,4]  R1401     3.1648358702659607e-01
    z[10,3,4]  R1402     8.5796646773815155e-02
    z[10,3,4]  R1403     1.6937313973903656e-01
    z[10,3,4]  R1404     3.5484090447425842e-01
    z[10,3,4]  R1405     -5.3575527854263783e-03
    z[10,3,4]  R1406     -5.2903532981872559e-02
    z[10,3,4]  R1407     -5.3471463918685913e-01
    z[10,3,4]  R1408     -0.59151291847229
    z[10,3,4]  R1409     -7.9646848142147064e-02
    z[10,3,4]  R1410     -0.0201775711029768
    z[10,3,4]  R1411     4.5154165476560593e-02
    z[10,3,4]  R1412     1.6619296371936798e-01
    z[10,3,4]  R1413     1.6266991198062897e-01
    z[10,3,4]  R1414     -3.7581852078437805e-01
    z[10,3,4]  R1415     -2.7733482420444489e-03
    z[10,3,4]  R1416     2.2970676422119141e-01
    z[10,3,4]  R1417     -1.4652857184410095e-01
    z[10,3,4]  R1418     1.3311018049716949e-01
    z[10,3,4]  R1419     2.1338362246751785e-02
    z[10,3,4]  R1420     -4.9263462424278259e-01
    z[10,3,4]  R1421     1.3779577612876892e-01
    z[10,3,4]  R1422     -3.4126002341508865e-02
    z[10,3,4]  R1423     -1.0386031121015549e-01
    z[10,3,4]  R1424     -1.1333167552947998e-02
    z[10,3,4]  R1425     1.8678863346576691e-01
    z[10,3,4]  R1426     1.9302532076835632e-02
    z[10,3,5]  R34       1
    z[10,3,5]  R97       -1
    z[10,3,5]  R1346     -1
    z[10,3,5]  R1347     1
    z[10,3,5]  R1350     4.3534699082374573e-01
    z[10,3,5]  R1351     -3.0110970139503479e-01
    z[10,3,5]  R1352     -7.4945211410522461e-02
    z[10,3,5]  R1353     -2.1428455412387848e-01
    z[10,3,5]  R1354     -2.2916541993618011e-01
    z[10,3,5]  R1355     0.117099329829216
    z[10,3,5]  R1356     -2.9089614748954773e-01
    z[10,3,5]  R1357     6.2324327230453491e-01
    z[10,3,5]  R1358     1.7301371321082115e-02
    z[10,3,5]  R1359     -0.616300642490387
    z[10,3,5]  R1360     -1.0651084035634995e-01
    z[10,3,5]  R1361     0.0874929204583168
    z[10,3,5]  R1362     -2.5583449006080627e-01
    z[10,3,5]  R1363     1.8713390827178955e-01
    z[10,3,5]  R1364     -7.1029275655746460e-02
    z[10,3,5]  R1365     5.2788585424423218e-01
    z[10,3,5]  R1366     2.3108594119548798e-01
    z[10,3,5]  R1367     4.7886174172163010e-02
    z[10,3,5]  R1368     2.9599308967590332e-01
    z[10,3,5]  R1369     0.613882303237915
    z[10,3,5]  R1370     1.8186467885971069e-01
    z[10,3,5]  R1371     1.5288820862770081e-01
    z[10,3,5]  R1372     0.002495281631127
    z[10,3,5]  R1373     1.7671933397650719e-02
    z[10,3,5]  R1374     -1.7113471031188965e-01
    z[10,3,5]  R1375     -3.1766149401664734e-01
    z[10,3,5]  R1376     -2.5111809372901917e-01
    z[10,3,5]  R1377     -7.8134298324584961e-02
    z[10,3,5]  R1378     -1.5438029170036316e-01
    z[10,3,5]  R1379     -2.3001509904861450e-01
    z[10,3,5]  R1380     1.1281652748584747e-01
    z[10,3,5]  R1381     -4.9397316575050354e-01
    z[10,3,5]  R1382     1.1745315045118332e-01
    z[10,3,5]  R1383     -3.0929425358772278e-01
    z[10,3,5]  R1384     5.5347144603729248e-01
    z[10,3,5]  R1385     3.9725202322006226e-01
    z[10,3,5]  R1386     2.0519931614398956e-01
    z[10,3,5]  R1387     2.6762205362319946e-01
    z[10,3,5]  R1388     1.3929626345634460e-01
    z[10,3,5]  R1389     -3.5279604792594910e-01
    z[10,3,5]  R1390     3.8220237940549850e-02
    z[10,3,5]  R1391     2.1354711055755615e-01
    z[10,3,5]  R1392     -4.0999558568000793e-01
    z[10,3,5]  R1393     8.4200963377952576e-02
    z[10,3,5]  R1394     2.8404369950294495e-01
    z[10,3,5]  R1395     3.8109812140464783e-01
    z[10,3,5]  R1396     7.8728175163269043e-01
    z[10,3,5]  R1397     6.7090344429016113e-01
    z[10,3,5]  R1398     3.5295647382736206e-01
    z[10,3,5]  R1399     -2.4163994938135147e-02
    z[10,3,5]  R1400     2.7940610051155090e-01
    z[10,3,5]  R1401     2.9542475938796997e-02
    z[10,3,5]  R1402     2.8805750608444214e-01
    z[10,3,5]  R1403     -1.4151780307292938e-01
    z[10,3,5]  R1404     -5.8375686407089233e-02
    z[10,3,5]  R1405     5.0904947519302368e-01
    z[10,3,5]  R1406     -2.0721639692783356e-01
    z[10,3,5]  R1407     2.2999155521392822e-01
    z[10,3,5]  R1408     1.7055776715278625e-01
    z[10,3,5]  R1409     4.8161312937736511e-01
    z[10,3,5]  R1410     -1.8148081004619598e-01
    z[10,3,5]  R1411     0.072996124625206
    z[10,3,5]  R1412     -1.3415264897048473e-02
    z[10,3,5]  R1413     2.1625134348869324e-01
    z[10,3,5]  R1414     0.118670254945755
    z[10,3,5]  R1415     -0.221003919839859
    z[10,3,5]  R1416     -3.0883875489234924e-01
    z[10,3,5]  R1417     -1.3896717131137848e-01
    z[10,3,5]  R1418     3.2583504915237427e-01
    z[10,3,5]  R1419     -8.8345922529697418e-02
    z[10,3,5]  R1420     2.5804251432418823e-01
    z[10,3,5]  R1421     2.5488847494125366e-01
    z[10,3,5]  R1422     -0.0645069107413292
    z[10,3,5]  R1423     2.2342254221439362e-01
    z[10,3,5]  R1424     5.1044980064034462e-03
    z[10,3,5]  R1425     -2.3616391420364380e-01
    z[10,3,5]  R1426     -3.1501868367195129e-01
    z[10,3,6]  R35       1
    z[10,3,6]  R98       -1
    z[10,3,6]  R1348     -1
    z[10,3,6]  R1349     1
    z[10,3,6]  R1350     4.6257647871971130e-01
    z[10,3,6]  R1351     -6.4826726913452148e-01
    z[10,3,6]  R1352     -3.6707019805908203e-01
    z[10,3,6]  R1353     -3.0498981475830078e-02
    z[10,3,6]  R1354     1.1798144131898880e-01
    z[10,3,6]  R1355     4.5223093032836914e-01
    z[10,3,6]  R1356     -0.593783438205719
    z[10,3,6]  R1357     5.4171487689018250e-02
    z[10,3,6]  R1358     -3.4121882636100054e-03
    z[10,3,6]  R1359     1.8707311153411865e-01
    z[10,3,6]  R1360     -1.7125976085662842e-01
    z[10,3,6]  R1361     4.3881905078887939e-01
    z[10,3,6]  R1362     3.7445154786109924e-01
    z[10,3,6]  R1363     -4.8380523920059204e-01
    z[10,3,6]  R1364     -3.6763486266136169e-01
    z[10,3,6]  R1365     -1.2910179793834686e-01
    z[10,3,6]  R1366     -1.0116583108901978e-01
    z[10,3,6]  R1367     1.2317669577896595e-02
    z[10,3,6]  R1368     2.1949866786599159e-02
    z[10,3,6]  R1369     -0.309481143951416
    z[10,3,6]  R1370     -0.00813719630241394
    z[10,3,6]  R1371     7.3095001280307770e-02
    z[10,3,6]  R1372     -2.1239452064037323e-02
    z[10,3,6]  R1373     3.2550552487373352e-01
    z[10,3,6]  R1374     -6.8013453483581543e-01
    z[10,3,6]  R1375     4.8612061887979507e-02
    z[10,3,6]  R1376     0.264587938785553
    z[10,3,6]  R1377     -0.352030485868454
    z[10,3,6]  R1378     5.4543163627386093e-02
    z[10,3,6]  R1379     2.6071846485137939e-02
    z[10,3,6]  R1380     1.3117910921573639e-01
    z[10,3,6]  R1381     -2.9611018300056458e-01
    z[10,3,6]  R1382     -2.7989998459815979e-01
    z[10,3,6]  R1383     -8.7218630313873291e-01
    z[10,3,6]  R1384     2.0902042090892792e-01
    z[10,3,6]  R1385     -1.4140348136425018e-01
    z[10,3,6]  R1386     2.7622020244598389e-01
    z[10,3,6]  R1387     1.8064013123512268e-01
    z[10,3,6]  R1388     -2.7296485379338264e-02
    z[10,3,6]  R1389     -6.9551318883895874e-01
    z[10,3,6]  R1390     -9.9850669503211975e-03
    z[10,3,6]  R1391     1.2903241813182831e-01
    z[10,3,6]  R1392     0.614565372467041
    z[10,3,6]  R1393     4.7373369336128235e-01
    z[10,3,6]  R1394     -9.6105104312300682e-03
    z[10,3,6]  R1395     -1.6487258672714233e-01
    z[10,3,6]  R1396     -3.3270925283432007e-01
    z[10,3,6]  R1397     -1.5050514601171017e-02
    z[10,3,6]  R1398     2.5339301675558090e-02
    z[10,3,6]  R1399     4.1012936830520630e-01
    z[10,3,6]  R1400     -2.2790496051311493e-01
    z[10,3,6]  R1401     1.9731713831424713e-01
    z[10,3,6]  R1402     -8.0265142023563385e-02
    z[10,3,6]  R1403     -2.3283023387193680e-02
    z[10,3,6]  R1404     9.9094063043594360e-02
    z[10,3,6]  R1405     3.0142712593078613e-01
    z[10,3,6]  R1406     1.8220894038677216e-01
    z[10,3,6]  R1407     1.3260385394096375e-01
    z[10,3,6]  R1408     3.8297748565673828e-01
    z[10,3,6]  R1409     2.5355115532875061e-01
    z[10,3,6]  R1410     1.6693432629108429e-01
    z[10,3,6]  R1411     1.8298017978668213e-01
    z[10,3,6]  R1412     3.3461713790893555e-01
    z[10,3,6]  R1413     1.3354423642158508e-01
    z[10,3,6]  R1414     3.5253062844276428e-02
    z[10,3,6]  R1415     -3.4190145134925842e-01
    z[10,3,6]  R1416     3.3973187208175659e-02
    z[10,3,6]  R1417     3.8801971077919006e-01
    z[10,3,6]  R1418     3.2108667492866516e-01
    z[10,3,6]  R1419     2.4911326169967651e-01
    z[10,3,6]  R1420     2.7404436469078064e-01
    z[10,3,6]  R1421     2.4183419346809387e-01
    z[10,3,6]  R1422     -1.0881573706865311e-01
    z[10,3,6]  R1423     -2.9862526059150696e-01
    z[10,3,6]  R1424     0.0569380484521389
    z[10,3,6]  R1425     -5.3832545876502991e-02
    z[10,3,6]  R1426     -2.0913438498973846e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1480     -1
    z[4,5,0]  R1481     1
    z[4,5,0]  R1494     0.623869776725769
    z[4,5,0]  R1495     4.7124966979026794e-01
    z[4,5,0]  R1496     4.6075388789176941e-01
    z[4,5,0]  R1497     7.0568728446960449e-01
    z[4,5,0]  R1498     -2.4869777262210846e-02
    z[4,5,0]  R1499     4.6758797764778137e-01
    z[4,5,0]  R1500     7.2842091321945190e-01
    z[4,5,0]  R1501     2.3502270877361298e-01
    z[4,5,0]  R1502     -6.4959675073623657e-01
    z[4,5,0]  R1503     -0.434550940990448
    z[4,5,0]  R1504     2.4478635191917419e-01
    z[4,5,0]  R1505     -8.0743575096130371e-01
    z[4,5,0]  R1506     -7.8418093919754028e-01
    z[4,5,0]  R1507     -7.4264776706695557e-01
    z[4,5,0]  R1508     -8.1033289432525635e-01
    z[4,5,0]  R1509     -0.653953492641449
    z[4,5,0]  R1510     -7.7817159891128540e-01
    z[4,5,0]  R1511     -6.3129687309265137e-01
    z[4,5,0]  R1512     -7.2030091285705566e-01
    z[4,5,0]  R1513     -0.704049825668335
    z[4,5,0]  R1514     3.6099374294281006e-01
    z[4,5,0]  R1515     -5.8742411434650421e-02
    z[4,5,0]  R1516     -3.2005450129508972e-01
    z[4,5,0]  R1517     -1.5671141445636749e-01
    z[4,5,0]  R1518     -6.1302137374877930e-01
    z[4,5,0]  R1519     -0.726642370223999
    z[4,5,0]  R1520     -5.1202350854873657e-01
    z[4,5,0]  R1521     -7.6954758167266846e-01
    z[4,5,0]  R1522     -4.6727684140205383e-01
    z[4,5,0]  R1523     0.0233807023614645
    z[4,5,0]  R1524     -3.0041972175240517e-02
    z[4,5,0]  R1525     5.7197922468185425e-01
    z[4,5,0]  R1526     1.9715158268809319e-02
    z[4,5,0]  R1527     2.7033057808876038e-01
    z[4,5,0]  R1528     -7.3233973979949951e-01
    z[4,5,0]  R1529     -6.9386434555053711e-01
    z[4,5,0]  R1530     -2.8363242745399475e-01
    z[4,5,0]  R1531     -6.0388818383216858e-02
    z[4,5,0]  R1532     -3.2891729474067688e-01
    z[4,5,0]  R1533     -1.4320007525384426e-02
    z[4,5,0]  R1534     0.779071033000946
    z[4,5,0]  R1535     5.8420836925506592e-01
    z[4,5,0]  R1536     6.7144513130187988e-01
    z[4,5,0]  R1537     3.2904317975044250e-01
    z[4,5,0]  R1538     1.7415077984333038e-01
    z[4,5,0]  R1539     -6.2151956558227539e-01
    z[4,5,0]  R1540     -0.679585337638855
    z[4,5,0]  R1541     -1.2746493518352509e-01
    z[4,5,0]  R1542     -6.1485564708709717e-01
    z[4,5,0]  R1543     -2.4496018886566162e-01
    z[4,5,0]  R1544     -1.1797130107879639e-01
    z[4,5,0]  R1545     9.0190194547176361e-02
    z[4,5,0]  R1546     1.1989449709653854e-01
    z[4,5,0]  R1547     -0.966793417930603
    z[4,5,0]  R1548     -8.8179326057434082e-01
    z[4,5,0]  R1549     9.3940198421478271e-02
    z[4,5,0]  R1550     -9.0632176399230957e-01
    z[4,5,0]  R1551     -9.4841402769088745e-01
    z[4,5,0]  R1552     -8.6142563819885254e-01
    z[4,5,0]  R1553     -9.2385548353195190e-01
    z[4,5,0]  R1554     1.0810466483235359e-03
    z[4,5,0]  R1555     -5.8041056618094444e-03
    z[4,5,0]  R1556     -8.0310928821563721e-01
    z[4,5,0]  R1557     8.9932829141616821e-02
    z[4,5,0]  R1558     -1.6305711865425110e-01
    z[4,5,0]  R1559     3.3410970121622086e-02
    z[4,5,0]  R1560     1.1821080930531025e-02
    z[4,5,0]  R1561     1.5017437934875488e-01
    z[4,5,0]  R1562     -2.9990875720977783e-01
    z[4,5,0]  R1563     -1.9459144771099091e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1482     -1
    z[4,5,1]  R1483     1
    z[4,5,1]  R1494     -5.7879839092493057e-02
    z[4,5,1]  R1495     4.7663533687591553e-01
    z[4,5,1]  R1496     0.136986643075943
    z[4,5,1]  R1497     1.8455080687999725e-02
    z[4,5,1]  R1498     -2.4925504624843597e-01
    z[4,5,1]  R1499     -0.396010160446167
    z[4,5,1]  R1500     -2.4161192774772644e-01
    z[4,5,1]  R1501     -5.0455331802368164e-01
    z[4,5,1]  R1502     4.0426418185234070e-02
    z[4,5,1]  R1503     1.4261446893215179e-02
    z[4,5,1]  R1504     5.0589561462402344e-01
    z[4,5,1]  R1505     -2.0128647983074188e-01
    z[4,5,1]  R1506     2.4805758893489838e-01
    z[4,5,1]  R1507     -2.9874911904335022e-01
    z[4,5,1]  R1508     -3.4483054280281067e-01
    z[4,5,1]  R1509     -0.194259375333786
    z[4,5,1]  R1510     4.3170002102851868e-01
    z[4,5,1]  R1511     -4.1876286268234253e-01
    z[4,5,1]  R1512     2.0251957699656487e-02
    z[4,5,1]  R1513     2.1078389883041382e-01
    z[4,5,1]  R1514     -7.9293411970138550e-01
    z[4,5,1]  R1515     -6.3022160530090332e-01
    z[4,5,1]  R1516     2.5774213671684265e-01
    z[4,5,1]  R1517     2.0051020383834839e-01
    z[4,5,1]  R1518     -1.8618722259998322e-01
    z[4,5,1]  R1519     2.9486516118049622e-01
    z[4,5,1]  R1520     -1.8806587159633636e-01
    z[4,5,1]  R1521     1.0639753937721252e-01
    z[4,5,1]  R1522     -1.5282559394836426e-01
    z[4,5,1]  R1523     3.2981187105178833e-01
    z[4,5,1]  R1524     8.7636457756161690e-03
    z[4,5,1]  R1525     -6.4705663919448853e-01
    z[4,5,1]  R1526     -5.9205174446105957e-01
    z[4,5,1]  R1527     -7.0185905694961548e-01
    z[4,5,1]  R1528     1.9007739424705505e-01
    z[4,5,1]  R1529     9.9332444369792938e-03
    z[4,5,1]  R1530     4.6222010254859924e-01
    z[4,5,1]  R1531     4.4346556067466736e-01
    z[4,5,1]  R1532     6.3291823863983154e-01
    z[4,5,1]  R1533     6.4614170789718628e-01
    z[4,5,1]  R1534     -2.4194441735744476e-01
    z[4,5,1]  R1535     -1.6875320672988892e-01
    z[4,5,1]  R1536     -4.5347511768341064e-01
    z[4,5,1]  R1537     -2.2050461173057556e-01
    z[4,5,1]  R1538     5.5806207656860352e-01
    z[4,5,1]  R1539     -1.0700858384370804e-01
    z[4,5,1]  R1540     -6.8935486488044262e-03
    z[4,5,1]  R1541     7.8041607141494751e-01
    z[4,5,1]  R1542     -4.4107872247695923e-01
    z[4,5,1]  R1543     -1.5828229486942291e-01
    z[4,5,1]  R1544     -9.5661687850952148e-01
    z[4,5,1]  R1545     6.7145246267318726e-01
    z[4,5,1]  R1546     3.7672051787376404e-01
    z[4,5,1]  R1547     -1.8287684023380280e-01
    z[4,5,1]  R1548     -0.260501503944397
    z[4,5,1]  R1549     -1.2866412103176117e-01
    z[4,5,1]  R1550     -1.5201704204082489e-01
    z[4,5,1]  R1551     2.3244591057300568e-01
    z[4,5,1]  R1552     -2.5467243790626526e-01
    z[4,5,1]  R1553     -1.7454622313380241e-02
    z[4,5,1]  R1554     4.5042019337415695e-02
    z[4,5,1]  R1555     6.1995232105255127e-01
    z[4,5,1]  R1556     -5.1690392196178436e-02
    z[4,5,1]  R1557     7.5798302888870239e-01
    z[4,5,1]  R1558     4.5514708757400513e-01
    z[4,5,1]  R1559     3.8885805010795593e-01
    z[4,5,1]  R1560     3.3261448144912720e-01
    z[4,5,1]  R1561     5.4179102182388306e-01
    z[4,5,1]  R1562     4.3273347616195679e-01
    z[4,5,1]  R1563     5.1244789361953735e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1484     -1
    z[4,5,2]  R1485     1
    z[4,5,2]  R1494     -0.253171443939209
    z[4,5,2]  R1495     -0.256808340549469
    z[4,5,2]  R1496     -6.0175049304962158e-01
    z[4,5,2]  R1497     -5.7989460229873657e-01
    z[4,5,2]  R1498     -5.1363348960876465e-01
    z[4,5,2]  R1499     -6.0305446386337280e-01
    z[4,5,2]  R1500     2.6512950658798218e-01
    z[4,5,2]  R1501     -4.9417650699615479e-01
    z[4,5,2]  R1502     5.0010327249765396e-02
    z[4,5,2]  R1503     5.4412502050399780e-01
    z[4,5,2]  R1504     0.260545551776886
    z[4,5,2]  R1505     -3.0604428052902222e-01
    z[4,5,2]  R1506     -4.4277977943420410e-01
    z[4,5,2]  R1507     1.6066820919513702e-01
    z[4,5,2]  R1508     -2.6069043204188347e-02
    z[4,5,2]  R1509     4.4048935174942017e-01
    z[4,5,2]  R1510     -1.8304710090160370e-01
    z[4,5,2]  R1511     0.511961817741394
    z[4,5,2]  R1512     -2.6515352725982666e-01
    z[4,5,2]  R1513     -3.3389872312545776e-01
    z[4,5,2]  R1514     -3.9977619051933289e-01
    z[4,5,2]  R1515     -2.2786787152290344e-01
    z[4,5,2]  R1516     -2.3326057195663452e-01
    z[4,5,2]  R1517     -7.6868957281112671e-01
    z[4,5,2]  R1518     3.6510381102561951e-01
    z[4,5,2]  R1519     -1.0599025338888168e-01
    z[4,5,2]  R1520     -3.5606861114501953e-01
    z[4,5,2]  R1521     3.6365887522697449e-01
    z[4,5,2]  R1522     -0.0385645292699337
    z[4,5,2]  R1523     8.1564372777938843e-01
    z[4,5,2]  R1524     -4.6448025107383728e-01
    z[4,5,2]  R1525     -3.2947650551795959e-01
    z[4,5,2]  R1526     -5.5192488431930542e-01
    z[4,5,2]  R1527     8.3687156438827515e-02
    z[4,5,2]  R1528     7.0837266743183136e-02
    z[4,5,2]  R1529     4.0494126081466675e-01
    z[4,5,2]  R1530     7.1850842237472534e-01
    z[4,5,2]  R1531     8.5093015432357788e-01
    z[4,5,2]  R1532     5.2036416530609131e-01
    z[4,5,2]  R1533     6.1346948146820068e-01
    z[4,5,2]  R1534     8.2626260817050934e-02
    z[4,5,2]  R1535     -1.4685069024562836e-01
    z[4,5,2]  R1536     -9.1911174356937408e-02
    z[4,5,2]  R1537     2.3904825747013092e-01
    z[4,5,2]  R1538     -2.8760096430778503e-01
    z[4,5,2]  R1539     5.1307892799377441e-01
    z[4,5,2]  R1540     -6.6355055570602417e-01
    z[4,5,2]  R1541     3.0482813715934753e-01
    z[4,5,2]  R1542     -3.4432035684585571e-01
    z[4,5,2]  R1543     7.3160648345947266e-01
    z[4,5,2]  R1544     -6.2353104352951050e-02
    z[4,5,2]  R1545     -9.0764164924621582e-02
    z[4,5,2]  R1546     -2.5851266458630562e-02
    z[4,5,2]  R1547     1.6871837899088860e-02
    z[4,5,2]  R1548     2.3442400991916656e-01
    z[4,5,2]  R1549     3.0210015177726746e-01
    z[4,5,2]  R1550     2.6036441326141357e-01
    z[4,5,2]  R1551     -1.9920321181416512e-02
    z[4,5,2]  R1552     1.5062890946865082e-01
    z[4,5,2]  R1553     -2.9315197467803955e-01
    z[4,5,2]  R1554     -7.2397851943969727e-01
    z[4,5,2]  R1555     -3.9215284585952759e-01
    z[4,5,2]  R1556     -2.9553228616714478e-01
    z[4,5,2]  R1557     1.4860726892948151e-01
    z[4,5,2]  R1558     0.322405606508255
    z[4,5,2]  R1559     1.3565708696842194e-01
    z[4,5,2]  R1560     -7.2536058723926544e-02
    z[4,5,2]  R1561     -6.6938288509845734e-02
    z[4,5,2]  R1562     2.0361553132534027e-01
    z[4,5,2]  R1563     2.4254187941551208e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1486     -1
    z[4,5,3]  R1487     1
    z[4,5,3]  R1494     1.2492491304874420e-01
    z[4,5,3]  R1495     -2.2062879800796509e-01
    z[4,5,3]  R1496     2.6165612041950226e-02
    z[4,5,3]  R1497     -3.9458128809928894e-01
    z[4,5,3]  R1498     -1.7055764794349670e-02
    z[4,5,3]  R1499     -3.6346483230590820e-01
    z[4,5,3]  R1500     -5.4058402776718140e-01
    z[4,5,3]  R1501     -2.5114113092422485e-01
    z[4,5,3]  R1502     -6.9336640834808350e-01
    z[4,5,3]  R1503     0.0930207222700119
    z[4,5,3]  R1504     7.2303497791290283e-01
    z[4,5,3]  R1505     3.0968725681304932e-01
    z[4,5,3]  R1506     0.0782003104686737
    z[4,5,3]  R1507     4.2925807833671570e-01
    z[4,5,3]  R1508     2.4197527766227722e-01
    z[4,5,3]  R1509     8.6328610777854919e-02
    z[4,5,3]  R1510     1.4247921109199524e-01
    z[4,5,3]  R1511     6.5046057105064392e-02
    z[4,5,3]  R1512     0.437688410282135
    z[4,5,3]  R1513     6.1790838837623596e-02
    z[4,5,3]  R1514     1.7396517097949982e-02
    z[4,5,3]  R1515     -6.1151021718978882e-01
    z[4,5,3]  R1516     7.5240248441696167e-01
    z[4,5,3]  R1517     1.4732128381729126e-01
    z[4,5,3]  R1518     -3.4460049867630005e-01
    z[4,5,3]  R1519     2.1453826129436493e-01
    z[4,5,3]  R1520     -6.2274432182312012e-01
    z[4,5,3]  R1521     2.8538236021995544e-01
    z[4,5,3]  R1522     -6.9842666387557983e-01
    z[4,5,3]  R1523     1.2472738325595856e-01
    z[4,5,3]  R1524     7.7994906902313232e-01
    z[4,5,3]  R1525     -9.5606915652751923e-02
    z[4,5,3]  R1526     -2.6460930705070496e-01
    z[4,5,3]  R1527     -6.1491703987121582e-01
    z[4,5,3]  R1528     -5.0796729326248169e-01
    z[4,5,3]  R1529     -5.5004650354385376e-01
    z[4,5,3]  R1530     1.3698703050613403e-01
    z[4,5,3]  R1531     3.0471283942461014e-02
    z[4,5,3]  R1532     7.1395240724086761e-02
    z[4,5,3]  R1533     -1.2433141469955444e-01
    z[4,5,3]  R1534     5.0736564397811890e-01
    z[4,5,3]  R1535     2.7258267998695374e-01
    z[4,5,3]  R1536     1.7339875921607018e-02
    z[4,5,3]  R1537     -1.3244172558188438e-02
    z[4,5,3]  R1538     3.5233655571937561e-01
    z[4,5,3]  R1539     -2.9630497097969055e-01
    z[4,5,3]  R1540     -2.9017748311161995e-02
    z[4,5,3]  R1541     1.0817368328571320e-01
    z[4,5,3]  R1542     -1.8502433598041534e-01
    z[4,5,3]  R1543     2.8789332509040833e-01
    z[4,5,3]  R1544     -2.0504589378833771e-01
    z[4,5,3]  R1545     3.1491145491600037e-01
    z[4,5,3]  R1546     2.9783454537391663e-01
    z[4,5,3]  R1547     1.0463164187967777e-02
    z[4,5,3]  R1548     -2.1111422777175903e-01
    z[4,5,3]  R1549     1.6048426926136017e-01
    z[4,5,3]  R1550     1.8241165578365326e-01
    z[4,5,3]  R1551     -1.0723023861646652e-01
    z[4,5,3]  R1552     -6.6596224904060364e-02
    z[4,5,3]  R1553     3.3402517437934875e-02
    z[4,5,3]  R1554     4.4289156794548035e-01
    z[4,5,3]  R1555     0.362806111574173
    z[4,5,3]  R1556     -4.3815332651138306e-01
    z[4,5,3]  R1557     2.1115960180759430e-01
    z[4,5,3]  R1558     -7.6380264759063721e-01
    z[4,5,3]  R1559     -0.864760160446167
    z[4,5,3]  R1560     -8.3527755737304688e-01
    z[4,5,3]  R1561     -7.1430534124374390e-01
    z[4,5,3]  R1562     -4.3158787488937378e-01
    z[4,5,3]  R1563     -5.1876145601272583e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1488     -1
    z[4,5,4]  R1489     1
    z[4,5,4]  R1494     1.3428099453449249e-01
    z[4,5,4]  R1495     -5.0115477293729782e-02
    z[4,5,4]  R1496     -6.0040223598480225e-01
    z[4,5,4]  R1497     2.4425039067864418e-02
    z[4,5,4]  R1498     -6.1566889286041260e-01
    z[4,5,4]  R1499     -3.2677662372589111e-01
    z[4,5,4]  R1500     -8.8102911831811070e-04
    z[4,5,4]  R1501     4.9350139498710632e-01
    z[4,5,4]  R1502     -1.6764195263385773e-01
    z[4,5,4]  R1503     5.2765417844057083e-02
    z[4,5,4]  R1504     2.9596433043479919e-01
    z[4,5,4]  R1505     1.2117193639278412e-01
    z[4,5,4]  R1506     -5.5758882313966751e-02
    z[4,5,4]  R1507     0.349113792181015
    z[4,5,4]  R1508     -4.4087474234402180e-03
    z[4,5,4]  R1509     -3.5065639019012451e-01
    z[4,5,4]  R1510     3.4546020627021790e-01
    z[4,5,4]  R1511     3.5722330212593079e-02
    z[4,5,4]  R1512     4.6186572313308716e-01
    z[4,5,4]  R1513     1.2337285280227661e-01
    z[4,5,4]  R1514     -6.2775298953056335e-02
    z[4,5,4]  R1515     1.9002555310726166e-01
    z[4,5,4]  R1516     2.0022791624069214e-01
    z[4,5,4]  R1517     3.3235016465187073e-01
    z[4,5,4]  R1518     3.2712128758430481e-01
    z[4,5,4]  R1519     -1.9327478110790253e-01
    z[4,5,4]  R1520     3.2679072022438049e-01
    z[4,5,4]  R1521     0.0372639000415802
    z[4,5,4]  R1522     1.5612757205963135e-01
    z[4,5,4]  R1523     -4.4850343465805054e-01
    z[4,5,4]  R1524     1.7781293392181396e-01
    z[4,5,4]  R1525     8.8864214718341827e-02
    z[4,5,4]  R1526     4.1311812400817871e-01
    z[4,5,4]  R1527     6.5062172710895538e-02
    z[4,5,4]  R1528     4.6158386394381523e-03
    z[4,5,4]  R1529     -1.8049257993698120e-01
    z[4,5,4]  R1530     -2.6640057563781738e-01
    z[4,5,4]  R1531     -2.5441393256187439e-01
    z[4,5,4]  R1532     -1.5200361609458923e-01
    z[4,5,4]  R1533     -4.0366733074188232e-01
    z[4,5,4]  R1534     -5.9939295053482056e-02
    z[4,5,4]  R1535     -4.1085857152938843e-01
    z[4,5,4]  R1536     -9.5507122576236725e-02
    z[4,5,4]  R1537     -4.8385095596313477e-01
    z[4,5,4]  R1538     -9.4575367867946625e-02
    z[4,5,4]  R1539     7.4334681034088135e-02
    z[4,5,4]  R1540     3.1032708287239075e-01
    z[4,5,4]  R1541     -5.8349415659904480e-02
    z[4,5,4]  R1542     -2.7441397309303284e-01
    z[4,5,4]  R1543     2.3987439274787903e-01
    z[4,5,4]  R1544     -2.6114033535122871e-02
    z[4,5,4]  R1545     4.6398764848709106e-01
    z[4,5,4]  R1546     5.9826242923736572e-01
    z[4,5,4]  R1547     9.2187933623790741e-02
    z[4,5,4]  R1548     1.1430983990430832e-01
    z[4,5,4]  R1549     8.3107441663742065e-01
    z[4,5,4]  R1550     -1.7113734781742096e-01
    z[4,5,4]  R1551     1.9617075100541115e-02
    z[4,5,4]  R1552     1.2819147109985352e-01
    z[4,5,4]  R1553     -2.0795492827892303e-01
    z[4,5,4]  R1554     4.2885860800743103e-01
    z[4,5,4]  R1555     -2.7451589703559875e-01
    z[4,5,4]  R1556     5.4069276899099350e-02
    z[4,5,4]  R1557     -4.3188178539276123e-01
    z[4,5,4]  R1558     1.2486344575881958e-01
    z[4,5,4]  R1559     -5.1023479551076889e-02
    z[4,5,4]  R1560     -1.8468033522367477e-02
    z[4,5,4]  R1561     5.6313324719667435e-02
    z[4,5,4]  R1562     1.1047400534152985e-01
    z[4,5,4]  R1563     -1.1940068751573563e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1490     -1
    z[4,5,5]  R1491     1
    z[4,5,5]  R1494     -7.1296584606170654e-01
    z[4,5,5]  R1495     -6.5558588504791260e-01
    z[4,5,5]  R1496     5.1895566284656525e-02
    z[4,5,5]  R1497     -0.0933489054441452
    z[4,5,5]  R1498     -5.4180312156677246e-01
    z[4,5,5]  R1499     0.0987154096364975
    z[4,5,5]  R1500     3.5888131707906723e-02
    z[4,5,5]  R1501     3.3192914724349976e-01
    z[4,5,5]  R1502     -2.4730521440505981e-01
    z[4,5,5]  R1503     -7.0260518789291382e-01
    z[4,5,5]  R1504     2.0185057073831558e-02
    z[4,5,5]  R1505     2.9615047574043274e-01
    z[4,5,5]  R1506     4.6754315495491028e-02
    z[4,5,5]  R1507     -1.4542146027088165e-01
    z[4,5,5]  R1508     3.5263496637344360e-01
    z[4,5,5]  R1509     4.4210180640220642e-01
    z[4,5,5]  R1510     1.8660034239292145e-01
    z[4,5,5]  R1511     3.9712288975715637e-01
    z[4,5,5]  R1512     2.1152688190340996e-02
    z[4,5,5]  R1513     5.3880882263183594e-01
    z[4,5,5]  R1514     2.0857958495616913e-01
    z[4,5,5]  R1515     -3.1896722316741943e-01
    z[4,5,5]  R1516     -3.0509606003761292e-01
    z[4,5,5]  R1517     -1.3022434897720814e-02
    z[4,5,5]  R1518     -3.6757189035415649e-01
    z[4,5,5]  R1519     -5.2152538299560547e-01
    z[4,5,5]  R1520     -0.00387446372769773
    z[4,5,5]  R1521     -3.5772538185119629e-01
    z[4,5,5]  R1522     4.2368492484092712e-01
    z[4,5,5]  R1523     3.1375296413898468e-02
    z[4,5,5]  R1524     -3.2512894272804260e-01
    z[4,5,5]  R1525     2.9254025220870972e-01
    z[4,5,5]  R1526     -1.3117742538452148e-01
    z[4,5,5]  R1527     -1.7303550243377686e-01
    z[4,5,5]  R1528     3.7424415349960327e-01
    z[4,5,5]  R1529     6.4648225903511047e-02
    z[4,5,5]  R1530     -1.1710131540894508e-02
    z[4,5,5]  R1531     -8.1055760383605957e-02
    z[4,5,5]  R1532     3.1751343607902527e-01
    z[4,5,5]  R1533     1.3374280929565430e-01
    z[4,5,5]  R1534     2.4319063127040863e-01
    z[4,5,5]  R1535     -5.8295673131942749e-01
    z[4,5,5]  R1536     -3.0251616239547729e-01
    z[4,5,5]  R1537     1.3146124780178070e-01
    z[4,5,5]  R1538     1.0964702069759369e-01
    z[4,5,5]  R1539     4.5769503712654114e-01
    z[4,5,5]  R1540     -2.2456597536802292e-02
    z[4,5,5]  R1541     -5.1432478427886963e-01
    z[4,5,5]  R1542     4.3542400002479553e-01
    z[4,5,5]  R1543     -4.8435342311859131e-01
    z[4,5,5]  R1544     1.5595848858356476e-01
    z[4,5,5]  R1545     -4.6357524394989014e-01
    z[4,5,5]  R1546     -3.7854495644569397e-01
    z[4,5,5]  R1547     2.6929848827421665e-03
    z[4,5,5]  R1548     -1.6067951917648315e-01
    z[4,5,5]  R1549     -3.7243768572807312e-01
    z[4,5,5]  R1550     9.3918427824974060e-02
    z[4,5,5]  R1551     2.9677912592887878e-02
    z[4,5,5]  R1552     -3.1352409720420837e-01
    z[4,5,5]  R1553     8.1947281956672668e-02
    z[4,5,5]  R1554     -2.7459457516670227e-01
    z[4,5,5]  R1555     9.1942958533763885e-02
    z[4,5,5]  R1556     7.3096431791782379e-02
    z[4,5,5]  R1557     7.3388456366956234e-03
    z[4,5,5]  R1558     2.3633052408695221e-01
    z[4,5,5]  R1559     0.277178019285202
    z[4,5,5]  R1560     4.2596709728240967e-01
    z[4,5,5]  R1561     4.0707957744598389e-01
    z[4,5,5]  R1562     6.4479613304138184e-01
    z[4,5,5]  R1563     5.8357077836990356e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1492     -1
    z[4,5,6]  R1493     1
    z[4,5,6]  R1494     -3.7183862179517746e-02
    z[4,5,6]  R1495     6.1730358749628067e-02
    z[4,5,6]  R1496     -2.0730726420879364e-01
    z[4,5,6]  R1497     -1.9549399614334106e-02
    z[4,5,6]  R1498     -2.3333156481385231e-02
    z[4,5,6]  R1499     1.1058200150728226e-01
    z[4,5,6]  R1500     2.1728603541851044e-01
    z[4,5,6]  R1501     1.7084307968616486e-01
    z[4,5,6]  R1502     0.0621943362057209
    z[4,5,6]  R1503     9.8989777266979218e-02
    z[4,5,6]  R1504     -7.4050143361091614e-02
    z[4,5,6]  R1505     1.2479652464389801e-01
    z[4,5,6]  R1506     3.4068095684051514e-01
    z[4,5,6]  R1507     -7.8221470117568970e-02
    z[4,5,6]  R1508     2.0211410522460938e-01
    z[4,5,6]  R1509     -1.2128803133964539e-01
    z[4,5,6]  R1510     1.0726608335971832e-02
    z[4,5,6]  R1511     -2.7989331632852554e-02
    z[4,5,6]  R1512     7.1495153009891510e-02
    z[4,5,6]  R1513     1.9758987426757812e-01
    z[4,5,6]  R1514     -0.182672381401062
    z[4,5,6]  R1515     1.8881724774837494e-01
    z[4,5,6]  R1516     2.7827912569046021e-01
    z[4,5,6]  R1517     4.6046045422554016e-01
    z[4,5,6]  R1518     3.0882257223129272e-01
    z[4,5,6]  R1519     1.3579729199409485e-01
    z[4,5,6]  R1520     -2.8471130132675171e-01
    z[4,5,6]  R1521     2.3114760220050812e-01
    z[4,5,6]  R1522     2.5519579648971558e-01
    z[4,5,6]  R1523     8.7783776223659515e-02
    z[4,5,6]  R1524     1.9398948550224304e-01
    z[4,5,6]  R1525     -2.0732876658439636e-01
    z[4,5,6]  R1526     2.9423266649246216e-01
    z[4,5,6]  R1527     -1.2253300100564957e-01
    z[4,5,6]  R1528     -1.5627020597457886e-01
    z[4,5,6]  R1529     1.2315811216831207e-01
    z[4,5,6]  R1530     3.1587821245193481e-01
    z[4,5,6]  R1531     -5.8175154030323029e-02
    z[4,5,6]  R1532     3.0237710475921631e-01
    z[4,5,6]  R1533     9.8276712000370026e-02
    z[4,5,6]  R1534     -8.6774595081806183e-02
    z[4,5,6]  R1535     1.6035346686840057e-01
    z[4,5,6]  R1536     4.8387566208839417e-01
    z[4,5,6]  R1537     7.3102325201034546e-01
    z[4,5,6]  R1538     6.5606081485748291e-01
    z[4,5,6]  R1539     1.9027769565582275e-01
    z[4,5,6]  R1540     -1.2946607545018196e-02
    z[4,5,6]  R1541     -4.6336270868778229e-02
    z[4,5,6]  R1542     -9.8562121391296387e-02
    z[4,5,6]  R1543     6.8356923758983612e-02
    z[4,5,6]  R1544     -5.5044367909431458e-03
    z[4,5,6]  R1545     -0.0585097037255764
    z[4,5,6]  R1546     -5.0310939550399780e-01
    z[4,5,6]  R1547     -1.5154702961444855e-01
    z[4,5,6]  R1548     -1.2716592848300934e-01
    z[4,5,6]  R1549     1.6794812679290771e-01
    z[4,5,6]  R1550     1.2766954302787781e-01
    z[4,5,6]  R1551     -1.8253472447395325e-01
    z[4,5,6]  R1552     2.2634802758693695e-01
    z[4,5,6]  R1553     9.5769934356212616e-02
    z[4,5,6]  R1554     1.3546362519264221e-01
    z[4,5,6]  R1555     -4.9638783931732178e-01
    z[4,5,6]  R1556     2.5447872281074524e-01
    z[4,5,6]  R1557     -4.0512412786483765e-01
    z[4,5,6]  R1558     -0.0864330604672432
    z[4,5,6]  R1559     -4.5044098049402237e-02
    z[4,5,6]  R1560     6.6999264061450958e-02
    z[4,5,6]  R1561     -1.7671030014753342e-02
    z[4,5,6]  R1562     -2.5904160737991333e-01
    z[4,5,6]  R1563     -1.2953734397888184e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1564     -1
    z[5,4,0]  R1565     1
    z[5,4,0]  R1578     0.779071033000946
    z[5,4,0]  R1579     5.8420836925506592e-01
    z[5,4,0]  R1580     6.7144513130187988e-01
    z[5,4,0]  R1581     3.2904317975044250e-01
    z[5,4,0]  R1582     1.7415077984333038e-01
    z[5,4,0]  R1583     -6.2151956558227539e-01
    z[5,4,0]  R1584     -0.679585337638855
    z[5,4,0]  R1585     -1.2746493518352509e-01
    z[5,4,0]  R1586     -6.1485564708709717e-01
    z[5,4,0]  R1587     -2.4496018886566162e-01
    z[5,4,0]  R1588     -1.1797130107879639e-01
    z[5,4,0]  R1589     9.0190194547176361e-02
    z[5,4,0]  R1590     1.1989449709653854e-01
    z[5,4,0]  R1591     -0.966793417930603
    z[5,4,0]  R1592     -8.8179326057434082e-01
    z[5,4,0]  R1593     9.3940198421478271e-02
    z[5,4,0]  R1594     -9.0632176399230957e-01
    z[5,4,0]  R1595     -9.4841402769088745e-01
    z[5,4,0]  R1596     -8.6142563819885254e-01
    z[5,4,0]  R1597     -9.2385548353195190e-01
    z[5,4,0]  R1598     1.0810466483235359e-03
    z[5,4,0]  R1599     -5.8041056618094444e-03
    z[5,4,0]  R1600     -8.0310928821563721e-01
    z[5,4,0]  R1601     8.9932829141616821e-02
    z[5,4,0]  R1602     -1.6305711865425110e-01
    z[5,4,0]  R1603     3.3410970121622086e-02
    z[5,4,0]  R1604     1.1821080930531025e-02
    z[5,4,0]  R1605     1.5017437934875488e-01
    z[5,4,0]  R1606     -2.9990875720977783e-01
    z[5,4,0]  R1607     -1.9459144771099091e-01
    z[5,4,0]  R1608     0.623869776725769
    z[5,4,0]  R1609     4.7124966979026794e-01
    z[5,4,0]  R1610     4.6075388789176941e-01
    z[5,4,0]  R1611     7.0568728446960449e-01
    z[5,4,0]  R1612     -2.4869777262210846e-02
    z[5,4,0]  R1613     4.6758797764778137e-01
    z[5,4,0]  R1614     7.2842091321945190e-01
    z[5,4,0]  R1615     2.3502270877361298e-01
    z[5,4,0]  R1616     -6.4959675073623657e-01
    z[5,4,0]  R1617     -0.434550940990448
    z[5,4,0]  R1618     2.4478635191917419e-01
    z[5,4,0]  R1619     -8.0743575096130371e-01
    z[5,4,0]  R1620     -7.8418093919754028e-01
    z[5,4,0]  R1621     -7.4264776706695557e-01
    z[5,4,0]  R1622     -8.1033289432525635e-01
    z[5,4,0]  R1623     -0.653953492641449
    z[5,4,0]  R1624     -7.7817159891128540e-01
    z[5,4,0]  R1625     -6.3129687309265137e-01
    z[5,4,0]  R1626     -7.2030091285705566e-01
    z[5,4,0]  R1627     -0.704049825668335
    z[5,4,0]  R1628     3.6099374294281006e-01
    z[5,4,0]  R1629     -5.8742411434650421e-02
    z[5,4,0]  R1630     -3.2005450129508972e-01
    z[5,4,0]  R1631     -1.5671141445636749e-01
    z[5,4,0]  R1632     -6.1302137374877930e-01
    z[5,4,0]  R1633     -0.726642370223999
    z[5,4,0]  R1634     -5.1202350854873657e-01
    z[5,4,0]  R1635     -7.6954758167266846e-01
    z[5,4,0]  R1636     -4.6727684140205383e-01
    z[5,4,0]  R1637     0.0233807023614645
    z[5,4,0]  R1638     -3.0041972175240517e-02
    z[5,4,0]  R1639     5.7197922468185425e-01
    z[5,4,0]  R1640     1.9715158268809319e-02
    z[5,4,0]  R1641     2.7033057808876038e-01
    z[5,4,0]  R1642     -7.3233973979949951e-01
    z[5,4,0]  R1643     -6.9386434555053711e-01
    z[5,4,0]  R1644     -2.8363242745399475e-01
    z[5,4,0]  R1645     -6.0388818383216858e-02
    z[5,4,0]  R1646     -3.2891729474067688e-01
    z[5,4,0]  R1647     -1.4320007525384426e-02
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1566     -1
    z[5,4,1]  R1567     1
    z[5,4,1]  R1578     -2.4194441735744476e-01
    z[5,4,1]  R1579     -1.6875320672988892e-01
    z[5,4,1]  R1580     -4.5347511768341064e-01
    z[5,4,1]  R1581     -2.2050461173057556e-01
    z[5,4,1]  R1582     5.5806207656860352e-01
    z[5,4,1]  R1583     -1.0700858384370804e-01
    z[5,4,1]  R1584     -6.8935486488044262e-03
    z[5,4,1]  R1585     7.8041607141494751e-01
    z[5,4,1]  R1586     -4.4107872247695923e-01
    z[5,4,1]  R1587     -1.5828229486942291e-01
    z[5,4,1]  R1588     -9.5661687850952148e-01
    z[5,4,1]  R1589     6.7145246267318726e-01
    z[5,4,1]  R1590     3.7672051787376404e-01
    z[5,4,1]  R1591     -1.8287684023380280e-01
    z[5,4,1]  R1592     -0.260501503944397
    z[5,4,1]  R1593     -1.2866412103176117e-01
    z[5,4,1]  R1594     -1.5201704204082489e-01
    z[5,4,1]  R1595     2.3244591057300568e-01
    z[5,4,1]  R1596     -2.5467243790626526e-01
    z[5,4,1]  R1597     -1.7454622313380241e-02
    z[5,4,1]  R1598     4.5042019337415695e-02
    z[5,4,1]  R1599     6.1995232105255127e-01
    z[5,4,1]  R1600     -5.1690392196178436e-02
    z[5,4,1]  R1601     7.5798302888870239e-01
    z[5,4,1]  R1602     4.5514708757400513e-01
    z[5,4,1]  R1603     3.8885805010795593e-01
    z[5,4,1]  R1604     3.3261448144912720e-01
    z[5,4,1]  R1605     5.4179102182388306e-01
    z[5,4,1]  R1606     4.3273347616195679e-01
    z[5,4,1]  R1607     5.1244789361953735e-01
    z[5,4,1]  R1608     -5.7879839092493057e-02
    z[5,4,1]  R1609     4.7663533687591553e-01
    z[5,4,1]  R1610     0.136986643075943
    z[5,4,1]  R1611     1.8455080687999725e-02
    z[5,4,1]  R1612     -2.4925504624843597e-01
    z[5,4,1]  R1613     -0.396010160446167
    z[5,4,1]  R1614     -2.4161192774772644e-01
    z[5,4,1]  R1615     -5.0455331802368164e-01
    z[5,4,1]  R1616     4.0426418185234070e-02
    z[5,4,1]  R1617     1.4261446893215179e-02
    z[5,4,1]  R1618     5.0589561462402344e-01
    z[5,4,1]  R1619     -2.0128647983074188e-01
    z[5,4,1]  R1620     2.4805758893489838e-01
    z[5,4,1]  R1621     -2.9874911904335022e-01
    z[5,4,1]  R1622     -3.4483054280281067e-01
    z[5,4,1]  R1623     -0.194259375333786
    z[5,4,1]  R1624     4.3170002102851868e-01
    z[5,4,1]  R1625     -4.1876286268234253e-01
    z[5,4,1]  R1626     2.0251957699656487e-02
    z[5,4,1]  R1627     2.1078389883041382e-01
    z[5,4,1]  R1628     -7.9293411970138550e-01
    z[5,4,1]  R1629     -6.3022160530090332e-01
    z[5,4,1]  R1630     2.5774213671684265e-01
    z[5,4,1]  R1631     2.0051020383834839e-01
    z[5,4,1]  R1632     -1.8618722259998322e-01
    z[5,4,1]  R1633     2.9486516118049622e-01
    z[5,4,1]  R1634     -1.8806587159633636e-01
    z[5,4,1]  R1635     1.0639753937721252e-01
    z[5,4,1]  R1636     -1.5282559394836426e-01
    z[5,4,1]  R1637     3.2981187105178833e-01
    z[5,4,1]  R1638     8.7636457756161690e-03
    z[5,4,1]  R1639     -6.4705663919448853e-01
    z[5,4,1]  R1640     -5.9205174446105957e-01
    z[5,4,1]  R1641     -7.0185905694961548e-01
    z[5,4,1]  R1642     1.9007739424705505e-01
    z[5,4,1]  R1643     9.9332444369792938e-03
    z[5,4,1]  R1644     4.6222010254859924e-01
    z[5,4,1]  R1645     4.4346556067466736e-01
    z[5,4,1]  R1646     6.3291823863983154e-01
    z[5,4,1]  R1647     6.4614170789718628e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1568     -1
    z[5,4,2]  R1569     1
    z[5,4,2]  R1578     8.2626260817050934e-02
    z[5,4,2]  R1579     -1.4685069024562836e-01
    z[5,4,2]  R1580     -9.1911174356937408e-02
    z[5,4,2]  R1581     2.3904825747013092e-01
    z[5,4,2]  R1582     -2.8760096430778503e-01
    z[5,4,2]  R1583     5.1307892799377441e-01
    z[5,4,2]  R1584     -6.6355055570602417e-01
    z[5,4,2]  R1585     3.0482813715934753e-01
    z[5,4,2]  R1586     -3.4432035684585571e-01
    z[5,4,2]  R1587     7.3160648345947266e-01
    z[5,4,2]  R1588     -6.2353104352951050e-02
    z[5,4,2]  R1589     -9.0764164924621582e-02
    z[5,4,2]  R1590     -2.5851266458630562e-02
    z[5,4,2]  R1591     1.6871837899088860e-02
    z[5,4,2]  R1592     2.3442400991916656e-01
    z[5,4,2]  R1593     3.0210015177726746e-01
    z[5,4,2]  R1594     2.6036441326141357e-01
    z[5,4,2]  R1595     -1.9920321181416512e-02
    z[5,4,2]  R1596     1.5062890946865082e-01
    z[5,4,2]  R1597     -2.9315197467803955e-01
    z[5,4,2]  R1598     -7.2397851943969727e-01
    z[5,4,2]  R1599     -3.9215284585952759e-01
    z[5,4,2]  R1600     -2.9553228616714478e-01
    z[5,4,2]  R1601     1.4860726892948151e-01
    z[5,4,2]  R1602     0.322405606508255
    z[5,4,2]  R1603     1.3565708696842194e-01
    z[5,4,2]  R1604     -7.2536058723926544e-02
    z[5,4,2]  R1605     -6.6938288509845734e-02
    z[5,4,2]  R1606     2.0361553132534027e-01
    z[5,4,2]  R1607     2.4254187941551208e-01
    z[5,4,2]  R1608     -0.253171443939209
    z[5,4,2]  R1609     -0.256808340549469
    z[5,4,2]  R1610     -6.0175049304962158e-01
    z[5,4,2]  R1611     -5.7989460229873657e-01
    z[5,4,2]  R1612     -5.1363348960876465e-01
    z[5,4,2]  R1613     -6.0305446386337280e-01
    z[5,4,2]  R1614     2.6512950658798218e-01
    z[5,4,2]  R1615     -4.9417650699615479e-01
    z[5,4,2]  R1616     5.0010327249765396e-02
    z[5,4,2]  R1617     5.4412502050399780e-01
    z[5,4,2]  R1618     0.260545551776886
    z[5,4,2]  R1619     -3.0604428052902222e-01
    z[5,4,2]  R1620     -4.4277977943420410e-01
    z[5,4,2]  R1621     1.6066820919513702e-01
    z[5,4,2]  R1622     -2.6069043204188347e-02
    z[5,4,2]  R1623     4.4048935174942017e-01
    z[5,4,2]  R1624     -1.8304710090160370e-01
    z[5,4,2]  R1625     0.511961817741394
    z[5,4,2]  R1626     -2.6515352725982666e-01
    z[5,4,2]  R1627     -3.3389872312545776e-01
    z[5,4,2]  R1628     -3.9977619051933289e-01
    z[5,4,2]  R1629     -2.2786787152290344e-01
    z[5,4,2]  R1630     -2.3326057195663452e-01
    z[5,4,2]  R1631     -7.6868957281112671e-01
    z[5,4,2]  R1632     3.6510381102561951e-01
    z[5,4,2]  R1633     -1.0599025338888168e-01
    z[5,4,2]  R1634     -3.5606861114501953e-01
    z[5,4,2]  R1635     3.6365887522697449e-01
    z[5,4,2]  R1636     -0.0385645292699337
    z[5,4,2]  R1637     8.1564372777938843e-01
    z[5,4,2]  R1638     -4.6448025107383728e-01
    z[5,4,2]  R1639     -3.2947650551795959e-01
    z[5,4,2]  R1640     -5.5192488431930542e-01
    z[5,4,2]  R1641     8.3687156438827515e-02
    z[5,4,2]  R1642     7.0837266743183136e-02
    z[5,4,2]  R1643     4.0494126081466675e-01
    z[5,4,2]  R1644     7.1850842237472534e-01
    z[5,4,2]  R1645     8.5093015432357788e-01
    z[5,4,2]  R1646     5.2036416530609131e-01
    z[5,4,2]  R1647     6.1346948146820068e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1570     -1
    z[5,4,3]  R1571     1
    z[5,4,3]  R1578     5.0736564397811890e-01
    z[5,4,3]  R1579     2.7258267998695374e-01
    z[5,4,3]  R1580     1.7339875921607018e-02
    z[5,4,3]  R1581     -1.3244172558188438e-02
    z[5,4,3]  R1582     3.5233655571937561e-01
    z[5,4,3]  R1583     -2.9630497097969055e-01
    z[5,4,3]  R1584     -2.9017748311161995e-02
    z[5,4,3]  R1585     1.0817368328571320e-01
    z[5,4,3]  R1586     -1.8502433598041534e-01
    z[5,4,3]  R1587     2.8789332509040833e-01
    z[5,4,3]  R1588     -2.0504589378833771e-01
    z[5,4,3]  R1589     3.1491145491600037e-01
    z[5,4,3]  R1590     2.9783454537391663e-01
    z[5,4,3]  R1591     1.0463164187967777e-02
    z[5,4,3]  R1592     -2.1111422777175903e-01
    z[5,4,3]  R1593     1.6048426926136017e-01
    z[5,4,3]  R1594     1.8241165578365326e-01
    z[5,4,3]  R1595     -1.0723023861646652e-01
    z[5,4,3]  R1596     -6.6596224904060364e-02
    z[5,4,3]  R1597     3.3402517437934875e-02
    z[5,4,3]  R1598     4.4289156794548035e-01
    z[5,4,3]  R1599     0.362806111574173
    z[5,4,3]  R1600     -4.3815332651138306e-01
    z[5,4,3]  R1601     2.1115960180759430e-01
    z[5,4,3]  R1602     -7.6380264759063721e-01
    z[5,4,3]  R1603     -0.864760160446167
    z[5,4,3]  R1604     -8.3527755737304688e-01
    z[5,4,3]  R1605     -7.1430534124374390e-01
    z[5,4,3]  R1606     -4.3158787488937378e-01
    z[5,4,3]  R1607     -5.1876145601272583e-01
    z[5,4,3]  R1608     1.2492491304874420e-01
    z[5,4,3]  R1609     -2.2062879800796509e-01
    z[5,4,3]  R1610     2.6165612041950226e-02
    z[5,4,3]  R1611     -3.9458128809928894e-01
    z[5,4,3]  R1612     -1.7055764794349670e-02
    z[5,4,3]  R1613     -3.6346483230590820e-01
    z[5,4,3]  R1614     -5.4058402776718140e-01
    z[5,4,3]  R1615     -2.5114113092422485e-01
    z[5,4,3]  R1616     -6.9336640834808350e-01
    z[5,4,3]  R1617     0.0930207222700119
    z[5,4,3]  R1618     7.2303497791290283e-01
    z[5,4,3]  R1619     3.0968725681304932e-01
    z[5,4,3]  R1620     0.0782003104686737
    z[5,4,3]  R1621     4.2925807833671570e-01
    z[5,4,3]  R1622     2.4197527766227722e-01
    z[5,4,3]  R1623     8.6328610777854919e-02
    z[5,4,3]  R1624     1.4247921109199524e-01
    z[5,4,3]  R1625     6.5046057105064392e-02
    z[5,4,3]  R1626     0.437688410282135
    z[5,4,3]  R1627     6.1790838837623596e-02
    z[5,4,3]  R1628     1.7396517097949982e-02
    z[5,4,3]  R1629     -6.1151021718978882e-01
    z[5,4,3]  R1630     7.5240248441696167e-01
    z[5,4,3]  R1631     1.4732128381729126e-01
    z[5,4,3]  R1632     -3.4460049867630005e-01
    z[5,4,3]  R1633     2.1453826129436493e-01
    z[5,4,3]  R1634     -6.2274432182312012e-01
    z[5,4,3]  R1635     2.8538236021995544e-01
    z[5,4,3]  R1636     -6.9842666387557983e-01
    z[5,4,3]  R1637     1.2472738325595856e-01
    z[5,4,3]  R1638     7.7994906902313232e-01
    z[5,4,3]  R1639     -9.5606915652751923e-02
    z[5,4,3]  R1640     -2.6460930705070496e-01
    z[5,4,3]  R1641     -6.1491703987121582e-01
    z[5,4,3]  R1642     -5.0796729326248169e-01
    z[5,4,3]  R1643     -5.5004650354385376e-01
    z[5,4,3]  R1644     1.3698703050613403e-01
    z[5,4,3]  R1645     3.0471283942461014e-02
    z[5,4,3]  R1646     7.1395240724086761e-02
    z[5,4,3]  R1647     -1.2433141469955444e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1572     -1
    z[5,4,4]  R1573     1
    z[5,4,4]  R1578     -5.9939295053482056e-02
    z[5,4,4]  R1579     -4.1085857152938843e-01
    z[5,4,4]  R1580     -9.5507122576236725e-02
    z[5,4,4]  R1581     -4.8385095596313477e-01
    z[5,4,4]  R1582     -9.4575367867946625e-02
    z[5,4,4]  R1583     7.4334681034088135e-02
    z[5,4,4]  R1584     3.1032708287239075e-01
    z[5,4,4]  R1585     -5.8349415659904480e-02
    z[5,4,4]  R1586     -2.7441397309303284e-01
    z[5,4,4]  R1587     2.3987439274787903e-01
    z[5,4,4]  R1588     -2.6114033535122871e-02
    z[5,4,4]  R1589     4.6398764848709106e-01
    z[5,4,4]  R1590     5.9826242923736572e-01
    z[5,4,4]  R1591     9.2187933623790741e-02
    z[5,4,4]  R1592     1.1430983990430832e-01
    z[5,4,4]  R1593     8.3107441663742065e-01
    z[5,4,4]  R1594     -1.7113734781742096e-01
    z[5,4,4]  R1595     1.9617075100541115e-02
    z[5,4,4]  R1596     1.2819147109985352e-01
    z[5,4,4]  R1597     -2.0795492827892303e-01
    z[5,4,4]  R1598     4.2885860800743103e-01
    z[5,4,4]  R1599     -2.7451589703559875e-01
    z[5,4,4]  R1600     5.4069276899099350e-02
    z[5,4,4]  R1601     -4.3188178539276123e-01
    z[5,4,4]  R1602     1.2486344575881958e-01
    z[5,4,4]  R1603     -5.1023479551076889e-02
    z[5,4,4]  R1604     -1.8468033522367477e-02
    z[5,4,4]  R1605     5.6313324719667435e-02
    z[5,4,4]  R1606     1.1047400534152985e-01
    z[5,4,4]  R1607     -1.1940068751573563e-01
    z[5,4,4]  R1608     1.3428099453449249e-01
    z[5,4,4]  R1609     -5.0115477293729782e-02
    z[5,4,4]  R1610     -6.0040223598480225e-01
    z[5,4,4]  R1611     2.4425039067864418e-02
    z[5,4,4]  R1612     -6.1566889286041260e-01
    z[5,4,4]  R1613     -3.2677662372589111e-01
    z[5,4,4]  R1614     -8.8102911831811070e-04
    z[5,4,4]  R1615     4.9350139498710632e-01
    z[5,4,4]  R1616     -1.6764195263385773e-01
    z[5,4,4]  R1617     5.2765417844057083e-02
    z[5,4,4]  R1618     2.9596433043479919e-01
    z[5,4,4]  R1619     1.2117193639278412e-01
    z[5,4,4]  R1620     -5.5758882313966751e-02
    z[5,4,4]  R1621     0.349113792181015
    z[5,4,4]  R1622     -4.4087474234402180e-03
    z[5,4,4]  R1623     -3.5065639019012451e-01
    z[5,4,4]  R1624     3.4546020627021790e-01
    z[5,4,4]  R1625     3.5722330212593079e-02
    z[5,4,4]  R1626     4.6186572313308716e-01
    z[5,4,4]  R1627     1.2337285280227661e-01
    z[5,4,4]  R1628     -6.2775298953056335e-02
    z[5,4,4]  R1629     1.9002555310726166e-01
    z[5,4,4]  R1630     2.0022791624069214e-01
    z[5,4,4]  R1631     3.3235016465187073e-01
    z[5,4,4]  R1632     3.2712128758430481e-01
    z[5,4,4]  R1633     -1.9327478110790253e-01
    z[5,4,4]  R1634     3.2679072022438049e-01
    z[5,4,4]  R1635     0.0372639000415802
    z[5,4,4]  R1636     1.5612757205963135e-01
    z[5,4,4]  R1637     -4.4850343465805054e-01
    z[5,4,4]  R1638     1.7781293392181396e-01
    z[5,4,4]  R1639     8.8864214718341827e-02
    z[5,4,4]  R1640     4.1311812400817871e-01
    z[5,4,4]  R1641     6.5062172710895538e-02
    z[5,4,4]  R1642     4.6158386394381523e-03
    z[5,4,4]  R1643     -1.8049257993698120e-01
    z[5,4,4]  R1644     -2.6640057563781738e-01
    z[5,4,4]  R1645     -2.5441393256187439e-01
    z[5,4,4]  R1646     -1.5200361609458923e-01
    z[5,4,4]  R1647     -4.0366733074188232e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1574     -1
    z[5,4,5]  R1575     1
    z[5,4,5]  R1578     2.4319063127040863e-01
    z[5,4,5]  R1579     -5.8295673131942749e-01
    z[5,4,5]  R1580     -3.0251616239547729e-01
    z[5,4,5]  R1581     1.3146124780178070e-01
    z[5,4,5]  R1582     1.0964702069759369e-01
    z[5,4,5]  R1583     4.5769503712654114e-01
    z[5,4,5]  R1584     -2.2456597536802292e-02
    z[5,4,5]  R1585     -5.1432478427886963e-01
    z[5,4,5]  R1586     4.3542400002479553e-01
    z[5,4,5]  R1587     -4.8435342311859131e-01
    z[5,4,5]  R1588     1.5595848858356476e-01
    z[5,4,5]  R1589     -4.6357524394989014e-01
    z[5,4,5]  R1590     -3.7854495644569397e-01
    z[5,4,5]  R1591     2.6929848827421665e-03
    z[5,4,5]  R1592     -1.6067951917648315e-01
    z[5,4,5]  R1593     -3.7243768572807312e-01
    z[5,4,5]  R1594     9.3918427824974060e-02
    z[5,4,5]  R1595     2.9677912592887878e-02
    z[5,4,5]  R1596     -3.1352409720420837e-01
    z[5,4,5]  R1597     8.1947281956672668e-02
    z[5,4,5]  R1598     -2.7459457516670227e-01
    z[5,4,5]  R1599     9.1942958533763885e-02
    z[5,4,5]  R1600     7.3096431791782379e-02
    z[5,4,5]  R1601     7.3388456366956234e-03
    z[5,4,5]  R1602     2.3633052408695221e-01
    z[5,4,5]  R1603     0.277178019285202
    z[5,4,5]  R1604     4.2596709728240967e-01
    z[5,4,5]  R1605     4.0707957744598389e-01
    z[5,4,5]  R1606     6.4479613304138184e-01
    z[5,4,5]  R1607     5.8357077836990356e-01
    z[5,4,5]  R1608     -7.1296584606170654e-01
    z[5,4,5]  R1609     -6.5558588504791260e-01
    z[5,4,5]  R1610     5.1895566284656525e-02
    z[5,4,5]  R1611     -0.0933489054441452
    z[5,4,5]  R1612     -5.4180312156677246e-01
    z[5,4,5]  R1613     0.0987154096364975
    z[5,4,5]  R1614     3.5888131707906723e-02
    z[5,4,5]  R1615     3.3192914724349976e-01
    z[5,4,5]  R1616     -2.4730521440505981e-01
    z[5,4,5]  R1617     -7.0260518789291382e-01
    z[5,4,5]  R1618     2.0185057073831558e-02
    z[5,4,5]  R1619     2.9615047574043274e-01
    z[5,4,5]  R1620     4.6754315495491028e-02
    z[5,4,5]  R1621     -1.4542146027088165e-01
    z[5,4,5]  R1622     3.5263496637344360e-01
    z[5,4,5]  R1623     4.4210180640220642e-01
    z[5,4,5]  R1624     1.8660034239292145e-01
    z[5,4,5]  R1625     3.9712288975715637e-01
    z[5,4,5]  R1626     2.1152688190340996e-02
    z[5,4,5]  R1627     5.3880882263183594e-01
    z[5,4,5]  R1628     2.0857958495616913e-01
    z[5,4,5]  R1629     -3.1896722316741943e-01
    z[5,4,5]  R1630     -3.0509606003761292e-01
    z[5,4,5]  R1631     -1.3022434897720814e-02
    z[5,4,5]  R1632     -3.6757189035415649e-01
    z[5,4,5]  R1633     -5.2152538299560547e-01
    z[5,4,5]  R1634     -0.00387446372769773
    z[5,4,5]  R1635     -3.5772538185119629e-01
    z[5,4,5]  R1636     4.2368492484092712e-01
    z[5,4,5]  R1637     3.1375296413898468e-02
    z[5,4,5]  R1638     -3.2512894272804260e-01
    z[5,4,5]  R1639     2.9254025220870972e-01
    z[5,4,5]  R1640     -1.3117742538452148e-01
    z[5,4,5]  R1641     -1.7303550243377686e-01
    z[5,4,5]  R1642     3.7424415349960327e-01
    z[5,4,5]  R1643     6.4648225903511047e-02
    z[5,4,5]  R1644     -1.1710131540894508e-02
    z[5,4,5]  R1645     -8.1055760383605957e-02
    z[5,4,5]  R1646     3.1751343607902527e-01
    z[5,4,5]  R1647     1.3374280929565430e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1576     -1
    z[5,4,6]  R1577     1
    z[5,4,6]  R1578     -8.6774595081806183e-02
    z[5,4,6]  R1579     1.6035346686840057e-01
    z[5,4,6]  R1580     4.8387566208839417e-01
    z[5,4,6]  R1581     7.3102325201034546e-01
    z[5,4,6]  R1582     6.5606081485748291e-01
    z[5,4,6]  R1583     1.9027769565582275e-01
    z[5,4,6]  R1584     -1.2946607545018196e-02
    z[5,4,6]  R1585     -4.6336270868778229e-02
    z[5,4,6]  R1586     -9.8562121391296387e-02
    z[5,4,6]  R1587     6.8356923758983612e-02
    z[5,4,6]  R1588     -5.5044367909431458e-03
    z[5,4,6]  R1589     -0.0585097037255764
    z[5,4,6]  R1590     -5.0310939550399780e-01
    z[5,4,6]  R1591     -1.5154702961444855e-01
    z[5,4,6]  R1592     -1.2716592848300934e-01
    z[5,4,6]  R1593     1.6794812679290771e-01
    z[5,4,6]  R1594     1.2766954302787781e-01
    z[5,4,6]  R1595     -1.8253472447395325e-01
    z[5,4,6]  R1596     2.2634802758693695e-01
    z[5,4,6]  R1597     9.5769934356212616e-02
    z[5,4,6]  R1598     1.3546362519264221e-01
    z[5,4,6]  R1599     -4.9638783931732178e-01
    z[5,4,6]  R1600     2.5447872281074524e-01
    z[5,4,6]  R1601     -4.0512412786483765e-01
    z[5,4,6]  R1602     -0.0864330604672432
    z[5,4,6]  R1603     -4.5044098049402237e-02
    z[5,4,6]  R1604     6.6999264061450958e-02
    z[5,4,6]  R1605     -1.7671030014753342e-02
    z[5,4,6]  R1606     -2.5904160737991333e-01
    z[5,4,6]  R1607     -1.2953734397888184e-01
    z[5,4,6]  R1608     -3.7183862179517746e-02
    z[5,4,6]  R1609     6.1730358749628067e-02
    z[5,4,6]  R1610     -2.0730726420879364e-01
    z[5,4,6]  R1611     -1.9549399614334106e-02
    z[5,4,6]  R1612     -2.3333156481385231e-02
    z[5,4,6]  R1613     1.1058200150728226e-01
    z[5,4,6]  R1614     2.1728603541851044e-01
    z[5,4,6]  R1615     1.7084307968616486e-01
    z[5,4,6]  R1616     0.0621943362057209
    z[5,4,6]  R1617     9.8989777266979218e-02
    z[5,4,6]  R1618     -7.4050143361091614e-02
    z[5,4,6]  R1619     1.2479652464389801e-01
    z[5,4,6]  R1620     3.4068095684051514e-01
    z[5,4,6]  R1621     -7.8221470117568970e-02
    z[5,4,6]  R1622     2.0211410522460938e-01
    z[5,4,6]  R1623     -1.2128803133964539e-01
    z[5,4,6]  R1624     1.0726608335971832e-02
    z[5,4,6]  R1625     -2.7989331632852554e-02
    z[5,4,6]  R1626     7.1495153009891510e-02
    z[5,4,6]  R1627     1.9758987426757812e-01
    z[5,4,6]  R1628     -0.182672381401062
    z[5,4,6]  R1629     1.8881724774837494e-01
    z[5,4,6]  R1630     2.7827912569046021e-01
    z[5,4,6]  R1631     4.6046045422554016e-01
    z[5,4,6]  R1632     3.0882257223129272e-01
    z[5,4,6]  R1633     1.3579729199409485e-01
    z[5,4,6]  R1634     -2.8471130132675171e-01
    z[5,4,6]  R1635     2.3114760220050812e-01
    z[5,4,6]  R1636     2.5519579648971558e-01
    z[5,4,6]  R1637     8.7783776223659515e-02
    z[5,4,6]  R1638     1.9398948550224304e-01
    z[5,4,6]  R1639     -2.0732876658439636e-01
    z[5,4,6]  R1640     2.9423266649246216e-01
    z[5,4,6]  R1641     -1.2253300100564957e-01
    z[5,4,6]  R1642     -1.5627020597457886e-01
    z[5,4,6]  R1643     1.2315811216831207e-01
    z[5,4,6]  R1644     3.1587821245193481e-01
    z[5,4,6]  R1645     -5.8175154030323029e-02
    z[5,4,6]  R1646     3.0237710475921631e-01
    z[5,4,6]  R1647     9.8276712000370026e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1702     -1
    z[5,6,0]  R1703     1
    z[5,6,0]  R1716     0.779071033000946
    z[5,6,0]  R1717     5.8420836925506592e-01
    z[5,6,0]  R1718     6.7144513130187988e-01
    z[5,6,0]  R1719     3.2904317975044250e-01
    z[5,6,0]  R1720     1.7415077984333038e-01
    z[5,6,0]  R1721     -6.2151956558227539e-01
    z[5,6,0]  R1722     -0.679585337638855
    z[5,6,0]  R1723     -1.2746493518352509e-01
    z[5,6,0]  R1724     -6.1485564708709717e-01
    z[5,6,0]  R1725     -2.4496018886566162e-01
    z[5,6,0]  R1726     -1.1797130107879639e-01
    z[5,6,0]  R1727     9.0190194547176361e-02
    z[5,6,0]  R1728     1.1989449709653854e-01
    z[5,6,0]  R1729     -0.966793417930603
    z[5,6,0]  R1730     -8.8179326057434082e-01
    z[5,6,0]  R1731     9.3940198421478271e-02
    z[5,6,0]  R1732     -9.0632176399230957e-01
    z[5,6,0]  R1733     -9.4841402769088745e-01
    z[5,6,0]  R1734     -8.6142563819885254e-01
    z[5,6,0]  R1735     -9.2385548353195190e-01
    z[5,6,0]  R1736     1.0810466483235359e-03
    z[5,6,0]  R1737     -5.8041056618094444e-03
    z[5,6,0]  R1738     -8.0310928821563721e-01
    z[5,6,0]  R1739     8.9932829141616821e-02
    z[5,6,0]  R1740     -1.6305711865425110e-01
    z[5,6,0]  R1741     3.3410970121622086e-02
    z[5,6,0]  R1742     1.1821080930531025e-02
    z[5,6,0]  R1743     1.5017437934875488e-01
    z[5,6,0]  R1744     -2.9990875720977783e-01
    z[5,6,0]  R1745     -1.9459144771099091e-01
    z[5,6,0]  R1746     4.3771749734878540e-01
    z[5,6,0]  R1747     -0.0391731858253479
    z[5,6,0]  R1748     -7.9466208815574646e-02
    z[5,6,0]  R1749     2.8266519308090210e-02
    z[5,6,0]  R1750     3.2036021351814270e-01
    z[5,6,0]  R1751     -0.265390545129776
    z[5,6,0]  R1752     -4.0817371010780334e-01
    z[5,6,0]  R1753     -2.0675820112228394e-01
    z[5,6,0]  R1754     -2.1835803985595703e-01
    z[5,6,0]  R1755     -4.9946942925453186e-01
    z[5,6,0]  R1756     1.2552453577518463e-01
    z[5,6,0]  R1757     -4.2251676321029663e-01
    z[5,6,0]  R1758     -3.4860372543334961e-01
    z[5,6,0]  R1759     -3.0182841420173645e-01
    z[5,6,0]  R1760     -1.7583738267421722e-01
    z[5,6,0]  R1761     -3.7901768088340759e-01
    z[5,6,0]  R1762     -0.405945360660553
    z[5,6,0]  R1763     -2.5149145722389221e-01
    z[5,6,0]  R1764     -1.7418639361858368e-01
    z[5,6,0]  R1765     -3.5367617011070251e-01
    z[5,6,0]  R1766     3.9054846763610840e-01
    z[5,6,0]  R1767     -7.9799056053161621e-02
    z[5,6,0]  R1768     -1.7246741056442261e-01
    z[5,6,0]  R1769     -1.9270287454128265e-01
    z[5,6,0]  R1770     -3.9180281758308411e-01
    z[5,6,0]  R1771     5.6069605052471161e-02
    z[5,6,0]  R1772     5.9873914718627930e-01
    z[5,6,0]  R1773     6.5670222043991089e-01
    z[5,6,0]  R1774     3.5155642032623291e-01
    z[5,6,0]  R1775     2.6440745592117310e-01
    z[5,6,0]  R1776     -4.0735068917274475e-01
    z[5,6,0]  R1777     -4.5452676713466644e-02
    z[5,6,0]  R1778     -2.4952669441699982e-01
    z[5,6,0]  R1779     -0.157730370759964
    z[5,6,0]  R1780     -6.5584409236907959e-01
    z[5,6,0]  R1781     -7.1817688643932343e-02
    z[5,6,0]  R1782     -9.2405068874359131e-01
    z[5,6,0]  R1783     -9.2647778987884521e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1704     -1
    z[5,6,1]  R1705     1
    z[5,6,1]  R1716     -2.4194441735744476e-01
    z[5,6,1]  R1717     -1.6875320672988892e-01
    z[5,6,1]  R1718     -4.5347511768341064e-01
    z[5,6,1]  R1719     -2.2050461173057556e-01
    z[5,6,1]  R1720     5.5806207656860352e-01
    z[5,6,1]  R1721     -1.0700858384370804e-01
    z[5,6,1]  R1722     -6.8935486488044262e-03
    z[5,6,1]  R1723     7.8041607141494751e-01
    z[5,6,1]  R1724     -4.4107872247695923e-01
    z[5,6,1]  R1725     -1.5828229486942291e-01
    z[5,6,1]  R1726     -9.5661687850952148e-01
    z[5,6,1]  R1727     6.7145246267318726e-01
    z[5,6,1]  R1728     3.7672051787376404e-01
    z[5,6,1]  R1729     -1.8287684023380280e-01
    z[5,6,1]  R1730     -0.260501503944397
    z[5,6,1]  R1731     -1.2866412103176117e-01
    z[5,6,1]  R1732     -1.5201704204082489e-01
    z[5,6,1]  R1733     2.3244591057300568e-01
    z[5,6,1]  R1734     -2.5467243790626526e-01
    z[5,6,1]  R1735     -1.7454622313380241e-02
    z[5,6,1]  R1736     4.5042019337415695e-02
    z[5,6,1]  R1737     6.1995232105255127e-01
    z[5,6,1]  R1738     -5.1690392196178436e-02
    z[5,6,1]  R1739     7.5798302888870239e-01
    z[5,6,1]  R1740     4.5514708757400513e-01
    z[5,6,1]  R1741     3.8885805010795593e-01
    z[5,6,1]  R1742     3.3261448144912720e-01
    z[5,6,1]  R1743     5.4179102182388306e-01
    z[5,6,1]  R1744     4.3273347616195679e-01
    z[5,6,1]  R1745     5.1244789361953735e-01
    z[5,6,1]  R1746     -6.3786697387695312e-01
    z[5,6,1]  R1747     -7.8977859020233154e-01
    z[5,6,1]  R1748     -6.4975708723068237e-01
    z[5,6,1]  R1749     -1.4225061237812042e-01
    z[5,6,1]  R1750     -1.5911851823329926e-01
    z[5,6,1]  R1751     7.4082785844802856e-01
    z[5,6,1]  R1752     6.8664455413818359e-01
    z[5,6,1]  R1753     7.6769286394119263e-01
    z[5,6,1]  R1754     7.7680385112762451e-01
    z[5,6,1]  R1755     4.6662130951881409e-01
    z[5,6,1]  R1756     -4.3242397904396057e-01
    z[5,6,1]  R1757     8.2586342096328735e-01
    z[5,6,1]  R1758     8.0291557312011719e-01
    z[5,6,1]  R1759     9.1544169187545776e-01
    z[5,6,1]  R1760     8.8984721899032593e-01
    z[5,6,1]  R1761     8.6142480373382568e-01
    z[5,6,1]  R1762     8.5968142747879028e-01
    z[5,6,1]  R1763     8.9190471172332764e-01
    z[5,6,1]  R1764     9.2931693792343140e-01
    z[5,6,1]  R1765     3.6163869500160217e-01
    z[5,6,1]  R1766     -1.3008889555931091e-01
    z[5,6,1]  R1767     8.9851087331771851e-01
    z[5,6,1]  R1768     4.9530696868896484e-01
    z[5,6,1]  R1769     5.3853332996368408e-01
    z[5,6,1]  R1770     1.7717395722866058e-01
    z[5,6,1]  R1771     6.4072179794311523e-01
    z[5,6,1]  R1772     5.4572504758834839e-01
    z[5,6,1]  R1773     5.3164607286453247e-01
    z[5,6,1]  R1774     2.2954449057579041e-01
    z[5,6,1]  R1775     3.2020118832588196e-01
    z[5,6,1]  R1776     8.6463242769241333e-01
    z[5,6,1]  R1777     9.0580314397811890e-01
    z[5,6,1]  R1778     4.1640976071357727e-01
    z[5,6,1]  R1779     5.1957857608795166e-01
    z[5,6,1]  R1780     1.3578817248344421e-01
    z[5,6,1]  R1781     6.4486914873123169e-01
    z[5,6,1]  R1782     1.0491027496755123e-02
    z[5,6,1]  R1783     0.0408322811126709
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1706     -1
    z[5,6,2]  R1707     1
    z[5,6,2]  R1716     8.2626260817050934e-02
    z[5,6,2]  R1717     -1.4685069024562836e-01
    z[5,6,2]  R1718     -9.1911174356937408e-02
    z[5,6,2]  R1719     2.3904825747013092e-01
    z[5,6,2]  R1720     -2.8760096430778503e-01
    z[5,6,2]  R1721     5.1307892799377441e-01
    z[5,6,2]  R1722     -6.6355055570602417e-01
    z[5,6,2]  R1723     3.0482813715934753e-01
    z[5,6,2]  R1724     -3.4432035684585571e-01
    z[5,6,2]  R1725     7.3160648345947266e-01
    z[5,6,2]  R1726     -6.2353104352951050e-02
    z[5,6,2]  R1727     -9.0764164924621582e-02
    z[5,6,2]  R1728     -2.5851266458630562e-02
    z[5,6,2]  R1729     1.6871837899088860e-02
    z[5,6,2]  R1730     2.3442400991916656e-01
    z[5,6,2]  R1731     3.0210015177726746e-01
    z[5,6,2]  R1732     2.6036441326141357e-01
    z[5,6,2]  R1733     -1.9920321181416512e-02
    z[5,6,2]  R1734     1.5062890946865082e-01
    z[5,6,2]  R1735     -2.9315197467803955e-01
    z[5,6,2]  R1736     -7.2397851943969727e-01
    z[5,6,2]  R1737     -3.9215284585952759e-01
    z[5,6,2]  R1738     -2.9553228616714478e-01
    z[5,6,2]  R1739     1.4860726892948151e-01
    z[5,6,2]  R1740     0.322405606508255
    z[5,6,2]  R1741     1.3565708696842194e-01
    z[5,6,2]  R1742     -7.2536058723926544e-02
    z[5,6,2]  R1743     -6.6938288509845734e-02
    z[5,6,2]  R1744     2.0361553132534027e-01
    z[5,6,2]  R1745     2.4254187941551208e-01
    z[5,6,2]  R1746     5.9278792142868042e-01
    z[5,6,2]  R1747     1.7924880981445312e-01
    z[5,6,2]  R1748     -1.9406531751155853e-01
    z[5,6,2]  R1749     6.1752600595355034e-04
    z[5,6,2]  R1750     -1.7152637243270874e-02
    z[5,6,2]  R1751     -1.6465066000819206e-02
    z[5,6,2]  R1752     1.0463666170835495e-01
    z[5,6,2]  R1753     2.5198884308338165e-02
    z[5,6,2]  R1754     3.4140422940254211e-01
    z[5,6,2]  R1755     3.1607914716005325e-02
    z[5,6,2]  R1756     -4.9568369984626770e-01
    z[5,6,2]  R1757     -3.0892071127891541e-01
    z[5,6,2]  R1758     -2.8230714797973633e-01
    z[5,6,2]  R1759     7.4818126857280731e-02
    z[5,6,2]  R1760     -3.3239787817001343e-01
    z[5,6,2]  R1761     -2.3629236221313477e-01
    z[5,6,2]  R1762     -1.4860311150550842e-01
    z[5,6,2]  R1763     -1.7808496952056885e-01
    z[5,6,2]  R1764     -1.9802547991275787e-01
    z[5,6,2]  R1765     4.0964248776435852e-01
    z[5,6,2]  R1766     -3.2503670454025269e-01
    z[5,6,2]  R1767     1.9173230230808258e-01
    z[5,6,2]  R1768     3.0728760361671448e-01
    z[5,6,2]  R1769     3.2520228624343872e-01
    z[5,6,2]  R1770     1.8137063086032867e-01
    z[5,6,2]  R1771     1.3683487474918365e-01
    z[5,6,2]  R1772     1.9424313306808472e-01
    z[5,6,2]  R1773     1.5622487664222717e-01
    z[5,6,2]  R1774     2.5217339396476746e-01
    z[5,6,2]  R1775     3.9589118957519531e-01
    z[5,6,2]  R1776     -4.1760094463825226e-02
    z[5,6,2]  R1777     8.1125594675540924e-02
    z[5,6,2]  R1778     1.5294852852821350e-01
    z[5,6,2]  R1779     2.2984346747398376e-01
    z[5,6,2]  R1780     3.5008290410041809e-01
    z[5,6,2]  R1781     1.5769174695014954e-01
    z[5,6,2]  R1782     9.1569451615214348e-03
    z[5,6,2]  R1783     4.3774012476205826e-02
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1708     -1
    z[5,6,3]  R1709     1
    z[5,6,3]  R1716     5.0736564397811890e-01
    z[5,6,3]  R1717     2.7258267998695374e-01
    z[5,6,3]  R1718     1.7339875921607018e-02
    z[5,6,3]  R1719     -1.3244172558188438e-02
    z[5,6,3]  R1720     3.5233655571937561e-01
    z[5,6,3]  R1721     -2.9630497097969055e-01
    z[5,6,3]  R1722     -2.9017748311161995e-02
    z[5,6,3]  R1723     1.0817368328571320e-01
    z[5,6,3]  R1724     -1.8502433598041534e-01
    z[5,6,3]  R1725     2.8789332509040833e-01
    z[5,6,3]  R1726     -2.0504589378833771e-01
    z[5,6,3]  R1727     3.1491145491600037e-01
    z[5,6,3]  R1728     2.9783454537391663e-01
    z[5,6,3]  R1729     1.0463164187967777e-02
    z[5,6,3]  R1730     -2.1111422777175903e-01
    z[5,6,3]  R1731     1.6048426926136017e-01
    z[5,6,3]  R1732     1.8241165578365326e-01
    z[5,6,3]  R1733     -1.0723023861646652e-01
    z[5,6,3]  R1734     -6.6596224904060364e-02
    z[5,6,3]  R1735     3.3402517437934875e-02
    z[5,6,3]  R1736     4.4289156794548035e-01
    z[5,6,3]  R1737     0.362806111574173
    z[5,6,3]  R1738     -4.3815332651138306e-01
    z[5,6,3]  R1739     2.1115960180759430e-01
    z[5,6,3]  R1740     -7.6380264759063721e-01
    z[5,6,3]  R1741     -0.864760160446167
    z[5,6,3]  R1742     -8.3527755737304688e-01
    z[5,6,3]  R1743     -7.1430534124374390e-01
    z[5,6,3]  R1744     -4.3158787488937378e-01
    z[5,6,3]  R1745     -5.1876145601272583e-01
    z[5,6,3]  R1746     1.4309599995613098e-01
    z[5,6,3]  R1747     2.0340880379080772e-02
    z[5,6,3]  R1748     4.2678320407867432e-01
    z[5,6,3]  R1749     6.4608812332153320e-01
    z[5,6,3]  R1750     6.9559633731842041e-01
    z[5,6,3]  R1751     -4.2864549160003662e-01
    z[5,6,3]  R1752     -4.9572768807411194e-01
    z[5,6,3]  R1753     -2.1139457821846008e-01
    z[5,6,3]  R1754     8.2375489175319672e-02
    z[5,6,3]  R1755     -3.4938955307006836e-01
    z[5,6,3]  R1756     -5.2039200067520142e-01
    z[5,6,3]  R1757     -1.9592165946960449e-01
    z[5,6,3]  R1758     -2.3345731198787689e-01
    z[5,6,3]  R1759     -0.0956321656703949
    z[5,6,3]  R1760     3.1020302325487137e-02
    z[5,6,3]  R1761     1.2633083760738373e-01
    z[5,6,3]  R1762     1.5026177465915680e-01
    z[5,6,3]  R1763     1.2448097020387650e-01
    z[5,6,3]  R1764     1.5761420130729675e-01
    z[5,6,3]  R1765     -5.7083618640899658e-01
    z[5,6,3]  R1766     -1.4982836320996284e-02
    z[5,6,3]  R1767     -5.1439993083477020e-02
    z[5,6,3]  R1768     -0.683329164981842
    z[5,6,3]  R1769     -6.9987994432449341e-01
    z[5,6,3]  R1770     -0.806423008441925
    z[5,6,3]  R1771     -0.5048828125
    z[5,6,3]  R1772     -4.6675089001655579e-01
    z[5,6,3]  R1773     -4.0775465965270996e-01
    z[5,6,3]  R1774     -7.8291893005371094e-01
    z[5,6,3]  R1775     -7.0910942554473877e-01
    z[5,6,3]  R1776     -1.1135594546794891e-01
    z[5,6,3]  R1777     -1.2968315184116364e-01
    z[5,6,3]  R1778     -7.8794735670089722e-01
    z[5,6,3]  R1779     -7.2757571935653687e-01
    z[5,6,3]  R1780     -4.1660082340240479e-01
    z[5,6,3]  R1781     -0.606228232383728
    z[5,6,3]  R1782     -2.7904081344604492e-01
    z[5,6,3]  R1783     -1.6004312038421631e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1710     -1
    z[5,6,4]  R1711     1
    z[5,6,4]  R1716     -5.9939295053482056e-02
    z[5,6,4]  R1717     -4.1085857152938843e-01
    z[5,6,4]  R1718     -9.5507122576236725e-02
    z[5,6,4]  R1719     -4.8385095596313477e-01
    z[5,6,4]  R1720     -9.4575367867946625e-02
    z[5,6,4]  R1721     7.4334681034088135e-02
    z[5,6,4]  R1722     3.1032708287239075e-01
    z[5,6,4]  R1723     -5.8349415659904480e-02
    z[5,6,4]  R1724     -2.7441397309303284e-01
    z[5,6,4]  R1725     2.3987439274787903e-01
    z[5,6,4]  R1726     -2.6114033535122871e-02
    z[5,6,4]  R1727     4.6398764848709106e-01
    z[5,6,4]  R1728     5.9826242923736572e-01
    z[5,6,4]  R1729     9.2187933623790741e-02
    z[5,6,4]  R1730     1.1430983990430832e-01
    z[5,6,4]  R1731     8.3107441663742065e-01
    z[5,6,4]  R1732     -1.7113734781742096e-01
    z[5,6,4]  R1733     1.9617075100541115e-02
    z[5,6,4]  R1734     1.2819147109985352e-01
    z[5,6,4]  R1735     -2.0795492827892303e-01
    z[5,6,4]  R1736     4.2885860800743103e-01
    z[5,6,4]  R1737     -2.7451589703559875e-01
    z[5,6,4]  R1738     5.4069276899099350e-02
    z[5,6,4]  R1739     -4.3188178539276123e-01
    z[5,6,4]  R1740     1.2486344575881958e-01
    z[5,6,4]  R1741     -5.1023479551076889e-02
    z[5,6,4]  R1742     -1.8468033522367477e-02
    z[5,6,4]  R1743     5.6313324719667435e-02
    z[5,6,4]  R1744     1.1047400534152985e-01
    z[5,6,4]  R1745     -1.1940068751573563e-01
    z[5,6,4]  R1746     2.7665689587593079e-02
    z[5,6,4]  R1747     -2.4357780814170837e-01
    z[5,6,4]  R1748     2.6279106736183167e-02
    z[5,6,4]  R1749     -6.8679553270339966e-01
    z[5,6,4]  R1750     -1.4388452470302582e-01
    z[5,6,4]  R1751     -2.7435779571533203e-01
    z[5,6,4]  R1752     -2.6665431261062622e-01
    z[5,6,4]  R1753     -1.9006811082363129e-01
    z[5,6,4]  R1754     1.6959916055202484e-01
    z[5,6,4]  R1755     -1.8545034527778625e-01
    z[5,6,4]  R1756     -1.9016557931900024e-01
    z[5,6,4]  R1757     2.3510249331593513e-02
    z[5,6,4]  R1758     -2.3511119186878204e-02
    z[5,6,4]  R1759     1.0578073561191559e-01
    z[5,6,4]  R1760     -8.4315322339534760e-02
    z[5,6,4]  R1761     -5.6022573262453079e-02
    z[5,6,4]  R1762     -2.3705333471298218e-02
    z[5,6,4]  R1763     -1.2435884773731232e-01
    z[5,6,4]  R1764     6.8415597081184387e-02
    z[5,6,4]  R1765     1.3256542384624481e-01
    z[5,6,4]  R1766     6.2827128171920776e-01
    z[5,6,4]  R1767     9.6080303192138672e-02
    z[5,6,4]  R1768     5.9793880209326744e-03
    z[5,6,4]  R1769     2.1853532642126083e-02
    z[5,6,4]  R1770     2.4359565973281860e-01
    z[5,6,4]  R1771     0.316095769405365
    z[5,6,4]  R1772     6.8187497556209564e-02
    z[5,6,4]  R1773     -1.7738720774650574e-01
    z[5,6,4]  R1774     0.0387742780148983
    z[5,6,4]  R1775     1.8076086044311523e-01
    z[5,6,4]  R1776     1.9370573759078979e-01
    z[5,6,4]  R1777     5.4957389831542969e-02
    z[5,6,4]  R1778     1.5441209077835083e-01
    z[5,6,4]  R1779     2.4482429027557373e-01
    z[5,6,4]  R1780     2.0240475237369537e-01
    z[5,6,4]  R1781     1.2232014536857605e-01
    z[5,6,4]  R1782     -1.7041441053152084e-02
    z[5,6,4]  R1783     -2.8279429674148560e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1712     -1
    z[5,6,5]  R1713     1
    z[5,6,5]  R1716     2.4319063127040863e-01
    z[5,6,5]  R1717     -5.8295673131942749e-01
    z[5,6,5]  R1718     -3.0251616239547729e-01
    z[5,6,5]  R1719     1.3146124780178070e-01
    z[5,6,5]  R1720     1.0964702069759369e-01
    z[5,6,5]  R1721     4.5769503712654114e-01
    z[5,6,5]  R1722     -2.2456597536802292e-02
    z[5,6,5]  R1723     -5.1432478427886963e-01
    z[5,6,5]  R1724     4.3542400002479553e-01
    z[5,6,5]  R1725     -4.8435342311859131e-01
    z[5,6,5]  R1726     1.5595848858356476e-01
    z[5,6,5]  R1727     -4.6357524394989014e-01
    z[5,6,5]  R1728     -3.7854495644569397e-01
    z[5,6,5]  R1729     2.6929848827421665e-03
    z[5,6,5]  R1730     -1.6067951917648315e-01
    z[5,6,5]  R1731     -3.7243768572807312e-01
    z[5,6,5]  R1732     9.3918427824974060e-02
    z[5,6,5]  R1733     2.9677912592887878e-02
    z[5,6,5]  R1734     -3.1352409720420837e-01
    z[5,6,5]  R1735     8.1947281956672668e-02
    z[5,6,5]  R1736     -2.7459457516670227e-01
    z[5,6,5]  R1737     9.1942958533763885e-02
    z[5,6,5]  R1738     7.3096431791782379e-02
    z[5,6,5]  R1739     7.3388456366956234e-03
    z[5,6,5]  R1740     2.3633052408695221e-01
    z[5,6,5]  R1741     0.277178019285202
    z[5,6,5]  R1742     4.2596709728240967e-01
    z[5,6,5]  R1743     4.0707957744598389e-01
    z[5,6,5]  R1744     6.4479613304138184e-01
    z[5,6,5]  R1745     5.8357077836990356e-01
    z[5,6,5]  R1746     3.6649480462074280e-03
    z[5,6,5]  R1747     -0.137080579996109
    z[5,6,5]  R1748     -5.3621435165405273e-01
    z[5,6,5]  R1749     1.3689872622489929e-01
    z[5,6,5]  R1750     5.7584780454635620e-01
    z[5,6,5]  R1751     3.4704136848449707e-01
    z[5,6,5]  R1752     -0.0242563858628273
    z[5,6,5]  R1753     -1.7235971987247467e-01
    z[5,6,5]  R1754     -2.6464128494262695e-01
    z[5,6,5]  R1755     -6.1068701744079590e-01
    z[5,6,5]  R1756     2.8620478510856628e-01
    z[5,6,5]  R1757     -5.8314543217420578e-02
    z[5,6,5]  R1758     2.1562939882278442e-01
    z[5,6,5]  R1759     -9.9507674574851990e-02
    z[5,6,5]  R1760     1.8301378190517426e-01
    z[5,6,5]  R1761     -5.8333072811365128e-03
    z[5,6,5]  R1762     -2.2119371592998505e-01
    z[5,6,5]  R1763     -2.1240086853504181e-01
    z[5,6,5]  R1764     5.4374445229768753e-02
    z[5,6,5]  R1765     0.46855628490448
    z[5,6,5]  R1766     4.4005391001701355e-01
    z[5,6,5]  R1767     3.4282210469245911e-01
    z[5,6,5]  R1768     3.7020862102508545e-01
    z[5,6,5]  R1769     2.7709373831748962e-01
    z[5,6,5]  R1770     2.6857927441596985e-02
    z[5,6,5]  R1771     3.1723475456237793e-01
    z[5,6,5]  R1772     -2.6693260669708252e-01
    z[5,6,5]  R1773     -1.7569415271282196e-01
    z[5,6,5]  R1774     -2.7833628654479980e-01
    z[5,6,5]  R1775     -2.1191258728504181e-01
    z[5,6,5]  R1776     -1.5550585091114044e-01
    z[5,6,5]  R1777     3.7700343132019043e-01
    z[5,6,5]  R1778     2.4028272926807404e-01
    z[5,6,5]  R1779     2.4893839657306671e-01
    z[5,6,5]  R1780     4.6183583140373230e-01
    z[5,6,5]  R1781     4.0268638730049133e-01
    z[5,6,5]  R1782     -2.1071991324424744e-01
    z[5,6,5]  R1783     -5.5100526660680771e-02
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1714     -1
    z[5,6,6]  R1715     1
    z[5,6,6]  R1716     -8.6774595081806183e-02
    z[5,6,6]  R1717     1.6035346686840057e-01
    z[5,6,6]  R1718     4.8387566208839417e-01
    z[5,6,6]  R1719     7.3102325201034546e-01
    z[5,6,6]  R1720     6.5606081485748291e-01
    z[5,6,6]  R1721     1.9027769565582275e-01
    z[5,6,6]  R1722     -1.2946607545018196e-02
    z[5,6,6]  R1723     -4.6336270868778229e-02
    z[5,6,6]  R1724     -9.8562121391296387e-02
    z[5,6,6]  R1725     6.8356923758983612e-02
    z[5,6,6]  R1726     -5.5044367909431458e-03
    z[5,6,6]  R1727     -0.0585097037255764
    z[5,6,6]  R1728     -5.0310939550399780e-01
    z[5,6,6]  R1729     -1.5154702961444855e-01
    z[5,6,6]  R1730     -1.2716592848300934e-01
    z[5,6,6]  R1731     1.6794812679290771e-01
    z[5,6,6]  R1732     1.2766954302787781e-01
    z[5,6,6]  R1733     -1.8253472447395325e-01
    z[5,6,6]  R1734     2.2634802758693695e-01
    z[5,6,6]  R1735     9.5769934356212616e-02
    z[5,6,6]  R1736     1.3546362519264221e-01
    z[5,6,6]  R1737     -4.9638783931732178e-01
    z[5,6,6]  R1738     2.5447872281074524e-01
    z[5,6,6]  R1739     -4.0512412786483765e-01
    z[5,6,6]  R1740     -0.0864330604672432
    z[5,6,6]  R1741     -4.5044098049402237e-02
    z[5,6,6]  R1742     6.6999264061450958e-02
    z[5,6,6]  R1743     -1.7671030014753342e-02
    z[5,6,6]  R1744     -2.5904160737991333e-01
    z[5,6,6]  R1745     -1.2953734397888184e-01
    z[5,6,6]  R1746     -1.6993029415607452e-01
    z[5,6,6]  R1747     5.1385802030563354e-01
    z[5,6,6]  R1748     2.5195059180259705e-01
    z[5,6,6]  R1749     0.266657292842865
    z[5,6,6]  R1750     -1.8867613375186920e-01
    z[5,6,6]  R1751     -3.2001528888940811e-02
    z[5,6,6]  R1752     -1.8310065567493439e-01
    z[5,6,6]  R1753     0.506697416305542
    z[5,6,6]  R1754     3.5602548718452454e-01
    z[5,6,6]  R1755     4.8910453915596008e-02
    z[5,6,6]  R1756     -0.403319776058197
    z[5,6,6]  R1757     -4.0726795792579651e-02
    z[5,6,6]  R1758     2.2924545407295227e-01
    z[5,6,6]  R1759     -1.8716701865196228e-01
    z[5,6,6]  R1760     -1.5874285995960236e-01
    z[5,6,6]  R1761     1.9830964505672455e-01
    z[5,6,6]  R1762     -4.4789519160985947e-02
    z[5,6,6]  R1763     -1.8294534087181091e-01
    z[5,6,6]  R1764     -1.8529818952083588e-01
    z[5,6,6]  R1765     1.1554679274559021e-01
    z[5,6,6]  R1766     3.6919271945953369e-01
    z[5,6,6]  R1767     1.4193138480186462e-01
    z[5,6,6]  R1768     1.6270010173320770e-01
    z[5,6,6]  R1769     -6.5023888600990176e-04
    z[5,6,6]  R1770     2.6800441741943359e-01
    z[5,6,6]  R1771     -3.3488348126411438e-01
    z[5,6,6]  R1772     1.1048205941915512e-01
    z[5,6,6]  R1773     1.8190686404705048e-01
    z[5,6,6]  R1774     2.6113128662109375e-01
    z[5,6,6]  R1775     3.0068665742874146e-01
    z[5,6,6]  R1776     1.0309263318777084e-01
    z[5,6,6]  R1777     -9.4360075891017914e-02
    z[5,6,6]  R1778     1.9623020291328430e-01
    z[5,6,6]  R1779     3.2488524913787842e-02
    z[5,6,6]  R1780     -3.2493855804204941e-02
    z[5,6,6]  R1781     -9.7407236695289612e-02
    z[5,6,6]  R1782     -1.5290263295173645e-01
    z[5,6,6]  R1783     -1.7156034708023071e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R1784     -1
    z[6,5,0]  R1785     1
    z[6,5,0]  R1798     4.3771749734878540e-01
    z[6,5,0]  R1799     -0.0391731858253479
    z[6,5,0]  R1800     -7.9466208815574646e-02
    z[6,5,0]  R1801     2.8266519308090210e-02
    z[6,5,0]  R1802     3.2036021351814270e-01
    z[6,5,0]  R1803     -0.265390545129776
    z[6,5,0]  R1804     -4.0817371010780334e-01
    z[6,5,0]  R1805     -2.0675820112228394e-01
    z[6,5,0]  R1806     -2.1835803985595703e-01
    z[6,5,0]  R1807     -4.9946942925453186e-01
    z[6,5,0]  R1808     1.2552453577518463e-01
    z[6,5,0]  R1809     -4.2251676321029663e-01
    z[6,5,0]  R1810     -3.4860372543334961e-01
    z[6,5,0]  R1811     -3.0182841420173645e-01
    z[6,5,0]  R1812     -1.7583738267421722e-01
    z[6,5,0]  R1813     -3.7901768088340759e-01
    z[6,5,0]  R1814     -0.405945360660553
    z[6,5,0]  R1815     -2.5149145722389221e-01
    z[6,5,0]  R1816     -1.7418639361858368e-01
    z[6,5,0]  R1817     -3.5367617011070251e-01
    z[6,5,0]  R1818     3.9054846763610840e-01
    z[6,5,0]  R1819     -7.9799056053161621e-02
    z[6,5,0]  R1820     -1.7246741056442261e-01
    z[6,5,0]  R1821     -1.9270287454128265e-01
    z[6,5,0]  R1822     -3.9180281758308411e-01
    z[6,5,0]  R1823     5.6069605052471161e-02
    z[6,5,0]  R1824     5.9873914718627930e-01
    z[6,5,0]  R1825     6.5670222043991089e-01
    z[6,5,0]  R1826     3.5155642032623291e-01
    z[6,5,0]  R1827     2.6440745592117310e-01
    z[6,5,0]  R1828     -4.0735068917274475e-01
    z[6,5,0]  R1829     -4.5452676713466644e-02
    z[6,5,0]  R1830     -2.4952669441699982e-01
    z[6,5,0]  R1831     -0.157730370759964
    z[6,5,0]  R1832     -6.5584409236907959e-01
    z[6,5,0]  R1833     -7.1817688643932343e-02
    z[6,5,0]  R1834     -9.2405068874359131e-01
    z[6,5,0]  R1835     -9.2647778987884521e-01
    z[6,5,0]  R1836     0.779071033000946
    z[6,5,0]  R1837     5.8420836925506592e-01
    z[6,5,0]  R1838     6.7144513130187988e-01
    z[6,5,0]  R1839     3.2904317975044250e-01
    z[6,5,0]  R1840     1.7415077984333038e-01
    z[6,5,0]  R1841     -6.2151956558227539e-01
    z[6,5,0]  R1842     -0.679585337638855
    z[6,5,0]  R1843     -1.2746493518352509e-01
    z[6,5,0]  R1844     -6.1485564708709717e-01
    z[6,5,0]  R1845     -2.4496018886566162e-01
    z[6,5,0]  R1846     -1.1797130107879639e-01
    z[6,5,0]  R1847     9.0190194547176361e-02
    z[6,5,0]  R1848     1.1989449709653854e-01
    z[6,5,0]  R1849     -0.966793417930603
    z[6,5,0]  R1850     -8.8179326057434082e-01
    z[6,5,0]  R1851     9.3940198421478271e-02
    z[6,5,0]  R1852     -9.0632176399230957e-01
    z[6,5,0]  R1853     -9.4841402769088745e-01
    z[6,5,0]  R1854     -8.6142563819885254e-01
    z[6,5,0]  R1855     -9.2385548353195190e-01
    z[6,5,0]  R1856     1.0810466483235359e-03
    z[6,5,0]  R1857     -5.8041056618094444e-03
    z[6,5,0]  R1858     -8.0310928821563721e-01
    z[6,5,0]  R1859     8.9932829141616821e-02
    z[6,5,0]  R1860     -1.6305711865425110e-01
    z[6,5,0]  R1861     3.3410970121622086e-02
    z[6,5,0]  R1862     1.1821080930531025e-02
    z[6,5,0]  R1863     1.5017437934875488e-01
    z[6,5,0]  R1864     -2.9990875720977783e-01
    z[6,5,0]  R1865     -1.9459144771099091e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R1786     -1
    z[6,5,1]  R1787     1
    z[6,5,1]  R1798     -6.3786697387695312e-01
    z[6,5,1]  R1799     -7.8977859020233154e-01
    z[6,5,1]  R1800     -6.4975708723068237e-01
    z[6,5,1]  R1801     -1.4225061237812042e-01
    z[6,5,1]  R1802     -1.5911851823329926e-01
    z[6,5,1]  R1803     7.4082785844802856e-01
    z[6,5,1]  R1804     6.8664455413818359e-01
    z[6,5,1]  R1805     7.6769286394119263e-01
    z[6,5,1]  R1806     7.7680385112762451e-01
    z[6,5,1]  R1807     4.6662130951881409e-01
    z[6,5,1]  R1808     -4.3242397904396057e-01
    z[6,5,1]  R1809     8.2586342096328735e-01
    z[6,5,1]  R1810     8.0291557312011719e-01
    z[6,5,1]  R1811     9.1544169187545776e-01
    z[6,5,1]  R1812     8.8984721899032593e-01
    z[6,5,1]  R1813     8.6142480373382568e-01
    z[6,5,1]  R1814     8.5968142747879028e-01
    z[6,5,1]  R1815     8.9190471172332764e-01
    z[6,5,1]  R1816     9.2931693792343140e-01
    z[6,5,1]  R1817     3.6163869500160217e-01
    z[6,5,1]  R1818     -1.3008889555931091e-01
    z[6,5,1]  R1819     8.9851087331771851e-01
    z[6,5,1]  R1820     4.9530696868896484e-01
    z[6,5,1]  R1821     5.3853332996368408e-01
    z[6,5,1]  R1822     1.7717395722866058e-01
    z[6,5,1]  R1823     6.4072179794311523e-01
    z[6,5,1]  R1824     5.4572504758834839e-01
    z[6,5,1]  R1825     5.3164607286453247e-01
    z[6,5,1]  R1826     2.2954449057579041e-01
    z[6,5,1]  R1827     3.2020118832588196e-01
    z[6,5,1]  R1828     8.6463242769241333e-01
    z[6,5,1]  R1829     9.0580314397811890e-01
    z[6,5,1]  R1830     4.1640976071357727e-01
    z[6,5,1]  R1831     5.1957857608795166e-01
    z[6,5,1]  R1832     1.3578817248344421e-01
    z[6,5,1]  R1833     6.4486914873123169e-01
    z[6,5,1]  R1834     1.0491027496755123e-02
    z[6,5,1]  R1835     0.0408322811126709
    z[6,5,1]  R1836     -2.4194441735744476e-01
    z[6,5,1]  R1837     -1.6875320672988892e-01
    z[6,5,1]  R1838     -4.5347511768341064e-01
    z[6,5,1]  R1839     -2.2050461173057556e-01
    z[6,5,1]  R1840     5.5806207656860352e-01
    z[6,5,1]  R1841     -1.0700858384370804e-01
    z[6,5,1]  R1842     -6.8935486488044262e-03
    z[6,5,1]  R1843     7.8041607141494751e-01
    z[6,5,1]  R1844     -4.4107872247695923e-01
    z[6,5,1]  R1845     -1.5828229486942291e-01
    z[6,5,1]  R1846     -9.5661687850952148e-01
    z[6,5,1]  R1847     6.7145246267318726e-01
    z[6,5,1]  R1848     3.7672051787376404e-01
    z[6,5,1]  R1849     -1.8287684023380280e-01
    z[6,5,1]  R1850     -0.260501503944397
    z[6,5,1]  R1851     -1.2866412103176117e-01
    z[6,5,1]  R1852     -1.5201704204082489e-01
    z[6,5,1]  R1853     2.3244591057300568e-01
    z[6,5,1]  R1854     -2.5467243790626526e-01
    z[6,5,1]  R1855     -1.7454622313380241e-02
    z[6,5,1]  R1856     4.5042019337415695e-02
    z[6,5,1]  R1857     6.1995232105255127e-01
    z[6,5,1]  R1858     -5.1690392196178436e-02
    z[6,5,1]  R1859     7.5798302888870239e-01
    z[6,5,1]  R1860     4.5514708757400513e-01
    z[6,5,1]  R1861     3.8885805010795593e-01
    z[6,5,1]  R1862     3.3261448144912720e-01
    z[6,5,1]  R1863     5.4179102182388306e-01
    z[6,5,1]  R1864     4.3273347616195679e-01
    z[6,5,1]  R1865     5.1244789361953735e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R1788     -1
    z[6,5,2]  R1789     1
    z[6,5,2]  R1798     5.9278792142868042e-01
    z[6,5,2]  R1799     1.7924880981445312e-01
    z[6,5,2]  R1800     -1.9406531751155853e-01
    z[6,5,2]  R1801     6.1752600595355034e-04
    z[6,5,2]  R1802     -1.7152637243270874e-02
    z[6,5,2]  R1803     -1.6465066000819206e-02
    z[6,5,2]  R1804     1.0463666170835495e-01
    z[6,5,2]  R1805     2.5198884308338165e-02
    z[6,5,2]  R1806     3.4140422940254211e-01
    z[6,5,2]  R1807     3.1607914716005325e-02
    z[6,5,2]  R1808     -4.9568369984626770e-01
    z[6,5,2]  R1809     -3.0892071127891541e-01
    z[6,5,2]  R1810     -2.8230714797973633e-01
    z[6,5,2]  R1811     7.4818126857280731e-02
    z[6,5,2]  R1812     -3.3239787817001343e-01
    z[6,5,2]  R1813     -2.3629236221313477e-01
    z[6,5,2]  R1814     -1.4860311150550842e-01
    z[6,5,2]  R1815     -1.7808496952056885e-01
    z[6,5,2]  R1816     -1.9802547991275787e-01
    z[6,5,2]  R1817     4.0964248776435852e-01
    z[6,5,2]  R1818     -3.2503670454025269e-01
    z[6,5,2]  R1819     1.9173230230808258e-01
    z[6,5,2]  R1820     3.0728760361671448e-01
    z[6,5,2]  R1821     3.2520228624343872e-01
    z[6,5,2]  R1822     1.8137063086032867e-01
    z[6,5,2]  R1823     1.3683487474918365e-01
    z[6,5,2]  R1824     1.9424313306808472e-01
    z[6,5,2]  R1825     1.5622487664222717e-01
    z[6,5,2]  R1826     2.5217339396476746e-01
    z[6,5,2]  R1827     3.9589118957519531e-01
    z[6,5,2]  R1828     -4.1760094463825226e-02
    z[6,5,2]  R1829     8.1125594675540924e-02
    z[6,5,2]  R1830     1.5294852852821350e-01
    z[6,5,2]  R1831     2.2984346747398376e-01
    z[6,5,2]  R1832     3.5008290410041809e-01
    z[6,5,2]  R1833     1.5769174695014954e-01
    z[6,5,2]  R1834     9.1569451615214348e-03
    z[6,5,2]  R1835     4.3774012476205826e-02
    z[6,5,2]  R1836     8.2626260817050934e-02
    z[6,5,2]  R1837     -1.4685069024562836e-01
    z[6,5,2]  R1838     -9.1911174356937408e-02
    z[6,5,2]  R1839     2.3904825747013092e-01
    z[6,5,2]  R1840     -2.8760096430778503e-01
    z[6,5,2]  R1841     5.1307892799377441e-01
    z[6,5,2]  R1842     -6.6355055570602417e-01
    z[6,5,2]  R1843     3.0482813715934753e-01
    z[6,5,2]  R1844     -3.4432035684585571e-01
    z[6,5,2]  R1845     7.3160648345947266e-01
    z[6,5,2]  R1846     -6.2353104352951050e-02
    z[6,5,2]  R1847     -9.0764164924621582e-02
    z[6,5,2]  R1848     -2.5851266458630562e-02
    z[6,5,2]  R1849     1.6871837899088860e-02
    z[6,5,2]  R1850     2.3442400991916656e-01
    z[6,5,2]  R1851     3.0210015177726746e-01
    z[6,5,2]  R1852     2.6036441326141357e-01
    z[6,5,2]  R1853     -1.9920321181416512e-02
    z[6,5,2]  R1854     1.5062890946865082e-01
    z[6,5,2]  R1855     -2.9315197467803955e-01
    z[6,5,2]  R1856     -7.2397851943969727e-01
    z[6,5,2]  R1857     -3.9215284585952759e-01
    z[6,5,2]  R1858     -2.9553228616714478e-01
    z[6,5,2]  R1859     1.4860726892948151e-01
    z[6,5,2]  R1860     0.322405606508255
    z[6,5,2]  R1861     1.3565708696842194e-01
    z[6,5,2]  R1862     -7.2536058723926544e-02
    z[6,5,2]  R1863     -6.6938288509845734e-02
    z[6,5,2]  R1864     2.0361553132534027e-01
    z[6,5,2]  R1865     2.4254187941551208e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R1790     -1
    z[6,5,3]  R1791     1
    z[6,5,3]  R1798     1.4309599995613098e-01
    z[6,5,3]  R1799     2.0340880379080772e-02
    z[6,5,3]  R1800     4.2678320407867432e-01
    z[6,5,3]  R1801     6.4608812332153320e-01
    z[6,5,3]  R1802     6.9559633731842041e-01
    z[6,5,3]  R1803     -4.2864549160003662e-01
    z[6,5,3]  R1804     -4.9572768807411194e-01
    z[6,5,3]  R1805     -2.1139457821846008e-01
    z[6,5,3]  R1806     8.2375489175319672e-02
    z[6,5,3]  R1807     -3.4938955307006836e-01
    z[6,5,3]  R1808     -5.2039200067520142e-01
    z[6,5,3]  R1809     -1.9592165946960449e-01
    z[6,5,3]  R1810     -2.3345731198787689e-01
    z[6,5,3]  R1811     -0.0956321656703949
    z[6,5,3]  R1812     3.1020302325487137e-02
    z[6,5,3]  R1813     1.2633083760738373e-01
    z[6,5,3]  R1814     1.5026177465915680e-01
    z[6,5,3]  R1815     1.2448097020387650e-01
    z[6,5,3]  R1816     1.5761420130729675e-01
    z[6,5,3]  R1817     -5.7083618640899658e-01
    z[6,5,3]  R1818     -1.4982836320996284e-02
    z[6,5,3]  R1819     -5.1439993083477020e-02
    z[6,5,3]  R1820     -0.683329164981842
    z[6,5,3]  R1821     -6.9987994432449341e-01
    z[6,5,3]  R1822     -0.806423008441925
    z[6,5,3]  R1823     -0.5048828125
    z[6,5,3]  R1824     -4.6675089001655579e-01
    z[6,5,3]  R1825     -4.0775465965270996e-01
    z[6,5,3]  R1826     -7.8291893005371094e-01
    z[6,5,3]  R1827     -7.0910942554473877e-01
    z[6,5,3]  R1828     -1.1135594546794891e-01
    z[6,5,3]  R1829     -1.2968315184116364e-01
    z[6,5,3]  R1830     -7.8794735670089722e-01
    z[6,5,3]  R1831     -7.2757571935653687e-01
    z[6,5,3]  R1832     -4.1660082340240479e-01
    z[6,5,3]  R1833     -0.606228232383728
    z[6,5,3]  R1834     -2.7904081344604492e-01
    z[6,5,3]  R1835     -1.6004312038421631e-01
    z[6,5,3]  R1836     5.0736564397811890e-01
    z[6,5,3]  R1837     2.7258267998695374e-01
    z[6,5,3]  R1838     1.7339875921607018e-02
    z[6,5,3]  R1839     -1.3244172558188438e-02
    z[6,5,3]  R1840     3.5233655571937561e-01
    z[6,5,3]  R1841     -2.9630497097969055e-01
    z[6,5,3]  R1842     -2.9017748311161995e-02
    z[6,5,3]  R1843     1.0817368328571320e-01
    z[6,5,3]  R1844     -1.8502433598041534e-01
    z[6,5,3]  R1845     2.8789332509040833e-01
    z[6,5,3]  R1846     -2.0504589378833771e-01
    z[6,5,3]  R1847     3.1491145491600037e-01
    z[6,5,3]  R1848     2.9783454537391663e-01
    z[6,5,3]  R1849     1.0463164187967777e-02
    z[6,5,3]  R1850     -2.1111422777175903e-01
    z[6,5,3]  R1851     1.6048426926136017e-01
    z[6,5,3]  R1852     1.8241165578365326e-01
    z[6,5,3]  R1853     -1.0723023861646652e-01
    z[6,5,3]  R1854     -6.6596224904060364e-02
    z[6,5,3]  R1855     3.3402517437934875e-02
    z[6,5,3]  R1856     4.4289156794548035e-01
    z[6,5,3]  R1857     0.362806111574173
    z[6,5,3]  R1858     -4.3815332651138306e-01
    z[6,5,3]  R1859     2.1115960180759430e-01
    z[6,5,3]  R1860     -7.6380264759063721e-01
    z[6,5,3]  R1861     -0.864760160446167
    z[6,5,3]  R1862     -8.3527755737304688e-01
    z[6,5,3]  R1863     -7.1430534124374390e-01
    z[6,5,3]  R1864     -4.3158787488937378e-01
    z[6,5,3]  R1865     -5.1876145601272583e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R1792     -1
    z[6,5,4]  R1793     1
    z[6,5,4]  R1798     2.7665689587593079e-02
    z[6,5,4]  R1799     -2.4357780814170837e-01
    z[6,5,4]  R1800     2.6279106736183167e-02
    z[6,5,4]  R1801     -6.8679553270339966e-01
    z[6,5,4]  R1802     -1.4388452470302582e-01
    z[6,5,4]  R1803     -2.7435779571533203e-01
    z[6,5,4]  R1804     -2.6665431261062622e-01
    z[6,5,4]  R1805     -1.9006811082363129e-01
    z[6,5,4]  R1806     1.6959916055202484e-01
    z[6,5,4]  R1807     -1.8545034527778625e-01
    z[6,5,4]  R1808     -1.9016557931900024e-01
    z[6,5,4]  R1809     2.3510249331593513e-02
    z[6,5,4]  R1810     -2.3511119186878204e-02
    z[6,5,4]  R1811     1.0578073561191559e-01
    z[6,5,4]  R1812     -8.4315322339534760e-02
    z[6,5,4]  R1813     -5.6022573262453079e-02
    z[6,5,4]  R1814     -2.3705333471298218e-02
    z[6,5,4]  R1815     -1.2435884773731232e-01
    z[6,5,4]  R1816     6.8415597081184387e-02
    z[6,5,4]  R1817     1.3256542384624481e-01
    z[6,5,4]  R1818     6.2827128171920776e-01
    z[6,5,4]  R1819     9.6080303192138672e-02
    z[6,5,4]  R1820     5.9793880209326744e-03
    z[6,5,4]  R1821     2.1853532642126083e-02
    z[6,5,4]  R1822     2.4359565973281860e-01
    z[6,5,4]  R1823     0.316095769405365
    z[6,5,4]  R1824     6.8187497556209564e-02
    z[6,5,4]  R1825     -1.7738720774650574e-01
    z[6,5,4]  R1826     0.0387742780148983
    z[6,5,4]  R1827     1.8076086044311523e-01
    z[6,5,4]  R1828     1.9370573759078979e-01
    z[6,5,4]  R1829     5.4957389831542969e-02
    z[6,5,4]  R1830     1.5441209077835083e-01
    z[6,5,4]  R1831     2.4482429027557373e-01
    z[6,5,4]  R1832     2.0240475237369537e-01
    z[6,5,4]  R1833     1.2232014536857605e-01
    z[6,5,4]  R1834     -1.7041441053152084e-02
    z[6,5,4]  R1835     -2.8279429674148560e-01
    z[6,5,4]  R1836     -5.9939295053482056e-02
    z[6,5,4]  R1837     -4.1085857152938843e-01
    z[6,5,4]  R1838     -9.5507122576236725e-02
    z[6,5,4]  R1839     -4.8385095596313477e-01
    z[6,5,4]  R1840     -9.4575367867946625e-02
    z[6,5,4]  R1841     7.4334681034088135e-02
    z[6,5,4]  R1842     3.1032708287239075e-01
    z[6,5,4]  R1843     -5.8349415659904480e-02
    z[6,5,4]  R1844     -2.7441397309303284e-01
    z[6,5,4]  R1845     2.3987439274787903e-01
    z[6,5,4]  R1846     -2.6114033535122871e-02
    z[6,5,4]  R1847     4.6398764848709106e-01
    z[6,5,4]  R1848     5.9826242923736572e-01
    z[6,5,4]  R1849     9.2187933623790741e-02
    z[6,5,4]  R1850     1.1430983990430832e-01
    z[6,5,4]  R1851     8.3107441663742065e-01
    z[6,5,4]  R1852     -1.7113734781742096e-01
    z[6,5,4]  R1853     1.9617075100541115e-02
    z[6,5,4]  R1854     1.2819147109985352e-01
    z[6,5,4]  R1855     -2.0795492827892303e-01
    z[6,5,4]  R1856     4.2885860800743103e-01
    z[6,5,4]  R1857     -2.7451589703559875e-01
    z[6,5,4]  R1858     5.4069276899099350e-02
    z[6,5,4]  R1859     -4.3188178539276123e-01
    z[6,5,4]  R1860     1.2486344575881958e-01
    z[6,5,4]  R1861     -5.1023479551076889e-02
    z[6,5,4]  R1862     -1.8468033522367477e-02
    z[6,5,4]  R1863     5.6313324719667435e-02
    z[6,5,4]  R1864     1.1047400534152985e-01
    z[6,5,4]  R1865     -1.1940068751573563e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R1794     -1
    z[6,5,5]  R1795     1
    z[6,5,5]  R1798     3.6649480462074280e-03
    z[6,5,5]  R1799     -0.137080579996109
    z[6,5,5]  R1800     -5.3621435165405273e-01
    z[6,5,5]  R1801     1.3689872622489929e-01
    z[6,5,5]  R1802     5.7584780454635620e-01
    z[6,5,5]  R1803     3.4704136848449707e-01
    z[6,5,5]  R1804     -0.0242563858628273
    z[6,5,5]  R1805     -1.7235971987247467e-01
    z[6,5,5]  R1806     -2.6464128494262695e-01
    z[6,5,5]  R1807     -6.1068701744079590e-01
    z[6,5,5]  R1808     2.8620478510856628e-01
    z[6,5,5]  R1809     -5.8314543217420578e-02
    z[6,5,5]  R1810     2.1562939882278442e-01
    z[6,5,5]  R1811     -9.9507674574851990e-02
    z[6,5,5]  R1812     1.8301378190517426e-01
    z[6,5,5]  R1813     -5.8333072811365128e-03
    z[6,5,5]  R1814     -2.2119371592998505e-01
    z[6,5,5]  R1815     -2.1240086853504181e-01
    z[6,5,5]  R1816     5.4374445229768753e-02
    z[6,5,5]  R1817     0.46855628490448
    z[6,5,5]  R1818     4.4005391001701355e-01
    z[6,5,5]  R1819     3.4282210469245911e-01
    z[6,5,5]  R1820     3.7020862102508545e-01
    z[6,5,5]  R1821     2.7709373831748962e-01
    z[6,5,5]  R1822     2.6857927441596985e-02
    z[6,5,5]  R1823     3.1723475456237793e-01
    z[6,5,5]  R1824     -2.6693260669708252e-01
    z[6,5,5]  R1825     -1.7569415271282196e-01
    z[6,5,5]  R1826     -2.7833628654479980e-01
    z[6,5,5]  R1827     -2.1191258728504181e-01
    z[6,5,5]  R1828     -1.5550585091114044e-01
    z[6,5,5]  R1829     3.7700343132019043e-01
    z[6,5,5]  R1830     2.4028272926807404e-01
    z[6,5,5]  R1831     2.4893839657306671e-01
    z[6,5,5]  R1832     4.6183583140373230e-01
    z[6,5,5]  R1833     4.0268638730049133e-01
    z[6,5,5]  R1834     -2.1071991324424744e-01
    z[6,5,5]  R1835     -5.5100526660680771e-02
    z[6,5,5]  R1836     2.4319063127040863e-01
    z[6,5,5]  R1837     -5.8295673131942749e-01
    z[6,5,5]  R1838     -3.0251616239547729e-01
    z[6,5,5]  R1839     1.3146124780178070e-01
    z[6,5,5]  R1840     1.0964702069759369e-01
    z[6,5,5]  R1841     4.5769503712654114e-01
    z[6,5,5]  R1842     -2.2456597536802292e-02
    z[6,5,5]  R1843     -5.1432478427886963e-01
    z[6,5,5]  R1844     4.3542400002479553e-01
    z[6,5,5]  R1845     -4.8435342311859131e-01
    z[6,5,5]  R1846     1.5595848858356476e-01
    z[6,5,5]  R1847     -4.6357524394989014e-01
    z[6,5,5]  R1848     -3.7854495644569397e-01
    z[6,5,5]  R1849     2.6929848827421665e-03
    z[6,5,5]  R1850     -1.6067951917648315e-01
    z[6,5,5]  R1851     -3.7243768572807312e-01
    z[6,5,5]  R1852     9.3918427824974060e-02
    z[6,5,5]  R1853     2.9677912592887878e-02
    z[6,5,5]  R1854     -3.1352409720420837e-01
    z[6,5,5]  R1855     8.1947281956672668e-02
    z[6,5,5]  R1856     -2.7459457516670227e-01
    z[6,5,5]  R1857     9.1942958533763885e-02
    z[6,5,5]  R1858     7.3096431791782379e-02
    z[6,5,5]  R1859     7.3388456366956234e-03
    z[6,5,5]  R1860     2.3633052408695221e-01
    z[6,5,5]  R1861     0.277178019285202
    z[6,5,5]  R1862     4.2596709728240967e-01
    z[6,5,5]  R1863     4.0707957744598389e-01
    z[6,5,5]  R1864     6.4479613304138184e-01
    z[6,5,5]  R1865     5.8357077836990356e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R1796     -1
    z[6,5,6]  R1797     1
    z[6,5,6]  R1798     -1.6993029415607452e-01
    z[6,5,6]  R1799     5.1385802030563354e-01
    z[6,5,6]  R1800     2.5195059180259705e-01
    z[6,5,6]  R1801     0.266657292842865
    z[6,5,6]  R1802     -1.8867613375186920e-01
    z[6,5,6]  R1803     -3.2001528888940811e-02
    z[6,5,6]  R1804     -1.8310065567493439e-01
    z[6,5,6]  R1805     0.506697416305542
    z[6,5,6]  R1806     3.5602548718452454e-01
    z[6,5,6]  R1807     4.8910453915596008e-02
    z[6,5,6]  R1808     -0.403319776058197
    z[6,5,6]  R1809     -4.0726795792579651e-02
    z[6,5,6]  R1810     2.2924545407295227e-01
    z[6,5,6]  R1811     -1.8716701865196228e-01
    z[6,5,6]  R1812     -1.5874285995960236e-01
    z[6,5,6]  R1813     1.9830964505672455e-01
    z[6,5,6]  R1814     -4.4789519160985947e-02
    z[6,5,6]  R1815     -1.8294534087181091e-01
    z[6,5,6]  R1816     -1.8529818952083588e-01
    z[6,5,6]  R1817     1.1554679274559021e-01
    z[6,5,6]  R1818     3.6919271945953369e-01
    z[6,5,6]  R1819     1.4193138480186462e-01
    z[6,5,6]  R1820     1.6270010173320770e-01
    z[6,5,6]  R1821     -6.5023888600990176e-04
    z[6,5,6]  R1822     2.6800441741943359e-01
    z[6,5,6]  R1823     -3.3488348126411438e-01
    z[6,5,6]  R1824     1.1048205941915512e-01
    z[6,5,6]  R1825     1.8190686404705048e-01
    z[6,5,6]  R1826     2.6113128662109375e-01
    z[6,5,6]  R1827     3.0068665742874146e-01
    z[6,5,6]  R1828     1.0309263318777084e-01
    z[6,5,6]  R1829     -9.4360075891017914e-02
    z[6,5,6]  R1830     1.9623020291328430e-01
    z[6,5,6]  R1831     3.2488524913787842e-02
    z[6,5,6]  R1832     -3.2493855804204941e-02
    z[6,5,6]  R1833     -9.7407236695289612e-02
    z[6,5,6]  R1834     -1.5290263295173645e-01
    z[6,5,6]  R1835     -1.7156034708023071e-01
    z[6,5,6]  R1836     -8.6774595081806183e-02
    z[6,5,6]  R1837     1.6035346686840057e-01
    z[6,5,6]  R1838     4.8387566208839417e-01
    z[6,5,6]  R1839     7.3102325201034546e-01
    z[6,5,6]  R1840     6.5606081485748291e-01
    z[6,5,6]  R1841     1.9027769565582275e-01
    z[6,5,6]  R1842     -1.2946607545018196e-02
    z[6,5,6]  R1843     -4.6336270868778229e-02
    z[6,5,6]  R1844     -9.8562121391296387e-02
    z[6,5,6]  R1845     6.8356923758983612e-02
    z[6,5,6]  R1846     -5.5044367909431458e-03
    z[6,5,6]  R1847     -0.0585097037255764
    z[6,5,6]  R1848     -5.0310939550399780e-01
    z[6,5,6]  R1849     -1.5154702961444855e-01
    z[6,5,6]  R1850     -1.2716592848300934e-01
    z[6,5,6]  R1851     1.6794812679290771e-01
    z[6,5,6]  R1852     1.2766954302787781e-01
    z[6,5,6]  R1853     -1.8253472447395325e-01
    z[6,5,6]  R1854     2.2634802758693695e-01
    z[6,5,6]  R1855     9.5769934356212616e-02
    z[6,5,6]  R1856     1.3546362519264221e-01
    z[6,5,6]  R1857     -4.9638783931732178e-01
    z[6,5,6]  R1858     2.5447872281074524e-01
    z[6,5,6]  R1859     -4.0512412786483765e-01
    z[6,5,6]  R1860     -0.0864330604672432
    z[6,5,6]  R1861     -4.5044098049402237e-02
    z[6,5,6]  R1862     6.6999264061450958e-02
    z[6,5,6]  R1863     -1.7671030014753342e-02
    z[6,5,6]  R1864     -2.5904160737991333e-01
    z[6,5,6]  R1865     -1.2953734397888184e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R1866     -1
    z[6,7,0]  R1867     1
    z[6,7,0]  R1880     4.3771749734878540e-01
    z[6,7,0]  R1881     -0.0391731858253479
    z[6,7,0]  R1882     -7.9466208815574646e-02
    z[6,7,0]  R1883     2.8266519308090210e-02
    z[6,7,0]  R1884     3.2036021351814270e-01
    z[6,7,0]  R1885     -0.265390545129776
    z[6,7,0]  R1886     -4.0817371010780334e-01
    z[6,7,0]  R1887     -2.0675820112228394e-01
    z[6,7,0]  R1888     -2.1835803985595703e-01
    z[6,7,0]  R1889     -4.9946942925453186e-01
    z[6,7,0]  R1890     1.2552453577518463e-01
    z[6,7,0]  R1891     -4.2251676321029663e-01
    z[6,7,0]  R1892     -3.4860372543334961e-01
    z[6,7,0]  R1893     -3.0182841420173645e-01
    z[6,7,0]  R1894     -1.7583738267421722e-01
    z[6,7,0]  R1895     -3.7901768088340759e-01
    z[6,7,0]  R1896     -0.405945360660553
    z[6,7,0]  R1897     -2.5149145722389221e-01
    z[6,7,0]  R1898     -1.7418639361858368e-01
    z[6,7,0]  R1899     -3.5367617011070251e-01
    z[6,7,0]  R1900     3.9054846763610840e-01
    z[6,7,0]  R1901     -7.9799056053161621e-02
    z[6,7,0]  R1902     -1.7246741056442261e-01
    z[6,7,0]  R1903     -1.9270287454128265e-01
    z[6,7,0]  R1904     -3.9180281758308411e-01
    z[6,7,0]  R1905     5.6069605052471161e-02
    z[6,7,0]  R1906     5.9873914718627930e-01
    z[6,7,0]  R1907     6.5670222043991089e-01
    z[6,7,0]  R1908     3.5155642032623291e-01
    z[6,7,0]  R1909     2.6440745592117310e-01
    z[6,7,0]  R1910     -4.0735068917274475e-01
    z[6,7,0]  R1911     -4.5452676713466644e-02
    z[6,7,0]  R1912     -2.4952669441699982e-01
    z[6,7,0]  R1913     -0.157730370759964
    z[6,7,0]  R1914     -6.5584409236907959e-01
    z[6,7,0]  R1915     -7.1817688643932343e-02
    z[6,7,0]  R1916     -9.2405068874359131e-01
    z[6,7,0]  R1917     -9.2647778987884521e-01
    z[6,7,0]  R1918     1.4462977647781372e-01
    z[6,7,0]  R1919     2.0282746851444244e-01
    z[6,7,0]  R1920     -1.4239031076431274e-01
    z[6,7,0]  R1921     -8.0109804868698120e-02
    z[6,7,0]  R1922     -2.0861518383026123e-01
    z[6,7,0]  R1923     1.8142579495906830e-01
    z[6,7,0]  R1924     1.0963388532400131e-01
    z[6,7,0]  R1925     -4.8393601179122925e-01
    z[6,7,0]  R1926     -3.7745830416679382e-01
    z[6,7,0]  R1927     -1.5982395410537720e-01
    z[6,7,0]  R1928     5.4731643199920654e-01
    z[6,7,0]  R1929     -2.8332433104515076e-01
    z[6,7,0]  R1930     1.8951942026615143e-01
    z[6,7,0]  R1931     2.0079214870929718e-01
    z[6,7,0]  R1932     5.3021436929702759e-01
    z[6,7,0]  R1933     -2.2666609287261963e-01
    z[6,7,0]  R1934     -3.4470555186271667e-01
    z[6,7,0]  R1935     1.7929136753082275e-01
    z[6,7,0]  R1936     4.1812822222709656e-01
    z[6,7,0]  R1937     2.3096819221973419e-01
    z[6,7,0]  R1938     3.1026995182037354e-01
    z[6,7,0]  R1939     1.9502638280391693e-01
    z[6,7,0]  R1940     -2.3145294189453125e-01
    z[6,7,0]  R1941     4.9859631806612015e-02
    z[6,7,0]  R1942     -2.3853557184338570e-02
    z[6,7,0]  R1943     -2.5242453813552856e-01
    z[6,7,0]  R1944     2.6620236039161682e-01
    z[6,7,0]  R1945     7.1300083398818970e-01
    z[6,7,0]  R1946     -3.1056925654411316e-01
    z[6,7,0]  R1947     -2.4116815626621246e-01
    z[6,7,0]  R1948     -6.1735503375530243e-02
    z[6,7,0]  R1949     3.5499048233032227e-01
    z[6,7,0]  R1950     -2.3529201745986938e-01
    z[6,7,0]  R1951     -4.5805446803569794e-02
    z[6,7,0]  R1952     -3.3786529302597046e-01
    z[6,7,0]  R1953     -1.2771472334861755e-01
    z[6,7,0]  R1954     7.2117978334426880e-01
    z[6,7,0]  R1955     2.2776730358600616e-01
    z[6,7,0]  R1956     2.8832095861434937e-01
    z[6,7,0]  R1957     -1.2953884899616241e-01
    z[6,7,0]  R1958     9.7091786563396454e-02
    z[6,7,0]  R1959     -0.0796702653169632
    z[6,7,0]  R1960     -1.6089361906051636e-01
    z[6,7,0]  R1961     1.7138876020908356e-01
    z[6,7,0]  R1962     -3.0284032225608826e-01
    z[6,7,0]  R1963     1.8827617168426514e-01
    z[6,7,0]  R1964     -3.8897427916526794e-01
    z[6,7,0]  R1965     -3.2350787520408630e-01
    z[6,7,0]  R1966     -1.8089754879474640e-01
    z[6,7,0]  R1967     -6.2212910503149033e-02
    z[6,7,0]  R1968     -5.4922342300415039e-02
    z[6,7,0]  R1969     2.1008875966072083e-01
    z[6,7,0]  R1970     -1.9150808453559875e-02
    z[6,7,0]  R1971     -1.3141886889934540e-01
    z[6,7,0]  R1972     -0.280888170003891
    z[6,7,0]  R1973     -3.2990834116935730e-01
    z[6,7,0]  R1974     4.2448371648788452e-02
    z[6,7,0]  R1975     2.3840151727199554e-01
    z[6,7,0]  R1976     4.2176750302314758e-01
    z[6,7,0]  R1977     7.9707928001880646e-02
    z[6,7,0]  R1978     2.2722578048706055e-01
    z[6,7,0]  R1979     2.6506033539772034e-01
    z[6,7,0]  R1980     -2.3064351081848145e-01
    z[6,7,0]  R1981     -1.8559268116950989e-01
    z[6,7,0]  R1982     2.2781016305088997e-02
    z[6,7,0]  R1983     -4.7762727737426758e-01
    z[6,7,0]  R1984     -5.0240868330001831e-01
    z[6,7,0]  R1985     -4.3745297193527222e-01
    z[6,7,0]  R1986     -2.7342742681503296e-01
    z[6,7,0]  R1987     -4.5025333762168884e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R1868     -1
    z[6,7,1]  R1869     1
    z[6,7,1]  R1880     -6.3786697387695312e-01
    z[6,7,1]  R1881     -7.8977859020233154e-01
    z[6,7,1]  R1882     -6.4975708723068237e-01
    z[6,7,1]  R1883     -1.4225061237812042e-01
    z[6,7,1]  R1884     -1.5911851823329926e-01
    z[6,7,1]  R1885     7.4082785844802856e-01
    z[6,7,1]  R1886     6.8664455413818359e-01
    z[6,7,1]  R1887     7.6769286394119263e-01
    z[6,7,1]  R1888     7.7680385112762451e-01
    z[6,7,1]  R1889     4.6662130951881409e-01
    z[6,7,1]  R1890     -4.3242397904396057e-01
    z[6,7,1]  R1891     8.2586342096328735e-01
    z[6,7,1]  R1892     8.0291557312011719e-01
    z[6,7,1]  R1893     9.1544169187545776e-01
    z[6,7,1]  R1894     8.8984721899032593e-01
    z[6,7,1]  R1895     8.6142480373382568e-01
    z[6,7,1]  R1896     8.5968142747879028e-01
    z[6,7,1]  R1897     8.9190471172332764e-01
    z[6,7,1]  R1898     9.2931693792343140e-01
    z[6,7,1]  R1899     3.6163869500160217e-01
    z[6,7,1]  R1900     -1.3008889555931091e-01
    z[6,7,1]  R1901     8.9851087331771851e-01
    z[6,7,1]  R1902     4.9530696868896484e-01
    z[6,7,1]  R1903     5.3853332996368408e-01
    z[6,7,1]  R1904     1.7717395722866058e-01
    z[6,7,1]  R1905     6.4072179794311523e-01
    z[6,7,1]  R1906     5.4572504758834839e-01
    z[6,7,1]  R1907     5.3164607286453247e-01
    z[6,7,1]  R1908     2.2954449057579041e-01
    z[6,7,1]  R1909     3.2020118832588196e-01
    z[6,7,1]  R1910     8.6463242769241333e-01
    z[6,7,1]  R1911     9.0580314397811890e-01
    z[6,7,1]  R1912     4.1640976071357727e-01
    z[6,7,1]  R1913     5.1957857608795166e-01
    z[6,7,1]  R1914     1.3578817248344421e-01
    z[6,7,1]  R1915     6.4486914873123169e-01
    z[6,7,1]  R1916     1.0491027496755123e-02
    z[6,7,1]  R1917     0.0408322811126709
    z[6,7,1]  R1918     8.8997566699981689e-01
    z[6,7,1]  R1919     5.6347352266311646e-01
    z[6,7,1]  R1920     5.3149688243865967e-01
    z[6,7,1]  R1921     4.7394096851348877e-01
    z[6,7,1]  R1922     -8.6980652809143066e-01
    z[6,7,1]  R1923     4.5374700427055359e-01
    z[6,7,1]  R1924     -7.2401589155197144e-01
    z[6,7,1]  R1925     -0.854438841342926
    z[6,7,1]  R1926     -5.5981749296188354e-01
    z[6,7,1]  R1927     4.8178479075431824e-01
    z[6,7,1]  R1928     3.6600002646446228e-01
    z[6,7,1]  R1929     -0.652351438999176
    z[6,7,1]  R1930     1.9683641195297241e-01
    z[6,7,1]  R1931     -5.6298565864562988e-01
    z[6,7,1]  R1932     9.3209460377693176e-02
    z[6,7,1]  R1933     -3.4307649731636047e-01
    z[6,7,1]  R1934     -2.4836876988410950e-01
    z[6,7,1]  R1935     -8.3863925933837891e-01
    z[6,7,1]  R1936     -1.2238927185535431e-01
    z[6,7,1]  R1937     -7.0744502544403076e-01
    z[6,7,1]  R1938     2.8402090072631836e-01
    z[6,7,1]  R1939     6.2036657333374023e-01
    z[6,7,1]  R1940     -5.9176814556121826e-01
    z[6,7,1]  R1941     -6.9369810819625854e-01
    z[6,7,1]  R1942     5.0723671913146973e-01
    z[6,7,1]  R1943     -5.3851896524429321e-01
    z[6,7,1]  R1944     6.1436223983764648e-01
    z[6,7,1]  R1945     5.4348480701446533e-01
    z[6,7,1]  R1946     -4.8074319958686829e-01
    z[6,7,1]  R1947     -4.0413281321525574e-01
    z[6,7,1]  R1948     -5.2071684598922729e-01
    z[6,7,1]  R1949     5.8704417943954468e-01
    z[6,7,1]  R1950     -4.6282440423965454e-01
    z[6,7,1]  R1951     6.0084664821624756e-01
    z[6,7,1]  R1952     -0.56495201587677
    z[6,7,1]  R1953     -4.6176734566688538e-01
    z[6,7,1]  R1954     4.9946096539497375e-01
    z[6,7,1]  R1955     6.1561310291290283e-01
    z[6,7,1]  R1956     -4.0816673636436462e-01
    z[6,7,1]  R1957     -4.3503656983375549e-01
    z[6,7,1]  R1958     6.2327593564987183e-01
    z[6,7,1]  R1959     7.1865928173065186e-01
    z[6,7,1]  R1960     -7.5535839796066284e-01
    z[6,7,1]  R1961     -5.4526019096374512e-01
    z[6,7,1]  R1962     -0.555756151676178
    z[6,7,1]  R1963     1.3988788425922394e-01
    z[6,7,1]  R1964     -6.5123164653778076e-01
    z[6,7,1]  R1965     -4.4593289494514465e-01
    z[6,7,1]  R1966     -4.6819174289703369e-01
    z[6,7,1]  R1967     -5.4919254779815674e-01
    z[6,7,1]  R1968     -8.0863159894943237e-01
    z[6,7,1]  R1969     -9.4244188070297241e-01
    z[6,7,1]  R1970     -7.6257109642028809e-01
    z[6,7,1]  R1971     -7.5732493400573730e-01
    z[6,7,1]  R1972     -7.1655815839767456e-01
    z[6,7,1]  R1973     -5.2059888839721680e-01
    z[6,7,1]  R1974     -7.0152491331100464e-01
    z[6,7,1]  R1975     -5.9501367807388306e-01
    z[6,7,1]  R1976     3.2451578974723816e-01
    z[6,7,1]  R1977     -2.0547662675380707e-01
    z[6,7,1]  R1978     5.9226512908935547e-01
    z[6,7,1]  R1979     -4.9956339597702026e-01
    z[6,7,1]  R1980     -5.6142532825469971e-01
    z[6,7,1]  R1981     -4.3255776166915894e-01
    z[6,7,1]  R1982     -4.2222142219543457e-01
    z[6,7,1]  R1983     7.2138541936874390e-01
    z[6,7,1]  R1984     7.3265445232391357e-01
    z[6,7,1]  R1985     0.735712468624115
    z[6,7,1]  R1986     8.1659460067749023e-01
    z[6,7,1]  R1987     6.6647243499755859e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R1870     -1
    z[6,7,2]  R1871     1
    z[6,7,2]  R1880     5.9278792142868042e-01
    z[6,7,2]  R1881     1.7924880981445312e-01
    z[6,7,2]  R1882     -1.9406531751155853e-01
    z[6,7,2]  R1883     6.1752600595355034e-04
    z[6,7,2]  R1884     -1.7152637243270874e-02
    z[6,7,2]  R1885     -1.6465066000819206e-02
    z[6,7,2]  R1886     1.0463666170835495e-01
    z[6,7,2]  R1887     2.5198884308338165e-02
    z[6,7,2]  R1888     3.4140422940254211e-01
    z[6,7,2]  R1889     3.1607914716005325e-02
    z[6,7,2]  R1890     -4.9568369984626770e-01
    z[6,7,2]  R1891     -3.0892071127891541e-01
    z[6,7,2]  R1892     -2.8230714797973633e-01
    z[6,7,2]  R1893     7.4818126857280731e-02
    z[6,7,2]  R1894     -3.3239787817001343e-01
    z[6,7,2]  R1895     -2.3629236221313477e-01
    z[6,7,2]  R1896     -1.4860311150550842e-01
    z[6,7,2]  R1897     -1.7808496952056885e-01
    z[6,7,2]  R1898     -1.9802547991275787e-01
    z[6,7,2]  R1899     4.0964248776435852e-01
    z[6,7,2]  R1900     -3.2503670454025269e-01
    z[6,7,2]  R1901     1.9173230230808258e-01
    z[6,7,2]  R1902     3.0728760361671448e-01
    z[6,7,2]  R1903     3.2520228624343872e-01
    z[6,7,2]  R1904     1.8137063086032867e-01
    z[6,7,2]  R1905     1.3683487474918365e-01
    z[6,7,2]  R1906     1.9424313306808472e-01
    z[6,7,2]  R1907     1.5622487664222717e-01
    z[6,7,2]  R1908     2.5217339396476746e-01
    z[6,7,2]  R1909     3.9589118957519531e-01
    z[6,7,2]  R1910     -4.1760094463825226e-02
    z[6,7,2]  R1911     8.1125594675540924e-02
    z[6,7,2]  R1912     1.5294852852821350e-01
    z[6,7,2]  R1913     2.2984346747398376e-01
    z[6,7,2]  R1914     3.5008290410041809e-01
    z[6,7,2]  R1915     1.5769174695014954e-01
    z[6,7,2]  R1916     9.1569451615214348e-03
    z[6,7,2]  R1917     4.3774012476205826e-02
    z[6,7,2]  R1918     1.5626215934753418e-01
    z[6,7,2]  R1919     1.4070723950862885e-01
    z[6,7,2]  R1920     6.9898366928100586e-02
    z[6,7,2]  R1921     -5.5283259600400925e-02
    z[6,7,2]  R1922     0.0860406756401062
    z[6,7,2]  R1923     5.0194729119539261e-02
    z[6,7,2]  R1924     5.7102650403976440e-01
    z[6,7,2]  R1925     -1.7140921950340271e-01
    z[6,7,2]  R1926     5.3867197036743164e-01
    z[6,7,2]  R1927     -1.0154915601015091e-01
    z[6,7,2]  R1928     9.3037039041519165e-02
    z[6,7,2]  R1929     8.0166503787040710e-02
    z[6,7,2]  R1930     -0.686255156993866
    z[6,7,2]  R1931     3.1873509287834167e-01
    z[6,7,2]  R1932     -2.4452788755297661e-02
    z[6,7,2]  R1933     3.0223757028579712e-01
    z[6,7,2]  R1934     -2.4538283050060272e-01
    z[6,7,2]  R1935     -1.0774039663374424e-02
    z[6,7,2]  R1936     3.8475415110588074e-01
    z[6,7,2]  R1937     -2.4036644399166107e-01
    z[6,7,2]  R1938     1.6755943000316620e-01
    z[6,7,2]  R1939     -6.1562073230743408e-01
    z[6,7,2]  R1940     1.2368278205394745e-01
    z[6,7,2]  R1941     -3.2838433980941772e-02
    z[6,7,2]  R1942     -5.2198302745819092e-01
    z[6,7,2]  R1943     2.7007073163986206e-01
    z[6,7,2]  R1944     3.4253621101379395e-01
    z[6,7,2]  R1945     1.1106052435934544e-02
    z[6,7,2]  R1946     -6.6184081137180328e-02
    z[6,7,2]  R1947     -2.2363376617431641e-01
    z[6,7,2]  R1948     6.8158376216888428e-01
    z[6,7,2]  R1949     2.2800515592098236e-01
    z[6,7,2]  R1950     4.6837532520294189e-01
    z[6,7,2]  R1951     -2.4548043310642242e-01
    z[6,7,2]  R1952     3.2230582088232040e-02
    z[6,7,2]  R1953     3.8513442873954773e-01
    z[6,7,2]  R1954     1.8799996376037598e-01
    z[6,7,2]  R1955     -2.9129263758659363e-01
    z[6,7,2]  R1956     4.2210742831230164e-01
    z[6,7,2]  R1957     5.6851077079772949e-01
    z[6,7,2]  R1958     -6.6060012578964233e-01
    z[6,7,2]  R1959     1.0846129059791565e-01
    z[6,7,2]  R1960     -1.4594377577304840e-01
    z[6,7,2]  R1961     6.9918280839920044e-01
    z[6,7,2]  R1962     -9.2435348778963089e-03
    z[6,7,2]  R1963     -2.3108625411987305e-01
    z[6,7,2]  R1964     -1.9133625924587250e-01
    z[6,7,2]  R1965     2.5521764159202576e-01
    z[6,7,2]  R1966     4.5094007253646851e-01
    z[6,7,2]  R1967     3.7741002440452576e-01
    z[6,7,2]  R1968     1.5772137045860291e-01
    z[6,7,2]  R1969     0.121115542948246
    z[6,7,2]  R1970     0.227840393781662
    z[6,7,2]  R1971     -0.0860668197274208
    z[6,7,2]  R1972     1.8881501257419586e-01
    z[6,7,2]  R1973     5.2971524000167847e-01
    z[6,7,2]  R1974     3.8336157798767090e-02
    z[6,7,2]  R1975     5.1168650388717651e-01
    z[6,7,2]  R1976     -6.2997028231620789e-02
    z[6,7,2]  R1977     0.702738344669342
    z[6,7,2]  R1978     -8.3330802619457245e-02
    z[6,7,2]  R1979     5.5563312768936157e-01
    z[6,7,2]  R1980     1.6081599891185760e-01
    z[6,7,2]  R1981     8.1674647331237793e-01
    z[6,7,2]  R1982     6.7043161392211914e-01
    z[6,7,2]  R1983     -2.8460618853569031e-01
    z[6,7,2]  R1984     1.6050188243389130e-01
    z[6,7,2]  R1985     -1.4110109210014343e-01
    z[6,7,2]  R1986     1.0098636895418167e-01
    z[6,7,2]  R1987     2.0625907927751541e-02
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R1872     -1
    z[6,7,3]  R1873     1
    z[6,7,3]  R1880     1.4309599995613098e-01
    z[6,7,3]  R1881     2.0340880379080772e-02
    z[6,7,3]  R1882     4.2678320407867432e-01
    z[6,7,3]  R1883     6.4608812332153320e-01
    z[6,7,3]  R1884     6.9559633731842041e-01
    z[6,7,3]  R1885     -4.2864549160003662e-01
    z[6,7,3]  R1886     -4.9572768807411194e-01
    z[6,7,3]  R1887     -2.1139457821846008e-01
    z[6,7,3]  R1888     8.2375489175319672e-02
    z[6,7,3]  R1889     -3.4938955307006836e-01
    z[6,7,3]  R1890     -5.2039200067520142e-01
    z[6,7,3]  R1891     -1.9592165946960449e-01
    z[6,7,3]  R1892     -2.3345731198787689e-01
    z[6,7,3]  R1893     -0.0956321656703949
    z[6,7,3]  R1894     3.1020302325487137e-02
    z[6,7,3]  R1895     1.2633083760738373e-01
    z[6,7,3]  R1896     1.5026177465915680e-01
    z[6,7,3]  R1897     1.2448097020387650e-01
    z[6,7,3]  R1898     1.5761420130729675e-01
    z[6,7,3]  R1899     -5.7083618640899658e-01
    z[6,7,3]  R1900     -1.4982836320996284e-02
    z[6,7,3]  R1901     -5.1439993083477020e-02
    z[6,7,3]  R1902     -0.683329164981842
    z[6,7,3]  R1903     -6.9987994432449341e-01
    z[6,7,3]  R1904     -0.806423008441925
    z[6,7,3]  R1905     -0.5048828125
    z[6,7,3]  R1906     -4.6675089001655579e-01
    z[6,7,3]  R1907     -4.0775465965270996e-01
    z[6,7,3]  R1908     -7.8291893005371094e-01
    z[6,7,3]  R1909     -7.0910942554473877e-01
    z[6,7,3]  R1910     -1.1135594546794891e-01
    z[6,7,3]  R1911     -1.2968315184116364e-01
    z[6,7,3]  R1912     -7.8794735670089722e-01
    z[6,7,3]  R1913     -7.2757571935653687e-01
    z[6,7,3]  R1914     -4.1660082340240479e-01
    z[6,7,3]  R1915     -0.606228232383728
    z[6,7,3]  R1916     -2.7904081344604492e-01
    z[6,7,3]  R1917     -1.6004312038421631e-01
    z[6,7,3]  R1918     -1.9977492094039917e-01
    z[6,7,3]  R1919     -4.5930573344230652e-01
    z[6,7,3]  R1920     -7.5363588333129883e-01
    z[6,7,3]  R1921     -5.6296902894973755e-01
    z[6,7,3]  R1922     -2.4565504863858223e-02
    z[6,7,3]  R1923     -5.3719317913055420e-01
    z[6,7,3]  R1924     -2.0710441470146179e-01
    z[6,7,3]  R1925     -2.1754177287220955e-02
    z[6,7,3]  R1926     -1.8905088305473328e-01
    z[6,7,3]  R1927     -2.4509520828723907e-01
    z[6,7,3]  R1928     -2.9720559716224670e-01
    z[6,7,3]  R1929     -4.1779360175132751e-01
    z[6,7,3]  R1930     -0.559943675994873
    z[6,7,3]  R1931     3.1916698813438416e-01
    z[6,7,3]  R1932     -7.5362426042556763e-01
    z[6,7,3]  R1933     7.7795481681823730e-01
    z[6,7,3]  R1934     8.0503243207931519e-01
    z[6,7,3]  R1935     3.2476234436035156e-01
    z[6,7,3]  R1936     -4.7026541829109192e-01
    z[6,7,3]  R1937     5.5571585893630981e-01
    z[6,7,3]  R1938     -6.1917799711227417e-01
    z[6,7,3]  R1939     6.9842688739299774e-02
    z[6,7,3]  R1940     -5.1531377248466015e-03
    z[6,7,3]  R1941     5.9765160083770752e-01
    z[6,7,3]  R1942     -4.1451793909072876e-01
    z[6,7,3]  R1943     1.8008767068386078e-01
    z[6,7,3]  R1944     -3.8358801603317261e-01
    z[6,7,3]  R1945     0.267170250415802
    z[6,7,3]  R1946     4.3227684497833252e-01
    z[6,7,3]  R1947     5.9382396936416626e-01
    z[6,7,3]  R1948     -4.5205873250961304e-01
    z[6,7,3]  R1949     -3.3212760090827942e-01
    z[6,7,3]  R1950     1.8679212033748627e-01
    z[6,7,3]  R1951     -2.9897835850715637e-01
    z[6,7,3]  R1952     2.3277139663696289e-01
    z[6,7,3]  R1953     5.3183770179748535e-01
    z[6,7,3]  R1954     -1.4117913320660591e-02
    z[6,7,3]  R1955     -1.3899800181388855e-01
    z[6,7,3]  R1956     -4.4124302268028259e-01
    z[6,7,3]  R1957     4.1658997535705566e-01
    z[6,7,3]  R1958     -2.7856573462486267e-01
    z[6,7,3]  R1959     -4.0980812907218933e-01
    z[6,7,3]  R1960     2.2978819906711578e-01
    z[6,7,3]  R1961     1.8695114180445671e-02
    z[6,7,3]  R1962     4.2316564917564392e-01
    z[6,7,3]  R1963     -9.2306923866271973e-01
    z[6,7,3]  R1964     3.0637022852897644e-01
    z[6,7,3]  R1965     6.0286504030227661e-01
    z[6,7,3]  R1966     -2.6251927018165588e-01
    z[6,7,3]  R1967     0.3237284719944
    z[6,7,3]  R1968     4.8264548182487488e-01
    z[6,7,3]  R1969     -6.8123318254947662e-02
    z[6,7,3]  R1970     -2.4848574399948120e-01
    z[6,7,3]  R1971     -0.09919423609972
    z[6,7,3]  R1972     6.9111935794353485e-02
    z[6,7,3]  R1973     3.1444087624549866e-01
    z[6,7,3]  R1974     2.7635595202445984e-01
    z[6,7,3]  R1975     1.7880478873848915e-02
    z[6,7,3]  R1976     -5.5708044767379761e-01
    z[6,7,3]  R1977     -4.9197328090667725e-01
    z[6,7,3]  R1978     -6.1810475587844849e-01
    z[6,7,3]  R1979     -2.9371315240859985e-01
    z[6,7,3]  R1980     3.5752159357070923e-01
    z[6,7,3]  R1981     2.3813307285308838e-01
    z[6,7,3]  R1982     -2.2278147935867310e-01
    z[6,7,3]  R1983     3.4698012471199036e-01
    z[6,7,3]  R1984     1.5617586672306061e-01
    z[6,7,3]  R1985     4.3177241086959839e-01
    z[6,7,3]  R1986     3.2639807462692261e-01
    z[6,7,3]  R1987     -0.044993806630373
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R1874     -1
    z[6,7,4]  R1875     1
    z[6,7,4]  R1880     2.7665689587593079e-02
    z[6,7,4]  R1881     -2.4357780814170837e-01
    z[6,7,4]  R1882     2.6279106736183167e-02
    z[6,7,4]  R1883     -6.8679553270339966e-01
    z[6,7,4]  R1884     -1.4388452470302582e-01
    z[6,7,4]  R1885     -2.7435779571533203e-01
    z[6,7,4]  R1886     -2.6665431261062622e-01
    z[6,7,4]  R1887     -1.9006811082363129e-01
    z[6,7,4]  R1888     1.6959916055202484e-01
    z[6,7,4]  R1889     -1.8545034527778625e-01
    z[6,7,4]  R1890     -1.9016557931900024e-01
    z[6,7,4]  R1891     2.3510249331593513e-02
    z[6,7,4]  R1892     -2.3511119186878204e-02
    z[6,7,4]  R1893     1.0578073561191559e-01
    z[6,7,4]  R1894     -8.4315322339534760e-02
    z[6,7,4]  R1895     -5.6022573262453079e-02
    z[6,7,4]  R1896     -2.3705333471298218e-02
    z[6,7,4]  R1897     -1.2435884773731232e-01
    z[6,7,4]  R1898     6.8415597081184387e-02
    z[6,7,4]  R1899     1.3256542384624481e-01
    z[6,7,4]  R1900     6.2827128171920776e-01
    z[6,7,4]  R1901     9.6080303192138672e-02
    z[6,7,4]  R1902     5.9793880209326744e-03
    z[6,7,4]  R1903     2.1853532642126083e-02
    z[6,7,4]  R1904     2.4359565973281860e-01
    z[6,7,4]  R1905     0.316095769405365
    z[6,7,4]  R1906     6.8187497556209564e-02
    z[6,7,4]  R1907     -1.7738720774650574e-01
    z[6,7,4]  R1908     0.0387742780148983
    z[6,7,4]  R1909     1.8076086044311523e-01
    z[6,7,4]  R1910     1.9370573759078979e-01
    z[6,7,4]  R1911     5.4957389831542969e-02
    z[6,7,4]  R1912     1.5441209077835083e-01
    z[6,7,4]  R1913     2.4482429027557373e-01
    z[6,7,4]  R1914     2.0240475237369537e-01
    z[6,7,4]  R1915     1.2232014536857605e-01
    z[6,7,4]  R1916     -1.7041441053152084e-02
    z[6,7,4]  R1917     -2.8279429674148560e-01
    z[6,7,4]  R1918     -1.5166673064231873e-01
    z[6,7,4]  R1919     -3.4555739164352417e-01
    z[6,7,4]  R1920     -9.1287478804588318e-02
    z[6,7,4]  R1921     -5.6490135192871094e-01
    z[6,7,4]  R1922     -1.1244915425777435e-01
    z[6,7,4]  R1923     -6.0637700557708740e-01
    z[6,7,4]  R1924     -2.2839431464672089e-01
    z[6,7,4]  R1925     -7.4578397907316685e-03
    z[6,7,4]  R1926     1.5477222204208374e-01
    z[6,7,4]  R1927     -7.9120141267776489e-01
    z[6,7,4]  R1928     0.379867285490036
    z[6,7,4]  R1929     -2.8409931063652039e-01
    z[6,7,4]  R1930     -1.5021848678588867e-01
    z[6,7,4]  R1931     0.51568603515625
    z[6,7,4]  R1932     3.2848662137985229e-01
    z[6,7,4]  R1933     1.1617516167461872e-02
    z[6,7,4]  R1934     -6.8178132176399231e-02
    z[6,7,4]  R1935     1.7207933962345123e-01
    z[6,7,4]  R1936     5.8379912376403809e-01
    z[6,7,4]  R1937     -1.2048694491386414e-01
    z[6,7,4]  R1938     -1.7973898351192474e-01
    z[6,7,4]  R1939     3.8831412792205811e-02
    z[6,7,4]  R1940     6.8202883005142212e-02
    z[6,7,4]  R1941     3.5923016071319580e-01
    z[6,7,4]  R1942     3.5152861475944519e-01
    z[6,7,4]  R1943     -1.1418701708316803e-01
    z[6,7,4]  R1944     3.3009532094001770e-01
    z[6,7,4]  R1945     -0.020780049264431
    z[6,7,4]  R1946     -2.5901803374290466e-01
    z[6,7,4]  R1947     1.0997701436281204e-01
    z[6,7,4]  R1948     -7.1648612618446350e-02
    z[6,7,4]  R1949     2.2435715794563293e-01
    z[6,7,4]  R1950     -1.0111869871616364e-01
    z[6,7,4]  R1951     6.5114194154739380e-01
    z[6,7,4]  R1952     7.0492070913314819e-01
    z[6,7,4]  R1953     5.3112041950225830e-01
    z[6,7,4]  R1954     -3.9135057479143143e-02
    z[6,7,4]  R1955     6.6909164190292358e-01
    z[6,7,4]  R1956     4.3342703580856323e-01
    z[6,7,4]  R1957     1.9511634111404419e-01
    z[6,7,4]  R1958     5.6614045053720474e-02
    z[6,7,4]  R1959     -3.3648470044136047e-01
    z[6,7,4]  R1960     -3.3892503380775452e-01
    z[6,7,4]  R1961     1.7174851894378662e-01
    z[6,7,4]  R1962     5.2391719818115234e-01
    z[6,7,4]  R1963     -5.4748533293604851e-03
    z[6,7,4]  R1964     5.0637274980545044e-01
    z[6,7,4]  R1965     -9.4249770045280457e-02
    z[6,7,4]  R1966     -3.7535166740417480e-01
    z[6,7,4]  R1967     5.7516556978225708e-01
    z[6,7,4]  R1968     -2.4371746182441711e-01
    z[6,7,4]  R1969     -0.0630812719464302
    z[6,7,4]  R1970     -1.5615428984165192e-01
    z[6,7,4]  R1971     -4.1815164685249329e-01
    z[6,7,4]  R1972     5.6889444589614868e-01
    z[6,7,4]  R1973     4.3261536955833435e-01
    z[6,7,4]  R1974     4.4233259558677673e-01
    z[6,7,4]  R1975     3.8211050629615784e-01
    z[6,7,4]  R1976     4.0350979566574097e-01
    z[6,7,4]  R1977     2.5373873114585876e-01
    z[6,7,4]  R1978     2.3028384149074554e-01
    z[6,7,4]  R1979     4.7659239172935486e-01
    z[6,7,4]  R1980     4.1253918409347534e-01
    z[6,7,4]  R1981     -3.1321745365858078e-02
    z[6,7,4]  R1982     4.2325553297996521e-01
    z[6,7,4]  R1983     -2.1023072768002748e-03
    z[6,7,4]  R1984     1.9366234540939331e-01
    z[6,7,4]  R1985     4.8675616271793842e-03
    z[6,7,4]  R1986     2.8165090084075928e-01
    z[6,7,4]  R1987     1.6946977376937866e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R1876     -1
    z[6,7,5]  R1877     1
    z[6,7,5]  R1880     3.6649480462074280e-03
    z[6,7,5]  R1881     -0.137080579996109
    z[6,7,5]  R1882     -5.3621435165405273e-01
    z[6,7,5]  R1883     1.3689872622489929e-01
    z[6,7,5]  R1884     5.7584780454635620e-01
    z[6,7,5]  R1885     3.4704136848449707e-01
    z[6,7,5]  R1886     -0.0242563858628273
    z[6,7,5]  R1887     -1.7235971987247467e-01
    z[6,7,5]  R1888     -2.6464128494262695e-01
    z[6,7,5]  R1889     -6.1068701744079590e-01
    z[6,7,5]  R1890     2.8620478510856628e-01
    z[6,7,5]  R1891     -5.8314543217420578e-02
    z[6,7,5]  R1892     2.1562939882278442e-01
    z[6,7,5]  R1893     -9.9507674574851990e-02
    z[6,7,5]  R1894     1.8301378190517426e-01
    z[6,7,5]  R1895     -5.8333072811365128e-03
    z[6,7,5]  R1896     -2.2119371592998505e-01
    z[6,7,5]  R1897     -2.1240086853504181e-01
    z[6,7,5]  R1898     5.4374445229768753e-02
    z[6,7,5]  R1899     0.46855628490448
    z[6,7,5]  R1900     4.4005391001701355e-01
    z[6,7,5]  R1901     3.4282210469245911e-01
    z[6,7,5]  R1902     3.7020862102508545e-01
    z[6,7,5]  R1903     2.7709373831748962e-01
    z[6,7,5]  R1904     2.6857927441596985e-02
    z[6,7,5]  R1905     3.1723475456237793e-01
    z[6,7,5]  R1906     -2.6693260669708252e-01
    z[6,7,5]  R1907     -1.7569415271282196e-01
    z[6,7,5]  R1908     -2.7833628654479980e-01
    z[6,7,5]  R1909     -2.1191258728504181e-01
    z[6,7,5]  R1910     -1.5550585091114044e-01
    z[6,7,5]  R1911     3.7700343132019043e-01
    z[6,7,5]  R1912     2.4028272926807404e-01
    z[6,7,5]  R1913     2.4893839657306671e-01
    z[6,7,5]  R1914     4.6183583140373230e-01
    z[6,7,5]  R1915     4.0268638730049133e-01
    z[6,7,5]  R1916     -2.1071991324424744e-01
    z[6,7,5]  R1917     -5.5100526660680771e-02
    z[6,7,5]  R1918     -3.1226858496665955e-01
    z[6,7,5]  R1919     2.1409997344017029e-01
    z[6,7,5]  R1920     -2.6923105120658875e-01
    z[6,7,5]  R1921     1.0556698776781559e-02
    z[6,7,5]  R1922     -2.2960084676742554e-01
    z[6,7,5]  R1923     -2.9354125261306763e-01
    z[6,7,5]  R1924     1.9772459566593170e-01
    z[6,7,5]  R1925     7.6270140707492828e-02
    z[6,7,5]  R1926     -0.438752144575119
    z[6,7,5]  R1927     1.8437439203262329e-01
    z[6,7,5]  R1928     0.479140043258667
    z[6,7,5]  R1929     -6.7136198282241821e-02
    z[6,7,5]  R1930     3.4269323945045471e-01
    z[6,7,5]  R1931     6.7509203217923641e-03
    z[6,7,5]  R1932     8.8318727910518646e-02
    z[6,7,5]  R1933     0.106237031519413
    z[6,7,5]  R1934     -3.2369217276573181e-01
    z[6,7,5]  R1935     -1.6108108684420586e-02
    z[6,7,5]  R1936     7.9521842300891876e-02
    z[6,7,5]  R1937     2.3443512618541718e-01
    z[6,7,5]  R1938     5.2159792184829712e-01
    z[6,7,5]  R1939     4.1334626078605652e-01
    z[6,7,5]  R1940     -7.4474519491195679e-01
    z[6,7,5]  R1941     7.9768463969230652e-02
    z[6,7,5]  R1942     -6.0710810124874115e-02
    z[6,7,5]  R1943     -4.7103354334831238e-01
    z[6,7,5]  R1944     3.9072573184967041e-01
    z[6,7,5]  R1945     3.0902734398841858e-01
    z[6,7,5]  R1946     -3.4278473258018494e-01
    z[6,7,5]  R1947     -2.3782655596733093e-01
    z[6,7,5]  R1948     6.0546682216227055e-03
    z[6,7,5]  R1949     -1.3144052028656006e-01
    z[6,7,5]  R1950     -4.4617635011672974e-01
    z[6,7,5]  R1951     1.5767388045787811e-02
    z[6,7,5]  R1952     -1.1991579830646515e-01
    z[6,7,5]  R1953     -2.3325958847999573e-01
    z[6,7,5]  R1954     3.0029314756393433e-01
    z[6,7,5]  R1955     -4.3859221041202545e-02
    z[6,7,5]  R1956     -2.2928142547607422e-01
    z[6,7,5]  R1957     3.3179539442062378e-01
    z[6,7,5]  R1958     -1.5246884524822235e-01
    z[6,7,5]  R1959     2.8487738966941833e-01
    z[6,7,5]  R1960     -2.4778003990650177e-01
    z[6,7,5]  R1961     -2.5329765677452087e-01
    z[6,7,5]  R1962     -3.7968876957893372e-01
    z[6,7,5]  R1963     1.1191966384649277e-01
    z[6,7,5]  R1964     -1.2519817054271698e-01
    z[6,7,5]  R1965     -4.8322504758834839e-01
    z[6,7,5]  R1966     -4.7513374686241150e-01
    z[6,7,5]  R1967     3.2976108789443970e-01
    z[6,7,5]  R1968     1.5676942467689514e-01
    z[6,7,5]  R1969     -1.5645761787891388e-01
    z[6,7,5]  R1970     -4.1767066717147827e-01
    z[6,7,5]  R1971     -0.441301167011261
    z[6,7,5]  R1972     1.9575420022010803e-01
    z[6,7,5]  R1973     -5.8023486286401749e-02
    z[6,7,5]  R1974     -1.9879633188247681e-01
    z[6,7,5]  R1975     1.8935534358024597e-01
    z[6,7,5]  R1976     4.8942747712135315e-01
    z[6,7,5]  R1977     -3.7614226341247559e-01
    z[6,7,5]  R1978     0.315332293510437
    z[6,7,5]  R1979     -1.5954193472862244e-01
    z[6,7,5]  R1980     -0.552865207195282
    z[6,7,5]  R1981     0.139020174741745
    z[6,7,5]  R1982     3.7712097167968750e-01
    z[6,7,5]  R1983     -2.0908264815807343e-01
    z[6,7,5]  R1984     -3.0829685926437378e-01
    z[6,7,5]  R1985     -5.7268466800451279e-02
    z[6,7,5]  R1986     -4.8269700258970261e-02
    z[6,7,5]  R1987     -4.9002546072006226e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R1878     -1
    z[6,7,6]  R1879     1
    z[6,7,6]  R1880     -1.6993029415607452e-01
    z[6,7,6]  R1881     5.1385802030563354e-01
    z[6,7,6]  R1882     2.5195059180259705e-01
    z[6,7,6]  R1883     0.266657292842865
    z[6,7,6]  R1884     -1.8867613375186920e-01
    z[6,7,6]  R1885     -3.2001528888940811e-02
    z[6,7,6]  R1886     -1.8310065567493439e-01
    z[6,7,6]  R1887     0.506697416305542
    z[6,7,6]  R1888     3.5602548718452454e-01
    z[6,7,6]  R1889     4.8910453915596008e-02
    z[6,7,6]  R1890     -0.403319776058197
    z[6,7,6]  R1891     -4.0726795792579651e-02
    z[6,7,6]  R1892     2.2924545407295227e-01
    z[6,7,6]  R1893     -1.8716701865196228e-01
    z[6,7,6]  R1894     -1.5874285995960236e-01
    z[6,7,6]  R1895     1.9830964505672455e-01
    z[6,7,6]  R1896     -4.4789519160985947e-02
    z[6,7,6]  R1897     -1.8294534087181091e-01
    z[6,7,6]  R1898     -1.8529818952083588e-01
    z[6,7,6]  R1899     1.1554679274559021e-01
    z[6,7,6]  R1900     3.6919271945953369e-01
    z[6,7,6]  R1901     1.4193138480186462e-01
    z[6,7,6]  R1902     1.6270010173320770e-01
    z[6,7,6]  R1903     -6.5023888600990176e-04
    z[6,7,6]  R1904     2.6800441741943359e-01
    z[6,7,6]  R1905     -3.3488348126411438e-01
    z[6,7,6]  R1906     1.1048205941915512e-01
    z[6,7,6]  R1907     1.8190686404705048e-01
    z[6,7,6]  R1908     2.6113128662109375e-01
    z[6,7,6]  R1909     3.0068665742874146e-01
    z[6,7,6]  R1910     1.0309263318777084e-01
    z[6,7,6]  R1911     -9.4360075891017914e-02
    z[6,7,6]  R1912     1.9623020291328430e-01
    z[6,7,6]  R1913     3.2488524913787842e-02
    z[6,7,6]  R1914     -3.2493855804204941e-02
    z[6,7,6]  R1915     -9.7407236695289612e-02
    z[6,7,6]  R1916     -1.5290263295173645e-01
    z[6,7,6]  R1917     -1.7156034708023071e-01
    z[6,7,6]  R1918     -4.6725422143936157e-02
    z[6,7,6]  R1919     4.9532783031463623e-01
    z[6,7,6]  R1920     -2.0872111618518829e-01
    z[6,7,6]  R1921     3.6020421981811523e-01
    z[6,7,6]  R1922     3.5573670268058777e-01
    z[6,7,6]  R1923     -1.2744718790054321e-01
    z[6,7,6]  R1924     5.9656377881765366e-02
    z[6,7,6]  R1925     3.6065650638192892e-03
    z[6,7,6]  R1926     4.1999436914920807e-02
    z[6,7,6]  R1927     -1.0937235504388809e-01
    z[6,7,6]  R1928     -3.0923649668693542e-01
    z[6,7,6]  R1929     -4.7745892405509949e-01
    z[6,7,6]  R1930     2.9163654893636703e-02
    z[6,7,6]  R1931     -4.1628414392471313e-01
    z[6,7,6]  R1932     1.6103953123092651e-01
    z[6,7,6]  R1933     -3.5062587261199951e-01
    z[6,7,6]  R1934     0.0421445369720459
    z[6,7,6]  R1935     -3.5927903652191162e-01
    z[6,7,6]  R1936     3.0636456608772278e-01
    z[6,7,6]  R1937     1.0050907731056213e-01
    z[6,7,6]  R1938     -3.2746991515159607e-01
    z[6,7,6]  R1939     -1.4449976384639740e-01
    z[6,7,6]  R1940     1.4703397452831268e-01
    z[6,7,6]  R1941     -1.5040592849254608e-01
    z[6,7,6]  R1942     0.413028359413147
    z[6,7,6]  R1943     -0.553170919418335
    z[6,7,6]  R1944     1.5998384356498718e-01
    z[6,7,6]  R1945     -1.6976815462112427e-01
    z[6,7,6]  R1946     -5.4460763931274414e-01
    z[6,7,6]  R1947     -5.5427354574203491e-01
    z[6,7,6]  R1948     -2.2574107348918915e-01
    z[6,7,6]  R1949     -5.4722303152084351e-01
    z[6,7,6]  R1950     -0.51659095287323
    z[6,7,6]  R1951     -2.5100201368331909e-01
    z[6,7,6]  R1952     -1.2728338129818439e-02
    z[6,7,6]  R1953     -5.2735541015863419e-02
    z[6,7,6]  R1954     -3.2122838497161865e-01
    z[6,7,6]  R1955     1.2394971400499344e-01
    z[6,7,6]  R1956     3.7009704113006592e-01
    z[6,7,6]  R1957     3.8607341051101685e-01
    z[6,7,6]  R1958     -2.4830827116966248e-01
    z[6,7,6]  R1959     -3.2108855247497559e-01
    z[6,7,6]  R1960     -3.9138159155845642e-01
    z[6,7,6]  R1961     3.0075541138648987e-01
    z[6,7,6]  R1962     4.0192052721977234e-02
    z[6,7,6]  R1963     -1.6422481834888458e-01
    z[6,7,6]  R1964     1.4844579994678497e-01
    z[6,7,6]  R1965     -1.5973339974880219e-01
    z[6,7,6]  R1966     -3.3040615916252136e-01
    z[6,7,6]  R1967     8.7868541479110718e-02
    z[6,7,6]  R1968     -3.6068413406610489e-02
    z[6,7,6]  R1969     -1.4106044173240662e-01
    z[6,7,6]  R1970     -3.2500657439231873e-01
    z[6,7,6]  R1971     -1.4947728812694550e-01
    z[6,7,6]  R1972     7.2512738406658173e-02
    z[6,7,6]  R1973     2.2392643988132477e-01
    z[6,7,6]  R1974     -4.3936377763748169e-01
    z[6,7,6]  R1975     -3.8094186782836914e-01
    z[6,7,6]  R1976     1.1625473387539387e-02
    z[6,7,6]  R1977     9.8391041159629822e-02
    z[6,7,6]  R1978     2.3691312968730927e-01
    z[6,7,6]  R1979     -1.8052671849727631e-01
    z[6,7,6]  R1980     -4.5531578361988068e-02
    z[6,7,6]  R1981     1.8536303937435150e-01
    z[6,7,6]  R1982     -2.7101499959826469e-02
    z[6,7,6]  R1983     7.9745732247829437e-02
    z[6,7,6]  R1984     1.6762834787368774e-01
    z[6,7,6]  R1985     2.4025343358516693e-01
    z[6,7,6]  R1986     2.4498908221721649e-01
    z[6,7,6]  R1987     2.8599247336387634e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R1988     -1
    z[7,6,0]  R1989     1
    z[7,6,0]  R2002     1.4462977647781372e-01
    z[7,6,0]  R2003     2.0282746851444244e-01
    z[7,6,0]  R2004     -1.4239031076431274e-01
    z[7,6,0]  R2005     -8.0109804868698120e-02
    z[7,6,0]  R2006     -2.0861518383026123e-01
    z[7,6,0]  R2007     1.8142579495906830e-01
    z[7,6,0]  R2008     1.0963388532400131e-01
    z[7,6,0]  R2009     -4.8393601179122925e-01
    z[7,6,0]  R2010     -3.7745830416679382e-01
    z[7,6,0]  R2011     -1.5982395410537720e-01
    z[7,6,0]  R2012     5.4731643199920654e-01
    z[7,6,0]  R2013     -2.8332433104515076e-01
    z[7,6,0]  R2014     1.8951942026615143e-01
    z[7,6,0]  R2015     2.0079214870929718e-01
    z[7,6,0]  R2016     5.3021436929702759e-01
    z[7,6,0]  R2017     -2.2666609287261963e-01
    z[7,6,0]  R2018     -3.4470555186271667e-01
    z[7,6,0]  R2019     1.7929136753082275e-01
    z[7,6,0]  R2020     4.1812822222709656e-01
    z[7,6,0]  R2021     2.3096819221973419e-01
    z[7,6,0]  R2022     3.1026995182037354e-01
    z[7,6,0]  R2023     1.9502638280391693e-01
    z[7,6,0]  R2024     -2.3145294189453125e-01
    z[7,6,0]  R2025     4.9859631806612015e-02
    z[7,6,0]  R2026     -2.3853557184338570e-02
    z[7,6,0]  R2027     -2.5242453813552856e-01
    z[7,6,0]  R2028     2.6620236039161682e-01
    z[7,6,0]  R2029     7.1300083398818970e-01
    z[7,6,0]  R2030     -3.1056925654411316e-01
    z[7,6,0]  R2031     -2.4116815626621246e-01
    z[7,6,0]  R2032     -6.1735503375530243e-02
    z[7,6,0]  R2033     3.5499048233032227e-01
    z[7,6,0]  R2034     -2.3529201745986938e-01
    z[7,6,0]  R2035     -4.5805446803569794e-02
    z[7,6,0]  R2036     -3.3786529302597046e-01
    z[7,6,0]  R2037     -1.2771472334861755e-01
    z[7,6,0]  R2038     7.2117978334426880e-01
    z[7,6,0]  R2039     2.2776730358600616e-01
    z[7,6,0]  R2040     2.8832095861434937e-01
    z[7,6,0]  R2041     -1.2953884899616241e-01
    z[7,6,0]  R2042     9.7091786563396454e-02
    z[7,6,0]  R2043     -0.0796702653169632
    z[7,6,0]  R2044     -1.6089361906051636e-01
    z[7,6,0]  R2045     1.7138876020908356e-01
    z[7,6,0]  R2046     -3.0284032225608826e-01
    z[7,6,0]  R2047     1.8827617168426514e-01
    z[7,6,0]  R2048     -3.8897427916526794e-01
    z[7,6,0]  R2049     -3.2350787520408630e-01
    z[7,6,0]  R2050     -1.8089754879474640e-01
    z[7,6,0]  R2051     -6.2212910503149033e-02
    z[7,6,0]  R2052     -5.4922342300415039e-02
    z[7,6,0]  R2053     2.1008875966072083e-01
    z[7,6,0]  R2054     -1.9150808453559875e-02
    z[7,6,0]  R2055     -1.3141886889934540e-01
    z[7,6,0]  R2056     -0.280888170003891
    z[7,6,0]  R2057     -3.2990834116935730e-01
    z[7,6,0]  R2058     4.2448371648788452e-02
    z[7,6,0]  R2059     2.3840151727199554e-01
    z[7,6,0]  R2060     4.2176750302314758e-01
    z[7,6,0]  R2061     7.9707928001880646e-02
    z[7,6,0]  R2062     2.2722578048706055e-01
    z[7,6,0]  R2063     2.6506033539772034e-01
    z[7,6,0]  R2064     -2.3064351081848145e-01
    z[7,6,0]  R2065     -1.8559268116950989e-01
    z[7,6,0]  R2066     2.2781016305088997e-02
    z[7,6,0]  R2067     -4.7762727737426758e-01
    z[7,6,0]  R2068     -5.0240868330001831e-01
    z[7,6,0]  R2069     -4.3745297193527222e-01
    z[7,6,0]  R2070     -2.7342742681503296e-01
    z[7,6,0]  R2071     -4.5025333762168884e-01
    z[7,6,0]  R2072     4.3771749734878540e-01
    z[7,6,0]  R2073     -0.0391731858253479
    z[7,6,0]  R2074     -7.9466208815574646e-02
    z[7,6,0]  R2075     2.8266519308090210e-02
    z[7,6,0]  R2076     3.2036021351814270e-01
    z[7,6,0]  R2077     -0.265390545129776
    z[7,6,0]  R2078     -4.0817371010780334e-01
    z[7,6,0]  R2079     -2.0675820112228394e-01
    z[7,6,0]  R2080     -2.1835803985595703e-01
    z[7,6,0]  R2081     -4.9946942925453186e-01
    z[7,6,0]  R2082     1.2552453577518463e-01
    z[7,6,0]  R2083     -4.2251676321029663e-01
    z[7,6,0]  R2084     -3.4860372543334961e-01
    z[7,6,0]  R2085     -3.0182841420173645e-01
    z[7,6,0]  R2086     -1.7583738267421722e-01
    z[7,6,0]  R2087     -3.7901768088340759e-01
    z[7,6,0]  R2088     -0.405945360660553
    z[7,6,0]  R2089     -2.5149145722389221e-01
    z[7,6,0]  R2090     -1.7418639361858368e-01
    z[7,6,0]  R2091     -3.5367617011070251e-01
    z[7,6,0]  R2092     3.9054846763610840e-01
    z[7,6,0]  R2093     -7.9799056053161621e-02
    z[7,6,0]  R2094     -1.7246741056442261e-01
    z[7,6,0]  R2095     -1.9270287454128265e-01
    z[7,6,0]  R2096     -3.9180281758308411e-01
    z[7,6,0]  R2097     5.6069605052471161e-02
    z[7,6,0]  R2098     5.9873914718627930e-01
    z[7,6,0]  R2099     6.5670222043991089e-01
    z[7,6,0]  R2100     3.5155642032623291e-01
    z[7,6,0]  R2101     2.6440745592117310e-01
    z[7,6,0]  R2102     -4.0735068917274475e-01
    z[7,6,0]  R2103     -4.5452676713466644e-02
    z[7,6,0]  R2104     -2.4952669441699982e-01
    z[7,6,0]  R2105     -0.157730370759964
    z[7,6,0]  R2106     -6.5584409236907959e-01
    z[7,6,0]  R2107     -7.1817688643932343e-02
    z[7,6,0]  R2108     -9.2405068874359131e-01
    z[7,6,0]  R2109     -9.2647778987884521e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R1990     -1
    z[7,6,1]  R1991     1
    z[7,6,1]  R2002     8.8997566699981689e-01
    z[7,6,1]  R2003     5.6347352266311646e-01
    z[7,6,1]  R2004     5.3149688243865967e-01
    z[7,6,1]  R2005     4.7394096851348877e-01
    z[7,6,1]  R2006     -8.6980652809143066e-01
    z[7,6,1]  R2007     4.5374700427055359e-01
    z[7,6,1]  R2008     -7.2401589155197144e-01
    z[7,6,1]  R2009     -0.854438841342926
    z[7,6,1]  R2010     -5.5981749296188354e-01
    z[7,6,1]  R2011     4.8178479075431824e-01
    z[7,6,1]  R2012     3.6600002646446228e-01
    z[7,6,1]  R2013     -0.652351438999176
    z[7,6,1]  R2014     1.9683641195297241e-01
    z[7,6,1]  R2015     -5.6298565864562988e-01
    z[7,6,1]  R2016     9.3209460377693176e-02
    z[7,6,1]  R2017     -3.4307649731636047e-01
    z[7,6,1]  R2018     -2.4836876988410950e-01
    z[7,6,1]  R2019     -8.3863925933837891e-01
    z[7,6,1]  R2020     -1.2238927185535431e-01
    z[7,6,1]  R2021     -7.0744502544403076e-01
    z[7,6,1]  R2022     2.8402090072631836e-01
    z[7,6,1]  R2023     6.2036657333374023e-01
    z[7,6,1]  R2024     -5.9176814556121826e-01
    z[7,6,1]  R2025     -6.9369810819625854e-01
    z[7,6,1]  R2026     5.0723671913146973e-01
    z[7,6,1]  R2027     -5.3851896524429321e-01
    z[7,6,1]  R2028     6.1436223983764648e-01
    z[7,6,1]  R2029     5.4348480701446533e-01
    z[7,6,1]  R2030     -4.8074319958686829e-01
    z[7,6,1]  R2031     -4.0413281321525574e-01
    z[7,6,1]  R2032     -5.2071684598922729e-01
    z[7,6,1]  R2033     5.8704417943954468e-01
    z[7,6,1]  R2034     -4.6282440423965454e-01
    z[7,6,1]  R2035     6.0084664821624756e-01
    z[7,6,1]  R2036     -0.56495201587677
    z[7,6,1]  R2037     -4.6176734566688538e-01
    z[7,6,1]  R2038     4.9946096539497375e-01
    z[7,6,1]  R2039     6.1561310291290283e-01
    z[7,6,1]  R2040     -4.0816673636436462e-01
    z[7,6,1]  R2041     -4.3503656983375549e-01
    z[7,6,1]  R2042     6.2327593564987183e-01
    z[7,6,1]  R2043     7.1865928173065186e-01
    z[7,6,1]  R2044     -7.5535839796066284e-01
    z[7,6,1]  R2045     -5.4526019096374512e-01
    z[7,6,1]  R2046     -0.555756151676178
    z[7,6,1]  R2047     1.3988788425922394e-01
    z[7,6,1]  R2048     -6.5123164653778076e-01
    z[7,6,1]  R2049     -4.4593289494514465e-01
    z[7,6,1]  R2050     -4.6819174289703369e-01
    z[7,6,1]  R2051     -5.4919254779815674e-01
    z[7,6,1]  R2052     -8.0863159894943237e-01
    z[7,6,1]  R2053     -9.4244188070297241e-01
    z[7,6,1]  R2054     -7.6257109642028809e-01
    z[7,6,1]  R2055     -7.5732493400573730e-01
    z[7,6,1]  R2056     -7.1655815839767456e-01
    z[7,6,1]  R2057     -5.2059888839721680e-01
    z[7,6,1]  R2058     -7.0152491331100464e-01
    z[7,6,1]  R2059     -5.9501367807388306e-01
    z[7,6,1]  R2060     3.2451578974723816e-01
    z[7,6,1]  R2061     -2.0547662675380707e-01
    z[7,6,1]  R2062     5.9226512908935547e-01
    z[7,6,1]  R2063     -4.9956339597702026e-01
    z[7,6,1]  R2064     -5.6142532825469971e-01
    z[7,6,1]  R2065     -4.3255776166915894e-01
    z[7,6,1]  R2066     -4.2222142219543457e-01
    z[7,6,1]  R2067     7.2138541936874390e-01
    z[7,6,1]  R2068     7.3265445232391357e-01
    z[7,6,1]  R2069     0.735712468624115
    z[7,6,1]  R2070     8.1659460067749023e-01
    z[7,6,1]  R2071     6.6647243499755859e-01
    z[7,6,1]  R2072     -6.3786697387695312e-01
    z[7,6,1]  R2073     -7.8977859020233154e-01
    z[7,6,1]  R2074     -6.4975708723068237e-01
    z[7,6,1]  R2075     -1.4225061237812042e-01
    z[7,6,1]  R2076     -1.5911851823329926e-01
    z[7,6,1]  R2077     7.4082785844802856e-01
    z[7,6,1]  R2078     6.8664455413818359e-01
    z[7,6,1]  R2079     7.6769286394119263e-01
    z[7,6,1]  R2080     7.7680385112762451e-01
    z[7,6,1]  R2081     4.6662130951881409e-01
    z[7,6,1]  R2082     -4.3242397904396057e-01
    z[7,6,1]  R2083     8.2586342096328735e-01
    z[7,6,1]  R2084     8.0291557312011719e-01
    z[7,6,1]  R2085     9.1544169187545776e-01
    z[7,6,1]  R2086     8.8984721899032593e-01
    z[7,6,1]  R2087     8.6142480373382568e-01
    z[7,6,1]  R2088     8.5968142747879028e-01
    z[7,6,1]  R2089     8.9190471172332764e-01
    z[7,6,1]  R2090     9.2931693792343140e-01
    z[7,6,1]  R2091     3.6163869500160217e-01
    z[7,6,1]  R2092     -1.3008889555931091e-01
    z[7,6,1]  R2093     8.9851087331771851e-01
    z[7,6,1]  R2094     4.9530696868896484e-01
    z[7,6,1]  R2095     5.3853332996368408e-01
    z[7,6,1]  R2096     1.7717395722866058e-01
    z[7,6,1]  R2097     6.4072179794311523e-01
    z[7,6,1]  R2098     5.4572504758834839e-01
    z[7,6,1]  R2099     5.3164607286453247e-01
    z[7,6,1]  R2100     2.2954449057579041e-01
    z[7,6,1]  R2101     3.2020118832588196e-01
    z[7,6,1]  R2102     8.6463242769241333e-01
    z[7,6,1]  R2103     9.0580314397811890e-01
    z[7,6,1]  R2104     4.1640976071357727e-01
    z[7,6,1]  R2105     5.1957857608795166e-01
    z[7,6,1]  R2106     1.3578817248344421e-01
    z[7,6,1]  R2107     6.4486914873123169e-01
    z[7,6,1]  R2108     1.0491027496755123e-02
    z[7,6,1]  R2109     0.0408322811126709
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R1992     -1
    z[7,6,2]  R1993     1
    z[7,6,2]  R2002     1.5626215934753418e-01
    z[7,6,2]  R2003     1.4070723950862885e-01
    z[7,6,2]  R2004     6.9898366928100586e-02
    z[7,6,2]  R2005     -5.5283259600400925e-02
    z[7,6,2]  R2006     0.0860406756401062
    z[7,6,2]  R2007     5.0194729119539261e-02
    z[7,6,2]  R2008     5.7102650403976440e-01
    z[7,6,2]  R2009     -1.7140921950340271e-01
    z[7,6,2]  R2010     5.3867197036743164e-01
    z[7,6,2]  R2011     -1.0154915601015091e-01
    z[7,6,2]  R2012     9.3037039041519165e-02
    z[7,6,2]  R2013     8.0166503787040710e-02
    z[7,6,2]  R2014     -0.686255156993866
    z[7,6,2]  R2015     3.1873509287834167e-01
    z[7,6,2]  R2016     -2.4452788755297661e-02
    z[7,6,2]  R2017     3.0223757028579712e-01
    z[7,6,2]  R2018     -2.4538283050060272e-01
    z[7,6,2]  R2019     -1.0774039663374424e-02
    z[7,6,2]  R2020     3.8475415110588074e-01
    z[7,6,2]  R2021     -2.4036644399166107e-01
    z[7,6,2]  R2022     1.6755943000316620e-01
    z[7,6,2]  R2023     -6.1562073230743408e-01
    z[7,6,2]  R2024     1.2368278205394745e-01
    z[7,6,2]  R2025     -3.2838433980941772e-02
    z[7,6,2]  R2026     -5.2198302745819092e-01
    z[7,6,2]  R2027     2.7007073163986206e-01
    z[7,6,2]  R2028     3.4253621101379395e-01
    z[7,6,2]  R2029     1.1106052435934544e-02
    z[7,6,2]  R2030     -6.6184081137180328e-02
    z[7,6,2]  R2031     -2.2363376617431641e-01
    z[7,6,2]  R2032     6.8158376216888428e-01
    z[7,6,2]  R2033     2.2800515592098236e-01
    z[7,6,2]  R2034     4.6837532520294189e-01
    z[7,6,2]  R2035     -2.4548043310642242e-01
    z[7,6,2]  R2036     3.2230582088232040e-02
    z[7,6,2]  R2037     3.8513442873954773e-01
    z[7,6,2]  R2038     1.8799996376037598e-01
    z[7,6,2]  R2039     -2.9129263758659363e-01
    z[7,6,2]  R2040     4.2210742831230164e-01
    z[7,6,2]  R2041     5.6851077079772949e-01
    z[7,6,2]  R2042     -6.6060012578964233e-01
    z[7,6,2]  R2043     1.0846129059791565e-01
    z[7,6,2]  R2044     -1.4594377577304840e-01
    z[7,6,2]  R2045     6.9918280839920044e-01
    z[7,6,2]  R2046     -9.2435348778963089e-03
    z[7,6,2]  R2047     -2.3108625411987305e-01
    z[7,6,2]  R2048     -1.9133625924587250e-01
    z[7,6,2]  R2049     2.5521764159202576e-01
    z[7,6,2]  R2050     4.5094007253646851e-01
    z[7,6,2]  R2051     3.7741002440452576e-01
    z[7,6,2]  R2052     1.5772137045860291e-01
    z[7,6,2]  R2053     0.121115542948246
    z[7,6,2]  R2054     0.227840393781662
    z[7,6,2]  R2055     -0.0860668197274208
    z[7,6,2]  R2056     1.8881501257419586e-01
    z[7,6,2]  R2057     5.2971524000167847e-01
    z[7,6,2]  R2058     3.8336157798767090e-02
    z[7,6,2]  R2059     5.1168650388717651e-01
    z[7,6,2]  R2060     -6.2997028231620789e-02
    z[7,6,2]  R2061     0.702738344669342
    z[7,6,2]  R2062     -8.3330802619457245e-02
    z[7,6,2]  R2063     5.5563312768936157e-01
    z[7,6,2]  R2064     1.6081599891185760e-01
    z[7,6,2]  R2065     8.1674647331237793e-01
    z[7,6,2]  R2066     6.7043161392211914e-01
    z[7,6,2]  R2067     -2.8460618853569031e-01
    z[7,6,2]  R2068     1.6050188243389130e-01
    z[7,6,2]  R2069     -1.4110109210014343e-01
    z[7,6,2]  R2070     1.0098636895418167e-01
    z[7,6,2]  R2071     2.0625907927751541e-02
    z[7,6,2]  R2072     5.9278792142868042e-01
    z[7,6,2]  R2073     1.7924880981445312e-01
    z[7,6,2]  R2074     -1.9406531751155853e-01
    z[7,6,2]  R2075     6.1752600595355034e-04
    z[7,6,2]  R2076     -1.7152637243270874e-02
    z[7,6,2]  R2077     -1.6465066000819206e-02
    z[7,6,2]  R2078     1.0463666170835495e-01
    z[7,6,2]  R2079     2.5198884308338165e-02
    z[7,6,2]  R2080     3.4140422940254211e-01
    z[7,6,2]  R2081     3.1607914716005325e-02
    z[7,6,2]  R2082     -4.9568369984626770e-01
    z[7,6,2]  R2083     -3.0892071127891541e-01
    z[7,6,2]  R2084     -2.8230714797973633e-01
    z[7,6,2]  R2085     7.4818126857280731e-02
    z[7,6,2]  R2086     -3.3239787817001343e-01
    z[7,6,2]  R2087     -2.3629236221313477e-01
    z[7,6,2]  R2088     -1.4860311150550842e-01
    z[7,6,2]  R2089     -1.7808496952056885e-01
    z[7,6,2]  R2090     -1.9802547991275787e-01
    z[7,6,2]  R2091     4.0964248776435852e-01
    z[7,6,2]  R2092     -3.2503670454025269e-01
    z[7,6,2]  R2093     1.9173230230808258e-01
    z[7,6,2]  R2094     3.0728760361671448e-01
    z[7,6,2]  R2095     3.2520228624343872e-01
    z[7,6,2]  R2096     1.8137063086032867e-01
    z[7,6,2]  R2097     1.3683487474918365e-01
    z[7,6,2]  R2098     1.9424313306808472e-01
    z[7,6,2]  R2099     1.5622487664222717e-01
    z[7,6,2]  R2100     2.5217339396476746e-01
    z[7,6,2]  R2101     3.9589118957519531e-01
    z[7,6,2]  R2102     -4.1760094463825226e-02
    z[7,6,2]  R2103     8.1125594675540924e-02
    z[7,6,2]  R2104     1.5294852852821350e-01
    z[7,6,2]  R2105     2.2984346747398376e-01
    z[7,6,2]  R2106     3.5008290410041809e-01
    z[7,6,2]  R2107     1.5769174695014954e-01
    z[7,6,2]  R2108     9.1569451615214348e-03
    z[7,6,2]  R2109     4.3774012476205826e-02
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R1994     -1
    z[7,6,3]  R1995     1
    z[7,6,3]  R2002     -1.9977492094039917e-01
    z[7,6,3]  R2003     -4.5930573344230652e-01
    z[7,6,3]  R2004     -7.5363588333129883e-01
    z[7,6,3]  R2005     -5.6296902894973755e-01
    z[7,6,3]  R2006     -2.4565504863858223e-02
    z[7,6,3]  R2007     -5.3719317913055420e-01
    z[7,6,3]  R2008     -2.0710441470146179e-01
    z[7,6,3]  R2009     -2.1754177287220955e-02
    z[7,6,3]  R2010     -1.8905088305473328e-01
    z[7,6,3]  R2011     -2.4509520828723907e-01
    z[7,6,3]  R2012     -2.9720559716224670e-01
    z[7,6,3]  R2013     -4.1779360175132751e-01
    z[7,6,3]  R2014     -0.559943675994873
    z[7,6,3]  R2015     3.1916698813438416e-01
    z[7,6,3]  R2016     -7.5362426042556763e-01
    z[7,6,3]  R2017     7.7795481681823730e-01
    z[7,6,3]  R2018     8.0503243207931519e-01
    z[7,6,3]  R2019     3.2476234436035156e-01
    z[7,6,3]  R2020     -4.7026541829109192e-01
    z[7,6,3]  R2021     5.5571585893630981e-01
    z[7,6,3]  R2022     -6.1917799711227417e-01
    z[7,6,3]  R2023     6.9842688739299774e-02
    z[7,6,3]  R2024     -5.1531377248466015e-03
    z[7,6,3]  R2025     5.9765160083770752e-01
    z[7,6,3]  R2026     -4.1451793909072876e-01
    z[7,6,3]  R2027     1.8008767068386078e-01
    z[7,6,3]  R2028     -3.8358801603317261e-01
    z[7,6,3]  R2029     0.267170250415802
    z[7,6,3]  R2030     4.3227684497833252e-01
    z[7,6,3]  R2031     5.9382396936416626e-01
    z[7,6,3]  R2032     -4.5205873250961304e-01
    z[7,6,3]  R2033     -3.3212760090827942e-01
    z[7,6,3]  R2034     1.8679212033748627e-01
    z[7,6,3]  R2035     -2.9897835850715637e-01
    z[7,6,3]  R2036     2.3277139663696289e-01
    z[7,6,3]  R2037     5.3183770179748535e-01
    z[7,6,3]  R2038     -1.4117913320660591e-02
    z[7,6,3]  R2039     -1.3899800181388855e-01
    z[7,6,3]  R2040     -4.4124302268028259e-01
    z[7,6,3]  R2041     4.1658997535705566e-01
    z[7,6,3]  R2042     -2.7856573462486267e-01
    z[7,6,3]  R2043     -4.0980812907218933e-01
    z[7,6,3]  R2044     2.2978819906711578e-01
    z[7,6,3]  R2045     1.8695114180445671e-02
    z[7,6,3]  R2046     4.2316564917564392e-01
    z[7,6,3]  R2047     -9.2306923866271973e-01
    z[7,6,3]  R2048     3.0637022852897644e-01
    z[7,6,3]  R2049     6.0286504030227661e-01
    z[7,6,3]  R2050     -2.6251927018165588e-01
    z[7,6,3]  R2051     0.3237284719944
    z[7,6,3]  R2052     4.8264548182487488e-01
    z[7,6,3]  R2053     -6.8123318254947662e-02
    z[7,6,3]  R2054     -2.4848574399948120e-01
    z[7,6,3]  R2055     -0.09919423609972
    z[7,6,3]  R2056     6.9111935794353485e-02
    z[7,6,3]  R2057     3.1444087624549866e-01
    z[7,6,3]  R2058     2.7635595202445984e-01
    z[7,6,3]  R2059     1.7880478873848915e-02
    z[7,6,3]  R2060     -5.5708044767379761e-01
    z[7,6,3]  R2061     -4.9197328090667725e-01
    z[7,6,3]  R2062     -6.1810475587844849e-01
    z[7,6,3]  R2063     -2.9371315240859985e-01
    z[7,6,3]  R2064     3.5752159357070923e-01
    z[7,6,3]  R2065     2.3813307285308838e-01
    z[7,6,3]  R2066     -2.2278147935867310e-01
    z[7,6,3]  R2067     3.4698012471199036e-01
    z[7,6,3]  R2068     1.5617586672306061e-01
    z[7,6,3]  R2069     4.3177241086959839e-01
    z[7,6,3]  R2070     3.2639807462692261e-01
    z[7,6,3]  R2071     -0.044993806630373
    z[7,6,3]  R2072     1.4309599995613098e-01
    z[7,6,3]  R2073     2.0340880379080772e-02
    z[7,6,3]  R2074     4.2678320407867432e-01
    z[7,6,3]  R2075     6.4608812332153320e-01
    z[7,6,3]  R2076     6.9559633731842041e-01
    z[7,6,3]  R2077     -4.2864549160003662e-01
    z[7,6,3]  R2078     -4.9572768807411194e-01
    z[7,6,3]  R2079     -2.1139457821846008e-01
    z[7,6,3]  R2080     8.2375489175319672e-02
    z[7,6,3]  R2081     -3.4938955307006836e-01
    z[7,6,3]  R2082     -5.2039200067520142e-01
    z[7,6,3]  R2083     -1.9592165946960449e-01
    z[7,6,3]  R2084     -2.3345731198787689e-01
    z[7,6,3]  R2085     -0.0956321656703949
    z[7,6,3]  R2086     3.1020302325487137e-02
    z[7,6,3]  R2087     1.2633083760738373e-01
    z[7,6,3]  R2088     1.5026177465915680e-01
    z[7,6,3]  R2089     1.2448097020387650e-01
    z[7,6,3]  R2090     1.5761420130729675e-01
    z[7,6,3]  R2091     -5.7083618640899658e-01
    z[7,6,3]  R2092     -1.4982836320996284e-02
    z[7,6,3]  R2093     -5.1439993083477020e-02
    z[7,6,3]  R2094     -0.683329164981842
    z[7,6,3]  R2095     -6.9987994432449341e-01
    z[7,6,3]  R2096     -0.806423008441925
    z[7,6,3]  R2097     -0.5048828125
    z[7,6,3]  R2098     -4.6675089001655579e-01
    z[7,6,3]  R2099     -4.0775465965270996e-01
    z[7,6,3]  R2100     -7.8291893005371094e-01
    z[7,6,3]  R2101     -7.0910942554473877e-01
    z[7,6,3]  R2102     -1.1135594546794891e-01
    z[7,6,3]  R2103     -1.2968315184116364e-01
    z[7,6,3]  R2104     -7.8794735670089722e-01
    z[7,6,3]  R2105     -7.2757571935653687e-01
    z[7,6,3]  R2106     -4.1660082340240479e-01
    z[7,6,3]  R2107     -0.606228232383728
    z[7,6,3]  R2108     -2.7904081344604492e-01
    z[7,6,3]  R2109     -1.6004312038421631e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R1996     -1
    z[7,6,4]  R1997     1
    z[7,6,4]  R2002     -1.5166673064231873e-01
    z[7,6,4]  R2003     -3.4555739164352417e-01
    z[7,6,4]  R2004     -9.1287478804588318e-02
    z[7,6,4]  R2005     -5.6490135192871094e-01
    z[7,6,4]  R2006     -1.1244915425777435e-01
    z[7,6,4]  R2007     -6.0637700557708740e-01
    z[7,6,4]  R2008     -2.2839431464672089e-01
    z[7,6,4]  R2009     -7.4578397907316685e-03
    z[7,6,4]  R2010     1.5477222204208374e-01
    z[7,6,4]  R2011     -7.9120141267776489e-01
    z[7,6,4]  R2012     0.379867285490036
    z[7,6,4]  R2013     -2.8409931063652039e-01
    z[7,6,4]  R2014     -1.5021848678588867e-01
    z[7,6,4]  R2015     0.51568603515625
    z[7,6,4]  R2016     3.2848662137985229e-01
    z[7,6,4]  R2017     1.1617516167461872e-02
    z[7,6,4]  R2018     -6.8178132176399231e-02
    z[7,6,4]  R2019     1.7207933962345123e-01
    z[7,6,4]  R2020     5.8379912376403809e-01
    z[7,6,4]  R2021     -1.2048694491386414e-01
    z[7,6,4]  R2022     -1.7973898351192474e-01
    z[7,6,4]  R2023     3.8831412792205811e-02
    z[7,6,4]  R2024     6.8202883005142212e-02
    z[7,6,4]  R2025     3.5923016071319580e-01
    z[7,6,4]  R2026     3.5152861475944519e-01
    z[7,6,4]  R2027     -1.1418701708316803e-01
    z[7,6,4]  R2028     3.3009532094001770e-01
    z[7,6,4]  R2029     -0.020780049264431
    z[7,6,4]  R2030     -2.5901803374290466e-01
    z[7,6,4]  R2031     1.0997701436281204e-01
    z[7,6,4]  R2032     -7.1648612618446350e-02
    z[7,6,4]  R2033     2.2435715794563293e-01
    z[7,6,4]  R2034     -1.0111869871616364e-01
    z[7,6,4]  R2035     6.5114194154739380e-01
    z[7,6,4]  R2036     7.0492070913314819e-01
    z[7,6,4]  R2037     5.3112041950225830e-01
    z[7,6,4]  R2038     -3.9135057479143143e-02
    z[7,6,4]  R2039     6.6909164190292358e-01
    z[7,6,4]  R2040     4.3342703580856323e-01
    z[7,6,4]  R2041     1.9511634111404419e-01
    z[7,6,4]  R2042     5.6614045053720474e-02
    z[7,6,4]  R2043     -3.3648470044136047e-01
    z[7,6,4]  R2044     -3.3892503380775452e-01
    z[7,6,4]  R2045     1.7174851894378662e-01
    z[7,6,4]  R2046     5.2391719818115234e-01
    z[7,6,4]  R2047     -5.4748533293604851e-03
    z[7,6,4]  R2048     5.0637274980545044e-01
    z[7,6,4]  R2049     -9.4249770045280457e-02
    z[7,6,4]  R2050     -3.7535166740417480e-01
    z[7,6,4]  R2051     5.7516556978225708e-01
    z[7,6,4]  R2052     -2.4371746182441711e-01
    z[7,6,4]  R2053     -0.0630812719464302
    z[7,6,4]  R2054     -1.5615428984165192e-01
    z[7,6,4]  R2055     -4.1815164685249329e-01
    z[7,6,4]  R2056     5.6889444589614868e-01
    z[7,6,4]  R2057     4.3261536955833435e-01
    z[7,6,4]  R2058     4.4233259558677673e-01
    z[7,6,4]  R2059     3.8211050629615784e-01
    z[7,6,4]  R2060     4.0350979566574097e-01
    z[7,6,4]  R2061     2.5373873114585876e-01
    z[7,6,4]  R2062     2.3028384149074554e-01
    z[7,6,4]  R2063     4.7659239172935486e-01
    z[7,6,4]  R2064     4.1253918409347534e-01
    z[7,6,4]  R2065     -3.1321745365858078e-02
    z[7,6,4]  R2066     4.2325553297996521e-01
    z[7,6,4]  R2067     -2.1023072768002748e-03
    z[7,6,4]  R2068     1.9366234540939331e-01
    z[7,6,4]  R2069     4.8675616271793842e-03
    z[7,6,4]  R2070     2.8165090084075928e-01
    z[7,6,4]  R2071     1.6946977376937866e-01
    z[7,6,4]  R2072     2.7665689587593079e-02
    z[7,6,4]  R2073     -2.4357780814170837e-01
    z[7,6,4]  R2074     2.6279106736183167e-02
    z[7,6,4]  R2075     -6.8679553270339966e-01
    z[7,6,4]  R2076     -1.4388452470302582e-01
    z[7,6,4]  R2077     -2.7435779571533203e-01
    z[7,6,4]  R2078     -2.6665431261062622e-01
    z[7,6,4]  R2079     -1.9006811082363129e-01
    z[7,6,4]  R2080     1.6959916055202484e-01
    z[7,6,4]  R2081     -1.8545034527778625e-01
    z[7,6,4]  R2082     -1.9016557931900024e-01
    z[7,6,4]  R2083     2.3510249331593513e-02
    z[7,6,4]  R2084     -2.3511119186878204e-02
    z[7,6,4]  R2085     1.0578073561191559e-01
    z[7,6,4]  R2086     -8.4315322339534760e-02
    z[7,6,4]  R2087     -5.6022573262453079e-02
    z[7,6,4]  R2088     -2.3705333471298218e-02
    z[7,6,4]  R2089     -1.2435884773731232e-01
    z[7,6,4]  R2090     6.8415597081184387e-02
    z[7,6,4]  R2091     1.3256542384624481e-01
    z[7,6,4]  R2092     6.2827128171920776e-01
    z[7,6,4]  R2093     9.6080303192138672e-02
    z[7,6,4]  R2094     5.9793880209326744e-03
    z[7,6,4]  R2095     2.1853532642126083e-02
    z[7,6,4]  R2096     2.4359565973281860e-01
    z[7,6,4]  R2097     0.316095769405365
    z[7,6,4]  R2098     6.8187497556209564e-02
    z[7,6,4]  R2099     -1.7738720774650574e-01
    z[7,6,4]  R2100     0.0387742780148983
    z[7,6,4]  R2101     1.8076086044311523e-01
    z[7,6,4]  R2102     1.9370573759078979e-01
    z[7,6,4]  R2103     5.4957389831542969e-02
    z[7,6,4]  R2104     1.5441209077835083e-01
    z[7,6,4]  R2105     2.4482429027557373e-01
    z[7,6,4]  R2106     2.0240475237369537e-01
    z[7,6,4]  R2107     1.2232014536857605e-01
    z[7,6,4]  R2108     -1.7041441053152084e-02
    z[7,6,4]  R2109     -2.8279429674148560e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R1998     -1
    z[7,6,5]  R1999     1
    z[7,6,5]  R2002     -3.1226858496665955e-01
    z[7,6,5]  R2003     2.1409997344017029e-01
    z[7,6,5]  R2004     -2.6923105120658875e-01
    z[7,6,5]  R2005     1.0556698776781559e-02
    z[7,6,5]  R2006     -2.2960084676742554e-01
    z[7,6,5]  R2007     -2.9354125261306763e-01
    z[7,6,5]  R2008     1.9772459566593170e-01
    z[7,6,5]  R2009     7.6270140707492828e-02
    z[7,6,5]  R2010     -0.438752144575119
    z[7,6,5]  R2011     1.8437439203262329e-01
    z[7,6,5]  R2012     0.479140043258667
    z[7,6,5]  R2013     -6.7136198282241821e-02
    z[7,6,5]  R2014     3.4269323945045471e-01
    z[7,6,5]  R2015     6.7509203217923641e-03
    z[7,6,5]  R2016     8.8318727910518646e-02
    z[7,6,5]  R2017     0.106237031519413
    z[7,6,5]  R2018     -3.2369217276573181e-01
    z[7,6,5]  R2019     -1.6108108684420586e-02
    z[7,6,5]  R2020     7.9521842300891876e-02
    z[7,6,5]  R2021     2.3443512618541718e-01
    z[7,6,5]  R2022     5.2159792184829712e-01
    z[7,6,5]  R2023     4.1334626078605652e-01
    z[7,6,5]  R2024     -7.4474519491195679e-01
    z[7,6,5]  R2025     7.9768463969230652e-02
    z[7,6,5]  R2026     -6.0710810124874115e-02
    z[7,6,5]  R2027     -4.7103354334831238e-01
    z[7,6,5]  R2028     3.9072573184967041e-01
    z[7,6,5]  R2029     3.0902734398841858e-01
    z[7,6,5]  R2030     -3.4278473258018494e-01
    z[7,6,5]  R2031     -2.3782655596733093e-01
    z[7,6,5]  R2032     6.0546682216227055e-03
    z[7,6,5]  R2033     -1.3144052028656006e-01
    z[7,6,5]  R2034     -4.4617635011672974e-01
    z[7,6,5]  R2035     1.5767388045787811e-02
    z[7,6,5]  R2036     -1.1991579830646515e-01
    z[7,6,5]  R2037     -2.3325958847999573e-01
    z[7,6,5]  R2038     3.0029314756393433e-01
    z[7,6,5]  R2039     -4.3859221041202545e-02
    z[7,6,5]  R2040     -2.2928142547607422e-01
    z[7,6,5]  R2041     3.3179539442062378e-01
    z[7,6,5]  R2042     -1.5246884524822235e-01
    z[7,6,5]  R2043     2.8487738966941833e-01
    z[7,6,5]  R2044     -2.4778003990650177e-01
    z[7,6,5]  R2045     -2.5329765677452087e-01
    z[7,6,5]  R2046     -3.7968876957893372e-01
    z[7,6,5]  R2047     1.1191966384649277e-01
    z[7,6,5]  R2048     -1.2519817054271698e-01
    z[7,6,5]  R2049     -4.8322504758834839e-01
    z[7,6,5]  R2050     -4.7513374686241150e-01
    z[7,6,5]  R2051     3.2976108789443970e-01
    z[7,6,5]  R2052     1.5676942467689514e-01
    z[7,6,5]  R2053     -1.5645761787891388e-01
    z[7,6,5]  R2054     -4.1767066717147827e-01
    z[7,6,5]  R2055     -0.441301167011261
    z[7,6,5]  R2056     1.9575420022010803e-01
    z[7,6,5]  R2057     -5.8023486286401749e-02
    z[7,6,5]  R2058     -1.9879633188247681e-01
    z[7,6,5]  R2059     1.8935534358024597e-01
    z[7,6,5]  R2060     4.8942747712135315e-01
    z[7,6,5]  R2061     -3.7614226341247559e-01
    z[7,6,5]  R2062     0.315332293510437
    z[7,6,5]  R2063     -1.5954193472862244e-01
    z[7,6,5]  R2064     -0.552865207195282
    z[7,6,5]  R2065     0.139020174741745
    z[7,6,5]  R2066     3.7712097167968750e-01
    z[7,6,5]  R2067     -2.0908264815807343e-01
    z[7,6,5]  R2068     -3.0829685926437378e-01
    z[7,6,5]  R2069     -5.7268466800451279e-02
    z[7,6,5]  R2070     -4.8269700258970261e-02
    z[7,6,5]  R2071     -4.9002546072006226e-01
    z[7,6,5]  R2072     3.6649480462074280e-03
    z[7,6,5]  R2073     -0.137080579996109
    z[7,6,5]  R2074     -5.3621435165405273e-01
    z[7,6,5]  R2075     1.3689872622489929e-01
    z[7,6,5]  R2076     5.7584780454635620e-01
    z[7,6,5]  R2077     3.4704136848449707e-01
    z[7,6,5]  R2078     -0.0242563858628273
    z[7,6,5]  R2079     -1.7235971987247467e-01
    z[7,6,5]  R2080     -2.6464128494262695e-01
    z[7,6,5]  R2081     -6.1068701744079590e-01
    z[7,6,5]  R2082     2.8620478510856628e-01
    z[7,6,5]  R2083     -5.8314543217420578e-02
    z[7,6,5]  R2084     2.1562939882278442e-01
    z[7,6,5]  R2085     -9.9507674574851990e-02
    z[7,6,5]  R2086     1.8301378190517426e-01
    z[7,6,5]  R2087     -5.8333072811365128e-03
    z[7,6,5]  R2088     -2.2119371592998505e-01
    z[7,6,5]  R2089     -2.1240086853504181e-01
    z[7,6,5]  R2090     5.4374445229768753e-02
    z[7,6,5]  R2091     0.46855628490448
    z[7,6,5]  R2092     4.4005391001701355e-01
    z[7,6,5]  R2093     3.4282210469245911e-01
    z[7,6,5]  R2094     3.7020862102508545e-01
    z[7,6,5]  R2095     2.7709373831748962e-01
    z[7,6,5]  R2096     2.6857927441596985e-02
    z[7,6,5]  R2097     3.1723475456237793e-01
    z[7,6,5]  R2098     -2.6693260669708252e-01
    z[7,6,5]  R2099     -1.7569415271282196e-01
    z[7,6,5]  R2100     -2.7833628654479980e-01
    z[7,6,5]  R2101     -2.1191258728504181e-01
    z[7,6,5]  R2102     -1.5550585091114044e-01
    z[7,6,5]  R2103     3.7700343132019043e-01
    z[7,6,5]  R2104     2.4028272926807404e-01
    z[7,6,5]  R2105     2.4893839657306671e-01
    z[7,6,5]  R2106     4.6183583140373230e-01
    z[7,6,5]  R2107     4.0268638730049133e-01
    z[7,6,5]  R2108     -2.1071991324424744e-01
    z[7,6,5]  R2109     -5.5100526660680771e-02
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2000     -1
    z[7,6,6]  R2001     1
    z[7,6,6]  R2002     -4.6725422143936157e-02
    z[7,6,6]  R2003     4.9532783031463623e-01
    z[7,6,6]  R2004     -2.0872111618518829e-01
    z[7,6,6]  R2005     3.6020421981811523e-01
    z[7,6,6]  R2006     3.5573670268058777e-01
    z[7,6,6]  R2007     -1.2744718790054321e-01
    z[7,6,6]  R2008     5.9656377881765366e-02
    z[7,6,6]  R2009     3.6065650638192892e-03
    z[7,6,6]  R2010     4.1999436914920807e-02
    z[7,6,6]  R2011     -1.0937235504388809e-01
    z[7,6,6]  R2012     -3.0923649668693542e-01
    z[7,6,6]  R2013     -4.7745892405509949e-01
    z[7,6,6]  R2014     2.9163654893636703e-02
    z[7,6,6]  R2015     -4.1628414392471313e-01
    z[7,6,6]  R2016     1.6103953123092651e-01
    z[7,6,6]  R2017     -3.5062587261199951e-01
    z[7,6,6]  R2018     0.0421445369720459
    z[7,6,6]  R2019     -3.5927903652191162e-01
    z[7,6,6]  R2020     3.0636456608772278e-01
    z[7,6,6]  R2021     1.0050907731056213e-01
    z[7,6,6]  R2022     -3.2746991515159607e-01
    z[7,6,6]  R2023     -1.4449976384639740e-01
    z[7,6,6]  R2024     1.4703397452831268e-01
    z[7,6,6]  R2025     -1.5040592849254608e-01
    z[7,6,6]  R2026     0.413028359413147
    z[7,6,6]  R2027     -0.553170919418335
    z[7,6,6]  R2028     1.5998384356498718e-01
    z[7,6,6]  R2029     -1.6976815462112427e-01
    z[7,6,6]  R2030     -5.4460763931274414e-01
    z[7,6,6]  R2031     -5.5427354574203491e-01
    z[7,6,6]  R2032     -2.2574107348918915e-01
    z[7,6,6]  R2033     -5.4722303152084351e-01
    z[7,6,6]  R2034     -0.51659095287323
    z[7,6,6]  R2035     -2.5100201368331909e-01
    z[7,6,6]  R2036     -1.2728338129818439e-02
    z[7,6,6]  R2037     -5.2735541015863419e-02
    z[7,6,6]  R2038     -3.2122838497161865e-01
    z[7,6,6]  R2039     1.2394971400499344e-01
    z[7,6,6]  R2040     3.7009704113006592e-01
    z[7,6,6]  R2041     3.8607341051101685e-01
    z[7,6,6]  R2042     -2.4830827116966248e-01
    z[7,6,6]  R2043     -3.2108855247497559e-01
    z[7,6,6]  R2044     -3.9138159155845642e-01
    z[7,6,6]  R2045     3.0075541138648987e-01
    z[7,6,6]  R2046     4.0192052721977234e-02
    z[7,6,6]  R2047     -1.6422481834888458e-01
    z[7,6,6]  R2048     1.4844579994678497e-01
    z[7,6,6]  R2049     -1.5973339974880219e-01
    z[7,6,6]  R2050     -3.3040615916252136e-01
    z[7,6,6]  R2051     8.7868541479110718e-02
    z[7,6,6]  R2052     -3.6068413406610489e-02
    z[7,6,6]  R2053     -1.4106044173240662e-01
    z[7,6,6]  R2054     -3.2500657439231873e-01
    z[7,6,6]  R2055     -1.4947728812694550e-01
    z[7,6,6]  R2056     7.2512738406658173e-02
    z[7,6,6]  R2057     2.2392643988132477e-01
    z[7,6,6]  R2058     -4.3936377763748169e-01
    z[7,6,6]  R2059     -3.8094186782836914e-01
    z[7,6,6]  R2060     1.1625473387539387e-02
    z[7,6,6]  R2061     9.8391041159629822e-02
    z[7,6,6]  R2062     2.3691312968730927e-01
    z[7,6,6]  R2063     -1.8052671849727631e-01
    z[7,6,6]  R2064     -4.5531578361988068e-02
    z[7,6,6]  R2065     1.8536303937435150e-01
    z[7,6,6]  R2066     -2.7101499959826469e-02
    z[7,6,6]  R2067     7.9745732247829437e-02
    z[7,6,6]  R2068     1.6762834787368774e-01
    z[7,6,6]  R2069     2.4025343358516693e-01
    z[7,6,6]  R2070     2.4498908221721649e-01
    z[7,6,6]  R2071     2.8599247336387634e-01
    z[7,6,6]  R2072     -1.6993029415607452e-01
    z[7,6,6]  R2073     5.1385802030563354e-01
    z[7,6,6]  R2074     2.5195059180259705e-01
    z[7,6,6]  R2075     0.266657292842865
    z[7,6,6]  R2076     -1.8867613375186920e-01
    z[7,6,6]  R2077     -3.2001528888940811e-02
    z[7,6,6]  R2078     -1.8310065567493439e-01
    z[7,6,6]  R2079     0.506697416305542
    z[7,6,6]  R2080     3.5602548718452454e-01
    z[7,6,6]  R2081     4.8910453915596008e-02
    z[7,6,6]  R2082     -0.403319776058197
    z[7,6,6]  R2083     -4.0726795792579651e-02
    z[7,6,6]  R2084     2.2924545407295227e-01
    z[7,6,6]  R2085     -1.8716701865196228e-01
    z[7,6,6]  R2086     -1.5874285995960236e-01
    z[7,6,6]  R2087     1.9830964505672455e-01
    z[7,6,6]  R2088     -4.4789519160985947e-02
    z[7,6,6]  R2089     -1.8294534087181091e-01
    z[7,6,6]  R2090     -1.8529818952083588e-01
    z[7,6,6]  R2091     1.1554679274559021e-01
    z[7,6,6]  R2092     3.6919271945953369e-01
    z[7,6,6]  R2093     1.4193138480186462e-01
    z[7,6,6]  R2094     1.6270010173320770e-01
    z[7,6,6]  R2095     -6.5023888600990176e-04
    z[7,6,6]  R2096     2.6800441741943359e-01
    z[7,6,6]  R2097     -3.3488348126411438e-01
    z[7,6,6]  R2098     1.1048205941915512e-01
    z[7,6,6]  R2099     1.8190686404705048e-01
    z[7,6,6]  R2100     2.6113128662109375e-01
    z[7,6,6]  R2101     3.0068665742874146e-01
    z[7,6,6]  R2102     1.0309263318777084e-01
    z[7,6,6]  R2103     -9.4360075891017914e-02
    z[7,6,6]  R2104     1.9623020291328430e-01
    z[7,6,6]  R2105     3.2488524913787842e-02
    z[7,6,6]  R2106     -3.2493855804204941e-02
    z[7,6,6]  R2107     -9.7407236695289612e-02
    z[7,6,6]  R2108     -1.5290263295173645e-01
    z[7,6,6]  R2109     -1.7156034708023071e-01
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2110     -1
    z[7,8,0]  R2111     1
    z[7,8,0]  R2124     1.4462977647781372e-01
    z[7,8,0]  R2125     2.0282746851444244e-01
    z[7,8,0]  R2126     -1.4239031076431274e-01
    z[7,8,0]  R2127     -8.0109804868698120e-02
    z[7,8,0]  R2128     -2.0861518383026123e-01
    z[7,8,0]  R2129     1.8142579495906830e-01
    z[7,8,0]  R2130     1.0963388532400131e-01
    z[7,8,0]  R2131     -4.8393601179122925e-01
    z[7,8,0]  R2132     -3.7745830416679382e-01
    z[7,8,0]  R2133     -1.5982395410537720e-01
    z[7,8,0]  R2134     5.4731643199920654e-01
    z[7,8,0]  R2135     -2.8332433104515076e-01
    z[7,8,0]  R2136     1.8951942026615143e-01
    z[7,8,0]  R2137     2.0079214870929718e-01
    z[7,8,0]  R2138     5.3021436929702759e-01
    z[7,8,0]  R2139     -2.2666609287261963e-01
    z[7,8,0]  R2140     -3.4470555186271667e-01
    z[7,8,0]  R2141     1.7929136753082275e-01
    z[7,8,0]  R2142     4.1812822222709656e-01
    z[7,8,0]  R2143     2.3096819221973419e-01
    z[7,8,0]  R2144     3.1026995182037354e-01
    z[7,8,0]  R2145     1.9502638280391693e-01
    z[7,8,0]  R2146     -2.3145294189453125e-01
    z[7,8,0]  R2147     4.9859631806612015e-02
    z[7,8,0]  R2148     -2.3853557184338570e-02
    z[7,8,0]  R2149     -2.5242453813552856e-01
    z[7,8,0]  R2150     2.6620236039161682e-01
    z[7,8,0]  R2151     7.1300083398818970e-01
    z[7,8,0]  R2152     -3.1056925654411316e-01
    z[7,8,0]  R2153     -2.4116815626621246e-01
    z[7,8,0]  R2154     -6.1735503375530243e-02
    z[7,8,0]  R2155     3.5499048233032227e-01
    z[7,8,0]  R2156     -2.3529201745986938e-01
    z[7,8,0]  R2157     -4.5805446803569794e-02
    z[7,8,0]  R2158     -3.3786529302597046e-01
    z[7,8,0]  R2159     -1.2771472334861755e-01
    z[7,8,0]  R2160     7.2117978334426880e-01
    z[7,8,0]  R2161     2.2776730358600616e-01
    z[7,8,0]  R2162     2.8832095861434937e-01
    z[7,8,0]  R2163     -1.2953884899616241e-01
    z[7,8,0]  R2164     9.7091786563396454e-02
    z[7,8,0]  R2165     -0.0796702653169632
    z[7,8,0]  R2166     -1.6089361906051636e-01
    z[7,8,0]  R2167     1.7138876020908356e-01
    z[7,8,0]  R2168     -3.0284032225608826e-01
    z[7,8,0]  R2169     1.8827617168426514e-01
    z[7,8,0]  R2170     -3.8897427916526794e-01
    z[7,8,0]  R2171     -3.2350787520408630e-01
    z[7,8,0]  R2172     -1.8089754879474640e-01
    z[7,8,0]  R2173     -6.2212910503149033e-02
    z[7,8,0]  R2174     -5.4922342300415039e-02
    z[7,8,0]  R2175     2.1008875966072083e-01
    z[7,8,0]  R2176     -1.9150808453559875e-02
    z[7,8,0]  R2177     -1.3141886889934540e-01
    z[7,8,0]  R2178     -0.280888170003891
    z[7,8,0]  R2179     -3.2990834116935730e-01
    z[7,8,0]  R2180     4.2448371648788452e-02
    z[7,8,0]  R2181     2.3840151727199554e-01
    z[7,8,0]  R2182     4.2176750302314758e-01
    z[7,8,0]  R2183     7.9707928001880646e-02
    z[7,8,0]  R2184     2.2722578048706055e-01
    z[7,8,0]  R2185     2.6506033539772034e-01
    z[7,8,0]  R2186     -2.3064351081848145e-01
    z[7,8,0]  R2187     -1.8559268116950989e-01
    z[7,8,0]  R2188     2.2781016305088997e-02
    z[7,8,0]  R2189     -4.7762727737426758e-01
    z[7,8,0]  R2190     -5.0240868330001831e-01
    z[7,8,0]  R2191     -4.3745297193527222e-01
    z[7,8,0]  R2192     -2.7342742681503296e-01
    z[7,8,0]  R2193     -4.5025333762168884e-01
    z[7,8,0]  R2194     -0.0651671439409256
    z[7,8,0]  R2195     -3.8651326298713684e-01
    z[7,8,0]  R2196     -8.7483161687850952e-01
    z[7,8,0]  R2197     -1.0937790572643280e-01
    z[7,8,0]  R2198     -7.1644246578216553e-01
    z[7,8,0]  R2199     -7.8381127119064331e-01
    z[7,8,0]  R2200     -8.2541257143020630e-01
    z[7,8,0]  R2201     -8.2917296886444092e-01
    z[7,8,0]  R2202     -7.0350253582000732e-01
    z[7,8,0]  R2203     -7.1030479669570923e-01
    z[7,8,0]  R2204     7.0778125524520874e-01
    z[7,8,0]  R2205     3.0961731076240540e-01
    z[7,8,0]  R2206     5.5427330732345581e-01
    z[7,8,0]  R2207     5.3040701150894165e-01
    z[7,8,0]  R2208     6.3643324375152588e-01
    z[7,8,0]  R2209     3.0334493517875671e-01
    z[7,8,0]  R2210     1.4406631886959076e-01
    z[7,8,0]  R2211     4.1738396883010864e-01
    z[7,8,0]  R2212     3.3460852503776550e-01
    z[7,8,0]  R2213     5.0922924280166626e-01
    z[7,8,0]  R2214     0.789631187915802
    z[7,8,0]  R2215     0.835048258304596
    z[7,8,0]  R2216     0.459786057472229
    z[7,8,0]  R2217     6.5228879451751709e-01
    z[7,8,0]  R2218     5.4485547542572021e-01
    z[7,8,0]  R2219     0.624904215335846
    z[7,8,0]  R2220     7.1223413944244385e-01
    z[7,8,0]  R2221     4.7081285715103149e-01
    z[7,8,0]  R2222     5.9584714472293854e-02
    z[7,8,0]  R2223     3.8621027022600174e-02
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2112     -1
    z[7,8,1]  R2113     1
    z[7,8,1]  R2124     8.8997566699981689e-01
    z[7,8,1]  R2125     5.6347352266311646e-01
    z[7,8,1]  R2126     5.3149688243865967e-01
    z[7,8,1]  R2127     4.7394096851348877e-01
    z[7,8,1]  R2128     -8.6980652809143066e-01
    z[7,8,1]  R2129     4.5374700427055359e-01
    z[7,8,1]  R2130     -7.2401589155197144e-01
    z[7,8,1]  R2131     -0.854438841342926
    z[7,8,1]  R2132     -5.5981749296188354e-01
    z[7,8,1]  R2133     4.8178479075431824e-01
    z[7,8,1]  R2134     3.6600002646446228e-01
    z[7,8,1]  R2135     -0.652351438999176
    z[7,8,1]  R2136     1.9683641195297241e-01
    z[7,8,1]  R2137     -5.6298565864562988e-01
    z[7,8,1]  R2138     9.3209460377693176e-02
    z[7,8,1]  R2139     -3.4307649731636047e-01
    z[7,8,1]  R2140     -2.4836876988410950e-01
    z[7,8,1]  R2141     -8.3863925933837891e-01
    z[7,8,1]  R2142     -1.2238927185535431e-01
    z[7,8,1]  R2143     -7.0744502544403076e-01
    z[7,8,1]  R2144     2.8402090072631836e-01
    z[7,8,1]  R2145     6.2036657333374023e-01
    z[7,8,1]  R2146     -5.9176814556121826e-01
    z[7,8,1]  R2147     -6.9369810819625854e-01
    z[7,8,1]  R2148     5.0723671913146973e-01
    z[7,8,1]  R2149     -5.3851896524429321e-01
    z[7,8,1]  R2150     6.1436223983764648e-01
    z[7,8,1]  R2151     5.4348480701446533e-01
    z[7,8,1]  R2152     -4.8074319958686829e-01
    z[7,8,1]  R2153     -4.0413281321525574e-01
    z[7,8,1]  R2154     -5.2071684598922729e-01
    z[7,8,1]  R2155     5.8704417943954468e-01
    z[7,8,1]  R2156     -4.6282440423965454e-01
    z[7,8,1]  R2157     6.0084664821624756e-01
    z[7,8,1]  R2158     -0.56495201587677
    z[7,8,1]  R2159     -4.6176734566688538e-01
    z[7,8,1]  R2160     4.9946096539497375e-01
    z[7,8,1]  R2161     6.1561310291290283e-01
    z[7,8,1]  R2162     -4.0816673636436462e-01
    z[7,8,1]  R2163     -4.3503656983375549e-01
    z[7,8,1]  R2164     6.2327593564987183e-01
    z[7,8,1]  R2165     7.1865928173065186e-01
    z[7,8,1]  R2166     -7.5535839796066284e-01
    z[7,8,1]  R2167     -5.4526019096374512e-01
    z[7,8,1]  R2168     -0.555756151676178
    z[7,8,1]  R2169     1.3988788425922394e-01
    z[7,8,1]  R2170     -6.5123164653778076e-01
    z[7,8,1]  R2171     -4.4593289494514465e-01
    z[7,8,1]  R2172     -4.6819174289703369e-01
    z[7,8,1]  R2173     -5.4919254779815674e-01
    z[7,8,1]  R2174     -8.0863159894943237e-01
    z[7,8,1]  R2175     -9.4244188070297241e-01
    z[7,8,1]  R2176     -7.6257109642028809e-01
    z[7,8,1]  R2177     -7.5732493400573730e-01
    z[7,8,1]  R2178     -7.1655815839767456e-01
    z[7,8,1]  R2179     -5.2059888839721680e-01
    z[7,8,1]  R2180     -7.0152491331100464e-01
    z[7,8,1]  R2181     -5.9501367807388306e-01
    z[7,8,1]  R2182     3.2451578974723816e-01
    z[7,8,1]  R2183     -2.0547662675380707e-01
    z[7,8,1]  R2184     5.9226512908935547e-01
    z[7,8,1]  R2185     -4.9956339597702026e-01
    z[7,8,1]  R2186     -5.6142532825469971e-01
    z[7,8,1]  R2187     -4.3255776166915894e-01
    z[7,8,1]  R2188     -4.2222142219543457e-01
    z[7,8,1]  R2189     7.2138541936874390e-01
    z[7,8,1]  R2190     7.3265445232391357e-01
    z[7,8,1]  R2191     0.735712468624115
    z[7,8,1]  R2192     8.1659460067749023e-01
    z[7,8,1]  R2193     6.6647243499755859e-01
    z[7,8,1]  R2194     -3.2979834079742432e-01
    z[7,8,1]  R2195     -1.1426496505737305e-01
    z[7,8,1]  R2196     -0.0662216767668724
    z[7,8,1]  R2197     -3.3748188614845276e-01
    z[7,8,1]  R2198     -4.0812242031097412e-01
    z[7,8,1]  R2199     -5.6595962494611740e-02
    z[7,8,1]  R2200     -5.6493185460567474e-02
    z[7,8,1]  R2201     1.6281509399414062e-01
    z[7,8,1]  R2202     -1.4227128028869629e-01
    z[7,8,1]  R2203     -2.3268491029739380e-01
    z[7,8,1]  R2204     4.0143576264381409e-01
    z[7,8,1]  R2205     -5.1193749904632568e-01
    z[7,8,1]  R2206     6.4949011802673340e-01
    z[7,8,1]  R2207     6.8918168544769287e-01
    z[7,8,1]  R2208     2.4982081353664398e-01
    z[7,8,1]  R2209     3.2470539212226868e-01
    z[7,8,1]  R2210     7.5429028272628784e-01
    z[7,8,1]  R2211     4.4429680705070496e-01
    z[7,8,1]  R2212     4.2257469892501831e-01
    z[7,8,1]  R2213     4.1837745904922485e-01
    z[7,8,1]  R2214     4.1784796863794327e-02
    z[7,8,1]  R2215     -2.0650871098041534e-01
    z[7,8,1]  R2216     -3.6184465885162354e-01
    z[7,8,1]  R2217     -3.6312100291252136e-01
    z[7,8,1]  R2218     2.7227425575256348e-01
    z[7,8,1]  R2219     2.6621243357658386e-01
    z[7,8,1]  R2220     -3.8219049572944641e-01
    z[7,8,1]  R2221     -2.7316927909851074e-01
    z[7,8,1]  R2222     6.4165496826171875e-01
    z[7,8,1]  R2223     8.5204273462295532e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2114     -1
    z[7,8,2]  R2115     1
    z[7,8,2]  R2124     1.5626215934753418e-01
    z[7,8,2]  R2125     1.4070723950862885e-01
    z[7,8,2]  R2126     6.9898366928100586e-02
    z[7,8,2]  R2127     -5.5283259600400925e-02
    z[7,8,2]  R2128     0.0860406756401062
    z[7,8,2]  R2129     5.0194729119539261e-02
    z[7,8,2]  R2130     5.7102650403976440e-01
    z[7,8,2]  R2131     -1.7140921950340271e-01
    z[7,8,2]  R2132     5.3867197036743164e-01
    z[7,8,2]  R2133     -1.0154915601015091e-01
    z[7,8,2]  R2134     9.3037039041519165e-02
    z[7,8,2]  R2135     8.0166503787040710e-02
    z[7,8,2]  R2136     -0.686255156993866
    z[7,8,2]  R2137     3.1873509287834167e-01
    z[7,8,2]  R2138     -2.4452788755297661e-02
    z[7,8,2]  R2139     3.0223757028579712e-01
    z[7,8,2]  R2140     -2.4538283050060272e-01
    z[7,8,2]  R2141     -1.0774039663374424e-02
    z[7,8,2]  R2142     3.8475415110588074e-01
    z[7,8,2]  R2143     -2.4036644399166107e-01
    z[7,8,2]  R2144     1.6755943000316620e-01
    z[7,8,2]  R2145     -6.1562073230743408e-01
    z[7,8,2]  R2146     1.2368278205394745e-01
    z[7,8,2]  R2147     -3.2838433980941772e-02
    z[7,8,2]  R2148     -5.2198302745819092e-01
    z[7,8,2]  R2149     2.7007073163986206e-01
    z[7,8,2]  R2150     3.4253621101379395e-01
    z[7,8,2]  R2151     1.1106052435934544e-02
    z[7,8,2]  R2152     -6.6184081137180328e-02
    z[7,8,2]  R2153     -2.2363376617431641e-01
    z[7,8,2]  R2154     6.8158376216888428e-01
    z[7,8,2]  R2155     2.2800515592098236e-01
    z[7,8,2]  R2156     4.6837532520294189e-01
    z[7,8,2]  R2157     -2.4548043310642242e-01
    z[7,8,2]  R2158     3.2230582088232040e-02
    z[7,8,2]  R2159     3.8513442873954773e-01
    z[7,8,2]  R2160     1.8799996376037598e-01
    z[7,8,2]  R2161     -2.9129263758659363e-01
    z[7,8,2]  R2162     4.2210742831230164e-01
    z[7,8,2]  R2163     5.6851077079772949e-01
    z[7,8,2]  R2164     -6.6060012578964233e-01
    z[7,8,2]  R2165     1.0846129059791565e-01
    z[7,8,2]  R2166     -1.4594377577304840e-01
    z[7,8,2]  R2167     6.9918280839920044e-01
    z[7,8,2]  R2168     -9.2435348778963089e-03
    z[7,8,2]  R2169     -2.3108625411987305e-01
    z[7,8,2]  R2170     -1.9133625924587250e-01
    z[7,8,2]  R2171     2.5521764159202576e-01
    z[7,8,2]  R2172     4.5094007253646851e-01
    z[7,8,2]  R2173     3.7741002440452576e-01
    z[7,8,2]  R2174     1.5772137045860291e-01
    z[7,8,2]  R2175     0.121115542948246
    z[7,8,2]  R2176     0.227840393781662
    z[7,8,2]  R2177     -0.0860668197274208
    z[7,8,2]  R2178     1.8881501257419586e-01
    z[7,8,2]  R2179     5.2971524000167847e-01
    z[7,8,2]  R2180     3.8336157798767090e-02
    z[7,8,2]  R2181     5.1168650388717651e-01
    z[7,8,2]  R2182     -6.2997028231620789e-02
    z[7,8,2]  R2183     0.702738344669342
    z[7,8,2]  R2184     -8.3330802619457245e-02
    z[7,8,2]  R2185     5.5563312768936157e-01
    z[7,8,2]  R2186     1.6081599891185760e-01
    z[7,8,2]  R2187     8.1674647331237793e-01
    z[7,8,2]  R2188     6.7043161392211914e-01
    z[7,8,2]  R2189     -2.8460618853569031e-01
    z[7,8,2]  R2190     1.6050188243389130e-01
    z[7,8,2]  R2191     -1.4110109210014343e-01
    z[7,8,2]  R2192     1.0098636895418167e-01
    z[7,8,2]  R2193     2.0625907927751541e-02
    z[7,8,2]  R2194     1.2959934771060944e-01
    z[7,8,2]  R2195     -1.3875004649162292e-01
    z[7,8,2]  R2196     -1.8310436606407166e-01
    z[7,8,2]  R2197     -6.7341946065425873e-02
    z[7,8,2]  R2198     -3.3988818526268005e-01
    z[7,8,2]  R2199     5.0396567583084106e-01
    z[7,8,2]  R2200     1.8700838088989258e-01
    z[7,8,2]  R2201     0.0691818818449974
    z[7,8,2]  R2202     4.2266142368316650e-01
    z[7,8,2]  R2203     4.0819045901298523e-01
    z[7,8,2]  R2204     4.3854832649230957e-01
    z[7,8,2]  R2205     3.8465568423271179e-01
    z[7,8,2]  R2206     -2.6800140738487244e-01
    z[7,8,2]  R2207     -1.2427277117967606e-01
    z[7,8,2]  R2208     2.0401073992252350e-01
    z[7,8,2]  R2209     5.3101760149002075e-01
    z[7,8,2]  R2210     -1.7486673593521118e-01
    z[7,8,2]  R2211     3.3118656277656555e-01
    z[7,8,2]  R2212     -5.0349120050668716e-02
    z[7,8,2]  R2213     1.7553143203258514e-01
    z[7,8,2]  R2214     -2.8456050157546997e-01
    z[7,8,2]  R2215     2.1536806225776672e-01
    z[7,8,2]  R2216     -6.1289733648300171e-01
    z[7,8,2]  R2217     -4.1806069016456604e-01
    z[7,8,2]  R2218     2.4455563724040985e-01
    z[7,8,2]  R2219     -3.7168264389038086e-01
    z[7,8,2]  R2220     6.2742471694946289e-02
    z[7,8,2]  R2221     -3.4416135400533676e-02
    z[7,8,2]  R2222     2.1319410204887390e-01
    z[7,8,2]  R2223     -2.3614510893821716e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2116     -1
    z[7,8,3]  R2117     1
    z[7,8,3]  R2124     -1.9977492094039917e-01
    z[7,8,3]  R2125     -4.5930573344230652e-01
    z[7,8,3]  R2126     -7.5363588333129883e-01
    z[7,8,3]  R2127     -5.6296902894973755e-01
    z[7,8,3]  R2128     -2.4565504863858223e-02
    z[7,8,3]  R2129     -5.3719317913055420e-01
    z[7,8,3]  R2130     -2.0710441470146179e-01
    z[7,8,3]  R2131     -2.1754177287220955e-02
    z[7,8,3]  R2132     -1.8905088305473328e-01
    z[7,8,3]  R2133     -2.4509520828723907e-01
    z[7,8,3]  R2134     -2.9720559716224670e-01
    z[7,8,3]  R2135     -4.1779360175132751e-01
    z[7,8,3]  R2136     -0.559943675994873
    z[7,8,3]  R2137     3.1916698813438416e-01
    z[7,8,3]  R2138     -7.5362426042556763e-01
    z[7,8,3]  R2139     7.7795481681823730e-01
    z[7,8,3]  R2140     8.0503243207931519e-01
    z[7,8,3]  R2141     3.2476234436035156e-01
    z[7,8,3]  R2142     -4.7026541829109192e-01
    z[7,8,3]  R2143     5.5571585893630981e-01
    z[7,8,3]  R2144     -6.1917799711227417e-01
    z[7,8,3]  R2145     6.9842688739299774e-02
    z[7,8,3]  R2146     -5.1531377248466015e-03
    z[7,8,3]  R2147     5.9765160083770752e-01
    z[7,8,3]  R2148     -4.1451793909072876e-01
    z[7,8,3]  R2149     1.8008767068386078e-01
    z[7,8,3]  R2150     -3.8358801603317261e-01
    z[7,8,3]  R2151     0.267170250415802
    z[7,8,3]  R2152     4.3227684497833252e-01
    z[7,8,3]  R2153     5.9382396936416626e-01
    z[7,8,3]  R2154     -4.5205873250961304e-01
    z[7,8,3]  R2155     -3.3212760090827942e-01
    z[7,8,3]  R2156     1.8679212033748627e-01
    z[7,8,3]  R2157     -2.9897835850715637e-01
    z[7,8,3]  R2158     2.3277139663696289e-01
    z[7,8,3]  R2159     5.3183770179748535e-01
    z[7,8,3]  R2160     -1.4117913320660591e-02
    z[7,8,3]  R2161     -1.3899800181388855e-01
    z[7,8,3]  R2162     -4.4124302268028259e-01
    z[7,8,3]  R2163     4.1658997535705566e-01
    z[7,8,3]  R2164     -2.7856573462486267e-01
    z[7,8,3]  R2165     -4.0980812907218933e-01
    z[7,8,3]  R2166     2.2978819906711578e-01
    z[7,8,3]  R2167     1.8695114180445671e-02
    z[7,8,3]  R2168     4.2316564917564392e-01
    z[7,8,3]  R2169     -9.2306923866271973e-01
    z[7,8,3]  R2170     3.0637022852897644e-01
    z[7,8,3]  R2171     6.0286504030227661e-01
    z[7,8,3]  R2172     -2.6251927018165588e-01
    z[7,8,3]  R2173     0.3237284719944
    z[7,8,3]  R2174     4.8264548182487488e-01
    z[7,8,3]  R2175     -6.8123318254947662e-02
    z[7,8,3]  R2176     -2.4848574399948120e-01
    z[7,8,3]  R2177     -0.09919423609972
    z[7,8,3]  R2178     6.9111935794353485e-02
    z[7,8,3]  R2179     3.1444087624549866e-01
    z[7,8,3]  R2180     2.7635595202445984e-01
    z[7,8,3]  R2181     1.7880478873848915e-02
    z[7,8,3]  R2182     -5.5708044767379761e-01
    z[7,8,3]  R2183     -4.9197328090667725e-01
    z[7,8,3]  R2184     -6.1810475587844849e-01
    z[7,8,3]  R2185     -2.9371315240859985e-01
    z[7,8,3]  R2186     3.5752159357070923e-01
    z[7,8,3]  R2187     2.3813307285308838e-01
    z[7,8,3]  R2188     -2.2278147935867310e-01
    z[7,8,3]  R2189     3.4698012471199036e-01
    z[7,8,3]  R2190     1.5617586672306061e-01
    z[7,8,3]  R2191     4.3177241086959839e-01
    z[7,8,3]  R2192     3.2639807462692261e-01
    z[7,8,3]  R2193     -0.044993806630373
    z[7,8,3]  R2194     2.7789419889450073e-01
    z[7,8,3]  R2195     8.6106359958648682e-02
    z[7,8,3]  R2196     3.5527431964874268e-01
    z[7,8,3]  R2197     -2.3907026648521423e-01
    z[7,8,3]  R2198     2.6862043142318726e-01
    z[7,8,3]  R2199     0.00202555931173265
    z[7,8,3]  R2200     -2.9539713263511658e-01
    z[7,8,3]  R2201     4.6744119375944138e-02
    z[7,8,3]  R2202     -2.7432683110237122e-01
    z[7,8,3]  R2203     -4.2522680759429932e-01
    z[7,8,3]  R2204     -1.9700820744037628e-01
    z[7,8,3]  R2205     -4.4549080729484558e-01
    z[7,8,3]  R2206     2.7383938431739807e-01
    z[7,8,3]  R2207     1.9027142226696014e-01
    z[7,8,3]  R2208     -4.0646929293870926e-02
    z[7,8,3]  R2209     6.2380152940750122e-01
    z[7,8,3]  R2210     -5.6583017110824585e-01
    z[7,8,3]  R2211     5.0485078245401382e-02
    z[7,8,3]  R2212     3.8308575749397278e-01
    z[7,8,3]  R2213     -6.3338160514831543e-02
    z[7,8,3]  R2214     2.5125262141227722e-01
    z[7,8,3]  R2215     8.3592817187309265e-02
    z[7,8,3]  R2216     -4.9714568257331848e-01
    z[7,8,3]  R2217     -5.9920862317085266e-02
    z[7,8,3]  R2218     1.8090160191059113e-01
    z[7,8,3]  R2219     -2.1851888298988342e-01
    z[7,8,3]  R2220     -0.518419623374939
    z[7,8,3]  R2221     -7.6481819152832031e-01
    z[7,8,3]  R2222     0.572091817855835
    z[7,8,3]  R2223     7.3339510709047318e-03
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2118     -1
    z[7,8,4]  R2119     1
    z[7,8,4]  R2124     -1.5166673064231873e-01
    z[7,8,4]  R2125     -3.4555739164352417e-01
    z[7,8,4]  R2126     -9.1287478804588318e-02
    z[7,8,4]  R2127     -5.6490135192871094e-01
    z[7,8,4]  R2128     -1.1244915425777435e-01
    z[7,8,4]  R2129     -6.0637700557708740e-01
    z[7,8,4]  R2130     -2.2839431464672089e-01
    z[7,8,4]  R2131     -7.4578397907316685e-03
    z[7,8,4]  R2132     1.5477222204208374e-01
    z[7,8,4]  R2133     -7.9120141267776489e-01
    z[7,8,4]  R2134     0.379867285490036
    z[7,8,4]  R2135     -2.8409931063652039e-01
    z[7,8,4]  R2136     -1.5021848678588867e-01
    z[7,8,4]  R2137     0.51568603515625
    z[7,8,4]  R2138     3.2848662137985229e-01
    z[7,8,4]  R2139     1.1617516167461872e-02
    z[7,8,4]  R2140     -6.8178132176399231e-02
    z[7,8,4]  R2141     1.7207933962345123e-01
    z[7,8,4]  R2142     5.8379912376403809e-01
    z[7,8,4]  R2143     -1.2048694491386414e-01
    z[7,8,4]  R2144     -1.7973898351192474e-01
    z[7,8,4]  R2145     3.8831412792205811e-02
    z[7,8,4]  R2146     6.8202883005142212e-02
    z[7,8,4]  R2147     3.5923016071319580e-01
    z[7,8,4]  R2148     3.5152861475944519e-01
    z[7,8,4]  R2149     -1.1418701708316803e-01
    z[7,8,4]  R2150     3.3009532094001770e-01
    z[7,8,4]  R2151     -0.020780049264431
    z[7,8,4]  R2152     -2.5901803374290466e-01
    z[7,8,4]  R2153     1.0997701436281204e-01
    z[7,8,4]  R2154     -7.1648612618446350e-02
    z[7,8,4]  R2155     2.2435715794563293e-01
    z[7,8,4]  R2156     -1.0111869871616364e-01
    z[7,8,4]  R2157     6.5114194154739380e-01
    z[7,8,4]  R2158     7.0492070913314819e-01
    z[7,8,4]  R2159     5.3112041950225830e-01
    z[7,8,4]  R2160     -3.9135057479143143e-02
    z[7,8,4]  R2161     6.6909164190292358e-01
    z[7,8,4]  R2162     4.3342703580856323e-01
    z[7,8,4]  R2163     1.9511634111404419e-01
    z[7,8,4]  R2164     5.6614045053720474e-02
    z[7,8,4]  R2165     -3.3648470044136047e-01
    z[7,8,4]  R2166     -3.3892503380775452e-01
    z[7,8,4]  R2167     1.7174851894378662e-01
    z[7,8,4]  R2168     5.2391719818115234e-01
    z[7,8,4]  R2169     -5.4748533293604851e-03
    z[7,8,4]  R2170     5.0637274980545044e-01
    z[7,8,4]  R2171     -9.4249770045280457e-02
    z[7,8,4]  R2172     -3.7535166740417480e-01
    z[7,8,4]  R2173     5.7516556978225708e-01
    z[7,8,4]  R2174     -2.4371746182441711e-01
    z[7,8,4]  R2175     -0.0630812719464302
    z[7,8,4]  R2176     -1.5615428984165192e-01
    z[7,8,4]  R2177     -4.1815164685249329e-01
    z[7,8,4]  R2178     5.6889444589614868e-01
    z[7,8,4]  R2179     4.3261536955833435e-01
    z[7,8,4]  R2180     4.4233259558677673e-01
    z[7,8,4]  R2181     3.8211050629615784e-01
    z[7,8,4]  R2182     4.0350979566574097e-01
    z[7,8,4]  R2183     2.5373873114585876e-01
    z[7,8,4]  R2184     2.3028384149074554e-01
    z[7,8,4]  R2185     4.7659239172935486e-01
    z[7,8,4]  R2186     4.1253918409347534e-01
    z[7,8,4]  R2187     -3.1321745365858078e-02
    z[7,8,4]  R2188     4.2325553297996521e-01
    z[7,8,4]  R2189     -2.1023072768002748e-03
    z[7,8,4]  R2190     1.9366234540939331e-01
    z[7,8,4]  R2191     4.8675616271793842e-03
    z[7,8,4]  R2192     2.8165090084075928e-01
    z[7,8,4]  R2193     1.6946977376937866e-01
    z[7,8,4]  R2194     -1.3234589993953705e-01
    z[7,8,4]  R2195     -7.7655291557312012e-01
    z[7,8,4]  R2196     -1.2535287439823151e-01
    z[7,8,4]  R2197     2.5612282752990723e-01
    z[7,8,4]  R2198     1.5100137889385223e-01
    z[7,8,4]  R2199     -3.5049033164978027e-01
    z[7,8,4]  R2200     -2.7637195587158203e-01
    z[7,8,4]  R2201     -4.8712566494941711e-01
    z[7,8,4]  R2202     2.1780742332339287e-02
    z[7,8,4]  R2203     7.4842788279056549e-02
    z[7,8,4]  R2204     -0.0647103488445282
    z[7,8,4]  R2205     -1.8469931185245514e-01
    z[7,8,4]  R2206     -2.3780560493469238e-01
    z[7,8,4]  R2207     -3.2354512810707092e-01
    z[7,8,4]  R2208     -6.7800402641296387e-01
    z[7,8,4]  R2209     1.6613423824310303e-01
    z[7,8,4]  R2210     -2.0452244579792023e-01
    z[7,8,4]  R2211     4.9505016207695007e-01
    z[7,8,4]  R2212     1.1797765642404556e-01
    z[7,8,4]  R2213     6.3076001405715942e-01
    z[7,8,4]  R2214     4.1038030385971069e-01
    z[7,8,4]  R2215     -7.8159511089324951e-02
    z[7,8,4]  R2216     2.5209732353687286e-02
    z[7,8,4]  R2217     -8.7192952632904053e-02
    z[7,8,4]  R2218     1.4575250446796417e-01
    z[7,8,4]  R2219     -4.7126278281211853e-02
    z[7,8,4]  R2220     1.8223161995410919e-01
    z[7,8,4]  R2221     1.9964620471000671e-01
    z[7,8,4]  R2222     2.1644271910190582e-01
    z[7,8,4]  R2223     1.6444487869739532e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2120     -1
    z[7,8,5]  R2121     1
    z[7,8,5]  R2124     -3.1226858496665955e-01
    z[7,8,5]  R2125     2.1409997344017029e-01
    z[7,8,5]  R2126     -2.6923105120658875e-01
    z[7,8,5]  R2127     1.0556698776781559e-02
    z[7,8,5]  R2128     -2.2960084676742554e-01
    z[7,8,5]  R2129     -2.9354125261306763e-01
    z[7,8,5]  R2130     1.9772459566593170e-01
    z[7,8,5]  R2131     7.6270140707492828e-02
    z[7,8,5]  R2132     -0.438752144575119
    z[7,8,5]  R2133     1.8437439203262329e-01
    z[7,8,5]  R2134     0.479140043258667
    z[7,8,5]  R2135     -6.7136198282241821e-02
    z[7,8,5]  R2136     3.4269323945045471e-01
    z[7,8,5]  R2137     6.7509203217923641e-03
    z[7,8,5]  R2138     8.8318727910518646e-02
    z[7,8,5]  R2139     0.106237031519413
    z[7,8,5]  R2140     -3.2369217276573181e-01
    z[7,8,5]  R2141     -1.6108108684420586e-02
    z[7,8,5]  R2142     7.9521842300891876e-02
    z[7,8,5]  R2143     2.3443512618541718e-01
    z[7,8,5]  R2144     5.2159792184829712e-01
    z[7,8,5]  R2145     4.1334626078605652e-01
    z[7,8,5]  R2146     -7.4474519491195679e-01
    z[7,8,5]  R2147     7.9768463969230652e-02
    z[7,8,5]  R2148     -6.0710810124874115e-02
    z[7,8,5]  R2149     -4.7103354334831238e-01
    z[7,8,5]  R2150     3.9072573184967041e-01
    z[7,8,5]  R2151     3.0902734398841858e-01
    z[7,8,5]  R2152     -3.4278473258018494e-01
    z[7,8,5]  R2153     -2.3782655596733093e-01
    z[7,8,5]  R2154     6.0546682216227055e-03
    z[7,8,5]  R2155     -1.3144052028656006e-01
    z[7,8,5]  R2156     -4.4617635011672974e-01
    z[7,8,5]  R2157     1.5767388045787811e-02
    z[7,8,5]  R2158     -1.1991579830646515e-01
    z[7,8,5]  R2159     -2.3325958847999573e-01
    z[7,8,5]  R2160     3.0029314756393433e-01
    z[7,8,5]  R2161     -4.3859221041202545e-02
    z[7,8,5]  R2162     -2.2928142547607422e-01
    z[7,8,5]  R2163     3.3179539442062378e-01
    z[7,8,5]  R2164     -1.5246884524822235e-01
    z[7,8,5]  R2165     2.8487738966941833e-01
    z[7,8,5]  R2166     -2.4778003990650177e-01
    z[7,8,5]  R2167     -2.5329765677452087e-01
    z[7,8,5]  R2168     -3.7968876957893372e-01
    z[7,8,5]  R2169     1.1191966384649277e-01
    z[7,8,5]  R2170     -1.2519817054271698e-01
    z[7,8,5]  R2171     -4.8322504758834839e-01
    z[7,8,5]  R2172     -4.7513374686241150e-01
    z[7,8,5]  R2173     3.2976108789443970e-01
    z[7,8,5]  R2174     1.5676942467689514e-01
    z[7,8,5]  R2175     -1.5645761787891388e-01
    z[7,8,5]  R2176     -4.1767066717147827e-01
    z[7,8,5]  R2177     -0.441301167011261
    z[7,8,5]  R2178     1.9575420022010803e-01
    z[7,8,5]  R2179     -5.8023486286401749e-02
    z[7,8,5]  R2180     -1.9879633188247681e-01
    z[7,8,5]  R2181     1.8935534358024597e-01
    z[7,8,5]  R2182     4.8942747712135315e-01
    z[7,8,5]  R2183     -3.7614226341247559e-01
    z[7,8,5]  R2184     0.315332293510437
    z[7,8,5]  R2185     -1.5954193472862244e-01
    z[7,8,5]  R2186     -0.552865207195282
    z[7,8,5]  R2187     0.139020174741745
    z[7,8,5]  R2188     3.7712097167968750e-01
    z[7,8,5]  R2189     -2.0908264815807343e-01
    z[7,8,5]  R2190     -3.0829685926437378e-01
    z[7,8,5]  R2191     -5.7268466800451279e-02
    z[7,8,5]  R2192     -4.8269700258970261e-02
    z[7,8,5]  R2193     -4.9002546072006226e-01
    z[7,8,5]  R2194     -8.0316364765167236e-01
    z[7,8,5]  R2195     8.3404947072267532e-03
    z[7,8,5]  R2196     1.0405653715133667e-01
    z[7,8,5]  R2197     3.6442485451698303e-01
    z[7,8,5]  R2198     -1.1600332707166672e-01
    z[7,8,5]  R2199     1.0517539456486702e-02
    z[7,8,5]  R2200     1.3749845325946808e-01
    z[7,8,5]  R2201     1.0967095941305161e-01
    z[7,8,5]  R2202     -7.9711824655532837e-02
    z[7,8,5]  R2203     2.2350908815860748e-01
    z[7,8,5]  R2204     0.320212721824646
    z[7,8,5]  R2205     2.7429682016372681e-01
    z[7,8,5]  R2206     2.4613082408905029e-01
    z[7,8,5]  R2207     2.1101389080286026e-02
    z[7,8,5]  R2208     4.2020749300718307e-02
    z[7,8,5]  R2209     -0.0749799907207489
    z[7,8,5]  R2210     1.3308162987232208e-01
    z[7,8,5]  R2211     5.0079214572906494e-01
    z[7,8,5]  R2212     4.7471746802330017e-01
    z[7,8,5]  R2213     2.4731396138668060e-01
    z[7,8,5]  R2214     -2.0713052153587341e-01
    z[7,8,5]  R2215     -3.2994800806045532e-01
    z[7,8,5]  R2216     1.1634192615747452e-01
    z[7,8,5]  R2217     -9.8115660250186920e-02
    z[7,8,5]  R2218     4.3850308656692505e-01
    z[7,8,5]  R2219     5.2142363786697388e-01
    z[7,8,5]  R2220     -1.7224879562854767e-01
    z[7,8,5]  R2221     1.4397594332695007e-01
    z[7,8,5]  R2222     -1.7490822076797485e-01
    z[7,8,5]  R2223     -3.5582467913627625e-01
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2122     -1
    z[7,8,6]  R2123     1
    z[7,8,6]  R2124     -4.6725422143936157e-02
    z[7,8,6]  R2125     4.9532783031463623e-01
    z[7,8,6]  R2126     -2.0872111618518829e-01
    z[7,8,6]  R2127     3.6020421981811523e-01
    z[7,8,6]  R2128     3.5573670268058777e-01
    z[7,8,6]  R2129     -1.2744718790054321e-01
    z[7,8,6]  R2130     5.9656377881765366e-02
    z[7,8,6]  R2131     3.6065650638192892e-03
    z[7,8,6]  R2132     4.1999436914920807e-02
    z[7,8,6]  R2133     -1.0937235504388809e-01
    z[7,8,6]  R2134     -3.0923649668693542e-01
    z[7,8,6]  R2135     -4.7745892405509949e-01
    z[7,8,6]  R2136     2.9163654893636703e-02
    z[7,8,6]  R2137     -4.1628414392471313e-01
    z[7,8,6]  R2138     1.6103953123092651e-01
    z[7,8,6]  R2139     -3.5062587261199951e-01
    z[7,8,6]  R2140     0.0421445369720459
    z[7,8,6]  R2141     -3.5927903652191162e-01
    z[7,8,6]  R2142     3.0636456608772278e-01
    z[7,8,6]  R2143     1.0050907731056213e-01
    z[7,8,6]  R2144     -3.2746991515159607e-01
    z[7,8,6]  R2145     -1.4449976384639740e-01
    z[7,8,6]  R2146     1.4703397452831268e-01
    z[7,8,6]  R2147     -1.5040592849254608e-01
    z[7,8,6]  R2148     0.413028359413147
    z[7,8,6]  R2149     -0.553170919418335
    z[7,8,6]  R2150     1.5998384356498718e-01
    z[7,8,6]  R2151     -1.6976815462112427e-01
    z[7,8,6]  R2152     -5.4460763931274414e-01
    z[7,8,6]  R2153     -5.5427354574203491e-01
    z[7,8,6]  R2154     -2.2574107348918915e-01
    z[7,8,6]  R2155     -5.4722303152084351e-01
    z[7,8,6]  R2156     -0.51659095287323
    z[7,8,6]  R2157     -2.5100201368331909e-01
    z[7,8,6]  R2158     -1.2728338129818439e-02
    z[7,8,6]  R2159     -5.2735541015863419e-02
    z[7,8,6]  R2160     -3.2122838497161865e-01
    z[7,8,6]  R2161     1.2394971400499344e-01
    z[7,8,6]  R2162     3.7009704113006592e-01
    z[7,8,6]  R2163     3.8607341051101685e-01
    z[7,8,6]  R2164     -2.4830827116966248e-01
    z[7,8,6]  R2165     -3.2108855247497559e-01
    z[7,8,6]  R2166     -3.9138159155845642e-01
    z[7,8,6]  R2167     3.0075541138648987e-01
    z[7,8,6]  R2168     4.0192052721977234e-02
    z[7,8,6]  R2169     -1.6422481834888458e-01
    z[7,8,6]  R2170     1.4844579994678497e-01
    z[7,8,6]  R2171     -1.5973339974880219e-01
    z[7,8,6]  R2172     -3.3040615916252136e-01
    z[7,8,6]  R2173     8.7868541479110718e-02
    z[7,8,6]  R2174     -3.6068413406610489e-02
    z[7,8,6]  R2175     -1.4106044173240662e-01
    z[7,8,6]  R2176     -3.2500657439231873e-01
    z[7,8,6]  R2177     -1.4947728812694550e-01
    z[7,8,6]  R2178     7.2512738406658173e-02
    z[7,8,6]  R2179     2.2392643988132477e-01
    z[7,8,6]  R2180     -4.3936377763748169e-01
    z[7,8,6]  R2181     -3.8094186782836914e-01
    z[7,8,6]  R2182     1.1625473387539387e-02
    z[7,8,6]  R2183     9.8391041159629822e-02
    z[7,8,6]  R2184     2.3691312968730927e-01
    z[7,8,6]  R2185     -1.8052671849727631e-01
    z[7,8,6]  R2186     -4.5531578361988068e-02
    z[7,8,6]  R2187     1.8536303937435150e-01
    z[7,8,6]  R2188     -2.7101499959826469e-02
    z[7,8,6]  R2189     7.9745732247829437e-02
    z[7,8,6]  R2190     1.6762834787368774e-01
    z[7,8,6]  R2191     2.4025343358516693e-01
    z[7,8,6]  R2192     2.4498908221721649e-01
    z[7,8,6]  R2193     2.8599247336387634e-01
    z[7,8,6]  R2194     3.6107870936393738e-01
    z[7,8,6]  R2195     4.5583018660545349e-01
    z[7,8,6]  R2196     2.0975235104560852e-01
    z[7,8,6]  R2197     7.8361243009567261e-01
    z[7,8,6]  R2198     -3.1017291545867920e-01
    z[7,8,6]  R2199     7.4143260717391968e-02
    z[7,8,6]  R2200     3.1302359700202942e-01
    z[7,8,6]  R2201     1.7225943505764008e-01
    z[7,8,6]  R2202     4.7340974211692810e-01
    z[7,8,6]  R2203     1.9577975571155548e-01
    z[7,8,6]  R2204     5.8809602633118629e-03
    z[7,8,6]  R2205     -4.3160450458526611e-01
    z[7,8,6]  R2206     -0.0836590826511383
    z[7,8,6]  R2207     2.9482778906822205e-01
    z[7,8,6]  R2208     -1.6677691042423248e-01
    z[7,8,6]  R2209     -3.1339681148529053e-01
    z[7,8,6]  R2210     2.9812278226017952e-03
    z[7,8,6]  R2211     -1.4244405925273895e-01
    z[7,8,6]  R2212     -5.6648272275924683e-01
    z[7,8,6]  R2213     2.6795610785484314e-01
    z[7,8,6]  R2214     -1.3899274170398712e-01
    z[7,8,6]  R2215     -0.302824467420578
    z[7,8,6]  R2216     -1.4386588335037231e-01
    z[7,8,6]  R2217     -4.9705934524536133e-01
    z[7,8,6]  R2218     -5.6827610731124878e-01
    z[7,8,6]  R2219     -2.8039899468421936e-01
    z[7,8,6]  R2220     1.0525915026664734e-01
    z[7,8,6]  R2221     2.3873572051525116e-01
    z[7,8,6]  R2222     3.6680704355239868e-01
    z[7,8,6]  R2223     -2.5111767649650574e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2224     -1
    z[8,7,0]  R2225     1
    z[8,7,0]  R2238     -0.0651671439409256
    z[8,7,0]  R2239     -3.8651326298713684e-01
    z[8,7,0]  R2240     -8.7483161687850952e-01
    z[8,7,0]  R2241     -1.0937790572643280e-01
    z[8,7,0]  R2242     -7.1644246578216553e-01
    z[8,7,0]  R2243     -7.8381127119064331e-01
    z[8,7,0]  R2244     -8.2541257143020630e-01
    z[8,7,0]  R2245     -8.2917296886444092e-01
    z[8,7,0]  R2246     -7.0350253582000732e-01
    z[8,7,0]  R2247     -7.1030479669570923e-01
    z[8,7,0]  R2248     7.0778125524520874e-01
    z[8,7,0]  R2249     3.0961731076240540e-01
    z[8,7,0]  R2250     5.5427330732345581e-01
    z[8,7,0]  R2251     5.3040701150894165e-01
    z[8,7,0]  R2252     6.3643324375152588e-01
    z[8,7,0]  R2253     3.0334493517875671e-01
    z[8,7,0]  R2254     1.4406631886959076e-01
    z[8,7,0]  R2255     4.1738396883010864e-01
    z[8,7,0]  R2256     3.3460852503776550e-01
    z[8,7,0]  R2257     5.0922924280166626e-01
    z[8,7,0]  R2258     0.789631187915802
    z[8,7,0]  R2259     0.835048258304596
    z[8,7,0]  R2260     0.459786057472229
    z[8,7,0]  R2261     6.5228879451751709e-01
    z[8,7,0]  R2262     5.4485547542572021e-01
    z[8,7,0]  R2263     0.624904215335846
    z[8,7,0]  R2264     7.1223413944244385e-01
    z[8,7,0]  R2265     4.7081285715103149e-01
    z[8,7,0]  R2266     5.9584714472293854e-02
    z[8,7,0]  R2267     3.8621027022600174e-02
    z[8,7,0]  R2268     1.4462977647781372e-01
    z[8,7,0]  R2269     2.0282746851444244e-01
    z[8,7,0]  R2270     -1.4239031076431274e-01
    z[8,7,0]  R2271     -8.0109804868698120e-02
    z[8,7,0]  R2272     -2.0861518383026123e-01
    z[8,7,0]  R2273     1.8142579495906830e-01
    z[8,7,0]  R2274     1.0963388532400131e-01
    z[8,7,0]  R2275     -4.8393601179122925e-01
    z[8,7,0]  R2276     -3.7745830416679382e-01
    z[8,7,0]  R2277     -1.5982395410537720e-01
    z[8,7,0]  R2278     5.4731643199920654e-01
    z[8,7,0]  R2279     -2.8332433104515076e-01
    z[8,7,0]  R2280     1.8951942026615143e-01
    z[8,7,0]  R2281     2.0079214870929718e-01
    z[8,7,0]  R2282     5.3021436929702759e-01
    z[8,7,0]  R2283     -2.2666609287261963e-01
    z[8,7,0]  R2284     -3.4470555186271667e-01
    z[8,7,0]  R2285     1.7929136753082275e-01
    z[8,7,0]  R2286     4.1812822222709656e-01
    z[8,7,0]  R2287     2.3096819221973419e-01
    z[8,7,0]  R2288     3.1026995182037354e-01
    z[8,7,0]  R2289     1.9502638280391693e-01
    z[8,7,0]  R2290     -2.3145294189453125e-01
    z[8,7,0]  R2291     4.9859631806612015e-02
    z[8,7,0]  R2292     -2.3853557184338570e-02
    z[8,7,0]  R2293     -2.5242453813552856e-01
    z[8,7,0]  R2294     2.6620236039161682e-01
    z[8,7,0]  R2295     7.1300083398818970e-01
    z[8,7,0]  R2296     -3.1056925654411316e-01
    z[8,7,0]  R2297     -2.4116815626621246e-01
    z[8,7,0]  R2298     -6.1735503375530243e-02
    z[8,7,0]  R2299     3.5499048233032227e-01
    z[8,7,0]  R2300     -2.3529201745986938e-01
    z[8,7,0]  R2301     -4.5805446803569794e-02
    z[8,7,0]  R2302     -3.3786529302597046e-01
    z[8,7,0]  R2303     -1.2771472334861755e-01
    z[8,7,0]  R2304     7.2117978334426880e-01
    z[8,7,0]  R2305     2.2776730358600616e-01
    z[8,7,0]  R2306     2.8832095861434937e-01
    z[8,7,0]  R2307     -1.2953884899616241e-01
    z[8,7,0]  R2308     9.7091786563396454e-02
    z[8,7,0]  R2309     -0.0796702653169632
    z[8,7,0]  R2310     -1.6089361906051636e-01
    z[8,7,0]  R2311     1.7138876020908356e-01
    z[8,7,0]  R2312     -3.0284032225608826e-01
    z[8,7,0]  R2313     1.8827617168426514e-01
    z[8,7,0]  R2314     -3.8897427916526794e-01
    z[8,7,0]  R2315     -3.2350787520408630e-01
    z[8,7,0]  R2316     -1.8089754879474640e-01
    z[8,7,0]  R2317     -6.2212910503149033e-02
    z[8,7,0]  R2318     -5.4922342300415039e-02
    z[8,7,0]  R2319     2.1008875966072083e-01
    z[8,7,0]  R2320     -1.9150808453559875e-02
    z[8,7,0]  R2321     -1.3141886889934540e-01
    z[8,7,0]  R2322     -0.280888170003891
    z[8,7,0]  R2323     -3.2990834116935730e-01
    z[8,7,0]  R2324     4.2448371648788452e-02
    z[8,7,0]  R2325     2.3840151727199554e-01
    z[8,7,0]  R2326     4.2176750302314758e-01
    z[8,7,0]  R2327     7.9707928001880646e-02
    z[8,7,0]  R2328     2.2722578048706055e-01
    z[8,7,0]  R2329     2.6506033539772034e-01
    z[8,7,0]  R2330     -2.3064351081848145e-01
    z[8,7,0]  R2331     -1.8559268116950989e-01
    z[8,7,0]  R2332     2.2781016305088997e-02
    z[8,7,0]  R2333     -4.7762727737426758e-01
    z[8,7,0]  R2334     -5.0240868330001831e-01
    z[8,7,0]  R2335     -4.3745297193527222e-01
    z[8,7,0]  R2336     -2.7342742681503296e-01
    z[8,7,0]  R2337     -4.5025333762168884e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2226     -1
    z[8,7,1]  R2227     1
    z[8,7,1]  R2238     -3.2979834079742432e-01
    z[8,7,1]  R2239     -1.1426496505737305e-01
    z[8,7,1]  R2240     -0.0662216767668724
    z[8,7,1]  R2241     -3.3748188614845276e-01
    z[8,7,1]  R2242     -4.0812242031097412e-01
    z[8,7,1]  R2243     -5.6595962494611740e-02
    z[8,7,1]  R2244     -5.6493185460567474e-02
    z[8,7,1]  R2245     1.6281509399414062e-01
    z[8,7,1]  R2246     -1.4227128028869629e-01
    z[8,7,1]  R2247     -2.3268491029739380e-01
    z[8,7,1]  R2248     4.0143576264381409e-01
    z[8,7,1]  R2249     -5.1193749904632568e-01
    z[8,7,1]  R2250     6.4949011802673340e-01
    z[8,7,1]  R2251     6.8918168544769287e-01
    z[8,7,1]  R2252     2.4982081353664398e-01
    z[8,7,1]  R2253     3.2470539212226868e-01
    z[8,7,1]  R2254     7.5429028272628784e-01
    z[8,7,1]  R2255     4.4429680705070496e-01
    z[8,7,1]  R2256     4.2257469892501831e-01
    z[8,7,1]  R2257     4.1837745904922485e-01
    z[8,7,1]  R2258     4.1784796863794327e-02
    z[8,7,1]  R2259     -2.0650871098041534e-01
    z[8,7,1]  R2260     -3.6184465885162354e-01
    z[8,7,1]  R2261     -3.6312100291252136e-01
    z[8,7,1]  R2262     2.7227425575256348e-01
    z[8,7,1]  R2263     2.6621243357658386e-01
    z[8,7,1]  R2264     -3.8219049572944641e-01
    z[8,7,1]  R2265     -2.7316927909851074e-01
    z[8,7,1]  R2266     6.4165496826171875e-01
    z[8,7,1]  R2267     8.5204273462295532e-01
    z[8,7,1]  R2268     8.8997566699981689e-01
    z[8,7,1]  R2269     5.6347352266311646e-01
    z[8,7,1]  R2270     5.3149688243865967e-01
    z[8,7,1]  R2271     4.7394096851348877e-01
    z[8,7,1]  R2272     -8.6980652809143066e-01
    z[8,7,1]  R2273     4.5374700427055359e-01
    z[8,7,1]  R2274     -7.2401589155197144e-01
    z[8,7,1]  R2275     -0.854438841342926
    z[8,7,1]  R2276     -5.5981749296188354e-01
    z[8,7,1]  R2277     4.8178479075431824e-01
    z[8,7,1]  R2278     3.6600002646446228e-01
    z[8,7,1]  R2279     -0.652351438999176
    z[8,7,1]  R2280     1.9683641195297241e-01
    z[8,7,1]  R2281     -5.6298565864562988e-01
    z[8,7,1]  R2282     9.3209460377693176e-02
    z[8,7,1]  R2283     -3.4307649731636047e-01
    z[8,7,1]  R2284     -2.4836876988410950e-01
    z[8,7,1]  R2285     -8.3863925933837891e-01
    z[8,7,1]  R2286     -1.2238927185535431e-01
    z[8,7,1]  R2287     -7.0744502544403076e-01
    z[8,7,1]  R2288     2.8402090072631836e-01
    z[8,7,1]  R2289     6.2036657333374023e-01
    z[8,7,1]  R2290     -5.9176814556121826e-01
    z[8,7,1]  R2291     -6.9369810819625854e-01
    z[8,7,1]  R2292     5.0723671913146973e-01
    z[8,7,1]  R2293     -5.3851896524429321e-01
    z[8,7,1]  R2294     6.1436223983764648e-01
    z[8,7,1]  R2295     5.4348480701446533e-01
    z[8,7,1]  R2296     -4.8074319958686829e-01
    z[8,7,1]  R2297     -4.0413281321525574e-01
    z[8,7,1]  R2298     -5.2071684598922729e-01
    z[8,7,1]  R2299     5.8704417943954468e-01
    z[8,7,1]  R2300     -4.6282440423965454e-01
    z[8,7,1]  R2301     6.0084664821624756e-01
    z[8,7,1]  R2302     -0.56495201587677
    z[8,7,1]  R2303     -4.6176734566688538e-01
    z[8,7,1]  R2304     4.9946096539497375e-01
    z[8,7,1]  R2305     6.1561310291290283e-01
    z[8,7,1]  R2306     -4.0816673636436462e-01
    z[8,7,1]  R2307     -4.3503656983375549e-01
    z[8,7,1]  R2308     6.2327593564987183e-01
    z[8,7,1]  R2309     7.1865928173065186e-01
    z[8,7,1]  R2310     -7.5535839796066284e-01
    z[8,7,1]  R2311     -5.4526019096374512e-01
    z[8,7,1]  R2312     -0.555756151676178
    z[8,7,1]  R2313     1.3988788425922394e-01
    z[8,7,1]  R2314     -6.5123164653778076e-01
    z[8,7,1]  R2315     -4.4593289494514465e-01
    z[8,7,1]  R2316     -4.6819174289703369e-01
    z[8,7,1]  R2317     -5.4919254779815674e-01
    z[8,7,1]  R2318     -8.0863159894943237e-01
    z[8,7,1]  R2319     -9.4244188070297241e-01
    z[8,7,1]  R2320     -7.6257109642028809e-01
    z[8,7,1]  R2321     -7.5732493400573730e-01
    z[8,7,1]  R2322     -7.1655815839767456e-01
    z[8,7,1]  R2323     -5.2059888839721680e-01
    z[8,7,1]  R2324     -7.0152491331100464e-01
    z[8,7,1]  R2325     -5.9501367807388306e-01
    z[8,7,1]  R2326     3.2451578974723816e-01
    z[8,7,1]  R2327     -2.0547662675380707e-01
    z[8,7,1]  R2328     5.9226512908935547e-01
    z[8,7,1]  R2329     -4.9956339597702026e-01
    z[8,7,1]  R2330     -5.6142532825469971e-01
    z[8,7,1]  R2331     -4.3255776166915894e-01
    z[8,7,1]  R2332     -4.2222142219543457e-01
    z[8,7,1]  R2333     7.2138541936874390e-01
    z[8,7,1]  R2334     7.3265445232391357e-01
    z[8,7,1]  R2335     0.735712468624115
    z[8,7,1]  R2336     8.1659460067749023e-01
    z[8,7,1]  R2337     6.6647243499755859e-01
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2228     -1
    z[8,7,2]  R2229     1
    z[8,7,2]  R2238     1.2959934771060944e-01
    z[8,7,2]  R2239     -1.3875004649162292e-01
    z[8,7,2]  R2240     -1.8310436606407166e-01
    z[8,7,2]  R2241     -6.7341946065425873e-02
    z[8,7,2]  R2242     -3.3988818526268005e-01
    z[8,7,2]  R2243     5.0396567583084106e-01
    z[8,7,2]  R2244     1.8700838088989258e-01
    z[8,7,2]  R2245     0.0691818818449974
    z[8,7,2]  R2246     4.2266142368316650e-01
    z[8,7,2]  R2247     4.0819045901298523e-01
    z[8,7,2]  R2248     4.3854832649230957e-01
    z[8,7,2]  R2249     3.8465568423271179e-01
    z[8,7,2]  R2250     -2.6800140738487244e-01
    z[8,7,2]  R2251     -1.2427277117967606e-01
    z[8,7,2]  R2252     2.0401073992252350e-01
    z[8,7,2]  R2253     5.3101760149002075e-01
    z[8,7,2]  R2254     -1.7486673593521118e-01
    z[8,7,2]  R2255     3.3118656277656555e-01
    z[8,7,2]  R2256     -5.0349120050668716e-02
    z[8,7,2]  R2257     1.7553143203258514e-01
    z[8,7,2]  R2258     -2.8456050157546997e-01
    z[8,7,2]  R2259     2.1536806225776672e-01
    z[8,7,2]  R2260     -6.1289733648300171e-01
    z[8,7,2]  R2261     -4.1806069016456604e-01
    z[8,7,2]  R2262     2.4455563724040985e-01
    z[8,7,2]  R2263     -3.7168264389038086e-01
    z[8,7,2]  R2264     6.2742471694946289e-02
    z[8,7,2]  R2265     -3.4416135400533676e-02
    z[8,7,2]  R2266     2.1319410204887390e-01
    z[8,7,2]  R2267     -2.3614510893821716e-01
    z[8,7,2]  R2268     1.5626215934753418e-01
    z[8,7,2]  R2269     1.4070723950862885e-01
    z[8,7,2]  R2270     6.9898366928100586e-02
    z[8,7,2]  R2271     -5.5283259600400925e-02
    z[8,7,2]  R2272     0.0860406756401062
    z[8,7,2]  R2273     5.0194729119539261e-02
    z[8,7,2]  R2274     5.7102650403976440e-01
    z[8,7,2]  R2275     -1.7140921950340271e-01
    z[8,7,2]  R2276     5.3867197036743164e-01
    z[8,7,2]  R2277     -1.0154915601015091e-01
    z[8,7,2]  R2278     9.3037039041519165e-02
    z[8,7,2]  R2279     8.0166503787040710e-02
    z[8,7,2]  R2280     -0.686255156993866
    z[8,7,2]  R2281     3.1873509287834167e-01
    z[8,7,2]  R2282     -2.4452788755297661e-02
    z[8,7,2]  R2283     3.0223757028579712e-01
    z[8,7,2]  R2284     -2.4538283050060272e-01
    z[8,7,2]  R2285     -1.0774039663374424e-02
    z[8,7,2]  R2286     3.8475415110588074e-01
    z[8,7,2]  R2287     -2.4036644399166107e-01
    z[8,7,2]  R2288     1.6755943000316620e-01
    z[8,7,2]  R2289     -6.1562073230743408e-01
    z[8,7,2]  R2290     1.2368278205394745e-01
    z[8,7,2]  R2291     -3.2838433980941772e-02
    z[8,7,2]  R2292     -5.2198302745819092e-01
    z[8,7,2]  R2293     2.7007073163986206e-01
    z[8,7,2]  R2294     3.4253621101379395e-01
    z[8,7,2]  R2295     1.1106052435934544e-02
    z[8,7,2]  R2296     -6.6184081137180328e-02
    z[8,7,2]  R2297     -2.2363376617431641e-01
    z[8,7,2]  R2298     6.8158376216888428e-01
    z[8,7,2]  R2299     2.2800515592098236e-01
    z[8,7,2]  R2300     4.6837532520294189e-01
    z[8,7,2]  R2301     -2.4548043310642242e-01
    z[8,7,2]  R2302     3.2230582088232040e-02
    z[8,7,2]  R2303     3.8513442873954773e-01
    z[8,7,2]  R2304     1.8799996376037598e-01
    z[8,7,2]  R2305     -2.9129263758659363e-01
    z[8,7,2]  R2306     4.2210742831230164e-01
    z[8,7,2]  R2307     5.6851077079772949e-01
    z[8,7,2]  R2308     -6.6060012578964233e-01
    z[8,7,2]  R2309     1.0846129059791565e-01
    z[8,7,2]  R2310     -1.4594377577304840e-01
    z[8,7,2]  R2311     6.9918280839920044e-01
    z[8,7,2]  R2312     -9.2435348778963089e-03
    z[8,7,2]  R2313     -2.3108625411987305e-01
    z[8,7,2]  R2314     -1.9133625924587250e-01
    z[8,7,2]  R2315     2.5521764159202576e-01
    z[8,7,2]  R2316     4.5094007253646851e-01
    z[8,7,2]  R2317     3.7741002440452576e-01
    z[8,7,2]  R2318     1.5772137045860291e-01
    z[8,7,2]  R2319     0.121115542948246
    z[8,7,2]  R2320     0.227840393781662
    z[8,7,2]  R2321     -0.0860668197274208
    z[8,7,2]  R2322     1.8881501257419586e-01
    z[8,7,2]  R2323     5.2971524000167847e-01
    z[8,7,2]  R2324     3.8336157798767090e-02
    z[8,7,2]  R2325     5.1168650388717651e-01
    z[8,7,2]  R2326     -6.2997028231620789e-02
    z[8,7,2]  R2327     0.702738344669342
    z[8,7,2]  R2328     -8.3330802619457245e-02
    z[8,7,2]  R2329     5.5563312768936157e-01
    z[8,7,2]  R2330     1.6081599891185760e-01
    z[8,7,2]  R2331     8.1674647331237793e-01
    z[8,7,2]  R2332     6.7043161392211914e-01
    z[8,7,2]  R2333     -2.8460618853569031e-01
    z[8,7,2]  R2334     1.6050188243389130e-01
    z[8,7,2]  R2335     -1.4110109210014343e-01
    z[8,7,2]  R2336     1.0098636895418167e-01
    z[8,7,2]  R2337     2.0625907927751541e-02
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2230     -1
    z[8,7,3]  R2231     1
    z[8,7,3]  R2238     2.7789419889450073e-01
    z[8,7,3]  R2239     8.6106359958648682e-02
    z[8,7,3]  R2240     3.5527431964874268e-01
    z[8,7,3]  R2241     -2.3907026648521423e-01
    z[8,7,3]  R2242     2.6862043142318726e-01
    z[8,7,3]  R2243     0.00202555931173265
    z[8,7,3]  R2244     -2.9539713263511658e-01
    z[8,7,3]  R2245     4.6744119375944138e-02
    z[8,7,3]  R2246     -2.7432683110237122e-01
    z[8,7,3]  R2247     -4.2522680759429932e-01
    z[8,7,3]  R2248     -1.9700820744037628e-01
    z[8,7,3]  R2249     -4.4549080729484558e-01
    z[8,7,3]  R2250     2.7383938431739807e-01
    z[8,7,3]  R2251     1.9027142226696014e-01
    z[8,7,3]  R2252     -4.0646929293870926e-02
    z[8,7,3]  R2253     6.2380152940750122e-01
    z[8,7,3]  R2254     -5.6583017110824585e-01
    z[8,7,3]  R2255     5.0485078245401382e-02
    z[8,7,3]  R2256     3.8308575749397278e-01
    z[8,7,3]  R2257     -6.3338160514831543e-02
    z[8,7,3]  R2258     2.5125262141227722e-01
    z[8,7,3]  R2259     8.3592817187309265e-02
    z[8,7,3]  R2260     -4.9714568257331848e-01
    z[8,7,3]  R2261     -5.9920862317085266e-02
    z[8,7,3]  R2262     1.8090160191059113e-01
    z[8,7,3]  R2263     -2.1851888298988342e-01
    z[8,7,3]  R2264     -0.518419623374939
    z[8,7,3]  R2265     -7.6481819152832031e-01
    z[8,7,3]  R2266     0.572091817855835
    z[8,7,3]  R2267     7.3339510709047318e-03
    z[8,7,3]  R2268     -1.9977492094039917e-01
    z[8,7,3]  R2269     -4.5930573344230652e-01
    z[8,7,3]  R2270     -7.5363588333129883e-01
    z[8,7,3]  R2271     -5.6296902894973755e-01
    z[8,7,3]  R2272     -2.4565504863858223e-02
    z[8,7,3]  R2273     -5.3719317913055420e-01
    z[8,7,3]  R2274     -2.0710441470146179e-01
    z[8,7,3]  R2275     -2.1754177287220955e-02
    z[8,7,3]  R2276     -1.8905088305473328e-01
    z[8,7,3]  R2277     -2.4509520828723907e-01
    z[8,7,3]  R2278     -2.9720559716224670e-01
    z[8,7,3]  R2279     -4.1779360175132751e-01
    z[8,7,3]  R2280     -0.559943675994873
    z[8,7,3]  R2281     3.1916698813438416e-01
    z[8,7,3]  R2282     -7.5362426042556763e-01
    z[8,7,3]  R2283     7.7795481681823730e-01
    z[8,7,3]  R2284     8.0503243207931519e-01
    z[8,7,3]  R2285     3.2476234436035156e-01
    z[8,7,3]  R2286     -4.7026541829109192e-01
    z[8,7,3]  R2287     5.5571585893630981e-01
    z[8,7,3]  R2288     -6.1917799711227417e-01
    z[8,7,3]  R2289     6.9842688739299774e-02
    z[8,7,3]  R2290     -5.1531377248466015e-03
    z[8,7,3]  R2291     5.9765160083770752e-01
    z[8,7,3]  R2292     -4.1451793909072876e-01
    z[8,7,3]  R2293     1.8008767068386078e-01
    z[8,7,3]  R2294     -3.8358801603317261e-01
    z[8,7,3]  R2295     0.267170250415802
    z[8,7,3]  R2296     4.3227684497833252e-01
    z[8,7,3]  R2297     5.9382396936416626e-01
    z[8,7,3]  R2298     -4.5205873250961304e-01
    z[8,7,3]  R2299     -3.3212760090827942e-01
    z[8,7,3]  R2300     1.8679212033748627e-01
    z[8,7,3]  R2301     -2.9897835850715637e-01
    z[8,7,3]  R2302     2.3277139663696289e-01
    z[8,7,3]  R2303     5.3183770179748535e-01
    z[8,7,3]  R2304     -1.4117913320660591e-02
    z[8,7,3]  R2305     -1.3899800181388855e-01
    z[8,7,3]  R2306     -4.4124302268028259e-01
    z[8,7,3]  R2307     4.1658997535705566e-01
    z[8,7,3]  R2308     -2.7856573462486267e-01
    z[8,7,3]  R2309     -4.0980812907218933e-01
    z[8,7,3]  R2310     2.2978819906711578e-01
    z[8,7,3]  R2311     1.8695114180445671e-02
    z[8,7,3]  R2312     4.2316564917564392e-01
    z[8,7,3]  R2313     -9.2306923866271973e-01
    z[8,7,3]  R2314     3.0637022852897644e-01
    z[8,7,3]  R2315     6.0286504030227661e-01
    z[8,7,3]  R2316     -2.6251927018165588e-01
    z[8,7,3]  R2317     0.3237284719944
    z[8,7,3]  R2318     4.8264548182487488e-01
    z[8,7,3]  R2319     -6.8123318254947662e-02
    z[8,7,3]  R2320     -2.4848574399948120e-01
    z[8,7,3]  R2321     -0.09919423609972
    z[8,7,3]  R2322     6.9111935794353485e-02
    z[8,7,3]  R2323     3.1444087624549866e-01
    z[8,7,3]  R2324     2.7635595202445984e-01
    z[8,7,3]  R2325     1.7880478873848915e-02
    z[8,7,3]  R2326     -5.5708044767379761e-01
    z[8,7,3]  R2327     -4.9197328090667725e-01
    z[8,7,3]  R2328     -6.1810475587844849e-01
    z[8,7,3]  R2329     -2.9371315240859985e-01
    z[8,7,3]  R2330     3.5752159357070923e-01
    z[8,7,3]  R2331     2.3813307285308838e-01
    z[8,7,3]  R2332     -2.2278147935867310e-01
    z[8,7,3]  R2333     3.4698012471199036e-01
    z[8,7,3]  R2334     1.5617586672306061e-01
    z[8,7,3]  R2335     4.3177241086959839e-01
    z[8,7,3]  R2336     3.2639807462692261e-01
    z[8,7,3]  R2337     -0.044993806630373
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2232     -1
    z[8,7,4]  R2233     1
    z[8,7,4]  R2238     -1.3234589993953705e-01
    z[8,7,4]  R2239     -7.7655291557312012e-01
    z[8,7,4]  R2240     -1.2535287439823151e-01
    z[8,7,4]  R2241     2.5612282752990723e-01
    z[8,7,4]  R2242     1.5100137889385223e-01
    z[8,7,4]  R2243     -3.5049033164978027e-01
    z[8,7,4]  R2244     -2.7637195587158203e-01
    z[8,7,4]  R2245     -4.8712566494941711e-01
    z[8,7,4]  R2246     2.1780742332339287e-02
    z[8,7,4]  R2247     7.4842788279056549e-02
    z[8,7,4]  R2248     -0.0647103488445282
    z[8,7,4]  R2249     -1.8469931185245514e-01
    z[8,7,4]  R2250     -2.3780560493469238e-01
    z[8,7,4]  R2251     -3.2354512810707092e-01
    z[8,7,4]  R2252     -6.7800402641296387e-01
    z[8,7,4]  R2253     1.6613423824310303e-01
    z[8,7,4]  R2254     -2.0452244579792023e-01
    z[8,7,4]  R2255     4.9505016207695007e-01
    z[8,7,4]  R2256     1.1797765642404556e-01
    z[8,7,4]  R2257     6.3076001405715942e-01
    z[8,7,4]  R2258     4.1038030385971069e-01
    z[8,7,4]  R2259     -7.8159511089324951e-02
    z[8,7,4]  R2260     2.5209732353687286e-02
    z[8,7,4]  R2261     -8.7192952632904053e-02
    z[8,7,4]  R2262     1.4575250446796417e-01
    z[8,7,4]  R2263     -4.7126278281211853e-02
    z[8,7,4]  R2264     1.8223161995410919e-01
    z[8,7,4]  R2265     1.9964620471000671e-01
    z[8,7,4]  R2266     2.1644271910190582e-01
    z[8,7,4]  R2267     1.6444487869739532e-01
    z[8,7,4]  R2268     -1.5166673064231873e-01
    z[8,7,4]  R2269     -3.4555739164352417e-01
    z[8,7,4]  R2270     -9.1287478804588318e-02
    z[8,7,4]  R2271     -5.6490135192871094e-01
    z[8,7,4]  R2272     -1.1244915425777435e-01
    z[8,7,4]  R2273     -6.0637700557708740e-01
    z[8,7,4]  R2274     -2.2839431464672089e-01
    z[8,7,4]  R2275     -7.4578397907316685e-03
    z[8,7,4]  R2276     1.5477222204208374e-01
    z[8,7,4]  R2277     -7.9120141267776489e-01
    z[8,7,4]  R2278     0.379867285490036
    z[8,7,4]  R2279     -2.8409931063652039e-01
    z[8,7,4]  R2280     -1.5021848678588867e-01
    z[8,7,4]  R2281     0.51568603515625
    z[8,7,4]  R2282     3.2848662137985229e-01
    z[8,7,4]  R2283     1.1617516167461872e-02
    z[8,7,4]  R2284     -6.8178132176399231e-02
    z[8,7,4]  R2285     1.7207933962345123e-01
    z[8,7,4]  R2286     5.8379912376403809e-01
    z[8,7,4]  R2287     -1.2048694491386414e-01
    z[8,7,4]  R2288     -1.7973898351192474e-01
    z[8,7,4]  R2289     3.8831412792205811e-02
    z[8,7,4]  R2290     6.8202883005142212e-02
    z[8,7,4]  R2291     3.5923016071319580e-01
    z[8,7,4]  R2292     3.5152861475944519e-01
    z[8,7,4]  R2293     -1.1418701708316803e-01
    z[8,7,4]  R2294     3.3009532094001770e-01
    z[8,7,4]  R2295     -0.020780049264431
    z[8,7,4]  R2296     -2.5901803374290466e-01
    z[8,7,4]  R2297     1.0997701436281204e-01
    z[8,7,4]  R2298     -7.1648612618446350e-02
    z[8,7,4]  R2299     2.2435715794563293e-01
    z[8,7,4]  R2300     -1.0111869871616364e-01
    z[8,7,4]  R2301     6.5114194154739380e-01
    z[8,7,4]  R2302     7.0492070913314819e-01
    z[8,7,4]  R2303     5.3112041950225830e-01
    z[8,7,4]  R2304     -3.9135057479143143e-02
    z[8,7,4]  R2305     6.6909164190292358e-01
    z[8,7,4]  R2306     4.3342703580856323e-01
    z[8,7,4]  R2307     1.9511634111404419e-01
    z[8,7,4]  R2308     5.6614045053720474e-02
    z[8,7,4]  R2309     -3.3648470044136047e-01
    z[8,7,4]  R2310     -3.3892503380775452e-01
    z[8,7,4]  R2311     1.7174851894378662e-01
    z[8,7,4]  R2312     5.2391719818115234e-01
    z[8,7,4]  R2313     -5.4748533293604851e-03
    z[8,7,4]  R2314     5.0637274980545044e-01
    z[8,7,4]  R2315     -9.4249770045280457e-02
    z[8,7,4]  R2316     -3.7535166740417480e-01
    z[8,7,4]  R2317     5.7516556978225708e-01
    z[8,7,4]  R2318     -2.4371746182441711e-01
    z[8,7,4]  R2319     -0.0630812719464302
    z[8,7,4]  R2320     -1.5615428984165192e-01
    z[8,7,4]  R2321     -4.1815164685249329e-01
    z[8,7,4]  R2322     5.6889444589614868e-01
    z[8,7,4]  R2323     4.3261536955833435e-01
    z[8,7,4]  R2324     4.4233259558677673e-01
    z[8,7,4]  R2325     3.8211050629615784e-01
    z[8,7,4]  R2326     4.0350979566574097e-01
    z[8,7,4]  R2327     2.5373873114585876e-01
    z[8,7,4]  R2328     2.3028384149074554e-01
    z[8,7,4]  R2329     4.7659239172935486e-01
    z[8,7,4]  R2330     4.1253918409347534e-01
    z[8,7,4]  R2331     -3.1321745365858078e-02
    z[8,7,4]  R2332     4.2325553297996521e-01
    z[8,7,4]  R2333     -2.1023072768002748e-03
    z[8,7,4]  R2334     1.9366234540939331e-01
    z[8,7,4]  R2335     4.8675616271793842e-03
    z[8,7,4]  R2336     2.8165090084075928e-01
    z[8,7,4]  R2337     1.6946977376937866e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2234     -1
    z[8,7,5]  R2235     1
    z[8,7,5]  R2238     -8.0316364765167236e-01
    z[8,7,5]  R2239     8.3404947072267532e-03
    z[8,7,5]  R2240     1.0405653715133667e-01
    z[8,7,5]  R2241     3.6442485451698303e-01
    z[8,7,5]  R2242     -1.1600332707166672e-01
    z[8,7,5]  R2243     1.0517539456486702e-02
    z[8,7,5]  R2244     1.3749845325946808e-01
    z[8,7,5]  R2245     1.0967095941305161e-01
    z[8,7,5]  R2246     -7.9711824655532837e-02
    z[8,7,5]  R2247     2.2350908815860748e-01
    z[8,7,5]  R2248     0.320212721824646
    z[8,7,5]  R2249     2.7429682016372681e-01
    z[8,7,5]  R2250     2.4613082408905029e-01
    z[8,7,5]  R2251     2.1101389080286026e-02
    z[8,7,5]  R2252     4.2020749300718307e-02
    z[8,7,5]  R2253     -0.0749799907207489
    z[8,7,5]  R2254     1.3308162987232208e-01
    z[8,7,5]  R2255     5.0079214572906494e-01
    z[8,7,5]  R2256     4.7471746802330017e-01
    z[8,7,5]  R2257     2.4731396138668060e-01
    z[8,7,5]  R2258     -2.0713052153587341e-01
    z[8,7,5]  R2259     -3.2994800806045532e-01
    z[8,7,5]  R2260     1.1634192615747452e-01
    z[8,7,5]  R2261     -9.8115660250186920e-02
    z[8,7,5]  R2262     4.3850308656692505e-01
    z[8,7,5]  R2263     5.2142363786697388e-01
    z[8,7,5]  R2264     -1.7224879562854767e-01
    z[8,7,5]  R2265     1.4397594332695007e-01
    z[8,7,5]  R2266     -1.7490822076797485e-01
    z[8,7,5]  R2267     -3.5582467913627625e-01
    z[8,7,5]  R2268     -3.1226858496665955e-01
    z[8,7,5]  R2269     2.1409997344017029e-01
    z[8,7,5]  R2270     -2.6923105120658875e-01
    z[8,7,5]  R2271     1.0556698776781559e-02
    z[8,7,5]  R2272     -2.2960084676742554e-01
    z[8,7,5]  R2273     -2.9354125261306763e-01
    z[8,7,5]  R2274     1.9772459566593170e-01
    z[8,7,5]  R2275     7.6270140707492828e-02
    z[8,7,5]  R2276     -0.438752144575119
    z[8,7,5]  R2277     1.8437439203262329e-01
    z[8,7,5]  R2278     0.479140043258667
    z[8,7,5]  R2279     -6.7136198282241821e-02
    z[8,7,5]  R2280     3.4269323945045471e-01
    z[8,7,5]  R2281     6.7509203217923641e-03
    z[8,7,5]  R2282     8.8318727910518646e-02
    z[8,7,5]  R2283     0.106237031519413
    z[8,7,5]  R2284     -3.2369217276573181e-01
    z[8,7,5]  R2285     -1.6108108684420586e-02
    z[8,7,5]  R2286     7.9521842300891876e-02
    z[8,7,5]  R2287     2.3443512618541718e-01
    z[8,7,5]  R2288     5.2159792184829712e-01
    z[8,7,5]  R2289     4.1334626078605652e-01
    z[8,7,5]  R2290     -7.4474519491195679e-01
    z[8,7,5]  R2291     7.9768463969230652e-02
    z[8,7,5]  R2292     -6.0710810124874115e-02
    z[8,7,5]  R2293     -4.7103354334831238e-01
    z[8,7,5]  R2294     3.9072573184967041e-01
    z[8,7,5]  R2295     3.0902734398841858e-01
    z[8,7,5]  R2296     -3.4278473258018494e-01
    z[8,7,5]  R2297     -2.3782655596733093e-01
    z[8,7,5]  R2298     6.0546682216227055e-03
    z[8,7,5]  R2299     -1.3144052028656006e-01
    z[8,7,5]  R2300     -4.4617635011672974e-01
    z[8,7,5]  R2301     1.5767388045787811e-02
    z[8,7,5]  R2302     -1.1991579830646515e-01
    z[8,7,5]  R2303     -2.3325958847999573e-01
    z[8,7,5]  R2304     3.0029314756393433e-01
    z[8,7,5]  R2305     -4.3859221041202545e-02
    z[8,7,5]  R2306     -2.2928142547607422e-01
    z[8,7,5]  R2307     3.3179539442062378e-01
    z[8,7,5]  R2308     -1.5246884524822235e-01
    z[8,7,5]  R2309     2.8487738966941833e-01
    z[8,7,5]  R2310     -2.4778003990650177e-01
    z[8,7,5]  R2311     -2.5329765677452087e-01
    z[8,7,5]  R2312     -3.7968876957893372e-01
    z[8,7,5]  R2313     1.1191966384649277e-01
    z[8,7,5]  R2314     -1.2519817054271698e-01
    z[8,7,5]  R2315     -4.8322504758834839e-01
    z[8,7,5]  R2316     -4.7513374686241150e-01
    z[8,7,5]  R2317     3.2976108789443970e-01
    z[8,7,5]  R2318     1.5676942467689514e-01
    z[8,7,5]  R2319     -1.5645761787891388e-01
    z[8,7,5]  R2320     -4.1767066717147827e-01
    z[8,7,5]  R2321     -0.441301167011261
    z[8,7,5]  R2322     1.9575420022010803e-01
    z[8,7,5]  R2323     -5.8023486286401749e-02
    z[8,7,5]  R2324     -1.9879633188247681e-01
    z[8,7,5]  R2325     1.8935534358024597e-01
    z[8,7,5]  R2326     4.8942747712135315e-01
    z[8,7,5]  R2327     -3.7614226341247559e-01
    z[8,7,5]  R2328     0.315332293510437
    z[8,7,5]  R2329     -1.5954193472862244e-01
    z[8,7,5]  R2330     -0.552865207195282
    z[8,7,5]  R2331     0.139020174741745
    z[8,7,5]  R2332     3.7712097167968750e-01
    z[8,7,5]  R2333     -2.0908264815807343e-01
    z[8,7,5]  R2334     -3.0829685926437378e-01
    z[8,7,5]  R2335     -5.7268466800451279e-02
    z[8,7,5]  R2336     -4.8269700258970261e-02
    z[8,7,5]  R2337     -4.9002546072006226e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2236     -1
    z[8,7,6]  R2237     1
    z[8,7,6]  R2238     3.6107870936393738e-01
    z[8,7,6]  R2239     4.5583018660545349e-01
    z[8,7,6]  R2240     2.0975235104560852e-01
    z[8,7,6]  R2241     7.8361243009567261e-01
    z[8,7,6]  R2242     -3.1017291545867920e-01
    z[8,7,6]  R2243     7.4143260717391968e-02
    z[8,7,6]  R2244     3.1302359700202942e-01
    z[8,7,6]  R2245     1.7225943505764008e-01
    z[8,7,6]  R2246     4.7340974211692810e-01
    z[8,7,6]  R2247     1.9577975571155548e-01
    z[8,7,6]  R2248     5.8809602633118629e-03
    z[8,7,6]  R2249     -4.3160450458526611e-01
    z[8,7,6]  R2250     -0.0836590826511383
    z[8,7,6]  R2251     2.9482778906822205e-01
    z[8,7,6]  R2252     -1.6677691042423248e-01
    z[8,7,6]  R2253     -3.1339681148529053e-01
    z[8,7,6]  R2254     2.9812278226017952e-03
    z[8,7,6]  R2255     -1.4244405925273895e-01
    z[8,7,6]  R2256     -5.6648272275924683e-01
    z[8,7,6]  R2257     2.6795610785484314e-01
    z[8,7,6]  R2258     -1.3899274170398712e-01
    z[8,7,6]  R2259     -0.302824467420578
    z[8,7,6]  R2260     -1.4386588335037231e-01
    z[8,7,6]  R2261     -4.9705934524536133e-01
    z[8,7,6]  R2262     -5.6827610731124878e-01
    z[8,7,6]  R2263     -2.8039899468421936e-01
    z[8,7,6]  R2264     1.0525915026664734e-01
    z[8,7,6]  R2265     2.3873572051525116e-01
    z[8,7,6]  R2266     3.6680704355239868e-01
    z[8,7,6]  R2267     -2.5111767649650574e-01
    z[8,7,6]  R2268     -4.6725422143936157e-02
    z[8,7,6]  R2269     4.9532783031463623e-01
    z[8,7,6]  R2270     -2.0872111618518829e-01
    z[8,7,6]  R2271     3.6020421981811523e-01
    z[8,7,6]  R2272     3.5573670268058777e-01
    z[8,7,6]  R2273     -1.2744718790054321e-01
    z[8,7,6]  R2274     5.9656377881765366e-02
    z[8,7,6]  R2275     3.6065650638192892e-03
    z[8,7,6]  R2276     4.1999436914920807e-02
    z[8,7,6]  R2277     -1.0937235504388809e-01
    z[8,7,6]  R2278     -3.0923649668693542e-01
    z[8,7,6]  R2279     -4.7745892405509949e-01
    z[8,7,6]  R2280     2.9163654893636703e-02
    z[8,7,6]  R2281     -4.1628414392471313e-01
    z[8,7,6]  R2282     1.6103953123092651e-01
    z[8,7,6]  R2283     -3.5062587261199951e-01
    z[8,7,6]  R2284     0.0421445369720459
    z[8,7,6]  R2285     -3.5927903652191162e-01
    z[8,7,6]  R2286     3.0636456608772278e-01
    z[8,7,6]  R2287     1.0050907731056213e-01
    z[8,7,6]  R2288     -3.2746991515159607e-01
    z[8,7,6]  R2289     -1.4449976384639740e-01
    z[8,7,6]  R2290     1.4703397452831268e-01
    z[8,7,6]  R2291     -1.5040592849254608e-01
    z[8,7,6]  R2292     0.413028359413147
    z[8,7,6]  R2293     -0.553170919418335
    z[8,7,6]  R2294     1.5998384356498718e-01
    z[8,7,6]  R2295     -1.6976815462112427e-01
    z[8,7,6]  R2296     -5.4460763931274414e-01
    z[8,7,6]  R2297     -5.5427354574203491e-01
    z[8,7,6]  R2298     -2.2574107348918915e-01
    z[8,7,6]  R2299     -5.4722303152084351e-01
    z[8,7,6]  R2300     -0.51659095287323
    z[8,7,6]  R2301     -2.5100201368331909e-01
    z[8,7,6]  R2302     -1.2728338129818439e-02
    z[8,7,6]  R2303     -5.2735541015863419e-02
    z[8,7,6]  R2304     -3.2122838497161865e-01
    z[8,7,6]  R2305     1.2394971400499344e-01
    z[8,7,6]  R2306     3.7009704113006592e-01
    z[8,7,6]  R2307     3.8607341051101685e-01
    z[8,7,6]  R2308     -2.4830827116966248e-01
    z[8,7,6]  R2309     -3.2108855247497559e-01
    z[8,7,6]  R2310     -3.9138159155845642e-01
    z[8,7,6]  R2311     3.0075541138648987e-01
    z[8,7,6]  R2312     4.0192052721977234e-02
    z[8,7,6]  R2313     -1.6422481834888458e-01
    z[8,7,6]  R2314     1.4844579994678497e-01
    z[8,7,6]  R2315     -1.5973339974880219e-01
    z[8,7,6]  R2316     -3.3040615916252136e-01
    z[8,7,6]  R2317     8.7868541479110718e-02
    z[8,7,6]  R2318     -3.6068413406610489e-02
    z[8,7,6]  R2319     -1.4106044173240662e-01
    z[8,7,6]  R2320     -3.2500657439231873e-01
    z[8,7,6]  R2321     -1.4947728812694550e-01
    z[8,7,6]  R2322     7.2512738406658173e-02
    z[8,7,6]  R2323     2.2392643988132477e-01
    z[8,7,6]  R2324     -4.3936377763748169e-01
    z[8,7,6]  R2325     -3.8094186782836914e-01
    z[8,7,6]  R2326     1.1625473387539387e-02
    z[8,7,6]  R2327     9.8391041159629822e-02
    z[8,7,6]  R2328     2.3691312968730927e-01
    z[8,7,6]  R2329     -1.8052671849727631e-01
    z[8,7,6]  R2330     -4.5531578361988068e-02
    z[8,7,6]  R2331     1.8536303937435150e-01
    z[8,7,6]  R2332     -2.7101499959826469e-02
    z[8,7,6]  R2333     7.9745732247829437e-02
    z[8,7,6]  R2334     1.6762834787368774e-01
    z[8,7,6]  R2335     2.4025343358516693e-01
    z[8,7,6]  R2336     2.4498908221721649e-01
    z[8,7,6]  R2337     2.8599247336387634e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2338     -1
    z[8,9,0]  R2339     1
    z[8,9,0]  R2352     -0.0651671439409256
    z[8,9,0]  R2353     -3.8651326298713684e-01
    z[8,9,0]  R2354     -8.7483161687850952e-01
    z[8,9,0]  R2355     -1.0937790572643280e-01
    z[8,9,0]  R2356     -7.1644246578216553e-01
    z[8,9,0]  R2357     -7.8381127119064331e-01
    z[8,9,0]  R2358     -8.2541257143020630e-01
    z[8,9,0]  R2359     -8.2917296886444092e-01
    z[8,9,0]  R2360     -7.0350253582000732e-01
    z[8,9,0]  R2361     -7.1030479669570923e-01
    z[8,9,0]  R2362     7.0778125524520874e-01
    z[8,9,0]  R2363     3.0961731076240540e-01
    z[8,9,0]  R2364     5.5427330732345581e-01
    z[8,9,0]  R2365     5.3040701150894165e-01
    z[8,9,0]  R2366     6.3643324375152588e-01
    z[8,9,0]  R2367     3.0334493517875671e-01
    z[8,9,0]  R2368     1.4406631886959076e-01
    z[8,9,0]  R2369     4.1738396883010864e-01
    z[8,9,0]  R2370     3.3460852503776550e-01
    z[8,9,0]  R2371     5.0922924280166626e-01
    z[8,9,0]  R2372     0.789631187915802
    z[8,9,0]  R2373     0.835048258304596
    z[8,9,0]  R2374     0.459786057472229
    z[8,9,0]  R2375     6.5228879451751709e-01
    z[8,9,0]  R2376     5.4485547542572021e-01
    z[8,9,0]  R2377     0.624904215335846
    z[8,9,0]  R2378     7.1223413944244385e-01
    z[8,9,0]  R2379     4.7081285715103149e-01
    z[8,9,0]  R2380     5.9584714472293854e-02
    z[8,9,0]  R2381     3.8621027022600174e-02
    z[8,9,0]  R2382     -4.3440824747085571e-01
    z[8,9,0]  R2383     2.1972376853227615e-02
    z[8,9,0]  R2384     -0.244341641664505
    z[8,9,0]  R2385     -6.8289309740066528e-01
    z[8,9,0]  R2386     -1.3521650806069374e-02
    z[8,9,0]  R2387     1.6398295760154724e-01
    z[8,9,0]  R2388     3.6707723047584295e-03
    z[8,9,0]  R2389     2.1146349608898163e-02
    z[8,9,0]  R2390     4.4592958875000477e-03
    z[8,9,0]  R2391     4.7170282341539860e-03
    z[8,9,0]  R2392     3.2629200816154480e-01
    z[8,9,0]  R2393     5.8327841758728027e-01
    z[8,9,0]  R2394     6.7834746837615967e-01
    z[8,9,0]  R2395     4.8005494475364685e-01
    z[8,9,0]  R2396     6.3030862808227539e-01
    z[8,9,0]  R2397     6.2125825881958008e-01
    z[8,9,0]  R2398     2.4060758948326111e-01
    z[8,9,0]  R2399     -9.2143654823303223e-02
    z[8,9,0]  R2400     -3.8049963116645813e-01
    z[8,9,0]  R2401     -6.6452682018280029e-01
    z[8,9,0]  R2402     -5.9119069576263428e-01
    z[8,9,0]  R2403     -6.5236341953277588e-01
    z[8,9,0]  R2404     2.9052925109863281e-01
    z[8,9,0]  R2405     5.5014067888259888e-01
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2340     -1
    z[8,9,1]  R2341     1
    z[8,9,1]  R2352     -3.2979834079742432e-01
    z[8,9,1]  R2353     -1.1426496505737305e-01
    z[8,9,1]  R2354     -0.0662216767668724
    z[8,9,1]  R2355     -3.3748188614845276e-01
    z[8,9,1]  R2356     -4.0812242031097412e-01
    z[8,9,1]  R2357     -5.6595962494611740e-02
    z[8,9,1]  R2358     -5.6493185460567474e-02
    z[8,9,1]  R2359     1.6281509399414062e-01
    z[8,9,1]  R2360     -1.4227128028869629e-01
    z[8,9,1]  R2361     -2.3268491029739380e-01
    z[8,9,1]  R2362     4.0143576264381409e-01
    z[8,9,1]  R2363     -5.1193749904632568e-01
    z[8,9,1]  R2364     6.4949011802673340e-01
    z[8,9,1]  R2365     6.8918168544769287e-01
    z[8,9,1]  R2366     2.4982081353664398e-01
    z[8,9,1]  R2367     3.2470539212226868e-01
    z[8,9,1]  R2368     7.5429028272628784e-01
    z[8,9,1]  R2369     4.4429680705070496e-01
    z[8,9,1]  R2370     4.2257469892501831e-01
    z[8,9,1]  R2371     4.1837745904922485e-01
    z[8,9,1]  R2372     4.1784796863794327e-02
    z[8,9,1]  R2373     -2.0650871098041534e-01
    z[8,9,1]  R2374     -3.6184465885162354e-01
    z[8,9,1]  R2375     -3.6312100291252136e-01
    z[8,9,1]  R2376     2.7227425575256348e-01
    z[8,9,1]  R2377     2.6621243357658386e-01
    z[8,9,1]  R2378     -3.8219049572944641e-01
    z[8,9,1]  R2379     -2.7316927909851074e-01
    z[8,9,1]  R2380     6.4165496826171875e-01
    z[8,9,1]  R2381     8.5204273462295532e-01
    z[8,9,1]  R2382     -5.0435990095138550e-01
    z[8,9,1]  R2383     -4.0948277711868286e-01
    z[8,9,1]  R2384     -1.7903269827365875e-01
    z[8,9,1]  R2385     3.6663429345935583e-03
    z[8,9,1]  R2386     -3.2231029868125916e-01
    z[8,9,1]  R2387     -3.7053756415843964e-02
    z[8,9,1]  R2388     0.81685870885849
    z[8,9,1]  R2389     7.0958900451660156e-01
    z[8,9,1]  R2390     7.1484923362731934e-01
    z[8,9,1]  R2391     7.7314484119415283e-01
    z[8,9,1]  R2392     -6.0189563035964966e-01
    z[8,9,1]  R2393     5.9015500545501709e-01
    z[8,9,1]  R2394     6.5964990854263306e-01
    z[8,9,1]  R2395     7.3843461275100708e-01
    z[8,9,1]  R2396     6.0166496038436890e-01
    z[8,9,1]  R2397     6.2605887651443481e-01
    z[8,9,1]  R2398     7.6555055379867554e-01
    z[8,9,1]  R2399     -6.4276337623596191e-01
    z[8,9,1]  R2400     -6.0771763324737549e-01
    z[8,9,1]  R2401     3.8339450955390930e-01
    z[8,9,1]  R2402     -5.5138278007507324e-01
    z[8,9,1]  R2403     3.2223567366600037e-01
    z[8,9,1]  R2404     -5.0489884614944458e-01
    z[8,9,1]  R2405     6.5147417783737183e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2342     -1
    z[8,9,2]  R2343     1
    z[8,9,2]  R2352     1.2959934771060944e-01
    z[8,9,2]  R2353     -1.3875004649162292e-01
    z[8,9,2]  R2354     -1.8310436606407166e-01
    z[8,9,2]  R2355     -6.7341946065425873e-02
    z[8,9,2]  R2356     -3.3988818526268005e-01
    z[8,9,2]  R2357     5.0396567583084106e-01
    z[8,9,2]  R2358     1.8700838088989258e-01
    z[8,9,2]  R2359     0.0691818818449974
    z[8,9,2]  R2360     4.2266142368316650e-01
    z[8,9,2]  R2361     4.0819045901298523e-01
    z[8,9,2]  R2362     4.3854832649230957e-01
    z[8,9,2]  R2363     3.8465568423271179e-01
    z[8,9,2]  R2364     -2.6800140738487244e-01
    z[8,9,2]  R2365     -1.2427277117967606e-01
    z[8,9,2]  R2366     2.0401073992252350e-01
    z[8,9,2]  R2367     5.3101760149002075e-01
    z[8,9,2]  R2368     -1.7486673593521118e-01
    z[8,9,2]  R2369     3.3118656277656555e-01
    z[8,9,2]  R2370     -5.0349120050668716e-02
    z[8,9,2]  R2371     1.7553143203258514e-01
    z[8,9,2]  R2372     -2.8456050157546997e-01
    z[8,9,2]  R2373     2.1536806225776672e-01
    z[8,9,2]  R2374     -6.1289733648300171e-01
    z[8,9,2]  R2375     -4.1806069016456604e-01
    z[8,9,2]  R2376     2.4455563724040985e-01
    z[8,9,2]  R2377     -3.7168264389038086e-01
    z[8,9,2]  R2378     6.2742471694946289e-02
    z[8,9,2]  R2379     -3.4416135400533676e-02
    z[8,9,2]  R2380     2.1319410204887390e-01
    z[8,9,2]  R2381     -2.3614510893821716e-01
    z[8,9,2]  R2382     3.8668855559080839e-03
    z[8,9,2]  R2383     -1.9738748669624329e-01
    z[8,9,2]  R2384     -1.0636299848556519e-01
    z[8,9,2]  R2385     -1.1574492603540421e-01
    z[8,9,2]  R2386     -3.0826982855796814e-01
    z[8,9,2]  R2387     -1.8078340590000153e-01
    z[8,9,2]  R2388     -4.7306194901466370e-03
    z[8,9,2]  R2389     6.2687176465988159e-01
    z[8,9,2]  R2390     6.1571222543716431e-01
    z[8,9,2]  R2391     -1.9940081238746643e-01
    z[8,9,2]  R2392     -6.7717593908309937e-01
    z[8,9,2]  R2393     6.8402059376239777e-02
    z[8,9,2]  R2394     1.9166319072246552e-01
    z[8,9,2]  R2395     -0.047185268253088
    z[8,9,2]  R2396     -1.8307060003280640e-01
    z[8,9,2]  R2397     1.8023288249969482e-01
    z[8,9,2]  R2398     -5.4310280084609985e-01
    z[8,9,2]  R2399     5.8327281475067139e-01
    z[8,9,2]  R2400     4.0467596054077148e-01
    z[8,9,2]  R2401     1.0259532183408737e-01
    z[8,9,2]  R2402     9.4871595501899719e-02
    z[8,9,2]  R2403     -5.5463671684265137e-01
    z[8,9,2]  R2404     3.9323535561561584e-01
    z[8,9,2]  R2405     -6.3270837068557739e-02
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2344     -1
    z[8,9,3]  R2345     1
    z[8,9,3]  R2352     2.7789419889450073e-01
    z[8,9,3]  R2353     8.6106359958648682e-02
    z[8,9,3]  R2354     3.5527431964874268e-01
    z[8,9,3]  R2355     -2.3907026648521423e-01
    z[8,9,3]  R2356     2.6862043142318726e-01
    z[8,9,3]  R2357     0.00202555931173265
    z[8,9,3]  R2358     -2.9539713263511658e-01
    z[8,9,3]  R2359     4.6744119375944138e-02
    z[8,9,3]  R2360     -2.7432683110237122e-01
    z[8,9,3]  R2361     -4.2522680759429932e-01
    z[8,9,3]  R2362     -1.9700820744037628e-01
    z[8,9,3]  R2363     -4.4549080729484558e-01
    z[8,9,3]  R2364     2.7383938431739807e-01
    z[8,9,3]  R2365     1.9027142226696014e-01
    z[8,9,3]  R2366     -4.0646929293870926e-02
    z[8,9,3]  R2367     6.2380152940750122e-01
    z[8,9,3]  R2368     -5.6583017110824585e-01
    z[8,9,3]  R2369     5.0485078245401382e-02
    z[8,9,3]  R2370     3.8308575749397278e-01
    z[8,9,3]  R2371     -6.3338160514831543e-02
    z[8,9,3]  R2372     2.5125262141227722e-01
    z[8,9,3]  R2373     8.3592817187309265e-02
    z[8,9,3]  R2374     -4.9714568257331848e-01
    z[8,9,3]  R2375     -5.9920862317085266e-02
    z[8,9,3]  R2376     1.8090160191059113e-01
    z[8,9,3]  R2377     -2.1851888298988342e-01
    z[8,9,3]  R2378     -0.518419623374939
    z[8,9,3]  R2379     -7.6481819152832031e-01
    z[8,9,3]  R2380     0.572091817855835
    z[8,9,3]  R2381     7.3339510709047318e-03
    z[8,9,3]  R2382     4.2166435718536377e-01
    z[8,9,3]  R2383     9.6186205744743347e-02
    z[8,9,3]  R2384     -2.6171660423278809e-01
    z[8,9,3]  R2385     -1.6528908908367157e-01
    z[8,9,3]  R2386     -2.3276420310139656e-02
    z[8,9,3]  R2387     8.3589881658554077e-01
    z[8,9,3]  R2388     -2.9706087708473206e-01
    z[8,9,3]  R2389     3.1430311501026154e-02
    z[8,9,3]  R2390     -2.3815210163593292e-01
    z[8,9,3]  R2391     1.2543287873268127e-01
    z[8,9,3]  R2392     7.5945779681205750e-03
    z[8,9,3]  R2393     2.1967248618602753e-01
    z[8,9,3]  R2394     -1.7578256130218506e-01
    z[8,9,3]  R2395     2.7775728702545166e-01
    z[8,9,3]  R2396     0.0916222333908081
    z[8,9,3]  R2397     -1.2926568090915680e-01
    z[8,9,3]  R2398     0.0892622321844101
    z[8,9,3]  R2399     -4.6714410185813904e-01
    z[8,9,3]  R2400     -1.3658659160137177e-01
    z[8,9,3]  R2401     -5.4128553718328476e-02
    z[8,9,3]  R2402     -2.3920129239559174e-01
    z[8,9,3]  R2403     3.6994791030883789e-01
    z[8,9,3]  R2404     0.219553142786026
    z[8,9,3]  R2405     2.1473543345928192e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2346     -1
    z[8,9,4]  R2347     1
    z[8,9,4]  R2352     -1.3234589993953705e-01
    z[8,9,4]  R2353     -7.7655291557312012e-01
    z[8,9,4]  R2354     -1.2535287439823151e-01
    z[8,9,4]  R2355     2.5612282752990723e-01
    z[8,9,4]  R2356     1.5100137889385223e-01
    z[8,9,4]  R2357     -3.5049033164978027e-01
    z[8,9,4]  R2358     -2.7637195587158203e-01
    z[8,9,4]  R2359     -4.8712566494941711e-01
    z[8,9,4]  R2360     2.1780742332339287e-02
    z[8,9,4]  R2361     7.4842788279056549e-02
    z[8,9,4]  R2362     -0.0647103488445282
    z[8,9,4]  R2363     -1.8469931185245514e-01
    z[8,9,4]  R2364     -2.3780560493469238e-01
    z[8,9,4]  R2365     -3.2354512810707092e-01
    z[8,9,4]  R2366     -6.7800402641296387e-01
    z[8,9,4]  R2367     1.6613423824310303e-01
    z[8,9,4]  R2368     -2.0452244579792023e-01
    z[8,9,4]  R2369     4.9505016207695007e-01
    z[8,9,4]  R2370     1.1797765642404556e-01
    z[8,9,4]  R2371     6.3076001405715942e-01
    z[8,9,4]  R2372     4.1038030385971069e-01
    z[8,9,4]  R2373     -7.8159511089324951e-02
    z[8,9,4]  R2374     2.5209732353687286e-02
    z[8,9,4]  R2375     -8.7192952632904053e-02
    z[8,9,4]  R2376     1.4575250446796417e-01
    z[8,9,4]  R2377     -4.7126278281211853e-02
    z[8,9,4]  R2378     1.8223161995410919e-01
    z[8,9,4]  R2379     1.9964620471000671e-01
    z[8,9,4]  R2380     2.1644271910190582e-01
    z[8,9,4]  R2381     1.6444487869739532e-01
    z[8,9,4]  R2382     0.288414865732193
    z[8,9,4]  R2383     -2.9510203003883362e-01
    z[8,9,4]  R2384     4.1223824024200439e-01
    z[8,9,4]  R2385     -5.1926040649414062e-01
    z[8,9,4]  R2386     5.5175840854644775e-01
    z[8,9,4]  R2387     3.1843644380569458e-01
    z[8,9,4]  R2388     -3.8677820563316345e-01
    z[8,9,4]  R2389     4.7104689292609692e-03
    z[8,9,4]  R2390     9.0189658105373383e-02
    z[8,9,4]  R2391     -5.2306872606277466e-01
    z[8,9,4]  R2392     -2.5491744279861450e-01
    z[8,9,4]  R2393     -3.1762102246284485e-01
    z[8,9,4]  R2394     1.1221686005592346e-01
    z[8,9,4]  R2395     1.0469968616962433e-01
    z[8,9,4]  R2396     3.0588868260383606e-01
    z[8,9,4]  R2397     -1.2397108227014542e-01
    z[8,9,4]  R2398     -4.1775055229663849e-02
    z[8,9,4]  R2399     -1.3703427277505398e-02
    z[8,9,4]  R2400     -9.8864041268825531e-02
    z[8,9,4]  R2401     1.1068919301033020e-01
    z[8,9,4]  R2402     7.9923301935195923e-02
    z[8,9,4]  R2403     -1.5262781083583832e-01
    z[8,9,4]  R2404     4.1960358619689941e-01
    z[8,9,4]  R2405     4.2174946516752243e-02
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2348     -1
    z[8,9,5]  R2349     1
    z[8,9,5]  R2352     -8.0316364765167236e-01
    z[8,9,5]  R2353     8.3404947072267532e-03
    z[8,9,5]  R2354     1.0405653715133667e-01
    z[8,9,5]  R2355     3.6442485451698303e-01
    z[8,9,5]  R2356     -1.1600332707166672e-01
    z[8,9,5]  R2357     1.0517539456486702e-02
    z[8,9,5]  R2358     1.3749845325946808e-01
    z[8,9,5]  R2359     1.0967095941305161e-01
    z[8,9,5]  R2360     -7.9711824655532837e-02
    z[8,9,5]  R2361     2.2350908815860748e-01
    z[8,9,5]  R2362     0.320212721824646
    z[8,9,5]  R2363     2.7429682016372681e-01
    z[8,9,5]  R2364     2.4613082408905029e-01
    z[8,9,5]  R2365     2.1101389080286026e-02
    z[8,9,5]  R2366     4.2020749300718307e-02
    z[8,9,5]  R2367     -0.0749799907207489
    z[8,9,5]  R2368     1.3308162987232208e-01
    z[8,9,5]  R2369     5.0079214572906494e-01
    z[8,9,5]  R2370     4.7471746802330017e-01
    z[8,9,5]  R2371     2.4731396138668060e-01
    z[8,9,5]  R2372     -2.0713052153587341e-01
    z[8,9,5]  R2373     -3.2994800806045532e-01
    z[8,9,5]  R2374     1.1634192615747452e-01
    z[8,9,5]  R2375     -9.8115660250186920e-02
    z[8,9,5]  R2376     4.3850308656692505e-01
    z[8,9,5]  R2377     5.2142363786697388e-01
    z[8,9,5]  R2378     -1.7224879562854767e-01
    z[8,9,5]  R2379     1.4397594332695007e-01
    z[8,9,5]  R2380     -1.7490822076797485e-01
    z[8,9,5]  R2381     -3.5582467913627625e-01
    z[8,9,5]  R2382     -5.4397702217102051e-01
    z[8,9,5]  R2383     8.5211597383022308e-02
    z[8,9,5]  R2384     -6.9079703092575073e-01
    z[8,9,5]  R2385     -3.5456809401512146e-01
    z[8,9,5]  R2386     4.3455553054809570e-01
    z[8,9,5]  R2387     -3.6502447724342346e-01
    z[8,9,5]  R2388     2.9783430695533752e-01
    z[8,9,5]  R2389     -7.5113177299499512e-02
    z[8,9,5]  R2390     -2.1189087629318237e-01
    z[8,9,5]  R2391     -2.4571208655834198e-01
    z[8,9,5]  R2392     -1.3572596013545990e-02
    z[8,9,5]  R2393     1.6685511171817780e-01
    z[8,9,5]  R2394     1.4573629200458527e-01
    z[8,9,5]  R2395     3.6457675695419312e-01
    z[8,9,5]  R2396     1.9797615706920624e-01
    z[8,9,5]  R2397     -3.6120936274528503e-01
    z[8,9,5]  R2398     -2.0752865076065063e-01
    z[8,9,5]  R2399     1.2425759434700012e-01
    z[8,9,5]  R2400     5.2669537067413330e-01
    z[8,9,5]  R2401     0.620917022228241
    z[8,9,5]  R2402     5.0102800130844116e-01
    z[8,9,5]  R2403     -5.2984073758125305e-02
    z[8,9,5]  R2404     5.0770413875579834e-01
    z[8,9,5]  R2405     -4.6820670366287231e-01
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2350     -1
    z[8,9,6]  R2351     1
    z[8,9,6]  R2352     3.6107870936393738e-01
    z[8,9,6]  R2353     4.5583018660545349e-01
    z[8,9,6]  R2354     2.0975235104560852e-01
    z[8,9,6]  R2355     7.8361243009567261e-01
    z[8,9,6]  R2356     -3.1017291545867920e-01
    z[8,9,6]  R2357     7.4143260717391968e-02
    z[8,9,6]  R2358     3.1302359700202942e-01
    z[8,9,6]  R2359     1.7225943505764008e-01
    z[8,9,6]  R2360     4.7340974211692810e-01
    z[8,9,6]  R2361     1.9577975571155548e-01
    z[8,9,6]  R2362     5.8809602633118629e-03
    z[8,9,6]  R2363     -4.3160450458526611e-01
    z[8,9,6]  R2364     -0.0836590826511383
    z[8,9,6]  R2365     2.9482778906822205e-01
    z[8,9,6]  R2366     -1.6677691042423248e-01
    z[8,9,6]  R2367     -3.1339681148529053e-01
    z[8,9,6]  R2368     2.9812278226017952e-03
    z[8,9,6]  R2369     -1.4244405925273895e-01
    z[8,9,6]  R2370     -5.6648272275924683e-01
    z[8,9,6]  R2371     2.6795610785484314e-01
    z[8,9,6]  R2372     -1.3899274170398712e-01
    z[8,9,6]  R2373     -0.302824467420578
    z[8,9,6]  R2374     -1.4386588335037231e-01
    z[8,9,6]  R2375     -4.9705934524536133e-01
    z[8,9,6]  R2376     -5.6827610731124878e-01
    z[8,9,6]  R2377     -2.8039899468421936e-01
    z[8,9,6]  R2378     1.0525915026664734e-01
    z[8,9,6]  R2379     2.3873572051525116e-01
    z[8,9,6]  R2380     3.6680704355239868e-01
    z[8,9,6]  R2381     -2.5111767649650574e-01
    z[8,9,6]  R2382     -7.3228485416620970e-04
    z[8,9,6]  R2383     -0.830229640007019
    z[8,9,6]  R2384     4.2578735947608948e-01
    z[8,9,6]  R2385     -3.1237217783927917e-01
    z[8,9,6]  R2386     5.5415272712707520e-01
    z[8,9,6]  R2387     7.5381986796855927e-02
    z[8,9,6]  R2388     7.8473798930644989e-02
    z[8,9,6]  R2389     3.1050935387611389e-01
    z[8,9,6]  R2390     -1.0989652946591377e-02
    z[8,9,6]  R2391     1.1293949186801910e-01
    z[8,9,6]  R2392     -8.6390130221843719e-02
    z[8,9,6]  R2393     -3.6033976078033447e-01
    z[8,9,6]  R2394     5.6928880512714386e-02
    z[8,9,6]  R2395     3.1745247542858124e-02
    z[8,9,6]  R2396     2.5697934627532959e-01
    z[8,9,6]  R2397     -1.6448059678077698e-01
    z[8,9,6]  R2398     9.1096490621566772e-02
    z[8,9,6]  R2399     -6.5622046589851379e-02
    z[8,9,6]  R2400     -0.127666175365448
    z[8,9,6]  R2401     -1.2923667207360268e-02
    z[8,9,6]  R2402     1.5111543238162994e-01
    z[8,9,6]  R2403     4.7627137973904610e-04
    z[8,9,6]  R2404     1.5492413938045502e-01
    z[8,9,6]  R2405     -4.2612094432115555e-02
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2406     -1
    z[9,8,0]  R2407     1
    z[9,8,0]  R2420     -4.3440824747085571e-01
    z[9,8,0]  R2421     2.1972376853227615e-02
    z[9,8,0]  R2422     -0.244341641664505
    z[9,8,0]  R2423     -6.8289309740066528e-01
    z[9,8,0]  R2424     -1.3521650806069374e-02
    z[9,8,0]  R2425     1.6398295760154724e-01
    z[9,8,0]  R2426     3.6707723047584295e-03
    z[9,8,0]  R2427     2.1146349608898163e-02
    z[9,8,0]  R2428     4.4592958875000477e-03
    z[9,8,0]  R2429     4.7170282341539860e-03
    z[9,8,0]  R2430     3.2629200816154480e-01
    z[9,8,0]  R2431     5.8327841758728027e-01
    z[9,8,0]  R2432     6.7834746837615967e-01
    z[9,8,0]  R2433     4.8005494475364685e-01
    z[9,8,0]  R2434     6.3030862808227539e-01
    z[9,8,0]  R2435     6.2125825881958008e-01
    z[9,8,0]  R2436     2.4060758948326111e-01
    z[9,8,0]  R2437     -9.2143654823303223e-02
    z[9,8,0]  R2438     -3.8049963116645813e-01
    z[9,8,0]  R2439     -6.6452682018280029e-01
    z[9,8,0]  R2440     -5.9119069576263428e-01
    z[9,8,0]  R2441     -6.5236341953277588e-01
    z[9,8,0]  R2442     2.9052925109863281e-01
    z[9,8,0]  R2443     5.5014067888259888e-01
    z[9,8,0]  R2444     -0.0651671439409256
    z[9,8,0]  R2445     -3.8651326298713684e-01
    z[9,8,0]  R2446     -8.7483161687850952e-01
    z[9,8,0]  R2447     -1.0937790572643280e-01
    z[9,8,0]  R2448     -7.1644246578216553e-01
    z[9,8,0]  R2449     -7.8381127119064331e-01
    z[9,8,0]  R2450     -8.2541257143020630e-01
    z[9,8,0]  R2451     -8.2917296886444092e-01
    z[9,8,0]  R2452     -7.0350253582000732e-01
    z[9,8,0]  R2453     -7.1030479669570923e-01
    z[9,8,0]  R2454     7.0778125524520874e-01
    z[9,8,0]  R2455     3.0961731076240540e-01
    z[9,8,0]  R2456     5.5427330732345581e-01
    z[9,8,0]  R2457     5.3040701150894165e-01
    z[9,8,0]  R2458     6.3643324375152588e-01
    z[9,8,0]  R2459     3.0334493517875671e-01
    z[9,8,0]  R2460     1.4406631886959076e-01
    z[9,8,0]  R2461     4.1738396883010864e-01
    z[9,8,0]  R2462     3.3460852503776550e-01
    z[9,8,0]  R2463     5.0922924280166626e-01
    z[9,8,0]  R2464     0.789631187915802
    z[9,8,0]  R2465     0.835048258304596
    z[9,8,0]  R2466     0.459786057472229
    z[9,8,0]  R2467     6.5228879451751709e-01
    z[9,8,0]  R2468     5.4485547542572021e-01
    z[9,8,0]  R2469     0.624904215335846
    z[9,8,0]  R2470     7.1223413944244385e-01
    z[9,8,0]  R2471     4.7081285715103149e-01
    z[9,8,0]  R2472     5.9584714472293854e-02
    z[9,8,0]  R2473     3.8621027022600174e-02
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2408     -1
    z[9,8,1]  R2409     1
    z[9,8,1]  R2420     -5.0435990095138550e-01
    z[9,8,1]  R2421     -4.0948277711868286e-01
    z[9,8,1]  R2422     -1.7903269827365875e-01
    z[9,8,1]  R2423     3.6663429345935583e-03
    z[9,8,1]  R2424     -3.2231029868125916e-01
    z[9,8,1]  R2425     -3.7053756415843964e-02
    z[9,8,1]  R2426     0.81685870885849
    z[9,8,1]  R2427     7.0958900451660156e-01
    z[9,8,1]  R2428     7.1484923362731934e-01
    z[9,8,1]  R2429     7.7314484119415283e-01
    z[9,8,1]  R2430     -6.0189563035964966e-01
    z[9,8,1]  R2431     5.9015500545501709e-01
    z[9,8,1]  R2432     6.5964990854263306e-01
    z[9,8,1]  R2433     7.3843461275100708e-01
    z[9,8,1]  R2434     6.0166496038436890e-01
    z[9,8,1]  R2435     6.2605887651443481e-01
    z[9,8,1]  R2436     7.6555055379867554e-01
    z[9,8,1]  R2437     -6.4276337623596191e-01
    z[9,8,1]  R2438     -6.0771763324737549e-01
    z[9,8,1]  R2439     3.8339450955390930e-01
    z[9,8,1]  R2440     -5.5138278007507324e-01
    z[9,8,1]  R2441     3.2223567366600037e-01
    z[9,8,1]  R2442     -5.0489884614944458e-01
    z[9,8,1]  R2443     6.5147417783737183e-01
    z[9,8,1]  R2444     -3.2979834079742432e-01
    z[9,8,1]  R2445     -1.1426496505737305e-01
    z[9,8,1]  R2446     -0.0662216767668724
    z[9,8,1]  R2447     -3.3748188614845276e-01
    z[9,8,1]  R2448     -4.0812242031097412e-01
    z[9,8,1]  R2449     -5.6595962494611740e-02
    z[9,8,1]  R2450     -5.6493185460567474e-02
    z[9,8,1]  R2451     1.6281509399414062e-01
    z[9,8,1]  R2452     -1.4227128028869629e-01
    z[9,8,1]  R2453     -2.3268491029739380e-01
    z[9,8,1]  R2454     4.0143576264381409e-01
    z[9,8,1]  R2455     -5.1193749904632568e-01
    z[9,8,1]  R2456     6.4949011802673340e-01
    z[9,8,1]  R2457     6.8918168544769287e-01
    z[9,8,1]  R2458     2.4982081353664398e-01
    z[9,8,1]  R2459     3.2470539212226868e-01
    z[9,8,1]  R2460     7.5429028272628784e-01
    z[9,8,1]  R2461     4.4429680705070496e-01
    z[9,8,1]  R2462     4.2257469892501831e-01
    z[9,8,1]  R2463     4.1837745904922485e-01
    z[9,8,1]  R2464     4.1784796863794327e-02
    z[9,8,1]  R2465     -2.0650871098041534e-01
    z[9,8,1]  R2466     -3.6184465885162354e-01
    z[9,8,1]  R2467     -3.6312100291252136e-01
    z[9,8,1]  R2468     2.7227425575256348e-01
    z[9,8,1]  R2469     2.6621243357658386e-01
    z[9,8,1]  R2470     -3.8219049572944641e-01
    z[9,8,1]  R2471     -2.7316927909851074e-01
    z[9,8,1]  R2472     6.4165496826171875e-01
    z[9,8,1]  R2473     8.5204273462295532e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2410     -1
    z[9,8,2]  R2411     1
    z[9,8,2]  R2420     3.8668855559080839e-03
    z[9,8,2]  R2421     -1.9738748669624329e-01
    z[9,8,2]  R2422     -1.0636299848556519e-01
    z[9,8,2]  R2423     -1.1574492603540421e-01
    z[9,8,2]  R2424     -3.0826982855796814e-01
    z[9,8,2]  R2425     -1.8078340590000153e-01
    z[9,8,2]  R2426     -4.7306194901466370e-03
    z[9,8,2]  R2427     6.2687176465988159e-01
    z[9,8,2]  R2428     6.1571222543716431e-01
    z[9,8,2]  R2429     -1.9940081238746643e-01
    z[9,8,2]  R2430     -6.7717593908309937e-01
    z[9,8,2]  R2431     6.8402059376239777e-02
    z[9,8,2]  R2432     1.9166319072246552e-01
    z[9,8,2]  R2433     -0.047185268253088
    z[9,8,2]  R2434     -1.8307060003280640e-01
    z[9,8,2]  R2435     1.8023288249969482e-01
    z[9,8,2]  R2436     -5.4310280084609985e-01
    z[9,8,2]  R2437     5.8327281475067139e-01
    z[9,8,2]  R2438     4.0467596054077148e-01
    z[9,8,2]  R2439     1.0259532183408737e-01
    z[9,8,2]  R2440     9.4871595501899719e-02
    z[9,8,2]  R2441     -5.5463671684265137e-01
    z[9,8,2]  R2442     3.9323535561561584e-01
    z[9,8,2]  R2443     -6.3270837068557739e-02
    z[9,8,2]  R2444     1.2959934771060944e-01
    z[9,8,2]  R2445     -1.3875004649162292e-01
    z[9,8,2]  R2446     -1.8310436606407166e-01
    z[9,8,2]  R2447     -6.7341946065425873e-02
    z[9,8,2]  R2448     -3.3988818526268005e-01
    z[9,8,2]  R2449     5.0396567583084106e-01
    z[9,8,2]  R2450     1.8700838088989258e-01
    z[9,8,2]  R2451     0.0691818818449974
    z[9,8,2]  R2452     4.2266142368316650e-01
    z[9,8,2]  R2453     4.0819045901298523e-01
    z[9,8,2]  R2454     4.3854832649230957e-01
    z[9,8,2]  R2455     3.8465568423271179e-01
    z[9,8,2]  R2456     -2.6800140738487244e-01
    z[9,8,2]  R2457     -1.2427277117967606e-01
    z[9,8,2]  R2458     2.0401073992252350e-01
    z[9,8,2]  R2459     5.3101760149002075e-01
    z[9,8,2]  R2460     -1.7486673593521118e-01
    z[9,8,2]  R2461     3.3118656277656555e-01
    z[9,8,2]  R2462     -5.0349120050668716e-02
    z[9,8,2]  R2463     1.7553143203258514e-01
    z[9,8,2]  R2464     -2.8456050157546997e-01
    z[9,8,2]  R2465     2.1536806225776672e-01
    z[9,8,2]  R2466     -6.1289733648300171e-01
    z[9,8,2]  R2467     -4.1806069016456604e-01
    z[9,8,2]  R2468     2.4455563724040985e-01
    z[9,8,2]  R2469     -3.7168264389038086e-01
    z[9,8,2]  R2470     6.2742471694946289e-02
    z[9,8,2]  R2471     -3.4416135400533676e-02
    z[9,8,2]  R2472     2.1319410204887390e-01
    z[9,8,2]  R2473     -2.3614510893821716e-01
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2412     -1
    z[9,8,3]  R2413     1
    z[9,8,3]  R2420     4.2166435718536377e-01
    z[9,8,3]  R2421     9.6186205744743347e-02
    z[9,8,3]  R2422     -2.6171660423278809e-01
    z[9,8,3]  R2423     -1.6528908908367157e-01
    z[9,8,3]  R2424     -2.3276420310139656e-02
    z[9,8,3]  R2425     8.3589881658554077e-01
    z[9,8,3]  R2426     -2.9706087708473206e-01
    z[9,8,3]  R2427     3.1430311501026154e-02
    z[9,8,3]  R2428     -2.3815210163593292e-01
    z[9,8,3]  R2429     1.2543287873268127e-01
    z[9,8,3]  R2430     7.5945779681205750e-03
    z[9,8,3]  R2431     2.1967248618602753e-01
    z[9,8,3]  R2432     -1.7578256130218506e-01
    z[9,8,3]  R2433     2.7775728702545166e-01
    z[9,8,3]  R2434     0.0916222333908081
    z[9,8,3]  R2435     -1.2926568090915680e-01
    z[9,8,3]  R2436     0.0892622321844101
    z[9,8,3]  R2437     -4.6714410185813904e-01
    z[9,8,3]  R2438     -1.3658659160137177e-01
    z[9,8,3]  R2439     -5.4128553718328476e-02
    z[9,8,3]  R2440     -2.3920129239559174e-01
    z[9,8,3]  R2441     3.6994791030883789e-01
    z[9,8,3]  R2442     0.219553142786026
    z[9,8,3]  R2443     2.1473543345928192e-01
    z[9,8,3]  R2444     2.7789419889450073e-01
    z[9,8,3]  R2445     8.6106359958648682e-02
    z[9,8,3]  R2446     3.5527431964874268e-01
    z[9,8,3]  R2447     -2.3907026648521423e-01
    z[9,8,3]  R2448     2.6862043142318726e-01
    z[9,8,3]  R2449     0.00202555931173265
    z[9,8,3]  R2450     -2.9539713263511658e-01
    z[9,8,3]  R2451     4.6744119375944138e-02
    z[9,8,3]  R2452     -2.7432683110237122e-01
    z[9,8,3]  R2453     -4.2522680759429932e-01
    z[9,8,3]  R2454     -1.9700820744037628e-01
    z[9,8,3]  R2455     -4.4549080729484558e-01
    z[9,8,3]  R2456     2.7383938431739807e-01
    z[9,8,3]  R2457     1.9027142226696014e-01
    z[9,8,3]  R2458     -4.0646929293870926e-02
    z[9,8,3]  R2459     6.2380152940750122e-01
    z[9,8,3]  R2460     -5.6583017110824585e-01
    z[9,8,3]  R2461     5.0485078245401382e-02
    z[9,8,3]  R2462     3.8308575749397278e-01
    z[9,8,3]  R2463     -6.3338160514831543e-02
    z[9,8,3]  R2464     2.5125262141227722e-01
    z[9,8,3]  R2465     8.3592817187309265e-02
    z[9,8,3]  R2466     -4.9714568257331848e-01
    z[9,8,3]  R2467     -5.9920862317085266e-02
    z[9,8,3]  R2468     1.8090160191059113e-01
    z[9,8,3]  R2469     -2.1851888298988342e-01
    z[9,8,3]  R2470     -0.518419623374939
    z[9,8,3]  R2471     -7.6481819152832031e-01
    z[9,8,3]  R2472     0.572091817855835
    z[9,8,3]  R2473     7.3339510709047318e-03
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2414     -1
    z[9,8,4]  R2415     1
    z[9,8,4]  R2420     0.288414865732193
    z[9,8,4]  R2421     -2.9510203003883362e-01
    z[9,8,4]  R2422     4.1223824024200439e-01
    z[9,8,4]  R2423     -5.1926040649414062e-01
    z[9,8,4]  R2424     5.5175840854644775e-01
    z[9,8,4]  R2425     3.1843644380569458e-01
    z[9,8,4]  R2426     -3.8677820563316345e-01
    z[9,8,4]  R2427     4.7104689292609692e-03
    z[9,8,4]  R2428     9.0189658105373383e-02
    z[9,8,4]  R2429     -5.2306872606277466e-01
    z[9,8,4]  R2430     -2.5491744279861450e-01
    z[9,8,4]  R2431     -3.1762102246284485e-01
    z[9,8,4]  R2432     1.1221686005592346e-01
    z[9,8,4]  R2433     1.0469968616962433e-01
    z[9,8,4]  R2434     3.0588868260383606e-01
    z[9,8,4]  R2435     -1.2397108227014542e-01
    z[9,8,4]  R2436     -4.1775055229663849e-02
    z[9,8,4]  R2437     -1.3703427277505398e-02
    z[9,8,4]  R2438     -9.8864041268825531e-02
    z[9,8,4]  R2439     1.1068919301033020e-01
    z[9,8,4]  R2440     7.9923301935195923e-02
    z[9,8,4]  R2441     -1.5262781083583832e-01
    z[9,8,4]  R2442     4.1960358619689941e-01
    z[9,8,4]  R2443     4.2174946516752243e-02
    z[9,8,4]  R2444     -1.3234589993953705e-01
    z[9,8,4]  R2445     -7.7655291557312012e-01
    z[9,8,4]  R2446     -1.2535287439823151e-01
    z[9,8,4]  R2447     2.5612282752990723e-01
    z[9,8,4]  R2448     1.5100137889385223e-01
    z[9,8,4]  R2449     -3.5049033164978027e-01
    z[9,8,4]  R2450     -2.7637195587158203e-01
    z[9,8,4]  R2451     -4.8712566494941711e-01
    z[9,8,4]  R2452     2.1780742332339287e-02
    z[9,8,4]  R2453     7.4842788279056549e-02
    z[9,8,4]  R2454     -0.0647103488445282
    z[9,8,4]  R2455     -1.8469931185245514e-01
    z[9,8,4]  R2456     -2.3780560493469238e-01
    z[9,8,4]  R2457     -3.2354512810707092e-01
    z[9,8,4]  R2458     -6.7800402641296387e-01
    z[9,8,4]  R2459     1.6613423824310303e-01
    z[9,8,4]  R2460     -2.0452244579792023e-01
    z[9,8,4]  R2461     4.9505016207695007e-01
    z[9,8,4]  R2462     1.1797765642404556e-01
    z[9,8,4]  R2463     6.3076001405715942e-01
    z[9,8,4]  R2464     4.1038030385971069e-01
    z[9,8,4]  R2465     -7.8159511089324951e-02
    z[9,8,4]  R2466     2.5209732353687286e-02
    z[9,8,4]  R2467     -8.7192952632904053e-02
    z[9,8,4]  R2468     1.4575250446796417e-01
    z[9,8,4]  R2469     -4.7126278281211853e-02
    z[9,8,4]  R2470     1.8223161995410919e-01
    z[9,8,4]  R2471     1.9964620471000671e-01
    z[9,8,4]  R2472     2.1644271910190582e-01
    z[9,8,4]  R2473     1.6444487869739532e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2416     -1
    z[9,8,5]  R2417     1
    z[9,8,5]  R2420     -5.4397702217102051e-01
    z[9,8,5]  R2421     8.5211597383022308e-02
    z[9,8,5]  R2422     -6.9079703092575073e-01
    z[9,8,5]  R2423     -3.5456809401512146e-01
    z[9,8,5]  R2424     4.3455553054809570e-01
    z[9,8,5]  R2425     -3.6502447724342346e-01
    z[9,8,5]  R2426     2.9783430695533752e-01
    z[9,8,5]  R2427     -7.5113177299499512e-02
    z[9,8,5]  R2428     -2.1189087629318237e-01
    z[9,8,5]  R2429     -2.4571208655834198e-01
    z[9,8,5]  R2430     -1.3572596013545990e-02
    z[9,8,5]  R2431     1.6685511171817780e-01
    z[9,8,5]  R2432     1.4573629200458527e-01
    z[9,8,5]  R2433     3.6457675695419312e-01
    z[9,8,5]  R2434     1.9797615706920624e-01
    z[9,8,5]  R2435     -3.6120936274528503e-01
    z[9,8,5]  R2436     -2.0752865076065063e-01
    z[9,8,5]  R2437     1.2425759434700012e-01
    z[9,8,5]  R2438     5.2669537067413330e-01
    z[9,8,5]  R2439     0.620917022228241
    z[9,8,5]  R2440     5.0102800130844116e-01
    z[9,8,5]  R2441     -5.2984073758125305e-02
    z[9,8,5]  R2442     5.0770413875579834e-01
    z[9,8,5]  R2443     -4.6820670366287231e-01
    z[9,8,5]  R2444     -8.0316364765167236e-01
    z[9,8,5]  R2445     8.3404947072267532e-03
    z[9,8,5]  R2446     1.0405653715133667e-01
    z[9,8,5]  R2447     3.6442485451698303e-01
    z[9,8,5]  R2448     -1.1600332707166672e-01
    z[9,8,5]  R2449     1.0517539456486702e-02
    z[9,8,5]  R2450     1.3749845325946808e-01
    z[9,8,5]  R2451     1.0967095941305161e-01
    z[9,8,5]  R2452     -7.9711824655532837e-02
    z[9,8,5]  R2453     2.2350908815860748e-01
    z[9,8,5]  R2454     0.320212721824646
    z[9,8,5]  R2455     2.7429682016372681e-01
    z[9,8,5]  R2456     2.4613082408905029e-01
    z[9,8,5]  R2457     2.1101389080286026e-02
    z[9,8,5]  R2458     4.2020749300718307e-02
    z[9,8,5]  R2459     -0.0749799907207489
    z[9,8,5]  R2460     1.3308162987232208e-01
    z[9,8,5]  R2461     5.0079214572906494e-01
    z[9,8,5]  R2462     4.7471746802330017e-01
    z[9,8,5]  R2463     2.4731396138668060e-01
    z[9,8,5]  R2464     -2.0713052153587341e-01
    z[9,8,5]  R2465     -3.2994800806045532e-01
    z[9,8,5]  R2466     1.1634192615747452e-01
    z[9,8,5]  R2467     -9.8115660250186920e-02
    z[9,8,5]  R2468     4.3850308656692505e-01
    z[9,8,5]  R2469     5.2142363786697388e-01
    z[9,8,5]  R2470     -1.7224879562854767e-01
    z[9,8,5]  R2471     1.4397594332695007e-01
    z[9,8,5]  R2472     -1.7490822076797485e-01
    z[9,8,5]  R2473     -3.5582467913627625e-01
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2418     -1
    z[9,8,6]  R2419     1
    z[9,8,6]  R2420     -7.3228485416620970e-04
    z[9,8,6]  R2421     -0.830229640007019
    z[9,8,6]  R2422     4.2578735947608948e-01
    z[9,8,6]  R2423     -3.1237217783927917e-01
    z[9,8,6]  R2424     5.5415272712707520e-01
    z[9,8,6]  R2425     7.5381986796855927e-02
    z[9,8,6]  R2426     7.8473798930644989e-02
    z[9,8,6]  R2427     3.1050935387611389e-01
    z[9,8,6]  R2428     -1.0989652946591377e-02
    z[9,8,6]  R2429     1.1293949186801910e-01
    z[9,8,6]  R2430     -8.6390130221843719e-02
    z[9,8,6]  R2431     -3.6033976078033447e-01
    z[9,8,6]  R2432     5.6928880512714386e-02
    z[9,8,6]  R2433     3.1745247542858124e-02
    z[9,8,6]  R2434     2.5697934627532959e-01
    z[9,8,6]  R2435     -1.6448059678077698e-01
    z[9,8,6]  R2436     9.1096490621566772e-02
    z[9,8,6]  R2437     -6.5622046589851379e-02
    z[9,8,6]  R2438     -0.127666175365448
    z[9,8,6]  R2439     -1.2923667207360268e-02
    z[9,8,6]  R2440     1.5111543238162994e-01
    z[9,8,6]  R2441     4.7627137973904610e-04
    z[9,8,6]  R2442     1.5492413938045502e-01
    z[9,8,6]  R2443     -4.2612094432115555e-02
    z[9,8,6]  R2444     3.6107870936393738e-01
    z[9,8,6]  R2445     4.5583018660545349e-01
    z[9,8,6]  R2446     2.0975235104560852e-01
    z[9,8,6]  R2447     7.8361243009567261e-01
    z[9,8,6]  R2448     -3.1017291545867920e-01
    z[9,8,6]  R2449     7.4143260717391968e-02
    z[9,8,6]  R2450     3.1302359700202942e-01
    z[9,8,6]  R2451     1.7225943505764008e-01
    z[9,8,6]  R2452     4.7340974211692810e-01
    z[9,8,6]  R2453     1.9577975571155548e-01
    z[9,8,6]  R2454     5.8809602633118629e-03
    z[9,8,6]  R2455     -4.3160450458526611e-01
    z[9,8,6]  R2456     -0.0836590826511383
    z[9,8,6]  R2457     2.9482778906822205e-01
    z[9,8,6]  R2458     -1.6677691042423248e-01
    z[9,8,6]  R2459     -3.1339681148529053e-01
    z[9,8,6]  R2460     2.9812278226017952e-03
    z[9,8,6]  R2461     -1.4244405925273895e-01
    z[9,8,6]  R2462     -5.6648272275924683e-01
    z[9,8,6]  R2463     2.6795610785484314e-01
    z[9,8,6]  R2464     -1.3899274170398712e-01
    z[9,8,6]  R2465     -0.302824467420578
    z[9,8,6]  R2466     -1.4386588335037231e-01
    z[9,8,6]  R2467     -4.9705934524536133e-01
    z[9,8,6]  R2468     -5.6827610731124878e-01
    z[9,8,6]  R2469     -2.8039899468421936e-01
    z[9,8,6]  R2470     1.0525915026664734e-01
    z[9,8,6]  R2471     2.3873572051525116e-01
    z[9,8,6]  R2472     3.6680704355239868e-01
    z[9,8,6]  R2473     -2.5111767649650574e-01
    z[9,10,0]  R83       -1
    z[9,10,0]  R92       1
    z[9,10,0]  R2474     -1
    z[9,10,0]  R2475     1
    z[9,10,0]  R2488     -4.3440824747085571e-01
    z[9,10,0]  R2489     2.1972376853227615e-02
    z[9,10,0]  R2490     -0.244341641664505
    z[9,10,0]  R2491     -6.8289309740066528e-01
    z[9,10,0]  R2492     -1.3521650806069374e-02
    z[9,10,0]  R2493     1.6398295760154724e-01
    z[9,10,0]  R2494     3.6707723047584295e-03
    z[9,10,0]  R2495     2.1146349608898163e-02
    z[9,10,0]  R2496     4.4592958875000477e-03
    z[9,10,0]  R2497     4.7170282341539860e-03
    z[9,10,0]  R2498     3.2629200816154480e-01
    z[9,10,0]  R2499     5.8327841758728027e-01
    z[9,10,0]  R2500     6.7834746837615967e-01
    z[9,10,0]  R2501     4.8005494475364685e-01
    z[9,10,0]  R2502     6.3030862808227539e-01
    z[9,10,0]  R2503     6.2125825881958008e-01
    z[9,10,0]  R2504     2.4060758948326111e-01
    z[9,10,0]  R2505     -9.2143654823303223e-02
    z[9,10,0]  R2506     -3.8049963116645813e-01
    z[9,10,0]  R2507     -6.6452682018280029e-01
    z[9,10,0]  R2508     -5.9119069576263428e-01
    z[9,10,0]  R2509     -6.5236341953277588e-01
    z[9,10,0]  R2510     2.9052925109863281e-01
    z[9,10,0]  R2511     5.5014067888259888e-01
    z[9,10,0]  R2512     -6.6838681697845459e-01
    z[9,10,0]  R2513     -3.3950451016426086e-01
    z[9,10,0]  R2514     1.0117264464497566e-02
    z[9,10,0]  R2515     -0.0162187647074461
    z[9,10,0]  R2516     -8.2763278484344482e-01
    z[9,10,0]  R2517     -2.7650287747383118e-01
    z[9,10,0]  R2518     2.9769884422421455e-02
    z[9,10,0]  R2519     -1.5378569066524506e-01
    z[9,10,0]  R2520     5.0816637277603149e-01
    z[9,10,0]  R2521     4.3544137477874756e-01
    z[9,10,0]  R2522     2.2410778701305389e-01
    z[9,10,0]  R2523     1.3578887283802032e-01
    z[9,10,0]  R2524     2.4790754914283752e-01
    z[9,10,0]  R2525     4.4172096252441406e-01
    z[9,10,0]  R2526     6.0829824209213257e-01
    z[9,10,0]  R2527     3.7431082129478455e-01
    z[9,10,0]  R2528     2.1239463984966278e-01
    z[9,10,0]  R2529     2.1339268982410431e-01
    z[9,10,0]  R2530     0.872349202632904
    z[9,10,0]  R2531     5.4281413555145264e-01
    z[9,10,0]  R2532     6.7251950502395630e-01
    z[9,10,0]  R2533     4.9651819467544556e-01
    z[9,10,0]  R2534     4.6507778763771057e-01
    z[9,10,0]  R2535     7.3322528600692749e-01
    z[9,10,0]  R2536     3.9651879668235779e-01
    z[9,10,0]  R2537     5.5991929769515991e-01
    z[9,10,0]  R2538     4.7536960244178772e-01
    z[9,10,0]  R2539     7.4354261159896851e-01
    z[9,10,0]  R2540     1.3204505667090416e-02
    z[9,10,0]  R2541     7.8628438711166382e-01
    z[9,10,0]  R2542     7.2115379571914673e-01
    z[9,10,0]  R2543     2.7202799916267395e-01
    z[9,10,0]  R2544     4.1065916419029236e-01
    z[9,10,0]  R2545     0.0442354753613472
    z[9,10,0]  R2546     7.0270322263240814e-02
    z[9,10,0]  R2547     -1.0864923149347305e-01
    z[9,10,0]  R2548     1.6413313150405884e-01
    z[9,10,0]  R2549     0.278475821018219
    z[9,10,1]  R84       -1
    z[9,10,1]  R93       1
    z[9,10,1]  R2476     -1
    z[9,10,1]  R2477     1
    z[9,10,1]  R2488     -5.0435990095138550e-01
    z[9,10,1]  R2489     -4.0948277711868286e-01
    z[9,10,1]  R2490     -1.7903269827365875e-01
    z[9,10,1]  R2491     3.6663429345935583e-03
    z[9,10,1]  R2492     -3.2231029868125916e-01
    z[9,10,1]  R2493     -3.7053756415843964e-02
    z[9,10,1]  R2494     0.81685870885849
    z[9,10,1]  R2495     7.0958900451660156e-01
    z[9,10,1]  R2496     7.1484923362731934e-01
    z[9,10,1]  R2497     7.7314484119415283e-01
    z[9,10,1]  R2498     -6.0189563035964966e-01
    z[9,10,1]  R2499     5.9015500545501709e-01
    z[9,10,1]  R2500     6.5964990854263306e-01
    z[9,10,1]  R2501     7.3843461275100708e-01
    z[9,10,1]  R2502     6.0166496038436890e-01
    z[9,10,1]  R2503     6.2605887651443481e-01
    z[9,10,1]  R2504     7.6555055379867554e-01
    z[9,10,1]  R2505     -6.4276337623596191e-01
    z[9,10,1]  R2506     -6.0771763324737549e-01
    z[9,10,1]  R2507     3.8339450955390930e-01
    z[9,10,1]  R2508     -5.5138278007507324e-01
    z[9,10,1]  R2509     3.2223567366600037e-01
    z[9,10,1]  R2510     -5.0489884614944458e-01
    z[9,10,1]  R2511     6.5147417783737183e-01
    z[9,10,1]  R2512     2.0451097190380096e-01
    z[9,10,1]  R2513     1.6970364749431610e-01
    z[9,10,1]  R2514     3.8651180267333984e-01
    z[9,10,1]  R2515     1.6717033088207245e-01
    z[9,10,1]  R2516     -0.0672031044960022
    z[9,10,1]  R2517     7.9678946733474731e-01
    z[9,10,1]  R2518     -8.5240013897418976e-02
    z[9,10,1]  R2519     -4.0651056915521622e-02
    z[9,10,1]  R2520     -3.5425412654876709e-01
    z[9,10,1]  R2521     3.7549253553152084e-02
    z[9,10,1]  R2522     -8.6507505178451538e-01
    z[9,10,1]  R2523     -5.4049581289291382e-01
    z[9,10,1]  R2524     -6.9356161355972290e-01
    z[9,10,1]  R2525     5.0812023878097534e-01
    z[9,10,1]  R2526     4.7119516134262085e-01
    z[9,10,1]  R2527     4.1220748424530029e-01
    z[9,10,1]  R2528     -1.0398972034454346e-01
    z[9,10,1]  R2529     -2.1055282652378082e-01
    z[9,10,1]  R2530     3.2922258973121643e-01
    z[9,10,1]  R2531     4.6399402618408203e-01
    z[9,10,1]  R2532     4.1465952992439270e-01
    z[9,10,1]  R2533     4.4240096211433411e-01
    z[9,10,1]  R2534     4.7214484214782715e-01
    z[9,10,1]  R2535     3.2677003741264343e-01
    z[9,10,1]  R2536     5.5083340406417847e-01
    z[9,10,1]  R2537     3.9904680848121643e-01
    z[9,10,1]  R2538     3.9580282568931580e-01
    z[9,10,1]  R2539     2.7318182587623596e-01
    z[9,10,1]  R2540     -5.3048763424158096e-02
    z[9,10,1]  R2541     4.3427705764770508e-01
    z[9,10,1]  R2542     3.6531442403793335e-01
    z[9,10,1]  R2543     -3.5306805372238159e-01
    z[9,10,1]  R2544     4.4144666194915771e-01
    z[9,10,1]  R2545     -1.1707927286624908e-01
    z[9,10,1]  R2546     -5.4121665656566620e-02
    z[9,10,1]  R2547     1.4069433510303497e-01
    z[9,10,1]  R2548     -0.326238214969635
    z[9,10,1]  R2549     -2.7720254659652710e-01
    z[9,10,2]  R85       -1
    z[9,10,2]  R94       1
    z[9,10,2]  R2478     -1
    z[9,10,2]  R2479     1
    z[9,10,2]  R2488     3.8668855559080839e-03
    z[9,10,2]  R2489     -1.9738748669624329e-01
    z[9,10,2]  R2490     -1.0636299848556519e-01
    z[9,10,2]  R2491     -1.1574492603540421e-01
    z[9,10,2]  R2492     -3.0826982855796814e-01
    z[9,10,2]  R2493     -1.8078340590000153e-01
    z[9,10,2]  R2494     -4.7306194901466370e-03
    z[9,10,2]  R2495     6.2687176465988159e-01
    z[9,10,2]  R2496     6.1571222543716431e-01
    z[9,10,2]  R2497     -1.9940081238746643e-01
    z[9,10,2]  R2498     -6.7717593908309937e-01
    z[9,10,2]  R2499     6.8402059376239777e-02
    z[9,10,2]  R2500     1.9166319072246552e-01
    z[9,10,2]  R2501     -0.047185268253088
    z[9,10,2]  R2502     -1.8307060003280640e-01
    z[9,10,2]  R2503     1.8023288249969482e-01
    z[9,10,2]  R2504     -5.4310280084609985e-01
    z[9,10,2]  R2505     5.8327281475067139e-01
    z[9,10,2]  R2506     4.0467596054077148e-01
    z[9,10,2]  R2507     1.0259532183408737e-01
    z[9,10,2]  R2508     9.4871595501899719e-02
    z[9,10,2]  R2509     -5.5463671684265137e-01
    z[9,10,2]  R2510     3.9323535561561584e-01
    z[9,10,2]  R2511     -6.3270837068557739e-02
    z[9,10,2]  R2512     1.8299490213394165e-01
    z[9,10,2]  R2513     3.7958872318267822e-01
    z[9,10,2]  R2514     -2.9160553216934204e-01
    z[9,10,2]  R2515     4.5660424232482910e-01
    z[9,10,2]  R2516     -0.388187050819397
    z[9,10,2]  R2517     -1.8965774774551392e-01
    z[9,10,2]  R2518     -1.1527680605649948e-01
    z[9,10,2]  R2519     7.1668088436126709e-01
    z[9,10,2]  R2520     -0.758916437625885
    z[9,10,2]  R2521     -5.8375918865203857e-01
    z[9,10,2]  R2522     -3.4515988826751709e-01
    z[9,10,2]  R2523     -4.1553407907485962e-01
    z[9,10,2]  R2524     -4.1028726100921631e-01
    z[9,10,2]  R2525     3.8359567523002625e-01
    z[9,10,2]  R2526     4.1494885087013245e-01
    z[9,10,2]  R2527     4.8236930370330811e-01
    z[9,10,2]  R2528     1.4560346305370331e-01
    z[9,10,2]  R2529     1.9953136146068573e-01
    z[9,10,2]  R2530     0.0757877379655838
    z[9,10,2]  R2531     1.2136624753475189e-01
    z[9,10,2]  R2532     -2.0224972069263458e-01
    z[9,10,2]  R2533     2.4038438498973846e-01
    z[9,10,2]  R2534     5.5548596382141113e-01
    z[9,10,2]  R2535     4.1592600941658020e-01
    z[9,10,2]  R2536     1.9032983481884003e-01
    z[9,10,2]  R2537     2.3802405595779419e-01
    z[9,10,2]  R2538     4.3518039584159851e-01
    z[9,10,2]  R2539     -0.337252676486969
    z[9,10,2]  R2540     -2.8646349906921387e-01
    z[9,10,2]  R2541     -0.155140221118927
    z[9,10,2]  R2542     4.3472087383270264e-01
    z[9,10,2]  R2543     -1.0040885210037231e-01
    z[9,10,2]  R2544     -2.0830640196800232e-01
    z[9,10,2]  R2545     -3.1272897124290466e-01
    z[9,10,2]  R2546     6.0756152868270874e-01
    z[9,10,2]  R2547     6.9988787174224854e-01
    z[9,10,2]  R2548     5.0023770332336426e-01
    z[9,10,2]  R2549     6.8567067384719849e-01
    z[9,10,3]  R86       -1
    z[9,10,3]  R95       1
    z[9,10,3]  R2480     -1
    z[9,10,3]  R2481     1
    z[9,10,3]  R2488     4.2166435718536377e-01
    z[9,10,3]  R2489     9.6186205744743347e-02
    z[9,10,3]  R2490     -2.6171660423278809e-01
    z[9,10,3]  R2491     -1.6528908908367157e-01
    z[9,10,3]  R2492     -2.3276420310139656e-02
    z[9,10,3]  R2493     8.3589881658554077e-01
    z[9,10,3]  R2494     -2.9706087708473206e-01
    z[9,10,3]  R2495     3.1430311501026154e-02
    z[9,10,3]  R2496     -2.3815210163593292e-01
    z[9,10,3]  R2497     1.2543287873268127e-01
    z[9,10,3]  R2498     7.5945779681205750e-03
    z[9,10,3]  R2499     2.1967248618602753e-01
    z[9,10,3]  R2500     -1.7578256130218506e-01
    z[9,10,3]  R2501     2.7775728702545166e-01
    z[9,10,3]  R2502     0.0916222333908081
    z[9,10,3]  R2503     -1.2926568090915680e-01
    z[9,10,3]  R2504     0.0892622321844101
    z[9,10,3]  R2505     -4.6714410185813904e-01
    z[9,10,3]  R2506     -1.3658659160137177e-01
    z[9,10,3]  R2507     -5.4128553718328476e-02
    z[9,10,3]  R2508     -2.3920129239559174e-01
    z[9,10,3]  R2509     3.6994791030883789e-01
    z[9,10,3]  R2510     0.219553142786026
    z[9,10,3]  R2511     2.1473543345928192e-01
    z[9,10,3]  R2512     -1.4703287184238434e-01
    z[9,10,3]  R2513     0.344155490398407
    z[9,10,3]  R2514     -7.7896326780319214e-01
    z[9,10,3]  R2515     -4.1236785054206848e-01
    z[9,10,3]  R2516     2.8863430023193359e-01
    z[9,10,3]  R2517     1.2976673245429993e-01
    z[9,10,3]  R2518     -2.0462699234485626e-01
    z[9,10,3]  R2519     1.9002115726470947e-01
    z[9,10,3]  R2520     -1.8746571242809296e-01
    z[9,10,3]  R2521     -7.2501905262470245e-02
    z[9,10,3]  R2522     -1.8766152858734131e-01
    z[9,10,3]  R2523     -4.7987371683120728e-01
    z[9,10,3]  R2524     -2.8874301910400391e-01
    z[9,10,3]  R2525     2.1433551609516144e-01
    z[9,10,3]  R2526     3.0487281084060669e-01
    z[9,10,3]  R2527     -3.9902785420417786e-01
    z[9,10,3]  R2528     7.7159124612808228e-01
    z[9,10,3]  R2529     8.8653421401977539e-01
    z[9,10,3]  R2530     -1.8677787482738495e-01
    z[9,10,3]  R2531     1.6629297286272049e-02
    z[9,10,3]  R2532     -4.0363001823425293e-01
    z[9,10,3]  R2533     -6.6593624651432037e-02
    z[9,10,3]  R2534     -2.3678421974182129e-01
    z[9,10,3]  R2535     -1.3033494353294373e-01
    z[9,10,3]  R2536     -9.6394300460815430e-02
    z[9,10,3]  R2537     -3.9456138014793396e-01
    z[9,10,3]  R2538     2.7258358895778656e-02
    z[9,10,3]  R2539     0.352216899394989
    z[9,10,3]  R2540     -6.2394142150878906e-01
    z[9,10,3]  R2541     -2.7145397663116455e-01
    z[9,10,3]  R2542     3.0579817295074463e-01
    z[9,10,3]  R2543     -3.1357815861701965e-01
    z[9,10,3]  R2544     2.1988305449485779e-01
    z[9,10,3]  R2545     -1.7302658408880234e-02
    z[9,10,3]  R2546     0.519877016544342
    z[9,10,3]  R2547     5.3139919042587280e-01
    z[9,10,3]  R2548     0.700632631778717
    z[9,10,3]  R2549     4.6535894274711609e-01
    z[9,10,4]  R87       -1
    z[9,10,4]  R96       1
    z[9,10,4]  R2482     -1
    z[9,10,4]  R2483     1
    z[9,10,4]  R2488     0.288414865732193
    z[9,10,4]  R2489     -2.9510203003883362e-01
    z[9,10,4]  R2490     4.1223824024200439e-01
    z[9,10,4]  R2491     -5.1926040649414062e-01
    z[9,10,4]  R2492     5.5175840854644775e-01
    z[9,10,4]  R2493     3.1843644380569458e-01
    z[9,10,4]  R2494     -3.8677820563316345e-01
    z[9,10,4]  R2495     4.7104689292609692e-03
    z[9,10,4]  R2496     9.0189658105373383e-02
    z[9,10,4]  R2497     -5.2306872606277466e-01
    z[9,10,4]  R2498     -2.5491744279861450e-01
    z[9,10,4]  R2499     -3.1762102246284485e-01
    z[9,10,4]  R2500     1.1221686005592346e-01
    z[9,10,4]  R2501     1.0469968616962433e-01
    z[9,10,4]  R2502     3.0588868260383606e-01
    z[9,10,4]  R2503     -1.2397108227014542e-01
    z[9,10,4]  R2504     -4.1775055229663849e-02
    z[9,10,4]  R2505     -1.3703427277505398e-02
    z[9,10,4]  R2506     -9.8864041268825531e-02
    z[9,10,4]  R2507     1.1068919301033020e-01
    z[9,10,4]  R2508     7.9923301935195923e-02
    z[9,10,4]  R2509     -1.5262781083583832e-01
    z[9,10,4]  R2510     4.1960358619689941e-01
    z[9,10,4]  R2511     4.2174946516752243e-02
    z[9,10,4]  R2512     2.2983600199222565e-01
    z[9,10,4]  R2513     2.8720948100090027e-01
    z[9,10,4]  R2514     1.3539366424083710e-01
    z[9,10,4]  R2515     -7.3919445276260376e-01
    z[9,10,4]  R2516     -1.0036127269268036e-01
    z[9,10,4]  R2517     1.3280834257602692e-01
    z[9,10,4]  R2518     -0.706744372844696
    z[9,10,4]  R2519     -1.8327893316745758e-01
    z[9,10,4]  R2520     -6.9730438292026520e-02
    z[9,10,4]  R2521     -2.1937829256057739e-01
    z[9,10,4]  R2522     -7.9963423311710358e-02
    z[9,10,4]  R2523     -2.9370233416557312e-01
    z[9,10,4]  R2524     1.1862007901072502e-02
    z[9,10,4]  R2525     -2.9073095321655273e-01
    z[9,10,4]  R2526     5.1163870841264725e-02
    z[9,10,4]  R2527     -5.2366904914379120e-02
    z[9,10,4]  R2528     5.1369827985763550e-01
    z[9,10,4]  R2529     2.8623512387275696e-01
    z[9,10,4]  R2530     -4.3542243540287018e-02
    z[9,10,4]  R2531     -4.9253765493631363e-02
    z[9,10,4]  R2532     -3.7257453799247742e-01
    z[9,10,4]  R2533     -6.8323785066604614e-01
    z[9,10,4]  R2534     -4.4237226247787476e-01
    z[9,10,4]  R2535     -2.4362699687480927e-01
    z[9,10,4]  R2536     4.4362466782331467e-02
    z[9,10,4]  R2537     -4.6004977822303772e-01
    z[9,10,4]  R2538     -5.4237610101699829e-01
    z[9,10,4]  R2539     6.8480938673019409e-02
    z[9,10,4]  R2540     -7.0628547668457031e-01
    z[9,10,4]  R2541     2.0449408888816833e-01
    z[9,10,4]  R2542     -1.8453244864940643e-01
    z[9,10,4]  R2543     -6.0103225708007812e-01
    z[9,10,4]  R2544     -0.672758936882019
    z[9,10,4]  R2545     -1.7281450331211090e-01
    z[9,10,4]  R2546     0.0520535483956337
    z[9,10,4]  R2547     -1.3552919030189514e-01
    z[9,10,4]  R2548     -8.4265895187854767e-02
    z[9,10,4]  R2549     -2.3378261923789978e-01
    z[9,10,5]  R88       -1
    z[9,10,5]  R97       1
    z[9,10,5]  R2484     -1
    z[9,10,5]  R2485     1
    z[9,10,5]  R2488     -5.4397702217102051e-01
    z[9,10,5]  R2489     8.5211597383022308e-02
    z[9,10,5]  R2490     -6.9079703092575073e-01
    z[9,10,5]  R2491     -3.5456809401512146e-01
    z[9,10,5]  R2492     4.3455553054809570e-01
    z[9,10,5]  R2493     -3.6502447724342346e-01
    z[9,10,5]  R2494     2.9783430695533752e-01
    z[9,10,5]  R2495     -7.5113177299499512e-02
    z[9,10,5]  R2496     -2.1189087629318237e-01
    z[9,10,5]  R2497     -2.4571208655834198e-01
    z[9,10,5]  R2498     -1.3572596013545990e-02
    z[9,10,5]  R2499     1.6685511171817780e-01
    z[9,10,5]  R2500     1.4573629200458527e-01
    z[9,10,5]  R2501     3.6457675695419312e-01
    z[9,10,5]  R2502     1.9797615706920624e-01
    z[9,10,5]  R2503     -3.6120936274528503e-01
    z[9,10,5]  R2504     -2.0752865076065063e-01
    z[9,10,5]  R2505     1.2425759434700012e-01
    z[9,10,5]  R2506     5.2669537067413330e-01
    z[9,10,5]  R2507     0.620917022228241
    z[9,10,5]  R2508     5.0102800130844116e-01
    z[9,10,5]  R2509     -5.2984073758125305e-02
    z[9,10,5]  R2510     5.0770413875579834e-01
    z[9,10,5]  R2511     -4.6820670366287231e-01
    z[9,10,5]  R2512     4.3534699082374573e-01
    z[9,10,5]  R2513     -3.0110970139503479e-01
    z[9,10,5]  R2514     -7.4945211410522461e-02
    z[9,10,5]  R2515     -2.1428455412387848e-01
    z[9,10,5]  R2516     -2.2916541993618011e-01
    z[9,10,5]  R2517     0.117099329829216
    z[9,10,5]  R2518     -2.9089614748954773e-01
    z[9,10,5]  R2519     6.2324327230453491e-01
    z[9,10,5]  R2520     1.7301371321082115e-02
    z[9,10,5]  R2521     -0.616300642490387
    z[9,10,5]  R2522     -1.0651084035634995e-01
    z[9,10,5]  R2523     0.0874929204583168
    z[9,10,5]  R2524     -2.5583449006080627e-01
    z[9,10,5]  R2525     1.8713390827178955e-01
    z[9,10,5]  R2526     -7.1029275655746460e-02
    z[9,10,5]  R2527     5.2788585424423218e-01
    z[9,10,5]  R2528     2.3108594119548798e-01
    z[9,10,5]  R2529     4.7886174172163010e-02
    z[9,10,5]  R2530     2.9599308967590332e-01
    z[9,10,5]  R2531     0.613882303237915
    z[9,10,5]  R2532     1.8186467885971069e-01
    z[9,10,5]  R2533     1.5288820862770081e-01
    z[9,10,5]  R2534     0.002495281631127
    z[9,10,5]  R2535     1.7671933397650719e-02
    z[9,10,5]  R2536     -1.7113471031188965e-01
    z[9,10,5]  R2537     -3.1766149401664734e-01
    z[9,10,5]  R2538     -2.5111809372901917e-01
    z[9,10,5]  R2539     -7.8134298324584961e-02
    z[9,10,5]  R2540     -1.5438029170036316e-01
    z[9,10,5]  R2541     -2.3001509904861450e-01
    z[9,10,5]  R2542     1.1281652748584747e-01
    z[9,10,5]  R2543     -4.9397316575050354e-01
    z[9,10,5]  R2544     1.1745315045118332e-01
    z[9,10,5]  R2545     -3.0929425358772278e-01
    z[9,10,5]  R2546     5.5347144603729248e-01
    z[9,10,5]  R2547     3.9725202322006226e-01
    z[9,10,5]  R2548     2.0519931614398956e-01
    z[9,10,5]  R2549     2.6762205362319946e-01
    z[9,10,6]  R89       -1
    z[9,10,6]  R98       1
    z[9,10,6]  R2486     -1
    z[9,10,6]  R2487     1
    z[9,10,6]  R2488     -7.3228485416620970e-04
    z[9,10,6]  R2489     -0.830229640007019
    z[9,10,6]  R2490     4.2578735947608948e-01
    z[9,10,6]  R2491     -3.1237217783927917e-01
    z[9,10,6]  R2492     5.5415272712707520e-01
    z[9,10,6]  R2493     7.5381986796855927e-02
    z[9,10,6]  R2494     7.8473798930644989e-02
    z[9,10,6]  R2495     3.1050935387611389e-01
    z[9,10,6]  R2496     -1.0989652946591377e-02
    z[9,10,6]  R2497     1.1293949186801910e-01
    z[9,10,6]  R2498     -8.6390130221843719e-02
    z[9,10,6]  R2499     -3.6033976078033447e-01
    z[9,10,6]  R2500     5.6928880512714386e-02
    z[9,10,6]  R2501     3.1745247542858124e-02
    z[9,10,6]  R2502     2.5697934627532959e-01
    z[9,10,6]  R2503     -1.6448059678077698e-01
    z[9,10,6]  R2504     9.1096490621566772e-02
    z[9,10,6]  R2505     -6.5622046589851379e-02
    z[9,10,6]  R2506     -0.127666175365448
    z[9,10,6]  R2507     -1.2923667207360268e-02
    z[9,10,6]  R2508     1.5111543238162994e-01
    z[9,10,6]  R2509     4.7627137973904610e-04
    z[9,10,6]  R2510     1.5492413938045502e-01
    z[9,10,6]  R2511     -4.2612094432115555e-02
    z[9,10,6]  R2512     4.6257647871971130e-01
    z[9,10,6]  R2513     -6.4826726913452148e-01
    z[9,10,6]  R2514     -3.6707019805908203e-01
    z[9,10,6]  R2515     -3.0498981475830078e-02
    z[9,10,6]  R2516     1.1798144131898880e-01
    z[9,10,6]  R2517     4.5223093032836914e-01
    z[9,10,6]  R2518     -0.593783438205719
    z[9,10,6]  R2519     5.4171487689018250e-02
    z[9,10,6]  R2520     -3.4121882636100054e-03
    z[9,10,6]  R2521     1.8707311153411865e-01
    z[9,10,6]  R2522     -1.7125976085662842e-01
    z[9,10,6]  R2523     4.3881905078887939e-01
    z[9,10,6]  R2524     3.7445154786109924e-01
    z[9,10,6]  R2525     -4.8380523920059204e-01
    z[9,10,6]  R2526     -3.6763486266136169e-01
    z[9,10,6]  R2527     -1.2910179793834686e-01
    z[9,10,6]  R2528     -1.0116583108901978e-01
    z[9,10,6]  R2529     1.2317669577896595e-02
    z[9,10,6]  R2530     2.1949866786599159e-02
    z[9,10,6]  R2531     -0.309481143951416
    z[9,10,6]  R2532     -0.00813719630241394
    z[9,10,6]  R2533     7.3095001280307770e-02
    z[9,10,6]  R2534     -2.1239452064037323e-02
    z[9,10,6]  R2535     3.2550552487373352e-01
    z[9,10,6]  R2536     -6.8013453483581543e-01
    z[9,10,6]  R2537     4.8612061887979507e-02
    z[9,10,6]  R2538     0.264587938785553
    z[9,10,6]  R2539     -0.352030485868454
    z[9,10,6]  R2540     5.4543163627386093e-02
    z[9,10,6]  R2541     2.6071846485137939e-02
    z[9,10,6]  R2542     1.3117910921573639e-01
    z[9,10,6]  R2543     -2.9611018300056458e-01
    z[9,10,6]  R2544     -2.7989998459815979e-01
    z[9,10,6]  R2545     -8.7218630313873291e-01
    z[9,10,6]  R2546     2.0902042090892792e-01
    z[9,10,6]  R2547     -1.4140348136425018e-01
    z[9,10,6]  R2548     2.7622020244598389e-01
    z[9,10,6]  R2549     1.8064013123512268e-01
    z[10,9,0]  R83       1
    z[10,9,0]  R92       -1
    z[10,9,0]  R2550     -1
    z[10,9,0]  R2551     1
    z[10,9,0]  R2564     -6.6838681697845459e-01
    z[10,9,0]  R2565     -3.3950451016426086e-01
    z[10,9,0]  R2566     1.0117264464497566e-02
    z[10,9,0]  R2567     -0.0162187647074461
    z[10,9,0]  R2568     -8.2763278484344482e-01
    z[10,9,0]  R2569     -2.7650287747383118e-01
    z[10,9,0]  R2570     2.9769884422421455e-02
    z[10,9,0]  R2571     -1.5378569066524506e-01
    z[10,9,0]  R2572     5.0816637277603149e-01
    z[10,9,0]  R2573     4.3544137477874756e-01
    z[10,9,0]  R2574     2.2410778701305389e-01
    z[10,9,0]  R2575     1.3578887283802032e-01
    z[10,9,0]  R2576     2.4790754914283752e-01
    z[10,9,0]  R2577     4.4172096252441406e-01
    z[10,9,0]  R2578     6.0829824209213257e-01
    z[10,9,0]  R2579     3.7431082129478455e-01
    z[10,9,0]  R2580     2.1239463984966278e-01
    z[10,9,0]  R2581     2.1339268982410431e-01
    z[10,9,0]  R2582     0.872349202632904
    z[10,9,0]  R2583     5.4281413555145264e-01
    z[10,9,0]  R2584     6.7251950502395630e-01
    z[10,9,0]  R2585     4.9651819467544556e-01
    z[10,9,0]  R2586     4.6507778763771057e-01
    z[10,9,0]  R2587     7.3322528600692749e-01
    z[10,9,0]  R2588     3.9651879668235779e-01
    z[10,9,0]  R2589     5.5991929769515991e-01
    z[10,9,0]  R2590     4.7536960244178772e-01
    z[10,9,0]  R2591     7.4354261159896851e-01
    z[10,9,0]  R2592     1.3204505667090416e-02
    z[10,9,0]  R2593     7.8628438711166382e-01
    z[10,9,0]  R2594     7.2115379571914673e-01
    z[10,9,0]  R2595     2.7202799916267395e-01
    z[10,9,0]  R2596     4.1065916419029236e-01
    z[10,9,0]  R2597     0.0442354753613472
    z[10,9,0]  R2598     7.0270322263240814e-02
    z[10,9,0]  R2599     -1.0864923149347305e-01
    z[10,9,0]  R2600     1.6413313150405884e-01
    z[10,9,0]  R2601     0.278475821018219
    z[10,9,0]  R2602     -4.3440824747085571e-01
    z[10,9,0]  R2603     2.1972376853227615e-02
    z[10,9,0]  R2604     -0.244341641664505
    z[10,9,0]  R2605     -6.8289309740066528e-01
    z[10,9,0]  R2606     -1.3521650806069374e-02
    z[10,9,0]  R2607     1.6398295760154724e-01
    z[10,9,0]  R2608     3.6707723047584295e-03
    z[10,9,0]  R2609     2.1146349608898163e-02
    z[10,9,0]  R2610     4.4592958875000477e-03
    z[10,9,0]  R2611     4.7170282341539860e-03
    z[10,9,0]  R2612     3.2629200816154480e-01
    z[10,9,0]  R2613     5.8327841758728027e-01
    z[10,9,0]  R2614     6.7834746837615967e-01
    z[10,9,0]  R2615     4.8005494475364685e-01
    z[10,9,0]  R2616     6.3030862808227539e-01
    z[10,9,0]  R2617     6.2125825881958008e-01
    z[10,9,0]  R2618     2.4060758948326111e-01
    z[10,9,0]  R2619     -9.2143654823303223e-02
    z[10,9,0]  R2620     -3.8049963116645813e-01
    z[10,9,0]  R2621     -6.6452682018280029e-01
    z[10,9,0]  R2622     -5.9119069576263428e-01
    z[10,9,0]  R2623     -6.5236341953277588e-01
    z[10,9,0]  R2624     2.9052925109863281e-01
    z[10,9,0]  R2625     5.5014067888259888e-01
    z[10,9,1]  R84       1
    z[10,9,1]  R93       -1
    z[10,9,1]  R2552     -1
    z[10,9,1]  R2553     1
    z[10,9,1]  R2564     2.0451097190380096e-01
    z[10,9,1]  R2565     1.6970364749431610e-01
    z[10,9,1]  R2566     3.8651180267333984e-01
    z[10,9,1]  R2567     1.6717033088207245e-01
    z[10,9,1]  R2568     -0.0672031044960022
    z[10,9,1]  R2569     7.9678946733474731e-01
    z[10,9,1]  R2570     -8.5240013897418976e-02
    z[10,9,1]  R2571     -4.0651056915521622e-02
    z[10,9,1]  R2572     -3.5425412654876709e-01
    z[10,9,1]  R2573     3.7549253553152084e-02
    z[10,9,1]  R2574     -8.6507505178451538e-01
    z[10,9,1]  R2575     -5.4049581289291382e-01
    z[10,9,1]  R2576     -6.9356161355972290e-01
    z[10,9,1]  R2577     5.0812023878097534e-01
    z[10,9,1]  R2578     4.7119516134262085e-01
    z[10,9,1]  R2579     4.1220748424530029e-01
    z[10,9,1]  R2580     -1.0398972034454346e-01
    z[10,9,1]  R2581     -2.1055282652378082e-01
    z[10,9,1]  R2582     3.2922258973121643e-01
    z[10,9,1]  R2583     4.6399402618408203e-01
    z[10,9,1]  R2584     4.1465952992439270e-01
    z[10,9,1]  R2585     4.4240096211433411e-01
    z[10,9,1]  R2586     4.7214484214782715e-01
    z[10,9,1]  R2587     3.2677003741264343e-01
    z[10,9,1]  R2588     5.5083340406417847e-01
    z[10,9,1]  R2589     3.9904680848121643e-01
    z[10,9,1]  R2590     3.9580282568931580e-01
    z[10,9,1]  R2591     2.7318182587623596e-01
    z[10,9,1]  R2592     -5.3048763424158096e-02
    z[10,9,1]  R2593     4.3427705764770508e-01
    z[10,9,1]  R2594     3.6531442403793335e-01
    z[10,9,1]  R2595     -3.5306805372238159e-01
    z[10,9,1]  R2596     4.4144666194915771e-01
    z[10,9,1]  R2597     -1.1707927286624908e-01
    z[10,9,1]  R2598     -5.4121665656566620e-02
    z[10,9,1]  R2599     1.4069433510303497e-01
    z[10,9,1]  R2600     -0.326238214969635
    z[10,9,1]  R2601     -2.7720254659652710e-01
    z[10,9,1]  R2602     -5.0435990095138550e-01
    z[10,9,1]  R2603     -4.0948277711868286e-01
    z[10,9,1]  R2604     -1.7903269827365875e-01
    z[10,9,1]  R2605     3.6663429345935583e-03
    z[10,9,1]  R2606     -3.2231029868125916e-01
    z[10,9,1]  R2607     -3.7053756415843964e-02
    z[10,9,1]  R2608     0.81685870885849
    z[10,9,1]  R2609     7.0958900451660156e-01
    z[10,9,1]  R2610     7.1484923362731934e-01
    z[10,9,1]  R2611     7.7314484119415283e-01
    z[10,9,1]  R2612     -6.0189563035964966e-01
    z[10,9,1]  R2613     5.9015500545501709e-01
    z[10,9,1]  R2614     6.5964990854263306e-01
    z[10,9,1]  R2615     7.3843461275100708e-01
    z[10,9,1]  R2616     6.0166496038436890e-01
    z[10,9,1]  R2617     6.2605887651443481e-01
    z[10,9,1]  R2618     7.6555055379867554e-01
    z[10,9,1]  R2619     -6.4276337623596191e-01
    z[10,9,1]  R2620     -6.0771763324737549e-01
    z[10,9,1]  R2621     3.8339450955390930e-01
    z[10,9,1]  R2622     -5.5138278007507324e-01
    z[10,9,1]  R2623     3.2223567366600037e-01
    z[10,9,1]  R2624     -5.0489884614944458e-01
    z[10,9,1]  R2625     6.5147417783737183e-01
    z[10,9,2]  R85       1
    z[10,9,2]  R94       -1
    z[10,9,2]  R2554     -1
    z[10,9,2]  R2555     1
    z[10,9,2]  R2564     1.8299490213394165e-01
    z[10,9,2]  R2565     3.7958872318267822e-01
    z[10,9,2]  R2566     -2.9160553216934204e-01
    z[10,9,2]  R2567     4.5660424232482910e-01
    z[10,9,2]  R2568     -0.388187050819397
    z[10,9,2]  R2569     -1.8965774774551392e-01
    z[10,9,2]  R2570     -1.1527680605649948e-01
    z[10,9,2]  R2571     7.1668088436126709e-01
    z[10,9,2]  R2572     -0.758916437625885
    z[10,9,2]  R2573     -5.8375918865203857e-01
    z[10,9,2]  R2574     -3.4515988826751709e-01
    z[10,9,2]  R2575     -4.1553407907485962e-01
    z[10,9,2]  R2576     -4.1028726100921631e-01
    z[10,9,2]  R2577     3.8359567523002625e-01
    z[10,9,2]  R2578     4.1494885087013245e-01
    z[10,9,2]  R2579     4.8236930370330811e-01
    z[10,9,2]  R2580     1.4560346305370331e-01
    z[10,9,2]  R2581     1.9953136146068573e-01
    z[10,9,2]  R2582     0.0757877379655838
    z[10,9,2]  R2583     1.2136624753475189e-01
    z[10,9,2]  R2584     -2.0224972069263458e-01
    z[10,9,2]  R2585     2.4038438498973846e-01
    z[10,9,2]  R2586     5.5548596382141113e-01
    z[10,9,2]  R2587     4.1592600941658020e-01
    z[10,9,2]  R2588     1.9032983481884003e-01
    z[10,9,2]  R2589     2.3802405595779419e-01
    z[10,9,2]  R2590     4.3518039584159851e-01
    z[10,9,2]  R2591     -0.337252676486969
    z[10,9,2]  R2592     -2.8646349906921387e-01
    z[10,9,2]  R2593     -0.155140221118927
    z[10,9,2]  R2594     4.3472087383270264e-01
    z[10,9,2]  R2595     -1.0040885210037231e-01
    z[10,9,2]  R2596     -2.0830640196800232e-01
    z[10,9,2]  R2597     -3.1272897124290466e-01
    z[10,9,2]  R2598     6.0756152868270874e-01
    z[10,9,2]  R2599     6.9988787174224854e-01
    z[10,9,2]  R2600     5.0023770332336426e-01
    z[10,9,2]  R2601     6.8567067384719849e-01
    z[10,9,2]  R2602     3.8668855559080839e-03
    z[10,9,2]  R2603     -1.9738748669624329e-01
    z[10,9,2]  R2604     -1.0636299848556519e-01
    z[10,9,2]  R2605     -1.1574492603540421e-01
    z[10,9,2]  R2606     -3.0826982855796814e-01
    z[10,9,2]  R2607     -1.8078340590000153e-01
    z[10,9,2]  R2608     -4.7306194901466370e-03
    z[10,9,2]  R2609     6.2687176465988159e-01
    z[10,9,2]  R2610     6.1571222543716431e-01
    z[10,9,2]  R2611     -1.9940081238746643e-01
    z[10,9,2]  R2612     -6.7717593908309937e-01
    z[10,9,2]  R2613     6.8402059376239777e-02
    z[10,9,2]  R2614     1.9166319072246552e-01
    z[10,9,2]  R2615     -0.047185268253088
    z[10,9,2]  R2616     -1.8307060003280640e-01
    z[10,9,2]  R2617     1.8023288249969482e-01
    z[10,9,2]  R2618     -5.4310280084609985e-01
    z[10,9,2]  R2619     5.8327281475067139e-01
    z[10,9,2]  R2620     4.0467596054077148e-01
    z[10,9,2]  R2621     1.0259532183408737e-01
    z[10,9,2]  R2622     9.4871595501899719e-02
    z[10,9,2]  R2623     -5.5463671684265137e-01
    z[10,9,2]  R2624     3.9323535561561584e-01
    z[10,9,2]  R2625     -6.3270837068557739e-02
    z[10,9,3]  R86       1
    z[10,9,3]  R95       -1
    z[10,9,3]  R2556     -1
    z[10,9,3]  R2557     1
    z[10,9,3]  R2564     -1.4703287184238434e-01
    z[10,9,3]  R2565     0.344155490398407
    z[10,9,3]  R2566     -7.7896326780319214e-01
    z[10,9,3]  R2567     -4.1236785054206848e-01
    z[10,9,3]  R2568     2.8863430023193359e-01
    z[10,9,3]  R2569     1.2976673245429993e-01
    z[10,9,3]  R2570     -2.0462699234485626e-01
    z[10,9,3]  R2571     1.9002115726470947e-01
    z[10,9,3]  R2572     -1.8746571242809296e-01
    z[10,9,3]  R2573     -7.2501905262470245e-02
    z[10,9,3]  R2574     -1.8766152858734131e-01
    z[10,9,3]  R2575     -4.7987371683120728e-01
    z[10,9,3]  R2576     -2.8874301910400391e-01
    z[10,9,3]  R2577     2.1433551609516144e-01
    z[10,9,3]  R2578     3.0487281084060669e-01
    z[10,9,3]  R2579     -3.9902785420417786e-01
    z[10,9,3]  R2580     7.7159124612808228e-01
    z[10,9,3]  R2581     8.8653421401977539e-01
    z[10,9,3]  R2582     -1.8677787482738495e-01
    z[10,9,3]  R2583     1.6629297286272049e-02
    z[10,9,3]  R2584     -4.0363001823425293e-01
    z[10,9,3]  R2585     -6.6593624651432037e-02
    z[10,9,3]  R2586     -2.3678421974182129e-01
    z[10,9,3]  R2587     -1.3033494353294373e-01
    z[10,9,3]  R2588     -9.6394300460815430e-02
    z[10,9,3]  R2589     -3.9456138014793396e-01
    z[10,9,3]  R2590     2.7258358895778656e-02
    z[10,9,3]  R2591     0.352216899394989
    z[10,9,3]  R2592     -6.2394142150878906e-01
    z[10,9,3]  R2593     -2.7145397663116455e-01
    z[10,9,3]  R2594     3.0579817295074463e-01
    z[10,9,3]  R2595     -3.1357815861701965e-01
    z[10,9,3]  R2596     2.1988305449485779e-01
    z[10,9,3]  R2597     -1.7302658408880234e-02
    z[10,9,3]  R2598     0.519877016544342
    z[10,9,3]  R2599     5.3139919042587280e-01
    z[10,9,3]  R2600     0.700632631778717
    z[10,9,3]  R2601     4.6535894274711609e-01
    z[10,9,3]  R2602     4.2166435718536377e-01
    z[10,9,3]  R2603     9.6186205744743347e-02
    z[10,9,3]  R2604     -2.6171660423278809e-01
    z[10,9,3]  R2605     -1.6528908908367157e-01
    z[10,9,3]  R2606     -2.3276420310139656e-02
    z[10,9,3]  R2607     8.3589881658554077e-01
    z[10,9,3]  R2608     -2.9706087708473206e-01
    z[10,9,3]  R2609     3.1430311501026154e-02
    z[10,9,3]  R2610     -2.3815210163593292e-01
    z[10,9,3]  R2611     1.2543287873268127e-01
    z[10,9,3]  R2612     7.5945779681205750e-03
    z[10,9,3]  R2613     2.1967248618602753e-01
    z[10,9,3]  R2614     -1.7578256130218506e-01
    z[10,9,3]  R2615     2.7775728702545166e-01
    z[10,9,3]  R2616     0.0916222333908081
    z[10,9,3]  R2617     -1.2926568090915680e-01
    z[10,9,3]  R2618     0.0892622321844101
    z[10,9,3]  R2619     -4.6714410185813904e-01
    z[10,9,3]  R2620     -1.3658659160137177e-01
    z[10,9,3]  R2621     -5.4128553718328476e-02
    z[10,9,3]  R2622     -2.3920129239559174e-01
    z[10,9,3]  R2623     3.6994791030883789e-01
    z[10,9,3]  R2624     0.219553142786026
    z[10,9,3]  R2625     2.1473543345928192e-01
    z[10,9,4]  R87       1
    z[10,9,4]  R96       -1
    z[10,9,4]  R2558     -1
    z[10,9,4]  R2559     1
    z[10,9,4]  R2564     2.2983600199222565e-01
    z[10,9,4]  R2565     2.8720948100090027e-01
    z[10,9,4]  R2566     1.3539366424083710e-01
    z[10,9,4]  R2567     -7.3919445276260376e-01
    z[10,9,4]  R2568     -1.0036127269268036e-01
    z[10,9,4]  R2569     1.3280834257602692e-01
    z[10,9,4]  R2570     -0.706744372844696
    z[10,9,4]  R2571     -1.8327893316745758e-01
    z[10,9,4]  R2572     -6.9730438292026520e-02
    z[10,9,4]  R2573     -2.1937829256057739e-01
    z[10,9,4]  R2574     -7.9963423311710358e-02
    z[10,9,4]  R2575     -2.9370233416557312e-01
    z[10,9,4]  R2576     1.1862007901072502e-02
    z[10,9,4]  R2577     -2.9073095321655273e-01
    z[10,9,4]  R2578     5.1163870841264725e-02
    z[10,9,4]  R2579     -5.2366904914379120e-02
    z[10,9,4]  R2580     5.1369827985763550e-01
    z[10,9,4]  R2581     2.8623512387275696e-01
    z[10,9,4]  R2582     -4.3542243540287018e-02
    z[10,9,4]  R2583     -4.9253765493631363e-02
    z[10,9,4]  R2584     -3.7257453799247742e-01
    z[10,9,4]  R2585     -6.8323785066604614e-01
    z[10,9,4]  R2586     -4.4237226247787476e-01
    z[10,9,4]  R2587     -2.4362699687480927e-01
    z[10,9,4]  R2588     4.4362466782331467e-02
    z[10,9,4]  R2589     -4.6004977822303772e-01
    z[10,9,4]  R2590     -5.4237610101699829e-01
    z[10,9,4]  R2591     6.8480938673019409e-02
    z[10,9,4]  R2592     -7.0628547668457031e-01
    z[10,9,4]  R2593     2.0449408888816833e-01
    z[10,9,4]  R2594     -1.8453244864940643e-01
    z[10,9,4]  R2595     -6.0103225708007812e-01
    z[10,9,4]  R2596     -0.672758936882019
    z[10,9,4]  R2597     -1.7281450331211090e-01
    z[10,9,4]  R2598     0.0520535483956337
    z[10,9,4]  R2599     -1.3552919030189514e-01
    z[10,9,4]  R2600     -8.4265895187854767e-02
    z[10,9,4]  R2601     -2.3378261923789978e-01
    z[10,9,4]  R2602     0.288414865732193
    z[10,9,4]  R2603     -2.9510203003883362e-01
    z[10,9,4]  R2604     4.1223824024200439e-01
    z[10,9,4]  R2605     -5.1926040649414062e-01
    z[10,9,4]  R2606     5.5175840854644775e-01
    z[10,9,4]  R2607     3.1843644380569458e-01
    z[10,9,4]  R2608     -3.8677820563316345e-01
    z[10,9,4]  R2609     4.7104689292609692e-03
    z[10,9,4]  R2610     9.0189658105373383e-02
    z[10,9,4]  R2611     -5.2306872606277466e-01
    z[10,9,4]  R2612     -2.5491744279861450e-01
    z[10,9,4]  R2613     -3.1762102246284485e-01
    z[10,9,4]  R2614     1.1221686005592346e-01
    z[10,9,4]  R2615     1.0469968616962433e-01
    z[10,9,4]  R2616     3.0588868260383606e-01
    z[10,9,4]  R2617     -1.2397108227014542e-01
    z[10,9,4]  R2618     -4.1775055229663849e-02
    z[10,9,4]  R2619     -1.3703427277505398e-02
    z[10,9,4]  R2620     -9.8864041268825531e-02
    z[10,9,4]  R2621     1.1068919301033020e-01
    z[10,9,4]  R2622     7.9923301935195923e-02
    z[10,9,4]  R2623     -1.5262781083583832e-01
    z[10,9,4]  R2624     4.1960358619689941e-01
    z[10,9,4]  R2625     4.2174946516752243e-02
    z[10,9,5]  R88       1
    z[10,9,5]  R97       -1
    z[10,9,5]  R2560     -1
    z[10,9,5]  R2561     1
    z[10,9,5]  R2564     4.3534699082374573e-01
    z[10,9,5]  R2565     -3.0110970139503479e-01
    z[10,9,5]  R2566     -7.4945211410522461e-02
    z[10,9,5]  R2567     -2.1428455412387848e-01
    z[10,9,5]  R2568     -2.2916541993618011e-01
    z[10,9,5]  R2569     0.117099329829216
    z[10,9,5]  R2570     -2.9089614748954773e-01
    z[10,9,5]  R2571     6.2324327230453491e-01
    z[10,9,5]  R2572     1.7301371321082115e-02
    z[10,9,5]  R2573     -0.616300642490387
    z[10,9,5]  R2574     -1.0651084035634995e-01
    z[10,9,5]  R2575     0.0874929204583168
    z[10,9,5]  R2576     -2.5583449006080627e-01
    z[10,9,5]  R2577     1.8713390827178955e-01
    z[10,9,5]  R2578     -7.1029275655746460e-02
    z[10,9,5]  R2579     5.2788585424423218e-01
    z[10,9,5]  R2580     2.3108594119548798e-01
    z[10,9,5]  R2581     4.7886174172163010e-02
    z[10,9,5]  R2582     2.9599308967590332e-01
    z[10,9,5]  R2583     0.613882303237915
    z[10,9,5]  R2584     1.8186467885971069e-01
    z[10,9,5]  R2585     1.5288820862770081e-01
    z[10,9,5]  R2586     0.002495281631127
    z[10,9,5]  R2587     1.7671933397650719e-02
    z[10,9,5]  R2588     -1.7113471031188965e-01
    z[10,9,5]  R2589     -3.1766149401664734e-01
    z[10,9,5]  R2590     -2.5111809372901917e-01
    z[10,9,5]  R2591     -7.8134298324584961e-02
    z[10,9,5]  R2592     -1.5438029170036316e-01
    z[10,9,5]  R2593     -2.3001509904861450e-01
    z[10,9,5]  R2594     1.1281652748584747e-01
    z[10,9,5]  R2595     -4.9397316575050354e-01
    z[10,9,5]  R2596     1.1745315045118332e-01
    z[10,9,5]  R2597     -3.0929425358772278e-01
    z[10,9,5]  R2598     5.5347144603729248e-01
    z[10,9,5]  R2599     3.9725202322006226e-01
    z[10,9,5]  R2600     2.0519931614398956e-01
    z[10,9,5]  R2601     2.6762205362319946e-01
    z[10,9,5]  R2602     -5.4397702217102051e-01
    z[10,9,5]  R2603     8.5211597383022308e-02
    z[10,9,5]  R2604     -6.9079703092575073e-01
    z[10,9,5]  R2605     -3.5456809401512146e-01
    z[10,9,5]  R2606     4.3455553054809570e-01
    z[10,9,5]  R2607     -3.6502447724342346e-01
    z[10,9,5]  R2608     2.9783430695533752e-01
    z[10,9,5]  R2609     -7.5113177299499512e-02
    z[10,9,5]  R2610     -2.1189087629318237e-01
    z[10,9,5]  R2611     -2.4571208655834198e-01
    z[10,9,5]  R2612     -1.3572596013545990e-02
    z[10,9,5]  R2613     1.6685511171817780e-01
    z[10,9,5]  R2614     1.4573629200458527e-01
    z[10,9,5]  R2615     3.6457675695419312e-01
    z[10,9,5]  R2616     1.9797615706920624e-01
    z[10,9,5]  R2617     -3.6120936274528503e-01
    z[10,9,5]  R2618     -2.0752865076065063e-01
    z[10,9,5]  R2619     1.2425759434700012e-01
    z[10,9,5]  R2620     5.2669537067413330e-01
    z[10,9,5]  R2621     0.620917022228241
    z[10,9,5]  R2622     5.0102800130844116e-01
    z[10,9,5]  R2623     -5.2984073758125305e-02
    z[10,9,5]  R2624     5.0770413875579834e-01
    z[10,9,5]  R2625     -4.6820670366287231e-01
    z[10,9,6]  R89       1
    z[10,9,6]  R98       -1
    z[10,9,6]  R2562     -1
    z[10,9,6]  R2563     1
    z[10,9,6]  R2564     4.6257647871971130e-01
    z[10,9,6]  R2565     -6.4826726913452148e-01
    z[10,9,6]  R2566     -3.6707019805908203e-01
    z[10,9,6]  R2567     -3.0498981475830078e-02
    z[10,9,6]  R2568     1.1798144131898880e-01
    z[10,9,6]  R2569     4.5223093032836914e-01
    z[10,9,6]  R2570     -0.593783438205719
    z[10,9,6]  R2571     5.4171487689018250e-02
    z[10,9,6]  R2572     -3.4121882636100054e-03
    z[10,9,6]  R2573     1.8707311153411865e-01
    z[10,9,6]  R2574     -1.7125976085662842e-01
    z[10,9,6]  R2575     4.3881905078887939e-01
    z[10,9,6]  R2576     3.7445154786109924e-01
    z[10,9,6]  R2577     -4.8380523920059204e-01
    z[10,9,6]  R2578     -3.6763486266136169e-01
    z[10,9,6]  R2579     -1.2910179793834686e-01
    z[10,9,6]  R2580     -1.0116583108901978e-01
    z[10,9,6]  R2581     1.2317669577896595e-02
    z[10,9,6]  R2582     2.1949866786599159e-02
    z[10,9,6]  R2583     -0.309481143951416
    z[10,9,6]  R2584     -0.00813719630241394
    z[10,9,6]  R2585     7.3095001280307770e-02
    z[10,9,6]  R2586     -2.1239452064037323e-02
    z[10,9,6]  R2587     3.2550552487373352e-01
    z[10,9,6]  R2588     -6.8013453483581543e-01
    z[10,9,6]  R2589     4.8612061887979507e-02
    z[10,9,6]  R2590     0.264587938785553
    z[10,9,6]  R2591     -0.352030485868454
    z[10,9,6]  R2592     5.4543163627386093e-02
    z[10,9,6]  R2593     2.6071846485137939e-02
    z[10,9,6]  R2594     1.3117910921573639e-01
    z[10,9,6]  R2595     -2.9611018300056458e-01
    z[10,9,6]  R2596     -2.7989998459815979e-01
    z[10,9,6]  R2597     -8.7218630313873291e-01
    z[10,9,6]  R2598     2.0902042090892792e-01
    z[10,9,6]  R2599     -1.4140348136425018e-01
    z[10,9,6]  R2600     2.7622020244598389e-01
    z[10,9,6]  R2601     1.8064013123512268e-01
    z[10,9,6]  R2602     -7.3228485416620970e-04
    z[10,9,6]  R2603     -0.830229640007019
    z[10,9,6]  R2604     4.2578735947608948e-01
    z[10,9,6]  R2605     -3.1237217783927917e-01
    z[10,9,6]  R2606     5.5415272712707520e-01
    z[10,9,6]  R2607     7.5381986796855927e-02
    z[10,9,6]  R2608     7.8473798930644989e-02
    z[10,9,6]  R2609     3.1050935387611389e-01
    z[10,9,6]  R2610     -1.0989652946591377e-02
    z[10,9,6]  R2611     1.1293949186801910e-01
    z[10,9,6]  R2612     -8.6390130221843719e-02
    z[10,9,6]  R2613     -3.6033976078033447e-01
    z[10,9,6]  R2614     5.6928880512714386e-02
    z[10,9,6]  R2615     3.1745247542858124e-02
    z[10,9,6]  R2616     2.5697934627532959e-01
    z[10,9,6]  R2617     -1.6448059678077698e-01
    z[10,9,6]  R2618     9.1096490621566772e-02
    z[10,9,6]  R2619     -6.5622046589851379e-02
    z[10,9,6]  R2620     -0.127666175365448
    z[10,9,6]  R2621     -1.2923667207360268e-02
    z[10,9,6]  R2622     1.5111543238162994e-01
    z[10,9,6]  R2623     4.7627137973904610e-04
    z[10,9,6]  R2624     1.5492413938045502e-01
    z[10,9,6]  R2625     -4.2612094432115555e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    length[10]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
    delta[10,0]  R92       1
    delta[10,1]  R93       1
    delta[10,2]  R94       1
    delta[10,3]  R95       1
    delta[10,4]  R96       1
    delta[10,5]  R97       1
    delta[10,6]  R98       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R91       1
    RHS1      R99       1
    RHS1      R100      -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[11,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,10]
 BV BND1      phi[10,3]
 BV BND1      phi[3,12]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[11,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,10]
 BV BND1      phi[10,9]
 BV BND1      phi[10,12]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,10,0]
 FR BND1      z[3,10,1]
 FR BND1      z[3,10,2]
 FR BND1      z[3,10,3]
 FR BND1      z[3,10,4]
 FR BND1      z[3,10,5]
 FR BND1      z[3,10,6]
 FR BND1      z[10,3,0]
 FR BND1      z[10,3,1]
 FR BND1      z[10,3,2]
 FR BND1      z[10,3,3]
 FR BND1      z[10,3,4]
 FR BND1      z[10,3,5]
 FR BND1      z[10,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      z[9,10,0]
 FR BND1      z[9,10,1]
 FR BND1      z[9,10,2]
 FR BND1      z[9,10,3]
 FR BND1      z[9,10,4]
 FR BND1      z[9,10,5]
 FR BND1      z[9,10,6]
 FR BND1      z[10,9,0]
 FR BND1      z[10,9,1]
 FR BND1      z[10,9,2]
 FR BND1      z[10,9,3]
 FR BND1      z[10,9,4]
 FR BND1      z[10,9,5]
 FR BND1      z[10,9,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
 FR BND1      delta[10,0]
 FR BND1      delta[10,1]
 FR BND1      delta[10,2]
 FR BND1      delta[10,3]
 FR BND1      delta[10,4]
 FR BND1      delta[10,5]
 FR BND1      delta[10,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
QCMATRIX   qc10    
    length[10]  length[10]  -1
    delta[10,0]  delta[10,0]  1
    delta[10,1]  delta[10,1]  1
    delta[10,2]  delta[10,2]  1
    delta[10,3]  delta[10,3]  1
    delta[10,4]  delta[10,4]  1
    delta[10,5]  delta[10,5]  1
    delta[10,6]  delta[10,6]  1
ENDATA
