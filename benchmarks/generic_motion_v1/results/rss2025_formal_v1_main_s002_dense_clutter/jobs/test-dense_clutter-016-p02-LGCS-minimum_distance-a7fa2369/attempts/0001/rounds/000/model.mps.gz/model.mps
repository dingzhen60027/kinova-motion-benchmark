NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 E  R64     
 L  R65     
 L  R66     
 L  R67     
 L  R68     
 L  R69     
 L  R70     
 L  R71     
 L  R72     
 L  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  R2911   
 L  R2912   
 L  R2913   
 L  R2914   
 L  R2915   
 L  R2916   
 L  R2917   
 L  R2918   
 L  R2919   
 L  R2920   
 L  R2921   
 L  R2922   
 L  R2923   
 L  R2924   
 L  R2925   
 L  R2926   
 L  R2927   
 L  R2928   
 L  R2929   
 L  R2930   
 L  R2931   
 L  R2932   
 L  R2933   
 L  R2934   
 L  R2935   
 L  R2936   
 L  R2937   
 L  R2938   
 L  R2939   
 L  R2940   
 L  R2941   
 L  R2942   
 L  R2943   
 L  R2944   
 L  R2945   
 L  R2946   
 L  R2947   
 L  R2948   
 L  R2949   
 L  R2950   
 L  R2951   
 L  R2952   
 L  R2953   
 L  R2954   
 L  R2955   
 L  R2956   
 L  R2957   
 L  R2958   
 L  R2959   
 L  R2960   
 L  R2961   
 L  R2962   
 L  R2963   
 L  R2964   
 L  R2965   
 L  R2966   
 L  R2967   
 L  R2968   
 L  R2969   
 L  R2970   
 L  R2971   
 L  R2972   
 L  R2973   
 L  R2974   
 L  R2975   
 L  R2976   
 L  R2977   
 L  R2978   
 L  R2979   
 L  R2980   
 L  R2981   
 L  R2982   
 L  R2983   
 L  R2984   
 L  R2985   
 L  R2986   
 L  R2987   
 L  R2988   
 L  R2989   
 L  R2990   
 L  R2991   
 L  R2992   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R65       -3.0999999046325684e+00
    phi[0,1]  R66       -3.0999999046325684e+00
    phi[0,1]  R67       -2.2400000095367432e+00
    phi[0,1]  R68       -2.2400000095367432e+00
    phi[0,1]  R69       -3.0999999046325684e+00
    phi[0,1]  R70       -3.0999999046325684e+00
    phi[0,1]  R71       -2.5699999332427979e+00
    phi[0,1]  R72       -2.5699999332427979e+00
    phi[0,1]  R73       -3.0999999046325684e+00
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -2.0899999141693115e+00
    phi[0,1]  R76       -2.0899999141693115e+00
    phi[0,1]  R77       -3.0999999046325684e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -6.2153726816177368e-01
    phi[0,1]  R80       3.8615599274635315e-01
    phi[0,1]  R81       -1.0438578128814697e+00
    phi[0,1]  R82       1.3706934452056885e-01
    phi[0,1]  R83       -8.5207962989807129e-01
    phi[0,1]  R84       2.4053584039211273e-01
    phi[0,1]  R85       7.8570723533630371e-02
    phi[0,1]  R86       4.4882947206497192e-01
    phi[0,1]  R87       -4.7162252664566040e-01
    phi[0,1]  R88       -1.0017442703247070e+00
    phi[0,1]  R89       -2.7992680072784424e+00
    phi[0,1]  R90       -1.9010308980941772e+00
    phi[0,1]  R91       -3.4234778881073
    phi[0,1]  R92       -2.5409832000732422e+00
    phi[0,1]  R93       -1.2280702590942383e+00
    phi[0,1]  R94       -8.0999964475631714e-01
    phi[0,1]  R95       -3.6448273062705994e-01
    phi[0,1]  R96       -1.2171106338500977e+00
    phi[0,1]  R97       -1.1339445114135742e+00
    phi[0,1]  R98       -1.0835635662078857e+00
    phi[0,1]  R99       -2.4785332679748535e+00
    phi[0,1]  R100      -1.5225770473480225e+00
    phi[0,1]  R101      -8.6607795953750610e-01
    phi[0,1]  R102      -2.8976552486419678e+00
    phi[0,1]  R103      -2.0128101110458374e-01
    phi[0,1]  R104      -3.4269950389862061e+00
    phi[0,1]  R105      1.5081332623958588e-01
    phi[0,1]  R106      -4.2730599641799927e-01
    phi[0,1]  R107      -2.1635155677795410e+00
    phi[0,1]  R108      -8.9301371574401855e-01
    phi[0,1]  R109      -2.3681366443634033e+00
    phi[0,1]  R110      -2.4416394233703613e+00
    phi[0,1]  R111      -3.0007560253143311e+00
    phi[0,1]  R112      -2.1427626609802246e+00
    phi[0,1]  R113      -1.4330477714538574e+00
    phi[0,1]  R114      1.0308989882469177e-01
    phi[0,1]  R115      -0.808255136013031
    phi[0,1]  R116      -6.3720744848251343e-01
    phi[0,1]  R117      -1.4937438964843750e+00
    phi[0,1]  R118      -1.6502450704574585e+00
    phi[0,1]  R119      -1.6489876508712769e+00
    phi[0,1]  R120      -7.3454529047012329e-01
    phi[0,1]  R121      4.4977761805057526e-02
    phi[0,1]  R122      -2.0196260511875153e-01
    phi[0,1]  R123      -7.8055971860885620e-01
    phi[0,1]  R124      4.6232786774635315e-01
    phi[0,1]  R125      -5.8772891759872437e-01
    phi[0,1]  R126      3.8126997649669647e-02
    phi[0,1]  R127      -4.7900289297103882e-01
    phi[0,1]  R128      -1.1507971286773682e+00
    phi[0,1]  R129      1.9664230346679688e+00
    phi[0,1]  R130      2.0808558464050293e+00
    phi[0,1]  R131      1.2804361581802368e+00
    phi[0,1]  R132      1.4970929622650146e+00
    phi[0,1]  R133      1.6670113801956177e+00
    phi[0,1]  R134      6.8956357240676880e-01
    phi[0,1]  R135      3.7077087163925171e-01
    phi[0,1]  R136      -3.7168118357658386e-01
    phi[0,1]  R137      -1.4298155903816223e-01
    phi[0,1]  R138      -1.0029788017272949e+00
    phi[0,1]  R139      -9.8529952764511108e-01
    phi[0,1]  R140      -3.9680135250091553e-01
    phi[0,1]  R141      -3.1370067596435547e-01
    phi[0,1]  R142      -2.0499134063720703e+00
    phi[0,1]  R143      8.1695950031280518e-01
    phi[0,1]  R144      -4.3905954360961914e+00
    phi[0,1]  R145      -3.3153734207153320e+00
    phi[0,1]  R146      -1.8261700868606567e+00
    phi[0,1]  R147      -2.3661906719207764e+00
    phi[0,1]  R148      -1.7181274890899658e+00
    phi[0,1]  R149      -1.6641924381256104e+00
    phi[0,1]  R150      -1.5336719751358032e+00
    phi[0,1]  R151      -9.6779960393905640e-01
    phi[0,1]  R152      -1.1057369709014893e+00
    phi[0,1]  R153      8.4525831043720245e-02
    phi[0,1]  R154      -1.3610336780548096e+00
    phi[0,1]  R155      -2.2789260745048523e-01
    phi[0,1]  R156      -1.4055078029632568e+00
    phi[0,1]  R157      -0.930335283279419
    phi[0,1]  R158      -1.0332182645797729e+00
    phi[0,1]  R159      1.5764783322811127e-01
    phi[0,1]  R160      6.6788923740386963e-01
    phi[0,1]  R161      8.8056391477584839e-01
    phi[0,1]  R162      0.979372501373291
    phi[0,1]  R163      -9.0368163585662842e-01
    phi[0,1]  R164      4.6497848629951477e-01
    phi[0,1]  R165      -3.8870871067047119e+00
    phi[0,1]  R166      -1.8786684274673462e+00
    phi[0,1]  R167      -1.7773544788360596e+00
    phi[0,1]  R168      -1.2514928579330444e+00
    phi[0,1]  R169      -1.2448586225509644e+00
    phi[0,1]  R170      -4.0075969696044922e+00
    phi[0,1]  R171      1.2261536121368408e+00
    phi[0,1]  R172      -9.5557585358619690e-02
    phi[0,1]  R173      -1.6775109767913818e+00
    phi[0,1]  R174      -1.2371207475662231e+00
    phi[0,1]  R175      -6.4163094758987427e-01
    phi[0,1]  R176      -2.1518533229827881e+00
    phi[0,1]  R177      -2.9930369928479195e-02
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R178      -3.0999999046325684e+00
    phi[1,0]  R179      -3.0999999046325684e+00
    phi[1,0]  R180      -2.2400000095367432e+00
    phi[1,0]  R181      -2.2400000095367432e+00
    phi[1,0]  R182      -3.0999999046325684e+00
    phi[1,0]  R183      -3.0999999046325684e+00
    phi[1,0]  R184      -2.5699999332427979e+00
    phi[1,0]  R185      -2.5699999332427979e+00
    phi[1,0]  R186      -3.0999999046325684e+00
    phi[1,0]  R187      -3.0999999046325684e+00
    phi[1,0]  R188      -2.0899999141693115e+00
    phi[1,0]  R189      -2.0899999141693115e+00
    phi[1,0]  R190      -3.0999999046325684e+00
    phi[1,0]  R191      -3.0999999046325684e+00
    phi[1,0]  R192      1.9664230346679688e+00
    phi[1,0]  R193      2.0808558464050293e+00
    phi[1,0]  R194      1.2804361581802368e+00
    phi[1,0]  R195      1.4970929622650146e+00
    phi[1,0]  R196      1.6670113801956177e+00
    phi[1,0]  R197      6.8956357240676880e-01
    phi[1,0]  R198      3.7077087163925171e-01
    phi[1,0]  R199      -3.7168118357658386e-01
    phi[1,0]  R200      -1.4298155903816223e-01
    phi[1,0]  R201      -1.0029788017272949e+00
    phi[1,0]  R202      -9.8529952764511108e-01
    phi[1,0]  R203      -3.9680135250091553e-01
    phi[1,0]  R204      -3.1370067596435547e-01
    phi[1,0]  R205      -2.0499134063720703e+00
    phi[1,0]  R206      8.1695950031280518e-01
    phi[1,0]  R207      -4.3905954360961914e+00
    phi[1,0]  R208      -3.3153734207153320e+00
    phi[1,0]  R209      -1.8261700868606567e+00
    phi[1,0]  R210      -2.3661906719207764e+00
    phi[1,0]  R211      -1.7181274890899658e+00
    phi[1,0]  R212      -1.6641924381256104e+00
    phi[1,0]  R213      -1.5336719751358032e+00
    phi[1,0]  R214      -9.6779960393905640e-01
    phi[1,0]  R215      -1.1057369709014893e+00
    phi[1,0]  R216      8.4525831043720245e-02
    phi[1,0]  R217      -1.3610336780548096e+00
    phi[1,0]  R218      -2.2789260745048523e-01
    phi[1,0]  R219      -1.4055078029632568e+00
    phi[1,0]  R220      -0.930335283279419
    phi[1,0]  R221      -1.0332182645797729e+00
    phi[1,0]  R222      1.5764783322811127e-01
    phi[1,0]  R223      6.6788923740386963e-01
    phi[1,0]  R224      8.8056391477584839e-01
    phi[1,0]  R225      0.979372501373291
    phi[1,0]  R226      -9.0368163585662842e-01
    phi[1,0]  R227      4.6497848629951477e-01
    phi[1,0]  R228      -3.8870871067047119e+00
    phi[1,0]  R229      -1.8786684274673462e+00
    phi[1,0]  R230      -1.7773544788360596e+00
    phi[1,0]  R231      -1.2514928579330444e+00
    phi[1,0]  R232      -1.2448586225509644e+00
    phi[1,0]  R233      -4.0075969696044922e+00
    phi[1,0]  R234      1.2261536121368408e+00
    phi[1,0]  R235      -9.5557585358619690e-02
    phi[1,0]  R236      -1.6775109767913818e+00
    phi[1,0]  R237      -1.2371207475662231e+00
    phi[1,0]  R238      -6.4163094758987427e-01
    phi[1,0]  R239      -2.1518533229827881e+00
    phi[1,0]  R240      -2.9930369928479195e-02
    phi[1,0]  R241      -6.2153726816177368e-01
    phi[1,0]  R242      3.8615599274635315e-01
    phi[1,0]  R243      -1.0438578128814697e+00
    phi[1,0]  R244      1.3706934452056885e-01
    phi[1,0]  R245      -8.5207962989807129e-01
    phi[1,0]  R246      2.4053584039211273e-01
    phi[1,0]  R247      7.8570723533630371e-02
    phi[1,0]  R248      4.4882947206497192e-01
    phi[1,0]  R249      -4.7162252664566040e-01
    phi[1,0]  R250      -1.0017442703247070e+00
    phi[1,0]  R251      -2.7992680072784424e+00
    phi[1,0]  R252      -1.9010308980941772e+00
    phi[1,0]  R253      -3.4234778881073
    phi[1,0]  R254      -2.5409832000732422e+00
    phi[1,0]  R255      -1.2280702590942383e+00
    phi[1,0]  R256      -8.0999964475631714e-01
    phi[1,0]  R257      -3.6448273062705994e-01
    phi[1,0]  R258      -1.2171106338500977e+00
    phi[1,0]  R259      -1.1339445114135742e+00
    phi[1,0]  R260      -1.0835635662078857e+00
    phi[1,0]  R261      -2.4785332679748535e+00
    phi[1,0]  R262      -1.5225770473480225e+00
    phi[1,0]  R263      -8.6607795953750610e-01
    phi[1,0]  R264      -2.8976552486419678e+00
    phi[1,0]  R265      -2.0128101110458374e-01
    phi[1,0]  R266      -3.4269950389862061e+00
    phi[1,0]  R267      1.5081332623958588e-01
    phi[1,0]  R268      -4.2730599641799927e-01
    phi[1,0]  R269      -2.1635155677795410e+00
    phi[1,0]  R270      -8.9301371574401855e-01
    phi[1,0]  R271      -2.3681366443634033e+00
    phi[1,0]  R272      -2.4416394233703613e+00
    phi[1,0]  R273      -3.0007560253143311e+00
    phi[1,0]  R274      -2.1427626609802246e+00
    phi[1,0]  R275      -1.4330477714538574e+00
    phi[1,0]  R276      1.0308989882469177e-01
    phi[1,0]  R277      -0.808255136013031
    phi[1,0]  R278      -6.3720744848251343e-01
    phi[1,0]  R279      -1.4937438964843750e+00
    phi[1,0]  R280      -1.6502450704574585e+00
    phi[1,0]  R281      -1.6489876508712769e+00
    phi[1,0]  R282      -7.3454529047012329e-01
    phi[1,0]  R283      4.4977761805057526e-02
    phi[1,0]  R284      -2.0196260511875153e-01
    phi[1,0]  R285      -7.8055971860885620e-01
    phi[1,0]  R286      4.6232786774635315e-01
    phi[1,0]  R287      -5.8772891759872437e-01
    phi[1,0]  R288      3.8126997649669647e-02
    phi[1,0]  R289      -4.7900289297103882e-01
    phi[1,0]  R290      -1.1507971286773682e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R291      -3.0999999046325684e+00
    phi[0,3]  R292      -3.0999999046325684e+00
    phi[0,3]  R293      -2.2400000095367432e+00
    phi[0,3]  R294      -2.2400000095367432e+00
    phi[0,3]  R295      -3.0999999046325684e+00
    phi[0,3]  R296      -3.0999999046325684e+00
    phi[0,3]  R297      -2.5699999332427979e+00
    phi[0,3]  R298      -2.5699999332427979e+00
    phi[0,3]  R299      -3.0999999046325684e+00
    phi[0,3]  R300      -3.0999999046325684e+00
    phi[0,3]  R301      -2.0899999141693115e+00
    phi[0,3]  R302      -2.0899999141693115e+00
    phi[0,3]  R303      -3.0999999046325684e+00
    phi[0,3]  R304      -3.0999999046325684e+00
    phi[0,3]  R305      -6.2153726816177368e-01
    phi[0,3]  R306      3.8615599274635315e-01
    phi[0,3]  R307      -1.0438578128814697e+00
    phi[0,3]  R308      1.3706934452056885e-01
    phi[0,3]  R309      -8.5207962989807129e-01
    phi[0,3]  R310      2.4053584039211273e-01
    phi[0,3]  R311      7.8570723533630371e-02
    phi[0,3]  R312      4.4882947206497192e-01
    phi[0,3]  R313      -4.7162252664566040e-01
    phi[0,3]  R314      -1.0017442703247070e+00
    phi[0,3]  R315      -2.7992680072784424e+00
    phi[0,3]  R316      -1.9010308980941772e+00
    phi[0,3]  R317      -3.4234778881073
    phi[0,3]  R318      -2.5409832000732422e+00
    phi[0,3]  R319      -1.2280702590942383e+00
    phi[0,3]  R320      -8.0999964475631714e-01
    phi[0,3]  R321      -3.6448273062705994e-01
    phi[0,3]  R322      -1.2171106338500977e+00
    phi[0,3]  R323      -1.1339445114135742e+00
    phi[0,3]  R324      -1.0835635662078857e+00
    phi[0,3]  R325      -2.4785332679748535e+00
    phi[0,3]  R326      -1.5225770473480225e+00
    phi[0,3]  R327      -8.6607795953750610e-01
    phi[0,3]  R328      -2.8976552486419678e+00
    phi[0,3]  R329      -2.0128101110458374e-01
    phi[0,3]  R330      -3.4269950389862061e+00
    phi[0,3]  R331      1.5081332623958588e-01
    phi[0,3]  R332      -4.2730599641799927e-01
    phi[0,3]  R333      -2.1635155677795410e+00
    phi[0,3]  R334      -8.9301371574401855e-01
    phi[0,3]  R335      -2.3681366443634033e+00
    phi[0,3]  R336      -2.4416394233703613e+00
    phi[0,3]  R337      -3.0007560253143311e+00
    phi[0,3]  R338      -2.1427626609802246e+00
    phi[0,3]  R339      -1.4330477714538574e+00
    phi[0,3]  R340      1.0308989882469177e-01
    phi[0,3]  R341      -0.808255136013031
    phi[0,3]  R342      -6.3720744848251343e-01
    phi[0,3]  R343      -1.4937438964843750e+00
    phi[0,3]  R344      -1.6502450704574585e+00
    phi[0,3]  R345      -1.6489876508712769e+00
    phi[0,3]  R346      -7.3454529047012329e-01
    phi[0,3]  R347      4.4977761805057526e-02
    phi[0,3]  R348      -2.0196260511875153e-01
    phi[0,3]  R349      -7.8055971860885620e-01
    phi[0,3]  R350      4.6232786774635315e-01
    phi[0,3]  R351      -5.8772891759872437e-01
    phi[0,3]  R352      3.8126997649669647e-02
    phi[0,3]  R353      -4.7900289297103882e-01
    phi[0,3]  R354      -1.1507971286773682e+00
    phi[0,3]  R355      2.6877233386039734e-01
    phi[0,3]  R356      5.0975906848907471e-01
    phi[0,3]  R357      6.8969108164310455e-02
    phi[0,3]  R358      -6.3626605272293091e-01
    phi[0,3]  R359      -4.8362094163894653e-01
    phi[0,3]  R360      -1.3299602270126343e+00
    phi[0,3]  R361      -1.2693172693252563e+00
    phi[0,3]  R362      -9.0696513652801514e-01
    phi[0,3]  R363      -1.7691845893859863e+00
    phi[0,3]  R364      -3.2035681605339050e-01
    phi[0,3]  R365      -2.8802313804626465e+00
    phi[0,3]  R366      -7.2605943679809570e-01
    phi[0,3]  R367      -3.0113141536712646e+00
    phi[0,3]  R368      -3.1982965469360352e+00
    phi[0,3]  R369      -2.2986972332000732e+00
    phi[0,3]  R370      -0.961458683013916
    phi[0,3]  R371      -3.40779709815979
    phi[0,3]  R372      -1.4032102823257446e+00
    phi[0,3]  R373      -7.4169713258743286e-01
    phi[0,3]  R374      -0.701866626739502
    phi[0,3]  R375      -2.3332602977752686e+00
    phi[0,3]  R376      -1.2475509643554688e+00
    phi[0,3]  R377      -2.1668624877929688e+00
    phi[0,3]  R378      -1.4293750524520874e+00
    phi[0,3]  R379      -1.5582545995712280e+00
    phi[0,3]  R380      -2.3570244312286377e+00
    phi[0,3]  R381      -1.2088606357574463e+00
    phi[0,3]  R382      -2.6937718391418457e+00
    phi[0,3]  R383      -2.9455242156982422e+00
    phi[0,3]  R384      -1.6762331724166870e+00
    phi[0,3]  R385      -0.000503971241414547
    phi[0,3]  R386      -3.2402661442756653e-01
    phi[0,3]  R387      -4.0109136700630188e-01
    phi[0,3]  R388      -4.5128709077835083e-01
    phi[0,3]  R389      3.8396877050399780e-01
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R390      -3.0999999046325684e+00
    phi[3,0]  R391      -3.0999999046325684e+00
    phi[3,0]  R392      -2.2400000095367432e+00
    phi[3,0]  R393      -2.2400000095367432e+00
    phi[3,0]  R394      -3.0999999046325684e+00
    phi[3,0]  R395      -3.0999999046325684e+00
    phi[3,0]  R396      -2.5699999332427979e+00
    phi[3,0]  R397      -2.5699999332427979e+00
    phi[3,0]  R398      -3.0999999046325684e+00
    phi[3,0]  R399      -3.0999999046325684e+00
    phi[3,0]  R400      -2.0899999141693115e+00
    phi[3,0]  R401      -2.0899999141693115e+00
    phi[3,0]  R402      -3.0999999046325684e+00
    phi[3,0]  R403      -3.0999999046325684e+00
    phi[3,0]  R404      2.6877233386039734e-01
    phi[3,0]  R405      5.0975906848907471e-01
    phi[3,0]  R406      6.8969108164310455e-02
    phi[3,0]  R407      -6.3626605272293091e-01
    phi[3,0]  R408      -4.8362094163894653e-01
    phi[3,0]  R409      -1.3299602270126343e+00
    phi[3,0]  R410      -1.2693172693252563e+00
    phi[3,0]  R411      -9.0696513652801514e-01
    phi[3,0]  R412      -1.0017442703247070e+00
    phi[3,0]  R413      -1.7691845893859863e+00
    phi[3,0]  R414      -3.2035681605339050e-01
    phi[3,0]  R415      -2.8802313804626465e+00
    phi[3,0]  R416      -7.2605943679809570e-01
    phi[3,0]  R417      -3.0113141536712646e+00
    phi[3,0]  R418      -3.1982965469360352e+00
    phi[3,0]  R419      -2.2986972332000732e+00
    phi[3,0]  R420      -0.961458683013916
    phi[3,0]  R421      -3.40779709815979
    phi[3,0]  R422      -1.4032102823257446e+00
    phi[3,0]  R423      -7.4169713258743286e-01
    phi[3,0]  R424      -0.701866626739502
    phi[3,0]  R425      -2.3332602977752686e+00
    phi[3,0]  R426      -1.2475509643554688e+00
    phi[3,0]  R427      -2.1668624877929688e+00
    phi[3,0]  R428      -1.4293750524520874e+00
    phi[3,0]  R429      -1.5582545995712280e+00
    phi[3,0]  R430      -2.3570244312286377e+00
    phi[3,0]  R431      -1.2088606357574463e+00
    phi[3,0]  R432      -2.6937718391418457e+00
    phi[3,0]  R433      -2.9455242156982422e+00
    phi[3,0]  R434      -1.6762331724166870e+00
    phi[3,0]  R435      -0.000503971241414547
    phi[3,0]  R436      -3.2402661442756653e-01
    phi[3,0]  R437      -4.0109136700630188e-01
    phi[3,0]  R438      -4.5128709077835083e-01
    phi[3,0]  R439      3.8396877050399780e-01
    phi[3,0]  R440      -6.2153726816177368e-01
    phi[3,0]  R441      3.8615599274635315e-01
    phi[3,0]  R442      -1.0438578128814697e+00
    phi[3,0]  R443      1.3706934452056885e-01
    phi[3,0]  R444      -8.5207962989807129e-01
    phi[3,0]  R445      2.4053584039211273e-01
    phi[3,0]  R446      7.8570723533630371e-02
    phi[3,0]  R447      4.4882947206497192e-01
    phi[3,0]  R448      -4.7162252664566040e-01
    phi[3,0]  R449      -2.7992680072784424e+00
    phi[3,0]  R450      -1.9010308980941772e+00
    phi[3,0]  R451      -3.4234778881073
    phi[3,0]  R452      -2.5409832000732422e+00
    phi[3,0]  R453      -1.2280702590942383e+00
    phi[3,0]  R454      -8.0999964475631714e-01
    phi[3,0]  R455      -3.6448273062705994e-01
    phi[3,0]  R456      -1.2171106338500977e+00
    phi[3,0]  R457      -1.1339445114135742e+00
    phi[3,0]  R458      -1.0835635662078857e+00
    phi[3,0]  R459      -2.4785332679748535e+00
    phi[3,0]  R460      -1.5225770473480225e+00
    phi[3,0]  R461      -8.6607795953750610e-01
    phi[3,0]  R462      -2.8976552486419678e+00
    phi[3,0]  R463      -2.0128101110458374e-01
    phi[3,0]  R464      -3.4269950389862061e+00
    phi[3,0]  R465      1.5081332623958588e-01
    phi[3,0]  R466      -4.2730599641799927e-01
    phi[3,0]  R467      -2.1635155677795410e+00
    phi[3,0]  R468      -8.9301371574401855e-01
    phi[3,0]  R469      -2.3681366443634033e+00
    phi[3,0]  R470      -2.4416394233703613e+00
    phi[3,0]  R471      -3.0007560253143311e+00
    phi[3,0]  R472      -2.1427626609802246e+00
    phi[3,0]  R473      -1.4330477714538574e+00
    phi[3,0]  R474      1.0308989882469177e-01
    phi[3,0]  R475      -0.808255136013031
    phi[3,0]  R476      -6.3720744848251343e-01
    phi[3,0]  R477      -1.4937438964843750e+00
    phi[3,0]  R478      -1.6502450704574585e+00
    phi[3,0]  R479      -1.6489876508712769e+00
    phi[3,0]  R480      -7.3454529047012329e-01
    phi[3,0]  R481      4.4977761805057526e-02
    phi[3,0]  R482      -2.0196260511875153e-01
    phi[3,0]  R483      -7.8055971860885620e-01
    phi[3,0]  R484      4.6232786774635315e-01
    phi[3,0]  R485      -5.8772891759872437e-01
    phi[3,0]  R486      3.8126997649669647e-02
    phi[3,0]  R487      -4.7900289297103882e-01
    phi[3,0]  R488      -1.1507971286773682e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R489      -3.0999999046325684e+00
    phi[0,4]  R490      -3.0999999046325684e+00
    phi[0,4]  R491      -2.2400000095367432e+00
    phi[0,4]  R492      -2.2400000095367432e+00
    phi[0,4]  R493      -3.0999999046325684e+00
    phi[0,4]  R494      -3.0999999046325684e+00
    phi[0,4]  R495      -2.5699999332427979e+00
    phi[0,4]  R496      -2.5699999332427979e+00
    phi[0,4]  R497      -3.0999999046325684e+00
    phi[0,4]  R498      -3.0999999046325684e+00
    phi[0,4]  R499      -2.0899999141693115e+00
    phi[0,4]  R500      -2.0899999141693115e+00
    phi[0,4]  R501      -3.0999999046325684e+00
    phi[0,4]  R502      -3.0999999046325684e+00
    phi[0,4]  R503      -6.2153726816177368e-01
    phi[0,4]  R504      3.8615599274635315e-01
    phi[0,4]  R505      -1.0438578128814697e+00
    phi[0,4]  R506      1.3706934452056885e-01
    phi[0,4]  R507      -8.5207962989807129e-01
    phi[0,4]  R508      2.4053584039211273e-01
    phi[0,4]  R509      7.8570723533630371e-02
    phi[0,4]  R510      4.4882947206497192e-01
    phi[0,4]  R511      -4.7162252664566040e-01
    phi[0,4]  R512      -1.0017442703247070e+00
    phi[0,4]  R513      -2.7992680072784424e+00
    phi[0,4]  R514      -1.9010308980941772e+00
    phi[0,4]  R515      -3.4234778881073
    phi[0,4]  R516      -2.5409832000732422e+00
    phi[0,4]  R517      -1.2280702590942383e+00
    phi[0,4]  R518      -8.0999964475631714e-01
    phi[0,4]  R519      -3.6448273062705994e-01
    phi[0,4]  R520      -1.2171106338500977e+00
    phi[0,4]  R521      -1.1339445114135742e+00
    phi[0,4]  R522      -1.0835635662078857e+00
    phi[0,4]  R523      -2.4785332679748535e+00
    phi[0,4]  R524      -1.5225770473480225e+00
    phi[0,4]  R525      -8.6607795953750610e-01
    phi[0,4]  R526      -2.8976552486419678e+00
    phi[0,4]  R527      -2.0128101110458374e-01
    phi[0,4]  R528      -3.4269950389862061e+00
    phi[0,4]  R529      1.5081332623958588e-01
    phi[0,4]  R530      -4.2730599641799927e-01
    phi[0,4]  R531      -2.1635155677795410e+00
    phi[0,4]  R532      -8.9301371574401855e-01
    phi[0,4]  R533      -2.3681366443634033e+00
    phi[0,4]  R534      -2.4416394233703613e+00
    phi[0,4]  R535      -3.0007560253143311e+00
    phi[0,4]  R536      -2.1427626609802246e+00
    phi[0,4]  R537      -1.4330477714538574e+00
    phi[0,4]  R538      1.0308989882469177e-01
    phi[0,4]  R539      -0.808255136013031
    phi[0,4]  R540      -6.3720744848251343e-01
    phi[0,4]  R541      -1.4937438964843750e+00
    phi[0,4]  R542      -1.6502450704574585e+00
    phi[0,4]  R543      -1.6489876508712769e+00
    phi[0,4]  R544      -7.3454529047012329e-01
    phi[0,4]  R545      4.4977761805057526e-02
    phi[0,4]  R546      -2.0196260511875153e-01
    phi[0,4]  R547      -7.8055971860885620e-01
    phi[0,4]  R548      4.6232786774635315e-01
    phi[0,4]  R549      -5.8772891759872437e-01
    phi[0,4]  R550      3.8126997649669647e-02
    phi[0,4]  R551      -4.7900289297103882e-01
    phi[0,4]  R552      -1.1507971286773682e+00
    phi[0,4]  R553      -2.6620849967002869e-01
    phi[0,4]  R554      6.1780887842178345e-01
    phi[0,4]  R555      0.597108781337738
    phi[0,4]  R556      -1.4282256364822388e-01
    phi[0,4]  R557      -4.2112955451011658e-01
    phi[0,4]  R558      -1.3484647870063782e-01
    phi[0,4]  R559      -1.5079364776611328e+00
    phi[0,4]  R560      -1.9822832345962524e+00
    phi[0,4]  R561      3.5428437590599060e-01
    phi[0,4]  R562      0.698932945728302
    phi[0,4]  R563      -1.0542341470718384e+00
    phi[0,4]  R564      -4.5922747254371643e-01
    phi[0,4]  R565      4.8277759552001953e-01
    phi[0,4]  R566      1.4037504792213440e-01
    phi[0,4]  R567      5.0263667106628418e-01
    phi[0,4]  R568      4.3771672248840332e-01
    phi[0,4]  R569      8.9146739244461060e-01
    phi[0,4]  R570      3.4647789597511292e-01
    phi[0,4]  R571      2.4962033331394196e-01
    phi[0,4]  R572      -3.3308632671833038e-02
    phi[0,4]  R573      -4.5381525158882141e-01
    phi[0,4]  R574      -7.7385807037353516e-01
    phi[0,4]  R575      -6.0524034500122070e-01
    phi[0,4]  R576      -1.1582537889480591e+00
    phi[0,4]  R577      -3.7087512016296387e-01
    phi[0,4]  R578      -1.0231051445007324e+00
    phi[0,4]  R579      -5.2838349342346191e-01
    phi[0,4]  R580      -1.2783248424530029e+00
    phi[0,4]  R581      -5.0509929656982422e-01
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R582      -3.0999999046325684e+00
    phi[4,0]  R583      -3.0999999046325684e+00
    phi[4,0]  R584      -2.2400000095367432e+00
    phi[4,0]  R585      -2.2400000095367432e+00
    phi[4,0]  R586      -3.0999999046325684e+00
    phi[4,0]  R587      -3.0999999046325684e+00
    phi[4,0]  R588      -2.5699999332427979e+00
    phi[4,0]  R589      -2.5699999332427979e+00
    phi[4,0]  R590      -3.0999999046325684e+00
    phi[4,0]  R591      -3.0999999046325684e+00
    phi[4,0]  R592      -2.0899999141693115e+00
    phi[4,0]  R593      -2.0899999141693115e+00
    phi[4,0]  R594      -3.0999999046325684e+00
    phi[4,0]  R595      -3.0999999046325684e+00
    phi[4,0]  R596      -2.6620849967002869e-01
    phi[4,0]  R597      6.1780887842178345e-01
    phi[4,0]  R598      0.597108781337738
    phi[4,0]  R599      -1.4282256364822388e-01
    phi[4,0]  R600      -4.2112955451011658e-01
    phi[4,0]  R601      -1.3484647870063782e-01
    phi[4,0]  R602      -1.5079364776611328e+00
    phi[4,0]  R603      -1.9822832345962524e+00
    phi[4,0]  R604      3.5428437590599060e-01
    phi[4,0]  R605      0.698932945728302
    phi[4,0]  R606      -1.0542341470718384e+00
    phi[4,0]  R607      -4.5922747254371643e-01
    phi[4,0]  R608      4.8277759552001953e-01
    phi[4,0]  R609      1.4037504792213440e-01
    phi[4,0]  R610      5.0263667106628418e-01
    phi[4,0]  R611      4.3771672248840332e-01
    phi[4,0]  R612      8.9146739244461060e-01
    phi[4,0]  R613      3.4647789597511292e-01
    phi[4,0]  R614      2.4962033331394196e-01
    phi[4,0]  R615      -3.3308632671833038e-02
    phi[4,0]  R616      -4.5381525158882141e-01
    phi[4,0]  R617      -7.7385807037353516e-01
    phi[4,0]  R618      -6.0524034500122070e-01
    phi[4,0]  R619      -1.1582537889480591e+00
    phi[4,0]  R620      -3.7087512016296387e-01
    phi[4,0]  R621      -1.0231051445007324e+00
    phi[4,0]  R622      -5.2838349342346191e-01
    phi[4,0]  R623      -1.2783248424530029e+00
    phi[4,0]  R624      -5.0509929656982422e-01
    phi[4,0]  R625      -6.2153726816177368e-01
    phi[4,0]  R626      3.8615599274635315e-01
    phi[4,0]  R627      -1.0438578128814697e+00
    phi[4,0]  R628      1.3706934452056885e-01
    phi[4,0]  R629      -8.5207962989807129e-01
    phi[4,0]  R630      2.4053584039211273e-01
    phi[4,0]  R631      7.8570723533630371e-02
    phi[4,0]  R632      4.4882947206497192e-01
    phi[4,0]  R633      -4.7162252664566040e-01
    phi[4,0]  R634      -1.0017442703247070e+00
    phi[4,0]  R635      -2.7992680072784424e+00
    phi[4,0]  R636      -1.9010308980941772e+00
    phi[4,0]  R637      -3.4234778881073
    phi[4,0]  R638      -2.5409832000732422e+00
    phi[4,0]  R639      -1.2280702590942383e+00
    phi[4,0]  R640      -8.0999964475631714e-01
    phi[4,0]  R641      -3.6448273062705994e-01
    phi[4,0]  R642      -1.2171106338500977e+00
    phi[4,0]  R643      -1.1339445114135742e+00
    phi[4,0]  R644      -1.0835635662078857e+00
    phi[4,0]  R645      -2.4785332679748535e+00
    phi[4,0]  R646      -1.5225770473480225e+00
    phi[4,0]  R647      -8.6607795953750610e-01
    phi[4,0]  R648      -2.8976552486419678e+00
    phi[4,0]  R649      -2.0128101110458374e-01
    phi[4,0]  R650      -3.4269950389862061e+00
    phi[4,0]  R651      1.5081332623958588e-01
    phi[4,0]  R652      -4.2730599641799927e-01
    phi[4,0]  R653      -2.1635155677795410e+00
    phi[4,0]  R654      -8.9301371574401855e-01
    phi[4,0]  R655      -2.3681366443634033e+00
    phi[4,0]  R656      -2.4416394233703613e+00
    phi[4,0]  R657      -3.0007560253143311e+00
    phi[4,0]  R658      -2.1427626609802246e+00
    phi[4,0]  R659      -1.4330477714538574e+00
    phi[4,0]  R660      1.0308989882469177e-01
    phi[4,0]  R661      -0.808255136013031
    phi[4,0]  R662      -6.3720744848251343e-01
    phi[4,0]  R663      -1.4937438964843750e+00
    phi[4,0]  R664      -1.6502450704574585e+00
    phi[4,0]  R665      -1.6489876508712769e+00
    phi[4,0]  R666      -7.3454529047012329e-01
    phi[4,0]  R667      4.4977761805057526e-02
    phi[4,0]  R668      -2.0196260511875153e-01
    phi[4,0]  R669      -7.8055971860885620e-01
    phi[4,0]  R670      4.6232786774635315e-01
    phi[4,0]  R671      -5.8772891759872437e-01
    phi[4,0]  R672      3.8126997649669647e-02
    phi[4,0]  R673      -4.7900289297103882e-01
    phi[4,0]  R674      -1.1507971286773682e+00
    phi[7,0]  R0        -1
    phi[7,0]  R2        2.3795410456599257e+00
    phi[7,0]  R3        4.9418230632458737e-01
    phi[7,0]  R4        1.7236009477472281e+00
    phi[7,0]  R5        -3.2571415741751997e-01
    phi[7,0]  R6        2.2724450891951746e+00
    phi[7,0]  R7        4.4884213324225586e-01
    phi[7,0]  R8        -2.3026884603500104e+00
    phi[7,0]  R63       1
    phi[7,0]  R675      -5.4795409502924937e+00
    phi[7,0]  R676      -7.2045885897264261e-01
    phi[7,0]  R677      -2.7341823158613305e+00
    phi[7,0]  R678      -1.7458177032121558e+00
    phi[7,0]  R679      -4.8236008523797960e+00
    phi[7,0]  R680      -1.3763989568853403e+00
    phi[7,0]  R681      -2.2442857758252779e+00
    phi[7,0]  R682      -2.8957140906603178e+00
    phi[7,0]  R683      -5.3724449938277434e+00
    phi[7,0]  R684      -8.2755481543739373e-01
    phi[7,0]  R685      -2.5388420474115674e+00
    phi[7,0]  R686      -1.6411577809270557e+00
    phi[7,0]  R687      -0.797311444282558
    phi[7,0]  R688      -5.4026883649825788e+00
    phi[7,0]  R689      -3.1319633856240375e-01
    phi[7,0]  R690      -3.1958753180130239e-01
    phi[7,0]  R691      -3.6745433867621791e-01
    phi[7,0]  R692      -3.7022785137526026e-01
    phi[7,0]  R693      -3.7202023301329190e-01
    phi[7,0]  R694      -3.8573697142758234e-01
    phi[7,0]  R695      -3.8640831505702333e-01
    phi[7,0]  R696      -4.0277236559089757e-01
    phi[7,0]  R697      -4.0877705484897320e-01
    phi[7,0]  R698      -4.1062510258035145e-01
    phi[7,0]  R699      -3.9421786172237017e-01
    phi[7,0]  R700      -0.470637639847201
    phi[7,0]  R701      -5.0601467020503055e-01
    phi[7,0]  R702      -5.2392466144058325e-01
    phi[7,0]  R703      -5.7417160870018458e-01
    phi[7,0]  R704      -5.7545603230349507e-01
    phi[7,0]  R705      -5.8301804442490424e-01
    phi[7,0]  R706      -5.8773259239889053e-01
    phi[7,0]  R707      -5.8829552606820668e-01
    phi[7,0]  R708      -5.9100033660011864e-01
    phi[7,0]  R709      -4.3643062821174716e-01
    phi[7,0]  R710      -4.4665532618142390e-01
    phi[7,0]  R711      -4.6771511664192156e-01
    phi[7,0]  R712      -4.7776770017628323e-01
    phi[7,0]  R713      -4.7933989951933431e-01
    phi[7,0]  R714      -4.8729640193297818e-01
    phi[7,0]  R715      -4.9044201831142387e-01
    phi[7,0]  R716      -0.501081240876079
    phi[7,0]  R717      -5.0323988795613550e-01
    phi[7,0]  R718      -5.0452966063555094e-01
    phi[7,0]  R719      -3.4489187593268866e-01
    phi[7,0]  R720      -3.5042724050035989e-01
    phi[7,0]  R721      -3.9977714357221128e-01
    phi[7,0]  R722      -4.0912242422665468e-01
    phi[7,0]  R723      -4.2541447578313352e-01
    phi[7,0]  R724      -4.3856310030019119e-01
    phi[7,0]  R725      -4.4313686380571771e-01
    phi[7,0]  R726      -4.5465181926663129e-01
    phi[7,0]  R727      -4.8396156474294272e-01
    phi[7,0]  R728      -4.8891637469349192e-01
    phi[7,0]  R729      -3.8497300602924822e-01
    phi[7,0]  R730      -4.2124487966058344e-01
    phi[7,0]  R731      -4.8044734094150776e-01
    phi[7,0]  R732      -5.0535113889812311e-01
    phi[7,0]  R733      -0.530290510227822
    phi[7,0]  R734      -5.5108916099909866e-01
    phi[7,0]  R735      -5.5906864877303641e-01
    phi[7,0]  R736      -5.8428773026336867e-01
    phi[7,0]  R737      -0.63876754610385
    phi[7,0]  R738      -6.4553621334700517e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R739      -3.0999999046325684e+00
    phi[1,2]  R740      -3.0999999046325684e+00
    phi[1,2]  R741      -2.2400000095367432e+00
    phi[1,2]  R742      -2.2400000095367432e+00
    phi[1,2]  R743      -3.0999999046325684e+00
    phi[1,2]  R744      -3.0999999046325684e+00
    phi[1,2]  R745      -2.5699999332427979e+00
    phi[1,2]  R746      -2.5699999332427979e+00
    phi[1,2]  R747      -3.0999999046325684e+00
    phi[1,2]  R748      -3.0999999046325684e+00
    phi[1,2]  R749      -2.0899999141693115e+00
    phi[1,2]  R750      -2.0899999141693115e+00
    phi[1,2]  R751      -3.0999999046325684e+00
    phi[1,2]  R752      -3.0999999046325684e+00
    phi[1,2]  R753      1.9664230346679688e+00
    phi[1,2]  R754      2.0808558464050293e+00
    phi[1,2]  R755      1.2804361581802368e+00
    phi[1,2]  R756      1.4970929622650146e+00
    phi[1,2]  R757      1.6670113801956177e+00
    phi[1,2]  R758      6.8956357240676880e-01
    phi[1,2]  R759      3.7077087163925171e-01
    phi[1,2]  R760      -3.7168118357658386e-01
    phi[1,2]  R761      -1.4298155903816223e-01
    phi[1,2]  R762      -1.0029788017272949e+00
    phi[1,2]  R763      -9.8529952764511108e-01
    phi[1,2]  R764      -3.9680135250091553e-01
    phi[1,2]  R765      -3.1370067596435547e-01
    phi[1,2]  R766      -2.0499134063720703e+00
    phi[1,2]  R767      8.1695950031280518e-01
    phi[1,2]  R768      -4.3905954360961914e+00
    phi[1,2]  R769      -3.3153734207153320e+00
    phi[1,2]  R770      -1.8261700868606567e+00
    phi[1,2]  R771      -2.3661906719207764e+00
    phi[1,2]  R772      -1.7181274890899658e+00
    phi[1,2]  R773      -1.6641924381256104e+00
    phi[1,2]  R774      -1.5336719751358032e+00
    phi[1,2]  R775      -9.6779960393905640e-01
    phi[1,2]  R776      -1.1057369709014893e+00
    phi[1,2]  R777      8.4525831043720245e-02
    phi[1,2]  R778      -1.3610336780548096e+00
    phi[1,2]  R779      -2.2789260745048523e-01
    phi[1,2]  R780      -1.4055078029632568e+00
    phi[1,2]  R781      -0.930335283279419
    phi[1,2]  R782      -1.0332182645797729e+00
    phi[1,2]  R783      1.5764783322811127e-01
    phi[1,2]  R784      6.6788923740386963e-01
    phi[1,2]  R785      8.8056391477584839e-01
    phi[1,2]  R786      0.979372501373291
    phi[1,2]  R787      -9.0368163585662842e-01
    phi[1,2]  R788      4.6497848629951477e-01
    phi[1,2]  R789      -3.8870871067047119e+00
    phi[1,2]  R790      -1.8786684274673462e+00
    phi[1,2]  R791      -1.7773544788360596e+00
    phi[1,2]  R792      -1.2514928579330444e+00
    phi[1,2]  R793      -1.2448586225509644e+00
    phi[1,2]  R794      -4.0075969696044922e+00
    phi[1,2]  R795      1.2261536121368408e+00
    phi[1,2]  R796      -9.5557585358619690e-02
    phi[1,2]  R797      -1.6775109767913818e+00
    phi[1,2]  R798      -1.2371207475662231e+00
    phi[1,2]  R799      -6.4163094758987427e-01
    phi[1,2]  R800      -2.1518533229827881e+00
    phi[1,2]  R801      -2.9930369928479195e-02
    phi[1,2]  R802      3.4267935752868652e+00
    phi[1,2]  R803      3.1847443580627441e+00
    phi[1,2]  R804      1.3899818658828735e+00
    phi[1,2]  R805      2.7984743118286133e+00
    phi[1,2]  R806      1.6508650779724121e+00
    phi[1,2]  R807      1.3627080917358398e+00
    phi[1,2]  R808      2.7761211395263672e+00
    phi[1,2]  R809      1.6322623491287231e+00
    phi[1,2]  R810      1.3762626647949219e+00
    phi[1,2]  R811      6.3023847341537476e-01
    phi[1,2]  R812      -3.2493534088134766e+00
    phi[1,2]  R813      -3.3668019771575928e+00
    phi[1,2]  R814      -3.5817096233367920e+00
    phi[1,2]  R815      -2.8174347877502441e+00
    phi[1,2]  R816      -8.1501394510269165e-01
    phi[1,2]  R817      -2.9840941429138184e+00
    phi[1,2]  R818      -8.5487204790115356e-01
    phi[1,2]  R819      -2.4057426452636719e+00
    phi[1,2]  R820      -1.2419953346252441e+00
    phi[1,2]  R821      -1.4479204416275024e+00
    phi[1,2]  R822      -1.8027145862579346e+00
    phi[1,2]  R823      -7.8940087556838989e-01
    phi[1,2]  R824      -1.6639393568038940e+00
    phi[1,2]  R825      -5.3820240497589111e-01
    phi[1,2]  R826      3.4851136803627014e-01
    phi[1,2]  R827      -7.4307215213775635e-01
    phi[1,2]  R828      -3.8825172185897827e-01
    phi[1,2]  R829      6.8314611911773682e-02
    phi[1,2]  R830      1.2263700366020203e-01
    phi[1,2]  R831      -1.2162035703659058e+00
    phi[1,2]  R832      -1.0650695562362671e+00
    phi[1,2]  R833      -5.2027985453605652e-02
    phi[1,2]  R834      2.7847609519958496e+00
    phi[1,2]  R835      2.9651448130607605e-01
    phi[1,2]  R836      -9.4075784087181091e-02
    phi[1,2]  R837      4.3631577491760254e-01
    phi[1,2]  R838      1.3488855361938477e+00
    phi[1,2]  R839      3.1169718503952026e-01
    phi[1,2]  R840      -3.2607132196426392e-01
    phi[1,2]  R841      4.4164359569549561e-03
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R842      -3.0999999046325684e+00
    phi[2,1]  R843      -3.0999999046325684e+00
    phi[2,1]  R844      -2.2400000095367432e+00
    phi[2,1]  R845      -2.2400000095367432e+00
    phi[2,1]  R846      -3.0999999046325684e+00
    phi[2,1]  R847      -3.0999999046325684e+00
    phi[2,1]  R848      -2.5699999332427979e+00
    phi[2,1]  R849      -2.5699999332427979e+00
    phi[2,1]  R850      -3.0999999046325684e+00
    phi[2,1]  R851      -3.0999999046325684e+00
    phi[2,1]  R852      -2.0899999141693115e+00
    phi[2,1]  R853      -2.0899999141693115e+00
    phi[2,1]  R854      -3.0999999046325684e+00
    phi[2,1]  R855      -3.0999999046325684e+00
    phi[2,1]  R856      3.4267935752868652e+00
    phi[2,1]  R857      3.1847443580627441e+00
    phi[2,1]  R858      1.3899818658828735e+00
    phi[2,1]  R859      2.7984743118286133e+00
    phi[2,1]  R860      1.6508650779724121e+00
    phi[2,1]  R861      1.3627080917358398e+00
    phi[2,1]  R862      2.7761211395263672e+00
    phi[2,1]  R863      1.6322623491287231e+00
    phi[2,1]  R864      1.3762626647949219e+00
    phi[2,1]  R865      6.3023847341537476e-01
    phi[2,1]  R866      -3.2493534088134766e+00
    phi[2,1]  R867      -3.3668019771575928e+00
    phi[2,1]  R868      -3.5817096233367920e+00
    phi[2,1]  R869      -2.8174347877502441e+00
    phi[2,1]  R870      -8.1501394510269165e-01
    phi[2,1]  R871      -2.9840941429138184e+00
    phi[2,1]  R872      -8.5487204790115356e-01
    phi[2,1]  R873      -2.4057426452636719e+00
    phi[2,1]  R874      -1.2419953346252441e+00
    phi[2,1]  R875      -1.4479204416275024e+00
    phi[2,1]  R876      -1.8027145862579346e+00
    phi[2,1]  R877      -7.8940087556838989e-01
    phi[2,1]  R878      -1.6639393568038940e+00
    phi[2,1]  R879      -5.3820240497589111e-01
    phi[2,1]  R880      3.4851136803627014e-01
    phi[2,1]  R881      -7.4307215213775635e-01
    phi[2,1]  R882      -3.8825172185897827e-01
    phi[2,1]  R883      6.8314611911773682e-02
    phi[2,1]  R884      1.2263700366020203e-01
    phi[2,1]  R885      -1.2162035703659058e+00
    phi[2,1]  R886      -1.0650695562362671e+00
    phi[2,1]  R887      -5.2027985453605652e-02
    phi[2,1]  R888      2.7847609519958496e+00
    phi[2,1]  R889      2.9651448130607605e-01
    phi[2,1]  R890      -9.4075784087181091e-02
    phi[2,1]  R891      4.3631577491760254e-01
    phi[2,1]  R892      1.3488855361938477e+00
    phi[2,1]  R893      3.1169718503952026e-01
    phi[2,1]  R894      -3.2607132196426392e-01
    phi[2,1]  R895      4.4164359569549561e-03
    phi[2,1]  R896      1.9664230346679688e+00
    phi[2,1]  R897      2.0808558464050293e+00
    phi[2,1]  R898      1.2804361581802368e+00
    phi[2,1]  R899      1.4970929622650146e+00
    phi[2,1]  R900      1.6670113801956177e+00
    phi[2,1]  R901      6.8956357240676880e-01
    phi[2,1]  R902      3.7077087163925171e-01
    phi[2,1]  R903      -3.7168118357658386e-01
    phi[2,1]  R904      -1.4298155903816223e-01
    phi[2,1]  R905      -1.0029788017272949e+00
    phi[2,1]  R906      -9.8529952764511108e-01
    phi[2,1]  R907      -3.9680135250091553e-01
    phi[2,1]  R908      -3.1370067596435547e-01
    phi[2,1]  R909      -2.0499134063720703e+00
    phi[2,1]  R910      8.1695950031280518e-01
    phi[2,1]  R911      -4.3905954360961914e+00
    phi[2,1]  R912      -3.3153734207153320e+00
    phi[2,1]  R913      -1.8261700868606567e+00
    phi[2,1]  R914      -2.3661906719207764e+00
    phi[2,1]  R915      -1.7181274890899658e+00
    phi[2,1]  R916      -1.6641924381256104e+00
    phi[2,1]  R917      -1.5336719751358032e+00
    phi[2,1]  R918      -9.6779960393905640e-01
    phi[2,1]  R919      -1.1057369709014893e+00
    phi[2,1]  R920      8.4525831043720245e-02
    phi[2,1]  R921      -1.3610336780548096e+00
    phi[2,1]  R922      -2.2789260745048523e-01
    phi[2,1]  R923      -1.4055078029632568e+00
    phi[2,1]  R924      -0.930335283279419
    phi[2,1]  R925      -1.0332182645797729e+00
    phi[2,1]  R926      1.5764783322811127e-01
    phi[2,1]  R927      6.6788923740386963e-01
    phi[2,1]  R928      8.8056391477584839e-01
    phi[2,1]  R929      0.979372501373291
    phi[2,1]  R930      -9.0368163585662842e-01
    phi[2,1]  R931      4.6497848629951477e-01
    phi[2,1]  R932      -3.8870871067047119e+00
    phi[2,1]  R933      -1.8786684274673462e+00
    phi[2,1]  R934      -1.7773544788360596e+00
    phi[2,1]  R935      -1.2514928579330444e+00
    phi[2,1]  R936      -1.2448586225509644e+00
    phi[2,1]  R937      -4.0075969696044922e+00
    phi[2,1]  R938      1.2261536121368408e+00
    phi[2,1]  R939      -9.5557585358619690e-02
    phi[2,1]  R940      -1.6775109767913818e+00
    phi[2,1]  R941      -1.2371207475662231e+00
    phi[2,1]  R942      -6.4163094758987427e-01
    phi[2,1]  R943      -2.1518533229827881e+00
    phi[2,1]  R944      -2.9930369928479195e-02
    phi[1,4]  R9        1
    phi[1,4]  R10       1
    phi[1,4]  R36       -1
    phi[1,4]  R945      -3.0999999046325684e+00
    phi[1,4]  R946      -3.0999999046325684e+00
    phi[1,4]  R947      -2.2400000095367432e+00
    phi[1,4]  R948      -2.2400000095367432e+00
    phi[1,4]  R949      -3.0999999046325684e+00
    phi[1,4]  R950      -3.0999999046325684e+00
    phi[1,4]  R951      -2.5699999332427979e+00
    phi[1,4]  R952      -2.5699999332427979e+00
    phi[1,4]  R953      -3.0999999046325684e+00
    phi[1,4]  R954      -3.0999999046325684e+00
    phi[1,4]  R955      -2.0899999141693115e+00
    phi[1,4]  R956      -2.0899999141693115e+00
    phi[1,4]  R957      -3.0999999046325684e+00
    phi[1,4]  R958      -3.0999999046325684e+00
    phi[1,4]  R959      1.9664230346679688e+00
    phi[1,4]  R960      2.0808558464050293e+00
    phi[1,4]  R961      1.2804361581802368e+00
    phi[1,4]  R962      1.4970929622650146e+00
    phi[1,4]  R963      1.6670113801956177e+00
    phi[1,4]  R964      6.8956357240676880e-01
    phi[1,4]  R965      3.7077087163925171e-01
    phi[1,4]  R966      -3.7168118357658386e-01
    phi[1,4]  R967      -1.4298155903816223e-01
    phi[1,4]  R968      -1.0029788017272949e+00
    phi[1,4]  R969      -9.8529952764511108e-01
    phi[1,4]  R970      -3.9680135250091553e-01
    phi[1,4]  R971      -3.1370067596435547e-01
    phi[1,4]  R972      -2.0499134063720703e+00
    phi[1,4]  R973      8.1695950031280518e-01
    phi[1,4]  R974      -4.3905954360961914e+00
    phi[1,4]  R975      -3.3153734207153320e+00
    phi[1,4]  R976      -1.8261700868606567e+00
    phi[1,4]  R977      -2.3661906719207764e+00
    phi[1,4]  R978      -1.7181274890899658e+00
    phi[1,4]  R979      -1.6641924381256104e+00
    phi[1,4]  R980      -1.5336719751358032e+00
    phi[1,4]  R981      -9.6779960393905640e-01
    phi[1,4]  R982      -1.1057369709014893e+00
    phi[1,4]  R983      8.4525831043720245e-02
    phi[1,4]  R984      -1.3610336780548096e+00
    phi[1,4]  R985      -2.2789260745048523e-01
    phi[1,4]  R986      -1.4055078029632568e+00
    phi[1,4]  R987      -0.930335283279419
    phi[1,4]  R988      -1.0332182645797729e+00
    phi[1,4]  R989      1.5764783322811127e-01
    phi[1,4]  R990      6.6788923740386963e-01
    phi[1,4]  R991      8.8056391477584839e-01
    phi[1,4]  R992      0.979372501373291
    phi[1,4]  R993      -9.0368163585662842e-01
    phi[1,4]  R994      4.6497848629951477e-01
    phi[1,4]  R995      -3.8870871067047119e+00
    phi[1,4]  R996      -1.8786684274673462e+00
    phi[1,4]  R997      -1.7773544788360596e+00
    phi[1,4]  R998      -1.2514928579330444e+00
    phi[1,4]  R999      -1.2448586225509644e+00
    phi[1,4]  R1000     -4.0075969696044922e+00
    phi[1,4]  R1001     1.2261536121368408e+00
    phi[1,4]  R1002     -9.5557585358619690e-02
    phi[1,4]  R1003     -1.6775109767913818e+00
    phi[1,4]  R1004     -1.2371207475662231e+00
    phi[1,4]  R1005     -6.4163094758987427e-01
    phi[1,4]  R1006     -2.1518533229827881e+00
    phi[1,4]  R1007     -2.9930369928479195e-02
    phi[1,4]  R1008     -2.6620849967002869e-01
    phi[1,4]  R1009     6.1780887842178345e-01
    phi[1,4]  R1010     0.597108781337738
    phi[1,4]  R1011     -1.4282256364822388e-01
    phi[1,4]  R1012     -4.2112955451011658e-01
    phi[1,4]  R1013     -1.3484647870063782e-01
    phi[1,4]  R1014     -1.5079364776611328e+00
    phi[1,4]  R1015     -1.9822832345962524e+00
    phi[1,4]  R1016     3.5428437590599060e-01
    phi[1,4]  R1017     0.698932945728302
    phi[1,4]  R1018     -1.0542341470718384e+00
    phi[1,4]  R1019     -4.5922747254371643e-01
    phi[1,4]  R1020     4.8277759552001953e-01
    phi[1,4]  R1021     1.4037504792213440e-01
    phi[1,4]  R1022     5.0263667106628418e-01
    phi[1,4]  R1023     4.3771672248840332e-01
    phi[1,4]  R1024     8.9146739244461060e-01
    phi[1,4]  R1025     3.4647789597511292e-01
    phi[1,4]  R1026     2.4962033331394196e-01
    phi[1,4]  R1027     -3.3308632671833038e-02
    phi[1,4]  R1028     -4.5381525158882141e-01
    phi[1,4]  R1029     -7.7385807037353516e-01
    phi[1,4]  R1030     -6.0524034500122070e-01
    phi[1,4]  R1031     -1.1582537889480591e+00
    phi[1,4]  R1032     -3.7087512016296387e-01
    phi[1,4]  R1033     -1.0231051445007324e+00
    phi[1,4]  R1034     -5.2838349342346191e-01
    phi[1,4]  R1035     -1.2783248424530029e+00
    phi[1,4]  R1036     -5.0509929656982422e-01
    phi[4,1]  R9        -1
    phi[4,1]  R36       1
    phi[4,1]  R37       1
    phi[4,1]  R1037     -3.0999999046325684e+00
    phi[4,1]  R1038     -3.0999999046325684e+00
    phi[4,1]  R1039     -2.2400000095367432e+00
    phi[4,1]  R1040     -2.2400000095367432e+00
    phi[4,1]  R1041     -3.0999999046325684e+00
    phi[4,1]  R1042     -3.0999999046325684e+00
    phi[4,1]  R1043     -2.5699999332427979e+00
    phi[4,1]  R1044     -2.5699999332427979e+00
    phi[4,1]  R1045     -3.0999999046325684e+00
    phi[4,1]  R1046     -3.0999999046325684e+00
    phi[4,1]  R1047     -2.0899999141693115e+00
    phi[4,1]  R1048     -2.0899999141693115e+00
    phi[4,1]  R1049     -3.0999999046325684e+00
    phi[4,1]  R1050     -3.0999999046325684e+00
    phi[4,1]  R1051     -2.6620849967002869e-01
    phi[4,1]  R1052     6.1780887842178345e-01
    phi[4,1]  R1053     0.597108781337738
    phi[4,1]  R1054     -1.4282256364822388e-01
    phi[4,1]  R1055     -4.2112955451011658e-01
    phi[4,1]  R1056     -1.3484647870063782e-01
    phi[4,1]  R1057     -1.5079364776611328e+00
    phi[4,1]  R1058     -1.9822832345962524e+00
    phi[4,1]  R1059     3.5428437590599060e-01
    phi[4,1]  R1060     0.698932945728302
    phi[4,1]  R1061     -1.0542341470718384e+00
    phi[4,1]  R1062     -4.5922747254371643e-01
    phi[4,1]  R1063     4.8277759552001953e-01
    phi[4,1]  R1064     1.4037504792213440e-01
    phi[4,1]  R1065     5.0263667106628418e-01
    phi[4,1]  R1066     4.3771672248840332e-01
    phi[4,1]  R1067     8.9146739244461060e-01
    phi[4,1]  R1068     3.4647789597511292e-01
    phi[4,1]  R1069     2.4962033331394196e-01
    phi[4,1]  R1070     -3.3308632671833038e-02
    phi[4,1]  R1071     -4.5381525158882141e-01
    phi[4,1]  R1072     -7.7385807037353516e-01
    phi[4,1]  R1073     -6.0524034500122070e-01
    phi[4,1]  R1074     -1.1582537889480591e+00
    phi[4,1]  R1075     -3.7087512016296387e-01
    phi[4,1]  R1076     -1.0231051445007324e+00
    phi[4,1]  R1077     -5.2838349342346191e-01
    phi[4,1]  R1078     -1.2783248424530029e+00
    phi[4,1]  R1079     -5.0509929656982422e-01
    phi[4,1]  R1080     1.9664230346679688e+00
    phi[4,1]  R1081     2.0808558464050293e+00
    phi[4,1]  R1082     1.2804361581802368e+00
    phi[4,1]  R1083     1.4970929622650146e+00
    phi[4,1]  R1084     1.6670113801956177e+00
    phi[4,1]  R1085     6.8956357240676880e-01
    phi[4,1]  R1086     3.7077087163925171e-01
    phi[4,1]  R1087     -3.7168118357658386e-01
    phi[4,1]  R1088     -1.4298155903816223e-01
    phi[4,1]  R1089     -1.0029788017272949e+00
    phi[4,1]  R1090     -9.8529952764511108e-01
    phi[4,1]  R1091     -3.9680135250091553e-01
    phi[4,1]  R1092     -3.1370067596435547e-01
    phi[4,1]  R1093     -2.0499134063720703e+00
    phi[4,1]  R1094     8.1695950031280518e-01
    phi[4,1]  R1095     -4.3905954360961914e+00
    phi[4,1]  R1096     -3.3153734207153320e+00
    phi[4,1]  R1097     -1.8261700868606567e+00
    phi[4,1]  R1098     -2.3661906719207764e+00
    phi[4,1]  R1099     -1.7181274890899658e+00
    phi[4,1]  R1100     -1.6641924381256104e+00
    phi[4,1]  R1101     -1.5336719751358032e+00
    phi[4,1]  R1102     -9.6779960393905640e-01
    phi[4,1]  R1103     -1.1057369709014893e+00
    phi[4,1]  R1104     8.4525831043720245e-02
    phi[4,1]  R1105     -1.3610336780548096e+00
    phi[4,1]  R1106     -2.2789260745048523e-01
    phi[4,1]  R1107     -1.4055078029632568e+00
    phi[4,1]  R1108     -0.930335283279419
    phi[4,1]  R1109     -1.0332182645797729e+00
    phi[4,1]  R1110     1.5764783322811127e-01
    phi[4,1]  R1111     6.6788923740386963e-01
    phi[4,1]  R1112     8.8056391477584839e-01
    phi[4,1]  R1113     0.979372501373291
    phi[4,1]  R1114     -9.0368163585662842e-01
    phi[4,1]  R1115     4.6497848629951477e-01
    phi[4,1]  R1116     -3.8870871067047119e+00
    phi[4,1]  R1117     -1.8786684274673462e+00
    phi[4,1]  R1118     -1.7773544788360596e+00
    phi[4,1]  R1119     -1.2514928579330444e+00
    phi[4,1]  R1120     -1.2448586225509644e+00
    phi[4,1]  R1121     -4.0075969696044922e+00
    phi[4,1]  R1122     1.2261536121368408e+00
    phi[4,1]  R1123     -9.5557585358619690e-02
    phi[4,1]  R1124     -1.6775109767913818e+00
    phi[4,1]  R1125     -1.2371207475662231e+00
    phi[4,1]  R1126     -6.4163094758987427e-01
    phi[4,1]  R1127     -2.1518533229827881e+00
    phi[4,1]  R1128     -2.9930369928479195e-02
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R1129     -3.0999999046325684e+00
    phi[1,5]  R1130     -3.0999999046325684e+00
    phi[1,5]  R1131     -2.2400000095367432e+00
    phi[1,5]  R1132     -2.2400000095367432e+00
    phi[1,5]  R1133     -3.0999999046325684e+00
    phi[1,5]  R1134     -3.0999999046325684e+00
    phi[1,5]  R1135     -2.5699999332427979e+00
    phi[1,5]  R1136     -2.5699999332427979e+00
    phi[1,5]  R1137     -3.0999999046325684e+00
    phi[1,5]  R1138     -3.0999999046325684e+00
    phi[1,5]  R1139     -2.0899999141693115e+00
    phi[1,5]  R1140     -2.0899999141693115e+00
    phi[1,5]  R1141     -3.0999999046325684e+00
    phi[1,5]  R1142     -3.0999999046325684e+00
    phi[1,5]  R1143     1.9664230346679688e+00
    phi[1,5]  R1144     2.0808558464050293e+00
    phi[1,5]  R1145     1.2804361581802368e+00
    phi[1,5]  R1146     1.4970929622650146e+00
    phi[1,5]  R1147     1.6670113801956177e+00
    phi[1,5]  R1148     6.8956357240676880e-01
    phi[1,5]  R1149     3.7077087163925171e-01
    phi[1,5]  R1150     -3.7168118357658386e-01
    phi[1,5]  R1151     -1.4298155903816223e-01
    phi[1,5]  R1152     -1.0029788017272949e+00
    phi[1,5]  R1153     -9.8529952764511108e-01
    phi[1,5]  R1154     -3.9680135250091553e-01
    phi[1,5]  R1155     -3.1370067596435547e-01
    phi[1,5]  R1156     -2.0499134063720703e+00
    phi[1,5]  R1157     8.1695950031280518e-01
    phi[1,5]  R1158     -4.3905954360961914e+00
    phi[1,5]  R1159     -3.3153734207153320e+00
    phi[1,5]  R1160     -1.8261700868606567e+00
    phi[1,5]  R1161     -2.3661906719207764e+00
    phi[1,5]  R1162     -1.7181274890899658e+00
    phi[1,5]  R1163     -1.6641924381256104e+00
    phi[1,5]  R1164     -1.5336719751358032e+00
    phi[1,5]  R1165     -9.6779960393905640e-01
    phi[1,5]  R1166     -1.1057369709014893e+00
    phi[1,5]  R1167     8.4525831043720245e-02
    phi[1,5]  R1168     -1.3610336780548096e+00
    phi[1,5]  R1169     -2.2789260745048523e-01
    phi[1,5]  R1170     -1.4055078029632568e+00
    phi[1,5]  R1171     -0.930335283279419
    phi[1,5]  R1172     -1.0332182645797729e+00
    phi[1,5]  R1173     1.5764783322811127e-01
    phi[1,5]  R1174     6.6788923740386963e-01
    phi[1,5]  R1175     8.8056391477584839e-01
    phi[1,5]  R1176     0.979372501373291
    phi[1,5]  R1177     -9.0368163585662842e-01
    phi[1,5]  R1178     4.6497848629951477e-01
    phi[1,5]  R1179     -3.8870871067047119e+00
    phi[1,5]  R1180     -1.8786684274673462e+00
    phi[1,5]  R1181     -1.7773544788360596e+00
    phi[1,5]  R1182     -1.2514928579330444e+00
    phi[1,5]  R1183     -1.2448586225509644e+00
    phi[1,5]  R1184     -4.0075969696044922e+00
    phi[1,5]  R1185     1.2261536121368408e+00
    phi[1,5]  R1186     -9.5557585358619690e-02
    phi[1,5]  R1187     -1.6775109767913818e+00
    phi[1,5]  R1188     -1.2371207475662231e+00
    phi[1,5]  R1189     -6.4163094758987427e-01
    phi[1,5]  R1190     -2.1518533229827881e+00
    phi[1,5]  R1191     -2.9930369928479195e-02
    phi[1,5]  R1192     7.4282556772232056e-01
    phi[1,5]  R1193     2.9529479146003723e-01
    phi[1,5]  R1194     1.1315840482711792e+00
    phi[1,5]  R1195     4.4400626420974731e-01
    phi[1,5]  R1196     -6.2369279563426971e-02
    phi[1,5]  R1197     8.0027955770492554e-01
    phi[1,5]  R1198     5.8231145143508911e-01
    phi[1,5]  R1199     0.707918107509613
    phi[1,5]  R1200     1.4931190013885498e+00
    phi[1,5]  R1201     -7.5401759147644043e-01
    phi[1,5]  R1202     -6.9086164236068726e-01
    phi[1,5]  R1203     -1.6924331188201904e+00
    phi[1,5]  R1204     -2.3630063533782959e+00
    phi[1,5]  R1205     -2.3373171687126160e-01
    phi[1,5]  R1206     8.4866231679916382e-01
    phi[1,5]  R1207     1.0191968083381653e-01
    phi[1,5]  R1208     -8.9570456743240356e-01
    phi[1,5]  R1209     -1.2557879090309143e-01
    phi[1,5]  R1210     -2.5273486971855164e-01
    phi[1,5]  R1211     -2.1915815770626068e-01
    phi[1,5]  R1212     -2.1859364509582520e+00
    phi[1,5]  R1213     1.7728338241577148e+00
    phi[1,5]  R1214     -1.6886414289474487e+00
    phi[1,5]  R1215     -1.3068474531173706e+00
    phi[1,5]  R1216     -3.3660628795623779e+00
    phi[1,5]  R1217     -2.1086461544036865e+00
    phi[1,5]  R1218     -1.8140971660614014e+00
    phi[1,5]  R1219     -2.83530855178833
    phi[1,5]  R1220     -2.9731068611145020e+00
    phi[1,5]  R1221     -2.5195360183715820e+00
    phi[1,5]  R1222     -6.9067078828811646e-01
    phi[1,5]  R1223     -2.1897029876708984e+00
    phi[1,5]  R1224     -4.0695637464523315e-01
    phi[1,5]  R1225     -2.0363402366638184e+00
    phi[1,5]  R1226     5.6539326906204224e-01
    phi[1,5]  R1227     5.2155834436416626e-01
    phi[1,5]  R1228     9.5216894149780273e-01
    phi[1,5]  R1229     -0.985035240650177
    phi[1,5]  R1230     3.3206190913915634e-02
    phi[1,5]  R1231     2.0095043182373047e+00
    phi[1,5]  R1232     -3.2473711967468262e+00
    phi[1,5]  R1233     1.0882055759429932e+00
    phi[1,5]  R1234     2.2832448482513428e+00
    phi[1,5]  R1235     7.0544868707656860e-01
    phi[1,5]  R1236     1.1342386007308960e+00
    phi[1,5]  R1237     -1.6827241182327271e+00
    phi[1,5]  R1238     -3.2920449972152710e-01
    phi[1,5]  R1239     5.2749556303024292e-01
    phi[1,5]  R1240     2.0337255001068115e+00
    phi[1,5]  R1241     1.16041100025177
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R1242     -3.0999999046325684e+00
    phi[5,1]  R1243     -3.0999999046325684e+00
    phi[5,1]  R1244     -2.2400000095367432e+00
    phi[5,1]  R1245     -2.2400000095367432e+00
    phi[5,1]  R1246     -3.0999999046325684e+00
    phi[5,1]  R1247     -3.0999999046325684e+00
    phi[5,1]  R1248     -2.5699999332427979e+00
    phi[5,1]  R1249     -2.5699999332427979e+00
    phi[5,1]  R1250     -3.0999999046325684e+00
    phi[5,1]  R1251     -3.0999999046325684e+00
    phi[5,1]  R1252     -2.0899999141693115e+00
    phi[5,1]  R1253     -2.0899999141693115e+00
    phi[5,1]  R1254     -3.0999999046325684e+00
    phi[5,1]  R1255     -3.0999999046325684e+00
    phi[5,1]  R1256     7.4282556772232056e-01
    phi[5,1]  R1257     2.9529479146003723e-01
    phi[5,1]  R1258     1.1315840482711792e+00
    phi[5,1]  R1259     4.4400626420974731e-01
    phi[5,1]  R1260     -6.2369279563426971e-02
    phi[5,1]  R1261     8.0027955770492554e-01
    phi[5,1]  R1262     5.8231145143508911e-01
    phi[5,1]  R1263     0.707918107509613
    phi[5,1]  R1264     1.4931190013885498e+00
    phi[5,1]  R1265     -7.5401759147644043e-01
    phi[5,1]  R1266     -6.9086164236068726e-01
    phi[5,1]  R1267     -1.6924331188201904e+00
    phi[5,1]  R1268     -2.3630063533782959e+00
    phi[5,1]  R1269     -2.3373171687126160e-01
    phi[5,1]  R1270     8.4866231679916382e-01
    phi[5,1]  R1271     1.0191968083381653e-01
    phi[5,1]  R1272     -8.9570456743240356e-01
    phi[5,1]  R1273     -1.2557879090309143e-01
    phi[5,1]  R1274     -2.5273486971855164e-01
    phi[5,1]  R1275     -2.1915815770626068e-01
    phi[5,1]  R1276     -2.1859364509582520e+00
    phi[5,1]  R1277     1.7728338241577148e+00
    phi[5,1]  R1278     -1.6886414289474487e+00
    phi[5,1]  R1279     -1.3068474531173706e+00
    phi[5,1]  R1280     -3.3660628795623779e+00
    phi[5,1]  R1281     -2.1086461544036865e+00
    phi[5,1]  R1282     -1.8140971660614014e+00
    phi[5,1]  R1283     -2.83530855178833
    phi[5,1]  R1284     -2.9731068611145020e+00
    phi[5,1]  R1285     -2.5195360183715820e+00
    phi[5,1]  R1286     -6.9067078828811646e-01
    phi[5,1]  R1287     -2.1897029876708984e+00
    phi[5,1]  R1288     -4.0695637464523315e-01
    phi[5,1]  R1289     -2.0363402366638184e+00
    phi[5,1]  R1290     5.6539326906204224e-01
    phi[5,1]  R1291     5.2155834436416626e-01
    phi[5,1]  R1292     9.5216894149780273e-01
    phi[5,1]  R1293     -0.985035240650177
    phi[5,1]  R1294     3.3206190913915634e-02
    phi[5,1]  R1295     2.0095043182373047e+00
    phi[5,1]  R1296     -3.2473711967468262e+00
    phi[5,1]  R1297     1.0882055759429932e+00
    phi[5,1]  R1298     2.2832448482513428e+00
    phi[5,1]  R1299     7.0544868707656860e-01
    phi[5,1]  R1300     1.1342386007308960e+00
    phi[5,1]  R1301     -1.6827241182327271e+00
    phi[5,1]  R1302     -3.2920449972152710e-01
    phi[5,1]  R1303     5.2749556303024292e-01
    phi[5,1]  R1304     2.0337255001068115e+00
    phi[5,1]  R1305     1.16041100025177
    phi[5,1]  R1306     1.9664230346679688e+00
    phi[5,1]  R1307     2.0808558464050293e+00
    phi[5,1]  R1308     1.2804361581802368e+00
    phi[5,1]  R1309     1.4970929622650146e+00
    phi[5,1]  R1310     1.6670113801956177e+00
    phi[5,1]  R1311     6.8956357240676880e-01
    phi[5,1]  R1312     3.7077087163925171e-01
    phi[5,1]  R1313     -3.7168118357658386e-01
    phi[5,1]  R1314     -1.4298155903816223e-01
    phi[5,1]  R1315     -1.0029788017272949e+00
    phi[5,1]  R1316     -9.8529952764511108e-01
    phi[5,1]  R1317     -3.9680135250091553e-01
    phi[5,1]  R1318     -3.1370067596435547e-01
    phi[5,1]  R1319     -2.0499134063720703e+00
    phi[5,1]  R1320     8.1695950031280518e-01
    phi[5,1]  R1321     -4.3905954360961914e+00
    phi[5,1]  R1322     -3.3153734207153320e+00
    phi[5,1]  R1323     -1.8261700868606567e+00
    phi[5,1]  R1324     -2.3661906719207764e+00
    phi[5,1]  R1325     -1.7181274890899658e+00
    phi[5,1]  R1326     -1.6641924381256104e+00
    phi[5,1]  R1327     -1.5336719751358032e+00
    phi[5,1]  R1328     -9.6779960393905640e-01
    phi[5,1]  R1329     -1.1057369709014893e+00
    phi[5,1]  R1330     8.4525831043720245e-02
    phi[5,1]  R1331     -1.3610336780548096e+00
    phi[5,1]  R1332     -2.2789260745048523e-01
    phi[5,1]  R1333     -1.4055078029632568e+00
    phi[5,1]  R1334     -0.930335283279419
    phi[5,1]  R1335     -1.0332182645797729e+00
    phi[5,1]  R1336     1.5764783322811127e-01
    phi[5,1]  R1337     6.6788923740386963e-01
    phi[5,1]  R1338     8.8056391477584839e-01
    phi[5,1]  R1339     0.979372501373291
    phi[5,1]  R1340     -9.0368163585662842e-01
    phi[5,1]  R1341     4.6497848629951477e-01
    phi[5,1]  R1342     -3.8870871067047119e+00
    phi[5,1]  R1343     -1.8786684274673462e+00
    phi[5,1]  R1344     -1.7773544788360596e+00
    phi[5,1]  R1345     -1.2514928579330444e+00
    phi[5,1]  R1346     -1.2448586225509644e+00
    phi[5,1]  R1347     -4.0075969696044922e+00
    phi[5,1]  R1348     1.2261536121368408e+00
    phi[5,1]  R1349     -9.5557585358619690e-02
    phi[5,1]  R1350     -1.6775109767913818e+00
    phi[5,1]  R1351     -1.2371207475662231e+00
    phi[5,1]  R1352     -6.4163094758987427e-01
    phi[5,1]  R1353     -2.1518533229827881e+00
    phi[5,1]  R1354     -2.9930369928479195e-02
    phi[1,6]  R9        1
    phi[1,6]  R10       1
    phi[1,6]  R54       -1
    phi[1,6]  R1355     -3.0999999046325684e+00
    phi[1,6]  R1356     -3.0999999046325684e+00
    phi[1,6]  R1357     -2.2400000095367432e+00
    phi[1,6]  R1358     -2.2400000095367432e+00
    phi[1,6]  R1359     -3.0999999046325684e+00
    phi[1,6]  R1360     -3.0999999046325684e+00
    phi[1,6]  R1361     -2.5699999332427979e+00
    phi[1,6]  R1362     -2.5699999332427979e+00
    phi[1,6]  R1363     -3.0999999046325684e+00
    phi[1,6]  R1364     -3.0999999046325684e+00
    phi[1,6]  R1365     -2.0899999141693115e+00
    phi[1,6]  R1366     -2.0899999141693115e+00
    phi[1,6]  R1367     -3.0999999046325684e+00
    phi[1,6]  R1368     -3.0999999046325684e+00
    phi[1,6]  R1369     1.9664230346679688e+00
    phi[1,6]  R1370     2.0808558464050293e+00
    phi[1,6]  R1371     1.2804361581802368e+00
    phi[1,6]  R1372     1.4970929622650146e+00
    phi[1,6]  R1373     1.6670113801956177e+00
    phi[1,6]  R1374     6.8956357240676880e-01
    phi[1,6]  R1375     3.7077087163925171e-01
    phi[1,6]  R1376     -3.7168118357658386e-01
    phi[1,6]  R1377     -1.4298155903816223e-01
    phi[1,6]  R1378     -1.0029788017272949e+00
    phi[1,6]  R1379     -9.8529952764511108e-01
    phi[1,6]  R1380     -3.9680135250091553e-01
    phi[1,6]  R1381     -3.1370067596435547e-01
    phi[1,6]  R1382     -2.0499134063720703e+00
    phi[1,6]  R1383     8.1695950031280518e-01
    phi[1,6]  R1384     -4.3905954360961914e+00
    phi[1,6]  R1385     -3.3153734207153320e+00
    phi[1,6]  R1386     -1.8261700868606567e+00
    phi[1,6]  R1387     -2.3661906719207764e+00
    phi[1,6]  R1388     -1.7181274890899658e+00
    phi[1,6]  R1389     -1.6641924381256104e+00
    phi[1,6]  R1390     -1.5336719751358032e+00
    phi[1,6]  R1391     -9.6779960393905640e-01
    phi[1,6]  R1392     -1.1057369709014893e+00
    phi[1,6]  R1393     8.4525831043720245e-02
    phi[1,6]  R1394     -1.3610336780548096e+00
    phi[1,6]  R1395     -2.2789260745048523e-01
    phi[1,6]  R1396     -1.4055078029632568e+00
    phi[1,6]  R1397     -0.930335283279419
    phi[1,6]  R1398     -1.0332182645797729e+00
    phi[1,6]  R1399     1.5764783322811127e-01
    phi[1,6]  R1400     6.6788923740386963e-01
    phi[1,6]  R1401     8.8056391477584839e-01
    phi[1,6]  R1402     0.979372501373291
    phi[1,6]  R1403     -9.0368163585662842e-01
    phi[1,6]  R1404     4.6497848629951477e-01
    phi[1,6]  R1405     -3.8870871067047119e+00
    phi[1,6]  R1406     -1.8786684274673462e+00
    phi[1,6]  R1407     -1.7773544788360596e+00
    phi[1,6]  R1408     -1.2514928579330444e+00
    phi[1,6]  R1409     -1.2448586225509644e+00
    phi[1,6]  R1410     -4.0075969696044922e+00
    phi[1,6]  R1411     1.2261536121368408e+00
    phi[1,6]  R1412     -9.5557585358619690e-02
    phi[1,6]  R1413     -1.6775109767913818e+00
    phi[1,6]  R1414     -1.2371207475662231e+00
    phi[1,6]  R1415     -6.4163094758987427e-01
    phi[1,6]  R1416     -2.1518533229827881e+00
    phi[1,6]  R1417     -2.9930369928479195e-02
    phi[1,6]  R1418     2.6976850032806396e+00
    phi[1,6]  R1419     0.0649002343416214
    phi[1,6]  R1420     1.4660350084304810e+00
    phi[1,6]  R1421     1.6225330829620361e+00
    phi[1,6]  R1422     -1.4243797063827515e+00
    phi[1,6]  R1423     1.1959240436553955e+00
    phi[1,6]  R1424     2.5323469638824463e+00
    phi[1,6]  R1425     -7.2055578231811523e-01
    phi[1,6]  R1426     7.6183575391769409e-01
    phi[1,6]  R1427     1.4031524658203125e+00
    phi[1,6]  R1428     -6.8570256233215332e-01
    phi[1,6]  R1429     1.1997667551040649e+00
    phi[1,6]  R1430     -1.7051937580108643e+00
    phi[1,6]  R1431     -5.6683665513992310e-01
    phi[1,6]  R1432     -1.1315454244613647e+00
    phi[1,6]  R1433     -6.9839775562286377e-01
    phi[1,6]  R1434     1.9077036380767822e+00
    phi[1,6]  R1435     -7.7044510841369629e-01
    phi[1,6]  R1436     -1.7779903113842010e-01
    phi[1,6]  R1437     5.8586782217025757e-01
    phi[1,6]  R1438     -1.1418428421020508e+00
    phi[1,6]  R1439     -1.5784937143325806e+00
    phi[1,6]  R1440     -1.2711124420166016e+00
    phi[1,6]  R1441     -1.5991345643997192e+00
    phi[1,6]  R1442     -3.2730693817138672e+00
    phi[1,6]  R1443     -4.6830692887306213e-01
    phi[1,6]  R1444     9.8743689060211182e-01
    phi[1,6]  R1445     -8.4336519241333008e-01
    phi[1,6]  R1446     2.4134533405303955e+00
    phi[1,6]  R1447     -7.4234205484390259e-01
    phi[1,6]  R1448     3.3050251007080078e-01
    phi[1,6]  R1449     1.1298936605453491e+00
    phi[1,6]  R1450     1.7137253284454346e+00
    phi[1,6]  R1451     -4.0233942866325378e-01
    phi[1,6]  R1452     0.582848072052002
    phi[1,6]  R1453     -1.7573174238204956e+00
    phi[1,6]  R1454     -3.8639216423034668e+00
    phi[1,6]  R1455     -1.0604963302612305e+00
    phi[1,6]  R1456     -9.3738555908203125e-01
    phi[1,6]  R1457     1.2641808390617371e-01
    phi[1,6]  R1458     1.5678017139434814e+00
    phi[1,6]  R1459     1.1833475828170776e+00
    phi[1,6]  R1460     -3.2950100898742676e+00
    phi[1,6]  R1461     -2.5938773155212402e+00
    phi[1,6]  R1462     -2.8689846992492676e+00
    phi[1,6]  R1463     -3.3586139678955078e+00
    phi[1,6]  R1464     -3.4290775656700134e-01
    phi[1,6]  R1465     7.6658993959426880e-02
    phi[1,6]  R1466     1.6971069574356079e+00
    phi[1,6]  R1467     1.1999979019165039e+00
    phi[1,6]  R1468     -3.2554969787597656e+00
    phi[1,6]  R1469     -2.0682649612426758e+00
    phi[1,6]  R1470     -1.8494064807891846e+00
    phi[1,6]  R1471     -3.7303090095520020e+00
    phi[1,6]  R1472     4.8862797021865845e-01
    phi[1,6]  R1473     -1.1611957550048828e+00
    phi[1,6]  R1474     1.8736764192581177e+00
    phi[1,6]  R1475     2.6591706275939941e+00
    phi[6,1]  R9        -1
    phi[6,1]  R54       1
    phi[6,1]  R55       1
    phi[6,1]  R1476     -3.0999999046325684e+00
    phi[6,1]  R1477     -3.0999999046325684e+00
    phi[6,1]  R1478     -2.2400000095367432e+00
    phi[6,1]  R1479     -2.2400000095367432e+00
    phi[6,1]  R1480     -3.0999999046325684e+00
    phi[6,1]  R1481     -3.0999999046325684e+00
    phi[6,1]  R1482     -2.5699999332427979e+00
    phi[6,1]  R1483     -2.5699999332427979e+00
    phi[6,1]  R1484     -3.0999999046325684e+00
    phi[6,1]  R1485     -3.0999999046325684e+00
    phi[6,1]  R1486     -2.0899999141693115e+00
    phi[6,1]  R1487     -2.0899999141693115e+00
    phi[6,1]  R1488     -3.0999999046325684e+00
    phi[6,1]  R1489     -3.0999999046325684e+00
    phi[6,1]  R1490     2.6976850032806396e+00
    phi[6,1]  R1491     0.0649002343416214
    phi[6,1]  R1492     1.4660350084304810e+00
    phi[6,1]  R1493     1.6225330829620361e+00
    phi[6,1]  R1494     -1.4243797063827515e+00
    phi[6,1]  R1495     1.1959240436553955e+00
    phi[6,1]  R1496     2.5323469638824463e+00
    phi[6,1]  R1497     -7.2055578231811523e-01
    phi[6,1]  R1498     7.6183575391769409e-01
    phi[6,1]  R1499     1.4031524658203125e+00
    phi[6,1]  R1500     -6.8570256233215332e-01
    phi[6,1]  R1501     1.1997667551040649e+00
    phi[6,1]  R1502     -1.7051937580108643e+00
    phi[6,1]  R1503     -5.6683665513992310e-01
    phi[6,1]  R1504     -1.1315454244613647e+00
    phi[6,1]  R1505     -6.9839775562286377e-01
    phi[6,1]  R1506     1.9077036380767822e+00
    phi[6,1]  R1507     -7.7044510841369629e-01
    phi[6,1]  R1508     -1.7779903113842010e-01
    phi[6,1]  R1509     5.8586782217025757e-01
    phi[6,1]  R1510     -1.1418428421020508e+00
    phi[6,1]  R1511     -1.5784937143325806e+00
    phi[6,1]  R1512     -1.2711124420166016e+00
    phi[6,1]  R1513     -1.5991345643997192e+00
    phi[6,1]  R1514     -3.2730693817138672e+00
    phi[6,1]  R1515     -4.6830692887306213e-01
    phi[6,1]  R1516     9.8743689060211182e-01
    phi[6,1]  R1517     -8.4336519241333008e-01
    phi[6,1]  R1518     2.4134533405303955e+00
    phi[6,1]  R1519     -7.4234205484390259e-01
    phi[6,1]  R1520     3.3050251007080078e-01
    phi[6,1]  R1521     1.1298936605453491e+00
    phi[6,1]  R1522     1.7137253284454346e+00
    phi[6,1]  R1523     -4.0233942866325378e-01
    phi[6,1]  R1524     0.582848072052002
    phi[6,1]  R1525     -1.7573174238204956e+00
    phi[6,1]  R1526     -3.8639216423034668e+00
    phi[6,1]  R1527     -1.0604963302612305e+00
    phi[6,1]  R1528     -9.3738555908203125e-01
    phi[6,1]  R1529     1.2641808390617371e-01
    phi[6,1]  R1530     1.5678017139434814e+00
    phi[6,1]  R1531     1.1833475828170776e+00
    phi[6,1]  R1532     -3.2950100898742676e+00
    phi[6,1]  R1533     -2.5938773155212402e+00
    phi[6,1]  R1534     -2.8689846992492676e+00
    phi[6,1]  R1535     -3.3586139678955078e+00
    phi[6,1]  R1536     -3.4290775656700134e-01
    phi[6,1]  R1537     7.6658993959426880e-02
    phi[6,1]  R1538     1.6971069574356079e+00
    phi[6,1]  R1539     1.1999979019165039e+00
    phi[6,1]  R1540     -3.2554969787597656e+00
    phi[6,1]  R1541     -2.0682649612426758e+00
    phi[6,1]  R1542     -1.8494064807891846e+00
    phi[6,1]  R1543     -3.7303090095520020e+00
    phi[6,1]  R1544     4.8862797021865845e-01
    phi[6,1]  R1545     -1.1611957550048828e+00
    phi[6,1]  R1546     1.8736764192581177e+00
    phi[6,1]  R1547     2.6591706275939941e+00
    phi[6,1]  R1548     1.9664230346679688e+00
    phi[6,1]  R1549     2.0808558464050293e+00
    phi[6,1]  R1550     1.2804361581802368e+00
    phi[6,1]  R1551     1.4970929622650146e+00
    phi[6,1]  R1552     1.6670113801956177e+00
    phi[6,1]  R1553     6.8956357240676880e-01
    phi[6,1]  R1554     3.7077087163925171e-01
    phi[6,1]  R1555     -3.7168118357658386e-01
    phi[6,1]  R1556     -1.4298155903816223e-01
    phi[6,1]  R1557     -1.0029788017272949e+00
    phi[6,1]  R1558     -9.8529952764511108e-01
    phi[6,1]  R1559     -3.9680135250091553e-01
    phi[6,1]  R1560     -3.1370067596435547e-01
    phi[6,1]  R1561     -2.0499134063720703e+00
    phi[6,1]  R1562     8.1695950031280518e-01
    phi[6,1]  R1563     -4.3905954360961914e+00
    phi[6,1]  R1564     -3.3153734207153320e+00
    phi[6,1]  R1565     -1.8261700868606567e+00
    phi[6,1]  R1566     -2.3661906719207764e+00
    phi[6,1]  R1567     -1.7181274890899658e+00
    phi[6,1]  R1568     -1.6641924381256104e+00
    phi[6,1]  R1569     -1.5336719751358032e+00
    phi[6,1]  R1570     -9.6779960393905640e-01
    phi[6,1]  R1571     -1.1057369709014893e+00
    phi[6,1]  R1572     8.4525831043720245e-02
    phi[6,1]  R1573     -1.3610336780548096e+00
    phi[6,1]  R1574     -2.2789260745048523e-01
    phi[6,1]  R1575     -1.4055078029632568e+00
    phi[6,1]  R1576     -0.930335283279419
    phi[6,1]  R1577     -1.0332182645797729e+00
    phi[6,1]  R1578     1.5764783322811127e-01
    phi[6,1]  R1579     6.6788923740386963e-01
    phi[6,1]  R1580     8.8056391477584839e-01
    phi[6,1]  R1581     0.979372501373291
    phi[6,1]  R1582     -9.0368163585662842e-01
    phi[6,1]  R1583     4.6497848629951477e-01
    phi[6,1]  R1584     -3.8870871067047119e+00
    phi[6,1]  R1585     -1.8786684274673462e+00
    phi[6,1]  R1586     -1.7773544788360596e+00
    phi[6,1]  R1587     -1.2514928579330444e+00
    phi[6,1]  R1588     -1.2448586225509644e+00
    phi[6,1]  R1589     -4.0075969696044922e+00
    phi[6,1]  R1590     1.2261536121368408e+00
    phi[6,1]  R1591     -9.5557585358619690e-02
    phi[6,1]  R1592     -1.6775109767913818e+00
    phi[6,1]  R1593     -1.2371207475662231e+00
    phi[6,1]  R1594     -6.4163094758987427e-01
    phi[6,1]  R1595     -2.1518533229827881e+00
    phi[6,1]  R1596     -2.9930369928479195e-02
    phi[2,5]  R18       1
    phi[2,5]  R19       1
    phi[2,5]  R45       -1
    phi[2,5]  R1597     -3.0999999046325684e+00
    phi[2,5]  R1598     -3.0999999046325684e+00
    phi[2,5]  R1599     -2.2400000095367432e+00
    phi[2,5]  R1600     -2.2400000095367432e+00
    phi[2,5]  R1601     -3.0999999046325684e+00
    phi[2,5]  R1602     -3.0999999046325684e+00
    phi[2,5]  R1603     -2.5699999332427979e+00
    phi[2,5]  R1604     -2.5699999332427979e+00
    phi[2,5]  R1605     -3.0999999046325684e+00
    phi[2,5]  R1606     -3.0999999046325684e+00
    phi[2,5]  R1607     -2.0899999141693115e+00
    phi[2,5]  R1608     -2.0899999141693115e+00
    phi[2,5]  R1609     -3.0999999046325684e+00
    phi[2,5]  R1610     -3.0999999046325684e+00
    phi[2,5]  R1611     3.4267935752868652e+00
    phi[2,5]  R1612     3.1847443580627441e+00
    phi[2,5]  R1613     1.3899818658828735e+00
    phi[2,5]  R1614     2.7984743118286133e+00
    phi[2,5]  R1615     1.6508650779724121e+00
    phi[2,5]  R1616     1.3627080917358398e+00
    phi[2,5]  R1617     2.7761211395263672e+00
    phi[2,5]  R1618     1.6322623491287231e+00
    phi[2,5]  R1619     1.3762626647949219e+00
    phi[2,5]  R1620     6.3023847341537476e-01
    phi[2,5]  R1621     -3.2493534088134766e+00
    phi[2,5]  R1622     -3.3668019771575928e+00
    phi[2,5]  R1623     -3.5817096233367920e+00
    phi[2,5]  R1624     -2.8174347877502441e+00
    phi[2,5]  R1625     -8.1501394510269165e-01
    phi[2,5]  R1626     -2.9840941429138184e+00
    phi[2,5]  R1627     -8.5487204790115356e-01
    phi[2,5]  R1628     -2.4057426452636719e+00
    phi[2,5]  R1629     -1.2419953346252441e+00
    phi[2,5]  R1630     -1.4479204416275024e+00
    phi[2,5]  R1631     -1.8027145862579346e+00
    phi[2,5]  R1632     -7.8940087556838989e-01
    phi[2,5]  R1633     -1.6639393568038940e+00
    phi[2,5]  R1634     -5.3820240497589111e-01
    phi[2,5]  R1635     3.4851136803627014e-01
    phi[2,5]  R1636     -7.4307215213775635e-01
    phi[2,5]  R1637     -3.8825172185897827e-01
    phi[2,5]  R1638     6.8314611911773682e-02
    phi[2,5]  R1639     1.2263700366020203e-01
    phi[2,5]  R1640     -1.2162035703659058e+00
    phi[2,5]  R1641     -1.0650695562362671e+00
    phi[2,5]  R1642     -5.2027985453605652e-02
    phi[2,5]  R1643     2.7847609519958496e+00
    phi[2,5]  R1644     2.9651448130607605e-01
    phi[2,5]  R1645     -9.4075784087181091e-02
    phi[2,5]  R1646     4.3631577491760254e-01
    phi[2,5]  R1647     1.3488855361938477e+00
    phi[2,5]  R1648     3.1169718503952026e-01
    phi[2,5]  R1649     -3.2607132196426392e-01
    phi[2,5]  R1650     4.4164359569549561e-03
    phi[2,5]  R1651     7.4282556772232056e-01
    phi[2,5]  R1652     2.9529479146003723e-01
    phi[2,5]  R1653     1.1315840482711792e+00
    phi[2,5]  R1654     4.4400626420974731e-01
    phi[2,5]  R1655     -6.2369279563426971e-02
    phi[2,5]  R1656     8.0027955770492554e-01
    phi[2,5]  R1657     5.8231145143508911e-01
    phi[2,5]  R1658     0.707918107509613
    phi[2,5]  R1659     1.4931190013885498e+00
    phi[2,5]  R1660     -7.5401759147644043e-01
    phi[2,5]  R1661     -6.9086164236068726e-01
    phi[2,5]  R1662     -1.6924331188201904e+00
    phi[2,5]  R1663     -2.3630063533782959e+00
    phi[2,5]  R1664     -2.3373171687126160e-01
    phi[2,5]  R1665     8.4866231679916382e-01
    phi[2,5]  R1666     1.0191968083381653e-01
    phi[2,5]  R1667     -8.9570456743240356e-01
    phi[2,5]  R1668     -1.2557879090309143e-01
    phi[2,5]  R1669     -2.5273486971855164e-01
    phi[2,5]  R1670     -2.1915815770626068e-01
    phi[2,5]  R1671     -2.1859364509582520e+00
    phi[2,5]  R1672     1.7728338241577148e+00
    phi[2,5]  R1673     -1.6886414289474487e+00
    phi[2,5]  R1674     -1.3068474531173706e+00
    phi[2,5]  R1675     -3.3660628795623779e+00
    phi[2,5]  R1676     -2.1086461544036865e+00
    phi[2,5]  R1677     -1.8140971660614014e+00
    phi[2,5]  R1678     -2.83530855178833
    phi[2,5]  R1679     -2.9731068611145020e+00
    phi[2,5]  R1680     -2.5195360183715820e+00
    phi[2,5]  R1681     -6.9067078828811646e-01
    phi[2,5]  R1682     -2.1897029876708984e+00
    phi[2,5]  R1683     -4.0695637464523315e-01
    phi[2,5]  R1684     -2.0363402366638184e+00
    phi[2,5]  R1685     5.6539326906204224e-01
    phi[2,5]  R1686     5.2155834436416626e-01
    phi[2,5]  R1687     9.5216894149780273e-01
    phi[2,5]  R1688     -0.985035240650177
    phi[2,5]  R1689     3.3206190913915634e-02
    phi[2,5]  R1690     2.0095043182373047e+00
    phi[2,5]  R1691     -3.2473711967468262e+00
    phi[2,5]  R1692     1.0882055759429932e+00
    phi[2,5]  R1693     2.2832448482513428e+00
    phi[2,5]  R1694     7.0544868707656860e-01
    phi[2,5]  R1695     1.1342386007308960e+00
    phi[2,5]  R1696     -1.6827241182327271e+00
    phi[2,5]  R1697     -3.2920449972152710e-01
    phi[2,5]  R1698     5.2749556303024292e-01
    phi[2,5]  R1699     2.0337255001068115e+00
    phi[2,5]  R1700     1.16041100025177
    phi[5,2]  R18       -1
    phi[5,2]  R45       1
    phi[5,2]  R46       1
    phi[5,2]  R1701     -3.0999999046325684e+00
    phi[5,2]  R1702     -3.0999999046325684e+00
    phi[5,2]  R1703     -2.2400000095367432e+00
    phi[5,2]  R1704     -2.2400000095367432e+00
    phi[5,2]  R1705     -3.0999999046325684e+00
    phi[5,2]  R1706     -3.0999999046325684e+00
    phi[5,2]  R1707     -2.5699999332427979e+00
    phi[5,2]  R1708     -2.5699999332427979e+00
    phi[5,2]  R1709     -3.0999999046325684e+00
    phi[5,2]  R1710     -3.0999999046325684e+00
    phi[5,2]  R1711     -2.0899999141693115e+00
    phi[5,2]  R1712     -2.0899999141693115e+00
    phi[5,2]  R1713     -3.0999999046325684e+00
    phi[5,2]  R1714     -3.0999999046325684e+00
    phi[5,2]  R1715     7.4282556772232056e-01
    phi[5,2]  R1716     2.9529479146003723e-01
    phi[5,2]  R1717     1.1315840482711792e+00
    phi[5,2]  R1718     4.4400626420974731e-01
    phi[5,2]  R1719     -6.2369279563426971e-02
    phi[5,2]  R1720     8.0027955770492554e-01
    phi[5,2]  R1721     5.8231145143508911e-01
    phi[5,2]  R1722     0.707918107509613
    phi[5,2]  R1723     1.4931190013885498e+00
    phi[5,2]  R1724     -7.5401759147644043e-01
    phi[5,2]  R1725     -6.9086164236068726e-01
    phi[5,2]  R1726     -1.6924331188201904e+00
    phi[5,2]  R1727     -2.3630063533782959e+00
    phi[5,2]  R1728     -2.3373171687126160e-01
    phi[5,2]  R1729     8.4866231679916382e-01
    phi[5,2]  R1730     1.0191968083381653e-01
    phi[5,2]  R1731     -8.9570456743240356e-01
    phi[5,2]  R1732     -1.2557879090309143e-01
    phi[5,2]  R1733     -2.5273486971855164e-01
    phi[5,2]  R1734     -2.1915815770626068e-01
    phi[5,2]  R1735     -2.1859364509582520e+00
    phi[5,2]  R1736     1.7728338241577148e+00
    phi[5,2]  R1737     -1.6886414289474487e+00
    phi[5,2]  R1738     -1.3068474531173706e+00
    phi[5,2]  R1739     -3.3660628795623779e+00
    phi[5,2]  R1740     -2.1086461544036865e+00
    phi[5,2]  R1741     -1.8140971660614014e+00
    phi[5,2]  R1742     -2.83530855178833
    phi[5,2]  R1743     -2.9731068611145020e+00
    phi[5,2]  R1744     -2.5195360183715820e+00
    phi[5,2]  R1745     -6.9067078828811646e-01
    phi[5,2]  R1746     -2.1897029876708984e+00
    phi[5,2]  R1747     -4.0695637464523315e-01
    phi[5,2]  R1748     -2.0363402366638184e+00
    phi[5,2]  R1749     5.6539326906204224e-01
    phi[5,2]  R1750     5.2155834436416626e-01
    phi[5,2]  R1751     9.5216894149780273e-01
    phi[5,2]  R1752     -0.985035240650177
    phi[5,2]  R1753     3.3206190913915634e-02
    phi[5,2]  R1754     2.0095043182373047e+00
    phi[5,2]  R1755     -3.2473711967468262e+00
    phi[5,2]  R1756     1.0882055759429932e+00
    phi[5,2]  R1757     2.2832448482513428e+00
    phi[5,2]  R1758     7.0544868707656860e-01
    phi[5,2]  R1759     1.1342386007308960e+00
    phi[5,2]  R1760     -1.6827241182327271e+00
    phi[5,2]  R1761     -3.2920449972152710e-01
    phi[5,2]  R1762     5.2749556303024292e-01
    phi[5,2]  R1763     2.0337255001068115e+00
    phi[5,2]  R1764     1.16041100025177
    phi[5,2]  R1765     3.4267935752868652e+00
    phi[5,2]  R1766     3.1847443580627441e+00
    phi[5,2]  R1767     1.3899818658828735e+00
    phi[5,2]  R1768     2.7984743118286133e+00
    phi[5,2]  R1769     1.6508650779724121e+00
    phi[5,2]  R1770     1.3627080917358398e+00
    phi[5,2]  R1771     2.7761211395263672e+00
    phi[5,2]  R1772     1.6322623491287231e+00
    phi[5,2]  R1773     1.3762626647949219e+00
    phi[5,2]  R1774     6.3023847341537476e-01
    phi[5,2]  R1775     -3.2493534088134766e+00
    phi[5,2]  R1776     -3.3668019771575928e+00
    phi[5,2]  R1777     -3.5817096233367920e+00
    phi[5,2]  R1778     -2.8174347877502441e+00
    phi[5,2]  R1779     -8.1501394510269165e-01
    phi[5,2]  R1780     -2.9840941429138184e+00
    phi[5,2]  R1781     -8.5487204790115356e-01
    phi[5,2]  R1782     -2.4057426452636719e+00
    phi[5,2]  R1783     -1.2419953346252441e+00
    phi[5,2]  R1784     -1.4479204416275024e+00
    phi[5,2]  R1785     -1.8027145862579346e+00
    phi[5,2]  R1786     -7.8940087556838989e-01
    phi[5,2]  R1787     -1.6639393568038940e+00
    phi[5,2]  R1788     -5.3820240497589111e-01
    phi[5,2]  R1789     3.4851136803627014e-01
    phi[5,2]  R1790     -7.4307215213775635e-01
    phi[5,2]  R1791     -3.8825172185897827e-01
    phi[5,2]  R1792     6.8314611911773682e-02
    phi[5,2]  R1793     1.2263700366020203e-01
    phi[5,2]  R1794     -1.2162035703659058e+00
    phi[5,2]  R1795     -1.0650695562362671e+00
    phi[5,2]  R1796     -5.2027985453605652e-02
    phi[5,2]  R1797     2.7847609519958496e+00
    phi[5,2]  R1798     2.9651448130607605e-01
    phi[5,2]  R1799     -9.4075784087181091e-02
    phi[5,2]  R1800     4.3631577491760254e-01
    phi[5,2]  R1801     1.3488855361938477e+00
    phi[5,2]  R1802     3.1169718503952026e-01
    phi[5,2]  R1803     -3.2607132196426392e-01
    phi[5,2]  R1804     4.4164359569549561e-03
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1805     -3.0999999046325684e+00
    phi[2,6]  R1806     -3.0999999046325684e+00
    phi[2,6]  R1807     -2.2400000095367432e+00
    phi[2,6]  R1808     -2.2400000095367432e+00
    phi[2,6]  R1809     -3.0999999046325684e+00
    phi[2,6]  R1810     -3.0999999046325684e+00
    phi[2,6]  R1811     -2.5699999332427979e+00
    phi[2,6]  R1812     -2.5699999332427979e+00
    phi[2,6]  R1813     -3.0999999046325684e+00
    phi[2,6]  R1814     -3.0999999046325684e+00
    phi[2,6]  R1815     -2.0899999141693115e+00
    phi[2,6]  R1816     -2.0899999141693115e+00
    phi[2,6]  R1817     -3.0999999046325684e+00
    phi[2,6]  R1818     -3.0999999046325684e+00
    phi[2,6]  R1819     3.4267935752868652e+00
    phi[2,6]  R1820     3.1847443580627441e+00
    phi[2,6]  R1821     1.3899818658828735e+00
    phi[2,6]  R1822     2.7984743118286133e+00
    phi[2,6]  R1823     1.6508650779724121e+00
    phi[2,6]  R1824     1.3627080917358398e+00
    phi[2,6]  R1825     2.7761211395263672e+00
    phi[2,6]  R1826     1.6322623491287231e+00
    phi[2,6]  R1827     1.3762626647949219e+00
    phi[2,6]  R1828     6.3023847341537476e-01
    phi[2,6]  R1829     -3.2493534088134766e+00
    phi[2,6]  R1830     -3.3668019771575928e+00
    phi[2,6]  R1831     -3.5817096233367920e+00
    phi[2,6]  R1832     -2.8174347877502441e+00
    phi[2,6]  R1833     -8.1501394510269165e-01
    phi[2,6]  R1834     -2.9840941429138184e+00
    phi[2,6]  R1835     -8.5487204790115356e-01
    phi[2,6]  R1836     -2.4057426452636719e+00
    phi[2,6]  R1837     -1.2419953346252441e+00
    phi[2,6]  R1838     -1.4479204416275024e+00
    phi[2,6]  R1839     -1.8027145862579346e+00
    phi[2,6]  R1840     -7.8940087556838989e-01
    phi[2,6]  R1841     -1.6639393568038940e+00
    phi[2,6]  R1842     -5.3820240497589111e-01
    phi[2,6]  R1843     3.4851136803627014e-01
    phi[2,6]  R1844     -7.4307215213775635e-01
    phi[2,6]  R1845     -3.8825172185897827e-01
    phi[2,6]  R1846     6.8314611911773682e-02
    phi[2,6]  R1847     1.2263700366020203e-01
    phi[2,6]  R1848     -1.2162035703659058e+00
    phi[2,6]  R1849     -1.0650695562362671e+00
    phi[2,6]  R1850     -5.2027985453605652e-02
    phi[2,6]  R1851     2.7847609519958496e+00
    phi[2,6]  R1852     2.9651448130607605e-01
    phi[2,6]  R1853     -9.4075784087181091e-02
    phi[2,6]  R1854     4.3631577491760254e-01
    phi[2,6]  R1855     1.3488855361938477e+00
    phi[2,6]  R1856     3.1169718503952026e-01
    phi[2,6]  R1857     -3.2607132196426392e-01
    phi[2,6]  R1858     4.4164359569549561e-03
    phi[2,6]  R1859     2.6976850032806396e+00
    phi[2,6]  R1860     0.0649002343416214
    phi[2,6]  R1861     1.4660350084304810e+00
    phi[2,6]  R1862     1.6225330829620361e+00
    phi[2,6]  R1863     -1.4243797063827515e+00
    phi[2,6]  R1864     1.1959240436553955e+00
    phi[2,6]  R1865     2.5323469638824463e+00
    phi[2,6]  R1866     -7.2055578231811523e-01
    phi[2,6]  R1867     7.6183575391769409e-01
    phi[2,6]  R1868     1.4031524658203125e+00
    phi[2,6]  R1869     -6.8570256233215332e-01
    phi[2,6]  R1870     1.1997667551040649e+00
    phi[2,6]  R1871     -1.7051937580108643e+00
    phi[2,6]  R1872     -5.6683665513992310e-01
    phi[2,6]  R1873     -1.1315454244613647e+00
    phi[2,6]  R1874     -6.9839775562286377e-01
    phi[2,6]  R1875     1.9077036380767822e+00
    phi[2,6]  R1876     -7.7044510841369629e-01
    phi[2,6]  R1877     -1.7779903113842010e-01
    phi[2,6]  R1878     5.8586782217025757e-01
    phi[2,6]  R1879     -1.1418428421020508e+00
    phi[2,6]  R1880     -1.5784937143325806e+00
    phi[2,6]  R1881     -1.2711124420166016e+00
    phi[2,6]  R1882     -1.5991345643997192e+00
    phi[2,6]  R1883     -3.2730693817138672e+00
    phi[2,6]  R1884     -4.6830692887306213e-01
    phi[2,6]  R1885     9.8743689060211182e-01
    phi[2,6]  R1886     -8.4336519241333008e-01
    phi[2,6]  R1887     2.4134533405303955e+00
    phi[2,6]  R1888     -7.4234205484390259e-01
    phi[2,6]  R1889     3.3050251007080078e-01
    phi[2,6]  R1890     1.1298936605453491e+00
    phi[2,6]  R1891     1.7137253284454346e+00
    phi[2,6]  R1892     -4.0233942866325378e-01
    phi[2,6]  R1893     0.582848072052002
    phi[2,6]  R1894     -1.7573174238204956e+00
    phi[2,6]  R1895     -3.8639216423034668e+00
    phi[2,6]  R1896     -1.0604963302612305e+00
    phi[2,6]  R1897     -9.3738555908203125e-01
    phi[2,6]  R1898     1.2641808390617371e-01
    phi[2,6]  R1899     1.5678017139434814e+00
    phi[2,6]  R1900     1.1833475828170776e+00
    phi[2,6]  R1901     -3.2950100898742676e+00
    phi[2,6]  R1902     -2.5938773155212402e+00
    phi[2,6]  R1903     -2.8689846992492676e+00
    phi[2,6]  R1904     -3.3586139678955078e+00
    phi[2,6]  R1905     -3.4290775656700134e-01
    phi[2,6]  R1906     7.6658993959426880e-02
    phi[2,6]  R1907     1.6971069574356079e+00
    phi[2,6]  R1908     1.1999979019165039e+00
    phi[2,6]  R1909     -3.2554969787597656e+00
    phi[2,6]  R1910     -2.0682649612426758e+00
    phi[2,6]  R1911     -1.8494064807891846e+00
    phi[2,6]  R1912     -3.7303090095520020e+00
    phi[2,6]  R1913     4.8862797021865845e-01
    phi[2,6]  R1914     -1.1611957550048828e+00
    phi[2,6]  R1915     1.8736764192581177e+00
    phi[2,6]  R1916     2.6591706275939941e+00
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1917     -3.0999999046325684e+00
    phi[6,2]  R1918     -3.0999999046325684e+00
    phi[6,2]  R1919     -2.2400000095367432e+00
    phi[6,2]  R1920     -2.2400000095367432e+00
    phi[6,2]  R1921     -3.0999999046325684e+00
    phi[6,2]  R1922     -3.0999999046325684e+00
    phi[6,2]  R1923     -2.5699999332427979e+00
    phi[6,2]  R1924     -2.5699999332427979e+00
    phi[6,2]  R1925     -3.0999999046325684e+00
    phi[6,2]  R1926     -3.0999999046325684e+00
    phi[6,2]  R1927     -2.0899999141693115e+00
    phi[6,2]  R1928     -2.0899999141693115e+00
    phi[6,2]  R1929     -3.0999999046325684e+00
    phi[6,2]  R1930     -3.0999999046325684e+00
    phi[6,2]  R1931     2.6976850032806396e+00
    phi[6,2]  R1932     0.0649002343416214
    phi[6,2]  R1933     1.4660350084304810e+00
    phi[6,2]  R1934     1.6225330829620361e+00
    phi[6,2]  R1935     -1.4243797063827515e+00
    phi[6,2]  R1936     1.1959240436553955e+00
    phi[6,2]  R1937     2.5323469638824463e+00
    phi[6,2]  R1938     -7.2055578231811523e-01
    phi[6,2]  R1939     7.6183575391769409e-01
    phi[6,2]  R1940     1.4031524658203125e+00
    phi[6,2]  R1941     -6.8570256233215332e-01
    phi[6,2]  R1942     1.1997667551040649e+00
    phi[6,2]  R1943     -1.7051937580108643e+00
    phi[6,2]  R1944     -5.6683665513992310e-01
    phi[6,2]  R1945     -1.1315454244613647e+00
    phi[6,2]  R1946     -6.9839775562286377e-01
    phi[6,2]  R1947     1.9077036380767822e+00
    phi[6,2]  R1948     -7.7044510841369629e-01
    phi[6,2]  R1949     -1.7779903113842010e-01
    phi[6,2]  R1950     5.8586782217025757e-01
    phi[6,2]  R1951     -1.1418428421020508e+00
    phi[6,2]  R1952     -1.5784937143325806e+00
    phi[6,2]  R1953     -1.2711124420166016e+00
    phi[6,2]  R1954     -1.5991345643997192e+00
    phi[6,2]  R1955     -3.2730693817138672e+00
    phi[6,2]  R1956     -4.6830692887306213e-01
    phi[6,2]  R1957     9.8743689060211182e-01
    phi[6,2]  R1958     -8.4336519241333008e-01
    phi[6,2]  R1959     2.4134533405303955e+00
    phi[6,2]  R1960     -7.4234205484390259e-01
    phi[6,2]  R1961     3.3050251007080078e-01
    phi[6,2]  R1962     1.1298936605453491e+00
    phi[6,2]  R1963     1.7137253284454346e+00
    phi[6,2]  R1964     -4.0233942866325378e-01
    phi[6,2]  R1965     0.582848072052002
    phi[6,2]  R1966     -1.7573174238204956e+00
    phi[6,2]  R1967     -3.8639216423034668e+00
    phi[6,2]  R1968     -1.0604963302612305e+00
    phi[6,2]  R1969     -9.3738555908203125e-01
    phi[6,2]  R1970     1.2641808390617371e-01
    phi[6,2]  R1971     1.5678017139434814e+00
    phi[6,2]  R1972     1.1833475828170776e+00
    phi[6,2]  R1973     -3.2950100898742676e+00
    phi[6,2]  R1974     -2.5938773155212402e+00
    phi[6,2]  R1975     -2.8689846992492676e+00
    phi[6,2]  R1976     -3.3586139678955078e+00
    phi[6,2]  R1977     -3.4290775656700134e-01
    phi[6,2]  R1978     7.6658993959426880e-02
    phi[6,2]  R1979     1.6971069574356079e+00
    phi[6,2]  R1980     1.1999979019165039e+00
    phi[6,2]  R1981     -3.2554969787597656e+00
    phi[6,2]  R1982     -2.0682649612426758e+00
    phi[6,2]  R1983     -1.8494064807891846e+00
    phi[6,2]  R1984     -3.7303090095520020e+00
    phi[6,2]  R1985     4.8862797021865845e-01
    phi[6,2]  R1986     -1.1611957550048828e+00
    phi[6,2]  R1987     1.8736764192581177e+00
    phi[6,2]  R1988     2.6591706275939941e+00
    phi[6,2]  R1989     3.4267935752868652e+00
    phi[6,2]  R1990     3.1847443580627441e+00
    phi[6,2]  R1991     1.3899818658828735e+00
    phi[6,2]  R1992     2.7984743118286133e+00
    phi[6,2]  R1993     1.6508650779724121e+00
    phi[6,2]  R1994     1.3627080917358398e+00
    phi[6,2]  R1995     2.7761211395263672e+00
    phi[6,2]  R1996     1.6322623491287231e+00
    phi[6,2]  R1997     1.3762626647949219e+00
    phi[6,2]  R1998     6.3023847341537476e-01
    phi[6,2]  R1999     -3.2493534088134766e+00
    phi[6,2]  R2000     -3.3668019771575928e+00
    phi[6,2]  R2001     -3.5817096233367920e+00
    phi[6,2]  R2002     -2.8174347877502441e+00
    phi[6,2]  R2003     -8.1501394510269165e-01
    phi[6,2]  R2004     -2.9840941429138184e+00
    phi[6,2]  R2005     -8.5487204790115356e-01
    phi[6,2]  R2006     -2.4057426452636719e+00
    phi[6,2]  R2007     -1.2419953346252441e+00
    phi[6,2]  R2008     -1.4479204416275024e+00
    phi[6,2]  R2009     -1.8027145862579346e+00
    phi[6,2]  R2010     -7.8940087556838989e-01
    phi[6,2]  R2011     -1.6639393568038940e+00
    phi[6,2]  R2012     -5.3820240497589111e-01
    phi[6,2]  R2013     3.4851136803627014e-01
    phi[6,2]  R2014     -7.4307215213775635e-01
    phi[6,2]  R2015     -3.8825172185897827e-01
    phi[6,2]  R2016     6.8314611911773682e-02
    phi[6,2]  R2017     1.2263700366020203e-01
    phi[6,2]  R2018     -1.2162035703659058e+00
    phi[6,2]  R2019     -1.0650695562362671e+00
    phi[6,2]  R2020     -5.2027985453605652e-02
    phi[6,2]  R2021     2.7847609519958496e+00
    phi[6,2]  R2022     2.9651448130607605e-01
    phi[6,2]  R2023     -9.4075784087181091e-02
    phi[6,2]  R2024     4.3631577491760254e-01
    phi[6,2]  R2025     1.3488855361938477e+00
    phi[6,2]  R2026     3.1169718503952026e-01
    phi[6,2]  R2027     -3.2607132196426392e-01
    phi[6,2]  R2028     4.4164359569549561e-03
    phi[2,8]  R18       1
    phi[2,8]  R19       1
    phi[2,8]  R20       3.0220562801228108e+00
    phi[2,8]  R21       8.9888316693691483e-01
    phi[2,8]  R22       2.8887315014679698e+00
    phi[2,8]  R23       2.2444807554349677e+00
    phi[2,8]  R24       2.2469849340023949e+00
    phi[2,8]  R25       1.6802018745846223e+00
    phi[2,8]  R26       1.3806192528410679e+00
    phi[2,8]  R64       -1
    phi[2,8]  R2029     -7.7943624509757559e-02
    phi[2,8]  R2030     -6.12205618475538
    phi[2,8]  R2031     -1.3411168425998283e+00
    phi[2,8]  R2032     -3.1388831764736578e+00
    phi[2,8]  R2033     -2.1126840316459861e-01
    phi[2,8]  R2034     -5.9887314061005377e+00
    phi[2,8]  R2035     -3.2551917780783013e-01
    phi[2,8]  R2036     -4.8144806886777651e+00
    phi[2,8]  R2037     -8.5301497063017351e-01
    phi[2,8]  R2038     -5.3469848386349632e+00
    phi[2,8]  R2039     -4.0979803958468919e-01
    phi[2,8]  R2040     -3.7702017887539339e+00
    phi[2,8]  R2041     -1.7193806517915005e+00
    phi[2,8]  R2042     -4.4806191574736367e+00
    phi[2,8]  R2043     -1.0750275787822750e-01
    phi[2,8]  R2044     -1.0957591537481015e-01
    phi[2,8]  R2045     -1.1822805092670041e-01
    phi[2,8]  R2046     -1.3669297565191663e-01
    phi[2,8]  R2047     -1.4316098943238154e-01
    phi[2,8]  R2048     -3.5267764727251882e-01
    phi[2,8]  R2049     -1.5823687903415165e+00
    phi[2,8]  R2050     -1.5791044406238646e+00
    phi[2,8]  R2051     -1.3655147632317841e+00
    phi[2,8]  R2052     -5.9864759710063176e-01
    phi[2,8]  R2053     -1.3011436355532302e-01
    phi[2,8]  R2054     -1.4122603370726772e-01
    phi[2,8]  R2055     -1.6113195662415958e-01
    phi[2,8]  R2056     -1.9962718702483961e-01
    phi[2,8]  R2057     -2.0716465428238062e-01
    phi[2,8]  R2058     -2.4497877385912048e-01
    phi[2,8]  R2059     -2.6758679003542318e-01
    phi[2,8]  R2060     -2.9526949201725472e-01
    phi[2,8]  R2061     -3.3592308604261256e-01
    phi[2,8]  R2062     -3.4633449249218806e-01
    phi[2,8]  R2063     -1.3589557856707057e-01
    phi[2,8]  R2064     -1.8998512482650032e-01
    phi[2,8]  R2065     -2.4347036662840438e-01
    phi[2,8]  R2066     -3.1533818536406227e-01
    phi[2,8]  R2067     -3.1561253061177030e-01
    phi[2,8]  R2068     -3.1700933513065838e-01
    phi[2,8]  R2069     -3.1871511590931034e-01
    phi[2,8]  R2070     -3.2021615298374934e-01
    phi[2,8]  R2071     -3.3151370190198259e-01
    phi[2,8]  R2072     -3.3815473017709863e-01
    phi[2,8]  R2073     -2.0024532579389553e-01
    phi[2,8]  R2074     -3.1558660094346969e-01
    phi[2,8]  R2075     -3.6429468517945907e-01
    phi[2,8]  R2076     -1.5498511029826805e+00
    phi[2,8]  R2077     -1.6487770510282309e+00
    phi[2,8]  R2078     -1.6702399909108010e+00
    phi[2,8]  R2079     -1.4624360908668308e+00
    phi[2,8]  R2080     -1.3715609497052808e+00
    phi[2,8]  R2081     -1.2547948616961859e+00
    phi[2,8]  R2082     -1.4910946810267847e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R2083     -3.0999999046325684e+00
    phi[3,4]  R2084     -3.0999999046325684e+00
    phi[3,4]  R2085     -2.2400000095367432e+00
    phi[3,4]  R2086     -2.2400000095367432e+00
    phi[3,4]  R2087     -3.0999999046325684e+00
    phi[3,4]  R2088     -3.0999999046325684e+00
    phi[3,4]  R2089     -2.5699999332427979e+00
    phi[3,4]  R2090     -2.5699999332427979e+00
    phi[3,4]  R2091     -3.0999999046325684e+00
    phi[3,4]  R2092     -3.0999999046325684e+00
    phi[3,4]  R2093     -2.0899999141693115e+00
    phi[3,4]  R2094     -2.0899999141693115e+00
    phi[3,4]  R2095     -3.0999999046325684e+00
    phi[3,4]  R2096     -3.0999999046325684e+00
    phi[3,4]  R2097     2.6877233386039734e-01
    phi[3,4]  R2098     5.0975906848907471e-01
    phi[3,4]  R2099     6.8969108164310455e-02
    phi[3,4]  R2100     -6.3626605272293091e-01
    phi[3,4]  R2101     -4.8362094163894653e-01
    phi[3,4]  R2102     -1.3299602270126343e+00
    phi[3,4]  R2103     -1.2693172693252563e+00
    phi[3,4]  R2104     -9.0696513652801514e-01
    phi[3,4]  R2105     -1.0017442703247070e+00
    phi[3,4]  R2106     -1.7691845893859863e+00
    phi[3,4]  R2107     -3.2035681605339050e-01
    phi[3,4]  R2108     -2.8802313804626465e+00
    phi[3,4]  R2109     -7.2605943679809570e-01
    phi[3,4]  R2110     -3.0113141536712646e+00
    phi[3,4]  R2111     -3.1982965469360352e+00
    phi[3,4]  R2112     -2.2986972332000732e+00
    phi[3,4]  R2113     -0.961458683013916
    phi[3,4]  R2114     -3.40779709815979
    phi[3,4]  R2115     -1.4032102823257446e+00
    phi[3,4]  R2116     -7.4169713258743286e-01
    phi[3,4]  R2117     -0.701866626739502
    phi[3,4]  R2118     -2.3332602977752686e+00
    phi[3,4]  R2119     -1.2475509643554688e+00
    phi[3,4]  R2120     -2.1668624877929688e+00
    phi[3,4]  R2121     -1.4293750524520874e+00
    phi[3,4]  R2122     -1.5582545995712280e+00
    phi[3,4]  R2123     -2.3570244312286377e+00
    phi[3,4]  R2124     -1.2088606357574463e+00
    phi[3,4]  R2125     -2.6937718391418457e+00
    phi[3,4]  R2126     -2.9455242156982422e+00
    phi[3,4]  R2127     -1.6762331724166870e+00
    phi[3,4]  R2128     -0.000503971241414547
    phi[3,4]  R2129     -3.2402661442756653e-01
    phi[3,4]  R2130     -4.0109136700630188e-01
    phi[3,4]  R2131     -4.5128709077835083e-01
    phi[3,4]  R2132     3.8396877050399780e-01
    phi[3,4]  R2133     -2.6620849967002869e-01
    phi[3,4]  R2134     6.1780887842178345e-01
    phi[3,4]  R2135     0.597108781337738
    phi[3,4]  R2136     -1.4282256364822388e-01
    phi[3,4]  R2137     -4.2112955451011658e-01
    phi[3,4]  R2138     -1.3484647870063782e-01
    phi[3,4]  R2139     -1.5079364776611328e+00
    phi[3,4]  R2140     -1.9822832345962524e+00
    phi[3,4]  R2141     3.5428437590599060e-01
    phi[3,4]  R2142     0.698932945728302
    phi[3,4]  R2143     -1.0542341470718384e+00
    phi[3,4]  R2144     -4.5922747254371643e-01
    phi[3,4]  R2145     4.8277759552001953e-01
    phi[3,4]  R2146     1.4037504792213440e-01
    phi[3,4]  R2147     5.0263667106628418e-01
    phi[3,4]  R2148     4.3771672248840332e-01
    phi[3,4]  R2149     8.9146739244461060e-01
    phi[3,4]  R2150     3.4647789597511292e-01
    phi[3,4]  R2151     2.4962033331394196e-01
    phi[3,4]  R2152     -3.3308632671833038e-02
    phi[3,4]  R2153     -4.5381525158882141e-01
    phi[3,4]  R2154     -7.7385807037353516e-01
    phi[3,4]  R2155     -6.0524034500122070e-01
    phi[3,4]  R2156     -1.1582537889480591e+00
    phi[3,4]  R2157     -3.7087512016296387e-01
    phi[3,4]  R2158     -1.0231051445007324e+00
    phi[3,4]  R2159     -5.2838349342346191e-01
    phi[3,4]  R2160     -1.2783248424530029e+00
    phi[3,4]  R2161     -5.0509929656982422e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R2162     -3.0999999046325684e+00
    phi[4,3]  R2163     -3.0999999046325684e+00
    phi[4,3]  R2164     -2.2400000095367432e+00
    phi[4,3]  R2165     -2.2400000095367432e+00
    phi[4,3]  R2166     -3.0999999046325684e+00
    phi[4,3]  R2167     -3.0999999046325684e+00
    phi[4,3]  R2168     -2.5699999332427979e+00
    phi[4,3]  R2169     -2.5699999332427979e+00
    phi[4,3]  R2170     -3.0999999046325684e+00
    phi[4,3]  R2171     -3.0999999046325684e+00
    phi[4,3]  R2172     -2.0899999141693115e+00
    phi[4,3]  R2173     -2.0899999141693115e+00
    phi[4,3]  R2174     -3.0999999046325684e+00
    phi[4,3]  R2175     -3.0999999046325684e+00
    phi[4,3]  R2176     -2.6620849967002869e-01
    phi[4,3]  R2177     6.1780887842178345e-01
    phi[4,3]  R2178     0.597108781337738
    phi[4,3]  R2179     -1.4282256364822388e-01
    phi[4,3]  R2180     -4.2112955451011658e-01
    phi[4,3]  R2181     -1.3484647870063782e-01
    phi[4,3]  R2182     -1.5079364776611328e+00
    phi[4,3]  R2183     -1.9822832345962524e+00
    phi[4,3]  R2184     3.5428437590599060e-01
    phi[4,3]  R2185     0.698932945728302
    phi[4,3]  R2186     -1.0542341470718384e+00
    phi[4,3]  R2187     -4.5922747254371643e-01
    phi[4,3]  R2188     4.8277759552001953e-01
    phi[4,3]  R2189     1.4037504792213440e-01
    phi[4,3]  R2190     5.0263667106628418e-01
    phi[4,3]  R2191     4.3771672248840332e-01
    phi[4,3]  R2192     8.9146739244461060e-01
    phi[4,3]  R2193     3.4647789597511292e-01
    phi[4,3]  R2194     2.4962033331394196e-01
    phi[4,3]  R2195     -3.3308632671833038e-02
    phi[4,3]  R2196     -4.5381525158882141e-01
    phi[4,3]  R2197     -7.7385807037353516e-01
    phi[4,3]  R2198     -6.0524034500122070e-01
    phi[4,3]  R2199     -1.1582537889480591e+00
    phi[4,3]  R2200     -3.7087512016296387e-01
    phi[4,3]  R2201     -1.0231051445007324e+00
    phi[4,3]  R2202     -5.2838349342346191e-01
    phi[4,3]  R2203     -1.2783248424530029e+00
    phi[4,3]  R2204     -5.0509929656982422e-01
    phi[4,3]  R2205     2.6877233386039734e-01
    phi[4,3]  R2206     5.0975906848907471e-01
    phi[4,3]  R2207     6.8969108164310455e-02
    phi[4,3]  R2208     -6.3626605272293091e-01
    phi[4,3]  R2209     -4.8362094163894653e-01
    phi[4,3]  R2210     -1.3299602270126343e+00
    phi[4,3]  R2211     -1.2693172693252563e+00
    phi[4,3]  R2212     -9.0696513652801514e-01
    phi[4,3]  R2213     -1.0017442703247070e+00
    phi[4,3]  R2214     -1.7691845893859863e+00
    phi[4,3]  R2215     -3.2035681605339050e-01
    phi[4,3]  R2216     -2.8802313804626465e+00
    phi[4,3]  R2217     -7.2605943679809570e-01
    phi[4,3]  R2218     -3.0113141536712646e+00
    phi[4,3]  R2219     -3.1982965469360352e+00
    phi[4,3]  R2220     -2.2986972332000732e+00
    phi[4,3]  R2221     -0.961458683013916
    phi[4,3]  R2222     -3.40779709815979
    phi[4,3]  R2223     -1.4032102823257446e+00
    phi[4,3]  R2224     -7.4169713258743286e-01
    phi[4,3]  R2225     -0.701866626739502
    phi[4,3]  R2226     -2.3332602977752686e+00
    phi[4,3]  R2227     -1.2475509643554688e+00
    phi[4,3]  R2228     -2.1668624877929688e+00
    phi[4,3]  R2229     -1.4293750524520874e+00
    phi[4,3]  R2230     -1.5582545995712280e+00
    phi[4,3]  R2231     -2.3570244312286377e+00
    phi[4,3]  R2232     -1.2088606357574463e+00
    phi[4,3]  R2233     -2.6937718391418457e+00
    phi[4,3]  R2234     -2.9455242156982422e+00
    phi[4,3]  R2235     -1.6762331724166870e+00
    phi[4,3]  R2236     -0.000503971241414547
    phi[4,3]  R2237     -3.2402661442756653e-01
    phi[4,3]  R2238     -4.0109136700630188e-01
    phi[4,3]  R2239     -4.5128709077835083e-01
    phi[4,3]  R2240     3.8396877050399780e-01
    phi[3,5]  R27       1
    phi[3,5]  R28       1
    phi[3,5]  R45       -1
    phi[3,5]  R2241     -3.0999999046325684e+00
    phi[3,5]  R2242     -3.0999999046325684e+00
    phi[3,5]  R2243     -2.2400000095367432e+00
    phi[3,5]  R2244     -2.2400000095367432e+00
    phi[3,5]  R2245     -3.0999999046325684e+00
    phi[3,5]  R2246     -3.0999999046325684e+00
    phi[3,5]  R2247     -2.5699999332427979e+00
    phi[3,5]  R2248     -2.5699999332427979e+00
    phi[3,5]  R2249     -3.0999999046325684e+00
    phi[3,5]  R2250     -3.0999999046325684e+00
    phi[3,5]  R2251     -2.0899999141693115e+00
    phi[3,5]  R2252     -2.0899999141693115e+00
    phi[3,5]  R2253     -3.0999999046325684e+00
    phi[3,5]  R2254     -3.0999999046325684e+00
    phi[3,5]  R2255     2.6877233386039734e-01
    phi[3,5]  R2256     5.0975906848907471e-01
    phi[3,5]  R2257     6.8969108164310455e-02
    phi[3,5]  R2258     -6.3626605272293091e-01
    phi[3,5]  R2259     -4.8362094163894653e-01
    phi[3,5]  R2260     -1.3299602270126343e+00
    phi[3,5]  R2261     -1.2693172693252563e+00
    phi[3,5]  R2262     -9.0696513652801514e-01
    phi[3,5]  R2263     -1.0017442703247070e+00
    phi[3,5]  R2264     -1.7691845893859863e+00
    phi[3,5]  R2265     -3.2035681605339050e-01
    phi[3,5]  R2266     -2.8802313804626465e+00
    phi[3,5]  R2267     -7.2605943679809570e-01
    phi[3,5]  R2268     -3.0113141536712646e+00
    phi[3,5]  R2269     -3.1982965469360352e+00
    phi[3,5]  R2270     -2.2986972332000732e+00
    phi[3,5]  R2271     -0.961458683013916
    phi[3,5]  R2272     -3.40779709815979
    phi[3,5]  R2273     -1.4032102823257446e+00
    phi[3,5]  R2274     -7.4169713258743286e-01
    phi[3,5]  R2275     -0.701866626739502
    phi[3,5]  R2276     -2.3332602977752686e+00
    phi[3,5]  R2277     -1.2475509643554688e+00
    phi[3,5]  R2278     -2.1668624877929688e+00
    phi[3,5]  R2279     -1.4293750524520874e+00
    phi[3,5]  R2280     -1.5582545995712280e+00
    phi[3,5]  R2281     -2.3570244312286377e+00
    phi[3,5]  R2282     -1.2088606357574463e+00
    phi[3,5]  R2283     -2.6937718391418457e+00
    phi[3,5]  R2284     -2.9455242156982422e+00
    phi[3,5]  R2285     -1.6762331724166870e+00
    phi[3,5]  R2286     -0.000503971241414547
    phi[3,5]  R2287     -3.2402661442756653e-01
    phi[3,5]  R2288     -4.0109136700630188e-01
    phi[3,5]  R2289     -4.5128709077835083e-01
    phi[3,5]  R2290     3.8396877050399780e-01
    phi[3,5]  R2291     7.4282556772232056e-01
    phi[3,5]  R2292     2.9529479146003723e-01
    phi[3,5]  R2293     1.1315840482711792e+00
    phi[3,5]  R2294     4.4400626420974731e-01
    phi[3,5]  R2295     -6.2369279563426971e-02
    phi[3,5]  R2296     8.0027955770492554e-01
    phi[3,5]  R2297     5.8231145143508911e-01
    phi[3,5]  R2298     0.707918107509613
    phi[3,5]  R2299     1.4931190013885498e+00
    phi[3,5]  R2300     -7.5401759147644043e-01
    phi[3,5]  R2301     -6.9086164236068726e-01
    phi[3,5]  R2302     -1.6924331188201904e+00
    phi[3,5]  R2303     -2.3630063533782959e+00
    phi[3,5]  R2304     -2.3373171687126160e-01
    phi[3,5]  R2305     8.4866231679916382e-01
    phi[3,5]  R2306     1.0191968083381653e-01
    phi[3,5]  R2307     -8.9570456743240356e-01
    phi[3,5]  R2308     -1.2557879090309143e-01
    phi[3,5]  R2309     -2.5273486971855164e-01
    phi[3,5]  R2310     -2.1915815770626068e-01
    phi[3,5]  R2311     -2.1859364509582520e+00
    phi[3,5]  R2312     1.7728338241577148e+00
    phi[3,5]  R2313     -1.6886414289474487e+00
    phi[3,5]  R2314     -1.3068474531173706e+00
    phi[3,5]  R2315     -3.3660628795623779e+00
    phi[3,5]  R2316     -2.1086461544036865e+00
    phi[3,5]  R2317     -1.8140971660614014e+00
    phi[3,5]  R2318     -2.83530855178833
    phi[3,5]  R2319     -2.9731068611145020e+00
    phi[3,5]  R2320     -2.5195360183715820e+00
    phi[3,5]  R2321     -6.9067078828811646e-01
    phi[3,5]  R2322     -2.1897029876708984e+00
    phi[3,5]  R2323     -4.0695637464523315e-01
    phi[3,5]  R2324     -2.0363402366638184e+00
    phi[3,5]  R2325     5.6539326906204224e-01
    phi[3,5]  R2326     5.2155834436416626e-01
    phi[3,5]  R2327     9.5216894149780273e-01
    phi[3,5]  R2328     -0.985035240650177
    phi[3,5]  R2329     3.3206190913915634e-02
    phi[3,5]  R2330     2.0095043182373047e+00
    phi[3,5]  R2331     -3.2473711967468262e+00
    phi[3,5]  R2332     1.0882055759429932e+00
    phi[3,5]  R2333     2.2832448482513428e+00
    phi[3,5]  R2334     7.0544868707656860e-01
    phi[3,5]  R2335     1.1342386007308960e+00
    phi[3,5]  R2336     -1.6827241182327271e+00
    phi[3,5]  R2337     -3.2920449972152710e-01
    phi[3,5]  R2338     5.2749556303024292e-01
    phi[3,5]  R2339     2.0337255001068115e+00
    phi[3,5]  R2340     1.16041100025177
    phi[5,3]  R27       -1
    phi[5,3]  R45       1
    phi[5,3]  R46       1
    phi[5,3]  R2341     -3.0999999046325684e+00
    phi[5,3]  R2342     -3.0999999046325684e+00
    phi[5,3]  R2343     -2.2400000095367432e+00
    phi[5,3]  R2344     -2.2400000095367432e+00
    phi[5,3]  R2345     -3.0999999046325684e+00
    phi[5,3]  R2346     -3.0999999046325684e+00
    phi[5,3]  R2347     -2.5699999332427979e+00
    phi[5,3]  R2348     -2.5699999332427979e+00
    phi[5,3]  R2349     -3.0999999046325684e+00
    phi[5,3]  R2350     -3.0999999046325684e+00
    phi[5,3]  R2351     -2.0899999141693115e+00
    phi[5,3]  R2352     -2.0899999141693115e+00
    phi[5,3]  R2353     -3.0999999046325684e+00
    phi[5,3]  R2354     -3.0999999046325684e+00
    phi[5,3]  R2355     7.4282556772232056e-01
    phi[5,3]  R2356     2.9529479146003723e-01
    phi[5,3]  R2357     1.1315840482711792e+00
    phi[5,3]  R2358     4.4400626420974731e-01
    phi[5,3]  R2359     -6.2369279563426971e-02
    phi[5,3]  R2360     8.0027955770492554e-01
    phi[5,3]  R2361     5.8231145143508911e-01
    phi[5,3]  R2362     0.707918107509613
    phi[5,3]  R2363     1.4931190013885498e+00
    phi[5,3]  R2364     -7.5401759147644043e-01
    phi[5,3]  R2365     -6.9086164236068726e-01
    phi[5,3]  R2366     -1.6924331188201904e+00
    phi[5,3]  R2367     -2.3630063533782959e+00
    phi[5,3]  R2368     -2.3373171687126160e-01
    phi[5,3]  R2369     8.4866231679916382e-01
    phi[5,3]  R2370     1.0191968083381653e-01
    phi[5,3]  R2371     -8.9570456743240356e-01
    phi[5,3]  R2372     -1.2557879090309143e-01
    phi[5,3]  R2373     -2.5273486971855164e-01
    phi[5,3]  R2374     -2.1915815770626068e-01
    phi[5,3]  R2375     -2.1859364509582520e+00
    phi[5,3]  R2376     1.7728338241577148e+00
    phi[5,3]  R2377     -1.6886414289474487e+00
    phi[5,3]  R2378     -1.3068474531173706e+00
    phi[5,3]  R2379     -3.3660628795623779e+00
    phi[5,3]  R2380     -2.1086461544036865e+00
    phi[5,3]  R2381     -1.8140971660614014e+00
    phi[5,3]  R2382     -2.83530855178833
    phi[5,3]  R2383     -2.9731068611145020e+00
    phi[5,3]  R2384     -2.5195360183715820e+00
    phi[5,3]  R2385     -6.9067078828811646e-01
    phi[5,3]  R2386     -2.1897029876708984e+00
    phi[5,3]  R2387     -4.0695637464523315e-01
    phi[5,3]  R2388     -2.0363402366638184e+00
    phi[5,3]  R2389     5.6539326906204224e-01
    phi[5,3]  R2390     5.2155834436416626e-01
    phi[5,3]  R2391     9.5216894149780273e-01
    phi[5,3]  R2392     -0.985035240650177
    phi[5,3]  R2393     3.3206190913915634e-02
    phi[5,3]  R2394     2.0095043182373047e+00
    phi[5,3]  R2395     -3.2473711967468262e+00
    phi[5,3]  R2396     1.0882055759429932e+00
    phi[5,3]  R2397     2.2832448482513428e+00
    phi[5,3]  R2398     7.0544868707656860e-01
    phi[5,3]  R2399     1.1342386007308960e+00
    phi[5,3]  R2400     -1.6827241182327271e+00
    phi[5,3]  R2401     -3.2920449972152710e-01
    phi[5,3]  R2402     5.2749556303024292e-01
    phi[5,3]  R2403     2.0337255001068115e+00
    phi[5,3]  R2404     1.16041100025177
    phi[5,3]  R2405     2.6877233386039734e-01
    phi[5,3]  R2406     5.0975906848907471e-01
    phi[5,3]  R2407     6.8969108164310455e-02
    phi[5,3]  R2408     -6.3626605272293091e-01
    phi[5,3]  R2409     -4.8362094163894653e-01
    phi[5,3]  R2410     -1.3299602270126343e+00
    phi[5,3]  R2411     -1.2693172693252563e+00
    phi[5,3]  R2412     -9.0696513652801514e-01
    phi[5,3]  R2413     -1.0017442703247070e+00
    phi[5,3]  R2414     -1.7691845893859863e+00
    phi[5,3]  R2415     -3.2035681605339050e-01
    phi[5,3]  R2416     -2.8802313804626465e+00
    phi[5,3]  R2417     -7.2605943679809570e-01
    phi[5,3]  R2418     -3.0113141536712646e+00
    phi[5,3]  R2419     -3.1982965469360352e+00
    phi[5,3]  R2420     -2.2986972332000732e+00
    phi[5,3]  R2421     -0.961458683013916
    phi[5,3]  R2422     -3.40779709815979
    phi[5,3]  R2423     -1.4032102823257446e+00
    phi[5,3]  R2424     -7.4169713258743286e-01
    phi[5,3]  R2425     -0.701866626739502
    phi[5,3]  R2426     -2.3332602977752686e+00
    phi[5,3]  R2427     -1.2475509643554688e+00
    phi[5,3]  R2428     -2.1668624877929688e+00
    phi[5,3]  R2429     -1.4293750524520874e+00
    phi[5,3]  R2430     -1.5582545995712280e+00
    phi[5,3]  R2431     -2.3570244312286377e+00
    phi[5,3]  R2432     -1.2088606357574463e+00
    phi[5,3]  R2433     -2.6937718391418457e+00
    phi[5,3]  R2434     -2.9455242156982422e+00
    phi[5,3]  R2435     -1.6762331724166870e+00
    phi[5,3]  R2436     -0.000503971241414547
    phi[5,3]  R2437     -3.2402661442756653e-01
    phi[5,3]  R2438     -4.0109136700630188e-01
    phi[5,3]  R2439     -4.5128709077835083e-01
    phi[5,3]  R2440     3.8396877050399780e-01
    phi[7,3]  R27       -1
    phi[7,3]  R29       2.3795410456599257e+00
    phi[7,3]  R30       4.9418230632458737e-01
    phi[7,3]  R31       1.7236009477472281e+00
    phi[7,3]  R32       -3.2571415741751997e-01
    phi[7,3]  R33       2.2724450891951746e+00
    phi[7,3]  R34       4.4884213324225586e-01
    phi[7,3]  R35       -2.3026884603500104e+00
    phi[7,3]  R63       1
    phi[7,3]  R2441     -5.4795409502924937e+00
    phi[7,3]  R2442     -7.2045885897264261e-01
    phi[7,3]  R2443     -2.7341823158613305e+00
    phi[7,3]  R2444     -1.7458177032121558e+00
    phi[7,3]  R2445     -4.8236008523797960e+00
    phi[7,3]  R2446     -1.3763989568853403e+00
    phi[7,3]  R2447     -2.2442857758252779e+00
    phi[7,3]  R2448     -2.8957140906603178e+00
    phi[7,3]  R2449     -5.3724449938277434e+00
    phi[7,3]  R2450     -8.2755481543739373e-01
    phi[7,3]  R2451     -2.5388420474115674e+00
    phi[7,3]  R2452     -1.6411577809270557e+00
    phi[7,3]  R2453     -0.797311444282558
    phi[7,3]  R2454     -5.4026883649825788e+00
    phi[7,3]  R2455     -4.2967301579551032e-02
    phi[7,3]  R2456     -5.3297408145647984e-02
    phi[7,3]  R2457     -7.7139207081305061e-02
    phi[7,3]  R2458     -9.9515973007808567e-02
    phi[7,3]  R2459     -1.0850299647082073e-01
    phi[7,3]  R2460     -1.6648741854696958e-01
    phi[7,3]  R2461     -1.7310973866889157e-01
    phi[7,3]  R2462     -3.0888585511366857e+00
    phi[7,3]  R2463     -4.1062510258035145e-01
    phi[7,3]  R2464     -4.1857226993420582e-01
    phi[7,3]  R2465     -8.1111036316857454e-02
    phi[7,3]  R2466     -3.7933744928883284e-01
    phi[7,3]  R2467     -3.8590756278652749e-01
    phi[7,3]  R2468     -3.9426317680630518e-01
    phi[7,3]  R2469     -3.9457813763328975e-01
    phi[7,3]  R2470     -4.2157425758660616e-01
    phi[7,3]  R2471     -4.3661987609584429e-01
    phi[7,3]  R2472     -4.3710477032462114e-01
    phi[7,3]  R2473     -4.4606713480408955e-01
    phi[7,3]  R2474     -4.6823212440313522e-01
    phi[7,3]  R2475     -3.2873869482219764e-01
    phi[7,3]  R2476     -3.3023283062581754e-01
    phi[7,3]  R2477     -3.3092236316217383e-01
    phi[7,3]  R2478     -3.3101222547038267e-01
    phi[7,3]  R2479     -3.3291827298613375e-01
    phi[7,3]  R2480     -3.3696873796816318e-01
    phi[7,3]  R2481     -0.34293774834084
    phi[7,3]  R2482     -3.4642168528914319e-01
    phi[7,3]  R2483     -3.6140487120503639e-01
    phi[7,3]  R2484     -3.7111546119963723e-01
    phi[7,3]  R2485     -3.3672259275244132e-01
    phi[7,3]  R2486     -5.6279194770426466e-01
    phi[7,3]  R2487     -6.0759135943710985e-01
    phi[7,3]  R2488     -6.3505022596780247e-01
    phi[7,3]  R2489     -6.5404785222148509e-01
    phi[7,3]  R2490     -8.5388148861837476e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2491     -3.0999999046325684e+00
    phi[4,5]  R2492     -3.0999999046325684e+00
    phi[4,5]  R2493     -2.2400000095367432e+00
    phi[4,5]  R2494     -2.2400000095367432e+00
    phi[4,5]  R2495     -3.0999999046325684e+00
    phi[4,5]  R2496     -3.0999999046325684e+00
    phi[4,5]  R2497     -2.5699999332427979e+00
    phi[4,5]  R2498     -2.5699999332427979e+00
    phi[4,5]  R2499     -3.0999999046325684e+00
    phi[4,5]  R2500     -3.0999999046325684e+00
    phi[4,5]  R2501     -2.0899999141693115e+00
    phi[4,5]  R2502     -2.0899999141693115e+00
    phi[4,5]  R2503     -3.0999999046325684e+00
    phi[4,5]  R2504     -3.0999999046325684e+00
    phi[4,5]  R2505     -2.6620849967002869e-01
    phi[4,5]  R2506     6.1780887842178345e-01
    phi[4,5]  R2507     0.597108781337738
    phi[4,5]  R2508     -1.4282256364822388e-01
    phi[4,5]  R2509     -4.2112955451011658e-01
    phi[4,5]  R2510     -1.3484647870063782e-01
    phi[4,5]  R2511     -1.5079364776611328e+00
    phi[4,5]  R2512     -1.9822832345962524e+00
    phi[4,5]  R2513     3.5428437590599060e-01
    phi[4,5]  R2514     0.698932945728302
    phi[4,5]  R2515     -1.0542341470718384e+00
    phi[4,5]  R2516     -4.5922747254371643e-01
    phi[4,5]  R2517     4.8277759552001953e-01
    phi[4,5]  R2518     1.4037504792213440e-01
    phi[4,5]  R2519     5.0263667106628418e-01
    phi[4,5]  R2520     4.3771672248840332e-01
    phi[4,5]  R2521     8.9146739244461060e-01
    phi[4,5]  R2522     3.4647789597511292e-01
    phi[4,5]  R2523     2.4962033331394196e-01
    phi[4,5]  R2524     -3.3308632671833038e-02
    phi[4,5]  R2525     -4.5381525158882141e-01
    phi[4,5]  R2526     -7.7385807037353516e-01
    phi[4,5]  R2527     -6.0524034500122070e-01
    phi[4,5]  R2528     -1.1582537889480591e+00
    phi[4,5]  R2529     -3.7087512016296387e-01
    phi[4,5]  R2530     -1.0231051445007324e+00
    phi[4,5]  R2531     -5.2838349342346191e-01
    phi[4,5]  R2532     -1.2783248424530029e+00
    phi[4,5]  R2533     -5.0509929656982422e-01
    phi[4,5]  R2534     7.4282556772232056e-01
    phi[4,5]  R2535     2.9529479146003723e-01
    phi[4,5]  R2536     1.1315840482711792e+00
    phi[4,5]  R2537     4.4400626420974731e-01
    phi[4,5]  R2538     -6.2369279563426971e-02
    phi[4,5]  R2539     8.0027955770492554e-01
    phi[4,5]  R2540     5.8231145143508911e-01
    phi[4,5]  R2541     0.707918107509613
    phi[4,5]  R2542     1.4931190013885498e+00
    phi[4,5]  R2543     -7.5401759147644043e-01
    phi[4,5]  R2544     -6.9086164236068726e-01
    phi[4,5]  R2545     -1.6924331188201904e+00
    phi[4,5]  R2546     -2.3630063533782959e+00
    phi[4,5]  R2547     -2.3373171687126160e-01
    phi[4,5]  R2548     8.4866231679916382e-01
    phi[4,5]  R2549     1.0191968083381653e-01
    phi[4,5]  R2550     -8.9570456743240356e-01
    phi[4,5]  R2551     -1.2557879090309143e-01
    phi[4,5]  R2552     -2.5273486971855164e-01
    phi[4,5]  R2553     -2.1915815770626068e-01
    phi[4,5]  R2554     -2.1859364509582520e+00
    phi[4,5]  R2555     1.7728338241577148e+00
    phi[4,5]  R2556     -1.6886414289474487e+00
    phi[4,5]  R2557     -1.3068474531173706e+00
    phi[4,5]  R2558     -3.3660628795623779e+00
    phi[4,5]  R2559     -2.1086461544036865e+00
    phi[4,5]  R2560     -1.8140971660614014e+00
    phi[4,5]  R2561     -2.83530855178833
    phi[4,5]  R2562     -2.9731068611145020e+00
    phi[4,5]  R2563     -2.5195360183715820e+00
    phi[4,5]  R2564     -6.9067078828811646e-01
    phi[4,5]  R2565     -2.1897029876708984e+00
    phi[4,5]  R2566     -4.0695637464523315e-01
    phi[4,5]  R2567     -2.0363402366638184e+00
    phi[4,5]  R2568     5.6539326906204224e-01
    phi[4,5]  R2569     5.2155834436416626e-01
    phi[4,5]  R2570     9.5216894149780273e-01
    phi[4,5]  R2571     -0.985035240650177
    phi[4,5]  R2572     3.3206190913915634e-02
    phi[4,5]  R2573     2.0095043182373047e+00
    phi[4,5]  R2574     -3.2473711967468262e+00
    phi[4,5]  R2575     1.0882055759429932e+00
    phi[4,5]  R2576     2.2832448482513428e+00
    phi[4,5]  R2577     7.0544868707656860e-01
    phi[4,5]  R2578     1.1342386007308960e+00
    phi[4,5]  R2579     -1.6827241182327271e+00
    phi[4,5]  R2580     -3.2920449972152710e-01
    phi[4,5]  R2581     5.2749556303024292e-01
    phi[4,5]  R2582     2.0337255001068115e+00
    phi[4,5]  R2583     1.16041100025177
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2584     -3.0999999046325684e+00
    phi[5,4]  R2585     -3.0999999046325684e+00
    phi[5,4]  R2586     -2.2400000095367432e+00
    phi[5,4]  R2587     -2.2400000095367432e+00
    phi[5,4]  R2588     -3.0999999046325684e+00
    phi[5,4]  R2589     -3.0999999046325684e+00
    phi[5,4]  R2590     -2.5699999332427979e+00
    phi[5,4]  R2591     -2.5699999332427979e+00
    phi[5,4]  R2592     -3.0999999046325684e+00
    phi[5,4]  R2593     -3.0999999046325684e+00
    phi[5,4]  R2594     -2.0899999141693115e+00
    phi[5,4]  R2595     -2.0899999141693115e+00
    phi[5,4]  R2596     -3.0999999046325684e+00
    phi[5,4]  R2597     -3.0999999046325684e+00
    phi[5,4]  R2598     7.4282556772232056e-01
    phi[5,4]  R2599     2.9529479146003723e-01
    phi[5,4]  R2600     1.1315840482711792e+00
    phi[5,4]  R2601     4.4400626420974731e-01
    phi[5,4]  R2602     -6.2369279563426971e-02
    phi[5,4]  R2603     8.0027955770492554e-01
    phi[5,4]  R2604     5.8231145143508911e-01
    phi[5,4]  R2605     0.707918107509613
    phi[5,4]  R2606     1.4931190013885498e+00
    phi[5,4]  R2607     -7.5401759147644043e-01
    phi[5,4]  R2608     -6.9086164236068726e-01
    phi[5,4]  R2609     -1.6924331188201904e+00
    phi[5,4]  R2610     -2.3630063533782959e+00
    phi[5,4]  R2611     -2.3373171687126160e-01
    phi[5,4]  R2612     8.4866231679916382e-01
    phi[5,4]  R2613     1.0191968083381653e-01
    phi[5,4]  R2614     -8.9570456743240356e-01
    phi[5,4]  R2615     -1.2557879090309143e-01
    phi[5,4]  R2616     -2.5273486971855164e-01
    phi[5,4]  R2617     -2.1915815770626068e-01
    phi[5,4]  R2618     -2.1859364509582520e+00
    phi[5,4]  R2619     1.7728338241577148e+00
    phi[5,4]  R2620     -1.6886414289474487e+00
    phi[5,4]  R2621     -1.3068474531173706e+00
    phi[5,4]  R2622     -3.3660628795623779e+00
    phi[5,4]  R2623     -2.1086461544036865e+00
    phi[5,4]  R2624     -1.8140971660614014e+00
    phi[5,4]  R2625     -2.83530855178833
    phi[5,4]  R2626     -2.9731068611145020e+00
    phi[5,4]  R2627     -2.5195360183715820e+00
    phi[5,4]  R2628     -6.9067078828811646e-01
    phi[5,4]  R2629     -2.1897029876708984e+00
    phi[5,4]  R2630     -4.0695637464523315e-01
    phi[5,4]  R2631     -2.0363402366638184e+00
    phi[5,4]  R2632     5.6539326906204224e-01
    phi[5,4]  R2633     5.2155834436416626e-01
    phi[5,4]  R2634     9.5216894149780273e-01
    phi[5,4]  R2635     -0.985035240650177
    phi[5,4]  R2636     3.3206190913915634e-02
    phi[5,4]  R2637     2.0095043182373047e+00
    phi[5,4]  R2638     -3.2473711967468262e+00
    phi[5,4]  R2639     1.0882055759429932e+00
    phi[5,4]  R2640     2.2832448482513428e+00
    phi[5,4]  R2641     7.0544868707656860e-01
    phi[5,4]  R2642     1.1342386007308960e+00
    phi[5,4]  R2643     -1.6827241182327271e+00
    phi[5,4]  R2644     -3.2920449972152710e-01
    phi[5,4]  R2645     5.2749556303024292e-01
    phi[5,4]  R2646     2.0337255001068115e+00
    phi[5,4]  R2647     1.16041100025177
    phi[5,4]  R2648     -2.6620849967002869e-01
    phi[5,4]  R2649     6.1780887842178345e-01
    phi[5,4]  R2650     0.597108781337738
    phi[5,4]  R2651     -1.4282256364822388e-01
    phi[5,4]  R2652     -4.2112955451011658e-01
    phi[5,4]  R2653     -1.3484647870063782e-01
    phi[5,4]  R2654     -1.5079364776611328e+00
    phi[5,4]  R2655     -1.9822832345962524e+00
    phi[5,4]  R2656     3.5428437590599060e-01
    phi[5,4]  R2657     0.698932945728302
    phi[5,4]  R2658     -1.0542341470718384e+00
    phi[5,4]  R2659     -4.5922747254371643e-01
    phi[5,4]  R2660     4.8277759552001953e-01
    phi[5,4]  R2661     1.4037504792213440e-01
    phi[5,4]  R2662     5.0263667106628418e-01
    phi[5,4]  R2663     4.3771672248840332e-01
    phi[5,4]  R2664     8.9146739244461060e-01
    phi[5,4]  R2665     3.4647789597511292e-01
    phi[5,4]  R2666     2.4962033331394196e-01
    phi[5,4]  R2667     -3.3308632671833038e-02
    phi[5,4]  R2668     -4.5381525158882141e-01
    phi[5,4]  R2669     -7.7385807037353516e-01
    phi[5,4]  R2670     -6.0524034500122070e-01
    phi[5,4]  R2671     -1.1582537889480591e+00
    phi[5,4]  R2672     -3.7087512016296387e-01
    phi[5,4]  R2673     -1.0231051445007324e+00
    phi[5,4]  R2674     -5.2838349342346191e-01
    phi[5,4]  R2675     -1.2783248424530029e+00
    phi[5,4]  R2676     -5.0509929656982422e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2677     -3.0999999046325684e+00
    phi[5,6]  R2678     -3.0999999046325684e+00
    phi[5,6]  R2679     -2.2400000095367432e+00
    phi[5,6]  R2680     -2.2400000095367432e+00
    phi[5,6]  R2681     -3.0999999046325684e+00
    phi[5,6]  R2682     -3.0999999046325684e+00
    phi[5,6]  R2683     -2.5699999332427979e+00
    phi[5,6]  R2684     -2.5699999332427979e+00
    phi[5,6]  R2685     -3.0999999046325684e+00
    phi[5,6]  R2686     -3.0999999046325684e+00
    phi[5,6]  R2687     -2.0899999141693115e+00
    phi[5,6]  R2688     -2.0899999141693115e+00
    phi[5,6]  R2689     -3.0999999046325684e+00
    phi[5,6]  R2690     -3.0999999046325684e+00
    phi[5,6]  R2691     7.4282556772232056e-01
    phi[5,6]  R2692     2.9529479146003723e-01
    phi[5,6]  R2693     1.1315840482711792e+00
    phi[5,6]  R2694     4.4400626420974731e-01
    phi[5,6]  R2695     -6.2369279563426971e-02
    phi[5,6]  R2696     8.0027955770492554e-01
    phi[5,6]  R2697     5.8231145143508911e-01
    phi[5,6]  R2698     0.707918107509613
    phi[5,6]  R2699     1.4931190013885498e+00
    phi[5,6]  R2700     -7.5401759147644043e-01
    phi[5,6]  R2701     -6.9086164236068726e-01
    phi[5,6]  R2702     -1.6924331188201904e+00
    phi[5,6]  R2703     -2.3630063533782959e+00
    phi[5,6]  R2704     -2.3373171687126160e-01
    phi[5,6]  R2705     8.4866231679916382e-01
    phi[5,6]  R2706     1.0191968083381653e-01
    phi[5,6]  R2707     -8.9570456743240356e-01
    phi[5,6]  R2708     -1.2557879090309143e-01
    phi[5,6]  R2709     -2.5273486971855164e-01
    phi[5,6]  R2710     -2.1915815770626068e-01
    phi[5,6]  R2711     -2.1859364509582520e+00
    phi[5,6]  R2712     1.7728338241577148e+00
    phi[5,6]  R2713     -1.6886414289474487e+00
    phi[5,6]  R2714     -1.3068474531173706e+00
    phi[5,6]  R2715     -3.3660628795623779e+00
    phi[5,6]  R2716     -2.1086461544036865e+00
    phi[5,6]  R2717     -1.8140971660614014e+00
    phi[5,6]  R2718     -2.83530855178833
    phi[5,6]  R2719     -2.9731068611145020e+00
    phi[5,6]  R2720     -2.5195360183715820e+00
    phi[5,6]  R2721     -6.9067078828811646e-01
    phi[5,6]  R2722     -2.1897029876708984e+00
    phi[5,6]  R2723     -4.0695637464523315e-01
    phi[5,6]  R2724     -2.0363402366638184e+00
    phi[5,6]  R2725     5.6539326906204224e-01
    phi[5,6]  R2726     5.2155834436416626e-01
    phi[5,6]  R2727     9.5216894149780273e-01
    phi[5,6]  R2728     -0.985035240650177
    phi[5,6]  R2729     3.3206190913915634e-02
    phi[5,6]  R2730     2.0095043182373047e+00
    phi[5,6]  R2731     -3.2473711967468262e+00
    phi[5,6]  R2732     1.0882055759429932e+00
    phi[5,6]  R2733     2.2832448482513428e+00
    phi[5,6]  R2734     7.0544868707656860e-01
    phi[5,6]  R2735     1.1342386007308960e+00
    phi[5,6]  R2736     -1.6827241182327271e+00
    phi[5,6]  R2737     -3.2920449972152710e-01
    phi[5,6]  R2738     5.2749556303024292e-01
    phi[5,6]  R2739     2.0337255001068115e+00
    phi[5,6]  R2740     1.16041100025177
    phi[5,6]  R2741     2.6976850032806396e+00
    phi[5,6]  R2742     0.0649002343416214
    phi[5,6]  R2743     1.4660350084304810e+00
    phi[5,6]  R2744     1.6225330829620361e+00
    phi[5,6]  R2745     -1.4243797063827515e+00
    phi[5,6]  R2746     1.1959240436553955e+00
    phi[5,6]  R2747     2.5323469638824463e+00
    phi[5,6]  R2748     -7.2055578231811523e-01
    phi[5,6]  R2749     7.6183575391769409e-01
    phi[5,6]  R2750     1.4031524658203125e+00
    phi[5,6]  R2751     -6.8570256233215332e-01
    phi[5,6]  R2752     1.1997667551040649e+00
    phi[5,6]  R2753     -1.7051937580108643e+00
    phi[5,6]  R2754     -5.6683665513992310e-01
    phi[5,6]  R2755     -1.1315454244613647e+00
    phi[5,6]  R2756     -6.9839775562286377e-01
    phi[5,6]  R2757     1.9077036380767822e+00
    phi[5,6]  R2758     -7.7044510841369629e-01
    phi[5,6]  R2759     -1.7779903113842010e-01
    phi[5,6]  R2760     5.8586782217025757e-01
    phi[5,6]  R2761     -1.1418428421020508e+00
    phi[5,6]  R2762     -1.5784937143325806e+00
    phi[5,6]  R2763     -1.2711124420166016e+00
    phi[5,6]  R2764     -1.5991345643997192e+00
    phi[5,6]  R2765     -3.2730693817138672e+00
    phi[5,6]  R2766     -4.6830692887306213e-01
    phi[5,6]  R2767     9.8743689060211182e-01
    phi[5,6]  R2768     -8.4336519241333008e-01
    phi[5,6]  R2769     2.4134533405303955e+00
    phi[5,6]  R2770     -7.4234205484390259e-01
    phi[5,6]  R2771     3.3050251007080078e-01
    phi[5,6]  R2772     1.1298936605453491e+00
    phi[5,6]  R2773     1.7137253284454346e+00
    phi[5,6]  R2774     -4.0233942866325378e-01
    phi[5,6]  R2775     0.582848072052002
    phi[5,6]  R2776     -1.7573174238204956e+00
    phi[5,6]  R2777     -3.8639216423034668e+00
    phi[5,6]  R2778     -1.0604963302612305e+00
    phi[5,6]  R2779     -9.3738555908203125e-01
    phi[5,6]  R2780     1.2641808390617371e-01
    phi[5,6]  R2781     1.5678017139434814e+00
    phi[5,6]  R2782     1.1833475828170776e+00
    phi[5,6]  R2783     -3.2950100898742676e+00
    phi[5,6]  R2784     -2.5938773155212402e+00
    phi[5,6]  R2785     -2.8689846992492676e+00
    phi[5,6]  R2786     -3.3586139678955078e+00
    phi[5,6]  R2787     -3.4290775656700134e-01
    phi[5,6]  R2788     7.6658993959426880e-02
    phi[5,6]  R2789     1.6971069574356079e+00
    phi[5,6]  R2790     1.1999979019165039e+00
    phi[5,6]  R2791     -3.2554969787597656e+00
    phi[5,6]  R2792     -2.0682649612426758e+00
    phi[5,6]  R2793     -1.8494064807891846e+00
    phi[5,6]  R2794     -3.7303090095520020e+00
    phi[5,6]  R2795     4.8862797021865845e-01
    phi[5,6]  R2796     -1.1611957550048828e+00
    phi[5,6]  R2797     1.8736764192581177e+00
    phi[5,6]  R2798     2.6591706275939941e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2799     -3.0999999046325684e+00
    phi[6,5]  R2800     -3.0999999046325684e+00
    phi[6,5]  R2801     -2.2400000095367432e+00
    phi[6,5]  R2802     -2.2400000095367432e+00
    phi[6,5]  R2803     -3.0999999046325684e+00
    phi[6,5]  R2804     -3.0999999046325684e+00
    phi[6,5]  R2805     -2.5699999332427979e+00
    phi[6,5]  R2806     -2.5699999332427979e+00
    phi[6,5]  R2807     -3.0999999046325684e+00
    phi[6,5]  R2808     -3.0999999046325684e+00
    phi[6,5]  R2809     -2.0899999141693115e+00
    phi[6,5]  R2810     -2.0899999141693115e+00
    phi[6,5]  R2811     -3.0999999046325684e+00
    phi[6,5]  R2812     -3.0999999046325684e+00
    phi[6,5]  R2813     2.6976850032806396e+00
    phi[6,5]  R2814     0.0649002343416214
    phi[6,5]  R2815     1.4660350084304810e+00
    phi[6,5]  R2816     1.6225330829620361e+00
    phi[6,5]  R2817     -1.4243797063827515e+00
    phi[6,5]  R2818     1.1959240436553955e+00
    phi[6,5]  R2819     2.5323469638824463e+00
    phi[6,5]  R2820     -7.2055578231811523e-01
    phi[6,5]  R2821     7.6183575391769409e-01
    phi[6,5]  R2822     1.4031524658203125e+00
    phi[6,5]  R2823     -6.8570256233215332e-01
    phi[6,5]  R2824     1.1997667551040649e+00
    phi[6,5]  R2825     -1.7051937580108643e+00
    phi[6,5]  R2826     -5.6683665513992310e-01
    phi[6,5]  R2827     -1.1315454244613647e+00
    phi[6,5]  R2828     -6.9839775562286377e-01
    phi[6,5]  R2829     1.9077036380767822e+00
    phi[6,5]  R2830     -7.7044510841369629e-01
    phi[6,5]  R2831     -1.7779903113842010e-01
    phi[6,5]  R2832     5.8586782217025757e-01
    phi[6,5]  R2833     -1.1418428421020508e+00
    phi[6,5]  R2834     -1.5784937143325806e+00
    phi[6,5]  R2835     -1.2711124420166016e+00
    phi[6,5]  R2836     -1.5991345643997192e+00
    phi[6,5]  R2837     -3.2730693817138672e+00
    phi[6,5]  R2838     -4.6830692887306213e-01
    phi[6,5]  R2839     9.8743689060211182e-01
    phi[6,5]  R2840     -8.4336519241333008e-01
    phi[6,5]  R2841     2.4134533405303955e+00
    phi[6,5]  R2842     -7.4234205484390259e-01
    phi[6,5]  R2843     3.3050251007080078e-01
    phi[6,5]  R2844     1.1298936605453491e+00
    phi[6,5]  R2845     1.7137253284454346e+00
    phi[6,5]  R2846     -4.0233942866325378e-01
    phi[6,5]  R2847     0.582848072052002
    phi[6,5]  R2848     -1.7573174238204956e+00
    phi[6,5]  R2849     -3.8639216423034668e+00
    phi[6,5]  R2850     -1.0604963302612305e+00
    phi[6,5]  R2851     -9.3738555908203125e-01
    phi[6,5]  R2852     1.2641808390617371e-01
    phi[6,5]  R2853     1.5678017139434814e+00
    phi[6,5]  R2854     1.1833475828170776e+00
    phi[6,5]  R2855     -3.2950100898742676e+00
    phi[6,5]  R2856     -2.5938773155212402e+00
    phi[6,5]  R2857     -2.8689846992492676e+00
    phi[6,5]  R2858     -3.3586139678955078e+00
    phi[6,5]  R2859     -3.4290775656700134e-01
    phi[6,5]  R2860     7.6658993959426880e-02
    phi[6,5]  R2861     1.6971069574356079e+00
    phi[6,5]  R2862     1.1999979019165039e+00
    phi[6,5]  R2863     -3.2554969787597656e+00
    phi[6,5]  R2864     -2.0682649612426758e+00
    phi[6,5]  R2865     -1.8494064807891846e+00
    phi[6,5]  R2866     -3.7303090095520020e+00
    phi[6,5]  R2867     4.8862797021865845e-01
    phi[6,5]  R2868     -1.1611957550048828e+00
    phi[6,5]  R2869     1.8736764192581177e+00
    phi[6,5]  R2870     2.6591706275939941e+00
    phi[6,5]  R2871     7.4282556772232056e-01
    phi[6,5]  R2872     2.9529479146003723e-01
    phi[6,5]  R2873     1.1315840482711792e+00
    phi[6,5]  R2874     4.4400626420974731e-01
    phi[6,5]  R2875     -6.2369279563426971e-02
    phi[6,5]  R2876     8.0027955770492554e-01
    phi[6,5]  R2877     5.8231145143508911e-01
    phi[6,5]  R2878     0.707918107509613
    phi[6,5]  R2879     1.4931190013885498e+00
    phi[6,5]  R2880     -7.5401759147644043e-01
    phi[6,5]  R2881     -6.9086164236068726e-01
    phi[6,5]  R2882     -1.6924331188201904e+00
    phi[6,5]  R2883     -2.3630063533782959e+00
    phi[6,5]  R2884     -2.3373171687126160e-01
    phi[6,5]  R2885     8.4866231679916382e-01
    phi[6,5]  R2886     1.0191968083381653e-01
    phi[6,5]  R2887     -8.9570456743240356e-01
    phi[6,5]  R2888     -1.2557879090309143e-01
    phi[6,5]  R2889     -2.5273486971855164e-01
    phi[6,5]  R2890     -2.1915815770626068e-01
    phi[6,5]  R2891     -2.1859364509582520e+00
    phi[6,5]  R2892     1.7728338241577148e+00
    phi[6,5]  R2893     -1.6886414289474487e+00
    phi[6,5]  R2894     -1.3068474531173706e+00
    phi[6,5]  R2895     -3.3660628795623779e+00
    phi[6,5]  R2896     -2.1086461544036865e+00
    phi[6,5]  R2897     -1.8140971660614014e+00
    phi[6,5]  R2898     -2.83530855178833
    phi[6,5]  R2899     -2.9731068611145020e+00
    phi[6,5]  R2900     -2.5195360183715820e+00
    phi[6,5]  R2901     -6.9067078828811646e-01
    phi[6,5]  R2902     -2.1897029876708984e+00
    phi[6,5]  R2903     -4.0695637464523315e-01
    phi[6,5]  R2904     -2.0363402366638184e+00
    phi[6,5]  R2905     5.6539326906204224e-01
    phi[6,5]  R2906     5.2155834436416626e-01
    phi[6,5]  R2907     9.5216894149780273e-01
    phi[6,5]  R2908     -0.985035240650177
    phi[6,5]  R2909     3.3206190913915634e-02
    phi[6,5]  R2910     2.0095043182373047e+00
    phi[6,5]  R2911     -3.2473711967468262e+00
    phi[6,5]  R2912     1.0882055759429932e+00
    phi[6,5]  R2913     2.2832448482513428e+00
    phi[6,5]  R2914     7.0544868707656860e-01
    phi[6,5]  R2915     1.1342386007308960e+00
    phi[6,5]  R2916     -1.6827241182327271e+00
    phi[6,5]  R2917     -3.2920449972152710e-01
    phi[6,5]  R2918     5.2749556303024292e-01
    phi[6,5]  R2919     2.0337255001068115e+00
    phi[6,5]  R2920     1.16041100025177
    phi[6,8]  R54       1
    phi[6,8]  R55       1
    phi[6,8]  R56       3.0220562801228108e+00
    phi[6,8]  R57       8.9888316693691483e-01
    phi[6,8]  R58       2.8887315014679698e+00
    phi[6,8]  R59       2.2444807554349677e+00
    phi[6,8]  R60       2.2469849340023949e+00
    phi[6,8]  R61       1.6802018745846223e+00
    phi[6,8]  R62       1.3806192528410679e+00
    phi[6,8]  R64       -1
    phi[6,8]  R2921     -7.7943624509757559e-02
    phi[6,8]  R2922     -6.12205618475538
    phi[6,8]  R2923     -1.3411168425998283e+00
    phi[6,8]  R2924     -3.1388831764736578e+00
    phi[6,8]  R2925     -2.1126840316459861e-01
    phi[6,8]  R2926     -5.9887314061005377e+00
    phi[6,8]  R2927     -3.2551917780783013e-01
    phi[6,8]  R2928     -4.8144806886777651e+00
    phi[6,8]  R2929     -8.5301497063017351e-01
    phi[6,8]  R2930     -5.3469848386349632e+00
    phi[6,8]  R2931     -4.0979803958468919e-01
    phi[6,8]  R2932     -3.7702017887539339e+00
    phi[6,8]  R2933     -1.7193806517915005e+00
    phi[6,8]  R2934     -4.4806191574736367e+00
    phi[6,8]  R2935     -1.1861773708872558e-01
    phi[6,8]  R2936     -1.2077866004026716e-01
    phi[6,8]  R2937     -1.3233164076004411e-01
    phi[6,8]  R2938     -1.8957203740544393e-01
    phi[6,8]  R2939     -1.9634843838929061e-01
    phi[6,8]  R2940     -9.5514380872420235e-01
    phi[6,8]  R2941     -3.6978298429270895e-01
    phi[6,8]  R2942     -4.1377086877624625e-01
    phi[6,8]  R2943     -4.2188759333156867e-01
    phi[6,8]  R2944     -1.4110160339920674e+00
    phi[6,8]  R2945     -1.8599556521518690e-01
    phi[6,8]  R2946     -1.9217967027299765e-01
    phi[6,8]  R2947     -1.9410497288083683e-01
    phi[6,8]  R2948     -0.231308768517395
    phi[6,8]  R2949     -2.6377126405233553e-01
    phi[6,8]  R2950     -2.6517802410431879e-01
    phi[6,8]  R2951     -2.7943202981235515e-01
    phi[6,8]  R2952     -2.8498699543166917e-01
    phi[6,8]  R2953     -0.291777750369695
    phi[6,8]  R2954     -2.9250819193180466e-01
    phi[6,8]  R2955     -1.1008831988236767e-01
    phi[6,8]  R2956     -1.4225422190958814e-01
    phi[6,8]  R2957     -1.4493128428608038e-01
    phi[6,8]  R2958     -1.6956657490925631e-01
    phi[6,8]  R2959     -1.7149003054784906e-01
    phi[6,8]  R2960     -1.8387890970894455e-01
    phi[6,8]  R2961     -2.1807764296343080e-01
    phi[6,8]  R2962     -2.3701880591866731e-01
    phi[6,8]  R2963     -2.3781763551497592e-01
    phi[6,8]  R2964     -2.3918209097980725e-01
    phi[6,8]  R2965     -8.6155027439762832e-02
    phi[6,8]  R2966     -1.2628004602696685e-01
    phi[6,8]  R2967     -1.4004515707119003e-01
    phi[6,8]  R2968     -1.8733678360057571e-01
    phi[6,8]  R2969     -2.0575947633326608e-01
    phi[6,8]  R2970     -2.0985953177251337e-01
    phi[6,8]  R2971     -2.1193126445009813e-01
    phi[6,8]  R2972     -2.6186827191908812e-01
    phi[6,8]  R2973     -2.6655042537519946e-01
    phi[6,8]  R2974     -2.6824804552114251e-01
    phi[6,8]  R2975     -1.2341792799981577e-01
    phi[6,8]  R2976     -1.6407218433637927e-01
    phi[6,8]  R2977     -1.8962178512847316e-01
    phi[6,8]  R2978     -2.1795772726297802e-01
    phi[6,8]  R2979     -2.2678513775615805e-01
    phi[6,8]  R2980     -2.3621413157725657e-01
    phi[6,8]  R2981     -2.4973896801276557e-01
    phi[6,8]  R2982     -2.7139994337336087e-01
    phi[6,8]  R2983     -2.8898091039326257e-01
    phi[6,8]  R2984     -2.9238702411309836e-01
    phi[6,8]  R2985     -1.6111327177652779e-01
    phi[6,8]  R2986     -1.6544861284582257e-01
    phi[6,8]  R2987     -1.8480927090281440e-01
    phi[6,8]  R2988     -1.8777470362307280e-01
    phi[6,8]  R2989     -2.2072804633368648e-01
    phi[6,8]  R2990     -2.2437197860684388e-01
    phi[6,8]  R2991     -2.0315948082026161e+00
    phi[6,8]  R2992     -2.0112885041282347e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R65       -1
    z[0,1,0]  R66       1
    z[0,1,0]  R79       2.3218529298901558e-02
    z[0,1,0]  R80       2.6585500687360764e-02
    z[0,1,0]  R81       7.1294128894805908e-02
    z[0,1,0]  R82       -2.7335685491561890e-01
    z[0,1,0]  R83       3.5928568243980408e-01
    z[0,1,0]  R84       5.9883729554712772e-03
    z[0,1,0]  R85       9.2439334839582443e-03
    z[0,1,0]  R86       -5.6336027383804321e-01
    z[0,1,0]  R87       4.0163779258728027e-01
    z[0,1,0]  R88       3.0317434668540955e-01
    z[0,1,0]  R89       7.8471505641937256e-01
    z[0,1,0]  R90       0.381783664226532
    z[0,1,0]  R91       3.5267886519432068e-01
    z[0,1,0]  R92       2.9792514443397522e-01
    z[0,1,0]  R93       0.076849564909935
    z[0,1,0]  R94       -1.4367805421352386e-01
    z[0,1,0]  R95       -6.4512050151824951e-01
    z[0,1,0]  R96       -1.4328041672706604e-01
    z[0,1,0]  R97       -3.8182201981544495e-01
    z[0,1,0]  R98       8.9524544775485992e-02
    z[0,1,0]  R99       1.5060995519161224e-01
    z[0,1,0]  R100      3.7041693925857544e-01
    z[0,1,0]  R101      2.2597697377204895e-01
    z[0,1,0]  R102      0.567455530166626
    z[0,1,0]  R103      1.5902924537658691e-01
    z[0,1,0]  R104      4.2210280895233154e-01
    z[0,1,0]  R105      -8.5973076522350311e-02
    z[0,1,0]  R106      2.6575249433517456e-01
    z[0,1,0]  R107      5.2248769998550415e-01
    z[0,1,0]  R108      6.5832680463790894e-01
    z[0,1,0]  R109      3.6908453702926636e-01
    z[0,1,0]  R110      4.6946355700492859e-01
    z[0,1,0]  R111      5.7255238294601440e-01
    z[0,1,0]  R112      4.2565661668777466e-01
    z[0,1,0]  R113      1.0079831629991531e-01
    z[0,1,0]  R114      2.0305563509464264e-01
    z[0,1,0]  R115      5.4893147945404053e-01
    z[0,1,0]  R116      -5.2610252052545547e-02
    z[0,1,0]  R117      2.1409960091114044e-01
    z[0,1,0]  R118      4.1114953160285950e-01
    z[0,1,0]  R119      5.8458864688873291e-01
    z[0,1,0]  R120      3.7280049920082092e-01
    z[0,1,0]  R121      2.8200241923332214e-01
    z[0,1,0]  R122      -4.1353516280651093e-02
    z[0,1,0]  R123      -3.7106537818908691e-01
    z[0,1,0]  R124      1.2341576069593430e-01
    z[0,1,0]  R125      -2.1269651129841805e-02
    z[0,1,0]  R126      -4.4928431510925293e-01
    z[0,1,0]  R127      -5.3979802131652832e-01
    z[0,1,0]  R128      -3.9149722456932068e-01
    z[0,1,0]  R129      -2.3927323520183563e-01
    z[0,1,0]  R130      -9.3068093061447144e-02
    z[0,1,0]  R131      -1.8396428227424622e-01
    z[0,1,0]  R132      1.1003871262073517e-01
    z[0,1,0]  R133      -4.2539175599813461e-02
    z[0,1,0]  R134      -3.0694505572319031e-01
    z[0,1,0]  R135      2.3849646747112274e-01
    z[0,1,0]  R136      -2.5389662384986877e-01
    z[0,1,0]  R137      -3.2029229402542114e-01
    z[0,1,0]  R138      -1.6619090735912323e-01
    z[0,1,0]  R139      6.6466385126113892e-01
    z[0,1,0]  R140      -4.7198975086212158e-01
    z[0,1,0]  R141      -7.8905403614044189e-01
    z[0,1,0]  R142      -0.89189612865448
    z[0,1,0]  R143      -3.1033545732498169e-01
    z[0,1,0]  R144      -5.1954627037048340e-01
    z[0,1,0]  R145      -3.0689609050750732e-01
    z[0,1,0]  R146      3.9101323485374451e-01
    z[0,1,0]  R147      -2.4056018888950348e-01
    z[0,1,0]  R148      -2.3183842003345490e-01
    z[0,1,0]  R149      3.5448500514030457e-01
    z[0,1,0]  R150      1.2213188409805298e-01
    z[0,1,0]  R151      4.4516941905021667e-01
    z[0,1,0]  R152      7.5336650013923645e-02
    z[0,1,0]  R153      2.0835784077644348e-01
    z[0,1,0]  R154      3.7897145748138428e-01
    z[0,1,0]  R155      -2.0715612173080444e-01
    z[0,1,0]  R156      6.3558273017406464e-02
    z[0,1,0]  R157      1.4043904957361519e-04
    z[0,1,0]  R158      -5.2889108657836914e-01
    z[0,1,0]  R159      0.124534472823143
    z[0,1,0]  R160      3.2512968778610229e-01
    z[0,1,0]  R161      1.2217810004949570e-01
    z[0,1,0]  R162      -0.0638943687081337
    z[0,1,0]  R163      3.9143315516412258e-03
    z[0,1,0]  R164      -5.3495984524488449e-02
    z[0,1,0]  R165      -6.1061024665832520e-01
    z[0,1,0]  R166      -3.2372646033763885e-02
    z[0,1,0]  R167      -1.4620240032672882e-01
    z[0,1,0]  R168      -5.6994175910949707e-01
    z[0,1,0]  R169      5.4328281432390213e-02
    z[0,1,0]  R170      -7.7049273252487183e-01
    z[0,1,0]  R171      -3.6872324347496033e-01
    z[0,1,0]  R172      -3.8276901841163635e-01
    z[0,1,0]  R173      -0.460308313369751
    z[0,1,0]  R174      -3.8408553600311279e-01
    z[0,1,0]  R175      5.7115048170089722e-01
    z[0,1,0]  R176      -2.7225458621978760e-01
    z[0,1,0]  R177      5.5754220485687256e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R67       -1
    z[0,1,1]  R68       1
    z[0,1,1]  R79       -6.9088816642761230e-01
    z[0,1,1]  R80       -8.2758784294128418e-01
    z[0,1,1]  R81       -5.2705746889114380e-01
    z[0,1,1]  R82       -8.5353112220764160e-01
    z[0,1,1]  R83       -7.9864984750747681e-01
    z[0,1,1]  R84       -9.2099231481552124e-01
    z[0,1,1]  R85       -5.0414168834686279e-01
    z[0,1,1]  R86       -7.7416580915451050e-01
    z[0,1,1]  R87       -8.3415180444717407e-01
    z[0,1,1]  R88       4.2863461375236511e-01
    z[0,1,1]  R89       5.2385592460632324e-01
    z[0,1,1]  R90       7.7788054943084717e-01
    z[0,1,1]  R91       5.1039779186248779e-01
    z[0,1,1]  R92       0.782328724861145
    z[0,1,1]  R93       9.3017423152923584e-01
    z[0,1,1]  R94       7.4598878622055054e-01
    z[0,1,1]  R95       6.2384688854217529e-01
    z[0,1,1]  R96       9.0567612648010254e-01
    z[0,1,1]  R97       8.4035253524780273e-01
    z[0,1,1]  R98       7.2656100988388062e-01
    z[0,1,1]  R99       0.54316645860672
    z[0,1,1]  R100      8.2122975587844849e-01
    z[0,1,1]  R101      3.5193365812301636e-01
    z[0,1,1]  R102      2.6572963595390320e-01
    z[0,1,1]  R103      6.3096469640731812e-01
    z[0,1,1]  R104      3.6601129174232483e-01
    z[0,1,1]  R105      5.9211635589599609e-01
    z[0,1,1]  R106      3.8181629776954651e-01
    z[0,1,1]  R107      3.8341113924980164e-01
    z[0,1,1]  R108      4.8087698221206665e-01
    z[0,1,1]  R109      7.4802255630493164e-01
    z[0,1,1]  R110      0.600898265838623
    z[0,1,1]  R111      3.2104572653770447e-01
    z[0,1,1]  R112      5.1311117410659790e-01
    z[0,1,1]  R113      0.793482780456543
    z[0,1,1]  R114      4.4519197940826416e-01
    z[0,1,1]  R115      -1.3799582421779633e-01
    z[0,1,1]  R116      -0.605397641658783
    z[0,1,1]  R117      5.4583203792572021e-01
    z[0,1,1]  R118      6.9718170166015625e-01
    z[0,1,1]  R119      4.2258173227310181e-01
    z[0,1,1]  R120      6.1684954166412354e-01
    z[0,1,1]  R121      -5.7018172740936279e-01
    z[0,1,1]  R122      1.1039377748966217e-01
    z[0,1,1]  R123      8.6186027526855469e-01
    z[0,1,1]  R124      5.7072877883911133e-01
    z[0,1,1]  R125      8.6363697052001953e-01
    z[0,1,1]  R126      7.0416003465652466e-01
    z[0,1,1]  R127      1.4872631430625916e-01
    z[0,1,1]  R128      3.2680952548980713e-01
    z[0,1,1]  R129      -2.3412662744522095e-01
    z[0,1,1]  R130      -3.2256475090980530e-01
    z[0,1,1]  R131      -3.6999046802520752e-01
    z[0,1,1]  R132      -5.2285623550415039e-01
    z[0,1,1]  R133      -4.6815851330757141e-01
    z[0,1,1]  R134      -4.2803874611854553e-01
    z[0,1,1]  R135      -7.1605294942855835e-01
    z[0,1,1]  R136      6.4604789018630981e-01
    z[0,1,1]  R137      8.5382020473480225e-01
    z[0,1,1]  R138      8.7410008907318115e-01
    z[0,1,1]  R139      -2.1206778287887573e-01
    z[0,1,1]  R140      5.5650299787521362e-01
    z[0,1,1]  R141      2.7068966627120972e-01
    z[0,1,1]  R142      2.0389008522033691e-01
    z[0,1,1]  R143      2.8315299749374390e-01
    z[0,1,1]  R144      3.0223432183265686e-01
    z[0,1,1]  R145      -1.4377743005752563e-01
    z[0,1,1]  R146      -2.0649042725563049e-01
    z[0,1,1]  R147      8.2114261388778687e-01
    z[0,1,1]  R148      7.1400213241577148e-01
    z[0,1,1]  R149      -3.3164060115814209e-01
    z[0,1,1]  R150      -1.8140999972820282e-01
    z[0,1,1]  R151      -5.1794147491455078e-01
    z[0,1,1]  R152      -5.0821495056152344e-01
    z[0,1,1]  R153      -6.5732920169830322e-01
    z[0,1,1]  R154      -5.3367048501968384e-01
    z[0,1,1]  R155      -5.9342402219772339e-01
    z[0,1,1]  R156      2.9371902346611023e-01
    z[0,1,1]  R157      3.0722531676292419e-01
    z[0,1,1]  R158      7.0174783468246460e-01
    z[0,1,1]  R159      -5.3573852777481079e-01
    z[0,1,1]  R160      -7.3988282680511475e-01
    z[0,1,1]  R161      -1.4559482038021088e-01
    z[0,1,1]  R162      -6.6544854640960693e-01
    z[0,1,1]  R163      2.6029470562934875e-01
    z[0,1,1]  R164      0.684913694858551
    z[0,1,1]  R165      5.3332304954528809e-01
    z[0,1,1]  R166      7.8472161293029785e-01
    z[0,1,1]  R167      8.9037430286407471e-01
    z[0,1,1]  R168      0.710384726524353
    z[0,1,1]  R169      -4.5226737856864929e-01
    z[0,1,1]  R170      2.4580633640289307e-01
    z[0,1,1]  R171      6.3817453384399414e-01
    z[0,1,1]  R172      -5.0469082593917847e-01
    z[0,1,1]  R173      7.7087897062301636e-01
    z[0,1,1]  R174      7.6046824455261230e-01
    z[0,1,1]  R175      7.8955745697021484e-01
    z[0,1,1]  R176      2.1833692491054535e-01
    z[0,1,1]  R177      7.0232802629470825e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R69       -1
    z[0,1,2]  R70       1
    z[0,1,2]  R79       -7.5585119426250458e-02
    z[0,1,2]  R80       2.4415375292301178e-01
    z[0,1,2]  R81       6.4707857370376587e-01
    z[0,1,2]  R82       2.7240115404129028e-01
    z[0,1,2]  R83       1.0018160194158554e-01
    z[0,1,2]  R84       -1.0218521207571030e-01
    z[0,1,2]  R85       4.6498867869377136e-01
    z[0,1,2]  R86       1.6942533850669861e-01
    z[0,1,2]  R87       -3.0455809831619263e-01
    z[0,1,2]  R88       3.7516161799430847e-01
    z[0,1,2]  R89       1.5947189927101135e-01
    z[0,1,2]  R90       -2.3742966353893280e-01
    z[0,1,2]  R91       4.0666827559471130e-01
    z[0,1,2]  R92       5.1089294254779816e-02
    z[0,1,2]  R93       -2.0245976746082306e-01
    z[0,1,2]  R94       4.5116788148880005e-01
    z[0,1,2]  R95       3.1718626618385315e-01
    z[0,1,2]  R96       -2.2297109663486481e-01
    z[0,1,2]  R97       1.5814979374408722e-01
    z[0,1,2]  R98       -1.4584209024906158e-01
    z[0,1,2]  R99       -4.3707605451345444e-02
    z[0,1,2]  R100      -9.2976361513137817e-02
    z[0,1,2]  R101      -4.3287232518196106e-01
    z[0,1,2]  R102      -1.6613063216209412e-01
    z[0,1,2]  R103      1.5279665589332581e-01
    z[0,1,2]  R104      2.2173093259334564e-01
    z[0,1,2]  R105      -2.2127854824066162e-01
    z[0,1,2]  R106      -1.9176118075847626e-02
    z[0,1,2]  R107      -1.9215150177478790e-01
    z[0,1,2]  R108      -4.6588137745857239e-01
    z[0,1,2]  R109      3.6818632483482361e-01
    z[0,1,2]  R110      1.9580742716789246e-01
    z[0,1,2]  R111      2.5650796294212341e-01
    z[0,1,2]  R112      4.0598914027214050e-01
    z[0,1,2]  R113      5.2883196622133255e-02
    z[0,1,2]  R114      1.0428345762193203e-02
    z[0,1,2]  R115      -1.7387193441390991e-01
    z[0,1,2]  R116      -4.5069187879562378e-01
    z[0,1,2]  R117      0.118861123919487
    z[0,1,2]  R118      4.8090755008161068e-03
    z[0,1,2]  R119      -1.7562119662761688e-01
    z[0,1,2]  R120      -3.9228554815053940e-02
    z[0,1,2]  R121      -5.5179435014724731e-01
    z[0,1,2]  R122      3.6836430430412292e-02
    z[0,1,2]  R123      1.0536435991525650e-01
    z[0,1,2]  R124      -3.7455025315284729e-01
    z[0,1,2]  R125      2.1165508031845093e-01
    z[0,1,2]  R126      2.3400449752807617e-01
    z[0,1,2]  R127      2.4168847501277924e-01
    z[0,1,2]  R128      6.5540504455566406e-01
    z[0,1,2]  R129      7.8288090229034424e-01
    z[0,1,2]  R130      6.9121789932250977e-01
    z[0,1,2]  R131      2.7046054601669312e-01
    z[0,1,2]  R132      -9.0173922479152679e-02
    z[0,1,2]  R133      0.612095057964325
    z[0,1,2]  R134      4.0137669444084167e-01
    z[0,1,2]  R135      -2.8709178790450096e-02
    z[0,1,2]  R136      -3.5165694355964661e-01
    z[0,1,2]  R137      7.7848076820373535e-02
    z[0,1,2]  R138      -2.6500681042671204e-01
    z[0,1,2]  R139      -1.8514315783977509e-01
    z[0,1,2]  R140      5.4202932119369507e-01
    z[0,1,2]  R141      -1.2013711780309677e-01
    z[0,1,2]  R142      3.0058783292770386e-01
    z[0,1,2]  R143      -3.3320057392120361e-01
    z[0,1,2]  R144      -2.3354759812355042e-01
    z[0,1,2]  R145      -2.6625505089759827e-01
    z[0,1,2]  R146      2.5235649943351746e-01
    z[0,1,2]  R147      -1.5740875899791718e-01
    z[0,1,2]  R148      2.9138955473899841e-01
    z[0,1,2]  R149      2.7108547091484070e-01
    z[0,1,2]  R150      4.9036440253257751e-01
    z[0,1,2]  R151      3.1304258108139038e-01
    z[0,1,2]  R152      3.3663868904113770e-01
    z[0,1,2]  R153      -2.5620761513710022e-01
    z[0,1,2]  R154      -3.8797748088836670e-01
    z[0,1,2]  R155      -1.6617652773857117e-01
    z[0,1,2]  R156      5.5452769994735718e-01
    z[0,1,2]  R157      5.9412352740764618e-02
    z[0,1,2]  R158      2.2869819402694702e-01
    z[0,1,2]  R159      7.1511673927307129e-01
    z[0,1,2]  R160      -2.6457920670509338e-01
    z[0,1,2]  R161      4.2584562301635742e-01
    z[0,1,2]  R162      -1.1458848416805267e-01
    z[0,1,2]  R163      -6.1519676446914673e-01
    z[0,1,2]  R164      -1.7192934453487396e-01
    z[0,1,2]  R165      -2.2272443771362305e-01
    z[0,1,2]  R166      -2.4329580366611481e-01
    z[0,1,2]  R167      -2.7469378709793091e-01
    z[0,1,2]  R168      1.3224802911281586e-02
    z[0,1,2]  R169      -1.1340240389108658e-01
    z[0,1,2]  R170      3.0671819113194942e-03
    z[0,1,2]  R171      5.8155737817287445e-02
    z[0,1,2]  R172      2.9615920782089233e-01
    z[0,1,2]  R173      -0.0243210606276989
    z[0,1,2]  R174      -3.4894734621047974e-01
    z[0,1,2]  R175      -1.1464491486549377e-01
    z[0,1,2]  R176      -6.2834733724594116e-01
    z[0,1,2]  R177      -2.8288549184799194e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R71       -1
    z[0,1,3]  R72       1
    z[0,1,3]  R79       -6.0313421487808228e-01
    z[0,1,3]  R80       -2.6426699757575989e-01
    z[0,1,3]  R81       -4.0811866521835327e-01
    z[0,1,3]  R82       -1.8318356946110725e-02
    z[0,1,3]  R83       -3.3026996254920959e-01
    z[0,1,3]  R84       6.8596608936786652e-02
    z[0,1,3]  R85       -4.8660203814506531e-01
    z[0,1,3]  R86       2.5030849501490593e-02
    z[0,1,3]  R87       1.7117737233638763e-01
    z[0,1,3]  R88       6.2525969743728638e-01
    z[0,1,3]  R89       -2.2083206474781036e-01
    z[0,1,3]  R90       -1.8068033456802368e-01
    z[0,1,3]  R91       1.0851048678159714e-01
    z[0,1,3]  R92       -9.9475458264350891e-02
    z[0,1,3]  R93       -2.8459498286247253e-01
    z[0,1,3]  R94       -0.405542254447937
    z[0,1,3]  R95       0.0989881381392479
    z[0,1,3]  R96       -1.9643209874629974e-02
    z[0,1,3]  R97       -2.3548056185245514e-01
    z[0,1,3]  R98       -4.4133788347244263e-01
    z[0,1,3]  R99       5.6281000375747681e-01
    z[0,1,3]  R100      1.4149080216884613e-01
    z[0,1,3]  R101      7.3939192295074463e-01
    z[0,1,3]  R102      5.2539533376693726e-01
    z[0,1,3]  R103      1.8167947232723236e-01
    z[0,1,3]  R104      2.4998384714126587e-01
    z[0,1,3]  R105      4.9449887871742249e-01
    z[0,1,3]  R106      6.6805613040924072e-01
    z[0,1,3]  R107      5.3257602453231812e-01
    z[0,1,3]  R108      3.0099043250083923e-01
    z[0,1,3]  R109      1.6139744222164154e-01
    z[0,1,3]  R110      2.4999523162841797e-01
    z[0,1,3]  R111      3.2812726497650146e-01
    z[0,1,3]  R112      4.9095913767814636e-01
    z[0,1,3]  R113      4.9335297942161560e-01
    z[0,1,3]  R114      0.771373450756073
    z[0,1,3]  R115      -6.1114239692687988e-01
    z[0,1,3]  R116      -3.4578660130500793e-01
    z[0,1,3]  R117      6.4186424016952515e-01
    z[0,1,3]  R118      6.5114744007587433e-02
    z[0,1,3]  R119      3.3785501122474670e-01
    z[0,1,3]  R120      5.6813359260559082e-01
    z[0,1,3]  R121      -3.4559237957000732e-01
    z[0,1,3]  R122      -7.2367310523986816e-01
    z[0,1,3]  R123      2.1732898056507111e-01
    z[0,1,3]  R124      3.1666469573974609e-01
    z[0,1,3]  R125      -1.6486048698425293e-01
    z[0,1,3]  R126      -1.4926570653915405e-01
    z[0,1,3]  R127      -7.3794215917587280e-01
    z[0,1,3]  R128      -4.1002565622329712e-01
    z[0,1,3]  R129      -1.3675062358379364e-01
    z[0,1,3]  R130      -1.2978547811508179e-01
    z[0,1,3]  R131      -2.1833953261375427e-01
    z[0,1,3]  R132      -0.192160502076149
    z[0,1,3]  R133      2.3703585565090179e-01
    z[0,1,3]  R134      1.8773065507411957e-01
    z[0,1,3]  R135      4.6362329274415970e-02
    z[0,1,3]  R136      -1.2510886788368225e-01
    z[0,1,3]  R137      -1.6061370074748993e-01
    z[0,1,3]  R138      -2.4646823108196259e-01
    z[0,1,3]  R139      -6.7244774103164673e-01
    z[0,1,3]  R140      -3.4394088387489319e-01
    z[0,1,3]  R141      1.5020883083343506e-01
    z[0,1,3]  R142      1.7196573317050934e-01
    z[0,1,3]  R143      -3.5162393003702164e-02
    z[0,1,3]  R144      -3.5772061347961426e-01
    z[0,1,3]  R145      -0.360651433467865
    z[0,1,3]  R146      1.1904857121407986e-02
    z[0,1,3]  R147      1.0218356549739838e-01
    z[0,1,3]  R148      7.6278068125247955e-02
    z[0,1,3]  R149      -1.2785153090953827e-01
    z[0,1,3]  R150      -3.0141493678092957e-01
    z[0,1,3]  R151      3.7640803493559361e-03
    z[0,1,3]  R152      4.3715375661849976e-01
    z[0,1,3]  R153      5.1293814182281494e-01
    z[0,1,3]  R154      1.5632462501525879e-01
    z[0,1,3]  R155      6.3311499357223511e-01
    z[0,1,3]  R156      -5.8447301387786865e-01
    z[0,1,3]  R157      -2.7181667089462280e-01
    z[0,1,3]  R158      -7.3082715272903442e-02
    z[0,1,3]  R159      -3.0466508865356445e-01
    z[0,1,3]  R160      -1.4586928486824036e-01
    z[0,1,3]  R161      -3.5448685288429260e-01
    z[0,1,3]  R162      5.7399606704711914e-01
    z[0,1,3]  R163      -5.2418279647827148e-01
    z[0,1,3]  R164      -0.277119517326355
    z[0,1,3]  R165      -1.5559767186641693e-01
    z[0,1,3]  R166      -4.8624446988105774e-01
    z[0,1,3]  R167      -1.8034832552075386e-02
    z[0,1,3]  R168      3.2120910286903381e-01
    z[0,1,3]  R169      2.6803153753280640e-01
    z[0,1,3]  R170      -4.8867025971412659e-01
    z[0,1,3]  R171      -7.2287283837795258e-02
    z[0,1,3]  R172      5.6514286994934082e-01
    z[0,1,3]  R173      2.9438361525535583e-01
    z[0,1,3]  R174      8.9321218430995941e-02
    z[0,1,3]  R175      1.5312604606151581e-02
    z[0,1,3]  R176      -0.288524866104126
    z[0,1,3]  R177      0.1168212890625
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R73       -1
    z[0,1,4]  R74       1
    z[0,1,4]  R79       -7.7204527333378792e-03
    z[0,1,4]  R80       4.5496243983507156e-02
    z[0,1,4]  R81       -3.1085941195487976e-01
    z[0,1,4]  R82       -6.0165543109178543e-02
    z[0,1,4]  R83       -1.1988577991724014e-01
    z[0,1,4]  R84       -8.8058109395205975e-04
    z[0,1,4]  R85       -1.5633161365985870e-01
    z[0,1,4]  R86       2.2820717096328735e-01
    z[0,1,4]  R87       -0.0789557546377182
    z[0,1,4]  R88       -3.4042972326278687e-01
    z[0,1,4]  R89       8.3188056945800781e-02
    z[0,1,4]  R90       3.5270789265632629e-01
    z[0,1,4]  R91       0.625708818435669
    z[0,1,4]  R92       4.3101277947425842e-01
    z[0,1,4]  R93       0.0524633526802063
    z[0,1,4]  R94       -8.2717090845108032e-02
    z[0,1,4]  R95       5.2935957908630371e-02
    z[0,1,4]  R96       1.2602145969867706e-01
    z[0,1,4]  R97       4.1201531887054443e-02
    z[0,1,4]  R98       1.8331001698970795e-01
    z[0,1,4]  R99       5.5005115270614624e-01
    z[0,1,4]  R100      -1.6806045174598694e-01
    z[0,1,4]  R101      2.3589572310447693e-01
    z[0,1,4]  R102      5.1857888698577881e-01
    z[0,1,4]  R103      3.3163938671350479e-02
    z[0,1,4]  R104      -3.9490621536970139e-02
    z[0,1,4]  R105      2.5820270180702209e-01
    z[0,1,4]  R106      2.3370358347892761e-01
    z[0,1,4]  R107      -6.8685412406921387e-02
    z[0,1,4]  R108      -1.0905279964208603e-01
    z[0,1,4]  R109      -4.2552232742309570e-02
    z[0,1,4]  R110      4.1010481119155884e-01
    z[0,1,4]  R111      2.1401986479759216e-01
    z[0,1,4]  R112      2.1495439112186432e-01
    z[0,1,4]  R113      2.3247393965721130e-01
    z[0,1,4]  R114      -8.0415733158588409e-02
    z[0,1,4]  R115      4.5572139322757721e-02
    z[0,1,4]  R116      3.4023562073707581e-01
    z[0,1,4]  R117      -1.7753715813159943e-01
    z[0,1,4]  R118      1.1264232546091080e-01
    z[0,1,4]  R119      -1.6377037763595581e-01
    z[0,1,4]  R120      -3.1421598792076111e-01
    z[0,1,4]  R121      2.8071027994155884e-01
    z[0,1,4]  R122      2.8293186426162720e-01
    z[0,1,4]  R123      6.4598284661769867e-02
    z[0,1,4]  R124      2.4649754166603088e-01
    z[0,1,4]  R125      -1.2283524870872498e-01
    z[0,1,4]  R126      2.3887798190116882e-01
    z[0,1,4]  R127      2.6853394508361816e-01
    z[0,1,4]  R128      -4.5189116150140762e-02
    z[0,1,4]  R129      3.7444502115249634e-01
    z[0,1,4]  R130      4.6636760234832764e-01
    z[0,1,4]  R131      7.1435712277889252e-02
    z[0,1,4]  R132      3.0189543962478638e-01
    z[0,1,4]  R133      4.6917036175727844e-01
    z[0,1,4]  R134      -6.2298811972141266e-02
    z[0,1,4]  R135      1.1157064139842987e-01
    z[0,1,4]  R136      1.7434763908386230e-01
    z[0,1,4]  R137      0.265186071395874
    z[0,1,4]  R138      8.1869371235370636e-02
    z[0,1,4]  R139      -0.0295050460845232
    z[0,1,4]  R140      4.1165456175804138e-02
    z[0,1,4]  R141      1.4436149597167969e-01
    z[0,1,4]  R142      -7.9460576176643372e-02
    z[0,1,4]  R143      7.5569534301757812e-01
    z[0,1,4]  R144      -5.1839772611856461e-02
    z[0,1,4]  R145      1.8890835344791412e-01
    z[0,1,4]  R146      -2.3591178655624390e-01
    z[0,1,4]  R147      -3.0672883987426758e-01
    z[0,1,4]  R148      -1.2151244282722473e-01
    z[0,1,4]  R149      -4.5494616031646729e-01
    z[0,1,4]  R150      -5.7108914852142334e-01
    z[0,1,4]  R151      -1.4176666736602783e-01
    z[0,1,4]  R152      -3.3100968599319458e-01
    z[0,1,4]  R153      1.0167949646711349e-01
    z[0,1,4]  R154      -3.1500551104545593e-01
    z[0,1,4]  R155      -2.4191634356975555e-01
    z[0,1,4]  R156      -2.6066654920578003e-01
    z[0,1,4]  R157      4.7065809369087219e-02
    z[0,1,4]  R158      -2.2838643193244934e-01
    z[0,1,4]  R159      -1.7407071590423584e-01
    z[0,1,4]  R160      1.1996034532785416e-01
    z[0,1,4]  R161      3.4921982884407043e-01
    z[0,1,4]  R162      1.6590552031993866e-01
    z[0,1,4]  R163      3.6356106400489807e-01
    z[0,1,4]  R164      0.567359983921051
    z[0,1,4]  R165      -4.1081428527832031e-01
    z[0,1,4]  R166      -2.4256144464015961e-01
    z[0,1,4]  R167      -6.1225313693284988e-02
    z[0,1,4]  R168      -2.1430957317352295e-01
    z[0,1,4]  R169      -3.9447724819183350e-01
    z[0,1,4]  R170      -1.9413267076015472e-01
    z[0,1,4]  R171      5.8033210039138794e-01
    z[0,1,4]  R172      -3.3854478597640991e-01
    z[0,1,4]  R173      -2.6605397462844849e-01
    z[0,1,4]  R174      -1.3745093345642090e-01
    z[0,1,4]  R175      6.3053965568542480e-02
    z[0,1,4]  R176      2.9617384076118469e-01
    z[0,1,4]  R177      1.8876156210899353e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R75       -1
    z[0,1,5]  R76       1
    z[0,1,5]  R79       3.5248550772666931e-01
    z[0,1,5]  R80       -1.8579567968845367e-01
    z[0,1,5]  R81       -1.3986136019229889e-01
    z[0,1,5]  R82       3.4295409917831421e-01
    z[0,1,5]  R83       -3.0872318148612976e-01
    z[0,1,5]  R84       3.6392825841903687e-01
    z[0,1,5]  R85       2.9768466949462891e-01
    z[0,1,5]  R86       -2.5655742734670639e-02
    z[0,1,5]  R87       0.0423213467001915
    z[0,1,5]  R88       -2.7284887433052063e-01
    z[0,1,5]  R89       -1.4773845672607422e-01
    z[0,1,5]  R90       -0.156717449426651
    z[0,1,5]  R91       1.5973153710365295e-01
    z[0,1,5]  R92       2.8820648789405823e-01
    z[0,1,5]  R93       8.1712851533666253e-04
    z[0,1,5]  R94       -4.1467282921075821e-02
    z[0,1,5]  R95       2.6289626955986023e-01
    z[0,1,5]  R96       -1.0409022122621536e-01
    z[0,1,5]  R97       0.084237240254879
    z[0,1,5]  R98       -4.5615535974502563e-01
    z[0,1,5]  R99       -1.3084410130977631e-01
    z[0,1,5]  R100      -2.8830143809318542e-01
    z[0,1,5]  R101      -0.164118230342865
    z[0,1,5]  R102      -1.4126639068126678e-01
    z[0,1,5]  R103      -5.7881736755371094e-01
    z[0,1,5]  R104      -2.4380034208297729e-01
    z[0,1,5]  R105      -4.7147154808044434e-01
    z[0,1,5]  R106      7.7939346432685852e-02
    z[0,1,5]  R107      3.9999324083328247e-01
    z[0,1,5]  R108      -7.4565164744853973e-02
    z[0,1,5]  R109      -3.2411959767341614e-01
    z[0,1,5]  R110      -3.5526511073112488e-01
    z[0,1,5]  R111      -5.4933613538742065e-01
    z[0,1,5]  R112      1.6533279418945312e-01
    z[0,1,5]  R113      2.3109537363052368e-01
    z[0,1,5]  R114      -2.4901962280273438e-01
    z[0,1,5]  R115      -4.3133646249771118e-01
    z[0,1,5]  R116      -3.3600360155105591e-01
    z[0,1,5]  R117      3.9849165081977844e-01
    z[0,1,5]  R118      5.0299203395843506e-01
    z[0,1,5]  R119      -4.7456416487693787e-01
    z[0,1,5]  R120      2.3958018422126770e-01
    z[0,1,5]  R121      -6.1677344143390656e-02
    z[0,1,5]  R122      -4.3604883551597595e-01
    z[0,1,5]  R123      -1.0302336513996124e-01
    z[0,1,5]  R124      -1.4970052242279053e-01
    z[0,1,5]  R125      3.0528476834297180e-01
    z[0,1,5]  R126      -2.1967029571533203e-01
    z[0,1,5]  R127      -7.0856891572475433e-02
    z[0,1,5]  R128      -3.5500779747962952e-01
    z[0,1,5]  R129      1.8587511777877808e-01
    z[0,1,5]  R130      -1.4139805734157562e-01
    z[0,1,5]  R131      4.5469993352890015e-01
    z[0,1,5]  R132      8.6127929389476776e-02
    z[0,1,5]  R133      0.0432896763086319
    z[0,1,5]  R134      7.2182303667068481e-01
    z[0,1,5]  R135      5.4944694042205811e-01
    z[0,1,5]  R136      5.7868117094039917e-01
    z[0,1,5]  R137      -0.176085963845253
    z[0,1,5]  R138      -1.6225415468215942e-01
    z[0,1,5]  R139      -2.5128121487796307e-03
    z[0,1,5]  R140      6.8202703259885311e-03
    z[0,1,5]  R141      2.7587673068046570e-01
    z[0,1,5]  R142      -1.8212584778666496e-02
    z[0,1,5]  R143      3.5121780633926392e-01
    z[0,1,5]  R144      -4.2768475413322449e-01
    z[0,1,5]  R145      1.0120529681444168e-01
    z[0,1,5]  R146      -7.2193038463592529e-01
    z[0,1,5]  R147      -8.1432253122329712e-02
    z[0,1,5]  R148      -1.8198329210281372e-01
    z[0,1,5]  R149      -6.8062287569046021e-01
    z[0,1,5]  R150      -4.0630817413330078e-01
    z[0,1,5]  R151      -4.6032306551933289e-01
    z[0,1,5]  R152      -1.7219726741313934e-01
    z[0,1,5]  R153      -0.430600643157959
    z[0,1,5]  R154      -5.0054562091827393e-01
    z[0,1,5]  R155      5.8270907029509544e-03
    z[0,1,5]  R156      2.9229742288589478e-01
    z[0,1,5]  R157      6.6445773839950562e-01
    z[0,1,5]  R158      2.1083930134773254e-01
    z[0,1,5]  R159      2.4733105301856995e-01
    z[0,1,5]  R160      4.7527906298637390e-01
    z[0,1,5]  R161      5.6023615598678589e-01
    z[0,1,5]  R162      -2.4616421759128571e-01
    z[0,1,5]  R163      3.7608388066291809e-01
    z[0,1,5]  R164      1.9763027131557465e-01
    z[0,1,5]  R165      -3.1555801630020142e-01
    z[0,1,5]  R166      1.6353559494018555e-01
    z[0,1,5]  R167      -1.9240470230579376e-01
    z[0,1,5]  R168      0.129002645611763
    z[0,1,5]  R169      5.4752331972122192e-01
    z[0,1,5]  R170      7.5934166088700294e-03
    z[0,1,5]  R171      3.3185136318206787e-01
    z[0,1,5]  R172      1.9408319890499115e-01
    z[0,1,5]  R173      -1.7621102929115295e-01
    z[0,1,5]  R174      -7.7011808753013611e-02
    z[0,1,5]  R175      -1.5127140283584595e-01
    z[0,1,5]  R176      -4.7354641556739807e-01
    z[0,1,5]  R177      1.2884079478681087e-02
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R77       -1
    z[0,1,6]  R78       1
    z[0,1,6]  R79       -1.6835945844650269e-01
    z[0,1,6]  R80       3.8516694307327271e-01
    z[0,1,6]  R81       -1.2514501810073853e-01
    z[0,1,6]  R82       -3.1389329582452774e-02
    z[0,1,6]  R83       -6.5383620560169220e-02
    z[0,1,6]  R84       6.4385667443275452e-02
    z[0,1,6]  R85       4.2391490936279297e-01
    z[0,1,6]  R86       -3.4991465508937836e-02
    z[0,1,6]  R87       -1.1311710625886917e-01
    z[0,1,6]  R88       -4.8196125775575638e-02
    z[0,1,6]  R89       8.2779310643672943e-02
    z[0,1,6]  R90       0.105648472905159
    z[0,1,6]  R91       1.4468035101890564e-01
    z[0,1,6]  R92       1.3364803791046143e-01
    z[0,1,6]  R93       -6.4286895096302032e-02
    z[0,1,6]  R94       2.1512460708618164e-01
    z[0,1,6]  R95       -1.1096056550741196e-01
    z[0,1,6]  R96       -2.8705963492393494e-01
    z[0,1,6]  R97       -0.242411807179451
    z[0,1,6]  R98       7.9782538115978241e-02
    z[0,1,6]  R99       -2.0963051915168762e-01
    z[0,1,6]  R100      -2.1987858414649963e-01
    z[0,1,6]  R101      -0.091742604970932
    z[0,1,6]  R102      -1.2191002815961838e-01
    z[0,1,6]  R103      4.2908000946044922e-01
    z[0,1,6]  R104      -7.1778148412704468e-01
    z[0,1,6]  R105      2.4404789507389069e-01
    z[0,1,6]  R106      0.525579035282135
    z[0,1,6]  R107      -3.0778363347053528e-01
    z[0,1,6]  R108      1.0134135931730270e-01
    z[0,1,6]  R109      -1.8911491334438324e-01
    z[0,1,6]  R110      1.5260358154773712e-01
    z[0,1,6]  R111      -2.1925979852676392e-01
    z[0,1,6]  R112      2.7590745687484741e-01
    z[0,1,6]  R113      0.0811280682682991
    z[0,1,6]  R114      3.1139880418777466e-01
    z[0,1,6]  R115      2.9627183079719543e-01
    z[0,1,6]  R116      -2.8173670172691345e-01
    z[0,1,6]  R117      -1.9948931038379669e-01
    z[0,1,6]  R118      0.273754358291626
    z[0,1,6]  R119      -2.8750661015510559e-01
    z[0,1,6]  R120      8.4515912458300591e-03
    z[0,1,6]  R121      2.9808378219604492e-01
    z[0,1,6]  R122      4.3686878681182861e-01
    z[0,1,6]  R123      -2.1537633240222931e-01
    z[0,1,6]  R124      0.579052209854126
    z[0,1,6]  R125      2.7095130085945129e-01
    z[0,1,6]  R126      3.4633249044418335e-01
    z[0,1,6]  R127      7.9971216619014740e-02
    z[0,1,6]  R128      -1.1906320601701736e-01
    z[0,1,6]  R129      2.8560683131217957e-01
    z[0,1,6]  R130      3.9391836524009705e-01
    z[0,1,6]  R131      7.0469003915786743e-01
    z[0,1,6]  R132      7.5557726621627808e-01
    z[0,1,6]  R133      -3.5521391034126282e-01
    z[0,1,6]  R134      -3.6219093948602676e-02
    z[0,1,6]  R135      -3.3626472949981689e-01
    z[0,1,6]  R136      -1.1651092767715454e-01
    z[0,1,6]  R137      1.8766130506992340e-01
    z[0,1,6]  R138      2.1053564548492432e-01
    z[0,1,6]  R139      -1.6096076369285583e-01
    z[0,1,6]  R140      2.3172810673713684e-01
    z[0,1,6]  R141      4.1252526640892029e-01
    z[0,1,6]  R142      -1.9073310494422913e-01
    z[0,1,6]  R143      -1.2972231209278107e-01
    z[0,1,6]  R144      -5.2020758390426636e-01
    z[0,1,6]  R145      -7.9890716075897217e-01
    z[0,1,6]  R146      -4.0473058819770813e-01
    z[0,1,6]  R147      -3.6321204900741577e-01
    z[0,1,6]  R148      -5.4574948549270630e-01
    z[0,1,6]  R149      6.5559722483158112e-02
    z[0,1,6]  R150      3.6005118489265442e-01
    z[0,1,6]  R151      -4.5117178559303284e-01
    z[0,1,6]  R152      -5.4073441028594971e-01
    z[0,1,6]  R153      1.2992599513381720e-03
    z[0,1,6]  R154      2.1642138063907623e-01
    z[0,1,6]  R155      3.4340581297874451e-01
    z[0,1,6]  R156      -3.2740628719329834e-01
    z[0,1,6]  R157      -6.2006378173828125e-01
    z[0,1,6]  R158      2.7123183012008667e-01
    z[0,1,6]  R159      -4.2300187051296234e-02
    z[0,1,6]  R160      1.2370651215314865e-01
    z[0,1,6]  R161      -4.7015976905822754e-01
    z[0,1,6]  R162      3.4981733560562134e-01
    z[0,1,6]  R163      -7.3354914784431458e-02
    z[0,1,6]  R164      -2.4641756713390350e-01
    z[0,1,6]  R165      -2.3655369877815247e-02
    z[0,1,6]  R166      4.4243231415748596e-02
    z[0,1,6]  R167      -2.6326501369476318e-01
    z[0,1,6]  R168      -6.7819356918334961e-02
    z[0,1,6]  R169      -5.0240176916122437e-01
    z[0,1,6]  R170      -2.6337611675262451e-01
    z[0,1,6]  R171      -3.5471022129058838e-02
    z[0,1,6]  R172      1.9848808646202087e-01
    z[0,1,6]  R173      -6.9091357290744781e-02
    z[0,1,6]  R174      3.4583261609077454e-01
    z[0,1,6]  R175      1.0074346512556076e-01
    z[0,1,6]  R176      2.9694160819053650e-01
    z[0,1,6]  R177      2.5770869851112366e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R178      -1
    z[1,0,0]  R179      1
    z[1,0,0]  R192      -2.3927323520183563e-01
    z[1,0,0]  R193      -9.3068093061447144e-02
    z[1,0,0]  R194      -1.8396428227424622e-01
    z[1,0,0]  R195      1.1003871262073517e-01
    z[1,0,0]  R196      -4.2539175599813461e-02
    z[1,0,0]  R197      -3.0694505572319031e-01
    z[1,0,0]  R198      2.3849646747112274e-01
    z[1,0,0]  R199      -2.5389662384986877e-01
    z[1,0,0]  R200      -3.2029229402542114e-01
    z[1,0,0]  R201      -1.6619090735912323e-01
    z[1,0,0]  R202      6.6466385126113892e-01
    z[1,0,0]  R203      -4.7198975086212158e-01
    z[1,0,0]  R204      -7.8905403614044189e-01
    z[1,0,0]  R205      -0.89189612865448
    z[1,0,0]  R206      -3.1033545732498169e-01
    z[1,0,0]  R207      -5.1954627037048340e-01
    z[1,0,0]  R208      -3.0689609050750732e-01
    z[1,0,0]  R209      3.9101323485374451e-01
    z[1,0,0]  R210      -2.4056018888950348e-01
    z[1,0,0]  R211      -2.3183842003345490e-01
    z[1,0,0]  R212      3.5448500514030457e-01
    z[1,0,0]  R213      1.2213188409805298e-01
    z[1,0,0]  R214      4.4516941905021667e-01
    z[1,0,0]  R215      7.5336650013923645e-02
    z[1,0,0]  R216      2.0835784077644348e-01
    z[1,0,0]  R217      3.7897145748138428e-01
    z[1,0,0]  R218      -2.0715612173080444e-01
    z[1,0,0]  R219      6.3558273017406464e-02
    z[1,0,0]  R220      1.4043904957361519e-04
    z[1,0,0]  R221      -5.2889108657836914e-01
    z[1,0,0]  R222      0.124534472823143
    z[1,0,0]  R223      3.2512968778610229e-01
    z[1,0,0]  R224      1.2217810004949570e-01
    z[1,0,0]  R225      -0.0638943687081337
    z[1,0,0]  R226      3.9143315516412258e-03
    z[1,0,0]  R227      -5.3495984524488449e-02
    z[1,0,0]  R228      -6.1061024665832520e-01
    z[1,0,0]  R229      -3.2372646033763885e-02
    z[1,0,0]  R230      -1.4620240032672882e-01
    z[1,0,0]  R231      -5.6994175910949707e-01
    z[1,0,0]  R232      5.4328281432390213e-02
    z[1,0,0]  R233      -7.7049273252487183e-01
    z[1,0,0]  R234      -3.6872324347496033e-01
    z[1,0,0]  R235      -3.8276901841163635e-01
    z[1,0,0]  R236      -0.460308313369751
    z[1,0,0]  R237      -3.8408553600311279e-01
    z[1,0,0]  R238      5.7115048170089722e-01
    z[1,0,0]  R239      -2.7225458621978760e-01
    z[1,0,0]  R240      5.5754220485687256e-01
    z[1,0,0]  R241      2.3218529298901558e-02
    z[1,0,0]  R242      2.6585500687360764e-02
    z[1,0,0]  R243      7.1294128894805908e-02
    z[1,0,0]  R244      -2.7335685491561890e-01
    z[1,0,0]  R245      3.5928568243980408e-01
    z[1,0,0]  R246      5.9883729554712772e-03
    z[1,0,0]  R247      9.2439334839582443e-03
    z[1,0,0]  R248      -5.6336027383804321e-01
    z[1,0,0]  R249      4.0163779258728027e-01
    z[1,0,0]  R250      3.0317434668540955e-01
    z[1,0,0]  R251      7.8471505641937256e-01
    z[1,0,0]  R252      0.381783664226532
    z[1,0,0]  R253      3.5267886519432068e-01
    z[1,0,0]  R254      2.9792514443397522e-01
    z[1,0,0]  R255      0.076849564909935
    z[1,0,0]  R256      -1.4367805421352386e-01
    z[1,0,0]  R257      -6.4512050151824951e-01
    z[1,0,0]  R258      -1.4328041672706604e-01
    z[1,0,0]  R259      -3.8182201981544495e-01
    z[1,0,0]  R260      8.9524544775485992e-02
    z[1,0,0]  R261      1.5060995519161224e-01
    z[1,0,0]  R262      3.7041693925857544e-01
    z[1,0,0]  R263      2.2597697377204895e-01
    z[1,0,0]  R264      0.567455530166626
    z[1,0,0]  R265      1.5902924537658691e-01
    z[1,0,0]  R266      4.2210280895233154e-01
    z[1,0,0]  R267      -8.5973076522350311e-02
    z[1,0,0]  R268      2.6575249433517456e-01
    z[1,0,0]  R269      5.2248769998550415e-01
    z[1,0,0]  R270      6.5832680463790894e-01
    z[1,0,0]  R271      3.6908453702926636e-01
    z[1,0,0]  R272      4.6946355700492859e-01
    z[1,0,0]  R273      5.7255238294601440e-01
    z[1,0,0]  R274      4.2565661668777466e-01
    z[1,0,0]  R275      1.0079831629991531e-01
    z[1,0,0]  R276      2.0305563509464264e-01
    z[1,0,0]  R277      5.4893147945404053e-01
    z[1,0,0]  R278      -5.2610252052545547e-02
    z[1,0,0]  R279      2.1409960091114044e-01
    z[1,0,0]  R280      4.1114953160285950e-01
    z[1,0,0]  R281      5.8458864688873291e-01
    z[1,0,0]  R282      3.7280049920082092e-01
    z[1,0,0]  R283      2.8200241923332214e-01
    z[1,0,0]  R284      -4.1353516280651093e-02
    z[1,0,0]  R285      -3.7106537818908691e-01
    z[1,0,0]  R286      1.2341576069593430e-01
    z[1,0,0]  R287      -2.1269651129841805e-02
    z[1,0,0]  R288      -4.4928431510925293e-01
    z[1,0,0]  R289      -5.3979802131652832e-01
    z[1,0,0]  R290      -3.9149722456932068e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R180      -1
    z[1,0,1]  R181      1
    z[1,0,1]  R192      -2.3412662744522095e-01
    z[1,0,1]  R193      -3.2256475090980530e-01
    z[1,0,1]  R194      -3.6999046802520752e-01
    z[1,0,1]  R195      -5.2285623550415039e-01
    z[1,0,1]  R196      -4.6815851330757141e-01
    z[1,0,1]  R197      -4.2803874611854553e-01
    z[1,0,1]  R198      -7.1605294942855835e-01
    z[1,0,1]  R199      6.4604789018630981e-01
    z[1,0,1]  R200      8.5382020473480225e-01
    z[1,0,1]  R201      8.7410008907318115e-01
    z[1,0,1]  R202      -2.1206778287887573e-01
    z[1,0,1]  R203      5.5650299787521362e-01
    z[1,0,1]  R204      2.7068966627120972e-01
    z[1,0,1]  R205      2.0389008522033691e-01
    z[1,0,1]  R206      2.8315299749374390e-01
    z[1,0,1]  R207      3.0223432183265686e-01
    z[1,0,1]  R208      -1.4377743005752563e-01
    z[1,0,1]  R209      -2.0649042725563049e-01
    z[1,0,1]  R210      8.2114261388778687e-01
    z[1,0,1]  R211      7.1400213241577148e-01
    z[1,0,1]  R212      -3.3164060115814209e-01
    z[1,0,1]  R213      -1.8140999972820282e-01
    z[1,0,1]  R214      -5.1794147491455078e-01
    z[1,0,1]  R215      -5.0821495056152344e-01
    z[1,0,1]  R216      -6.5732920169830322e-01
    z[1,0,1]  R217      -5.3367048501968384e-01
    z[1,0,1]  R218      -5.9342402219772339e-01
    z[1,0,1]  R219      2.9371902346611023e-01
    z[1,0,1]  R220      3.0722531676292419e-01
    z[1,0,1]  R221      7.0174783468246460e-01
    z[1,0,1]  R222      -5.3573852777481079e-01
    z[1,0,1]  R223      -7.3988282680511475e-01
    z[1,0,1]  R224      -1.4559482038021088e-01
    z[1,0,1]  R225      -6.6544854640960693e-01
    z[1,0,1]  R226      2.6029470562934875e-01
    z[1,0,1]  R227      0.684913694858551
    z[1,0,1]  R228      5.3332304954528809e-01
    z[1,0,1]  R229      7.8472161293029785e-01
    z[1,0,1]  R230      8.9037430286407471e-01
    z[1,0,1]  R231      0.710384726524353
    z[1,0,1]  R232      -4.5226737856864929e-01
    z[1,0,1]  R233      2.4580633640289307e-01
    z[1,0,1]  R234      6.3817453384399414e-01
    z[1,0,1]  R235      -5.0469082593917847e-01
    z[1,0,1]  R236      7.7087897062301636e-01
    z[1,0,1]  R237      7.6046824455261230e-01
    z[1,0,1]  R238      7.8955745697021484e-01
    z[1,0,1]  R239      2.1833692491054535e-01
    z[1,0,1]  R240      7.0232802629470825e-01
    z[1,0,1]  R241      -6.9088816642761230e-01
    z[1,0,1]  R242      -8.2758784294128418e-01
    z[1,0,1]  R243      -5.2705746889114380e-01
    z[1,0,1]  R244      -8.5353112220764160e-01
    z[1,0,1]  R245      -7.9864984750747681e-01
    z[1,0,1]  R246      -9.2099231481552124e-01
    z[1,0,1]  R247      -5.0414168834686279e-01
    z[1,0,1]  R248      -7.7416580915451050e-01
    z[1,0,1]  R249      -8.3415180444717407e-01
    z[1,0,1]  R250      4.2863461375236511e-01
    z[1,0,1]  R251      5.2385592460632324e-01
    z[1,0,1]  R252      7.7788054943084717e-01
    z[1,0,1]  R253      5.1039779186248779e-01
    z[1,0,1]  R254      0.782328724861145
    z[1,0,1]  R255      9.3017423152923584e-01
    z[1,0,1]  R256      7.4598878622055054e-01
    z[1,0,1]  R257      6.2384688854217529e-01
    z[1,0,1]  R258      9.0567612648010254e-01
    z[1,0,1]  R259      8.4035253524780273e-01
    z[1,0,1]  R260      7.2656100988388062e-01
    z[1,0,1]  R261      0.54316645860672
    z[1,0,1]  R262      8.2122975587844849e-01
    z[1,0,1]  R263      3.5193365812301636e-01
    z[1,0,1]  R264      2.6572963595390320e-01
    z[1,0,1]  R265      6.3096469640731812e-01
    z[1,0,1]  R266      3.6601129174232483e-01
    z[1,0,1]  R267      5.9211635589599609e-01
    z[1,0,1]  R268      3.8181629776954651e-01
    z[1,0,1]  R269      3.8341113924980164e-01
    z[1,0,1]  R270      4.8087698221206665e-01
    z[1,0,1]  R271      7.4802255630493164e-01
    z[1,0,1]  R272      0.600898265838623
    z[1,0,1]  R273      3.2104572653770447e-01
    z[1,0,1]  R274      5.1311117410659790e-01
    z[1,0,1]  R275      0.793482780456543
    z[1,0,1]  R276      4.4519197940826416e-01
    z[1,0,1]  R277      -1.3799582421779633e-01
    z[1,0,1]  R278      -0.605397641658783
    z[1,0,1]  R279      5.4583203792572021e-01
    z[1,0,1]  R280      6.9718170166015625e-01
    z[1,0,1]  R281      4.2258173227310181e-01
    z[1,0,1]  R282      6.1684954166412354e-01
    z[1,0,1]  R283      -5.7018172740936279e-01
    z[1,0,1]  R284      1.1039377748966217e-01
    z[1,0,1]  R285      8.6186027526855469e-01
    z[1,0,1]  R286      5.7072877883911133e-01
    z[1,0,1]  R287      8.6363697052001953e-01
    z[1,0,1]  R288      7.0416003465652466e-01
    z[1,0,1]  R289      1.4872631430625916e-01
    z[1,0,1]  R290      3.2680952548980713e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R182      -1
    z[1,0,2]  R183      1
    z[1,0,2]  R192      7.8288090229034424e-01
    z[1,0,2]  R193      6.9121789932250977e-01
    z[1,0,2]  R194      2.7046054601669312e-01
    z[1,0,2]  R195      -9.0173922479152679e-02
    z[1,0,2]  R196      0.612095057964325
    z[1,0,2]  R197      4.0137669444084167e-01
    z[1,0,2]  R198      -2.8709178790450096e-02
    z[1,0,2]  R199      -3.5165694355964661e-01
    z[1,0,2]  R200      7.7848076820373535e-02
    z[1,0,2]  R201      -2.6500681042671204e-01
    z[1,0,2]  R202      -1.8514315783977509e-01
    z[1,0,2]  R203      5.4202932119369507e-01
    z[1,0,2]  R204      -1.2013711780309677e-01
    z[1,0,2]  R205      3.0058783292770386e-01
    z[1,0,2]  R206      -3.3320057392120361e-01
    z[1,0,2]  R207      -2.3354759812355042e-01
    z[1,0,2]  R208      -2.6625505089759827e-01
    z[1,0,2]  R209      2.5235649943351746e-01
    z[1,0,2]  R210      -1.5740875899791718e-01
    z[1,0,2]  R211      2.9138955473899841e-01
    z[1,0,2]  R212      2.7108547091484070e-01
    z[1,0,2]  R213      4.9036440253257751e-01
    z[1,0,2]  R214      3.1304258108139038e-01
    z[1,0,2]  R215      3.3663868904113770e-01
    z[1,0,2]  R216      -2.5620761513710022e-01
    z[1,0,2]  R217      -3.8797748088836670e-01
    z[1,0,2]  R218      -1.6617652773857117e-01
    z[1,0,2]  R219      5.5452769994735718e-01
    z[1,0,2]  R220      5.9412352740764618e-02
    z[1,0,2]  R221      2.2869819402694702e-01
    z[1,0,2]  R222      7.1511673927307129e-01
    z[1,0,2]  R223      -2.6457920670509338e-01
    z[1,0,2]  R224      4.2584562301635742e-01
    z[1,0,2]  R225      -1.1458848416805267e-01
    z[1,0,2]  R226      -6.1519676446914673e-01
    z[1,0,2]  R227      -1.7192934453487396e-01
    z[1,0,2]  R228      -2.2272443771362305e-01
    z[1,0,2]  R229      -2.4329580366611481e-01
    z[1,0,2]  R230      -2.7469378709793091e-01
    z[1,0,2]  R231      1.3224802911281586e-02
    z[1,0,2]  R232      -1.1340240389108658e-01
    z[1,0,2]  R233      3.0671819113194942e-03
    z[1,0,2]  R234      5.8155737817287445e-02
    z[1,0,2]  R235      2.9615920782089233e-01
    z[1,0,2]  R236      -0.0243210606276989
    z[1,0,2]  R237      -3.4894734621047974e-01
    z[1,0,2]  R238      -1.1464491486549377e-01
    z[1,0,2]  R239      -6.2834733724594116e-01
    z[1,0,2]  R240      -2.8288549184799194e-01
    z[1,0,2]  R241      -7.5585119426250458e-02
    z[1,0,2]  R242      2.4415375292301178e-01
    z[1,0,2]  R243      6.4707857370376587e-01
    z[1,0,2]  R244      2.7240115404129028e-01
    z[1,0,2]  R245      1.0018160194158554e-01
    z[1,0,2]  R246      -1.0218521207571030e-01
    z[1,0,2]  R247      4.6498867869377136e-01
    z[1,0,2]  R248      1.6942533850669861e-01
    z[1,0,2]  R249      -3.0455809831619263e-01
    z[1,0,2]  R250      3.7516161799430847e-01
    z[1,0,2]  R251      1.5947189927101135e-01
    z[1,0,2]  R252      -2.3742966353893280e-01
    z[1,0,2]  R253      4.0666827559471130e-01
    z[1,0,2]  R254      5.1089294254779816e-02
    z[1,0,2]  R255      -2.0245976746082306e-01
    z[1,0,2]  R256      4.5116788148880005e-01
    z[1,0,2]  R257      3.1718626618385315e-01
    z[1,0,2]  R258      -2.2297109663486481e-01
    z[1,0,2]  R259      1.5814979374408722e-01
    z[1,0,2]  R260      -1.4584209024906158e-01
    z[1,0,2]  R261      -4.3707605451345444e-02
    z[1,0,2]  R262      -9.2976361513137817e-02
    z[1,0,2]  R263      -4.3287232518196106e-01
    z[1,0,2]  R264      -1.6613063216209412e-01
    z[1,0,2]  R265      1.5279665589332581e-01
    z[1,0,2]  R266      2.2173093259334564e-01
    z[1,0,2]  R267      -2.2127854824066162e-01
    z[1,0,2]  R268      -1.9176118075847626e-02
    z[1,0,2]  R269      -1.9215150177478790e-01
    z[1,0,2]  R270      -4.6588137745857239e-01
    z[1,0,2]  R271      3.6818632483482361e-01
    z[1,0,2]  R272      1.9580742716789246e-01
    z[1,0,2]  R273      2.5650796294212341e-01
    z[1,0,2]  R274      4.0598914027214050e-01
    z[1,0,2]  R275      5.2883196622133255e-02
    z[1,0,2]  R276      1.0428345762193203e-02
    z[1,0,2]  R277      -1.7387193441390991e-01
    z[1,0,2]  R278      -4.5069187879562378e-01
    z[1,0,2]  R279      0.118861123919487
    z[1,0,2]  R280      4.8090755008161068e-03
    z[1,0,2]  R281      -1.7562119662761688e-01
    z[1,0,2]  R282      -3.9228554815053940e-02
    z[1,0,2]  R283      -5.5179435014724731e-01
    z[1,0,2]  R284      3.6836430430412292e-02
    z[1,0,2]  R285      1.0536435991525650e-01
    z[1,0,2]  R286      -3.7455025315284729e-01
    z[1,0,2]  R287      2.1165508031845093e-01
    z[1,0,2]  R288      2.3400449752807617e-01
    z[1,0,2]  R289      2.4168847501277924e-01
    z[1,0,2]  R290      6.5540504455566406e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R184      -1
    z[1,0,3]  R185      1
    z[1,0,3]  R192      -1.3675062358379364e-01
    z[1,0,3]  R193      -1.2978547811508179e-01
    z[1,0,3]  R194      -2.1833953261375427e-01
    z[1,0,3]  R195      -0.192160502076149
    z[1,0,3]  R196      2.3703585565090179e-01
    z[1,0,3]  R197      1.8773065507411957e-01
    z[1,0,3]  R198      4.6362329274415970e-02
    z[1,0,3]  R199      -1.2510886788368225e-01
    z[1,0,3]  R200      -1.6061370074748993e-01
    z[1,0,3]  R201      -2.4646823108196259e-01
    z[1,0,3]  R202      -6.7244774103164673e-01
    z[1,0,3]  R203      -3.4394088387489319e-01
    z[1,0,3]  R204      1.5020883083343506e-01
    z[1,0,3]  R205      1.7196573317050934e-01
    z[1,0,3]  R206      -3.5162393003702164e-02
    z[1,0,3]  R207      -3.5772061347961426e-01
    z[1,0,3]  R208      -0.360651433467865
    z[1,0,3]  R209      1.1904857121407986e-02
    z[1,0,3]  R210      1.0218356549739838e-01
    z[1,0,3]  R211      7.6278068125247955e-02
    z[1,0,3]  R212      -1.2785153090953827e-01
    z[1,0,3]  R213      -3.0141493678092957e-01
    z[1,0,3]  R214      3.7640803493559361e-03
    z[1,0,3]  R215      4.3715375661849976e-01
    z[1,0,3]  R216      5.1293814182281494e-01
    z[1,0,3]  R217      1.5632462501525879e-01
    z[1,0,3]  R218      6.3311499357223511e-01
    z[1,0,3]  R219      -5.8447301387786865e-01
    z[1,0,3]  R220      -2.7181667089462280e-01
    z[1,0,3]  R221      -7.3082715272903442e-02
    z[1,0,3]  R222      -3.0466508865356445e-01
    z[1,0,3]  R223      -1.4586928486824036e-01
    z[1,0,3]  R224      -3.5448685288429260e-01
    z[1,0,3]  R225      5.7399606704711914e-01
    z[1,0,3]  R226      -5.2418279647827148e-01
    z[1,0,3]  R227      -0.277119517326355
    z[1,0,3]  R228      -1.5559767186641693e-01
    z[1,0,3]  R229      -4.8624446988105774e-01
    z[1,0,3]  R230      -1.8034832552075386e-02
    z[1,0,3]  R231      3.2120910286903381e-01
    z[1,0,3]  R232      2.6803153753280640e-01
    z[1,0,3]  R233      -4.8867025971412659e-01
    z[1,0,3]  R234      -7.2287283837795258e-02
    z[1,0,3]  R235      5.6514286994934082e-01
    z[1,0,3]  R236      2.9438361525535583e-01
    z[1,0,3]  R237      8.9321218430995941e-02
    z[1,0,3]  R238      1.5312604606151581e-02
    z[1,0,3]  R239      -0.288524866104126
    z[1,0,3]  R240      0.1168212890625
    z[1,0,3]  R241      -6.0313421487808228e-01
    z[1,0,3]  R242      -2.6426699757575989e-01
    z[1,0,3]  R243      -4.0811866521835327e-01
    z[1,0,3]  R244      -1.8318356946110725e-02
    z[1,0,3]  R245      -3.3026996254920959e-01
    z[1,0,3]  R246      6.8596608936786652e-02
    z[1,0,3]  R247      -4.8660203814506531e-01
    z[1,0,3]  R248      2.5030849501490593e-02
    z[1,0,3]  R249      1.7117737233638763e-01
    z[1,0,3]  R250      6.2525969743728638e-01
    z[1,0,3]  R251      -2.2083206474781036e-01
    z[1,0,3]  R252      -1.8068033456802368e-01
    z[1,0,3]  R253      1.0851048678159714e-01
    z[1,0,3]  R254      -9.9475458264350891e-02
    z[1,0,3]  R255      -2.8459498286247253e-01
    z[1,0,3]  R256      -0.405542254447937
    z[1,0,3]  R257      0.0989881381392479
    z[1,0,3]  R258      -1.9643209874629974e-02
    z[1,0,3]  R259      -2.3548056185245514e-01
    z[1,0,3]  R260      -4.4133788347244263e-01
    z[1,0,3]  R261      5.6281000375747681e-01
    z[1,0,3]  R262      1.4149080216884613e-01
    z[1,0,3]  R263      7.3939192295074463e-01
    z[1,0,3]  R264      5.2539533376693726e-01
    z[1,0,3]  R265      1.8167947232723236e-01
    z[1,0,3]  R266      2.4998384714126587e-01
    z[1,0,3]  R267      4.9449887871742249e-01
    z[1,0,3]  R268      6.6805613040924072e-01
    z[1,0,3]  R269      5.3257602453231812e-01
    z[1,0,3]  R270      3.0099043250083923e-01
    z[1,0,3]  R271      1.6139744222164154e-01
    z[1,0,3]  R272      2.4999523162841797e-01
    z[1,0,3]  R273      3.2812726497650146e-01
    z[1,0,3]  R274      4.9095913767814636e-01
    z[1,0,3]  R275      4.9335297942161560e-01
    z[1,0,3]  R276      0.771373450756073
    z[1,0,3]  R277      -6.1114239692687988e-01
    z[1,0,3]  R278      -3.4578660130500793e-01
    z[1,0,3]  R279      6.4186424016952515e-01
    z[1,0,3]  R280      6.5114744007587433e-02
    z[1,0,3]  R281      3.3785501122474670e-01
    z[1,0,3]  R282      5.6813359260559082e-01
    z[1,0,3]  R283      -3.4559237957000732e-01
    z[1,0,3]  R284      -7.2367310523986816e-01
    z[1,0,3]  R285      2.1732898056507111e-01
    z[1,0,3]  R286      3.1666469573974609e-01
    z[1,0,3]  R287      -1.6486048698425293e-01
    z[1,0,3]  R288      -1.4926570653915405e-01
    z[1,0,3]  R289      -7.3794215917587280e-01
    z[1,0,3]  R290      -4.1002565622329712e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R186      -1
    z[1,0,4]  R187      1
    z[1,0,4]  R192      3.7444502115249634e-01
    z[1,0,4]  R193      4.6636760234832764e-01
    z[1,0,4]  R194      7.1435712277889252e-02
    z[1,0,4]  R195      3.0189543962478638e-01
    z[1,0,4]  R196      4.6917036175727844e-01
    z[1,0,4]  R197      -6.2298811972141266e-02
    z[1,0,4]  R198      1.1157064139842987e-01
    z[1,0,4]  R199      1.7434763908386230e-01
    z[1,0,4]  R200      0.265186071395874
    z[1,0,4]  R201      8.1869371235370636e-02
    z[1,0,4]  R202      -0.0295050460845232
    z[1,0,4]  R203      4.1165456175804138e-02
    z[1,0,4]  R204      1.4436149597167969e-01
    z[1,0,4]  R205      -7.9460576176643372e-02
    z[1,0,4]  R206      7.5569534301757812e-01
    z[1,0,4]  R207      -5.1839772611856461e-02
    z[1,0,4]  R208      1.8890835344791412e-01
    z[1,0,4]  R209      -2.3591178655624390e-01
    z[1,0,4]  R210      -3.0672883987426758e-01
    z[1,0,4]  R211      -1.2151244282722473e-01
    z[1,0,4]  R212      -4.5494616031646729e-01
    z[1,0,4]  R213      -5.7108914852142334e-01
    z[1,0,4]  R214      -1.4176666736602783e-01
    z[1,0,4]  R215      -3.3100968599319458e-01
    z[1,0,4]  R216      1.0167949646711349e-01
    z[1,0,4]  R217      -3.1500551104545593e-01
    z[1,0,4]  R218      -2.4191634356975555e-01
    z[1,0,4]  R219      -2.6066654920578003e-01
    z[1,0,4]  R220      4.7065809369087219e-02
    z[1,0,4]  R221      -2.2838643193244934e-01
    z[1,0,4]  R222      -1.7407071590423584e-01
    z[1,0,4]  R223      1.1996034532785416e-01
    z[1,0,4]  R224      3.4921982884407043e-01
    z[1,0,4]  R225      1.6590552031993866e-01
    z[1,0,4]  R226      3.6356106400489807e-01
    z[1,0,4]  R227      0.567359983921051
    z[1,0,4]  R228      -4.1081428527832031e-01
    z[1,0,4]  R229      -2.4256144464015961e-01
    z[1,0,4]  R230      -6.1225313693284988e-02
    z[1,0,4]  R231      -2.1430957317352295e-01
    z[1,0,4]  R232      -3.9447724819183350e-01
    z[1,0,4]  R233      -1.9413267076015472e-01
    z[1,0,4]  R234      5.8033210039138794e-01
    z[1,0,4]  R235      -3.3854478597640991e-01
    z[1,0,4]  R236      -2.6605397462844849e-01
    z[1,0,4]  R237      -1.3745093345642090e-01
    z[1,0,4]  R238      6.3053965568542480e-02
    z[1,0,4]  R239      2.9617384076118469e-01
    z[1,0,4]  R240      1.8876156210899353e-01
    z[1,0,4]  R241      -7.7204527333378792e-03
    z[1,0,4]  R242      4.5496243983507156e-02
    z[1,0,4]  R243      -3.1085941195487976e-01
    z[1,0,4]  R244      -6.0165543109178543e-02
    z[1,0,4]  R245      -1.1988577991724014e-01
    z[1,0,4]  R246      -8.8058109395205975e-04
    z[1,0,4]  R247      -1.5633161365985870e-01
    z[1,0,4]  R248      2.2820717096328735e-01
    z[1,0,4]  R249      -0.0789557546377182
    z[1,0,4]  R250      -3.4042972326278687e-01
    z[1,0,4]  R251      8.3188056945800781e-02
    z[1,0,4]  R252      3.5270789265632629e-01
    z[1,0,4]  R253      0.625708818435669
    z[1,0,4]  R254      4.3101277947425842e-01
    z[1,0,4]  R255      0.0524633526802063
    z[1,0,4]  R256      -8.2717090845108032e-02
    z[1,0,4]  R257      5.2935957908630371e-02
    z[1,0,4]  R258      1.2602145969867706e-01
    z[1,0,4]  R259      4.1201531887054443e-02
    z[1,0,4]  R260      1.8331001698970795e-01
    z[1,0,4]  R261      5.5005115270614624e-01
    z[1,0,4]  R262      -1.6806045174598694e-01
    z[1,0,4]  R263      2.3589572310447693e-01
    z[1,0,4]  R264      5.1857888698577881e-01
    z[1,0,4]  R265      3.3163938671350479e-02
    z[1,0,4]  R266      -3.9490621536970139e-02
    z[1,0,4]  R267      2.5820270180702209e-01
    z[1,0,4]  R268      2.3370358347892761e-01
    z[1,0,4]  R269      -6.8685412406921387e-02
    z[1,0,4]  R270      -1.0905279964208603e-01
    z[1,0,4]  R271      -4.2552232742309570e-02
    z[1,0,4]  R272      4.1010481119155884e-01
    z[1,0,4]  R273      2.1401986479759216e-01
    z[1,0,4]  R274      2.1495439112186432e-01
    z[1,0,4]  R275      2.3247393965721130e-01
    z[1,0,4]  R276      -8.0415733158588409e-02
    z[1,0,4]  R277      4.5572139322757721e-02
    z[1,0,4]  R278      3.4023562073707581e-01
    z[1,0,4]  R279      -1.7753715813159943e-01
    z[1,0,4]  R280      1.1264232546091080e-01
    z[1,0,4]  R281      -1.6377037763595581e-01
    z[1,0,4]  R282      -3.1421598792076111e-01
    z[1,0,4]  R283      2.8071027994155884e-01
    z[1,0,4]  R284      2.8293186426162720e-01
    z[1,0,4]  R285      6.4598284661769867e-02
    z[1,0,4]  R286      2.4649754166603088e-01
    z[1,0,4]  R287      -1.2283524870872498e-01
    z[1,0,4]  R288      2.3887798190116882e-01
    z[1,0,4]  R289      2.6853394508361816e-01
    z[1,0,4]  R290      -4.5189116150140762e-02
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R188      -1
    z[1,0,5]  R189      1
    z[1,0,5]  R192      1.8587511777877808e-01
    z[1,0,5]  R193      -1.4139805734157562e-01
    z[1,0,5]  R194      4.5469993352890015e-01
    z[1,0,5]  R195      8.6127929389476776e-02
    z[1,0,5]  R196      0.0432896763086319
    z[1,0,5]  R197      7.2182303667068481e-01
    z[1,0,5]  R198      5.4944694042205811e-01
    z[1,0,5]  R199      5.7868117094039917e-01
    z[1,0,5]  R200      -0.176085963845253
    z[1,0,5]  R201      -1.6225415468215942e-01
    z[1,0,5]  R202      -2.5128121487796307e-03
    z[1,0,5]  R203      6.8202703259885311e-03
    z[1,0,5]  R204      2.7587673068046570e-01
    z[1,0,5]  R205      -1.8212584778666496e-02
    z[1,0,5]  R206      3.5121780633926392e-01
    z[1,0,5]  R207      -4.2768475413322449e-01
    z[1,0,5]  R208      1.0120529681444168e-01
    z[1,0,5]  R209      -7.2193038463592529e-01
    z[1,0,5]  R210      -8.1432253122329712e-02
    z[1,0,5]  R211      -1.8198329210281372e-01
    z[1,0,5]  R212      -6.8062287569046021e-01
    z[1,0,5]  R213      -4.0630817413330078e-01
    z[1,0,5]  R214      -4.6032306551933289e-01
    z[1,0,5]  R215      -1.7219726741313934e-01
    z[1,0,5]  R216      -0.430600643157959
    z[1,0,5]  R217      -5.0054562091827393e-01
    z[1,0,5]  R218      5.8270907029509544e-03
    z[1,0,5]  R219      2.9229742288589478e-01
    z[1,0,5]  R220      6.6445773839950562e-01
    z[1,0,5]  R221      2.1083930134773254e-01
    z[1,0,5]  R222      2.4733105301856995e-01
    z[1,0,5]  R223      4.7527906298637390e-01
    z[1,0,5]  R224      5.6023615598678589e-01
    z[1,0,5]  R225      -2.4616421759128571e-01
    z[1,0,5]  R226      3.7608388066291809e-01
    z[1,0,5]  R227      1.9763027131557465e-01
    z[1,0,5]  R228      -3.1555801630020142e-01
    z[1,0,5]  R229      1.6353559494018555e-01
    z[1,0,5]  R230      -1.9240470230579376e-01
    z[1,0,5]  R231      0.129002645611763
    z[1,0,5]  R232      5.4752331972122192e-01
    z[1,0,5]  R233      7.5934166088700294e-03
    z[1,0,5]  R234      3.3185136318206787e-01
    z[1,0,5]  R235      1.9408319890499115e-01
    z[1,0,5]  R236      -1.7621102929115295e-01
    z[1,0,5]  R237      -7.7011808753013611e-02
    z[1,0,5]  R238      -1.5127140283584595e-01
    z[1,0,5]  R239      -4.7354641556739807e-01
    z[1,0,5]  R240      1.2884079478681087e-02
    z[1,0,5]  R241      3.5248550772666931e-01
    z[1,0,5]  R242      -1.8579567968845367e-01
    z[1,0,5]  R243      -1.3986136019229889e-01
    z[1,0,5]  R244      3.4295409917831421e-01
    z[1,0,5]  R245      -3.0872318148612976e-01
    z[1,0,5]  R246      3.6392825841903687e-01
    z[1,0,5]  R247      2.9768466949462891e-01
    z[1,0,5]  R248      -2.5655742734670639e-02
    z[1,0,5]  R249      0.0423213467001915
    z[1,0,5]  R250      -2.7284887433052063e-01
    z[1,0,5]  R251      -1.4773845672607422e-01
    z[1,0,5]  R252      -0.156717449426651
    z[1,0,5]  R253      1.5973153710365295e-01
    z[1,0,5]  R254      2.8820648789405823e-01
    z[1,0,5]  R255      8.1712851533666253e-04
    z[1,0,5]  R256      -4.1467282921075821e-02
    z[1,0,5]  R257      2.6289626955986023e-01
    z[1,0,5]  R258      -1.0409022122621536e-01
    z[1,0,5]  R259      0.084237240254879
    z[1,0,5]  R260      -4.5615535974502563e-01
    z[1,0,5]  R261      -1.3084410130977631e-01
    z[1,0,5]  R262      -2.8830143809318542e-01
    z[1,0,5]  R263      -0.164118230342865
    z[1,0,5]  R264      -1.4126639068126678e-01
    z[1,0,5]  R265      -5.7881736755371094e-01
    z[1,0,5]  R266      -2.4380034208297729e-01
    z[1,0,5]  R267      -4.7147154808044434e-01
    z[1,0,5]  R268      7.7939346432685852e-02
    z[1,0,5]  R269      3.9999324083328247e-01
    z[1,0,5]  R270      -7.4565164744853973e-02
    z[1,0,5]  R271      -3.2411959767341614e-01
    z[1,0,5]  R272      -3.5526511073112488e-01
    z[1,0,5]  R273      -5.4933613538742065e-01
    z[1,0,5]  R274      1.6533279418945312e-01
    z[1,0,5]  R275      2.3109537363052368e-01
    z[1,0,5]  R276      -2.4901962280273438e-01
    z[1,0,5]  R277      -4.3133646249771118e-01
    z[1,0,5]  R278      -3.3600360155105591e-01
    z[1,0,5]  R279      3.9849165081977844e-01
    z[1,0,5]  R280      5.0299203395843506e-01
    z[1,0,5]  R281      -4.7456416487693787e-01
    z[1,0,5]  R282      2.3958018422126770e-01
    z[1,0,5]  R283      -6.1677344143390656e-02
    z[1,0,5]  R284      -4.3604883551597595e-01
    z[1,0,5]  R285      -1.0302336513996124e-01
    z[1,0,5]  R286      -1.4970052242279053e-01
    z[1,0,5]  R287      3.0528476834297180e-01
    z[1,0,5]  R288      -2.1967029571533203e-01
    z[1,0,5]  R289      -7.0856891572475433e-02
    z[1,0,5]  R290      -3.5500779747962952e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R190      -1
    z[1,0,6]  R191      1
    z[1,0,6]  R192      2.8560683131217957e-01
    z[1,0,6]  R193      3.9391836524009705e-01
    z[1,0,6]  R194      7.0469003915786743e-01
    z[1,0,6]  R195      7.5557726621627808e-01
    z[1,0,6]  R196      -3.5521391034126282e-01
    z[1,0,6]  R197      -3.6219093948602676e-02
    z[1,0,6]  R198      -3.3626472949981689e-01
    z[1,0,6]  R199      -1.1651092767715454e-01
    z[1,0,6]  R200      1.8766130506992340e-01
    z[1,0,6]  R201      2.1053564548492432e-01
    z[1,0,6]  R202      -1.6096076369285583e-01
    z[1,0,6]  R203      2.3172810673713684e-01
    z[1,0,6]  R204      4.1252526640892029e-01
    z[1,0,6]  R205      -1.9073310494422913e-01
    z[1,0,6]  R206      -1.2972231209278107e-01
    z[1,0,6]  R207      -5.2020758390426636e-01
    z[1,0,6]  R208      -7.9890716075897217e-01
    z[1,0,6]  R209      -4.0473058819770813e-01
    z[1,0,6]  R210      -3.6321204900741577e-01
    z[1,0,6]  R211      -5.4574948549270630e-01
    z[1,0,6]  R212      6.5559722483158112e-02
    z[1,0,6]  R213      3.6005118489265442e-01
    z[1,0,6]  R214      -4.5117178559303284e-01
    z[1,0,6]  R215      -5.4073441028594971e-01
    z[1,0,6]  R216      1.2992599513381720e-03
    z[1,0,6]  R217      2.1642138063907623e-01
    z[1,0,6]  R218      3.4340581297874451e-01
    z[1,0,6]  R219      -3.2740628719329834e-01
    z[1,0,6]  R220      -6.2006378173828125e-01
    z[1,0,6]  R221      2.7123183012008667e-01
    z[1,0,6]  R222      -4.2300187051296234e-02
    z[1,0,6]  R223      1.2370651215314865e-01
    z[1,0,6]  R224      -4.7015976905822754e-01
    z[1,0,6]  R225      3.4981733560562134e-01
    z[1,0,6]  R226      -7.3354914784431458e-02
    z[1,0,6]  R227      -2.4641756713390350e-01
    z[1,0,6]  R228      -2.3655369877815247e-02
    z[1,0,6]  R229      4.4243231415748596e-02
    z[1,0,6]  R230      -2.6326501369476318e-01
    z[1,0,6]  R231      -6.7819356918334961e-02
    z[1,0,6]  R232      -5.0240176916122437e-01
    z[1,0,6]  R233      -2.6337611675262451e-01
    z[1,0,6]  R234      -3.5471022129058838e-02
    z[1,0,6]  R235      1.9848808646202087e-01
    z[1,0,6]  R236      -6.9091357290744781e-02
    z[1,0,6]  R237      3.4583261609077454e-01
    z[1,0,6]  R238      1.0074346512556076e-01
    z[1,0,6]  R239      2.9694160819053650e-01
    z[1,0,6]  R240      2.5770869851112366e-01
    z[1,0,6]  R241      -1.6835945844650269e-01
    z[1,0,6]  R242      3.8516694307327271e-01
    z[1,0,6]  R243      -1.2514501810073853e-01
    z[1,0,6]  R244      -3.1389329582452774e-02
    z[1,0,6]  R245      -6.5383620560169220e-02
    z[1,0,6]  R246      6.4385667443275452e-02
    z[1,0,6]  R247      4.2391490936279297e-01
    z[1,0,6]  R248      -3.4991465508937836e-02
    z[1,0,6]  R249      -1.1311710625886917e-01
    z[1,0,6]  R250      -4.8196125775575638e-02
    z[1,0,6]  R251      8.2779310643672943e-02
    z[1,0,6]  R252      0.105648472905159
    z[1,0,6]  R253      1.4468035101890564e-01
    z[1,0,6]  R254      1.3364803791046143e-01
    z[1,0,6]  R255      -6.4286895096302032e-02
    z[1,0,6]  R256      2.1512460708618164e-01
    z[1,0,6]  R257      -1.1096056550741196e-01
    z[1,0,6]  R258      -2.8705963492393494e-01
    z[1,0,6]  R259      -0.242411807179451
    z[1,0,6]  R260      7.9782538115978241e-02
    z[1,0,6]  R261      -2.0963051915168762e-01
    z[1,0,6]  R262      -2.1987858414649963e-01
    z[1,0,6]  R263      -0.091742604970932
    z[1,0,6]  R264      -1.2191002815961838e-01
    z[1,0,6]  R265      4.2908000946044922e-01
    z[1,0,6]  R266      -7.1778148412704468e-01
    z[1,0,6]  R267      2.4404789507389069e-01
    z[1,0,6]  R268      0.525579035282135
    z[1,0,6]  R269      -3.0778363347053528e-01
    z[1,0,6]  R270      1.0134135931730270e-01
    z[1,0,6]  R271      -1.8911491334438324e-01
    z[1,0,6]  R272      1.5260358154773712e-01
    z[1,0,6]  R273      -2.1925979852676392e-01
    z[1,0,6]  R274      2.7590745687484741e-01
    z[1,0,6]  R275      0.0811280682682991
    z[1,0,6]  R276      3.1139880418777466e-01
    z[1,0,6]  R277      2.9627183079719543e-01
    z[1,0,6]  R278      -2.8173670172691345e-01
    z[1,0,6]  R279      -1.9948931038379669e-01
    z[1,0,6]  R280      0.273754358291626
    z[1,0,6]  R281      -2.8750661015510559e-01
    z[1,0,6]  R282      8.4515912458300591e-03
    z[1,0,6]  R283      2.9808378219604492e-01
    z[1,0,6]  R284      4.3686878681182861e-01
    z[1,0,6]  R285      -2.1537633240222931e-01
    z[1,0,6]  R286      0.579052209854126
    z[1,0,6]  R287      2.7095130085945129e-01
    z[1,0,6]  R288      3.4633249044418335e-01
    z[1,0,6]  R289      7.9971216619014740e-02
    z[1,0,6]  R290      -1.1906320601701736e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R291      -1
    z[0,3,0]  R292      1
    z[0,3,0]  R305      2.3218529298901558e-02
    z[0,3,0]  R306      2.6585500687360764e-02
    z[0,3,0]  R307      7.1294128894805908e-02
    z[0,3,0]  R308      -2.7335685491561890e-01
    z[0,3,0]  R309      3.5928568243980408e-01
    z[0,3,0]  R310      5.9883729554712772e-03
    z[0,3,0]  R311      9.2439334839582443e-03
    z[0,3,0]  R312      -5.6336027383804321e-01
    z[0,3,0]  R313      4.0163779258728027e-01
    z[0,3,0]  R314      3.0317434668540955e-01
    z[0,3,0]  R315      7.8471505641937256e-01
    z[0,3,0]  R316      0.381783664226532
    z[0,3,0]  R317      3.5267886519432068e-01
    z[0,3,0]  R318      2.9792514443397522e-01
    z[0,3,0]  R319      0.076849564909935
    z[0,3,0]  R320      -1.4367805421352386e-01
    z[0,3,0]  R321      -6.4512050151824951e-01
    z[0,3,0]  R322      -1.4328041672706604e-01
    z[0,3,0]  R323      -3.8182201981544495e-01
    z[0,3,0]  R324      8.9524544775485992e-02
    z[0,3,0]  R325      1.5060995519161224e-01
    z[0,3,0]  R326      3.7041693925857544e-01
    z[0,3,0]  R327      2.2597697377204895e-01
    z[0,3,0]  R328      0.567455530166626
    z[0,3,0]  R329      1.5902924537658691e-01
    z[0,3,0]  R330      4.2210280895233154e-01
    z[0,3,0]  R331      -8.5973076522350311e-02
    z[0,3,0]  R332      2.6575249433517456e-01
    z[0,3,0]  R333      5.2248769998550415e-01
    z[0,3,0]  R334      6.5832680463790894e-01
    z[0,3,0]  R335      3.6908453702926636e-01
    z[0,3,0]  R336      4.6946355700492859e-01
    z[0,3,0]  R337      5.7255238294601440e-01
    z[0,3,0]  R338      4.2565661668777466e-01
    z[0,3,0]  R339      1.0079831629991531e-01
    z[0,3,0]  R340      2.0305563509464264e-01
    z[0,3,0]  R341      5.4893147945404053e-01
    z[0,3,0]  R342      -5.2610252052545547e-02
    z[0,3,0]  R343      2.1409960091114044e-01
    z[0,3,0]  R344      4.1114953160285950e-01
    z[0,3,0]  R345      5.8458864688873291e-01
    z[0,3,0]  R346      3.7280049920082092e-01
    z[0,3,0]  R347      2.8200241923332214e-01
    z[0,3,0]  R348      -4.1353516280651093e-02
    z[0,3,0]  R349      -3.7106537818908691e-01
    z[0,3,0]  R350      1.2341576069593430e-01
    z[0,3,0]  R351      -2.1269651129841805e-02
    z[0,3,0]  R352      -4.4928431510925293e-01
    z[0,3,0]  R353      -5.3979802131652832e-01
    z[0,3,0]  R354      -3.9149722456932068e-01
    z[0,3,0]  R355      1.8530371785163879e-01
    z[0,3,0]  R356      -2.5193458795547485e-01
    z[0,3,0]  R357      -5.6188285350799561e-01
    z[0,3,0]  R358      1.5947241336107254e-02
    z[0,3,0]  R359      2.9958420991897583e-01
    z[0,3,0]  R360      0.526293158531189
    z[0,3,0]  R361      -5.1610004901885986e-01
    z[0,3,0]  R362      -3.3037957549095154e-01
    z[0,3,0]  R363      3.3268904685974121e-01
    z[0,3,0]  R364      0.154024139046669
    z[0,3,0]  R365      3.9366778731346130e-01
    z[0,3,0]  R366      4.0054762363433838e-01
    z[0,3,0]  R367      3.4238618612289429e-01
    z[0,3,0]  R368      5.7106947898864746e-01
    z[0,3,0]  R369      5.3418982028961182e-01
    z[0,3,0]  R370      6.4118576049804688e-01
    z[0,3,0]  R371      7.8070056438446045e-01
    z[0,3,0]  R372      3.5703986883163452e-01
    z[0,3,0]  R373      -1.4922395348548889e-01
    z[0,3,0]  R374      3.4297034144401550e-01
    z[0,3,0]  R375      6.8746519088745117e-01
    z[0,3,0]  R376      5.9731644392013550e-01
    z[0,3,0]  R377      0.451546847820282
    z[0,3,0]  R378      3.8975724577903748e-01
    z[0,3,0]  R379      5.2762645483016968e-01
    z[0,3,0]  R380      0.359191358089447
    z[0,3,0]  R381      3.3647558093070984e-01
    z[0,3,0]  R382      4.7783535718917847e-01
    z[0,3,0]  R383      5.2259588241577148e-01
    z[0,3,0]  R384      5.2622985839843750e-01
    z[0,3,0]  R385      -3.9881786704063416e-01
    z[0,3,0]  R386      -2.2276766598224640e-01
    z[0,3,0]  R387      -3.8694933056831360e-01
    z[0,3,0]  R388      -1.8728250265121460e-01
    z[0,3,0]  R389      -6.7813791334629059e-02
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R293      -1
    z[0,3,1]  R294      1
    z[0,3,1]  R305      -6.9088816642761230e-01
    z[0,3,1]  R306      -8.2758784294128418e-01
    z[0,3,1]  R307      -5.2705746889114380e-01
    z[0,3,1]  R308      -8.5353112220764160e-01
    z[0,3,1]  R309      -7.9864984750747681e-01
    z[0,3,1]  R310      -9.2099231481552124e-01
    z[0,3,1]  R311      -5.0414168834686279e-01
    z[0,3,1]  R312      -7.7416580915451050e-01
    z[0,3,1]  R313      -8.3415180444717407e-01
    z[0,3,1]  R314      4.2863461375236511e-01
    z[0,3,1]  R315      5.2385592460632324e-01
    z[0,3,1]  R316      7.7788054943084717e-01
    z[0,3,1]  R317      5.1039779186248779e-01
    z[0,3,1]  R318      0.782328724861145
    z[0,3,1]  R319      9.3017423152923584e-01
    z[0,3,1]  R320      7.4598878622055054e-01
    z[0,3,1]  R321      6.2384688854217529e-01
    z[0,3,1]  R322      9.0567612648010254e-01
    z[0,3,1]  R323      8.4035253524780273e-01
    z[0,3,1]  R324      7.2656100988388062e-01
    z[0,3,1]  R325      0.54316645860672
    z[0,3,1]  R326      8.2122975587844849e-01
    z[0,3,1]  R327      3.5193365812301636e-01
    z[0,3,1]  R328      2.6572963595390320e-01
    z[0,3,1]  R329      6.3096469640731812e-01
    z[0,3,1]  R330      3.6601129174232483e-01
    z[0,3,1]  R331      5.9211635589599609e-01
    z[0,3,1]  R332      3.8181629776954651e-01
    z[0,3,1]  R333      3.8341113924980164e-01
    z[0,3,1]  R334      4.8087698221206665e-01
    z[0,3,1]  R335      7.4802255630493164e-01
    z[0,3,1]  R336      0.600898265838623
    z[0,3,1]  R337      3.2104572653770447e-01
    z[0,3,1]  R338      5.1311117410659790e-01
    z[0,3,1]  R339      0.793482780456543
    z[0,3,1]  R340      4.4519197940826416e-01
    z[0,3,1]  R341      -1.3799582421779633e-01
    z[0,3,1]  R342      -0.605397641658783
    z[0,3,1]  R343      5.4583203792572021e-01
    z[0,3,1]  R344      6.9718170166015625e-01
    z[0,3,1]  R345      4.2258173227310181e-01
    z[0,3,1]  R346      6.1684954166412354e-01
    z[0,3,1]  R347      -5.7018172740936279e-01
    z[0,3,1]  R348      1.1039377748966217e-01
    z[0,3,1]  R349      8.6186027526855469e-01
    z[0,3,1]  R350      5.7072877883911133e-01
    z[0,3,1]  R351      8.6363697052001953e-01
    z[0,3,1]  R352      7.0416003465652466e-01
    z[0,3,1]  R353      1.4872631430625916e-01
    z[0,3,1]  R354      3.2680952548980713e-01
    z[0,3,1]  R355      -8.6314660310745239e-01
    z[0,3,1]  R356      -0.620816707611084
    z[0,3,1]  R357      -5.4310923814773560e-01
    z[0,3,1]  R358      -4.0189677476882935e-01
    z[0,3,1]  R359      -4.8578220605850220e-01
    z[0,3,1]  R360      -2.4732129275798798e-01
    z[0,3,1]  R361      0.180352121591568
    z[0,3,1]  R362      3.7351536750793457e-01
    z[0,3,1]  R363      0.567589521408081
    z[0,3,1]  R364      4.7279828786849976e-01
    z[0,3,1]  R365      6.7619991302490234e-01
    z[0,3,1]  R366      6.0610163211822510e-01
    z[0,3,1]  R367      5.5915105342864990e-01
    z[0,3,1]  R368      4.4078534841537476e-01
    z[0,3,1]  R369      4.1569101810455322e-01
    z[0,3,1]  R370      4.3550312519073486e-01
    z[0,3,1]  R371      4.0601298213005066e-01
    z[0,3,1]  R372      7.6938372850418091e-01
    z[0,3,1]  R373      7.6927435398101807e-01
    z[0,3,1]  R374      6.8489295244216919e-01
    z[0,3,1]  R375      0.523723304271698
    z[0,3,1]  R376      5.9777599573135376e-01
    z[0,3,1]  R377      5.7301956415176392e-01
    z[0,3,1]  R378      6.8097829818725586e-01
    z[0,3,1]  R379      6.5009635686874390e-01
    z[0,3,1]  R380      0.77623051404953
    z[0,3,1]  R381      0.825904130935669
    z[0,3,1]  R382      5.0051957368850708e-01
    z[0,3,1]  R383      4.6122789382934570e-01
    z[0,3,1]  R384      0.753503680229187
    z[0,3,1]  R385      6.0441082715988159e-01
    z[0,3,1]  R386      6.9407802820205688e-01
    z[0,3,1]  R387      7.0124787092208862e-01
    z[0,3,1]  R388      6.6254991292953491e-01
    z[0,3,1]  R389      4.9700316786766052e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R295      -1
    z[0,3,2]  R296      1
    z[0,3,2]  R305      -7.5585119426250458e-02
    z[0,3,2]  R306      2.4415375292301178e-01
    z[0,3,2]  R307      6.4707857370376587e-01
    z[0,3,2]  R308      2.7240115404129028e-01
    z[0,3,2]  R309      1.0018160194158554e-01
    z[0,3,2]  R310      -1.0218521207571030e-01
    z[0,3,2]  R311      4.6498867869377136e-01
    z[0,3,2]  R312      1.6942533850669861e-01
    z[0,3,2]  R313      -3.0455809831619263e-01
    z[0,3,2]  R314      3.7516161799430847e-01
    z[0,3,2]  R315      1.5947189927101135e-01
    z[0,3,2]  R316      -2.3742966353893280e-01
    z[0,3,2]  R317      4.0666827559471130e-01
    z[0,3,2]  R318      5.1089294254779816e-02
    z[0,3,2]  R319      -2.0245976746082306e-01
    z[0,3,2]  R320      4.5116788148880005e-01
    z[0,3,2]  R321      3.1718626618385315e-01
    z[0,3,2]  R322      -2.2297109663486481e-01
    z[0,3,2]  R323      1.5814979374408722e-01
    z[0,3,2]  R324      -1.4584209024906158e-01
    z[0,3,2]  R325      -4.3707605451345444e-02
    z[0,3,2]  R326      -9.2976361513137817e-02
    z[0,3,2]  R327      -4.3287232518196106e-01
    z[0,3,2]  R328      -1.6613063216209412e-01
    z[0,3,2]  R329      1.5279665589332581e-01
    z[0,3,2]  R330      2.2173093259334564e-01
    z[0,3,2]  R331      -2.2127854824066162e-01
    z[0,3,2]  R332      -1.9176118075847626e-02
    z[0,3,2]  R333      -1.9215150177478790e-01
    z[0,3,2]  R334      -4.6588137745857239e-01
    z[0,3,2]  R335      3.6818632483482361e-01
    z[0,3,2]  R336      1.9580742716789246e-01
    z[0,3,2]  R337      2.5650796294212341e-01
    z[0,3,2]  R338      4.0598914027214050e-01
    z[0,3,2]  R339      5.2883196622133255e-02
    z[0,3,2]  R340      1.0428345762193203e-02
    z[0,3,2]  R341      -1.7387193441390991e-01
    z[0,3,2]  R342      -4.5069187879562378e-01
    z[0,3,2]  R343      0.118861123919487
    z[0,3,2]  R344      4.8090755008161068e-03
    z[0,3,2]  R345      -1.7562119662761688e-01
    z[0,3,2]  R346      -3.9228554815053940e-02
    z[0,3,2]  R347      -5.5179435014724731e-01
    z[0,3,2]  R348      3.6836430430412292e-02
    z[0,3,2]  R349      1.0536435991525650e-01
    z[0,3,2]  R350      -3.7455025315284729e-01
    z[0,3,2]  R351      2.1165508031845093e-01
    z[0,3,2]  R352      2.3400449752807617e-01
    z[0,3,2]  R353      2.4168847501277924e-01
    z[0,3,2]  R354      6.5540504455566406e-01
    z[0,3,2]  R355      2.2956785559654236e-01
    z[0,3,2]  R356      4.2582547664642334e-01
    z[0,3,2]  R357      -1.6568163037300110e-01
    z[0,3,2]  R358      5.4286289215087891e-01
    z[0,3,2]  R359      -5.3863358497619629e-01
    z[0,3,2]  R360      -3.8546475768089294e-01
    z[0,3,2]  R361      4.0814954042434692e-01
    z[0,3,2]  R362      -4.4135829806327820e-01
    z[0,3,2]  R363      2.8477218747138977e-01
    z[0,3,2]  R364      -2.2615494672209024e-03
    z[0,3,2]  R365      3.3404495567083359e-02
    z[0,3,2]  R366      -4.4436094164848328e-01
    z[0,3,2]  R367      0.0140988202765584
    z[0,3,2]  R368      4.9933022260665894e-01
    z[0,3,2]  R369      -1.5091960132122040e-01
    z[0,3,2]  R370      -3.3889949321746826e-01
    z[0,3,2]  R371      2.6863566040992737e-01
    z[0,3,2]  R372      -2.5784516334533691e-01
    z[0,3,2]  R373      1.3406106829643250e-01
    z[0,3,2]  R374      -6.1934594996273518e-03
    z[0,3,2]  R375      3.0340753495693207e-02
    z[0,3,2]  R376      -2.0380338653922081e-02
    z[0,3,2]  R377      1.6603243350982666e-01
    z[0,3,2]  R378      -1.2298868969082832e-02
    z[0,3,2]  R379      1.7190766334533691e-01
    z[0,3,2]  R380      1.2203613668680191e-01
    z[0,3,2]  R381      1.2268714606761932e-01
    z[0,3,2]  R382      2.8339171409606934e-01
    z[0,3,2]  R383      2.9617032408714294e-01
    z[0,3,2]  R384      -1.5018188953399658e-01
    z[0,3,2]  R385      4.4502297043800354e-01
    z[0,3,2]  R386      2.9261613264679909e-02
    z[0,3,2]  R387      -3.6792778968811035e-01
    z[0,3,2]  R388      -2.3362116515636444e-01
    z[0,3,2]  R389      -3.2235378026962280e-01
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R297      -1
    z[0,3,3]  R298      1
    z[0,3,3]  R305      -6.0313421487808228e-01
    z[0,3,3]  R306      -2.6426699757575989e-01
    z[0,3,3]  R307      -4.0811866521835327e-01
    z[0,3,3]  R308      -1.8318356946110725e-02
    z[0,3,3]  R309      -3.3026996254920959e-01
    z[0,3,3]  R310      6.8596608936786652e-02
    z[0,3,3]  R311      -4.8660203814506531e-01
    z[0,3,3]  R312      2.5030849501490593e-02
    z[0,3,3]  R313      1.7117737233638763e-01
    z[0,3,3]  R314      6.2525969743728638e-01
    z[0,3,3]  R315      -2.2083206474781036e-01
    z[0,3,3]  R316      -1.8068033456802368e-01
    z[0,3,3]  R317      1.0851048678159714e-01
    z[0,3,3]  R318      -9.9475458264350891e-02
    z[0,3,3]  R319      -2.8459498286247253e-01
    z[0,3,3]  R320      -0.405542254447937
    z[0,3,3]  R321      0.0989881381392479
    z[0,3,3]  R322      -1.9643209874629974e-02
    z[0,3,3]  R323      -2.3548056185245514e-01
    z[0,3,3]  R324      -4.4133788347244263e-01
    z[0,3,3]  R325      5.6281000375747681e-01
    z[0,3,3]  R326      1.4149080216884613e-01
    z[0,3,3]  R327      7.3939192295074463e-01
    z[0,3,3]  R328      5.2539533376693726e-01
    z[0,3,3]  R329      1.8167947232723236e-01
    z[0,3,3]  R330      2.4998384714126587e-01
    z[0,3,3]  R331      4.9449887871742249e-01
    z[0,3,3]  R332      6.6805613040924072e-01
    z[0,3,3]  R333      5.3257602453231812e-01
    z[0,3,3]  R334      3.0099043250083923e-01
    z[0,3,3]  R335      1.6139744222164154e-01
    z[0,3,3]  R336      2.4999523162841797e-01
    z[0,3,3]  R337      3.2812726497650146e-01
    z[0,3,3]  R338      4.9095913767814636e-01
    z[0,3,3]  R339      4.9335297942161560e-01
    z[0,3,3]  R340      0.771373450756073
    z[0,3,3]  R341      -6.1114239692687988e-01
    z[0,3,3]  R342      -3.4578660130500793e-01
    z[0,3,3]  R343      6.4186424016952515e-01
    z[0,3,3]  R344      6.5114744007587433e-02
    z[0,3,3]  R345      3.3785501122474670e-01
    z[0,3,3]  R346      5.6813359260559082e-01
    z[0,3,3]  R347      -3.4559237957000732e-01
    z[0,3,3]  R348      -7.2367310523986816e-01
    z[0,3,3]  R349      2.1732898056507111e-01
    z[0,3,3]  R350      3.1666469573974609e-01
    z[0,3,3]  R351      -1.6486048698425293e-01
    z[0,3,3]  R352      -1.4926570653915405e-01
    z[0,3,3]  R353      -7.3794215917587280e-01
    z[0,3,3]  R354      -4.1002565622329712e-01
    z[0,3,3]  R355      -1.6177067160606384e-01
    z[0,3,3]  R356      -2.6279929280281067e-01
    z[0,3,3]  R357      -2.6221841573715210e-01
    z[0,3,3]  R358      1.3024370372295380e-01
    z[0,3,3]  R359      -3.8735681772232056e-01
    z[0,3,3]  R360      -2.7802714705467224e-01
    z[0,3,3]  R361      -2.8050836920738220e-01
    z[0,3,3]  R362      -4.0410766005516052e-01
    z[0,3,3]  R363      1.2843927368521690e-02
    z[0,3,3]  R364      -6.5263265371322632e-01
    z[0,3,3]  R365      4.4501677155494690e-01
    z[0,3,3]  R366      4.9889558553695679e-01
    z[0,3,3]  R367      4.7653332352638245e-01
    z[0,3,3]  R368      4.1545253992080688e-01
    z[0,3,3]  R369      4.8808595538139343e-01
    z[0,3,3]  R370      4.2026409506797791e-01
    z[0,3,3]  R371      1.4036716520786285e-01
    z[0,3,3]  R372      2.2125220298767090e-01
    z[0,3,3]  R373      5.8147305250167847e-01
    z[0,3,3]  R374      4.7862425446510315e-01
    z[0,3,3]  R375      4.2620095610618591e-01
    z[0,3,3]  R376      5.0037211179733276e-01
    z[0,3,3]  R377      5.6852996349334717e-01
    z[0,3,3]  R378      5.5031090974807739e-01
    z[0,3,3]  R379      3.2639884948730469e-01
    z[0,3,3]  R380      3.2783108949661255e-01
    z[0,3,3]  R381      3.9959990978240967e-01
    z[0,3,3]  R382      5.1531338691711426e-01
    z[0,3,3]  R383      2.4345543980598450e-01
    z[0,3,3]  R384      2.5134083628654480e-01
    z[0,3,3]  R385      3.5491314530372620e-01
    z[0,3,3]  R386      3.9876180887222290e-01
    z[0,3,3]  R387      2.8322747349739075e-01
    z[0,3,3]  R388      5.1692402362823486e-01
    z[0,3,3]  R389      5.1157861948013306e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R299      -1
    z[0,3,4]  R300      1
    z[0,3,4]  R305      -7.7204527333378792e-03
    z[0,3,4]  R306      4.5496243983507156e-02
    z[0,3,4]  R307      -3.1085941195487976e-01
    z[0,3,4]  R308      -6.0165543109178543e-02
    z[0,3,4]  R309      -1.1988577991724014e-01
    z[0,3,4]  R310      -8.8058109395205975e-04
    z[0,3,4]  R311      -1.5633161365985870e-01
    z[0,3,4]  R312      2.2820717096328735e-01
    z[0,3,4]  R313      -0.0789557546377182
    z[0,3,4]  R314      -3.4042972326278687e-01
    z[0,3,4]  R315      8.3188056945800781e-02
    z[0,3,4]  R316      3.5270789265632629e-01
    z[0,3,4]  R317      0.625708818435669
    z[0,3,4]  R318      4.3101277947425842e-01
    z[0,3,4]  R319      0.0524633526802063
    z[0,3,4]  R320      -8.2717090845108032e-02
    z[0,3,4]  R321      5.2935957908630371e-02
    z[0,3,4]  R322      1.2602145969867706e-01
    z[0,3,4]  R323      4.1201531887054443e-02
    z[0,3,4]  R324      1.8331001698970795e-01
    z[0,3,4]  R325      5.5005115270614624e-01
    z[0,3,4]  R326      -1.6806045174598694e-01
    z[0,3,4]  R327      2.3589572310447693e-01
    z[0,3,4]  R328      5.1857888698577881e-01
    z[0,3,4]  R329      3.3163938671350479e-02
    z[0,3,4]  R330      -3.9490621536970139e-02
    z[0,3,4]  R331      2.5820270180702209e-01
    z[0,3,4]  R332      2.3370358347892761e-01
    z[0,3,4]  R333      -6.8685412406921387e-02
    z[0,3,4]  R334      -1.0905279964208603e-01
    z[0,3,4]  R335      -4.2552232742309570e-02
    z[0,3,4]  R336      4.1010481119155884e-01
    z[0,3,4]  R337      2.1401986479759216e-01
    z[0,3,4]  R338      2.1495439112186432e-01
    z[0,3,4]  R339      2.3247393965721130e-01
    z[0,3,4]  R340      -8.0415733158588409e-02
    z[0,3,4]  R341      4.5572139322757721e-02
    z[0,3,4]  R342      3.4023562073707581e-01
    z[0,3,4]  R343      -1.7753715813159943e-01
    z[0,3,4]  R344      1.1264232546091080e-01
    z[0,3,4]  R345      -1.6377037763595581e-01
    z[0,3,4]  R346      -3.1421598792076111e-01
    z[0,3,4]  R347      2.8071027994155884e-01
    z[0,3,4]  R348      2.8293186426162720e-01
    z[0,3,4]  R349      6.4598284661769867e-02
    z[0,3,4]  R350      2.4649754166603088e-01
    z[0,3,4]  R351      -1.2283524870872498e-01
    z[0,3,4]  R352      2.3887798190116882e-01
    z[0,3,4]  R353      2.6853394508361816e-01
    z[0,3,4]  R354      -4.5189116150140762e-02
    z[0,3,4]  R355      -6.5339556895196438e-03
    z[0,3,4]  R356      1.4562240242958069e-01
    z[0,3,4]  R357      4.8759466409683228e-01
    z[0,3,4]  R358      -5.0998383760452271e-01
    z[0,3,4]  R359      2.5875428691506386e-02
    z[0,3,4]  R360      -2.5735804438591003e-01
    z[0,3,4]  R361      -7.9946219921112061e-04
    z[0,3,4]  R362      8.2271791994571686e-02
    z[0,3,4]  R363      3.3132830262184143e-01
    z[0,3,4]  R364      2.3930130898952484e-01
    z[0,3,4]  R365      3.3419987559318542e-01
    z[0,3,4]  R366      1.1739798635244370e-01
    z[0,3,4]  R367      5.4334950447082520e-01
    z[0,3,4]  R368      2.1896690130233765e-01
    z[0,3,4]  R369      5.0954711437225342e-01
    z[0,3,4]  R370      -2.7300122380256653e-01
    z[0,3,4]  R371      1.1436348408460617e-01
    z[0,3,4]  R372      -6.5126776695251465e-02
    z[0,3,4]  R373      3.4790221601724625e-02
    z[0,3,4]  R374      -1.4352890849113464e-01
    z[0,3,4]  R375      1.5856587886810303e-01
    z[0,3,4]  R376      -0.129226416349411
    z[0,3,4]  R377      2.1101680397987366e-01
    z[0,3,4]  R378      2.0117874443531036e-01
    z[0,3,4]  R379      -3.3486044406890869e-01
    z[0,3,4]  R380      -1.0937442071735859e-02
    z[0,3,4]  R381      -1.2377080321311951e-01
    z[0,3,4]  R382      -5.8204419910907745e-02
    z[0,3,4]  R383      -7.0177665911614895e-03
    z[0,3,4]  R384      -1.3035634160041809e-01
    z[0,3,4]  R385      -1.9441822543740273e-02
    z[0,3,4]  R386      -9.7734019160270691e-02
    z[0,3,4]  R387      2.4935714900493622e-01
    z[0,3,4]  R388      1.0530297458171844e-01
    z[0,3,4]  R389      1.9780211150646210e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R301      -1
    z[0,3,5]  R302      1
    z[0,3,5]  R305      3.5248550772666931e-01
    z[0,3,5]  R306      -1.8579567968845367e-01
    z[0,3,5]  R307      -1.3986136019229889e-01
    z[0,3,5]  R308      3.4295409917831421e-01
    z[0,3,5]  R309      -3.0872318148612976e-01
    z[0,3,5]  R310      3.6392825841903687e-01
    z[0,3,5]  R311      2.9768466949462891e-01
    z[0,3,5]  R312      -2.5655742734670639e-02
    z[0,3,5]  R313      0.0423213467001915
    z[0,3,5]  R314      -2.7284887433052063e-01
    z[0,3,5]  R315      -1.4773845672607422e-01
    z[0,3,5]  R316      -0.156717449426651
    z[0,3,5]  R317      1.5973153710365295e-01
    z[0,3,5]  R318      2.8820648789405823e-01
    z[0,3,5]  R319      8.1712851533666253e-04
    z[0,3,5]  R320      -4.1467282921075821e-02
    z[0,3,5]  R321      2.6289626955986023e-01
    z[0,3,5]  R322      -1.0409022122621536e-01
    z[0,3,5]  R323      0.084237240254879
    z[0,3,5]  R324      -4.5615535974502563e-01
    z[0,3,5]  R325      -1.3084410130977631e-01
    z[0,3,5]  R326      -2.8830143809318542e-01
    z[0,3,5]  R327      -0.164118230342865
    z[0,3,5]  R328      -1.4126639068126678e-01
    z[0,3,5]  R329      -5.7881736755371094e-01
    z[0,3,5]  R330      -2.4380034208297729e-01
    z[0,3,5]  R331      -4.7147154808044434e-01
    z[0,3,5]  R332      7.7939346432685852e-02
    z[0,3,5]  R333      3.9999324083328247e-01
    z[0,3,5]  R334      -7.4565164744853973e-02
    z[0,3,5]  R335      -3.2411959767341614e-01
    z[0,3,5]  R336      -3.5526511073112488e-01
    z[0,3,5]  R337      -5.4933613538742065e-01
    z[0,3,5]  R338      1.6533279418945312e-01
    z[0,3,5]  R339      2.3109537363052368e-01
    z[0,3,5]  R340      -2.4901962280273438e-01
    z[0,3,5]  R341      -4.3133646249771118e-01
    z[0,3,5]  R342      -3.3600360155105591e-01
    z[0,3,5]  R343      3.9849165081977844e-01
    z[0,3,5]  R344      5.0299203395843506e-01
    z[0,3,5]  R345      -4.7456416487693787e-01
    z[0,3,5]  R346      2.3958018422126770e-01
    z[0,3,5]  R347      -6.1677344143390656e-02
    z[0,3,5]  R348      -4.3604883551597595e-01
    z[0,3,5]  R349      -1.0302336513996124e-01
    z[0,3,5]  R350      -1.4970052242279053e-01
    z[0,3,5]  R351      3.0528476834297180e-01
    z[0,3,5]  R352      -2.1967029571533203e-01
    z[0,3,5]  R353      -7.0856891572475433e-02
    z[0,3,5]  R354      -3.5500779747962952e-01
    z[0,3,5]  R355      -2.5043833255767822e-01
    z[0,3,5]  R356      3.2815396785736084e-01
    z[0,3,5]  R357      5.5406481027603149e-02
    z[0,3,5]  R358      3.8574171066284180e-01
    z[0,3,5]  R359      4.4239467382431030e-01
    z[0,3,5]  R360      -2.3063258826732635e-01
    z[0,3,5]  R361      -1.5647193789482117e-01
    z[0,3,5]  R362      2.8870645165443420e-01
    z[0,3,5]  R363      -5.2633565664291382e-01
    z[0,3,5]  R364      -0.297408789396286
    z[0,3,5]  R365      1.8562559783458710e-01
    z[0,3,5]  R366      4.2010764591395855e-03
    z[0,3,5]  R367      -8.6681410670280457e-02
    z[0,3,5]  R368      9.7037024796009064e-02
    z[0,3,5]  R369      -7.6643405482172966e-03
    z[0,3,5]  R370      1.8124409019947052e-01
    z[0,3,5]  R371      3.4569692611694336e-01
    z[0,3,5]  R372      3.8990718126296997e-01
    z[0,3,5]  R373      -1.4692430198192596e-01
    z[0,3,5]  R374      -4.0169146656990051e-01
    z[0,3,5]  R375      -2.1082855761051178e-01
    z[0,3,5]  R376      -5.7908255606889725e-02
    z[0,3,5]  R377      -2.6901489496231079e-01
    z[0,3,5]  R378      -1.2342879176139832e-01
    z[0,3,5]  R379      -1.8436795473098755e-01
    z[0,3,5]  R380      -1.7887786030769348e-01
    z[0,3,5]  R381      8.9686758816242218e-02
    z[0,3,5]  R382      -1.9222494959831238e-01
    z[0,3,5]  R383      -4.6440163254737854e-01
    z[0,3,5]  R384      -1.4157579839229584e-01
    z[0,3,5]  R385      2.7153030037879944e-01
    z[0,3,5]  R386      5.4672157764434814e-01
    z[0,3,5]  R387      2.2526112198829651e-01
    z[0,3,5]  R388      -3.9854088425636292e-01
    z[0,3,5]  R389      2.8633320331573486e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R303      -1
    z[0,3,6]  R304      1
    z[0,3,6]  R305      -1.6835945844650269e-01
    z[0,3,6]  R306      3.8516694307327271e-01
    z[0,3,6]  R307      -1.2514501810073853e-01
    z[0,3,6]  R308      -3.1389329582452774e-02
    z[0,3,6]  R309      -6.5383620560169220e-02
    z[0,3,6]  R310      6.4385667443275452e-02
    z[0,3,6]  R311      4.2391490936279297e-01
    z[0,3,6]  R312      -3.4991465508937836e-02
    z[0,3,6]  R313      -1.1311710625886917e-01
    z[0,3,6]  R314      -4.8196125775575638e-02
    z[0,3,6]  R315      8.2779310643672943e-02
    z[0,3,6]  R316      0.105648472905159
    z[0,3,6]  R317      1.4468035101890564e-01
    z[0,3,6]  R318      1.3364803791046143e-01
    z[0,3,6]  R319      -6.4286895096302032e-02
    z[0,3,6]  R320      2.1512460708618164e-01
    z[0,3,6]  R321      -1.1096056550741196e-01
    z[0,3,6]  R322      -2.8705963492393494e-01
    z[0,3,6]  R323      -0.242411807179451
    z[0,3,6]  R324      7.9782538115978241e-02
    z[0,3,6]  R325      -2.0963051915168762e-01
    z[0,3,6]  R326      -2.1987858414649963e-01
    z[0,3,6]  R327      -0.091742604970932
    z[0,3,6]  R328      -1.2191002815961838e-01
    z[0,3,6]  R329      4.2908000946044922e-01
    z[0,3,6]  R330      -7.1778148412704468e-01
    z[0,3,6]  R331      2.4404789507389069e-01
    z[0,3,6]  R332      0.525579035282135
    z[0,3,6]  R333      -3.0778363347053528e-01
    z[0,3,6]  R334      1.0134135931730270e-01
    z[0,3,6]  R335      -1.8911491334438324e-01
    z[0,3,6]  R336      1.5260358154773712e-01
    z[0,3,6]  R337      -2.1925979852676392e-01
    z[0,3,6]  R338      2.7590745687484741e-01
    z[0,3,6]  R339      0.0811280682682991
    z[0,3,6]  R340      3.1139880418777466e-01
    z[0,3,6]  R341      2.9627183079719543e-01
    z[0,3,6]  R342      -2.8173670172691345e-01
    z[0,3,6]  R343      -1.9948931038379669e-01
    z[0,3,6]  R344      0.273754358291626
    z[0,3,6]  R345      -2.8750661015510559e-01
    z[0,3,6]  R346      8.4515912458300591e-03
    z[0,3,6]  R347      2.9808378219604492e-01
    z[0,3,6]  R348      4.3686878681182861e-01
    z[0,3,6]  R349      -2.1537633240222931e-01
    z[0,3,6]  R350      0.579052209854126
    z[0,3,6]  R351      2.7095130085945129e-01
    z[0,3,6]  R352      3.4633249044418335e-01
    z[0,3,6]  R353      7.9971216619014740e-02
    z[0,3,6]  R354      -1.1906320601701736e-01
    z[0,3,6]  R355      2.8108218312263489e-01
    z[0,3,6]  R356      4.1452851891517639e-01
    z[0,3,6]  R357      -2.2867612540721893e-01
    z[0,3,6]  R358      -3.4304666519165039e-01
    z[0,3,6]  R359      -1.9419296085834503e-01
    z[0,3,6]  R360      -5.6261980533599854e-01
    z[0,3,6]  R361      -6.5677899122238159e-01
    z[0,3,6]  R362      5.5055910348892212e-01
    z[0,3,6]  R363      3.1478923559188843e-01
    z[0,3,6]  R364      4.2554289102554321e-01
    z[0,3,6]  R365      -2.0609997212886810e-01
    z[0,3,6]  R366      1.0976740717887878e-01
    z[0,3,6]  R367      -2.0024146139621735e-01
    z[0,3,6]  R368      1.7138667404651642e-02
    z[0,3,6]  R369      1.4539824426174164e-01
    z[0,3,6]  R370      -1.9080650061368942e-02
    z[0,3,6]  R371      -3.4737512469291687e-02
    z[0,3,6]  R372      -9.4156764447689056e-02
    z[0,3,6]  R373      -8.4076039493083954e-02
    z[0,3,6]  R374      4.7083523124456406e-02
    z[0,3,6]  R375      3.0754547566175461e-02
    z[0,3,6]  R376      1.2262330204248428e-01
    z[0,3,6]  R377      -8.0017736181616783e-03
    z[0,3,6]  R378      1.6017764806747437e-01
    z[0,3,6]  R379      -0.129512757062912
    z[0,3,6]  R380      -3.3758670091629028e-01
    z[0,3,6]  R381      8.1064760684967041e-02
    z[0,3,6]  R382      -3.6736443638801575e-01
    z[0,3,6]  R383      -3.8917452096939087e-01
    z[0,3,6]  R384      -0.1804189234972
    z[0,3,6]  R385      2.7841767668724060e-01
    z[0,3,6]  R386      1.7514521256089211e-02
    z[0,3,6]  R387      -1.7323812842369080e-01
    z[0,3,6]  R388      -0.185040682554245
    z[0,3,6]  R389      5.1151943206787109e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R390      -1
    z[3,0,0]  R391      1
    z[3,0,0]  R404      1.8530371785163879e-01
    z[3,0,0]  R405      -2.5193458795547485e-01
    z[3,0,0]  R406      -5.6188285350799561e-01
    z[3,0,0]  R407      1.5947241336107254e-02
    z[3,0,0]  R408      2.9958420991897583e-01
    z[3,0,0]  R409      0.526293158531189
    z[3,0,0]  R410      -5.1610004901885986e-01
    z[3,0,0]  R411      -3.3037957549095154e-01
    z[3,0,0]  R412      3.0317434668540955e-01
    z[3,0,0]  R413      3.3268904685974121e-01
    z[3,0,0]  R414      0.154024139046669
    z[3,0,0]  R415      3.9366778731346130e-01
    z[3,0,0]  R416      4.0054762363433838e-01
    z[3,0,0]  R417      3.4238618612289429e-01
    z[3,0,0]  R418      5.7106947898864746e-01
    z[3,0,0]  R419      5.3418982028961182e-01
    z[3,0,0]  R420      6.4118576049804688e-01
    z[3,0,0]  R421      7.8070056438446045e-01
    z[3,0,0]  R422      3.5703986883163452e-01
    z[3,0,0]  R423      -1.4922395348548889e-01
    z[3,0,0]  R424      3.4297034144401550e-01
    z[3,0,0]  R425      6.8746519088745117e-01
    z[3,0,0]  R426      5.9731644392013550e-01
    z[3,0,0]  R427      0.451546847820282
    z[3,0,0]  R428      3.8975724577903748e-01
    z[3,0,0]  R429      5.2762645483016968e-01
    z[3,0,0]  R430      0.359191358089447
    z[3,0,0]  R431      3.3647558093070984e-01
    z[3,0,0]  R432      4.7783535718917847e-01
    z[3,0,0]  R433      5.2259588241577148e-01
    z[3,0,0]  R434      5.2622985839843750e-01
    z[3,0,0]  R435      -3.9881786704063416e-01
    z[3,0,0]  R436      -2.2276766598224640e-01
    z[3,0,0]  R437      -3.8694933056831360e-01
    z[3,0,0]  R438      -1.8728250265121460e-01
    z[3,0,0]  R439      -6.7813791334629059e-02
    z[3,0,0]  R440      2.3218529298901558e-02
    z[3,0,0]  R441      2.6585500687360764e-02
    z[3,0,0]  R442      7.1294128894805908e-02
    z[3,0,0]  R443      -2.7335685491561890e-01
    z[3,0,0]  R444      3.5928568243980408e-01
    z[3,0,0]  R445      5.9883729554712772e-03
    z[3,0,0]  R446      9.2439334839582443e-03
    z[3,0,0]  R447      -5.6336027383804321e-01
    z[3,0,0]  R448      4.0163779258728027e-01
    z[3,0,0]  R449      7.8471505641937256e-01
    z[3,0,0]  R450      0.381783664226532
    z[3,0,0]  R451      3.5267886519432068e-01
    z[3,0,0]  R452      2.9792514443397522e-01
    z[3,0,0]  R453      0.076849564909935
    z[3,0,0]  R454      -1.4367805421352386e-01
    z[3,0,0]  R455      -6.4512050151824951e-01
    z[3,0,0]  R456      -1.4328041672706604e-01
    z[3,0,0]  R457      -3.8182201981544495e-01
    z[3,0,0]  R458      8.9524544775485992e-02
    z[3,0,0]  R459      1.5060995519161224e-01
    z[3,0,0]  R460      3.7041693925857544e-01
    z[3,0,0]  R461      2.2597697377204895e-01
    z[3,0,0]  R462      0.567455530166626
    z[3,0,0]  R463      1.5902924537658691e-01
    z[3,0,0]  R464      4.2210280895233154e-01
    z[3,0,0]  R465      -8.5973076522350311e-02
    z[3,0,0]  R466      2.6575249433517456e-01
    z[3,0,0]  R467      5.2248769998550415e-01
    z[3,0,0]  R468      6.5832680463790894e-01
    z[3,0,0]  R469      3.6908453702926636e-01
    z[3,0,0]  R470      4.6946355700492859e-01
    z[3,0,0]  R471      5.7255238294601440e-01
    z[3,0,0]  R472      4.2565661668777466e-01
    z[3,0,0]  R473      1.0079831629991531e-01
    z[3,0,0]  R474      2.0305563509464264e-01
    z[3,0,0]  R475      5.4893147945404053e-01
    z[3,0,0]  R476      -5.2610252052545547e-02
    z[3,0,0]  R477      2.1409960091114044e-01
    z[3,0,0]  R478      4.1114953160285950e-01
    z[3,0,0]  R479      5.8458864688873291e-01
    z[3,0,0]  R480      3.7280049920082092e-01
    z[3,0,0]  R481      2.8200241923332214e-01
    z[3,0,0]  R482      -4.1353516280651093e-02
    z[3,0,0]  R483      -3.7106537818908691e-01
    z[3,0,0]  R484      1.2341576069593430e-01
    z[3,0,0]  R485      -2.1269651129841805e-02
    z[3,0,0]  R486      -4.4928431510925293e-01
    z[3,0,0]  R487      -5.3979802131652832e-01
    z[3,0,0]  R488      -3.9149722456932068e-01
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R392      -1
    z[3,0,1]  R393      1
    z[3,0,1]  R404      -8.6314660310745239e-01
    z[3,0,1]  R405      -0.620816707611084
    z[3,0,1]  R406      -5.4310923814773560e-01
    z[3,0,1]  R407      -4.0189677476882935e-01
    z[3,0,1]  R408      -4.8578220605850220e-01
    z[3,0,1]  R409      -2.4732129275798798e-01
    z[3,0,1]  R410      0.180352121591568
    z[3,0,1]  R411      3.7351536750793457e-01
    z[3,0,1]  R412      4.2863461375236511e-01
    z[3,0,1]  R413      0.567589521408081
    z[3,0,1]  R414      4.7279828786849976e-01
    z[3,0,1]  R415      6.7619991302490234e-01
    z[3,0,1]  R416      6.0610163211822510e-01
    z[3,0,1]  R417      5.5915105342864990e-01
    z[3,0,1]  R418      4.4078534841537476e-01
    z[3,0,1]  R419      4.1569101810455322e-01
    z[3,0,1]  R420      4.3550312519073486e-01
    z[3,0,1]  R421      4.0601298213005066e-01
    z[3,0,1]  R422      7.6938372850418091e-01
    z[3,0,1]  R423      7.6927435398101807e-01
    z[3,0,1]  R424      6.8489295244216919e-01
    z[3,0,1]  R425      0.523723304271698
    z[3,0,1]  R426      5.9777599573135376e-01
    z[3,0,1]  R427      5.7301956415176392e-01
    z[3,0,1]  R428      6.8097829818725586e-01
    z[3,0,1]  R429      6.5009635686874390e-01
    z[3,0,1]  R430      0.77623051404953
    z[3,0,1]  R431      0.825904130935669
    z[3,0,1]  R432      5.0051957368850708e-01
    z[3,0,1]  R433      4.6122789382934570e-01
    z[3,0,1]  R434      0.753503680229187
    z[3,0,1]  R435      6.0441082715988159e-01
    z[3,0,1]  R436      6.9407802820205688e-01
    z[3,0,1]  R437      7.0124787092208862e-01
    z[3,0,1]  R438      6.6254991292953491e-01
    z[3,0,1]  R439      4.9700316786766052e-01
    z[3,0,1]  R440      -6.9088816642761230e-01
    z[3,0,1]  R441      -8.2758784294128418e-01
    z[3,0,1]  R442      -5.2705746889114380e-01
    z[3,0,1]  R443      -8.5353112220764160e-01
    z[3,0,1]  R444      -7.9864984750747681e-01
    z[3,0,1]  R445      -9.2099231481552124e-01
    z[3,0,1]  R446      -5.0414168834686279e-01
    z[3,0,1]  R447      -7.7416580915451050e-01
    z[3,0,1]  R448      -8.3415180444717407e-01
    z[3,0,1]  R449      5.2385592460632324e-01
    z[3,0,1]  R450      7.7788054943084717e-01
    z[3,0,1]  R451      5.1039779186248779e-01
    z[3,0,1]  R452      0.782328724861145
    z[3,0,1]  R453      9.3017423152923584e-01
    z[3,0,1]  R454      7.4598878622055054e-01
    z[3,0,1]  R455      6.2384688854217529e-01
    z[3,0,1]  R456      9.0567612648010254e-01
    z[3,0,1]  R457      8.4035253524780273e-01
    z[3,0,1]  R458      7.2656100988388062e-01
    z[3,0,1]  R459      0.54316645860672
    z[3,0,1]  R460      8.2122975587844849e-01
    z[3,0,1]  R461      3.5193365812301636e-01
    z[3,0,1]  R462      2.6572963595390320e-01
    z[3,0,1]  R463      6.3096469640731812e-01
    z[3,0,1]  R464      3.6601129174232483e-01
    z[3,0,1]  R465      5.9211635589599609e-01
    z[3,0,1]  R466      3.8181629776954651e-01
    z[3,0,1]  R467      3.8341113924980164e-01
    z[3,0,1]  R468      4.8087698221206665e-01
    z[3,0,1]  R469      7.4802255630493164e-01
    z[3,0,1]  R470      0.600898265838623
    z[3,0,1]  R471      3.2104572653770447e-01
    z[3,0,1]  R472      5.1311117410659790e-01
    z[3,0,1]  R473      0.793482780456543
    z[3,0,1]  R474      4.4519197940826416e-01
    z[3,0,1]  R475      -1.3799582421779633e-01
    z[3,0,1]  R476      -0.605397641658783
    z[3,0,1]  R477      5.4583203792572021e-01
    z[3,0,1]  R478      6.9718170166015625e-01
    z[3,0,1]  R479      4.2258173227310181e-01
    z[3,0,1]  R480      6.1684954166412354e-01
    z[3,0,1]  R481      -5.7018172740936279e-01
    z[3,0,1]  R482      1.1039377748966217e-01
    z[3,0,1]  R483      8.6186027526855469e-01
    z[3,0,1]  R484      5.7072877883911133e-01
    z[3,0,1]  R485      8.6363697052001953e-01
    z[3,0,1]  R486      7.0416003465652466e-01
    z[3,0,1]  R487      1.4872631430625916e-01
    z[3,0,1]  R488      3.2680952548980713e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R394      -1
    z[3,0,2]  R395      1
    z[3,0,2]  R404      2.2956785559654236e-01
    z[3,0,2]  R405      4.2582547664642334e-01
    z[3,0,2]  R406      -1.6568163037300110e-01
    z[3,0,2]  R407      5.4286289215087891e-01
    z[3,0,2]  R408      -5.3863358497619629e-01
    z[3,0,2]  R409      -3.8546475768089294e-01
    z[3,0,2]  R410      4.0814954042434692e-01
    z[3,0,2]  R411      -4.4135829806327820e-01
    z[3,0,2]  R412      3.7516161799430847e-01
    z[3,0,2]  R413      2.8477218747138977e-01
    z[3,0,2]  R414      -2.2615494672209024e-03
    z[3,0,2]  R415      3.3404495567083359e-02
    z[3,0,2]  R416      -4.4436094164848328e-01
    z[3,0,2]  R417      0.0140988202765584
    z[3,0,2]  R418      4.9933022260665894e-01
    z[3,0,2]  R419      -1.5091960132122040e-01
    z[3,0,2]  R420      -3.3889949321746826e-01
    z[3,0,2]  R421      2.6863566040992737e-01
    z[3,0,2]  R422      -2.5784516334533691e-01
    z[3,0,2]  R423      1.3406106829643250e-01
    z[3,0,2]  R424      -6.1934594996273518e-03
    z[3,0,2]  R425      3.0340753495693207e-02
    z[3,0,2]  R426      -2.0380338653922081e-02
    z[3,0,2]  R427      1.6603243350982666e-01
    z[3,0,2]  R428      -1.2298868969082832e-02
    z[3,0,2]  R429      1.7190766334533691e-01
    z[3,0,2]  R430      1.2203613668680191e-01
    z[3,0,2]  R431      1.2268714606761932e-01
    z[3,0,2]  R432      2.8339171409606934e-01
    z[3,0,2]  R433      2.9617032408714294e-01
    z[3,0,2]  R434      -1.5018188953399658e-01
    z[3,0,2]  R435      4.4502297043800354e-01
    z[3,0,2]  R436      2.9261613264679909e-02
    z[3,0,2]  R437      -3.6792778968811035e-01
    z[3,0,2]  R438      -2.3362116515636444e-01
    z[3,0,2]  R439      -3.2235378026962280e-01
    z[3,0,2]  R440      -7.5585119426250458e-02
    z[3,0,2]  R441      2.4415375292301178e-01
    z[3,0,2]  R442      6.4707857370376587e-01
    z[3,0,2]  R443      2.7240115404129028e-01
    z[3,0,2]  R444      1.0018160194158554e-01
    z[3,0,2]  R445      -1.0218521207571030e-01
    z[3,0,2]  R446      4.6498867869377136e-01
    z[3,0,2]  R447      1.6942533850669861e-01
    z[3,0,2]  R448      -3.0455809831619263e-01
    z[3,0,2]  R449      1.5947189927101135e-01
    z[3,0,2]  R450      -2.3742966353893280e-01
    z[3,0,2]  R451      4.0666827559471130e-01
    z[3,0,2]  R452      5.1089294254779816e-02
    z[3,0,2]  R453      -2.0245976746082306e-01
    z[3,0,2]  R454      4.5116788148880005e-01
    z[3,0,2]  R455      3.1718626618385315e-01
    z[3,0,2]  R456      -2.2297109663486481e-01
    z[3,0,2]  R457      1.5814979374408722e-01
    z[3,0,2]  R458      -1.4584209024906158e-01
    z[3,0,2]  R459      -4.3707605451345444e-02
    z[3,0,2]  R460      -9.2976361513137817e-02
    z[3,0,2]  R461      -4.3287232518196106e-01
    z[3,0,2]  R462      -1.6613063216209412e-01
    z[3,0,2]  R463      1.5279665589332581e-01
    z[3,0,2]  R464      2.2173093259334564e-01
    z[3,0,2]  R465      -2.2127854824066162e-01
    z[3,0,2]  R466      -1.9176118075847626e-02
    z[3,0,2]  R467      -1.9215150177478790e-01
    z[3,0,2]  R468      -4.6588137745857239e-01
    z[3,0,2]  R469      3.6818632483482361e-01
    z[3,0,2]  R470      1.9580742716789246e-01
    z[3,0,2]  R471      2.5650796294212341e-01
    z[3,0,2]  R472      4.0598914027214050e-01
    z[3,0,2]  R473      5.2883196622133255e-02
    z[3,0,2]  R474      1.0428345762193203e-02
    z[3,0,2]  R475      -1.7387193441390991e-01
    z[3,0,2]  R476      -4.5069187879562378e-01
    z[3,0,2]  R477      0.118861123919487
    z[3,0,2]  R478      4.8090755008161068e-03
    z[3,0,2]  R479      -1.7562119662761688e-01
    z[3,0,2]  R480      -3.9228554815053940e-02
    z[3,0,2]  R481      -5.5179435014724731e-01
    z[3,0,2]  R482      3.6836430430412292e-02
    z[3,0,2]  R483      1.0536435991525650e-01
    z[3,0,2]  R484      -3.7455025315284729e-01
    z[3,0,2]  R485      2.1165508031845093e-01
    z[3,0,2]  R486      2.3400449752807617e-01
    z[3,0,2]  R487      2.4168847501277924e-01
    z[3,0,2]  R488      6.5540504455566406e-01
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R396      -1
    z[3,0,3]  R397      1
    z[3,0,3]  R404      -1.6177067160606384e-01
    z[3,0,3]  R405      -2.6279929280281067e-01
    z[3,0,3]  R406      -2.6221841573715210e-01
    z[3,0,3]  R407      1.3024370372295380e-01
    z[3,0,3]  R408      -3.8735681772232056e-01
    z[3,0,3]  R409      -2.7802714705467224e-01
    z[3,0,3]  R410      -2.8050836920738220e-01
    z[3,0,3]  R411      -4.0410766005516052e-01
    z[3,0,3]  R412      6.2525969743728638e-01
    z[3,0,3]  R413      1.2843927368521690e-02
    z[3,0,3]  R414      -6.5263265371322632e-01
    z[3,0,3]  R415      4.4501677155494690e-01
    z[3,0,3]  R416      4.9889558553695679e-01
    z[3,0,3]  R417      4.7653332352638245e-01
    z[3,0,3]  R418      4.1545253992080688e-01
    z[3,0,3]  R419      4.8808595538139343e-01
    z[3,0,3]  R420      4.2026409506797791e-01
    z[3,0,3]  R421      1.4036716520786285e-01
    z[3,0,3]  R422      2.2125220298767090e-01
    z[3,0,3]  R423      5.8147305250167847e-01
    z[3,0,3]  R424      4.7862425446510315e-01
    z[3,0,3]  R425      4.2620095610618591e-01
    z[3,0,3]  R426      5.0037211179733276e-01
    z[3,0,3]  R427      5.6852996349334717e-01
    z[3,0,3]  R428      5.5031090974807739e-01
    z[3,0,3]  R429      3.2639884948730469e-01
    z[3,0,3]  R430      3.2783108949661255e-01
    z[3,0,3]  R431      3.9959990978240967e-01
    z[3,0,3]  R432      5.1531338691711426e-01
    z[3,0,3]  R433      2.4345543980598450e-01
    z[3,0,3]  R434      2.5134083628654480e-01
    z[3,0,3]  R435      3.5491314530372620e-01
    z[3,0,3]  R436      3.9876180887222290e-01
    z[3,0,3]  R437      2.8322747349739075e-01
    z[3,0,3]  R438      5.1692402362823486e-01
    z[3,0,3]  R439      5.1157861948013306e-01
    z[3,0,3]  R440      -6.0313421487808228e-01
    z[3,0,3]  R441      -2.6426699757575989e-01
    z[3,0,3]  R442      -4.0811866521835327e-01
    z[3,0,3]  R443      -1.8318356946110725e-02
    z[3,0,3]  R444      -3.3026996254920959e-01
    z[3,0,3]  R445      6.8596608936786652e-02
    z[3,0,3]  R446      -4.8660203814506531e-01
    z[3,0,3]  R447      2.5030849501490593e-02
    z[3,0,3]  R448      1.7117737233638763e-01
    z[3,0,3]  R449      -2.2083206474781036e-01
    z[3,0,3]  R450      -1.8068033456802368e-01
    z[3,0,3]  R451      1.0851048678159714e-01
    z[3,0,3]  R452      -9.9475458264350891e-02
    z[3,0,3]  R453      -2.8459498286247253e-01
    z[3,0,3]  R454      -0.405542254447937
    z[3,0,3]  R455      0.0989881381392479
    z[3,0,3]  R456      -1.9643209874629974e-02
    z[3,0,3]  R457      -2.3548056185245514e-01
    z[3,0,3]  R458      -4.4133788347244263e-01
    z[3,0,3]  R459      5.6281000375747681e-01
    z[3,0,3]  R460      1.4149080216884613e-01
    z[3,0,3]  R461      7.3939192295074463e-01
    z[3,0,3]  R462      5.2539533376693726e-01
    z[3,0,3]  R463      1.8167947232723236e-01
    z[3,0,3]  R464      2.4998384714126587e-01
    z[3,0,3]  R465      4.9449887871742249e-01
    z[3,0,3]  R466      6.6805613040924072e-01
    z[3,0,3]  R467      5.3257602453231812e-01
    z[3,0,3]  R468      3.0099043250083923e-01
    z[3,0,3]  R469      1.6139744222164154e-01
    z[3,0,3]  R470      2.4999523162841797e-01
    z[3,0,3]  R471      3.2812726497650146e-01
    z[3,0,3]  R472      4.9095913767814636e-01
    z[3,0,3]  R473      4.9335297942161560e-01
    z[3,0,3]  R474      0.771373450756073
    z[3,0,3]  R475      -6.1114239692687988e-01
    z[3,0,3]  R476      -3.4578660130500793e-01
    z[3,0,3]  R477      6.4186424016952515e-01
    z[3,0,3]  R478      6.5114744007587433e-02
    z[3,0,3]  R479      3.3785501122474670e-01
    z[3,0,3]  R480      5.6813359260559082e-01
    z[3,0,3]  R481      -3.4559237957000732e-01
    z[3,0,3]  R482      -7.2367310523986816e-01
    z[3,0,3]  R483      2.1732898056507111e-01
    z[3,0,3]  R484      3.1666469573974609e-01
    z[3,0,3]  R485      -1.6486048698425293e-01
    z[3,0,3]  R486      -1.4926570653915405e-01
    z[3,0,3]  R487      -7.3794215917587280e-01
    z[3,0,3]  R488      -4.1002565622329712e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R398      -1
    z[3,0,4]  R399      1
    z[3,0,4]  R404      -6.5339556895196438e-03
    z[3,0,4]  R405      1.4562240242958069e-01
    z[3,0,4]  R406      4.8759466409683228e-01
    z[3,0,4]  R407      -5.0998383760452271e-01
    z[3,0,4]  R408      2.5875428691506386e-02
    z[3,0,4]  R409      -2.5735804438591003e-01
    z[3,0,4]  R410      -7.9946219921112061e-04
    z[3,0,4]  R411      8.2271791994571686e-02
    z[3,0,4]  R412      -3.4042972326278687e-01
    z[3,0,4]  R413      3.3132830262184143e-01
    z[3,0,4]  R414      2.3930130898952484e-01
    z[3,0,4]  R415      3.3419987559318542e-01
    z[3,0,4]  R416      1.1739798635244370e-01
    z[3,0,4]  R417      5.4334950447082520e-01
    z[3,0,4]  R418      2.1896690130233765e-01
    z[3,0,4]  R419      5.0954711437225342e-01
    z[3,0,4]  R420      -2.7300122380256653e-01
    z[3,0,4]  R421      1.1436348408460617e-01
    z[3,0,4]  R422      -6.5126776695251465e-02
    z[3,0,4]  R423      3.4790221601724625e-02
    z[3,0,4]  R424      -1.4352890849113464e-01
    z[3,0,4]  R425      1.5856587886810303e-01
    z[3,0,4]  R426      -0.129226416349411
    z[3,0,4]  R427      2.1101680397987366e-01
    z[3,0,4]  R428      2.0117874443531036e-01
    z[3,0,4]  R429      -3.3486044406890869e-01
    z[3,0,4]  R430      -1.0937442071735859e-02
    z[3,0,4]  R431      -1.2377080321311951e-01
    z[3,0,4]  R432      -5.8204419910907745e-02
    z[3,0,4]  R433      -7.0177665911614895e-03
    z[3,0,4]  R434      -1.3035634160041809e-01
    z[3,0,4]  R435      -1.9441822543740273e-02
    z[3,0,4]  R436      -9.7734019160270691e-02
    z[3,0,4]  R437      2.4935714900493622e-01
    z[3,0,4]  R438      1.0530297458171844e-01
    z[3,0,4]  R439      1.9780211150646210e-01
    z[3,0,4]  R440      -7.7204527333378792e-03
    z[3,0,4]  R441      4.5496243983507156e-02
    z[3,0,4]  R442      -3.1085941195487976e-01
    z[3,0,4]  R443      -6.0165543109178543e-02
    z[3,0,4]  R444      -1.1988577991724014e-01
    z[3,0,4]  R445      -8.8058109395205975e-04
    z[3,0,4]  R446      -1.5633161365985870e-01
    z[3,0,4]  R447      2.2820717096328735e-01
    z[3,0,4]  R448      -0.0789557546377182
    z[3,0,4]  R449      8.3188056945800781e-02
    z[3,0,4]  R450      3.5270789265632629e-01
    z[3,0,4]  R451      0.625708818435669
    z[3,0,4]  R452      4.3101277947425842e-01
    z[3,0,4]  R453      0.0524633526802063
    z[3,0,4]  R454      -8.2717090845108032e-02
    z[3,0,4]  R455      5.2935957908630371e-02
    z[3,0,4]  R456      1.2602145969867706e-01
    z[3,0,4]  R457      4.1201531887054443e-02
    z[3,0,4]  R458      1.8331001698970795e-01
    z[3,0,4]  R459      5.5005115270614624e-01
    z[3,0,4]  R460      -1.6806045174598694e-01
    z[3,0,4]  R461      2.3589572310447693e-01
    z[3,0,4]  R462      5.1857888698577881e-01
    z[3,0,4]  R463      3.3163938671350479e-02
    z[3,0,4]  R464      -3.9490621536970139e-02
    z[3,0,4]  R465      2.5820270180702209e-01
    z[3,0,4]  R466      2.3370358347892761e-01
    z[3,0,4]  R467      -6.8685412406921387e-02
    z[3,0,4]  R468      -1.0905279964208603e-01
    z[3,0,4]  R469      -4.2552232742309570e-02
    z[3,0,4]  R470      4.1010481119155884e-01
    z[3,0,4]  R471      2.1401986479759216e-01
    z[3,0,4]  R472      2.1495439112186432e-01
    z[3,0,4]  R473      2.3247393965721130e-01
    z[3,0,4]  R474      -8.0415733158588409e-02
    z[3,0,4]  R475      4.5572139322757721e-02
    z[3,0,4]  R476      3.4023562073707581e-01
    z[3,0,4]  R477      -1.7753715813159943e-01
    z[3,0,4]  R478      1.1264232546091080e-01
    z[3,0,4]  R479      -1.6377037763595581e-01
    z[3,0,4]  R480      -3.1421598792076111e-01
    z[3,0,4]  R481      2.8071027994155884e-01
    z[3,0,4]  R482      2.8293186426162720e-01
    z[3,0,4]  R483      6.4598284661769867e-02
    z[3,0,4]  R484      2.4649754166603088e-01
    z[3,0,4]  R485      -1.2283524870872498e-01
    z[3,0,4]  R486      2.3887798190116882e-01
    z[3,0,4]  R487      2.6853394508361816e-01
    z[3,0,4]  R488      -4.5189116150140762e-02
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R400      -1
    z[3,0,5]  R401      1
    z[3,0,5]  R404      -2.5043833255767822e-01
    z[3,0,5]  R405      3.2815396785736084e-01
    z[3,0,5]  R406      5.5406481027603149e-02
    z[3,0,5]  R407      3.8574171066284180e-01
    z[3,0,5]  R408      4.4239467382431030e-01
    z[3,0,5]  R409      -2.3063258826732635e-01
    z[3,0,5]  R410      -1.5647193789482117e-01
    z[3,0,5]  R411      2.8870645165443420e-01
    z[3,0,5]  R412      -2.7284887433052063e-01
    z[3,0,5]  R413      -5.2633565664291382e-01
    z[3,0,5]  R414      -0.297408789396286
    z[3,0,5]  R415      1.8562559783458710e-01
    z[3,0,5]  R416      4.2010764591395855e-03
    z[3,0,5]  R417      -8.6681410670280457e-02
    z[3,0,5]  R418      9.7037024796009064e-02
    z[3,0,5]  R419      -7.6643405482172966e-03
    z[3,0,5]  R420      1.8124409019947052e-01
    z[3,0,5]  R421      3.4569692611694336e-01
    z[3,0,5]  R422      3.8990718126296997e-01
    z[3,0,5]  R423      -1.4692430198192596e-01
    z[3,0,5]  R424      -4.0169146656990051e-01
    z[3,0,5]  R425      -2.1082855761051178e-01
    z[3,0,5]  R426      -5.7908255606889725e-02
    z[3,0,5]  R427      -2.6901489496231079e-01
    z[3,0,5]  R428      -1.2342879176139832e-01
    z[3,0,5]  R429      -1.8436795473098755e-01
    z[3,0,5]  R430      -1.7887786030769348e-01
    z[3,0,5]  R431      8.9686758816242218e-02
    z[3,0,5]  R432      -1.9222494959831238e-01
    z[3,0,5]  R433      -4.6440163254737854e-01
    z[3,0,5]  R434      -1.4157579839229584e-01
    z[3,0,5]  R435      2.7153030037879944e-01
    z[3,0,5]  R436      5.4672157764434814e-01
    z[3,0,5]  R437      2.2526112198829651e-01
    z[3,0,5]  R438      -3.9854088425636292e-01
    z[3,0,5]  R439      2.8633320331573486e-01
    z[3,0,5]  R440      3.5248550772666931e-01
    z[3,0,5]  R441      -1.8579567968845367e-01
    z[3,0,5]  R442      -1.3986136019229889e-01
    z[3,0,5]  R443      3.4295409917831421e-01
    z[3,0,5]  R444      -3.0872318148612976e-01
    z[3,0,5]  R445      3.6392825841903687e-01
    z[3,0,5]  R446      2.9768466949462891e-01
    z[3,0,5]  R447      -2.5655742734670639e-02
    z[3,0,5]  R448      0.0423213467001915
    z[3,0,5]  R449      -1.4773845672607422e-01
    z[3,0,5]  R450      -0.156717449426651
    z[3,0,5]  R451      1.5973153710365295e-01
    z[3,0,5]  R452      2.8820648789405823e-01
    z[3,0,5]  R453      8.1712851533666253e-04
    z[3,0,5]  R454      -4.1467282921075821e-02
    z[3,0,5]  R455      2.6289626955986023e-01
    z[3,0,5]  R456      -1.0409022122621536e-01
    z[3,0,5]  R457      0.084237240254879
    z[3,0,5]  R458      -4.5615535974502563e-01
    z[3,0,5]  R459      -1.3084410130977631e-01
    z[3,0,5]  R460      -2.8830143809318542e-01
    z[3,0,5]  R461      -0.164118230342865
    z[3,0,5]  R462      -1.4126639068126678e-01
    z[3,0,5]  R463      -5.7881736755371094e-01
    z[3,0,5]  R464      -2.4380034208297729e-01
    z[3,0,5]  R465      -4.7147154808044434e-01
    z[3,0,5]  R466      7.7939346432685852e-02
    z[3,0,5]  R467      3.9999324083328247e-01
    z[3,0,5]  R468      -7.4565164744853973e-02
    z[3,0,5]  R469      -3.2411959767341614e-01
    z[3,0,5]  R470      -3.5526511073112488e-01
    z[3,0,5]  R471      -5.4933613538742065e-01
    z[3,0,5]  R472      1.6533279418945312e-01
    z[3,0,5]  R473      2.3109537363052368e-01
    z[3,0,5]  R474      -2.4901962280273438e-01
    z[3,0,5]  R475      -4.3133646249771118e-01
    z[3,0,5]  R476      -3.3600360155105591e-01
    z[3,0,5]  R477      3.9849165081977844e-01
    z[3,0,5]  R478      5.0299203395843506e-01
    z[3,0,5]  R479      -4.7456416487693787e-01
    z[3,0,5]  R480      2.3958018422126770e-01
    z[3,0,5]  R481      -6.1677344143390656e-02
    z[3,0,5]  R482      -4.3604883551597595e-01
    z[3,0,5]  R483      -1.0302336513996124e-01
    z[3,0,5]  R484      -1.4970052242279053e-01
    z[3,0,5]  R485      3.0528476834297180e-01
    z[3,0,5]  R486      -2.1967029571533203e-01
    z[3,0,5]  R487      -7.0856891572475433e-02
    z[3,0,5]  R488      -3.5500779747962952e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R402      -1
    z[3,0,6]  R403      1
    z[3,0,6]  R404      2.8108218312263489e-01
    z[3,0,6]  R405      4.1452851891517639e-01
    z[3,0,6]  R406      -2.2867612540721893e-01
    z[3,0,6]  R407      -3.4304666519165039e-01
    z[3,0,6]  R408      -1.9419296085834503e-01
    z[3,0,6]  R409      -5.6261980533599854e-01
    z[3,0,6]  R410      -6.5677899122238159e-01
    z[3,0,6]  R411      5.5055910348892212e-01
    z[3,0,6]  R412      -4.8196125775575638e-02
    z[3,0,6]  R413      3.1478923559188843e-01
    z[3,0,6]  R414      4.2554289102554321e-01
    z[3,0,6]  R415      -2.0609997212886810e-01
    z[3,0,6]  R416      1.0976740717887878e-01
    z[3,0,6]  R417      -2.0024146139621735e-01
    z[3,0,6]  R418      1.7138667404651642e-02
    z[3,0,6]  R419      1.4539824426174164e-01
    z[3,0,6]  R420      -1.9080650061368942e-02
    z[3,0,6]  R421      -3.4737512469291687e-02
    z[3,0,6]  R422      -9.4156764447689056e-02
    z[3,0,6]  R423      -8.4076039493083954e-02
    z[3,0,6]  R424      4.7083523124456406e-02
    z[3,0,6]  R425      3.0754547566175461e-02
    z[3,0,6]  R426      1.2262330204248428e-01
    z[3,0,6]  R427      -8.0017736181616783e-03
    z[3,0,6]  R428      1.6017764806747437e-01
    z[3,0,6]  R429      -0.129512757062912
    z[3,0,6]  R430      -3.3758670091629028e-01
    z[3,0,6]  R431      8.1064760684967041e-02
    z[3,0,6]  R432      -3.6736443638801575e-01
    z[3,0,6]  R433      -3.8917452096939087e-01
    z[3,0,6]  R434      -0.1804189234972
    z[3,0,6]  R435      2.7841767668724060e-01
    z[3,0,6]  R436      1.7514521256089211e-02
    z[3,0,6]  R437      -1.7323812842369080e-01
    z[3,0,6]  R438      -0.185040682554245
    z[3,0,6]  R439      5.1151943206787109e-01
    z[3,0,6]  R440      -1.6835945844650269e-01
    z[3,0,6]  R441      3.8516694307327271e-01
    z[3,0,6]  R442      -1.2514501810073853e-01
    z[3,0,6]  R443      -3.1389329582452774e-02
    z[3,0,6]  R444      -6.5383620560169220e-02
    z[3,0,6]  R445      6.4385667443275452e-02
    z[3,0,6]  R446      4.2391490936279297e-01
    z[3,0,6]  R447      -3.4991465508937836e-02
    z[3,0,6]  R448      -1.1311710625886917e-01
    z[3,0,6]  R449      8.2779310643672943e-02
    z[3,0,6]  R450      0.105648472905159
    z[3,0,6]  R451      1.4468035101890564e-01
    z[3,0,6]  R452      1.3364803791046143e-01
    z[3,0,6]  R453      -6.4286895096302032e-02
    z[3,0,6]  R454      2.1512460708618164e-01
    z[3,0,6]  R455      -1.1096056550741196e-01
    z[3,0,6]  R456      -2.8705963492393494e-01
    z[3,0,6]  R457      -0.242411807179451
    z[3,0,6]  R458      7.9782538115978241e-02
    z[3,0,6]  R459      -2.0963051915168762e-01
    z[3,0,6]  R460      -2.1987858414649963e-01
    z[3,0,6]  R461      -0.091742604970932
    z[3,0,6]  R462      -1.2191002815961838e-01
    z[3,0,6]  R463      4.2908000946044922e-01
    z[3,0,6]  R464      -7.1778148412704468e-01
    z[3,0,6]  R465      2.4404789507389069e-01
    z[3,0,6]  R466      0.525579035282135
    z[3,0,6]  R467      -3.0778363347053528e-01
    z[3,0,6]  R468      1.0134135931730270e-01
    z[3,0,6]  R469      -1.8911491334438324e-01
    z[3,0,6]  R470      1.5260358154773712e-01
    z[3,0,6]  R471      -2.1925979852676392e-01
    z[3,0,6]  R472      2.7590745687484741e-01
    z[3,0,6]  R473      0.0811280682682991
    z[3,0,6]  R474      3.1139880418777466e-01
    z[3,0,6]  R475      2.9627183079719543e-01
    z[3,0,6]  R476      -2.8173670172691345e-01
    z[3,0,6]  R477      -1.9948931038379669e-01
    z[3,0,6]  R478      0.273754358291626
    z[3,0,6]  R479      -2.8750661015510559e-01
    z[3,0,6]  R480      8.4515912458300591e-03
    z[3,0,6]  R481      2.9808378219604492e-01
    z[3,0,6]  R482      4.3686878681182861e-01
    z[3,0,6]  R483      -2.1537633240222931e-01
    z[3,0,6]  R484      0.579052209854126
    z[3,0,6]  R485      2.7095130085945129e-01
    z[3,0,6]  R486      3.4633249044418335e-01
    z[3,0,6]  R487      7.9971216619014740e-02
    z[3,0,6]  R488      -1.1906320601701736e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R489      -1
    z[0,4,0]  R490      1
    z[0,4,0]  R503      2.3218529298901558e-02
    z[0,4,0]  R504      2.6585500687360764e-02
    z[0,4,0]  R505      7.1294128894805908e-02
    z[0,4,0]  R506      -2.7335685491561890e-01
    z[0,4,0]  R507      3.5928568243980408e-01
    z[0,4,0]  R508      5.9883729554712772e-03
    z[0,4,0]  R509      9.2439334839582443e-03
    z[0,4,0]  R510      -5.6336027383804321e-01
    z[0,4,0]  R511      4.0163779258728027e-01
    z[0,4,0]  R512      3.0317434668540955e-01
    z[0,4,0]  R513      7.8471505641937256e-01
    z[0,4,0]  R514      0.381783664226532
    z[0,4,0]  R515      3.5267886519432068e-01
    z[0,4,0]  R516      2.9792514443397522e-01
    z[0,4,0]  R517      0.076849564909935
    z[0,4,0]  R518      -1.4367805421352386e-01
    z[0,4,0]  R519      -6.4512050151824951e-01
    z[0,4,0]  R520      -1.4328041672706604e-01
    z[0,4,0]  R521      -3.8182201981544495e-01
    z[0,4,0]  R522      8.9524544775485992e-02
    z[0,4,0]  R523      1.5060995519161224e-01
    z[0,4,0]  R524      3.7041693925857544e-01
    z[0,4,0]  R525      2.2597697377204895e-01
    z[0,4,0]  R526      0.567455530166626
    z[0,4,0]  R527      1.5902924537658691e-01
    z[0,4,0]  R528      4.2210280895233154e-01
    z[0,4,0]  R529      -8.5973076522350311e-02
    z[0,4,0]  R530      2.6575249433517456e-01
    z[0,4,0]  R531      5.2248769998550415e-01
    z[0,4,0]  R532      6.5832680463790894e-01
    z[0,4,0]  R533      3.6908453702926636e-01
    z[0,4,0]  R534      4.6946355700492859e-01
    z[0,4,0]  R535      5.7255238294601440e-01
    z[0,4,0]  R536      4.2565661668777466e-01
    z[0,4,0]  R537      1.0079831629991531e-01
    z[0,4,0]  R538      2.0305563509464264e-01
    z[0,4,0]  R539      5.4893147945404053e-01
    z[0,4,0]  R540      -5.2610252052545547e-02
    z[0,4,0]  R541      2.1409960091114044e-01
    z[0,4,0]  R542      4.1114953160285950e-01
    z[0,4,0]  R543      5.8458864688873291e-01
    z[0,4,0]  R544      3.7280049920082092e-01
    z[0,4,0]  R545      2.8200241923332214e-01
    z[0,4,0]  R546      -4.1353516280651093e-02
    z[0,4,0]  R547      -3.7106537818908691e-01
    z[0,4,0]  R548      1.2341576069593430e-01
    z[0,4,0]  R549      -2.1269651129841805e-02
    z[0,4,0]  R550      -4.4928431510925293e-01
    z[0,4,0]  R551      -5.3979802131652832e-01
    z[0,4,0]  R552      -3.9149722456932068e-01
    z[0,4,0]  R553      -0.0692228153347969
    z[0,4,0]  R554      -1.8829548358917236e-01
    z[0,4,0]  R555      -3.2876855134963989e-01
    z[0,4,0]  R556      -0.364611953496933
    z[0,4,0]  R557      -5.1757901906967163e-01
    z[0,4,0]  R558      -4.3709689378738403e-01
    z[0,4,0]  R559      -1.4845295250415802e-01
    z[0,4,0]  R560      -6.5169042348861694e-01
    z[0,4,0]  R561      4.5602847822010517e-03
    z[0,4,0]  R562      -4.2190793156623840e-01
    z[0,4,0]  R563      1.9931890070438385e-01
    z[0,4,0]  R564      -1.1368344724178314e-01
    z[0,4,0]  R565      5.8324247598648071e-01
    z[0,4,0]  R566      6.9198060035705566e-01
    z[0,4,0]  R567      0.673913836479187
    z[0,4,0]  R568      5.4904800653457642e-01
    z[0,4,0]  R569      6.6781336069107056e-01
    z[0,4,0]  R570      0.593197226524353
    z[0,4,0]  R571      7.4587661027908325e-01
    z[0,4,0]  R572      7.3596894741058350e-01
    z[0,4,0]  R573      5.3640419244766235e-01
    z[0,4,0]  R574      2.8914016485214233e-01
    z[0,4,0]  R575      4.8537275195121765e-01
    z[0,4,0]  R576      5.3979862481355667e-02
    z[0,4,0]  R577      8.1701517105102539e-02
    z[0,4,0]  R578      -5.5371288908645511e-04
    z[0,4,0]  R579      2.7030816674232483e-01
    z[0,4,0]  R580      3.8807886838912964e-01
    z[0,4,0]  R581      5.0469088554382324e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R491      -1
    z[0,4,1]  R492      1
    z[0,4,1]  R503      -6.9088816642761230e-01
    z[0,4,1]  R504      -8.2758784294128418e-01
    z[0,4,1]  R505      -5.2705746889114380e-01
    z[0,4,1]  R506      -8.5353112220764160e-01
    z[0,4,1]  R507      -7.9864984750747681e-01
    z[0,4,1]  R508      -9.2099231481552124e-01
    z[0,4,1]  R509      -5.0414168834686279e-01
    z[0,4,1]  R510      -7.7416580915451050e-01
    z[0,4,1]  R511      -8.3415180444717407e-01
    z[0,4,1]  R512      4.2863461375236511e-01
    z[0,4,1]  R513      5.2385592460632324e-01
    z[0,4,1]  R514      7.7788054943084717e-01
    z[0,4,1]  R515      5.1039779186248779e-01
    z[0,4,1]  R516      0.782328724861145
    z[0,4,1]  R517      9.3017423152923584e-01
    z[0,4,1]  R518      7.4598878622055054e-01
    z[0,4,1]  R519      6.2384688854217529e-01
    z[0,4,1]  R520      9.0567612648010254e-01
    z[0,4,1]  R521      8.4035253524780273e-01
    z[0,4,1]  R522      7.2656100988388062e-01
    z[0,4,1]  R523      0.54316645860672
    z[0,4,1]  R524      8.2122975587844849e-01
    z[0,4,1]  R525      3.5193365812301636e-01
    z[0,4,1]  R526      2.6572963595390320e-01
    z[0,4,1]  R527      6.3096469640731812e-01
    z[0,4,1]  R528      3.6601129174232483e-01
    z[0,4,1]  R529      5.9211635589599609e-01
    z[0,4,1]  R530      3.8181629776954651e-01
    z[0,4,1]  R531      3.8341113924980164e-01
    z[0,4,1]  R532      4.8087698221206665e-01
    z[0,4,1]  R533      7.4802255630493164e-01
    z[0,4,1]  R534      0.600898265838623
    z[0,4,1]  R535      3.2104572653770447e-01
    z[0,4,1]  R536      5.1311117410659790e-01
    z[0,4,1]  R537      0.793482780456543
    z[0,4,1]  R538      4.4519197940826416e-01
    z[0,4,1]  R539      -1.3799582421779633e-01
    z[0,4,1]  R540      -0.605397641658783
    z[0,4,1]  R541      5.4583203792572021e-01
    z[0,4,1]  R542      6.9718170166015625e-01
    z[0,4,1]  R543      4.2258173227310181e-01
    z[0,4,1]  R544      6.1684954166412354e-01
    z[0,4,1]  R545      -5.7018172740936279e-01
    z[0,4,1]  R546      1.1039377748966217e-01
    z[0,4,1]  R547      8.6186027526855469e-01
    z[0,4,1]  R548      5.7072877883911133e-01
    z[0,4,1]  R549      8.6363697052001953e-01
    z[0,4,1]  R550      7.0416003465652466e-01
    z[0,4,1]  R551      1.4872631430625916e-01
    z[0,4,1]  R552      3.2680952548980713e-01
    z[0,4,1]  R553      7.7890682220458984e-01
    z[0,4,1]  R554      6.7440932989120483e-01
    z[0,4,1]  R555      0.812924325466156
    z[0,4,1]  R556      0.594958484172821
    z[0,4,1]  R557      6.1003899574279785e-01
    z[0,4,1]  R558      5.5178344249725342e-01
    z[0,4,1]  R559      5.8253526687622070e-01
    z[0,4,1]  R560      5.1752042770385742e-01
    z[0,4,1]  R561      5.7960999011993408e-01
    z[0,4,1]  R562      -4.8534622788429260e-01
    z[0,4,1]  R563      -6.8122231960296631e-01
    z[0,4,1]  R564      -6.4879775047302246e-01
    z[0,4,1]  R565      -4.6633762121200562e-01
    z[0,4,1]  R566      -4.0039667487144470e-01
    z[0,4,1]  R567      -4.0915042161941528e-01
    z[0,4,1]  R568      -3.6398413777351379e-01
    z[0,4,1]  R569      -5.5775296688079834e-01
    z[0,4,1]  R570      -4.2307758331298828e-01
    z[0,4,1]  R571      -3.9859792590141296e-01
    z[0,4,1]  R572      -0.547124445438385
    z[0,4,1]  R573      -2.6161062717437744e-01
    z[0,4,1]  R574      -1.8674476444721222e-01
    z[0,4,1]  R575      1.7809976637363434e-01
    z[0,4,1]  R576      -4.5620836317539215e-02
    z[0,4,1]  R577      -2.5697553157806396e-01
    z[0,4,1]  R578      -0.725864589214325
    z[0,4,1]  R579      -5.9336471557617188e-01
    z[0,4,1]  R580      -1.5418398380279541e-01
    z[0,4,1]  R581      -7.1462118625640869e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R493      -1
    z[0,4,2]  R494      1
    z[0,4,2]  R503      -7.5585119426250458e-02
    z[0,4,2]  R504      2.4415375292301178e-01
    z[0,4,2]  R505      6.4707857370376587e-01
    z[0,4,2]  R506      2.7240115404129028e-01
    z[0,4,2]  R507      1.0018160194158554e-01
    z[0,4,2]  R508      -1.0218521207571030e-01
    z[0,4,2]  R509      4.6498867869377136e-01
    z[0,4,2]  R510      1.6942533850669861e-01
    z[0,4,2]  R511      -3.0455809831619263e-01
    z[0,4,2]  R512      3.7516161799430847e-01
    z[0,4,2]  R513      1.5947189927101135e-01
    z[0,4,2]  R514      -2.3742966353893280e-01
    z[0,4,2]  R515      4.0666827559471130e-01
    z[0,4,2]  R516      5.1089294254779816e-02
    z[0,4,2]  R517      -2.0245976746082306e-01
    z[0,4,2]  R518      4.5116788148880005e-01
    z[0,4,2]  R519      3.1718626618385315e-01
    z[0,4,2]  R520      -2.2297109663486481e-01
    z[0,4,2]  R521      1.5814979374408722e-01
    z[0,4,2]  R522      -1.4584209024906158e-01
    z[0,4,2]  R523      -4.3707605451345444e-02
    z[0,4,2]  R524      -9.2976361513137817e-02
    z[0,4,2]  R525      -4.3287232518196106e-01
    z[0,4,2]  R526      -1.6613063216209412e-01
    z[0,4,2]  R527      1.5279665589332581e-01
    z[0,4,2]  R528      2.2173093259334564e-01
    z[0,4,2]  R529      -2.2127854824066162e-01
    z[0,4,2]  R530      -1.9176118075847626e-02
    z[0,4,2]  R531      -1.9215150177478790e-01
    z[0,4,2]  R532      -4.6588137745857239e-01
    z[0,4,2]  R533      3.6818632483482361e-01
    z[0,4,2]  R534      1.9580742716789246e-01
    z[0,4,2]  R535      2.5650796294212341e-01
    z[0,4,2]  R536      4.0598914027214050e-01
    z[0,4,2]  R537      5.2883196622133255e-02
    z[0,4,2]  R538      1.0428345762193203e-02
    z[0,4,2]  R539      -1.7387193441390991e-01
    z[0,4,2]  R540      -4.5069187879562378e-01
    z[0,4,2]  R541      0.118861123919487
    z[0,4,2]  R542      4.8090755008161068e-03
    z[0,4,2]  R543      -1.7562119662761688e-01
    z[0,4,2]  R544      -3.9228554815053940e-02
    z[0,4,2]  R545      -5.5179435014724731e-01
    z[0,4,2]  R546      3.6836430430412292e-02
    z[0,4,2]  R547      1.0536435991525650e-01
    z[0,4,2]  R548      -3.7455025315284729e-01
    z[0,4,2]  R549      2.1165508031845093e-01
    z[0,4,2]  R550      2.3400449752807617e-01
    z[0,4,2]  R551      2.4168847501277924e-01
    z[0,4,2]  R552      6.5540504455566406e-01
    z[0,4,2]  R553      -2.9798674583435059e-01
    z[0,4,2]  R554      -0.347235769033432
    z[0,4,2]  R555      -7.6188750565052032e-02
    z[0,4,2]  R556      2.3774772882461548e-01
    z[0,4,2]  R557      -0.0581904798746109
    z[0,4,2]  R558      4.2077171802520752e-01
    z[0,4,2]  R559      -2.3059609532356262e-01
    z[0,4,2]  R560      1.4783754944801331e-01
    z[0,4,2]  R561      -4.7947093844413757e-01
    z[0,4,2]  R562      -1.1642266064882278e-01
    z[0,4,2]  R563      3.3215153217315674e-01
    z[0,4,2]  R564      2.8857752680778503e-01
    z[0,4,2]  R565      5.6902801990509033e-01
    z[0,4,2]  R566      0.561430811882019
    z[0,4,2]  R567      5.6609356403350830e-01
    z[0,4,2]  R568      6.9370740652084351e-01
    z[0,4,2]  R569      4.2793425917625427e-01
    z[0,4,2]  R570      4.9629786610603333e-01
    z[0,4,2]  R571      2.9269164800643921e-01
    z[0,4,2]  R572      2.1162860095500946e-01
    z[0,4,2]  R573      -3.2568764686584473e-01
    z[0,4,2]  R574      -1.9889141619205475e-01
    z[0,4,2]  R575      -1.4858931303024292e-01
    z[0,4,2]  R576      2.5257551670074463e-01
    z[0,4,2]  R577      -4.2722240090370178e-02
    z[0,4,2]  R578      3.6074250936508179e-01
    z[0,4,2]  R579      1.5408769249916077e-01
    z[0,4,2]  R580      5.6516725569963455e-02
    z[0,4,2]  R581      -2.8202304244041443e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R495      -1
    z[0,4,3]  R496      1
    z[0,4,3]  R503      -6.0313421487808228e-01
    z[0,4,3]  R504      -2.6426699757575989e-01
    z[0,4,3]  R505      -4.0811866521835327e-01
    z[0,4,3]  R506      -1.8318356946110725e-02
    z[0,4,3]  R507      -3.3026996254920959e-01
    z[0,4,3]  R508      6.8596608936786652e-02
    z[0,4,3]  R509      -4.8660203814506531e-01
    z[0,4,3]  R510      2.5030849501490593e-02
    z[0,4,3]  R511      1.7117737233638763e-01
    z[0,4,3]  R512      6.2525969743728638e-01
    z[0,4,3]  R513      -2.2083206474781036e-01
    z[0,4,3]  R514      -1.8068033456802368e-01
    z[0,4,3]  R515      1.0851048678159714e-01
    z[0,4,3]  R516      -9.9475458264350891e-02
    z[0,4,3]  R517      -2.8459498286247253e-01
    z[0,4,3]  R518      -0.405542254447937
    z[0,4,3]  R519      0.0989881381392479
    z[0,4,3]  R520      -1.9643209874629974e-02
    z[0,4,3]  R521      -2.3548056185245514e-01
    z[0,4,3]  R522      -4.4133788347244263e-01
    z[0,4,3]  R523      5.6281000375747681e-01
    z[0,4,3]  R524      1.4149080216884613e-01
    z[0,4,3]  R525      7.3939192295074463e-01
    z[0,4,3]  R526      5.2539533376693726e-01
    z[0,4,3]  R527      1.8167947232723236e-01
    z[0,4,3]  R528      2.4998384714126587e-01
    z[0,4,3]  R529      4.9449887871742249e-01
    z[0,4,3]  R530      6.6805613040924072e-01
    z[0,4,3]  R531      5.3257602453231812e-01
    z[0,4,3]  R532      3.0099043250083923e-01
    z[0,4,3]  R533      1.6139744222164154e-01
    z[0,4,3]  R534      2.4999523162841797e-01
    z[0,4,3]  R535      3.2812726497650146e-01
    z[0,4,3]  R536      4.9095913767814636e-01
    z[0,4,3]  R537      4.9335297942161560e-01
    z[0,4,3]  R538      0.771373450756073
    z[0,4,3]  R539      -6.1114239692687988e-01
    z[0,4,3]  R540      -3.4578660130500793e-01
    z[0,4,3]  R541      6.4186424016952515e-01
    z[0,4,3]  R542      6.5114744007587433e-02
    z[0,4,3]  R543      3.3785501122474670e-01
    z[0,4,3]  R544      5.6813359260559082e-01
    z[0,4,3]  R545      -3.4559237957000732e-01
    z[0,4,3]  R546      -7.2367310523986816e-01
    z[0,4,3]  R547      2.1732898056507111e-01
    z[0,4,3]  R548      3.1666469573974609e-01
    z[0,4,3]  R549      -1.6486048698425293e-01
    z[0,4,3]  R550      -1.4926570653915405e-01
    z[0,4,3]  R551      -7.3794215917587280e-01
    z[0,4,3]  R552      -4.1002565622329712e-01
    z[0,4,3]  R553      -2.7236613631248474e-01
    z[0,4,3]  R554      4.8791030049324036e-01
    z[0,4,3]  R555      1.8327637016773224e-01
    z[0,4,3]  R556      4.3993502855300903e-01
    z[0,4,3]  R557      2.8136044740676880e-01
    z[0,4,3]  R558      -1.7711807787418365e-01
    z[0,4,3]  R559      -1.3692776858806610e-01
    z[0,4,3]  R560      -2.7051979303359985e-01
    z[0,4,3]  R561      9.7662389278411865e-02
    z[0,4,3]  R562      -2.1610608696937561e-01
    z[0,4,3]  R563      -3.7701785564422607e-01
    z[0,4,3]  R564      -6.3731677830219269e-02
    z[0,4,3]  R565      -4.6401996165513992e-02
    z[0,4,3]  R566      -8.5805654525756836e-02
    z[0,4,3]  R567      -1.5014901757240295e-01
    z[0,4,3]  R568      -5.4991997778415680e-02
    z[0,4,3]  R569      1.2495151162147522e-01
    z[0,4,3]  R570      7.7261097729206085e-02
    z[0,4,3]  R571      -4.2161926627159119e-02
    z[0,4,3]  R572      8.5739880800247192e-02
    z[0,4,3]  R573      -7.1150410175323486e-01
    z[0,4,3]  R574      -6.3634729385375977e-01
    z[0,4,3]  R575      -7.4254709482192993e-01
    z[0,4,3]  R576      -7.9481166601181030e-01
    z[0,4,3]  R577      -5.0166660547256470e-01
    z[0,4,3]  R578      -0.315601110458374
    z[0,4,3]  R579      -5.9093427658081055e-01
    z[0,4,3]  R580      -6.3995629549026489e-01
    z[0,4,3]  R581      1.8050726503133774e-02
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R497      -1
    z[0,4,4]  R498      1
    z[0,4,4]  R503      -7.7204527333378792e-03
    z[0,4,4]  R504      4.5496243983507156e-02
    z[0,4,4]  R505      -3.1085941195487976e-01
    z[0,4,4]  R506      -6.0165543109178543e-02
    z[0,4,4]  R507      -1.1988577991724014e-01
    z[0,4,4]  R508      -8.8058109395205975e-04
    z[0,4,4]  R509      -1.5633161365985870e-01
    z[0,4,4]  R510      2.2820717096328735e-01
    z[0,4,4]  R511      -0.0789557546377182
    z[0,4,4]  R512      -3.4042972326278687e-01
    z[0,4,4]  R513      8.3188056945800781e-02
    z[0,4,4]  R514      3.5270789265632629e-01
    z[0,4,4]  R515      0.625708818435669
    z[0,4,4]  R516      4.3101277947425842e-01
    z[0,4,4]  R517      0.0524633526802063
    z[0,4,4]  R518      -8.2717090845108032e-02
    z[0,4,4]  R519      5.2935957908630371e-02
    z[0,4,4]  R520      1.2602145969867706e-01
    z[0,4,4]  R521      4.1201531887054443e-02
    z[0,4,4]  R522      1.8331001698970795e-01
    z[0,4,4]  R523      5.5005115270614624e-01
    z[0,4,4]  R524      -1.6806045174598694e-01
    z[0,4,4]  R525      2.3589572310447693e-01
    z[0,4,4]  R526      5.1857888698577881e-01
    z[0,4,4]  R527      3.3163938671350479e-02
    z[0,4,4]  R528      -3.9490621536970139e-02
    z[0,4,4]  R529      2.5820270180702209e-01
    z[0,4,4]  R530      2.3370358347892761e-01
    z[0,4,4]  R531      -6.8685412406921387e-02
    z[0,4,4]  R532      -1.0905279964208603e-01
    z[0,4,4]  R533      -4.2552232742309570e-02
    z[0,4,4]  R534      4.1010481119155884e-01
    z[0,4,4]  R535      2.1401986479759216e-01
    z[0,4,4]  R536      2.1495439112186432e-01
    z[0,4,4]  R537      2.3247393965721130e-01
    z[0,4,4]  R538      -8.0415733158588409e-02
    z[0,4,4]  R539      4.5572139322757721e-02
    z[0,4,4]  R540      3.4023562073707581e-01
    z[0,4,4]  R541      -1.7753715813159943e-01
    z[0,4,4]  R542      1.1264232546091080e-01
    z[0,4,4]  R543      -1.6377037763595581e-01
    z[0,4,4]  R544      -3.1421598792076111e-01
    z[0,4,4]  R545      2.8071027994155884e-01
    z[0,4,4]  R546      2.8293186426162720e-01
    z[0,4,4]  R547      6.4598284661769867e-02
    z[0,4,4]  R548      2.4649754166603088e-01
    z[0,4,4]  R549      -1.2283524870872498e-01
    z[0,4,4]  R550      2.3887798190116882e-01
    z[0,4,4]  R551      2.6853394508361816e-01
    z[0,4,4]  R552      -4.5189116150140762e-02
    z[0,4,4]  R553      4.3432092666625977e-01
    z[0,4,4]  R554      3.4715458750724792e-01
    z[0,4,4]  R555      4.3599805235862732e-01
    z[0,4,4]  R556      6.2857642769813538e-02
    z[0,4,4]  R557      1.6727188229560852e-01
    z[0,4,4]  R558      3.2528951764106750e-01
    z[0,4,4]  R559      -4.4658705592155457e-02
    z[0,4,4]  R560      -1.3284756243228912e-01
    z[0,4,4]  R561      1.2144851684570312e-01
    z[0,4,4]  R562      4.8336514830589294e-01
    z[0,4,4]  R563      -1.4025740325450897e-01
    z[0,4,4]  R564      1.1695694178342819e-01
    z[0,4,4]  R565      2.9780622571706772e-02
    z[0,4,4]  R566      -0.113673135638237
    z[0,4,4]  R567      9.4564080238342285e-02
    z[0,4,4]  R568      -2.2984115406870842e-02
    z[0,4,4]  R569      1.2909808754920959e-01
    z[0,4,4]  R570      -1.5918545424938202e-01
    z[0,4,4]  R571      -1.1347037553787231e-01
    z[0,4,4]  R572      -1.8654270470142365e-01
    z[0,4,4]  R573      1.5339119732379913e-01
    z[0,4,4]  R574      -8.2135021686553955e-02
    z[0,4,4]  R575      8.2185156643390656e-02
    z[0,4,4]  R576      -1.1228418350219727e-01
    z[0,4,4]  R577      2.6528099179267883e-01
    z[0,4,4]  R578      -4.2539444565773010e-01
    z[0,4,4]  R579      9.4021543860435486e-02
    z[0,4,4]  R580      -4.5273822546005249e-01
    z[0,4,4]  R581      -0.379819393157959
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R499      -1
    z[0,4,5]  R500      1
    z[0,4,5]  R503      3.5248550772666931e-01
    z[0,4,5]  R504      -1.8579567968845367e-01
    z[0,4,5]  R505      -1.3986136019229889e-01
    z[0,4,5]  R506      3.4295409917831421e-01
    z[0,4,5]  R507      -3.0872318148612976e-01
    z[0,4,5]  R508      3.6392825841903687e-01
    z[0,4,5]  R509      2.9768466949462891e-01
    z[0,4,5]  R510      -2.5655742734670639e-02
    z[0,4,5]  R511      0.0423213467001915
    z[0,4,5]  R512      -2.7284887433052063e-01
    z[0,4,5]  R513      -1.4773845672607422e-01
    z[0,4,5]  R514      -0.156717449426651
    z[0,4,5]  R515      1.5973153710365295e-01
    z[0,4,5]  R516      2.8820648789405823e-01
    z[0,4,5]  R517      8.1712851533666253e-04
    z[0,4,5]  R518      -4.1467282921075821e-02
    z[0,4,5]  R519      2.6289626955986023e-01
    z[0,4,5]  R520      -1.0409022122621536e-01
    z[0,4,5]  R521      0.084237240254879
    z[0,4,5]  R522      -4.5615535974502563e-01
    z[0,4,5]  R523      -1.3084410130977631e-01
    z[0,4,5]  R524      -2.8830143809318542e-01
    z[0,4,5]  R525      -0.164118230342865
    z[0,4,5]  R526      -1.4126639068126678e-01
    z[0,4,5]  R527      -5.7881736755371094e-01
    z[0,4,5]  R528      -2.4380034208297729e-01
    z[0,4,5]  R529      -4.7147154808044434e-01
    z[0,4,5]  R530      7.7939346432685852e-02
    z[0,4,5]  R531      3.9999324083328247e-01
    z[0,4,5]  R532      -7.4565164744853973e-02
    z[0,4,5]  R533      -3.2411959767341614e-01
    z[0,4,5]  R534      -3.5526511073112488e-01
    z[0,4,5]  R535      -5.4933613538742065e-01
    z[0,4,5]  R536      1.6533279418945312e-01
    z[0,4,5]  R537      2.3109537363052368e-01
    z[0,4,5]  R538      -2.4901962280273438e-01
    z[0,4,5]  R539      -4.3133646249771118e-01
    z[0,4,5]  R540      -3.3600360155105591e-01
    z[0,4,5]  R541      3.9849165081977844e-01
    z[0,4,5]  R542      5.0299203395843506e-01
    z[0,4,5]  R543      -4.7456416487693787e-01
    z[0,4,5]  R544      2.3958018422126770e-01
    z[0,4,5]  R545      -6.1677344143390656e-02
    z[0,4,5]  R546      -4.3604883551597595e-01
    z[0,4,5]  R547      -1.0302336513996124e-01
    z[0,4,5]  R548      -1.4970052242279053e-01
    z[0,4,5]  R549      3.0528476834297180e-01
    z[0,4,5]  R550      -2.1967029571533203e-01
    z[0,4,5]  R551      -7.0856891572475433e-02
    z[0,4,5]  R552      -3.5500779747962952e-01
    z[0,4,5]  R553      -1.1757581681013107e-01
    z[0,4,5]  R554      -6.0707405209541321e-02
    z[0,4,5]  R555      6.5165506675839424e-03
    z[0,4,5]  R556      -3.0680984258651733e-01
    z[0,4,5]  R557      1.6882508993148804e-01
    z[0,4,5]  R558      -4.3570473790168762e-01
    z[0,4,5]  R559      2.8054052591323853e-01
    z[0,4,5]  R560      -3.7503218650817871e-01
    z[0,4,5]  R561      4.0232893824577332e-01
    z[0,4,5]  R562      8.7758600711822510e-02
    z[0,4,5]  R563      -2.8529292345046997e-01
    z[0,4,5]  R564      -1.2879328429698944e-01
    z[0,4,5]  R565      3.3906564116477966e-01
    z[0,4,5]  R566      1.3632264733314514e-01
    z[0,4,5]  R567      1.3902534544467926e-01
    z[0,4,5]  R568      1.9321456551551819e-01
    z[0,4,5]  R569      1.4572256803512573e-01
    z[0,4,5]  R570      3.3065313100814819e-01
    z[0,4,5]  R571      3.3350548148155212e-01
    z[0,4,5]  R572      2.5434008240699768e-01
    z[0,4,5]  R573      0.0653185248374939
    z[0,4,5]  R574      6.4751470088958740e-01
    z[0,4,5]  R575      -2.3476819694042206e-01
    z[0,4,5]  R576      4.9129912257194519e-01
    z[0,4,5]  R577      3.8730046153068542e-01
    z[0,4,5]  R578      2.4547970294952393e-01
    z[0,4,5]  R579      -4.3531551957130432e-01
    z[0,4,5]  R580      2.4686281383037567e-01
    z[0,4,5]  R581      5.7919424027204514e-02
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R501      -1
    z[0,4,6]  R502      1
    z[0,4,6]  R503      -1.6835945844650269e-01
    z[0,4,6]  R504      3.8516694307327271e-01
    z[0,4,6]  R505      -1.2514501810073853e-01
    z[0,4,6]  R506      -3.1389329582452774e-02
    z[0,4,6]  R507      -6.5383620560169220e-02
    z[0,4,6]  R508      6.4385667443275452e-02
    z[0,4,6]  R509      4.2391490936279297e-01
    z[0,4,6]  R510      -3.4991465508937836e-02
    z[0,4,6]  R511      -1.1311710625886917e-01
    z[0,4,6]  R512      -4.8196125775575638e-02
    z[0,4,6]  R513      8.2779310643672943e-02
    z[0,4,6]  R514      0.105648472905159
    z[0,4,6]  R515      1.4468035101890564e-01
    z[0,4,6]  R516      1.3364803791046143e-01
    z[0,4,6]  R517      -6.4286895096302032e-02
    z[0,4,6]  R518      2.1512460708618164e-01
    z[0,4,6]  R519      -1.1096056550741196e-01
    z[0,4,6]  R520      -2.8705963492393494e-01
    z[0,4,6]  R521      -0.242411807179451
    z[0,4,6]  R522      7.9782538115978241e-02
    z[0,4,6]  R523      -2.0963051915168762e-01
    z[0,4,6]  R524      -2.1987858414649963e-01
    z[0,4,6]  R525      -0.091742604970932
    z[0,4,6]  R526      -1.2191002815961838e-01
    z[0,4,6]  R527      4.2908000946044922e-01
    z[0,4,6]  R528      -7.1778148412704468e-01
    z[0,4,6]  R529      2.4404789507389069e-01
    z[0,4,6]  R530      0.525579035282135
    z[0,4,6]  R531      -3.0778363347053528e-01
    z[0,4,6]  R532      1.0134135931730270e-01
    z[0,4,6]  R533      -1.8911491334438324e-01
    z[0,4,6]  R534      1.5260358154773712e-01
    z[0,4,6]  R535      -2.1925979852676392e-01
    z[0,4,6]  R536      2.7590745687484741e-01
    z[0,4,6]  R537      0.0811280682682991
    z[0,4,6]  R538      3.1139880418777466e-01
    z[0,4,6]  R539      2.9627183079719543e-01
    z[0,4,6]  R540      -2.8173670172691345e-01
    z[0,4,6]  R541      -1.9948931038379669e-01
    z[0,4,6]  R542      0.273754358291626
    z[0,4,6]  R543      -2.8750661015510559e-01
    z[0,4,6]  R544      8.4515912458300591e-03
    z[0,4,6]  R545      2.9808378219604492e-01
    z[0,4,6]  R546      4.3686878681182861e-01
    z[0,4,6]  R547      -2.1537633240222931e-01
    z[0,4,6]  R548      0.579052209854126
    z[0,4,6]  R549      2.7095130085945129e-01
    z[0,4,6]  R550      3.4633249044418335e-01
    z[0,4,6]  R551      7.9971216619014740e-02
    z[0,4,6]  R552      -1.1906320601701736e-01
    z[0,4,6]  R553      -1.5190209448337555e-01
    z[0,4,6]  R554      -0.163969486951828
    z[0,4,6]  R555      -3.9161231368780136e-02
    z[0,4,6]  R556      -4.0611866116523743e-01
    z[0,4,6]  R557      -4.7003483772277832e-01
    z[0,4,6]  R558      -2.0241707563400269e-02
    z[0,4,6]  R559      -6.9713217020034790e-01
    z[0,4,6]  R560      0.232675239443779
    z[0,4,6]  R561      4.9797871708869934e-01
    z[0,4,6]  R562      5.3369772434234619e-01
    z[0,4,6]  R563      -3.7772583961486816e-01
    z[0,4,6]  R564      -6.6972541809082031e-01
    z[0,4,6]  R565      -2.3642625659704208e-02
    z[0,4,6]  R566      8.2296334207057953e-02
    z[0,4,6]  R567      8.4611341357231140e-02
    z[0,4,6]  R568      2.0963713526725769e-01
    z[0,4,6]  R569      7.9340517520904541e-02
    z[0,4,6]  R570      2.8665328025817871e-01
    z[0,4,6]  R571      2.7062943577766418e-01
    z[0,4,6]  R572      -0.0859035924077034
    z[0,4,6]  R573      -0.061029102653265
    z[0,4,6]  R574      -1.0491538792848587e-01
    z[0,4,6]  R575      3.1203892827033997e-01
    z[0,4,6]  R576      -2.1331250667572021e-01
    z[0,4,6]  R577      -6.7336338758468628e-01
    z[0,4,6]  R578      -4.6480432152748108e-02
    z[0,4,6]  R579      -5.9714134782552719e-02
    z[0,4,6]  R580      3.8336774706840515e-01
    z[0,4,6]  R581      8.4399670362472534e-02
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R582      -1
    z[4,0,0]  R583      1
    z[4,0,0]  R596      -0.0692228153347969
    z[4,0,0]  R597      -1.8829548358917236e-01
    z[4,0,0]  R598      -3.2876855134963989e-01
    z[4,0,0]  R599      -0.364611953496933
    z[4,0,0]  R600      -5.1757901906967163e-01
    z[4,0,0]  R601      -4.3709689378738403e-01
    z[4,0,0]  R602      -1.4845295250415802e-01
    z[4,0,0]  R603      -6.5169042348861694e-01
    z[4,0,0]  R604      4.5602847822010517e-03
    z[4,0,0]  R605      -4.2190793156623840e-01
    z[4,0,0]  R606      1.9931890070438385e-01
    z[4,0,0]  R607      -1.1368344724178314e-01
    z[4,0,0]  R608      5.8324247598648071e-01
    z[4,0,0]  R609      6.9198060035705566e-01
    z[4,0,0]  R610      0.673913836479187
    z[4,0,0]  R611      5.4904800653457642e-01
    z[4,0,0]  R612      6.6781336069107056e-01
    z[4,0,0]  R613      0.593197226524353
    z[4,0,0]  R614      7.4587661027908325e-01
    z[4,0,0]  R615      7.3596894741058350e-01
    z[4,0,0]  R616      5.3640419244766235e-01
    z[4,0,0]  R617      2.8914016485214233e-01
    z[4,0,0]  R618      4.8537275195121765e-01
    z[4,0,0]  R619      5.3979862481355667e-02
    z[4,0,0]  R620      8.1701517105102539e-02
    z[4,0,0]  R621      -5.5371288908645511e-04
    z[4,0,0]  R622      2.7030816674232483e-01
    z[4,0,0]  R623      3.8807886838912964e-01
    z[4,0,0]  R624      5.0469088554382324e-01
    z[4,0,0]  R625      2.3218529298901558e-02
    z[4,0,0]  R626      2.6585500687360764e-02
    z[4,0,0]  R627      7.1294128894805908e-02
    z[4,0,0]  R628      -2.7335685491561890e-01
    z[4,0,0]  R629      3.5928568243980408e-01
    z[4,0,0]  R630      5.9883729554712772e-03
    z[4,0,0]  R631      9.2439334839582443e-03
    z[4,0,0]  R632      -5.6336027383804321e-01
    z[4,0,0]  R633      4.0163779258728027e-01
    z[4,0,0]  R634      3.0317434668540955e-01
    z[4,0,0]  R635      7.8471505641937256e-01
    z[4,0,0]  R636      0.381783664226532
    z[4,0,0]  R637      3.5267886519432068e-01
    z[4,0,0]  R638      2.9792514443397522e-01
    z[4,0,0]  R639      0.076849564909935
    z[4,0,0]  R640      -1.4367805421352386e-01
    z[4,0,0]  R641      -6.4512050151824951e-01
    z[4,0,0]  R642      -1.4328041672706604e-01
    z[4,0,0]  R643      -3.8182201981544495e-01
    z[4,0,0]  R644      8.9524544775485992e-02
    z[4,0,0]  R645      1.5060995519161224e-01
    z[4,0,0]  R646      3.7041693925857544e-01
    z[4,0,0]  R647      2.2597697377204895e-01
    z[4,0,0]  R648      0.567455530166626
    z[4,0,0]  R649      1.5902924537658691e-01
    z[4,0,0]  R650      4.2210280895233154e-01
    z[4,0,0]  R651      -8.5973076522350311e-02
    z[4,0,0]  R652      2.6575249433517456e-01
    z[4,0,0]  R653      5.2248769998550415e-01
    z[4,0,0]  R654      6.5832680463790894e-01
    z[4,0,0]  R655      3.6908453702926636e-01
    z[4,0,0]  R656      4.6946355700492859e-01
    z[4,0,0]  R657      5.7255238294601440e-01
    z[4,0,0]  R658      4.2565661668777466e-01
    z[4,0,0]  R659      1.0079831629991531e-01
    z[4,0,0]  R660      2.0305563509464264e-01
    z[4,0,0]  R661      5.4893147945404053e-01
    z[4,0,0]  R662      -5.2610252052545547e-02
    z[4,0,0]  R663      2.1409960091114044e-01
    z[4,0,0]  R664      4.1114953160285950e-01
    z[4,0,0]  R665      5.8458864688873291e-01
    z[4,0,0]  R666      3.7280049920082092e-01
    z[4,0,0]  R667      2.8200241923332214e-01
    z[4,0,0]  R668      -4.1353516280651093e-02
    z[4,0,0]  R669      -3.7106537818908691e-01
    z[4,0,0]  R670      1.2341576069593430e-01
    z[4,0,0]  R671      -2.1269651129841805e-02
    z[4,0,0]  R672      -4.4928431510925293e-01
    z[4,0,0]  R673      -5.3979802131652832e-01
    z[4,0,0]  R674      -3.9149722456932068e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R584      -1
    z[4,0,1]  R585      1
    z[4,0,1]  R596      7.7890682220458984e-01
    z[4,0,1]  R597      6.7440932989120483e-01
    z[4,0,1]  R598      0.812924325466156
    z[4,0,1]  R599      0.594958484172821
    z[4,0,1]  R600      6.1003899574279785e-01
    z[4,0,1]  R601      5.5178344249725342e-01
    z[4,0,1]  R602      5.8253526687622070e-01
    z[4,0,1]  R603      5.1752042770385742e-01
    z[4,0,1]  R604      5.7960999011993408e-01
    z[4,0,1]  R605      -4.8534622788429260e-01
    z[4,0,1]  R606      -6.8122231960296631e-01
    z[4,0,1]  R607      -6.4879775047302246e-01
    z[4,0,1]  R608      -4.6633762121200562e-01
    z[4,0,1]  R609      -4.0039667487144470e-01
    z[4,0,1]  R610      -4.0915042161941528e-01
    z[4,0,1]  R611      -3.6398413777351379e-01
    z[4,0,1]  R612      -5.5775296688079834e-01
    z[4,0,1]  R613      -4.2307758331298828e-01
    z[4,0,1]  R614      -3.9859792590141296e-01
    z[4,0,1]  R615      -0.547124445438385
    z[4,0,1]  R616      -2.6161062717437744e-01
    z[4,0,1]  R617      -1.8674476444721222e-01
    z[4,0,1]  R618      1.7809976637363434e-01
    z[4,0,1]  R619      -4.5620836317539215e-02
    z[4,0,1]  R620      -2.5697553157806396e-01
    z[4,0,1]  R621      -0.725864589214325
    z[4,0,1]  R622      -5.9336471557617188e-01
    z[4,0,1]  R623      -1.5418398380279541e-01
    z[4,0,1]  R624      -7.1462118625640869e-01
    z[4,0,1]  R625      -6.9088816642761230e-01
    z[4,0,1]  R626      -8.2758784294128418e-01
    z[4,0,1]  R627      -5.2705746889114380e-01
    z[4,0,1]  R628      -8.5353112220764160e-01
    z[4,0,1]  R629      -7.9864984750747681e-01
    z[4,0,1]  R630      -9.2099231481552124e-01
    z[4,0,1]  R631      -5.0414168834686279e-01
    z[4,0,1]  R632      -7.7416580915451050e-01
    z[4,0,1]  R633      -8.3415180444717407e-01
    z[4,0,1]  R634      4.2863461375236511e-01
    z[4,0,1]  R635      5.2385592460632324e-01
    z[4,0,1]  R636      7.7788054943084717e-01
    z[4,0,1]  R637      5.1039779186248779e-01
    z[4,0,1]  R638      0.782328724861145
    z[4,0,1]  R639      9.3017423152923584e-01
    z[4,0,1]  R640      7.4598878622055054e-01
    z[4,0,1]  R641      6.2384688854217529e-01
    z[4,0,1]  R642      9.0567612648010254e-01
    z[4,0,1]  R643      8.4035253524780273e-01
    z[4,0,1]  R644      7.2656100988388062e-01
    z[4,0,1]  R645      0.54316645860672
    z[4,0,1]  R646      8.2122975587844849e-01
    z[4,0,1]  R647      3.5193365812301636e-01
    z[4,0,1]  R648      2.6572963595390320e-01
    z[4,0,1]  R649      6.3096469640731812e-01
    z[4,0,1]  R650      3.6601129174232483e-01
    z[4,0,1]  R651      5.9211635589599609e-01
    z[4,0,1]  R652      3.8181629776954651e-01
    z[4,0,1]  R653      3.8341113924980164e-01
    z[4,0,1]  R654      4.8087698221206665e-01
    z[4,0,1]  R655      7.4802255630493164e-01
    z[4,0,1]  R656      0.600898265838623
    z[4,0,1]  R657      3.2104572653770447e-01
    z[4,0,1]  R658      5.1311117410659790e-01
    z[4,0,1]  R659      0.793482780456543
    z[4,0,1]  R660      4.4519197940826416e-01
    z[4,0,1]  R661      -1.3799582421779633e-01
    z[4,0,1]  R662      -0.605397641658783
    z[4,0,1]  R663      5.4583203792572021e-01
    z[4,0,1]  R664      6.9718170166015625e-01
    z[4,0,1]  R665      4.2258173227310181e-01
    z[4,0,1]  R666      6.1684954166412354e-01
    z[4,0,1]  R667      -5.7018172740936279e-01
    z[4,0,1]  R668      1.1039377748966217e-01
    z[4,0,1]  R669      8.6186027526855469e-01
    z[4,0,1]  R670      5.7072877883911133e-01
    z[4,0,1]  R671      8.6363697052001953e-01
    z[4,0,1]  R672      7.0416003465652466e-01
    z[4,0,1]  R673      1.4872631430625916e-01
    z[4,0,1]  R674      3.2680952548980713e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R586      -1
    z[4,0,2]  R587      1
    z[4,0,2]  R596      -2.9798674583435059e-01
    z[4,0,2]  R597      -0.347235769033432
    z[4,0,2]  R598      -7.6188750565052032e-02
    z[4,0,2]  R599      2.3774772882461548e-01
    z[4,0,2]  R600      -0.0581904798746109
    z[4,0,2]  R601      4.2077171802520752e-01
    z[4,0,2]  R602      -2.3059609532356262e-01
    z[4,0,2]  R603      1.4783754944801331e-01
    z[4,0,2]  R604      -4.7947093844413757e-01
    z[4,0,2]  R605      -1.1642266064882278e-01
    z[4,0,2]  R606      3.3215153217315674e-01
    z[4,0,2]  R607      2.8857752680778503e-01
    z[4,0,2]  R608      5.6902801990509033e-01
    z[4,0,2]  R609      0.561430811882019
    z[4,0,2]  R610      5.6609356403350830e-01
    z[4,0,2]  R611      6.9370740652084351e-01
    z[4,0,2]  R612      4.2793425917625427e-01
    z[4,0,2]  R613      4.9629786610603333e-01
    z[4,0,2]  R614      2.9269164800643921e-01
    z[4,0,2]  R615      2.1162860095500946e-01
    z[4,0,2]  R616      -3.2568764686584473e-01
    z[4,0,2]  R617      -1.9889141619205475e-01
    z[4,0,2]  R618      -1.4858931303024292e-01
    z[4,0,2]  R619      2.5257551670074463e-01
    z[4,0,2]  R620      -4.2722240090370178e-02
    z[4,0,2]  R621      3.6074250936508179e-01
    z[4,0,2]  R622      1.5408769249916077e-01
    z[4,0,2]  R623      5.6516725569963455e-02
    z[4,0,2]  R624      -2.8202304244041443e-01
    z[4,0,2]  R625      -7.5585119426250458e-02
    z[4,0,2]  R626      2.4415375292301178e-01
    z[4,0,2]  R627      6.4707857370376587e-01
    z[4,0,2]  R628      2.7240115404129028e-01
    z[4,0,2]  R629      1.0018160194158554e-01
    z[4,0,2]  R630      -1.0218521207571030e-01
    z[4,0,2]  R631      4.6498867869377136e-01
    z[4,0,2]  R632      1.6942533850669861e-01
    z[4,0,2]  R633      -3.0455809831619263e-01
    z[4,0,2]  R634      3.7516161799430847e-01
    z[4,0,2]  R635      1.5947189927101135e-01
    z[4,0,2]  R636      -2.3742966353893280e-01
    z[4,0,2]  R637      4.0666827559471130e-01
    z[4,0,2]  R638      5.1089294254779816e-02
    z[4,0,2]  R639      -2.0245976746082306e-01
    z[4,0,2]  R640      4.5116788148880005e-01
    z[4,0,2]  R641      3.1718626618385315e-01
    z[4,0,2]  R642      -2.2297109663486481e-01
    z[4,0,2]  R643      1.5814979374408722e-01
    z[4,0,2]  R644      -1.4584209024906158e-01
    z[4,0,2]  R645      -4.3707605451345444e-02
    z[4,0,2]  R646      -9.2976361513137817e-02
    z[4,0,2]  R647      -4.3287232518196106e-01
    z[4,0,2]  R648      -1.6613063216209412e-01
    z[4,0,2]  R649      1.5279665589332581e-01
    z[4,0,2]  R650      2.2173093259334564e-01
    z[4,0,2]  R651      -2.2127854824066162e-01
    z[4,0,2]  R652      -1.9176118075847626e-02
    z[4,0,2]  R653      -1.9215150177478790e-01
    z[4,0,2]  R654      -4.6588137745857239e-01
    z[4,0,2]  R655      3.6818632483482361e-01
    z[4,0,2]  R656      1.9580742716789246e-01
    z[4,0,2]  R657      2.5650796294212341e-01
    z[4,0,2]  R658      4.0598914027214050e-01
    z[4,0,2]  R659      5.2883196622133255e-02
    z[4,0,2]  R660      1.0428345762193203e-02
    z[4,0,2]  R661      -1.7387193441390991e-01
    z[4,0,2]  R662      -4.5069187879562378e-01
    z[4,0,2]  R663      0.118861123919487
    z[4,0,2]  R664      4.8090755008161068e-03
    z[4,0,2]  R665      -1.7562119662761688e-01
    z[4,0,2]  R666      -3.9228554815053940e-02
    z[4,0,2]  R667      -5.5179435014724731e-01
    z[4,0,2]  R668      3.6836430430412292e-02
    z[4,0,2]  R669      1.0536435991525650e-01
    z[4,0,2]  R670      -3.7455025315284729e-01
    z[4,0,2]  R671      2.1165508031845093e-01
    z[4,0,2]  R672      2.3400449752807617e-01
    z[4,0,2]  R673      2.4168847501277924e-01
    z[4,0,2]  R674      6.5540504455566406e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R588      -1
    z[4,0,3]  R589      1
    z[4,0,3]  R596      -2.7236613631248474e-01
    z[4,0,3]  R597      4.8791030049324036e-01
    z[4,0,3]  R598      1.8327637016773224e-01
    z[4,0,3]  R599      4.3993502855300903e-01
    z[4,0,3]  R600      2.8136044740676880e-01
    z[4,0,3]  R601      -1.7711807787418365e-01
    z[4,0,3]  R602      -1.3692776858806610e-01
    z[4,0,3]  R603      -2.7051979303359985e-01
    z[4,0,3]  R604      9.7662389278411865e-02
    z[4,0,3]  R605      -2.1610608696937561e-01
    z[4,0,3]  R606      -3.7701785564422607e-01
    z[4,0,3]  R607      -6.3731677830219269e-02
    z[4,0,3]  R608      -4.6401996165513992e-02
    z[4,0,3]  R609      -8.5805654525756836e-02
    z[4,0,3]  R610      -1.5014901757240295e-01
    z[4,0,3]  R611      -5.4991997778415680e-02
    z[4,0,3]  R612      1.2495151162147522e-01
    z[4,0,3]  R613      7.7261097729206085e-02
    z[4,0,3]  R614      -4.2161926627159119e-02
    z[4,0,3]  R615      8.5739880800247192e-02
    z[4,0,3]  R616      -7.1150410175323486e-01
    z[4,0,3]  R617      -6.3634729385375977e-01
    z[4,0,3]  R618      -7.4254709482192993e-01
    z[4,0,3]  R619      -7.9481166601181030e-01
    z[4,0,3]  R620      -5.0166660547256470e-01
    z[4,0,3]  R621      -0.315601110458374
    z[4,0,3]  R622      -5.9093427658081055e-01
    z[4,0,3]  R623      -6.3995629549026489e-01
    z[4,0,3]  R624      1.8050726503133774e-02
    z[4,0,3]  R625      -6.0313421487808228e-01
    z[4,0,3]  R626      -2.6426699757575989e-01
    z[4,0,3]  R627      -4.0811866521835327e-01
    z[4,0,3]  R628      -1.8318356946110725e-02
    z[4,0,3]  R629      -3.3026996254920959e-01
    z[4,0,3]  R630      6.8596608936786652e-02
    z[4,0,3]  R631      -4.8660203814506531e-01
    z[4,0,3]  R632      2.5030849501490593e-02
    z[4,0,3]  R633      1.7117737233638763e-01
    z[4,0,3]  R634      6.2525969743728638e-01
    z[4,0,3]  R635      -2.2083206474781036e-01
    z[4,0,3]  R636      -1.8068033456802368e-01
    z[4,0,3]  R637      1.0851048678159714e-01
    z[4,0,3]  R638      -9.9475458264350891e-02
    z[4,0,3]  R639      -2.8459498286247253e-01
    z[4,0,3]  R640      -0.405542254447937
    z[4,0,3]  R641      0.0989881381392479
    z[4,0,3]  R642      -1.9643209874629974e-02
    z[4,0,3]  R643      -2.3548056185245514e-01
    z[4,0,3]  R644      -4.4133788347244263e-01
    z[4,0,3]  R645      5.6281000375747681e-01
    z[4,0,3]  R646      1.4149080216884613e-01
    z[4,0,3]  R647      7.3939192295074463e-01
    z[4,0,3]  R648      5.2539533376693726e-01
    z[4,0,3]  R649      1.8167947232723236e-01
    z[4,0,3]  R650      2.4998384714126587e-01
    z[4,0,3]  R651      4.9449887871742249e-01
    z[4,0,3]  R652      6.6805613040924072e-01
    z[4,0,3]  R653      5.3257602453231812e-01
    z[4,0,3]  R654      3.0099043250083923e-01
    z[4,0,3]  R655      1.6139744222164154e-01
    z[4,0,3]  R656      2.4999523162841797e-01
    z[4,0,3]  R657      3.2812726497650146e-01
    z[4,0,3]  R658      4.9095913767814636e-01
    z[4,0,3]  R659      4.9335297942161560e-01
    z[4,0,3]  R660      0.771373450756073
    z[4,0,3]  R661      -6.1114239692687988e-01
    z[4,0,3]  R662      -3.4578660130500793e-01
    z[4,0,3]  R663      6.4186424016952515e-01
    z[4,0,3]  R664      6.5114744007587433e-02
    z[4,0,3]  R665      3.3785501122474670e-01
    z[4,0,3]  R666      5.6813359260559082e-01
    z[4,0,3]  R667      -3.4559237957000732e-01
    z[4,0,3]  R668      -7.2367310523986816e-01
    z[4,0,3]  R669      2.1732898056507111e-01
    z[4,0,3]  R670      3.1666469573974609e-01
    z[4,0,3]  R671      -1.6486048698425293e-01
    z[4,0,3]  R672      -1.4926570653915405e-01
    z[4,0,3]  R673      -7.3794215917587280e-01
    z[4,0,3]  R674      -4.1002565622329712e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R590      -1
    z[4,0,4]  R591      1
    z[4,0,4]  R596      4.3432092666625977e-01
    z[4,0,4]  R597      3.4715458750724792e-01
    z[4,0,4]  R598      4.3599805235862732e-01
    z[4,0,4]  R599      6.2857642769813538e-02
    z[4,0,4]  R600      1.6727188229560852e-01
    z[4,0,4]  R601      3.2528951764106750e-01
    z[4,0,4]  R602      -4.4658705592155457e-02
    z[4,0,4]  R603      -1.3284756243228912e-01
    z[4,0,4]  R604      1.2144851684570312e-01
    z[4,0,4]  R605      4.8336514830589294e-01
    z[4,0,4]  R606      -1.4025740325450897e-01
    z[4,0,4]  R607      1.1695694178342819e-01
    z[4,0,4]  R608      2.9780622571706772e-02
    z[4,0,4]  R609      -0.113673135638237
    z[4,0,4]  R610      9.4564080238342285e-02
    z[4,0,4]  R611      -2.2984115406870842e-02
    z[4,0,4]  R612      1.2909808754920959e-01
    z[4,0,4]  R613      -1.5918545424938202e-01
    z[4,0,4]  R614      -1.1347037553787231e-01
    z[4,0,4]  R615      -1.8654270470142365e-01
    z[4,0,4]  R616      1.5339119732379913e-01
    z[4,0,4]  R617      -8.2135021686553955e-02
    z[4,0,4]  R618      8.2185156643390656e-02
    z[4,0,4]  R619      -1.1228418350219727e-01
    z[4,0,4]  R620      2.6528099179267883e-01
    z[4,0,4]  R621      -4.2539444565773010e-01
    z[4,0,4]  R622      9.4021543860435486e-02
    z[4,0,4]  R623      -4.5273822546005249e-01
    z[4,0,4]  R624      -0.379819393157959
    z[4,0,4]  R625      -7.7204527333378792e-03
    z[4,0,4]  R626      4.5496243983507156e-02
    z[4,0,4]  R627      -3.1085941195487976e-01
    z[4,0,4]  R628      -6.0165543109178543e-02
    z[4,0,4]  R629      -1.1988577991724014e-01
    z[4,0,4]  R630      -8.8058109395205975e-04
    z[4,0,4]  R631      -1.5633161365985870e-01
    z[4,0,4]  R632      2.2820717096328735e-01
    z[4,0,4]  R633      -0.0789557546377182
    z[4,0,4]  R634      -3.4042972326278687e-01
    z[4,0,4]  R635      8.3188056945800781e-02
    z[4,0,4]  R636      3.5270789265632629e-01
    z[4,0,4]  R637      0.625708818435669
    z[4,0,4]  R638      4.3101277947425842e-01
    z[4,0,4]  R639      0.0524633526802063
    z[4,0,4]  R640      -8.2717090845108032e-02
    z[4,0,4]  R641      5.2935957908630371e-02
    z[4,0,4]  R642      1.2602145969867706e-01
    z[4,0,4]  R643      4.1201531887054443e-02
    z[4,0,4]  R644      1.8331001698970795e-01
    z[4,0,4]  R645      5.5005115270614624e-01
    z[4,0,4]  R646      -1.6806045174598694e-01
    z[4,0,4]  R647      2.3589572310447693e-01
    z[4,0,4]  R648      5.1857888698577881e-01
    z[4,0,4]  R649      3.3163938671350479e-02
    z[4,0,4]  R650      -3.9490621536970139e-02
    z[4,0,4]  R651      2.5820270180702209e-01
    z[4,0,4]  R652      2.3370358347892761e-01
    z[4,0,4]  R653      -6.8685412406921387e-02
    z[4,0,4]  R654      -1.0905279964208603e-01
    z[4,0,4]  R655      -4.2552232742309570e-02
    z[4,0,4]  R656      4.1010481119155884e-01
    z[4,0,4]  R657      2.1401986479759216e-01
    z[4,0,4]  R658      2.1495439112186432e-01
    z[4,0,4]  R659      2.3247393965721130e-01
    z[4,0,4]  R660      -8.0415733158588409e-02
    z[4,0,4]  R661      4.5572139322757721e-02
    z[4,0,4]  R662      3.4023562073707581e-01
    z[4,0,4]  R663      -1.7753715813159943e-01
    z[4,0,4]  R664      1.1264232546091080e-01
    z[4,0,4]  R665      -1.6377037763595581e-01
    z[4,0,4]  R666      -3.1421598792076111e-01
    z[4,0,4]  R667      2.8071027994155884e-01
    z[4,0,4]  R668      2.8293186426162720e-01
    z[4,0,4]  R669      6.4598284661769867e-02
    z[4,0,4]  R670      2.4649754166603088e-01
    z[4,0,4]  R671      -1.2283524870872498e-01
    z[4,0,4]  R672      2.3887798190116882e-01
    z[4,0,4]  R673      2.6853394508361816e-01
    z[4,0,4]  R674      -4.5189116150140762e-02
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R592      -1
    z[4,0,5]  R593      1
    z[4,0,5]  R596      -1.1757581681013107e-01
    z[4,0,5]  R597      -6.0707405209541321e-02
    z[4,0,5]  R598      6.5165506675839424e-03
    z[4,0,5]  R599      -3.0680984258651733e-01
    z[4,0,5]  R600      1.6882508993148804e-01
    z[4,0,5]  R601      -4.3570473790168762e-01
    z[4,0,5]  R602      2.8054052591323853e-01
    z[4,0,5]  R603      -3.7503218650817871e-01
    z[4,0,5]  R604      4.0232893824577332e-01
    z[4,0,5]  R605      8.7758600711822510e-02
    z[4,0,5]  R606      -2.8529292345046997e-01
    z[4,0,5]  R607      -1.2879328429698944e-01
    z[4,0,5]  R608      3.3906564116477966e-01
    z[4,0,5]  R609      1.3632264733314514e-01
    z[4,0,5]  R610      1.3902534544467926e-01
    z[4,0,5]  R611      1.9321456551551819e-01
    z[4,0,5]  R612      1.4572256803512573e-01
    z[4,0,5]  R613      3.3065313100814819e-01
    z[4,0,5]  R614      3.3350548148155212e-01
    z[4,0,5]  R615      2.5434008240699768e-01
    z[4,0,5]  R616      0.0653185248374939
    z[4,0,5]  R617      6.4751470088958740e-01
    z[4,0,5]  R618      -2.3476819694042206e-01
    z[4,0,5]  R619      4.9129912257194519e-01
    z[4,0,5]  R620      3.8730046153068542e-01
    z[4,0,5]  R621      2.4547970294952393e-01
    z[4,0,5]  R622      -4.3531551957130432e-01
    z[4,0,5]  R623      2.4686281383037567e-01
    z[4,0,5]  R624      5.7919424027204514e-02
    z[4,0,5]  R625      3.5248550772666931e-01
    z[4,0,5]  R626      -1.8579567968845367e-01
    z[4,0,5]  R627      -1.3986136019229889e-01
    z[4,0,5]  R628      3.4295409917831421e-01
    z[4,0,5]  R629      -3.0872318148612976e-01
    z[4,0,5]  R630      3.6392825841903687e-01
    z[4,0,5]  R631      2.9768466949462891e-01
    z[4,0,5]  R632      -2.5655742734670639e-02
    z[4,0,5]  R633      0.0423213467001915
    z[4,0,5]  R634      -2.7284887433052063e-01
    z[4,0,5]  R635      -1.4773845672607422e-01
    z[4,0,5]  R636      -0.156717449426651
    z[4,0,5]  R637      1.5973153710365295e-01
    z[4,0,5]  R638      2.8820648789405823e-01
    z[4,0,5]  R639      8.1712851533666253e-04
    z[4,0,5]  R640      -4.1467282921075821e-02
    z[4,0,5]  R641      2.6289626955986023e-01
    z[4,0,5]  R642      -1.0409022122621536e-01
    z[4,0,5]  R643      0.084237240254879
    z[4,0,5]  R644      -4.5615535974502563e-01
    z[4,0,5]  R645      -1.3084410130977631e-01
    z[4,0,5]  R646      -2.8830143809318542e-01
    z[4,0,5]  R647      -0.164118230342865
    z[4,0,5]  R648      -1.4126639068126678e-01
    z[4,0,5]  R649      -5.7881736755371094e-01
    z[4,0,5]  R650      -2.4380034208297729e-01
    z[4,0,5]  R651      -4.7147154808044434e-01
    z[4,0,5]  R652      7.7939346432685852e-02
    z[4,0,5]  R653      3.9999324083328247e-01
    z[4,0,5]  R654      -7.4565164744853973e-02
    z[4,0,5]  R655      -3.2411959767341614e-01
    z[4,0,5]  R656      -3.5526511073112488e-01
    z[4,0,5]  R657      -5.4933613538742065e-01
    z[4,0,5]  R658      1.6533279418945312e-01
    z[4,0,5]  R659      2.3109537363052368e-01
    z[4,0,5]  R660      -2.4901962280273438e-01
    z[4,0,5]  R661      -4.3133646249771118e-01
    z[4,0,5]  R662      -3.3600360155105591e-01
    z[4,0,5]  R663      3.9849165081977844e-01
    z[4,0,5]  R664      5.0299203395843506e-01
    z[4,0,5]  R665      -4.7456416487693787e-01
    z[4,0,5]  R666      2.3958018422126770e-01
    z[4,0,5]  R667      -6.1677344143390656e-02
    z[4,0,5]  R668      -4.3604883551597595e-01
    z[4,0,5]  R669      -1.0302336513996124e-01
    z[4,0,5]  R670      -1.4970052242279053e-01
    z[4,0,5]  R671      3.0528476834297180e-01
    z[4,0,5]  R672      -2.1967029571533203e-01
    z[4,0,5]  R673      -7.0856891572475433e-02
    z[4,0,5]  R674      -3.5500779747962952e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R594      -1
    z[4,0,6]  R595      1
    z[4,0,6]  R596      -1.5190209448337555e-01
    z[4,0,6]  R597      -0.163969486951828
    z[4,0,6]  R598      -3.9161231368780136e-02
    z[4,0,6]  R599      -4.0611866116523743e-01
    z[4,0,6]  R600      -4.7003483772277832e-01
    z[4,0,6]  R601      -2.0241707563400269e-02
    z[4,0,6]  R602      -6.9713217020034790e-01
    z[4,0,6]  R603      0.232675239443779
    z[4,0,6]  R604      4.9797871708869934e-01
    z[4,0,6]  R605      5.3369772434234619e-01
    z[4,0,6]  R606      -3.7772583961486816e-01
    z[4,0,6]  R607      -6.6972541809082031e-01
    z[4,0,6]  R608      -2.3642625659704208e-02
    z[4,0,6]  R609      8.2296334207057953e-02
    z[4,0,6]  R610      8.4611341357231140e-02
    z[4,0,6]  R611      2.0963713526725769e-01
    z[4,0,6]  R612      7.9340517520904541e-02
    z[4,0,6]  R613      2.8665328025817871e-01
    z[4,0,6]  R614      2.7062943577766418e-01
    z[4,0,6]  R615      -0.0859035924077034
    z[4,0,6]  R616      -0.061029102653265
    z[4,0,6]  R617      -1.0491538792848587e-01
    z[4,0,6]  R618      3.1203892827033997e-01
    z[4,0,6]  R619      -2.1331250667572021e-01
    z[4,0,6]  R620      -6.7336338758468628e-01
    z[4,0,6]  R621      -4.6480432152748108e-02
    z[4,0,6]  R622      -5.9714134782552719e-02
    z[4,0,6]  R623      3.8336774706840515e-01
    z[4,0,6]  R624      8.4399670362472534e-02
    z[4,0,6]  R625      -1.6835945844650269e-01
    z[4,0,6]  R626      3.8516694307327271e-01
    z[4,0,6]  R627      -1.2514501810073853e-01
    z[4,0,6]  R628      -3.1389329582452774e-02
    z[4,0,6]  R629      -6.5383620560169220e-02
    z[4,0,6]  R630      6.4385667443275452e-02
    z[4,0,6]  R631      4.2391490936279297e-01
    z[4,0,6]  R632      -3.4991465508937836e-02
    z[4,0,6]  R633      -1.1311710625886917e-01
    z[4,0,6]  R634      -4.8196125775575638e-02
    z[4,0,6]  R635      8.2779310643672943e-02
    z[4,0,6]  R636      0.105648472905159
    z[4,0,6]  R637      1.4468035101890564e-01
    z[4,0,6]  R638      1.3364803791046143e-01
    z[4,0,6]  R639      -6.4286895096302032e-02
    z[4,0,6]  R640      2.1512460708618164e-01
    z[4,0,6]  R641      -1.1096056550741196e-01
    z[4,0,6]  R642      -2.8705963492393494e-01
    z[4,0,6]  R643      -0.242411807179451
    z[4,0,6]  R644      7.9782538115978241e-02
    z[4,0,6]  R645      -2.0963051915168762e-01
    z[4,0,6]  R646      -2.1987858414649963e-01
    z[4,0,6]  R647      -0.091742604970932
    z[4,0,6]  R648      -1.2191002815961838e-01
    z[4,0,6]  R649      4.2908000946044922e-01
    z[4,0,6]  R650      -7.1778148412704468e-01
    z[4,0,6]  R651      2.4404789507389069e-01
    z[4,0,6]  R652      0.525579035282135
    z[4,0,6]  R653      -3.0778363347053528e-01
    z[4,0,6]  R654      1.0134135931730270e-01
    z[4,0,6]  R655      -1.8911491334438324e-01
    z[4,0,6]  R656      1.5260358154773712e-01
    z[4,0,6]  R657      -2.1925979852676392e-01
    z[4,0,6]  R658      2.7590745687484741e-01
    z[4,0,6]  R659      0.0811280682682991
    z[4,0,6]  R660      3.1139880418777466e-01
    z[4,0,6]  R661      2.9627183079719543e-01
    z[4,0,6]  R662      -2.8173670172691345e-01
    z[4,0,6]  R663      -1.9948931038379669e-01
    z[4,0,6]  R664      0.273754358291626
    z[4,0,6]  R665      -2.8750661015510559e-01
    z[4,0,6]  R666      8.4515912458300591e-03
    z[4,0,6]  R667      2.9808378219604492e-01
    z[4,0,6]  R668      4.3686878681182861e-01
    z[4,0,6]  R669      -2.1537633240222931e-01
    z[4,0,6]  R670      0.579052209854126
    z[4,0,6]  R671      2.7095130085945129e-01
    z[4,0,6]  R672      3.4633249044418335e-01
    z[4,0,6]  R673      7.9971216619014740e-02
    z[4,0,6]  R674      -1.1906320601701736e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R739      -1
    z[1,2,0]  R740      1
    z[1,2,0]  R753      -2.3927323520183563e-01
    z[1,2,0]  R754      -9.3068093061447144e-02
    z[1,2,0]  R755      -1.8396428227424622e-01
    z[1,2,0]  R756      1.1003871262073517e-01
    z[1,2,0]  R757      -4.2539175599813461e-02
    z[1,2,0]  R758      -3.0694505572319031e-01
    z[1,2,0]  R759      2.3849646747112274e-01
    z[1,2,0]  R760      -2.5389662384986877e-01
    z[1,2,0]  R761      -3.2029229402542114e-01
    z[1,2,0]  R762      -1.6619090735912323e-01
    z[1,2,0]  R763      6.6466385126113892e-01
    z[1,2,0]  R764      -4.7198975086212158e-01
    z[1,2,0]  R765      -7.8905403614044189e-01
    z[1,2,0]  R766      -0.89189612865448
    z[1,2,0]  R767      -3.1033545732498169e-01
    z[1,2,0]  R768      -5.1954627037048340e-01
    z[1,2,0]  R769      -3.0689609050750732e-01
    z[1,2,0]  R770      3.9101323485374451e-01
    z[1,2,0]  R771      -2.4056018888950348e-01
    z[1,2,0]  R772      -2.3183842003345490e-01
    z[1,2,0]  R773      3.5448500514030457e-01
    z[1,2,0]  R774      1.2213188409805298e-01
    z[1,2,0]  R775      4.4516941905021667e-01
    z[1,2,0]  R776      7.5336650013923645e-02
    z[1,2,0]  R777      2.0835784077644348e-01
    z[1,2,0]  R778      3.7897145748138428e-01
    z[1,2,0]  R779      -2.0715612173080444e-01
    z[1,2,0]  R780      6.3558273017406464e-02
    z[1,2,0]  R781      1.4043904957361519e-04
    z[1,2,0]  R782      -5.2889108657836914e-01
    z[1,2,0]  R783      0.124534472823143
    z[1,2,0]  R784      3.2512968778610229e-01
    z[1,2,0]  R785      1.2217810004949570e-01
    z[1,2,0]  R786      -0.0638943687081337
    z[1,2,0]  R787      3.9143315516412258e-03
    z[1,2,0]  R788      -5.3495984524488449e-02
    z[1,2,0]  R789      -6.1061024665832520e-01
    z[1,2,0]  R790      -3.2372646033763885e-02
    z[1,2,0]  R791      -1.4620240032672882e-01
    z[1,2,0]  R792      -5.6994175910949707e-01
    z[1,2,0]  R793      5.4328281432390213e-02
    z[1,2,0]  R794      -7.7049273252487183e-01
    z[1,2,0]  R795      -3.6872324347496033e-01
    z[1,2,0]  R796      -3.8276901841163635e-01
    z[1,2,0]  R797      -0.460308313369751
    z[1,2,0]  R798      -3.8408553600311279e-01
    z[1,2,0]  R799      5.7115048170089722e-01
    z[1,2,0]  R800      -2.7225458621978760e-01
    z[1,2,0]  R801      5.5754220485687256e-01
    z[1,2,0]  R802      3.1432923674583435e-01
    z[1,2,0]  R803      1.1821191757917404e-01
    z[1,2,0]  R804      -4.2595438659191132e-02
    z[1,2,0]  R805      -2.8032967820763588e-02
    z[1,2,0]  R806      2.3776893317699432e-01
    z[1,2,0]  R807      7.2030341625213623e-01
    z[1,2,0]  R808      3.6836597323417664e-01
    z[1,2,0]  R809      6.8994998931884766e-01
    z[1,2,0]  R810      5.5068814754486084e-01
    z[1,2,0]  R811      3.8371109962463379e-01
    z[1,2,0]  R812      -5.1737666130065918e-01
    z[1,2,0]  R813      5.7984985411167145e-02
    z[1,2,0]  R814      -3.4597349166870117e-01
    z[1,2,0]  R815      -6.9435632228851318e-01
    z[1,2,0]  R816      -5.8090382814407349e-01
    z[1,2,0]  R817      -7.2835075855255127e-01
    z[1,2,0]  R818      -6.3251376152038574e-01
    z[1,2,0]  R819      -0.282098650932312
    z[1,2,0]  R820      -8.0061239004135132e-01
    z[1,2,0]  R821      2.9811334609985352e-01
    z[1,2,0]  R822      -0.727404773235321
    z[1,2,0]  R823      -6.9134902954101562e-01
    z[1,2,0]  R824      -3.8005176186561584e-01
    z[1,2,0]  R825      2.9792213439941406e-01
    z[1,2,0]  R826      2.5141090154647827e-01
    z[1,2,0]  R827      4.8459729552268982e-01
    z[1,2,0]  R828      2.2911366820335388e-01
    z[1,2,0]  R829      2.8318625688552856e-01
    z[1,2,0]  R830      1.4619770646095276e-01
    z[1,2,0]  R831      5.0927591323852539e-01
    z[1,2,0]  R832      -3.6842474341392517e-01
    z[1,2,0]  R833      3.8788583874702454e-01
    z[1,2,0]  R834      0.511343777179718
    z[1,2,0]  R835      4.3528911471366882e-01
    z[1,2,0]  R836      2.7572733163833618e-01
    z[1,2,0]  R837      0.501968264579773
    z[1,2,0]  R838      2.5607383251190186e-01
    z[1,2,0]  R839      4.8280277848243713e-01
    z[1,2,0]  R840      1.5415605902671814e-01
    z[1,2,0]  R841      1.2871250510215759e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R741      -1
    z[1,2,1]  R742      1
    z[1,2,1]  R753      -2.3412662744522095e-01
    z[1,2,1]  R754      -3.2256475090980530e-01
    z[1,2,1]  R755      -3.6999046802520752e-01
    z[1,2,1]  R756      -5.2285623550415039e-01
    z[1,2,1]  R757      -4.6815851330757141e-01
    z[1,2,1]  R758      -4.2803874611854553e-01
    z[1,2,1]  R759      -7.1605294942855835e-01
    z[1,2,1]  R760      6.4604789018630981e-01
    z[1,2,1]  R761      8.5382020473480225e-01
    z[1,2,1]  R762      8.7410008907318115e-01
    z[1,2,1]  R763      -2.1206778287887573e-01
    z[1,2,1]  R764      5.5650299787521362e-01
    z[1,2,1]  R765      2.7068966627120972e-01
    z[1,2,1]  R766      2.0389008522033691e-01
    z[1,2,1]  R767      2.8315299749374390e-01
    z[1,2,1]  R768      3.0223432183265686e-01
    z[1,2,1]  R769      -1.4377743005752563e-01
    z[1,2,1]  R770      -2.0649042725563049e-01
    z[1,2,1]  R771      8.2114261388778687e-01
    z[1,2,1]  R772      7.1400213241577148e-01
    z[1,2,1]  R773      -3.3164060115814209e-01
    z[1,2,1]  R774      -1.8140999972820282e-01
    z[1,2,1]  R775      -5.1794147491455078e-01
    z[1,2,1]  R776      -5.0821495056152344e-01
    z[1,2,1]  R777      -6.5732920169830322e-01
    z[1,2,1]  R778      -5.3367048501968384e-01
    z[1,2,1]  R779      -5.9342402219772339e-01
    z[1,2,1]  R780      2.9371902346611023e-01
    z[1,2,1]  R781      3.0722531676292419e-01
    z[1,2,1]  R782      7.0174783468246460e-01
    z[1,2,1]  R783      -5.3573852777481079e-01
    z[1,2,1]  R784      -7.3988282680511475e-01
    z[1,2,1]  R785      -1.4559482038021088e-01
    z[1,2,1]  R786      -6.6544854640960693e-01
    z[1,2,1]  R787      2.6029470562934875e-01
    z[1,2,1]  R788      0.684913694858551
    z[1,2,1]  R789      5.3332304954528809e-01
    z[1,2,1]  R790      7.8472161293029785e-01
    z[1,2,1]  R791      8.9037430286407471e-01
    z[1,2,1]  R792      0.710384726524353
    z[1,2,1]  R793      -4.5226737856864929e-01
    z[1,2,1]  R794      2.4580633640289307e-01
    z[1,2,1]  R795      6.3817453384399414e-01
    z[1,2,1]  R796      -5.0469082593917847e-01
    z[1,2,1]  R797      7.7087897062301636e-01
    z[1,2,1]  R798      7.6046824455261230e-01
    z[1,2,1]  R799      7.8955745697021484e-01
    z[1,2,1]  R800      2.1833692491054535e-01
    z[1,2,1]  R801      7.0232802629470825e-01
    z[1,2,1]  R802      4.3151691555976868e-01
    z[1,2,1]  R803      4.2549699544906616e-01
    z[1,2,1]  R804      5.2562618255615234e-01
    z[1,2,1]  R805      5.6732589006423950e-01
    z[1,2,1]  R806      8.2880979776382446e-01
    z[1,2,1]  R807      -6.1817508935928345e-01
    z[1,2,1]  R808      -2.8042098879814148e-01
    z[1,2,1]  R809      -3.8915368914604187e-01
    z[1,2,1]  R810      -0.612704873085022
    z[1,2,1]  R811      -3.9651420712471008e-01
    z[1,2,1]  R812      4.7555673122406006e-01
    z[1,2,1]  R813      0.518293559551239
    z[1,2,1]  R814      2.9023453593254089e-01
    z[1,2,1]  R815      3.4667372703552246e-01
    z[1,2,1]  R816      3.2177156209945679e-01
    z[1,2,1]  R817      -1.8335235118865967e-01
    z[1,2,1]  R818      -7.5615622103214264e-02
    z[1,2,1]  R819      2.2285100817680359e-01
    z[1,2,1]  R820      -1.9160155951976776e-01
    z[1,2,1]  R821      -7.9132926464080811e-01
    z[1,2,1]  R822      5.5986744165420532e-01
    z[1,2,1]  R823      2.4091683328151703e-01
    z[1,2,1]  R824      -2.6302519440650940e-01
    z[1,2,1]  R825      -8.7849563360214233e-01
    z[1,2,1]  R826      -9.0676325559616089e-01
    z[1,2,1]  R827      -0.81097811460495
    z[1,2,1]  R828      -9.1801899671554565e-01
    z[1,2,1]  R829      -8.8772386312484741e-01
    z[1,2,1]  R830      -9.1601639986038208e-01
    z[1,2,1]  R831      -7.4158489704132080e-01
    z[1,2,1]  R832      4.2555916309356689e-01
    z[1,2,1]  R833      -0.866968035697937
    z[1,2,1]  R834      -6.5728002786636353e-01
    z[1,2,1]  R835      -4.3178817629814148e-01
    z[1,2,1]  R836      -4.6381074190139771e-01
    z[1,2,1]  R837      -2.9665133357048035e-01
    z[1,2,1]  R838      -4.6428361535072327e-01
    z[1,2,1]  R839      -4.8970067501068115e-01
    z[1,2,1]  R840      -5.3583443164825439e-01
    z[1,2,1]  R841      -5.1682722568511963e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R743      -1
    z[1,2,2]  R744      1
    z[1,2,2]  R753      7.8288090229034424e-01
    z[1,2,2]  R754      6.9121789932250977e-01
    z[1,2,2]  R755      2.7046054601669312e-01
    z[1,2,2]  R756      -9.0173922479152679e-02
    z[1,2,2]  R757      0.612095057964325
    z[1,2,2]  R758      4.0137669444084167e-01
    z[1,2,2]  R759      -2.8709178790450096e-02
    z[1,2,2]  R760      -3.5165694355964661e-01
    z[1,2,2]  R761      7.7848076820373535e-02
    z[1,2,2]  R762      -2.6500681042671204e-01
    z[1,2,2]  R763      -1.8514315783977509e-01
    z[1,2,2]  R764      5.4202932119369507e-01
    z[1,2,2]  R765      -1.2013711780309677e-01
    z[1,2,2]  R766      3.0058783292770386e-01
    z[1,2,2]  R767      -3.3320057392120361e-01
    z[1,2,2]  R768      -2.3354759812355042e-01
    z[1,2,2]  R769      -2.6625505089759827e-01
    z[1,2,2]  R770      2.5235649943351746e-01
    z[1,2,2]  R771      -1.5740875899791718e-01
    z[1,2,2]  R772      2.9138955473899841e-01
    z[1,2,2]  R773      2.7108547091484070e-01
    z[1,2,2]  R774      4.9036440253257751e-01
    z[1,2,2]  R775      3.1304258108139038e-01
    z[1,2,2]  R776      3.3663868904113770e-01
    z[1,2,2]  R777      -2.5620761513710022e-01
    z[1,2,2]  R778      -3.8797748088836670e-01
    z[1,2,2]  R779      -1.6617652773857117e-01
    z[1,2,2]  R780      5.5452769994735718e-01
    z[1,2,2]  R781      5.9412352740764618e-02
    z[1,2,2]  R782      2.2869819402694702e-01
    z[1,2,2]  R783      7.1511673927307129e-01
    z[1,2,2]  R784      -2.6457920670509338e-01
    z[1,2,2]  R785      4.2584562301635742e-01
    z[1,2,2]  R786      -1.1458848416805267e-01
    z[1,2,2]  R787      -6.1519676446914673e-01
    z[1,2,2]  R788      -1.7192934453487396e-01
    z[1,2,2]  R789      -2.2272443771362305e-01
    z[1,2,2]  R790      -2.4329580366611481e-01
    z[1,2,2]  R791      -2.7469378709793091e-01
    z[1,2,2]  R792      1.3224802911281586e-02
    z[1,2,2]  R793      -1.1340240389108658e-01
    z[1,2,2]  R794      3.0671819113194942e-03
    z[1,2,2]  R795      5.8155737817287445e-02
    z[1,2,2]  R796      2.9615920782089233e-01
    z[1,2,2]  R797      -0.0243210606276989
    z[1,2,2]  R798      -3.4894734621047974e-01
    z[1,2,2]  R799      -1.1464491486549377e-01
    z[1,2,2]  R800      -6.2834733724594116e-01
    z[1,2,2]  R801      -2.8288549184799194e-01
    z[1,2,2]  R802      -1.4077208936214447e-01
    z[1,2,2]  R803      9.7302317619323730e-02
    z[1,2,2]  R804      -2.1837297081947327e-01
    z[1,2,2]  R805      1.1307616531848907e-01
    z[1,2,2]  R806      -1.9834028184413910e-01
    z[1,2,2]  R807      -1.0964637994766235e-01
    z[1,2,2]  R808      8.0503863096237183e-01
    z[1,2,2]  R809      4.9628299474716187e-01
    z[1,2,2]  R810      4.6857553720474243e-01
    z[1,2,2]  R811      -0.295538067817688
    z[1,2,2]  R812      -2.3308368399739265e-02
    z[1,2,2]  R813      -4.4742828607559204e-01
    z[1,2,2]  R814      -5.0015095621347427e-02
    z[1,2,2]  R815      1.6715654730796814e-01
    z[1,2,2]  R816      3.5724112391471863e-01
    z[1,2,2]  R817      2.2476868331432343e-01
    z[1,2,2]  R818      5.4395663738250732e-01
    z[1,2,2]  R819      -1.1327151954174042e-01
    z[1,2,2]  R820      0.394095242023468
    z[1,2,2]  R821      -2.5027871131896973e-01
    z[1,2,2]  R822      2.8507426381111145e-01
    z[1,2,2]  R823      9.3729391694068909e-02
    z[1,2,2]  R824      2.3452764749526978e-01
    z[1,2,2]  R825      -6.1158183962106705e-02
    z[1,2,2]  R826      1.6787745058536530e-01
    z[1,2,2]  R827      -1.3995537161827087e-01
    z[1,2,2]  R828      4.8986006528139114e-02
    z[1,2,2]  R829      1.9130004942417145e-01
    z[1,2,2]  R830      1.5195025503635406e-01
    z[1,2,2]  R831      -2.1155475080013275e-01
    z[1,2,2]  R832      -2.0650514960289001e-01
    z[1,2,2]  R833      -3.3399043604731560e-03
    z[1,2,2]  R834      8.1033043563365936e-02
    z[1,2,2]  R835      6.9183951616287231e-01
    z[1,2,2]  R836      6.9558727741241455e-01
    z[1,2,2]  R837      0.603071391582489
    z[1,2,2]  R838      0.738192081451416
    z[1,2,2]  R839      4.5026838779449463e-01
    z[1,2,2]  R840      6.5014606714248657e-01
    z[1,2,2]  R841      0.777576744556427
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R745      -1
    z[1,2,3]  R746      1
    z[1,2,3]  R753      -1.3675062358379364e-01
    z[1,2,3]  R754      -1.2978547811508179e-01
    z[1,2,3]  R755      -2.1833953261375427e-01
    z[1,2,3]  R756      -0.192160502076149
    z[1,2,3]  R757      2.3703585565090179e-01
    z[1,2,3]  R758      1.8773065507411957e-01
    z[1,2,3]  R759      4.6362329274415970e-02
    z[1,2,3]  R760      -1.2510886788368225e-01
    z[1,2,3]  R761      -1.6061370074748993e-01
    z[1,2,3]  R762      -2.4646823108196259e-01
    z[1,2,3]  R763      -6.7244774103164673e-01
    z[1,2,3]  R764      -3.4394088387489319e-01
    z[1,2,3]  R765      1.5020883083343506e-01
    z[1,2,3]  R766      1.7196573317050934e-01
    z[1,2,3]  R767      -3.5162393003702164e-02
    z[1,2,3]  R768      -3.5772061347961426e-01
    z[1,2,3]  R769      -0.360651433467865
    z[1,2,3]  R770      1.1904857121407986e-02
    z[1,2,3]  R771      1.0218356549739838e-01
    z[1,2,3]  R772      7.6278068125247955e-02
    z[1,2,3]  R773      -1.2785153090953827e-01
    z[1,2,3]  R774      -3.0141493678092957e-01
    z[1,2,3]  R775      3.7640803493559361e-03
    z[1,2,3]  R776      4.3715375661849976e-01
    z[1,2,3]  R777      5.1293814182281494e-01
    z[1,2,3]  R778      1.5632462501525879e-01
    z[1,2,3]  R779      6.3311499357223511e-01
    z[1,2,3]  R780      -5.8447301387786865e-01
    z[1,2,3]  R781      -2.7181667089462280e-01
    z[1,2,3]  R782      -7.3082715272903442e-02
    z[1,2,3]  R783      -3.0466508865356445e-01
    z[1,2,3]  R784      -1.4586928486824036e-01
    z[1,2,3]  R785      -3.5448685288429260e-01
    z[1,2,3]  R786      5.7399606704711914e-01
    z[1,2,3]  R787      -5.2418279647827148e-01
    z[1,2,3]  R788      -0.277119517326355
    z[1,2,3]  R789      -1.5559767186641693e-01
    z[1,2,3]  R790      -4.8624446988105774e-01
    z[1,2,3]  R791      -1.8034832552075386e-02
    z[1,2,3]  R792      3.2120910286903381e-01
    z[1,2,3]  R793      2.6803153753280640e-01
    z[1,2,3]  R794      -4.8867025971412659e-01
    z[1,2,3]  R795      -7.2287283837795258e-02
    z[1,2,3]  R796      5.6514286994934082e-01
    z[1,2,3]  R797      2.9438361525535583e-01
    z[1,2,3]  R798      8.9321218430995941e-02
    z[1,2,3]  R799      1.5312604606151581e-02
    z[1,2,3]  R800      -0.288524866104126
    z[1,2,3]  R801      0.1168212890625
    z[1,2,3]  R802      1.5378223359584808e-01
    z[1,2,3]  R803      -2.1045181900262833e-02
    z[1,2,3]  R804      1.5678630769252777e-01
    z[1,2,3]  R805      0.206902414560318
    z[1,2,3]  R806      2.7443605661392212e-01
    z[1,2,3]  R807      -1.2152399122714996e-01
    z[1,2,3]  R808      1.6491317749023438e-01
    z[1,2,3]  R809      -9.8055362701416016e-02
    z[1,2,3]  R810      2.6900875568389893e-01
    z[1,2,3]  R811      7.0876121520996094e-01
    z[1,2,3]  R812      -4.3087130784988403e-01
    z[1,2,3]  R813      -5.1461577415466309e-01
    z[1,2,3]  R814      -6.5086215734481812e-01
    z[1,2,3]  R815      1.0967974364757538e-01
    z[1,2,3]  R816      2.5317004323005676e-01
    z[1,2,3]  R817      -3.0487614870071411e-01
    z[1,2,3]  R818      -4.6829420328140259e-01
    z[1,2,3]  R819      4.8402658104896545e-01
    z[1,2,3]  R820      2.2843122482299805e-01
    z[1,2,3]  R821      2.0251031219959259e-01
    z[1,2,3]  R822      -0.0773281380534172
    z[1,2,3]  R823      0.431424617767334
    z[1,2,3]  R824      -6.8704259395599365e-01
    z[1,2,3]  R825      2.6176929473876953e-01
    z[1,2,3]  R826      1.0777126997709274e-01
    z[1,2,3]  R827      -1.5613524615764618e-01
    z[1,2,3]  R828      -1.8808171153068542e-01
    z[1,2,3]  R829      -2.1368660032749176e-01
    z[1,2,3]  R830      -7.0396766066551208e-02
    z[1,2,3]  R831      -2.1032449603080750e-01
    z[1,2,3]  R832      6.5436446666717529e-01
    z[1,2,3]  R833      -1.0747081041336060e-01
    z[1,2,3]  R834      1.3733908534049988e-01
    z[1,2,3]  R835      -2.0159746706485748e-01
    z[1,2,3]  R836      5.9304811060428619e-02
    z[1,2,3]  R837      -1.3849201798439026e-01
    z[1,2,3]  R838      1.3117182254791260e-01
    z[1,2,3]  R839      -1.4365708827972412e-01
    z[1,2,3]  R840      -8.5474856197834015e-02
    z[1,2,3]  R841      -3.2779112458229065e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R747      -1
    z[1,2,4]  R748      1
    z[1,2,4]  R753      3.7444502115249634e-01
    z[1,2,4]  R754      4.6636760234832764e-01
    z[1,2,4]  R755      7.1435712277889252e-02
    z[1,2,4]  R756      3.0189543962478638e-01
    z[1,2,4]  R757      4.6917036175727844e-01
    z[1,2,4]  R758      -6.2298811972141266e-02
    z[1,2,4]  R759      1.1157064139842987e-01
    z[1,2,4]  R760      1.7434763908386230e-01
    z[1,2,4]  R761      0.265186071395874
    z[1,2,4]  R762      8.1869371235370636e-02
    z[1,2,4]  R763      -0.0295050460845232
    z[1,2,4]  R764      4.1165456175804138e-02
    z[1,2,4]  R765      1.4436149597167969e-01
    z[1,2,4]  R766      -7.9460576176643372e-02
    z[1,2,4]  R767      7.5569534301757812e-01
    z[1,2,4]  R768      -5.1839772611856461e-02
    z[1,2,4]  R769      1.8890835344791412e-01
    z[1,2,4]  R770      -2.3591178655624390e-01
    z[1,2,4]  R771      -3.0672883987426758e-01
    z[1,2,4]  R772      -1.2151244282722473e-01
    z[1,2,4]  R773      -4.5494616031646729e-01
    z[1,2,4]  R774      -5.7108914852142334e-01
    z[1,2,4]  R775      -1.4176666736602783e-01
    z[1,2,4]  R776      -3.3100968599319458e-01
    z[1,2,4]  R777      1.0167949646711349e-01
    z[1,2,4]  R778      -3.1500551104545593e-01
    z[1,2,4]  R779      -2.4191634356975555e-01
    z[1,2,4]  R780      -2.6066654920578003e-01
    z[1,2,4]  R781      4.7065809369087219e-02
    z[1,2,4]  R782      -2.2838643193244934e-01
    z[1,2,4]  R783      -1.7407071590423584e-01
    z[1,2,4]  R784      1.1996034532785416e-01
    z[1,2,4]  R785      3.4921982884407043e-01
    z[1,2,4]  R786      1.6590552031993866e-01
    z[1,2,4]  R787      3.6356106400489807e-01
    z[1,2,4]  R788      0.567359983921051
    z[1,2,4]  R789      -4.1081428527832031e-01
    z[1,2,4]  R790      -2.4256144464015961e-01
    z[1,2,4]  R791      -6.1225313693284988e-02
    z[1,2,4]  R792      -2.1430957317352295e-01
    z[1,2,4]  R793      -3.9447724819183350e-01
    z[1,2,4]  R794      -1.9413267076015472e-01
    z[1,2,4]  R795      5.8033210039138794e-01
    z[1,2,4]  R796      -3.3854478597640991e-01
    z[1,2,4]  R797      -2.6605397462844849e-01
    z[1,2,4]  R798      -1.3745093345642090e-01
    z[1,2,4]  R799      6.3053965568542480e-02
    z[1,2,4]  R800      2.9617384076118469e-01
    z[1,2,4]  R801      1.8876156210899353e-01
    z[1,2,4]  R802      5.0439256429672241e-01
    z[1,2,4]  R803      7.7387249469757080e-01
    z[1,2,4]  R804      5.1933001726865768e-02
    z[1,2,4]  R805      7.1761339902877808e-02
    z[1,2,4]  R806      9.4068972393870354e-03
    z[1,2,4]  R807      1.5361286699771881e-01
    z[1,2,4]  R808      4.7112341970205307e-02
    z[1,2,4]  R809      4.5098189264535904e-02
    z[1,2,4]  R810      -3.5120092798024416e-03
    z[1,2,4]  R811      -2.4536836892366409e-02
    z[1,2,4]  R812      -4.0133681148290634e-02
    z[1,2,4]  R813      -3.6904710531234741e-01
    z[1,2,4]  R814      -5.7447558641433716e-01
    z[1,2,4]  R815      -4.7752285003662109e-01
    z[1,2,4]  R816      0.193202406167984
    z[1,2,4]  R817      -4.0770679712295532e-01
    z[1,2,4]  R818      2.0824690163135529e-01
    z[1,2,4]  R819      -2.6912295818328857e-01
    z[1,2,4]  R820      0.0373593270778656
    z[1,2,4]  R821      -3.7109193205833435e-01
    z[1,2,4]  R822      -8.2805931568145752e-02
    z[1,2,4]  R823      -2.0254465937614441e-01
    z[1,2,4]  R824      -4.0486253798007965e-02
    z[1,2,4]  R825      -1.0614348202943802e-01
    z[1,2,4]  R826      -3.2525051385164261e-02
    z[1,2,4]  R827      -2.2475828230381012e-01
    z[1,2,4]  R828      -5.6633982807397842e-02
    z[1,2,4]  R829      1.6786442697048187e-01
    z[1,2,4]  R830      2.0928440988063812e-01
    z[1,2,4]  R831      -2.6660870760679245e-02
    z[1,2,4]  R832      -3.6228525638580322e-01
    z[1,2,4]  R833      1.8636827170848846e-01
    z[1,2,4]  R834      3.5006308555603027e-01
    z[1,2,4]  R835      -3.1885942816734314e-01
    z[1,2,4]  R836      -3.5632592439651489e-01
    z[1,2,4]  R837      -4.6853971481323242e-01
    z[1,2,4]  R838      -2.6781409978866577e-01
    z[1,2,4]  R839      -4.4630682468414307e-01
    z[1,2,4]  R840      -4.3747693300247192e-01
    z[1,2,4]  R841      -3.1682330369949341e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R749      -1
    z[1,2,5]  R750      1
    z[1,2,5]  R753      1.8587511777877808e-01
    z[1,2,5]  R754      -1.4139805734157562e-01
    z[1,2,5]  R755      4.5469993352890015e-01
    z[1,2,5]  R756      8.6127929389476776e-02
    z[1,2,5]  R757      0.0432896763086319
    z[1,2,5]  R758      7.2182303667068481e-01
    z[1,2,5]  R759      5.4944694042205811e-01
    z[1,2,5]  R760      5.7868117094039917e-01
    z[1,2,5]  R761      -0.176085963845253
    z[1,2,5]  R762      -1.6225415468215942e-01
    z[1,2,5]  R763      -2.5128121487796307e-03
    z[1,2,5]  R764      6.8202703259885311e-03
    z[1,2,5]  R765      2.7587673068046570e-01
    z[1,2,5]  R766      -1.8212584778666496e-02
    z[1,2,5]  R767      3.5121780633926392e-01
    z[1,2,5]  R768      -4.2768475413322449e-01
    z[1,2,5]  R769      1.0120529681444168e-01
    z[1,2,5]  R770      -7.2193038463592529e-01
    z[1,2,5]  R771      -8.1432253122329712e-02
    z[1,2,5]  R772      -1.8198329210281372e-01
    z[1,2,5]  R773      -6.8062287569046021e-01
    z[1,2,5]  R774      -4.0630817413330078e-01
    z[1,2,5]  R775      -4.6032306551933289e-01
    z[1,2,5]  R776      -1.7219726741313934e-01
    z[1,2,5]  R777      -0.430600643157959
    z[1,2,5]  R778      -5.0054562091827393e-01
    z[1,2,5]  R779      5.8270907029509544e-03
    z[1,2,5]  R780      2.9229742288589478e-01
    z[1,2,5]  R781      6.6445773839950562e-01
    z[1,2,5]  R782      2.1083930134773254e-01
    z[1,2,5]  R783      2.4733105301856995e-01
    z[1,2,5]  R784      4.7527906298637390e-01
    z[1,2,5]  R785      5.6023615598678589e-01
    z[1,2,5]  R786      -2.4616421759128571e-01
    z[1,2,5]  R787      3.7608388066291809e-01
    z[1,2,5]  R788      1.9763027131557465e-01
    z[1,2,5]  R789      -3.1555801630020142e-01
    z[1,2,5]  R790      1.6353559494018555e-01
    z[1,2,5]  R791      -1.9240470230579376e-01
    z[1,2,5]  R792      0.129002645611763
    z[1,2,5]  R793      5.4752331972122192e-01
    z[1,2,5]  R794      7.5934166088700294e-03
    z[1,2,5]  R795      3.3185136318206787e-01
    z[1,2,5]  R796      1.9408319890499115e-01
    z[1,2,5]  R797      -1.7621102929115295e-01
    z[1,2,5]  R798      -7.7011808753013611e-02
    z[1,2,5]  R799      -1.5127140283584595e-01
    z[1,2,5]  R800      -4.7354641556739807e-01
    z[1,2,5]  R801      1.2884079478681087e-02
    z[1,2,5]  R802      6.4517277479171753e-01
    z[1,2,5]  R803      4.3082606792449951e-01
    z[1,2,5]  R804      8.0412948131561279e-01
    z[1,2,5]  R805      3.4908747673034668e-01
    z[1,2,5]  R806      -1.3144983351230621e-01
    z[1,2,5]  R807      2.1137522533535957e-02
    z[1,2,5]  R808      2.9554679989814758e-01
    z[1,2,5]  R809      2.6696437597274780e-01
    z[1,2,5]  R810      -5.8818902820348740e-02
    z[1,2,5]  R811      1.0087272524833679e-01
    z[1,2,5]  R812      -4.9122326076030731e-02
    z[1,2,5]  R813      -6.3139609992504120e-02
    z[1,2,5]  R814      -0.00911277811974287
    z[1,2,5]  R815      -3.5208237171173096e-01
    z[1,2,5]  R816      -0.540863037109375
    z[1,2,5]  R817      3.5498145222663879e-01
    z[1,2,5]  R818      1.2205304205417633e-01
    z[1,2,5]  R819      -5.9540885686874390e-01
    z[1,2,5]  R820      1.9575688242912292e-01
    z[1,2,5]  R821      5.3384047001600266e-02
    z[1,2,5]  R822      -2.5146719813346863e-01
    z[1,2,5]  R823      4.4127443432807922e-01
    z[1,2,5]  R824      5.0499880313873291e-01
    z[1,2,5]  R825      -1.5250724554061890e-01
    z[1,2,5]  R826      -1.4797471463680267e-01
    z[1,2,5]  R827      -3.1573437154293060e-02
    z[1,2,5]  R828      2.4974641203880310e-01
    z[1,2,5]  R829      -1.2833094596862793e-01
    z[1,2,5]  R830      1.9335845112800598e-01
    z[1,2,5]  R831      -1.1957912892103195e-01
    z[1,2,5]  R832      1.0361205041408539e-01
    z[1,2,5]  R833      9.6019506454467773e-03
    z[1,2,5]  R834      3.0154320597648621e-01
    z[1,2,5]  R835      7.7177612110972404e-03
    z[1,2,5]  R836      1.1364541202783585e-01
    z[1,2,5]  R837      2.3114676773548126e-01
    z[1,2,5]  R838      2.4534982442855835e-01
    z[1,2,5]  R839      2.8570652008056641e-01
    z[1,2,5]  R840      -0.0637502521276474
    z[1,2,5]  R841      9.4810724258422852e-02
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R751      -1
    z[1,2,6]  R752      1
    z[1,2,6]  R753      2.8560683131217957e-01
    z[1,2,6]  R754      3.9391836524009705e-01
    z[1,2,6]  R755      7.0469003915786743e-01
    z[1,2,6]  R756      7.5557726621627808e-01
    z[1,2,6]  R757      -3.5521391034126282e-01
    z[1,2,6]  R758      -3.6219093948602676e-02
    z[1,2,6]  R759      -3.3626472949981689e-01
    z[1,2,6]  R760      -1.1651092767715454e-01
    z[1,2,6]  R761      1.8766130506992340e-01
    z[1,2,6]  R762      2.1053564548492432e-01
    z[1,2,6]  R763      -1.6096076369285583e-01
    z[1,2,6]  R764      2.3172810673713684e-01
    z[1,2,6]  R765      4.1252526640892029e-01
    z[1,2,6]  R766      -1.9073310494422913e-01
    z[1,2,6]  R767      -1.2972231209278107e-01
    z[1,2,6]  R768      -5.2020758390426636e-01
    z[1,2,6]  R769      -7.9890716075897217e-01
    z[1,2,6]  R770      -4.0473058819770813e-01
    z[1,2,6]  R771      -3.6321204900741577e-01
    z[1,2,6]  R772      -5.4574948549270630e-01
    z[1,2,6]  R773      6.5559722483158112e-02
    z[1,2,6]  R774      3.6005118489265442e-01
    z[1,2,6]  R775      -4.5117178559303284e-01
    z[1,2,6]  R776      -5.4073441028594971e-01
    z[1,2,6]  R777      1.2992599513381720e-03
    z[1,2,6]  R778      2.1642138063907623e-01
    z[1,2,6]  R779      3.4340581297874451e-01
    z[1,2,6]  R780      -3.2740628719329834e-01
    z[1,2,6]  R781      -6.2006378173828125e-01
    z[1,2,6]  R782      2.7123183012008667e-01
    z[1,2,6]  R783      -4.2300187051296234e-02
    z[1,2,6]  R784      1.2370651215314865e-01
    z[1,2,6]  R785      -4.7015976905822754e-01
    z[1,2,6]  R786      3.4981733560562134e-01
    z[1,2,6]  R787      -7.3354914784431458e-02
    z[1,2,6]  R788      -2.4641756713390350e-01
    z[1,2,6]  R789      -2.3655369877815247e-02
    z[1,2,6]  R790      4.4243231415748596e-02
    z[1,2,6]  R791      -2.6326501369476318e-01
    z[1,2,6]  R792      -6.7819356918334961e-02
    z[1,2,6]  R793      -5.0240176916122437e-01
    z[1,2,6]  R794      -2.6337611675262451e-01
    z[1,2,6]  R795      -3.5471022129058838e-02
    z[1,2,6]  R796      1.9848808646202087e-01
    z[1,2,6]  R797      -6.9091357290744781e-02
    z[1,2,6]  R798      3.4583261609077454e-01
    z[1,2,6]  R799      1.0074346512556076e-01
    z[1,2,6]  R800      2.9694160819053650e-01
    z[1,2,6]  R801      2.5770869851112366e-01
    z[1,2,6]  R802      2.9407748952507973e-02
    z[1,2,6]  R803      -1.0284823179244995e-01
    z[1,2,6]  R804      -1.7685037106275558e-02
    z[1,2,6]  R805      7.0338404178619385e-01
    z[1,2,6]  R806      3.5287228226661682e-01
    z[1,2,6]  R807      2.1951857209205627e-01
    z[1,2,6]  R808      1.4428961277008057e-01
    z[1,2,6]  R809      -2.0811758935451508e-01
    z[1,2,6]  R810      -1.6104213893413544e-01
    z[1,2,6]  R811      -3.0834999680519104e-01
    z[1,2,6]  R812      -5.6209444999694824e-01
    z[1,2,6]  R813      -3.5043638944625854e-01
    z[1,2,6]  R814      1.9959436357021332e-01
    z[1,2,6]  R815      7.5668044388294220e-02
    z[1,2,6]  R816      -1.9348785281181335e-01
    z[1,2,6]  R817      -1.3416618108749390e-02
    z[1,2,6]  R818      1.4407142996788025e-01
    z[1,2,6]  R819      -0.443516343832016
    z[1,2,6]  R820      -2.7404433488845825e-01
    z[1,2,6]  R821      -2.0178568363189697e-01
    z[1,2,6]  R822      -9.5452917739748955e-03
    z[1,2,6]  R823      -1.8258096277713776e-01
    z[1,2,6]  R824      5.1814638078212738e-02
    z[1,2,6]  R825      -1.8083012104034424e-01
    z[1,2,6]  R826      2.2764241695404053e-01
    z[1,2,6]  R827      1.0954919457435608e-01
    z[1,2,6]  R828      3.7324190139770508e-02
    z[1,2,6]  R829      6.9620959460735321e-02
    z[1,2,6]  R830      -1.7409196496009827e-01
    z[1,2,6]  R831      -2.9442825913429260e-01
    z[1,2,6]  R832      -2.6521581411361694e-01
    z[1,2,6]  R833      -2.2699010372161865e-01
    z[1,2,6]  R834      2.6001834869384766e-01
    z[1,2,6]  R835      5.5389977991580963e-02
    z[1,2,6]  R836      -2.8567776083946228e-01
    z[1,2,6]  R837      6.4749278128147125e-02
    z[1,2,6]  R838      1.5751951932907104e-01
    z[1,2,6]  R839      1.5132038295269012e-01
    z[1,2,6]  R840      2.5233200192451477e-01
    z[1,2,6]  R841      -0.035448107868433
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R842      -1
    z[2,1,0]  R843      1
    z[2,1,0]  R856      3.1432923674583435e-01
    z[2,1,0]  R857      1.1821191757917404e-01
    z[2,1,0]  R858      -4.2595438659191132e-02
    z[2,1,0]  R859      -2.8032967820763588e-02
    z[2,1,0]  R860      2.3776893317699432e-01
    z[2,1,0]  R861      7.2030341625213623e-01
    z[2,1,0]  R862      3.6836597323417664e-01
    z[2,1,0]  R863      6.8994998931884766e-01
    z[2,1,0]  R864      5.5068814754486084e-01
    z[2,1,0]  R865      3.8371109962463379e-01
    z[2,1,0]  R866      -5.1737666130065918e-01
    z[2,1,0]  R867      5.7984985411167145e-02
    z[2,1,0]  R868      -3.4597349166870117e-01
    z[2,1,0]  R869      -6.9435632228851318e-01
    z[2,1,0]  R870      -5.8090382814407349e-01
    z[2,1,0]  R871      -7.2835075855255127e-01
    z[2,1,0]  R872      -6.3251376152038574e-01
    z[2,1,0]  R873      -0.282098650932312
    z[2,1,0]  R874      -8.0061239004135132e-01
    z[2,1,0]  R875      2.9811334609985352e-01
    z[2,1,0]  R876      -0.727404773235321
    z[2,1,0]  R877      -6.9134902954101562e-01
    z[2,1,0]  R878      -3.8005176186561584e-01
    z[2,1,0]  R879      2.9792213439941406e-01
    z[2,1,0]  R880      2.5141090154647827e-01
    z[2,1,0]  R881      4.8459729552268982e-01
    z[2,1,0]  R882      2.2911366820335388e-01
    z[2,1,0]  R883      2.8318625688552856e-01
    z[2,1,0]  R884      1.4619770646095276e-01
    z[2,1,0]  R885      5.0927591323852539e-01
    z[2,1,0]  R886      -3.6842474341392517e-01
    z[2,1,0]  R887      3.8788583874702454e-01
    z[2,1,0]  R888      0.511343777179718
    z[2,1,0]  R889      4.3528911471366882e-01
    z[2,1,0]  R890      2.7572733163833618e-01
    z[2,1,0]  R891      0.501968264579773
    z[2,1,0]  R892      2.5607383251190186e-01
    z[2,1,0]  R893      4.8280277848243713e-01
    z[2,1,0]  R894      1.5415605902671814e-01
    z[2,1,0]  R895      1.2871250510215759e-01
    z[2,1,0]  R896      -2.3927323520183563e-01
    z[2,1,0]  R897      -9.3068093061447144e-02
    z[2,1,0]  R898      -1.8396428227424622e-01
    z[2,1,0]  R899      1.1003871262073517e-01
    z[2,1,0]  R900      -4.2539175599813461e-02
    z[2,1,0]  R901      -3.0694505572319031e-01
    z[2,1,0]  R902      2.3849646747112274e-01
    z[2,1,0]  R903      -2.5389662384986877e-01
    z[2,1,0]  R904      -3.2029229402542114e-01
    z[2,1,0]  R905      -1.6619090735912323e-01
    z[2,1,0]  R906      6.6466385126113892e-01
    z[2,1,0]  R907      -4.7198975086212158e-01
    z[2,1,0]  R908      -7.8905403614044189e-01
    z[2,1,0]  R909      -0.89189612865448
    z[2,1,0]  R910      -3.1033545732498169e-01
    z[2,1,0]  R911      -5.1954627037048340e-01
    z[2,1,0]  R912      -3.0689609050750732e-01
    z[2,1,0]  R913      3.9101323485374451e-01
    z[2,1,0]  R914      -2.4056018888950348e-01
    z[2,1,0]  R915      -2.3183842003345490e-01
    z[2,1,0]  R916      3.5448500514030457e-01
    z[2,1,0]  R917      1.2213188409805298e-01
    z[2,1,0]  R918      4.4516941905021667e-01
    z[2,1,0]  R919      7.5336650013923645e-02
    z[2,1,0]  R920      2.0835784077644348e-01
    z[2,1,0]  R921      3.7897145748138428e-01
    z[2,1,0]  R922      -2.0715612173080444e-01
    z[2,1,0]  R923      6.3558273017406464e-02
    z[2,1,0]  R924      1.4043904957361519e-04
    z[2,1,0]  R925      -5.2889108657836914e-01
    z[2,1,0]  R926      0.124534472823143
    z[2,1,0]  R927      3.2512968778610229e-01
    z[2,1,0]  R928      1.2217810004949570e-01
    z[2,1,0]  R929      -0.0638943687081337
    z[2,1,0]  R930      3.9143315516412258e-03
    z[2,1,0]  R931      -5.3495984524488449e-02
    z[2,1,0]  R932      -6.1061024665832520e-01
    z[2,1,0]  R933      -3.2372646033763885e-02
    z[2,1,0]  R934      -1.4620240032672882e-01
    z[2,1,0]  R935      -5.6994175910949707e-01
    z[2,1,0]  R936      5.4328281432390213e-02
    z[2,1,0]  R937      -7.7049273252487183e-01
    z[2,1,0]  R938      -3.6872324347496033e-01
    z[2,1,0]  R939      -3.8276901841163635e-01
    z[2,1,0]  R940      -0.460308313369751
    z[2,1,0]  R941      -3.8408553600311279e-01
    z[2,1,0]  R942      5.7115048170089722e-01
    z[2,1,0]  R943      -2.7225458621978760e-01
    z[2,1,0]  R944      5.5754220485687256e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R844      -1
    z[2,1,1]  R845      1
    z[2,1,1]  R856      4.3151691555976868e-01
    z[2,1,1]  R857      4.2549699544906616e-01
    z[2,1,1]  R858      5.2562618255615234e-01
    z[2,1,1]  R859      5.6732589006423950e-01
    z[2,1,1]  R860      8.2880979776382446e-01
    z[2,1,1]  R861      -6.1817508935928345e-01
    z[2,1,1]  R862      -2.8042098879814148e-01
    z[2,1,1]  R863      -3.8915368914604187e-01
    z[2,1,1]  R864      -0.612704873085022
    z[2,1,1]  R865      -3.9651420712471008e-01
    z[2,1,1]  R866      4.7555673122406006e-01
    z[2,1,1]  R867      0.518293559551239
    z[2,1,1]  R868      2.9023453593254089e-01
    z[2,1,1]  R869      3.4667372703552246e-01
    z[2,1,1]  R870      3.2177156209945679e-01
    z[2,1,1]  R871      -1.8335235118865967e-01
    z[2,1,1]  R872      -7.5615622103214264e-02
    z[2,1,1]  R873      2.2285100817680359e-01
    z[2,1,1]  R874      -1.9160155951976776e-01
    z[2,1,1]  R875      -7.9132926464080811e-01
    z[2,1,1]  R876      5.5986744165420532e-01
    z[2,1,1]  R877      2.4091683328151703e-01
    z[2,1,1]  R878      -2.6302519440650940e-01
    z[2,1,1]  R879      -8.7849563360214233e-01
    z[2,1,1]  R880      -9.0676325559616089e-01
    z[2,1,1]  R881      -0.81097811460495
    z[2,1,1]  R882      -9.1801899671554565e-01
    z[2,1,1]  R883      -8.8772386312484741e-01
    z[2,1,1]  R884      -9.1601639986038208e-01
    z[2,1,1]  R885      -7.4158489704132080e-01
    z[2,1,1]  R886      4.2555916309356689e-01
    z[2,1,1]  R887      -0.866968035697937
    z[2,1,1]  R888      -6.5728002786636353e-01
    z[2,1,1]  R889      -4.3178817629814148e-01
    z[2,1,1]  R890      -4.6381074190139771e-01
    z[2,1,1]  R891      -2.9665133357048035e-01
    z[2,1,1]  R892      -4.6428361535072327e-01
    z[2,1,1]  R893      -4.8970067501068115e-01
    z[2,1,1]  R894      -5.3583443164825439e-01
    z[2,1,1]  R895      -5.1682722568511963e-01
    z[2,1,1]  R896      -2.3412662744522095e-01
    z[2,1,1]  R897      -3.2256475090980530e-01
    z[2,1,1]  R898      -3.6999046802520752e-01
    z[2,1,1]  R899      -5.2285623550415039e-01
    z[2,1,1]  R900      -4.6815851330757141e-01
    z[2,1,1]  R901      -4.2803874611854553e-01
    z[2,1,1]  R902      -7.1605294942855835e-01
    z[2,1,1]  R903      6.4604789018630981e-01
    z[2,1,1]  R904      8.5382020473480225e-01
    z[2,1,1]  R905      8.7410008907318115e-01
    z[2,1,1]  R906      -2.1206778287887573e-01
    z[2,1,1]  R907      5.5650299787521362e-01
    z[2,1,1]  R908      2.7068966627120972e-01
    z[2,1,1]  R909      2.0389008522033691e-01
    z[2,1,1]  R910      2.8315299749374390e-01
    z[2,1,1]  R911      3.0223432183265686e-01
    z[2,1,1]  R912      -1.4377743005752563e-01
    z[2,1,1]  R913      -2.0649042725563049e-01
    z[2,1,1]  R914      8.2114261388778687e-01
    z[2,1,1]  R915      7.1400213241577148e-01
    z[2,1,1]  R916      -3.3164060115814209e-01
    z[2,1,1]  R917      -1.8140999972820282e-01
    z[2,1,1]  R918      -5.1794147491455078e-01
    z[2,1,1]  R919      -5.0821495056152344e-01
    z[2,1,1]  R920      -6.5732920169830322e-01
    z[2,1,1]  R921      -5.3367048501968384e-01
    z[2,1,1]  R922      -5.9342402219772339e-01
    z[2,1,1]  R923      2.9371902346611023e-01
    z[2,1,1]  R924      3.0722531676292419e-01
    z[2,1,1]  R925      7.0174783468246460e-01
    z[2,1,1]  R926      -5.3573852777481079e-01
    z[2,1,1]  R927      -7.3988282680511475e-01
    z[2,1,1]  R928      -1.4559482038021088e-01
    z[2,1,1]  R929      -6.6544854640960693e-01
    z[2,1,1]  R930      2.6029470562934875e-01
    z[2,1,1]  R931      0.684913694858551
    z[2,1,1]  R932      5.3332304954528809e-01
    z[2,1,1]  R933      7.8472161293029785e-01
    z[2,1,1]  R934      8.9037430286407471e-01
    z[2,1,1]  R935      0.710384726524353
    z[2,1,1]  R936      -4.5226737856864929e-01
    z[2,1,1]  R937      2.4580633640289307e-01
    z[2,1,1]  R938      6.3817453384399414e-01
    z[2,1,1]  R939      -5.0469082593917847e-01
    z[2,1,1]  R940      7.7087897062301636e-01
    z[2,1,1]  R941      7.6046824455261230e-01
    z[2,1,1]  R942      7.8955745697021484e-01
    z[2,1,1]  R943      2.1833692491054535e-01
    z[2,1,1]  R944      7.0232802629470825e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R846      -1
    z[2,1,2]  R847      1
    z[2,1,2]  R856      -1.4077208936214447e-01
    z[2,1,2]  R857      9.7302317619323730e-02
    z[2,1,2]  R858      -2.1837297081947327e-01
    z[2,1,2]  R859      1.1307616531848907e-01
    z[2,1,2]  R860      -1.9834028184413910e-01
    z[2,1,2]  R861      -1.0964637994766235e-01
    z[2,1,2]  R862      8.0503863096237183e-01
    z[2,1,2]  R863      4.9628299474716187e-01
    z[2,1,2]  R864      4.6857553720474243e-01
    z[2,1,2]  R865      -0.295538067817688
    z[2,1,2]  R866      -2.3308368399739265e-02
    z[2,1,2]  R867      -4.4742828607559204e-01
    z[2,1,2]  R868      -5.0015095621347427e-02
    z[2,1,2]  R869      1.6715654730796814e-01
    z[2,1,2]  R870      3.5724112391471863e-01
    z[2,1,2]  R871      2.2476868331432343e-01
    z[2,1,2]  R872      5.4395663738250732e-01
    z[2,1,2]  R873      -1.1327151954174042e-01
    z[2,1,2]  R874      0.394095242023468
    z[2,1,2]  R875      -2.5027871131896973e-01
    z[2,1,2]  R876      2.8507426381111145e-01
    z[2,1,2]  R877      9.3729391694068909e-02
    z[2,1,2]  R878      2.3452764749526978e-01
    z[2,1,2]  R879      -6.1158183962106705e-02
    z[2,1,2]  R880      1.6787745058536530e-01
    z[2,1,2]  R881      -1.3995537161827087e-01
    z[2,1,2]  R882      4.8986006528139114e-02
    z[2,1,2]  R883      1.9130004942417145e-01
    z[2,1,2]  R884      1.5195025503635406e-01
    z[2,1,2]  R885      -2.1155475080013275e-01
    z[2,1,2]  R886      -2.0650514960289001e-01
    z[2,1,2]  R887      -3.3399043604731560e-03
    z[2,1,2]  R888      8.1033043563365936e-02
    z[2,1,2]  R889      6.9183951616287231e-01
    z[2,1,2]  R890      6.9558727741241455e-01
    z[2,1,2]  R891      0.603071391582489
    z[2,1,2]  R892      0.738192081451416
    z[2,1,2]  R893      4.5026838779449463e-01
    z[2,1,2]  R894      6.5014606714248657e-01
    z[2,1,2]  R895      0.777576744556427
    z[2,1,2]  R896      7.8288090229034424e-01
    z[2,1,2]  R897      6.9121789932250977e-01
    z[2,1,2]  R898      2.7046054601669312e-01
    z[2,1,2]  R899      -9.0173922479152679e-02
    z[2,1,2]  R900      0.612095057964325
    z[2,1,2]  R901      4.0137669444084167e-01
    z[2,1,2]  R902      -2.8709178790450096e-02
    z[2,1,2]  R903      -3.5165694355964661e-01
    z[2,1,2]  R904      7.7848076820373535e-02
    z[2,1,2]  R905      -2.6500681042671204e-01
    z[2,1,2]  R906      -1.8514315783977509e-01
    z[2,1,2]  R907      5.4202932119369507e-01
    z[2,1,2]  R908      -1.2013711780309677e-01
    z[2,1,2]  R909      3.0058783292770386e-01
    z[2,1,2]  R910      -3.3320057392120361e-01
    z[2,1,2]  R911      -2.3354759812355042e-01
    z[2,1,2]  R912      -2.6625505089759827e-01
    z[2,1,2]  R913      2.5235649943351746e-01
    z[2,1,2]  R914      -1.5740875899791718e-01
    z[2,1,2]  R915      2.9138955473899841e-01
    z[2,1,2]  R916      2.7108547091484070e-01
    z[2,1,2]  R917      4.9036440253257751e-01
    z[2,1,2]  R918      3.1304258108139038e-01
    z[2,1,2]  R919      3.3663868904113770e-01
    z[2,1,2]  R920      -2.5620761513710022e-01
    z[2,1,2]  R921      -3.8797748088836670e-01
    z[2,1,2]  R922      -1.6617652773857117e-01
    z[2,1,2]  R923      5.5452769994735718e-01
    z[2,1,2]  R924      5.9412352740764618e-02
    z[2,1,2]  R925      2.2869819402694702e-01
    z[2,1,2]  R926      7.1511673927307129e-01
    z[2,1,2]  R927      -2.6457920670509338e-01
    z[2,1,2]  R928      4.2584562301635742e-01
    z[2,1,2]  R929      -1.1458848416805267e-01
    z[2,1,2]  R930      -6.1519676446914673e-01
    z[2,1,2]  R931      -1.7192934453487396e-01
    z[2,1,2]  R932      -2.2272443771362305e-01
    z[2,1,2]  R933      -2.4329580366611481e-01
    z[2,1,2]  R934      -2.7469378709793091e-01
    z[2,1,2]  R935      1.3224802911281586e-02
    z[2,1,2]  R936      -1.1340240389108658e-01
    z[2,1,2]  R937      3.0671819113194942e-03
    z[2,1,2]  R938      5.8155737817287445e-02
    z[2,1,2]  R939      2.9615920782089233e-01
    z[2,1,2]  R940      -0.0243210606276989
    z[2,1,2]  R941      -3.4894734621047974e-01
    z[2,1,2]  R942      -1.1464491486549377e-01
    z[2,1,2]  R943      -6.2834733724594116e-01
    z[2,1,2]  R944      -2.8288549184799194e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R848      -1
    z[2,1,3]  R849      1
    z[2,1,3]  R856      1.5378223359584808e-01
    z[2,1,3]  R857      -2.1045181900262833e-02
    z[2,1,3]  R858      1.5678630769252777e-01
    z[2,1,3]  R859      0.206902414560318
    z[2,1,3]  R860      2.7443605661392212e-01
    z[2,1,3]  R861      -1.2152399122714996e-01
    z[2,1,3]  R862      1.6491317749023438e-01
    z[2,1,3]  R863      -9.8055362701416016e-02
    z[2,1,3]  R864      2.6900875568389893e-01
    z[2,1,3]  R865      7.0876121520996094e-01
    z[2,1,3]  R866      -4.3087130784988403e-01
    z[2,1,3]  R867      -5.1461577415466309e-01
    z[2,1,3]  R868      -6.5086215734481812e-01
    z[2,1,3]  R869      1.0967974364757538e-01
    z[2,1,3]  R870      2.5317004323005676e-01
    z[2,1,3]  R871      -3.0487614870071411e-01
    z[2,1,3]  R872      -4.6829420328140259e-01
    z[2,1,3]  R873      4.8402658104896545e-01
    z[2,1,3]  R874      2.2843122482299805e-01
    z[2,1,3]  R875      2.0251031219959259e-01
    z[2,1,3]  R876      -0.0773281380534172
    z[2,1,3]  R877      0.431424617767334
    z[2,1,3]  R878      -6.8704259395599365e-01
    z[2,1,3]  R879      2.6176929473876953e-01
    z[2,1,3]  R880      1.0777126997709274e-01
    z[2,1,3]  R881      -1.5613524615764618e-01
    z[2,1,3]  R882      -1.8808171153068542e-01
    z[2,1,3]  R883      -2.1368660032749176e-01
    z[2,1,3]  R884      -7.0396766066551208e-02
    z[2,1,3]  R885      -2.1032449603080750e-01
    z[2,1,3]  R886      6.5436446666717529e-01
    z[2,1,3]  R887      -1.0747081041336060e-01
    z[2,1,3]  R888      1.3733908534049988e-01
    z[2,1,3]  R889      -2.0159746706485748e-01
    z[2,1,3]  R890      5.9304811060428619e-02
    z[2,1,3]  R891      -1.3849201798439026e-01
    z[2,1,3]  R892      1.3117182254791260e-01
    z[2,1,3]  R893      -1.4365708827972412e-01
    z[2,1,3]  R894      -8.5474856197834015e-02
    z[2,1,3]  R895      -3.2779112458229065e-02
    z[2,1,3]  R896      -1.3675062358379364e-01
    z[2,1,3]  R897      -1.2978547811508179e-01
    z[2,1,3]  R898      -2.1833953261375427e-01
    z[2,1,3]  R899      -0.192160502076149
    z[2,1,3]  R900      2.3703585565090179e-01
    z[2,1,3]  R901      1.8773065507411957e-01
    z[2,1,3]  R902      4.6362329274415970e-02
    z[2,1,3]  R903      -1.2510886788368225e-01
    z[2,1,3]  R904      -1.6061370074748993e-01
    z[2,1,3]  R905      -2.4646823108196259e-01
    z[2,1,3]  R906      -6.7244774103164673e-01
    z[2,1,3]  R907      -3.4394088387489319e-01
    z[2,1,3]  R908      1.5020883083343506e-01
    z[2,1,3]  R909      1.7196573317050934e-01
    z[2,1,3]  R910      -3.5162393003702164e-02
    z[2,1,3]  R911      -3.5772061347961426e-01
    z[2,1,3]  R912      -0.360651433467865
    z[2,1,3]  R913      1.1904857121407986e-02
    z[2,1,3]  R914      1.0218356549739838e-01
    z[2,1,3]  R915      7.6278068125247955e-02
    z[2,1,3]  R916      -1.2785153090953827e-01
    z[2,1,3]  R917      -3.0141493678092957e-01
    z[2,1,3]  R918      3.7640803493559361e-03
    z[2,1,3]  R919      4.3715375661849976e-01
    z[2,1,3]  R920      5.1293814182281494e-01
    z[2,1,3]  R921      1.5632462501525879e-01
    z[2,1,3]  R922      6.3311499357223511e-01
    z[2,1,3]  R923      -5.8447301387786865e-01
    z[2,1,3]  R924      -2.7181667089462280e-01
    z[2,1,3]  R925      -7.3082715272903442e-02
    z[2,1,3]  R926      -3.0466508865356445e-01
    z[2,1,3]  R927      -1.4586928486824036e-01
    z[2,1,3]  R928      -3.5448685288429260e-01
    z[2,1,3]  R929      5.7399606704711914e-01
    z[2,1,3]  R930      -5.2418279647827148e-01
    z[2,1,3]  R931      -0.277119517326355
    z[2,1,3]  R932      -1.5559767186641693e-01
    z[2,1,3]  R933      -4.8624446988105774e-01
    z[2,1,3]  R934      -1.8034832552075386e-02
    z[2,1,3]  R935      3.2120910286903381e-01
    z[2,1,3]  R936      2.6803153753280640e-01
    z[2,1,3]  R937      -4.8867025971412659e-01
    z[2,1,3]  R938      -7.2287283837795258e-02
    z[2,1,3]  R939      5.6514286994934082e-01
    z[2,1,3]  R940      2.9438361525535583e-01
    z[2,1,3]  R941      8.9321218430995941e-02
    z[2,1,3]  R942      1.5312604606151581e-02
    z[2,1,3]  R943      -0.288524866104126
    z[2,1,3]  R944      0.1168212890625
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R850      -1
    z[2,1,4]  R851      1
    z[2,1,4]  R856      5.0439256429672241e-01
    z[2,1,4]  R857      7.7387249469757080e-01
    z[2,1,4]  R858      5.1933001726865768e-02
    z[2,1,4]  R859      7.1761339902877808e-02
    z[2,1,4]  R860      9.4068972393870354e-03
    z[2,1,4]  R861      1.5361286699771881e-01
    z[2,1,4]  R862      4.7112341970205307e-02
    z[2,1,4]  R863      4.5098189264535904e-02
    z[2,1,4]  R864      -3.5120092798024416e-03
    z[2,1,4]  R865      -2.4536836892366409e-02
    z[2,1,4]  R866      -4.0133681148290634e-02
    z[2,1,4]  R867      -3.6904710531234741e-01
    z[2,1,4]  R868      -5.7447558641433716e-01
    z[2,1,4]  R869      -4.7752285003662109e-01
    z[2,1,4]  R870      0.193202406167984
    z[2,1,4]  R871      -4.0770679712295532e-01
    z[2,1,4]  R872      2.0824690163135529e-01
    z[2,1,4]  R873      -2.6912295818328857e-01
    z[2,1,4]  R874      0.0373593270778656
    z[2,1,4]  R875      -3.7109193205833435e-01
    z[2,1,4]  R876      -8.2805931568145752e-02
    z[2,1,4]  R877      -2.0254465937614441e-01
    z[2,1,4]  R878      -4.0486253798007965e-02
    z[2,1,4]  R879      -1.0614348202943802e-01
    z[2,1,4]  R880      -3.2525051385164261e-02
    z[2,1,4]  R881      -2.2475828230381012e-01
    z[2,1,4]  R882      -5.6633982807397842e-02
    z[2,1,4]  R883      1.6786442697048187e-01
    z[2,1,4]  R884      2.0928440988063812e-01
    z[2,1,4]  R885      -2.6660870760679245e-02
    z[2,1,4]  R886      -3.6228525638580322e-01
    z[2,1,4]  R887      1.8636827170848846e-01
    z[2,1,4]  R888      3.5006308555603027e-01
    z[2,1,4]  R889      -3.1885942816734314e-01
    z[2,1,4]  R890      -3.5632592439651489e-01
    z[2,1,4]  R891      -4.6853971481323242e-01
    z[2,1,4]  R892      -2.6781409978866577e-01
    z[2,1,4]  R893      -4.4630682468414307e-01
    z[2,1,4]  R894      -4.3747693300247192e-01
    z[2,1,4]  R895      -3.1682330369949341e-01
    z[2,1,4]  R896      3.7444502115249634e-01
    z[2,1,4]  R897      4.6636760234832764e-01
    z[2,1,4]  R898      7.1435712277889252e-02
    z[2,1,4]  R899      3.0189543962478638e-01
    z[2,1,4]  R900      4.6917036175727844e-01
    z[2,1,4]  R901      -6.2298811972141266e-02
    z[2,1,4]  R902      1.1157064139842987e-01
    z[2,1,4]  R903      1.7434763908386230e-01
    z[2,1,4]  R904      0.265186071395874
    z[2,1,4]  R905      8.1869371235370636e-02
    z[2,1,4]  R906      -0.0295050460845232
    z[2,1,4]  R907      4.1165456175804138e-02
    z[2,1,4]  R908      1.4436149597167969e-01
    z[2,1,4]  R909      -7.9460576176643372e-02
    z[2,1,4]  R910      7.5569534301757812e-01
    z[2,1,4]  R911      -5.1839772611856461e-02
    z[2,1,4]  R912      1.8890835344791412e-01
    z[2,1,4]  R913      -2.3591178655624390e-01
    z[2,1,4]  R914      -3.0672883987426758e-01
    z[2,1,4]  R915      -1.2151244282722473e-01
    z[2,1,4]  R916      -4.5494616031646729e-01
    z[2,1,4]  R917      -5.7108914852142334e-01
    z[2,1,4]  R918      -1.4176666736602783e-01
    z[2,1,4]  R919      -3.3100968599319458e-01
    z[2,1,4]  R920      1.0167949646711349e-01
    z[2,1,4]  R921      -3.1500551104545593e-01
    z[2,1,4]  R922      -2.4191634356975555e-01
    z[2,1,4]  R923      -2.6066654920578003e-01
    z[2,1,4]  R924      4.7065809369087219e-02
    z[2,1,4]  R925      -2.2838643193244934e-01
    z[2,1,4]  R926      -1.7407071590423584e-01
    z[2,1,4]  R927      1.1996034532785416e-01
    z[2,1,4]  R928      3.4921982884407043e-01
    z[2,1,4]  R929      1.6590552031993866e-01
    z[2,1,4]  R930      3.6356106400489807e-01
    z[2,1,4]  R931      0.567359983921051
    z[2,1,4]  R932      -4.1081428527832031e-01
    z[2,1,4]  R933      -2.4256144464015961e-01
    z[2,1,4]  R934      -6.1225313693284988e-02
    z[2,1,4]  R935      -2.1430957317352295e-01
    z[2,1,4]  R936      -3.9447724819183350e-01
    z[2,1,4]  R937      -1.9413267076015472e-01
    z[2,1,4]  R938      5.8033210039138794e-01
    z[2,1,4]  R939      -3.3854478597640991e-01
    z[2,1,4]  R940      -2.6605397462844849e-01
    z[2,1,4]  R941      -1.3745093345642090e-01
    z[2,1,4]  R942      6.3053965568542480e-02
    z[2,1,4]  R943      2.9617384076118469e-01
    z[2,1,4]  R944      1.8876156210899353e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R852      -1
    z[2,1,5]  R853      1
    z[2,1,5]  R856      6.4517277479171753e-01
    z[2,1,5]  R857      4.3082606792449951e-01
    z[2,1,5]  R858      8.0412948131561279e-01
    z[2,1,5]  R859      3.4908747673034668e-01
    z[2,1,5]  R860      -1.3144983351230621e-01
    z[2,1,5]  R861      2.1137522533535957e-02
    z[2,1,5]  R862      2.9554679989814758e-01
    z[2,1,5]  R863      2.6696437597274780e-01
    z[2,1,5]  R864      -5.8818902820348740e-02
    z[2,1,5]  R865      1.0087272524833679e-01
    z[2,1,5]  R866      -4.9122326076030731e-02
    z[2,1,5]  R867      -6.3139609992504120e-02
    z[2,1,5]  R868      -0.00911277811974287
    z[2,1,5]  R869      -3.5208237171173096e-01
    z[2,1,5]  R870      -0.540863037109375
    z[2,1,5]  R871      3.5498145222663879e-01
    z[2,1,5]  R872      1.2205304205417633e-01
    z[2,1,5]  R873      -5.9540885686874390e-01
    z[2,1,5]  R874      1.9575688242912292e-01
    z[2,1,5]  R875      5.3384047001600266e-02
    z[2,1,5]  R876      -2.5146719813346863e-01
    z[2,1,5]  R877      4.4127443432807922e-01
    z[2,1,5]  R878      5.0499880313873291e-01
    z[2,1,5]  R879      -1.5250724554061890e-01
    z[2,1,5]  R880      -1.4797471463680267e-01
    z[2,1,5]  R881      -3.1573437154293060e-02
    z[2,1,5]  R882      2.4974641203880310e-01
    z[2,1,5]  R883      -1.2833094596862793e-01
    z[2,1,5]  R884      1.9335845112800598e-01
    z[2,1,5]  R885      -1.1957912892103195e-01
    z[2,1,5]  R886      1.0361205041408539e-01
    z[2,1,5]  R887      9.6019506454467773e-03
    z[2,1,5]  R888      3.0154320597648621e-01
    z[2,1,5]  R889      7.7177612110972404e-03
    z[2,1,5]  R890      1.1364541202783585e-01
    z[2,1,5]  R891      2.3114676773548126e-01
    z[2,1,5]  R892      2.4534982442855835e-01
    z[2,1,5]  R893      2.8570652008056641e-01
    z[2,1,5]  R894      -0.0637502521276474
    z[2,1,5]  R895      9.4810724258422852e-02
    z[2,1,5]  R896      1.8587511777877808e-01
    z[2,1,5]  R897      -1.4139805734157562e-01
    z[2,1,5]  R898      4.5469993352890015e-01
    z[2,1,5]  R899      8.6127929389476776e-02
    z[2,1,5]  R900      0.0432896763086319
    z[2,1,5]  R901      7.2182303667068481e-01
    z[2,1,5]  R902      5.4944694042205811e-01
    z[2,1,5]  R903      5.7868117094039917e-01
    z[2,1,5]  R904      -0.176085963845253
    z[2,1,5]  R905      -1.6225415468215942e-01
    z[2,1,5]  R906      -2.5128121487796307e-03
    z[2,1,5]  R907      6.8202703259885311e-03
    z[2,1,5]  R908      2.7587673068046570e-01
    z[2,1,5]  R909      -1.8212584778666496e-02
    z[2,1,5]  R910      3.5121780633926392e-01
    z[2,1,5]  R911      -4.2768475413322449e-01
    z[2,1,5]  R912      1.0120529681444168e-01
    z[2,1,5]  R913      -7.2193038463592529e-01
    z[2,1,5]  R914      -8.1432253122329712e-02
    z[2,1,5]  R915      -1.8198329210281372e-01
    z[2,1,5]  R916      -6.8062287569046021e-01
    z[2,1,5]  R917      -4.0630817413330078e-01
    z[2,1,5]  R918      -4.6032306551933289e-01
    z[2,1,5]  R919      -1.7219726741313934e-01
    z[2,1,5]  R920      -0.430600643157959
    z[2,1,5]  R921      -5.0054562091827393e-01
    z[2,1,5]  R922      5.8270907029509544e-03
    z[2,1,5]  R923      2.9229742288589478e-01
    z[2,1,5]  R924      6.6445773839950562e-01
    z[2,1,5]  R925      2.1083930134773254e-01
    z[2,1,5]  R926      2.4733105301856995e-01
    z[2,1,5]  R927      4.7527906298637390e-01
    z[2,1,5]  R928      5.6023615598678589e-01
    z[2,1,5]  R929      -2.4616421759128571e-01
    z[2,1,5]  R930      3.7608388066291809e-01
    z[2,1,5]  R931      1.9763027131557465e-01
    z[2,1,5]  R932      -3.1555801630020142e-01
    z[2,1,5]  R933      1.6353559494018555e-01
    z[2,1,5]  R934      -1.9240470230579376e-01
    z[2,1,5]  R935      0.129002645611763
    z[2,1,5]  R936      5.4752331972122192e-01
    z[2,1,5]  R937      7.5934166088700294e-03
    z[2,1,5]  R938      3.3185136318206787e-01
    z[2,1,5]  R939      1.9408319890499115e-01
    z[2,1,5]  R940      -1.7621102929115295e-01
    z[2,1,5]  R941      -7.7011808753013611e-02
    z[2,1,5]  R942      -1.5127140283584595e-01
    z[2,1,5]  R943      -4.7354641556739807e-01
    z[2,1,5]  R944      1.2884079478681087e-02
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R854      -1
    z[2,1,6]  R855      1
    z[2,1,6]  R856      2.9407748952507973e-02
    z[2,1,6]  R857      -1.0284823179244995e-01
    z[2,1,6]  R858      -1.7685037106275558e-02
    z[2,1,6]  R859      7.0338404178619385e-01
    z[2,1,6]  R860      3.5287228226661682e-01
    z[2,1,6]  R861      2.1951857209205627e-01
    z[2,1,6]  R862      1.4428961277008057e-01
    z[2,1,6]  R863      -2.0811758935451508e-01
    z[2,1,6]  R864      -1.6104213893413544e-01
    z[2,1,6]  R865      -3.0834999680519104e-01
    z[2,1,6]  R866      -5.6209444999694824e-01
    z[2,1,6]  R867      -3.5043638944625854e-01
    z[2,1,6]  R868      1.9959436357021332e-01
    z[2,1,6]  R869      7.5668044388294220e-02
    z[2,1,6]  R870      -1.9348785281181335e-01
    z[2,1,6]  R871      -1.3416618108749390e-02
    z[2,1,6]  R872      1.4407142996788025e-01
    z[2,1,6]  R873      -0.443516343832016
    z[2,1,6]  R874      -2.7404433488845825e-01
    z[2,1,6]  R875      -2.0178568363189697e-01
    z[2,1,6]  R876      -9.5452917739748955e-03
    z[2,1,6]  R877      -1.8258096277713776e-01
    z[2,1,6]  R878      5.1814638078212738e-02
    z[2,1,6]  R879      -1.8083012104034424e-01
    z[2,1,6]  R880      2.2764241695404053e-01
    z[2,1,6]  R881      1.0954919457435608e-01
    z[2,1,6]  R882      3.7324190139770508e-02
    z[2,1,6]  R883      6.9620959460735321e-02
    z[2,1,6]  R884      -1.7409196496009827e-01
    z[2,1,6]  R885      -2.9442825913429260e-01
    z[2,1,6]  R886      -2.6521581411361694e-01
    z[2,1,6]  R887      -2.2699010372161865e-01
    z[2,1,6]  R888      2.6001834869384766e-01
    z[2,1,6]  R889      5.5389977991580963e-02
    z[2,1,6]  R890      -2.8567776083946228e-01
    z[2,1,6]  R891      6.4749278128147125e-02
    z[2,1,6]  R892      1.5751951932907104e-01
    z[2,1,6]  R893      1.5132038295269012e-01
    z[2,1,6]  R894      2.5233200192451477e-01
    z[2,1,6]  R895      -0.035448107868433
    z[2,1,6]  R896      2.8560683131217957e-01
    z[2,1,6]  R897      3.9391836524009705e-01
    z[2,1,6]  R898      7.0469003915786743e-01
    z[2,1,6]  R899      7.5557726621627808e-01
    z[2,1,6]  R900      -3.5521391034126282e-01
    z[2,1,6]  R901      -3.6219093948602676e-02
    z[2,1,6]  R902      -3.3626472949981689e-01
    z[2,1,6]  R903      -1.1651092767715454e-01
    z[2,1,6]  R904      1.8766130506992340e-01
    z[2,1,6]  R905      2.1053564548492432e-01
    z[2,1,6]  R906      -1.6096076369285583e-01
    z[2,1,6]  R907      2.3172810673713684e-01
    z[2,1,6]  R908      4.1252526640892029e-01
    z[2,1,6]  R909      -1.9073310494422913e-01
    z[2,1,6]  R910      -1.2972231209278107e-01
    z[2,1,6]  R911      -5.2020758390426636e-01
    z[2,1,6]  R912      -7.9890716075897217e-01
    z[2,1,6]  R913      -4.0473058819770813e-01
    z[2,1,6]  R914      -3.6321204900741577e-01
    z[2,1,6]  R915      -5.4574948549270630e-01
    z[2,1,6]  R916      6.5559722483158112e-02
    z[2,1,6]  R917      3.6005118489265442e-01
    z[2,1,6]  R918      -4.5117178559303284e-01
    z[2,1,6]  R919      -5.4073441028594971e-01
    z[2,1,6]  R920      1.2992599513381720e-03
    z[2,1,6]  R921      2.1642138063907623e-01
    z[2,1,6]  R922      3.4340581297874451e-01
    z[2,1,6]  R923      -3.2740628719329834e-01
    z[2,1,6]  R924      -6.2006378173828125e-01
    z[2,1,6]  R925      2.7123183012008667e-01
    z[2,1,6]  R926      -4.2300187051296234e-02
    z[2,1,6]  R927      1.2370651215314865e-01
    z[2,1,6]  R928      -4.7015976905822754e-01
    z[2,1,6]  R929      3.4981733560562134e-01
    z[2,1,6]  R930      -7.3354914784431458e-02
    z[2,1,6]  R931      -2.4641756713390350e-01
    z[2,1,6]  R932      -2.3655369877815247e-02
    z[2,1,6]  R933      4.4243231415748596e-02
    z[2,1,6]  R934      -2.6326501369476318e-01
    z[2,1,6]  R935      -6.7819356918334961e-02
    z[2,1,6]  R936      -5.0240176916122437e-01
    z[2,1,6]  R937      -2.6337611675262451e-01
    z[2,1,6]  R938      -3.5471022129058838e-02
    z[2,1,6]  R939      1.9848808646202087e-01
    z[2,1,6]  R940      -6.9091357290744781e-02
    z[2,1,6]  R941      3.4583261609077454e-01
    z[2,1,6]  R942      1.0074346512556076e-01
    z[2,1,6]  R943      2.9694160819053650e-01
    z[2,1,6]  R944      2.5770869851112366e-01
    z[1,4,0]  R11       -1
    z[1,4,0]  R38       1
    z[1,4,0]  R945      -1
    z[1,4,0]  R946      1
    z[1,4,0]  R959      -2.3927323520183563e-01
    z[1,4,0]  R960      -9.3068093061447144e-02
    z[1,4,0]  R961      -1.8396428227424622e-01
    z[1,4,0]  R962      1.1003871262073517e-01
    z[1,4,0]  R963      -4.2539175599813461e-02
    z[1,4,0]  R964      -3.0694505572319031e-01
    z[1,4,0]  R965      2.3849646747112274e-01
    z[1,4,0]  R966      -2.5389662384986877e-01
    z[1,4,0]  R967      -3.2029229402542114e-01
    z[1,4,0]  R968      -1.6619090735912323e-01
    z[1,4,0]  R969      6.6466385126113892e-01
    z[1,4,0]  R970      -4.7198975086212158e-01
    z[1,4,0]  R971      -7.8905403614044189e-01
    z[1,4,0]  R972      -0.89189612865448
    z[1,4,0]  R973      -3.1033545732498169e-01
    z[1,4,0]  R974      -5.1954627037048340e-01
    z[1,4,0]  R975      -3.0689609050750732e-01
    z[1,4,0]  R976      3.9101323485374451e-01
    z[1,4,0]  R977      -2.4056018888950348e-01
    z[1,4,0]  R978      -2.3183842003345490e-01
    z[1,4,0]  R979      3.5448500514030457e-01
    z[1,4,0]  R980      1.2213188409805298e-01
    z[1,4,0]  R981      4.4516941905021667e-01
    z[1,4,0]  R982      7.5336650013923645e-02
    z[1,4,0]  R983      2.0835784077644348e-01
    z[1,4,0]  R984      3.7897145748138428e-01
    z[1,4,0]  R985      -2.0715612173080444e-01
    z[1,4,0]  R986      6.3558273017406464e-02
    z[1,4,0]  R987      1.4043904957361519e-04
    z[1,4,0]  R988      -5.2889108657836914e-01
    z[1,4,0]  R989      0.124534472823143
    z[1,4,0]  R990      3.2512968778610229e-01
    z[1,4,0]  R991      1.2217810004949570e-01
    z[1,4,0]  R992      -0.0638943687081337
    z[1,4,0]  R993      3.9143315516412258e-03
    z[1,4,0]  R994      -5.3495984524488449e-02
    z[1,4,0]  R995      -6.1061024665832520e-01
    z[1,4,0]  R996      -3.2372646033763885e-02
    z[1,4,0]  R997      -1.4620240032672882e-01
    z[1,4,0]  R998      -5.6994175910949707e-01
    z[1,4,0]  R999      5.4328281432390213e-02
    z[1,4,0]  R1000     -7.7049273252487183e-01
    z[1,4,0]  R1001     -3.6872324347496033e-01
    z[1,4,0]  R1002     -3.8276901841163635e-01
    z[1,4,0]  R1003     -0.460308313369751
    z[1,4,0]  R1004     -3.8408553600311279e-01
    z[1,4,0]  R1005     5.7115048170089722e-01
    z[1,4,0]  R1006     -2.7225458621978760e-01
    z[1,4,0]  R1007     5.5754220485687256e-01
    z[1,4,0]  R1008     -0.0692228153347969
    z[1,4,0]  R1009     -1.8829548358917236e-01
    z[1,4,0]  R1010     -3.2876855134963989e-01
    z[1,4,0]  R1011     -0.364611953496933
    z[1,4,0]  R1012     -5.1757901906967163e-01
    z[1,4,0]  R1013     -4.3709689378738403e-01
    z[1,4,0]  R1014     -1.4845295250415802e-01
    z[1,4,0]  R1015     -6.5169042348861694e-01
    z[1,4,0]  R1016     4.5602847822010517e-03
    z[1,4,0]  R1017     -4.2190793156623840e-01
    z[1,4,0]  R1018     1.9931890070438385e-01
    z[1,4,0]  R1019     -1.1368344724178314e-01
    z[1,4,0]  R1020     5.8324247598648071e-01
    z[1,4,0]  R1021     6.9198060035705566e-01
    z[1,4,0]  R1022     0.673913836479187
    z[1,4,0]  R1023     5.4904800653457642e-01
    z[1,4,0]  R1024     6.6781336069107056e-01
    z[1,4,0]  R1025     0.593197226524353
    z[1,4,0]  R1026     7.4587661027908325e-01
    z[1,4,0]  R1027     7.3596894741058350e-01
    z[1,4,0]  R1028     5.3640419244766235e-01
    z[1,4,0]  R1029     2.8914016485214233e-01
    z[1,4,0]  R1030     4.8537275195121765e-01
    z[1,4,0]  R1031     5.3979862481355667e-02
    z[1,4,0]  R1032     8.1701517105102539e-02
    z[1,4,0]  R1033     -5.5371288908645511e-04
    z[1,4,0]  R1034     2.7030816674232483e-01
    z[1,4,0]  R1035     3.8807886838912964e-01
    z[1,4,0]  R1036     5.0469088554382324e-01
    z[1,4,1]  R12       -1
    z[1,4,1]  R39       1
    z[1,4,1]  R947      -1
    z[1,4,1]  R948      1
    z[1,4,1]  R959      -2.3412662744522095e-01
    z[1,4,1]  R960      -3.2256475090980530e-01
    z[1,4,1]  R961      -3.6999046802520752e-01
    z[1,4,1]  R962      -5.2285623550415039e-01
    z[1,4,1]  R963      -4.6815851330757141e-01
    z[1,4,1]  R964      -4.2803874611854553e-01
    z[1,4,1]  R965      -7.1605294942855835e-01
    z[1,4,1]  R966      6.4604789018630981e-01
    z[1,4,1]  R967      8.5382020473480225e-01
    z[1,4,1]  R968      8.7410008907318115e-01
    z[1,4,1]  R969      -2.1206778287887573e-01
    z[1,4,1]  R970      5.5650299787521362e-01
    z[1,4,1]  R971      2.7068966627120972e-01
    z[1,4,1]  R972      2.0389008522033691e-01
    z[1,4,1]  R973      2.8315299749374390e-01
    z[1,4,1]  R974      3.0223432183265686e-01
    z[1,4,1]  R975      -1.4377743005752563e-01
    z[1,4,1]  R976      -2.0649042725563049e-01
    z[1,4,1]  R977      8.2114261388778687e-01
    z[1,4,1]  R978      7.1400213241577148e-01
    z[1,4,1]  R979      -3.3164060115814209e-01
    z[1,4,1]  R980      -1.8140999972820282e-01
    z[1,4,1]  R981      -5.1794147491455078e-01
    z[1,4,1]  R982      -5.0821495056152344e-01
    z[1,4,1]  R983      -6.5732920169830322e-01
    z[1,4,1]  R984      -5.3367048501968384e-01
    z[1,4,1]  R985      -5.9342402219772339e-01
    z[1,4,1]  R986      2.9371902346611023e-01
    z[1,4,1]  R987      3.0722531676292419e-01
    z[1,4,1]  R988      7.0174783468246460e-01
    z[1,4,1]  R989      -5.3573852777481079e-01
    z[1,4,1]  R990      -7.3988282680511475e-01
    z[1,4,1]  R991      -1.4559482038021088e-01
    z[1,4,1]  R992      -6.6544854640960693e-01
    z[1,4,1]  R993      2.6029470562934875e-01
    z[1,4,1]  R994      0.684913694858551
    z[1,4,1]  R995      5.3332304954528809e-01
    z[1,4,1]  R996      7.8472161293029785e-01
    z[1,4,1]  R997      8.9037430286407471e-01
    z[1,4,1]  R998      0.710384726524353
    z[1,4,1]  R999      -4.5226737856864929e-01
    z[1,4,1]  R1000     2.4580633640289307e-01
    z[1,4,1]  R1001     6.3817453384399414e-01
    z[1,4,1]  R1002     -5.0469082593917847e-01
    z[1,4,1]  R1003     7.7087897062301636e-01
    z[1,4,1]  R1004     7.6046824455261230e-01
    z[1,4,1]  R1005     7.8955745697021484e-01
    z[1,4,1]  R1006     2.1833692491054535e-01
    z[1,4,1]  R1007     7.0232802629470825e-01
    z[1,4,1]  R1008     7.7890682220458984e-01
    z[1,4,1]  R1009     6.7440932989120483e-01
    z[1,4,1]  R1010     0.812924325466156
    z[1,4,1]  R1011     0.594958484172821
    z[1,4,1]  R1012     6.1003899574279785e-01
    z[1,4,1]  R1013     5.5178344249725342e-01
    z[1,4,1]  R1014     5.8253526687622070e-01
    z[1,4,1]  R1015     5.1752042770385742e-01
    z[1,4,1]  R1016     5.7960999011993408e-01
    z[1,4,1]  R1017     -4.8534622788429260e-01
    z[1,4,1]  R1018     -6.8122231960296631e-01
    z[1,4,1]  R1019     -6.4879775047302246e-01
    z[1,4,1]  R1020     -4.6633762121200562e-01
    z[1,4,1]  R1021     -4.0039667487144470e-01
    z[1,4,1]  R1022     -4.0915042161941528e-01
    z[1,4,1]  R1023     -3.6398413777351379e-01
    z[1,4,1]  R1024     -5.5775296688079834e-01
    z[1,4,1]  R1025     -4.2307758331298828e-01
    z[1,4,1]  R1026     -3.9859792590141296e-01
    z[1,4,1]  R1027     -0.547124445438385
    z[1,4,1]  R1028     -2.6161062717437744e-01
    z[1,4,1]  R1029     -1.8674476444721222e-01
    z[1,4,1]  R1030     1.7809976637363434e-01
    z[1,4,1]  R1031     -4.5620836317539215e-02
    z[1,4,1]  R1032     -2.5697553157806396e-01
    z[1,4,1]  R1033     -0.725864589214325
    z[1,4,1]  R1034     -5.9336471557617188e-01
    z[1,4,1]  R1035     -1.5418398380279541e-01
    z[1,4,1]  R1036     -7.1462118625640869e-01
    z[1,4,2]  R13       -1
    z[1,4,2]  R40       1
    z[1,4,2]  R949      -1
    z[1,4,2]  R950      1
    z[1,4,2]  R959      7.8288090229034424e-01
    z[1,4,2]  R960      6.9121789932250977e-01
    z[1,4,2]  R961      2.7046054601669312e-01
    z[1,4,2]  R962      -9.0173922479152679e-02
    z[1,4,2]  R963      0.612095057964325
    z[1,4,2]  R964      4.0137669444084167e-01
    z[1,4,2]  R965      -2.8709178790450096e-02
    z[1,4,2]  R966      -3.5165694355964661e-01
    z[1,4,2]  R967      7.7848076820373535e-02
    z[1,4,2]  R968      -2.6500681042671204e-01
    z[1,4,2]  R969      -1.8514315783977509e-01
    z[1,4,2]  R970      5.4202932119369507e-01
    z[1,4,2]  R971      -1.2013711780309677e-01
    z[1,4,2]  R972      3.0058783292770386e-01
    z[1,4,2]  R973      -3.3320057392120361e-01
    z[1,4,2]  R974      -2.3354759812355042e-01
    z[1,4,2]  R975      -2.6625505089759827e-01
    z[1,4,2]  R976      2.5235649943351746e-01
    z[1,4,2]  R977      -1.5740875899791718e-01
    z[1,4,2]  R978      2.9138955473899841e-01
    z[1,4,2]  R979      2.7108547091484070e-01
    z[1,4,2]  R980      4.9036440253257751e-01
    z[1,4,2]  R981      3.1304258108139038e-01
    z[1,4,2]  R982      3.3663868904113770e-01
    z[1,4,2]  R983      -2.5620761513710022e-01
    z[1,4,2]  R984      -3.8797748088836670e-01
    z[1,4,2]  R985      -1.6617652773857117e-01
    z[1,4,2]  R986      5.5452769994735718e-01
    z[1,4,2]  R987      5.9412352740764618e-02
    z[1,4,2]  R988      2.2869819402694702e-01
    z[1,4,2]  R989      7.1511673927307129e-01
    z[1,4,2]  R990      -2.6457920670509338e-01
    z[1,4,2]  R991      4.2584562301635742e-01
    z[1,4,2]  R992      -1.1458848416805267e-01
    z[1,4,2]  R993      -6.1519676446914673e-01
    z[1,4,2]  R994      -1.7192934453487396e-01
    z[1,4,2]  R995      -2.2272443771362305e-01
    z[1,4,2]  R996      -2.4329580366611481e-01
    z[1,4,2]  R997      -2.7469378709793091e-01
    z[1,4,2]  R998      1.3224802911281586e-02
    z[1,4,2]  R999      -1.1340240389108658e-01
    z[1,4,2]  R1000     3.0671819113194942e-03
    z[1,4,2]  R1001     5.8155737817287445e-02
    z[1,4,2]  R1002     2.9615920782089233e-01
    z[1,4,2]  R1003     -0.0243210606276989
    z[1,4,2]  R1004     -3.4894734621047974e-01
    z[1,4,2]  R1005     -1.1464491486549377e-01
    z[1,4,2]  R1006     -6.2834733724594116e-01
    z[1,4,2]  R1007     -2.8288549184799194e-01
    z[1,4,2]  R1008     -2.9798674583435059e-01
    z[1,4,2]  R1009     -0.347235769033432
    z[1,4,2]  R1010     -7.6188750565052032e-02
    z[1,4,2]  R1011     2.3774772882461548e-01
    z[1,4,2]  R1012     -0.0581904798746109
    z[1,4,2]  R1013     4.2077171802520752e-01
    z[1,4,2]  R1014     -2.3059609532356262e-01
    z[1,4,2]  R1015     1.4783754944801331e-01
    z[1,4,2]  R1016     -4.7947093844413757e-01
    z[1,4,2]  R1017     -1.1642266064882278e-01
    z[1,4,2]  R1018     3.3215153217315674e-01
    z[1,4,2]  R1019     2.8857752680778503e-01
    z[1,4,2]  R1020     5.6902801990509033e-01
    z[1,4,2]  R1021     0.561430811882019
    z[1,4,2]  R1022     5.6609356403350830e-01
    z[1,4,2]  R1023     6.9370740652084351e-01
    z[1,4,2]  R1024     4.2793425917625427e-01
    z[1,4,2]  R1025     4.9629786610603333e-01
    z[1,4,2]  R1026     2.9269164800643921e-01
    z[1,4,2]  R1027     2.1162860095500946e-01
    z[1,4,2]  R1028     -3.2568764686584473e-01
    z[1,4,2]  R1029     -1.9889141619205475e-01
    z[1,4,2]  R1030     -1.4858931303024292e-01
    z[1,4,2]  R1031     2.5257551670074463e-01
    z[1,4,2]  R1032     -4.2722240090370178e-02
    z[1,4,2]  R1033     3.6074250936508179e-01
    z[1,4,2]  R1034     1.5408769249916077e-01
    z[1,4,2]  R1035     5.6516725569963455e-02
    z[1,4,2]  R1036     -2.8202304244041443e-01
    z[1,4,3]  R14       -1
    z[1,4,3]  R41       1
    z[1,4,3]  R951      -1
    z[1,4,3]  R952      1
    z[1,4,3]  R959      -1.3675062358379364e-01
    z[1,4,3]  R960      -1.2978547811508179e-01
    z[1,4,3]  R961      -2.1833953261375427e-01
    z[1,4,3]  R962      -0.192160502076149
    z[1,4,3]  R963      2.3703585565090179e-01
    z[1,4,3]  R964      1.8773065507411957e-01
    z[1,4,3]  R965      4.6362329274415970e-02
    z[1,4,3]  R966      -1.2510886788368225e-01
    z[1,4,3]  R967      -1.6061370074748993e-01
    z[1,4,3]  R968      -2.4646823108196259e-01
    z[1,4,3]  R969      -6.7244774103164673e-01
    z[1,4,3]  R970      -3.4394088387489319e-01
    z[1,4,3]  R971      1.5020883083343506e-01
    z[1,4,3]  R972      1.7196573317050934e-01
    z[1,4,3]  R973      -3.5162393003702164e-02
    z[1,4,3]  R974      -3.5772061347961426e-01
    z[1,4,3]  R975      -0.360651433467865
    z[1,4,3]  R976      1.1904857121407986e-02
    z[1,4,3]  R977      1.0218356549739838e-01
    z[1,4,3]  R978      7.6278068125247955e-02
    z[1,4,3]  R979      -1.2785153090953827e-01
    z[1,4,3]  R980      -3.0141493678092957e-01
    z[1,4,3]  R981      3.7640803493559361e-03
    z[1,4,3]  R982      4.3715375661849976e-01
    z[1,4,3]  R983      5.1293814182281494e-01
    z[1,4,3]  R984      1.5632462501525879e-01
    z[1,4,3]  R985      6.3311499357223511e-01
    z[1,4,3]  R986      -5.8447301387786865e-01
    z[1,4,3]  R987      -2.7181667089462280e-01
    z[1,4,3]  R988      -7.3082715272903442e-02
    z[1,4,3]  R989      -3.0466508865356445e-01
    z[1,4,3]  R990      -1.4586928486824036e-01
    z[1,4,3]  R991      -3.5448685288429260e-01
    z[1,4,3]  R992      5.7399606704711914e-01
    z[1,4,3]  R993      -5.2418279647827148e-01
    z[1,4,3]  R994      -0.277119517326355
    z[1,4,3]  R995      -1.5559767186641693e-01
    z[1,4,3]  R996      -4.8624446988105774e-01
    z[1,4,3]  R997      -1.8034832552075386e-02
    z[1,4,3]  R998      3.2120910286903381e-01
    z[1,4,3]  R999      2.6803153753280640e-01
    z[1,4,3]  R1000     -4.8867025971412659e-01
    z[1,4,3]  R1001     -7.2287283837795258e-02
    z[1,4,3]  R1002     5.6514286994934082e-01
    z[1,4,3]  R1003     2.9438361525535583e-01
    z[1,4,3]  R1004     8.9321218430995941e-02
    z[1,4,3]  R1005     1.5312604606151581e-02
    z[1,4,3]  R1006     -0.288524866104126
    z[1,4,3]  R1007     0.1168212890625
    z[1,4,3]  R1008     -2.7236613631248474e-01
    z[1,4,3]  R1009     4.8791030049324036e-01
    z[1,4,3]  R1010     1.8327637016773224e-01
    z[1,4,3]  R1011     4.3993502855300903e-01
    z[1,4,3]  R1012     2.8136044740676880e-01
    z[1,4,3]  R1013     -1.7711807787418365e-01
    z[1,4,3]  R1014     -1.3692776858806610e-01
    z[1,4,3]  R1015     -2.7051979303359985e-01
    z[1,4,3]  R1016     9.7662389278411865e-02
    z[1,4,3]  R1017     -2.1610608696937561e-01
    z[1,4,3]  R1018     -3.7701785564422607e-01
    z[1,4,3]  R1019     -6.3731677830219269e-02
    z[1,4,3]  R1020     -4.6401996165513992e-02
    z[1,4,3]  R1021     -8.5805654525756836e-02
    z[1,4,3]  R1022     -1.5014901757240295e-01
    z[1,4,3]  R1023     -5.4991997778415680e-02
    z[1,4,3]  R1024     1.2495151162147522e-01
    z[1,4,3]  R1025     7.7261097729206085e-02
    z[1,4,3]  R1026     -4.2161926627159119e-02
    z[1,4,3]  R1027     8.5739880800247192e-02
    z[1,4,3]  R1028     -7.1150410175323486e-01
    z[1,4,3]  R1029     -6.3634729385375977e-01
    z[1,4,3]  R1030     -7.4254709482192993e-01
    z[1,4,3]  R1031     -7.9481166601181030e-01
    z[1,4,3]  R1032     -5.0166660547256470e-01
    z[1,4,3]  R1033     -0.315601110458374
    z[1,4,3]  R1034     -5.9093427658081055e-01
    z[1,4,3]  R1035     -6.3995629549026489e-01
    z[1,4,3]  R1036     1.8050726503133774e-02
    z[1,4,4]  R15       -1
    z[1,4,4]  R42       1
    z[1,4,4]  R953      -1
    z[1,4,4]  R954      1
    z[1,4,4]  R959      3.7444502115249634e-01
    z[1,4,4]  R960      4.6636760234832764e-01
    z[1,4,4]  R961      7.1435712277889252e-02
    z[1,4,4]  R962      3.0189543962478638e-01
    z[1,4,4]  R963      4.6917036175727844e-01
    z[1,4,4]  R964      -6.2298811972141266e-02
    z[1,4,4]  R965      1.1157064139842987e-01
    z[1,4,4]  R966      1.7434763908386230e-01
    z[1,4,4]  R967      0.265186071395874
    z[1,4,4]  R968      8.1869371235370636e-02
    z[1,4,4]  R969      -0.0295050460845232
    z[1,4,4]  R970      4.1165456175804138e-02
    z[1,4,4]  R971      1.4436149597167969e-01
    z[1,4,4]  R972      -7.9460576176643372e-02
    z[1,4,4]  R973      7.5569534301757812e-01
    z[1,4,4]  R974      -5.1839772611856461e-02
    z[1,4,4]  R975      1.8890835344791412e-01
    z[1,4,4]  R976      -2.3591178655624390e-01
    z[1,4,4]  R977      -3.0672883987426758e-01
    z[1,4,4]  R978      -1.2151244282722473e-01
    z[1,4,4]  R979      -4.5494616031646729e-01
    z[1,4,4]  R980      -5.7108914852142334e-01
    z[1,4,4]  R981      -1.4176666736602783e-01
    z[1,4,4]  R982      -3.3100968599319458e-01
    z[1,4,4]  R983      1.0167949646711349e-01
    z[1,4,4]  R984      -3.1500551104545593e-01
    z[1,4,4]  R985      -2.4191634356975555e-01
    z[1,4,4]  R986      -2.6066654920578003e-01
    z[1,4,4]  R987      4.7065809369087219e-02
    z[1,4,4]  R988      -2.2838643193244934e-01
    z[1,4,4]  R989      -1.7407071590423584e-01
    z[1,4,4]  R990      1.1996034532785416e-01
    z[1,4,4]  R991      3.4921982884407043e-01
    z[1,4,4]  R992      1.6590552031993866e-01
    z[1,4,4]  R993      3.6356106400489807e-01
    z[1,4,4]  R994      0.567359983921051
    z[1,4,4]  R995      -4.1081428527832031e-01
    z[1,4,4]  R996      -2.4256144464015961e-01
    z[1,4,4]  R997      -6.1225313693284988e-02
    z[1,4,4]  R998      -2.1430957317352295e-01
    z[1,4,4]  R999      -3.9447724819183350e-01
    z[1,4,4]  R1000     -1.9413267076015472e-01
    z[1,4,4]  R1001     5.8033210039138794e-01
    z[1,4,4]  R1002     -3.3854478597640991e-01
    z[1,4,4]  R1003     -2.6605397462844849e-01
    z[1,4,4]  R1004     -1.3745093345642090e-01
    z[1,4,4]  R1005     6.3053965568542480e-02
    z[1,4,4]  R1006     2.9617384076118469e-01
    z[1,4,4]  R1007     1.8876156210899353e-01
    z[1,4,4]  R1008     4.3432092666625977e-01
    z[1,4,4]  R1009     3.4715458750724792e-01
    z[1,4,4]  R1010     4.3599805235862732e-01
    z[1,4,4]  R1011     6.2857642769813538e-02
    z[1,4,4]  R1012     1.6727188229560852e-01
    z[1,4,4]  R1013     3.2528951764106750e-01
    z[1,4,4]  R1014     -4.4658705592155457e-02
    z[1,4,4]  R1015     -1.3284756243228912e-01
    z[1,4,4]  R1016     1.2144851684570312e-01
    z[1,4,4]  R1017     4.8336514830589294e-01
    z[1,4,4]  R1018     -1.4025740325450897e-01
    z[1,4,4]  R1019     1.1695694178342819e-01
    z[1,4,4]  R1020     2.9780622571706772e-02
    z[1,4,4]  R1021     -0.113673135638237
    z[1,4,4]  R1022     9.4564080238342285e-02
    z[1,4,4]  R1023     -2.2984115406870842e-02
    z[1,4,4]  R1024     1.2909808754920959e-01
    z[1,4,4]  R1025     -1.5918545424938202e-01
    z[1,4,4]  R1026     -1.1347037553787231e-01
    z[1,4,4]  R1027     -1.8654270470142365e-01
    z[1,4,4]  R1028     1.5339119732379913e-01
    z[1,4,4]  R1029     -8.2135021686553955e-02
    z[1,4,4]  R1030     8.2185156643390656e-02
    z[1,4,4]  R1031     -1.1228418350219727e-01
    z[1,4,4]  R1032     2.6528099179267883e-01
    z[1,4,4]  R1033     -4.2539444565773010e-01
    z[1,4,4]  R1034     9.4021543860435486e-02
    z[1,4,4]  R1035     -4.5273822546005249e-01
    z[1,4,4]  R1036     -0.379819393157959
    z[1,4,5]  R16       -1
    z[1,4,5]  R43       1
    z[1,4,5]  R955      -1
    z[1,4,5]  R956      1
    z[1,4,5]  R959      1.8587511777877808e-01
    z[1,4,5]  R960      -1.4139805734157562e-01
    z[1,4,5]  R961      4.5469993352890015e-01
    z[1,4,5]  R962      8.6127929389476776e-02
    z[1,4,5]  R963      0.0432896763086319
    z[1,4,5]  R964      7.2182303667068481e-01
    z[1,4,5]  R965      5.4944694042205811e-01
    z[1,4,5]  R966      5.7868117094039917e-01
    z[1,4,5]  R967      -0.176085963845253
    z[1,4,5]  R968      -1.6225415468215942e-01
    z[1,4,5]  R969      -2.5128121487796307e-03
    z[1,4,5]  R970      6.8202703259885311e-03
    z[1,4,5]  R971      2.7587673068046570e-01
    z[1,4,5]  R972      -1.8212584778666496e-02
    z[1,4,5]  R973      3.5121780633926392e-01
    z[1,4,5]  R974      -4.2768475413322449e-01
    z[1,4,5]  R975      1.0120529681444168e-01
    z[1,4,5]  R976      -7.2193038463592529e-01
    z[1,4,5]  R977      -8.1432253122329712e-02
    z[1,4,5]  R978      -1.8198329210281372e-01
    z[1,4,5]  R979      -6.8062287569046021e-01
    z[1,4,5]  R980      -4.0630817413330078e-01
    z[1,4,5]  R981      -4.6032306551933289e-01
    z[1,4,5]  R982      -1.7219726741313934e-01
    z[1,4,5]  R983      -0.430600643157959
    z[1,4,5]  R984      -5.0054562091827393e-01
    z[1,4,5]  R985      5.8270907029509544e-03
    z[1,4,5]  R986      2.9229742288589478e-01
    z[1,4,5]  R987      6.6445773839950562e-01
    z[1,4,5]  R988      2.1083930134773254e-01
    z[1,4,5]  R989      2.4733105301856995e-01
    z[1,4,5]  R990      4.7527906298637390e-01
    z[1,4,5]  R991      5.6023615598678589e-01
    z[1,4,5]  R992      -2.4616421759128571e-01
    z[1,4,5]  R993      3.7608388066291809e-01
    z[1,4,5]  R994      1.9763027131557465e-01
    z[1,4,5]  R995      -3.1555801630020142e-01
    z[1,4,5]  R996      1.6353559494018555e-01
    z[1,4,5]  R997      -1.9240470230579376e-01
    z[1,4,5]  R998      0.129002645611763
    z[1,4,5]  R999      5.4752331972122192e-01
    z[1,4,5]  R1000     7.5934166088700294e-03
    z[1,4,5]  R1001     3.3185136318206787e-01
    z[1,4,5]  R1002     1.9408319890499115e-01
    z[1,4,5]  R1003     -1.7621102929115295e-01
    z[1,4,5]  R1004     -7.7011808753013611e-02
    z[1,4,5]  R1005     -1.5127140283584595e-01
    z[1,4,5]  R1006     -4.7354641556739807e-01
    z[1,4,5]  R1007     1.2884079478681087e-02
    z[1,4,5]  R1008     -1.1757581681013107e-01
    z[1,4,5]  R1009     -6.0707405209541321e-02
    z[1,4,5]  R1010     6.5165506675839424e-03
    z[1,4,5]  R1011     -3.0680984258651733e-01
    z[1,4,5]  R1012     1.6882508993148804e-01
    z[1,4,5]  R1013     -4.3570473790168762e-01
    z[1,4,5]  R1014     2.8054052591323853e-01
    z[1,4,5]  R1015     -3.7503218650817871e-01
    z[1,4,5]  R1016     4.0232893824577332e-01
    z[1,4,5]  R1017     8.7758600711822510e-02
    z[1,4,5]  R1018     -2.8529292345046997e-01
    z[1,4,5]  R1019     -1.2879328429698944e-01
    z[1,4,5]  R1020     3.3906564116477966e-01
    z[1,4,5]  R1021     1.3632264733314514e-01
    z[1,4,5]  R1022     1.3902534544467926e-01
    z[1,4,5]  R1023     1.9321456551551819e-01
    z[1,4,5]  R1024     1.4572256803512573e-01
    z[1,4,5]  R1025     3.3065313100814819e-01
    z[1,4,5]  R1026     3.3350548148155212e-01
    z[1,4,5]  R1027     2.5434008240699768e-01
    z[1,4,5]  R1028     0.0653185248374939
    z[1,4,5]  R1029     6.4751470088958740e-01
    z[1,4,5]  R1030     -2.3476819694042206e-01
    z[1,4,5]  R1031     4.9129912257194519e-01
    z[1,4,5]  R1032     3.8730046153068542e-01
    z[1,4,5]  R1033     2.4547970294952393e-01
    z[1,4,5]  R1034     -4.3531551957130432e-01
    z[1,4,5]  R1035     2.4686281383037567e-01
    z[1,4,5]  R1036     5.7919424027204514e-02
    z[1,4,6]  R17       -1
    z[1,4,6]  R44       1
    z[1,4,6]  R957      -1
    z[1,4,6]  R958      1
    z[1,4,6]  R959      2.8560683131217957e-01
    z[1,4,6]  R960      3.9391836524009705e-01
    z[1,4,6]  R961      7.0469003915786743e-01
    z[1,4,6]  R962      7.5557726621627808e-01
    z[1,4,6]  R963      -3.5521391034126282e-01
    z[1,4,6]  R964      -3.6219093948602676e-02
    z[1,4,6]  R965      -3.3626472949981689e-01
    z[1,4,6]  R966      -1.1651092767715454e-01
    z[1,4,6]  R967      1.8766130506992340e-01
    z[1,4,6]  R968      2.1053564548492432e-01
    z[1,4,6]  R969      -1.6096076369285583e-01
    z[1,4,6]  R970      2.3172810673713684e-01
    z[1,4,6]  R971      4.1252526640892029e-01
    z[1,4,6]  R972      -1.9073310494422913e-01
    z[1,4,6]  R973      -1.2972231209278107e-01
    z[1,4,6]  R974      -5.2020758390426636e-01
    z[1,4,6]  R975      -7.9890716075897217e-01
    z[1,4,6]  R976      -4.0473058819770813e-01
    z[1,4,6]  R977      -3.6321204900741577e-01
    z[1,4,6]  R978      -5.4574948549270630e-01
    z[1,4,6]  R979      6.5559722483158112e-02
    z[1,4,6]  R980      3.6005118489265442e-01
    z[1,4,6]  R981      -4.5117178559303284e-01
    z[1,4,6]  R982      -5.4073441028594971e-01
    z[1,4,6]  R983      1.2992599513381720e-03
    z[1,4,6]  R984      2.1642138063907623e-01
    z[1,4,6]  R985      3.4340581297874451e-01
    z[1,4,6]  R986      -3.2740628719329834e-01
    z[1,4,6]  R987      -6.2006378173828125e-01
    z[1,4,6]  R988      2.7123183012008667e-01
    z[1,4,6]  R989      -4.2300187051296234e-02
    z[1,4,6]  R990      1.2370651215314865e-01
    z[1,4,6]  R991      -4.7015976905822754e-01
    z[1,4,6]  R992      3.4981733560562134e-01
    z[1,4,6]  R993      -7.3354914784431458e-02
    z[1,4,6]  R994      -2.4641756713390350e-01
    z[1,4,6]  R995      -2.3655369877815247e-02
    z[1,4,6]  R996      4.4243231415748596e-02
    z[1,4,6]  R997      -2.6326501369476318e-01
    z[1,4,6]  R998      -6.7819356918334961e-02
    z[1,4,6]  R999      -5.0240176916122437e-01
    z[1,4,6]  R1000     -2.6337611675262451e-01
    z[1,4,6]  R1001     -3.5471022129058838e-02
    z[1,4,6]  R1002     1.9848808646202087e-01
    z[1,4,6]  R1003     -6.9091357290744781e-02
    z[1,4,6]  R1004     3.4583261609077454e-01
    z[1,4,6]  R1005     1.0074346512556076e-01
    z[1,4,6]  R1006     2.9694160819053650e-01
    z[1,4,6]  R1007     2.5770869851112366e-01
    z[1,4,6]  R1008     -1.5190209448337555e-01
    z[1,4,6]  R1009     -0.163969486951828
    z[1,4,6]  R1010     -3.9161231368780136e-02
    z[1,4,6]  R1011     -4.0611866116523743e-01
    z[1,4,6]  R1012     -4.7003483772277832e-01
    z[1,4,6]  R1013     -2.0241707563400269e-02
    z[1,4,6]  R1014     -6.9713217020034790e-01
    z[1,4,6]  R1015     0.232675239443779
    z[1,4,6]  R1016     4.9797871708869934e-01
    z[1,4,6]  R1017     5.3369772434234619e-01
    z[1,4,6]  R1018     -3.7772583961486816e-01
    z[1,4,6]  R1019     -6.6972541809082031e-01
    z[1,4,6]  R1020     -2.3642625659704208e-02
    z[1,4,6]  R1021     8.2296334207057953e-02
    z[1,4,6]  R1022     8.4611341357231140e-02
    z[1,4,6]  R1023     2.0963713526725769e-01
    z[1,4,6]  R1024     7.9340517520904541e-02
    z[1,4,6]  R1025     2.8665328025817871e-01
    z[1,4,6]  R1026     2.7062943577766418e-01
    z[1,4,6]  R1027     -0.0859035924077034
    z[1,4,6]  R1028     -0.061029102653265
    z[1,4,6]  R1029     -1.0491538792848587e-01
    z[1,4,6]  R1030     3.1203892827033997e-01
    z[1,4,6]  R1031     -2.1331250667572021e-01
    z[1,4,6]  R1032     -6.7336338758468628e-01
    z[1,4,6]  R1033     -4.6480432152748108e-02
    z[1,4,6]  R1034     -5.9714134782552719e-02
    z[1,4,6]  R1035     3.8336774706840515e-01
    z[1,4,6]  R1036     8.4399670362472534e-02
    z[4,1,0]  R11       1
    z[4,1,0]  R38       -1
    z[4,1,0]  R1037     -1
    z[4,1,0]  R1038     1
    z[4,1,0]  R1051     -0.0692228153347969
    z[4,1,0]  R1052     -1.8829548358917236e-01
    z[4,1,0]  R1053     -3.2876855134963989e-01
    z[4,1,0]  R1054     -0.364611953496933
    z[4,1,0]  R1055     -5.1757901906967163e-01
    z[4,1,0]  R1056     -4.3709689378738403e-01
    z[4,1,0]  R1057     -1.4845295250415802e-01
    z[4,1,0]  R1058     -6.5169042348861694e-01
    z[4,1,0]  R1059     4.5602847822010517e-03
    z[4,1,0]  R1060     -4.2190793156623840e-01
    z[4,1,0]  R1061     1.9931890070438385e-01
    z[4,1,0]  R1062     -1.1368344724178314e-01
    z[4,1,0]  R1063     5.8324247598648071e-01
    z[4,1,0]  R1064     6.9198060035705566e-01
    z[4,1,0]  R1065     0.673913836479187
    z[4,1,0]  R1066     5.4904800653457642e-01
    z[4,1,0]  R1067     6.6781336069107056e-01
    z[4,1,0]  R1068     0.593197226524353
    z[4,1,0]  R1069     7.4587661027908325e-01
    z[4,1,0]  R1070     7.3596894741058350e-01
    z[4,1,0]  R1071     5.3640419244766235e-01
    z[4,1,0]  R1072     2.8914016485214233e-01
    z[4,1,0]  R1073     4.8537275195121765e-01
    z[4,1,0]  R1074     5.3979862481355667e-02
    z[4,1,0]  R1075     8.1701517105102539e-02
    z[4,1,0]  R1076     -5.5371288908645511e-04
    z[4,1,0]  R1077     2.7030816674232483e-01
    z[4,1,0]  R1078     3.8807886838912964e-01
    z[4,1,0]  R1079     5.0469088554382324e-01
    z[4,1,0]  R1080     -2.3927323520183563e-01
    z[4,1,0]  R1081     -9.3068093061447144e-02
    z[4,1,0]  R1082     -1.8396428227424622e-01
    z[4,1,0]  R1083     1.1003871262073517e-01
    z[4,1,0]  R1084     -4.2539175599813461e-02
    z[4,1,0]  R1085     -3.0694505572319031e-01
    z[4,1,0]  R1086     2.3849646747112274e-01
    z[4,1,0]  R1087     -2.5389662384986877e-01
    z[4,1,0]  R1088     -3.2029229402542114e-01
    z[4,1,0]  R1089     -1.6619090735912323e-01
    z[4,1,0]  R1090     6.6466385126113892e-01
    z[4,1,0]  R1091     -4.7198975086212158e-01
    z[4,1,0]  R1092     -7.8905403614044189e-01
    z[4,1,0]  R1093     -0.89189612865448
    z[4,1,0]  R1094     -3.1033545732498169e-01
    z[4,1,0]  R1095     -5.1954627037048340e-01
    z[4,1,0]  R1096     -3.0689609050750732e-01
    z[4,1,0]  R1097     3.9101323485374451e-01
    z[4,1,0]  R1098     -2.4056018888950348e-01
    z[4,1,0]  R1099     -2.3183842003345490e-01
    z[4,1,0]  R1100     3.5448500514030457e-01
    z[4,1,0]  R1101     1.2213188409805298e-01
    z[4,1,0]  R1102     4.4516941905021667e-01
    z[4,1,0]  R1103     7.5336650013923645e-02
    z[4,1,0]  R1104     2.0835784077644348e-01
    z[4,1,0]  R1105     3.7897145748138428e-01
    z[4,1,0]  R1106     -2.0715612173080444e-01
    z[4,1,0]  R1107     6.3558273017406464e-02
    z[4,1,0]  R1108     1.4043904957361519e-04
    z[4,1,0]  R1109     -5.2889108657836914e-01
    z[4,1,0]  R1110     0.124534472823143
    z[4,1,0]  R1111     3.2512968778610229e-01
    z[4,1,0]  R1112     1.2217810004949570e-01
    z[4,1,0]  R1113     -0.0638943687081337
    z[4,1,0]  R1114     3.9143315516412258e-03
    z[4,1,0]  R1115     -5.3495984524488449e-02
    z[4,1,0]  R1116     -6.1061024665832520e-01
    z[4,1,0]  R1117     -3.2372646033763885e-02
    z[4,1,0]  R1118     -1.4620240032672882e-01
    z[4,1,0]  R1119     -5.6994175910949707e-01
    z[4,1,0]  R1120     5.4328281432390213e-02
    z[4,1,0]  R1121     -7.7049273252487183e-01
    z[4,1,0]  R1122     -3.6872324347496033e-01
    z[4,1,0]  R1123     -3.8276901841163635e-01
    z[4,1,0]  R1124     -0.460308313369751
    z[4,1,0]  R1125     -3.8408553600311279e-01
    z[4,1,0]  R1126     5.7115048170089722e-01
    z[4,1,0]  R1127     -2.7225458621978760e-01
    z[4,1,0]  R1128     5.5754220485687256e-01
    z[4,1,1]  R12       1
    z[4,1,1]  R39       -1
    z[4,1,1]  R1039     -1
    z[4,1,1]  R1040     1
    z[4,1,1]  R1051     7.7890682220458984e-01
    z[4,1,1]  R1052     6.7440932989120483e-01
    z[4,1,1]  R1053     0.812924325466156
    z[4,1,1]  R1054     0.594958484172821
    z[4,1,1]  R1055     6.1003899574279785e-01
    z[4,1,1]  R1056     5.5178344249725342e-01
    z[4,1,1]  R1057     5.8253526687622070e-01
    z[4,1,1]  R1058     5.1752042770385742e-01
    z[4,1,1]  R1059     5.7960999011993408e-01
    z[4,1,1]  R1060     -4.8534622788429260e-01
    z[4,1,1]  R1061     -6.8122231960296631e-01
    z[4,1,1]  R1062     -6.4879775047302246e-01
    z[4,1,1]  R1063     -4.6633762121200562e-01
    z[4,1,1]  R1064     -4.0039667487144470e-01
    z[4,1,1]  R1065     -4.0915042161941528e-01
    z[4,1,1]  R1066     -3.6398413777351379e-01
    z[4,1,1]  R1067     -5.5775296688079834e-01
    z[4,1,1]  R1068     -4.2307758331298828e-01
    z[4,1,1]  R1069     -3.9859792590141296e-01
    z[4,1,1]  R1070     -0.547124445438385
    z[4,1,1]  R1071     -2.6161062717437744e-01
    z[4,1,1]  R1072     -1.8674476444721222e-01
    z[4,1,1]  R1073     1.7809976637363434e-01
    z[4,1,1]  R1074     -4.5620836317539215e-02
    z[4,1,1]  R1075     -2.5697553157806396e-01
    z[4,1,1]  R1076     -0.725864589214325
    z[4,1,1]  R1077     -5.9336471557617188e-01
    z[4,1,1]  R1078     -1.5418398380279541e-01
    z[4,1,1]  R1079     -7.1462118625640869e-01
    z[4,1,1]  R1080     -2.3412662744522095e-01
    z[4,1,1]  R1081     -3.2256475090980530e-01
    z[4,1,1]  R1082     -3.6999046802520752e-01
    z[4,1,1]  R1083     -5.2285623550415039e-01
    z[4,1,1]  R1084     -4.6815851330757141e-01
    z[4,1,1]  R1085     -4.2803874611854553e-01
    z[4,1,1]  R1086     -7.1605294942855835e-01
    z[4,1,1]  R1087     6.4604789018630981e-01
    z[4,1,1]  R1088     8.5382020473480225e-01
    z[4,1,1]  R1089     8.7410008907318115e-01
    z[4,1,1]  R1090     -2.1206778287887573e-01
    z[4,1,1]  R1091     5.5650299787521362e-01
    z[4,1,1]  R1092     2.7068966627120972e-01
    z[4,1,1]  R1093     2.0389008522033691e-01
    z[4,1,1]  R1094     2.8315299749374390e-01
    z[4,1,1]  R1095     3.0223432183265686e-01
    z[4,1,1]  R1096     -1.4377743005752563e-01
    z[4,1,1]  R1097     -2.0649042725563049e-01
    z[4,1,1]  R1098     8.2114261388778687e-01
    z[4,1,1]  R1099     7.1400213241577148e-01
    z[4,1,1]  R1100     -3.3164060115814209e-01
    z[4,1,1]  R1101     -1.8140999972820282e-01
    z[4,1,1]  R1102     -5.1794147491455078e-01
    z[4,1,1]  R1103     -5.0821495056152344e-01
    z[4,1,1]  R1104     -6.5732920169830322e-01
    z[4,1,1]  R1105     -5.3367048501968384e-01
    z[4,1,1]  R1106     -5.9342402219772339e-01
    z[4,1,1]  R1107     2.9371902346611023e-01
    z[4,1,1]  R1108     3.0722531676292419e-01
    z[4,1,1]  R1109     7.0174783468246460e-01
    z[4,1,1]  R1110     -5.3573852777481079e-01
    z[4,1,1]  R1111     -7.3988282680511475e-01
    z[4,1,1]  R1112     -1.4559482038021088e-01
    z[4,1,1]  R1113     -6.6544854640960693e-01
    z[4,1,1]  R1114     2.6029470562934875e-01
    z[4,1,1]  R1115     0.684913694858551
    z[4,1,1]  R1116     5.3332304954528809e-01
    z[4,1,1]  R1117     7.8472161293029785e-01
    z[4,1,1]  R1118     8.9037430286407471e-01
    z[4,1,1]  R1119     0.710384726524353
    z[4,1,1]  R1120     -4.5226737856864929e-01
    z[4,1,1]  R1121     2.4580633640289307e-01
    z[4,1,1]  R1122     6.3817453384399414e-01
    z[4,1,1]  R1123     -5.0469082593917847e-01
    z[4,1,1]  R1124     7.7087897062301636e-01
    z[4,1,1]  R1125     7.6046824455261230e-01
    z[4,1,1]  R1126     7.8955745697021484e-01
    z[4,1,1]  R1127     2.1833692491054535e-01
    z[4,1,1]  R1128     7.0232802629470825e-01
    z[4,1,2]  R13       1
    z[4,1,2]  R40       -1
    z[4,1,2]  R1041     -1
    z[4,1,2]  R1042     1
    z[4,1,2]  R1051     -2.9798674583435059e-01
    z[4,1,2]  R1052     -0.347235769033432
    z[4,1,2]  R1053     -7.6188750565052032e-02
    z[4,1,2]  R1054     2.3774772882461548e-01
    z[4,1,2]  R1055     -0.0581904798746109
    z[4,1,2]  R1056     4.2077171802520752e-01
    z[4,1,2]  R1057     -2.3059609532356262e-01
    z[4,1,2]  R1058     1.4783754944801331e-01
    z[4,1,2]  R1059     -4.7947093844413757e-01
    z[4,1,2]  R1060     -1.1642266064882278e-01
    z[4,1,2]  R1061     3.3215153217315674e-01
    z[4,1,2]  R1062     2.8857752680778503e-01
    z[4,1,2]  R1063     5.6902801990509033e-01
    z[4,1,2]  R1064     0.561430811882019
    z[4,1,2]  R1065     5.6609356403350830e-01
    z[4,1,2]  R1066     6.9370740652084351e-01
    z[4,1,2]  R1067     4.2793425917625427e-01
    z[4,1,2]  R1068     4.9629786610603333e-01
    z[4,1,2]  R1069     2.9269164800643921e-01
    z[4,1,2]  R1070     2.1162860095500946e-01
    z[4,1,2]  R1071     -3.2568764686584473e-01
    z[4,1,2]  R1072     -1.9889141619205475e-01
    z[4,1,2]  R1073     -1.4858931303024292e-01
    z[4,1,2]  R1074     2.5257551670074463e-01
    z[4,1,2]  R1075     -4.2722240090370178e-02
    z[4,1,2]  R1076     3.6074250936508179e-01
    z[4,1,2]  R1077     1.5408769249916077e-01
    z[4,1,2]  R1078     5.6516725569963455e-02
    z[4,1,2]  R1079     -2.8202304244041443e-01
    z[4,1,2]  R1080     7.8288090229034424e-01
    z[4,1,2]  R1081     6.9121789932250977e-01
    z[4,1,2]  R1082     2.7046054601669312e-01
    z[4,1,2]  R1083     -9.0173922479152679e-02
    z[4,1,2]  R1084     0.612095057964325
    z[4,1,2]  R1085     4.0137669444084167e-01
    z[4,1,2]  R1086     -2.8709178790450096e-02
    z[4,1,2]  R1087     -3.5165694355964661e-01
    z[4,1,2]  R1088     7.7848076820373535e-02
    z[4,1,2]  R1089     -2.6500681042671204e-01
    z[4,1,2]  R1090     -1.8514315783977509e-01
    z[4,1,2]  R1091     5.4202932119369507e-01
    z[4,1,2]  R1092     -1.2013711780309677e-01
    z[4,1,2]  R1093     3.0058783292770386e-01
    z[4,1,2]  R1094     -3.3320057392120361e-01
    z[4,1,2]  R1095     -2.3354759812355042e-01
    z[4,1,2]  R1096     -2.6625505089759827e-01
    z[4,1,2]  R1097     2.5235649943351746e-01
    z[4,1,2]  R1098     -1.5740875899791718e-01
    z[4,1,2]  R1099     2.9138955473899841e-01
    z[4,1,2]  R1100     2.7108547091484070e-01
    z[4,1,2]  R1101     4.9036440253257751e-01
    z[4,1,2]  R1102     3.1304258108139038e-01
    z[4,1,2]  R1103     3.3663868904113770e-01
    z[4,1,2]  R1104     -2.5620761513710022e-01
    z[4,1,2]  R1105     -3.8797748088836670e-01
    z[4,1,2]  R1106     -1.6617652773857117e-01
    z[4,1,2]  R1107     5.5452769994735718e-01
    z[4,1,2]  R1108     5.9412352740764618e-02
    z[4,1,2]  R1109     2.2869819402694702e-01
    z[4,1,2]  R1110     7.1511673927307129e-01
    z[4,1,2]  R1111     -2.6457920670509338e-01
    z[4,1,2]  R1112     4.2584562301635742e-01
    z[4,1,2]  R1113     -1.1458848416805267e-01
    z[4,1,2]  R1114     -6.1519676446914673e-01
    z[4,1,2]  R1115     -1.7192934453487396e-01
    z[4,1,2]  R1116     -2.2272443771362305e-01
    z[4,1,2]  R1117     -2.4329580366611481e-01
    z[4,1,2]  R1118     -2.7469378709793091e-01
    z[4,1,2]  R1119     1.3224802911281586e-02
    z[4,1,2]  R1120     -1.1340240389108658e-01
    z[4,1,2]  R1121     3.0671819113194942e-03
    z[4,1,2]  R1122     5.8155737817287445e-02
    z[4,1,2]  R1123     2.9615920782089233e-01
    z[4,1,2]  R1124     -0.0243210606276989
    z[4,1,2]  R1125     -3.4894734621047974e-01
    z[4,1,2]  R1126     -1.1464491486549377e-01
    z[4,1,2]  R1127     -6.2834733724594116e-01
    z[4,1,2]  R1128     -2.8288549184799194e-01
    z[4,1,3]  R14       1
    z[4,1,3]  R41       -1
    z[4,1,3]  R1043     -1
    z[4,1,3]  R1044     1
    z[4,1,3]  R1051     -2.7236613631248474e-01
    z[4,1,3]  R1052     4.8791030049324036e-01
    z[4,1,3]  R1053     1.8327637016773224e-01
    z[4,1,3]  R1054     4.3993502855300903e-01
    z[4,1,3]  R1055     2.8136044740676880e-01
    z[4,1,3]  R1056     -1.7711807787418365e-01
    z[4,1,3]  R1057     -1.3692776858806610e-01
    z[4,1,3]  R1058     -2.7051979303359985e-01
    z[4,1,3]  R1059     9.7662389278411865e-02
    z[4,1,3]  R1060     -2.1610608696937561e-01
    z[4,1,3]  R1061     -3.7701785564422607e-01
    z[4,1,3]  R1062     -6.3731677830219269e-02
    z[4,1,3]  R1063     -4.6401996165513992e-02
    z[4,1,3]  R1064     -8.5805654525756836e-02
    z[4,1,3]  R1065     -1.5014901757240295e-01
    z[4,1,3]  R1066     -5.4991997778415680e-02
    z[4,1,3]  R1067     1.2495151162147522e-01
    z[4,1,3]  R1068     7.7261097729206085e-02
    z[4,1,3]  R1069     -4.2161926627159119e-02
    z[4,1,3]  R1070     8.5739880800247192e-02
    z[4,1,3]  R1071     -7.1150410175323486e-01
    z[4,1,3]  R1072     -6.3634729385375977e-01
    z[4,1,3]  R1073     -7.4254709482192993e-01
    z[4,1,3]  R1074     -7.9481166601181030e-01
    z[4,1,3]  R1075     -5.0166660547256470e-01
    z[4,1,3]  R1076     -0.315601110458374
    z[4,1,3]  R1077     -5.9093427658081055e-01
    z[4,1,3]  R1078     -6.3995629549026489e-01
    z[4,1,3]  R1079     1.8050726503133774e-02
    z[4,1,3]  R1080     -1.3675062358379364e-01
    z[4,1,3]  R1081     -1.2978547811508179e-01
    z[4,1,3]  R1082     -2.1833953261375427e-01
    z[4,1,3]  R1083     -0.192160502076149
    z[4,1,3]  R1084     2.3703585565090179e-01
    z[4,1,3]  R1085     1.8773065507411957e-01
    z[4,1,3]  R1086     4.6362329274415970e-02
    z[4,1,3]  R1087     -1.2510886788368225e-01
    z[4,1,3]  R1088     -1.6061370074748993e-01
    z[4,1,3]  R1089     -2.4646823108196259e-01
    z[4,1,3]  R1090     -6.7244774103164673e-01
    z[4,1,3]  R1091     -3.4394088387489319e-01
    z[4,1,3]  R1092     1.5020883083343506e-01
    z[4,1,3]  R1093     1.7196573317050934e-01
    z[4,1,3]  R1094     -3.5162393003702164e-02
    z[4,1,3]  R1095     -3.5772061347961426e-01
    z[4,1,3]  R1096     -0.360651433467865
    z[4,1,3]  R1097     1.1904857121407986e-02
    z[4,1,3]  R1098     1.0218356549739838e-01
    z[4,1,3]  R1099     7.6278068125247955e-02
    z[4,1,3]  R1100     -1.2785153090953827e-01
    z[4,1,3]  R1101     -3.0141493678092957e-01
    z[4,1,3]  R1102     3.7640803493559361e-03
    z[4,1,3]  R1103     4.3715375661849976e-01
    z[4,1,3]  R1104     5.1293814182281494e-01
    z[4,1,3]  R1105     1.5632462501525879e-01
    z[4,1,3]  R1106     6.3311499357223511e-01
    z[4,1,3]  R1107     -5.8447301387786865e-01
    z[4,1,3]  R1108     -2.7181667089462280e-01
    z[4,1,3]  R1109     -7.3082715272903442e-02
    z[4,1,3]  R1110     -3.0466508865356445e-01
    z[4,1,3]  R1111     -1.4586928486824036e-01
    z[4,1,3]  R1112     -3.5448685288429260e-01
    z[4,1,3]  R1113     5.7399606704711914e-01
    z[4,1,3]  R1114     -5.2418279647827148e-01
    z[4,1,3]  R1115     -0.277119517326355
    z[4,1,3]  R1116     -1.5559767186641693e-01
    z[4,1,3]  R1117     -4.8624446988105774e-01
    z[4,1,3]  R1118     -1.8034832552075386e-02
    z[4,1,3]  R1119     3.2120910286903381e-01
    z[4,1,3]  R1120     2.6803153753280640e-01
    z[4,1,3]  R1121     -4.8867025971412659e-01
    z[4,1,3]  R1122     -7.2287283837795258e-02
    z[4,1,3]  R1123     5.6514286994934082e-01
    z[4,1,3]  R1124     2.9438361525535583e-01
    z[4,1,3]  R1125     8.9321218430995941e-02
    z[4,1,3]  R1126     1.5312604606151581e-02
    z[4,1,3]  R1127     -0.288524866104126
    z[4,1,3]  R1128     0.1168212890625
    z[4,1,4]  R15       1
    z[4,1,4]  R42       -1
    z[4,1,4]  R1045     -1
    z[4,1,4]  R1046     1
    z[4,1,4]  R1051     4.3432092666625977e-01
    z[4,1,4]  R1052     3.4715458750724792e-01
    z[4,1,4]  R1053     4.3599805235862732e-01
    z[4,1,4]  R1054     6.2857642769813538e-02
    z[4,1,4]  R1055     1.6727188229560852e-01
    z[4,1,4]  R1056     3.2528951764106750e-01
    z[4,1,4]  R1057     -4.4658705592155457e-02
    z[4,1,4]  R1058     -1.3284756243228912e-01
    z[4,1,4]  R1059     1.2144851684570312e-01
    z[4,1,4]  R1060     4.8336514830589294e-01
    z[4,1,4]  R1061     -1.4025740325450897e-01
    z[4,1,4]  R1062     1.1695694178342819e-01
    z[4,1,4]  R1063     2.9780622571706772e-02
    z[4,1,4]  R1064     -0.113673135638237
    z[4,1,4]  R1065     9.4564080238342285e-02
    z[4,1,4]  R1066     -2.2984115406870842e-02
    z[4,1,4]  R1067     1.2909808754920959e-01
    z[4,1,4]  R1068     -1.5918545424938202e-01
    z[4,1,4]  R1069     -1.1347037553787231e-01
    z[4,1,4]  R1070     -1.8654270470142365e-01
    z[4,1,4]  R1071     1.5339119732379913e-01
    z[4,1,4]  R1072     -8.2135021686553955e-02
    z[4,1,4]  R1073     8.2185156643390656e-02
    z[4,1,4]  R1074     -1.1228418350219727e-01
    z[4,1,4]  R1075     2.6528099179267883e-01
    z[4,1,4]  R1076     -4.2539444565773010e-01
    z[4,1,4]  R1077     9.4021543860435486e-02
    z[4,1,4]  R1078     -4.5273822546005249e-01
    z[4,1,4]  R1079     -0.379819393157959
    z[4,1,4]  R1080     3.7444502115249634e-01
    z[4,1,4]  R1081     4.6636760234832764e-01
    z[4,1,4]  R1082     7.1435712277889252e-02
    z[4,1,4]  R1083     3.0189543962478638e-01
    z[4,1,4]  R1084     4.6917036175727844e-01
    z[4,1,4]  R1085     -6.2298811972141266e-02
    z[4,1,4]  R1086     1.1157064139842987e-01
    z[4,1,4]  R1087     1.7434763908386230e-01
    z[4,1,4]  R1088     0.265186071395874
    z[4,1,4]  R1089     8.1869371235370636e-02
    z[4,1,4]  R1090     -0.0295050460845232
    z[4,1,4]  R1091     4.1165456175804138e-02
    z[4,1,4]  R1092     1.4436149597167969e-01
    z[4,1,4]  R1093     -7.9460576176643372e-02
    z[4,1,4]  R1094     7.5569534301757812e-01
    z[4,1,4]  R1095     -5.1839772611856461e-02
    z[4,1,4]  R1096     1.8890835344791412e-01
    z[4,1,4]  R1097     -2.3591178655624390e-01
    z[4,1,4]  R1098     -3.0672883987426758e-01
    z[4,1,4]  R1099     -1.2151244282722473e-01
    z[4,1,4]  R1100     -4.5494616031646729e-01
    z[4,1,4]  R1101     -5.7108914852142334e-01
    z[4,1,4]  R1102     -1.4176666736602783e-01
    z[4,1,4]  R1103     -3.3100968599319458e-01
    z[4,1,4]  R1104     1.0167949646711349e-01
    z[4,1,4]  R1105     -3.1500551104545593e-01
    z[4,1,4]  R1106     -2.4191634356975555e-01
    z[4,1,4]  R1107     -2.6066654920578003e-01
    z[4,1,4]  R1108     4.7065809369087219e-02
    z[4,1,4]  R1109     -2.2838643193244934e-01
    z[4,1,4]  R1110     -1.7407071590423584e-01
    z[4,1,4]  R1111     1.1996034532785416e-01
    z[4,1,4]  R1112     3.4921982884407043e-01
    z[4,1,4]  R1113     1.6590552031993866e-01
    z[4,1,4]  R1114     3.6356106400489807e-01
    z[4,1,4]  R1115     0.567359983921051
    z[4,1,4]  R1116     -4.1081428527832031e-01
    z[4,1,4]  R1117     -2.4256144464015961e-01
    z[4,1,4]  R1118     -6.1225313693284988e-02
    z[4,1,4]  R1119     -2.1430957317352295e-01
    z[4,1,4]  R1120     -3.9447724819183350e-01
    z[4,1,4]  R1121     -1.9413267076015472e-01
    z[4,1,4]  R1122     5.8033210039138794e-01
    z[4,1,4]  R1123     -3.3854478597640991e-01
    z[4,1,4]  R1124     -2.6605397462844849e-01
    z[4,1,4]  R1125     -1.3745093345642090e-01
    z[4,1,4]  R1126     6.3053965568542480e-02
    z[4,1,4]  R1127     2.9617384076118469e-01
    z[4,1,4]  R1128     1.8876156210899353e-01
    z[4,1,5]  R16       1
    z[4,1,5]  R43       -1
    z[4,1,5]  R1047     -1
    z[4,1,5]  R1048     1
    z[4,1,5]  R1051     -1.1757581681013107e-01
    z[4,1,5]  R1052     -6.0707405209541321e-02
    z[4,1,5]  R1053     6.5165506675839424e-03
    z[4,1,5]  R1054     -3.0680984258651733e-01
    z[4,1,5]  R1055     1.6882508993148804e-01
    z[4,1,5]  R1056     -4.3570473790168762e-01
    z[4,1,5]  R1057     2.8054052591323853e-01
    z[4,1,5]  R1058     -3.7503218650817871e-01
    z[4,1,5]  R1059     4.0232893824577332e-01
    z[4,1,5]  R1060     8.7758600711822510e-02
    z[4,1,5]  R1061     -2.8529292345046997e-01
    z[4,1,5]  R1062     -1.2879328429698944e-01
    z[4,1,5]  R1063     3.3906564116477966e-01
    z[4,1,5]  R1064     1.3632264733314514e-01
    z[4,1,5]  R1065     1.3902534544467926e-01
    z[4,1,5]  R1066     1.9321456551551819e-01
    z[4,1,5]  R1067     1.4572256803512573e-01
    z[4,1,5]  R1068     3.3065313100814819e-01
    z[4,1,5]  R1069     3.3350548148155212e-01
    z[4,1,5]  R1070     2.5434008240699768e-01
    z[4,1,5]  R1071     0.0653185248374939
    z[4,1,5]  R1072     6.4751470088958740e-01
    z[4,1,5]  R1073     -2.3476819694042206e-01
    z[4,1,5]  R1074     4.9129912257194519e-01
    z[4,1,5]  R1075     3.8730046153068542e-01
    z[4,1,5]  R1076     2.4547970294952393e-01
    z[4,1,5]  R1077     -4.3531551957130432e-01
    z[4,1,5]  R1078     2.4686281383037567e-01
    z[4,1,5]  R1079     5.7919424027204514e-02
    z[4,1,5]  R1080     1.8587511777877808e-01
    z[4,1,5]  R1081     -1.4139805734157562e-01
    z[4,1,5]  R1082     4.5469993352890015e-01
    z[4,1,5]  R1083     8.6127929389476776e-02
    z[4,1,5]  R1084     0.0432896763086319
    z[4,1,5]  R1085     7.2182303667068481e-01
    z[4,1,5]  R1086     5.4944694042205811e-01
    z[4,1,5]  R1087     5.7868117094039917e-01
    z[4,1,5]  R1088     -0.176085963845253
    z[4,1,5]  R1089     -1.6225415468215942e-01
    z[4,1,5]  R1090     -2.5128121487796307e-03
    z[4,1,5]  R1091     6.8202703259885311e-03
    z[4,1,5]  R1092     2.7587673068046570e-01
    z[4,1,5]  R1093     -1.8212584778666496e-02
    z[4,1,5]  R1094     3.5121780633926392e-01
    z[4,1,5]  R1095     -4.2768475413322449e-01
    z[4,1,5]  R1096     1.0120529681444168e-01
    z[4,1,5]  R1097     -7.2193038463592529e-01
    z[4,1,5]  R1098     -8.1432253122329712e-02
    z[4,1,5]  R1099     -1.8198329210281372e-01
    z[4,1,5]  R1100     -6.8062287569046021e-01
    z[4,1,5]  R1101     -4.0630817413330078e-01
    z[4,1,5]  R1102     -4.6032306551933289e-01
    z[4,1,5]  R1103     -1.7219726741313934e-01
    z[4,1,5]  R1104     -0.430600643157959
    z[4,1,5]  R1105     -5.0054562091827393e-01
    z[4,1,5]  R1106     5.8270907029509544e-03
    z[4,1,5]  R1107     2.9229742288589478e-01
    z[4,1,5]  R1108     6.6445773839950562e-01
    z[4,1,5]  R1109     2.1083930134773254e-01
    z[4,1,5]  R1110     2.4733105301856995e-01
    z[4,1,5]  R1111     4.7527906298637390e-01
    z[4,1,5]  R1112     5.6023615598678589e-01
    z[4,1,5]  R1113     -2.4616421759128571e-01
    z[4,1,5]  R1114     3.7608388066291809e-01
    z[4,1,5]  R1115     1.9763027131557465e-01
    z[4,1,5]  R1116     -3.1555801630020142e-01
    z[4,1,5]  R1117     1.6353559494018555e-01
    z[4,1,5]  R1118     -1.9240470230579376e-01
    z[4,1,5]  R1119     0.129002645611763
    z[4,1,5]  R1120     5.4752331972122192e-01
    z[4,1,5]  R1121     7.5934166088700294e-03
    z[4,1,5]  R1122     3.3185136318206787e-01
    z[4,1,5]  R1123     1.9408319890499115e-01
    z[4,1,5]  R1124     -1.7621102929115295e-01
    z[4,1,5]  R1125     -7.7011808753013611e-02
    z[4,1,5]  R1126     -1.5127140283584595e-01
    z[4,1,5]  R1127     -4.7354641556739807e-01
    z[4,1,5]  R1128     1.2884079478681087e-02
    z[4,1,6]  R17       1
    z[4,1,6]  R44       -1
    z[4,1,6]  R1049     -1
    z[4,1,6]  R1050     1
    z[4,1,6]  R1051     -1.5190209448337555e-01
    z[4,1,6]  R1052     -0.163969486951828
    z[4,1,6]  R1053     -3.9161231368780136e-02
    z[4,1,6]  R1054     -4.0611866116523743e-01
    z[4,1,6]  R1055     -4.7003483772277832e-01
    z[4,1,6]  R1056     -2.0241707563400269e-02
    z[4,1,6]  R1057     -6.9713217020034790e-01
    z[4,1,6]  R1058     0.232675239443779
    z[4,1,6]  R1059     4.9797871708869934e-01
    z[4,1,6]  R1060     5.3369772434234619e-01
    z[4,1,6]  R1061     -3.7772583961486816e-01
    z[4,1,6]  R1062     -6.6972541809082031e-01
    z[4,1,6]  R1063     -2.3642625659704208e-02
    z[4,1,6]  R1064     8.2296334207057953e-02
    z[4,1,6]  R1065     8.4611341357231140e-02
    z[4,1,6]  R1066     2.0963713526725769e-01
    z[4,1,6]  R1067     7.9340517520904541e-02
    z[4,1,6]  R1068     2.8665328025817871e-01
    z[4,1,6]  R1069     2.7062943577766418e-01
    z[4,1,6]  R1070     -0.0859035924077034
    z[4,1,6]  R1071     -0.061029102653265
    z[4,1,6]  R1072     -1.0491538792848587e-01
    z[4,1,6]  R1073     3.1203892827033997e-01
    z[4,1,6]  R1074     -2.1331250667572021e-01
    z[4,1,6]  R1075     -6.7336338758468628e-01
    z[4,1,6]  R1076     -4.6480432152748108e-02
    z[4,1,6]  R1077     -5.9714134782552719e-02
    z[4,1,6]  R1078     3.8336774706840515e-01
    z[4,1,6]  R1079     8.4399670362472534e-02
    z[4,1,6]  R1080     2.8560683131217957e-01
    z[4,1,6]  R1081     3.9391836524009705e-01
    z[4,1,6]  R1082     7.0469003915786743e-01
    z[4,1,6]  R1083     7.5557726621627808e-01
    z[4,1,6]  R1084     -3.5521391034126282e-01
    z[4,1,6]  R1085     -3.6219093948602676e-02
    z[4,1,6]  R1086     -3.3626472949981689e-01
    z[4,1,6]  R1087     -1.1651092767715454e-01
    z[4,1,6]  R1088     1.8766130506992340e-01
    z[4,1,6]  R1089     2.1053564548492432e-01
    z[4,1,6]  R1090     -1.6096076369285583e-01
    z[4,1,6]  R1091     2.3172810673713684e-01
    z[4,1,6]  R1092     4.1252526640892029e-01
    z[4,1,6]  R1093     -1.9073310494422913e-01
    z[4,1,6]  R1094     -1.2972231209278107e-01
    z[4,1,6]  R1095     -5.2020758390426636e-01
    z[4,1,6]  R1096     -7.9890716075897217e-01
    z[4,1,6]  R1097     -4.0473058819770813e-01
    z[4,1,6]  R1098     -3.6321204900741577e-01
    z[4,1,6]  R1099     -5.4574948549270630e-01
    z[4,1,6]  R1100     6.5559722483158112e-02
    z[4,1,6]  R1101     3.6005118489265442e-01
    z[4,1,6]  R1102     -4.5117178559303284e-01
    z[4,1,6]  R1103     -5.4073441028594971e-01
    z[4,1,6]  R1104     1.2992599513381720e-03
    z[4,1,6]  R1105     2.1642138063907623e-01
    z[4,1,6]  R1106     3.4340581297874451e-01
    z[4,1,6]  R1107     -3.2740628719329834e-01
    z[4,1,6]  R1108     -6.2006378173828125e-01
    z[4,1,6]  R1109     2.7123183012008667e-01
    z[4,1,6]  R1110     -4.2300187051296234e-02
    z[4,1,6]  R1111     1.2370651215314865e-01
    z[4,1,6]  R1112     -4.7015976905822754e-01
    z[4,1,6]  R1113     3.4981733560562134e-01
    z[4,1,6]  R1114     -7.3354914784431458e-02
    z[4,1,6]  R1115     -2.4641756713390350e-01
    z[4,1,6]  R1116     -2.3655369877815247e-02
    z[4,1,6]  R1117     4.4243231415748596e-02
    z[4,1,6]  R1118     -2.6326501369476318e-01
    z[4,1,6]  R1119     -6.7819356918334961e-02
    z[4,1,6]  R1120     -5.0240176916122437e-01
    z[4,1,6]  R1121     -2.6337611675262451e-01
    z[4,1,6]  R1122     -3.5471022129058838e-02
    z[4,1,6]  R1123     1.9848808646202087e-01
    z[4,1,6]  R1124     -6.9091357290744781e-02
    z[4,1,6]  R1125     3.4583261609077454e-01
    z[4,1,6]  R1126     1.0074346512556076e-01
    z[4,1,6]  R1127     2.9694160819053650e-01
    z[4,1,6]  R1128     2.5770869851112366e-01
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R1129     -1
    z[1,5,0]  R1130     1
    z[1,5,0]  R1143     -2.3927323520183563e-01
    z[1,5,0]  R1144     -9.3068093061447144e-02
    z[1,5,0]  R1145     -1.8396428227424622e-01
    z[1,5,0]  R1146     1.1003871262073517e-01
    z[1,5,0]  R1147     -4.2539175599813461e-02
    z[1,5,0]  R1148     -3.0694505572319031e-01
    z[1,5,0]  R1149     2.3849646747112274e-01
    z[1,5,0]  R1150     -2.5389662384986877e-01
    z[1,5,0]  R1151     -3.2029229402542114e-01
    z[1,5,0]  R1152     -1.6619090735912323e-01
    z[1,5,0]  R1153     6.6466385126113892e-01
    z[1,5,0]  R1154     -4.7198975086212158e-01
    z[1,5,0]  R1155     -7.8905403614044189e-01
    z[1,5,0]  R1156     -0.89189612865448
    z[1,5,0]  R1157     -3.1033545732498169e-01
    z[1,5,0]  R1158     -5.1954627037048340e-01
    z[1,5,0]  R1159     -3.0689609050750732e-01
    z[1,5,0]  R1160     3.9101323485374451e-01
    z[1,5,0]  R1161     -2.4056018888950348e-01
    z[1,5,0]  R1162     -2.3183842003345490e-01
    z[1,5,0]  R1163     3.5448500514030457e-01
    z[1,5,0]  R1164     1.2213188409805298e-01
    z[1,5,0]  R1165     4.4516941905021667e-01
    z[1,5,0]  R1166     7.5336650013923645e-02
    z[1,5,0]  R1167     2.0835784077644348e-01
    z[1,5,0]  R1168     3.7897145748138428e-01
    z[1,5,0]  R1169     -2.0715612173080444e-01
    z[1,5,0]  R1170     6.3558273017406464e-02
    z[1,5,0]  R1171     1.4043904957361519e-04
    z[1,5,0]  R1172     -5.2889108657836914e-01
    z[1,5,0]  R1173     0.124534472823143
    z[1,5,0]  R1174     3.2512968778610229e-01
    z[1,5,0]  R1175     1.2217810004949570e-01
    z[1,5,0]  R1176     -0.0638943687081337
    z[1,5,0]  R1177     3.9143315516412258e-03
    z[1,5,0]  R1178     -5.3495984524488449e-02
    z[1,5,0]  R1179     -6.1061024665832520e-01
    z[1,5,0]  R1180     -3.2372646033763885e-02
    z[1,5,0]  R1181     -1.4620240032672882e-01
    z[1,5,0]  R1182     -5.6994175910949707e-01
    z[1,5,0]  R1183     5.4328281432390213e-02
    z[1,5,0]  R1184     -7.7049273252487183e-01
    z[1,5,0]  R1185     -3.6872324347496033e-01
    z[1,5,0]  R1186     -3.8276901841163635e-01
    z[1,5,0]  R1187     -0.460308313369751
    z[1,5,0]  R1188     -3.8408553600311279e-01
    z[1,5,0]  R1189     5.7115048170089722e-01
    z[1,5,0]  R1190     -2.7225458621978760e-01
    z[1,5,0]  R1191     5.5754220485687256e-01
    z[1,5,0]  R1192     9.1751128435134888e-02
    z[1,5,0]  R1193     -2.9391407966613770e-01
    z[1,5,0]  R1194     3.5134589672088623e-01
    z[1,5,0]  R1195     1.8095086514949799e-01
    z[1,5,0]  R1196     4.5932576060295105e-02
    z[1,5,0]  R1197     0.0817050188779831
    z[1,5,0]  R1198     1.5777802467346191e-01
    z[1,5,0]  R1199     -2.8450459241867065e-01
    z[1,5,0]  R1200     -2.5793009996414185e-01
    z[1,5,0]  R1201     2.9511460661888123e-01
    z[1,5,0]  R1202     -8.0357983708381653e-02
    z[1,5,0]  R1203     -2.6397609710693359e-01
    z[1,5,0]  R1204     -7.9158611595630646e-02
    z[1,5,0]  R1205     -1.3939459621906281e-01
    z[1,5,0]  R1206     3.3405673503875732e-01
    z[1,5,0]  R1207     -3.1011231243610382e-02
    z[1,5,0]  R1208     -2.3243987560272217e-01
    z[1,5,0]  R1209     6.5164053812623024e-03
    z[1,5,0]  R1210     -1.2624450027942657e-01
    z[1,5,0]  R1211     3.0309295654296875e-01
    z[1,5,0]  R1212     -6.2123370170593262e-01
    z[1,5,0]  R1213     -1.2315837293863297e-01
    z[1,5,0]  R1214     -7.4878519773483276e-01
    z[1,5,0]  R1215     1.7647108435630798e-01
    z[1,5,0]  R1216     -7.7983301877975464e-01
    z[1,5,0]  R1217     -4.7811153531074524e-01
    z[1,5,0]  R1218     -3.9945331215858459e-01
    z[1,5,0]  R1219     -7.3482406139373779e-01
    z[1,5,0]  R1220     -5.1747697591781616e-01
    z[1,5,0]  R1221     -5.3739684820175171e-01
    z[1,5,0]  R1222     5.9888356924057007e-01
    z[1,5,0]  R1223     1.9250044226646423e-01
    z[1,5,0]  R1224     3.4843954443931580e-01
    z[1,5,0]  R1225     -1.4973483979701996e-01
    z[1,5,0]  R1226     5.2489286661148071e-01
    z[1,5,0]  R1227     7.5461953878402710e-01
    z[1,5,0]  R1228     6.6458392143249512e-01
    z[1,5,0]  R1229     -2.1477121859788895e-02
    z[1,5,0]  R1230     0.493700236082077
    z[1,5,0]  R1231     5.5405634641647339e-01
    z[1,5,0]  R1232     -3.0755949020385742e-01
    z[1,5,0]  R1233     5.7791608572006226e-01
    z[1,5,0]  R1234     3.1935986876487732e-01
    z[1,5,0]  R1235     -5.7855671644210815e-01
    z[1,5,0]  R1236     2.0953913033008575e-01
    z[1,5,0]  R1237     2.7045177295804024e-02
    z[1,5,0]  R1238     1.8525169789791107e-01
    z[1,5,0]  R1239     7.2206068038940430e-01
    z[1,5,0]  R1240     0.537449300289154
    z[1,5,0]  R1241     7.2452224791049957e-02
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R1131     -1
    z[1,5,1]  R1132     1
    z[1,5,1]  R1143     -2.3412662744522095e-01
    z[1,5,1]  R1144     -3.2256475090980530e-01
    z[1,5,1]  R1145     -3.6999046802520752e-01
    z[1,5,1]  R1146     -5.2285623550415039e-01
    z[1,5,1]  R1147     -4.6815851330757141e-01
    z[1,5,1]  R1148     -4.2803874611854553e-01
    z[1,5,1]  R1149     -7.1605294942855835e-01
    z[1,5,1]  R1150     6.4604789018630981e-01
    z[1,5,1]  R1151     8.5382020473480225e-01
    z[1,5,1]  R1152     8.7410008907318115e-01
    z[1,5,1]  R1153     -2.1206778287887573e-01
    z[1,5,1]  R1154     5.5650299787521362e-01
    z[1,5,1]  R1155     2.7068966627120972e-01
    z[1,5,1]  R1156     2.0389008522033691e-01
    z[1,5,1]  R1157     2.8315299749374390e-01
    z[1,5,1]  R1158     3.0223432183265686e-01
    z[1,5,1]  R1159     -1.4377743005752563e-01
    z[1,5,1]  R1160     -2.0649042725563049e-01
    z[1,5,1]  R1161     8.2114261388778687e-01
    z[1,5,1]  R1162     7.1400213241577148e-01
    z[1,5,1]  R1163     -3.3164060115814209e-01
    z[1,5,1]  R1164     -1.8140999972820282e-01
    z[1,5,1]  R1165     -5.1794147491455078e-01
    z[1,5,1]  R1166     -5.0821495056152344e-01
    z[1,5,1]  R1167     -6.5732920169830322e-01
    z[1,5,1]  R1168     -5.3367048501968384e-01
    z[1,5,1]  R1169     -5.9342402219772339e-01
    z[1,5,1]  R1170     2.9371902346611023e-01
    z[1,5,1]  R1171     3.0722531676292419e-01
    z[1,5,1]  R1172     7.0174783468246460e-01
    z[1,5,1]  R1173     -5.3573852777481079e-01
    z[1,5,1]  R1174     -7.3988282680511475e-01
    z[1,5,1]  R1175     -1.4559482038021088e-01
    z[1,5,1]  R1176     -6.6544854640960693e-01
    z[1,5,1]  R1177     2.6029470562934875e-01
    z[1,5,1]  R1178     0.684913694858551
    z[1,5,1]  R1179     5.3332304954528809e-01
    z[1,5,1]  R1180     7.8472161293029785e-01
    z[1,5,1]  R1181     8.9037430286407471e-01
    z[1,5,1]  R1182     0.710384726524353
    z[1,5,1]  R1183     -4.5226737856864929e-01
    z[1,5,1]  R1184     2.4580633640289307e-01
    z[1,5,1]  R1185     6.3817453384399414e-01
    z[1,5,1]  R1186     -5.0469082593917847e-01
    z[1,5,1]  R1187     7.7087897062301636e-01
    z[1,5,1]  R1188     7.6046824455261230e-01
    z[1,5,1]  R1189     7.8955745697021484e-01
    z[1,5,1]  R1190     2.1833692491054535e-01
    z[1,5,1]  R1191     7.0232802629470825e-01
    z[1,5,1]  R1192     8.7547320127487183e-01
    z[1,5,1]  R1193     8.5558646917343140e-01
    z[1,5,1]  R1194     7.4692708253860474e-01
    z[1,5,1]  R1195     7.0906698703765869e-01
    z[1,5,1]  R1196     6.2525153160095215e-01
    z[1,5,1]  R1197     6.2553548812866211e-01
    z[1,5,1]  R1198     4.2846208810806274e-01
    z[1,5,1]  R1199     6.0804325342178345e-01
    z[1,5,1]  R1200     2.9897719621658325e-01
    z[1,5,1]  R1201     6.6439443826675415e-01
    z[1,5,1]  R1202     -9.2065292596817017e-01
    z[1,5,1]  R1203     -9.4883036613464355e-01
    z[1,5,1]  R1204     -8.4418761730194092e-01
    z[1,5,1]  R1205     -8.5557991266250610e-01
    z[1,5,1]  R1206     -8.8591217994689941e-01
    z[1,5,1]  R1207     -8.5599416494369507e-01
    z[1,5,1]  R1208     -0.837941586971283
    z[1,5,1]  R1209     -8.3161729574203491e-01
    z[1,5,1]  R1210     -8.2682949304580688e-01
    z[1,5,1]  R1211     -8.9267814159393311e-01
    z[1,5,1]  R1212     -9.1890551149845123e-02
    z[1,5,1]  R1213     -1.7950126528739929e-01
    z[1,5,1]  R1214     3.0340716242790222e-01
    z[1,5,1]  R1215     2.9247373342514038e-01
    z[1,5,1]  R1216     1.9021998345851898e-01
    z[1,5,1]  R1217     2.6451054215431213e-01
    z[1,5,1]  R1218     1.7234939336776733e-01
    z[1,5,1]  R1219     4.5606139302253723e-01
    z[1,5,1]  R1220     3.7726444005966187e-01
    z[1,5,1]  R1221     -2.4689415469765663e-02
    z[1,5,1]  R1222     -1.1694305390119553e-01
    z[1,5,1]  R1223     -6.3666746020317078e-02
    z[1,5,1]  R1224     -5.9154576063156128e-01
    z[1,5,1]  R1225     7.1902751922607422e-02
    z[1,5,1]  R1226     -5.9003078937530518e-01
    z[1,5,1]  R1227     -5.4779714345932007e-01
    z[1,5,1]  R1228     -5.7059872150421143e-01
    z[1,5,1]  R1229     -6.3786470890045166e-01
    z[1,5,1]  R1230     -6.7252731323242188e-01
    z[1,5,1]  R1231     -6.6398131847381592e-01
    z[1,5,1]  R1232     4.1244527697563171e-01
    z[1,5,1]  R1233     2.9022064805030823e-01
    z[1,5,1]  R1234     0.279297411441803
    z[1,5,1]  R1235     -0.230604350566864
    z[1,5,1]  R1236     1.7475579679012299e-01
    z[1,5,1]  R1237     8.5760280489921570e-02
    z[1,5,1]  R1238     -3.2181721925735474e-01
    z[1,5,1]  R1239     -2.1566207706928253e-01
    z[1,5,1]  R1240     -3.5702559351921082e-01
    z[1,5,1]  R1241     -6.3930189609527588e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R1133     -1
    z[1,5,2]  R1134     1
    z[1,5,2]  R1143     7.8288090229034424e-01
    z[1,5,2]  R1144     6.9121789932250977e-01
    z[1,5,2]  R1145     2.7046054601669312e-01
    z[1,5,2]  R1146     -9.0173922479152679e-02
    z[1,5,2]  R1147     0.612095057964325
    z[1,5,2]  R1148     4.0137669444084167e-01
    z[1,5,2]  R1149     -2.8709178790450096e-02
    z[1,5,2]  R1150     -3.5165694355964661e-01
    z[1,5,2]  R1151     7.7848076820373535e-02
    z[1,5,2]  R1152     -2.6500681042671204e-01
    z[1,5,2]  R1153     -1.8514315783977509e-01
    z[1,5,2]  R1154     5.4202932119369507e-01
    z[1,5,2]  R1155     -1.2013711780309677e-01
    z[1,5,2]  R1156     3.0058783292770386e-01
    z[1,5,2]  R1157     -3.3320057392120361e-01
    z[1,5,2]  R1158     -2.3354759812355042e-01
    z[1,5,2]  R1159     -2.6625505089759827e-01
    z[1,5,2]  R1160     2.5235649943351746e-01
    z[1,5,2]  R1161     -1.5740875899791718e-01
    z[1,5,2]  R1162     2.9138955473899841e-01
    z[1,5,2]  R1163     2.7108547091484070e-01
    z[1,5,2]  R1164     4.9036440253257751e-01
    z[1,5,2]  R1165     3.1304258108139038e-01
    z[1,5,2]  R1166     3.3663868904113770e-01
    z[1,5,2]  R1167     -2.5620761513710022e-01
    z[1,5,2]  R1168     -3.8797748088836670e-01
    z[1,5,2]  R1169     -1.6617652773857117e-01
    z[1,5,2]  R1170     5.5452769994735718e-01
    z[1,5,2]  R1171     5.9412352740764618e-02
    z[1,5,2]  R1172     2.2869819402694702e-01
    z[1,5,2]  R1173     7.1511673927307129e-01
    z[1,5,2]  R1174     -2.6457920670509338e-01
    z[1,5,2]  R1175     4.2584562301635742e-01
    z[1,5,2]  R1176     -1.1458848416805267e-01
    z[1,5,2]  R1177     -6.1519676446914673e-01
    z[1,5,2]  R1178     -1.7192934453487396e-01
    z[1,5,2]  R1179     -2.2272443771362305e-01
    z[1,5,2]  R1180     -2.4329580366611481e-01
    z[1,5,2]  R1181     -2.7469378709793091e-01
    z[1,5,2]  R1182     1.3224802911281586e-02
    z[1,5,2]  R1183     -1.1340240389108658e-01
    z[1,5,2]  R1184     3.0671819113194942e-03
    z[1,5,2]  R1185     5.8155737817287445e-02
    z[1,5,2]  R1186     2.9615920782089233e-01
    z[1,5,2]  R1187     -0.0243210606276989
    z[1,5,2]  R1188     -3.4894734621047974e-01
    z[1,5,2]  R1189     -1.1464491486549377e-01
    z[1,5,2]  R1190     -6.2834733724594116e-01
    z[1,5,2]  R1191     -2.8288549184799194e-01
    z[1,5,2]  R1192     2.2204430401325226e-01
    z[1,5,2]  R1193     -6.9286718964576721e-02
    z[1,5,2]  R1194     1.0267228819429874e-02
    z[1,5,2]  R1195     -3.1002461910247803e-02
    z[1,5,2]  R1196     1.0819110274314880e-01
    z[1,5,2]  R1197     -3.7111940979957581e-01
    z[1,5,2]  R1198     7.5985920429229736e-01
    z[1,5,2]  R1199     -2.4186022579669952e-01
    z[1,5,2]  R1200     7.5410521030426025e-01
    z[1,5,2]  R1201     -4.7407627105712891e-01
    z[1,5,2]  R1202     2.6614934206008911e-01
    z[1,5,2]  R1203     -4.7693509608507156e-02
    z[1,5,2]  R1204     2.5060348212718964e-02
    z[1,5,2]  R1205     -2.1321940422058105e-01
    z[1,5,2]  R1206     0.201337531208992
    z[1,5,2]  R1207     -2.9549381136894226e-01
    z[1,5,2]  R1208     -1.6530798375606537e-01
    z[1,5,2]  R1209     0.0824781134724617
    z[1,5,2]  R1210     -6.8636782467365265e-02
    z[1,5,2]  R1211     1.6016195714473724e-01
    z[1,5,2]  R1212     -4.8945721983909607e-01
    z[1,5,2]  R1213     5.1430130004882812e-01
    z[1,5,2]  R1214     3.4037387371063232e-01
    z[1,5,2]  R1215     -8.9806658029556274e-01
    z[1,5,2]  R1216     -0.0916375145316124
    z[1,5,2]  R1217     3.0163705348968506e-02
    z[1,5,2]  R1218     -4.7916686534881592e-01
    z[1,5,2]  R1219     -1.5109807252883911e-01
    z[1,5,2]  R1220     -3.7307778000831604e-01
    z[1,5,2]  R1221     -9.4032082706689835e-03
    z[1,5,2]  R1222     8.0027438700199127e-02
    z[1,5,2]  R1223     -5.8725923299789429e-02
    z[1,5,2]  R1224     1.0964184254407883e-01
    z[1,5,2]  R1225     -7.3334950208663940e-01
    z[1,5,2]  R1226     4.0528017282485962e-01
    z[1,5,2]  R1227     0.284252792596817
    z[1,5,2]  R1228     3.6815294623374939e-01
    z[1,5,2]  R1229     1.5899296104907990e-01
    z[1,5,2]  R1230     4.2180046439170837e-01
    z[1,5,2]  R1231     4.2704778909683228e-01
    z[1,5,2]  R1232     -5.3261661529541016e-01
    z[1,5,2]  R1233     -4.9754548072814941e-01
    z[1,5,2]  R1234     4.1682365536689758e-01
    z[1,5,2]  R1235     -9.4092383980751038e-02
    z[1,5,2]  R1236     6.6872701048851013e-02
    z[1,5,2]  R1237     5.3215879201889038e-01
    z[1,5,2]  R1238     4.9683311581611633e-01
    z[1,5,2]  R1239     4.9082070589065552e-01
    z[1,5,2]  R1240     6.5681940317153931e-01
    z[1,5,2]  R1241     6.7451059818267822e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R1135     -1
    z[1,5,3]  R1136     1
    z[1,5,3]  R1143     -1.3675062358379364e-01
    z[1,5,3]  R1144     -1.2978547811508179e-01
    z[1,5,3]  R1145     -2.1833953261375427e-01
    z[1,5,3]  R1146     -0.192160502076149
    z[1,5,3]  R1147     2.3703585565090179e-01
    z[1,5,3]  R1148     1.8773065507411957e-01
    z[1,5,3]  R1149     4.6362329274415970e-02
    z[1,5,3]  R1150     -1.2510886788368225e-01
    z[1,5,3]  R1151     -1.6061370074748993e-01
    z[1,5,3]  R1152     -2.4646823108196259e-01
    z[1,5,3]  R1153     -6.7244774103164673e-01
    z[1,5,3]  R1154     -3.4394088387489319e-01
    z[1,5,3]  R1155     1.5020883083343506e-01
    z[1,5,3]  R1156     1.7196573317050934e-01
    z[1,5,3]  R1157     -3.5162393003702164e-02
    z[1,5,3]  R1158     -3.5772061347961426e-01
    z[1,5,3]  R1159     -0.360651433467865
    z[1,5,3]  R1160     1.1904857121407986e-02
    z[1,5,3]  R1161     1.0218356549739838e-01
    z[1,5,3]  R1162     7.6278068125247955e-02
    z[1,5,3]  R1163     -1.2785153090953827e-01
    z[1,5,3]  R1164     -3.0141493678092957e-01
    z[1,5,3]  R1165     3.7640803493559361e-03
    z[1,5,3]  R1166     4.3715375661849976e-01
    z[1,5,3]  R1167     5.1293814182281494e-01
    z[1,5,3]  R1168     1.5632462501525879e-01
    z[1,5,3]  R1169     6.3311499357223511e-01
    z[1,5,3]  R1170     -5.8447301387786865e-01
    z[1,5,3]  R1171     -2.7181667089462280e-01
    z[1,5,3]  R1172     -7.3082715272903442e-02
    z[1,5,3]  R1173     -3.0466508865356445e-01
    z[1,5,3]  R1174     -1.4586928486824036e-01
    z[1,5,3]  R1175     -3.5448685288429260e-01
    z[1,5,3]  R1176     5.7399606704711914e-01
    z[1,5,3]  R1177     -5.2418279647827148e-01
    z[1,5,3]  R1178     -0.277119517326355
    z[1,5,3]  R1179     -1.5559767186641693e-01
    z[1,5,3]  R1180     -4.8624446988105774e-01
    z[1,5,3]  R1181     -1.8034832552075386e-02
    z[1,5,3]  R1182     3.2120910286903381e-01
    z[1,5,3]  R1183     2.6803153753280640e-01
    z[1,5,3]  R1184     -4.8867025971412659e-01
    z[1,5,3]  R1185     -7.2287283837795258e-02
    z[1,5,3]  R1186     5.6514286994934082e-01
    z[1,5,3]  R1187     2.9438361525535583e-01
    z[1,5,3]  R1188     8.9321218430995941e-02
    z[1,5,3]  R1189     1.5312604606151581e-02
    z[1,5,3]  R1190     -0.288524866104126
    z[1,5,3]  R1191     0.1168212890625
    z[1,5,3]  R1192     -1.7188473045825958e-01
    z[1,5,3]  R1193     1.8126615881919861e-01
    z[1,5,3]  R1194     4.3439182639122009e-01
    z[1,5,3]  R1195     -1.2478467077016830e-01
    z[1,5,3]  R1196     1.9832178950309753e-01
    z[1,5,3]  R1197     4.3204563856124878e-01
    z[1,5,3]  R1198     1.1489140801131725e-02
    z[1,5,3]  R1199     -4.0967710316181183e-02
    z[1,5,3]  R1200     4.8574271798133850e-01
    z[1,5,3]  R1201     -4.3506991118192673e-02
    z[1,5,3]  R1202     -4.6891830861568451e-02
    z[1,5,3]  R1203     -2.8363440185785294e-02
    z[1,5,3]  R1204     1.3611934147775173e-02
    z[1,5,3]  R1205     -0.0231669619679451
    z[1,5,3]  R1206     2.2896258533000946e-01
    z[1,5,3]  R1207     3.4761503338813782e-01
    z[1,5,3]  R1208     2.6514670252799988e-01
    z[1,5,3]  R1209     1.0575447231531143e-01
    z[1,5,3]  R1210     4.9875143170356750e-01
    z[1,5,3]  R1211     7.5762018561363220e-02
    z[1,5,3]  R1212     -2.3659074306488037e-01
    z[1,5,3]  R1213     -2.6496499776840210e-01
    z[1,5,3]  R1214     -1.8247883021831512e-01
    z[1,5,3]  R1215     -2.2330953180789948e-01
    z[1,5,3]  R1216     -1.5001441538333893e-01
    z[1,5,3]  R1217     -4.4930616021156311e-01
    z[1,5,3]  R1218     -2.6776903867721558e-01
    z[1,5,3]  R1219     9.8131135106086731e-02
    z[1,5,3]  R1220     -2.6228803396224976e-01
    z[1,5,3]  R1221     -1.6434629261493683e-01
    z[1,5,3]  R1222     -6.9557195901870728e-01
    z[1,5,3]  R1223     -0.846520185470581
    z[1,5,3]  R1224     -4.7702023386955261e-01
    z[1,5,3]  R1225     -4.8704613000154495e-02
    z[1,5,3]  R1226     -1.0013290494680405e-01
    z[1,5,3]  R1227     -9.7566343843936920e-02
    z[1,5,3]  R1228     -8.4781445562839508e-02
    z[1,5,3]  R1229     -0.349507600069046
    z[1,5,3]  R1230     -4.1402030736207962e-02
    z[1,5,3]  R1231     1.7861567437648773e-01
    z[1,5,3]  R1232     -4.2533260583877563e-01
    z[1,5,3]  R1233     -2.0311589539051056e-01
    z[1,5,3]  R1234     -2.9586234688758850e-01
    z[1,5,3]  R1235     1.5119914710521698e-01
    z[1,5,3]  R1236     -4.7901135683059692e-01
    z[1,5,3]  R1237     -7.7033668756484985e-01
    z[1,5,3]  R1238     -5.8633148670196533e-01
    z[1,5,3]  R1239     -2.6660934090614319e-01
    z[1,5,3]  R1240     1.6089810431003571e-01
    z[1,5,3]  R1241     3.4706801176071167e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R1137     -1
    z[1,5,4]  R1138     1
    z[1,5,4]  R1143     3.7444502115249634e-01
    z[1,5,4]  R1144     4.6636760234832764e-01
    z[1,5,4]  R1145     7.1435712277889252e-02
    z[1,5,4]  R1146     3.0189543962478638e-01
    z[1,5,4]  R1147     4.6917036175727844e-01
    z[1,5,4]  R1148     -6.2298811972141266e-02
    z[1,5,4]  R1149     1.1157064139842987e-01
    z[1,5,4]  R1150     1.7434763908386230e-01
    z[1,5,4]  R1151     0.265186071395874
    z[1,5,4]  R1152     8.1869371235370636e-02
    z[1,5,4]  R1153     -0.0295050460845232
    z[1,5,4]  R1154     4.1165456175804138e-02
    z[1,5,4]  R1155     1.4436149597167969e-01
    z[1,5,4]  R1156     -7.9460576176643372e-02
    z[1,5,4]  R1157     7.5569534301757812e-01
    z[1,5,4]  R1158     -5.1839772611856461e-02
    z[1,5,4]  R1159     1.8890835344791412e-01
    z[1,5,4]  R1160     -2.3591178655624390e-01
    z[1,5,4]  R1161     -3.0672883987426758e-01
    z[1,5,4]  R1162     -1.2151244282722473e-01
    z[1,5,4]  R1163     -4.5494616031646729e-01
    z[1,5,4]  R1164     -5.7108914852142334e-01
    z[1,5,4]  R1165     -1.4176666736602783e-01
    z[1,5,4]  R1166     -3.3100968599319458e-01
    z[1,5,4]  R1167     1.0167949646711349e-01
    z[1,5,4]  R1168     -3.1500551104545593e-01
    z[1,5,4]  R1169     -2.4191634356975555e-01
    z[1,5,4]  R1170     -2.6066654920578003e-01
    z[1,5,4]  R1171     4.7065809369087219e-02
    z[1,5,4]  R1172     -2.2838643193244934e-01
    z[1,5,4]  R1173     -1.7407071590423584e-01
    z[1,5,4]  R1174     1.1996034532785416e-01
    z[1,5,4]  R1175     3.4921982884407043e-01
    z[1,5,4]  R1176     1.6590552031993866e-01
    z[1,5,4]  R1177     3.6356106400489807e-01
    z[1,5,4]  R1178     0.567359983921051
    z[1,5,4]  R1179     -4.1081428527832031e-01
    z[1,5,4]  R1180     -2.4256144464015961e-01
    z[1,5,4]  R1181     -6.1225313693284988e-02
    z[1,5,4]  R1182     -2.1430957317352295e-01
    z[1,5,4]  R1183     -3.9447724819183350e-01
    z[1,5,4]  R1184     -1.9413267076015472e-01
    z[1,5,4]  R1185     5.8033210039138794e-01
    z[1,5,4]  R1186     -3.3854478597640991e-01
    z[1,5,4]  R1187     -2.6605397462844849e-01
    z[1,5,4]  R1188     -1.3745093345642090e-01
    z[1,5,4]  R1189     6.3053965568542480e-02
    z[1,5,4]  R1190     2.9617384076118469e-01
    z[1,5,4]  R1191     1.8876156210899353e-01
    z[1,5,4]  R1192     2.3010133206844330e-01
    z[1,5,4]  R1193     3.4058505296707153e-01
    z[1,5,4]  R1194     1.6457255184650421e-01
    z[1,5,4]  R1195     1.1215513199567795e-01
    z[1,5,4]  R1196     2.1339850500226021e-03
    z[1,5,4]  R1197     2.0488698035478592e-02
    z[1,5,4]  R1198     1.5322379767894745e-02
    z[1,5,4]  R1199     6.2139028310775757e-01
    z[1,5,4]  R1200     4.9387805163860321e-02
    z[1,5,4]  R1201     1.4650250971317291e-01
    z[1,5,4]  R1202     -1.3256011903285980e-01
    z[1,5,4]  R1203     3.7601027637720108e-02
    z[1,5,4]  R1204     -3.1871777772903442e-01
    z[1,5,4]  R1205     2.6871031522750854e-01
    z[1,5,4]  R1206     4.8271864652633667e-02
    z[1,5,4]  R1207     2.1161170303821564e-01
    z[1,5,4]  R1208     -3.2673040404915810e-03
    z[1,5,4]  R1209     0.360588401556015
    z[1,5,4]  R1210     0.0846773162484169
    z[1,5,4]  R1211     0.078289695084095
    z[1,5,4]  R1212     -2.1471163630485535e-01
    z[1,5,4]  R1213     4.7779548168182373e-01
    z[1,5,4]  R1214     -1.5561152994632721e-01
    z[1,5,4]  R1215     6.5029174089431763e-02
    z[1,5,4]  R1216     -5.4568547010421753e-01
    z[1,5,4]  R1217     -2.0039555430412292e-01
    z[1,5,4]  R1218     -6.9484390318393707e-02
    z[1,5,4]  R1219     -3.6225995421409607e-01
    z[1,5,4]  R1220     -3.3178317546844482e-01
    z[1,5,4]  R1221     -4.5058351755142212e-01
    z[1,5,4]  R1222     -1.4191937446594238e-01
    z[1,5,4]  R1223     -3.5129639506340027e-01
    z[1,5,4]  R1224     -2.0226357877254486e-01
    z[1,5,4]  R1225     -1.7484459280967712e-01
    z[1,5,4]  R1226     -2.4712309241294861e-01
    z[1,5,4]  R1227     -1.8820452690124512e-01
    z[1,5,4]  R1228     -7.1713291108608246e-02
    z[1,5,4]  R1229     -3.2527527213096619e-01
    z[1,5,4]  R1230     -3.5218662023544312e-01
    z[1,5,4]  R1231     0.144295796751976
    z[1,5,4]  R1232     -3.9359182119369507e-01
    z[1,5,4]  R1233     5.1760542392730713e-01
    z[1,5,4]  R1234     6.9337749481201172e-01
    z[1,5,4]  R1235     3.5283794999122620e-01
    z[1,5,4]  R1236     5.1066315174102783e-01
    z[1,5,4]  R1237     -2.9012659192085266e-01
    z[1,5,4]  R1238     -1.2565696239471436e-01
    z[1,5,4]  R1239     -2.2074703872203827e-01
    z[1,5,4]  R1240     2.0937354862689972e-01
    z[1,5,4]  R1241     -5.6084852665662766e-02
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R1139     -1
    z[1,5,5]  R1140     1
    z[1,5,5]  R1143     1.8587511777877808e-01
    z[1,5,5]  R1144     -1.4139805734157562e-01
    z[1,5,5]  R1145     4.5469993352890015e-01
    z[1,5,5]  R1146     8.6127929389476776e-02
    z[1,5,5]  R1147     0.0432896763086319
    z[1,5,5]  R1148     7.2182303667068481e-01
    z[1,5,5]  R1149     5.4944694042205811e-01
    z[1,5,5]  R1150     5.7868117094039917e-01
    z[1,5,5]  R1151     -0.176085963845253
    z[1,5,5]  R1152     -1.6225415468215942e-01
    z[1,5,5]  R1153     -2.5128121487796307e-03
    z[1,5,5]  R1154     6.8202703259885311e-03
    z[1,5,5]  R1155     2.7587673068046570e-01
    z[1,5,5]  R1156     -1.8212584778666496e-02
    z[1,5,5]  R1157     3.5121780633926392e-01
    z[1,5,5]  R1158     -4.2768475413322449e-01
    z[1,5,5]  R1159     1.0120529681444168e-01
    z[1,5,5]  R1160     -7.2193038463592529e-01
    z[1,5,5]  R1161     -8.1432253122329712e-02
    z[1,5,5]  R1162     -1.8198329210281372e-01
    z[1,5,5]  R1163     -6.8062287569046021e-01
    z[1,5,5]  R1164     -4.0630817413330078e-01
    z[1,5,5]  R1165     -4.6032306551933289e-01
    z[1,5,5]  R1166     -1.7219726741313934e-01
    z[1,5,5]  R1167     -0.430600643157959
    z[1,5,5]  R1168     -5.0054562091827393e-01
    z[1,5,5]  R1169     5.8270907029509544e-03
    z[1,5,5]  R1170     2.9229742288589478e-01
    z[1,5,5]  R1171     6.6445773839950562e-01
    z[1,5,5]  R1172     2.1083930134773254e-01
    z[1,5,5]  R1173     2.4733105301856995e-01
    z[1,5,5]  R1174     4.7527906298637390e-01
    z[1,5,5]  R1175     5.6023615598678589e-01
    z[1,5,5]  R1176     -2.4616421759128571e-01
    z[1,5,5]  R1177     3.7608388066291809e-01
    z[1,5,5]  R1178     1.9763027131557465e-01
    z[1,5,5]  R1179     -3.1555801630020142e-01
    z[1,5,5]  R1180     1.6353559494018555e-01
    z[1,5,5]  R1181     -1.9240470230579376e-01
    z[1,5,5]  R1182     0.129002645611763
    z[1,5,5]  R1183     5.4752331972122192e-01
    z[1,5,5]  R1184     7.5934166088700294e-03
    z[1,5,5]  R1185     3.3185136318206787e-01
    z[1,5,5]  R1186     1.9408319890499115e-01
    z[1,5,5]  R1187     -1.7621102929115295e-01
    z[1,5,5]  R1188     -7.7011808753013611e-02
    z[1,5,5]  R1189     -1.5127140283584595e-01
    z[1,5,5]  R1190     -4.7354641556739807e-01
    z[1,5,5]  R1191     1.2884079478681087e-02
    z[1,5,5]  R1192     1.6349695622920990e-02
    z[1,5,5]  R1193     4.0406482294201851e-03
    z[1,5,5]  R1194     -2.8824573755264282e-01
    z[1,5,5]  R1195     6.4108437299728394e-01
    z[1,5,5]  R1196     2.6808005571365356e-01
    z[1,5,5]  R1197     3.5143008828163147e-01
    z[1,5,5]  R1198     -1.1392273753881454e-01
    z[1,5,5]  R1199     2.9049047827720642e-01
    z[1,5,5]  R1200     1.9229158759117126e-01
    z[1,5,5]  R1201     -1.3685730099678040e-01
    z[1,5,5]  R1202     2.3453648388385773e-01
    z[1,5,5]  R1203     -0.155681312084198
    z[1,5,5]  R1204     -2.1839885041117668e-02
    z[1,5,5]  R1205     1.5839838981628418e-01
    z[1,5,5]  R1206     9.0267747640609741e-02
    z[1,5,5]  R1207     1.0915318131446838e-01
    z[1,5,5]  R1208     2.9655680060386658e-01
    z[1,5,5]  R1209     1.3262277841567993e-01
    z[1,5,5]  R1210     -0.0666360929608345
    z[1,5,5]  R1211     -2.6828205585479736e-01
    z[1,5,5]  R1212     2.8831627964973450e-01
    z[1,5,5]  R1213     6.0940408706665039e-01
    z[1,5,5]  R1214     -2.6306754350662231e-01
    z[1,5,5]  R1215     3.0098492279648781e-03
    z[1,5,5]  R1216     1.1404132843017578e-01
    z[1,5,5]  R1217     -3.3031675219535828e-01
    z[1,5,5]  R1218     -2.3639994859695435e-01
    z[1,5,5]  R1219     -1.1001867055892944e-01
    z[1,5,5]  R1220     -3.6067163944244385e-01
    z[1,5,5]  R1221     5.5549168586730957e-01
    z[1,5,5]  R1222     3.3442208170890808e-01
    z[1,5,5]  R1223     2.1022740006446838e-01
    z[1,5,5]  R1224     4.3663203716278076e-01
    z[1,5,5]  R1225     5.2558046579360962e-01
    z[1,5,5]  R1226     3.7022992968559265e-01
    z[1,5,5]  R1227     2.5225467979907990e-02
    z[1,5,5]  R1228     2.4903084337711334e-01
    z[1,5,5]  R1229     5.6108510494232178e-01
    z[1,5,5]  R1230     1.4927624724805355e-02
    z[1,5,5]  R1231     9.7732760012149811e-02
    z[1,5,5]  R1232     2.3926517367362976e-01
    z[1,5,5]  R1233     1.5449105203151703e-01
    z[1,5,5]  R1234     -6.4368017017841339e-02
    z[1,5,5]  R1235     6.5900111198425293e-01
    z[1,5,5]  R1236     -1.0784979909658432e-01
    z[1,5,5]  R1237     1.7631146311759949e-01
    z[1,5,5]  R1238     0.00893962662667036
    z[1,5,5]  R1239     5.4915450513362885e-02
    z[1,5,5]  R1240     -2.6482370495796204e-01
    z[1,5,5]  R1241     0.0788489356637001
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R1141     -1
    z[1,5,6]  R1142     1
    z[1,5,6]  R1143     2.8560683131217957e-01
    z[1,5,6]  R1144     3.9391836524009705e-01
    z[1,5,6]  R1145     7.0469003915786743e-01
    z[1,5,6]  R1146     7.5557726621627808e-01
    z[1,5,6]  R1147     -3.5521391034126282e-01
    z[1,5,6]  R1148     -3.6219093948602676e-02
    z[1,5,6]  R1149     -3.3626472949981689e-01
    z[1,5,6]  R1150     -1.1651092767715454e-01
    z[1,5,6]  R1151     1.8766130506992340e-01
    z[1,5,6]  R1152     2.1053564548492432e-01
    z[1,5,6]  R1153     -1.6096076369285583e-01
    z[1,5,6]  R1154     2.3172810673713684e-01
    z[1,5,6]  R1155     4.1252526640892029e-01
    z[1,5,6]  R1156     -1.9073310494422913e-01
    z[1,5,6]  R1157     -1.2972231209278107e-01
    z[1,5,6]  R1158     -5.2020758390426636e-01
    z[1,5,6]  R1159     -7.9890716075897217e-01
    z[1,5,6]  R1160     -4.0473058819770813e-01
    z[1,5,6]  R1161     -3.6321204900741577e-01
    z[1,5,6]  R1162     -5.4574948549270630e-01
    z[1,5,6]  R1163     6.5559722483158112e-02
    z[1,5,6]  R1164     3.6005118489265442e-01
    z[1,5,6]  R1165     -4.5117178559303284e-01
    z[1,5,6]  R1166     -5.4073441028594971e-01
    z[1,5,6]  R1167     1.2992599513381720e-03
    z[1,5,6]  R1168     2.1642138063907623e-01
    z[1,5,6]  R1169     3.4340581297874451e-01
    z[1,5,6]  R1170     -3.2740628719329834e-01
    z[1,5,6]  R1171     -6.2006378173828125e-01
    z[1,5,6]  R1172     2.7123183012008667e-01
    z[1,5,6]  R1173     -4.2300187051296234e-02
    z[1,5,6]  R1174     1.2370651215314865e-01
    z[1,5,6]  R1175     -4.7015976905822754e-01
    z[1,5,6]  R1176     3.4981733560562134e-01
    z[1,5,6]  R1177     -7.3354914784431458e-02
    z[1,5,6]  R1178     -2.4641756713390350e-01
    z[1,5,6]  R1179     -2.3655369877815247e-02
    z[1,5,6]  R1180     4.4243231415748596e-02
    z[1,5,6]  R1181     -2.6326501369476318e-01
    z[1,5,6]  R1182     -6.7819356918334961e-02
    z[1,5,6]  R1183     -5.0240176916122437e-01
    z[1,5,6]  R1184     -2.6337611675262451e-01
    z[1,5,6]  R1185     -3.5471022129058838e-02
    z[1,5,6]  R1186     1.9848808646202087e-01
    z[1,5,6]  R1187     -6.9091357290744781e-02
    z[1,5,6]  R1188     3.4583261609077454e-01
    z[1,5,6]  R1189     1.0074346512556076e-01
    z[1,5,6]  R1190     2.9694160819053650e-01
    z[1,5,6]  R1191     2.5770869851112366e-01
    z[1,5,6]  R1192     3.0506783723831177e-01
    z[1,5,6]  R1193     -1.6707411408424377e-01
    z[1,5,6]  R1194     -1.4030157029628754e-01
    z[1,5,6]  R1195     -1.5614232420921326e-01
    z[1,5,6]  R1196     -6.9573158025741577e-01
    z[1,5,6]  R1197     3.9206331968307495e-01
    z[1,5,6]  R1198     -4.4810160994529724e-01
    z[1,5,6]  R1199     -1.3658446073532104e-01
    z[1,5,6]  R1200     6.9953277707099915e-03
    z[1,5,6]  R1201     -4.5238631963729858e-01
    z[1,5,6]  R1202     -1.8078187480568886e-02
    z[1,5,6]  R1203     3.6166332662105560e-02
    z[1,5,6]  R1204     -4.2214909195899963e-01
    z[1,5,6]  R1205     3.2443445920944214e-01
    z[1,5,6]  R1206     -1.1246681213378906e-02
    z[1,5,6]  R1207     0.0382811576128006
    z[1,5,6]  R1208     -2.4132886528968811e-01
    z[1,5,6]  R1209     -3.7785002589225769e-01
    z[1,5,6]  R1210     -1.8799139559268951e-01
    z[1,5,6]  R1211     -4.2002037167549133e-02
    z[1,5,6]  R1212     4.2526909708976746e-01
    z[1,5,6]  R1213     1.3504503667354584e-01
    z[1,5,6]  R1214     3.2356211543083191e-01
    z[1,5,6]  R1215     1.5062689781188965e-01
    z[1,5,6]  R1216     -1.1830971390008926e-01
    z[1,5,6]  R1217     5.9109228849411011e-01
    z[1,5,6]  R1218     6.6986465454101562e-01
    z[1,5,6]  R1219     -2.7612483501434326e-01
    z[1,5,6]  R1220     3.7648779153823853e-01
    z[1,5,6]  R1221     -4.1460883617401123e-01
    z[1,5,6]  R1222     -7.3883078992366791e-02
    z[1,5,6]  R1223     2.6690849661827087e-01
    z[1,5,6]  R1224     2.3986613750457764e-01
    z[1,5,6]  R1225     -0.35416179895401
    z[1,5,6]  R1226     6.2710128724575043e-02
    z[1,5,6]  R1227     -6.3965469598770142e-02
    z[1,5,6]  R1228     -1.5120127797126770e-01
    z[1,5,6]  R1229     1.5688399970531464e-01
    z[1,5,6]  R1230     8.8956616818904877e-03
    z[1,5,6]  R1231     8.6626596748828888e-02
    z[1,5,6]  R1232     -2.4196162819862366e-01
    z[1,5,6]  R1233     -3.4563142806291580e-02
    z[1,5,6]  R1234     2.7168050408363342e-01
    z[1,5,6]  R1235     1.4697673916816711e-01
    z[1,5,6]  R1236     6.4747321605682373e-01
    z[1,5,6]  R1237     6.5576941706240177e-03
    z[1,5,6]  R1238     5.0558692216873169e-01
    z[1,5,6]  R1239     2.6151040196418762e-01
    z[1,5,6]  R1240     1.1140928417444229e-01
    z[1,5,6]  R1241     -3.5501249134540558e-02
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R1242     -1
    z[5,1,0]  R1243     1
    z[5,1,0]  R1256     9.1751128435134888e-02
    z[5,1,0]  R1257     -2.9391407966613770e-01
    z[5,1,0]  R1258     3.5134589672088623e-01
    z[5,1,0]  R1259     1.8095086514949799e-01
    z[5,1,0]  R1260     4.5932576060295105e-02
    z[5,1,0]  R1261     0.0817050188779831
    z[5,1,0]  R1262     1.5777802467346191e-01
    z[5,1,0]  R1263     -2.8450459241867065e-01
    z[5,1,0]  R1264     -2.5793009996414185e-01
    z[5,1,0]  R1265     2.9511460661888123e-01
    z[5,1,0]  R1266     -8.0357983708381653e-02
    z[5,1,0]  R1267     -2.6397609710693359e-01
    z[5,1,0]  R1268     -7.9158611595630646e-02
    z[5,1,0]  R1269     -1.3939459621906281e-01
    z[5,1,0]  R1270     3.3405673503875732e-01
    z[5,1,0]  R1271     -3.1011231243610382e-02
    z[5,1,0]  R1272     -2.3243987560272217e-01
    z[5,1,0]  R1273     6.5164053812623024e-03
    z[5,1,0]  R1274     -1.2624450027942657e-01
    z[5,1,0]  R1275     3.0309295654296875e-01
    z[5,1,0]  R1276     -6.2123370170593262e-01
    z[5,1,0]  R1277     -1.2315837293863297e-01
    z[5,1,0]  R1278     -7.4878519773483276e-01
    z[5,1,0]  R1279     1.7647108435630798e-01
    z[5,1,0]  R1280     -7.7983301877975464e-01
    z[5,1,0]  R1281     -4.7811153531074524e-01
    z[5,1,0]  R1282     -3.9945331215858459e-01
    z[5,1,0]  R1283     -7.3482406139373779e-01
    z[5,1,0]  R1284     -5.1747697591781616e-01
    z[5,1,0]  R1285     -5.3739684820175171e-01
    z[5,1,0]  R1286     5.9888356924057007e-01
    z[5,1,0]  R1287     1.9250044226646423e-01
    z[5,1,0]  R1288     3.4843954443931580e-01
    z[5,1,0]  R1289     -1.4973483979701996e-01
    z[5,1,0]  R1290     5.2489286661148071e-01
    z[5,1,0]  R1291     7.5461953878402710e-01
    z[5,1,0]  R1292     6.6458392143249512e-01
    z[5,1,0]  R1293     -2.1477121859788895e-02
    z[5,1,0]  R1294     0.493700236082077
    z[5,1,0]  R1295     5.5405634641647339e-01
    z[5,1,0]  R1296     -3.0755949020385742e-01
    z[5,1,0]  R1297     5.7791608572006226e-01
    z[5,1,0]  R1298     3.1935986876487732e-01
    z[5,1,0]  R1299     -5.7855671644210815e-01
    z[5,1,0]  R1300     2.0953913033008575e-01
    z[5,1,0]  R1301     2.7045177295804024e-02
    z[5,1,0]  R1302     1.8525169789791107e-01
    z[5,1,0]  R1303     7.2206068038940430e-01
    z[5,1,0]  R1304     0.537449300289154
    z[5,1,0]  R1305     7.2452224791049957e-02
    z[5,1,0]  R1306     -2.3927323520183563e-01
    z[5,1,0]  R1307     -9.3068093061447144e-02
    z[5,1,0]  R1308     -1.8396428227424622e-01
    z[5,1,0]  R1309     1.1003871262073517e-01
    z[5,1,0]  R1310     -4.2539175599813461e-02
    z[5,1,0]  R1311     -3.0694505572319031e-01
    z[5,1,0]  R1312     2.3849646747112274e-01
    z[5,1,0]  R1313     -2.5389662384986877e-01
    z[5,1,0]  R1314     -3.2029229402542114e-01
    z[5,1,0]  R1315     -1.6619090735912323e-01
    z[5,1,0]  R1316     6.6466385126113892e-01
    z[5,1,0]  R1317     -4.7198975086212158e-01
    z[5,1,0]  R1318     -7.8905403614044189e-01
    z[5,1,0]  R1319     -0.89189612865448
    z[5,1,0]  R1320     -3.1033545732498169e-01
    z[5,1,0]  R1321     -5.1954627037048340e-01
    z[5,1,0]  R1322     -3.0689609050750732e-01
    z[5,1,0]  R1323     3.9101323485374451e-01
    z[5,1,0]  R1324     -2.4056018888950348e-01
    z[5,1,0]  R1325     -2.3183842003345490e-01
    z[5,1,0]  R1326     3.5448500514030457e-01
    z[5,1,0]  R1327     1.2213188409805298e-01
    z[5,1,0]  R1328     4.4516941905021667e-01
    z[5,1,0]  R1329     7.5336650013923645e-02
    z[5,1,0]  R1330     2.0835784077644348e-01
    z[5,1,0]  R1331     3.7897145748138428e-01
    z[5,1,0]  R1332     -2.0715612173080444e-01
    z[5,1,0]  R1333     6.3558273017406464e-02
    z[5,1,0]  R1334     1.4043904957361519e-04
    z[5,1,0]  R1335     -5.2889108657836914e-01
    z[5,1,0]  R1336     0.124534472823143
    z[5,1,0]  R1337     3.2512968778610229e-01
    z[5,1,0]  R1338     1.2217810004949570e-01
    z[5,1,0]  R1339     -0.0638943687081337
    z[5,1,0]  R1340     3.9143315516412258e-03
    z[5,1,0]  R1341     -5.3495984524488449e-02
    z[5,1,0]  R1342     -6.1061024665832520e-01
    z[5,1,0]  R1343     -3.2372646033763885e-02
    z[5,1,0]  R1344     -1.4620240032672882e-01
    z[5,1,0]  R1345     -5.6994175910949707e-01
    z[5,1,0]  R1346     5.4328281432390213e-02
    z[5,1,0]  R1347     -7.7049273252487183e-01
    z[5,1,0]  R1348     -3.6872324347496033e-01
    z[5,1,0]  R1349     -3.8276901841163635e-01
    z[5,1,0]  R1350     -0.460308313369751
    z[5,1,0]  R1351     -3.8408553600311279e-01
    z[5,1,0]  R1352     5.7115048170089722e-01
    z[5,1,0]  R1353     -2.7225458621978760e-01
    z[5,1,0]  R1354     5.5754220485687256e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R1244     -1
    z[5,1,1]  R1245     1
    z[5,1,1]  R1256     8.7547320127487183e-01
    z[5,1,1]  R1257     8.5558646917343140e-01
    z[5,1,1]  R1258     7.4692708253860474e-01
    z[5,1,1]  R1259     7.0906698703765869e-01
    z[5,1,1]  R1260     6.2525153160095215e-01
    z[5,1,1]  R1261     6.2553548812866211e-01
    z[5,1,1]  R1262     4.2846208810806274e-01
    z[5,1,1]  R1263     6.0804325342178345e-01
    z[5,1,1]  R1264     2.9897719621658325e-01
    z[5,1,1]  R1265     6.6439443826675415e-01
    z[5,1,1]  R1266     -9.2065292596817017e-01
    z[5,1,1]  R1267     -9.4883036613464355e-01
    z[5,1,1]  R1268     -8.4418761730194092e-01
    z[5,1,1]  R1269     -8.5557991266250610e-01
    z[5,1,1]  R1270     -8.8591217994689941e-01
    z[5,1,1]  R1271     -8.5599416494369507e-01
    z[5,1,1]  R1272     -0.837941586971283
    z[5,1,1]  R1273     -8.3161729574203491e-01
    z[5,1,1]  R1274     -8.2682949304580688e-01
    z[5,1,1]  R1275     -8.9267814159393311e-01
    z[5,1,1]  R1276     -9.1890551149845123e-02
    z[5,1,1]  R1277     -1.7950126528739929e-01
    z[5,1,1]  R1278     3.0340716242790222e-01
    z[5,1,1]  R1279     2.9247373342514038e-01
    z[5,1,1]  R1280     1.9021998345851898e-01
    z[5,1,1]  R1281     2.6451054215431213e-01
    z[5,1,1]  R1282     1.7234939336776733e-01
    z[5,1,1]  R1283     4.5606139302253723e-01
    z[5,1,1]  R1284     3.7726444005966187e-01
    z[5,1,1]  R1285     -2.4689415469765663e-02
    z[5,1,1]  R1286     -1.1694305390119553e-01
    z[5,1,1]  R1287     -6.3666746020317078e-02
    z[5,1,1]  R1288     -5.9154576063156128e-01
    z[5,1,1]  R1289     7.1902751922607422e-02
    z[5,1,1]  R1290     -5.9003078937530518e-01
    z[5,1,1]  R1291     -5.4779714345932007e-01
    z[5,1,1]  R1292     -5.7059872150421143e-01
    z[5,1,1]  R1293     -6.3786470890045166e-01
    z[5,1,1]  R1294     -6.7252731323242188e-01
    z[5,1,1]  R1295     -6.6398131847381592e-01
    z[5,1,1]  R1296     4.1244527697563171e-01
    z[5,1,1]  R1297     2.9022064805030823e-01
    z[5,1,1]  R1298     0.279297411441803
    z[5,1,1]  R1299     -0.230604350566864
    z[5,1,1]  R1300     1.7475579679012299e-01
    z[5,1,1]  R1301     8.5760280489921570e-02
    z[5,1,1]  R1302     -3.2181721925735474e-01
    z[5,1,1]  R1303     -2.1566207706928253e-01
    z[5,1,1]  R1304     -3.5702559351921082e-01
    z[5,1,1]  R1305     -6.3930189609527588e-01
    z[5,1,1]  R1306     -2.3412662744522095e-01
    z[5,1,1]  R1307     -3.2256475090980530e-01
    z[5,1,1]  R1308     -3.6999046802520752e-01
    z[5,1,1]  R1309     -5.2285623550415039e-01
    z[5,1,1]  R1310     -4.6815851330757141e-01
    z[5,1,1]  R1311     -4.2803874611854553e-01
    z[5,1,1]  R1312     -7.1605294942855835e-01
    z[5,1,1]  R1313     6.4604789018630981e-01
    z[5,1,1]  R1314     8.5382020473480225e-01
    z[5,1,1]  R1315     8.7410008907318115e-01
    z[5,1,1]  R1316     -2.1206778287887573e-01
    z[5,1,1]  R1317     5.5650299787521362e-01
    z[5,1,1]  R1318     2.7068966627120972e-01
    z[5,1,1]  R1319     2.0389008522033691e-01
    z[5,1,1]  R1320     2.8315299749374390e-01
    z[5,1,1]  R1321     3.0223432183265686e-01
    z[5,1,1]  R1322     -1.4377743005752563e-01
    z[5,1,1]  R1323     -2.0649042725563049e-01
    z[5,1,1]  R1324     8.2114261388778687e-01
    z[5,1,1]  R1325     7.1400213241577148e-01
    z[5,1,1]  R1326     -3.3164060115814209e-01
    z[5,1,1]  R1327     -1.8140999972820282e-01
    z[5,1,1]  R1328     -5.1794147491455078e-01
    z[5,1,1]  R1329     -5.0821495056152344e-01
    z[5,1,1]  R1330     -6.5732920169830322e-01
    z[5,1,1]  R1331     -5.3367048501968384e-01
    z[5,1,1]  R1332     -5.9342402219772339e-01
    z[5,1,1]  R1333     2.9371902346611023e-01
    z[5,1,1]  R1334     3.0722531676292419e-01
    z[5,1,1]  R1335     7.0174783468246460e-01
    z[5,1,1]  R1336     -5.3573852777481079e-01
    z[5,1,1]  R1337     -7.3988282680511475e-01
    z[5,1,1]  R1338     -1.4559482038021088e-01
    z[5,1,1]  R1339     -6.6544854640960693e-01
    z[5,1,1]  R1340     2.6029470562934875e-01
    z[5,1,1]  R1341     0.684913694858551
    z[5,1,1]  R1342     5.3332304954528809e-01
    z[5,1,1]  R1343     7.8472161293029785e-01
    z[5,1,1]  R1344     8.9037430286407471e-01
    z[5,1,1]  R1345     0.710384726524353
    z[5,1,1]  R1346     -4.5226737856864929e-01
    z[5,1,1]  R1347     2.4580633640289307e-01
    z[5,1,1]  R1348     6.3817453384399414e-01
    z[5,1,1]  R1349     -5.0469082593917847e-01
    z[5,1,1]  R1350     7.7087897062301636e-01
    z[5,1,1]  R1351     7.6046824455261230e-01
    z[5,1,1]  R1352     7.8955745697021484e-01
    z[5,1,1]  R1353     2.1833692491054535e-01
    z[5,1,1]  R1354     7.0232802629470825e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R1246     -1
    z[5,1,2]  R1247     1
    z[5,1,2]  R1256     2.2204430401325226e-01
    z[5,1,2]  R1257     -6.9286718964576721e-02
    z[5,1,2]  R1258     1.0267228819429874e-02
    z[5,1,2]  R1259     -3.1002461910247803e-02
    z[5,1,2]  R1260     1.0819110274314880e-01
    z[5,1,2]  R1261     -3.7111940979957581e-01
    z[5,1,2]  R1262     7.5985920429229736e-01
    z[5,1,2]  R1263     -2.4186022579669952e-01
    z[5,1,2]  R1264     7.5410521030426025e-01
    z[5,1,2]  R1265     -4.7407627105712891e-01
    z[5,1,2]  R1266     2.6614934206008911e-01
    z[5,1,2]  R1267     -4.7693509608507156e-02
    z[5,1,2]  R1268     2.5060348212718964e-02
    z[5,1,2]  R1269     -2.1321940422058105e-01
    z[5,1,2]  R1270     0.201337531208992
    z[5,1,2]  R1271     -2.9549381136894226e-01
    z[5,1,2]  R1272     -1.6530798375606537e-01
    z[5,1,2]  R1273     0.0824781134724617
    z[5,1,2]  R1274     -6.8636782467365265e-02
    z[5,1,2]  R1275     1.6016195714473724e-01
    z[5,1,2]  R1276     -4.8945721983909607e-01
    z[5,1,2]  R1277     5.1430130004882812e-01
    z[5,1,2]  R1278     3.4037387371063232e-01
    z[5,1,2]  R1279     -8.9806658029556274e-01
    z[5,1,2]  R1280     -0.0916375145316124
    z[5,1,2]  R1281     3.0163705348968506e-02
    z[5,1,2]  R1282     -4.7916686534881592e-01
    z[5,1,2]  R1283     -1.5109807252883911e-01
    z[5,1,2]  R1284     -3.7307778000831604e-01
    z[5,1,2]  R1285     -9.4032082706689835e-03
    z[5,1,2]  R1286     8.0027438700199127e-02
    z[5,1,2]  R1287     -5.8725923299789429e-02
    z[5,1,2]  R1288     1.0964184254407883e-01
    z[5,1,2]  R1289     -7.3334950208663940e-01
    z[5,1,2]  R1290     4.0528017282485962e-01
    z[5,1,2]  R1291     0.284252792596817
    z[5,1,2]  R1292     3.6815294623374939e-01
    z[5,1,2]  R1293     1.5899296104907990e-01
    z[5,1,2]  R1294     4.2180046439170837e-01
    z[5,1,2]  R1295     4.2704778909683228e-01
    z[5,1,2]  R1296     -5.3261661529541016e-01
    z[5,1,2]  R1297     -4.9754548072814941e-01
    z[5,1,2]  R1298     4.1682365536689758e-01
    z[5,1,2]  R1299     -9.4092383980751038e-02
    z[5,1,2]  R1300     6.6872701048851013e-02
    z[5,1,2]  R1301     5.3215879201889038e-01
    z[5,1,2]  R1302     4.9683311581611633e-01
    z[5,1,2]  R1303     4.9082070589065552e-01
    z[5,1,2]  R1304     6.5681940317153931e-01
    z[5,1,2]  R1305     6.7451059818267822e-01
    z[5,1,2]  R1306     7.8288090229034424e-01
    z[5,1,2]  R1307     6.9121789932250977e-01
    z[5,1,2]  R1308     2.7046054601669312e-01
    z[5,1,2]  R1309     -9.0173922479152679e-02
    z[5,1,2]  R1310     0.612095057964325
    z[5,1,2]  R1311     4.0137669444084167e-01
    z[5,1,2]  R1312     -2.8709178790450096e-02
    z[5,1,2]  R1313     -3.5165694355964661e-01
    z[5,1,2]  R1314     7.7848076820373535e-02
    z[5,1,2]  R1315     -2.6500681042671204e-01
    z[5,1,2]  R1316     -1.8514315783977509e-01
    z[5,1,2]  R1317     5.4202932119369507e-01
    z[5,1,2]  R1318     -1.2013711780309677e-01
    z[5,1,2]  R1319     3.0058783292770386e-01
    z[5,1,2]  R1320     -3.3320057392120361e-01
    z[5,1,2]  R1321     -2.3354759812355042e-01
    z[5,1,2]  R1322     -2.6625505089759827e-01
    z[5,1,2]  R1323     2.5235649943351746e-01
    z[5,1,2]  R1324     -1.5740875899791718e-01
    z[5,1,2]  R1325     2.9138955473899841e-01
    z[5,1,2]  R1326     2.7108547091484070e-01
    z[5,1,2]  R1327     4.9036440253257751e-01
    z[5,1,2]  R1328     3.1304258108139038e-01
    z[5,1,2]  R1329     3.3663868904113770e-01
    z[5,1,2]  R1330     -2.5620761513710022e-01
    z[5,1,2]  R1331     -3.8797748088836670e-01
    z[5,1,2]  R1332     -1.6617652773857117e-01
    z[5,1,2]  R1333     5.5452769994735718e-01
    z[5,1,2]  R1334     5.9412352740764618e-02
    z[5,1,2]  R1335     2.2869819402694702e-01
    z[5,1,2]  R1336     7.1511673927307129e-01
    z[5,1,2]  R1337     -2.6457920670509338e-01
    z[5,1,2]  R1338     4.2584562301635742e-01
    z[5,1,2]  R1339     -1.1458848416805267e-01
    z[5,1,2]  R1340     -6.1519676446914673e-01
    z[5,1,2]  R1341     -1.7192934453487396e-01
    z[5,1,2]  R1342     -2.2272443771362305e-01
    z[5,1,2]  R1343     -2.4329580366611481e-01
    z[5,1,2]  R1344     -2.7469378709793091e-01
    z[5,1,2]  R1345     1.3224802911281586e-02
    z[5,1,2]  R1346     -1.1340240389108658e-01
    z[5,1,2]  R1347     3.0671819113194942e-03
    z[5,1,2]  R1348     5.8155737817287445e-02
    z[5,1,2]  R1349     2.9615920782089233e-01
    z[5,1,2]  R1350     -0.0243210606276989
    z[5,1,2]  R1351     -3.4894734621047974e-01
    z[5,1,2]  R1352     -1.1464491486549377e-01
    z[5,1,2]  R1353     -6.2834733724594116e-01
    z[5,1,2]  R1354     -2.8288549184799194e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R1248     -1
    z[5,1,3]  R1249     1
    z[5,1,3]  R1256     -1.7188473045825958e-01
    z[5,1,3]  R1257     1.8126615881919861e-01
    z[5,1,3]  R1258     4.3439182639122009e-01
    z[5,1,3]  R1259     -1.2478467077016830e-01
    z[5,1,3]  R1260     1.9832178950309753e-01
    z[5,1,3]  R1261     4.3204563856124878e-01
    z[5,1,3]  R1262     1.1489140801131725e-02
    z[5,1,3]  R1263     -4.0967710316181183e-02
    z[5,1,3]  R1264     4.8574271798133850e-01
    z[5,1,3]  R1265     -4.3506991118192673e-02
    z[5,1,3]  R1266     -4.6891830861568451e-02
    z[5,1,3]  R1267     -2.8363440185785294e-02
    z[5,1,3]  R1268     1.3611934147775173e-02
    z[5,1,3]  R1269     -0.0231669619679451
    z[5,1,3]  R1270     2.2896258533000946e-01
    z[5,1,3]  R1271     3.4761503338813782e-01
    z[5,1,3]  R1272     2.6514670252799988e-01
    z[5,1,3]  R1273     1.0575447231531143e-01
    z[5,1,3]  R1274     4.9875143170356750e-01
    z[5,1,3]  R1275     7.5762018561363220e-02
    z[5,1,3]  R1276     -2.3659074306488037e-01
    z[5,1,3]  R1277     -2.6496499776840210e-01
    z[5,1,3]  R1278     -1.8247883021831512e-01
    z[5,1,3]  R1279     -2.2330953180789948e-01
    z[5,1,3]  R1280     -1.5001441538333893e-01
    z[5,1,3]  R1281     -4.4930616021156311e-01
    z[5,1,3]  R1282     -2.6776903867721558e-01
    z[5,1,3]  R1283     9.8131135106086731e-02
    z[5,1,3]  R1284     -2.6228803396224976e-01
    z[5,1,3]  R1285     -1.6434629261493683e-01
    z[5,1,3]  R1286     -6.9557195901870728e-01
    z[5,1,3]  R1287     -0.846520185470581
    z[5,1,3]  R1288     -4.7702023386955261e-01
    z[5,1,3]  R1289     -4.8704613000154495e-02
    z[5,1,3]  R1290     -1.0013290494680405e-01
    z[5,1,3]  R1291     -9.7566343843936920e-02
    z[5,1,3]  R1292     -8.4781445562839508e-02
    z[5,1,3]  R1293     -0.349507600069046
    z[5,1,3]  R1294     -4.1402030736207962e-02
    z[5,1,3]  R1295     1.7861567437648773e-01
    z[5,1,3]  R1296     -4.2533260583877563e-01
    z[5,1,3]  R1297     -2.0311589539051056e-01
    z[5,1,3]  R1298     -2.9586234688758850e-01
    z[5,1,3]  R1299     1.5119914710521698e-01
    z[5,1,3]  R1300     -4.7901135683059692e-01
    z[5,1,3]  R1301     -7.7033668756484985e-01
    z[5,1,3]  R1302     -5.8633148670196533e-01
    z[5,1,3]  R1303     -2.6660934090614319e-01
    z[5,1,3]  R1304     1.6089810431003571e-01
    z[5,1,3]  R1305     3.4706801176071167e-01
    z[5,1,3]  R1306     -1.3675062358379364e-01
    z[5,1,3]  R1307     -1.2978547811508179e-01
    z[5,1,3]  R1308     -2.1833953261375427e-01
    z[5,1,3]  R1309     -0.192160502076149
    z[5,1,3]  R1310     2.3703585565090179e-01
    z[5,1,3]  R1311     1.8773065507411957e-01
    z[5,1,3]  R1312     4.6362329274415970e-02
    z[5,1,3]  R1313     -1.2510886788368225e-01
    z[5,1,3]  R1314     -1.6061370074748993e-01
    z[5,1,3]  R1315     -2.4646823108196259e-01
    z[5,1,3]  R1316     -6.7244774103164673e-01
    z[5,1,3]  R1317     -3.4394088387489319e-01
    z[5,1,3]  R1318     1.5020883083343506e-01
    z[5,1,3]  R1319     1.7196573317050934e-01
    z[5,1,3]  R1320     -3.5162393003702164e-02
    z[5,1,3]  R1321     -3.5772061347961426e-01
    z[5,1,3]  R1322     -0.360651433467865
    z[5,1,3]  R1323     1.1904857121407986e-02
    z[5,1,3]  R1324     1.0218356549739838e-01
    z[5,1,3]  R1325     7.6278068125247955e-02
    z[5,1,3]  R1326     -1.2785153090953827e-01
    z[5,1,3]  R1327     -3.0141493678092957e-01
    z[5,1,3]  R1328     3.7640803493559361e-03
    z[5,1,3]  R1329     4.3715375661849976e-01
    z[5,1,3]  R1330     5.1293814182281494e-01
    z[5,1,3]  R1331     1.5632462501525879e-01
    z[5,1,3]  R1332     6.3311499357223511e-01
    z[5,1,3]  R1333     -5.8447301387786865e-01
    z[5,1,3]  R1334     -2.7181667089462280e-01
    z[5,1,3]  R1335     -7.3082715272903442e-02
    z[5,1,3]  R1336     -3.0466508865356445e-01
    z[5,1,3]  R1337     -1.4586928486824036e-01
    z[5,1,3]  R1338     -3.5448685288429260e-01
    z[5,1,3]  R1339     5.7399606704711914e-01
    z[5,1,3]  R1340     -5.2418279647827148e-01
    z[5,1,3]  R1341     -0.277119517326355
    z[5,1,3]  R1342     -1.5559767186641693e-01
    z[5,1,3]  R1343     -4.8624446988105774e-01
    z[5,1,3]  R1344     -1.8034832552075386e-02
    z[5,1,3]  R1345     3.2120910286903381e-01
    z[5,1,3]  R1346     2.6803153753280640e-01
    z[5,1,3]  R1347     -4.8867025971412659e-01
    z[5,1,3]  R1348     -7.2287283837795258e-02
    z[5,1,3]  R1349     5.6514286994934082e-01
    z[5,1,3]  R1350     2.9438361525535583e-01
    z[5,1,3]  R1351     8.9321218430995941e-02
    z[5,1,3]  R1352     1.5312604606151581e-02
    z[5,1,3]  R1353     -0.288524866104126
    z[5,1,3]  R1354     0.1168212890625
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R1250     -1
    z[5,1,4]  R1251     1
    z[5,1,4]  R1256     2.3010133206844330e-01
    z[5,1,4]  R1257     3.4058505296707153e-01
    z[5,1,4]  R1258     1.6457255184650421e-01
    z[5,1,4]  R1259     1.1215513199567795e-01
    z[5,1,4]  R1260     2.1339850500226021e-03
    z[5,1,4]  R1261     2.0488698035478592e-02
    z[5,1,4]  R1262     1.5322379767894745e-02
    z[5,1,4]  R1263     6.2139028310775757e-01
    z[5,1,4]  R1264     4.9387805163860321e-02
    z[5,1,4]  R1265     1.4650250971317291e-01
    z[5,1,4]  R1266     -1.3256011903285980e-01
    z[5,1,4]  R1267     3.7601027637720108e-02
    z[5,1,4]  R1268     -3.1871777772903442e-01
    z[5,1,4]  R1269     2.6871031522750854e-01
    z[5,1,4]  R1270     4.8271864652633667e-02
    z[5,1,4]  R1271     2.1161170303821564e-01
    z[5,1,4]  R1272     -3.2673040404915810e-03
    z[5,1,4]  R1273     0.360588401556015
    z[5,1,4]  R1274     0.0846773162484169
    z[5,1,4]  R1275     0.078289695084095
    z[5,1,4]  R1276     -2.1471163630485535e-01
    z[5,1,4]  R1277     4.7779548168182373e-01
    z[5,1,4]  R1278     -1.5561152994632721e-01
    z[5,1,4]  R1279     6.5029174089431763e-02
    z[5,1,4]  R1280     -5.4568547010421753e-01
    z[5,1,4]  R1281     -2.0039555430412292e-01
    z[5,1,4]  R1282     -6.9484390318393707e-02
    z[5,1,4]  R1283     -3.6225995421409607e-01
    z[5,1,4]  R1284     -3.3178317546844482e-01
    z[5,1,4]  R1285     -4.5058351755142212e-01
    z[5,1,4]  R1286     -1.4191937446594238e-01
    z[5,1,4]  R1287     -3.5129639506340027e-01
    z[5,1,4]  R1288     -2.0226357877254486e-01
    z[5,1,4]  R1289     -1.7484459280967712e-01
    z[5,1,4]  R1290     -2.4712309241294861e-01
    z[5,1,4]  R1291     -1.8820452690124512e-01
    z[5,1,4]  R1292     -7.1713291108608246e-02
    z[5,1,4]  R1293     -3.2527527213096619e-01
    z[5,1,4]  R1294     -3.5218662023544312e-01
    z[5,1,4]  R1295     0.144295796751976
    z[5,1,4]  R1296     -3.9359182119369507e-01
    z[5,1,4]  R1297     5.1760542392730713e-01
    z[5,1,4]  R1298     6.9337749481201172e-01
    z[5,1,4]  R1299     3.5283794999122620e-01
    z[5,1,4]  R1300     5.1066315174102783e-01
    z[5,1,4]  R1301     -2.9012659192085266e-01
    z[5,1,4]  R1302     -1.2565696239471436e-01
    z[5,1,4]  R1303     -2.2074703872203827e-01
    z[5,1,4]  R1304     2.0937354862689972e-01
    z[5,1,4]  R1305     -5.6084852665662766e-02
    z[5,1,4]  R1306     3.7444502115249634e-01
    z[5,1,4]  R1307     4.6636760234832764e-01
    z[5,1,4]  R1308     7.1435712277889252e-02
    z[5,1,4]  R1309     3.0189543962478638e-01
    z[5,1,4]  R1310     4.6917036175727844e-01
    z[5,1,4]  R1311     -6.2298811972141266e-02
    z[5,1,4]  R1312     1.1157064139842987e-01
    z[5,1,4]  R1313     1.7434763908386230e-01
    z[5,1,4]  R1314     0.265186071395874
    z[5,1,4]  R1315     8.1869371235370636e-02
    z[5,1,4]  R1316     -0.0295050460845232
    z[5,1,4]  R1317     4.1165456175804138e-02
    z[5,1,4]  R1318     1.4436149597167969e-01
    z[5,1,4]  R1319     -7.9460576176643372e-02
    z[5,1,4]  R1320     7.5569534301757812e-01
    z[5,1,4]  R1321     -5.1839772611856461e-02
    z[5,1,4]  R1322     1.8890835344791412e-01
    z[5,1,4]  R1323     -2.3591178655624390e-01
    z[5,1,4]  R1324     -3.0672883987426758e-01
    z[5,1,4]  R1325     -1.2151244282722473e-01
    z[5,1,4]  R1326     -4.5494616031646729e-01
    z[5,1,4]  R1327     -5.7108914852142334e-01
    z[5,1,4]  R1328     -1.4176666736602783e-01
    z[5,1,4]  R1329     -3.3100968599319458e-01
    z[5,1,4]  R1330     1.0167949646711349e-01
    z[5,1,4]  R1331     -3.1500551104545593e-01
    z[5,1,4]  R1332     -2.4191634356975555e-01
    z[5,1,4]  R1333     -2.6066654920578003e-01
    z[5,1,4]  R1334     4.7065809369087219e-02
    z[5,1,4]  R1335     -2.2838643193244934e-01
    z[5,1,4]  R1336     -1.7407071590423584e-01
    z[5,1,4]  R1337     1.1996034532785416e-01
    z[5,1,4]  R1338     3.4921982884407043e-01
    z[5,1,4]  R1339     1.6590552031993866e-01
    z[5,1,4]  R1340     3.6356106400489807e-01
    z[5,1,4]  R1341     0.567359983921051
    z[5,1,4]  R1342     -4.1081428527832031e-01
    z[5,1,4]  R1343     -2.4256144464015961e-01
    z[5,1,4]  R1344     -6.1225313693284988e-02
    z[5,1,4]  R1345     -2.1430957317352295e-01
    z[5,1,4]  R1346     -3.9447724819183350e-01
    z[5,1,4]  R1347     -1.9413267076015472e-01
    z[5,1,4]  R1348     5.8033210039138794e-01
    z[5,1,4]  R1349     -3.3854478597640991e-01
    z[5,1,4]  R1350     -2.6605397462844849e-01
    z[5,1,4]  R1351     -1.3745093345642090e-01
    z[5,1,4]  R1352     6.3053965568542480e-02
    z[5,1,4]  R1353     2.9617384076118469e-01
    z[5,1,4]  R1354     1.8876156210899353e-01
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R1252     -1
    z[5,1,5]  R1253     1
    z[5,1,5]  R1256     1.6349695622920990e-02
    z[5,1,5]  R1257     4.0406482294201851e-03
    z[5,1,5]  R1258     -2.8824573755264282e-01
    z[5,1,5]  R1259     6.4108437299728394e-01
    z[5,1,5]  R1260     2.6808005571365356e-01
    z[5,1,5]  R1261     3.5143008828163147e-01
    z[5,1,5]  R1262     -1.1392273753881454e-01
    z[5,1,5]  R1263     2.9049047827720642e-01
    z[5,1,5]  R1264     1.9229158759117126e-01
    z[5,1,5]  R1265     -1.3685730099678040e-01
    z[5,1,5]  R1266     2.3453648388385773e-01
    z[5,1,5]  R1267     -0.155681312084198
    z[5,1,5]  R1268     -2.1839885041117668e-02
    z[5,1,5]  R1269     1.5839838981628418e-01
    z[5,1,5]  R1270     9.0267747640609741e-02
    z[5,1,5]  R1271     1.0915318131446838e-01
    z[5,1,5]  R1272     2.9655680060386658e-01
    z[5,1,5]  R1273     1.3262277841567993e-01
    z[5,1,5]  R1274     -0.0666360929608345
    z[5,1,5]  R1275     -2.6828205585479736e-01
    z[5,1,5]  R1276     2.8831627964973450e-01
    z[5,1,5]  R1277     6.0940408706665039e-01
    z[5,1,5]  R1278     -2.6306754350662231e-01
    z[5,1,5]  R1279     3.0098492279648781e-03
    z[5,1,5]  R1280     1.1404132843017578e-01
    z[5,1,5]  R1281     -3.3031675219535828e-01
    z[5,1,5]  R1282     -2.3639994859695435e-01
    z[5,1,5]  R1283     -1.1001867055892944e-01
    z[5,1,5]  R1284     -3.6067163944244385e-01
    z[5,1,5]  R1285     5.5549168586730957e-01
    z[5,1,5]  R1286     3.3442208170890808e-01
    z[5,1,5]  R1287     2.1022740006446838e-01
    z[5,1,5]  R1288     4.3663203716278076e-01
    z[5,1,5]  R1289     5.2558046579360962e-01
    z[5,1,5]  R1290     3.7022992968559265e-01
    z[5,1,5]  R1291     2.5225467979907990e-02
    z[5,1,5]  R1292     2.4903084337711334e-01
    z[5,1,5]  R1293     5.6108510494232178e-01
    z[5,1,5]  R1294     1.4927624724805355e-02
    z[5,1,5]  R1295     9.7732760012149811e-02
    z[5,1,5]  R1296     2.3926517367362976e-01
    z[5,1,5]  R1297     1.5449105203151703e-01
    z[5,1,5]  R1298     -6.4368017017841339e-02
    z[5,1,5]  R1299     6.5900111198425293e-01
    z[5,1,5]  R1300     -1.0784979909658432e-01
    z[5,1,5]  R1301     1.7631146311759949e-01
    z[5,1,5]  R1302     0.00893962662667036
    z[5,1,5]  R1303     5.4915450513362885e-02
    z[5,1,5]  R1304     -2.6482370495796204e-01
    z[5,1,5]  R1305     0.0788489356637001
    z[5,1,5]  R1306     1.8587511777877808e-01
    z[5,1,5]  R1307     -1.4139805734157562e-01
    z[5,1,5]  R1308     4.5469993352890015e-01
    z[5,1,5]  R1309     8.6127929389476776e-02
    z[5,1,5]  R1310     0.0432896763086319
    z[5,1,5]  R1311     7.2182303667068481e-01
    z[5,1,5]  R1312     5.4944694042205811e-01
    z[5,1,5]  R1313     5.7868117094039917e-01
    z[5,1,5]  R1314     -0.176085963845253
    z[5,1,5]  R1315     -1.6225415468215942e-01
    z[5,1,5]  R1316     -2.5128121487796307e-03
    z[5,1,5]  R1317     6.8202703259885311e-03
    z[5,1,5]  R1318     2.7587673068046570e-01
    z[5,1,5]  R1319     -1.8212584778666496e-02
    z[5,1,5]  R1320     3.5121780633926392e-01
    z[5,1,5]  R1321     -4.2768475413322449e-01
    z[5,1,5]  R1322     1.0120529681444168e-01
    z[5,1,5]  R1323     -7.2193038463592529e-01
    z[5,1,5]  R1324     -8.1432253122329712e-02
    z[5,1,5]  R1325     -1.8198329210281372e-01
    z[5,1,5]  R1326     -6.8062287569046021e-01
    z[5,1,5]  R1327     -4.0630817413330078e-01
    z[5,1,5]  R1328     -4.6032306551933289e-01
    z[5,1,5]  R1329     -1.7219726741313934e-01
    z[5,1,5]  R1330     -0.430600643157959
    z[5,1,5]  R1331     -5.0054562091827393e-01
    z[5,1,5]  R1332     5.8270907029509544e-03
    z[5,1,5]  R1333     2.9229742288589478e-01
    z[5,1,5]  R1334     6.6445773839950562e-01
    z[5,1,5]  R1335     2.1083930134773254e-01
    z[5,1,5]  R1336     2.4733105301856995e-01
    z[5,1,5]  R1337     4.7527906298637390e-01
    z[5,1,5]  R1338     5.6023615598678589e-01
    z[5,1,5]  R1339     -2.4616421759128571e-01
    z[5,1,5]  R1340     3.7608388066291809e-01
    z[5,1,5]  R1341     1.9763027131557465e-01
    z[5,1,5]  R1342     -3.1555801630020142e-01
    z[5,1,5]  R1343     1.6353559494018555e-01
    z[5,1,5]  R1344     -1.9240470230579376e-01
    z[5,1,5]  R1345     0.129002645611763
    z[5,1,5]  R1346     5.4752331972122192e-01
    z[5,1,5]  R1347     7.5934166088700294e-03
    z[5,1,5]  R1348     3.3185136318206787e-01
    z[5,1,5]  R1349     1.9408319890499115e-01
    z[5,1,5]  R1350     -1.7621102929115295e-01
    z[5,1,5]  R1351     -7.7011808753013611e-02
    z[5,1,5]  R1352     -1.5127140283584595e-01
    z[5,1,5]  R1353     -4.7354641556739807e-01
    z[5,1,5]  R1354     1.2884079478681087e-02
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R1254     -1
    z[5,1,6]  R1255     1
    z[5,1,6]  R1256     3.0506783723831177e-01
    z[5,1,6]  R1257     -1.6707411408424377e-01
    z[5,1,6]  R1258     -1.4030157029628754e-01
    z[5,1,6]  R1259     -1.5614232420921326e-01
    z[5,1,6]  R1260     -6.9573158025741577e-01
    z[5,1,6]  R1261     3.9206331968307495e-01
    z[5,1,6]  R1262     -4.4810160994529724e-01
    z[5,1,6]  R1263     -1.3658446073532104e-01
    z[5,1,6]  R1264     6.9953277707099915e-03
    z[5,1,6]  R1265     -4.5238631963729858e-01
    z[5,1,6]  R1266     -1.8078187480568886e-02
    z[5,1,6]  R1267     3.6166332662105560e-02
    z[5,1,6]  R1268     -4.2214909195899963e-01
    z[5,1,6]  R1269     3.2443445920944214e-01
    z[5,1,6]  R1270     -1.1246681213378906e-02
    z[5,1,6]  R1271     0.0382811576128006
    z[5,1,6]  R1272     -2.4132886528968811e-01
    z[5,1,6]  R1273     -3.7785002589225769e-01
    z[5,1,6]  R1274     -1.8799139559268951e-01
    z[5,1,6]  R1275     -4.2002037167549133e-02
    z[5,1,6]  R1276     4.2526909708976746e-01
    z[5,1,6]  R1277     1.3504503667354584e-01
    z[5,1,6]  R1278     3.2356211543083191e-01
    z[5,1,6]  R1279     1.5062689781188965e-01
    z[5,1,6]  R1280     -1.1830971390008926e-01
    z[5,1,6]  R1281     5.9109228849411011e-01
    z[5,1,6]  R1282     6.6986465454101562e-01
    z[5,1,6]  R1283     -2.7612483501434326e-01
    z[5,1,6]  R1284     3.7648779153823853e-01
    z[5,1,6]  R1285     -4.1460883617401123e-01
    z[5,1,6]  R1286     -7.3883078992366791e-02
    z[5,1,6]  R1287     2.6690849661827087e-01
    z[5,1,6]  R1288     2.3986613750457764e-01
    z[5,1,6]  R1289     -0.35416179895401
    z[5,1,6]  R1290     6.2710128724575043e-02
    z[5,1,6]  R1291     -6.3965469598770142e-02
    z[5,1,6]  R1292     -1.5120127797126770e-01
    z[5,1,6]  R1293     1.5688399970531464e-01
    z[5,1,6]  R1294     8.8956616818904877e-03
    z[5,1,6]  R1295     8.6626596748828888e-02
    z[5,1,6]  R1296     -2.4196162819862366e-01
    z[5,1,6]  R1297     -3.4563142806291580e-02
    z[5,1,6]  R1298     2.7168050408363342e-01
    z[5,1,6]  R1299     1.4697673916816711e-01
    z[5,1,6]  R1300     6.4747321605682373e-01
    z[5,1,6]  R1301     6.5576941706240177e-03
    z[5,1,6]  R1302     5.0558692216873169e-01
    z[5,1,6]  R1303     2.6151040196418762e-01
    z[5,1,6]  R1304     1.1140928417444229e-01
    z[5,1,6]  R1305     -3.5501249134540558e-02
    z[5,1,6]  R1306     2.8560683131217957e-01
    z[5,1,6]  R1307     3.9391836524009705e-01
    z[5,1,6]  R1308     7.0469003915786743e-01
    z[5,1,6]  R1309     7.5557726621627808e-01
    z[5,1,6]  R1310     -3.5521391034126282e-01
    z[5,1,6]  R1311     -3.6219093948602676e-02
    z[5,1,6]  R1312     -3.3626472949981689e-01
    z[5,1,6]  R1313     -1.1651092767715454e-01
    z[5,1,6]  R1314     1.8766130506992340e-01
    z[5,1,6]  R1315     2.1053564548492432e-01
    z[5,1,6]  R1316     -1.6096076369285583e-01
    z[5,1,6]  R1317     2.3172810673713684e-01
    z[5,1,6]  R1318     4.1252526640892029e-01
    z[5,1,6]  R1319     -1.9073310494422913e-01
    z[5,1,6]  R1320     -1.2972231209278107e-01
    z[5,1,6]  R1321     -5.2020758390426636e-01
    z[5,1,6]  R1322     -7.9890716075897217e-01
    z[5,1,6]  R1323     -4.0473058819770813e-01
    z[5,1,6]  R1324     -3.6321204900741577e-01
    z[5,1,6]  R1325     -5.4574948549270630e-01
    z[5,1,6]  R1326     6.5559722483158112e-02
    z[5,1,6]  R1327     3.6005118489265442e-01
    z[5,1,6]  R1328     -4.5117178559303284e-01
    z[5,1,6]  R1329     -5.4073441028594971e-01
    z[5,1,6]  R1330     1.2992599513381720e-03
    z[5,1,6]  R1331     2.1642138063907623e-01
    z[5,1,6]  R1332     3.4340581297874451e-01
    z[5,1,6]  R1333     -3.2740628719329834e-01
    z[5,1,6]  R1334     -6.2006378173828125e-01
    z[5,1,6]  R1335     2.7123183012008667e-01
    z[5,1,6]  R1336     -4.2300187051296234e-02
    z[5,1,6]  R1337     1.2370651215314865e-01
    z[5,1,6]  R1338     -4.7015976905822754e-01
    z[5,1,6]  R1339     3.4981733560562134e-01
    z[5,1,6]  R1340     -7.3354914784431458e-02
    z[5,1,6]  R1341     -2.4641756713390350e-01
    z[5,1,6]  R1342     -2.3655369877815247e-02
    z[5,1,6]  R1343     4.4243231415748596e-02
    z[5,1,6]  R1344     -2.6326501369476318e-01
    z[5,1,6]  R1345     -6.7819356918334961e-02
    z[5,1,6]  R1346     -5.0240176916122437e-01
    z[5,1,6]  R1347     -2.6337611675262451e-01
    z[5,1,6]  R1348     -3.5471022129058838e-02
    z[5,1,6]  R1349     1.9848808646202087e-01
    z[5,1,6]  R1350     -6.9091357290744781e-02
    z[5,1,6]  R1351     3.4583261609077454e-01
    z[5,1,6]  R1352     1.0074346512556076e-01
    z[5,1,6]  R1353     2.9694160819053650e-01
    z[5,1,6]  R1354     2.5770869851112366e-01
    z[1,6,0]  R11       -1
    z[1,6,0]  R56       1
    z[1,6,0]  R1355     -1
    z[1,6,0]  R1356     1
    z[1,6,0]  R1369     -2.3927323520183563e-01
    z[1,6,0]  R1370     -9.3068093061447144e-02
    z[1,6,0]  R1371     -1.8396428227424622e-01
    z[1,6,0]  R1372     1.1003871262073517e-01
    z[1,6,0]  R1373     -4.2539175599813461e-02
    z[1,6,0]  R1374     -3.0694505572319031e-01
    z[1,6,0]  R1375     2.3849646747112274e-01
    z[1,6,0]  R1376     -2.5389662384986877e-01
    z[1,6,0]  R1377     -3.2029229402542114e-01
    z[1,6,0]  R1378     -1.6619090735912323e-01
    z[1,6,0]  R1379     6.6466385126113892e-01
    z[1,6,0]  R1380     -4.7198975086212158e-01
    z[1,6,0]  R1381     -7.8905403614044189e-01
    z[1,6,0]  R1382     -0.89189612865448
    z[1,6,0]  R1383     -3.1033545732498169e-01
    z[1,6,0]  R1384     -5.1954627037048340e-01
    z[1,6,0]  R1385     -3.0689609050750732e-01
    z[1,6,0]  R1386     3.9101323485374451e-01
    z[1,6,0]  R1387     -2.4056018888950348e-01
    z[1,6,0]  R1388     -2.3183842003345490e-01
    z[1,6,0]  R1389     3.5448500514030457e-01
    z[1,6,0]  R1390     1.2213188409805298e-01
    z[1,6,0]  R1391     4.4516941905021667e-01
    z[1,6,0]  R1392     7.5336650013923645e-02
    z[1,6,0]  R1393     2.0835784077644348e-01
    z[1,6,0]  R1394     3.7897145748138428e-01
    z[1,6,0]  R1395     -2.0715612173080444e-01
    z[1,6,0]  R1396     6.3558273017406464e-02
    z[1,6,0]  R1397     1.4043904957361519e-04
    z[1,6,0]  R1398     -5.2889108657836914e-01
    z[1,6,0]  R1399     0.124534472823143
    z[1,6,0]  R1400     3.2512968778610229e-01
    z[1,6,0]  R1401     1.2217810004949570e-01
    z[1,6,0]  R1402     -0.0638943687081337
    z[1,6,0]  R1403     3.9143315516412258e-03
    z[1,6,0]  R1404     -5.3495984524488449e-02
    z[1,6,0]  R1405     -6.1061024665832520e-01
    z[1,6,0]  R1406     -3.2372646033763885e-02
    z[1,6,0]  R1407     -1.4620240032672882e-01
    z[1,6,0]  R1408     -5.6994175910949707e-01
    z[1,6,0]  R1409     5.4328281432390213e-02
    z[1,6,0]  R1410     -7.7049273252487183e-01
    z[1,6,0]  R1411     -3.6872324347496033e-01
    z[1,6,0]  R1412     -3.8276901841163635e-01
    z[1,6,0]  R1413     -0.460308313369751
    z[1,6,0]  R1414     -3.8408553600311279e-01
    z[1,6,0]  R1415     5.7115048170089722e-01
    z[1,6,0]  R1416     -2.7225458621978760e-01
    z[1,6,0]  R1417     5.5754220485687256e-01
    z[1,6,0]  R1418     -1.3540515303611755e-01
    z[1,6,0]  R1419     -1.8146499991416931e-01
    z[1,6,0]  R1420     -1.1458253115415573e-01
    z[1,6,0]  R1421     2.4590075016021729e-01
    z[1,6,0]  R1422     -1.9872394204139709e-01
    z[1,6,0]  R1423     -3.5660693049430847e-01
    z[1,6,0]  R1424     1.5453067421913147e-01
    z[1,6,0]  R1425     2.2420710325241089e-01
    z[1,6,0]  R1426     1.5158204734325409e-01
    z[1,6,0]  R1427     2.6731389760971069e-01
    z[1,6,0]  R1428     -5.2680999040603638e-01
    z[1,6,0]  R1429     3.3764970302581787e-01
    z[1,6,0]  R1430     -1.2792757153511047e-01
    z[1,6,0]  R1431     1.6103994846343994e-01
    z[1,6,0]  R1432     5.2135378122329712e-01
    z[1,6,0]  R1433     5.9990906715393066e-01
    z[1,6,0]  R1434     3.3722755312919617e-01
    z[1,6,0]  R1435     1.8013438582420349e-01
    z[1,6,0]  R1436     -0.107862688601017
    z[1,6,0]  R1437     3.6219507455825806e-01
    z[1,6,0]  R1438     1.5011836588382721e-01
    z[1,6,0]  R1439     1.5852367877960205e-01
    z[1,6,0]  R1440     -6.0171049833297729e-01
    z[1,6,0]  R1441     5.0972029566764832e-03
    z[1,6,0]  R1442     -2.3490250110626221e-01
    z[1,6,0]  R1443     -0.58235764503479
    z[1,6,0]  R1444     -3.8865572214126587e-01
    z[1,6,0]  R1445     -6.6175174713134766e-01
    z[1,6,0]  R1446     1.3481132686138153e-01
    z[1,6,0]  R1447     3.1511485576629639e-02
    z[1,6,0]  R1448     -9.6586331725120544e-02
    z[1,6,0]  R1449     -2.2670675814151764e-01
    z[1,6,0]  R1450     3.0439281463623047e-01
    z[1,6,0]  R1451     -3.5883578658103943e-01
    z[1,6,0]  R1452     -3.6778151988983154e-01
    z[1,6,0]  R1453     1.4055030420422554e-02
    z[1,6,0]  R1454     -2.7112754061818123e-02
    z[1,6,0]  R1455     1.8437290191650391e-01
    z[1,6,0]  R1456     3.1333580613136292e-01
    z[1,6,0]  R1457     1.6550573706626892e-01
    z[1,6,0]  R1458     -2.2626711428165436e-01
    z[1,6,0]  R1459     -3.5421958565711975e-01
    z[1,6,0]  R1460     1.0648952424526215e-01
    z[1,6,0]  R1461     0.0934305191040039
    z[1,6,0]  R1462     -1.3700267672538757e-01
    z[1,6,0]  R1463     -2.2628770768642426e-01
    z[1,6,0]  R1464     0.297559529542923
    z[1,6,0]  R1465     1.7040875554084778e-01
    z[1,6,0]  R1466     0.509533703327179
    z[1,6,0]  R1467     0.547876238822937
    z[1,6,0]  R1468     -1.1656825244426727e-01
    z[1,6,0]  R1469     -2.2897545248270035e-02
    z[1,6,0]  R1470     0.0225005391985178
    z[1,6,0]  R1471     -2.7690127491950989e-01
    z[1,6,0]  R1472     2.2823049128055573e-01
    z[1,6,0]  R1473     2.1646852791309357e-01
    z[1,6,0]  R1474     6.0384386777877808e-01
    z[1,6,0]  R1475     0.574550986289978
    z[1,6,1]  R12       -1
    z[1,6,1]  R57       1
    z[1,6,1]  R1357     -1
    z[1,6,1]  R1358     1
    z[1,6,1]  R1369     -2.3412662744522095e-01
    z[1,6,1]  R1370     -3.2256475090980530e-01
    z[1,6,1]  R1371     -3.6999046802520752e-01
    z[1,6,1]  R1372     -5.2285623550415039e-01
    z[1,6,1]  R1373     -4.6815851330757141e-01
    z[1,6,1]  R1374     -4.2803874611854553e-01
    z[1,6,1]  R1375     -7.1605294942855835e-01
    z[1,6,1]  R1376     6.4604789018630981e-01
    z[1,6,1]  R1377     8.5382020473480225e-01
    z[1,6,1]  R1378     8.7410008907318115e-01
    z[1,6,1]  R1379     -2.1206778287887573e-01
    z[1,6,1]  R1380     5.5650299787521362e-01
    z[1,6,1]  R1381     2.7068966627120972e-01
    z[1,6,1]  R1382     2.0389008522033691e-01
    z[1,6,1]  R1383     2.8315299749374390e-01
    z[1,6,1]  R1384     3.0223432183265686e-01
    z[1,6,1]  R1385     -1.4377743005752563e-01
    z[1,6,1]  R1386     -2.0649042725563049e-01
    z[1,6,1]  R1387     8.2114261388778687e-01
    z[1,6,1]  R1388     7.1400213241577148e-01
    z[1,6,1]  R1389     -3.3164060115814209e-01
    z[1,6,1]  R1390     -1.8140999972820282e-01
    z[1,6,1]  R1391     -5.1794147491455078e-01
    z[1,6,1]  R1392     -5.0821495056152344e-01
    z[1,6,1]  R1393     -6.5732920169830322e-01
    z[1,6,1]  R1394     -5.3367048501968384e-01
    z[1,6,1]  R1395     -5.9342402219772339e-01
    z[1,6,1]  R1396     2.9371902346611023e-01
    z[1,6,1]  R1397     3.0722531676292419e-01
    z[1,6,1]  R1398     7.0174783468246460e-01
    z[1,6,1]  R1399     -5.3573852777481079e-01
    z[1,6,1]  R1400     -7.3988282680511475e-01
    z[1,6,1]  R1401     -1.4559482038021088e-01
    z[1,6,1]  R1402     -6.6544854640960693e-01
    z[1,6,1]  R1403     2.6029470562934875e-01
    z[1,6,1]  R1404     0.684913694858551
    z[1,6,1]  R1405     5.3332304954528809e-01
    z[1,6,1]  R1406     7.8472161293029785e-01
    z[1,6,1]  R1407     8.9037430286407471e-01
    z[1,6,1]  R1408     0.710384726524353
    z[1,6,1]  R1409     -4.5226737856864929e-01
    z[1,6,1]  R1410     2.4580633640289307e-01
    z[1,6,1]  R1411     6.3817453384399414e-01
    z[1,6,1]  R1412     -5.0469082593917847e-01
    z[1,6,1]  R1413     7.7087897062301636e-01
    z[1,6,1]  R1414     7.6046824455261230e-01
    z[1,6,1]  R1415     7.8955745697021484e-01
    z[1,6,1]  R1416     2.1833692491054535e-01
    z[1,6,1]  R1417     7.0232802629470825e-01
    z[1,6,1]  R1418     5.9156060218811035e-01
    z[1,6,1]  R1419     6.1252003908157349e-01
    z[1,6,1]  R1420     3.3040410280227661e-01
    z[1,6,1]  R1421     7.1475124359130859e-01
    z[1,6,1]  R1422     7.8449553251266479e-01
    z[1,6,1]  R1423     6.9461055099964142e-02
    z[1,6,1]  R1424     -6.2608772516250610e-01
    z[1,6,1]  R1425     0.651689350605011
    z[1,6,1]  R1426     -0.763340950012207
    z[1,6,1]  R1427     -6.0725015401840210e-01
    z[1,6,1]  R1428     2.6873454451560974e-01
    z[1,6,1]  R1429     2.9936638474464417e-01
    z[1,6,1]  R1430     5.9346508979797363e-01
    z[1,6,1]  R1431     -9.4619792699813843e-01
    z[1,6,1]  R1432     -0.740623414516449
    z[1,6,1]  R1433     -6.8825989961624146e-01
    z[1,6,1]  R1434     -7.1170818805694580e-01
    z[1,6,1]  R1435     -7.4227726459503174e-01
    z[1,6,1]  R1436     4.0774738788604736e-01
    z[1,6,1]  R1437     -7.3594230413436890e-01
    z[1,6,1]  R1438     5.5974102020263672e-01
    z[1,6,1]  R1439     5.8711689710617065e-01
    z[1,6,1]  R1440     3.8535785675048828e-01
    z[1,6,1]  R1441     -3.0366463586688042e-02
    z[1,6,1]  R1442     1.5404240787029266e-01
    z[1,6,1]  R1443     3.3650639653205872e-01
    z[1,6,1]  R1444     4.0871241688728333e-01
    z[1,6,1]  R1445     -1.7309428751468658e-01
    z[1,6,1]  R1446     2.8831285238265991e-01
    z[1,6,1]  R1447     6.1456203460693359e-02
    z[1,6,1]  R1448     0.931501567363739
    z[1,6,1]  R1449     0.725002110004425
    z[1,6,1]  R1450     3.9444544911384583e-01
    z[1,6,1]  R1451     -1.6152249276638031e-01
    z[1,6,1]  R1452     2.9948723316192627e-01
    z[1,6,1]  R1453     2.3306940495967865e-01
    z[1,6,1]  R1454     -1.8271915614604950e-01
    z[1,6,1]  R1455     -8.4464186429977417e-01
    z[1,6,1]  R1456     -7.6121377944946289e-01
    z[1,6,1]  R1457     -8.0869638919830322e-01
    z[1,6,1]  R1458     0.27131387591362
    z[1,6,1]  R1459     5.6756451725959778e-02
    z[1,6,1]  R1460     -1.9486691057682037e-01
    z[1,6,1]  R1461     -5.3097051382064819e-01
    z[1,6,1]  R1462     -3.6388668417930603e-01
    z[1,6,1]  R1463     -4.2843598127365112e-01
    z[1,6,1]  R1464     -0.859521210193634
    z[1,6,1]  R1465     -0.878296434879303
    z[1,6,1]  R1466     -6.5130203962326050e-01
    z[1,6,1]  R1467     -6.2969833612442017e-01
    z[1,6,1]  R1468     8.3298072218894958e-02
    z[1,6,1]  R1469     1.2004360556602478e-01
    z[1,6,1]  R1470     -4.1857150197029114e-01
    z[1,6,1]  R1471     -3.4635263681411743e-01
    z[1,6,1]  R1472     -9.4786942005157471e-01
    z[1,6,1]  R1473     -9.4751822948455811e-01
    z[1,6,1]  R1474     -1.6938674449920654e-01
    z[1,6,1]  R1475     -0.0797528326511383
    z[1,6,2]  R13       -1
    z[1,6,2]  R58       1
    z[1,6,2]  R1359     -1
    z[1,6,2]  R1360     1
    z[1,6,2]  R1369     7.8288090229034424e-01
    z[1,6,2]  R1370     6.9121789932250977e-01
    z[1,6,2]  R1371     2.7046054601669312e-01
    z[1,6,2]  R1372     -9.0173922479152679e-02
    z[1,6,2]  R1373     0.612095057964325
    z[1,6,2]  R1374     4.0137669444084167e-01
    z[1,6,2]  R1375     -2.8709178790450096e-02
    z[1,6,2]  R1376     -3.5165694355964661e-01
    z[1,6,2]  R1377     7.7848076820373535e-02
    z[1,6,2]  R1378     -2.6500681042671204e-01
    z[1,6,2]  R1379     -1.8514315783977509e-01
    z[1,6,2]  R1380     5.4202932119369507e-01
    z[1,6,2]  R1381     -1.2013711780309677e-01
    z[1,6,2]  R1382     3.0058783292770386e-01
    z[1,6,2]  R1383     -3.3320057392120361e-01
    z[1,6,2]  R1384     -2.3354759812355042e-01
    z[1,6,2]  R1385     -2.6625505089759827e-01
    z[1,6,2]  R1386     2.5235649943351746e-01
    z[1,6,2]  R1387     -1.5740875899791718e-01
    z[1,6,2]  R1388     2.9138955473899841e-01
    z[1,6,2]  R1389     2.7108547091484070e-01
    z[1,6,2]  R1390     4.9036440253257751e-01
    z[1,6,2]  R1391     3.1304258108139038e-01
    z[1,6,2]  R1392     3.3663868904113770e-01
    z[1,6,2]  R1393     -2.5620761513710022e-01
    z[1,6,2]  R1394     -3.8797748088836670e-01
    z[1,6,2]  R1395     -1.6617652773857117e-01
    z[1,6,2]  R1396     5.5452769994735718e-01
    z[1,6,2]  R1397     5.9412352740764618e-02
    z[1,6,2]  R1398     2.2869819402694702e-01
    z[1,6,2]  R1399     7.1511673927307129e-01
    z[1,6,2]  R1400     -2.6457920670509338e-01
    z[1,6,2]  R1401     4.2584562301635742e-01
    z[1,6,2]  R1402     -1.1458848416805267e-01
    z[1,6,2]  R1403     -6.1519676446914673e-01
    z[1,6,2]  R1404     -1.7192934453487396e-01
    z[1,6,2]  R1405     -2.2272443771362305e-01
    z[1,6,2]  R1406     -2.4329580366611481e-01
    z[1,6,2]  R1407     -2.7469378709793091e-01
    z[1,6,2]  R1408     1.3224802911281586e-02
    z[1,6,2]  R1409     -1.1340240389108658e-01
    z[1,6,2]  R1410     3.0671819113194942e-03
    z[1,6,2]  R1411     5.8155737817287445e-02
    z[1,6,2]  R1412     2.9615920782089233e-01
    z[1,6,2]  R1413     -0.0243210606276989
    z[1,6,2]  R1414     -3.4894734621047974e-01
    z[1,6,2]  R1415     -1.1464491486549377e-01
    z[1,6,2]  R1416     -6.2834733724594116e-01
    z[1,6,2]  R1417     -2.8288549184799194e-01
    z[1,6,2]  R1418     -3.7073939893161878e-05
    z[1,6,2]  R1419     -9.4061434268951416e-02
    z[1,6,2]  R1420     -1.0151164606213570e-02
    z[1,6,2]  R1421     -3.6912170052528381e-01
    z[1,6,2]  R1422     -9.4815976917743683e-02
    z[1,6,2]  R1423     6.6864097118377686e-01
    z[1,6,2]  R1424     1.4853793382644653e-01
    z[1,6,2]  R1425     -2.0206044614315033e-01
    z[1,6,2]  R1426     5.1261745393276215e-02
    z[1,6,2]  R1427     5.7070064544677734e-01
    z[1,6,2]  R1428     1.9373928010463715e-01
    z[1,6,2]  R1429     -1.2308959662914276e-01
    z[1,6,2]  R1430     5.0703313201665878e-02
    z[1,6,2]  R1431     7.4863538146018982e-02
    z[1,6,2]  R1432     -2.7872905135154724e-01
    z[1,6,2]  R1433     -0.290794312953949
    z[1,6,2]  R1434     -8.2097806036472321e-02
    z[1,6,2]  R1435     1.1182001233100891e-01
    z[1,6,2]  R1436     1.9414447247982025e-01
    z[1,6,2]  R1437     -1.1578583717346191e-01
    z[1,6,2]  R1438     -3.4295099973678589e-01
    z[1,6,2]  R1439     -2.4560411274433136e-01
    z[1,6,2]  R1440     3.8912689685821533e-01
    z[1,6,2]  R1441     -1.2461658567190170e-01
    z[1,6,2]  R1442     3.0976501293480396e-03
    z[1,6,2]  R1443     4.9459049105644226e-01
    z[1,6,2]  R1444     1.7571765184402466e-01
    z[1,6,2]  R1445     4.7093614935874939e-01
    z[1,6,2]  R1446     -9.6561267971992493e-02
    z[1,6,2]  R1447     -2.7793669700622559e-01
    z[1,6,2]  R1448     -1.8980790674686432e-01
    z[1,6,2]  R1449     4.4485166668891907e-02
    z[1,6,2]  R1450     -4.0721407532691956e-01
    z[1,6,2]  R1451     1.6186350584030151e-01
    z[1,6,2]  R1452     4.1436710953712463e-01
    z[1,6,2]  R1453     -2.9058215022087097e-01
    z[1,6,2]  R1454     -1.3824518024921417e-01
    z[1,6,2]  R1455     -0.0147575493901968
    z[1,6,2]  R1456     -3.6450235638767481e-03
    z[1,6,2]  R1457     -1.9960529170930386e-03
    z[1,6,2]  R1458     -2.4927143007516861e-02
    z[1,6,2]  R1459     1.8710285425186157e-01
    z[1,6,2]  R1460     -2.4280165135860443e-01
    z[1,6,2]  R1461     -1.8334476277232170e-02
    z[1,6,2]  R1462     1.8672838807106018e-01
    z[1,6,2]  R1463     2.4049901962280273e-01
    z[1,6,2]  R1464     -8.7707303464412689e-02
    z[1,6,2]  R1465     1.1487445980310440e-01
    z[1,6,2]  R1466     -1.4127650856971741e-01
    z[1,6,2]  R1467     -1.9877615571022034e-01
    z[1,6,2]  R1468     -6.0105919837951660e-02
    z[1,6,2]  R1469     -0.25982666015625
    z[1,6,2]  R1470     0.0089586041867733
    z[1,6,2]  R1471     1.5497873723506927e-01
    z[1,6,2]  R1472     7.0586748421192169e-02
    z[1,6,2]  R1473     3.0409701168537140e-02
    z[1,6,2]  R1474     7.0663064718246460e-01
    z[1,6,2]  R1475     6.9450670480728149e-01
    z[1,6,3]  R14       -1
    z[1,6,3]  R59       1
    z[1,6,3]  R1361     -1
    z[1,6,3]  R1362     1
    z[1,6,3]  R1369     -1.3675062358379364e-01
    z[1,6,3]  R1370     -1.2978547811508179e-01
    z[1,6,3]  R1371     -2.1833953261375427e-01
    z[1,6,3]  R1372     -0.192160502076149
    z[1,6,3]  R1373     2.3703585565090179e-01
    z[1,6,3]  R1374     1.8773065507411957e-01
    z[1,6,3]  R1375     4.6362329274415970e-02
    z[1,6,3]  R1376     -1.2510886788368225e-01
    z[1,6,3]  R1377     -1.6061370074748993e-01
    z[1,6,3]  R1378     -2.4646823108196259e-01
    z[1,6,3]  R1379     -6.7244774103164673e-01
    z[1,6,3]  R1380     -3.4394088387489319e-01
    z[1,6,3]  R1381     1.5020883083343506e-01
    z[1,6,3]  R1382     1.7196573317050934e-01
    z[1,6,3]  R1383     -3.5162393003702164e-02
    z[1,6,3]  R1384     -3.5772061347961426e-01
    z[1,6,3]  R1385     -0.360651433467865
    z[1,6,3]  R1386     1.1904857121407986e-02
    z[1,6,3]  R1387     1.0218356549739838e-01
    z[1,6,3]  R1388     7.6278068125247955e-02
    z[1,6,3]  R1389     -1.2785153090953827e-01
    z[1,6,3]  R1390     -3.0141493678092957e-01
    z[1,6,3]  R1391     3.7640803493559361e-03
    z[1,6,3]  R1392     4.3715375661849976e-01
    z[1,6,3]  R1393     5.1293814182281494e-01
    z[1,6,3]  R1394     1.5632462501525879e-01
    z[1,6,3]  R1395     6.3311499357223511e-01
    z[1,6,3]  R1396     -5.8447301387786865e-01
    z[1,6,3]  R1397     -2.7181667089462280e-01
    z[1,6,3]  R1398     -7.3082715272903442e-02
    z[1,6,3]  R1399     -3.0466508865356445e-01
    z[1,6,3]  R1400     -1.4586928486824036e-01
    z[1,6,3]  R1401     -3.5448685288429260e-01
    z[1,6,3]  R1402     5.7399606704711914e-01
    z[1,6,3]  R1403     -5.2418279647827148e-01
    z[1,6,3]  R1404     -0.277119517326355
    z[1,6,3]  R1405     -1.5559767186641693e-01
    z[1,6,3]  R1406     -4.8624446988105774e-01
    z[1,6,3]  R1407     -1.8034832552075386e-02
    z[1,6,3]  R1408     3.2120910286903381e-01
    z[1,6,3]  R1409     2.6803153753280640e-01
    z[1,6,3]  R1410     -4.8867025971412659e-01
    z[1,6,3]  R1411     -7.2287283837795258e-02
    z[1,6,3]  R1412     5.6514286994934082e-01
    z[1,6,3]  R1413     2.9438361525535583e-01
    z[1,6,3]  R1414     8.9321218430995941e-02
    z[1,6,3]  R1415     1.5312604606151581e-02
    z[1,6,3]  R1416     -0.288524866104126
    z[1,6,3]  R1417     0.1168212890625
    z[1,6,3]  R1418     1.8679147958755493e-01
    z[1,6,3]  R1419     -4.4278789311647415e-02
    z[1,6,3]  R1420     7.9929538071155548e-02
    z[1,6,3]  R1421     2.9882493615150452e-01
    z[1,6,3]  R1422     0.0489862896502018
    z[1,6,3]  R1423     -3.0913609080016613e-03
    z[1,6,3]  R1424     6.4784783124923706e-01
    z[1,6,3]  R1425     -5.0599642097949982e-02
    z[1,6,3]  R1426     7.8698612749576569e-02
    z[1,6,3]  R1427     1.6925598680973053e-01
    z[1,6,3]  R1428     -3.2823413610458374e-01
    z[1,6,3]  R1429     3.4984898567199707e-01
    z[1,6,3]  R1430     -3.0766350030899048e-01
    z[1,6,3]  R1431     4.0364719927310944e-02
    z[1,6,3]  R1432     -2.7162888646125793e-01
    z[1,6,3]  R1433     -1.4464857056736946e-02
    z[1,6,3]  R1434     8.4742859005928040e-02
    z[1,6,3]  R1435     -1.9598224759101868e-01
    z[1,6,3]  R1436     4.3875631690025330e-01
    z[1,6,3]  R1437     -1.6346287727355957e-01
    z[1,6,3]  R1438     -6.8979716300964355e-01
    z[1,6,3]  R1439     -3.6139088869094849e-01
    z[1,6,3]  R1440     -4.2000424861907959e-01
    z[1,6,3]  R1441     -6.9814813137054443e-01
    z[1,6,3]  R1442     -7.1037340164184570e-01
    z[1,6,3]  R1443     2.2700959444046021e-01
    z[1,6,3]  R1444     0.538135290145874
    z[1,6,3]  R1445     -2.0437745749950409e-01
    z[1,6,3]  R1446     8.8150733709335327e-01
    z[1,6,3]  R1447     -3.2526946067810059e-01
    z[1,6,3]  R1448     -1.4847362041473389e-01
    z[1,6,3]  R1449     5.6813931465148926e-01
    z[1,6,3]  R1450     -9.4906553626060486e-02
    z[1,6,3]  R1451     -6.2504941225051880e-01
    z[1,6,3]  R1452     2.7463027834892273e-01
    z[1,6,3]  R1453     -0.272591233253479
    z[1,6,3]  R1454     -7.9053580760955811e-01
    z[1,6,3]  R1455     -1.2500332295894623e-01
    z[1,6,3]  R1456     -2.5557151436805725e-01
    z[1,6,3]  R1457     -1.2475780397653580e-01
    z[1,6,3]  R1458     -3.4341163933277130e-02
    z[1,6,3]  R1459     -2.7871277928352356e-01
    z[1,6,3]  R1460     -8.3474278450012207e-01
    z[1,6,3]  R1461     -6.9614422321319580e-01
    z[1,6,3]  R1462     -6.7734891176223755e-01
    z[1,6,3]  R1463     -6.7219221591949463e-01
    z[1,6,3]  R1464     -3.2140710949897766e-01
    z[1,6,3]  R1465     -1.2192024849355221e-02
    z[1,6,3]  R1466     3.0854457616806030e-01
    z[1,6,3]  R1467     4.8076364398002625e-01
    z[1,6,3]  R1468     -9.0143275260925293e-01
    z[1,6,3]  R1469     -5.5771899223327637e-01
    z[1,6,3]  R1470     -8.2206577062606812e-01
    z[1,6,3]  R1471     -0.804474413394928
    z[1,6,3]  R1472     1.1394319683313370e-01
    z[1,6,3]  R1473     -1.3347879052162170e-01
    z[1,6,3]  R1474     2.9186752438545227e-01
    z[1,6,3]  R1475     3.9525943994522095e-01
    z[1,6,4]  R15       -1
    z[1,6,4]  R60       1
    z[1,6,4]  R1363     -1
    z[1,6,4]  R1364     1
    z[1,6,4]  R1369     3.7444502115249634e-01
    z[1,6,4]  R1370     4.6636760234832764e-01
    z[1,6,4]  R1371     7.1435712277889252e-02
    z[1,6,4]  R1372     3.0189543962478638e-01
    z[1,6,4]  R1373     4.6917036175727844e-01
    z[1,6,4]  R1374     -6.2298811972141266e-02
    z[1,6,4]  R1375     1.1157064139842987e-01
    z[1,6,4]  R1376     1.7434763908386230e-01
    z[1,6,4]  R1377     0.265186071395874
    z[1,6,4]  R1378     8.1869371235370636e-02
    z[1,6,4]  R1379     -0.0295050460845232
    z[1,6,4]  R1380     4.1165456175804138e-02
    z[1,6,4]  R1381     1.4436149597167969e-01
    z[1,6,4]  R1382     -7.9460576176643372e-02
    z[1,6,4]  R1383     7.5569534301757812e-01
    z[1,6,4]  R1384     -5.1839772611856461e-02
    z[1,6,4]  R1385     1.8890835344791412e-01
    z[1,6,4]  R1386     -2.3591178655624390e-01
    z[1,6,4]  R1387     -3.0672883987426758e-01
    z[1,6,4]  R1388     -1.2151244282722473e-01
    z[1,6,4]  R1389     -4.5494616031646729e-01
    z[1,6,4]  R1390     -5.7108914852142334e-01
    z[1,6,4]  R1391     -1.4176666736602783e-01
    z[1,6,4]  R1392     -3.3100968599319458e-01
    z[1,6,4]  R1393     1.0167949646711349e-01
    z[1,6,4]  R1394     -3.1500551104545593e-01
    z[1,6,4]  R1395     -2.4191634356975555e-01
    z[1,6,4]  R1396     -2.6066654920578003e-01
    z[1,6,4]  R1397     4.7065809369087219e-02
    z[1,6,4]  R1398     -2.2838643193244934e-01
    z[1,6,4]  R1399     -1.7407071590423584e-01
    z[1,6,4]  R1400     1.1996034532785416e-01
    z[1,6,4]  R1401     3.4921982884407043e-01
    z[1,6,4]  R1402     1.6590552031993866e-01
    z[1,6,4]  R1403     3.6356106400489807e-01
    z[1,6,4]  R1404     0.567359983921051
    z[1,6,4]  R1405     -4.1081428527832031e-01
    z[1,6,4]  R1406     -2.4256144464015961e-01
    z[1,6,4]  R1407     -6.1225313693284988e-02
    z[1,6,4]  R1408     -2.1430957317352295e-01
    z[1,6,4]  R1409     -3.9447724819183350e-01
    z[1,6,4]  R1410     -1.9413267076015472e-01
    z[1,6,4]  R1411     5.8033210039138794e-01
    z[1,6,4]  R1412     -3.3854478597640991e-01
    z[1,6,4]  R1413     -2.6605397462844849e-01
    z[1,6,4]  R1414     -1.3745093345642090e-01
    z[1,6,4]  R1415     6.3053965568542480e-02
    z[1,6,4]  R1416     2.9617384076118469e-01
    z[1,6,4]  R1417     1.8876156210899353e-01
    z[1,6,4]  R1418     3.4189215302467346e-01
    z[1,6,4]  R1419     -1.3627833127975464e-01
    z[1,6,4]  R1420     -0.111341193318367
    z[1,6,4]  R1421     4.4122478365898132e-01
    z[1,6,4]  R1422     -4.4462826102972031e-02
    z[1,6,4]  R1423     4.0168440341949463e-01
    z[1,6,4]  R1424     2.2923342883586884e-01
    z[1,6,4]  R1425     -4.7273480892181396e-01
    z[1,6,4]  R1426     5.8079534769058228e-01
    z[1,6,4]  R1427     2.5078555941581726e-01
    z[1,6,4]  R1428     6.5549755096435547e-01
    z[1,6,4]  R1429     -5.1414966583251953e-01
    z[1,6,4]  R1430     -5.3345358371734619e-01
    z[1,6,4]  R1431     -1.3015829026699066e-01
    z[1,6,4]  R1432     -8.5632158443331718e-03
    z[1,6,4]  R1433     -2.7972236275672913e-01
    z[1,6,4]  R1434     3.5864907503128052e-01
    z[1,6,4]  R1435     -4.1146072745323181e-01
    z[1,6,4]  R1436     -3.7646195292472839e-01
    z[1,6,4]  R1437     -7.9846596345305443e-03
    z[1,6,4]  R1438     1.5329687297344208e-01
    z[1,6,4]  R1439     -6.2212800979614258e-01
    z[1,6,4]  R1440     5.5183735676109791e-03
    z[1,6,4]  R1441     -2.9356116056442261e-01
    z[1,6,4]  R1442     -4.8711401224136353e-01
    z[1,6,4]  R1443     -1.0112939774990082e-01
    z[1,6,4]  R1444     3.0689540505409241e-01
    z[1,6,4]  R1445     -9.3758301809430122e-03
    z[1,6,4]  R1446     2.0063920319080353e-01
    z[1,6,4]  R1447     5.8596688508987427e-01
    z[1,6,4]  R1448     2.3003134131431580e-01
    z[1,6,4]  R1449     -6.3085383735597134e-03
    z[1,6,4]  R1450     2.6756027340888977e-01
    z[1,6,4]  R1451     5.7051169872283936e-01
    z[1,6,4]  R1452     -3.7801295518875122e-01
    z[1,6,4]  R1453     2.4625961482524872e-01
    z[1,6,4]  R1454     -1.7379105091094971e-01
    z[1,6,4]  R1455     2.6957783102989197e-01
    z[1,6,4]  R1456     -0.25974240899086
    z[1,6,4]  R1457     5.2982503175735474e-01
    z[1,6,4]  R1458     5.3899204730987549e-01
    z[1,6,4]  R1459     8.0369651317596436e-01
    z[1,6,4]  R1460     6.0987651348114014e-02
    z[1,6,4]  R1461     4.5826774090528488e-02
    z[1,6,4]  R1462     -5.1132738590240479e-01
    z[1,6,4]  R1463     -2.9330241680145264e-01
    z[1,6,4]  R1464     1.3294976949691772e-01
    z[1,6,4]  R1465     2.1586577594280243e-01
    z[1,6,4]  R1466     2.0460948348045349e-01
    z[1,6,4]  R1467     7.9268246889114380e-02
    z[1,6,4]  R1468     -3.7390011548995972e-01
    z[1,6,4]  R1469     1.3041408360004425e-01
    z[1,6,4]  R1470     5.6369446218013763e-02
    z[1,6,4]  R1471     -2.6048952341079712e-01
    z[1,6,4]  R1472     1.4222750067710876e-01
    z[1,6,4]  R1473     -5.8729931712150574e-02
    z[1,6,4]  R1474     -1.0785602778196335e-01
    z[1,6,4]  R1475     -6.0210663825273514e-02
    z[1,6,5]  R16       -1
    z[1,6,5]  R61       1
    z[1,6,5]  R1365     -1
    z[1,6,5]  R1366     1
    z[1,6,5]  R1369     1.8587511777877808e-01
    z[1,6,5]  R1370     -1.4139805734157562e-01
    z[1,6,5]  R1371     4.5469993352890015e-01
    z[1,6,5]  R1372     8.6127929389476776e-02
    z[1,6,5]  R1373     0.0432896763086319
    z[1,6,5]  R1374     7.2182303667068481e-01
    z[1,6,5]  R1375     5.4944694042205811e-01
    z[1,6,5]  R1376     5.7868117094039917e-01
    z[1,6,5]  R1377     -0.176085963845253
    z[1,6,5]  R1378     -1.6225415468215942e-01
    z[1,6,5]  R1379     -2.5128121487796307e-03
    z[1,6,5]  R1380     6.8202703259885311e-03
    z[1,6,5]  R1381     2.7587673068046570e-01
    z[1,6,5]  R1382     -1.8212584778666496e-02
    z[1,6,5]  R1383     3.5121780633926392e-01
    z[1,6,5]  R1384     -4.2768475413322449e-01
    z[1,6,5]  R1385     1.0120529681444168e-01
    z[1,6,5]  R1386     -7.2193038463592529e-01
    z[1,6,5]  R1387     -8.1432253122329712e-02
    z[1,6,5]  R1388     -1.8198329210281372e-01
    z[1,6,5]  R1389     -6.8062287569046021e-01
    z[1,6,5]  R1390     -4.0630817413330078e-01
    z[1,6,5]  R1391     -4.6032306551933289e-01
    z[1,6,5]  R1392     -1.7219726741313934e-01
    z[1,6,5]  R1393     -0.430600643157959
    z[1,6,5]  R1394     -5.0054562091827393e-01
    z[1,6,5]  R1395     5.8270907029509544e-03
    z[1,6,5]  R1396     2.9229742288589478e-01
    z[1,6,5]  R1397     6.6445773839950562e-01
    z[1,6,5]  R1398     2.1083930134773254e-01
    z[1,6,5]  R1399     2.4733105301856995e-01
    z[1,6,5]  R1400     4.7527906298637390e-01
    z[1,6,5]  R1401     5.6023615598678589e-01
    z[1,6,5]  R1402     -2.4616421759128571e-01
    z[1,6,5]  R1403     3.7608388066291809e-01
    z[1,6,5]  R1404     1.9763027131557465e-01
    z[1,6,5]  R1405     -3.1555801630020142e-01
    z[1,6,5]  R1406     1.6353559494018555e-01
    z[1,6,5]  R1407     -1.9240470230579376e-01
    z[1,6,5]  R1408     0.129002645611763
    z[1,6,5]  R1409     5.4752331972122192e-01
    z[1,6,5]  R1410     7.5934166088700294e-03
    z[1,6,5]  R1411     3.3185136318206787e-01
    z[1,6,5]  R1412     1.9408319890499115e-01
    z[1,6,5]  R1413     -1.7621102929115295e-01
    z[1,6,5]  R1414     -7.7011808753013611e-02
    z[1,6,5]  R1415     -1.5127140283584595e-01
    z[1,6,5]  R1416     -4.7354641556739807e-01
    z[1,6,5]  R1417     1.2884079478681087e-02
    z[1,6,5]  R1418     0.528590977191925
    z[1,6,5]  R1419     7.1026724576950073e-01
    z[1,6,5]  R1420     9.1388291120529175e-01
    z[1,6,5]  R1421     -2.9233081266283989e-02
    z[1,6,5]  R1422     -1.8909063935279846e-01
    z[1,6,5]  R1423     4.2841640114784241e-01
    z[1,6,5]  R1424     1.3852208852767944e-01
    z[1,6,5]  R1425     -2.5052863359451294e-01
    z[1,6,5]  R1426     -2.0143085718154907e-01
    z[1,6,5]  R1427     2.2526636719703674e-01
    z[1,6,5]  R1428     -4.2061571031808853e-02
    z[1,6,5]  R1429     -2.2896220907568932e-02
    z[1,6,5]  R1430     -2.8610411286354065e-01
    z[1,6,5]  R1431     1.5323950350284576e-01
    z[1,6,5]  R1432     -1.5778636932373047e-01
    z[1,6,5]  R1433     -4.3013781309127808e-02
    z[1,6,5]  R1434     3.2962355017662048e-01
    z[1,6,5]  R1435     4.1474539786577225e-02
    z[1,6,5]  R1436     -6.0724008083343506e-01
    z[1,6,5]  R1437     4.2287012934684753e-01
    z[1,6,5]  R1438     -5.1012925803661346e-02
    z[1,6,5]  R1439     1.2685698270797729e-01
    z[1,6,5]  R1440     -1.9729802012443542e-01
    z[1,6,5]  R1441     6.3614523410797119e-01
    z[1,6,5]  R1442     3.1838470697402954e-01
    z[1,6,5]  R1443     -4.6052387356758118e-01
    z[1,6,5]  R1444     1.6816663742065430e-01
    z[1,6,5]  R1445     5.0231683254241943e-01
    z[1,6,5]  R1446     1.0454358160495758e-01
    z[1,6,5]  R1447     0.260141521692276
    z[1,6,5]  R1448     9.3274883925914764e-02
    z[1,6,5]  R1449     1.6127622127532959e-01
    z[1,6,5]  R1450     6.9633203744888306e-01
    z[1,6,5]  R1451     2.9558527469635010e-01
    z[1,6,5]  R1452     -1.0555070638656616e-01
    z[1,6,5]  R1453     1.5233403444290161e-01
    z[1,6,5]  R1454     -5.9906851500272751e-02
    z[1,6,5]  R1455     -0.296150267124176
    z[1,6,5]  R1456     -1.8459224700927734e-01
    z[1,6,5]  R1457     -1.4714795351028442e-01
    z[1,6,5]  R1458     7.5066995620727539e-01
    z[1,6,5]  R1459     1.3029675185680389e-01
    z[1,6,5]  R1460     -1.4577963948249817e-01
    z[1,6,5]  R1461     -4.6445944905281067e-01
    z[1,6,5]  R1462     -1.0121800005435944e-01
    z[1,6,5]  R1463     -4.0525132417678833e-01
    z[1,6,5]  R1464     1.6238564252853394e-01
    z[1,6,5]  R1465     -2.9147368669509888e-01
    z[1,6,5]  R1466     -1.3680888712406158e-01
    z[1,6,5]  R1467     -1.6233567893505096e-01
    z[1,6,5]  R1468     1.5122829377651215e-01
    z[1,6,5]  R1469     4.0020561218261719e-01
    z[1,6,5]  R1470     -1.0169178247451782e-01
    z[1,6,5]  R1471     -6.7678354680538177e-02
    z[1,6,5]  R1472     -2.8892930597066879e-02
    z[1,6,5]  R1473     -1.4586250483989716e-01
    z[1,6,5]  R1474     -7.0206761360168457e-02
    z[1,6,5]  R1475     1.4605778455734253e-01
    z[1,6,6]  R17       -1
    z[1,6,6]  R62       1
    z[1,6,6]  R1367     -1
    z[1,6,6]  R1368     1
    z[1,6,6]  R1369     2.8560683131217957e-01
    z[1,6,6]  R1370     3.9391836524009705e-01
    z[1,6,6]  R1371     7.0469003915786743e-01
    z[1,6,6]  R1372     7.5557726621627808e-01
    z[1,6,6]  R1373     -3.5521391034126282e-01
    z[1,6,6]  R1374     -3.6219093948602676e-02
    z[1,6,6]  R1375     -3.3626472949981689e-01
    z[1,6,6]  R1376     -1.1651092767715454e-01
    z[1,6,6]  R1377     1.8766130506992340e-01
    z[1,6,6]  R1378     2.1053564548492432e-01
    z[1,6,6]  R1379     -1.6096076369285583e-01
    z[1,6,6]  R1380     2.3172810673713684e-01
    z[1,6,6]  R1381     4.1252526640892029e-01
    z[1,6,6]  R1382     -1.9073310494422913e-01
    z[1,6,6]  R1383     -1.2972231209278107e-01
    z[1,6,6]  R1384     -5.2020758390426636e-01
    z[1,6,6]  R1385     -7.9890716075897217e-01
    z[1,6,6]  R1386     -4.0473058819770813e-01
    z[1,6,6]  R1387     -3.6321204900741577e-01
    z[1,6,6]  R1388     -5.4574948549270630e-01
    z[1,6,6]  R1389     6.5559722483158112e-02
    z[1,6,6]  R1390     3.6005118489265442e-01
    z[1,6,6]  R1391     -4.5117178559303284e-01
    z[1,6,6]  R1392     -5.4073441028594971e-01
    z[1,6,6]  R1393     1.2992599513381720e-03
    z[1,6,6]  R1394     2.1642138063907623e-01
    z[1,6,6]  R1395     3.4340581297874451e-01
    z[1,6,6]  R1396     -3.2740628719329834e-01
    z[1,6,6]  R1397     -6.2006378173828125e-01
    z[1,6,6]  R1398     2.7123183012008667e-01
    z[1,6,6]  R1399     -4.2300187051296234e-02
    z[1,6,6]  R1400     1.2370651215314865e-01
    z[1,6,6]  R1401     -4.7015976905822754e-01
    z[1,6,6]  R1402     3.4981733560562134e-01
    z[1,6,6]  R1403     -7.3354914784431458e-02
    z[1,6,6]  R1404     -2.4641756713390350e-01
    z[1,6,6]  R1405     -2.3655369877815247e-02
    z[1,6,6]  R1406     4.4243231415748596e-02
    z[1,6,6]  R1407     -2.6326501369476318e-01
    z[1,6,6]  R1408     -6.7819356918334961e-02
    z[1,6,6]  R1409     -5.0240176916122437e-01
    z[1,6,6]  R1410     -2.6337611675262451e-01
    z[1,6,6]  R1411     -3.5471022129058838e-02
    z[1,6,6]  R1412     1.9848808646202087e-01
    z[1,6,6]  R1413     -6.9091357290744781e-02
    z[1,6,6]  R1414     3.4583261609077454e-01
    z[1,6,6]  R1415     1.0074346512556076e-01
    z[1,6,6]  R1416     2.9694160819053650e-01
    z[1,6,6]  R1417     2.5770869851112366e-01
    z[1,6,6]  R1418     4.4780775904655457e-01
    z[1,6,6]  R1419     -2.4089443683624268e-01
    z[1,6,6]  R1420     1.5373152494430542e-01
    z[1,6,6]  R1421     -0.0870768278837204
    z[1,6,6]  R1422     -5.4401624202728271e-01
    z[1,6,6]  R1423     -2.7572691440582275e-01
    z[1,6,6]  R1424     2.6575896143913269e-01
    z[1,6,6]  R1425     4.4204148650169373e-01
    z[1,6,6]  R1426     8.7261833250522614e-02
    z[1,6,6]  R1427     -3.0299395322799683e-01
    z[1,6,6]  R1428     -2.7117198705673218e-01
    z[1,6,6]  R1429     6.2765669822692871e-01
    z[1,6,6]  R1430     4.0960687398910522e-01
    z[1,6,6]  R1431     -1.7640371620655060e-01
    z[1,6,6]  R1432     -0.0567912831902504
    z[1,6,6]  R1433     -3.9269987493753433e-02
    z[1,6,6]  R1434     3.5853415727615356e-01
    z[1,6,6]  R1435     4.4118392467498779e-01
    z[1,6,6]  R1436     2.8538459539413452e-01
    z[1,6,6]  R1437     3.2892918586730957e-01
    z[1,6,6]  R1438     2.1122667193412781e-01
    z[1,6,6]  R1439     1.9000871479511261e-01
    z[1,6,6]  R1440     3.5023361444473267e-01
    z[1,6,6]  R1441     7.2476804256439209e-02
    z[1,6,6]  R1442     -2.7893170714378357e-01
    z[1,6,6]  R1443     1.7076477408409119e-01
    z[1,6,6]  R1444     -4.8884540796279907e-01
    z[1,6,6]  R1445     -1.2712916731834412e-01
    z[1,6,6]  R1446     -2.4725881218910217e-01
    z[1,6,6]  R1447     -6.3336426019668579e-01
    z[1,6,6]  R1448     5.7357203215360641e-02
    z[1,6,6]  R1449     -0.268635094165802
    z[1,6,6]  R1450     1.4303991198539734e-01
    z[1,6,6]  R1451     1.2412270158529282e-01
    z[1,6,6]  R1452     6.1146342754364014e-01
    z[1,6,6]  R1453     -8.3838403224945068e-01
    z[1,6,6]  R1454     -5.3668224811553955e-01
    z[1,6,6]  R1455     -2.7634406089782715e-01
    z[1,6,6]  R1456     3.9433974027633667e-01
    z[1,6,6]  R1457     -2.6123058050870895e-02
    z[1,6,6]  R1458     -1.3918830454349518e-01
    z[1,6,6]  R1459     3.0937612056732178e-01
    z[1,6,6]  R1460     -4.1227099299430847e-01
    z[1,6,6]  R1461     8.1027291715145111e-02
    z[1,6,6]  R1462     2.8887173533439636e-01
    z[1,6,6]  R1463     7.2796165943145752e-02
    z[1,6,6]  R1464     1.3282217085361481e-01
    z[1,6,6]  R1465     0.233786940574646
    z[1,6,6]  R1466     3.7475389242172241e-01
    z[1,6,6]  R1467     -5.4427143186330795e-03
    z[1,6,6]  R1468     -2.4663519114255905e-02
    z[1,6,6]  R1469     -6.5523463487625122e-01
    z[1,6,6]  R1470     3.6728808283805847e-01
    z[1,6,6]  R1471     -2.4440322816371918e-01
    z[1,6,6]  R1472     1.0210485011339188e-01
    z[1,6,6]  R1473     -1.0901399701833725e-01
    z[1,6,6]  R1474     -7.4868492782115936e-02
    z[1,6,6]  R1475     1.6749604837968946e-03
    z[6,1,0]  R11       1
    z[6,1,0]  R56       -1
    z[6,1,0]  R1476     -1
    z[6,1,0]  R1477     1
    z[6,1,0]  R1490     -1.3540515303611755e-01
    z[6,1,0]  R1491     -1.8146499991416931e-01
    z[6,1,0]  R1492     -1.1458253115415573e-01
    z[6,1,0]  R1493     2.4590075016021729e-01
    z[6,1,0]  R1494     -1.9872394204139709e-01
    z[6,1,0]  R1495     -3.5660693049430847e-01
    z[6,1,0]  R1496     1.5453067421913147e-01
    z[6,1,0]  R1497     2.2420710325241089e-01
    z[6,1,0]  R1498     1.5158204734325409e-01
    z[6,1,0]  R1499     2.6731389760971069e-01
    z[6,1,0]  R1500     -5.2680999040603638e-01
    z[6,1,0]  R1501     3.3764970302581787e-01
    z[6,1,0]  R1502     -1.2792757153511047e-01
    z[6,1,0]  R1503     1.6103994846343994e-01
    z[6,1,0]  R1504     5.2135378122329712e-01
    z[6,1,0]  R1505     5.9990906715393066e-01
    z[6,1,0]  R1506     3.3722755312919617e-01
    z[6,1,0]  R1507     1.8013438582420349e-01
    z[6,1,0]  R1508     -0.107862688601017
    z[6,1,0]  R1509     3.6219507455825806e-01
    z[6,1,0]  R1510     1.5011836588382721e-01
    z[6,1,0]  R1511     1.5852367877960205e-01
    z[6,1,0]  R1512     -6.0171049833297729e-01
    z[6,1,0]  R1513     5.0972029566764832e-03
    z[6,1,0]  R1514     -2.3490250110626221e-01
    z[6,1,0]  R1515     -0.58235764503479
    z[6,1,0]  R1516     -3.8865572214126587e-01
    z[6,1,0]  R1517     -6.6175174713134766e-01
    z[6,1,0]  R1518     1.3481132686138153e-01
    z[6,1,0]  R1519     3.1511485576629639e-02
    z[6,1,0]  R1520     -9.6586331725120544e-02
    z[6,1,0]  R1521     -2.2670675814151764e-01
    z[6,1,0]  R1522     3.0439281463623047e-01
    z[6,1,0]  R1523     -3.5883578658103943e-01
    z[6,1,0]  R1524     -3.6778151988983154e-01
    z[6,1,0]  R1525     1.4055030420422554e-02
    z[6,1,0]  R1526     -2.7112754061818123e-02
    z[6,1,0]  R1527     1.8437290191650391e-01
    z[6,1,0]  R1528     3.1333580613136292e-01
    z[6,1,0]  R1529     1.6550573706626892e-01
    z[6,1,0]  R1530     -2.2626711428165436e-01
    z[6,1,0]  R1531     -3.5421958565711975e-01
    z[6,1,0]  R1532     1.0648952424526215e-01
    z[6,1,0]  R1533     0.0934305191040039
    z[6,1,0]  R1534     -1.3700267672538757e-01
    z[6,1,0]  R1535     -2.2628770768642426e-01
    z[6,1,0]  R1536     0.297559529542923
    z[6,1,0]  R1537     1.7040875554084778e-01
    z[6,1,0]  R1538     0.509533703327179
    z[6,1,0]  R1539     0.547876238822937
    z[6,1,0]  R1540     -1.1656825244426727e-01
    z[6,1,0]  R1541     -2.2897545248270035e-02
    z[6,1,0]  R1542     0.0225005391985178
    z[6,1,0]  R1543     -2.7690127491950989e-01
    z[6,1,0]  R1544     2.2823049128055573e-01
    z[6,1,0]  R1545     2.1646852791309357e-01
    z[6,1,0]  R1546     6.0384386777877808e-01
    z[6,1,0]  R1547     0.574550986289978
    z[6,1,0]  R1548     -2.3927323520183563e-01
    z[6,1,0]  R1549     -9.3068093061447144e-02
    z[6,1,0]  R1550     -1.8396428227424622e-01
    z[6,1,0]  R1551     1.1003871262073517e-01
    z[6,1,0]  R1552     -4.2539175599813461e-02
    z[6,1,0]  R1553     -3.0694505572319031e-01
    z[6,1,0]  R1554     2.3849646747112274e-01
    z[6,1,0]  R1555     -2.5389662384986877e-01
    z[6,1,0]  R1556     -3.2029229402542114e-01
    z[6,1,0]  R1557     -1.6619090735912323e-01
    z[6,1,0]  R1558     6.6466385126113892e-01
    z[6,1,0]  R1559     -4.7198975086212158e-01
    z[6,1,0]  R1560     -7.8905403614044189e-01
    z[6,1,0]  R1561     -0.89189612865448
    z[6,1,0]  R1562     -3.1033545732498169e-01
    z[6,1,0]  R1563     -5.1954627037048340e-01
    z[6,1,0]  R1564     -3.0689609050750732e-01
    z[6,1,0]  R1565     3.9101323485374451e-01
    z[6,1,0]  R1566     -2.4056018888950348e-01
    z[6,1,0]  R1567     -2.3183842003345490e-01
    z[6,1,0]  R1568     3.5448500514030457e-01
    z[6,1,0]  R1569     1.2213188409805298e-01
    z[6,1,0]  R1570     4.4516941905021667e-01
    z[6,1,0]  R1571     7.5336650013923645e-02
    z[6,1,0]  R1572     2.0835784077644348e-01
    z[6,1,0]  R1573     3.7897145748138428e-01
    z[6,1,0]  R1574     -2.0715612173080444e-01
    z[6,1,0]  R1575     6.3558273017406464e-02
    z[6,1,0]  R1576     1.4043904957361519e-04
    z[6,1,0]  R1577     -5.2889108657836914e-01
    z[6,1,0]  R1578     0.124534472823143
    z[6,1,0]  R1579     3.2512968778610229e-01
    z[6,1,0]  R1580     1.2217810004949570e-01
    z[6,1,0]  R1581     -0.0638943687081337
    z[6,1,0]  R1582     3.9143315516412258e-03
    z[6,1,0]  R1583     -5.3495984524488449e-02
    z[6,1,0]  R1584     -6.1061024665832520e-01
    z[6,1,0]  R1585     -3.2372646033763885e-02
    z[6,1,0]  R1586     -1.4620240032672882e-01
    z[6,1,0]  R1587     -5.6994175910949707e-01
    z[6,1,0]  R1588     5.4328281432390213e-02
    z[6,1,0]  R1589     -7.7049273252487183e-01
    z[6,1,0]  R1590     -3.6872324347496033e-01
    z[6,1,0]  R1591     -3.8276901841163635e-01
    z[6,1,0]  R1592     -0.460308313369751
    z[6,1,0]  R1593     -3.8408553600311279e-01
    z[6,1,0]  R1594     5.7115048170089722e-01
    z[6,1,0]  R1595     -2.7225458621978760e-01
    z[6,1,0]  R1596     5.5754220485687256e-01
    z[6,1,1]  R12       1
    z[6,1,1]  R57       -1
    z[6,1,1]  R1478     -1
    z[6,1,1]  R1479     1
    z[6,1,1]  R1490     5.9156060218811035e-01
    z[6,1,1]  R1491     6.1252003908157349e-01
    z[6,1,1]  R1492     3.3040410280227661e-01
    z[6,1,1]  R1493     7.1475124359130859e-01
    z[6,1,1]  R1494     7.8449553251266479e-01
    z[6,1,1]  R1495     6.9461055099964142e-02
    z[6,1,1]  R1496     -6.2608772516250610e-01
    z[6,1,1]  R1497     0.651689350605011
    z[6,1,1]  R1498     -0.763340950012207
    z[6,1,1]  R1499     -6.0725015401840210e-01
    z[6,1,1]  R1500     2.6873454451560974e-01
    z[6,1,1]  R1501     2.9936638474464417e-01
    z[6,1,1]  R1502     5.9346508979797363e-01
    z[6,1,1]  R1503     -9.4619792699813843e-01
    z[6,1,1]  R1504     -0.740623414516449
    z[6,1,1]  R1505     -6.8825989961624146e-01
    z[6,1,1]  R1506     -7.1170818805694580e-01
    z[6,1,1]  R1507     -7.4227726459503174e-01
    z[6,1,1]  R1508     4.0774738788604736e-01
    z[6,1,1]  R1509     -7.3594230413436890e-01
    z[6,1,1]  R1510     5.5974102020263672e-01
    z[6,1,1]  R1511     5.8711689710617065e-01
    z[6,1,1]  R1512     3.8535785675048828e-01
    z[6,1,1]  R1513     -3.0366463586688042e-02
    z[6,1,1]  R1514     1.5404240787029266e-01
    z[6,1,1]  R1515     3.3650639653205872e-01
    z[6,1,1]  R1516     4.0871241688728333e-01
    z[6,1,1]  R1517     -1.7309428751468658e-01
    z[6,1,1]  R1518     2.8831285238265991e-01
    z[6,1,1]  R1519     6.1456203460693359e-02
    z[6,1,1]  R1520     0.931501567363739
    z[6,1,1]  R1521     0.725002110004425
    z[6,1,1]  R1522     3.9444544911384583e-01
    z[6,1,1]  R1523     -1.6152249276638031e-01
    z[6,1,1]  R1524     2.9948723316192627e-01
    z[6,1,1]  R1525     2.3306940495967865e-01
    z[6,1,1]  R1526     -1.8271915614604950e-01
    z[6,1,1]  R1527     -8.4464186429977417e-01
    z[6,1,1]  R1528     -7.6121377944946289e-01
    z[6,1,1]  R1529     -8.0869638919830322e-01
    z[6,1,1]  R1530     0.27131387591362
    z[6,1,1]  R1531     5.6756451725959778e-02
    z[6,1,1]  R1532     -1.9486691057682037e-01
    z[6,1,1]  R1533     -5.3097051382064819e-01
    z[6,1,1]  R1534     -3.6388668417930603e-01
    z[6,1,1]  R1535     -4.2843598127365112e-01
    z[6,1,1]  R1536     -0.859521210193634
    z[6,1,1]  R1537     -0.878296434879303
    z[6,1,1]  R1538     -6.5130203962326050e-01
    z[6,1,1]  R1539     -6.2969833612442017e-01
    z[6,1,1]  R1540     8.3298072218894958e-02
    z[6,1,1]  R1541     1.2004360556602478e-01
    z[6,1,1]  R1542     -4.1857150197029114e-01
    z[6,1,1]  R1543     -3.4635263681411743e-01
    z[6,1,1]  R1544     -9.4786942005157471e-01
    z[6,1,1]  R1545     -9.4751822948455811e-01
    z[6,1,1]  R1546     -1.6938674449920654e-01
    z[6,1,1]  R1547     -0.0797528326511383
    z[6,1,1]  R1548     -2.3412662744522095e-01
    z[6,1,1]  R1549     -3.2256475090980530e-01
    z[6,1,1]  R1550     -3.6999046802520752e-01
    z[6,1,1]  R1551     -5.2285623550415039e-01
    z[6,1,1]  R1552     -4.6815851330757141e-01
    z[6,1,1]  R1553     -4.2803874611854553e-01
    z[6,1,1]  R1554     -7.1605294942855835e-01
    z[6,1,1]  R1555     6.4604789018630981e-01
    z[6,1,1]  R1556     8.5382020473480225e-01
    z[6,1,1]  R1557     8.7410008907318115e-01
    z[6,1,1]  R1558     -2.1206778287887573e-01
    z[6,1,1]  R1559     5.5650299787521362e-01
    z[6,1,1]  R1560     2.7068966627120972e-01
    z[6,1,1]  R1561     2.0389008522033691e-01
    z[6,1,1]  R1562     2.8315299749374390e-01
    z[6,1,1]  R1563     3.0223432183265686e-01
    z[6,1,1]  R1564     -1.4377743005752563e-01
    z[6,1,1]  R1565     -2.0649042725563049e-01
    z[6,1,1]  R1566     8.2114261388778687e-01
    z[6,1,1]  R1567     7.1400213241577148e-01
    z[6,1,1]  R1568     -3.3164060115814209e-01
    z[6,1,1]  R1569     -1.8140999972820282e-01
    z[6,1,1]  R1570     -5.1794147491455078e-01
    z[6,1,1]  R1571     -5.0821495056152344e-01
    z[6,1,1]  R1572     -6.5732920169830322e-01
    z[6,1,1]  R1573     -5.3367048501968384e-01
    z[6,1,1]  R1574     -5.9342402219772339e-01
    z[6,1,1]  R1575     2.9371902346611023e-01
    z[6,1,1]  R1576     3.0722531676292419e-01
    z[6,1,1]  R1577     7.0174783468246460e-01
    z[6,1,1]  R1578     -5.3573852777481079e-01
    z[6,1,1]  R1579     -7.3988282680511475e-01
    z[6,1,1]  R1580     -1.4559482038021088e-01
    z[6,1,1]  R1581     -6.6544854640960693e-01
    z[6,1,1]  R1582     2.6029470562934875e-01
    z[6,1,1]  R1583     0.684913694858551
    z[6,1,1]  R1584     5.3332304954528809e-01
    z[6,1,1]  R1585     7.8472161293029785e-01
    z[6,1,1]  R1586     8.9037430286407471e-01
    z[6,1,1]  R1587     0.710384726524353
    z[6,1,1]  R1588     -4.5226737856864929e-01
    z[6,1,1]  R1589     2.4580633640289307e-01
    z[6,1,1]  R1590     6.3817453384399414e-01
    z[6,1,1]  R1591     -5.0469082593917847e-01
    z[6,1,1]  R1592     7.7087897062301636e-01
    z[6,1,1]  R1593     7.6046824455261230e-01
    z[6,1,1]  R1594     7.8955745697021484e-01
    z[6,1,1]  R1595     2.1833692491054535e-01
    z[6,1,1]  R1596     7.0232802629470825e-01
    z[6,1,2]  R13       1
    z[6,1,2]  R58       -1
    z[6,1,2]  R1480     -1
    z[6,1,2]  R1481     1
    z[6,1,2]  R1490     -3.7073939893161878e-05
    z[6,1,2]  R1491     -9.4061434268951416e-02
    z[6,1,2]  R1492     -1.0151164606213570e-02
    z[6,1,2]  R1493     -3.6912170052528381e-01
    z[6,1,2]  R1494     -9.4815976917743683e-02
    z[6,1,2]  R1495     6.6864097118377686e-01
    z[6,1,2]  R1496     1.4853793382644653e-01
    z[6,1,2]  R1497     -2.0206044614315033e-01
    z[6,1,2]  R1498     5.1261745393276215e-02
    z[6,1,2]  R1499     5.7070064544677734e-01
    z[6,1,2]  R1500     1.9373928010463715e-01
    z[6,1,2]  R1501     -1.2308959662914276e-01
    z[6,1,2]  R1502     5.0703313201665878e-02
    z[6,1,2]  R1503     7.4863538146018982e-02
    z[6,1,2]  R1504     -2.7872905135154724e-01
    z[6,1,2]  R1505     -0.290794312953949
    z[6,1,2]  R1506     -8.2097806036472321e-02
    z[6,1,2]  R1507     1.1182001233100891e-01
    z[6,1,2]  R1508     1.9414447247982025e-01
    z[6,1,2]  R1509     -1.1578583717346191e-01
    z[6,1,2]  R1510     -3.4295099973678589e-01
    z[6,1,2]  R1511     -2.4560411274433136e-01
    z[6,1,2]  R1512     3.8912689685821533e-01
    z[6,1,2]  R1513     -1.2461658567190170e-01
    z[6,1,2]  R1514     3.0976501293480396e-03
    z[6,1,2]  R1515     4.9459049105644226e-01
    z[6,1,2]  R1516     1.7571765184402466e-01
    z[6,1,2]  R1517     4.7093614935874939e-01
    z[6,1,2]  R1518     -9.6561267971992493e-02
    z[6,1,2]  R1519     -2.7793669700622559e-01
    z[6,1,2]  R1520     -1.8980790674686432e-01
    z[6,1,2]  R1521     4.4485166668891907e-02
    z[6,1,2]  R1522     -4.0721407532691956e-01
    z[6,1,2]  R1523     1.6186350584030151e-01
    z[6,1,2]  R1524     4.1436710953712463e-01
    z[6,1,2]  R1525     -2.9058215022087097e-01
    z[6,1,2]  R1526     -1.3824518024921417e-01
    z[6,1,2]  R1527     -0.0147575493901968
    z[6,1,2]  R1528     -3.6450235638767481e-03
    z[6,1,2]  R1529     -1.9960529170930386e-03
    z[6,1,2]  R1530     -2.4927143007516861e-02
    z[6,1,2]  R1531     1.8710285425186157e-01
    z[6,1,2]  R1532     -2.4280165135860443e-01
    z[6,1,2]  R1533     -1.8334476277232170e-02
    z[6,1,2]  R1534     1.8672838807106018e-01
    z[6,1,2]  R1535     2.4049901962280273e-01
    z[6,1,2]  R1536     -8.7707303464412689e-02
    z[6,1,2]  R1537     1.1487445980310440e-01
    z[6,1,2]  R1538     -1.4127650856971741e-01
    z[6,1,2]  R1539     -1.9877615571022034e-01
    z[6,1,2]  R1540     -6.0105919837951660e-02
    z[6,1,2]  R1541     -0.25982666015625
    z[6,1,2]  R1542     0.0089586041867733
    z[6,1,2]  R1543     1.5497873723506927e-01
    z[6,1,2]  R1544     7.0586748421192169e-02
    z[6,1,2]  R1545     3.0409701168537140e-02
    z[6,1,2]  R1546     7.0663064718246460e-01
    z[6,1,2]  R1547     6.9450670480728149e-01
    z[6,1,2]  R1548     7.8288090229034424e-01
    z[6,1,2]  R1549     6.9121789932250977e-01
    z[6,1,2]  R1550     2.7046054601669312e-01
    z[6,1,2]  R1551     -9.0173922479152679e-02
    z[6,1,2]  R1552     0.612095057964325
    z[6,1,2]  R1553     4.0137669444084167e-01
    z[6,1,2]  R1554     -2.8709178790450096e-02
    z[6,1,2]  R1555     -3.5165694355964661e-01
    z[6,1,2]  R1556     7.7848076820373535e-02
    z[6,1,2]  R1557     -2.6500681042671204e-01
    z[6,1,2]  R1558     -1.8514315783977509e-01
    z[6,1,2]  R1559     5.4202932119369507e-01
    z[6,1,2]  R1560     -1.2013711780309677e-01
    z[6,1,2]  R1561     3.0058783292770386e-01
    z[6,1,2]  R1562     -3.3320057392120361e-01
    z[6,1,2]  R1563     -2.3354759812355042e-01
    z[6,1,2]  R1564     -2.6625505089759827e-01
    z[6,1,2]  R1565     2.5235649943351746e-01
    z[6,1,2]  R1566     -1.5740875899791718e-01
    z[6,1,2]  R1567     2.9138955473899841e-01
    z[6,1,2]  R1568     2.7108547091484070e-01
    z[6,1,2]  R1569     4.9036440253257751e-01
    z[6,1,2]  R1570     3.1304258108139038e-01
    z[6,1,2]  R1571     3.3663868904113770e-01
    z[6,1,2]  R1572     -2.5620761513710022e-01
    z[6,1,2]  R1573     -3.8797748088836670e-01
    z[6,1,2]  R1574     -1.6617652773857117e-01
    z[6,1,2]  R1575     5.5452769994735718e-01
    z[6,1,2]  R1576     5.9412352740764618e-02
    z[6,1,2]  R1577     2.2869819402694702e-01
    z[6,1,2]  R1578     7.1511673927307129e-01
    z[6,1,2]  R1579     -2.6457920670509338e-01
    z[6,1,2]  R1580     4.2584562301635742e-01
    z[6,1,2]  R1581     -1.1458848416805267e-01
    z[6,1,2]  R1582     -6.1519676446914673e-01
    z[6,1,2]  R1583     -1.7192934453487396e-01
    z[6,1,2]  R1584     -2.2272443771362305e-01
    z[6,1,2]  R1585     -2.4329580366611481e-01
    z[6,1,2]  R1586     -2.7469378709793091e-01
    z[6,1,2]  R1587     1.3224802911281586e-02
    z[6,1,2]  R1588     -1.1340240389108658e-01
    z[6,1,2]  R1589     3.0671819113194942e-03
    z[6,1,2]  R1590     5.8155737817287445e-02
    z[6,1,2]  R1591     2.9615920782089233e-01
    z[6,1,2]  R1592     -0.0243210606276989
    z[6,1,2]  R1593     -3.4894734621047974e-01
    z[6,1,2]  R1594     -1.1464491486549377e-01
    z[6,1,2]  R1595     -6.2834733724594116e-01
    z[6,1,2]  R1596     -2.8288549184799194e-01
    z[6,1,3]  R14       1
    z[6,1,3]  R59       -1
    z[6,1,3]  R1482     -1
    z[6,1,3]  R1483     1
    z[6,1,3]  R1490     1.8679147958755493e-01
    z[6,1,3]  R1491     -4.4278789311647415e-02
    z[6,1,3]  R1492     7.9929538071155548e-02
    z[6,1,3]  R1493     2.9882493615150452e-01
    z[6,1,3]  R1494     0.0489862896502018
    z[6,1,3]  R1495     -3.0913609080016613e-03
    z[6,1,3]  R1496     6.4784783124923706e-01
    z[6,1,3]  R1497     -5.0599642097949982e-02
    z[6,1,3]  R1498     7.8698612749576569e-02
    z[6,1,3]  R1499     1.6925598680973053e-01
    z[6,1,3]  R1500     -3.2823413610458374e-01
    z[6,1,3]  R1501     3.4984898567199707e-01
    z[6,1,3]  R1502     -3.0766350030899048e-01
    z[6,1,3]  R1503     4.0364719927310944e-02
    z[6,1,3]  R1504     -2.7162888646125793e-01
    z[6,1,3]  R1505     -1.4464857056736946e-02
    z[6,1,3]  R1506     8.4742859005928040e-02
    z[6,1,3]  R1507     -1.9598224759101868e-01
    z[6,1,3]  R1508     4.3875631690025330e-01
    z[6,1,3]  R1509     -1.6346287727355957e-01
    z[6,1,3]  R1510     -6.8979716300964355e-01
    z[6,1,3]  R1511     -3.6139088869094849e-01
    z[6,1,3]  R1512     -4.2000424861907959e-01
    z[6,1,3]  R1513     -6.9814813137054443e-01
    z[6,1,3]  R1514     -7.1037340164184570e-01
    z[6,1,3]  R1515     2.2700959444046021e-01
    z[6,1,3]  R1516     0.538135290145874
    z[6,1,3]  R1517     -2.0437745749950409e-01
    z[6,1,3]  R1518     8.8150733709335327e-01
    z[6,1,3]  R1519     -3.2526946067810059e-01
    z[6,1,3]  R1520     -1.4847362041473389e-01
    z[6,1,3]  R1521     5.6813931465148926e-01
    z[6,1,3]  R1522     -9.4906553626060486e-02
    z[6,1,3]  R1523     -6.2504941225051880e-01
    z[6,1,3]  R1524     2.7463027834892273e-01
    z[6,1,3]  R1525     -0.272591233253479
    z[6,1,3]  R1526     -7.9053580760955811e-01
    z[6,1,3]  R1527     -1.2500332295894623e-01
    z[6,1,3]  R1528     -2.5557151436805725e-01
    z[6,1,3]  R1529     -1.2475780397653580e-01
    z[6,1,3]  R1530     -3.4341163933277130e-02
    z[6,1,3]  R1531     -2.7871277928352356e-01
    z[6,1,3]  R1532     -8.3474278450012207e-01
    z[6,1,3]  R1533     -6.9614422321319580e-01
    z[6,1,3]  R1534     -6.7734891176223755e-01
    z[6,1,3]  R1535     -6.7219221591949463e-01
    z[6,1,3]  R1536     -3.2140710949897766e-01
    z[6,1,3]  R1537     -1.2192024849355221e-02
    z[6,1,3]  R1538     3.0854457616806030e-01
    z[6,1,3]  R1539     4.8076364398002625e-01
    z[6,1,3]  R1540     -9.0143275260925293e-01
    z[6,1,3]  R1541     -5.5771899223327637e-01
    z[6,1,3]  R1542     -8.2206577062606812e-01
    z[6,1,3]  R1543     -0.804474413394928
    z[6,1,3]  R1544     1.1394319683313370e-01
    z[6,1,3]  R1545     -1.3347879052162170e-01
    z[6,1,3]  R1546     2.9186752438545227e-01
    z[6,1,3]  R1547     3.9525943994522095e-01
    z[6,1,3]  R1548     -1.3675062358379364e-01
    z[6,1,3]  R1549     -1.2978547811508179e-01
    z[6,1,3]  R1550     -2.1833953261375427e-01
    z[6,1,3]  R1551     -0.192160502076149
    z[6,1,3]  R1552     2.3703585565090179e-01
    z[6,1,3]  R1553     1.8773065507411957e-01
    z[6,1,3]  R1554     4.6362329274415970e-02
    z[6,1,3]  R1555     -1.2510886788368225e-01
    z[6,1,3]  R1556     -1.6061370074748993e-01
    z[6,1,3]  R1557     -2.4646823108196259e-01
    z[6,1,3]  R1558     -6.7244774103164673e-01
    z[6,1,3]  R1559     -3.4394088387489319e-01
    z[6,1,3]  R1560     1.5020883083343506e-01
    z[6,1,3]  R1561     1.7196573317050934e-01
    z[6,1,3]  R1562     -3.5162393003702164e-02
    z[6,1,3]  R1563     -3.5772061347961426e-01
    z[6,1,3]  R1564     -0.360651433467865
    z[6,1,3]  R1565     1.1904857121407986e-02
    z[6,1,3]  R1566     1.0218356549739838e-01
    z[6,1,3]  R1567     7.6278068125247955e-02
    z[6,1,3]  R1568     -1.2785153090953827e-01
    z[6,1,3]  R1569     -3.0141493678092957e-01
    z[6,1,3]  R1570     3.7640803493559361e-03
    z[6,1,3]  R1571     4.3715375661849976e-01
    z[6,1,3]  R1572     5.1293814182281494e-01
    z[6,1,3]  R1573     1.5632462501525879e-01
    z[6,1,3]  R1574     6.3311499357223511e-01
    z[6,1,3]  R1575     -5.8447301387786865e-01
    z[6,1,3]  R1576     -2.7181667089462280e-01
    z[6,1,3]  R1577     -7.3082715272903442e-02
    z[6,1,3]  R1578     -3.0466508865356445e-01
    z[6,1,3]  R1579     -1.4586928486824036e-01
    z[6,1,3]  R1580     -3.5448685288429260e-01
    z[6,1,3]  R1581     5.7399606704711914e-01
    z[6,1,3]  R1582     -5.2418279647827148e-01
    z[6,1,3]  R1583     -0.277119517326355
    z[6,1,3]  R1584     -1.5559767186641693e-01
    z[6,1,3]  R1585     -4.8624446988105774e-01
    z[6,1,3]  R1586     -1.8034832552075386e-02
    z[6,1,3]  R1587     3.2120910286903381e-01
    z[6,1,3]  R1588     2.6803153753280640e-01
    z[6,1,3]  R1589     -4.8867025971412659e-01
    z[6,1,3]  R1590     -7.2287283837795258e-02
    z[6,1,3]  R1591     5.6514286994934082e-01
    z[6,1,3]  R1592     2.9438361525535583e-01
    z[6,1,3]  R1593     8.9321218430995941e-02
    z[6,1,3]  R1594     1.5312604606151581e-02
    z[6,1,3]  R1595     -0.288524866104126
    z[6,1,3]  R1596     0.1168212890625
    z[6,1,4]  R15       1
    z[6,1,4]  R60       -1
    z[6,1,4]  R1484     -1
    z[6,1,4]  R1485     1
    z[6,1,4]  R1490     3.4189215302467346e-01
    z[6,1,4]  R1491     -1.3627833127975464e-01
    z[6,1,4]  R1492     -0.111341193318367
    z[6,1,4]  R1493     4.4122478365898132e-01
    z[6,1,4]  R1494     -4.4462826102972031e-02
    z[6,1,4]  R1495     4.0168440341949463e-01
    z[6,1,4]  R1496     2.2923342883586884e-01
    z[6,1,4]  R1497     -4.7273480892181396e-01
    z[6,1,4]  R1498     5.8079534769058228e-01
    z[6,1,4]  R1499     2.5078555941581726e-01
    z[6,1,4]  R1500     6.5549755096435547e-01
    z[6,1,4]  R1501     -5.1414966583251953e-01
    z[6,1,4]  R1502     -5.3345358371734619e-01
    z[6,1,4]  R1503     -1.3015829026699066e-01
    z[6,1,4]  R1504     -8.5632158443331718e-03
    z[6,1,4]  R1505     -2.7972236275672913e-01
    z[6,1,4]  R1506     3.5864907503128052e-01
    z[6,1,4]  R1507     -4.1146072745323181e-01
    z[6,1,4]  R1508     -3.7646195292472839e-01
    z[6,1,4]  R1509     -7.9846596345305443e-03
    z[6,1,4]  R1510     1.5329687297344208e-01
    z[6,1,4]  R1511     -6.2212800979614258e-01
    z[6,1,4]  R1512     5.5183735676109791e-03
    z[6,1,4]  R1513     -2.9356116056442261e-01
    z[6,1,4]  R1514     -4.8711401224136353e-01
    z[6,1,4]  R1515     -1.0112939774990082e-01
    z[6,1,4]  R1516     3.0689540505409241e-01
    z[6,1,4]  R1517     -9.3758301809430122e-03
    z[6,1,4]  R1518     2.0063920319080353e-01
    z[6,1,4]  R1519     5.8596688508987427e-01
    z[6,1,4]  R1520     2.3003134131431580e-01
    z[6,1,4]  R1521     -6.3085383735597134e-03
    z[6,1,4]  R1522     2.6756027340888977e-01
    z[6,1,4]  R1523     5.7051169872283936e-01
    z[6,1,4]  R1524     -3.7801295518875122e-01
    z[6,1,4]  R1525     2.4625961482524872e-01
    z[6,1,4]  R1526     -1.7379105091094971e-01
    z[6,1,4]  R1527     2.6957783102989197e-01
    z[6,1,4]  R1528     -0.25974240899086
    z[6,1,4]  R1529     5.2982503175735474e-01
    z[6,1,4]  R1530     5.3899204730987549e-01
    z[6,1,4]  R1531     8.0369651317596436e-01
    z[6,1,4]  R1532     6.0987651348114014e-02
    z[6,1,4]  R1533     4.5826774090528488e-02
    z[6,1,4]  R1534     -5.1132738590240479e-01
    z[6,1,4]  R1535     -2.9330241680145264e-01
    z[6,1,4]  R1536     1.3294976949691772e-01
    z[6,1,4]  R1537     2.1586577594280243e-01
    z[6,1,4]  R1538     2.0460948348045349e-01
    z[6,1,4]  R1539     7.9268246889114380e-02
    z[6,1,4]  R1540     -3.7390011548995972e-01
    z[6,1,4]  R1541     1.3041408360004425e-01
    z[6,1,4]  R1542     5.6369446218013763e-02
    z[6,1,4]  R1543     -2.6048952341079712e-01
    z[6,1,4]  R1544     1.4222750067710876e-01
    z[6,1,4]  R1545     -5.8729931712150574e-02
    z[6,1,4]  R1546     -1.0785602778196335e-01
    z[6,1,4]  R1547     -6.0210663825273514e-02
    z[6,1,4]  R1548     3.7444502115249634e-01
    z[6,1,4]  R1549     4.6636760234832764e-01
    z[6,1,4]  R1550     7.1435712277889252e-02
    z[6,1,4]  R1551     3.0189543962478638e-01
    z[6,1,4]  R1552     4.6917036175727844e-01
    z[6,1,4]  R1553     -6.2298811972141266e-02
    z[6,1,4]  R1554     1.1157064139842987e-01
    z[6,1,4]  R1555     1.7434763908386230e-01
    z[6,1,4]  R1556     0.265186071395874
    z[6,1,4]  R1557     8.1869371235370636e-02
    z[6,1,4]  R1558     -0.0295050460845232
    z[6,1,4]  R1559     4.1165456175804138e-02
    z[6,1,4]  R1560     1.4436149597167969e-01
    z[6,1,4]  R1561     -7.9460576176643372e-02
    z[6,1,4]  R1562     7.5569534301757812e-01
    z[6,1,4]  R1563     -5.1839772611856461e-02
    z[6,1,4]  R1564     1.8890835344791412e-01
    z[6,1,4]  R1565     -2.3591178655624390e-01
    z[6,1,4]  R1566     -3.0672883987426758e-01
    z[6,1,4]  R1567     -1.2151244282722473e-01
    z[6,1,4]  R1568     -4.5494616031646729e-01
    z[6,1,4]  R1569     -5.7108914852142334e-01
    z[6,1,4]  R1570     -1.4176666736602783e-01
    z[6,1,4]  R1571     -3.3100968599319458e-01
    z[6,1,4]  R1572     1.0167949646711349e-01
    z[6,1,4]  R1573     -3.1500551104545593e-01
    z[6,1,4]  R1574     -2.4191634356975555e-01
    z[6,1,4]  R1575     -2.6066654920578003e-01
    z[6,1,4]  R1576     4.7065809369087219e-02
    z[6,1,4]  R1577     -2.2838643193244934e-01
    z[6,1,4]  R1578     -1.7407071590423584e-01
    z[6,1,4]  R1579     1.1996034532785416e-01
    z[6,1,4]  R1580     3.4921982884407043e-01
    z[6,1,4]  R1581     1.6590552031993866e-01
    z[6,1,4]  R1582     3.6356106400489807e-01
    z[6,1,4]  R1583     0.567359983921051
    z[6,1,4]  R1584     -4.1081428527832031e-01
    z[6,1,4]  R1585     -2.4256144464015961e-01
    z[6,1,4]  R1586     -6.1225313693284988e-02
    z[6,1,4]  R1587     -2.1430957317352295e-01
    z[6,1,4]  R1588     -3.9447724819183350e-01
    z[6,1,4]  R1589     -1.9413267076015472e-01
    z[6,1,4]  R1590     5.8033210039138794e-01
    z[6,1,4]  R1591     -3.3854478597640991e-01
    z[6,1,4]  R1592     -2.6605397462844849e-01
    z[6,1,4]  R1593     -1.3745093345642090e-01
    z[6,1,4]  R1594     6.3053965568542480e-02
    z[6,1,4]  R1595     2.9617384076118469e-01
    z[6,1,4]  R1596     1.8876156210899353e-01
    z[6,1,5]  R16       1
    z[6,1,5]  R61       -1
    z[6,1,5]  R1486     -1
    z[6,1,5]  R1487     1
    z[6,1,5]  R1490     0.528590977191925
    z[6,1,5]  R1491     7.1026724576950073e-01
    z[6,1,5]  R1492     9.1388291120529175e-01
    z[6,1,5]  R1493     -2.9233081266283989e-02
    z[6,1,5]  R1494     -1.8909063935279846e-01
    z[6,1,5]  R1495     4.2841640114784241e-01
    z[6,1,5]  R1496     1.3852208852767944e-01
    z[6,1,5]  R1497     -2.5052863359451294e-01
    z[6,1,5]  R1498     -2.0143085718154907e-01
    z[6,1,5]  R1499     2.2526636719703674e-01
    z[6,1,5]  R1500     -4.2061571031808853e-02
    z[6,1,5]  R1501     -2.2896220907568932e-02
    z[6,1,5]  R1502     -2.8610411286354065e-01
    z[6,1,5]  R1503     1.5323950350284576e-01
    z[6,1,5]  R1504     -1.5778636932373047e-01
    z[6,1,5]  R1505     -4.3013781309127808e-02
    z[6,1,5]  R1506     3.2962355017662048e-01
    z[6,1,5]  R1507     4.1474539786577225e-02
    z[6,1,5]  R1508     -6.0724008083343506e-01
    z[6,1,5]  R1509     4.2287012934684753e-01
    z[6,1,5]  R1510     -5.1012925803661346e-02
    z[6,1,5]  R1511     1.2685698270797729e-01
    z[6,1,5]  R1512     -1.9729802012443542e-01
    z[6,1,5]  R1513     6.3614523410797119e-01
    z[6,1,5]  R1514     3.1838470697402954e-01
    z[6,1,5]  R1515     -4.6052387356758118e-01
    z[6,1,5]  R1516     1.6816663742065430e-01
    z[6,1,5]  R1517     5.0231683254241943e-01
    z[6,1,5]  R1518     1.0454358160495758e-01
    z[6,1,5]  R1519     0.260141521692276
    z[6,1,5]  R1520     9.3274883925914764e-02
    z[6,1,5]  R1521     1.6127622127532959e-01
    z[6,1,5]  R1522     6.9633203744888306e-01
    z[6,1,5]  R1523     2.9558527469635010e-01
    z[6,1,5]  R1524     -1.0555070638656616e-01
    z[6,1,5]  R1525     1.5233403444290161e-01
    z[6,1,5]  R1526     -5.9906851500272751e-02
    z[6,1,5]  R1527     -0.296150267124176
    z[6,1,5]  R1528     -1.8459224700927734e-01
    z[6,1,5]  R1529     -1.4714795351028442e-01
    z[6,1,5]  R1530     7.5066995620727539e-01
    z[6,1,5]  R1531     1.3029675185680389e-01
    z[6,1,5]  R1532     -1.4577963948249817e-01
    z[6,1,5]  R1533     -4.6445944905281067e-01
    z[6,1,5]  R1534     -1.0121800005435944e-01
    z[6,1,5]  R1535     -4.0525132417678833e-01
    z[6,1,5]  R1536     1.6238564252853394e-01
    z[6,1,5]  R1537     -2.9147368669509888e-01
    z[6,1,5]  R1538     -1.3680888712406158e-01
    z[6,1,5]  R1539     -1.6233567893505096e-01
    z[6,1,5]  R1540     1.5122829377651215e-01
    z[6,1,5]  R1541     4.0020561218261719e-01
    z[6,1,5]  R1542     -1.0169178247451782e-01
    z[6,1,5]  R1543     -6.7678354680538177e-02
    z[6,1,5]  R1544     -2.8892930597066879e-02
    z[6,1,5]  R1545     -1.4586250483989716e-01
    z[6,1,5]  R1546     -7.0206761360168457e-02
    z[6,1,5]  R1547     1.4605778455734253e-01
    z[6,1,5]  R1548     1.8587511777877808e-01
    z[6,1,5]  R1549     -1.4139805734157562e-01
    z[6,1,5]  R1550     4.5469993352890015e-01
    z[6,1,5]  R1551     8.6127929389476776e-02
    z[6,1,5]  R1552     0.0432896763086319
    z[6,1,5]  R1553     7.2182303667068481e-01
    z[6,1,5]  R1554     5.4944694042205811e-01
    z[6,1,5]  R1555     5.7868117094039917e-01
    z[6,1,5]  R1556     -0.176085963845253
    z[6,1,5]  R1557     -1.6225415468215942e-01
    z[6,1,5]  R1558     -2.5128121487796307e-03
    z[6,1,5]  R1559     6.8202703259885311e-03
    z[6,1,5]  R1560     2.7587673068046570e-01
    z[6,1,5]  R1561     -1.8212584778666496e-02
    z[6,1,5]  R1562     3.5121780633926392e-01
    z[6,1,5]  R1563     -4.2768475413322449e-01
    z[6,1,5]  R1564     1.0120529681444168e-01
    z[6,1,5]  R1565     -7.2193038463592529e-01
    z[6,1,5]  R1566     -8.1432253122329712e-02
    z[6,1,5]  R1567     -1.8198329210281372e-01
    z[6,1,5]  R1568     -6.8062287569046021e-01
    z[6,1,5]  R1569     -4.0630817413330078e-01
    z[6,1,5]  R1570     -4.6032306551933289e-01
    z[6,1,5]  R1571     -1.7219726741313934e-01
    z[6,1,5]  R1572     -0.430600643157959
    z[6,1,5]  R1573     -5.0054562091827393e-01
    z[6,1,5]  R1574     5.8270907029509544e-03
    z[6,1,5]  R1575     2.9229742288589478e-01
    z[6,1,5]  R1576     6.6445773839950562e-01
    z[6,1,5]  R1577     2.1083930134773254e-01
    z[6,1,5]  R1578     2.4733105301856995e-01
    z[6,1,5]  R1579     4.7527906298637390e-01
    z[6,1,5]  R1580     5.6023615598678589e-01
    z[6,1,5]  R1581     -2.4616421759128571e-01
    z[6,1,5]  R1582     3.7608388066291809e-01
    z[6,1,5]  R1583     1.9763027131557465e-01
    z[6,1,5]  R1584     -3.1555801630020142e-01
    z[6,1,5]  R1585     1.6353559494018555e-01
    z[6,1,5]  R1586     -1.9240470230579376e-01
    z[6,1,5]  R1587     0.129002645611763
    z[6,1,5]  R1588     5.4752331972122192e-01
    z[6,1,5]  R1589     7.5934166088700294e-03
    z[6,1,5]  R1590     3.3185136318206787e-01
    z[6,1,5]  R1591     1.9408319890499115e-01
    z[6,1,5]  R1592     -1.7621102929115295e-01
    z[6,1,5]  R1593     -7.7011808753013611e-02
    z[6,1,5]  R1594     -1.5127140283584595e-01
    z[6,1,5]  R1595     -4.7354641556739807e-01
    z[6,1,5]  R1596     1.2884079478681087e-02
    z[6,1,6]  R17       1
    z[6,1,6]  R62       -1
    z[6,1,6]  R1488     -1
    z[6,1,6]  R1489     1
    z[6,1,6]  R1490     4.4780775904655457e-01
    z[6,1,6]  R1491     -2.4089443683624268e-01
    z[6,1,6]  R1492     1.5373152494430542e-01
    z[6,1,6]  R1493     -0.0870768278837204
    z[6,1,6]  R1494     -5.4401624202728271e-01
    z[6,1,6]  R1495     -2.7572691440582275e-01
    z[6,1,6]  R1496     2.6575896143913269e-01
    z[6,1,6]  R1497     4.4204148650169373e-01
    z[6,1,6]  R1498     8.7261833250522614e-02
    z[6,1,6]  R1499     -3.0299395322799683e-01
    z[6,1,6]  R1500     -2.7117198705673218e-01
    z[6,1,6]  R1501     6.2765669822692871e-01
    z[6,1,6]  R1502     4.0960687398910522e-01
    z[6,1,6]  R1503     -1.7640371620655060e-01
    z[6,1,6]  R1504     -0.0567912831902504
    z[6,1,6]  R1505     -3.9269987493753433e-02
    z[6,1,6]  R1506     3.5853415727615356e-01
    z[6,1,6]  R1507     4.4118392467498779e-01
    z[6,1,6]  R1508     2.8538459539413452e-01
    z[6,1,6]  R1509     3.2892918586730957e-01
    z[6,1,6]  R1510     2.1122667193412781e-01
    z[6,1,6]  R1511     1.9000871479511261e-01
    z[6,1,6]  R1512     3.5023361444473267e-01
    z[6,1,6]  R1513     7.2476804256439209e-02
    z[6,1,6]  R1514     -2.7893170714378357e-01
    z[6,1,6]  R1515     1.7076477408409119e-01
    z[6,1,6]  R1516     -4.8884540796279907e-01
    z[6,1,6]  R1517     -1.2712916731834412e-01
    z[6,1,6]  R1518     -2.4725881218910217e-01
    z[6,1,6]  R1519     -6.3336426019668579e-01
    z[6,1,6]  R1520     5.7357203215360641e-02
    z[6,1,6]  R1521     -0.268635094165802
    z[6,1,6]  R1522     1.4303991198539734e-01
    z[6,1,6]  R1523     1.2412270158529282e-01
    z[6,1,6]  R1524     6.1146342754364014e-01
    z[6,1,6]  R1525     -8.3838403224945068e-01
    z[6,1,6]  R1526     -5.3668224811553955e-01
    z[6,1,6]  R1527     -2.7634406089782715e-01
    z[6,1,6]  R1528     3.9433974027633667e-01
    z[6,1,6]  R1529     -2.6123058050870895e-02
    z[6,1,6]  R1530     -1.3918830454349518e-01
    z[6,1,6]  R1531     3.0937612056732178e-01
    z[6,1,6]  R1532     -4.1227099299430847e-01
    z[6,1,6]  R1533     8.1027291715145111e-02
    z[6,1,6]  R1534     2.8887173533439636e-01
    z[6,1,6]  R1535     7.2796165943145752e-02
    z[6,1,6]  R1536     1.3282217085361481e-01
    z[6,1,6]  R1537     0.233786940574646
    z[6,1,6]  R1538     3.7475389242172241e-01
    z[6,1,6]  R1539     -5.4427143186330795e-03
    z[6,1,6]  R1540     -2.4663519114255905e-02
    z[6,1,6]  R1541     -6.5523463487625122e-01
    z[6,1,6]  R1542     3.6728808283805847e-01
    z[6,1,6]  R1543     -2.4440322816371918e-01
    z[6,1,6]  R1544     1.0210485011339188e-01
    z[6,1,6]  R1545     -1.0901399701833725e-01
    z[6,1,6]  R1546     -7.4868492782115936e-02
    z[6,1,6]  R1547     1.6749604837968946e-03
    z[6,1,6]  R1548     2.8560683131217957e-01
    z[6,1,6]  R1549     3.9391836524009705e-01
    z[6,1,6]  R1550     7.0469003915786743e-01
    z[6,1,6]  R1551     7.5557726621627808e-01
    z[6,1,6]  R1552     -3.5521391034126282e-01
    z[6,1,6]  R1553     -3.6219093948602676e-02
    z[6,1,6]  R1554     -3.3626472949981689e-01
    z[6,1,6]  R1555     -1.1651092767715454e-01
    z[6,1,6]  R1556     1.8766130506992340e-01
    z[6,1,6]  R1557     2.1053564548492432e-01
    z[6,1,6]  R1558     -1.6096076369285583e-01
    z[6,1,6]  R1559     2.3172810673713684e-01
    z[6,1,6]  R1560     4.1252526640892029e-01
    z[6,1,6]  R1561     -1.9073310494422913e-01
    z[6,1,6]  R1562     -1.2972231209278107e-01
    z[6,1,6]  R1563     -5.2020758390426636e-01
    z[6,1,6]  R1564     -7.9890716075897217e-01
    z[6,1,6]  R1565     -4.0473058819770813e-01
    z[6,1,6]  R1566     -3.6321204900741577e-01
    z[6,1,6]  R1567     -5.4574948549270630e-01
    z[6,1,6]  R1568     6.5559722483158112e-02
    z[6,1,6]  R1569     3.6005118489265442e-01
    z[6,1,6]  R1570     -4.5117178559303284e-01
    z[6,1,6]  R1571     -5.4073441028594971e-01
    z[6,1,6]  R1572     1.2992599513381720e-03
    z[6,1,6]  R1573     2.1642138063907623e-01
    z[6,1,6]  R1574     3.4340581297874451e-01
    z[6,1,6]  R1575     -3.2740628719329834e-01
    z[6,1,6]  R1576     -6.2006378173828125e-01
    z[6,1,6]  R1577     2.7123183012008667e-01
    z[6,1,6]  R1578     -4.2300187051296234e-02
    z[6,1,6]  R1579     1.2370651215314865e-01
    z[6,1,6]  R1580     -4.7015976905822754e-01
    z[6,1,6]  R1581     3.4981733560562134e-01
    z[6,1,6]  R1582     -7.3354914784431458e-02
    z[6,1,6]  R1583     -2.4641756713390350e-01
    z[6,1,6]  R1584     -2.3655369877815247e-02
    z[6,1,6]  R1585     4.4243231415748596e-02
    z[6,1,6]  R1586     -2.6326501369476318e-01
    z[6,1,6]  R1587     -6.7819356918334961e-02
    z[6,1,6]  R1588     -5.0240176916122437e-01
    z[6,1,6]  R1589     -2.6337611675262451e-01
    z[6,1,6]  R1590     -3.5471022129058838e-02
    z[6,1,6]  R1591     1.9848808646202087e-01
    z[6,1,6]  R1592     -6.9091357290744781e-02
    z[6,1,6]  R1593     3.4583261609077454e-01
    z[6,1,6]  R1594     1.0074346512556076e-01
    z[6,1,6]  R1595     2.9694160819053650e-01
    z[6,1,6]  R1596     2.5770869851112366e-01
    z[2,5,0]  R20       -1
    z[2,5,0]  R47       1
    z[2,5,0]  R1597     -1
    z[2,5,0]  R1598     1
    z[2,5,0]  R1611     3.1432923674583435e-01
    z[2,5,0]  R1612     1.1821191757917404e-01
    z[2,5,0]  R1613     -4.2595438659191132e-02
    z[2,5,0]  R1614     -2.8032967820763588e-02
    z[2,5,0]  R1615     2.3776893317699432e-01
    z[2,5,0]  R1616     7.2030341625213623e-01
    z[2,5,0]  R1617     3.6836597323417664e-01
    z[2,5,0]  R1618     6.8994998931884766e-01
    z[2,5,0]  R1619     5.5068814754486084e-01
    z[2,5,0]  R1620     3.8371109962463379e-01
    z[2,5,0]  R1621     -5.1737666130065918e-01
    z[2,5,0]  R1622     5.7984985411167145e-02
    z[2,5,0]  R1623     -3.4597349166870117e-01
    z[2,5,0]  R1624     -6.9435632228851318e-01
    z[2,5,0]  R1625     -5.8090382814407349e-01
    z[2,5,0]  R1626     -7.2835075855255127e-01
    z[2,5,0]  R1627     -6.3251376152038574e-01
    z[2,5,0]  R1628     -0.282098650932312
    z[2,5,0]  R1629     -8.0061239004135132e-01
    z[2,5,0]  R1630     2.9811334609985352e-01
    z[2,5,0]  R1631     -0.727404773235321
    z[2,5,0]  R1632     -6.9134902954101562e-01
    z[2,5,0]  R1633     -3.8005176186561584e-01
    z[2,5,0]  R1634     2.9792213439941406e-01
    z[2,5,0]  R1635     2.5141090154647827e-01
    z[2,5,0]  R1636     4.8459729552268982e-01
    z[2,5,0]  R1637     2.2911366820335388e-01
    z[2,5,0]  R1638     2.8318625688552856e-01
    z[2,5,0]  R1639     1.4619770646095276e-01
    z[2,5,0]  R1640     5.0927591323852539e-01
    z[2,5,0]  R1641     -3.6842474341392517e-01
    z[2,5,0]  R1642     3.8788583874702454e-01
    z[2,5,0]  R1643     0.511343777179718
    z[2,5,0]  R1644     4.3528911471366882e-01
    z[2,5,0]  R1645     2.7572733163833618e-01
    z[2,5,0]  R1646     0.501968264579773
    z[2,5,0]  R1647     2.5607383251190186e-01
    z[2,5,0]  R1648     4.8280277848243713e-01
    z[2,5,0]  R1649     1.5415605902671814e-01
    z[2,5,0]  R1650     1.2871250510215759e-01
    z[2,5,0]  R1651     9.1751128435134888e-02
    z[2,5,0]  R1652     -2.9391407966613770e-01
    z[2,5,0]  R1653     3.5134589672088623e-01
    z[2,5,0]  R1654     1.8095086514949799e-01
    z[2,5,0]  R1655     4.5932576060295105e-02
    z[2,5,0]  R1656     0.0817050188779831
    z[2,5,0]  R1657     1.5777802467346191e-01
    z[2,5,0]  R1658     -2.8450459241867065e-01
    z[2,5,0]  R1659     -2.5793009996414185e-01
    z[2,5,0]  R1660     2.9511460661888123e-01
    z[2,5,0]  R1661     -8.0357983708381653e-02
    z[2,5,0]  R1662     -2.6397609710693359e-01
    z[2,5,0]  R1663     -7.9158611595630646e-02
    z[2,5,0]  R1664     -1.3939459621906281e-01
    z[2,5,0]  R1665     3.3405673503875732e-01
    z[2,5,0]  R1666     -3.1011231243610382e-02
    z[2,5,0]  R1667     -2.3243987560272217e-01
    z[2,5,0]  R1668     6.5164053812623024e-03
    z[2,5,0]  R1669     -1.2624450027942657e-01
    z[2,5,0]  R1670     3.0309295654296875e-01
    z[2,5,0]  R1671     -6.2123370170593262e-01
    z[2,5,0]  R1672     -1.2315837293863297e-01
    z[2,5,0]  R1673     -7.4878519773483276e-01
    z[2,5,0]  R1674     1.7647108435630798e-01
    z[2,5,0]  R1675     -7.7983301877975464e-01
    z[2,5,0]  R1676     -4.7811153531074524e-01
    z[2,5,0]  R1677     -3.9945331215858459e-01
    z[2,5,0]  R1678     -7.3482406139373779e-01
    z[2,5,0]  R1679     -5.1747697591781616e-01
    z[2,5,0]  R1680     -5.3739684820175171e-01
    z[2,5,0]  R1681     5.9888356924057007e-01
    z[2,5,0]  R1682     1.9250044226646423e-01
    z[2,5,0]  R1683     3.4843954443931580e-01
    z[2,5,0]  R1684     -1.4973483979701996e-01
    z[2,5,0]  R1685     5.2489286661148071e-01
    z[2,5,0]  R1686     7.5461953878402710e-01
    z[2,5,0]  R1687     6.6458392143249512e-01
    z[2,5,0]  R1688     -2.1477121859788895e-02
    z[2,5,0]  R1689     0.493700236082077
    z[2,5,0]  R1690     5.5405634641647339e-01
    z[2,5,0]  R1691     -3.0755949020385742e-01
    z[2,5,0]  R1692     5.7791608572006226e-01
    z[2,5,0]  R1693     3.1935986876487732e-01
    z[2,5,0]  R1694     -5.7855671644210815e-01
    z[2,5,0]  R1695     2.0953913033008575e-01
    z[2,5,0]  R1696     2.7045177295804024e-02
    z[2,5,0]  R1697     1.8525169789791107e-01
    z[2,5,0]  R1698     7.2206068038940430e-01
    z[2,5,0]  R1699     0.537449300289154
    z[2,5,0]  R1700     7.2452224791049957e-02
    z[2,5,1]  R21       -1
    z[2,5,1]  R48       1
    z[2,5,1]  R1599     -1
    z[2,5,1]  R1600     1
    z[2,5,1]  R1611     4.3151691555976868e-01
    z[2,5,1]  R1612     4.2549699544906616e-01
    z[2,5,1]  R1613     5.2562618255615234e-01
    z[2,5,1]  R1614     5.6732589006423950e-01
    z[2,5,1]  R1615     8.2880979776382446e-01
    z[2,5,1]  R1616     -6.1817508935928345e-01
    z[2,5,1]  R1617     -2.8042098879814148e-01
    z[2,5,1]  R1618     -3.8915368914604187e-01
    z[2,5,1]  R1619     -0.612704873085022
    z[2,5,1]  R1620     -3.9651420712471008e-01
    z[2,5,1]  R1621     4.7555673122406006e-01
    z[2,5,1]  R1622     0.518293559551239
    z[2,5,1]  R1623     2.9023453593254089e-01
    z[2,5,1]  R1624     3.4667372703552246e-01
    z[2,5,1]  R1625     3.2177156209945679e-01
    z[2,5,1]  R1626     -1.8335235118865967e-01
    z[2,5,1]  R1627     -7.5615622103214264e-02
    z[2,5,1]  R1628     2.2285100817680359e-01
    z[2,5,1]  R1629     -1.9160155951976776e-01
    z[2,5,1]  R1630     -7.9132926464080811e-01
    z[2,5,1]  R1631     5.5986744165420532e-01
    z[2,5,1]  R1632     2.4091683328151703e-01
    z[2,5,1]  R1633     -2.6302519440650940e-01
    z[2,5,1]  R1634     -8.7849563360214233e-01
    z[2,5,1]  R1635     -9.0676325559616089e-01
    z[2,5,1]  R1636     -0.81097811460495
    z[2,5,1]  R1637     -9.1801899671554565e-01
    z[2,5,1]  R1638     -8.8772386312484741e-01
    z[2,5,1]  R1639     -9.1601639986038208e-01
    z[2,5,1]  R1640     -7.4158489704132080e-01
    z[2,5,1]  R1641     4.2555916309356689e-01
    z[2,5,1]  R1642     -0.866968035697937
    z[2,5,1]  R1643     -6.5728002786636353e-01
    z[2,5,1]  R1644     -4.3178817629814148e-01
    z[2,5,1]  R1645     -4.6381074190139771e-01
    z[2,5,1]  R1646     -2.9665133357048035e-01
    z[2,5,1]  R1647     -4.6428361535072327e-01
    z[2,5,1]  R1648     -4.8970067501068115e-01
    z[2,5,1]  R1649     -5.3583443164825439e-01
    z[2,5,1]  R1650     -5.1682722568511963e-01
    z[2,5,1]  R1651     8.7547320127487183e-01
    z[2,5,1]  R1652     8.5558646917343140e-01
    z[2,5,1]  R1653     7.4692708253860474e-01
    z[2,5,1]  R1654     7.0906698703765869e-01
    z[2,5,1]  R1655     6.2525153160095215e-01
    z[2,5,1]  R1656     6.2553548812866211e-01
    z[2,5,1]  R1657     4.2846208810806274e-01
    z[2,5,1]  R1658     6.0804325342178345e-01
    z[2,5,1]  R1659     2.9897719621658325e-01
    z[2,5,1]  R1660     6.6439443826675415e-01
    z[2,5,1]  R1661     -9.2065292596817017e-01
    z[2,5,1]  R1662     -9.4883036613464355e-01
    z[2,5,1]  R1663     -8.4418761730194092e-01
    z[2,5,1]  R1664     -8.5557991266250610e-01
    z[2,5,1]  R1665     -8.8591217994689941e-01
    z[2,5,1]  R1666     -8.5599416494369507e-01
    z[2,5,1]  R1667     -0.837941586971283
    z[2,5,1]  R1668     -8.3161729574203491e-01
    z[2,5,1]  R1669     -8.2682949304580688e-01
    z[2,5,1]  R1670     -8.9267814159393311e-01
    z[2,5,1]  R1671     -9.1890551149845123e-02
    z[2,5,1]  R1672     -1.7950126528739929e-01
    z[2,5,1]  R1673     3.0340716242790222e-01
    z[2,5,1]  R1674     2.9247373342514038e-01
    z[2,5,1]  R1675     1.9021998345851898e-01
    z[2,5,1]  R1676     2.6451054215431213e-01
    z[2,5,1]  R1677     1.7234939336776733e-01
    z[2,5,1]  R1678     4.5606139302253723e-01
    z[2,5,1]  R1679     3.7726444005966187e-01
    z[2,5,1]  R1680     -2.4689415469765663e-02
    z[2,5,1]  R1681     -1.1694305390119553e-01
    z[2,5,1]  R1682     -6.3666746020317078e-02
    z[2,5,1]  R1683     -5.9154576063156128e-01
    z[2,5,1]  R1684     7.1902751922607422e-02
    z[2,5,1]  R1685     -5.9003078937530518e-01
    z[2,5,1]  R1686     -5.4779714345932007e-01
    z[2,5,1]  R1687     -5.7059872150421143e-01
    z[2,5,1]  R1688     -6.3786470890045166e-01
    z[2,5,1]  R1689     -6.7252731323242188e-01
    z[2,5,1]  R1690     -6.6398131847381592e-01
    z[2,5,1]  R1691     4.1244527697563171e-01
    z[2,5,1]  R1692     2.9022064805030823e-01
    z[2,5,1]  R1693     0.279297411441803
    z[2,5,1]  R1694     -0.230604350566864
    z[2,5,1]  R1695     1.7475579679012299e-01
    z[2,5,1]  R1696     8.5760280489921570e-02
    z[2,5,1]  R1697     -3.2181721925735474e-01
    z[2,5,1]  R1698     -2.1566207706928253e-01
    z[2,5,1]  R1699     -3.5702559351921082e-01
    z[2,5,1]  R1700     -6.3930189609527588e-01
    z[2,5,2]  R22       -1
    z[2,5,2]  R49       1
    z[2,5,2]  R1601     -1
    z[2,5,2]  R1602     1
    z[2,5,2]  R1611     -1.4077208936214447e-01
    z[2,5,2]  R1612     9.7302317619323730e-02
    z[2,5,2]  R1613     -2.1837297081947327e-01
    z[2,5,2]  R1614     1.1307616531848907e-01
    z[2,5,2]  R1615     -1.9834028184413910e-01
    z[2,5,2]  R1616     -1.0964637994766235e-01
    z[2,5,2]  R1617     8.0503863096237183e-01
    z[2,5,2]  R1618     4.9628299474716187e-01
    z[2,5,2]  R1619     4.6857553720474243e-01
    z[2,5,2]  R1620     -0.295538067817688
    z[2,5,2]  R1621     -2.3308368399739265e-02
    z[2,5,2]  R1622     -4.4742828607559204e-01
    z[2,5,2]  R1623     -5.0015095621347427e-02
    z[2,5,2]  R1624     1.6715654730796814e-01
    z[2,5,2]  R1625     3.5724112391471863e-01
    z[2,5,2]  R1626     2.2476868331432343e-01
    z[2,5,2]  R1627     5.4395663738250732e-01
    z[2,5,2]  R1628     -1.1327151954174042e-01
    z[2,5,2]  R1629     0.394095242023468
    z[2,5,2]  R1630     -2.5027871131896973e-01
    z[2,5,2]  R1631     2.8507426381111145e-01
    z[2,5,2]  R1632     9.3729391694068909e-02
    z[2,5,2]  R1633     2.3452764749526978e-01
    z[2,5,2]  R1634     -6.1158183962106705e-02
    z[2,5,2]  R1635     1.6787745058536530e-01
    z[2,5,2]  R1636     -1.3995537161827087e-01
    z[2,5,2]  R1637     4.8986006528139114e-02
    z[2,5,2]  R1638     1.9130004942417145e-01
    z[2,5,2]  R1639     1.5195025503635406e-01
    z[2,5,2]  R1640     -2.1155475080013275e-01
    z[2,5,2]  R1641     -2.0650514960289001e-01
    z[2,5,2]  R1642     -3.3399043604731560e-03
    z[2,5,2]  R1643     8.1033043563365936e-02
    z[2,5,2]  R1644     6.9183951616287231e-01
    z[2,5,2]  R1645     6.9558727741241455e-01
    z[2,5,2]  R1646     0.603071391582489
    z[2,5,2]  R1647     0.738192081451416
    z[2,5,2]  R1648     4.5026838779449463e-01
    z[2,5,2]  R1649     6.5014606714248657e-01
    z[2,5,2]  R1650     0.777576744556427
    z[2,5,2]  R1651     2.2204430401325226e-01
    z[2,5,2]  R1652     -6.9286718964576721e-02
    z[2,5,2]  R1653     1.0267228819429874e-02
    z[2,5,2]  R1654     -3.1002461910247803e-02
    z[2,5,2]  R1655     1.0819110274314880e-01
    z[2,5,2]  R1656     -3.7111940979957581e-01
    z[2,5,2]  R1657     7.5985920429229736e-01
    z[2,5,2]  R1658     -2.4186022579669952e-01
    z[2,5,2]  R1659     7.5410521030426025e-01
    z[2,5,2]  R1660     -4.7407627105712891e-01
    z[2,5,2]  R1661     2.6614934206008911e-01
    z[2,5,2]  R1662     -4.7693509608507156e-02
    z[2,5,2]  R1663     2.5060348212718964e-02
    z[2,5,2]  R1664     -2.1321940422058105e-01
    z[2,5,2]  R1665     0.201337531208992
    z[2,5,2]  R1666     -2.9549381136894226e-01
    z[2,5,2]  R1667     -1.6530798375606537e-01
    z[2,5,2]  R1668     0.0824781134724617
    z[2,5,2]  R1669     -6.8636782467365265e-02
    z[2,5,2]  R1670     1.6016195714473724e-01
    z[2,5,2]  R1671     -4.8945721983909607e-01
    z[2,5,2]  R1672     5.1430130004882812e-01
    z[2,5,2]  R1673     3.4037387371063232e-01
    z[2,5,2]  R1674     -8.9806658029556274e-01
    z[2,5,2]  R1675     -0.0916375145316124
    z[2,5,2]  R1676     3.0163705348968506e-02
    z[2,5,2]  R1677     -4.7916686534881592e-01
    z[2,5,2]  R1678     -1.5109807252883911e-01
    z[2,5,2]  R1679     -3.7307778000831604e-01
    z[2,5,2]  R1680     -9.4032082706689835e-03
    z[2,5,2]  R1681     8.0027438700199127e-02
    z[2,5,2]  R1682     -5.8725923299789429e-02
    z[2,5,2]  R1683     1.0964184254407883e-01
    z[2,5,2]  R1684     -7.3334950208663940e-01
    z[2,5,2]  R1685     4.0528017282485962e-01
    z[2,5,2]  R1686     0.284252792596817
    z[2,5,2]  R1687     3.6815294623374939e-01
    z[2,5,2]  R1688     1.5899296104907990e-01
    z[2,5,2]  R1689     4.2180046439170837e-01
    z[2,5,2]  R1690     4.2704778909683228e-01
    z[2,5,2]  R1691     -5.3261661529541016e-01
    z[2,5,2]  R1692     -4.9754548072814941e-01
    z[2,5,2]  R1693     4.1682365536689758e-01
    z[2,5,2]  R1694     -9.4092383980751038e-02
    z[2,5,2]  R1695     6.6872701048851013e-02
    z[2,5,2]  R1696     5.3215879201889038e-01
    z[2,5,2]  R1697     4.9683311581611633e-01
    z[2,5,2]  R1698     4.9082070589065552e-01
    z[2,5,2]  R1699     6.5681940317153931e-01
    z[2,5,2]  R1700     6.7451059818267822e-01
    z[2,5,3]  R23       -1
    z[2,5,3]  R50       1
    z[2,5,3]  R1603     -1
    z[2,5,3]  R1604     1
    z[2,5,3]  R1611     1.5378223359584808e-01
    z[2,5,3]  R1612     -2.1045181900262833e-02
    z[2,5,3]  R1613     1.5678630769252777e-01
    z[2,5,3]  R1614     0.206902414560318
    z[2,5,3]  R1615     2.7443605661392212e-01
    z[2,5,3]  R1616     -1.2152399122714996e-01
    z[2,5,3]  R1617     1.6491317749023438e-01
    z[2,5,3]  R1618     -9.8055362701416016e-02
    z[2,5,3]  R1619     2.6900875568389893e-01
    z[2,5,3]  R1620     7.0876121520996094e-01
    z[2,5,3]  R1621     -4.3087130784988403e-01
    z[2,5,3]  R1622     -5.1461577415466309e-01
    z[2,5,3]  R1623     -6.5086215734481812e-01
    z[2,5,3]  R1624     1.0967974364757538e-01
    z[2,5,3]  R1625     2.5317004323005676e-01
    z[2,5,3]  R1626     -3.0487614870071411e-01
    z[2,5,3]  R1627     -4.6829420328140259e-01
    z[2,5,3]  R1628     4.8402658104896545e-01
    z[2,5,3]  R1629     2.2843122482299805e-01
    z[2,5,3]  R1630     2.0251031219959259e-01
    z[2,5,3]  R1631     -0.0773281380534172
    z[2,5,3]  R1632     0.431424617767334
    z[2,5,3]  R1633     -6.8704259395599365e-01
    z[2,5,3]  R1634     2.6176929473876953e-01
    z[2,5,3]  R1635     1.0777126997709274e-01
    z[2,5,3]  R1636     -1.5613524615764618e-01
    z[2,5,3]  R1637     -1.8808171153068542e-01
    z[2,5,3]  R1638     -2.1368660032749176e-01
    z[2,5,3]  R1639     -7.0396766066551208e-02
    z[2,5,3]  R1640     -2.1032449603080750e-01
    z[2,5,3]  R1641     6.5436446666717529e-01
    z[2,5,3]  R1642     -1.0747081041336060e-01
    z[2,5,3]  R1643     1.3733908534049988e-01
    z[2,5,3]  R1644     -2.0159746706485748e-01
    z[2,5,3]  R1645     5.9304811060428619e-02
    z[2,5,3]  R1646     -1.3849201798439026e-01
    z[2,5,3]  R1647     1.3117182254791260e-01
    z[2,5,3]  R1648     -1.4365708827972412e-01
    z[2,5,3]  R1649     -8.5474856197834015e-02
    z[2,5,3]  R1650     -3.2779112458229065e-02
    z[2,5,3]  R1651     -1.7188473045825958e-01
    z[2,5,3]  R1652     1.8126615881919861e-01
    z[2,5,3]  R1653     4.3439182639122009e-01
    z[2,5,3]  R1654     -1.2478467077016830e-01
    z[2,5,3]  R1655     1.9832178950309753e-01
    z[2,5,3]  R1656     4.3204563856124878e-01
    z[2,5,3]  R1657     1.1489140801131725e-02
    z[2,5,3]  R1658     -4.0967710316181183e-02
    z[2,5,3]  R1659     4.8574271798133850e-01
    z[2,5,3]  R1660     -4.3506991118192673e-02
    z[2,5,3]  R1661     -4.6891830861568451e-02
    z[2,5,3]  R1662     -2.8363440185785294e-02
    z[2,5,3]  R1663     1.3611934147775173e-02
    z[2,5,3]  R1664     -0.0231669619679451
    z[2,5,3]  R1665     2.2896258533000946e-01
    z[2,5,3]  R1666     3.4761503338813782e-01
    z[2,5,3]  R1667     2.6514670252799988e-01
    z[2,5,3]  R1668     1.0575447231531143e-01
    z[2,5,3]  R1669     4.9875143170356750e-01
    z[2,5,3]  R1670     7.5762018561363220e-02
    z[2,5,3]  R1671     -2.3659074306488037e-01
    z[2,5,3]  R1672     -2.6496499776840210e-01
    z[2,5,3]  R1673     -1.8247883021831512e-01
    z[2,5,3]  R1674     -2.2330953180789948e-01
    z[2,5,3]  R1675     -1.5001441538333893e-01
    z[2,5,3]  R1676     -4.4930616021156311e-01
    z[2,5,3]  R1677     -2.6776903867721558e-01
    z[2,5,3]  R1678     9.8131135106086731e-02
    z[2,5,3]  R1679     -2.6228803396224976e-01
    z[2,5,3]  R1680     -1.6434629261493683e-01
    z[2,5,3]  R1681     -6.9557195901870728e-01
    z[2,5,3]  R1682     -0.846520185470581
    z[2,5,3]  R1683     -4.7702023386955261e-01
    z[2,5,3]  R1684     -4.8704613000154495e-02
    z[2,5,3]  R1685     -1.0013290494680405e-01
    z[2,5,3]  R1686     -9.7566343843936920e-02
    z[2,5,3]  R1687     -8.4781445562839508e-02
    z[2,5,3]  R1688     -0.349507600069046
    z[2,5,3]  R1689     -4.1402030736207962e-02
    z[2,5,3]  R1690     1.7861567437648773e-01
    z[2,5,3]  R1691     -4.2533260583877563e-01
    z[2,5,3]  R1692     -2.0311589539051056e-01
    z[2,5,3]  R1693     -2.9586234688758850e-01
    z[2,5,3]  R1694     1.5119914710521698e-01
    z[2,5,3]  R1695     -4.7901135683059692e-01
    z[2,5,3]  R1696     -7.7033668756484985e-01
    z[2,5,3]  R1697     -5.8633148670196533e-01
    z[2,5,3]  R1698     -2.6660934090614319e-01
    z[2,5,3]  R1699     1.6089810431003571e-01
    z[2,5,3]  R1700     3.4706801176071167e-01
    z[2,5,4]  R24       -1
    z[2,5,4]  R51       1
    z[2,5,4]  R1605     -1
    z[2,5,4]  R1606     1
    z[2,5,4]  R1611     5.0439256429672241e-01
    z[2,5,4]  R1612     7.7387249469757080e-01
    z[2,5,4]  R1613     5.1933001726865768e-02
    z[2,5,4]  R1614     7.1761339902877808e-02
    z[2,5,4]  R1615     9.4068972393870354e-03
    z[2,5,4]  R1616     1.5361286699771881e-01
    z[2,5,4]  R1617     4.7112341970205307e-02
    z[2,5,4]  R1618     4.5098189264535904e-02
    z[2,5,4]  R1619     -3.5120092798024416e-03
    z[2,5,4]  R1620     -2.4536836892366409e-02
    z[2,5,4]  R1621     -4.0133681148290634e-02
    z[2,5,4]  R1622     -3.6904710531234741e-01
    z[2,5,4]  R1623     -5.7447558641433716e-01
    z[2,5,4]  R1624     -4.7752285003662109e-01
    z[2,5,4]  R1625     0.193202406167984
    z[2,5,4]  R1626     -4.0770679712295532e-01
    z[2,5,4]  R1627     2.0824690163135529e-01
    z[2,5,4]  R1628     -2.6912295818328857e-01
    z[2,5,4]  R1629     0.0373593270778656
    z[2,5,4]  R1630     -3.7109193205833435e-01
    z[2,5,4]  R1631     -8.2805931568145752e-02
    z[2,5,4]  R1632     -2.0254465937614441e-01
    z[2,5,4]  R1633     -4.0486253798007965e-02
    z[2,5,4]  R1634     -1.0614348202943802e-01
    z[2,5,4]  R1635     -3.2525051385164261e-02
    z[2,5,4]  R1636     -2.2475828230381012e-01
    z[2,5,4]  R1637     -5.6633982807397842e-02
    z[2,5,4]  R1638     1.6786442697048187e-01
    z[2,5,4]  R1639     2.0928440988063812e-01
    z[2,5,4]  R1640     -2.6660870760679245e-02
    z[2,5,4]  R1641     -3.6228525638580322e-01
    z[2,5,4]  R1642     1.8636827170848846e-01
    z[2,5,4]  R1643     3.5006308555603027e-01
    z[2,5,4]  R1644     -3.1885942816734314e-01
    z[2,5,4]  R1645     -3.5632592439651489e-01
    z[2,5,4]  R1646     -4.6853971481323242e-01
    z[2,5,4]  R1647     -2.6781409978866577e-01
    z[2,5,4]  R1648     -4.4630682468414307e-01
    z[2,5,4]  R1649     -4.3747693300247192e-01
    z[2,5,4]  R1650     -3.1682330369949341e-01
    z[2,5,4]  R1651     2.3010133206844330e-01
    z[2,5,4]  R1652     3.4058505296707153e-01
    z[2,5,4]  R1653     1.6457255184650421e-01
    z[2,5,4]  R1654     1.1215513199567795e-01
    z[2,5,4]  R1655     2.1339850500226021e-03
    z[2,5,4]  R1656     2.0488698035478592e-02
    z[2,5,4]  R1657     1.5322379767894745e-02
    z[2,5,4]  R1658     6.2139028310775757e-01
    z[2,5,4]  R1659     4.9387805163860321e-02
    z[2,5,4]  R1660     1.4650250971317291e-01
    z[2,5,4]  R1661     -1.3256011903285980e-01
    z[2,5,4]  R1662     3.7601027637720108e-02
    z[2,5,4]  R1663     -3.1871777772903442e-01
    z[2,5,4]  R1664     2.6871031522750854e-01
    z[2,5,4]  R1665     4.8271864652633667e-02
    z[2,5,4]  R1666     2.1161170303821564e-01
    z[2,5,4]  R1667     -3.2673040404915810e-03
    z[2,5,4]  R1668     0.360588401556015
    z[2,5,4]  R1669     0.0846773162484169
    z[2,5,4]  R1670     0.078289695084095
    z[2,5,4]  R1671     -2.1471163630485535e-01
    z[2,5,4]  R1672     4.7779548168182373e-01
    z[2,5,4]  R1673     -1.5561152994632721e-01
    z[2,5,4]  R1674     6.5029174089431763e-02
    z[2,5,4]  R1675     -5.4568547010421753e-01
    z[2,5,4]  R1676     -2.0039555430412292e-01
    z[2,5,4]  R1677     -6.9484390318393707e-02
    z[2,5,4]  R1678     -3.6225995421409607e-01
    z[2,5,4]  R1679     -3.3178317546844482e-01
    z[2,5,4]  R1680     -4.5058351755142212e-01
    z[2,5,4]  R1681     -1.4191937446594238e-01
    z[2,5,4]  R1682     -3.5129639506340027e-01
    z[2,5,4]  R1683     -2.0226357877254486e-01
    z[2,5,4]  R1684     -1.7484459280967712e-01
    z[2,5,4]  R1685     -2.4712309241294861e-01
    z[2,5,4]  R1686     -1.8820452690124512e-01
    z[2,5,4]  R1687     -7.1713291108608246e-02
    z[2,5,4]  R1688     -3.2527527213096619e-01
    z[2,5,4]  R1689     -3.5218662023544312e-01
    z[2,5,4]  R1690     0.144295796751976
    z[2,5,4]  R1691     -3.9359182119369507e-01
    z[2,5,4]  R1692     5.1760542392730713e-01
    z[2,5,4]  R1693     6.9337749481201172e-01
    z[2,5,4]  R1694     3.5283794999122620e-01
    z[2,5,4]  R1695     5.1066315174102783e-01
    z[2,5,4]  R1696     -2.9012659192085266e-01
    z[2,5,4]  R1697     -1.2565696239471436e-01
    z[2,5,4]  R1698     -2.2074703872203827e-01
    z[2,5,4]  R1699     2.0937354862689972e-01
    z[2,5,4]  R1700     -5.6084852665662766e-02
    z[2,5,5]  R25       -1
    z[2,5,5]  R52       1
    z[2,5,5]  R1607     -1
    z[2,5,5]  R1608     1
    z[2,5,5]  R1611     6.4517277479171753e-01
    z[2,5,5]  R1612     4.3082606792449951e-01
    z[2,5,5]  R1613     8.0412948131561279e-01
    z[2,5,5]  R1614     3.4908747673034668e-01
    z[2,5,5]  R1615     -1.3144983351230621e-01
    z[2,5,5]  R1616     2.1137522533535957e-02
    z[2,5,5]  R1617     2.9554679989814758e-01
    z[2,5,5]  R1618     2.6696437597274780e-01
    z[2,5,5]  R1619     -5.8818902820348740e-02
    z[2,5,5]  R1620     1.0087272524833679e-01
    z[2,5,5]  R1621     -4.9122326076030731e-02
    z[2,5,5]  R1622     -6.3139609992504120e-02
    z[2,5,5]  R1623     -0.00911277811974287
    z[2,5,5]  R1624     -3.5208237171173096e-01
    z[2,5,5]  R1625     -0.540863037109375
    z[2,5,5]  R1626     3.5498145222663879e-01
    z[2,5,5]  R1627     1.2205304205417633e-01
    z[2,5,5]  R1628     -5.9540885686874390e-01
    z[2,5,5]  R1629     1.9575688242912292e-01
    z[2,5,5]  R1630     5.3384047001600266e-02
    z[2,5,5]  R1631     -2.5146719813346863e-01
    z[2,5,5]  R1632     4.4127443432807922e-01
    z[2,5,5]  R1633     5.0499880313873291e-01
    z[2,5,5]  R1634     -1.5250724554061890e-01
    z[2,5,5]  R1635     -1.4797471463680267e-01
    z[2,5,5]  R1636     -3.1573437154293060e-02
    z[2,5,5]  R1637     2.4974641203880310e-01
    z[2,5,5]  R1638     -1.2833094596862793e-01
    z[2,5,5]  R1639     1.9335845112800598e-01
    z[2,5,5]  R1640     -1.1957912892103195e-01
    z[2,5,5]  R1641     1.0361205041408539e-01
    z[2,5,5]  R1642     9.6019506454467773e-03
    z[2,5,5]  R1643     3.0154320597648621e-01
    z[2,5,5]  R1644     7.7177612110972404e-03
    z[2,5,5]  R1645     1.1364541202783585e-01
    z[2,5,5]  R1646     2.3114676773548126e-01
    z[2,5,5]  R1647     2.4534982442855835e-01
    z[2,5,5]  R1648     2.8570652008056641e-01
    z[2,5,5]  R1649     -0.0637502521276474
    z[2,5,5]  R1650     9.4810724258422852e-02
    z[2,5,5]  R1651     1.6349695622920990e-02
    z[2,5,5]  R1652     4.0406482294201851e-03
    z[2,5,5]  R1653     -2.8824573755264282e-01
    z[2,5,5]  R1654     6.4108437299728394e-01
    z[2,5,5]  R1655     2.6808005571365356e-01
    z[2,5,5]  R1656     3.5143008828163147e-01
    z[2,5,5]  R1657     -1.1392273753881454e-01
    z[2,5,5]  R1658     2.9049047827720642e-01
    z[2,5,5]  R1659     1.9229158759117126e-01
    z[2,5,5]  R1660     -1.3685730099678040e-01
    z[2,5,5]  R1661     2.3453648388385773e-01
    z[2,5,5]  R1662     -0.155681312084198
    z[2,5,5]  R1663     -2.1839885041117668e-02
    z[2,5,5]  R1664     1.5839838981628418e-01
    z[2,5,5]  R1665     9.0267747640609741e-02
    z[2,5,5]  R1666     1.0915318131446838e-01
    z[2,5,5]  R1667     2.9655680060386658e-01
    z[2,5,5]  R1668     1.3262277841567993e-01
    z[2,5,5]  R1669     -0.0666360929608345
    z[2,5,5]  R1670     -2.6828205585479736e-01
    z[2,5,5]  R1671     2.8831627964973450e-01
    z[2,5,5]  R1672     6.0940408706665039e-01
    z[2,5,5]  R1673     -2.6306754350662231e-01
    z[2,5,5]  R1674     3.0098492279648781e-03
    z[2,5,5]  R1675     1.1404132843017578e-01
    z[2,5,5]  R1676     -3.3031675219535828e-01
    z[2,5,5]  R1677     -2.3639994859695435e-01
    z[2,5,5]  R1678     -1.1001867055892944e-01
    z[2,5,5]  R1679     -3.6067163944244385e-01
    z[2,5,5]  R1680     5.5549168586730957e-01
    z[2,5,5]  R1681     3.3442208170890808e-01
    z[2,5,5]  R1682     2.1022740006446838e-01
    z[2,5,5]  R1683     4.3663203716278076e-01
    z[2,5,5]  R1684     5.2558046579360962e-01
    z[2,5,5]  R1685     3.7022992968559265e-01
    z[2,5,5]  R1686     2.5225467979907990e-02
    z[2,5,5]  R1687     2.4903084337711334e-01
    z[2,5,5]  R1688     5.6108510494232178e-01
    z[2,5,5]  R1689     1.4927624724805355e-02
    z[2,5,5]  R1690     9.7732760012149811e-02
    z[2,5,5]  R1691     2.3926517367362976e-01
    z[2,5,5]  R1692     1.5449105203151703e-01
    z[2,5,5]  R1693     -6.4368017017841339e-02
    z[2,5,5]  R1694     6.5900111198425293e-01
    z[2,5,5]  R1695     -1.0784979909658432e-01
    z[2,5,5]  R1696     1.7631146311759949e-01
    z[2,5,5]  R1697     0.00893962662667036
    z[2,5,5]  R1698     5.4915450513362885e-02
    z[2,5,5]  R1699     -2.6482370495796204e-01
    z[2,5,5]  R1700     0.0788489356637001
    z[2,5,6]  R26       -1
    z[2,5,6]  R53       1
    z[2,5,6]  R1609     -1
    z[2,5,6]  R1610     1
    z[2,5,6]  R1611     2.9407748952507973e-02
    z[2,5,6]  R1612     -1.0284823179244995e-01
    z[2,5,6]  R1613     -1.7685037106275558e-02
    z[2,5,6]  R1614     7.0338404178619385e-01
    z[2,5,6]  R1615     3.5287228226661682e-01
    z[2,5,6]  R1616     2.1951857209205627e-01
    z[2,5,6]  R1617     1.4428961277008057e-01
    z[2,5,6]  R1618     -2.0811758935451508e-01
    z[2,5,6]  R1619     -1.6104213893413544e-01
    z[2,5,6]  R1620     -3.0834999680519104e-01
    z[2,5,6]  R1621     -5.6209444999694824e-01
    z[2,5,6]  R1622     -3.5043638944625854e-01
    z[2,5,6]  R1623     1.9959436357021332e-01
    z[2,5,6]  R1624     7.5668044388294220e-02
    z[2,5,6]  R1625     -1.9348785281181335e-01
    z[2,5,6]  R1626     -1.3416618108749390e-02
    z[2,5,6]  R1627     1.4407142996788025e-01
    z[2,5,6]  R1628     -0.443516343832016
    z[2,5,6]  R1629     -2.7404433488845825e-01
    z[2,5,6]  R1630     -2.0178568363189697e-01
    z[2,5,6]  R1631     -9.5452917739748955e-03
    z[2,5,6]  R1632     -1.8258096277713776e-01
    z[2,5,6]  R1633     5.1814638078212738e-02
    z[2,5,6]  R1634     -1.8083012104034424e-01
    z[2,5,6]  R1635     2.2764241695404053e-01
    z[2,5,6]  R1636     1.0954919457435608e-01
    z[2,5,6]  R1637     3.7324190139770508e-02
    z[2,5,6]  R1638     6.9620959460735321e-02
    z[2,5,6]  R1639     -1.7409196496009827e-01
    z[2,5,6]  R1640     -2.9442825913429260e-01
    z[2,5,6]  R1641     -2.6521581411361694e-01
    z[2,5,6]  R1642     -2.2699010372161865e-01
    z[2,5,6]  R1643     2.6001834869384766e-01
    z[2,5,6]  R1644     5.5389977991580963e-02
    z[2,5,6]  R1645     -2.8567776083946228e-01
    z[2,5,6]  R1646     6.4749278128147125e-02
    z[2,5,6]  R1647     1.5751951932907104e-01
    z[2,5,6]  R1648     1.5132038295269012e-01
    z[2,5,6]  R1649     2.5233200192451477e-01
    z[2,5,6]  R1650     -0.035448107868433
    z[2,5,6]  R1651     3.0506783723831177e-01
    z[2,5,6]  R1652     -1.6707411408424377e-01
    z[2,5,6]  R1653     -1.4030157029628754e-01
    z[2,5,6]  R1654     -1.5614232420921326e-01
    z[2,5,6]  R1655     -6.9573158025741577e-01
    z[2,5,6]  R1656     3.9206331968307495e-01
    z[2,5,6]  R1657     -4.4810160994529724e-01
    z[2,5,6]  R1658     -1.3658446073532104e-01
    z[2,5,6]  R1659     6.9953277707099915e-03
    z[2,5,6]  R1660     -4.5238631963729858e-01
    z[2,5,6]  R1661     -1.8078187480568886e-02
    z[2,5,6]  R1662     3.6166332662105560e-02
    z[2,5,6]  R1663     -4.2214909195899963e-01
    z[2,5,6]  R1664     3.2443445920944214e-01
    z[2,5,6]  R1665     -1.1246681213378906e-02
    z[2,5,6]  R1666     0.0382811576128006
    z[2,5,6]  R1667     -2.4132886528968811e-01
    z[2,5,6]  R1668     -3.7785002589225769e-01
    z[2,5,6]  R1669     -1.8799139559268951e-01
    z[2,5,6]  R1670     -4.2002037167549133e-02
    z[2,5,6]  R1671     4.2526909708976746e-01
    z[2,5,6]  R1672     1.3504503667354584e-01
    z[2,5,6]  R1673     3.2356211543083191e-01
    z[2,5,6]  R1674     1.5062689781188965e-01
    z[2,5,6]  R1675     -1.1830971390008926e-01
    z[2,5,6]  R1676     5.9109228849411011e-01
    z[2,5,6]  R1677     6.6986465454101562e-01
    z[2,5,6]  R1678     -2.7612483501434326e-01
    z[2,5,6]  R1679     3.7648779153823853e-01
    z[2,5,6]  R1680     -4.1460883617401123e-01
    z[2,5,6]  R1681     -7.3883078992366791e-02
    z[2,5,6]  R1682     2.6690849661827087e-01
    z[2,5,6]  R1683     2.3986613750457764e-01
    z[2,5,6]  R1684     -0.35416179895401
    z[2,5,6]  R1685     6.2710128724575043e-02
    z[2,5,6]  R1686     -6.3965469598770142e-02
    z[2,5,6]  R1687     -1.5120127797126770e-01
    z[2,5,6]  R1688     1.5688399970531464e-01
    z[2,5,6]  R1689     8.8956616818904877e-03
    z[2,5,6]  R1690     8.6626596748828888e-02
    z[2,5,6]  R1691     -2.4196162819862366e-01
    z[2,5,6]  R1692     -3.4563142806291580e-02
    z[2,5,6]  R1693     2.7168050408363342e-01
    z[2,5,6]  R1694     1.4697673916816711e-01
    z[2,5,6]  R1695     6.4747321605682373e-01
    z[2,5,6]  R1696     6.5576941706240177e-03
    z[2,5,6]  R1697     5.0558692216873169e-01
    z[2,5,6]  R1698     2.6151040196418762e-01
    z[2,5,6]  R1699     1.1140928417444229e-01
    z[2,5,6]  R1700     -3.5501249134540558e-02
    z[5,2,0]  R20       1
    z[5,2,0]  R47       -1
    z[5,2,0]  R1701     -1
    z[5,2,0]  R1702     1
    z[5,2,0]  R1715     9.1751128435134888e-02
    z[5,2,0]  R1716     -2.9391407966613770e-01
    z[5,2,0]  R1717     3.5134589672088623e-01
    z[5,2,0]  R1718     1.8095086514949799e-01
    z[5,2,0]  R1719     4.5932576060295105e-02
    z[5,2,0]  R1720     0.0817050188779831
    z[5,2,0]  R1721     1.5777802467346191e-01
    z[5,2,0]  R1722     -2.8450459241867065e-01
    z[5,2,0]  R1723     -2.5793009996414185e-01
    z[5,2,0]  R1724     2.9511460661888123e-01
    z[5,2,0]  R1725     -8.0357983708381653e-02
    z[5,2,0]  R1726     -2.6397609710693359e-01
    z[5,2,0]  R1727     -7.9158611595630646e-02
    z[5,2,0]  R1728     -1.3939459621906281e-01
    z[5,2,0]  R1729     3.3405673503875732e-01
    z[5,2,0]  R1730     -3.1011231243610382e-02
    z[5,2,0]  R1731     -2.3243987560272217e-01
    z[5,2,0]  R1732     6.5164053812623024e-03
    z[5,2,0]  R1733     -1.2624450027942657e-01
    z[5,2,0]  R1734     3.0309295654296875e-01
    z[5,2,0]  R1735     -6.2123370170593262e-01
    z[5,2,0]  R1736     -1.2315837293863297e-01
    z[5,2,0]  R1737     -7.4878519773483276e-01
    z[5,2,0]  R1738     1.7647108435630798e-01
    z[5,2,0]  R1739     -7.7983301877975464e-01
    z[5,2,0]  R1740     -4.7811153531074524e-01
    z[5,2,0]  R1741     -3.9945331215858459e-01
    z[5,2,0]  R1742     -7.3482406139373779e-01
    z[5,2,0]  R1743     -5.1747697591781616e-01
    z[5,2,0]  R1744     -5.3739684820175171e-01
    z[5,2,0]  R1745     5.9888356924057007e-01
    z[5,2,0]  R1746     1.9250044226646423e-01
    z[5,2,0]  R1747     3.4843954443931580e-01
    z[5,2,0]  R1748     -1.4973483979701996e-01
    z[5,2,0]  R1749     5.2489286661148071e-01
    z[5,2,0]  R1750     7.5461953878402710e-01
    z[5,2,0]  R1751     6.6458392143249512e-01
    z[5,2,0]  R1752     -2.1477121859788895e-02
    z[5,2,0]  R1753     0.493700236082077
    z[5,2,0]  R1754     5.5405634641647339e-01
    z[5,2,0]  R1755     -3.0755949020385742e-01
    z[5,2,0]  R1756     5.7791608572006226e-01
    z[5,2,0]  R1757     3.1935986876487732e-01
    z[5,2,0]  R1758     -5.7855671644210815e-01
    z[5,2,0]  R1759     2.0953913033008575e-01
    z[5,2,0]  R1760     2.7045177295804024e-02
    z[5,2,0]  R1761     1.8525169789791107e-01
    z[5,2,0]  R1762     7.2206068038940430e-01
    z[5,2,0]  R1763     0.537449300289154
    z[5,2,0]  R1764     7.2452224791049957e-02
    z[5,2,0]  R1765     3.1432923674583435e-01
    z[5,2,0]  R1766     1.1821191757917404e-01
    z[5,2,0]  R1767     -4.2595438659191132e-02
    z[5,2,0]  R1768     -2.8032967820763588e-02
    z[5,2,0]  R1769     2.3776893317699432e-01
    z[5,2,0]  R1770     7.2030341625213623e-01
    z[5,2,0]  R1771     3.6836597323417664e-01
    z[5,2,0]  R1772     6.8994998931884766e-01
    z[5,2,0]  R1773     5.5068814754486084e-01
    z[5,2,0]  R1774     3.8371109962463379e-01
    z[5,2,0]  R1775     -5.1737666130065918e-01
    z[5,2,0]  R1776     5.7984985411167145e-02
    z[5,2,0]  R1777     -3.4597349166870117e-01
    z[5,2,0]  R1778     -6.9435632228851318e-01
    z[5,2,0]  R1779     -5.8090382814407349e-01
    z[5,2,0]  R1780     -7.2835075855255127e-01
    z[5,2,0]  R1781     -6.3251376152038574e-01
    z[5,2,0]  R1782     -0.282098650932312
    z[5,2,0]  R1783     -8.0061239004135132e-01
    z[5,2,0]  R1784     2.9811334609985352e-01
    z[5,2,0]  R1785     -0.727404773235321
    z[5,2,0]  R1786     -6.9134902954101562e-01
    z[5,2,0]  R1787     -3.8005176186561584e-01
    z[5,2,0]  R1788     2.9792213439941406e-01
    z[5,2,0]  R1789     2.5141090154647827e-01
    z[5,2,0]  R1790     4.8459729552268982e-01
    z[5,2,0]  R1791     2.2911366820335388e-01
    z[5,2,0]  R1792     2.8318625688552856e-01
    z[5,2,0]  R1793     1.4619770646095276e-01
    z[5,2,0]  R1794     5.0927591323852539e-01
    z[5,2,0]  R1795     -3.6842474341392517e-01
    z[5,2,0]  R1796     3.8788583874702454e-01
    z[5,2,0]  R1797     0.511343777179718
    z[5,2,0]  R1798     4.3528911471366882e-01
    z[5,2,0]  R1799     2.7572733163833618e-01
    z[5,2,0]  R1800     0.501968264579773
    z[5,2,0]  R1801     2.5607383251190186e-01
    z[5,2,0]  R1802     4.8280277848243713e-01
    z[5,2,0]  R1803     1.5415605902671814e-01
    z[5,2,0]  R1804     1.2871250510215759e-01
    z[5,2,1]  R21       1
    z[5,2,1]  R48       -1
    z[5,2,1]  R1703     -1
    z[5,2,1]  R1704     1
    z[5,2,1]  R1715     8.7547320127487183e-01
    z[5,2,1]  R1716     8.5558646917343140e-01
    z[5,2,1]  R1717     7.4692708253860474e-01
    z[5,2,1]  R1718     7.0906698703765869e-01
    z[5,2,1]  R1719     6.2525153160095215e-01
    z[5,2,1]  R1720     6.2553548812866211e-01
    z[5,2,1]  R1721     4.2846208810806274e-01
    z[5,2,1]  R1722     6.0804325342178345e-01
    z[5,2,1]  R1723     2.9897719621658325e-01
    z[5,2,1]  R1724     6.6439443826675415e-01
    z[5,2,1]  R1725     -9.2065292596817017e-01
    z[5,2,1]  R1726     -9.4883036613464355e-01
    z[5,2,1]  R1727     -8.4418761730194092e-01
    z[5,2,1]  R1728     -8.5557991266250610e-01
    z[5,2,1]  R1729     -8.8591217994689941e-01
    z[5,2,1]  R1730     -8.5599416494369507e-01
    z[5,2,1]  R1731     -0.837941586971283
    z[5,2,1]  R1732     -8.3161729574203491e-01
    z[5,2,1]  R1733     -8.2682949304580688e-01
    z[5,2,1]  R1734     -8.9267814159393311e-01
    z[5,2,1]  R1735     -9.1890551149845123e-02
    z[5,2,1]  R1736     -1.7950126528739929e-01
    z[5,2,1]  R1737     3.0340716242790222e-01
    z[5,2,1]  R1738     2.9247373342514038e-01
    z[5,2,1]  R1739     1.9021998345851898e-01
    z[5,2,1]  R1740     2.6451054215431213e-01
    z[5,2,1]  R1741     1.7234939336776733e-01
    z[5,2,1]  R1742     4.5606139302253723e-01
    z[5,2,1]  R1743     3.7726444005966187e-01
    z[5,2,1]  R1744     -2.4689415469765663e-02
    z[5,2,1]  R1745     -1.1694305390119553e-01
    z[5,2,1]  R1746     -6.3666746020317078e-02
    z[5,2,1]  R1747     -5.9154576063156128e-01
    z[5,2,1]  R1748     7.1902751922607422e-02
    z[5,2,1]  R1749     -5.9003078937530518e-01
    z[5,2,1]  R1750     -5.4779714345932007e-01
    z[5,2,1]  R1751     -5.7059872150421143e-01
    z[5,2,1]  R1752     -6.3786470890045166e-01
    z[5,2,1]  R1753     -6.7252731323242188e-01
    z[5,2,1]  R1754     -6.6398131847381592e-01
    z[5,2,1]  R1755     4.1244527697563171e-01
    z[5,2,1]  R1756     2.9022064805030823e-01
    z[5,2,1]  R1757     0.279297411441803
    z[5,2,1]  R1758     -0.230604350566864
    z[5,2,1]  R1759     1.7475579679012299e-01
    z[5,2,1]  R1760     8.5760280489921570e-02
    z[5,2,1]  R1761     -3.2181721925735474e-01
    z[5,2,1]  R1762     -2.1566207706928253e-01
    z[5,2,1]  R1763     -3.5702559351921082e-01
    z[5,2,1]  R1764     -6.3930189609527588e-01
    z[5,2,1]  R1765     4.3151691555976868e-01
    z[5,2,1]  R1766     4.2549699544906616e-01
    z[5,2,1]  R1767     5.2562618255615234e-01
    z[5,2,1]  R1768     5.6732589006423950e-01
    z[5,2,1]  R1769     8.2880979776382446e-01
    z[5,2,1]  R1770     -6.1817508935928345e-01
    z[5,2,1]  R1771     -2.8042098879814148e-01
    z[5,2,1]  R1772     -3.8915368914604187e-01
    z[5,2,1]  R1773     -0.612704873085022
    z[5,2,1]  R1774     -3.9651420712471008e-01
    z[5,2,1]  R1775     4.7555673122406006e-01
    z[5,2,1]  R1776     0.518293559551239
    z[5,2,1]  R1777     2.9023453593254089e-01
    z[5,2,1]  R1778     3.4667372703552246e-01
    z[5,2,1]  R1779     3.2177156209945679e-01
    z[5,2,1]  R1780     -1.8335235118865967e-01
    z[5,2,1]  R1781     -7.5615622103214264e-02
    z[5,2,1]  R1782     2.2285100817680359e-01
    z[5,2,1]  R1783     -1.9160155951976776e-01
    z[5,2,1]  R1784     -7.9132926464080811e-01
    z[5,2,1]  R1785     5.5986744165420532e-01
    z[5,2,1]  R1786     2.4091683328151703e-01
    z[5,2,1]  R1787     -2.6302519440650940e-01
    z[5,2,1]  R1788     -8.7849563360214233e-01
    z[5,2,1]  R1789     -9.0676325559616089e-01
    z[5,2,1]  R1790     -0.81097811460495
    z[5,2,1]  R1791     -9.1801899671554565e-01
    z[5,2,1]  R1792     -8.8772386312484741e-01
    z[5,2,1]  R1793     -9.1601639986038208e-01
    z[5,2,1]  R1794     -7.4158489704132080e-01
    z[5,2,1]  R1795     4.2555916309356689e-01
    z[5,2,1]  R1796     -0.866968035697937
    z[5,2,1]  R1797     -6.5728002786636353e-01
    z[5,2,1]  R1798     -4.3178817629814148e-01
    z[5,2,1]  R1799     -4.6381074190139771e-01
    z[5,2,1]  R1800     -2.9665133357048035e-01
    z[5,2,1]  R1801     -4.6428361535072327e-01
    z[5,2,1]  R1802     -4.8970067501068115e-01
    z[5,2,1]  R1803     -5.3583443164825439e-01
    z[5,2,1]  R1804     -5.1682722568511963e-01
    z[5,2,2]  R22       1
    z[5,2,2]  R49       -1
    z[5,2,2]  R1705     -1
    z[5,2,2]  R1706     1
    z[5,2,2]  R1715     2.2204430401325226e-01
    z[5,2,2]  R1716     -6.9286718964576721e-02
    z[5,2,2]  R1717     1.0267228819429874e-02
    z[5,2,2]  R1718     -3.1002461910247803e-02
    z[5,2,2]  R1719     1.0819110274314880e-01
    z[5,2,2]  R1720     -3.7111940979957581e-01
    z[5,2,2]  R1721     7.5985920429229736e-01
    z[5,2,2]  R1722     -2.4186022579669952e-01
    z[5,2,2]  R1723     7.5410521030426025e-01
    z[5,2,2]  R1724     -4.7407627105712891e-01
    z[5,2,2]  R1725     2.6614934206008911e-01
    z[5,2,2]  R1726     -4.7693509608507156e-02
    z[5,2,2]  R1727     2.5060348212718964e-02
    z[5,2,2]  R1728     -2.1321940422058105e-01
    z[5,2,2]  R1729     0.201337531208992
    z[5,2,2]  R1730     -2.9549381136894226e-01
    z[5,2,2]  R1731     -1.6530798375606537e-01
    z[5,2,2]  R1732     0.0824781134724617
    z[5,2,2]  R1733     -6.8636782467365265e-02
    z[5,2,2]  R1734     1.6016195714473724e-01
    z[5,2,2]  R1735     -4.8945721983909607e-01
    z[5,2,2]  R1736     5.1430130004882812e-01
    z[5,2,2]  R1737     3.4037387371063232e-01
    z[5,2,2]  R1738     -8.9806658029556274e-01
    z[5,2,2]  R1739     -0.0916375145316124
    z[5,2,2]  R1740     3.0163705348968506e-02
    z[5,2,2]  R1741     -4.7916686534881592e-01
    z[5,2,2]  R1742     -1.5109807252883911e-01
    z[5,2,2]  R1743     -3.7307778000831604e-01
    z[5,2,2]  R1744     -9.4032082706689835e-03
    z[5,2,2]  R1745     8.0027438700199127e-02
    z[5,2,2]  R1746     -5.8725923299789429e-02
    z[5,2,2]  R1747     1.0964184254407883e-01
    z[5,2,2]  R1748     -7.3334950208663940e-01
    z[5,2,2]  R1749     4.0528017282485962e-01
    z[5,2,2]  R1750     0.284252792596817
    z[5,2,2]  R1751     3.6815294623374939e-01
    z[5,2,2]  R1752     1.5899296104907990e-01
    z[5,2,2]  R1753     4.2180046439170837e-01
    z[5,2,2]  R1754     4.2704778909683228e-01
    z[5,2,2]  R1755     -5.3261661529541016e-01
    z[5,2,2]  R1756     -4.9754548072814941e-01
    z[5,2,2]  R1757     4.1682365536689758e-01
    z[5,2,2]  R1758     -9.4092383980751038e-02
    z[5,2,2]  R1759     6.6872701048851013e-02
    z[5,2,2]  R1760     5.3215879201889038e-01
    z[5,2,2]  R1761     4.9683311581611633e-01
    z[5,2,2]  R1762     4.9082070589065552e-01
    z[5,2,2]  R1763     6.5681940317153931e-01
    z[5,2,2]  R1764     6.7451059818267822e-01
    z[5,2,2]  R1765     -1.4077208936214447e-01
    z[5,2,2]  R1766     9.7302317619323730e-02
    z[5,2,2]  R1767     -2.1837297081947327e-01
    z[5,2,2]  R1768     1.1307616531848907e-01
    z[5,2,2]  R1769     -1.9834028184413910e-01
    z[5,2,2]  R1770     -1.0964637994766235e-01
    z[5,2,2]  R1771     8.0503863096237183e-01
    z[5,2,2]  R1772     4.9628299474716187e-01
    z[5,2,2]  R1773     4.6857553720474243e-01
    z[5,2,2]  R1774     -0.295538067817688
    z[5,2,2]  R1775     -2.3308368399739265e-02
    z[5,2,2]  R1776     -4.4742828607559204e-01
    z[5,2,2]  R1777     -5.0015095621347427e-02
    z[5,2,2]  R1778     1.6715654730796814e-01
    z[5,2,2]  R1779     3.5724112391471863e-01
    z[5,2,2]  R1780     2.2476868331432343e-01
    z[5,2,2]  R1781     5.4395663738250732e-01
    z[5,2,2]  R1782     -1.1327151954174042e-01
    z[5,2,2]  R1783     0.394095242023468
    z[5,2,2]  R1784     -2.5027871131896973e-01
    z[5,2,2]  R1785     2.8507426381111145e-01
    z[5,2,2]  R1786     9.3729391694068909e-02
    z[5,2,2]  R1787     2.3452764749526978e-01
    z[5,2,2]  R1788     -6.1158183962106705e-02
    z[5,2,2]  R1789     1.6787745058536530e-01
    z[5,2,2]  R1790     -1.3995537161827087e-01
    z[5,2,2]  R1791     4.8986006528139114e-02
    z[5,2,2]  R1792     1.9130004942417145e-01
    z[5,2,2]  R1793     1.5195025503635406e-01
    z[5,2,2]  R1794     -2.1155475080013275e-01
    z[5,2,2]  R1795     -2.0650514960289001e-01
    z[5,2,2]  R1796     -3.3399043604731560e-03
    z[5,2,2]  R1797     8.1033043563365936e-02
    z[5,2,2]  R1798     6.9183951616287231e-01
    z[5,2,2]  R1799     6.9558727741241455e-01
    z[5,2,2]  R1800     0.603071391582489
    z[5,2,2]  R1801     0.738192081451416
    z[5,2,2]  R1802     4.5026838779449463e-01
    z[5,2,2]  R1803     6.5014606714248657e-01
    z[5,2,2]  R1804     0.777576744556427
    z[5,2,3]  R23       1
    z[5,2,3]  R50       -1
    z[5,2,3]  R1707     -1
    z[5,2,3]  R1708     1
    z[5,2,3]  R1715     -1.7188473045825958e-01
    z[5,2,3]  R1716     1.8126615881919861e-01
    z[5,2,3]  R1717     4.3439182639122009e-01
    z[5,2,3]  R1718     -1.2478467077016830e-01
    z[5,2,3]  R1719     1.9832178950309753e-01
    z[5,2,3]  R1720     4.3204563856124878e-01
    z[5,2,3]  R1721     1.1489140801131725e-02
    z[5,2,3]  R1722     -4.0967710316181183e-02
    z[5,2,3]  R1723     4.8574271798133850e-01
    z[5,2,3]  R1724     -4.3506991118192673e-02
    z[5,2,3]  R1725     -4.6891830861568451e-02
    z[5,2,3]  R1726     -2.8363440185785294e-02
    z[5,2,3]  R1727     1.3611934147775173e-02
    z[5,2,3]  R1728     -0.0231669619679451
    z[5,2,3]  R1729     2.2896258533000946e-01
    z[5,2,3]  R1730     3.4761503338813782e-01
    z[5,2,3]  R1731     2.6514670252799988e-01
    z[5,2,3]  R1732     1.0575447231531143e-01
    z[5,2,3]  R1733     4.9875143170356750e-01
    z[5,2,3]  R1734     7.5762018561363220e-02
    z[5,2,3]  R1735     -2.3659074306488037e-01
    z[5,2,3]  R1736     -2.6496499776840210e-01
    z[5,2,3]  R1737     -1.8247883021831512e-01
    z[5,2,3]  R1738     -2.2330953180789948e-01
    z[5,2,3]  R1739     -1.5001441538333893e-01
    z[5,2,3]  R1740     -4.4930616021156311e-01
    z[5,2,3]  R1741     -2.6776903867721558e-01
    z[5,2,3]  R1742     9.8131135106086731e-02
    z[5,2,3]  R1743     -2.6228803396224976e-01
    z[5,2,3]  R1744     -1.6434629261493683e-01
    z[5,2,3]  R1745     -6.9557195901870728e-01
    z[5,2,3]  R1746     -0.846520185470581
    z[5,2,3]  R1747     -4.7702023386955261e-01
    z[5,2,3]  R1748     -4.8704613000154495e-02
    z[5,2,3]  R1749     -1.0013290494680405e-01
    z[5,2,3]  R1750     -9.7566343843936920e-02
    z[5,2,3]  R1751     -8.4781445562839508e-02
    z[5,2,3]  R1752     -0.349507600069046
    z[5,2,3]  R1753     -4.1402030736207962e-02
    z[5,2,3]  R1754     1.7861567437648773e-01
    z[5,2,3]  R1755     -4.2533260583877563e-01
    z[5,2,3]  R1756     -2.0311589539051056e-01
    z[5,2,3]  R1757     -2.9586234688758850e-01
    z[5,2,3]  R1758     1.5119914710521698e-01
    z[5,2,3]  R1759     -4.7901135683059692e-01
    z[5,2,3]  R1760     -7.7033668756484985e-01
    z[5,2,3]  R1761     -5.8633148670196533e-01
    z[5,2,3]  R1762     -2.6660934090614319e-01
    z[5,2,3]  R1763     1.6089810431003571e-01
    z[5,2,3]  R1764     3.4706801176071167e-01
    z[5,2,3]  R1765     1.5378223359584808e-01
    z[5,2,3]  R1766     -2.1045181900262833e-02
    z[5,2,3]  R1767     1.5678630769252777e-01
    z[5,2,3]  R1768     0.206902414560318
    z[5,2,3]  R1769     2.7443605661392212e-01
    z[5,2,3]  R1770     -1.2152399122714996e-01
    z[5,2,3]  R1771     1.6491317749023438e-01
    z[5,2,3]  R1772     -9.8055362701416016e-02
    z[5,2,3]  R1773     2.6900875568389893e-01
    z[5,2,3]  R1774     7.0876121520996094e-01
    z[5,2,3]  R1775     -4.3087130784988403e-01
    z[5,2,3]  R1776     -5.1461577415466309e-01
    z[5,2,3]  R1777     -6.5086215734481812e-01
    z[5,2,3]  R1778     1.0967974364757538e-01
    z[5,2,3]  R1779     2.5317004323005676e-01
    z[5,2,3]  R1780     -3.0487614870071411e-01
    z[5,2,3]  R1781     -4.6829420328140259e-01
    z[5,2,3]  R1782     4.8402658104896545e-01
    z[5,2,3]  R1783     2.2843122482299805e-01
    z[5,2,3]  R1784     2.0251031219959259e-01
    z[5,2,3]  R1785     -0.0773281380534172
    z[5,2,3]  R1786     0.431424617767334
    z[5,2,3]  R1787     -6.8704259395599365e-01
    z[5,2,3]  R1788     2.6176929473876953e-01
    z[5,2,3]  R1789     1.0777126997709274e-01
    z[5,2,3]  R1790     -1.5613524615764618e-01
    z[5,2,3]  R1791     -1.8808171153068542e-01
    z[5,2,3]  R1792     -2.1368660032749176e-01
    z[5,2,3]  R1793     -7.0396766066551208e-02
    z[5,2,3]  R1794     -2.1032449603080750e-01
    z[5,2,3]  R1795     6.5436446666717529e-01
    z[5,2,3]  R1796     -1.0747081041336060e-01
    z[5,2,3]  R1797     1.3733908534049988e-01
    z[5,2,3]  R1798     -2.0159746706485748e-01
    z[5,2,3]  R1799     5.9304811060428619e-02
    z[5,2,3]  R1800     -1.3849201798439026e-01
    z[5,2,3]  R1801     1.3117182254791260e-01
    z[5,2,3]  R1802     -1.4365708827972412e-01
    z[5,2,3]  R1803     -8.5474856197834015e-02
    z[5,2,3]  R1804     -3.2779112458229065e-02
    z[5,2,4]  R24       1
    z[5,2,4]  R51       -1
    z[5,2,4]  R1709     -1
    z[5,2,4]  R1710     1
    z[5,2,4]  R1715     2.3010133206844330e-01
    z[5,2,4]  R1716     3.4058505296707153e-01
    z[5,2,4]  R1717     1.6457255184650421e-01
    z[5,2,4]  R1718     1.1215513199567795e-01
    z[5,2,4]  R1719     2.1339850500226021e-03
    z[5,2,4]  R1720     2.0488698035478592e-02
    z[5,2,4]  R1721     1.5322379767894745e-02
    z[5,2,4]  R1722     6.2139028310775757e-01
    z[5,2,4]  R1723     4.9387805163860321e-02
    z[5,2,4]  R1724     1.4650250971317291e-01
    z[5,2,4]  R1725     -1.3256011903285980e-01
    z[5,2,4]  R1726     3.7601027637720108e-02
    z[5,2,4]  R1727     -3.1871777772903442e-01
    z[5,2,4]  R1728     2.6871031522750854e-01
    z[5,2,4]  R1729     4.8271864652633667e-02
    z[5,2,4]  R1730     2.1161170303821564e-01
    z[5,2,4]  R1731     -3.2673040404915810e-03
    z[5,2,4]  R1732     0.360588401556015
    z[5,2,4]  R1733     0.0846773162484169
    z[5,2,4]  R1734     0.078289695084095
    z[5,2,4]  R1735     -2.1471163630485535e-01
    z[5,2,4]  R1736     4.7779548168182373e-01
    z[5,2,4]  R1737     -1.5561152994632721e-01
    z[5,2,4]  R1738     6.5029174089431763e-02
    z[5,2,4]  R1739     -5.4568547010421753e-01
    z[5,2,4]  R1740     -2.0039555430412292e-01
    z[5,2,4]  R1741     -6.9484390318393707e-02
    z[5,2,4]  R1742     -3.6225995421409607e-01
    z[5,2,4]  R1743     -3.3178317546844482e-01
    z[5,2,4]  R1744     -4.5058351755142212e-01
    z[5,2,4]  R1745     -1.4191937446594238e-01
    z[5,2,4]  R1746     -3.5129639506340027e-01
    z[5,2,4]  R1747     -2.0226357877254486e-01
    z[5,2,4]  R1748     -1.7484459280967712e-01
    z[5,2,4]  R1749     -2.4712309241294861e-01
    z[5,2,4]  R1750     -1.8820452690124512e-01
    z[5,2,4]  R1751     -7.1713291108608246e-02
    z[5,2,4]  R1752     -3.2527527213096619e-01
    z[5,2,4]  R1753     -3.5218662023544312e-01
    z[5,2,4]  R1754     0.144295796751976
    z[5,2,4]  R1755     -3.9359182119369507e-01
    z[5,2,4]  R1756     5.1760542392730713e-01
    z[5,2,4]  R1757     6.9337749481201172e-01
    z[5,2,4]  R1758     3.5283794999122620e-01
    z[5,2,4]  R1759     5.1066315174102783e-01
    z[5,2,4]  R1760     -2.9012659192085266e-01
    z[5,2,4]  R1761     -1.2565696239471436e-01
    z[5,2,4]  R1762     -2.2074703872203827e-01
    z[5,2,4]  R1763     2.0937354862689972e-01
    z[5,2,4]  R1764     -5.6084852665662766e-02
    z[5,2,4]  R1765     5.0439256429672241e-01
    z[5,2,4]  R1766     7.7387249469757080e-01
    z[5,2,4]  R1767     5.1933001726865768e-02
    z[5,2,4]  R1768     7.1761339902877808e-02
    z[5,2,4]  R1769     9.4068972393870354e-03
    z[5,2,4]  R1770     1.5361286699771881e-01
    z[5,2,4]  R1771     4.7112341970205307e-02
    z[5,2,4]  R1772     4.5098189264535904e-02
    z[5,2,4]  R1773     -3.5120092798024416e-03
    z[5,2,4]  R1774     -2.4536836892366409e-02
    z[5,2,4]  R1775     -4.0133681148290634e-02
    z[5,2,4]  R1776     -3.6904710531234741e-01
    z[5,2,4]  R1777     -5.7447558641433716e-01
    z[5,2,4]  R1778     -4.7752285003662109e-01
    z[5,2,4]  R1779     0.193202406167984
    z[5,2,4]  R1780     -4.0770679712295532e-01
    z[5,2,4]  R1781     2.0824690163135529e-01
    z[5,2,4]  R1782     -2.6912295818328857e-01
    z[5,2,4]  R1783     0.0373593270778656
    z[5,2,4]  R1784     -3.7109193205833435e-01
    z[5,2,4]  R1785     -8.2805931568145752e-02
    z[5,2,4]  R1786     -2.0254465937614441e-01
    z[5,2,4]  R1787     -4.0486253798007965e-02
    z[5,2,4]  R1788     -1.0614348202943802e-01
    z[5,2,4]  R1789     -3.2525051385164261e-02
    z[5,2,4]  R1790     -2.2475828230381012e-01
    z[5,2,4]  R1791     -5.6633982807397842e-02
    z[5,2,4]  R1792     1.6786442697048187e-01
    z[5,2,4]  R1793     2.0928440988063812e-01
    z[5,2,4]  R1794     -2.6660870760679245e-02
    z[5,2,4]  R1795     -3.6228525638580322e-01
    z[5,2,4]  R1796     1.8636827170848846e-01
    z[5,2,4]  R1797     3.5006308555603027e-01
    z[5,2,4]  R1798     -3.1885942816734314e-01
    z[5,2,4]  R1799     -3.5632592439651489e-01
    z[5,2,4]  R1800     -4.6853971481323242e-01
    z[5,2,4]  R1801     -2.6781409978866577e-01
    z[5,2,4]  R1802     -4.4630682468414307e-01
    z[5,2,4]  R1803     -4.3747693300247192e-01
    z[5,2,4]  R1804     -3.1682330369949341e-01
    z[5,2,5]  R25       1
    z[5,2,5]  R52       -1
    z[5,2,5]  R1711     -1
    z[5,2,5]  R1712     1
    z[5,2,5]  R1715     1.6349695622920990e-02
    z[5,2,5]  R1716     4.0406482294201851e-03
    z[5,2,5]  R1717     -2.8824573755264282e-01
    z[5,2,5]  R1718     6.4108437299728394e-01
    z[5,2,5]  R1719     2.6808005571365356e-01
    z[5,2,5]  R1720     3.5143008828163147e-01
    z[5,2,5]  R1721     -1.1392273753881454e-01
    z[5,2,5]  R1722     2.9049047827720642e-01
    z[5,2,5]  R1723     1.9229158759117126e-01
    z[5,2,5]  R1724     -1.3685730099678040e-01
    z[5,2,5]  R1725     2.3453648388385773e-01
    z[5,2,5]  R1726     -0.155681312084198
    z[5,2,5]  R1727     -2.1839885041117668e-02
    z[5,2,5]  R1728     1.5839838981628418e-01
    z[5,2,5]  R1729     9.0267747640609741e-02
    z[5,2,5]  R1730     1.0915318131446838e-01
    z[5,2,5]  R1731     2.9655680060386658e-01
    z[5,2,5]  R1732     1.3262277841567993e-01
    z[5,2,5]  R1733     -0.0666360929608345
    z[5,2,5]  R1734     -2.6828205585479736e-01
    z[5,2,5]  R1735     2.8831627964973450e-01
    z[5,2,5]  R1736     6.0940408706665039e-01
    z[5,2,5]  R1737     -2.6306754350662231e-01
    z[5,2,5]  R1738     3.0098492279648781e-03
    z[5,2,5]  R1739     1.1404132843017578e-01
    z[5,2,5]  R1740     -3.3031675219535828e-01
    z[5,2,5]  R1741     -2.3639994859695435e-01
    z[5,2,5]  R1742     -1.1001867055892944e-01
    z[5,2,5]  R1743     -3.6067163944244385e-01
    z[5,2,5]  R1744     5.5549168586730957e-01
    z[5,2,5]  R1745     3.3442208170890808e-01
    z[5,2,5]  R1746     2.1022740006446838e-01
    z[5,2,5]  R1747     4.3663203716278076e-01
    z[5,2,5]  R1748     5.2558046579360962e-01
    z[5,2,5]  R1749     3.7022992968559265e-01
    z[5,2,5]  R1750     2.5225467979907990e-02
    z[5,2,5]  R1751     2.4903084337711334e-01
    z[5,2,5]  R1752     5.6108510494232178e-01
    z[5,2,5]  R1753     1.4927624724805355e-02
    z[5,2,5]  R1754     9.7732760012149811e-02
    z[5,2,5]  R1755     2.3926517367362976e-01
    z[5,2,5]  R1756     1.5449105203151703e-01
    z[5,2,5]  R1757     -6.4368017017841339e-02
    z[5,2,5]  R1758     6.5900111198425293e-01
    z[5,2,5]  R1759     -1.0784979909658432e-01
    z[5,2,5]  R1760     1.7631146311759949e-01
    z[5,2,5]  R1761     0.00893962662667036
    z[5,2,5]  R1762     5.4915450513362885e-02
    z[5,2,5]  R1763     -2.6482370495796204e-01
    z[5,2,5]  R1764     0.0788489356637001
    z[5,2,5]  R1765     6.4517277479171753e-01
    z[5,2,5]  R1766     4.3082606792449951e-01
    z[5,2,5]  R1767     8.0412948131561279e-01
    z[5,2,5]  R1768     3.4908747673034668e-01
    z[5,2,5]  R1769     -1.3144983351230621e-01
    z[5,2,5]  R1770     2.1137522533535957e-02
    z[5,2,5]  R1771     2.9554679989814758e-01
    z[5,2,5]  R1772     2.6696437597274780e-01
    z[5,2,5]  R1773     -5.8818902820348740e-02
    z[5,2,5]  R1774     1.0087272524833679e-01
    z[5,2,5]  R1775     -4.9122326076030731e-02
    z[5,2,5]  R1776     -6.3139609992504120e-02
    z[5,2,5]  R1777     -0.00911277811974287
    z[5,2,5]  R1778     -3.5208237171173096e-01
    z[5,2,5]  R1779     -0.540863037109375
    z[5,2,5]  R1780     3.5498145222663879e-01
    z[5,2,5]  R1781     1.2205304205417633e-01
    z[5,2,5]  R1782     -5.9540885686874390e-01
    z[5,2,5]  R1783     1.9575688242912292e-01
    z[5,2,5]  R1784     5.3384047001600266e-02
    z[5,2,5]  R1785     -2.5146719813346863e-01
    z[5,2,5]  R1786     4.4127443432807922e-01
    z[5,2,5]  R1787     5.0499880313873291e-01
    z[5,2,5]  R1788     -1.5250724554061890e-01
    z[5,2,5]  R1789     -1.4797471463680267e-01
    z[5,2,5]  R1790     -3.1573437154293060e-02
    z[5,2,5]  R1791     2.4974641203880310e-01
    z[5,2,5]  R1792     -1.2833094596862793e-01
    z[5,2,5]  R1793     1.9335845112800598e-01
    z[5,2,5]  R1794     -1.1957912892103195e-01
    z[5,2,5]  R1795     1.0361205041408539e-01
    z[5,2,5]  R1796     9.6019506454467773e-03
    z[5,2,5]  R1797     3.0154320597648621e-01
    z[5,2,5]  R1798     7.7177612110972404e-03
    z[5,2,5]  R1799     1.1364541202783585e-01
    z[5,2,5]  R1800     2.3114676773548126e-01
    z[5,2,5]  R1801     2.4534982442855835e-01
    z[5,2,5]  R1802     2.8570652008056641e-01
    z[5,2,5]  R1803     -0.0637502521276474
    z[5,2,5]  R1804     9.4810724258422852e-02
    z[5,2,6]  R26       1
    z[5,2,6]  R53       -1
    z[5,2,6]  R1713     -1
    z[5,2,6]  R1714     1
    z[5,2,6]  R1715     3.0506783723831177e-01
    z[5,2,6]  R1716     -1.6707411408424377e-01
    z[5,2,6]  R1717     -1.4030157029628754e-01
    z[5,2,6]  R1718     -1.5614232420921326e-01
    z[5,2,6]  R1719     -6.9573158025741577e-01
    z[5,2,6]  R1720     3.9206331968307495e-01
    z[5,2,6]  R1721     -4.4810160994529724e-01
    z[5,2,6]  R1722     -1.3658446073532104e-01
    z[5,2,6]  R1723     6.9953277707099915e-03
    z[5,2,6]  R1724     -4.5238631963729858e-01
    z[5,2,6]  R1725     -1.8078187480568886e-02
    z[5,2,6]  R1726     3.6166332662105560e-02
    z[5,2,6]  R1727     -4.2214909195899963e-01
    z[5,2,6]  R1728     3.2443445920944214e-01
    z[5,2,6]  R1729     -1.1246681213378906e-02
    z[5,2,6]  R1730     0.0382811576128006
    z[5,2,6]  R1731     -2.4132886528968811e-01
    z[5,2,6]  R1732     -3.7785002589225769e-01
    z[5,2,6]  R1733     -1.8799139559268951e-01
    z[5,2,6]  R1734     -4.2002037167549133e-02
    z[5,2,6]  R1735     4.2526909708976746e-01
    z[5,2,6]  R1736     1.3504503667354584e-01
    z[5,2,6]  R1737     3.2356211543083191e-01
    z[5,2,6]  R1738     1.5062689781188965e-01
    z[5,2,6]  R1739     -1.1830971390008926e-01
    z[5,2,6]  R1740     5.9109228849411011e-01
    z[5,2,6]  R1741     6.6986465454101562e-01
    z[5,2,6]  R1742     -2.7612483501434326e-01
    z[5,2,6]  R1743     3.7648779153823853e-01
    z[5,2,6]  R1744     -4.1460883617401123e-01
    z[5,2,6]  R1745     -7.3883078992366791e-02
    z[5,2,6]  R1746     2.6690849661827087e-01
    z[5,2,6]  R1747     2.3986613750457764e-01
    z[5,2,6]  R1748     -0.35416179895401
    z[5,2,6]  R1749     6.2710128724575043e-02
    z[5,2,6]  R1750     -6.3965469598770142e-02
    z[5,2,6]  R1751     -1.5120127797126770e-01
    z[5,2,6]  R1752     1.5688399970531464e-01
    z[5,2,6]  R1753     8.8956616818904877e-03
    z[5,2,6]  R1754     8.6626596748828888e-02
    z[5,2,6]  R1755     -2.4196162819862366e-01
    z[5,2,6]  R1756     -3.4563142806291580e-02
    z[5,2,6]  R1757     2.7168050408363342e-01
    z[5,2,6]  R1758     1.4697673916816711e-01
    z[5,2,6]  R1759     6.4747321605682373e-01
    z[5,2,6]  R1760     6.5576941706240177e-03
    z[5,2,6]  R1761     5.0558692216873169e-01
    z[5,2,6]  R1762     2.6151040196418762e-01
    z[5,2,6]  R1763     1.1140928417444229e-01
    z[5,2,6]  R1764     -3.5501249134540558e-02
    z[5,2,6]  R1765     2.9407748952507973e-02
    z[5,2,6]  R1766     -1.0284823179244995e-01
    z[5,2,6]  R1767     -1.7685037106275558e-02
    z[5,2,6]  R1768     7.0338404178619385e-01
    z[5,2,6]  R1769     3.5287228226661682e-01
    z[5,2,6]  R1770     2.1951857209205627e-01
    z[5,2,6]  R1771     1.4428961277008057e-01
    z[5,2,6]  R1772     -2.0811758935451508e-01
    z[5,2,6]  R1773     -1.6104213893413544e-01
    z[5,2,6]  R1774     -3.0834999680519104e-01
    z[5,2,6]  R1775     -5.6209444999694824e-01
    z[5,2,6]  R1776     -3.5043638944625854e-01
    z[5,2,6]  R1777     1.9959436357021332e-01
    z[5,2,6]  R1778     7.5668044388294220e-02
    z[5,2,6]  R1779     -1.9348785281181335e-01
    z[5,2,6]  R1780     -1.3416618108749390e-02
    z[5,2,6]  R1781     1.4407142996788025e-01
    z[5,2,6]  R1782     -0.443516343832016
    z[5,2,6]  R1783     -2.7404433488845825e-01
    z[5,2,6]  R1784     -2.0178568363189697e-01
    z[5,2,6]  R1785     -9.5452917739748955e-03
    z[5,2,6]  R1786     -1.8258096277713776e-01
    z[5,2,6]  R1787     5.1814638078212738e-02
    z[5,2,6]  R1788     -1.8083012104034424e-01
    z[5,2,6]  R1789     2.2764241695404053e-01
    z[5,2,6]  R1790     1.0954919457435608e-01
    z[5,2,6]  R1791     3.7324190139770508e-02
    z[5,2,6]  R1792     6.9620959460735321e-02
    z[5,2,6]  R1793     -1.7409196496009827e-01
    z[5,2,6]  R1794     -2.9442825913429260e-01
    z[5,2,6]  R1795     -2.6521581411361694e-01
    z[5,2,6]  R1796     -2.2699010372161865e-01
    z[5,2,6]  R1797     2.6001834869384766e-01
    z[5,2,6]  R1798     5.5389977991580963e-02
    z[5,2,6]  R1799     -2.8567776083946228e-01
    z[5,2,6]  R1800     6.4749278128147125e-02
    z[5,2,6]  R1801     1.5751951932907104e-01
    z[5,2,6]  R1802     1.5132038295269012e-01
    z[5,2,6]  R1803     2.5233200192451477e-01
    z[5,2,6]  R1804     -0.035448107868433
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1805     -1
    z[2,6,0]  R1806     1
    z[2,6,0]  R1819     3.1432923674583435e-01
    z[2,6,0]  R1820     1.1821191757917404e-01
    z[2,6,0]  R1821     -4.2595438659191132e-02
    z[2,6,0]  R1822     -2.8032967820763588e-02
    z[2,6,0]  R1823     2.3776893317699432e-01
    z[2,6,0]  R1824     7.2030341625213623e-01
    z[2,6,0]  R1825     3.6836597323417664e-01
    z[2,6,0]  R1826     6.8994998931884766e-01
    z[2,6,0]  R1827     5.5068814754486084e-01
    z[2,6,0]  R1828     3.8371109962463379e-01
    z[2,6,0]  R1829     -5.1737666130065918e-01
    z[2,6,0]  R1830     5.7984985411167145e-02
    z[2,6,0]  R1831     -3.4597349166870117e-01
    z[2,6,0]  R1832     -6.9435632228851318e-01
    z[2,6,0]  R1833     -5.8090382814407349e-01
    z[2,6,0]  R1834     -7.2835075855255127e-01
    z[2,6,0]  R1835     -6.3251376152038574e-01
    z[2,6,0]  R1836     -0.282098650932312
    z[2,6,0]  R1837     -8.0061239004135132e-01
    z[2,6,0]  R1838     2.9811334609985352e-01
    z[2,6,0]  R1839     -0.727404773235321
    z[2,6,0]  R1840     -6.9134902954101562e-01
    z[2,6,0]  R1841     -3.8005176186561584e-01
    z[2,6,0]  R1842     2.9792213439941406e-01
    z[2,6,0]  R1843     2.5141090154647827e-01
    z[2,6,0]  R1844     4.8459729552268982e-01
    z[2,6,0]  R1845     2.2911366820335388e-01
    z[2,6,0]  R1846     2.8318625688552856e-01
    z[2,6,0]  R1847     1.4619770646095276e-01
    z[2,6,0]  R1848     5.0927591323852539e-01
    z[2,6,0]  R1849     -3.6842474341392517e-01
    z[2,6,0]  R1850     3.8788583874702454e-01
    z[2,6,0]  R1851     0.511343777179718
    z[2,6,0]  R1852     4.3528911471366882e-01
    z[2,6,0]  R1853     2.7572733163833618e-01
    z[2,6,0]  R1854     0.501968264579773
    z[2,6,0]  R1855     2.5607383251190186e-01
    z[2,6,0]  R1856     4.8280277848243713e-01
    z[2,6,0]  R1857     1.5415605902671814e-01
    z[2,6,0]  R1858     1.2871250510215759e-01
    z[2,6,0]  R1859     -1.3540515303611755e-01
    z[2,6,0]  R1860     -1.8146499991416931e-01
    z[2,6,0]  R1861     -1.1458253115415573e-01
    z[2,6,0]  R1862     2.4590075016021729e-01
    z[2,6,0]  R1863     -1.9872394204139709e-01
    z[2,6,0]  R1864     -3.5660693049430847e-01
    z[2,6,0]  R1865     1.5453067421913147e-01
    z[2,6,0]  R1866     2.2420710325241089e-01
    z[2,6,0]  R1867     1.5158204734325409e-01
    z[2,6,0]  R1868     2.6731389760971069e-01
    z[2,6,0]  R1869     -5.2680999040603638e-01
    z[2,6,0]  R1870     3.3764970302581787e-01
    z[2,6,0]  R1871     -1.2792757153511047e-01
    z[2,6,0]  R1872     1.6103994846343994e-01
    z[2,6,0]  R1873     5.2135378122329712e-01
    z[2,6,0]  R1874     5.9990906715393066e-01
    z[2,6,0]  R1875     3.3722755312919617e-01
    z[2,6,0]  R1876     1.8013438582420349e-01
    z[2,6,0]  R1877     -0.107862688601017
    z[2,6,0]  R1878     3.6219507455825806e-01
    z[2,6,0]  R1879     1.5011836588382721e-01
    z[2,6,0]  R1880     1.5852367877960205e-01
    z[2,6,0]  R1881     -6.0171049833297729e-01
    z[2,6,0]  R1882     5.0972029566764832e-03
    z[2,6,0]  R1883     -2.3490250110626221e-01
    z[2,6,0]  R1884     -0.58235764503479
    z[2,6,0]  R1885     -3.8865572214126587e-01
    z[2,6,0]  R1886     -6.6175174713134766e-01
    z[2,6,0]  R1887     1.3481132686138153e-01
    z[2,6,0]  R1888     3.1511485576629639e-02
    z[2,6,0]  R1889     -9.6586331725120544e-02
    z[2,6,0]  R1890     -2.2670675814151764e-01
    z[2,6,0]  R1891     3.0439281463623047e-01
    z[2,6,0]  R1892     -3.5883578658103943e-01
    z[2,6,0]  R1893     -3.6778151988983154e-01
    z[2,6,0]  R1894     1.4055030420422554e-02
    z[2,6,0]  R1895     -2.7112754061818123e-02
    z[2,6,0]  R1896     1.8437290191650391e-01
    z[2,6,0]  R1897     3.1333580613136292e-01
    z[2,6,0]  R1898     1.6550573706626892e-01
    z[2,6,0]  R1899     -2.2626711428165436e-01
    z[2,6,0]  R1900     -3.5421958565711975e-01
    z[2,6,0]  R1901     1.0648952424526215e-01
    z[2,6,0]  R1902     0.0934305191040039
    z[2,6,0]  R1903     -1.3700267672538757e-01
    z[2,6,0]  R1904     -2.2628770768642426e-01
    z[2,6,0]  R1905     0.297559529542923
    z[2,6,0]  R1906     1.7040875554084778e-01
    z[2,6,0]  R1907     0.509533703327179
    z[2,6,0]  R1908     0.547876238822937
    z[2,6,0]  R1909     -1.1656825244426727e-01
    z[2,6,0]  R1910     -2.2897545248270035e-02
    z[2,6,0]  R1911     0.0225005391985178
    z[2,6,0]  R1912     -2.7690127491950989e-01
    z[2,6,0]  R1913     2.2823049128055573e-01
    z[2,6,0]  R1914     2.1646852791309357e-01
    z[2,6,0]  R1915     6.0384386777877808e-01
    z[2,6,0]  R1916     0.574550986289978
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1807     -1
    z[2,6,1]  R1808     1
    z[2,6,1]  R1819     4.3151691555976868e-01
    z[2,6,1]  R1820     4.2549699544906616e-01
    z[2,6,1]  R1821     5.2562618255615234e-01
    z[2,6,1]  R1822     5.6732589006423950e-01
    z[2,6,1]  R1823     8.2880979776382446e-01
    z[2,6,1]  R1824     -6.1817508935928345e-01
    z[2,6,1]  R1825     -2.8042098879814148e-01
    z[2,6,1]  R1826     -3.8915368914604187e-01
    z[2,6,1]  R1827     -0.612704873085022
    z[2,6,1]  R1828     -3.9651420712471008e-01
    z[2,6,1]  R1829     4.7555673122406006e-01
    z[2,6,1]  R1830     0.518293559551239
    z[2,6,1]  R1831     2.9023453593254089e-01
    z[2,6,1]  R1832     3.4667372703552246e-01
    z[2,6,1]  R1833     3.2177156209945679e-01
    z[2,6,1]  R1834     -1.8335235118865967e-01
    z[2,6,1]  R1835     -7.5615622103214264e-02
    z[2,6,1]  R1836     2.2285100817680359e-01
    z[2,6,1]  R1837     -1.9160155951976776e-01
    z[2,6,1]  R1838     -7.9132926464080811e-01
    z[2,6,1]  R1839     5.5986744165420532e-01
    z[2,6,1]  R1840     2.4091683328151703e-01
    z[2,6,1]  R1841     -2.6302519440650940e-01
    z[2,6,1]  R1842     -8.7849563360214233e-01
    z[2,6,1]  R1843     -9.0676325559616089e-01
    z[2,6,1]  R1844     -0.81097811460495
    z[2,6,1]  R1845     -9.1801899671554565e-01
    z[2,6,1]  R1846     -8.8772386312484741e-01
    z[2,6,1]  R1847     -9.1601639986038208e-01
    z[2,6,1]  R1848     -7.4158489704132080e-01
    z[2,6,1]  R1849     4.2555916309356689e-01
    z[2,6,1]  R1850     -0.866968035697937
    z[2,6,1]  R1851     -6.5728002786636353e-01
    z[2,6,1]  R1852     -4.3178817629814148e-01
    z[2,6,1]  R1853     -4.6381074190139771e-01
    z[2,6,1]  R1854     -2.9665133357048035e-01
    z[2,6,1]  R1855     -4.6428361535072327e-01
    z[2,6,1]  R1856     -4.8970067501068115e-01
    z[2,6,1]  R1857     -5.3583443164825439e-01
    z[2,6,1]  R1858     -5.1682722568511963e-01
    z[2,6,1]  R1859     5.9156060218811035e-01
    z[2,6,1]  R1860     6.1252003908157349e-01
    z[2,6,1]  R1861     3.3040410280227661e-01
    z[2,6,1]  R1862     7.1475124359130859e-01
    z[2,6,1]  R1863     7.8449553251266479e-01
    z[2,6,1]  R1864     6.9461055099964142e-02
    z[2,6,1]  R1865     -6.2608772516250610e-01
    z[2,6,1]  R1866     0.651689350605011
    z[2,6,1]  R1867     -0.763340950012207
    z[2,6,1]  R1868     -6.0725015401840210e-01
    z[2,6,1]  R1869     2.6873454451560974e-01
    z[2,6,1]  R1870     2.9936638474464417e-01
    z[2,6,1]  R1871     5.9346508979797363e-01
    z[2,6,1]  R1872     -9.4619792699813843e-01
    z[2,6,1]  R1873     -0.740623414516449
    z[2,6,1]  R1874     -6.8825989961624146e-01
    z[2,6,1]  R1875     -7.1170818805694580e-01
    z[2,6,1]  R1876     -7.4227726459503174e-01
    z[2,6,1]  R1877     4.0774738788604736e-01
    z[2,6,1]  R1878     -7.3594230413436890e-01
    z[2,6,1]  R1879     5.5974102020263672e-01
    z[2,6,1]  R1880     5.8711689710617065e-01
    z[2,6,1]  R1881     3.8535785675048828e-01
    z[2,6,1]  R1882     -3.0366463586688042e-02
    z[2,6,1]  R1883     1.5404240787029266e-01
    z[2,6,1]  R1884     3.3650639653205872e-01
    z[2,6,1]  R1885     4.0871241688728333e-01
    z[2,6,1]  R1886     -1.7309428751468658e-01
    z[2,6,1]  R1887     2.8831285238265991e-01
    z[2,6,1]  R1888     6.1456203460693359e-02
    z[2,6,1]  R1889     0.931501567363739
    z[2,6,1]  R1890     0.725002110004425
    z[2,6,1]  R1891     3.9444544911384583e-01
    z[2,6,1]  R1892     -1.6152249276638031e-01
    z[2,6,1]  R1893     2.9948723316192627e-01
    z[2,6,1]  R1894     2.3306940495967865e-01
    z[2,6,1]  R1895     -1.8271915614604950e-01
    z[2,6,1]  R1896     -8.4464186429977417e-01
    z[2,6,1]  R1897     -7.6121377944946289e-01
    z[2,6,1]  R1898     -8.0869638919830322e-01
    z[2,6,1]  R1899     0.27131387591362
    z[2,6,1]  R1900     5.6756451725959778e-02
    z[2,6,1]  R1901     -1.9486691057682037e-01
    z[2,6,1]  R1902     -5.3097051382064819e-01
    z[2,6,1]  R1903     -3.6388668417930603e-01
    z[2,6,1]  R1904     -4.2843598127365112e-01
    z[2,6,1]  R1905     -0.859521210193634
    z[2,6,1]  R1906     -0.878296434879303
    z[2,6,1]  R1907     -6.5130203962326050e-01
    z[2,6,1]  R1908     -6.2969833612442017e-01
    z[2,6,1]  R1909     8.3298072218894958e-02
    z[2,6,1]  R1910     1.2004360556602478e-01
    z[2,6,1]  R1911     -4.1857150197029114e-01
    z[2,6,1]  R1912     -3.4635263681411743e-01
    z[2,6,1]  R1913     -9.4786942005157471e-01
    z[2,6,1]  R1914     -9.4751822948455811e-01
    z[2,6,1]  R1915     -1.6938674449920654e-01
    z[2,6,1]  R1916     -0.0797528326511383
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1809     -1
    z[2,6,2]  R1810     1
    z[2,6,2]  R1819     -1.4077208936214447e-01
    z[2,6,2]  R1820     9.7302317619323730e-02
    z[2,6,2]  R1821     -2.1837297081947327e-01
    z[2,6,2]  R1822     1.1307616531848907e-01
    z[2,6,2]  R1823     -1.9834028184413910e-01
    z[2,6,2]  R1824     -1.0964637994766235e-01
    z[2,6,2]  R1825     8.0503863096237183e-01
    z[2,6,2]  R1826     4.9628299474716187e-01
    z[2,6,2]  R1827     4.6857553720474243e-01
    z[2,6,2]  R1828     -0.295538067817688
    z[2,6,2]  R1829     -2.3308368399739265e-02
    z[2,6,2]  R1830     -4.4742828607559204e-01
    z[2,6,2]  R1831     -5.0015095621347427e-02
    z[2,6,2]  R1832     1.6715654730796814e-01
    z[2,6,2]  R1833     3.5724112391471863e-01
    z[2,6,2]  R1834     2.2476868331432343e-01
    z[2,6,2]  R1835     5.4395663738250732e-01
    z[2,6,2]  R1836     -1.1327151954174042e-01
    z[2,6,2]  R1837     0.394095242023468
    z[2,6,2]  R1838     -2.5027871131896973e-01
    z[2,6,2]  R1839     2.8507426381111145e-01
    z[2,6,2]  R1840     9.3729391694068909e-02
    z[2,6,2]  R1841     2.3452764749526978e-01
    z[2,6,2]  R1842     -6.1158183962106705e-02
    z[2,6,2]  R1843     1.6787745058536530e-01
    z[2,6,2]  R1844     -1.3995537161827087e-01
    z[2,6,2]  R1845     4.8986006528139114e-02
    z[2,6,2]  R1846     1.9130004942417145e-01
    z[2,6,2]  R1847     1.5195025503635406e-01
    z[2,6,2]  R1848     -2.1155475080013275e-01
    z[2,6,2]  R1849     -2.0650514960289001e-01
    z[2,6,2]  R1850     -3.3399043604731560e-03
    z[2,6,2]  R1851     8.1033043563365936e-02
    z[2,6,2]  R1852     6.9183951616287231e-01
    z[2,6,2]  R1853     6.9558727741241455e-01
    z[2,6,2]  R1854     0.603071391582489
    z[2,6,2]  R1855     0.738192081451416
    z[2,6,2]  R1856     4.5026838779449463e-01
    z[2,6,2]  R1857     6.5014606714248657e-01
    z[2,6,2]  R1858     0.777576744556427
    z[2,6,2]  R1859     -3.7073939893161878e-05
    z[2,6,2]  R1860     -9.4061434268951416e-02
    z[2,6,2]  R1861     -1.0151164606213570e-02
    z[2,6,2]  R1862     -3.6912170052528381e-01
    z[2,6,2]  R1863     -9.4815976917743683e-02
    z[2,6,2]  R1864     6.6864097118377686e-01
    z[2,6,2]  R1865     1.4853793382644653e-01
    z[2,6,2]  R1866     -2.0206044614315033e-01
    z[2,6,2]  R1867     5.1261745393276215e-02
    z[2,6,2]  R1868     5.7070064544677734e-01
    z[2,6,2]  R1869     1.9373928010463715e-01
    z[2,6,2]  R1870     -1.2308959662914276e-01
    z[2,6,2]  R1871     5.0703313201665878e-02
    z[2,6,2]  R1872     7.4863538146018982e-02
    z[2,6,2]  R1873     -2.7872905135154724e-01
    z[2,6,2]  R1874     -0.290794312953949
    z[2,6,2]  R1875     -8.2097806036472321e-02
    z[2,6,2]  R1876     1.1182001233100891e-01
    z[2,6,2]  R1877     1.9414447247982025e-01
    z[2,6,2]  R1878     -1.1578583717346191e-01
    z[2,6,2]  R1879     -3.4295099973678589e-01
    z[2,6,2]  R1880     -2.4560411274433136e-01
    z[2,6,2]  R1881     3.8912689685821533e-01
    z[2,6,2]  R1882     -1.2461658567190170e-01
    z[2,6,2]  R1883     3.0976501293480396e-03
    z[2,6,2]  R1884     4.9459049105644226e-01
    z[2,6,2]  R1885     1.7571765184402466e-01
    z[2,6,2]  R1886     4.7093614935874939e-01
    z[2,6,2]  R1887     -9.6561267971992493e-02
    z[2,6,2]  R1888     -2.7793669700622559e-01
    z[2,6,2]  R1889     -1.8980790674686432e-01
    z[2,6,2]  R1890     4.4485166668891907e-02
    z[2,6,2]  R1891     -4.0721407532691956e-01
    z[2,6,2]  R1892     1.6186350584030151e-01
    z[2,6,2]  R1893     4.1436710953712463e-01
    z[2,6,2]  R1894     -2.9058215022087097e-01
    z[2,6,2]  R1895     -1.3824518024921417e-01
    z[2,6,2]  R1896     -0.0147575493901968
    z[2,6,2]  R1897     -3.6450235638767481e-03
    z[2,6,2]  R1898     -1.9960529170930386e-03
    z[2,6,2]  R1899     -2.4927143007516861e-02
    z[2,6,2]  R1900     1.8710285425186157e-01
    z[2,6,2]  R1901     -2.4280165135860443e-01
    z[2,6,2]  R1902     -1.8334476277232170e-02
    z[2,6,2]  R1903     1.8672838807106018e-01
    z[2,6,2]  R1904     2.4049901962280273e-01
    z[2,6,2]  R1905     -8.7707303464412689e-02
    z[2,6,2]  R1906     1.1487445980310440e-01
    z[2,6,2]  R1907     -1.4127650856971741e-01
    z[2,6,2]  R1908     -1.9877615571022034e-01
    z[2,6,2]  R1909     -6.0105919837951660e-02
    z[2,6,2]  R1910     -0.25982666015625
    z[2,6,2]  R1911     0.0089586041867733
    z[2,6,2]  R1912     1.5497873723506927e-01
    z[2,6,2]  R1913     7.0586748421192169e-02
    z[2,6,2]  R1914     3.0409701168537140e-02
    z[2,6,2]  R1915     7.0663064718246460e-01
    z[2,6,2]  R1916     6.9450670480728149e-01
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1811     -1
    z[2,6,3]  R1812     1
    z[2,6,3]  R1819     1.5378223359584808e-01
    z[2,6,3]  R1820     -2.1045181900262833e-02
    z[2,6,3]  R1821     1.5678630769252777e-01
    z[2,6,3]  R1822     0.206902414560318
    z[2,6,3]  R1823     2.7443605661392212e-01
    z[2,6,3]  R1824     -1.2152399122714996e-01
    z[2,6,3]  R1825     1.6491317749023438e-01
    z[2,6,3]  R1826     -9.8055362701416016e-02
    z[2,6,3]  R1827     2.6900875568389893e-01
    z[2,6,3]  R1828     7.0876121520996094e-01
    z[2,6,3]  R1829     -4.3087130784988403e-01
    z[2,6,3]  R1830     -5.1461577415466309e-01
    z[2,6,3]  R1831     -6.5086215734481812e-01
    z[2,6,3]  R1832     1.0967974364757538e-01
    z[2,6,3]  R1833     2.5317004323005676e-01
    z[2,6,3]  R1834     -3.0487614870071411e-01
    z[2,6,3]  R1835     -4.6829420328140259e-01
    z[2,6,3]  R1836     4.8402658104896545e-01
    z[2,6,3]  R1837     2.2843122482299805e-01
    z[2,6,3]  R1838     2.0251031219959259e-01
    z[2,6,3]  R1839     -0.0773281380534172
    z[2,6,3]  R1840     0.431424617767334
    z[2,6,3]  R1841     -6.8704259395599365e-01
    z[2,6,3]  R1842     2.6176929473876953e-01
    z[2,6,3]  R1843     1.0777126997709274e-01
    z[2,6,3]  R1844     -1.5613524615764618e-01
    z[2,6,3]  R1845     -1.8808171153068542e-01
    z[2,6,3]  R1846     -2.1368660032749176e-01
    z[2,6,3]  R1847     -7.0396766066551208e-02
    z[2,6,3]  R1848     -2.1032449603080750e-01
    z[2,6,3]  R1849     6.5436446666717529e-01
    z[2,6,3]  R1850     -1.0747081041336060e-01
    z[2,6,3]  R1851     1.3733908534049988e-01
    z[2,6,3]  R1852     -2.0159746706485748e-01
    z[2,6,3]  R1853     5.9304811060428619e-02
    z[2,6,3]  R1854     -1.3849201798439026e-01
    z[2,6,3]  R1855     1.3117182254791260e-01
    z[2,6,3]  R1856     -1.4365708827972412e-01
    z[2,6,3]  R1857     -8.5474856197834015e-02
    z[2,6,3]  R1858     -3.2779112458229065e-02
    z[2,6,3]  R1859     1.8679147958755493e-01
    z[2,6,3]  R1860     -4.4278789311647415e-02
    z[2,6,3]  R1861     7.9929538071155548e-02
    z[2,6,3]  R1862     2.9882493615150452e-01
    z[2,6,3]  R1863     0.0489862896502018
    z[2,6,3]  R1864     -3.0913609080016613e-03
    z[2,6,3]  R1865     6.4784783124923706e-01
    z[2,6,3]  R1866     -5.0599642097949982e-02
    z[2,6,3]  R1867     7.8698612749576569e-02
    z[2,6,3]  R1868     1.6925598680973053e-01
    z[2,6,3]  R1869     -3.2823413610458374e-01
    z[2,6,3]  R1870     3.4984898567199707e-01
    z[2,6,3]  R1871     -3.0766350030899048e-01
    z[2,6,3]  R1872     4.0364719927310944e-02
    z[2,6,3]  R1873     -2.7162888646125793e-01
    z[2,6,3]  R1874     -1.4464857056736946e-02
    z[2,6,3]  R1875     8.4742859005928040e-02
    z[2,6,3]  R1876     -1.9598224759101868e-01
    z[2,6,3]  R1877     4.3875631690025330e-01
    z[2,6,3]  R1878     -1.6346287727355957e-01
    z[2,6,3]  R1879     -6.8979716300964355e-01
    z[2,6,3]  R1880     -3.6139088869094849e-01
    z[2,6,3]  R1881     -4.2000424861907959e-01
    z[2,6,3]  R1882     -6.9814813137054443e-01
    z[2,6,3]  R1883     -7.1037340164184570e-01
    z[2,6,3]  R1884     2.2700959444046021e-01
    z[2,6,3]  R1885     0.538135290145874
    z[2,6,3]  R1886     -2.0437745749950409e-01
    z[2,6,3]  R1887     8.8150733709335327e-01
    z[2,6,3]  R1888     -3.2526946067810059e-01
    z[2,6,3]  R1889     -1.4847362041473389e-01
    z[2,6,3]  R1890     5.6813931465148926e-01
    z[2,6,3]  R1891     -9.4906553626060486e-02
    z[2,6,3]  R1892     -6.2504941225051880e-01
    z[2,6,3]  R1893     2.7463027834892273e-01
    z[2,6,3]  R1894     -0.272591233253479
    z[2,6,3]  R1895     -7.9053580760955811e-01
    z[2,6,3]  R1896     -1.2500332295894623e-01
    z[2,6,3]  R1897     -2.5557151436805725e-01
    z[2,6,3]  R1898     -1.2475780397653580e-01
    z[2,6,3]  R1899     -3.4341163933277130e-02
    z[2,6,3]  R1900     -2.7871277928352356e-01
    z[2,6,3]  R1901     -8.3474278450012207e-01
    z[2,6,3]  R1902     -6.9614422321319580e-01
    z[2,6,3]  R1903     -6.7734891176223755e-01
    z[2,6,3]  R1904     -6.7219221591949463e-01
    z[2,6,3]  R1905     -3.2140710949897766e-01
    z[2,6,3]  R1906     -1.2192024849355221e-02
    z[2,6,3]  R1907     3.0854457616806030e-01
    z[2,6,3]  R1908     4.8076364398002625e-01
    z[2,6,3]  R1909     -9.0143275260925293e-01
    z[2,6,3]  R1910     -5.5771899223327637e-01
    z[2,6,3]  R1911     -8.2206577062606812e-01
    z[2,6,3]  R1912     -0.804474413394928
    z[2,6,3]  R1913     1.1394319683313370e-01
    z[2,6,3]  R1914     -1.3347879052162170e-01
    z[2,6,3]  R1915     2.9186752438545227e-01
    z[2,6,3]  R1916     3.9525943994522095e-01
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1813     -1
    z[2,6,4]  R1814     1
    z[2,6,4]  R1819     5.0439256429672241e-01
    z[2,6,4]  R1820     7.7387249469757080e-01
    z[2,6,4]  R1821     5.1933001726865768e-02
    z[2,6,4]  R1822     7.1761339902877808e-02
    z[2,6,4]  R1823     9.4068972393870354e-03
    z[2,6,4]  R1824     1.5361286699771881e-01
    z[2,6,4]  R1825     4.7112341970205307e-02
    z[2,6,4]  R1826     4.5098189264535904e-02
    z[2,6,4]  R1827     -3.5120092798024416e-03
    z[2,6,4]  R1828     -2.4536836892366409e-02
    z[2,6,4]  R1829     -4.0133681148290634e-02
    z[2,6,4]  R1830     -3.6904710531234741e-01
    z[2,6,4]  R1831     -5.7447558641433716e-01
    z[2,6,4]  R1832     -4.7752285003662109e-01
    z[2,6,4]  R1833     0.193202406167984
    z[2,6,4]  R1834     -4.0770679712295532e-01
    z[2,6,4]  R1835     2.0824690163135529e-01
    z[2,6,4]  R1836     -2.6912295818328857e-01
    z[2,6,4]  R1837     0.0373593270778656
    z[2,6,4]  R1838     -3.7109193205833435e-01
    z[2,6,4]  R1839     -8.2805931568145752e-02
    z[2,6,4]  R1840     -2.0254465937614441e-01
    z[2,6,4]  R1841     -4.0486253798007965e-02
    z[2,6,4]  R1842     -1.0614348202943802e-01
    z[2,6,4]  R1843     -3.2525051385164261e-02
    z[2,6,4]  R1844     -2.2475828230381012e-01
    z[2,6,4]  R1845     -5.6633982807397842e-02
    z[2,6,4]  R1846     1.6786442697048187e-01
    z[2,6,4]  R1847     2.0928440988063812e-01
    z[2,6,4]  R1848     -2.6660870760679245e-02
    z[2,6,4]  R1849     -3.6228525638580322e-01
    z[2,6,4]  R1850     1.8636827170848846e-01
    z[2,6,4]  R1851     3.5006308555603027e-01
    z[2,6,4]  R1852     -3.1885942816734314e-01
    z[2,6,4]  R1853     -3.5632592439651489e-01
    z[2,6,4]  R1854     -4.6853971481323242e-01
    z[2,6,4]  R1855     -2.6781409978866577e-01
    z[2,6,4]  R1856     -4.4630682468414307e-01
    z[2,6,4]  R1857     -4.3747693300247192e-01
    z[2,6,4]  R1858     -3.1682330369949341e-01
    z[2,6,4]  R1859     3.4189215302467346e-01
    z[2,6,4]  R1860     -1.3627833127975464e-01
    z[2,6,4]  R1861     -0.111341193318367
    z[2,6,4]  R1862     4.4122478365898132e-01
    z[2,6,4]  R1863     -4.4462826102972031e-02
    z[2,6,4]  R1864     4.0168440341949463e-01
    z[2,6,4]  R1865     2.2923342883586884e-01
    z[2,6,4]  R1866     -4.7273480892181396e-01
    z[2,6,4]  R1867     5.8079534769058228e-01
    z[2,6,4]  R1868     2.5078555941581726e-01
    z[2,6,4]  R1869     6.5549755096435547e-01
    z[2,6,4]  R1870     -5.1414966583251953e-01
    z[2,6,4]  R1871     -5.3345358371734619e-01
    z[2,6,4]  R1872     -1.3015829026699066e-01
    z[2,6,4]  R1873     -8.5632158443331718e-03
    z[2,6,4]  R1874     -2.7972236275672913e-01
    z[2,6,4]  R1875     3.5864907503128052e-01
    z[2,6,4]  R1876     -4.1146072745323181e-01
    z[2,6,4]  R1877     -3.7646195292472839e-01
    z[2,6,4]  R1878     -7.9846596345305443e-03
    z[2,6,4]  R1879     1.5329687297344208e-01
    z[2,6,4]  R1880     -6.2212800979614258e-01
    z[2,6,4]  R1881     5.5183735676109791e-03
    z[2,6,4]  R1882     -2.9356116056442261e-01
    z[2,6,4]  R1883     -4.8711401224136353e-01
    z[2,6,4]  R1884     -1.0112939774990082e-01
    z[2,6,4]  R1885     3.0689540505409241e-01
    z[2,6,4]  R1886     -9.3758301809430122e-03
    z[2,6,4]  R1887     2.0063920319080353e-01
    z[2,6,4]  R1888     5.8596688508987427e-01
    z[2,6,4]  R1889     2.3003134131431580e-01
    z[2,6,4]  R1890     -6.3085383735597134e-03
    z[2,6,4]  R1891     2.6756027340888977e-01
    z[2,6,4]  R1892     5.7051169872283936e-01
    z[2,6,4]  R1893     -3.7801295518875122e-01
    z[2,6,4]  R1894     2.4625961482524872e-01
    z[2,6,4]  R1895     -1.7379105091094971e-01
    z[2,6,4]  R1896     2.6957783102989197e-01
    z[2,6,4]  R1897     -0.25974240899086
    z[2,6,4]  R1898     5.2982503175735474e-01
    z[2,6,4]  R1899     5.3899204730987549e-01
    z[2,6,4]  R1900     8.0369651317596436e-01
    z[2,6,4]  R1901     6.0987651348114014e-02
    z[2,6,4]  R1902     4.5826774090528488e-02
    z[2,6,4]  R1903     -5.1132738590240479e-01
    z[2,6,4]  R1904     -2.9330241680145264e-01
    z[2,6,4]  R1905     1.3294976949691772e-01
    z[2,6,4]  R1906     2.1586577594280243e-01
    z[2,6,4]  R1907     2.0460948348045349e-01
    z[2,6,4]  R1908     7.9268246889114380e-02
    z[2,6,4]  R1909     -3.7390011548995972e-01
    z[2,6,4]  R1910     1.3041408360004425e-01
    z[2,6,4]  R1911     5.6369446218013763e-02
    z[2,6,4]  R1912     -2.6048952341079712e-01
    z[2,6,4]  R1913     1.4222750067710876e-01
    z[2,6,4]  R1914     -5.8729931712150574e-02
    z[2,6,4]  R1915     -1.0785602778196335e-01
    z[2,6,4]  R1916     -6.0210663825273514e-02
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1815     -1
    z[2,6,5]  R1816     1
    z[2,6,5]  R1819     6.4517277479171753e-01
    z[2,6,5]  R1820     4.3082606792449951e-01
    z[2,6,5]  R1821     8.0412948131561279e-01
    z[2,6,5]  R1822     3.4908747673034668e-01
    z[2,6,5]  R1823     -1.3144983351230621e-01
    z[2,6,5]  R1824     2.1137522533535957e-02
    z[2,6,5]  R1825     2.9554679989814758e-01
    z[2,6,5]  R1826     2.6696437597274780e-01
    z[2,6,5]  R1827     -5.8818902820348740e-02
    z[2,6,5]  R1828     1.0087272524833679e-01
    z[2,6,5]  R1829     -4.9122326076030731e-02
    z[2,6,5]  R1830     -6.3139609992504120e-02
    z[2,6,5]  R1831     -0.00911277811974287
    z[2,6,5]  R1832     -3.5208237171173096e-01
    z[2,6,5]  R1833     -0.540863037109375
    z[2,6,5]  R1834     3.5498145222663879e-01
    z[2,6,5]  R1835     1.2205304205417633e-01
    z[2,6,5]  R1836     -5.9540885686874390e-01
    z[2,6,5]  R1837     1.9575688242912292e-01
    z[2,6,5]  R1838     5.3384047001600266e-02
    z[2,6,5]  R1839     -2.5146719813346863e-01
    z[2,6,5]  R1840     4.4127443432807922e-01
    z[2,6,5]  R1841     5.0499880313873291e-01
    z[2,6,5]  R1842     -1.5250724554061890e-01
    z[2,6,5]  R1843     -1.4797471463680267e-01
    z[2,6,5]  R1844     -3.1573437154293060e-02
    z[2,6,5]  R1845     2.4974641203880310e-01
    z[2,6,5]  R1846     -1.2833094596862793e-01
    z[2,6,5]  R1847     1.9335845112800598e-01
    z[2,6,5]  R1848     -1.1957912892103195e-01
    z[2,6,5]  R1849     1.0361205041408539e-01
    z[2,6,5]  R1850     9.6019506454467773e-03
    z[2,6,5]  R1851     3.0154320597648621e-01
    z[2,6,5]  R1852     7.7177612110972404e-03
    z[2,6,5]  R1853     1.1364541202783585e-01
    z[2,6,5]  R1854     2.3114676773548126e-01
    z[2,6,5]  R1855     2.4534982442855835e-01
    z[2,6,5]  R1856     2.8570652008056641e-01
    z[2,6,5]  R1857     -0.0637502521276474
    z[2,6,5]  R1858     9.4810724258422852e-02
    z[2,6,5]  R1859     0.528590977191925
    z[2,6,5]  R1860     7.1026724576950073e-01
    z[2,6,5]  R1861     9.1388291120529175e-01
    z[2,6,5]  R1862     -2.9233081266283989e-02
    z[2,6,5]  R1863     -1.8909063935279846e-01
    z[2,6,5]  R1864     4.2841640114784241e-01
    z[2,6,5]  R1865     1.3852208852767944e-01
    z[2,6,5]  R1866     -2.5052863359451294e-01
    z[2,6,5]  R1867     -2.0143085718154907e-01
    z[2,6,5]  R1868     2.2526636719703674e-01
    z[2,6,5]  R1869     -4.2061571031808853e-02
    z[2,6,5]  R1870     -2.2896220907568932e-02
    z[2,6,5]  R1871     -2.8610411286354065e-01
    z[2,6,5]  R1872     1.5323950350284576e-01
    z[2,6,5]  R1873     -1.5778636932373047e-01
    z[2,6,5]  R1874     -4.3013781309127808e-02
    z[2,6,5]  R1875     3.2962355017662048e-01
    z[2,6,5]  R1876     4.1474539786577225e-02
    z[2,6,5]  R1877     -6.0724008083343506e-01
    z[2,6,5]  R1878     4.2287012934684753e-01
    z[2,6,5]  R1879     -5.1012925803661346e-02
    z[2,6,5]  R1880     1.2685698270797729e-01
    z[2,6,5]  R1881     -1.9729802012443542e-01
    z[2,6,5]  R1882     6.3614523410797119e-01
    z[2,6,5]  R1883     3.1838470697402954e-01
    z[2,6,5]  R1884     -4.6052387356758118e-01
    z[2,6,5]  R1885     1.6816663742065430e-01
    z[2,6,5]  R1886     5.0231683254241943e-01
    z[2,6,5]  R1887     1.0454358160495758e-01
    z[2,6,5]  R1888     0.260141521692276
    z[2,6,5]  R1889     9.3274883925914764e-02
    z[2,6,5]  R1890     1.6127622127532959e-01
    z[2,6,5]  R1891     6.9633203744888306e-01
    z[2,6,5]  R1892     2.9558527469635010e-01
    z[2,6,5]  R1893     -1.0555070638656616e-01
    z[2,6,5]  R1894     1.5233403444290161e-01
    z[2,6,5]  R1895     -5.9906851500272751e-02
    z[2,6,5]  R1896     -0.296150267124176
    z[2,6,5]  R1897     -1.8459224700927734e-01
    z[2,6,5]  R1898     -1.4714795351028442e-01
    z[2,6,5]  R1899     7.5066995620727539e-01
    z[2,6,5]  R1900     1.3029675185680389e-01
    z[2,6,5]  R1901     -1.4577963948249817e-01
    z[2,6,5]  R1902     -4.6445944905281067e-01
    z[2,6,5]  R1903     -1.0121800005435944e-01
    z[2,6,5]  R1904     -4.0525132417678833e-01
    z[2,6,5]  R1905     1.6238564252853394e-01
    z[2,6,5]  R1906     -2.9147368669509888e-01
    z[2,6,5]  R1907     -1.3680888712406158e-01
    z[2,6,5]  R1908     -1.6233567893505096e-01
    z[2,6,5]  R1909     1.5122829377651215e-01
    z[2,6,5]  R1910     4.0020561218261719e-01
    z[2,6,5]  R1911     -1.0169178247451782e-01
    z[2,6,5]  R1912     -6.7678354680538177e-02
    z[2,6,5]  R1913     -2.8892930597066879e-02
    z[2,6,5]  R1914     -1.4586250483989716e-01
    z[2,6,5]  R1915     -7.0206761360168457e-02
    z[2,6,5]  R1916     1.4605778455734253e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1817     -1
    z[2,6,6]  R1818     1
    z[2,6,6]  R1819     2.9407748952507973e-02
    z[2,6,6]  R1820     -1.0284823179244995e-01
    z[2,6,6]  R1821     -1.7685037106275558e-02
    z[2,6,6]  R1822     7.0338404178619385e-01
    z[2,6,6]  R1823     3.5287228226661682e-01
    z[2,6,6]  R1824     2.1951857209205627e-01
    z[2,6,6]  R1825     1.4428961277008057e-01
    z[2,6,6]  R1826     -2.0811758935451508e-01
    z[2,6,6]  R1827     -1.6104213893413544e-01
    z[2,6,6]  R1828     -3.0834999680519104e-01
    z[2,6,6]  R1829     -5.6209444999694824e-01
    z[2,6,6]  R1830     -3.5043638944625854e-01
    z[2,6,6]  R1831     1.9959436357021332e-01
    z[2,6,6]  R1832     7.5668044388294220e-02
    z[2,6,6]  R1833     -1.9348785281181335e-01
    z[2,6,6]  R1834     -1.3416618108749390e-02
    z[2,6,6]  R1835     1.4407142996788025e-01
    z[2,6,6]  R1836     -0.443516343832016
    z[2,6,6]  R1837     -2.7404433488845825e-01
    z[2,6,6]  R1838     -2.0178568363189697e-01
    z[2,6,6]  R1839     -9.5452917739748955e-03
    z[2,6,6]  R1840     -1.8258096277713776e-01
    z[2,6,6]  R1841     5.1814638078212738e-02
    z[2,6,6]  R1842     -1.8083012104034424e-01
    z[2,6,6]  R1843     2.2764241695404053e-01
    z[2,6,6]  R1844     1.0954919457435608e-01
    z[2,6,6]  R1845     3.7324190139770508e-02
    z[2,6,6]  R1846     6.9620959460735321e-02
    z[2,6,6]  R1847     -1.7409196496009827e-01
    z[2,6,6]  R1848     -2.9442825913429260e-01
    z[2,6,6]  R1849     -2.6521581411361694e-01
    z[2,6,6]  R1850     -2.2699010372161865e-01
    z[2,6,6]  R1851     2.6001834869384766e-01
    z[2,6,6]  R1852     5.5389977991580963e-02
    z[2,6,6]  R1853     -2.8567776083946228e-01
    z[2,6,6]  R1854     6.4749278128147125e-02
    z[2,6,6]  R1855     1.5751951932907104e-01
    z[2,6,6]  R1856     1.5132038295269012e-01
    z[2,6,6]  R1857     2.5233200192451477e-01
    z[2,6,6]  R1858     -0.035448107868433
    z[2,6,6]  R1859     4.4780775904655457e-01
    z[2,6,6]  R1860     -2.4089443683624268e-01
    z[2,6,6]  R1861     1.5373152494430542e-01
    z[2,6,6]  R1862     -0.0870768278837204
    z[2,6,6]  R1863     -5.4401624202728271e-01
    z[2,6,6]  R1864     -2.7572691440582275e-01
    z[2,6,6]  R1865     2.6575896143913269e-01
    z[2,6,6]  R1866     4.4204148650169373e-01
    z[2,6,6]  R1867     8.7261833250522614e-02
    z[2,6,6]  R1868     -3.0299395322799683e-01
    z[2,6,6]  R1869     -2.7117198705673218e-01
    z[2,6,6]  R1870     6.2765669822692871e-01
    z[2,6,6]  R1871     4.0960687398910522e-01
    z[2,6,6]  R1872     -1.7640371620655060e-01
    z[2,6,6]  R1873     -0.0567912831902504
    z[2,6,6]  R1874     -3.9269987493753433e-02
    z[2,6,6]  R1875     3.5853415727615356e-01
    z[2,6,6]  R1876     4.4118392467498779e-01
    z[2,6,6]  R1877     2.8538459539413452e-01
    z[2,6,6]  R1878     3.2892918586730957e-01
    z[2,6,6]  R1879     2.1122667193412781e-01
    z[2,6,6]  R1880     1.9000871479511261e-01
    z[2,6,6]  R1881     3.5023361444473267e-01
    z[2,6,6]  R1882     7.2476804256439209e-02
    z[2,6,6]  R1883     -2.7893170714378357e-01
    z[2,6,6]  R1884     1.7076477408409119e-01
    z[2,6,6]  R1885     -4.8884540796279907e-01
    z[2,6,6]  R1886     -1.2712916731834412e-01
    z[2,6,6]  R1887     -2.4725881218910217e-01
    z[2,6,6]  R1888     -6.3336426019668579e-01
    z[2,6,6]  R1889     5.7357203215360641e-02
    z[2,6,6]  R1890     -0.268635094165802
    z[2,6,6]  R1891     1.4303991198539734e-01
    z[2,6,6]  R1892     1.2412270158529282e-01
    z[2,6,6]  R1893     6.1146342754364014e-01
    z[2,6,6]  R1894     -8.3838403224945068e-01
    z[2,6,6]  R1895     -5.3668224811553955e-01
    z[2,6,6]  R1896     -2.7634406089782715e-01
    z[2,6,6]  R1897     3.9433974027633667e-01
    z[2,6,6]  R1898     -2.6123058050870895e-02
    z[2,6,6]  R1899     -1.3918830454349518e-01
    z[2,6,6]  R1900     3.0937612056732178e-01
    z[2,6,6]  R1901     -4.1227099299430847e-01
    z[2,6,6]  R1902     8.1027291715145111e-02
    z[2,6,6]  R1903     2.8887173533439636e-01
    z[2,6,6]  R1904     7.2796165943145752e-02
    z[2,6,6]  R1905     1.3282217085361481e-01
    z[2,6,6]  R1906     0.233786940574646
    z[2,6,6]  R1907     3.7475389242172241e-01
    z[2,6,6]  R1908     -5.4427143186330795e-03
    z[2,6,6]  R1909     -2.4663519114255905e-02
    z[2,6,6]  R1910     -6.5523463487625122e-01
    z[2,6,6]  R1911     3.6728808283805847e-01
    z[2,6,6]  R1912     -2.4440322816371918e-01
    z[2,6,6]  R1913     1.0210485011339188e-01
    z[2,6,6]  R1914     -1.0901399701833725e-01
    z[2,6,6]  R1915     -7.4868492782115936e-02
    z[2,6,6]  R1916     1.6749604837968946e-03
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1917     -1
    z[6,2,0]  R1918     1
    z[6,2,0]  R1931     -1.3540515303611755e-01
    z[6,2,0]  R1932     -1.8146499991416931e-01
    z[6,2,0]  R1933     -1.1458253115415573e-01
    z[6,2,0]  R1934     2.4590075016021729e-01
    z[6,2,0]  R1935     -1.9872394204139709e-01
    z[6,2,0]  R1936     -3.5660693049430847e-01
    z[6,2,0]  R1937     1.5453067421913147e-01
    z[6,2,0]  R1938     2.2420710325241089e-01
    z[6,2,0]  R1939     1.5158204734325409e-01
    z[6,2,0]  R1940     2.6731389760971069e-01
    z[6,2,0]  R1941     -5.2680999040603638e-01
    z[6,2,0]  R1942     3.3764970302581787e-01
    z[6,2,0]  R1943     -1.2792757153511047e-01
    z[6,2,0]  R1944     1.6103994846343994e-01
    z[6,2,0]  R1945     5.2135378122329712e-01
    z[6,2,0]  R1946     5.9990906715393066e-01
    z[6,2,0]  R1947     3.3722755312919617e-01
    z[6,2,0]  R1948     1.8013438582420349e-01
    z[6,2,0]  R1949     -0.107862688601017
    z[6,2,0]  R1950     3.6219507455825806e-01
    z[6,2,0]  R1951     1.5011836588382721e-01
    z[6,2,0]  R1952     1.5852367877960205e-01
    z[6,2,0]  R1953     -6.0171049833297729e-01
    z[6,2,0]  R1954     5.0972029566764832e-03
    z[6,2,0]  R1955     -2.3490250110626221e-01
    z[6,2,0]  R1956     -0.58235764503479
    z[6,2,0]  R1957     -3.8865572214126587e-01
    z[6,2,0]  R1958     -6.6175174713134766e-01
    z[6,2,0]  R1959     1.3481132686138153e-01
    z[6,2,0]  R1960     3.1511485576629639e-02
    z[6,2,0]  R1961     -9.6586331725120544e-02
    z[6,2,0]  R1962     -2.2670675814151764e-01
    z[6,2,0]  R1963     3.0439281463623047e-01
    z[6,2,0]  R1964     -3.5883578658103943e-01
    z[6,2,0]  R1965     -3.6778151988983154e-01
    z[6,2,0]  R1966     1.4055030420422554e-02
    z[6,2,0]  R1967     -2.7112754061818123e-02
    z[6,2,0]  R1968     1.8437290191650391e-01
    z[6,2,0]  R1969     3.1333580613136292e-01
    z[6,2,0]  R1970     1.6550573706626892e-01
    z[6,2,0]  R1971     -2.2626711428165436e-01
    z[6,2,0]  R1972     -3.5421958565711975e-01
    z[6,2,0]  R1973     1.0648952424526215e-01
    z[6,2,0]  R1974     0.0934305191040039
    z[6,2,0]  R1975     -1.3700267672538757e-01
    z[6,2,0]  R1976     -2.2628770768642426e-01
    z[6,2,0]  R1977     0.297559529542923
    z[6,2,0]  R1978     1.7040875554084778e-01
    z[6,2,0]  R1979     0.509533703327179
    z[6,2,0]  R1980     0.547876238822937
    z[6,2,0]  R1981     -1.1656825244426727e-01
    z[6,2,0]  R1982     -2.2897545248270035e-02
    z[6,2,0]  R1983     0.0225005391985178
    z[6,2,0]  R1984     -2.7690127491950989e-01
    z[6,2,0]  R1985     2.2823049128055573e-01
    z[6,2,0]  R1986     2.1646852791309357e-01
    z[6,2,0]  R1987     6.0384386777877808e-01
    z[6,2,0]  R1988     0.574550986289978
    z[6,2,0]  R1989     3.1432923674583435e-01
    z[6,2,0]  R1990     1.1821191757917404e-01
    z[6,2,0]  R1991     -4.2595438659191132e-02
    z[6,2,0]  R1992     -2.8032967820763588e-02
    z[6,2,0]  R1993     2.3776893317699432e-01
    z[6,2,0]  R1994     7.2030341625213623e-01
    z[6,2,0]  R1995     3.6836597323417664e-01
    z[6,2,0]  R1996     6.8994998931884766e-01
    z[6,2,0]  R1997     5.5068814754486084e-01
    z[6,2,0]  R1998     3.8371109962463379e-01
    z[6,2,0]  R1999     -5.1737666130065918e-01
    z[6,2,0]  R2000     5.7984985411167145e-02
    z[6,2,0]  R2001     -3.4597349166870117e-01
    z[6,2,0]  R2002     -6.9435632228851318e-01
    z[6,2,0]  R2003     -5.8090382814407349e-01
    z[6,2,0]  R2004     -7.2835075855255127e-01
    z[6,2,0]  R2005     -6.3251376152038574e-01
    z[6,2,0]  R2006     -0.282098650932312
    z[6,2,0]  R2007     -8.0061239004135132e-01
    z[6,2,0]  R2008     2.9811334609985352e-01
    z[6,2,0]  R2009     -0.727404773235321
    z[6,2,0]  R2010     -6.9134902954101562e-01
    z[6,2,0]  R2011     -3.8005176186561584e-01
    z[6,2,0]  R2012     2.9792213439941406e-01
    z[6,2,0]  R2013     2.5141090154647827e-01
    z[6,2,0]  R2014     4.8459729552268982e-01
    z[6,2,0]  R2015     2.2911366820335388e-01
    z[6,2,0]  R2016     2.8318625688552856e-01
    z[6,2,0]  R2017     1.4619770646095276e-01
    z[6,2,0]  R2018     5.0927591323852539e-01
    z[6,2,0]  R2019     -3.6842474341392517e-01
    z[6,2,0]  R2020     3.8788583874702454e-01
    z[6,2,0]  R2021     0.511343777179718
    z[6,2,0]  R2022     4.3528911471366882e-01
    z[6,2,0]  R2023     2.7572733163833618e-01
    z[6,2,0]  R2024     0.501968264579773
    z[6,2,0]  R2025     2.5607383251190186e-01
    z[6,2,0]  R2026     4.8280277848243713e-01
    z[6,2,0]  R2027     1.5415605902671814e-01
    z[6,2,0]  R2028     1.2871250510215759e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1919     -1
    z[6,2,1]  R1920     1
    z[6,2,1]  R1931     5.9156060218811035e-01
    z[6,2,1]  R1932     6.1252003908157349e-01
    z[6,2,1]  R1933     3.3040410280227661e-01
    z[6,2,1]  R1934     7.1475124359130859e-01
    z[6,2,1]  R1935     7.8449553251266479e-01
    z[6,2,1]  R1936     6.9461055099964142e-02
    z[6,2,1]  R1937     -6.2608772516250610e-01
    z[6,2,1]  R1938     0.651689350605011
    z[6,2,1]  R1939     -0.763340950012207
    z[6,2,1]  R1940     -6.0725015401840210e-01
    z[6,2,1]  R1941     2.6873454451560974e-01
    z[6,2,1]  R1942     2.9936638474464417e-01
    z[6,2,1]  R1943     5.9346508979797363e-01
    z[6,2,1]  R1944     -9.4619792699813843e-01
    z[6,2,1]  R1945     -0.740623414516449
    z[6,2,1]  R1946     -6.8825989961624146e-01
    z[6,2,1]  R1947     -7.1170818805694580e-01
    z[6,2,1]  R1948     -7.4227726459503174e-01
    z[6,2,1]  R1949     4.0774738788604736e-01
    z[6,2,1]  R1950     -7.3594230413436890e-01
    z[6,2,1]  R1951     5.5974102020263672e-01
    z[6,2,1]  R1952     5.8711689710617065e-01
    z[6,2,1]  R1953     3.8535785675048828e-01
    z[6,2,1]  R1954     -3.0366463586688042e-02
    z[6,2,1]  R1955     1.5404240787029266e-01
    z[6,2,1]  R1956     3.3650639653205872e-01
    z[6,2,1]  R1957     4.0871241688728333e-01
    z[6,2,1]  R1958     -1.7309428751468658e-01
    z[6,2,1]  R1959     2.8831285238265991e-01
    z[6,2,1]  R1960     6.1456203460693359e-02
    z[6,2,1]  R1961     0.931501567363739
    z[6,2,1]  R1962     0.725002110004425
    z[6,2,1]  R1963     3.9444544911384583e-01
    z[6,2,1]  R1964     -1.6152249276638031e-01
    z[6,2,1]  R1965     2.9948723316192627e-01
    z[6,2,1]  R1966     2.3306940495967865e-01
    z[6,2,1]  R1967     -1.8271915614604950e-01
    z[6,2,1]  R1968     -8.4464186429977417e-01
    z[6,2,1]  R1969     -7.6121377944946289e-01
    z[6,2,1]  R1970     -8.0869638919830322e-01
    z[6,2,1]  R1971     0.27131387591362
    z[6,2,1]  R1972     5.6756451725959778e-02
    z[6,2,1]  R1973     -1.9486691057682037e-01
    z[6,2,1]  R1974     -5.3097051382064819e-01
    z[6,2,1]  R1975     -3.6388668417930603e-01
    z[6,2,1]  R1976     -4.2843598127365112e-01
    z[6,2,1]  R1977     -0.859521210193634
    z[6,2,1]  R1978     -0.878296434879303
    z[6,2,1]  R1979     -6.5130203962326050e-01
    z[6,2,1]  R1980     -6.2969833612442017e-01
    z[6,2,1]  R1981     8.3298072218894958e-02
    z[6,2,1]  R1982     1.2004360556602478e-01
    z[6,2,1]  R1983     -4.1857150197029114e-01
    z[6,2,1]  R1984     -3.4635263681411743e-01
    z[6,2,1]  R1985     -9.4786942005157471e-01
    z[6,2,1]  R1986     -9.4751822948455811e-01
    z[6,2,1]  R1987     -1.6938674449920654e-01
    z[6,2,1]  R1988     -0.0797528326511383
    z[6,2,1]  R1989     4.3151691555976868e-01
    z[6,2,1]  R1990     4.2549699544906616e-01
    z[6,2,1]  R1991     5.2562618255615234e-01
    z[6,2,1]  R1992     5.6732589006423950e-01
    z[6,2,1]  R1993     8.2880979776382446e-01
    z[6,2,1]  R1994     -6.1817508935928345e-01
    z[6,2,1]  R1995     -2.8042098879814148e-01
    z[6,2,1]  R1996     -3.8915368914604187e-01
    z[6,2,1]  R1997     -0.612704873085022
    z[6,2,1]  R1998     -3.9651420712471008e-01
    z[6,2,1]  R1999     4.7555673122406006e-01
    z[6,2,1]  R2000     0.518293559551239
    z[6,2,1]  R2001     2.9023453593254089e-01
    z[6,2,1]  R2002     3.4667372703552246e-01
    z[6,2,1]  R2003     3.2177156209945679e-01
    z[6,2,1]  R2004     -1.8335235118865967e-01
    z[6,2,1]  R2005     -7.5615622103214264e-02
    z[6,2,1]  R2006     2.2285100817680359e-01
    z[6,2,1]  R2007     -1.9160155951976776e-01
    z[6,2,1]  R2008     -7.9132926464080811e-01
    z[6,2,1]  R2009     5.5986744165420532e-01
    z[6,2,1]  R2010     2.4091683328151703e-01
    z[6,2,1]  R2011     -2.6302519440650940e-01
    z[6,2,1]  R2012     -8.7849563360214233e-01
    z[6,2,1]  R2013     -9.0676325559616089e-01
    z[6,2,1]  R2014     -0.81097811460495
    z[6,2,1]  R2015     -9.1801899671554565e-01
    z[6,2,1]  R2016     -8.8772386312484741e-01
    z[6,2,1]  R2017     -9.1601639986038208e-01
    z[6,2,1]  R2018     -7.4158489704132080e-01
    z[6,2,1]  R2019     4.2555916309356689e-01
    z[6,2,1]  R2020     -0.866968035697937
    z[6,2,1]  R2021     -6.5728002786636353e-01
    z[6,2,1]  R2022     -4.3178817629814148e-01
    z[6,2,1]  R2023     -4.6381074190139771e-01
    z[6,2,1]  R2024     -2.9665133357048035e-01
    z[6,2,1]  R2025     -4.6428361535072327e-01
    z[6,2,1]  R2026     -4.8970067501068115e-01
    z[6,2,1]  R2027     -5.3583443164825439e-01
    z[6,2,1]  R2028     -5.1682722568511963e-01
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1921     -1
    z[6,2,2]  R1922     1
    z[6,2,2]  R1931     -3.7073939893161878e-05
    z[6,2,2]  R1932     -9.4061434268951416e-02
    z[6,2,2]  R1933     -1.0151164606213570e-02
    z[6,2,2]  R1934     -3.6912170052528381e-01
    z[6,2,2]  R1935     -9.4815976917743683e-02
    z[6,2,2]  R1936     6.6864097118377686e-01
    z[6,2,2]  R1937     1.4853793382644653e-01
    z[6,2,2]  R1938     -2.0206044614315033e-01
    z[6,2,2]  R1939     5.1261745393276215e-02
    z[6,2,2]  R1940     5.7070064544677734e-01
    z[6,2,2]  R1941     1.9373928010463715e-01
    z[6,2,2]  R1942     -1.2308959662914276e-01
    z[6,2,2]  R1943     5.0703313201665878e-02
    z[6,2,2]  R1944     7.4863538146018982e-02
    z[6,2,2]  R1945     -2.7872905135154724e-01
    z[6,2,2]  R1946     -0.290794312953949
    z[6,2,2]  R1947     -8.2097806036472321e-02
    z[6,2,2]  R1948     1.1182001233100891e-01
    z[6,2,2]  R1949     1.9414447247982025e-01
    z[6,2,2]  R1950     -1.1578583717346191e-01
    z[6,2,2]  R1951     -3.4295099973678589e-01
    z[6,2,2]  R1952     -2.4560411274433136e-01
    z[6,2,2]  R1953     3.8912689685821533e-01
    z[6,2,2]  R1954     -1.2461658567190170e-01
    z[6,2,2]  R1955     3.0976501293480396e-03
    z[6,2,2]  R1956     4.9459049105644226e-01
    z[6,2,2]  R1957     1.7571765184402466e-01
    z[6,2,2]  R1958     4.7093614935874939e-01
    z[6,2,2]  R1959     -9.6561267971992493e-02
    z[6,2,2]  R1960     -2.7793669700622559e-01
    z[6,2,2]  R1961     -1.8980790674686432e-01
    z[6,2,2]  R1962     4.4485166668891907e-02
    z[6,2,2]  R1963     -4.0721407532691956e-01
    z[6,2,2]  R1964     1.6186350584030151e-01
    z[6,2,2]  R1965     4.1436710953712463e-01
    z[6,2,2]  R1966     -2.9058215022087097e-01
    z[6,2,2]  R1967     -1.3824518024921417e-01
    z[6,2,2]  R1968     -0.0147575493901968
    z[6,2,2]  R1969     -3.6450235638767481e-03
    z[6,2,2]  R1970     -1.9960529170930386e-03
    z[6,2,2]  R1971     -2.4927143007516861e-02
    z[6,2,2]  R1972     1.8710285425186157e-01
    z[6,2,2]  R1973     -2.4280165135860443e-01
    z[6,2,2]  R1974     -1.8334476277232170e-02
    z[6,2,2]  R1975     1.8672838807106018e-01
    z[6,2,2]  R1976     2.4049901962280273e-01
    z[6,2,2]  R1977     -8.7707303464412689e-02
    z[6,2,2]  R1978     1.1487445980310440e-01
    z[6,2,2]  R1979     -1.4127650856971741e-01
    z[6,2,2]  R1980     -1.9877615571022034e-01
    z[6,2,2]  R1981     -6.0105919837951660e-02
    z[6,2,2]  R1982     -0.25982666015625
    z[6,2,2]  R1983     0.0089586041867733
    z[6,2,2]  R1984     1.5497873723506927e-01
    z[6,2,2]  R1985     7.0586748421192169e-02
    z[6,2,2]  R1986     3.0409701168537140e-02
    z[6,2,2]  R1987     7.0663064718246460e-01
    z[6,2,2]  R1988     6.9450670480728149e-01
    z[6,2,2]  R1989     -1.4077208936214447e-01
    z[6,2,2]  R1990     9.7302317619323730e-02
    z[6,2,2]  R1991     -2.1837297081947327e-01
    z[6,2,2]  R1992     1.1307616531848907e-01
    z[6,2,2]  R1993     -1.9834028184413910e-01
    z[6,2,2]  R1994     -1.0964637994766235e-01
    z[6,2,2]  R1995     8.0503863096237183e-01
    z[6,2,2]  R1996     4.9628299474716187e-01
    z[6,2,2]  R1997     4.6857553720474243e-01
    z[6,2,2]  R1998     -0.295538067817688
    z[6,2,2]  R1999     -2.3308368399739265e-02
    z[6,2,2]  R2000     -4.4742828607559204e-01
    z[6,2,2]  R2001     -5.0015095621347427e-02
    z[6,2,2]  R2002     1.6715654730796814e-01
    z[6,2,2]  R2003     3.5724112391471863e-01
    z[6,2,2]  R2004     2.2476868331432343e-01
    z[6,2,2]  R2005     5.4395663738250732e-01
    z[6,2,2]  R2006     -1.1327151954174042e-01
    z[6,2,2]  R2007     0.394095242023468
    z[6,2,2]  R2008     -2.5027871131896973e-01
    z[6,2,2]  R2009     2.8507426381111145e-01
    z[6,2,2]  R2010     9.3729391694068909e-02
    z[6,2,2]  R2011     2.3452764749526978e-01
    z[6,2,2]  R2012     -6.1158183962106705e-02
    z[6,2,2]  R2013     1.6787745058536530e-01
    z[6,2,2]  R2014     -1.3995537161827087e-01
    z[6,2,2]  R2015     4.8986006528139114e-02
    z[6,2,2]  R2016     1.9130004942417145e-01
    z[6,2,2]  R2017     1.5195025503635406e-01
    z[6,2,2]  R2018     -2.1155475080013275e-01
    z[6,2,2]  R2019     -2.0650514960289001e-01
    z[6,2,2]  R2020     -3.3399043604731560e-03
    z[6,2,2]  R2021     8.1033043563365936e-02
    z[6,2,2]  R2022     6.9183951616287231e-01
    z[6,2,2]  R2023     6.9558727741241455e-01
    z[6,2,2]  R2024     0.603071391582489
    z[6,2,2]  R2025     0.738192081451416
    z[6,2,2]  R2026     4.5026838779449463e-01
    z[6,2,2]  R2027     6.5014606714248657e-01
    z[6,2,2]  R2028     0.777576744556427
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1923     -1
    z[6,2,3]  R1924     1
    z[6,2,3]  R1931     1.8679147958755493e-01
    z[6,2,3]  R1932     -4.4278789311647415e-02
    z[6,2,3]  R1933     7.9929538071155548e-02
    z[6,2,3]  R1934     2.9882493615150452e-01
    z[6,2,3]  R1935     0.0489862896502018
    z[6,2,3]  R1936     -3.0913609080016613e-03
    z[6,2,3]  R1937     6.4784783124923706e-01
    z[6,2,3]  R1938     -5.0599642097949982e-02
    z[6,2,3]  R1939     7.8698612749576569e-02
    z[6,2,3]  R1940     1.6925598680973053e-01
    z[6,2,3]  R1941     -3.2823413610458374e-01
    z[6,2,3]  R1942     3.4984898567199707e-01
    z[6,2,3]  R1943     -3.0766350030899048e-01
    z[6,2,3]  R1944     4.0364719927310944e-02
    z[6,2,3]  R1945     -2.7162888646125793e-01
    z[6,2,3]  R1946     -1.4464857056736946e-02
    z[6,2,3]  R1947     8.4742859005928040e-02
    z[6,2,3]  R1948     -1.9598224759101868e-01
    z[6,2,3]  R1949     4.3875631690025330e-01
    z[6,2,3]  R1950     -1.6346287727355957e-01
    z[6,2,3]  R1951     -6.8979716300964355e-01
    z[6,2,3]  R1952     -3.6139088869094849e-01
    z[6,2,3]  R1953     -4.2000424861907959e-01
    z[6,2,3]  R1954     -6.9814813137054443e-01
    z[6,2,3]  R1955     -7.1037340164184570e-01
    z[6,2,3]  R1956     2.2700959444046021e-01
    z[6,2,3]  R1957     0.538135290145874
    z[6,2,3]  R1958     -2.0437745749950409e-01
    z[6,2,3]  R1959     8.8150733709335327e-01
    z[6,2,3]  R1960     -3.2526946067810059e-01
    z[6,2,3]  R1961     -1.4847362041473389e-01
    z[6,2,3]  R1962     5.6813931465148926e-01
    z[6,2,3]  R1963     -9.4906553626060486e-02
    z[6,2,3]  R1964     -6.2504941225051880e-01
    z[6,2,3]  R1965     2.7463027834892273e-01
    z[6,2,3]  R1966     -0.272591233253479
    z[6,2,3]  R1967     -7.9053580760955811e-01
    z[6,2,3]  R1968     -1.2500332295894623e-01
    z[6,2,3]  R1969     -2.5557151436805725e-01
    z[6,2,3]  R1970     -1.2475780397653580e-01
    z[6,2,3]  R1971     -3.4341163933277130e-02
    z[6,2,3]  R1972     -2.7871277928352356e-01
    z[6,2,3]  R1973     -8.3474278450012207e-01
    z[6,2,3]  R1974     -6.9614422321319580e-01
    z[6,2,3]  R1975     -6.7734891176223755e-01
    z[6,2,3]  R1976     -6.7219221591949463e-01
    z[6,2,3]  R1977     -3.2140710949897766e-01
    z[6,2,3]  R1978     -1.2192024849355221e-02
    z[6,2,3]  R1979     3.0854457616806030e-01
    z[6,2,3]  R1980     4.8076364398002625e-01
    z[6,2,3]  R1981     -9.0143275260925293e-01
    z[6,2,3]  R1982     -5.5771899223327637e-01
    z[6,2,3]  R1983     -8.2206577062606812e-01
    z[6,2,3]  R1984     -0.804474413394928
    z[6,2,3]  R1985     1.1394319683313370e-01
    z[6,2,3]  R1986     -1.3347879052162170e-01
    z[6,2,3]  R1987     2.9186752438545227e-01
    z[6,2,3]  R1988     3.9525943994522095e-01
    z[6,2,3]  R1989     1.5378223359584808e-01
    z[6,2,3]  R1990     -2.1045181900262833e-02
    z[6,2,3]  R1991     1.5678630769252777e-01
    z[6,2,3]  R1992     0.206902414560318
    z[6,2,3]  R1993     2.7443605661392212e-01
    z[6,2,3]  R1994     -1.2152399122714996e-01
    z[6,2,3]  R1995     1.6491317749023438e-01
    z[6,2,3]  R1996     -9.8055362701416016e-02
    z[6,2,3]  R1997     2.6900875568389893e-01
    z[6,2,3]  R1998     7.0876121520996094e-01
    z[6,2,3]  R1999     -4.3087130784988403e-01
    z[6,2,3]  R2000     -5.1461577415466309e-01
    z[6,2,3]  R2001     -6.5086215734481812e-01
    z[6,2,3]  R2002     1.0967974364757538e-01
    z[6,2,3]  R2003     2.5317004323005676e-01
    z[6,2,3]  R2004     -3.0487614870071411e-01
    z[6,2,3]  R2005     -4.6829420328140259e-01
    z[6,2,3]  R2006     4.8402658104896545e-01
    z[6,2,3]  R2007     2.2843122482299805e-01
    z[6,2,3]  R2008     2.0251031219959259e-01
    z[6,2,3]  R2009     -0.0773281380534172
    z[6,2,3]  R2010     0.431424617767334
    z[6,2,3]  R2011     -6.8704259395599365e-01
    z[6,2,3]  R2012     2.6176929473876953e-01
    z[6,2,3]  R2013     1.0777126997709274e-01
    z[6,2,3]  R2014     -1.5613524615764618e-01
    z[6,2,3]  R2015     -1.8808171153068542e-01
    z[6,2,3]  R2016     -2.1368660032749176e-01
    z[6,2,3]  R2017     -7.0396766066551208e-02
    z[6,2,3]  R2018     -2.1032449603080750e-01
    z[6,2,3]  R2019     6.5436446666717529e-01
    z[6,2,3]  R2020     -1.0747081041336060e-01
    z[6,2,3]  R2021     1.3733908534049988e-01
    z[6,2,3]  R2022     -2.0159746706485748e-01
    z[6,2,3]  R2023     5.9304811060428619e-02
    z[6,2,3]  R2024     -1.3849201798439026e-01
    z[6,2,3]  R2025     1.3117182254791260e-01
    z[6,2,3]  R2026     -1.4365708827972412e-01
    z[6,2,3]  R2027     -8.5474856197834015e-02
    z[6,2,3]  R2028     -3.2779112458229065e-02
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1925     -1
    z[6,2,4]  R1926     1
    z[6,2,4]  R1931     3.4189215302467346e-01
    z[6,2,4]  R1932     -1.3627833127975464e-01
    z[6,2,4]  R1933     -0.111341193318367
    z[6,2,4]  R1934     4.4122478365898132e-01
    z[6,2,4]  R1935     -4.4462826102972031e-02
    z[6,2,4]  R1936     4.0168440341949463e-01
    z[6,2,4]  R1937     2.2923342883586884e-01
    z[6,2,4]  R1938     -4.7273480892181396e-01
    z[6,2,4]  R1939     5.8079534769058228e-01
    z[6,2,4]  R1940     2.5078555941581726e-01
    z[6,2,4]  R1941     6.5549755096435547e-01
    z[6,2,4]  R1942     -5.1414966583251953e-01
    z[6,2,4]  R1943     -5.3345358371734619e-01
    z[6,2,4]  R1944     -1.3015829026699066e-01
    z[6,2,4]  R1945     -8.5632158443331718e-03
    z[6,2,4]  R1946     -2.7972236275672913e-01
    z[6,2,4]  R1947     3.5864907503128052e-01
    z[6,2,4]  R1948     -4.1146072745323181e-01
    z[6,2,4]  R1949     -3.7646195292472839e-01
    z[6,2,4]  R1950     -7.9846596345305443e-03
    z[6,2,4]  R1951     1.5329687297344208e-01
    z[6,2,4]  R1952     -6.2212800979614258e-01
    z[6,2,4]  R1953     5.5183735676109791e-03
    z[6,2,4]  R1954     -2.9356116056442261e-01
    z[6,2,4]  R1955     -4.8711401224136353e-01
    z[6,2,4]  R1956     -1.0112939774990082e-01
    z[6,2,4]  R1957     3.0689540505409241e-01
    z[6,2,4]  R1958     -9.3758301809430122e-03
    z[6,2,4]  R1959     2.0063920319080353e-01
    z[6,2,4]  R1960     5.8596688508987427e-01
    z[6,2,4]  R1961     2.3003134131431580e-01
    z[6,2,4]  R1962     -6.3085383735597134e-03
    z[6,2,4]  R1963     2.6756027340888977e-01
    z[6,2,4]  R1964     5.7051169872283936e-01
    z[6,2,4]  R1965     -3.7801295518875122e-01
    z[6,2,4]  R1966     2.4625961482524872e-01
    z[6,2,4]  R1967     -1.7379105091094971e-01
    z[6,2,4]  R1968     2.6957783102989197e-01
    z[6,2,4]  R1969     -0.25974240899086
    z[6,2,4]  R1970     5.2982503175735474e-01
    z[6,2,4]  R1971     5.3899204730987549e-01
    z[6,2,4]  R1972     8.0369651317596436e-01
    z[6,2,4]  R1973     6.0987651348114014e-02
    z[6,2,4]  R1974     4.5826774090528488e-02
    z[6,2,4]  R1975     -5.1132738590240479e-01
    z[6,2,4]  R1976     -2.9330241680145264e-01
    z[6,2,4]  R1977     1.3294976949691772e-01
    z[6,2,4]  R1978     2.1586577594280243e-01
    z[6,2,4]  R1979     2.0460948348045349e-01
    z[6,2,4]  R1980     7.9268246889114380e-02
    z[6,2,4]  R1981     -3.7390011548995972e-01
    z[6,2,4]  R1982     1.3041408360004425e-01
    z[6,2,4]  R1983     5.6369446218013763e-02
    z[6,2,4]  R1984     -2.6048952341079712e-01
    z[6,2,4]  R1985     1.4222750067710876e-01
    z[6,2,4]  R1986     -5.8729931712150574e-02
    z[6,2,4]  R1987     -1.0785602778196335e-01
    z[6,2,4]  R1988     -6.0210663825273514e-02
    z[6,2,4]  R1989     5.0439256429672241e-01
    z[6,2,4]  R1990     7.7387249469757080e-01
    z[6,2,4]  R1991     5.1933001726865768e-02
    z[6,2,4]  R1992     7.1761339902877808e-02
    z[6,2,4]  R1993     9.4068972393870354e-03
    z[6,2,4]  R1994     1.5361286699771881e-01
    z[6,2,4]  R1995     4.7112341970205307e-02
    z[6,2,4]  R1996     4.5098189264535904e-02
    z[6,2,4]  R1997     -3.5120092798024416e-03
    z[6,2,4]  R1998     -2.4536836892366409e-02
    z[6,2,4]  R1999     -4.0133681148290634e-02
    z[6,2,4]  R2000     -3.6904710531234741e-01
    z[6,2,4]  R2001     -5.7447558641433716e-01
    z[6,2,4]  R2002     -4.7752285003662109e-01
    z[6,2,4]  R2003     0.193202406167984
    z[6,2,4]  R2004     -4.0770679712295532e-01
    z[6,2,4]  R2005     2.0824690163135529e-01
    z[6,2,4]  R2006     -2.6912295818328857e-01
    z[6,2,4]  R2007     0.0373593270778656
    z[6,2,4]  R2008     -3.7109193205833435e-01
    z[6,2,4]  R2009     -8.2805931568145752e-02
    z[6,2,4]  R2010     -2.0254465937614441e-01
    z[6,2,4]  R2011     -4.0486253798007965e-02
    z[6,2,4]  R2012     -1.0614348202943802e-01
    z[6,2,4]  R2013     -3.2525051385164261e-02
    z[6,2,4]  R2014     -2.2475828230381012e-01
    z[6,2,4]  R2015     -5.6633982807397842e-02
    z[6,2,4]  R2016     1.6786442697048187e-01
    z[6,2,4]  R2017     2.0928440988063812e-01
    z[6,2,4]  R2018     -2.6660870760679245e-02
    z[6,2,4]  R2019     -3.6228525638580322e-01
    z[6,2,4]  R2020     1.8636827170848846e-01
    z[6,2,4]  R2021     3.5006308555603027e-01
    z[6,2,4]  R2022     -3.1885942816734314e-01
    z[6,2,4]  R2023     -3.5632592439651489e-01
    z[6,2,4]  R2024     -4.6853971481323242e-01
    z[6,2,4]  R2025     -2.6781409978866577e-01
    z[6,2,4]  R2026     -4.4630682468414307e-01
    z[6,2,4]  R2027     -4.3747693300247192e-01
    z[6,2,4]  R2028     -3.1682330369949341e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1927     -1
    z[6,2,5]  R1928     1
    z[6,2,5]  R1931     0.528590977191925
    z[6,2,5]  R1932     7.1026724576950073e-01
    z[6,2,5]  R1933     9.1388291120529175e-01
    z[6,2,5]  R1934     -2.9233081266283989e-02
    z[6,2,5]  R1935     -1.8909063935279846e-01
    z[6,2,5]  R1936     4.2841640114784241e-01
    z[6,2,5]  R1937     1.3852208852767944e-01
    z[6,2,5]  R1938     -2.5052863359451294e-01
    z[6,2,5]  R1939     -2.0143085718154907e-01
    z[6,2,5]  R1940     2.2526636719703674e-01
    z[6,2,5]  R1941     -4.2061571031808853e-02
    z[6,2,5]  R1942     -2.2896220907568932e-02
    z[6,2,5]  R1943     -2.8610411286354065e-01
    z[6,2,5]  R1944     1.5323950350284576e-01
    z[6,2,5]  R1945     -1.5778636932373047e-01
    z[6,2,5]  R1946     -4.3013781309127808e-02
    z[6,2,5]  R1947     3.2962355017662048e-01
    z[6,2,5]  R1948     4.1474539786577225e-02
    z[6,2,5]  R1949     -6.0724008083343506e-01
    z[6,2,5]  R1950     4.2287012934684753e-01
    z[6,2,5]  R1951     -5.1012925803661346e-02
    z[6,2,5]  R1952     1.2685698270797729e-01
    z[6,2,5]  R1953     -1.9729802012443542e-01
    z[6,2,5]  R1954     6.3614523410797119e-01
    z[6,2,5]  R1955     3.1838470697402954e-01
    z[6,2,5]  R1956     -4.6052387356758118e-01
    z[6,2,5]  R1957     1.6816663742065430e-01
    z[6,2,5]  R1958     5.0231683254241943e-01
    z[6,2,5]  R1959     1.0454358160495758e-01
    z[6,2,5]  R1960     0.260141521692276
    z[6,2,5]  R1961     9.3274883925914764e-02
    z[6,2,5]  R1962     1.6127622127532959e-01
    z[6,2,5]  R1963     6.9633203744888306e-01
    z[6,2,5]  R1964     2.9558527469635010e-01
    z[6,2,5]  R1965     -1.0555070638656616e-01
    z[6,2,5]  R1966     1.5233403444290161e-01
    z[6,2,5]  R1967     -5.9906851500272751e-02
    z[6,2,5]  R1968     -0.296150267124176
    z[6,2,5]  R1969     -1.8459224700927734e-01
    z[6,2,5]  R1970     -1.4714795351028442e-01
    z[6,2,5]  R1971     7.5066995620727539e-01
    z[6,2,5]  R1972     1.3029675185680389e-01
    z[6,2,5]  R1973     -1.4577963948249817e-01
    z[6,2,5]  R1974     -4.6445944905281067e-01
    z[6,2,5]  R1975     -1.0121800005435944e-01
    z[6,2,5]  R1976     -4.0525132417678833e-01
    z[6,2,5]  R1977     1.6238564252853394e-01
    z[6,2,5]  R1978     -2.9147368669509888e-01
    z[6,2,5]  R1979     -1.3680888712406158e-01
    z[6,2,5]  R1980     -1.6233567893505096e-01
    z[6,2,5]  R1981     1.5122829377651215e-01
    z[6,2,5]  R1982     4.0020561218261719e-01
    z[6,2,5]  R1983     -1.0169178247451782e-01
    z[6,2,5]  R1984     -6.7678354680538177e-02
    z[6,2,5]  R1985     -2.8892930597066879e-02
    z[6,2,5]  R1986     -1.4586250483989716e-01
    z[6,2,5]  R1987     -7.0206761360168457e-02
    z[6,2,5]  R1988     1.4605778455734253e-01
    z[6,2,5]  R1989     6.4517277479171753e-01
    z[6,2,5]  R1990     4.3082606792449951e-01
    z[6,2,5]  R1991     8.0412948131561279e-01
    z[6,2,5]  R1992     3.4908747673034668e-01
    z[6,2,5]  R1993     -1.3144983351230621e-01
    z[6,2,5]  R1994     2.1137522533535957e-02
    z[6,2,5]  R1995     2.9554679989814758e-01
    z[6,2,5]  R1996     2.6696437597274780e-01
    z[6,2,5]  R1997     -5.8818902820348740e-02
    z[6,2,5]  R1998     1.0087272524833679e-01
    z[6,2,5]  R1999     -4.9122326076030731e-02
    z[6,2,5]  R2000     -6.3139609992504120e-02
    z[6,2,5]  R2001     -0.00911277811974287
    z[6,2,5]  R2002     -3.5208237171173096e-01
    z[6,2,5]  R2003     -0.540863037109375
    z[6,2,5]  R2004     3.5498145222663879e-01
    z[6,2,5]  R2005     1.2205304205417633e-01
    z[6,2,5]  R2006     -5.9540885686874390e-01
    z[6,2,5]  R2007     1.9575688242912292e-01
    z[6,2,5]  R2008     5.3384047001600266e-02
    z[6,2,5]  R2009     -2.5146719813346863e-01
    z[6,2,5]  R2010     4.4127443432807922e-01
    z[6,2,5]  R2011     5.0499880313873291e-01
    z[6,2,5]  R2012     -1.5250724554061890e-01
    z[6,2,5]  R2013     -1.4797471463680267e-01
    z[6,2,5]  R2014     -3.1573437154293060e-02
    z[6,2,5]  R2015     2.4974641203880310e-01
    z[6,2,5]  R2016     -1.2833094596862793e-01
    z[6,2,5]  R2017     1.9335845112800598e-01
    z[6,2,5]  R2018     -1.1957912892103195e-01
    z[6,2,5]  R2019     1.0361205041408539e-01
    z[6,2,5]  R2020     9.6019506454467773e-03
    z[6,2,5]  R2021     3.0154320597648621e-01
    z[6,2,5]  R2022     7.7177612110972404e-03
    z[6,2,5]  R2023     1.1364541202783585e-01
    z[6,2,5]  R2024     2.3114676773548126e-01
    z[6,2,5]  R2025     2.4534982442855835e-01
    z[6,2,5]  R2026     2.8570652008056641e-01
    z[6,2,5]  R2027     -0.0637502521276474
    z[6,2,5]  R2028     9.4810724258422852e-02
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1929     -1
    z[6,2,6]  R1930     1
    z[6,2,6]  R1931     4.4780775904655457e-01
    z[6,2,6]  R1932     -2.4089443683624268e-01
    z[6,2,6]  R1933     1.5373152494430542e-01
    z[6,2,6]  R1934     -0.0870768278837204
    z[6,2,6]  R1935     -5.4401624202728271e-01
    z[6,2,6]  R1936     -2.7572691440582275e-01
    z[6,2,6]  R1937     2.6575896143913269e-01
    z[6,2,6]  R1938     4.4204148650169373e-01
    z[6,2,6]  R1939     8.7261833250522614e-02
    z[6,2,6]  R1940     -3.0299395322799683e-01
    z[6,2,6]  R1941     -2.7117198705673218e-01
    z[6,2,6]  R1942     6.2765669822692871e-01
    z[6,2,6]  R1943     4.0960687398910522e-01
    z[6,2,6]  R1944     -1.7640371620655060e-01
    z[6,2,6]  R1945     -0.0567912831902504
    z[6,2,6]  R1946     -3.9269987493753433e-02
    z[6,2,6]  R1947     3.5853415727615356e-01
    z[6,2,6]  R1948     4.4118392467498779e-01
    z[6,2,6]  R1949     2.8538459539413452e-01
    z[6,2,6]  R1950     3.2892918586730957e-01
    z[6,2,6]  R1951     2.1122667193412781e-01
    z[6,2,6]  R1952     1.9000871479511261e-01
    z[6,2,6]  R1953     3.5023361444473267e-01
    z[6,2,6]  R1954     7.2476804256439209e-02
    z[6,2,6]  R1955     -2.7893170714378357e-01
    z[6,2,6]  R1956     1.7076477408409119e-01
    z[6,2,6]  R1957     -4.8884540796279907e-01
    z[6,2,6]  R1958     -1.2712916731834412e-01
    z[6,2,6]  R1959     -2.4725881218910217e-01
    z[6,2,6]  R1960     -6.3336426019668579e-01
    z[6,2,6]  R1961     5.7357203215360641e-02
    z[6,2,6]  R1962     -0.268635094165802
    z[6,2,6]  R1963     1.4303991198539734e-01
    z[6,2,6]  R1964     1.2412270158529282e-01
    z[6,2,6]  R1965     6.1146342754364014e-01
    z[6,2,6]  R1966     -8.3838403224945068e-01
    z[6,2,6]  R1967     -5.3668224811553955e-01
    z[6,2,6]  R1968     -2.7634406089782715e-01
    z[6,2,6]  R1969     3.9433974027633667e-01
    z[6,2,6]  R1970     -2.6123058050870895e-02
    z[6,2,6]  R1971     -1.3918830454349518e-01
    z[6,2,6]  R1972     3.0937612056732178e-01
    z[6,2,6]  R1973     -4.1227099299430847e-01
    z[6,2,6]  R1974     8.1027291715145111e-02
    z[6,2,6]  R1975     2.8887173533439636e-01
    z[6,2,6]  R1976     7.2796165943145752e-02
    z[6,2,6]  R1977     1.3282217085361481e-01
    z[6,2,6]  R1978     0.233786940574646
    z[6,2,6]  R1979     3.7475389242172241e-01
    z[6,2,6]  R1980     -5.4427143186330795e-03
    z[6,2,6]  R1981     -2.4663519114255905e-02
    z[6,2,6]  R1982     -6.5523463487625122e-01
    z[6,2,6]  R1983     3.6728808283805847e-01
    z[6,2,6]  R1984     -2.4440322816371918e-01
    z[6,2,6]  R1985     1.0210485011339188e-01
    z[6,2,6]  R1986     -1.0901399701833725e-01
    z[6,2,6]  R1987     -7.4868492782115936e-02
    z[6,2,6]  R1988     1.6749604837968946e-03
    z[6,2,6]  R1989     2.9407748952507973e-02
    z[6,2,6]  R1990     -1.0284823179244995e-01
    z[6,2,6]  R1991     -1.7685037106275558e-02
    z[6,2,6]  R1992     7.0338404178619385e-01
    z[6,2,6]  R1993     3.5287228226661682e-01
    z[6,2,6]  R1994     2.1951857209205627e-01
    z[6,2,6]  R1995     1.4428961277008057e-01
    z[6,2,6]  R1996     -2.0811758935451508e-01
    z[6,2,6]  R1997     -1.6104213893413544e-01
    z[6,2,6]  R1998     -3.0834999680519104e-01
    z[6,2,6]  R1999     -5.6209444999694824e-01
    z[6,2,6]  R2000     -3.5043638944625854e-01
    z[6,2,6]  R2001     1.9959436357021332e-01
    z[6,2,6]  R2002     7.5668044388294220e-02
    z[6,2,6]  R2003     -1.9348785281181335e-01
    z[6,2,6]  R2004     -1.3416618108749390e-02
    z[6,2,6]  R2005     1.4407142996788025e-01
    z[6,2,6]  R2006     -0.443516343832016
    z[6,2,6]  R2007     -2.7404433488845825e-01
    z[6,2,6]  R2008     -2.0178568363189697e-01
    z[6,2,6]  R2009     -9.5452917739748955e-03
    z[6,2,6]  R2010     -1.8258096277713776e-01
    z[6,2,6]  R2011     5.1814638078212738e-02
    z[6,2,6]  R2012     -1.8083012104034424e-01
    z[6,2,6]  R2013     2.2764241695404053e-01
    z[6,2,6]  R2014     1.0954919457435608e-01
    z[6,2,6]  R2015     3.7324190139770508e-02
    z[6,2,6]  R2016     6.9620959460735321e-02
    z[6,2,6]  R2017     -1.7409196496009827e-01
    z[6,2,6]  R2018     -2.9442825913429260e-01
    z[6,2,6]  R2019     -2.6521581411361694e-01
    z[6,2,6]  R2020     -2.2699010372161865e-01
    z[6,2,6]  R2021     2.6001834869384766e-01
    z[6,2,6]  R2022     5.5389977991580963e-02
    z[6,2,6]  R2023     -2.8567776083946228e-01
    z[6,2,6]  R2024     6.4749278128147125e-02
    z[6,2,6]  R2025     1.5751951932907104e-01
    z[6,2,6]  R2026     1.5132038295269012e-01
    z[6,2,6]  R2027     2.5233200192451477e-01
    z[6,2,6]  R2028     -0.035448107868433
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R2083     -1
    z[3,4,0]  R2084     1
    z[3,4,0]  R2097     1.8530371785163879e-01
    z[3,4,0]  R2098     -2.5193458795547485e-01
    z[3,4,0]  R2099     -5.6188285350799561e-01
    z[3,4,0]  R2100     1.5947241336107254e-02
    z[3,4,0]  R2101     2.9958420991897583e-01
    z[3,4,0]  R2102     0.526293158531189
    z[3,4,0]  R2103     -5.1610004901885986e-01
    z[3,4,0]  R2104     -3.3037957549095154e-01
    z[3,4,0]  R2105     3.0317434668540955e-01
    z[3,4,0]  R2106     3.3268904685974121e-01
    z[3,4,0]  R2107     0.154024139046669
    z[3,4,0]  R2108     3.9366778731346130e-01
    z[3,4,0]  R2109     4.0054762363433838e-01
    z[3,4,0]  R2110     3.4238618612289429e-01
    z[3,4,0]  R2111     5.7106947898864746e-01
    z[3,4,0]  R2112     5.3418982028961182e-01
    z[3,4,0]  R2113     6.4118576049804688e-01
    z[3,4,0]  R2114     7.8070056438446045e-01
    z[3,4,0]  R2115     3.5703986883163452e-01
    z[3,4,0]  R2116     -1.4922395348548889e-01
    z[3,4,0]  R2117     3.4297034144401550e-01
    z[3,4,0]  R2118     6.8746519088745117e-01
    z[3,4,0]  R2119     5.9731644392013550e-01
    z[3,4,0]  R2120     0.451546847820282
    z[3,4,0]  R2121     3.8975724577903748e-01
    z[3,4,0]  R2122     5.2762645483016968e-01
    z[3,4,0]  R2123     0.359191358089447
    z[3,4,0]  R2124     3.3647558093070984e-01
    z[3,4,0]  R2125     4.7783535718917847e-01
    z[3,4,0]  R2126     5.2259588241577148e-01
    z[3,4,0]  R2127     5.2622985839843750e-01
    z[3,4,0]  R2128     -3.9881786704063416e-01
    z[3,4,0]  R2129     -2.2276766598224640e-01
    z[3,4,0]  R2130     -3.8694933056831360e-01
    z[3,4,0]  R2131     -1.8728250265121460e-01
    z[3,4,0]  R2132     -6.7813791334629059e-02
    z[3,4,0]  R2133     -0.0692228153347969
    z[3,4,0]  R2134     -1.8829548358917236e-01
    z[3,4,0]  R2135     -3.2876855134963989e-01
    z[3,4,0]  R2136     -0.364611953496933
    z[3,4,0]  R2137     -5.1757901906967163e-01
    z[3,4,0]  R2138     -4.3709689378738403e-01
    z[3,4,0]  R2139     -1.4845295250415802e-01
    z[3,4,0]  R2140     -6.5169042348861694e-01
    z[3,4,0]  R2141     4.5602847822010517e-03
    z[3,4,0]  R2142     -4.2190793156623840e-01
    z[3,4,0]  R2143     1.9931890070438385e-01
    z[3,4,0]  R2144     -1.1368344724178314e-01
    z[3,4,0]  R2145     5.8324247598648071e-01
    z[3,4,0]  R2146     6.9198060035705566e-01
    z[3,4,0]  R2147     0.673913836479187
    z[3,4,0]  R2148     5.4904800653457642e-01
    z[3,4,0]  R2149     6.6781336069107056e-01
    z[3,4,0]  R2150     0.593197226524353
    z[3,4,0]  R2151     7.4587661027908325e-01
    z[3,4,0]  R2152     7.3596894741058350e-01
    z[3,4,0]  R2153     5.3640419244766235e-01
    z[3,4,0]  R2154     2.8914016485214233e-01
    z[3,4,0]  R2155     4.8537275195121765e-01
    z[3,4,0]  R2156     5.3979862481355667e-02
    z[3,4,0]  R2157     8.1701517105102539e-02
    z[3,4,0]  R2158     -5.5371288908645511e-04
    z[3,4,0]  R2159     2.7030816674232483e-01
    z[3,4,0]  R2160     3.8807886838912964e-01
    z[3,4,0]  R2161     5.0469088554382324e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R2085     -1
    z[3,4,1]  R2086     1
    z[3,4,1]  R2097     -8.6314660310745239e-01
    z[3,4,1]  R2098     -0.620816707611084
    z[3,4,1]  R2099     -5.4310923814773560e-01
    z[3,4,1]  R2100     -4.0189677476882935e-01
    z[3,4,1]  R2101     -4.8578220605850220e-01
    z[3,4,1]  R2102     -2.4732129275798798e-01
    z[3,4,1]  R2103     0.180352121591568
    z[3,4,1]  R2104     3.7351536750793457e-01
    z[3,4,1]  R2105     4.2863461375236511e-01
    z[3,4,1]  R2106     0.567589521408081
    z[3,4,1]  R2107     4.7279828786849976e-01
    z[3,4,1]  R2108     6.7619991302490234e-01
    z[3,4,1]  R2109     6.0610163211822510e-01
    z[3,4,1]  R2110     5.5915105342864990e-01
    z[3,4,1]  R2111     4.4078534841537476e-01
    z[3,4,1]  R2112     4.1569101810455322e-01
    z[3,4,1]  R2113     4.3550312519073486e-01
    z[3,4,1]  R2114     4.0601298213005066e-01
    z[3,4,1]  R2115     7.6938372850418091e-01
    z[3,4,1]  R2116     7.6927435398101807e-01
    z[3,4,1]  R2117     6.8489295244216919e-01
    z[3,4,1]  R2118     0.523723304271698
    z[3,4,1]  R2119     5.9777599573135376e-01
    z[3,4,1]  R2120     5.7301956415176392e-01
    z[3,4,1]  R2121     6.8097829818725586e-01
    z[3,4,1]  R2122     6.5009635686874390e-01
    z[3,4,1]  R2123     0.77623051404953
    z[3,4,1]  R2124     0.825904130935669
    z[3,4,1]  R2125     5.0051957368850708e-01
    z[3,4,1]  R2126     4.6122789382934570e-01
    z[3,4,1]  R2127     0.753503680229187
    z[3,4,1]  R2128     6.0441082715988159e-01
    z[3,4,1]  R2129     6.9407802820205688e-01
    z[3,4,1]  R2130     7.0124787092208862e-01
    z[3,4,1]  R2131     6.6254991292953491e-01
    z[3,4,1]  R2132     4.9700316786766052e-01
    z[3,4,1]  R2133     7.7890682220458984e-01
    z[3,4,1]  R2134     6.7440932989120483e-01
    z[3,4,1]  R2135     0.812924325466156
    z[3,4,1]  R2136     0.594958484172821
    z[3,4,1]  R2137     6.1003899574279785e-01
    z[3,4,1]  R2138     5.5178344249725342e-01
    z[3,4,1]  R2139     5.8253526687622070e-01
    z[3,4,1]  R2140     5.1752042770385742e-01
    z[3,4,1]  R2141     5.7960999011993408e-01
    z[3,4,1]  R2142     -4.8534622788429260e-01
    z[3,4,1]  R2143     -6.8122231960296631e-01
    z[3,4,1]  R2144     -6.4879775047302246e-01
    z[3,4,1]  R2145     -4.6633762121200562e-01
    z[3,4,1]  R2146     -4.0039667487144470e-01
    z[3,4,1]  R2147     -4.0915042161941528e-01
    z[3,4,1]  R2148     -3.6398413777351379e-01
    z[3,4,1]  R2149     -5.5775296688079834e-01
    z[3,4,1]  R2150     -4.2307758331298828e-01
    z[3,4,1]  R2151     -3.9859792590141296e-01
    z[3,4,1]  R2152     -0.547124445438385
    z[3,4,1]  R2153     -2.6161062717437744e-01
    z[3,4,1]  R2154     -1.8674476444721222e-01
    z[3,4,1]  R2155     1.7809976637363434e-01
    z[3,4,1]  R2156     -4.5620836317539215e-02
    z[3,4,1]  R2157     -2.5697553157806396e-01
    z[3,4,1]  R2158     -0.725864589214325
    z[3,4,1]  R2159     -5.9336471557617188e-01
    z[3,4,1]  R2160     -1.5418398380279541e-01
    z[3,4,1]  R2161     -7.1462118625640869e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R2087     -1
    z[3,4,2]  R2088     1
    z[3,4,2]  R2097     2.2956785559654236e-01
    z[3,4,2]  R2098     4.2582547664642334e-01
    z[3,4,2]  R2099     -1.6568163037300110e-01
    z[3,4,2]  R2100     5.4286289215087891e-01
    z[3,4,2]  R2101     -5.3863358497619629e-01
    z[3,4,2]  R2102     -3.8546475768089294e-01
    z[3,4,2]  R2103     4.0814954042434692e-01
    z[3,4,2]  R2104     -4.4135829806327820e-01
    z[3,4,2]  R2105     3.7516161799430847e-01
    z[3,4,2]  R2106     2.8477218747138977e-01
    z[3,4,2]  R2107     -2.2615494672209024e-03
    z[3,4,2]  R2108     3.3404495567083359e-02
    z[3,4,2]  R2109     -4.4436094164848328e-01
    z[3,4,2]  R2110     0.0140988202765584
    z[3,4,2]  R2111     4.9933022260665894e-01
    z[3,4,2]  R2112     -1.5091960132122040e-01
    z[3,4,2]  R2113     -3.3889949321746826e-01
    z[3,4,2]  R2114     2.6863566040992737e-01
    z[3,4,2]  R2115     -2.5784516334533691e-01
    z[3,4,2]  R2116     1.3406106829643250e-01
    z[3,4,2]  R2117     -6.1934594996273518e-03
    z[3,4,2]  R2118     3.0340753495693207e-02
    z[3,4,2]  R2119     -2.0380338653922081e-02
    z[3,4,2]  R2120     1.6603243350982666e-01
    z[3,4,2]  R2121     -1.2298868969082832e-02
    z[3,4,2]  R2122     1.7190766334533691e-01
    z[3,4,2]  R2123     1.2203613668680191e-01
    z[3,4,2]  R2124     1.2268714606761932e-01
    z[3,4,2]  R2125     2.8339171409606934e-01
    z[3,4,2]  R2126     2.9617032408714294e-01
    z[3,4,2]  R2127     -1.5018188953399658e-01
    z[3,4,2]  R2128     4.4502297043800354e-01
    z[3,4,2]  R2129     2.9261613264679909e-02
    z[3,4,2]  R2130     -3.6792778968811035e-01
    z[3,4,2]  R2131     -2.3362116515636444e-01
    z[3,4,2]  R2132     -3.2235378026962280e-01
    z[3,4,2]  R2133     -2.9798674583435059e-01
    z[3,4,2]  R2134     -0.347235769033432
    z[3,4,2]  R2135     -7.6188750565052032e-02
    z[3,4,2]  R2136     2.3774772882461548e-01
    z[3,4,2]  R2137     -0.0581904798746109
    z[3,4,2]  R2138     4.2077171802520752e-01
    z[3,4,2]  R2139     -2.3059609532356262e-01
    z[3,4,2]  R2140     1.4783754944801331e-01
    z[3,4,2]  R2141     -4.7947093844413757e-01
    z[3,4,2]  R2142     -1.1642266064882278e-01
    z[3,4,2]  R2143     3.3215153217315674e-01
    z[3,4,2]  R2144     2.8857752680778503e-01
    z[3,4,2]  R2145     5.6902801990509033e-01
    z[3,4,2]  R2146     0.561430811882019
    z[3,4,2]  R2147     5.6609356403350830e-01
    z[3,4,2]  R2148     6.9370740652084351e-01
    z[3,4,2]  R2149     4.2793425917625427e-01
    z[3,4,2]  R2150     4.9629786610603333e-01
    z[3,4,2]  R2151     2.9269164800643921e-01
    z[3,4,2]  R2152     2.1162860095500946e-01
    z[3,4,2]  R2153     -3.2568764686584473e-01
    z[3,4,2]  R2154     -1.9889141619205475e-01
    z[3,4,2]  R2155     -1.4858931303024292e-01
    z[3,4,2]  R2156     2.5257551670074463e-01
    z[3,4,2]  R2157     -4.2722240090370178e-02
    z[3,4,2]  R2158     3.6074250936508179e-01
    z[3,4,2]  R2159     1.5408769249916077e-01
    z[3,4,2]  R2160     5.6516725569963455e-02
    z[3,4,2]  R2161     -2.8202304244041443e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R2089     -1
    z[3,4,3]  R2090     1
    z[3,4,3]  R2097     -1.6177067160606384e-01
    z[3,4,3]  R2098     -2.6279929280281067e-01
    z[3,4,3]  R2099     -2.6221841573715210e-01
    z[3,4,3]  R2100     1.3024370372295380e-01
    z[3,4,3]  R2101     -3.8735681772232056e-01
    z[3,4,3]  R2102     -2.7802714705467224e-01
    z[3,4,3]  R2103     -2.8050836920738220e-01
    z[3,4,3]  R2104     -4.0410766005516052e-01
    z[3,4,3]  R2105     6.2525969743728638e-01
    z[3,4,3]  R2106     1.2843927368521690e-02
    z[3,4,3]  R2107     -6.5263265371322632e-01
    z[3,4,3]  R2108     4.4501677155494690e-01
    z[3,4,3]  R2109     4.9889558553695679e-01
    z[3,4,3]  R2110     4.7653332352638245e-01
    z[3,4,3]  R2111     4.1545253992080688e-01
    z[3,4,3]  R2112     4.8808595538139343e-01
    z[3,4,3]  R2113     4.2026409506797791e-01
    z[3,4,3]  R2114     1.4036716520786285e-01
    z[3,4,3]  R2115     2.2125220298767090e-01
    z[3,4,3]  R2116     5.8147305250167847e-01
    z[3,4,3]  R2117     4.7862425446510315e-01
    z[3,4,3]  R2118     4.2620095610618591e-01
    z[3,4,3]  R2119     5.0037211179733276e-01
    z[3,4,3]  R2120     5.6852996349334717e-01
    z[3,4,3]  R2121     5.5031090974807739e-01
    z[3,4,3]  R2122     3.2639884948730469e-01
    z[3,4,3]  R2123     3.2783108949661255e-01
    z[3,4,3]  R2124     3.9959990978240967e-01
    z[3,4,3]  R2125     5.1531338691711426e-01
    z[3,4,3]  R2126     2.4345543980598450e-01
    z[3,4,3]  R2127     2.5134083628654480e-01
    z[3,4,3]  R2128     3.5491314530372620e-01
    z[3,4,3]  R2129     3.9876180887222290e-01
    z[3,4,3]  R2130     2.8322747349739075e-01
    z[3,4,3]  R2131     5.1692402362823486e-01
    z[3,4,3]  R2132     5.1157861948013306e-01
    z[3,4,3]  R2133     -2.7236613631248474e-01
    z[3,4,3]  R2134     4.8791030049324036e-01
    z[3,4,3]  R2135     1.8327637016773224e-01
    z[3,4,3]  R2136     4.3993502855300903e-01
    z[3,4,3]  R2137     2.8136044740676880e-01
    z[3,4,3]  R2138     -1.7711807787418365e-01
    z[3,4,3]  R2139     -1.3692776858806610e-01
    z[3,4,3]  R2140     -2.7051979303359985e-01
    z[3,4,3]  R2141     9.7662389278411865e-02
    z[3,4,3]  R2142     -2.1610608696937561e-01
    z[3,4,3]  R2143     -3.7701785564422607e-01
    z[3,4,3]  R2144     -6.3731677830219269e-02
    z[3,4,3]  R2145     -4.6401996165513992e-02
    z[3,4,3]  R2146     -8.5805654525756836e-02
    z[3,4,3]  R2147     -1.5014901757240295e-01
    z[3,4,3]  R2148     -5.4991997778415680e-02
    z[3,4,3]  R2149     1.2495151162147522e-01
    z[3,4,3]  R2150     7.7261097729206085e-02
    z[3,4,3]  R2151     -4.2161926627159119e-02
    z[3,4,3]  R2152     8.5739880800247192e-02
    z[3,4,3]  R2153     -7.1150410175323486e-01
    z[3,4,3]  R2154     -6.3634729385375977e-01
    z[3,4,3]  R2155     -7.4254709482192993e-01
    z[3,4,3]  R2156     -7.9481166601181030e-01
    z[3,4,3]  R2157     -5.0166660547256470e-01
    z[3,4,3]  R2158     -0.315601110458374
    z[3,4,3]  R2159     -5.9093427658081055e-01
    z[3,4,3]  R2160     -6.3995629549026489e-01
    z[3,4,3]  R2161     1.8050726503133774e-02
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R2091     -1
    z[3,4,4]  R2092     1
    z[3,4,4]  R2097     -6.5339556895196438e-03
    z[3,4,4]  R2098     1.4562240242958069e-01
    z[3,4,4]  R2099     4.8759466409683228e-01
    z[3,4,4]  R2100     -5.0998383760452271e-01
    z[3,4,4]  R2101     2.5875428691506386e-02
    z[3,4,4]  R2102     -2.5735804438591003e-01
    z[3,4,4]  R2103     -7.9946219921112061e-04
    z[3,4,4]  R2104     8.2271791994571686e-02
    z[3,4,4]  R2105     -3.4042972326278687e-01
    z[3,4,4]  R2106     3.3132830262184143e-01
    z[3,4,4]  R2107     2.3930130898952484e-01
    z[3,4,4]  R2108     3.3419987559318542e-01
    z[3,4,4]  R2109     1.1739798635244370e-01
    z[3,4,4]  R2110     5.4334950447082520e-01
    z[3,4,4]  R2111     2.1896690130233765e-01
    z[3,4,4]  R2112     5.0954711437225342e-01
    z[3,4,4]  R2113     -2.7300122380256653e-01
    z[3,4,4]  R2114     1.1436348408460617e-01
    z[3,4,4]  R2115     -6.5126776695251465e-02
    z[3,4,4]  R2116     3.4790221601724625e-02
    z[3,4,4]  R2117     -1.4352890849113464e-01
    z[3,4,4]  R2118     1.5856587886810303e-01
    z[3,4,4]  R2119     -0.129226416349411
    z[3,4,4]  R2120     2.1101680397987366e-01
    z[3,4,4]  R2121     2.0117874443531036e-01
    z[3,4,4]  R2122     -3.3486044406890869e-01
    z[3,4,4]  R2123     -1.0937442071735859e-02
    z[3,4,4]  R2124     -1.2377080321311951e-01
    z[3,4,4]  R2125     -5.8204419910907745e-02
    z[3,4,4]  R2126     -7.0177665911614895e-03
    z[3,4,4]  R2127     -1.3035634160041809e-01
    z[3,4,4]  R2128     -1.9441822543740273e-02
    z[3,4,4]  R2129     -9.7734019160270691e-02
    z[3,4,4]  R2130     2.4935714900493622e-01
    z[3,4,4]  R2131     1.0530297458171844e-01
    z[3,4,4]  R2132     1.9780211150646210e-01
    z[3,4,4]  R2133     4.3432092666625977e-01
    z[3,4,4]  R2134     3.4715458750724792e-01
    z[3,4,4]  R2135     4.3599805235862732e-01
    z[3,4,4]  R2136     6.2857642769813538e-02
    z[3,4,4]  R2137     1.6727188229560852e-01
    z[3,4,4]  R2138     3.2528951764106750e-01
    z[3,4,4]  R2139     -4.4658705592155457e-02
    z[3,4,4]  R2140     -1.3284756243228912e-01
    z[3,4,4]  R2141     1.2144851684570312e-01
    z[3,4,4]  R2142     4.8336514830589294e-01
    z[3,4,4]  R2143     -1.4025740325450897e-01
    z[3,4,4]  R2144     1.1695694178342819e-01
    z[3,4,4]  R2145     2.9780622571706772e-02
    z[3,4,4]  R2146     -0.113673135638237
    z[3,4,4]  R2147     9.4564080238342285e-02
    z[3,4,4]  R2148     -2.2984115406870842e-02
    z[3,4,4]  R2149     1.2909808754920959e-01
    z[3,4,4]  R2150     -1.5918545424938202e-01
    z[3,4,4]  R2151     -1.1347037553787231e-01
    z[3,4,4]  R2152     -1.8654270470142365e-01
    z[3,4,4]  R2153     1.5339119732379913e-01
    z[3,4,4]  R2154     -8.2135021686553955e-02
    z[3,4,4]  R2155     8.2185156643390656e-02
    z[3,4,4]  R2156     -1.1228418350219727e-01
    z[3,4,4]  R2157     2.6528099179267883e-01
    z[3,4,4]  R2158     -4.2539444565773010e-01
    z[3,4,4]  R2159     9.4021543860435486e-02
    z[3,4,4]  R2160     -4.5273822546005249e-01
    z[3,4,4]  R2161     -0.379819393157959
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R2093     -1
    z[3,4,5]  R2094     1
    z[3,4,5]  R2097     -2.5043833255767822e-01
    z[3,4,5]  R2098     3.2815396785736084e-01
    z[3,4,5]  R2099     5.5406481027603149e-02
    z[3,4,5]  R2100     3.8574171066284180e-01
    z[3,4,5]  R2101     4.4239467382431030e-01
    z[3,4,5]  R2102     -2.3063258826732635e-01
    z[3,4,5]  R2103     -1.5647193789482117e-01
    z[3,4,5]  R2104     2.8870645165443420e-01
    z[3,4,5]  R2105     -2.7284887433052063e-01
    z[3,4,5]  R2106     -5.2633565664291382e-01
    z[3,4,5]  R2107     -0.297408789396286
    z[3,4,5]  R2108     1.8562559783458710e-01
    z[3,4,5]  R2109     4.2010764591395855e-03
    z[3,4,5]  R2110     -8.6681410670280457e-02
    z[3,4,5]  R2111     9.7037024796009064e-02
    z[3,4,5]  R2112     -7.6643405482172966e-03
    z[3,4,5]  R2113     1.8124409019947052e-01
    z[3,4,5]  R2114     3.4569692611694336e-01
    z[3,4,5]  R2115     3.8990718126296997e-01
    z[3,4,5]  R2116     -1.4692430198192596e-01
    z[3,4,5]  R2117     -4.0169146656990051e-01
    z[3,4,5]  R2118     -2.1082855761051178e-01
    z[3,4,5]  R2119     -5.7908255606889725e-02
    z[3,4,5]  R2120     -2.6901489496231079e-01
    z[3,4,5]  R2121     -1.2342879176139832e-01
    z[3,4,5]  R2122     -1.8436795473098755e-01
    z[3,4,5]  R2123     -1.7887786030769348e-01
    z[3,4,5]  R2124     8.9686758816242218e-02
    z[3,4,5]  R2125     -1.9222494959831238e-01
    z[3,4,5]  R2126     -4.6440163254737854e-01
    z[3,4,5]  R2127     -1.4157579839229584e-01
    z[3,4,5]  R2128     2.7153030037879944e-01
    z[3,4,5]  R2129     5.4672157764434814e-01
    z[3,4,5]  R2130     2.2526112198829651e-01
    z[3,4,5]  R2131     -3.9854088425636292e-01
    z[3,4,5]  R2132     2.8633320331573486e-01
    z[3,4,5]  R2133     -1.1757581681013107e-01
    z[3,4,5]  R2134     -6.0707405209541321e-02
    z[3,4,5]  R2135     6.5165506675839424e-03
    z[3,4,5]  R2136     -3.0680984258651733e-01
    z[3,4,5]  R2137     1.6882508993148804e-01
    z[3,4,5]  R2138     -4.3570473790168762e-01
    z[3,4,5]  R2139     2.8054052591323853e-01
    z[3,4,5]  R2140     -3.7503218650817871e-01
    z[3,4,5]  R2141     4.0232893824577332e-01
    z[3,4,5]  R2142     8.7758600711822510e-02
    z[3,4,5]  R2143     -2.8529292345046997e-01
    z[3,4,5]  R2144     -1.2879328429698944e-01
    z[3,4,5]  R2145     3.3906564116477966e-01
    z[3,4,5]  R2146     1.3632264733314514e-01
    z[3,4,5]  R2147     1.3902534544467926e-01
    z[3,4,5]  R2148     1.9321456551551819e-01
    z[3,4,5]  R2149     1.4572256803512573e-01
    z[3,4,5]  R2150     3.3065313100814819e-01
    z[3,4,5]  R2151     3.3350548148155212e-01
    z[3,4,5]  R2152     2.5434008240699768e-01
    z[3,4,5]  R2153     0.0653185248374939
    z[3,4,5]  R2154     6.4751470088958740e-01
    z[3,4,5]  R2155     -2.3476819694042206e-01
    z[3,4,5]  R2156     4.9129912257194519e-01
    z[3,4,5]  R2157     3.8730046153068542e-01
    z[3,4,5]  R2158     2.4547970294952393e-01
    z[3,4,5]  R2159     -4.3531551957130432e-01
    z[3,4,5]  R2160     2.4686281383037567e-01
    z[3,4,5]  R2161     5.7919424027204514e-02
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R2095     -1
    z[3,4,6]  R2096     1
    z[3,4,6]  R2097     2.8108218312263489e-01
    z[3,4,6]  R2098     4.1452851891517639e-01
    z[3,4,6]  R2099     -2.2867612540721893e-01
    z[3,4,6]  R2100     -3.4304666519165039e-01
    z[3,4,6]  R2101     -1.9419296085834503e-01
    z[3,4,6]  R2102     -5.6261980533599854e-01
    z[3,4,6]  R2103     -6.5677899122238159e-01
    z[3,4,6]  R2104     5.5055910348892212e-01
    z[3,4,6]  R2105     -4.8196125775575638e-02
    z[3,4,6]  R2106     3.1478923559188843e-01
    z[3,4,6]  R2107     4.2554289102554321e-01
    z[3,4,6]  R2108     -2.0609997212886810e-01
    z[3,4,6]  R2109     1.0976740717887878e-01
    z[3,4,6]  R2110     -2.0024146139621735e-01
    z[3,4,6]  R2111     1.7138667404651642e-02
    z[3,4,6]  R2112     1.4539824426174164e-01
    z[3,4,6]  R2113     -1.9080650061368942e-02
    z[3,4,6]  R2114     -3.4737512469291687e-02
    z[3,4,6]  R2115     -9.4156764447689056e-02
    z[3,4,6]  R2116     -8.4076039493083954e-02
    z[3,4,6]  R2117     4.7083523124456406e-02
    z[3,4,6]  R2118     3.0754547566175461e-02
    z[3,4,6]  R2119     1.2262330204248428e-01
    z[3,4,6]  R2120     -8.0017736181616783e-03
    z[3,4,6]  R2121     1.6017764806747437e-01
    z[3,4,6]  R2122     -0.129512757062912
    z[3,4,6]  R2123     -3.3758670091629028e-01
    z[3,4,6]  R2124     8.1064760684967041e-02
    z[3,4,6]  R2125     -3.6736443638801575e-01
    z[3,4,6]  R2126     -3.8917452096939087e-01
    z[3,4,6]  R2127     -0.1804189234972
    z[3,4,6]  R2128     2.7841767668724060e-01
    z[3,4,6]  R2129     1.7514521256089211e-02
    z[3,4,6]  R2130     -1.7323812842369080e-01
    z[3,4,6]  R2131     -0.185040682554245
    z[3,4,6]  R2132     5.1151943206787109e-01
    z[3,4,6]  R2133     -1.5190209448337555e-01
    z[3,4,6]  R2134     -0.163969486951828
    z[3,4,6]  R2135     -3.9161231368780136e-02
    z[3,4,6]  R2136     -4.0611866116523743e-01
    z[3,4,6]  R2137     -4.7003483772277832e-01
    z[3,4,6]  R2138     -2.0241707563400269e-02
    z[3,4,6]  R2139     -6.9713217020034790e-01
    z[3,4,6]  R2140     0.232675239443779
    z[3,4,6]  R2141     4.9797871708869934e-01
    z[3,4,6]  R2142     5.3369772434234619e-01
    z[3,4,6]  R2143     -3.7772583961486816e-01
    z[3,4,6]  R2144     -6.6972541809082031e-01
    z[3,4,6]  R2145     -2.3642625659704208e-02
    z[3,4,6]  R2146     8.2296334207057953e-02
    z[3,4,6]  R2147     8.4611341357231140e-02
    z[3,4,6]  R2148     2.0963713526725769e-01
    z[3,4,6]  R2149     7.9340517520904541e-02
    z[3,4,6]  R2150     2.8665328025817871e-01
    z[3,4,6]  R2151     2.7062943577766418e-01
    z[3,4,6]  R2152     -0.0859035924077034
    z[3,4,6]  R2153     -0.061029102653265
    z[3,4,6]  R2154     -1.0491538792848587e-01
    z[3,4,6]  R2155     3.1203892827033997e-01
    z[3,4,6]  R2156     -2.1331250667572021e-01
    z[3,4,6]  R2157     -6.7336338758468628e-01
    z[3,4,6]  R2158     -4.6480432152748108e-02
    z[3,4,6]  R2159     -5.9714134782552719e-02
    z[3,4,6]  R2160     3.8336774706840515e-01
    z[3,4,6]  R2161     8.4399670362472534e-02
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R2162     -1
    z[4,3,0]  R2163     1
    z[4,3,0]  R2176     -0.0692228153347969
    z[4,3,0]  R2177     -1.8829548358917236e-01
    z[4,3,0]  R2178     -3.2876855134963989e-01
    z[4,3,0]  R2179     -0.364611953496933
    z[4,3,0]  R2180     -5.1757901906967163e-01
    z[4,3,0]  R2181     -4.3709689378738403e-01
    z[4,3,0]  R2182     -1.4845295250415802e-01
    z[4,3,0]  R2183     -6.5169042348861694e-01
    z[4,3,0]  R2184     4.5602847822010517e-03
    z[4,3,0]  R2185     -4.2190793156623840e-01
    z[4,3,0]  R2186     1.9931890070438385e-01
    z[4,3,0]  R2187     -1.1368344724178314e-01
    z[4,3,0]  R2188     5.8324247598648071e-01
    z[4,3,0]  R2189     6.9198060035705566e-01
    z[4,3,0]  R2190     0.673913836479187
    z[4,3,0]  R2191     5.4904800653457642e-01
    z[4,3,0]  R2192     6.6781336069107056e-01
    z[4,3,0]  R2193     0.593197226524353
    z[4,3,0]  R2194     7.4587661027908325e-01
    z[4,3,0]  R2195     7.3596894741058350e-01
    z[4,3,0]  R2196     5.3640419244766235e-01
    z[4,3,0]  R2197     2.8914016485214233e-01
    z[4,3,0]  R2198     4.8537275195121765e-01
    z[4,3,0]  R2199     5.3979862481355667e-02
    z[4,3,0]  R2200     8.1701517105102539e-02
    z[4,3,0]  R2201     -5.5371288908645511e-04
    z[4,3,0]  R2202     2.7030816674232483e-01
    z[4,3,0]  R2203     3.8807886838912964e-01
    z[4,3,0]  R2204     5.0469088554382324e-01
    z[4,3,0]  R2205     1.8530371785163879e-01
    z[4,3,0]  R2206     -2.5193458795547485e-01
    z[4,3,0]  R2207     -5.6188285350799561e-01
    z[4,3,0]  R2208     1.5947241336107254e-02
    z[4,3,0]  R2209     2.9958420991897583e-01
    z[4,3,0]  R2210     0.526293158531189
    z[4,3,0]  R2211     -5.1610004901885986e-01
    z[4,3,0]  R2212     -3.3037957549095154e-01
    z[4,3,0]  R2213     3.0317434668540955e-01
    z[4,3,0]  R2214     3.3268904685974121e-01
    z[4,3,0]  R2215     0.154024139046669
    z[4,3,0]  R2216     3.9366778731346130e-01
    z[4,3,0]  R2217     4.0054762363433838e-01
    z[4,3,0]  R2218     3.4238618612289429e-01
    z[4,3,0]  R2219     5.7106947898864746e-01
    z[4,3,0]  R2220     5.3418982028961182e-01
    z[4,3,0]  R2221     6.4118576049804688e-01
    z[4,3,0]  R2222     7.8070056438446045e-01
    z[4,3,0]  R2223     3.5703986883163452e-01
    z[4,3,0]  R2224     -1.4922395348548889e-01
    z[4,3,0]  R2225     3.4297034144401550e-01
    z[4,3,0]  R2226     6.8746519088745117e-01
    z[4,3,0]  R2227     5.9731644392013550e-01
    z[4,3,0]  R2228     0.451546847820282
    z[4,3,0]  R2229     3.8975724577903748e-01
    z[4,3,0]  R2230     5.2762645483016968e-01
    z[4,3,0]  R2231     0.359191358089447
    z[4,3,0]  R2232     3.3647558093070984e-01
    z[4,3,0]  R2233     4.7783535718917847e-01
    z[4,3,0]  R2234     5.2259588241577148e-01
    z[4,3,0]  R2235     5.2622985839843750e-01
    z[4,3,0]  R2236     -3.9881786704063416e-01
    z[4,3,0]  R2237     -2.2276766598224640e-01
    z[4,3,0]  R2238     -3.8694933056831360e-01
    z[4,3,0]  R2239     -1.8728250265121460e-01
    z[4,3,0]  R2240     -6.7813791334629059e-02
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R2164     -1
    z[4,3,1]  R2165     1
    z[4,3,1]  R2176     7.7890682220458984e-01
    z[4,3,1]  R2177     6.7440932989120483e-01
    z[4,3,1]  R2178     0.812924325466156
    z[4,3,1]  R2179     0.594958484172821
    z[4,3,1]  R2180     6.1003899574279785e-01
    z[4,3,1]  R2181     5.5178344249725342e-01
    z[4,3,1]  R2182     5.8253526687622070e-01
    z[4,3,1]  R2183     5.1752042770385742e-01
    z[4,3,1]  R2184     5.7960999011993408e-01
    z[4,3,1]  R2185     -4.8534622788429260e-01
    z[4,3,1]  R2186     -6.8122231960296631e-01
    z[4,3,1]  R2187     -6.4879775047302246e-01
    z[4,3,1]  R2188     -4.6633762121200562e-01
    z[4,3,1]  R2189     -4.0039667487144470e-01
    z[4,3,1]  R2190     -4.0915042161941528e-01
    z[4,3,1]  R2191     -3.6398413777351379e-01
    z[4,3,1]  R2192     -5.5775296688079834e-01
    z[4,3,1]  R2193     -4.2307758331298828e-01
    z[4,3,1]  R2194     -3.9859792590141296e-01
    z[4,3,1]  R2195     -0.547124445438385
    z[4,3,1]  R2196     -2.6161062717437744e-01
    z[4,3,1]  R2197     -1.8674476444721222e-01
    z[4,3,1]  R2198     1.7809976637363434e-01
    z[4,3,1]  R2199     -4.5620836317539215e-02
    z[4,3,1]  R2200     -2.5697553157806396e-01
    z[4,3,1]  R2201     -0.725864589214325
    z[4,3,1]  R2202     -5.9336471557617188e-01
    z[4,3,1]  R2203     -1.5418398380279541e-01
    z[4,3,1]  R2204     -7.1462118625640869e-01
    z[4,3,1]  R2205     -8.6314660310745239e-01
    z[4,3,1]  R2206     -0.620816707611084
    z[4,3,1]  R2207     -5.4310923814773560e-01
    z[4,3,1]  R2208     -4.0189677476882935e-01
    z[4,3,1]  R2209     -4.8578220605850220e-01
    z[4,3,1]  R2210     -2.4732129275798798e-01
    z[4,3,1]  R2211     0.180352121591568
    z[4,3,1]  R2212     3.7351536750793457e-01
    z[4,3,1]  R2213     4.2863461375236511e-01
    z[4,3,1]  R2214     0.567589521408081
    z[4,3,1]  R2215     4.7279828786849976e-01
    z[4,3,1]  R2216     6.7619991302490234e-01
    z[4,3,1]  R2217     6.0610163211822510e-01
    z[4,3,1]  R2218     5.5915105342864990e-01
    z[4,3,1]  R2219     4.4078534841537476e-01
    z[4,3,1]  R2220     4.1569101810455322e-01
    z[4,3,1]  R2221     4.3550312519073486e-01
    z[4,3,1]  R2222     4.0601298213005066e-01
    z[4,3,1]  R2223     7.6938372850418091e-01
    z[4,3,1]  R2224     7.6927435398101807e-01
    z[4,3,1]  R2225     6.8489295244216919e-01
    z[4,3,1]  R2226     0.523723304271698
    z[4,3,1]  R2227     5.9777599573135376e-01
    z[4,3,1]  R2228     5.7301956415176392e-01
    z[4,3,1]  R2229     6.8097829818725586e-01
    z[4,3,1]  R2230     6.5009635686874390e-01
    z[4,3,1]  R2231     0.77623051404953
    z[4,3,1]  R2232     0.825904130935669
    z[4,3,1]  R2233     5.0051957368850708e-01
    z[4,3,1]  R2234     4.6122789382934570e-01
    z[4,3,1]  R2235     0.753503680229187
    z[4,3,1]  R2236     6.0441082715988159e-01
    z[4,3,1]  R2237     6.9407802820205688e-01
    z[4,3,1]  R2238     7.0124787092208862e-01
    z[4,3,1]  R2239     6.6254991292953491e-01
    z[4,3,1]  R2240     4.9700316786766052e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R2166     -1
    z[4,3,2]  R2167     1
    z[4,3,2]  R2176     -2.9798674583435059e-01
    z[4,3,2]  R2177     -0.347235769033432
    z[4,3,2]  R2178     -7.6188750565052032e-02
    z[4,3,2]  R2179     2.3774772882461548e-01
    z[4,3,2]  R2180     -0.0581904798746109
    z[4,3,2]  R2181     4.2077171802520752e-01
    z[4,3,2]  R2182     -2.3059609532356262e-01
    z[4,3,2]  R2183     1.4783754944801331e-01
    z[4,3,2]  R2184     -4.7947093844413757e-01
    z[4,3,2]  R2185     -1.1642266064882278e-01
    z[4,3,2]  R2186     3.3215153217315674e-01
    z[4,3,2]  R2187     2.8857752680778503e-01
    z[4,3,2]  R2188     5.6902801990509033e-01
    z[4,3,2]  R2189     0.561430811882019
    z[4,3,2]  R2190     5.6609356403350830e-01
    z[4,3,2]  R2191     6.9370740652084351e-01
    z[4,3,2]  R2192     4.2793425917625427e-01
    z[4,3,2]  R2193     4.9629786610603333e-01
    z[4,3,2]  R2194     2.9269164800643921e-01
    z[4,3,2]  R2195     2.1162860095500946e-01
    z[4,3,2]  R2196     -3.2568764686584473e-01
    z[4,3,2]  R2197     -1.9889141619205475e-01
    z[4,3,2]  R2198     -1.4858931303024292e-01
    z[4,3,2]  R2199     2.5257551670074463e-01
    z[4,3,2]  R2200     -4.2722240090370178e-02
    z[4,3,2]  R2201     3.6074250936508179e-01
    z[4,3,2]  R2202     1.5408769249916077e-01
    z[4,3,2]  R2203     5.6516725569963455e-02
    z[4,3,2]  R2204     -2.8202304244041443e-01
    z[4,3,2]  R2205     2.2956785559654236e-01
    z[4,3,2]  R2206     4.2582547664642334e-01
    z[4,3,2]  R2207     -1.6568163037300110e-01
    z[4,3,2]  R2208     5.4286289215087891e-01
    z[4,3,2]  R2209     -5.3863358497619629e-01
    z[4,3,2]  R2210     -3.8546475768089294e-01
    z[4,3,2]  R2211     4.0814954042434692e-01
    z[4,3,2]  R2212     -4.4135829806327820e-01
    z[4,3,2]  R2213     3.7516161799430847e-01
    z[4,3,2]  R2214     2.8477218747138977e-01
    z[4,3,2]  R2215     -2.2615494672209024e-03
    z[4,3,2]  R2216     3.3404495567083359e-02
    z[4,3,2]  R2217     -4.4436094164848328e-01
    z[4,3,2]  R2218     0.0140988202765584
    z[4,3,2]  R2219     4.9933022260665894e-01
    z[4,3,2]  R2220     -1.5091960132122040e-01
    z[4,3,2]  R2221     -3.3889949321746826e-01
    z[4,3,2]  R2222     2.6863566040992737e-01
    z[4,3,2]  R2223     -2.5784516334533691e-01
    z[4,3,2]  R2224     1.3406106829643250e-01
    z[4,3,2]  R2225     -6.1934594996273518e-03
    z[4,3,2]  R2226     3.0340753495693207e-02
    z[4,3,2]  R2227     -2.0380338653922081e-02
    z[4,3,2]  R2228     1.6603243350982666e-01
    z[4,3,2]  R2229     -1.2298868969082832e-02
    z[4,3,2]  R2230     1.7190766334533691e-01
    z[4,3,2]  R2231     1.2203613668680191e-01
    z[4,3,2]  R2232     1.2268714606761932e-01
    z[4,3,2]  R2233     2.8339171409606934e-01
    z[4,3,2]  R2234     2.9617032408714294e-01
    z[4,3,2]  R2235     -1.5018188953399658e-01
    z[4,3,2]  R2236     4.4502297043800354e-01
    z[4,3,2]  R2237     2.9261613264679909e-02
    z[4,3,2]  R2238     -3.6792778968811035e-01
    z[4,3,2]  R2239     -2.3362116515636444e-01
    z[4,3,2]  R2240     -3.2235378026962280e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R2168     -1
    z[4,3,3]  R2169     1
    z[4,3,3]  R2176     -2.7236613631248474e-01
    z[4,3,3]  R2177     4.8791030049324036e-01
    z[4,3,3]  R2178     1.8327637016773224e-01
    z[4,3,3]  R2179     4.3993502855300903e-01
    z[4,3,3]  R2180     2.8136044740676880e-01
    z[4,3,3]  R2181     -1.7711807787418365e-01
    z[4,3,3]  R2182     -1.3692776858806610e-01
    z[4,3,3]  R2183     -2.7051979303359985e-01
    z[4,3,3]  R2184     9.7662389278411865e-02
    z[4,3,3]  R2185     -2.1610608696937561e-01
    z[4,3,3]  R2186     -3.7701785564422607e-01
    z[4,3,3]  R2187     -6.3731677830219269e-02
    z[4,3,3]  R2188     -4.6401996165513992e-02
    z[4,3,3]  R2189     -8.5805654525756836e-02
    z[4,3,3]  R2190     -1.5014901757240295e-01
    z[4,3,3]  R2191     -5.4991997778415680e-02
    z[4,3,3]  R2192     1.2495151162147522e-01
    z[4,3,3]  R2193     7.7261097729206085e-02
    z[4,3,3]  R2194     -4.2161926627159119e-02
    z[4,3,3]  R2195     8.5739880800247192e-02
    z[4,3,3]  R2196     -7.1150410175323486e-01
    z[4,3,3]  R2197     -6.3634729385375977e-01
    z[4,3,3]  R2198     -7.4254709482192993e-01
    z[4,3,3]  R2199     -7.9481166601181030e-01
    z[4,3,3]  R2200     -5.0166660547256470e-01
    z[4,3,3]  R2201     -0.315601110458374
    z[4,3,3]  R2202     -5.9093427658081055e-01
    z[4,3,3]  R2203     -6.3995629549026489e-01
    z[4,3,3]  R2204     1.8050726503133774e-02
    z[4,3,3]  R2205     -1.6177067160606384e-01
    z[4,3,3]  R2206     -2.6279929280281067e-01
    z[4,3,3]  R2207     -2.6221841573715210e-01
    z[4,3,3]  R2208     1.3024370372295380e-01
    z[4,3,3]  R2209     -3.8735681772232056e-01
    z[4,3,3]  R2210     -2.7802714705467224e-01
    z[4,3,3]  R2211     -2.8050836920738220e-01
    z[4,3,3]  R2212     -4.0410766005516052e-01
    z[4,3,3]  R2213     6.2525969743728638e-01
    z[4,3,3]  R2214     1.2843927368521690e-02
    z[4,3,3]  R2215     -6.5263265371322632e-01
    z[4,3,3]  R2216     4.4501677155494690e-01
    z[4,3,3]  R2217     4.9889558553695679e-01
    z[4,3,3]  R2218     4.7653332352638245e-01
    z[4,3,3]  R2219     4.1545253992080688e-01
    z[4,3,3]  R2220     4.8808595538139343e-01
    z[4,3,3]  R2221     4.2026409506797791e-01
    z[4,3,3]  R2222     1.4036716520786285e-01
    z[4,3,3]  R2223     2.2125220298767090e-01
    z[4,3,3]  R2224     5.8147305250167847e-01
    z[4,3,3]  R2225     4.7862425446510315e-01
    z[4,3,3]  R2226     4.2620095610618591e-01
    z[4,3,3]  R2227     5.0037211179733276e-01
    z[4,3,3]  R2228     5.6852996349334717e-01
    z[4,3,3]  R2229     5.5031090974807739e-01
    z[4,3,3]  R2230     3.2639884948730469e-01
    z[4,3,3]  R2231     3.2783108949661255e-01
    z[4,3,3]  R2232     3.9959990978240967e-01
    z[4,3,3]  R2233     5.1531338691711426e-01
    z[4,3,3]  R2234     2.4345543980598450e-01
    z[4,3,3]  R2235     2.5134083628654480e-01
    z[4,3,3]  R2236     3.5491314530372620e-01
    z[4,3,3]  R2237     3.9876180887222290e-01
    z[4,3,3]  R2238     2.8322747349739075e-01
    z[4,3,3]  R2239     5.1692402362823486e-01
    z[4,3,3]  R2240     5.1157861948013306e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R2170     -1
    z[4,3,4]  R2171     1
    z[4,3,4]  R2176     4.3432092666625977e-01
    z[4,3,4]  R2177     3.4715458750724792e-01
    z[4,3,4]  R2178     4.3599805235862732e-01
    z[4,3,4]  R2179     6.2857642769813538e-02
    z[4,3,4]  R2180     1.6727188229560852e-01
    z[4,3,4]  R2181     3.2528951764106750e-01
    z[4,3,4]  R2182     -4.4658705592155457e-02
    z[4,3,4]  R2183     -1.3284756243228912e-01
    z[4,3,4]  R2184     1.2144851684570312e-01
    z[4,3,4]  R2185     4.8336514830589294e-01
    z[4,3,4]  R2186     -1.4025740325450897e-01
    z[4,3,4]  R2187     1.1695694178342819e-01
    z[4,3,4]  R2188     2.9780622571706772e-02
    z[4,3,4]  R2189     -0.113673135638237
    z[4,3,4]  R2190     9.4564080238342285e-02
    z[4,3,4]  R2191     -2.2984115406870842e-02
    z[4,3,4]  R2192     1.2909808754920959e-01
    z[4,3,4]  R2193     -1.5918545424938202e-01
    z[4,3,4]  R2194     -1.1347037553787231e-01
    z[4,3,4]  R2195     -1.8654270470142365e-01
    z[4,3,4]  R2196     1.5339119732379913e-01
    z[4,3,4]  R2197     -8.2135021686553955e-02
    z[4,3,4]  R2198     8.2185156643390656e-02
    z[4,3,4]  R2199     -1.1228418350219727e-01
    z[4,3,4]  R2200     2.6528099179267883e-01
    z[4,3,4]  R2201     -4.2539444565773010e-01
    z[4,3,4]  R2202     9.4021543860435486e-02
    z[4,3,4]  R2203     -4.5273822546005249e-01
    z[4,3,4]  R2204     -0.379819393157959
    z[4,3,4]  R2205     -6.5339556895196438e-03
    z[4,3,4]  R2206     1.4562240242958069e-01
    z[4,3,4]  R2207     4.8759466409683228e-01
    z[4,3,4]  R2208     -5.0998383760452271e-01
    z[4,3,4]  R2209     2.5875428691506386e-02
    z[4,3,4]  R2210     -2.5735804438591003e-01
    z[4,3,4]  R2211     -7.9946219921112061e-04
    z[4,3,4]  R2212     8.2271791994571686e-02
    z[4,3,4]  R2213     -3.4042972326278687e-01
    z[4,3,4]  R2214     3.3132830262184143e-01
    z[4,3,4]  R2215     2.3930130898952484e-01
    z[4,3,4]  R2216     3.3419987559318542e-01
    z[4,3,4]  R2217     1.1739798635244370e-01
    z[4,3,4]  R2218     5.4334950447082520e-01
    z[4,3,4]  R2219     2.1896690130233765e-01
    z[4,3,4]  R2220     5.0954711437225342e-01
    z[4,3,4]  R2221     -2.7300122380256653e-01
    z[4,3,4]  R2222     1.1436348408460617e-01
    z[4,3,4]  R2223     -6.5126776695251465e-02
    z[4,3,4]  R2224     3.4790221601724625e-02
    z[4,3,4]  R2225     -1.4352890849113464e-01
    z[4,3,4]  R2226     1.5856587886810303e-01
    z[4,3,4]  R2227     -0.129226416349411
    z[4,3,4]  R2228     2.1101680397987366e-01
    z[4,3,4]  R2229     2.0117874443531036e-01
    z[4,3,4]  R2230     -3.3486044406890869e-01
    z[4,3,4]  R2231     -1.0937442071735859e-02
    z[4,3,4]  R2232     -1.2377080321311951e-01
    z[4,3,4]  R2233     -5.8204419910907745e-02
    z[4,3,4]  R2234     -7.0177665911614895e-03
    z[4,3,4]  R2235     -1.3035634160041809e-01
    z[4,3,4]  R2236     -1.9441822543740273e-02
    z[4,3,4]  R2237     -9.7734019160270691e-02
    z[4,3,4]  R2238     2.4935714900493622e-01
    z[4,3,4]  R2239     1.0530297458171844e-01
    z[4,3,4]  R2240     1.9780211150646210e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R2172     -1
    z[4,3,5]  R2173     1
    z[4,3,5]  R2176     -1.1757581681013107e-01
    z[4,3,5]  R2177     -6.0707405209541321e-02
    z[4,3,5]  R2178     6.5165506675839424e-03
    z[4,3,5]  R2179     -3.0680984258651733e-01
    z[4,3,5]  R2180     1.6882508993148804e-01
    z[4,3,5]  R2181     -4.3570473790168762e-01
    z[4,3,5]  R2182     2.8054052591323853e-01
    z[4,3,5]  R2183     -3.7503218650817871e-01
    z[4,3,5]  R2184     4.0232893824577332e-01
    z[4,3,5]  R2185     8.7758600711822510e-02
    z[4,3,5]  R2186     -2.8529292345046997e-01
    z[4,3,5]  R2187     -1.2879328429698944e-01
    z[4,3,5]  R2188     3.3906564116477966e-01
    z[4,3,5]  R2189     1.3632264733314514e-01
    z[4,3,5]  R2190     1.3902534544467926e-01
    z[4,3,5]  R2191     1.9321456551551819e-01
    z[4,3,5]  R2192     1.4572256803512573e-01
    z[4,3,5]  R2193     3.3065313100814819e-01
    z[4,3,5]  R2194     3.3350548148155212e-01
    z[4,3,5]  R2195     2.5434008240699768e-01
    z[4,3,5]  R2196     0.0653185248374939
    z[4,3,5]  R2197     6.4751470088958740e-01
    z[4,3,5]  R2198     -2.3476819694042206e-01
    z[4,3,5]  R2199     4.9129912257194519e-01
    z[4,3,5]  R2200     3.8730046153068542e-01
    z[4,3,5]  R2201     2.4547970294952393e-01
    z[4,3,5]  R2202     -4.3531551957130432e-01
    z[4,3,5]  R2203     2.4686281383037567e-01
    z[4,3,5]  R2204     5.7919424027204514e-02
    z[4,3,5]  R2205     -2.5043833255767822e-01
    z[4,3,5]  R2206     3.2815396785736084e-01
    z[4,3,5]  R2207     5.5406481027603149e-02
    z[4,3,5]  R2208     3.8574171066284180e-01
    z[4,3,5]  R2209     4.4239467382431030e-01
    z[4,3,5]  R2210     -2.3063258826732635e-01
    z[4,3,5]  R2211     -1.5647193789482117e-01
    z[4,3,5]  R2212     2.8870645165443420e-01
    z[4,3,5]  R2213     -2.7284887433052063e-01
    z[4,3,5]  R2214     -5.2633565664291382e-01
    z[4,3,5]  R2215     -0.297408789396286
    z[4,3,5]  R2216     1.8562559783458710e-01
    z[4,3,5]  R2217     4.2010764591395855e-03
    z[4,3,5]  R2218     -8.6681410670280457e-02
    z[4,3,5]  R2219     9.7037024796009064e-02
    z[4,3,5]  R2220     -7.6643405482172966e-03
    z[4,3,5]  R2221     1.8124409019947052e-01
    z[4,3,5]  R2222     3.4569692611694336e-01
    z[4,3,5]  R2223     3.8990718126296997e-01
    z[4,3,5]  R2224     -1.4692430198192596e-01
    z[4,3,5]  R2225     -4.0169146656990051e-01
    z[4,3,5]  R2226     -2.1082855761051178e-01
    z[4,3,5]  R2227     -5.7908255606889725e-02
    z[4,3,5]  R2228     -2.6901489496231079e-01
    z[4,3,5]  R2229     -1.2342879176139832e-01
    z[4,3,5]  R2230     -1.8436795473098755e-01
    z[4,3,5]  R2231     -1.7887786030769348e-01
    z[4,3,5]  R2232     8.9686758816242218e-02
    z[4,3,5]  R2233     -1.9222494959831238e-01
    z[4,3,5]  R2234     -4.6440163254737854e-01
    z[4,3,5]  R2235     -1.4157579839229584e-01
    z[4,3,5]  R2236     2.7153030037879944e-01
    z[4,3,5]  R2237     5.4672157764434814e-01
    z[4,3,5]  R2238     2.2526112198829651e-01
    z[4,3,5]  R2239     -3.9854088425636292e-01
    z[4,3,5]  R2240     2.8633320331573486e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R2174     -1
    z[4,3,6]  R2175     1
    z[4,3,6]  R2176     -1.5190209448337555e-01
    z[4,3,6]  R2177     -0.163969486951828
    z[4,3,6]  R2178     -3.9161231368780136e-02
    z[4,3,6]  R2179     -4.0611866116523743e-01
    z[4,3,6]  R2180     -4.7003483772277832e-01
    z[4,3,6]  R2181     -2.0241707563400269e-02
    z[4,3,6]  R2182     -6.9713217020034790e-01
    z[4,3,6]  R2183     0.232675239443779
    z[4,3,6]  R2184     4.9797871708869934e-01
    z[4,3,6]  R2185     5.3369772434234619e-01
    z[4,3,6]  R2186     -3.7772583961486816e-01
    z[4,3,6]  R2187     -6.6972541809082031e-01
    z[4,3,6]  R2188     -2.3642625659704208e-02
    z[4,3,6]  R2189     8.2296334207057953e-02
    z[4,3,6]  R2190     8.4611341357231140e-02
    z[4,3,6]  R2191     2.0963713526725769e-01
    z[4,3,6]  R2192     7.9340517520904541e-02
    z[4,3,6]  R2193     2.8665328025817871e-01
    z[4,3,6]  R2194     2.7062943577766418e-01
    z[4,3,6]  R2195     -0.0859035924077034
    z[4,3,6]  R2196     -0.061029102653265
    z[4,3,6]  R2197     -1.0491538792848587e-01
    z[4,3,6]  R2198     3.1203892827033997e-01
    z[4,3,6]  R2199     -2.1331250667572021e-01
    z[4,3,6]  R2200     -6.7336338758468628e-01
    z[4,3,6]  R2201     -4.6480432152748108e-02
    z[4,3,6]  R2202     -5.9714134782552719e-02
    z[4,3,6]  R2203     3.8336774706840515e-01
    z[4,3,6]  R2204     8.4399670362472534e-02
    z[4,3,6]  R2205     2.8108218312263489e-01
    z[4,3,6]  R2206     4.1452851891517639e-01
    z[4,3,6]  R2207     -2.2867612540721893e-01
    z[4,3,6]  R2208     -3.4304666519165039e-01
    z[4,3,6]  R2209     -1.9419296085834503e-01
    z[4,3,6]  R2210     -5.6261980533599854e-01
    z[4,3,6]  R2211     -6.5677899122238159e-01
    z[4,3,6]  R2212     5.5055910348892212e-01
    z[4,3,6]  R2213     -4.8196125775575638e-02
    z[4,3,6]  R2214     3.1478923559188843e-01
    z[4,3,6]  R2215     4.2554289102554321e-01
    z[4,3,6]  R2216     -2.0609997212886810e-01
    z[4,3,6]  R2217     1.0976740717887878e-01
    z[4,3,6]  R2218     -2.0024146139621735e-01
    z[4,3,6]  R2219     1.7138667404651642e-02
    z[4,3,6]  R2220     1.4539824426174164e-01
    z[4,3,6]  R2221     -1.9080650061368942e-02
    z[4,3,6]  R2222     -3.4737512469291687e-02
    z[4,3,6]  R2223     -9.4156764447689056e-02
    z[4,3,6]  R2224     -8.4076039493083954e-02
    z[4,3,6]  R2225     4.7083523124456406e-02
    z[4,3,6]  R2226     3.0754547566175461e-02
    z[4,3,6]  R2227     1.2262330204248428e-01
    z[4,3,6]  R2228     -8.0017736181616783e-03
    z[4,3,6]  R2229     1.6017764806747437e-01
    z[4,3,6]  R2230     -0.129512757062912
    z[4,3,6]  R2231     -3.3758670091629028e-01
    z[4,3,6]  R2232     8.1064760684967041e-02
    z[4,3,6]  R2233     -3.6736443638801575e-01
    z[4,3,6]  R2234     -3.8917452096939087e-01
    z[4,3,6]  R2235     -0.1804189234972
    z[4,3,6]  R2236     2.7841767668724060e-01
    z[4,3,6]  R2237     1.7514521256089211e-02
    z[4,3,6]  R2238     -1.7323812842369080e-01
    z[4,3,6]  R2239     -0.185040682554245
    z[4,3,6]  R2240     5.1151943206787109e-01
    z[3,5,0]  R29       -1
    z[3,5,0]  R47       1
    z[3,5,0]  R2241     -1
    z[3,5,0]  R2242     1
    z[3,5,0]  R2255     1.8530371785163879e-01
    z[3,5,0]  R2256     -2.5193458795547485e-01
    z[3,5,0]  R2257     -5.6188285350799561e-01
    z[3,5,0]  R2258     1.5947241336107254e-02
    z[3,5,0]  R2259     2.9958420991897583e-01
    z[3,5,0]  R2260     0.526293158531189
    z[3,5,0]  R2261     -5.1610004901885986e-01
    z[3,5,0]  R2262     -3.3037957549095154e-01
    z[3,5,0]  R2263     3.0317434668540955e-01
    z[3,5,0]  R2264     3.3268904685974121e-01
    z[3,5,0]  R2265     0.154024139046669
    z[3,5,0]  R2266     3.9366778731346130e-01
    z[3,5,0]  R2267     4.0054762363433838e-01
    z[3,5,0]  R2268     3.4238618612289429e-01
    z[3,5,0]  R2269     5.7106947898864746e-01
    z[3,5,0]  R2270     5.3418982028961182e-01
    z[3,5,0]  R2271     6.4118576049804688e-01
    z[3,5,0]  R2272     7.8070056438446045e-01
    z[3,5,0]  R2273     3.5703986883163452e-01
    z[3,5,0]  R2274     -1.4922395348548889e-01
    z[3,5,0]  R2275     3.4297034144401550e-01
    z[3,5,0]  R2276     6.8746519088745117e-01
    z[3,5,0]  R2277     5.9731644392013550e-01
    z[3,5,0]  R2278     0.451546847820282
    z[3,5,0]  R2279     3.8975724577903748e-01
    z[3,5,0]  R2280     5.2762645483016968e-01
    z[3,5,0]  R2281     0.359191358089447
    z[3,5,0]  R2282     3.3647558093070984e-01
    z[3,5,0]  R2283     4.7783535718917847e-01
    z[3,5,0]  R2284     5.2259588241577148e-01
    z[3,5,0]  R2285     5.2622985839843750e-01
    z[3,5,0]  R2286     -3.9881786704063416e-01
    z[3,5,0]  R2287     -2.2276766598224640e-01
    z[3,5,0]  R2288     -3.8694933056831360e-01
    z[3,5,0]  R2289     -1.8728250265121460e-01
    z[3,5,0]  R2290     -6.7813791334629059e-02
    z[3,5,0]  R2291     9.1751128435134888e-02
    z[3,5,0]  R2292     -2.9391407966613770e-01
    z[3,5,0]  R2293     3.5134589672088623e-01
    z[3,5,0]  R2294     1.8095086514949799e-01
    z[3,5,0]  R2295     4.5932576060295105e-02
    z[3,5,0]  R2296     0.0817050188779831
    z[3,5,0]  R2297     1.5777802467346191e-01
    z[3,5,0]  R2298     -2.8450459241867065e-01
    z[3,5,0]  R2299     -2.5793009996414185e-01
    z[3,5,0]  R2300     2.9511460661888123e-01
    z[3,5,0]  R2301     -8.0357983708381653e-02
    z[3,5,0]  R2302     -2.6397609710693359e-01
    z[3,5,0]  R2303     -7.9158611595630646e-02
    z[3,5,0]  R2304     -1.3939459621906281e-01
    z[3,5,0]  R2305     3.3405673503875732e-01
    z[3,5,0]  R2306     -3.1011231243610382e-02
    z[3,5,0]  R2307     -2.3243987560272217e-01
    z[3,5,0]  R2308     6.5164053812623024e-03
    z[3,5,0]  R2309     -1.2624450027942657e-01
    z[3,5,0]  R2310     3.0309295654296875e-01
    z[3,5,0]  R2311     -6.2123370170593262e-01
    z[3,5,0]  R2312     -1.2315837293863297e-01
    z[3,5,0]  R2313     -7.4878519773483276e-01
    z[3,5,0]  R2314     1.7647108435630798e-01
    z[3,5,0]  R2315     -7.7983301877975464e-01
    z[3,5,0]  R2316     -4.7811153531074524e-01
    z[3,5,0]  R2317     -3.9945331215858459e-01
    z[3,5,0]  R2318     -7.3482406139373779e-01
    z[3,5,0]  R2319     -5.1747697591781616e-01
    z[3,5,0]  R2320     -5.3739684820175171e-01
    z[3,5,0]  R2321     5.9888356924057007e-01
    z[3,5,0]  R2322     1.9250044226646423e-01
    z[3,5,0]  R2323     3.4843954443931580e-01
    z[3,5,0]  R2324     -1.4973483979701996e-01
    z[3,5,0]  R2325     5.2489286661148071e-01
    z[3,5,0]  R2326     7.5461953878402710e-01
    z[3,5,0]  R2327     6.6458392143249512e-01
    z[3,5,0]  R2328     -2.1477121859788895e-02
    z[3,5,0]  R2329     0.493700236082077
    z[3,5,0]  R2330     5.5405634641647339e-01
    z[3,5,0]  R2331     -3.0755949020385742e-01
    z[3,5,0]  R2332     5.7791608572006226e-01
    z[3,5,0]  R2333     3.1935986876487732e-01
    z[3,5,0]  R2334     -5.7855671644210815e-01
    z[3,5,0]  R2335     2.0953913033008575e-01
    z[3,5,0]  R2336     2.7045177295804024e-02
    z[3,5,0]  R2337     1.8525169789791107e-01
    z[3,5,0]  R2338     7.2206068038940430e-01
    z[3,5,0]  R2339     0.537449300289154
    z[3,5,0]  R2340     7.2452224791049957e-02
    z[3,5,1]  R30       -1
    z[3,5,1]  R48       1
    z[3,5,1]  R2243     -1
    z[3,5,1]  R2244     1
    z[3,5,1]  R2255     -8.6314660310745239e-01
    z[3,5,1]  R2256     -0.620816707611084
    z[3,5,1]  R2257     -5.4310923814773560e-01
    z[3,5,1]  R2258     -4.0189677476882935e-01
    z[3,5,1]  R2259     -4.8578220605850220e-01
    z[3,5,1]  R2260     -2.4732129275798798e-01
    z[3,5,1]  R2261     0.180352121591568
    z[3,5,1]  R2262     3.7351536750793457e-01
    z[3,5,1]  R2263     4.2863461375236511e-01
    z[3,5,1]  R2264     0.567589521408081
    z[3,5,1]  R2265     4.7279828786849976e-01
    z[3,5,1]  R2266     6.7619991302490234e-01
    z[3,5,1]  R2267     6.0610163211822510e-01
    z[3,5,1]  R2268     5.5915105342864990e-01
    z[3,5,1]  R2269     4.4078534841537476e-01
    z[3,5,1]  R2270     4.1569101810455322e-01
    z[3,5,1]  R2271     4.3550312519073486e-01
    z[3,5,1]  R2272     4.0601298213005066e-01
    z[3,5,1]  R2273     7.6938372850418091e-01
    z[3,5,1]  R2274     7.6927435398101807e-01
    z[3,5,1]  R2275     6.8489295244216919e-01
    z[3,5,1]  R2276     0.523723304271698
    z[3,5,1]  R2277     5.9777599573135376e-01
    z[3,5,1]  R2278     5.7301956415176392e-01
    z[3,5,1]  R2279     6.8097829818725586e-01
    z[3,5,1]  R2280     6.5009635686874390e-01
    z[3,5,1]  R2281     0.77623051404953
    z[3,5,1]  R2282     0.825904130935669
    z[3,5,1]  R2283     5.0051957368850708e-01
    z[3,5,1]  R2284     4.6122789382934570e-01
    z[3,5,1]  R2285     0.753503680229187
    z[3,5,1]  R2286     6.0441082715988159e-01
    z[3,5,1]  R2287     6.9407802820205688e-01
    z[3,5,1]  R2288     7.0124787092208862e-01
    z[3,5,1]  R2289     6.6254991292953491e-01
    z[3,5,1]  R2290     4.9700316786766052e-01
    z[3,5,1]  R2291     8.7547320127487183e-01
    z[3,5,1]  R2292     8.5558646917343140e-01
    z[3,5,1]  R2293     7.4692708253860474e-01
    z[3,5,1]  R2294     7.0906698703765869e-01
    z[3,5,1]  R2295     6.2525153160095215e-01
    z[3,5,1]  R2296     6.2553548812866211e-01
    z[3,5,1]  R2297     4.2846208810806274e-01
    z[3,5,1]  R2298     6.0804325342178345e-01
    z[3,5,1]  R2299     2.9897719621658325e-01
    z[3,5,1]  R2300     6.6439443826675415e-01
    z[3,5,1]  R2301     -9.2065292596817017e-01
    z[3,5,1]  R2302     -9.4883036613464355e-01
    z[3,5,1]  R2303     -8.4418761730194092e-01
    z[3,5,1]  R2304     -8.5557991266250610e-01
    z[3,5,1]  R2305     -8.8591217994689941e-01
    z[3,5,1]  R2306     -8.5599416494369507e-01
    z[3,5,1]  R2307     -0.837941586971283
    z[3,5,1]  R2308     -8.3161729574203491e-01
    z[3,5,1]  R2309     -8.2682949304580688e-01
    z[3,5,1]  R2310     -8.9267814159393311e-01
    z[3,5,1]  R2311     -9.1890551149845123e-02
    z[3,5,1]  R2312     -1.7950126528739929e-01
    z[3,5,1]  R2313     3.0340716242790222e-01
    z[3,5,1]  R2314     2.9247373342514038e-01
    z[3,5,1]  R2315     1.9021998345851898e-01
    z[3,5,1]  R2316     2.6451054215431213e-01
    z[3,5,1]  R2317     1.7234939336776733e-01
    z[3,5,1]  R2318     4.5606139302253723e-01
    z[3,5,1]  R2319     3.7726444005966187e-01
    z[3,5,1]  R2320     -2.4689415469765663e-02
    z[3,5,1]  R2321     -1.1694305390119553e-01
    z[3,5,1]  R2322     -6.3666746020317078e-02
    z[3,5,1]  R2323     -5.9154576063156128e-01
    z[3,5,1]  R2324     7.1902751922607422e-02
    z[3,5,1]  R2325     -5.9003078937530518e-01
    z[3,5,1]  R2326     -5.4779714345932007e-01
    z[3,5,1]  R2327     -5.7059872150421143e-01
    z[3,5,1]  R2328     -6.3786470890045166e-01
    z[3,5,1]  R2329     -6.7252731323242188e-01
    z[3,5,1]  R2330     -6.6398131847381592e-01
    z[3,5,1]  R2331     4.1244527697563171e-01
    z[3,5,1]  R2332     2.9022064805030823e-01
    z[3,5,1]  R2333     0.279297411441803
    z[3,5,1]  R2334     -0.230604350566864
    z[3,5,1]  R2335     1.7475579679012299e-01
    z[3,5,1]  R2336     8.5760280489921570e-02
    z[3,5,1]  R2337     -3.2181721925735474e-01
    z[3,5,1]  R2338     -2.1566207706928253e-01
    z[3,5,1]  R2339     -3.5702559351921082e-01
    z[3,5,1]  R2340     -6.3930189609527588e-01
    z[3,5,2]  R31       -1
    z[3,5,2]  R49       1
    z[3,5,2]  R2245     -1
    z[3,5,2]  R2246     1
    z[3,5,2]  R2255     2.2956785559654236e-01
    z[3,5,2]  R2256     4.2582547664642334e-01
    z[3,5,2]  R2257     -1.6568163037300110e-01
    z[3,5,2]  R2258     5.4286289215087891e-01
    z[3,5,2]  R2259     -5.3863358497619629e-01
    z[3,5,2]  R2260     -3.8546475768089294e-01
    z[3,5,2]  R2261     4.0814954042434692e-01
    z[3,5,2]  R2262     -4.4135829806327820e-01
    z[3,5,2]  R2263     3.7516161799430847e-01
    z[3,5,2]  R2264     2.8477218747138977e-01
    z[3,5,2]  R2265     -2.2615494672209024e-03
    z[3,5,2]  R2266     3.3404495567083359e-02
    z[3,5,2]  R2267     -4.4436094164848328e-01
    z[3,5,2]  R2268     0.0140988202765584
    z[3,5,2]  R2269     4.9933022260665894e-01
    z[3,5,2]  R2270     -1.5091960132122040e-01
    z[3,5,2]  R2271     -3.3889949321746826e-01
    z[3,5,2]  R2272     2.6863566040992737e-01
    z[3,5,2]  R2273     -2.5784516334533691e-01
    z[3,5,2]  R2274     1.3406106829643250e-01
    z[3,5,2]  R2275     -6.1934594996273518e-03
    z[3,5,2]  R2276     3.0340753495693207e-02
    z[3,5,2]  R2277     -2.0380338653922081e-02
    z[3,5,2]  R2278     1.6603243350982666e-01
    z[3,5,2]  R2279     -1.2298868969082832e-02
    z[3,5,2]  R2280     1.7190766334533691e-01
    z[3,5,2]  R2281     1.2203613668680191e-01
    z[3,5,2]  R2282     1.2268714606761932e-01
    z[3,5,2]  R2283     2.8339171409606934e-01
    z[3,5,2]  R2284     2.9617032408714294e-01
    z[3,5,2]  R2285     -1.5018188953399658e-01
    z[3,5,2]  R2286     4.4502297043800354e-01
    z[3,5,2]  R2287     2.9261613264679909e-02
    z[3,5,2]  R2288     -3.6792778968811035e-01
    z[3,5,2]  R2289     -2.3362116515636444e-01
    z[3,5,2]  R2290     -3.2235378026962280e-01
    z[3,5,2]  R2291     2.2204430401325226e-01
    z[3,5,2]  R2292     -6.9286718964576721e-02
    z[3,5,2]  R2293     1.0267228819429874e-02
    z[3,5,2]  R2294     -3.1002461910247803e-02
    z[3,5,2]  R2295     1.0819110274314880e-01
    z[3,5,2]  R2296     -3.7111940979957581e-01
    z[3,5,2]  R2297     7.5985920429229736e-01
    z[3,5,2]  R2298     -2.4186022579669952e-01
    z[3,5,2]  R2299     7.5410521030426025e-01
    z[3,5,2]  R2300     -4.7407627105712891e-01
    z[3,5,2]  R2301     2.6614934206008911e-01
    z[3,5,2]  R2302     -4.7693509608507156e-02
    z[3,5,2]  R2303     2.5060348212718964e-02
    z[3,5,2]  R2304     -2.1321940422058105e-01
    z[3,5,2]  R2305     0.201337531208992
    z[3,5,2]  R2306     -2.9549381136894226e-01
    z[3,5,2]  R2307     -1.6530798375606537e-01
    z[3,5,2]  R2308     0.0824781134724617
    z[3,5,2]  R2309     -6.8636782467365265e-02
    z[3,5,2]  R2310     1.6016195714473724e-01
    z[3,5,2]  R2311     -4.8945721983909607e-01
    z[3,5,2]  R2312     5.1430130004882812e-01
    z[3,5,2]  R2313     3.4037387371063232e-01
    z[3,5,2]  R2314     -8.9806658029556274e-01
    z[3,5,2]  R2315     -0.0916375145316124
    z[3,5,2]  R2316     3.0163705348968506e-02
    z[3,5,2]  R2317     -4.7916686534881592e-01
    z[3,5,2]  R2318     -1.5109807252883911e-01
    z[3,5,2]  R2319     -3.7307778000831604e-01
    z[3,5,2]  R2320     -9.4032082706689835e-03
    z[3,5,2]  R2321     8.0027438700199127e-02
    z[3,5,2]  R2322     -5.8725923299789429e-02
    z[3,5,2]  R2323     1.0964184254407883e-01
    z[3,5,2]  R2324     -7.3334950208663940e-01
    z[3,5,2]  R2325     4.0528017282485962e-01
    z[3,5,2]  R2326     0.284252792596817
    z[3,5,2]  R2327     3.6815294623374939e-01
    z[3,5,2]  R2328     1.5899296104907990e-01
    z[3,5,2]  R2329     4.2180046439170837e-01
    z[3,5,2]  R2330     4.2704778909683228e-01
    z[3,5,2]  R2331     -5.3261661529541016e-01
    z[3,5,2]  R2332     -4.9754548072814941e-01
    z[3,5,2]  R2333     4.1682365536689758e-01
    z[3,5,2]  R2334     -9.4092383980751038e-02
    z[3,5,2]  R2335     6.6872701048851013e-02
    z[3,5,2]  R2336     5.3215879201889038e-01
    z[3,5,2]  R2337     4.9683311581611633e-01
    z[3,5,2]  R2338     4.9082070589065552e-01
    z[3,5,2]  R2339     6.5681940317153931e-01
    z[3,5,2]  R2340     6.7451059818267822e-01
    z[3,5,3]  R32       -1
    z[3,5,3]  R50       1
    z[3,5,3]  R2247     -1
    z[3,5,3]  R2248     1
    z[3,5,3]  R2255     -1.6177067160606384e-01
    z[3,5,3]  R2256     -2.6279929280281067e-01
    z[3,5,3]  R2257     -2.6221841573715210e-01
    z[3,5,3]  R2258     1.3024370372295380e-01
    z[3,5,3]  R2259     -3.8735681772232056e-01
    z[3,5,3]  R2260     -2.7802714705467224e-01
    z[3,5,3]  R2261     -2.8050836920738220e-01
    z[3,5,3]  R2262     -4.0410766005516052e-01
    z[3,5,3]  R2263     6.2525969743728638e-01
    z[3,5,3]  R2264     1.2843927368521690e-02
    z[3,5,3]  R2265     -6.5263265371322632e-01
    z[3,5,3]  R2266     4.4501677155494690e-01
    z[3,5,3]  R2267     4.9889558553695679e-01
    z[3,5,3]  R2268     4.7653332352638245e-01
    z[3,5,3]  R2269     4.1545253992080688e-01
    z[3,5,3]  R2270     4.8808595538139343e-01
    z[3,5,3]  R2271     4.2026409506797791e-01
    z[3,5,3]  R2272     1.4036716520786285e-01
    z[3,5,3]  R2273     2.2125220298767090e-01
    z[3,5,3]  R2274     5.8147305250167847e-01
    z[3,5,3]  R2275     4.7862425446510315e-01
    z[3,5,3]  R2276     4.2620095610618591e-01
    z[3,5,3]  R2277     5.0037211179733276e-01
    z[3,5,3]  R2278     5.6852996349334717e-01
    z[3,5,3]  R2279     5.5031090974807739e-01
    z[3,5,3]  R2280     3.2639884948730469e-01
    z[3,5,3]  R2281     3.2783108949661255e-01
    z[3,5,3]  R2282     3.9959990978240967e-01
    z[3,5,3]  R2283     5.1531338691711426e-01
    z[3,5,3]  R2284     2.4345543980598450e-01
    z[3,5,3]  R2285     2.5134083628654480e-01
    z[3,5,3]  R2286     3.5491314530372620e-01
    z[3,5,3]  R2287     3.9876180887222290e-01
    z[3,5,3]  R2288     2.8322747349739075e-01
    z[3,5,3]  R2289     5.1692402362823486e-01
    z[3,5,3]  R2290     5.1157861948013306e-01
    z[3,5,3]  R2291     -1.7188473045825958e-01
    z[3,5,3]  R2292     1.8126615881919861e-01
    z[3,5,3]  R2293     4.3439182639122009e-01
    z[3,5,3]  R2294     -1.2478467077016830e-01
    z[3,5,3]  R2295     1.9832178950309753e-01
    z[3,5,3]  R2296     4.3204563856124878e-01
    z[3,5,3]  R2297     1.1489140801131725e-02
    z[3,5,3]  R2298     -4.0967710316181183e-02
    z[3,5,3]  R2299     4.8574271798133850e-01
    z[3,5,3]  R2300     -4.3506991118192673e-02
    z[3,5,3]  R2301     -4.6891830861568451e-02
    z[3,5,3]  R2302     -2.8363440185785294e-02
    z[3,5,3]  R2303     1.3611934147775173e-02
    z[3,5,3]  R2304     -0.0231669619679451
    z[3,5,3]  R2305     2.2896258533000946e-01
    z[3,5,3]  R2306     3.4761503338813782e-01
    z[3,5,3]  R2307     2.6514670252799988e-01
    z[3,5,3]  R2308     1.0575447231531143e-01
    z[3,5,3]  R2309     4.9875143170356750e-01
    z[3,5,3]  R2310     7.5762018561363220e-02
    z[3,5,3]  R2311     -2.3659074306488037e-01
    z[3,5,3]  R2312     -2.6496499776840210e-01
    z[3,5,3]  R2313     -1.8247883021831512e-01
    z[3,5,3]  R2314     -2.2330953180789948e-01
    z[3,5,3]  R2315     -1.5001441538333893e-01
    z[3,5,3]  R2316     -4.4930616021156311e-01
    z[3,5,3]  R2317     -2.6776903867721558e-01
    z[3,5,3]  R2318     9.8131135106086731e-02
    z[3,5,3]  R2319     -2.6228803396224976e-01
    z[3,5,3]  R2320     -1.6434629261493683e-01
    z[3,5,3]  R2321     -6.9557195901870728e-01
    z[3,5,3]  R2322     -0.846520185470581
    z[3,5,3]  R2323     -4.7702023386955261e-01
    z[3,5,3]  R2324     -4.8704613000154495e-02
    z[3,5,3]  R2325     -1.0013290494680405e-01
    z[3,5,3]  R2326     -9.7566343843936920e-02
    z[3,5,3]  R2327     -8.4781445562839508e-02
    z[3,5,3]  R2328     -0.349507600069046
    z[3,5,3]  R2329     -4.1402030736207962e-02
    z[3,5,3]  R2330     1.7861567437648773e-01
    z[3,5,3]  R2331     -4.2533260583877563e-01
    z[3,5,3]  R2332     -2.0311589539051056e-01
    z[3,5,3]  R2333     -2.9586234688758850e-01
    z[3,5,3]  R2334     1.5119914710521698e-01
    z[3,5,3]  R2335     -4.7901135683059692e-01
    z[3,5,3]  R2336     -7.7033668756484985e-01
    z[3,5,3]  R2337     -5.8633148670196533e-01
    z[3,5,3]  R2338     -2.6660934090614319e-01
    z[3,5,3]  R2339     1.6089810431003571e-01
    z[3,5,3]  R2340     3.4706801176071167e-01
    z[3,5,4]  R33       -1
    z[3,5,4]  R51       1
    z[3,5,4]  R2249     -1
    z[3,5,4]  R2250     1
    z[3,5,4]  R2255     -6.5339556895196438e-03
    z[3,5,4]  R2256     1.4562240242958069e-01
    z[3,5,4]  R2257     4.8759466409683228e-01
    z[3,5,4]  R2258     -5.0998383760452271e-01
    z[3,5,4]  R2259     2.5875428691506386e-02
    z[3,5,4]  R2260     -2.5735804438591003e-01
    z[3,5,4]  R2261     -7.9946219921112061e-04
    z[3,5,4]  R2262     8.2271791994571686e-02
    z[3,5,4]  R2263     -3.4042972326278687e-01
    z[3,5,4]  R2264     3.3132830262184143e-01
    z[3,5,4]  R2265     2.3930130898952484e-01
    z[3,5,4]  R2266     3.3419987559318542e-01
    z[3,5,4]  R2267     1.1739798635244370e-01
    z[3,5,4]  R2268     5.4334950447082520e-01
    z[3,5,4]  R2269     2.1896690130233765e-01
    z[3,5,4]  R2270     5.0954711437225342e-01
    z[3,5,4]  R2271     -2.7300122380256653e-01
    z[3,5,4]  R2272     1.1436348408460617e-01
    z[3,5,4]  R2273     -6.5126776695251465e-02
    z[3,5,4]  R2274     3.4790221601724625e-02
    z[3,5,4]  R2275     -1.4352890849113464e-01
    z[3,5,4]  R2276     1.5856587886810303e-01
    z[3,5,4]  R2277     -0.129226416349411
    z[3,5,4]  R2278     2.1101680397987366e-01
    z[3,5,4]  R2279     2.0117874443531036e-01
    z[3,5,4]  R2280     -3.3486044406890869e-01
    z[3,5,4]  R2281     -1.0937442071735859e-02
    z[3,5,4]  R2282     -1.2377080321311951e-01
    z[3,5,4]  R2283     -5.8204419910907745e-02
    z[3,5,4]  R2284     -7.0177665911614895e-03
    z[3,5,4]  R2285     -1.3035634160041809e-01
    z[3,5,4]  R2286     -1.9441822543740273e-02
    z[3,5,4]  R2287     -9.7734019160270691e-02
    z[3,5,4]  R2288     2.4935714900493622e-01
    z[3,5,4]  R2289     1.0530297458171844e-01
    z[3,5,4]  R2290     1.9780211150646210e-01
    z[3,5,4]  R2291     2.3010133206844330e-01
    z[3,5,4]  R2292     3.4058505296707153e-01
    z[3,5,4]  R2293     1.6457255184650421e-01
    z[3,5,4]  R2294     1.1215513199567795e-01
    z[3,5,4]  R2295     2.1339850500226021e-03
    z[3,5,4]  R2296     2.0488698035478592e-02
    z[3,5,4]  R2297     1.5322379767894745e-02
    z[3,5,4]  R2298     6.2139028310775757e-01
    z[3,5,4]  R2299     4.9387805163860321e-02
    z[3,5,4]  R2300     1.4650250971317291e-01
    z[3,5,4]  R2301     -1.3256011903285980e-01
    z[3,5,4]  R2302     3.7601027637720108e-02
    z[3,5,4]  R2303     -3.1871777772903442e-01
    z[3,5,4]  R2304     2.6871031522750854e-01
    z[3,5,4]  R2305     4.8271864652633667e-02
    z[3,5,4]  R2306     2.1161170303821564e-01
    z[3,5,4]  R2307     -3.2673040404915810e-03
    z[3,5,4]  R2308     0.360588401556015
    z[3,5,4]  R2309     0.0846773162484169
    z[3,5,4]  R2310     0.078289695084095
    z[3,5,4]  R2311     -2.1471163630485535e-01
    z[3,5,4]  R2312     4.7779548168182373e-01
    z[3,5,4]  R2313     -1.5561152994632721e-01
    z[3,5,4]  R2314     6.5029174089431763e-02
    z[3,5,4]  R2315     -5.4568547010421753e-01
    z[3,5,4]  R2316     -2.0039555430412292e-01
    z[3,5,4]  R2317     -6.9484390318393707e-02
    z[3,5,4]  R2318     -3.6225995421409607e-01
    z[3,5,4]  R2319     -3.3178317546844482e-01
    z[3,5,4]  R2320     -4.5058351755142212e-01
    z[3,5,4]  R2321     -1.4191937446594238e-01
    z[3,5,4]  R2322     -3.5129639506340027e-01
    z[3,5,4]  R2323     -2.0226357877254486e-01
    z[3,5,4]  R2324     -1.7484459280967712e-01
    z[3,5,4]  R2325     -2.4712309241294861e-01
    z[3,5,4]  R2326     -1.8820452690124512e-01
    z[3,5,4]  R2327     -7.1713291108608246e-02
    z[3,5,4]  R2328     -3.2527527213096619e-01
    z[3,5,4]  R2329     -3.5218662023544312e-01
    z[3,5,4]  R2330     0.144295796751976
    z[3,5,4]  R2331     -3.9359182119369507e-01
    z[3,5,4]  R2332     5.1760542392730713e-01
    z[3,5,4]  R2333     6.9337749481201172e-01
    z[3,5,4]  R2334     3.5283794999122620e-01
    z[3,5,4]  R2335     5.1066315174102783e-01
    z[3,5,4]  R2336     -2.9012659192085266e-01
    z[3,5,4]  R2337     -1.2565696239471436e-01
    z[3,5,4]  R2338     -2.2074703872203827e-01
    z[3,5,4]  R2339     2.0937354862689972e-01
    z[3,5,4]  R2340     -5.6084852665662766e-02
    z[3,5,5]  R34       -1
    z[3,5,5]  R52       1
    z[3,5,5]  R2251     -1
    z[3,5,5]  R2252     1
    z[3,5,5]  R2255     -2.5043833255767822e-01
    z[3,5,5]  R2256     3.2815396785736084e-01
    z[3,5,5]  R2257     5.5406481027603149e-02
    z[3,5,5]  R2258     3.8574171066284180e-01
    z[3,5,5]  R2259     4.4239467382431030e-01
    z[3,5,5]  R2260     -2.3063258826732635e-01
    z[3,5,5]  R2261     -1.5647193789482117e-01
    z[3,5,5]  R2262     2.8870645165443420e-01
    z[3,5,5]  R2263     -2.7284887433052063e-01
    z[3,5,5]  R2264     -5.2633565664291382e-01
    z[3,5,5]  R2265     -0.297408789396286
    z[3,5,5]  R2266     1.8562559783458710e-01
    z[3,5,5]  R2267     4.2010764591395855e-03
    z[3,5,5]  R2268     -8.6681410670280457e-02
    z[3,5,5]  R2269     9.7037024796009064e-02
    z[3,5,5]  R2270     -7.6643405482172966e-03
    z[3,5,5]  R2271     1.8124409019947052e-01
    z[3,5,5]  R2272     3.4569692611694336e-01
    z[3,5,5]  R2273     3.8990718126296997e-01
    z[3,5,5]  R2274     -1.4692430198192596e-01
    z[3,5,5]  R2275     -4.0169146656990051e-01
    z[3,5,5]  R2276     -2.1082855761051178e-01
    z[3,5,5]  R2277     -5.7908255606889725e-02
    z[3,5,5]  R2278     -2.6901489496231079e-01
    z[3,5,5]  R2279     -1.2342879176139832e-01
    z[3,5,5]  R2280     -1.8436795473098755e-01
    z[3,5,5]  R2281     -1.7887786030769348e-01
    z[3,5,5]  R2282     8.9686758816242218e-02
    z[3,5,5]  R2283     -1.9222494959831238e-01
    z[3,5,5]  R2284     -4.6440163254737854e-01
    z[3,5,5]  R2285     -1.4157579839229584e-01
    z[3,5,5]  R2286     2.7153030037879944e-01
    z[3,5,5]  R2287     5.4672157764434814e-01
    z[3,5,5]  R2288     2.2526112198829651e-01
    z[3,5,5]  R2289     -3.9854088425636292e-01
    z[3,5,5]  R2290     2.8633320331573486e-01
    z[3,5,5]  R2291     1.6349695622920990e-02
    z[3,5,5]  R2292     4.0406482294201851e-03
    z[3,5,5]  R2293     -2.8824573755264282e-01
    z[3,5,5]  R2294     6.4108437299728394e-01
    z[3,5,5]  R2295     2.6808005571365356e-01
    z[3,5,5]  R2296     3.5143008828163147e-01
    z[3,5,5]  R2297     -1.1392273753881454e-01
    z[3,5,5]  R2298     2.9049047827720642e-01
    z[3,5,5]  R2299     1.9229158759117126e-01
    z[3,5,5]  R2300     -1.3685730099678040e-01
    z[3,5,5]  R2301     2.3453648388385773e-01
    z[3,5,5]  R2302     -0.155681312084198
    z[3,5,5]  R2303     -2.1839885041117668e-02
    z[3,5,5]  R2304     1.5839838981628418e-01
    z[3,5,5]  R2305     9.0267747640609741e-02
    z[3,5,5]  R2306     1.0915318131446838e-01
    z[3,5,5]  R2307     2.9655680060386658e-01
    z[3,5,5]  R2308     1.3262277841567993e-01
    z[3,5,5]  R2309     -0.0666360929608345
    z[3,5,5]  R2310     -2.6828205585479736e-01
    z[3,5,5]  R2311     2.8831627964973450e-01
    z[3,5,5]  R2312     6.0940408706665039e-01
    z[3,5,5]  R2313     -2.6306754350662231e-01
    z[3,5,5]  R2314     3.0098492279648781e-03
    z[3,5,5]  R2315     1.1404132843017578e-01
    z[3,5,5]  R2316     -3.3031675219535828e-01
    z[3,5,5]  R2317     -2.3639994859695435e-01
    z[3,5,5]  R2318     -1.1001867055892944e-01
    z[3,5,5]  R2319     -3.6067163944244385e-01
    z[3,5,5]  R2320     5.5549168586730957e-01
    z[3,5,5]  R2321     3.3442208170890808e-01
    z[3,5,5]  R2322     2.1022740006446838e-01
    z[3,5,5]  R2323     4.3663203716278076e-01
    z[3,5,5]  R2324     5.2558046579360962e-01
    z[3,5,5]  R2325     3.7022992968559265e-01
    z[3,5,5]  R2326     2.5225467979907990e-02
    z[3,5,5]  R2327     2.4903084337711334e-01
    z[3,5,5]  R2328     5.6108510494232178e-01
    z[3,5,5]  R2329     1.4927624724805355e-02
    z[3,5,5]  R2330     9.7732760012149811e-02
    z[3,5,5]  R2331     2.3926517367362976e-01
    z[3,5,5]  R2332     1.5449105203151703e-01
    z[3,5,5]  R2333     -6.4368017017841339e-02
    z[3,5,5]  R2334     6.5900111198425293e-01
    z[3,5,5]  R2335     -1.0784979909658432e-01
    z[3,5,5]  R2336     1.7631146311759949e-01
    z[3,5,5]  R2337     0.00893962662667036
    z[3,5,5]  R2338     5.4915450513362885e-02
    z[3,5,5]  R2339     -2.6482370495796204e-01
    z[3,5,5]  R2340     0.0788489356637001
    z[3,5,6]  R35       -1
    z[3,5,6]  R53       1
    z[3,5,6]  R2253     -1
    z[3,5,6]  R2254     1
    z[3,5,6]  R2255     2.8108218312263489e-01
    z[3,5,6]  R2256     4.1452851891517639e-01
    z[3,5,6]  R2257     -2.2867612540721893e-01
    z[3,5,6]  R2258     -3.4304666519165039e-01
    z[3,5,6]  R2259     -1.9419296085834503e-01
    z[3,5,6]  R2260     -5.6261980533599854e-01
    z[3,5,6]  R2261     -6.5677899122238159e-01
    z[3,5,6]  R2262     5.5055910348892212e-01
    z[3,5,6]  R2263     -4.8196125775575638e-02
    z[3,5,6]  R2264     3.1478923559188843e-01
    z[3,5,6]  R2265     4.2554289102554321e-01
    z[3,5,6]  R2266     -2.0609997212886810e-01
    z[3,5,6]  R2267     1.0976740717887878e-01
    z[3,5,6]  R2268     -2.0024146139621735e-01
    z[3,5,6]  R2269     1.7138667404651642e-02
    z[3,5,6]  R2270     1.4539824426174164e-01
    z[3,5,6]  R2271     -1.9080650061368942e-02
    z[3,5,6]  R2272     -3.4737512469291687e-02
    z[3,5,6]  R2273     -9.4156764447689056e-02
    z[3,5,6]  R2274     -8.4076039493083954e-02
    z[3,5,6]  R2275     4.7083523124456406e-02
    z[3,5,6]  R2276     3.0754547566175461e-02
    z[3,5,6]  R2277     1.2262330204248428e-01
    z[3,5,6]  R2278     -8.0017736181616783e-03
    z[3,5,6]  R2279     1.6017764806747437e-01
    z[3,5,6]  R2280     -0.129512757062912
    z[3,5,6]  R2281     -3.3758670091629028e-01
    z[3,5,6]  R2282     8.1064760684967041e-02
    z[3,5,6]  R2283     -3.6736443638801575e-01
    z[3,5,6]  R2284     -3.8917452096939087e-01
    z[3,5,6]  R2285     -0.1804189234972
    z[3,5,6]  R2286     2.7841767668724060e-01
    z[3,5,6]  R2287     1.7514521256089211e-02
    z[3,5,6]  R2288     -1.7323812842369080e-01
    z[3,5,6]  R2289     -0.185040682554245
    z[3,5,6]  R2290     5.1151943206787109e-01
    z[3,5,6]  R2291     3.0506783723831177e-01
    z[3,5,6]  R2292     -1.6707411408424377e-01
    z[3,5,6]  R2293     -1.4030157029628754e-01
    z[3,5,6]  R2294     -1.5614232420921326e-01
    z[3,5,6]  R2295     -6.9573158025741577e-01
    z[3,5,6]  R2296     3.9206331968307495e-01
    z[3,5,6]  R2297     -4.4810160994529724e-01
    z[3,5,6]  R2298     -1.3658446073532104e-01
    z[3,5,6]  R2299     6.9953277707099915e-03
    z[3,5,6]  R2300     -4.5238631963729858e-01
    z[3,5,6]  R2301     -1.8078187480568886e-02
    z[3,5,6]  R2302     3.6166332662105560e-02
    z[3,5,6]  R2303     -4.2214909195899963e-01
    z[3,5,6]  R2304     3.2443445920944214e-01
    z[3,5,6]  R2305     -1.1246681213378906e-02
    z[3,5,6]  R2306     0.0382811576128006
    z[3,5,6]  R2307     -2.4132886528968811e-01
    z[3,5,6]  R2308     -3.7785002589225769e-01
    z[3,5,6]  R2309     -1.8799139559268951e-01
    z[3,5,6]  R2310     -4.2002037167549133e-02
    z[3,5,6]  R2311     4.2526909708976746e-01
    z[3,5,6]  R2312     1.3504503667354584e-01
    z[3,5,6]  R2313     3.2356211543083191e-01
    z[3,5,6]  R2314     1.5062689781188965e-01
    z[3,5,6]  R2315     -1.1830971390008926e-01
    z[3,5,6]  R2316     5.9109228849411011e-01
    z[3,5,6]  R2317     6.6986465454101562e-01
    z[3,5,6]  R2318     -2.7612483501434326e-01
    z[3,5,6]  R2319     3.7648779153823853e-01
    z[3,5,6]  R2320     -4.1460883617401123e-01
    z[3,5,6]  R2321     -7.3883078992366791e-02
    z[3,5,6]  R2322     2.6690849661827087e-01
    z[3,5,6]  R2323     2.3986613750457764e-01
    z[3,5,6]  R2324     -0.35416179895401
    z[3,5,6]  R2325     6.2710128724575043e-02
    z[3,5,6]  R2326     -6.3965469598770142e-02
    z[3,5,6]  R2327     -1.5120127797126770e-01
    z[3,5,6]  R2328     1.5688399970531464e-01
    z[3,5,6]  R2329     8.8956616818904877e-03
    z[3,5,6]  R2330     8.6626596748828888e-02
    z[3,5,6]  R2331     -2.4196162819862366e-01
    z[3,5,6]  R2332     -3.4563142806291580e-02
    z[3,5,6]  R2333     2.7168050408363342e-01
    z[3,5,6]  R2334     1.4697673916816711e-01
    z[3,5,6]  R2335     6.4747321605682373e-01
    z[3,5,6]  R2336     6.5576941706240177e-03
    z[3,5,6]  R2337     5.0558692216873169e-01
    z[3,5,6]  R2338     2.6151040196418762e-01
    z[3,5,6]  R2339     1.1140928417444229e-01
    z[3,5,6]  R2340     -3.5501249134540558e-02
    z[5,3,0]  R29       1
    z[5,3,0]  R47       -1
    z[5,3,0]  R2341     -1
    z[5,3,0]  R2342     1
    z[5,3,0]  R2355     9.1751128435134888e-02
    z[5,3,0]  R2356     -2.9391407966613770e-01
    z[5,3,0]  R2357     3.5134589672088623e-01
    z[5,3,0]  R2358     1.8095086514949799e-01
    z[5,3,0]  R2359     4.5932576060295105e-02
    z[5,3,0]  R2360     0.0817050188779831
    z[5,3,0]  R2361     1.5777802467346191e-01
    z[5,3,0]  R2362     -2.8450459241867065e-01
    z[5,3,0]  R2363     -2.5793009996414185e-01
    z[5,3,0]  R2364     2.9511460661888123e-01
    z[5,3,0]  R2365     -8.0357983708381653e-02
    z[5,3,0]  R2366     -2.6397609710693359e-01
    z[5,3,0]  R2367     -7.9158611595630646e-02
    z[5,3,0]  R2368     -1.3939459621906281e-01
    z[5,3,0]  R2369     3.3405673503875732e-01
    z[5,3,0]  R2370     -3.1011231243610382e-02
    z[5,3,0]  R2371     -2.3243987560272217e-01
    z[5,3,0]  R2372     6.5164053812623024e-03
    z[5,3,0]  R2373     -1.2624450027942657e-01
    z[5,3,0]  R2374     3.0309295654296875e-01
    z[5,3,0]  R2375     -6.2123370170593262e-01
    z[5,3,0]  R2376     -1.2315837293863297e-01
    z[5,3,0]  R2377     -7.4878519773483276e-01
    z[5,3,0]  R2378     1.7647108435630798e-01
    z[5,3,0]  R2379     -7.7983301877975464e-01
    z[5,3,0]  R2380     -4.7811153531074524e-01
    z[5,3,0]  R2381     -3.9945331215858459e-01
    z[5,3,0]  R2382     -7.3482406139373779e-01
    z[5,3,0]  R2383     -5.1747697591781616e-01
    z[5,3,0]  R2384     -5.3739684820175171e-01
    z[5,3,0]  R2385     5.9888356924057007e-01
    z[5,3,0]  R2386     1.9250044226646423e-01
    z[5,3,0]  R2387     3.4843954443931580e-01
    z[5,3,0]  R2388     -1.4973483979701996e-01
    z[5,3,0]  R2389     5.2489286661148071e-01
    z[5,3,0]  R2390     7.5461953878402710e-01
    z[5,3,0]  R2391     6.6458392143249512e-01
    z[5,3,0]  R2392     -2.1477121859788895e-02
    z[5,3,0]  R2393     0.493700236082077
    z[5,3,0]  R2394     5.5405634641647339e-01
    z[5,3,0]  R2395     -3.0755949020385742e-01
    z[5,3,0]  R2396     5.7791608572006226e-01
    z[5,3,0]  R2397     3.1935986876487732e-01
    z[5,3,0]  R2398     -5.7855671644210815e-01
    z[5,3,0]  R2399     2.0953913033008575e-01
    z[5,3,0]  R2400     2.7045177295804024e-02
    z[5,3,0]  R2401     1.8525169789791107e-01
    z[5,3,0]  R2402     7.2206068038940430e-01
    z[5,3,0]  R2403     0.537449300289154
    z[5,3,0]  R2404     7.2452224791049957e-02
    z[5,3,0]  R2405     1.8530371785163879e-01
    z[5,3,0]  R2406     -2.5193458795547485e-01
    z[5,3,0]  R2407     -5.6188285350799561e-01
    z[5,3,0]  R2408     1.5947241336107254e-02
    z[5,3,0]  R2409     2.9958420991897583e-01
    z[5,3,0]  R2410     0.526293158531189
    z[5,3,0]  R2411     -5.1610004901885986e-01
    z[5,3,0]  R2412     -3.3037957549095154e-01
    z[5,3,0]  R2413     3.0317434668540955e-01
    z[5,3,0]  R2414     3.3268904685974121e-01
    z[5,3,0]  R2415     0.154024139046669
    z[5,3,0]  R2416     3.9366778731346130e-01
    z[5,3,0]  R2417     4.0054762363433838e-01
    z[5,3,0]  R2418     3.4238618612289429e-01
    z[5,3,0]  R2419     5.7106947898864746e-01
    z[5,3,0]  R2420     5.3418982028961182e-01
    z[5,3,0]  R2421     6.4118576049804688e-01
    z[5,3,0]  R2422     7.8070056438446045e-01
    z[5,3,0]  R2423     3.5703986883163452e-01
    z[5,3,0]  R2424     -1.4922395348548889e-01
    z[5,3,0]  R2425     3.4297034144401550e-01
    z[5,3,0]  R2426     6.8746519088745117e-01
    z[5,3,0]  R2427     5.9731644392013550e-01
    z[5,3,0]  R2428     0.451546847820282
    z[5,3,0]  R2429     3.8975724577903748e-01
    z[5,3,0]  R2430     5.2762645483016968e-01
    z[5,3,0]  R2431     0.359191358089447
    z[5,3,0]  R2432     3.3647558093070984e-01
    z[5,3,0]  R2433     4.7783535718917847e-01
    z[5,3,0]  R2434     5.2259588241577148e-01
    z[5,3,0]  R2435     5.2622985839843750e-01
    z[5,3,0]  R2436     -3.9881786704063416e-01
    z[5,3,0]  R2437     -2.2276766598224640e-01
    z[5,3,0]  R2438     -3.8694933056831360e-01
    z[5,3,0]  R2439     -1.8728250265121460e-01
    z[5,3,0]  R2440     -6.7813791334629059e-02
    z[5,3,1]  R30       1
    z[5,3,1]  R48       -1
    z[5,3,1]  R2343     -1
    z[5,3,1]  R2344     1
    z[5,3,1]  R2355     8.7547320127487183e-01
    z[5,3,1]  R2356     8.5558646917343140e-01
    z[5,3,1]  R2357     7.4692708253860474e-01
    z[5,3,1]  R2358     7.0906698703765869e-01
    z[5,3,1]  R2359     6.2525153160095215e-01
    z[5,3,1]  R2360     6.2553548812866211e-01
    z[5,3,1]  R2361     4.2846208810806274e-01
    z[5,3,1]  R2362     6.0804325342178345e-01
    z[5,3,1]  R2363     2.9897719621658325e-01
    z[5,3,1]  R2364     6.6439443826675415e-01
    z[5,3,1]  R2365     -9.2065292596817017e-01
    z[5,3,1]  R2366     -9.4883036613464355e-01
    z[5,3,1]  R2367     -8.4418761730194092e-01
    z[5,3,1]  R2368     -8.5557991266250610e-01
    z[5,3,1]  R2369     -8.8591217994689941e-01
    z[5,3,1]  R2370     -8.5599416494369507e-01
    z[5,3,1]  R2371     -0.837941586971283
    z[5,3,1]  R2372     -8.3161729574203491e-01
    z[5,3,1]  R2373     -8.2682949304580688e-01
    z[5,3,1]  R2374     -8.9267814159393311e-01
    z[5,3,1]  R2375     -9.1890551149845123e-02
    z[5,3,1]  R2376     -1.7950126528739929e-01
    z[5,3,1]  R2377     3.0340716242790222e-01
    z[5,3,1]  R2378     2.9247373342514038e-01
    z[5,3,1]  R2379     1.9021998345851898e-01
    z[5,3,1]  R2380     2.6451054215431213e-01
    z[5,3,1]  R2381     1.7234939336776733e-01
    z[5,3,1]  R2382     4.5606139302253723e-01
    z[5,3,1]  R2383     3.7726444005966187e-01
    z[5,3,1]  R2384     -2.4689415469765663e-02
    z[5,3,1]  R2385     -1.1694305390119553e-01
    z[5,3,1]  R2386     -6.3666746020317078e-02
    z[5,3,1]  R2387     -5.9154576063156128e-01
    z[5,3,1]  R2388     7.1902751922607422e-02
    z[5,3,1]  R2389     -5.9003078937530518e-01
    z[5,3,1]  R2390     -5.4779714345932007e-01
    z[5,3,1]  R2391     -5.7059872150421143e-01
    z[5,3,1]  R2392     -6.3786470890045166e-01
    z[5,3,1]  R2393     -6.7252731323242188e-01
    z[5,3,1]  R2394     -6.6398131847381592e-01
    z[5,3,1]  R2395     4.1244527697563171e-01
    z[5,3,1]  R2396     2.9022064805030823e-01
    z[5,3,1]  R2397     0.279297411441803
    z[5,3,1]  R2398     -0.230604350566864
    z[5,3,1]  R2399     1.7475579679012299e-01
    z[5,3,1]  R2400     8.5760280489921570e-02
    z[5,3,1]  R2401     -3.2181721925735474e-01
    z[5,3,1]  R2402     -2.1566207706928253e-01
    z[5,3,1]  R2403     -3.5702559351921082e-01
    z[5,3,1]  R2404     -6.3930189609527588e-01
    z[5,3,1]  R2405     -8.6314660310745239e-01
    z[5,3,1]  R2406     -0.620816707611084
    z[5,3,1]  R2407     -5.4310923814773560e-01
    z[5,3,1]  R2408     -4.0189677476882935e-01
    z[5,3,1]  R2409     -4.8578220605850220e-01
    z[5,3,1]  R2410     -2.4732129275798798e-01
    z[5,3,1]  R2411     0.180352121591568
    z[5,3,1]  R2412     3.7351536750793457e-01
    z[5,3,1]  R2413     4.2863461375236511e-01
    z[5,3,1]  R2414     0.567589521408081
    z[5,3,1]  R2415     4.7279828786849976e-01
    z[5,3,1]  R2416     6.7619991302490234e-01
    z[5,3,1]  R2417     6.0610163211822510e-01
    z[5,3,1]  R2418     5.5915105342864990e-01
    z[5,3,1]  R2419     4.4078534841537476e-01
    z[5,3,1]  R2420     4.1569101810455322e-01
    z[5,3,1]  R2421     4.3550312519073486e-01
    z[5,3,1]  R2422     4.0601298213005066e-01
    z[5,3,1]  R2423     7.6938372850418091e-01
    z[5,3,1]  R2424     7.6927435398101807e-01
    z[5,3,1]  R2425     6.8489295244216919e-01
    z[5,3,1]  R2426     0.523723304271698
    z[5,3,1]  R2427     5.9777599573135376e-01
    z[5,3,1]  R2428     5.7301956415176392e-01
    z[5,3,1]  R2429     6.8097829818725586e-01
    z[5,3,1]  R2430     6.5009635686874390e-01
    z[5,3,1]  R2431     0.77623051404953
    z[5,3,1]  R2432     0.825904130935669
    z[5,3,1]  R2433     5.0051957368850708e-01
    z[5,3,1]  R2434     4.6122789382934570e-01
    z[5,3,1]  R2435     0.753503680229187
    z[5,3,1]  R2436     6.0441082715988159e-01
    z[5,3,1]  R2437     6.9407802820205688e-01
    z[5,3,1]  R2438     7.0124787092208862e-01
    z[5,3,1]  R2439     6.6254991292953491e-01
    z[5,3,1]  R2440     4.9700316786766052e-01
    z[5,3,2]  R31       1
    z[5,3,2]  R49       -1
    z[5,3,2]  R2345     -1
    z[5,3,2]  R2346     1
    z[5,3,2]  R2355     2.2204430401325226e-01
    z[5,3,2]  R2356     -6.9286718964576721e-02
    z[5,3,2]  R2357     1.0267228819429874e-02
    z[5,3,2]  R2358     -3.1002461910247803e-02
    z[5,3,2]  R2359     1.0819110274314880e-01
    z[5,3,2]  R2360     -3.7111940979957581e-01
    z[5,3,2]  R2361     7.5985920429229736e-01
    z[5,3,2]  R2362     -2.4186022579669952e-01
    z[5,3,2]  R2363     7.5410521030426025e-01
    z[5,3,2]  R2364     -4.7407627105712891e-01
    z[5,3,2]  R2365     2.6614934206008911e-01
    z[5,3,2]  R2366     -4.7693509608507156e-02
    z[5,3,2]  R2367     2.5060348212718964e-02
    z[5,3,2]  R2368     -2.1321940422058105e-01
    z[5,3,2]  R2369     0.201337531208992
    z[5,3,2]  R2370     -2.9549381136894226e-01
    z[5,3,2]  R2371     -1.6530798375606537e-01
    z[5,3,2]  R2372     0.0824781134724617
    z[5,3,2]  R2373     -6.8636782467365265e-02
    z[5,3,2]  R2374     1.6016195714473724e-01
    z[5,3,2]  R2375     -4.8945721983909607e-01
    z[5,3,2]  R2376     5.1430130004882812e-01
    z[5,3,2]  R2377     3.4037387371063232e-01
    z[5,3,2]  R2378     -8.9806658029556274e-01
    z[5,3,2]  R2379     -0.0916375145316124
    z[5,3,2]  R2380     3.0163705348968506e-02
    z[5,3,2]  R2381     -4.7916686534881592e-01
    z[5,3,2]  R2382     -1.5109807252883911e-01
    z[5,3,2]  R2383     -3.7307778000831604e-01
    z[5,3,2]  R2384     -9.4032082706689835e-03
    z[5,3,2]  R2385     8.0027438700199127e-02
    z[5,3,2]  R2386     -5.8725923299789429e-02
    z[5,3,2]  R2387     1.0964184254407883e-01
    z[5,3,2]  R2388     -7.3334950208663940e-01
    z[5,3,2]  R2389     4.0528017282485962e-01
    z[5,3,2]  R2390     0.284252792596817
    z[5,3,2]  R2391     3.6815294623374939e-01
    z[5,3,2]  R2392     1.5899296104907990e-01
    z[5,3,2]  R2393     4.2180046439170837e-01
    z[5,3,2]  R2394     4.2704778909683228e-01
    z[5,3,2]  R2395     -5.3261661529541016e-01
    z[5,3,2]  R2396     -4.9754548072814941e-01
    z[5,3,2]  R2397     4.1682365536689758e-01
    z[5,3,2]  R2398     -9.4092383980751038e-02
    z[5,3,2]  R2399     6.6872701048851013e-02
    z[5,3,2]  R2400     5.3215879201889038e-01
    z[5,3,2]  R2401     4.9683311581611633e-01
    z[5,3,2]  R2402     4.9082070589065552e-01
    z[5,3,2]  R2403     6.5681940317153931e-01
    z[5,3,2]  R2404     6.7451059818267822e-01
    z[5,3,2]  R2405     2.2956785559654236e-01
    z[5,3,2]  R2406     4.2582547664642334e-01
    z[5,3,2]  R2407     -1.6568163037300110e-01
    z[5,3,2]  R2408     5.4286289215087891e-01
    z[5,3,2]  R2409     -5.3863358497619629e-01
    z[5,3,2]  R2410     -3.8546475768089294e-01
    z[5,3,2]  R2411     4.0814954042434692e-01
    z[5,3,2]  R2412     -4.4135829806327820e-01
    z[5,3,2]  R2413     3.7516161799430847e-01
    z[5,3,2]  R2414     2.8477218747138977e-01
    z[5,3,2]  R2415     -2.2615494672209024e-03
    z[5,3,2]  R2416     3.3404495567083359e-02
    z[5,3,2]  R2417     -4.4436094164848328e-01
    z[5,3,2]  R2418     0.0140988202765584
    z[5,3,2]  R2419     4.9933022260665894e-01
    z[5,3,2]  R2420     -1.5091960132122040e-01
    z[5,3,2]  R2421     -3.3889949321746826e-01
    z[5,3,2]  R2422     2.6863566040992737e-01
    z[5,3,2]  R2423     -2.5784516334533691e-01
    z[5,3,2]  R2424     1.3406106829643250e-01
    z[5,3,2]  R2425     -6.1934594996273518e-03
    z[5,3,2]  R2426     3.0340753495693207e-02
    z[5,3,2]  R2427     -2.0380338653922081e-02
    z[5,3,2]  R2428     1.6603243350982666e-01
    z[5,3,2]  R2429     -1.2298868969082832e-02
    z[5,3,2]  R2430     1.7190766334533691e-01
    z[5,3,2]  R2431     1.2203613668680191e-01
    z[5,3,2]  R2432     1.2268714606761932e-01
    z[5,3,2]  R2433     2.8339171409606934e-01
    z[5,3,2]  R2434     2.9617032408714294e-01
    z[5,3,2]  R2435     -1.5018188953399658e-01
    z[5,3,2]  R2436     4.4502297043800354e-01
    z[5,3,2]  R2437     2.9261613264679909e-02
    z[5,3,2]  R2438     -3.6792778968811035e-01
    z[5,3,2]  R2439     -2.3362116515636444e-01
    z[5,3,2]  R2440     -3.2235378026962280e-01
    z[5,3,3]  R32       1
    z[5,3,3]  R50       -1
    z[5,3,3]  R2347     -1
    z[5,3,3]  R2348     1
    z[5,3,3]  R2355     -1.7188473045825958e-01
    z[5,3,3]  R2356     1.8126615881919861e-01
    z[5,3,3]  R2357     4.3439182639122009e-01
    z[5,3,3]  R2358     -1.2478467077016830e-01
    z[5,3,3]  R2359     1.9832178950309753e-01
    z[5,3,3]  R2360     4.3204563856124878e-01
    z[5,3,3]  R2361     1.1489140801131725e-02
    z[5,3,3]  R2362     -4.0967710316181183e-02
    z[5,3,3]  R2363     4.8574271798133850e-01
    z[5,3,3]  R2364     -4.3506991118192673e-02
    z[5,3,3]  R2365     -4.6891830861568451e-02
    z[5,3,3]  R2366     -2.8363440185785294e-02
    z[5,3,3]  R2367     1.3611934147775173e-02
    z[5,3,3]  R2368     -0.0231669619679451
    z[5,3,3]  R2369     2.2896258533000946e-01
    z[5,3,3]  R2370     3.4761503338813782e-01
    z[5,3,3]  R2371     2.6514670252799988e-01
    z[5,3,3]  R2372     1.0575447231531143e-01
    z[5,3,3]  R2373     4.9875143170356750e-01
    z[5,3,3]  R2374     7.5762018561363220e-02
    z[5,3,3]  R2375     -2.3659074306488037e-01
    z[5,3,3]  R2376     -2.6496499776840210e-01
    z[5,3,3]  R2377     -1.8247883021831512e-01
    z[5,3,3]  R2378     -2.2330953180789948e-01
    z[5,3,3]  R2379     -1.5001441538333893e-01
    z[5,3,3]  R2380     -4.4930616021156311e-01
    z[5,3,3]  R2381     -2.6776903867721558e-01
    z[5,3,3]  R2382     9.8131135106086731e-02
    z[5,3,3]  R2383     -2.6228803396224976e-01
    z[5,3,3]  R2384     -1.6434629261493683e-01
    z[5,3,3]  R2385     -6.9557195901870728e-01
    z[5,3,3]  R2386     -0.846520185470581
    z[5,3,3]  R2387     -4.7702023386955261e-01
    z[5,3,3]  R2388     -4.8704613000154495e-02
    z[5,3,3]  R2389     -1.0013290494680405e-01
    z[5,3,3]  R2390     -9.7566343843936920e-02
    z[5,3,3]  R2391     -8.4781445562839508e-02
    z[5,3,3]  R2392     -0.349507600069046
    z[5,3,3]  R2393     -4.1402030736207962e-02
    z[5,3,3]  R2394     1.7861567437648773e-01
    z[5,3,3]  R2395     -4.2533260583877563e-01
    z[5,3,3]  R2396     -2.0311589539051056e-01
    z[5,3,3]  R2397     -2.9586234688758850e-01
    z[5,3,3]  R2398     1.5119914710521698e-01
    z[5,3,3]  R2399     -4.7901135683059692e-01
    z[5,3,3]  R2400     -7.7033668756484985e-01
    z[5,3,3]  R2401     -5.8633148670196533e-01
    z[5,3,3]  R2402     -2.6660934090614319e-01
    z[5,3,3]  R2403     1.6089810431003571e-01
    z[5,3,3]  R2404     3.4706801176071167e-01
    z[5,3,3]  R2405     -1.6177067160606384e-01
    z[5,3,3]  R2406     -2.6279929280281067e-01
    z[5,3,3]  R2407     -2.6221841573715210e-01
    z[5,3,3]  R2408     1.3024370372295380e-01
    z[5,3,3]  R2409     -3.8735681772232056e-01
    z[5,3,3]  R2410     -2.7802714705467224e-01
    z[5,3,3]  R2411     -2.8050836920738220e-01
    z[5,3,3]  R2412     -4.0410766005516052e-01
    z[5,3,3]  R2413     6.2525969743728638e-01
    z[5,3,3]  R2414     1.2843927368521690e-02
    z[5,3,3]  R2415     -6.5263265371322632e-01
    z[5,3,3]  R2416     4.4501677155494690e-01
    z[5,3,3]  R2417     4.9889558553695679e-01
    z[5,3,3]  R2418     4.7653332352638245e-01
    z[5,3,3]  R2419     4.1545253992080688e-01
    z[5,3,3]  R2420     4.8808595538139343e-01
    z[5,3,3]  R2421     4.2026409506797791e-01
    z[5,3,3]  R2422     1.4036716520786285e-01
    z[5,3,3]  R2423     2.2125220298767090e-01
    z[5,3,3]  R2424     5.8147305250167847e-01
    z[5,3,3]  R2425     4.7862425446510315e-01
    z[5,3,3]  R2426     4.2620095610618591e-01
    z[5,3,3]  R2427     5.0037211179733276e-01
    z[5,3,3]  R2428     5.6852996349334717e-01
    z[5,3,3]  R2429     5.5031090974807739e-01
    z[5,3,3]  R2430     3.2639884948730469e-01
    z[5,3,3]  R2431     3.2783108949661255e-01
    z[5,3,3]  R2432     3.9959990978240967e-01
    z[5,3,3]  R2433     5.1531338691711426e-01
    z[5,3,3]  R2434     2.4345543980598450e-01
    z[5,3,3]  R2435     2.5134083628654480e-01
    z[5,3,3]  R2436     3.5491314530372620e-01
    z[5,3,3]  R2437     3.9876180887222290e-01
    z[5,3,3]  R2438     2.8322747349739075e-01
    z[5,3,3]  R2439     5.1692402362823486e-01
    z[5,3,3]  R2440     5.1157861948013306e-01
    z[5,3,4]  R33       1
    z[5,3,4]  R51       -1
    z[5,3,4]  R2349     -1
    z[5,3,4]  R2350     1
    z[5,3,4]  R2355     2.3010133206844330e-01
    z[5,3,4]  R2356     3.4058505296707153e-01
    z[5,3,4]  R2357     1.6457255184650421e-01
    z[5,3,4]  R2358     1.1215513199567795e-01
    z[5,3,4]  R2359     2.1339850500226021e-03
    z[5,3,4]  R2360     2.0488698035478592e-02
    z[5,3,4]  R2361     1.5322379767894745e-02
    z[5,3,4]  R2362     6.2139028310775757e-01
    z[5,3,4]  R2363     4.9387805163860321e-02
    z[5,3,4]  R2364     1.4650250971317291e-01
    z[5,3,4]  R2365     -1.3256011903285980e-01
    z[5,3,4]  R2366     3.7601027637720108e-02
    z[5,3,4]  R2367     -3.1871777772903442e-01
    z[5,3,4]  R2368     2.6871031522750854e-01
    z[5,3,4]  R2369     4.8271864652633667e-02
    z[5,3,4]  R2370     2.1161170303821564e-01
    z[5,3,4]  R2371     -3.2673040404915810e-03
    z[5,3,4]  R2372     0.360588401556015
    z[5,3,4]  R2373     0.0846773162484169
    z[5,3,4]  R2374     0.078289695084095
    z[5,3,4]  R2375     -2.1471163630485535e-01
    z[5,3,4]  R2376     4.7779548168182373e-01
    z[5,3,4]  R2377     -1.5561152994632721e-01
    z[5,3,4]  R2378     6.5029174089431763e-02
    z[5,3,4]  R2379     -5.4568547010421753e-01
    z[5,3,4]  R2380     -2.0039555430412292e-01
    z[5,3,4]  R2381     -6.9484390318393707e-02
    z[5,3,4]  R2382     -3.6225995421409607e-01
    z[5,3,4]  R2383     -3.3178317546844482e-01
    z[5,3,4]  R2384     -4.5058351755142212e-01
    z[5,3,4]  R2385     -1.4191937446594238e-01
    z[5,3,4]  R2386     -3.5129639506340027e-01
    z[5,3,4]  R2387     -2.0226357877254486e-01
    z[5,3,4]  R2388     -1.7484459280967712e-01
    z[5,3,4]  R2389     -2.4712309241294861e-01
    z[5,3,4]  R2390     -1.8820452690124512e-01
    z[5,3,4]  R2391     -7.1713291108608246e-02
    z[5,3,4]  R2392     -3.2527527213096619e-01
    z[5,3,4]  R2393     -3.5218662023544312e-01
    z[5,3,4]  R2394     0.144295796751976
    z[5,3,4]  R2395     -3.9359182119369507e-01
    z[5,3,4]  R2396     5.1760542392730713e-01
    z[5,3,4]  R2397     6.9337749481201172e-01
    z[5,3,4]  R2398     3.5283794999122620e-01
    z[5,3,4]  R2399     5.1066315174102783e-01
    z[5,3,4]  R2400     -2.9012659192085266e-01
    z[5,3,4]  R2401     -1.2565696239471436e-01
    z[5,3,4]  R2402     -2.2074703872203827e-01
    z[5,3,4]  R2403     2.0937354862689972e-01
    z[5,3,4]  R2404     -5.6084852665662766e-02
    z[5,3,4]  R2405     -6.5339556895196438e-03
    z[5,3,4]  R2406     1.4562240242958069e-01
    z[5,3,4]  R2407     4.8759466409683228e-01
    z[5,3,4]  R2408     -5.0998383760452271e-01
    z[5,3,4]  R2409     2.5875428691506386e-02
    z[5,3,4]  R2410     -2.5735804438591003e-01
    z[5,3,4]  R2411     -7.9946219921112061e-04
    z[5,3,4]  R2412     8.2271791994571686e-02
    z[5,3,4]  R2413     -3.4042972326278687e-01
    z[5,3,4]  R2414     3.3132830262184143e-01
    z[5,3,4]  R2415     2.3930130898952484e-01
    z[5,3,4]  R2416     3.3419987559318542e-01
    z[5,3,4]  R2417     1.1739798635244370e-01
    z[5,3,4]  R2418     5.4334950447082520e-01
    z[5,3,4]  R2419     2.1896690130233765e-01
    z[5,3,4]  R2420     5.0954711437225342e-01
    z[5,3,4]  R2421     -2.7300122380256653e-01
    z[5,3,4]  R2422     1.1436348408460617e-01
    z[5,3,4]  R2423     -6.5126776695251465e-02
    z[5,3,4]  R2424     3.4790221601724625e-02
    z[5,3,4]  R2425     -1.4352890849113464e-01
    z[5,3,4]  R2426     1.5856587886810303e-01
    z[5,3,4]  R2427     -0.129226416349411
    z[5,3,4]  R2428     2.1101680397987366e-01
    z[5,3,4]  R2429     2.0117874443531036e-01
    z[5,3,4]  R2430     -3.3486044406890869e-01
    z[5,3,4]  R2431     -1.0937442071735859e-02
    z[5,3,4]  R2432     -1.2377080321311951e-01
    z[5,3,4]  R2433     -5.8204419910907745e-02
    z[5,3,4]  R2434     -7.0177665911614895e-03
    z[5,3,4]  R2435     -1.3035634160041809e-01
    z[5,3,4]  R2436     -1.9441822543740273e-02
    z[5,3,4]  R2437     -9.7734019160270691e-02
    z[5,3,4]  R2438     2.4935714900493622e-01
    z[5,3,4]  R2439     1.0530297458171844e-01
    z[5,3,4]  R2440     1.9780211150646210e-01
    z[5,3,5]  R34       1
    z[5,3,5]  R52       -1
    z[5,3,5]  R2351     -1
    z[5,3,5]  R2352     1
    z[5,3,5]  R2355     1.6349695622920990e-02
    z[5,3,5]  R2356     4.0406482294201851e-03
    z[5,3,5]  R2357     -2.8824573755264282e-01
    z[5,3,5]  R2358     6.4108437299728394e-01
    z[5,3,5]  R2359     2.6808005571365356e-01
    z[5,3,5]  R2360     3.5143008828163147e-01
    z[5,3,5]  R2361     -1.1392273753881454e-01
    z[5,3,5]  R2362     2.9049047827720642e-01
    z[5,3,5]  R2363     1.9229158759117126e-01
    z[5,3,5]  R2364     -1.3685730099678040e-01
    z[5,3,5]  R2365     2.3453648388385773e-01
    z[5,3,5]  R2366     -0.155681312084198
    z[5,3,5]  R2367     -2.1839885041117668e-02
    z[5,3,5]  R2368     1.5839838981628418e-01
    z[5,3,5]  R2369     9.0267747640609741e-02
    z[5,3,5]  R2370     1.0915318131446838e-01
    z[5,3,5]  R2371     2.9655680060386658e-01
    z[5,3,5]  R2372     1.3262277841567993e-01
    z[5,3,5]  R2373     -0.0666360929608345
    z[5,3,5]  R2374     -2.6828205585479736e-01
    z[5,3,5]  R2375     2.8831627964973450e-01
    z[5,3,5]  R2376     6.0940408706665039e-01
    z[5,3,5]  R2377     -2.6306754350662231e-01
    z[5,3,5]  R2378     3.0098492279648781e-03
    z[5,3,5]  R2379     1.1404132843017578e-01
    z[5,3,5]  R2380     -3.3031675219535828e-01
    z[5,3,5]  R2381     -2.3639994859695435e-01
    z[5,3,5]  R2382     -1.1001867055892944e-01
    z[5,3,5]  R2383     -3.6067163944244385e-01
    z[5,3,5]  R2384     5.5549168586730957e-01
    z[5,3,5]  R2385     3.3442208170890808e-01
    z[5,3,5]  R2386     2.1022740006446838e-01
    z[5,3,5]  R2387     4.3663203716278076e-01
    z[5,3,5]  R2388     5.2558046579360962e-01
    z[5,3,5]  R2389     3.7022992968559265e-01
    z[5,3,5]  R2390     2.5225467979907990e-02
    z[5,3,5]  R2391     2.4903084337711334e-01
    z[5,3,5]  R2392     5.6108510494232178e-01
    z[5,3,5]  R2393     1.4927624724805355e-02
    z[5,3,5]  R2394     9.7732760012149811e-02
    z[5,3,5]  R2395     2.3926517367362976e-01
    z[5,3,5]  R2396     1.5449105203151703e-01
    z[5,3,5]  R2397     -6.4368017017841339e-02
    z[5,3,5]  R2398     6.5900111198425293e-01
    z[5,3,5]  R2399     -1.0784979909658432e-01
    z[5,3,5]  R2400     1.7631146311759949e-01
    z[5,3,5]  R2401     0.00893962662667036
    z[5,3,5]  R2402     5.4915450513362885e-02
    z[5,3,5]  R2403     -2.6482370495796204e-01
    z[5,3,5]  R2404     0.0788489356637001
    z[5,3,5]  R2405     -2.5043833255767822e-01
    z[5,3,5]  R2406     3.2815396785736084e-01
    z[5,3,5]  R2407     5.5406481027603149e-02
    z[5,3,5]  R2408     3.8574171066284180e-01
    z[5,3,5]  R2409     4.4239467382431030e-01
    z[5,3,5]  R2410     -2.3063258826732635e-01
    z[5,3,5]  R2411     -1.5647193789482117e-01
    z[5,3,5]  R2412     2.8870645165443420e-01
    z[5,3,5]  R2413     -2.7284887433052063e-01
    z[5,3,5]  R2414     -5.2633565664291382e-01
    z[5,3,5]  R2415     -0.297408789396286
    z[5,3,5]  R2416     1.8562559783458710e-01
    z[5,3,5]  R2417     4.2010764591395855e-03
    z[5,3,5]  R2418     -8.6681410670280457e-02
    z[5,3,5]  R2419     9.7037024796009064e-02
    z[5,3,5]  R2420     -7.6643405482172966e-03
    z[5,3,5]  R2421     1.8124409019947052e-01
    z[5,3,5]  R2422     3.4569692611694336e-01
    z[5,3,5]  R2423     3.8990718126296997e-01
    z[5,3,5]  R2424     -1.4692430198192596e-01
    z[5,3,5]  R2425     -4.0169146656990051e-01
    z[5,3,5]  R2426     -2.1082855761051178e-01
    z[5,3,5]  R2427     -5.7908255606889725e-02
    z[5,3,5]  R2428     -2.6901489496231079e-01
    z[5,3,5]  R2429     -1.2342879176139832e-01
    z[5,3,5]  R2430     -1.8436795473098755e-01
    z[5,3,5]  R2431     -1.7887786030769348e-01
    z[5,3,5]  R2432     8.9686758816242218e-02
    z[5,3,5]  R2433     -1.9222494959831238e-01
    z[5,3,5]  R2434     -4.6440163254737854e-01
    z[5,3,5]  R2435     -1.4157579839229584e-01
    z[5,3,5]  R2436     2.7153030037879944e-01
    z[5,3,5]  R2437     5.4672157764434814e-01
    z[5,3,5]  R2438     2.2526112198829651e-01
    z[5,3,5]  R2439     -3.9854088425636292e-01
    z[5,3,5]  R2440     2.8633320331573486e-01
    z[5,3,6]  R35       1
    z[5,3,6]  R53       -1
    z[5,3,6]  R2353     -1
    z[5,3,6]  R2354     1
    z[5,3,6]  R2355     3.0506783723831177e-01
    z[5,3,6]  R2356     -1.6707411408424377e-01
    z[5,3,6]  R2357     -1.4030157029628754e-01
    z[5,3,6]  R2358     -1.5614232420921326e-01
    z[5,3,6]  R2359     -6.9573158025741577e-01
    z[5,3,6]  R2360     3.9206331968307495e-01
    z[5,3,6]  R2361     -4.4810160994529724e-01
    z[5,3,6]  R2362     -1.3658446073532104e-01
    z[5,3,6]  R2363     6.9953277707099915e-03
    z[5,3,6]  R2364     -4.5238631963729858e-01
    z[5,3,6]  R2365     -1.8078187480568886e-02
    z[5,3,6]  R2366     3.6166332662105560e-02
    z[5,3,6]  R2367     -4.2214909195899963e-01
    z[5,3,6]  R2368     3.2443445920944214e-01
    z[5,3,6]  R2369     -1.1246681213378906e-02
    z[5,3,6]  R2370     0.0382811576128006
    z[5,3,6]  R2371     -2.4132886528968811e-01
    z[5,3,6]  R2372     -3.7785002589225769e-01
    z[5,3,6]  R2373     -1.8799139559268951e-01
    z[5,3,6]  R2374     -4.2002037167549133e-02
    z[5,3,6]  R2375     4.2526909708976746e-01
    z[5,3,6]  R2376     1.3504503667354584e-01
    z[5,3,6]  R2377     3.2356211543083191e-01
    z[5,3,6]  R2378     1.5062689781188965e-01
    z[5,3,6]  R2379     -1.1830971390008926e-01
    z[5,3,6]  R2380     5.9109228849411011e-01
    z[5,3,6]  R2381     6.6986465454101562e-01
    z[5,3,6]  R2382     -2.7612483501434326e-01
    z[5,3,6]  R2383     3.7648779153823853e-01
    z[5,3,6]  R2384     -4.1460883617401123e-01
    z[5,3,6]  R2385     -7.3883078992366791e-02
    z[5,3,6]  R2386     2.6690849661827087e-01
    z[5,3,6]  R2387     2.3986613750457764e-01
    z[5,3,6]  R2388     -0.35416179895401
    z[5,3,6]  R2389     6.2710128724575043e-02
    z[5,3,6]  R2390     -6.3965469598770142e-02
    z[5,3,6]  R2391     -1.5120127797126770e-01
    z[5,3,6]  R2392     1.5688399970531464e-01
    z[5,3,6]  R2393     8.8956616818904877e-03
    z[5,3,6]  R2394     8.6626596748828888e-02
    z[5,3,6]  R2395     -2.4196162819862366e-01
    z[5,3,6]  R2396     -3.4563142806291580e-02
    z[5,3,6]  R2397     2.7168050408363342e-01
    z[5,3,6]  R2398     1.4697673916816711e-01
    z[5,3,6]  R2399     6.4747321605682373e-01
    z[5,3,6]  R2400     6.5576941706240177e-03
    z[5,3,6]  R2401     5.0558692216873169e-01
    z[5,3,6]  R2402     2.6151040196418762e-01
    z[5,3,6]  R2403     1.1140928417444229e-01
    z[5,3,6]  R2404     -3.5501249134540558e-02
    z[5,3,6]  R2405     2.8108218312263489e-01
    z[5,3,6]  R2406     4.1452851891517639e-01
    z[5,3,6]  R2407     -2.2867612540721893e-01
    z[5,3,6]  R2408     -3.4304666519165039e-01
    z[5,3,6]  R2409     -1.9419296085834503e-01
    z[5,3,6]  R2410     -5.6261980533599854e-01
    z[5,3,6]  R2411     -6.5677899122238159e-01
    z[5,3,6]  R2412     5.5055910348892212e-01
    z[5,3,6]  R2413     -4.8196125775575638e-02
    z[5,3,6]  R2414     3.1478923559188843e-01
    z[5,3,6]  R2415     4.2554289102554321e-01
    z[5,3,6]  R2416     -2.0609997212886810e-01
    z[5,3,6]  R2417     1.0976740717887878e-01
    z[5,3,6]  R2418     -2.0024146139621735e-01
    z[5,3,6]  R2419     1.7138667404651642e-02
    z[5,3,6]  R2420     1.4539824426174164e-01
    z[5,3,6]  R2421     -1.9080650061368942e-02
    z[5,3,6]  R2422     -3.4737512469291687e-02
    z[5,3,6]  R2423     -9.4156764447689056e-02
    z[5,3,6]  R2424     -8.4076039493083954e-02
    z[5,3,6]  R2425     4.7083523124456406e-02
    z[5,3,6]  R2426     3.0754547566175461e-02
    z[5,3,6]  R2427     1.2262330204248428e-01
    z[5,3,6]  R2428     -8.0017736181616783e-03
    z[5,3,6]  R2429     1.6017764806747437e-01
    z[5,3,6]  R2430     -0.129512757062912
    z[5,3,6]  R2431     -3.3758670091629028e-01
    z[5,3,6]  R2432     8.1064760684967041e-02
    z[5,3,6]  R2433     -3.6736443638801575e-01
    z[5,3,6]  R2434     -3.8917452096939087e-01
    z[5,3,6]  R2435     -0.1804189234972
    z[5,3,6]  R2436     2.7841767668724060e-01
    z[5,3,6]  R2437     1.7514521256089211e-02
    z[5,3,6]  R2438     -1.7323812842369080e-01
    z[5,3,6]  R2439     -0.185040682554245
    z[5,3,6]  R2440     5.1151943206787109e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2491     -1
    z[4,5,0]  R2492     1
    z[4,5,0]  R2505     -0.0692228153347969
    z[4,5,0]  R2506     -1.8829548358917236e-01
    z[4,5,0]  R2507     -3.2876855134963989e-01
    z[4,5,0]  R2508     -0.364611953496933
    z[4,5,0]  R2509     -5.1757901906967163e-01
    z[4,5,0]  R2510     -4.3709689378738403e-01
    z[4,5,0]  R2511     -1.4845295250415802e-01
    z[4,5,0]  R2512     -6.5169042348861694e-01
    z[4,5,0]  R2513     4.5602847822010517e-03
    z[4,5,0]  R2514     -4.2190793156623840e-01
    z[4,5,0]  R2515     1.9931890070438385e-01
    z[4,5,0]  R2516     -1.1368344724178314e-01
    z[4,5,0]  R2517     5.8324247598648071e-01
    z[4,5,0]  R2518     6.9198060035705566e-01
    z[4,5,0]  R2519     0.673913836479187
    z[4,5,0]  R2520     5.4904800653457642e-01
    z[4,5,0]  R2521     6.6781336069107056e-01
    z[4,5,0]  R2522     0.593197226524353
    z[4,5,0]  R2523     7.4587661027908325e-01
    z[4,5,0]  R2524     7.3596894741058350e-01
    z[4,5,0]  R2525     5.3640419244766235e-01
    z[4,5,0]  R2526     2.8914016485214233e-01
    z[4,5,0]  R2527     4.8537275195121765e-01
    z[4,5,0]  R2528     5.3979862481355667e-02
    z[4,5,0]  R2529     8.1701517105102539e-02
    z[4,5,0]  R2530     -5.5371288908645511e-04
    z[4,5,0]  R2531     2.7030816674232483e-01
    z[4,5,0]  R2532     3.8807886838912964e-01
    z[4,5,0]  R2533     5.0469088554382324e-01
    z[4,5,0]  R2534     9.1751128435134888e-02
    z[4,5,0]  R2535     -2.9391407966613770e-01
    z[4,5,0]  R2536     3.5134589672088623e-01
    z[4,5,0]  R2537     1.8095086514949799e-01
    z[4,5,0]  R2538     4.5932576060295105e-02
    z[4,5,0]  R2539     0.0817050188779831
    z[4,5,0]  R2540     1.5777802467346191e-01
    z[4,5,0]  R2541     -2.8450459241867065e-01
    z[4,5,0]  R2542     -2.5793009996414185e-01
    z[4,5,0]  R2543     2.9511460661888123e-01
    z[4,5,0]  R2544     -8.0357983708381653e-02
    z[4,5,0]  R2545     -2.6397609710693359e-01
    z[4,5,0]  R2546     -7.9158611595630646e-02
    z[4,5,0]  R2547     -1.3939459621906281e-01
    z[4,5,0]  R2548     3.3405673503875732e-01
    z[4,5,0]  R2549     -3.1011231243610382e-02
    z[4,5,0]  R2550     -2.3243987560272217e-01
    z[4,5,0]  R2551     6.5164053812623024e-03
    z[4,5,0]  R2552     -1.2624450027942657e-01
    z[4,5,0]  R2553     3.0309295654296875e-01
    z[4,5,0]  R2554     -6.2123370170593262e-01
    z[4,5,0]  R2555     -1.2315837293863297e-01
    z[4,5,0]  R2556     -7.4878519773483276e-01
    z[4,5,0]  R2557     1.7647108435630798e-01
    z[4,5,0]  R2558     -7.7983301877975464e-01
    z[4,5,0]  R2559     -4.7811153531074524e-01
    z[4,5,0]  R2560     -3.9945331215858459e-01
    z[4,5,0]  R2561     -7.3482406139373779e-01
    z[4,5,0]  R2562     -5.1747697591781616e-01
    z[4,5,0]  R2563     -5.3739684820175171e-01
    z[4,5,0]  R2564     5.9888356924057007e-01
    z[4,5,0]  R2565     1.9250044226646423e-01
    z[4,5,0]  R2566     3.4843954443931580e-01
    z[4,5,0]  R2567     -1.4973483979701996e-01
    z[4,5,0]  R2568     5.2489286661148071e-01
    z[4,5,0]  R2569     7.5461953878402710e-01
    z[4,5,0]  R2570     6.6458392143249512e-01
    z[4,5,0]  R2571     -2.1477121859788895e-02
    z[4,5,0]  R2572     0.493700236082077
    z[4,5,0]  R2573     5.5405634641647339e-01
    z[4,5,0]  R2574     -3.0755949020385742e-01
    z[4,5,0]  R2575     5.7791608572006226e-01
    z[4,5,0]  R2576     3.1935986876487732e-01
    z[4,5,0]  R2577     -5.7855671644210815e-01
    z[4,5,0]  R2578     2.0953913033008575e-01
    z[4,5,0]  R2579     2.7045177295804024e-02
    z[4,5,0]  R2580     1.8525169789791107e-01
    z[4,5,0]  R2581     7.2206068038940430e-01
    z[4,5,0]  R2582     0.537449300289154
    z[4,5,0]  R2583     7.2452224791049957e-02
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2493     -1
    z[4,5,1]  R2494     1
    z[4,5,1]  R2505     7.7890682220458984e-01
    z[4,5,1]  R2506     6.7440932989120483e-01
    z[4,5,1]  R2507     0.812924325466156
    z[4,5,1]  R2508     0.594958484172821
    z[4,5,1]  R2509     6.1003899574279785e-01
    z[4,5,1]  R2510     5.5178344249725342e-01
    z[4,5,1]  R2511     5.8253526687622070e-01
    z[4,5,1]  R2512     5.1752042770385742e-01
    z[4,5,1]  R2513     5.7960999011993408e-01
    z[4,5,1]  R2514     -4.8534622788429260e-01
    z[4,5,1]  R2515     -6.8122231960296631e-01
    z[4,5,1]  R2516     -6.4879775047302246e-01
    z[4,5,1]  R2517     -4.6633762121200562e-01
    z[4,5,1]  R2518     -4.0039667487144470e-01
    z[4,5,1]  R2519     -4.0915042161941528e-01
    z[4,5,1]  R2520     -3.6398413777351379e-01
    z[4,5,1]  R2521     -5.5775296688079834e-01
    z[4,5,1]  R2522     -4.2307758331298828e-01
    z[4,5,1]  R2523     -3.9859792590141296e-01
    z[4,5,1]  R2524     -0.547124445438385
    z[4,5,1]  R2525     -2.6161062717437744e-01
    z[4,5,1]  R2526     -1.8674476444721222e-01
    z[4,5,1]  R2527     1.7809976637363434e-01
    z[4,5,1]  R2528     -4.5620836317539215e-02
    z[4,5,1]  R2529     -2.5697553157806396e-01
    z[4,5,1]  R2530     -0.725864589214325
    z[4,5,1]  R2531     -5.9336471557617188e-01
    z[4,5,1]  R2532     -1.5418398380279541e-01
    z[4,5,1]  R2533     -7.1462118625640869e-01
    z[4,5,1]  R2534     8.7547320127487183e-01
    z[4,5,1]  R2535     8.5558646917343140e-01
    z[4,5,1]  R2536     7.4692708253860474e-01
    z[4,5,1]  R2537     7.0906698703765869e-01
    z[4,5,1]  R2538     6.2525153160095215e-01
    z[4,5,1]  R2539     6.2553548812866211e-01
    z[4,5,1]  R2540     4.2846208810806274e-01
    z[4,5,1]  R2541     6.0804325342178345e-01
    z[4,5,1]  R2542     2.9897719621658325e-01
    z[4,5,1]  R2543     6.6439443826675415e-01
    z[4,5,1]  R2544     -9.2065292596817017e-01
    z[4,5,1]  R2545     -9.4883036613464355e-01
    z[4,5,1]  R2546     -8.4418761730194092e-01
    z[4,5,1]  R2547     -8.5557991266250610e-01
    z[4,5,1]  R2548     -8.8591217994689941e-01
    z[4,5,1]  R2549     -8.5599416494369507e-01
    z[4,5,1]  R2550     -0.837941586971283
    z[4,5,1]  R2551     -8.3161729574203491e-01
    z[4,5,1]  R2552     -8.2682949304580688e-01
    z[4,5,1]  R2553     -8.9267814159393311e-01
    z[4,5,1]  R2554     -9.1890551149845123e-02
    z[4,5,1]  R2555     -1.7950126528739929e-01
    z[4,5,1]  R2556     3.0340716242790222e-01
    z[4,5,1]  R2557     2.9247373342514038e-01
    z[4,5,1]  R2558     1.9021998345851898e-01
    z[4,5,1]  R2559     2.6451054215431213e-01
    z[4,5,1]  R2560     1.7234939336776733e-01
    z[4,5,1]  R2561     4.5606139302253723e-01
    z[4,5,1]  R2562     3.7726444005966187e-01
    z[4,5,1]  R2563     -2.4689415469765663e-02
    z[4,5,1]  R2564     -1.1694305390119553e-01
    z[4,5,1]  R2565     -6.3666746020317078e-02
    z[4,5,1]  R2566     -5.9154576063156128e-01
    z[4,5,1]  R2567     7.1902751922607422e-02
    z[4,5,1]  R2568     -5.9003078937530518e-01
    z[4,5,1]  R2569     -5.4779714345932007e-01
    z[4,5,1]  R2570     -5.7059872150421143e-01
    z[4,5,1]  R2571     -6.3786470890045166e-01
    z[4,5,1]  R2572     -6.7252731323242188e-01
    z[4,5,1]  R2573     -6.6398131847381592e-01
    z[4,5,1]  R2574     4.1244527697563171e-01
    z[4,5,1]  R2575     2.9022064805030823e-01
    z[4,5,1]  R2576     0.279297411441803
    z[4,5,1]  R2577     -0.230604350566864
    z[4,5,1]  R2578     1.7475579679012299e-01
    z[4,5,1]  R2579     8.5760280489921570e-02
    z[4,5,1]  R2580     -3.2181721925735474e-01
    z[4,5,1]  R2581     -2.1566207706928253e-01
    z[4,5,1]  R2582     -3.5702559351921082e-01
    z[4,5,1]  R2583     -6.3930189609527588e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2495     -1
    z[4,5,2]  R2496     1
    z[4,5,2]  R2505     -2.9798674583435059e-01
    z[4,5,2]  R2506     -0.347235769033432
    z[4,5,2]  R2507     -7.6188750565052032e-02
    z[4,5,2]  R2508     2.3774772882461548e-01
    z[4,5,2]  R2509     -0.0581904798746109
    z[4,5,2]  R2510     4.2077171802520752e-01
    z[4,5,2]  R2511     -2.3059609532356262e-01
    z[4,5,2]  R2512     1.4783754944801331e-01
    z[4,5,2]  R2513     -4.7947093844413757e-01
    z[4,5,2]  R2514     -1.1642266064882278e-01
    z[4,5,2]  R2515     3.3215153217315674e-01
    z[4,5,2]  R2516     2.8857752680778503e-01
    z[4,5,2]  R2517     5.6902801990509033e-01
    z[4,5,2]  R2518     0.561430811882019
    z[4,5,2]  R2519     5.6609356403350830e-01
    z[4,5,2]  R2520     6.9370740652084351e-01
    z[4,5,2]  R2521     4.2793425917625427e-01
    z[4,5,2]  R2522     4.9629786610603333e-01
    z[4,5,2]  R2523     2.9269164800643921e-01
    z[4,5,2]  R2524     2.1162860095500946e-01
    z[4,5,2]  R2525     -3.2568764686584473e-01
    z[4,5,2]  R2526     -1.9889141619205475e-01
    z[4,5,2]  R2527     -1.4858931303024292e-01
    z[4,5,2]  R2528     2.5257551670074463e-01
    z[4,5,2]  R2529     -4.2722240090370178e-02
    z[4,5,2]  R2530     3.6074250936508179e-01
    z[4,5,2]  R2531     1.5408769249916077e-01
    z[4,5,2]  R2532     5.6516725569963455e-02
    z[4,5,2]  R2533     -2.8202304244041443e-01
    z[4,5,2]  R2534     2.2204430401325226e-01
    z[4,5,2]  R2535     -6.9286718964576721e-02
    z[4,5,2]  R2536     1.0267228819429874e-02
    z[4,5,2]  R2537     -3.1002461910247803e-02
    z[4,5,2]  R2538     1.0819110274314880e-01
    z[4,5,2]  R2539     -3.7111940979957581e-01
    z[4,5,2]  R2540     7.5985920429229736e-01
    z[4,5,2]  R2541     -2.4186022579669952e-01
    z[4,5,2]  R2542     7.5410521030426025e-01
    z[4,5,2]  R2543     -4.7407627105712891e-01
    z[4,5,2]  R2544     2.6614934206008911e-01
    z[4,5,2]  R2545     -4.7693509608507156e-02
    z[4,5,2]  R2546     2.5060348212718964e-02
    z[4,5,2]  R2547     -2.1321940422058105e-01
    z[4,5,2]  R2548     0.201337531208992
    z[4,5,2]  R2549     -2.9549381136894226e-01
    z[4,5,2]  R2550     -1.6530798375606537e-01
    z[4,5,2]  R2551     0.0824781134724617
    z[4,5,2]  R2552     -6.8636782467365265e-02
    z[4,5,2]  R2553     1.6016195714473724e-01
    z[4,5,2]  R2554     -4.8945721983909607e-01
    z[4,5,2]  R2555     5.1430130004882812e-01
    z[4,5,2]  R2556     3.4037387371063232e-01
    z[4,5,2]  R2557     -8.9806658029556274e-01
    z[4,5,2]  R2558     -0.0916375145316124
    z[4,5,2]  R2559     3.0163705348968506e-02
    z[4,5,2]  R2560     -4.7916686534881592e-01
    z[4,5,2]  R2561     -1.5109807252883911e-01
    z[4,5,2]  R2562     -3.7307778000831604e-01
    z[4,5,2]  R2563     -9.4032082706689835e-03
    z[4,5,2]  R2564     8.0027438700199127e-02
    z[4,5,2]  R2565     -5.8725923299789429e-02
    z[4,5,2]  R2566     1.0964184254407883e-01
    z[4,5,2]  R2567     -7.3334950208663940e-01
    z[4,5,2]  R2568     4.0528017282485962e-01
    z[4,5,2]  R2569     0.284252792596817
    z[4,5,2]  R2570     3.6815294623374939e-01
    z[4,5,2]  R2571     1.5899296104907990e-01
    z[4,5,2]  R2572     4.2180046439170837e-01
    z[4,5,2]  R2573     4.2704778909683228e-01
    z[4,5,2]  R2574     -5.3261661529541016e-01
    z[4,5,2]  R2575     -4.9754548072814941e-01
    z[4,5,2]  R2576     4.1682365536689758e-01
    z[4,5,2]  R2577     -9.4092383980751038e-02
    z[4,5,2]  R2578     6.6872701048851013e-02
    z[4,5,2]  R2579     5.3215879201889038e-01
    z[4,5,2]  R2580     4.9683311581611633e-01
    z[4,5,2]  R2581     4.9082070589065552e-01
    z[4,5,2]  R2582     6.5681940317153931e-01
    z[4,5,2]  R2583     6.7451059818267822e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2497     -1
    z[4,5,3]  R2498     1
    z[4,5,3]  R2505     -2.7236613631248474e-01
    z[4,5,3]  R2506     4.8791030049324036e-01
    z[4,5,3]  R2507     1.8327637016773224e-01
    z[4,5,3]  R2508     4.3993502855300903e-01
    z[4,5,3]  R2509     2.8136044740676880e-01
    z[4,5,3]  R2510     -1.7711807787418365e-01
    z[4,5,3]  R2511     -1.3692776858806610e-01
    z[4,5,3]  R2512     -2.7051979303359985e-01
    z[4,5,3]  R2513     9.7662389278411865e-02
    z[4,5,3]  R2514     -2.1610608696937561e-01
    z[4,5,3]  R2515     -3.7701785564422607e-01
    z[4,5,3]  R2516     -6.3731677830219269e-02
    z[4,5,3]  R2517     -4.6401996165513992e-02
    z[4,5,3]  R2518     -8.5805654525756836e-02
    z[4,5,3]  R2519     -1.5014901757240295e-01
    z[4,5,3]  R2520     -5.4991997778415680e-02
    z[4,5,3]  R2521     1.2495151162147522e-01
    z[4,5,3]  R2522     7.7261097729206085e-02
    z[4,5,3]  R2523     -4.2161926627159119e-02
    z[4,5,3]  R2524     8.5739880800247192e-02
    z[4,5,3]  R2525     -7.1150410175323486e-01
    z[4,5,3]  R2526     -6.3634729385375977e-01
    z[4,5,3]  R2527     -7.4254709482192993e-01
    z[4,5,3]  R2528     -7.9481166601181030e-01
    z[4,5,3]  R2529     -5.0166660547256470e-01
    z[4,5,3]  R2530     -0.315601110458374
    z[4,5,3]  R2531     -5.9093427658081055e-01
    z[4,5,3]  R2532     -6.3995629549026489e-01
    z[4,5,3]  R2533     1.8050726503133774e-02
    z[4,5,3]  R2534     -1.7188473045825958e-01
    z[4,5,3]  R2535     1.8126615881919861e-01
    z[4,5,3]  R2536     4.3439182639122009e-01
    z[4,5,3]  R2537     -1.2478467077016830e-01
    z[4,5,3]  R2538     1.9832178950309753e-01
    z[4,5,3]  R2539     4.3204563856124878e-01
    z[4,5,3]  R2540     1.1489140801131725e-02
    z[4,5,3]  R2541     -4.0967710316181183e-02
    z[4,5,3]  R2542     4.8574271798133850e-01
    z[4,5,3]  R2543     -4.3506991118192673e-02
    z[4,5,3]  R2544     -4.6891830861568451e-02
    z[4,5,3]  R2545     -2.8363440185785294e-02
    z[4,5,3]  R2546     1.3611934147775173e-02
    z[4,5,3]  R2547     -0.0231669619679451
    z[4,5,3]  R2548     2.2896258533000946e-01
    z[4,5,3]  R2549     3.4761503338813782e-01
    z[4,5,3]  R2550     2.6514670252799988e-01
    z[4,5,3]  R2551     1.0575447231531143e-01
    z[4,5,3]  R2552     4.9875143170356750e-01
    z[4,5,3]  R2553     7.5762018561363220e-02
    z[4,5,3]  R2554     -2.3659074306488037e-01
    z[4,5,3]  R2555     -2.6496499776840210e-01
    z[4,5,3]  R2556     -1.8247883021831512e-01
    z[4,5,3]  R2557     -2.2330953180789948e-01
    z[4,5,3]  R2558     -1.5001441538333893e-01
    z[4,5,3]  R2559     -4.4930616021156311e-01
    z[4,5,3]  R2560     -2.6776903867721558e-01
    z[4,5,3]  R2561     9.8131135106086731e-02
    z[4,5,3]  R2562     -2.6228803396224976e-01
    z[4,5,3]  R2563     -1.6434629261493683e-01
    z[4,5,3]  R2564     -6.9557195901870728e-01
    z[4,5,3]  R2565     -0.846520185470581
    z[4,5,3]  R2566     -4.7702023386955261e-01
    z[4,5,3]  R2567     -4.8704613000154495e-02
    z[4,5,3]  R2568     -1.0013290494680405e-01
    z[4,5,3]  R2569     -9.7566343843936920e-02
    z[4,5,3]  R2570     -8.4781445562839508e-02
    z[4,5,3]  R2571     -0.349507600069046
    z[4,5,3]  R2572     -4.1402030736207962e-02
    z[4,5,3]  R2573     1.7861567437648773e-01
    z[4,5,3]  R2574     -4.2533260583877563e-01
    z[4,5,3]  R2575     -2.0311589539051056e-01
    z[4,5,3]  R2576     -2.9586234688758850e-01
    z[4,5,3]  R2577     1.5119914710521698e-01
    z[4,5,3]  R2578     -4.7901135683059692e-01
    z[4,5,3]  R2579     -7.7033668756484985e-01
    z[4,5,3]  R2580     -5.8633148670196533e-01
    z[4,5,3]  R2581     -2.6660934090614319e-01
    z[4,5,3]  R2582     1.6089810431003571e-01
    z[4,5,3]  R2583     3.4706801176071167e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2499     -1
    z[4,5,4]  R2500     1
    z[4,5,4]  R2505     4.3432092666625977e-01
    z[4,5,4]  R2506     3.4715458750724792e-01
    z[4,5,4]  R2507     4.3599805235862732e-01
    z[4,5,4]  R2508     6.2857642769813538e-02
    z[4,5,4]  R2509     1.6727188229560852e-01
    z[4,5,4]  R2510     3.2528951764106750e-01
    z[4,5,4]  R2511     -4.4658705592155457e-02
    z[4,5,4]  R2512     -1.3284756243228912e-01
    z[4,5,4]  R2513     1.2144851684570312e-01
    z[4,5,4]  R2514     4.8336514830589294e-01
    z[4,5,4]  R2515     -1.4025740325450897e-01
    z[4,5,4]  R2516     1.1695694178342819e-01
    z[4,5,4]  R2517     2.9780622571706772e-02
    z[4,5,4]  R2518     -0.113673135638237
    z[4,5,4]  R2519     9.4564080238342285e-02
    z[4,5,4]  R2520     -2.2984115406870842e-02
    z[4,5,4]  R2521     1.2909808754920959e-01
    z[4,5,4]  R2522     -1.5918545424938202e-01
    z[4,5,4]  R2523     -1.1347037553787231e-01
    z[4,5,4]  R2524     -1.8654270470142365e-01
    z[4,5,4]  R2525     1.5339119732379913e-01
    z[4,5,4]  R2526     -8.2135021686553955e-02
    z[4,5,4]  R2527     8.2185156643390656e-02
    z[4,5,4]  R2528     -1.1228418350219727e-01
    z[4,5,4]  R2529     2.6528099179267883e-01
    z[4,5,4]  R2530     -4.2539444565773010e-01
    z[4,5,4]  R2531     9.4021543860435486e-02
    z[4,5,4]  R2532     -4.5273822546005249e-01
    z[4,5,4]  R2533     -0.379819393157959
    z[4,5,4]  R2534     2.3010133206844330e-01
    z[4,5,4]  R2535     3.4058505296707153e-01
    z[4,5,4]  R2536     1.6457255184650421e-01
    z[4,5,4]  R2537     1.1215513199567795e-01
    z[4,5,4]  R2538     2.1339850500226021e-03
    z[4,5,4]  R2539     2.0488698035478592e-02
    z[4,5,4]  R2540     1.5322379767894745e-02
    z[4,5,4]  R2541     6.2139028310775757e-01
    z[4,5,4]  R2542     4.9387805163860321e-02
    z[4,5,4]  R2543     1.4650250971317291e-01
    z[4,5,4]  R2544     -1.3256011903285980e-01
    z[4,5,4]  R2545     3.7601027637720108e-02
    z[4,5,4]  R2546     -3.1871777772903442e-01
    z[4,5,4]  R2547     2.6871031522750854e-01
    z[4,5,4]  R2548     4.8271864652633667e-02
    z[4,5,4]  R2549     2.1161170303821564e-01
    z[4,5,4]  R2550     -3.2673040404915810e-03
    z[4,5,4]  R2551     0.360588401556015
    z[4,5,4]  R2552     0.0846773162484169
    z[4,5,4]  R2553     0.078289695084095
    z[4,5,4]  R2554     -2.1471163630485535e-01
    z[4,5,4]  R2555     4.7779548168182373e-01
    z[4,5,4]  R2556     -1.5561152994632721e-01
    z[4,5,4]  R2557     6.5029174089431763e-02
    z[4,5,4]  R2558     -5.4568547010421753e-01
    z[4,5,4]  R2559     -2.0039555430412292e-01
    z[4,5,4]  R2560     -6.9484390318393707e-02
    z[4,5,4]  R2561     -3.6225995421409607e-01
    z[4,5,4]  R2562     -3.3178317546844482e-01
    z[4,5,4]  R2563     -4.5058351755142212e-01
    z[4,5,4]  R2564     -1.4191937446594238e-01
    z[4,5,4]  R2565     -3.5129639506340027e-01
    z[4,5,4]  R2566     -2.0226357877254486e-01
    z[4,5,4]  R2567     -1.7484459280967712e-01
    z[4,5,4]  R2568     -2.4712309241294861e-01
    z[4,5,4]  R2569     -1.8820452690124512e-01
    z[4,5,4]  R2570     -7.1713291108608246e-02
    z[4,5,4]  R2571     -3.2527527213096619e-01
    z[4,5,4]  R2572     -3.5218662023544312e-01
    z[4,5,4]  R2573     0.144295796751976
    z[4,5,4]  R2574     -3.9359182119369507e-01
    z[4,5,4]  R2575     5.1760542392730713e-01
    z[4,5,4]  R2576     6.9337749481201172e-01
    z[4,5,4]  R2577     3.5283794999122620e-01
    z[4,5,4]  R2578     5.1066315174102783e-01
    z[4,5,4]  R2579     -2.9012659192085266e-01
    z[4,5,4]  R2580     -1.2565696239471436e-01
    z[4,5,4]  R2581     -2.2074703872203827e-01
    z[4,5,4]  R2582     2.0937354862689972e-01
    z[4,5,4]  R2583     -5.6084852665662766e-02
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2501     -1
    z[4,5,5]  R2502     1
    z[4,5,5]  R2505     -1.1757581681013107e-01
    z[4,5,5]  R2506     -6.0707405209541321e-02
    z[4,5,5]  R2507     6.5165506675839424e-03
    z[4,5,5]  R2508     -3.0680984258651733e-01
    z[4,5,5]  R2509     1.6882508993148804e-01
    z[4,5,5]  R2510     -4.3570473790168762e-01
    z[4,5,5]  R2511     2.8054052591323853e-01
    z[4,5,5]  R2512     -3.7503218650817871e-01
    z[4,5,5]  R2513     4.0232893824577332e-01
    z[4,5,5]  R2514     8.7758600711822510e-02
    z[4,5,5]  R2515     -2.8529292345046997e-01
    z[4,5,5]  R2516     -1.2879328429698944e-01
    z[4,5,5]  R2517     3.3906564116477966e-01
    z[4,5,5]  R2518     1.3632264733314514e-01
    z[4,5,5]  R2519     1.3902534544467926e-01
    z[4,5,5]  R2520     1.9321456551551819e-01
    z[4,5,5]  R2521     1.4572256803512573e-01
    z[4,5,5]  R2522     3.3065313100814819e-01
    z[4,5,5]  R2523     3.3350548148155212e-01
    z[4,5,5]  R2524     2.5434008240699768e-01
    z[4,5,5]  R2525     0.0653185248374939
    z[4,5,5]  R2526     6.4751470088958740e-01
    z[4,5,5]  R2527     -2.3476819694042206e-01
    z[4,5,5]  R2528     4.9129912257194519e-01
    z[4,5,5]  R2529     3.8730046153068542e-01
    z[4,5,5]  R2530     2.4547970294952393e-01
    z[4,5,5]  R2531     -4.3531551957130432e-01
    z[4,5,5]  R2532     2.4686281383037567e-01
    z[4,5,5]  R2533     5.7919424027204514e-02
    z[4,5,5]  R2534     1.6349695622920990e-02
    z[4,5,5]  R2535     4.0406482294201851e-03
    z[4,5,5]  R2536     -2.8824573755264282e-01
    z[4,5,5]  R2537     6.4108437299728394e-01
    z[4,5,5]  R2538     2.6808005571365356e-01
    z[4,5,5]  R2539     3.5143008828163147e-01
    z[4,5,5]  R2540     -1.1392273753881454e-01
    z[4,5,5]  R2541     2.9049047827720642e-01
    z[4,5,5]  R2542     1.9229158759117126e-01
    z[4,5,5]  R2543     -1.3685730099678040e-01
    z[4,5,5]  R2544     2.3453648388385773e-01
    z[4,5,5]  R2545     -0.155681312084198
    z[4,5,5]  R2546     -2.1839885041117668e-02
    z[4,5,5]  R2547     1.5839838981628418e-01
    z[4,5,5]  R2548     9.0267747640609741e-02
    z[4,5,5]  R2549     1.0915318131446838e-01
    z[4,5,5]  R2550     2.9655680060386658e-01
    z[4,5,5]  R2551     1.3262277841567993e-01
    z[4,5,5]  R2552     -0.0666360929608345
    z[4,5,5]  R2553     -2.6828205585479736e-01
    z[4,5,5]  R2554     2.8831627964973450e-01
    z[4,5,5]  R2555     6.0940408706665039e-01
    z[4,5,5]  R2556     -2.6306754350662231e-01
    z[4,5,5]  R2557     3.0098492279648781e-03
    z[4,5,5]  R2558     1.1404132843017578e-01
    z[4,5,5]  R2559     -3.3031675219535828e-01
    z[4,5,5]  R2560     -2.3639994859695435e-01
    z[4,5,5]  R2561     -1.1001867055892944e-01
    z[4,5,5]  R2562     -3.6067163944244385e-01
    z[4,5,5]  R2563     5.5549168586730957e-01
    z[4,5,5]  R2564     3.3442208170890808e-01
    z[4,5,5]  R2565     2.1022740006446838e-01
    z[4,5,5]  R2566     4.3663203716278076e-01
    z[4,5,5]  R2567     5.2558046579360962e-01
    z[4,5,5]  R2568     3.7022992968559265e-01
    z[4,5,5]  R2569     2.5225467979907990e-02
    z[4,5,5]  R2570     2.4903084337711334e-01
    z[4,5,5]  R2571     5.6108510494232178e-01
    z[4,5,5]  R2572     1.4927624724805355e-02
    z[4,5,5]  R2573     9.7732760012149811e-02
    z[4,5,5]  R2574     2.3926517367362976e-01
    z[4,5,5]  R2575     1.5449105203151703e-01
    z[4,5,5]  R2576     -6.4368017017841339e-02
    z[4,5,5]  R2577     6.5900111198425293e-01
    z[4,5,5]  R2578     -1.0784979909658432e-01
    z[4,5,5]  R2579     1.7631146311759949e-01
    z[4,5,5]  R2580     0.00893962662667036
    z[4,5,5]  R2581     5.4915450513362885e-02
    z[4,5,5]  R2582     -2.6482370495796204e-01
    z[4,5,5]  R2583     0.0788489356637001
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2503     -1
    z[4,5,6]  R2504     1
    z[4,5,6]  R2505     -1.5190209448337555e-01
    z[4,5,6]  R2506     -0.163969486951828
    z[4,5,6]  R2507     -3.9161231368780136e-02
    z[4,5,6]  R2508     -4.0611866116523743e-01
    z[4,5,6]  R2509     -4.7003483772277832e-01
    z[4,5,6]  R2510     -2.0241707563400269e-02
    z[4,5,6]  R2511     -6.9713217020034790e-01
    z[4,5,6]  R2512     0.232675239443779
    z[4,5,6]  R2513     4.9797871708869934e-01
    z[4,5,6]  R2514     5.3369772434234619e-01
    z[4,5,6]  R2515     -3.7772583961486816e-01
    z[4,5,6]  R2516     -6.6972541809082031e-01
    z[4,5,6]  R2517     -2.3642625659704208e-02
    z[4,5,6]  R2518     8.2296334207057953e-02
    z[4,5,6]  R2519     8.4611341357231140e-02
    z[4,5,6]  R2520     2.0963713526725769e-01
    z[4,5,6]  R2521     7.9340517520904541e-02
    z[4,5,6]  R2522     2.8665328025817871e-01
    z[4,5,6]  R2523     2.7062943577766418e-01
    z[4,5,6]  R2524     -0.0859035924077034
    z[4,5,6]  R2525     -0.061029102653265
    z[4,5,6]  R2526     -1.0491538792848587e-01
    z[4,5,6]  R2527     3.1203892827033997e-01
    z[4,5,6]  R2528     -2.1331250667572021e-01
    z[4,5,6]  R2529     -6.7336338758468628e-01
    z[4,5,6]  R2530     -4.6480432152748108e-02
    z[4,5,6]  R2531     -5.9714134782552719e-02
    z[4,5,6]  R2532     3.8336774706840515e-01
    z[4,5,6]  R2533     8.4399670362472534e-02
    z[4,5,6]  R2534     3.0506783723831177e-01
    z[4,5,6]  R2535     -1.6707411408424377e-01
    z[4,5,6]  R2536     -1.4030157029628754e-01
    z[4,5,6]  R2537     -1.5614232420921326e-01
    z[4,5,6]  R2538     -6.9573158025741577e-01
    z[4,5,6]  R2539     3.9206331968307495e-01
    z[4,5,6]  R2540     -4.4810160994529724e-01
    z[4,5,6]  R2541     -1.3658446073532104e-01
    z[4,5,6]  R2542     6.9953277707099915e-03
    z[4,5,6]  R2543     -4.5238631963729858e-01
    z[4,5,6]  R2544     -1.8078187480568886e-02
    z[4,5,6]  R2545     3.6166332662105560e-02
    z[4,5,6]  R2546     -4.2214909195899963e-01
    z[4,5,6]  R2547     3.2443445920944214e-01
    z[4,5,6]  R2548     -1.1246681213378906e-02
    z[4,5,6]  R2549     0.0382811576128006
    z[4,5,6]  R2550     -2.4132886528968811e-01
    z[4,5,6]  R2551     -3.7785002589225769e-01
    z[4,5,6]  R2552     -1.8799139559268951e-01
    z[4,5,6]  R2553     -4.2002037167549133e-02
    z[4,5,6]  R2554     4.2526909708976746e-01
    z[4,5,6]  R2555     1.3504503667354584e-01
    z[4,5,6]  R2556     3.2356211543083191e-01
    z[4,5,6]  R2557     1.5062689781188965e-01
    z[4,5,6]  R2558     -1.1830971390008926e-01
    z[4,5,6]  R2559     5.9109228849411011e-01
    z[4,5,6]  R2560     6.6986465454101562e-01
    z[4,5,6]  R2561     -2.7612483501434326e-01
    z[4,5,6]  R2562     3.7648779153823853e-01
    z[4,5,6]  R2563     -4.1460883617401123e-01
    z[4,5,6]  R2564     -7.3883078992366791e-02
    z[4,5,6]  R2565     2.6690849661827087e-01
    z[4,5,6]  R2566     2.3986613750457764e-01
    z[4,5,6]  R2567     -0.35416179895401
    z[4,5,6]  R2568     6.2710128724575043e-02
    z[4,5,6]  R2569     -6.3965469598770142e-02
    z[4,5,6]  R2570     -1.5120127797126770e-01
    z[4,5,6]  R2571     1.5688399970531464e-01
    z[4,5,6]  R2572     8.8956616818904877e-03
    z[4,5,6]  R2573     8.6626596748828888e-02
    z[4,5,6]  R2574     -2.4196162819862366e-01
    z[4,5,6]  R2575     -3.4563142806291580e-02
    z[4,5,6]  R2576     2.7168050408363342e-01
    z[4,5,6]  R2577     1.4697673916816711e-01
    z[4,5,6]  R2578     6.4747321605682373e-01
    z[4,5,6]  R2579     6.5576941706240177e-03
    z[4,5,6]  R2580     5.0558692216873169e-01
    z[4,5,6]  R2581     2.6151040196418762e-01
    z[4,5,6]  R2582     1.1140928417444229e-01
    z[4,5,6]  R2583     -3.5501249134540558e-02
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2584     -1
    z[5,4,0]  R2585     1
    z[5,4,0]  R2598     9.1751128435134888e-02
    z[5,4,0]  R2599     -2.9391407966613770e-01
    z[5,4,0]  R2600     3.5134589672088623e-01
    z[5,4,0]  R2601     1.8095086514949799e-01
    z[5,4,0]  R2602     4.5932576060295105e-02
    z[5,4,0]  R2603     0.0817050188779831
    z[5,4,0]  R2604     1.5777802467346191e-01
    z[5,4,0]  R2605     -2.8450459241867065e-01
    z[5,4,0]  R2606     -2.5793009996414185e-01
    z[5,4,0]  R2607     2.9511460661888123e-01
    z[5,4,0]  R2608     -8.0357983708381653e-02
    z[5,4,0]  R2609     -2.6397609710693359e-01
    z[5,4,0]  R2610     -7.9158611595630646e-02
    z[5,4,0]  R2611     -1.3939459621906281e-01
    z[5,4,0]  R2612     3.3405673503875732e-01
    z[5,4,0]  R2613     -3.1011231243610382e-02
    z[5,4,0]  R2614     -2.3243987560272217e-01
    z[5,4,0]  R2615     6.5164053812623024e-03
    z[5,4,0]  R2616     -1.2624450027942657e-01
    z[5,4,0]  R2617     3.0309295654296875e-01
    z[5,4,0]  R2618     -6.2123370170593262e-01
    z[5,4,0]  R2619     -1.2315837293863297e-01
    z[5,4,0]  R2620     -7.4878519773483276e-01
    z[5,4,0]  R2621     1.7647108435630798e-01
    z[5,4,0]  R2622     -7.7983301877975464e-01
    z[5,4,0]  R2623     -4.7811153531074524e-01
    z[5,4,0]  R2624     -3.9945331215858459e-01
    z[5,4,0]  R2625     -7.3482406139373779e-01
    z[5,4,0]  R2626     -5.1747697591781616e-01
    z[5,4,0]  R2627     -5.3739684820175171e-01
    z[5,4,0]  R2628     5.9888356924057007e-01
    z[5,4,0]  R2629     1.9250044226646423e-01
    z[5,4,0]  R2630     3.4843954443931580e-01
    z[5,4,0]  R2631     -1.4973483979701996e-01
    z[5,4,0]  R2632     5.2489286661148071e-01
    z[5,4,0]  R2633     7.5461953878402710e-01
    z[5,4,0]  R2634     6.6458392143249512e-01
    z[5,4,0]  R2635     -2.1477121859788895e-02
    z[5,4,0]  R2636     0.493700236082077
    z[5,4,0]  R2637     5.5405634641647339e-01
    z[5,4,0]  R2638     -3.0755949020385742e-01
    z[5,4,0]  R2639     5.7791608572006226e-01
    z[5,4,0]  R2640     3.1935986876487732e-01
    z[5,4,0]  R2641     -5.7855671644210815e-01
    z[5,4,0]  R2642     2.0953913033008575e-01
    z[5,4,0]  R2643     2.7045177295804024e-02
    z[5,4,0]  R2644     1.8525169789791107e-01
    z[5,4,0]  R2645     7.2206068038940430e-01
    z[5,4,0]  R2646     0.537449300289154
    z[5,4,0]  R2647     7.2452224791049957e-02
    z[5,4,0]  R2648     -0.0692228153347969
    z[5,4,0]  R2649     -1.8829548358917236e-01
    z[5,4,0]  R2650     -3.2876855134963989e-01
    z[5,4,0]  R2651     -0.364611953496933
    z[5,4,0]  R2652     -5.1757901906967163e-01
    z[5,4,0]  R2653     -4.3709689378738403e-01
    z[5,4,0]  R2654     -1.4845295250415802e-01
    z[5,4,0]  R2655     -6.5169042348861694e-01
    z[5,4,0]  R2656     4.5602847822010517e-03
    z[5,4,0]  R2657     -4.2190793156623840e-01
    z[5,4,0]  R2658     1.9931890070438385e-01
    z[5,4,0]  R2659     -1.1368344724178314e-01
    z[5,4,0]  R2660     5.8324247598648071e-01
    z[5,4,0]  R2661     6.9198060035705566e-01
    z[5,4,0]  R2662     0.673913836479187
    z[5,4,0]  R2663     5.4904800653457642e-01
    z[5,4,0]  R2664     6.6781336069107056e-01
    z[5,4,0]  R2665     0.593197226524353
    z[5,4,0]  R2666     7.4587661027908325e-01
    z[5,4,0]  R2667     7.3596894741058350e-01
    z[5,4,0]  R2668     5.3640419244766235e-01
    z[5,4,0]  R2669     2.8914016485214233e-01
    z[5,4,0]  R2670     4.8537275195121765e-01
    z[5,4,0]  R2671     5.3979862481355667e-02
    z[5,4,0]  R2672     8.1701517105102539e-02
    z[5,4,0]  R2673     -5.5371288908645511e-04
    z[5,4,0]  R2674     2.7030816674232483e-01
    z[5,4,0]  R2675     3.8807886838912964e-01
    z[5,4,0]  R2676     5.0469088554382324e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2586     -1
    z[5,4,1]  R2587     1
    z[5,4,1]  R2598     8.7547320127487183e-01
    z[5,4,1]  R2599     8.5558646917343140e-01
    z[5,4,1]  R2600     7.4692708253860474e-01
    z[5,4,1]  R2601     7.0906698703765869e-01
    z[5,4,1]  R2602     6.2525153160095215e-01
    z[5,4,1]  R2603     6.2553548812866211e-01
    z[5,4,1]  R2604     4.2846208810806274e-01
    z[5,4,1]  R2605     6.0804325342178345e-01
    z[5,4,1]  R2606     2.9897719621658325e-01
    z[5,4,1]  R2607     6.6439443826675415e-01
    z[5,4,1]  R2608     -9.2065292596817017e-01
    z[5,4,1]  R2609     -9.4883036613464355e-01
    z[5,4,1]  R2610     -8.4418761730194092e-01
    z[5,4,1]  R2611     -8.5557991266250610e-01
    z[5,4,1]  R2612     -8.8591217994689941e-01
    z[5,4,1]  R2613     -8.5599416494369507e-01
    z[5,4,1]  R2614     -0.837941586971283
    z[5,4,1]  R2615     -8.3161729574203491e-01
    z[5,4,1]  R2616     -8.2682949304580688e-01
    z[5,4,1]  R2617     -8.9267814159393311e-01
    z[5,4,1]  R2618     -9.1890551149845123e-02
    z[5,4,1]  R2619     -1.7950126528739929e-01
    z[5,4,1]  R2620     3.0340716242790222e-01
    z[5,4,1]  R2621     2.9247373342514038e-01
    z[5,4,1]  R2622     1.9021998345851898e-01
    z[5,4,1]  R2623     2.6451054215431213e-01
    z[5,4,1]  R2624     1.7234939336776733e-01
    z[5,4,1]  R2625     4.5606139302253723e-01
    z[5,4,1]  R2626     3.7726444005966187e-01
    z[5,4,1]  R2627     -2.4689415469765663e-02
    z[5,4,1]  R2628     -1.1694305390119553e-01
    z[5,4,1]  R2629     -6.3666746020317078e-02
    z[5,4,1]  R2630     -5.9154576063156128e-01
    z[5,4,1]  R2631     7.1902751922607422e-02
    z[5,4,1]  R2632     -5.9003078937530518e-01
    z[5,4,1]  R2633     -5.4779714345932007e-01
    z[5,4,1]  R2634     -5.7059872150421143e-01
    z[5,4,1]  R2635     -6.3786470890045166e-01
    z[5,4,1]  R2636     -6.7252731323242188e-01
    z[5,4,1]  R2637     -6.6398131847381592e-01
    z[5,4,1]  R2638     4.1244527697563171e-01
    z[5,4,1]  R2639     2.9022064805030823e-01
    z[5,4,1]  R2640     0.279297411441803
    z[5,4,1]  R2641     -0.230604350566864
    z[5,4,1]  R2642     1.7475579679012299e-01
    z[5,4,1]  R2643     8.5760280489921570e-02
    z[5,4,1]  R2644     -3.2181721925735474e-01
    z[5,4,1]  R2645     -2.1566207706928253e-01
    z[5,4,1]  R2646     -3.5702559351921082e-01
    z[5,4,1]  R2647     -6.3930189609527588e-01
    z[5,4,1]  R2648     7.7890682220458984e-01
    z[5,4,1]  R2649     6.7440932989120483e-01
    z[5,4,1]  R2650     0.812924325466156
    z[5,4,1]  R2651     0.594958484172821
    z[5,4,1]  R2652     6.1003899574279785e-01
    z[5,4,1]  R2653     5.5178344249725342e-01
    z[5,4,1]  R2654     5.8253526687622070e-01
    z[5,4,1]  R2655     5.1752042770385742e-01
    z[5,4,1]  R2656     5.7960999011993408e-01
    z[5,4,1]  R2657     -4.8534622788429260e-01
    z[5,4,1]  R2658     -6.8122231960296631e-01
    z[5,4,1]  R2659     -6.4879775047302246e-01
    z[5,4,1]  R2660     -4.6633762121200562e-01
    z[5,4,1]  R2661     -4.0039667487144470e-01
    z[5,4,1]  R2662     -4.0915042161941528e-01
    z[5,4,1]  R2663     -3.6398413777351379e-01
    z[5,4,1]  R2664     -5.5775296688079834e-01
    z[5,4,1]  R2665     -4.2307758331298828e-01
    z[5,4,1]  R2666     -3.9859792590141296e-01
    z[5,4,1]  R2667     -0.547124445438385
    z[5,4,1]  R2668     -2.6161062717437744e-01
    z[5,4,1]  R2669     -1.8674476444721222e-01
    z[5,4,1]  R2670     1.7809976637363434e-01
    z[5,4,1]  R2671     -4.5620836317539215e-02
    z[5,4,1]  R2672     -2.5697553157806396e-01
    z[5,4,1]  R2673     -0.725864589214325
    z[5,4,1]  R2674     -5.9336471557617188e-01
    z[5,4,1]  R2675     -1.5418398380279541e-01
    z[5,4,1]  R2676     -7.1462118625640869e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2588     -1
    z[5,4,2]  R2589     1
    z[5,4,2]  R2598     2.2204430401325226e-01
    z[5,4,2]  R2599     -6.9286718964576721e-02
    z[5,4,2]  R2600     1.0267228819429874e-02
    z[5,4,2]  R2601     -3.1002461910247803e-02
    z[5,4,2]  R2602     1.0819110274314880e-01
    z[5,4,2]  R2603     -3.7111940979957581e-01
    z[5,4,2]  R2604     7.5985920429229736e-01
    z[5,4,2]  R2605     -2.4186022579669952e-01
    z[5,4,2]  R2606     7.5410521030426025e-01
    z[5,4,2]  R2607     -4.7407627105712891e-01
    z[5,4,2]  R2608     2.6614934206008911e-01
    z[5,4,2]  R2609     -4.7693509608507156e-02
    z[5,4,2]  R2610     2.5060348212718964e-02
    z[5,4,2]  R2611     -2.1321940422058105e-01
    z[5,4,2]  R2612     0.201337531208992
    z[5,4,2]  R2613     -2.9549381136894226e-01
    z[5,4,2]  R2614     -1.6530798375606537e-01
    z[5,4,2]  R2615     0.0824781134724617
    z[5,4,2]  R2616     -6.8636782467365265e-02
    z[5,4,2]  R2617     1.6016195714473724e-01
    z[5,4,2]  R2618     -4.8945721983909607e-01
    z[5,4,2]  R2619     5.1430130004882812e-01
    z[5,4,2]  R2620     3.4037387371063232e-01
    z[5,4,2]  R2621     -8.9806658029556274e-01
    z[5,4,2]  R2622     -0.0916375145316124
    z[5,4,2]  R2623     3.0163705348968506e-02
    z[5,4,2]  R2624     -4.7916686534881592e-01
    z[5,4,2]  R2625     -1.5109807252883911e-01
    z[5,4,2]  R2626     -3.7307778000831604e-01
    z[5,4,2]  R2627     -9.4032082706689835e-03
    z[5,4,2]  R2628     8.0027438700199127e-02
    z[5,4,2]  R2629     -5.8725923299789429e-02
    z[5,4,2]  R2630     1.0964184254407883e-01
    z[5,4,2]  R2631     -7.3334950208663940e-01
    z[5,4,2]  R2632     4.0528017282485962e-01
    z[5,4,2]  R2633     0.284252792596817
    z[5,4,2]  R2634     3.6815294623374939e-01
    z[5,4,2]  R2635     1.5899296104907990e-01
    z[5,4,2]  R2636     4.2180046439170837e-01
    z[5,4,2]  R2637     4.2704778909683228e-01
    z[5,4,2]  R2638     -5.3261661529541016e-01
    z[5,4,2]  R2639     -4.9754548072814941e-01
    z[5,4,2]  R2640     4.1682365536689758e-01
    z[5,4,2]  R2641     -9.4092383980751038e-02
    z[5,4,2]  R2642     6.6872701048851013e-02
    z[5,4,2]  R2643     5.3215879201889038e-01
    z[5,4,2]  R2644     4.9683311581611633e-01
    z[5,4,2]  R2645     4.9082070589065552e-01
    z[5,4,2]  R2646     6.5681940317153931e-01
    z[5,4,2]  R2647     6.7451059818267822e-01
    z[5,4,2]  R2648     -2.9798674583435059e-01
    z[5,4,2]  R2649     -0.347235769033432
    z[5,4,2]  R2650     -7.6188750565052032e-02
    z[5,4,2]  R2651     2.3774772882461548e-01
    z[5,4,2]  R2652     -0.0581904798746109
    z[5,4,2]  R2653     4.2077171802520752e-01
    z[5,4,2]  R2654     -2.3059609532356262e-01
    z[5,4,2]  R2655     1.4783754944801331e-01
    z[5,4,2]  R2656     -4.7947093844413757e-01
    z[5,4,2]  R2657     -1.1642266064882278e-01
    z[5,4,2]  R2658     3.3215153217315674e-01
    z[5,4,2]  R2659     2.8857752680778503e-01
    z[5,4,2]  R2660     5.6902801990509033e-01
    z[5,4,2]  R2661     0.561430811882019
    z[5,4,2]  R2662     5.6609356403350830e-01
    z[5,4,2]  R2663     6.9370740652084351e-01
    z[5,4,2]  R2664     4.2793425917625427e-01
    z[5,4,2]  R2665     4.9629786610603333e-01
    z[5,4,2]  R2666     2.9269164800643921e-01
    z[5,4,2]  R2667     2.1162860095500946e-01
    z[5,4,2]  R2668     -3.2568764686584473e-01
    z[5,4,2]  R2669     -1.9889141619205475e-01
    z[5,4,2]  R2670     -1.4858931303024292e-01
    z[5,4,2]  R2671     2.5257551670074463e-01
    z[5,4,2]  R2672     -4.2722240090370178e-02
    z[5,4,2]  R2673     3.6074250936508179e-01
    z[5,4,2]  R2674     1.5408769249916077e-01
    z[5,4,2]  R2675     5.6516725569963455e-02
    z[5,4,2]  R2676     -2.8202304244041443e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2590     -1
    z[5,4,3]  R2591     1
    z[5,4,3]  R2598     -1.7188473045825958e-01
    z[5,4,3]  R2599     1.8126615881919861e-01
    z[5,4,3]  R2600     4.3439182639122009e-01
    z[5,4,3]  R2601     -1.2478467077016830e-01
    z[5,4,3]  R2602     1.9832178950309753e-01
    z[5,4,3]  R2603     4.3204563856124878e-01
    z[5,4,3]  R2604     1.1489140801131725e-02
    z[5,4,3]  R2605     -4.0967710316181183e-02
    z[5,4,3]  R2606     4.8574271798133850e-01
    z[5,4,3]  R2607     -4.3506991118192673e-02
    z[5,4,3]  R2608     -4.6891830861568451e-02
    z[5,4,3]  R2609     -2.8363440185785294e-02
    z[5,4,3]  R2610     1.3611934147775173e-02
    z[5,4,3]  R2611     -0.0231669619679451
    z[5,4,3]  R2612     2.2896258533000946e-01
    z[5,4,3]  R2613     3.4761503338813782e-01
    z[5,4,3]  R2614     2.6514670252799988e-01
    z[5,4,3]  R2615     1.0575447231531143e-01
    z[5,4,3]  R2616     4.9875143170356750e-01
    z[5,4,3]  R2617     7.5762018561363220e-02
    z[5,4,3]  R2618     -2.3659074306488037e-01
    z[5,4,3]  R2619     -2.6496499776840210e-01
    z[5,4,3]  R2620     -1.8247883021831512e-01
    z[5,4,3]  R2621     -2.2330953180789948e-01
    z[5,4,3]  R2622     -1.5001441538333893e-01
    z[5,4,3]  R2623     -4.4930616021156311e-01
    z[5,4,3]  R2624     -2.6776903867721558e-01
    z[5,4,3]  R2625     9.8131135106086731e-02
    z[5,4,3]  R2626     -2.6228803396224976e-01
    z[5,4,3]  R2627     -1.6434629261493683e-01
    z[5,4,3]  R2628     -6.9557195901870728e-01
    z[5,4,3]  R2629     -0.846520185470581
    z[5,4,3]  R2630     -4.7702023386955261e-01
    z[5,4,3]  R2631     -4.8704613000154495e-02
    z[5,4,3]  R2632     -1.0013290494680405e-01
    z[5,4,3]  R2633     -9.7566343843936920e-02
    z[5,4,3]  R2634     -8.4781445562839508e-02
    z[5,4,3]  R2635     -0.349507600069046
    z[5,4,3]  R2636     -4.1402030736207962e-02
    z[5,4,3]  R2637     1.7861567437648773e-01
    z[5,4,3]  R2638     -4.2533260583877563e-01
    z[5,4,3]  R2639     -2.0311589539051056e-01
    z[5,4,3]  R2640     -2.9586234688758850e-01
    z[5,4,3]  R2641     1.5119914710521698e-01
    z[5,4,3]  R2642     -4.7901135683059692e-01
    z[5,4,3]  R2643     -7.7033668756484985e-01
    z[5,4,3]  R2644     -5.8633148670196533e-01
    z[5,4,3]  R2645     -2.6660934090614319e-01
    z[5,4,3]  R2646     1.6089810431003571e-01
    z[5,4,3]  R2647     3.4706801176071167e-01
    z[5,4,3]  R2648     -2.7236613631248474e-01
    z[5,4,3]  R2649     4.8791030049324036e-01
    z[5,4,3]  R2650     1.8327637016773224e-01
    z[5,4,3]  R2651     4.3993502855300903e-01
    z[5,4,3]  R2652     2.8136044740676880e-01
    z[5,4,3]  R2653     -1.7711807787418365e-01
    z[5,4,3]  R2654     -1.3692776858806610e-01
    z[5,4,3]  R2655     -2.7051979303359985e-01
    z[5,4,3]  R2656     9.7662389278411865e-02
    z[5,4,3]  R2657     -2.1610608696937561e-01
    z[5,4,3]  R2658     -3.7701785564422607e-01
    z[5,4,3]  R2659     -6.3731677830219269e-02
    z[5,4,3]  R2660     -4.6401996165513992e-02
    z[5,4,3]  R2661     -8.5805654525756836e-02
    z[5,4,3]  R2662     -1.5014901757240295e-01
    z[5,4,3]  R2663     -5.4991997778415680e-02
    z[5,4,3]  R2664     1.2495151162147522e-01
    z[5,4,3]  R2665     7.7261097729206085e-02
    z[5,4,3]  R2666     -4.2161926627159119e-02
    z[5,4,3]  R2667     8.5739880800247192e-02
    z[5,4,3]  R2668     -7.1150410175323486e-01
    z[5,4,3]  R2669     -6.3634729385375977e-01
    z[5,4,3]  R2670     -7.4254709482192993e-01
    z[5,4,3]  R2671     -7.9481166601181030e-01
    z[5,4,3]  R2672     -5.0166660547256470e-01
    z[5,4,3]  R2673     -0.315601110458374
    z[5,4,3]  R2674     -5.9093427658081055e-01
    z[5,4,3]  R2675     -6.3995629549026489e-01
    z[5,4,3]  R2676     1.8050726503133774e-02
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2592     -1
    z[5,4,4]  R2593     1
    z[5,4,4]  R2598     2.3010133206844330e-01
    z[5,4,4]  R2599     3.4058505296707153e-01
    z[5,4,4]  R2600     1.6457255184650421e-01
    z[5,4,4]  R2601     1.1215513199567795e-01
    z[5,4,4]  R2602     2.1339850500226021e-03
    z[5,4,4]  R2603     2.0488698035478592e-02
    z[5,4,4]  R2604     1.5322379767894745e-02
    z[5,4,4]  R2605     6.2139028310775757e-01
    z[5,4,4]  R2606     4.9387805163860321e-02
    z[5,4,4]  R2607     1.4650250971317291e-01
    z[5,4,4]  R2608     -1.3256011903285980e-01
    z[5,4,4]  R2609     3.7601027637720108e-02
    z[5,4,4]  R2610     -3.1871777772903442e-01
    z[5,4,4]  R2611     2.6871031522750854e-01
    z[5,4,4]  R2612     4.8271864652633667e-02
    z[5,4,4]  R2613     2.1161170303821564e-01
    z[5,4,4]  R2614     -3.2673040404915810e-03
    z[5,4,4]  R2615     0.360588401556015
    z[5,4,4]  R2616     0.0846773162484169
    z[5,4,4]  R2617     0.078289695084095
    z[5,4,4]  R2618     -2.1471163630485535e-01
    z[5,4,4]  R2619     4.7779548168182373e-01
    z[5,4,4]  R2620     -1.5561152994632721e-01
    z[5,4,4]  R2621     6.5029174089431763e-02
    z[5,4,4]  R2622     -5.4568547010421753e-01
    z[5,4,4]  R2623     -2.0039555430412292e-01
    z[5,4,4]  R2624     -6.9484390318393707e-02
    z[5,4,4]  R2625     -3.6225995421409607e-01
    z[5,4,4]  R2626     -3.3178317546844482e-01
    z[5,4,4]  R2627     -4.5058351755142212e-01
    z[5,4,4]  R2628     -1.4191937446594238e-01
    z[5,4,4]  R2629     -3.5129639506340027e-01
    z[5,4,4]  R2630     -2.0226357877254486e-01
    z[5,4,4]  R2631     -1.7484459280967712e-01
    z[5,4,4]  R2632     -2.4712309241294861e-01
    z[5,4,4]  R2633     -1.8820452690124512e-01
    z[5,4,4]  R2634     -7.1713291108608246e-02
    z[5,4,4]  R2635     -3.2527527213096619e-01
    z[5,4,4]  R2636     -3.5218662023544312e-01
    z[5,4,4]  R2637     0.144295796751976
    z[5,4,4]  R2638     -3.9359182119369507e-01
    z[5,4,4]  R2639     5.1760542392730713e-01
    z[5,4,4]  R2640     6.9337749481201172e-01
    z[5,4,4]  R2641     3.5283794999122620e-01
    z[5,4,4]  R2642     5.1066315174102783e-01
    z[5,4,4]  R2643     -2.9012659192085266e-01
    z[5,4,4]  R2644     -1.2565696239471436e-01
    z[5,4,4]  R2645     -2.2074703872203827e-01
    z[5,4,4]  R2646     2.0937354862689972e-01
    z[5,4,4]  R2647     -5.6084852665662766e-02
    z[5,4,4]  R2648     4.3432092666625977e-01
    z[5,4,4]  R2649     3.4715458750724792e-01
    z[5,4,4]  R2650     4.3599805235862732e-01
    z[5,4,4]  R2651     6.2857642769813538e-02
    z[5,4,4]  R2652     1.6727188229560852e-01
    z[5,4,4]  R2653     3.2528951764106750e-01
    z[5,4,4]  R2654     -4.4658705592155457e-02
    z[5,4,4]  R2655     -1.3284756243228912e-01
    z[5,4,4]  R2656     1.2144851684570312e-01
    z[5,4,4]  R2657     4.8336514830589294e-01
    z[5,4,4]  R2658     -1.4025740325450897e-01
    z[5,4,4]  R2659     1.1695694178342819e-01
    z[5,4,4]  R2660     2.9780622571706772e-02
    z[5,4,4]  R2661     -0.113673135638237
    z[5,4,4]  R2662     9.4564080238342285e-02
    z[5,4,4]  R2663     -2.2984115406870842e-02
    z[5,4,4]  R2664     1.2909808754920959e-01
    z[5,4,4]  R2665     -1.5918545424938202e-01
    z[5,4,4]  R2666     -1.1347037553787231e-01
    z[5,4,4]  R2667     -1.8654270470142365e-01
    z[5,4,4]  R2668     1.5339119732379913e-01
    z[5,4,4]  R2669     -8.2135021686553955e-02
    z[5,4,4]  R2670     8.2185156643390656e-02
    z[5,4,4]  R2671     -1.1228418350219727e-01
    z[5,4,4]  R2672     2.6528099179267883e-01
    z[5,4,4]  R2673     -4.2539444565773010e-01
    z[5,4,4]  R2674     9.4021543860435486e-02
    z[5,4,4]  R2675     -4.5273822546005249e-01
    z[5,4,4]  R2676     -0.379819393157959
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2594     -1
    z[5,4,5]  R2595     1
    z[5,4,5]  R2598     1.6349695622920990e-02
    z[5,4,5]  R2599     4.0406482294201851e-03
    z[5,4,5]  R2600     -2.8824573755264282e-01
    z[5,4,5]  R2601     6.4108437299728394e-01
    z[5,4,5]  R2602     2.6808005571365356e-01
    z[5,4,5]  R2603     3.5143008828163147e-01
    z[5,4,5]  R2604     -1.1392273753881454e-01
    z[5,4,5]  R2605     2.9049047827720642e-01
    z[5,4,5]  R2606     1.9229158759117126e-01
    z[5,4,5]  R2607     -1.3685730099678040e-01
    z[5,4,5]  R2608     2.3453648388385773e-01
    z[5,4,5]  R2609     -0.155681312084198
    z[5,4,5]  R2610     -2.1839885041117668e-02
    z[5,4,5]  R2611     1.5839838981628418e-01
    z[5,4,5]  R2612     9.0267747640609741e-02
    z[5,4,5]  R2613     1.0915318131446838e-01
    z[5,4,5]  R2614     2.9655680060386658e-01
    z[5,4,5]  R2615     1.3262277841567993e-01
    z[5,4,5]  R2616     -0.0666360929608345
    z[5,4,5]  R2617     -2.6828205585479736e-01
    z[5,4,5]  R2618     2.8831627964973450e-01
    z[5,4,5]  R2619     6.0940408706665039e-01
    z[5,4,5]  R2620     -2.6306754350662231e-01
    z[5,4,5]  R2621     3.0098492279648781e-03
    z[5,4,5]  R2622     1.1404132843017578e-01
    z[5,4,5]  R2623     -3.3031675219535828e-01
    z[5,4,5]  R2624     -2.3639994859695435e-01
    z[5,4,5]  R2625     -1.1001867055892944e-01
    z[5,4,5]  R2626     -3.6067163944244385e-01
    z[5,4,5]  R2627     5.5549168586730957e-01
    z[5,4,5]  R2628     3.3442208170890808e-01
    z[5,4,5]  R2629     2.1022740006446838e-01
    z[5,4,5]  R2630     4.3663203716278076e-01
    z[5,4,5]  R2631     5.2558046579360962e-01
    z[5,4,5]  R2632     3.7022992968559265e-01
    z[5,4,5]  R2633     2.5225467979907990e-02
    z[5,4,5]  R2634     2.4903084337711334e-01
    z[5,4,5]  R2635     5.6108510494232178e-01
    z[5,4,5]  R2636     1.4927624724805355e-02
    z[5,4,5]  R2637     9.7732760012149811e-02
    z[5,4,5]  R2638     2.3926517367362976e-01
    z[5,4,5]  R2639     1.5449105203151703e-01
    z[5,4,5]  R2640     -6.4368017017841339e-02
    z[5,4,5]  R2641     6.5900111198425293e-01
    z[5,4,5]  R2642     -1.0784979909658432e-01
    z[5,4,5]  R2643     1.7631146311759949e-01
    z[5,4,5]  R2644     0.00893962662667036
    z[5,4,5]  R2645     5.4915450513362885e-02
    z[5,4,5]  R2646     -2.6482370495796204e-01
    z[5,4,5]  R2647     0.0788489356637001
    z[5,4,5]  R2648     -1.1757581681013107e-01
    z[5,4,5]  R2649     -6.0707405209541321e-02
    z[5,4,5]  R2650     6.5165506675839424e-03
    z[5,4,5]  R2651     -3.0680984258651733e-01
    z[5,4,5]  R2652     1.6882508993148804e-01
    z[5,4,5]  R2653     -4.3570473790168762e-01
    z[5,4,5]  R2654     2.8054052591323853e-01
    z[5,4,5]  R2655     -3.7503218650817871e-01
    z[5,4,5]  R2656     4.0232893824577332e-01
    z[5,4,5]  R2657     8.7758600711822510e-02
    z[5,4,5]  R2658     -2.8529292345046997e-01
    z[5,4,5]  R2659     -1.2879328429698944e-01
    z[5,4,5]  R2660     3.3906564116477966e-01
    z[5,4,5]  R2661     1.3632264733314514e-01
    z[5,4,5]  R2662     1.3902534544467926e-01
    z[5,4,5]  R2663     1.9321456551551819e-01
    z[5,4,5]  R2664     1.4572256803512573e-01
    z[5,4,5]  R2665     3.3065313100814819e-01
    z[5,4,5]  R2666     3.3350548148155212e-01
    z[5,4,5]  R2667     2.5434008240699768e-01
    z[5,4,5]  R2668     0.0653185248374939
    z[5,4,5]  R2669     6.4751470088958740e-01
    z[5,4,5]  R2670     -2.3476819694042206e-01
    z[5,4,5]  R2671     4.9129912257194519e-01
    z[5,4,5]  R2672     3.8730046153068542e-01
    z[5,4,5]  R2673     2.4547970294952393e-01
    z[5,4,5]  R2674     -4.3531551957130432e-01
    z[5,4,5]  R2675     2.4686281383037567e-01
    z[5,4,5]  R2676     5.7919424027204514e-02
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2596     -1
    z[5,4,6]  R2597     1
    z[5,4,6]  R2598     3.0506783723831177e-01
    z[5,4,6]  R2599     -1.6707411408424377e-01
    z[5,4,6]  R2600     -1.4030157029628754e-01
    z[5,4,6]  R2601     -1.5614232420921326e-01
    z[5,4,6]  R2602     -6.9573158025741577e-01
    z[5,4,6]  R2603     3.9206331968307495e-01
    z[5,4,6]  R2604     -4.4810160994529724e-01
    z[5,4,6]  R2605     -1.3658446073532104e-01
    z[5,4,6]  R2606     6.9953277707099915e-03
    z[5,4,6]  R2607     -4.5238631963729858e-01
    z[5,4,6]  R2608     -1.8078187480568886e-02
    z[5,4,6]  R2609     3.6166332662105560e-02
    z[5,4,6]  R2610     -4.2214909195899963e-01
    z[5,4,6]  R2611     3.2443445920944214e-01
    z[5,4,6]  R2612     -1.1246681213378906e-02
    z[5,4,6]  R2613     0.0382811576128006
    z[5,4,6]  R2614     -2.4132886528968811e-01
    z[5,4,6]  R2615     -3.7785002589225769e-01
    z[5,4,6]  R2616     -1.8799139559268951e-01
    z[5,4,6]  R2617     -4.2002037167549133e-02
    z[5,4,6]  R2618     4.2526909708976746e-01
    z[5,4,6]  R2619     1.3504503667354584e-01
    z[5,4,6]  R2620     3.2356211543083191e-01
    z[5,4,6]  R2621     1.5062689781188965e-01
    z[5,4,6]  R2622     -1.1830971390008926e-01
    z[5,4,6]  R2623     5.9109228849411011e-01
    z[5,4,6]  R2624     6.6986465454101562e-01
    z[5,4,6]  R2625     -2.7612483501434326e-01
    z[5,4,6]  R2626     3.7648779153823853e-01
    z[5,4,6]  R2627     -4.1460883617401123e-01
    z[5,4,6]  R2628     -7.3883078992366791e-02
    z[5,4,6]  R2629     2.6690849661827087e-01
    z[5,4,6]  R2630     2.3986613750457764e-01
    z[5,4,6]  R2631     -0.35416179895401
    z[5,4,6]  R2632     6.2710128724575043e-02
    z[5,4,6]  R2633     -6.3965469598770142e-02
    z[5,4,6]  R2634     -1.5120127797126770e-01
    z[5,4,6]  R2635     1.5688399970531464e-01
    z[5,4,6]  R2636     8.8956616818904877e-03
    z[5,4,6]  R2637     8.6626596748828888e-02
    z[5,4,6]  R2638     -2.4196162819862366e-01
    z[5,4,6]  R2639     -3.4563142806291580e-02
    z[5,4,6]  R2640     2.7168050408363342e-01
    z[5,4,6]  R2641     1.4697673916816711e-01
    z[5,4,6]  R2642     6.4747321605682373e-01
    z[5,4,6]  R2643     6.5576941706240177e-03
    z[5,4,6]  R2644     5.0558692216873169e-01
    z[5,4,6]  R2645     2.6151040196418762e-01
    z[5,4,6]  R2646     1.1140928417444229e-01
    z[5,4,6]  R2647     -3.5501249134540558e-02
    z[5,4,6]  R2648     -1.5190209448337555e-01
    z[5,4,6]  R2649     -0.163969486951828
    z[5,4,6]  R2650     -3.9161231368780136e-02
    z[5,4,6]  R2651     -4.0611866116523743e-01
    z[5,4,6]  R2652     -4.7003483772277832e-01
    z[5,4,6]  R2653     -2.0241707563400269e-02
    z[5,4,6]  R2654     -6.9713217020034790e-01
    z[5,4,6]  R2655     0.232675239443779
    z[5,4,6]  R2656     4.9797871708869934e-01
    z[5,4,6]  R2657     5.3369772434234619e-01
    z[5,4,6]  R2658     -3.7772583961486816e-01
    z[5,4,6]  R2659     -6.6972541809082031e-01
    z[5,4,6]  R2660     -2.3642625659704208e-02
    z[5,4,6]  R2661     8.2296334207057953e-02
    z[5,4,6]  R2662     8.4611341357231140e-02
    z[5,4,6]  R2663     2.0963713526725769e-01
    z[5,4,6]  R2664     7.9340517520904541e-02
    z[5,4,6]  R2665     2.8665328025817871e-01
    z[5,4,6]  R2666     2.7062943577766418e-01
    z[5,4,6]  R2667     -0.0859035924077034
    z[5,4,6]  R2668     -0.061029102653265
    z[5,4,6]  R2669     -1.0491538792848587e-01
    z[5,4,6]  R2670     3.1203892827033997e-01
    z[5,4,6]  R2671     -2.1331250667572021e-01
    z[5,4,6]  R2672     -6.7336338758468628e-01
    z[5,4,6]  R2673     -4.6480432152748108e-02
    z[5,4,6]  R2674     -5.9714134782552719e-02
    z[5,4,6]  R2675     3.8336774706840515e-01
    z[5,4,6]  R2676     8.4399670362472534e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2677     -1
    z[5,6,0]  R2678     1
    z[5,6,0]  R2691     9.1751128435134888e-02
    z[5,6,0]  R2692     -2.9391407966613770e-01
    z[5,6,0]  R2693     3.5134589672088623e-01
    z[5,6,0]  R2694     1.8095086514949799e-01
    z[5,6,0]  R2695     4.5932576060295105e-02
    z[5,6,0]  R2696     0.0817050188779831
    z[5,6,0]  R2697     1.5777802467346191e-01
    z[5,6,0]  R2698     -2.8450459241867065e-01
    z[5,6,0]  R2699     -2.5793009996414185e-01
    z[5,6,0]  R2700     2.9511460661888123e-01
    z[5,6,0]  R2701     -8.0357983708381653e-02
    z[5,6,0]  R2702     -2.6397609710693359e-01
    z[5,6,0]  R2703     -7.9158611595630646e-02
    z[5,6,0]  R2704     -1.3939459621906281e-01
    z[5,6,0]  R2705     3.3405673503875732e-01
    z[5,6,0]  R2706     -3.1011231243610382e-02
    z[5,6,0]  R2707     -2.3243987560272217e-01
    z[5,6,0]  R2708     6.5164053812623024e-03
    z[5,6,0]  R2709     -1.2624450027942657e-01
    z[5,6,0]  R2710     3.0309295654296875e-01
    z[5,6,0]  R2711     -6.2123370170593262e-01
    z[5,6,0]  R2712     -1.2315837293863297e-01
    z[5,6,0]  R2713     -7.4878519773483276e-01
    z[5,6,0]  R2714     1.7647108435630798e-01
    z[5,6,0]  R2715     -7.7983301877975464e-01
    z[5,6,0]  R2716     -4.7811153531074524e-01
    z[5,6,0]  R2717     -3.9945331215858459e-01
    z[5,6,0]  R2718     -7.3482406139373779e-01
    z[5,6,0]  R2719     -5.1747697591781616e-01
    z[5,6,0]  R2720     -5.3739684820175171e-01
    z[5,6,0]  R2721     5.9888356924057007e-01
    z[5,6,0]  R2722     1.9250044226646423e-01
    z[5,6,0]  R2723     3.4843954443931580e-01
    z[5,6,0]  R2724     -1.4973483979701996e-01
    z[5,6,0]  R2725     5.2489286661148071e-01
    z[5,6,0]  R2726     7.5461953878402710e-01
    z[5,6,0]  R2727     6.6458392143249512e-01
    z[5,6,0]  R2728     -2.1477121859788895e-02
    z[5,6,0]  R2729     0.493700236082077
    z[5,6,0]  R2730     5.5405634641647339e-01
    z[5,6,0]  R2731     -3.0755949020385742e-01
    z[5,6,0]  R2732     5.7791608572006226e-01
    z[5,6,0]  R2733     3.1935986876487732e-01
    z[5,6,0]  R2734     -5.7855671644210815e-01
    z[5,6,0]  R2735     2.0953913033008575e-01
    z[5,6,0]  R2736     2.7045177295804024e-02
    z[5,6,0]  R2737     1.8525169789791107e-01
    z[5,6,0]  R2738     7.2206068038940430e-01
    z[5,6,0]  R2739     0.537449300289154
    z[5,6,0]  R2740     7.2452224791049957e-02
    z[5,6,0]  R2741     -1.3540515303611755e-01
    z[5,6,0]  R2742     -1.8146499991416931e-01
    z[5,6,0]  R2743     -1.1458253115415573e-01
    z[5,6,0]  R2744     2.4590075016021729e-01
    z[5,6,0]  R2745     -1.9872394204139709e-01
    z[5,6,0]  R2746     -3.5660693049430847e-01
    z[5,6,0]  R2747     1.5453067421913147e-01
    z[5,6,0]  R2748     2.2420710325241089e-01
    z[5,6,0]  R2749     1.5158204734325409e-01
    z[5,6,0]  R2750     2.6731389760971069e-01
    z[5,6,0]  R2751     -5.2680999040603638e-01
    z[5,6,0]  R2752     3.3764970302581787e-01
    z[5,6,0]  R2753     -1.2792757153511047e-01
    z[5,6,0]  R2754     1.6103994846343994e-01
    z[5,6,0]  R2755     5.2135378122329712e-01
    z[5,6,0]  R2756     5.9990906715393066e-01
    z[5,6,0]  R2757     3.3722755312919617e-01
    z[5,6,0]  R2758     1.8013438582420349e-01
    z[5,6,0]  R2759     -0.107862688601017
    z[5,6,0]  R2760     3.6219507455825806e-01
    z[5,6,0]  R2761     1.5011836588382721e-01
    z[5,6,0]  R2762     1.5852367877960205e-01
    z[5,6,0]  R2763     -6.0171049833297729e-01
    z[5,6,0]  R2764     5.0972029566764832e-03
    z[5,6,0]  R2765     -2.3490250110626221e-01
    z[5,6,0]  R2766     -0.58235764503479
    z[5,6,0]  R2767     -3.8865572214126587e-01
    z[5,6,0]  R2768     -6.6175174713134766e-01
    z[5,6,0]  R2769     1.3481132686138153e-01
    z[5,6,0]  R2770     3.1511485576629639e-02
    z[5,6,0]  R2771     -9.6586331725120544e-02
    z[5,6,0]  R2772     -2.2670675814151764e-01
    z[5,6,0]  R2773     3.0439281463623047e-01
    z[5,6,0]  R2774     -3.5883578658103943e-01
    z[5,6,0]  R2775     -3.6778151988983154e-01
    z[5,6,0]  R2776     1.4055030420422554e-02
    z[5,6,0]  R2777     -2.7112754061818123e-02
    z[5,6,0]  R2778     1.8437290191650391e-01
    z[5,6,0]  R2779     3.1333580613136292e-01
    z[5,6,0]  R2780     1.6550573706626892e-01
    z[5,6,0]  R2781     -2.2626711428165436e-01
    z[5,6,0]  R2782     -3.5421958565711975e-01
    z[5,6,0]  R2783     1.0648952424526215e-01
    z[5,6,0]  R2784     0.0934305191040039
    z[5,6,0]  R2785     -1.3700267672538757e-01
    z[5,6,0]  R2786     -2.2628770768642426e-01
    z[5,6,0]  R2787     0.297559529542923
    z[5,6,0]  R2788     1.7040875554084778e-01
    z[5,6,0]  R2789     0.509533703327179
    z[5,6,0]  R2790     0.547876238822937
    z[5,6,0]  R2791     -1.1656825244426727e-01
    z[5,6,0]  R2792     -2.2897545248270035e-02
    z[5,6,0]  R2793     0.0225005391985178
    z[5,6,0]  R2794     -2.7690127491950989e-01
    z[5,6,0]  R2795     2.2823049128055573e-01
    z[5,6,0]  R2796     2.1646852791309357e-01
    z[5,6,0]  R2797     6.0384386777877808e-01
    z[5,6,0]  R2798     0.574550986289978
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2679     -1
    z[5,6,1]  R2680     1
    z[5,6,1]  R2691     8.7547320127487183e-01
    z[5,6,1]  R2692     8.5558646917343140e-01
    z[5,6,1]  R2693     7.4692708253860474e-01
    z[5,6,1]  R2694     7.0906698703765869e-01
    z[5,6,1]  R2695     6.2525153160095215e-01
    z[5,6,1]  R2696     6.2553548812866211e-01
    z[5,6,1]  R2697     4.2846208810806274e-01
    z[5,6,1]  R2698     6.0804325342178345e-01
    z[5,6,1]  R2699     2.9897719621658325e-01
    z[5,6,1]  R2700     6.6439443826675415e-01
    z[5,6,1]  R2701     -9.2065292596817017e-01
    z[5,6,1]  R2702     -9.4883036613464355e-01
    z[5,6,1]  R2703     -8.4418761730194092e-01
    z[5,6,1]  R2704     -8.5557991266250610e-01
    z[5,6,1]  R2705     -8.8591217994689941e-01
    z[5,6,1]  R2706     -8.5599416494369507e-01
    z[5,6,1]  R2707     -0.837941586971283
    z[5,6,1]  R2708     -8.3161729574203491e-01
    z[5,6,1]  R2709     -8.2682949304580688e-01
    z[5,6,1]  R2710     -8.9267814159393311e-01
    z[5,6,1]  R2711     -9.1890551149845123e-02
    z[5,6,1]  R2712     -1.7950126528739929e-01
    z[5,6,1]  R2713     3.0340716242790222e-01
    z[5,6,1]  R2714     2.9247373342514038e-01
    z[5,6,1]  R2715     1.9021998345851898e-01
    z[5,6,1]  R2716     2.6451054215431213e-01
    z[5,6,1]  R2717     1.7234939336776733e-01
    z[5,6,1]  R2718     4.5606139302253723e-01
    z[5,6,1]  R2719     3.7726444005966187e-01
    z[5,6,1]  R2720     -2.4689415469765663e-02
    z[5,6,1]  R2721     -1.1694305390119553e-01
    z[5,6,1]  R2722     -6.3666746020317078e-02
    z[5,6,1]  R2723     -5.9154576063156128e-01
    z[5,6,1]  R2724     7.1902751922607422e-02
    z[5,6,1]  R2725     -5.9003078937530518e-01
    z[5,6,1]  R2726     -5.4779714345932007e-01
    z[5,6,1]  R2727     -5.7059872150421143e-01
    z[5,6,1]  R2728     -6.3786470890045166e-01
    z[5,6,1]  R2729     -6.7252731323242188e-01
    z[5,6,1]  R2730     -6.6398131847381592e-01
    z[5,6,1]  R2731     4.1244527697563171e-01
    z[5,6,1]  R2732     2.9022064805030823e-01
    z[5,6,1]  R2733     0.279297411441803
    z[5,6,1]  R2734     -0.230604350566864
    z[5,6,1]  R2735     1.7475579679012299e-01
    z[5,6,1]  R2736     8.5760280489921570e-02
    z[5,6,1]  R2737     -3.2181721925735474e-01
    z[5,6,1]  R2738     -2.1566207706928253e-01
    z[5,6,1]  R2739     -3.5702559351921082e-01
    z[5,6,1]  R2740     -6.3930189609527588e-01
    z[5,6,1]  R2741     5.9156060218811035e-01
    z[5,6,1]  R2742     6.1252003908157349e-01
    z[5,6,1]  R2743     3.3040410280227661e-01
    z[5,6,1]  R2744     7.1475124359130859e-01
    z[5,6,1]  R2745     7.8449553251266479e-01
    z[5,6,1]  R2746     6.9461055099964142e-02
    z[5,6,1]  R2747     -6.2608772516250610e-01
    z[5,6,1]  R2748     0.651689350605011
    z[5,6,1]  R2749     -0.763340950012207
    z[5,6,1]  R2750     -6.0725015401840210e-01
    z[5,6,1]  R2751     2.6873454451560974e-01
    z[5,6,1]  R2752     2.9936638474464417e-01
    z[5,6,1]  R2753     5.9346508979797363e-01
    z[5,6,1]  R2754     -9.4619792699813843e-01
    z[5,6,1]  R2755     -0.740623414516449
    z[5,6,1]  R2756     -6.8825989961624146e-01
    z[5,6,1]  R2757     -7.1170818805694580e-01
    z[5,6,1]  R2758     -7.4227726459503174e-01
    z[5,6,1]  R2759     4.0774738788604736e-01
    z[5,6,1]  R2760     -7.3594230413436890e-01
    z[5,6,1]  R2761     5.5974102020263672e-01
    z[5,6,1]  R2762     5.8711689710617065e-01
    z[5,6,1]  R2763     3.8535785675048828e-01
    z[5,6,1]  R2764     -3.0366463586688042e-02
    z[5,6,1]  R2765     1.5404240787029266e-01
    z[5,6,1]  R2766     3.3650639653205872e-01
    z[5,6,1]  R2767     4.0871241688728333e-01
    z[5,6,1]  R2768     -1.7309428751468658e-01
    z[5,6,1]  R2769     2.8831285238265991e-01
    z[5,6,1]  R2770     6.1456203460693359e-02
    z[5,6,1]  R2771     0.931501567363739
    z[5,6,1]  R2772     0.725002110004425
    z[5,6,1]  R2773     3.9444544911384583e-01
    z[5,6,1]  R2774     -1.6152249276638031e-01
    z[5,6,1]  R2775     2.9948723316192627e-01
    z[5,6,1]  R2776     2.3306940495967865e-01
    z[5,6,1]  R2777     -1.8271915614604950e-01
    z[5,6,1]  R2778     -8.4464186429977417e-01
    z[5,6,1]  R2779     -7.6121377944946289e-01
    z[5,6,1]  R2780     -8.0869638919830322e-01
    z[5,6,1]  R2781     0.27131387591362
    z[5,6,1]  R2782     5.6756451725959778e-02
    z[5,6,1]  R2783     -1.9486691057682037e-01
    z[5,6,1]  R2784     -5.3097051382064819e-01
    z[5,6,1]  R2785     -3.6388668417930603e-01
    z[5,6,1]  R2786     -4.2843598127365112e-01
    z[5,6,1]  R2787     -0.859521210193634
    z[5,6,1]  R2788     -0.878296434879303
    z[5,6,1]  R2789     -6.5130203962326050e-01
    z[5,6,1]  R2790     -6.2969833612442017e-01
    z[5,6,1]  R2791     8.3298072218894958e-02
    z[5,6,1]  R2792     1.2004360556602478e-01
    z[5,6,1]  R2793     -4.1857150197029114e-01
    z[5,6,1]  R2794     -3.4635263681411743e-01
    z[5,6,1]  R2795     -9.4786942005157471e-01
    z[5,6,1]  R2796     -9.4751822948455811e-01
    z[5,6,1]  R2797     -1.6938674449920654e-01
    z[5,6,1]  R2798     -0.0797528326511383
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2681     -1
    z[5,6,2]  R2682     1
    z[5,6,2]  R2691     2.2204430401325226e-01
    z[5,6,2]  R2692     -6.9286718964576721e-02
    z[5,6,2]  R2693     1.0267228819429874e-02
    z[5,6,2]  R2694     -3.1002461910247803e-02
    z[5,6,2]  R2695     1.0819110274314880e-01
    z[5,6,2]  R2696     -3.7111940979957581e-01
    z[5,6,2]  R2697     7.5985920429229736e-01
    z[5,6,2]  R2698     -2.4186022579669952e-01
    z[5,6,2]  R2699     7.5410521030426025e-01
    z[5,6,2]  R2700     -4.7407627105712891e-01
    z[5,6,2]  R2701     2.6614934206008911e-01
    z[5,6,2]  R2702     -4.7693509608507156e-02
    z[5,6,2]  R2703     2.5060348212718964e-02
    z[5,6,2]  R2704     -2.1321940422058105e-01
    z[5,6,2]  R2705     0.201337531208992
    z[5,6,2]  R2706     -2.9549381136894226e-01
    z[5,6,2]  R2707     -1.6530798375606537e-01
    z[5,6,2]  R2708     0.0824781134724617
    z[5,6,2]  R2709     -6.8636782467365265e-02
    z[5,6,2]  R2710     1.6016195714473724e-01
    z[5,6,2]  R2711     -4.8945721983909607e-01
    z[5,6,2]  R2712     5.1430130004882812e-01
    z[5,6,2]  R2713     3.4037387371063232e-01
    z[5,6,2]  R2714     -8.9806658029556274e-01
    z[5,6,2]  R2715     -0.0916375145316124
    z[5,6,2]  R2716     3.0163705348968506e-02
    z[5,6,2]  R2717     -4.7916686534881592e-01
    z[5,6,2]  R2718     -1.5109807252883911e-01
    z[5,6,2]  R2719     -3.7307778000831604e-01
    z[5,6,2]  R2720     -9.4032082706689835e-03
    z[5,6,2]  R2721     8.0027438700199127e-02
    z[5,6,2]  R2722     -5.8725923299789429e-02
    z[5,6,2]  R2723     1.0964184254407883e-01
    z[5,6,2]  R2724     -7.3334950208663940e-01
    z[5,6,2]  R2725     4.0528017282485962e-01
    z[5,6,2]  R2726     0.284252792596817
    z[5,6,2]  R2727     3.6815294623374939e-01
    z[5,6,2]  R2728     1.5899296104907990e-01
    z[5,6,2]  R2729     4.2180046439170837e-01
    z[5,6,2]  R2730     4.2704778909683228e-01
    z[5,6,2]  R2731     -5.3261661529541016e-01
    z[5,6,2]  R2732     -4.9754548072814941e-01
    z[5,6,2]  R2733     4.1682365536689758e-01
    z[5,6,2]  R2734     -9.4092383980751038e-02
    z[5,6,2]  R2735     6.6872701048851013e-02
    z[5,6,2]  R2736     5.3215879201889038e-01
    z[5,6,2]  R2737     4.9683311581611633e-01
    z[5,6,2]  R2738     4.9082070589065552e-01
    z[5,6,2]  R2739     6.5681940317153931e-01
    z[5,6,2]  R2740     6.7451059818267822e-01
    z[5,6,2]  R2741     -3.7073939893161878e-05
    z[5,6,2]  R2742     -9.4061434268951416e-02
    z[5,6,2]  R2743     -1.0151164606213570e-02
    z[5,6,2]  R2744     -3.6912170052528381e-01
    z[5,6,2]  R2745     -9.4815976917743683e-02
    z[5,6,2]  R2746     6.6864097118377686e-01
    z[5,6,2]  R2747     1.4853793382644653e-01
    z[5,6,2]  R2748     -2.0206044614315033e-01
    z[5,6,2]  R2749     5.1261745393276215e-02
    z[5,6,2]  R2750     5.7070064544677734e-01
    z[5,6,2]  R2751     1.9373928010463715e-01
    z[5,6,2]  R2752     -1.2308959662914276e-01
    z[5,6,2]  R2753     5.0703313201665878e-02
    z[5,6,2]  R2754     7.4863538146018982e-02
    z[5,6,2]  R2755     -2.7872905135154724e-01
    z[5,6,2]  R2756     -0.290794312953949
    z[5,6,2]  R2757     -8.2097806036472321e-02
    z[5,6,2]  R2758     1.1182001233100891e-01
    z[5,6,2]  R2759     1.9414447247982025e-01
    z[5,6,2]  R2760     -1.1578583717346191e-01
    z[5,6,2]  R2761     -3.4295099973678589e-01
    z[5,6,2]  R2762     -2.4560411274433136e-01
    z[5,6,2]  R2763     3.8912689685821533e-01
    z[5,6,2]  R2764     -1.2461658567190170e-01
    z[5,6,2]  R2765     3.0976501293480396e-03
    z[5,6,2]  R2766     4.9459049105644226e-01
    z[5,6,2]  R2767     1.7571765184402466e-01
    z[5,6,2]  R2768     4.7093614935874939e-01
    z[5,6,2]  R2769     -9.6561267971992493e-02
    z[5,6,2]  R2770     -2.7793669700622559e-01
    z[5,6,2]  R2771     -1.8980790674686432e-01
    z[5,6,2]  R2772     4.4485166668891907e-02
    z[5,6,2]  R2773     -4.0721407532691956e-01
    z[5,6,2]  R2774     1.6186350584030151e-01
    z[5,6,2]  R2775     4.1436710953712463e-01
    z[5,6,2]  R2776     -2.9058215022087097e-01
    z[5,6,2]  R2777     -1.3824518024921417e-01
    z[5,6,2]  R2778     -0.0147575493901968
    z[5,6,2]  R2779     -3.6450235638767481e-03
    z[5,6,2]  R2780     -1.9960529170930386e-03
    z[5,6,2]  R2781     -2.4927143007516861e-02
    z[5,6,2]  R2782     1.8710285425186157e-01
    z[5,6,2]  R2783     -2.4280165135860443e-01
    z[5,6,2]  R2784     -1.8334476277232170e-02
    z[5,6,2]  R2785     1.8672838807106018e-01
    z[5,6,2]  R2786     2.4049901962280273e-01
    z[5,6,2]  R2787     -8.7707303464412689e-02
    z[5,6,2]  R2788     1.1487445980310440e-01
    z[5,6,2]  R2789     -1.4127650856971741e-01
    z[5,6,2]  R2790     -1.9877615571022034e-01
    z[5,6,2]  R2791     -6.0105919837951660e-02
    z[5,6,2]  R2792     -0.25982666015625
    z[5,6,2]  R2793     0.0089586041867733
    z[5,6,2]  R2794     1.5497873723506927e-01
    z[5,6,2]  R2795     7.0586748421192169e-02
    z[5,6,2]  R2796     3.0409701168537140e-02
    z[5,6,2]  R2797     7.0663064718246460e-01
    z[5,6,2]  R2798     6.9450670480728149e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2683     -1
    z[5,6,3]  R2684     1
    z[5,6,3]  R2691     -1.7188473045825958e-01
    z[5,6,3]  R2692     1.8126615881919861e-01
    z[5,6,3]  R2693     4.3439182639122009e-01
    z[5,6,3]  R2694     -1.2478467077016830e-01
    z[5,6,3]  R2695     1.9832178950309753e-01
    z[5,6,3]  R2696     4.3204563856124878e-01
    z[5,6,3]  R2697     1.1489140801131725e-02
    z[5,6,3]  R2698     -4.0967710316181183e-02
    z[5,6,3]  R2699     4.8574271798133850e-01
    z[5,6,3]  R2700     -4.3506991118192673e-02
    z[5,6,3]  R2701     -4.6891830861568451e-02
    z[5,6,3]  R2702     -2.8363440185785294e-02
    z[5,6,3]  R2703     1.3611934147775173e-02
    z[5,6,3]  R2704     -0.0231669619679451
    z[5,6,3]  R2705     2.2896258533000946e-01
    z[5,6,3]  R2706     3.4761503338813782e-01
    z[5,6,3]  R2707     2.6514670252799988e-01
    z[5,6,3]  R2708     1.0575447231531143e-01
    z[5,6,3]  R2709     4.9875143170356750e-01
    z[5,6,3]  R2710     7.5762018561363220e-02
    z[5,6,3]  R2711     -2.3659074306488037e-01
    z[5,6,3]  R2712     -2.6496499776840210e-01
    z[5,6,3]  R2713     -1.8247883021831512e-01
    z[5,6,3]  R2714     -2.2330953180789948e-01
    z[5,6,3]  R2715     -1.5001441538333893e-01
    z[5,6,3]  R2716     -4.4930616021156311e-01
    z[5,6,3]  R2717     -2.6776903867721558e-01
    z[5,6,3]  R2718     9.8131135106086731e-02
    z[5,6,3]  R2719     -2.6228803396224976e-01
    z[5,6,3]  R2720     -1.6434629261493683e-01
    z[5,6,3]  R2721     -6.9557195901870728e-01
    z[5,6,3]  R2722     -0.846520185470581
    z[5,6,3]  R2723     -4.7702023386955261e-01
    z[5,6,3]  R2724     -4.8704613000154495e-02
    z[5,6,3]  R2725     -1.0013290494680405e-01
    z[5,6,3]  R2726     -9.7566343843936920e-02
    z[5,6,3]  R2727     -8.4781445562839508e-02
    z[5,6,3]  R2728     -0.349507600069046
    z[5,6,3]  R2729     -4.1402030736207962e-02
    z[5,6,3]  R2730     1.7861567437648773e-01
    z[5,6,3]  R2731     -4.2533260583877563e-01
    z[5,6,3]  R2732     -2.0311589539051056e-01
    z[5,6,3]  R2733     -2.9586234688758850e-01
    z[5,6,3]  R2734     1.5119914710521698e-01
    z[5,6,3]  R2735     -4.7901135683059692e-01
    z[5,6,3]  R2736     -7.7033668756484985e-01
    z[5,6,3]  R2737     -5.8633148670196533e-01
    z[5,6,3]  R2738     -2.6660934090614319e-01
    z[5,6,3]  R2739     1.6089810431003571e-01
    z[5,6,3]  R2740     3.4706801176071167e-01
    z[5,6,3]  R2741     1.8679147958755493e-01
    z[5,6,3]  R2742     -4.4278789311647415e-02
    z[5,6,3]  R2743     7.9929538071155548e-02
    z[5,6,3]  R2744     2.9882493615150452e-01
    z[5,6,3]  R2745     0.0489862896502018
    z[5,6,3]  R2746     -3.0913609080016613e-03
    z[5,6,3]  R2747     6.4784783124923706e-01
    z[5,6,3]  R2748     -5.0599642097949982e-02
    z[5,6,3]  R2749     7.8698612749576569e-02
    z[5,6,3]  R2750     1.6925598680973053e-01
    z[5,6,3]  R2751     -3.2823413610458374e-01
    z[5,6,3]  R2752     3.4984898567199707e-01
    z[5,6,3]  R2753     -3.0766350030899048e-01
    z[5,6,3]  R2754     4.0364719927310944e-02
    z[5,6,3]  R2755     -2.7162888646125793e-01
    z[5,6,3]  R2756     -1.4464857056736946e-02
    z[5,6,3]  R2757     8.4742859005928040e-02
    z[5,6,3]  R2758     -1.9598224759101868e-01
    z[5,6,3]  R2759     4.3875631690025330e-01
    z[5,6,3]  R2760     -1.6346287727355957e-01
    z[5,6,3]  R2761     -6.8979716300964355e-01
    z[5,6,3]  R2762     -3.6139088869094849e-01
    z[5,6,3]  R2763     -4.2000424861907959e-01
    z[5,6,3]  R2764     -6.9814813137054443e-01
    z[5,6,3]  R2765     -7.1037340164184570e-01
    z[5,6,3]  R2766     2.2700959444046021e-01
    z[5,6,3]  R2767     0.538135290145874
    z[5,6,3]  R2768     -2.0437745749950409e-01
    z[5,6,3]  R2769     8.8150733709335327e-01
    z[5,6,3]  R2770     -3.2526946067810059e-01
    z[5,6,3]  R2771     -1.4847362041473389e-01
    z[5,6,3]  R2772     5.6813931465148926e-01
    z[5,6,3]  R2773     -9.4906553626060486e-02
    z[5,6,3]  R2774     -6.2504941225051880e-01
    z[5,6,3]  R2775     2.7463027834892273e-01
    z[5,6,3]  R2776     -0.272591233253479
    z[5,6,3]  R2777     -7.9053580760955811e-01
    z[5,6,3]  R2778     -1.2500332295894623e-01
    z[5,6,3]  R2779     -2.5557151436805725e-01
    z[5,6,3]  R2780     -1.2475780397653580e-01
    z[5,6,3]  R2781     -3.4341163933277130e-02
    z[5,6,3]  R2782     -2.7871277928352356e-01
    z[5,6,3]  R2783     -8.3474278450012207e-01
    z[5,6,3]  R2784     -6.9614422321319580e-01
    z[5,6,3]  R2785     -6.7734891176223755e-01
    z[5,6,3]  R2786     -6.7219221591949463e-01
    z[5,6,3]  R2787     -3.2140710949897766e-01
    z[5,6,3]  R2788     -1.2192024849355221e-02
    z[5,6,3]  R2789     3.0854457616806030e-01
    z[5,6,3]  R2790     4.8076364398002625e-01
    z[5,6,3]  R2791     -9.0143275260925293e-01
    z[5,6,3]  R2792     -5.5771899223327637e-01
    z[5,6,3]  R2793     -8.2206577062606812e-01
    z[5,6,3]  R2794     -0.804474413394928
    z[5,6,3]  R2795     1.1394319683313370e-01
    z[5,6,3]  R2796     -1.3347879052162170e-01
    z[5,6,3]  R2797     2.9186752438545227e-01
    z[5,6,3]  R2798     3.9525943994522095e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2685     -1
    z[5,6,4]  R2686     1
    z[5,6,4]  R2691     2.3010133206844330e-01
    z[5,6,4]  R2692     3.4058505296707153e-01
    z[5,6,4]  R2693     1.6457255184650421e-01
    z[5,6,4]  R2694     1.1215513199567795e-01
    z[5,6,4]  R2695     2.1339850500226021e-03
    z[5,6,4]  R2696     2.0488698035478592e-02
    z[5,6,4]  R2697     1.5322379767894745e-02
    z[5,6,4]  R2698     6.2139028310775757e-01
    z[5,6,4]  R2699     4.9387805163860321e-02
    z[5,6,4]  R2700     1.4650250971317291e-01
    z[5,6,4]  R2701     -1.3256011903285980e-01
    z[5,6,4]  R2702     3.7601027637720108e-02
    z[5,6,4]  R2703     -3.1871777772903442e-01
    z[5,6,4]  R2704     2.6871031522750854e-01
    z[5,6,4]  R2705     4.8271864652633667e-02
    z[5,6,4]  R2706     2.1161170303821564e-01
    z[5,6,4]  R2707     -3.2673040404915810e-03
    z[5,6,4]  R2708     0.360588401556015
    z[5,6,4]  R2709     0.0846773162484169
    z[5,6,4]  R2710     0.078289695084095
    z[5,6,4]  R2711     -2.1471163630485535e-01
    z[5,6,4]  R2712     4.7779548168182373e-01
    z[5,6,4]  R2713     -1.5561152994632721e-01
    z[5,6,4]  R2714     6.5029174089431763e-02
    z[5,6,4]  R2715     -5.4568547010421753e-01
    z[5,6,4]  R2716     -2.0039555430412292e-01
    z[5,6,4]  R2717     -6.9484390318393707e-02
    z[5,6,4]  R2718     -3.6225995421409607e-01
    z[5,6,4]  R2719     -3.3178317546844482e-01
    z[5,6,4]  R2720     -4.5058351755142212e-01
    z[5,6,4]  R2721     -1.4191937446594238e-01
    z[5,6,4]  R2722     -3.5129639506340027e-01
    z[5,6,4]  R2723     -2.0226357877254486e-01
    z[5,6,4]  R2724     -1.7484459280967712e-01
    z[5,6,4]  R2725     -2.4712309241294861e-01
    z[5,6,4]  R2726     -1.8820452690124512e-01
    z[5,6,4]  R2727     -7.1713291108608246e-02
    z[5,6,4]  R2728     -3.2527527213096619e-01
    z[5,6,4]  R2729     -3.5218662023544312e-01
    z[5,6,4]  R2730     0.144295796751976
    z[5,6,4]  R2731     -3.9359182119369507e-01
    z[5,6,4]  R2732     5.1760542392730713e-01
    z[5,6,4]  R2733     6.9337749481201172e-01
    z[5,6,4]  R2734     3.5283794999122620e-01
    z[5,6,4]  R2735     5.1066315174102783e-01
    z[5,6,4]  R2736     -2.9012659192085266e-01
    z[5,6,4]  R2737     -1.2565696239471436e-01
    z[5,6,4]  R2738     -2.2074703872203827e-01
    z[5,6,4]  R2739     2.0937354862689972e-01
    z[5,6,4]  R2740     -5.6084852665662766e-02
    z[5,6,4]  R2741     3.4189215302467346e-01
    z[5,6,4]  R2742     -1.3627833127975464e-01
    z[5,6,4]  R2743     -0.111341193318367
    z[5,6,4]  R2744     4.4122478365898132e-01
    z[5,6,4]  R2745     -4.4462826102972031e-02
    z[5,6,4]  R2746     4.0168440341949463e-01
    z[5,6,4]  R2747     2.2923342883586884e-01
    z[5,6,4]  R2748     -4.7273480892181396e-01
    z[5,6,4]  R2749     5.8079534769058228e-01
    z[5,6,4]  R2750     2.5078555941581726e-01
    z[5,6,4]  R2751     6.5549755096435547e-01
    z[5,6,4]  R2752     -5.1414966583251953e-01
    z[5,6,4]  R2753     -5.3345358371734619e-01
    z[5,6,4]  R2754     -1.3015829026699066e-01
    z[5,6,4]  R2755     -8.5632158443331718e-03
    z[5,6,4]  R2756     -2.7972236275672913e-01
    z[5,6,4]  R2757     3.5864907503128052e-01
    z[5,6,4]  R2758     -4.1146072745323181e-01
    z[5,6,4]  R2759     -3.7646195292472839e-01
    z[5,6,4]  R2760     -7.9846596345305443e-03
    z[5,6,4]  R2761     1.5329687297344208e-01
    z[5,6,4]  R2762     -6.2212800979614258e-01
    z[5,6,4]  R2763     5.5183735676109791e-03
    z[5,6,4]  R2764     -2.9356116056442261e-01
    z[5,6,4]  R2765     -4.8711401224136353e-01
    z[5,6,4]  R2766     -1.0112939774990082e-01
    z[5,6,4]  R2767     3.0689540505409241e-01
    z[5,6,4]  R2768     -9.3758301809430122e-03
    z[5,6,4]  R2769     2.0063920319080353e-01
    z[5,6,4]  R2770     5.8596688508987427e-01
    z[5,6,4]  R2771     2.3003134131431580e-01
    z[5,6,4]  R2772     -6.3085383735597134e-03
    z[5,6,4]  R2773     2.6756027340888977e-01
    z[5,6,4]  R2774     5.7051169872283936e-01
    z[5,6,4]  R2775     -3.7801295518875122e-01
    z[5,6,4]  R2776     2.4625961482524872e-01
    z[5,6,4]  R2777     -1.7379105091094971e-01
    z[5,6,4]  R2778     2.6957783102989197e-01
    z[5,6,4]  R2779     -0.25974240899086
    z[5,6,4]  R2780     5.2982503175735474e-01
    z[5,6,4]  R2781     5.3899204730987549e-01
    z[5,6,4]  R2782     8.0369651317596436e-01
    z[5,6,4]  R2783     6.0987651348114014e-02
    z[5,6,4]  R2784     4.5826774090528488e-02
    z[5,6,4]  R2785     -5.1132738590240479e-01
    z[5,6,4]  R2786     -2.9330241680145264e-01
    z[5,6,4]  R2787     1.3294976949691772e-01
    z[5,6,4]  R2788     2.1586577594280243e-01
    z[5,6,4]  R2789     2.0460948348045349e-01
    z[5,6,4]  R2790     7.9268246889114380e-02
    z[5,6,4]  R2791     -3.7390011548995972e-01
    z[5,6,4]  R2792     1.3041408360004425e-01
    z[5,6,4]  R2793     5.6369446218013763e-02
    z[5,6,4]  R2794     -2.6048952341079712e-01
    z[5,6,4]  R2795     1.4222750067710876e-01
    z[5,6,4]  R2796     -5.8729931712150574e-02
    z[5,6,4]  R2797     -1.0785602778196335e-01
    z[5,6,4]  R2798     -6.0210663825273514e-02
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2687     -1
    z[5,6,5]  R2688     1
    z[5,6,5]  R2691     1.6349695622920990e-02
    z[5,6,5]  R2692     4.0406482294201851e-03
    z[5,6,5]  R2693     -2.8824573755264282e-01
    z[5,6,5]  R2694     6.4108437299728394e-01
    z[5,6,5]  R2695     2.6808005571365356e-01
    z[5,6,5]  R2696     3.5143008828163147e-01
    z[5,6,5]  R2697     -1.1392273753881454e-01
    z[5,6,5]  R2698     2.9049047827720642e-01
    z[5,6,5]  R2699     1.9229158759117126e-01
    z[5,6,5]  R2700     -1.3685730099678040e-01
    z[5,6,5]  R2701     2.3453648388385773e-01
    z[5,6,5]  R2702     -0.155681312084198
    z[5,6,5]  R2703     -2.1839885041117668e-02
    z[5,6,5]  R2704     1.5839838981628418e-01
    z[5,6,5]  R2705     9.0267747640609741e-02
    z[5,6,5]  R2706     1.0915318131446838e-01
    z[5,6,5]  R2707     2.9655680060386658e-01
    z[5,6,5]  R2708     1.3262277841567993e-01
    z[5,6,5]  R2709     -0.0666360929608345
    z[5,6,5]  R2710     -2.6828205585479736e-01
    z[5,6,5]  R2711     2.8831627964973450e-01
    z[5,6,5]  R2712     6.0940408706665039e-01
    z[5,6,5]  R2713     -2.6306754350662231e-01
    z[5,6,5]  R2714     3.0098492279648781e-03
    z[5,6,5]  R2715     1.1404132843017578e-01
    z[5,6,5]  R2716     -3.3031675219535828e-01
    z[5,6,5]  R2717     -2.3639994859695435e-01
    z[5,6,5]  R2718     -1.1001867055892944e-01
    z[5,6,5]  R2719     -3.6067163944244385e-01
    z[5,6,5]  R2720     5.5549168586730957e-01
    z[5,6,5]  R2721     3.3442208170890808e-01
    z[5,6,5]  R2722     2.1022740006446838e-01
    z[5,6,5]  R2723     4.3663203716278076e-01
    z[5,6,5]  R2724     5.2558046579360962e-01
    z[5,6,5]  R2725     3.7022992968559265e-01
    z[5,6,5]  R2726     2.5225467979907990e-02
    z[5,6,5]  R2727     2.4903084337711334e-01
    z[5,6,5]  R2728     5.6108510494232178e-01
    z[5,6,5]  R2729     1.4927624724805355e-02
    z[5,6,5]  R2730     9.7732760012149811e-02
    z[5,6,5]  R2731     2.3926517367362976e-01
    z[5,6,5]  R2732     1.5449105203151703e-01
    z[5,6,5]  R2733     -6.4368017017841339e-02
    z[5,6,5]  R2734     6.5900111198425293e-01
    z[5,6,5]  R2735     -1.0784979909658432e-01
    z[5,6,5]  R2736     1.7631146311759949e-01
    z[5,6,5]  R2737     0.00893962662667036
    z[5,6,5]  R2738     5.4915450513362885e-02
    z[5,6,5]  R2739     -2.6482370495796204e-01
    z[5,6,5]  R2740     0.0788489356637001
    z[5,6,5]  R2741     0.528590977191925
    z[5,6,5]  R2742     7.1026724576950073e-01
    z[5,6,5]  R2743     9.1388291120529175e-01
    z[5,6,5]  R2744     -2.9233081266283989e-02
    z[5,6,5]  R2745     -1.8909063935279846e-01
    z[5,6,5]  R2746     4.2841640114784241e-01
    z[5,6,5]  R2747     1.3852208852767944e-01
    z[5,6,5]  R2748     -2.5052863359451294e-01
    z[5,6,5]  R2749     -2.0143085718154907e-01
    z[5,6,5]  R2750     2.2526636719703674e-01
    z[5,6,5]  R2751     -4.2061571031808853e-02
    z[5,6,5]  R2752     -2.2896220907568932e-02
    z[5,6,5]  R2753     -2.8610411286354065e-01
    z[5,6,5]  R2754     1.5323950350284576e-01
    z[5,6,5]  R2755     -1.5778636932373047e-01
    z[5,6,5]  R2756     -4.3013781309127808e-02
    z[5,6,5]  R2757     3.2962355017662048e-01
    z[5,6,5]  R2758     4.1474539786577225e-02
    z[5,6,5]  R2759     -6.0724008083343506e-01
    z[5,6,5]  R2760     4.2287012934684753e-01
    z[5,6,5]  R2761     -5.1012925803661346e-02
    z[5,6,5]  R2762     1.2685698270797729e-01
    z[5,6,5]  R2763     -1.9729802012443542e-01
    z[5,6,5]  R2764     6.3614523410797119e-01
    z[5,6,5]  R2765     3.1838470697402954e-01
    z[5,6,5]  R2766     -4.6052387356758118e-01
    z[5,6,5]  R2767     1.6816663742065430e-01
    z[5,6,5]  R2768     5.0231683254241943e-01
    z[5,6,5]  R2769     1.0454358160495758e-01
    z[5,6,5]  R2770     0.260141521692276
    z[5,6,5]  R2771     9.3274883925914764e-02
    z[5,6,5]  R2772     1.6127622127532959e-01
    z[5,6,5]  R2773     6.9633203744888306e-01
    z[5,6,5]  R2774     2.9558527469635010e-01
    z[5,6,5]  R2775     -1.0555070638656616e-01
    z[5,6,5]  R2776     1.5233403444290161e-01
    z[5,6,5]  R2777     -5.9906851500272751e-02
    z[5,6,5]  R2778     -0.296150267124176
    z[5,6,5]  R2779     -1.8459224700927734e-01
    z[5,6,5]  R2780     -1.4714795351028442e-01
    z[5,6,5]  R2781     7.5066995620727539e-01
    z[5,6,5]  R2782     1.3029675185680389e-01
    z[5,6,5]  R2783     -1.4577963948249817e-01
    z[5,6,5]  R2784     -4.6445944905281067e-01
    z[5,6,5]  R2785     -1.0121800005435944e-01
    z[5,6,5]  R2786     -4.0525132417678833e-01
    z[5,6,5]  R2787     1.6238564252853394e-01
    z[5,6,5]  R2788     -2.9147368669509888e-01
    z[5,6,5]  R2789     -1.3680888712406158e-01
    z[5,6,5]  R2790     -1.6233567893505096e-01
    z[5,6,5]  R2791     1.5122829377651215e-01
    z[5,6,5]  R2792     4.0020561218261719e-01
    z[5,6,5]  R2793     -1.0169178247451782e-01
    z[5,6,5]  R2794     -6.7678354680538177e-02
    z[5,6,5]  R2795     -2.8892930597066879e-02
    z[5,6,5]  R2796     -1.4586250483989716e-01
    z[5,6,5]  R2797     -7.0206761360168457e-02
    z[5,6,5]  R2798     1.4605778455734253e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2689     -1
    z[5,6,6]  R2690     1
    z[5,6,6]  R2691     3.0506783723831177e-01
    z[5,6,6]  R2692     -1.6707411408424377e-01
    z[5,6,6]  R2693     -1.4030157029628754e-01
    z[5,6,6]  R2694     -1.5614232420921326e-01
    z[5,6,6]  R2695     -6.9573158025741577e-01
    z[5,6,6]  R2696     3.9206331968307495e-01
    z[5,6,6]  R2697     -4.4810160994529724e-01
    z[5,6,6]  R2698     -1.3658446073532104e-01
    z[5,6,6]  R2699     6.9953277707099915e-03
    z[5,6,6]  R2700     -4.5238631963729858e-01
    z[5,6,6]  R2701     -1.8078187480568886e-02
    z[5,6,6]  R2702     3.6166332662105560e-02
    z[5,6,6]  R2703     -4.2214909195899963e-01
    z[5,6,6]  R2704     3.2443445920944214e-01
    z[5,6,6]  R2705     -1.1246681213378906e-02
    z[5,6,6]  R2706     0.0382811576128006
    z[5,6,6]  R2707     -2.4132886528968811e-01
    z[5,6,6]  R2708     -3.7785002589225769e-01
    z[5,6,6]  R2709     -1.8799139559268951e-01
    z[5,6,6]  R2710     -4.2002037167549133e-02
    z[5,6,6]  R2711     4.2526909708976746e-01
    z[5,6,6]  R2712     1.3504503667354584e-01
    z[5,6,6]  R2713     3.2356211543083191e-01
    z[5,6,6]  R2714     1.5062689781188965e-01
    z[5,6,6]  R2715     -1.1830971390008926e-01
    z[5,6,6]  R2716     5.9109228849411011e-01
    z[5,6,6]  R2717     6.6986465454101562e-01
    z[5,6,6]  R2718     -2.7612483501434326e-01
    z[5,6,6]  R2719     3.7648779153823853e-01
    z[5,6,6]  R2720     -4.1460883617401123e-01
    z[5,6,6]  R2721     -7.3883078992366791e-02
    z[5,6,6]  R2722     2.6690849661827087e-01
    z[5,6,6]  R2723     2.3986613750457764e-01
    z[5,6,6]  R2724     -0.35416179895401
    z[5,6,6]  R2725     6.2710128724575043e-02
    z[5,6,6]  R2726     -6.3965469598770142e-02
    z[5,6,6]  R2727     -1.5120127797126770e-01
    z[5,6,6]  R2728     1.5688399970531464e-01
    z[5,6,6]  R2729     8.8956616818904877e-03
    z[5,6,6]  R2730     8.6626596748828888e-02
    z[5,6,6]  R2731     -2.4196162819862366e-01
    z[5,6,6]  R2732     -3.4563142806291580e-02
    z[5,6,6]  R2733     2.7168050408363342e-01
    z[5,6,6]  R2734     1.4697673916816711e-01
    z[5,6,6]  R2735     6.4747321605682373e-01
    z[5,6,6]  R2736     6.5576941706240177e-03
    z[5,6,6]  R2737     5.0558692216873169e-01
    z[5,6,6]  R2738     2.6151040196418762e-01
    z[5,6,6]  R2739     1.1140928417444229e-01
    z[5,6,6]  R2740     -3.5501249134540558e-02
    z[5,6,6]  R2741     4.4780775904655457e-01
    z[5,6,6]  R2742     -2.4089443683624268e-01
    z[5,6,6]  R2743     1.5373152494430542e-01
    z[5,6,6]  R2744     -0.0870768278837204
    z[5,6,6]  R2745     -5.4401624202728271e-01
    z[5,6,6]  R2746     -2.7572691440582275e-01
    z[5,6,6]  R2747     2.6575896143913269e-01
    z[5,6,6]  R2748     4.4204148650169373e-01
    z[5,6,6]  R2749     8.7261833250522614e-02
    z[5,6,6]  R2750     -3.0299395322799683e-01
    z[5,6,6]  R2751     -2.7117198705673218e-01
    z[5,6,6]  R2752     6.2765669822692871e-01
    z[5,6,6]  R2753     4.0960687398910522e-01
    z[5,6,6]  R2754     -1.7640371620655060e-01
    z[5,6,6]  R2755     -0.0567912831902504
    z[5,6,6]  R2756     -3.9269987493753433e-02
    z[5,6,6]  R2757     3.5853415727615356e-01
    z[5,6,6]  R2758     4.4118392467498779e-01
    z[5,6,6]  R2759     2.8538459539413452e-01
    z[5,6,6]  R2760     3.2892918586730957e-01
    z[5,6,6]  R2761     2.1122667193412781e-01
    z[5,6,6]  R2762     1.9000871479511261e-01
    z[5,6,6]  R2763     3.5023361444473267e-01
    z[5,6,6]  R2764     7.2476804256439209e-02
    z[5,6,6]  R2765     -2.7893170714378357e-01
    z[5,6,6]  R2766     1.7076477408409119e-01
    z[5,6,6]  R2767     -4.8884540796279907e-01
    z[5,6,6]  R2768     -1.2712916731834412e-01
    z[5,6,6]  R2769     -2.4725881218910217e-01
    z[5,6,6]  R2770     -6.3336426019668579e-01
    z[5,6,6]  R2771     5.7357203215360641e-02
    z[5,6,6]  R2772     -0.268635094165802
    z[5,6,6]  R2773     1.4303991198539734e-01
    z[5,6,6]  R2774     1.2412270158529282e-01
    z[5,6,6]  R2775     6.1146342754364014e-01
    z[5,6,6]  R2776     -8.3838403224945068e-01
    z[5,6,6]  R2777     -5.3668224811553955e-01
    z[5,6,6]  R2778     -2.7634406089782715e-01
    z[5,6,6]  R2779     3.9433974027633667e-01
    z[5,6,6]  R2780     -2.6123058050870895e-02
    z[5,6,6]  R2781     -1.3918830454349518e-01
    z[5,6,6]  R2782     3.0937612056732178e-01
    z[5,6,6]  R2783     -4.1227099299430847e-01
    z[5,6,6]  R2784     8.1027291715145111e-02
    z[5,6,6]  R2785     2.8887173533439636e-01
    z[5,6,6]  R2786     7.2796165943145752e-02
    z[5,6,6]  R2787     1.3282217085361481e-01
    z[5,6,6]  R2788     0.233786940574646
    z[5,6,6]  R2789     3.7475389242172241e-01
    z[5,6,6]  R2790     -5.4427143186330795e-03
    z[5,6,6]  R2791     -2.4663519114255905e-02
    z[5,6,6]  R2792     -6.5523463487625122e-01
    z[5,6,6]  R2793     3.6728808283805847e-01
    z[5,6,6]  R2794     -2.4440322816371918e-01
    z[5,6,6]  R2795     1.0210485011339188e-01
    z[5,6,6]  R2796     -1.0901399701833725e-01
    z[5,6,6]  R2797     -7.4868492782115936e-02
    z[5,6,6]  R2798     1.6749604837968946e-03
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2799     -1
    z[6,5,0]  R2800     1
    z[6,5,0]  R2813     -1.3540515303611755e-01
    z[6,5,0]  R2814     -1.8146499991416931e-01
    z[6,5,0]  R2815     -1.1458253115415573e-01
    z[6,5,0]  R2816     2.4590075016021729e-01
    z[6,5,0]  R2817     -1.9872394204139709e-01
    z[6,5,0]  R2818     -3.5660693049430847e-01
    z[6,5,0]  R2819     1.5453067421913147e-01
    z[6,5,0]  R2820     2.2420710325241089e-01
    z[6,5,0]  R2821     1.5158204734325409e-01
    z[6,5,0]  R2822     2.6731389760971069e-01
    z[6,5,0]  R2823     -5.2680999040603638e-01
    z[6,5,0]  R2824     3.3764970302581787e-01
    z[6,5,0]  R2825     -1.2792757153511047e-01
    z[6,5,0]  R2826     1.6103994846343994e-01
    z[6,5,0]  R2827     5.2135378122329712e-01
    z[6,5,0]  R2828     5.9990906715393066e-01
    z[6,5,0]  R2829     3.3722755312919617e-01
    z[6,5,0]  R2830     1.8013438582420349e-01
    z[6,5,0]  R2831     -0.107862688601017
    z[6,5,0]  R2832     3.6219507455825806e-01
    z[6,5,0]  R2833     1.5011836588382721e-01
    z[6,5,0]  R2834     1.5852367877960205e-01
    z[6,5,0]  R2835     -6.0171049833297729e-01
    z[6,5,0]  R2836     5.0972029566764832e-03
    z[6,5,0]  R2837     -2.3490250110626221e-01
    z[6,5,0]  R2838     -0.58235764503479
    z[6,5,0]  R2839     -3.8865572214126587e-01
    z[6,5,0]  R2840     -6.6175174713134766e-01
    z[6,5,0]  R2841     1.3481132686138153e-01
    z[6,5,0]  R2842     3.1511485576629639e-02
    z[6,5,0]  R2843     -9.6586331725120544e-02
    z[6,5,0]  R2844     -2.2670675814151764e-01
    z[6,5,0]  R2845     3.0439281463623047e-01
    z[6,5,0]  R2846     -3.5883578658103943e-01
    z[6,5,0]  R2847     -3.6778151988983154e-01
    z[6,5,0]  R2848     1.4055030420422554e-02
    z[6,5,0]  R2849     -2.7112754061818123e-02
    z[6,5,0]  R2850     1.8437290191650391e-01
    z[6,5,0]  R2851     3.1333580613136292e-01
    z[6,5,0]  R2852     1.6550573706626892e-01
    z[6,5,0]  R2853     -2.2626711428165436e-01
    z[6,5,0]  R2854     -3.5421958565711975e-01
    z[6,5,0]  R2855     1.0648952424526215e-01
    z[6,5,0]  R2856     0.0934305191040039
    z[6,5,0]  R2857     -1.3700267672538757e-01
    z[6,5,0]  R2858     -2.2628770768642426e-01
    z[6,5,0]  R2859     0.297559529542923
    z[6,5,0]  R2860     1.7040875554084778e-01
    z[6,5,0]  R2861     0.509533703327179
    z[6,5,0]  R2862     0.547876238822937
    z[6,5,0]  R2863     -1.1656825244426727e-01
    z[6,5,0]  R2864     -2.2897545248270035e-02
    z[6,5,0]  R2865     0.0225005391985178
    z[6,5,0]  R2866     -2.7690127491950989e-01
    z[6,5,0]  R2867     2.2823049128055573e-01
    z[6,5,0]  R2868     2.1646852791309357e-01
    z[6,5,0]  R2869     6.0384386777877808e-01
    z[6,5,0]  R2870     0.574550986289978
    z[6,5,0]  R2871     9.1751128435134888e-02
    z[6,5,0]  R2872     -2.9391407966613770e-01
    z[6,5,0]  R2873     3.5134589672088623e-01
    z[6,5,0]  R2874     1.8095086514949799e-01
    z[6,5,0]  R2875     4.5932576060295105e-02
    z[6,5,0]  R2876     0.0817050188779831
    z[6,5,0]  R2877     1.5777802467346191e-01
    z[6,5,0]  R2878     -2.8450459241867065e-01
    z[6,5,0]  R2879     -2.5793009996414185e-01
    z[6,5,0]  R2880     2.9511460661888123e-01
    z[6,5,0]  R2881     -8.0357983708381653e-02
    z[6,5,0]  R2882     -2.6397609710693359e-01
    z[6,5,0]  R2883     -7.9158611595630646e-02
    z[6,5,0]  R2884     -1.3939459621906281e-01
    z[6,5,0]  R2885     3.3405673503875732e-01
    z[6,5,0]  R2886     -3.1011231243610382e-02
    z[6,5,0]  R2887     -2.3243987560272217e-01
    z[6,5,0]  R2888     6.5164053812623024e-03
    z[6,5,0]  R2889     -1.2624450027942657e-01
    z[6,5,0]  R2890     3.0309295654296875e-01
    z[6,5,0]  R2891     -6.2123370170593262e-01
    z[6,5,0]  R2892     -1.2315837293863297e-01
    z[6,5,0]  R2893     -7.4878519773483276e-01
    z[6,5,0]  R2894     1.7647108435630798e-01
    z[6,5,0]  R2895     -7.7983301877975464e-01
    z[6,5,0]  R2896     -4.7811153531074524e-01
    z[6,5,0]  R2897     -3.9945331215858459e-01
    z[6,5,0]  R2898     -7.3482406139373779e-01
    z[6,5,0]  R2899     -5.1747697591781616e-01
    z[6,5,0]  R2900     -5.3739684820175171e-01
    z[6,5,0]  R2901     5.9888356924057007e-01
    z[6,5,0]  R2902     1.9250044226646423e-01
    z[6,5,0]  R2903     3.4843954443931580e-01
    z[6,5,0]  R2904     -1.4973483979701996e-01
    z[6,5,0]  R2905     5.2489286661148071e-01
    z[6,5,0]  R2906     7.5461953878402710e-01
    z[6,5,0]  R2907     6.6458392143249512e-01
    z[6,5,0]  R2908     -2.1477121859788895e-02
    z[6,5,0]  R2909     0.493700236082077
    z[6,5,0]  R2910     5.5405634641647339e-01
    z[6,5,0]  R2911     -3.0755949020385742e-01
    z[6,5,0]  R2912     5.7791608572006226e-01
    z[6,5,0]  R2913     3.1935986876487732e-01
    z[6,5,0]  R2914     -5.7855671644210815e-01
    z[6,5,0]  R2915     2.0953913033008575e-01
    z[6,5,0]  R2916     2.7045177295804024e-02
    z[6,5,0]  R2917     1.8525169789791107e-01
    z[6,5,0]  R2918     7.2206068038940430e-01
    z[6,5,0]  R2919     0.537449300289154
    z[6,5,0]  R2920     7.2452224791049957e-02
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2801     -1
    z[6,5,1]  R2802     1
    z[6,5,1]  R2813     5.9156060218811035e-01
    z[6,5,1]  R2814     6.1252003908157349e-01
    z[6,5,1]  R2815     3.3040410280227661e-01
    z[6,5,1]  R2816     7.1475124359130859e-01
    z[6,5,1]  R2817     7.8449553251266479e-01
    z[6,5,1]  R2818     6.9461055099964142e-02
    z[6,5,1]  R2819     -6.2608772516250610e-01
    z[6,5,1]  R2820     0.651689350605011
    z[6,5,1]  R2821     -0.763340950012207
    z[6,5,1]  R2822     -6.0725015401840210e-01
    z[6,5,1]  R2823     2.6873454451560974e-01
    z[6,5,1]  R2824     2.9936638474464417e-01
    z[6,5,1]  R2825     5.9346508979797363e-01
    z[6,5,1]  R2826     -9.4619792699813843e-01
    z[6,5,1]  R2827     -0.740623414516449
    z[6,5,1]  R2828     -6.8825989961624146e-01
    z[6,5,1]  R2829     -7.1170818805694580e-01
    z[6,5,1]  R2830     -7.4227726459503174e-01
    z[6,5,1]  R2831     4.0774738788604736e-01
    z[6,5,1]  R2832     -7.3594230413436890e-01
    z[6,5,1]  R2833     5.5974102020263672e-01
    z[6,5,1]  R2834     5.8711689710617065e-01
    z[6,5,1]  R2835     3.8535785675048828e-01
    z[6,5,1]  R2836     -3.0366463586688042e-02
    z[6,5,1]  R2837     1.5404240787029266e-01
    z[6,5,1]  R2838     3.3650639653205872e-01
    z[6,5,1]  R2839     4.0871241688728333e-01
    z[6,5,1]  R2840     -1.7309428751468658e-01
    z[6,5,1]  R2841     2.8831285238265991e-01
    z[6,5,1]  R2842     6.1456203460693359e-02
    z[6,5,1]  R2843     0.931501567363739
    z[6,5,1]  R2844     0.725002110004425
    z[6,5,1]  R2845     3.9444544911384583e-01
    z[6,5,1]  R2846     -1.6152249276638031e-01
    z[6,5,1]  R2847     2.9948723316192627e-01
    z[6,5,1]  R2848     2.3306940495967865e-01
    z[6,5,1]  R2849     -1.8271915614604950e-01
    z[6,5,1]  R2850     -8.4464186429977417e-01
    z[6,5,1]  R2851     -7.6121377944946289e-01
    z[6,5,1]  R2852     -8.0869638919830322e-01
    z[6,5,1]  R2853     0.27131387591362
    z[6,5,1]  R2854     5.6756451725959778e-02
    z[6,5,1]  R2855     -1.9486691057682037e-01
    z[6,5,1]  R2856     -5.3097051382064819e-01
    z[6,5,1]  R2857     -3.6388668417930603e-01
    z[6,5,1]  R2858     -4.2843598127365112e-01
    z[6,5,1]  R2859     -0.859521210193634
    z[6,5,1]  R2860     -0.878296434879303
    z[6,5,1]  R2861     -6.5130203962326050e-01
    z[6,5,1]  R2862     -6.2969833612442017e-01
    z[6,5,1]  R2863     8.3298072218894958e-02
    z[6,5,1]  R2864     1.2004360556602478e-01
    z[6,5,1]  R2865     -4.1857150197029114e-01
    z[6,5,1]  R2866     -3.4635263681411743e-01
    z[6,5,1]  R2867     -9.4786942005157471e-01
    z[6,5,1]  R2868     -9.4751822948455811e-01
    z[6,5,1]  R2869     -1.6938674449920654e-01
    z[6,5,1]  R2870     -0.0797528326511383
    z[6,5,1]  R2871     8.7547320127487183e-01
    z[6,5,1]  R2872     8.5558646917343140e-01
    z[6,5,1]  R2873     7.4692708253860474e-01
    z[6,5,1]  R2874     7.0906698703765869e-01
    z[6,5,1]  R2875     6.2525153160095215e-01
    z[6,5,1]  R2876     6.2553548812866211e-01
    z[6,5,1]  R2877     4.2846208810806274e-01
    z[6,5,1]  R2878     6.0804325342178345e-01
    z[6,5,1]  R2879     2.9897719621658325e-01
    z[6,5,1]  R2880     6.6439443826675415e-01
    z[6,5,1]  R2881     -9.2065292596817017e-01
    z[6,5,1]  R2882     -9.4883036613464355e-01
    z[6,5,1]  R2883     -8.4418761730194092e-01
    z[6,5,1]  R2884     -8.5557991266250610e-01
    z[6,5,1]  R2885     -8.8591217994689941e-01
    z[6,5,1]  R2886     -8.5599416494369507e-01
    z[6,5,1]  R2887     -0.837941586971283
    z[6,5,1]  R2888     -8.3161729574203491e-01
    z[6,5,1]  R2889     -8.2682949304580688e-01
    z[6,5,1]  R2890     -8.9267814159393311e-01
    z[6,5,1]  R2891     -9.1890551149845123e-02
    z[6,5,1]  R2892     -1.7950126528739929e-01
    z[6,5,1]  R2893     3.0340716242790222e-01
    z[6,5,1]  R2894     2.9247373342514038e-01
    z[6,5,1]  R2895     1.9021998345851898e-01
    z[6,5,1]  R2896     2.6451054215431213e-01
    z[6,5,1]  R2897     1.7234939336776733e-01
    z[6,5,1]  R2898     4.5606139302253723e-01
    z[6,5,1]  R2899     3.7726444005966187e-01
    z[6,5,1]  R2900     -2.4689415469765663e-02
    z[6,5,1]  R2901     -1.1694305390119553e-01
    z[6,5,1]  R2902     -6.3666746020317078e-02
    z[6,5,1]  R2903     -5.9154576063156128e-01
    z[6,5,1]  R2904     7.1902751922607422e-02
    z[6,5,1]  R2905     -5.9003078937530518e-01
    z[6,5,1]  R2906     -5.4779714345932007e-01
    z[6,5,1]  R2907     -5.7059872150421143e-01
    z[6,5,1]  R2908     -6.3786470890045166e-01
    z[6,5,1]  R2909     -6.7252731323242188e-01
    z[6,5,1]  R2910     -6.6398131847381592e-01
    z[6,5,1]  R2911     4.1244527697563171e-01
    z[6,5,1]  R2912     2.9022064805030823e-01
    z[6,5,1]  R2913     0.279297411441803
    z[6,5,1]  R2914     -0.230604350566864
    z[6,5,1]  R2915     1.7475579679012299e-01
    z[6,5,1]  R2916     8.5760280489921570e-02
    z[6,5,1]  R2917     -3.2181721925735474e-01
    z[6,5,1]  R2918     -2.1566207706928253e-01
    z[6,5,1]  R2919     -3.5702559351921082e-01
    z[6,5,1]  R2920     -6.3930189609527588e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2803     -1
    z[6,5,2]  R2804     1
    z[6,5,2]  R2813     -3.7073939893161878e-05
    z[6,5,2]  R2814     -9.4061434268951416e-02
    z[6,5,2]  R2815     -1.0151164606213570e-02
    z[6,5,2]  R2816     -3.6912170052528381e-01
    z[6,5,2]  R2817     -9.4815976917743683e-02
    z[6,5,2]  R2818     6.6864097118377686e-01
    z[6,5,2]  R2819     1.4853793382644653e-01
    z[6,5,2]  R2820     -2.0206044614315033e-01
    z[6,5,2]  R2821     5.1261745393276215e-02
    z[6,5,2]  R2822     5.7070064544677734e-01
    z[6,5,2]  R2823     1.9373928010463715e-01
    z[6,5,2]  R2824     -1.2308959662914276e-01
    z[6,5,2]  R2825     5.0703313201665878e-02
    z[6,5,2]  R2826     7.4863538146018982e-02
    z[6,5,2]  R2827     -2.7872905135154724e-01
    z[6,5,2]  R2828     -0.290794312953949
    z[6,5,2]  R2829     -8.2097806036472321e-02
    z[6,5,2]  R2830     1.1182001233100891e-01
    z[6,5,2]  R2831     1.9414447247982025e-01
    z[6,5,2]  R2832     -1.1578583717346191e-01
    z[6,5,2]  R2833     -3.4295099973678589e-01
    z[6,5,2]  R2834     -2.4560411274433136e-01
    z[6,5,2]  R2835     3.8912689685821533e-01
    z[6,5,2]  R2836     -1.2461658567190170e-01
    z[6,5,2]  R2837     3.0976501293480396e-03
    z[6,5,2]  R2838     4.9459049105644226e-01
    z[6,5,2]  R2839     1.7571765184402466e-01
    z[6,5,2]  R2840     4.7093614935874939e-01
    z[6,5,2]  R2841     -9.6561267971992493e-02
    z[6,5,2]  R2842     -2.7793669700622559e-01
    z[6,5,2]  R2843     -1.8980790674686432e-01
    z[6,5,2]  R2844     4.4485166668891907e-02
    z[6,5,2]  R2845     -4.0721407532691956e-01
    z[6,5,2]  R2846     1.6186350584030151e-01
    z[6,5,2]  R2847     4.1436710953712463e-01
    z[6,5,2]  R2848     -2.9058215022087097e-01
    z[6,5,2]  R2849     -1.3824518024921417e-01
    z[6,5,2]  R2850     -0.0147575493901968
    z[6,5,2]  R2851     -3.6450235638767481e-03
    z[6,5,2]  R2852     -1.9960529170930386e-03
    z[6,5,2]  R2853     -2.4927143007516861e-02
    z[6,5,2]  R2854     1.8710285425186157e-01
    z[6,5,2]  R2855     -2.4280165135860443e-01
    z[6,5,2]  R2856     -1.8334476277232170e-02
    z[6,5,2]  R2857     1.8672838807106018e-01
    z[6,5,2]  R2858     2.4049901962280273e-01
    z[6,5,2]  R2859     -8.7707303464412689e-02
    z[6,5,2]  R2860     1.1487445980310440e-01
    z[6,5,2]  R2861     -1.4127650856971741e-01
    z[6,5,2]  R2862     -1.9877615571022034e-01
    z[6,5,2]  R2863     -6.0105919837951660e-02
    z[6,5,2]  R2864     -0.25982666015625
    z[6,5,2]  R2865     0.0089586041867733
    z[6,5,2]  R2866     1.5497873723506927e-01
    z[6,5,2]  R2867     7.0586748421192169e-02
    z[6,5,2]  R2868     3.0409701168537140e-02
    z[6,5,2]  R2869     7.0663064718246460e-01
    z[6,5,2]  R2870     6.9450670480728149e-01
    z[6,5,2]  R2871     2.2204430401325226e-01
    z[6,5,2]  R2872     -6.9286718964576721e-02
    z[6,5,2]  R2873     1.0267228819429874e-02
    z[6,5,2]  R2874     -3.1002461910247803e-02
    z[6,5,2]  R2875     1.0819110274314880e-01
    z[6,5,2]  R2876     -3.7111940979957581e-01
    z[6,5,2]  R2877     7.5985920429229736e-01
    z[6,5,2]  R2878     -2.4186022579669952e-01
    z[6,5,2]  R2879     7.5410521030426025e-01
    z[6,5,2]  R2880     -4.7407627105712891e-01
    z[6,5,2]  R2881     2.6614934206008911e-01
    z[6,5,2]  R2882     -4.7693509608507156e-02
    z[6,5,2]  R2883     2.5060348212718964e-02
    z[6,5,2]  R2884     -2.1321940422058105e-01
    z[6,5,2]  R2885     0.201337531208992
    z[6,5,2]  R2886     -2.9549381136894226e-01
    z[6,5,2]  R2887     -1.6530798375606537e-01
    z[6,5,2]  R2888     0.0824781134724617
    z[6,5,2]  R2889     -6.8636782467365265e-02
    z[6,5,2]  R2890     1.6016195714473724e-01
    z[6,5,2]  R2891     -4.8945721983909607e-01
    z[6,5,2]  R2892     5.1430130004882812e-01
    z[6,5,2]  R2893     3.4037387371063232e-01
    z[6,5,2]  R2894     -8.9806658029556274e-01
    z[6,5,2]  R2895     -0.0916375145316124
    z[6,5,2]  R2896     3.0163705348968506e-02
    z[6,5,2]  R2897     -4.7916686534881592e-01
    z[6,5,2]  R2898     -1.5109807252883911e-01
    z[6,5,2]  R2899     -3.7307778000831604e-01
    z[6,5,2]  R2900     -9.4032082706689835e-03
    z[6,5,2]  R2901     8.0027438700199127e-02
    z[6,5,2]  R2902     -5.8725923299789429e-02
    z[6,5,2]  R2903     1.0964184254407883e-01
    z[6,5,2]  R2904     -7.3334950208663940e-01
    z[6,5,2]  R2905     4.0528017282485962e-01
    z[6,5,2]  R2906     0.284252792596817
    z[6,5,2]  R2907     3.6815294623374939e-01
    z[6,5,2]  R2908     1.5899296104907990e-01
    z[6,5,2]  R2909     4.2180046439170837e-01
    z[6,5,2]  R2910     4.2704778909683228e-01
    z[6,5,2]  R2911     -5.3261661529541016e-01
    z[6,5,2]  R2912     -4.9754548072814941e-01
    z[6,5,2]  R2913     4.1682365536689758e-01
    z[6,5,2]  R2914     -9.4092383980751038e-02
    z[6,5,2]  R2915     6.6872701048851013e-02
    z[6,5,2]  R2916     5.3215879201889038e-01
    z[6,5,2]  R2917     4.9683311581611633e-01
    z[6,5,2]  R2918     4.9082070589065552e-01
    z[6,5,2]  R2919     6.5681940317153931e-01
    z[6,5,2]  R2920     6.7451059818267822e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2805     -1
    z[6,5,3]  R2806     1
    z[6,5,3]  R2813     1.8679147958755493e-01
    z[6,5,3]  R2814     -4.4278789311647415e-02
    z[6,5,3]  R2815     7.9929538071155548e-02
    z[6,5,3]  R2816     2.9882493615150452e-01
    z[6,5,3]  R2817     0.0489862896502018
    z[6,5,3]  R2818     -3.0913609080016613e-03
    z[6,5,3]  R2819     6.4784783124923706e-01
    z[6,5,3]  R2820     -5.0599642097949982e-02
    z[6,5,3]  R2821     7.8698612749576569e-02
    z[6,5,3]  R2822     1.6925598680973053e-01
    z[6,5,3]  R2823     -3.2823413610458374e-01
    z[6,5,3]  R2824     3.4984898567199707e-01
    z[6,5,3]  R2825     -3.0766350030899048e-01
    z[6,5,3]  R2826     4.0364719927310944e-02
    z[6,5,3]  R2827     -2.7162888646125793e-01
    z[6,5,3]  R2828     -1.4464857056736946e-02
    z[6,5,3]  R2829     8.4742859005928040e-02
    z[6,5,3]  R2830     -1.9598224759101868e-01
    z[6,5,3]  R2831     4.3875631690025330e-01
    z[6,5,3]  R2832     -1.6346287727355957e-01
    z[6,5,3]  R2833     -6.8979716300964355e-01
    z[6,5,3]  R2834     -3.6139088869094849e-01
    z[6,5,3]  R2835     -4.2000424861907959e-01
    z[6,5,3]  R2836     -6.9814813137054443e-01
    z[6,5,3]  R2837     -7.1037340164184570e-01
    z[6,5,3]  R2838     2.2700959444046021e-01
    z[6,5,3]  R2839     0.538135290145874
    z[6,5,3]  R2840     -2.0437745749950409e-01
    z[6,5,3]  R2841     8.8150733709335327e-01
    z[6,5,3]  R2842     -3.2526946067810059e-01
    z[6,5,3]  R2843     -1.4847362041473389e-01
    z[6,5,3]  R2844     5.6813931465148926e-01
    z[6,5,3]  R2845     -9.4906553626060486e-02
    z[6,5,3]  R2846     -6.2504941225051880e-01
    z[6,5,3]  R2847     2.7463027834892273e-01
    z[6,5,3]  R2848     -0.272591233253479
    z[6,5,3]  R2849     -7.9053580760955811e-01
    z[6,5,3]  R2850     -1.2500332295894623e-01
    z[6,5,3]  R2851     -2.5557151436805725e-01
    z[6,5,3]  R2852     -1.2475780397653580e-01
    z[6,5,3]  R2853     -3.4341163933277130e-02
    z[6,5,3]  R2854     -2.7871277928352356e-01
    z[6,5,3]  R2855     -8.3474278450012207e-01
    z[6,5,3]  R2856     -6.9614422321319580e-01
    z[6,5,3]  R2857     -6.7734891176223755e-01
    z[6,5,3]  R2858     -6.7219221591949463e-01
    z[6,5,3]  R2859     -3.2140710949897766e-01
    z[6,5,3]  R2860     -1.2192024849355221e-02
    z[6,5,3]  R2861     3.0854457616806030e-01
    z[6,5,3]  R2862     4.8076364398002625e-01
    z[6,5,3]  R2863     -9.0143275260925293e-01
    z[6,5,3]  R2864     -5.5771899223327637e-01
    z[6,5,3]  R2865     -8.2206577062606812e-01
    z[6,5,3]  R2866     -0.804474413394928
    z[6,5,3]  R2867     1.1394319683313370e-01
    z[6,5,3]  R2868     -1.3347879052162170e-01
    z[6,5,3]  R2869     2.9186752438545227e-01
    z[6,5,3]  R2870     3.9525943994522095e-01
    z[6,5,3]  R2871     -1.7188473045825958e-01
    z[6,5,3]  R2872     1.8126615881919861e-01
    z[6,5,3]  R2873     4.3439182639122009e-01
    z[6,5,3]  R2874     -1.2478467077016830e-01
    z[6,5,3]  R2875     1.9832178950309753e-01
    z[6,5,3]  R2876     4.3204563856124878e-01
    z[6,5,3]  R2877     1.1489140801131725e-02
    z[6,5,3]  R2878     -4.0967710316181183e-02
    z[6,5,3]  R2879     4.8574271798133850e-01
    z[6,5,3]  R2880     -4.3506991118192673e-02
    z[6,5,3]  R2881     -4.6891830861568451e-02
    z[6,5,3]  R2882     -2.8363440185785294e-02
    z[6,5,3]  R2883     1.3611934147775173e-02
    z[6,5,3]  R2884     -0.0231669619679451
    z[6,5,3]  R2885     2.2896258533000946e-01
    z[6,5,3]  R2886     3.4761503338813782e-01
    z[6,5,3]  R2887     2.6514670252799988e-01
    z[6,5,3]  R2888     1.0575447231531143e-01
    z[6,5,3]  R2889     4.9875143170356750e-01
    z[6,5,3]  R2890     7.5762018561363220e-02
    z[6,5,3]  R2891     -2.3659074306488037e-01
    z[6,5,3]  R2892     -2.6496499776840210e-01
    z[6,5,3]  R2893     -1.8247883021831512e-01
    z[6,5,3]  R2894     -2.2330953180789948e-01
    z[6,5,3]  R2895     -1.5001441538333893e-01
    z[6,5,3]  R2896     -4.4930616021156311e-01
    z[6,5,3]  R2897     -2.6776903867721558e-01
    z[6,5,3]  R2898     9.8131135106086731e-02
    z[6,5,3]  R2899     -2.6228803396224976e-01
    z[6,5,3]  R2900     -1.6434629261493683e-01
    z[6,5,3]  R2901     -6.9557195901870728e-01
    z[6,5,3]  R2902     -0.846520185470581
    z[6,5,3]  R2903     -4.7702023386955261e-01
    z[6,5,3]  R2904     -4.8704613000154495e-02
    z[6,5,3]  R2905     -1.0013290494680405e-01
    z[6,5,3]  R2906     -9.7566343843936920e-02
    z[6,5,3]  R2907     -8.4781445562839508e-02
    z[6,5,3]  R2908     -0.349507600069046
    z[6,5,3]  R2909     -4.1402030736207962e-02
    z[6,5,3]  R2910     1.7861567437648773e-01
    z[6,5,3]  R2911     -4.2533260583877563e-01
    z[6,5,3]  R2912     -2.0311589539051056e-01
    z[6,5,3]  R2913     -2.9586234688758850e-01
    z[6,5,3]  R2914     1.5119914710521698e-01
    z[6,5,3]  R2915     -4.7901135683059692e-01
    z[6,5,3]  R2916     -7.7033668756484985e-01
    z[6,5,3]  R2917     -5.8633148670196533e-01
    z[6,5,3]  R2918     -2.6660934090614319e-01
    z[6,5,3]  R2919     1.6089810431003571e-01
    z[6,5,3]  R2920     3.4706801176071167e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2807     -1
    z[6,5,4]  R2808     1
    z[6,5,4]  R2813     3.4189215302467346e-01
    z[6,5,4]  R2814     -1.3627833127975464e-01
    z[6,5,4]  R2815     -0.111341193318367
    z[6,5,4]  R2816     4.4122478365898132e-01
    z[6,5,4]  R2817     -4.4462826102972031e-02
    z[6,5,4]  R2818     4.0168440341949463e-01
    z[6,5,4]  R2819     2.2923342883586884e-01
    z[6,5,4]  R2820     -4.7273480892181396e-01
    z[6,5,4]  R2821     5.8079534769058228e-01
    z[6,5,4]  R2822     2.5078555941581726e-01
    z[6,5,4]  R2823     6.5549755096435547e-01
    z[6,5,4]  R2824     -5.1414966583251953e-01
    z[6,5,4]  R2825     -5.3345358371734619e-01
    z[6,5,4]  R2826     -1.3015829026699066e-01
    z[6,5,4]  R2827     -8.5632158443331718e-03
    z[6,5,4]  R2828     -2.7972236275672913e-01
    z[6,5,4]  R2829     3.5864907503128052e-01
    z[6,5,4]  R2830     -4.1146072745323181e-01
    z[6,5,4]  R2831     -3.7646195292472839e-01
    z[6,5,4]  R2832     -7.9846596345305443e-03
    z[6,5,4]  R2833     1.5329687297344208e-01
    z[6,5,4]  R2834     -6.2212800979614258e-01
    z[6,5,4]  R2835     5.5183735676109791e-03
    z[6,5,4]  R2836     -2.9356116056442261e-01
    z[6,5,4]  R2837     -4.8711401224136353e-01
    z[6,5,4]  R2838     -1.0112939774990082e-01
    z[6,5,4]  R2839     3.0689540505409241e-01
    z[6,5,4]  R2840     -9.3758301809430122e-03
    z[6,5,4]  R2841     2.0063920319080353e-01
    z[6,5,4]  R2842     5.8596688508987427e-01
    z[6,5,4]  R2843     2.3003134131431580e-01
    z[6,5,4]  R2844     -6.3085383735597134e-03
    z[6,5,4]  R2845     2.6756027340888977e-01
    z[6,5,4]  R2846     5.7051169872283936e-01
    z[6,5,4]  R2847     -3.7801295518875122e-01
    z[6,5,4]  R2848     2.4625961482524872e-01
    z[6,5,4]  R2849     -1.7379105091094971e-01
    z[6,5,4]  R2850     2.6957783102989197e-01
    z[6,5,4]  R2851     -0.25974240899086
    z[6,5,4]  R2852     5.2982503175735474e-01
    z[6,5,4]  R2853     5.3899204730987549e-01
    z[6,5,4]  R2854     8.0369651317596436e-01
    z[6,5,4]  R2855     6.0987651348114014e-02
    z[6,5,4]  R2856     4.5826774090528488e-02
    z[6,5,4]  R2857     -5.1132738590240479e-01
    z[6,5,4]  R2858     -2.9330241680145264e-01
    z[6,5,4]  R2859     1.3294976949691772e-01
    z[6,5,4]  R2860     2.1586577594280243e-01
    z[6,5,4]  R2861     2.0460948348045349e-01
    z[6,5,4]  R2862     7.9268246889114380e-02
    z[6,5,4]  R2863     -3.7390011548995972e-01
    z[6,5,4]  R2864     1.3041408360004425e-01
    z[6,5,4]  R2865     5.6369446218013763e-02
    z[6,5,4]  R2866     -2.6048952341079712e-01
    z[6,5,4]  R2867     1.4222750067710876e-01
    z[6,5,4]  R2868     -5.8729931712150574e-02
    z[6,5,4]  R2869     -1.0785602778196335e-01
    z[6,5,4]  R2870     -6.0210663825273514e-02
    z[6,5,4]  R2871     2.3010133206844330e-01
    z[6,5,4]  R2872     3.4058505296707153e-01
    z[6,5,4]  R2873     1.6457255184650421e-01
    z[6,5,4]  R2874     1.1215513199567795e-01
    z[6,5,4]  R2875     2.1339850500226021e-03
    z[6,5,4]  R2876     2.0488698035478592e-02
    z[6,5,4]  R2877     1.5322379767894745e-02
    z[6,5,4]  R2878     6.2139028310775757e-01
    z[6,5,4]  R2879     4.9387805163860321e-02
    z[6,5,4]  R2880     1.4650250971317291e-01
    z[6,5,4]  R2881     -1.3256011903285980e-01
    z[6,5,4]  R2882     3.7601027637720108e-02
    z[6,5,4]  R2883     -3.1871777772903442e-01
    z[6,5,4]  R2884     2.6871031522750854e-01
    z[6,5,4]  R2885     4.8271864652633667e-02
    z[6,5,4]  R2886     2.1161170303821564e-01
    z[6,5,4]  R2887     -3.2673040404915810e-03
    z[6,5,4]  R2888     0.360588401556015
    z[6,5,4]  R2889     0.0846773162484169
    z[6,5,4]  R2890     0.078289695084095
    z[6,5,4]  R2891     -2.1471163630485535e-01
    z[6,5,4]  R2892     4.7779548168182373e-01
    z[6,5,4]  R2893     -1.5561152994632721e-01
    z[6,5,4]  R2894     6.5029174089431763e-02
    z[6,5,4]  R2895     -5.4568547010421753e-01
    z[6,5,4]  R2896     -2.0039555430412292e-01
    z[6,5,4]  R2897     -6.9484390318393707e-02
    z[6,5,4]  R2898     -3.6225995421409607e-01
    z[6,5,4]  R2899     -3.3178317546844482e-01
    z[6,5,4]  R2900     -4.5058351755142212e-01
    z[6,5,4]  R2901     -1.4191937446594238e-01
    z[6,5,4]  R2902     -3.5129639506340027e-01
    z[6,5,4]  R2903     -2.0226357877254486e-01
    z[6,5,4]  R2904     -1.7484459280967712e-01
    z[6,5,4]  R2905     -2.4712309241294861e-01
    z[6,5,4]  R2906     -1.8820452690124512e-01
    z[6,5,4]  R2907     -7.1713291108608246e-02
    z[6,5,4]  R2908     -3.2527527213096619e-01
    z[6,5,4]  R2909     -3.5218662023544312e-01
    z[6,5,4]  R2910     0.144295796751976
    z[6,5,4]  R2911     -3.9359182119369507e-01
    z[6,5,4]  R2912     5.1760542392730713e-01
    z[6,5,4]  R2913     6.9337749481201172e-01
    z[6,5,4]  R2914     3.5283794999122620e-01
    z[6,5,4]  R2915     5.1066315174102783e-01
    z[6,5,4]  R2916     -2.9012659192085266e-01
    z[6,5,4]  R2917     -1.2565696239471436e-01
    z[6,5,4]  R2918     -2.2074703872203827e-01
    z[6,5,4]  R2919     2.0937354862689972e-01
    z[6,5,4]  R2920     -5.6084852665662766e-02
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2809     -1
    z[6,5,5]  R2810     1
    z[6,5,5]  R2813     0.528590977191925
    z[6,5,5]  R2814     7.1026724576950073e-01
    z[6,5,5]  R2815     9.1388291120529175e-01
    z[6,5,5]  R2816     -2.9233081266283989e-02
    z[6,5,5]  R2817     -1.8909063935279846e-01
    z[6,5,5]  R2818     4.2841640114784241e-01
    z[6,5,5]  R2819     1.3852208852767944e-01
    z[6,5,5]  R2820     -2.5052863359451294e-01
    z[6,5,5]  R2821     -2.0143085718154907e-01
    z[6,5,5]  R2822     2.2526636719703674e-01
    z[6,5,5]  R2823     -4.2061571031808853e-02
    z[6,5,5]  R2824     -2.2896220907568932e-02
    z[6,5,5]  R2825     -2.8610411286354065e-01
    z[6,5,5]  R2826     1.5323950350284576e-01
    z[6,5,5]  R2827     -1.5778636932373047e-01
    z[6,5,5]  R2828     -4.3013781309127808e-02
    z[6,5,5]  R2829     3.2962355017662048e-01
    z[6,5,5]  R2830     4.1474539786577225e-02
    z[6,5,5]  R2831     -6.0724008083343506e-01
    z[6,5,5]  R2832     4.2287012934684753e-01
    z[6,5,5]  R2833     -5.1012925803661346e-02
    z[6,5,5]  R2834     1.2685698270797729e-01
    z[6,5,5]  R2835     -1.9729802012443542e-01
    z[6,5,5]  R2836     6.3614523410797119e-01
    z[6,5,5]  R2837     3.1838470697402954e-01
    z[6,5,5]  R2838     -4.6052387356758118e-01
    z[6,5,5]  R2839     1.6816663742065430e-01
    z[6,5,5]  R2840     5.0231683254241943e-01
    z[6,5,5]  R2841     1.0454358160495758e-01
    z[6,5,5]  R2842     0.260141521692276
    z[6,5,5]  R2843     9.3274883925914764e-02
    z[6,5,5]  R2844     1.6127622127532959e-01
    z[6,5,5]  R2845     6.9633203744888306e-01
    z[6,5,5]  R2846     2.9558527469635010e-01
    z[6,5,5]  R2847     -1.0555070638656616e-01
    z[6,5,5]  R2848     1.5233403444290161e-01
    z[6,5,5]  R2849     -5.9906851500272751e-02
    z[6,5,5]  R2850     -0.296150267124176
    z[6,5,5]  R2851     -1.8459224700927734e-01
    z[6,5,5]  R2852     -1.4714795351028442e-01
    z[6,5,5]  R2853     7.5066995620727539e-01
    z[6,5,5]  R2854     1.3029675185680389e-01
    z[6,5,5]  R2855     -1.4577963948249817e-01
    z[6,5,5]  R2856     -4.6445944905281067e-01
    z[6,5,5]  R2857     -1.0121800005435944e-01
    z[6,5,5]  R2858     -4.0525132417678833e-01
    z[6,5,5]  R2859     1.6238564252853394e-01
    z[6,5,5]  R2860     -2.9147368669509888e-01
    z[6,5,5]  R2861     -1.3680888712406158e-01
    z[6,5,5]  R2862     -1.6233567893505096e-01
    z[6,5,5]  R2863     1.5122829377651215e-01
    z[6,5,5]  R2864     4.0020561218261719e-01
    z[6,5,5]  R2865     -1.0169178247451782e-01
    z[6,5,5]  R2866     -6.7678354680538177e-02
    z[6,5,5]  R2867     -2.8892930597066879e-02
    z[6,5,5]  R2868     -1.4586250483989716e-01
    z[6,5,5]  R2869     -7.0206761360168457e-02
    z[6,5,5]  R2870     1.4605778455734253e-01
    z[6,5,5]  R2871     1.6349695622920990e-02
    z[6,5,5]  R2872     4.0406482294201851e-03
    z[6,5,5]  R2873     -2.8824573755264282e-01
    z[6,5,5]  R2874     6.4108437299728394e-01
    z[6,5,5]  R2875     2.6808005571365356e-01
    z[6,5,5]  R2876     3.5143008828163147e-01
    z[6,5,5]  R2877     -1.1392273753881454e-01
    z[6,5,5]  R2878     2.9049047827720642e-01
    z[6,5,5]  R2879     1.9229158759117126e-01
    z[6,5,5]  R2880     -1.3685730099678040e-01
    z[6,5,5]  R2881     2.3453648388385773e-01
    z[6,5,5]  R2882     -0.155681312084198
    z[6,5,5]  R2883     -2.1839885041117668e-02
    z[6,5,5]  R2884     1.5839838981628418e-01
    z[6,5,5]  R2885     9.0267747640609741e-02
    z[6,5,5]  R2886     1.0915318131446838e-01
    z[6,5,5]  R2887     2.9655680060386658e-01
    z[6,5,5]  R2888     1.3262277841567993e-01
    z[6,5,5]  R2889     -0.0666360929608345
    z[6,5,5]  R2890     -2.6828205585479736e-01
    z[6,5,5]  R2891     2.8831627964973450e-01
    z[6,5,5]  R2892     6.0940408706665039e-01
    z[6,5,5]  R2893     -2.6306754350662231e-01
    z[6,5,5]  R2894     3.0098492279648781e-03
    z[6,5,5]  R2895     1.1404132843017578e-01
    z[6,5,5]  R2896     -3.3031675219535828e-01
    z[6,5,5]  R2897     -2.3639994859695435e-01
    z[6,5,5]  R2898     -1.1001867055892944e-01
    z[6,5,5]  R2899     -3.6067163944244385e-01
    z[6,5,5]  R2900     5.5549168586730957e-01
    z[6,5,5]  R2901     3.3442208170890808e-01
    z[6,5,5]  R2902     2.1022740006446838e-01
    z[6,5,5]  R2903     4.3663203716278076e-01
    z[6,5,5]  R2904     5.2558046579360962e-01
    z[6,5,5]  R2905     3.7022992968559265e-01
    z[6,5,5]  R2906     2.5225467979907990e-02
    z[6,5,5]  R2907     2.4903084337711334e-01
    z[6,5,5]  R2908     5.6108510494232178e-01
    z[6,5,5]  R2909     1.4927624724805355e-02
    z[6,5,5]  R2910     9.7732760012149811e-02
    z[6,5,5]  R2911     2.3926517367362976e-01
    z[6,5,5]  R2912     1.5449105203151703e-01
    z[6,5,5]  R2913     -6.4368017017841339e-02
    z[6,5,5]  R2914     6.5900111198425293e-01
    z[6,5,5]  R2915     -1.0784979909658432e-01
    z[6,5,5]  R2916     1.7631146311759949e-01
    z[6,5,5]  R2917     0.00893962662667036
    z[6,5,5]  R2918     5.4915450513362885e-02
    z[6,5,5]  R2919     -2.6482370495796204e-01
    z[6,5,5]  R2920     0.0788489356637001
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2811     -1
    z[6,5,6]  R2812     1
    z[6,5,6]  R2813     4.4780775904655457e-01
    z[6,5,6]  R2814     -2.4089443683624268e-01
    z[6,5,6]  R2815     1.5373152494430542e-01
    z[6,5,6]  R2816     -0.0870768278837204
    z[6,5,6]  R2817     -5.4401624202728271e-01
    z[6,5,6]  R2818     -2.7572691440582275e-01
    z[6,5,6]  R2819     2.6575896143913269e-01
    z[6,5,6]  R2820     4.4204148650169373e-01
    z[6,5,6]  R2821     8.7261833250522614e-02
    z[6,5,6]  R2822     -3.0299395322799683e-01
    z[6,5,6]  R2823     -2.7117198705673218e-01
    z[6,5,6]  R2824     6.2765669822692871e-01
    z[6,5,6]  R2825     4.0960687398910522e-01
    z[6,5,6]  R2826     -1.7640371620655060e-01
    z[6,5,6]  R2827     -0.0567912831902504
    z[6,5,6]  R2828     -3.9269987493753433e-02
    z[6,5,6]  R2829     3.5853415727615356e-01
    z[6,5,6]  R2830     4.4118392467498779e-01
    z[6,5,6]  R2831     2.8538459539413452e-01
    z[6,5,6]  R2832     3.2892918586730957e-01
    z[6,5,6]  R2833     2.1122667193412781e-01
    z[6,5,6]  R2834     1.9000871479511261e-01
    z[6,5,6]  R2835     3.5023361444473267e-01
    z[6,5,6]  R2836     7.2476804256439209e-02
    z[6,5,6]  R2837     -2.7893170714378357e-01
    z[6,5,6]  R2838     1.7076477408409119e-01
    z[6,5,6]  R2839     -4.8884540796279907e-01
    z[6,5,6]  R2840     -1.2712916731834412e-01
    z[6,5,6]  R2841     -2.4725881218910217e-01
    z[6,5,6]  R2842     -6.3336426019668579e-01
    z[6,5,6]  R2843     5.7357203215360641e-02
    z[6,5,6]  R2844     -0.268635094165802
    z[6,5,6]  R2845     1.4303991198539734e-01
    z[6,5,6]  R2846     1.2412270158529282e-01
    z[6,5,6]  R2847     6.1146342754364014e-01
    z[6,5,6]  R2848     -8.3838403224945068e-01
    z[6,5,6]  R2849     -5.3668224811553955e-01
    z[6,5,6]  R2850     -2.7634406089782715e-01
    z[6,5,6]  R2851     3.9433974027633667e-01
    z[6,5,6]  R2852     -2.6123058050870895e-02
    z[6,5,6]  R2853     -1.3918830454349518e-01
    z[6,5,6]  R2854     3.0937612056732178e-01
    z[6,5,6]  R2855     -4.1227099299430847e-01
    z[6,5,6]  R2856     8.1027291715145111e-02
    z[6,5,6]  R2857     2.8887173533439636e-01
    z[6,5,6]  R2858     7.2796165943145752e-02
    z[6,5,6]  R2859     1.3282217085361481e-01
    z[6,5,6]  R2860     0.233786940574646
    z[6,5,6]  R2861     3.7475389242172241e-01
    z[6,5,6]  R2862     -5.4427143186330795e-03
    z[6,5,6]  R2863     -2.4663519114255905e-02
    z[6,5,6]  R2864     -6.5523463487625122e-01
    z[6,5,6]  R2865     3.6728808283805847e-01
    z[6,5,6]  R2866     -2.4440322816371918e-01
    z[6,5,6]  R2867     1.0210485011339188e-01
    z[6,5,6]  R2868     -1.0901399701833725e-01
    z[6,5,6]  R2869     -7.4868492782115936e-02
    z[6,5,6]  R2870     1.6749604837968946e-03
    z[6,5,6]  R2871     3.0506783723831177e-01
    z[6,5,6]  R2872     -1.6707411408424377e-01
    z[6,5,6]  R2873     -1.4030157029628754e-01
    z[6,5,6]  R2874     -1.5614232420921326e-01
    z[6,5,6]  R2875     -6.9573158025741577e-01
    z[6,5,6]  R2876     3.9206331968307495e-01
    z[6,5,6]  R2877     -4.4810160994529724e-01
    z[6,5,6]  R2878     -1.3658446073532104e-01
    z[6,5,6]  R2879     6.9953277707099915e-03
    z[6,5,6]  R2880     -4.5238631963729858e-01
    z[6,5,6]  R2881     -1.8078187480568886e-02
    z[6,5,6]  R2882     3.6166332662105560e-02
    z[6,5,6]  R2883     -4.2214909195899963e-01
    z[6,5,6]  R2884     3.2443445920944214e-01
    z[6,5,6]  R2885     -1.1246681213378906e-02
    z[6,5,6]  R2886     0.0382811576128006
    z[6,5,6]  R2887     -2.4132886528968811e-01
    z[6,5,6]  R2888     -3.7785002589225769e-01
    z[6,5,6]  R2889     -1.8799139559268951e-01
    z[6,5,6]  R2890     -4.2002037167549133e-02
    z[6,5,6]  R2891     4.2526909708976746e-01
    z[6,5,6]  R2892     1.3504503667354584e-01
    z[6,5,6]  R2893     3.2356211543083191e-01
    z[6,5,6]  R2894     1.5062689781188965e-01
    z[6,5,6]  R2895     -1.1830971390008926e-01
    z[6,5,6]  R2896     5.9109228849411011e-01
    z[6,5,6]  R2897     6.6986465454101562e-01
    z[6,5,6]  R2898     -2.7612483501434326e-01
    z[6,5,6]  R2899     3.7648779153823853e-01
    z[6,5,6]  R2900     -4.1460883617401123e-01
    z[6,5,6]  R2901     -7.3883078992366791e-02
    z[6,5,6]  R2902     2.6690849661827087e-01
    z[6,5,6]  R2903     2.3986613750457764e-01
    z[6,5,6]  R2904     -0.35416179895401
    z[6,5,6]  R2905     6.2710128724575043e-02
    z[6,5,6]  R2906     -6.3965469598770142e-02
    z[6,5,6]  R2907     -1.5120127797126770e-01
    z[6,5,6]  R2908     1.5688399970531464e-01
    z[6,5,6]  R2909     8.8956616818904877e-03
    z[6,5,6]  R2910     8.6626596748828888e-02
    z[6,5,6]  R2911     -2.4196162819862366e-01
    z[6,5,6]  R2912     -3.4563142806291580e-02
    z[6,5,6]  R2913     2.7168050408363342e-01
    z[6,5,6]  R2914     1.4697673916816711e-01
    z[6,5,6]  R2915     6.4747321605682373e-01
    z[6,5,6]  R2916     6.5576941706240177e-03
    z[6,5,6]  R2917     5.0558692216873169e-01
    z[6,5,6]  R2918     2.6151040196418762e-01
    z[6,5,6]  R2919     1.1140928417444229e-01
    z[6,5,6]  R2920     -3.5501249134540558e-02
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R63       1
    RHS1      R64       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[7,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,4]
 BV BND1      phi[4,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[1,6]
 BV BND1      phi[6,1]
 BV BND1      phi[2,5]
 BV BND1      phi[5,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[2,8]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[3,5]
 BV BND1      phi[5,3]
 BV BND1      phi[7,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,8]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,4,0]
 FR BND1      z[1,4,1]
 FR BND1      z[1,4,2]
 FR BND1      z[1,4,3]
 FR BND1      z[1,4,4]
 FR BND1      z[1,4,5]
 FR BND1      z[1,4,6]
 FR BND1      z[4,1,0]
 FR BND1      z[4,1,1]
 FR BND1      z[4,1,2]
 FR BND1      z[4,1,3]
 FR BND1      z[4,1,4]
 FR BND1      z[4,1,5]
 FR BND1      z[4,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[1,6,0]
 FR BND1      z[1,6,1]
 FR BND1      z[1,6,2]
 FR BND1      z[1,6,3]
 FR BND1      z[1,6,4]
 FR BND1      z[1,6,5]
 FR BND1      z[1,6,6]
 FR BND1      z[6,1,0]
 FR BND1      z[6,1,1]
 FR BND1      z[6,1,2]
 FR BND1      z[6,1,3]
 FR BND1      z[6,1,4]
 FR BND1      z[6,1,5]
 FR BND1      z[6,1,6]
 FR BND1      z[2,5,0]
 FR BND1      z[2,5,1]
 FR BND1      z[2,5,2]
 FR BND1      z[2,5,3]
 FR BND1      z[2,5,4]
 FR BND1      z[2,5,5]
 FR BND1      z[2,5,6]
 FR BND1      z[5,2,0]
 FR BND1      z[5,2,1]
 FR BND1      z[5,2,2]
 FR BND1      z[5,2,3]
 FR BND1      z[5,2,4]
 FR BND1      z[5,2,5]
 FR BND1      z[5,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[3,5,0]
 FR BND1      z[3,5,1]
 FR BND1      z[3,5,2]
 FR BND1      z[3,5,3]
 FR BND1      z[3,5,4]
 FR BND1      z[3,5,5]
 FR BND1      z[3,5,6]
 FR BND1      z[5,3,0]
 FR BND1      z[5,3,1]
 FR BND1      z[5,3,2]
 FR BND1      z[5,3,3]
 FR BND1      z[5,3,4]
 FR BND1      z[5,3,5]
 FR BND1      z[5,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
ENDATA
