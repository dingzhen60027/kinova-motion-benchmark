NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 L  R73     
 E  R74     
 E  R75     
 E  R76     
 E  R77     
 E  R78     
 E  R79     
 E  R80     
 E  R81     
 L  R82     
 E  R83     
 E  R84     
 E  R85     
 E  R86     
 E  R87     
 E  R88     
 E  R89     
 E  R90     
 E  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
 L  qc8     
 L  qc9     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R92       -3.0999999046325684e+00
    phi[0,1]  R93       -3.0999999046325684e+00
    phi[0,1]  R94       -2.2400000095367432e+00
    phi[0,1]  R95       -2.2400000095367432e+00
    phi[0,1]  R96       -3.0999999046325684e+00
    phi[0,1]  R97       -3.0999999046325684e+00
    phi[0,1]  R98       -2.5699999332427979e+00
    phi[0,1]  R99       -2.5699999332427979e+00
    phi[0,1]  R100      -3.0999999046325684e+00
    phi[0,1]  R101      -3.0999999046325684e+00
    phi[0,1]  R102      -2.0899999141693115e+00
    phi[0,1]  R103      -2.0899999141693115e+00
    phi[0,1]  R104      -3.0999999046325684e+00
    phi[0,1]  R105      -3.0999999046325684e+00
    phi[0,1]  R106      2.1111133098602295e+00
    phi[0,1]  R107      1.2405002117156982e+00
    phi[0,1]  R108      9.9406063556671143e-01
    phi[0,1]  R109      1.6866980791091919e+00
    phi[0,1]  R110      1.9280288219451904e+00
    phi[0,1]  R111      1.3586753606796265e+00
    phi[0,1]  R112      4.8280379176139832e-01
    phi[0,1]  R113      9.1404080390930176e-02
    phi[0,1]  R114      1.1769498586654663e+00
    phi[0,1]  R115      1.7412993907928467e+00
    phi[0,1]  R116      3.3208038657903671e-02
    phi[0,1]  R117      3.9561790227890015e-01
    phi[0,1]  R118      -1.3896132707595825e+00
    phi[0,1]  R119      -1.5441114902496338e+00
    phi[0,1]  R120      6.7641323804855347e-01
    phi[0,1]  R121      1.0858708620071411e+00
    phi[0,1]  R122      1.4311429262161255e+00
    phi[0,1]  R123      1.5027213096618652e+00
    phi[0,1]  R124      5.1756536960601807e-01
    phi[0,1]  R125      -1.7241834402084351e+00
    phi[0,1]  R126      -1.6303300857543945e+00
    phi[0,1]  R127      -1.4130406379699707e+00
    phi[0,1]  R128      -1.8679690361022949e+00
    phi[0,1]  R129      -1.7106771469116211e+00
    phi[0,1]  R130      -4.4275146722793579e-01
    phi[0,1]  R131      -3.0449658632278442e-01
    phi[0,1]  R132      -1.6108542680740356e+00
    phi[0,1]  R133      2.0795999467372894e-01
    phi[0,1]  R134      -2.9758825898170471e-01
    phi[0,1]  R135      -9.8760712146759033e-01
    phi[0,1]  R136      -9.3340158462524414e-01
    phi[0,1]  R137      -1.39418625831604
    phi[0,1]  R138      -8.4509927034378052e-01
    phi[0,1]  R139      -7.9650598764419556e-01
    phi[0,1]  R140      -9.5198571681976318e-01
    phi[0,1]  R141      7.8030876815319061e-02
    phi[0,1]  R142      -1.9262020587921143e+00
    phi[0,1]  R143      2.4219554662704468e-01
    phi[0,1]  R144      4.4177421927452087e-01
    phi[0,1]  R145      -4.5119118690490723e-01
    phi[0,1]  R146      -2.0381007194519043e+00
    phi[0,1]  R147      3.1324726343154907e-01
    phi[0,1]  R148      3.4268283843994141e-01
    phi[0,1]  R149      1.7832143306732178e+00
    phi[0,1]  R150      7.5625765323638916e-01
    phi[0,1]  R151      1.1160174608230591e+00
    phi[0,1]  R152      -2.1530742645263672e+00
    phi[0,1]  R153      -4.9819093942642212e-01
    phi[0,1]  R154      -6.5312761068344116e-01
    phi[0,1]  R155      1.14546799659729
    phi[0,1]  R156      5.3793883323669434e-01
    phi[0,1]  R157      -1.2572054862976074e+00
    phi[0,1]  R158      -1.5476222038269043e+00
    phi[0,1]  R159      9.8605215549468994e-01
    phi[0,1]  R160      1.0055705904960632e-02
    phi[0,1]  R161      1.0746426582336426e+00
    phi[0,1]  R162      -5.4876990616321564e-02
    phi[0,1]  R163      3.0719954520463943e-03
    phi[0,1]  R164      2.7624544501304626e-01
    phi[0,1]  R165      2.4640098214149475e-01
    phi[0,1]  R166      1.7823770046234131e+00
    phi[0,1]  R167      1.8414847850799561e+00
    phi[0,1]  R168      1.6318974494934082e+00
    phi[0,1]  R169      1.3178656101226807e+00
    phi[0,1]  R170      1.0555876493453979e+00
    phi[0,1]  R171      8.0102640390396118e-01
    phi[0,1]  R172      5.6271618604660034e-01
    phi[0,1]  R173      1.7857429981231689e+00
    phi[0,1]  R174      1.3656859397888184e+00
    phi[0,1]  R175      1.5073101520538330e+00
    phi[0,1]  R176      -2.0515973567962646e+00
    phi[0,1]  R177      3.8029190897941589e-01
    phi[0,1]  R178      -4.0581017732620239e-01
    phi[0,1]  R179      -0.0988592877984047
    phi[0,1]  R180      -4.4718825817108154e-01
    phi[0,1]  R181      -1.0819220542907715e+00
    phi[0,1]  R182      -2.6537837982177734e+00
    phi[0,1]  R183      1.1160815954208374e+00
    phi[0,1]  R184      -8.8257211446762085e-01
    phi[0,1]  R185      1.0012186765670776e+00
    phi[0,1]  R186      -2.1105275154113770e+00
    phi[0,1]  R187      -1.7885791063308716e+00
    phi[0,1]  R188      -1.8100674152374268e+00
    phi[0,1]  R189      -1.8939080238342285e+00
    phi[0,1]  R190      -1.4730018377304077e+00
    phi[0,1]  R191      -5.8110469579696655e-01
    phi[0,1]  R192      -1.1079891920089722e+00
    phi[0,1]  R193      2.5218960642814636e-01
    phi[0,1]  R194      -2.0196737349033356e-01
    phi[0,1]  R195      -1.2990446090698242e+00
    phi[0,1]  R196      -1.7714790105819702e+00
    phi[0,1]  R197      -2.6203885674476624e-01
    phi[0,1]  R198      -4.6201121807098389e-01
    phi[0,1]  R199      -1.1703782081604004e+00
    phi[0,1]  R200      4.1271677613258362e-01
    phi[0,1]  R201      -5.8660662174224854e-01
    phi[0,1]  R202      -1.3668122291564941e+00
    phi[0,1]  R203      -2.1489934921264648e+00
    phi[0,1]  R204      -1.8899157047271729e+00
    phi[0,1]  R205      -8.8776206970214844e-01
    phi[0,1]  R206      -9.5157051086425781e-01
    phi[0,1]  R207      5.4105478525161743e-01
    phi[0,1]  R208      -1.5727872848510742e+00
    phi[0,1]  R209      -2.3860310018062592e-01
    phi[0,1]  R210      -1.2798976898193359e+00
    phi[0,1]  R211      -1.2325476408004761e+00
    phi[0,1]  R212      -1.6513645648956299e+00
    phi[0,1]  R213      -1.9905910491943359e+00
    phi[0,1]  R214      -2.2684124112129211e-01
    phi[0,1]  R215      1.6258996725082397e+00
    phi[0,1]  R216      -1.9279876947402954e+00
    phi[0,1]  R217      5.4483568668365479e-01
    phi[0,1]  R218      -8.4611111879348755e-01
    phi[0,1]  R219      1.8662067651748657e+00
    phi[0,1]  R220      -1.9398202896118164e+00
    phi[0,1]  R221      -1.0792801529169083e-01
    phi[0,1]  R222      -9.9833548069000244e-01
    phi[0,1]  R223      -8.1440013647079468e-01
    phi[0,1]  R224      1.6196583509445190e+00
    phi[0,1]  R225      3.0551645159721375e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R226      -3.0999999046325684e+00
    phi[1,0]  R227      -3.0999999046325684e+00
    phi[1,0]  R228      -2.2400000095367432e+00
    phi[1,0]  R229      -2.2400000095367432e+00
    phi[1,0]  R230      -3.0999999046325684e+00
    phi[1,0]  R231      -3.0999999046325684e+00
    phi[1,0]  R232      -2.5699999332427979e+00
    phi[1,0]  R233      -2.5699999332427979e+00
    phi[1,0]  R234      -3.0999999046325684e+00
    phi[1,0]  R235      -3.0999999046325684e+00
    phi[1,0]  R236      -2.0899999141693115e+00
    phi[1,0]  R237      -2.0899999141693115e+00
    phi[1,0]  R238      -3.0999999046325684e+00
    phi[1,0]  R239      -3.0999999046325684e+00
    phi[1,0]  R240      1.7823770046234131e+00
    phi[1,0]  R241      1.8414847850799561e+00
    phi[1,0]  R242      1.6318974494934082e+00
    phi[1,0]  R243      1.3178656101226807e+00
    phi[1,0]  R244      1.0555876493453979e+00
    phi[1,0]  R245      8.0102640390396118e-01
    phi[1,0]  R246      5.6271618604660034e-01
    phi[1,0]  R247      1.7857429981231689e+00
    phi[1,0]  R248      1.3656859397888184e+00
    phi[1,0]  R249      1.5073101520538330e+00
    phi[1,0]  R250      -2.0515973567962646e+00
    phi[1,0]  R251      3.8029190897941589e-01
    phi[1,0]  R252      -4.0581017732620239e-01
    phi[1,0]  R253      -0.0988592877984047
    phi[1,0]  R254      -4.4718825817108154e-01
    phi[1,0]  R255      -1.0819220542907715e+00
    phi[1,0]  R256      -2.6537837982177734e+00
    phi[1,0]  R257      1.1160815954208374e+00
    phi[1,0]  R258      -8.8257211446762085e-01
    phi[1,0]  R259      1.0012186765670776e+00
    phi[1,0]  R260      -2.1105275154113770e+00
    phi[1,0]  R261      -1.7885791063308716e+00
    phi[1,0]  R262      -1.8100674152374268e+00
    phi[1,0]  R263      -1.8939080238342285e+00
    phi[1,0]  R264      -1.4730018377304077e+00
    phi[1,0]  R265      -5.8110469579696655e-01
    phi[1,0]  R266      -1.1079891920089722e+00
    phi[1,0]  R267      2.5218960642814636e-01
    phi[1,0]  R268      -2.0196737349033356e-01
    phi[1,0]  R269      -1.2990446090698242e+00
    phi[1,0]  R270      -1.7714790105819702e+00
    phi[1,0]  R271      -2.6203885674476624e-01
    phi[1,0]  R272      -4.6201121807098389e-01
    phi[1,0]  R273      -1.1703782081604004e+00
    phi[1,0]  R274      4.1271677613258362e-01
    phi[1,0]  R275      -5.8660662174224854e-01
    phi[1,0]  R276      -1.3668122291564941e+00
    phi[1,0]  R277      -2.1489934921264648e+00
    phi[1,0]  R278      -1.8899157047271729e+00
    phi[1,0]  R279      -8.8776206970214844e-01
    phi[1,0]  R280      -9.5157051086425781e-01
    phi[1,0]  R281      5.4105478525161743e-01
    phi[1,0]  R282      -1.5727872848510742e+00
    phi[1,0]  R283      -2.3860310018062592e-01
    phi[1,0]  R284      -1.2798976898193359e+00
    phi[1,0]  R285      -1.2325476408004761e+00
    phi[1,0]  R286      -1.6513645648956299e+00
    phi[1,0]  R287      -1.9905910491943359e+00
    phi[1,0]  R288      -2.2684124112129211e-01
    phi[1,0]  R289      1.6258996725082397e+00
    phi[1,0]  R290      -1.9279876947402954e+00
    phi[1,0]  R291      5.4483568668365479e-01
    phi[1,0]  R292      -8.4611111879348755e-01
    phi[1,0]  R293      1.8662067651748657e+00
    phi[1,0]  R294      -1.9398202896118164e+00
    phi[1,0]  R295      -1.0792801529169083e-01
    phi[1,0]  R296      -9.9833548069000244e-01
    phi[1,0]  R297      -8.1440013647079468e-01
    phi[1,0]  R298      1.6196583509445190e+00
    phi[1,0]  R299      3.0551645159721375e-01
    phi[1,0]  R300      2.1111133098602295e+00
    phi[1,0]  R301      1.2405002117156982e+00
    phi[1,0]  R302      9.9406063556671143e-01
    phi[1,0]  R303      1.6866980791091919e+00
    phi[1,0]  R304      1.9280288219451904e+00
    phi[1,0]  R305      1.3586753606796265e+00
    phi[1,0]  R306      4.8280379176139832e-01
    phi[1,0]  R307      9.1404080390930176e-02
    phi[1,0]  R308      1.1769498586654663e+00
    phi[1,0]  R309      1.7412993907928467e+00
    phi[1,0]  R310      3.3208038657903671e-02
    phi[1,0]  R311      3.9561790227890015e-01
    phi[1,0]  R312      -1.3896132707595825e+00
    phi[1,0]  R313      -1.5441114902496338e+00
    phi[1,0]  R314      6.7641323804855347e-01
    phi[1,0]  R315      1.0858708620071411e+00
    phi[1,0]  R316      1.4311429262161255e+00
    phi[1,0]  R317      1.5027213096618652e+00
    phi[1,0]  R318      5.1756536960601807e-01
    phi[1,0]  R319      -1.7241834402084351e+00
    phi[1,0]  R320      -1.6303300857543945e+00
    phi[1,0]  R321      -1.4130406379699707e+00
    phi[1,0]  R322      -1.8679690361022949e+00
    phi[1,0]  R323      -1.7106771469116211e+00
    phi[1,0]  R324      -4.4275146722793579e-01
    phi[1,0]  R325      -3.0449658632278442e-01
    phi[1,0]  R326      -1.6108542680740356e+00
    phi[1,0]  R327      2.0795999467372894e-01
    phi[1,0]  R328      -2.9758825898170471e-01
    phi[1,0]  R329      -9.8760712146759033e-01
    phi[1,0]  R330      -9.3340158462524414e-01
    phi[1,0]  R331      -1.39418625831604
    phi[1,0]  R332      -8.4509927034378052e-01
    phi[1,0]  R333      -7.9650598764419556e-01
    phi[1,0]  R334      -9.5198571681976318e-01
    phi[1,0]  R335      7.8030876815319061e-02
    phi[1,0]  R336      -1.9262020587921143e+00
    phi[1,0]  R337      2.4219554662704468e-01
    phi[1,0]  R338      4.4177421927452087e-01
    phi[1,0]  R339      -4.5119118690490723e-01
    phi[1,0]  R340      -2.0381007194519043e+00
    phi[1,0]  R341      3.1324726343154907e-01
    phi[1,0]  R342      3.4268283843994141e-01
    phi[1,0]  R343      1.7832143306732178e+00
    phi[1,0]  R344      7.5625765323638916e-01
    phi[1,0]  R345      1.1160174608230591e+00
    phi[1,0]  R346      -2.1530742645263672e+00
    phi[1,0]  R347      -4.9819093942642212e-01
    phi[1,0]  R348      -6.5312761068344116e-01
    phi[1,0]  R349      1.14546799659729
    phi[1,0]  R350      5.3793883323669434e-01
    phi[1,0]  R351      -1.2572054862976074e+00
    phi[1,0]  R352      -1.5476222038269043e+00
    phi[1,0]  R353      9.8605215549468994e-01
    phi[1,0]  R354      1.0055705904960632e-02
    phi[1,0]  R355      1.0746426582336426e+00
    phi[1,0]  R356      -5.4876990616321564e-02
    phi[1,0]  R357      3.0719954520463943e-03
    phi[1,0]  R358      2.7624544501304626e-01
    phi[1,0]  R359      2.4640098214149475e-01
    phi[0,7]  R0        1
    phi[0,7]  R1        1
    phi[0,7]  R63       -1
    phi[0,7]  R360      -3.0999999046325684e+00
    phi[0,7]  R361      -3.0999999046325684e+00
    phi[0,7]  R362      -2.2400000095367432e+00
    phi[0,7]  R363      -2.2400000095367432e+00
    phi[0,7]  R364      -3.0999999046325684e+00
    phi[0,7]  R365      -3.0999999046325684e+00
    phi[0,7]  R366      -2.5699999332427979e+00
    phi[0,7]  R367      -2.5699999332427979e+00
    phi[0,7]  R368      -3.0999999046325684e+00
    phi[0,7]  R369      -3.0999999046325684e+00
    phi[0,7]  R370      -2.0899999141693115e+00
    phi[0,7]  R371      -2.0899999141693115e+00
    phi[0,7]  R372      -3.0999999046325684e+00
    phi[0,7]  R373      -3.0999999046325684e+00
    phi[0,7]  R374      2.1111133098602295e+00
    phi[0,7]  R375      1.2405002117156982e+00
    phi[0,7]  R376      9.9406063556671143e-01
    phi[0,7]  R377      1.6866980791091919e+00
    phi[0,7]  R378      1.9280288219451904e+00
    phi[0,7]  R379      1.3586753606796265e+00
    phi[0,7]  R380      4.8280379176139832e-01
    phi[0,7]  R381      9.1404080390930176e-02
    phi[0,7]  R382      1.1769498586654663e+00
    phi[0,7]  R383      1.7412993907928467e+00
    phi[0,7]  R384      3.3208038657903671e-02
    phi[0,7]  R385      3.9561790227890015e-01
    phi[0,7]  R386      -1.3896132707595825e+00
    phi[0,7]  R387      -1.5441114902496338e+00
    phi[0,7]  R388      6.7641323804855347e-01
    phi[0,7]  R389      1.0858708620071411e+00
    phi[0,7]  R390      1.4311429262161255e+00
    phi[0,7]  R391      1.5027213096618652e+00
    phi[0,7]  R392      5.1756536960601807e-01
    phi[0,7]  R393      -1.7241834402084351e+00
    phi[0,7]  R394      -1.6303300857543945e+00
    phi[0,7]  R395      -1.4130406379699707e+00
    phi[0,7]  R396      -1.8679690361022949e+00
    phi[0,7]  R397      -1.7106771469116211e+00
    phi[0,7]  R398      -4.4275146722793579e-01
    phi[0,7]  R399      -3.0449658632278442e-01
    phi[0,7]  R400      -1.6108542680740356e+00
    phi[0,7]  R401      2.0795999467372894e-01
    phi[0,7]  R402      -2.9758825898170471e-01
    phi[0,7]  R403      -9.8760712146759033e-01
    phi[0,7]  R404      -9.3340158462524414e-01
    phi[0,7]  R405      -1.39418625831604
    phi[0,7]  R406      -8.4509927034378052e-01
    phi[0,7]  R407      -7.9650598764419556e-01
    phi[0,7]  R408      -9.5198571681976318e-01
    phi[0,7]  R409      7.8030876815319061e-02
    phi[0,7]  R410      -1.9262020587921143e+00
    phi[0,7]  R411      2.4219554662704468e-01
    phi[0,7]  R412      4.4177421927452087e-01
    phi[0,7]  R413      -4.5119118690490723e-01
    phi[0,7]  R414      -2.0381007194519043e+00
    phi[0,7]  R415      3.1324726343154907e-01
    phi[0,7]  R416      3.4268283843994141e-01
    phi[0,7]  R417      1.7832143306732178e+00
    phi[0,7]  R418      7.5625765323638916e-01
    phi[0,7]  R419      1.1160174608230591e+00
    phi[0,7]  R420      -2.1530742645263672e+00
    phi[0,7]  R421      -4.9819093942642212e-01
    phi[0,7]  R422      -6.5312761068344116e-01
    phi[0,7]  R423      1.14546799659729
    phi[0,7]  R424      5.3793883323669434e-01
    phi[0,7]  R425      -1.2572054862976074e+00
    phi[0,7]  R426      -1.5476222038269043e+00
    phi[0,7]  R427      9.8605215549468994e-01
    phi[0,7]  R428      1.0055705904960632e-02
    phi[0,7]  R429      1.0746426582336426e+00
    phi[0,7]  R430      -5.4876990616321564e-02
    phi[0,7]  R431      3.0719954520463943e-03
    phi[0,7]  R432      2.7624544501304626e-01
    phi[0,7]  R433      2.4640098214149475e-01
    phi[0,7]  R434      1.7703909873962402e+00
    phi[0,7]  R435      1.4271932840347290e+00
    phi[0,7]  R436      2.03298282623291
    phi[0,7]  R437      9.2722147703170776e-01
    phi[0,7]  R438      1.0555876493453979e+00
    phi[0,7]  R439      9.4596719741821289e-01
    phi[0,7]  R440      -9.8126053810119629e-02
    phi[0,7]  R441      8.9248466491699219e-01
    phi[0,7]  R442      -2.1293966472148895e-01
    phi[0,7]  R443      2.2604021430015564e-01
    phi[0,7]  R444      -1.3818459510803223e+00
    phi[0,7]  R445      -1.0415548086166382e+00
    phi[0,7]  R446      -1.9686316251754761e+00
    phi[0,7]  R447      -5.9821850061416626e-01
    phi[0,7]  R448      -4.3241882324218750e-01
    phi[0,7]  R449      -5.7898980379104614e-01
    phi[0,7]  R450      -2.6958050727844238e+00
    phi[0,7]  R451      -1.5797593593597412e+00
    phi[0,7]  R452      -1.9584161043167114e+00
    phi[0,7]  R453      -1.8934646844863892e+00
    phi[0,7]  R454      -2.5175108909606934e+00
    phi[0,7]  R455      -1.9551842212677002e+00
    phi[0,7]  R456      -8.4858405590057373e-01
    phi[0,7]  R457      -1.6719341278076172e+00
    phi[0,7]  R458      -2.4382147789001465e+00
    phi[0,7]  R459      -1.1550946235656738e+00
    phi[0,7]  R460      -1.1460968255996704e+00
    phi[0,7]  R461      -1.6403200626373291e+00
    phi[0,7]  R462      -1.3433316946029663e+00
    phi[0,7]  R463      -0.688581645488739
    phi[0,7]  R464      -1.5594618320465088e+00
    phi[0,7]  R465      -1.6825697422027588e+00
    phi[0,7]  R466      1.2310864403843880e-03
    phi[0,7]  R467      -8.7218195199966431e-01
    phi[0,7]  R468      -1.1113963127136230e+00
    phi[0,7]  R469      -2.6635712385177612e-01
    phi[0,7]  R470      1.7014296352863312e-01
    phi[0,7]  R471      -1.1135574579238892e+00
    phi[0,7]  R472      -2.06619930267334
    phi[0,7]  R473      1.8527619540691376e-01
    phi[7,0]  R0        -1
    phi[7,0]  R63       1
    phi[7,0]  R64       1
    phi[7,0]  R474      -3.0999999046325684e+00
    phi[7,0]  R475      -3.0999999046325684e+00
    phi[7,0]  R476      -2.2400000095367432e+00
    phi[7,0]  R477      -2.2400000095367432e+00
    phi[7,0]  R478      -3.0999999046325684e+00
    phi[7,0]  R479      -3.0999999046325684e+00
    phi[7,0]  R480      -2.5699999332427979e+00
    phi[7,0]  R481      -2.5699999332427979e+00
    phi[7,0]  R482      -3.0999999046325684e+00
    phi[7,0]  R483      -3.0999999046325684e+00
    phi[7,0]  R484      -2.0899999141693115e+00
    phi[7,0]  R485      -2.0899999141693115e+00
    phi[7,0]  R486      -3.0999999046325684e+00
    phi[7,0]  R487      -3.0999999046325684e+00
    phi[7,0]  R488      1.7703909873962402e+00
    phi[7,0]  R489      1.4271932840347290e+00
    phi[7,0]  R490      2.03298282623291
    phi[7,0]  R491      9.2722147703170776e-01
    phi[7,0]  R492      1.0555876493453979e+00
    phi[7,0]  R493      9.4596719741821289e-01
    phi[7,0]  R494      -9.8126053810119629e-02
    phi[7,0]  R495      8.9248466491699219e-01
    phi[7,0]  R496      -2.1293966472148895e-01
    phi[7,0]  R497      2.2604021430015564e-01
    phi[7,0]  R498      -1.3818459510803223e+00
    phi[7,0]  R499      -1.0415548086166382e+00
    phi[7,0]  R500      -1.9686316251754761e+00
    phi[7,0]  R501      -5.9821850061416626e-01
    phi[7,0]  R502      -4.3241882324218750e-01
    phi[7,0]  R503      -5.7898980379104614e-01
    phi[7,0]  R504      -2.6958050727844238e+00
    phi[7,0]  R505      -1.5797593593597412e+00
    phi[7,0]  R506      -1.9584161043167114e+00
    phi[7,0]  R507      -1.8934646844863892e+00
    phi[7,0]  R508      -2.5175108909606934e+00
    phi[7,0]  R509      -1.9551842212677002e+00
    phi[7,0]  R510      -8.4858405590057373e-01
    phi[7,0]  R511      -1.6719341278076172e+00
    phi[7,0]  R512      -2.4382147789001465e+00
    phi[7,0]  R513      -1.1550946235656738e+00
    phi[7,0]  R514      -1.1460968255996704e+00
    phi[7,0]  R515      -1.6403200626373291e+00
    phi[7,0]  R516      -1.3433316946029663e+00
    phi[7,0]  R517      -0.688581645488739
    phi[7,0]  R518      -1.5594618320465088e+00
    phi[7,0]  R519      -1.6825697422027588e+00
    phi[7,0]  R520      1.2310864403843880e-03
    phi[7,0]  R521      -8.7218195199966431e-01
    phi[7,0]  R522      -1.1113963127136230e+00
    phi[7,0]  R523      -2.6635712385177612e-01
    phi[7,0]  R524      1.7014296352863312e-01
    phi[7,0]  R525      -1.1135574579238892e+00
    phi[7,0]  R526      -2.06619930267334
    phi[7,0]  R527      1.8527619540691376e-01
    phi[7,0]  R528      2.1111133098602295e+00
    phi[7,0]  R529      1.2405002117156982e+00
    phi[7,0]  R530      9.9406063556671143e-01
    phi[7,0]  R531      1.6866980791091919e+00
    phi[7,0]  R532      1.9280288219451904e+00
    phi[7,0]  R533      1.3586753606796265e+00
    phi[7,0]  R534      4.8280379176139832e-01
    phi[7,0]  R535      9.1404080390930176e-02
    phi[7,0]  R536      1.1769498586654663e+00
    phi[7,0]  R537      1.7412993907928467e+00
    phi[7,0]  R538      3.3208038657903671e-02
    phi[7,0]  R539      3.9561790227890015e-01
    phi[7,0]  R540      -1.3896132707595825e+00
    phi[7,0]  R541      -1.5441114902496338e+00
    phi[7,0]  R542      6.7641323804855347e-01
    phi[7,0]  R543      1.0858708620071411e+00
    phi[7,0]  R544      1.4311429262161255e+00
    phi[7,0]  R545      1.5027213096618652e+00
    phi[7,0]  R546      5.1756536960601807e-01
    phi[7,0]  R547      -1.7241834402084351e+00
    phi[7,0]  R548      -1.6303300857543945e+00
    phi[7,0]  R549      -1.4130406379699707e+00
    phi[7,0]  R550      -1.8679690361022949e+00
    phi[7,0]  R551      -1.7106771469116211e+00
    phi[7,0]  R552      -4.4275146722793579e-01
    phi[7,0]  R553      -3.0449658632278442e-01
    phi[7,0]  R554      -1.6108542680740356e+00
    phi[7,0]  R555      2.0795999467372894e-01
    phi[7,0]  R556      -2.9758825898170471e-01
    phi[7,0]  R557      -9.8760712146759033e-01
    phi[7,0]  R558      -9.3340158462524414e-01
    phi[7,0]  R559      -1.39418625831604
    phi[7,0]  R560      -8.4509927034378052e-01
    phi[7,0]  R561      -7.9650598764419556e-01
    phi[7,0]  R562      -9.5198571681976318e-01
    phi[7,0]  R563      7.8030876815319061e-02
    phi[7,0]  R564      -1.9262020587921143e+00
    phi[7,0]  R565      2.4219554662704468e-01
    phi[7,0]  R566      4.4177421927452087e-01
    phi[7,0]  R567      -4.5119118690490723e-01
    phi[7,0]  R568      -2.0381007194519043e+00
    phi[7,0]  R569      3.1324726343154907e-01
    phi[7,0]  R570      3.4268283843994141e-01
    phi[7,0]  R571      1.7832143306732178e+00
    phi[7,0]  R572      7.5625765323638916e-01
    phi[7,0]  R573      1.1160174608230591e+00
    phi[7,0]  R574      -2.1530742645263672e+00
    phi[7,0]  R575      -4.9819093942642212e-01
    phi[7,0]  R576      -6.5312761068344116e-01
    phi[7,0]  R577      1.14546799659729
    phi[7,0]  R578      5.3793883323669434e-01
    phi[7,0]  R579      -1.2572054862976074e+00
    phi[7,0]  R580      -1.5476222038269043e+00
    phi[7,0]  R581      9.8605215549468994e-01
    phi[7,0]  R582      1.0055705904960632e-02
    phi[7,0]  R583      1.0746426582336426e+00
    phi[7,0]  R584      -5.4876990616321564e-02
    phi[7,0]  R585      3.0719954520463943e-03
    phi[7,0]  R586      2.7624544501304626e-01
    phi[7,0]  R587      2.4640098214149475e-01
    phi[10,0]  R0        -1
    phi[10,0]  R2        -2.1827746042916267e+00
    phi[10,0]  R3        1.1644562075550637e+00
    phi[10,0]  R4        1.2167052281950808e-01
    phi[10,0]  R5        -2.0887870120209850e+00
    phi[10,0]  R6        -1.8742076134270436e+00
    phi[10,0]  R7        -1.7449256160373570e+00
    phi[10,0]  R8        1.6733168354416477e+00
    phi[10,0]  R90       1
    phi[10,0]  R588      -9.1722530034094163e-01
    phi[10,0]  R589      -5.2827745089241951e+00
    phi[10,0]  R590      -3.4044562170918069e+00
    phi[10,0]  R591      -1.0755438019816794e+00
    phi[10,0]  R592      -3.2216704274520764e+00
    phi[10,0]  R593      -2.9783293818130603e+00
    phi[10,0]  R594      -4.8121292122181281e-01
    phi[10,0]  R595      -4.6587869452637829e+00
    phi[10,0]  R596      -1.2257922912055248e+00
    phi[10,0]  R597      -4.9742075180596119e+00
    phi[10,0]  R598      -3.4507429813195456e-01
    phi[10,0]  R599      -3.8349255302066685e+00
    phi[10,0]  R600      -4.7733167400742165e+00
    phi[10,0]  R601      -1.4266830691909207e+00
    phi[10,0]  R602      -8.6193752857882755e-01
    phi[10,0]  R603      -5.1389091598186853e-01
    phi[10,0]  R604      -8.7888337662830351e-01
    phi[10,0]  R605      -2.8292639566173050e-01
    phi[10,0]  R606      -1.2819344610445915e-01
    phi[10,0]  R607      -1.8030363506804781e-01
    phi[10,0]  R608      -2.5782362256263447e-01
    phi[10,0]  R609      -4.6835197241517290e-01
    phi[10,0]  R610      -8.3579424794236212e-01
    phi[10,0]  R611      -3.8381319850817297e-01
    phi[10,0]  R612      -1.3826959564018182e-01
    phi[10,0]  R613      -1.4771019902052185e-01
    phi[10,0]  R614      -1.5071782129992783e-01
    phi[10,0]  R615      -1.5359565554714960e-01
    phi[10,0]  R616      -1.5768750354851613e-01
    phi[10,0]  R617      -1.7671670121774552e-01
    phi[10,0]  R618      -1.9259660407424950e-01
    phi[10,0]  R619      -1.9259918488671168e-01
    phi[10,0]  R620      -2.0022593220943863e-01
    phi[10,0]  R621      -2.3984098183872060e-01
    phi[10,0]  R622      -3.6794904392096472e-01
    phi[10,0]  R623      -2.1465498606180722e-01
    phi[10,0]  R624      -2.1602202526795433e-01
    phi[10,0]  R625      -4.3964354122250549e-01
    phi[10,0]  R626      -2.2319157780163507e-01
    phi[10,0]  R627      -2.2618809879543539e-01
    phi[10,0]  R628      -2.3715643039360512e-01
    phi[10,0]  R629      -2.3906602421849410e-01
    phi[10,0]  R630      -2.4356699261618203e-01
    phi[10,0]  R631      -2.4847346978476681e-01
    phi[10,0]  R632      -1.3016046036895890e-01
    phi[10,0]  R633      -1.3735274359352290e-01
    phi[10,0]  R634      -1.4370399652215926e-01
    phi[10,0]  R635      -1.5535672738674844e-01
    phi[10,0]  R636      -1.5783455611228459e-01
    phi[10,0]  R637      -1.6137185970134288e-01
    phi[10,0]  R638      -1.6374450411200892e-01
    phi[10,0]  R639      -1.6792473358478033e-01
    phi[10,0]  R640      -1.7063468930483627e-01
    phi[10,0]  R641      -1.7110941002433894e-01
    phi[10,0]  R642      -1.8688157317150811e-01
    phi[10,0]  R643      -1.5149463199425556e-01
    phi[10,0]  R644      -1.6606965663253026e-01
    phi[10,0]  R645      -2.0925802652684289e-01
    phi[10,0]  R646      -2.2071605057055321e-01
    phi[10,0]  R647      -2.3580009841558369e-01
    phi[10,0]  R648      -2.3670597448391417e-01
    phi[10,0]  R649      -2.4097603767128428e-01
    phi[10,0]  R650      -2.4853365831239538e-01
    phi[10,0]  R651      -2.5788410536779471e-01
    phi[10,0]  R652      -1.7380579354738945e-01
    phi[10,0]  R653      -5.2615031488108843e-01
    phi[10,0]  R654      -1.6989548249335229e-01
    phi[10,0]  R655      -1.7578352568697730e-01
    phi[10,0]  R656      -1.9130548952282189e-01
    phi[10,0]  R657      -2.1197639234914867e-01
    phi[10,0]  R658      -2.2697311567866574e-01
    phi[10,0]  R659      -2.4451026432979087e-01
    phi[10,0]  R660      -2.5019628194571786e-01
    phi[10,0]  R661      -2.5138533508384020e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R662      -3.0999999046325684e+00
    phi[1,2]  R663      -3.0999999046325684e+00
    phi[1,2]  R664      -2.2400000095367432e+00
    phi[1,2]  R665      -2.2400000095367432e+00
    phi[1,2]  R666      -3.0999999046325684e+00
    phi[1,2]  R667      -3.0999999046325684e+00
    phi[1,2]  R668      -2.5699999332427979e+00
    phi[1,2]  R669      -2.5699999332427979e+00
    phi[1,2]  R670      -3.0999999046325684e+00
    phi[1,2]  R671      -3.0999999046325684e+00
    phi[1,2]  R672      -2.0899999141693115e+00
    phi[1,2]  R673      -2.0899999141693115e+00
    phi[1,2]  R674      -3.0999999046325684e+00
    phi[1,2]  R675      -3.0999999046325684e+00
    phi[1,2]  R676      1.7823770046234131e+00
    phi[1,2]  R677      1.8414847850799561e+00
    phi[1,2]  R678      1.6318974494934082e+00
    phi[1,2]  R679      1.3178656101226807e+00
    phi[1,2]  R680      1.0555876493453979e+00
    phi[1,2]  R681      8.0102640390396118e-01
    phi[1,2]  R682      5.6271618604660034e-01
    phi[1,2]  R683      1.7857429981231689e+00
    phi[1,2]  R684      1.3656859397888184e+00
    phi[1,2]  R685      1.5073101520538330e+00
    phi[1,2]  R686      -2.0515973567962646e+00
    phi[1,2]  R687      3.8029190897941589e-01
    phi[1,2]  R688      -4.0581017732620239e-01
    phi[1,2]  R689      -0.0988592877984047
    phi[1,2]  R690      -4.4718825817108154e-01
    phi[1,2]  R691      -1.0819220542907715e+00
    phi[1,2]  R692      -2.6537837982177734e+00
    phi[1,2]  R693      1.1160815954208374e+00
    phi[1,2]  R694      -8.8257211446762085e-01
    phi[1,2]  R695      1.0012186765670776e+00
    phi[1,2]  R696      -2.1105275154113770e+00
    phi[1,2]  R697      -1.7885791063308716e+00
    phi[1,2]  R698      -1.8100674152374268e+00
    phi[1,2]  R699      -1.8939080238342285e+00
    phi[1,2]  R700      -1.4730018377304077e+00
    phi[1,2]  R701      -5.8110469579696655e-01
    phi[1,2]  R702      -1.1079891920089722e+00
    phi[1,2]  R703      2.5218960642814636e-01
    phi[1,2]  R704      -2.0196737349033356e-01
    phi[1,2]  R705      -1.2990446090698242e+00
    phi[1,2]  R706      -1.7714790105819702e+00
    phi[1,2]  R707      -2.6203885674476624e-01
    phi[1,2]  R708      -4.6201121807098389e-01
    phi[1,2]  R709      -1.1703782081604004e+00
    phi[1,2]  R710      4.1271677613258362e-01
    phi[1,2]  R711      -5.8660662174224854e-01
    phi[1,2]  R712      -1.3668122291564941e+00
    phi[1,2]  R713      -2.1489934921264648e+00
    phi[1,2]  R714      -1.8899157047271729e+00
    phi[1,2]  R715      -8.8776206970214844e-01
    phi[1,2]  R716      -9.5157051086425781e-01
    phi[1,2]  R717      5.4105478525161743e-01
    phi[1,2]  R718      -1.5727872848510742e+00
    phi[1,2]  R719      -2.3860310018062592e-01
    phi[1,2]  R720      -1.2798976898193359e+00
    phi[1,2]  R721      -1.2325476408004761e+00
    phi[1,2]  R722      -1.6513645648956299e+00
    phi[1,2]  R723      -1.9905910491943359e+00
    phi[1,2]  R724      -2.2684124112129211e-01
    phi[1,2]  R725      1.6258996725082397e+00
    phi[1,2]  R726      -1.9279876947402954e+00
    phi[1,2]  R727      5.4483568668365479e-01
    phi[1,2]  R728      -8.4611111879348755e-01
    phi[1,2]  R729      1.8662067651748657e+00
    phi[1,2]  R730      -1.9398202896118164e+00
    phi[1,2]  R731      -1.0792801529169083e-01
    phi[1,2]  R732      -9.9833548069000244e-01
    phi[1,2]  R733      -8.1440013647079468e-01
    phi[1,2]  R734      1.6196583509445190e+00
    phi[1,2]  R735      3.0551645159721375e-01
    phi[1,2]  R736      8.0786603689193726e-01
    phi[1,2]  R737      7.1641206741333008e-01
    phi[1,2]  R738      1.4393913745880127e+00
    phi[1,2]  R739      -3.5111829638481140e-01
    phi[1,2]  R740      -4.0952679514884949e-01
    phi[1,2]  R741      2.3377480506896973e+00
    phi[1,2]  R742      1.8587820529937744e+00
    phi[1,2]  R743      -1.9482092857360840e+00
    phi[1,2]  R744      3.0694682598114014e+00
    phi[1,2]  R745      5.9986180067062378e-01
    phi[1,2]  R746      1.2426754236221313e+00
    phi[1,2]  R747      -2.7419283390045166e+00
    phi[1,2]  R748      -2.2499439716339111e+00
    phi[1,2]  R749      -1.5730418264865875e-01
    phi[1,2]  R750      -2.1421055793762207e+00
    phi[1,2]  R751      -3.6601121425628662e+00
    phi[1,2]  R752      -2.5075614452362061e+00
    phi[1,2]  R753      -3.3420655727386475e+00
    phi[1,2]  R754      -1.7481670379638672e+00
    phi[1,2]  R755      -1.0879999399185181e+00
    phi[1,2]  R756      -8.6936020851135254e-01
    phi[1,2]  R757      -2.5862040519714355e+00
    phi[1,2]  R758      2.7027806267142296e-02
    phi[1,2]  R759      -1.2045701742172241e+00
    phi[1,2]  R760      -2.6990315914154053e+00
    phi[1,2]  R761      0.521091103553772
    phi[1,2]  R762      -2.3710992336273193e+00
    phi[1,2]  R763      -1.4575570821762085e+00
    phi[1,2]  R764      -1.5494993925094604e+00
    phi[1,2]  R765      -2.87011456489563
    phi[1,2]  R766      -1.8798170089721680e+00
    phi[1,2]  R767      -2.2968268394470215e+00
    phi[1,2]  R768      2.0874054431915283e+00
    phi[1,2]  R769      1.3691589832305908e+00
    phi[1,2]  R770      2.3171701431274414e+00
    phi[1,2]  R771      2.8823087215423584e+00
    phi[1,2]  R772      2.8800537586212158e+00
    phi[1,2]  R773      2.3107764720916748e+00
    phi[1,2]  R774      6.4636695384979248e-01
    phi[1,2]  R775      -8.7963038682937622e-01
    phi[1,2]  R776      -1.7880413532257080e+00
    phi[1,2]  R777      -3.2817232608795166e+00
    phi[1,2]  R778      -1.0900740623474121e+00
    phi[1,2]  R779      0.654232919216156
    phi[1,2]  R780      6.2169218063354492e-01
    phi[1,2]  R781      1.9989033937454224e+00
    phi[1,2]  R782      2.9746482372283936e+00
    phi[1,2]  R783      1.6789057254791260e+00
    phi[1,2]  R784      3.1226108074188232e+00
    phi[1,2]  R785      -5.3400844335556030e-01
    phi[1,2]  R786      -1.3224254548549652e-01
    phi[1,2]  R787      -8.8649958372116089e-01
    phi[1,2]  R788      -4.7719323635101318e-01
    phi[1,2]  R789      2.4326823651790619e-01
    phi[1,2]  R790      1.1355647444725037e-01
    phi[1,2]  R791      1.0799465179443359e+00
    phi[1,2]  R792      -1.0341274738311768e+00
    phi[1,2]  R793      -0.891402542591095
    phi[1,2]  R794      -3.7492564320564270e-01
    phi[1,2]  R795      -1.7356138229370117e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R796      -3.0999999046325684e+00
    phi[2,1]  R797      -3.0999999046325684e+00
    phi[2,1]  R798      -2.2400000095367432e+00
    phi[2,1]  R799      -2.2400000095367432e+00
    phi[2,1]  R800      -3.0999999046325684e+00
    phi[2,1]  R801      -3.0999999046325684e+00
    phi[2,1]  R802      -2.5699999332427979e+00
    phi[2,1]  R803      -2.5699999332427979e+00
    phi[2,1]  R804      -3.0999999046325684e+00
    phi[2,1]  R805      -3.0999999046325684e+00
    phi[2,1]  R806      -2.0899999141693115e+00
    phi[2,1]  R807      -2.0899999141693115e+00
    phi[2,1]  R808      -3.0999999046325684e+00
    phi[2,1]  R809      -3.0999999046325684e+00
    phi[2,1]  R810      8.0786603689193726e-01
    phi[2,1]  R811      7.1641206741333008e-01
    phi[2,1]  R812      1.4393913745880127e+00
    phi[2,1]  R813      -3.5111829638481140e-01
    phi[2,1]  R814      -4.0952679514884949e-01
    phi[2,1]  R815      2.3377480506896973e+00
    phi[2,1]  R816      1.8587820529937744e+00
    phi[2,1]  R817      -1.9482092857360840e+00
    phi[2,1]  R818      3.0694682598114014e+00
    phi[2,1]  R819      5.9986180067062378e-01
    phi[2,1]  R820      1.2426754236221313e+00
    phi[2,1]  R821      -2.7419283390045166e+00
    phi[2,1]  R822      -2.2499439716339111e+00
    phi[2,1]  R823      -1.5730418264865875e-01
    phi[2,1]  R824      -2.1421055793762207e+00
    phi[2,1]  R825      -3.6601121425628662e+00
    phi[2,1]  R826      -2.5075614452362061e+00
    phi[2,1]  R827      -3.3420655727386475e+00
    phi[2,1]  R828      -1.7481670379638672e+00
    phi[2,1]  R829      -1.0879999399185181e+00
    phi[2,1]  R830      -8.6936020851135254e-01
    phi[2,1]  R831      -2.5862040519714355e+00
    phi[2,1]  R832      2.7027806267142296e-02
    phi[2,1]  R833      -1.2045701742172241e+00
    phi[2,1]  R834      -2.6990315914154053e+00
    phi[2,1]  R835      0.521091103553772
    phi[2,1]  R836      -2.3710992336273193e+00
    phi[2,1]  R837      -1.4575570821762085e+00
    phi[2,1]  R838      -1.5494993925094604e+00
    phi[2,1]  R839      -2.87011456489563
    phi[2,1]  R840      -1.8798170089721680e+00
    phi[2,1]  R841      -2.2968268394470215e+00
    phi[2,1]  R842      2.0874054431915283e+00
    phi[2,1]  R843      1.3691589832305908e+00
    phi[2,1]  R844      2.3171701431274414e+00
    phi[2,1]  R845      2.8823087215423584e+00
    phi[2,1]  R846      2.8800537586212158e+00
    phi[2,1]  R847      2.3107764720916748e+00
    phi[2,1]  R848      6.4636695384979248e-01
    phi[2,1]  R849      -8.7963038682937622e-01
    phi[2,1]  R850      -1.7880413532257080e+00
    phi[2,1]  R851      -3.2817232608795166e+00
    phi[2,1]  R852      -1.0900740623474121e+00
    phi[2,1]  R853      0.654232919216156
    phi[2,1]  R854      6.2169218063354492e-01
    phi[2,1]  R855      1.9989033937454224e+00
    phi[2,1]  R856      2.9746482372283936e+00
    phi[2,1]  R857      1.6789057254791260e+00
    phi[2,1]  R858      3.1226108074188232e+00
    phi[2,1]  R859      -5.3400844335556030e-01
    phi[2,1]  R860      -1.3224254548549652e-01
    phi[2,1]  R861      -8.8649958372116089e-01
    phi[2,1]  R862      -4.7719323635101318e-01
    phi[2,1]  R863      2.4326823651790619e-01
    phi[2,1]  R864      1.1355647444725037e-01
    phi[2,1]  R865      1.0799465179443359e+00
    phi[2,1]  R866      -1.0341274738311768e+00
    phi[2,1]  R867      -0.891402542591095
    phi[2,1]  R868      -3.7492564320564270e-01
    phi[2,1]  R869      -1.7356138229370117e+00
    phi[2,1]  R870      1.7823770046234131e+00
    phi[2,1]  R871      1.8414847850799561e+00
    phi[2,1]  R872      1.6318974494934082e+00
    phi[2,1]  R873      1.3178656101226807e+00
    phi[2,1]  R874      1.0555876493453979e+00
    phi[2,1]  R875      8.0102640390396118e-01
    phi[2,1]  R876      5.6271618604660034e-01
    phi[2,1]  R877      1.7857429981231689e+00
    phi[2,1]  R878      1.3656859397888184e+00
    phi[2,1]  R879      1.5073101520538330e+00
    phi[2,1]  R880      -2.0515973567962646e+00
    phi[2,1]  R881      3.8029190897941589e-01
    phi[2,1]  R882      -4.0581017732620239e-01
    phi[2,1]  R883      -0.0988592877984047
    phi[2,1]  R884      -4.4718825817108154e-01
    phi[2,1]  R885      -1.0819220542907715e+00
    phi[2,1]  R886      -2.6537837982177734e+00
    phi[2,1]  R887      1.1160815954208374e+00
    phi[2,1]  R888      -8.8257211446762085e-01
    phi[2,1]  R889      1.0012186765670776e+00
    phi[2,1]  R890      -2.1105275154113770e+00
    phi[2,1]  R891      -1.7885791063308716e+00
    phi[2,1]  R892      -1.8100674152374268e+00
    phi[2,1]  R893      -1.8939080238342285e+00
    phi[2,1]  R894      -1.4730018377304077e+00
    phi[2,1]  R895      -5.8110469579696655e-01
    phi[2,1]  R896      -1.1079891920089722e+00
    phi[2,1]  R897      2.5218960642814636e-01
    phi[2,1]  R898      -2.0196737349033356e-01
    phi[2,1]  R899      -1.2990446090698242e+00
    phi[2,1]  R900      -1.7714790105819702e+00
    phi[2,1]  R901      -2.6203885674476624e-01
    phi[2,1]  R902      -4.6201121807098389e-01
    phi[2,1]  R903      -1.1703782081604004e+00
    phi[2,1]  R904      4.1271677613258362e-01
    phi[2,1]  R905      -5.8660662174224854e-01
    phi[2,1]  R906      -1.3668122291564941e+00
    phi[2,1]  R907      -2.1489934921264648e+00
    phi[2,1]  R908      -1.8899157047271729e+00
    phi[2,1]  R909      -8.8776206970214844e-01
    phi[2,1]  R910      -9.5157051086425781e-01
    phi[2,1]  R911      5.4105478525161743e-01
    phi[2,1]  R912      -1.5727872848510742e+00
    phi[2,1]  R913      -2.3860310018062592e-01
    phi[2,1]  R914      -1.2798976898193359e+00
    phi[2,1]  R915      -1.2325476408004761e+00
    phi[2,1]  R916      -1.6513645648956299e+00
    phi[2,1]  R917      -1.9905910491943359e+00
    phi[2,1]  R918      -2.2684124112129211e-01
    phi[2,1]  R919      1.6258996725082397e+00
    phi[2,1]  R920      -1.9279876947402954e+00
    phi[2,1]  R921      5.4483568668365479e-01
    phi[2,1]  R922      -8.4611111879348755e-01
    phi[2,1]  R923      1.8662067651748657e+00
    phi[2,1]  R924      -1.9398202896118164e+00
    phi[2,1]  R925      -1.0792801529169083e-01
    phi[2,1]  R926      -9.9833548069000244e-01
    phi[2,1]  R927      -8.1440013647079468e-01
    phi[2,1]  R928      1.6196583509445190e+00
    phi[2,1]  R929      3.0551645159721375e-01
    phi[1,7]  R9        1
    phi[1,7]  R10       1
    phi[1,7]  R63       -1
    phi[1,7]  R930      -3.0999999046325684e+00
    phi[1,7]  R931      -3.0999999046325684e+00
    phi[1,7]  R932      -2.2400000095367432e+00
    phi[1,7]  R933      -2.2400000095367432e+00
    phi[1,7]  R934      -3.0999999046325684e+00
    phi[1,7]  R935      -3.0999999046325684e+00
    phi[1,7]  R936      -2.5699999332427979e+00
    phi[1,7]  R937      -2.5699999332427979e+00
    phi[1,7]  R938      -3.0999999046325684e+00
    phi[1,7]  R939      -3.0999999046325684e+00
    phi[1,7]  R940      -2.0899999141693115e+00
    phi[1,7]  R941      -2.0899999141693115e+00
    phi[1,7]  R942      -3.0999999046325684e+00
    phi[1,7]  R943      -3.0999999046325684e+00
    phi[1,7]  R944      1.7823770046234131e+00
    phi[1,7]  R945      1.8414847850799561e+00
    phi[1,7]  R946      1.6318974494934082e+00
    phi[1,7]  R947      1.3178656101226807e+00
    phi[1,7]  R948      1.0555876493453979e+00
    phi[1,7]  R949      8.0102640390396118e-01
    phi[1,7]  R950      5.6271618604660034e-01
    phi[1,7]  R951      1.7857429981231689e+00
    phi[1,7]  R952      1.3656859397888184e+00
    phi[1,7]  R953      1.5073101520538330e+00
    phi[1,7]  R954      -2.0515973567962646e+00
    phi[1,7]  R955      3.8029190897941589e-01
    phi[1,7]  R956      -4.0581017732620239e-01
    phi[1,7]  R957      -0.0988592877984047
    phi[1,7]  R958      -4.4718825817108154e-01
    phi[1,7]  R959      -1.0819220542907715e+00
    phi[1,7]  R960      -2.6537837982177734e+00
    phi[1,7]  R961      1.1160815954208374e+00
    phi[1,7]  R962      -8.8257211446762085e-01
    phi[1,7]  R963      1.0012186765670776e+00
    phi[1,7]  R964      -2.1105275154113770e+00
    phi[1,7]  R965      -1.7885791063308716e+00
    phi[1,7]  R966      -1.8100674152374268e+00
    phi[1,7]  R967      -1.8939080238342285e+00
    phi[1,7]  R968      -1.4730018377304077e+00
    phi[1,7]  R969      -5.8110469579696655e-01
    phi[1,7]  R970      -1.1079891920089722e+00
    phi[1,7]  R971      2.5218960642814636e-01
    phi[1,7]  R972      -2.0196737349033356e-01
    phi[1,7]  R973      -1.2990446090698242e+00
    phi[1,7]  R974      -1.7714790105819702e+00
    phi[1,7]  R975      -2.6203885674476624e-01
    phi[1,7]  R976      -4.6201121807098389e-01
    phi[1,7]  R977      -1.1703782081604004e+00
    phi[1,7]  R978      4.1271677613258362e-01
    phi[1,7]  R979      -5.8660662174224854e-01
    phi[1,7]  R980      -1.3668122291564941e+00
    phi[1,7]  R981      -2.1489934921264648e+00
    phi[1,7]  R982      -1.8899157047271729e+00
    phi[1,7]  R983      -8.8776206970214844e-01
    phi[1,7]  R984      -9.5157051086425781e-01
    phi[1,7]  R985      5.4105478525161743e-01
    phi[1,7]  R986      -1.5727872848510742e+00
    phi[1,7]  R987      -2.3860310018062592e-01
    phi[1,7]  R988      -1.2798976898193359e+00
    phi[1,7]  R989      -1.2325476408004761e+00
    phi[1,7]  R990      -1.6513645648956299e+00
    phi[1,7]  R991      -1.9905910491943359e+00
    phi[1,7]  R992      -2.2684124112129211e-01
    phi[1,7]  R993      1.6258996725082397e+00
    phi[1,7]  R994      -1.9279876947402954e+00
    phi[1,7]  R995      5.4483568668365479e-01
    phi[1,7]  R996      -8.4611111879348755e-01
    phi[1,7]  R997      1.8662067651748657e+00
    phi[1,7]  R998      -1.9398202896118164e+00
    phi[1,7]  R999      -1.0792801529169083e-01
    phi[1,7]  R1000     -9.9833548069000244e-01
    phi[1,7]  R1001     -8.1440013647079468e-01
    phi[1,7]  R1002     1.6196583509445190e+00
    phi[1,7]  R1003     3.0551645159721375e-01
    phi[1,7]  R1004     1.7703909873962402e+00
    phi[1,7]  R1005     1.4271932840347290e+00
    phi[1,7]  R1006     2.03298282623291
    phi[1,7]  R1007     9.2722147703170776e-01
    phi[1,7]  R1008     9.4596719741821289e-01
    phi[1,7]  R1009     -9.8126053810119629e-02
    phi[1,7]  R1010     8.9248466491699219e-01
    phi[1,7]  R1011     -2.1293966472148895e-01
    phi[1,7]  R1012     2.2604021430015564e-01
    phi[1,7]  R1013     -1.3818459510803223e+00
    phi[1,7]  R1014     -1.0415548086166382e+00
    phi[1,7]  R1015     -1.9686316251754761e+00
    phi[1,7]  R1016     -5.9821850061416626e-01
    phi[1,7]  R1017     -4.3241882324218750e-01
    phi[1,7]  R1018     -5.7898980379104614e-01
    phi[1,7]  R1019     -2.6958050727844238e+00
    phi[1,7]  R1020     -1.5797593593597412e+00
    phi[1,7]  R1021     -1.9584161043167114e+00
    phi[1,7]  R1022     -1.8934646844863892e+00
    phi[1,7]  R1023     -2.5175108909606934e+00
    phi[1,7]  R1024     -1.9551842212677002e+00
    phi[1,7]  R1025     -8.4858405590057373e-01
    phi[1,7]  R1026     -1.6719341278076172e+00
    phi[1,7]  R1027     -2.4382147789001465e+00
    phi[1,7]  R1028     -1.1550946235656738e+00
    phi[1,7]  R1029     -1.1460968255996704e+00
    phi[1,7]  R1030     -1.6403200626373291e+00
    phi[1,7]  R1031     -1.3433316946029663e+00
    phi[1,7]  R1032     -0.688581645488739
    phi[1,7]  R1033     -1.5594618320465088e+00
    phi[1,7]  R1034     -1.6825697422027588e+00
    phi[1,7]  R1035     1.2310864403843880e-03
    phi[1,7]  R1036     -8.7218195199966431e-01
    phi[1,7]  R1037     -1.1113963127136230e+00
    phi[1,7]  R1038     -2.6635712385177612e-01
    phi[1,7]  R1039     1.7014296352863312e-01
    phi[1,7]  R1040     -1.1135574579238892e+00
    phi[1,7]  R1041     -2.06619930267334
    phi[1,7]  R1042     1.8527619540691376e-01
    phi[7,1]  R9        -1
    phi[7,1]  R63       1
    phi[7,1]  R64       1
    phi[7,1]  R1043     -3.0999999046325684e+00
    phi[7,1]  R1044     -3.0999999046325684e+00
    phi[7,1]  R1045     -2.2400000095367432e+00
    phi[7,1]  R1046     -2.2400000095367432e+00
    phi[7,1]  R1047     -3.0999999046325684e+00
    phi[7,1]  R1048     -3.0999999046325684e+00
    phi[7,1]  R1049     -2.5699999332427979e+00
    phi[7,1]  R1050     -2.5699999332427979e+00
    phi[7,1]  R1051     -3.0999999046325684e+00
    phi[7,1]  R1052     -3.0999999046325684e+00
    phi[7,1]  R1053     -2.0899999141693115e+00
    phi[7,1]  R1054     -2.0899999141693115e+00
    phi[7,1]  R1055     -3.0999999046325684e+00
    phi[7,1]  R1056     -3.0999999046325684e+00
    phi[7,1]  R1057     1.7703909873962402e+00
    phi[7,1]  R1058     1.4271932840347290e+00
    phi[7,1]  R1059     2.03298282623291
    phi[7,1]  R1060     9.2722147703170776e-01
    phi[7,1]  R1061     1.0555876493453979e+00
    phi[7,1]  R1062     9.4596719741821289e-01
    phi[7,1]  R1063     -9.8126053810119629e-02
    phi[7,1]  R1064     8.9248466491699219e-01
    phi[7,1]  R1065     -2.1293966472148895e-01
    phi[7,1]  R1066     2.2604021430015564e-01
    phi[7,1]  R1067     -1.3818459510803223e+00
    phi[7,1]  R1068     -1.0415548086166382e+00
    phi[7,1]  R1069     -1.9686316251754761e+00
    phi[7,1]  R1070     -5.9821850061416626e-01
    phi[7,1]  R1071     -4.3241882324218750e-01
    phi[7,1]  R1072     -5.7898980379104614e-01
    phi[7,1]  R1073     -2.6958050727844238e+00
    phi[7,1]  R1074     -1.5797593593597412e+00
    phi[7,1]  R1075     -1.9584161043167114e+00
    phi[7,1]  R1076     -1.8934646844863892e+00
    phi[7,1]  R1077     -2.5175108909606934e+00
    phi[7,1]  R1078     -1.9551842212677002e+00
    phi[7,1]  R1079     -8.4858405590057373e-01
    phi[7,1]  R1080     -1.6719341278076172e+00
    phi[7,1]  R1081     -2.4382147789001465e+00
    phi[7,1]  R1082     -1.1550946235656738e+00
    phi[7,1]  R1083     -1.1460968255996704e+00
    phi[7,1]  R1084     -1.6403200626373291e+00
    phi[7,1]  R1085     -1.3433316946029663e+00
    phi[7,1]  R1086     -0.688581645488739
    phi[7,1]  R1087     -1.5594618320465088e+00
    phi[7,1]  R1088     -1.6825697422027588e+00
    phi[7,1]  R1089     1.2310864403843880e-03
    phi[7,1]  R1090     -8.7218195199966431e-01
    phi[7,1]  R1091     -1.1113963127136230e+00
    phi[7,1]  R1092     -2.6635712385177612e-01
    phi[7,1]  R1093     1.7014296352863312e-01
    phi[7,1]  R1094     -1.1135574579238892e+00
    phi[7,1]  R1095     -2.06619930267334
    phi[7,1]  R1096     1.8527619540691376e-01
    phi[7,1]  R1097     1.7823770046234131e+00
    phi[7,1]  R1098     1.8414847850799561e+00
    phi[7,1]  R1099     1.6318974494934082e+00
    phi[7,1]  R1100     1.3178656101226807e+00
    phi[7,1]  R1101     8.0102640390396118e-01
    phi[7,1]  R1102     5.6271618604660034e-01
    phi[7,1]  R1103     1.7857429981231689e+00
    phi[7,1]  R1104     1.3656859397888184e+00
    phi[7,1]  R1105     1.5073101520538330e+00
    phi[7,1]  R1106     -2.0515973567962646e+00
    phi[7,1]  R1107     3.8029190897941589e-01
    phi[7,1]  R1108     -4.0581017732620239e-01
    phi[7,1]  R1109     -0.0988592877984047
    phi[7,1]  R1110     -4.4718825817108154e-01
    phi[7,1]  R1111     -1.0819220542907715e+00
    phi[7,1]  R1112     -2.6537837982177734e+00
    phi[7,1]  R1113     1.1160815954208374e+00
    phi[7,1]  R1114     -8.8257211446762085e-01
    phi[7,1]  R1115     1.0012186765670776e+00
    phi[7,1]  R1116     -2.1105275154113770e+00
    phi[7,1]  R1117     -1.7885791063308716e+00
    phi[7,1]  R1118     -1.8100674152374268e+00
    phi[7,1]  R1119     -1.8939080238342285e+00
    phi[7,1]  R1120     -1.4730018377304077e+00
    phi[7,1]  R1121     -5.8110469579696655e-01
    phi[7,1]  R1122     -1.1079891920089722e+00
    phi[7,1]  R1123     2.5218960642814636e-01
    phi[7,1]  R1124     -2.0196737349033356e-01
    phi[7,1]  R1125     -1.2990446090698242e+00
    phi[7,1]  R1126     -1.7714790105819702e+00
    phi[7,1]  R1127     -2.6203885674476624e-01
    phi[7,1]  R1128     -4.6201121807098389e-01
    phi[7,1]  R1129     -1.1703782081604004e+00
    phi[7,1]  R1130     4.1271677613258362e-01
    phi[7,1]  R1131     -5.8660662174224854e-01
    phi[7,1]  R1132     -1.3668122291564941e+00
    phi[7,1]  R1133     -2.1489934921264648e+00
    phi[7,1]  R1134     -1.8899157047271729e+00
    phi[7,1]  R1135     -8.8776206970214844e-01
    phi[7,1]  R1136     -9.5157051086425781e-01
    phi[7,1]  R1137     5.4105478525161743e-01
    phi[7,1]  R1138     -1.5727872848510742e+00
    phi[7,1]  R1139     -2.3860310018062592e-01
    phi[7,1]  R1140     -1.2798976898193359e+00
    phi[7,1]  R1141     -1.2325476408004761e+00
    phi[7,1]  R1142     -1.6513645648956299e+00
    phi[7,1]  R1143     -1.9905910491943359e+00
    phi[7,1]  R1144     -2.2684124112129211e-01
    phi[7,1]  R1145     1.6258996725082397e+00
    phi[7,1]  R1146     -1.9279876947402954e+00
    phi[7,1]  R1147     5.4483568668365479e-01
    phi[7,1]  R1148     -8.4611111879348755e-01
    phi[7,1]  R1149     1.8662067651748657e+00
    phi[7,1]  R1150     -1.9398202896118164e+00
    phi[7,1]  R1151     -1.0792801529169083e-01
    phi[7,1]  R1152     -9.9833548069000244e-01
    phi[7,1]  R1153     -8.1440013647079468e-01
    phi[7,1]  R1154     1.6196583509445190e+00
    phi[7,1]  R1155     3.0551645159721375e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1156     -3.0999999046325684e+00
    phi[2,3]  R1157     -3.0999999046325684e+00
    phi[2,3]  R1158     -2.2400000095367432e+00
    phi[2,3]  R1159     -2.2400000095367432e+00
    phi[2,3]  R1160     -3.0999999046325684e+00
    phi[2,3]  R1161     -3.0999999046325684e+00
    phi[2,3]  R1162     -2.5699999332427979e+00
    phi[2,3]  R1163     -2.5699999332427979e+00
    phi[2,3]  R1164     -3.0999999046325684e+00
    phi[2,3]  R1165     -3.0999999046325684e+00
    phi[2,3]  R1166     -2.0899999141693115e+00
    phi[2,3]  R1167     -2.0899999141693115e+00
    phi[2,3]  R1168     -3.0999999046325684e+00
    phi[2,3]  R1169     -3.0999999046325684e+00
    phi[2,3]  R1170     8.0786603689193726e-01
    phi[2,3]  R1171     7.1641206741333008e-01
    phi[2,3]  R1172     1.4393913745880127e+00
    phi[2,3]  R1173     -3.5111829638481140e-01
    phi[2,3]  R1174     -4.0952679514884949e-01
    phi[2,3]  R1175     2.3377480506896973e+00
    phi[2,3]  R1176     1.8587820529937744e+00
    phi[2,3]  R1177     -1.9482092857360840e+00
    phi[2,3]  R1178     3.0694682598114014e+00
    phi[2,3]  R1179     5.9986180067062378e-01
    phi[2,3]  R1180     1.2426754236221313e+00
    phi[2,3]  R1181     -2.7419283390045166e+00
    phi[2,3]  R1182     -2.2499439716339111e+00
    phi[2,3]  R1183     -1.5730418264865875e-01
    phi[2,3]  R1184     -2.1421055793762207e+00
    phi[2,3]  R1185     -3.6601121425628662e+00
    phi[2,3]  R1186     -2.5075614452362061e+00
    phi[2,3]  R1187     -3.3420655727386475e+00
    phi[2,3]  R1188     -1.7481670379638672e+00
    phi[2,3]  R1189     -1.0879999399185181e+00
    phi[2,3]  R1190     -8.6936020851135254e-01
    phi[2,3]  R1191     -2.5862040519714355e+00
    phi[2,3]  R1192     2.7027806267142296e-02
    phi[2,3]  R1193     -1.2045701742172241e+00
    phi[2,3]  R1194     -2.6990315914154053e+00
    phi[2,3]  R1195     0.521091103553772
    phi[2,3]  R1196     -2.3710992336273193e+00
    phi[2,3]  R1197     -1.4575570821762085e+00
    phi[2,3]  R1198     -1.5494993925094604e+00
    phi[2,3]  R1199     -2.87011456489563
    phi[2,3]  R1200     -1.8798170089721680e+00
    phi[2,3]  R1201     -2.2968268394470215e+00
    phi[2,3]  R1202     2.0874054431915283e+00
    phi[2,3]  R1203     1.3691589832305908e+00
    phi[2,3]  R1204     2.3171701431274414e+00
    phi[2,3]  R1205     2.8823087215423584e+00
    phi[2,3]  R1206     2.8800537586212158e+00
    phi[2,3]  R1207     2.3107764720916748e+00
    phi[2,3]  R1208     6.4636695384979248e-01
    phi[2,3]  R1209     -8.7963038682937622e-01
    phi[2,3]  R1210     -1.7880413532257080e+00
    phi[2,3]  R1211     -3.2817232608795166e+00
    phi[2,3]  R1212     -1.0900740623474121e+00
    phi[2,3]  R1213     0.654232919216156
    phi[2,3]  R1214     6.2169218063354492e-01
    phi[2,3]  R1215     1.9989033937454224e+00
    phi[2,3]  R1216     2.9746482372283936e+00
    phi[2,3]  R1217     1.6789057254791260e+00
    phi[2,3]  R1218     3.1226108074188232e+00
    phi[2,3]  R1219     -5.3400844335556030e-01
    phi[2,3]  R1220     -1.3224254548549652e-01
    phi[2,3]  R1221     -8.8649958372116089e-01
    phi[2,3]  R1222     -4.7719323635101318e-01
    phi[2,3]  R1223     2.4326823651790619e-01
    phi[2,3]  R1224     1.1355647444725037e-01
    phi[2,3]  R1225     1.0799465179443359e+00
    phi[2,3]  R1226     -1.0341274738311768e+00
    phi[2,3]  R1227     -0.891402542591095
    phi[2,3]  R1228     -3.7492564320564270e-01
    phi[2,3]  R1229     -1.7356138229370117e+00
    phi[2,3]  R1230     5.4301452636718750e-01
    phi[2,3]  R1231     2.0116925239562988e+00
    phi[2,3]  R1232     6.9962137937545776e-01
    phi[2,3]  R1233     1.9135606288909912e+00
    phi[2,3]  R1234     -3.2288244366645813e-01
    phi[2,3]  R1235     1.7682911157608032e+00
    phi[2,3]  R1236     1.2683656215667725e+00
    phi[2,3]  R1237     1.1886276006698608e+00
    phi[2,3]  R1238     -6.6109704971313477e-01
    phi[2,3]  R1239     2.9773311614990234e+00
    phi[2,3]  R1240     -2.1637871265411377e+00
    phi[2,3]  R1241     -3.0163996219635010e+00
    phi[2,3]  R1242     -1.2190973758697510e+00
    phi[2,3]  R1243     -2.1271502971649170e+00
    phi[2,3]  R1244     -2.3151473999023438e+00
    phi[2,3]  R1245     -1.6957592964172363e+00
    phi[2,3]  R1246     -1.5052018165588379e+00
    phi[2,3]  R1247     -1.0363342761993408e+00
    phi[2,3]  R1248     -1.4546654224395752e+00
    phi[2,3]  R1249     6.6672779619693756e-02
    phi[2,3]  R1250     -1.5995570421218872e+00
    phi[2,3]  R1251     7.4410539865493774e-01
    phi[2,3]  R1252     -6.4341419935226440e-01
    phi[2,3]  R1253     7.5798624753952026e-01
    phi[2,3]  R1254     -8.7112945318222046e-01
    phi[2,3]  R1255     -1.3777490854263306e+00
    phi[2,3]  R1256     -2.7671670913696289e+00
    phi[2,3]  R1257     -2.6031451225280762e+00
    phi[2,3]  R1258     -2.1354725360870361e+00
    phi[2,3]  R1259     -2.6453692913055420e+00
    phi[2,3]  R1260     -1.5828638076782227e+00
    phi[2,3]  R1261     -2.2366211414337158e+00
    phi[2,3]  R1262     1.4361420273780823e-01
    phi[2,3]  R1263     0.560276448726654
    phi[2,3]  R1264     8.3116590976715088e-01
    phi[2,3]  R1265     -4.2362129688262939e-01
    phi[2,3]  R1266     5.4282151162624359e-02
    phi[2,3]  R1267     -1.5481582880020142e+00
    phi[2,3]  R1268     -2.4041914939880371e+00
    phi[2,3]  R1269     -9.1363430023193359e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1270     -3.0999999046325684e+00
    phi[3,2]  R1271     -3.0999999046325684e+00
    phi[3,2]  R1272     -2.2400000095367432e+00
    phi[3,2]  R1273     -2.2400000095367432e+00
    phi[3,2]  R1274     -3.0999999046325684e+00
    phi[3,2]  R1275     -3.0999999046325684e+00
    phi[3,2]  R1276     -2.5699999332427979e+00
    phi[3,2]  R1277     -2.5699999332427979e+00
    phi[3,2]  R1278     -3.0999999046325684e+00
    phi[3,2]  R1279     -3.0999999046325684e+00
    phi[3,2]  R1280     -2.0899999141693115e+00
    phi[3,2]  R1281     -2.0899999141693115e+00
    phi[3,2]  R1282     -3.0999999046325684e+00
    phi[3,2]  R1283     -3.0999999046325684e+00
    phi[3,2]  R1284     5.4301452636718750e-01
    phi[3,2]  R1285     2.0116925239562988e+00
    phi[3,2]  R1286     6.9962137937545776e-01
    phi[3,2]  R1287     1.9135606288909912e+00
    phi[3,2]  R1288     -3.2288244366645813e-01
    phi[3,2]  R1289     1.7682911157608032e+00
    phi[3,2]  R1290     1.2683656215667725e+00
    phi[3,2]  R1291     1.1886276006698608e+00
    phi[3,2]  R1292     -6.6109704971313477e-01
    phi[3,2]  R1293     2.9773311614990234e+00
    phi[3,2]  R1294     -2.1637871265411377e+00
    phi[3,2]  R1295     -3.0163996219635010e+00
    phi[3,2]  R1296     -1.2190973758697510e+00
    phi[3,2]  R1297     -2.1271502971649170e+00
    phi[3,2]  R1298     -2.3151473999023438e+00
    phi[3,2]  R1299     -1.6957592964172363e+00
    phi[3,2]  R1300     -1.5052018165588379e+00
    phi[3,2]  R1301     -1.0363342761993408e+00
    phi[3,2]  R1302     -1.4546654224395752e+00
    phi[3,2]  R1303     6.6672779619693756e-02
    phi[3,2]  R1304     -1.5995570421218872e+00
    phi[3,2]  R1305     7.4410539865493774e-01
    phi[3,2]  R1306     -6.4341419935226440e-01
    phi[3,2]  R1307     7.5798624753952026e-01
    phi[3,2]  R1308     -8.7112945318222046e-01
    phi[3,2]  R1309     -1.3777490854263306e+00
    phi[3,2]  R1310     -2.7671670913696289e+00
    phi[3,2]  R1311     -2.6031451225280762e+00
    phi[3,2]  R1312     -2.1354725360870361e+00
    phi[3,2]  R1313     -2.6453692913055420e+00
    phi[3,2]  R1314     -1.5828638076782227e+00
    phi[3,2]  R1315     -2.2366211414337158e+00
    phi[3,2]  R1316     1.4361420273780823e-01
    phi[3,2]  R1317     0.560276448726654
    phi[3,2]  R1318     8.3116590976715088e-01
    phi[3,2]  R1319     -4.2362129688262939e-01
    phi[3,2]  R1320     5.4282151162624359e-02
    phi[3,2]  R1321     -1.5481582880020142e+00
    phi[3,2]  R1322     -2.4041914939880371e+00
    phi[3,2]  R1323     -9.1363430023193359e-01
    phi[3,2]  R1324     8.0786603689193726e-01
    phi[3,2]  R1325     7.1641206741333008e-01
    phi[3,2]  R1326     1.4393913745880127e+00
    phi[3,2]  R1327     -3.5111829638481140e-01
    phi[3,2]  R1328     -4.0952679514884949e-01
    phi[3,2]  R1329     2.3377480506896973e+00
    phi[3,2]  R1330     1.8587820529937744e+00
    phi[3,2]  R1331     -1.9482092857360840e+00
    phi[3,2]  R1332     3.0694682598114014e+00
    phi[3,2]  R1333     5.9986180067062378e-01
    phi[3,2]  R1334     1.2426754236221313e+00
    phi[3,2]  R1335     -2.7419283390045166e+00
    phi[3,2]  R1336     -2.2499439716339111e+00
    phi[3,2]  R1337     -1.5730418264865875e-01
    phi[3,2]  R1338     -2.1421055793762207e+00
    phi[3,2]  R1339     -3.6601121425628662e+00
    phi[3,2]  R1340     -2.5075614452362061e+00
    phi[3,2]  R1341     -3.3420655727386475e+00
    phi[3,2]  R1342     -1.7481670379638672e+00
    phi[3,2]  R1343     -1.0879999399185181e+00
    phi[3,2]  R1344     -8.6936020851135254e-01
    phi[3,2]  R1345     -2.5862040519714355e+00
    phi[3,2]  R1346     2.7027806267142296e-02
    phi[3,2]  R1347     -1.2045701742172241e+00
    phi[3,2]  R1348     -2.6990315914154053e+00
    phi[3,2]  R1349     0.521091103553772
    phi[3,2]  R1350     -2.3710992336273193e+00
    phi[3,2]  R1351     -1.4575570821762085e+00
    phi[3,2]  R1352     -1.5494993925094604e+00
    phi[3,2]  R1353     -2.87011456489563
    phi[3,2]  R1354     -1.8798170089721680e+00
    phi[3,2]  R1355     -2.2968268394470215e+00
    phi[3,2]  R1356     2.0874054431915283e+00
    phi[3,2]  R1357     1.3691589832305908e+00
    phi[3,2]  R1358     2.3171701431274414e+00
    phi[3,2]  R1359     2.8823087215423584e+00
    phi[3,2]  R1360     2.8800537586212158e+00
    phi[3,2]  R1361     2.3107764720916748e+00
    phi[3,2]  R1362     6.4636695384979248e-01
    phi[3,2]  R1363     -8.7963038682937622e-01
    phi[3,2]  R1364     -1.7880413532257080e+00
    phi[3,2]  R1365     -3.2817232608795166e+00
    phi[3,2]  R1366     -1.0900740623474121e+00
    phi[3,2]  R1367     0.654232919216156
    phi[3,2]  R1368     6.2169218063354492e-01
    phi[3,2]  R1369     1.9989033937454224e+00
    phi[3,2]  R1370     2.9746482372283936e+00
    phi[3,2]  R1371     1.6789057254791260e+00
    phi[3,2]  R1372     3.1226108074188232e+00
    phi[3,2]  R1373     -5.3400844335556030e-01
    phi[3,2]  R1374     -1.3224254548549652e-01
    phi[3,2]  R1375     -8.8649958372116089e-01
    phi[3,2]  R1376     -4.7719323635101318e-01
    phi[3,2]  R1377     2.4326823651790619e-01
    phi[3,2]  R1378     1.1355647444725037e-01
    phi[3,2]  R1379     1.0799465179443359e+00
    phi[3,2]  R1380     -1.0341274738311768e+00
    phi[3,2]  R1381     -0.891402542591095
    phi[3,2]  R1382     -3.7492564320564270e-01
    phi[3,2]  R1383     -1.7356138229370117e+00
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1384     -3.0999999046325684e+00
    phi[3,4]  R1385     -3.0999999046325684e+00
    phi[3,4]  R1386     -2.2400000095367432e+00
    phi[3,4]  R1387     -2.2400000095367432e+00
    phi[3,4]  R1388     -3.0999999046325684e+00
    phi[3,4]  R1389     -3.0999999046325684e+00
    phi[3,4]  R1390     -2.5699999332427979e+00
    phi[3,4]  R1391     -2.5699999332427979e+00
    phi[3,4]  R1392     -3.0999999046325684e+00
    phi[3,4]  R1393     -3.0999999046325684e+00
    phi[3,4]  R1394     -2.0899999141693115e+00
    phi[3,4]  R1395     -2.0899999141693115e+00
    phi[3,4]  R1396     -3.0999999046325684e+00
    phi[3,4]  R1397     -3.0999999046325684e+00
    phi[3,4]  R1398     5.4301452636718750e-01
    phi[3,4]  R1399     2.0116925239562988e+00
    phi[3,4]  R1400     6.9962137937545776e-01
    phi[3,4]  R1401     1.9135606288909912e+00
    phi[3,4]  R1402     -3.2288244366645813e-01
    phi[3,4]  R1403     1.7682911157608032e+00
    phi[3,4]  R1404     1.2683656215667725e+00
    phi[3,4]  R1405     1.1886276006698608e+00
    phi[3,4]  R1406     -6.6109704971313477e-01
    phi[3,4]  R1407     2.9773311614990234e+00
    phi[3,4]  R1408     -2.1637871265411377e+00
    phi[3,4]  R1409     -3.0163996219635010e+00
    phi[3,4]  R1410     -1.2190973758697510e+00
    phi[3,4]  R1411     -2.1271502971649170e+00
    phi[3,4]  R1412     -2.3151473999023438e+00
    phi[3,4]  R1413     -1.6957592964172363e+00
    phi[3,4]  R1414     -1.5052018165588379e+00
    phi[3,4]  R1415     -1.0363342761993408e+00
    phi[3,4]  R1416     -1.4546654224395752e+00
    phi[3,4]  R1417     6.6672779619693756e-02
    phi[3,4]  R1418     -1.5995570421218872e+00
    phi[3,4]  R1419     7.4410539865493774e-01
    phi[3,4]  R1420     -6.4341419935226440e-01
    phi[3,4]  R1421     7.5798624753952026e-01
    phi[3,4]  R1422     -8.7112945318222046e-01
    phi[3,4]  R1423     -1.3777490854263306e+00
    phi[3,4]  R1424     -2.7671670913696289e+00
    phi[3,4]  R1425     -2.6031451225280762e+00
    phi[3,4]  R1426     -2.1354725360870361e+00
    phi[3,4]  R1427     -2.6453692913055420e+00
    phi[3,4]  R1428     -1.5828638076782227e+00
    phi[3,4]  R1429     -2.2366211414337158e+00
    phi[3,4]  R1430     1.4361420273780823e-01
    phi[3,4]  R1431     0.560276448726654
    phi[3,4]  R1432     8.3116590976715088e-01
    phi[3,4]  R1433     -4.2362129688262939e-01
    phi[3,4]  R1434     5.4282151162624359e-02
    phi[3,4]  R1435     -1.5481582880020142e+00
    phi[3,4]  R1436     -2.4041914939880371e+00
    phi[3,4]  R1437     -9.1363430023193359e-01
    phi[3,4]  R1438     1.5132053196430206e-01
    phi[3,4]  R1439     -3.2858854532241821e-01
    phi[3,4]  R1440     6.9058108329772949e-01
    phi[3,4]  R1441     -7.9128110408782959e-01
    phi[3,4]  R1442     -1.8973617553710938e+00
    phi[3,4]  R1443     1.8260340690612793e+00
    phi[3,4]  R1444     2.2739622592926025e+00
    phi[3,4]  R1445     5.3751808404922485e-01
    phi[3,4]  R1446     2.4600176811218262e+00
    phi[3,4]  R1447     2.1750757694244385e+00
    phi[3,4]  R1448     -2.6624202728271484e+00
    phi[3,4]  R1449     -2.1576702594757080e+00
    phi[3,4]  R1450     -1.6714205741882324e+00
    phi[3,4]  R1451     -1.8643856048583984e+00
    phi[3,4]  R1452     -6.0773772001266479e-01
    phi[3,4]  R1453     -1.6379754543304443e+00
    phi[3,4]  R1454     -2.3578174114227295e+00
    phi[3,4]  R1455     -1.4603581428527832e+00
    phi[3,4]  R1456     3.8047683238983154e-01
    phi[3,4]  R1457     -1.1817698478698730e+00
    phi[3,4]  R1458     8.4066860377788544e-02
    phi[3,4]  R1459     1.8670029640197754e+00
    phi[3,4]  R1460     -3.5495104789733887e+00
    phi[3,4]  R1461     -1.9779573380947113e-01
    phi[3,4]  R1462     5.5089813470840454e-01
    phi[3,4]  R1463     1.2613279819488525e+00
    phi[3,4]  R1464     -1.8200945854187012e-01
    phi[3,4]  R1465     -5.4556232690811157e-01
    phi[3,4]  R1466     -5.8386214077472687e-03
    phi[3,4]  R1467     2.2097306251525879e+00
    phi[3,4]  R1468     -2.2871522903442383e+00
    phi[3,4]  R1469     3.9482709765434265e-01
    phi[3,4]  R1470     -6.5235964953899384e-02
    phi[3,4]  R1471     -1.6307736635208130e+00
    phi[3,4]  R1472     -1.6180105209350586e+00
    phi[3,4]  R1473     1.0895246267318726e+00
    phi[3,4]  R1474     4.3104001879692078e-01
    phi[3,4]  R1475     2.7414767742156982e+00
    phi[3,4]  R1476     -1.0861378163099289e-01
    phi[3,4]  R1477     -7.9317373037338257e-01
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1478     -3.0999999046325684e+00
    phi[4,3]  R1479     -3.0999999046325684e+00
    phi[4,3]  R1480     -2.2400000095367432e+00
    phi[4,3]  R1481     -2.2400000095367432e+00
    phi[4,3]  R1482     -3.0999999046325684e+00
    phi[4,3]  R1483     -3.0999999046325684e+00
    phi[4,3]  R1484     -2.5699999332427979e+00
    phi[4,3]  R1485     -2.5699999332427979e+00
    phi[4,3]  R1486     -3.0999999046325684e+00
    phi[4,3]  R1487     -3.0999999046325684e+00
    phi[4,3]  R1488     -2.0899999141693115e+00
    phi[4,3]  R1489     -2.0899999141693115e+00
    phi[4,3]  R1490     -3.0999999046325684e+00
    phi[4,3]  R1491     -3.0999999046325684e+00
    phi[4,3]  R1492     1.5132053196430206e-01
    phi[4,3]  R1493     -3.2858854532241821e-01
    phi[4,3]  R1494     6.9058108329772949e-01
    phi[4,3]  R1495     -7.9128110408782959e-01
    phi[4,3]  R1496     -1.8973617553710938e+00
    phi[4,3]  R1497     1.8260340690612793e+00
    phi[4,3]  R1498     2.2739622592926025e+00
    phi[4,3]  R1499     5.3751808404922485e-01
    phi[4,3]  R1500     2.4600176811218262e+00
    phi[4,3]  R1501     2.1750757694244385e+00
    phi[4,3]  R1502     -2.6624202728271484e+00
    phi[4,3]  R1503     -2.1576702594757080e+00
    phi[4,3]  R1504     -1.6714205741882324e+00
    phi[4,3]  R1505     -1.8643856048583984e+00
    phi[4,3]  R1506     -6.0773772001266479e-01
    phi[4,3]  R1507     -1.6379754543304443e+00
    phi[4,3]  R1508     -2.3578174114227295e+00
    phi[4,3]  R1509     -1.4603581428527832e+00
    phi[4,3]  R1510     3.8047683238983154e-01
    phi[4,3]  R1511     -1.1817698478698730e+00
    phi[4,3]  R1512     8.4066860377788544e-02
    phi[4,3]  R1513     1.8670029640197754e+00
    phi[4,3]  R1514     -3.5495104789733887e+00
    phi[4,3]  R1515     -1.9779573380947113e-01
    phi[4,3]  R1516     5.5089813470840454e-01
    phi[4,3]  R1517     1.2613279819488525e+00
    phi[4,3]  R1518     -1.8200945854187012e-01
    phi[4,3]  R1519     -5.4556232690811157e-01
    phi[4,3]  R1520     -5.8386214077472687e-03
    phi[4,3]  R1521     2.2097306251525879e+00
    phi[4,3]  R1522     -2.2871522903442383e+00
    phi[4,3]  R1523     3.9482709765434265e-01
    phi[4,3]  R1524     -6.5235964953899384e-02
    phi[4,3]  R1525     -1.6307736635208130e+00
    phi[4,3]  R1526     -1.6180105209350586e+00
    phi[4,3]  R1527     1.0895246267318726e+00
    phi[4,3]  R1528     4.3104001879692078e-01
    phi[4,3]  R1529     2.7414767742156982e+00
    phi[4,3]  R1530     -1.0861378163099289e-01
    phi[4,3]  R1531     -7.9317373037338257e-01
    phi[4,3]  R1532     5.4301452636718750e-01
    phi[4,3]  R1533     2.0116925239562988e+00
    phi[4,3]  R1534     6.9962137937545776e-01
    phi[4,3]  R1535     1.9135606288909912e+00
    phi[4,3]  R1536     -3.2288244366645813e-01
    phi[4,3]  R1537     1.7682911157608032e+00
    phi[4,3]  R1538     1.2683656215667725e+00
    phi[4,3]  R1539     1.1886276006698608e+00
    phi[4,3]  R1540     -6.6109704971313477e-01
    phi[4,3]  R1541     2.9773311614990234e+00
    phi[4,3]  R1542     -2.1637871265411377e+00
    phi[4,3]  R1543     -3.0163996219635010e+00
    phi[4,3]  R1544     -1.2190973758697510e+00
    phi[4,3]  R1545     -2.1271502971649170e+00
    phi[4,3]  R1546     -2.3151473999023438e+00
    phi[4,3]  R1547     -1.6957592964172363e+00
    phi[4,3]  R1548     -1.5052018165588379e+00
    phi[4,3]  R1549     -1.0363342761993408e+00
    phi[4,3]  R1550     -1.4546654224395752e+00
    phi[4,3]  R1551     6.6672779619693756e-02
    phi[4,3]  R1552     -1.5995570421218872e+00
    phi[4,3]  R1553     7.4410539865493774e-01
    phi[4,3]  R1554     -6.4341419935226440e-01
    phi[4,3]  R1555     7.5798624753952026e-01
    phi[4,3]  R1556     -8.7112945318222046e-01
    phi[4,3]  R1557     -1.3777490854263306e+00
    phi[4,3]  R1558     -2.7671670913696289e+00
    phi[4,3]  R1559     -2.6031451225280762e+00
    phi[4,3]  R1560     -2.1354725360870361e+00
    phi[4,3]  R1561     -2.6453692913055420e+00
    phi[4,3]  R1562     -1.5828638076782227e+00
    phi[4,3]  R1563     -2.2366211414337158e+00
    phi[4,3]  R1564     1.4361420273780823e-01
    phi[4,3]  R1565     0.560276448726654
    phi[4,3]  R1566     8.3116590976715088e-01
    phi[4,3]  R1567     -4.2362129688262939e-01
    phi[4,3]  R1568     5.4282151162624359e-02
    phi[4,3]  R1569     -1.5481582880020142e+00
    phi[4,3]  R1570     -2.4041914939880371e+00
    phi[4,3]  R1571     -9.1363430023193359e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1572     -3.0999999046325684e+00
    phi[4,5]  R1573     -3.0999999046325684e+00
    phi[4,5]  R1574     -2.2400000095367432e+00
    phi[4,5]  R1575     -2.2400000095367432e+00
    phi[4,5]  R1576     -3.0999999046325684e+00
    phi[4,5]  R1577     -3.0999999046325684e+00
    phi[4,5]  R1578     -2.5699999332427979e+00
    phi[4,5]  R1579     -2.5699999332427979e+00
    phi[4,5]  R1580     -3.0999999046325684e+00
    phi[4,5]  R1581     -3.0999999046325684e+00
    phi[4,5]  R1582     -2.0899999141693115e+00
    phi[4,5]  R1583     -2.0899999141693115e+00
    phi[4,5]  R1584     -3.0999999046325684e+00
    phi[4,5]  R1585     -3.0999999046325684e+00
    phi[4,5]  R1586     1.5132053196430206e-01
    phi[4,5]  R1587     -3.2858854532241821e-01
    phi[4,5]  R1588     6.9058108329772949e-01
    phi[4,5]  R1589     -7.9128110408782959e-01
    phi[4,5]  R1590     -1.8973617553710938e+00
    phi[4,5]  R1591     1.8260340690612793e+00
    phi[4,5]  R1592     2.2739622592926025e+00
    phi[4,5]  R1593     5.3751808404922485e-01
    phi[4,5]  R1594     2.4600176811218262e+00
    phi[4,5]  R1595     2.1750757694244385e+00
    phi[4,5]  R1596     -2.6624202728271484e+00
    phi[4,5]  R1597     -2.1576702594757080e+00
    phi[4,5]  R1598     -1.6714205741882324e+00
    phi[4,5]  R1599     -1.8643856048583984e+00
    phi[4,5]  R1600     -6.0773772001266479e-01
    phi[4,5]  R1601     -1.6379754543304443e+00
    phi[4,5]  R1602     -2.3578174114227295e+00
    phi[4,5]  R1603     -1.4603581428527832e+00
    phi[4,5]  R1604     3.8047683238983154e-01
    phi[4,5]  R1605     -1.1817698478698730e+00
    phi[4,5]  R1606     8.4066860377788544e-02
    phi[4,5]  R1607     1.8670029640197754e+00
    phi[4,5]  R1608     -3.5495104789733887e+00
    phi[4,5]  R1609     -1.9779573380947113e-01
    phi[4,5]  R1610     5.5089813470840454e-01
    phi[4,5]  R1611     1.2613279819488525e+00
    phi[4,5]  R1612     -1.8200945854187012e-01
    phi[4,5]  R1613     -5.4556232690811157e-01
    phi[4,5]  R1614     -5.8386214077472687e-03
    phi[4,5]  R1615     2.2097306251525879e+00
    phi[4,5]  R1616     -2.2871522903442383e+00
    phi[4,5]  R1617     3.9482709765434265e-01
    phi[4,5]  R1618     -6.5235964953899384e-02
    phi[4,5]  R1619     -1.6307736635208130e+00
    phi[4,5]  R1620     -1.6180105209350586e+00
    phi[4,5]  R1621     1.0895246267318726e+00
    phi[4,5]  R1622     4.3104001879692078e-01
    phi[4,5]  R1623     2.7414767742156982e+00
    phi[4,5]  R1624     -1.0861378163099289e-01
    phi[4,5]  R1625     -7.9317373037338257e-01
    phi[4,5]  R1626     2.1165213584899902e+00
    phi[4,5]  R1627     7.2308969497680664e-01
    phi[4,5]  R1628     -1.5602080821990967e+00
    phi[4,5]  R1629     -3.0994510650634766e-01
    phi[4,5]  R1630     5.3391796350479126e-01
    phi[4,5]  R1631     -3.4909281134605408e-01
    phi[4,5]  R1632     -1.7518922090530396e+00
    phi[4,5]  R1633     7.3234319686889648e-01
    phi[4,5]  R1634     8.5885190963745117e-01
    phi[4,5]  R1635     2.0002782344818115e+00
    phi[4,5]  R1636     7.6688937842845917e-02
    phi[4,5]  R1637     -5.3507310152053833e-01
    phi[4,5]  R1638     -7.1354568004608154e-02
    phi[4,5]  R1639     3.8823747634887695e-01
    phi[4,5]  R1640     7.8415459394454956e-01
    phi[4,5]  R1641     -3.5915219783782959e+00
    phi[4,5]  R1642     -2.4265739917755127e+00
    phi[4,5]  R1643     -3.8343389034271240e+00
    phi[4,5]  R1644     -1.5297281742095947e+00
    phi[4,5]  R1645     1.5307280421257019e-01
    phi[4,5]  R1646     -3.3610882759094238e+00
    phi[4,5]  R1647     -1.6722922325134277e+00
    phi[4,5]  R1648     -1.5968784093856812e+00
    phi[4,5]  R1649     -1.3980268239974976e+00
    phi[4,5]  R1650     -1.2853127717971802e+00
    phi[4,5]  R1651     -1.0975484848022461e+00
    phi[4,5]  R1652     -3.67848539352417
    phi[4,5]  R1653     2.1184508800506592e+00
    phi[4,5]  R1654     -2.8128664493560791e+00
    phi[4,5]  R1655     2.0287983417510986e+00
    phi[4,5]  R1656     -1.8377016782760620e+00
    phi[4,5]  R1657     1.3876323401927948e-01
    phi[4,5]  R1658     4.1846714913845062e-02
    phi[4,5]  R1659     -6.5188914537429810e-01
    phi[4,5]  R1660     -1.6529903411865234e+00
    phi[4,5]  R1661     -1.1135631799697876e+00
    phi[4,5]  R1662     1.2023074179887772e-01
    phi[4,5]  R1663     3.9294254779815674e-01
    phi[4,5]  R1664     2.3972176015377045e-01
    phi[4,5]  R1665     -4.9594807624816895e-01
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1666     -3.0999999046325684e+00
    phi[5,4]  R1667     -3.0999999046325684e+00
    phi[5,4]  R1668     -2.2400000095367432e+00
    phi[5,4]  R1669     -2.2400000095367432e+00
    phi[5,4]  R1670     -3.0999999046325684e+00
    phi[5,4]  R1671     -3.0999999046325684e+00
    phi[5,4]  R1672     -2.5699999332427979e+00
    phi[5,4]  R1673     -2.5699999332427979e+00
    phi[5,4]  R1674     -3.0999999046325684e+00
    phi[5,4]  R1675     -3.0999999046325684e+00
    phi[5,4]  R1676     -2.0899999141693115e+00
    phi[5,4]  R1677     -2.0899999141693115e+00
    phi[5,4]  R1678     -3.0999999046325684e+00
    phi[5,4]  R1679     -3.0999999046325684e+00
    phi[5,4]  R1680     2.1165213584899902e+00
    phi[5,4]  R1681     7.2308969497680664e-01
    phi[5,4]  R1682     -1.5602080821990967e+00
    phi[5,4]  R1683     -3.0994510650634766e-01
    phi[5,4]  R1684     5.3391796350479126e-01
    phi[5,4]  R1685     -3.4909281134605408e-01
    phi[5,4]  R1686     -1.7518922090530396e+00
    phi[5,4]  R1687     7.3234319686889648e-01
    phi[5,4]  R1688     8.5885190963745117e-01
    phi[5,4]  R1689     2.0002782344818115e+00
    phi[5,4]  R1690     7.6688937842845917e-02
    phi[5,4]  R1691     -5.3507310152053833e-01
    phi[5,4]  R1692     -7.1354568004608154e-02
    phi[5,4]  R1693     3.8823747634887695e-01
    phi[5,4]  R1694     7.8415459394454956e-01
    phi[5,4]  R1695     -3.5915219783782959e+00
    phi[5,4]  R1696     -2.4265739917755127e+00
    phi[5,4]  R1697     -3.8343389034271240e+00
    phi[5,4]  R1698     -1.5297281742095947e+00
    phi[5,4]  R1699     1.5307280421257019e-01
    phi[5,4]  R1700     -3.3610882759094238e+00
    phi[5,4]  R1701     -1.6722922325134277e+00
    phi[5,4]  R1702     -1.5968784093856812e+00
    phi[5,4]  R1703     -1.3980268239974976e+00
    phi[5,4]  R1704     -1.2853127717971802e+00
    phi[5,4]  R1705     -1.0975484848022461e+00
    phi[5,4]  R1706     -3.67848539352417
    phi[5,4]  R1707     2.1184508800506592e+00
    phi[5,4]  R1708     -2.8128664493560791e+00
    phi[5,4]  R1709     2.0287983417510986e+00
    phi[5,4]  R1710     -1.8377016782760620e+00
    phi[5,4]  R1711     1.3876323401927948e-01
    phi[5,4]  R1712     4.1846714913845062e-02
    phi[5,4]  R1713     -6.5188914537429810e-01
    phi[5,4]  R1714     -1.6529903411865234e+00
    phi[5,4]  R1715     -1.1135631799697876e+00
    phi[5,4]  R1716     1.2023074179887772e-01
    phi[5,4]  R1717     3.9294254779815674e-01
    phi[5,4]  R1718     2.3972176015377045e-01
    phi[5,4]  R1719     -4.9594807624816895e-01
    phi[5,4]  R1720     1.5132053196430206e-01
    phi[5,4]  R1721     -3.2858854532241821e-01
    phi[5,4]  R1722     6.9058108329772949e-01
    phi[5,4]  R1723     -7.9128110408782959e-01
    phi[5,4]  R1724     -1.8973617553710938e+00
    phi[5,4]  R1725     1.8260340690612793e+00
    phi[5,4]  R1726     2.2739622592926025e+00
    phi[5,4]  R1727     5.3751808404922485e-01
    phi[5,4]  R1728     2.4600176811218262e+00
    phi[5,4]  R1729     2.1750757694244385e+00
    phi[5,4]  R1730     -2.6624202728271484e+00
    phi[5,4]  R1731     -2.1576702594757080e+00
    phi[5,4]  R1732     -1.6714205741882324e+00
    phi[5,4]  R1733     -1.8643856048583984e+00
    phi[5,4]  R1734     -6.0773772001266479e-01
    phi[5,4]  R1735     -1.6379754543304443e+00
    phi[5,4]  R1736     -2.3578174114227295e+00
    phi[5,4]  R1737     -1.4603581428527832e+00
    phi[5,4]  R1738     3.8047683238983154e-01
    phi[5,4]  R1739     -1.1817698478698730e+00
    phi[5,4]  R1740     8.4066860377788544e-02
    phi[5,4]  R1741     1.8670029640197754e+00
    phi[5,4]  R1742     -3.5495104789733887e+00
    phi[5,4]  R1743     -1.9779573380947113e-01
    phi[5,4]  R1744     5.5089813470840454e-01
    phi[5,4]  R1745     1.2613279819488525e+00
    phi[5,4]  R1746     -1.8200945854187012e-01
    phi[5,4]  R1747     -5.4556232690811157e-01
    phi[5,4]  R1748     -5.8386214077472687e-03
    phi[5,4]  R1749     2.2097306251525879e+00
    phi[5,4]  R1750     -2.2871522903442383e+00
    phi[5,4]  R1751     3.9482709765434265e-01
    phi[5,4]  R1752     -6.5235964953899384e-02
    phi[5,4]  R1753     -1.6307736635208130e+00
    phi[5,4]  R1754     -1.6180105209350586e+00
    phi[5,4]  R1755     1.0895246267318726e+00
    phi[5,4]  R1756     4.3104001879692078e-01
    phi[5,4]  R1757     2.7414767742156982e+00
    phi[5,4]  R1758     -1.0861378163099289e-01
    phi[5,4]  R1759     -7.9317373037338257e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R1760     -3.0999999046325684e+00
    phi[5,6]  R1761     -3.0999999046325684e+00
    phi[5,6]  R1762     -2.2400000095367432e+00
    phi[5,6]  R1763     -2.2400000095367432e+00
    phi[5,6]  R1764     -3.0999999046325684e+00
    phi[5,6]  R1765     -3.0999999046325684e+00
    phi[5,6]  R1766     -2.5699999332427979e+00
    phi[5,6]  R1767     -2.5699999332427979e+00
    phi[5,6]  R1768     -3.0999999046325684e+00
    phi[5,6]  R1769     -3.0999999046325684e+00
    phi[5,6]  R1770     -2.0899999141693115e+00
    phi[5,6]  R1771     -2.0899999141693115e+00
    phi[5,6]  R1772     -3.0999999046325684e+00
    phi[5,6]  R1773     -3.0999999046325684e+00
    phi[5,6]  R1774     2.1165213584899902e+00
    phi[5,6]  R1775     7.2308969497680664e-01
    phi[5,6]  R1776     -1.5602080821990967e+00
    phi[5,6]  R1777     -3.0994510650634766e-01
    phi[5,6]  R1778     5.3391796350479126e-01
    phi[5,6]  R1779     -3.4909281134605408e-01
    phi[5,6]  R1780     -1.7518922090530396e+00
    phi[5,6]  R1781     7.3234319686889648e-01
    phi[5,6]  R1782     8.5885190963745117e-01
    phi[5,6]  R1783     2.0002782344818115e+00
    phi[5,6]  R1784     7.6688937842845917e-02
    phi[5,6]  R1785     -5.3507310152053833e-01
    phi[5,6]  R1786     -7.1354568004608154e-02
    phi[5,6]  R1787     3.8823747634887695e-01
    phi[5,6]  R1788     7.8415459394454956e-01
    phi[5,6]  R1789     -3.5915219783782959e+00
    phi[5,6]  R1790     -2.4265739917755127e+00
    phi[5,6]  R1791     -3.8343389034271240e+00
    phi[5,6]  R1792     -1.5297281742095947e+00
    phi[5,6]  R1793     1.5307280421257019e-01
    phi[5,6]  R1794     -3.3610882759094238e+00
    phi[5,6]  R1795     -1.6722922325134277e+00
    phi[5,6]  R1796     -1.5968784093856812e+00
    phi[5,6]  R1797     -1.3980268239974976e+00
    phi[5,6]  R1798     -1.2853127717971802e+00
    phi[5,6]  R1799     -1.0975484848022461e+00
    phi[5,6]  R1800     -3.67848539352417
    phi[5,6]  R1801     2.1184508800506592e+00
    phi[5,6]  R1802     -2.8128664493560791e+00
    phi[5,6]  R1803     2.0287983417510986e+00
    phi[5,6]  R1804     -1.8377016782760620e+00
    phi[5,6]  R1805     1.3876323401927948e-01
    phi[5,6]  R1806     4.1846714913845062e-02
    phi[5,6]  R1807     -6.5188914537429810e-01
    phi[5,6]  R1808     -1.6529903411865234e+00
    phi[5,6]  R1809     -1.1135631799697876e+00
    phi[5,6]  R1810     1.2023074179887772e-01
    phi[5,6]  R1811     3.9294254779815674e-01
    phi[5,6]  R1812     2.3972176015377045e-01
    phi[5,6]  R1813     -4.9594807624816895e-01
    phi[5,6]  R1814     1.8995443582534790e+00
    phi[5,6]  R1815     -9.8058871924877167e-02
    phi[5,6]  R1816     8.8887715339660645e-01
    phi[5,6]  R1817     1.6052172183990479e+00
    phi[5,6]  R1818     3.2450896501541138e-01
    phi[5,6]  R1819     3.9605379104614258e-01
    phi[5,6]  R1820     -2.2444821894168854e-01
    phi[5,6]  R1821     1.1835951805114746e+00
    phi[5,6]  R1822     -1.0702869296073914e-01
    phi[5,6]  R1823     7.2948426008224487e-01
    phi[5,6]  R1824     -2.2262823581695557e+00
    phi[5,6]  R1825     -2.9352024197578430e-01
    phi[5,6]  R1826     -9.8595410585403442e-01
    phi[5,6]  R1827     -1.54683256149292
    phi[5,6]  R1828     -2.09316349029541
    phi[5,6]  R1829     -1.6229231357574463e+00
    phi[5,6]  R1830     -1.0691384077072144e+00
    phi[5,6]  R1831     -2.3470537662506104e+00
    phi[5,6]  R1832     -2.6523220539093018e+00
    phi[5,6]  R1833     -2.0940120220184326e+00
    phi[5,6]  R1834     -5.4659098386764526e-01
    phi[5,6]  R1835     -2.2760362625122070e+00
    phi[5,6]  R1836     -1.0502289533615112e+00
    phi[5,6]  R1837     -1.44489586353302
    phi[5,6]  R1838     2.5122940540313721e-01
    phi[5,6]  R1839     -1.2394889593124390e+00
    phi[5,6]  R1840     -1.8778074979782104e+00
    phi[5,6]  R1841     -1.5595707893371582e+00
    phi[5,6]  R1842     -1.0592002868652344e+00
    phi[5,6]  R1843     -1.1280980110168457e+00
    phi[5,6]  R1844     -5.8078575134277344e-01
    phi[5,6]  R1845     -3.7194153666496277e-01
    phi[5,6]  R1846     -1.9900658130645752e+00
    phi[5,6]  R1847     -1.4523872137069702e+00
    phi[5,6]  R1848     -1.2675957679748535e+00
    phi[5,6]  R1849     2.3996865749359131e-01
    phi[5,6]  R1850     -2.4707953929901123e+00
    phi[5,6]  R1851     -1.5241569280624390e+00
    phi[5,6]  R1852     -3.5946995019912720e-01
    phi[5,6]  R1853     -1.1945325881242752e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R1854     -3.0999999046325684e+00
    phi[6,5]  R1855     -3.0999999046325684e+00
    phi[6,5]  R1856     -2.2400000095367432e+00
    phi[6,5]  R1857     -2.2400000095367432e+00
    phi[6,5]  R1858     -3.0999999046325684e+00
    phi[6,5]  R1859     -3.0999999046325684e+00
    phi[6,5]  R1860     -2.5699999332427979e+00
    phi[6,5]  R1861     -2.5699999332427979e+00
    phi[6,5]  R1862     -3.0999999046325684e+00
    phi[6,5]  R1863     -3.0999999046325684e+00
    phi[6,5]  R1864     -2.0899999141693115e+00
    phi[6,5]  R1865     -2.0899999141693115e+00
    phi[6,5]  R1866     -3.0999999046325684e+00
    phi[6,5]  R1867     -3.0999999046325684e+00
    phi[6,5]  R1868     1.8995443582534790e+00
    phi[6,5]  R1869     -9.8058871924877167e-02
    phi[6,5]  R1870     8.8887715339660645e-01
    phi[6,5]  R1871     1.6052172183990479e+00
    phi[6,5]  R1872     3.2450896501541138e-01
    phi[6,5]  R1873     3.9605379104614258e-01
    phi[6,5]  R1874     -2.2444821894168854e-01
    phi[6,5]  R1875     1.1835951805114746e+00
    phi[6,5]  R1876     -1.0702869296073914e-01
    phi[6,5]  R1877     7.2948426008224487e-01
    phi[6,5]  R1878     -2.2262823581695557e+00
    phi[6,5]  R1879     -2.9352024197578430e-01
    phi[6,5]  R1880     -9.8595410585403442e-01
    phi[6,5]  R1881     -1.54683256149292
    phi[6,5]  R1882     -2.09316349029541
    phi[6,5]  R1883     -1.6229231357574463e+00
    phi[6,5]  R1884     -1.0691384077072144e+00
    phi[6,5]  R1885     -2.3470537662506104e+00
    phi[6,5]  R1886     -2.6523220539093018e+00
    phi[6,5]  R1887     -2.0940120220184326e+00
    phi[6,5]  R1888     -5.4659098386764526e-01
    phi[6,5]  R1889     -2.2760362625122070e+00
    phi[6,5]  R1890     -1.0502289533615112e+00
    phi[6,5]  R1891     -1.44489586353302
    phi[6,5]  R1892     2.5122940540313721e-01
    phi[6,5]  R1893     -1.2394889593124390e+00
    phi[6,5]  R1894     -1.8778074979782104e+00
    phi[6,5]  R1895     -1.5595707893371582e+00
    phi[6,5]  R1896     -1.0592002868652344e+00
    phi[6,5]  R1897     -1.1280980110168457e+00
    phi[6,5]  R1898     -5.8078575134277344e-01
    phi[6,5]  R1899     -3.7194153666496277e-01
    phi[6,5]  R1900     -1.9900658130645752e+00
    phi[6,5]  R1901     -1.4523872137069702e+00
    phi[6,5]  R1902     -1.2675957679748535e+00
    phi[6,5]  R1903     2.3996865749359131e-01
    phi[6,5]  R1904     -2.4707953929901123e+00
    phi[6,5]  R1905     -1.5241569280624390e+00
    phi[6,5]  R1906     -3.5946995019912720e-01
    phi[6,5]  R1907     -1.1945325881242752e-01
    phi[6,5]  R1908     2.1165213584899902e+00
    phi[6,5]  R1909     7.2308969497680664e-01
    phi[6,5]  R1910     -1.5602080821990967e+00
    phi[6,5]  R1911     -3.0994510650634766e-01
    phi[6,5]  R1912     5.3391796350479126e-01
    phi[6,5]  R1913     -3.4909281134605408e-01
    phi[6,5]  R1914     -1.7518922090530396e+00
    phi[6,5]  R1915     7.3234319686889648e-01
    phi[6,5]  R1916     8.5885190963745117e-01
    phi[6,5]  R1917     2.0002782344818115e+00
    phi[6,5]  R1918     7.6688937842845917e-02
    phi[6,5]  R1919     -5.3507310152053833e-01
    phi[6,5]  R1920     -7.1354568004608154e-02
    phi[6,5]  R1921     3.8823747634887695e-01
    phi[6,5]  R1922     7.8415459394454956e-01
    phi[6,5]  R1923     -3.5915219783782959e+00
    phi[6,5]  R1924     -2.4265739917755127e+00
    phi[6,5]  R1925     -3.8343389034271240e+00
    phi[6,5]  R1926     -1.5297281742095947e+00
    phi[6,5]  R1927     1.5307280421257019e-01
    phi[6,5]  R1928     -3.3610882759094238e+00
    phi[6,5]  R1929     -1.6722922325134277e+00
    phi[6,5]  R1930     -1.5968784093856812e+00
    phi[6,5]  R1931     -1.3980268239974976e+00
    phi[6,5]  R1932     -1.2853127717971802e+00
    phi[6,5]  R1933     -1.0975484848022461e+00
    phi[6,5]  R1934     -3.67848539352417
    phi[6,5]  R1935     2.1184508800506592e+00
    phi[6,5]  R1936     -2.8128664493560791e+00
    phi[6,5]  R1937     2.0287983417510986e+00
    phi[6,5]  R1938     -1.8377016782760620e+00
    phi[6,5]  R1939     1.3876323401927948e-01
    phi[6,5]  R1940     4.1846714913845062e-02
    phi[6,5]  R1941     -6.5188914537429810e-01
    phi[6,5]  R1942     -1.6529903411865234e+00
    phi[6,5]  R1943     -1.1135631799697876e+00
    phi[6,5]  R1944     1.2023074179887772e-01
    phi[6,5]  R1945     3.9294254779815674e-01
    phi[6,5]  R1946     2.3972176015377045e-01
    phi[6,5]  R1947     -4.9594807624816895e-01
    phi[6,9]  R54       1
    phi[6,9]  R55       1
    phi[6,9]  R81       -1
    phi[6,9]  R1948     -3.0999999046325684e+00
    phi[6,9]  R1949     -3.0999999046325684e+00
    phi[6,9]  R1950     -2.2400000095367432e+00
    phi[6,9]  R1951     -2.2400000095367432e+00
    phi[6,9]  R1952     -3.0999999046325684e+00
    phi[6,9]  R1953     -3.0999999046325684e+00
    phi[6,9]  R1954     -2.5699999332427979e+00
    phi[6,9]  R1955     -2.5699999332427979e+00
    phi[6,9]  R1956     -3.0999999046325684e+00
    phi[6,9]  R1957     -3.0999999046325684e+00
    phi[6,9]  R1958     -2.0899999141693115e+00
    phi[6,9]  R1959     -2.0899999141693115e+00
    phi[6,9]  R1960     -3.0999999046325684e+00
    phi[6,9]  R1961     -3.0999999046325684e+00
    phi[6,9]  R1962     1.8995443582534790e+00
    phi[6,9]  R1963     -9.8058871924877167e-02
    phi[6,9]  R1964     8.8887715339660645e-01
    phi[6,9]  R1965     1.6052172183990479e+00
    phi[6,9]  R1966     3.2450896501541138e-01
    phi[6,9]  R1967     3.9605379104614258e-01
    phi[6,9]  R1968     -2.2444821894168854e-01
    phi[6,9]  R1969     1.1835951805114746e+00
    phi[6,9]  R1970     -1.0702869296073914e-01
    phi[6,9]  R1971     7.2948426008224487e-01
    phi[6,9]  R1972     -2.2262823581695557e+00
    phi[6,9]  R1973     -2.9352024197578430e-01
    phi[6,9]  R1974     -9.8595410585403442e-01
    phi[6,9]  R1975     -1.54683256149292
    phi[6,9]  R1976     -2.09316349029541
    phi[6,9]  R1977     -1.6229231357574463e+00
    phi[6,9]  R1978     -1.0691384077072144e+00
    phi[6,9]  R1979     -2.3470537662506104e+00
    phi[6,9]  R1980     -2.6523220539093018e+00
    phi[6,9]  R1981     -2.0940120220184326e+00
    phi[6,9]  R1982     -5.4659098386764526e-01
    phi[6,9]  R1983     -2.2760362625122070e+00
    phi[6,9]  R1984     -1.0502289533615112e+00
    phi[6,9]  R1985     -1.44489586353302
    phi[6,9]  R1986     2.5122940540313721e-01
    phi[6,9]  R1987     -1.2394889593124390e+00
    phi[6,9]  R1988     -1.8778074979782104e+00
    phi[6,9]  R1989     -1.5595707893371582e+00
    phi[6,9]  R1990     -1.0592002868652344e+00
    phi[6,9]  R1991     -1.1280980110168457e+00
    phi[6,9]  R1992     -5.8078575134277344e-01
    phi[6,9]  R1993     -3.7194153666496277e-01
    phi[6,9]  R1994     -1.9900658130645752e+00
    phi[6,9]  R1995     -1.4523872137069702e+00
    phi[6,9]  R1996     -1.2675957679748535e+00
    phi[6,9]  R1997     2.3996865749359131e-01
    phi[6,9]  R1998     -2.4707953929901123e+00
    phi[6,9]  R1999     -1.5241569280624390e+00
    phi[6,9]  R2000     -3.5946995019912720e-01
    phi[6,9]  R2001     -1.1945325881242752e-01
    phi[6,9]  R2002     -1.3770622014999390e+00
    phi[6,9]  R2003     5.6833225488662720e-01
    phi[6,9]  R2004     8.4544509649276733e-01
    phi[6,9]  R2005     -3.7393894791603088e-01
    phi[6,9]  R2006     8.0551540851593018e-01
    phi[6,9]  R2007     -7.3468881845474243e-01
    phi[6,9]  R2008     -2.46248722076416
    phi[6,9]  R2009     9.5710223913192749e-01
    phi[6,9]  R2010     7.8933566808700562e-01
    phi[6,9]  R2011     -2.5540232658386230e+00
    phi[6,9]  R2012     -4.8328506946563721e-01
    phi[6,9]  R2013     -4.7625067830085754e-01
    phi[6,9]  R2014     -2.4598406255245209e-01
    phi[6,9]  R2015     1.6408972442150116e-02
    phi[6,9]  R2016     -4.8787850141525269e-01
    phi[6,9]  R2017     -0.416997492313385
    phi[6,9]  R2018     -7.3280632495880127e-01
    phi[6,9]  R2019     -6.1915236711502075e-01
    phi[6,9]  R2020     -1.5431900322437286e-01
    phi[6,9]  R2021     -2.2088640928268433e-01
    phi[6,9]  R2022     -6.1689329147338867e-01
    phi[6,9]  R2023     -1.4016860723495483e+00
    phi[6,9]  R2024     0.716096818447113
    phi[6,9]  R2025     -1.8152981996536255e+00
    phi[6,9]  R2026     -4.3602293729782104e-01
    phi[6,9]  R2027     -2.6896500587463379e-01
    phi[6,9]  R2028     -1.1633385419845581e+00
    phi[6,9]  R2029     -6.8402653932571411e-01
    phi[6,9]  R2030     -8.4457957744598389e-01
    phi[6,9]  R2031     -1.0135630369186401e+00
    phi[6,9]  R2032     -2.03751540184021
    phi[6,9]  R2033     -1.5284481048583984e+00
    phi[6,9]  R2034     -1.9574134349822998e+00
    phi[6,9]  R2035     -1.8773310184478760e+00
    phi[6,9]  R2036     -2.1419427394866943e+00
    phi[6,9]  R2037     -1.0630619525909424e+00
    phi[6,9]  R2038     3.5026636719703674e-01
    phi[6,9]  R2039     -3.2419508695602417e-01
    phi[6,9]  R2040     -3.7456721067428589e-02
    phi[6,9]  R2041     4.9300286173820496e-01
    phi[6,9]  R2042     -1.4489610195159912e+00
    phi[6,9]  R2043     -2.3869900703430176e+00
    phi[6,9]  R2044     -1.9708932638168335e+00
    phi[6,9]  R2045     -1.5119796991348267e+00
    phi[6,9]  R2046     -8.8546389341354370e-01
    phi[6,9]  R2047     -4.2762222886085510e-01
    phi[6,9]  R2048     -2.8716245293617249e-01
    phi[6,9]  R2049     -7.9392135143280029e-01
    phi[6,9]  R2050     -3.0480644106864929e-01
    phi[6,9]  R2051     -4.8553872108459473e-01
    phi[9,6]  R54       -1
    phi[9,6]  R81       1
    phi[9,6]  R82       1
    phi[9,6]  R2052     -3.0999999046325684e+00
    phi[9,6]  R2053     -3.0999999046325684e+00
    phi[9,6]  R2054     -2.2400000095367432e+00
    phi[9,6]  R2055     -2.2400000095367432e+00
    phi[9,6]  R2056     -3.0999999046325684e+00
    phi[9,6]  R2057     -3.0999999046325684e+00
    phi[9,6]  R2058     -2.5699999332427979e+00
    phi[9,6]  R2059     -2.5699999332427979e+00
    phi[9,6]  R2060     -3.0999999046325684e+00
    phi[9,6]  R2061     -3.0999999046325684e+00
    phi[9,6]  R2062     -2.0899999141693115e+00
    phi[9,6]  R2063     -2.0899999141693115e+00
    phi[9,6]  R2064     -3.0999999046325684e+00
    phi[9,6]  R2065     -3.0999999046325684e+00
    phi[9,6]  R2066     -1.3770622014999390e+00
    phi[9,6]  R2067     5.6833225488662720e-01
    phi[9,6]  R2068     8.4544509649276733e-01
    phi[9,6]  R2069     -3.7393894791603088e-01
    phi[9,6]  R2070     8.0551540851593018e-01
    phi[9,6]  R2071     -7.3468881845474243e-01
    phi[9,6]  R2072     -2.46248722076416
    phi[9,6]  R2073     9.5710223913192749e-01
    phi[9,6]  R2074     7.8933566808700562e-01
    phi[9,6]  R2075     -2.5540232658386230e+00
    phi[9,6]  R2076     -4.8328506946563721e-01
    phi[9,6]  R2077     -4.7625067830085754e-01
    phi[9,6]  R2078     -2.4598406255245209e-01
    phi[9,6]  R2079     1.6408972442150116e-02
    phi[9,6]  R2080     -4.8787850141525269e-01
    phi[9,6]  R2081     -0.416997492313385
    phi[9,6]  R2082     -7.3280632495880127e-01
    phi[9,6]  R2083     -6.1915236711502075e-01
    phi[9,6]  R2084     -1.5431900322437286e-01
    phi[9,6]  R2085     -2.2088640928268433e-01
    phi[9,6]  R2086     -6.1689329147338867e-01
    phi[9,6]  R2087     -1.4016860723495483e+00
    phi[9,6]  R2088     0.716096818447113
    phi[9,6]  R2089     -1.8152981996536255e+00
    phi[9,6]  R2090     -4.3602293729782104e-01
    phi[9,6]  R2091     -2.6896500587463379e-01
    phi[9,6]  R2092     -1.1633385419845581e+00
    phi[9,6]  R2093     -6.8402653932571411e-01
    phi[9,6]  R2094     -8.4457957744598389e-01
    phi[9,6]  R2095     -1.0135630369186401e+00
    phi[9,6]  R2096     -2.03751540184021
    phi[9,6]  R2097     -1.5284481048583984e+00
    phi[9,6]  R2098     -1.9574134349822998e+00
    phi[9,6]  R2099     -1.8773310184478760e+00
    phi[9,6]  R2100     -2.1419427394866943e+00
    phi[9,6]  R2101     -1.0630619525909424e+00
    phi[9,6]  R2102     3.5026636719703674e-01
    phi[9,6]  R2103     -3.2419508695602417e-01
    phi[9,6]  R2104     -3.7456721067428589e-02
    phi[9,6]  R2105     4.9300286173820496e-01
    phi[9,6]  R2106     -1.4489610195159912e+00
    phi[9,6]  R2107     -2.3869900703430176e+00
    phi[9,6]  R2108     -1.9708932638168335e+00
    phi[9,6]  R2109     -1.5119796991348267e+00
    phi[9,6]  R2110     -8.8546389341354370e-01
    phi[9,6]  R2111     -4.2762222886085510e-01
    phi[9,6]  R2112     -2.8716245293617249e-01
    phi[9,6]  R2113     -7.9392135143280029e-01
    phi[9,6]  R2114     -3.0480644106864929e-01
    phi[9,6]  R2115     -4.8553872108459473e-01
    phi[9,6]  R2116     1.8995443582534790e+00
    phi[9,6]  R2117     -9.8058871924877167e-02
    phi[9,6]  R2118     8.8887715339660645e-01
    phi[9,6]  R2119     1.6052172183990479e+00
    phi[9,6]  R2120     3.2450896501541138e-01
    phi[9,6]  R2121     3.9605379104614258e-01
    phi[9,6]  R2122     -2.2444821894168854e-01
    phi[9,6]  R2123     1.1835951805114746e+00
    phi[9,6]  R2124     -1.0702869296073914e-01
    phi[9,6]  R2125     7.2948426008224487e-01
    phi[9,6]  R2126     -2.2262823581695557e+00
    phi[9,6]  R2127     -2.9352024197578430e-01
    phi[9,6]  R2128     -9.8595410585403442e-01
    phi[9,6]  R2129     -1.54683256149292
    phi[9,6]  R2130     -2.09316349029541
    phi[9,6]  R2131     -1.6229231357574463e+00
    phi[9,6]  R2132     -1.0691384077072144e+00
    phi[9,6]  R2133     -2.3470537662506104e+00
    phi[9,6]  R2134     -2.6523220539093018e+00
    phi[9,6]  R2135     -2.0940120220184326e+00
    phi[9,6]  R2136     -5.4659098386764526e-01
    phi[9,6]  R2137     -2.2760362625122070e+00
    phi[9,6]  R2138     -1.0502289533615112e+00
    phi[9,6]  R2139     -1.44489586353302
    phi[9,6]  R2140     2.5122940540313721e-01
    phi[9,6]  R2141     -1.2394889593124390e+00
    phi[9,6]  R2142     -1.8778074979782104e+00
    phi[9,6]  R2143     -1.5595707893371582e+00
    phi[9,6]  R2144     -1.0592002868652344e+00
    phi[9,6]  R2145     -1.1280980110168457e+00
    phi[9,6]  R2146     -5.8078575134277344e-01
    phi[9,6]  R2147     -3.7194153666496277e-01
    phi[9,6]  R2148     -1.9900658130645752e+00
    phi[9,6]  R2149     -1.4523872137069702e+00
    phi[9,6]  R2150     -1.2675957679748535e+00
    phi[9,6]  R2151     2.3996865749359131e-01
    phi[9,6]  R2152     -2.4707953929901123e+00
    phi[9,6]  R2153     -1.5241569280624390e+00
    phi[9,6]  R2154     -3.5946995019912720e-01
    phi[9,6]  R2155     -1.1945325881242752e-01
    phi[6,11]  R54       1
    phi[6,11]  R55       1
    phi[6,11]  R56       0.788722811102132
    phi[6,11]  R57       -6.6991738554245606e-01
    phi[6,11]  R58       -1.4880616263057456e+00
    phi[6,11]  R59       1.2642929596650563e+00
    phi[6,11]  R60       -7.2314554216418525e-02
    phi[6,11]  R61       -1.0918912784859067e+00
    phi[6,11]  R62       -2.2962304549132955e+00
    phi[6,11]  R91       -1
    phi[6,11]  R2156     -2.3112770935304363e+00
    phi[6,11]  R2157     -3.8887227157347004e+00
    phi[6,11]  R2158     -2.9099173950791992e+00
    phi[6,11]  R2159     -1.5700826239942871e+00
    phi[6,11]  R2160     -4.5880615309383135e+00
    phi[6,11]  R2161     -1.6119382783268228e+00
    phi[6,11]  R2162     -1.3057069735777416e+00
    phi[6,11]  R2163     -3.8342928929078539e+00
    phi[6,11]  R2164     -3.1723144588489869e+00
    phi[6,11]  R2165     -3.02768535041615
    phi[6,11]  R2166     -3.1818911926552182e+00
    phi[6,11]  R2167     -9.9810863568340480e-01
    phi[6,11]  R2168     -5.3962303595458643e+00
    phi[6,11]  R2169     -8.0376944971927289e-01
    phi[6,11]  R2170     -9.5026710203434561e-02
    phi[6,11]  R2171     -2.6475922849414479e-01
    phi[6,11]  R2172     -6.2809101817796309e-02
    phi[6,11]  R2173     -1.6811590470836046e-01
    phi[6,11]  R2174     -2.1205113228254957e-01
    phi[6,11]  R2175     -2.1628614355795461e-01
    phi[6,11]  R2176     -2.1848019770095239e-01
    phi[6,11]  R2177     -2.2348122153417149e-01
    phi[6,11]  R2178     -0.28089405000022
    phi[6,11]  R2179     -3.1886306228756034e-01
    phi[6,11]  R2180     -1.6945874747502288e-01
    phi[6,11]  R2181     -1.9491970641058320e-01
    phi[6,11]  R2182     -2.1090402607154080e-01
    phi[6,11]  R2183     -2.1156386467522315e-01
    phi[6,11]  R2184     -2.7796740492224892e-01
    phi[6,11]  R2185     -2.8318884028591396e-01
    phi[6,11]  R2186     -2.8743235044481197e-01
    phi[6,11]  R2187     -2.9726536752390187e-01
    phi[6,11]  R2188     -3.3884634567285277e-01
    phi[6,11]  R2189     -4.5430293246846576e-01
    phi[6,11]  R2190     -8.3196803775248851e-02
    phi[6,11]  R2191     -4.1952701346098786e-01
    phi[6,11]  R2192     -2.8705553949814977e-01
    phi[6,11]  R2193     -1.6087360099541526e-01
    phi[6,11]  R2194     -1.3139204370471141e-01
    phi[6,11]  R2195     -1.4521931888303996e-01
    phi[6,11]  R2196     -1.4738056959495127e-01
    phi[6,11]  R2197     -1.4893148448484927e-01
    phi[6,11]  R2198     -1.5286994678033150e-01
    phi[6,11]  R2199     -1.6382859966114238e-01
    phi[6,11]  R2200     -6.1505672004019019e-02
    phi[6,11]  R2201     -1.2158440417373567e-01
    phi[6,11]  R2202     -1.5794842568720835e-01
    phi[6,11]  R2203     -2.0055440557804727e-01
    phi[6,11]  R2204     -2.0058708970895722e-01
    phi[6,11]  R2205     -2.0086735093313468e-01
    phi[6,11]  R2206     -2.0410041614613661e-01
    phi[6,11]  R2207     -2.0421477426000179e-01
    phi[6,11]  R2208     -2.1112554102221537e-01
    phi[6,11]  R2209     -2.1538258768030394e-01
    phi[7,8]  R63       1
    phi[7,8]  R64       1
    phi[7,8]  R72       -1
    phi[7,8]  R2210     -3.0999999046325684e+00
    phi[7,8]  R2211     -3.0999999046325684e+00
    phi[7,8]  R2212     -2.2400000095367432e+00
    phi[7,8]  R2213     -2.2400000095367432e+00
    phi[7,8]  R2214     -3.0999999046325684e+00
    phi[7,8]  R2215     -3.0999999046325684e+00
    phi[7,8]  R2216     -2.5699999332427979e+00
    phi[7,8]  R2217     -2.5699999332427979e+00
    phi[7,8]  R2218     -3.0999999046325684e+00
    phi[7,8]  R2219     -3.0999999046325684e+00
    phi[7,8]  R2220     -2.0899999141693115e+00
    phi[7,8]  R2221     -2.0899999141693115e+00
    phi[7,8]  R2222     -3.0999999046325684e+00
    phi[7,8]  R2223     -3.0999999046325684e+00
    phi[7,8]  R2224     1.7703909873962402e+00
    phi[7,8]  R2225     1.4271932840347290e+00
    phi[7,8]  R2226     2.03298282623291
    phi[7,8]  R2227     9.2722147703170776e-01
    phi[7,8]  R2228     1.0555876493453979e+00
    phi[7,8]  R2229     9.4596719741821289e-01
    phi[7,8]  R2230     -9.8126053810119629e-02
    phi[7,8]  R2231     8.9248466491699219e-01
    phi[7,8]  R2232     -2.1293966472148895e-01
    phi[7,8]  R2233     2.2604021430015564e-01
    phi[7,8]  R2234     -1.3818459510803223e+00
    phi[7,8]  R2235     -1.0415548086166382e+00
    phi[7,8]  R2236     -1.9686316251754761e+00
    phi[7,8]  R2237     -5.9821850061416626e-01
    phi[7,8]  R2238     -4.3241882324218750e-01
    phi[7,8]  R2239     -5.7898980379104614e-01
    phi[7,8]  R2240     -2.6958050727844238e+00
    phi[7,8]  R2241     -1.5797593593597412e+00
    phi[7,8]  R2242     -1.9584161043167114e+00
    phi[7,8]  R2243     -1.8934646844863892e+00
    phi[7,8]  R2244     -2.5175108909606934e+00
    phi[7,8]  R2245     -1.9551842212677002e+00
    phi[7,8]  R2246     -8.4858405590057373e-01
    phi[7,8]  R2247     -1.6719341278076172e+00
    phi[7,8]  R2248     -2.4382147789001465e+00
    phi[7,8]  R2249     -1.1550946235656738e+00
    phi[7,8]  R2250     -1.1460968255996704e+00
    phi[7,8]  R2251     -1.6403200626373291e+00
    phi[7,8]  R2252     -1.3433316946029663e+00
    phi[7,8]  R2253     -0.688581645488739
    phi[7,8]  R2254     -1.5594618320465088e+00
    phi[7,8]  R2255     -1.6825697422027588e+00
    phi[7,8]  R2256     1.2310864403843880e-03
    phi[7,8]  R2257     -8.7218195199966431e-01
    phi[7,8]  R2258     -1.1113963127136230e+00
    phi[7,8]  R2259     -2.6635712385177612e-01
    phi[7,8]  R2260     1.7014296352863312e-01
    phi[7,8]  R2261     -1.1135574579238892e+00
    phi[7,8]  R2262     -2.06619930267334
    phi[7,8]  R2263     1.8527619540691376e-01
    phi[7,8]  R2264     1.0851918458938599e+00
    phi[7,8]  R2265     7.9430508613586426e-01
    phi[7,8]  R2266     -1.8262483179569244e-01
    phi[7,8]  R2267     1.0446691513061523e+00
    phi[7,8]  R2268     6.6994005441665649e-01
    phi[7,8]  R2269     1.2349568605422974e+00
    phi[7,8]  R2270     -4.8155063390731812e-01
    phi[7,8]  R2271     1.5320324897766113e-01
    phi[7,8]  R2272     -4.4790914654731750e-01
    phi[7,8]  R2273     -1.7371711134910583e-01
    phi[7,8]  R2274     -2.3146750926971436e+00
    phi[7,8]  R2275     -4.1294717788696289e-01
    phi[7,8]  R2276     3.5104748606681824e-01
    phi[7,8]  R2277     -1.4386190474033356e-01
    phi[7,8]  R2278     -9.4538515806198120e-01
    phi[7,8]  R2279     -1.7054168507456779e-02
    phi[7,8]  R2280     -1.2027609348297119e+00
    phi[7,8]  R2281     -5.2112442255020142e-01
    phi[7,8]  R2282     -4.9178075790405273e-01
    phi[7,8]  R2283     -5.2963405847549438e-01
    phi[7,8]  R2284     -1.8925609588623047e+00
    phi[7,8]  R2285     -1.0294183492660522e+00
    phi[7,8]  R2286     -1.56235933303833
    phi[7,8]  R2287     -2.3867456912994385e+00
    phi[7,8]  R2288     -1.9220429658889771e+00
    phi[7,8]  R2289     -2.2119202613830566e+00
    phi[7,8]  R2290     -2.4857409000396729e+00
    phi[7,8]  R2291     -1.1096735298633575e-01
    phi[7,8]  R2292     -1.5483415126800537e+00
    phi[7,8]  R2293     -5.8789056539535522e-01
    phi[7,8]  R2294     2.4071514606475830e-01
    phi[7,8]  R2295     -2.9020297527313232e-01
    phi[7,8]  R2296     -1.6058403998613358e-03
    phi[7,8]  R2297     -7.6923334598541260e-01
    phi[7,8]  R2298     -1.2472302913665771e+00
    phi[7,8]  R2299     -1.0650407075881958e+00
    phi[7,8]  R2300     1.0581927001476288e-01
    phi[7,8]  R2301     -1.1356604099273682e+00
    phi[7,8]  R2302     -1.0166940689086914e+00
    phi[7,8]  R2303     -7.5970947742462158e-01
    phi[7,8]  R2304     -6.3250929117202759e-01
    phi[7,8]  R2305     -1.9953331947326660e+00
    phi[7,8]  R2306     1.1684216558933258e-01
    phi[7,8]  R2307     -1.3261359930038452e+00
    phi[7,8]  R2308     -8.6208456754684448e-01
    phi[7,8]  R2309     1.0603432655334473e+00
    phi[7,8]  R2310     -6.2094604969024658e-01
    phi[7,8]  R2311     1.0191992521286011e+00
    phi[7,8]  R2312     5.2774041891098022e-02
    phi[7,8]  R2313     1.0904344171285629e-01
    phi[7,8]  R2314     -1.9899421930313110e+00
    phi[7,8]  R2315     8.8306295871734619e-01
    phi[7,8]  R2316     -2.5801613330841064e+00
    phi[7,8]  R2317     -1.2673774957656860e+00
    phi[7,8]  R2318     -1.2558984756469727e+00
    phi[7,8]  R2319     1.0442696809768677e+00
    phi[7,8]  R2320     1.5314826369285583e-01
    phi[7,8]  R2321     -6.8095284700393677e-01
    phi[7,8]  R2322     1.6005283594131470e-01
    phi[7,8]  R2323     -3.1006821990013123e-01
    phi[8,7]  R63       -1
    phi[8,7]  R72       1
    phi[8,7]  R73       1
    phi[8,7]  R2324     -3.0999999046325684e+00
    phi[8,7]  R2325     -3.0999999046325684e+00
    phi[8,7]  R2326     -2.2400000095367432e+00
    phi[8,7]  R2327     -2.2400000095367432e+00
    phi[8,7]  R2328     -3.0999999046325684e+00
    phi[8,7]  R2329     -3.0999999046325684e+00
    phi[8,7]  R2330     -2.5699999332427979e+00
    phi[8,7]  R2331     -2.5699999332427979e+00
    phi[8,7]  R2332     -3.0999999046325684e+00
    phi[8,7]  R2333     -3.0999999046325684e+00
    phi[8,7]  R2334     -2.0899999141693115e+00
    phi[8,7]  R2335     -2.0899999141693115e+00
    phi[8,7]  R2336     -3.0999999046325684e+00
    phi[8,7]  R2337     -3.0999999046325684e+00
    phi[8,7]  R2338     1.0851918458938599e+00
    phi[8,7]  R2339     7.9430508613586426e-01
    phi[8,7]  R2340     -1.8262483179569244e-01
    phi[8,7]  R2341     1.0446691513061523e+00
    phi[8,7]  R2342     6.6994005441665649e-01
    phi[8,7]  R2343     1.2349568605422974e+00
    phi[8,7]  R2344     -4.8155063390731812e-01
    phi[8,7]  R2345     1.5320324897766113e-01
    phi[8,7]  R2346     -4.4790914654731750e-01
    phi[8,7]  R2347     -1.7371711134910583e-01
    phi[8,7]  R2348     -2.3146750926971436e+00
    phi[8,7]  R2349     -4.1294717788696289e-01
    phi[8,7]  R2350     3.5104748606681824e-01
    phi[8,7]  R2351     -1.4386190474033356e-01
    phi[8,7]  R2352     -9.4538515806198120e-01
    phi[8,7]  R2353     -1.7054168507456779e-02
    phi[8,7]  R2354     -1.2027609348297119e+00
    phi[8,7]  R2355     -5.2112442255020142e-01
    phi[8,7]  R2356     -4.9178075790405273e-01
    phi[8,7]  R2357     -5.2963405847549438e-01
    phi[8,7]  R2358     -1.8925609588623047e+00
    phi[8,7]  R2359     -1.0294183492660522e+00
    phi[8,7]  R2360     -1.56235933303833
    phi[8,7]  R2361     -2.3867456912994385e+00
    phi[8,7]  R2362     -1.9220429658889771e+00
    phi[8,7]  R2363     -2.2119202613830566e+00
    phi[8,7]  R2364     -2.4857409000396729e+00
    phi[8,7]  R2365     -1.1096735298633575e-01
    phi[8,7]  R2366     -1.5483415126800537e+00
    phi[8,7]  R2367     -5.8789056539535522e-01
    phi[8,7]  R2368     2.4071514606475830e-01
    phi[8,7]  R2369     -2.9020297527313232e-01
    phi[8,7]  R2370     -1.6058403998613358e-03
    phi[8,7]  R2371     -7.6923334598541260e-01
    phi[8,7]  R2372     -1.2472302913665771e+00
    phi[8,7]  R2373     -1.0650407075881958e+00
    phi[8,7]  R2374     1.0581927001476288e-01
    phi[8,7]  R2375     -1.1356604099273682e+00
    phi[8,7]  R2376     -1.0166940689086914e+00
    phi[8,7]  R2377     -7.5970947742462158e-01
    phi[8,7]  R2378     -6.3250929117202759e-01
    phi[8,7]  R2379     -1.9953331947326660e+00
    phi[8,7]  R2380     1.1684216558933258e-01
    phi[8,7]  R2381     -1.3261359930038452e+00
    phi[8,7]  R2382     -8.6208456754684448e-01
    phi[8,7]  R2383     1.0603432655334473e+00
    phi[8,7]  R2384     -6.2094604969024658e-01
    phi[8,7]  R2385     1.0191992521286011e+00
    phi[8,7]  R2386     5.2774041891098022e-02
    phi[8,7]  R2387     1.0904344171285629e-01
    phi[8,7]  R2388     -1.9899421930313110e+00
    phi[8,7]  R2389     8.8306295871734619e-01
    phi[8,7]  R2390     -2.5801613330841064e+00
    phi[8,7]  R2391     -1.2673774957656860e+00
    phi[8,7]  R2392     -1.2558984756469727e+00
    phi[8,7]  R2393     1.0442696809768677e+00
    phi[8,7]  R2394     1.5314826369285583e-01
    phi[8,7]  R2395     -6.8095284700393677e-01
    phi[8,7]  R2396     1.6005283594131470e-01
    phi[8,7]  R2397     -3.1006821990013123e-01
    phi[8,7]  R2398     1.7703909873962402e+00
    phi[8,7]  R2399     1.4271932840347290e+00
    phi[8,7]  R2400     2.03298282623291
    phi[8,7]  R2401     9.2722147703170776e-01
    phi[8,7]  R2402     1.0555876493453979e+00
    phi[8,7]  R2403     9.4596719741821289e-01
    phi[8,7]  R2404     -9.8126053810119629e-02
    phi[8,7]  R2405     8.9248466491699219e-01
    phi[8,7]  R2406     -2.1293966472148895e-01
    phi[8,7]  R2407     2.2604021430015564e-01
    phi[8,7]  R2408     -1.3818459510803223e+00
    phi[8,7]  R2409     -1.0415548086166382e+00
    phi[8,7]  R2410     -1.9686316251754761e+00
    phi[8,7]  R2411     -5.9821850061416626e-01
    phi[8,7]  R2412     -4.3241882324218750e-01
    phi[8,7]  R2413     -5.7898980379104614e-01
    phi[8,7]  R2414     -2.6958050727844238e+00
    phi[8,7]  R2415     -1.5797593593597412e+00
    phi[8,7]  R2416     -1.9584161043167114e+00
    phi[8,7]  R2417     -1.8934646844863892e+00
    phi[8,7]  R2418     -2.5175108909606934e+00
    phi[8,7]  R2419     -1.9551842212677002e+00
    phi[8,7]  R2420     -8.4858405590057373e-01
    phi[8,7]  R2421     -1.6719341278076172e+00
    phi[8,7]  R2422     -2.4382147789001465e+00
    phi[8,7]  R2423     -1.1550946235656738e+00
    phi[8,7]  R2424     -1.1460968255996704e+00
    phi[8,7]  R2425     -1.6403200626373291e+00
    phi[8,7]  R2426     -1.3433316946029663e+00
    phi[8,7]  R2427     -0.688581645488739
    phi[8,7]  R2428     -1.5594618320465088e+00
    phi[8,7]  R2429     -1.6825697422027588e+00
    phi[8,7]  R2430     1.2310864403843880e-03
    phi[8,7]  R2431     -8.7218195199966431e-01
    phi[8,7]  R2432     -1.1113963127136230e+00
    phi[8,7]  R2433     -2.6635712385177612e-01
    phi[8,7]  R2434     1.7014296352863312e-01
    phi[8,7]  R2435     -1.1135574579238892e+00
    phi[8,7]  R2436     -2.06619930267334
    phi[8,7]  R2437     1.8527619540691376e-01
    phi[8,9]  R72       1
    phi[8,9]  R73       1
    phi[8,9]  R81       -1
    phi[8,9]  R2438     -3.0999999046325684e+00
    phi[8,9]  R2439     -3.0999999046325684e+00
    phi[8,9]  R2440     -2.2400000095367432e+00
    phi[8,9]  R2441     -2.2400000095367432e+00
    phi[8,9]  R2442     -3.0999999046325684e+00
    phi[8,9]  R2443     -3.0999999046325684e+00
    phi[8,9]  R2444     -2.5699999332427979e+00
    phi[8,9]  R2445     -2.5699999332427979e+00
    phi[8,9]  R2446     -3.0999999046325684e+00
    phi[8,9]  R2447     -3.0999999046325684e+00
    phi[8,9]  R2448     -2.0899999141693115e+00
    phi[8,9]  R2449     -2.0899999141693115e+00
    phi[8,9]  R2450     -3.0999999046325684e+00
    phi[8,9]  R2451     -3.0999999046325684e+00
    phi[8,9]  R2452     1.0851918458938599e+00
    phi[8,9]  R2453     7.9430508613586426e-01
    phi[8,9]  R2454     -1.8262483179569244e-01
    phi[8,9]  R2455     1.0446691513061523e+00
    phi[8,9]  R2456     6.6994005441665649e-01
    phi[8,9]  R2457     1.2349568605422974e+00
    phi[8,9]  R2458     -4.8155063390731812e-01
    phi[8,9]  R2459     1.5320324897766113e-01
    phi[8,9]  R2460     -4.4790914654731750e-01
    phi[8,9]  R2461     -1.7371711134910583e-01
    phi[8,9]  R2462     -2.3146750926971436e+00
    phi[8,9]  R2463     -4.1294717788696289e-01
    phi[8,9]  R2464     3.5104748606681824e-01
    phi[8,9]  R2465     -1.4386190474033356e-01
    phi[8,9]  R2466     -9.4538515806198120e-01
    phi[8,9]  R2467     -1.7054168507456779e-02
    phi[8,9]  R2468     -1.2027609348297119e+00
    phi[8,9]  R2469     -5.2112442255020142e-01
    phi[8,9]  R2470     -4.9178075790405273e-01
    phi[8,9]  R2471     -5.2963405847549438e-01
    phi[8,9]  R2472     -1.8925609588623047e+00
    phi[8,9]  R2473     -1.0294183492660522e+00
    phi[8,9]  R2474     -1.56235933303833
    phi[8,9]  R2475     -2.3867456912994385e+00
    phi[8,9]  R2476     -1.9220429658889771e+00
    phi[8,9]  R2477     -2.2119202613830566e+00
    phi[8,9]  R2478     -2.4857409000396729e+00
    phi[8,9]  R2479     -1.1096735298633575e-01
    phi[8,9]  R2480     -1.5483415126800537e+00
    phi[8,9]  R2481     -5.8789056539535522e-01
    phi[8,9]  R2482     2.4071514606475830e-01
    phi[8,9]  R2483     -2.9020297527313232e-01
    phi[8,9]  R2484     -1.6058403998613358e-03
    phi[8,9]  R2485     -7.6923334598541260e-01
    phi[8,9]  R2486     -1.2472302913665771e+00
    phi[8,9]  R2487     -1.0650407075881958e+00
    phi[8,9]  R2488     1.0581927001476288e-01
    phi[8,9]  R2489     -1.1356604099273682e+00
    phi[8,9]  R2490     -1.0166940689086914e+00
    phi[8,9]  R2491     -7.5970947742462158e-01
    phi[8,9]  R2492     -6.3250929117202759e-01
    phi[8,9]  R2493     -1.9953331947326660e+00
    phi[8,9]  R2494     1.1684216558933258e-01
    phi[8,9]  R2495     -1.3261359930038452e+00
    phi[8,9]  R2496     -8.6208456754684448e-01
    phi[8,9]  R2497     1.0603432655334473e+00
    phi[8,9]  R2498     -6.2094604969024658e-01
    phi[8,9]  R2499     1.0191992521286011e+00
    phi[8,9]  R2500     5.2774041891098022e-02
    phi[8,9]  R2501     1.0904344171285629e-01
    phi[8,9]  R2502     -1.9899421930313110e+00
    phi[8,9]  R2503     8.8306295871734619e-01
    phi[8,9]  R2504     -2.5801613330841064e+00
    phi[8,9]  R2505     -1.2673774957656860e+00
    phi[8,9]  R2506     -1.2558984756469727e+00
    phi[8,9]  R2507     1.0442696809768677e+00
    phi[8,9]  R2508     1.5314826369285583e-01
    phi[8,9]  R2509     -6.8095284700393677e-01
    phi[8,9]  R2510     1.6005283594131470e-01
    phi[8,9]  R2511     -3.1006821990013123e-01
    phi[8,9]  R2512     -1.3770622014999390e+00
    phi[8,9]  R2513     5.6833225488662720e-01
    phi[8,9]  R2514     8.4544509649276733e-01
    phi[8,9]  R2515     -3.7393894791603088e-01
    phi[8,9]  R2516     8.0551540851593018e-01
    phi[8,9]  R2517     -7.3468881845474243e-01
    phi[8,9]  R2518     -2.46248722076416
    phi[8,9]  R2519     9.5710223913192749e-01
    phi[8,9]  R2520     7.8933566808700562e-01
    phi[8,9]  R2521     -2.5540232658386230e+00
    phi[8,9]  R2522     -4.8328506946563721e-01
    phi[8,9]  R2523     -4.7625067830085754e-01
    phi[8,9]  R2524     -2.4598406255245209e-01
    phi[8,9]  R2525     1.6408972442150116e-02
    phi[8,9]  R2526     -4.8787850141525269e-01
    phi[8,9]  R2527     -0.416997492313385
    phi[8,9]  R2528     -7.3280632495880127e-01
    phi[8,9]  R2529     -6.1915236711502075e-01
    phi[8,9]  R2530     -1.5431900322437286e-01
    phi[8,9]  R2531     -2.2088640928268433e-01
    phi[8,9]  R2532     -6.1689329147338867e-01
    phi[8,9]  R2533     -1.4016860723495483e+00
    phi[8,9]  R2534     0.716096818447113
    phi[8,9]  R2535     -1.8152981996536255e+00
    phi[8,9]  R2536     -4.3602293729782104e-01
    phi[8,9]  R2537     -2.6896500587463379e-01
    phi[8,9]  R2538     -1.1633385419845581e+00
    phi[8,9]  R2539     -6.8402653932571411e-01
    phi[8,9]  R2540     -8.4457957744598389e-01
    phi[8,9]  R2541     -1.0135630369186401e+00
    phi[8,9]  R2542     -2.03751540184021
    phi[8,9]  R2543     -1.5284481048583984e+00
    phi[8,9]  R2544     -1.9574134349822998e+00
    phi[8,9]  R2545     -1.8773310184478760e+00
    phi[8,9]  R2546     -2.1419427394866943e+00
    phi[8,9]  R2547     -1.0630619525909424e+00
    phi[8,9]  R2548     3.5026636719703674e-01
    phi[8,9]  R2549     -3.2419508695602417e-01
    phi[8,9]  R2550     -3.7456721067428589e-02
    phi[8,9]  R2551     4.9300286173820496e-01
    phi[8,9]  R2552     -1.4489610195159912e+00
    phi[8,9]  R2553     -2.3869900703430176e+00
    phi[8,9]  R2554     -1.9708932638168335e+00
    phi[8,9]  R2555     -1.5119796991348267e+00
    phi[8,9]  R2556     -8.8546389341354370e-01
    phi[8,9]  R2557     -4.2762222886085510e-01
    phi[8,9]  R2558     -2.8716245293617249e-01
    phi[8,9]  R2559     -7.9392135143280029e-01
    phi[8,9]  R2560     -3.0480644106864929e-01
    phi[8,9]  R2561     -4.8553872108459473e-01
    phi[9,8]  R72       -1
    phi[9,8]  R81       1
    phi[9,8]  R82       1
    phi[9,8]  R2562     -3.0999999046325684e+00
    phi[9,8]  R2563     -3.0999999046325684e+00
    phi[9,8]  R2564     -2.2400000095367432e+00
    phi[9,8]  R2565     -2.2400000095367432e+00
    phi[9,8]  R2566     -3.0999999046325684e+00
    phi[9,8]  R2567     -3.0999999046325684e+00
    phi[9,8]  R2568     -2.5699999332427979e+00
    phi[9,8]  R2569     -2.5699999332427979e+00
    phi[9,8]  R2570     -3.0999999046325684e+00
    phi[9,8]  R2571     -3.0999999046325684e+00
    phi[9,8]  R2572     -2.0899999141693115e+00
    phi[9,8]  R2573     -2.0899999141693115e+00
    phi[9,8]  R2574     -3.0999999046325684e+00
    phi[9,8]  R2575     -3.0999999046325684e+00
    phi[9,8]  R2576     -1.3770622014999390e+00
    phi[9,8]  R2577     5.6833225488662720e-01
    phi[9,8]  R2578     8.4544509649276733e-01
    phi[9,8]  R2579     -3.7393894791603088e-01
    phi[9,8]  R2580     8.0551540851593018e-01
    phi[9,8]  R2581     -7.3468881845474243e-01
    phi[9,8]  R2582     -2.46248722076416
    phi[9,8]  R2583     9.5710223913192749e-01
    phi[9,8]  R2584     7.8933566808700562e-01
    phi[9,8]  R2585     -2.5540232658386230e+00
    phi[9,8]  R2586     -4.8328506946563721e-01
    phi[9,8]  R2587     -4.7625067830085754e-01
    phi[9,8]  R2588     -2.4598406255245209e-01
    phi[9,8]  R2589     1.6408972442150116e-02
    phi[9,8]  R2590     -4.8787850141525269e-01
    phi[9,8]  R2591     -0.416997492313385
    phi[9,8]  R2592     -7.3280632495880127e-01
    phi[9,8]  R2593     -6.1915236711502075e-01
    phi[9,8]  R2594     -1.5431900322437286e-01
    phi[9,8]  R2595     -2.2088640928268433e-01
    phi[9,8]  R2596     -6.1689329147338867e-01
    phi[9,8]  R2597     -1.4016860723495483e+00
    phi[9,8]  R2598     0.716096818447113
    phi[9,8]  R2599     -1.8152981996536255e+00
    phi[9,8]  R2600     -4.3602293729782104e-01
    phi[9,8]  R2601     -2.6896500587463379e-01
    phi[9,8]  R2602     -1.1633385419845581e+00
    phi[9,8]  R2603     -6.8402653932571411e-01
    phi[9,8]  R2604     -8.4457957744598389e-01
    phi[9,8]  R2605     -1.0135630369186401e+00
    phi[9,8]  R2606     -2.03751540184021
    phi[9,8]  R2607     -1.5284481048583984e+00
    phi[9,8]  R2608     -1.9574134349822998e+00
    phi[9,8]  R2609     -1.8773310184478760e+00
    phi[9,8]  R2610     -2.1419427394866943e+00
    phi[9,8]  R2611     -1.0630619525909424e+00
    phi[9,8]  R2612     3.5026636719703674e-01
    phi[9,8]  R2613     -3.2419508695602417e-01
    phi[9,8]  R2614     -3.7456721067428589e-02
    phi[9,8]  R2615     4.9300286173820496e-01
    phi[9,8]  R2616     -1.4489610195159912e+00
    phi[9,8]  R2617     -2.3869900703430176e+00
    phi[9,8]  R2618     -1.9708932638168335e+00
    phi[9,8]  R2619     -1.5119796991348267e+00
    phi[9,8]  R2620     -8.8546389341354370e-01
    phi[9,8]  R2621     -4.2762222886085510e-01
    phi[9,8]  R2622     -2.8716245293617249e-01
    phi[9,8]  R2623     -7.9392135143280029e-01
    phi[9,8]  R2624     -3.0480644106864929e-01
    phi[9,8]  R2625     -4.8553872108459473e-01
    phi[9,8]  R2626     1.0851918458938599e+00
    phi[9,8]  R2627     7.9430508613586426e-01
    phi[9,8]  R2628     -1.8262483179569244e-01
    phi[9,8]  R2629     1.0446691513061523e+00
    phi[9,8]  R2630     6.6994005441665649e-01
    phi[9,8]  R2631     1.2349568605422974e+00
    phi[9,8]  R2632     -4.8155063390731812e-01
    phi[9,8]  R2633     1.5320324897766113e-01
    phi[9,8]  R2634     -4.4790914654731750e-01
    phi[9,8]  R2635     -1.7371711134910583e-01
    phi[9,8]  R2636     -2.3146750926971436e+00
    phi[9,8]  R2637     -4.1294717788696289e-01
    phi[9,8]  R2638     3.5104748606681824e-01
    phi[9,8]  R2639     -1.4386190474033356e-01
    phi[9,8]  R2640     -9.4538515806198120e-01
    phi[9,8]  R2641     -1.7054168507456779e-02
    phi[9,8]  R2642     -1.2027609348297119e+00
    phi[9,8]  R2643     -5.2112442255020142e-01
    phi[9,8]  R2644     -4.9178075790405273e-01
    phi[9,8]  R2645     -5.2963405847549438e-01
    phi[9,8]  R2646     -1.8925609588623047e+00
    phi[9,8]  R2647     -1.0294183492660522e+00
    phi[9,8]  R2648     -1.56235933303833
    phi[9,8]  R2649     -2.3867456912994385e+00
    phi[9,8]  R2650     -1.9220429658889771e+00
    phi[9,8]  R2651     -2.2119202613830566e+00
    phi[9,8]  R2652     -2.4857409000396729e+00
    phi[9,8]  R2653     -1.1096735298633575e-01
    phi[9,8]  R2654     -1.5483415126800537e+00
    phi[9,8]  R2655     -5.8789056539535522e-01
    phi[9,8]  R2656     2.4071514606475830e-01
    phi[9,8]  R2657     -2.9020297527313232e-01
    phi[9,8]  R2658     -1.6058403998613358e-03
    phi[9,8]  R2659     -7.6923334598541260e-01
    phi[9,8]  R2660     -1.2472302913665771e+00
    phi[9,8]  R2661     -1.0650407075881958e+00
    phi[9,8]  R2662     1.0581927001476288e-01
    phi[9,8]  R2663     -1.1356604099273682e+00
    phi[9,8]  R2664     -1.0166940689086914e+00
    phi[9,8]  R2665     -7.5970947742462158e-01
    phi[9,8]  R2666     -6.3250929117202759e-01
    phi[9,8]  R2667     -1.9953331947326660e+00
    phi[9,8]  R2668     1.1684216558933258e-01
    phi[9,8]  R2669     -1.3261359930038452e+00
    phi[9,8]  R2670     -8.6208456754684448e-01
    phi[9,8]  R2671     1.0603432655334473e+00
    phi[9,8]  R2672     -6.2094604969024658e-01
    phi[9,8]  R2673     1.0191992521286011e+00
    phi[9,8]  R2674     5.2774041891098022e-02
    phi[9,8]  R2675     1.0904344171285629e-01
    phi[9,8]  R2676     -1.9899421930313110e+00
    phi[9,8]  R2677     8.8306295871734619e-01
    phi[9,8]  R2678     -2.5801613330841064e+00
    phi[9,8]  R2679     -1.2673774957656860e+00
    phi[9,8]  R2680     -1.2558984756469727e+00
    phi[9,8]  R2681     1.0442696809768677e+00
    phi[9,8]  R2682     1.5314826369285583e-01
    phi[9,8]  R2683     -6.8095284700393677e-01
    phi[9,8]  R2684     1.6005283594131470e-01
    phi[9,8]  R2685     -3.1006821990013123e-01
    phi[9,11]  R81       1
    phi[9,11]  R82       1
    phi[9,11]  R83       0.788722811102132
    phi[9,11]  R84       -6.6991738554245606e-01
    phi[9,11]  R85       -1.4880616263057456e+00
    phi[9,11]  R86       1.2642929596650563e+00
    phi[9,11]  R87       -7.2314554216418525e-02
    phi[9,11]  R88       -1.0918912784859067e+00
    phi[9,11]  R89       -2.2962304549132955e+00
    phi[9,11]  R91       -1
    phi[9,11]  R2686     -2.3112770935304363e+00
    phi[9,11]  R2687     -3.8887227157347004e+00
    phi[9,11]  R2688     -2.9099173950791992e+00
    phi[9,11]  R2689     -1.5700826239942871e+00
    phi[9,11]  R2690     -4.5880615309383135e+00
    phi[9,11]  R2691     -1.6119382783268228e+00
    phi[9,11]  R2692     -1.3057069735777416e+00
    phi[9,11]  R2693     -3.8342928929078539e+00
    phi[9,11]  R2694     -3.1723144588489869e+00
    phi[9,11]  R2695     -3.02768535041615
    phi[9,11]  R2696     -3.1818911926552182e+00
    phi[9,11]  R2697     -9.9810863568340480e-01
    phi[9,11]  R2698     -5.3962303595458643e+00
    phi[9,11]  R2699     -8.0376944971927289e-01
    phi[9,11]  R2700     -1.6387395917451864e-01
    phi[9,11]  R2701     -1.7153607329272258e-01
    phi[9,11]  R2702     -1.7696736066020735e-01
    phi[9,11]  R2703     -1.9131744208581922e-01
    phi[9,11]  R2704     -1.9177378907587805e-01
    phi[9,11]  R2705     -1.9294813231026819e-01
    phi[9,11]  R2706     -1.9424925368933410e-01
    phi[9,11]  R2707     -1.9587889673041348e-01
    phi[9,11]  R2708     -1.9749584089146954e-01
    phi[9,11]  R2709     -1.9752942168914167e-01
    phi[9,11]  R2710     -1.2406665039119067e+00
    phi[9,11]  R2711     -1.9211418369434443e+00
    phi[9,11]  R2712     -1.3976452313851226e+00
    phi[9,11]  R2713     -3.8003093485037348e-01
    phi[9,11]  R2714     -1.5098651276382486e+00
    phi[9,11]  R2715     -1.0116743985862753e+00
    phi[9,11]  R2716     -1.9343335076803454e+00
    phi[9,11]  R2717     -1.9070390133377950e+00
    phi[9,11]  R2718     -1.0428964062733512e+00
    phi[9,11]  R2719     -1.0637595982709902e+00
    phi[9,11]  R2720     -2.3256207704685283e-01
    phi[9,11]  R2721     -2.6806183927411853e-01
    phi[9,11]  R2722     -2.9063435102104229e-01
    phi[9,11]  R2723     -3.0639250297427556e-01
    phi[9,11]  R2724     -3.1336270234138563e-01
    phi[9,11]  R2725     -3.3534671748859046e-01
    phi[9,11]  R2726     -0.556170478782212
    phi[9,11]  R2727     -5.6761584024201972e-01
    phi[9,11]  R2728     -5.7579088223334951e-01
    phi[9,11]  R2729     -5.9657636179449725e-01
    phi[9,11]  R2730     -0.211481760599459
    phi[9,11]  R2731     -2.3401164756806381e-01
    phi[9,11]  R2732     -2.4779282675753267e-01
    phi[9,11]  R2733     -2.6381482419427549e-01
    phi[9,11]  R2734     -0.299232550947941
    phi[9,11]  R2735     -3.5192695440773059e-01
    phi[9,11]  R2736     -4.0597183710793483e-01
    phi[9,11]  R2737     -0.419133261564248
    phi[9,11]  R2738     -4.7354799572019518e-01
    phi[9,11]  R2739     -4.7690386032563314e-01
    phi[9,11]  R2740     -1.7620283404631643e-01
    phi[9,11]  R2741     -2.3051379653159731e-01
    phi[9,11]  R2742     -2.3833823991241543e-01
    phi[9,11]  R2743     -2.7791827727218732e-01
    phi[9,11]  R2744     -3.2779996468125105e-01
    phi[9,11]  R2745     -1.0803108450723049e+00
    phi[9,11]  R2746     -4.3125597185637193e-01
    phi[9,11]  R2747     -4.3578704900451615e-01
    phi[9,11]  R2748     -4.6238517162303872e-01
    phi[9,11]  R2749     -4.7213996948348558e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R92       -1
    z[0,1,0]  R93       1
    z[0,1,0]  R106      0.620798647403717
    z[0,1,0]  R107      5.2654927968978882e-01
    z[0,1,0]  R108      0.462368905544281
    z[0,1,0]  R109      1.3268569111824036e-01
    z[0,1,0]  R110      1.5740792453289032e-01
    z[0,1,0]  R111      -1.3772873580455780e-01
    z[0,1,0]  R112      5.1359629631042480e-01
    z[0,1,0]  R113      1.8717673420906067e-01
    z[0,1,0]  R114      7.0190334320068359e-01
    z[0,1,0]  R115      -1.2152490764856339e-01
    z[0,1,0]  R116      -3.8810375332832336e-01
    z[0,1,0]  R117      -1.6573785245418549e-01
    z[0,1,0]  R118      -3.1329813599586487e-01
    z[0,1,0]  R119      -3.6065387725830078e-01
    z[0,1,0]  R120      -1.4641138911247253e-01
    z[0,1,0]  R121      -3.8380718231201172e-01
    z[0,1,0]  R122      -1.9463101029396057e-01
    z[0,1,0]  R123      -2.1786668896675110e-01
    z[0,1,0]  R124      -3.5266622900962830e-01
    z[0,1,0]  R125      1.3635067641735077e-01
    z[0,1,0]  R126      -4.0896780788898468e-02
    z[0,1,0]  R127      -1.0298158973455429e-01
    z[0,1,0]  R128      -2.5520476698875427e-01
    z[0,1,0]  R129      -4.1922938078641891e-02
    z[0,1,0]  R130      -5.3105160593986511e-02
    z[0,1,0]  R131      2.2029291093349457e-01
    z[0,1,0]  R132      -1.6303269565105438e-01
    z[0,1,0]  R133      4.5278385281562805e-01
    z[0,1,0]  R134      3.0736759305000305e-01
    z[0,1,0]  R135      2.5611084699630737e-01
    z[0,1,0]  R136      1.6221153736114502e-01
    z[0,1,0]  R137      1.0434409230947495e-01
    z[0,1,0]  R138      -1.9514784216880798e-01
    z[0,1,0]  R139      2.0719854533672333e-01
    z[0,1,0]  R140      -4.5424412935972214e-02
    z[0,1,0]  R141      -5.9812828898429871e-02
    z[0,1,0]  R142      1.2708221375942230e-01
    z[0,1,0]  R143      4.8202324658632278e-02
    z[0,1,0]  R144      4.0944972634315491e-01
    z[0,1,0]  R145      9.1523610055446625e-02
    z[0,1,0]  R146      4.2951118946075439e-01
    z[0,1,0]  R147      -3.9567712694406509e-02
    z[0,1,0]  R148      -3.1187409535050392e-02
    z[0,1,0]  R149      7.9985029995441437e-02
    z[0,1,0]  R150      4.0240153670310974e-01
    z[0,1,0]  R151      2.4220819771289825e-01
    z[0,1,0]  R152      -0.302153080701828
    z[0,1,0]  R153      2.0053511857986450e-01
    z[0,1,0]  R154      -2.2063534706830978e-02
    z[0,1,0]  R155      -2.2748107090592384e-02
    z[0,1,0]  R156      2.3923364281654358e-01
    z[0,1,0]  R157      2.6735377311706543e-01
    z[0,1,0]  R158      2.5035685300827026e-01
    z[0,1,0]  R159      -1.0845737904310226e-01
    z[0,1,0]  R160      7.5069174170494080e-02
    z[0,1,0]  R161      -5.2948564291000366e-02
    z[0,1,0]  R162      3.5006088018417358e-01
    z[0,1,0]  R163      -2.5894674658775330e-01
    z[0,1,0]  R164      -2.6131308078765869e-01
    z[0,1,0]  R165      -1.0611040890216827e-01
    z[0,1,0]  R166      5.6712478399276733e-01
    z[0,1,0]  R167      5.7326781749725342e-01
    z[0,1,0]  R168      3.5377502441406250e-01
    z[0,1,0]  R169      6.1590307950973511e-01
    z[0,1,0]  R170      3.1329560279846191e-01
    z[0,1,0]  R171      4.0936514735221863e-01
    z[0,1,0]  R172      1.7265732586383820e-01
    z[0,1,0]  R173      2.4288158118724823e-01
    z[0,1,0]  R174      2.0638771355152130e-01
    z[0,1,0]  R175      0.621462345123291
    z[0,1,0]  R176      -5.0725597143173218e-01
    z[0,1,0]  R177      -4.5115393400192261e-01
    z[0,1,0]  R178      -7.2730302810668945e-01
    z[0,1,0]  R179      -4.6807822585105896e-01
    z[0,1,0]  R180      -7.8397506475448608e-01
    z[0,1,0]  R181      -3.0847826600074768e-01
    z[0,1,0]  R182      -2.0180958509445190e-01
    z[0,1,0]  R183      -4.7805258631706238e-01
    z[0,1,0]  R184      -4.5329952239990234e-01
    z[0,1,0]  R185      -3.3067616820335388e-01
    z[0,1,0]  R186      -2.8777632117271423e-01
    z[0,1,0]  R187      3.1904092431068420e-01
    z[0,1,0]  R188      -5.8472013473510742e-01
    z[0,1,0]  R189      -1.1177876591682434e-01
    z[0,1,0]  R190      1.5771120786666870e-01
    z[0,1,0]  R191      -1.2083274126052856e-01
    z[0,1,0]  R192      -3.0223888158798218e-01
    z[0,1,0]  R193      -4.8529732227325439e-01
    z[0,1,0]  R194      1.0204591602087021e-01
    z[0,1,0]  R195      1.7605938017368317e-01
    z[0,1,0]  R196      3.5676565766334534e-01
    z[0,1,0]  R197      6.0027921199798584e-01
    z[0,1,0]  R198      -2.0596690475940704e-01
    z[0,1,0]  R199      -1.1497341096401215e-01
    z[0,1,0]  R200      -1.2827318906784058e-01
    z[0,1,0]  R201      2.9592707753181458e-01
    z[0,1,0]  R202      -4.6516966074705124e-02
    z[0,1,0]  R203      -1.7297618091106415e-01
    z[0,1,0]  R204      2.1709685027599335e-01
    z[0,1,0]  R205      2.8099268674850464e-01
    z[0,1,0]  R206      4.5194447040557861e-01
    z[0,1,0]  R207      1.7751461267471313e-01
    z[0,1,0]  R208      2.8391501307487488e-01
    z[0,1,0]  R209      -0.141950786113739
    z[0,1,0]  R210      -2.7992233633995056e-01
    z[0,1,0]  R211      -2.6550477743148804e-01
    z[0,1,0]  R212      -1.6600802540779114e-02
    z[0,1,0]  R213      -9.8987082019448280e-03
    z[0,1,0]  R214      -2.7718076109886169e-01
    z[0,1,0]  R215      -2.1165333688259125e-01
    z[0,1,0]  R216      -1.7723931372165680e-01
    z[0,1,0]  R217      8.8512469083070755e-03
    z[0,1,0]  R218      1.0552880913019180e-01
    z[0,1,0]  R219      -2.0274975895881653e-01
    z[0,1,0]  R220      -6.2486010789871216e-01
    z[0,1,0]  R221      -4.3374547362327576e-01
    z[0,1,0]  R222      -5.0168428570032120e-03
    z[0,1,0]  R223      -6.3746839761734009e-01
    z[0,1,0]  R224      -3.2313367724418640e-01
    z[0,1,0]  R225      3.9484769105911255e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R94       -1
    z[0,1,1]  R95       1
    z[0,1,1]  R106      -5.2527648210525513e-01
    z[0,1,1]  R107      -7.6045840978622437e-01
    z[0,1,1]  R108      -2.5633433461189270e-01
    z[0,1,1]  R109      -8.1234443187713623e-01
    z[0,1,1]  R110      -5.2500879764556885e-01
    z[0,1,1]  R111      -8.3281147480010986e-01
    z[0,1,1]  R112      -4.5282069593667984e-02
    z[0,1,1]  R113      -6.6825169324874878e-01
    z[0,1,1]  R114      9.4174752011895180e-03
    z[0,1,1]  R115      -4.4155597686767578e-01
    z[0,1,1]  R116      0.336871862411499
    z[0,1,1]  R117      4.4043898582458496e-01
    z[0,1,1]  R118      5.4839485883712769e-01
    z[0,1,1]  R119      2.0966002345085144e-01
    z[0,1,1]  R120      3.0229339003562927e-01
    z[0,1,1]  R121      3.9771580696105957e-01
    z[0,1,1]  R122      2.9277262091636658e-01
    z[0,1,1]  R123      2.0392750203609467e-01
    z[0,1,1]  R124      4.5268815755844116e-01
    z[0,1,1]  R125      5.1453071832656860e-01
    z[0,1,1]  R126      1.6954012215137482e-01
    z[0,1,1]  R127      -4.2636382579803467e-01
    z[0,1,1]  R128      4.4002529978752136e-01
    z[0,1,1]  R129      6.4283883571624756e-01
    z[0,1,1]  R130      -6.4902478456497192e-01
    z[0,1,1]  R131      -7.3591619729995728e-01
    z[0,1,1]  R132      1.1351312696933746e-01
    z[0,1,1]  R133      -6.2721645832061768e-01
    z[0,1,1]  R134      -0.582633376121521
    z[0,1,1]  R135      -6.8468379974365234e-01
    z[0,1,1]  R136      1.4159551262855530e-01
    z[0,1,1]  R137      4.7614101320505142e-02
    z[0,1,1]  R138      4.0677130222320557e-01
    z[0,1,1]  R139      3.2636293768882751e-01
    z[0,1,1]  R140      4.5732742547988892e-01
    z[0,1,1]  R141      -7.8393936157226562e-01
    z[0,1,1]  R142      6.3165462017059326e-01
    z[0,1,1]  R143      -9.3769985437393188e-01
    z[0,1,1]  R144      -8.0721575021743774e-01
    z[0,1,1]  R145      -5.4238897562026978e-01
    z[0,1,1]  R146      2.5861972570419312e-01
    z[0,1,1]  R147      -9.6798247098922729e-01
    z[0,1,1]  R148      -6.7429274320602417e-01
    z[0,1,1]  R149      -7.2020101547241211e-01
    z[0,1,1]  R150      2.9705107212066650e-01
    z[0,1,1]  R151      3.9390709996223450e-01
    z[0,1,1]  R152      1.5610887110233307e-01
    z[0,1,1]  R153      -4.3803668022155762e-01
    z[0,1,1]  R154      -4.0859362483024597e-01
    z[0,1,1]  R155      -6.4626979827880859e-01
    z[0,1,1]  R156      -2.8822859749197960e-02
    z[0,1,1]  R157      -1.3212330639362335e-01
    z[0,1,1]  R158      -4.8857319355010986e-01
    z[0,1,1]  R159      2.1396249532699585e-01
    z[0,1,1]  R160      -6.9400328397750854e-01
    z[0,1,1]  R161      3.4333273768424988e-01
    z[0,1,1]  R162      -4.4806605577468872e-01
    z[0,1,1]  R163      -4.6262946724891663e-01
    z[0,1,1]  R164      -3.0958941578865051e-01
    z[0,1,1]  R165      -1.9974282383918762e-01
    z[0,1,1]  R166      -7.1999573707580566e-01
    z[0,1,1]  R167      -3.5951447486877441e-01
    z[0,1,1]  R168      -5.4621613025665283e-01
    z[0,1,1]  R169      -1.6242490708827972e-01
    z[0,1,1]  R170      -4.4142702221870422e-01
    z[0,1,1]  R171      -2.7157762646675110e-01
    z[0,1,1]  R172      -5.8418369293212891e-01
    z[0,1,1]  R173      -5.1755124330520630e-01
    z[0,1,1]  R174      -0.0967964380979538
    z[0,1,1]  R175      -1.8083013594150543e-01
    z[0,1,1]  R176      0.252617210149765
    z[0,1,1]  R177      1.4443641901016235e-01
    z[0,1,1]  R178      1.6302208602428436e-01
    z[0,1,1]  R179      2.6922336220741272e-01
    z[0,1,1]  R180      -5.7934081554412842e-01
    z[0,1,1]  R181      -6.4178925752639771e-01
    z[0,1,1]  R182      4.4595742225646973e-01
    z[0,1,1]  R183      -4.1689127683639526e-01
    z[0,1,1]  R184      1.3225845992565155e-01
    z[0,1,1]  R185      -4.0894353389739990e-01
    z[0,1,1]  R186      2.6005470752716064e-01
    z[0,1,1]  R187      2.8158989548683167e-01
    z[0,1,1]  R188      1.1962978541851044e-01
    z[0,1,1]  R189      6.8216927349567413e-02
    z[0,1,1]  R190      3.1921774148941040e-01
    z[0,1,1]  R191      -3.2574182748794556e-01
    z[0,1,1]  R192      2.5507461279630661e-02
    z[0,1,1]  R193      -8.6136408150196075e-02
    z[0,1,1]  R194      7.0345389842987061e-01
    z[0,1,1]  R195      7.4947863817214966e-01
    z[0,1,1]  R196      3.0610787868499756e-01
    z[0,1,1]  R197      -2.9526799917221069e-01
    z[0,1,1]  R198      -1.3627997040748596e-01
    z[0,1,1]  R199      -4.7529456019401550e-01
    z[0,1,1]  R200      -7.9015719890594482e-01
    z[0,1,1]  R201      4.8739153146743774e-01
    z[0,1,1]  R202      -7.3559558391571045e-01
    z[0,1,1]  R203      -5.5131548643112183e-01
    z[0,1,1]  R204      -4.9255535006523132e-01
    z[0,1,1]  R205      4.8768538236618042e-01
    z[0,1,1]  R206      -2.4818757176399231e-01
    z[0,1,1]  R207      -7.0166671276092529e-01
    z[0,1,1]  R208      -1.6952741146087646e-01
    z[0,1,1]  R209      -1.9266216456890106e-01
    z[0,1,1]  R210      4.8682785034179688e-01
    z[0,1,1]  R211      4.3564680218696594e-01
    z[0,1,1]  R212      5.3933960199356079e-01
    z[0,1,1]  R213      4.3277230858802795e-01
    z[0,1,1]  R214      5.5286341905593872e-01
    z[0,1,1]  R215      -0.690163791179657
    z[0,1,1]  R216      -0.218377947807312
    z[0,1,1]  R217      -6.0111218690872192e-01
    z[0,1,1]  R218      -1.8813097476959229e-01
    z[0,1,1]  R219      -6.2833160161972046e-01
    z[0,1,1]  R220      1.2874330580234528e-01
    z[0,1,1]  R221      1.2565034627914429e-01
    z[0,1,1]  R222      -6.9239699840545654e-01
    z[0,1,1]  R223      -9.4848774373531342e-02
    z[0,1,1]  R224      -3.7407833337783813e-01
    z[0,1,1]  R225      6.4214813709259033e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R96       -1
    z[0,1,2]  R97       1
    z[0,1,2]  R106      2.8240248560905457e-01
    z[0,1,2]  R107      0.145859956741333
    z[0,1,2]  R108      -4.8697876930236816e-01
    z[0,1,2]  R109      4.4901812076568604e-01
    z[0,1,2]  R110      0.73260498046875
    z[0,1,2]  R111      2.6689371466636658e-01
    z[0,1,2]  R112      6.9678300619125366e-01
    z[0,1,2]  R113      -6.3427609205245972e-01
    z[0,1,2]  R114      -4.9273434281349182e-01
    z[0,1,2]  R115      2.7878072857856750e-01
    z[0,1,2]  R116      2.7123796939849854e-01
    z[0,1,2]  R117      3.3787584304809570e-01
    z[0,1,2]  R118      4.5626482367515564e-01
    z[0,1,2]  R119      5.3327459096908569e-01
    z[0,1,2]  R120      2.6201978325843811e-01
    z[0,1,2]  R121      2.1138642728328705e-01
    z[0,1,2]  R122      1.2170034646987915e-01
    z[0,1,2]  R123      -7.8172661364078522e-02
    z[0,1,2]  R124      -2.7911770343780518e-01
    z[0,1,2]  R125      -3.5881170630455017e-01
    z[0,1,2]  R126      -3.0714237689971924e-01
    z[0,1,2]  R127      -4.1826552152633667e-01
    z[0,1,2]  R128      -6.2289965152740479e-01
    z[0,1,2]  R129      -6.6303437948226929e-01
    z[0,1,2]  R130      -2.7375000715255737e-01
    z[0,1,2]  R131      -1.0064578801393509e-01
    z[0,1,2]  R132      -7.7345591783523560e-01
    z[0,1,2]  R133      -1.1731107532978058e-01
    z[0,1,2]  R134      -3.5247454047203064e-01
    z[0,1,2]  R135      -6.3121385872364044e-02
    z[0,1,2]  R136      -9.9313713610172272e-02
    z[0,1,2]  R137      -8.2837289571762085e-01
    z[0,1,2]  R138      -8.0990833044052124e-01
    z[0,1,2]  R139      -5.9784799814224243e-01
    z[0,1,2]  R140      -5.1879543066024780e-01
    z[0,1,2]  R141      -3.8309359550476074e-01
    z[0,1,2]  R142      -4.7910192608833313e-01
    z[0,1,2]  R143      -4.6313893049955368e-02
    z[0,1,2]  R144      1.7006424069404602e-01
    z[0,1,2]  R145      1.9337338209152222e-01
    z[0,1,2]  R146      -1.1138269305229187e-01
    z[0,1,2]  R147      -1.0139747709035873e-01
    z[0,1,2]  R148      -6.2791548669338226e-02
    z[0,1,2]  R149      -8.6022213101387024e-02
    z[0,1,2]  R150      3.9707577228546143e-01
    z[0,1,2]  R151      6.3471257686614990e-01
    z[0,1,2]  R152      -6.6998451948165894e-01
    z[0,1,2]  R153      5.1057374477386475e-01
    z[0,1,2]  R154      4.7518399357795715e-01
    z[0,1,2]  R155      -5.5646121501922607e-02
    z[0,1,2]  R156      2.1809941530227661e-01
    z[0,1,2]  R157      -6.7226584069430828e-03
    z[0,1,2]  R158      1.0934574529528618e-02
    z[0,1,2]  R159      5.5326181463897228e-03
    z[0,1,2]  R160      -2.4967899918556213e-01
    z[0,1,2]  R161      7.6059329509735107e-01
    z[0,1,2]  R162      4.9448895454406738e-01
    z[0,1,2]  R163      4.0338733792304993e-01
    z[0,1,2]  R164      3.7548035383224487e-01
    z[0,1,2]  R165      0.501044511795044
    z[0,1,2]  R166      1.5428924560546875e-01
    z[0,1,2]  R167      4.0962803363800049e-01
    z[0,1,2]  R168      6.6589558124542236e-01
    z[0,1,2]  R169      -5.7522392272949219e-01
    z[0,1,2]  R170      -5.7281100749969482e-01
    z[0,1,2]  R171      -2.7774125337600708e-01
    z[0,1,2]  R172      5.6136876344680786e-01
    z[0,1,2]  R173      3.6103519797325134e-01
    z[0,1,2]  R174      1.8868075311183929e-01
    z[0,1,2]  R175      2.1593287587165833e-01
    z[0,1,2]  R176      7.1879738569259644e-01
    z[0,1,2]  R177      3.8259690999984741e-01
    z[0,1,2]  R178      2.4863047897815704e-01
    z[0,1,2]  R179      4.0550294518470764e-01
    z[0,1,2]  R180      -9.4124749302864075e-02
    z[0,1,2]  R181      -4.7052997350692749e-01
    z[0,1,2]  R182      -0.661577045917511
    z[0,1,2]  R183      -2.0283532142639160e-01
    z[0,1,2]  R184      -3.4149882197380066e-01
    z[0,1,2]  R185      -8.9774593710899353e-02
    z[0,1,2]  R186      -7.1543413400650024e-01
    z[0,1,2]  R187      -5.2829998731613159e-01
    z[0,1,2]  R188      -5.0700902938842773e-01
    z[0,1,2]  R189      -1.2854686379432678e-01
    z[0,1,2]  R190      -5.9702497720718384e-01
    z[0,1,2]  R191      6.1337524652481079e-01
    z[0,1,2]  R192      -2.6337766647338867e-01
    z[0,1,2]  R193      5.3891700506210327e-01
    z[0,1,2]  R194      -4.6299663186073303e-01
    z[0,1,2]  R195      -3.3626869320869446e-01
    z[0,1,2]  R196      -5.5185207165777683e-03
    z[0,1,2]  R197      1.2516488134860992e-01
    z[0,1,2]  R198      -1.8550613522529602e-01
    z[0,1,2]  R199      4.9989435821771622e-02
    z[0,1,2]  R200      3.4611660242080688e-01
    z[0,1,2]  R201      -5.7898926734924316e-01
    z[0,1,2]  R202      -1.8837502598762512e-01
    z[0,1,2]  R203      -1.5222257375717163e-01
    z[0,1,2]  R204      -1.1982090771198273e-01
    z[0,1,2]  R205      -4.3433573842048645e-01
    z[0,1,2]  R206      -3.8566648960113525e-01
    z[0,1,2]  R207      2.9167747497558594e-01
    z[0,1,2]  R208      -5.5262643098831177e-01
    z[0,1,2]  R209      3.9856532216072083e-01
    z[0,1,2]  R210      -4.4477036595344543e-01
    z[0,1,2]  R211      -0.545142650604248
    z[0,1,2]  R212      0.0301351398229599
    z[0,1,2]  R213      -7.3880887031555176e-01
    z[0,1,2]  R214      -6.6751509904861450e-01
    z[0,1,2]  R215      1.7958452925086021e-02
    z[0,1,2]  R216      -3.0071580410003662e-01
    z[0,1,2]  R217      2.2520966827869415e-01
    z[0,1,2]  R218      3.2320278882980347e-01
    z[0,1,2]  R219      4.7071447968482971e-01
    z[0,1,2]  R220      -6.5022307634353638e-01
    z[0,1,2]  R221      -6.3702452182769775e-01
    z[0,1,2]  R222      7.2934284806251526e-02
    z[0,1,2]  R223      2.8145051002502441e-01
    z[0,1,2]  R224      2.4381391704082489e-01
    z[0,1,2]  R225      -8.2089319825172424e-02
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R98       -1
    z[0,1,3]  R99       1
    z[0,1,3]  R106      -4.2973395437002182e-02
    z[0,1,3]  R107      -2.6564297080039978e-01
    z[0,1,3]  R108      -1.2342379242181778e-01
    z[0,1,3]  R109      5.4581563919782639e-02
    z[0,1,3]  R110      7.4223875999450684e-02
    z[0,1,3]  R111      -8.6148120462894440e-02
    z[0,1,3]  R112      -2.2465391457080841e-01
    z[0,1,3]  R113      -1.4569766819477081e-01
    z[0,1,3]  R114      -1.1452665925025940e-01
    z[0,1,3]  R115      -2.2144512832164764e-01
    z[0,1,3]  R116      7.7179753780364990e-01
    z[0,1,3]  R117      7.7670842409133911e-01
    z[0,1,3]  R118      4.2458295822143555e-01
    z[0,1,3]  R119      5.3509742021560669e-01
    z[0,1,3]  R120      8.8359820842742920e-01
    z[0,1,3]  R121      7.1848428249359131e-01
    z[0,1,3]  R122      7.4888008832931519e-01
    z[0,1,3]  R123      8.1281745433807373e-01
    z[0,1,3]  R124      6.4981228113174438e-01
    z[0,1,3]  R125      3.4159621596336365e-01
    z[0,1,3]  R126      -7.3769712448120117e-01
    z[0,1,3]  R127      -7.5746411085128784e-01
    z[0,1,3]  R128      -3.2506421208381653e-01
    z[0,1,3]  R129      1.0737046599388123e-02
    z[0,1,3]  R130      -2.7211424708366394e-01
    z[0,1,3]  R131      -1.4180260896682739e-01
    z[0,1,3]  R132      -9.1851547360420227e-02
    z[0,1,3]  R133      -0.193960040807724
    z[0,1,3]  R134      -2.9411277174949646e-01
    z[0,1,3]  R135      -2.3583996295928955e-01
    z[0,1,3]  R136      -8.8795667886734009e-01
    z[0,1,3]  R137      -1.4621990919113159e-01
    z[0,1,3]  R138      5.4085712879896164e-02
    z[0,1,3]  R139      2.6164343953132629e-01
    z[0,1,3]  R140      -2.8413820266723633e-01
    z[0,1,3]  R141      -4.3831738829612732e-01
    z[0,1,3]  R142      -1.9417501986026764e-01
    z[0,1,3]  R143      -3.3469071984291077e-01
    z[0,1,3]  R144      -0.192152202129364
    z[0,1,3]  R145      -7.4606943130493164e-01
    z[0,1,3]  R146      -4.2095720767974854e-01
    z[0,1,3]  R147      -1.1743719130754471e-01
    z[0,1,3]  R148      -5.9809368848800659e-01
    z[0,1,3]  R149      2.8989285230636597e-01
    z[0,1,3]  R150      5.8652019500732422e-01
    z[0,1,3]  R151      4.0933492779731750e-01
    z[0,1,3]  R152      -5.1661711931228638e-01
    z[0,1,3]  R153      -5.6924719363451004e-02
    z[0,1,3]  R154      -1.4558336138725281e-01
    z[0,1,3]  R155      7.0159655809402466e-01
    z[0,1,3]  R156      -1.7490082979202271e-01
    z[0,1,3]  R157      -4.4254866242408752e-01
    z[0,1,3]  R158      -5.4232919216156006e-01
    z[0,1,3]  R159      8.7038993835449219e-01
    z[0,1,3]  R160      -2.5695204734802246e-01
    z[0,1,3]  R161      4.2477965354919434e-01
    z[0,1,3]  R162      -2.2404132783412933e-01
    z[0,1,3]  R163      -1.2913145124912262e-01
    z[0,1,3]  R164      -2.1360759437084198e-01
    z[0,1,3]  R165      -9.8005183041095734e-02
    z[0,1,3]  R166      -1.9785149395465851e-01
    z[0,1,3]  R167      -1.5579080581665039e-01
    z[0,1,3]  R168      -1.2824720144271851e-01
    z[0,1,3]  R169      -1.8338501453399658e-01
    z[0,1,3]  R170      -1.1830183863639832e-01
    z[0,1,3]  R171      -2.9639992117881775e-01
    z[0,1,3]  R172      -1.6545537114143372e-01
    z[0,1,3]  R173      -8.5804708302021027e-02
    z[0,1,3]  R174      -2.9832187294960022e-01
    z[0,1,3]  R175      -1.2625852227210999e-01
    z[0,1,3]  R176      3.0539923906326294e-01
    z[0,1,3]  R177      7.6536345481872559e-01
    z[0,1,3]  R178      4.9695274233818054e-01
    z[0,1,3]  R179      5.2950328588485718e-01
    z[0,1,3]  R180      4.5159395784139633e-02
    z[0,1,3]  R181      8.6288101971149445e-02
    z[0,1,3]  R182      -2.1833214163780212e-01
    z[0,1,3]  R183      6.7773485183715820e-01
    z[0,1,3]  R184      5.8339411020278931e-01
    z[0,1,3]  R185      8.2833594083786011e-01
    z[0,1,3]  R186      -4.2537021636962891e-01
    z[0,1,3]  R187      -0.408914178609848
    z[0,1,3]  R188      -6.0810461640357971e-02
    z[0,1,3]  R189      -9.0807807445526123e-01
    z[0,1,3]  R190      1.6254587471485138e-01
    z[0,1,3]  R191      -1.5159854292869568e-01
    z[0,1,3]  R192      -6.9932979345321655e-01
    z[0,1,3]  R193      1.6053098440170288e-01
    z[0,1,3]  R194      3.4772035479545593e-01
    z[0,1,3]  R195      -4.2696991562843323e-01
    z[0,1,3]  R196      -8.7268584966659546e-01
    z[0,1,3]  R197      -5.4635971784591675e-01
    z[0,1,3]  R198      -6.4791935682296753e-01
    z[0,1,3]  R199      -7.7812254428863525e-01
    z[0,1,3]  R200      2.4809615314006805e-01
    z[0,1,3]  R201      5.4636709392070770e-02
    z[0,1,3]  R202      -4.3005886673927307e-01
    z[0,1,3]  R203      -4.3866130709648132e-01
    z[0,1,3]  R204      -3.9875060319900513e-01
    z[0,1,3]  R205      -3.0273789167404175e-01
    z[0,1,3]  R206      -4.1669008135795593e-01
    z[0,1,3]  R207      -8.8196210563182831e-02
    z[0,1,3]  R208      -6.0438591241836548e-01
    z[0,1,3]  R209      -5.9017026424407959e-01
    z[0,1,3]  R210      -1.5177384018898010e-01
    z[0,1,3]  R211      3.3042982220649719e-01
    z[0,1,3]  R212      8.0193474888801575e-02
    z[0,1,3]  R213      0.0891735851764679
    z[0,1,3]  R214      2.8843116760253906e-01
    z[0,1,3]  R215      6.1815810203552246e-01
    z[0,1,3]  R216      -9.0811568498611450e-01
    z[0,1,3]  R217      -4.9738240242004395e-01
    z[0,1,3]  R218      -8.3319848775863647e-01
    z[0,1,3]  R219      4.9404117465019226e-01
    z[0,1,3]  R220      -3.2991480082273483e-02
    z[0,1,3]  R221      3.7585198879241943e-01
    z[0,1,3]  R222      -4.0448507666587830e-01
    z[0,1,3]  R223      -7.5693726539611816e-02
    z[0,1,3]  R224      2.9689380526542664e-01
    z[0,1,3]  R225      5.2299493551254272e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R100      -1
    z[0,1,4]  R101      1
    z[0,1,4]  R106      4.2537233233451843e-01
    z[0,1,4]  R107      -9.5285743474960327e-02
    z[0,1,4]  R108      6.5638190507888794e-01
    z[0,1,4]  R109      3.3855831716209650e-03
    z[0,1,4]  R110      3.1257805228233337e-01
    z[0,1,4]  R111      4.1833665966987610e-01
    z[0,1,4]  R112      3.7378013134002686e-01
    z[0,1,4]  R113      1.3977633416652679e-01
    z[0,1,4]  R114      1.4557459950447083e-01
    z[0,1,4]  R115      6.6414761543273926e-01
    z[0,1,4]  R116      -2.2514109313488007e-01
    z[0,1,4]  R117      1.5775656700134277e-01
    z[0,1,4]  R118      -4.4935601949691772e-01
    z[0,1,4]  R119      -4.4440931081771851e-01
    z[0,1,4]  R120      -9.2320390045642853e-02
    z[0,1,4]  R121      1.6472026705741882e-01
    z[0,1,4]  R122      -1.4845220744609833e-01
    z[0,1,4]  R123      7.1356974542140961e-02
    z[0,1,4]  R124      3.1857442855834961e-01
    z[0,1,4]  R125      -1.8808278441429138e-01
    z[0,1,4]  R126      -7.0799104869365692e-02
    z[0,1,4]  R127      -4.6892590820789337e-02
    z[0,1,4]  R128      -3.5155621170997620e-01
    z[0,1,4]  R129      -2.6395657658576965e-01
    z[0,1,4]  R130      -5.4082489013671875e-01
    z[0,1,4]  R131      -6.0410511493682861e-01
    z[0,1,4]  R132      -5.7146471738815308e-01
    z[0,1,4]  R133      -1.4503400027751923e-01
    z[0,1,4]  R134      5.4119382053613663e-02
    z[0,1,4]  R135      -4.9069771170616150e-01
    z[0,1,4]  R136      2.3150597512722015e-01
    z[0,1,4]  R137      -3.9880722761154175e-01
    z[0,1,4]  R138      -1.0147042572498322e-01
    z[0,1,4]  R139      -2.7505621314048767e-01
    z[0,1,4]  R140      4.4939219951629639e-01
    z[0,1,4]  R141      -7.8716287389397621e-03
    z[0,1,4]  R142      1.5144766867160797e-01
    z[0,1,4]  R143      -2.9947564005851746e-02
    z[0,1,4]  R144      -1.3263091444969177e-01
    z[0,1,4]  R145      -3.4195877611637115e-02
    z[0,1,4]  R146      8.7610080838203430e-02
    z[0,1,4]  R147      -7.7473089098930359e-02
    z[0,1,4]  R148      3.5602787137031555e-01
    z[0,1,4]  R149      -1.8323583528399467e-02
    z[0,1,4]  R150      -3.1564787030220032e-01
    z[0,1,4]  R151      -1.6070117056369781e-01
    z[0,1,4]  R152      2.2763521969318390e-01
    z[0,1,4]  R153      -3.6384207010269165e-01
    z[0,1,4]  R154      9.4340629875659943e-03
    z[0,1,4]  R155      -2.4918565154075623e-01
    z[0,1,4]  R156      7.2349125146865845e-01
    z[0,1,4]  R157      -2.0824027061462402e-01
    z[0,1,4]  R158      -1.0618934780359268e-01
    z[0,1,4]  R159      2.2421617805957794e-01
    z[0,1,4]  R160      3.9329430460929871e-01
    z[0,1,4]  R161      2.2341303527355194e-01
    z[0,1,4]  R162      -5.3956985473632812e-01
    z[0,1,4]  R163      -3.5801011323928833e-01
    z[0,1,4]  R164      -1.4515841007232666e-01
    z[0,1,4]  R165      -3.4462669491767883e-01
    z[0,1,4]  R166      2.8005328774452209e-01
    z[0,1,4]  R167      3.1539127230644226e-01
    z[0,1,4]  R168      1.8078483641147614e-01
    z[0,1,4]  R169      3.1668260693550110e-01
    z[0,1,4]  R170      5.9276384115219116e-01
    z[0,1,4]  R171      1.5372152626514435e-01
    z[0,1,4]  R172      -3.5441529750823975e-01
    z[0,1,4]  R173      0.682155430316925
    z[0,1,4]  R174      8.0553829669952393e-01
    z[0,1,4]  R175      7.1015870571136475e-01
    z[0,1,4]  R176      -2.3386125266551971e-01
    z[0,1,4]  R177      -4.2920134961605072e-02
    z[0,1,4]  R178      6.7264698445796967e-03
    z[0,1,4]  R179      -1.3860683143138885e-01
    z[0,1,4]  R180      -1.0556232929229736e-01
    z[0,1,4]  R181      -0.180857852101326
    z[0,1,4]  R182      -0.347945898771286
    z[0,1,4]  R183      1.9008468091487885e-01
    z[0,1,4]  R184      -5.6145143508911133e-01
    z[0,1,4]  R185      -1.2967351078987122e-01
    z[0,1,4]  R186      1.1638043820858002e-01
    z[0,1,4]  R187      3.6474909633398056e-02
    z[0,1,4]  R188      -2.7737969160079956e-01
    z[0,1,4]  R189      1.9040282070636749e-01
    z[0,1,4]  R190      -2.9372459650039673e-01
    z[0,1,4]  R191      -6.5552002191543579e-01
    z[0,1,4]  R192      6.1285290867090225e-02
    z[0,1,4]  R193      -3.7403675913810730e-01
    z[0,1,4]  R194      1.5211680531501770e-01
    z[0,1,4]  R195      2.6128438115119934e-01
    z[0,1,4]  R196      -0.0209683645516634
    z[0,1,4]  R197      2.5459289550781250e-01
    z[0,1,4]  R198      6.8388420343399048e-01
    z[0,1,4]  R199      -2.5255185365676880e-01
    z[0,1,4]  R200      -3.7624785304069519e-01
    z[0,1,4]  R201      2.7798625826835632e-01
    z[0,1,4]  R202      -1.2289223819971085e-01
    z[0,1,4]  R203      -5.3070688247680664e-01
    z[0,1,4]  R204      -4.8383176326751709e-01
    z[0,1,4]  R205      4.1114774346351624e-01
    z[0,1,4]  R206      1.1680650711059570e-01
    z[0,1,4]  R207      7.0235341787338257e-02
    z[0,1,4]  R208      -4.6366035938262939e-01
    z[0,1,4]  R209      2.2281800210475922e-01
    z[0,1,4]  R210      -2.2254188358783722e-01
    z[0,1,4]  R211      -4.0633025765419006e-01
    z[0,1,4]  R212      -8.1712412834167480e-01
    z[0,1,4]  R213      -2.9364114999771118e-01
    z[0,1,4]  R214      1.6318482160568237e-01
    z[0,1,4]  R215      2.2752128541469574e-01
    z[0,1,4]  R216      1.4992308802902699e-02
    z[0,1,4]  R217      0.574512779712677
    z[0,1,4]  R218      -1.1573029309511185e-01
    z[0,1,4]  R219      6.6686391830444336e-02
    z[0,1,4]  R220      -0.254208505153656
    z[0,1,4]  R221      1.9960589706897736e-01
    z[0,1,4]  R222      -0.208910271525383
    z[0,1,4]  R223      -4.3405908346176147e-01
    z[0,1,4]  R224      4.1917651891708374e-01
    z[0,1,4]  R225      -7.3116861283779144e-02
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R102      -1
    z[0,1,5]  R103      1
    z[0,1,5]  R106      2.6495385169982910e-01
    z[0,1,5]  R107      1.9240137934684753e-01
    z[0,1,5]  R108      -1.3365660607814789e-01
    z[0,1,5]  R109      3.4046092629432678e-01
    z[0,1,5]  R110      2.4582780897617340e-02
    z[0,1,5]  R111      1.8337704241275787e-01
    z[0,1,5]  R112      -1.9482944905757904e-01
    z[0,1,5]  R113      -1.8364679813385010e-01
    z[0,1,5]  R114      -0.193043053150177
    z[0,1,5]  R115      3.8441222906112671e-01
    z[0,1,5]  R116      1.2443643063306808e-01
    z[0,1,5]  R117      -1.4630503952503204e-01
    z[0,1,5]  R118      -3.8261435925960541e-02
    z[0,1,5]  R119      -1.8658266961574554e-01
    z[0,1,5]  R120      7.1583420038223267e-02
    z[0,1,5]  R121      2.6711371541023254e-01
    z[0,1,5]  R122      1.5770785510540009e-01
    z[0,1,5]  R123      -1.2754441797733307e-01
    z[0,1,5]  R124      -1.7384602129459381e-01
    z[0,1,5]  R125      -4.2658314108848572e-01
    z[0,1,5]  R126      5.4422867298126221e-01
    z[0,1,5]  R127      2.0371700823307037e-01
    z[0,1,5]  R128      3.4966117143630981e-01
    z[0,1,5]  R129      1.7822083830833435e-01
    z[0,1,5]  R130      3.6539715528488159e-01
    z[0,1,5]  R131      0.0839887410402298
    z[0,1,5]  R132      0.165176123380661
    z[0,1,5]  R133      -5.3859132528305054e-01
    z[0,1,5]  R134      -5.9076285362243652e-01
    z[0,1,5]  R135      -4.0633502602577209e-01
    z[0,1,5]  R136      -6.1492525041103363e-02
    z[0,1,5]  R137      -3.3974891901016235e-01
    z[0,1,5]  R138      -1.8887110054492950e-01
    z[0,1,5]  R139      -0.579322099685669
    z[0,1,5]  R140      -4.4994905591011047e-01
    z[0,1,5]  R141      -0.00333201652392745
    z[0,1,5]  R142      -4.9279722571372986e-01
    z[0,1,5]  R143      2.7345292270183563e-02
    z[0,1,5]  R144      -3.1193593144416809e-01
    z[0,1,5]  R145      3.1948056817054749e-01
    z[0,1,5]  R146      -4.8160004615783691e-01
    z[0,1,5]  R147      0.0496273897588253
    z[0,1,5]  R148      -1.6497241333127022e-02
    z[0,1,5]  R149      -2.9432615637779236e-01
    z[0,1,5]  R150      -3.0568757653236389e-01
    z[0,1,5]  R151      4.5855797827243805e-02
    z[0,1,5]  R152      3.6847241222858429e-02
    z[0,1,5]  R153      3.0827721953392029e-01
    z[0,1,5]  R154      3.6515498161315918e-01
    z[0,1,5]  R155      -1.5479294955730438e-01
    z[0,1,5]  R156      -5.7219195365905762e-01
    z[0,1,5]  R157      5.1941418647766113e-01
    z[0,1,5]  R158      -6.6952146589756012e-02
    z[0,1,5]  R159      -3.6570990085601807e-01
    z[0,1,5]  R160      -4.6580466628074646e-01
    z[0,1,5]  R161      2.4896523356437683e-01
    z[0,1,5]  R162      2.9639750719070435e-01
    z[0,1,5]  R163      0.634490430355072
    z[0,1,5]  R164      7.8915208578109741e-01
    z[0,1,5]  R165      7.5244468450546265e-01
    z[0,1,5]  R166      1.2996168434619904e-01
    z[0,1,5]  R167      4.9831250309944153e-01
    z[0,1,5]  R168      -5.2954863756895065e-02
    z[0,1,5]  R169      -1.0397800803184509e-01
    z[0,1,5]  R170      -4.3760299682617188e-02
    z[0,1,5]  R171      -4.7443735599517822e-01
    z[0,1,5]  R172      4.0084591507911682e-01
    z[0,1,5]  R173      2.3899297416210175e-01
    z[0,1,5]  R174      -1.7053984105587006e-01
    z[0,1,5]  R175      -9.2424347996711731e-02
    z[0,1,5]  R176      6.7016161978244781e-02
    z[0,1,5]  R177      1.2693777680397034e-01
    z[0,1,5]  R178      -8.8410764932632446e-02
    z[0,1,5]  R179      4.9413305521011353e-01
    z[0,1,5]  R180      -5.4077520966529846e-02
    z[0,1,5]  R181      -3.5688707232475281e-01
    z[0,1,5]  R182      7.8935608267784119e-02
    z[0,1,5]  R183      -0.186315655708313
    z[0,1,5]  R184      -6.7505680024623871e-02
    z[0,1,5]  R185      6.6189900040626526e-02
    z[0,1,5]  R186      -3.7717631459236145e-01
    z[0,1,5]  R187      -5.9734326601028442e-01
    z[0,1,5]  R188      -4.7837734222412109e-01
    z[0,1,5]  R189      2.5130003690719604e-01
    z[0,1,5]  R190      -6.3161790370941162e-01
    z[0,1,5]  R191      1.6878260672092438e-01
    z[0,1,5]  R192      5.8353751897811890e-01
    z[0,1,5]  R193      3.8660675287246704e-01
    z[0,1,5]  R194      -0.318907767534256
    z[0,1,5]  R195      -1.6402861475944519e-01
    z[0,1,5]  R196      -1.2997676432132721e-01
    z[0,1,5]  R197      -3.9555296301841736e-01
    z[0,1,5]  R198      1.1939511448144913e-01
    z[0,1,5]  R199      -1.0598129779100418e-01
    z[0,1,5]  R200      0.0935024619102478
    z[0,1,5]  R201      -5.0922483205795288e-01
    z[0,1,5]  R202      -2.5957217812538147e-01
    z[0,1,5]  R203      -3.4279155731201172e-01
    z[0,1,5]  R204      -2.1769352257251740e-01
    z[0,1,5]  R205      2.4725930392742157e-01
    z[0,1,5]  R206      -5.9044855833053589e-01
    z[0,1,5]  R207      3.7515202164649963e-01
    z[0,1,5]  R208      -0.0705728530883789
    z[0,1,5]  R209      6.1502200365066528e-01
    z[0,1,5]  R210      -3.3472391963005066e-01
    z[0,1,5]  R211      -3.5757660865783691e-01
    z[0,1,5]  R212      -7.8355483710765839e-02
    z[0,1,5]  R213      -1.3906839489936829e-01
    z[0,1,5]  R214      -1.8571268767118454e-02
    z[0,1,5]  R215      -2.0394992828369141e-01
    z[0,1,5]  R216      0.0060595260001719
    z[0,1,5]  R217      7.9848654568195343e-02
    z[0,1,5]  R218      3.7020778656005859e-01
    z[0,1,5]  R219      3.0023878812789917e-01
    z[0,1,5]  R220      -3.0967068672180176e-01
    z[0,1,5]  R221      -3.7857425212860107e-01
    z[0,1,5]  R222      -5.5424129962921143e-01
    z[0,1,5]  R223      5.4742813110351562e-01
    z[0,1,5]  R224      -2.9570639133453369e-01
    z[0,1,5]  R225      3.1599190831184387e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R104      -1
    z[0,1,6]  R105      1
    z[0,1,6]  R106      7.7159710228443146e-02
    z[0,1,6]  R107      -8.0683961510658264e-02
    z[0,1,6]  R108      0.139371857047081
    z[0,1,6]  R109      -4.4379360973834991e-02
    z[0,1,6]  R110      -2.4302257597446442e-01
    z[0,1,6]  R111      1.3012232258915901e-02
    z[0,1,6]  R112      1.4325623214244843e-01
    z[0,1,6]  R113      2.0397785305976868e-01
    z[0,1,6]  R114      -4.3918332457542419e-01
    z[0,1,6]  R115      -2.7320069074630737e-01
    z[0,1,6]  R116      -2.1874524652957916e-02
    z[0,1,6]  R117      1.2172093987464905e-01
    z[0,1,6]  R118      -9.6303343772888184e-02
    z[0,1,6]  R119      1.5148496627807617e-01
    z[0,1,6]  R120      1.5535451471805573e-01
    z[0,1,6]  R121      -1.8742421269416809e-01
    z[0,1,6]  R122      -5.0384610891342163e-01
    z[0,1,6]  R123      -4.7202232480049133e-01
    z[0,1,6]  R124      -1.9704076647758484e-01
    z[0,1,6]  R125      5.0386947393417358e-01
    z[0,1,6]  R126      1.7277951538562775e-01
    z[0,1,6]  R127      1.2333349883556366e-01
    z[0,1,6]  R128      -4.1507761925458908e-02
    z[0,1,6]  R129      2.0936825871467590e-01
    z[0,1,6]  R130      -3.0899370089173317e-02
    z[0,1,6]  R131      8.7542489171028137e-02
    z[0,1,6]  R132      3.0347725842148066e-03
    z[0,1,6]  R133      -1.9770814478397369e-01
    z[0,1,6]  R134      -5.8251347392797470e-02
    z[0,1,6]  R135      -1.0866452008485794e-02
    z[0,1,6]  R136      -3.1294006109237671e-01
    z[0,1,6]  R137      -6.9185465574264526e-02
    z[0,1,6]  R138      -3.0267012119293213e-01
    z[0,1,6]  R139      -1.1578613519668579e-01
    z[0,1,6]  R140      -1.8573486804962158e-01
    z[0,1,6]  R141      -2.0713666081428528e-01
    z[0,1,6]  R142      2.2767202556133270e-01
    z[0,1,6]  R143      5.0874944776296616e-02
    z[0,1,6]  R144      3.7979960907250643e-03
    z[0,1,6]  R145      1.3695596717298031e-02
    z[0,1,6]  R146      5.6516444683074951e-01
    z[0,1,6]  R147      1.7001870274543762e-01
    z[0,1,6]  R148      -2.3594453930854797e-01
    z[0,1,6]  R149      -5.4452878236770630e-01
    z[0,1,6]  R150      -2.3469147086143494e-01
    z[0,1,6]  R151      -4.3339309096336365e-01
    z[0,1,6]  R152      3.3968454599380493e-01
    z[0,1,6]  R153      5.2589696645736694e-01
    z[0,1,6]  R154      6.7241585254669189e-01
    z[0,1,6]  R155      2.0722452551126480e-02
    z[0,1,6]  R156      -1.1373517662286758e-01
    z[0,1,6]  R157      6.3404709100723267e-01
    z[0,1,6]  R158      0.623392641544342
    z[0,1,6]  R159      -2.8832862153649330e-02
    z[0,1,6]  R160      1.1271952837705612e-01
    z[0,1,6]  R161      -9.2097982764244080e-02
    z[0,1,6]  R162      5.4710201919078827e-02
    z[0,1,6]  R163      -9.3675032258033752e-02
    z[0,1,6]  R164      -7.3648296296596527e-02
    z[0,1,6]  R165      -5.7028006762266159e-02
    z[0,1,6]  R166      -4.1296545416116714e-02
    z[0,1,6]  R167      4.7544579952955246e-02
    z[0,1,6]  R168      -2.8484994173049927e-01
    z[0,1,6]  R169      -3.4448447823524475e-01
    z[0,1,6]  R170      1.0768654197454453e-01
    z[0,1,6]  R171      -5.8732575178146362e-01
    z[0,1,6]  R172      1.0995424352586269e-02
    z[0,1,6]  R173      1.1395853757858276e-01
    z[0,1,6]  R174      -3.8139519095420837e-01
    z[0,1,6]  R175      7.5161732733249664e-02
    z[0,1,6]  R176      9.8768718540668488e-02
    z[0,1,6]  R177      -1.5962858498096466e-01
    z[0,1,6]  R178      -3.5750970244407654e-01
    z[0,1,6]  R179      -1.5360661782324314e-02
    z[0,1,6]  R180      -1.5741893649101257e-01
    z[0,1,6]  R181      3.2253009080886841e-01
    z[0,1,6]  R182      3.8437563180923462e-01
    z[0,1,6]  R183      -1.6234208643436432e-01
    z[0,1,6]  R184      -1.6507243737578392e-02
    z[0,1,6]  R185      8.9567065238952637e-02
    z[0,1,6]  R186      3.1049272045493126e-02
    z[0,1,6]  R187      1.2024573236703873e-01
    z[0,1,6]  R188      -0.277940034866333
    z[0,1,6]  R189      2.0571085810661316e-01
    z[0,1,6]  R190      7.1777604520320892e-02
    z[0,1,6]  R191      -1.4794050157070160e-01
    z[0,1,6]  R192      -7.2795733809471130e-02
    z[0,1,6]  R193      -3.8922619819641113e-01
    z[0,1,6]  R194      -1.8607042729854584e-01
    z[0,1,6]  R195      -1.2934499979019165e-01
    z[0,1,6]  R196      8.4637450054287910e-03
    z[0,1,6]  R197      1.3048601150512695e-01
    z[0,1,6]  R198      5.3298264741897583e-02
    z[0,1,6]  R199      -2.7908441424369812e-01
    z[0,1,6]  R200      1.6596347093582153e-01
    z[0,1,6]  R201      0.00876099057495594
    z[0,1,6]  R202      3.9219805598258972e-01
    z[0,1,6]  R203      2.2666966915130615e-01
    z[0,1,6]  R204      5.0538641214370728e-01
    z[0,1,6]  R205      4.1560640931129456e-01
    z[0,1,6]  R206      2.2250089049339294e-01
    z[0,1,6]  R207      4.8746901750564575e-01
    z[0,1,6]  R208      3.5872368607670069e-03
    z[0,1,6]  R209      0.087613046169281
    z[0,1,6]  R210      -5.4974645376205444e-01
    z[0,1,6]  R211      -2.0097108185291290e-01
    z[0,1,6]  R212      -1.6633279621601105e-01
    z[0,1,6]  R213      3.9147740602493286e-01
    z[0,1,6]  R214      -2.4853512644767761e-01
    z[0,1,6]  R215      -5.5437427014112473e-02
    z[0,1,6]  R216      7.4375040829181671e-02
    z[0,1,6]  R217      6.3531458377838135e-02
    z[0,1,6]  R218      -6.5903551876544952e-02
    z[0,1,6]  R219      -6.2070630490779877e-02
    z[0,1,6]  R220      -9.2620790004730225e-02
    z[0,1,6]  R221      -2.5661420822143555e-01
    z[0,1,6]  R222      -2.8402399271726608e-02
    z[0,1,6]  R223      -1.0774499922990799e-01
    z[0,1,6]  R224      -0.587288498878479
    z[0,1,6]  R225      2.1513158082962036e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R226      -1
    z[1,0,0]  R227      1
    z[1,0,0]  R240      5.6712478399276733e-01
    z[1,0,0]  R241      5.7326781749725342e-01
    z[1,0,0]  R242      3.5377502441406250e-01
    z[1,0,0]  R243      6.1590307950973511e-01
    z[1,0,0]  R244      3.1329560279846191e-01
    z[1,0,0]  R245      4.0936514735221863e-01
    z[1,0,0]  R246      1.7265732586383820e-01
    z[1,0,0]  R247      2.4288158118724823e-01
    z[1,0,0]  R248      2.0638771355152130e-01
    z[1,0,0]  R249      0.621462345123291
    z[1,0,0]  R250      -5.0725597143173218e-01
    z[1,0,0]  R251      -4.5115393400192261e-01
    z[1,0,0]  R252      -7.2730302810668945e-01
    z[1,0,0]  R253      -4.6807822585105896e-01
    z[1,0,0]  R254      -7.8397506475448608e-01
    z[1,0,0]  R255      -3.0847826600074768e-01
    z[1,0,0]  R256      -2.0180958509445190e-01
    z[1,0,0]  R257      -4.7805258631706238e-01
    z[1,0,0]  R258      -4.5329952239990234e-01
    z[1,0,0]  R259      -3.3067616820335388e-01
    z[1,0,0]  R260      -2.8777632117271423e-01
    z[1,0,0]  R261      3.1904092431068420e-01
    z[1,0,0]  R262      -5.8472013473510742e-01
    z[1,0,0]  R263      -1.1177876591682434e-01
    z[1,0,0]  R264      1.5771120786666870e-01
    z[1,0,0]  R265      -1.2083274126052856e-01
    z[1,0,0]  R266      -3.0223888158798218e-01
    z[1,0,0]  R267      -4.8529732227325439e-01
    z[1,0,0]  R268      1.0204591602087021e-01
    z[1,0,0]  R269      1.7605938017368317e-01
    z[1,0,0]  R270      3.5676565766334534e-01
    z[1,0,0]  R271      6.0027921199798584e-01
    z[1,0,0]  R272      -2.0596690475940704e-01
    z[1,0,0]  R273      -1.1497341096401215e-01
    z[1,0,0]  R274      -1.2827318906784058e-01
    z[1,0,0]  R275      2.9592707753181458e-01
    z[1,0,0]  R276      -4.6516966074705124e-02
    z[1,0,0]  R277      -1.7297618091106415e-01
    z[1,0,0]  R278      2.1709685027599335e-01
    z[1,0,0]  R279      2.8099268674850464e-01
    z[1,0,0]  R280      4.5194447040557861e-01
    z[1,0,0]  R281      1.7751461267471313e-01
    z[1,0,0]  R282      2.8391501307487488e-01
    z[1,0,0]  R283      -0.141950786113739
    z[1,0,0]  R284      -2.7992233633995056e-01
    z[1,0,0]  R285      -2.6550477743148804e-01
    z[1,0,0]  R286      -1.6600802540779114e-02
    z[1,0,0]  R287      -9.8987082019448280e-03
    z[1,0,0]  R288      -2.7718076109886169e-01
    z[1,0,0]  R289      -2.1165333688259125e-01
    z[1,0,0]  R290      -1.7723931372165680e-01
    z[1,0,0]  R291      8.8512469083070755e-03
    z[1,0,0]  R292      1.0552880913019180e-01
    z[1,0,0]  R293      -2.0274975895881653e-01
    z[1,0,0]  R294      -6.2486010789871216e-01
    z[1,0,0]  R295      -4.3374547362327576e-01
    z[1,0,0]  R296      -5.0168428570032120e-03
    z[1,0,0]  R297      -6.3746839761734009e-01
    z[1,0,0]  R298      -3.2313367724418640e-01
    z[1,0,0]  R299      3.9484769105911255e-01
    z[1,0,0]  R300      0.620798647403717
    z[1,0,0]  R301      5.2654927968978882e-01
    z[1,0,0]  R302      0.462368905544281
    z[1,0,0]  R303      1.3268569111824036e-01
    z[1,0,0]  R304      1.5740792453289032e-01
    z[1,0,0]  R305      -1.3772873580455780e-01
    z[1,0,0]  R306      5.1359629631042480e-01
    z[1,0,0]  R307      1.8717673420906067e-01
    z[1,0,0]  R308      7.0190334320068359e-01
    z[1,0,0]  R309      -1.2152490764856339e-01
    z[1,0,0]  R310      -3.8810375332832336e-01
    z[1,0,0]  R311      -1.6573785245418549e-01
    z[1,0,0]  R312      -3.1329813599586487e-01
    z[1,0,0]  R313      -3.6065387725830078e-01
    z[1,0,0]  R314      -1.4641138911247253e-01
    z[1,0,0]  R315      -3.8380718231201172e-01
    z[1,0,0]  R316      -1.9463101029396057e-01
    z[1,0,0]  R317      -2.1786668896675110e-01
    z[1,0,0]  R318      -3.5266622900962830e-01
    z[1,0,0]  R319      1.3635067641735077e-01
    z[1,0,0]  R320      -4.0896780788898468e-02
    z[1,0,0]  R321      -1.0298158973455429e-01
    z[1,0,0]  R322      -2.5520476698875427e-01
    z[1,0,0]  R323      -4.1922938078641891e-02
    z[1,0,0]  R324      -5.3105160593986511e-02
    z[1,0,0]  R325      2.2029291093349457e-01
    z[1,0,0]  R326      -1.6303269565105438e-01
    z[1,0,0]  R327      4.5278385281562805e-01
    z[1,0,0]  R328      3.0736759305000305e-01
    z[1,0,0]  R329      2.5611084699630737e-01
    z[1,0,0]  R330      1.6221153736114502e-01
    z[1,0,0]  R331      1.0434409230947495e-01
    z[1,0,0]  R332      -1.9514784216880798e-01
    z[1,0,0]  R333      2.0719854533672333e-01
    z[1,0,0]  R334      -4.5424412935972214e-02
    z[1,0,0]  R335      -5.9812828898429871e-02
    z[1,0,0]  R336      1.2708221375942230e-01
    z[1,0,0]  R337      4.8202324658632278e-02
    z[1,0,0]  R338      4.0944972634315491e-01
    z[1,0,0]  R339      9.1523610055446625e-02
    z[1,0,0]  R340      4.2951118946075439e-01
    z[1,0,0]  R341      -3.9567712694406509e-02
    z[1,0,0]  R342      -3.1187409535050392e-02
    z[1,0,0]  R343      7.9985029995441437e-02
    z[1,0,0]  R344      4.0240153670310974e-01
    z[1,0,0]  R345      2.4220819771289825e-01
    z[1,0,0]  R346      -0.302153080701828
    z[1,0,0]  R347      2.0053511857986450e-01
    z[1,0,0]  R348      -2.2063534706830978e-02
    z[1,0,0]  R349      -2.2748107090592384e-02
    z[1,0,0]  R350      2.3923364281654358e-01
    z[1,0,0]  R351      2.6735377311706543e-01
    z[1,0,0]  R352      2.5035685300827026e-01
    z[1,0,0]  R353      -1.0845737904310226e-01
    z[1,0,0]  R354      7.5069174170494080e-02
    z[1,0,0]  R355      -5.2948564291000366e-02
    z[1,0,0]  R356      3.5006088018417358e-01
    z[1,0,0]  R357      -2.5894674658775330e-01
    z[1,0,0]  R358      -2.6131308078765869e-01
    z[1,0,0]  R359      -1.0611040890216827e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R228      -1
    z[1,0,1]  R229      1
    z[1,0,1]  R240      -7.1999573707580566e-01
    z[1,0,1]  R241      -3.5951447486877441e-01
    z[1,0,1]  R242      -5.4621613025665283e-01
    z[1,0,1]  R243      -1.6242490708827972e-01
    z[1,0,1]  R244      -4.4142702221870422e-01
    z[1,0,1]  R245      -2.7157762646675110e-01
    z[1,0,1]  R246      -5.8418369293212891e-01
    z[1,0,1]  R247      -5.1755124330520630e-01
    z[1,0,1]  R248      -0.0967964380979538
    z[1,0,1]  R249      -1.8083013594150543e-01
    z[1,0,1]  R250      0.252617210149765
    z[1,0,1]  R251      1.4443641901016235e-01
    z[1,0,1]  R252      1.6302208602428436e-01
    z[1,0,1]  R253      2.6922336220741272e-01
    z[1,0,1]  R254      -5.7934081554412842e-01
    z[1,0,1]  R255      -6.4178925752639771e-01
    z[1,0,1]  R256      4.4595742225646973e-01
    z[1,0,1]  R257      -4.1689127683639526e-01
    z[1,0,1]  R258      1.3225845992565155e-01
    z[1,0,1]  R259      -4.0894353389739990e-01
    z[1,0,1]  R260      2.6005470752716064e-01
    z[1,0,1]  R261      2.8158989548683167e-01
    z[1,0,1]  R262      1.1962978541851044e-01
    z[1,0,1]  R263      6.8216927349567413e-02
    z[1,0,1]  R264      3.1921774148941040e-01
    z[1,0,1]  R265      -3.2574182748794556e-01
    z[1,0,1]  R266      2.5507461279630661e-02
    z[1,0,1]  R267      -8.6136408150196075e-02
    z[1,0,1]  R268      7.0345389842987061e-01
    z[1,0,1]  R269      7.4947863817214966e-01
    z[1,0,1]  R270      3.0610787868499756e-01
    z[1,0,1]  R271      -2.9526799917221069e-01
    z[1,0,1]  R272      -1.3627997040748596e-01
    z[1,0,1]  R273      -4.7529456019401550e-01
    z[1,0,1]  R274      -7.9015719890594482e-01
    z[1,0,1]  R275      4.8739153146743774e-01
    z[1,0,1]  R276      -7.3559558391571045e-01
    z[1,0,1]  R277      -5.5131548643112183e-01
    z[1,0,1]  R278      -4.9255535006523132e-01
    z[1,0,1]  R279      4.8768538236618042e-01
    z[1,0,1]  R280      -2.4818757176399231e-01
    z[1,0,1]  R281      -7.0166671276092529e-01
    z[1,0,1]  R282      -1.6952741146087646e-01
    z[1,0,1]  R283      -1.9266216456890106e-01
    z[1,0,1]  R284      4.8682785034179688e-01
    z[1,0,1]  R285      4.3564680218696594e-01
    z[1,0,1]  R286      5.3933960199356079e-01
    z[1,0,1]  R287      4.3277230858802795e-01
    z[1,0,1]  R288      5.5286341905593872e-01
    z[1,0,1]  R289      -0.690163791179657
    z[1,0,1]  R290      -0.218377947807312
    z[1,0,1]  R291      -6.0111218690872192e-01
    z[1,0,1]  R292      -1.8813097476959229e-01
    z[1,0,1]  R293      -6.2833160161972046e-01
    z[1,0,1]  R294      1.2874330580234528e-01
    z[1,0,1]  R295      1.2565034627914429e-01
    z[1,0,1]  R296      -6.9239699840545654e-01
    z[1,0,1]  R297      -9.4848774373531342e-02
    z[1,0,1]  R298      -3.7407833337783813e-01
    z[1,0,1]  R299      6.4214813709259033e-01
    z[1,0,1]  R300      -5.2527648210525513e-01
    z[1,0,1]  R301      -7.6045840978622437e-01
    z[1,0,1]  R302      -2.5633433461189270e-01
    z[1,0,1]  R303      -8.1234443187713623e-01
    z[1,0,1]  R304      -5.2500879764556885e-01
    z[1,0,1]  R305      -8.3281147480010986e-01
    z[1,0,1]  R306      -4.5282069593667984e-02
    z[1,0,1]  R307      -6.6825169324874878e-01
    z[1,0,1]  R308      9.4174752011895180e-03
    z[1,0,1]  R309      -4.4155597686767578e-01
    z[1,0,1]  R310      0.336871862411499
    z[1,0,1]  R311      4.4043898582458496e-01
    z[1,0,1]  R312      5.4839485883712769e-01
    z[1,0,1]  R313      2.0966002345085144e-01
    z[1,0,1]  R314      3.0229339003562927e-01
    z[1,0,1]  R315      3.9771580696105957e-01
    z[1,0,1]  R316      2.9277262091636658e-01
    z[1,0,1]  R317      2.0392750203609467e-01
    z[1,0,1]  R318      4.5268815755844116e-01
    z[1,0,1]  R319      5.1453071832656860e-01
    z[1,0,1]  R320      1.6954012215137482e-01
    z[1,0,1]  R321      -4.2636382579803467e-01
    z[1,0,1]  R322      4.4002529978752136e-01
    z[1,0,1]  R323      6.4283883571624756e-01
    z[1,0,1]  R324      -6.4902478456497192e-01
    z[1,0,1]  R325      -7.3591619729995728e-01
    z[1,0,1]  R326      1.1351312696933746e-01
    z[1,0,1]  R327      -6.2721645832061768e-01
    z[1,0,1]  R328      -0.582633376121521
    z[1,0,1]  R329      -6.8468379974365234e-01
    z[1,0,1]  R330      1.4159551262855530e-01
    z[1,0,1]  R331      4.7614101320505142e-02
    z[1,0,1]  R332      4.0677130222320557e-01
    z[1,0,1]  R333      3.2636293768882751e-01
    z[1,0,1]  R334      4.5732742547988892e-01
    z[1,0,1]  R335      -7.8393936157226562e-01
    z[1,0,1]  R336      6.3165462017059326e-01
    z[1,0,1]  R337      -9.3769985437393188e-01
    z[1,0,1]  R338      -8.0721575021743774e-01
    z[1,0,1]  R339      -5.4238897562026978e-01
    z[1,0,1]  R340      2.5861972570419312e-01
    z[1,0,1]  R341      -9.6798247098922729e-01
    z[1,0,1]  R342      -6.7429274320602417e-01
    z[1,0,1]  R343      -7.2020101547241211e-01
    z[1,0,1]  R344      2.9705107212066650e-01
    z[1,0,1]  R345      3.9390709996223450e-01
    z[1,0,1]  R346      1.5610887110233307e-01
    z[1,0,1]  R347      -4.3803668022155762e-01
    z[1,0,1]  R348      -4.0859362483024597e-01
    z[1,0,1]  R349      -6.4626979827880859e-01
    z[1,0,1]  R350      -2.8822859749197960e-02
    z[1,0,1]  R351      -1.3212330639362335e-01
    z[1,0,1]  R352      -4.8857319355010986e-01
    z[1,0,1]  R353      2.1396249532699585e-01
    z[1,0,1]  R354      -6.9400328397750854e-01
    z[1,0,1]  R355      3.4333273768424988e-01
    z[1,0,1]  R356      -4.4806605577468872e-01
    z[1,0,1]  R357      -4.6262946724891663e-01
    z[1,0,1]  R358      -3.0958941578865051e-01
    z[1,0,1]  R359      -1.9974282383918762e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R230      -1
    z[1,0,2]  R231      1
    z[1,0,2]  R240      1.5428924560546875e-01
    z[1,0,2]  R241      4.0962803363800049e-01
    z[1,0,2]  R242      6.6589558124542236e-01
    z[1,0,2]  R243      -5.7522392272949219e-01
    z[1,0,2]  R244      -5.7281100749969482e-01
    z[1,0,2]  R245      -2.7774125337600708e-01
    z[1,0,2]  R246      5.6136876344680786e-01
    z[1,0,2]  R247      3.6103519797325134e-01
    z[1,0,2]  R248      1.8868075311183929e-01
    z[1,0,2]  R249      2.1593287587165833e-01
    z[1,0,2]  R250      7.1879738569259644e-01
    z[1,0,2]  R251      3.8259690999984741e-01
    z[1,0,2]  R252      2.4863047897815704e-01
    z[1,0,2]  R253      4.0550294518470764e-01
    z[1,0,2]  R254      -9.4124749302864075e-02
    z[1,0,2]  R255      -4.7052997350692749e-01
    z[1,0,2]  R256      -0.661577045917511
    z[1,0,2]  R257      -2.0283532142639160e-01
    z[1,0,2]  R258      -3.4149882197380066e-01
    z[1,0,2]  R259      -8.9774593710899353e-02
    z[1,0,2]  R260      -7.1543413400650024e-01
    z[1,0,2]  R261      -5.2829998731613159e-01
    z[1,0,2]  R262      -5.0700902938842773e-01
    z[1,0,2]  R263      -1.2854686379432678e-01
    z[1,0,2]  R264      -5.9702497720718384e-01
    z[1,0,2]  R265      6.1337524652481079e-01
    z[1,0,2]  R266      -2.6337766647338867e-01
    z[1,0,2]  R267      5.3891700506210327e-01
    z[1,0,2]  R268      -4.6299663186073303e-01
    z[1,0,2]  R269      -3.3626869320869446e-01
    z[1,0,2]  R270      -5.5185207165777683e-03
    z[1,0,2]  R271      1.2516488134860992e-01
    z[1,0,2]  R272      -1.8550613522529602e-01
    z[1,0,2]  R273      4.9989435821771622e-02
    z[1,0,2]  R274      3.4611660242080688e-01
    z[1,0,2]  R275      -5.7898926734924316e-01
    z[1,0,2]  R276      -1.8837502598762512e-01
    z[1,0,2]  R277      -1.5222257375717163e-01
    z[1,0,2]  R278      -1.1982090771198273e-01
    z[1,0,2]  R279      -4.3433573842048645e-01
    z[1,0,2]  R280      -3.8566648960113525e-01
    z[1,0,2]  R281      2.9167747497558594e-01
    z[1,0,2]  R282      -5.5262643098831177e-01
    z[1,0,2]  R283      3.9856532216072083e-01
    z[1,0,2]  R284      -4.4477036595344543e-01
    z[1,0,2]  R285      -0.545142650604248
    z[1,0,2]  R286      0.0301351398229599
    z[1,0,2]  R287      -7.3880887031555176e-01
    z[1,0,2]  R288      -6.6751509904861450e-01
    z[1,0,2]  R289      1.7958452925086021e-02
    z[1,0,2]  R290      -3.0071580410003662e-01
    z[1,0,2]  R291      2.2520966827869415e-01
    z[1,0,2]  R292      3.2320278882980347e-01
    z[1,0,2]  R293      4.7071447968482971e-01
    z[1,0,2]  R294      -6.5022307634353638e-01
    z[1,0,2]  R295      -6.3702452182769775e-01
    z[1,0,2]  R296      7.2934284806251526e-02
    z[1,0,2]  R297      2.8145051002502441e-01
    z[1,0,2]  R298      2.4381391704082489e-01
    z[1,0,2]  R299      -8.2089319825172424e-02
    z[1,0,2]  R300      2.8240248560905457e-01
    z[1,0,2]  R301      0.145859956741333
    z[1,0,2]  R302      -4.8697876930236816e-01
    z[1,0,2]  R303      4.4901812076568604e-01
    z[1,0,2]  R304      0.73260498046875
    z[1,0,2]  R305      2.6689371466636658e-01
    z[1,0,2]  R306      6.9678300619125366e-01
    z[1,0,2]  R307      -6.3427609205245972e-01
    z[1,0,2]  R308      -4.9273434281349182e-01
    z[1,0,2]  R309      2.7878072857856750e-01
    z[1,0,2]  R310      2.7123796939849854e-01
    z[1,0,2]  R311      3.3787584304809570e-01
    z[1,0,2]  R312      4.5626482367515564e-01
    z[1,0,2]  R313      5.3327459096908569e-01
    z[1,0,2]  R314      2.6201978325843811e-01
    z[1,0,2]  R315      2.1138642728328705e-01
    z[1,0,2]  R316      1.2170034646987915e-01
    z[1,0,2]  R317      -7.8172661364078522e-02
    z[1,0,2]  R318      -2.7911770343780518e-01
    z[1,0,2]  R319      -3.5881170630455017e-01
    z[1,0,2]  R320      -3.0714237689971924e-01
    z[1,0,2]  R321      -4.1826552152633667e-01
    z[1,0,2]  R322      -6.2289965152740479e-01
    z[1,0,2]  R323      -6.6303437948226929e-01
    z[1,0,2]  R324      -2.7375000715255737e-01
    z[1,0,2]  R325      -1.0064578801393509e-01
    z[1,0,2]  R326      -7.7345591783523560e-01
    z[1,0,2]  R327      -1.1731107532978058e-01
    z[1,0,2]  R328      -3.5247454047203064e-01
    z[1,0,2]  R329      -6.3121385872364044e-02
    z[1,0,2]  R330      -9.9313713610172272e-02
    z[1,0,2]  R331      -8.2837289571762085e-01
    z[1,0,2]  R332      -8.0990833044052124e-01
    z[1,0,2]  R333      -5.9784799814224243e-01
    z[1,0,2]  R334      -5.1879543066024780e-01
    z[1,0,2]  R335      -3.8309359550476074e-01
    z[1,0,2]  R336      -4.7910192608833313e-01
    z[1,0,2]  R337      -4.6313893049955368e-02
    z[1,0,2]  R338      1.7006424069404602e-01
    z[1,0,2]  R339      1.9337338209152222e-01
    z[1,0,2]  R340      -1.1138269305229187e-01
    z[1,0,2]  R341      -1.0139747709035873e-01
    z[1,0,2]  R342      -6.2791548669338226e-02
    z[1,0,2]  R343      -8.6022213101387024e-02
    z[1,0,2]  R344      3.9707577228546143e-01
    z[1,0,2]  R345      6.3471257686614990e-01
    z[1,0,2]  R346      -6.6998451948165894e-01
    z[1,0,2]  R347      5.1057374477386475e-01
    z[1,0,2]  R348      4.7518399357795715e-01
    z[1,0,2]  R349      -5.5646121501922607e-02
    z[1,0,2]  R350      2.1809941530227661e-01
    z[1,0,2]  R351      -6.7226584069430828e-03
    z[1,0,2]  R352      1.0934574529528618e-02
    z[1,0,2]  R353      5.5326181463897228e-03
    z[1,0,2]  R354      -2.4967899918556213e-01
    z[1,0,2]  R355      7.6059329509735107e-01
    z[1,0,2]  R356      4.9448895454406738e-01
    z[1,0,2]  R357      4.0338733792304993e-01
    z[1,0,2]  R358      3.7548035383224487e-01
    z[1,0,2]  R359      0.501044511795044
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R232      -1
    z[1,0,3]  R233      1
    z[1,0,3]  R240      -1.9785149395465851e-01
    z[1,0,3]  R241      -1.5579080581665039e-01
    z[1,0,3]  R242      -1.2824720144271851e-01
    z[1,0,3]  R243      -1.8338501453399658e-01
    z[1,0,3]  R244      -1.1830183863639832e-01
    z[1,0,3]  R245      -2.9639992117881775e-01
    z[1,0,3]  R246      -1.6545537114143372e-01
    z[1,0,3]  R247      -8.5804708302021027e-02
    z[1,0,3]  R248      -2.9832187294960022e-01
    z[1,0,3]  R249      -1.2625852227210999e-01
    z[1,0,3]  R250      3.0539923906326294e-01
    z[1,0,3]  R251      7.6536345481872559e-01
    z[1,0,3]  R252      4.9695274233818054e-01
    z[1,0,3]  R253      5.2950328588485718e-01
    z[1,0,3]  R254      4.5159395784139633e-02
    z[1,0,3]  R255      8.6288101971149445e-02
    z[1,0,3]  R256      -2.1833214163780212e-01
    z[1,0,3]  R257      6.7773485183715820e-01
    z[1,0,3]  R258      5.8339411020278931e-01
    z[1,0,3]  R259      8.2833594083786011e-01
    z[1,0,3]  R260      -4.2537021636962891e-01
    z[1,0,3]  R261      -0.408914178609848
    z[1,0,3]  R262      -6.0810461640357971e-02
    z[1,0,3]  R263      -9.0807807445526123e-01
    z[1,0,3]  R264      1.6254587471485138e-01
    z[1,0,3]  R265      -1.5159854292869568e-01
    z[1,0,3]  R266      -6.9932979345321655e-01
    z[1,0,3]  R267      1.6053098440170288e-01
    z[1,0,3]  R268      3.4772035479545593e-01
    z[1,0,3]  R269      -4.2696991562843323e-01
    z[1,0,3]  R270      -8.7268584966659546e-01
    z[1,0,3]  R271      -5.4635971784591675e-01
    z[1,0,3]  R272      -6.4791935682296753e-01
    z[1,0,3]  R273      -7.7812254428863525e-01
    z[1,0,3]  R274      2.4809615314006805e-01
    z[1,0,3]  R275      5.4636709392070770e-02
    z[1,0,3]  R276      -4.3005886673927307e-01
    z[1,0,3]  R277      -4.3866130709648132e-01
    z[1,0,3]  R278      -3.9875060319900513e-01
    z[1,0,3]  R279      -3.0273789167404175e-01
    z[1,0,3]  R280      -4.1669008135795593e-01
    z[1,0,3]  R281      -8.8196210563182831e-02
    z[1,0,3]  R282      -6.0438591241836548e-01
    z[1,0,3]  R283      -5.9017026424407959e-01
    z[1,0,3]  R284      -1.5177384018898010e-01
    z[1,0,3]  R285      3.3042982220649719e-01
    z[1,0,3]  R286      8.0193474888801575e-02
    z[1,0,3]  R287      0.0891735851764679
    z[1,0,3]  R288      2.8843116760253906e-01
    z[1,0,3]  R289      6.1815810203552246e-01
    z[1,0,3]  R290      -9.0811568498611450e-01
    z[1,0,3]  R291      -4.9738240242004395e-01
    z[1,0,3]  R292      -8.3319848775863647e-01
    z[1,0,3]  R293      4.9404117465019226e-01
    z[1,0,3]  R294      -3.2991480082273483e-02
    z[1,0,3]  R295      3.7585198879241943e-01
    z[1,0,3]  R296      -4.0448507666587830e-01
    z[1,0,3]  R297      -7.5693726539611816e-02
    z[1,0,3]  R298      2.9689380526542664e-01
    z[1,0,3]  R299      5.2299493551254272e-01
    z[1,0,3]  R300      -4.2973395437002182e-02
    z[1,0,3]  R301      -2.6564297080039978e-01
    z[1,0,3]  R302      -1.2342379242181778e-01
    z[1,0,3]  R303      5.4581563919782639e-02
    z[1,0,3]  R304      7.4223875999450684e-02
    z[1,0,3]  R305      -8.6148120462894440e-02
    z[1,0,3]  R306      -2.2465391457080841e-01
    z[1,0,3]  R307      -1.4569766819477081e-01
    z[1,0,3]  R308      -1.1452665925025940e-01
    z[1,0,3]  R309      -2.2144512832164764e-01
    z[1,0,3]  R310      7.7179753780364990e-01
    z[1,0,3]  R311      7.7670842409133911e-01
    z[1,0,3]  R312      4.2458295822143555e-01
    z[1,0,3]  R313      5.3509742021560669e-01
    z[1,0,3]  R314      8.8359820842742920e-01
    z[1,0,3]  R315      7.1848428249359131e-01
    z[1,0,3]  R316      7.4888008832931519e-01
    z[1,0,3]  R317      8.1281745433807373e-01
    z[1,0,3]  R318      6.4981228113174438e-01
    z[1,0,3]  R319      3.4159621596336365e-01
    z[1,0,3]  R320      -7.3769712448120117e-01
    z[1,0,3]  R321      -7.5746411085128784e-01
    z[1,0,3]  R322      -3.2506421208381653e-01
    z[1,0,3]  R323      1.0737046599388123e-02
    z[1,0,3]  R324      -2.7211424708366394e-01
    z[1,0,3]  R325      -1.4180260896682739e-01
    z[1,0,3]  R326      -9.1851547360420227e-02
    z[1,0,3]  R327      -0.193960040807724
    z[1,0,3]  R328      -2.9411277174949646e-01
    z[1,0,3]  R329      -2.3583996295928955e-01
    z[1,0,3]  R330      -8.8795667886734009e-01
    z[1,0,3]  R331      -1.4621990919113159e-01
    z[1,0,3]  R332      5.4085712879896164e-02
    z[1,0,3]  R333      2.6164343953132629e-01
    z[1,0,3]  R334      -2.8413820266723633e-01
    z[1,0,3]  R335      -4.3831738829612732e-01
    z[1,0,3]  R336      -1.9417501986026764e-01
    z[1,0,3]  R337      -3.3469071984291077e-01
    z[1,0,3]  R338      -0.192152202129364
    z[1,0,3]  R339      -7.4606943130493164e-01
    z[1,0,3]  R340      -4.2095720767974854e-01
    z[1,0,3]  R341      -1.1743719130754471e-01
    z[1,0,3]  R342      -5.9809368848800659e-01
    z[1,0,3]  R343      2.8989285230636597e-01
    z[1,0,3]  R344      5.8652019500732422e-01
    z[1,0,3]  R345      4.0933492779731750e-01
    z[1,0,3]  R346      -5.1661711931228638e-01
    z[1,0,3]  R347      -5.6924719363451004e-02
    z[1,0,3]  R348      -1.4558336138725281e-01
    z[1,0,3]  R349      7.0159655809402466e-01
    z[1,0,3]  R350      -1.7490082979202271e-01
    z[1,0,3]  R351      -4.4254866242408752e-01
    z[1,0,3]  R352      -5.4232919216156006e-01
    z[1,0,3]  R353      8.7038993835449219e-01
    z[1,0,3]  R354      -2.5695204734802246e-01
    z[1,0,3]  R355      4.2477965354919434e-01
    z[1,0,3]  R356      -2.2404132783412933e-01
    z[1,0,3]  R357      -1.2913145124912262e-01
    z[1,0,3]  R358      -2.1360759437084198e-01
    z[1,0,3]  R359      -9.8005183041095734e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R234      -1
    z[1,0,4]  R235      1
    z[1,0,4]  R240      2.8005328774452209e-01
    z[1,0,4]  R241      3.1539127230644226e-01
    z[1,0,4]  R242      1.8078483641147614e-01
    z[1,0,4]  R243      3.1668260693550110e-01
    z[1,0,4]  R244      5.9276384115219116e-01
    z[1,0,4]  R245      1.5372152626514435e-01
    z[1,0,4]  R246      -3.5441529750823975e-01
    z[1,0,4]  R247      0.682155430316925
    z[1,0,4]  R248      8.0553829669952393e-01
    z[1,0,4]  R249      7.1015870571136475e-01
    z[1,0,4]  R250      -2.3386125266551971e-01
    z[1,0,4]  R251      -4.2920134961605072e-02
    z[1,0,4]  R252      6.7264698445796967e-03
    z[1,0,4]  R253      -1.3860683143138885e-01
    z[1,0,4]  R254      -1.0556232929229736e-01
    z[1,0,4]  R255      -0.180857852101326
    z[1,0,4]  R256      -0.347945898771286
    z[1,0,4]  R257      1.9008468091487885e-01
    z[1,0,4]  R258      -5.6145143508911133e-01
    z[1,0,4]  R259      -1.2967351078987122e-01
    z[1,0,4]  R260      1.1638043820858002e-01
    z[1,0,4]  R261      3.6474909633398056e-02
    z[1,0,4]  R262      -2.7737969160079956e-01
    z[1,0,4]  R263      1.9040282070636749e-01
    z[1,0,4]  R264      -2.9372459650039673e-01
    z[1,0,4]  R265      -6.5552002191543579e-01
    z[1,0,4]  R266      6.1285290867090225e-02
    z[1,0,4]  R267      -3.7403675913810730e-01
    z[1,0,4]  R268      1.5211680531501770e-01
    z[1,0,4]  R269      2.6128438115119934e-01
    z[1,0,4]  R270      -0.0209683645516634
    z[1,0,4]  R271      2.5459289550781250e-01
    z[1,0,4]  R272      6.8388420343399048e-01
    z[1,0,4]  R273      -2.5255185365676880e-01
    z[1,0,4]  R274      -3.7624785304069519e-01
    z[1,0,4]  R275      2.7798625826835632e-01
    z[1,0,4]  R276      -1.2289223819971085e-01
    z[1,0,4]  R277      -5.3070688247680664e-01
    z[1,0,4]  R278      -4.8383176326751709e-01
    z[1,0,4]  R279      4.1114774346351624e-01
    z[1,0,4]  R280      1.1680650711059570e-01
    z[1,0,4]  R281      7.0235341787338257e-02
    z[1,0,4]  R282      -4.6366035938262939e-01
    z[1,0,4]  R283      2.2281800210475922e-01
    z[1,0,4]  R284      -2.2254188358783722e-01
    z[1,0,4]  R285      -4.0633025765419006e-01
    z[1,0,4]  R286      -8.1712412834167480e-01
    z[1,0,4]  R287      -2.9364114999771118e-01
    z[1,0,4]  R288      1.6318482160568237e-01
    z[1,0,4]  R289      2.2752128541469574e-01
    z[1,0,4]  R290      1.4992308802902699e-02
    z[1,0,4]  R291      0.574512779712677
    z[1,0,4]  R292      -1.1573029309511185e-01
    z[1,0,4]  R293      6.6686391830444336e-02
    z[1,0,4]  R294      -0.254208505153656
    z[1,0,4]  R295      1.9960589706897736e-01
    z[1,0,4]  R296      -0.208910271525383
    z[1,0,4]  R297      -4.3405908346176147e-01
    z[1,0,4]  R298      4.1917651891708374e-01
    z[1,0,4]  R299      -7.3116861283779144e-02
    z[1,0,4]  R300      4.2537233233451843e-01
    z[1,0,4]  R301      -9.5285743474960327e-02
    z[1,0,4]  R302      6.5638190507888794e-01
    z[1,0,4]  R303      3.3855831716209650e-03
    z[1,0,4]  R304      3.1257805228233337e-01
    z[1,0,4]  R305      4.1833665966987610e-01
    z[1,0,4]  R306      3.7378013134002686e-01
    z[1,0,4]  R307      1.3977633416652679e-01
    z[1,0,4]  R308      1.4557459950447083e-01
    z[1,0,4]  R309      6.6414761543273926e-01
    z[1,0,4]  R310      -2.2514109313488007e-01
    z[1,0,4]  R311      1.5775656700134277e-01
    z[1,0,4]  R312      -4.4935601949691772e-01
    z[1,0,4]  R313      -4.4440931081771851e-01
    z[1,0,4]  R314      -9.2320390045642853e-02
    z[1,0,4]  R315      1.6472026705741882e-01
    z[1,0,4]  R316      -1.4845220744609833e-01
    z[1,0,4]  R317      7.1356974542140961e-02
    z[1,0,4]  R318      3.1857442855834961e-01
    z[1,0,4]  R319      -1.8808278441429138e-01
    z[1,0,4]  R320      -7.0799104869365692e-02
    z[1,0,4]  R321      -4.6892590820789337e-02
    z[1,0,4]  R322      -3.5155621170997620e-01
    z[1,0,4]  R323      -2.6395657658576965e-01
    z[1,0,4]  R324      -5.4082489013671875e-01
    z[1,0,4]  R325      -6.0410511493682861e-01
    z[1,0,4]  R326      -5.7146471738815308e-01
    z[1,0,4]  R327      -1.4503400027751923e-01
    z[1,0,4]  R328      5.4119382053613663e-02
    z[1,0,4]  R329      -4.9069771170616150e-01
    z[1,0,4]  R330      2.3150597512722015e-01
    z[1,0,4]  R331      -3.9880722761154175e-01
    z[1,0,4]  R332      -1.0147042572498322e-01
    z[1,0,4]  R333      -2.7505621314048767e-01
    z[1,0,4]  R334      4.4939219951629639e-01
    z[1,0,4]  R335      -7.8716287389397621e-03
    z[1,0,4]  R336      1.5144766867160797e-01
    z[1,0,4]  R337      -2.9947564005851746e-02
    z[1,0,4]  R338      -1.3263091444969177e-01
    z[1,0,4]  R339      -3.4195877611637115e-02
    z[1,0,4]  R340      8.7610080838203430e-02
    z[1,0,4]  R341      -7.7473089098930359e-02
    z[1,0,4]  R342      3.5602787137031555e-01
    z[1,0,4]  R343      -1.8323583528399467e-02
    z[1,0,4]  R344      -3.1564787030220032e-01
    z[1,0,4]  R345      -1.6070117056369781e-01
    z[1,0,4]  R346      2.2763521969318390e-01
    z[1,0,4]  R347      -3.6384207010269165e-01
    z[1,0,4]  R348      9.4340629875659943e-03
    z[1,0,4]  R349      -2.4918565154075623e-01
    z[1,0,4]  R350      7.2349125146865845e-01
    z[1,0,4]  R351      -2.0824027061462402e-01
    z[1,0,4]  R352      -1.0618934780359268e-01
    z[1,0,4]  R353      2.2421617805957794e-01
    z[1,0,4]  R354      3.9329430460929871e-01
    z[1,0,4]  R355      2.2341303527355194e-01
    z[1,0,4]  R356      -5.3956985473632812e-01
    z[1,0,4]  R357      -3.5801011323928833e-01
    z[1,0,4]  R358      -1.4515841007232666e-01
    z[1,0,4]  R359      -3.4462669491767883e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R236      -1
    z[1,0,5]  R237      1
    z[1,0,5]  R240      1.2996168434619904e-01
    z[1,0,5]  R241      4.9831250309944153e-01
    z[1,0,5]  R242      -5.2954863756895065e-02
    z[1,0,5]  R243      -1.0397800803184509e-01
    z[1,0,5]  R244      -4.3760299682617188e-02
    z[1,0,5]  R245      -4.7443735599517822e-01
    z[1,0,5]  R246      4.0084591507911682e-01
    z[1,0,5]  R247      2.3899297416210175e-01
    z[1,0,5]  R248      -1.7053984105587006e-01
    z[1,0,5]  R249      -9.2424347996711731e-02
    z[1,0,5]  R250      6.7016161978244781e-02
    z[1,0,5]  R251      1.2693777680397034e-01
    z[1,0,5]  R252      -8.8410764932632446e-02
    z[1,0,5]  R253      4.9413305521011353e-01
    z[1,0,5]  R254      -5.4077520966529846e-02
    z[1,0,5]  R255      -3.5688707232475281e-01
    z[1,0,5]  R256      7.8935608267784119e-02
    z[1,0,5]  R257      -0.186315655708313
    z[1,0,5]  R258      -6.7505680024623871e-02
    z[1,0,5]  R259      6.6189900040626526e-02
    z[1,0,5]  R260      -3.7717631459236145e-01
    z[1,0,5]  R261      -5.9734326601028442e-01
    z[1,0,5]  R262      -4.7837734222412109e-01
    z[1,0,5]  R263      2.5130003690719604e-01
    z[1,0,5]  R264      -6.3161790370941162e-01
    z[1,0,5]  R265      1.6878260672092438e-01
    z[1,0,5]  R266      5.8353751897811890e-01
    z[1,0,5]  R267      3.8660675287246704e-01
    z[1,0,5]  R268      -0.318907767534256
    z[1,0,5]  R269      -1.6402861475944519e-01
    z[1,0,5]  R270      -1.2997676432132721e-01
    z[1,0,5]  R271      -3.9555296301841736e-01
    z[1,0,5]  R272      1.1939511448144913e-01
    z[1,0,5]  R273      -1.0598129779100418e-01
    z[1,0,5]  R274      0.0935024619102478
    z[1,0,5]  R275      -5.0922483205795288e-01
    z[1,0,5]  R276      -2.5957217812538147e-01
    z[1,0,5]  R277      -3.4279155731201172e-01
    z[1,0,5]  R278      -2.1769352257251740e-01
    z[1,0,5]  R279      2.4725930392742157e-01
    z[1,0,5]  R280      -5.9044855833053589e-01
    z[1,0,5]  R281      3.7515202164649963e-01
    z[1,0,5]  R282      -0.0705728530883789
    z[1,0,5]  R283      6.1502200365066528e-01
    z[1,0,5]  R284      -3.3472391963005066e-01
    z[1,0,5]  R285      -3.5757660865783691e-01
    z[1,0,5]  R286      -7.8355483710765839e-02
    z[1,0,5]  R287      -1.3906839489936829e-01
    z[1,0,5]  R288      -1.8571268767118454e-02
    z[1,0,5]  R289      -2.0394992828369141e-01
    z[1,0,5]  R290      0.0060595260001719
    z[1,0,5]  R291      7.9848654568195343e-02
    z[1,0,5]  R292      3.7020778656005859e-01
    z[1,0,5]  R293      3.0023878812789917e-01
    z[1,0,5]  R294      -3.0967068672180176e-01
    z[1,0,5]  R295      -3.7857425212860107e-01
    z[1,0,5]  R296      -5.5424129962921143e-01
    z[1,0,5]  R297      5.4742813110351562e-01
    z[1,0,5]  R298      -2.9570639133453369e-01
    z[1,0,5]  R299      3.1599190831184387e-01
    z[1,0,5]  R300      2.6495385169982910e-01
    z[1,0,5]  R301      1.9240137934684753e-01
    z[1,0,5]  R302      -1.3365660607814789e-01
    z[1,0,5]  R303      3.4046092629432678e-01
    z[1,0,5]  R304      2.4582780897617340e-02
    z[1,0,5]  R305      1.8337704241275787e-01
    z[1,0,5]  R306      -1.9482944905757904e-01
    z[1,0,5]  R307      -1.8364679813385010e-01
    z[1,0,5]  R308      -0.193043053150177
    z[1,0,5]  R309      3.8441222906112671e-01
    z[1,0,5]  R310      1.2443643063306808e-01
    z[1,0,5]  R311      -1.4630503952503204e-01
    z[1,0,5]  R312      -3.8261435925960541e-02
    z[1,0,5]  R313      -1.8658266961574554e-01
    z[1,0,5]  R314      7.1583420038223267e-02
    z[1,0,5]  R315      2.6711371541023254e-01
    z[1,0,5]  R316      1.5770785510540009e-01
    z[1,0,5]  R317      -1.2754441797733307e-01
    z[1,0,5]  R318      -1.7384602129459381e-01
    z[1,0,5]  R319      -4.2658314108848572e-01
    z[1,0,5]  R320      5.4422867298126221e-01
    z[1,0,5]  R321      2.0371700823307037e-01
    z[1,0,5]  R322      3.4966117143630981e-01
    z[1,0,5]  R323      1.7822083830833435e-01
    z[1,0,5]  R324      3.6539715528488159e-01
    z[1,0,5]  R325      0.0839887410402298
    z[1,0,5]  R326      0.165176123380661
    z[1,0,5]  R327      -5.3859132528305054e-01
    z[1,0,5]  R328      -5.9076285362243652e-01
    z[1,0,5]  R329      -4.0633502602577209e-01
    z[1,0,5]  R330      -6.1492525041103363e-02
    z[1,0,5]  R331      -3.3974891901016235e-01
    z[1,0,5]  R332      -1.8887110054492950e-01
    z[1,0,5]  R333      -0.579322099685669
    z[1,0,5]  R334      -4.4994905591011047e-01
    z[1,0,5]  R335      -0.00333201652392745
    z[1,0,5]  R336      -4.9279722571372986e-01
    z[1,0,5]  R337      2.7345292270183563e-02
    z[1,0,5]  R338      -3.1193593144416809e-01
    z[1,0,5]  R339      3.1948056817054749e-01
    z[1,0,5]  R340      -4.8160004615783691e-01
    z[1,0,5]  R341      0.0496273897588253
    z[1,0,5]  R342      -1.6497241333127022e-02
    z[1,0,5]  R343      -2.9432615637779236e-01
    z[1,0,5]  R344      -3.0568757653236389e-01
    z[1,0,5]  R345      4.5855797827243805e-02
    z[1,0,5]  R346      3.6847241222858429e-02
    z[1,0,5]  R347      3.0827721953392029e-01
    z[1,0,5]  R348      3.6515498161315918e-01
    z[1,0,5]  R349      -1.5479294955730438e-01
    z[1,0,5]  R350      -5.7219195365905762e-01
    z[1,0,5]  R351      5.1941418647766113e-01
    z[1,0,5]  R352      -6.6952146589756012e-02
    z[1,0,5]  R353      -3.6570990085601807e-01
    z[1,0,5]  R354      -4.6580466628074646e-01
    z[1,0,5]  R355      2.4896523356437683e-01
    z[1,0,5]  R356      2.9639750719070435e-01
    z[1,0,5]  R357      0.634490430355072
    z[1,0,5]  R358      7.8915208578109741e-01
    z[1,0,5]  R359      7.5244468450546265e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R238      -1
    z[1,0,6]  R239      1
    z[1,0,6]  R240      -4.1296545416116714e-02
    z[1,0,6]  R241      4.7544579952955246e-02
    z[1,0,6]  R242      -2.8484994173049927e-01
    z[1,0,6]  R243      -3.4448447823524475e-01
    z[1,0,6]  R244      1.0768654197454453e-01
    z[1,0,6]  R245      -5.8732575178146362e-01
    z[1,0,6]  R246      1.0995424352586269e-02
    z[1,0,6]  R247      1.1395853757858276e-01
    z[1,0,6]  R248      -3.8139519095420837e-01
    z[1,0,6]  R249      7.5161732733249664e-02
    z[1,0,6]  R250      9.8768718540668488e-02
    z[1,0,6]  R251      -1.5962858498096466e-01
    z[1,0,6]  R252      -3.5750970244407654e-01
    z[1,0,6]  R253      -1.5360661782324314e-02
    z[1,0,6]  R254      -1.5741893649101257e-01
    z[1,0,6]  R255      3.2253009080886841e-01
    z[1,0,6]  R256      3.8437563180923462e-01
    z[1,0,6]  R257      -1.6234208643436432e-01
    z[1,0,6]  R258      -1.6507243737578392e-02
    z[1,0,6]  R259      8.9567065238952637e-02
    z[1,0,6]  R260      3.1049272045493126e-02
    z[1,0,6]  R261      1.2024573236703873e-01
    z[1,0,6]  R262      -0.277940034866333
    z[1,0,6]  R263      2.0571085810661316e-01
    z[1,0,6]  R264      7.1777604520320892e-02
    z[1,0,6]  R265      -1.4794050157070160e-01
    z[1,0,6]  R266      -7.2795733809471130e-02
    z[1,0,6]  R267      -3.8922619819641113e-01
    z[1,0,6]  R268      -1.8607042729854584e-01
    z[1,0,6]  R269      -1.2934499979019165e-01
    z[1,0,6]  R270      8.4637450054287910e-03
    z[1,0,6]  R271      1.3048601150512695e-01
    z[1,0,6]  R272      5.3298264741897583e-02
    z[1,0,6]  R273      -2.7908441424369812e-01
    z[1,0,6]  R274      1.6596347093582153e-01
    z[1,0,6]  R275      0.00876099057495594
    z[1,0,6]  R276      3.9219805598258972e-01
    z[1,0,6]  R277      2.2666966915130615e-01
    z[1,0,6]  R278      5.0538641214370728e-01
    z[1,0,6]  R279      4.1560640931129456e-01
    z[1,0,6]  R280      2.2250089049339294e-01
    z[1,0,6]  R281      4.8746901750564575e-01
    z[1,0,6]  R282      3.5872368607670069e-03
    z[1,0,6]  R283      0.087613046169281
    z[1,0,6]  R284      -5.4974645376205444e-01
    z[1,0,6]  R285      -2.0097108185291290e-01
    z[1,0,6]  R286      -1.6633279621601105e-01
    z[1,0,6]  R287      3.9147740602493286e-01
    z[1,0,6]  R288      -2.4853512644767761e-01
    z[1,0,6]  R289      -5.5437427014112473e-02
    z[1,0,6]  R290      7.4375040829181671e-02
    z[1,0,6]  R291      6.3531458377838135e-02
    z[1,0,6]  R292      -6.5903551876544952e-02
    z[1,0,6]  R293      -6.2070630490779877e-02
    z[1,0,6]  R294      -9.2620790004730225e-02
    z[1,0,6]  R295      -2.5661420822143555e-01
    z[1,0,6]  R296      -2.8402399271726608e-02
    z[1,0,6]  R297      -1.0774499922990799e-01
    z[1,0,6]  R298      -0.587288498878479
    z[1,0,6]  R299      2.1513158082962036e-01
    z[1,0,6]  R300      7.7159710228443146e-02
    z[1,0,6]  R301      -8.0683961510658264e-02
    z[1,0,6]  R302      0.139371857047081
    z[1,0,6]  R303      -4.4379360973834991e-02
    z[1,0,6]  R304      -2.4302257597446442e-01
    z[1,0,6]  R305      1.3012232258915901e-02
    z[1,0,6]  R306      1.4325623214244843e-01
    z[1,0,6]  R307      2.0397785305976868e-01
    z[1,0,6]  R308      -4.3918332457542419e-01
    z[1,0,6]  R309      -2.7320069074630737e-01
    z[1,0,6]  R310      -2.1874524652957916e-02
    z[1,0,6]  R311      1.2172093987464905e-01
    z[1,0,6]  R312      -9.6303343772888184e-02
    z[1,0,6]  R313      1.5148496627807617e-01
    z[1,0,6]  R314      1.5535451471805573e-01
    z[1,0,6]  R315      -1.8742421269416809e-01
    z[1,0,6]  R316      -5.0384610891342163e-01
    z[1,0,6]  R317      -4.7202232480049133e-01
    z[1,0,6]  R318      -1.9704076647758484e-01
    z[1,0,6]  R319      5.0386947393417358e-01
    z[1,0,6]  R320      1.7277951538562775e-01
    z[1,0,6]  R321      1.2333349883556366e-01
    z[1,0,6]  R322      -4.1507761925458908e-02
    z[1,0,6]  R323      2.0936825871467590e-01
    z[1,0,6]  R324      -3.0899370089173317e-02
    z[1,0,6]  R325      8.7542489171028137e-02
    z[1,0,6]  R326      3.0347725842148066e-03
    z[1,0,6]  R327      -1.9770814478397369e-01
    z[1,0,6]  R328      -5.8251347392797470e-02
    z[1,0,6]  R329      -1.0866452008485794e-02
    z[1,0,6]  R330      -3.1294006109237671e-01
    z[1,0,6]  R331      -6.9185465574264526e-02
    z[1,0,6]  R332      -3.0267012119293213e-01
    z[1,0,6]  R333      -1.1578613519668579e-01
    z[1,0,6]  R334      -1.8573486804962158e-01
    z[1,0,6]  R335      -2.0713666081428528e-01
    z[1,0,6]  R336      2.2767202556133270e-01
    z[1,0,6]  R337      5.0874944776296616e-02
    z[1,0,6]  R338      3.7979960907250643e-03
    z[1,0,6]  R339      1.3695596717298031e-02
    z[1,0,6]  R340      5.6516444683074951e-01
    z[1,0,6]  R341      1.7001870274543762e-01
    z[1,0,6]  R342      -2.3594453930854797e-01
    z[1,0,6]  R343      -5.4452878236770630e-01
    z[1,0,6]  R344      -2.3469147086143494e-01
    z[1,0,6]  R345      -4.3339309096336365e-01
    z[1,0,6]  R346      3.3968454599380493e-01
    z[1,0,6]  R347      5.2589696645736694e-01
    z[1,0,6]  R348      6.7241585254669189e-01
    z[1,0,6]  R349      2.0722452551126480e-02
    z[1,0,6]  R350      -1.1373517662286758e-01
    z[1,0,6]  R351      6.3404709100723267e-01
    z[1,0,6]  R352      0.623392641544342
    z[1,0,6]  R353      -2.8832862153649330e-02
    z[1,0,6]  R354      1.1271952837705612e-01
    z[1,0,6]  R355      -9.2097982764244080e-02
    z[1,0,6]  R356      5.4710201919078827e-02
    z[1,0,6]  R357      -9.3675032258033752e-02
    z[1,0,6]  R358      -7.3648296296596527e-02
    z[1,0,6]  R359      -5.7028006762266159e-02
    z[0,7,0]  R2        -1
    z[0,7,0]  R65       1
    z[0,7,0]  R360      -1
    z[0,7,0]  R361      1
    z[0,7,0]  R374      0.620798647403717
    z[0,7,0]  R375      5.2654927968978882e-01
    z[0,7,0]  R376      0.462368905544281
    z[0,7,0]  R377      1.3268569111824036e-01
    z[0,7,0]  R378      1.5740792453289032e-01
    z[0,7,0]  R379      -1.3772873580455780e-01
    z[0,7,0]  R380      5.1359629631042480e-01
    z[0,7,0]  R381      1.8717673420906067e-01
    z[0,7,0]  R382      7.0190334320068359e-01
    z[0,7,0]  R383      -1.2152490764856339e-01
    z[0,7,0]  R384      -3.8810375332832336e-01
    z[0,7,0]  R385      -1.6573785245418549e-01
    z[0,7,0]  R386      -3.1329813599586487e-01
    z[0,7,0]  R387      -3.6065387725830078e-01
    z[0,7,0]  R388      -1.4641138911247253e-01
    z[0,7,0]  R389      -3.8380718231201172e-01
    z[0,7,0]  R390      -1.9463101029396057e-01
    z[0,7,0]  R391      -2.1786668896675110e-01
    z[0,7,0]  R392      -3.5266622900962830e-01
    z[0,7,0]  R393      1.3635067641735077e-01
    z[0,7,0]  R394      -4.0896780788898468e-02
    z[0,7,0]  R395      -1.0298158973455429e-01
    z[0,7,0]  R396      -2.5520476698875427e-01
    z[0,7,0]  R397      -4.1922938078641891e-02
    z[0,7,0]  R398      -5.3105160593986511e-02
    z[0,7,0]  R399      2.2029291093349457e-01
    z[0,7,0]  R400      -1.6303269565105438e-01
    z[0,7,0]  R401      4.5278385281562805e-01
    z[0,7,0]  R402      3.0736759305000305e-01
    z[0,7,0]  R403      2.5611084699630737e-01
    z[0,7,0]  R404      1.6221153736114502e-01
    z[0,7,0]  R405      1.0434409230947495e-01
    z[0,7,0]  R406      -1.9514784216880798e-01
    z[0,7,0]  R407      2.0719854533672333e-01
    z[0,7,0]  R408      -4.5424412935972214e-02
    z[0,7,0]  R409      -5.9812828898429871e-02
    z[0,7,0]  R410      1.2708221375942230e-01
    z[0,7,0]  R411      4.8202324658632278e-02
    z[0,7,0]  R412      4.0944972634315491e-01
    z[0,7,0]  R413      9.1523610055446625e-02
    z[0,7,0]  R414      4.2951118946075439e-01
    z[0,7,0]  R415      -3.9567712694406509e-02
    z[0,7,0]  R416      -3.1187409535050392e-02
    z[0,7,0]  R417      7.9985029995441437e-02
    z[0,7,0]  R418      4.0240153670310974e-01
    z[0,7,0]  R419      2.4220819771289825e-01
    z[0,7,0]  R420      -0.302153080701828
    z[0,7,0]  R421      2.0053511857986450e-01
    z[0,7,0]  R422      -2.2063534706830978e-02
    z[0,7,0]  R423      -2.2748107090592384e-02
    z[0,7,0]  R424      2.3923364281654358e-01
    z[0,7,0]  R425      2.6735377311706543e-01
    z[0,7,0]  R426      2.5035685300827026e-01
    z[0,7,0]  R427      -1.0845737904310226e-01
    z[0,7,0]  R428      7.5069174170494080e-02
    z[0,7,0]  R429      -5.2948564291000366e-02
    z[0,7,0]  R430      3.5006088018417358e-01
    z[0,7,0]  R431      -2.5894674658775330e-01
    z[0,7,0]  R432      -2.6131308078765869e-01
    z[0,7,0]  R433      -1.0611040890216827e-01
    z[0,7,0]  R434      0.56584632396698
    z[0,7,0]  R435      3.8680833578109741e-01
    z[0,7,0]  R436      3.1114852428436279e-01
    z[0,7,0]  R437      2.8785562515258789e-01
    z[0,7,0]  R438      3.1329560279846191e-01
    z[0,7,0]  R439      6.3915866613388062e-01
    z[0,7,0]  R440      6.1947333812713623e-01
    z[0,7,0]  R441      -3.6312767863273621e-01
    z[0,7,0]  R442      -1.4555731415748596e-01
    z[0,7,0]  R443      1.5721313655376434e-01
    z[0,7,0]  R444      -0.337566077709198
    z[0,7,0]  R445      -4.3169227242469788e-01
    z[0,7,0]  R446      -6.1430495977401733e-01
    z[0,7,0]  R447      -4.2309236526489258e-01
    z[0,7,0]  R448      -6.2170523405075073e-01
    z[0,7,0]  R449      -6.3902544975280762e-01
    z[0,7,0]  R450      -1.3756404817104340e-01
    z[0,7,0]  R451      -5.1230460405349731e-01
    z[0,7,0]  R452      -7.5247043371200562e-01
    z[0,7,0]  R453      -4.0488809347152710e-01
    z[0,7,0]  R454      2.0064330101013184e-01
    z[0,7,0]  R455      -2.8924819827079773e-01
    z[0,7,0]  R456      2.7174675464630127e-01
    z[0,7,0]  R457      -8.5789456963539124e-02
    z[0,7,0]  R458      -6.6463607549667358e-01
    z[0,7,0]  R459      4.3180355429649353e-01
    z[0,7,0]  R460      -3.8987055420875549e-01
    z[0,7,0]  R461      0.343079149723053
    z[0,7,0]  R462      -2.0219059288501740e-01
    z[0,7,0]  R463      2.2271190583705902e-01
    z[0,7,0]  R464      3.1970273703336716e-02
    z[0,7,0]  R465      8.0609925091266632e-02
    z[0,7,0]  R466      5.9101927280426025e-01
    z[0,7,0]  R467      -2.2363428771495819e-01
    z[0,7,0]  R468      -2.9740871861577034e-02
    z[0,7,0]  R469      2.7416062355041504e-01
    z[0,7,0]  R470      -1.0326413810253143e-01
    z[0,7,0]  R471      -1.7664854228496552e-01
    z[0,7,0]  R472      -5.9103786945343018e-01
    z[0,7,0]  R473      -2.7790278196334839e-01
    z[0,7,1]  R3        -1
    z[0,7,1]  R66       1
    z[0,7,1]  R362      -1
    z[0,7,1]  R363      1
    z[0,7,1]  R374      -5.2527648210525513e-01
    z[0,7,1]  R375      -7.6045840978622437e-01
    z[0,7,1]  R376      -2.5633433461189270e-01
    z[0,7,1]  R377      -8.1234443187713623e-01
    z[0,7,1]  R378      -5.2500879764556885e-01
    z[0,7,1]  R379      -8.3281147480010986e-01
    z[0,7,1]  R380      -4.5282069593667984e-02
    z[0,7,1]  R381      -6.6825169324874878e-01
    z[0,7,1]  R382      9.4174752011895180e-03
    z[0,7,1]  R383      -4.4155597686767578e-01
    z[0,7,1]  R384      0.336871862411499
    z[0,7,1]  R385      4.4043898582458496e-01
    z[0,7,1]  R386      5.4839485883712769e-01
    z[0,7,1]  R387      2.0966002345085144e-01
    z[0,7,1]  R388      3.0229339003562927e-01
    z[0,7,1]  R389      3.9771580696105957e-01
    z[0,7,1]  R390      2.9277262091636658e-01
    z[0,7,1]  R391      2.0392750203609467e-01
    z[0,7,1]  R392      4.5268815755844116e-01
    z[0,7,1]  R393      5.1453071832656860e-01
    z[0,7,1]  R394      1.6954012215137482e-01
    z[0,7,1]  R395      -4.2636382579803467e-01
    z[0,7,1]  R396      4.4002529978752136e-01
    z[0,7,1]  R397      6.4283883571624756e-01
    z[0,7,1]  R398      -6.4902478456497192e-01
    z[0,7,1]  R399      -7.3591619729995728e-01
    z[0,7,1]  R400      1.1351312696933746e-01
    z[0,7,1]  R401      -6.2721645832061768e-01
    z[0,7,1]  R402      -0.582633376121521
    z[0,7,1]  R403      -6.8468379974365234e-01
    z[0,7,1]  R404      1.4159551262855530e-01
    z[0,7,1]  R405      4.7614101320505142e-02
    z[0,7,1]  R406      4.0677130222320557e-01
    z[0,7,1]  R407      3.2636293768882751e-01
    z[0,7,1]  R408      4.5732742547988892e-01
    z[0,7,1]  R409      -7.8393936157226562e-01
    z[0,7,1]  R410      6.3165462017059326e-01
    z[0,7,1]  R411      -9.3769985437393188e-01
    z[0,7,1]  R412      -8.0721575021743774e-01
    z[0,7,1]  R413      -5.4238897562026978e-01
    z[0,7,1]  R414      2.5861972570419312e-01
    z[0,7,1]  R415      -9.6798247098922729e-01
    z[0,7,1]  R416      -6.7429274320602417e-01
    z[0,7,1]  R417      -7.2020101547241211e-01
    z[0,7,1]  R418      2.9705107212066650e-01
    z[0,7,1]  R419      3.9390709996223450e-01
    z[0,7,1]  R420      1.5610887110233307e-01
    z[0,7,1]  R421      -4.3803668022155762e-01
    z[0,7,1]  R422      -4.0859362483024597e-01
    z[0,7,1]  R423      -6.4626979827880859e-01
    z[0,7,1]  R424      -2.8822859749197960e-02
    z[0,7,1]  R425      -1.3212330639362335e-01
    z[0,7,1]  R426      -4.8857319355010986e-01
    z[0,7,1]  R427      2.1396249532699585e-01
    z[0,7,1]  R428      -6.9400328397750854e-01
    z[0,7,1]  R429      3.4333273768424988e-01
    z[0,7,1]  R430      -4.4806605577468872e-01
    z[0,7,1]  R431      -4.6262946724891663e-01
    z[0,7,1]  R432      -3.0958941578865051e-01
    z[0,7,1]  R433      -1.9974282383918762e-01
    z[0,7,1]  R434      -7.2112256288528442e-01
    z[0,7,1]  R435      -6.0716563463211060e-01
    z[0,7,1]  R436      -4.7086629271507263e-01
    z[0,7,1]  R437      -4.8536252975463867e-01
    z[0,7,1]  R438      -4.4142702221870422e-01
    z[0,7,1]  R439      -3.5772338509559631e-02
    z[0,7,1]  R440      -1.1704052239656448e-01
    z[0,7,1]  R441      -8.4566110372543335e-01
    z[0,7,1]  R442      -7.9250574111938477e-01
    z[0,7,1]  R443      5.1438021659851074e-01
    z[0,7,1]  R444      4.7565326094627380e-01
    z[0,7,1]  R445      5.1896393299102783e-01
    z[0,7,1]  R446      5.3056395053863525e-01
    z[0,7,1]  R447      4.3915295600891113e-01
    z[0,7,1]  R448      4.2227533459663391e-01
    z[0,7,1]  R449      4.2494386434555054e-01
    z[0,7,1]  R450      1.5499807894229889e-01
    z[0,7,1]  R451      4.4935676455497742e-01
    z[0,7,1]  R452      4.9008226394653320e-01
    z[0,7,1]  R453      6.5573644638061523e-01
    z[0,7,1]  R454      -7.9547427594661713e-02
    z[0,7,1]  R455      5.8217358589172363e-01
    z[0,7,1]  R456      4.4434210658073425e-01
    z[0,7,1]  R457      6.3792675733566284e-01
    z[0,7,1]  R458      2.3921658098697662e-01
    z[0,7,1]  R459      1.3692812621593475e-01
    z[0,7,1]  R460      -3.5033699870109558e-01
    z[0,7,1]  R461      2.3405049741268158e-01
    z[0,7,1]  R462      -5.1957017183303833e-01
    z[0,7,1]  R463      5.6142288446426392e-01
    z[0,7,1]  R464      1.9173850119113922e-01
    z[0,7,1]  R465      -6.3599482178688049e-02
    z[0,7,1]  R466      3.2843938469886780e-01
    z[0,7,1]  R467      -6.9322896003723145e-01
    z[0,7,1]  R468      3.4201240539550781e-01
    z[0,7,1]  R469      -8.2714691758155823e-02
    z[0,7,1]  R470      0.0487123504281044
    z[0,7,1]  R471      1.3683560490608215e-01
    z[0,7,1]  R472      -5.1087313890457153e-01
    z[0,7,1]  R473      8.6742222309112549e-02
    z[0,7,2]  R4        -1
    z[0,7,2]  R67       1
    z[0,7,2]  R364      -1
    z[0,7,2]  R365      1
    z[0,7,2]  R374      2.8240248560905457e-01
    z[0,7,2]  R375      0.145859956741333
    z[0,7,2]  R376      -4.8697876930236816e-01
    z[0,7,2]  R377      4.4901812076568604e-01
    z[0,7,2]  R378      0.73260498046875
    z[0,7,2]  R379      2.6689371466636658e-01
    z[0,7,2]  R380      6.9678300619125366e-01
    z[0,7,2]  R381      -6.3427609205245972e-01
    z[0,7,2]  R382      -4.9273434281349182e-01
    z[0,7,2]  R383      2.7878072857856750e-01
    z[0,7,2]  R384      2.7123796939849854e-01
    z[0,7,2]  R385      3.3787584304809570e-01
    z[0,7,2]  R386      4.5626482367515564e-01
    z[0,7,2]  R387      5.3327459096908569e-01
    z[0,7,2]  R388      2.6201978325843811e-01
    z[0,7,2]  R389      2.1138642728328705e-01
    z[0,7,2]  R390      1.2170034646987915e-01
    z[0,7,2]  R391      -7.8172661364078522e-02
    z[0,7,2]  R392      -2.7911770343780518e-01
    z[0,7,2]  R393      -3.5881170630455017e-01
    z[0,7,2]  R394      -3.0714237689971924e-01
    z[0,7,2]  R395      -4.1826552152633667e-01
    z[0,7,2]  R396      -6.2289965152740479e-01
    z[0,7,2]  R397      -6.6303437948226929e-01
    z[0,7,2]  R398      -2.7375000715255737e-01
    z[0,7,2]  R399      -1.0064578801393509e-01
    z[0,7,2]  R400      -7.7345591783523560e-01
    z[0,7,2]  R401      -1.1731107532978058e-01
    z[0,7,2]  R402      -3.5247454047203064e-01
    z[0,7,2]  R403      -6.3121385872364044e-02
    z[0,7,2]  R404      -9.9313713610172272e-02
    z[0,7,2]  R405      -8.2837289571762085e-01
    z[0,7,2]  R406      -8.0990833044052124e-01
    z[0,7,2]  R407      -5.9784799814224243e-01
    z[0,7,2]  R408      -5.1879543066024780e-01
    z[0,7,2]  R409      -3.8309359550476074e-01
    z[0,7,2]  R410      -4.7910192608833313e-01
    z[0,7,2]  R411      -4.6313893049955368e-02
    z[0,7,2]  R412      1.7006424069404602e-01
    z[0,7,2]  R413      1.9337338209152222e-01
    z[0,7,2]  R414      -1.1138269305229187e-01
    z[0,7,2]  R415      -1.0139747709035873e-01
    z[0,7,2]  R416      -6.2791548669338226e-02
    z[0,7,2]  R417      -8.6022213101387024e-02
    z[0,7,2]  R418      3.9707577228546143e-01
    z[0,7,2]  R419      6.3471257686614990e-01
    z[0,7,2]  R420      -6.6998451948165894e-01
    z[0,7,2]  R421      5.1057374477386475e-01
    z[0,7,2]  R422      4.7518399357795715e-01
    z[0,7,2]  R423      -5.5646121501922607e-02
    z[0,7,2]  R424      2.1809941530227661e-01
    z[0,7,2]  R425      -6.7226584069430828e-03
    z[0,7,2]  R426      1.0934574529528618e-02
    z[0,7,2]  R427      5.5326181463897228e-03
    z[0,7,2]  R428      -2.4967899918556213e-01
    z[0,7,2]  R429      7.6059329509735107e-01
    z[0,7,2]  R430      4.9448895454406738e-01
    z[0,7,2]  R431      4.0338733792304993e-01
    z[0,7,2]  R432      3.7548035383224487e-01
    z[0,7,2]  R433      0.501044511795044
    z[0,7,2]  R434      1.5238769352436066e-01
    z[0,7,2]  R435      3.8924619555473328e-01
    z[0,7,2]  R436      1.3544920086860657e-01
    z[0,7,2]  R437      6.2276750802993774e-01
    z[0,7,2]  R438      -5.7281100749969482e-01
    z[0,7,2]  R439      3.1706255674362183e-01
    z[0,7,2]  R440      -7.3331922292709351e-01
    z[0,7,2]  R441      2.8229501843452454e-01
    z[0,7,2]  R442      2.0769460499286652e-01
    z[0,7,2]  R443      -5.9686416387557983e-01
    z[0,7,2]  R444      7.2961330413818359e-01
    z[0,7,2]  R445      4.3422129750251770e-01
    z[0,7,2]  R446      3.8158121705055237e-01
    z[0,7,2]  R447      0.550506055355072
    z[0,7,2]  R448      3.2392820715904236e-01
    z[0,7,2]  R449      2.4571396410465240e-01
    z[0,7,2]  R450      0.067622110247612
    z[0,7,2]  R451      0.459238737821579
    z[0,7,2]  R452      3.2472480088472366e-02
    z[0,7,2]  R453      2.7156364917755127e-01
    z[0,7,2]  R454      -1.8956419825553894e-01
    z[0,7,2]  R455      -6.9618624448776245e-01
    z[0,7,2]  R456      -3.2738870382308960e-01
    z[0,7,2]  R457      -4.9386900663375854e-01
    z[0,7,2]  R458      -5.8306747674942017e-01
    z[0,7,2]  R459      1.5498754382133484e-01
    z[0,7,2]  R460      -1.3371452689170837e-01
    z[0,7,2]  R461      -3.7353730201721191e-01
    z[0,7,2]  R462      -2.8236207365989685e-01
    z[0,7,2]  R463      -5.8703833818435669e-01
    z[0,7,2]  R464      -1.8302412331104279e-01
    z[0,7,2]  R465      8.9372813701629639e-02
    z[0,7,2]  R466      -1.2978021800518036e-01
    z[0,7,2]  R467      6.9510176777839661e-02
    z[0,7,2]  R468      5.3976005315780640e-01
    z[0,7,2]  R469      -8.5104942321777344e-01
    z[0,7,2]  R470      -7.3560386896133423e-01
    z[0,7,2]  R471      -4.1516625881195068e-01
    z[0,7,2]  R472      -2.0120188593864441e-01
    z[0,7,2]  R473      -4.5631888508796692e-01
    z[0,7,3]  R5        -1
    z[0,7,3]  R68       1
    z[0,7,3]  R366      -1
    z[0,7,3]  R367      1
    z[0,7,3]  R374      -4.2973395437002182e-02
    z[0,7,3]  R375      -2.6564297080039978e-01
    z[0,7,3]  R376      -1.2342379242181778e-01
    z[0,7,3]  R377      5.4581563919782639e-02
    z[0,7,3]  R378      7.4223875999450684e-02
    z[0,7,3]  R379      -8.6148120462894440e-02
    z[0,7,3]  R380      -2.2465391457080841e-01
    z[0,7,3]  R381      -1.4569766819477081e-01
    z[0,7,3]  R382      -1.1452665925025940e-01
    z[0,7,3]  R383      -2.2144512832164764e-01
    z[0,7,3]  R384      7.7179753780364990e-01
    z[0,7,3]  R385      7.7670842409133911e-01
    z[0,7,3]  R386      4.2458295822143555e-01
    z[0,7,3]  R387      5.3509742021560669e-01
    z[0,7,3]  R388      8.8359820842742920e-01
    z[0,7,3]  R389      7.1848428249359131e-01
    z[0,7,3]  R390      7.4888008832931519e-01
    z[0,7,3]  R391      8.1281745433807373e-01
    z[0,7,3]  R392      6.4981228113174438e-01
    z[0,7,3]  R393      3.4159621596336365e-01
    z[0,7,3]  R394      -7.3769712448120117e-01
    z[0,7,3]  R395      -7.5746411085128784e-01
    z[0,7,3]  R396      -3.2506421208381653e-01
    z[0,7,3]  R397      1.0737046599388123e-02
    z[0,7,3]  R398      -2.7211424708366394e-01
    z[0,7,3]  R399      -1.4180260896682739e-01
    z[0,7,3]  R400      -9.1851547360420227e-02
    z[0,7,3]  R401      -0.193960040807724
    z[0,7,3]  R402      -2.9411277174949646e-01
    z[0,7,3]  R403      -2.3583996295928955e-01
    z[0,7,3]  R404      -8.8795667886734009e-01
    z[0,7,3]  R405      -1.4621990919113159e-01
    z[0,7,3]  R406      5.4085712879896164e-02
    z[0,7,3]  R407      2.6164343953132629e-01
    z[0,7,3]  R408      -2.8413820266723633e-01
    z[0,7,3]  R409      -4.3831738829612732e-01
    z[0,7,3]  R410      -1.9417501986026764e-01
    z[0,7,3]  R411      -3.3469071984291077e-01
    z[0,7,3]  R412      -0.192152202129364
    z[0,7,3]  R413      -7.4606943130493164e-01
    z[0,7,3]  R414      -4.2095720767974854e-01
    z[0,7,3]  R415      -1.1743719130754471e-01
    z[0,7,3]  R416      -5.9809368848800659e-01
    z[0,7,3]  R417      2.8989285230636597e-01
    z[0,7,3]  R418      5.8652019500732422e-01
    z[0,7,3]  R419      4.0933492779731750e-01
    z[0,7,3]  R420      -5.1661711931228638e-01
    z[0,7,3]  R421      -5.6924719363451004e-02
    z[0,7,3]  R422      -1.4558336138725281e-01
    z[0,7,3]  R423      7.0159655809402466e-01
    z[0,7,3]  R424      -1.7490082979202271e-01
    z[0,7,3]  R425      -4.4254866242408752e-01
    z[0,7,3]  R426      -5.4232919216156006e-01
    z[0,7,3]  R427      8.7038993835449219e-01
    z[0,7,3]  R428      -2.5695204734802246e-01
    z[0,7,3]  R429      4.2477965354919434e-01
    z[0,7,3]  R430      -2.2404132783412933e-01
    z[0,7,3]  R431      -1.2913145124912262e-01
    z[0,7,3]  R432      -2.1360759437084198e-01
    z[0,7,3]  R433      -9.8005183041095734e-02
    z[0,7,3]  R434      -1.9879573583602905e-01
    z[0,7,3]  R435      -1.2019961327314377e-01
    z[0,7,3]  R436      -2.1669751405715942e-01
    z[0,7,3]  R437      -1.7680196464061737e-01
    z[0,7,3]  R438      -1.1830183863639832e-01
    z[0,7,3]  R439      -2.1421962976455688e-01
    z[0,7,3]  R440      -1.0761692374944687e-01
    z[0,7,3]  R441      1.9323322176933289e-01
    z[0,7,3]  R442      2.0005673170089722e-01
    z[0,7,3]  R443      3.9944455027580261e-01
    z[0,7,3]  R444      2.5041863322257996e-01
    z[0,7,3]  R445      2.5284075736999512e-01
    z[0,7,3]  R446      7.8956015408039093e-02
    z[0,7,3]  R447      3.5475313663482666e-01
    z[0,7,3]  R448      4.1027444601058960e-01
    z[0,7,3]  R449      3.6534574627876282e-01
    z[0,7,3]  R450      -9.1493481397628784e-01
    z[0,7,3]  R451      2.1414358913898468e-01
    z[0,7,3]  R452      2.4445576965808868e-01
    z[0,7,3]  R453      3.4286347031593323e-01
    z[0,7,3]  R454      -6.6909611225128174e-01
    z[0,7,3]  R455      -8.4517627954483032e-02
    z[0,7,3]  R456      -5.9091800451278687e-01
    z[0,7,3]  R457      -3.9055764675140381e-01
    z[0,7,3]  R458      -1.2892629206180573e-01
    z[0,7,3]  R459      -4.0681746602058411e-01
    z[0,7,3]  R460      -7.3988062143325806e-01
    z[0,7,3]  R461      -7.0957213640213013e-01
    z[0,7,3]  R462      -5.8777654170989990e-01
    z[0,7,3]  R463      1.9040267169475555e-01
    z[0,7,3]  R464      -8.9693957567214966e-01
    z[0,7,3]  R465      -9.2326998710632324e-01
    z[0,7,3]  R466      -5.1264625042676926e-02
    z[0,7,3]  R467      -2.4642907083034515e-01
    z[0,7,3]  R468      -5.7452076673507690e-01
    z[0,7,3]  R469      -3.1194803118705750e-01
    z[0,7,3]  R470      4.3479931354522705e-01
    z[0,7,3]  R471      3.0651673674583435e-01
    z[0,7,3]  R472      -4.3567517399787903e-01
    z[0,7,3]  R473      4.9107018113136292e-01
    z[0,7,4]  R6        -1
    z[0,7,4]  R69       1
    z[0,7,4]  R368      -1
    z[0,7,4]  R369      1
    z[0,7,4]  R374      4.2537233233451843e-01
    z[0,7,4]  R375      -9.5285743474960327e-02
    z[0,7,4]  R376      6.5638190507888794e-01
    z[0,7,4]  R377      3.3855831716209650e-03
    z[0,7,4]  R378      3.1257805228233337e-01
    z[0,7,4]  R379      4.1833665966987610e-01
    z[0,7,4]  R380      3.7378013134002686e-01
    z[0,7,4]  R381      1.3977633416652679e-01
    z[0,7,4]  R382      1.4557459950447083e-01
    z[0,7,4]  R383      6.6414761543273926e-01
    z[0,7,4]  R384      -2.2514109313488007e-01
    z[0,7,4]  R385      1.5775656700134277e-01
    z[0,7,4]  R386      -4.4935601949691772e-01
    z[0,7,4]  R387      -4.4440931081771851e-01
    z[0,7,4]  R388      -9.2320390045642853e-02
    z[0,7,4]  R389      1.6472026705741882e-01
    z[0,7,4]  R390      -1.4845220744609833e-01
    z[0,7,4]  R391      7.1356974542140961e-02
    z[0,7,4]  R392      3.1857442855834961e-01
    z[0,7,4]  R393      -1.8808278441429138e-01
    z[0,7,4]  R394      -7.0799104869365692e-02
    z[0,7,4]  R395      -4.6892590820789337e-02
    z[0,7,4]  R396      -3.5155621170997620e-01
    z[0,7,4]  R397      -2.6395657658576965e-01
    z[0,7,4]  R398      -5.4082489013671875e-01
    z[0,7,4]  R399      -6.0410511493682861e-01
    z[0,7,4]  R400      -5.7146471738815308e-01
    z[0,7,4]  R401      -1.4503400027751923e-01
    z[0,7,4]  R402      5.4119382053613663e-02
    z[0,7,4]  R403      -4.9069771170616150e-01
    z[0,7,4]  R404      2.3150597512722015e-01
    z[0,7,4]  R405      -3.9880722761154175e-01
    z[0,7,4]  R406      -1.0147042572498322e-01
    z[0,7,4]  R407      -2.7505621314048767e-01
    z[0,7,4]  R408      4.4939219951629639e-01
    z[0,7,4]  R409      -7.8716287389397621e-03
    z[0,7,4]  R410      1.5144766867160797e-01
    z[0,7,4]  R411      -2.9947564005851746e-02
    z[0,7,4]  R412      -1.3263091444969177e-01
    z[0,7,4]  R413      -3.4195877611637115e-02
    z[0,7,4]  R414      8.7610080838203430e-02
    z[0,7,4]  R415      -7.7473089098930359e-02
    z[0,7,4]  R416      3.5602787137031555e-01
    z[0,7,4]  R417      -1.8323583528399467e-02
    z[0,7,4]  R418      -3.1564787030220032e-01
    z[0,7,4]  R419      -1.6070117056369781e-01
    z[0,7,4]  R420      2.2763521969318390e-01
    z[0,7,4]  R421      -3.6384207010269165e-01
    z[0,7,4]  R422      9.4340629875659943e-03
    z[0,7,4]  R423      -2.4918565154075623e-01
    z[0,7,4]  R424      7.2349125146865845e-01
    z[0,7,4]  R425      -2.0824027061462402e-01
    z[0,7,4]  R426      -1.0618934780359268e-01
    z[0,7,4]  R427      2.2421617805957794e-01
    z[0,7,4]  R428      3.9329430460929871e-01
    z[0,7,4]  R429      2.2341303527355194e-01
    z[0,7,4]  R430      -5.3956985473632812e-01
    z[0,7,4]  R431      -3.5801011323928833e-01
    z[0,7,4]  R432      -1.4515841007232666e-01
    z[0,7,4]  R433      -3.4462669491767883e-01
    z[0,7,4]  R434      2.8136044740676880e-01
    z[0,7,4]  R435      1.3414669036865234e-01
    z[0,7,4]  R436      6.0929656028747559e-01
    z[0,7,4]  R437      4.6493580937385559e-01
    z[0,7,4]  R438      5.9276384115219116e-01
    z[0,7,4]  R439      5.8546477556228638e-01
    z[0,7,4]  R440      -9.6167489886283875e-02
    z[0,7,4]  R441      -1.0068996995687485e-01
    z[0,7,4]  R442      -1.6605491936206818e-01
    z[0,7,4]  R443      3.6492672562599182e-01
    z[0,7,4]  R444      -2.4456101655960083e-01
    z[0,7,4]  R445      -2.1529795229434967e-01
    z[0,7,4]  R446      -2.6367521286010742e-01
    z[0,7,4]  R447      2.7901515364646912e-01
    z[0,7,4]  R448      2.8647467494010925e-01
    z[0,7,4]  R449      9.8640955984592438e-02
    z[0,7,4]  R450      -3.3423733711242676e-01
    z[0,7,4]  R451      5.5307867005467415e-03
    z[0,7,4]  R452      -2.2386403381824493e-01
    z[0,7,4]  R453      -3.8595151901245117e-01
    z[0,7,4]  R454      -1.9395154714584351e-01
    z[0,7,4]  R455      -1.3204665482044220e-01
    z[0,7,4]  R456      4.1910582780838013e-01
    z[0,7,4]  R457      1.9031862914562225e-01
    z[0,7,4]  R458      -2.3103572428226471e-01
    z[0,7,4]  R459      7.7144846320152283e-02
    z[0,7,4]  R460      0.0887860581278801
    z[0,7,4]  R461      -3.5474222898483276e-01
    z[0,7,4]  R462      -4.5493033528327942e-01
    z[0,7,4]  R463      4.9308523535728455e-02
    z[0,7,4]  R464      3.2211273908615112e-01
    z[0,7,4]  R465      2.5527609977871180e-03
    z[0,7,4]  R466      0.415828675031662
    z[0,7,4]  R467      -2.0532572269439697e-01
    z[0,7,4]  R468      1.3875405490398407e-01
    z[0,7,4]  R469      -3.2913282513618469e-02
    z[0,7,4]  R470      4.0149144828319550e-02
    z[0,7,4]  R471      2.2124961018562317e-01
    z[0,7,4]  R472      -5.4027330130338669e-02
    z[0,7,4]  R473      3.3655592799186707e-01
    z[0,7,5]  R7        -1
    z[0,7,5]  R70       1
    z[0,7,5]  R370      -1
    z[0,7,5]  R371      1
    z[0,7,5]  R374      2.6495385169982910e-01
    z[0,7,5]  R375      1.9240137934684753e-01
    z[0,7,5]  R376      -1.3365660607814789e-01
    z[0,7,5]  R377      3.4046092629432678e-01
    z[0,7,5]  R378      2.4582780897617340e-02
    z[0,7,5]  R379      1.8337704241275787e-01
    z[0,7,5]  R380      -1.9482944905757904e-01
    z[0,7,5]  R381      -1.8364679813385010e-01
    z[0,7,5]  R382      -0.193043053150177
    z[0,7,5]  R383      3.8441222906112671e-01
    z[0,7,5]  R384      1.2443643063306808e-01
    z[0,7,5]  R385      -1.4630503952503204e-01
    z[0,7,5]  R386      -3.8261435925960541e-02
    z[0,7,5]  R387      -1.8658266961574554e-01
    z[0,7,5]  R388      7.1583420038223267e-02
    z[0,7,5]  R389      2.6711371541023254e-01
    z[0,7,5]  R390      1.5770785510540009e-01
    z[0,7,5]  R391      -1.2754441797733307e-01
    z[0,7,5]  R392      -1.7384602129459381e-01
    z[0,7,5]  R393      -4.2658314108848572e-01
    z[0,7,5]  R394      5.4422867298126221e-01
    z[0,7,5]  R395      2.0371700823307037e-01
    z[0,7,5]  R396      3.4966117143630981e-01
    z[0,7,5]  R397      1.7822083830833435e-01
    z[0,7,5]  R398      3.6539715528488159e-01
    z[0,7,5]  R399      0.0839887410402298
    z[0,7,5]  R400      0.165176123380661
    z[0,7,5]  R401      -5.3859132528305054e-01
    z[0,7,5]  R402      -5.9076285362243652e-01
    z[0,7,5]  R403      -4.0633502602577209e-01
    z[0,7,5]  R404      -6.1492525041103363e-02
    z[0,7,5]  R405      -3.3974891901016235e-01
    z[0,7,5]  R406      -1.8887110054492950e-01
    z[0,7,5]  R407      -0.579322099685669
    z[0,7,5]  R408      -4.4994905591011047e-01
    z[0,7,5]  R409      -0.00333201652392745
    z[0,7,5]  R410      -4.9279722571372986e-01
    z[0,7,5]  R411      2.7345292270183563e-02
    z[0,7,5]  R412      -3.1193593144416809e-01
    z[0,7,5]  R413      3.1948056817054749e-01
    z[0,7,5]  R414      -4.8160004615783691e-01
    z[0,7,5]  R415      0.0496273897588253
    z[0,7,5]  R416      -1.6497241333127022e-02
    z[0,7,5]  R417      -2.9432615637779236e-01
    z[0,7,5]  R418      -3.0568757653236389e-01
    z[0,7,5]  R419      4.5855797827243805e-02
    z[0,7,5]  R420      3.6847241222858429e-02
    z[0,7,5]  R421      3.0827721953392029e-01
    z[0,7,5]  R422      3.6515498161315918e-01
    z[0,7,5]  R423      -1.5479294955730438e-01
    z[0,7,5]  R424      -5.7219195365905762e-01
    z[0,7,5]  R425      5.1941418647766113e-01
    z[0,7,5]  R426      -6.6952146589756012e-02
    z[0,7,5]  R427      -3.6570990085601807e-01
    z[0,7,5]  R428      -4.6580466628074646e-01
    z[0,7,5]  R429      2.4896523356437683e-01
    z[0,7,5]  R430      2.9639750719070435e-01
    z[0,7,5]  R431      0.634490430355072
    z[0,7,5]  R432      7.8915208578109741e-01
    z[0,7,5]  R433      7.5244468450546265e-01
    z[0,7,5]  R434      1.2903597950935364e-01
    z[0,7,5]  R435      5.0718921422958374e-01
    z[0,7,5]  R436      4.9037474393844604e-01
    z[0,7,5]  R437      -1.2133947759866714e-01
    z[0,7,5]  R438      -4.3760299682617188e-02
    z[0,7,5]  R439      1.1665125936269760e-01
    z[0,7,5]  R440      -2.1996637806296349e-02
    z[0,7,5]  R441      1.4449493587017059e-01
    z[0,7,5]  R442      -1.3534571230411530e-01
    z[0,7,5]  R443      1.2469103187322617e-01
    z[0,7,5]  R444      4.2589064687490463e-02
    z[0,7,5]  R445      4.6388205885887146e-01
    z[0,7,5]  R446      6.5515274181962013e-03
    z[0,7,5]  R447      -3.1412345170974731e-01
    z[0,7,5]  R448      -1.1265028268098831e-01
    z[0,7,5]  R449      1.6476555168628693e-01
    z[0,7,5]  R450      -3.8684133440256119e-02
    z[0,7,5]  R451      -0.51753830909729
    z[0,7,5]  R452      -2.8312796354293823e-01
    z[0,7,5]  R453      -7.5021870434284210e-02
    z[0,7,5]  R454      -0.572472095489502
    z[0,7,5]  R455      -2.5666135549545288e-01
    z[0,7,5]  R456      -2.5014990568161011e-01
    z[0,7,5]  R457      -3.4819102287292480e-01
    z[0,7,5]  R458      -3.0022063851356506e-01
    z[0,7,5]  R459      -7.7347451448440552e-01
    z[0,7,5]  R460      -1.6917371749877930e-01
    z[0,7,5]  R461      2.4217553436756134e-01
    z[0,7,5]  R462      -5.9445660561323166e-02
    z[0,7,5]  R463      -4.9349084496498108e-01
    z[0,7,5]  R464      1.0130524635314941e-01
    z[0,7,5]  R465      -3.2140168547630310e-01
    z[0,7,5]  R466      -5.9102743864059448e-01
    z[0,7,5]  R467      -5.9029066562652588e-01
    z[0,7,5]  R468      4.5784175395965576e-01
    z[0,7,5]  R469      -1.1757113784551620e-01
    z[0,7,5]  R470      -4.3659603595733643e-01
    z[0,7,5]  R471      -0.759149968624115
    z[0,7,5]  R472      -3.9859518408775330e-02
    z[0,7,5]  R473      -5.7088422775268555e-01
    z[0,7,6]  R8        -1
    z[0,7,6]  R71       1
    z[0,7,6]  R372      -1
    z[0,7,6]  R373      1
    z[0,7,6]  R374      7.7159710228443146e-02
    z[0,7,6]  R375      -8.0683961510658264e-02
    z[0,7,6]  R376      0.139371857047081
    z[0,7,6]  R377      -4.4379360973834991e-02
    z[0,7,6]  R378      -2.4302257597446442e-01
    z[0,7,6]  R379      1.3012232258915901e-02
    z[0,7,6]  R380      1.4325623214244843e-01
    z[0,7,6]  R381      2.0397785305976868e-01
    z[0,7,6]  R382      -4.3918332457542419e-01
    z[0,7,6]  R383      -2.7320069074630737e-01
    z[0,7,6]  R384      -2.1874524652957916e-02
    z[0,7,6]  R385      1.2172093987464905e-01
    z[0,7,6]  R386      -9.6303343772888184e-02
    z[0,7,6]  R387      1.5148496627807617e-01
    z[0,7,6]  R388      1.5535451471805573e-01
    z[0,7,6]  R389      -1.8742421269416809e-01
    z[0,7,6]  R390      -5.0384610891342163e-01
    z[0,7,6]  R391      -4.7202232480049133e-01
    z[0,7,6]  R392      -1.9704076647758484e-01
    z[0,7,6]  R393      5.0386947393417358e-01
    z[0,7,6]  R394      1.7277951538562775e-01
    z[0,7,6]  R395      1.2333349883556366e-01
    z[0,7,6]  R396      -4.1507761925458908e-02
    z[0,7,6]  R397      2.0936825871467590e-01
    z[0,7,6]  R398      -3.0899370089173317e-02
    z[0,7,6]  R399      8.7542489171028137e-02
    z[0,7,6]  R400      3.0347725842148066e-03
    z[0,7,6]  R401      -1.9770814478397369e-01
    z[0,7,6]  R402      -5.8251347392797470e-02
    z[0,7,6]  R403      -1.0866452008485794e-02
    z[0,7,6]  R404      -3.1294006109237671e-01
    z[0,7,6]  R405      -6.9185465574264526e-02
    z[0,7,6]  R406      -3.0267012119293213e-01
    z[0,7,6]  R407      -1.1578613519668579e-01
    z[0,7,6]  R408      -1.8573486804962158e-01
    z[0,7,6]  R409      -2.0713666081428528e-01
    z[0,7,6]  R410      2.2767202556133270e-01
    z[0,7,6]  R411      5.0874944776296616e-02
    z[0,7,6]  R412      3.7979960907250643e-03
    z[0,7,6]  R413      1.3695596717298031e-02
    z[0,7,6]  R414      5.6516444683074951e-01
    z[0,7,6]  R415      1.7001870274543762e-01
    z[0,7,6]  R416      -2.3594453930854797e-01
    z[0,7,6]  R417      -5.4452878236770630e-01
    z[0,7,6]  R418      -2.3469147086143494e-01
    z[0,7,6]  R419      -4.3339309096336365e-01
    z[0,7,6]  R420      3.3968454599380493e-01
    z[0,7,6]  R421      5.2589696645736694e-01
    z[0,7,6]  R422      6.7241585254669189e-01
    z[0,7,6]  R423      2.0722452551126480e-02
    z[0,7,6]  R424      -1.1373517662286758e-01
    z[0,7,6]  R425      6.3404709100723267e-01
    z[0,7,6]  R426      0.623392641544342
    z[0,7,6]  R427      -2.8832862153649330e-02
    z[0,7,6]  R428      1.1271952837705612e-01
    z[0,7,6]  R429      -9.2097982764244080e-02
    z[0,7,6]  R430      5.4710201919078827e-02
    z[0,7,6]  R431      -9.3675032258033752e-02
    z[0,7,6]  R432      -7.3648296296596527e-02
    z[0,7,6]  R433      -5.7028006762266159e-02
    z[0,7,6]  R434      -3.5278104245662689e-02
    z[0,7,6]  R435      2.0132671296596527e-01
    z[0,7,6]  R436      -0.0667652115225792
    z[0,7,6]  R437      1.7769466340541840e-01
    z[0,7,6]  R438      1.0768654197454453e-01
    z[0,7,6]  R439      2.9563727974891663e-01
    z[0,7,6]  R440      2.0852752029895782e-01
    z[0,7,6]  R441      -7.0347420871257782e-02
    z[0,7,6]  R442      4.7084507346153259e-01
    z[0,7,6]  R443      2.1488350629806519e-01
    z[0,7,6]  R444      5.5983554571866989e-02
    z[0,7,6]  R445      -1.7407430708408356e-01
    z[0,7,6]  R446      -3.4601387381553650e-01
    z[0,7,6]  R447      -1.5069159865379333e-01
    z[0,7,6]  R448      -2.5914004445075989e-01
    z[0,7,6]  R449      -4.2466285824775696e-01
    z[0,7,6]  R450      -4.6498034149408340e-02
    z[0,7,6]  R451      -1.0482472181320190e-01
    z[0,7,6]  R452      -5.0177793949842453e-02
    z[0,7,6]  R453      2.4532899260520935e-01
    z[0,7,6]  R454      0.323185533285141
    z[0,7,6]  R455      -4.7742825001478195e-02
    z[0,7,6]  R456      -1.8472076952457428e-01
    z[0,7,6]  R457      -1.7829626798629761e-01
    z[0,7,6]  R458      3.0573625117540359e-02
    z[0,7,6]  R459      -3.2567363232374191e-02
    z[0,7,6]  R460      -3.5136780142784119e-01
    z[0,7,6]  R461      1.8085611518472433e-03
    z[0,7,6]  R462      -2.3121614754199982e-01
    z[0,7,6]  R463      -9.1499179601669312e-02
    z[0,7,6]  R464      1.0097808390855789e-01
    z[0,7,6]  R465      -1.6042618453502655e-01
    z[0,7,6]  R466      3.3555500209331512e-02
    z[0,7,6]  R467      -1.1515476554632187e-01
    z[0,7,6]  R468      1.7848303914070129e-01
    z[0,7,6]  R469      -2.8546676039695740e-01
    z[0,7,6]  R470      -2.5411024689674377e-01
    z[0,7,6]  R471      2.4185892939567566e-01
    z[0,7,6]  R472      3.9354795217514038e-01
    z[0,7,6]  R473      -1.6337199509143829e-01
    z[7,0,0]  R2        1
    z[7,0,0]  R65       -1
    z[7,0,0]  R474      -1
    z[7,0,0]  R475      1
    z[7,0,0]  R488      0.56584632396698
    z[7,0,0]  R489      3.8680833578109741e-01
    z[7,0,0]  R490      3.1114852428436279e-01
    z[7,0,0]  R491      2.8785562515258789e-01
    z[7,0,0]  R492      3.1329560279846191e-01
    z[7,0,0]  R493      6.3915866613388062e-01
    z[7,0,0]  R494      6.1947333812713623e-01
    z[7,0,0]  R495      -3.6312767863273621e-01
    z[7,0,0]  R496      -1.4555731415748596e-01
    z[7,0,0]  R497      1.5721313655376434e-01
    z[7,0,0]  R498      -0.337566077709198
    z[7,0,0]  R499      -4.3169227242469788e-01
    z[7,0,0]  R500      -6.1430495977401733e-01
    z[7,0,0]  R501      -4.2309236526489258e-01
    z[7,0,0]  R502      -6.2170523405075073e-01
    z[7,0,0]  R503      -6.3902544975280762e-01
    z[7,0,0]  R504      -1.3756404817104340e-01
    z[7,0,0]  R505      -5.1230460405349731e-01
    z[7,0,0]  R506      -7.5247043371200562e-01
    z[7,0,0]  R507      -4.0488809347152710e-01
    z[7,0,0]  R508      2.0064330101013184e-01
    z[7,0,0]  R509      -2.8924819827079773e-01
    z[7,0,0]  R510      2.7174675464630127e-01
    z[7,0,0]  R511      -8.5789456963539124e-02
    z[7,0,0]  R512      -6.6463607549667358e-01
    z[7,0,0]  R513      4.3180355429649353e-01
    z[7,0,0]  R514      -3.8987055420875549e-01
    z[7,0,0]  R515      0.343079149723053
    z[7,0,0]  R516      -2.0219059288501740e-01
    z[7,0,0]  R517      2.2271190583705902e-01
    z[7,0,0]  R518      3.1970273703336716e-02
    z[7,0,0]  R519      8.0609925091266632e-02
    z[7,0,0]  R520      5.9101927280426025e-01
    z[7,0,0]  R521      -2.2363428771495819e-01
    z[7,0,0]  R522      -2.9740871861577034e-02
    z[7,0,0]  R523      2.7416062355041504e-01
    z[7,0,0]  R524      -1.0326413810253143e-01
    z[7,0,0]  R525      -1.7664854228496552e-01
    z[7,0,0]  R526      -5.9103786945343018e-01
    z[7,0,0]  R527      -2.7790278196334839e-01
    z[7,0,0]  R528      0.620798647403717
    z[7,0,0]  R529      5.2654927968978882e-01
    z[7,0,0]  R530      0.462368905544281
    z[7,0,0]  R531      1.3268569111824036e-01
    z[7,0,0]  R532      1.5740792453289032e-01
    z[7,0,0]  R533      -1.3772873580455780e-01
    z[7,0,0]  R534      5.1359629631042480e-01
    z[7,0,0]  R535      1.8717673420906067e-01
    z[7,0,0]  R536      7.0190334320068359e-01
    z[7,0,0]  R537      -1.2152490764856339e-01
    z[7,0,0]  R538      -3.8810375332832336e-01
    z[7,0,0]  R539      -1.6573785245418549e-01
    z[7,0,0]  R540      -3.1329813599586487e-01
    z[7,0,0]  R541      -3.6065387725830078e-01
    z[7,0,0]  R542      -1.4641138911247253e-01
    z[7,0,0]  R543      -3.8380718231201172e-01
    z[7,0,0]  R544      -1.9463101029396057e-01
    z[7,0,0]  R545      -2.1786668896675110e-01
    z[7,0,0]  R546      -3.5266622900962830e-01
    z[7,0,0]  R547      1.3635067641735077e-01
    z[7,0,0]  R548      -4.0896780788898468e-02
    z[7,0,0]  R549      -1.0298158973455429e-01
    z[7,0,0]  R550      -2.5520476698875427e-01
    z[7,0,0]  R551      -4.1922938078641891e-02
    z[7,0,0]  R552      -5.3105160593986511e-02
    z[7,0,0]  R553      2.2029291093349457e-01
    z[7,0,0]  R554      -1.6303269565105438e-01
    z[7,0,0]  R555      4.5278385281562805e-01
    z[7,0,0]  R556      3.0736759305000305e-01
    z[7,0,0]  R557      2.5611084699630737e-01
    z[7,0,0]  R558      1.6221153736114502e-01
    z[7,0,0]  R559      1.0434409230947495e-01
    z[7,0,0]  R560      -1.9514784216880798e-01
    z[7,0,0]  R561      2.0719854533672333e-01
    z[7,0,0]  R562      -4.5424412935972214e-02
    z[7,0,0]  R563      -5.9812828898429871e-02
    z[7,0,0]  R564      1.2708221375942230e-01
    z[7,0,0]  R565      4.8202324658632278e-02
    z[7,0,0]  R566      4.0944972634315491e-01
    z[7,0,0]  R567      9.1523610055446625e-02
    z[7,0,0]  R568      4.2951118946075439e-01
    z[7,0,0]  R569      -3.9567712694406509e-02
    z[7,0,0]  R570      -3.1187409535050392e-02
    z[7,0,0]  R571      7.9985029995441437e-02
    z[7,0,0]  R572      4.0240153670310974e-01
    z[7,0,0]  R573      2.4220819771289825e-01
    z[7,0,0]  R574      -0.302153080701828
    z[7,0,0]  R575      2.0053511857986450e-01
    z[7,0,0]  R576      -2.2063534706830978e-02
    z[7,0,0]  R577      -2.2748107090592384e-02
    z[7,0,0]  R578      2.3923364281654358e-01
    z[7,0,0]  R579      2.6735377311706543e-01
    z[7,0,0]  R580      2.5035685300827026e-01
    z[7,0,0]  R581      -1.0845737904310226e-01
    z[7,0,0]  R582      7.5069174170494080e-02
    z[7,0,0]  R583      -5.2948564291000366e-02
    z[7,0,0]  R584      3.5006088018417358e-01
    z[7,0,0]  R585      -2.5894674658775330e-01
    z[7,0,0]  R586      -2.6131308078765869e-01
    z[7,0,0]  R587      -1.0611040890216827e-01
    z[7,0,1]  R3        1
    z[7,0,1]  R66       -1
    z[7,0,1]  R476      -1
    z[7,0,1]  R477      1
    z[7,0,1]  R488      -7.2112256288528442e-01
    z[7,0,1]  R489      -6.0716563463211060e-01
    z[7,0,1]  R490      -4.7086629271507263e-01
    z[7,0,1]  R491      -4.8536252975463867e-01
    z[7,0,1]  R492      -4.4142702221870422e-01
    z[7,0,1]  R493      -3.5772338509559631e-02
    z[7,0,1]  R494      -1.1704052239656448e-01
    z[7,0,1]  R495      -8.4566110372543335e-01
    z[7,0,1]  R496      -7.9250574111938477e-01
    z[7,0,1]  R497      5.1438021659851074e-01
    z[7,0,1]  R498      4.7565326094627380e-01
    z[7,0,1]  R499      5.1896393299102783e-01
    z[7,0,1]  R500      5.3056395053863525e-01
    z[7,0,1]  R501      4.3915295600891113e-01
    z[7,0,1]  R502      4.2227533459663391e-01
    z[7,0,1]  R503      4.2494386434555054e-01
    z[7,0,1]  R504      1.5499807894229889e-01
    z[7,0,1]  R505      4.4935676455497742e-01
    z[7,0,1]  R506      4.9008226394653320e-01
    z[7,0,1]  R507      6.5573644638061523e-01
    z[7,0,1]  R508      -7.9547427594661713e-02
    z[7,0,1]  R509      5.8217358589172363e-01
    z[7,0,1]  R510      4.4434210658073425e-01
    z[7,0,1]  R511      6.3792675733566284e-01
    z[7,0,1]  R512      2.3921658098697662e-01
    z[7,0,1]  R513      1.3692812621593475e-01
    z[7,0,1]  R514      -3.5033699870109558e-01
    z[7,0,1]  R515      2.3405049741268158e-01
    z[7,0,1]  R516      -5.1957017183303833e-01
    z[7,0,1]  R517      5.6142288446426392e-01
    z[7,0,1]  R518      1.9173850119113922e-01
    z[7,0,1]  R519      -6.3599482178688049e-02
    z[7,0,1]  R520      3.2843938469886780e-01
    z[7,0,1]  R521      -6.9322896003723145e-01
    z[7,0,1]  R522      3.4201240539550781e-01
    z[7,0,1]  R523      -8.2714691758155823e-02
    z[7,0,1]  R524      0.0487123504281044
    z[7,0,1]  R525      1.3683560490608215e-01
    z[7,0,1]  R526      -5.1087313890457153e-01
    z[7,0,1]  R527      8.6742222309112549e-02
    z[7,0,1]  R528      -5.2527648210525513e-01
    z[7,0,1]  R529      -7.6045840978622437e-01
    z[7,0,1]  R530      -2.5633433461189270e-01
    z[7,0,1]  R531      -8.1234443187713623e-01
    z[7,0,1]  R532      -5.2500879764556885e-01
    z[7,0,1]  R533      -8.3281147480010986e-01
    z[7,0,1]  R534      -4.5282069593667984e-02
    z[7,0,1]  R535      -6.6825169324874878e-01
    z[7,0,1]  R536      9.4174752011895180e-03
    z[7,0,1]  R537      -4.4155597686767578e-01
    z[7,0,1]  R538      0.336871862411499
    z[7,0,1]  R539      4.4043898582458496e-01
    z[7,0,1]  R540      5.4839485883712769e-01
    z[7,0,1]  R541      2.0966002345085144e-01
    z[7,0,1]  R542      3.0229339003562927e-01
    z[7,0,1]  R543      3.9771580696105957e-01
    z[7,0,1]  R544      2.9277262091636658e-01
    z[7,0,1]  R545      2.0392750203609467e-01
    z[7,0,1]  R546      4.5268815755844116e-01
    z[7,0,1]  R547      5.1453071832656860e-01
    z[7,0,1]  R548      1.6954012215137482e-01
    z[7,0,1]  R549      -4.2636382579803467e-01
    z[7,0,1]  R550      4.4002529978752136e-01
    z[7,0,1]  R551      6.4283883571624756e-01
    z[7,0,1]  R552      -6.4902478456497192e-01
    z[7,0,1]  R553      -7.3591619729995728e-01
    z[7,0,1]  R554      1.1351312696933746e-01
    z[7,0,1]  R555      -6.2721645832061768e-01
    z[7,0,1]  R556      -0.582633376121521
    z[7,0,1]  R557      -6.8468379974365234e-01
    z[7,0,1]  R558      1.4159551262855530e-01
    z[7,0,1]  R559      4.7614101320505142e-02
    z[7,0,1]  R560      4.0677130222320557e-01
    z[7,0,1]  R561      3.2636293768882751e-01
    z[7,0,1]  R562      4.5732742547988892e-01
    z[7,0,1]  R563      -7.8393936157226562e-01
    z[7,0,1]  R564      6.3165462017059326e-01
    z[7,0,1]  R565      -9.3769985437393188e-01
    z[7,0,1]  R566      -8.0721575021743774e-01
    z[7,0,1]  R567      -5.4238897562026978e-01
    z[7,0,1]  R568      2.5861972570419312e-01
    z[7,0,1]  R569      -9.6798247098922729e-01
    z[7,0,1]  R570      -6.7429274320602417e-01
    z[7,0,1]  R571      -7.2020101547241211e-01
    z[7,0,1]  R572      2.9705107212066650e-01
    z[7,0,1]  R573      3.9390709996223450e-01
    z[7,0,1]  R574      1.5610887110233307e-01
    z[7,0,1]  R575      -4.3803668022155762e-01
    z[7,0,1]  R576      -4.0859362483024597e-01
    z[7,0,1]  R577      -6.4626979827880859e-01
    z[7,0,1]  R578      -2.8822859749197960e-02
    z[7,0,1]  R579      -1.3212330639362335e-01
    z[7,0,1]  R580      -4.8857319355010986e-01
    z[7,0,1]  R581      2.1396249532699585e-01
    z[7,0,1]  R582      -6.9400328397750854e-01
    z[7,0,1]  R583      3.4333273768424988e-01
    z[7,0,1]  R584      -4.4806605577468872e-01
    z[7,0,1]  R585      -4.6262946724891663e-01
    z[7,0,1]  R586      -3.0958941578865051e-01
    z[7,0,1]  R587      -1.9974282383918762e-01
    z[7,0,2]  R4        1
    z[7,0,2]  R67       -1
    z[7,0,2]  R478      -1
    z[7,0,2]  R479      1
    z[7,0,2]  R488      1.5238769352436066e-01
    z[7,0,2]  R489      3.8924619555473328e-01
    z[7,0,2]  R490      1.3544920086860657e-01
    z[7,0,2]  R491      6.2276750802993774e-01
    z[7,0,2]  R492      -5.7281100749969482e-01
    z[7,0,2]  R493      3.1706255674362183e-01
    z[7,0,2]  R494      -7.3331922292709351e-01
    z[7,0,2]  R495      2.8229501843452454e-01
    z[7,0,2]  R496      2.0769460499286652e-01
    z[7,0,2]  R497      -5.9686416387557983e-01
    z[7,0,2]  R498      7.2961330413818359e-01
    z[7,0,2]  R499      4.3422129750251770e-01
    z[7,0,2]  R500      3.8158121705055237e-01
    z[7,0,2]  R501      0.550506055355072
    z[7,0,2]  R502      3.2392820715904236e-01
    z[7,0,2]  R503      2.4571396410465240e-01
    z[7,0,2]  R504      0.067622110247612
    z[7,0,2]  R505      0.459238737821579
    z[7,0,2]  R506      3.2472480088472366e-02
    z[7,0,2]  R507      2.7156364917755127e-01
    z[7,0,2]  R508      -1.8956419825553894e-01
    z[7,0,2]  R509      -6.9618624448776245e-01
    z[7,0,2]  R510      -3.2738870382308960e-01
    z[7,0,2]  R511      -4.9386900663375854e-01
    z[7,0,2]  R512      -5.8306747674942017e-01
    z[7,0,2]  R513      1.5498754382133484e-01
    z[7,0,2]  R514      -1.3371452689170837e-01
    z[7,0,2]  R515      -3.7353730201721191e-01
    z[7,0,2]  R516      -2.8236207365989685e-01
    z[7,0,2]  R517      -5.8703833818435669e-01
    z[7,0,2]  R518      -1.8302412331104279e-01
    z[7,0,2]  R519      8.9372813701629639e-02
    z[7,0,2]  R520      -1.2978021800518036e-01
    z[7,0,2]  R521      6.9510176777839661e-02
    z[7,0,2]  R522      5.3976005315780640e-01
    z[7,0,2]  R523      -8.5104942321777344e-01
    z[7,0,2]  R524      -7.3560386896133423e-01
    z[7,0,2]  R525      -4.1516625881195068e-01
    z[7,0,2]  R526      -2.0120188593864441e-01
    z[7,0,2]  R527      -4.5631888508796692e-01
    z[7,0,2]  R528      2.8240248560905457e-01
    z[7,0,2]  R529      0.145859956741333
    z[7,0,2]  R530      -4.8697876930236816e-01
    z[7,0,2]  R531      4.4901812076568604e-01
    z[7,0,2]  R532      0.73260498046875
    z[7,0,2]  R533      2.6689371466636658e-01
    z[7,0,2]  R534      6.9678300619125366e-01
    z[7,0,2]  R535      -6.3427609205245972e-01
    z[7,0,2]  R536      -4.9273434281349182e-01
    z[7,0,2]  R537      2.7878072857856750e-01
    z[7,0,2]  R538      2.7123796939849854e-01
    z[7,0,2]  R539      3.3787584304809570e-01
    z[7,0,2]  R540      4.5626482367515564e-01
    z[7,0,2]  R541      5.3327459096908569e-01
    z[7,0,2]  R542      2.6201978325843811e-01
    z[7,0,2]  R543      2.1138642728328705e-01
    z[7,0,2]  R544      1.2170034646987915e-01
    z[7,0,2]  R545      -7.8172661364078522e-02
    z[7,0,2]  R546      -2.7911770343780518e-01
    z[7,0,2]  R547      -3.5881170630455017e-01
    z[7,0,2]  R548      -3.0714237689971924e-01
    z[7,0,2]  R549      -4.1826552152633667e-01
    z[7,0,2]  R550      -6.2289965152740479e-01
    z[7,0,2]  R551      -6.6303437948226929e-01
    z[7,0,2]  R552      -2.7375000715255737e-01
    z[7,0,2]  R553      -1.0064578801393509e-01
    z[7,0,2]  R554      -7.7345591783523560e-01
    z[7,0,2]  R555      -1.1731107532978058e-01
    z[7,0,2]  R556      -3.5247454047203064e-01
    z[7,0,2]  R557      -6.3121385872364044e-02
    z[7,0,2]  R558      -9.9313713610172272e-02
    z[7,0,2]  R559      -8.2837289571762085e-01
    z[7,0,2]  R560      -8.0990833044052124e-01
    z[7,0,2]  R561      -5.9784799814224243e-01
    z[7,0,2]  R562      -5.1879543066024780e-01
    z[7,0,2]  R563      -3.8309359550476074e-01
    z[7,0,2]  R564      -4.7910192608833313e-01
    z[7,0,2]  R565      -4.6313893049955368e-02
    z[7,0,2]  R566      1.7006424069404602e-01
    z[7,0,2]  R567      1.9337338209152222e-01
    z[7,0,2]  R568      -1.1138269305229187e-01
    z[7,0,2]  R569      -1.0139747709035873e-01
    z[7,0,2]  R570      -6.2791548669338226e-02
    z[7,0,2]  R571      -8.6022213101387024e-02
    z[7,0,2]  R572      3.9707577228546143e-01
    z[7,0,2]  R573      6.3471257686614990e-01
    z[7,0,2]  R574      -6.6998451948165894e-01
    z[7,0,2]  R575      5.1057374477386475e-01
    z[7,0,2]  R576      4.7518399357795715e-01
    z[7,0,2]  R577      -5.5646121501922607e-02
    z[7,0,2]  R578      2.1809941530227661e-01
    z[7,0,2]  R579      -6.7226584069430828e-03
    z[7,0,2]  R580      1.0934574529528618e-02
    z[7,0,2]  R581      5.5326181463897228e-03
    z[7,0,2]  R582      -2.4967899918556213e-01
    z[7,0,2]  R583      7.6059329509735107e-01
    z[7,0,2]  R584      4.9448895454406738e-01
    z[7,0,2]  R585      4.0338733792304993e-01
    z[7,0,2]  R586      3.7548035383224487e-01
    z[7,0,2]  R587      0.501044511795044
    z[7,0,3]  R5        1
    z[7,0,3]  R68       -1
    z[7,0,3]  R480      -1
    z[7,0,3]  R481      1
    z[7,0,3]  R488      -1.9879573583602905e-01
    z[7,0,3]  R489      -1.2019961327314377e-01
    z[7,0,3]  R490      -2.1669751405715942e-01
    z[7,0,3]  R491      -1.7680196464061737e-01
    z[7,0,3]  R492      -1.1830183863639832e-01
    z[7,0,3]  R493      -2.1421962976455688e-01
    z[7,0,3]  R494      -1.0761692374944687e-01
    z[7,0,3]  R495      1.9323322176933289e-01
    z[7,0,3]  R496      2.0005673170089722e-01
    z[7,0,3]  R497      3.9944455027580261e-01
    z[7,0,3]  R498      2.5041863322257996e-01
    z[7,0,3]  R499      2.5284075736999512e-01
    z[7,0,3]  R500      7.8956015408039093e-02
    z[7,0,3]  R501      3.5475313663482666e-01
    z[7,0,3]  R502      4.1027444601058960e-01
    z[7,0,3]  R503      3.6534574627876282e-01
    z[7,0,3]  R504      -9.1493481397628784e-01
    z[7,0,3]  R505      2.1414358913898468e-01
    z[7,0,3]  R506      2.4445576965808868e-01
    z[7,0,3]  R507      3.4286347031593323e-01
    z[7,0,3]  R508      -6.6909611225128174e-01
    z[7,0,3]  R509      -8.4517627954483032e-02
    z[7,0,3]  R510      -5.9091800451278687e-01
    z[7,0,3]  R511      -3.9055764675140381e-01
    z[7,0,3]  R512      -1.2892629206180573e-01
    z[7,0,3]  R513      -4.0681746602058411e-01
    z[7,0,3]  R514      -7.3988062143325806e-01
    z[7,0,3]  R515      -7.0957213640213013e-01
    z[7,0,3]  R516      -5.8777654170989990e-01
    z[7,0,3]  R517      1.9040267169475555e-01
    z[7,0,3]  R518      -8.9693957567214966e-01
    z[7,0,3]  R519      -9.2326998710632324e-01
    z[7,0,3]  R520      -5.1264625042676926e-02
    z[7,0,3]  R521      -2.4642907083034515e-01
    z[7,0,3]  R522      -5.7452076673507690e-01
    z[7,0,3]  R523      -3.1194803118705750e-01
    z[7,0,3]  R524      4.3479931354522705e-01
    z[7,0,3]  R525      3.0651673674583435e-01
    z[7,0,3]  R526      -4.3567517399787903e-01
    z[7,0,3]  R527      4.9107018113136292e-01
    z[7,0,3]  R528      -4.2973395437002182e-02
    z[7,0,3]  R529      -2.6564297080039978e-01
    z[7,0,3]  R530      -1.2342379242181778e-01
    z[7,0,3]  R531      5.4581563919782639e-02
    z[7,0,3]  R532      7.4223875999450684e-02
    z[7,0,3]  R533      -8.6148120462894440e-02
    z[7,0,3]  R534      -2.2465391457080841e-01
    z[7,0,3]  R535      -1.4569766819477081e-01
    z[7,0,3]  R536      -1.1452665925025940e-01
    z[7,0,3]  R537      -2.2144512832164764e-01
    z[7,0,3]  R538      7.7179753780364990e-01
    z[7,0,3]  R539      7.7670842409133911e-01
    z[7,0,3]  R540      4.2458295822143555e-01
    z[7,0,3]  R541      5.3509742021560669e-01
    z[7,0,3]  R542      8.8359820842742920e-01
    z[7,0,3]  R543      7.1848428249359131e-01
    z[7,0,3]  R544      7.4888008832931519e-01
    z[7,0,3]  R545      8.1281745433807373e-01
    z[7,0,3]  R546      6.4981228113174438e-01
    z[7,0,3]  R547      3.4159621596336365e-01
    z[7,0,3]  R548      -7.3769712448120117e-01
    z[7,0,3]  R549      -7.5746411085128784e-01
    z[7,0,3]  R550      -3.2506421208381653e-01
    z[7,0,3]  R551      1.0737046599388123e-02
    z[7,0,3]  R552      -2.7211424708366394e-01
    z[7,0,3]  R553      -1.4180260896682739e-01
    z[7,0,3]  R554      -9.1851547360420227e-02
    z[7,0,3]  R555      -0.193960040807724
    z[7,0,3]  R556      -2.9411277174949646e-01
    z[7,0,3]  R557      -2.3583996295928955e-01
    z[7,0,3]  R558      -8.8795667886734009e-01
    z[7,0,3]  R559      -1.4621990919113159e-01
    z[7,0,3]  R560      5.4085712879896164e-02
    z[7,0,3]  R561      2.6164343953132629e-01
    z[7,0,3]  R562      -2.8413820266723633e-01
    z[7,0,3]  R563      -4.3831738829612732e-01
    z[7,0,3]  R564      -1.9417501986026764e-01
    z[7,0,3]  R565      -3.3469071984291077e-01
    z[7,0,3]  R566      -0.192152202129364
    z[7,0,3]  R567      -7.4606943130493164e-01
    z[7,0,3]  R568      -4.2095720767974854e-01
    z[7,0,3]  R569      -1.1743719130754471e-01
    z[7,0,3]  R570      -5.9809368848800659e-01
    z[7,0,3]  R571      2.8989285230636597e-01
    z[7,0,3]  R572      5.8652019500732422e-01
    z[7,0,3]  R573      4.0933492779731750e-01
    z[7,0,3]  R574      -5.1661711931228638e-01
    z[7,0,3]  R575      -5.6924719363451004e-02
    z[7,0,3]  R576      -1.4558336138725281e-01
    z[7,0,3]  R577      7.0159655809402466e-01
    z[7,0,3]  R578      -1.7490082979202271e-01
    z[7,0,3]  R579      -4.4254866242408752e-01
    z[7,0,3]  R580      -5.4232919216156006e-01
    z[7,0,3]  R581      8.7038993835449219e-01
    z[7,0,3]  R582      -2.5695204734802246e-01
    z[7,0,3]  R583      4.2477965354919434e-01
    z[7,0,3]  R584      -2.2404132783412933e-01
    z[7,0,3]  R585      -1.2913145124912262e-01
    z[7,0,3]  R586      -2.1360759437084198e-01
    z[7,0,3]  R587      -9.8005183041095734e-02
    z[7,0,4]  R6        1
    z[7,0,4]  R69       -1
    z[7,0,4]  R482      -1
    z[7,0,4]  R483      1
    z[7,0,4]  R488      2.8136044740676880e-01
    z[7,0,4]  R489      1.3414669036865234e-01
    z[7,0,4]  R490      6.0929656028747559e-01
    z[7,0,4]  R491      4.6493580937385559e-01
    z[7,0,4]  R492      5.9276384115219116e-01
    z[7,0,4]  R493      5.8546477556228638e-01
    z[7,0,4]  R494      -9.6167489886283875e-02
    z[7,0,4]  R495      -1.0068996995687485e-01
    z[7,0,4]  R496      -1.6605491936206818e-01
    z[7,0,4]  R497      3.6492672562599182e-01
    z[7,0,4]  R498      -2.4456101655960083e-01
    z[7,0,4]  R499      -2.1529795229434967e-01
    z[7,0,4]  R500      -2.6367521286010742e-01
    z[7,0,4]  R501      2.7901515364646912e-01
    z[7,0,4]  R502      2.8647467494010925e-01
    z[7,0,4]  R503      9.8640955984592438e-02
    z[7,0,4]  R504      -3.3423733711242676e-01
    z[7,0,4]  R505      5.5307867005467415e-03
    z[7,0,4]  R506      -2.2386403381824493e-01
    z[7,0,4]  R507      -3.8595151901245117e-01
    z[7,0,4]  R508      -1.9395154714584351e-01
    z[7,0,4]  R509      -1.3204665482044220e-01
    z[7,0,4]  R510      4.1910582780838013e-01
    z[7,0,4]  R511      1.9031862914562225e-01
    z[7,0,4]  R512      -2.3103572428226471e-01
    z[7,0,4]  R513      7.7144846320152283e-02
    z[7,0,4]  R514      0.0887860581278801
    z[7,0,4]  R515      -3.5474222898483276e-01
    z[7,0,4]  R516      -4.5493033528327942e-01
    z[7,0,4]  R517      4.9308523535728455e-02
    z[7,0,4]  R518      3.2211273908615112e-01
    z[7,0,4]  R519      2.5527609977871180e-03
    z[7,0,4]  R520      0.415828675031662
    z[7,0,4]  R521      -2.0532572269439697e-01
    z[7,0,4]  R522      1.3875405490398407e-01
    z[7,0,4]  R523      -3.2913282513618469e-02
    z[7,0,4]  R524      4.0149144828319550e-02
    z[7,0,4]  R525      2.2124961018562317e-01
    z[7,0,4]  R526      -5.4027330130338669e-02
    z[7,0,4]  R527      3.3655592799186707e-01
    z[7,0,4]  R528      4.2537233233451843e-01
    z[7,0,4]  R529      -9.5285743474960327e-02
    z[7,0,4]  R530      6.5638190507888794e-01
    z[7,0,4]  R531      3.3855831716209650e-03
    z[7,0,4]  R532      3.1257805228233337e-01
    z[7,0,4]  R533      4.1833665966987610e-01
    z[7,0,4]  R534      3.7378013134002686e-01
    z[7,0,4]  R535      1.3977633416652679e-01
    z[7,0,4]  R536      1.4557459950447083e-01
    z[7,0,4]  R537      6.6414761543273926e-01
    z[7,0,4]  R538      -2.2514109313488007e-01
    z[7,0,4]  R539      1.5775656700134277e-01
    z[7,0,4]  R540      -4.4935601949691772e-01
    z[7,0,4]  R541      -4.4440931081771851e-01
    z[7,0,4]  R542      -9.2320390045642853e-02
    z[7,0,4]  R543      1.6472026705741882e-01
    z[7,0,4]  R544      -1.4845220744609833e-01
    z[7,0,4]  R545      7.1356974542140961e-02
    z[7,0,4]  R546      3.1857442855834961e-01
    z[7,0,4]  R547      -1.8808278441429138e-01
    z[7,0,4]  R548      -7.0799104869365692e-02
    z[7,0,4]  R549      -4.6892590820789337e-02
    z[7,0,4]  R550      -3.5155621170997620e-01
    z[7,0,4]  R551      -2.6395657658576965e-01
    z[7,0,4]  R552      -5.4082489013671875e-01
    z[7,0,4]  R553      -6.0410511493682861e-01
    z[7,0,4]  R554      -5.7146471738815308e-01
    z[7,0,4]  R555      -1.4503400027751923e-01
    z[7,0,4]  R556      5.4119382053613663e-02
    z[7,0,4]  R557      -4.9069771170616150e-01
    z[7,0,4]  R558      2.3150597512722015e-01
    z[7,0,4]  R559      -3.9880722761154175e-01
    z[7,0,4]  R560      -1.0147042572498322e-01
    z[7,0,4]  R561      -2.7505621314048767e-01
    z[7,0,4]  R562      4.4939219951629639e-01
    z[7,0,4]  R563      -7.8716287389397621e-03
    z[7,0,4]  R564      1.5144766867160797e-01
    z[7,0,4]  R565      -2.9947564005851746e-02
    z[7,0,4]  R566      -1.3263091444969177e-01
    z[7,0,4]  R567      -3.4195877611637115e-02
    z[7,0,4]  R568      8.7610080838203430e-02
    z[7,0,4]  R569      -7.7473089098930359e-02
    z[7,0,4]  R570      3.5602787137031555e-01
    z[7,0,4]  R571      -1.8323583528399467e-02
    z[7,0,4]  R572      -3.1564787030220032e-01
    z[7,0,4]  R573      -1.6070117056369781e-01
    z[7,0,4]  R574      2.2763521969318390e-01
    z[7,0,4]  R575      -3.6384207010269165e-01
    z[7,0,4]  R576      9.4340629875659943e-03
    z[7,0,4]  R577      -2.4918565154075623e-01
    z[7,0,4]  R578      7.2349125146865845e-01
    z[7,0,4]  R579      -2.0824027061462402e-01
    z[7,0,4]  R580      -1.0618934780359268e-01
    z[7,0,4]  R581      2.2421617805957794e-01
    z[7,0,4]  R582      3.9329430460929871e-01
    z[7,0,4]  R583      2.2341303527355194e-01
    z[7,0,4]  R584      -5.3956985473632812e-01
    z[7,0,4]  R585      -3.5801011323928833e-01
    z[7,0,4]  R586      -1.4515841007232666e-01
    z[7,0,4]  R587      -3.4462669491767883e-01
    z[7,0,5]  R7        1
    z[7,0,5]  R70       -1
    z[7,0,5]  R484      -1
    z[7,0,5]  R485      1
    z[7,0,5]  R488      1.2903597950935364e-01
    z[7,0,5]  R489      5.0718921422958374e-01
    z[7,0,5]  R490      4.9037474393844604e-01
    z[7,0,5]  R491      -1.2133947759866714e-01
    z[7,0,5]  R492      -4.3760299682617188e-02
    z[7,0,5]  R493      1.1665125936269760e-01
    z[7,0,5]  R494      -2.1996637806296349e-02
    z[7,0,5]  R495      1.4449493587017059e-01
    z[7,0,5]  R496      -1.3534571230411530e-01
    z[7,0,5]  R497      1.2469103187322617e-01
    z[7,0,5]  R498      4.2589064687490463e-02
    z[7,0,5]  R499      4.6388205885887146e-01
    z[7,0,5]  R500      6.5515274181962013e-03
    z[7,0,5]  R501      -3.1412345170974731e-01
    z[7,0,5]  R502      -1.1265028268098831e-01
    z[7,0,5]  R503      1.6476555168628693e-01
    z[7,0,5]  R504      -3.8684133440256119e-02
    z[7,0,5]  R505      -0.51753830909729
    z[7,0,5]  R506      -2.8312796354293823e-01
    z[7,0,5]  R507      -7.5021870434284210e-02
    z[7,0,5]  R508      -0.572472095489502
    z[7,0,5]  R509      -2.5666135549545288e-01
    z[7,0,5]  R510      -2.5014990568161011e-01
    z[7,0,5]  R511      -3.4819102287292480e-01
    z[7,0,5]  R512      -3.0022063851356506e-01
    z[7,0,5]  R513      -7.7347451448440552e-01
    z[7,0,5]  R514      -1.6917371749877930e-01
    z[7,0,5]  R515      2.4217553436756134e-01
    z[7,0,5]  R516      -5.9445660561323166e-02
    z[7,0,5]  R517      -4.9349084496498108e-01
    z[7,0,5]  R518      1.0130524635314941e-01
    z[7,0,5]  R519      -3.2140168547630310e-01
    z[7,0,5]  R520      -5.9102743864059448e-01
    z[7,0,5]  R521      -5.9029066562652588e-01
    z[7,0,5]  R522      4.5784175395965576e-01
    z[7,0,5]  R523      -1.1757113784551620e-01
    z[7,0,5]  R524      -4.3659603595733643e-01
    z[7,0,5]  R525      -0.759149968624115
    z[7,0,5]  R526      -3.9859518408775330e-02
    z[7,0,5]  R527      -5.7088422775268555e-01
    z[7,0,5]  R528      2.6495385169982910e-01
    z[7,0,5]  R529      1.9240137934684753e-01
    z[7,0,5]  R530      -1.3365660607814789e-01
    z[7,0,5]  R531      3.4046092629432678e-01
    z[7,0,5]  R532      2.4582780897617340e-02
    z[7,0,5]  R533      1.8337704241275787e-01
    z[7,0,5]  R534      -1.9482944905757904e-01
    z[7,0,5]  R535      -1.8364679813385010e-01
    z[7,0,5]  R536      -0.193043053150177
    z[7,0,5]  R537      3.8441222906112671e-01
    z[7,0,5]  R538      1.2443643063306808e-01
    z[7,0,5]  R539      -1.4630503952503204e-01
    z[7,0,5]  R540      -3.8261435925960541e-02
    z[7,0,5]  R541      -1.8658266961574554e-01
    z[7,0,5]  R542      7.1583420038223267e-02
    z[7,0,5]  R543      2.6711371541023254e-01
    z[7,0,5]  R544      1.5770785510540009e-01
    z[7,0,5]  R545      -1.2754441797733307e-01
    z[7,0,5]  R546      -1.7384602129459381e-01
    z[7,0,5]  R547      -4.2658314108848572e-01
    z[7,0,5]  R548      5.4422867298126221e-01
    z[7,0,5]  R549      2.0371700823307037e-01
    z[7,0,5]  R550      3.4966117143630981e-01
    z[7,0,5]  R551      1.7822083830833435e-01
    z[7,0,5]  R552      3.6539715528488159e-01
    z[7,0,5]  R553      0.0839887410402298
    z[7,0,5]  R554      0.165176123380661
    z[7,0,5]  R555      -5.3859132528305054e-01
    z[7,0,5]  R556      -5.9076285362243652e-01
    z[7,0,5]  R557      -4.0633502602577209e-01
    z[7,0,5]  R558      -6.1492525041103363e-02
    z[7,0,5]  R559      -3.3974891901016235e-01
    z[7,0,5]  R560      -1.8887110054492950e-01
    z[7,0,5]  R561      -0.579322099685669
    z[7,0,5]  R562      -4.4994905591011047e-01
    z[7,0,5]  R563      -0.00333201652392745
    z[7,0,5]  R564      -4.9279722571372986e-01
    z[7,0,5]  R565      2.7345292270183563e-02
    z[7,0,5]  R566      -3.1193593144416809e-01
    z[7,0,5]  R567      3.1948056817054749e-01
    z[7,0,5]  R568      -4.8160004615783691e-01
    z[7,0,5]  R569      0.0496273897588253
    z[7,0,5]  R570      -1.6497241333127022e-02
    z[7,0,5]  R571      -2.9432615637779236e-01
    z[7,0,5]  R572      -3.0568757653236389e-01
    z[7,0,5]  R573      4.5855797827243805e-02
    z[7,0,5]  R574      3.6847241222858429e-02
    z[7,0,5]  R575      3.0827721953392029e-01
    z[7,0,5]  R576      3.6515498161315918e-01
    z[7,0,5]  R577      -1.5479294955730438e-01
    z[7,0,5]  R578      -5.7219195365905762e-01
    z[7,0,5]  R579      5.1941418647766113e-01
    z[7,0,5]  R580      -6.6952146589756012e-02
    z[7,0,5]  R581      -3.6570990085601807e-01
    z[7,0,5]  R582      -4.6580466628074646e-01
    z[7,0,5]  R583      2.4896523356437683e-01
    z[7,0,5]  R584      2.9639750719070435e-01
    z[7,0,5]  R585      0.634490430355072
    z[7,0,5]  R586      7.8915208578109741e-01
    z[7,0,5]  R587      7.5244468450546265e-01
    z[7,0,6]  R8        1
    z[7,0,6]  R71       -1
    z[7,0,6]  R486      -1
    z[7,0,6]  R487      1
    z[7,0,6]  R488      -3.5278104245662689e-02
    z[7,0,6]  R489      2.0132671296596527e-01
    z[7,0,6]  R490      -0.0667652115225792
    z[7,0,6]  R491      1.7769466340541840e-01
    z[7,0,6]  R492      1.0768654197454453e-01
    z[7,0,6]  R493      2.9563727974891663e-01
    z[7,0,6]  R494      2.0852752029895782e-01
    z[7,0,6]  R495      -7.0347420871257782e-02
    z[7,0,6]  R496      4.7084507346153259e-01
    z[7,0,6]  R497      2.1488350629806519e-01
    z[7,0,6]  R498      5.5983554571866989e-02
    z[7,0,6]  R499      -1.7407430708408356e-01
    z[7,0,6]  R500      -3.4601387381553650e-01
    z[7,0,6]  R501      -1.5069159865379333e-01
    z[7,0,6]  R502      -2.5914004445075989e-01
    z[7,0,6]  R503      -4.2466285824775696e-01
    z[7,0,6]  R504      -4.6498034149408340e-02
    z[7,0,6]  R505      -1.0482472181320190e-01
    z[7,0,6]  R506      -5.0177793949842453e-02
    z[7,0,6]  R507      2.4532899260520935e-01
    z[7,0,6]  R508      0.323185533285141
    z[7,0,6]  R509      -4.7742825001478195e-02
    z[7,0,6]  R510      -1.8472076952457428e-01
    z[7,0,6]  R511      -1.7829626798629761e-01
    z[7,0,6]  R512      3.0573625117540359e-02
    z[7,0,6]  R513      -3.2567363232374191e-02
    z[7,0,6]  R514      -3.5136780142784119e-01
    z[7,0,6]  R515      1.8085611518472433e-03
    z[7,0,6]  R516      -2.3121614754199982e-01
    z[7,0,6]  R517      -9.1499179601669312e-02
    z[7,0,6]  R518      1.0097808390855789e-01
    z[7,0,6]  R519      -1.6042618453502655e-01
    z[7,0,6]  R520      3.3555500209331512e-02
    z[7,0,6]  R521      -1.1515476554632187e-01
    z[7,0,6]  R522      1.7848303914070129e-01
    z[7,0,6]  R523      -2.8546676039695740e-01
    z[7,0,6]  R524      -2.5411024689674377e-01
    z[7,0,6]  R525      2.4185892939567566e-01
    z[7,0,6]  R526      3.9354795217514038e-01
    z[7,0,6]  R527      -1.6337199509143829e-01
    z[7,0,6]  R528      7.7159710228443146e-02
    z[7,0,6]  R529      -8.0683961510658264e-02
    z[7,0,6]  R530      0.139371857047081
    z[7,0,6]  R531      -4.4379360973834991e-02
    z[7,0,6]  R532      -2.4302257597446442e-01
    z[7,0,6]  R533      1.3012232258915901e-02
    z[7,0,6]  R534      1.4325623214244843e-01
    z[7,0,6]  R535      2.0397785305976868e-01
    z[7,0,6]  R536      -4.3918332457542419e-01
    z[7,0,6]  R537      -2.7320069074630737e-01
    z[7,0,6]  R538      -2.1874524652957916e-02
    z[7,0,6]  R539      1.2172093987464905e-01
    z[7,0,6]  R540      -9.6303343772888184e-02
    z[7,0,6]  R541      1.5148496627807617e-01
    z[7,0,6]  R542      1.5535451471805573e-01
    z[7,0,6]  R543      -1.8742421269416809e-01
    z[7,0,6]  R544      -5.0384610891342163e-01
    z[7,0,6]  R545      -4.7202232480049133e-01
    z[7,0,6]  R546      -1.9704076647758484e-01
    z[7,0,6]  R547      5.0386947393417358e-01
    z[7,0,6]  R548      1.7277951538562775e-01
    z[7,0,6]  R549      1.2333349883556366e-01
    z[7,0,6]  R550      -4.1507761925458908e-02
    z[7,0,6]  R551      2.0936825871467590e-01
    z[7,0,6]  R552      -3.0899370089173317e-02
    z[7,0,6]  R553      8.7542489171028137e-02
    z[7,0,6]  R554      3.0347725842148066e-03
    z[7,0,6]  R555      -1.9770814478397369e-01
    z[7,0,6]  R556      -5.8251347392797470e-02
    z[7,0,6]  R557      -1.0866452008485794e-02
    z[7,0,6]  R558      -3.1294006109237671e-01
    z[7,0,6]  R559      -6.9185465574264526e-02
    z[7,0,6]  R560      -3.0267012119293213e-01
    z[7,0,6]  R561      -1.1578613519668579e-01
    z[7,0,6]  R562      -1.8573486804962158e-01
    z[7,0,6]  R563      -2.0713666081428528e-01
    z[7,0,6]  R564      2.2767202556133270e-01
    z[7,0,6]  R565      5.0874944776296616e-02
    z[7,0,6]  R566      3.7979960907250643e-03
    z[7,0,6]  R567      1.3695596717298031e-02
    z[7,0,6]  R568      5.6516444683074951e-01
    z[7,0,6]  R569      1.7001870274543762e-01
    z[7,0,6]  R570      -2.3594453930854797e-01
    z[7,0,6]  R571      -5.4452878236770630e-01
    z[7,0,6]  R572      -2.3469147086143494e-01
    z[7,0,6]  R573      -4.3339309096336365e-01
    z[7,0,6]  R574      3.3968454599380493e-01
    z[7,0,6]  R575      5.2589696645736694e-01
    z[7,0,6]  R576      6.7241585254669189e-01
    z[7,0,6]  R577      2.0722452551126480e-02
    z[7,0,6]  R578      -1.1373517662286758e-01
    z[7,0,6]  R579      6.3404709100723267e-01
    z[7,0,6]  R580      0.623392641544342
    z[7,0,6]  R581      -2.8832862153649330e-02
    z[7,0,6]  R582      1.1271952837705612e-01
    z[7,0,6]  R583      -9.2097982764244080e-02
    z[7,0,6]  R584      5.4710201919078827e-02
    z[7,0,6]  R585      -9.3675032258033752e-02
    z[7,0,6]  R586      -7.3648296296596527e-02
    z[7,0,6]  R587      -5.7028006762266159e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R662      -1
    z[1,2,0]  R663      1
    z[1,2,0]  R676      5.6712478399276733e-01
    z[1,2,0]  R677      5.7326781749725342e-01
    z[1,2,0]  R678      3.5377502441406250e-01
    z[1,2,0]  R679      6.1590307950973511e-01
    z[1,2,0]  R680      3.1329560279846191e-01
    z[1,2,0]  R681      4.0936514735221863e-01
    z[1,2,0]  R682      1.7265732586383820e-01
    z[1,2,0]  R683      2.4288158118724823e-01
    z[1,2,0]  R684      2.0638771355152130e-01
    z[1,2,0]  R685      0.621462345123291
    z[1,2,0]  R686      -5.0725597143173218e-01
    z[1,2,0]  R687      -4.5115393400192261e-01
    z[1,2,0]  R688      -7.2730302810668945e-01
    z[1,2,0]  R689      -4.6807822585105896e-01
    z[1,2,0]  R690      -7.8397506475448608e-01
    z[1,2,0]  R691      -3.0847826600074768e-01
    z[1,2,0]  R692      -2.0180958509445190e-01
    z[1,2,0]  R693      -4.7805258631706238e-01
    z[1,2,0]  R694      -4.5329952239990234e-01
    z[1,2,0]  R695      -3.3067616820335388e-01
    z[1,2,0]  R696      -2.8777632117271423e-01
    z[1,2,0]  R697      3.1904092431068420e-01
    z[1,2,0]  R698      -5.8472013473510742e-01
    z[1,2,0]  R699      -1.1177876591682434e-01
    z[1,2,0]  R700      1.5771120786666870e-01
    z[1,2,0]  R701      -1.2083274126052856e-01
    z[1,2,0]  R702      -3.0223888158798218e-01
    z[1,2,0]  R703      -4.8529732227325439e-01
    z[1,2,0]  R704      1.0204591602087021e-01
    z[1,2,0]  R705      1.7605938017368317e-01
    z[1,2,0]  R706      3.5676565766334534e-01
    z[1,2,0]  R707      6.0027921199798584e-01
    z[1,2,0]  R708      -2.0596690475940704e-01
    z[1,2,0]  R709      -1.1497341096401215e-01
    z[1,2,0]  R710      -1.2827318906784058e-01
    z[1,2,0]  R711      2.9592707753181458e-01
    z[1,2,0]  R712      -4.6516966074705124e-02
    z[1,2,0]  R713      -1.7297618091106415e-01
    z[1,2,0]  R714      2.1709685027599335e-01
    z[1,2,0]  R715      2.8099268674850464e-01
    z[1,2,0]  R716      4.5194447040557861e-01
    z[1,2,0]  R717      1.7751461267471313e-01
    z[1,2,0]  R718      2.8391501307487488e-01
    z[1,2,0]  R719      -0.141950786113739
    z[1,2,0]  R720      -2.7992233633995056e-01
    z[1,2,0]  R721      -2.6550477743148804e-01
    z[1,2,0]  R722      -1.6600802540779114e-02
    z[1,2,0]  R723      -9.8987082019448280e-03
    z[1,2,0]  R724      -2.7718076109886169e-01
    z[1,2,0]  R725      -2.1165333688259125e-01
    z[1,2,0]  R726      -1.7723931372165680e-01
    z[1,2,0]  R727      8.8512469083070755e-03
    z[1,2,0]  R728      1.0552880913019180e-01
    z[1,2,0]  R729      -2.0274975895881653e-01
    z[1,2,0]  R730      -6.2486010789871216e-01
    z[1,2,0]  R731      -4.3374547362327576e-01
    z[1,2,0]  R732      -5.0168428570032120e-03
    z[1,2,0]  R733      -6.3746839761734009e-01
    z[1,2,0]  R734      -3.2313367724418640e-01
    z[1,2,0]  R735      3.9484769105911255e-01
    z[1,2,0]  R736      -3.2776564359664917e-01
    z[1,2,0]  R737      -1.8122953176498413e-01
    z[1,2,0]  R738      0.0782022625207901
    z[1,2,0]  R739      -3.8154255598783493e-02
    z[1,2,0]  R740      -1.0823357105255127e-01
    z[1,2,0]  R741      1.1593800783157349e-01
    z[1,2,0]  R742      1.5558232367038727e-01
    z[1,2,0]  R743      -5.0421273708343506e-01
    z[1,2,0]  R744      5.5407893657684326e-01
    z[1,2,0]  R745      -1.2754349410533905e-01
    z[1,2,0]  R746      4.2848935723304749e-01
    z[1,2,0]  R747      -6.9649821519851685e-01
    z[1,2,0]  R748      -8.1040644645690918e-01
    z[1,2,0]  R749      -1.0012060403823853e-01
    z[1,2,0]  R750      -5.0157243013381958e-01
    z[1,2,0]  R751      -4.1528832912445068e-01
    z[1,2,0]  R752      -8.7722289562225342e-01
    z[1,2,0]  R753      -5.3326344490051270e-01
    z[1,2,0]  R754      -3.3016419410705566e-01
    z[1,2,0]  R755      3.0442732572555542e-01
    z[1,2,0]  R756      -1.5702560544013977e-01
    z[1,2,0]  R757      -5.0300967693328857e-01
    z[1,2,0]  R758      -5.6752872467041016e-01
    z[1,2,0]  R759      -6.1493963003158569e-01
    z[1,2,0]  R760      -4.1481819748878479e-01
    z[1,2,0]  R761      -2.0261837542057037e-01
    z[1,2,0]  R762      -6.9657880067825317e-01
    z[1,2,0]  R763      -5.2908849716186523e-01
    z[1,2,0]  R764      -2.1004769206047058e-01
    z[1,2,0]  R765      -8.3767634630203247e-01
    z[1,2,0]  R766      -6.4867216348648071e-01
    z[1,2,0]  R767      -4.2403453588485718e-01
    z[1,2,0]  R768      3.0908182263374329e-01
    z[1,2,0]  R769      -2.7287423610687256e-02
    z[1,2,0]  R770      3.7874868512153625e-01
    z[1,2,0]  R771      5.4182535409927368e-01
    z[1,2,0]  R772      4.1882076859474182e-01
    z[1,2,0]  R773      7.0044904947280884e-01
    z[1,2,0]  R774      4.9352419376373291e-01
    z[1,2,0]  R775      4.3174853920936584e-01
    z[1,2,0]  R776      -6.7483878135681152e-01
    z[1,2,0]  R777      -5.6025809049606323e-01
    z[1,2,0]  R778      -5.9989315271377563e-01
    z[1,2,0]  R779      -1.0695355385541916e-01
    z[1,2,0]  R780      0.602087140083313
    z[1,2,0]  R781      1.4182625710964203e-01
    z[1,2,0]  R782      6.2107789516448975e-01
    z[1,2,0]  R783      5.8524739742279053e-01
    z[1,2,0]  R784      3.9227432012557983e-01
    z[1,2,0]  R785      9.2200249433517456e-02
    z[1,2,0]  R786      -3.3049005270004272e-01
    z[1,2,0]  R787      -4.3728652596473694e-01
    z[1,2,0]  R788      -2.7133550494909286e-02
    z[1,2,0]  R789      -1.9071012502536178e-03
    z[1,2,0]  R790      1.7247703671455383e-01
    z[1,2,0]  R791      2.4037280678749084e-01
    z[1,2,0]  R792      3.6065945029258728e-01
    z[1,2,0]  R793      4.0757986903190613e-01
    z[1,2,0]  R794      0.410907119512558
    z[1,2,0]  R795      4.0464967489242554e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R664      -1
    z[1,2,1]  R665      1
    z[1,2,1]  R676      -7.1999573707580566e-01
    z[1,2,1]  R677      -3.5951447486877441e-01
    z[1,2,1]  R678      -5.4621613025665283e-01
    z[1,2,1]  R679      -1.6242490708827972e-01
    z[1,2,1]  R680      -4.4142702221870422e-01
    z[1,2,1]  R681      -2.7157762646675110e-01
    z[1,2,1]  R682      -5.8418369293212891e-01
    z[1,2,1]  R683      -5.1755124330520630e-01
    z[1,2,1]  R684      -0.0967964380979538
    z[1,2,1]  R685      -1.8083013594150543e-01
    z[1,2,1]  R686      0.252617210149765
    z[1,2,1]  R687      1.4443641901016235e-01
    z[1,2,1]  R688      1.6302208602428436e-01
    z[1,2,1]  R689      2.6922336220741272e-01
    z[1,2,1]  R690      -5.7934081554412842e-01
    z[1,2,1]  R691      -6.4178925752639771e-01
    z[1,2,1]  R692      4.4595742225646973e-01
    z[1,2,1]  R693      -4.1689127683639526e-01
    z[1,2,1]  R694      1.3225845992565155e-01
    z[1,2,1]  R695      -4.0894353389739990e-01
    z[1,2,1]  R696      2.6005470752716064e-01
    z[1,2,1]  R697      2.8158989548683167e-01
    z[1,2,1]  R698      1.1962978541851044e-01
    z[1,2,1]  R699      6.8216927349567413e-02
    z[1,2,1]  R700      3.1921774148941040e-01
    z[1,2,1]  R701      -3.2574182748794556e-01
    z[1,2,1]  R702      2.5507461279630661e-02
    z[1,2,1]  R703      -8.6136408150196075e-02
    z[1,2,1]  R704      7.0345389842987061e-01
    z[1,2,1]  R705      7.4947863817214966e-01
    z[1,2,1]  R706      3.0610787868499756e-01
    z[1,2,1]  R707      -2.9526799917221069e-01
    z[1,2,1]  R708      -1.3627997040748596e-01
    z[1,2,1]  R709      -4.7529456019401550e-01
    z[1,2,1]  R710      -7.9015719890594482e-01
    z[1,2,1]  R711      4.8739153146743774e-01
    z[1,2,1]  R712      -7.3559558391571045e-01
    z[1,2,1]  R713      -5.5131548643112183e-01
    z[1,2,1]  R714      -4.9255535006523132e-01
    z[1,2,1]  R715      4.8768538236618042e-01
    z[1,2,1]  R716      -2.4818757176399231e-01
    z[1,2,1]  R717      -7.0166671276092529e-01
    z[1,2,1]  R718      -1.6952741146087646e-01
    z[1,2,1]  R719      -1.9266216456890106e-01
    z[1,2,1]  R720      4.8682785034179688e-01
    z[1,2,1]  R721      4.3564680218696594e-01
    z[1,2,1]  R722      5.3933960199356079e-01
    z[1,2,1]  R723      4.3277230858802795e-01
    z[1,2,1]  R724      5.5286341905593872e-01
    z[1,2,1]  R725      -0.690163791179657
    z[1,2,1]  R726      -0.218377947807312
    z[1,2,1]  R727      -6.0111218690872192e-01
    z[1,2,1]  R728      -1.8813097476959229e-01
    z[1,2,1]  R729      -6.2833160161972046e-01
    z[1,2,1]  R730      1.2874330580234528e-01
    z[1,2,1]  R731      1.2565034627914429e-01
    z[1,2,1]  R732      -6.9239699840545654e-01
    z[1,2,1]  R733      -9.4848774373531342e-02
    z[1,2,1]  R734      -3.7407833337783813e-01
    z[1,2,1]  R735      6.4214813709259033e-01
    z[1,2,1]  R736      1.3667623698711395e-01
    z[1,2,1]  R737      -6.8870939314365387e-02
    z[1,2,1]  R738      -7.5835567712783813e-01
    z[1,2,1]  R739      -4.3164405971765518e-02
    z[1,2,1]  R740      -3.5222802311182022e-02
    z[1,2,1]  R741      -6.3071471452713013e-01
    z[1,2,1]  R742      -6.2627446651458740e-01
    z[1,2,1]  R743      -3.1206080317497253e-01
    z[1,2,1]  R744      -6.4502626657485962e-01
    z[1,2,1]  R745      1.3340739905834198e-01
    z[1,2,1]  R746      -5.7495719194412231e-01
    z[1,2,1]  R747      1.7622421681880951e-01
    z[1,2,1]  R748      1.8245464190840721e-02
    z[1,2,1]  R749      -7.1773201227188110e-01
    z[1,2,1]  R750      7.1016073226928711e-01
    z[1,2,1]  R751      6.9762754440307617e-01
    z[1,2,1]  R752      2.7729269862174988e-01
    z[1,2,1]  R753      7.4746048450469971e-01
    z[1,2,1]  R754      5.2432936429977417e-01
    z[1,2,1]  R755      6.6270820796489716e-02
    z[1,2,1]  R756      -3.7990295886993408e-01
    z[1,2,1]  R757      5.6112813949584961e-01
    z[1,2,1]  R758      -2.9780879616737366e-01
    z[1,2,1]  R759      -0.264649361371994
    z[1,2,1]  R760      -6.2970317900180817e-02
    z[1,2,1]  R761      -7.4537402391433716e-01
    z[1,2,1]  R762      -1.3572390377521515e-01
    z[1,2,1]  R763      3.1126219034194946e-01
    z[1,2,1]  R764      5.7729268074035645e-01
    z[1,2,1]  R765      1.5036055445671082e-01
    z[1,2,1]  R766      4.3710783123970032e-01
    z[1,2,1]  R767      0.510776162147522
    z[1,2,1]  R768      1.7163111269474030e-01
    z[1,2,1]  R769      1.1031579971313477e-01
    z[1,2,1]  R770      -0.258175253868103
    z[1,2,1]  R771      -1.8876637518405914e-01
    z[1,2,1]  R772      -6.7064231634140015e-01
    z[1,2,1]  R773      1.7958882451057434e-01
    z[1,2,1]  R774      2.3338532447814941e-01
    z[1,2,1]  R775      8.8805359601974487e-01
    z[1,2,1]  R776      2.4562311172485352e-01
    z[1,2,1]  R777      3.8305193185806274e-01
    z[1,2,1]  R778      5.1997935771942139e-01
    z[1,2,1]  R779      4.0128874778747559e-01
    z[1,2,1]  R780      -2.8923526406288147e-01
    z[1,2,1]  R781      1.2952621909789741e-04
    z[1,2,1]  R782      -0.165132075548172
    z[1,2,1]  R783      0.0938212126493454
    z[1,2,1]  R784      -6.4189112186431885e-01
    z[1,2,1]  R785      2.4857778847217560e-01
    z[1,2,1]  R786      1.9468443095684052e-01
    z[1,2,1]  R787      3.9200019836425781e-01
    z[1,2,1]  R788      -7.1944159269332886e-01
    z[1,2,1]  R789      -7.7920407056808472e-01
    z[1,2,1]  R790      4.0922917425632477e-02
    z[1,2,1]  R791      -2.2571529448032379e-01
    z[1,2,1]  R792      9.0154004096984863e-01
    z[1,2,1]  R793      8.3971405029296875e-01
    z[1,2,1]  R794      3.5176548361778259e-01
    z[1,2,1]  R795      2.1756376326084137e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R666      -1
    z[1,2,2]  R667      1
    z[1,2,2]  R676      1.5428924560546875e-01
    z[1,2,2]  R677      4.0962803363800049e-01
    z[1,2,2]  R678      6.6589558124542236e-01
    z[1,2,2]  R679      -5.7522392272949219e-01
    z[1,2,2]  R680      -5.7281100749969482e-01
    z[1,2,2]  R681      -2.7774125337600708e-01
    z[1,2,2]  R682      5.6136876344680786e-01
    z[1,2,2]  R683      3.6103519797325134e-01
    z[1,2,2]  R684      1.8868075311183929e-01
    z[1,2,2]  R685      2.1593287587165833e-01
    z[1,2,2]  R686      7.1879738569259644e-01
    z[1,2,2]  R687      3.8259690999984741e-01
    z[1,2,2]  R688      2.4863047897815704e-01
    z[1,2,2]  R689      4.0550294518470764e-01
    z[1,2,2]  R690      -9.4124749302864075e-02
    z[1,2,2]  R691      -4.7052997350692749e-01
    z[1,2,2]  R692      -0.661577045917511
    z[1,2,2]  R693      -2.0283532142639160e-01
    z[1,2,2]  R694      -3.4149882197380066e-01
    z[1,2,2]  R695      -8.9774593710899353e-02
    z[1,2,2]  R696      -7.1543413400650024e-01
    z[1,2,2]  R697      -5.2829998731613159e-01
    z[1,2,2]  R698      -5.0700902938842773e-01
    z[1,2,2]  R699      -1.2854686379432678e-01
    z[1,2,2]  R700      -5.9702497720718384e-01
    z[1,2,2]  R701      6.1337524652481079e-01
    z[1,2,2]  R702      -2.6337766647338867e-01
    z[1,2,2]  R703      5.3891700506210327e-01
    z[1,2,2]  R704      -4.6299663186073303e-01
    z[1,2,2]  R705      -3.3626869320869446e-01
    z[1,2,2]  R706      -5.5185207165777683e-03
    z[1,2,2]  R707      1.2516488134860992e-01
    z[1,2,2]  R708      -1.8550613522529602e-01
    z[1,2,2]  R709      4.9989435821771622e-02
    z[1,2,2]  R710      3.4611660242080688e-01
    z[1,2,2]  R711      -5.7898926734924316e-01
    z[1,2,2]  R712      -1.8837502598762512e-01
    z[1,2,2]  R713      -1.5222257375717163e-01
    z[1,2,2]  R714      -1.1982090771198273e-01
    z[1,2,2]  R715      -4.3433573842048645e-01
    z[1,2,2]  R716      -3.8566648960113525e-01
    z[1,2,2]  R717      2.9167747497558594e-01
    z[1,2,2]  R718      -5.5262643098831177e-01
    z[1,2,2]  R719      3.9856532216072083e-01
    z[1,2,2]  R720      -4.4477036595344543e-01
    z[1,2,2]  R721      -0.545142650604248
    z[1,2,2]  R722      0.0301351398229599
    z[1,2,2]  R723      -7.3880887031555176e-01
    z[1,2,2]  R724      -6.6751509904861450e-01
    z[1,2,2]  R725      1.7958452925086021e-02
    z[1,2,2]  R726      -3.0071580410003662e-01
    z[1,2,2]  R727      2.2520966827869415e-01
    z[1,2,2]  R728      3.2320278882980347e-01
    z[1,2,2]  R729      4.7071447968482971e-01
    z[1,2,2]  R730      -6.5022307634353638e-01
    z[1,2,2]  R731      -6.3702452182769775e-01
    z[1,2,2]  R732      7.2934284806251526e-02
    z[1,2,2]  R733      2.8145051002502441e-01
    z[1,2,2]  R734      2.4381391704082489e-01
    z[1,2,2]  R735      -8.2089319825172424e-02
    z[1,2,2]  R736      3.9351809024810791e-01
    z[1,2,2]  R737      3.7518355250358582e-01
    z[1,2,2]  R738      -0.393670916557312
    z[1,2,2]  R739      7.3147565126419067e-01
    z[1,2,2]  R740      7.9934698343276978e-01
    z[1,2,2]  R741      -4.9697494506835938e-01
    z[1,2,2]  R742      -7.4237972497940063e-01
    z[1,2,2]  R743      -6.0311222076416016e-01
    z[1,2,2]  R744      -1.4511504769325256e-01
    z[1,2,2]  R745      -2.1574316546320915e-02
    z[1,2,2]  R746      1.5001340769231319e-02
    z[1,2,2]  R747      1.1816588789224625e-01
    z[1,2,2]  R748      3.0645513907074928e-02
    z[1,2,2]  R749      4.0301901102066040e-01
    z[1,2,2]  R750      -0.204465851187706
    z[1,2,2]  R751      2.9491984844207764e-01
    z[1,2,2]  R752      -2.9875391721725464e-01
    z[1,2,2]  R753      8.0763585865497589e-02
    z[1,2,2]  R754      4.5759817957878113e-01
    z[1,2,2]  R755      -0.422170490026474
    z[1,2,2]  R756      -0.523331880569458
    z[1,2,2]  R757      0.362429141998291
    z[1,2,2]  R758      2.7793258428573608e-01
    z[1,2,2]  R759      5.4511779546737671e-01
    z[1,2,2]  R760      4.4897815585136414e-01
    z[1,2,2]  R761      5.0363477319478989e-02
    z[1,2,2]  R762      1.6044487059116364e-01
    z[1,2,2]  R763      1.4809851348400116e-01
    z[1,2,2]  R764      7.5230455398559570e-01
    z[1,2,2]  R765      4.0379768610000610e-01
    z[1,2,2]  R766      7.1681782603263855e-02
    z[1,2,2]  R767      5.9995889663696289e-01
    z[1,2,2]  R768      -4.1300213336944580e-01
    z[1,2,2]  R769      -0.5770223736763
    z[1,2,2]  R770      -3.4725788235664368e-01
    z[1,2,2]  R771      -1.4485648274421692e-01
    z[1,2,2]  R772      -0.0309580210596323
    z[1,2,2]  R773      -4.0920473635196686e-02
    z[1,2,2]  R774      -2.1138539910316467e-01
    z[1,2,2]  R775      1.8279202282428741e-02
    z[1,2,2]  R776      5.6813371181488037e-01
    z[1,2,2]  R777      2.4197937548160553e-01
    z[1,2,2]  R778      -2.0100402832031250e-01
    z[1,2,2]  R779      1.4997847378253937e-01
    z[1,2,2]  R780      -4.4935917854309082e-01
    z[1,2,2]  R781      -0.46416175365448
    z[1,2,2]  R782      -5.9348784387111664e-02
    z[1,2,2]  R783      1.3861194252967834e-01
    z[1,2,2]  R784      -0.0834183618426323
    z[1,2,2]  R785      -3.4910953044891357e-01
    z[1,2,2]  R786      5.9702861309051514e-01
    z[1,2,2]  R787      1.6165429353713989e-01
    z[1,2,2]  R788      -1.9677430391311646e-02
    z[1,2,2]  R789      -2.2065903246402740e-01
    z[1,2,2]  R790      1.6770800948143005e-01
    z[1,2,2]  R791      -2.9879701137542725e-01
    z[1,2,2]  R792      -1.4886486530303955e-01
    z[1,2,2]  R793      -1.8530897796154022e-01
    z[1,2,2]  R794      -4.6247458457946777e-01
    z[1,2,2]  R795      -4.2749953269958496e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R668      -1
    z[1,2,3]  R669      1
    z[1,2,3]  R676      -1.9785149395465851e-01
    z[1,2,3]  R677      -1.5579080581665039e-01
    z[1,2,3]  R678      -1.2824720144271851e-01
    z[1,2,3]  R679      -1.8338501453399658e-01
    z[1,2,3]  R680      -1.1830183863639832e-01
    z[1,2,3]  R681      -2.9639992117881775e-01
    z[1,2,3]  R682      -1.6545537114143372e-01
    z[1,2,3]  R683      -8.5804708302021027e-02
    z[1,2,3]  R684      -2.9832187294960022e-01
    z[1,2,3]  R685      -1.2625852227210999e-01
    z[1,2,3]  R686      3.0539923906326294e-01
    z[1,2,3]  R687      7.6536345481872559e-01
    z[1,2,3]  R688      4.9695274233818054e-01
    z[1,2,3]  R689      5.2950328588485718e-01
    z[1,2,3]  R690      4.5159395784139633e-02
    z[1,2,3]  R691      8.6288101971149445e-02
    z[1,2,3]  R692      -2.1833214163780212e-01
    z[1,2,3]  R693      6.7773485183715820e-01
    z[1,2,3]  R694      5.8339411020278931e-01
    z[1,2,3]  R695      8.2833594083786011e-01
    z[1,2,3]  R696      -4.2537021636962891e-01
    z[1,2,3]  R697      -0.408914178609848
    z[1,2,3]  R698      -6.0810461640357971e-02
    z[1,2,3]  R699      -9.0807807445526123e-01
    z[1,2,3]  R700      1.6254587471485138e-01
    z[1,2,3]  R701      -1.5159854292869568e-01
    z[1,2,3]  R702      -6.9932979345321655e-01
    z[1,2,3]  R703      1.6053098440170288e-01
    z[1,2,3]  R704      3.4772035479545593e-01
    z[1,2,3]  R705      -4.2696991562843323e-01
    z[1,2,3]  R706      -8.7268584966659546e-01
    z[1,2,3]  R707      -5.4635971784591675e-01
    z[1,2,3]  R708      -6.4791935682296753e-01
    z[1,2,3]  R709      -7.7812254428863525e-01
    z[1,2,3]  R710      2.4809615314006805e-01
    z[1,2,3]  R711      5.4636709392070770e-02
    z[1,2,3]  R712      -4.3005886673927307e-01
    z[1,2,3]  R713      -4.3866130709648132e-01
    z[1,2,3]  R714      -3.9875060319900513e-01
    z[1,2,3]  R715      -3.0273789167404175e-01
    z[1,2,3]  R716      -4.1669008135795593e-01
    z[1,2,3]  R717      -8.8196210563182831e-02
    z[1,2,3]  R718      -6.0438591241836548e-01
    z[1,2,3]  R719      -5.9017026424407959e-01
    z[1,2,3]  R720      -1.5177384018898010e-01
    z[1,2,3]  R721      3.3042982220649719e-01
    z[1,2,3]  R722      8.0193474888801575e-02
    z[1,2,3]  R723      0.0891735851764679
    z[1,2,3]  R724      2.8843116760253906e-01
    z[1,2,3]  R725      6.1815810203552246e-01
    z[1,2,3]  R726      -9.0811568498611450e-01
    z[1,2,3]  R727      -4.9738240242004395e-01
    z[1,2,3]  R728      -8.3319848775863647e-01
    z[1,2,3]  R729      4.9404117465019226e-01
    z[1,2,3]  R730      -3.2991480082273483e-02
    z[1,2,3]  R731      3.7585198879241943e-01
    z[1,2,3]  R732      -4.0448507666587830e-01
    z[1,2,3]  R733      -7.5693726539611816e-02
    z[1,2,3]  R734      2.9689380526542664e-01
    z[1,2,3]  R735      5.2299493551254272e-01
    z[1,2,3]  R736      6.6688269376754761e-01
    z[1,2,3]  R737      5.1572436094284058e-01
    z[1,2,3]  R738      -0.0335572175681591
    z[1,2,3]  R739      2.5846010446548462e-01
    z[1,2,3]  R740      3.7230160832405090e-01
    z[1,2,3]  R741      9.4167873263359070e-02
    z[1,2,3]  R742      1.1200413852930069e-01
    z[1,2,3]  R743      -2.5182047486305237e-01
    z[1,2,3]  R744      -1.4875121414661407e-02
    z[1,2,3]  R745      8.9829826354980469e-01
    z[1,2,3]  R746      -5.8477652072906494e-01
    z[1,2,3]  R747      3.4625104069709778e-01
    z[1,2,3]  R748      2.9363808035850525e-01
    z[1,2,3]  R749      -0.509032666683197
    z[1,2,3]  R750      3.5776901245117188e-01
    z[1,2,3]  R751      -8.1725783646106720e-02
    z[1,2,3]  R752      1.5989720821380615e-01
    z[1,2,3]  R753      4.3401163071393967e-02
    z[1,2,3]  R754      2.2026045620441437e-01
    z[1,2,3]  R755      -6.7249870300292969e-01
    z[1,2,3]  R756      -6.6445702314376831e-01
    z[1,2,3]  R757      2.9607766866683960e-01
    z[1,2,3]  R758      6.4727288484573364e-01
    z[1,2,3]  R759      3.8072162866592407e-01
    z[1,2,3]  R760      3.6636695265769958e-01
    z[1,2,3]  R761      -3.3809766173362732e-01
    z[1,2,3]  R762      2.7824339270591736e-01
    z[1,2,3]  R763      1.0880557447671890e-01
    z[1,2,3]  R764      1.6239469870924950e-02
    z[1,2,3]  R765      -1.1333606392145157e-01
    z[1,2,3]  R766      3.5330617427825928e-01
    z[1,2,3]  R767      2.8760345652699471e-02
    z[1,2,3]  R768      7.1464496850967407e-01
    z[1,2,3]  R769      7.4313563108444214e-01
    z[1,2,3]  R770      6.5993690490722656e-01
    z[1,2,3]  R771      7.3723417520523071e-01
    z[1,2,3]  R772      5.7594460248947144e-01
    z[1,2,3]  R773      3.9901995658874512e-01
    z[1,2,3]  R774      2.5344261527061462e-01
    z[1,2,3]  R775      -7.5182631611824036e-02
    z[1,2,3]  R776      3.6799827218055725e-01
    z[1,2,3]  R777      2.8462353348731995e-01
    z[1,2,3]  R778      4.3726623058319092e-01
    z[1,2,3]  R779      8.8551706075668335e-01
    z[1,2,3]  R780      -3.9345484972000122e-01
    z[1,2,3]  R781      0.773955762386322
    z[1,2,3]  R782      5.0759112834930420e-01
    z[1,2,3]  R783      3.9197233319282532e-01
    z[1,2,3]  R784      0.642471969127655
    z[1,2,3]  R785      1.5008336305618286e-01
    z[1,2,3]  R786      4.8011535406112671e-01
    z[1,2,3]  R787      2.3251669108867645e-01
    z[1,2,3]  R788      -1.5396174788475037e-01
    z[1,2,3]  R789      -1.6268764436244965e-01
    z[1,2,3]  R790      3.4525668621063232e-01
    z[1,2,3]  R791      0.374606728553772
    z[1,2,3]  R792      -1.6411715745925903e-01
    z[1,2,3]  R793      9.1871835291385651e-02
    z[1,2,3]  R794      6.4905665814876556e-02
    z[1,2,3]  R795      1.3168838620185852e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R670      -1
    z[1,2,4]  R671      1
    z[1,2,4]  R676      2.8005328774452209e-01
    z[1,2,4]  R677      3.1539127230644226e-01
    z[1,2,4]  R678      1.8078483641147614e-01
    z[1,2,4]  R679      3.1668260693550110e-01
    z[1,2,4]  R680      5.9276384115219116e-01
    z[1,2,4]  R681      1.5372152626514435e-01
    z[1,2,4]  R682      -3.5441529750823975e-01
    z[1,2,4]  R683      0.682155430316925
    z[1,2,4]  R684      8.0553829669952393e-01
    z[1,2,4]  R685      7.1015870571136475e-01
    z[1,2,4]  R686      -2.3386125266551971e-01
    z[1,2,4]  R687      -4.2920134961605072e-02
    z[1,2,4]  R688      6.7264698445796967e-03
    z[1,2,4]  R689      -1.3860683143138885e-01
    z[1,2,4]  R690      -1.0556232929229736e-01
    z[1,2,4]  R691      -0.180857852101326
    z[1,2,4]  R692      -0.347945898771286
    z[1,2,4]  R693      1.9008468091487885e-01
    z[1,2,4]  R694      -5.6145143508911133e-01
    z[1,2,4]  R695      -1.2967351078987122e-01
    z[1,2,4]  R696      1.1638043820858002e-01
    z[1,2,4]  R697      3.6474909633398056e-02
    z[1,2,4]  R698      -2.7737969160079956e-01
    z[1,2,4]  R699      1.9040282070636749e-01
    z[1,2,4]  R700      -2.9372459650039673e-01
    z[1,2,4]  R701      -6.5552002191543579e-01
    z[1,2,4]  R702      6.1285290867090225e-02
    z[1,2,4]  R703      -3.7403675913810730e-01
    z[1,2,4]  R704      1.5211680531501770e-01
    z[1,2,4]  R705      2.6128438115119934e-01
    z[1,2,4]  R706      -0.0209683645516634
    z[1,2,4]  R707      2.5459289550781250e-01
    z[1,2,4]  R708      6.8388420343399048e-01
    z[1,2,4]  R709      -2.5255185365676880e-01
    z[1,2,4]  R710      -3.7624785304069519e-01
    z[1,2,4]  R711      2.7798625826835632e-01
    z[1,2,4]  R712      -1.2289223819971085e-01
    z[1,2,4]  R713      -5.3070688247680664e-01
    z[1,2,4]  R714      -4.8383176326751709e-01
    z[1,2,4]  R715      4.1114774346351624e-01
    z[1,2,4]  R716      1.1680650711059570e-01
    z[1,2,4]  R717      7.0235341787338257e-02
    z[1,2,4]  R718      -4.6366035938262939e-01
    z[1,2,4]  R719      2.2281800210475922e-01
    z[1,2,4]  R720      -2.2254188358783722e-01
    z[1,2,4]  R721      -4.0633025765419006e-01
    z[1,2,4]  R722      -8.1712412834167480e-01
    z[1,2,4]  R723      -2.9364114999771118e-01
    z[1,2,4]  R724      1.6318482160568237e-01
    z[1,2,4]  R725      2.2752128541469574e-01
    z[1,2,4]  R726      1.4992308802902699e-02
    z[1,2,4]  R727      0.574512779712677
    z[1,2,4]  R728      -1.1573029309511185e-01
    z[1,2,4]  R729      6.6686391830444336e-02
    z[1,2,4]  R730      -0.254208505153656
    z[1,2,4]  R731      1.9960589706897736e-01
    z[1,2,4]  R732      -0.208910271525383
    z[1,2,4]  R733      -4.3405908346176147e-01
    z[1,2,4]  R734      4.1917651891708374e-01
    z[1,2,4]  R735      -7.3116861283779144e-02
    z[1,2,4]  R736      -2.3895879089832306e-01
    z[1,2,4]  R737      -4.7157695889472961e-01
    z[1,2,4]  R738      -3.7143155932426453e-01
    z[1,2,4]  R739      -5.8237057924270630e-01
    z[1,2,4]  R740      4.2662656307220459e-01
    z[1,2,4]  R741      -3.4332302212715149e-01
    z[1,2,4]  R742      -1.3079759478569031e-01
    z[1,2,4]  R743      -6.1369098722934723e-02
    z[1,2,4]  R744      -1.6491885483264923e-01
    z[1,2,4]  R745      3.5114273428916931e-01
    z[1,2,4]  R746      -1.4118352532386780e-01
    z[1,2,4]  R747      3.3173173666000366e-01
    z[1,2,4]  R748      -1.0776351392269135e-01
    z[1,2,4]  R749      -1.4837658405303955e-01
    z[1,2,4]  R750      -3.0603675171732903e-02
    z[1,2,4]  R751      -4.1560694575309753e-01
    z[1,2,4]  R752      -0.0971241444349289
    z[1,2,4]  R753      2.3729506134986877e-01
    z[1,2,4]  R754      3.9734295010566711e-01
    z[1,2,4]  R755      -1.9221581518650055e-01
    z[1,2,4]  R756      -3.3902657032012939e-01
    z[1,2,4]  R757      2.2356674075126648e-01
    z[1,2,4]  R758      -1.6046515107154846e-01
    z[1,2,4]  R759      2.5032532215118408e-01
    z[1,2,4]  R760      -5.6066513061523438e-01
    z[1,2,4]  R761      -2.8734448552131653e-01
    z[1,2,4]  R762      -4.5655864477157593e-01
    z[1,2,4]  R763      -5.9938418865203857e-01
    z[1,2,4]  R764      -5.5443480610847473e-02
    z[1,2,4]  R765      -3.0573008116334677e-03
    z[1,2,4]  R766      2.4033010005950928e-01
    z[1,2,4]  R767      -2.1824173629283905e-01
    z[1,2,4]  R768      -2.3332582414150238e-01
    z[1,2,4]  R769      -2.1850545704364777e-01
    z[1,2,4]  R770      -3.8703937083482742e-02
    z[1,2,4]  R771      4.0596637874841690e-02
    z[1,2,4]  R772      1.8956919014453888e-01
    z[1,2,4]  R773      -2.4005274474620819e-01
    z[1,2,4]  R774      -8.1402897834777832e-02
    z[1,2,4]  R775      1.0504613071680069e-01
    z[1,2,4]  R776      -7.7836655080318451e-02
    z[1,2,4]  R777      -0.404949426651001
    z[1,2,4]  R778      -2.4935327470302582e-01
    z[1,2,4]  R779      5.4351929575204849e-02
    z[1,2,4]  R780      3.2880973815917969e-01
    z[1,2,4]  R781      -2.1899476647377014e-01
    z[1,2,4]  R782      -2.7377369999885559e-01
    z[1,2,4]  R783      -1.4054611325263977e-01
    z[1,2,4]  R784      7.4891060590744019e-02
    z[1,2,4]  R785      -2.6861688494682312e-01
    z[1,2,4]  R786      1.3103212416172028e-01
    z[1,2,4]  R787      -6.5347111225128174e-01
    z[1,2,4]  R788      3.8102969527244568e-01
    z[1,2,4]  R789      3.8656479120254517e-01
    z[1,2,4]  R790      -9.0547271072864532e-02
    z[1,2,4]  R791      -1.6460482776165009e-01
    z[1,2,4]  R792      -4.8961769789457321e-04
    z[1,2,4]  R793      -1.9483752548694611e-01
    z[1,2,4]  R794      -0.689633846282959
    z[1,2,4]  R795      -5.9421205520629883e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R672      -1
    z[1,2,5]  R673      1
    z[1,2,5]  R676      1.2996168434619904e-01
    z[1,2,5]  R677      4.9831250309944153e-01
    z[1,2,5]  R678      -5.2954863756895065e-02
    z[1,2,5]  R679      -1.0397800803184509e-01
    z[1,2,5]  R680      -4.3760299682617188e-02
    z[1,2,5]  R681      -4.7443735599517822e-01
    z[1,2,5]  R682      4.0084591507911682e-01
    z[1,2,5]  R683      2.3899297416210175e-01
    z[1,2,5]  R684      -1.7053984105587006e-01
    z[1,2,5]  R685      -9.2424347996711731e-02
    z[1,2,5]  R686      6.7016161978244781e-02
    z[1,2,5]  R687      1.2693777680397034e-01
    z[1,2,5]  R688      -8.8410764932632446e-02
    z[1,2,5]  R689      4.9413305521011353e-01
    z[1,2,5]  R690      -5.4077520966529846e-02
    z[1,2,5]  R691      -3.5688707232475281e-01
    z[1,2,5]  R692      7.8935608267784119e-02
    z[1,2,5]  R693      -0.186315655708313
    z[1,2,5]  R694      -6.7505680024623871e-02
    z[1,2,5]  R695      6.6189900040626526e-02
    z[1,2,5]  R696      -3.7717631459236145e-01
    z[1,2,5]  R697      -5.9734326601028442e-01
    z[1,2,5]  R698      -4.7837734222412109e-01
    z[1,2,5]  R699      2.5130003690719604e-01
    z[1,2,5]  R700      -6.3161790370941162e-01
    z[1,2,5]  R701      1.6878260672092438e-01
    z[1,2,5]  R702      5.8353751897811890e-01
    z[1,2,5]  R703      3.8660675287246704e-01
    z[1,2,5]  R704      -0.318907767534256
    z[1,2,5]  R705      -1.6402861475944519e-01
    z[1,2,5]  R706      -1.2997676432132721e-01
    z[1,2,5]  R707      -3.9555296301841736e-01
    z[1,2,5]  R708      1.1939511448144913e-01
    z[1,2,5]  R709      -1.0598129779100418e-01
    z[1,2,5]  R710      0.0935024619102478
    z[1,2,5]  R711      -5.0922483205795288e-01
    z[1,2,5]  R712      -2.5957217812538147e-01
    z[1,2,5]  R713      -3.4279155731201172e-01
    z[1,2,5]  R714      -2.1769352257251740e-01
    z[1,2,5]  R715      2.4725930392742157e-01
    z[1,2,5]  R716      -5.9044855833053589e-01
    z[1,2,5]  R717      3.7515202164649963e-01
    z[1,2,5]  R718      -0.0705728530883789
    z[1,2,5]  R719      6.1502200365066528e-01
    z[1,2,5]  R720      -3.3472391963005066e-01
    z[1,2,5]  R721      -3.5757660865783691e-01
    z[1,2,5]  R722      -7.8355483710765839e-02
    z[1,2,5]  R723      -1.3906839489936829e-01
    z[1,2,5]  R724      -1.8571268767118454e-02
    z[1,2,5]  R725      -2.0394992828369141e-01
    z[1,2,5]  R726      0.0060595260001719
    z[1,2,5]  R727      7.9848654568195343e-02
    z[1,2,5]  R728      3.7020778656005859e-01
    z[1,2,5]  R729      3.0023878812789917e-01
    z[1,2,5]  R730      -3.0967068672180176e-01
    z[1,2,5]  R731      -3.7857425212860107e-01
    z[1,2,5]  R732      -5.5424129962921143e-01
    z[1,2,5]  R733      5.4742813110351562e-01
    z[1,2,5]  R734      -2.9570639133453369e-01
    z[1,2,5]  R735      3.1599190831184387e-01
    z[1,2,5]  R736      -2.4737168103456497e-02
    z[1,2,5]  R737      5.7684624195098877e-01
    z[1,2,5]  R738      0.331180602312088
    z[1,2,5]  R739      2.2983746230602264e-01
    z[1,2,5]  R740      -1.2704163789749146e-01
    z[1,2,5]  R741      -1.1993834376335144e-01
    z[1,2,5]  R742      -3.6350786685943604e-02
    z[1,2,5]  R743      7.7492587268352509e-02
    z[1,2,5]  R744      -1.1959101259708405e-01
    z[1,2,5]  R745      -6.9265522062778473e-02
    z[1,2,5]  R746      -1.3553163409233093e-01
    z[1,2,5]  R747      -3.1456491351127625e-01
    z[1,2,5]  R748      2.5362795591354370e-01
    z[1,2,5]  R749      -0.0747024267911911
    z[1,2,5]  R750      1.3659586012363434e-01
    z[1,2,5]  R751      9.5757313072681427e-02
    z[1,2,5]  R752      -1.7079490423202515e-01
    z[1,2,5]  R753      -7.5730629265308380e-02
    z[1,2,5]  R754      -4.2192158102989197e-01
    z[1,2,5]  R755      3.4134829044342041e-01
    z[1,2,5]  R756      2.6010846719145775e-02
    z[1,2,5]  R757      1.0972206294536591e-01
    z[1,2,5]  R758      2.2955326735973358e-01
    z[1,2,5]  R759      -1.1781092733144760e-01
    z[1,2,5]  R760      -2.6004803180694580e-01
    z[1,2,5]  R761      -2.0570079982280731e-01
    z[1,2,5]  R762      -4.2971235513687134e-01
    z[1,2,5]  R763      4.7969031333923340e-01
    z[1,2,5]  R764      8.0762747675180435e-03
    z[1,2,5]  R765      -2.8292128443717957e-01
    z[1,2,5]  R766      -4.2411741614341736e-01
    z[1,2,5]  R767      3.6013630032539368e-01
    z[1,2,5]  R768      3.7317776679992676e-01
    z[1,2,5]  R769      2.3234508931636810e-01
    z[1,2,5]  R770      3.9454281330108643e-01
    z[1,2,5]  R771      3.0197301506996155e-01
    z[1,2,5]  R772      4.3862808495759964e-02
    z[1,2,5]  R773      5.0850385427474976e-01
    z[1,2,5]  R774      6.0775619745254517e-01
    z[1,2,5]  R775      8.8746301829814911e-02
    z[1,2,5]  R776      1.2499637901782990e-01
    z[1,2,5]  R777      -4.8106333613395691e-01
    z[1,2,5]  R778      -7.4209660291671753e-02
    z[1,2,5]  R779      1.3393706083297729e-01
    z[1,2,5]  R780      -9.5786139369010925e-02
    z[1,2,5]  R781      3.3809685707092285e-01
    z[1,2,5]  R782      5.0066936016082764e-01
    z[1,2,5]  R783      6.2086051702499390e-01
    z[1,2,5]  R784      9.3482971191406250e-02
    z[1,2,5]  R785      6.6434174776077271e-01
    z[1,2,5]  R786      -3.0788388848304749e-01
    z[1,2,5]  R787      2.0122538506984711e-01
    z[1,2,5]  R788      -1.6681909561157227e-02
    z[1,2,5]  R789      -3.8226428627967834e-01
    z[1,2,5]  R790      6.9038450717926025e-01
    z[1,2,5]  R791      6.1444973945617676e-01
    z[1,2,5]  R792      6.2699727714061737e-02
    z[1,2,5]  R793      -1.7816412448883057e-01
    z[1,2,5]  R794      1.0726174712181091e-01
    z[1,2,5]  R795      -2.1086144447326660e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R674      -1
    z[1,2,6]  R675      1
    z[1,2,6]  R676      -4.1296545416116714e-02
    z[1,2,6]  R677      4.7544579952955246e-02
    z[1,2,6]  R678      -2.8484994173049927e-01
    z[1,2,6]  R679      -3.4448447823524475e-01
    z[1,2,6]  R680      1.0768654197454453e-01
    z[1,2,6]  R681      -5.8732575178146362e-01
    z[1,2,6]  R682      1.0995424352586269e-02
    z[1,2,6]  R683      1.1395853757858276e-01
    z[1,2,6]  R684      -3.8139519095420837e-01
    z[1,2,6]  R685      7.5161732733249664e-02
    z[1,2,6]  R686      9.8768718540668488e-02
    z[1,2,6]  R687      -1.5962858498096466e-01
    z[1,2,6]  R688      -3.5750970244407654e-01
    z[1,2,6]  R689      -1.5360661782324314e-02
    z[1,2,6]  R690      -1.5741893649101257e-01
    z[1,2,6]  R691      3.2253009080886841e-01
    z[1,2,6]  R692      3.8437563180923462e-01
    z[1,2,6]  R693      -1.6234208643436432e-01
    z[1,2,6]  R694      -1.6507243737578392e-02
    z[1,2,6]  R695      8.9567065238952637e-02
    z[1,2,6]  R696      3.1049272045493126e-02
    z[1,2,6]  R697      1.2024573236703873e-01
    z[1,2,6]  R698      -0.277940034866333
    z[1,2,6]  R699      2.0571085810661316e-01
    z[1,2,6]  R700      7.1777604520320892e-02
    z[1,2,6]  R701      -1.4794050157070160e-01
    z[1,2,6]  R702      -7.2795733809471130e-02
    z[1,2,6]  R703      -3.8922619819641113e-01
    z[1,2,6]  R704      -1.8607042729854584e-01
    z[1,2,6]  R705      -1.2934499979019165e-01
    z[1,2,6]  R706      8.4637450054287910e-03
    z[1,2,6]  R707      1.3048601150512695e-01
    z[1,2,6]  R708      5.3298264741897583e-02
    z[1,2,6]  R709      -2.7908441424369812e-01
    z[1,2,6]  R710      1.6596347093582153e-01
    z[1,2,6]  R711      0.00876099057495594
    z[1,2,6]  R712      3.9219805598258972e-01
    z[1,2,6]  R713      2.2666966915130615e-01
    z[1,2,6]  R714      5.0538641214370728e-01
    z[1,2,6]  R715      4.1560640931129456e-01
    z[1,2,6]  R716      2.2250089049339294e-01
    z[1,2,6]  R717      4.8746901750564575e-01
    z[1,2,6]  R718      3.5872368607670069e-03
    z[1,2,6]  R719      0.087613046169281
    z[1,2,6]  R720      -5.4974645376205444e-01
    z[1,2,6]  R721      -2.0097108185291290e-01
    z[1,2,6]  R722      -1.6633279621601105e-01
    z[1,2,6]  R723      3.9147740602493286e-01
    z[1,2,6]  R724      -2.4853512644767761e-01
    z[1,2,6]  R725      -5.5437427014112473e-02
    z[1,2,6]  R726      7.4375040829181671e-02
    z[1,2,6]  R727      6.3531458377838135e-02
    z[1,2,6]  R728      -6.5903551876544952e-02
    z[1,2,6]  R729      -6.2070630490779877e-02
    z[1,2,6]  R730      -9.2620790004730225e-02
    z[1,2,6]  R731      -2.5661420822143555e-01
    z[1,2,6]  R732      -2.8402399271726608e-02
    z[1,2,6]  R733      -1.0774499922990799e-01
    z[1,2,6]  R734      -0.587288498878479
    z[1,2,6]  R735      2.1513158082962036e-01
    z[1,2,6]  R736      -4.6538898348808289e-01
    z[1,2,6]  R737      2.3281384259462357e-02
    z[1,2,6]  R738      1.2262260913848877e-01
    z[1,2,6]  R739      -5.3310345858335495e-02
    z[1,2,6]  R740      1.0644710063934326e-01
    z[1,2,6]  R741      -4.4793951511383057e-01
    z[1,2,6]  R742      -3.8373082876205444e-02
    z[1,2,6]  R743      4.5984596014022827e-01
    z[1,2,6]  R744      -4.6277174353599548e-01
    z[1,2,6]  R745      1.7444470524787903e-01
    z[1,2,6]  R746      -3.2454732060432434e-01
    z[1,2,6]  R747      3.7547999620437622e-01
    z[1,2,6]  R748      4.2403522133827209e-01
    z[1,2,6]  R749      -1.6031830012798309e-01
    z[1,2,6]  R750      2.3387399315834045e-01
    z[1,2,6]  R751      2.5553089380264282e-01
    z[1,2,6]  R752      0.0127909230068326
    z[1,2,6]  R753      2.9407903552055359e-01
    z[1,2,6]  R754      -1.4919905364513397e-01
    z[1,2,6]  R755      3.4494093060493469e-01
    z[1,2,6]  R756      4.6677622012794018e-03
    z[1,2,6]  R757      3.8868820667266846e-01
    z[1,2,6]  R758      1.2070067971944809e-01
    z[1,2,6]  R759      1.8211397528648376e-01
    z[1,2,6]  R760      3.2585906982421875e-01
    z[1,2,6]  R761      -4.0204131603240967e-01
    z[1,2,6]  R762      -9.8212985321879387e-03
    z[1,2,6]  R763      -6.7253420129418373e-03
    z[1,2,6]  R764      -2.3075561225414276e-01
    z[1,2,6]  R765      -1.4049398899078369e-01
    z[1,2,6]  R766      -1.4339953660964966e-01
    z[1,2,6]  R767      1.4559175074100494e-01
    z[1,2,6]  R768      4.5146606862545013e-03
    z[1,2,6]  R769      1.2308930046856403e-02
    z[1,2,6]  R770      2.7681791782379150e-01
    z[1,2,6]  R771      1.1601343005895615e-01
    z[1,2,6]  R772      6.5551467239856720e-02
    z[1,2,6]  R773      -5.1159677095711231e-03
    z[1,2,6]  R774      4.6589076519012451e-01
    z[1,2,6]  R775      7.5365439988672733e-03
    z[1,2,6]  R776      0.06618682295084
    z[1,2,6]  R777      6.6418468952178955e-02
    z[1,2,6]  R778      -2.6544502377510071e-01
    z[1,2,6]  R779      -9.4690709374845028e-04
    z[1,2,6]  R780      2.8251171112060547e-01
    z[1,2,6]  R781      5.6245069950819016e-02
    z[1,2,6]  R782      -1.4166802167892456e-02
    z[1,2,6]  R783      2.6571869850158691e-01
    z[1,2,6]  R784      -4.4701248407363892e-03
    z[1,2,6]  R785      5.2134519815444946e-01
    z[1,2,6]  R786      -3.9237537980079651e-01
    z[1,2,6]  R787      -3.2772576808929443e-01
    z[1,2,6]  R788      5.5867195129394531e-01
    z[1,2,6]  R789      0.148732990026474
    z[1,2,6]  R790      5.8001667261123657e-01
    z[1,2,6]  R791      5.0697189569473267e-01
    z[1,2,6]  R792      -0.0642150416970253
    z[1,2,6]  R793      -1.2757311761379242e-01
    z[1,2,6]  R794      4.7128215432167053e-02
    z[1,2,6]  R795      4.3735164403915405e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R796      -1
    z[2,1,0]  R797      1
    z[2,1,0]  R810      -3.2776564359664917e-01
    z[2,1,0]  R811      -1.8122953176498413e-01
    z[2,1,0]  R812      0.0782022625207901
    z[2,1,0]  R813      -3.8154255598783493e-02
    z[2,1,0]  R814      -1.0823357105255127e-01
    z[2,1,0]  R815      1.1593800783157349e-01
    z[2,1,0]  R816      1.5558232367038727e-01
    z[2,1,0]  R817      -5.0421273708343506e-01
    z[2,1,0]  R818      5.5407893657684326e-01
    z[2,1,0]  R819      -1.2754349410533905e-01
    z[2,1,0]  R820      4.2848935723304749e-01
    z[2,1,0]  R821      -6.9649821519851685e-01
    z[2,1,0]  R822      -8.1040644645690918e-01
    z[2,1,0]  R823      -1.0012060403823853e-01
    z[2,1,0]  R824      -5.0157243013381958e-01
    z[2,1,0]  R825      -4.1528832912445068e-01
    z[2,1,0]  R826      -8.7722289562225342e-01
    z[2,1,0]  R827      -5.3326344490051270e-01
    z[2,1,0]  R828      -3.3016419410705566e-01
    z[2,1,0]  R829      3.0442732572555542e-01
    z[2,1,0]  R830      -1.5702560544013977e-01
    z[2,1,0]  R831      -5.0300967693328857e-01
    z[2,1,0]  R832      -5.6752872467041016e-01
    z[2,1,0]  R833      -6.1493963003158569e-01
    z[2,1,0]  R834      -4.1481819748878479e-01
    z[2,1,0]  R835      -2.0261837542057037e-01
    z[2,1,0]  R836      -6.9657880067825317e-01
    z[2,1,0]  R837      -5.2908849716186523e-01
    z[2,1,0]  R838      -2.1004769206047058e-01
    z[2,1,0]  R839      -8.3767634630203247e-01
    z[2,1,0]  R840      -6.4867216348648071e-01
    z[2,1,0]  R841      -4.2403453588485718e-01
    z[2,1,0]  R842      3.0908182263374329e-01
    z[2,1,0]  R843      -2.7287423610687256e-02
    z[2,1,0]  R844      3.7874868512153625e-01
    z[2,1,0]  R845      5.4182535409927368e-01
    z[2,1,0]  R846      4.1882076859474182e-01
    z[2,1,0]  R847      7.0044904947280884e-01
    z[2,1,0]  R848      4.9352419376373291e-01
    z[2,1,0]  R849      4.3174853920936584e-01
    z[2,1,0]  R850      -6.7483878135681152e-01
    z[2,1,0]  R851      -5.6025809049606323e-01
    z[2,1,0]  R852      -5.9989315271377563e-01
    z[2,1,0]  R853      -1.0695355385541916e-01
    z[2,1,0]  R854      0.602087140083313
    z[2,1,0]  R855      1.4182625710964203e-01
    z[2,1,0]  R856      6.2107789516448975e-01
    z[2,1,0]  R857      5.8524739742279053e-01
    z[2,1,0]  R858      3.9227432012557983e-01
    z[2,1,0]  R859      9.2200249433517456e-02
    z[2,1,0]  R860      -3.3049005270004272e-01
    z[2,1,0]  R861      -4.3728652596473694e-01
    z[2,1,0]  R862      -2.7133550494909286e-02
    z[2,1,0]  R863      -1.9071012502536178e-03
    z[2,1,0]  R864      1.7247703671455383e-01
    z[2,1,0]  R865      2.4037280678749084e-01
    z[2,1,0]  R866      3.6065945029258728e-01
    z[2,1,0]  R867      4.0757986903190613e-01
    z[2,1,0]  R868      0.410907119512558
    z[2,1,0]  R869      4.0464967489242554e-01
    z[2,1,0]  R870      5.6712478399276733e-01
    z[2,1,0]  R871      5.7326781749725342e-01
    z[2,1,0]  R872      3.5377502441406250e-01
    z[2,1,0]  R873      6.1590307950973511e-01
    z[2,1,0]  R874      3.1329560279846191e-01
    z[2,1,0]  R875      4.0936514735221863e-01
    z[2,1,0]  R876      1.7265732586383820e-01
    z[2,1,0]  R877      2.4288158118724823e-01
    z[2,1,0]  R878      2.0638771355152130e-01
    z[2,1,0]  R879      0.621462345123291
    z[2,1,0]  R880      -5.0725597143173218e-01
    z[2,1,0]  R881      -4.5115393400192261e-01
    z[2,1,0]  R882      -7.2730302810668945e-01
    z[2,1,0]  R883      -4.6807822585105896e-01
    z[2,1,0]  R884      -7.8397506475448608e-01
    z[2,1,0]  R885      -3.0847826600074768e-01
    z[2,1,0]  R886      -2.0180958509445190e-01
    z[2,1,0]  R887      -4.7805258631706238e-01
    z[2,1,0]  R888      -4.5329952239990234e-01
    z[2,1,0]  R889      -3.3067616820335388e-01
    z[2,1,0]  R890      -2.8777632117271423e-01
    z[2,1,0]  R891      3.1904092431068420e-01
    z[2,1,0]  R892      -5.8472013473510742e-01
    z[2,1,0]  R893      -1.1177876591682434e-01
    z[2,1,0]  R894      1.5771120786666870e-01
    z[2,1,0]  R895      -1.2083274126052856e-01
    z[2,1,0]  R896      -3.0223888158798218e-01
    z[2,1,0]  R897      -4.8529732227325439e-01
    z[2,1,0]  R898      1.0204591602087021e-01
    z[2,1,0]  R899      1.7605938017368317e-01
    z[2,1,0]  R900      3.5676565766334534e-01
    z[2,1,0]  R901      6.0027921199798584e-01
    z[2,1,0]  R902      -2.0596690475940704e-01
    z[2,1,0]  R903      -1.1497341096401215e-01
    z[2,1,0]  R904      -1.2827318906784058e-01
    z[2,1,0]  R905      2.9592707753181458e-01
    z[2,1,0]  R906      -4.6516966074705124e-02
    z[2,1,0]  R907      -1.7297618091106415e-01
    z[2,1,0]  R908      2.1709685027599335e-01
    z[2,1,0]  R909      2.8099268674850464e-01
    z[2,1,0]  R910      4.5194447040557861e-01
    z[2,1,0]  R911      1.7751461267471313e-01
    z[2,1,0]  R912      2.8391501307487488e-01
    z[2,1,0]  R913      -0.141950786113739
    z[2,1,0]  R914      -2.7992233633995056e-01
    z[2,1,0]  R915      -2.6550477743148804e-01
    z[2,1,0]  R916      -1.6600802540779114e-02
    z[2,1,0]  R917      -9.8987082019448280e-03
    z[2,1,0]  R918      -2.7718076109886169e-01
    z[2,1,0]  R919      -2.1165333688259125e-01
    z[2,1,0]  R920      -1.7723931372165680e-01
    z[2,1,0]  R921      8.8512469083070755e-03
    z[2,1,0]  R922      1.0552880913019180e-01
    z[2,1,0]  R923      -2.0274975895881653e-01
    z[2,1,0]  R924      -6.2486010789871216e-01
    z[2,1,0]  R925      -4.3374547362327576e-01
    z[2,1,0]  R926      -5.0168428570032120e-03
    z[2,1,0]  R927      -6.3746839761734009e-01
    z[2,1,0]  R928      -3.2313367724418640e-01
    z[2,1,0]  R929      3.9484769105911255e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R798      -1
    z[2,1,1]  R799      1
    z[2,1,1]  R810      1.3667623698711395e-01
    z[2,1,1]  R811      -6.8870939314365387e-02
    z[2,1,1]  R812      -7.5835567712783813e-01
    z[2,1,1]  R813      -4.3164405971765518e-02
    z[2,1,1]  R814      -3.5222802311182022e-02
    z[2,1,1]  R815      -6.3071471452713013e-01
    z[2,1,1]  R816      -6.2627446651458740e-01
    z[2,1,1]  R817      -3.1206080317497253e-01
    z[2,1,1]  R818      -6.4502626657485962e-01
    z[2,1,1]  R819      1.3340739905834198e-01
    z[2,1,1]  R820      -5.7495719194412231e-01
    z[2,1,1]  R821      1.7622421681880951e-01
    z[2,1,1]  R822      1.8245464190840721e-02
    z[2,1,1]  R823      -7.1773201227188110e-01
    z[2,1,1]  R824      7.1016073226928711e-01
    z[2,1,1]  R825      6.9762754440307617e-01
    z[2,1,1]  R826      2.7729269862174988e-01
    z[2,1,1]  R827      7.4746048450469971e-01
    z[2,1,1]  R828      5.2432936429977417e-01
    z[2,1,1]  R829      6.6270820796489716e-02
    z[2,1,1]  R830      -3.7990295886993408e-01
    z[2,1,1]  R831      5.6112813949584961e-01
    z[2,1,1]  R832      -2.9780879616737366e-01
    z[2,1,1]  R833      -0.264649361371994
    z[2,1,1]  R834      -6.2970317900180817e-02
    z[2,1,1]  R835      -7.4537402391433716e-01
    z[2,1,1]  R836      -1.3572390377521515e-01
    z[2,1,1]  R837      3.1126219034194946e-01
    z[2,1,1]  R838      5.7729268074035645e-01
    z[2,1,1]  R839      1.5036055445671082e-01
    z[2,1,1]  R840      4.3710783123970032e-01
    z[2,1,1]  R841      0.510776162147522
    z[2,1,1]  R842      1.7163111269474030e-01
    z[2,1,1]  R843      1.1031579971313477e-01
    z[2,1,1]  R844      -0.258175253868103
    z[2,1,1]  R845      -1.8876637518405914e-01
    z[2,1,1]  R846      -6.7064231634140015e-01
    z[2,1,1]  R847      1.7958882451057434e-01
    z[2,1,1]  R848      2.3338532447814941e-01
    z[2,1,1]  R849      8.8805359601974487e-01
    z[2,1,1]  R850      2.4562311172485352e-01
    z[2,1,1]  R851      3.8305193185806274e-01
    z[2,1,1]  R852      5.1997935771942139e-01
    z[2,1,1]  R853      4.0128874778747559e-01
    z[2,1,1]  R854      -2.8923526406288147e-01
    z[2,1,1]  R855      1.2952621909789741e-04
    z[2,1,1]  R856      -0.165132075548172
    z[2,1,1]  R857      0.0938212126493454
    z[2,1,1]  R858      -6.4189112186431885e-01
    z[2,1,1]  R859      2.4857778847217560e-01
    z[2,1,1]  R860      1.9468443095684052e-01
    z[2,1,1]  R861      3.9200019836425781e-01
    z[2,1,1]  R862      -7.1944159269332886e-01
    z[2,1,1]  R863      -7.7920407056808472e-01
    z[2,1,1]  R864      4.0922917425632477e-02
    z[2,1,1]  R865      -2.2571529448032379e-01
    z[2,1,1]  R866      9.0154004096984863e-01
    z[2,1,1]  R867      8.3971405029296875e-01
    z[2,1,1]  R868      3.5176548361778259e-01
    z[2,1,1]  R869      2.1756376326084137e-01
    z[2,1,1]  R870      -7.1999573707580566e-01
    z[2,1,1]  R871      -3.5951447486877441e-01
    z[2,1,1]  R872      -5.4621613025665283e-01
    z[2,1,1]  R873      -1.6242490708827972e-01
    z[2,1,1]  R874      -4.4142702221870422e-01
    z[2,1,1]  R875      -2.7157762646675110e-01
    z[2,1,1]  R876      -5.8418369293212891e-01
    z[2,1,1]  R877      -5.1755124330520630e-01
    z[2,1,1]  R878      -0.0967964380979538
    z[2,1,1]  R879      -1.8083013594150543e-01
    z[2,1,1]  R880      0.252617210149765
    z[2,1,1]  R881      1.4443641901016235e-01
    z[2,1,1]  R882      1.6302208602428436e-01
    z[2,1,1]  R883      2.6922336220741272e-01
    z[2,1,1]  R884      -5.7934081554412842e-01
    z[2,1,1]  R885      -6.4178925752639771e-01
    z[2,1,1]  R886      4.4595742225646973e-01
    z[2,1,1]  R887      -4.1689127683639526e-01
    z[2,1,1]  R888      1.3225845992565155e-01
    z[2,1,1]  R889      -4.0894353389739990e-01
    z[2,1,1]  R890      2.6005470752716064e-01
    z[2,1,1]  R891      2.8158989548683167e-01
    z[2,1,1]  R892      1.1962978541851044e-01
    z[2,1,1]  R893      6.8216927349567413e-02
    z[2,1,1]  R894      3.1921774148941040e-01
    z[2,1,1]  R895      -3.2574182748794556e-01
    z[2,1,1]  R896      2.5507461279630661e-02
    z[2,1,1]  R897      -8.6136408150196075e-02
    z[2,1,1]  R898      7.0345389842987061e-01
    z[2,1,1]  R899      7.4947863817214966e-01
    z[2,1,1]  R900      3.0610787868499756e-01
    z[2,1,1]  R901      -2.9526799917221069e-01
    z[2,1,1]  R902      -1.3627997040748596e-01
    z[2,1,1]  R903      -4.7529456019401550e-01
    z[2,1,1]  R904      -7.9015719890594482e-01
    z[2,1,1]  R905      4.8739153146743774e-01
    z[2,1,1]  R906      -7.3559558391571045e-01
    z[2,1,1]  R907      -5.5131548643112183e-01
    z[2,1,1]  R908      -4.9255535006523132e-01
    z[2,1,1]  R909      4.8768538236618042e-01
    z[2,1,1]  R910      -2.4818757176399231e-01
    z[2,1,1]  R911      -7.0166671276092529e-01
    z[2,1,1]  R912      -1.6952741146087646e-01
    z[2,1,1]  R913      -1.9266216456890106e-01
    z[2,1,1]  R914      4.8682785034179688e-01
    z[2,1,1]  R915      4.3564680218696594e-01
    z[2,1,1]  R916      5.3933960199356079e-01
    z[2,1,1]  R917      4.3277230858802795e-01
    z[2,1,1]  R918      5.5286341905593872e-01
    z[2,1,1]  R919      -0.690163791179657
    z[2,1,1]  R920      -0.218377947807312
    z[2,1,1]  R921      -6.0111218690872192e-01
    z[2,1,1]  R922      -1.8813097476959229e-01
    z[2,1,1]  R923      -6.2833160161972046e-01
    z[2,1,1]  R924      1.2874330580234528e-01
    z[2,1,1]  R925      1.2565034627914429e-01
    z[2,1,1]  R926      -6.9239699840545654e-01
    z[2,1,1]  R927      -9.4848774373531342e-02
    z[2,1,1]  R928      -3.7407833337783813e-01
    z[2,1,1]  R929      6.4214813709259033e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R800      -1
    z[2,1,2]  R801      1
    z[2,1,2]  R810      3.9351809024810791e-01
    z[2,1,2]  R811      3.7518355250358582e-01
    z[2,1,2]  R812      -0.393670916557312
    z[2,1,2]  R813      7.3147565126419067e-01
    z[2,1,2]  R814      7.9934698343276978e-01
    z[2,1,2]  R815      -4.9697494506835938e-01
    z[2,1,2]  R816      -7.4237972497940063e-01
    z[2,1,2]  R817      -6.0311222076416016e-01
    z[2,1,2]  R818      -1.4511504769325256e-01
    z[2,1,2]  R819      -2.1574316546320915e-02
    z[2,1,2]  R820      1.5001340769231319e-02
    z[2,1,2]  R821      1.1816588789224625e-01
    z[2,1,2]  R822      3.0645513907074928e-02
    z[2,1,2]  R823      4.0301901102066040e-01
    z[2,1,2]  R824      -0.204465851187706
    z[2,1,2]  R825      2.9491984844207764e-01
    z[2,1,2]  R826      -2.9875391721725464e-01
    z[2,1,2]  R827      8.0763585865497589e-02
    z[2,1,2]  R828      4.5759817957878113e-01
    z[2,1,2]  R829      -0.422170490026474
    z[2,1,2]  R830      -0.523331880569458
    z[2,1,2]  R831      0.362429141998291
    z[2,1,2]  R832      2.7793258428573608e-01
    z[2,1,2]  R833      5.4511779546737671e-01
    z[2,1,2]  R834      4.4897815585136414e-01
    z[2,1,2]  R835      5.0363477319478989e-02
    z[2,1,2]  R836      1.6044487059116364e-01
    z[2,1,2]  R837      1.4809851348400116e-01
    z[2,1,2]  R838      7.5230455398559570e-01
    z[2,1,2]  R839      4.0379768610000610e-01
    z[2,1,2]  R840      7.1681782603263855e-02
    z[2,1,2]  R841      5.9995889663696289e-01
    z[2,1,2]  R842      -4.1300213336944580e-01
    z[2,1,2]  R843      -0.5770223736763
    z[2,1,2]  R844      -3.4725788235664368e-01
    z[2,1,2]  R845      -1.4485648274421692e-01
    z[2,1,2]  R846      -0.0309580210596323
    z[2,1,2]  R847      -4.0920473635196686e-02
    z[2,1,2]  R848      -2.1138539910316467e-01
    z[2,1,2]  R849      1.8279202282428741e-02
    z[2,1,2]  R850      5.6813371181488037e-01
    z[2,1,2]  R851      2.4197937548160553e-01
    z[2,1,2]  R852      -2.0100402832031250e-01
    z[2,1,2]  R853      1.4997847378253937e-01
    z[2,1,2]  R854      -4.4935917854309082e-01
    z[2,1,2]  R855      -0.46416175365448
    z[2,1,2]  R856      -5.9348784387111664e-02
    z[2,1,2]  R857      1.3861194252967834e-01
    z[2,1,2]  R858      -0.0834183618426323
    z[2,1,2]  R859      -3.4910953044891357e-01
    z[2,1,2]  R860      5.9702861309051514e-01
    z[2,1,2]  R861      1.6165429353713989e-01
    z[2,1,2]  R862      -1.9677430391311646e-02
    z[2,1,2]  R863      -2.2065903246402740e-01
    z[2,1,2]  R864      1.6770800948143005e-01
    z[2,1,2]  R865      -2.9879701137542725e-01
    z[2,1,2]  R866      -1.4886486530303955e-01
    z[2,1,2]  R867      -1.8530897796154022e-01
    z[2,1,2]  R868      -4.6247458457946777e-01
    z[2,1,2]  R869      -4.2749953269958496e-01
    z[2,1,2]  R870      1.5428924560546875e-01
    z[2,1,2]  R871      4.0962803363800049e-01
    z[2,1,2]  R872      6.6589558124542236e-01
    z[2,1,2]  R873      -5.7522392272949219e-01
    z[2,1,2]  R874      -5.7281100749969482e-01
    z[2,1,2]  R875      -2.7774125337600708e-01
    z[2,1,2]  R876      5.6136876344680786e-01
    z[2,1,2]  R877      3.6103519797325134e-01
    z[2,1,2]  R878      1.8868075311183929e-01
    z[2,1,2]  R879      2.1593287587165833e-01
    z[2,1,2]  R880      7.1879738569259644e-01
    z[2,1,2]  R881      3.8259690999984741e-01
    z[2,1,2]  R882      2.4863047897815704e-01
    z[2,1,2]  R883      4.0550294518470764e-01
    z[2,1,2]  R884      -9.4124749302864075e-02
    z[2,1,2]  R885      -4.7052997350692749e-01
    z[2,1,2]  R886      -0.661577045917511
    z[2,1,2]  R887      -2.0283532142639160e-01
    z[2,1,2]  R888      -3.4149882197380066e-01
    z[2,1,2]  R889      -8.9774593710899353e-02
    z[2,1,2]  R890      -7.1543413400650024e-01
    z[2,1,2]  R891      -5.2829998731613159e-01
    z[2,1,2]  R892      -5.0700902938842773e-01
    z[2,1,2]  R893      -1.2854686379432678e-01
    z[2,1,2]  R894      -5.9702497720718384e-01
    z[2,1,2]  R895      6.1337524652481079e-01
    z[2,1,2]  R896      -2.6337766647338867e-01
    z[2,1,2]  R897      5.3891700506210327e-01
    z[2,1,2]  R898      -4.6299663186073303e-01
    z[2,1,2]  R899      -3.3626869320869446e-01
    z[2,1,2]  R900      -5.5185207165777683e-03
    z[2,1,2]  R901      1.2516488134860992e-01
    z[2,1,2]  R902      -1.8550613522529602e-01
    z[2,1,2]  R903      4.9989435821771622e-02
    z[2,1,2]  R904      3.4611660242080688e-01
    z[2,1,2]  R905      -5.7898926734924316e-01
    z[2,1,2]  R906      -1.8837502598762512e-01
    z[2,1,2]  R907      -1.5222257375717163e-01
    z[2,1,2]  R908      -1.1982090771198273e-01
    z[2,1,2]  R909      -4.3433573842048645e-01
    z[2,1,2]  R910      -3.8566648960113525e-01
    z[2,1,2]  R911      2.9167747497558594e-01
    z[2,1,2]  R912      -5.5262643098831177e-01
    z[2,1,2]  R913      3.9856532216072083e-01
    z[2,1,2]  R914      -4.4477036595344543e-01
    z[2,1,2]  R915      -0.545142650604248
    z[2,1,2]  R916      0.0301351398229599
    z[2,1,2]  R917      -7.3880887031555176e-01
    z[2,1,2]  R918      -6.6751509904861450e-01
    z[2,1,2]  R919      1.7958452925086021e-02
    z[2,1,2]  R920      -3.0071580410003662e-01
    z[2,1,2]  R921      2.2520966827869415e-01
    z[2,1,2]  R922      3.2320278882980347e-01
    z[2,1,2]  R923      4.7071447968482971e-01
    z[2,1,2]  R924      -6.5022307634353638e-01
    z[2,1,2]  R925      -6.3702452182769775e-01
    z[2,1,2]  R926      7.2934284806251526e-02
    z[2,1,2]  R927      2.8145051002502441e-01
    z[2,1,2]  R928      2.4381391704082489e-01
    z[2,1,2]  R929      -8.2089319825172424e-02
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R802      -1
    z[2,1,3]  R803      1
    z[2,1,3]  R810      6.6688269376754761e-01
    z[2,1,3]  R811      5.1572436094284058e-01
    z[2,1,3]  R812      -0.0335572175681591
    z[2,1,3]  R813      2.5846010446548462e-01
    z[2,1,3]  R814      3.7230160832405090e-01
    z[2,1,3]  R815      9.4167873263359070e-02
    z[2,1,3]  R816      1.1200413852930069e-01
    z[2,1,3]  R817      -2.5182047486305237e-01
    z[2,1,3]  R818      -1.4875121414661407e-02
    z[2,1,3]  R819      8.9829826354980469e-01
    z[2,1,3]  R820      -5.8477652072906494e-01
    z[2,1,3]  R821      3.4625104069709778e-01
    z[2,1,3]  R822      2.9363808035850525e-01
    z[2,1,3]  R823      -0.509032666683197
    z[2,1,3]  R824      3.5776901245117188e-01
    z[2,1,3]  R825      -8.1725783646106720e-02
    z[2,1,3]  R826      1.5989720821380615e-01
    z[2,1,3]  R827      4.3401163071393967e-02
    z[2,1,3]  R828      2.2026045620441437e-01
    z[2,1,3]  R829      -6.7249870300292969e-01
    z[2,1,3]  R830      -6.6445702314376831e-01
    z[2,1,3]  R831      2.9607766866683960e-01
    z[2,1,3]  R832      6.4727288484573364e-01
    z[2,1,3]  R833      3.8072162866592407e-01
    z[2,1,3]  R834      3.6636695265769958e-01
    z[2,1,3]  R835      -3.3809766173362732e-01
    z[2,1,3]  R836      2.7824339270591736e-01
    z[2,1,3]  R837      1.0880557447671890e-01
    z[2,1,3]  R838      1.6239469870924950e-02
    z[2,1,3]  R839      -1.1333606392145157e-01
    z[2,1,3]  R840      3.5330617427825928e-01
    z[2,1,3]  R841      2.8760345652699471e-02
    z[2,1,3]  R842      7.1464496850967407e-01
    z[2,1,3]  R843      7.4313563108444214e-01
    z[2,1,3]  R844      6.5993690490722656e-01
    z[2,1,3]  R845      7.3723417520523071e-01
    z[2,1,3]  R846      5.7594460248947144e-01
    z[2,1,3]  R847      3.9901995658874512e-01
    z[2,1,3]  R848      2.5344261527061462e-01
    z[2,1,3]  R849      -7.5182631611824036e-02
    z[2,1,3]  R850      3.6799827218055725e-01
    z[2,1,3]  R851      2.8462353348731995e-01
    z[2,1,3]  R852      4.3726623058319092e-01
    z[2,1,3]  R853      8.8551706075668335e-01
    z[2,1,3]  R854      -3.9345484972000122e-01
    z[2,1,3]  R855      0.773955762386322
    z[2,1,3]  R856      5.0759112834930420e-01
    z[2,1,3]  R857      3.9197233319282532e-01
    z[2,1,3]  R858      0.642471969127655
    z[2,1,3]  R859      1.5008336305618286e-01
    z[2,1,3]  R860      4.8011535406112671e-01
    z[2,1,3]  R861      2.3251669108867645e-01
    z[2,1,3]  R862      -1.5396174788475037e-01
    z[2,1,3]  R863      -1.6268764436244965e-01
    z[2,1,3]  R864      3.4525668621063232e-01
    z[2,1,3]  R865      0.374606728553772
    z[2,1,3]  R866      -1.6411715745925903e-01
    z[2,1,3]  R867      9.1871835291385651e-02
    z[2,1,3]  R868      6.4905665814876556e-02
    z[2,1,3]  R869      1.3168838620185852e-01
    z[2,1,3]  R870      -1.9785149395465851e-01
    z[2,1,3]  R871      -1.5579080581665039e-01
    z[2,1,3]  R872      -1.2824720144271851e-01
    z[2,1,3]  R873      -1.8338501453399658e-01
    z[2,1,3]  R874      -1.1830183863639832e-01
    z[2,1,3]  R875      -2.9639992117881775e-01
    z[2,1,3]  R876      -1.6545537114143372e-01
    z[2,1,3]  R877      -8.5804708302021027e-02
    z[2,1,3]  R878      -2.9832187294960022e-01
    z[2,1,3]  R879      -1.2625852227210999e-01
    z[2,1,3]  R880      3.0539923906326294e-01
    z[2,1,3]  R881      7.6536345481872559e-01
    z[2,1,3]  R882      4.9695274233818054e-01
    z[2,1,3]  R883      5.2950328588485718e-01
    z[2,1,3]  R884      4.5159395784139633e-02
    z[2,1,3]  R885      8.6288101971149445e-02
    z[2,1,3]  R886      -2.1833214163780212e-01
    z[2,1,3]  R887      6.7773485183715820e-01
    z[2,1,3]  R888      5.8339411020278931e-01
    z[2,1,3]  R889      8.2833594083786011e-01
    z[2,1,3]  R890      -4.2537021636962891e-01
    z[2,1,3]  R891      -0.408914178609848
    z[2,1,3]  R892      -6.0810461640357971e-02
    z[2,1,3]  R893      -9.0807807445526123e-01
    z[2,1,3]  R894      1.6254587471485138e-01
    z[2,1,3]  R895      -1.5159854292869568e-01
    z[2,1,3]  R896      -6.9932979345321655e-01
    z[2,1,3]  R897      1.6053098440170288e-01
    z[2,1,3]  R898      3.4772035479545593e-01
    z[2,1,3]  R899      -4.2696991562843323e-01
    z[2,1,3]  R900      -8.7268584966659546e-01
    z[2,1,3]  R901      -5.4635971784591675e-01
    z[2,1,3]  R902      -6.4791935682296753e-01
    z[2,1,3]  R903      -7.7812254428863525e-01
    z[2,1,3]  R904      2.4809615314006805e-01
    z[2,1,3]  R905      5.4636709392070770e-02
    z[2,1,3]  R906      -4.3005886673927307e-01
    z[2,1,3]  R907      -4.3866130709648132e-01
    z[2,1,3]  R908      -3.9875060319900513e-01
    z[2,1,3]  R909      -3.0273789167404175e-01
    z[2,1,3]  R910      -4.1669008135795593e-01
    z[2,1,3]  R911      -8.8196210563182831e-02
    z[2,1,3]  R912      -6.0438591241836548e-01
    z[2,1,3]  R913      -5.9017026424407959e-01
    z[2,1,3]  R914      -1.5177384018898010e-01
    z[2,1,3]  R915      3.3042982220649719e-01
    z[2,1,3]  R916      8.0193474888801575e-02
    z[2,1,3]  R917      0.0891735851764679
    z[2,1,3]  R918      2.8843116760253906e-01
    z[2,1,3]  R919      6.1815810203552246e-01
    z[2,1,3]  R920      -9.0811568498611450e-01
    z[2,1,3]  R921      -4.9738240242004395e-01
    z[2,1,3]  R922      -8.3319848775863647e-01
    z[2,1,3]  R923      4.9404117465019226e-01
    z[2,1,3]  R924      -3.2991480082273483e-02
    z[2,1,3]  R925      3.7585198879241943e-01
    z[2,1,3]  R926      -4.0448507666587830e-01
    z[2,1,3]  R927      -7.5693726539611816e-02
    z[2,1,3]  R928      2.9689380526542664e-01
    z[2,1,3]  R929      5.2299493551254272e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R804      -1
    z[2,1,4]  R805      1
    z[2,1,4]  R810      -2.3895879089832306e-01
    z[2,1,4]  R811      -4.7157695889472961e-01
    z[2,1,4]  R812      -3.7143155932426453e-01
    z[2,1,4]  R813      -5.8237057924270630e-01
    z[2,1,4]  R814      4.2662656307220459e-01
    z[2,1,4]  R815      -3.4332302212715149e-01
    z[2,1,4]  R816      -1.3079759478569031e-01
    z[2,1,4]  R817      -6.1369098722934723e-02
    z[2,1,4]  R818      -1.6491885483264923e-01
    z[2,1,4]  R819      3.5114273428916931e-01
    z[2,1,4]  R820      -1.4118352532386780e-01
    z[2,1,4]  R821      3.3173173666000366e-01
    z[2,1,4]  R822      -1.0776351392269135e-01
    z[2,1,4]  R823      -1.4837658405303955e-01
    z[2,1,4]  R824      -3.0603675171732903e-02
    z[2,1,4]  R825      -4.1560694575309753e-01
    z[2,1,4]  R826      -0.0971241444349289
    z[2,1,4]  R827      2.3729506134986877e-01
    z[2,1,4]  R828      3.9734295010566711e-01
    z[2,1,4]  R829      -1.9221581518650055e-01
    z[2,1,4]  R830      -3.3902657032012939e-01
    z[2,1,4]  R831      2.2356674075126648e-01
    z[2,1,4]  R832      -1.6046515107154846e-01
    z[2,1,4]  R833      2.5032532215118408e-01
    z[2,1,4]  R834      -5.6066513061523438e-01
    z[2,1,4]  R835      -2.8734448552131653e-01
    z[2,1,4]  R836      -4.5655864477157593e-01
    z[2,1,4]  R837      -5.9938418865203857e-01
    z[2,1,4]  R838      -5.5443480610847473e-02
    z[2,1,4]  R839      -3.0573008116334677e-03
    z[2,1,4]  R840      2.4033010005950928e-01
    z[2,1,4]  R841      -2.1824173629283905e-01
    z[2,1,4]  R842      -2.3332582414150238e-01
    z[2,1,4]  R843      -2.1850545704364777e-01
    z[2,1,4]  R844      -3.8703937083482742e-02
    z[2,1,4]  R845      4.0596637874841690e-02
    z[2,1,4]  R846      1.8956919014453888e-01
    z[2,1,4]  R847      -2.4005274474620819e-01
    z[2,1,4]  R848      -8.1402897834777832e-02
    z[2,1,4]  R849      1.0504613071680069e-01
    z[2,1,4]  R850      -7.7836655080318451e-02
    z[2,1,4]  R851      -0.404949426651001
    z[2,1,4]  R852      -2.4935327470302582e-01
    z[2,1,4]  R853      5.4351929575204849e-02
    z[2,1,4]  R854      3.2880973815917969e-01
    z[2,1,4]  R855      -2.1899476647377014e-01
    z[2,1,4]  R856      -2.7377369999885559e-01
    z[2,1,4]  R857      -1.4054611325263977e-01
    z[2,1,4]  R858      7.4891060590744019e-02
    z[2,1,4]  R859      -2.6861688494682312e-01
    z[2,1,4]  R860      1.3103212416172028e-01
    z[2,1,4]  R861      -6.5347111225128174e-01
    z[2,1,4]  R862      3.8102969527244568e-01
    z[2,1,4]  R863      3.8656479120254517e-01
    z[2,1,4]  R864      -9.0547271072864532e-02
    z[2,1,4]  R865      -1.6460482776165009e-01
    z[2,1,4]  R866      -4.8961769789457321e-04
    z[2,1,4]  R867      -1.9483752548694611e-01
    z[2,1,4]  R868      -0.689633846282959
    z[2,1,4]  R869      -5.9421205520629883e-01
    z[2,1,4]  R870      2.8005328774452209e-01
    z[2,1,4]  R871      3.1539127230644226e-01
    z[2,1,4]  R872      1.8078483641147614e-01
    z[2,1,4]  R873      3.1668260693550110e-01
    z[2,1,4]  R874      5.9276384115219116e-01
    z[2,1,4]  R875      1.5372152626514435e-01
    z[2,1,4]  R876      -3.5441529750823975e-01
    z[2,1,4]  R877      0.682155430316925
    z[2,1,4]  R878      8.0553829669952393e-01
    z[2,1,4]  R879      7.1015870571136475e-01
    z[2,1,4]  R880      -2.3386125266551971e-01
    z[2,1,4]  R881      -4.2920134961605072e-02
    z[2,1,4]  R882      6.7264698445796967e-03
    z[2,1,4]  R883      -1.3860683143138885e-01
    z[2,1,4]  R884      -1.0556232929229736e-01
    z[2,1,4]  R885      -0.180857852101326
    z[2,1,4]  R886      -0.347945898771286
    z[2,1,4]  R887      1.9008468091487885e-01
    z[2,1,4]  R888      -5.6145143508911133e-01
    z[2,1,4]  R889      -1.2967351078987122e-01
    z[2,1,4]  R890      1.1638043820858002e-01
    z[2,1,4]  R891      3.6474909633398056e-02
    z[2,1,4]  R892      -2.7737969160079956e-01
    z[2,1,4]  R893      1.9040282070636749e-01
    z[2,1,4]  R894      -2.9372459650039673e-01
    z[2,1,4]  R895      -6.5552002191543579e-01
    z[2,1,4]  R896      6.1285290867090225e-02
    z[2,1,4]  R897      -3.7403675913810730e-01
    z[2,1,4]  R898      1.5211680531501770e-01
    z[2,1,4]  R899      2.6128438115119934e-01
    z[2,1,4]  R900      -0.0209683645516634
    z[2,1,4]  R901      2.5459289550781250e-01
    z[2,1,4]  R902      6.8388420343399048e-01
    z[2,1,4]  R903      -2.5255185365676880e-01
    z[2,1,4]  R904      -3.7624785304069519e-01
    z[2,1,4]  R905      2.7798625826835632e-01
    z[2,1,4]  R906      -1.2289223819971085e-01
    z[2,1,4]  R907      -5.3070688247680664e-01
    z[2,1,4]  R908      -4.8383176326751709e-01
    z[2,1,4]  R909      4.1114774346351624e-01
    z[2,1,4]  R910      1.1680650711059570e-01
    z[2,1,4]  R911      7.0235341787338257e-02
    z[2,1,4]  R912      -4.6366035938262939e-01
    z[2,1,4]  R913      2.2281800210475922e-01
    z[2,1,4]  R914      -2.2254188358783722e-01
    z[2,1,4]  R915      -4.0633025765419006e-01
    z[2,1,4]  R916      -8.1712412834167480e-01
    z[2,1,4]  R917      -2.9364114999771118e-01
    z[2,1,4]  R918      1.6318482160568237e-01
    z[2,1,4]  R919      2.2752128541469574e-01
    z[2,1,4]  R920      1.4992308802902699e-02
    z[2,1,4]  R921      0.574512779712677
    z[2,1,4]  R922      -1.1573029309511185e-01
    z[2,1,4]  R923      6.6686391830444336e-02
    z[2,1,4]  R924      -0.254208505153656
    z[2,1,4]  R925      1.9960589706897736e-01
    z[2,1,4]  R926      -0.208910271525383
    z[2,1,4]  R927      -4.3405908346176147e-01
    z[2,1,4]  R928      4.1917651891708374e-01
    z[2,1,4]  R929      -7.3116861283779144e-02
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R806      -1
    z[2,1,5]  R807      1
    z[2,1,5]  R810      -2.4737168103456497e-02
    z[2,1,5]  R811      5.7684624195098877e-01
    z[2,1,5]  R812      0.331180602312088
    z[2,1,5]  R813      2.2983746230602264e-01
    z[2,1,5]  R814      -1.2704163789749146e-01
    z[2,1,5]  R815      -1.1993834376335144e-01
    z[2,1,5]  R816      -3.6350786685943604e-02
    z[2,1,5]  R817      7.7492587268352509e-02
    z[2,1,5]  R818      -1.1959101259708405e-01
    z[2,1,5]  R819      -6.9265522062778473e-02
    z[2,1,5]  R820      -1.3553163409233093e-01
    z[2,1,5]  R821      -3.1456491351127625e-01
    z[2,1,5]  R822      2.5362795591354370e-01
    z[2,1,5]  R823      -0.0747024267911911
    z[2,1,5]  R824      1.3659586012363434e-01
    z[2,1,5]  R825      9.5757313072681427e-02
    z[2,1,5]  R826      -1.7079490423202515e-01
    z[2,1,5]  R827      -7.5730629265308380e-02
    z[2,1,5]  R828      -4.2192158102989197e-01
    z[2,1,5]  R829      3.4134829044342041e-01
    z[2,1,5]  R830      2.6010846719145775e-02
    z[2,1,5]  R831      1.0972206294536591e-01
    z[2,1,5]  R832      2.2955326735973358e-01
    z[2,1,5]  R833      -1.1781092733144760e-01
    z[2,1,5]  R834      -2.6004803180694580e-01
    z[2,1,5]  R835      -2.0570079982280731e-01
    z[2,1,5]  R836      -4.2971235513687134e-01
    z[2,1,5]  R837      4.7969031333923340e-01
    z[2,1,5]  R838      8.0762747675180435e-03
    z[2,1,5]  R839      -2.8292128443717957e-01
    z[2,1,5]  R840      -4.2411741614341736e-01
    z[2,1,5]  R841      3.6013630032539368e-01
    z[2,1,5]  R842      3.7317776679992676e-01
    z[2,1,5]  R843      2.3234508931636810e-01
    z[2,1,5]  R844      3.9454281330108643e-01
    z[2,1,5]  R845      3.0197301506996155e-01
    z[2,1,5]  R846      4.3862808495759964e-02
    z[2,1,5]  R847      5.0850385427474976e-01
    z[2,1,5]  R848      6.0775619745254517e-01
    z[2,1,5]  R849      8.8746301829814911e-02
    z[2,1,5]  R850      1.2499637901782990e-01
    z[2,1,5]  R851      -4.8106333613395691e-01
    z[2,1,5]  R852      -7.4209660291671753e-02
    z[2,1,5]  R853      1.3393706083297729e-01
    z[2,1,5]  R854      -9.5786139369010925e-02
    z[2,1,5]  R855      3.3809685707092285e-01
    z[2,1,5]  R856      5.0066936016082764e-01
    z[2,1,5]  R857      6.2086051702499390e-01
    z[2,1,5]  R858      9.3482971191406250e-02
    z[2,1,5]  R859      6.6434174776077271e-01
    z[2,1,5]  R860      -3.0788388848304749e-01
    z[2,1,5]  R861      2.0122538506984711e-01
    z[2,1,5]  R862      -1.6681909561157227e-02
    z[2,1,5]  R863      -3.8226428627967834e-01
    z[2,1,5]  R864      6.9038450717926025e-01
    z[2,1,5]  R865      6.1444973945617676e-01
    z[2,1,5]  R866      6.2699727714061737e-02
    z[2,1,5]  R867      -1.7816412448883057e-01
    z[2,1,5]  R868      1.0726174712181091e-01
    z[2,1,5]  R869      -2.1086144447326660e-01
    z[2,1,5]  R870      1.2996168434619904e-01
    z[2,1,5]  R871      4.9831250309944153e-01
    z[2,1,5]  R872      -5.2954863756895065e-02
    z[2,1,5]  R873      -1.0397800803184509e-01
    z[2,1,5]  R874      -4.3760299682617188e-02
    z[2,1,5]  R875      -4.7443735599517822e-01
    z[2,1,5]  R876      4.0084591507911682e-01
    z[2,1,5]  R877      2.3899297416210175e-01
    z[2,1,5]  R878      -1.7053984105587006e-01
    z[2,1,5]  R879      -9.2424347996711731e-02
    z[2,1,5]  R880      6.7016161978244781e-02
    z[2,1,5]  R881      1.2693777680397034e-01
    z[2,1,5]  R882      -8.8410764932632446e-02
    z[2,1,5]  R883      4.9413305521011353e-01
    z[2,1,5]  R884      -5.4077520966529846e-02
    z[2,1,5]  R885      -3.5688707232475281e-01
    z[2,1,5]  R886      7.8935608267784119e-02
    z[2,1,5]  R887      -0.186315655708313
    z[2,1,5]  R888      -6.7505680024623871e-02
    z[2,1,5]  R889      6.6189900040626526e-02
    z[2,1,5]  R890      -3.7717631459236145e-01
    z[2,1,5]  R891      -5.9734326601028442e-01
    z[2,1,5]  R892      -4.7837734222412109e-01
    z[2,1,5]  R893      2.5130003690719604e-01
    z[2,1,5]  R894      -6.3161790370941162e-01
    z[2,1,5]  R895      1.6878260672092438e-01
    z[2,1,5]  R896      5.8353751897811890e-01
    z[2,1,5]  R897      3.8660675287246704e-01
    z[2,1,5]  R898      -0.318907767534256
    z[2,1,5]  R899      -1.6402861475944519e-01
    z[2,1,5]  R900      -1.2997676432132721e-01
    z[2,1,5]  R901      -3.9555296301841736e-01
    z[2,1,5]  R902      1.1939511448144913e-01
    z[2,1,5]  R903      -1.0598129779100418e-01
    z[2,1,5]  R904      0.0935024619102478
    z[2,1,5]  R905      -5.0922483205795288e-01
    z[2,1,5]  R906      -2.5957217812538147e-01
    z[2,1,5]  R907      -3.4279155731201172e-01
    z[2,1,5]  R908      -2.1769352257251740e-01
    z[2,1,5]  R909      2.4725930392742157e-01
    z[2,1,5]  R910      -5.9044855833053589e-01
    z[2,1,5]  R911      3.7515202164649963e-01
    z[2,1,5]  R912      -0.0705728530883789
    z[2,1,5]  R913      6.1502200365066528e-01
    z[2,1,5]  R914      -3.3472391963005066e-01
    z[2,1,5]  R915      -3.5757660865783691e-01
    z[2,1,5]  R916      -7.8355483710765839e-02
    z[2,1,5]  R917      -1.3906839489936829e-01
    z[2,1,5]  R918      -1.8571268767118454e-02
    z[2,1,5]  R919      -2.0394992828369141e-01
    z[2,1,5]  R920      0.0060595260001719
    z[2,1,5]  R921      7.9848654568195343e-02
    z[2,1,5]  R922      3.7020778656005859e-01
    z[2,1,5]  R923      3.0023878812789917e-01
    z[2,1,5]  R924      -3.0967068672180176e-01
    z[2,1,5]  R925      -3.7857425212860107e-01
    z[2,1,5]  R926      -5.5424129962921143e-01
    z[2,1,5]  R927      5.4742813110351562e-01
    z[2,1,5]  R928      -2.9570639133453369e-01
    z[2,1,5]  R929      3.1599190831184387e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R808      -1
    z[2,1,6]  R809      1
    z[2,1,6]  R810      -4.6538898348808289e-01
    z[2,1,6]  R811      2.3281384259462357e-02
    z[2,1,6]  R812      1.2262260913848877e-01
    z[2,1,6]  R813      -5.3310345858335495e-02
    z[2,1,6]  R814      1.0644710063934326e-01
    z[2,1,6]  R815      -4.4793951511383057e-01
    z[2,1,6]  R816      -3.8373082876205444e-02
    z[2,1,6]  R817      4.5984596014022827e-01
    z[2,1,6]  R818      -4.6277174353599548e-01
    z[2,1,6]  R819      1.7444470524787903e-01
    z[2,1,6]  R820      -3.2454732060432434e-01
    z[2,1,6]  R821      3.7547999620437622e-01
    z[2,1,6]  R822      4.2403522133827209e-01
    z[2,1,6]  R823      -1.6031830012798309e-01
    z[2,1,6]  R824      2.3387399315834045e-01
    z[2,1,6]  R825      2.5553089380264282e-01
    z[2,1,6]  R826      0.0127909230068326
    z[2,1,6]  R827      2.9407903552055359e-01
    z[2,1,6]  R828      -1.4919905364513397e-01
    z[2,1,6]  R829      3.4494093060493469e-01
    z[2,1,6]  R830      4.6677622012794018e-03
    z[2,1,6]  R831      3.8868820667266846e-01
    z[2,1,6]  R832      1.2070067971944809e-01
    z[2,1,6]  R833      1.8211397528648376e-01
    z[2,1,6]  R834      3.2585906982421875e-01
    z[2,1,6]  R835      -4.0204131603240967e-01
    z[2,1,6]  R836      -9.8212985321879387e-03
    z[2,1,6]  R837      -6.7253420129418373e-03
    z[2,1,6]  R838      -2.3075561225414276e-01
    z[2,1,6]  R839      -1.4049398899078369e-01
    z[2,1,6]  R840      -1.4339953660964966e-01
    z[2,1,6]  R841      1.4559175074100494e-01
    z[2,1,6]  R842      4.5146606862545013e-03
    z[2,1,6]  R843      1.2308930046856403e-02
    z[2,1,6]  R844      2.7681791782379150e-01
    z[2,1,6]  R845      1.1601343005895615e-01
    z[2,1,6]  R846      6.5551467239856720e-02
    z[2,1,6]  R847      -5.1159677095711231e-03
    z[2,1,6]  R848      4.6589076519012451e-01
    z[2,1,6]  R849      7.5365439988672733e-03
    z[2,1,6]  R850      0.06618682295084
    z[2,1,6]  R851      6.6418468952178955e-02
    z[2,1,6]  R852      -2.6544502377510071e-01
    z[2,1,6]  R853      -9.4690709374845028e-04
    z[2,1,6]  R854      2.8251171112060547e-01
    z[2,1,6]  R855      5.6245069950819016e-02
    z[2,1,6]  R856      -1.4166802167892456e-02
    z[2,1,6]  R857      2.6571869850158691e-01
    z[2,1,6]  R858      -4.4701248407363892e-03
    z[2,1,6]  R859      5.2134519815444946e-01
    z[2,1,6]  R860      -3.9237537980079651e-01
    z[2,1,6]  R861      -3.2772576808929443e-01
    z[2,1,6]  R862      5.5867195129394531e-01
    z[2,1,6]  R863      0.148732990026474
    z[2,1,6]  R864      5.8001667261123657e-01
    z[2,1,6]  R865      5.0697189569473267e-01
    z[2,1,6]  R866      -0.0642150416970253
    z[2,1,6]  R867      -1.2757311761379242e-01
    z[2,1,6]  R868      4.7128215432167053e-02
    z[2,1,6]  R869      4.3735164403915405e-01
    z[2,1,6]  R870      -4.1296545416116714e-02
    z[2,1,6]  R871      4.7544579952955246e-02
    z[2,1,6]  R872      -2.8484994173049927e-01
    z[2,1,6]  R873      -3.4448447823524475e-01
    z[2,1,6]  R874      1.0768654197454453e-01
    z[2,1,6]  R875      -5.8732575178146362e-01
    z[2,1,6]  R876      1.0995424352586269e-02
    z[2,1,6]  R877      1.1395853757858276e-01
    z[2,1,6]  R878      -3.8139519095420837e-01
    z[2,1,6]  R879      7.5161732733249664e-02
    z[2,1,6]  R880      9.8768718540668488e-02
    z[2,1,6]  R881      -1.5962858498096466e-01
    z[2,1,6]  R882      -3.5750970244407654e-01
    z[2,1,6]  R883      -1.5360661782324314e-02
    z[2,1,6]  R884      -1.5741893649101257e-01
    z[2,1,6]  R885      3.2253009080886841e-01
    z[2,1,6]  R886      3.8437563180923462e-01
    z[2,1,6]  R887      -1.6234208643436432e-01
    z[2,1,6]  R888      -1.6507243737578392e-02
    z[2,1,6]  R889      8.9567065238952637e-02
    z[2,1,6]  R890      3.1049272045493126e-02
    z[2,1,6]  R891      1.2024573236703873e-01
    z[2,1,6]  R892      -0.277940034866333
    z[2,1,6]  R893      2.0571085810661316e-01
    z[2,1,6]  R894      7.1777604520320892e-02
    z[2,1,6]  R895      -1.4794050157070160e-01
    z[2,1,6]  R896      -7.2795733809471130e-02
    z[2,1,6]  R897      -3.8922619819641113e-01
    z[2,1,6]  R898      -1.8607042729854584e-01
    z[2,1,6]  R899      -1.2934499979019165e-01
    z[2,1,6]  R900      8.4637450054287910e-03
    z[2,1,6]  R901      1.3048601150512695e-01
    z[2,1,6]  R902      5.3298264741897583e-02
    z[2,1,6]  R903      -2.7908441424369812e-01
    z[2,1,6]  R904      1.6596347093582153e-01
    z[2,1,6]  R905      0.00876099057495594
    z[2,1,6]  R906      3.9219805598258972e-01
    z[2,1,6]  R907      2.2666966915130615e-01
    z[2,1,6]  R908      5.0538641214370728e-01
    z[2,1,6]  R909      4.1560640931129456e-01
    z[2,1,6]  R910      2.2250089049339294e-01
    z[2,1,6]  R911      4.8746901750564575e-01
    z[2,1,6]  R912      3.5872368607670069e-03
    z[2,1,6]  R913      0.087613046169281
    z[2,1,6]  R914      -5.4974645376205444e-01
    z[2,1,6]  R915      -2.0097108185291290e-01
    z[2,1,6]  R916      -1.6633279621601105e-01
    z[2,1,6]  R917      3.9147740602493286e-01
    z[2,1,6]  R918      -2.4853512644767761e-01
    z[2,1,6]  R919      -5.5437427014112473e-02
    z[2,1,6]  R920      7.4375040829181671e-02
    z[2,1,6]  R921      6.3531458377838135e-02
    z[2,1,6]  R922      -6.5903551876544952e-02
    z[2,1,6]  R923      -6.2070630490779877e-02
    z[2,1,6]  R924      -9.2620790004730225e-02
    z[2,1,6]  R925      -2.5661420822143555e-01
    z[2,1,6]  R926      -2.8402399271726608e-02
    z[2,1,6]  R927      -1.0774499922990799e-01
    z[2,1,6]  R928      -0.587288498878479
    z[2,1,6]  R929      2.1513158082962036e-01
    z[1,7,0]  R11       -1
    z[1,7,0]  R65       1
    z[1,7,0]  R930      -1
    z[1,7,0]  R931      1
    z[1,7,0]  R944      5.6712478399276733e-01
    z[1,7,0]  R945      5.7326781749725342e-01
    z[1,7,0]  R946      3.5377502441406250e-01
    z[1,7,0]  R947      6.1590307950973511e-01
    z[1,7,0]  R948      3.1329560279846191e-01
    z[1,7,0]  R949      4.0936514735221863e-01
    z[1,7,0]  R950      1.7265732586383820e-01
    z[1,7,0]  R951      2.4288158118724823e-01
    z[1,7,0]  R952      2.0638771355152130e-01
    z[1,7,0]  R953      0.621462345123291
    z[1,7,0]  R954      -5.0725597143173218e-01
    z[1,7,0]  R955      -4.5115393400192261e-01
    z[1,7,0]  R956      -7.2730302810668945e-01
    z[1,7,0]  R957      -4.6807822585105896e-01
    z[1,7,0]  R958      -7.8397506475448608e-01
    z[1,7,0]  R959      -3.0847826600074768e-01
    z[1,7,0]  R960      -2.0180958509445190e-01
    z[1,7,0]  R961      -4.7805258631706238e-01
    z[1,7,0]  R962      -4.5329952239990234e-01
    z[1,7,0]  R963      -3.3067616820335388e-01
    z[1,7,0]  R964      -2.8777632117271423e-01
    z[1,7,0]  R965      3.1904092431068420e-01
    z[1,7,0]  R966      -5.8472013473510742e-01
    z[1,7,0]  R967      -1.1177876591682434e-01
    z[1,7,0]  R968      1.5771120786666870e-01
    z[1,7,0]  R969      -1.2083274126052856e-01
    z[1,7,0]  R970      -3.0223888158798218e-01
    z[1,7,0]  R971      -4.8529732227325439e-01
    z[1,7,0]  R972      1.0204591602087021e-01
    z[1,7,0]  R973      1.7605938017368317e-01
    z[1,7,0]  R974      3.5676565766334534e-01
    z[1,7,0]  R975      6.0027921199798584e-01
    z[1,7,0]  R976      -2.0596690475940704e-01
    z[1,7,0]  R977      -1.1497341096401215e-01
    z[1,7,0]  R978      -1.2827318906784058e-01
    z[1,7,0]  R979      2.9592707753181458e-01
    z[1,7,0]  R980      -4.6516966074705124e-02
    z[1,7,0]  R981      -1.7297618091106415e-01
    z[1,7,0]  R982      2.1709685027599335e-01
    z[1,7,0]  R983      2.8099268674850464e-01
    z[1,7,0]  R984      4.5194447040557861e-01
    z[1,7,0]  R985      1.7751461267471313e-01
    z[1,7,0]  R986      2.8391501307487488e-01
    z[1,7,0]  R987      -0.141950786113739
    z[1,7,0]  R988      -2.7992233633995056e-01
    z[1,7,0]  R989      -2.6550477743148804e-01
    z[1,7,0]  R990      -1.6600802540779114e-02
    z[1,7,0]  R991      -9.8987082019448280e-03
    z[1,7,0]  R992      -2.7718076109886169e-01
    z[1,7,0]  R993      -2.1165333688259125e-01
    z[1,7,0]  R994      -1.7723931372165680e-01
    z[1,7,0]  R995      8.8512469083070755e-03
    z[1,7,0]  R996      1.0552880913019180e-01
    z[1,7,0]  R997      -2.0274975895881653e-01
    z[1,7,0]  R998      -6.2486010789871216e-01
    z[1,7,0]  R999      -4.3374547362327576e-01
    z[1,7,0]  R1000     -5.0168428570032120e-03
    z[1,7,0]  R1001     -6.3746839761734009e-01
    z[1,7,0]  R1002     -3.2313367724418640e-01
    z[1,7,0]  R1003     3.9484769105911255e-01
    z[1,7,0]  R1004     0.56584632396698
    z[1,7,0]  R1005     3.8680833578109741e-01
    z[1,7,0]  R1006     3.1114852428436279e-01
    z[1,7,0]  R1007     2.8785562515258789e-01
    z[1,7,0]  R1008     6.3915866613388062e-01
    z[1,7,0]  R1009     6.1947333812713623e-01
    z[1,7,0]  R1010     -3.6312767863273621e-01
    z[1,7,0]  R1011     -1.4555731415748596e-01
    z[1,7,0]  R1012     1.5721313655376434e-01
    z[1,7,0]  R1013     -0.337566077709198
    z[1,7,0]  R1014     -4.3169227242469788e-01
    z[1,7,0]  R1015     -6.1430495977401733e-01
    z[1,7,0]  R1016     -4.2309236526489258e-01
    z[1,7,0]  R1017     -6.2170523405075073e-01
    z[1,7,0]  R1018     -6.3902544975280762e-01
    z[1,7,0]  R1019     -1.3756404817104340e-01
    z[1,7,0]  R1020     -5.1230460405349731e-01
    z[1,7,0]  R1021     -7.5247043371200562e-01
    z[1,7,0]  R1022     -4.0488809347152710e-01
    z[1,7,0]  R1023     2.0064330101013184e-01
    z[1,7,0]  R1024     -2.8924819827079773e-01
    z[1,7,0]  R1025     2.7174675464630127e-01
    z[1,7,0]  R1026     -8.5789456963539124e-02
    z[1,7,0]  R1027     -6.6463607549667358e-01
    z[1,7,0]  R1028     4.3180355429649353e-01
    z[1,7,0]  R1029     -3.8987055420875549e-01
    z[1,7,0]  R1030     0.343079149723053
    z[1,7,0]  R1031     -2.0219059288501740e-01
    z[1,7,0]  R1032     2.2271190583705902e-01
    z[1,7,0]  R1033     3.1970273703336716e-02
    z[1,7,0]  R1034     8.0609925091266632e-02
    z[1,7,0]  R1035     5.9101927280426025e-01
    z[1,7,0]  R1036     -2.2363428771495819e-01
    z[1,7,0]  R1037     -2.9740871861577034e-02
    z[1,7,0]  R1038     2.7416062355041504e-01
    z[1,7,0]  R1039     -1.0326413810253143e-01
    z[1,7,0]  R1040     -1.7664854228496552e-01
    z[1,7,0]  R1041     -5.9103786945343018e-01
    z[1,7,0]  R1042     -2.7790278196334839e-01
    z[1,7,1]  R12       -1
    z[1,7,1]  R66       1
    z[1,7,1]  R932      -1
    z[1,7,1]  R933      1
    z[1,7,1]  R944      -7.1999573707580566e-01
    z[1,7,1]  R945      -3.5951447486877441e-01
    z[1,7,1]  R946      -5.4621613025665283e-01
    z[1,7,1]  R947      -1.6242490708827972e-01
    z[1,7,1]  R948      -4.4142702221870422e-01
    z[1,7,1]  R949      -2.7157762646675110e-01
    z[1,7,1]  R950      -5.8418369293212891e-01
    z[1,7,1]  R951      -5.1755124330520630e-01
    z[1,7,1]  R952      -0.0967964380979538
    z[1,7,1]  R953      -1.8083013594150543e-01
    z[1,7,1]  R954      0.252617210149765
    z[1,7,1]  R955      1.4443641901016235e-01
    z[1,7,1]  R956      1.6302208602428436e-01
    z[1,7,1]  R957      2.6922336220741272e-01
    z[1,7,1]  R958      -5.7934081554412842e-01
    z[1,7,1]  R959      -6.4178925752639771e-01
    z[1,7,1]  R960      4.4595742225646973e-01
    z[1,7,1]  R961      -4.1689127683639526e-01
    z[1,7,1]  R962      1.3225845992565155e-01
    z[1,7,1]  R963      -4.0894353389739990e-01
    z[1,7,1]  R964      2.6005470752716064e-01
    z[1,7,1]  R965      2.8158989548683167e-01
    z[1,7,1]  R966      1.1962978541851044e-01
    z[1,7,1]  R967      6.8216927349567413e-02
    z[1,7,1]  R968      3.1921774148941040e-01
    z[1,7,1]  R969      -3.2574182748794556e-01
    z[1,7,1]  R970      2.5507461279630661e-02
    z[1,7,1]  R971      -8.6136408150196075e-02
    z[1,7,1]  R972      7.0345389842987061e-01
    z[1,7,1]  R973      7.4947863817214966e-01
    z[1,7,1]  R974      3.0610787868499756e-01
    z[1,7,1]  R975      -2.9526799917221069e-01
    z[1,7,1]  R976      -1.3627997040748596e-01
    z[1,7,1]  R977      -4.7529456019401550e-01
    z[1,7,1]  R978      -7.9015719890594482e-01
    z[1,7,1]  R979      4.8739153146743774e-01
    z[1,7,1]  R980      -7.3559558391571045e-01
    z[1,7,1]  R981      -5.5131548643112183e-01
    z[1,7,1]  R982      -4.9255535006523132e-01
    z[1,7,1]  R983      4.8768538236618042e-01
    z[1,7,1]  R984      -2.4818757176399231e-01
    z[1,7,1]  R985      -7.0166671276092529e-01
    z[1,7,1]  R986      -1.6952741146087646e-01
    z[1,7,1]  R987      -1.9266216456890106e-01
    z[1,7,1]  R988      4.8682785034179688e-01
    z[1,7,1]  R989      4.3564680218696594e-01
    z[1,7,1]  R990      5.3933960199356079e-01
    z[1,7,1]  R991      4.3277230858802795e-01
    z[1,7,1]  R992      5.5286341905593872e-01
    z[1,7,1]  R993      -0.690163791179657
    z[1,7,1]  R994      -0.218377947807312
    z[1,7,1]  R995      -6.0111218690872192e-01
    z[1,7,1]  R996      -1.8813097476959229e-01
    z[1,7,1]  R997      -6.2833160161972046e-01
    z[1,7,1]  R998      1.2874330580234528e-01
    z[1,7,1]  R999      1.2565034627914429e-01
    z[1,7,1]  R1000     -6.9239699840545654e-01
    z[1,7,1]  R1001     -9.4848774373531342e-02
    z[1,7,1]  R1002     -3.7407833337783813e-01
    z[1,7,1]  R1003     6.4214813709259033e-01
    z[1,7,1]  R1004     -7.2112256288528442e-01
    z[1,7,1]  R1005     -6.0716563463211060e-01
    z[1,7,1]  R1006     -4.7086629271507263e-01
    z[1,7,1]  R1007     -4.8536252975463867e-01
    z[1,7,1]  R1008     -3.5772338509559631e-02
    z[1,7,1]  R1009     -1.1704052239656448e-01
    z[1,7,1]  R1010     -8.4566110372543335e-01
    z[1,7,1]  R1011     -7.9250574111938477e-01
    z[1,7,1]  R1012     5.1438021659851074e-01
    z[1,7,1]  R1013     4.7565326094627380e-01
    z[1,7,1]  R1014     5.1896393299102783e-01
    z[1,7,1]  R1015     5.3056395053863525e-01
    z[1,7,1]  R1016     4.3915295600891113e-01
    z[1,7,1]  R1017     4.2227533459663391e-01
    z[1,7,1]  R1018     4.2494386434555054e-01
    z[1,7,1]  R1019     1.5499807894229889e-01
    z[1,7,1]  R1020     4.4935676455497742e-01
    z[1,7,1]  R1021     4.9008226394653320e-01
    z[1,7,1]  R1022     6.5573644638061523e-01
    z[1,7,1]  R1023     -7.9547427594661713e-02
    z[1,7,1]  R1024     5.8217358589172363e-01
    z[1,7,1]  R1025     4.4434210658073425e-01
    z[1,7,1]  R1026     6.3792675733566284e-01
    z[1,7,1]  R1027     2.3921658098697662e-01
    z[1,7,1]  R1028     1.3692812621593475e-01
    z[1,7,1]  R1029     -3.5033699870109558e-01
    z[1,7,1]  R1030     2.3405049741268158e-01
    z[1,7,1]  R1031     -5.1957017183303833e-01
    z[1,7,1]  R1032     5.6142288446426392e-01
    z[1,7,1]  R1033     1.9173850119113922e-01
    z[1,7,1]  R1034     -6.3599482178688049e-02
    z[1,7,1]  R1035     3.2843938469886780e-01
    z[1,7,1]  R1036     -6.9322896003723145e-01
    z[1,7,1]  R1037     3.4201240539550781e-01
    z[1,7,1]  R1038     -8.2714691758155823e-02
    z[1,7,1]  R1039     0.0487123504281044
    z[1,7,1]  R1040     1.3683560490608215e-01
    z[1,7,1]  R1041     -5.1087313890457153e-01
    z[1,7,1]  R1042     8.6742222309112549e-02
    z[1,7,2]  R13       -1
    z[1,7,2]  R67       1
    z[1,7,2]  R934      -1
    z[1,7,2]  R935      1
    z[1,7,2]  R944      1.5428924560546875e-01
    z[1,7,2]  R945      4.0962803363800049e-01
    z[1,7,2]  R946      6.6589558124542236e-01
    z[1,7,2]  R947      -5.7522392272949219e-01
    z[1,7,2]  R948      -5.7281100749969482e-01
    z[1,7,2]  R949      -2.7774125337600708e-01
    z[1,7,2]  R950      5.6136876344680786e-01
    z[1,7,2]  R951      3.6103519797325134e-01
    z[1,7,2]  R952      1.8868075311183929e-01
    z[1,7,2]  R953      2.1593287587165833e-01
    z[1,7,2]  R954      7.1879738569259644e-01
    z[1,7,2]  R955      3.8259690999984741e-01
    z[1,7,2]  R956      2.4863047897815704e-01
    z[1,7,2]  R957      4.0550294518470764e-01
    z[1,7,2]  R958      -9.4124749302864075e-02
    z[1,7,2]  R959      -4.7052997350692749e-01
    z[1,7,2]  R960      -0.661577045917511
    z[1,7,2]  R961      -2.0283532142639160e-01
    z[1,7,2]  R962      -3.4149882197380066e-01
    z[1,7,2]  R963      -8.9774593710899353e-02
    z[1,7,2]  R964      -7.1543413400650024e-01
    z[1,7,2]  R965      -5.2829998731613159e-01
    z[1,7,2]  R966      -5.0700902938842773e-01
    z[1,7,2]  R967      -1.2854686379432678e-01
    z[1,7,2]  R968      -5.9702497720718384e-01
    z[1,7,2]  R969      6.1337524652481079e-01
    z[1,7,2]  R970      -2.6337766647338867e-01
    z[1,7,2]  R971      5.3891700506210327e-01
    z[1,7,2]  R972      -4.6299663186073303e-01
    z[1,7,2]  R973      -3.3626869320869446e-01
    z[1,7,2]  R974      -5.5185207165777683e-03
    z[1,7,2]  R975      1.2516488134860992e-01
    z[1,7,2]  R976      -1.8550613522529602e-01
    z[1,7,2]  R977      4.9989435821771622e-02
    z[1,7,2]  R978      3.4611660242080688e-01
    z[1,7,2]  R979      -5.7898926734924316e-01
    z[1,7,2]  R980      -1.8837502598762512e-01
    z[1,7,2]  R981      -1.5222257375717163e-01
    z[1,7,2]  R982      -1.1982090771198273e-01
    z[1,7,2]  R983      -4.3433573842048645e-01
    z[1,7,2]  R984      -3.8566648960113525e-01
    z[1,7,2]  R985      2.9167747497558594e-01
    z[1,7,2]  R986      -5.5262643098831177e-01
    z[1,7,2]  R987      3.9856532216072083e-01
    z[1,7,2]  R988      -4.4477036595344543e-01
    z[1,7,2]  R989      -0.545142650604248
    z[1,7,2]  R990      0.0301351398229599
    z[1,7,2]  R991      -7.3880887031555176e-01
    z[1,7,2]  R992      -6.6751509904861450e-01
    z[1,7,2]  R993      1.7958452925086021e-02
    z[1,7,2]  R994      -3.0071580410003662e-01
    z[1,7,2]  R995      2.2520966827869415e-01
    z[1,7,2]  R996      3.2320278882980347e-01
    z[1,7,2]  R997      4.7071447968482971e-01
    z[1,7,2]  R998      -6.5022307634353638e-01
    z[1,7,2]  R999      -6.3702452182769775e-01
    z[1,7,2]  R1000     7.2934284806251526e-02
    z[1,7,2]  R1001     2.8145051002502441e-01
    z[1,7,2]  R1002     2.4381391704082489e-01
    z[1,7,2]  R1003     -8.2089319825172424e-02
    z[1,7,2]  R1004     1.5238769352436066e-01
    z[1,7,2]  R1005     3.8924619555473328e-01
    z[1,7,2]  R1006     1.3544920086860657e-01
    z[1,7,2]  R1007     6.2276750802993774e-01
    z[1,7,2]  R1008     3.1706255674362183e-01
    z[1,7,2]  R1009     -7.3331922292709351e-01
    z[1,7,2]  R1010     2.8229501843452454e-01
    z[1,7,2]  R1011     2.0769460499286652e-01
    z[1,7,2]  R1012     -5.9686416387557983e-01
    z[1,7,2]  R1013     7.2961330413818359e-01
    z[1,7,2]  R1014     4.3422129750251770e-01
    z[1,7,2]  R1015     3.8158121705055237e-01
    z[1,7,2]  R1016     0.550506055355072
    z[1,7,2]  R1017     3.2392820715904236e-01
    z[1,7,2]  R1018     2.4571396410465240e-01
    z[1,7,2]  R1019     0.067622110247612
    z[1,7,2]  R1020     0.459238737821579
    z[1,7,2]  R1021     3.2472480088472366e-02
    z[1,7,2]  R1022     2.7156364917755127e-01
    z[1,7,2]  R1023     -1.8956419825553894e-01
    z[1,7,2]  R1024     -6.9618624448776245e-01
    z[1,7,2]  R1025     -3.2738870382308960e-01
    z[1,7,2]  R1026     -4.9386900663375854e-01
    z[1,7,2]  R1027     -5.8306747674942017e-01
    z[1,7,2]  R1028     1.5498754382133484e-01
    z[1,7,2]  R1029     -1.3371452689170837e-01
    z[1,7,2]  R1030     -3.7353730201721191e-01
    z[1,7,2]  R1031     -2.8236207365989685e-01
    z[1,7,2]  R1032     -5.8703833818435669e-01
    z[1,7,2]  R1033     -1.8302412331104279e-01
    z[1,7,2]  R1034     8.9372813701629639e-02
    z[1,7,2]  R1035     -1.2978021800518036e-01
    z[1,7,2]  R1036     6.9510176777839661e-02
    z[1,7,2]  R1037     5.3976005315780640e-01
    z[1,7,2]  R1038     -8.5104942321777344e-01
    z[1,7,2]  R1039     -7.3560386896133423e-01
    z[1,7,2]  R1040     -4.1516625881195068e-01
    z[1,7,2]  R1041     -2.0120188593864441e-01
    z[1,7,2]  R1042     -4.5631888508796692e-01
    z[1,7,3]  R14       -1
    z[1,7,3]  R68       1
    z[1,7,3]  R936      -1
    z[1,7,3]  R937      1
    z[1,7,3]  R944      -1.9785149395465851e-01
    z[1,7,3]  R945      -1.5579080581665039e-01
    z[1,7,3]  R946      -1.2824720144271851e-01
    z[1,7,3]  R947      -1.8338501453399658e-01
    z[1,7,3]  R948      -1.1830183863639832e-01
    z[1,7,3]  R949      -2.9639992117881775e-01
    z[1,7,3]  R950      -1.6545537114143372e-01
    z[1,7,3]  R951      -8.5804708302021027e-02
    z[1,7,3]  R952      -2.9832187294960022e-01
    z[1,7,3]  R953      -1.2625852227210999e-01
    z[1,7,3]  R954      3.0539923906326294e-01
    z[1,7,3]  R955      7.6536345481872559e-01
    z[1,7,3]  R956      4.9695274233818054e-01
    z[1,7,3]  R957      5.2950328588485718e-01
    z[1,7,3]  R958      4.5159395784139633e-02
    z[1,7,3]  R959      8.6288101971149445e-02
    z[1,7,3]  R960      -2.1833214163780212e-01
    z[1,7,3]  R961      6.7773485183715820e-01
    z[1,7,3]  R962      5.8339411020278931e-01
    z[1,7,3]  R963      8.2833594083786011e-01
    z[1,7,3]  R964      -4.2537021636962891e-01
    z[1,7,3]  R965      -0.408914178609848
    z[1,7,3]  R966      -6.0810461640357971e-02
    z[1,7,3]  R967      -9.0807807445526123e-01
    z[1,7,3]  R968      1.6254587471485138e-01
    z[1,7,3]  R969      -1.5159854292869568e-01
    z[1,7,3]  R970      -6.9932979345321655e-01
    z[1,7,3]  R971      1.6053098440170288e-01
    z[1,7,3]  R972      3.4772035479545593e-01
    z[1,7,3]  R973      -4.2696991562843323e-01
    z[1,7,3]  R974      -8.7268584966659546e-01
    z[1,7,3]  R975      -5.4635971784591675e-01
    z[1,7,3]  R976      -6.4791935682296753e-01
    z[1,7,3]  R977      -7.7812254428863525e-01
    z[1,7,3]  R978      2.4809615314006805e-01
    z[1,7,3]  R979      5.4636709392070770e-02
    z[1,7,3]  R980      -4.3005886673927307e-01
    z[1,7,3]  R981      -4.3866130709648132e-01
    z[1,7,3]  R982      -3.9875060319900513e-01
    z[1,7,3]  R983      -3.0273789167404175e-01
    z[1,7,3]  R984      -4.1669008135795593e-01
    z[1,7,3]  R985      -8.8196210563182831e-02
    z[1,7,3]  R986      -6.0438591241836548e-01
    z[1,7,3]  R987      -5.9017026424407959e-01
    z[1,7,3]  R988      -1.5177384018898010e-01
    z[1,7,3]  R989      3.3042982220649719e-01
    z[1,7,3]  R990      8.0193474888801575e-02
    z[1,7,3]  R991      0.0891735851764679
    z[1,7,3]  R992      2.8843116760253906e-01
    z[1,7,3]  R993      6.1815810203552246e-01
    z[1,7,3]  R994      -9.0811568498611450e-01
    z[1,7,3]  R995      -4.9738240242004395e-01
    z[1,7,3]  R996      -8.3319848775863647e-01
    z[1,7,3]  R997      4.9404117465019226e-01
    z[1,7,3]  R998      -3.2991480082273483e-02
    z[1,7,3]  R999      3.7585198879241943e-01
    z[1,7,3]  R1000     -4.0448507666587830e-01
    z[1,7,3]  R1001     -7.5693726539611816e-02
    z[1,7,3]  R1002     2.9689380526542664e-01
    z[1,7,3]  R1003     5.2299493551254272e-01
    z[1,7,3]  R1004     -1.9879573583602905e-01
    z[1,7,3]  R1005     -1.2019961327314377e-01
    z[1,7,3]  R1006     -2.1669751405715942e-01
    z[1,7,3]  R1007     -1.7680196464061737e-01
    z[1,7,3]  R1008     -2.1421962976455688e-01
    z[1,7,3]  R1009     -1.0761692374944687e-01
    z[1,7,3]  R1010     1.9323322176933289e-01
    z[1,7,3]  R1011     2.0005673170089722e-01
    z[1,7,3]  R1012     3.9944455027580261e-01
    z[1,7,3]  R1013     2.5041863322257996e-01
    z[1,7,3]  R1014     2.5284075736999512e-01
    z[1,7,3]  R1015     7.8956015408039093e-02
    z[1,7,3]  R1016     3.5475313663482666e-01
    z[1,7,3]  R1017     4.1027444601058960e-01
    z[1,7,3]  R1018     3.6534574627876282e-01
    z[1,7,3]  R1019     -9.1493481397628784e-01
    z[1,7,3]  R1020     2.1414358913898468e-01
    z[1,7,3]  R1021     2.4445576965808868e-01
    z[1,7,3]  R1022     3.4286347031593323e-01
    z[1,7,3]  R1023     -6.6909611225128174e-01
    z[1,7,3]  R1024     -8.4517627954483032e-02
    z[1,7,3]  R1025     -5.9091800451278687e-01
    z[1,7,3]  R1026     -3.9055764675140381e-01
    z[1,7,3]  R1027     -1.2892629206180573e-01
    z[1,7,3]  R1028     -4.0681746602058411e-01
    z[1,7,3]  R1029     -7.3988062143325806e-01
    z[1,7,3]  R1030     -7.0957213640213013e-01
    z[1,7,3]  R1031     -5.8777654170989990e-01
    z[1,7,3]  R1032     1.9040267169475555e-01
    z[1,7,3]  R1033     -8.9693957567214966e-01
    z[1,7,3]  R1034     -9.2326998710632324e-01
    z[1,7,3]  R1035     -5.1264625042676926e-02
    z[1,7,3]  R1036     -2.4642907083034515e-01
    z[1,7,3]  R1037     -5.7452076673507690e-01
    z[1,7,3]  R1038     -3.1194803118705750e-01
    z[1,7,3]  R1039     4.3479931354522705e-01
    z[1,7,3]  R1040     3.0651673674583435e-01
    z[1,7,3]  R1041     -4.3567517399787903e-01
    z[1,7,3]  R1042     4.9107018113136292e-01
    z[1,7,4]  R15       -1
    z[1,7,4]  R69       1
    z[1,7,4]  R938      -1
    z[1,7,4]  R939      1
    z[1,7,4]  R944      2.8005328774452209e-01
    z[1,7,4]  R945      3.1539127230644226e-01
    z[1,7,4]  R946      1.8078483641147614e-01
    z[1,7,4]  R947      3.1668260693550110e-01
    z[1,7,4]  R948      5.9276384115219116e-01
    z[1,7,4]  R949      1.5372152626514435e-01
    z[1,7,4]  R950      -3.5441529750823975e-01
    z[1,7,4]  R951      0.682155430316925
    z[1,7,4]  R952      8.0553829669952393e-01
    z[1,7,4]  R953      7.1015870571136475e-01
    z[1,7,4]  R954      -2.3386125266551971e-01
    z[1,7,4]  R955      -4.2920134961605072e-02
    z[1,7,4]  R956      6.7264698445796967e-03
    z[1,7,4]  R957      -1.3860683143138885e-01
    z[1,7,4]  R958      -1.0556232929229736e-01
    z[1,7,4]  R959      -0.180857852101326
    z[1,7,4]  R960      -0.347945898771286
    z[1,7,4]  R961      1.9008468091487885e-01
    z[1,7,4]  R962      -5.6145143508911133e-01
    z[1,7,4]  R963      -1.2967351078987122e-01
    z[1,7,4]  R964      1.1638043820858002e-01
    z[1,7,4]  R965      3.6474909633398056e-02
    z[1,7,4]  R966      -2.7737969160079956e-01
    z[1,7,4]  R967      1.9040282070636749e-01
    z[1,7,4]  R968      -2.9372459650039673e-01
    z[1,7,4]  R969      -6.5552002191543579e-01
    z[1,7,4]  R970      6.1285290867090225e-02
    z[1,7,4]  R971      -3.7403675913810730e-01
    z[1,7,4]  R972      1.5211680531501770e-01
    z[1,7,4]  R973      2.6128438115119934e-01
    z[1,7,4]  R974      -0.0209683645516634
    z[1,7,4]  R975      2.5459289550781250e-01
    z[1,7,4]  R976      6.8388420343399048e-01
    z[1,7,4]  R977      -2.5255185365676880e-01
    z[1,7,4]  R978      -3.7624785304069519e-01
    z[1,7,4]  R979      2.7798625826835632e-01
    z[1,7,4]  R980      -1.2289223819971085e-01
    z[1,7,4]  R981      -5.3070688247680664e-01
    z[1,7,4]  R982      -4.8383176326751709e-01
    z[1,7,4]  R983      4.1114774346351624e-01
    z[1,7,4]  R984      1.1680650711059570e-01
    z[1,7,4]  R985      7.0235341787338257e-02
    z[1,7,4]  R986      -4.6366035938262939e-01
    z[1,7,4]  R987      2.2281800210475922e-01
    z[1,7,4]  R988      -2.2254188358783722e-01
    z[1,7,4]  R989      -4.0633025765419006e-01
    z[1,7,4]  R990      -8.1712412834167480e-01
    z[1,7,4]  R991      -2.9364114999771118e-01
    z[1,7,4]  R992      1.6318482160568237e-01
    z[1,7,4]  R993      2.2752128541469574e-01
    z[1,7,4]  R994      1.4992308802902699e-02
    z[1,7,4]  R995      0.574512779712677
    z[1,7,4]  R996      -1.1573029309511185e-01
    z[1,7,4]  R997      6.6686391830444336e-02
    z[1,7,4]  R998      -0.254208505153656
    z[1,7,4]  R999      1.9960589706897736e-01
    z[1,7,4]  R1000     -0.208910271525383
    z[1,7,4]  R1001     -4.3405908346176147e-01
    z[1,7,4]  R1002     4.1917651891708374e-01
    z[1,7,4]  R1003     -7.3116861283779144e-02
    z[1,7,4]  R1004     2.8136044740676880e-01
    z[1,7,4]  R1005     1.3414669036865234e-01
    z[1,7,4]  R1006     6.0929656028747559e-01
    z[1,7,4]  R1007     4.6493580937385559e-01
    z[1,7,4]  R1008     5.8546477556228638e-01
    z[1,7,4]  R1009     -9.6167489886283875e-02
    z[1,7,4]  R1010     -1.0068996995687485e-01
    z[1,7,4]  R1011     -1.6605491936206818e-01
    z[1,7,4]  R1012     3.6492672562599182e-01
    z[1,7,4]  R1013     -2.4456101655960083e-01
    z[1,7,4]  R1014     -2.1529795229434967e-01
    z[1,7,4]  R1015     -2.6367521286010742e-01
    z[1,7,4]  R1016     2.7901515364646912e-01
    z[1,7,4]  R1017     2.8647467494010925e-01
    z[1,7,4]  R1018     9.8640955984592438e-02
    z[1,7,4]  R1019     -3.3423733711242676e-01
    z[1,7,4]  R1020     5.5307867005467415e-03
    z[1,7,4]  R1021     -2.2386403381824493e-01
    z[1,7,4]  R1022     -3.8595151901245117e-01
    z[1,7,4]  R1023     -1.9395154714584351e-01
    z[1,7,4]  R1024     -1.3204665482044220e-01
    z[1,7,4]  R1025     4.1910582780838013e-01
    z[1,7,4]  R1026     1.9031862914562225e-01
    z[1,7,4]  R1027     -2.3103572428226471e-01
    z[1,7,4]  R1028     7.7144846320152283e-02
    z[1,7,4]  R1029     0.0887860581278801
    z[1,7,4]  R1030     -3.5474222898483276e-01
    z[1,7,4]  R1031     -4.5493033528327942e-01
    z[1,7,4]  R1032     4.9308523535728455e-02
    z[1,7,4]  R1033     3.2211273908615112e-01
    z[1,7,4]  R1034     2.5527609977871180e-03
    z[1,7,4]  R1035     0.415828675031662
    z[1,7,4]  R1036     -2.0532572269439697e-01
    z[1,7,4]  R1037     1.3875405490398407e-01
    z[1,7,4]  R1038     -3.2913282513618469e-02
    z[1,7,4]  R1039     4.0149144828319550e-02
    z[1,7,4]  R1040     2.2124961018562317e-01
    z[1,7,4]  R1041     -5.4027330130338669e-02
    z[1,7,4]  R1042     3.3655592799186707e-01
    z[1,7,5]  R16       -1
    z[1,7,5]  R70       1
    z[1,7,5]  R940      -1
    z[1,7,5]  R941      1
    z[1,7,5]  R944      1.2996168434619904e-01
    z[1,7,5]  R945      4.9831250309944153e-01
    z[1,7,5]  R946      -5.2954863756895065e-02
    z[1,7,5]  R947      -1.0397800803184509e-01
    z[1,7,5]  R948      -4.3760299682617188e-02
    z[1,7,5]  R949      -4.7443735599517822e-01
    z[1,7,5]  R950      4.0084591507911682e-01
    z[1,7,5]  R951      2.3899297416210175e-01
    z[1,7,5]  R952      -1.7053984105587006e-01
    z[1,7,5]  R953      -9.2424347996711731e-02
    z[1,7,5]  R954      6.7016161978244781e-02
    z[1,7,5]  R955      1.2693777680397034e-01
    z[1,7,5]  R956      -8.8410764932632446e-02
    z[1,7,5]  R957      4.9413305521011353e-01
    z[1,7,5]  R958      -5.4077520966529846e-02
    z[1,7,5]  R959      -3.5688707232475281e-01
    z[1,7,5]  R960      7.8935608267784119e-02
    z[1,7,5]  R961      -0.186315655708313
    z[1,7,5]  R962      -6.7505680024623871e-02
    z[1,7,5]  R963      6.6189900040626526e-02
    z[1,7,5]  R964      -3.7717631459236145e-01
    z[1,7,5]  R965      -5.9734326601028442e-01
    z[1,7,5]  R966      -4.7837734222412109e-01
    z[1,7,5]  R967      2.5130003690719604e-01
    z[1,7,5]  R968      -6.3161790370941162e-01
    z[1,7,5]  R969      1.6878260672092438e-01
    z[1,7,5]  R970      5.8353751897811890e-01
    z[1,7,5]  R971      3.8660675287246704e-01
    z[1,7,5]  R972      -0.318907767534256
    z[1,7,5]  R973      -1.6402861475944519e-01
    z[1,7,5]  R974      -1.2997676432132721e-01
    z[1,7,5]  R975      -3.9555296301841736e-01
    z[1,7,5]  R976      1.1939511448144913e-01
    z[1,7,5]  R977      -1.0598129779100418e-01
    z[1,7,5]  R978      0.0935024619102478
    z[1,7,5]  R979      -5.0922483205795288e-01
    z[1,7,5]  R980      -2.5957217812538147e-01
    z[1,7,5]  R981      -3.4279155731201172e-01
    z[1,7,5]  R982      -2.1769352257251740e-01
    z[1,7,5]  R983      2.4725930392742157e-01
    z[1,7,5]  R984      -5.9044855833053589e-01
    z[1,7,5]  R985      3.7515202164649963e-01
    z[1,7,5]  R986      -0.0705728530883789
    z[1,7,5]  R987      6.1502200365066528e-01
    z[1,7,5]  R988      -3.3472391963005066e-01
    z[1,7,5]  R989      -3.5757660865783691e-01
    z[1,7,5]  R990      -7.8355483710765839e-02
    z[1,7,5]  R991      -1.3906839489936829e-01
    z[1,7,5]  R992      -1.8571268767118454e-02
    z[1,7,5]  R993      -2.0394992828369141e-01
    z[1,7,5]  R994      0.0060595260001719
    z[1,7,5]  R995      7.9848654568195343e-02
    z[1,7,5]  R996      3.7020778656005859e-01
    z[1,7,5]  R997      3.0023878812789917e-01
    z[1,7,5]  R998      -3.0967068672180176e-01
    z[1,7,5]  R999      -3.7857425212860107e-01
    z[1,7,5]  R1000     -5.5424129962921143e-01
    z[1,7,5]  R1001     5.4742813110351562e-01
    z[1,7,5]  R1002     -2.9570639133453369e-01
    z[1,7,5]  R1003     3.1599190831184387e-01
    z[1,7,5]  R1004     1.2903597950935364e-01
    z[1,7,5]  R1005     5.0718921422958374e-01
    z[1,7,5]  R1006     4.9037474393844604e-01
    z[1,7,5]  R1007     -1.2133947759866714e-01
    z[1,7,5]  R1008     1.1665125936269760e-01
    z[1,7,5]  R1009     -2.1996637806296349e-02
    z[1,7,5]  R1010     1.4449493587017059e-01
    z[1,7,5]  R1011     -1.3534571230411530e-01
    z[1,7,5]  R1012     1.2469103187322617e-01
    z[1,7,5]  R1013     4.2589064687490463e-02
    z[1,7,5]  R1014     4.6388205885887146e-01
    z[1,7,5]  R1015     6.5515274181962013e-03
    z[1,7,5]  R1016     -3.1412345170974731e-01
    z[1,7,5]  R1017     -1.1265028268098831e-01
    z[1,7,5]  R1018     1.6476555168628693e-01
    z[1,7,5]  R1019     -3.8684133440256119e-02
    z[1,7,5]  R1020     -0.51753830909729
    z[1,7,5]  R1021     -2.8312796354293823e-01
    z[1,7,5]  R1022     -7.5021870434284210e-02
    z[1,7,5]  R1023     -0.572472095489502
    z[1,7,5]  R1024     -2.5666135549545288e-01
    z[1,7,5]  R1025     -2.5014990568161011e-01
    z[1,7,5]  R1026     -3.4819102287292480e-01
    z[1,7,5]  R1027     -3.0022063851356506e-01
    z[1,7,5]  R1028     -7.7347451448440552e-01
    z[1,7,5]  R1029     -1.6917371749877930e-01
    z[1,7,5]  R1030     2.4217553436756134e-01
    z[1,7,5]  R1031     -5.9445660561323166e-02
    z[1,7,5]  R1032     -4.9349084496498108e-01
    z[1,7,5]  R1033     1.0130524635314941e-01
    z[1,7,5]  R1034     -3.2140168547630310e-01
    z[1,7,5]  R1035     -5.9102743864059448e-01
    z[1,7,5]  R1036     -5.9029066562652588e-01
    z[1,7,5]  R1037     4.5784175395965576e-01
    z[1,7,5]  R1038     -1.1757113784551620e-01
    z[1,7,5]  R1039     -4.3659603595733643e-01
    z[1,7,5]  R1040     -0.759149968624115
    z[1,7,5]  R1041     -3.9859518408775330e-02
    z[1,7,5]  R1042     -5.7088422775268555e-01
    z[1,7,6]  R17       -1
    z[1,7,6]  R71       1
    z[1,7,6]  R942      -1
    z[1,7,6]  R943      1
    z[1,7,6]  R944      -4.1296545416116714e-02
    z[1,7,6]  R945      4.7544579952955246e-02
    z[1,7,6]  R946      -2.8484994173049927e-01
    z[1,7,6]  R947      -3.4448447823524475e-01
    z[1,7,6]  R948      1.0768654197454453e-01
    z[1,7,6]  R949      -5.8732575178146362e-01
    z[1,7,6]  R950      1.0995424352586269e-02
    z[1,7,6]  R951      1.1395853757858276e-01
    z[1,7,6]  R952      -3.8139519095420837e-01
    z[1,7,6]  R953      7.5161732733249664e-02
    z[1,7,6]  R954      9.8768718540668488e-02
    z[1,7,6]  R955      -1.5962858498096466e-01
    z[1,7,6]  R956      -3.5750970244407654e-01
    z[1,7,6]  R957      -1.5360661782324314e-02
    z[1,7,6]  R958      -1.5741893649101257e-01
    z[1,7,6]  R959      3.2253009080886841e-01
    z[1,7,6]  R960      3.8437563180923462e-01
    z[1,7,6]  R961      -1.6234208643436432e-01
    z[1,7,6]  R962      -1.6507243737578392e-02
    z[1,7,6]  R963      8.9567065238952637e-02
    z[1,7,6]  R964      3.1049272045493126e-02
    z[1,7,6]  R965      1.2024573236703873e-01
    z[1,7,6]  R966      -0.277940034866333
    z[1,7,6]  R967      2.0571085810661316e-01
    z[1,7,6]  R968      7.1777604520320892e-02
    z[1,7,6]  R969      -1.4794050157070160e-01
    z[1,7,6]  R970      -7.2795733809471130e-02
    z[1,7,6]  R971      -3.8922619819641113e-01
    z[1,7,6]  R972      -1.8607042729854584e-01
    z[1,7,6]  R973      -1.2934499979019165e-01
    z[1,7,6]  R974      8.4637450054287910e-03
    z[1,7,6]  R975      1.3048601150512695e-01
    z[1,7,6]  R976      5.3298264741897583e-02
    z[1,7,6]  R977      -2.7908441424369812e-01
    z[1,7,6]  R978      1.6596347093582153e-01
    z[1,7,6]  R979      0.00876099057495594
    z[1,7,6]  R980      3.9219805598258972e-01
    z[1,7,6]  R981      2.2666966915130615e-01
    z[1,7,6]  R982      5.0538641214370728e-01
    z[1,7,6]  R983      4.1560640931129456e-01
    z[1,7,6]  R984      2.2250089049339294e-01
    z[1,7,6]  R985      4.8746901750564575e-01
    z[1,7,6]  R986      3.5872368607670069e-03
    z[1,7,6]  R987      0.087613046169281
    z[1,7,6]  R988      -5.4974645376205444e-01
    z[1,7,6]  R989      -2.0097108185291290e-01
    z[1,7,6]  R990      -1.6633279621601105e-01
    z[1,7,6]  R991      3.9147740602493286e-01
    z[1,7,6]  R992      -2.4853512644767761e-01
    z[1,7,6]  R993      -5.5437427014112473e-02
    z[1,7,6]  R994      7.4375040829181671e-02
    z[1,7,6]  R995      6.3531458377838135e-02
    z[1,7,6]  R996      -6.5903551876544952e-02
    z[1,7,6]  R997      -6.2070630490779877e-02
    z[1,7,6]  R998      -9.2620790004730225e-02
    z[1,7,6]  R999      -2.5661420822143555e-01
    z[1,7,6]  R1000     -2.8402399271726608e-02
    z[1,7,6]  R1001     -1.0774499922990799e-01
    z[1,7,6]  R1002     -0.587288498878479
    z[1,7,6]  R1003     2.1513158082962036e-01
    z[1,7,6]  R1004     -3.5278104245662689e-02
    z[1,7,6]  R1005     2.0132671296596527e-01
    z[1,7,6]  R1006     -0.0667652115225792
    z[1,7,6]  R1007     1.7769466340541840e-01
    z[1,7,6]  R1008     2.9563727974891663e-01
    z[1,7,6]  R1009     2.0852752029895782e-01
    z[1,7,6]  R1010     -7.0347420871257782e-02
    z[1,7,6]  R1011     4.7084507346153259e-01
    z[1,7,6]  R1012     2.1488350629806519e-01
    z[1,7,6]  R1013     5.5983554571866989e-02
    z[1,7,6]  R1014     -1.7407430708408356e-01
    z[1,7,6]  R1015     -3.4601387381553650e-01
    z[1,7,6]  R1016     -1.5069159865379333e-01
    z[1,7,6]  R1017     -2.5914004445075989e-01
    z[1,7,6]  R1018     -4.2466285824775696e-01
    z[1,7,6]  R1019     -4.6498034149408340e-02
    z[1,7,6]  R1020     -1.0482472181320190e-01
    z[1,7,6]  R1021     -5.0177793949842453e-02
    z[1,7,6]  R1022     2.4532899260520935e-01
    z[1,7,6]  R1023     0.323185533285141
    z[1,7,6]  R1024     -4.7742825001478195e-02
    z[1,7,6]  R1025     -1.8472076952457428e-01
    z[1,7,6]  R1026     -1.7829626798629761e-01
    z[1,7,6]  R1027     3.0573625117540359e-02
    z[1,7,6]  R1028     -3.2567363232374191e-02
    z[1,7,6]  R1029     -3.5136780142784119e-01
    z[1,7,6]  R1030     1.8085611518472433e-03
    z[1,7,6]  R1031     -2.3121614754199982e-01
    z[1,7,6]  R1032     -9.1499179601669312e-02
    z[1,7,6]  R1033     1.0097808390855789e-01
    z[1,7,6]  R1034     -1.6042618453502655e-01
    z[1,7,6]  R1035     3.3555500209331512e-02
    z[1,7,6]  R1036     -1.1515476554632187e-01
    z[1,7,6]  R1037     1.7848303914070129e-01
    z[1,7,6]  R1038     -2.8546676039695740e-01
    z[1,7,6]  R1039     -2.5411024689674377e-01
    z[1,7,6]  R1040     2.4185892939567566e-01
    z[1,7,6]  R1041     3.9354795217514038e-01
    z[1,7,6]  R1042     -1.6337199509143829e-01
    z[7,1,0]  R11       1
    z[7,1,0]  R65       -1
    z[7,1,0]  R1043     -1
    z[7,1,0]  R1044     1
    z[7,1,0]  R1057     0.56584632396698
    z[7,1,0]  R1058     3.8680833578109741e-01
    z[7,1,0]  R1059     3.1114852428436279e-01
    z[7,1,0]  R1060     2.8785562515258789e-01
    z[7,1,0]  R1061     3.1329560279846191e-01
    z[7,1,0]  R1062     6.3915866613388062e-01
    z[7,1,0]  R1063     6.1947333812713623e-01
    z[7,1,0]  R1064     -3.6312767863273621e-01
    z[7,1,0]  R1065     -1.4555731415748596e-01
    z[7,1,0]  R1066     1.5721313655376434e-01
    z[7,1,0]  R1067     -0.337566077709198
    z[7,1,0]  R1068     -4.3169227242469788e-01
    z[7,1,0]  R1069     -6.1430495977401733e-01
    z[7,1,0]  R1070     -4.2309236526489258e-01
    z[7,1,0]  R1071     -6.2170523405075073e-01
    z[7,1,0]  R1072     -6.3902544975280762e-01
    z[7,1,0]  R1073     -1.3756404817104340e-01
    z[7,1,0]  R1074     -5.1230460405349731e-01
    z[7,1,0]  R1075     -7.5247043371200562e-01
    z[7,1,0]  R1076     -4.0488809347152710e-01
    z[7,1,0]  R1077     2.0064330101013184e-01
    z[7,1,0]  R1078     -2.8924819827079773e-01
    z[7,1,0]  R1079     2.7174675464630127e-01
    z[7,1,0]  R1080     -8.5789456963539124e-02
    z[7,1,0]  R1081     -6.6463607549667358e-01
    z[7,1,0]  R1082     4.3180355429649353e-01
    z[7,1,0]  R1083     -3.8987055420875549e-01
    z[7,1,0]  R1084     0.343079149723053
    z[7,1,0]  R1085     -2.0219059288501740e-01
    z[7,1,0]  R1086     2.2271190583705902e-01
    z[7,1,0]  R1087     3.1970273703336716e-02
    z[7,1,0]  R1088     8.0609925091266632e-02
    z[7,1,0]  R1089     5.9101927280426025e-01
    z[7,1,0]  R1090     -2.2363428771495819e-01
    z[7,1,0]  R1091     -2.9740871861577034e-02
    z[7,1,0]  R1092     2.7416062355041504e-01
    z[7,1,0]  R1093     -1.0326413810253143e-01
    z[7,1,0]  R1094     -1.7664854228496552e-01
    z[7,1,0]  R1095     -5.9103786945343018e-01
    z[7,1,0]  R1096     -2.7790278196334839e-01
    z[7,1,0]  R1097     5.6712478399276733e-01
    z[7,1,0]  R1098     5.7326781749725342e-01
    z[7,1,0]  R1099     3.5377502441406250e-01
    z[7,1,0]  R1100     6.1590307950973511e-01
    z[7,1,0]  R1101     4.0936514735221863e-01
    z[7,1,0]  R1102     1.7265732586383820e-01
    z[7,1,0]  R1103     2.4288158118724823e-01
    z[7,1,0]  R1104     2.0638771355152130e-01
    z[7,1,0]  R1105     0.621462345123291
    z[7,1,0]  R1106     -5.0725597143173218e-01
    z[7,1,0]  R1107     -4.5115393400192261e-01
    z[7,1,0]  R1108     -7.2730302810668945e-01
    z[7,1,0]  R1109     -4.6807822585105896e-01
    z[7,1,0]  R1110     -7.8397506475448608e-01
    z[7,1,0]  R1111     -3.0847826600074768e-01
    z[7,1,0]  R1112     -2.0180958509445190e-01
    z[7,1,0]  R1113     -4.7805258631706238e-01
    z[7,1,0]  R1114     -4.5329952239990234e-01
    z[7,1,0]  R1115     -3.3067616820335388e-01
    z[7,1,0]  R1116     -2.8777632117271423e-01
    z[7,1,0]  R1117     3.1904092431068420e-01
    z[7,1,0]  R1118     -5.8472013473510742e-01
    z[7,1,0]  R1119     -1.1177876591682434e-01
    z[7,1,0]  R1120     1.5771120786666870e-01
    z[7,1,0]  R1121     -1.2083274126052856e-01
    z[7,1,0]  R1122     -3.0223888158798218e-01
    z[7,1,0]  R1123     -4.8529732227325439e-01
    z[7,1,0]  R1124     1.0204591602087021e-01
    z[7,1,0]  R1125     1.7605938017368317e-01
    z[7,1,0]  R1126     3.5676565766334534e-01
    z[7,1,0]  R1127     6.0027921199798584e-01
    z[7,1,0]  R1128     -2.0596690475940704e-01
    z[7,1,0]  R1129     -1.1497341096401215e-01
    z[7,1,0]  R1130     -1.2827318906784058e-01
    z[7,1,0]  R1131     2.9592707753181458e-01
    z[7,1,0]  R1132     -4.6516966074705124e-02
    z[7,1,0]  R1133     -1.7297618091106415e-01
    z[7,1,0]  R1134     2.1709685027599335e-01
    z[7,1,0]  R1135     2.8099268674850464e-01
    z[7,1,0]  R1136     4.5194447040557861e-01
    z[7,1,0]  R1137     1.7751461267471313e-01
    z[7,1,0]  R1138     2.8391501307487488e-01
    z[7,1,0]  R1139     -0.141950786113739
    z[7,1,0]  R1140     -2.7992233633995056e-01
    z[7,1,0]  R1141     -2.6550477743148804e-01
    z[7,1,0]  R1142     -1.6600802540779114e-02
    z[7,1,0]  R1143     -9.8987082019448280e-03
    z[7,1,0]  R1144     -2.7718076109886169e-01
    z[7,1,0]  R1145     -2.1165333688259125e-01
    z[7,1,0]  R1146     -1.7723931372165680e-01
    z[7,1,0]  R1147     8.8512469083070755e-03
    z[7,1,0]  R1148     1.0552880913019180e-01
    z[7,1,0]  R1149     -2.0274975895881653e-01
    z[7,1,0]  R1150     -6.2486010789871216e-01
    z[7,1,0]  R1151     -4.3374547362327576e-01
    z[7,1,0]  R1152     -5.0168428570032120e-03
    z[7,1,0]  R1153     -6.3746839761734009e-01
    z[7,1,0]  R1154     -3.2313367724418640e-01
    z[7,1,0]  R1155     3.9484769105911255e-01
    z[7,1,1]  R12       1
    z[7,1,1]  R66       -1
    z[7,1,1]  R1045     -1
    z[7,1,1]  R1046     1
    z[7,1,1]  R1057     -7.2112256288528442e-01
    z[7,1,1]  R1058     -6.0716563463211060e-01
    z[7,1,1]  R1059     -4.7086629271507263e-01
    z[7,1,1]  R1060     -4.8536252975463867e-01
    z[7,1,1]  R1061     -4.4142702221870422e-01
    z[7,1,1]  R1062     -3.5772338509559631e-02
    z[7,1,1]  R1063     -1.1704052239656448e-01
    z[7,1,1]  R1064     -8.4566110372543335e-01
    z[7,1,1]  R1065     -7.9250574111938477e-01
    z[7,1,1]  R1066     5.1438021659851074e-01
    z[7,1,1]  R1067     4.7565326094627380e-01
    z[7,1,1]  R1068     5.1896393299102783e-01
    z[7,1,1]  R1069     5.3056395053863525e-01
    z[7,1,1]  R1070     4.3915295600891113e-01
    z[7,1,1]  R1071     4.2227533459663391e-01
    z[7,1,1]  R1072     4.2494386434555054e-01
    z[7,1,1]  R1073     1.5499807894229889e-01
    z[7,1,1]  R1074     4.4935676455497742e-01
    z[7,1,1]  R1075     4.9008226394653320e-01
    z[7,1,1]  R1076     6.5573644638061523e-01
    z[7,1,1]  R1077     -7.9547427594661713e-02
    z[7,1,1]  R1078     5.8217358589172363e-01
    z[7,1,1]  R1079     4.4434210658073425e-01
    z[7,1,1]  R1080     6.3792675733566284e-01
    z[7,1,1]  R1081     2.3921658098697662e-01
    z[7,1,1]  R1082     1.3692812621593475e-01
    z[7,1,1]  R1083     -3.5033699870109558e-01
    z[7,1,1]  R1084     2.3405049741268158e-01
    z[7,1,1]  R1085     -5.1957017183303833e-01
    z[7,1,1]  R1086     5.6142288446426392e-01
    z[7,1,1]  R1087     1.9173850119113922e-01
    z[7,1,1]  R1088     -6.3599482178688049e-02
    z[7,1,1]  R1089     3.2843938469886780e-01
    z[7,1,1]  R1090     -6.9322896003723145e-01
    z[7,1,1]  R1091     3.4201240539550781e-01
    z[7,1,1]  R1092     -8.2714691758155823e-02
    z[7,1,1]  R1093     0.0487123504281044
    z[7,1,1]  R1094     1.3683560490608215e-01
    z[7,1,1]  R1095     -5.1087313890457153e-01
    z[7,1,1]  R1096     8.6742222309112549e-02
    z[7,1,1]  R1097     -7.1999573707580566e-01
    z[7,1,1]  R1098     -3.5951447486877441e-01
    z[7,1,1]  R1099     -5.4621613025665283e-01
    z[7,1,1]  R1100     -1.6242490708827972e-01
    z[7,1,1]  R1101     -2.7157762646675110e-01
    z[7,1,1]  R1102     -5.8418369293212891e-01
    z[7,1,1]  R1103     -5.1755124330520630e-01
    z[7,1,1]  R1104     -0.0967964380979538
    z[7,1,1]  R1105     -1.8083013594150543e-01
    z[7,1,1]  R1106     0.252617210149765
    z[7,1,1]  R1107     1.4443641901016235e-01
    z[7,1,1]  R1108     1.6302208602428436e-01
    z[7,1,1]  R1109     2.6922336220741272e-01
    z[7,1,1]  R1110     -5.7934081554412842e-01
    z[7,1,1]  R1111     -6.4178925752639771e-01
    z[7,1,1]  R1112     4.4595742225646973e-01
    z[7,1,1]  R1113     -4.1689127683639526e-01
    z[7,1,1]  R1114     1.3225845992565155e-01
    z[7,1,1]  R1115     -4.0894353389739990e-01
    z[7,1,1]  R1116     2.6005470752716064e-01
    z[7,1,1]  R1117     2.8158989548683167e-01
    z[7,1,1]  R1118     1.1962978541851044e-01
    z[7,1,1]  R1119     6.8216927349567413e-02
    z[7,1,1]  R1120     3.1921774148941040e-01
    z[7,1,1]  R1121     -3.2574182748794556e-01
    z[7,1,1]  R1122     2.5507461279630661e-02
    z[7,1,1]  R1123     -8.6136408150196075e-02
    z[7,1,1]  R1124     7.0345389842987061e-01
    z[7,1,1]  R1125     7.4947863817214966e-01
    z[7,1,1]  R1126     3.0610787868499756e-01
    z[7,1,1]  R1127     -2.9526799917221069e-01
    z[7,1,1]  R1128     -1.3627997040748596e-01
    z[7,1,1]  R1129     -4.7529456019401550e-01
    z[7,1,1]  R1130     -7.9015719890594482e-01
    z[7,1,1]  R1131     4.8739153146743774e-01
    z[7,1,1]  R1132     -7.3559558391571045e-01
    z[7,1,1]  R1133     -5.5131548643112183e-01
    z[7,1,1]  R1134     -4.9255535006523132e-01
    z[7,1,1]  R1135     4.8768538236618042e-01
    z[7,1,1]  R1136     -2.4818757176399231e-01
    z[7,1,1]  R1137     -7.0166671276092529e-01
    z[7,1,1]  R1138     -1.6952741146087646e-01
    z[7,1,1]  R1139     -1.9266216456890106e-01
    z[7,1,1]  R1140     4.8682785034179688e-01
    z[7,1,1]  R1141     4.3564680218696594e-01
    z[7,1,1]  R1142     5.3933960199356079e-01
    z[7,1,1]  R1143     4.3277230858802795e-01
    z[7,1,1]  R1144     5.5286341905593872e-01
    z[7,1,1]  R1145     -0.690163791179657
    z[7,1,1]  R1146     -0.218377947807312
    z[7,1,1]  R1147     -6.0111218690872192e-01
    z[7,1,1]  R1148     -1.8813097476959229e-01
    z[7,1,1]  R1149     -6.2833160161972046e-01
    z[7,1,1]  R1150     1.2874330580234528e-01
    z[7,1,1]  R1151     1.2565034627914429e-01
    z[7,1,1]  R1152     -6.9239699840545654e-01
    z[7,1,1]  R1153     -9.4848774373531342e-02
    z[7,1,1]  R1154     -3.7407833337783813e-01
    z[7,1,1]  R1155     6.4214813709259033e-01
    z[7,1,2]  R13       1
    z[7,1,2]  R67       -1
    z[7,1,2]  R1047     -1
    z[7,1,2]  R1048     1
    z[7,1,2]  R1057     1.5238769352436066e-01
    z[7,1,2]  R1058     3.8924619555473328e-01
    z[7,1,2]  R1059     1.3544920086860657e-01
    z[7,1,2]  R1060     6.2276750802993774e-01
    z[7,1,2]  R1061     -5.7281100749969482e-01
    z[7,1,2]  R1062     3.1706255674362183e-01
    z[7,1,2]  R1063     -7.3331922292709351e-01
    z[7,1,2]  R1064     2.8229501843452454e-01
    z[7,1,2]  R1065     2.0769460499286652e-01
    z[7,1,2]  R1066     -5.9686416387557983e-01
    z[7,1,2]  R1067     7.2961330413818359e-01
    z[7,1,2]  R1068     4.3422129750251770e-01
    z[7,1,2]  R1069     3.8158121705055237e-01
    z[7,1,2]  R1070     0.550506055355072
    z[7,1,2]  R1071     3.2392820715904236e-01
    z[7,1,2]  R1072     2.4571396410465240e-01
    z[7,1,2]  R1073     0.067622110247612
    z[7,1,2]  R1074     0.459238737821579
    z[7,1,2]  R1075     3.2472480088472366e-02
    z[7,1,2]  R1076     2.7156364917755127e-01
    z[7,1,2]  R1077     -1.8956419825553894e-01
    z[7,1,2]  R1078     -6.9618624448776245e-01
    z[7,1,2]  R1079     -3.2738870382308960e-01
    z[7,1,2]  R1080     -4.9386900663375854e-01
    z[7,1,2]  R1081     -5.8306747674942017e-01
    z[7,1,2]  R1082     1.5498754382133484e-01
    z[7,1,2]  R1083     -1.3371452689170837e-01
    z[7,1,2]  R1084     -3.7353730201721191e-01
    z[7,1,2]  R1085     -2.8236207365989685e-01
    z[7,1,2]  R1086     -5.8703833818435669e-01
    z[7,1,2]  R1087     -1.8302412331104279e-01
    z[7,1,2]  R1088     8.9372813701629639e-02
    z[7,1,2]  R1089     -1.2978021800518036e-01
    z[7,1,2]  R1090     6.9510176777839661e-02
    z[7,1,2]  R1091     5.3976005315780640e-01
    z[7,1,2]  R1092     -8.5104942321777344e-01
    z[7,1,2]  R1093     -7.3560386896133423e-01
    z[7,1,2]  R1094     -4.1516625881195068e-01
    z[7,1,2]  R1095     -2.0120188593864441e-01
    z[7,1,2]  R1096     -4.5631888508796692e-01
    z[7,1,2]  R1097     1.5428924560546875e-01
    z[7,1,2]  R1098     4.0962803363800049e-01
    z[7,1,2]  R1099     6.6589558124542236e-01
    z[7,1,2]  R1100     -5.7522392272949219e-01
    z[7,1,2]  R1101     -2.7774125337600708e-01
    z[7,1,2]  R1102     5.6136876344680786e-01
    z[7,1,2]  R1103     3.6103519797325134e-01
    z[7,1,2]  R1104     1.8868075311183929e-01
    z[7,1,2]  R1105     2.1593287587165833e-01
    z[7,1,2]  R1106     7.1879738569259644e-01
    z[7,1,2]  R1107     3.8259690999984741e-01
    z[7,1,2]  R1108     2.4863047897815704e-01
    z[7,1,2]  R1109     4.0550294518470764e-01
    z[7,1,2]  R1110     -9.4124749302864075e-02
    z[7,1,2]  R1111     -4.7052997350692749e-01
    z[7,1,2]  R1112     -0.661577045917511
    z[7,1,2]  R1113     -2.0283532142639160e-01
    z[7,1,2]  R1114     -3.4149882197380066e-01
    z[7,1,2]  R1115     -8.9774593710899353e-02
    z[7,1,2]  R1116     -7.1543413400650024e-01
    z[7,1,2]  R1117     -5.2829998731613159e-01
    z[7,1,2]  R1118     -5.0700902938842773e-01
    z[7,1,2]  R1119     -1.2854686379432678e-01
    z[7,1,2]  R1120     -5.9702497720718384e-01
    z[7,1,2]  R1121     6.1337524652481079e-01
    z[7,1,2]  R1122     -2.6337766647338867e-01
    z[7,1,2]  R1123     5.3891700506210327e-01
    z[7,1,2]  R1124     -4.6299663186073303e-01
    z[7,1,2]  R1125     -3.3626869320869446e-01
    z[7,1,2]  R1126     -5.5185207165777683e-03
    z[7,1,2]  R1127     1.2516488134860992e-01
    z[7,1,2]  R1128     -1.8550613522529602e-01
    z[7,1,2]  R1129     4.9989435821771622e-02
    z[7,1,2]  R1130     3.4611660242080688e-01
    z[7,1,2]  R1131     -5.7898926734924316e-01
    z[7,1,2]  R1132     -1.8837502598762512e-01
    z[7,1,2]  R1133     -1.5222257375717163e-01
    z[7,1,2]  R1134     -1.1982090771198273e-01
    z[7,1,2]  R1135     -4.3433573842048645e-01
    z[7,1,2]  R1136     -3.8566648960113525e-01
    z[7,1,2]  R1137     2.9167747497558594e-01
    z[7,1,2]  R1138     -5.5262643098831177e-01
    z[7,1,2]  R1139     3.9856532216072083e-01
    z[7,1,2]  R1140     -4.4477036595344543e-01
    z[7,1,2]  R1141     -0.545142650604248
    z[7,1,2]  R1142     0.0301351398229599
    z[7,1,2]  R1143     -7.3880887031555176e-01
    z[7,1,2]  R1144     -6.6751509904861450e-01
    z[7,1,2]  R1145     1.7958452925086021e-02
    z[7,1,2]  R1146     -3.0071580410003662e-01
    z[7,1,2]  R1147     2.2520966827869415e-01
    z[7,1,2]  R1148     3.2320278882980347e-01
    z[7,1,2]  R1149     4.7071447968482971e-01
    z[7,1,2]  R1150     -6.5022307634353638e-01
    z[7,1,2]  R1151     -6.3702452182769775e-01
    z[7,1,2]  R1152     7.2934284806251526e-02
    z[7,1,2]  R1153     2.8145051002502441e-01
    z[7,1,2]  R1154     2.4381391704082489e-01
    z[7,1,2]  R1155     -8.2089319825172424e-02
    z[7,1,3]  R14       1
    z[7,1,3]  R68       -1
    z[7,1,3]  R1049     -1
    z[7,1,3]  R1050     1
    z[7,1,3]  R1057     -1.9879573583602905e-01
    z[7,1,3]  R1058     -1.2019961327314377e-01
    z[7,1,3]  R1059     -2.1669751405715942e-01
    z[7,1,3]  R1060     -1.7680196464061737e-01
    z[7,1,3]  R1061     -1.1830183863639832e-01
    z[7,1,3]  R1062     -2.1421962976455688e-01
    z[7,1,3]  R1063     -1.0761692374944687e-01
    z[7,1,3]  R1064     1.9323322176933289e-01
    z[7,1,3]  R1065     2.0005673170089722e-01
    z[7,1,3]  R1066     3.9944455027580261e-01
    z[7,1,3]  R1067     2.5041863322257996e-01
    z[7,1,3]  R1068     2.5284075736999512e-01
    z[7,1,3]  R1069     7.8956015408039093e-02
    z[7,1,3]  R1070     3.5475313663482666e-01
    z[7,1,3]  R1071     4.1027444601058960e-01
    z[7,1,3]  R1072     3.6534574627876282e-01
    z[7,1,3]  R1073     -9.1493481397628784e-01
    z[7,1,3]  R1074     2.1414358913898468e-01
    z[7,1,3]  R1075     2.4445576965808868e-01
    z[7,1,3]  R1076     3.4286347031593323e-01
    z[7,1,3]  R1077     -6.6909611225128174e-01
    z[7,1,3]  R1078     -8.4517627954483032e-02
    z[7,1,3]  R1079     -5.9091800451278687e-01
    z[7,1,3]  R1080     -3.9055764675140381e-01
    z[7,1,3]  R1081     -1.2892629206180573e-01
    z[7,1,3]  R1082     -4.0681746602058411e-01
    z[7,1,3]  R1083     -7.3988062143325806e-01
    z[7,1,3]  R1084     -7.0957213640213013e-01
    z[7,1,3]  R1085     -5.8777654170989990e-01
    z[7,1,3]  R1086     1.9040267169475555e-01
    z[7,1,3]  R1087     -8.9693957567214966e-01
    z[7,1,3]  R1088     -9.2326998710632324e-01
    z[7,1,3]  R1089     -5.1264625042676926e-02
    z[7,1,3]  R1090     -2.4642907083034515e-01
    z[7,1,3]  R1091     -5.7452076673507690e-01
    z[7,1,3]  R1092     -3.1194803118705750e-01
    z[7,1,3]  R1093     4.3479931354522705e-01
    z[7,1,3]  R1094     3.0651673674583435e-01
    z[7,1,3]  R1095     -4.3567517399787903e-01
    z[7,1,3]  R1096     4.9107018113136292e-01
    z[7,1,3]  R1097     -1.9785149395465851e-01
    z[7,1,3]  R1098     -1.5579080581665039e-01
    z[7,1,3]  R1099     -1.2824720144271851e-01
    z[7,1,3]  R1100     -1.8338501453399658e-01
    z[7,1,3]  R1101     -2.9639992117881775e-01
    z[7,1,3]  R1102     -1.6545537114143372e-01
    z[7,1,3]  R1103     -8.5804708302021027e-02
    z[7,1,3]  R1104     -2.9832187294960022e-01
    z[7,1,3]  R1105     -1.2625852227210999e-01
    z[7,1,3]  R1106     3.0539923906326294e-01
    z[7,1,3]  R1107     7.6536345481872559e-01
    z[7,1,3]  R1108     4.9695274233818054e-01
    z[7,1,3]  R1109     5.2950328588485718e-01
    z[7,1,3]  R1110     4.5159395784139633e-02
    z[7,1,3]  R1111     8.6288101971149445e-02
    z[7,1,3]  R1112     -2.1833214163780212e-01
    z[7,1,3]  R1113     6.7773485183715820e-01
    z[7,1,3]  R1114     5.8339411020278931e-01
    z[7,1,3]  R1115     8.2833594083786011e-01
    z[7,1,3]  R1116     -4.2537021636962891e-01
    z[7,1,3]  R1117     -0.408914178609848
    z[7,1,3]  R1118     -6.0810461640357971e-02
    z[7,1,3]  R1119     -9.0807807445526123e-01
    z[7,1,3]  R1120     1.6254587471485138e-01
    z[7,1,3]  R1121     -1.5159854292869568e-01
    z[7,1,3]  R1122     -6.9932979345321655e-01
    z[7,1,3]  R1123     1.6053098440170288e-01
    z[7,1,3]  R1124     3.4772035479545593e-01
    z[7,1,3]  R1125     -4.2696991562843323e-01
    z[7,1,3]  R1126     -8.7268584966659546e-01
    z[7,1,3]  R1127     -5.4635971784591675e-01
    z[7,1,3]  R1128     -6.4791935682296753e-01
    z[7,1,3]  R1129     -7.7812254428863525e-01
    z[7,1,3]  R1130     2.4809615314006805e-01
    z[7,1,3]  R1131     5.4636709392070770e-02
    z[7,1,3]  R1132     -4.3005886673927307e-01
    z[7,1,3]  R1133     -4.3866130709648132e-01
    z[7,1,3]  R1134     -3.9875060319900513e-01
    z[7,1,3]  R1135     -3.0273789167404175e-01
    z[7,1,3]  R1136     -4.1669008135795593e-01
    z[7,1,3]  R1137     -8.8196210563182831e-02
    z[7,1,3]  R1138     -6.0438591241836548e-01
    z[7,1,3]  R1139     -5.9017026424407959e-01
    z[7,1,3]  R1140     -1.5177384018898010e-01
    z[7,1,3]  R1141     3.3042982220649719e-01
    z[7,1,3]  R1142     8.0193474888801575e-02
    z[7,1,3]  R1143     0.0891735851764679
    z[7,1,3]  R1144     2.8843116760253906e-01
    z[7,1,3]  R1145     6.1815810203552246e-01
    z[7,1,3]  R1146     -9.0811568498611450e-01
    z[7,1,3]  R1147     -4.9738240242004395e-01
    z[7,1,3]  R1148     -8.3319848775863647e-01
    z[7,1,3]  R1149     4.9404117465019226e-01
    z[7,1,3]  R1150     -3.2991480082273483e-02
    z[7,1,3]  R1151     3.7585198879241943e-01
    z[7,1,3]  R1152     -4.0448507666587830e-01
    z[7,1,3]  R1153     -7.5693726539611816e-02
    z[7,1,3]  R1154     2.9689380526542664e-01
    z[7,1,3]  R1155     5.2299493551254272e-01
    z[7,1,4]  R15       1
    z[7,1,4]  R69       -1
    z[7,1,4]  R1051     -1
    z[7,1,4]  R1052     1
    z[7,1,4]  R1057     2.8136044740676880e-01
    z[7,1,4]  R1058     1.3414669036865234e-01
    z[7,1,4]  R1059     6.0929656028747559e-01
    z[7,1,4]  R1060     4.6493580937385559e-01
    z[7,1,4]  R1061     5.9276384115219116e-01
    z[7,1,4]  R1062     5.8546477556228638e-01
    z[7,1,4]  R1063     -9.6167489886283875e-02
    z[7,1,4]  R1064     -1.0068996995687485e-01
    z[7,1,4]  R1065     -1.6605491936206818e-01
    z[7,1,4]  R1066     3.6492672562599182e-01
    z[7,1,4]  R1067     -2.4456101655960083e-01
    z[7,1,4]  R1068     -2.1529795229434967e-01
    z[7,1,4]  R1069     -2.6367521286010742e-01
    z[7,1,4]  R1070     2.7901515364646912e-01
    z[7,1,4]  R1071     2.8647467494010925e-01
    z[7,1,4]  R1072     9.8640955984592438e-02
    z[7,1,4]  R1073     -3.3423733711242676e-01
    z[7,1,4]  R1074     5.5307867005467415e-03
    z[7,1,4]  R1075     -2.2386403381824493e-01
    z[7,1,4]  R1076     -3.8595151901245117e-01
    z[7,1,4]  R1077     -1.9395154714584351e-01
    z[7,1,4]  R1078     -1.3204665482044220e-01
    z[7,1,4]  R1079     4.1910582780838013e-01
    z[7,1,4]  R1080     1.9031862914562225e-01
    z[7,1,4]  R1081     -2.3103572428226471e-01
    z[7,1,4]  R1082     7.7144846320152283e-02
    z[7,1,4]  R1083     0.0887860581278801
    z[7,1,4]  R1084     -3.5474222898483276e-01
    z[7,1,4]  R1085     -4.5493033528327942e-01
    z[7,1,4]  R1086     4.9308523535728455e-02
    z[7,1,4]  R1087     3.2211273908615112e-01
    z[7,1,4]  R1088     2.5527609977871180e-03
    z[7,1,4]  R1089     0.415828675031662
    z[7,1,4]  R1090     -2.0532572269439697e-01
    z[7,1,4]  R1091     1.3875405490398407e-01
    z[7,1,4]  R1092     -3.2913282513618469e-02
    z[7,1,4]  R1093     4.0149144828319550e-02
    z[7,1,4]  R1094     2.2124961018562317e-01
    z[7,1,4]  R1095     -5.4027330130338669e-02
    z[7,1,4]  R1096     3.3655592799186707e-01
    z[7,1,4]  R1097     2.8005328774452209e-01
    z[7,1,4]  R1098     3.1539127230644226e-01
    z[7,1,4]  R1099     1.8078483641147614e-01
    z[7,1,4]  R1100     3.1668260693550110e-01
    z[7,1,4]  R1101     1.5372152626514435e-01
    z[7,1,4]  R1102     -3.5441529750823975e-01
    z[7,1,4]  R1103     0.682155430316925
    z[7,1,4]  R1104     8.0553829669952393e-01
    z[7,1,4]  R1105     7.1015870571136475e-01
    z[7,1,4]  R1106     -2.3386125266551971e-01
    z[7,1,4]  R1107     -4.2920134961605072e-02
    z[7,1,4]  R1108     6.7264698445796967e-03
    z[7,1,4]  R1109     -1.3860683143138885e-01
    z[7,1,4]  R1110     -1.0556232929229736e-01
    z[7,1,4]  R1111     -0.180857852101326
    z[7,1,4]  R1112     -0.347945898771286
    z[7,1,4]  R1113     1.9008468091487885e-01
    z[7,1,4]  R1114     -5.6145143508911133e-01
    z[7,1,4]  R1115     -1.2967351078987122e-01
    z[7,1,4]  R1116     1.1638043820858002e-01
    z[7,1,4]  R1117     3.6474909633398056e-02
    z[7,1,4]  R1118     -2.7737969160079956e-01
    z[7,1,4]  R1119     1.9040282070636749e-01
    z[7,1,4]  R1120     -2.9372459650039673e-01
    z[7,1,4]  R1121     -6.5552002191543579e-01
    z[7,1,4]  R1122     6.1285290867090225e-02
    z[7,1,4]  R1123     -3.7403675913810730e-01
    z[7,1,4]  R1124     1.5211680531501770e-01
    z[7,1,4]  R1125     2.6128438115119934e-01
    z[7,1,4]  R1126     -0.0209683645516634
    z[7,1,4]  R1127     2.5459289550781250e-01
    z[7,1,4]  R1128     6.8388420343399048e-01
    z[7,1,4]  R1129     -2.5255185365676880e-01
    z[7,1,4]  R1130     -3.7624785304069519e-01
    z[7,1,4]  R1131     2.7798625826835632e-01
    z[7,1,4]  R1132     -1.2289223819971085e-01
    z[7,1,4]  R1133     -5.3070688247680664e-01
    z[7,1,4]  R1134     -4.8383176326751709e-01
    z[7,1,4]  R1135     4.1114774346351624e-01
    z[7,1,4]  R1136     1.1680650711059570e-01
    z[7,1,4]  R1137     7.0235341787338257e-02
    z[7,1,4]  R1138     -4.6366035938262939e-01
    z[7,1,4]  R1139     2.2281800210475922e-01
    z[7,1,4]  R1140     -2.2254188358783722e-01
    z[7,1,4]  R1141     -4.0633025765419006e-01
    z[7,1,4]  R1142     -8.1712412834167480e-01
    z[7,1,4]  R1143     -2.9364114999771118e-01
    z[7,1,4]  R1144     1.6318482160568237e-01
    z[7,1,4]  R1145     2.2752128541469574e-01
    z[7,1,4]  R1146     1.4992308802902699e-02
    z[7,1,4]  R1147     0.574512779712677
    z[7,1,4]  R1148     -1.1573029309511185e-01
    z[7,1,4]  R1149     6.6686391830444336e-02
    z[7,1,4]  R1150     -0.254208505153656
    z[7,1,4]  R1151     1.9960589706897736e-01
    z[7,1,4]  R1152     -0.208910271525383
    z[7,1,4]  R1153     -4.3405908346176147e-01
    z[7,1,4]  R1154     4.1917651891708374e-01
    z[7,1,4]  R1155     -7.3116861283779144e-02
    z[7,1,5]  R16       1
    z[7,1,5]  R70       -1
    z[7,1,5]  R1053     -1
    z[7,1,5]  R1054     1
    z[7,1,5]  R1057     1.2903597950935364e-01
    z[7,1,5]  R1058     5.0718921422958374e-01
    z[7,1,5]  R1059     4.9037474393844604e-01
    z[7,1,5]  R1060     -1.2133947759866714e-01
    z[7,1,5]  R1061     -4.3760299682617188e-02
    z[7,1,5]  R1062     1.1665125936269760e-01
    z[7,1,5]  R1063     -2.1996637806296349e-02
    z[7,1,5]  R1064     1.4449493587017059e-01
    z[7,1,5]  R1065     -1.3534571230411530e-01
    z[7,1,5]  R1066     1.2469103187322617e-01
    z[7,1,5]  R1067     4.2589064687490463e-02
    z[7,1,5]  R1068     4.6388205885887146e-01
    z[7,1,5]  R1069     6.5515274181962013e-03
    z[7,1,5]  R1070     -3.1412345170974731e-01
    z[7,1,5]  R1071     -1.1265028268098831e-01
    z[7,1,5]  R1072     1.6476555168628693e-01
    z[7,1,5]  R1073     -3.8684133440256119e-02
    z[7,1,5]  R1074     -0.51753830909729
    z[7,1,5]  R1075     -2.8312796354293823e-01
    z[7,1,5]  R1076     -7.5021870434284210e-02
    z[7,1,5]  R1077     -0.572472095489502
    z[7,1,5]  R1078     -2.5666135549545288e-01
    z[7,1,5]  R1079     -2.5014990568161011e-01
    z[7,1,5]  R1080     -3.4819102287292480e-01
    z[7,1,5]  R1081     -3.0022063851356506e-01
    z[7,1,5]  R1082     -7.7347451448440552e-01
    z[7,1,5]  R1083     -1.6917371749877930e-01
    z[7,1,5]  R1084     2.4217553436756134e-01
    z[7,1,5]  R1085     -5.9445660561323166e-02
    z[7,1,5]  R1086     -4.9349084496498108e-01
    z[7,1,5]  R1087     1.0130524635314941e-01
    z[7,1,5]  R1088     -3.2140168547630310e-01
    z[7,1,5]  R1089     -5.9102743864059448e-01
    z[7,1,5]  R1090     -5.9029066562652588e-01
    z[7,1,5]  R1091     4.5784175395965576e-01
    z[7,1,5]  R1092     -1.1757113784551620e-01
    z[7,1,5]  R1093     -4.3659603595733643e-01
    z[7,1,5]  R1094     -0.759149968624115
    z[7,1,5]  R1095     -3.9859518408775330e-02
    z[7,1,5]  R1096     -5.7088422775268555e-01
    z[7,1,5]  R1097     1.2996168434619904e-01
    z[7,1,5]  R1098     4.9831250309944153e-01
    z[7,1,5]  R1099     -5.2954863756895065e-02
    z[7,1,5]  R1100     -1.0397800803184509e-01
    z[7,1,5]  R1101     -4.7443735599517822e-01
    z[7,1,5]  R1102     4.0084591507911682e-01
    z[7,1,5]  R1103     2.3899297416210175e-01
    z[7,1,5]  R1104     -1.7053984105587006e-01
    z[7,1,5]  R1105     -9.2424347996711731e-02
    z[7,1,5]  R1106     6.7016161978244781e-02
    z[7,1,5]  R1107     1.2693777680397034e-01
    z[7,1,5]  R1108     -8.8410764932632446e-02
    z[7,1,5]  R1109     4.9413305521011353e-01
    z[7,1,5]  R1110     -5.4077520966529846e-02
    z[7,1,5]  R1111     -3.5688707232475281e-01
    z[7,1,5]  R1112     7.8935608267784119e-02
    z[7,1,5]  R1113     -0.186315655708313
    z[7,1,5]  R1114     -6.7505680024623871e-02
    z[7,1,5]  R1115     6.6189900040626526e-02
    z[7,1,5]  R1116     -3.7717631459236145e-01
    z[7,1,5]  R1117     -5.9734326601028442e-01
    z[7,1,5]  R1118     -4.7837734222412109e-01
    z[7,1,5]  R1119     2.5130003690719604e-01
    z[7,1,5]  R1120     -6.3161790370941162e-01
    z[7,1,5]  R1121     1.6878260672092438e-01
    z[7,1,5]  R1122     5.8353751897811890e-01
    z[7,1,5]  R1123     3.8660675287246704e-01
    z[7,1,5]  R1124     -0.318907767534256
    z[7,1,5]  R1125     -1.6402861475944519e-01
    z[7,1,5]  R1126     -1.2997676432132721e-01
    z[7,1,5]  R1127     -3.9555296301841736e-01
    z[7,1,5]  R1128     1.1939511448144913e-01
    z[7,1,5]  R1129     -1.0598129779100418e-01
    z[7,1,5]  R1130     0.0935024619102478
    z[7,1,5]  R1131     -5.0922483205795288e-01
    z[7,1,5]  R1132     -2.5957217812538147e-01
    z[7,1,5]  R1133     -3.4279155731201172e-01
    z[7,1,5]  R1134     -2.1769352257251740e-01
    z[7,1,5]  R1135     2.4725930392742157e-01
    z[7,1,5]  R1136     -5.9044855833053589e-01
    z[7,1,5]  R1137     3.7515202164649963e-01
    z[7,1,5]  R1138     -0.0705728530883789
    z[7,1,5]  R1139     6.1502200365066528e-01
    z[7,1,5]  R1140     -3.3472391963005066e-01
    z[7,1,5]  R1141     -3.5757660865783691e-01
    z[7,1,5]  R1142     -7.8355483710765839e-02
    z[7,1,5]  R1143     -1.3906839489936829e-01
    z[7,1,5]  R1144     -1.8571268767118454e-02
    z[7,1,5]  R1145     -2.0394992828369141e-01
    z[7,1,5]  R1146     0.0060595260001719
    z[7,1,5]  R1147     7.9848654568195343e-02
    z[7,1,5]  R1148     3.7020778656005859e-01
    z[7,1,5]  R1149     3.0023878812789917e-01
    z[7,1,5]  R1150     -3.0967068672180176e-01
    z[7,1,5]  R1151     -3.7857425212860107e-01
    z[7,1,5]  R1152     -5.5424129962921143e-01
    z[7,1,5]  R1153     5.4742813110351562e-01
    z[7,1,5]  R1154     -2.9570639133453369e-01
    z[7,1,5]  R1155     3.1599190831184387e-01
    z[7,1,6]  R17       1
    z[7,1,6]  R71       -1
    z[7,1,6]  R1055     -1
    z[7,1,6]  R1056     1
    z[7,1,6]  R1057     -3.5278104245662689e-02
    z[7,1,6]  R1058     2.0132671296596527e-01
    z[7,1,6]  R1059     -0.0667652115225792
    z[7,1,6]  R1060     1.7769466340541840e-01
    z[7,1,6]  R1061     1.0768654197454453e-01
    z[7,1,6]  R1062     2.9563727974891663e-01
    z[7,1,6]  R1063     2.0852752029895782e-01
    z[7,1,6]  R1064     -7.0347420871257782e-02
    z[7,1,6]  R1065     4.7084507346153259e-01
    z[7,1,6]  R1066     2.1488350629806519e-01
    z[7,1,6]  R1067     5.5983554571866989e-02
    z[7,1,6]  R1068     -1.7407430708408356e-01
    z[7,1,6]  R1069     -3.4601387381553650e-01
    z[7,1,6]  R1070     -1.5069159865379333e-01
    z[7,1,6]  R1071     -2.5914004445075989e-01
    z[7,1,6]  R1072     -4.2466285824775696e-01
    z[7,1,6]  R1073     -4.6498034149408340e-02
    z[7,1,6]  R1074     -1.0482472181320190e-01
    z[7,1,6]  R1075     -5.0177793949842453e-02
    z[7,1,6]  R1076     2.4532899260520935e-01
    z[7,1,6]  R1077     0.323185533285141
    z[7,1,6]  R1078     -4.7742825001478195e-02
    z[7,1,6]  R1079     -1.8472076952457428e-01
    z[7,1,6]  R1080     -1.7829626798629761e-01
    z[7,1,6]  R1081     3.0573625117540359e-02
    z[7,1,6]  R1082     -3.2567363232374191e-02
    z[7,1,6]  R1083     -3.5136780142784119e-01
    z[7,1,6]  R1084     1.8085611518472433e-03
    z[7,1,6]  R1085     -2.3121614754199982e-01
    z[7,1,6]  R1086     -9.1499179601669312e-02
    z[7,1,6]  R1087     1.0097808390855789e-01
    z[7,1,6]  R1088     -1.6042618453502655e-01
    z[7,1,6]  R1089     3.3555500209331512e-02
    z[7,1,6]  R1090     -1.1515476554632187e-01
    z[7,1,6]  R1091     1.7848303914070129e-01
    z[7,1,6]  R1092     -2.8546676039695740e-01
    z[7,1,6]  R1093     -2.5411024689674377e-01
    z[7,1,6]  R1094     2.4185892939567566e-01
    z[7,1,6]  R1095     3.9354795217514038e-01
    z[7,1,6]  R1096     -1.6337199509143829e-01
    z[7,1,6]  R1097     -4.1296545416116714e-02
    z[7,1,6]  R1098     4.7544579952955246e-02
    z[7,1,6]  R1099     -2.8484994173049927e-01
    z[7,1,6]  R1100     -3.4448447823524475e-01
    z[7,1,6]  R1101     -5.8732575178146362e-01
    z[7,1,6]  R1102     1.0995424352586269e-02
    z[7,1,6]  R1103     1.1395853757858276e-01
    z[7,1,6]  R1104     -3.8139519095420837e-01
    z[7,1,6]  R1105     7.5161732733249664e-02
    z[7,1,6]  R1106     9.8768718540668488e-02
    z[7,1,6]  R1107     -1.5962858498096466e-01
    z[7,1,6]  R1108     -3.5750970244407654e-01
    z[7,1,6]  R1109     -1.5360661782324314e-02
    z[7,1,6]  R1110     -1.5741893649101257e-01
    z[7,1,6]  R1111     3.2253009080886841e-01
    z[7,1,6]  R1112     3.8437563180923462e-01
    z[7,1,6]  R1113     -1.6234208643436432e-01
    z[7,1,6]  R1114     -1.6507243737578392e-02
    z[7,1,6]  R1115     8.9567065238952637e-02
    z[7,1,6]  R1116     3.1049272045493126e-02
    z[7,1,6]  R1117     1.2024573236703873e-01
    z[7,1,6]  R1118     -0.277940034866333
    z[7,1,6]  R1119     2.0571085810661316e-01
    z[7,1,6]  R1120     7.1777604520320892e-02
    z[7,1,6]  R1121     -1.4794050157070160e-01
    z[7,1,6]  R1122     -7.2795733809471130e-02
    z[7,1,6]  R1123     -3.8922619819641113e-01
    z[7,1,6]  R1124     -1.8607042729854584e-01
    z[7,1,6]  R1125     -1.2934499979019165e-01
    z[7,1,6]  R1126     8.4637450054287910e-03
    z[7,1,6]  R1127     1.3048601150512695e-01
    z[7,1,6]  R1128     5.3298264741897583e-02
    z[7,1,6]  R1129     -2.7908441424369812e-01
    z[7,1,6]  R1130     1.6596347093582153e-01
    z[7,1,6]  R1131     0.00876099057495594
    z[7,1,6]  R1132     3.9219805598258972e-01
    z[7,1,6]  R1133     2.2666966915130615e-01
    z[7,1,6]  R1134     5.0538641214370728e-01
    z[7,1,6]  R1135     4.1560640931129456e-01
    z[7,1,6]  R1136     2.2250089049339294e-01
    z[7,1,6]  R1137     4.8746901750564575e-01
    z[7,1,6]  R1138     3.5872368607670069e-03
    z[7,1,6]  R1139     0.087613046169281
    z[7,1,6]  R1140     -5.4974645376205444e-01
    z[7,1,6]  R1141     -2.0097108185291290e-01
    z[7,1,6]  R1142     -1.6633279621601105e-01
    z[7,1,6]  R1143     3.9147740602493286e-01
    z[7,1,6]  R1144     -2.4853512644767761e-01
    z[7,1,6]  R1145     -5.5437427014112473e-02
    z[7,1,6]  R1146     7.4375040829181671e-02
    z[7,1,6]  R1147     6.3531458377838135e-02
    z[7,1,6]  R1148     -6.5903551876544952e-02
    z[7,1,6]  R1149     -6.2070630490779877e-02
    z[7,1,6]  R1150     -9.2620790004730225e-02
    z[7,1,6]  R1151     -2.5661420822143555e-01
    z[7,1,6]  R1152     -2.8402399271726608e-02
    z[7,1,6]  R1153     -1.0774499922990799e-01
    z[7,1,6]  R1154     -0.587288498878479
    z[7,1,6]  R1155     2.1513158082962036e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1156     -1
    z[2,3,0]  R1157     1
    z[2,3,0]  R1170     -3.2776564359664917e-01
    z[2,3,0]  R1171     -1.8122953176498413e-01
    z[2,3,0]  R1172     0.0782022625207901
    z[2,3,0]  R1173     -3.8154255598783493e-02
    z[2,3,0]  R1174     -1.0823357105255127e-01
    z[2,3,0]  R1175     1.1593800783157349e-01
    z[2,3,0]  R1176     1.5558232367038727e-01
    z[2,3,0]  R1177     -5.0421273708343506e-01
    z[2,3,0]  R1178     5.5407893657684326e-01
    z[2,3,0]  R1179     -1.2754349410533905e-01
    z[2,3,0]  R1180     4.2848935723304749e-01
    z[2,3,0]  R1181     -6.9649821519851685e-01
    z[2,3,0]  R1182     -8.1040644645690918e-01
    z[2,3,0]  R1183     -1.0012060403823853e-01
    z[2,3,0]  R1184     -5.0157243013381958e-01
    z[2,3,0]  R1185     -4.1528832912445068e-01
    z[2,3,0]  R1186     -8.7722289562225342e-01
    z[2,3,0]  R1187     -5.3326344490051270e-01
    z[2,3,0]  R1188     -3.3016419410705566e-01
    z[2,3,0]  R1189     3.0442732572555542e-01
    z[2,3,0]  R1190     -1.5702560544013977e-01
    z[2,3,0]  R1191     -5.0300967693328857e-01
    z[2,3,0]  R1192     -5.6752872467041016e-01
    z[2,3,0]  R1193     -6.1493963003158569e-01
    z[2,3,0]  R1194     -4.1481819748878479e-01
    z[2,3,0]  R1195     -2.0261837542057037e-01
    z[2,3,0]  R1196     -6.9657880067825317e-01
    z[2,3,0]  R1197     -5.2908849716186523e-01
    z[2,3,0]  R1198     -2.1004769206047058e-01
    z[2,3,0]  R1199     -8.3767634630203247e-01
    z[2,3,0]  R1200     -6.4867216348648071e-01
    z[2,3,0]  R1201     -4.2403453588485718e-01
    z[2,3,0]  R1202     3.0908182263374329e-01
    z[2,3,0]  R1203     -2.7287423610687256e-02
    z[2,3,0]  R1204     3.7874868512153625e-01
    z[2,3,0]  R1205     5.4182535409927368e-01
    z[2,3,0]  R1206     4.1882076859474182e-01
    z[2,3,0]  R1207     7.0044904947280884e-01
    z[2,3,0]  R1208     4.9352419376373291e-01
    z[2,3,0]  R1209     4.3174853920936584e-01
    z[2,3,0]  R1210     -6.7483878135681152e-01
    z[2,3,0]  R1211     -5.6025809049606323e-01
    z[2,3,0]  R1212     -5.9989315271377563e-01
    z[2,3,0]  R1213     -1.0695355385541916e-01
    z[2,3,0]  R1214     0.602087140083313
    z[2,3,0]  R1215     1.4182625710964203e-01
    z[2,3,0]  R1216     6.2107789516448975e-01
    z[2,3,0]  R1217     5.8524739742279053e-01
    z[2,3,0]  R1218     3.9227432012557983e-01
    z[2,3,0]  R1219     9.2200249433517456e-02
    z[2,3,0]  R1220     -3.3049005270004272e-01
    z[2,3,0]  R1221     -4.3728652596473694e-01
    z[2,3,0]  R1222     -2.7133550494909286e-02
    z[2,3,0]  R1223     -1.9071012502536178e-03
    z[2,3,0]  R1224     1.7247703671455383e-01
    z[2,3,0]  R1225     2.4037280678749084e-01
    z[2,3,0]  R1226     3.6065945029258728e-01
    z[2,3,0]  R1227     4.0757986903190613e-01
    z[2,3,0]  R1228     0.410907119512558
    z[2,3,0]  R1229     4.0464967489242554e-01
    z[2,3,0]  R1230     -1.1964192241430283e-01
    z[2,3,0]  R1231     4.0206423401832581e-01
    z[2,3,0]  R1232     -1.3556101918220520e-01
    z[2,3,0]  R1233     5.1215697079896927e-02
    z[2,3,0]  R1234     3.4780604764819145e-03
    z[2,3,0]  R1235     -1.1641890555620193e-01
    z[2,3,0]  R1236     1.5033109486103058e-01
    z[2,3,0]  R1237     4.7395345568656921e-01
    z[2,3,0]  R1238     -1.1855874210596085e-01
    z[2,3,0]  R1239     6.9723552465438843e-01
    z[2,3,0]  R1240     -2.5846174359321594e-01
    z[2,3,0]  R1241     -2.6794302463531494e-01
    z[2,3,0]  R1242     -9.2754676938056946e-02
    z[2,3,0]  R1243     -0.0926201194524765
    z[2,3,0]  R1244     -6.0131609439849854e-01
    z[2,3,0]  R1245     -3.1854861974716187e-01
    z[2,3,0]  R1246     -2.8617480397224426e-01
    z[2,3,0]  R1247     -3.4148630499839783e-01
    z[2,3,0]  R1248     -1.9698794186115265e-01
    z[2,3,0]  R1249     6.1476562172174454e-02
    z[2,3,0]  R1250     -5.3763681650161743e-01
    z[2,3,0]  R1251     2.3490490019321442e-01
    z[2,3,0]  R1252     3.8144361227750778e-02
    z[2,3,0]  R1253     0.29140505194664
    z[2,3,0]  R1254     -4.8267990350723267e-01
    z[2,3,0]  R1255     -1.6096152365207672e-01
    z[2,3,0]  R1256     -9.0267103910446167e-01
    z[2,3,0]  R1257     -8.6181628704071045e-01
    z[2,3,0]  R1258     -8.6449366807937622e-01
    z[2,3,0]  R1259     -8.3858233690261841e-01
    z[2,3,0]  R1260     -0.0920419692993164
    z[2,3,0]  R1261     -5.5750578641891479e-01
    z[2,3,0]  R1262     4.5923680067062378e-02
    z[2,3,0]  R1263     6.3780355453491211e-01
    z[2,3,0]  R1264     3.5756379365921021e-01
    z[2,3,0]  R1265     -4.3255165219306946e-01
    z[2,3,0]  R1266     6.6954243183135986e-01
    z[2,3,0]  R1267     -4.8768940567970276e-01
    z[2,3,0]  R1268     -2.2892622649669647e-01
    z[2,3,0]  R1269     -5.1787346601486206e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1158     -1
    z[2,3,1]  R1159     1
    z[2,3,1]  R1170     1.3667623698711395e-01
    z[2,3,1]  R1171     -6.8870939314365387e-02
    z[2,3,1]  R1172     -7.5835567712783813e-01
    z[2,3,1]  R1173     -4.3164405971765518e-02
    z[2,3,1]  R1174     -3.5222802311182022e-02
    z[2,3,1]  R1175     -6.3071471452713013e-01
    z[2,3,1]  R1176     -6.2627446651458740e-01
    z[2,3,1]  R1177     -3.1206080317497253e-01
    z[2,3,1]  R1178     -6.4502626657485962e-01
    z[2,3,1]  R1179     1.3340739905834198e-01
    z[2,3,1]  R1180     -5.7495719194412231e-01
    z[2,3,1]  R1181     1.7622421681880951e-01
    z[2,3,1]  R1182     1.8245464190840721e-02
    z[2,3,1]  R1183     -7.1773201227188110e-01
    z[2,3,1]  R1184     7.1016073226928711e-01
    z[2,3,1]  R1185     6.9762754440307617e-01
    z[2,3,1]  R1186     2.7729269862174988e-01
    z[2,3,1]  R1187     7.4746048450469971e-01
    z[2,3,1]  R1188     5.2432936429977417e-01
    z[2,3,1]  R1189     6.6270820796489716e-02
    z[2,3,1]  R1190     -3.7990295886993408e-01
    z[2,3,1]  R1191     5.6112813949584961e-01
    z[2,3,1]  R1192     -2.9780879616737366e-01
    z[2,3,1]  R1193     -0.264649361371994
    z[2,3,1]  R1194     -6.2970317900180817e-02
    z[2,3,1]  R1195     -7.4537402391433716e-01
    z[2,3,1]  R1196     -1.3572390377521515e-01
    z[2,3,1]  R1197     3.1126219034194946e-01
    z[2,3,1]  R1198     5.7729268074035645e-01
    z[2,3,1]  R1199     1.5036055445671082e-01
    z[2,3,1]  R1200     4.3710783123970032e-01
    z[2,3,1]  R1201     0.510776162147522
    z[2,3,1]  R1202     1.7163111269474030e-01
    z[2,3,1]  R1203     1.1031579971313477e-01
    z[2,3,1]  R1204     -0.258175253868103
    z[2,3,1]  R1205     -1.8876637518405914e-01
    z[2,3,1]  R1206     -6.7064231634140015e-01
    z[2,3,1]  R1207     1.7958882451057434e-01
    z[2,3,1]  R1208     2.3338532447814941e-01
    z[2,3,1]  R1209     8.8805359601974487e-01
    z[2,3,1]  R1210     2.4562311172485352e-01
    z[2,3,1]  R1211     3.8305193185806274e-01
    z[2,3,1]  R1212     5.1997935771942139e-01
    z[2,3,1]  R1213     4.0128874778747559e-01
    z[2,3,1]  R1214     -2.8923526406288147e-01
    z[2,3,1]  R1215     1.2952621909789741e-04
    z[2,3,1]  R1216     -0.165132075548172
    z[2,3,1]  R1217     0.0938212126493454
    z[2,3,1]  R1218     -6.4189112186431885e-01
    z[2,3,1]  R1219     2.4857778847217560e-01
    z[2,3,1]  R1220     1.9468443095684052e-01
    z[2,3,1]  R1221     3.9200019836425781e-01
    z[2,3,1]  R1222     -7.1944159269332886e-01
    z[2,3,1]  R1223     -7.7920407056808472e-01
    z[2,3,1]  R1224     4.0922917425632477e-02
    z[2,3,1]  R1225     -2.2571529448032379e-01
    z[2,3,1]  R1226     9.0154004096984863e-01
    z[2,3,1]  R1227     8.3971405029296875e-01
    z[2,3,1]  R1228     3.5176548361778259e-01
    z[2,3,1]  R1229     2.1756376326084137e-01
    z[2,3,1]  R1230     2.2257371246814728e-01
    z[2,3,1]  R1231     1.3655059039592743e-01
    z[2,3,1]  R1232     1.3799153268337250e-01
    z[2,3,1]  R1233     -1.4160220511257648e-02
    z[2,3,1]  R1234     2.2218354046344757e-01
    z[2,3,1]  R1235     6.1632741242647171e-02
    z[2,3,1]  R1236     2.0420733094215393e-01
    z[2,3,1]  R1237     -5.2433669567108154e-01
    z[2,3,1]  R1238     -8.0431565642356873e-02
    z[2,3,1]  R1239     -5.4815441370010376e-01
    z[2,3,1]  R1240     8.6236643791198730e-01
    z[2,3,1]  R1241     8.9285075664520264e-01
    z[2,3,1]  R1242     7.2662174701690674e-01
    z[2,3,1]  R1243     4.3325155973434448e-01
    z[2,3,1]  R1244     6.2199360132217407e-01
    z[2,3,1]  R1245     1.0795595496892929e-01
    z[2,3,1]  R1246     1.4799709618091583e-01
    z[2,3,1]  R1247     1.3905423879623413e-01
    z[2,3,1]  R1248     7.8896120190620422e-02
    z[2,3,1]  R1249     6.1751686036586761e-02
    z[2,3,1]  R1250     2.0509964227676392e-01
    z[2,3,1]  R1251     -6.4890630543231964e-02
    z[2,3,1]  R1252     2.3985694348812103e-01
    z[2,3,1]  R1253     2.2835461795330048e-01
    z[2,3,1]  R1254     -5.0408226251602173e-01
    z[2,3,1]  R1255     3.2518602907657623e-02
    z[2,3,1]  R1256     -2.5041484832763672e-01
    z[2,3,1]  R1257     -2.2475172579288483e-01
    z[2,3,1]  R1258     -1.8111494183540344e-01
    z[2,3,1]  R1259     -2.7215388417243958e-01
    z[2,3,1]  R1260     9.5345407724380493e-01
    z[2,3,1]  R1261     7.3015928268432617e-01
    z[2,3,1]  R1262     -1.1836803704500198e-01
    z[2,3,1]  R1263     2.0745410025119781e-01
    z[2,3,1]  R1264     1.6270010173320770e-01
    z[2,3,1]  R1265     -6.2895172834396362e-01
    z[2,3,1]  R1266     3.3519536256790161e-01
    z[2,3,1]  R1267     -2.7930495142936707e-01
    z[2,3,1]  R1268     -5.5695421993732452e-02
    z[2,3,1]  R1269     -5.0767141580581665e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1160     -1
    z[2,3,2]  R1161     1
    z[2,3,2]  R1170     3.9351809024810791e-01
    z[2,3,2]  R1171     3.7518355250358582e-01
    z[2,3,2]  R1172     -0.393670916557312
    z[2,3,2]  R1173     7.3147565126419067e-01
    z[2,3,2]  R1174     7.9934698343276978e-01
    z[2,3,2]  R1175     -4.9697494506835938e-01
    z[2,3,2]  R1176     -7.4237972497940063e-01
    z[2,3,2]  R1177     -6.0311222076416016e-01
    z[2,3,2]  R1178     -1.4511504769325256e-01
    z[2,3,2]  R1179     -2.1574316546320915e-02
    z[2,3,2]  R1180     1.5001340769231319e-02
    z[2,3,2]  R1181     1.1816588789224625e-01
    z[2,3,2]  R1182     3.0645513907074928e-02
    z[2,3,2]  R1183     4.0301901102066040e-01
    z[2,3,2]  R1184     -0.204465851187706
    z[2,3,2]  R1185     2.9491984844207764e-01
    z[2,3,2]  R1186     -2.9875391721725464e-01
    z[2,3,2]  R1187     8.0763585865497589e-02
    z[2,3,2]  R1188     4.5759817957878113e-01
    z[2,3,2]  R1189     -0.422170490026474
    z[2,3,2]  R1190     -0.523331880569458
    z[2,3,2]  R1191     0.362429141998291
    z[2,3,2]  R1192     2.7793258428573608e-01
    z[2,3,2]  R1193     5.4511779546737671e-01
    z[2,3,2]  R1194     4.4897815585136414e-01
    z[2,3,2]  R1195     5.0363477319478989e-02
    z[2,3,2]  R1196     1.6044487059116364e-01
    z[2,3,2]  R1197     1.4809851348400116e-01
    z[2,3,2]  R1198     7.5230455398559570e-01
    z[2,3,2]  R1199     4.0379768610000610e-01
    z[2,3,2]  R1200     7.1681782603263855e-02
    z[2,3,2]  R1201     5.9995889663696289e-01
    z[2,3,2]  R1202     -4.1300213336944580e-01
    z[2,3,2]  R1203     -0.5770223736763
    z[2,3,2]  R1204     -3.4725788235664368e-01
    z[2,3,2]  R1205     -1.4485648274421692e-01
    z[2,3,2]  R1206     -0.0309580210596323
    z[2,3,2]  R1207     -4.0920473635196686e-02
    z[2,3,2]  R1208     -2.1138539910316467e-01
    z[2,3,2]  R1209     1.8279202282428741e-02
    z[2,3,2]  R1210     5.6813371181488037e-01
    z[2,3,2]  R1211     2.4197937548160553e-01
    z[2,3,2]  R1212     -2.0100402832031250e-01
    z[2,3,2]  R1213     1.4997847378253937e-01
    z[2,3,2]  R1214     -4.4935917854309082e-01
    z[2,3,2]  R1215     -0.46416175365448
    z[2,3,2]  R1216     -5.9348784387111664e-02
    z[2,3,2]  R1217     1.3861194252967834e-01
    z[2,3,2]  R1218     -0.0834183618426323
    z[2,3,2]  R1219     -3.4910953044891357e-01
    z[2,3,2]  R1220     5.9702861309051514e-01
    z[2,3,2]  R1221     1.6165429353713989e-01
    z[2,3,2]  R1222     -1.9677430391311646e-02
    z[2,3,2]  R1223     -2.2065903246402740e-01
    z[2,3,2]  R1224     1.6770800948143005e-01
    z[2,3,2]  R1225     -2.9879701137542725e-01
    z[2,3,2]  R1226     -1.4886486530303955e-01
    z[2,3,2]  R1227     -1.8530897796154022e-01
    z[2,3,2]  R1228     -4.6247458457946777e-01
    z[2,3,2]  R1229     -4.2749953269958496e-01
    z[2,3,2]  R1230     1.6007901728153229e-01
    z[2,3,2]  R1231     5.3326040506362915e-01
    z[2,3,2]  R1232     5.4453080892562866e-01
    z[2,3,2]  R1233     1.6188374161720276e-01
    z[2,3,2]  R1234     7.3928517103195190e-01
    z[2,3,2]  R1235     3.2165729999542236e-01
    z[2,3,2]  R1236     5.5308485031127930e-01
    z[2,3,2]  R1237     -4.5288002490997314e-01
    z[2,3,2]  R1238     6.9390898942947388e-01
    z[2,3,2]  R1239     -3.5546028614044189e-01
    z[2,3,2]  R1240     -3.0676954984664917e-01
    z[2,3,2]  R1241     -0.0371239148080349
    z[2,3,2]  R1242     -1.3091565109789371e-02
    z[2,3,2]  R1243     -4.9499917030334473e-01
    z[2,3,2]  R1244     -0.222425177693367
    z[2,3,2]  R1245     -6.6375064849853516e-01
    z[2,3,2]  R1246     -4.0637367963790894e-01
    z[2,3,2]  R1247     -0.684245228767395
    z[2,3,2]  R1248     -9.0016961097717285e-01
    z[2,3,2]  R1249     -1.3463929295539856e-01
    z[2,3,2]  R1250     1.8626801669597626e-01
    z[2,3,2]  R1251     -6.9084298610687256e-01
    z[2,3,2]  R1252     -6.0531413555145264e-01
    z[2,3,2]  R1253     -8.0756264925003052e-01
    z[2,3,2]  R1254     -4.5582181215286255e-01
    z[2,3,2]  R1255     -3.7148183584213257e-01
    z[2,3,2]  R1256     -6.4220331609249115e-02
    z[2,3,2]  R1257     1.9715829193592072e-01
    z[2,3,2]  R1258     -5.4146878421306610e-02
    z[2,3,2]  R1259     -2.3206777870655060e-02
    z[2,3,2]  R1260     -2.2958593070507050e-01
    z[2,3,2]  R1261     1.5322811901569366e-01
    z[2,3,2]  R1262     -9.5299792289733887e-01
    z[2,3,2]  R1263     -0.603747546672821
    z[2,3,2]  R1264     -8.0380862951278687e-01
    z[2,3,2]  R1265     -4.9176487326622009e-01
    z[2,3,2]  R1266     7.6304391026496887e-02
    z[2,3,2]  R1267     -0.568027675151825
    z[2,3,2]  R1268     -3.4215328097343445e-01
    z[2,3,2]  R1269     -4.1428482532501221e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1162     -1
    z[2,3,3]  R1163     1
    z[2,3,3]  R1170     6.6688269376754761e-01
    z[2,3,3]  R1171     5.1572436094284058e-01
    z[2,3,3]  R1172     -0.0335572175681591
    z[2,3,3]  R1173     2.5846010446548462e-01
    z[2,3,3]  R1174     3.7230160832405090e-01
    z[2,3,3]  R1175     9.4167873263359070e-02
    z[2,3,3]  R1176     1.1200413852930069e-01
    z[2,3,3]  R1177     -2.5182047486305237e-01
    z[2,3,3]  R1178     -1.4875121414661407e-02
    z[2,3,3]  R1179     8.9829826354980469e-01
    z[2,3,3]  R1180     -5.8477652072906494e-01
    z[2,3,3]  R1181     3.4625104069709778e-01
    z[2,3,3]  R1182     2.9363808035850525e-01
    z[2,3,3]  R1183     -0.509032666683197
    z[2,3,3]  R1184     3.5776901245117188e-01
    z[2,3,3]  R1185     -8.1725783646106720e-02
    z[2,3,3]  R1186     1.5989720821380615e-01
    z[2,3,3]  R1187     4.3401163071393967e-02
    z[2,3,3]  R1188     2.2026045620441437e-01
    z[2,3,3]  R1189     -6.7249870300292969e-01
    z[2,3,3]  R1190     -6.6445702314376831e-01
    z[2,3,3]  R1191     2.9607766866683960e-01
    z[2,3,3]  R1192     6.4727288484573364e-01
    z[2,3,3]  R1193     3.8072162866592407e-01
    z[2,3,3]  R1194     3.6636695265769958e-01
    z[2,3,3]  R1195     -3.3809766173362732e-01
    z[2,3,3]  R1196     2.7824339270591736e-01
    z[2,3,3]  R1197     1.0880557447671890e-01
    z[2,3,3]  R1198     1.6239469870924950e-02
    z[2,3,3]  R1199     -1.1333606392145157e-01
    z[2,3,3]  R1200     3.5330617427825928e-01
    z[2,3,3]  R1201     2.8760345652699471e-02
    z[2,3,3]  R1202     7.1464496850967407e-01
    z[2,3,3]  R1203     7.4313563108444214e-01
    z[2,3,3]  R1204     6.5993690490722656e-01
    z[2,3,3]  R1205     7.3723417520523071e-01
    z[2,3,3]  R1206     5.7594460248947144e-01
    z[2,3,3]  R1207     3.9901995658874512e-01
    z[2,3,3]  R1208     2.5344261527061462e-01
    z[2,3,3]  R1209     -7.5182631611824036e-02
    z[2,3,3]  R1210     3.6799827218055725e-01
    z[2,3,3]  R1211     2.8462353348731995e-01
    z[2,3,3]  R1212     4.3726623058319092e-01
    z[2,3,3]  R1213     8.8551706075668335e-01
    z[2,3,3]  R1214     -3.9345484972000122e-01
    z[2,3,3]  R1215     0.773955762386322
    z[2,3,3]  R1216     5.0759112834930420e-01
    z[2,3,3]  R1217     3.9197233319282532e-01
    z[2,3,3]  R1218     0.642471969127655
    z[2,3,3]  R1219     1.5008336305618286e-01
    z[2,3,3]  R1220     4.8011535406112671e-01
    z[2,3,3]  R1221     2.3251669108867645e-01
    z[2,3,3]  R1222     -1.5396174788475037e-01
    z[2,3,3]  R1223     -1.6268764436244965e-01
    z[2,3,3]  R1224     3.4525668621063232e-01
    z[2,3,3]  R1225     0.374606728553772
    z[2,3,3]  R1226     -1.6411715745925903e-01
    z[2,3,3]  R1227     9.1871835291385651e-02
    z[2,3,3]  R1228     6.4905665814876556e-02
    z[2,3,3]  R1229     1.3168838620185852e-01
    z[2,3,3]  R1230     9.0734344720840454e-01
    z[2,3,3]  R1231     6.0657733678817749e-01
    z[2,3,3]  R1232     7.1679770946502686e-01
    z[2,3,3]  R1233     9.0983533859252930e-01
    z[2,3,3]  R1234     0.408944696187973
    z[2,3,3]  R1235     8.0546975135803223e-01
    z[2,3,3]  R1236     2.9149407148361206e-01
    z[2,3,3]  R1237     -2.0121458172798157e-01
    z[2,3,3]  R1238     1.2604017555713654e-01
    z[2,3,3]  R1239     -9.3929208815097809e-02
    z[2,3,3]  R1240     1.5068401396274567e-01
    z[2,3,3]  R1241     -2.0425774157047272e-01
    z[2,3,3]  R1242     1.6447030007839203e-01
    z[2,3,3]  R1243     -6.1712962388992310e-01
    z[2,3,3]  R1244     -6.0796007513999939e-02
    z[2,3,3]  R1245     -5.2693754434585571e-01
    z[2,3,3]  R1246     -4.2322179675102234e-01
    z[2,3,3]  R1247     -2.7854594588279724e-01
    z[2,3,3]  R1248     -2.9469951987266541e-01
    z[2,3,3]  R1249     -3.3626815676689148e-01
    z[2,3,3]  R1250     4.0921539068222046e-01
    z[2,3,3]  R1251     -2.5749981403350830e-01
    z[2,3,3]  R1252     -3.5923480987548828e-01
    z[2,3,3]  R1253     -1.7536112666130066e-01
    z[2,3,3]  R1254     -1.9739560782909393e-01
    z[2,3,3]  R1255     -5.6692975759506226e-01
    z[2,3,3]  R1256     -2.6862585544586182e-01
    z[2,3,3]  R1257     -2.1962922811508179e-01
    z[2,3,3]  R1258     -1.7073485255241394e-01
    z[2,3,3]  R1259     -2.5808918476104736e-01
    z[2,3,3]  R1260     1.5992234647274017e-01
    z[2,3,3]  R1261     1.6902923583984375e-01
    z[2,3,3]  R1262     -2.3952773213386536e-01
    z[2,3,3]  R1263     -3.7652522325515747e-01
    z[2,3,3]  R1264     -2.0028272271156311e-01
    z[2,3,3]  R1265     -2.7765011787414551e-01
    z[2,3,3]  R1266     -4.0416863560676575e-01
    z[2,3,3]  R1267     -3.9246571063995361e-01
    z[2,3,3]  R1268     -0.846693754196167
    z[2,3,3]  R1269     -3.2565972208976746e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1164     -1
    z[2,3,4]  R1165     1
    z[2,3,4]  R1170     -2.3895879089832306e-01
    z[2,3,4]  R1171     -4.7157695889472961e-01
    z[2,3,4]  R1172     -3.7143155932426453e-01
    z[2,3,4]  R1173     -5.8237057924270630e-01
    z[2,3,4]  R1174     4.2662656307220459e-01
    z[2,3,4]  R1175     -3.4332302212715149e-01
    z[2,3,4]  R1176     -1.3079759478569031e-01
    z[2,3,4]  R1177     -6.1369098722934723e-02
    z[2,3,4]  R1178     -1.6491885483264923e-01
    z[2,3,4]  R1179     3.5114273428916931e-01
    z[2,3,4]  R1180     -1.4118352532386780e-01
    z[2,3,4]  R1181     3.3173173666000366e-01
    z[2,3,4]  R1182     -1.0776351392269135e-01
    z[2,3,4]  R1183     -1.4837658405303955e-01
    z[2,3,4]  R1184     -3.0603675171732903e-02
    z[2,3,4]  R1185     -4.1560694575309753e-01
    z[2,3,4]  R1186     -0.0971241444349289
    z[2,3,4]  R1187     2.3729506134986877e-01
    z[2,3,4]  R1188     3.9734295010566711e-01
    z[2,3,4]  R1189     -1.9221581518650055e-01
    z[2,3,4]  R1190     -3.3902657032012939e-01
    z[2,3,4]  R1191     2.2356674075126648e-01
    z[2,3,4]  R1192     -1.6046515107154846e-01
    z[2,3,4]  R1193     2.5032532215118408e-01
    z[2,3,4]  R1194     -5.6066513061523438e-01
    z[2,3,4]  R1195     -2.8734448552131653e-01
    z[2,3,4]  R1196     -4.5655864477157593e-01
    z[2,3,4]  R1197     -5.9938418865203857e-01
    z[2,3,4]  R1198     -5.5443480610847473e-02
    z[2,3,4]  R1199     -3.0573008116334677e-03
    z[2,3,4]  R1200     2.4033010005950928e-01
    z[2,3,4]  R1201     -2.1824173629283905e-01
    z[2,3,4]  R1202     -2.3332582414150238e-01
    z[2,3,4]  R1203     -2.1850545704364777e-01
    z[2,3,4]  R1204     -3.8703937083482742e-02
    z[2,3,4]  R1205     4.0596637874841690e-02
    z[2,3,4]  R1206     1.8956919014453888e-01
    z[2,3,4]  R1207     -2.4005274474620819e-01
    z[2,3,4]  R1208     -8.1402897834777832e-02
    z[2,3,4]  R1209     1.0504613071680069e-01
    z[2,3,4]  R1210     -7.7836655080318451e-02
    z[2,3,4]  R1211     -0.404949426651001
    z[2,3,4]  R1212     -2.4935327470302582e-01
    z[2,3,4]  R1213     5.4351929575204849e-02
    z[2,3,4]  R1214     3.2880973815917969e-01
    z[2,3,4]  R1215     -2.1899476647377014e-01
    z[2,3,4]  R1216     -2.7377369999885559e-01
    z[2,3,4]  R1217     -1.4054611325263977e-01
    z[2,3,4]  R1218     7.4891060590744019e-02
    z[2,3,4]  R1219     -2.6861688494682312e-01
    z[2,3,4]  R1220     1.3103212416172028e-01
    z[2,3,4]  R1221     -6.5347111225128174e-01
    z[2,3,4]  R1222     3.8102969527244568e-01
    z[2,3,4]  R1223     3.8656479120254517e-01
    z[2,3,4]  R1224     -9.0547271072864532e-02
    z[2,3,4]  R1225     -1.6460482776165009e-01
    z[2,3,4]  R1226     -4.8961769789457321e-04
    z[2,3,4]  R1227     -1.9483752548694611e-01
    z[2,3,4]  R1228     -0.689633846282959
    z[2,3,4]  R1229     -5.9421205520629883e-01
    z[2,3,4]  R1230     2.1208053454756737e-02
    z[2,3,4]  R1231     -0.158487930893898
    z[2,3,4]  R1232     0.0169528815895319
    z[2,3,4]  R1233     -3.4378603100776672e-01
    z[2,3,4]  R1234     -1.3737997412681580e-01
    z[2,3,4]  R1235     -2.7875187993049622e-01
    z[2,3,4]  R1236     9.3737430870532990e-03
    z[2,3,4]  R1237     -1.0268484055995941e-01
    z[2,3,4]  R1238     2.1089982986450195e-01
    z[2,3,4]  R1239     -1.3674362003803253e-01
    z[2,3,4]  R1240     8.0831823870539665e-03
    z[2,3,4]  R1241     2.1813374757766724e-01
    z[2,3,4]  R1242     -1.1247310787439346e-01
    z[2,3,4]  R1243     1.9123336672782898e-01
    z[2,3,4]  R1244     1.1492103338241577e-01
    z[2,3,4]  R1245     2.1364960074424744e-01
    z[2,3,4]  R1246     0.0580105260014534
    z[2,3,4]  R1247     4.8082344233989716e-02
    z[2,3,4]  R1248     5.2392229437828064e-02
    z[2,3,4]  R1249     -4.8945634625852108e-03
    z[2,3,4]  R1250     3.6185383796691895e-02
    z[2,3,4]  R1251     1.1271552741527557e-01
    z[2,3,4]  R1252     -5.3692040964961052e-03
    z[2,3,4]  R1253     1.4080798253417015e-02
    z[2,3,4]  R1254     -3.4365782141685486e-01
    z[2,3,4]  R1255     -6.8464004993438721e-01
    z[2,3,4]  R1256     1.7493329942226410e-01
    z[2,3,4]  R1257     -2.7211913466453552e-01
    z[2,3,4]  R1258     -3.3249381184577942e-01
    z[2,3,4]  R1259     -1.3458943367004395e-01
    z[2,3,4]  R1260     1.1815481819212437e-02
    z[2,3,4]  R1261     3.0346587300300598e-02
    z[2,3,4]  R1262     -1.9262244924902916e-02
    z[2,3,4]  R1263     8.2460500299930573e-02
    z[2,3,4]  R1264     -0.0631580650806427
    z[2,3,4]  R1265     2.7730926871299744e-02
    z[2,3,4]  R1266     2.4314887821674347e-02
    z[2,3,4]  R1267     -3.7103638052940369e-01
    z[2,3,4]  R1268     -0.279972106218338
    z[2,3,4]  R1269     -4.1296628117561340e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1166     -1
    z[2,3,5]  R1167     1
    z[2,3,5]  R1170     -2.4737168103456497e-02
    z[2,3,5]  R1171     5.7684624195098877e-01
    z[2,3,5]  R1172     0.331180602312088
    z[2,3,5]  R1173     2.2983746230602264e-01
    z[2,3,5]  R1174     -1.2704163789749146e-01
    z[2,3,5]  R1175     -1.1993834376335144e-01
    z[2,3,5]  R1176     -3.6350786685943604e-02
    z[2,3,5]  R1177     7.7492587268352509e-02
    z[2,3,5]  R1178     -1.1959101259708405e-01
    z[2,3,5]  R1179     -6.9265522062778473e-02
    z[2,3,5]  R1180     -1.3553163409233093e-01
    z[2,3,5]  R1181     -3.1456491351127625e-01
    z[2,3,5]  R1182     2.5362795591354370e-01
    z[2,3,5]  R1183     -0.0747024267911911
    z[2,3,5]  R1184     1.3659586012363434e-01
    z[2,3,5]  R1185     9.5757313072681427e-02
    z[2,3,5]  R1186     -1.7079490423202515e-01
    z[2,3,5]  R1187     -7.5730629265308380e-02
    z[2,3,5]  R1188     -4.2192158102989197e-01
    z[2,3,5]  R1189     3.4134829044342041e-01
    z[2,3,5]  R1190     2.6010846719145775e-02
    z[2,3,5]  R1191     1.0972206294536591e-01
    z[2,3,5]  R1192     2.2955326735973358e-01
    z[2,3,5]  R1193     -1.1781092733144760e-01
    z[2,3,5]  R1194     -2.6004803180694580e-01
    z[2,3,5]  R1195     -2.0570079982280731e-01
    z[2,3,5]  R1196     -4.2971235513687134e-01
    z[2,3,5]  R1197     4.7969031333923340e-01
    z[2,3,5]  R1198     8.0762747675180435e-03
    z[2,3,5]  R1199     -2.8292128443717957e-01
    z[2,3,5]  R1200     -4.2411741614341736e-01
    z[2,3,5]  R1201     3.6013630032539368e-01
    z[2,3,5]  R1202     3.7317776679992676e-01
    z[2,3,5]  R1203     2.3234508931636810e-01
    z[2,3,5]  R1204     3.9454281330108643e-01
    z[2,3,5]  R1205     3.0197301506996155e-01
    z[2,3,5]  R1206     4.3862808495759964e-02
    z[2,3,5]  R1207     5.0850385427474976e-01
    z[2,3,5]  R1208     6.0775619745254517e-01
    z[2,3,5]  R1209     8.8746301829814911e-02
    z[2,3,5]  R1210     1.2499637901782990e-01
    z[2,3,5]  R1211     -4.8106333613395691e-01
    z[2,3,5]  R1212     -7.4209660291671753e-02
    z[2,3,5]  R1213     1.3393706083297729e-01
    z[2,3,5]  R1214     -9.5786139369010925e-02
    z[2,3,5]  R1215     3.3809685707092285e-01
    z[2,3,5]  R1216     5.0066936016082764e-01
    z[2,3,5]  R1217     6.2086051702499390e-01
    z[2,3,5]  R1218     9.3482971191406250e-02
    z[2,3,5]  R1219     6.6434174776077271e-01
    z[2,3,5]  R1220     -3.0788388848304749e-01
    z[2,3,5]  R1221     2.0122538506984711e-01
    z[2,3,5]  R1222     -1.6681909561157227e-02
    z[2,3,5]  R1223     -3.8226428627967834e-01
    z[2,3,5]  R1224     6.9038450717926025e-01
    z[2,3,5]  R1225     6.1444973945617676e-01
    z[2,3,5]  R1226     6.2699727714061737e-02
    z[2,3,5]  R1227     -1.7816412448883057e-01
    z[2,3,5]  R1228     1.0726174712181091e-01
    z[2,3,5]  R1229     -2.1086144447326660e-01
    z[2,3,5]  R1230     -2.9314762353897095e-01
    z[2,3,5]  R1231     -3.6674866080284119e-01
    z[2,3,5]  R1232     1.9188152253627777e-01
    z[2,3,5]  R1233     -8.2696892321109772e-02
    z[2,3,5]  R1234     2.3804658651351929e-01
    z[2,3,5]  R1235     8.0359637737274170e-02
    z[2,3,5]  R1236     -3.1121543049812317e-01
    z[2,3,5]  R1237     1.6140596568584442e-01
    z[2,3,5]  R1238     -0.660844087600708
    z[2,3,5]  R1239     1.1799512058496475e-01
    z[2,3,5]  R1240     3.7678044289350510e-02
    z[2,3,5]  R1241     -1.6677133738994598e-01
    z[2,3,5]  R1242     6.4428091049194336e-01
    z[2,3,5]  R1243     3.5658633708953857e-01
    z[2,3,5]  R1244     1.4558520913124084e-01
    z[2,3,5]  R1245     -1.7941139638423920e-02
    z[2,3,5]  R1246     6.9416350126266479e-01
    z[2,3,5]  R1247     3.7060967087745667e-01
    z[2,3,5]  R1248     6.9558471441268921e-02
    z[2,3,5]  R1249     7.5775671005249023e-01
    z[2,3,5]  R1250     -6.0562163591384888e-01
    z[2,3,5]  R1251     -4.7300764918327332e-01
    z[2,3,5]  R1252     6.4526784420013428e-01
    z[2,3,5]  R1253     -5.8970566838979721e-02
    z[2,3,5]  R1254     -3.8173735141754150e-01
    z[2,3,5]  R1255     -2.1188192069530487e-01
    z[2,3,5]  R1256     4.5160077512264252e-02
    z[2,3,5]  R1257     2.0999759435653687e-01
    z[2,3,5]  R1258     2.0915111899375916e-01
    z[2,3,5]  R1259     3.5207679867744446e-01
    z[2,3,5]  R1260     8.4841158241033554e-03
    z[2,3,5]  R1261     2.6747798919677734e-01
    z[2,3,5]  R1262     1.1453200131654739e-01
    z[2,3,5]  R1263     -1.9214065372943878e-01
    z[2,3,5]  R1264     3.0960902571678162e-01
    z[2,3,5]  R1265     2.1103376150131226e-01
    z[2,3,5]  R1266     0.509830892086029
    z[2,3,5]  R1267     -2.5707918405532837e-01
    z[2,3,5]  R1268     0.0906599685549736
    z[2,3,5]  R1269     1.3356056809425354e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1168     -1
    z[2,3,6]  R1169     1
    z[2,3,6]  R1170     -4.6538898348808289e-01
    z[2,3,6]  R1171     2.3281384259462357e-02
    z[2,3,6]  R1172     1.2262260913848877e-01
    z[2,3,6]  R1173     -5.3310345858335495e-02
    z[2,3,6]  R1174     1.0644710063934326e-01
    z[2,3,6]  R1175     -4.4793951511383057e-01
    z[2,3,6]  R1176     -3.8373082876205444e-02
    z[2,3,6]  R1177     4.5984596014022827e-01
    z[2,3,6]  R1178     -4.6277174353599548e-01
    z[2,3,6]  R1179     1.7444470524787903e-01
    z[2,3,6]  R1180     -3.2454732060432434e-01
    z[2,3,6]  R1181     3.7547999620437622e-01
    z[2,3,6]  R1182     4.2403522133827209e-01
    z[2,3,6]  R1183     -1.6031830012798309e-01
    z[2,3,6]  R1184     2.3387399315834045e-01
    z[2,3,6]  R1185     2.5553089380264282e-01
    z[2,3,6]  R1186     0.0127909230068326
    z[2,3,6]  R1187     2.9407903552055359e-01
    z[2,3,6]  R1188     -1.4919905364513397e-01
    z[2,3,6]  R1189     3.4494093060493469e-01
    z[2,3,6]  R1190     4.6677622012794018e-03
    z[2,3,6]  R1191     3.8868820667266846e-01
    z[2,3,6]  R1192     1.2070067971944809e-01
    z[2,3,6]  R1193     1.8211397528648376e-01
    z[2,3,6]  R1194     3.2585906982421875e-01
    z[2,3,6]  R1195     -4.0204131603240967e-01
    z[2,3,6]  R1196     -9.8212985321879387e-03
    z[2,3,6]  R1197     -6.7253420129418373e-03
    z[2,3,6]  R1198     -2.3075561225414276e-01
    z[2,3,6]  R1199     -1.4049398899078369e-01
    z[2,3,6]  R1200     -1.4339953660964966e-01
    z[2,3,6]  R1201     1.4559175074100494e-01
    z[2,3,6]  R1202     4.5146606862545013e-03
    z[2,3,6]  R1203     1.2308930046856403e-02
    z[2,3,6]  R1204     2.7681791782379150e-01
    z[2,3,6]  R1205     1.1601343005895615e-01
    z[2,3,6]  R1206     6.5551467239856720e-02
    z[2,3,6]  R1207     -5.1159677095711231e-03
    z[2,3,6]  R1208     4.6589076519012451e-01
    z[2,3,6]  R1209     7.5365439988672733e-03
    z[2,3,6]  R1210     0.06618682295084
    z[2,3,6]  R1211     6.6418468952178955e-02
    z[2,3,6]  R1212     -2.6544502377510071e-01
    z[2,3,6]  R1213     -9.4690709374845028e-04
    z[2,3,6]  R1214     2.8251171112060547e-01
    z[2,3,6]  R1215     5.6245069950819016e-02
    z[2,3,6]  R1216     -1.4166802167892456e-02
    z[2,3,6]  R1217     2.6571869850158691e-01
    z[2,3,6]  R1218     -4.4701248407363892e-03
    z[2,3,6]  R1219     5.2134519815444946e-01
    z[2,3,6]  R1220     -3.9237537980079651e-01
    z[2,3,6]  R1221     -3.2772576808929443e-01
    z[2,3,6]  R1222     5.5867195129394531e-01
    z[2,3,6]  R1223     0.148732990026474
    z[2,3,6]  R1224     5.8001667261123657e-01
    z[2,3,6]  R1225     5.0697189569473267e-01
    z[2,3,6]  R1226     -0.0642150416970253
    z[2,3,6]  R1227     -1.2757311761379242e-01
    z[2,3,6]  R1228     4.7128215432167053e-02
    z[2,3,6]  R1229     4.3735164403915405e-01
    z[2,3,6]  R1230     2.9392398893833160e-02
    z[2,3,6]  R1231     -8.8162004947662354e-02
    z[2,3,6]  R1232     -3.3935663104057312e-01
    z[2,3,6]  R1233     1.3469257950782776e-01
    z[2,3,6]  R1234     4.0162736177444458e-01
    z[2,3,6]  R1235     -3.8241699337959290e-01
    z[2,3,6]  R1236     -6.6924232244491577e-01
    z[2,3,6]  R1237     4.6717819571495056e-01
    z[2,3,6]  R1238     2.9751356691122055e-02
    z[2,3,6]  R1239     -2.1352486312389374e-01
    z[2,3,6]  R1240     2.6687702536582947e-01
    z[2,3,6]  R1241     1.1193595826625824e-01
    z[2,3,6]  R1242     0.0919094830751419
    z[2,3,6]  R1243     -1.1881686002016068e-01
    z[2,3,6]  R1244     -4.0493446588516235e-01
    z[2,3,6]  R1245     -3.5025155544281006e-01
    z[2,3,6]  R1246     -2.5829532742500305e-01
    z[2,3,6]  R1247     -4.2262068390846252e-01
    z[2,3,6]  R1248     2.2413088381290436e-01
    z[2,3,6]  R1249     -5.3570896387100220e-01
    z[2,3,6]  R1250     0.314071387052536
    z[2,3,6]  R1251     -4.0074631571769714e-01
    z[2,3,6]  R1252     -1.7076133191585541e-01
    z[2,3,6]  R1253     -4.1994345188140869e-01
    z[2,3,6]  R1254     4.8565447330474854e-02
    z[2,3,6]  R1255     4.8103256631293334e-06
    z[2,3,6]  R1256     -1.1641392111778259e-01
    z[2,3,6]  R1257     3.8770534098148346e-02
    z[2,3,6]  R1258     -1.8294635415077209e-01
    z[2,3,6]  R1259     1.1615064740180969e-01
    z[2,3,6]  R1260     6.2905430793762207e-02
    z[2,3,6]  R1261     -1.7759373784065247e-01
    z[2,3,6]  R1262     -6.9373399019241333e-02
    z[2,3,6]  R1263     1.3008493930101395e-02
    z[2,3,6]  R1264     -2.4414883553981781e-01
    z[2,3,6]  R1265     -2.3041759431362152e-01
    z[2,3,6]  R1266     9.8304279148578644e-02
    z[2,3,6]  R1267     6.0870878398418427e-02
    z[2,3,6]  R1268     1.5468700230121613e-01
    z[2,3,6]  R1269     -8.9504495263099670e-02
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1270     -1
    z[3,2,0]  R1271     1
    z[3,2,0]  R1284     -1.1964192241430283e-01
    z[3,2,0]  R1285     4.0206423401832581e-01
    z[3,2,0]  R1286     -1.3556101918220520e-01
    z[3,2,0]  R1287     5.1215697079896927e-02
    z[3,2,0]  R1288     3.4780604764819145e-03
    z[3,2,0]  R1289     -1.1641890555620193e-01
    z[3,2,0]  R1290     1.5033109486103058e-01
    z[3,2,0]  R1291     4.7395345568656921e-01
    z[3,2,0]  R1292     -1.1855874210596085e-01
    z[3,2,0]  R1293     6.9723552465438843e-01
    z[3,2,0]  R1294     -2.5846174359321594e-01
    z[3,2,0]  R1295     -2.6794302463531494e-01
    z[3,2,0]  R1296     -9.2754676938056946e-02
    z[3,2,0]  R1297     -0.0926201194524765
    z[3,2,0]  R1298     -6.0131609439849854e-01
    z[3,2,0]  R1299     -3.1854861974716187e-01
    z[3,2,0]  R1300     -2.8617480397224426e-01
    z[3,2,0]  R1301     -3.4148630499839783e-01
    z[3,2,0]  R1302     -1.9698794186115265e-01
    z[3,2,0]  R1303     6.1476562172174454e-02
    z[3,2,0]  R1304     -5.3763681650161743e-01
    z[3,2,0]  R1305     2.3490490019321442e-01
    z[3,2,0]  R1306     3.8144361227750778e-02
    z[3,2,0]  R1307     0.29140505194664
    z[3,2,0]  R1308     -4.8267990350723267e-01
    z[3,2,0]  R1309     -1.6096152365207672e-01
    z[3,2,0]  R1310     -9.0267103910446167e-01
    z[3,2,0]  R1311     -8.6181628704071045e-01
    z[3,2,0]  R1312     -8.6449366807937622e-01
    z[3,2,0]  R1313     -8.3858233690261841e-01
    z[3,2,0]  R1314     -0.0920419692993164
    z[3,2,0]  R1315     -5.5750578641891479e-01
    z[3,2,0]  R1316     4.5923680067062378e-02
    z[3,2,0]  R1317     6.3780355453491211e-01
    z[3,2,0]  R1318     3.5756379365921021e-01
    z[3,2,0]  R1319     -4.3255165219306946e-01
    z[3,2,0]  R1320     6.6954243183135986e-01
    z[3,2,0]  R1321     -4.8768940567970276e-01
    z[3,2,0]  R1322     -2.2892622649669647e-01
    z[3,2,0]  R1323     -5.1787346601486206e-01
    z[3,2,0]  R1324     -3.2776564359664917e-01
    z[3,2,0]  R1325     -1.8122953176498413e-01
    z[3,2,0]  R1326     0.0782022625207901
    z[3,2,0]  R1327     -3.8154255598783493e-02
    z[3,2,0]  R1328     -1.0823357105255127e-01
    z[3,2,0]  R1329     1.1593800783157349e-01
    z[3,2,0]  R1330     1.5558232367038727e-01
    z[3,2,0]  R1331     -5.0421273708343506e-01
    z[3,2,0]  R1332     5.5407893657684326e-01
    z[3,2,0]  R1333     -1.2754349410533905e-01
    z[3,2,0]  R1334     4.2848935723304749e-01
    z[3,2,0]  R1335     -6.9649821519851685e-01
    z[3,2,0]  R1336     -8.1040644645690918e-01
    z[3,2,0]  R1337     -1.0012060403823853e-01
    z[3,2,0]  R1338     -5.0157243013381958e-01
    z[3,2,0]  R1339     -4.1528832912445068e-01
    z[3,2,0]  R1340     -8.7722289562225342e-01
    z[3,2,0]  R1341     -5.3326344490051270e-01
    z[3,2,0]  R1342     -3.3016419410705566e-01
    z[3,2,0]  R1343     3.0442732572555542e-01
    z[3,2,0]  R1344     -1.5702560544013977e-01
    z[3,2,0]  R1345     -5.0300967693328857e-01
    z[3,2,0]  R1346     -5.6752872467041016e-01
    z[3,2,0]  R1347     -6.1493963003158569e-01
    z[3,2,0]  R1348     -4.1481819748878479e-01
    z[3,2,0]  R1349     -2.0261837542057037e-01
    z[3,2,0]  R1350     -6.9657880067825317e-01
    z[3,2,0]  R1351     -5.2908849716186523e-01
    z[3,2,0]  R1352     -2.1004769206047058e-01
    z[3,2,0]  R1353     -8.3767634630203247e-01
    z[3,2,0]  R1354     -6.4867216348648071e-01
    z[3,2,0]  R1355     -4.2403453588485718e-01
    z[3,2,0]  R1356     3.0908182263374329e-01
    z[3,2,0]  R1357     -2.7287423610687256e-02
    z[3,2,0]  R1358     3.7874868512153625e-01
    z[3,2,0]  R1359     5.4182535409927368e-01
    z[3,2,0]  R1360     4.1882076859474182e-01
    z[3,2,0]  R1361     7.0044904947280884e-01
    z[3,2,0]  R1362     4.9352419376373291e-01
    z[3,2,0]  R1363     4.3174853920936584e-01
    z[3,2,0]  R1364     -6.7483878135681152e-01
    z[3,2,0]  R1365     -5.6025809049606323e-01
    z[3,2,0]  R1366     -5.9989315271377563e-01
    z[3,2,0]  R1367     -1.0695355385541916e-01
    z[3,2,0]  R1368     0.602087140083313
    z[3,2,0]  R1369     1.4182625710964203e-01
    z[3,2,0]  R1370     6.2107789516448975e-01
    z[3,2,0]  R1371     5.8524739742279053e-01
    z[3,2,0]  R1372     3.9227432012557983e-01
    z[3,2,0]  R1373     9.2200249433517456e-02
    z[3,2,0]  R1374     -3.3049005270004272e-01
    z[3,2,0]  R1375     -4.3728652596473694e-01
    z[3,2,0]  R1376     -2.7133550494909286e-02
    z[3,2,0]  R1377     -1.9071012502536178e-03
    z[3,2,0]  R1378     1.7247703671455383e-01
    z[3,2,0]  R1379     2.4037280678749084e-01
    z[3,2,0]  R1380     3.6065945029258728e-01
    z[3,2,0]  R1381     4.0757986903190613e-01
    z[3,2,0]  R1382     0.410907119512558
    z[3,2,0]  R1383     4.0464967489242554e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1272     -1
    z[3,2,1]  R1273     1
    z[3,2,1]  R1284     2.2257371246814728e-01
    z[3,2,1]  R1285     1.3655059039592743e-01
    z[3,2,1]  R1286     1.3799153268337250e-01
    z[3,2,1]  R1287     -1.4160220511257648e-02
    z[3,2,1]  R1288     2.2218354046344757e-01
    z[3,2,1]  R1289     6.1632741242647171e-02
    z[3,2,1]  R1290     2.0420733094215393e-01
    z[3,2,1]  R1291     -5.2433669567108154e-01
    z[3,2,1]  R1292     -8.0431565642356873e-02
    z[3,2,1]  R1293     -5.4815441370010376e-01
    z[3,2,1]  R1294     8.6236643791198730e-01
    z[3,2,1]  R1295     8.9285075664520264e-01
    z[3,2,1]  R1296     7.2662174701690674e-01
    z[3,2,1]  R1297     4.3325155973434448e-01
    z[3,2,1]  R1298     6.2199360132217407e-01
    z[3,2,1]  R1299     1.0795595496892929e-01
    z[3,2,1]  R1300     1.4799709618091583e-01
    z[3,2,1]  R1301     1.3905423879623413e-01
    z[3,2,1]  R1302     7.8896120190620422e-02
    z[3,2,1]  R1303     6.1751686036586761e-02
    z[3,2,1]  R1304     2.0509964227676392e-01
    z[3,2,1]  R1305     -6.4890630543231964e-02
    z[3,2,1]  R1306     2.3985694348812103e-01
    z[3,2,1]  R1307     2.2835461795330048e-01
    z[3,2,1]  R1308     -5.0408226251602173e-01
    z[3,2,1]  R1309     3.2518602907657623e-02
    z[3,2,1]  R1310     -2.5041484832763672e-01
    z[3,2,1]  R1311     -2.2475172579288483e-01
    z[3,2,1]  R1312     -1.8111494183540344e-01
    z[3,2,1]  R1313     -2.7215388417243958e-01
    z[3,2,1]  R1314     9.5345407724380493e-01
    z[3,2,1]  R1315     7.3015928268432617e-01
    z[3,2,1]  R1316     -1.1836803704500198e-01
    z[3,2,1]  R1317     2.0745410025119781e-01
    z[3,2,1]  R1318     1.6270010173320770e-01
    z[3,2,1]  R1319     -6.2895172834396362e-01
    z[3,2,1]  R1320     3.3519536256790161e-01
    z[3,2,1]  R1321     -2.7930495142936707e-01
    z[3,2,1]  R1322     -5.5695421993732452e-02
    z[3,2,1]  R1323     -5.0767141580581665e-01
    z[3,2,1]  R1324     1.3667623698711395e-01
    z[3,2,1]  R1325     -6.8870939314365387e-02
    z[3,2,1]  R1326     -7.5835567712783813e-01
    z[3,2,1]  R1327     -4.3164405971765518e-02
    z[3,2,1]  R1328     -3.5222802311182022e-02
    z[3,2,1]  R1329     -6.3071471452713013e-01
    z[3,2,1]  R1330     -6.2627446651458740e-01
    z[3,2,1]  R1331     -3.1206080317497253e-01
    z[3,2,1]  R1332     -6.4502626657485962e-01
    z[3,2,1]  R1333     1.3340739905834198e-01
    z[3,2,1]  R1334     -5.7495719194412231e-01
    z[3,2,1]  R1335     1.7622421681880951e-01
    z[3,2,1]  R1336     1.8245464190840721e-02
    z[3,2,1]  R1337     -7.1773201227188110e-01
    z[3,2,1]  R1338     7.1016073226928711e-01
    z[3,2,1]  R1339     6.9762754440307617e-01
    z[3,2,1]  R1340     2.7729269862174988e-01
    z[3,2,1]  R1341     7.4746048450469971e-01
    z[3,2,1]  R1342     5.2432936429977417e-01
    z[3,2,1]  R1343     6.6270820796489716e-02
    z[3,2,1]  R1344     -3.7990295886993408e-01
    z[3,2,1]  R1345     5.6112813949584961e-01
    z[3,2,1]  R1346     -2.9780879616737366e-01
    z[3,2,1]  R1347     -0.264649361371994
    z[3,2,1]  R1348     -6.2970317900180817e-02
    z[3,2,1]  R1349     -7.4537402391433716e-01
    z[3,2,1]  R1350     -1.3572390377521515e-01
    z[3,2,1]  R1351     3.1126219034194946e-01
    z[3,2,1]  R1352     5.7729268074035645e-01
    z[3,2,1]  R1353     1.5036055445671082e-01
    z[3,2,1]  R1354     4.3710783123970032e-01
    z[3,2,1]  R1355     0.510776162147522
    z[3,2,1]  R1356     1.7163111269474030e-01
    z[3,2,1]  R1357     1.1031579971313477e-01
    z[3,2,1]  R1358     -0.258175253868103
    z[3,2,1]  R1359     -1.8876637518405914e-01
    z[3,2,1]  R1360     -6.7064231634140015e-01
    z[3,2,1]  R1361     1.7958882451057434e-01
    z[3,2,1]  R1362     2.3338532447814941e-01
    z[3,2,1]  R1363     8.8805359601974487e-01
    z[3,2,1]  R1364     2.4562311172485352e-01
    z[3,2,1]  R1365     3.8305193185806274e-01
    z[3,2,1]  R1366     5.1997935771942139e-01
    z[3,2,1]  R1367     4.0128874778747559e-01
    z[3,2,1]  R1368     -2.8923526406288147e-01
    z[3,2,1]  R1369     1.2952621909789741e-04
    z[3,2,1]  R1370     -0.165132075548172
    z[3,2,1]  R1371     0.0938212126493454
    z[3,2,1]  R1372     -6.4189112186431885e-01
    z[3,2,1]  R1373     2.4857778847217560e-01
    z[3,2,1]  R1374     1.9468443095684052e-01
    z[3,2,1]  R1375     3.9200019836425781e-01
    z[3,2,1]  R1376     -7.1944159269332886e-01
    z[3,2,1]  R1377     -7.7920407056808472e-01
    z[3,2,1]  R1378     4.0922917425632477e-02
    z[3,2,1]  R1379     -2.2571529448032379e-01
    z[3,2,1]  R1380     9.0154004096984863e-01
    z[3,2,1]  R1381     8.3971405029296875e-01
    z[3,2,1]  R1382     3.5176548361778259e-01
    z[3,2,1]  R1383     2.1756376326084137e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1274     -1
    z[3,2,2]  R1275     1
    z[3,2,2]  R1284     1.6007901728153229e-01
    z[3,2,2]  R1285     5.3326040506362915e-01
    z[3,2,2]  R1286     5.4453080892562866e-01
    z[3,2,2]  R1287     1.6188374161720276e-01
    z[3,2,2]  R1288     7.3928517103195190e-01
    z[3,2,2]  R1289     3.2165729999542236e-01
    z[3,2,2]  R1290     5.5308485031127930e-01
    z[3,2,2]  R1291     -4.5288002490997314e-01
    z[3,2,2]  R1292     6.9390898942947388e-01
    z[3,2,2]  R1293     -3.5546028614044189e-01
    z[3,2,2]  R1294     -3.0676954984664917e-01
    z[3,2,2]  R1295     -0.0371239148080349
    z[3,2,2]  R1296     -1.3091565109789371e-02
    z[3,2,2]  R1297     -4.9499917030334473e-01
    z[3,2,2]  R1298     -0.222425177693367
    z[3,2,2]  R1299     -6.6375064849853516e-01
    z[3,2,2]  R1300     -4.0637367963790894e-01
    z[3,2,2]  R1301     -0.684245228767395
    z[3,2,2]  R1302     -9.0016961097717285e-01
    z[3,2,2]  R1303     -1.3463929295539856e-01
    z[3,2,2]  R1304     1.8626801669597626e-01
    z[3,2,2]  R1305     -6.9084298610687256e-01
    z[3,2,2]  R1306     -6.0531413555145264e-01
    z[3,2,2]  R1307     -8.0756264925003052e-01
    z[3,2,2]  R1308     -4.5582181215286255e-01
    z[3,2,2]  R1309     -3.7148183584213257e-01
    z[3,2,2]  R1310     -6.4220331609249115e-02
    z[3,2,2]  R1311     1.9715829193592072e-01
    z[3,2,2]  R1312     -5.4146878421306610e-02
    z[3,2,2]  R1313     -2.3206777870655060e-02
    z[3,2,2]  R1314     -2.2958593070507050e-01
    z[3,2,2]  R1315     1.5322811901569366e-01
    z[3,2,2]  R1316     -9.5299792289733887e-01
    z[3,2,2]  R1317     -0.603747546672821
    z[3,2,2]  R1318     -8.0380862951278687e-01
    z[3,2,2]  R1319     -4.9176487326622009e-01
    z[3,2,2]  R1320     7.6304391026496887e-02
    z[3,2,2]  R1321     -0.568027675151825
    z[3,2,2]  R1322     -3.4215328097343445e-01
    z[3,2,2]  R1323     -4.1428482532501221e-01
    z[3,2,2]  R1324     3.9351809024810791e-01
    z[3,2,2]  R1325     3.7518355250358582e-01
    z[3,2,2]  R1326     -0.393670916557312
    z[3,2,2]  R1327     7.3147565126419067e-01
    z[3,2,2]  R1328     7.9934698343276978e-01
    z[3,2,2]  R1329     -4.9697494506835938e-01
    z[3,2,2]  R1330     -7.4237972497940063e-01
    z[3,2,2]  R1331     -6.0311222076416016e-01
    z[3,2,2]  R1332     -1.4511504769325256e-01
    z[3,2,2]  R1333     -2.1574316546320915e-02
    z[3,2,2]  R1334     1.5001340769231319e-02
    z[3,2,2]  R1335     1.1816588789224625e-01
    z[3,2,2]  R1336     3.0645513907074928e-02
    z[3,2,2]  R1337     4.0301901102066040e-01
    z[3,2,2]  R1338     -0.204465851187706
    z[3,2,2]  R1339     2.9491984844207764e-01
    z[3,2,2]  R1340     -2.9875391721725464e-01
    z[3,2,2]  R1341     8.0763585865497589e-02
    z[3,2,2]  R1342     4.5759817957878113e-01
    z[3,2,2]  R1343     -0.422170490026474
    z[3,2,2]  R1344     -0.523331880569458
    z[3,2,2]  R1345     0.362429141998291
    z[3,2,2]  R1346     2.7793258428573608e-01
    z[3,2,2]  R1347     5.4511779546737671e-01
    z[3,2,2]  R1348     4.4897815585136414e-01
    z[3,2,2]  R1349     5.0363477319478989e-02
    z[3,2,2]  R1350     1.6044487059116364e-01
    z[3,2,2]  R1351     1.4809851348400116e-01
    z[3,2,2]  R1352     7.5230455398559570e-01
    z[3,2,2]  R1353     4.0379768610000610e-01
    z[3,2,2]  R1354     7.1681782603263855e-02
    z[3,2,2]  R1355     5.9995889663696289e-01
    z[3,2,2]  R1356     -4.1300213336944580e-01
    z[3,2,2]  R1357     -0.5770223736763
    z[3,2,2]  R1358     -3.4725788235664368e-01
    z[3,2,2]  R1359     -1.4485648274421692e-01
    z[3,2,2]  R1360     -0.0309580210596323
    z[3,2,2]  R1361     -4.0920473635196686e-02
    z[3,2,2]  R1362     -2.1138539910316467e-01
    z[3,2,2]  R1363     1.8279202282428741e-02
    z[3,2,2]  R1364     5.6813371181488037e-01
    z[3,2,2]  R1365     2.4197937548160553e-01
    z[3,2,2]  R1366     -2.0100402832031250e-01
    z[3,2,2]  R1367     1.4997847378253937e-01
    z[3,2,2]  R1368     -4.4935917854309082e-01
    z[3,2,2]  R1369     -0.46416175365448
    z[3,2,2]  R1370     -5.9348784387111664e-02
    z[3,2,2]  R1371     1.3861194252967834e-01
    z[3,2,2]  R1372     -0.0834183618426323
    z[3,2,2]  R1373     -3.4910953044891357e-01
    z[3,2,2]  R1374     5.9702861309051514e-01
    z[3,2,2]  R1375     1.6165429353713989e-01
    z[3,2,2]  R1376     -1.9677430391311646e-02
    z[3,2,2]  R1377     -2.2065903246402740e-01
    z[3,2,2]  R1378     1.6770800948143005e-01
    z[3,2,2]  R1379     -2.9879701137542725e-01
    z[3,2,2]  R1380     -1.4886486530303955e-01
    z[3,2,2]  R1381     -1.8530897796154022e-01
    z[3,2,2]  R1382     -4.6247458457946777e-01
    z[3,2,2]  R1383     -4.2749953269958496e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1276     -1
    z[3,2,3]  R1277     1
    z[3,2,3]  R1284     9.0734344720840454e-01
    z[3,2,3]  R1285     6.0657733678817749e-01
    z[3,2,3]  R1286     7.1679770946502686e-01
    z[3,2,3]  R1287     9.0983533859252930e-01
    z[3,2,3]  R1288     0.408944696187973
    z[3,2,3]  R1289     8.0546975135803223e-01
    z[3,2,3]  R1290     2.9149407148361206e-01
    z[3,2,3]  R1291     -2.0121458172798157e-01
    z[3,2,3]  R1292     1.2604017555713654e-01
    z[3,2,3]  R1293     -9.3929208815097809e-02
    z[3,2,3]  R1294     1.5068401396274567e-01
    z[3,2,3]  R1295     -2.0425774157047272e-01
    z[3,2,3]  R1296     1.6447030007839203e-01
    z[3,2,3]  R1297     -6.1712962388992310e-01
    z[3,2,3]  R1298     -6.0796007513999939e-02
    z[3,2,3]  R1299     -5.2693754434585571e-01
    z[3,2,3]  R1300     -4.2322179675102234e-01
    z[3,2,3]  R1301     -2.7854594588279724e-01
    z[3,2,3]  R1302     -2.9469951987266541e-01
    z[3,2,3]  R1303     -3.3626815676689148e-01
    z[3,2,3]  R1304     4.0921539068222046e-01
    z[3,2,3]  R1305     -2.5749981403350830e-01
    z[3,2,3]  R1306     -3.5923480987548828e-01
    z[3,2,3]  R1307     -1.7536112666130066e-01
    z[3,2,3]  R1308     -1.9739560782909393e-01
    z[3,2,3]  R1309     -5.6692975759506226e-01
    z[3,2,3]  R1310     -2.6862585544586182e-01
    z[3,2,3]  R1311     -2.1962922811508179e-01
    z[3,2,3]  R1312     -1.7073485255241394e-01
    z[3,2,3]  R1313     -2.5808918476104736e-01
    z[3,2,3]  R1314     1.5992234647274017e-01
    z[3,2,3]  R1315     1.6902923583984375e-01
    z[3,2,3]  R1316     -2.3952773213386536e-01
    z[3,2,3]  R1317     -3.7652522325515747e-01
    z[3,2,3]  R1318     -2.0028272271156311e-01
    z[3,2,3]  R1319     -2.7765011787414551e-01
    z[3,2,3]  R1320     -4.0416863560676575e-01
    z[3,2,3]  R1321     -3.9246571063995361e-01
    z[3,2,3]  R1322     -0.846693754196167
    z[3,2,3]  R1323     -3.2565972208976746e-01
    z[3,2,3]  R1324     6.6688269376754761e-01
    z[3,2,3]  R1325     5.1572436094284058e-01
    z[3,2,3]  R1326     -0.0335572175681591
    z[3,2,3]  R1327     2.5846010446548462e-01
    z[3,2,3]  R1328     3.7230160832405090e-01
    z[3,2,3]  R1329     9.4167873263359070e-02
    z[3,2,3]  R1330     1.1200413852930069e-01
    z[3,2,3]  R1331     -2.5182047486305237e-01
    z[3,2,3]  R1332     -1.4875121414661407e-02
    z[3,2,3]  R1333     8.9829826354980469e-01
    z[3,2,3]  R1334     -5.8477652072906494e-01
    z[3,2,3]  R1335     3.4625104069709778e-01
    z[3,2,3]  R1336     2.9363808035850525e-01
    z[3,2,3]  R1337     -0.509032666683197
    z[3,2,3]  R1338     3.5776901245117188e-01
    z[3,2,3]  R1339     -8.1725783646106720e-02
    z[3,2,3]  R1340     1.5989720821380615e-01
    z[3,2,3]  R1341     4.3401163071393967e-02
    z[3,2,3]  R1342     2.2026045620441437e-01
    z[3,2,3]  R1343     -6.7249870300292969e-01
    z[3,2,3]  R1344     -6.6445702314376831e-01
    z[3,2,3]  R1345     2.9607766866683960e-01
    z[3,2,3]  R1346     6.4727288484573364e-01
    z[3,2,3]  R1347     3.8072162866592407e-01
    z[3,2,3]  R1348     3.6636695265769958e-01
    z[3,2,3]  R1349     -3.3809766173362732e-01
    z[3,2,3]  R1350     2.7824339270591736e-01
    z[3,2,3]  R1351     1.0880557447671890e-01
    z[3,2,3]  R1352     1.6239469870924950e-02
    z[3,2,3]  R1353     -1.1333606392145157e-01
    z[3,2,3]  R1354     3.5330617427825928e-01
    z[3,2,3]  R1355     2.8760345652699471e-02
    z[3,2,3]  R1356     7.1464496850967407e-01
    z[3,2,3]  R1357     7.4313563108444214e-01
    z[3,2,3]  R1358     6.5993690490722656e-01
    z[3,2,3]  R1359     7.3723417520523071e-01
    z[3,2,3]  R1360     5.7594460248947144e-01
    z[3,2,3]  R1361     3.9901995658874512e-01
    z[3,2,3]  R1362     2.5344261527061462e-01
    z[3,2,3]  R1363     -7.5182631611824036e-02
    z[3,2,3]  R1364     3.6799827218055725e-01
    z[3,2,3]  R1365     2.8462353348731995e-01
    z[3,2,3]  R1366     4.3726623058319092e-01
    z[3,2,3]  R1367     8.8551706075668335e-01
    z[3,2,3]  R1368     -3.9345484972000122e-01
    z[3,2,3]  R1369     0.773955762386322
    z[3,2,3]  R1370     5.0759112834930420e-01
    z[3,2,3]  R1371     3.9197233319282532e-01
    z[3,2,3]  R1372     0.642471969127655
    z[3,2,3]  R1373     1.5008336305618286e-01
    z[3,2,3]  R1374     4.8011535406112671e-01
    z[3,2,3]  R1375     2.3251669108867645e-01
    z[3,2,3]  R1376     -1.5396174788475037e-01
    z[3,2,3]  R1377     -1.6268764436244965e-01
    z[3,2,3]  R1378     3.4525668621063232e-01
    z[3,2,3]  R1379     0.374606728553772
    z[3,2,3]  R1380     -1.6411715745925903e-01
    z[3,2,3]  R1381     9.1871835291385651e-02
    z[3,2,3]  R1382     6.4905665814876556e-02
    z[3,2,3]  R1383     1.3168838620185852e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1278     -1
    z[3,2,4]  R1279     1
    z[3,2,4]  R1284     2.1208053454756737e-02
    z[3,2,4]  R1285     -0.158487930893898
    z[3,2,4]  R1286     0.0169528815895319
    z[3,2,4]  R1287     -3.4378603100776672e-01
    z[3,2,4]  R1288     -1.3737997412681580e-01
    z[3,2,4]  R1289     -2.7875187993049622e-01
    z[3,2,4]  R1290     9.3737430870532990e-03
    z[3,2,4]  R1291     -1.0268484055995941e-01
    z[3,2,4]  R1292     2.1089982986450195e-01
    z[3,2,4]  R1293     -1.3674362003803253e-01
    z[3,2,4]  R1294     8.0831823870539665e-03
    z[3,2,4]  R1295     2.1813374757766724e-01
    z[3,2,4]  R1296     -1.1247310787439346e-01
    z[3,2,4]  R1297     1.9123336672782898e-01
    z[3,2,4]  R1298     1.1492103338241577e-01
    z[3,2,4]  R1299     2.1364960074424744e-01
    z[3,2,4]  R1300     0.0580105260014534
    z[3,2,4]  R1301     4.8082344233989716e-02
    z[3,2,4]  R1302     5.2392229437828064e-02
    z[3,2,4]  R1303     -4.8945634625852108e-03
    z[3,2,4]  R1304     3.6185383796691895e-02
    z[3,2,4]  R1305     1.1271552741527557e-01
    z[3,2,4]  R1306     -5.3692040964961052e-03
    z[3,2,4]  R1307     1.4080798253417015e-02
    z[3,2,4]  R1308     -3.4365782141685486e-01
    z[3,2,4]  R1309     -6.8464004993438721e-01
    z[3,2,4]  R1310     1.7493329942226410e-01
    z[3,2,4]  R1311     -2.7211913466453552e-01
    z[3,2,4]  R1312     -3.3249381184577942e-01
    z[3,2,4]  R1313     -1.3458943367004395e-01
    z[3,2,4]  R1314     1.1815481819212437e-02
    z[3,2,4]  R1315     3.0346587300300598e-02
    z[3,2,4]  R1316     -1.9262244924902916e-02
    z[3,2,4]  R1317     8.2460500299930573e-02
    z[3,2,4]  R1318     -0.0631580650806427
    z[3,2,4]  R1319     2.7730926871299744e-02
    z[3,2,4]  R1320     2.4314887821674347e-02
    z[3,2,4]  R1321     -3.7103638052940369e-01
    z[3,2,4]  R1322     -0.279972106218338
    z[3,2,4]  R1323     -4.1296628117561340e-01
    z[3,2,4]  R1324     -2.3895879089832306e-01
    z[3,2,4]  R1325     -4.7157695889472961e-01
    z[3,2,4]  R1326     -3.7143155932426453e-01
    z[3,2,4]  R1327     -5.8237057924270630e-01
    z[3,2,4]  R1328     4.2662656307220459e-01
    z[3,2,4]  R1329     -3.4332302212715149e-01
    z[3,2,4]  R1330     -1.3079759478569031e-01
    z[3,2,4]  R1331     -6.1369098722934723e-02
    z[3,2,4]  R1332     -1.6491885483264923e-01
    z[3,2,4]  R1333     3.5114273428916931e-01
    z[3,2,4]  R1334     -1.4118352532386780e-01
    z[3,2,4]  R1335     3.3173173666000366e-01
    z[3,2,4]  R1336     -1.0776351392269135e-01
    z[3,2,4]  R1337     -1.4837658405303955e-01
    z[3,2,4]  R1338     -3.0603675171732903e-02
    z[3,2,4]  R1339     -4.1560694575309753e-01
    z[3,2,4]  R1340     -0.0971241444349289
    z[3,2,4]  R1341     2.3729506134986877e-01
    z[3,2,4]  R1342     3.9734295010566711e-01
    z[3,2,4]  R1343     -1.9221581518650055e-01
    z[3,2,4]  R1344     -3.3902657032012939e-01
    z[3,2,4]  R1345     2.2356674075126648e-01
    z[3,2,4]  R1346     -1.6046515107154846e-01
    z[3,2,4]  R1347     2.5032532215118408e-01
    z[3,2,4]  R1348     -5.6066513061523438e-01
    z[3,2,4]  R1349     -2.8734448552131653e-01
    z[3,2,4]  R1350     -4.5655864477157593e-01
    z[3,2,4]  R1351     -5.9938418865203857e-01
    z[3,2,4]  R1352     -5.5443480610847473e-02
    z[3,2,4]  R1353     -3.0573008116334677e-03
    z[3,2,4]  R1354     2.4033010005950928e-01
    z[3,2,4]  R1355     -2.1824173629283905e-01
    z[3,2,4]  R1356     -2.3332582414150238e-01
    z[3,2,4]  R1357     -2.1850545704364777e-01
    z[3,2,4]  R1358     -3.8703937083482742e-02
    z[3,2,4]  R1359     4.0596637874841690e-02
    z[3,2,4]  R1360     1.8956919014453888e-01
    z[3,2,4]  R1361     -2.4005274474620819e-01
    z[3,2,4]  R1362     -8.1402897834777832e-02
    z[3,2,4]  R1363     1.0504613071680069e-01
    z[3,2,4]  R1364     -7.7836655080318451e-02
    z[3,2,4]  R1365     -0.404949426651001
    z[3,2,4]  R1366     -2.4935327470302582e-01
    z[3,2,4]  R1367     5.4351929575204849e-02
    z[3,2,4]  R1368     3.2880973815917969e-01
    z[3,2,4]  R1369     -2.1899476647377014e-01
    z[3,2,4]  R1370     -2.7377369999885559e-01
    z[3,2,4]  R1371     -1.4054611325263977e-01
    z[3,2,4]  R1372     7.4891060590744019e-02
    z[3,2,4]  R1373     -2.6861688494682312e-01
    z[3,2,4]  R1374     1.3103212416172028e-01
    z[3,2,4]  R1375     -6.5347111225128174e-01
    z[3,2,4]  R1376     3.8102969527244568e-01
    z[3,2,4]  R1377     3.8656479120254517e-01
    z[3,2,4]  R1378     -9.0547271072864532e-02
    z[3,2,4]  R1379     -1.6460482776165009e-01
    z[3,2,4]  R1380     -4.8961769789457321e-04
    z[3,2,4]  R1381     -1.9483752548694611e-01
    z[3,2,4]  R1382     -0.689633846282959
    z[3,2,4]  R1383     -5.9421205520629883e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1280     -1
    z[3,2,5]  R1281     1
    z[3,2,5]  R1284     -2.9314762353897095e-01
    z[3,2,5]  R1285     -3.6674866080284119e-01
    z[3,2,5]  R1286     1.9188152253627777e-01
    z[3,2,5]  R1287     -8.2696892321109772e-02
    z[3,2,5]  R1288     2.3804658651351929e-01
    z[3,2,5]  R1289     8.0359637737274170e-02
    z[3,2,5]  R1290     -3.1121543049812317e-01
    z[3,2,5]  R1291     1.6140596568584442e-01
    z[3,2,5]  R1292     -0.660844087600708
    z[3,2,5]  R1293     1.1799512058496475e-01
    z[3,2,5]  R1294     3.7678044289350510e-02
    z[3,2,5]  R1295     -1.6677133738994598e-01
    z[3,2,5]  R1296     6.4428091049194336e-01
    z[3,2,5]  R1297     3.5658633708953857e-01
    z[3,2,5]  R1298     1.4558520913124084e-01
    z[3,2,5]  R1299     -1.7941139638423920e-02
    z[3,2,5]  R1300     6.9416350126266479e-01
    z[3,2,5]  R1301     3.7060967087745667e-01
    z[3,2,5]  R1302     6.9558471441268921e-02
    z[3,2,5]  R1303     7.5775671005249023e-01
    z[3,2,5]  R1304     -6.0562163591384888e-01
    z[3,2,5]  R1305     -4.7300764918327332e-01
    z[3,2,5]  R1306     6.4526784420013428e-01
    z[3,2,5]  R1307     -5.8970566838979721e-02
    z[3,2,5]  R1308     -3.8173735141754150e-01
    z[3,2,5]  R1309     -2.1188192069530487e-01
    z[3,2,5]  R1310     4.5160077512264252e-02
    z[3,2,5]  R1311     2.0999759435653687e-01
    z[3,2,5]  R1312     2.0915111899375916e-01
    z[3,2,5]  R1313     3.5207679867744446e-01
    z[3,2,5]  R1314     8.4841158241033554e-03
    z[3,2,5]  R1315     2.6747798919677734e-01
    z[3,2,5]  R1316     1.1453200131654739e-01
    z[3,2,5]  R1317     -1.9214065372943878e-01
    z[3,2,5]  R1318     3.0960902571678162e-01
    z[3,2,5]  R1319     2.1103376150131226e-01
    z[3,2,5]  R1320     0.509830892086029
    z[3,2,5]  R1321     -2.5707918405532837e-01
    z[3,2,5]  R1322     0.0906599685549736
    z[3,2,5]  R1323     1.3356056809425354e-01
    z[3,2,5]  R1324     -2.4737168103456497e-02
    z[3,2,5]  R1325     5.7684624195098877e-01
    z[3,2,5]  R1326     0.331180602312088
    z[3,2,5]  R1327     2.2983746230602264e-01
    z[3,2,5]  R1328     -1.2704163789749146e-01
    z[3,2,5]  R1329     -1.1993834376335144e-01
    z[3,2,5]  R1330     -3.6350786685943604e-02
    z[3,2,5]  R1331     7.7492587268352509e-02
    z[3,2,5]  R1332     -1.1959101259708405e-01
    z[3,2,5]  R1333     -6.9265522062778473e-02
    z[3,2,5]  R1334     -1.3553163409233093e-01
    z[3,2,5]  R1335     -3.1456491351127625e-01
    z[3,2,5]  R1336     2.5362795591354370e-01
    z[3,2,5]  R1337     -0.0747024267911911
    z[3,2,5]  R1338     1.3659586012363434e-01
    z[3,2,5]  R1339     9.5757313072681427e-02
    z[3,2,5]  R1340     -1.7079490423202515e-01
    z[3,2,5]  R1341     -7.5730629265308380e-02
    z[3,2,5]  R1342     -4.2192158102989197e-01
    z[3,2,5]  R1343     3.4134829044342041e-01
    z[3,2,5]  R1344     2.6010846719145775e-02
    z[3,2,5]  R1345     1.0972206294536591e-01
    z[3,2,5]  R1346     2.2955326735973358e-01
    z[3,2,5]  R1347     -1.1781092733144760e-01
    z[3,2,5]  R1348     -2.6004803180694580e-01
    z[3,2,5]  R1349     -2.0570079982280731e-01
    z[3,2,5]  R1350     -4.2971235513687134e-01
    z[3,2,5]  R1351     4.7969031333923340e-01
    z[3,2,5]  R1352     8.0762747675180435e-03
    z[3,2,5]  R1353     -2.8292128443717957e-01
    z[3,2,5]  R1354     -4.2411741614341736e-01
    z[3,2,5]  R1355     3.6013630032539368e-01
    z[3,2,5]  R1356     3.7317776679992676e-01
    z[3,2,5]  R1357     2.3234508931636810e-01
    z[3,2,5]  R1358     3.9454281330108643e-01
    z[3,2,5]  R1359     3.0197301506996155e-01
    z[3,2,5]  R1360     4.3862808495759964e-02
    z[3,2,5]  R1361     5.0850385427474976e-01
    z[3,2,5]  R1362     6.0775619745254517e-01
    z[3,2,5]  R1363     8.8746301829814911e-02
    z[3,2,5]  R1364     1.2499637901782990e-01
    z[3,2,5]  R1365     -4.8106333613395691e-01
    z[3,2,5]  R1366     -7.4209660291671753e-02
    z[3,2,5]  R1367     1.3393706083297729e-01
    z[3,2,5]  R1368     -9.5786139369010925e-02
    z[3,2,5]  R1369     3.3809685707092285e-01
    z[3,2,5]  R1370     5.0066936016082764e-01
    z[3,2,5]  R1371     6.2086051702499390e-01
    z[3,2,5]  R1372     9.3482971191406250e-02
    z[3,2,5]  R1373     6.6434174776077271e-01
    z[3,2,5]  R1374     -3.0788388848304749e-01
    z[3,2,5]  R1375     2.0122538506984711e-01
    z[3,2,5]  R1376     -1.6681909561157227e-02
    z[3,2,5]  R1377     -3.8226428627967834e-01
    z[3,2,5]  R1378     6.9038450717926025e-01
    z[3,2,5]  R1379     6.1444973945617676e-01
    z[3,2,5]  R1380     6.2699727714061737e-02
    z[3,2,5]  R1381     -1.7816412448883057e-01
    z[3,2,5]  R1382     1.0726174712181091e-01
    z[3,2,5]  R1383     -2.1086144447326660e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1282     -1
    z[3,2,6]  R1283     1
    z[3,2,6]  R1284     2.9392398893833160e-02
    z[3,2,6]  R1285     -8.8162004947662354e-02
    z[3,2,6]  R1286     -3.3935663104057312e-01
    z[3,2,6]  R1287     1.3469257950782776e-01
    z[3,2,6]  R1288     4.0162736177444458e-01
    z[3,2,6]  R1289     -3.8241699337959290e-01
    z[3,2,6]  R1290     -6.6924232244491577e-01
    z[3,2,6]  R1291     4.6717819571495056e-01
    z[3,2,6]  R1292     2.9751356691122055e-02
    z[3,2,6]  R1293     -2.1352486312389374e-01
    z[3,2,6]  R1294     2.6687702536582947e-01
    z[3,2,6]  R1295     1.1193595826625824e-01
    z[3,2,6]  R1296     0.0919094830751419
    z[3,2,6]  R1297     -1.1881686002016068e-01
    z[3,2,6]  R1298     -4.0493446588516235e-01
    z[3,2,6]  R1299     -3.5025155544281006e-01
    z[3,2,6]  R1300     -2.5829532742500305e-01
    z[3,2,6]  R1301     -4.2262068390846252e-01
    z[3,2,6]  R1302     2.2413088381290436e-01
    z[3,2,6]  R1303     -5.3570896387100220e-01
    z[3,2,6]  R1304     0.314071387052536
    z[3,2,6]  R1305     -4.0074631571769714e-01
    z[3,2,6]  R1306     -1.7076133191585541e-01
    z[3,2,6]  R1307     -4.1994345188140869e-01
    z[3,2,6]  R1308     4.8565447330474854e-02
    z[3,2,6]  R1309     4.8103256631293334e-06
    z[3,2,6]  R1310     -1.1641392111778259e-01
    z[3,2,6]  R1311     3.8770534098148346e-02
    z[3,2,6]  R1312     -1.8294635415077209e-01
    z[3,2,6]  R1313     1.1615064740180969e-01
    z[3,2,6]  R1314     6.2905430793762207e-02
    z[3,2,6]  R1315     -1.7759373784065247e-01
    z[3,2,6]  R1316     -6.9373399019241333e-02
    z[3,2,6]  R1317     1.3008493930101395e-02
    z[3,2,6]  R1318     -2.4414883553981781e-01
    z[3,2,6]  R1319     -2.3041759431362152e-01
    z[3,2,6]  R1320     9.8304279148578644e-02
    z[3,2,6]  R1321     6.0870878398418427e-02
    z[3,2,6]  R1322     1.5468700230121613e-01
    z[3,2,6]  R1323     -8.9504495263099670e-02
    z[3,2,6]  R1324     -4.6538898348808289e-01
    z[3,2,6]  R1325     2.3281384259462357e-02
    z[3,2,6]  R1326     1.2262260913848877e-01
    z[3,2,6]  R1327     -5.3310345858335495e-02
    z[3,2,6]  R1328     1.0644710063934326e-01
    z[3,2,6]  R1329     -4.4793951511383057e-01
    z[3,2,6]  R1330     -3.8373082876205444e-02
    z[3,2,6]  R1331     4.5984596014022827e-01
    z[3,2,6]  R1332     -4.6277174353599548e-01
    z[3,2,6]  R1333     1.7444470524787903e-01
    z[3,2,6]  R1334     -3.2454732060432434e-01
    z[3,2,6]  R1335     3.7547999620437622e-01
    z[3,2,6]  R1336     4.2403522133827209e-01
    z[3,2,6]  R1337     -1.6031830012798309e-01
    z[3,2,6]  R1338     2.3387399315834045e-01
    z[3,2,6]  R1339     2.5553089380264282e-01
    z[3,2,6]  R1340     0.0127909230068326
    z[3,2,6]  R1341     2.9407903552055359e-01
    z[3,2,6]  R1342     -1.4919905364513397e-01
    z[3,2,6]  R1343     3.4494093060493469e-01
    z[3,2,6]  R1344     4.6677622012794018e-03
    z[3,2,6]  R1345     3.8868820667266846e-01
    z[3,2,6]  R1346     1.2070067971944809e-01
    z[3,2,6]  R1347     1.8211397528648376e-01
    z[3,2,6]  R1348     3.2585906982421875e-01
    z[3,2,6]  R1349     -4.0204131603240967e-01
    z[3,2,6]  R1350     -9.8212985321879387e-03
    z[3,2,6]  R1351     -6.7253420129418373e-03
    z[3,2,6]  R1352     -2.3075561225414276e-01
    z[3,2,6]  R1353     -1.4049398899078369e-01
    z[3,2,6]  R1354     -1.4339953660964966e-01
    z[3,2,6]  R1355     1.4559175074100494e-01
    z[3,2,6]  R1356     4.5146606862545013e-03
    z[3,2,6]  R1357     1.2308930046856403e-02
    z[3,2,6]  R1358     2.7681791782379150e-01
    z[3,2,6]  R1359     1.1601343005895615e-01
    z[3,2,6]  R1360     6.5551467239856720e-02
    z[3,2,6]  R1361     -5.1159677095711231e-03
    z[3,2,6]  R1362     4.6589076519012451e-01
    z[3,2,6]  R1363     7.5365439988672733e-03
    z[3,2,6]  R1364     0.06618682295084
    z[3,2,6]  R1365     6.6418468952178955e-02
    z[3,2,6]  R1366     -2.6544502377510071e-01
    z[3,2,6]  R1367     -9.4690709374845028e-04
    z[3,2,6]  R1368     2.8251171112060547e-01
    z[3,2,6]  R1369     5.6245069950819016e-02
    z[3,2,6]  R1370     -1.4166802167892456e-02
    z[3,2,6]  R1371     2.6571869850158691e-01
    z[3,2,6]  R1372     -4.4701248407363892e-03
    z[3,2,6]  R1373     5.2134519815444946e-01
    z[3,2,6]  R1374     -3.9237537980079651e-01
    z[3,2,6]  R1375     -3.2772576808929443e-01
    z[3,2,6]  R1376     5.5867195129394531e-01
    z[3,2,6]  R1377     0.148732990026474
    z[3,2,6]  R1378     5.8001667261123657e-01
    z[3,2,6]  R1379     5.0697189569473267e-01
    z[3,2,6]  R1380     -0.0642150416970253
    z[3,2,6]  R1381     -1.2757311761379242e-01
    z[3,2,6]  R1382     4.7128215432167053e-02
    z[3,2,6]  R1383     4.3735164403915405e-01
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1384     -1
    z[3,4,0]  R1385     1
    z[3,4,0]  R1398     -1.1964192241430283e-01
    z[3,4,0]  R1399     4.0206423401832581e-01
    z[3,4,0]  R1400     -1.3556101918220520e-01
    z[3,4,0]  R1401     5.1215697079896927e-02
    z[3,4,0]  R1402     3.4780604764819145e-03
    z[3,4,0]  R1403     -1.1641890555620193e-01
    z[3,4,0]  R1404     1.5033109486103058e-01
    z[3,4,0]  R1405     4.7395345568656921e-01
    z[3,4,0]  R1406     -1.1855874210596085e-01
    z[3,4,0]  R1407     6.9723552465438843e-01
    z[3,4,0]  R1408     -2.5846174359321594e-01
    z[3,4,0]  R1409     -2.6794302463531494e-01
    z[3,4,0]  R1410     -9.2754676938056946e-02
    z[3,4,0]  R1411     -0.0926201194524765
    z[3,4,0]  R1412     -6.0131609439849854e-01
    z[3,4,0]  R1413     -3.1854861974716187e-01
    z[3,4,0]  R1414     -2.8617480397224426e-01
    z[3,4,0]  R1415     -3.4148630499839783e-01
    z[3,4,0]  R1416     -1.9698794186115265e-01
    z[3,4,0]  R1417     6.1476562172174454e-02
    z[3,4,0]  R1418     -5.3763681650161743e-01
    z[3,4,0]  R1419     2.3490490019321442e-01
    z[3,4,0]  R1420     3.8144361227750778e-02
    z[3,4,0]  R1421     0.29140505194664
    z[3,4,0]  R1422     -4.8267990350723267e-01
    z[3,4,0]  R1423     -1.6096152365207672e-01
    z[3,4,0]  R1424     -9.0267103910446167e-01
    z[3,4,0]  R1425     -8.6181628704071045e-01
    z[3,4,0]  R1426     -8.6449366807937622e-01
    z[3,4,0]  R1427     -8.3858233690261841e-01
    z[3,4,0]  R1428     -0.0920419692993164
    z[3,4,0]  R1429     -5.5750578641891479e-01
    z[3,4,0]  R1430     4.5923680067062378e-02
    z[3,4,0]  R1431     6.3780355453491211e-01
    z[3,4,0]  R1432     3.5756379365921021e-01
    z[3,4,0]  R1433     -4.3255165219306946e-01
    z[3,4,0]  R1434     6.6954243183135986e-01
    z[3,4,0]  R1435     -4.8768940567970276e-01
    z[3,4,0]  R1436     -2.2892622649669647e-01
    z[3,4,0]  R1437     -5.1787346601486206e-01
    z[3,4,0]  R1438     -5.7870741933584213e-02
    z[3,4,0]  R1439     -3.6122322082519531e-01
    z[3,4,0]  R1440     -1.3643909990787506e-01
    z[3,4,0]  R1441     -2.3454368114471436e-01
    z[3,4,0]  R1442     -7.5736775994300842e-02
    z[3,4,0]  R1443     -4.8929926007986069e-02
    z[3,4,0]  R1444     5.4211288690567017e-02
    z[3,4,0]  R1445     -3.7526279687881470e-01
    z[3,4,0]  R1446     4.6862432360649109e-01
    z[3,4,0]  R1447     1.2227475643157959e-01
    z[3,4,0]  R1448     -6.0676383972167969e-01
    z[3,4,0]  R1449     -6.0688352584838867e-01
    z[3,4,0]  R1450     -1.5276689827442169e-01
    z[3,4,0]  R1451     -3.3048603218048811e-03
    z[3,4,0]  R1452     2.5384861230850220e-01
    z[3,4,0]  R1453     -4.9653518944978714e-03
    z[3,4,0]  R1454     2.8222510591149330e-03
    z[3,4,0]  R1455     -2.4970605969429016e-01
    z[3,4,0]  R1456     3.6843252182006836e-01
    z[3,4,0]  R1457     2.6904299855232239e-02
    z[3,4,0]  R1458     2.2376640141010284e-01
    z[3,4,0]  R1459     5.5176131427288055e-02
    z[3,4,0]  R1460     -6.9494640827178955e-01
    z[3,4,0]  R1461     -6.0231178998947144e-01
    z[3,4,0]  R1462     2.7584481239318848e-01
    z[3,4,0]  R1463     2.2619657218456268e-01
    z[3,4,0]  R1464     -2.4203982949256897e-01
    z[3,4,0]  R1465     -9.5208868384361267e-02
    z[3,4,0]  R1466     -1.5311998128890991e-01
    z[3,4,0]  R1467     3.1878852844238281e-01
    z[3,4,0]  R1468     -3.1288117170333862e-01
    z[3,4,0]  R1469     -6.1639484018087387e-02
    z[3,4,0]  R1470     -5.1401168107986450e-01
    z[3,4,0]  R1471     -4.5085260272026062e-01
    z[3,4,0]  R1472     -4.4631335139274597e-01
    z[3,4,0]  R1473     -1.3485868275165558e-01
    z[3,4,0]  R1474     0.544841468334198
    z[3,4,0]  R1475     4.5743012428283691e-01
    z[3,4,0]  R1476     2.6476213335990906e-01
    z[3,4,0]  R1477     1.8688598275184631e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1386     -1
    z[3,4,1]  R1387     1
    z[3,4,1]  R1398     2.2257371246814728e-01
    z[3,4,1]  R1399     1.3655059039592743e-01
    z[3,4,1]  R1400     1.3799153268337250e-01
    z[3,4,1]  R1401     -1.4160220511257648e-02
    z[3,4,1]  R1402     2.2218354046344757e-01
    z[3,4,1]  R1403     6.1632741242647171e-02
    z[3,4,1]  R1404     2.0420733094215393e-01
    z[3,4,1]  R1405     -5.2433669567108154e-01
    z[3,4,1]  R1406     -8.0431565642356873e-02
    z[3,4,1]  R1407     -5.4815441370010376e-01
    z[3,4,1]  R1408     8.6236643791198730e-01
    z[3,4,1]  R1409     8.9285075664520264e-01
    z[3,4,1]  R1410     7.2662174701690674e-01
    z[3,4,1]  R1411     4.3325155973434448e-01
    z[3,4,1]  R1412     6.2199360132217407e-01
    z[3,4,1]  R1413     1.0795595496892929e-01
    z[3,4,1]  R1414     1.4799709618091583e-01
    z[3,4,1]  R1415     1.3905423879623413e-01
    z[3,4,1]  R1416     7.8896120190620422e-02
    z[3,4,1]  R1417     6.1751686036586761e-02
    z[3,4,1]  R1418     2.0509964227676392e-01
    z[3,4,1]  R1419     -6.4890630543231964e-02
    z[3,4,1]  R1420     2.3985694348812103e-01
    z[3,4,1]  R1421     2.2835461795330048e-01
    z[3,4,1]  R1422     -5.0408226251602173e-01
    z[3,4,1]  R1423     3.2518602907657623e-02
    z[3,4,1]  R1424     -2.5041484832763672e-01
    z[3,4,1]  R1425     -2.2475172579288483e-01
    z[3,4,1]  R1426     -1.8111494183540344e-01
    z[3,4,1]  R1427     -2.7215388417243958e-01
    z[3,4,1]  R1428     9.5345407724380493e-01
    z[3,4,1]  R1429     7.3015928268432617e-01
    z[3,4,1]  R1430     -1.1836803704500198e-01
    z[3,4,1]  R1431     2.0745410025119781e-01
    z[3,4,1]  R1432     1.6270010173320770e-01
    z[3,4,1]  R1433     -6.2895172834396362e-01
    z[3,4,1]  R1434     3.3519536256790161e-01
    z[3,4,1]  R1435     -2.7930495142936707e-01
    z[3,4,1]  R1436     -5.5695421993732452e-02
    z[3,4,1]  R1437     -5.0767141580581665e-01
    z[3,4,1]  R1438     9.0703427791595459e-02
    z[3,4,1]  R1439     -1.8035714328289032e-01
    z[3,4,1]  R1440     6.8937726318836212e-02
    z[3,4,1]  R1441     -2.4070395529270172e-01
    z[3,4,1]  R1442     1.8579232692718506e-01
    z[3,4,1]  R1443     1.3862904906272888e-01
    z[3,4,1]  R1444     1.8008811771869659e-01
    z[3,4,1]  R1445     -2.8175202012062073e-01
    z[3,4,1]  R1446     -6.8649560213088989e-01
    z[3,4,1]  R1447     -6.7654556035995483e-01
    z[3,4,1]  R1448     6.4975041151046753e-01
    z[3,4,1]  R1449     6.0589939355850220e-01
    z[3,4,1]  R1450     9.5547932386398315e-01
    z[3,4,1]  R1451     2.4890752136707306e-01
    z[3,4,1]  R1452     1.2335730716586113e-02
    z[3,4,1]  R1453     -0.477426677942276
    z[3,4,1]  R1454     -1.5880693495273590e-01
    z[3,4,1]  R1455     -3.6295831203460693e-01
    z[3,4,1]  R1456     1.5812905505299568e-02
    z[3,4,1]  R1457     -1.7650930583477020e-01
    z[3,4,1]  R1458     4.1115105152130127e-01
    z[3,4,1]  R1459     3.4792086482048035e-01
    z[3,4,1]  R1460     0.456438273191452
    z[3,4,1]  R1461     2.4656632542610168e-01
    z[3,4,1]  R1462     -4.8314133286476135e-01
    z[3,4,1]  R1463     7.0207816362380981e-01
    z[3,4,1]  R1464     6.8296289443969727e-01
    z[3,4,1]  R1465     5.4343974590301514e-01
    z[3,4,1]  R1466     5.8972358703613281e-01
    z[3,4,1]  R1467     -2.5271937251091003e-01
    z[3,4,1]  R1468     0.870954155921936
    z[3,4,1]  R1469     7.4187004566192627e-01
    z[3,4,1]  R1470     1.6852082312107086e-01
    z[3,4,1]  R1471     4.4823831319808960e-01
    z[3,4,1]  R1472     2.8948095440864563e-01
    z[3,4,1]  R1473     3.1888470053672791e-01
    z[3,4,1]  R1474     -1.2318441271781921e-01
    z[3,4,1]  R1475     -5.2266317605972290e-01
    z[3,4,1]  R1476     2.3398680984973907e-01
    z[3,4,1]  R1477     1.7198304831981659e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1388     -1
    z[3,4,2]  R1389     1
    z[3,4,2]  R1398     1.6007901728153229e-01
    z[3,4,2]  R1399     5.3326040506362915e-01
    z[3,4,2]  R1400     5.4453080892562866e-01
    z[3,4,2]  R1401     1.6188374161720276e-01
    z[3,4,2]  R1402     7.3928517103195190e-01
    z[3,4,2]  R1403     3.2165729999542236e-01
    z[3,4,2]  R1404     5.5308485031127930e-01
    z[3,4,2]  R1405     -4.5288002490997314e-01
    z[3,4,2]  R1406     6.9390898942947388e-01
    z[3,4,2]  R1407     -3.5546028614044189e-01
    z[3,4,2]  R1408     -3.0676954984664917e-01
    z[3,4,2]  R1409     -0.0371239148080349
    z[3,4,2]  R1410     -1.3091565109789371e-02
    z[3,4,2]  R1411     -4.9499917030334473e-01
    z[3,4,2]  R1412     -0.222425177693367
    z[3,4,2]  R1413     -6.6375064849853516e-01
    z[3,4,2]  R1414     -4.0637367963790894e-01
    z[3,4,2]  R1415     -0.684245228767395
    z[3,4,2]  R1416     -9.0016961097717285e-01
    z[3,4,2]  R1417     -1.3463929295539856e-01
    z[3,4,2]  R1418     1.8626801669597626e-01
    z[3,4,2]  R1419     -6.9084298610687256e-01
    z[3,4,2]  R1420     -6.0531413555145264e-01
    z[3,4,2]  R1421     -8.0756264925003052e-01
    z[3,4,2]  R1422     -4.5582181215286255e-01
    z[3,4,2]  R1423     -3.7148183584213257e-01
    z[3,4,2]  R1424     -6.4220331609249115e-02
    z[3,4,2]  R1425     1.9715829193592072e-01
    z[3,4,2]  R1426     -5.4146878421306610e-02
    z[3,4,2]  R1427     -2.3206777870655060e-02
    z[3,4,2]  R1428     -2.2958593070507050e-01
    z[3,4,2]  R1429     1.5322811901569366e-01
    z[3,4,2]  R1430     -9.5299792289733887e-01
    z[3,4,2]  R1431     -0.603747546672821
    z[3,4,2]  R1432     -8.0380862951278687e-01
    z[3,4,2]  R1433     -4.9176487326622009e-01
    z[3,4,2]  R1434     7.6304391026496887e-02
    z[3,4,2]  R1435     -0.568027675151825
    z[3,4,2]  R1436     -3.4215328097343445e-01
    z[3,4,2]  R1437     -4.1428482532501221e-01
    z[3,4,2]  R1438     2.8583189845085144e-01
    z[3,4,2]  R1439     4.1041865944862366e-01
    z[3,4,2]  R1440     6.0781556367874146e-01
    z[3,4,2]  R1441     7.0913535356521606e-01
    z[3,4,2]  R1442     6.4988970756530762e-01
    z[3,4,2]  R1443     4.4665363430976868e-01
    z[3,4,2]  R1444     -0.0573224201798439
    z[3,4,2]  R1445     7.3578923940658569e-01
    z[3,4,2]  R1446     -4.7941815853118896e-01
    z[3,4,2]  R1447     -5.1720386743545532e-01
    z[3,4,2]  R1448     -3.5617422312498093e-02
    z[3,4,2]  R1449     -1.4120461046695709e-01
    z[3,4,2]  R1450     -8.9397631585597992e-02
    z[3,4,2]  R1451     -0.627575695514679
    z[3,4,2]  R1452     -3.0603927373886108e-01
    z[3,4,2]  R1453     -0.419014036655426
    z[3,4,2]  R1454     -0.333706259727478
    z[3,4,2]  R1455     -5.6432580947875977e-01
    z[3,4,2]  R1456     -3.5146871209144592e-01
    z[3,4,2]  R1457     -3.9342594146728516e-01
    z[3,4,2]  R1458     5.5873185396194458e-01
    z[3,4,2]  R1459     4.0096721053123474e-01
    z[3,4,2]  R1460     2.2632074356079102e-01
    z[3,4,2]  R1461     2.5209259986877441e-01
    z[3,4,2]  R1462     -4.2676281929016113e-01
    z[3,4,2]  R1463     1.1735233711078763e-03
    z[3,4,2]  R1464     1.0540015250444412e-01
    z[3,4,2]  R1465     8.9570038020610809e-02
    z[3,4,2]  R1466     -3.0892717838287354e-01
    z[3,4,2]  R1467     -4.6907064318656921e-01
    z[3,4,2]  R1468     2.4958732724189758e-01
    z[3,4,2]  R1469     2.2815760970115662e-01
    z[3,4,2]  R1470     5.3504353761672974e-01
    z[3,4,2]  R1471     6.6952472925186157e-01
    z[3,4,2]  R1472     3.9554160833358765e-01
    z[3,4,2]  R1473     -2.1934132277965546e-01
    z[3,4,2]  R1474     -6.5033769607543945e-01
    z[3,4,2]  R1475     -4.0592589974403381e-01
    z[3,4,2]  R1476     -6.9633078575134277e-01
    z[3,4,2]  R1477     -6.9222939014434814e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1390     -1
    z[3,4,3]  R1391     1
    z[3,4,3]  R1398     9.0734344720840454e-01
    z[3,4,3]  R1399     6.0657733678817749e-01
    z[3,4,3]  R1400     7.1679770946502686e-01
    z[3,4,3]  R1401     9.0983533859252930e-01
    z[3,4,3]  R1402     0.408944696187973
    z[3,4,3]  R1403     8.0546975135803223e-01
    z[3,4,3]  R1404     2.9149407148361206e-01
    z[3,4,3]  R1405     -2.0121458172798157e-01
    z[3,4,3]  R1406     1.2604017555713654e-01
    z[3,4,3]  R1407     -9.3929208815097809e-02
    z[3,4,3]  R1408     1.5068401396274567e-01
    z[3,4,3]  R1409     -2.0425774157047272e-01
    z[3,4,3]  R1410     1.6447030007839203e-01
    z[3,4,3]  R1411     -6.1712962388992310e-01
    z[3,4,3]  R1412     -6.0796007513999939e-02
    z[3,4,3]  R1413     -5.2693754434585571e-01
    z[3,4,3]  R1414     -4.2322179675102234e-01
    z[3,4,3]  R1415     -2.7854594588279724e-01
    z[3,4,3]  R1416     -2.9469951987266541e-01
    z[3,4,3]  R1417     -3.3626815676689148e-01
    z[3,4,3]  R1418     4.0921539068222046e-01
    z[3,4,3]  R1419     -2.5749981403350830e-01
    z[3,4,3]  R1420     -3.5923480987548828e-01
    z[3,4,3]  R1421     -1.7536112666130066e-01
    z[3,4,3]  R1422     -1.9739560782909393e-01
    z[3,4,3]  R1423     -5.6692975759506226e-01
    z[3,4,3]  R1424     -2.6862585544586182e-01
    z[3,4,3]  R1425     -2.1962922811508179e-01
    z[3,4,3]  R1426     -1.7073485255241394e-01
    z[3,4,3]  R1427     -2.5808918476104736e-01
    z[3,4,3]  R1428     1.5992234647274017e-01
    z[3,4,3]  R1429     1.6902923583984375e-01
    z[3,4,3]  R1430     -2.3952773213386536e-01
    z[3,4,3]  R1431     -3.7652522325515747e-01
    z[3,4,3]  R1432     -2.0028272271156311e-01
    z[3,4,3]  R1433     -2.7765011787414551e-01
    z[3,4,3]  R1434     -4.0416863560676575e-01
    z[3,4,3]  R1435     -3.9246571063995361e-01
    z[3,4,3]  R1436     -0.846693754196167
    z[3,4,3]  R1437     -3.2565972208976746e-01
    z[3,4,3]  R1438     7.9734712839126587e-01
    z[3,4,3]  R1439     6.8379396200180054e-01
    z[3,4,3]  R1440     4.0485379099845886e-01
    z[3,4,3]  R1441     -6.9874495267868042e-02
    z[3,4,3]  R1442     -3.5210162401199341e-01
    z[3,4,3]  R1443     4.6901756525039673e-01
    z[3,4,3]  R1444     6.8851172924041748e-01
    z[3,4,3]  R1445     1.2063708156347275e-01
    z[3,4,3]  R1446     -1.9099628925323486e-01
    z[3,4,3]  R1447     -0.0162209402769804
    z[3,4,3]  R1448     1.4994834363460541e-01
    z[3,4,3]  R1449     8.5919030010700226e-02
    z[3,4,3]  R1450     2.9778733849525452e-02
    z[3,4,3]  R1451     -0.585460901260376
    z[3,4,3]  R1452     -6.4031469821929932e-01
    z[3,4,3]  R1453     -4.1169667243957520e-01
    z[3,4,3]  R1454     -7.3668831586837769e-01
    z[3,4,3]  R1455     3.5517036914825439e-02
    z[3,4,3]  R1456     -7.5250577926635742e-01
    z[3,4,3]  R1457     -6.9029337167739868e-01
    z[3,4,3]  R1458     1.0706377774477005e-01
    z[3,4,3]  R1459     4.1478452086448669e-01
    z[3,4,3]  R1460     7.4573658406734467e-02
    z[3,4,3]  R1461     4.4015997648239136e-01
    z[3,4,3]  R1462     -5.5497705936431885e-01
    z[3,4,3]  R1463     4.8583814501762390e-01
    z[3,4,3]  R1464     1.8936289846897125e-01
    z[3,4,3]  R1465     8.3995535969734192e-02
    z[3,4,3]  R1466     6.4312392473220825e-01
    z[3,4,3]  R1467     -4.0286022424697876e-01
    z[3,4,3]  R1468     1.5088823437690735e-01
    z[3,4,3]  R1469     2.0504210889339447e-01
    z[3,4,3]  R1470     3.8115409016609192e-01
    z[3,4,3]  R1471     -2.0081575214862823e-01
    z[3,4,3]  R1472     3.2083225250244141e-01
    z[3,4,3]  R1473     8.3555358648300171e-01
    z[3,4,3]  R1474     -3.6146077513694763e-01
    z[3,4,3]  R1475     -2.1051061153411865e-01
    z[3,4,3]  R1476     -4.5876809954643250e-01
    z[3,4,3]  R1477     -6.5730553865432739e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1392     -1
    z[3,4,4]  R1393     1
    z[3,4,4]  R1398     2.1208053454756737e-02
    z[3,4,4]  R1399     -0.158487930893898
    z[3,4,4]  R1400     0.0169528815895319
    z[3,4,4]  R1401     -3.4378603100776672e-01
    z[3,4,4]  R1402     -1.3737997412681580e-01
    z[3,4,4]  R1403     -2.7875187993049622e-01
    z[3,4,4]  R1404     9.3737430870532990e-03
    z[3,4,4]  R1405     -1.0268484055995941e-01
    z[3,4,4]  R1406     2.1089982986450195e-01
    z[3,4,4]  R1407     -1.3674362003803253e-01
    z[3,4,4]  R1408     8.0831823870539665e-03
    z[3,4,4]  R1409     2.1813374757766724e-01
    z[3,4,4]  R1410     -1.1247310787439346e-01
    z[3,4,4]  R1411     1.9123336672782898e-01
    z[3,4,4]  R1412     1.1492103338241577e-01
    z[3,4,4]  R1413     2.1364960074424744e-01
    z[3,4,4]  R1414     0.0580105260014534
    z[3,4,4]  R1415     4.8082344233989716e-02
    z[3,4,4]  R1416     5.2392229437828064e-02
    z[3,4,4]  R1417     -4.8945634625852108e-03
    z[3,4,4]  R1418     3.6185383796691895e-02
    z[3,4,4]  R1419     1.1271552741527557e-01
    z[3,4,4]  R1420     -5.3692040964961052e-03
    z[3,4,4]  R1421     1.4080798253417015e-02
    z[3,4,4]  R1422     -3.4365782141685486e-01
    z[3,4,4]  R1423     -6.8464004993438721e-01
    z[3,4,4]  R1424     1.7493329942226410e-01
    z[3,4,4]  R1425     -2.7211913466453552e-01
    z[3,4,4]  R1426     -3.3249381184577942e-01
    z[3,4,4]  R1427     -1.3458943367004395e-01
    z[3,4,4]  R1428     1.1815481819212437e-02
    z[3,4,4]  R1429     3.0346587300300598e-02
    z[3,4,4]  R1430     -1.9262244924902916e-02
    z[3,4,4]  R1431     8.2460500299930573e-02
    z[3,4,4]  R1432     -0.0631580650806427
    z[3,4,4]  R1433     2.7730926871299744e-02
    z[3,4,4]  R1434     2.4314887821674347e-02
    z[3,4,4]  R1435     -3.7103638052940369e-01
    z[3,4,4]  R1436     -0.279972106218338
    z[3,4,4]  R1437     -4.1296628117561340e-01
    z[3,4,4]  R1438     2.8962832689285278e-01
    z[3,4,4]  R1439     9.4165757298469543e-02
    z[3,4,4]  R1440     -0.375297486782074
    z[3,4,4]  R1441     -6.2481898814439774e-02
    z[3,4,4]  R1442     2.3791453242301941e-01
    z[3,4,4]  R1443     -3.4306889772415161e-01
    z[3,4,4]  R1444     -4.9269944429397583e-01
    z[3,4,4]  R1445     -2.7725201845169067e-01
    z[3,4,4]  R1446     -1.7659810185432434e-01
    z[3,4,4]  R1447     -2.8725671768188477e-01
    z[3,4,4]  R1448     1.4359951019287109e-01
    z[3,4,4]  R1449     -2.5267881155014038e-01
    z[3,4,4]  R1450     3.2495800405740738e-02
    z[3,4,4]  R1451     1.7760351300239563e-01
    z[3,4,4]  R1452     2.9704385995864868e-01
    z[3,4,4]  R1453     5.0171726942062378e-01
    z[3,4,4]  R1454     4.2885333299636841e-01
    z[3,4,4]  R1455     1.6307403147220612e-01
    z[3,4,4]  R1456     -0.385662317276001
    z[3,4,4]  R1457     -2.0439927279949188e-01
    z[3,4,4]  R1458     2.3397077620029449e-01
    z[3,4,4]  R1459     -4.3531784415245056e-01
    z[3,4,4]  R1460     0.378226101398468
    z[3,4,4]  R1461     -4.9855765700340271e-01
    z[3,4,4]  R1462     7.0312090218067169e-02
    z[3,4,4]  R1463     -2.9113510251045227e-01
    z[3,4,4]  R1464     -0.640434205532074
    z[3,4,4]  R1465     -5.1009333133697510e-01
    z[3,4,4]  R1466     -2.8283417224884033e-01
    z[3,4,4]  R1467     -5.1376384496688843e-01
    z[3,4,4]  R1468     1.2046154588460922e-01
    z[3,4,4]  R1469     -5.4465734958648682e-01
    z[3,4,4]  R1470     -1.9026456773281097e-01
    z[3,4,4]  R1471     -1.1776334047317505e-01
    z[3,4,4]  R1472     4.4609126448631287e-01
    z[3,4,4]  R1473     -2.0541222393512726e-01
    z[3,4,4]  R1474     0.0743880346417427
    z[3,4,4]  R1475     -5.3647822141647339e-01
    z[3,4,4]  R1476     -1.4164827764034271e-01
    z[3,4,4]  R1477     9.1382518410682678e-02
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1394     -1
    z[3,4,5]  R1395     1
    z[3,4,5]  R1398     -2.9314762353897095e-01
    z[3,4,5]  R1399     -3.6674866080284119e-01
    z[3,4,5]  R1400     1.9188152253627777e-01
    z[3,4,5]  R1401     -8.2696892321109772e-02
    z[3,4,5]  R1402     2.3804658651351929e-01
    z[3,4,5]  R1403     8.0359637737274170e-02
    z[3,4,5]  R1404     -3.1121543049812317e-01
    z[3,4,5]  R1405     1.6140596568584442e-01
    z[3,4,5]  R1406     -0.660844087600708
    z[3,4,5]  R1407     1.1799512058496475e-01
    z[3,4,5]  R1408     3.7678044289350510e-02
    z[3,4,5]  R1409     -1.6677133738994598e-01
    z[3,4,5]  R1410     6.4428091049194336e-01
    z[3,4,5]  R1411     3.5658633708953857e-01
    z[3,4,5]  R1412     1.4558520913124084e-01
    z[3,4,5]  R1413     -1.7941139638423920e-02
    z[3,4,5]  R1414     6.9416350126266479e-01
    z[3,4,5]  R1415     3.7060967087745667e-01
    z[3,4,5]  R1416     6.9558471441268921e-02
    z[3,4,5]  R1417     7.5775671005249023e-01
    z[3,4,5]  R1418     -6.0562163591384888e-01
    z[3,4,5]  R1419     -4.7300764918327332e-01
    z[3,4,5]  R1420     6.4526784420013428e-01
    z[3,4,5]  R1421     -5.8970566838979721e-02
    z[3,4,5]  R1422     -3.8173735141754150e-01
    z[3,4,5]  R1423     -2.1188192069530487e-01
    z[3,4,5]  R1424     4.5160077512264252e-02
    z[3,4,5]  R1425     2.0999759435653687e-01
    z[3,4,5]  R1426     2.0915111899375916e-01
    z[3,4,5]  R1427     3.5207679867744446e-01
    z[3,4,5]  R1428     8.4841158241033554e-03
    z[3,4,5]  R1429     2.6747798919677734e-01
    z[3,4,5]  R1430     1.1453200131654739e-01
    z[3,4,5]  R1431     -1.9214065372943878e-01
    z[3,4,5]  R1432     3.0960902571678162e-01
    z[3,4,5]  R1433     2.1103376150131226e-01
    z[3,4,5]  R1434     0.509830892086029
    z[3,4,5]  R1435     -2.5707918405532837e-01
    z[3,4,5]  R1436     0.0906599685549736
    z[3,4,5]  R1437     1.3356056809425354e-01
    z[3,4,5]  R1438     -4.3192145228385925e-01
    z[3,4,5]  R1439     -3.5169312357902527e-01
    z[3,4,5]  R1440     -5.3854197263717651e-01
    z[3,4,5]  R1441     -5.3042483329772949e-01
    z[3,4,5]  R1442     -5.6895679235458374e-01
    z[3,4,5]  R1443     -3.0301621556282043e-01
    z[3,4,5]  R1444     -4.4310775399208069e-01
    z[3,4,5]  R1445     3.4799691289663315e-02
    z[3,4,5]  R1446     -2.1711723878979683e-02
    z[3,4,5]  R1447     3.6115863919258118e-01
    z[3,4,5]  R1448     4.0278828144073486e-01
    z[3,4,5]  R1449     3.6516085267066956e-01
    z[3,4,5]  R1450     1.3691034913063049e-01
    z[3,4,5]  R1451     3.8916292786598206e-01
    z[3,4,5]  R1452     4.3744662404060364e-01
    z[3,4,5]  R1453     2.6634088158607483e-01
    z[3,4,5]  R1454     2.4068865180015564e-01
    z[3,4,5]  R1455     2.8285548090934753e-01
    z[3,4,5]  R1456     1.5305081009864807e-01
    z[3,4,5]  R1457     1.4244772493839264e-01
    z[3,4,5]  R1458     -4.6020811796188354e-01
    z[3,4,5]  R1459     -8.6697600781917572e-02
    z[3,4,5]  R1460     -2.4631278216838837e-01
    z[3,4,5]  R1461     2.5095903873443604e-01
    z[3,4,5]  R1462     4.2448881268501282e-01
    z[3,4,5]  R1463     -2.0095948874950409e-01
    z[3,4,5]  R1464     -8.2308724522590637e-02
    z[3,4,5]  R1465     -4.2418184876441956e-01
    z[3,4,5]  R1466     -4.5460681430995464e-03
    z[3,4,5]  R1467     2.3905214667320251e-01
    z[3,4,5]  R1468     -2.0068673789501190e-01
    z[3,4,5]  R1469     -1.6319629549980164e-01
    z[3,4,5]  R1470     -1.6506245732307434e-01
    z[3,4,5]  R1471     1.7667191103100777e-02
    z[3,4,5]  R1472     2.0985834300518036e-01
    z[3,4,5]  R1473     2.0626035332679749e-01
    z[3,4,5]  R1474     -1.1976198852062225e-01
    z[3,4,5]  R1475     1.4380528032779694e-01
    z[3,4,5]  R1476     3.9840835332870483e-01
    z[3,4,5]  R1477     -1.1201862990856171e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1396     -1
    z[3,4,6]  R1397     1
    z[3,4,6]  R1398     2.9392398893833160e-02
    z[3,4,6]  R1399     -8.8162004947662354e-02
    z[3,4,6]  R1400     -3.3935663104057312e-01
    z[3,4,6]  R1401     1.3469257950782776e-01
    z[3,4,6]  R1402     4.0162736177444458e-01
    z[3,4,6]  R1403     -3.8241699337959290e-01
    z[3,4,6]  R1404     -6.6924232244491577e-01
    z[3,4,6]  R1405     4.6717819571495056e-01
    z[3,4,6]  R1406     2.9751356691122055e-02
    z[3,4,6]  R1407     -2.1352486312389374e-01
    z[3,4,6]  R1408     2.6687702536582947e-01
    z[3,4,6]  R1409     1.1193595826625824e-01
    z[3,4,6]  R1410     0.0919094830751419
    z[3,4,6]  R1411     -1.1881686002016068e-01
    z[3,4,6]  R1412     -4.0493446588516235e-01
    z[3,4,6]  R1413     -3.5025155544281006e-01
    z[3,4,6]  R1414     -2.5829532742500305e-01
    z[3,4,6]  R1415     -4.2262068390846252e-01
    z[3,4,6]  R1416     2.2413088381290436e-01
    z[3,4,6]  R1417     -5.3570896387100220e-01
    z[3,4,6]  R1418     0.314071387052536
    z[3,4,6]  R1419     -4.0074631571769714e-01
    z[3,4,6]  R1420     -1.7076133191585541e-01
    z[3,4,6]  R1421     -4.1994345188140869e-01
    z[3,4,6]  R1422     4.8565447330474854e-02
    z[3,4,6]  R1423     4.8103256631293334e-06
    z[3,4,6]  R1424     -1.1641392111778259e-01
    z[3,4,6]  R1425     3.8770534098148346e-02
    z[3,4,6]  R1426     -1.8294635415077209e-01
    z[3,4,6]  R1427     1.1615064740180969e-01
    z[3,4,6]  R1428     6.2905430793762207e-02
    z[3,4,6]  R1429     -1.7759373784065247e-01
    z[3,4,6]  R1430     -6.9373399019241333e-02
    z[3,4,6]  R1431     1.3008493930101395e-02
    z[3,4,6]  R1432     -2.4414883553981781e-01
    z[3,4,6]  R1433     -2.3041759431362152e-01
    z[3,4,6]  R1434     9.8304279148578644e-02
    z[3,4,6]  R1435     6.0870878398418427e-02
    z[3,4,6]  R1436     1.5468700230121613e-01
    z[3,4,6]  R1437     -8.9504495263099670e-02
    z[3,4,6]  R1438     2.2819772362709045e-02
    z[3,4,6]  R1439     2.6156494021415710e-01
    z[3,4,6]  R1440     1.1140027642250061e-01
    z[3,4,6]  R1441     3.0666095018386841e-01
    z[3,4,6]  R1442     1.8192812800407410e-01
    z[3,4,6]  R1443     -5.9109717607498169e-01
    z[3,4,6]  R1444     -2.1954016387462616e-01
    z[3,4,6]  R1445     -3.8180452585220337e-01
    z[3,4,6]  R1446     -1.0552482306957245e-01
    z[3,4,6]  R1447     -2.1591672301292419e-01
    z[3,4,6]  R1448     -0.055225919932127
    z[3,4,6]  R1449     2.0017151534557343e-01
    z[3,4,6]  R1450     -1.8719619512557983e-01
    z[3,4,6]  R1451     1.3574877381324768e-01
    z[3,4,6]  R1452     -3.9006552100181580e-01
    z[3,4,6]  R1453     3.2297751307487488e-01
    z[3,4,6]  R1454     2.8081426024436951e-01
    z[3,4,6]  R1455     6.1610287427902222e-01
    z[3,4,6]  R1456     4.5302573591470718e-02
    z[3,4,6]  R1457     5.2417677640914917e-01
    z[3,4,6]  R1458     -4.3669855594635010e-01
    z[3,4,6]  R1459     -5.8827507495880127e-01
    z[3,4,6]  R1460     2.1955946087837219e-01
    z[3,4,6]  R1461     -8.7143093347549438e-02
    z[3,4,6]  R1462     -1.2338374555110931e-01
    z[3,4,6]  R1463     -3.0779343843460083e-01
    z[3,4,6]  R1464     1.0526287555694580e-01
    z[3,4,6]  R1465     4.9031114578247070e-01
    z[3,4,6]  R1466     1.9929949939250946e-01
    z[3,4,6]  R1467     -3.6205506324768066e-01
    z[3,4,6]  R1468     6.0803771018981934e-02
    z[3,4,6]  R1469     -1.6866151988506317e-01
    z[3,4,6]  R1470     -4.6086505055427551e-01
    z[3,4,6]  R1471     -3.0503043532371521e-01
    z[3,4,6]  R1472     -4.6322867274284363e-01
    z[3,4,6]  R1473     -2.2164769470691681e-01
    z[3,4,6]  R1474     3.3838397264480591e-01
    z[3,4,6]  R1475     1.2639641063287854e-03
    z[3,4,6]  R1476     3.1826782971620560e-02
    z[3,4,6]  R1477     -5.8003194630146027e-02
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1478     -1
    z[4,3,0]  R1479     1
    z[4,3,0]  R1492     -5.7870741933584213e-02
    z[4,3,0]  R1493     -3.6122322082519531e-01
    z[4,3,0]  R1494     -1.3643909990787506e-01
    z[4,3,0]  R1495     -2.3454368114471436e-01
    z[4,3,0]  R1496     -7.5736775994300842e-02
    z[4,3,0]  R1497     -4.8929926007986069e-02
    z[4,3,0]  R1498     5.4211288690567017e-02
    z[4,3,0]  R1499     -3.7526279687881470e-01
    z[4,3,0]  R1500     4.6862432360649109e-01
    z[4,3,0]  R1501     1.2227475643157959e-01
    z[4,3,0]  R1502     -6.0676383972167969e-01
    z[4,3,0]  R1503     -6.0688352584838867e-01
    z[4,3,0]  R1504     -1.5276689827442169e-01
    z[4,3,0]  R1505     -3.3048603218048811e-03
    z[4,3,0]  R1506     2.5384861230850220e-01
    z[4,3,0]  R1507     -4.9653518944978714e-03
    z[4,3,0]  R1508     2.8222510591149330e-03
    z[4,3,0]  R1509     -2.4970605969429016e-01
    z[4,3,0]  R1510     3.6843252182006836e-01
    z[4,3,0]  R1511     2.6904299855232239e-02
    z[4,3,0]  R1512     2.2376640141010284e-01
    z[4,3,0]  R1513     5.5176131427288055e-02
    z[4,3,0]  R1514     -6.9494640827178955e-01
    z[4,3,0]  R1515     -6.0231178998947144e-01
    z[4,3,0]  R1516     2.7584481239318848e-01
    z[4,3,0]  R1517     2.2619657218456268e-01
    z[4,3,0]  R1518     -2.4203982949256897e-01
    z[4,3,0]  R1519     -9.5208868384361267e-02
    z[4,3,0]  R1520     -1.5311998128890991e-01
    z[4,3,0]  R1521     3.1878852844238281e-01
    z[4,3,0]  R1522     -3.1288117170333862e-01
    z[4,3,0]  R1523     -6.1639484018087387e-02
    z[4,3,0]  R1524     -5.1401168107986450e-01
    z[4,3,0]  R1525     -4.5085260272026062e-01
    z[4,3,0]  R1526     -4.4631335139274597e-01
    z[4,3,0]  R1527     -1.3485868275165558e-01
    z[4,3,0]  R1528     0.544841468334198
    z[4,3,0]  R1529     4.5743012428283691e-01
    z[4,3,0]  R1530     2.6476213335990906e-01
    z[4,3,0]  R1531     1.8688598275184631e-01
    z[4,3,0]  R1532     -1.1964192241430283e-01
    z[4,3,0]  R1533     4.0206423401832581e-01
    z[4,3,0]  R1534     -1.3556101918220520e-01
    z[4,3,0]  R1535     5.1215697079896927e-02
    z[4,3,0]  R1536     3.4780604764819145e-03
    z[4,3,0]  R1537     -1.1641890555620193e-01
    z[4,3,0]  R1538     1.5033109486103058e-01
    z[4,3,0]  R1539     4.7395345568656921e-01
    z[4,3,0]  R1540     -1.1855874210596085e-01
    z[4,3,0]  R1541     6.9723552465438843e-01
    z[4,3,0]  R1542     -2.5846174359321594e-01
    z[4,3,0]  R1543     -2.6794302463531494e-01
    z[4,3,0]  R1544     -9.2754676938056946e-02
    z[4,3,0]  R1545     -0.0926201194524765
    z[4,3,0]  R1546     -6.0131609439849854e-01
    z[4,3,0]  R1547     -3.1854861974716187e-01
    z[4,3,0]  R1548     -2.8617480397224426e-01
    z[4,3,0]  R1549     -3.4148630499839783e-01
    z[4,3,0]  R1550     -1.9698794186115265e-01
    z[4,3,0]  R1551     6.1476562172174454e-02
    z[4,3,0]  R1552     -5.3763681650161743e-01
    z[4,3,0]  R1553     2.3490490019321442e-01
    z[4,3,0]  R1554     3.8144361227750778e-02
    z[4,3,0]  R1555     0.29140505194664
    z[4,3,0]  R1556     -4.8267990350723267e-01
    z[4,3,0]  R1557     -1.6096152365207672e-01
    z[4,3,0]  R1558     -9.0267103910446167e-01
    z[4,3,0]  R1559     -8.6181628704071045e-01
    z[4,3,0]  R1560     -8.6449366807937622e-01
    z[4,3,0]  R1561     -8.3858233690261841e-01
    z[4,3,0]  R1562     -0.0920419692993164
    z[4,3,0]  R1563     -5.5750578641891479e-01
    z[4,3,0]  R1564     4.5923680067062378e-02
    z[4,3,0]  R1565     6.3780355453491211e-01
    z[4,3,0]  R1566     3.5756379365921021e-01
    z[4,3,0]  R1567     -4.3255165219306946e-01
    z[4,3,0]  R1568     6.6954243183135986e-01
    z[4,3,0]  R1569     -4.8768940567970276e-01
    z[4,3,0]  R1570     -2.2892622649669647e-01
    z[4,3,0]  R1571     -5.1787346601486206e-01
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1480     -1
    z[4,3,1]  R1481     1
    z[4,3,1]  R1492     9.0703427791595459e-02
    z[4,3,1]  R1493     -1.8035714328289032e-01
    z[4,3,1]  R1494     6.8937726318836212e-02
    z[4,3,1]  R1495     -2.4070395529270172e-01
    z[4,3,1]  R1496     1.8579232692718506e-01
    z[4,3,1]  R1497     1.3862904906272888e-01
    z[4,3,1]  R1498     1.8008811771869659e-01
    z[4,3,1]  R1499     -2.8175202012062073e-01
    z[4,3,1]  R1500     -6.8649560213088989e-01
    z[4,3,1]  R1501     -6.7654556035995483e-01
    z[4,3,1]  R1502     6.4975041151046753e-01
    z[4,3,1]  R1503     6.0589939355850220e-01
    z[4,3,1]  R1504     9.5547932386398315e-01
    z[4,3,1]  R1505     2.4890752136707306e-01
    z[4,3,1]  R1506     1.2335730716586113e-02
    z[4,3,1]  R1507     -0.477426677942276
    z[4,3,1]  R1508     -1.5880693495273590e-01
    z[4,3,1]  R1509     -3.6295831203460693e-01
    z[4,3,1]  R1510     1.5812905505299568e-02
    z[4,3,1]  R1511     -1.7650930583477020e-01
    z[4,3,1]  R1512     4.1115105152130127e-01
    z[4,3,1]  R1513     3.4792086482048035e-01
    z[4,3,1]  R1514     0.456438273191452
    z[4,3,1]  R1515     2.4656632542610168e-01
    z[4,3,1]  R1516     -4.8314133286476135e-01
    z[4,3,1]  R1517     7.0207816362380981e-01
    z[4,3,1]  R1518     6.8296289443969727e-01
    z[4,3,1]  R1519     5.4343974590301514e-01
    z[4,3,1]  R1520     5.8972358703613281e-01
    z[4,3,1]  R1521     -2.5271937251091003e-01
    z[4,3,1]  R1522     0.870954155921936
    z[4,3,1]  R1523     7.4187004566192627e-01
    z[4,3,1]  R1524     1.6852082312107086e-01
    z[4,3,1]  R1525     4.4823831319808960e-01
    z[4,3,1]  R1526     2.8948095440864563e-01
    z[4,3,1]  R1527     3.1888470053672791e-01
    z[4,3,1]  R1528     -1.2318441271781921e-01
    z[4,3,1]  R1529     -5.2266317605972290e-01
    z[4,3,1]  R1530     2.3398680984973907e-01
    z[4,3,1]  R1531     1.7198304831981659e-01
    z[4,3,1]  R1532     2.2257371246814728e-01
    z[4,3,1]  R1533     1.3655059039592743e-01
    z[4,3,1]  R1534     1.3799153268337250e-01
    z[4,3,1]  R1535     -1.4160220511257648e-02
    z[4,3,1]  R1536     2.2218354046344757e-01
    z[4,3,1]  R1537     6.1632741242647171e-02
    z[4,3,1]  R1538     2.0420733094215393e-01
    z[4,3,1]  R1539     -5.2433669567108154e-01
    z[4,3,1]  R1540     -8.0431565642356873e-02
    z[4,3,1]  R1541     -5.4815441370010376e-01
    z[4,3,1]  R1542     8.6236643791198730e-01
    z[4,3,1]  R1543     8.9285075664520264e-01
    z[4,3,1]  R1544     7.2662174701690674e-01
    z[4,3,1]  R1545     4.3325155973434448e-01
    z[4,3,1]  R1546     6.2199360132217407e-01
    z[4,3,1]  R1547     1.0795595496892929e-01
    z[4,3,1]  R1548     1.4799709618091583e-01
    z[4,3,1]  R1549     1.3905423879623413e-01
    z[4,3,1]  R1550     7.8896120190620422e-02
    z[4,3,1]  R1551     6.1751686036586761e-02
    z[4,3,1]  R1552     2.0509964227676392e-01
    z[4,3,1]  R1553     -6.4890630543231964e-02
    z[4,3,1]  R1554     2.3985694348812103e-01
    z[4,3,1]  R1555     2.2835461795330048e-01
    z[4,3,1]  R1556     -5.0408226251602173e-01
    z[4,3,1]  R1557     3.2518602907657623e-02
    z[4,3,1]  R1558     -2.5041484832763672e-01
    z[4,3,1]  R1559     -2.2475172579288483e-01
    z[4,3,1]  R1560     -1.8111494183540344e-01
    z[4,3,1]  R1561     -2.7215388417243958e-01
    z[4,3,1]  R1562     9.5345407724380493e-01
    z[4,3,1]  R1563     7.3015928268432617e-01
    z[4,3,1]  R1564     -1.1836803704500198e-01
    z[4,3,1]  R1565     2.0745410025119781e-01
    z[4,3,1]  R1566     1.6270010173320770e-01
    z[4,3,1]  R1567     -6.2895172834396362e-01
    z[4,3,1]  R1568     3.3519536256790161e-01
    z[4,3,1]  R1569     -2.7930495142936707e-01
    z[4,3,1]  R1570     -5.5695421993732452e-02
    z[4,3,1]  R1571     -5.0767141580581665e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1482     -1
    z[4,3,2]  R1483     1
    z[4,3,2]  R1492     2.8583189845085144e-01
    z[4,3,2]  R1493     4.1041865944862366e-01
    z[4,3,2]  R1494     6.0781556367874146e-01
    z[4,3,2]  R1495     7.0913535356521606e-01
    z[4,3,2]  R1496     6.4988970756530762e-01
    z[4,3,2]  R1497     4.4665363430976868e-01
    z[4,3,2]  R1498     -0.0573224201798439
    z[4,3,2]  R1499     7.3578923940658569e-01
    z[4,3,2]  R1500     -4.7941815853118896e-01
    z[4,3,2]  R1501     -5.1720386743545532e-01
    z[4,3,2]  R1502     -3.5617422312498093e-02
    z[4,3,2]  R1503     -1.4120461046695709e-01
    z[4,3,2]  R1504     -8.9397631585597992e-02
    z[4,3,2]  R1505     -0.627575695514679
    z[4,3,2]  R1506     -3.0603927373886108e-01
    z[4,3,2]  R1507     -0.419014036655426
    z[4,3,2]  R1508     -0.333706259727478
    z[4,3,2]  R1509     -5.6432580947875977e-01
    z[4,3,2]  R1510     -3.5146871209144592e-01
    z[4,3,2]  R1511     -3.9342594146728516e-01
    z[4,3,2]  R1512     5.5873185396194458e-01
    z[4,3,2]  R1513     4.0096721053123474e-01
    z[4,3,2]  R1514     2.2632074356079102e-01
    z[4,3,2]  R1515     2.5209259986877441e-01
    z[4,3,2]  R1516     -4.2676281929016113e-01
    z[4,3,2]  R1517     1.1735233711078763e-03
    z[4,3,2]  R1518     1.0540015250444412e-01
    z[4,3,2]  R1519     8.9570038020610809e-02
    z[4,3,2]  R1520     -3.0892717838287354e-01
    z[4,3,2]  R1521     -4.6907064318656921e-01
    z[4,3,2]  R1522     2.4958732724189758e-01
    z[4,3,2]  R1523     2.2815760970115662e-01
    z[4,3,2]  R1524     5.3504353761672974e-01
    z[4,3,2]  R1525     6.6952472925186157e-01
    z[4,3,2]  R1526     3.9554160833358765e-01
    z[4,3,2]  R1527     -2.1934132277965546e-01
    z[4,3,2]  R1528     -6.5033769607543945e-01
    z[4,3,2]  R1529     -4.0592589974403381e-01
    z[4,3,2]  R1530     -6.9633078575134277e-01
    z[4,3,2]  R1531     -6.9222939014434814e-01
    z[4,3,2]  R1532     1.6007901728153229e-01
    z[4,3,2]  R1533     5.3326040506362915e-01
    z[4,3,2]  R1534     5.4453080892562866e-01
    z[4,3,2]  R1535     1.6188374161720276e-01
    z[4,3,2]  R1536     7.3928517103195190e-01
    z[4,3,2]  R1537     3.2165729999542236e-01
    z[4,3,2]  R1538     5.5308485031127930e-01
    z[4,3,2]  R1539     -4.5288002490997314e-01
    z[4,3,2]  R1540     6.9390898942947388e-01
    z[4,3,2]  R1541     -3.5546028614044189e-01
    z[4,3,2]  R1542     -3.0676954984664917e-01
    z[4,3,2]  R1543     -0.0371239148080349
    z[4,3,2]  R1544     -1.3091565109789371e-02
    z[4,3,2]  R1545     -4.9499917030334473e-01
    z[4,3,2]  R1546     -0.222425177693367
    z[4,3,2]  R1547     -6.6375064849853516e-01
    z[4,3,2]  R1548     -4.0637367963790894e-01
    z[4,3,2]  R1549     -0.684245228767395
    z[4,3,2]  R1550     -9.0016961097717285e-01
    z[4,3,2]  R1551     -1.3463929295539856e-01
    z[4,3,2]  R1552     1.8626801669597626e-01
    z[4,3,2]  R1553     -6.9084298610687256e-01
    z[4,3,2]  R1554     -6.0531413555145264e-01
    z[4,3,2]  R1555     -8.0756264925003052e-01
    z[4,3,2]  R1556     -4.5582181215286255e-01
    z[4,3,2]  R1557     -3.7148183584213257e-01
    z[4,3,2]  R1558     -6.4220331609249115e-02
    z[4,3,2]  R1559     1.9715829193592072e-01
    z[4,3,2]  R1560     -5.4146878421306610e-02
    z[4,3,2]  R1561     -2.3206777870655060e-02
    z[4,3,2]  R1562     -2.2958593070507050e-01
    z[4,3,2]  R1563     1.5322811901569366e-01
    z[4,3,2]  R1564     -9.5299792289733887e-01
    z[4,3,2]  R1565     -0.603747546672821
    z[4,3,2]  R1566     -8.0380862951278687e-01
    z[4,3,2]  R1567     -4.9176487326622009e-01
    z[4,3,2]  R1568     7.6304391026496887e-02
    z[4,3,2]  R1569     -0.568027675151825
    z[4,3,2]  R1570     -3.4215328097343445e-01
    z[4,3,2]  R1571     -4.1428482532501221e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1484     -1
    z[4,3,3]  R1485     1
    z[4,3,3]  R1492     7.9734712839126587e-01
    z[4,3,3]  R1493     6.8379396200180054e-01
    z[4,3,3]  R1494     4.0485379099845886e-01
    z[4,3,3]  R1495     -6.9874495267868042e-02
    z[4,3,3]  R1496     -3.5210162401199341e-01
    z[4,3,3]  R1497     4.6901756525039673e-01
    z[4,3,3]  R1498     6.8851172924041748e-01
    z[4,3,3]  R1499     1.2063708156347275e-01
    z[4,3,3]  R1500     -1.9099628925323486e-01
    z[4,3,3]  R1501     -0.0162209402769804
    z[4,3,3]  R1502     1.4994834363460541e-01
    z[4,3,3]  R1503     8.5919030010700226e-02
    z[4,3,3]  R1504     2.9778733849525452e-02
    z[4,3,3]  R1505     -0.585460901260376
    z[4,3,3]  R1506     -6.4031469821929932e-01
    z[4,3,3]  R1507     -4.1169667243957520e-01
    z[4,3,3]  R1508     -7.3668831586837769e-01
    z[4,3,3]  R1509     3.5517036914825439e-02
    z[4,3,3]  R1510     -7.5250577926635742e-01
    z[4,3,3]  R1511     -6.9029337167739868e-01
    z[4,3,3]  R1512     1.0706377774477005e-01
    z[4,3,3]  R1513     4.1478452086448669e-01
    z[4,3,3]  R1514     7.4573658406734467e-02
    z[4,3,3]  R1515     4.4015997648239136e-01
    z[4,3,3]  R1516     -5.5497705936431885e-01
    z[4,3,3]  R1517     4.8583814501762390e-01
    z[4,3,3]  R1518     1.8936289846897125e-01
    z[4,3,3]  R1519     8.3995535969734192e-02
    z[4,3,3]  R1520     6.4312392473220825e-01
    z[4,3,3]  R1521     -4.0286022424697876e-01
    z[4,3,3]  R1522     1.5088823437690735e-01
    z[4,3,3]  R1523     2.0504210889339447e-01
    z[4,3,3]  R1524     3.8115409016609192e-01
    z[4,3,3]  R1525     -2.0081575214862823e-01
    z[4,3,3]  R1526     3.2083225250244141e-01
    z[4,3,3]  R1527     8.3555358648300171e-01
    z[4,3,3]  R1528     -3.6146077513694763e-01
    z[4,3,3]  R1529     -2.1051061153411865e-01
    z[4,3,3]  R1530     -4.5876809954643250e-01
    z[4,3,3]  R1531     -6.5730553865432739e-01
    z[4,3,3]  R1532     9.0734344720840454e-01
    z[4,3,3]  R1533     6.0657733678817749e-01
    z[4,3,3]  R1534     7.1679770946502686e-01
    z[4,3,3]  R1535     9.0983533859252930e-01
    z[4,3,3]  R1536     0.408944696187973
    z[4,3,3]  R1537     8.0546975135803223e-01
    z[4,3,3]  R1538     2.9149407148361206e-01
    z[4,3,3]  R1539     -2.0121458172798157e-01
    z[4,3,3]  R1540     1.2604017555713654e-01
    z[4,3,3]  R1541     -9.3929208815097809e-02
    z[4,3,3]  R1542     1.5068401396274567e-01
    z[4,3,3]  R1543     -2.0425774157047272e-01
    z[4,3,3]  R1544     1.6447030007839203e-01
    z[4,3,3]  R1545     -6.1712962388992310e-01
    z[4,3,3]  R1546     -6.0796007513999939e-02
    z[4,3,3]  R1547     -5.2693754434585571e-01
    z[4,3,3]  R1548     -4.2322179675102234e-01
    z[4,3,3]  R1549     -2.7854594588279724e-01
    z[4,3,3]  R1550     -2.9469951987266541e-01
    z[4,3,3]  R1551     -3.3626815676689148e-01
    z[4,3,3]  R1552     4.0921539068222046e-01
    z[4,3,3]  R1553     -2.5749981403350830e-01
    z[4,3,3]  R1554     -3.5923480987548828e-01
    z[4,3,3]  R1555     -1.7536112666130066e-01
    z[4,3,3]  R1556     -1.9739560782909393e-01
    z[4,3,3]  R1557     -5.6692975759506226e-01
    z[4,3,3]  R1558     -2.6862585544586182e-01
    z[4,3,3]  R1559     -2.1962922811508179e-01
    z[4,3,3]  R1560     -1.7073485255241394e-01
    z[4,3,3]  R1561     -2.5808918476104736e-01
    z[4,3,3]  R1562     1.5992234647274017e-01
    z[4,3,3]  R1563     1.6902923583984375e-01
    z[4,3,3]  R1564     -2.3952773213386536e-01
    z[4,3,3]  R1565     -3.7652522325515747e-01
    z[4,3,3]  R1566     -2.0028272271156311e-01
    z[4,3,3]  R1567     -2.7765011787414551e-01
    z[4,3,3]  R1568     -4.0416863560676575e-01
    z[4,3,3]  R1569     -3.9246571063995361e-01
    z[4,3,3]  R1570     -0.846693754196167
    z[4,3,3]  R1571     -3.2565972208976746e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1486     -1
    z[4,3,4]  R1487     1
    z[4,3,4]  R1492     2.8962832689285278e-01
    z[4,3,4]  R1493     9.4165757298469543e-02
    z[4,3,4]  R1494     -0.375297486782074
    z[4,3,4]  R1495     -6.2481898814439774e-02
    z[4,3,4]  R1496     2.3791453242301941e-01
    z[4,3,4]  R1497     -3.4306889772415161e-01
    z[4,3,4]  R1498     -4.9269944429397583e-01
    z[4,3,4]  R1499     -2.7725201845169067e-01
    z[4,3,4]  R1500     -1.7659810185432434e-01
    z[4,3,4]  R1501     -2.8725671768188477e-01
    z[4,3,4]  R1502     1.4359951019287109e-01
    z[4,3,4]  R1503     -2.5267881155014038e-01
    z[4,3,4]  R1504     3.2495800405740738e-02
    z[4,3,4]  R1505     1.7760351300239563e-01
    z[4,3,4]  R1506     2.9704385995864868e-01
    z[4,3,4]  R1507     5.0171726942062378e-01
    z[4,3,4]  R1508     4.2885333299636841e-01
    z[4,3,4]  R1509     1.6307403147220612e-01
    z[4,3,4]  R1510     -0.385662317276001
    z[4,3,4]  R1511     -2.0439927279949188e-01
    z[4,3,4]  R1512     2.3397077620029449e-01
    z[4,3,4]  R1513     -4.3531784415245056e-01
    z[4,3,4]  R1514     0.378226101398468
    z[4,3,4]  R1515     -4.9855765700340271e-01
    z[4,3,4]  R1516     7.0312090218067169e-02
    z[4,3,4]  R1517     -2.9113510251045227e-01
    z[4,3,4]  R1518     -0.640434205532074
    z[4,3,4]  R1519     -5.1009333133697510e-01
    z[4,3,4]  R1520     -2.8283417224884033e-01
    z[4,3,4]  R1521     -5.1376384496688843e-01
    z[4,3,4]  R1522     1.2046154588460922e-01
    z[4,3,4]  R1523     -5.4465734958648682e-01
    z[4,3,4]  R1524     -1.9026456773281097e-01
    z[4,3,4]  R1525     -1.1776334047317505e-01
    z[4,3,4]  R1526     4.4609126448631287e-01
    z[4,3,4]  R1527     -2.0541222393512726e-01
    z[4,3,4]  R1528     0.0743880346417427
    z[4,3,4]  R1529     -5.3647822141647339e-01
    z[4,3,4]  R1530     -1.4164827764034271e-01
    z[4,3,4]  R1531     9.1382518410682678e-02
    z[4,3,4]  R1532     2.1208053454756737e-02
    z[4,3,4]  R1533     -0.158487930893898
    z[4,3,4]  R1534     0.0169528815895319
    z[4,3,4]  R1535     -3.4378603100776672e-01
    z[4,3,4]  R1536     -1.3737997412681580e-01
    z[4,3,4]  R1537     -2.7875187993049622e-01
    z[4,3,4]  R1538     9.3737430870532990e-03
    z[4,3,4]  R1539     -1.0268484055995941e-01
    z[4,3,4]  R1540     2.1089982986450195e-01
    z[4,3,4]  R1541     -1.3674362003803253e-01
    z[4,3,4]  R1542     8.0831823870539665e-03
    z[4,3,4]  R1543     2.1813374757766724e-01
    z[4,3,4]  R1544     -1.1247310787439346e-01
    z[4,3,4]  R1545     1.9123336672782898e-01
    z[4,3,4]  R1546     1.1492103338241577e-01
    z[4,3,4]  R1547     2.1364960074424744e-01
    z[4,3,4]  R1548     0.0580105260014534
    z[4,3,4]  R1549     4.8082344233989716e-02
    z[4,3,4]  R1550     5.2392229437828064e-02
    z[4,3,4]  R1551     -4.8945634625852108e-03
    z[4,3,4]  R1552     3.6185383796691895e-02
    z[4,3,4]  R1553     1.1271552741527557e-01
    z[4,3,4]  R1554     -5.3692040964961052e-03
    z[4,3,4]  R1555     1.4080798253417015e-02
    z[4,3,4]  R1556     -3.4365782141685486e-01
    z[4,3,4]  R1557     -6.8464004993438721e-01
    z[4,3,4]  R1558     1.7493329942226410e-01
    z[4,3,4]  R1559     -2.7211913466453552e-01
    z[4,3,4]  R1560     -3.3249381184577942e-01
    z[4,3,4]  R1561     -1.3458943367004395e-01
    z[4,3,4]  R1562     1.1815481819212437e-02
    z[4,3,4]  R1563     3.0346587300300598e-02
    z[4,3,4]  R1564     -1.9262244924902916e-02
    z[4,3,4]  R1565     8.2460500299930573e-02
    z[4,3,4]  R1566     -0.0631580650806427
    z[4,3,4]  R1567     2.7730926871299744e-02
    z[4,3,4]  R1568     2.4314887821674347e-02
    z[4,3,4]  R1569     -3.7103638052940369e-01
    z[4,3,4]  R1570     -0.279972106218338
    z[4,3,4]  R1571     -4.1296628117561340e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1488     -1
    z[4,3,5]  R1489     1
    z[4,3,5]  R1492     -4.3192145228385925e-01
    z[4,3,5]  R1493     -3.5169312357902527e-01
    z[4,3,5]  R1494     -5.3854197263717651e-01
    z[4,3,5]  R1495     -5.3042483329772949e-01
    z[4,3,5]  R1496     -5.6895679235458374e-01
    z[4,3,5]  R1497     -3.0301621556282043e-01
    z[4,3,5]  R1498     -4.4310775399208069e-01
    z[4,3,5]  R1499     3.4799691289663315e-02
    z[4,3,5]  R1500     -2.1711723878979683e-02
    z[4,3,5]  R1501     3.6115863919258118e-01
    z[4,3,5]  R1502     4.0278828144073486e-01
    z[4,3,5]  R1503     3.6516085267066956e-01
    z[4,3,5]  R1504     1.3691034913063049e-01
    z[4,3,5]  R1505     3.8916292786598206e-01
    z[4,3,5]  R1506     4.3744662404060364e-01
    z[4,3,5]  R1507     2.6634088158607483e-01
    z[4,3,5]  R1508     2.4068865180015564e-01
    z[4,3,5]  R1509     2.8285548090934753e-01
    z[4,3,5]  R1510     1.5305081009864807e-01
    z[4,3,5]  R1511     1.4244772493839264e-01
    z[4,3,5]  R1512     -4.6020811796188354e-01
    z[4,3,5]  R1513     -8.6697600781917572e-02
    z[4,3,5]  R1514     -2.4631278216838837e-01
    z[4,3,5]  R1515     2.5095903873443604e-01
    z[4,3,5]  R1516     4.2448881268501282e-01
    z[4,3,5]  R1517     -2.0095948874950409e-01
    z[4,3,5]  R1518     -8.2308724522590637e-02
    z[4,3,5]  R1519     -4.2418184876441956e-01
    z[4,3,5]  R1520     -4.5460681430995464e-03
    z[4,3,5]  R1521     2.3905214667320251e-01
    z[4,3,5]  R1522     -2.0068673789501190e-01
    z[4,3,5]  R1523     -1.6319629549980164e-01
    z[4,3,5]  R1524     -1.6506245732307434e-01
    z[4,3,5]  R1525     1.7667191103100777e-02
    z[4,3,5]  R1526     2.0985834300518036e-01
    z[4,3,5]  R1527     2.0626035332679749e-01
    z[4,3,5]  R1528     -1.1976198852062225e-01
    z[4,3,5]  R1529     1.4380528032779694e-01
    z[4,3,5]  R1530     3.9840835332870483e-01
    z[4,3,5]  R1531     -1.1201862990856171e-01
    z[4,3,5]  R1532     -2.9314762353897095e-01
    z[4,3,5]  R1533     -3.6674866080284119e-01
    z[4,3,5]  R1534     1.9188152253627777e-01
    z[4,3,5]  R1535     -8.2696892321109772e-02
    z[4,3,5]  R1536     2.3804658651351929e-01
    z[4,3,5]  R1537     8.0359637737274170e-02
    z[4,3,5]  R1538     -3.1121543049812317e-01
    z[4,3,5]  R1539     1.6140596568584442e-01
    z[4,3,5]  R1540     -0.660844087600708
    z[4,3,5]  R1541     1.1799512058496475e-01
    z[4,3,5]  R1542     3.7678044289350510e-02
    z[4,3,5]  R1543     -1.6677133738994598e-01
    z[4,3,5]  R1544     6.4428091049194336e-01
    z[4,3,5]  R1545     3.5658633708953857e-01
    z[4,3,5]  R1546     1.4558520913124084e-01
    z[4,3,5]  R1547     -1.7941139638423920e-02
    z[4,3,5]  R1548     6.9416350126266479e-01
    z[4,3,5]  R1549     3.7060967087745667e-01
    z[4,3,5]  R1550     6.9558471441268921e-02
    z[4,3,5]  R1551     7.5775671005249023e-01
    z[4,3,5]  R1552     -6.0562163591384888e-01
    z[4,3,5]  R1553     -4.7300764918327332e-01
    z[4,3,5]  R1554     6.4526784420013428e-01
    z[4,3,5]  R1555     -5.8970566838979721e-02
    z[4,3,5]  R1556     -3.8173735141754150e-01
    z[4,3,5]  R1557     -2.1188192069530487e-01
    z[4,3,5]  R1558     4.5160077512264252e-02
    z[4,3,5]  R1559     2.0999759435653687e-01
    z[4,3,5]  R1560     2.0915111899375916e-01
    z[4,3,5]  R1561     3.5207679867744446e-01
    z[4,3,5]  R1562     8.4841158241033554e-03
    z[4,3,5]  R1563     2.6747798919677734e-01
    z[4,3,5]  R1564     1.1453200131654739e-01
    z[4,3,5]  R1565     -1.9214065372943878e-01
    z[4,3,5]  R1566     3.0960902571678162e-01
    z[4,3,5]  R1567     2.1103376150131226e-01
    z[4,3,5]  R1568     0.509830892086029
    z[4,3,5]  R1569     -2.5707918405532837e-01
    z[4,3,5]  R1570     0.0906599685549736
    z[4,3,5]  R1571     1.3356056809425354e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1490     -1
    z[4,3,6]  R1491     1
    z[4,3,6]  R1492     2.2819772362709045e-02
    z[4,3,6]  R1493     2.6156494021415710e-01
    z[4,3,6]  R1494     1.1140027642250061e-01
    z[4,3,6]  R1495     3.0666095018386841e-01
    z[4,3,6]  R1496     1.8192812800407410e-01
    z[4,3,6]  R1497     -5.9109717607498169e-01
    z[4,3,6]  R1498     -2.1954016387462616e-01
    z[4,3,6]  R1499     -3.8180452585220337e-01
    z[4,3,6]  R1500     -1.0552482306957245e-01
    z[4,3,6]  R1501     -2.1591672301292419e-01
    z[4,3,6]  R1502     -0.055225919932127
    z[4,3,6]  R1503     2.0017151534557343e-01
    z[4,3,6]  R1504     -1.8719619512557983e-01
    z[4,3,6]  R1505     1.3574877381324768e-01
    z[4,3,6]  R1506     -3.9006552100181580e-01
    z[4,3,6]  R1507     3.2297751307487488e-01
    z[4,3,6]  R1508     2.8081426024436951e-01
    z[4,3,6]  R1509     6.1610287427902222e-01
    z[4,3,6]  R1510     4.5302573591470718e-02
    z[4,3,6]  R1511     5.2417677640914917e-01
    z[4,3,6]  R1512     -4.3669855594635010e-01
    z[4,3,6]  R1513     -5.8827507495880127e-01
    z[4,3,6]  R1514     2.1955946087837219e-01
    z[4,3,6]  R1515     -8.7143093347549438e-02
    z[4,3,6]  R1516     -1.2338374555110931e-01
    z[4,3,6]  R1517     -3.0779343843460083e-01
    z[4,3,6]  R1518     1.0526287555694580e-01
    z[4,3,6]  R1519     4.9031114578247070e-01
    z[4,3,6]  R1520     1.9929949939250946e-01
    z[4,3,6]  R1521     -3.6205506324768066e-01
    z[4,3,6]  R1522     6.0803771018981934e-02
    z[4,3,6]  R1523     -1.6866151988506317e-01
    z[4,3,6]  R1524     -4.6086505055427551e-01
    z[4,3,6]  R1525     -3.0503043532371521e-01
    z[4,3,6]  R1526     -4.6322867274284363e-01
    z[4,3,6]  R1527     -2.2164769470691681e-01
    z[4,3,6]  R1528     3.3838397264480591e-01
    z[4,3,6]  R1529     1.2639641063287854e-03
    z[4,3,6]  R1530     3.1826782971620560e-02
    z[4,3,6]  R1531     -5.8003194630146027e-02
    z[4,3,6]  R1532     2.9392398893833160e-02
    z[4,3,6]  R1533     -8.8162004947662354e-02
    z[4,3,6]  R1534     -3.3935663104057312e-01
    z[4,3,6]  R1535     1.3469257950782776e-01
    z[4,3,6]  R1536     4.0162736177444458e-01
    z[4,3,6]  R1537     -3.8241699337959290e-01
    z[4,3,6]  R1538     -6.6924232244491577e-01
    z[4,3,6]  R1539     4.6717819571495056e-01
    z[4,3,6]  R1540     2.9751356691122055e-02
    z[4,3,6]  R1541     -2.1352486312389374e-01
    z[4,3,6]  R1542     2.6687702536582947e-01
    z[4,3,6]  R1543     1.1193595826625824e-01
    z[4,3,6]  R1544     0.0919094830751419
    z[4,3,6]  R1545     -1.1881686002016068e-01
    z[4,3,6]  R1546     -4.0493446588516235e-01
    z[4,3,6]  R1547     -3.5025155544281006e-01
    z[4,3,6]  R1548     -2.5829532742500305e-01
    z[4,3,6]  R1549     -4.2262068390846252e-01
    z[4,3,6]  R1550     2.2413088381290436e-01
    z[4,3,6]  R1551     -5.3570896387100220e-01
    z[4,3,6]  R1552     0.314071387052536
    z[4,3,6]  R1553     -4.0074631571769714e-01
    z[4,3,6]  R1554     -1.7076133191585541e-01
    z[4,3,6]  R1555     -4.1994345188140869e-01
    z[4,3,6]  R1556     4.8565447330474854e-02
    z[4,3,6]  R1557     4.8103256631293334e-06
    z[4,3,6]  R1558     -1.1641392111778259e-01
    z[4,3,6]  R1559     3.8770534098148346e-02
    z[4,3,6]  R1560     -1.8294635415077209e-01
    z[4,3,6]  R1561     1.1615064740180969e-01
    z[4,3,6]  R1562     6.2905430793762207e-02
    z[4,3,6]  R1563     -1.7759373784065247e-01
    z[4,3,6]  R1564     -6.9373399019241333e-02
    z[4,3,6]  R1565     1.3008493930101395e-02
    z[4,3,6]  R1566     -2.4414883553981781e-01
    z[4,3,6]  R1567     -2.3041759431362152e-01
    z[4,3,6]  R1568     9.8304279148578644e-02
    z[4,3,6]  R1569     6.0870878398418427e-02
    z[4,3,6]  R1570     1.5468700230121613e-01
    z[4,3,6]  R1571     -8.9504495263099670e-02
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1572     -1
    z[4,5,0]  R1573     1
    z[4,5,0]  R1586     -5.7870741933584213e-02
    z[4,5,0]  R1587     -3.6122322082519531e-01
    z[4,5,0]  R1588     -1.3643909990787506e-01
    z[4,5,0]  R1589     -2.3454368114471436e-01
    z[4,5,0]  R1590     -7.5736775994300842e-02
    z[4,5,0]  R1591     -4.8929926007986069e-02
    z[4,5,0]  R1592     5.4211288690567017e-02
    z[4,5,0]  R1593     -3.7526279687881470e-01
    z[4,5,0]  R1594     4.6862432360649109e-01
    z[4,5,0]  R1595     1.2227475643157959e-01
    z[4,5,0]  R1596     -6.0676383972167969e-01
    z[4,5,0]  R1597     -6.0688352584838867e-01
    z[4,5,0]  R1598     -1.5276689827442169e-01
    z[4,5,0]  R1599     -3.3048603218048811e-03
    z[4,5,0]  R1600     2.5384861230850220e-01
    z[4,5,0]  R1601     -4.9653518944978714e-03
    z[4,5,0]  R1602     2.8222510591149330e-03
    z[4,5,0]  R1603     -2.4970605969429016e-01
    z[4,5,0]  R1604     3.6843252182006836e-01
    z[4,5,0]  R1605     2.6904299855232239e-02
    z[4,5,0]  R1606     2.2376640141010284e-01
    z[4,5,0]  R1607     5.5176131427288055e-02
    z[4,5,0]  R1608     -6.9494640827178955e-01
    z[4,5,0]  R1609     -6.0231178998947144e-01
    z[4,5,0]  R1610     2.7584481239318848e-01
    z[4,5,0]  R1611     2.2619657218456268e-01
    z[4,5,0]  R1612     -2.4203982949256897e-01
    z[4,5,0]  R1613     -9.5208868384361267e-02
    z[4,5,0]  R1614     -1.5311998128890991e-01
    z[4,5,0]  R1615     3.1878852844238281e-01
    z[4,5,0]  R1616     -3.1288117170333862e-01
    z[4,5,0]  R1617     -6.1639484018087387e-02
    z[4,5,0]  R1618     -5.1401168107986450e-01
    z[4,5,0]  R1619     -4.5085260272026062e-01
    z[4,5,0]  R1620     -4.4631335139274597e-01
    z[4,5,0]  R1621     -1.3485868275165558e-01
    z[4,5,0]  R1622     0.544841468334198
    z[4,5,0]  R1623     4.5743012428283691e-01
    z[4,5,0]  R1624     2.6476213335990906e-01
    z[4,5,0]  R1625     1.8688598275184631e-01
    z[4,5,0]  R1626     -2.1965850889682770e-01
    z[4,5,0]  R1627     3.8964539766311646e-01
    z[4,5,0]  R1628     -4.8913940787315369e-01
    z[4,5,0]  R1629     3.9033308625221252e-02
    z[4,5,0]  R1630     -7.6041102409362793e-02
    z[4,5,0]  R1631     -1.8263314664363861e-01
    z[4,5,0]  R1632     -2.1608844399452209e-01
    z[4,5,0]  R1633     -3.2449704408645630e-01
    z[4,5,0]  R1634     -3.8376316428184509e-01
    z[4,5,0]  R1635     0.533849835395813
    z[4,5,0]  R1636     9.1885060071945190e-02
    z[4,5,0]  R1637     8.0419188737869263e-01
    z[4,5,0]  R1638     7.9476422071456909e-01
    z[4,5,0]  R1639     7.5385099649429321e-01
    z[4,5,0]  R1640     5.5066674947738647e-01
    z[4,5,0]  R1641     -2.9325127601623535e-01
    z[4,5,0]  R1642     -3.2178360223770142e-01
    z[4,5,0]  R1643     -4.5268434286117554e-01
    z[4,5,0]  R1644     3.8365894556045532e-01
    z[4,5,0]  R1645     3.0912798643112183e-01
    z[4,5,0]  R1646     -5.2593553066253662e-01
    z[4,5,0]  R1647     -7.1485877037048340e-01
    z[4,5,0]  R1648     -8.7346452474594116e-01
    z[4,5,0]  R1649     -8.7916219234466553e-01
    z[4,5,0]  R1650     -3.0520135164260864e-01
    z[4,5,0]  R1651     1.2800628319382668e-03
    z[4,5,0]  R1652     -2.8656333684921265e-01
    z[4,5,0]  R1653     8.7442982196807861e-01
    z[4,5,0]  R1654     -5.7233875989913940e-01
    z[4,5,0]  R1655     6.8655538558959961e-01
    z[4,5,0]  R1656     -6.5309411287307739e-01
    z[4,5,0]  R1657     -3.5251370072364807e-01
    z[4,5,0]  R1658     -1.1558666080236435e-01
    z[4,5,0]  R1659     -3.2930415868759155e-01
    z[4,5,0]  R1660     -1.2061957269906998e-01
    z[4,5,0]  R1661     -2.0873010158538818e-01
    z[4,5,0]  R1662     4.3043011426925659e-01
    z[4,5,0]  R1663     0.673404335975647
    z[4,5,0]  R1664     4.6897763013839722e-01
    z[4,5,0]  R1665     5.4304844141006470e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1574     -1
    z[4,5,1]  R1575     1
    z[4,5,1]  R1586     9.0703427791595459e-02
    z[4,5,1]  R1587     -1.8035714328289032e-01
    z[4,5,1]  R1588     6.8937726318836212e-02
    z[4,5,1]  R1589     -2.4070395529270172e-01
    z[4,5,1]  R1590     1.8579232692718506e-01
    z[4,5,1]  R1591     1.3862904906272888e-01
    z[4,5,1]  R1592     1.8008811771869659e-01
    z[4,5,1]  R1593     -2.8175202012062073e-01
    z[4,5,1]  R1594     -6.8649560213088989e-01
    z[4,5,1]  R1595     -6.7654556035995483e-01
    z[4,5,1]  R1596     6.4975041151046753e-01
    z[4,5,1]  R1597     6.0589939355850220e-01
    z[4,5,1]  R1598     9.5547932386398315e-01
    z[4,5,1]  R1599     2.4890752136707306e-01
    z[4,5,1]  R1600     1.2335730716586113e-02
    z[4,5,1]  R1601     -0.477426677942276
    z[4,5,1]  R1602     -1.5880693495273590e-01
    z[4,5,1]  R1603     -3.6295831203460693e-01
    z[4,5,1]  R1604     1.5812905505299568e-02
    z[4,5,1]  R1605     -1.7650930583477020e-01
    z[4,5,1]  R1606     4.1115105152130127e-01
    z[4,5,1]  R1607     3.4792086482048035e-01
    z[4,5,1]  R1608     0.456438273191452
    z[4,5,1]  R1609     2.4656632542610168e-01
    z[4,5,1]  R1610     -4.8314133286476135e-01
    z[4,5,1]  R1611     7.0207816362380981e-01
    z[4,5,1]  R1612     6.8296289443969727e-01
    z[4,5,1]  R1613     5.4343974590301514e-01
    z[4,5,1]  R1614     5.8972358703613281e-01
    z[4,5,1]  R1615     -2.5271937251091003e-01
    z[4,5,1]  R1616     0.870954155921936
    z[4,5,1]  R1617     7.4187004566192627e-01
    z[4,5,1]  R1618     1.6852082312107086e-01
    z[4,5,1]  R1619     4.4823831319808960e-01
    z[4,5,1]  R1620     2.8948095440864563e-01
    z[4,5,1]  R1621     3.1888470053672791e-01
    z[4,5,1]  R1622     -1.2318441271781921e-01
    z[4,5,1]  R1623     -5.2266317605972290e-01
    z[4,5,1]  R1624     2.3398680984973907e-01
    z[4,5,1]  R1625     1.7198304831981659e-01
    z[4,5,1]  R1626     -0.554340124130249
    z[4,5,1]  R1627     -6.7100626230239868e-01
    z[4,5,1]  R1628     -5.4123604297637939e-01
    z[4,5,1]  R1629     -6.1328488588333130e-01
    z[4,5,1]  R1630     -8.1643950939178467e-01
    z[4,5,1]  R1631     3.6129321902990341e-02
    z[4,5,1]  R1632     1.7198620736598969e-01
    z[4,5,1]  R1633     -0.0684293881058693
    z[4,5,1]  R1634     -1.2355047464370728e-01
    z[4,5,1]  R1635     1.3018621504306793e-01
    z[4,5,1]  R1636     -2.2815652191638947e-01
    z[4,5,1]  R1637     3.6367753148078918e-01
    z[4,5,1]  R1638     1.1067080497741699e-01
    z[4,5,1]  R1639     2.8792858123779297e-01
    z[4,5,1]  R1640     2.5240519642829895e-01
    z[4,5,1]  R1641     5.4331791400909424e-01
    z[4,5,1]  R1642     5.6653678417205811e-01
    z[4,5,1]  R1643     5.5422651767730713e-01
    z[4,5,1]  R1644     7.4812614917755127e-01
    z[4,5,1]  R1645     0.758578360080719
    z[4,5,1]  R1646     4.2381352186203003e-01
    z[4,5,1]  R1647     8.5695318877696991e-02
    z[4,5,1]  R1648     2.2513927519321442e-01
    z[4,5,1]  R1649     2.5168797373771667e-01
    z[4,5,1]  R1650     4.5791548490524292e-01
    z[4,5,1]  R1651     -1.1175908148288727e-01
    z[4,5,1]  R1652     2.9197549819946289e-01
    z[4,5,1]  R1653     -1.8015447258949280e-01
    z[4,5,1]  R1654     4.5995992422103882e-01
    z[4,5,1]  R1655     1.4378155767917633e-01
    z[4,5,1]  R1656     -8.0687880516052246e-02
    z[4,5,1]  R1657     3.3827960491180420e-01
    z[4,5,1]  R1658     -2.6293650269508362e-01
    z[4,5,1]  R1659     4.4365060329437256e-01
    z[4,5,1]  R1660     -1.2746001780033112e-01
    z[4,5,1]  R1661     7.3309385776519775e-01
    z[4,5,1]  R1662     -1.0934652388095856e-01
    z[4,5,1]  R1663     3.1935906410217285e-01
    z[4,5,1]  R1664     -1.7344640195369720e-01
    z[4,5,1]  R1665     1.3700337149202824e-04
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1576     -1
    z[4,5,2]  R1577     1
    z[4,5,2]  R1586     2.8583189845085144e-01
    z[4,5,2]  R1587     4.1041865944862366e-01
    z[4,5,2]  R1588     6.0781556367874146e-01
    z[4,5,2]  R1589     7.0913535356521606e-01
    z[4,5,2]  R1590     6.4988970756530762e-01
    z[4,5,2]  R1591     4.4665363430976868e-01
    z[4,5,2]  R1592     -0.0573224201798439
    z[4,5,2]  R1593     7.3578923940658569e-01
    z[4,5,2]  R1594     -4.7941815853118896e-01
    z[4,5,2]  R1595     -5.1720386743545532e-01
    z[4,5,2]  R1596     -3.5617422312498093e-02
    z[4,5,2]  R1597     -1.4120461046695709e-01
    z[4,5,2]  R1598     -8.9397631585597992e-02
    z[4,5,2]  R1599     -0.627575695514679
    z[4,5,2]  R1600     -3.0603927373886108e-01
    z[4,5,2]  R1601     -0.419014036655426
    z[4,5,2]  R1602     -0.333706259727478
    z[4,5,2]  R1603     -5.6432580947875977e-01
    z[4,5,2]  R1604     -3.5146871209144592e-01
    z[4,5,2]  R1605     -3.9342594146728516e-01
    z[4,5,2]  R1606     5.5873185396194458e-01
    z[4,5,2]  R1607     4.0096721053123474e-01
    z[4,5,2]  R1608     2.2632074356079102e-01
    z[4,5,2]  R1609     2.5209259986877441e-01
    z[4,5,2]  R1610     -4.2676281929016113e-01
    z[4,5,2]  R1611     1.1735233711078763e-03
    z[4,5,2]  R1612     1.0540015250444412e-01
    z[4,5,2]  R1613     8.9570038020610809e-02
    z[4,5,2]  R1614     -3.0892717838287354e-01
    z[4,5,2]  R1615     -4.6907064318656921e-01
    z[4,5,2]  R1616     2.4958732724189758e-01
    z[4,5,2]  R1617     2.2815760970115662e-01
    z[4,5,2]  R1618     5.3504353761672974e-01
    z[4,5,2]  R1619     6.6952472925186157e-01
    z[4,5,2]  R1620     3.9554160833358765e-01
    z[4,5,2]  R1621     -2.1934132277965546e-01
    z[4,5,2]  R1622     -6.5033769607543945e-01
    z[4,5,2]  R1623     -4.0592589974403381e-01
    z[4,5,2]  R1624     -6.9633078575134277e-01
    z[4,5,2]  R1625     -6.9222939014434814e-01
    z[4,5,2]  R1626     -6.8994587659835815e-01
    z[4,5,2]  R1627     -4.7157332301139832e-01
    z[4,5,2]  R1628     -2.1637642383575439e-01
    z[4,5,2]  R1629     -1.1653658747673035e-01
    z[4,5,2]  R1630     3.1965553760528564e-01
    z[4,5,2]  R1631     4.6624442934989929e-01
    z[4,5,2]  R1632     5.4059821367263794e-01
    z[4,5,2]  R1633     4.8135438561439514e-01
    z[4,5,2]  R1634     2.9447263479232788e-01
    z[4,5,2]  R1635     -5.8466184139251709e-01
    z[4,5,2]  R1636     0.0337735079228878
    z[4,5,2]  R1637     4.4190880656242371e-01
    z[4,5,2]  R1638     2.8016534447669983e-01
    z[4,5,2]  R1639     4.1245257854461670e-01
    z[4,5,2]  R1640     0.546988308429718
    z[4,5,2]  R1641     3.0850669741630554e-01
    z[4,5,2]  R1642     4.8759835958480835e-01
    z[4,5,2]  R1643     -4.5866728760302067e-03
    z[4,5,2]  R1644     -1.5615680813789368e-01
    z[4,5,2]  R1645     2.7312371134757996e-01
    z[4,5,2]  R1646     6.4112591743469238e-01
    z[4,5,2]  R1647     6.7079651355743408e-01
    z[4,5,2]  R1648     2.6852738857269287e-01
    z[4,5,2]  R1649     2.3587007820606232e-01
    z[4,5,2]  R1650     0.693960964679718
    z[4,5,2]  R1651     8.8741952180862427e-01
    z[4,5,2]  R1652     4.5759826898574829e-01
    z[4,5,2]  R1653     0.0328427255153656
    z[4,5,2]  R1654     1.7511083185672760e-01
    z[4,5,2]  R1655     -1.8304964900016785e-01
    z[4,5,2]  R1656     2.5656121969223022e-01
    z[4,5,2]  R1657     5.2649009227752686e-01
    z[4,5,2]  R1658     7.2265160083770752e-01
    z[4,5,2]  R1659     1.8507625162601471e-01
    z[4,5,2]  R1660     7.3358118534088135e-01
    z[4,5,2]  R1661     1.8976634740829468e-01
    z[4,5,2]  R1662     -3.2092091441154480e-01
    z[4,5,2]  R1663     5.8595299720764160e-01
    z[4,5,2]  R1664     1.5920553356409073e-02
    z[4,5,2]  R1665     -1.1534313112497330e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1578     -1
    z[4,5,3]  R1579     1
    z[4,5,3]  R1586     7.9734712839126587e-01
    z[4,5,3]  R1587     6.8379396200180054e-01
    z[4,5,3]  R1588     4.0485379099845886e-01
    z[4,5,3]  R1589     -6.9874495267868042e-02
    z[4,5,3]  R1590     -3.5210162401199341e-01
    z[4,5,3]  R1591     4.6901756525039673e-01
    z[4,5,3]  R1592     6.8851172924041748e-01
    z[4,5,3]  R1593     1.2063708156347275e-01
    z[4,5,3]  R1594     -1.9099628925323486e-01
    z[4,5,3]  R1595     -0.0162209402769804
    z[4,5,3]  R1596     1.4994834363460541e-01
    z[4,5,3]  R1597     8.5919030010700226e-02
    z[4,5,3]  R1598     2.9778733849525452e-02
    z[4,5,3]  R1599     -0.585460901260376
    z[4,5,3]  R1600     -6.4031469821929932e-01
    z[4,5,3]  R1601     -4.1169667243957520e-01
    z[4,5,3]  R1602     -7.3668831586837769e-01
    z[4,5,3]  R1603     3.5517036914825439e-02
    z[4,5,3]  R1604     -7.5250577926635742e-01
    z[4,5,3]  R1605     -6.9029337167739868e-01
    z[4,5,3]  R1606     1.0706377774477005e-01
    z[4,5,3]  R1607     4.1478452086448669e-01
    z[4,5,3]  R1608     7.4573658406734467e-02
    z[4,5,3]  R1609     4.4015997648239136e-01
    z[4,5,3]  R1610     -5.5497705936431885e-01
    z[4,5,3]  R1611     4.8583814501762390e-01
    z[4,5,3]  R1612     1.8936289846897125e-01
    z[4,5,3]  R1613     8.3995535969734192e-02
    z[4,5,3]  R1614     6.4312392473220825e-01
    z[4,5,3]  R1615     -4.0286022424697876e-01
    z[4,5,3]  R1616     1.5088823437690735e-01
    z[4,5,3]  R1617     2.0504210889339447e-01
    z[4,5,3]  R1618     3.8115409016609192e-01
    z[4,5,3]  R1619     -2.0081575214862823e-01
    z[4,5,3]  R1620     3.2083225250244141e-01
    z[4,5,3]  R1621     8.3555358648300171e-01
    z[4,5,3]  R1622     -3.6146077513694763e-01
    z[4,5,3]  R1623     -2.1051061153411865e-01
    z[4,5,3]  R1624     -4.5876809954643250e-01
    z[4,5,3]  R1625     -6.5730553865432739e-01
    z[4,5,3]  R1626     3.5014513134956360e-01
    z[4,5,3]  R1627     -3.6427515745162964e-01
    z[4,5,3]  R1628     -5.1047003269195557e-01
    z[4,5,3]  R1629     4.1621926426887512e-01
    z[4,5,3]  R1630     -1.1771318316459656e-01
    z[4,5,3]  R1631     1.4986169338226318e-01
    z[4,5,3]  R1632     -4.0647247433662415e-01
    z[4,5,3]  R1633     1.6493260860443115e-01
    z[4,5,3]  R1634     6.3142031431198120e-01
    z[4,5,3]  R1635     4.7200274467468262e-01
    z[4,5,3]  R1636     -1.7275893688201904e-01
    z[4,5,3]  R1637     -5.1414594054222107e-02
    z[4,5,3]  R1638     5.1054474897682667e-03
    z[4,5,3]  R1639     -6.0823790729045868e-02
    z[4,5,3]  R1640     3.9098763465881348e-01
    z[4,5,3]  R1641     2.2858822345733643e-01
    z[4,5,3]  R1642     3.1345912814140320e-01
    z[4,5,3]  R1643     1.8895380198955536e-01
    z[4,5,3]  R1644     -1.5413288772106171e-01
    z[4,5,3]  R1645     -6.4357981085777283e-02
    z[4,5,3]  R1646     -8.0260913819074631e-03
    z[4,5,3]  R1647     7.9134419560432434e-02
    z[4,5,3]  R1648     3.2658487558364868e-01
    z[4,5,3]  R1649     -3.9690818637609482e-02
    z[4,5,3]  R1650     4.2428621649742126e-01
    z[4,5,3]  R1651     3.2454070448875427e-01
    z[4,5,3]  R1652     1.7222511768341064e-01
    z[4,5,3]  R1653     2.8329461812973022e-01
    z[4,5,3]  R1654     3.5891965031623840e-01
    z[4,5,3]  R1655     2.9375055432319641e-01
    z[4,5,3]  R1656     0.315595418214798
    z[4,5,3]  R1657     1.5480515360832214e-01
    z[4,5,3]  R1658     4.0509562939405441e-02
    z[4,5,3]  R1659     5.1195913553237915e-01
    z[4,5,3]  R1660     1.0345229879021645e-02
    z[4,5,3]  R1661     3.8209143280982971e-01
    z[4,5,3]  R1662     -4.0541300177574158e-01
    z[4,5,3]  R1663     0.161179780960083
    z[4,5,3]  R1664     -6.9057798385620117e-01
    z[4,5,3]  R1665     -6.7248648405075073e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1580     -1
    z[4,5,4]  R1581     1
    z[4,5,4]  R1586     2.8962832689285278e-01
    z[4,5,4]  R1587     9.4165757298469543e-02
    z[4,5,4]  R1588     -0.375297486782074
    z[4,5,4]  R1589     -6.2481898814439774e-02
    z[4,5,4]  R1590     2.3791453242301941e-01
    z[4,5,4]  R1591     -3.4306889772415161e-01
    z[4,5,4]  R1592     -4.9269944429397583e-01
    z[4,5,4]  R1593     -2.7725201845169067e-01
    z[4,5,4]  R1594     -1.7659810185432434e-01
    z[4,5,4]  R1595     -2.8725671768188477e-01
    z[4,5,4]  R1596     1.4359951019287109e-01
    z[4,5,4]  R1597     -2.5267881155014038e-01
    z[4,5,4]  R1598     3.2495800405740738e-02
    z[4,5,4]  R1599     1.7760351300239563e-01
    z[4,5,4]  R1600     2.9704385995864868e-01
    z[4,5,4]  R1601     5.0171726942062378e-01
    z[4,5,4]  R1602     4.2885333299636841e-01
    z[4,5,4]  R1603     1.6307403147220612e-01
    z[4,5,4]  R1604     -0.385662317276001
    z[4,5,4]  R1605     -2.0439927279949188e-01
    z[4,5,4]  R1606     2.3397077620029449e-01
    z[4,5,4]  R1607     -4.3531784415245056e-01
    z[4,5,4]  R1608     0.378226101398468
    z[4,5,4]  R1609     -4.9855765700340271e-01
    z[4,5,4]  R1610     7.0312090218067169e-02
    z[4,5,4]  R1611     -2.9113510251045227e-01
    z[4,5,4]  R1612     -0.640434205532074
    z[4,5,4]  R1613     -5.1009333133697510e-01
    z[4,5,4]  R1614     -2.8283417224884033e-01
    z[4,5,4]  R1615     -5.1376384496688843e-01
    z[4,5,4]  R1616     1.2046154588460922e-01
    z[4,5,4]  R1617     -5.4465734958648682e-01
    z[4,5,4]  R1618     -1.9026456773281097e-01
    z[4,5,4]  R1619     -1.1776334047317505e-01
    z[4,5,4]  R1620     4.4609126448631287e-01
    z[4,5,4]  R1621     -2.0541222393512726e-01
    z[4,5,4]  R1622     0.0743880346417427
    z[4,5,4]  R1623     -5.3647822141647339e-01
    z[4,5,4]  R1624     -1.4164827764034271e-01
    z[4,5,4]  R1625     9.1382518410682678e-02
    z[4,5,4]  R1626     -8.4111243486404419e-02
    z[4,5,4]  R1627     1.7591449618339539e-01
    z[4,5,4]  R1628     1.4838105440139771e-01
    z[4,5,4]  R1629     1.8645854294300079e-01
    z[4,5,4]  R1630     2.4851320683956146e-01
    z[4,5,4]  R1631     1.8241493403911591e-01
    z[4,5,4]  R1632     2.4589349329471588e-01
    z[4,5,4]  R1633     1.2977319955825806e-01
    z[4,5,4]  R1634     1.1258167028427124e-01
    z[4,5,4]  R1635     -0.160190612077713
    z[4,5,4]  R1636     3.1359833478927612e-01
    z[4,5,4]  R1637     1.0080862790346146e-01
    z[4,5,4]  R1638     2.5663849711418152e-01
    z[4,5,4]  R1639     1.4975853264331818e-01
    z[4,5,4]  R1640     7.1244575083255768e-02
    z[4,5,4]  R1641     6.0734695196151733e-01
    z[4,5,4]  R1642     -2.2092871367931366e-01
    z[4,5,4]  R1643     5.9946626424789429e-01
    z[4,5,4]  R1644     -1.4683061838150024e-01
    z[4,5,4]  R1645     -2.0465135574340820e-01
    z[4,5,4]  R1646     1.0752888023853302e-01
    z[4,5,4]  R1647     -1.2483403831720352e-01
    z[4,5,4]  R1648     -7.7004201710224152e-02
    z[4,5,4]  R1649     -7.0594884455204010e-02
    z[4,5,4]  R1650     -1.8695162236690521e-01
    z[4,5,4]  R1651     2.9199129343032837e-01
    z[4,5,4]  R1652     7.3304343223571777e-01
    z[4,5,4]  R1653     1.8396420776844025e-01
    z[4,5,4]  R1654     5.2788454294204712e-01
    z[4,5,4]  R1655     0.0999830886721611
    z[4,5,4]  R1656     4.4631978869438171e-01
    z[4,5,4]  R1657     -0.260684072971344
    z[4,5,4]  R1658     4.9166500568389893e-02
    z[4,5,4]  R1659     -2.4913236498832703e-01
    z[4,5,4]  R1660     5.1458673551678658e-03
    z[4,5,4]  R1661     2.4429830908775330e-01
    z[4,5,4]  R1662     2.8930205106735229e-01
    z[4,5,4]  R1663     6.8917974829673767e-02
    z[4,5,4]  R1664     2.9879891872406006e-01
    z[4,5,4]  R1665     2.7954256534576416e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1582     -1
    z[4,5,5]  R1583     1
    z[4,5,5]  R1586     -4.3192145228385925e-01
    z[4,5,5]  R1587     -3.5169312357902527e-01
    z[4,5,5]  R1588     -5.3854197263717651e-01
    z[4,5,5]  R1589     -5.3042483329772949e-01
    z[4,5,5]  R1590     -5.6895679235458374e-01
    z[4,5,5]  R1591     -3.0301621556282043e-01
    z[4,5,5]  R1592     -4.4310775399208069e-01
    z[4,5,5]  R1593     3.4799691289663315e-02
    z[4,5,5]  R1594     -2.1711723878979683e-02
    z[4,5,5]  R1595     3.6115863919258118e-01
    z[4,5,5]  R1596     4.0278828144073486e-01
    z[4,5,5]  R1597     3.6516085267066956e-01
    z[4,5,5]  R1598     1.3691034913063049e-01
    z[4,5,5]  R1599     3.8916292786598206e-01
    z[4,5,5]  R1600     4.3744662404060364e-01
    z[4,5,5]  R1601     2.6634088158607483e-01
    z[4,5,5]  R1602     2.4068865180015564e-01
    z[4,5,5]  R1603     2.8285548090934753e-01
    z[4,5,5]  R1604     1.5305081009864807e-01
    z[4,5,5]  R1605     1.4244772493839264e-01
    z[4,5,5]  R1606     -4.6020811796188354e-01
    z[4,5,5]  R1607     -8.6697600781917572e-02
    z[4,5,5]  R1608     -2.4631278216838837e-01
    z[4,5,5]  R1609     2.5095903873443604e-01
    z[4,5,5]  R1610     4.2448881268501282e-01
    z[4,5,5]  R1611     -2.0095948874950409e-01
    z[4,5,5]  R1612     -8.2308724522590637e-02
    z[4,5,5]  R1613     -4.2418184876441956e-01
    z[4,5,5]  R1614     -4.5460681430995464e-03
    z[4,5,5]  R1615     2.3905214667320251e-01
    z[4,5,5]  R1616     -2.0068673789501190e-01
    z[4,5,5]  R1617     -1.6319629549980164e-01
    z[4,5,5]  R1618     -1.6506245732307434e-01
    z[4,5,5]  R1619     1.7667191103100777e-02
    z[4,5,5]  R1620     2.0985834300518036e-01
    z[4,5,5]  R1621     2.0626035332679749e-01
    z[4,5,5]  R1622     -1.1976198852062225e-01
    z[4,5,5]  R1623     1.4380528032779694e-01
    z[4,5,5]  R1624     3.9840835332870483e-01
    z[4,5,5]  R1625     -1.1201862990856171e-01
    z[4,5,5]  R1626     -1.4309965074062347e-01
    z[4,5,5]  R1627     9.5048017799854279e-02
    z[4,5,5]  R1628     8.6816504597663879e-02
    z[4,5,5]  R1629     2.6909697055816650e-01
    z[4,5,5]  R1630     -3.8634249567985535e-01
    z[4,5,5]  R1631     -8.3060008287429810e-01
    z[4,5,5]  R1632     -6.3589096069335938e-01
    z[4,5,5]  R1633     -4.4720986485481262e-01
    z[4,5,5]  R1634     -4.9541616439819336e-01
    z[4,5,5]  R1635     -2.8148138523101807e-01
    z[4,5,5]  R1636     5.9881383180618286e-01
    z[4,5,5]  R1637     9.1375805437564850e-02
    z[4,5,5]  R1638     4.1600292921066284e-01
    z[4,5,5]  R1639     7.8808829188346863e-02
    z[4,5,5]  R1640     6.0233663767576218e-02
    z[4,5,5]  R1641     3.1459605693817139e-01
    z[4,5,5]  R1642     2.8942698240280151e-01
    z[4,5,5]  R1643     1.5429291129112244e-01
    z[4,5,5]  R1644     4.3332797288894653e-01
    z[4,5,5]  R1645     -1.9631743431091309e-01
    z[4,5,5]  R1646     -3.2332543283700943e-02
    z[4,5,5]  R1647     -9.9013172090053558e-02
    z[4,5,5]  R1648     -3.7514790892601013e-02
    z[4,5,5]  R1649     -2.1448303759098053e-01
    z[4,5,5]  R1650     1.9197199493646622e-02
    z[4,5,5]  R1651     5.4930694401264191e-02
    z[4,5,5]  R1652     1.3632969558238983e-01
    z[4,5,5]  R1653     -2.3126402497291565e-01
    z[4,5,5]  R1654     0.122758649289608
    z[4,5,5]  R1655     0.195773646235466
    z[4,5,5]  R1656     -4.1888365149497986e-01
    z[4,5,5]  R1657     -5.7614952325820923e-01
    z[4,5,5]  R1658     -6.2454670667648315e-01
    z[4,5,5]  R1659     -4.7182309627532959e-01
    z[4,5,5]  R1660     -3.8587334752082825e-01
    z[4,5,5]  R1661     -0.326010525226593
    z[4,5,5]  R1662     5.2686333656311035e-01
    z[4,5,5]  R1663     -7.8539215028285980e-02
    z[4,5,5]  R1664     -3.0201127752661705e-02
    z[4,5,5]  R1665     3.0798721313476562e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1584     -1
    z[4,5,6]  R1585     1
    z[4,5,6]  R1586     2.2819772362709045e-02
    z[4,5,6]  R1587     2.6156494021415710e-01
    z[4,5,6]  R1588     1.1140027642250061e-01
    z[4,5,6]  R1589     3.0666095018386841e-01
    z[4,5,6]  R1590     1.8192812800407410e-01
    z[4,5,6]  R1591     -5.9109717607498169e-01
    z[4,5,6]  R1592     -2.1954016387462616e-01
    z[4,5,6]  R1593     -3.8180452585220337e-01
    z[4,5,6]  R1594     -1.0552482306957245e-01
    z[4,5,6]  R1595     -2.1591672301292419e-01
    z[4,5,6]  R1596     -0.055225919932127
    z[4,5,6]  R1597     2.0017151534557343e-01
    z[4,5,6]  R1598     -1.8719619512557983e-01
    z[4,5,6]  R1599     1.3574877381324768e-01
    z[4,5,6]  R1600     -3.9006552100181580e-01
    z[4,5,6]  R1601     3.2297751307487488e-01
    z[4,5,6]  R1602     2.8081426024436951e-01
    z[4,5,6]  R1603     6.1610287427902222e-01
    z[4,5,6]  R1604     4.5302573591470718e-02
    z[4,5,6]  R1605     5.2417677640914917e-01
    z[4,5,6]  R1606     -4.3669855594635010e-01
    z[4,5,6]  R1607     -5.8827507495880127e-01
    z[4,5,6]  R1608     2.1955946087837219e-01
    z[4,5,6]  R1609     -8.7143093347549438e-02
    z[4,5,6]  R1610     -1.2338374555110931e-01
    z[4,5,6]  R1611     -3.0779343843460083e-01
    z[4,5,6]  R1612     1.0526287555694580e-01
    z[4,5,6]  R1613     4.9031114578247070e-01
    z[4,5,6]  R1614     1.9929949939250946e-01
    z[4,5,6]  R1615     -3.6205506324768066e-01
    z[4,5,6]  R1616     6.0803771018981934e-02
    z[4,5,6]  R1617     -1.6866151988506317e-01
    z[4,5,6]  R1618     -4.6086505055427551e-01
    z[4,5,6]  R1619     -3.0503043532371521e-01
    z[4,5,6]  R1620     -4.6322867274284363e-01
    z[4,5,6]  R1621     -2.2164769470691681e-01
    z[4,5,6]  R1622     3.3838397264480591e-01
    z[4,5,6]  R1623     1.2639641063287854e-03
    z[4,5,6]  R1624     3.1826782971620560e-02
    z[4,5,6]  R1625     -5.8003194630146027e-02
    z[4,5,6]  R1626     -1.3519684970378876e-01
    z[4,5,6]  R1627     5.3564831614494324e-02
    z[4,5,6]  R1628     0.361736923456192
    z[4,5,6]  R1629     5.7302600145339966e-01
    z[4,5,6]  R1630     -2.4264581501483917e-02
    z[4,5,6]  R1631     4.8225581645965576e-02
    z[4,5,6]  R1632     3.7936046719551086e-02
    z[4,5,6]  R1633     -6.4364320039749146e-01
    z[4,5,6]  R1634     -3.0650213360786438e-01
    z[4,5,6]  R1635     1.6895861923694611e-01
    z[4,5,6]  R1636     -6.7200702428817749e-01
    z[4,5,6]  R1637     6.7640833556652069e-02
    z[4,5,6]  R1638     -1.9662520289421082e-01
    z[4,5,6]  R1639     -3.8255810737609863e-01
    z[4,5,6]  R1640     -4.1507405042648315e-01
    z[4,5,6]  R1641     5.9493549168109894e-02
    z[4,5,6]  R1642     3.2696339488029480e-01
    z[4,5,6]  R1643     2.6271492242813110e-01
    z[4,5,6]  R1644     1.8878260254859924e-01
    z[4,5,6]  R1645     -4.1211363673210144e-01
    z[4,5,6]  R1646     3.4649577736854553e-01
    z[4,5,6]  R1647     -3.9930595085024834e-03
    z[4,5,6]  R1648     -1.6441099345684052e-02
    z[4,5,6]  R1649     -2.3564879596233368e-01
    z[4,5,6]  R1650     1.5668654814362526e-02
    z[4,5,6]  R1651     -7.9948879778385162e-02
    z[4,5,6]  R1652     1.9399905204772949e-01
    z[4,5,6]  R1653     -1.8508534133434296e-01
    z[4,5,6]  R1654     -8.7443970143795013e-02
    z[4,5,6]  R1655     -5.8296483755111694e-01
    z[4,5,6]  R1656     0.16391621530056
    z[4,5,6]  R1657     -2.4543851613998413e-01
    z[4,5,6]  R1658     -3.4087572246789932e-02
    z[4,5,6]  R1659     3.3718466758728027e-01
    z[4,5,6]  R1660     5.3106665611267090e-01
    z[4,5,6]  R1661     -2.6652488112449646e-01
    z[4,5,6]  R1662     -4.1730406880378723e-01
    z[4,5,6]  R1663     -2.5357139110565186e-01
    z[4,5,6]  R1664     -4.2735478281974792e-01
    z[4,5,6]  R1665     -2.5798463821411133e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1666     -1
    z[5,4,0]  R1667     1
    z[5,4,0]  R1680     -2.1965850889682770e-01
    z[5,4,0]  R1681     3.8964539766311646e-01
    z[5,4,0]  R1682     -4.8913940787315369e-01
    z[5,4,0]  R1683     3.9033308625221252e-02
    z[5,4,0]  R1684     -7.6041102409362793e-02
    z[5,4,0]  R1685     -1.8263314664363861e-01
    z[5,4,0]  R1686     -2.1608844399452209e-01
    z[5,4,0]  R1687     -3.2449704408645630e-01
    z[5,4,0]  R1688     -3.8376316428184509e-01
    z[5,4,0]  R1689     0.533849835395813
    z[5,4,0]  R1690     9.1885060071945190e-02
    z[5,4,0]  R1691     8.0419188737869263e-01
    z[5,4,0]  R1692     7.9476422071456909e-01
    z[5,4,0]  R1693     7.5385099649429321e-01
    z[5,4,0]  R1694     5.5066674947738647e-01
    z[5,4,0]  R1695     -2.9325127601623535e-01
    z[5,4,0]  R1696     -3.2178360223770142e-01
    z[5,4,0]  R1697     -4.5268434286117554e-01
    z[5,4,0]  R1698     3.8365894556045532e-01
    z[5,4,0]  R1699     3.0912798643112183e-01
    z[5,4,0]  R1700     -5.2593553066253662e-01
    z[5,4,0]  R1701     -7.1485877037048340e-01
    z[5,4,0]  R1702     -8.7346452474594116e-01
    z[5,4,0]  R1703     -8.7916219234466553e-01
    z[5,4,0]  R1704     -3.0520135164260864e-01
    z[5,4,0]  R1705     1.2800628319382668e-03
    z[5,4,0]  R1706     -2.8656333684921265e-01
    z[5,4,0]  R1707     8.7442982196807861e-01
    z[5,4,0]  R1708     -5.7233875989913940e-01
    z[5,4,0]  R1709     6.8655538558959961e-01
    z[5,4,0]  R1710     -6.5309411287307739e-01
    z[5,4,0]  R1711     -3.5251370072364807e-01
    z[5,4,0]  R1712     -1.1558666080236435e-01
    z[5,4,0]  R1713     -3.2930415868759155e-01
    z[5,4,0]  R1714     -1.2061957269906998e-01
    z[5,4,0]  R1715     -2.0873010158538818e-01
    z[5,4,0]  R1716     4.3043011426925659e-01
    z[5,4,0]  R1717     0.673404335975647
    z[5,4,0]  R1718     4.6897763013839722e-01
    z[5,4,0]  R1719     5.4304844141006470e-01
    z[5,4,0]  R1720     -5.7870741933584213e-02
    z[5,4,0]  R1721     -3.6122322082519531e-01
    z[5,4,0]  R1722     -1.3643909990787506e-01
    z[5,4,0]  R1723     -2.3454368114471436e-01
    z[5,4,0]  R1724     -7.5736775994300842e-02
    z[5,4,0]  R1725     -4.8929926007986069e-02
    z[5,4,0]  R1726     5.4211288690567017e-02
    z[5,4,0]  R1727     -3.7526279687881470e-01
    z[5,4,0]  R1728     4.6862432360649109e-01
    z[5,4,0]  R1729     1.2227475643157959e-01
    z[5,4,0]  R1730     -6.0676383972167969e-01
    z[5,4,0]  R1731     -6.0688352584838867e-01
    z[5,4,0]  R1732     -1.5276689827442169e-01
    z[5,4,0]  R1733     -3.3048603218048811e-03
    z[5,4,0]  R1734     2.5384861230850220e-01
    z[5,4,0]  R1735     -4.9653518944978714e-03
    z[5,4,0]  R1736     2.8222510591149330e-03
    z[5,4,0]  R1737     -2.4970605969429016e-01
    z[5,4,0]  R1738     3.6843252182006836e-01
    z[5,4,0]  R1739     2.6904299855232239e-02
    z[5,4,0]  R1740     2.2376640141010284e-01
    z[5,4,0]  R1741     5.5176131427288055e-02
    z[5,4,0]  R1742     -6.9494640827178955e-01
    z[5,4,0]  R1743     -6.0231178998947144e-01
    z[5,4,0]  R1744     2.7584481239318848e-01
    z[5,4,0]  R1745     2.2619657218456268e-01
    z[5,4,0]  R1746     -2.4203982949256897e-01
    z[5,4,0]  R1747     -9.5208868384361267e-02
    z[5,4,0]  R1748     -1.5311998128890991e-01
    z[5,4,0]  R1749     3.1878852844238281e-01
    z[5,4,0]  R1750     -3.1288117170333862e-01
    z[5,4,0]  R1751     -6.1639484018087387e-02
    z[5,4,0]  R1752     -5.1401168107986450e-01
    z[5,4,0]  R1753     -4.5085260272026062e-01
    z[5,4,0]  R1754     -4.4631335139274597e-01
    z[5,4,0]  R1755     -1.3485868275165558e-01
    z[5,4,0]  R1756     0.544841468334198
    z[5,4,0]  R1757     4.5743012428283691e-01
    z[5,4,0]  R1758     2.6476213335990906e-01
    z[5,4,0]  R1759     1.8688598275184631e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1668     -1
    z[5,4,1]  R1669     1
    z[5,4,1]  R1680     -0.554340124130249
    z[5,4,1]  R1681     -6.7100626230239868e-01
    z[5,4,1]  R1682     -5.4123604297637939e-01
    z[5,4,1]  R1683     -6.1328488588333130e-01
    z[5,4,1]  R1684     -8.1643950939178467e-01
    z[5,4,1]  R1685     3.6129321902990341e-02
    z[5,4,1]  R1686     1.7198620736598969e-01
    z[5,4,1]  R1687     -0.0684293881058693
    z[5,4,1]  R1688     -1.2355047464370728e-01
    z[5,4,1]  R1689     1.3018621504306793e-01
    z[5,4,1]  R1690     -2.2815652191638947e-01
    z[5,4,1]  R1691     3.6367753148078918e-01
    z[5,4,1]  R1692     1.1067080497741699e-01
    z[5,4,1]  R1693     2.8792858123779297e-01
    z[5,4,1]  R1694     2.5240519642829895e-01
    z[5,4,1]  R1695     5.4331791400909424e-01
    z[5,4,1]  R1696     5.6653678417205811e-01
    z[5,4,1]  R1697     5.5422651767730713e-01
    z[5,4,1]  R1698     7.4812614917755127e-01
    z[5,4,1]  R1699     0.758578360080719
    z[5,4,1]  R1700     4.2381352186203003e-01
    z[5,4,1]  R1701     8.5695318877696991e-02
    z[5,4,1]  R1702     2.2513927519321442e-01
    z[5,4,1]  R1703     2.5168797373771667e-01
    z[5,4,1]  R1704     4.5791548490524292e-01
    z[5,4,1]  R1705     -1.1175908148288727e-01
    z[5,4,1]  R1706     2.9197549819946289e-01
    z[5,4,1]  R1707     -1.8015447258949280e-01
    z[5,4,1]  R1708     4.5995992422103882e-01
    z[5,4,1]  R1709     1.4378155767917633e-01
    z[5,4,1]  R1710     -8.0687880516052246e-02
    z[5,4,1]  R1711     3.3827960491180420e-01
    z[5,4,1]  R1712     -2.6293650269508362e-01
    z[5,4,1]  R1713     4.4365060329437256e-01
    z[5,4,1]  R1714     -1.2746001780033112e-01
    z[5,4,1]  R1715     7.3309385776519775e-01
    z[5,4,1]  R1716     -1.0934652388095856e-01
    z[5,4,1]  R1717     3.1935906410217285e-01
    z[5,4,1]  R1718     -1.7344640195369720e-01
    z[5,4,1]  R1719     1.3700337149202824e-04
    z[5,4,1]  R1720     9.0703427791595459e-02
    z[5,4,1]  R1721     -1.8035714328289032e-01
    z[5,4,1]  R1722     6.8937726318836212e-02
    z[5,4,1]  R1723     -2.4070395529270172e-01
    z[5,4,1]  R1724     1.8579232692718506e-01
    z[5,4,1]  R1725     1.3862904906272888e-01
    z[5,4,1]  R1726     1.8008811771869659e-01
    z[5,4,1]  R1727     -2.8175202012062073e-01
    z[5,4,1]  R1728     -6.8649560213088989e-01
    z[5,4,1]  R1729     -6.7654556035995483e-01
    z[5,4,1]  R1730     6.4975041151046753e-01
    z[5,4,1]  R1731     6.0589939355850220e-01
    z[5,4,1]  R1732     9.5547932386398315e-01
    z[5,4,1]  R1733     2.4890752136707306e-01
    z[5,4,1]  R1734     1.2335730716586113e-02
    z[5,4,1]  R1735     -0.477426677942276
    z[5,4,1]  R1736     -1.5880693495273590e-01
    z[5,4,1]  R1737     -3.6295831203460693e-01
    z[5,4,1]  R1738     1.5812905505299568e-02
    z[5,4,1]  R1739     -1.7650930583477020e-01
    z[5,4,1]  R1740     4.1115105152130127e-01
    z[5,4,1]  R1741     3.4792086482048035e-01
    z[5,4,1]  R1742     0.456438273191452
    z[5,4,1]  R1743     2.4656632542610168e-01
    z[5,4,1]  R1744     -4.8314133286476135e-01
    z[5,4,1]  R1745     7.0207816362380981e-01
    z[5,4,1]  R1746     6.8296289443969727e-01
    z[5,4,1]  R1747     5.4343974590301514e-01
    z[5,4,1]  R1748     5.8972358703613281e-01
    z[5,4,1]  R1749     -2.5271937251091003e-01
    z[5,4,1]  R1750     0.870954155921936
    z[5,4,1]  R1751     7.4187004566192627e-01
    z[5,4,1]  R1752     1.6852082312107086e-01
    z[5,4,1]  R1753     4.4823831319808960e-01
    z[5,4,1]  R1754     2.8948095440864563e-01
    z[5,4,1]  R1755     3.1888470053672791e-01
    z[5,4,1]  R1756     -1.2318441271781921e-01
    z[5,4,1]  R1757     -5.2266317605972290e-01
    z[5,4,1]  R1758     2.3398680984973907e-01
    z[5,4,1]  R1759     1.7198304831981659e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1670     -1
    z[5,4,2]  R1671     1
    z[5,4,2]  R1680     -6.8994587659835815e-01
    z[5,4,2]  R1681     -4.7157332301139832e-01
    z[5,4,2]  R1682     -2.1637642383575439e-01
    z[5,4,2]  R1683     -1.1653658747673035e-01
    z[5,4,2]  R1684     3.1965553760528564e-01
    z[5,4,2]  R1685     4.6624442934989929e-01
    z[5,4,2]  R1686     5.4059821367263794e-01
    z[5,4,2]  R1687     4.8135438561439514e-01
    z[5,4,2]  R1688     2.9447263479232788e-01
    z[5,4,2]  R1689     -5.8466184139251709e-01
    z[5,4,2]  R1690     0.0337735079228878
    z[5,4,2]  R1691     4.4190880656242371e-01
    z[5,4,2]  R1692     2.8016534447669983e-01
    z[5,4,2]  R1693     4.1245257854461670e-01
    z[5,4,2]  R1694     0.546988308429718
    z[5,4,2]  R1695     3.0850669741630554e-01
    z[5,4,2]  R1696     4.8759835958480835e-01
    z[5,4,2]  R1697     -4.5866728760302067e-03
    z[5,4,2]  R1698     -1.5615680813789368e-01
    z[5,4,2]  R1699     2.7312371134757996e-01
    z[5,4,2]  R1700     6.4112591743469238e-01
    z[5,4,2]  R1701     6.7079651355743408e-01
    z[5,4,2]  R1702     2.6852738857269287e-01
    z[5,4,2]  R1703     2.3587007820606232e-01
    z[5,4,2]  R1704     0.693960964679718
    z[5,4,2]  R1705     8.8741952180862427e-01
    z[5,4,2]  R1706     4.5759826898574829e-01
    z[5,4,2]  R1707     0.0328427255153656
    z[5,4,2]  R1708     1.7511083185672760e-01
    z[5,4,2]  R1709     -1.8304964900016785e-01
    z[5,4,2]  R1710     2.5656121969223022e-01
    z[5,4,2]  R1711     5.2649009227752686e-01
    z[5,4,2]  R1712     7.2265160083770752e-01
    z[5,4,2]  R1713     1.8507625162601471e-01
    z[5,4,2]  R1714     7.3358118534088135e-01
    z[5,4,2]  R1715     1.8976634740829468e-01
    z[5,4,2]  R1716     -3.2092091441154480e-01
    z[5,4,2]  R1717     5.8595299720764160e-01
    z[5,4,2]  R1718     1.5920553356409073e-02
    z[5,4,2]  R1719     -1.1534313112497330e-01
    z[5,4,2]  R1720     2.8583189845085144e-01
    z[5,4,2]  R1721     4.1041865944862366e-01
    z[5,4,2]  R1722     6.0781556367874146e-01
    z[5,4,2]  R1723     7.0913535356521606e-01
    z[5,4,2]  R1724     6.4988970756530762e-01
    z[5,4,2]  R1725     4.4665363430976868e-01
    z[5,4,2]  R1726     -0.0573224201798439
    z[5,4,2]  R1727     7.3578923940658569e-01
    z[5,4,2]  R1728     -4.7941815853118896e-01
    z[5,4,2]  R1729     -5.1720386743545532e-01
    z[5,4,2]  R1730     -3.5617422312498093e-02
    z[5,4,2]  R1731     -1.4120461046695709e-01
    z[5,4,2]  R1732     -8.9397631585597992e-02
    z[5,4,2]  R1733     -0.627575695514679
    z[5,4,2]  R1734     -3.0603927373886108e-01
    z[5,4,2]  R1735     -0.419014036655426
    z[5,4,2]  R1736     -0.333706259727478
    z[5,4,2]  R1737     -5.6432580947875977e-01
    z[5,4,2]  R1738     -3.5146871209144592e-01
    z[5,4,2]  R1739     -3.9342594146728516e-01
    z[5,4,2]  R1740     5.5873185396194458e-01
    z[5,4,2]  R1741     4.0096721053123474e-01
    z[5,4,2]  R1742     2.2632074356079102e-01
    z[5,4,2]  R1743     2.5209259986877441e-01
    z[5,4,2]  R1744     -4.2676281929016113e-01
    z[5,4,2]  R1745     1.1735233711078763e-03
    z[5,4,2]  R1746     1.0540015250444412e-01
    z[5,4,2]  R1747     8.9570038020610809e-02
    z[5,4,2]  R1748     -3.0892717838287354e-01
    z[5,4,2]  R1749     -4.6907064318656921e-01
    z[5,4,2]  R1750     2.4958732724189758e-01
    z[5,4,2]  R1751     2.2815760970115662e-01
    z[5,4,2]  R1752     5.3504353761672974e-01
    z[5,4,2]  R1753     6.6952472925186157e-01
    z[5,4,2]  R1754     3.9554160833358765e-01
    z[5,4,2]  R1755     -2.1934132277965546e-01
    z[5,4,2]  R1756     -6.5033769607543945e-01
    z[5,4,2]  R1757     -4.0592589974403381e-01
    z[5,4,2]  R1758     -6.9633078575134277e-01
    z[5,4,2]  R1759     -6.9222939014434814e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1672     -1
    z[5,4,3]  R1673     1
    z[5,4,3]  R1680     3.5014513134956360e-01
    z[5,4,3]  R1681     -3.6427515745162964e-01
    z[5,4,3]  R1682     -5.1047003269195557e-01
    z[5,4,3]  R1683     4.1621926426887512e-01
    z[5,4,3]  R1684     -1.1771318316459656e-01
    z[5,4,3]  R1685     1.4986169338226318e-01
    z[5,4,3]  R1686     -4.0647247433662415e-01
    z[5,4,3]  R1687     1.6493260860443115e-01
    z[5,4,3]  R1688     6.3142031431198120e-01
    z[5,4,3]  R1689     4.7200274467468262e-01
    z[5,4,3]  R1690     -1.7275893688201904e-01
    z[5,4,3]  R1691     -5.1414594054222107e-02
    z[5,4,3]  R1692     5.1054474897682667e-03
    z[5,4,3]  R1693     -6.0823790729045868e-02
    z[5,4,3]  R1694     3.9098763465881348e-01
    z[5,4,3]  R1695     2.2858822345733643e-01
    z[5,4,3]  R1696     3.1345912814140320e-01
    z[5,4,3]  R1697     1.8895380198955536e-01
    z[5,4,3]  R1698     -1.5413288772106171e-01
    z[5,4,3]  R1699     -6.4357981085777283e-02
    z[5,4,3]  R1700     -8.0260913819074631e-03
    z[5,4,3]  R1701     7.9134419560432434e-02
    z[5,4,3]  R1702     3.2658487558364868e-01
    z[5,4,3]  R1703     -3.9690818637609482e-02
    z[5,4,3]  R1704     4.2428621649742126e-01
    z[5,4,3]  R1705     3.2454070448875427e-01
    z[5,4,3]  R1706     1.7222511768341064e-01
    z[5,4,3]  R1707     2.8329461812973022e-01
    z[5,4,3]  R1708     3.5891965031623840e-01
    z[5,4,3]  R1709     2.9375055432319641e-01
    z[5,4,3]  R1710     0.315595418214798
    z[5,4,3]  R1711     1.5480515360832214e-01
    z[5,4,3]  R1712     4.0509562939405441e-02
    z[5,4,3]  R1713     5.1195913553237915e-01
    z[5,4,3]  R1714     1.0345229879021645e-02
    z[5,4,3]  R1715     3.8209143280982971e-01
    z[5,4,3]  R1716     -4.0541300177574158e-01
    z[5,4,3]  R1717     0.161179780960083
    z[5,4,3]  R1718     -6.9057798385620117e-01
    z[5,4,3]  R1719     -6.7248648405075073e-01
    z[5,4,3]  R1720     7.9734712839126587e-01
    z[5,4,3]  R1721     6.8379396200180054e-01
    z[5,4,3]  R1722     4.0485379099845886e-01
    z[5,4,3]  R1723     -6.9874495267868042e-02
    z[5,4,3]  R1724     -3.5210162401199341e-01
    z[5,4,3]  R1725     4.6901756525039673e-01
    z[5,4,3]  R1726     6.8851172924041748e-01
    z[5,4,3]  R1727     1.2063708156347275e-01
    z[5,4,3]  R1728     -1.9099628925323486e-01
    z[5,4,3]  R1729     -0.0162209402769804
    z[5,4,3]  R1730     1.4994834363460541e-01
    z[5,4,3]  R1731     8.5919030010700226e-02
    z[5,4,3]  R1732     2.9778733849525452e-02
    z[5,4,3]  R1733     -0.585460901260376
    z[5,4,3]  R1734     -6.4031469821929932e-01
    z[5,4,3]  R1735     -4.1169667243957520e-01
    z[5,4,3]  R1736     -7.3668831586837769e-01
    z[5,4,3]  R1737     3.5517036914825439e-02
    z[5,4,3]  R1738     -7.5250577926635742e-01
    z[5,4,3]  R1739     -6.9029337167739868e-01
    z[5,4,3]  R1740     1.0706377774477005e-01
    z[5,4,3]  R1741     4.1478452086448669e-01
    z[5,4,3]  R1742     7.4573658406734467e-02
    z[5,4,3]  R1743     4.4015997648239136e-01
    z[5,4,3]  R1744     -5.5497705936431885e-01
    z[5,4,3]  R1745     4.8583814501762390e-01
    z[5,4,3]  R1746     1.8936289846897125e-01
    z[5,4,3]  R1747     8.3995535969734192e-02
    z[5,4,3]  R1748     6.4312392473220825e-01
    z[5,4,3]  R1749     -4.0286022424697876e-01
    z[5,4,3]  R1750     1.5088823437690735e-01
    z[5,4,3]  R1751     2.0504210889339447e-01
    z[5,4,3]  R1752     3.8115409016609192e-01
    z[5,4,3]  R1753     -2.0081575214862823e-01
    z[5,4,3]  R1754     3.2083225250244141e-01
    z[5,4,3]  R1755     8.3555358648300171e-01
    z[5,4,3]  R1756     -3.6146077513694763e-01
    z[5,4,3]  R1757     -2.1051061153411865e-01
    z[5,4,3]  R1758     -4.5876809954643250e-01
    z[5,4,3]  R1759     -6.5730553865432739e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1674     -1
    z[5,4,4]  R1675     1
    z[5,4,4]  R1680     -8.4111243486404419e-02
    z[5,4,4]  R1681     1.7591449618339539e-01
    z[5,4,4]  R1682     1.4838105440139771e-01
    z[5,4,4]  R1683     1.8645854294300079e-01
    z[5,4,4]  R1684     2.4851320683956146e-01
    z[5,4,4]  R1685     1.8241493403911591e-01
    z[5,4,4]  R1686     2.4589349329471588e-01
    z[5,4,4]  R1687     1.2977319955825806e-01
    z[5,4,4]  R1688     1.1258167028427124e-01
    z[5,4,4]  R1689     -0.160190612077713
    z[5,4,4]  R1690     3.1359833478927612e-01
    z[5,4,4]  R1691     1.0080862790346146e-01
    z[5,4,4]  R1692     2.5663849711418152e-01
    z[5,4,4]  R1693     1.4975853264331818e-01
    z[5,4,4]  R1694     7.1244575083255768e-02
    z[5,4,4]  R1695     6.0734695196151733e-01
    z[5,4,4]  R1696     -2.2092871367931366e-01
    z[5,4,4]  R1697     5.9946626424789429e-01
    z[5,4,4]  R1698     -1.4683061838150024e-01
    z[5,4,4]  R1699     -2.0465135574340820e-01
    z[5,4,4]  R1700     1.0752888023853302e-01
    z[5,4,4]  R1701     -1.2483403831720352e-01
    z[5,4,4]  R1702     -7.7004201710224152e-02
    z[5,4,4]  R1703     -7.0594884455204010e-02
    z[5,4,4]  R1704     -1.8695162236690521e-01
    z[5,4,4]  R1705     2.9199129343032837e-01
    z[5,4,4]  R1706     7.3304343223571777e-01
    z[5,4,4]  R1707     1.8396420776844025e-01
    z[5,4,4]  R1708     5.2788454294204712e-01
    z[5,4,4]  R1709     0.0999830886721611
    z[5,4,4]  R1710     4.4631978869438171e-01
    z[5,4,4]  R1711     -0.260684072971344
    z[5,4,4]  R1712     4.9166500568389893e-02
    z[5,4,4]  R1713     -2.4913236498832703e-01
    z[5,4,4]  R1714     5.1458673551678658e-03
    z[5,4,4]  R1715     2.4429830908775330e-01
    z[5,4,4]  R1716     2.8930205106735229e-01
    z[5,4,4]  R1717     6.8917974829673767e-02
    z[5,4,4]  R1718     2.9879891872406006e-01
    z[5,4,4]  R1719     2.7954256534576416e-01
    z[5,4,4]  R1720     2.8962832689285278e-01
    z[5,4,4]  R1721     9.4165757298469543e-02
    z[5,4,4]  R1722     -0.375297486782074
    z[5,4,4]  R1723     -6.2481898814439774e-02
    z[5,4,4]  R1724     2.3791453242301941e-01
    z[5,4,4]  R1725     -3.4306889772415161e-01
    z[5,4,4]  R1726     -4.9269944429397583e-01
    z[5,4,4]  R1727     -2.7725201845169067e-01
    z[5,4,4]  R1728     -1.7659810185432434e-01
    z[5,4,4]  R1729     -2.8725671768188477e-01
    z[5,4,4]  R1730     1.4359951019287109e-01
    z[5,4,4]  R1731     -2.5267881155014038e-01
    z[5,4,4]  R1732     3.2495800405740738e-02
    z[5,4,4]  R1733     1.7760351300239563e-01
    z[5,4,4]  R1734     2.9704385995864868e-01
    z[5,4,4]  R1735     5.0171726942062378e-01
    z[5,4,4]  R1736     4.2885333299636841e-01
    z[5,4,4]  R1737     1.6307403147220612e-01
    z[5,4,4]  R1738     -0.385662317276001
    z[5,4,4]  R1739     -2.0439927279949188e-01
    z[5,4,4]  R1740     2.3397077620029449e-01
    z[5,4,4]  R1741     -4.3531784415245056e-01
    z[5,4,4]  R1742     0.378226101398468
    z[5,4,4]  R1743     -4.9855765700340271e-01
    z[5,4,4]  R1744     7.0312090218067169e-02
    z[5,4,4]  R1745     -2.9113510251045227e-01
    z[5,4,4]  R1746     -0.640434205532074
    z[5,4,4]  R1747     -5.1009333133697510e-01
    z[5,4,4]  R1748     -2.8283417224884033e-01
    z[5,4,4]  R1749     -5.1376384496688843e-01
    z[5,4,4]  R1750     1.2046154588460922e-01
    z[5,4,4]  R1751     -5.4465734958648682e-01
    z[5,4,4]  R1752     -1.9026456773281097e-01
    z[5,4,4]  R1753     -1.1776334047317505e-01
    z[5,4,4]  R1754     4.4609126448631287e-01
    z[5,4,4]  R1755     -2.0541222393512726e-01
    z[5,4,4]  R1756     0.0743880346417427
    z[5,4,4]  R1757     -5.3647822141647339e-01
    z[5,4,4]  R1758     -1.4164827764034271e-01
    z[5,4,4]  R1759     9.1382518410682678e-02
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1676     -1
    z[5,4,5]  R1677     1
    z[5,4,5]  R1680     -1.4309965074062347e-01
    z[5,4,5]  R1681     9.5048017799854279e-02
    z[5,4,5]  R1682     8.6816504597663879e-02
    z[5,4,5]  R1683     2.6909697055816650e-01
    z[5,4,5]  R1684     -3.8634249567985535e-01
    z[5,4,5]  R1685     -8.3060008287429810e-01
    z[5,4,5]  R1686     -6.3589096069335938e-01
    z[5,4,5]  R1687     -4.4720986485481262e-01
    z[5,4,5]  R1688     -4.9541616439819336e-01
    z[5,4,5]  R1689     -2.8148138523101807e-01
    z[5,4,5]  R1690     5.9881383180618286e-01
    z[5,4,5]  R1691     9.1375805437564850e-02
    z[5,4,5]  R1692     4.1600292921066284e-01
    z[5,4,5]  R1693     7.8808829188346863e-02
    z[5,4,5]  R1694     6.0233663767576218e-02
    z[5,4,5]  R1695     3.1459605693817139e-01
    z[5,4,5]  R1696     2.8942698240280151e-01
    z[5,4,5]  R1697     1.5429291129112244e-01
    z[5,4,5]  R1698     4.3332797288894653e-01
    z[5,4,5]  R1699     -1.9631743431091309e-01
    z[5,4,5]  R1700     -3.2332543283700943e-02
    z[5,4,5]  R1701     -9.9013172090053558e-02
    z[5,4,5]  R1702     -3.7514790892601013e-02
    z[5,4,5]  R1703     -2.1448303759098053e-01
    z[5,4,5]  R1704     1.9197199493646622e-02
    z[5,4,5]  R1705     5.4930694401264191e-02
    z[5,4,5]  R1706     1.3632969558238983e-01
    z[5,4,5]  R1707     -2.3126402497291565e-01
    z[5,4,5]  R1708     0.122758649289608
    z[5,4,5]  R1709     0.195773646235466
    z[5,4,5]  R1710     -4.1888365149497986e-01
    z[5,4,5]  R1711     -5.7614952325820923e-01
    z[5,4,5]  R1712     -6.2454670667648315e-01
    z[5,4,5]  R1713     -4.7182309627532959e-01
    z[5,4,5]  R1714     -3.8587334752082825e-01
    z[5,4,5]  R1715     -0.326010525226593
    z[5,4,5]  R1716     5.2686333656311035e-01
    z[5,4,5]  R1717     -7.8539215028285980e-02
    z[5,4,5]  R1718     -3.0201127752661705e-02
    z[5,4,5]  R1719     3.0798721313476562e-01
    z[5,4,5]  R1720     -4.3192145228385925e-01
    z[5,4,5]  R1721     -3.5169312357902527e-01
    z[5,4,5]  R1722     -5.3854197263717651e-01
    z[5,4,5]  R1723     -5.3042483329772949e-01
    z[5,4,5]  R1724     -5.6895679235458374e-01
    z[5,4,5]  R1725     -3.0301621556282043e-01
    z[5,4,5]  R1726     -4.4310775399208069e-01
    z[5,4,5]  R1727     3.4799691289663315e-02
    z[5,4,5]  R1728     -2.1711723878979683e-02
    z[5,4,5]  R1729     3.6115863919258118e-01
    z[5,4,5]  R1730     4.0278828144073486e-01
    z[5,4,5]  R1731     3.6516085267066956e-01
    z[5,4,5]  R1732     1.3691034913063049e-01
    z[5,4,5]  R1733     3.8916292786598206e-01
    z[5,4,5]  R1734     4.3744662404060364e-01
    z[5,4,5]  R1735     2.6634088158607483e-01
    z[5,4,5]  R1736     2.4068865180015564e-01
    z[5,4,5]  R1737     2.8285548090934753e-01
    z[5,4,5]  R1738     1.5305081009864807e-01
    z[5,4,5]  R1739     1.4244772493839264e-01
    z[5,4,5]  R1740     -4.6020811796188354e-01
    z[5,4,5]  R1741     -8.6697600781917572e-02
    z[5,4,5]  R1742     -2.4631278216838837e-01
    z[5,4,5]  R1743     2.5095903873443604e-01
    z[5,4,5]  R1744     4.2448881268501282e-01
    z[5,4,5]  R1745     -2.0095948874950409e-01
    z[5,4,5]  R1746     -8.2308724522590637e-02
    z[5,4,5]  R1747     -4.2418184876441956e-01
    z[5,4,5]  R1748     -4.5460681430995464e-03
    z[5,4,5]  R1749     2.3905214667320251e-01
    z[5,4,5]  R1750     -2.0068673789501190e-01
    z[5,4,5]  R1751     -1.6319629549980164e-01
    z[5,4,5]  R1752     -1.6506245732307434e-01
    z[5,4,5]  R1753     1.7667191103100777e-02
    z[5,4,5]  R1754     2.0985834300518036e-01
    z[5,4,5]  R1755     2.0626035332679749e-01
    z[5,4,5]  R1756     -1.1976198852062225e-01
    z[5,4,5]  R1757     1.4380528032779694e-01
    z[5,4,5]  R1758     3.9840835332870483e-01
    z[5,4,5]  R1759     -1.1201862990856171e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1678     -1
    z[5,4,6]  R1679     1
    z[5,4,6]  R1680     -1.3519684970378876e-01
    z[5,4,6]  R1681     5.3564831614494324e-02
    z[5,4,6]  R1682     0.361736923456192
    z[5,4,6]  R1683     5.7302600145339966e-01
    z[5,4,6]  R1684     -2.4264581501483917e-02
    z[5,4,6]  R1685     4.8225581645965576e-02
    z[5,4,6]  R1686     3.7936046719551086e-02
    z[5,4,6]  R1687     -6.4364320039749146e-01
    z[5,4,6]  R1688     -3.0650213360786438e-01
    z[5,4,6]  R1689     1.6895861923694611e-01
    z[5,4,6]  R1690     -6.7200702428817749e-01
    z[5,4,6]  R1691     6.7640833556652069e-02
    z[5,4,6]  R1692     -1.9662520289421082e-01
    z[5,4,6]  R1693     -3.8255810737609863e-01
    z[5,4,6]  R1694     -4.1507405042648315e-01
    z[5,4,6]  R1695     5.9493549168109894e-02
    z[5,4,6]  R1696     3.2696339488029480e-01
    z[5,4,6]  R1697     2.6271492242813110e-01
    z[5,4,6]  R1698     1.8878260254859924e-01
    z[5,4,6]  R1699     -4.1211363673210144e-01
    z[5,4,6]  R1700     3.4649577736854553e-01
    z[5,4,6]  R1701     -3.9930595085024834e-03
    z[5,4,6]  R1702     -1.6441099345684052e-02
    z[5,4,6]  R1703     -2.3564879596233368e-01
    z[5,4,6]  R1704     1.5668654814362526e-02
    z[5,4,6]  R1705     -7.9948879778385162e-02
    z[5,4,6]  R1706     1.9399905204772949e-01
    z[5,4,6]  R1707     -1.8508534133434296e-01
    z[5,4,6]  R1708     -8.7443970143795013e-02
    z[5,4,6]  R1709     -5.8296483755111694e-01
    z[5,4,6]  R1710     0.16391621530056
    z[5,4,6]  R1711     -2.4543851613998413e-01
    z[5,4,6]  R1712     -3.4087572246789932e-02
    z[5,4,6]  R1713     3.3718466758728027e-01
    z[5,4,6]  R1714     5.3106665611267090e-01
    z[5,4,6]  R1715     -2.6652488112449646e-01
    z[5,4,6]  R1716     -4.1730406880378723e-01
    z[5,4,6]  R1717     -2.5357139110565186e-01
    z[5,4,6]  R1718     -4.2735478281974792e-01
    z[5,4,6]  R1719     -2.5798463821411133e-01
    z[5,4,6]  R1720     2.2819772362709045e-02
    z[5,4,6]  R1721     2.6156494021415710e-01
    z[5,4,6]  R1722     1.1140027642250061e-01
    z[5,4,6]  R1723     3.0666095018386841e-01
    z[5,4,6]  R1724     1.8192812800407410e-01
    z[5,4,6]  R1725     -5.9109717607498169e-01
    z[5,4,6]  R1726     -2.1954016387462616e-01
    z[5,4,6]  R1727     -3.8180452585220337e-01
    z[5,4,6]  R1728     -1.0552482306957245e-01
    z[5,4,6]  R1729     -2.1591672301292419e-01
    z[5,4,6]  R1730     -0.055225919932127
    z[5,4,6]  R1731     2.0017151534557343e-01
    z[5,4,6]  R1732     -1.8719619512557983e-01
    z[5,4,6]  R1733     1.3574877381324768e-01
    z[5,4,6]  R1734     -3.9006552100181580e-01
    z[5,4,6]  R1735     3.2297751307487488e-01
    z[5,4,6]  R1736     2.8081426024436951e-01
    z[5,4,6]  R1737     6.1610287427902222e-01
    z[5,4,6]  R1738     4.5302573591470718e-02
    z[5,4,6]  R1739     5.2417677640914917e-01
    z[5,4,6]  R1740     -4.3669855594635010e-01
    z[5,4,6]  R1741     -5.8827507495880127e-01
    z[5,4,6]  R1742     2.1955946087837219e-01
    z[5,4,6]  R1743     -8.7143093347549438e-02
    z[5,4,6]  R1744     -1.2338374555110931e-01
    z[5,4,6]  R1745     -3.0779343843460083e-01
    z[5,4,6]  R1746     1.0526287555694580e-01
    z[5,4,6]  R1747     4.9031114578247070e-01
    z[5,4,6]  R1748     1.9929949939250946e-01
    z[5,4,6]  R1749     -3.6205506324768066e-01
    z[5,4,6]  R1750     6.0803771018981934e-02
    z[5,4,6]  R1751     -1.6866151988506317e-01
    z[5,4,6]  R1752     -4.6086505055427551e-01
    z[5,4,6]  R1753     -3.0503043532371521e-01
    z[5,4,6]  R1754     -4.6322867274284363e-01
    z[5,4,6]  R1755     -2.2164769470691681e-01
    z[5,4,6]  R1756     3.3838397264480591e-01
    z[5,4,6]  R1757     1.2639641063287854e-03
    z[5,4,6]  R1758     3.1826782971620560e-02
    z[5,4,6]  R1759     -5.8003194630146027e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R1760     -1
    z[5,6,0]  R1761     1
    z[5,6,0]  R1774     -2.1965850889682770e-01
    z[5,6,0]  R1775     3.8964539766311646e-01
    z[5,6,0]  R1776     -4.8913940787315369e-01
    z[5,6,0]  R1777     3.9033308625221252e-02
    z[5,6,0]  R1778     -7.6041102409362793e-02
    z[5,6,0]  R1779     -1.8263314664363861e-01
    z[5,6,0]  R1780     -2.1608844399452209e-01
    z[5,6,0]  R1781     -3.2449704408645630e-01
    z[5,6,0]  R1782     -3.8376316428184509e-01
    z[5,6,0]  R1783     0.533849835395813
    z[5,6,0]  R1784     9.1885060071945190e-02
    z[5,6,0]  R1785     8.0419188737869263e-01
    z[5,6,0]  R1786     7.9476422071456909e-01
    z[5,6,0]  R1787     7.5385099649429321e-01
    z[5,6,0]  R1788     5.5066674947738647e-01
    z[5,6,0]  R1789     -2.9325127601623535e-01
    z[5,6,0]  R1790     -3.2178360223770142e-01
    z[5,6,0]  R1791     -4.5268434286117554e-01
    z[5,6,0]  R1792     3.8365894556045532e-01
    z[5,6,0]  R1793     3.0912798643112183e-01
    z[5,6,0]  R1794     -5.2593553066253662e-01
    z[5,6,0]  R1795     -7.1485877037048340e-01
    z[5,6,0]  R1796     -8.7346452474594116e-01
    z[5,6,0]  R1797     -8.7916219234466553e-01
    z[5,6,0]  R1798     -3.0520135164260864e-01
    z[5,6,0]  R1799     1.2800628319382668e-03
    z[5,6,0]  R1800     -2.8656333684921265e-01
    z[5,6,0]  R1801     8.7442982196807861e-01
    z[5,6,0]  R1802     -5.7233875989913940e-01
    z[5,6,0]  R1803     6.8655538558959961e-01
    z[5,6,0]  R1804     -6.5309411287307739e-01
    z[5,6,0]  R1805     -3.5251370072364807e-01
    z[5,6,0]  R1806     -1.1558666080236435e-01
    z[5,6,0]  R1807     -3.2930415868759155e-01
    z[5,6,0]  R1808     -1.2061957269906998e-01
    z[5,6,0]  R1809     -2.0873010158538818e-01
    z[5,6,0]  R1810     4.3043011426925659e-01
    z[5,6,0]  R1811     0.673404335975647
    z[5,6,0]  R1812     4.6897763013839722e-01
    z[5,6,0]  R1813     5.4304844141006470e-01
    z[5,6,0]  R1814     -2.6171565055847168e-01
    z[5,6,0]  R1815     -4.8409137129783630e-01
    z[5,6,0]  R1816     -4.0355199575424194e-01
    z[5,6,0]  R1817     3.8174521923065186e-01
    z[5,6,0]  R1818     4.4334220886230469e-01
    z[5,6,0]  R1819     6.9331407546997070e-01
    z[5,6,0]  R1820     5.3337591886520386e-01
    z[5,6,0]  R1821     4.0423554182052612e-01
    z[5,6,0]  R1822     5.2008930593729019e-02
    z[5,6,0]  R1823     1.6269832849502563e-01
    z[5,6,0]  R1824     1.8686690926551819e-01
    z[5,6,0]  R1825     2.0650996267795563e-01
    z[5,6,0]  R1826     0.518527626991272
    z[5,6,0]  R1827     -2.3127996921539307e-01
    z[5,6,0]  R1828     9.4481986016035080e-03
    z[5,6,0]  R1829     -5.1704061031341553e-01
    z[5,6,0]  R1830     -2.1425540745258331e-01
    z[5,6,0]  R1831     1.6143192350864410e-01
    z[5,6,0]  R1832     9.0215191245079041e-02
    z[5,6,0]  R1833     -2.6278412342071533e-01
    z[5,6,0]  R1834     2.7463972568511963e-01
    z[5,6,0]  R1835     4.4837236404418945e-02
    z[5,6,0]  R1836     4.5980989933013916e-01
    z[5,6,0]  R1837     2.1286228299140930e-01
    z[5,6,0]  R1838     2.9343879222869873e-01
    z[5,6,0]  R1839     -3.5603947937488556e-02
    z[5,6,0]  R1840     -1.9836364313960075e-02
    z[5,6,0]  R1841     -4.4679844379425049e-01
    z[5,6,0]  R1842     1.1935807764530182e-01
    z[5,6,0]  R1843     5.2002698183059692e-01
    z[5,6,0]  R1844     2.4204833805561066e-01
    z[5,6,0]  R1845     -1.7059673368930817e-01
    z[5,6,0]  R1846     -7.4065856635570526e-02
    z[5,6,0]  R1847     -1.4131058752536774e-01
    z[5,6,0]  R1848     4.5075584203004837e-02
    z[5,6,0]  R1849     0.470356822013855
    z[5,6,0]  R1850     4.0498252958059311e-02
    z[5,6,0]  R1851     1.9757135212421417e-01
    z[5,6,0]  R1852     -1.5444062650203705e-01
    z[5,6,0]  R1853     1.4068734645843506e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R1762     -1
    z[5,6,1]  R1763     1
    z[5,6,1]  R1774     -0.554340124130249
    z[5,6,1]  R1775     -6.7100626230239868e-01
    z[5,6,1]  R1776     -5.4123604297637939e-01
    z[5,6,1]  R1777     -6.1328488588333130e-01
    z[5,6,1]  R1778     -8.1643950939178467e-01
    z[5,6,1]  R1779     3.6129321902990341e-02
    z[5,6,1]  R1780     1.7198620736598969e-01
    z[5,6,1]  R1781     -0.0684293881058693
    z[5,6,1]  R1782     -1.2355047464370728e-01
    z[5,6,1]  R1783     1.3018621504306793e-01
    z[5,6,1]  R1784     -2.2815652191638947e-01
    z[5,6,1]  R1785     3.6367753148078918e-01
    z[5,6,1]  R1786     1.1067080497741699e-01
    z[5,6,1]  R1787     2.8792858123779297e-01
    z[5,6,1]  R1788     2.5240519642829895e-01
    z[5,6,1]  R1789     5.4331791400909424e-01
    z[5,6,1]  R1790     5.6653678417205811e-01
    z[5,6,1]  R1791     5.5422651767730713e-01
    z[5,6,1]  R1792     7.4812614917755127e-01
    z[5,6,1]  R1793     0.758578360080719
    z[5,6,1]  R1794     4.2381352186203003e-01
    z[5,6,1]  R1795     8.5695318877696991e-02
    z[5,6,1]  R1796     2.2513927519321442e-01
    z[5,6,1]  R1797     2.5168797373771667e-01
    z[5,6,1]  R1798     4.5791548490524292e-01
    z[5,6,1]  R1799     -1.1175908148288727e-01
    z[5,6,1]  R1800     2.9197549819946289e-01
    z[5,6,1]  R1801     -1.8015447258949280e-01
    z[5,6,1]  R1802     4.5995992422103882e-01
    z[5,6,1]  R1803     1.4378155767917633e-01
    z[5,6,1]  R1804     -8.0687880516052246e-02
    z[5,6,1]  R1805     3.3827960491180420e-01
    z[5,6,1]  R1806     -2.6293650269508362e-01
    z[5,6,1]  R1807     4.4365060329437256e-01
    z[5,6,1]  R1808     -1.2746001780033112e-01
    z[5,6,1]  R1809     7.3309385776519775e-01
    z[5,6,1]  R1810     -1.0934652388095856e-01
    z[5,6,1]  R1811     3.1935906410217285e-01
    z[5,6,1]  R1812     -1.7344640195369720e-01
    z[5,6,1]  R1813     1.3700337149202824e-04
    z[5,6,1]  R1814     -5.4178398847579956e-01
    z[5,6,1]  R1815     -6.9878840446472168e-01
    z[5,6,1]  R1816     -6.4104229211807251e-01
    z[5,6,1]  R1817     -6.2312567234039307e-01
    z[5,6,1]  R1818     -6.4854383468627930e-01
    z[5,6,1]  R1819     -5.5554753541946411e-01
    z[5,6,1]  R1820     -5.5843216180801392e-01
    z[5,6,1]  R1821     -6.1905372142791748e-01
    z[5,6,1]  R1822     3.2348605990409851e-01
    z[5,6,1]  R1823     2.7741560339927673e-01
    z[5,6,1]  R1824     7.0114231109619141e-01
    z[5,6,1]  R1825     8.0504411458969116e-01
    z[5,6,1]  R1826     7.4551194906234741e-01
    z[5,6,1]  R1827     0.799316942691803
    z[5,6,1]  R1828     5.7951068878173828e-01
    z[5,6,1]  R1829     7.2197246551513672e-01
    z[5,6,1]  R1830     8.2318013906478882e-01
    z[5,6,1]  R1831     3.9585524797439575e-01
    z[5,6,1]  R1832     -1.6483476758003235e-01
    z[5,6,1]  R1833     -3.2920852303504944e-01
    z[5,6,1]  R1834     -5.7070219516754150e-01
    z[5,6,1]  R1835     -2.3279976844787598e-01
    z[5,6,1]  R1836     -2.3191344738006592e-01
    z[5,6,1]  R1837     -3.1613373756408691e-01
    z[5,6,1]  R1838     -5.6601864099502563e-01
    z[5,6,1]  R1839     -6.1027604341506958e-01
    z[5,6,1]  R1840     -5.3468197584152222e-01
    z[5,6,1]  R1841     -4.9905860424041748e-01
    z[5,6,1]  R1842     -2.8273808956146240e-01
    z[5,6,1]  R1843     5.5129849910736084e-01
    z[5,6,1]  R1844     -7.7998697757720947e-01
    z[5,6,1]  R1845     -5.2748590707778931e-01
    z[5,6,1]  R1846     6.0195082426071167e-01
    z[5,6,1]  R1847     5.9612119197845459e-01
    z[5,6,1]  R1848     6.3063758611679077e-01
    z[5,6,1]  R1849     7.5140869617462158e-01
    z[5,6,1]  R1850     2.4554686248302460e-01
    z[5,6,1]  R1851     3.0078712105751038e-01
    z[5,6,1]  R1852     6.2154537439346313e-01
    z[5,6,1]  R1853     4.2001038789749146e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R1764     -1
    z[5,6,2]  R1765     1
    z[5,6,2]  R1774     -6.8994587659835815e-01
    z[5,6,2]  R1775     -4.7157332301139832e-01
    z[5,6,2]  R1776     -2.1637642383575439e-01
    z[5,6,2]  R1777     -1.1653658747673035e-01
    z[5,6,2]  R1778     3.1965553760528564e-01
    z[5,6,2]  R1779     4.6624442934989929e-01
    z[5,6,2]  R1780     5.4059821367263794e-01
    z[5,6,2]  R1781     4.8135438561439514e-01
    z[5,6,2]  R1782     2.9447263479232788e-01
    z[5,6,2]  R1783     -5.8466184139251709e-01
    z[5,6,2]  R1784     0.0337735079228878
    z[5,6,2]  R1785     4.4190880656242371e-01
    z[5,6,2]  R1786     2.8016534447669983e-01
    z[5,6,2]  R1787     4.1245257854461670e-01
    z[5,6,2]  R1788     0.546988308429718
    z[5,6,2]  R1789     3.0850669741630554e-01
    z[5,6,2]  R1790     4.8759835958480835e-01
    z[5,6,2]  R1791     -4.5866728760302067e-03
    z[5,6,2]  R1792     -1.5615680813789368e-01
    z[5,6,2]  R1793     2.7312371134757996e-01
    z[5,6,2]  R1794     6.4112591743469238e-01
    z[5,6,2]  R1795     6.7079651355743408e-01
    z[5,6,2]  R1796     2.6852738857269287e-01
    z[5,6,2]  R1797     2.3587007820606232e-01
    z[5,6,2]  R1798     0.693960964679718
    z[5,6,2]  R1799     8.8741952180862427e-01
    z[5,6,2]  R1800     4.5759826898574829e-01
    z[5,6,2]  R1801     0.0328427255153656
    z[5,6,2]  R1802     1.7511083185672760e-01
    z[5,6,2]  R1803     -1.8304964900016785e-01
    z[5,6,2]  R1804     2.5656121969223022e-01
    z[5,6,2]  R1805     5.2649009227752686e-01
    z[5,6,2]  R1806     7.2265160083770752e-01
    z[5,6,2]  R1807     1.8507625162601471e-01
    z[5,6,2]  R1808     7.3358118534088135e-01
    z[5,6,2]  R1809     1.8976634740829468e-01
    z[5,6,2]  R1810     -3.2092091441154480e-01
    z[5,6,2]  R1811     5.8595299720764160e-01
    z[5,6,2]  R1812     1.5920553356409073e-02
    z[5,6,2]  R1813     -1.1534313112497330e-01
    z[5,6,2]  R1814     -7.2222578525543213e-01
    z[5,6,2]  R1815     -2.1871227025985718e-01
    z[5,6,2]  R1816     -2.7881475165486336e-02
    z[5,6,2]  R1817     1.7660474777221680e-01
    z[5,6,2]  R1818     2.2964945435523987e-01
    z[5,6,2]  R1819     0.317281574010849
    z[5,6,2]  R1820     6.0548734664916992e-01
    z[5,6,2]  R1821     1.7457424104213715e-01
    z[5,6,2]  R1822     0.370514452457428
    z[5,6,2]  R1823     2.9978102445602417e-01
    z[5,6,2]  R1824     4.9604347348213196e-01
    z[5,6,2]  R1825     2.4289000034332275e-01
    z[5,6,2]  R1826     -6.0649398714303970e-02
    z[5,6,2]  R1827     3.9552986621856689e-01
    z[5,6,2]  R1828     2.5210650637745857e-03
    z[5,6,2]  R1829     1.1607456207275391e-01
    z[5,6,2]  R1830     -2.7868294715881348e-01
    z[5,6,2]  R1831     9.7012668848037720e-02
    z[5,6,2]  R1832     -3.6694344133138657e-02
    z[5,6,2]  R1833     5.1258850097656250e-01
    z[5,6,2]  R1834     -2.5376963615417480e-01
    z[5,6,2]  R1835     -8.5715778172016144e-02
    z[5,6,2]  R1836     -2.3895697295665741e-01
    z[5,6,2]  R1837     5.1837243139743805e-02
    z[5,6,2]  R1838     1.9625426828861237e-01
    z[5,6,2]  R1839     4.5921251177787781e-01
    z[5,6,2]  R1840     -1.5197678469121456e-02
    z[5,6,2]  R1841     3.5245051980018616e-01
    z[5,6,2]  R1842     -2.3002301156520844e-01
    z[5,6,2]  R1843     4.7003245353698730e-01
    z[5,6,2]  R1844     -7.8544422984123230e-02
    z[5,6,2]  R1845     3.7402617931365967e-01
    z[5,6,2]  R1846     6.9573557376861572e-01
    z[5,6,2]  R1847     5.0485479831695557e-01
    z[5,6,2]  R1848     2.0139449834823608e-01
    z[5,6,2]  R1849     3.9129763841629028e-02
    z[5,6,2]  R1850     8.4094721078872681e-01
    z[5,6,2]  R1851     6.8945086002349854e-01
    z[5,6,2]  R1852     4.4315326213836670e-01
    z[5,6,2]  R1853     4.9261784553527832e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R1766     -1
    z[5,6,3]  R1767     1
    z[5,6,3]  R1774     3.5014513134956360e-01
    z[5,6,3]  R1775     -3.6427515745162964e-01
    z[5,6,3]  R1776     -5.1047003269195557e-01
    z[5,6,3]  R1777     4.1621926426887512e-01
    z[5,6,3]  R1778     -1.1771318316459656e-01
    z[5,6,3]  R1779     1.4986169338226318e-01
    z[5,6,3]  R1780     -4.0647247433662415e-01
    z[5,6,3]  R1781     1.6493260860443115e-01
    z[5,6,3]  R1782     6.3142031431198120e-01
    z[5,6,3]  R1783     4.7200274467468262e-01
    z[5,6,3]  R1784     -1.7275893688201904e-01
    z[5,6,3]  R1785     -5.1414594054222107e-02
    z[5,6,3]  R1786     5.1054474897682667e-03
    z[5,6,3]  R1787     -6.0823790729045868e-02
    z[5,6,3]  R1788     3.9098763465881348e-01
    z[5,6,3]  R1789     2.2858822345733643e-01
    z[5,6,3]  R1790     3.1345912814140320e-01
    z[5,6,3]  R1791     1.8895380198955536e-01
    z[5,6,3]  R1792     -1.5413288772106171e-01
    z[5,6,3]  R1793     -6.4357981085777283e-02
    z[5,6,3]  R1794     -8.0260913819074631e-03
    z[5,6,3]  R1795     7.9134419560432434e-02
    z[5,6,3]  R1796     3.2658487558364868e-01
    z[5,6,3]  R1797     -3.9690818637609482e-02
    z[5,6,3]  R1798     4.2428621649742126e-01
    z[5,6,3]  R1799     3.2454070448875427e-01
    z[5,6,3]  R1800     1.7222511768341064e-01
    z[5,6,3]  R1801     2.8329461812973022e-01
    z[5,6,3]  R1802     3.5891965031623840e-01
    z[5,6,3]  R1803     2.9375055432319641e-01
    z[5,6,3]  R1804     0.315595418214798
    z[5,6,3]  R1805     1.5480515360832214e-01
    z[5,6,3]  R1806     4.0509562939405441e-02
    z[5,6,3]  R1807     5.1195913553237915e-01
    z[5,6,3]  R1808     1.0345229879021645e-02
    z[5,6,3]  R1809     3.8209143280982971e-01
    z[5,6,3]  R1810     -4.0541300177574158e-01
    z[5,6,3]  R1811     0.161179780960083
    z[5,6,3]  R1812     -6.9057798385620117e-01
    z[5,6,3]  R1813     -6.7248648405075073e-01
    z[5,6,3]  R1814     2.5378414988517761e-01
    z[5,6,3]  R1815     -2.3658950626850128e-01
    z[5,6,3]  R1816     9.3324109911918640e-02
    z[5,6,3]  R1817     -1.0986461490392685e-01
    z[5,6,3]  R1818     -8.5124827921390533e-02
    z[5,6,3]  R1819     2.5477004051208496e-01
    z[5,6,3]  R1820     -9.1371774673461914e-02
    z[5,6,3]  R1821     -2.2307975217700005e-02
    z[5,6,3]  R1822     -2.1528103947639465e-01
    z[5,6,3]  R1823     -1.6826815903186798e-01
    z[5,6,3]  R1824     6.4688093960285187e-02
    z[5,6,3]  R1825     4.0098321437835693e-01
    z[5,6,3]  R1826     -1.6461324691772461e-01
    z[5,6,3]  R1827     4.8995133489370346e-02
    z[5,6,3]  R1828     -1.0676565766334534e-01
    z[5,6,3]  R1829     2.9994124174118042e-01
    z[5,6,3]  R1830     2.1029375493526459e-01
    z[5,6,3]  R1831     -4.0868633985519409e-01
    z[5,6,3]  R1832     -2.4901716411113739e-01
    z[5,6,3]  R1833     4.1392478346824646e-01
    z[5,6,3]  R1834     -5.2605450153350830e-01
    z[5,6,3]  R1835     -8.9653067290782928e-02
    z[5,6,3]  R1836     -7.7100642956793308e-03
    z[5,6,3]  R1837     3.1648337841033936e-01
    z[5,6,3]  R1838     5.1185590028762817e-01
    z[5,6,3]  R1839     2.8471636772155762e-01
    z[5,6,3]  R1840     2.7658654376864433e-02
    z[5,6,3]  R1841     2.8667786717414856e-01
    z[5,6,3]  R1842     2.4606034159660339e-01
    z[5,6,3]  R1843     -3.3424678444862366e-01
    z[5,6,3]  R1844     -4.4091507792472839e-01
    z[5,6,3]  R1845     5.8085656166076660e-01
    z[5,6,3]  R1846     -2.7782931923866272e-01
    z[5,6,3]  R1847     9.5294103026390076e-02
    z[5,6,3]  R1848     -3.8310185074806213e-01
    z[5,6,3]  R1849     -1.7785681784152985e-01
    z[5,6,3]  R1850     -0.131015345454216
    z[5,6,3]  R1851     -1.9377744197845459e-01
    z[5,6,3]  R1852     4.7956906259059906e-02
    z[5,6,3]  R1853     -0.0905357152223587
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R1768     -1
    z[5,6,4]  R1769     1
    z[5,6,4]  R1774     -8.4111243486404419e-02
    z[5,6,4]  R1775     1.7591449618339539e-01
    z[5,6,4]  R1776     1.4838105440139771e-01
    z[5,6,4]  R1777     1.8645854294300079e-01
    z[5,6,4]  R1778     2.4851320683956146e-01
    z[5,6,4]  R1779     1.8241493403911591e-01
    z[5,6,4]  R1780     2.4589349329471588e-01
    z[5,6,4]  R1781     1.2977319955825806e-01
    z[5,6,4]  R1782     1.1258167028427124e-01
    z[5,6,4]  R1783     -0.160190612077713
    z[5,6,4]  R1784     3.1359833478927612e-01
    z[5,6,4]  R1785     1.0080862790346146e-01
    z[5,6,4]  R1786     2.5663849711418152e-01
    z[5,6,4]  R1787     1.4975853264331818e-01
    z[5,6,4]  R1788     7.1244575083255768e-02
    z[5,6,4]  R1789     6.0734695196151733e-01
    z[5,6,4]  R1790     -2.2092871367931366e-01
    z[5,6,4]  R1791     5.9946626424789429e-01
    z[5,6,4]  R1792     -1.4683061838150024e-01
    z[5,6,4]  R1793     -2.0465135574340820e-01
    z[5,6,4]  R1794     1.0752888023853302e-01
    z[5,6,4]  R1795     -1.2483403831720352e-01
    z[5,6,4]  R1796     -7.7004201710224152e-02
    z[5,6,4]  R1797     -7.0594884455204010e-02
    z[5,6,4]  R1798     -1.8695162236690521e-01
    z[5,6,4]  R1799     2.9199129343032837e-01
    z[5,6,4]  R1800     7.3304343223571777e-01
    z[5,6,4]  R1801     1.8396420776844025e-01
    z[5,6,4]  R1802     5.2788454294204712e-01
    z[5,6,4]  R1803     0.0999830886721611
    z[5,6,4]  R1804     4.4631978869438171e-01
    z[5,6,4]  R1805     -0.260684072971344
    z[5,6,4]  R1806     4.9166500568389893e-02
    z[5,6,4]  R1807     -2.4913236498832703e-01
    z[5,6,4]  R1808     5.1458673551678658e-03
    z[5,6,4]  R1809     2.4429830908775330e-01
    z[5,6,4]  R1810     2.8930205106735229e-01
    z[5,6,4]  R1811     6.8917974829673767e-02
    z[5,6,4]  R1812     2.9879891872406006e-01
    z[5,6,4]  R1813     2.7954256534576416e-01
    z[5,6,4]  R1814     -1.4301426708698273e-01
    z[5,6,4]  R1815     4.0275582671165466e-01
    z[5,6,4]  R1816     5.7950782775878906e-01
    z[5,6,4]  R1817     -1.9071938097476959e-01
    z[5,6,4]  R1818     -5.0799185037612915e-01
    z[5,6,4]  R1819     6.4860903657972813e-03
    z[5,6,4]  R1820     9.7983568906784058e-02
    z[5,6,4]  R1821     -2.1194885671138763e-01
    z[5,6,4]  R1822     -1.5737390518188477e-01
    z[5,6,4]  R1823     3.3369123935699463e-01
    z[5,6,4]  R1824     6.4953304827213287e-03
    z[5,6,4]  R1825     -1.3158570230007172e-01
    z[5,6,4]  R1826     2.0307642221450806e-01
    z[5,6,4]  R1827     -3.4298968315124512e-01
    z[5,6,4]  R1828     6.1942702531814575e-01
    z[5,6,4]  R1829     1.9328743219375610e-01
    z[5,6,4]  R1830     2.0901934802532196e-01
    z[5,6,4]  R1831     0.644838273525238
    z[5,6,4]  R1832     -3.1977668404579163e-01
    z[5,6,4]  R1833     -2.4432940781116486e-01
    z[5,6,4]  R1834     -3.4927028417587280e-01
    z[5,6,4]  R1835     -3.2429978251457214e-01
    z[5,6,4]  R1836     3.5322725772857666e-02
    z[5,6,4]  R1837     -1.1022664606571198e-01
    z[5,6,4]  R1838     6.3435077667236328e-02
    z[5,6,4]  R1839     -3.1357151269912720e-01
    z[5,6,4]  R1840     7.1364670991897583e-02
    z[5,6,4]  R1841     -3.0642592906951904e-01
    z[5,6,4]  R1842     4.2516708374023438e-01
    z[5,6,4]  R1843     -2.8752040863037109e-01
    z[5,6,4]  R1844     1.9588541984558105e-01
    z[5,6,4]  R1845     -3.3665180206298828e-01
    z[5,6,4]  R1846     -1.9591686129570007e-01
    z[5,6,4]  R1847     5.7059031724929810e-01
    z[5,6,4]  R1848     6.1753702163696289e-01
    z[5,6,4]  R1849     2.2575153410434723e-01
    z[5,6,4]  R1850     3.6807185411453247e-01
    z[5,6,4]  R1851     3.8116380572319031e-01
    z[5,6,4]  R1852     4.7033616900444031e-01
    z[5,6,4]  R1853     5.4592221975326538e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R1770     -1
    z[5,6,5]  R1771     1
    z[5,6,5]  R1774     -1.4309965074062347e-01
    z[5,6,5]  R1775     9.5048017799854279e-02
    z[5,6,5]  R1776     8.6816504597663879e-02
    z[5,6,5]  R1777     2.6909697055816650e-01
    z[5,6,5]  R1778     -3.8634249567985535e-01
    z[5,6,5]  R1779     -8.3060008287429810e-01
    z[5,6,5]  R1780     -6.3589096069335938e-01
    z[5,6,5]  R1781     -4.4720986485481262e-01
    z[5,6,5]  R1782     -4.9541616439819336e-01
    z[5,6,5]  R1783     -2.8148138523101807e-01
    z[5,6,5]  R1784     5.9881383180618286e-01
    z[5,6,5]  R1785     9.1375805437564850e-02
    z[5,6,5]  R1786     4.1600292921066284e-01
    z[5,6,5]  R1787     7.8808829188346863e-02
    z[5,6,5]  R1788     6.0233663767576218e-02
    z[5,6,5]  R1789     3.1459605693817139e-01
    z[5,6,5]  R1790     2.8942698240280151e-01
    z[5,6,5]  R1791     1.5429291129112244e-01
    z[5,6,5]  R1792     4.3332797288894653e-01
    z[5,6,5]  R1793     -1.9631743431091309e-01
    z[5,6,5]  R1794     -3.2332543283700943e-02
    z[5,6,5]  R1795     -9.9013172090053558e-02
    z[5,6,5]  R1796     -3.7514790892601013e-02
    z[5,6,5]  R1797     -2.1448303759098053e-01
    z[5,6,5]  R1798     1.9197199493646622e-02
    z[5,6,5]  R1799     5.4930694401264191e-02
    z[5,6,5]  R1800     1.3632969558238983e-01
    z[5,6,5]  R1801     -2.3126402497291565e-01
    z[5,6,5]  R1802     0.122758649289608
    z[5,6,5]  R1803     0.195773646235466
    z[5,6,5]  R1804     -4.1888365149497986e-01
    z[5,6,5]  R1805     -5.7614952325820923e-01
    z[5,6,5]  R1806     -6.2454670667648315e-01
    z[5,6,5]  R1807     -4.7182309627532959e-01
    z[5,6,5]  R1808     -3.8587334752082825e-01
    z[5,6,5]  R1809     -0.326010525226593
    z[5,6,5]  R1810     5.2686333656311035e-01
    z[5,6,5]  R1811     -7.8539215028285980e-02
    z[5,6,5]  R1812     -3.0201127752661705e-02
    z[5,6,5]  R1813     3.0798721313476562e-01
    z[5,6,5]  R1814     -1.1922200024127960e-01
    z[5,6,5]  R1815     7.7422834932804108e-02
    z[5,6,5]  R1816     -1.2829670310020447e-01
    z[5,6,5]  R1817     -1.4491325244307518e-02
    z[5,6,5]  R1818     -2.5016161799430847e-01
    z[5,6,5]  R1819     -1.5713991224765778e-01
    z[5,6,5]  R1820     -1.3413535058498383e-01
    z[5,6,5]  R1821     -6.0129874944686890e-01
    z[5,6,5]  R1822     -0.818955659866333
    z[5,6,5]  R1823     -6.7674064636230469e-01
    z[5,6,5]  R1824     3.7047886848449707e-01
    z[5,6,5]  R1825     0.217903271317482
    z[5,6,5]  R1826     3.0730402469635010e-01
    z[5,6,5]  R1827     -1.3440935313701630e-01
    z[5,6,5]  R1828     6.3022486865520477e-02
    z[5,6,5]  R1829     3.2050319015979767e-02
    z[5,6,5]  R1830     -0.0315934419631958
    z[5,6,5]  R1831     2.2678345441818237e-01
    z[5,6,5]  R1832     2.8900709748268127e-01
    z[5,6,5]  R1833     3.4041884541511536e-01
    z[5,6,5]  R1834     -3.7923332303762436e-02
    z[5,6,5]  R1835     7.0256894826889038e-01
    z[5,6,5]  R1836     7.4205398559570312e-01
    z[5,6,5]  R1837     6.5531963109970093e-01
    z[5,6,5]  R1838     5.3755646944046021e-01
    z[5,6,5]  R1839     3.3445313572883606e-01
    z[5,6,5]  R1840     0.444111704826355
    z[5,6,5]  R1841     1.2943306565284729e-01
    z[5,6,5]  R1842     5.9656274318695068e-01
    z[5,6,5]  R1843     0.0689297541975975
    z[5,6,5]  R1844     1.5085551142692566e-01
    z[5,6,5]  R1845     2.7574095129966736e-01
    z[5,6,5]  R1846     -1.6325747966766357e-01
    z[5,6,5]  R1847     1.7915613949298859e-01
    z[5,6,5]  R1848     -1.7667318880558014e-01
    z[5,6,5]  R1849     -2.4725198745727539e-01
    z[5,6,5]  R1850     5.6163590401411057e-02
    z[5,6,5]  R1851     -4.2012929916381836e-01
    z[5,6,5]  R1852     -9.1173492372035980e-02
    z[5,6,5]  R1853     0.00541772460564971
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R1772     -1
    z[5,6,6]  R1773     1
    z[5,6,6]  R1774     -1.3519684970378876e-01
    z[5,6,6]  R1775     5.3564831614494324e-02
    z[5,6,6]  R1776     0.361736923456192
    z[5,6,6]  R1777     5.7302600145339966e-01
    z[5,6,6]  R1778     -2.4264581501483917e-02
    z[5,6,6]  R1779     4.8225581645965576e-02
    z[5,6,6]  R1780     3.7936046719551086e-02
    z[5,6,6]  R1781     -6.4364320039749146e-01
    z[5,6,6]  R1782     -3.0650213360786438e-01
    z[5,6,6]  R1783     1.6895861923694611e-01
    z[5,6,6]  R1784     -6.7200702428817749e-01
    z[5,6,6]  R1785     6.7640833556652069e-02
    z[5,6,6]  R1786     -1.9662520289421082e-01
    z[5,6,6]  R1787     -3.8255810737609863e-01
    z[5,6,6]  R1788     -4.1507405042648315e-01
    z[5,6,6]  R1789     5.9493549168109894e-02
    z[5,6,6]  R1790     3.2696339488029480e-01
    z[5,6,6]  R1791     2.6271492242813110e-01
    z[5,6,6]  R1792     1.8878260254859924e-01
    z[5,6,6]  R1793     -4.1211363673210144e-01
    z[5,6,6]  R1794     3.4649577736854553e-01
    z[5,6,6]  R1795     -3.9930595085024834e-03
    z[5,6,6]  R1796     -1.6441099345684052e-02
    z[5,6,6]  R1797     -2.3564879596233368e-01
    z[5,6,6]  R1798     1.5668654814362526e-02
    z[5,6,6]  R1799     -7.9948879778385162e-02
    z[5,6,6]  R1800     1.9399905204772949e-01
    z[5,6,6]  R1801     -1.8508534133434296e-01
    z[5,6,6]  R1802     -8.7443970143795013e-02
    z[5,6,6]  R1803     -5.8296483755111694e-01
    z[5,6,6]  R1804     0.16391621530056
    z[5,6,6]  R1805     -2.4543851613998413e-01
    z[5,6,6]  R1806     -3.4087572246789932e-02
    z[5,6,6]  R1807     3.3718466758728027e-01
    z[5,6,6]  R1808     5.3106665611267090e-01
    z[5,6,6]  R1809     -2.6652488112449646e-01
    z[5,6,6]  R1810     -4.1730406880378723e-01
    z[5,6,6]  R1811     -2.5357139110565186e-01
    z[5,6,6]  R1812     -4.2735478281974792e-01
    z[5,6,6]  R1813     -2.5798463821411133e-01
    z[5,6,6]  R1814     -1.3149733841419220e-01
    z[5,6,6]  R1815     -7.3035918176174164e-02
    z[5,6,6]  R1816     -2.5383949279785156e-01
    z[5,6,6]  R1817     -0.62140291929245
    z[5,6,6]  R1818     4.7083269804716110e-02
    z[5,6,6]  R1819     1.4273120462894440e-01
    z[5,6,6]  R1820     -3.3267743885517120e-02
    z[5,6,6]  R1821     -1.2613409757614136e-01
    z[5,6,6]  R1822     -1.1649063229560852e-01
    z[5,6,6]  R1823     -4.5722997188568115e-01
    z[5,6,6]  R1824     2.9315501451492310e-01
    z[5,6,6]  R1825     -1.5709204971790314e-01
    z[5,6,6]  R1826     9.4283193349838257e-02
    z[5,6,6]  R1827     1.1423571407794952e-01
    z[5,6,6]  R1828     5.1479238271713257e-01
    z[5,6,6]  R1829     2.6381725072860718e-01
    z[5,6,6]  R1830     3.3150288462638855e-01
    z[5,6,6]  R1831     4.1659972071647644e-01
    z[5,6,6]  R1832     8.4590339660644531e-01
    z[5,6,6]  R1833     4.6141487360000610e-01
    z[5,6,6]  R1834     3.6648562550544739e-01
    z[5,6,6]  R1835     5.7413893938064575e-01
    z[5,6,6]  R1836     3.5459730029106140e-01
    z[5,6,6]  R1837     5.5705165863037109e-01
    z[5,6,6]  R1838     -3.6742768716067076e-03
    z[5,6,6]  R1839     3.5237762331962585e-01
    z[5,6,6]  R1840     7.1442115306854248e-01
    z[5,6,6]  R1841     4.8400026559829712e-01
    z[5,6,6]  R1842     5.0567018985748291e-01
    z[5,6,6]  R1843     -7.4640981853008270e-02
    z[5,6,6]  R1844     2.6707506179809570e-01
    z[5,6,6]  R1845     1.6123822331428528e-01
    z[5,6,6]  R1846     7.6784379780292511e-02
    z[5,6,6]  R1847     -5.5147089064121246e-02
    z[5,6,6]  R1848     1.9290894269943237e-02
    z[5,6,6]  R1849     -2.6246497035026550e-01
    z[5,6,6]  R1850     2.7400395274162292e-01
    z[5,6,6]  R1851     1.8922476470470428e-01
    z[5,6,6]  R1852     -4.0201491117477417e-01
    z[5,6,6]  R1853     -0.504845380783081
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R1854     -1
    z[6,5,0]  R1855     1
    z[6,5,0]  R1868     -2.6171565055847168e-01
    z[6,5,0]  R1869     -4.8409137129783630e-01
    z[6,5,0]  R1870     -4.0355199575424194e-01
    z[6,5,0]  R1871     3.8174521923065186e-01
    z[6,5,0]  R1872     4.4334220886230469e-01
    z[6,5,0]  R1873     6.9331407546997070e-01
    z[6,5,0]  R1874     5.3337591886520386e-01
    z[6,5,0]  R1875     4.0423554182052612e-01
    z[6,5,0]  R1876     5.2008930593729019e-02
    z[6,5,0]  R1877     1.6269832849502563e-01
    z[6,5,0]  R1878     1.8686690926551819e-01
    z[6,5,0]  R1879     2.0650996267795563e-01
    z[6,5,0]  R1880     0.518527626991272
    z[6,5,0]  R1881     -2.3127996921539307e-01
    z[6,5,0]  R1882     9.4481986016035080e-03
    z[6,5,0]  R1883     -5.1704061031341553e-01
    z[6,5,0]  R1884     -2.1425540745258331e-01
    z[6,5,0]  R1885     1.6143192350864410e-01
    z[6,5,0]  R1886     9.0215191245079041e-02
    z[6,5,0]  R1887     -2.6278412342071533e-01
    z[6,5,0]  R1888     2.7463972568511963e-01
    z[6,5,0]  R1889     4.4837236404418945e-02
    z[6,5,0]  R1890     4.5980989933013916e-01
    z[6,5,0]  R1891     2.1286228299140930e-01
    z[6,5,0]  R1892     2.9343879222869873e-01
    z[6,5,0]  R1893     -3.5603947937488556e-02
    z[6,5,0]  R1894     -1.9836364313960075e-02
    z[6,5,0]  R1895     -4.4679844379425049e-01
    z[6,5,0]  R1896     1.1935807764530182e-01
    z[6,5,0]  R1897     5.2002698183059692e-01
    z[6,5,0]  R1898     2.4204833805561066e-01
    z[6,5,0]  R1899     -1.7059673368930817e-01
    z[6,5,0]  R1900     -7.4065856635570526e-02
    z[6,5,0]  R1901     -1.4131058752536774e-01
    z[6,5,0]  R1902     4.5075584203004837e-02
    z[6,5,0]  R1903     0.470356822013855
    z[6,5,0]  R1904     4.0498252958059311e-02
    z[6,5,0]  R1905     1.9757135212421417e-01
    z[6,5,0]  R1906     -1.5444062650203705e-01
    z[6,5,0]  R1907     1.4068734645843506e-01
    z[6,5,0]  R1908     -2.1965850889682770e-01
    z[6,5,0]  R1909     3.8964539766311646e-01
    z[6,5,0]  R1910     -4.8913940787315369e-01
    z[6,5,0]  R1911     3.9033308625221252e-02
    z[6,5,0]  R1912     -7.6041102409362793e-02
    z[6,5,0]  R1913     -1.8263314664363861e-01
    z[6,5,0]  R1914     -2.1608844399452209e-01
    z[6,5,0]  R1915     -3.2449704408645630e-01
    z[6,5,0]  R1916     -3.8376316428184509e-01
    z[6,5,0]  R1917     0.533849835395813
    z[6,5,0]  R1918     9.1885060071945190e-02
    z[6,5,0]  R1919     8.0419188737869263e-01
    z[6,5,0]  R1920     7.9476422071456909e-01
    z[6,5,0]  R1921     7.5385099649429321e-01
    z[6,5,0]  R1922     5.5066674947738647e-01
    z[6,5,0]  R1923     -2.9325127601623535e-01
    z[6,5,0]  R1924     -3.2178360223770142e-01
    z[6,5,0]  R1925     -4.5268434286117554e-01
    z[6,5,0]  R1926     3.8365894556045532e-01
    z[6,5,0]  R1927     3.0912798643112183e-01
    z[6,5,0]  R1928     -5.2593553066253662e-01
    z[6,5,0]  R1929     -7.1485877037048340e-01
    z[6,5,0]  R1930     -8.7346452474594116e-01
    z[6,5,0]  R1931     -8.7916219234466553e-01
    z[6,5,0]  R1932     -3.0520135164260864e-01
    z[6,5,0]  R1933     1.2800628319382668e-03
    z[6,5,0]  R1934     -2.8656333684921265e-01
    z[6,5,0]  R1935     8.7442982196807861e-01
    z[6,5,0]  R1936     -5.7233875989913940e-01
    z[6,5,0]  R1937     6.8655538558959961e-01
    z[6,5,0]  R1938     -6.5309411287307739e-01
    z[6,5,0]  R1939     -3.5251370072364807e-01
    z[6,5,0]  R1940     -1.1558666080236435e-01
    z[6,5,0]  R1941     -3.2930415868759155e-01
    z[6,5,0]  R1942     -1.2061957269906998e-01
    z[6,5,0]  R1943     -2.0873010158538818e-01
    z[6,5,0]  R1944     4.3043011426925659e-01
    z[6,5,0]  R1945     0.673404335975647
    z[6,5,0]  R1946     4.6897763013839722e-01
    z[6,5,0]  R1947     5.4304844141006470e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R1856     -1
    z[6,5,1]  R1857     1
    z[6,5,1]  R1868     -5.4178398847579956e-01
    z[6,5,1]  R1869     -6.9878840446472168e-01
    z[6,5,1]  R1870     -6.4104229211807251e-01
    z[6,5,1]  R1871     -6.2312567234039307e-01
    z[6,5,1]  R1872     -6.4854383468627930e-01
    z[6,5,1]  R1873     -5.5554753541946411e-01
    z[6,5,1]  R1874     -5.5843216180801392e-01
    z[6,5,1]  R1875     -6.1905372142791748e-01
    z[6,5,1]  R1876     3.2348605990409851e-01
    z[6,5,1]  R1877     2.7741560339927673e-01
    z[6,5,1]  R1878     7.0114231109619141e-01
    z[6,5,1]  R1879     8.0504411458969116e-01
    z[6,5,1]  R1880     7.4551194906234741e-01
    z[6,5,1]  R1881     0.799316942691803
    z[6,5,1]  R1882     5.7951068878173828e-01
    z[6,5,1]  R1883     7.2197246551513672e-01
    z[6,5,1]  R1884     8.2318013906478882e-01
    z[6,5,1]  R1885     3.9585524797439575e-01
    z[6,5,1]  R1886     -1.6483476758003235e-01
    z[6,5,1]  R1887     -3.2920852303504944e-01
    z[6,5,1]  R1888     -5.7070219516754150e-01
    z[6,5,1]  R1889     -2.3279976844787598e-01
    z[6,5,1]  R1890     -2.3191344738006592e-01
    z[6,5,1]  R1891     -3.1613373756408691e-01
    z[6,5,1]  R1892     -5.6601864099502563e-01
    z[6,5,1]  R1893     -6.1027604341506958e-01
    z[6,5,1]  R1894     -5.3468197584152222e-01
    z[6,5,1]  R1895     -4.9905860424041748e-01
    z[6,5,1]  R1896     -2.8273808956146240e-01
    z[6,5,1]  R1897     5.5129849910736084e-01
    z[6,5,1]  R1898     -7.7998697757720947e-01
    z[6,5,1]  R1899     -5.2748590707778931e-01
    z[6,5,1]  R1900     6.0195082426071167e-01
    z[6,5,1]  R1901     5.9612119197845459e-01
    z[6,5,1]  R1902     6.3063758611679077e-01
    z[6,5,1]  R1903     7.5140869617462158e-01
    z[6,5,1]  R1904     2.4554686248302460e-01
    z[6,5,1]  R1905     3.0078712105751038e-01
    z[6,5,1]  R1906     6.2154537439346313e-01
    z[6,5,1]  R1907     4.2001038789749146e-01
    z[6,5,1]  R1908     -0.554340124130249
    z[6,5,1]  R1909     -6.7100626230239868e-01
    z[6,5,1]  R1910     -5.4123604297637939e-01
    z[6,5,1]  R1911     -6.1328488588333130e-01
    z[6,5,1]  R1912     -8.1643950939178467e-01
    z[6,5,1]  R1913     3.6129321902990341e-02
    z[6,5,1]  R1914     1.7198620736598969e-01
    z[6,5,1]  R1915     -0.0684293881058693
    z[6,5,1]  R1916     -1.2355047464370728e-01
    z[6,5,1]  R1917     1.3018621504306793e-01
    z[6,5,1]  R1918     -2.2815652191638947e-01
    z[6,5,1]  R1919     3.6367753148078918e-01
    z[6,5,1]  R1920     1.1067080497741699e-01
    z[6,5,1]  R1921     2.8792858123779297e-01
    z[6,5,1]  R1922     2.5240519642829895e-01
    z[6,5,1]  R1923     5.4331791400909424e-01
    z[6,5,1]  R1924     5.6653678417205811e-01
    z[6,5,1]  R1925     5.5422651767730713e-01
    z[6,5,1]  R1926     7.4812614917755127e-01
    z[6,5,1]  R1927     0.758578360080719
    z[6,5,1]  R1928     4.2381352186203003e-01
    z[6,5,1]  R1929     8.5695318877696991e-02
    z[6,5,1]  R1930     2.2513927519321442e-01
    z[6,5,1]  R1931     2.5168797373771667e-01
    z[6,5,1]  R1932     4.5791548490524292e-01
    z[6,5,1]  R1933     -1.1175908148288727e-01
    z[6,5,1]  R1934     2.9197549819946289e-01
    z[6,5,1]  R1935     -1.8015447258949280e-01
    z[6,5,1]  R1936     4.5995992422103882e-01
    z[6,5,1]  R1937     1.4378155767917633e-01
    z[6,5,1]  R1938     -8.0687880516052246e-02
    z[6,5,1]  R1939     3.3827960491180420e-01
    z[6,5,1]  R1940     -2.6293650269508362e-01
    z[6,5,1]  R1941     4.4365060329437256e-01
    z[6,5,1]  R1942     -1.2746001780033112e-01
    z[6,5,1]  R1943     7.3309385776519775e-01
    z[6,5,1]  R1944     -1.0934652388095856e-01
    z[6,5,1]  R1945     3.1935906410217285e-01
    z[6,5,1]  R1946     -1.7344640195369720e-01
    z[6,5,1]  R1947     1.3700337149202824e-04
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R1858     -1
    z[6,5,2]  R1859     1
    z[6,5,2]  R1868     -7.2222578525543213e-01
    z[6,5,2]  R1869     -2.1871227025985718e-01
    z[6,5,2]  R1870     -2.7881475165486336e-02
    z[6,5,2]  R1871     1.7660474777221680e-01
    z[6,5,2]  R1872     2.2964945435523987e-01
    z[6,5,2]  R1873     0.317281574010849
    z[6,5,2]  R1874     6.0548734664916992e-01
    z[6,5,2]  R1875     1.7457424104213715e-01
    z[6,5,2]  R1876     0.370514452457428
    z[6,5,2]  R1877     2.9978102445602417e-01
    z[6,5,2]  R1878     4.9604347348213196e-01
    z[6,5,2]  R1879     2.4289000034332275e-01
    z[6,5,2]  R1880     -6.0649398714303970e-02
    z[6,5,2]  R1881     3.9552986621856689e-01
    z[6,5,2]  R1882     2.5210650637745857e-03
    z[6,5,2]  R1883     1.1607456207275391e-01
    z[6,5,2]  R1884     -2.7868294715881348e-01
    z[6,5,2]  R1885     9.7012668848037720e-02
    z[6,5,2]  R1886     -3.6694344133138657e-02
    z[6,5,2]  R1887     5.1258850097656250e-01
    z[6,5,2]  R1888     -2.5376963615417480e-01
    z[6,5,2]  R1889     -8.5715778172016144e-02
    z[6,5,2]  R1890     -2.3895697295665741e-01
    z[6,5,2]  R1891     5.1837243139743805e-02
    z[6,5,2]  R1892     1.9625426828861237e-01
    z[6,5,2]  R1893     4.5921251177787781e-01
    z[6,5,2]  R1894     -1.5197678469121456e-02
    z[6,5,2]  R1895     3.5245051980018616e-01
    z[6,5,2]  R1896     -2.3002301156520844e-01
    z[6,5,2]  R1897     4.7003245353698730e-01
    z[6,5,2]  R1898     -7.8544422984123230e-02
    z[6,5,2]  R1899     3.7402617931365967e-01
    z[6,5,2]  R1900     6.9573557376861572e-01
    z[6,5,2]  R1901     5.0485479831695557e-01
    z[6,5,2]  R1902     2.0139449834823608e-01
    z[6,5,2]  R1903     3.9129763841629028e-02
    z[6,5,2]  R1904     8.4094721078872681e-01
    z[6,5,2]  R1905     6.8945086002349854e-01
    z[6,5,2]  R1906     4.4315326213836670e-01
    z[6,5,2]  R1907     4.9261784553527832e-01
    z[6,5,2]  R1908     -6.8994587659835815e-01
    z[6,5,2]  R1909     -4.7157332301139832e-01
    z[6,5,2]  R1910     -2.1637642383575439e-01
    z[6,5,2]  R1911     -1.1653658747673035e-01
    z[6,5,2]  R1912     3.1965553760528564e-01
    z[6,5,2]  R1913     4.6624442934989929e-01
    z[6,5,2]  R1914     5.4059821367263794e-01
    z[6,5,2]  R1915     4.8135438561439514e-01
    z[6,5,2]  R1916     2.9447263479232788e-01
    z[6,5,2]  R1917     -5.8466184139251709e-01
    z[6,5,2]  R1918     0.0337735079228878
    z[6,5,2]  R1919     4.4190880656242371e-01
    z[6,5,2]  R1920     2.8016534447669983e-01
    z[6,5,2]  R1921     4.1245257854461670e-01
    z[6,5,2]  R1922     0.546988308429718
    z[6,5,2]  R1923     3.0850669741630554e-01
    z[6,5,2]  R1924     4.8759835958480835e-01
    z[6,5,2]  R1925     -4.5866728760302067e-03
    z[6,5,2]  R1926     -1.5615680813789368e-01
    z[6,5,2]  R1927     2.7312371134757996e-01
    z[6,5,2]  R1928     6.4112591743469238e-01
    z[6,5,2]  R1929     6.7079651355743408e-01
    z[6,5,2]  R1930     2.6852738857269287e-01
    z[6,5,2]  R1931     2.3587007820606232e-01
    z[6,5,2]  R1932     0.693960964679718
    z[6,5,2]  R1933     8.8741952180862427e-01
    z[6,5,2]  R1934     4.5759826898574829e-01
    z[6,5,2]  R1935     0.0328427255153656
    z[6,5,2]  R1936     1.7511083185672760e-01
    z[6,5,2]  R1937     -1.8304964900016785e-01
    z[6,5,2]  R1938     2.5656121969223022e-01
    z[6,5,2]  R1939     5.2649009227752686e-01
    z[6,5,2]  R1940     7.2265160083770752e-01
    z[6,5,2]  R1941     1.8507625162601471e-01
    z[6,5,2]  R1942     7.3358118534088135e-01
    z[6,5,2]  R1943     1.8976634740829468e-01
    z[6,5,2]  R1944     -3.2092091441154480e-01
    z[6,5,2]  R1945     5.8595299720764160e-01
    z[6,5,2]  R1946     1.5920553356409073e-02
    z[6,5,2]  R1947     -1.1534313112497330e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R1860     -1
    z[6,5,3]  R1861     1
    z[6,5,3]  R1868     2.5378414988517761e-01
    z[6,5,3]  R1869     -2.3658950626850128e-01
    z[6,5,3]  R1870     9.3324109911918640e-02
    z[6,5,3]  R1871     -1.0986461490392685e-01
    z[6,5,3]  R1872     -8.5124827921390533e-02
    z[6,5,3]  R1873     2.5477004051208496e-01
    z[6,5,3]  R1874     -9.1371774673461914e-02
    z[6,5,3]  R1875     -2.2307975217700005e-02
    z[6,5,3]  R1876     -2.1528103947639465e-01
    z[6,5,3]  R1877     -1.6826815903186798e-01
    z[6,5,3]  R1878     6.4688093960285187e-02
    z[6,5,3]  R1879     4.0098321437835693e-01
    z[6,5,3]  R1880     -1.6461324691772461e-01
    z[6,5,3]  R1881     4.8995133489370346e-02
    z[6,5,3]  R1882     -1.0676565766334534e-01
    z[6,5,3]  R1883     2.9994124174118042e-01
    z[6,5,3]  R1884     2.1029375493526459e-01
    z[6,5,3]  R1885     -4.0868633985519409e-01
    z[6,5,3]  R1886     -2.4901716411113739e-01
    z[6,5,3]  R1887     4.1392478346824646e-01
    z[6,5,3]  R1888     -5.2605450153350830e-01
    z[6,5,3]  R1889     -8.9653067290782928e-02
    z[6,5,3]  R1890     -7.7100642956793308e-03
    z[6,5,3]  R1891     3.1648337841033936e-01
    z[6,5,3]  R1892     5.1185590028762817e-01
    z[6,5,3]  R1893     2.8471636772155762e-01
    z[6,5,3]  R1894     2.7658654376864433e-02
    z[6,5,3]  R1895     2.8667786717414856e-01
    z[6,5,3]  R1896     2.4606034159660339e-01
    z[6,5,3]  R1897     -3.3424678444862366e-01
    z[6,5,3]  R1898     -4.4091507792472839e-01
    z[6,5,3]  R1899     5.8085656166076660e-01
    z[6,5,3]  R1900     -2.7782931923866272e-01
    z[6,5,3]  R1901     9.5294103026390076e-02
    z[6,5,3]  R1902     -3.8310185074806213e-01
    z[6,5,3]  R1903     -1.7785681784152985e-01
    z[6,5,3]  R1904     -0.131015345454216
    z[6,5,3]  R1905     -1.9377744197845459e-01
    z[6,5,3]  R1906     4.7956906259059906e-02
    z[6,5,3]  R1907     -0.0905357152223587
    z[6,5,3]  R1908     3.5014513134956360e-01
    z[6,5,3]  R1909     -3.6427515745162964e-01
    z[6,5,3]  R1910     -5.1047003269195557e-01
    z[6,5,3]  R1911     4.1621926426887512e-01
    z[6,5,3]  R1912     -1.1771318316459656e-01
    z[6,5,3]  R1913     1.4986169338226318e-01
    z[6,5,3]  R1914     -4.0647247433662415e-01
    z[6,5,3]  R1915     1.6493260860443115e-01
    z[6,5,3]  R1916     6.3142031431198120e-01
    z[6,5,3]  R1917     4.7200274467468262e-01
    z[6,5,3]  R1918     -1.7275893688201904e-01
    z[6,5,3]  R1919     -5.1414594054222107e-02
    z[6,5,3]  R1920     5.1054474897682667e-03
    z[6,5,3]  R1921     -6.0823790729045868e-02
    z[6,5,3]  R1922     3.9098763465881348e-01
    z[6,5,3]  R1923     2.2858822345733643e-01
    z[6,5,3]  R1924     3.1345912814140320e-01
    z[6,5,3]  R1925     1.8895380198955536e-01
    z[6,5,3]  R1926     -1.5413288772106171e-01
    z[6,5,3]  R1927     -6.4357981085777283e-02
    z[6,5,3]  R1928     -8.0260913819074631e-03
    z[6,5,3]  R1929     7.9134419560432434e-02
    z[6,5,3]  R1930     3.2658487558364868e-01
    z[6,5,3]  R1931     -3.9690818637609482e-02
    z[6,5,3]  R1932     4.2428621649742126e-01
    z[6,5,3]  R1933     3.2454070448875427e-01
    z[6,5,3]  R1934     1.7222511768341064e-01
    z[6,5,3]  R1935     2.8329461812973022e-01
    z[6,5,3]  R1936     3.5891965031623840e-01
    z[6,5,3]  R1937     2.9375055432319641e-01
    z[6,5,3]  R1938     0.315595418214798
    z[6,5,3]  R1939     1.5480515360832214e-01
    z[6,5,3]  R1940     4.0509562939405441e-02
    z[6,5,3]  R1941     5.1195913553237915e-01
    z[6,5,3]  R1942     1.0345229879021645e-02
    z[6,5,3]  R1943     3.8209143280982971e-01
    z[6,5,3]  R1944     -4.0541300177574158e-01
    z[6,5,3]  R1945     0.161179780960083
    z[6,5,3]  R1946     -6.9057798385620117e-01
    z[6,5,3]  R1947     -6.7248648405075073e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R1862     -1
    z[6,5,4]  R1863     1
    z[6,5,4]  R1868     -1.4301426708698273e-01
    z[6,5,4]  R1869     4.0275582671165466e-01
    z[6,5,4]  R1870     5.7950782775878906e-01
    z[6,5,4]  R1871     -1.9071938097476959e-01
    z[6,5,4]  R1872     -5.0799185037612915e-01
    z[6,5,4]  R1873     6.4860903657972813e-03
    z[6,5,4]  R1874     9.7983568906784058e-02
    z[6,5,4]  R1875     -2.1194885671138763e-01
    z[6,5,4]  R1876     -1.5737390518188477e-01
    z[6,5,4]  R1877     3.3369123935699463e-01
    z[6,5,4]  R1878     6.4953304827213287e-03
    z[6,5,4]  R1879     -1.3158570230007172e-01
    z[6,5,4]  R1880     2.0307642221450806e-01
    z[6,5,4]  R1881     -3.4298968315124512e-01
    z[6,5,4]  R1882     6.1942702531814575e-01
    z[6,5,4]  R1883     1.9328743219375610e-01
    z[6,5,4]  R1884     2.0901934802532196e-01
    z[6,5,4]  R1885     0.644838273525238
    z[6,5,4]  R1886     -3.1977668404579163e-01
    z[6,5,4]  R1887     -2.4432940781116486e-01
    z[6,5,4]  R1888     -3.4927028417587280e-01
    z[6,5,4]  R1889     -3.2429978251457214e-01
    z[6,5,4]  R1890     3.5322725772857666e-02
    z[6,5,4]  R1891     -1.1022664606571198e-01
    z[6,5,4]  R1892     6.3435077667236328e-02
    z[6,5,4]  R1893     -3.1357151269912720e-01
    z[6,5,4]  R1894     7.1364670991897583e-02
    z[6,5,4]  R1895     -3.0642592906951904e-01
    z[6,5,4]  R1896     4.2516708374023438e-01
    z[6,5,4]  R1897     -2.8752040863037109e-01
    z[6,5,4]  R1898     1.9588541984558105e-01
    z[6,5,4]  R1899     -3.3665180206298828e-01
    z[6,5,4]  R1900     -1.9591686129570007e-01
    z[6,5,4]  R1901     5.7059031724929810e-01
    z[6,5,4]  R1902     6.1753702163696289e-01
    z[6,5,4]  R1903     2.2575153410434723e-01
    z[6,5,4]  R1904     3.6807185411453247e-01
    z[6,5,4]  R1905     3.8116380572319031e-01
    z[6,5,4]  R1906     4.7033616900444031e-01
    z[6,5,4]  R1907     5.4592221975326538e-01
    z[6,5,4]  R1908     -8.4111243486404419e-02
    z[6,5,4]  R1909     1.7591449618339539e-01
    z[6,5,4]  R1910     1.4838105440139771e-01
    z[6,5,4]  R1911     1.8645854294300079e-01
    z[6,5,4]  R1912     2.4851320683956146e-01
    z[6,5,4]  R1913     1.8241493403911591e-01
    z[6,5,4]  R1914     2.4589349329471588e-01
    z[6,5,4]  R1915     1.2977319955825806e-01
    z[6,5,4]  R1916     1.1258167028427124e-01
    z[6,5,4]  R1917     -0.160190612077713
    z[6,5,4]  R1918     3.1359833478927612e-01
    z[6,5,4]  R1919     1.0080862790346146e-01
    z[6,5,4]  R1920     2.5663849711418152e-01
    z[6,5,4]  R1921     1.4975853264331818e-01
    z[6,5,4]  R1922     7.1244575083255768e-02
    z[6,5,4]  R1923     6.0734695196151733e-01
    z[6,5,4]  R1924     -2.2092871367931366e-01
    z[6,5,4]  R1925     5.9946626424789429e-01
    z[6,5,4]  R1926     -1.4683061838150024e-01
    z[6,5,4]  R1927     -2.0465135574340820e-01
    z[6,5,4]  R1928     1.0752888023853302e-01
    z[6,5,4]  R1929     -1.2483403831720352e-01
    z[6,5,4]  R1930     -7.7004201710224152e-02
    z[6,5,4]  R1931     -7.0594884455204010e-02
    z[6,5,4]  R1932     -1.8695162236690521e-01
    z[6,5,4]  R1933     2.9199129343032837e-01
    z[6,5,4]  R1934     7.3304343223571777e-01
    z[6,5,4]  R1935     1.8396420776844025e-01
    z[6,5,4]  R1936     5.2788454294204712e-01
    z[6,5,4]  R1937     0.0999830886721611
    z[6,5,4]  R1938     4.4631978869438171e-01
    z[6,5,4]  R1939     -0.260684072971344
    z[6,5,4]  R1940     4.9166500568389893e-02
    z[6,5,4]  R1941     -2.4913236498832703e-01
    z[6,5,4]  R1942     5.1458673551678658e-03
    z[6,5,4]  R1943     2.4429830908775330e-01
    z[6,5,4]  R1944     2.8930205106735229e-01
    z[6,5,4]  R1945     6.8917974829673767e-02
    z[6,5,4]  R1946     2.9879891872406006e-01
    z[6,5,4]  R1947     2.7954256534576416e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R1864     -1
    z[6,5,5]  R1865     1
    z[6,5,5]  R1868     -1.1922200024127960e-01
    z[6,5,5]  R1869     7.7422834932804108e-02
    z[6,5,5]  R1870     -1.2829670310020447e-01
    z[6,5,5]  R1871     -1.4491325244307518e-02
    z[6,5,5]  R1872     -2.5016161799430847e-01
    z[6,5,5]  R1873     -1.5713991224765778e-01
    z[6,5,5]  R1874     -1.3413535058498383e-01
    z[6,5,5]  R1875     -6.0129874944686890e-01
    z[6,5,5]  R1876     -0.818955659866333
    z[6,5,5]  R1877     -6.7674064636230469e-01
    z[6,5,5]  R1878     3.7047886848449707e-01
    z[6,5,5]  R1879     0.217903271317482
    z[6,5,5]  R1880     3.0730402469635010e-01
    z[6,5,5]  R1881     -1.3440935313701630e-01
    z[6,5,5]  R1882     6.3022486865520477e-02
    z[6,5,5]  R1883     3.2050319015979767e-02
    z[6,5,5]  R1884     -0.0315934419631958
    z[6,5,5]  R1885     2.2678345441818237e-01
    z[6,5,5]  R1886     2.8900709748268127e-01
    z[6,5,5]  R1887     3.4041884541511536e-01
    z[6,5,5]  R1888     -3.7923332303762436e-02
    z[6,5,5]  R1889     7.0256894826889038e-01
    z[6,5,5]  R1890     7.4205398559570312e-01
    z[6,5,5]  R1891     6.5531963109970093e-01
    z[6,5,5]  R1892     5.3755646944046021e-01
    z[6,5,5]  R1893     3.3445313572883606e-01
    z[6,5,5]  R1894     0.444111704826355
    z[6,5,5]  R1895     1.2943306565284729e-01
    z[6,5,5]  R1896     5.9656274318695068e-01
    z[6,5,5]  R1897     0.0689297541975975
    z[6,5,5]  R1898     1.5085551142692566e-01
    z[6,5,5]  R1899     2.7574095129966736e-01
    z[6,5,5]  R1900     -1.6325747966766357e-01
    z[6,5,5]  R1901     1.7915613949298859e-01
    z[6,5,5]  R1902     -1.7667318880558014e-01
    z[6,5,5]  R1903     -2.4725198745727539e-01
    z[6,5,5]  R1904     5.6163590401411057e-02
    z[6,5,5]  R1905     -4.2012929916381836e-01
    z[6,5,5]  R1906     -9.1173492372035980e-02
    z[6,5,5]  R1907     0.00541772460564971
    z[6,5,5]  R1908     -1.4309965074062347e-01
    z[6,5,5]  R1909     9.5048017799854279e-02
    z[6,5,5]  R1910     8.6816504597663879e-02
    z[6,5,5]  R1911     2.6909697055816650e-01
    z[6,5,5]  R1912     -3.8634249567985535e-01
    z[6,5,5]  R1913     -8.3060008287429810e-01
    z[6,5,5]  R1914     -6.3589096069335938e-01
    z[6,5,5]  R1915     -4.4720986485481262e-01
    z[6,5,5]  R1916     -4.9541616439819336e-01
    z[6,5,5]  R1917     -2.8148138523101807e-01
    z[6,5,5]  R1918     5.9881383180618286e-01
    z[6,5,5]  R1919     9.1375805437564850e-02
    z[6,5,5]  R1920     4.1600292921066284e-01
    z[6,5,5]  R1921     7.8808829188346863e-02
    z[6,5,5]  R1922     6.0233663767576218e-02
    z[6,5,5]  R1923     3.1459605693817139e-01
    z[6,5,5]  R1924     2.8942698240280151e-01
    z[6,5,5]  R1925     1.5429291129112244e-01
    z[6,5,5]  R1926     4.3332797288894653e-01
    z[6,5,5]  R1927     -1.9631743431091309e-01
    z[6,5,5]  R1928     -3.2332543283700943e-02
    z[6,5,5]  R1929     -9.9013172090053558e-02
    z[6,5,5]  R1930     -3.7514790892601013e-02
    z[6,5,5]  R1931     -2.1448303759098053e-01
    z[6,5,5]  R1932     1.9197199493646622e-02
    z[6,5,5]  R1933     5.4930694401264191e-02
    z[6,5,5]  R1934     1.3632969558238983e-01
    z[6,5,5]  R1935     -2.3126402497291565e-01
    z[6,5,5]  R1936     0.122758649289608
    z[6,5,5]  R1937     0.195773646235466
    z[6,5,5]  R1938     -4.1888365149497986e-01
    z[6,5,5]  R1939     -5.7614952325820923e-01
    z[6,5,5]  R1940     -6.2454670667648315e-01
    z[6,5,5]  R1941     -4.7182309627532959e-01
    z[6,5,5]  R1942     -3.8587334752082825e-01
    z[6,5,5]  R1943     -0.326010525226593
    z[6,5,5]  R1944     5.2686333656311035e-01
    z[6,5,5]  R1945     -7.8539215028285980e-02
    z[6,5,5]  R1946     -3.0201127752661705e-02
    z[6,5,5]  R1947     3.0798721313476562e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R1866     -1
    z[6,5,6]  R1867     1
    z[6,5,6]  R1868     -1.3149733841419220e-01
    z[6,5,6]  R1869     -7.3035918176174164e-02
    z[6,5,6]  R1870     -2.5383949279785156e-01
    z[6,5,6]  R1871     -0.62140291929245
    z[6,5,6]  R1872     4.7083269804716110e-02
    z[6,5,6]  R1873     1.4273120462894440e-01
    z[6,5,6]  R1874     -3.3267743885517120e-02
    z[6,5,6]  R1875     -1.2613409757614136e-01
    z[6,5,6]  R1876     -1.1649063229560852e-01
    z[6,5,6]  R1877     -4.5722997188568115e-01
    z[6,5,6]  R1878     2.9315501451492310e-01
    z[6,5,6]  R1879     -1.5709204971790314e-01
    z[6,5,6]  R1880     9.4283193349838257e-02
    z[6,5,6]  R1881     1.1423571407794952e-01
    z[6,5,6]  R1882     5.1479238271713257e-01
    z[6,5,6]  R1883     2.6381725072860718e-01
    z[6,5,6]  R1884     3.3150288462638855e-01
    z[6,5,6]  R1885     4.1659972071647644e-01
    z[6,5,6]  R1886     8.4590339660644531e-01
    z[6,5,6]  R1887     4.6141487360000610e-01
    z[6,5,6]  R1888     3.6648562550544739e-01
    z[6,5,6]  R1889     5.7413893938064575e-01
    z[6,5,6]  R1890     3.5459730029106140e-01
    z[6,5,6]  R1891     5.5705165863037109e-01
    z[6,5,6]  R1892     -3.6742768716067076e-03
    z[6,5,6]  R1893     3.5237762331962585e-01
    z[6,5,6]  R1894     7.1442115306854248e-01
    z[6,5,6]  R1895     4.8400026559829712e-01
    z[6,5,6]  R1896     5.0567018985748291e-01
    z[6,5,6]  R1897     -7.4640981853008270e-02
    z[6,5,6]  R1898     2.6707506179809570e-01
    z[6,5,6]  R1899     1.6123822331428528e-01
    z[6,5,6]  R1900     7.6784379780292511e-02
    z[6,5,6]  R1901     -5.5147089064121246e-02
    z[6,5,6]  R1902     1.9290894269943237e-02
    z[6,5,6]  R1903     -2.6246497035026550e-01
    z[6,5,6]  R1904     2.7400395274162292e-01
    z[6,5,6]  R1905     1.8922476470470428e-01
    z[6,5,6]  R1906     -4.0201491117477417e-01
    z[6,5,6]  R1907     -0.504845380783081
    z[6,5,6]  R1908     -1.3519684970378876e-01
    z[6,5,6]  R1909     5.3564831614494324e-02
    z[6,5,6]  R1910     0.361736923456192
    z[6,5,6]  R1911     5.7302600145339966e-01
    z[6,5,6]  R1912     -2.4264581501483917e-02
    z[6,5,6]  R1913     4.8225581645965576e-02
    z[6,5,6]  R1914     3.7936046719551086e-02
    z[6,5,6]  R1915     -6.4364320039749146e-01
    z[6,5,6]  R1916     -3.0650213360786438e-01
    z[6,5,6]  R1917     1.6895861923694611e-01
    z[6,5,6]  R1918     -6.7200702428817749e-01
    z[6,5,6]  R1919     6.7640833556652069e-02
    z[6,5,6]  R1920     -1.9662520289421082e-01
    z[6,5,6]  R1921     -3.8255810737609863e-01
    z[6,5,6]  R1922     -4.1507405042648315e-01
    z[6,5,6]  R1923     5.9493549168109894e-02
    z[6,5,6]  R1924     3.2696339488029480e-01
    z[6,5,6]  R1925     2.6271492242813110e-01
    z[6,5,6]  R1926     1.8878260254859924e-01
    z[6,5,6]  R1927     -4.1211363673210144e-01
    z[6,5,6]  R1928     3.4649577736854553e-01
    z[6,5,6]  R1929     -3.9930595085024834e-03
    z[6,5,6]  R1930     -1.6441099345684052e-02
    z[6,5,6]  R1931     -2.3564879596233368e-01
    z[6,5,6]  R1932     1.5668654814362526e-02
    z[6,5,6]  R1933     -7.9948879778385162e-02
    z[6,5,6]  R1934     1.9399905204772949e-01
    z[6,5,6]  R1935     -1.8508534133434296e-01
    z[6,5,6]  R1936     -8.7443970143795013e-02
    z[6,5,6]  R1937     -5.8296483755111694e-01
    z[6,5,6]  R1938     0.16391621530056
    z[6,5,6]  R1939     -2.4543851613998413e-01
    z[6,5,6]  R1940     -3.4087572246789932e-02
    z[6,5,6]  R1941     3.3718466758728027e-01
    z[6,5,6]  R1942     5.3106665611267090e-01
    z[6,5,6]  R1943     -2.6652488112449646e-01
    z[6,5,6]  R1944     -4.1730406880378723e-01
    z[6,5,6]  R1945     -2.5357139110565186e-01
    z[6,5,6]  R1946     -4.2735478281974792e-01
    z[6,5,6]  R1947     -2.5798463821411133e-01
    z[6,9,0]  R56       -1
    z[6,9,0]  R83       1
    z[6,9,0]  R1948     -1
    z[6,9,0]  R1949     1
    z[6,9,0]  R1962     -2.6171565055847168e-01
    z[6,9,0]  R1963     -4.8409137129783630e-01
    z[6,9,0]  R1964     -4.0355199575424194e-01
    z[6,9,0]  R1965     3.8174521923065186e-01
    z[6,9,0]  R1966     4.4334220886230469e-01
    z[6,9,0]  R1967     6.9331407546997070e-01
    z[6,9,0]  R1968     5.3337591886520386e-01
    z[6,9,0]  R1969     4.0423554182052612e-01
    z[6,9,0]  R1970     5.2008930593729019e-02
    z[6,9,0]  R1971     1.6269832849502563e-01
    z[6,9,0]  R1972     1.8686690926551819e-01
    z[6,9,0]  R1973     2.0650996267795563e-01
    z[6,9,0]  R1974     0.518527626991272
    z[6,9,0]  R1975     -2.3127996921539307e-01
    z[6,9,0]  R1976     9.4481986016035080e-03
    z[6,9,0]  R1977     -5.1704061031341553e-01
    z[6,9,0]  R1978     -2.1425540745258331e-01
    z[6,9,0]  R1979     1.6143192350864410e-01
    z[6,9,0]  R1980     9.0215191245079041e-02
    z[6,9,0]  R1981     -2.6278412342071533e-01
    z[6,9,0]  R1982     2.7463972568511963e-01
    z[6,9,0]  R1983     4.4837236404418945e-02
    z[6,9,0]  R1984     4.5980989933013916e-01
    z[6,9,0]  R1985     2.1286228299140930e-01
    z[6,9,0]  R1986     2.9343879222869873e-01
    z[6,9,0]  R1987     -3.5603947937488556e-02
    z[6,9,0]  R1988     -1.9836364313960075e-02
    z[6,9,0]  R1989     -4.4679844379425049e-01
    z[6,9,0]  R1990     1.1935807764530182e-01
    z[6,9,0]  R1991     5.2002698183059692e-01
    z[6,9,0]  R1992     2.4204833805561066e-01
    z[6,9,0]  R1993     -1.7059673368930817e-01
    z[6,9,0]  R1994     -7.4065856635570526e-02
    z[6,9,0]  R1995     -1.4131058752536774e-01
    z[6,9,0]  R1996     4.5075584203004837e-02
    z[6,9,0]  R1997     0.470356822013855
    z[6,9,0]  R1998     4.0498252958059311e-02
    z[6,9,0]  R1999     1.9757135212421417e-01
    z[6,9,0]  R2000     -1.5444062650203705e-01
    z[6,9,0]  R2001     1.4068734645843506e-01
    z[6,9,0]  R2002     -6.8731087446212769e-01
    z[6,9,0]  R2003     1.8868595361709595e-01
    z[6,9,0]  R2004     0.314831018447876
    z[6,9,0]  R2005     -6.5993182361125946e-02
    z[6,9,0]  R2006     6.4107263088226318e-01
    z[6,9,0]  R2007     -0.579894483089447
    z[6,9,0]  R2008     -3.6888748407363892e-01
    z[6,9,0]  R2009     -0.0707937628030777
    z[6,9,0]  R2010     3.2471904158592224e-01
    z[6,9,0]  R2011     -4.9675229191780090e-01
    z[6,9,0]  R2012     6.8372559547424316e-01
    z[6,9,0]  R2013     0.373611181974411
    z[6,9,0]  R2014     7.1792131662368774e-01
    z[6,9,0]  R2015     5.4708194732666016e-01
    z[6,9,0]  R2016     6.4950835704803467e-01
    z[6,9,0]  R2017     5.0930714607238770e-01
    z[6,9,0]  R2018     5.6132233142852783e-01
    z[6,9,0]  R2019     5.0749319791793823e-01
    z[6,9,0]  R2020     4.6792671084403992e-01
    z[6,9,0]  R2021     4.3902179598808289e-01
    z[6,9,0]  R2022     2.2824968397617340e-01
    z[6,9,0]  R2023     2.9348272085189819e-01
    z[6,9,0]  R2024     -4.1523975133895874e-01
    z[6,9,0]  R2025     4.0554103255271912e-01
    z[6,9,0]  R2026     -4.1935831308364868e-01
    z[6,9,0]  R2027     -1.5771935880184174e-01
    z[6,9,0]  R2028     6.8925315141677856e-01
    z[6,9,0]  R2029     5.3505182266235352e-01
    z[6,9,0]  R2030     -4.6125955879688263e-02
    z[6,9,0]  R2031     1.0763436555862427e-01
    z[6,9,0]  R2032     -1.3161328434944153e-01
    z[6,9,0]  R2033     -1.0903768241405487e-01
    z[6,9,0]  R2034     3.3622455596923828e-01
    z[6,9,0]  R2035     -1.2607610225677490e-01
    z[6,9,0]  R2036     2.4502323567867279e-01
    z[6,9,0]  R2037     -1.1051161214709282e-02
    z[6,9,0]  R2038     6.3118702173233032e-01
    z[6,9,0]  R2039     -1.7386722564697266e-01
    z[6,9,0]  R2040     0.850654661655426
    z[6,9,0]  R2041     7.7652537822723389e-01
    z[6,9,0]  R2042     1.4204418659210205e-01
    z[6,9,0]  R2043     -0.145231232047081
    z[6,9,0]  R2044     3.3592867851257324e-01
    z[6,9,0]  R2045     -5.2047741413116455e-01
    z[6,9,0]  R2046     -6.8435454368591309e-01
    z[6,9,0]  R2047     5.6111800670623779e-01
    z[6,9,0]  R2048     7.0265668630599976e-01
    z[6,9,0]  R2049     6.2914478778839111e-01
    z[6,9,0]  R2050     9.1968637704849243e-01
    z[6,9,0]  R2051     8.2632642984390259e-01
    z[6,9,1]  R57       -1
    z[6,9,1]  R84       1
    z[6,9,1]  R1950     -1
    z[6,9,1]  R1951     1
    z[6,9,1]  R1962     -5.4178398847579956e-01
    z[6,9,1]  R1963     -6.9878840446472168e-01
    z[6,9,1]  R1964     -6.4104229211807251e-01
    z[6,9,1]  R1965     -6.2312567234039307e-01
    z[6,9,1]  R1966     -6.4854383468627930e-01
    z[6,9,1]  R1967     -5.5554753541946411e-01
    z[6,9,1]  R1968     -5.5843216180801392e-01
    z[6,9,1]  R1969     -6.1905372142791748e-01
    z[6,9,1]  R1970     3.2348605990409851e-01
    z[6,9,1]  R1971     2.7741560339927673e-01
    z[6,9,1]  R1972     7.0114231109619141e-01
    z[6,9,1]  R1973     8.0504411458969116e-01
    z[6,9,1]  R1974     7.4551194906234741e-01
    z[6,9,1]  R1975     0.799316942691803
    z[6,9,1]  R1976     5.7951068878173828e-01
    z[6,9,1]  R1977     7.2197246551513672e-01
    z[6,9,1]  R1978     8.2318013906478882e-01
    z[6,9,1]  R1979     3.9585524797439575e-01
    z[6,9,1]  R1980     -1.6483476758003235e-01
    z[6,9,1]  R1981     -3.2920852303504944e-01
    z[6,9,1]  R1982     -5.7070219516754150e-01
    z[6,9,1]  R1983     -2.3279976844787598e-01
    z[6,9,1]  R1984     -2.3191344738006592e-01
    z[6,9,1]  R1985     -3.1613373756408691e-01
    z[6,9,1]  R1986     -5.6601864099502563e-01
    z[6,9,1]  R1987     -6.1027604341506958e-01
    z[6,9,1]  R1988     -5.3468197584152222e-01
    z[6,9,1]  R1989     -4.9905860424041748e-01
    z[6,9,1]  R1990     -2.8273808956146240e-01
    z[6,9,1]  R1991     5.5129849910736084e-01
    z[6,9,1]  R1992     -7.7998697757720947e-01
    z[6,9,1]  R1993     -5.2748590707778931e-01
    z[6,9,1]  R1994     6.0195082426071167e-01
    z[6,9,1]  R1995     5.9612119197845459e-01
    z[6,9,1]  R1996     6.3063758611679077e-01
    z[6,9,1]  R1997     7.5140869617462158e-01
    z[6,9,1]  R1998     2.4554686248302460e-01
    z[6,9,1]  R1999     3.0078712105751038e-01
    z[6,9,1]  R2000     6.2154537439346313e-01
    z[6,9,1]  R2001     4.2001038789749146e-01
    z[6,9,1]  R2002     3.7119895219802856e-01
    z[6,9,1]  R2003     -9.0266567468643188e-01
    z[6,9,1]  R2004     -8.2593297958374023e-01
    z[6,9,1]  R2005     -8.8777500391006470e-01
    z[6,9,1]  R2006     -0.729659914970398
    z[6,9,1]  R2007     4.9801096320152283e-01
    z[6,9,1]  R2008     4.3764263391494751e-01
    z[6,9,1]  R2009     -8.8085365295410156e-01
    z[6,9,1]  R2010     -7.9509723186492920e-01
    z[6,9,1]  R2011     0.380319744348526
    z[6,9,1]  R2012     6.1788678169250488e-01
    z[6,9,1]  R2013     4.1270852088928223e-01
    z[6,9,1]  R2014     3.7514024972915649e-01
    z[6,9,1]  R2015     5.3677648305892944e-01
    z[6,9,1]  R2016     3.5736340284347534e-01
    z[6,9,1]  R2017     6.0424667596817017e-01
    z[6,9,1]  R2018     5.2081435918807983e-01
    z[6,9,1]  R2019     5.3743779659271240e-01
    z[6,9,1]  R2020     3.2512420415878296e-01
    z[6,9,1]  R2021     3.0059731006622314e-01
    z[6,9,1]  R2022     1.0095855593681335e-01
    z[6,9,1]  R2023     0.0694957971572876
    z[6,9,1]  R2024     -2.5015929341316223e-01
    z[6,9,1]  R2025     2.1684801578521729e-01
    z[6,9,1]  R2026     -3.2938501238822937e-01
    z[6,9,1]  R2027     -1.5268255770206451e-01
    z[6,9,1]  R2028     -9.6914544701576233e-02
    z[6,9,1]  R2029     -1.2869754433631897e-01
    z[6,9,1]  R2030     -3.8322377204895020e-01
    z[6,9,1]  R2031     -6.1499518156051636e-01
    z[6,9,1]  R2032     1.0826831310987473e-01
    z[6,9,1]  R2033     4.4784832000732422e-01
    z[6,9,1]  R2034     1.4900089800357819e-01
    z[6,9,1]  R2035     0.413095086812973
    z[6,9,1]  R2036     -2.4542917311191559e-01
    z[6,9,1]  R2037     8.2061541080474854e-01
    z[6,9,1]  R2038     1.3012255728244781e-01
    z[6,9,1]  R2039     -7.1297782659530640e-01
    z[6,9,1]  R2040     2.6907867193222046e-01
    z[6,9,1]  R2041     0.342650443315506
    z[6,9,1]  R2042     4.7802817821502686e-01
    z[6,9,1]  R2043     3.4184309840202332e-01
    z[6,9,1]  R2044     4.0005022287368774e-01
    z[6,9,1]  R2045     5.2099019289016724e-01
    z[6,9,1]  R2046     -4.3250057101249695e-01
    z[6,9,1]  R2047     5.7302784919738770e-01
    z[6,9,1]  R2048     1.4423719048500061e-01
    z[6,9,1]  R2049     1.1946291476488113e-01
    z[6,9,1]  R2050     4.7665104269981384e-02
    z[6,9,1]  R2051     3.2784324884414673e-01
    z[6,9,2]  R58       -1
    z[6,9,2]  R85       1
    z[6,9,2]  R1952     -1
    z[6,9,2]  R1953     1
    z[6,9,2]  R1962     -7.2222578525543213e-01
    z[6,9,2]  R1963     -2.1871227025985718e-01
    z[6,9,2]  R1964     -2.7881475165486336e-02
    z[6,9,2]  R1965     1.7660474777221680e-01
    z[6,9,2]  R1966     2.2964945435523987e-01
    z[6,9,2]  R1967     0.317281574010849
    z[6,9,2]  R1968     6.0548734664916992e-01
    z[6,9,2]  R1969     1.7457424104213715e-01
    z[6,9,2]  R1970     0.370514452457428
    z[6,9,2]  R1971     2.9978102445602417e-01
    z[6,9,2]  R1972     4.9604347348213196e-01
    z[6,9,2]  R1973     2.4289000034332275e-01
    z[6,9,2]  R1974     -6.0649398714303970e-02
    z[6,9,2]  R1975     3.9552986621856689e-01
    z[6,9,2]  R1976     2.5210650637745857e-03
    z[6,9,2]  R1977     1.1607456207275391e-01
    z[6,9,2]  R1978     -2.7868294715881348e-01
    z[6,9,2]  R1979     9.7012668848037720e-02
    z[6,9,2]  R1980     -3.6694344133138657e-02
    z[6,9,2]  R1981     5.1258850097656250e-01
    z[6,9,2]  R1982     -2.5376963615417480e-01
    z[6,9,2]  R1983     -8.5715778172016144e-02
    z[6,9,2]  R1984     -2.3895697295665741e-01
    z[6,9,2]  R1985     5.1837243139743805e-02
    z[6,9,2]  R1986     1.9625426828861237e-01
    z[6,9,2]  R1987     4.5921251177787781e-01
    z[6,9,2]  R1988     -1.5197678469121456e-02
    z[6,9,2]  R1989     3.5245051980018616e-01
    z[6,9,2]  R1990     -2.3002301156520844e-01
    z[6,9,2]  R1991     4.7003245353698730e-01
    z[6,9,2]  R1992     -7.8544422984123230e-02
    z[6,9,2]  R1993     3.7402617931365967e-01
    z[6,9,2]  R1994     6.9573557376861572e-01
    z[6,9,2]  R1995     5.0485479831695557e-01
    z[6,9,2]  R1996     2.0139449834823608e-01
    z[6,9,2]  R1997     3.9129763841629028e-02
    z[6,9,2]  R1998     8.4094721078872681e-01
    z[6,9,2]  R1999     6.8945086002349854e-01
    z[6,9,2]  R2000     4.4315326213836670e-01
    z[6,9,2]  R2001     4.9261784553527832e-01
    z[6,9,2]  R2002     5.0463789701461792e-01
    z[6,9,2]  R2003     2.1183522045612335e-01
    z[6,9,2]  R2004     1.3079099357128143e-01
    z[6,9,2]  R2005     2.2281858325004578e-01
    z[6,9,2]  R2006     -3.7268076092004776e-02
    z[6,9,2]  R2007     5.2665509283542633e-02
    z[6,9,2]  R2008     6.3711577653884888e-01
    z[6,9,2]  R2009     -2.4388581514358521e-03
    z[6,9,2]  R2010     -3.2720527052879333e-01
    z[6,9,2]  R2011     3.9461705088615417e-01
    z[6,9,2]  R2012     1.0636379569768906e-01
    z[6,9,2]  R2013     -3.1514503061771393e-03
    z[6,9,2]  R2014     0.0676359236240387
    z[6,9,2]  R2015     2.4678535759449005e-01
    z[6,9,2]  R2016     3.8335734605789185e-01
    z[6,9,2]  R2017     0.0618075467646122
    z[6,9,2]  R2018     2.2087465226650238e-01
    z[6,9,2]  R2019     -2.5211388710886240e-03
    z[6,9,2]  R2020     -4.1485149413347244e-02
    z[6,9,2]  R2021     2.1859072148799896e-01
    z[6,9,2]  R2022     -0.0520876981317997
    z[6,9,2]  R2023     -1.4615756273269653e-01
    z[6,9,2]  R2024     -7.7589017152786255e-01
    z[6,9,2]  R2025     4.7463127970695496e-01
    z[6,9,2]  R2026     -5.5337548255920410e-01
    z[6,9,2]  R2027     -6.3175731897354126e-01
    z[6,9,2]  R2028     5.8389431238174438e-01
    z[6,9,2]  R2029     5.9024572372436523e-01
    z[6,9,2]  R2030     -5.0399124622344971e-01
    z[6,9,2]  R2031     -1.4449145644903183e-02
    z[6,9,2]  R2032     4.6048730611801147e-01
    z[6,9,2]  R2033     6.6099238395690918e-01
    z[6,9,2]  R2034     9.0163767337799072e-02
    z[6,9,2]  R2035     -7.6733380556106567e-02
    z[6,9,2]  R2036     4.7940242290496826e-01
    z[6,9,2]  R2037     -1.9397798180580139e-01
    z[6,9,2]  R2038     3.3856812119483948e-01
    z[6,9,2]  R2039     -2.4168695509433746e-01
    z[6,9,2]  R2040     1.6360796988010406e-01
    z[6,9,2]  R2041     -1.9548648595809937e-01
    z[6,9,2]  R2042     4.8458430171012878e-01
    z[6,9,2]  R2043     2.2467520087957382e-02
    z[6,9,2]  R2044     6.4751081168651581e-02
    z[6,9,2]  R2045     -6.5491750836372375e-02
    z[6,9,2]  R2046     -3.0540412664413452e-01
    z[6,9,2]  R2047     1.4728691428899765e-02
    z[6,9,2]  R2048     2.0782814919948578e-01
    z[6,9,2]  R2049     0.5059814453125
    z[6,9,2]  R2050     3.3739551901817322e-01
    z[6,9,2]  R2051     1.1924399994313717e-02
    z[6,9,3]  R59       -1
    z[6,9,3]  R86       1
    z[6,9,3]  R1954     -1
    z[6,9,3]  R1955     1
    z[6,9,3]  R1962     2.5378414988517761e-01
    z[6,9,3]  R1963     -2.3658950626850128e-01
    z[6,9,3]  R1964     9.3324109911918640e-02
    z[6,9,3]  R1965     -1.0986461490392685e-01
    z[6,9,3]  R1966     -8.5124827921390533e-02
    z[6,9,3]  R1967     2.5477004051208496e-01
    z[6,9,3]  R1968     -9.1371774673461914e-02
    z[6,9,3]  R1969     -2.2307975217700005e-02
    z[6,9,3]  R1970     -2.1528103947639465e-01
    z[6,9,3]  R1971     -1.6826815903186798e-01
    z[6,9,3]  R1972     6.4688093960285187e-02
    z[6,9,3]  R1973     4.0098321437835693e-01
    z[6,9,3]  R1974     -1.6461324691772461e-01
    z[6,9,3]  R1975     4.8995133489370346e-02
    z[6,9,3]  R1976     -1.0676565766334534e-01
    z[6,9,3]  R1977     2.9994124174118042e-01
    z[6,9,3]  R1978     2.1029375493526459e-01
    z[6,9,3]  R1979     -4.0868633985519409e-01
    z[6,9,3]  R1980     -2.4901716411113739e-01
    z[6,9,3]  R1981     4.1392478346824646e-01
    z[6,9,3]  R1982     -5.2605450153350830e-01
    z[6,9,3]  R1983     -8.9653067290782928e-02
    z[6,9,3]  R1984     -7.7100642956793308e-03
    z[6,9,3]  R1985     3.1648337841033936e-01
    z[6,9,3]  R1986     5.1185590028762817e-01
    z[6,9,3]  R1987     2.8471636772155762e-01
    z[6,9,3]  R1988     2.7658654376864433e-02
    z[6,9,3]  R1989     2.8667786717414856e-01
    z[6,9,3]  R1990     2.4606034159660339e-01
    z[6,9,3]  R1991     -3.3424678444862366e-01
    z[6,9,3]  R1992     -4.4091507792472839e-01
    z[6,9,3]  R1993     5.8085656166076660e-01
    z[6,9,3]  R1994     -2.7782931923866272e-01
    z[6,9,3]  R1995     9.5294103026390076e-02
    z[6,9,3]  R1996     -3.8310185074806213e-01
    z[6,9,3]  R1997     -1.7785681784152985e-01
    z[6,9,3]  R1998     -0.131015345454216
    z[6,9,3]  R1999     -1.9377744197845459e-01
    z[6,9,3]  R2000     4.7956906259059906e-02
    z[6,9,3]  R2001     -0.0905357152223587
    z[6,9,3]  R2002     -1.0172878205776215e-01
    z[6,9,3]  R2003     2.9667043685913086e-01
    z[6,9,3]  R2004     1.1939336359500885e-01
    z[6,9,3]  R2005     -2.9703578352928162e-01
    z[6,9,3]  R2006     3.4623626619577408e-02
    z[6,9,3]  R2007     -3.6751374602317810e-01
    z[6,9,3]  R2008     -3.2996940612792969e-01
    z[6,9,3]  R2009     -2.0167191326618195e-01
    z[6,9,3]  R2010     -1.8123102188110352e-01
    z[6,9,3]  R2011     -1.0467819869518280e-01
    z[6,9,3]  R2012     0.279776394367218
    z[6,9,3]  R2013     7.4402558803558350e-01
    z[6,9,3]  R2014     5.3678333759307861e-01
    z[6,9,3]  R2015     5.6045120954513550e-01
    z[6,9,3]  R2016     4.6524614095687866e-01
    z[6,9,3]  R2017     4.5251858234405518e-01
    z[6,9,3]  R2018     3.9085876941680908e-01
    z[6,9,3]  R2019     4.6487808227539062e-01
    z[6,9,3]  R2020     7.6949393749237061e-01
    z[6,9,3]  R2021     0.788844883441925
    z[6,9,3]  R2022     -8.9666461944580078e-01
    z[6,9,3]  R2023     -8.4360587596893311e-01
    z[6,9,3]  R2024     2.8829258680343628e-01
    z[6,9,3]  R2025     -6.7255079746246338e-01
    z[6,9,3]  R2026     -8.7308675050735474e-02
    z[6,9,3]  R2027     -3.8905474543571472e-01
    z[6,9,3]  R2028     1.9464203715324402e-01
    z[6,9,3]  R2029     2.5558346509933472e-01
    z[6,9,3]  R2030     -3.0210450291633606e-01
    z[6,9,3]  R2031     4.8521433025598526e-02
    z[6,9,3]  R2032     -6.6162657737731934e-01
    z[6,9,3]  R2033     -0.0974312275648117
    z[6,9,3]  R2034     -5.6235814094543457e-01
    z[6,9,3]  R2035     -8.3075851202011108e-01
    z[6,9,3]  R2036     -5.5331909656524658e-01
    z[6,9,3]  R2037     1.8006226420402527e-01
    z[6,9,3]  R2038     6.6044223308563232e-01
    z[6,9,3]  R2039     2.1907755732536316e-01
    z[6,9,3]  R2040     2.4703326821327209e-01
    z[6,9,3]  R2041     1.1764498800039291e-01
    z[6,9,3]  R2042     -0.595727801322937
    z[6,9,3]  R2043     -7.4787449836730957e-01
    z[6,9,3]  R2044     -0.720929741859436
    z[6,9,3]  R2045     2.8892710804939270e-01
    z[6,9,3]  R2046     -3.9735764265060425e-01
    z[6,9,3]  R2047     5.5459076166152954e-01
    z[6,9,3]  R2048     4.6066072583198547e-01
    z[6,9,3]  R2049     4.0360546112060547e-01
    z[6,9,3]  R2050     1.0930617898702621e-01
    z[6,9,3]  R2051     2.4287261068820953e-01
    z[6,9,4]  R60       -1
    z[6,9,4]  R87       1
    z[6,9,4]  R1956     -1
    z[6,9,4]  R1957     1
    z[6,9,4]  R1962     -1.4301426708698273e-01
    z[6,9,4]  R1963     4.0275582671165466e-01
    z[6,9,4]  R1964     5.7950782775878906e-01
    z[6,9,4]  R1965     -1.9071938097476959e-01
    z[6,9,4]  R1966     -5.0799185037612915e-01
    z[6,9,4]  R1967     6.4860903657972813e-03
    z[6,9,4]  R1968     9.7983568906784058e-02
    z[6,9,4]  R1969     -2.1194885671138763e-01
    z[6,9,4]  R1970     -1.5737390518188477e-01
    z[6,9,4]  R1971     3.3369123935699463e-01
    z[6,9,4]  R1972     6.4953304827213287e-03
    z[6,9,4]  R1973     -1.3158570230007172e-01
    z[6,9,4]  R1974     2.0307642221450806e-01
    z[6,9,4]  R1975     -3.4298968315124512e-01
    z[6,9,4]  R1976     6.1942702531814575e-01
    z[6,9,4]  R1977     1.9328743219375610e-01
    z[6,9,4]  R1978     2.0901934802532196e-01
    z[6,9,4]  R1979     0.644838273525238
    z[6,9,4]  R1980     -3.1977668404579163e-01
    z[6,9,4]  R1981     -2.4432940781116486e-01
    z[6,9,4]  R1982     -3.4927028417587280e-01
    z[6,9,4]  R1983     -3.2429978251457214e-01
    z[6,9,4]  R1984     3.5322725772857666e-02
    z[6,9,4]  R1985     -1.1022664606571198e-01
    z[6,9,4]  R1986     6.3435077667236328e-02
    z[6,9,4]  R1987     -3.1357151269912720e-01
    z[6,9,4]  R1988     7.1364670991897583e-02
    z[6,9,4]  R1989     -3.0642592906951904e-01
    z[6,9,4]  R1990     4.2516708374023438e-01
    z[6,9,4]  R1991     -2.8752040863037109e-01
    z[6,9,4]  R1992     1.9588541984558105e-01
    z[6,9,4]  R1993     -3.3665180206298828e-01
    z[6,9,4]  R1994     -1.9591686129570007e-01
    z[6,9,4]  R1995     5.7059031724929810e-01
    z[6,9,4]  R1996     6.1753702163696289e-01
    z[6,9,4]  R1997     2.2575153410434723e-01
    z[6,9,4]  R1998     3.6807185411453247e-01
    z[6,9,4]  R1999     3.8116380572319031e-01
    z[6,9,4]  R2000     4.7033616900444031e-01
    z[6,9,4]  R2001     5.4592221975326538e-01
    z[6,9,4]  R2002     1.2485647201538086e-01
    z[6,9,4]  R2003     1.2310385704040527e-01
    z[6,9,4]  R2004     9.4127535820007324e-02
    z[6,9,4]  R2005     -2.7633709833025932e-02
    z[6,9,4]  R2006     6.7929677665233612e-02
    z[6,9,4]  R2007     3.4966897964477539e-01
    z[6,9,4]  R2008     -2.3460452258586884e-01
    z[6,9,4]  R2009     2.3682729899883270e-01
    z[6,9,4]  R2010     1.4008422195911407e-01
    z[6,9,4]  R2011     -4.9797093868255615e-01
    z[6,9,4]  R2012     -0.0261647067964077
    z[6,9,4]  R2013     -3.1128239631652832e-01
    z[6,9,4]  R2014     -1.7917363345623016e-01
    z[6,9,4]  R2015     1.4596521854400635e-01
    z[6,9,4]  R2016     -7.2413086891174316e-02
    z[6,9,4]  R2017     -3.8450222462415695e-02
    z[6,9,4]  R2018     -1.3183638453483582e-01
    z[6,9,4]  R2019     -2.1108466386795044e-01
    z[6,9,4]  R2020     -2.5628310441970825e-01
    z[6,9,4]  R2021     -1.5942068397998810e-01
    z[6,9,4]  R2022     1.7088495194911957e-01
    z[6,9,4]  R2023     -2.4839282035827637e-01
    z[6,9,4]  R2024     -2.4773180484771729e-02
    z[6,9,4]  R2025     -1.0599285364151001e-01
    z[6,9,4]  R2026     -3.3445760607719421e-01
    z[6,9,4]  R2027     -1.4131318032741547e-01
    z[6,9,4]  R2028     -2.6053443551063538e-01
    z[6,9,4]  R2029     -7.1282930672168732e-02
    z[6,9,4]  R2030     -4.5570683479309082e-01
    z[6,9,4]  R2031     -5.4738348722457886e-01
    z[6,9,4]  R2032     -1.4750123023986816e-01
    z[6,9,4]  R2033     0.0989510715007782
    z[6,9,4]  R2034     -0.514692485332489
    z[6,9,4]  R2035     -1.6152802109718323e-01
    z[6,9,4]  R2036     -4.8854687809944153e-01
    z[6,9,4]  R2037     -1.6791987419128418e-01
    z[6,9,4]  R2038     1.0922468453645706e-01
    z[6,9,4]  R2039     -4.6905669569969177e-01
    z[6,9,4]  R2040     8.1659637391567230e-02
    z[6,9,4]  R2041     1.8564572930335999e-01
    z[6,9,4]  R2042     1.2279351055622101e-01
    z[6,9,4]  R2043     -4.2905974388122559e-01
    z[6,9,4]  R2044     -3.3084303140640259e-01
    z[6,9,4]  R2045     -3.2869505882263184e-01
    z[6,9,4]  R2046     -2.5666296482086182e-01
    z[6,9,4]  R2047     -1.7523898184299469e-01
    z[6,9,4]  R2048     -1.7954197525978088e-01
    z[6,9,4]  R2049     -1.9712452590465546e-01
    z[6,9,4]  R2050     -2.9913255944848061e-02
    z[6,9,4]  R2051     -1.8272459506988525e-01
    z[6,9,5]  R61       -1
    z[6,9,5]  R88       1
    z[6,9,5]  R1958     -1
    z[6,9,5]  R1959     1
    z[6,9,5]  R1962     -1.1922200024127960e-01
    z[6,9,5]  R1963     7.7422834932804108e-02
    z[6,9,5]  R1964     -1.2829670310020447e-01
    z[6,9,5]  R1965     -1.4491325244307518e-02
    z[6,9,5]  R1966     -2.5016161799430847e-01
    z[6,9,5]  R1967     -1.5713991224765778e-01
    z[6,9,5]  R1968     -1.3413535058498383e-01
    z[6,9,5]  R1969     -6.0129874944686890e-01
    z[6,9,5]  R1970     -0.818955659866333
    z[6,9,5]  R1971     -6.7674064636230469e-01
    z[6,9,5]  R1972     3.7047886848449707e-01
    z[6,9,5]  R1973     0.217903271317482
    z[6,9,5]  R1974     3.0730402469635010e-01
    z[6,9,5]  R1975     -1.3440935313701630e-01
    z[6,9,5]  R1976     6.3022486865520477e-02
    z[6,9,5]  R1977     3.2050319015979767e-02
    z[6,9,5]  R1978     -0.0315934419631958
    z[6,9,5]  R1979     2.2678345441818237e-01
    z[6,9,5]  R1980     2.8900709748268127e-01
    z[6,9,5]  R1981     3.4041884541511536e-01
    z[6,9,5]  R1982     -3.7923332303762436e-02
    z[6,9,5]  R1983     7.0256894826889038e-01
    z[6,9,5]  R1984     7.4205398559570312e-01
    z[6,9,5]  R1985     6.5531963109970093e-01
    z[6,9,5]  R1986     5.3755646944046021e-01
    z[6,9,5]  R1987     3.3445313572883606e-01
    z[6,9,5]  R1988     0.444111704826355
    z[6,9,5]  R1989     1.2943306565284729e-01
    z[6,9,5]  R1990     5.9656274318695068e-01
    z[6,9,5]  R1991     0.0689297541975975
    z[6,9,5]  R1992     1.5085551142692566e-01
    z[6,9,5]  R1993     2.7574095129966736e-01
    z[6,9,5]  R1994     -1.6325747966766357e-01
    z[6,9,5]  R1995     1.7915613949298859e-01
    z[6,9,5]  R1996     -1.7667318880558014e-01
    z[6,9,5]  R1997     -2.4725198745727539e-01
    z[6,9,5]  R1998     5.6163590401411057e-02
    z[6,9,5]  R1999     -4.2012929916381836e-01
    z[6,9,5]  R2000     -9.1173492372035980e-02
    z[6,9,5]  R2001     0.00541772460564971
    z[6,9,5]  R2002     1.6958688199520111e-01
    z[6,9,5]  R2003     -1.6247332096099854e-02
    z[6,9,5]  R2004     -0.414997398853302
    z[6,9,5]  R2005     2.4028332531452179e-01
    z[6,9,5]  R2006     2.1356710791587830e-01
    z[6,9,5]  R2007     -3.4443348646163940e-01
    z[6,9,5]  R2008     3.2018628716468811e-01
    z[6,9,5]  R2009     -1.2827628850936890e-01
    z[6,9,5]  R2010     2.9745748639106750e-01
    z[6,9,5]  R2011     3.3233964443206787e-01
    z[6,9,5]  R2012     -2.3302085697650909e-01
    z[6,9,5]  R2013     -1.5327532589435577e-01
    z[6,9,5]  R2014     -1.3046006858348846e-01
    z[6,9,5]  R2015     1.1618450284004211e-01
    z[6,9,5]  R2016     -1.0945549607276917e-01
    z[6,9,5]  R2017     -3.8443204760551453e-01
    z[6,9,5]  R2018     -3.7906184792518616e-01
    z[6,9,5]  R2019     -4.3311020731925964e-01
    z[6,9,5]  R2020     3.5544145852327347e-02
    z[6,9,5]  R2021     1.2966738641262054e-01
    z[6,9,5]  R2022     1.0781476646661758e-01
    z[6,9,5]  R2023     -1.6917613148689270e-01
    z[6,9,5]  R2024     -1.6113029420375824e-01
    z[6,9,5]  R2025     -2.5836187601089478e-01
    z[6,9,5]  R2026     -2.8022146224975586e-01
    z[6,9,5]  R2027     -4.7952279448509216e-01
    z[6,9,5]  R2028     8.8292052969336510e-03
    z[6,9,5]  R2029     4.8833701014518738e-01
    z[6,9,5]  R2030     5.2868378162384033e-01
    z[6,9,5]  R2031     5.1520484685897827e-01
    z[6,9,5]  R2032     -4.6827748417854309e-01
    z[6,9,5]  R2033     -5.4940879344940186e-01
    z[6,9,5]  R2034     4.6486946940422058e-01
    z[6,9,5]  R2035     -1.9641081988811493e-01
    z[6,9,5]  R2036     1.2209662795066833e-01
    z[6,9,5]  R2037     4.7225895524024963e-01
    z[6,9,5]  R2038     1.2973374128341675e-01
    z[6,9,5]  R2039     2.1981272101402283e-01
    z[6,9,5]  R2040     -2.7609056234359741e-01
    z[6,9,5]  R2041     3.6554217338562012e-01
    z[6,9,5]  R2042     2.4138320982456207e-01
    z[6,9,5]  R2043     1.0179761797189713e-01
    z[6,9,5]  R2044     4.6536628156900406e-02
    z[6,9,5]  R2045     -1.4922022819519043e-01
    z[6,9,5]  R2046     1.5973517298698425e-01
    z[6,9,5]  R2047     -1.0053821653127670e-01
    z[6,9,5]  R2048     4.4184795022010803e-01
    z[6,9,5]  R2049     0.357094407081604
    z[6,9,5]  R2050     1.5882861614227295e-01
    z[6,9,5]  R2051     -3.1715262681245804e-02
    z[6,9,6]  R62       -1
    z[6,9,6]  R89       1
    z[6,9,6]  R1960     -1
    z[6,9,6]  R1961     1
    z[6,9,6]  R1962     -1.3149733841419220e-01
    z[6,9,6]  R1963     -7.3035918176174164e-02
    z[6,9,6]  R1964     -2.5383949279785156e-01
    z[6,9,6]  R1965     -0.62140291929245
    z[6,9,6]  R1966     4.7083269804716110e-02
    z[6,9,6]  R1967     1.4273120462894440e-01
    z[6,9,6]  R1968     -3.3267743885517120e-02
    z[6,9,6]  R1969     -1.2613409757614136e-01
    z[6,9,6]  R1970     -1.1649063229560852e-01
    z[6,9,6]  R1971     -4.5722997188568115e-01
    z[6,9,6]  R1972     2.9315501451492310e-01
    z[6,9,6]  R1973     -1.5709204971790314e-01
    z[6,9,6]  R1974     9.4283193349838257e-02
    z[6,9,6]  R1975     1.1423571407794952e-01
    z[6,9,6]  R1976     5.1479238271713257e-01
    z[6,9,6]  R1977     2.6381725072860718e-01
    z[6,9,6]  R1978     3.3150288462638855e-01
    z[6,9,6]  R1979     4.1659972071647644e-01
    z[6,9,6]  R1980     8.4590339660644531e-01
    z[6,9,6]  R1981     4.6141487360000610e-01
    z[6,9,6]  R1982     3.6648562550544739e-01
    z[6,9,6]  R1983     5.7413893938064575e-01
    z[6,9,6]  R1984     3.5459730029106140e-01
    z[6,9,6]  R1985     5.5705165863037109e-01
    z[6,9,6]  R1986     -3.6742768716067076e-03
    z[6,9,6]  R1987     3.5237762331962585e-01
    z[6,9,6]  R1988     7.1442115306854248e-01
    z[6,9,6]  R1989     4.8400026559829712e-01
    z[6,9,6]  R1990     5.0567018985748291e-01
    z[6,9,6]  R1991     -7.4640981853008270e-02
    z[6,9,6]  R1992     2.6707506179809570e-01
    z[6,9,6]  R1993     1.6123822331428528e-01
    z[6,9,6]  R1994     7.6784379780292511e-02
    z[6,9,6]  R1995     -5.5147089064121246e-02
    z[6,9,6]  R1996     1.9290894269943237e-02
    z[6,9,6]  R1997     -2.6246497035026550e-01
    z[6,9,6]  R1998     2.7400395274162292e-01
    z[6,9,6]  R1999     1.8922476470470428e-01
    z[6,9,6]  R2000     -4.0201491117477417e-01
    z[6,9,6]  R2001     -0.504845380783081
    z[6,9,6]  R2002     -2.8365132212638855e-01
    z[6,9,6]  R2003     3.5866007208824158e-02
    z[6,9,6]  R2004     7.9198144376277924e-02
    z[6,9,6]  R2005     -1.0546236485242844e-01
    z[6,9,6]  R2006     -6.1719194054603577e-02
    z[6,9,6]  R2007     -0.192262202501297
    z[6,9,6]  R2008     -6.0034235939383507e-03
    z[6,9,6]  R2009     -3.2536983489990234e-01
    z[6,9,6]  R2010     -1.1985626071691513e-01
    z[6,9,6]  R2011     2.8894510865211487e-01
    z[6,9,6]  R2012     -0.0785093605518341
    z[6,9,6]  R2013     -1.2693412601947784e-01
    z[6,9,6]  R2014     -4.4996868818998337e-02
    z[6,9,6]  R2015     -5.2526675164699554e-02
    z[6,9,6]  R2016     -2.6417663693428040e-01
    z[6,9,6]  R2017     1.3278764486312866e-01
    z[6,9,6]  R2018     -2.2593078017234802e-01
    z[6,9,6]  R2019     -7.3157578706741333e-02
    z[6,9,6]  R2020     1.2063318490982056e-01
    z[6,9,6]  R2021     -0.0679294764995575
    z[6,9,6]  R2022     -3.0027189850807190e-01
    z[6,9,6]  R2023     2.9272112250328064e-01
    z[6,9,6]  R2024     2.3087087273597717e-01
    z[6,9,6]  R2025     1.8146304786205292e-01
    z[6,9,6]  R2026     4.5979449152946472e-01
    z[6,9,6]  R2027     3.8912755250930786e-01
    z[6,9,6]  R2028     2.6222813129425049e-01
    z[6,9,6]  R2029     -1.9972331821918488e-01
    z[6,9,6]  R2030     1.3624365627765656e-01
    z[6,9,6]  R2031     2.0632030069828033e-01
    z[6,9,6]  R2032     2.8304985165596008e-01
    z[6,9,6]  R2033     1.7174871265888214e-01
    z[6,9,6]  R2034     2.4364647269248962e-01
    z[6,9,6]  R2035     2.2965441644191742e-01
    z[6,9,6]  R2036     3.0025640130043030e-01
    z[6,9,6]  R2037     7.2059154510498047e-02
    z[6,9,6]  R2038     -7.1399368345737457e-02
    z[6,9,6]  R2039     2.9443749785423279e-01
    z[6,9,6]  R2040     1.8247225880622864e-01
    z[6,9,6]  R2041     -2.4384070932865143e-01
    z[6,9,6]  R2042     -2.9707708954811096e-01
    z[6,9,6]  R2043     3.2829120755195618e-01
    z[6,9,6]  R2044     0.302583247423172
    z[6,9,6]  R2045     4.8948684334754944e-01
    z[6,9,6]  R2046     4.5234248042106628e-02
    z[6,9,6]  R2047     9.0449877083301544e-02
    z[6,9,6]  R2048     5.1024246960878372e-02
    z[6,9,6]  R2049     6.7944198846817017e-02
    z[6,9,6]  R2050     0.000320744322380051
    z[6,9,6]  R2051     3.4085190296173096e-01
    z[9,6,0]  R56       1
    z[9,6,0]  R83       -1
    z[9,6,0]  R2052     -1
    z[9,6,0]  R2053     1
    z[9,6,0]  R2066     -6.8731087446212769e-01
    z[9,6,0]  R2067     1.8868595361709595e-01
    z[9,6,0]  R2068     0.314831018447876
    z[9,6,0]  R2069     -6.5993182361125946e-02
    z[9,6,0]  R2070     6.4107263088226318e-01
    z[9,6,0]  R2071     -0.579894483089447
    z[9,6,0]  R2072     -3.6888748407363892e-01
    z[9,6,0]  R2073     -0.0707937628030777
    z[9,6,0]  R2074     3.2471904158592224e-01
    z[9,6,0]  R2075     -4.9675229191780090e-01
    z[9,6,0]  R2076     6.8372559547424316e-01
    z[9,6,0]  R2077     0.373611181974411
    z[9,6,0]  R2078     7.1792131662368774e-01
    z[9,6,0]  R2079     5.4708194732666016e-01
    z[9,6,0]  R2080     6.4950835704803467e-01
    z[9,6,0]  R2081     5.0930714607238770e-01
    z[9,6,0]  R2082     5.6132233142852783e-01
    z[9,6,0]  R2083     5.0749319791793823e-01
    z[9,6,0]  R2084     4.6792671084403992e-01
    z[9,6,0]  R2085     4.3902179598808289e-01
    z[9,6,0]  R2086     2.2824968397617340e-01
    z[9,6,0]  R2087     2.9348272085189819e-01
    z[9,6,0]  R2088     -4.1523975133895874e-01
    z[9,6,0]  R2089     4.0554103255271912e-01
    z[9,6,0]  R2090     -4.1935831308364868e-01
    z[9,6,0]  R2091     -1.5771935880184174e-01
    z[9,6,0]  R2092     6.8925315141677856e-01
    z[9,6,0]  R2093     5.3505182266235352e-01
    z[9,6,0]  R2094     -4.6125955879688263e-02
    z[9,6,0]  R2095     1.0763436555862427e-01
    z[9,6,0]  R2096     -1.3161328434944153e-01
    z[9,6,0]  R2097     -1.0903768241405487e-01
    z[9,6,0]  R2098     3.3622455596923828e-01
    z[9,6,0]  R2099     -1.2607610225677490e-01
    z[9,6,0]  R2100     2.4502323567867279e-01
    z[9,6,0]  R2101     -1.1051161214709282e-02
    z[9,6,0]  R2102     6.3118702173233032e-01
    z[9,6,0]  R2103     -1.7386722564697266e-01
    z[9,6,0]  R2104     0.850654661655426
    z[9,6,0]  R2105     7.7652537822723389e-01
    z[9,6,0]  R2106     1.4204418659210205e-01
    z[9,6,0]  R2107     -0.145231232047081
    z[9,6,0]  R2108     3.3592867851257324e-01
    z[9,6,0]  R2109     -5.2047741413116455e-01
    z[9,6,0]  R2110     -6.8435454368591309e-01
    z[9,6,0]  R2111     5.6111800670623779e-01
    z[9,6,0]  R2112     7.0265668630599976e-01
    z[9,6,0]  R2113     6.2914478778839111e-01
    z[9,6,0]  R2114     9.1968637704849243e-01
    z[9,6,0]  R2115     8.2632642984390259e-01
    z[9,6,0]  R2116     -2.6171565055847168e-01
    z[9,6,0]  R2117     -4.8409137129783630e-01
    z[9,6,0]  R2118     -4.0355199575424194e-01
    z[9,6,0]  R2119     3.8174521923065186e-01
    z[9,6,0]  R2120     4.4334220886230469e-01
    z[9,6,0]  R2121     6.9331407546997070e-01
    z[9,6,0]  R2122     5.3337591886520386e-01
    z[9,6,0]  R2123     4.0423554182052612e-01
    z[9,6,0]  R2124     5.2008930593729019e-02
    z[9,6,0]  R2125     1.6269832849502563e-01
    z[9,6,0]  R2126     1.8686690926551819e-01
    z[9,6,0]  R2127     2.0650996267795563e-01
    z[9,6,0]  R2128     0.518527626991272
    z[9,6,0]  R2129     -2.3127996921539307e-01
    z[9,6,0]  R2130     9.4481986016035080e-03
    z[9,6,0]  R2131     -5.1704061031341553e-01
    z[9,6,0]  R2132     -2.1425540745258331e-01
    z[9,6,0]  R2133     1.6143192350864410e-01
    z[9,6,0]  R2134     9.0215191245079041e-02
    z[9,6,0]  R2135     -2.6278412342071533e-01
    z[9,6,0]  R2136     2.7463972568511963e-01
    z[9,6,0]  R2137     4.4837236404418945e-02
    z[9,6,0]  R2138     4.5980989933013916e-01
    z[9,6,0]  R2139     2.1286228299140930e-01
    z[9,6,0]  R2140     2.9343879222869873e-01
    z[9,6,0]  R2141     -3.5603947937488556e-02
    z[9,6,0]  R2142     -1.9836364313960075e-02
    z[9,6,0]  R2143     -4.4679844379425049e-01
    z[9,6,0]  R2144     1.1935807764530182e-01
    z[9,6,0]  R2145     5.2002698183059692e-01
    z[9,6,0]  R2146     2.4204833805561066e-01
    z[9,6,0]  R2147     -1.7059673368930817e-01
    z[9,6,0]  R2148     -7.4065856635570526e-02
    z[9,6,0]  R2149     -1.4131058752536774e-01
    z[9,6,0]  R2150     4.5075584203004837e-02
    z[9,6,0]  R2151     0.470356822013855
    z[9,6,0]  R2152     4.0498252958059311e-02
    z[9,6,0]  R2153     1.9757135212421417e-01
    z[9,6,0]  R2154     -1.5444062650203705e-01
    z[9,6,0]  R2155     1.4068734645843506e-01
    z[9,6,1]  R57       1
    z[9,6,1]  R84       -1
    z[9,6,1]  R2054     -1
    z[9,6,1]  R2055     1
    z[9,6,1]  R2066     3.7119895219802856e-01
    z[9,6,1]  R2067     -9.0266567468643188e-01
    z[9,6,1]  R2068     -8.2593297958374023e-01
    z[9,6,1]  R2069     -8.8777500391006470e-01
    z[9,6,1]  R2070     -0.729659914970398
    z[9,6,1]  R2071     4.9801096320152283e-01
    z[9,6,1]  R2072     4.3764263391494751e-01
    z[9,6,1]  R2073     -8.8085365295410156e-01
    z[9,6,1]  R2074     -7.9509723186492920e-01
    z[9,6,1]  R2075     0.380319744348526
    z[9,6,1]  R2076     6.1788678169250488e-01
    z[9,6,1]  R2077     4.1270852088928223e-01
    z[9,6,1]  R2078     3.7514024972915649e-01
    z[9,6,1]  R2079     5.3677648305892944e-01
    z[9,6,1]  R2080     3.5736340284347534e-01
    z[9,6,1]  R2081     6.0424667596817017e-01
    z[9,6,1]  R2082     5.2081435918807983e-01
    z[9,6,1]  R2083     5.3743779659271240e-01
    z[9,6,1]  R2084     3.2512420415878296e-01
    z[9,6,1]  R2085     3.0059731006622314e-01
    z[9,6,1]  R2086     1.0095855593681335e-01
    z[9,6,1]  R2087     0.0694957971572876
    z[9,6,1]  R2088     -2.5015929341316223e-01
    z[9,6,1]  R2089     2.1684801578521729e-01
    z[9,6,1]  R2090     -3.2938501238822937e-01
    z[9,6,1]  R2091     -1.5268255770206451e-01
    z[9,6,1]  R2092     -9.6914544701576233e-02
    z[9,6,1]  R2093     -1.2869754433631897e-01
    z[9,6,1]  R2094     -3.8322377204895020e-01
    z[9,6,1]  R2095     -6.1499518156051636e-01
    z[9,6,1]  R2096     1.0826831310987473e-01
    z[9,6,1]  R2097     4.4784832000732422e-01
    z[9,6,1]  R2098     1.4900089800357819e-01
    z[9,6,1]  R2099     0.413095086812973
    z[9,6,1]  R2100     -2.4542917311191559e-01
    z[9,6,1]  R2101     8.2061541080474854e-01
    z[9,6,1]  R2102     1.3012255728244781e-01
    z[9,6,1]  R2103     -7.1297782659530640e-01
    z[9,6,1]  R2104     2.6907867193222046e-01
    z[9,6,1]  R2105     0.342650443315506
    z[9,6,1]  R2106     4.7802817821502686e-01
    z[9,6,1]  R2107     3.4184309840202332e-01
    z[9,6,1]  R2108     4.0005022287368774e-01
    z[9,6,1]  R2109     5.2099019289016724e-01
    z[9,6,1]  R2110     -4.3250057101249695e-01
    z[9,6,1]  R2111     5.7302784919738770e-01
    z[9,6,1]  R2112     1.4423719048500061e-01
    z[9,6,1]  R2113     1.1946291476488113e-01
    z[9,6,1]  R2114     4.7665104269981384e-02
    z[9,6,1]  R2115     3.2784324884414673e-01
    z[9,6,1]  R2116     -5.4178398847579956e-01
    z[9,6,1]  R2117     -6.9878840446472168e-01
    z[9,6,1]  R2118     -6.4104229211807251e-01
    z[9,6,1]  R2119     -6.2312567234039307e-01
    z[9,6,1]  R2120     -6.4854383468627930e-01
    z[9,6,1]  R2121     -5.5554753541946411e-01
    z[9,6,1]  R2122     -5.5843216180801392e-01
    z[9,6,1]  R2123     -6.1905372142791748e-01
    z[9,6,1]  R2124     3.2348605990409851e-01
    z[9,6,1]  R2125     2.7741560339927673e-01
    z[9,6,1]  R2126     7.0114231109619141e-01
    z[9,6,1]  R2127     8.0504411458969116e-01
    z[9,6,1]  R2128     7.4551194906234741e-01
    z[9,6,1]  R2129     0.799316942691803
    z[9,6,1]  R2130     5.7951068878173828e-01
    z[9,6,1]  R2131     7.2197246551513672e-01
    z[9,6,1]  R2132     8.2318013906478882e-01
    z[9,6,1]  R2133     3.9585524797439575e-01
    z[9,6,1]  R2134     -1.6483476758003235e-01
    z[9,6,1]  R2135     -3.2920852303504944e-01
    z[9,6,1]  R2136     -5.7070219516754150e-01
    z[9,6,1]  R2137     -2.3279976844787598e-01
    z[9,6,1]  R2138     -2.3191344738006592e-01
    z[9,6,1]  R2139     -3.1613373756408691e-01
    z[9,6,1]  R2140     -5.6601864099502563e-01
    z[9,6,1]  R2141     -6.1027604341506958e-01
    z[9,6,1]  R2142     -5.3468197584152222e-01
    z[9,6,1]  R2143     -4.9905860424041748e-01
    z[9,6,1]  R2144     -2.8273808956146240e-01
    z[9,6,1]  R2145     5.5129849910736084e-01
    z[9,6,1]  R2146     -7.7998697757720947e-01
    z[9,6,1]  R2147     -5.2748590707778931e-01
    z[9,6,1]  R2148     6.0195082426071167e-01
    z[9,6,1]  R2149     5.9612119197845459e-01
    z[9,6,1]  R2150     6.3063758611679077e-01
    z[9,6,1]  R2151     7.5140869617462158e-01
    z[9,6,1]  R2152     2.4554686248302460e-01
    z[9,6,1]  R2153     3.0078712105751038e-01
    z[9,6,1]  R2154     6.2154537439346313e-01
    z[9,6,1]  R2155     4.2001038789749146e-01
    z[9,6,2]  R58       1
    z[9,6,2]  R85       -1
    z[9,6,2]  R2056     -1
    z[9,6,2]  R2057     1
    z[9,6,2]  R2066     5.0463789701461792e-01
    z[9,6,2]  R2067     2.1183522045612335e-01
    z[9,6,2]  R2068     1.3079099357128143e-01
    z[9,6,2]  R2069     2.2281858325004578e-01
    z[9,6,2]  R2070     -3.7268076092004776e-02
    z[9,6,2]  R2071     5.2665509283542633e-02
    z[9,6,2]  R2072     6.3711577653884888e-01
    z[9,6,2]  R2073     -2.4388581514358521e-03
    z[9,6,2]  R2074     -3.2720527052879333e-01
    z[9,6,2]  R2075     3.9461705088615417e-01
    z[9,6,2]  R2076     1.0636379569768906e-01
    z[9,6,2]  R2077     -3.1514503061771393e-03
    z[9,6,2]  R2078     0.0676359236240387
    z[9,6,2]  R2079     2.4678535759449005e-01
    z[9,6,2]  R2080     3.8335734605789185e-01
    z[9,6,2]  R2081     0.0618075467646122
    z[9,6,2]  R2082     2.2087465226650238e-01
    z[9,6,2]  R2083     -2.5211388710886240e-03
    z[9,6,2]  R2084     -4.1485149413347244e-02
    z[9,6,2]  R2085     2.1859072148799896e-01
    z[9,6,2]  R2086     -0.0520876981317997
    z[9,6,2]  R2087     -1.4615756273269653e-01
    z[9,6,2]  R2088     -7.7589017152786255e-01
    z[9,6,2]  R2089     4.7463127970695496e-01
    z[9,6,2]  R2090     -5.5337548255920410e-01
    z[9,6,2]  R2091     -6.3175731897354126e-01
    z[9,6,2]  R2092     5.8389431238174438e-01
    z[9,6,2]  R2093     5.9024572372436523e-01
    z[9,6,2]  R2094     -5.0399124622344971e-01
    z[9,6,2]  R2095     -1.4449145644903183e-02
    z[9,6,2]  R2096     4.6048730611801147e-01
    z[9,6,2]  R2097     6.6099238395690918e-01
    z[9,6,2]  R2098     9.0163767337799072e-02
    z[9,6,2]  R2099     -7.6733380556106567e-02
    z[9,6,2]  R2100     4.7940242290496826e-01
    z[9,6,2]  R2101     -1.9397798180580139e-01
    z[9,6,2]  R2102     3.3856812119483948e-01
    z[9,6,2]  R2103     -2.4168695509433746e-01
    z[9,6,2]  R2104     1.6360796988010406e-01
    z[9,6,2]  R2105     -1.9548648595809937e-01
    z[9,6,2]  R2106     4.8458430171012878e-01
    z[9,6,2]  R2107     2.2467520087957382e-02
    z[9,6,2]  R2108     6.4751081168651581e-02
    z[9,6,2]  R2109     -6.5491750836372375e-02
    z[9,6,2]  R2110     -3.0540412664413452e-01
    z[9,6,2]  R2111     1.4728691428899765e-02
    z[9,6,2]  R2112     2.0782814919948578e-01
    z[9,6,2]  R2113     0.5059814453125
    z[9,6,2]  R2114     3.3739551901817322e-01
    z[9,6,2]  R2115     1.1924399994313717e-02
    z[9,6,2]  R2116     -7.2222578525543213e-01
    z[9,6,2]  R2117     -2.1871227025985718e-01
    z[9,6,2]  R2118     -2.7881475165486336e-02
    z[9,6,2]  R2119     1.7660474777221680e-01
    z[9,6,2]  R2120     2.2964945435523987e-01
    z[9,6,2]  R2121     0.317281574010849
    z[9,6,2]  R2122     6.0548734664916992e-01
    z[9,6,2]  R2123     1.7457424104213715e-01
    z[9,6,2]  R2124     0.370514452457428
    z[9,6,2]  R2125     2.9978102445602417e-01
    z[9,6,2]  R2126     4.9604347348213196e-01
    z[9,6,2]  R2127     2.4289000034332275e-01
    z[9,6,2]  R2128     -6.0649398714303970e-02
    z[9,6,2]  R2129     3.9552986621856689e-01
    z[9,6,2]  R2130     2.5210650637745857e-03
    z[9,6,2]  R2131     1.1607456207275391e-01
    z[9,6,2]  R2132     -2.7868294715881348e-01
    z[9,6,2]  R2133     9.7012668848037720e-02
    z[9,6,2]  R2134     -3.6694344133138657e-02
    z[9,6,2]  R2135     5.1258850097656250e-01
    z[9,6,2]  R2136     -2.5376963615417480e-01
    z[9,6,2]  R2137     -8.5715778172016144e-02
    z[9,6,2]  R2138     -2.3895697295665741e-01
    z[9,6,2]  R2139     5.1837243139743805e-02
    z[9,6,2]  R2140     1.9625426828861237e-01
    z[9,6,2]  R2141     4.5921251177787781e-01
    z[9,6,2]  R2142     -1.5197678469121456e-02
    z[9,6,2]  R2143     3.5245051980018616e-01
    z[9,6,2]  R2144     -2.3002301156520844e-01
    z[9,6,2]  R2145     4.7003245353698730e-01
    z[9,6,2]  R2146     -7.8544422984123230e-02
    z[9,6,2]  R2147     3.7402617931365967e-01
    z[9,6,2]  R2148     6.9573557376861572e-01
    z[9,6,2]  R2149     5.0485479831695557e-01
    z[9,6,2]  R2150     2.0139449834823608e-01
    z[9,6,2]  R2151     3.9129763841629028e-02
    z[9,6,2]  R2152     8.4094721078872681e-01
    z[9,6,2]  R2153     6.8945086002349854e-01
    z[9,6,2]  R2154     4.4315326213836670e-01
    z[9,6,2]  R2155     4.9261784553527832e-01
    z[9,6,3]  R59       1
    z[9,6,3]  R86       -1
    z[9,6,3]  R2058     -1
    z[9,6,3]  R2059     1
    z[9,6,3]  R2066     -1.0172878205776215e-01
    z[9,6,3]  R2067     2.9667043685913086e-01
    z[9,6,3]  R2068     1.1939336359500885e-01
    z[9,6,3]  R2069     -2.9703578352928162e-01
    z[9,6,3]  R2070     3.4623626619577408e-02
    z[9,6,3]  R2071     -3.6751374602317810e-01
    z[9,6,3]  R2072     -3.2996940612792969e-01
    z[9,6,3]  R2073     -2.0167191326618195e-01
    z[9,6,3]  R2074     -1.8123102188110352e-01
    z[9,6,3]  R2075     -1.0467819869518280e-01
    z[9,6,3]  R2076     0.279776394367218
    z[9,6,3]  R2077     7.4402558803558350e-01
    z[9,6,3]  R2078     5.3678333759307861e-01
    z[9,6,3]  R2079     5.6045120954513550e-01
    z[9,6,3]  R2080     4.6524614095687866e-01
    z[9,6,3]  R2081     4.5251858234405518e-01
    z[9,6,3]  R2082     3.9085876941680908e-01
    z[9,6,3]  R2083     4.6487808227539062e-01
    z[9,6,3]  R2084     7.6949393749237061e-01
    z[9,6,3]  R2085     0.788844883441925
    z[9,6,3]  R2086     -8.9666461944580078e-01
    z[9,6,3]  R2087     -8.4360587596893311e-01
    z[9,6,3]  R2088     2.8829258680343628e-01
    z[9,6,3]  R2089     -6.7255079746246338e-01
    z[9,6,3]  R2090     -8.7308675050735474e-02
    z[9,6,3]  R2091     -3.8905474543571472e-01
    z[9,6,3]  R2092     1.9464203715324402e-01
    z[9,6,3]  R2093     2.5558346509933472e-01
    z[9,6,3]  R2094     -3.0210450291633606e-01
    z[9,6,3]  R2095     4.8521433025598526e-02
    z[9,6,3]  R2096     -6.6162657737731934e-01
    z[9,6,3]  R2097     -0.0974312275648117
    z[9,6,3]  R2098     -5.6235814094543457e-01
    z[9,6,3]  R2099     -8.3075851202011108e-01
    z[9,6,3]  R2100     -5.5331909656524658e-01
    z[9,6,3]  R2101     1.8006226420402527e-01
    z[9,6,3]  R2102     6.6044223308563232e-01
    z[9,6,3]  R2103     2.1907755732536316e-01
    z[9,6,3]  R2104     2.4703326821327209e-01
    z[9,6,3]  R2105     1.1764498800039291e-01
    z[9,6,3]  R2106     -0.595727801322937
    z[9,6,3]  R2107     -7.4787449836730957e-01
    z[9,6,3]  R2108     -0.720929741859436
    z[9,6,3]  R2109     2.8892710804939270e-01
    z[9,6,3]  R2110     -3.9735764265060425e-01
    z[9,6,3]  R2111     5.5459076166152954e-01
    z[9,6,3]  R2112     4.6066072583198547e-01
    z[9,6,3]  R2113     4.0360546112060547e-01
    z[9,6,3]  R2114     1.0930617898702621e-01
    z[9,6,3]  R2115     2.4287261068820953e-01
    z[9,6,3]  R2116     2.5378414988517761e-01
    z[9,6,3]  R2117     -2.3658950626850128e-01
    z[9,6,3]  R2118     9.3324109911918640e-02
    z[9,6,3]  R2119     -1.0986461490392685e-01
    z[9,6,3]  R2120     -8.5124827921390533e-02
    z[9,6,3]  R2121     2.5477004051208496e-01
    z[9,6,3]  R2122     -9.1371774673461914e-02
    z[9,6,3]  R2123     -2.2307975217700005e-02
    z[9,6,3]  R2124     -2.1528103947639465e-01
    z[9,6,3]  R2125     -1.6826815903186798e-01
    z[9,6,3]  R2126     6.4688093960285187e-02
    z[9,6,3]  R2127     4.0098321437835693e-01
    z[9,6,3]  R2128     -1.6461324691772461e-01
    z[9,6,3]  R2129     4.8995133489370346e-02
    z[9,6,3]  R2130     -1.0676565766334534e-01
    z[9,6,3]  R2131     2.9994124174118042e-01
    z[9,6,3]  R2132     2.1029375493526459e-01
    z[9,6,3]  R2133     -4.0868633985519409e-01
    z[9,6,3]  R2134     -2.4901716411113739e-01
    z[9,6,3]  R2135     4.1392478346824646e-01
    z[9,6,3]  R2136     -5.2605450153350830e-01
    z[9,6,3]  R2137     -8.9653067290782928e-02
    z[9,6,3]  R2138     -7.7100642956793308e-03
    z[9,6,3]  R2139     3.1648337841033936e-01
    z[9,6,3]  R2140     5.1185590028762817e-01
    z[9,6,3]  R2141     2.8471636772155762e-01
    z[9,6,3]  R2142     2.7658654376864433e-02
    z[9,6,3]  R2143     2.8667786717414856e-01
    z[9,6,3]  R2144     2.4606034159660339e-01
    z[9,6,3]  R2145     -3.3424678444862366e-01
    z[9,6,3]  R2146     -4.4091507792472839e-01
    z[9,6,3]  R2147     5.8085656166076660e-01
    z[9,6,3]  R2148     -2.7782931923866272e-01
    z[9,6,3]  R2149     9.5294103026390076e-02
    z[9,6,3]  R2150     -3.8310185074806213e-01
    z[9,6,3]  R2151     -1.7785681784152985e-01
    z[9,6,3]  R2152     -0.131015345454216
    z[9,6,3]  R2153     -1.9377744197845459e-01
    z[9,6,3]  R2154     4.7956906259059906e-02
    z[9,6,3]  R2155     -0.0905357152223587
    z[9,6,4]  R60       1
    z[9,6,4]  R87       -1
    z[9,6,4]  R2060     -1
    z[9,6,4]  R2061     1
    z[9,6,4]  R2066     1.2485647201538086e-01
    z[9,6,4]  R2067     1.2310385704040527e-01
    z[9,6,4]  R2068     9.4127535820007324e-02
    z[9,6,4]  R2069     -2.7633709833025932e-02
    z[9,6,4]  R2070     6.7929677665233612e-02
    z[9,6,4]  R2071     3.4966897964477539e-01
    z[9,6,4]  R2072     -2.3460452258586884e-01
    z[9,6,4]  R2073     2.3682729899883270e-01
    z[9,6,4]  R2074     1.4008422195911407e-01
    z[9,6,4]  R2075     -4.9797093868255615e-01
    z[9,6,4]  R2076     -0.0261647067964077
    z[9,6,4]  R2077     -3.1128239631652832e-01
    z[9,6,4]  R2078     -1.7917363345623016e-01
    z[9,6,4]  R2079     1.4596521854400635e-01
    z[9,6,4]  R2080     -7.2413086891174316e-02
    z[9,6,4]  R2081     -3.8450222462415695e-02
    z[9,6,4]  R2082     -1.3183638453483582e-01
    z[9,6,4]  R2083     -2.1108466386795044e-01
    z[9,6,4]  R2084     -2.5628310441970825e-01
    z[9,6,4]  R2085     -1.5942068397998810e-01
    z[9,6,4]  R2086     1.7088495194911957e-01
    z[9,6,4]  R2087     -2.4839282035827637e-01
    z[9,6,4]  R2088     -2.4773180484771729e-02
    z[9,6,4]  R2089     -1.0599285364151001e-01
    z[9,6,4]  R2090     -3.3445760607719421e-01
    z[9,6,4]  R2091     -1.4131318032741547e-01
    z[9,6,4]  R2092     -2.6053443551063538e-01
    z[9,6,4]  R2093     -7.1282930672168732e-02
    z[9,6,4]  R2094     -4.5570683479309082e-01
    z[9,6,4]  R2095     -5.4738348722457886e-01
    z[9,6,4]  R2096     -1.4750123023986816e-01
    z[9,6,4]  R2097     0.0989510715007782
    z[9,6,4]  R2098     -0.514692485332489
    z[9,6,4]  R2099     -1.6152802109718323e-01
    z[9,6,4]  R2100     -4.8854687809944153e-01
    z[9,6,4]  R2101     -1.6791987419128418e-01
    z[9,6,4]  R2102     1.0922468453645706e-01
    z[9,6,4]  R2103     -4.6905669569969177e-01
    z[9,6,4]  R2104     8.1659637391567230e-02
    z[9,6,4]  R2105     1.8564572930335999e-01
    z[9,6,4]  R2106     1.2279351055622101e-01
    z[9,6,4]  R2107     -4.2905974388122559e-01
    z[9,6,4]  R2108     -3.3084303140640259e-01
    z[9,6,4]  R2109     -3.2869505882263184e-01
    z[9,6,4]  R2110     -2.5666296482086182e-01
    z[9,6,4]  R2111     -1.7523898184299469e-01
    z[9,6,4]  R2112     -1.7954197525978088e-01
    z[9,6,4]  R2113     -1.9712452590465546e-01
    z[9,6,4]  R2114     -2.9913255944848061e-02
    z[9,6,4]  R2115     -1.8272459506988525e-01
    z[9,6,4]  R2116     -1.4301426708698273e-01
    z[9,6,4]  R2117     4.0275582671165466e-01
    z[9,6,4]  R2118     5.7950782775878906e-01
    z[9,6,4]  R2119     -1.9071938097476959e-01
    z[9,6,4]  R2120     -5.0799185037612915e-01
    z[9,6,4]  R2121     6.4860903657972813e-03
    z[9,6,4]  R2122     9.7983568906784058e-02
    z[9,6,4]  R2123     -2.1194885671138763e-01
    z[9,6,4]  R2124     -1.5737390518188477e-01
    z[9,6,4]  R2125     3.3369123935699463e-01
    z[9,6,4]  R2126     6.4953304827213287e-03
    z[9,6,4]  R2127     -1.3158570230007172e-01
    z[9,6,4]  R2128     2.0307642221450806e-01
    z[9,6,4]  R2129     -3.4298968315124512e-01
    z[9,6,4]  R2130     6.1942702531814575e-01
    z[9,6,4]  R2131     1.9328743219375610e-01
    z[9,6,4]  R2132     2.0901934802532196e-01
    z[9,6,4]  R2133     0.644838273525238
    z[9,6,4]  R2134     -3.1977668404579163e-01
    z[9,6,4]  R2135     -2.4432940781116486e-01
    z[9,6,4]  R2136     -3.4927028417587280e-01
    z[9,6,4]  R2137     -3.2429978251457214e-01
    z[9,6,4]  R2138     3.5322725772857666e-02
    z[9,6,4]  R2139     -1.1022664606571198e-01
    z[9,6,4]  R2140     6.3435077667236328e-02
    z[9,6,4]  R2141     -3.1357151269912720e-01
    z[9,6,4]  R2142     7.1364670991897583e-02
    z[9,6,4]  R2143     -3.0642592906951904e-01
    z[9,6,4]  R2144     4.2516708374023438e-01
    z[9,6,4]  R2145     -2.8752040863037109e-01
    z[9,6,4]  R2146     1.9588541984558105e-01
    z[9,6,4]  R2147     -3.3665180206298828e-01
    z[9,6,4]  R2148     -1.9591686129570007e-01
    z[9,6,4]  R2149     5.7059031724929810e-01
    z[9,6,4]  R2150     6.1753702163696289e-01
    z[9,6,4]  R2151     2.2575153410434723e-01
    z[9,6,4]  R2152     3.6807185411453247e-01
    z[9,6,4]  R2153     3.8116380572319031e-01
    z[9,6,4]  R2154     4.7033616900444031e-01
    z[9,6,4]  R2155     5.4592221975326538e-01
    z[9,6,5]  R61       1
    z[9,6,5]  R88       -1
    z[9,6,5]  R2062     -1
    z[9,6,5]  R2063     1
    z[9,6,5]  R2066     1.6958688199520111e-01
    z[9,6,5]  R2067     -1.6247332096099854e-02
    z[9,6,5]  R2068     -0.414997398853302
    z[9,6,5]  R2069     2.4028332531452179e-01
    z[9,6,5]  R2070     2.1356710791587830e-01
    z[9,6,5]  R2071     -3.4443348646163940e-01
    z[9,6,5]  R2072     3.2018628716468811e-01
    z[9,6,5]  R2073     -1.2827628850936890e-01
    z[9,6,5]  R2074     2.9745748639106750e-01
    z[9,6,5]  R2075     3.3233964443206787e-01
    z[9,6,5]  R2076     -2.3302085697650909e-01
    z[9,6,5]  R2077     -1.5327532589435577e-01
    z[9,6,5]  R2078     -1.3046006858348846e-01
    z[9,6,5]  R2079     1.1618450284004211e-01
    z[9,6,5]  R2080     -1.0945549607276917e-01
    z[9,6,5]  R2081     -3.8443204760551453e-01
    z[9,6,5]  R2082     -3.7906184792518616e-01
    z[9,6,5]  R2083     -4.3311020731925964e-01
    z[9,6,5]  R2084     3.5544145852327347e-02
    z[9,6,5]  R2085     1.2966738641262054e-01
    z[9,6,5]  R2086     1.0781476646661758e-01
    z[9,6,5]  R2087     -1.6917613148689270e-01
    z[9,6,5]  R2088     -1.6113029420375824e-01
    z[9,6,5]  R2089     -2.5836187601089478e-01
    z[9,6,5]  R2090     -2.8022146224975586e-01
    z[9,6,5]  R2091     -4.7952279448509216e-01
    z[9,6,5]  R2092     8.8292052969336510e-03
    z[9,6,5]  R2093     4.8833701014518738e-01
    z[9,6,5]  R2094     5.2868378162384033e-01
    z[9,6,5]  R2095     5.1520484685897827e-01
    z[9,6,5]  R2096     -4.6827748417854309e-01
    z[9,6,5]  R2097     -5.4940879344940186e-01
    z[9,6,5]  R2098     4.6486946940422058e-01
    z[9,6,5]  R2099     -1.9641081988811493e-01
    z[9,6,5]  R2100     1.2209662795066833e-01
    z[9,6,5]  R2101     4.7225895524024963e-01
    z[9,6,5]  R2102     1.2973374128341675e-01
    z[9,6,5]  R2103     2.1981272101402283e-01
    z[9,6,5]  R2104     -2.7609056234359741e-01
    z[9,6,5]  R2105     3.6554217338562012e-01
    z[9,6,5]  R2106     2.4138320982456207e-01
    z[9,6,5]  R2107     1.0179761797189713e-01
    z[9,6,5]  R2108     4.6536628156900406e-02
    z[9,6,5]  R2109     -1.4922022819519043e-01
    z[9,6,5]  R2110     1.5973517298698425e-01
    z[9,6,5]  R2111     -1.0053821653127670e-01
    z[9,6,5]  R2112     4.4184795022010803e-01
    z[9,6,5]  R2113     0.357094407081604
    z[9,6,5]  R2114     1.5882861614227295e-01
    z[9,6,5]  R2115     -3.1715262681245804e-02
    z[9,6,5]  R2116     -1.1922200024127960e-01
    z[9,6,5]  R2117     7.7422834932804108e-02
    z[9,6,5]  R2118     -1.2829670310020447e-01
    z[9,6,5]  R2119     -1.4491325244307518e-02
    z[9,6,5]  R2120     -2.5016161799430847e-01
    z[9,6,5]  R2121     -1.5713991224765778e-01
    z[9,6,5]  R2122     -1.3413535058498383e-01
    z[9,6,5]  R2123     -6.0129874944686890e-01
    z[9,6,5]  R2124     -0.818955659866333
    z[9,6,5]  R2125     -6.7674064636230469e-01
    z[9,6,5]  R2126     3.7047886848449707e-01
    z[9,6,5]  R2127     0.217903271317482
    z[9,6,5]  R2128     3.0730402469635010e-01
    z[9,6,5]  R2129     -1.3440935313701630e-01
    z[9,6,5]  R2130     6.3022486865520477e-02
    z[9,6,5]  R2131     3.2050319015979767e-02
    z[9,6,5]  R2132     -0.0315934419631958
    z[9,6,5]  R2133     2.2678345441818237e-01
    z[9,6,5]  R2134     2.8900709748268127e-01
    z[9,6,5]  R2135     3.4041884541511536e-01
    z[9,6,5]  R2136     -3.7923332303762436e-02
    z[9,6,5]  R2137     7.0256894826889038e-01
    z[9,6,5]  R2138     7.4205398559570312e-01
    z[9,6,5]  R2139     6.5531963109970093e-01
    z[9,6,5]  R2140     5.3755646944046021e-01
    z[9,6,5]  R2141     3.3445313572883606e-01
    z[9,6,5]  R2142     0.444111704826355
    z[9,6,5]  R2143     1.2943306565284729e-01
    z[9,6,5]  R2144     5.9656274318695068e-01
    z[9,6,5]  R2145     0.0689297541975975
    z[9,6,5]  R2146     1.5085551142692566e-01
    z[9,6,5]  R2147     2.7574095129966736e-01
    z[9,6,5]  R2148     -1.6325747966766357e-01
    z[9,6,5]  R2149     1.7915613949298859e-01
    z[9,6,5]  R2150     -1.7667318880558014e-01
    z[9,6,5]  R2151     -2.4725198745727539e-01
    z[9,6,5]  R2152     5.6163590401411057e-02
    z[9,6,5]  R2153     -4.2012929916381836e-01
    z[9,6,5]  R2154     -9.1173492372035980e-02
    z[9,6,5]  R2155     0.00541772460564971
    z[9,6,6]  R62       1
    z[9,6,6]  R89       -1
    z[9,6,6]  R2064     -1
    z[9,6,6]  R2065     1
    z[9,6,6]  R2066     -2.8365132212638855e-01
    z[9,6,6]  R2067     3.5866007208824158e-02
    z[9,6,6]  R2068     7.9198144376277924e-02
    z[9,6,6]  R2069     -1.0546236485242844e-01
    z[9,6,6]  R2070     -6.1719194054603577e-02
    z[9,6,6]  R2071     -0.192262202501297
    z[9,6,6]  R2072     -6.0034235939383507e-03
    z[9,6,6]  R2073     -3.2536983489990234e-01
    z[9,6,6]  R2074     -1.1985626071691513e-01
    z[9,6,6]  R2075     2.8894510865211487e-01
    z[9,6,6]  R2076     -0.0785093605518341
    z[9,6,6]  R2077     -1.2693412601947784e-01
    z[9,6,6]  R2078     -4.4996868818998337e-02
    z[9,6,6]  R2079     -5.2526675164699554e-02
    z[9,6,6]  R2080     -2.6417663693428040e-01
    z[9,6,6]  R2081     1.3278764486312866e-01
    z[9,6,6]  R2082     -2.2593078017234802e-01
    z[9,6,6]  R2083     -7.3157578706741333e-02
    z[9,6,6]  R2084     1.2063318490982056e-01
    z[9,6,6]  R2085     -0.0679294764995575
    z[9,6,6]  R2086     -3.0027189850807190e-01
    z[9,6,6]  R2087     2.9272112250328064e-01
    z[9,6,6]  R2088     2.3087087273597717e-01
    z[9,6,6]  R2089     1.8146304786205292e-01
    z[9,6,6]  R2090     4.5979449152946472e-01
    z[9,6,6]  R2091     3.8912755250930786e-01
    z[9,6,6]  R2092     2.6222813129425049e-01
    z[9,6,6]  R2093     -1.9972331821918488e-01
    z[9,6,6]  R2094     1.3624365627765656e-01
    z[9,6,6]  R2095     2.0632030069828033e-01
    z[9,6,6]  R2096     2.8304985165596008e-01
    z[9,6,6]  R2097     1.7174871265888214e-01
    z[9,6,6]  R2098     2.4364647269248962e-01
    z[9,6,6]  R2099     2.2965441644191742e-01
    z[9,6,6]  R2100     3.0025640130043030e-01
    z[9,6,6]  R2101     7.2059154510498047e-02
    z[9,6,6]  R2102     -7.1399368345737457e-02
    z[9,6,6]  R2103     2.9443749785423279e-01
    z[9,6,6]  R2104     1.8247225880622864e-01
    z[9,6,6]  R2105     -2.4384070932865143e-01
    z[9,6,6]  R2106     -2.9707708954811096e-01
    z[9,6,6]  R2107     3.2829120755195618e-01
    z[9,6,6]  R2108     0.302583247423172
    z[9,6,6]  R2109     4.8948684334754944e-01
    z[9,6,6]  R2110     4.5234248042106628e-02
    z[9,6,6]  R2111     9.0449877083301544e-02
    z[9,6,6]  R2112     5.1024246960878372e-02
    z[9,6,6]  R2113     6.7944198846817017e-02
    z[9,6,6]  R2114     0.000320744322380051
    z[9,6,6]  R2115     3.4085190296173096e-01
    z[9,6,6]  R2116     -1.3149733841419220e-01
    z[9,6,6]  R2117     -7.3035918176174164e-02
    z[9,6,6]  R2118     -2.5383949279785156e-01
    z[9,6,6]  R2119     -0.62140291929245
    z[9,6,6]  R2120     4.7083269804716110e-02
    z[9,6,6]  R2121     1.4273120462894440e-01
    z[9,6,6]  R2122     -3.3267743885517120e-02
    z[9,6,6]  R2123     -1.2613409757614136e-01
    z[9,6,6]  R2124     -1.1649063229560852e-01
    z[9,6,6]  R2125     -4.5722997188568115e-01
    z[9,6,6]  R2126     2.9315501451492310e-01
    z[9,6,6]  R2127     -1.5709204971790314e-01
    z[9,6,6]  R2128     9.4283193349838257e-02
    z[9,6,6]  R2129     1.1423571407794952e-01
    z[9,6,6]  R2130     5.1479238271713257e-01
    z[9,6,6]  R2131     2.6381725072860718e-01
    z[9,6,6]  R2132     3.3150288462638855e-01
    z[9,6,6]  R2133     4.1659972071647644e-01
    z[9,6,6]  R2134     8.4590339660644531e-01
    z[9,6,6]  R2135     4.6141487360000610e-01
    z[9,6,6]  R2136     3.6648562550544739e-01
    z[9,6,6]  R2137     5.7413893938064575e-01
    z[9,6,6]  R2138     3.5459730029106140e-01
    z[9,6,6]  R2139     5.5705165863037109e-01
    z[9,6,6]  R2140     -3.6742768716067076e-03
    z[9,6,6]  R2141     3.5237762331962585e-01
    z[9,6,6]  R2142     7.1442115306854248e-01
    z[9,6,6]  R2143     4.8400026559829712e-01
    z[9,6,6]  R2144     5.0567018985748291e-01
    z[9,6,6]  R2145     -7.4640981853008270e-02
    z[9,6,6]  R2146     2.6707506179809570e-01
    z[9,6,6]  R2147     1.6123822331428528e-01
    z[9,6,6]  R2148     7.6784379780292511e-02
    z[9,6,6]  R2149     -5.5147089064121246e-02
    z[9,6,6]  R2150     1.9290894269943237e-02
    z[9,6,6]  R2151     -2.6246497035026550e-01
    z[9,6,6]  R2152     2.7400395274162292e-01
    z[9,6,6]  R2153     1.8922476470470428e-01
    z[9,6,6]  R2154     -4.0201491117477417e-01
    z[9,6,6]  R2155     -0.504845380783081
    z[7,8,0]  R65       -1
    z[7,8,0]  R74       1
    z[7,8,0]  R2210     -1
    z[7,8,0]  R2211     1
    z[7,8,0]  R2224     0.56584632396698
    z[7,8,0]  R2225     3.8680833578109741e-01
    z[7,8,0]  R2226     3.1114852428436279e-01
    z[7,8,0]  R2227     2.8785562515258789e-01
    z[7,8,0]  R2228     3.1329560279846191e-01
    z[7,8,0]  R2229     6.3915866613388062e-01
    z[7,8,0]  R2230     6.1947333812713623e-01
    z[7,8,0]  R2231     -3.6312767863273621e-01
    z[7,8,0]  R2232     -1.4555731415748596e-01
    z[7,8,0]  R2233     1.5721313655376434e-01
    z[7,8,0]  R2234     -0.337566077709198
    z[7,8,0]  R2235     -4.3169227242469788e-01
    z[7,8,0]  R2236     -6.1430495977401733e-01
    z[7,8,0]  R2237     -4.2309236526489258e-01
    z[7,8,0]  R2238     -6.2170523405075073e-01
    z[7,8,0]  R2239     -6.3902544975280762e-01
    z[7,8,0]  R2240     -1.3756404817104340e-01
    z[7,8,0]  R2241     -5.1230460405349731e-01
    z[7,8,0]  R2242     -7.5247043371200562e-01
    z[7,8,0]  R2243     -4.0488809347152710e-01
    z[7,8,0]  R2244     2.0064330101013184e-01
    z[7,8,0]  R2245     -2.8924819827079773e-01
    z[7,8,0]  R2246     2.7174675464630127e-01
    z[7,8,0]  R2247     -8.5789456963539124e-02
    z[7,8,0]  R2248     -6.6463607549667358e-01
    z[7,8,0]  R2249     4.3180355429649353e-01
    z[7,8,0]  R2250     -3.8987055420875549e-01
    z[7,8,0]  R2251     0.343079149723053
    z[7,8,0]  R2252     -2.0219059288501740e-01
    z[7,8,0]  R2253     2.2271190583705902e-01
    z[7,8,0]  R2254     3.1970273703336716e-02
    z[7,8,0]  R2255     8.0609925091266632e-02
    z[7,8,0]  R2256     5.9101927280426025e-01
    z[7,8,0]  R2257     -2.2363428771495819e-01
    z[7,8,0]  R2258     -2.9740871861577034e-02
    z[7,8,0]  R2259     2.7416062355041504e-01
    z[7,8,0]  R2260     -1.0326413810253143e-01
    z[7,8,0]  R2261     -1.7664854228496552e-01
    z[7,8,0]  R2262     -5.9103786945343018e-01
    z[7,8,0]  R2263     -2.7790278196334839e-01
    z[7,8,0]  R2264     -3.9074981212615967e-01
    z[7,8,0]  R2265     1.2499614059925079e-01
    z[7,8,0]  R2266     -4.2654818296432495e-01
    z[7,8,0]  R2267     -1.2063000351190567e-01
    z[7,8,0]  R2268     -2.0915327593684196e-02
    z[7,8,0]  R2269     5.8277625590562820e-02
    z[7,8,0]  R2270     -4.8038700222969055e-01
    z[7,8,0]  R2271     -4.1091445088386536e-01
    z[7,8,0]  R2272     -6.9333279132843018e-01
    z[7,8,0]  R2273     -5.6187170743942261e-01
    z[7,8,0]  R2274     -9.8007969558238983e-02
    z[7,8,0]  R2275     4.2319771647453308e-01
    z[7,8,0]  R2276     6.0794532299041748e-01
    z[7,8,0]  R2277     6.4149641990661621e-01
    z[7,8,0]  R2278     4.8135679960250854e-01
    z[7,8,0]  R2279     6.9264853000640869e-01
    z[7,8,0]  R2280     6.2139403820037842e-01
    z[7,8,0]  R2281     8.1307172775268555e-01
    z[7,8,0]  R2282     7.7958720922470093e-01
    z[7,8,0]  R2283     5.7829689979553223e-01
    z[7,8,0]  R2284     -2.7352419495582581e-01
    z[7,8,0]  R2285     -3.5296434164047241e-01
    z[7,8,0]  R2286     -3.4004601836204529e-01
    z[7,8,0]  R2287     -3.1818976998329163e-01
    z[7,8,0]  R2288     -1.9661569595336914e-01
    z[7,8,0]  R2289     -4.8411211371421814e-01
    z[7,8,0]  R2290     -3.2321357727050781e-01
    z[7,8,0]  R2291     -4.7861676663160324e-02
    z[7,8,0]  R2292     8.1224814057350159e-02
    z[7,8,0]  R2293     -2.8232285380363464e-01
    z[7,8,0]  R2294     -2.2531481087207794e-01
    z[7,8,0]  R2295     -6.2602043151855469e-01
    z[7,8,0]  R2296     1.8498246371746063e-01
    z[7,8,0]  R2297     2.6215562224388123e-01
    z[7,8,0]  R2298     3.3195510506629944e-01
    z[7,8,0]  R2299     4.2471545934677124e-01
    z[7,8,0]  R2300     4.9482813477516174e-01
    z[7,8,0]  R2301     3.9878904819488525e-01
    z[7,8,0]  R2302     2.2056475281715393e-01
    z[7,8,0]  R2303     4.1833823919296265e-01
    z[7,8,0]  R2304     -4.0368527173995972e-01
    z[7,8,0]  R2305     -7.6156002283096313e-01
    z[7,8,0]  R2306     1.7492818832397461e-01
    z[7,8,0]  R2307     -6.5001899003982544e-01
    z[7,8,0]  R2308     1.4738659560680389e-01
    z[7,8,0]  R2309     -1.9520901143550873e-02
    z[7,8,0]  R2310     -6.6485571861267090e-01
    z[7,8,0]  R2311     3.7170723080635071e-01
    z[7,8,0]  R2312     3.1934314966201782e-01
    z[7,8,0]  R2313     8.7775045633316040e-01
    z[7,8,0]  R2314     -5.1952421665191650e-01
    z[7,8,0]  R2315     4.7968052327632904e-02
    z[7,8,0]  R2316     -4.3762215971946716e-01
    z[7,8,0]  R2317     -5.0627154111862183e-01
    z[7,8,0]  R2318     -0.8146932721138
    z[7,8,0]  R2319     4.1255185008049011e-01
    z[7,8,0]  R2320     3.0727377533912659e-01
    z[7,8,0]  R2321     5.7641327381134033e-01
    z[7,8,0]  R2322     4.7787776589393616e-01
    z[7,8,0]  R2323     1.0288880020380020e-01
    z[7,8,1]  R66       -1
    z[7,8,1]  R75       1
    z[7,8,1]  R2212     -1
    z[7,8,1]  R2213     1
    z[7,8,1]  R2224     -7.2112256288528442e-01
    z[7,8,1]  R2225     -6.0716563463211060e-01
    z[7,8,1]  R2226     -4.7086629271507263e-01
    z[7,8,1]  R2227     -4.8536252975463867e-01
    z[7,8,1]  R2228     -4.4142702221870422e-01
    z[7,8,1]  R2229     -3.5772338509559631e-02
    z[7,8,1]  R2230     -1.1704052239656448e-01
    z[7,8,1]  R2231     -8.4566110372543335e-01
    z[7,8,1]  R2232     -7.9250574111938477e-01
    z[7,8,1]  R2233     5.1438021659851074e-01
    z[7,8,1]  R2234     4.7565326094627380e-01
    z[7,8,1]  R2235     5.1896393299102783e-01
    z[7,8,1]  R2236     5.3056395053863525e-01
    z[7,8,1]  R2237     4.3915295600891113e-01
    z[7,8,1]  R2238     4.2227533459663391e-01
    z[7,8,1]  R2239     4.2494386434555054e-01
    z[7,8,1]  R2240     1.5499807894229889e-01
    z[7,8,1]  R2241     4.4935676455497742e-01
    z[7,8,1]  R2242     4.9008226394653320e-01
    z[7,8,1]  R2243     6.5573644638061523e-01
    z[7,8,1]  R2244     -7.9547427594661713e-02
    z[7,8,1]  R2245     5.8217358589172363e-01
    z[7,8,1]  R2246     4.4434210658073425e-01
    z[7,8,1]  R2247     6.3792675733566284e-01
    z[7,8,1]  R2248     2.3921658098697662e-01
    z[7,8,1]  R2249     1.3692812621593475e-01
    z[7,8,1]  R2250     -3.5033699870109558e-01
    z[7,8,1]  R2251     2.3405049741268158e-01
    z[7,8,1]  R2252     -5.1957017183303833e-01
    z[7,8,1]  R2253     5.6142288446426392e-01
    z[7,8,1]  R2254     1.9173850119113922e-01
    z[7,8,1]  R2255     -6.3599482178688049e-02
    z[7,8,1]  R2256     3.2843938469886780e-01
    z[7,8,1]  R2257     -6.9322896003723145e-01
    z[7,8,1]  R2258     3.4201240539550781e-01
    z[7,8,1]  R2259     -8.2714691758155823e-02
    z[7,8,1]  R2260     0.0487123504281044
    z[7,8,1]  R2261     1.3683560490608215e-01
    z[7,8,1]  R2262     -5.1087313890457153e-01
    z[7,8,1]  R2263     8.6742222309112549e-02
    z[7,8,1]  R2264     -0.705855131149292
    z[7,8,1]  R2265     -8.8269656896591187e-01
    z[7,8,1]  R2266     -7.9068571329116821e-01
    z[7,8,1]  R2267     -5.4778116941452026e-01
    z[7,8,1]  R2268     -6.0107243061065674e-01
    z[7,8,1]  R2269     -4.9703511595726013e-01
    z[7,8,1]  R2270     -6.2793469429016113e-01
    z[7,8,1]  R2271     -5.2283900976181030e-01
    z[7,8,1]  R2272     2.2895354032516479e-01
    z[7,8,1]  R2273     2.3920297622680664e-01
    z[7,8,1]  R2274     3.6573797464370728e-01
    z[7,8,1]  R2275     0.535042941570282
    z[7,8,1]  R2276     3.9402100443840027e-01
    z[7,8,1]  R2277     3.3955448865890503e-01
    z[7,8,1]  R2278     0.601771891117096
    z[7,8,1]  R2279     2.4936752021312714e-01
    z[7,8,1]  R2280     6.0777044296264648e-01
    z[7,8,1]  R2281     3.5975351929664612e-01
    z[7,8,1]  R2282     3.0412450432777405e-01
    z[7,8,1]  R2283     3.3013802766799927e-01
    z[7,8,1]  R2284     6.4259105920791626e-01
    z[7,8,1]  R2285     5.3079181909561157e-01
    z[7,8,1]  R2286     5.4316770285367966e-02
    z[7,8,1]  R2287     4.1214996576309204e-01
    z[7,8,1]  R2288     -2.1932059526443481e-01
    z[7,8,1]  R2289     5.2335137128829956e-01
    z[7,8,1]  R2290     5.0564658641815186e-01
    z[7,8,1]  R2291     3.3324155211448669e-01
    z[7,8,1]  R2292     3.0066317319869995e-01
    z[7,8,1]  R2293     1.8425990641117096e-01
    z[7,8,1]  R2294     -4.0147960186004639e-01
    z[7,8,1]  R2295     -6.2851530313491821e-01
    z[7,8,1]  R2296     -0.184574156999588
    z[7,8,1]  R2297     4.6243998408317566e-01
    z[7,8,1]  R2298     5.9263890981674194e-01
    z[7,8,1]  R2299     4.7417640686035156e-01
    z[7,8,1]  R2300     -3.5979515314102173e-01
    z[7,8,1]  R2301     6.3976579904556274e-01
    z[7,8,1]  R2302     3.4338611364364624e-01
    z[7,8,1]  R2303     5.0573313236236572e-01
    z[7,8,1]  R2304     0.583396852016449
    z[7,8,1]  R2305     2.2258840501308441e-01
    z[7,8,1]  R2306     -7.5896930694580078e-01
    z[7,8,1]  R2307     3.1945669651031494e-01
    z[7,8,1]  R2308     -4.3107905983924866e-01
    z[7,8,1]  R2309     -6.2369698286056519e-01
    z[7,8,1]  R2310     3.5161608457565308e-01
    z[7,8,1]  R2311     -5.3372174501419067e-01
    z[7,8,1]  R2312     0.620152473449707
    z[7,8,1]  R2313     2.5708135962486267e-01
    z[7,8,1]  R2314     3.5777881741523743e-01
    z[7,8,1]  R2315     -8.6368823051452637e-01
    z[7,8,1]  R2316     6.8246811628341675e-01
    z[7,8,1]  R2317     6.0013699531555176e-01
    z[7,8,1]  R2318     -3.8814717531204224e-01
    z[7,8,1]  R2319     -4.7604104876518250e-01
    z[7,8,1]  R2320     -4.1460853815078735e-01
    z[7,8,1]  R2321     7.2182583808898926e-01
    z[7,8,1]  R2322     4.3425035476684570e-01
    z[7,8,1]  R2323     5.8105295896530151e-01
    z[7,8,2]  R67       -1
    z[7,8,2]  R76       1
    z[7,8,2]  R2214     -1
    z[7,8,2]  R2215     1
    z[7,8,2]  R2224     1.5238769352436066e-01
    z[7,8,2]  R2225     3.8924619555473328e-01
    z[7,8,2]  R2226     1.3544920086860657e-01
    z[7,8,2]  R2227     6.2276750802993774e-01
    z[7,8,2]  R2228     -5.7281100749969482e-01
    z[7,8,2]  R2229     3.1706255674362183e-01
    z[7,8,2]  R2230     -7.3331922292709351e-01
    z[7,8,2]  R2231     2.8229501843452454e-01
    z[7,8,2]  R2232     2.0769460499286652e-01
    z[7,8,2]  R2233     -5.9686416387557983e-01
    z[7,8,2]  R2234     7.2961330413818359e-01
    z[7,8,2]  R2235     4.3422129750251770e-01
    z[7,8,2]  R2236     3.8158121705055237e-01
    z[7,8,2]  R2237     0.550506055355072
    z[7,8,2]  R2238     3.2392820715904236e-01
    z[7,8,2]  R2239     2.4571396410465240e-01
    z[7,8,2]  R2240     0.067622110247612
    z[7,8,2]  R2241     0.459238737821579
    z[7,8,2]  R2242     3.2472480088472366e-02
    z[7,8,2]  R2243     2.7156364917755127e-01
    z[7,8,2]  R2244     -1.8956419825553894e-01
    z[7,8,2]  R2245     -6.9618624448776245e-01
    z[7,8,2]  R2246     -3.2738870382308960e-01
    z[7,8,2]  R2247     -4.9386900663375854e-01
    z[7,8,2]  R2248     -5.8306747674942017e-01
    z[7,8,2]  R2249     1.5498754382133484e-01
    z[7,8,2]  R2250     -1.3371452689170837e-01
    z[7,8,2]  R2251     -3.7353730201721191e-01
    z[7,8,2]  R2252     -2.8236207365989685e-01
    z[7,8,2]  R2253     -5.8703833818435669e-01
    z[7,8,2]  R2254     -1.8302412331104279e-01
    z[7,8,2]  R2255     8.9372813701629639e-02
    z[7,8,2]  R2256     -1.2978021800518036e-01
    z[7,8,2]  R2257     6.9510176777839661e-02
    z[7,8,2]  R2258     5.3976005315780640e-01
    z[7,8,2]  R2259     -8.5104942321777344e-01
    z[7,8,2]  R2260     -7.3560386896133423e-01
    z[7,8,2]  R2261     -4.1516625881195068e-01
    z[7,8,2]  R2262     -2.0120188593864441e-01
    z[7,8,2]  R2263     -4.5631888508796692e-01
    z[7,8,2]  R2264     -3.6354590207338333e-02
    z[7,8,2]  R2265     -2.7984252572059631e-01
    z[7,8,2]  R2266     -0.00863682571798563
    z[7,8,2]  R2267     -2.5398376584053040e-01
    z[7,8,2]  R2268     -4.2689961194992065e-01
    z[7,8,2]  R2269     3.2003694772720337e-01
    z[7,8,2]  R2270     1.3535057008266449e-01
    z[7,8,2]  R2271     -3.9969551563262939e-01
    z[7,8,2]  R2272     1.6448435187339783e-01
    z[7,8,2]  R2273     1.7573493719100952e-01
    z[7,8,2]  R2274     4.6703219413757324e-01
    z[7,8,2]  R2275     2.1635392308235168e-01
    z[7,8,2]  R2276     1.6247582435607910e-01
    z[7,8,2]  R2277     1.7877030372619629e-01
    z[7,8,2]  R2278     -6.9348454475402832e-02
    z[7,8,2]  R2279     2.6478347182273865e-01
    z[7,8,2]  R2280     4.5628994703292847e-02
    z[7,8,2]  R2281     1.8481417000293732e-01
    z[7,8,2]  R2282     4.2502439022064209e-01
    z[7,8,2]  R2283     8.1140503287315369e-02
    z[7,8,2]  R2284     5.0389105081558228e-01
    z[7,8,2]  R2285     3.9021718502044678e-01
    z[7,8,2]  R2286     7.0239871740341187e-01
    z[7,8,2]  R2287     3.2019799947738647e-01
    z[7,8,2]  R2288     -6.0397596098482609e-03
    z[7,8,2]  R2289     -4.7329090535640717e-02
    z[7,8,2]  R2290     -1.8379144370555878e-02
    z[7,8,2]  R2291     5.7520174980163574e-01
    z[7,8,2]  R2292     0.642295241355896
    z[7,8,2]  R2293     3.9481487870216370e-01
    z[7,8,2]  R2294     4.0127193927764893e-01
    z[7,8,2]  R2295     -2.4796979129314423e-01
    z[7,8,2]  R2296     6.5727323293685913e-02
    z[7,8,2]  R2297     -6.7530685663223267e-01
    z[7,8,2]  R2298     -5.8397132158279419e-01
    z[7,8,2]  R2299     -5.4952836036682129e-01
    z[7,8,2]  R2300     -3.1262585520744324e-01
    z[7,8,2]  R2301     -5.2683001756668091e-01
    z[7,8,2]  R2302     -7.5382733345031738e-01
    z[7,8,2]  R2303     -7.3114919662475586e-01
    z[7,8,2]  R2304     5.2697986364364624e-01
    z[7,8,2]  R2305     3.8458457589149475e-01
    z[7,8,2]  R2306     4.0947649627923965e-02
    z[7,8,2]  R2307     2.8311860561370850e-01
    z[7,8,2]  R2308     3.5711872577667236e-01
    z[7,8,2]  R2309     -5.0671335309743881e-02
    z[7,8,2]  R2310     -1.1463362723588943e-01
    z[7,8,2]  R2311     -7.8487031161785126e-02
    z[7,8,2]  R2312     -2.1065986156463623e-01
    z[7,8,2]  R2313     -4.0730472654104233e-02
    z[7,8,2]  R2314     6.3772797584533691e-01
    z[7,8,2]  R2315     7.4824534356594086e-02
    z[7,8,2]  R2316     1.8205539882183075e-01
    z[7,8,2]  R2317     -1.8323624506592751e-02
    z[7,8,2]  R2318     2.4640716612339020e-01
    z[7,8,2]  R2319     -1.8924209475517273e-01
    z[7,8,2]  R2320     -4.0736806392669678e-01
    z[7,8,2]  R2321     1.0924704372882843e-01
    z[7,8,2]  R2322     -2.3694667220115662e-01
    z[7,8,2]  R2323     -4.2501190304756165e-01
    z[7,8,3]  R68       -1
    z[7,8,3]  R77       1
    z[7,8,3]  R2216     -1
    z[7,8,3]  R2217     1
    z[7,8,3]  R2224     -1.9879573583602905e-01
    z[7,8,3]  R2225     -1.2019961327314377e-01
    z[7,8,3]  R2226     -2.1669751405715942e-01
    z[7,8,3]  R2227     -1.7680196464061737e-01
    z[7,8,3]  R2228     -1.1830183863639832e-01
    z[7,8,3]  R2229     -2.1421962976455688e-01
    z[7,8,3]  R2230     -1.0761692374944687e-01
    z[7,8,3]  R2231     1.9323322176933289e-01
    z[7,8,3]  R2232     2.0005673170089722e-01
    z[7,8,3]  R2233     3.9944455027580261e-01
    z[7,8,3]  R2234     2.5041863322257996e-01
    z[7,8,3]  R2235     2.5284075736999512e-01
    z[7,8,3]  R2236     7.8956015408039093e-02
    z[7,8,3]  R2237     3.5475313663482666e-01
    z[7,8,3]  R2238     4.1027444601058960e-01
    z[7,8,3]  R2239     3.6534574627876282e-01
    z[7,8,3]  R2240     -9.1493481397628784e-01
    z[7,8,3]  R2241     2.1414358913898468e-01
    z[7,8,3]  R2242     2.4445576965808868e-01
    z[7,8,3]  R2243     3.4286347031593323e-01
    z[7,8,3]  R2244     -6.6909611225128174e-01
    z[7,8,3]  R2245     -8.4517627954483032e-02
    z[7,8,3]  R2246     -5.9091800451278687e-01
    z[7,8,3]  R2247     -3.9055764675140381e-01
    z[7,8,3]  R2248     -1.2892629206180573e-01
    z[7,8,3]  R2249     -4.0681746602058411e-01
    z[7,8,3]  R2250     -7.3988062143325806e-01
    z[7,8,3]  R2251     -7.0957213640213013e-01
    z[7,8,3]  R2252     -5.8777654170989990e-01
    z[7,8,3]  R2253     1.9040267169475555e-01
    z[7,8,3]  R2254     -8.9693957567214966e-01
    z[7,8,3]  R2255     -9.2326998710632324e-01
    z[7,8,3]  R2256     -5.1264625042676926e-02
    z[7,8,3]  R2257     -2.4642907083034515e-01
    z[7,8,3]  R2258     -5.7452076673507690e-01
    z[7,8,3]  R2259     -3.1194803118705750e-01
    z[7,8,3]  R2260     4.3479931354522705e-01
    z[7,8,3]  R2261     3.0651673674583435e-01
    z[7,8,3]  R2262     -4.3567517399787903e-01
    z[7,8,3]  R2263     4.9107018113136292e-01
    z[7,8,3]  R2264     -2.4049256742000580e-01
    z[7,8,3]  R2265     -1.8227960169315338e-01
    z[7,8,3]  R2266     -1.8367478251457214e-01
    z[7,8,3]  R2267     -2.1280041337013245e-01
    z[7,8,3]  R2268     -2.0879431068897247e-01
    z[7,8,3]  R2269     -2.2890414297580719e-01
    z[7,8,3]  R2270     -1.2697722017765045e-01
    z[7,8,3]  R2271     -1.5663371980190277e-01
    z[7,8,3]  R2272     1.1656701564788818e-01
    z[7,8,3]  R2273     1.3841967284679413e-01
    z[7,8,3]  R2274     -8.7010592222213745e-02
    z[7,8,3]  R2275     6.7712718248367310e-01
    z[7,8,3]  R2276     6.4832371473312378e-01
    z[7,8,3]  R2277     6.1362695693969727e-01
    z[7,8,3]  R2278     4.8928019404411316e-01
    z[7,8,3]  R2279     6.0580068826675415e-01
    z[7,8,3]  R2280     2.9120427370071411e-01
    z[7,8,3]  R2281     3.3687943220138550e-01
    z[7,8,3]  R2282     3.2745805382728577e-01
    z[7,8,3]  R2283     5.7278507947921753e-01
    z[7,8,3]  R2284     -4.6318760514259338e-01
    z[7,8,3]  R2285     3.5891026258468628e-01
    z[7,8,3]  R2286     -4.9805739521980286e-01
    z[7,8,3]  R2287     -3.4513863921165466e-01
    z[7,8,3]  R2288     -7.7164888381958008e-01
    z[7,8,3]  R2289     2.2541718184947968e-01
    z[7,8,3]  R2290     -2.8522717952728271e-01
    z[7,8,3]  R2291     8.7847806513309479e-02
    z[7,8,3]  R2292     -2.8901886940002441e-01
    z[7,8,3]  R2293     5.1158016920089722e-01
    z[7,8,3]  R2294     -2.6556468009948730e-01
    z[7,8,3]  R2295     -1.1575835943222046e-01
    z[7,8,3]  R2296     -7.4994575977325439e-01
    z[7,8,3]  R2297     -1.3088975846767426e-01
    z[7,8,3]  R2298     -1.5370818972587585e-01
    z[7,8,3]  R2299     -0.136946439743042
    z[7,8,3]  R2300     -3.2947468757629395e-01
    z[7,8,3]  R2301     -2.2416210174560547e-01
    z[7,8,3]  R2302     -1.1424796283245087e-01
    z[7,8,3]  R2303     3.1601503491401672e-02
    z[7,8,3]  R2304     1.7844025790691376e-01
    z[7,8,3]  R2305     9.4157420098781586e-02
    z[7,8,3]  R2306     -4.8243671655654907e-01
    z[7,8,3]  R2307     1.7940548062324524e-01
    z[7,8,3]  R2308     -7.8748118877410889e-01
    z[7,8,3]  R2309     -1.9369816780090332e-01
    z[7,8,3]  R2310     4.6675175428390503e-01
    z[7,8,3]  R2311     -2.1306182444095612e-01
    z[7,8,3]  R2312     6.8165791034698486e-01
    z[7,8,3]  R2313     -2.6813134551048279e-01
    z[7,8,3]  R2314     -9.8371699452400208e-02
    z[7,8,3]  R2315     -2.9901558160781860e-01
    z[7,8,3]  R2316     -6.8399451673030853e-02
    z[7,8,3]  R2317     -1.7771961167454720e-02
    z[7,8,3]  R2318     -3.3625584840774536e-01
    z[7,8,3]  R2319     -3.8571050763130188e-01
    z[7,8,3]  R2320     -3.6949291825294495e-01
    z[7,8,3]  R2321     2.4150632321834564e-01
    z[7,8,3]  R2322     5.7673478126525879e-01
    z[7,8,3]  R2323     6.2681674957275391e-01
    z[7,8,4]  R69       -1
    z[7,8,4]  R78       1
    z[7,8,4]  R2218     -1
    z[7,8,4]  R2219     1
    z[7,8,4]  R2224     2.8136044740676880e-01
    z[7,8,4]  R2225     1.3414669036865234e-01
    z[7,8,4]  R2226     6.0929656028747559e-01
    z[7,8,4]  R2227     4.6493580937385559e-01
    z[7,8,4]  R2228     5.9276384115219116e-01
    z[7,8,4]  R2229     5.8546477556228638e-01
    z[7,8,4]  R2230     -9.6167489886283875e-02
    z[7,8,4]  R2231     -1.0068996995687485e-01
    z[7,8,4]  R2232     -1.6605491936206818e-01
    z[7,8,4]  R2233     3.6492672562599182e-01
    z[7,8,4]  R2234     -2.4456101655960083e-01
    z[7,8,4]  R2235     -2.1529795229434967e-01
    z[7,8,4]  R2236     -2.6367521286010742e-01
    z[7,8,4]  R2237     2.7901515364646912e-01
    z[7,8,4]  R2238     2.8647467494010925e-01
    z[7,8,4]  R2239     9.8640955984592438e-02
    z[7,8,4]  R2240     -3.3423733711242676e-01
    z[7,8,4]  R2241     5.5307867005467415e-03
    z[7,8,4]  R2242     -2.2386403381824493e-01
    z[7,8,4]  R2243     -3.8595151901245117e-01
    z[7,8,4]  R2244     -1.9395154714584351e-01
    z[7,8,4]  R2245     -1.3204665482044220e-01
    z[7,8,4]  R2246     4.1910582780838013e-01
    z[7,8,4]  R2247     1.9031862914562225e-01
    z[7,8,4]  R2248     -2.3103572428226471e-01
    z[7,8,4]  R2249     7.7144846320152283e-02
    z[7,8,4]  R2250     0.0887860581278801
    z[7,8,4]  R2251     -3.5474222898483276e-01
    z[7,8,4]  R2252     -4.5493033528327942e-01
    z[7,8,4]  R2253     4.9308523535728455e-02
    z[7,8,4]  R2254     3.2211273908615112e-01
    z[7,8,4]  R2255     2.5527609977871180e-03
    z[7,8,4]  R2256     0.415828675031662
    z[7,8,4]  R2257     -2.0532572269439697e-01
    z[7,8,4]  R2258     1.3875405490398407e-01
    z[7,8,4]  R2259     -3.2913282513618469e-02
    z[7,8,4]  R2260     4.0149144828319550e-02
    z[7,8,4]  R2261     2.2124961018562317e-01
    z[7,8,4]  R2262     -5.4027330130338669e-02
    z[7,8,4]  R2263     3.3655592799186707e-01
    z[7,8,4]  R2264     4.7157740592956543e-01
    z[7,8,4]  R2265     -5.2349831908941269e-02
    z[7,8,4]  R2266     -1.3976477086544037e-01
    z[7,8,4]  R2267     2.9161083698272705e-01
    z[7,8,4]  R2268     -3.2475203275680542e-02
    z[7,8,4]  R2269     0.745089054107666
    z[7,8,4]  R2270     -7.4821531772613525e-02
    z[7,8,4]  R2271     -1.2268606573343277e-01
    z[7,8,4]  R2272     2.7033528685569763e-01
    z[7,8,4]  R2273     3.1954219937324524e-01
    z[7,8,4]  R2274     -4.0138435363769531e-01
    z[7,8,4]  R2275     -0.0943312868475914
    z[7,8,4]  R2276     1.3736635446548462e-01
    z[7,8,4]  R2277     -1.0122365504503250e-01
    z[7,8,4]  R2278     -3.8699424266815186e-01
    z[7,8,4]  R2279     -5.2707046270370483e-02
    z[7,8,4]  R2280     -3.8135918974876404e-01
    z[7,8,4]  R2281     -1.6239321231842041e-01
    z[7,8,4]  R2282     -3.1952168792486191e-02
    z[7,8,4]  R2283     -2.7643764019012451e-01
    z[7,8,4]  R2284     7.9723246395587921e-02
    z[7,8,4]  R2285     3.1396403908729553e-02
    z[7,8,4]  R2286     1.6028310358524323e-01
    z[7,8,4]  R2287     -3.3956998586654663e-01
    z[7,8,4]  R2288     -4.7288507223129272e-01
    z[7,8,4]  R2289     -6.5615504980087280e-01
    z[7,8,4]  R2290     -6.0443294048309326e-01
    z[7,8,4]  R2291     5.7951617240905762e-01
    z[7,8,4]  R2292     8.9810833334922791e-02
    z[7,8,4]  R2293     1.0060887038707733e-01
    z[7,8,4]  R2294     4.5800673961639404e-01
    z[7,8,4]  R2295     -2.1552371978759766e-01
    z[7,8,4]  R2296     3.7567341327667236e-01
    z[7,8,4]  R2297     2.7588644623756409e-01
    z[7,8,4]  R2298     1.0778700560331345e-01
    z[7,8,4]  R2299     8.4838949143886566e-02
    z[7,8,4]  R2300     -6.3639283180236816e-02
    z[7,8,4]  R2301     1.5019574761390686e-01
    z[7,8,4]  R2302     9.2797234654426575e-02
    z[7,8,4]  R2303     -5.2797406911849976e-02
    z[7,8,4]  R2304     3.9403277635574341e-01
    z[7,8,4]  R2305     -3.3162882924079895e-01
    z[7,8,4]  R2306     -6.2922318466007710e-03
    z[7,8,4]  R2307     -1.2952215969562531e-01
    z[7,8,4]  R2308     4.7503627836704254e-02
    z[7,8,4]  R2309     3.4745806455612183e-01
    z[7,8,4]  R2310     -8.5709132254123688e-02
    z[7,8,4]  R2311     3.7121790647506714e-01
    z[7,8,4]  R2312     7.4765356257557869e-03
    z[7,8,4]  R2313     2.4638114869594574e-01
    z[7,8,4]  R2314     -1.0565236210823059e-01
    z[7,8,4]  R2315     2.7540171146392822e-01
    z[7,8,4]  R2316     -5.3796207904815674e-01
    z[7,8,4]  R2317     -8.4774866700172424e-02
    z[7,8,4]  R2318     -1.0620661079883575e-01
    z[7,8,4]  R2319     3.7548542022705078e-01
    z[7,8,4]  R2320     -1.1374235898256302e-01
    z[7,8,4]  R2321     6.3498369418084621e-03
    z[7,8,4]  R2322     -6.4141921699047089e-02
    z[7,8,4]  R2323     -1.3149622082710266e-01
    z[7,8,5]  R70       -1
    z[7,8,5]  R79       1
    z[7,8,5]  R2220     -1
    z[7,8,5]  R2221     1
    z[7,8,5]  R2224     1.2903597950935364e-01
    z[7,8,5]  R2225     5.0718921422958374e-01
    z[7,8,5]  R2226     4.9037474393844604e-01
    z[7,8,5]  R2227     -1.2133947759866714e-01
    z[7,8,5]  R2228     -4.3760299682617188e-02
    z[7,8,5]  R2229     1.1665125936269760e-01
    z[7,8,5]  R2230     -2.1996637806296349e-02
    z[7,8,5]  R2231     1.4449493587017059e-01
    z[7,8,5]  R2232     -1.3534571230411530e-01
    z[7,8,5]  R2233     1.2469103187322617e-01
    z[7,8,5]  R2234     4.2589064687490463e-02
    z[7,8,5]  R2235     4.6388205885887146e-01
    z[7,8,5]  R2236     6.5515274181962013e-03
    z[7,8,5]  R2237     -3.1412345170974731e-01
    z[7,8,5]  R2238     -1.1265028268098831e-01
    z[7,8,5]  R2239     1.6476555168628693e-01
    z[7,8,5]  R2240     -3.8684133440256119e-02
    z[7,8,5]  R2241     -0.51753830909729
    z[7,8,5]  R2242     -2.8312796354293823e-01
    z[7,8,5]  R2243     -7.5021870434284210e-02
    z[7,8,5]  R2244     -0.572472095489502
    z[7,8,5]  R2245     -2.5666135549545288e-01
    z[7,8,5]  R2246     -2.5014990568161011e-01
    z[7,8,5]  R2247     -3.4819102287292480e-01
    z[7,8,5]  R2248     -3.0022063851356506e-01
    z[7,8,5]  R2249     -7.7347451448440552e-01
    z[7,8,5]  R2250     -1.6917371749877930e-01
    z[7,8,5]  R2251     2.4217553436756134e-01
    z[7,8,5]  R2252     -5.9445660561323166e-02
    z[7,8,5]  R2253     -4.9349084496498108e-01
    z[7,8,5]  R2254     1.0130524635314941e-01
    z[7,8,5]  R2255     -3.2140168547630310e-01
    z[7,8,5]  R2256     -5.9102743864059448e-01
    z[7,8,5]  R2257     -5.9029066562652588e-01
    z[7,8,5]  R2258     4.5784175395965576e-01
    z[7,8,5]  R2259     -1.1757113784551620e-01
    z[7,8,5]  R2260     -4.3659603595733643e-01
    z[7,8,5]  R2261     -0.759149968624115
    z[7,8,5]  R2262     -3.9859518408775330e-02
    z[7,8,5]  R2263     -5.7088422775268555e-01
    z[7,8,5]  R2264     2.5104042887687683e-01
    z[7,8,5]  R2265     -8.7841480970382690e-02
    z[7,8,5]  R2266     -1.9002674520015717e-01
    z[7,8,5]  R2267     3.6660602688789368e-01
    z[7,8,5]  R2268     3.5867232084274292e-01
    z[7,8,5]  R2269     -1.9685764610767365e-01
    z[7,8,5]  R2270     -2.3646345734596252e-01
    z[7,8,5]  R2271     4.7210484743118286e-01
    z[7,8,5]  R2272     3.0779346823692322e-01
    z[7,8,5]  R2273     1.9148269295692444e-01
    z[7,8,5]  R2274     -5.3942728042602539e-01
    z[7,8,5]  R2275     -2.4274408817291260e-02
    z[7,8,5]  R2276     -6.3160099089145660e-02
    z[7,8,5]  R2277     1.4341041445732117e-01
    z[7,8,5]  R2278     -3.2551422715187073e-02
    z[7,8,5]  R2279     1.0987445712089539e-01
    z[7,8,5]  R2280     -9.7465276718139648e-02
    z[7,8,5]  R2281     -1.5779529511928558e-01
    z[7,8,5]  R2282     -7.3694236576557159e-02
    z[7,8,5]  R2283     -3.8061082363128662e-01
    z[7,8,5]  R2284     1.9135256111621857e-01
    z[7,8,5]  R2285     -3.3060204982757568e-01
    z[7,8,5]  R2286     -3.1885802745819092e-01
    z[7,8,5]  R2287     5.9416841715574265e-02
    z[7,8,5]  R2288     3.0407893657684326e-01
    z[7,8,5]  R2289     8.8839247822761536e-02
    z[7,8,5]  R2290     3.5376599431037903e-01
    z[7,8,5]  R2291     -3.2122090458869934e-01
    z[7,8,5]  R2292     -4.5879325270652771e-01
    z[7,8,5]  R2293     -6.0984903573989868e-01
    z[7,8,5]  R2294     -2.6245990395545959e-01
    z[7,8,5]  R2295     0.254169762134552
    z[7,8,5]  R2296     4.5750427246093750e-01
    z[7,8,5]  R2297     -4.0662378072738647e-01
    z[7,8,5]  R2298     -3.9159911870956421e-01
    z[7,8,5]  R2299     -4.9317845702171326e-01
    z[7,8,5]  R2300     2.2540882229804993e-01
    z[7,8,5]  R2301     -2.3525390028953552e-01
    z[7,8,5]  R2302     -4.6838164329528809e-01
    z[7,8,5]  R2303     -1.1270120739936829e-01
    z[7,8,5]  R2304     -1.2917117774486542e-01
    z[7,8,5]  R2305     -2.8374055027961731e-01
    z[7,8,5]  R2306     -2.3278048634529114e-01
    z[7,8,5]  R2307     -1.2248796969652176e-01
    z[7,8,5]  R2308     -1.9105631113052368e-01
    z[7,8,5]  R2309     1.1361550539731979e-02
    z[7,8,5]  R2310     0.294919490814209
    z[7,8,5]  R2311     3.6078030243515968e-03
    z[7,8,5]  R2312     -5.7003190740942955e-03
    z[7,8,5]  R2313     1.1956840753555298e-01
    z[7,8,5]  R2314     -4.0403288602828979e-01
    z[7,8,5]  R2315     -2.6048877835273743e-01
    z[7,8,5]  R2316     1.2340676039457321e-01
    z[7,8,5]  R2317     5.8245950937271118e-01
    z[7,8,5]  R2318     2.0201133564114571e-02
    z[7,8,5]  R2319     2.8838792443275452e-01
    z[7,8,5]  R2320     4.0955805778503418e-01
    z[7,8,5]  R2321     -1.9069863855838776e-01
    z[7,8,5]  R2322     -1.3184095919132233e-01
    z[7,8,5]  R2323     1.8675215542316437e-02
    z[7,8,6]  R71       -1
    z[7,8,6]  R80       1
    z[7,8,6]  R2222     -1
    z[7,8,6]  R2223     1
    z[7,8,6]  R2224     -3.5278104245662689e-02
    z[7,8,6]  R2225     2.0132671296596527e-01
    z[7,8,6]  R2226     -0.0667652115225792
    z[7,8,6]  R2227     1.7769466340541840e-01
    z[7,8,6]  R2228     1.0768654197454453e-01
    z[7,8,6]  R2229     2.9563727974891663e-01
    z[7,8,6]  R2230     2.0852752029895782e-01
    z[7,8,6]  R2231     -7.0347420871257782e-02
    z[7,8,6]  R2232     4.7084507346153259e-01
    z[7,8,6]  R2233     2.1488350629806519e-01
    z[7,8,6]  R2234     5.5983554571866989e-02
    z[7,8,6]  R2235     -1.7407430708408356e-01
    z[7,8,6]  R2236     -3.4601387381553650e-01
    z[7,8,6]  R2237     -1.5069159865379333e-01
    z[7,8,6]  R2238     -2.5914004445075989e-01
    z[7,8,6]  R2239     -4.2466285824775696e-01
    z[7,8,6]  R2240     -4.6498034149408340e-02
    z[7,8,6]  R2241     -1.0482472181320190e-01
    z[7,8,6]  R2242     -5.0177793949842453e-02
    z[7,8,6]  R2243     2.4532899260520935e-01
    z[7,8,6]  R2244     0.323185533285141
    z[7,8,6]  R2245     -4.7742825001478195e-02
    z[7,8,6]  R2246     -1.8472076952457428e-01
    z[7,8,6]  R2247     -1.7829626798629761e-01
    z[7,8,6]  R2248     3.0573625117540359e-02
    z[7,8,6]  R2249     -3.2567363232374191e-02
    z[7,8,6]  R2250     -3.5136780142784119e-01
    z[7,8,6]  R2251     1.8085611518472433e-03
    z[7,8,6]  R2252     -2.3121614754199982e-01
    z[7,8,6]  R2253     -9.1499179601669312e-02
    z[7,8,6]  R2254     1.0097808390855789e-01
    z[7,8,6]  R2255     -1.6042618453502655e-01
    z[7,8,6]  R2256     3.3555500209331512e-02
    z[7,8,6]  R2257     -1.1515476554632187e-01
    z[7,8,6]  R2258     1.7848303914070129e-01
    z[7,8,6]  R2259     -2.8546676039695740e-01
    z[7,8,6]  R2260     -2.5411024689674377e-01
    z[7,8,6]  R2261     2.4185892939567566e-01
    z[7,8,6]  R2262     3.9354795217514038e-01
    z[7,8,6]  R2263     -1.6337199509143829e-01
    z[7,8,6]  R2264     0.0672181099653244
    z[7,8,6]  R2265     -2.8849324584007263e-01
    z[7,8,6]  R2266     -3.2158580422401428e-01
    z[7,8,6]  R2267     -5.9678763151168823e-01
    z[7,8,6]  R2268     -5.3172874450683594e-01
    z[7,8,6]  R2269     -2.8782900422811508e-02
    z[7,8,6]  R2270     5.2817636728286743e-01
    z[7,8,6]  R2271     -3.6818888783454895e-01
    z[7,8,6]  R2272     0.508339524269104
    z[7,8,6]  R2273     -6.6201704740524292e-01
    z[7,8,6]  R2274     -4.2290541529655457e-01
    z[7,8,6]  R2275     -1.4083603024482727e-01
    z[7,8,6]  R2276     7.4627533555030823e-02
    z[7,8,6]  R2277     1.8405258655548096e-01
    z[7,8,6]  R2278     1.0553563386201859e-01
    z[7,8,6]  R2279     -7.8094065189361572e-02
    z[7,8,6]  R2280     5.1657155156135559e-02
    z[7,8,6]  R2281     1.0284334421157837e-01
    z[7,8,6]  R2282     -7.3660321533679962e-02
    z[7,8,6]  R2283     -2.5152249261736870e-02
    z[7,8,6]  R2284     -2.8996374458074570e-02
    z[7,8,6]  R2285     -4.4978532195091248e-01
    z[7,8,6]  R2286     -1.1239292472600937e-01
    z[7,8,6]  R2287     6.2321919202804565e-01
    z[7,8,6]  R2288     4.0963903069496155e-02
    z[7,8,6]  R2289     0.0159404706209898
    z[7,8,6]  R2290     -2.6013967394828796e-01
    z[7,8,6]  R2291     3.3024734258651733e-01
    z[7,8,6]  R2292     4.3401810526847839e-01
    z[7,8,6]  R2293     2.9446718096733093e-01
    z[7,8,6]  R2294     -5.2711308002471924e-01
    z[7,8,6]  R2295     1.6469725966453552e-01
    z[7,8,6]  R2296     -1.2055918574333191e-01
    z[7,8,6]  R2297     -5.2877198904752731e-02
    z[7,8,6]  R2298     9.4701521098613739e-02
    z[7,8,6]  R2299     -1.5367236733436584e-01
    z[7,8,6]  R2300     0.603775680065155
    z[7,8,6]  R2301     -1.6113768517971039e-01
    z[7,8,6]  R2302     1.5535804629325867e-01
    z[7,8,6]  R2303     -1.3475976884365082e-01
    z[7,8,6]  R2304     -1.2325000762939453e-01
    z[7,8,6]  R2305     -1.5239277482032776e-01
    z[7,8,6]  R2306     -3.2360067963600159e-01
    z[7,8,6]  R2307     -5.7558751106262207e-01
    z[7,8,6]  R2308     7.7643796801567078e-02
    z[7,8,6]  R2309     -6.7058050632476807e-01
    z[7,8,6]  R2310     3.3016854524612427e-01
    z[7,8,6]  R2311     6.2257814407348633e-01
    z[7,8,6]  R2312     0.0656309723854065
    z[7,8,6]  R2313     1.2210515886545181e-01
    z[7,8,6]  R2314     -1.0634802281856537e-01
    z[7,8,6]  R2315     -1.1415829509496689e-01
    z[7,8,6]  R2316     1.6399851068854332e-02
    z[7,8,6]  R2317     1.9085927307605743e-01
    z[7,8,6]  R2318     1.2006171047687531e-02
    z[7,8,6]  R2319     4.4095784425735474e-01
    z[7,8,6]  R2320     0.500533401966095
    z[7,8,6]  R2321     -2.0012147724628448e-01
    z[7,8,6]  R2322     -4.1568791866302490e-01
    z[7,8,6]  R2323     -2.4620507657527924e-01
    z[8,7,0]  R65       1
    z[8,7,0]  R74       -1
    z[8,7,0]  R2324     -1
    z[8,7,0]  R2325     1
    z[8,7,0]  R2338     -3.9074981212615967e-01
    z[8,7,0]  R2339     1.2499614059925079e-01
    z[8,7,0]  R2340     -4.2654818296432495e-01
    z[8,7,0]  R2341     -1.2063000351190567e-01
    z[8,7,0]  R2342     -2.0915327593684196e-02
    z[8,7,0]  R2343     5.8277625590562820e-02
    z[8,7,0]  R2344     -4.8038700222969055e-01
    z[8,7,0]  R2345     -4.1091445088386536e-01
    z[8,7,0]  R2346     -6.9333279132843018e-01
    z[8,7,0]  R2347     -5.6187170743942261e-01
    z[8,7,0]  R2348     -9.8007969558238983e-02
    z[8,7,0]  R2349     4.2319771647453308e-01
    z[8,7,0]  R2350     6.0794532299041748e-01
    z[8,7,0]  R2351     6.4149641990661621e-01
    z[8,7,0]  R2352     4.8135679960250854e-01
    z[8,7,0]  R2353     6.9264853000640869e-01
    z[8,7,0]  R2354     6.2139403820037842e-01
    z[8,7,0]  R2355     8.1307172775268555e-01
    z[8,7,0]  R2356     7.7958720922470093e-01
    z[8,7,0]  R2357     5.7829689979553223e-01
    z[8,7,0]  R2358     -2.7352419495582581e-01
    z[8,7,0]  R2359     -3.5296434164047241e-01
    z[8,7,0]  R2360     -3.4004601836204529e-01
    z[8,7,0]  R2361     -3.1818976998329163e-01
    z[8,7,0]  R2362     -1.9661569595336914e-01
    z[8,7,0]  R2363     -4.8411211371421814e-01
    z[8,7,0]  R2364     -3.2321357727050781e-01
    z[8,7,0]  R2365     -4.7861676663160324e-02
    z[8,7,0]  R2366     8.1224814057350159e-02
    z[8,7,0]  R2367     -2.8232285380363464e-01
    z[8,7,0]  R2368     -2.2531481087207794e-01
    z[8,7,0]  R2369     -6.2602043151855469e-01
    z[8,7,0]  R2370     1.8498246371746063e-01
    z[8,7,0]  R2371     2.6215562224388123e-01
    z[8,7,0]  R2372     3.3195510506629944e-01
    z[8,7,0]  R2373     4.2471545934677124e-01
    z[8,7,0]  R2374     4.9482813477516174e-01
    z[8,7,0]  R2375     3.9878904819488525e-01
    z[8,7,0]  R2376     2.2056475281715393e-01
    z[8,7,0]  R2377     4.1833823919296265e-01
    z[8,7,0]  R2378     -4.0368527173995972e-01
    z[8,7,0]  R2379     -7.6156002283096313e-01
    z[8,7,0]  R2380     1.7492818832397461e-01
    z[8,7,0]  R2381     -6.5001899003982544e-01
    z[8,7,0]  R2382     1.4738659560680389e-01
    z[8,7,0]  R2383     -1.9520901143550873e-02
    z[8,7,0]  R2384     -6.6485571861267090e-01
    z[8,7,0]  R2385     3.7170723080635071e-01
    z[8,7,0]  R2386     3.1934314966201782e-01
    z[8,7,0]  R2387     8.7775045633316040e-01
    z[8,7,0]  R2388     -5.1952421665191650e-01
    z[8,7,0]  R2389     4.7968052327632904e-02
    z[8,7,0]  R2390     -4.3762215971946716e-01
    z[8,7,0]  R2391     -5.0627154111862183e-01
    z[8,7,0]  R2392     -0.8146932721138
    z[8,7,0]  R2393     4.1255185008049011e-01
    z[8,7,0]  R2394     3.0727377533912659e-01
    z[8,7,0]  R2395     5.7641327381134033e-01
    z[8,7,0]  R2396     4.7787776589393616e-01
    z[8,7,0]  R2397     1.0288880020380020e-01
    z[8,7,0]  R2398     0.56584632396698
    z[8,7,0]  R2399     3.8680833578109741e-01
    z[8,7,0]  R2400     3.1114852428436279e-01
    z[8,7,0]  R2401     2.8785562515258789e-01
    z[8,7,0]  R2402     3.1329560279846191e-01
    z[8,7,0]  R2403     6.3915866613388062e-01
    z[8,7,0]  R2404     6.1947333812713623e-01
    z[8,7,0]  R2405     -3.6312767863273621e-01
    z[8,7,0]  R2406     -1.4555731415748596e-01
    z[8,7,0]  R2407     1.5721313655376434e-01
    z[8,7,0]  R2408     -0.337566077709198
    z[8,7,0]  R2409     -4.3169227242469788e-01
    z[8,7,0]  R2410     -6.1430495977401733e-01
    z[8,7,0]  R2411     -4.2309236526489258e-01
    z[8,7,0]  R2412     -6.2170523405075073e-01
    z[8,7,0]  R2413     -6.3902544975280762e-01
    z[8,7,0]  R2414     -1.3756404817104340e-01
    z[8,7,0]  R2415     -5.1230460405349731e-01
    z[8,7,0]  R2416     -7.5247043371200562e-01
    z[8,7,0]  R2417     -4.0488809347152710e-01
    z[8,7,0]  R2418     2.0064330101013184e-01
    z[8,7,0]  R2419     -2.8924819827079773e-01
    z[8,7,0]  R2420     2.7174675464630127e-01
    z[8,7,0]  R2421     -8.5789456963539124e-02
    z[8,7,0]  R2422     -6.6463607549667358e-01
    z[8,7,0]  R2423     4.3180355429649353e-01
    z[8,7,0]  R2424     -3.8987055420875549e-01
    z[8,7,0]  R2425     0.343079149723053
    z[8,7,0]  R2426     -2.0219059288501740e-01
    z[8,7,0]  R2427     2.2271190583705902e-01
    z[8,7,0]  R2428     3.1970273703336716e-02
    z[8,7,0]  R2429     8.0609925091266632e-02
    z[8,7,0]  R2430     5.9101927280426025e-01
    z[8,7,0]  R2431     -2.2363428771495819e-01
    z[8,7,0]  R2432     -2.9740871861577034e-02
    z[8,7,0]  R2433     2.7416062355041504e-01
    z[8,7,0]  R2434     -1.0326413810253143e-01
    z[8,7,0]  R2435     -1.7664854228496552e-01
    z[8,7,0]  R2436     -5.9103786945343018e-01
    z[8,7,0]  R2437     -2.7790278196334839e-01
    z[8,7,1]  R66       1
    z[8,7,1]  R75       -1
    z[8,7,1]  R2326     -1
    z[8,7,1]  R2327     1
    z[8,7,1]  R2338     -0.705855131149292
    z[8,7,1]  R2339     -8.8269656896591187e-01
    z[8,7,1]  R2340     -7.9068571329116821e-01
    z[8,7,1]  R2341     -5.4778116941452026e-01
    z[8,7,1]  R2342     -6.0107243061065674e-01
    z[8,7,1]  R2343     -4.9703511595726013e-01
    z[8,7,1]  R2344     -6.2793469429016113e-01
    z[8,7,1]  R2345     -5.2283900976181030e-01
    z[8,7,1]  R2346     2.2895354032516479e-01
    z[8,7,1]  R2347     2.3920297622680664e-01
    z[8,7,1]  R2348     3.6573797464370728e-01
    z[8,7,1]  R2349     0.535042941570282
    z[8,7,1]  R2350     3.9402100443840027e-01
    z[8,7,1]  R2351     3.3955448865890503e-01
    z[8,7,1]  R2352     0.601771891117096
    z[8,7,1]  R2353     2.4936752021312714e-01
    z[8,7,1]  R2354     6.0777044296264648e-01
    z[8,7,1]  R2355     3.5975351929664612e-01
    z[8,7,1]  R2356     3.0412450432777405e-01
    z[8,7,1]  R2357     3.3013802766799927e-01
    z[8,7,1]  R2358     6.4259105920791626e-01
    z[8,7,1]  R2359     5.3079181909561157e-01
    z[8,7,1]  R2360     5.4316770285367966e-02
    z[8,7,1]  R2361     4.1214996576309204e-01
    z[8,7,1]  R2362     -2.1932059526443481e-01
    z[8,7,1]  R2363     5.2335137128829956e-01
    z[8,7,1]  R2364     5.0564658641815186e-01
    z[8,7,1]  R2365     3.3324155211448669e-01
    z[8,7,1]  R2366     3.0066317319869995e-01
    z[8,7,1]  R2367     1.8425990641117096e-01
    z[8,7,1]  R2368     -4.0147960186004639e-01
    z[8,7,1]  R2369     -6.2851530313491821e-01
    z[8,7,1]  R2370     -0.184574156999588
    z[8,7,1]  R2371     4.6243998408317566e-01
    z[8,7,1]  R2372     5.9263890981674194e-01
    z[8,7,1]  R2373     4.7417640686035156e-01
    z[8,7,1]  R2374     -3.5979515314102173e-01
    z[8,7,1]  R2375     6.3976579904556274e-01
    z[8,7,1]  R2376     3.4338611364364624e-01
    z[8,7,1]  R2377     5.0573313236236572e-01
    z[8,7,1]  R2378     0.583396852016449
    z[8,7,1]  R2379     2.2258840501308441e-01
    z[8,7,1]  R2380     -7.5896930694580078e-01
    z[8,7,1]  R2381     3.1945669651031494e-01
    z[8,7,1]  R2382     -4.3107905983924866e-01
    z[8,7,1]  R2383     -6.2369698286056519e-01
    z[8,7,1]  R2384     3.5161608457565308e-01
    z[8,7,1]  R2385     -5.3372174501419067e-01
    z[8,7,1]  R2386     0.620152473449707
    z[8,7,1]  R2387     2.5708135962486267e-01
    z[8,7,1]  R2388     3.5777881741523743e-01
    z[8,7,1]  R2389     -8.6368823051452637e-01
    z[8,7,1]  R2390     6.8246811628341675e-01
    z[8,7,1]  R2391     6.0013699531555176e-01
    z[8,7,1]  R2392     -3.8814717531204224e-01
    z[8,7,1]  R2393     -4.7604104876518250e-01
    z[8,7,1]  R2394     -4.1460853815078735e-01
    z[8,7,1]  R2395     7.2182583808898926e-01
    z[8,7,1]  R2396     4.3425035476684570e-01
    z[8,7,1]  R2397     5.8105295896530151e-01
    z[8,7,1]  R2398     -7.2112256288528442e-01
    z[8,7,1]  R2399     -6.0716563463211060e-01
    z[8,7,1]  R2400     -4.7086629271507263e-01
    z[8,7,1]  R2401     -4.8536252975463867e-01
    z[8,7,1]  R2402     -4.4142702221870422e-01
    z[8,7,1]  R2403     -3.5772338509559631e-02
    z[8,7,1]  R2404     -1.1704052239656448e-01
    z[8,7,1]  R2405     -8.4566110372543335e-01
    z[8,7,1]  R2406     -7.9250574111938477e-01
    z[8,7,1]  R2407     5.1438021659851074e-01
    z[8,7,1]  R2408     4.7565326094627380e-01
    z[8,7,1]  R2409     5.1896393299102783e-01
    z[8,7,1]  R2410     5.3056395053863525e-01
    z[8,7,1]  R2411     4.3915295600891113e-01
    z[8,7,1]  R2412     4.2227533459663391e-01
    z[8,7,1]  R2413     4.2494386434555054e-01
    z[8,7,1]  R2414     1.5499807894229889e-01
    z[8,7,1]  R2415     4.4935676455497742e-01
    z[8,7,1]  R2416     4.9008226394653320e-01
    z[8,7,1]  R2417     6.5573644638061523e-01
    z[8,7,1]  R2418     -7.9547427594661713e-02
    z[8,7,1]  R2419     5.8217358589172363e-01
    z[8,7,1]  R2420     4.4434210658073425e-01
    z[8,7,1]  R2421     6.3792675733566284e-01
    z[8,7,1]  R2422     2.3921658098697662e-01
    z[8,7,1]  R2423     1.3692812621593475e-01
    z[8,7,1]  R2424     -3.5033699870109558e-01
    z[8,7,1]  R2425     2.3405049741268158e-01
    z[8,7,1]  R2426     -5.1957017183303833e-01
    z[8,7,1]  R2427     5.6142288446426392e-01
    z[8,7,1]  R2428     1.9173850119113922e-01
    z[8,7,1]  R2429     -6.3599482178688049e-02
    z[8,7,1]  R2430     3.2843938469886780e-01
    z[8,7,1]  R2431     -6.9322896003723145e-01
    z[8,7,1]  R2432     3.4201240539550781e-01
    z[8,7,1]  R2433     -8.2714691758155823e-02
    z[8,7,1]  R2434     0.0487123504281044
    z[8,7,1]  R2435     1.3683560490608215e-01
    z[8,7,1]  R2436     -5.1087313890457153e-01
    z[8,7,1]  R2437     8.6742222309112549e-02
    z[8,7,2]  R67       1
    z[8,7,2]  R76       -1
    z[8,7,2]  R2328     -1
    z[8,7,2]  R2329     1
    z[8,7,2]  R2338     -3.6354590207338333e-02
    z[8,7,2]  R2339     -2.7984252572059631e-01
    z[8,7,2]  R2340     -0.00863682571798563
    z[8,7,2]  R2341     -2.5398376584053040e-01
    z[8,7,2]  R2342     -4.2689961194992065e-01
    z[8,7,2]  R2343     3.2003694772720337e-01
    z[8,7,2]  R2344     1.3535057008266449e-01
    z[8,7,2]  R2345     -3.9969551563262939e-01
    z[8,7,2]  R2346     1.6448435187339783e-01
    z[8,7,2]  R2347     1.7573493719100952e-01
    z[8,7,2]  R2348     4.6703219413757324e-01
    z[8,7,2]  R2349     2.1635392308235168e-01
    z[8,7,2]  R2350     1.6247582435607910e-01
    z[8,7,2]  R2351     1.7877030372619629e-01
    z[8,7,2]  R2352     -6.9348454475402832e-02
    z[8,7,2]  R2353     2.6478347182273865e-01
    z[8,7,2]  R2354     4.5628994703292847e-02
    z[8,7,2]  R2355     1.8481417000293732e-01
    z[8,7,2]  R2356     4.2502439022064209e-01
    z[8,7,2]  R2357     8.1140503287315369e-02
    z[8,7,2]  R2358     5.0389105081558228e-01
    z[8,7,2]  R2359     3.9021718502044678e-01
    z[8,7,2]  R2360     7.0239871740341187e-01
    z[8,7,2]  R2361     3.2019799947738647e-01
    z[8,7,2]  R2362     -6.0397596098482609e-03
    z[8,7,2]  R2363     -4.7329090535640717e-02
    z[8,7,2]  R2364     -1.8379144370555878e-02
    z[8,7,2]  R2365     5.7520174980163574e-01
    z[8,7,2]  R2366     0.642295241355896
    z[8,7,2]  R2367     3.9481487870216370e-01
    z[8,7,2]  R2368     4.0127193927764893e-01
    z[8,7,2]  R2369     -2.4796979129314423e-01
    z[8,7,2]  R2370     6.5727323293685913e-02
    z[8,7,2]  R2371     -6.7530685663223267e-01
    z[8,7,2]  R2372     -5.8397132158279419e-01
    z[8,7,2]  R2373     -5.4952836036682129e-01
    z[8,7,2]  R2374     -3.1262585520744324e-01
    z[8,7,2]  R2375     -5.2683001756668091e-01
    z[8,7,2]  R2376     -7.5382733345031738e-01
    z[8,7,2]  R2377     -7.3114919662475586e-01
    z[8,7,2]  R2378     5.2697986364364624e-01
    z[8,7,2]  R2379     3.8458457589149475e-01
    z[8,7,2]  R2380     4.0947649627923965e-02
    z[8,7,2]  R2381     2.8311860561370850e-01
    z[8,7,2]  R2382     3.5711872577667236e-01
    z[8,7,2]  R2383     -5.0671335309743881e-02
    z[8,7,2]  R2384     -1.1463362723588943e-01
    z[8,7,2]  R2385     -7.8487031161785126e-02
    z[8,7,2]  R2386     -2.1065986156463623e-01
    z[8,7,2]  R2387     -4.0730472654104233e-02
    z[8,7,2]  R2388     6.3772797584533691e-01
    z[8,7,2]  R2389     7.4824534356594086e-02
    z[8,7,2]  R2390     1.8205539882183075e-01
    z[8,7,2]  R2391     -1.8323624506592751e-02
    z[8,7,2]  R2392     2.4640716612339020e-01
    z[8,7,2]  R2393     -1.8924209475517273e-01
    z[8,7,2]  R2394     -4.0736806392669678e-01
    z[8,7,2]  R2395     1.0924704372882843e-01
    z[8,7,2]  R2396     -2.3694667220115662e-01
    z[8,7,2]  R2397     -4.2501190304756165e-01
    z[8,7,2]  R2398     1.5238769352436066e-01
    z[8,7,2]  R2399     3.8924619555473328e-01
    z[8,7,2]  R2400     1.3544920086860657e-01
    z[8,7,2]  R2401     6.2276750802993774e-01
    z[8,7,2]  R2402     -5.7281100749969482e-01
    z[8,7,2]  R2403     3.1706255674362183e-01
    z[8,7,2]  R2404     -7.3331922292709351e-01
    z[8,7,2]  R2405     2.8229501843452454e-01
    z[8,7,2]  R2406     2.0769460499286652e-01
    z[8,7,2]  R2407     -5.9686416387557983e-01
    z[8,7,2]  R2408     7.2961330413818359e-01
    z[8,7,2]  R2409     4.3422129750251770e-01
    z[8,7,2]  R2410     3.8158121705055237e-01
    z[8,7,2]  R2411     0.550506055355072
    z[8,7,2]  R2412     3.2392820715904236e-01
    z[8,7,2]  R2413     2.4571396410465240e-01
    z[8,7,2]  R2414     0.067622110247612
    z[8,7,2]  R2415     0.459238737821579
    z[8,7,2]  R2416     3.2472480088472366e-02
    z[8,7,2]  R2417     2.7156364917755127e-01
    z[8,7,2]  R2418     -1.8956419825553894e-01
    z[8,7,2]  R2419     -6.9618624448776245e-01
    z[8,7,2]  R2420     -3.2738870382308960e-01
    z[8,7,2]  R2421     -4.9386900663375854e-01
    z[8,7,2]  R2422     -5.8306747674942017e-01
    z[8,7,2]  R2423     1.5498754382133484e-01
    z[8,7,2]  R2424     -1.3371452689170837e-01
    z[8,7,2]  R2425     -3.7353730201721191e-01
    z[8,7,2]  R2426     -2.8236207365989685e-01
    z[8,7,2]  R2427     -5.8703833818435669e-01
    z[8,7,2]  R2428     -1.8302412331104279e-01
    z[8,7,2]  R2429     8.9372813701629639e-02
    z[8,7,2]  R2430     -1.2978021800518036e-01
    z[8,7,2]  R2431     6.9510176777839661e-02
    z[8,7,2]  R2432     5.3976005315780640e-01
    z[8,7,2]  R2433     -8.5104942321777344e-01
    z[8,7,2]  R2434     -7.3560386896133423e-01
    z[8,7,2]  R2435     -4.1516625881195068e-01
    z[8,7,2]  R2436     -2.0120188593864441e-01
    z[8,7,2]  R2437     -4.5631888508796692e-01
    z[8,7,3]  R68       1
    z[8,7,3]  R77       -1
    z[8,7,3]  R2330     -1
    z[8,7,3]  R2331     1
    z[8,7,3]  R2338     -2.4049256742000580e-01
    z[8,7,3]  R2339     -1.8227960169315338e-01
    z[8,7,3]  R2340     -1.8367478251457214e-01
    z[8,7,3]  R2341     -2.1280041337013245e-01
    z[8,7,3]  R2342     -2.0879431068897247e-01
    z[8,7,3]  R2343     -2.2890414297580719e-01
    z[8,7,3]  R2344     -1.2697722017765045e-01
    z[8,7,3]  R2345     -1.5663371980190277e-01
    z[8,7,3]  R2346     1.1656701564788818e-01
    z[8,7,3]  R2347     1.3841967284679413e-01
    z[8,7,3]  R2348     -8.7010592222213745e-02
    z[8,7,3]  R2349     6.7712718248367310e-01
    z[8,7,3]  R2350     6.4832371473312378e-01
    z[8,7,3]  R2351     6.1362695693969727e-01
    z[8,7,3]  R2352     4.8928019404411316e-01
    z[8,7,3]  R2353     6.0580068826675415e-01
    z[8,7,3]  R2354     2.9120427370071411e-01
    z[8,7,3]  R2355     3.3687943220138550e-01
    z[8,7,3]  R2356     3.2745805382728577e-01
    z[8,7,3]  R2357     5.7278507947921753e-01
    z[8,7,3]  R2358     -4.6318760514259338e-01
    z[8,7,3]  R2359     3.5891026258468628e-01
    z[8,7,3]  R2360     -4.9805739521980286e-01
    z[8,7,3]  R2361     -3.4513863921165466e-01
    z[8,7,3]  R2362     -7.7164888381958008e-01
    z[8,7,3]  R2363     2.2541718184947968e-01
    z[8,7,3]  R2364     -2.8522717952728271e-01
    z[8,7,3]  R2365     8.7847806513309479e-02
    z[8,7,3]  R2366     -2.8901886940002441e-01
    z[8,7,3]  R2367     5.1158016920089722e-01
    z[8,7,3]  R2368     -2.6556468009948730e-01
    z[8,7,3]  R2369     -1.1575835943222046e-01
    z[8,7,3]  R2370     -7.4994575977325439e-01
    z[8,7,3]  R2371     -1.3088975846767426e-01
    z[8,7,3]  R2372     -1.5370818972587585e-01
    z[8,7,3]  R2373     -0.136946439743042
    z[8,7,3]  R2374     -3.2947468757629395e-01
    z[8,7,3]  R2375     -2.2416210174560547e-01
    z[8,7,3]  R2376     -1.1424796283245087e-01
    z[8,7,3]  R2377     3.1601503491401672e-02
    z[8,7,3]  R2378     1.7844025790691376e-01
    z[8,7,3]  R2379     9.4157420098781586e-02
    z[8,7,3]  R2380     -4.8243671655654907e-01
    z[8,7,3]  R2381     1.7940548062324524e-01
    z[8,7,3]  R2382     -7.8748118877410889e-01
    z[8,7,3]  R2383     -1.9369816780090332e-01
    z[8,7,3]  R2384     4.6675175428390503e-01
    z[8,7,3]  R2385     -2.1306182444095612e-01
    z[8,7,3]  R2386     6.8165791034698486e-01
    z[8,7,3]  R2387     -2.6813134551048279e-01
    z[8,7,3]  R2388     -9.8371699452400208e-02
    z[8,7,3]  R2389     -2.9901558160781860e-01
    z[8,7,3]  R2390     -6.8399451673030853e-02
    z[8,7,3]  R2391     -1.7771961167454720e-02
    z[8,7,3]  R2392     -3.3625584840774536e-01
    z[8,7,3]  R2393     -3.8571050763130188e-01
    z[8,7,3]  R2394     -3.6949291825294495e-01
    z[8,7,3]  R2395     2.4150632321834564e-01
    z[8,7,3]  R2396     5.7673478126525879e-01
    z[8,7,3]  R2397     6.2681674957275391e-01
    z[8,7,3]  R2398     -1.9879573583602905e-01
    z[8,7,3]  R2399     -1.2019961327314377e-01
    z[8,7,3]  R2400     -2.1669751405715942e-01
    z[8,7,3]  R2401     -1.7680196464061737e-01
    z[8,7,3]  R2402     -1.1830183863639832e-01
    z[8,7,3]  R2403     -2.1421962976455688e-01
    z[8,7,3]  R2404     -1.0761692374944687e-01
    z[8,7,3]  R2405     1.9323322176933289e-01
    z[8,7,3]  R2406     2.0005673170089722e-01
    z[8,7,3]  R2407     3.9944455027580261e-01
    z[8,7,3]  R2408     2.5041863322257996e-01
    z[8,7,3]  R2409     2.5284075736999512e-01
    z[8,7,3]  R2410     7.8956015408039093e-02
    z[8,7,3]  R2411     3.5475313663482666e-01
    z[8,7,3]  R2412     4.1027444601058960e-01
    z[8,7,3]  R2413     3.6534574627876282e-01
    z[8,7,3]  R2414     -9.1493481397628784e-01
    z[8,7,3]  R2415     2.1414358913898468e-01
    z[8,7,3]  R2416     2.4445576965808868e-01
    z[8,7,3]  R2417     3.4286347031593323e-01
    z[8,7,3]  R2418     -6.6909611225128174e-01
    z[8,7,3]  R2419     -8.4517627954483032e-02
    z[8,7,3]  R2420     -5.9091800451278687e-01
    z[8,7,3]  R2421     -3.9055764675140381e-01
    z[8,7,3]  R2422     -1.2892629206180573e-01
    z[8,7,3]  R2423     -4.0681746602058411e-01
    z[8,7,3]  R2424     -7.3988062143325806e-01
    z[8,7,3]  R2425     -7.0957213640213013e-01
    z[8,7,3]  R2426     -5.8777654170989990e-01
    z[8,7,3]  R2427     1.9040267169475555e-01
    z[8,7,3]  R2428     -8.9693957567214966e-01
    z[8,7,3]  R2429     -9.2326998710632324e-01
    z[8,7,3]  R2430     -5.1264625042676926e-02
    z[8,7,3]  R2431     -2.4642907083034515e-01
    z[8,7,3]  R2432     -5.7452076673507690e-01
    z[8,7,3]  R2433     -3.1194803118705750e-01
    z[8,7,3]  R2434     4.3479931354522705e-01
    z[8,7,3]  R2435     3.0651673674583435e-01
    z[8,7,3]  R2436     -4.3567517399787903e-01
    z[8,7,3]  R2437     4.9107018113136292e-01
    z[8,7,4]  R69       1
    z[8,7,4]  R78       -1
    z[8,7,4]  R2332     -1
    z[8,7,4]  R2333     1
    z[8,7,4]  R2338     4.7157740592956543e-01
    z[8,7,4]  R2339     -5.2349831908941269e-02
    z[8,7,4]  R2340     -1.3976477086544037e-01
    z[8,7,4]  R2341     2.9161083698272705e-01
    z[8,7,4]  R2342     -3.2475203275680542e-02
    z[8,7,4]  R2343     0.745089054107666
    z[8,7,4]  R2344     -7.4821531772613525e-02
    z[8,7,4]  R2345     -1.2268606573343277e-01
    z[8,7,4]  R2346     2.7033528685569763e-01
    z[8,7,4]  R2347     3.1954219937324524e-01
    z[8,7,4]  R2348     -4.0138435363769531e-01
    z[8,7,4]  R2349     -0.0943312868475914
    z[8,7,4]  R2350     1.3736635446548462e-01
    z[8,7,4]  R2351     -1.0122365504503250e-01
    z[8,7,4]  R2352     -3.8699424266815186e-01
    z[8,7,4]  R2353     -5.2707046270370483e-02
    z[8,7,4]  R2354     -3.8135918974876404e-01
    z[8,7,4]  R2355     -1.6239321231842041e-01
    z[8,7,4]  R2356     -3.1952168792486191e-02
    z[8,7,4]  R2357     -2.7643764019012451e-01
    z[8,7,4]  R2358     7.9723246395587921e-02
    z[8,7,4]  R2359     3.1396403908729553e-02
    z[8,7,4]  R2360     1.6028310358524323e-01
    z[8,7,4]  R2361     -3.3956998586654663e-01
    z[8,7,4]  R2362     -4.7288507223129272e-01
    z[8,7,4]  R2363     -6.5615504980087280e-01
    z[8,7,4]  R2364     -6.0443294048309326e-01
    z[8,7,4]  R2365     5.7951617240905762e-01
    z[8,7,4]  R2366     8.9810833334922791e-02
    z[8,7,4]  R2367     1.0060887038707733e-01
    z[8,7,4]  R2368     4.5800673961639404e-01
    z[8,7,4]  R2369     -2.1552371978759766e-01
    z[8,7,4]  R2370     3.7567341327667236e-01
    z[8,7,4]  R2371     2.7588644623756409e-01
    z[8,7,4]  R2372     1.0778700560331345e-01
    z[8,7,4]  R2373     8.4838949143886566e-02
    z[8,7,4]  R2374     -6.3639283180236816e-02
    z[8,7,4]  R2375     1.5019574761390686e-01
    z[8,7,4]  R2376     9.2797234654426575e-02
    z[8,7,4]  R2377     -5.2797406911849976e-02
    z[8,7,4]  R2378     3.9403277635574341e-01
    z[8,7,4]  R2379     -3.3162882924079895e-01
    z[8,7,4]  R2380     -6.2922318466007710e-03
    z[8,7,4]  R2381     -1.2952215969562531e-01
    z[8,7,4]  R2382     4.7503627836704254e-02
    z[8,7,4]  R2383     3.4745806455612183e-01
    z[8,7,4]  R2384     -8.5709132254123688e-02
    z[8,7,4]  R2385     3.7121790647506714e-01
    z[8,7,4]  R2386     7.4765356257557869e-03
    z[8,7,4]  R2387     2.4638114869594574e-01
    z[8,7,4]  R2388     -1.0565236210823059e-01
    z[8,7,4]  R2389     2.7540171146392822e-01
    z[8,7,4]  R2390     -5.3796207904815674e-01
    z[8,7,4]  R2391     -8.4774866700172424e-02
    z[8,7,4]  R2392     -1.0620661079883575e-01
    z[8,7,4]  R2393     3.7548542022705078e-01
    z[8,7,4]  R2394     -1.1374235898256302e-01
    z[8,7,4]  R2395     6.3498369418084621e-03
    z[8,7,4]  R2396     -6.4141921699047089e-02
    z[8,7,4]  R2397     -1.3149622082710266e-01
    z[8,7,4]  R2398     2.8136044740676880e-01
    z[8,7,4]  R2399     1.3414669036865234e-01
    z[8,7,4]  R2400     6.0929656028747559e-01
    z[8,7,4]  R2401     4.6493580937385559e-01
    z[8,7,4]  R2402     5.9276384115219116e-01
    z[8,7,4]  R2403     5.8546477556228638e-01
    z[8,7,4]  R2404     -9.6167489886283875e-02
    z[8,7,4]  R2405     -1.0068996995687485e-01
    z[8,7,4]  R2406     -1.6605491936206818e-01
    z[8,7,4]  R2407     3.6492672562599182e-01
    z[8,7,4]  R2408     -2.4456101655960083e-01
    z[8,7,4]  R2409     -2.1529795229434967e-01
    z[8,7,4]  R2410     -2.6367521286010742e-01
    z[8,7,4]  R2411     2.7901515364646912e-01
    z[8,7,4]  R2412     2.8647467494010925e-01
    z[8,7,4]  R2413     9.8640955984592438e-02
    z[8,7,4]  R2414     -3.3423733711242676e-01
    z[8,7,4]  R2415     5.5307867005467415e-03
    z[8,7,4]  R2416     -2.2386403381824493e-01
    z[8,7,4]  R2417     -3.8595151901245117e-01
    z[8,7,4]  R2418     -1.9395154714584351e-01
    z[8,7,4]  R2419     -1.3204665482044220e-01
    z[8,7,4]  R2420     4.1910582780838013e-01
    z[8,7,4]  R2421     1.9031862914562225e-01
    z[8,7,4]  R2422     -2.3103572428226471e-01
    z[8,7,4]  R2423     7.7144846320152283e-02
    z[8,7,4]  R2424     0.0887860581278801
    z[8,7,4]  R2425     -3.5474222898483276e-01
    z[8,7,4]  R2426     -4.5493033528327942e-01
    z[8,7,4]  R2427     4.9308523535728455e-02
    z[8,7,4]  R2428     3.2211273908615112e-01
    z[8,7,4]  R2429     2.5527609977871180e-03
    z[8,7,4]  R2430     0.415828675031662
    z[8,7,4]  R2431     -2.0532572269439697e-01
    z[8,7,4]  R2432     1.3875405490398407e-01
    z[8,7,4]  R2433     -3.2913282513618469e-02
    z[8,7,4]  R2434     4.0149144828319550e-02
    z[8,7,4]  R2435     2.2124961018562317e-01
    z[8,7,4]  R2436     -5.4027330130338669e-02
    z[8,7,4]  R2437     3.3655592799186707e-01
    z[8,7,5]  R70       1
    z[8,7,5]  R79       -1
    z[8,7,5]  R2334     -1
    z[8,7,5]  R2335     1
    z[8,7,5]  R2338     2.5104042887687683e-01
    z[8,7,5]  R2339     -8.7841480970382690e-02
    z[8,7,5]  R2340     -1.9002674520015717e-01
    z[8,7,5]  R2341     3.6660602688789368e-01
    z[8,7,5]  R2342     3.5867232084274292e-01
    z[8,7,5]  R2343     -1.9685764610767365e-01
    z[8,7,5]  R2344     -2.3646345734596252e-01
    z[8,7,5]  R2345     4.7210484743118286e-01
    z[8,7,5]  R2346     3.0779346823692322e-01
    z[8,7,5]  R2347     1.9148269295692444e-01
    z[8,7,5]  R2348     -5.3942728042602539e-01
    z[8,7,5]  R2349     -2.4274408817291260e-02
    z[8,7,5]  R2350     -6.3160099089145660e-02
    z[8,7,5]  R2351     1.4341041445732117e-01
    z[8,7,5]  R2352     -3.2551422715187073e-02
    z[8,7,5]  R2353     1.0987445712089539e-01
    z[8,7,5]  R2354     -9.7465276718139648e-02
    z[8,7,5]  R2355     -1.5779529511928558e-01
    z[8,7,5]  R2356     -7.3694236576557159e-02
    z[8,7,5]  R2357     -3.8061082363128662e-01
    z[8,7,5]  R2358     1.9135256111621857e-01
    z[8,7,5]  R2359     -3.3060204982757568e-01
    z[8,7,5]  R2360     -3.1885802745819092e-01
    z[8,7,5]  R2361     5.9416841715574265e-02
    z[8,7,5]  R2362     3.0407893657684326e-01
    z[8,7,5]  R2363     8.8839247822761536e-02
    z[8,7,5]  R2364     3.5376599431037903e-01
    z[8,7,5]  R2365     -3.2122090458869934e-01
    z[8,7,5]  R2366     -4.5879325270652771e-01
    z[8,7,5]  R2367     -6.0984903573989868e-01
    z[8,7,5]  R2368     -2.6245990395545959e-01
    z[8,7,5]  R2369     0.254169762134552
    z[8,7,5]  R2370     4.5750427246093750e-01
    z[8,7,5]  R2371     -4.0662378072738647e-01
    z[8,7,5]  R2372     -3.9159911870956421e-01
    z[8,7,5]  R2373     -4.9317845702171326e-01
    z[8,7,5]  R2374     2.2540882229804993e-01
    z[8,7,5]  R2375     -2.3525390028953552e-01
    z[8,7,5]  R2376     -4.6838164329528809e-01
    z[8,7,5]  R2377     -1.1270120739936829e-01
    z[8,7,5]  R2378     -1.2917117774486542e-01
    z[8,7,5]  R2379     -2.8374055027961731e-01
    z[8,7,5]  R2380     -2.3278048634529114e-01
    z[8,7,5]  R2381     -1.2248796969652176e-01
    z[8,7,5]  R2382     -1.9105631113052368e-01
    z[8,7,5]  R2383     1.1361550539731979e-02
    z[8,7,5]  R2384     0.294919490814209
    z[8,7,5]  R2385     3.6078030243515968e-03
    z[8,7,5]  R2386     -5.7003190740942955e-03
    z[8,7,5]  R2387     1.1956840753555298e-01
    z[8,7,5]  R2388     -4.0403288602828979e-01
    z[8,7,5]  R2389     -2.6048877835273743e-01
    z[8,7,5]  R2390     1.2340676039457321e-01
    z[8,7,5]  R2391     5.8245950937271118e-01
    z[8,7,5]  R2392     2.0201133564114571e-02
    z[8,7,5]  R2393     2.8838792443275452e-01
    z[8,7,5]  R2394     4.0955805778503418e-01
    z[8,7,5]  R2395     -1.9069863855838776e-01
    z[8,7,5]  R2396     -1.3184095919132233e-01
    z[8,7,5]  R2397     1.8675215542316437e-02
    z[8,7,5]  R2398     1.2903597950935364e-01
    z[8,7,5]  R2399     5.0718921422958374e-01
    z[8,7,5]  R2400     4.9037474393844604e-01
    z[8,7,5]  R2401     -1.2133947759866714e-01
    z[8,7,5]  R2402     -4.3760299682617188e-02
    z[8,7,5]  R2403     1.1665125936269760e-01
    z[8,7,5]  R2404     -2.1996637806296349e-02
    z[8,7,5]  R2405     1.4449493587017059e-01
    z[8,7,5]  R2406     -1.3534571230411530e-01
    z[8,7,5]  R2407     1.2469103187322617e-01
    z[8,7,5]  R2408     4.2589064687490463e-02
    z[8,7,5]  R2409     4.6388205885887146e-01
    z[8,7,5]  R2410     6.5515274181962013e-03
    z[8,7,5]  R2411     -3.1412345170974731e-01
    z[8,7,5]  R2412     -1.1265028268098831e-01
    z[8,7,5]  R2413     1.6476555168628693e-01
    z[8,7,5]  R2414     -3.8684133440256119e-02
    z[8,7,5]  R2415     -0.51753830909729
    z[8,7,5]  R2416     -2.8312796354293823e-01
    z[8,7,5]  R2417     -7.5021870434284210e-02
    z[8,7,5]  R2418     -0.572472095489502
    z[8,7,5]  R2419     -2.5666135549545288e-01
    z[8,7,5]  R2420     -2.5014990568161011e-01
    z[8,7,5]  R2421     -3.4819102287292480e-01
    z[8,7,5]  R2422     -3.0022063851356506e-01
    z[8,7,5]  R2423     -7.7347451448440552e-01
    z[8,7,5]  R2424     -1.6917371749877930e-01
    z[8,7,5]  R2425     2.4217553436756134e-01
    z[8,7,5]  R2426     -5.9445660561323166e-02
    z[8,7,5]  R2427     -4.9349084496498108e-01
    z[8,7,5]  R2428     1.0130524635314941e-01
    z[8,7,5]  R2429     -3.2140168547630310e-01
    z[8,7,5]  R2430     -5.9102743864059448e-01
    z[8,7,5]  R2431     -5.9029066562652588e-01
    z[8,7,5]  R2432     4.5784175395965576e-01
    z[8,7,5]  R2433     -1.1757113784551620e-01
    z[8,7,5]  R2434     -4.3659603595733643e-01
    z[8,7,5]  R2435     -0.759149968624115
    z[8,7,5]  R2436     -3.9859518408775330e-02
    z[8,7,5]  R2437     -5.7088422775268555e-01
    z[8,7,6]  R71       1
    z[8,7,6]  R80       -1
    z[8,7,6]  R2336     -1
    z[8,7,6]  R2337     1
    z[8,7,6]  R2338     0.0672181099653244
    z[8,7,6]  R2339     -2.8849324584007263e-01
    z[8,7,6]  R2340     -3.2158580422401428e-01
    z[8,7,6]  R2341     -5.9678763151168823e-01
    z[8,7,6]  R2342     -5.3172874450683594e-01
    z[8,7,6]  R2343     -2.8782900422811508e-02
    z[8,7,6]  R2344     5.2817636728286743e-01
    z[8,7,6]  R2345     -3.6818888783454895e-01
    z[8,7,6]  R2346     0.508339524269104
    z[8,7,6]  R2347     -6.6201704740524292e-01
    z[8,7,6]  R2348     -4.2290541529655457e-01
    z[8,7,6]  R2349     -1.4083603024482727e-01
    z[8,7,6]  R2350     7.4627533555030823e-02
    z[8,7,6]  R2351     1.8405258655548096e-01
    z[8,7,6]  R2352     1.0553563386201859e-01
    z[8,7,6]  R2353     -7.8094065189361572e-02
    z[8,7,6]  R2354     5.1657155156135559e-02
    z[8,7,6]  R2355     1.0284334421157837e-01
    z[8,7,6]  R2356     -7.3660321533679962e-02
    z[8,7,6]  R2357     -2.5152249261736870e-02
    z[8,7,6]  R2358     -2.8996374458074570e-02
    z[8,7,6]  R2359     -4.4978532195091248e-01
    z[8,7,6]  R2360     -1.1239292472600937e-01
    z[8,7,6]  R2361     6.2321919202804565e-01
    z[8,7,6]  R2362     4.0963903069496155e-02
    z[8,7,6]  R2363     0.0159404706209898
    z[8,7,6]  R2364     -2.6013967394828796e-01
    z[8,7,6]  R2365     3.3024734258651733e-01
    z[8,7,6]  R2366     4.3401810526847839e-01
    z[8,7,6]  R2367     2.9446718096733093e-01
    z[8,7,6]  R2368     -5.2711308002471924e-01
    z[8,7,6]  R2369     1.6469725966453552e-01
    z[8,7,6]  R2370     -1.2055918574333191e-01
    z[8,7,6]  R2371     -5.2877198904752731e-02
    z[8,7,6]  R2372     9.4701521098613739e-02
    z[8,7,6]  R2373     -1.5367236733436584e-01
    z[8,7,6]  R2374     0.603775680065155
    z[8,7,6]  R2375     -1.6113768517971039e-01
    z[8,7,6]  R2376     1.5535804629325867e-01
    z[8,7,6]  R2377     -1.3475976884365082e-01
    z[8,7,6]  R2378     -1.2325000762939453e-01
    z[8,7,6]  R2379     -1.5239277482032776e-01
    z[8,7,6]  R2380     -3.2360067963600159e-01
    z[8,7,6]  R2381     -5.7558751106262207e-01
    z[8,7,6]  R2382     7.7643796801567078e-02
    z[8,7,6]  R2383     -6.7058050632476807e-01
    z[8,7,6]  R2384     3.3016854524612427e-01
    z[8,7,6]  R2385     6.2257814407348633e-01
    z[8,7,6]  R2386     0.0656309723854065
    z[8,7,6]  R2387     1.2210515886545181e-01
    z[8,7,6]  R2388     -1.0634802281856537e-01
    z[8,7,6]  R2389     -1.1415829509496689e-01
    z[8,7,6]  R2390     1.6399851068854332e-02
    z[8,7,6]  R2391     1.9085927307605743e-01
    z[8,7,6]  R2392     1.2006171047687531e-02
    z[8,7,6]  R2393     4.4095784425735474e-01
    z[8,7,6]  R2394     0.500533401966095
    z[8,7,6]  R2395     -2.0012147724628448e-01
    z[8,7,6]  R2396     -4.1568791866302490e-01
    z[8,7,6]  R2397     -2.4620507657527924e-01
    z[8,7,6]  R2398     -3.5278104245662689e-02
    z[8,7,6]  R2399     2.0132671296596527e-01
    z[8,7,6]  R2400     -0.0667652115225792
    z[8,7,6]  R2401     1.7769466340541840e-01
    z[8,7,6]  R2402     1.0768654197454453e-01
    z[8,7,6]  R2403     2.9563727974891663e-01
    z[8,7,6]  R2404     2.0852752029895782e-01
    z[8,7,6]  R2405     -7.0347420871257782e-02
    z[8,7,6]  R2406     4.7084507346153259e-01
    z[8,7,6]  R2407     2.1488350629806519e-01
    z[8,7,6]  R2408     5.5983554571866989e-02
    z[8,7,6]  R2409     -1.7407430708408356e-01
    z[8,7,6]  R2410     -3.4601387381553650e-01
    z[8,7,6]  R2411     -1.5069159865379333e-01
    z[8,7,6]  R2412     -2.5914004445075989e-01
    z[8,7,6]  R2413     -4.2466285824775696e-01
    z[8,7,6]  R2414     -4.6498034149408340e-02
    z[8,7,6]  R2415     -1.0482472181320190e-01
    z[8,7,6]  R2416     -5.0177793949842453e-02
    z[8,7,6]  R2417     2.4532899260520935e-01
    z[8,7,6]  R2418     0.323185533285141
    z[8,7,6]  R2419     -4.7742825001478195e-02
    z[8,7,6]  R2420     -1.8472076952457428e-01
    z[8,7,6]  R2421     -1.7829626798629761e-01
    z[8,7,6]  R2422     3.0573625117540359e-02
    z[8,7,6]  R2423     -3.2567363232374191e-02
    z[8,7,6]  R2424     -3.5136780142784119e-01
    z[8,7,6]  R2425     1.8085611518472433e-03
    z[8,7,6]  R2426     -2.3121614754199982e-01
    z[8,7,6]  R2427     -9.1499179601669312e-02
    z[8,7,6]  R2428     1.0097808390855789e-01
    z[8,7,6]  R2429     -1.6042618453502655e-01
    z[8,7,6]  R2430     3.3555500209331512e-02
    z[8,7,6]  R2431     -1.1515476554632187e-01
    z[8,7,6]  R2432     1.7848303914070129e-01
    z[8,7,6]  R2433     -2.8546676039695740e-01
    z[8,7,6]  R2434     -2.5411024689674377e-01
    z[8,7,6]  R2435     2.4185892939567566e-01
    z[8,7,6]  R2436     3.9354795217514038e-01
    z[8,7,6]  R2437     -1.6337199509143829e-01
    z[8,9,0]  R74       -1
    z[8,9,0]  R83       1
    z[8,9,0]  R2438     -1
    z[8,9,0]  R2439     1
    z[8,9,0]  R2452     -3.9074981212615967e-01
    z[8,9,0]  R2453     1.2499614059925079e-01
    z[8,9,0]  R2454     -4.2654818296432495e-01
    z[8,9,0]  R2455     -1.2063000351190567e-01
    z[8,9,0]  R2456     -2.0915327593684196e-02
    z[8,9,0]  R2457     5.8277625590562820e-02
    z[8,9,0]  R2458     -4.8038700222969055e-01
    z[8,9,0]  R2459     -4.1091445088386536e-01
    z[8,9,0]  R2460     -6.9333279132843018e-01
    z[8,9,0]  R2461     -5.6187170743942261e-01
    z[8,9,0]  R2462     -9.8007969558238983e-02
    z[8,9,0]  R2463     4.2319771647453308e-01
    z[8,9,0]  R2464     6.0794532299041748e-01
    z[8,9,0]  R2465     6.4149641990661621e-01
    z[8,9,0]  R2466     4.8135679960250854e-01
    z[8,9,0]  R2467     6.9264853000640869e-01
    z[8,9,0]  R2468     6.2139403820037842e-01
    z[8,9,0]  R2469     8.1307172775268555e-01
    z[8,9,0]  R2470     7.7958720922470093e-01
    z[8,9,0]  R2471     5.7829689979553223e-01
    z[8,9,0]  R2472     -2.7352419495582581e-01
    z[8,9,0]  R2473     -3.5296434164047241e-01
    z[8,9,0]  R2474     -3.4004601836204529e-01
    z[8,9,0]  R2475     -3.1818976998329163e-01
    z[8,9,0]  R2476     -1.9661569595336914e-01
    z[8,9,0]  R2477     -4.8411211371421814e-01
    z[8,9,0]  R2478     -3.2321357727050781e-01
    z[8,9,0]  R2479     -4.7861676663160324e-02
    z[8,9,0]  R2480     8.1224814057350159e-02
    z[8,9,0]  R2481     -2.8232285380363464e-01
    z[8,9,0]  R2482     -2.2531481087207794e-01
    z[8,9,0]  R2483     -6.2602043151855469e-01
    z[8,9,0]  R2484     1.8498246371746063e-01
    z[8,9,0]  R2485     2.6215562224388123e-01
    z[8,9,0]  R2486     3.3195510506629944e-01
    z[8,9,0]  R2487     4.2471545934677124e-01
    z[8,9,0]  R2488     4.9482813477516174e-01
    z[8,9,0]  R2489     3.9878904819488525e-01
    z[8,9,0]  R2490     2.2056475281715393e-01
    z[8,9,0]  R2491     4.1833823919296265e-01
    z[8,9,0]  R2492     -4.0368527173995972e-01
    z[8,9,0]  R2493     -7.6156002283096313e-01
    z[8,9,0]  R2494     1.7492818832397461e-01
    z[8,9,0]  R2495     -6.5001899003982544e-01
    z[8,9,0]  R2496     1.4738659560680389e-01
    z[8,9,0]  R2497     -1.9520901143550873e-02
    z[8,9,0]  R2498     -6.6485571861267090e-01
    z[8,9,0]  R2499     3.7170723080635071e-01
    z[8,9,0]  R2500     3.1934314966201782e-01
    z[8,9,0]  R2501     8.7775045633316040e-01
    z[8,9,0]  R2502     -5.1952421665191650e-01
    z[8,9,0]  R2503     4.7968052327632904e-02
    z[8,9,0]  R2504     -4.3762215971946716e-01
    z[8,9,0]  R2505     -5.0627154111862183e-01
    z[8,9,0]  R2506     -0.8146932721138
    z[8,9,0]  R2507     4.1255185008049011e-01
    z[8,9,0]  R2508     3.0727377533912659e-01
    z[8,9,0]  R2509     5.7641327381134033e-01
    z[8,9,0]  R2510     4.7787776589393616e-01
    z[8,9,0]  R2511     1.0288880020380020e-01
    z[8,9,0]  R2512     -6.8731087446212769e-01
    z[8,9,0]  R2513     1.8868595361709595e-01
    z[8,9,0]  R2514     0.314831018447876
    z[8,9,0]  R2515     -6.5993182361125946e-02
    z[8,9,0]  R2516     6.4107263088226318e-01
    z[8,9,0]  R2517     -0.579894483089447
    z[8,9,0]  R2518     -3.6888748407363892e-01
    z[8,9,0]  R2519     -0.0707937628030777
    z[8,9,0]  R2520     3.2471904158592224e-01
    z[8,9,0]  R2521     -4.9675229191780090e-01
    z[8,9,0]  R2522     6.8372559547424316e-01
    z[8,9,0]  R2523     0.373611181974411
    z[8,9,0]  R2524     7.1792131662368774e-01
    z[8,9,0]  R2525     5.4708194732666016e-01
    z[8,9,0]  R2526     6.4950835704803467e-01
    z[8,9,0]  R2527     5.0930714607238770e-01
    z[8,9,0]  R2528     5.6132233142852783e-01
    z[8,9,0]  R2529     5.0749319791793823e-01
    z[8,9,0]  R2530     4.6792671084403992e-01
    z[8,9,0]  R2531     4.3902179598808289e-01
    z[8,9,0]  R2532     2.2824968397617340e-01
    z[8,9,0]  R2533     2.9348272085189819e-01
    z[8,9,0]  R2534     -4.1523975133895874e-01
    z[8,9,0]  R2535     4.0554103255271912e-01
    z[8,9,0]  R2536     -4.1935831308364868e-01
    z[8,9,0]  R2537     -1.5771935880184174e-01
    z[8,9,0]  R2538     6.8925315141677856e-01
    z[8,9,0]  R2539     5.3505182266235352e-01
    z[8,9,0]  R2540     -4.6125955879688263e-02
    z[8,9,0]  R2541     1.0763436555862427e-01
    z[8,9,0]  R2542     -1.3161328434944153e-01
    z[8,9,0]  R2543     -1.0903768241405487e-01
    z[8,9,0]  R2544     3.3622455596923828e-01
    z[8,9,0]  R2545     -1.2607610225677490e-01
    z[8,9,0]  R2546     2.4502323567867279e-01
    z[8,9,0]  R2547     -1.1051161214709282e-02
    z[8,9,0]  R2548     6.3118702173233032e-01
    z[8,9,0]  R2549     -1.7386722564697266e-01
    z[8,9,0]  R2550     0.850654661655426
    z[8,9,0]  R2551     7.7652537822723389e-01
    z[8,9,0]  R2552     1.4204418659210205e-01
    z[8,9,0]  R2553     -0.145231232047081
    z[8,9,0]  R2554     3.3592867851257324e-01
    z[8,9,0]  R2555     -5.2047741413116455e-01
    z[8,9,0]  R2556     -6.8435454368591309e-01
    z[8,9,0]  R2557     5.6111800670623779e-01
    z[8,9,0]  R2558     7.0265668630599976e-01
    z[8,9,0]  R2559     6.2914478778839111e-01
    z[8,9,0]  R2560     9.1968637704849243e-01
    z[8,9,0]  R2561     8.2632642984390259e-01
    z[8,9,1]  R75       -1
    z[8,9,1]  R84       1
    z[8,9,1]  R2440     -1
    z[8,9,1]  R2441     1
    z[8,9,1]  R2452     -0.705855131149292
    z[8,9,1]  R2453     -8.8269656896591187e-01
    z[8,9,1]  R2454     -7.9068571329116821e-01
    z[8,9,1]  R2455     -5.4778116941452026e-01
    z[8,9,1]  R2456     -6.0107243061065674e-01
    z[8,9,1]  R2457     -4.9703511595726013e-01
    z[8,9,1]  R2458     -6.2793469429016113e-01
    z[8,9,1]  R2459     -5.2283900976181030e-01
    z[8,9,1]  R2460     2.2895354032516479e-01
    z[8,9,1]  R2461     2.3920297622680664e-01
    z[8,9,1]  R2462     3.6573797464370728e-01
    z[8,9,1]  R2463     0.535042941570282
    z[8,9,1]  R2464     3.9402100443840027e-01
    z[8,9,1]  R2465     3.3955448865890503e-01
    z[8,9,1]  R2466     0.601771891117096
    z[8,9,1]  R2467     2.4936752021312714e-01
    z[8,9,1]  R2468     6.0777044296264648e-01
    z[8,9,1]  R2469     3.5975351929664612e-01
    z[8,9,1]  R2470     3.0412450432777405e-01
    z[8,9,1]  R2471     3.3013802766799927e-01
    z[8,9,1]  R2472     6.4259105920791626e-01
    z[8,9,1]  R2473     5.3079181909561157e-01
    z[8,9,1]  R2474     5.4316770285367966e-02
    z[8,9,1]  R2475     4.1214996576309204e-01
    z[8,9,1]  R2476     -2.1932059526443481e-01
    z[8,9,1]  R2477     5.2335137128829956e-01
    z[8,9,1]  R2478     5.0564658641815186e-01
    z[8,9,1]  R2479     3.3324155211448669e-01
    z[8,9,1]  R2480     3.0066317319869995e-01
    z[8,9,1]  R2481     1.8425990641117096e-01
    z[8,9,1]  R2482     -4.0147960186004639e-01
    z[8,9,1]  R2483     -6.2851530313491821e-01
    z[8,9,1]  R2484     -0.184574156999588
    z[8,9,1]  R2485     4.6243998408317566e-01
    z[8,9,1]  R2486     5.9263890981674194e-01
    z[8,9,1]  R2487     4.7417640686035156e-01
    z[8,9,1]  R2488     -3.5979515314102173e-01
    z[8,9,1]  R2489     6.3976579904556274e-01
    z[8,9,1]  R2490     3.4338611364364624e-01
    z[8,9,1]  R2491     5.0573313236236572e-01
    z[8,9,1]  R2492     0.583396852016449
    z[8,9,1]  R2493     2.2258840501308441e-01
    z[8,9,1]  R2494     -7.5896930694580078e-01
    z[8,9,1]  R2495     3.1945669651031494e-01
    z[8,9,1]  R2496     -4.3107905983924866e-01
    z[8,9,1]  R2497     -6.2369698286056519e-01
    z[8,9,1]  R2498     3.5161608457565308e-01
    z[8,9,1]  R2499     -5.3372174501419067e-01
    z[8,9,1]  R2500     0.620152473449707
    z[8,9,1]  R2501     2.5708135962486267e-01
    z[8,9,1]  R2502     3.5777881741523743e-01
    z[8,9,1]  R2503     -8.6368823051452637e-01
    z[8,9,1]  R2504     6.8246811628341675e-01
    z[8,9,1]  R2505     6.0013699531555176e-01
    z[8,9,1]  R2506     -3.8814717531204224e-01
    z[8,9,1]  R2507     -4.7604104876518250e-01
    z[8,9,1]  R2508     -4.1460853815078735e-01
    z[8,9,1]  R2509     7.2182583808898926e-01
    z[8,9,1]  R2510     4.3425035476684570e-01
    z[8,9,1]  R2511     5.8105295896530151e-01
    z[8,9,1]  R2512     3.7119895219802856e-01
    z[8,9,1]  R2513     -9.0266567468643188e-01
    z[8,9,1]  R2514     -8.2593297958374023e-01
    z[8,9,1]  R2515     -8.8777500391006470e-01
    z[8,9,1]  R2516     -0.729659914970398
    z[8,9,1]  R2517     4.9801096320152283e-01
    z[8,9,1]  R2518     4.3764263391494751e-01
    z[8,9,1]  R2519     -8.8085365295410156e-01
    z[8,9,1]  R2520     -7.9509723186492920e-01
    z[8,9,1]  R2521     0.380319744348526
    z[8,9,1]  R2522     6.1788678169250488e-01
    z[8,9,1]  R2523     4.1270852088928223e-01
    z[8,9,1]  R2524     3.7514024972915649e-01
    z[8,9,1]  R2525     5.3677648305892944e-01
    z[8,9,1]  R2526     3.5736340284347534e-01
    z[8,9,1]  R2527     6.0424667596817017e-01
    z[8,9,1]  R2528     5.2081435918807983e-01
    z[8,9,1]  R2529     5.3743779659271240e-01
    z[8,9,1]  R2530     3.2512420415878296e-01
    z[8,9,1]  R2531     3.0059731006622314e-01
    z[8,9,1]  R2532     1.0095855593681335e-01
    z[8,9,1]  R2533     0.0694957971572876
    z[8,9,1]  R2534     -2.5015929341316223e-01
    z[8,9,1]  R2535     2.1684801578521729e-01
    z[8,9,1]  R2536     -3.2938501238822937e-01
    z[8,9,1]  R2537     -1.5268255770206451e-01
    z[8,9,1]  R2538     -9.6914544701576233e-02
    z[8,9,1]  R2539     -1.2869754433631897e-01
    z[8,9,1]  R2540     -3.8322377204895020e-01
    z[8,9,1]  R2541     -6.1499518156051636e-01
    z[8,9,1]  R2542     1.0826831310987473e-01
    z[8,9,1]  R2543     4.4784832000732422e-01
    z[8,9,1]  R2544     1.4900089800357819e-01
    z[8,9,1]  R2545     0.413095086812973
    z[8,9,1]  R2546     -2.4542917311191559e-01
    z[8,9,1]  R2547     8.2061541080474854e-01
    z[8,9,1]  R2548     1.3012255728244781e-01
    z[8,9,1]  R2549     -7.1297782659530640e-01
    z[8,9,1]  R2550     2.6907867193222046e-01
    z[8,9,1]  R2551     0.342650443315506
    z[8,9,1]  R2552     4.7802817821502686e-01
    z[8,9,1]  R2553     3.4184309840202332e-01
    z[8,9,1]  R2554     4.0005022287368774e-01
    z[8,9,1]  R2555     5.2099019289016724e-01
    z[8,9,1]  R2556     -4.3250057101249695e-01
    z[8,9,1]  R2557     5.7302784919738770e-01
    z[8,9,1]  R2558     1.4423719048500061e-01
    z[8,9,1]  R2559     1.1946291476488113e-01
    z[8,9,1]  R2560     4.7665104269981384e-02
    z[8,9,1]  R2561     3.2784324884414673e-01
    z[8,9,2]  R76       -1
    z[8,9,2]  R85       1
    z[8,9,2]  R2442     -1
    z[8,9,2]  R2443     1
    z[8,9,2]  R2452     -3.6354590207338333e-02
    z[8,9,2]  R2453     -2.7984252572059631e-01
    z[8,9,2]  R2454     -0.00863682571798563
    z[8,9,2]  R2455     -2.5398376584053040e-01
    z[8,9,2]  R2456     -4.2689961194992065e-01
    z[8,9,2]  R2457     3.2003694772720337e-01
    z[8,9,2]  R2458     1.3535057008266449e-01
    z[8,9,2]  R2459     -3.9969551563262939e-01
    z[8,9,2]  R2460     1.6448435187339783e-01
    z[8,9,2]  R2461     1.7573493719100952e-01
    z[8,9,2]  R2462     4.6703219413757324e-01
    z[8,9,2]  R2463     2.1635392308235168e-01
    z[8,9,2]  R2464     1.6247582435607910e-01
    z[8,9,2]  R2465     1.7877030372619629e-01
    z[8,9,2]  R2466     -6.9348454475402832e-02
    z[8,9,2]  R2467     2.6478347182273865e-01
    z[8,9,2]  R2468     4.5628994703292847e-02
    z[8,9,2]  R2469     1.8481417000293732e-01
    z[8,9,2]  R2470     4.2502439022064209e-01
    z[8,9,2]  R2471     8.1140503287315369e-02
    z[8,9,2]  R2472     5.0389105081558228e-01
    z[8,9,2]  R2473     3.9021718502044678e-01
    z[8,9,2]  R2474     7.0239871740341187e-01
    z[8,9,2]  R2475     3.2019799947738647e-01
    z[8,9,2]  R2476     -6.0397596098482609e-03
    z[8,9,2]  R2477     -4.7329090535640717e-02
    z[8,9,2]  R2478     -1.8379144370555878e-02
    z[8,9,2]  R2479     5.7520174980163574e-01
    z[8,9,2]  R2480     0.642295241355896
    z[8,9,2]  R2481     3.9481487870216370e-01
    z[8,9,2]  R2482     4.0127193927764893e-01
    z[8,9,2]  R2483     -2.4796979129314423e-01
    z[8,9,2]  R2484     6.5727323293685913e-02
    z[8,9,2]  R2485     -6.7530685663223267e-01
    z[8,9,2]  R2486     -5.8397132158279419e-01
    z[8,9,2]  R2487     -5.4952836036682129e-01
    z[8,9,2]  R2488     -3.1262585520744324e-01
    z[8,9,2]  R2489     -5.2683001756668091e-01
    z[8,9,2]  R2490     -7.5382733345031738e-01
    z[8,9,2]  R2491     -7.3114919662475586e-01
    z[8,9,2]  R2492     5.2697986364364624e-01
    z[8,9,2]  R2493     3.8458457589149475e-01
    z[8,9,2]  R2494     4.0947649627923965e-02
    z[8,9,2]  R2495     2.8311860561370850e-01
    z[8,9,2]  R2496     3.5711872577667236e-01
    z[8,9,2]  R2497     -5.0671335309743881e-02
    z[8,9,2]  R2498     -1.1463362723588943e-01
    z[8,9,2]  R2499     -7.8487031161785126e-02
    z[8,9,2]  R2500     -2.1065986156463623e-01
    z[8,9,2]  R2501     -4.0730472654104233e-02
    z[8,9,2]  R2502     6.3772797584533691e-01
    z[8,9,2]  R2503     7.4824534356594086e-02
    z[8,9,2]  R2504     1.8205539882183075e-01
    z[8,9,2]  R2505     -1.8323624506592751e-02
    z[8,9,2]  R2506     2.4640716612339020e-01
    z[8,9,2]  R2507     -1.8924209475517273e-01
    z[8,9,2]  R2508     -4.0736806392669678e-01
    z[8,9,2]  R2509     1.0924704372882843e-01
    z[8,9,2]  R2510     -2.3694667220115662e-01
    z[8,9,2]  R2511     -4.2501190304756165e-01
    z[8,9,2]  R2512     5.0463789701461792e-01
    z[8,9,2]  R2513     2.1183522045612335e-01
    z[8,9,2]  R2514     1.3079099357128143e-01
    z[8,9,2]  R2515     2.2281858325004578e-01
    z[8,9,2]  R2516     -3.7268076092004776e-02
    z[8,9,2]  R2517     5.2665509283542633e-02
    z[8,9,2]  R2518     6.3711577653884888e-01
    z[8,9,2]  R2519     -2.4388581514358521e-03
    z[8,9,2]  R2520     -3.2720527052879333e-01
    z[8,9,2]  R2521     3.9461705088615417e-01
    z[8,9,2]  R2522     1.0636379569768906e-01
    z[8,9,2]  R2523     -3.1514503061771393e-03
    z[8,9,2]  R2524     0.0676359236240387
    z[8,9,2]  R2525     2.4678535759449005e-01
    z[8,9,2]  R2526     3.8335734605789185e-01
    z[8,9,2]  R2527     0.0618075467646122
    z[8,9,2]  R2528     2.2087465226650238e-01
    z[8,9,2]  R2529     -2.5211388710886240e-03
    z[8,9,2]  R2530     -4.1485149413347244e-02
    z[8,9,2]  R2531     2.1859072148799896e-01
    z[8,9,2]  R2532     -0.0520876981317997
    z[8,9,2]  R2533     -1.4615756273269653e-01
    z[8,9,2]  R2534     -7.7589017152786255e-01
    z[8,9,2]  R2535     4.7463127970695496e-01
    z[8,9,2]  R2536     -5.5337548255920410e-01
    z[8,9,2]  R2537     -6.3175731897354126e-01
    z[8,9,2]  R2538     5.8389431238174438e-01
    z[8,9,2]  R2539     5.9024572372436523e-01
    z[8,9,2]  R2540     -5.0399124622344971e-01
    z[8,9,2]  R2541     -1.4449145644903183e-02
    z[8,9,2]  R2542     4.6048730611801147e-01
    z[8,9,2]  R2543     6.6099238395690918e-01
    z[8,9,2]  R2544     9.0163767337799072e-02
    z[8,9,2]  R2545     -7.6733380556106567e-02
    z[8,9,2]  R2546     4.7940242290496826e-01
    z[8,9,2]  R2547     -1.9397798180580139e-01
    z[8,9,2]  R2548     3.3856812119483948e-01
    z[8,9,2]  R2549     -2.4168695509433746e-01
    z[8,9,2]  R2550     1.6360796988010406e-01
    z[8,9,2]  R2551     -1.9548648595809937e-01
    z[8,9,2]  R2552     4.8458430171012878e-01
    z[8,9,2]  R2553     2.2467520087957382e-02
    z[8,9,2]  R2554     6.4751081168651581e-02
    z[8,9,2]  R2555     -6.5491750836372375e-02
    z[8,9,2]  R2556     -3.0540412664413452e-01
    z[8,9,2]  R2557     1.4728691428899765e-02
    z[8,9,2]  R2558     2.0782814919948578e-01
    z[8,9,2]  R2559     0.5059814453125
    z[8,9,2]  R2560     3.3739551901817322e-01
    z[8,9,2]  R2561     1.1924399994313717e-02
    z[8,9,3]  R77       -1
    z[8,9,3]  R86       1
    z[8,9,3]  R2444     -1
    z[8,9,3]  R2445     1
    z[8,9,3]  R2452     -2.4049256742000580e-01
    z[8,9,3]  R2453     -1.8227960169315338e-01
    z[8,9,3]  R2454     -1.8367478251457214e-01
    z[8,9,3]  R2455     -2.1280041337013245e-01
    z[8,9,3]  R2456     -2.0879431068897247e-01
    z[8,9,3]  R2457     -2.2890414297580719e-01
    z[8,9,3]  R2458     -1.2697722017765045e-01
    z[8,9,3]  R2459     -1.5663371980190277e-01
    z[8,9,3]  R2460     1.1656701564788818e-01
    z[8,9,3]  R2461     1.3841967284679413e-01
    z[8,9,3]  R2462     -8.7010592222213745e-02
    z[8,9,3]  R2463     6.7712718248367310e-01
    z[8,9,3]  R2464     6.4832371473312378e-01
    z[8,9,3]  R2465     6.1362695693969727e-01
    z[8,9,3]  R2466     4.8928019404411316e-01
    z[8,9,3]  R2467     6.0580068826675415e-01
    z[8,9,3]  R2468     2.9120427370071411e-01
    z[8,9,3]  R2469     3.3687943220138550e-01
    z[8,9,3]  R2470     3.2745805382728577e-01
    z[8,9,3]  R2471     5.7278507947921753e-01
    z[8,9,3]  R2472     -4.6318760514259338e-01
    z[8,9,3]  R2473     3.5891026258468628e-01
    z[8,9,3]  R2474     -4.9805739521980286e-01
    z[8,9,3]  R2475     -3.4513863921165466e-01
    z[8,9,3]  R2476     -7.7164888381958008e-01
    z[8,9,3]  R2477     2.2541718184947968e-01
    z[8,9,3]  R2478     -2.8522717952728271e-01
    z[8,9,3]  R2479     8.7847806513309479e-02
    z[8,9,3]  R2480     -2.8901886940002441e-01
    z[8,9,3]  R2481     5.1158016920089722e-01
    z[8,9,3]  R2482     -2.6556468009948730e-01
    z[8,9,3]  R2483     -1.1575835943222046e-01
    z[8,9,3]  R2484     -7.4994575977325439e-01
    z[8,9,3]  R2485     -1.3088975846767426e-01
    z[8,9,3]  R2486     -1.5370818972587585e-01
    z[8,9,3]  R2487     -0.136946439743042
    z[8,9,3]  R2488     -3.2947468757629395e-01
    z[8,9,3]  R2489     -2.2416210174560547e-01
    z[8,9,3]  R2490     -1.1424796283245087e-01
    z[8,9,3]  R2491     3.1601503491401672e-02
    z[8,9,3]  R2492     1.7844025790691376e-01
    z[8,9,3]  R2493     9.4157420098781586e-02
    z[8,9,3]  R2494     -4.8243671655654907e-01
    z[8,9,3]  R2495     1.7940548062324524e-01
    z[8,9,3]  R2496     -7.8748118877410889e-01
    z[8,9,3]  R2497     -1.9369816780090332e-01
    z[8,9,3]  R2498     4.6675175428390503e-01
    z[8,9,3]  R2499     -2.1306182444095612e-01
    z[8,9,3]  R2500     6.8165791034698486e-01
    z[8,9,3]  R2501     -2.6813134551048279e-01
    z[8,9,3]  R2502     -9.8371699452400208e-02
    z[8,9,3]  R2503     -2.9901558160781860e-01
    z[8,9,3]  R2504     -6.8399451673030853e-02
    z[8,9,3]  R2505     -1.7771961167454720e-02
    z[8,9,3]  R2506     -3.3625584840774536e-01
    z[8,9,3]  R2507     -3.8571050763130188e-01
    z[8,9,3]  R2508     -3.6949291825294495e-01
    z[8,9,3]  R2509     2.4150632321834564e-01
    z[8,9,3]  R2510     5.7673478126525879e-01
    z[8,9,3]  R2511     6.2681674957275391e-01
    z[8,9,3]  R2512     -1.0172878205776215e-01
    z[8,9,3]  R2513     2.9667043685913086e-01
    z[8,9,3]  R2514     1.1939336359500885e-01
    z[8,9,3]  R2515     -2.9703578352928162e-01
    z[8,9,3]  R2516     3.4623626619577408e-02
    z[8,9,3]  R2517     -3.6751374602317810e-01
    z[8,9,3]  R2518     -3.2996940612792969e-01
    z[8,9,3]  R2519     -2.0167191326618195e-01
    z[8,9,3]  R2520     -1.8123102188110352e-01
    z[8,9,3]  R2521     -1.0467819869518280e-01
    z[8,9,3]  R2522     0.279776394367218
    z[8,9,3]  R2523     7.4402558803558350e-01
    z[8,9,3]  R2524     5.3678333759307861e-01
    z[8,9,3]  R2525     5.6045120954513550e-01
    z[8,9,3]  R2526     4.6524614095687866e-01
    z[8,9,3]  R2527     4.5251858234405518e-01
    z[8,9,3]  R2528     3.9085876941680908e-01
    z[8,9,3]  R2529     4.6487808227539062e-01
    z[8,9,3]  R2530     7.6949393749237061e-01
    z[8,9,3]  R2531     0.788844883441925
    z[8,9,3]  R2532     -8.9666461944580078e-01
    z[8,9,3]  R2533     -8.4360587596893311e-01
    z[8,9,3]  R2534     2.8829258680343628e-01
    z[8,9,3]  R2535     -6.7255079746246338e-01
    z[8,9,3]  R2536     -8.7308675050735474e-02
    z[8,9,3]  R2537     -3.8905474543571472e-01
    z[8,9,3]  R2538     1.9464203715324402e-01
    z[8,9,3]  R2539     2.5558346509933472e-01
    z[8,9,3]  R2540     -3.0210450291633606e-01
    z[8,9,3]  R2541     4.8521433025598526e-02
    z[8,9,3]  R2542     -6.6162657737731934e-01
    z[8,9,3]  R2543     -0.0974312275648117
    z[8,9,3]  R2544     -5.6235814094543457e-01
    z[8,9,3]  R2545     -8.3075851202011108e-01
    z[8,9,3]  R2546     -5.5331909656524658e-01
    z[8,9,3]  R2547     1.8006226420402527e-01
    z[8,9,3]  R2548     6.6044223308563232e-01
    z[8,9,3]  R2549     2.1907755732536316e-01
    z[8,9,3]  R2550     2.4703326821327209e-01
    z[8,9,3]  R2551     1.1764498800039291e-01
    z[8,9,3]  R2552     -0.595727801322937
    z[8,9,3]  R2553     -7.4787449836730957e-01
    z[8,9,3]  R2554     -0.720929741859436
    z[8,9,3]  R2555     2.8892710804939270e-01
    z[8,9,3]  R2556     -3.9735764265060425e-01
    z[8,9,3]  R2557     5.5459076166152954e-01
    z[8,9,3]  R2558     4.6066072583198547e-01
    z[8,9,3]  R2559     4.0360546112060547e-01
    z[8,9,3]  R2560     1.0930617898702621e-01
    z[8,9,3]  R2561     2.4287261068820953e-01
    z[8,9,4]  R78       -1
    z[8,9,4]  R87       1
    z[8,9,4]  R2446     -1
    z[8,9,4]  R2447     1
    z[8,9,4]  R2452     4.7157740592956543e-01
    z[8,9,4]  R2453     -5.2349831908941269e-02
    z[8,9,4]  R2454     -1.3976477086544037e-01
    z[8,9,4]  R2455     2.9161083698272705e-01
    z[8,9,4]  R2456     -3.2475203275680542e-02
    z[8,9,4]  R2457     0.745089054107666
    z[8,9,4]  R2458     -7.4821531772613525e-02
    z[8,9,4]  R2459     -1.2268606573343277e-01
    z[8,9,4]  R2460     2.7033528685569763e-01
    z[8,9,4]  R2461     3.1954219937324524e-01
    z[8,9,4]  R2462     -4.0138435363769531e-01
    z[8,9,4]  R2463     -0.0943312868475914
    z[8,9,4]  R2464     1.3736635446548462e-01
    z[8,9,4]  R2465     -1.0122365504503250e-01
    z[8,9,4]  R2466     -3.8699424266815186e-01
    z[8,9,4]  R2467     -5.2707046270370483e-02
    z[8,9,4]  R2468     -3.8135918974876404e-01
    z[8,9,4]  R2469     -1.6239321231842041e-01
    z[8,9,4]  R2470     -3.1952168792486191e-02
    z[8,9,4]  R2471     -2.7643764019012451e-01
    z[8,9,4]  R2472     7.9723246395587921e-02
    z[8,9,4]  R2473     3.1396403908729553e-02
    z[8,9,4]  R2474     1.6028310358524323e-01
    z[8,9,4]  R2475     -3.3956998586654663e-01
    z[8,9,4]  R2476     -4.7288507223129272e-01
    z[8,9,4]  R2477     -6.5615504980087280e-01
    z[8,9,4]  R2478     -6.0443294048309326e-01
    z[8,9,4]  R2479     5.7951617240905762e-01
    z[8,9,4]  R2480     8.9810833334922791e-02
    z[8,9,4]  R2481     1.0060887038707733e-01
    z[8,9,4]  R2482     4.5800673961639404e-01
    z[8,9,4]  R2483     -2.1552371978759766e-01
    z[8,9,4]  R2484     3.7567341327667236e-01
    z[8,9,4]  R2485     2.7588644623756409e-01
    z[8,9,4]  R2486     1.0778700560331345e-01
    z[8,9,4]  R2487     8.4838949143886566e-02
    z[8,9,4]  R2488     -6.3639283180236816e-02
    z[8,9,4]  R2489     1.5019574761390686e-01
    z[8,9,4]  R2490     9.2797234654426575e-02
    z[8,9,4]  R2491     -5.2797406911849976e-02
    z[8,9,4]  R2492     3.9403277635574341e-01
    z[8,9,4]  R2493     -3.3162882924079895e-01
    z[8,9,4]  R2494     -6.2922318466007710e-03
    z[8,9,4]  R2495     -1.2952215969562531e-01
    z[8,9,4]  R2496     4.7503627836704254e-02
    z[8,9,4]  R2497     3.4745806455612183e-01
    z[8,9,4]  R2498     -8.5709132254123688e-02
    z[8,9,4]  R2499     3.7121790647506714e-01
    z[8,9,4]  R2500     7.4765356257557869e-03
    z[8,9,4]  R2501     2.4638114869594574e-01
    z[8,9,4]  R2502     -1.0565236210823059e-01
    z[8,9,4]  R2503     2.7540171146392822e-01
    z[8,9,4]  R2504     -5.3796207904815674e-01
    z[8,9,4]  R2505     -8.4774866700172424e-02
    z[8,9,4]  R2506     -1.0620661079883575e-01
    z[8,9,4]  R2507     3.7548542022705078e-01
    z[8,9,4]  R2508     -1.1374235898256302e-01
    z[8,9,4]  R2509     6.3498369418084621e-03
    z[8,9,4]  R2510     -6.4141921699047089e-02
    z[8,9,4]  R2511     -1.3149622082710266e-01
    z[8,9,4]  R2512     1.2485647201538086e-01
    z[8,9,4]  R2513     1.2310385704040527e-01
    z[8,9,4]  R2514     9.4127535820007324e-02
    z[8,9,4]  R2515     -2.7633709833025932e-02
    z[8,9,4]  R2516     6.7929677665233612e-02
    z[8,9,4]  R2517     3.4966897964477539e-01
    z[8,9,4]  R2518     -2.3460452258586884e-01
    z[8,9,4]  R2519     2.3682729899883270e-01
    z[8,9,4]  R2520     1.4008422195911407e-01
    z[8,9,4]  R2521     -4.9797093868255615e-01
    z[8,9,4]  R2522     -0.0261647067964077
    z[8,9,4]  R2523     -3.1128239631652832e-01
    z[8,9,4]  R2524     -1.7917363345623016e-01
    z[8,9,4]  R2525     1.4596521854400635e-01
    z[8,9,4]  R2526     -7.2413086891174316e-02
    z[8,9,4]  R2527     -3.8450222462415695e-02
    z[8,9,4]  R2528     -1.3183638453483582e-01
    z[8,9,4]  R2529     -2.1108466386795044e-01
    z[8,9,4]  R2530     -2.5628310441970825e-01
    z[8,9,4]  R2531     -1.5942068397998810e-01
    z[8,9,4]  R2532     1.7088495194911957e-01
    z[8,9,4]  R2533     -2.4839282035827637e-01
    z[8,9,4]  R2534     -2.4773180484771729e-02
    z[8,9,4]  R2535     -1.0599285364151001e-01
    z[8,9,4]  R2536     -3.3445760607719421e-01
    z[8,9,4]  R2537     -1.4131318032741547e-01
    z[8,9,4]  R2538     -2.6053443551063538e-01
    z[8,9,4]  R2539     -7.1282930672168732e-02
    z[8,9,4]  R2540     -4.5570683479309082e-01
    z[8,9,4]  R2541     -5.4738348722457886e-01
    z[8,9,4]  R2542     -1.4750123023986816e-01
    z[8,9,4]  R2543     0.0989510715007782
    z[8,9,4]  R2544     -0.514692485332489
    z[8,9,4]  R2545     -1.6152802109718323e-01
    z[8,9,4]  R2546     -4.8854687809944153e-01
    z[8,9,4]  R2547     -1.6791987419128418e-01
    z[8,9,4]  R2548     1.0922468453645706e-01
    z[8,9,4]  R2549     -4.6905669569969177e-01
    z[8,9,4]  R2550     8.1659637391567230e-02
    z[8,9,4]  R2551     1.8564572930335999e-01
    z[8,9,4]  R2552     1.2279351055622101e-01
    z[8,9,4]  R2553     -4.2905974388122559e-01
    z[8,9,4]  R2554     -3.3084303140640259e-01
    z[8,9,4]  R2555     -3.2869505882263184e-01
    z[8,9,4]  R2556     -2.5666296482086182e-01
    z[8,9,4]  R2557     -1.7523898184299469e-01
    z[8,9,4]  R2558     -1.7954197525978088e-01
    z[8,9,4]  R2559     -1.9712452590465546e-01
    z[8,9,4]  R2560     -2.9913255944848061e-02
    z[8,9,4]  R2561     -1.8272459506988525e-01
    z[8,9,5]  R79       -1
    z[8,9,5]  R88       1
    z[8,9,5]  R2448     -1
    z[8,9,5]  R2449     1
    z[8,9,5]  R2452     2.5104042887687683e-01
    z[8,9,5]  R2453     -8.7841480970382690e-02
    z[8,9,5]  R2454     -1.9002674520015717e-01
    z[8,9,5]  R2455     3.6660602688789368e-01
    z[8,9,5]  R2456     3.5867232084274292e-01
    z[8,9,5]  R2457     -1.9685764610767365e-01
    z[8,9,5]  R2458     -2.3646345734596252e-01
    z[8,9,5]  R2459     4.7210484743118286e-01
    z[8,9,5]  R2460     3.0779346823692322e-01
    z[8,9,5]  R2461     1.9148269295692444e-01
    z[8,9,5]  R2462     -5.3942728042602539e-01
    z[8,9,5]  R2463     -2.4274408817291260e-02
    z[8,9,5]  R2464     -6.3160099089145660e-02
    z[8,9,5]  R2465     1.4341041445732117e-01
    z[8,9,5]  R2466     -3.2551422715187073e-02
    z[8,9,5]  R2467     1.0987445712089539e-01
    z[8,9,5]  R2468     -9.7465276718139648e-02
    z[8,9,5]  R2469     -1.5779529511928558e-01
    z[8,9,5]  R2470     -7.3694236576557159e-02
    z[8,9,5]  R2471     -3.8061082363128662e-01
    z[8,9,5]  R2472     1.9135256111621857e-01
    z[8,9,5]  R2473     -3.3060204982757568e-01
    z[8,9,5]  R2474     -3.1885802745819092e-01
    z[8,9,5]  R2475     5.9416841715574265e-02
    z[8,9,5]  R2476     3.0407893657684326e-01
    z[8,9,5]  R2477     8.8839247822761536e-02
    z[8,9,5]  R2478     3.5376599431037903e-01
    z[8,9,5]  R2479     -3.2122090458869934e-01
    z[8,9,5]  R2480     -4.5879325270652771e-01
    z[8,9,5]  R2481     -6.0984903573989868e-01
    z[8,9,5]  R2482     -2.6245990395545959e-01
    z[8,9,5]  R2483     0.254169762134552
    z[8,9,5]  R2484     4.5750427246093750e-01
    z[8,9,5]  R2485     -4.0662378072738647e-01
    z[8,9,5]  R2486     -3.9159911870956421e-01
    z[8,9,5]  R2487     -4.9317845702171326e-01
    z[8,9,5]  R2488     2.2540882229804993e-01
    z[8,9,5]  R2489     -2.3525390028953552e-01
    z[8,9,5]  R2490     -4.6838164329528809e-01
    z[8,9,5]  R2491     -1.1270120739936829e-01
    z[8,9,5]  R2492     -1.2917117774486542e-01
    z[8,9,5]  R2493     -2.8374055027961731e-01
    z[8,9,5]  R2494     -2.3278048634529114e-01
    z[8,9,5]  R2495     -1.2248796969652176e-01
    z[8,9,5]  R2496     -1.9105631113052368e-01
    z[8,9,5]  R2497     1.1361550539731979e-02
    z[8,9,5]  R2498     0.294919490814209
    z[8,9,5]  R2499     3.6078030243515968e-03
    z[8,9,5]  R2500     -5.7003190740942955e-03
    z[8,9,5]  R2501     1.1956840753555298e-01
    z[8,9,5]  R2502     -4.0403288602828979e-01
    z[8,9,5]  R2503     -2.6048877835273743e-01
    z[8,9,5]  R2504     1.2340676039457321e-01
    z[8,9,5]  R2505     5.8245950937271118e-01
    z[8,9,5]  R2506     2.0201133564114571e-02
    z[8,9,5]  R2507     2.8838792443275452e-01
    z[8,9,5]  R2508     4.0955805778503418e-01
    z[8,9,5]  R2509     -1.9069863855838776e-01
    z[8,9,5]  R2510     -1.3184095919132233e-01
    z[8,9,5]  R2511     1.8675215542316437e-02
    z[8,9,5]  R2512     1.6958688199520111e-01
    z[8,9,5]  R2513     -1.6247332096099854e-02
    z[8,9,5]  R2514     -0.414997398853302
    z[8,9,5]  R2515     2.4028332531452179e-01
    z[8,9,5]  R2516     2.1356710791587830e-01
    z[8,9,5]  R2517     -3.4443348646163940e-01
    z[8,9,5]  R2518     3.2018628716468811e-01
    z[8,9,5]  R2519     -1.2827628850936890e-01
    z[8,9,5]  R2520     2.9745748639106750e-01
    z[8,9,5]  R2521     3.3233964443206787e-01
    z[8,9,5]  R2522     -2.3302085697650909e-01
    z[8,9,5]  R2523     -1.5327532589435577e-01
    z[8,9,5]  R2524     -1.3046006858348846e-01
    z[8,9,5]  R2525     1.1618450284004211e-01
    z[8,9,5]  R2526     -1.0945549607276917e-01
    z[8,9,5]  R2527     -3.8443204760551453e-01
    z[8,9,5]  R2528     -3.7906184792518616e-01
    z[8,9,5]  R2529     -4.3311020731925964e-01
    z[8,9,5]  R2530     3.5544145852327347e-02
    z[8,9,5]  R2531     1.2966738641262054e-01
    z[8,9,5]  R2532     1.0781476646661758e-01
    z[8,9,5]  R2533     -1.6917613148689270e-01
    z[8,9,5]  R2534     -1.6113029420375824e-01
    z[8,9,5]  R2535     -2.5836187601089478e-01
    z[8,9,5]  R2536     -2.8022146224975586e-01
    z[8,9,5]  R2537     -4.7952279448509216e-01
    z[8,9,5]  R2538     8.8292052969336510e-03
    z[8,9,5]  R2539     4.8833701014518738e-01
    z[8,9,5]  R2540     5.2868378162384033e-01
    z[8,9,5]  R2541     5.1520484685897827e-01
    z[8,9,5]  R2542     -4.6827748417854309e-01
    z[8,9,5]  R2543     -5.4940879344940186e-01
    z[8,9,5]  R2544     4.6486946940422058e-01
    z[8,9,5]  R2545     -1.9641081988811493e-01
    z[8,9,5]  R2546     1.2209662795066833e-01
    z[8,9,5]  R2547     4.7225895524024963e-01
    z[8,9,5]  R2548     1.2973374128341675e-01
    z[8,9,5]  R2549     2.1981272101402283e-01
    z[8,9,5]  R2550     -2.7609056234359741e-01
    z[8,9,5]  R2551     3.6554217338562012e-01
    z[8,9,5]  R2552     2.4138320982456207e-01
    z[8,9,5]  R2553     1.0179761797189713e-01
    z[8,9,5]  R2554     4.6536628156900406e-02
    z[8,9,5]  R2555     -1.4922022819519043e-01
    z[8,9,5]  R2556     1.5973517298698425e-01
    z[8,9,5]  R2557     -1.0053821653127670e-01
    z[8,9,5]  R2558     4.4184795022010803e-01
    z[8,9,5]  R2559     0.357094407081604
    z[8,9,5]  R2560     1.5882861614227295e-01
    z[8,9,5]  R2561     -3.1715262681245804e-02
    z[8,9,6]  R80       -1
    z[8,9,6]  R89       1
    z[8,9,6]  R2450     -1
    z[8,9,6]  R2451     1
    z[8,9,6]  R2452     0.0672181099653244
    z[8,9,6]  R2453     -2.8849324584007263e-01
    z[8,9,6]  R2454     -3.2158580422401428e-01
    z[8,9,6]  R2455     -5.9678763151168823e-01
    z[8,9,6]  R2456     -5.3172874450683594e-01
    z[8,9,6]  R2457     -2.8782900422811508e-02
    z[8,9,6]  R2458     5.2817636728286743e-01
    z[8,9,6]  R2459     -3.6818888783454895e-01
    z[8,9,6]  R2460     0.508339524269104
    z[8,9,6]  R2461     -6.6201704740524292e-01
    z[8,9,6]  R2462     -4.2290541529655457e-01
    z[8,9,6]  R2463     -1.4083603024482727e-01
    z[8,9,6]  R2464     7.4627533555030823e-02
    z[8,9,6]  R2465     1.8405258655548096e-01
    z[8,9,6]  R2466     1.0553563386201859e-01
    z[8,9,6]  R2467     -7.8094065189361572e-02
    z[8,9,6]  R2468     5.1657155156135559e-02
    z[8,9,6]  R2469     1.0284334421157837e-01
    z[8,9,6]  R2470     -7.3660321533679962e-02
    z[8,9,6]  R2471     -2.5152249261736870e-02
    z[8,9,6]  R2472     -2.8996374458074570e-02
    z[8,9,6]  R2473     -4.4978532195091248e-01
    z[8,9,6]  R2474     -1.1239292472600937e-01
    z[8,9,6]  R2475     6.2321919202804565e-01
    z[8,9,6]  R2476     4.0963903069496155e-02
    z[8,9,6]  R2477     0.0159404706209898
    z[8,9,6]  R2478     -2.6013967394828796e-01
    z[8,9,6]  R2479     3.3024734258651733e-01
    z[8,9,6]  R2480     4.3401810526847839e-01
    z[8,9,6]  R2481     2.9446718096733093e-01
    z[8,9,6]  R2482     -5.2711308002471924e-01
    z[8,9,6]  R2483     1.6469725966453552e-01
    z[8,9,6]  R2484     -1.2055918574333191e-01
    z[8,9,6]  R2485     -5.2877198904752731e-02
    z[8,9,6]  R2486     9.4701521098613739e-02
    z[8,9,6]  R2487     -1.5367236733436584e-01
    z[8,9,6]  R2488     0.603775680065155
    z[8,9,6]  R2489     -1.6113768517971039e-01
    z[8,9,6]  R2490     1.5535804629325867e-01
    z[8,9,6]  R2491     -1.3475976884365082e-01
    z[8,9,6]  R2492     -1.2325000762939453e-01
    z[8,9,6]  R2493     -1.5239277482032776e-01
    z[8,9,6]  R2494     -3.2360067963600159e-01
    z[8,9,6]  R2495     -5.7558751106262207e-01
    z[8,9,6]  R2496     7.7643796801567078e-02
    z[8,9,6]  R2497     -6.7058050632476807e-01
    z[8,9,6]  R2498     3.3016854524612427e-01
    z[8,9,6]  R2499     6.2257814407348633e-01
    z[8,9,6]  R2500     0.0656309723854065
    z[8,9,6]  R2501     1.2210515886545181e-01
    z[8,9,6]  R2502     -1.0634802281856537e-01
    z[8,9,6]  R2503     -1.1415829509496689e-01
    z[8,9,6]  R2504     1.6399851068854332e-02
    z[8,9,6]  R2505     1.9085927307605743e-01
    z[8,9,6]  R2506     1.2006171047687531e-02
    z[8,9,6]  R2507     4.4095784425735474e-01
    z[8,9,6]  R2508     0.500533401966095
    z[8,9,6]  R2509     -2.0012147724628448e-01
    z[8,9,6]  R2510     -4.1568791866302490e-01
    z[8,9,6]  R2511     -2.4620507657527924e-01
    z[8,9,6]  R2512     -2.8365132212638855e-01
    z[8,9,6]  R2513     3.5866007208824158e-02
    z[8,9,6]  R2514     7.9198144376277924e-02
    z[8,9,6]  R2515     -1.0546236485242844e-01
    z[8,9,6]  R2516     -6.1719194054603577e-02
    z[8,9,6]  R2517     -0.192262202501297
    z[8,9,6]  R2518     -6.0034235939383507e-03
    z[8,9,6]  R2519     -3.2536983489990234e-01
    z[8,9,6]  R2520     -1.1985626071691513e-01
    z[8,9,6]  R2521     2.8894510865211487e-01
    z[8,9,6]  R2522     -0.0785093605518341
    z[8,9,6]  R2523     -1.2693412601947784e-01
    z[8,9,6]  R2524     -4.4996868818998337e-02
    z[8,9,6]  R2525     -5.2526675164699554e-02
    z[8,9,6]  R2526     -2.6417663693428040e-01
    z[8,9,6]  R2527     1.3278764486312866e-01
    z[8,9,6]  R2528     -2.2593078017234802e-01
    z[8,9,6]  R2529     -7.3157578706741333e-02
    z[8,9,6]  R2530     1.2063318490982056e-01
    z[8,9,6]  R2531     -0.0679294764995575
    z[8,9,6]  R2532     -3.0027189850807190e-01
    z[8,9,6]  R2533     2.9272112250328064e-01
    z[8,9,6]  R2534     2.3087087273597717e-01
    z[8,9,6]  R2535     1.8146304786205292e-01
    z[8,9,6]  R2536     4.5979449152946472e-01
    z[8,9,6]  R2537     3.8912755250930786e-01
    z[8,9,6]  R2538     2.6222813129425049e-01
    z[8,9,6]  R2539     -1.9972331821918488e-01
    z[8,9,6]  R2540     1.3624365627765656e-01
    z[8,9,6]  R2541     2.0632030069828033e-01
    z[8,9,6]  R2542     2.8304985165596008e-01
    z[8,9,6]  R2543     1.7174871265888214e-01
    z[8,9,6]  R2544     2.4364647269248962e-01
    z[8,9,6]  R2545     2.2965441644191742e-01
    z[8,9,6]  R2546     3.0025640130043030e-01
    z[8,9,6]  R2547     7.2059154510498047e-02
    z[8,9,6]  R2548     -7.1399368345737457e-02
    z[8,9,6]  R2549     2.9443749785423279e-01
    z[8,9,6]  R2550     1.8247225880622864e-01
    z[8,9,6]  R2551     -2.4384070932865143e-01
    z[8,9,6]  R2552     -2.9707708954811096e-01
    z[8,9,6]  R2553     3.2829120755195618e-01
    z[8,9,6]  R2554     0.302583247423172
    z[8,9,6]  R2555     4.8948684334754944e-01
    z[8,9,6]  R2556     4.5234248042106628e-02
    z[8,9,6]  R2557     9.0449877083301544e-02
    z[8,9,6]  R2558     5.1024246960878372e-02
    z[8,9,6]  R2559     6.7944198846817017e-02
    z[8,9,6]  R2560     0.000320744322380051
    z[8,9,6]  R2561     3.4085190296173096e-01
    z[9,8,0]  R74       1
    z[9,8,0]  R83       -1
    z[9,8,0]  R2562     -1
    z[9,8,0]  R2563     1
    z[9,8,0]  R2576     -6.8731087446212769e-01
    z[9,8,0]  R2577     1.8868595361709595e-01
    z[9,8,0]  R2578     0.314831018447876
    z[9,8,0]  R2579     -6.5993182361125946e-02
    z[9,8,0]  R2580     6.4107263088226318e-01
    z[9,8,0]  R2581     -0.579894483089447
    z[9,8,0]  R2582     -3.6888748407363892e-01
    z[9,8,0]  R2583     -0.0707937628030777
    z[9,8,0]  R2584     3.2471904158592224e-01
    z[9,8,0]  R2585     -4.9675229191780090e-01
    z[9,8,0]  R2586     6.8372559547424316e-01
    z[9,8,0]  R2587     0.373611181974411
    z[9,8,0]  R2588     7.1792131662368774e-01
    z[9,8,0]  R2589     5.4708194732666016e-01
    z[9,8,0]  R2590     6.4950835704803467e-01
    z[9,8,0]  R2591     5.0930714607238770e-01
    z[9,8,0]  R2592     5.6132233142852783e-01
    z[9,8,0]  R2593     5.0749319791793823e-01
    z[9,8,0]  R2594     4.6792671084403992e-01
    z[9,8,0]  R2595     4.3902179598808289e-01
    z[9,8,0]  R2596     2.2824968397617340e-01
    z[9,8,0]  R2597     2.9348272085189819e-01
    z[9,8,0]  R2598     -4.1523975133895874e-01
    z[9,8,0]  R2599     4.0554103255271912e-01
    z[9,8,0]  R2600     -4.1935831308364868e-01
    z[9,8,0]  R2601     -1.5771935880184174e-01
    z[9,8,0]  R2602     6.8925315141677856e-01
    z[9,8,0]  R2603     5.3505182266235352e-01
    z[9,8,0]  R2604     -4.6125955879688263e-02
    z[9,8,0]  R2605     1.0763436555862427e-01
    z[9,8,0]  R2606     -1.3161328434944153e-01
    z[9,8,0]  R2607     -1.0903768241405487e-01
    z[9,8,0]  R2608     3.3622455596923828e-01
    z[9,8,0]  R2609     -1.2607610225677490e-01
    z[9,8,0]  R2610     2.4502323567867279e-01
    z[9,8,0]  R2611     -1.1051161214709282e-02
    z[9,8,0]  R2612     6.3118702173233032e-01
    z[9,8,0]  R2613     -1.7386722564697266e-01
    z[9,8,0]  R2614     0.850654661655426
    z[9,8,0]  R2615     7.7652537822723389e-01
    z[9,8,0]  R2616     1.4204418659210205e-01
    z[9,8,0]  R2617     -0.145231232047081
    z[9,8,0]  R2618     3.3592867851257324e-01
    z[9,8,0]  R2619     -5.2047741413116455e-01
    z[9,8,0]  R2620     -6.8435454368591309e-01
    z[9,8,0]  R2621     5.6111800670623779e-01
    z[9,8,0]  R2622     7.0265668630599976e-01
    z[9,8,0]  R2623     6.2914478778839111e-01
    z[9,8,0]  R2624     9.1968637704849243e-01
    z[9,8,0]  R2625     8.2632642984390259e-01
    z[9,8,0]  R2626     -3.9074981212615967e-01
    z[9,8,0]  R2627     1.2499614059925079e-01
    z[9,8,0]  R2628     -4.2654818296432495e-01
    z[9,8,0]  R2629     -1.2063000351190567e-01
    z[9,8,0]  R2630     -2.0915327593684196e-02
    z[9,8,0]  R2631     5.8277625590562820e-02
    z[9,8,0]  R2632     -4.8038700222969055e-01
    z[9,8,0]  R2633     -4.1091445088386536e-01
    z[9,8,0]  R2634     -6.9333279132843018e-01
    z[9,8,0]  R2635     -5.6187170743942261e-01
    z[9,8,0]  R2636     -9.8007969558238983e-02
    z[9,8,0]  R2637     4.2319771647453308e-01
    z[9,8,0]  R2638     6.0794532299041748e-01
    z[9,8,0]  R2639     6.4149641990661621e-01
    z[9,8,0]  R2640     4.8135679960250854e-01
    z[9,8,0]  R2641     6.9264853000640869e-01
    z[9,8,0]  R2642     6.2139403820037842e-01
    z[9,8,0]  R2643     8.1307172775268555e-01
    z[9,8,0]  R2644     7.7958720922470093e-01
    z[9,8,0]  R2645     5.7829689979553223e-01
    z[9,8,0]  R2646     -2.7352419495582581e-01
    z[9,8,0]  R2647     -3.5296434164047241e-01
    z[9,8,0]  R2648     -3.4004601836204529e-01
    z[9,8,0]  R2649     -3.1818976998329163e-01
    z[9,8,0]  R2650     -1.9661569595336914e-01
    z[9,8,0]  R2651     -4.8411211371421814e-01
    z[9,8,0]  R2652     -3.2321357727050781e-01
    z[9,8,0]  R2653     -4.7861676663160324e-02
    z[9,8,0]  R2654     8.1224814057350159e-02
    z[9,8,0]  R2655     -2.8232285380363464e-01
    z[9,8,0]  R2656     -2.2531481087207794e-01
    z[9,8,0]  R2657     -6.2602043151855469e-01
    z[9,8,0]  R2658     1.8498246371746063e-01
    z[9,8,0]  R2659     2.6215562224388123e-01
    z[9,8,0]  R2660     3.3195510506629944e-01
    z[9,8,0]  R2661     4.2471545934677124e-01
    z[9,8,0]  R2662     4.9482813477516174e-01
    z[9,8,0]  R2663     3.9878904819488525e-01
    z[9,8,0]  R2664     2.2056475281715393e-01
    z[9,8,0]  R2665     4.1833823919296265e-01
    z[9,8,0]  R2666     -4.0368527173995972e-01
    z[9,8,0]  R2667     -7.6156002283096313e-01
    z[9,8,0]  R2668     1.7492818832397461e-01
    z[9,8,0]  R2669     -6.5001899003982544e-01
    z[9,8,0]  R2670     1.4738659560680389e-01
    z[9,8,0]  R2671     -1.9520901143550873e-02
    z[9,8,0]  R2672     -6.6485571861267090e-01
    z[9,8,0]  R2673     3.7170723080635071e-01
    z[9,8,0]  R2674     3.1934314966201782e-01
    z[9,8,0]  R2675     8.7775045633316040e-01
    z[9,8,0]  R2676     -5.1952421665191650e-01
    z[9,8,0]  R2677     4.7968052327632904e-02
    z[9,8,0]  R2678     -4.3762215971946716e-01
    z[9,8,0]  R2679     -5.0627154111862183e-01
    z[9,8,0]  R2680     -0.8146932721138
    z[9,8,0]  R2681     4.1255185008049011e-01
    z[9,8,0]  R2682     3.0727377533912659e-01
    z[9,8,0]  R2683     5.7641327381134033e-01
    z[9,8,0]  R2684     4.7787776589393616e-01
    z[9,8,0]  R2685     1.0288880020380020e-01
    z[9,8,1]  R75       1
    z[9,8,1]  R84       -1
    z[9,8,1]  R2564     -1
    z[9,8,1]  R2565     1
    z[9,8,1]  R2576     3.7119895219802856e-01
    z[9,8,1]  R2577     -9.0266567468643188e-01
    z[9,8,1]  R2578     -8.2593297958374023e-01
    z[9,8,1]  R2579     -8.8777500391006470e-01
    z[9,8,1]  R2580     -0.729659914970398
    z[9,8,1]  R2581     4.9801096320152283e-01
    z[9,8,1]  R2582     4.3764263391494751e-01
    z[9,8,1]  R2583     -8.8085365295410156e-01
    z[9,8,1]  R2584     -7.9509723186492920e-01
    z[9,8,1]  R2585     0.380319744348526
    z[9,8,1]  R2586     6.1788678169250488e-01
    z[9,8,1]  R2587     4.1270852088928223e-01
    z[9,8,1]  R2588     3.7514024972915649e-01
    z[9,8,1]  R2589     5.3677648305892944e-01
    z[9,8,1]  R2590     3.5736340284347534e-01
    z[9,8,1]  R2591     6.0424667596817017e-01
    z[9,8,1]  R2592     5.2081435918807983e-01
    z[9,8,1]  R2593     5.3743779659271240e-01
    z[9,8,1]  R2594     3.2512420415878296e-01
    z[9,8,1]  R2595     3.0059731006622314e-01
    z[9,8,1]  R2596     1.0095855593681335e-01
    z[9,8,1]  R2597     0.0694957971572876
    z[9,8,1]  R2598     -2.5015929341316223e-01
    z[9,8,1]  R2599     2.1684801578521729e-01
    z[9,8,1]  R2600     -3.2938501238822937e-01
    z[9,8,1]  R2601     -1.5268255770206451e-01
    z[9,8,1]  R2602     -9.6914544701576233e-02
    z[9,8,1]  R2603     -1.2869754433631897e-01
    z[9,8,1]  R2604     -3.8322377204895020e-01
    z[9,8,1]  R2605     -6.1499518156051636e-01
    z[9,8,1]  R2606     1.0826831310987473e-01
    z[9,8,1]  R2607     4.4784832000732422e-01
    z[9,8,1]  R2608     1.4900089800357819e-01
    z[9,8,1]  R2609     0.413095086812973
    z[9,8,1]  R2610     -2.4542917311191559e-01
    z[9,8,1]  R2611     8.2061541080474854e-01
    z[9,8,1]  R2612     1.3012255728244781e-01
    z[9,8,1]  R2613     -7.1297782659530640e-01
    z[9,8,1]  R2614     2.6907867193222046e-01
    z[9,8,1]  R2615     0.342650443315506
    z[9,8,1]  R2616     4.7802817821502686e-01
    z[9,8,1]  R2617     3.4184309840202332e-01
    z[9,8,1]  R2618     4.0005022287368774e-01
    z[9,8,1]  R2619     5.2099019289016724e-01
    z[9,8,1]  R2620     -4.3250057101249695e-01
    z[9,8,1]  R2621     5.7302784919738770e-01
    z[9,8,1]  R2622     1.4423719048500061e-01
    z[9,8,1]  R2623     1.1946291476488113e-01
    z[9,8,1]  R2624     4.7665104269981384e-02
    z[9,8,1]  R2625     3.2784324884414673e-01
    z[9,8,1]  R2626     -0.705855131149292
    z[9,8,1]  R2627     -8.8269656896591187e-01
    z[9,8,1]  R2628     -7.9068571329116821e-01
    z[9,8,1]  R2629     -5.4778116941452026e-01
    z[9,8,1]  R2630     -6.0107243061065674e-01
    z[9,8,1]  R2631     -4.9703511595726013e-01
    z[9,8,1]  R2632     -6.2793469429016113e-01
    z[9,8,1]  R2633     -5.2283900976181030e-01
    z[9,8,1]  R2634     2.2895354032516479e-01
    z[9,8,1]  R2635     2.3920297622680664e-01
    z[9,8,1]  R2636     3.6573797464370728e-01
    z[9,8,1]  R2637     0.535042941570282
    z[9,8,1]  R2638     3.9402100443840027e-01
    z[9,8,1]  R2639     3.3955448865890503e-01
    z[9,8,1]  R2640     0.601771891117096
    z[9,8,1]  R2641     2.4936752021312714e-01
    z[9,8,1]  R2642     6.0777044296264648e-01
    z[9,8,1]  R2643     3.5975351929664612e-01
    z[9,8,1]  R2644     3.0412450432777405e-01
    z[9,8,1]  R2645     3.3013802766799927e-01
    z[9,8,1]  R2646     6.4259105920791626e-01
    z[9,8,1]  R2647     5.3079181909561157e-01
    z[9,8,1]  R2648     5.4316770285367966e-02
    z[9,8,1]  R2649     4.1214996576309204e-01
    z[9,8,1]  R2650     -2.1932059526443481e-01
    z[9,8,1]  R2651     5.2335137128829956e-01
    z[9,8,1]  R2652     5.0564658641815186e-01
    z[9,8,1]  R2653     3.3324155211448669e-01
    z[9,8,1]  R2654     3.0066317319869995e-01
    z[9,8,1]  R2655     1.8425990641117096e-01
    z[9,8,1]  R2656     -4.0147960186004639e-01
    z[9,8,1]  R2657     -6.2851530313491821e-01
    z[9,8,1]  R2658     -0.184574156999588
    z[9,8,1]  R2659     4.6243998408317566e-01
    z[9,8,1]  R2660     5.9263890981674194e-01
    z[9,8,1]  R2661     4.7417640686035156e-01
    z[9,8,1]  R2662     -3.5979515314102173e-01
    z[9,8,1]  R2663     6.3976579904556274e-01
    z[9,8,1]  R2664     3.4338611364364624e-01
    z[9,8,1]  R2665     5.0573313236236572e-01
    z[9,8,1]  R2666     0.583396852016449
    z[9,8,1]  R2667     2.2258840501308441e-01
    z[9,8,1]  R2668     -7.5896930694580078e-01
    z[9,8,1]  R2669     3.1945669651031494e-01
    z[9,8,1]  R2670     -4.3107905983924866e-01
    z[9,8,1]  R2671     -6.2369698286056519e-01
    z[9,8,1]  R2672     3.5161608457565308e-01
    z[9,8,1]  R2673     -5.3372174501419067e-01
    z[9,8,1]  R2674     0.620152473449707
    z[9,8,1]  R2675     2.5708135962486267e-01
    z[9,8,1]  R2676     3.5777881741523743e-01
    z[9,8,1]  R2677     -8.6368823051452637e-01
    z[9,8,1]  R2678     6.8246811628341675e-01
    z[9,8,1]  R2679     6.0013699531555176e-01
    z[9,8,1]  R2680     -3.8814717531204224e-01
    z[9,8,1]  R2681     -4.7604104876518250e-01
    z[9,8,1]  R2682     -4.1460853815078735e-01
    z[9,8,1]  R2683     7.2182583808898926e-01
    z[9,8,1]  R2684     4.3425035476684570e-01
    z[9,8,1]  R2685     5.8105295896530151e-01
    z[9,8,2]  R76       1
    z[9,8,2]  R85       -1
    z[9,8,2]  R2566     -1
    z[9,8,2]  R2567     1
    z[9,8,2]  R2576     5.0463789701461792e-01
    z[9,8,2]  R2577     2.1183522045612335e-01
    z[9,8,2]  R2578     1.3079099357128143e-01
    z[9,8,2]  R2579     2.2281858325004578e-01
    z[9,8,2]  R2580     -3.7268076092004776e-02
    z[9,8,2]  R2581     5.2665509283542633e-02
    z[9,8,2]  R2582     6.3711577653884888e-01
    z[9,8,2]  R2583     -2.4388581514358521e-03
    z[9,8,2]  R2584     -3.2720527052879333e-01
    z[9,8,2]  R2585     3.9461705088615417e-01
    z[9,8,2]  R2586     1.0636379569768906e-01
    z[9,8,2]  R2587     -3.1514503061771393e-03
    z[9,8,2]  R2588     0.0676359236240387
    z[9,8,2]  R2589     2.4678535759449005e-01
    z[9,8,2]  R2590     3.8335734605789185e-01
    z[9,8,2]  R2591     0.0618075467646122
    z[9,8,2]  R2592     2.2087465226650238e-01
    z[9,8,2]  R2593     -2.5211388710886240e-03
    z[9,8,2]  R2594     -4.1485149413347244e-02
    z[9,8,2]  R2595     2.1859072148799896e-01
    z[9,8,2]  R2596     -0.0520876981317997
    z[9,8,2]  R2597     -1.4615756273269653e-01
    z[9,8,2]  R2598     -7.7589017152786255e-01
    z[9,8,2]  R2599     4.7463127970695496e-01
    z[9,8,2]  R2600     -5.5337548255920410e-01
    z[9,8,2]  R2601     -6.3175731897354126e-01
    z[9,8,2]  R2602     5.8389431238174438e-01
    z[9,8,2]  R2603     5.9024572372436523e-01
    z[9,8,2]  R2604     -5.0399124622344971e-01
    z[9,8,2]  R2605     -1.4449145644903183e-02
    z[9,8,2]  R2606     4.6048730611801147e-01
    z[9,8,2]  R2607     6.6099238395690918e-01
    z[9,8,2]  R2608     9.0163767337799072e-02
    z[9,8,2]  R2609     -7.6733380556106567e-02
    z[9,8,2]  R2610     4.7940242290496826e-01
    z[9,8,2]  R2611     -1.9397798180580139e-01
    z[9,8,2]  R2612     3.3856812119483948e-01
    z[9,8,2]  R2613     -2.4168695509433746e-01
    z[9,8,2]  R2614     1.6360796988010406e-01
    z[9,8,2]  R2615     -1.9548648595809937e-01
    z[9,8,2]  R2616     4.8458430171012878e-01
    z[9,8,2]  R2617     2.2467520087957382e-02
    z[9,8,2]  R2618     6.4751081168651581e-02
    z[9,8,2]  R2619     -6.5491750836372375e-02
    z[9,8,2]  R2620     -3.0540412664413452e-01
    z[9,8,2]  R2621     1.4728691428899765e-02
    z[9,8,2]  R2622     2.0782814919948578e-01
    z[9,8,2]  R2623     0.5059814453125
    z[9,8,2]  R2624     3.3739551901817322e-01
    z[9,8,2]  R2625     1.1924399994313717e-02
    z[9,8,2]  R2626     -3.6354590207338333e-02
    z[9,8,2]  R2627     -2.7984252572059631e-01
    z[9,8,2]  R2628     -0.00863682571798563
    z[9,8,2]  R2629     -2.5398376584053040e-01
    z[9,8,2]  R2630     -4.2689961194992065e-01
    z[9,8,2]  R2631     3.2003694772720337e-01
    z[9,8,2]  R2632     1.3535057008266449e-01
    z[9,8,2]  R2633     -3.9969551563262939e-01
    z[9,8,2]  R2634     1.6448435187339783e-01
    z[9,8,2]  R2635     1.7573493719100952e-01
    z[9,8,2]  R2636     4.6703219413757324e-01
    z[9,8,2]  R2637     2.1635392308235168e-01
    z[9,8,2]  R2638     1.6247582435607910e-01
    z[9,8,2]  R2639     1.7877030372619629e-01
    z[9,8,2]  R2640     -6.9348454475402832e-02
    z[9,8,2]  R2641     2.6478347182273865e-01
    z[9,8,2]  R2642     4.5628994703292847e-02
    z[9,8,2]  R2643     1.8481417000293732e-01
    z[9,8,2]  R2644     4.2502439022064209e-01
    z[9,8,2]  R2645     8.1140503287315369e-02
    z[9,8,2]  R2646     5.0389105081558228e-01
    z[9,8,2]  R2647     3.9021718502044678e-01
    z[9,8,2]  R2648     7.0239871740341187e-01
    z[9,8,2]  R2649     3.2019799947738647e-01
    z[9,8,2]  R2650     -6.0397596098482609e-03
    z[9,8,2]  R2651     -4.7329090535640717e-02
    z[9,8,2]  R2652     -1.8379144370555878e-02
    z[9,8,2]  R2653     5.7520174980163574e-01
    z[9,8,2]  R2654     0.642295241355896
    z[9,8,2]  R2655     3.9481487870216370e-01
    z[9,8,2]  R2656     4.0127193927764893e-01
    z[9,8,2]  R2657     -2.4796979129314423e-01
    z[9,8,2]  R2658     6.5727323293685913e-02
    z[9,8,2]  R2659     -6.7530685663223267e-01
    z[9,8,2]  R2660     -5.8397132158279419e-01
    z[9,8,2]  R2661     -5.4952836036682129e-01
    z[9,8,2]  R2662     -3.1262585520744324e-01
    z[9,8,2]  R2663     -5.2683001756668091e-01
    z[9,8,2]  R2664     -7.5382733345031738e-01
    z[9,8,2]  R2665     -7.3114919662475586e-01
    z[9,8,2]  R2666     5.2697986364364624e-01
    z[9,8,2]  R2667     3.8458457589149475e-01
    z[9,8,2]  R2668     4.0947649627923965e-02
    z[9,8,2]  R2669     2.8311860561370850e-01
    z[9,8,2]  R2670     3.5711872577667236e-01
    z[9,8,2]  R2671     -5.0671335309743881e-02
    z[9,8,2]  R2672     -1.1463362723588943e-01
    z[9,8,2]  R2673     -7.8487031161785126e-02
    z[9,8,2]  R2674     -2.1065986156463623e-01
    z[9,8,2]  R2675     -4.0730472654104233e-02
    z[9,8,2]  R2676     6.3772797584533691e-01
    z[9,8,2]  R2677     7.4824534356594086e-02
    z[9,8,2]  R2678     1.8205539882183075e-01
    z[9,8,2]  R2679     -1.8323624506592751e-02
    z[9,8,2]  R2680     2.4640716612339020e-01
    z[9,8,2]  R2681     -1.8924209475517273e-01
    z[9,8,2]  R2682     -4.0736806392669678e-01
    z[9,8,2]  R2683     1.0924704372882843e-01
    z[9,8,2]  R2684     -2.3694667220115662e-01
    z[9,8,2]  R2685     -4.2501190304756165e-01
    z[9,8,3]  R77       1
    z[9,8,3]  R86       -1
    z[9,8,3]  R2568     -1
    z[9,8,3]  R2569     1
    z[9,8,3]  R2576     -1.0172878205776215e-01
    z[9,8,3]  R2577     2.9667043685913086e-01
    z[9,8,3]  R2578     1.1939336359500885e-01
    z[9,8,3]  R2579     -2.9703578352928162e-01
    z[9,8,3]  R2580     3.4623626619577408e-02
    z[9,8,3]  R2581     -3.6751374602317810e-01
    z[9,8,3]  R2582     -3.2996940612792969e-01
    z[9,8,3]  R2583     -2.0167191326618195e-01
    z[9,8,3]  R2584     -1.8123102188110352e-01
    z[9,8,3]  R2585     -1.0467819869518280e-01
    z[9,8,3]  R2586     0.279776394367218
    z[9,8,3]  R2587     7.4402558803558350e-01
    z[9,8,3]  R2588     5.3678333759307861e-01
    z[9,8,3]  R2589     5.6045120954513550e-01
    z[9,8,3]  R2590     4.6524614095687866e-01
    z[9,8,3]  R2591     4.5251858234405518e-01
    z[9,8,3]  R2592     3.9085876941680908e-01
    z[9,8,3]  R2593     4.6487808227539062e-01
    z[9,8,3]  R2594     7.6949393749237061e-01
    z[9,8,3]  R2595     0.788844883441925
    z[9,8,3]  R2596     -8.9666461944580078e-01
    z[9,8,3]  R2597     -8.4360587596893311e-01
    z[9,8,3]  R2598     2.8829258680343628e-01
    z[9,8,3]  R2599     -6.7255079746246338e-01
    z[9,8,3]  R2600     -8.7308675050735474e-02
    z[9,8,3]  R2601     -3.8905474543571472e-01
    z[9,8,3]  R2602     1.9464203715324402e-01
    z[9,8,3]  R2603     2.5558346509933472e-01
    z[9,8,3]  R2604     -3.0210450291633606e-01
    z[9,8,3]  R2605     4.8521433025598526e-02
    z[9,8,3]  R2606     -6.6162657737731934e-01
    z[9,8,3]  R2607     -0.0974312275648117
    z[9,8,3]  R2608     -5.6235814094543457e-01
    z[9,8,3]  R2609     -8.3075851202011108e-01
    z[9,8,3]  R2610     -5.5331909656524658e-01
    z[9,8,3]  R2611     1.8006226420402527e-01
    z[9,8,3]  R2612     6.6044223308563232e-01
    z[9,8,3]  R2613     2.1907755732536316e-01
    z[9,8,3]  R2614     2.4703326821327209e-01
    z[9,8,3]  R2615     1.1764498800039291e-01
    z[9,8,3]  R2616     -0.595727801322937
    z[9,8,3]  R2617     -7.4787449836730957e-01
    z[9,8,3]  R2618     -0.720929741859436
    z[9,8,3]  R2619     2.8892710804939270e-01
    z[9,8,3]  R2620     -3.9735764265060425e-01
    z[9,8,3]  R2621     5.5459076166152954e-01
    z[9,8,3]  R2622     4.6066072583198547e-01
    z[9,8,3]  R2623     4.0360546112060547e-01
    z[9,8,3]  R2624     1.0930617898702621e-01
    z[9,8,3]  R2625     2.4287261068820953e-01
    z[9,8,3]  R2626     -2.4049256742000580e-01
    z[9,8,3]  R2627     -1.8227960169315338e-01
    z[9,8,3]  R2628     -1.8367478251457214e-01
    z[9,8,3]  R2629     -2.1280041337013245e-01
    z[9,8,3]  R2630     -2.0879431068897247e-01
    z[9,8,3]  R2631     -2.2890414297580719e-01
    z[9,8,3]  R2632     -1.2697722017765045e-01
    z[9,8,3]  R2633     -1.5663371980190277e-01
    z[9,8,3]  R2634     1.1656701564788818e-01
    z[9,8,3]  R2635     1.3841967284679413e-01
    z[9,8,3]  R2636     -8.7010592222213745e-02
    z[9,8,3]  R2637     6.7712718248367310e-01
    z[9,8,3]  R2638     6.4832371473312378e-01
    z[9,8,3]  R2639     6.1362695693969727e-01
    z[9,8,3]  R2640     4.8928019404411316e-01
    z[9,8,3]  R2641     6.0580068826675415e-01
    z[9,8,3]  R2642     2.9120427370071411e-01
    z[9,8,3]  R2643     3.3687943220138550e-01
    z[9,8,3]  R2644     3.2745805382728577e-01
    z[9,8,3]  R2645     5.7278507947921753e-01
    z[9,8,3]  R2646     -4.6318760514259338e-01
    z[9,8,3]  R2647     3.5891026258468628e-01
    z[9,8,3]  R2648     -4.9805739521980286e-01
    z[9,8,3]  R2649     -3.4513863921165466e-01
    z[9,8,3]  R2650     -7.7164888381958008e-01
    z[9,8,3]  R2651     2.2541718184947968e-01
    z[9,8,3]  R2652     -2.8522717952728271e-01
    z[9,8,3]  R2653     8.7847806513309479e-02
    z[9,8,3]  R2654     -2.8901886940002441e-01
    z[9,8,3]  R2655     5.1158016920089722e-01
    z[9,8,3]  R2656     -2.6556468009948730e-01
    z[9,8,3]  R2657     -1.1575835943222046e-01
    z[9,8,3]  R2658     -7.4994575977325439e-01
    z[9,8,3]  R2659     -1.3088975846767426e-01
    z[9,8,3]  R2660     -1.5370818972587585e-01
    z[9,8,3]  R2661     -0.136946439743042
    z[9,8,3]  R2662     -3.2947468757629395e-01
    z[9,8,3]  R2663     -2.2416210174560547e-01
    z[9,8,3]  R2664     -1.1424796283245087e-01
    z[9,8,3]  R2665     3.1601503491401672e-02
    z[9,8,3]  R2666     1.7844025790691376e-01
    z[9,8,3]  R2667     9.4157420098781586e-02
    z[9,8,3]  R2668     -4.8243671655654907e-01
    z[9,8,3]  R2669     1.7940548062324524e-01
    z[9,8,3]  R2670     -7.8748118877410889e-01
    z[9,8,3]  R2671     -1.9369816780090332e-01
    z[9,8,3]  R2672     4.6675175428390503e-01
    z[9,8,3]  R2673     -2.1306182444095612e-01
    z[9,8,3]  R2674     6.8165791034698486e-01
    z[9,8,3]  R2675     -2.6813134551048279e-01
    z[9,8,3]  R2676     -9.8371699452400208e-02
    z[9,8,3]  R2677     -2.9901558160781860e-01
    z[9,8,3]  R2678     -6.8399451673030853e-02
    z[9,8,3]  R2679     -1.7771961167454720e-02
    z[9,8,3]  R2680     -3.3625584840774536e-01
    z[9,8,3]  R2681     -3.8571050763130188e-01
    z[9,8,3]  R2682     -3.6949291825294495e-01
    z[9,8,3]  R2683     2.4150632321834564e-01
    z[9,8,3]  R2684     5.7673478126525879e-01
    z[9,8,3]  R2685     6.2681674957275391e-01
    z[9,8,4]  R78       1
    z[9,8,4]  R87       -1
    z[9,8,4]  R2570     -1
    z[9,8,4]  R2571     1
    z[9,8,4]  R2576     1.2485647201538086e-01
    z[9,8,4]  R2577     1.2310385704040527e-01
    z[9,8,4]  R2578     9.4127535820007324e-02
    z[9,8,4]  R2579     -2.7633709833025932e-02
    z[9,8,4]  R2580     6.7929677665233612e-02
    z[9,8,4]  R2581     3.4966897964477539e-01
    z[9,8,4]  R2582     -2.3460452258586884e-01
    z[9,8,4]  R2583     2.3682729899883270e-01
    z[9,8,4]  R2584     1.4008422195911407e-01
    z[9,8,4]  R2585     -4.9797093868255615e-01
    z[9,8,4]  R2586     -0.0261647067964077
    z[9,8,4]  R2587     -3.1128239631652832e-01
    z[9,8,4]  R2588     -1.7917363345623016e-01
    z[9,8,4]  R2589     1.4596521854400635e-01
    z[9,8,4]  R2590     -7.2413086891174316e-02
    z[9,8,4]  R2591     -3.8450222462415695e-02
    z[9,8,4]  R2592     -1.3183638453483582e-01
    z[9,8,4]  R2593     -2.1108466386795044e-01
    z[9,8,4]  R2594     -2.5628310441970825e-01
    z[9,8,4]  R2595     -1.5942068397998810e-01
    z[9,8,4]  R2596     1.7088495194911957e-01
    z[9,8,4]  R2597     -2.4839282035827637e-01
    z[9,8,4]  R2598     -2.4773180484771729e-02
    z[9,8,4]  R2599     -1.0599285364151001e-01
    z[9,8,4]  R2600     -3.3445760607719421e-01
    z[9,8,4]  R2601     -1.4131318032741547e-01
    z[9,8,4]  R2602     -2.6053443551063538e-01
    z[9,8,4]  R2603     -7.1282930672168732e-02
    z[9,8,4]  R2604     -4.5570683479309082e-01
    z[9,8,4]  R2605     -5.4738348722457886e-01
    z[9,8,4]  R2606     -1.4750123023986816e-01
    z[9,8,4]  R2607     0.0989510715007782
    z[9,8,4]  R2608     -0.514692485332489
    z[9,8,4]  R2609     -1.6152802109718323e-01
    z[9,8,4]  R2610     -4.8854687809944153e-01
    z[9,8,4]  R2611     -1.6791987419128418e-01
    z[9,8,4]  R2612     1.0922468453645706e-01
    z[9,8,4]  R2613     -4.6905669569969177e-01
    z[9,8,4]  R2614     8.1659637391567230e-02
    z[9,8,4]  R2615     1.8564572930335999e-01
    z[9,8,4]  R2616     1.2279351055622101e-01
    z[9,8,4]  R2617     -4.2905974388122559e-01
    z[9,8,4]  R2618     -3.3084303140640259e-01
    z[9,8,4]  R2619     -3.2869505882263184e-01
    z[9,8,4]  R2620     -2.5666296482086182e-01
    z[9,8,4]  R2621     -1.7523898184299469e-01
    z[9,8,4]  R2622     -1.7954197525978088e-01
    z[9,8,4]  R2623     -1.9712452590465546e-01
    z[9,8,4]  R2624     -2.9913255944848061e-02
    z[9,8,4]  R2625     -1.8272459506988525e-01
    z[9,8,4]  R2626     4.7157740592956543e-01
    z[9,8,4]  R2627     -5.2349831908941269e-02
    z[9,8,4]  R2628     -1.3976477086544037e-01
    z[9,8,4]  R2629     2.9161083698272705e-01
    z[9,8,4]  R2630     -3.2475203275680542e-02
    z[9,8,4]  R2631     0.745089054107666
    z[9,8,4]  R2632     -7.4821531772613525e-02
    z[9,8,4]  R2633     -1.2268606573343277e-01
    z[9,8,4]  R2634     2.7033528685569763e-01
    z[9,8,4]  R2635     3.1954219937324524e-01
    z[9,8,4]  R2636     -4.0138435363769531e-01
    z[9,8,4]  R2637     -0.0943312868475914
    z[9,8,4]  R2638     1.3736635446548462e-01
    z[9,8,4]  R2639     -1.0122365504503250e-01
    z[9,8,4]  R2640     -3.8699424266815186e-01
    z[9,8,4]  R2641     -5.2707046270370483e-02
    z[9,8,4]  R2642     -3.8135918974876404e-01
    z[9,8,4]  R2643     -1.6239321231842041e-01
    z[9,8,4]  R2644     -3.1952168792486191e-02
    z[9,8,4]  R2645     -2.7643764019012451e-01
    z[9,8,4]  R2646     7.9723246395587921e-02
    z[9,8,4]  R2647     3.1396403908729553e-02
    z[9,8,4]  R2648     1.6028310358524323e-01
    z[9,8,4]  R2649     -3.3956998586654663e-01
    z[9,8,4]  R2650     -4.7288507223129272e-01
    z[9,8,4]  R2651     -6.5615504980087280e-01
    z[9,8,4]  R2652     -6.0443294048309326e-01
    z[9,8,4]  R2653     5.7951617240905762e-01
    z[9,8,4]  R2654     8.9810833334922791e-02
    z[9,8,4]  R2655     1.0060887038707733e-01
    z[9,8,4]  R2656     4.5800673961639404e-01
    z[9,8,4]  R2657     -2.1552371978759766e-01
    z[9,8,4]  R2658     3.7567341327667236e-01
    z[9,8,4]  R2659     2.7588644623756409e-01
    z[9,8,4]  R2660     1.0778700560331345e-01
    z[9,8,4]  R2661     8.4838949143886566e-02
    z[9,8,4]  R2662     -6.3639283180236816e-02
    z[9,8,4]  R2663     1.5019574761390686e-01
    z[9,8,4]  R2664     9.2797234654426575e-02
    z[9,8,4]  R2665     -5.2797406911849976e-02
    z[9,8,4]  R2666     3.9403277635574341e-01
    z[9,8,4]  R2667     -3.3162882924079895e-01
    z[9,8,4]  R2668     -6.2922318466007710e-03
    z[9,8,4]  R2669     -1.2952215969562531e-01
    z[9,8,4]  R2670     4.7503627836704254e-02
    z[9,8,4]  R2671     3.4745806455612183e-01
    z[9,8,4]  R2672     -8.5709132254123688e-02
    z[9,8,4]  R2673     3.7121790647506714e-01
    z[9,8,4]  R2674     7.4765356257557869e-03
    z[9,8,4]  R2675     2.4638114869594574e-01
    z[9,8,4]  R2676     -1.0565236210823059e-01
    z[9,8,4]  R2677     2.7540171146392822e-01
    z[9,8,4]  R2678     -5.3796207904815674e-01
    z[9,8,4]  R2679     -8.4774866700172424e-02
    z[9,8,4]  R2680     -1.0620661079883575e-01
    z[9,8,4]  R2681     3.7548542022705078e-01
    z[9,8,4]  R2682     -1.1374235898256302e-01
    z[9,8,4]  R2683     6.3498369418084621e-03
    z[9,8,4]  R2684     -6.4141921699047089e-02
    z[9,8,4]  R2685     -1.3149622082710266e-01
    z[9,8,5]  R79       1
    z[9,8,5]  R88       -1
    z[9,8,5]  R2572     -1
    z[9,8,5]  R2573     1
    z[9,8,5]  R2576     1.6958688199520111e-01
    z[9,8,5]  R2577     -1.6247332096099854e-02
    z[9,8,5]  R2578     -0.414997398853302
    z[9,8,5]  R2579     2.4028332531452179e-01
    z[9,8,5]  R2580     2.1356710791587830e-01
    z[9,8,5]  R2581     -3.4443348646163940e-01
    z[9,8,5]  R2582     3.2018628716468811e-01
    z[9,8,5]  R2583     -1.2827628850936890e-01
    z[9,8,5]  R2584     2.9745748639106750e-01
    z[9,8,5]  R2585     3.3233964443206787e-01
    z[9,8,5]  R2586     -2.3302085697650909e-01
    z[9,8,5]  R2587     -1.5327532589435577e-01
    z[9,8,5]  R2588     -1.3046006858348846e-01
    z[9,8,5]  R2589     1.1618450284004211e-01
    z[9,8,5]  R2590     -1.0945549607276917e-01
    z[9,8,5]  R2591     -3.8443204760551453e-01
    z[9,8,5]  R2592     -3.7906184792518616e-01
    z[9,8,5]  R2593     -4.3311020731925964e-01
    z[9,8,5]  R2594     3.5544145852327347e-02
    z[9,8,5]  R2595     1.2966738641262054e-01
    z[9,8,5]  R2596     1.0781476646661758e-01
    z[9,8,5]  R2597     -1.6917613148689270e-01
    z[9,8,5]  R2598     -1.6113029420375824e-01
    z[9,8,5]  R2599     -2.5836187601089478e-01
    z[9,8,5]  R2600     -2.8022146224975586e-01
    z[9,8,5]  R2601     -4.7952279448509216e-01
    z[9,8,5]  R2602     8.8292052969336510e-03
    z[9,8,5]  R2603     4.8833701014518738e-01
    z[9,8,5]  R2604     5.2868378162384033e-01
    z[9,8,5]  R2605     5.1520484685897827e-01
    z[9,8,5]  R2606     -4.6827748417854309e-01
    z[9,8,5]  R2607     -5.4940879344940186e-01
    z[9,8,5]  R2608     4.6486946940422058e-01
    z[9,8,5]  R2609     -1.9641081988811493e-01
    z[9,8,5]  R2610     1.2209662795066833e-01
    z[9,8,5]  R2611     4.7225895524024963e-01
    z[9,8,5]  R2612     1.2973374128341675e-01
    z[9,8,5]  R2613     2.1981272101402283e-01
    z[9,8,5]  R2614     -2.7609056234359741e-01
    z[9,8,5]  R2615     3.6554217338562012e-01
    z[9,8,5]  R2616     2.4138320982456207e-01
    z[9,8,5]  R2617     1.0179761797189713e-01
    z[9,8,5]  R2618     4.6536628156900406e-02
    z[9,8,5]  R2619     -1.4922022819519043e-01
    z[9,8,5]  R2620     1.5973517298698425e-01
    z[9,8,5]  R2621     -1.0053821653127670e-01
    z[9,8,5]  R2622     4.4184795022010803e-01
    z[9,8,5]  R2623     0.357094407081604
    z[9,8,5]  R2624     1.5882861614227295e-01
    z[9,8,5]  R2625     -3.1715262681245804e-02
    z[9,8,5]  R2626     2.5104042887687683e-01
    z[9,8,5]  R2627     -8.7841480970382690e-02
    z[9,8,5]  R2628     -1.9002674520015717e-01
    z[9,8,5]  R2629     3.6660602688789368e-01
    z[9,8,5]  R2630     3.5867232084274292e-01
    z[9,8,5]  R2631     -1.9685764610767365e-01
    z[9,8,5]  R2632     -2.3646345734596252e-01
    z[9,8,5]  R2633     4.7210484743118286e-01
    z[9,8,5]  R2634     3.0779346823692322e-01
    z[9,8,5]  R2635     1.9148269295692444e-01
    z[9,8,5]  R2636     -5.3942728042602539e-01
    z[9,8,5]  R2637     -2.4274408817291260e-02
    z[9,8,5]  R2638     -6.3160099089145660e-02
    z[9,8,5]  R2639     1.4341041445732117e-01
    z[9,8,5]  R2640     -3.2551422715187073e-02
    z[9,8,5]  R2641     1.0987445712089539e-01
    z[9,8,5]  R2642     -9.7465276718139648e-02
    z[9,8,5]  R2643     -1.5779529511928558e-01
    z[9,8,5]  R2644     -7.3694236576557159e-02
    z[9,8,5]  R2645     -3.8061082363128662e-01
    z[9,8,5]  R2646     1.9135256111621857e-01
    z[9,8,5]  R2647     -3.3060204982757568e-01
    z[9,8,5]  R2648     -3.1885802745819092e-01
    z[9,8,5]  R2649     5.9416841715574265e-02
    z[9,8,5]  R2650     3.0407893657684326e-01
    z[9,8,5]  R2651     8.8839247822761536e-02
    z[9,8,5]  R2652     3.5376599431037903e-01
    z[9,8,5]  R2653     -3.2122090458869934e-01
    z[9,8,5]  R2654     -4.5879325270652771e-01
    z[9,8,5]  R2655     -6.0984903573989868e-01
    z[9,8,5]  R2656     -2.6245990395545959e-01
    z[9,8,5]  R2657     0.254169762134552
    z[9,8,5]  R2658     4.5750427246093750e-01
    z[9,8,5]  R2659     -4.0662378072738647e-01
    z[9,8,5]  R2660     -3.9159911870956421e-01
    z[9,8,5]  R2661     -4.9317845702171326e-01
    z[9,8,5]  R2662     2.2540882229804993e-01
    z[9,8,5]  R2663     -2.3525390028953552e-01
    z[9,8,5]  R2664     -4.6838164329528809e-01
    z[9,8,5]  R2665     -1.1270120739936829e-01
    z[9,8,5]  R2666     -1.2917117774486542e-01
    z[9,8,5]  R2667     -2.8374055027961731e-01
    z[9,8,5]  R2668     -2.3278048634529114e-01
    z[9,8,5]  R2669     -1.2248796969652176e-01
    z[9,8,5]  R2670     -1.9105631113052368e-01
    z[9,8,5]  R2671     1.1361550539731979e-02
    z[9,8,5]  R2672     0.294919490814209
    z[9,8,5]  R2673     3.6078030243515968e-03
    z[9,8,5]  R2674     -5.7003190740942955e-03
    z[9,8,5]  R2675     1.1956840753555298e-01
    z[9,8,5]  R2676     -4.0403288602828979e-01
    z[9,8,5]  R2677     -2.6048877835273743e-01
    z[9,8,5]  R2678     1.2340676039457321e-01
    z[9,8,5]  R2679     5.8245950937271118e-01
    z[9,8,5]  R2680     2.0201133564114571e-02
    z[9,8,5]  R2681     2.8838792443275452e-01
    z[9,8,5]  R2682     4.0955805778503418e-01
    z[9,8,5]  R2683     -1.9069863855838776e-01
    z[9,8,5]  R2684     -1.3184095919132233e-01
    z[9,8,5]  R2685     1.8675215542316437e-02
    z[9,8,6]  R80       1
    z[9,8,6]  R89       -1
    z[9,8,6]  R2574     -1
    z[9,8,6]  R2575     1
    z[9,8,6]  R2576     -2.8365132212638855e-01
    z[9,8,6]  R2577     3.5866007208824158e-02
    z[9,8,6]  R2578     7.9198144376277924e-02
    z[9,8,6]  R2579     -1.0546236485242844e-01
    z[9,8,6]  R2580     -6.1719194054603577e-02
    z[9,8,6]  R2581     -0.192262202501297
    z[9,8,6]  R2582     -6.0034235939383507e-03
    z[9,8,6]  R2583     -3.2536983489990234e-01
    z[9,8,6]  R2584     -1.1985626071691513e-01
    z[9,8,6]  R2585     2.8894510865211487e-01
    z[9,8,6]  R2586     -0.0785093605518341
    z[9,8,6]  R2587     -1.2693412601947784e-01
    z[9,8,6]  R2588     -4.4996868818998337e-02
    z[9,8,6]  R2589     -5.2526675164699554e-02
    z[9,8,6]  R2590     -2.6417663693428040e-01
    z[9,8,6]  R2591     1.3278764486312866e-01
    z[9,8,6]  R2592     -2.2593078017234802e-01
    z[9,8,6]  R2593     -7.3157578706741333e-02
    z[9,8,6]  R2594     1.2063318490982056e-01
    z[9,8,6]  R2595     -0.0679294764995575
    z[9,8,6]  R2596     -3.0027189850807190e-01
    z[9,8,6]  R2597     2.9272112250328064e-01
    z[9,8,6]  R2598     2.3087087273597717e-01
    z[9,8,6]  R2599     1.8146304786205292e-01
    z[9,8,6]  R2600     4.5979449152946472e-01
    z[9,8,6]  R2601     3.8912755250930786e-01
    z[9,8,6]  R2602     2.6222813129425049e-01
    z[9,8,6]  R2603     -1.9972331821918488e-01
    z[9,8,6]  R2604     1.3624365627765656e-01
    z[9,8,6]  R2605     2.0632030069828033e-01
    z[9,8,6]  R2606     2.8304985165596008e-01
    z[9,8,6]  R2607     1.7174871265888214e-01
    z[9,8,6]  R2608     2.4364647269248962e-01
    z[9,8,6]  R2609     2.2965441644191742e-01
    z[9,8,6]  R2610     3.0025640130043030e-01
    z[9,8,6]  R2611     7.2059154510498047e-02
    z[9,8,6]  R2612     -7.1399368345737457e-02
    z[9,8,6]  R2613     2.9443749785423279e-01
    z[9,8,6]  R2614     1.8247225880622864e-01
    z[9,8,6]  R2615     -2.4384070932865143e-01
    z[9,8,6]  R2616     -2.9707708954811096e-01
    z[9,8,6]  R2617     3.2829120755195618e-01
    z[9,8,6]  R2618     0.302583247423172
    z[9,8,6]  R2619     4.8948684334754944e-01
    z[9,8,6]  R2620     4.5234248042106628e-02
    z[9,8,6]  R2621     9.0449877083301544e-02
    z[9,8,6]  R2622     5.1024246960878372e-02
    z[9,8,6]  R2623     6.7944198846817017e-02
    z[9,8,6]  R2624     0.000320744322380051
    z[9,8,6]  R2625     3.4085190296173096e-01
    z[9,8,6]  R2626     0.0672181099653244
    z[9,8,6]  R2627     -2.8849324584007263e-01
    z[9,8,6]  R2628     -3.2158580422401428e-01
    z[9,8,6]  R2629     -5.9678763151168823e-01
    z[9,8,6]  R2630     -5.3172874450683594e-01
    z[9,8,6]  R2631     -2.8782900422811508e-02
    z[9,8,6]  R2632     5.2817636728286743e-01
    z[9,8,6]  R2633     -3.6818888783454895e-01
    z[9,8,6]  R2634     0.508339524269104
    z[9,8,6]  R2635     -6.6201704740524292e-01
    z[9,8,6]  R2636     -4.2290541529655457e-01
    z[9,8,6]  R2637     -1.4083603024482727e-01
    z[9,8,6]  R2638     7.4627533555030823e-02
    z[9,8,6]  R2639     1.8405258655548096e-01
    z[9,8,6]  R2640     1.0553563386201859e-01
    z[9,8,6]  R2641     -7.8094065189361572e-02
    z[9,8,6]  R2642     5.1657155156135559e-02
    z[9,8,6]  R2643     1.0284334421157837e-01
    z[9,8,6]  R2644     -7.3660321533679962e-02
    z[9,8,6]  R2645     -2.5152249261736870e-02
    z[9,8,6]  R2646     -2.8996374458074570e-02
    z[9,8,6]  R2647     -4.4978532195091248e-01
    z[9,8,6]  R2648     -1.1239292472600937e-01
    z[9,8,6]  R2649     6.2321919202804565e-01
    z[9,8,6]  R2650     4.0963903069496155e-02
    z[9,8,6]  R2651     0.0159404706209898
    z[9,8,6]  R2652     -2.6013967394828796e-01
    z[9,8,6]  R2653     3.3024734258651733e-01
    z[9,8,6]  R2654     4.3401810526847839e-01
    z[9,8,6]  R2655     2.9446718096733093e-01
    z[9,8,6]  R2656     -5.2711308002471924e-01
    z[9,8,6]  R2657     1.6469725966453552e-01
    z[9,8,6]  R2658     -1.2055918574333191e-01
    z[9,8,6]  R2659     -5.2877198904752731e-02
    z[9,8,6]  R2660     9.4701521098613739e-02
    z[9,8,6]  R2661     -1.5367236733436584e-01
    z[9,8,6]  R2662     0.603775680065155
    z[9,8,6]  R2663     -1.6113768517971039e-01
    z[9,8,6]  R2664     1.5535804629325867e-01
    z[9,8,6]  R2665     -1.3475976884365082e-01
    z[9,8,6]  R2666     -1.2325000762939453e-01
    z[9,8,6]  R2667     -1.5239277482032776e-01
    z[9,8,6]  R2668     -3.2360067963600159e-01
    z[9,8,6]  R2669     -5.7558751106262207e-01
    z[9,8,6]  R2670     7.7643796801567078e-02
    z[9,8,6]  R2671     -6.7058050632476807e-01
    z[9,8,6]  R2672     3.3016854524612427e-01
    z[9,8,6]  R2673     6.2257814407348633e-01
    z[9,8,6]  R2674     0.0656309723854065
    z[9,8,6]  R2675     1.2210515886545181e-01
    z[9,8,6]  R2676     -1.0634802281856537e-01
    z[9,8,6]  R2677     -1.1415829509496689e-01
    z[9,8,6]  R2678     1.6399851068854332e-02
    z[9,8,6]  R2679     1.9085927307605743e-01
    z[9,8,6]  R2680     1.2006171047687531e-02
    z[9,8,6]  R2681     4.4095784425735474e-01
    z[9,8,6]  R2682     0.500533401966095
    z[9,8,6]  R2683     -2.0012147724628448e-01
    z[9,8,6]  R2684     -4.1568791866302490e-01
    z[9,8,6]  R2685     -2.4620507657527924e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    length[8]  OBJ       1
    length[9]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
    delta[8,0]  R74       1
    delta[8,1]  R75       1
    delta[8,2]  R76       1
    delta[8,3]  R77       1
    delta[8,4]  R78       1
    delta[8,5]  R79       1
    delta[8,6]  R80       1
    delta[9,0]  R83       1
    delta[9,1]  R84       1
    delta[9,2]  R85       1
    delta[9,3]  R86       1
    delta[9,4]  R87       1
    delta[9,5]  R88       1
    delta[9,6]  R89       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R73       1
    RHS1      R82       1
    RHS1      R90       1
    RHS1      R91       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,7]
 BV BND1      phi[7,0]
 BV BND1      phi[10,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,7]
 BV BND1      phi[7,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,9]
 BV BND1      phi[9,6]
 BV BND1      phi[6,11]
 BV BND1      phi[7,8]
 BV BND1      phi[8,7]
 BV BND1      phi[8,9]
 BV BND1      phi[9,8]
 BV BND1      phi[9,11]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,7,0]
 FR BND1      z[0,7,1]
 FR BND1      z[0,7,2]
 FR BND1      z[0,7,3]
 FR BND1      z[0,7,4]
 FR BND1      z[0,7,5]
 FR BND1      z[0,7,6]
 FR BND1      z[7,0,0]
 FR BND1      z[7,0,1]
 FR BND1      z[7,0,2]
 FR BND1      z[7,0,3]
 FR BND1      z[7,0,4]
 FR BND1      z[7,0,5]
 FR BND1      z[7,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,7,0]
 FR BND1      z[1,7,1]
 FR BND1      z[1,7,2]
 FR BND1      z[1,7,3]
 FR BND1      z[1,7,4]
 FR BND1      z[1,7,5]
 FR BND1      z[1,7,6]
 FR BND1      z[7,1,0]
 FR BND1      z[7,1,1]
 FR BND1      z[7,1,2]
 FR BND1      z[7,1,3]
 FR BND1      z[7,1,4]
 FR BND1      z[7,1,5]
 FR BND1      z[7,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,9,0]
 FR BND1      z[6,9,1]
 FR BND1      z[6,9,2]
 FR BND1      z[6,9,3]
 FR BND1      z[6,9,4]
 FR BND1      z[6,9,5]
 FR BND1      z[6,9,6]
 FR BND1      z[9,6,0]
 FR BND1      z[9,6,1]
 FR BND1      z[9,6,2]
 FR BND1      z[9,6,3]
 FR BND1      z[9,6,4]
 FR BND1      z[9,6,5]
 FR BND1      z[9,6,6]
 FR BND1      z[7,8,0]
 FR BND1      z[7,8,1]
 FR BND1      z[7,8,2]
 FR BND1      z[7,8,3]
 FR BND1      z[7,8,4]
 FR BND1      z[7,8,5]
 FR BND1      z[7,8,6]
 FR BND1      z[8,7,0]
 FR BND1      z[8,7,1]
 FR BND1      z[8,7,2]
 FR BND1      z[8,7,3]
 FR BND1      z[8,7,4]
 FR BND1      z[8,7,5]
 FR BND1      z[8,7,6]
 FR BND1      z[8,9,0]
 FR BND1      z[8,9,1]
 FR BND1      z[8,9,2]
 FR BND1      z[8,9,3]
 FR BND1      z[8,9,4]
 FR BND1      z[8,9,5]
 FR BND1      z[8,9,6]
 FR BND1      z[9,8,0]
 FR BND1      z[9,8,1]
 FR BND1      z[9,8,2]
 FR BND1      z[9,8,3]
 FR BND1      z[9,8,4]
 FR BND1      z[9,8,5]
 FR BND1      z[9,8,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
 FR BND1      delta[8,0]
 FR BND1      delta[8,1]
 FR BND1      delta[8,2]
 FR BND1      delta[8,3]
 FR BND1      delta[8,4]
 FR BND1      delta[8,5]
 FR BND1      delta[8,6]
 FR BND1      delta[9,0]
 FR BND1      delta[9,1]
 FR BND1      delta[9,2]
 FR BND1      delta[9,3]
 FR BND1      delta[9,4]
 FR BND1      delta[9,5]
 FR BND1      delta[9,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
QCMATRIX   qc8     
    length[8]  length[8]  -1
    delta[8,0]  delta[8,0]  1
    delta[8,1]  delta[8,1]  1
    delta[8,2]  delta[8,2]  1
    delta[8,3]  delta[8,3]  1
    delta[8,4]  delta[8,4]  1
    delta[8,5]  delta[8,5]  1
    delta[8,6]  delta[8,6]  1
QCMATRIX   qc9     
    length[9]  length[9]  -1
    delta[9,0]  delta[9,0]  1
    delta[9,1]  delta[9,1]  1
    delta[9,2]  delta[9,2]  1
    delta[9,3]  delta[9,3]  1
    delta[9,4]  delta[9,4]  1
    delta[9,5]  delta[9,5]  1
    delta[9,6]  delta[9,6]  1
ENDATA
