NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       8.2204186916351318e-01
    phi[0,1]  R89       -1.5355687141418457e+00
    phi[0,1]  R90       7.7809435129165649e-01
    phi[0,1]  R91       1.7362434864044189e+00
    phi[0,1]  R92       2.0645534992218018e+00
    phi[0,1]  R93       1.0654863119125366e+00
    phi[0,1]  R94       1.5956361293792725e+00
    phi[0,1]  R95       2.35722279548645
    phi[0,1]  R96       1.6249700784683228e+00
    phi[0,1]  R97       5.8969491720199585e-01
    phi[0,1]  R98       -1.1283679008483887e+00
    phi[0,1]  R99       -8.8904851675033569e-01
    phi[0,1]  R100      -1.2689760923385620e+00
    phi[0,1]  R101      -2.1150507926940918e+00
    phi[0,1]  R102      -1.0663774013519287e+00
    phi[0,1]  R103      -1.6495133638381958e+00
    phi[0,1]  R104      -1.7876969575881958e+00
    phi[0,1]  R105      -2.1545734405517578e+00
    phi[0,1]  R106      -1.9888492822647095e+00
    phi[0,1]  R107      -2.4679982662200928e+00
    phi[0,1]  R108      -1.6190400123596191e+00
    phi[0,1]  R109      -1.2137428522109985e+00
    phi[0,1]  R110      -9.9427509307861328e-01
    phi[0,1]  R111      -1.9108096361160278e+00
    phi[0,1]  R112      1.0506602525711060e+00
    phi[0,1]  R113      -3.7995693087577820e-01
    phi[0,1]  R114      -3.0779085159301758e+00
    phi[0,1]  R115      -1.3453286886215210e+00
    phi[0,1]  R116      -1.7443501949310303e+00
    phi[0,1]  R117      -1.5603388547897339e+00
    phi[0,1]  R118      -2.1415870189666748e+00
    phi[0,1]  R119      4.2512229084968567e-01
    phi[0,1]  R120      -7.6467859745025635e-01
    phi[0,1]  R121      5.6004941463470459e-01
    phi[0,1]  R122      -1.6723041534423828e+00
    phi[0,1]  R123      -2.2941758632659912e+00
    phi[0,1]  R124      -1.5266613960266113e+00
    phi[0,1]  R125      4.1331166028976440e-01
    phi[0,1]  R126      -1.1123176813125610e+00
    phi[0,1]  R127      -7.5530248880386353e-01
    phi[0,1]  R128      -1.4328337907791138e+00
    phi[0,1]  R129      -2.3254852294921875e+00
    phi[0,1]  R130      -7.0821315050125122e-01
    phi[0,1]  R131      -9.2190051078796387e-01
    phi[0,1]  R132      -4.2791271209716797e-01
    phi[0,1]  R133      -1.6778037548065186e+00
    phi[0,1]  R134      -1.0415605306625366e+00
    phi[0,1]  R135      -3.7993150949478149e-01
    phi[0,1]  R136      -1.4740023612976074e+00
    phi[0,1]  R137      -1.8155421018600464e+00
    phi[0,1]  R138      -1.7303017377853394e+00
    phi[0,1]  R139      -5.6986922025680542e-01
    phi[0,1]  R140      -1.0568298101425171e+00
    phi[0,1]  R141      -1.2585718631744385e+00
    phi[0,1]  R142      -7.7688217163085938e-01
    phi[0,1]  R143      -2.4530377388000488e+00
    phi[0,1]  R144      -9.1006451845169067e-01
    phi[0,1]  R145      -5.3525978326797485e-01
    phi[0,1]  R146      -6.3049727678298950e-01
    phi[0,1]  R147      -1.1754255294799805e+00
    phi[0,1]  R148      1.9033626317977905e+00
    phi[0,1]  R149      -0.326955109834671
    phi[0,1]  R150      2.0944395065307617e+00
    phi[0,1]  R151      3.4711289405822754e-01
    phi[0,1]  R152      -1.4293063879013062e+00
    phi[0,1]  R153      4.7431564331054688e-01
    phi[0,1]  R154      -2.1994407176971436e+00
    phi[0,1]  R155      -2.8046000003814697e+00
    phi[0,1]  R156      -4.6077299118041992e-01
    phi[0,1]  R157      -5.9478712081909180e-01
    phi[0,1]  R158      4.5901998877525330e-01
    phi[0,1]  R159      -8.8368499279022217e-01
    phi[0,1]  R160      -1.0490156412124634e+00
    phi[0,1]  R161      3.0581495165824890e-01
    phi[0,1]  R162      -3.5239839553833008e-01
    phi[0,1]  R163      -4.2484962940216064e-01
    phi[0,1]  R164      -1.3119363784790039e+00
    phi[0,1]  R165      -2.41902232170105
    phi[0,1]  R166      -3.1082506179809570e+00
    phi[0,1]  R167      -3.8047525882720947e+00
    phi[0,1]  R168      -7.5253582000732422e-01
    phi[0,1]  R169      -9.3663769960403442e-01
    phi[0,1]  R170      1.4129548072814941e+00
    phi[0,1]  R171      -7.7636218070983887e-01
    phi[0,1]  R172      -6.0727477073669434e-02
    phi[0,1]  R173      -1.21875
    phi[0,1]  R174      -1.4323198795318604e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R175      -3.0999999046325684e+00
    phi[1,0]  R176      -3.0999999046325684e+00
    phi[1,0]  R177      -2.2400000095367432e+00
    phi[1,0]  R178      -2.2400000095367432e+00
    phi[1,0]  R179      -3.0999999046325684e+00
    phi[1,0]  R180      -3.0999999046325684e+00
    phi[1,0]  R181      -2.5699999332427979e+00
    phi[1,0]  R182      -2.5699999332427979e+00
    phi[1,0]  R183      -3.0999999046325684e+00
    phi[1,0]  R184      -3.0999999046325684e+00
    phi[1,0]  R185      -2.0899999141693115e+00
    phi[1,0]  R186      -2.0899999141693115e+00
    phi[1,0]  R187      -3.0999999046325684e+00
    phi[1,0]  R188      -3.0999999046325684e+00
    phi[1,0]  R189      1.9033626317977905e+00
    phi[1,0]  R190      -0.326955109834671
    phi[1,0]  R191      2.0944395065307617e+00
    phi[1,0]  R192      3.4711289405822754e-01
    phi[1,0]  R193      -1.4293063879013062e+00
    phi[1,0]  R194      4.7431564331054688e-01
    phi[1,0]  R195      -2.1994407176971436e+00
    phi[1,0]  R196      -2.8046000003814697e+00
    phi[1,0]  R197      -4.6077299118041992e-01
    phi[1,0]  R198      -5.9478712081909180e-01
    phi[1,0]  R199      4.5901998877525330e-01
    phi[1,0]  R200      -8.8368499279022217e-01
    phi[1,0]  R201      -1.0490156412124634e+00
    phi[1,0]  R202      3.0581495165824890e-01
    phi[1,0]  R203      -3.5239839553833008e-01
    phi[1,0]  R204      -4.2484962940216064e-01
    phi[1,0]  R205      -1.3119363784790039e+00
    phi[1,0]  R206      -2.41902232170105
    phi[1,0]  R207      -3.1082506179809570e+00
    phi[1,0]  R208      -3.8047525882720947e+00
    phi[1,0]  R209      -7.5253582000732422e-01
    phi[1,0]  R210      -9.3663769960403442e-01
    phi[1,0]  R211      1.4129548072814941e+00
    phi[1,0]  R212      -7.7636218070983887e-01
    phi[1,0]  R213      -6.0727477073669434e-02
    phi[1,0]  R214      -1.21875
    phi[1,0]  R215      -1.4323198795318604e+00
    phi[1,0]  R216      8.2204186916351318e-01
    phi[1,0]  R217      -1.5355687141418457e+00
    phi[1,0]  R218      7.7809435129165649e-01
    phi[1,0]  R219      1.7362434864044189e+00
    phi[1,0]  R220      2.0645534992218018e+00
    phi[1,0]  R221      1.0654863119125366e+00
    phi[1,0]  R222      1.5956361293792725e+00
    phi[1,0]  R223      2.35722279548645
    phi[1,0]  R224      1.6249700784683228e+00
    phi[1,0]  R225      5.8969491720199585e-01
    phi[1,0]  R226      -1.1283679008483887e+00
    phi[1,0]  R227      -8.8904851675033569e-01
    phi[1,0]  R228      -1.2689760923385620e+00
    phi[1,0]  R229      -2.1150507926940918e+00
    phi[1,0]  R230      -1.0663774013519287e+00
    phi[1,0]  R231      -1.6495133638381958e+00
    phi[1,0]  R232      -1.7876969575881958e+00
    phi[1,0]  R233      -2.1545734405517578e+00
    phi[1,0]  R234      -1.9888492822647095e+00
    phi[1,0]  R235      -2.4679982662200928e+00
    phi[1,0]  R236      -1.6190400123596191e+00
    phi[1,0]  R237      -1.2137428522109985e+00
    phi[1,0]  R238      -9.9427509307861328e-01
    phi[1,0]  R239      -1.9108096361160278e+00
    phi[1,0]  R240      1.0506602525711060e+00
    phi[1,0]  R241      -3.7995693087577820e-01
    phi[1,0]  R242      -3.0779085159301758e+00
    phi[1,0]  R243      -1.3453286886215210e+00
    phi[1,0]  R244      -1.7443501949310303e+00
    phi[1,0]  R245      -1.5603388547897339e+00
    phi[1,0]  R246      -2.1415870189666748e+00
    phi[1,0]  R247      4.2512229084968567e-01
    phi[1,0]  R248      -7.6467859745025635e-01
    phi[1,0]  R249      5.6004941463470459e-01
    phi[1,0]  R250      -1.6723041534423828e+00
    phi[1,0]  R251      -2.2941758632659912e+00
    phi[1,0]  R252      -1.5266613960266113e+00
    phi[1,0]  R253      4.1331166028976440e-01
    phi[1,0]  R254      -1.1123176813125610e+00
    phi[1,0]  R255      -7.5530248880386353e-01
    phi[1,0]  R256      -1.4328337907791138e+00
    phi[1,0]  R257      -2.3254852294921875e+00
    phi[1,0]  R258      -7.0821315050125122e-01
    phi[1,0]  R259      -9.2190051078796387e-01
    phi[1,0]  R260      -4.2791271209716797e-01
    phi[1,0]  R261      -1.6778037548065186e+00
    phi[1,0]  R262      -1.0415605306625366e+00
    phi[1,0]  R263      -3.7993150949478149e-01
    phi[1,0]  R264      -1.4740023612976074e+00
    phi[1,0]  R265      -1.8155421018600464e+00
    phi[1,0]  R266      -1.7303017377853394e+00
    phi[1,0]  R267      -5.6986922025680542e-01
    phi[1,0]  R268      -1.0568298101425171e+00
    phi[1,0]  R269      -1.2585718631744385e+00
    phi[1,0]  R270      -7.7688217163085938e-01
    phi[1,0]  R271      -2.4530377388000488e+00
    phi[1,0]  R272      -9.1006451845169067e-01
    phi[1,0]  R273      -5.3525978326797485e-01
    phi[1,0]  R274      -6.3049727678298950e-01
    phi[1,0]  R275      -1.1754255294799805e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R276      -3.0999999046325684e+00
    phi[0,4]  R277      -3.0999999046325684e+00
    phi[0,4]  R278      -2.2400000095367432e+00
    phi[0,4]  R279      -2.2400000095367432e+00
    phi[0,4]  R280      -3.0999999046325684e+00
    phi[0,4]  R281      -3.0999999046325684e+00
    phi[0,4]  R282      -2.5699999332427979e+00
    phi[0,4]  R283      -2.5699999332427979e+00
    phi[0,4]  R284      -3.0999999046325684e+00
    phi[0,4]  R285      -3.0999999046325684e+00
    phi[0,4]  R286      -2.0899999141693115e+00
    phi[0,4]  R287      -2.0899999141693115e+00
    phi[0,4]  R288      -3.0999999046325684e+00
    phi[0,4]  R289      -3.0999999046325684e+00
    phi[0,4]  R290      8.2204186916351318e-01
    phi[0,4]  R291      -1.5355687141418457e+00
    phi[0,4]  R292      7.7809435129165649e-01
    phi[0,4]  R293      1.7362434864044189e+00
    phi[0,4]  R294      2.0645534992218018e+00
    phi[0,4]  R295      1.0654863119125366e+00
    phi[0,4]  R296      1.5956361293792725e+00
    phi[0,4]  R297      2.35722279548645
    phi[0,4]  R298      1.6249700784683228e+00
    phi[0,4]  R299      5.8969491720199585e-01
    phi[0,4]  R300      -1.1283679008483887e+00
    phi[0,4]  R301      -8.8904851675033569e-01
    phi[0,4]  R302      -1.2689760923385620e+00
    phi[0,4]  R303      -2.1150507926940918e+00
    phi[0,4]  R304      -1.0663774013519287e+00
    phi[0,4]  R305      -1.6495133638381958e+00
    phi[0,4]  R306      -1.7876969575881958e+00
    phi[0,4]  R307      -2.1545734405517578e+00
    phi[0,4]  R308      -1.9888492822647095e+00
    phi[0,4]  R309      -2.4679982662200928e+00
    phi[0,4]  R310      -1.6190400123596191e+00
    phi[0,4]  R311      -1.2137428522109985e+00
    phi[0,4]  R312      -9.9427509307861328e-01
    phi[0,4]  R313      -1.9108096361160278e+00
    phi[0,4]  R314      1.0506602525711060e+00
    phi[0,4]  R315      -3.7995693087577820e-01
    phi[0,4]  R316      -3.0779085159301758e+00
    phi[0,4]  R317      -1.3453286886215210e+00
    phi[0,4]  R318      -1.7443501949310303e+00
    phi[0,4]  R319      -1.5603388547897339e+00
    phi[0,4]  R320      -2.1415870189666748e+00
    phi[0,4]  R321      4.2512229084968567e-01
    phi[0,4]  R322      -7.6467859745025635e-01
    phi[0,4]  R323      5.6004941463470459e-01
    phi[0,4]  R324      -1.6723041534423828e+00
    phi[0,4]  R325      -2.2941758632659912e+00
    phi[0,4]  R326      -1.5266613960266113e+00
    phi[0,4]  R327      4.1331166028976440e-01
    phi[0,4]  R328      -1.1123176813125610e+00
    phi[0,4]  R329      -7.5530248880386353e-01
    phi[0,4]  R330      -1.4328337907791138e+00
    phi[0,4]  R331      -2.3254852294921875e+00
    phi[0,4]  R332      -7.0821315050125122e-01
    phi[0,4]  R333      -9.2190051078796387e-01
    phi[0,4]  R334      -4.2791271209716797e-01
    phi[0,4]  R335      -1.6778037548065186e+00
    phi[0,4]  R336      -1.0415605306625366e+00
    phi[0,4]  R337      -3.7993150949478149e-01
    phi[0,4]  R338      -1.4740023612976074e+00
    phi[0,4]  R339      -1.8155421018600464e+00
    phi[0,4]  R340      -1.7303017377853394e+00
    phi[0,4]  R341      -5.6986922025680542e-01
    phi[0,4]  R342      -1.0568298101425171e+00
    phi[0,4]  R343      -1.2585718631744385e+00
    phi[0,4]  R344      -7.7688217163085938e-01
    phi[0,4]  R345      -2.4530377388000488e+00
    phi[0,4]  R346      -9.1006451845169067e-01
    phi[0,4]  R347      -5.3525978326797485e-01
    phi[0,4]  R348      -6.3049727678298950e-01
    phi[0,4]  R349      -1.1754255294799805e+00
    phi[0,4]  R350      1.2876926660537720e+00
    phi[0,4]  R351      1.7858449220657349e+00
    phi[0,4]  R352      1.2794536352157593e+00
    phi[0,4]  R353      6.0153192281723022e-01
    phi[0,4]  R354      2.2252583503723145e+00
    phi[0,4]  R355      0.828194260597229
    phi[0,4]  R356      9.5010602474212646e-01
    phi[0,4]  R357      2.1598362922668457e+00
    phi[0,4]  R358      1.2177836894989014e+00
    phi[0,4]  R359      6.2312108278274536e-01
    phi[0,4]  R360      -9.5100885629653931e-01
    phi[0,4]  R361      -3.3563313484191895e+00
    phi[0,4]  R362      -2.0805172920227051e+00
    phi[0,4]  R363      -3.2488257884979248e+00
    phi[0,4]  R364      -4.0639810562133789e+00
    phi[0,4]  R365      -3.6794190406799316e+00
    phi[0,4]  R366      -1.6260633468627930e+00
    phi[0,4]  R367      -2.5315217971801758e+00
    phi[0,4]  R368      -2.3085432052612305e+00
    phi[0,4]  R369      -2.4476613998413086e+00
    phi[0,4]  R370      -2.5149133205413818e+00
    phi[0,4]  R371      -9.9706232547760010e-01
    phi[0,4]  R372      -7.7825969457626343e-01
    phi[0,4]  R373      -2.2911386489868164e+00
    phi[0,4]  R374      1.3851609826087952e-01
    phi[0,4]  R375      -4.2769312858581543e-04
    phi[0,4]  R376      -3.7595915794372559e-01
    phi[0,4]  R377      -2.6977107524871826e+00
    phi[0,4]  R378      -2.2754948139190674e+00
    phi[0,4]  R379      -5.6862151622772217e-01
    phi[0,4]  R380      -1.4224802255630493e+00
    phi[0,4]  R381      -0.834635317325592
    phi[0,4]  R382      -1.4658658504486084e+00
    phi[0,4]  R383      -1.4826879501342773e+00
    phi[0,4]  R384      1.2372667789459229e+00
    phi[0,4]  R385      -6.8143361806869507e-01
    phi[0,4]  R386      -2.8161978721618652e-01
    phi[0,4]  R387      -8.2134252786636353e-01
    phi[0,4]  R388      -1.9720678329467773e+00
    phi[0,4]  R389      -2.2614393234252930e+00
    phi[0,4]  R390      -9.2362242937088013e-01
    phi[0,4]  R391      -9.3353599309921265e-01
    phi[0,4]  R392      -2.8592083454132080e+00
    phi[0,4]  R393      9.9744945764541626e-01
    phi[0,4]  R394      -9.3784385919570923e-01
    phi[0,4]  R395      -1.8985871970653534e-01
    phi[0,4]  R396      -0.11457559466362
    phi[0,4]  R397      -0.611226499080658
    phi[0,4]  R398      -8.4949588775634766e-01
    phi[0,4]  R399      -2.0525836944580078e+00
    phi[0,4]  R400      -4.8115390539169312e-01
    phi[0,4]  R401      1.3090106844902039e-01
    phi[0,4]  R402      0.150233194231987
    phi[0,4]  R403      -2.5207295417785645e+00
    phi[0,4]  R404      -3.3459177017211914e+00
    phi[0,4]  R405      -1.4203413724899292e+00
    phi[0,4]  R406      -0.198886901140213
    phi[0,4]  R407      -1.3393635749816895e+00
    phi[0,4]  R408      -2.7078204154968262e+00
    phi[0,4]  R409      -1.3536406755447388e+00
    phi[0,4]  R410      9.2417567968368530e-01
    phi[0,4]  R411      -2.5498208999633789e+00
    phi[0,4]  R412      8.7446987628936768e-01
    phi[0,4]  R413      1.5119456052780151e+00
    phi[0,4]  R414      -1.8385847806930542e+00
    phi[0,4]  R415      -2.2482223510742188e+00
    phi[0,4]  R416      -1.2958370447158813e+00
    phi[0,4]  R417      -8.0106329917907715e-01
    phi[0,4]  R418      9.7039178013801575e-02
    phi[0,4]  R419      -2.2740507125854492e+00
    phi[0,4]  R420      -4.6221889555454254e-02
    phi[0,4]  R421      5.8612763881683350e-01
    phi[0,4]  R422      1.8060906231403351e-01
    phi[0,4]  R423      7.2762691974639893e-01
    phi[0,4]  R424      -9.6866947412490845e-01
    phi[0,4]  R425      3.7237685173749924e-03
    phi[0,4]  R426      -3.8075485825538635e-01
    phi[0,4]  R427      2.3247180879116058e-01
    phi[0,4]  R428      8.5076552629470825e-01
    phi[0,4]  R429      -1.2772547006607056e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R430      -3.0999999046325684e+00
    phi[4,0]  R431      -3.0999999046325684e+00
    phi[4,0]  R432      -2.2400000095367432e+00
    phi[4,0]  R433      -2.2400000095367432e+00
    phi[4,0]  R434      -3.0999999046325684e+00
    phi[4,0]  R435      -3.0999999046325684e+00
    phi[4,0]  R436      -2.5699999332427979e+00
    phi[4,0]  R437      -2.5699999332427979e+00
    phi[4,0]  R438      -3.0999999046325684e+00
    phi[4,0]  R439      -3.0999999046325684e+00
    phi[4,0]  R440      -2.0899999141693115e+00
    phi[4,0]  R441      -2.0899999141693115e+00
    phi[4,0]  R442      -3.0999999046325684e+00
    phi[4,0]  R443      -3.0999999046325684e+00
    phi[4,0]  R444      1.2876926660537720e+00
    phi[4,0]  R445      1.7858449220657349e+00
    phi[4,0]  R446      1.2794536352157593e+00
    phi[4,0]  R447      6.0153192281723022e-01
    phi[4,0]  R448      2.2252583503723145e+00
    phi[4,0]  R449      0.828194260597229
    phi[4,0]  R450      9.5010602474212646e-01
    phi[4,0]  R451      2.1598362922668457e+00
    phi[4,0]  R452      1.2177836894989014e+00
    phi[4,0]  R453      6.2312108278274536e-01
    phi[4,0]  R454      -9.5100885629653931e-01
    phi[4,0]  R455      -3.3563313484191895e+00
    phi[4,0]  R456      -2.0805172920227051e+00
    phi[4,0]  R457      -3.2488257884979248e+00
    phi[4,0]  R458      -4.0639810562133789e+00
    phi[4,0]  R459      -3.6794190406799316e+00
    phi[4,0]  R460      -1.6260633468627930e+00
    phi[4,0]  R461      -2.5315217971801758e+00
    phi[4,0]  R462      -2.3085432052612305e+00
    phi[4,0]  R463      -2.4476613998413086e+00
    phi[4,0]  R464      -2.5149133205413818e+00
    phi[4,0]  R465      -9.9706232547760010e-01
    phi[4,0]  R466      -7.7825969457626343e-01
    phi[4,0]  R467      -2.2911386489868164e+00
    phi[4,0]  R468      1.3851609826087952e-01
    phi[4,0]  R469      -4.2769312858581543e-04
    phi[4,0]  R470      -3.7595915794372559e-01
    phi[4,0]  R471      -2.6977107524871826e+00
    phi[4,0]  R472      -2.2754948139190674e+00
    phi[4,0]  R473      -5.6862151622772217e-01
    phi[4,0]  R474      -1.4224802255630493e+00
    phi[4,0]  R475      -0.834635317325592
    phi[4,0]  R476      -1.4658658504486084e+00
    phi[4,0]  R477      -1.4826879501342773e+00
    phi[4,0]  R478      1.2372667789459229e+00
    phi[4,0]  R479      -6.8143361806869507e-01
    phi[4,0]  R480      -2.8161978721618652e-01
    phi[4,0]  R481      -8.2134252786636353e-01
    phi[4,0]  R482      -1.9720678329467773e+00
    phi[4,0]  R483      -2.2614393234252930e+00
    phi[4,0]  R484      -9.2362242937088013e-01
    phi[4,0]  R485      -9.3353599309921265e-01
    phi[4,0]  R486      -2.8592083454132080e+00
    phi[4,0]  R487      9.9744945764541626e-01
    phi[4,0]  R488      -9.3784385919570923e-01
    phi[4,0]  R489      -1.8985871970653534e-01
    phi[4,0]  R490      -0.11457559466362
    phi[4,0]  R491      -0.611226499080658
    phi[4,0]  R492      -8.4949588775634766e-01
    phi[4,0]  R493      -2.0525836944580078e+00
    phi[4,0]  R494      -4.8115390539169312e-01
    phi[4,0]  R495      1.3090106844902039e-01
    phi[4,0]  R496      0.150233194231987
    phi[4,0]  R497      -2.5207295417785645e+00
    phi[4,0]  R498      -3.3459177017211914e+00
    phi[4,0]  R499      -1.4203413724899292e+00
    phi[4,0]  R500      -0.198886901140213
    phi[4,0]  R501      -1.3393635749816895e+00
    phi[4,0]  R502      -2.7078204154968262e+00
    phi[4,0]  R503      -1.3536406755447388e+00
    phi[4,0]  R504      9.2417567968368530e-01
    phi[4,0]  R505      -2.5498208999633789e+00
    phi[4,0]  R506      8.7446987628936768e-01
    phi[4,0]  R507      1.5119456052780151e+00
    phi[4,0]  R508      -1.8385847806930542e+00
    phi[4,0]  R509      -2.2482223510742188e+00
    phi[4,0]  R510      -1.2958370447158813e+00
    phi[4,0]  R511      -8.0106329917907715e-01
    phi[4,0]  R512      9.7039178013801575e-02
    phi[4,0]  R513      -2.2740507125854492e+00
    phi[4,0]  R514      -4.6221889555454254e-02
    phi[4,0]  R515      5.8612763881683350e-01
    phi[4,0]  R516      1.8060906231403351e-01
    phi[4,0]  R517      7.2762691974639893e-01
    phi[4,0]  R518      -9.6866947412490845e-01
    phi[4,0]  R519      3.7237685173749924e-03
    phi[4,0]  R520      -3.8075485825538635e-01
    phi[4,0]  R521      2.3247180879116058e-01
    phi[4,0]  R522      8.5076552629470825e-01
    phi[4,0]  R523      -1.2772547006607056e+00
    phi[4,0]  R524      8.2204186916351318e-01
    phi[4,0]  R525      -1.5355687141418457e+00
    phi[4,0]  R526      7.7809435129165649e-01
    phi[4,0]  R527      1.7362434864044189e+00
    phi[4,0]  R528      2.0645534992218018e+00
    phi[4,0]  R529      1.0654863119125366e+00
    phi[4,0]  R530      1.5956361293792725e+00
    phi[4,0]  R531      2.35722279548645
    phi[4,0]  R532      1.6249700784683228e+00
    phi[4,0]  R533      5.8969491720199585e-01
    phi[4,0]  R534      -1.1283679008483887e+00
    phi[4,0]  R535      -8.8904851675033569e-01
    phi[4,0]  R536      -1.2689760923385620e+00
    phi[4,0]  R537      -2.1150507926940918e+00
    phi[4,0]  R538      -1.0663774013519287e+00
    phi[4,0]  R539      -1.6495133638381958e+00
    phi[4,0]  R540      -1.7876969575881958e+00
    phi[4,0]  R541      -2.1545734405517578e+00
    phi[4,0]  R542      -1.9888492822647095e+00
    phi[4,0]  R543      -2.4679982662200928e+00
    phi[4,0]  R544      -1.6190400123596191e+00
    phi[4,0]  R545      -1.2137428522109985e+00
    phi[4,0]  R546      -9.9427509307861328e-01
    phi[4,0]  R547      -1.9108096361160278e+00
    phi[4,0]  R548      1.0506602525711060e+00
    phi[4,0]  R549      -3.7995693087577820e-01
    phi[4,0]  R550      -3.0779085159301758e+00
    phi[4,0]  R551      -1.3453286886215210e+00
    phi[4,0]  R552      -1.7443501949310303e+00
    phi[4,0]  R553      -1.5603388547897339e+00
    phi[4,0]  R554      -2.1415870189666748e+00
    phi[4,0]  R555      4.2512229084968567e-01
    phi[4,0]  R556      -7.6467859745025635e-01
    phi[4,0]  R557      5.6004941463470459e-01
    phi[4,0]  R558      -1.6723041534423828e+00
    phi[4,0]  R559      -2.2941758632659912e+00
    phi[4,0]  R560      -1.5266613960266113e+00
    phi[4,0]  R561      4.1331166028976440e-01
    phi[4,0]  R562      -1.1123176813125610e+00
    phi[4,0]  R563      -7.5530248880386353e-01
    phi[4,0]  R564      -1.4328337907791138e+00
    phi[4,0]  R565      -2.3254852294921875e+00
    phi[4,0]  R566      -7.0821315050125122e-01
    phi[4,0]  R567      -9.2190051078796387e-01
    phi[4,0]  R568      -4.2791271209716797e-01
    phi[4,0]  R569      -1.6778037548065186e+00
    phi[4,0]  R570      -1.0415605306625366e+00
    phi[4,0]  R571      -3.7993150949478149e-01
    phi[4,0]  R572      -1.4740023612976074e+00
    phi[4,0]  R573      -1.8155421018600464e+00
    phi[4,0]  R574      -1.7303017377853394e+00
    phi[4,0]  R575      -5.6986922025680542e-01
    phi[4,0]  R576      -1.0568298101425171e+00
    phi[4,0]  R577      -1.2585718631744385e+00
    phi[4,0]  R578      -7.7688217163085938e-01
    phi[4,0]  R579      -2.4530377388000488e+00
    phi[4,0]  R580      -9.1006451845169067e-01
    phi[4,0]  R581      -5.3525978326797485e-01
    phi[4,0]  R582      -6.3049727678298950e-01
    phi[4,0]  R583      -1.1754255294799805e+00
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R584      -3.0999999046325684e+00
    phi[0,5]  R585      -3.0999999046325684e+00
    phi[0,5]  R586      -2.2400000095367432e+00
    phi[0,5]  R587      -2.2400000095367432e+00
    phi[0,5]  R588      -3.0999999046325684e+00
    phi[0,5]  R589      -3.0999999046325684e+00
    phi[0,5]  R590      -2.5699999332427979e+00
    phi[0,5]  R591      -2.5699999332427979e+00
    phi[0,5]  R592      -3.0999999046325684e+00
    phi[0,5]  R593      -3.0999999046325684e+00
    phi[0,5]  R594      -2.0899999141693115e+00
    phi[0,5]  R595      -2.0899999141693115e+00
    phi[0,5]  R596      -3.0999999046325684e+00
    phi[0,5]  R597      -3.0999999046325684e+00
    phi[0,5]  R598      8.2204186916351318e-01
    phi[0,5]  R599      -1.5355687141418457e+00
    phi[0,5]  R600      7.7809435129165649e-01
    phi[0,5]  R601      1.7362434864044189e+00
    phi[0,5]  R602      2.0645534992218018e+00
    phi[0,5]  R603      1.0654863119125366e+00
    phi[0,5]  R604      1.5956361293792725e+00
    phi[0,5]  R605      2.35722279548645
    phi[0,5]  R606      1.6249700784683228e+00
    phi[0,5]  R607      5.8969491720199585e-01
    phi[0,5]  R608      -1.1283679008483887e+00
    phi[0,5]  R609      -8.8904851675033569e-01
    phi[0,5]  R610      -1.2689760923385620e+00
    phi[0,5]  R611      -2.1150507926940918e+00
    phi[0,5]  R612      -1.0663774013519287e+00
    phi[0,5]  R613      -1.6495133638381958e+00
    phi[0,5]  R614      -1.7876969575881958e+00
    phi[0,5]  R615      -2.1545734405517578e+00
    phi[0,5]  R616      -1.9888492822647095e+00
    phi[0,5]  R617      -2.4679982662200928e+00
    phi[0,5]  R618      -1.6190400123596191e+00
    phi[0,5]  R619      -1.2137428522109985e+00
    phi[0,5]  R620      -9.9427509307861328e-01
    phi[0,5]  R621      -1.9108096361160278e+00
    phi[0,5]  R622      1.0506602525711060e+00
    phi[0,5]  R623      -3.7995693087577820e-01
    phi[0,5]  R624      -3.0779085159301758e+00
    phi[0,5]  R625      -1.3453286886215210e+00
    phi[0,5]  R626      -1.7443501949310303e+00
    phi[0,5]  R627      -1.5603388547897339e+00
    phi[0,5]  R628      -2.1415870189666748e+00
    phi[0,5]  R629      4.2512229084968567e-01
    phi[0,5]  R630      -7.6467859745025635e-01
    phi[0,5]  R631      5.6004941463470459e-01
    phi[0,5]  R632      -1.6723041534423828e+00
    phi[0,5]  R633      -2.2941758632659912e+00
    phi[0,5]  R634      -1.5266613960266113e+00
    phi[0,5]  R635      4.1331166028976440e-01
    phi[0,5]  R636      -1.1123176813125610e+00
    phi[0,5]  R637      -7.5530248880386353e-01
    phi[0,5]  R638      -1.4328337907791138e+00
    phi[0,5]  R639      -2.3254852294921875e+00
    phi[0,5]  R640      -7.0821315050125122e-01
    phi[0,5]  R641      -9.2190051078796387e-01
    phi[0,5]  R642      -4.2791271209716797e-01
    phi[0,5]  R643      -1.6778037548065186e+00
    phi[0,5]  R644      -1.0415605306625366e+00
    phi[0,5]  R645      -3.7993150949478149e-01
    phi[0,5]  R646      -1.4740023612976074e+00
    phi[0,5]  R647      -1.8155421018600464e+00
    phi[0,5]  R648      -1.7303017377853394e+00
    phi[0,5]  R649      -5.6986922025680542e-01
    phi[0,5]  R650      -1.0568298101425171e+00
    phi[0,5]  R651      -1.2585718631744385e+00
    phi[0,5]  R652      -7.7688217163085938e-01
    phi[0,5]  R653      -2.4530377388000488e+00
    phi[0,5]  R654      -9.1006451845169067e-01
    phi[0,5]  R655      -5.3525978326797485e-01
    phi[0,5]  R656      -6.3049727678298950e-01
    phi[0,5]  R657      -1.1754255294799805e+00
    phi[0,5]  R658      3.5862150788307190e-01
    phi[0,5]  R659      -8.8397532701492310e-02
    phi[0,5]  R660      -2.3632271289825439e+00
    phi[0,5]  R661      -1.6439291238784790e+00
    phi[0,5]  R662      -5.5766832828521729e-01
    phi[0,5]  R663      4.1910272836685181e-01
    phi[0,5]  R664      0.538382351398468
    phi[0,5]  R665      4.2780020833015442e-01
    phi[0,5]  R666      9.2371094226837158e-01
    phi[0,5]  R667      -4.9513936042785645e-01
    phi[0,5]  R668      -3.7828025817871094e+00
    phi[0,5]  R669      -1.0869710445404053e+00
    phi[0,5]  R670      -2.1998443603515625e+00
    phi[0,5]  R671      -2.2529246807098389e+00
    phi[0,5]  R672      -3.3244824409484863e+00
    phi[0,5]  R673      -1.7207760810852051e+00
    phi[0,5]  R674      -1.2366402149200439e+00
    phi[0,5]  R675      -2.2820990085601807e+00
    phi[0,5]  R676      -9.0117925405502319e-01
    phi[0,5]  R677      1.01506769657135
    phi[0,5]  R678      -1.0205707550048828e+00
    phi[0,5]  R679      -2.5271527767181396e+00
    phi[0,5]  R680      -3.2483839988708496e+00
    phi[0,5]  R681      -1.7225369215011597e+00
    phi[0,5]  R682      -2.0456347465515137e+00
    phi[0,5]  R683      1.3176333904266357e-01
    phi[0,5]  R684      -1.4420702457427979e+00
    phi[0,5]  R685      -1.2058852910995483e+00
    phi[0,5]  R686      -1.6367682218551636e+00
    phi[0,5]  R687      -9.8614972829818726e-01
    phi[0,5]  R688      -2.0370001792907715e+00
    phi[0,5]  R689      -1.0286095142364502e+00
    phi[0,5]  R690      -0.334529846906662
    phi[0,5]  R691      -1.6693704128265381e+00
    phi[0,5]  R692      -2.0915732383728027e+00
    phi[0,5]  R693      -1.4981856346130371e+00
    phi[0,5]  R694      -3.2042825222015381e-01
    phi[0,5]  R695      -1.4067845046520233e-01
    phi[0,5]  R696      6.2854802608489990e-01
    phi[0,5]  R697      4.0614315867424011e-01
    phi[0,5]  R698      -1.4917596578598022e+00
    phi[0,5]  R699      -1.2277196645736694e+00
    phi[0,5]  R700      -0.97231525182724
    phi[0,5]  R701      -5.2728354930877686e-01
    phi[0,5]  R702      -6.3815675675868988e-02
    phi[0,5]  R703      2.1822267770767212e-01
    phi[0,5]  R704      0.81246018409729
    phi[0,5]  R705      -1.0950099229812622e+00
    phi[0,5]  R706      9.7735381126403809e-01
    phi[0,5]  R707      -1.2340433597564697e+00
    phi[0,5]  R708      -1.3304902315139771e+00
    phi[0,5]  R709      -1.6969020366668701e+00
    phi[0,5]  R710      -0.729495108127594
    phi[0,5]  R711      3.6927068233489990e-01
    phi[0,5]  R712      -1.3265398740768433e+00
    phi[0,5]  R713      5.9096527099609375e-01
    phi[0,5]  R714      4.0344056487083435e-01
    phi[0,5]  R715      -1.0654102563858032e+00
    phi[0,5]  R716      -9.7947669029235840e-01
    phi[0,5]  R717      -7.9193478822708130e-01
    phi[0,5]  R718      -1.4723758697509766e+00
    phi[0,5]  R719      -1.9478726387023926e+00
    phi[0,5]  R720      -3.0355346202850342e+00
    phi[0,5]  R721      -1.4996035397052765e-01
    phi[0,5]  R722      -1.5929557085037231e+00
    phi[0,5]  R723      -4.45606803894043
    phi[0,5]  R724      3.6826890707015991e-01
    phi[0,5]  R725      -5.6327456235885620e-01
    phi[0,5]  R726      2.0189964771270752e-01
    phi[0,5]  R727      -1.1730509996414185e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R728      -3.0999999046325684e+00
    phi[5,0]  R729      -3.0999999046325684e+00
    phi[5,0]  R730      -2.2400000095367432e+00
    phi[5,0]  R731      -2.2400000095367432e+00
    phi[5,0]  R732      -3.0999999046325684e+00
    phi[5,0]  R733      -3.0999999046325684e+00
    phi[5,0]  R734      -2.5699999332427979e+00
    phi[5,0]  R735      -2.5699999332427979e+00
    phi[5,0]  R736      -3.0999999046325684e+00
    phi[5,0]  R737      -3.0999999046325684e+00
    phi[5,0]  R738      -2.0899999141693115e+00
    phi[5,0]  R739      -2.0899999141693115e+00
    phi[5,0]  R740      -3.0999999046325684e+00
    phi[5,0]  R741      -3.0999999046325684e+00
    phi[5,0]  R742      3.5862150788307190e-01
    phi[5,0]  R743      -8.8397532701492310e-02
    phi[5,0]  R744      -2.3632271289825439e+00
    phi[5,0]  R745      -1.6439291238784790e+00
    phi[5,0]  R746      -5.5766832828521729e-01
    phi[5,0]  R747      4.1910272836685181e-01
    phi[5,0]  R748      0.538382351398468
    phi[5,0]  R749      4.2780020833015442e-01
    phi[5,0]  R750      9.2371094226837158e-01
    phi[5,0]  R751      -4.9513936042785645e-01
    phi[5,0]  R752      -3.7828025817871094e+00
    phi[5,0]  R753      -1.0869710445404053e+00
    phi[5,0]  R754      -2.1998443603515625e+00
    phi[5,0]  R755      -2.2529246807098389e+00
    phi[5,0]  R756      -3.3244824409484863e+00
    phi[5,0]  R757      -1.7207760810852051e+00
    phi[5,0]  R758      -1.2366402149200439e+00
    phi[5,0]  R759      -2.2820990085601807e+00
    phi[5,0]  R760      -9.0117925405502319e-01
    phi[5,0]  R761      1.01506769657135
    phi[5,0]  R762      -1.0205707550048828e+00
    phi[5,0]  R763      -2.5271527767181396e+00
    phi[5,0]  R764      -3.2483839988708496e+00
    phi[5,0]  R765      -1.7225369215011597e+00
    phi[5,0]  R766      -2.0456347465515137e+00
    phi[5,0]  R767      1.3176333904266357e-01
    phi[5,0]  R768      -1.4420702457427979e+00
    phi[5,0]  R769      -1.2058852910995483e+00
    phi[5,0]  R770      -1.6367682218551636e+00
    phi[5,0]  R771      -9.8614972829818726e-01
    phi[5,0]  R772      -2.0370001792907715e+00
    phi[5,0]  R773      -1.0286095142364502e+00
    phi[5,0]  R774      -0.334529846906662
    phi[5,0]  R775      -1.6693704128265381e+00
    phi[5,0]  R776      -2.0915732383728027e+00
    phi[5,0]  R777      -1.4981856346130371e+00
    phi[5,0]  R778      -3.2042825222015381e-01
    phi[5,0]  R779      -1.4067845046520233e-01
    phi[5,0]  R780      6.2854802608489990e-01
    phi[5,0]  R781      4.0614315867424011e-01
    phi[5,0]  R782      -1.4917596578598022e+00
    phi[5,0]  R783      -1.2277196645736694e+00
    phi[5,0]  R784      -0.97231525182724
    phi[5,0]  R785      -5.2728354930877686e-01
    phi[5,0]  R786      -6.3815675675868988e-02
    phi[5,0]  R787      2.1822267770767212e-01
    phi[5,0]  R788      0.81246018409729
    phi[5,0]  R789      -1.0950099229812622e+00
    phi[5,0]  R790      9.7735381126403809e-01
    phi[5,0]  R791      -1.2340433597564697e+00
    phi[5,0]  R792      -1.3304902315139771e+00
    phi[5,0]  R793      -1.6969020366668701e+00
    phi[5,0]  R794      -0.729495108127594
    phi[5,0]  R795      3.6927068233489990e-01
    phi[5,0]  R796      -1.3265398740768433e+00
    phi[5,0]  R797      5.9096527099609375e-01
    phi[5,0]  R798      4.0344056487083435e-01
    phi[5,0]  R799      -1.0654102563858032e+00
    phi[5,0]  R800      -9.7947669029235840e-01
    phi[5,0]  R801      -7.9193478822708130e-01
    phi[5,0]  R802      -1.4723758697509766e+00
    phi[5,0]  R803      -1.9478726387023926e+00
    phi[5,0]  R804      -3.0355346202850342e+00
    phi[5,0]  R805      -1.4996035397052765e-01
    phi[5,0]  R806      -1.5929557085037231e+00
    phi[5,0]  R807      -4.45606803894043
    phi[5,0]  R808      3.6826890707015991e-01
    phi[5,0]  R809      -5.6327456235885620e-01
    phi[5,0]  R810      2.0189964771270752e-01
    phi[5,0]  R811      -1.1730509996414185e+00
    phi[5,0]  R812      8.2204186916351318e-01
    phi[5,0]  R813      -1.5355687141418457e+00
    phi[5,0]  R814      7.7809435129165649e-01
    phi[5,0]  R815      1.7362434864044189e+00
    phi[5,0]  R816      2.0645534992218018e+00
    phi[5,0]  R817      1.0654863119125366e+00
    phi[5,0]  R818      1.5956361293792725e+00
    phi[5,0]  R819      2.35722279548645
    phi[5,0]  R820      1.6249700784683228e+00
    phi[5,0]  R821      5.8969491720199585e-01
    phi[5,0]  R822      -1.1283679008483887e+00
    phi[5,0]  R823      -8.8904851675033569e-01
    phi[5,0]  R824      -1.2689760923385620e+00
    phi[5,0]  R825      -2.1150507926940918e+00
    phi[5,0]  R826      -1.0663774013519287e+00
    phi[5,0]  R827      -1.6495133638381958e+00
    phi[5,0]  R828      -1.7876969575881958e+00
    phi[5,0]  R829      -2.1545734405517578e+00
    phi[5,0]  R830      -1.9888492822647095e+00
    phi[5,0]  R831      -2.4679982662200928e+00
    phi[5,0]  R832      -1.6190400123596191e+00
    phi[5,0]  R833      -1.2137428522109985e+00
    phi[5,0]  R834      -9.9427509307861328e-01
    phi[5,0]  R835      -1.9108096361160278e+00
    phi[5,0]  R836      1.0506602525711060e+00
    phi[5,0]  R837      -3.7995693087577820e-01
    phi[5,0]  R838      -3.0779085159301758e+00
    phi[5,0]  R839      -1.3453286886215210e+00
    phi[5,0]  R840      -1.7443501949310303e+00
    phi[5,0]  R841      -1.5603388547897339e+00
    phi[5,0]  R842      -2.1415870189666748e+00
    phi[5,0]  R843      4.2512229084968567e-01
    phi[5,0]  R844      -7.6467859745025635e-01
    phi[5,0]  R845      5.6004941463470459e-01
    phi[5,0]  R846      -1.6723041534423828e+00
    phi[5,0]  R847      -2.2941758632659912e+00
    phi[5,0]  R848      -1.5266613960266113e+00
    phi[5,0]  R849      4.1331166028976440e-01
    phi[5,0]  R850      -1.1123176813125610e+00
    phi[5,0]  R851      -7.5530248880386353e-01
    phi[5,0]  R852      -1.4328337907791138e+00
    phi[5,0]  R853      -2.3254852294921875e+00
    phi[5,0]  R854      -7.0821315050125122e-01
    phi[5,0]  R855      -9.2190051078796387e-01
    phi[5,0]  R856      -4.2791271209716797e-01
    phi[5,0]  R857      -1.6778037548065186e+00
    phi[5,0]  R858      -1.0415605306625366e+00
    phi[5,0]  R859      -3.7993150949478149e-01
    phi[5,0]  R860      -1.4740023612976074e+00
    phi[5,0]  R861      -1.8155421018600464e+00
    phi[5,0]  R862      -1.7303017377853394e+00
    phi[5,0]  R863      -5.6986922025680542e-01
    phi[5,0]  R864      -1.0568298101425171e+00
    phi[5,0]  R865      -1.2585718631744385e+00
    phi[5,0]  R866      -7.7688217163085938e-01
    phi[5,0]  R867      -2.4530377388000488e+00
    phi[5,0]  R868      -9.1006451845169067e-01
    phi[5,0]  R869      -5.3525978326797485e-01
    phi[5,0]  R870      -6.3049727678298950e-01
    phi[5,0]  R871      -1.1754255294799805e+00
    phi[8,0]  R0        -1
    phi[8,0]  R2        1.3567283072419181e+00
    phi[8,0]  R3        -1.7372120413499115e-02
    phi[8,0]  R4        -2.4839895291357847e+00
    phi[8,0]  R5        2.4987097719418014e+00
    phi[8,0]  R6        1.7682589915159661e+00
    phi[8,0]  R7        -3.5276147398467406e-01
    phi[8,0]  R8        8.9427933357589140e-01
    phi[8,0]  R72       1
    phi[8,0]  R872      -4.4567282118744860e+00
    phi[8,0]  R873      -1.7432715973906503e+00
    phi[8,0]  R874      -2.2226278891232440e+00
    phi[8,0]  R875      -2.2573721299502423e+00
    phi[8,0]  R876      -6.1601037549678361e-01
    phi[8,0]  R877      -5.5839894337683535e+00
    phi[8,0]  R878      -5.0687097051845988e+00
    phi[8,0]  R879      -7.1290161300996413e-02
    phi[8,0]  R880      -4.8682588961485340e+00
    phi[8,0]  R881      -1.3317409131166023e+00
    phi[8,0]  R882      -1.7372384401846375e+00
    phi[8,0]  R883      -2.4427613881539854e+00
    phi[8,0]  R884      -3.9942792382084598e+00
    phi[8,0]  R885      -2.2057205710566770e+00
    phi[8,0]  R886      -1.3729361097118842e-01
    phi[8,0]  R887      -1.5194710791829613e-01
    phi[8,0]  R888      -1.5764562872765620e-01
    phi[8,0]  R889      -1.6879301877036346e-01
    phi[8,0]  R890      -1.6919454868699946e-01
    phi[8,0]  R891      -1.8706272741068397e-01
    phi[8,0]  R892      -1.8950529243219849e-01
    phi[8,0]  R893      -1.9039376694889754e-01
    phi[8,0]  R894      -2.0284673283045929e-01
    phi[8,0]  R895      -7.7255447083473672e-01
    phi[8,0]  R896      -5.4295068463541130e-01
    phi[8,0]  R897      -5.5490241709778687e-01
    phi[8,0]  R898      -5.6159962760389392e-01
    phi[8,0]  R899      -5.6701812129837492e-01
    phi[8,0]  R900      -5.7839285469536950e-01
    phi[8,0]  R901      -5.9068905732098287e-01
    phi[8,0]  R902      -5.9114193499887779e-01
    phi[8,0]  R903      -5.9327688899000419e-01
    phi[8,0]  R904      -5.9408808367438048e-01
    phi[8,0]  R905      -0.616150767165178
    phi[8,0]  R906      -0.434379236910994
    phi[8,0]  R907      -4.9884180525407062e-01
    phi[8,0]  R908      -5.5192918724772722e-01
    phi[8,0]  R909      -6.6802733362371525e-01
    phi[8,0]  R910      -7.2972646595085777e-01
    phi[8,0]  R911      -7.3536132834751955e-01
    phi[8,0]  R912      -0.759674897271494
    phi[8,0]  R913      -1.9816379868862106e+00
    phi[8,0]  R914      -2.7277931815277685e+00
    phi[8,0]  R915      -2.6572493716285410e+00
    phi[8,0]  R916      -4.4334360194756539e-01
    phi[8,0]  R917      -4.4642047730649470e-01
    phi[8,0]  R918      -5.1121364582586537e-01
    phi[8,0]  R919      -5.4016096647609646e-01
    phi[8,0]  R920      -5.5788019261428268e-01
    phi[8,0]  R921      -5.7331289397251983e-01
    phi[8,0]  R922      -5.8021787440721928e-01
    phi[8,0]  R923      -6.2332241091553242e-01
    phi[8,0]  R924      -6.2524267214367168e-01
    phi[8,0]  R925      -6.7859075816441394e-01
    phi[8,0]  R926      -3.9030318421864352e-01
    phi[8,0]  R927      -4.3845357946414487e-01
    phi[8,0]  R928      -0.514089732941497
    phi[8,0]  R929      -5.3083808904868990e-01
    phi[8,0]  R930      -5.3265171416254686e-01
    phi[8,0]  R931      -5.3889117026684175e-01
    phi[8,0]  R932      -5.4459163823464474e-01
    phi[8,0]  R933      -0.566266213902749
    phi[8,0]  R934      -5.8619895515673759e-01
    phi[8,0]  R935      -3.6546965712837745e+00
    phi[8,0]  R936      -2.8660484307890854e-01
    phi[8,0]  R937      -3.8067287503600733e-01
    phi[8,0]  R938      -3.8768871026094742e-01
    phi[8,0]  R939      -4.5935642149563494e-01
    phi[8,0]  R940      -5.4869650880978749e-01
    phi[8,0]  R941      -6.0287019239774331e-01
    phi[8,0]  R942      -8.8496853069599513e-01
    phi[8,0]  R943      -8.8699991995653327e-01
    phi[8,0]  R944      -8.8809084664851090e-01
    phi[8,0]  R945      -8.8882538798588218e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R946      -3.0999999046325684e+00
    phi[1,2]  R947      -3.0999999046325684e+00
    phi[1,2]  R948      -2.2400000095367432e+00
    phi[1,2]  R949      -2.2400000095367432e+00
    phi[1,2]  R950      -3.0999999046325684e+00
    phi[1,2]  R951      -3.0999999046325684e+00
    phi[1,2]  R952      -2.5699999332427979e+00
    phi[1,2]  R953      -2.5699999332427979e+00
    phi[1,2]  R954      -3.0999999046325684e+00
    phi[1,2]  R955      -3.0999999046325684e+00
    phi[1,2]  R956      -2.0899999141693115e+00
    phi[1,2]  R957      -2.0899999141693115e+00
    phi[1,2]  R958      -3.0999999046325684e+00
    phi[1,2]  R959      -3.0999999046325684e+00
    phi[1,2]  R960      1.9033626317977905e+00
    phi[1,2]  R961      -0.326955109834671
    phi[1,2]  R962      2.0944395065307617e+00
    phi[1,2]  R963      3.4711289405822754e-01
    phi[1,2]  R964      -1.4293063879013062e+00
    phi[1,2]  R965      4.7431564331054688e-01
    phi[1,2]  R966      -2.1994407176971436e+00
    phi[1,2]  R967      -2.8046000003814697e+00
    phi[1,2]  R968      -4.6077299118041992e-01
    phi[1,2]  R969      -5.9478712081909180e-01
    phi[1,2]  R970      4.5901998877525330e-01
    phi[1,2]  R971      -8.8368499279022217e-01
    phi[1,2]  R972      -1.0490156412124634e+00
    phi[1,2]  R973      3.0581495165824890e-01
    phi[1,2]  R974      -3.5239839553833008e-01
    phi[1,2]  R975      -4.2484962940216064e-01
    phi[1,2]  R976      -1.3119363784790039e+00
    phi[1,2]  R977      -2.41902232170105
    phi[1,2]  R978      -3.1082506179809570e+00
    phi[1,2]  R979      -3.8047525882720947e+00
    phi[1,2]  R980      -7.5253582000732422e-01
    phi[1,2]  R981      -9.3663769960403442e-01
    phi[1,2]  R982      1.4129548072814941e+00
    phi[1,2]  R983      -7.7636218070983887e-01
    phi[1,2]  R984      -6.0727477073669434e-02
    phi[1,2]  R985      -1.21875
    phi[1,2]  R986      -1.4323198795318604e+00
    phi[1,2]  R987      2.1171543598175049e+00
    phi[1,2]  R988      6.5808349847793579e-01
    phi[1,2]  R989      -1.2099655866622925e+00
    phi[1,2]  R990      -3.9904829859733582e-01
    phi[1,2]  R991      1.2998136281967163e+00
    phi[1,2]  R992      -2.7281978726387024e-01
    phi[1,2]  R993      6.2350833415985107e-01
    phi[1,2]  R994      -0.190694198012352
    phi[1,2]  R995      2.1254785358905792e-01
    phi[1,2]  R996      -2.46032452583313
    phi[1,2]  R997      -2.2105915546417236e+00
    phi[1,2]  R998      -2.0161082744598389e+00
    phi[1,2]  R999      -2.4433412551879883e+00
    phi[1,2]  R1000     -8.6483329534530640e-01
    phi[1,2]  R1001     -8.0825787782669067e-01
    phi[1,2]  R1002     1.0437054634094238e+00
    phi[1,2]  R1003     -1.2570858001708984e+00
    phi[1,2]  R1004     -8.0240339040756226e-01
    phi[1,2]  R1005     -1.7341774702072144e+00
    phi[1,2]  R1006     -5.9906393289566040e-01
    phi[1,2]  R1007     -4.3571156263351440e-01
    phi[1,2]  R1008     1.9068117439746857e-01
    phi[1,2]  R1009     6.8291515111923218e-01
    phi[1,2]  R1010     -1.1162043809890747e+00
    phi[1,2]  R1011     -4.4823470711708069e-01
    phi[1,2]  R1012     -2.0030717849731445e+00
    phi[1,2]  R1013     -1.3136255741119385e+00
    phi[1,2]  R1014     -2.1125154495239258e+00
    phi[1,2]  R1015     -6.3643038272857666e-01
    phi[1,2]  R1016     -2.1707201004028320e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R1017     -3.0999999046325684e+00
    phi[2,1]  R1018     -3.0999999046325684e+00
    phi[2,1]  R1019     -2.2400000095367432e+00
    phi[2,1]  R1020     -2.2400000095367432e+00
    phi[2,1]  R1021     -3.0999999046325684e+00
    phi[2,1]  R1022     -3.0999999046325684e+00
    phi[2,1]  R1023     -2.5699999332427979e+00
    phi[2,1]  R1024     -2.5699999332427979e+00
    phi[2,1]  R1025     -3.0999999046325684e+00
    phi[2,1]  R1026     -3.0999999046325684e+00
    phi[2,1]  R1027     -2.0899999141693115e+00
    phi[2,1]  R1028     -2.0899999141693115e+00
    phi[2,1]  R1029     -3.0999999046325684e+00
    phi[2,1]  R1030     -3.0999999046325684e+00
    phi[2,1]  R1031     2.1171543598175049e+00
    phi[2,1]  R1032     6.5808349847793579e-01
    phi[2,1]  R1033     -1.2099655866622925e+00
    phi[2,1]  R1034     -3.9904829859733582e-01
    phi[2,1]  R1035     1.2998136281967163e+00
    phi[2,1]  R1036     -2.7281978726387024e-01
    phi[2,1]  R1037     6.2350833415985107e-01
    phi[2,1]  R1038     -0.190694198012352
    phi[2,1]  R1039     2.1254785358905792e-01
    phi[2,1]  R1040     -2.46032452583313
    phi[2,1]  R1041     -2.2105915546417236e+00
    phi[2,1]  R1042     -2.0161082744598389e+00
    phi[2,1]  R1043     -2.4433412551879883e+00
    phi[2,1]  R1044     -8.6483329534530640e-01
    phi[2,1]  R1045     -8.0825787782669067e-01
    phi[2,1]  R1046     1.0437054634094238e+00
    phi[2,1]  R1047     -1.2570858001708984e+00
    phi[2,1]  R1048     -8.0240339040756226e-01
    phi[2,1]  R1049     -1.7341774702072144e+00
    phi[2,1]  R1050     -5.9906393289566040e-01
    phi[2,1]  R1051     -4.3571156263351440e-01
    phi[2,1]  R1052     1.9068117439746857e-01
    phi[2,1]  R1053     6.8291515111923218e-01
    phi[2,1]  R1054     -1.1162043809890747e+00
    phi[2,1]  R1055     -4.4823470711708069e-01
    phi[2,1]  R1056     -2.0030717849731445e+00
    phi[2,1]  R1057     -1.3136255741119385e+00
    phi[2,1]  R1058     -2.1125154495239258e+00
    phi[2,1]  R1059     -6.3643038272857666e-01
    phi[2,1]  R1060     -2.1707201004028320e+00
    phi[2,1]  R1061     1.9033626317977905e+00
    phi[2,1]  R1062     -0.326955109834671
    phi[2,1]  R1063     2.0944395065307617e+00
    phi[2,1]  R1064     3.4711289405822754e-01
    phi[2,1]  R1065     -1.4293063879013062e+00
    phi[2,1]  R1066     4.7431564331054688e-01
    phi[2,1]  R1067     -2.1994407176971436e+00
    phi[2,1]  R1068     -2.8046000003814697e+00
    phi[2,1]  R1069     -4.6077299118041992e-01
    phi[2,1]  R1070     -5.9478712081909180e-01
    phi[2,1]  R1071     4.5901998877525330e-01
    phi[2,1]  R1072     -8.8368499279022217e-01
    phi[2,1]  R1073     -1.0490156412124634e+00
    phi[2,1]  R1074     3.0581495165824890e-01
    phi[2,1]  R1075     -3.5239839553833008e-01
    phi[2,1]  R1076     -4.2484962940216064e-01
    phi[2,1]  R1077     -1.3119363784790039e+00
    phi[2,1]  R1078     -2.41902232170105
    phi[2,1]  R1079     -3.1082506179809570e+00
    phi[2,1]  R1080     -3.8047525882720947e+00
    phi[2,1]  R1081     -7.5253582000732422e-01
    phi[2,1]  R1082     -9.3663769960403442e-01
    phi[2,1]  R1083     1.4129548072814941e+00
    phi[2,1]  R1084     -7.7636218070983887e-01
    phi[2,1]  R1085     -6.0727477073669434e-02
    phi[2,1]  R1086     -1.21875
    phi[2,1]  R1087     -1.4323198795318604e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1088     -3.0999999046325684e+00
    phi[2,3]  R1089     -3.0999999046325684e+00
    phi[2,3]  R1090     -2.2400000095367432e+00
    phi[2,3]  R1091     -2.2400000095367432e+00
    phi[2,3]  R1092     -3.0999999046325684e+00
    phi[2,3]  R1093     -3.0999999046325684e+00
    phi[2,3]  R1094     -2.5699999332427979e+00
    phi[2,3]  R1095     -2.5699999332427979e+00
    phi[2,3]  R1096     -3.0999999046325684e+00
    phi[2,3]  R1097     -3.0999999046325684e+00
    phi[2,3]  R1098     -2.0899999141693115e+00
    phi[2,3]  R1099     -2.0899999141693115e+00
    phi[2,3]  R1100     -3.0999999046325684e+00
    phi[2,3]  R1101     -3.0999999046325684e+00
    phi[2,3]  R1102     2.1171543598175049e+00
    phi[2,3]  R1103     6.5808349847793579e-01
    phi[2,3]  R1104     -1.2099655866622925e+00
    phi[2,3]  R1105     -3.9904829859733582e-01
    phi[2,3]  R1106     1.2998136281967163e+00
    phi[2,3]  R1107     -2.7281978726387024e-01
    phi[2,3]  R1108     6.2350833415985107e-01
    phi[2,3]  R1109     -0.190694198012352
    phi[2,3]  R1110     2.1254785358905792e-01
    phi[2,3]  R1111     -2.46032452583313
    phi[2,3]  R1112     -2.2105915546417236e+00
    phi[2,3]  R1113     -2.0161082744598389e+00
    phi[2,3]  R1114     -2.4433412551879883e+00
    phi[2,3]  R1115     -8.6483329534530640e-01
    phi[2,3]  R1116     -8.0825787782669067e-01
    phi[2,3]  R1117     1.0437054634094238e+00
    phi[2,3]  R1118     -1.2570858001708984e+00
    phi[2,3]  R1119     -8.0240339040756226e-01
    phi[2,3]  R1120     -1.7341774702072144e+00
    phi[2,3]  R1121     -5.9906393289566040e-01
    phi[2,3]  R1122     -4.3571156263351440e-01
    phi[2,3]  R1123     1.9068117439746857e-01
    phi[2,3]  R1124     6.8291515111923218e-01
    phi[2,3]  R1125     -1.1162043809890747e+00
    phi[2,3]  R1126     -4.4823470711708069e-01
    phi[2,3]  R1127     -2.0030717849731445e+00
    phi[2,3]  R1128     -1.3136255741119385e+00
    phi[2,3]  R1129     -2.1125154495239258e+00
    phi[2,3]  R1130     -6.3643038272857666e-01
    phi[2,3]  R1131     -2.1707201004028320e+00
    phi[2,3]  R1132     9.0025734901428223e-01
    phi[2,3]  R1133     1.0605969429016113e+00
    phi[2,3]  R1134     1.8920346498489380e+00
    phi[2,3]  R1135     3.8706502318382263e-01
    phi[2,3]  R1136     2.0736405849456787e+00
    phi[2,3]  R1137     2.3381197452545166e+00
    phi[2,3]  R1138     2.5461647510528564e+00
    phi[2,3]  R1139     2.1254689693450928e+00
    phi[2,3]  R1140     1.6688864231109619e+00
    phi[2,3]  R1141     2.8265070915222168e+00
    phi[2,3]  R1142     -1.8422288894653320e+00
    phi[2,3]  R1143     -1.8020691871643066e+00
    phi[2,3]  R1144     -0.253984659910202
    phi[2,3]  R1145     -9.0316408872604370e-01
    phi[2,3]  R1146     -1.18865168094635
    phi[2,3]  R1147     -7.1086090803146362e-01
    phi[2,3]  R1148     -1.9460805654525757e+00
    phi[2,3]  R1149     -2.5952296257019043e+00
    phi[2,3]  R1150     -1.1347218751907349e+00
    phi[2,3]  R1151     -9.6284967660903931e-01
    phi[2,3]  R1152     1.3753581047058105e+00
    phi[2,3]  R1153     -3.3623225688934326e+00
    phi[2,3]  R1154     -1.4756593108177185e-01
    phi[2,3]  R1155     -3.7570407390594482e+00
    phi[2,3]  R1156     -3.2858762741088867e+00
    phi[2,3]  R1157     -1.0282185077667236e+00
    phi[2,3]  R1158     -8.3390957117080688e-01
    phi[2,3]  R1159     -1.7055542469024658e+00
    phi[2,3]  R1160     1.0807485878467560e-01
    phi[2,3]  R1161     -2.3921124935150146e+00
    phi[2,3]  R1162     -1.8905744552612305e+00
    phi[2,3]  R1163     -1.2648417949676514e+00
    phi[2,3]  R1164     -3.2647356986999512e+00
    phi[2,3]  R1165     -2.5097584724426270e+00
    phi[2,3]  R1166     -1.0411006212234497e+00
    phi[2,3]  R1167     -1.4013190269470215e+00
    phi[2,3]  R1168     -1.4764014482498169e+00
    phi[2,3]  R1169     9.8951049149036407e-02
    phi[2,3]  R1170     -1.4446837902069092e+00
    phi[2,3]  R1171     -7.1867114305496216e-01
    phi[2,3]  R1172     8.2380151748657227e-01
    phi[2,3]  R1173     -7.0742887258529663e-01
    phi[2,3]  R1174     -2.6190855503082275e+00
    phi[2,3]  R1175     -1.3313853740692139e+00
    phi[2,3]  R1176     -2.2638657093048096e+00
    phi[2,3]  R1177     -2.7738561630249023e+00
    phi[2,3]  R1178     -0.759874701499939
    phi[2,3]  R1179     -1.9779274463653564e+00
    phi[2,3]  R1180     -1.1714207381010056e-01
    phi[2,3]  R1181     -1.5422806143760681e-01
    phi[2,3]  R1182     -2.0958421230316162e+00
    phi[2,3]  R1183     -2.01777982711792
    phi[2,3]  R1184     -1.7183429002761841e+00
    phi[2,3]  R1185     -1.5953238010406494e+00
    phi[2,3]  R1186     0.580449104309082
    phi[2,3]  R1187     -6.1701989173889160e-01
    phi[2,3]  R1188     -0.416536808013916
    phi[2,3]  R1189     5.4069352149963379e-01
    phi[2,3]  R1190     -8.5856938362121582e-01
    phi[2,3]  R1191     8.3861315250396729e-01
    phi[2,3]  R1192     -2.3076042532920837e-01
    phi[2,3]  R1193     -2.0889606475830078e+00
    phi[2,3]  R1194     -1.8290075063705444e+00
    phi[2,3]  R1195     -7.4344366788864136e-01
    phi[2,3]  R1196     -7.9874575138092041e-01
    phi[2,3]  R1197     -2.0243305712938309e-02
    phi[2,3]  R1198     -6.0688573122024536e-01
    phi[2,3]  R1199     -3.9562520384788513e-01
    phi[2,3]  R1200     -3.4328062534332275e+00
    phi[2,3]  R1201     1.1214677095413208e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1202     -3.0999999046325684e+00
    phi[3,2]  R1203     -3.0999999046325684e+00
    phi[3,2]  R1204     -2.2400000095367432e+00
    phi[3,2]  R1205     -2.2400000095367432e+00
    phi[3,2]  R1206     -3.0999999046325684e+00
    phi[3,2]  R1207     -3.0999999046325684e+00
    phi[3,2]  R1208     -2.5699999332427979e+00
    phi[3,2]  R1209     -2.5699999332427979e+00
    phi[3,2]  R1210     -3.0999999046325684e+00
    phi[3,2]  R1211     -3.0999999046325684e+00
    phi[3,2]  R1212     -2.0899999141693115e+00
    phi[3,2]  R1213     -2.0899999141693115e+00
    phi[3,2]  R1214     -3.0999999046325684e+00
    phi[3,2]  R1215     -3.0999999046325684e+00
    phi[3,2]  R1216     9.0025734901428223e-01
    phi[3,2]  R1217     1.0605969429016113e+00
    phi[3,2]  R1218     1.8920346498489380e+00
    phi[3,2]  R1219     3.8706502318382263e-01
    phi[3,2]  R1220     2.0736405849456787e+00
    phi[3,2]  R1221     2.3381197452545166e+00
    phi[3,2]  R1222     2.5461647510528564e+00
    phi[3,2]  R1223     2.1254689693450928e+00
    phi[3,2]  R1224     1.6688864231109619e+00
    phi[3,2]  R1225     2.8265070915222168e+00
    phi[3,2]  R1226     -1.8422288894653320e+00
    phi[3,2]  R1227     -1.8020691871643066e+00
    phi[3,2]  R1228     -0.253984659910202
    phi[3,2]  R1229     -9.0316408872604370e-01
    phi[3,2]  R1230     -1.18865168094635
    phi[3,2]  R1231     -7.1086090803146362e-01
    phi[3,2]  R1232     -1.9460805654525757e+00
    phi[3,2]  R1233     -2.5952296257019043e+00
    phi[3,2]  R1234     -1.1347218751907349e+00
    phi[3,2]  R1235     -9.6284967660903931e-01
    phi[3,2]  R1236     1.3753581047058105e+00
    phi[3,2]  R1237     -3.3623225688934326e+00
    phi[3,2]  R1238     -1.4756593108177185e-01
    phi[3,2]  R1239     -3.7570407390594482e+00
    phi[3,2]  R1240     -3.2858762741088867e+00
    phi[3,2]  R1241     -1.0282185077667236e+00
    phi[3,2]  R1242     -8.3390957117080688e-01
    phi[3,2]  R1243     -1.7055542469024658e+00
    phi[3,2]  R1244     1.0807485878467560e-01
    phi[3,2]  R1245     -2.3921124935150146e+00
    phi[3,2]  R1246     -1.8905744552612305e+00
    phi[3,2]  R1247     -1.2648417949676514e+00
    phi[3,2]  R1248     -3.2647356986999512e+00
    phi[3,2]  R1249     -2.5097584724426270e+00
    phi[3,2]  R1250     -1.0411006212234497e+00
    phi[3,2]  R1251     -1.4013190269470215e+00
    phi[3,2]  R1252     -1.4764014482498169e+00
    phi[3,2]  R1253     9.8951049149036407e-02
    phi[3,2]  R1254     -1.4446837902069092e+00
    phi[3,2]  R1255     -7.1867114305496216e-01
    phi[3,2]  R1256     8.2380151748657227e-01
    phi[3,2]  R1257     -7.0742887258529663e-01
    phi[3,2]  R1258     -2.6190855503082275e+00
    phi[3,2]  R1259     -1.3313853740692139e+00
    phi[3,2]  R1260     -2.2638657093048096e+00
    phi[3,2]  R1261     -2.7738561630249023e+00
    phi[3,2]  R1262     -0.759874701499939
    phi[3,2]  R1263     -1.9779274463653564e+00
    phi[3,2]  R1264     -1.1714207381010056e-01
    phi[3,2]  R1265     -1.5422806143760681e-01
    phi[3,2]  R1266     -2.0958421230316162e+00
    phi[3,2]  R1267     -2.01777982711792
    phi[3,2]  R1268     -1.7183429002761841e+00
    phi[3,2]  R1269     -1.5953238010406494e+00
    phi[3,2]  R1270     0.580449104309082
    phi[3,2]  R1271     -6.1701989173889160e-01
    phi[3,2]  R1272     -0.416536808013916
    phi[3,2]  R1273     5.4069352149963379e-01
    phi[3,2]  R1274     -8.5856938362121582e-01
    phi[3,2]  R1275     8.3861315250396729e-01
    phi[3,2]  R1276     -2.3076042532920837e-01
    phi[3,2]  R1277     -2.0889606475830078e+00
    phi[3,2]  R1278     -1.8290075063705444e+00
    phi[3,2]  R1279     -7.4344366788864136e-01
    phi[3,2]  R1280     -7.9874575138092041e-01
    phi[3,2]  R1281     -2.0243305712938309e-02
    phi[3,2]  R1282     -6.0688573122024536e-01
    phi[3,2]  R1283     -3.9562520384788513e-01
    phi[3,2]  R1284     -3.4328062534332275e+00
    phi[3,2]  R1285     1.1214677095413208e+00
    phi[3,2]  R1286     2.1171543598175049e+00
    phi[3,2]  R1287     6.5808349847793579e-01
    phi[3,2]  R1288     -1.2099655866622925e+00
    phi[3,2]  R1289     -3.9904829859733582e-01
    phi[3,2]  R1290     1.2998136281967163e+00
    phi[3,2]  R1291     -2.7281978726387024e-01
    phi[3,2]  R1292     6.2350833415985107e-01
    phi[3,2]  R1293     -0.190694198012352
    phi[3,2]  R1294     2.1254785358905792e-01
    phi[3,2]  R1295     -2.46032452583313
    phi[3,2]  R1296     -2.2105915546417236e+00
    phi[3,2]  R1297     -2.0161082744598389e+00
    phi[3,2]  R1298     -2.4433412551879883e+00
    phi[3,2]  R1299     -8.6483329534530640e-01
    phi[3,2]  R1300     -8.0825787782669067e-01
    phi[3,2]  R1301     1.0437054634094238e+00
    phi[3,2]  R1302     -1.2570858001708984e+00
    phi[3,2]  R1303     -8.0240339040756226e-01
    phi[3,2]  R1304     -1.7341774702072144e+00
    phi[3,2]  R1305     -5.9906393289566040e-01
    phi[3,2]  R1306     -4.3571156263351440e-01
    phi[3,2]  R1307     1.9068117439746857e-01
    phi[3,2]  R1308     6.8291515111923218e-01
    phi[3,2]  R1309     -1.1162043809890747e+00
    phi[3,2]  R1310     -4.4823470711708069e-01
    phi[3,2]  R1311     -2.0030717849731445e+00
    phi[3,2]  R1312     -1.3136255741119385e+00
    phi[3,2]  R1313     -2.1125154495239258e+00
    phi[3,2]  R1314     -6.3643038272857666e-01
    phi[3,2]  R1315     -2.1707201004028320e+00
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1316     -3.0999999046325684e+00
    phi[3,7]  R1317     -3.0999999046325684e+00
    phi[3,7]  R1318     -2.2400000095367432e+00
    phi[3,7]  R1319     -2.2400000095367432e+00
    phi[3,7]  R1320     -3.0999999046325684e+00
    phi[3,7]  R1321     -3.0999999046325684e+00
    phi[3,7]  R1322     -2.5699999332427979e+00
    phi[3,7]  R1323     -2.5699999332427979e+00
    phi[3,7]  R1324     -3.0999999046325684e+00
    phi[3,7]  R1325     -3.0999999046325684e+00
    phi[3,7]  R1326     -2.0899999141693115e+00
    phi[3,7]  R1327     -2.0899999141693115e+00
    phi[3,7]  R1328     -3.0999999046325684e+00
    phi[3,7]  R1329     -3.0999999046325684e+00
    phi[3,7]  R1330     9.0025734901428223e-01
    phi[3,7]  R1331     1.0605969429016113e+00
    phi[3,7]  R1332     1.8920346498489380e+00
    phi[3,7]  R1333     3.8706502318382263e-01
    phi[3,7]  R1334     2.0736405849456787e+00
    phi[3,7]  R1335     2.3381197452545166e+00
    phi[3,7]  R1336     2.5461647510528564e+00
    phi[3,7]  R1337     2.1254689693450928e+00
    phi[3,7]  R1338     1.6688864231109619e+00
    phi[3,7]  R1339     2.8265070915222168e+00
    phi[3,7]  R1340     -1.8422288894653320e+00
    phi[3,7]  R1341     -1.8020691871643066e+00
    phi[3,7]  R1342     -0.253984659910202
    phi[3,7]  R1343     -9.0316408872604370e-01
    phi[3,7]  R1344     -1.18865168094635
    phi[3,7]  R1345     -7.1086090803146362e-01
    phi[3,7]  R1346     -1.9460805654525757e+00
    phi[3,7]  R1347     -2.5952296257019043e+00
    phi[3,7]  R1348     -1.1347218751907349e+00
    phi[3,7]  R1349     -9.6284967660903931e-01
    phi[3,7]  R1350     1.3753581047058105e+00
    phi[3,7]  R1351     -3.3623225688934326e+00
    phi[3,7]  R1352     -1.4756593108177185e-01
    phi[3,7]  R1353     -3.7570407390594482e+00
    phi[3,7]  R1354     -3.2858762741088867e+00
    phi[3,7]  R1355     -1.0282185077667236e+00
    phi[3,7]  R1356     -8.3390957117080688e-01
    phi[3,7]  R1357     -1.7055542469024658e+00
    phi[3,7]  R1358     1.0807485878467560e-01
    phi[3,7]  R1359     -2.3921124935150146e+00
    phi[3,7]  R1360     -1.8905744552612305e+00
    phi[3,7]  R1361     -1.2648417949676514e+00
    phi[3,7]  R1362     -3.2647356986999512e+00
    phi[3,7]  R1363     -2.5097584724426270e+00
    phi[3,7]  R1364     -1.0411006212234497e+00
    phi[3,7]  R1365     -1.4013190269470215e+00
    phi[3,7]  R1366     -1.4764014482498169e+00
    phi[3,7]  R1367     9.8951049149036407e-02
    phi[3,7]  R1368     -1.4446837902069092e+00
    phi[3,7]  R1369     -7.1867114305496216e-01
    phi[3,7]  R1370     8.2380151748657227e-01
    phi[3,7]  R1371     -7.0742887258529663e-01
    phi[3,7]  R1372     -2.6190855503082275e+00
    phi[3,7]  R1373     -1.3313853740692139e+00
    phi[3,7]  R1374     -2.2638657093048096e+00
    phi[3,7]  R1375     -2.7738561630249023e+00
    phi[3,7]  R1376     -0.759874701499939
    phi[3,7]  R1377     -1.9779274463653564e+00
    phi[3,7]  R1378     -1.1714207381010056e-01
    phi[3,7]  R1379     -1.5422806143760681e-01
    phi[3,7]  R1380     -2.0958421230316162e+00
    phi[3,7]  R1381     -2.01777982711792
    phi[3,7]  R1382     -1.7183429002761841e+00
    phi[3,7]  R1383     -1.5953238010406494e+00
    phi[3,7]  R1384     0.580449104309082
    phi[3,7]  R1385     -6.1701989173889160e-01
    phi[3,7]  R1386     -0.416536808013916
    phi[3,7]  R1387     5.4069352149963379e-01
    phi[3,7]  R1388     -8.5856938362121582e-01
    phi[3,7]  R1389     8.3861315250396729e-01
    phi[3,7]  R1390     -2.3076042532920837e-01
    phi[3,7]  R1391     -2.0889606475830078e+00
    phi[3,7]  R1392     -1.8290075063705444e+00
    phi[3,7]  R1393     -7.4344366788864136e-01
    phi[3,7]  R1394     -7.9874575138092041e-01
    phi[3,7]  R1395     -2.0243305712938309e-02
    phi[3,7]  R1396     -6.0688573122024536e-01
    phi[3,7]  R1397     -3.9562520384788513e-01
    phi[3,7]  R1398     -3.4328062534332275e+00
    phi[3,7]  R1399     1.1214677095413208e+00
    phi[3,7]  R1400     1.5157955884933472e+00
    phi[3,7]  R1401     1.4524074792861938e+00
    phi[3,7]  R1402     1.9572380781173706e+00
    phi[3,7]  R1403     7.0032197237014771e-01
    phi[3,7]  R1404     3.6809897422790527e-01
    phi[3,7]  R1405     1.8319376707077026e+00
    phi[3,7]  R1406     1.1818906068801880e+00
    phi[3,7]  R1407     0.0642305240035057
    phi[3,7]  R1408     -1.2609101533889771e+00
    phi[3,7]  R1409     2.9697136878967285e+00
    phi[3,7]  R1410     2.2100695967674255e-01
    phi[3,7]  R1411     -1.5630285739898682e+00
    phi[3,7]  R1412     -5.5848407745361328e-01
    phi[3,7]  R1413     3.8759194314479828e-02
    phi[3,7]  R1414     -1.9457818269729614e+00
    phi[3,7]  R1415     1.9051110744476318e-01
    phi[3,7]  R1416     -1.0537143945693970e+00
    phi[3,7]  R1417     -8.2304340600967407e-01
    phi[3,7]  R1418     -1.1463737487792969e+00
    phi[3,7]  R1419     -1.0232319831848145e+00
    phi[3,7]  R1420     2.0703089237213135e+00
    phi[3,7]  R1421     -1.0858736038208008e+00
    phi[3,7]  R1422     -9.0961617231369019e-01
    phi[3,7]  R1423     -6.7851436138153076e-01
    phi[3,7]  R1424     -1.7182477712631226e+00
    phi[3,7]  R1425     -1.4546529054641724e+00
    phi[3,7]  R1426     -1.2674812078475952e+00
    phi[3,7]  R1427     9.9343806505203247e-01
    phi[3,7]  R1428     -3.0663328170776367e+00
    phi[3,7]  R1429     -8.6945533752441406e-01
    phi[3,7]  R1430     -1.2644258737564087e+00
    phi[3,7]  R1431     -8.7993699312210083e-01
    phi[3,7]  R1432     3.1222975254058838e-01
    phi[3,7]  R1433     -2.2932727336883545e+00
    phi[3,7]  R1434     1.7466973066329956e+00
    phi[3,7]  R1435     -1.1367386579513550e+00
    phi[3,7]  R1436     3.8913464546203613e-01
    phi[3,7]  R1437     -4.3696403503417969e-01
    phi[3,7]  R1438     1.6298514604568481e+00
    phi[3,7]  R1439     1.9558619260787964e+00
    phi[3,7]  R1440     7.2932803630828857e-01
    phi[3,7]  R1441     1.5361700057983398e+00
    phi[3,7]  R1442     -4.6852782368659973e-02
    phi[3,7]  R1443     -5.5777156352996826e-01
    phi[3,7]  R1444     5.6770741939544678e-02
    phi[3,7]  R1445     -5.3308892250061035e-01
    phi[3,7]  R1446     1.3279511928558350e+00
    phi[3,7]  R1447     -1.7660877704620361e+00
    phi[3,7]  R1448     -1.2284924983978271e+00
    phi[3,7]  R1449     -1.8811229467391968e+00
    phi[3,7]  R1450     -1.9472305774688721e+00
    phi[3,7]  R1451     -2.1569206714630127e+00
    phi[3,7]  R1452     -1.0387932062149048e+00
    phi[3,7]  R1453     -1.4165586233139038e+00
    phi[3,7]  R1454     -4.8767790198326111e-01
    phi[3,7]  R1455     -2.2541556358337402e+00
    phi[3,7]  R1456     -1.6244801282882690e+00
    phi[3,7]  R1457     -1.0569058656692505e+00
    phi[3,7]  R1458     -5.2110075950622559e-01
    phi[3,7]  R1459     -9.8713082075119019e-01
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1460     -3.0999999046325684e+00
    phi[7,3]  R1461     -3.0999999046325684e+00
    phi[7,3]  R1462     -2.2400000095367432e+00
    phi[7,3]  R1463     -2.2400000095367432e+00
    phi[7,3]  R1464     -3.0999999046325684e+00
    phi[7,3]  R1465     -3.0999999046325684e+00
    phi[7,3]  R1466     -2.5699999332427979e+00
    phi[7,3]  R1467     -2.5699999332427979e+00
    phi[7,3]  R1468     -3.0999999046325684e+00
    phi[7,3]  R1469     -3.0999999046325684e+00
    phi[7,3]  R1470     -2.0899999141693115e+00
    phi[7,3]  R1471     -2.0899999141693115e+00
    phi[7,3]  R1472     -3.0999999046325684e+00
    phi[7,3]  R1473     -3.0999999046325684e+00
    phi[7,3]  R1474     1.5157955884933472e+00
    phi[7,3]  R1475     1.4524074792861938e+00
    phi[7,3]  R1476     1.9572380781173706e+00
    phi[7,3]  R1477     7.0032197237014771e-01
    phi[7,3]  R1478     3.6809897422790527e-01
    phi[7,3]  R1479     1.8319376707077026e+00
    phi[7,3]  R1480     1.1818906068801880e+00
    phi[7,3]  R1481     0.0642305240035057
    phi[7,3]  R1482     -1.2609101533889771e+00
    phi[7,3]  R1483     2.9697136878967285e+00
    phi[7,3]  R1484     2.2100695967674255e-01
    phi[7,3]  R1485     -1.5630285739898682e+00
    phi[7,3]  R1486     -5.5848407745361328e-01
    phi[7,3]  R1487     3.8759194314479828e-02
    phi[7,3]  R1488     -1.9457818269729614e+00
    phi[7,3]  R1489     1.9051110744476318e-01
    phi[7,3]  R1490     -1.0537143945693970e+00
    phi[7,3]  R1491     -8.2304340600967407e-01
    phi[7,3]  R1492     -1.1463737487792969e+00
    phi[7,3]  R1493     -1.0232319831848145e+00
    phi[7,3]  R1494     2.0703089237213135e+00
    phi[7,3]  R1495     -1.0858736038208008e+00
    phi[7,3]  R1496     -9.0961617231369019e-01
    phi[7,3]  R1497     -6.7851436138153076e-01
    phi[7,3]  R1498     -1.7182477712631226e+00
    phi[7,3]  R1499     -1.4546529054641724e+00
    phi[7,3]  R1500     -1.2674812078475952e+00
    phi[7,3]  R1501     9.9343806505203247e-01
    phi[7,3]  R1502     -3.0663328170776367e+00
    phi[7,3]  R1503     -8.6945533752441406e-01
    phi[7,3]  R1504     -1.2644258737564087e+00
    phi[7,3]  R1505     -8.7993699312210083e-01
    phi[7,3]  R1506     3.1222975254058838e-01
    phi[7,3]  R1507     -2.2932727336883545e+00
    phi[7,3]  R1508     1.7466973066329956e+00
    phi[7,3]  R1509     -1.1367386579513550e+00
    phi[7,3]  R1510     3.8913464546203613e-01
    phi[7,3]  R1511     -4.3696403503417969e-01
    phi[7,3]  R1512     1.6298514604568481e+00
    phi[7,3]  R1513     1.9558619260787964e+00
    phi[7,3]  R1514     7.2932803630828857e-01
    phi[7,3]  R1515     1.5361700057983398e+00
    phi[7,3]  R1516     -4.6852782368659973e-02
    phi[7,3]  R1517     -5.5777156352996826e-01
    phi[7,3]  R1518     5.6770741939544678e-02
    phi[7,3]  R1519     -5.3308892250061035e-01
    phi[7,3]  R1520     1.3279511928558350e+00
    phi[7,3]  R1521     -1.7660877704620361e+00
    phi[7,3]  R1522     -1.2284924983978271e+00
    phi[7,3]  R1523     -1.8811229467391968e+00
    phi[7,3]  R1524     -1.9472305774688721e+00
    phi[7,3]  R1525     -2.1569206714630127e+00
    phi[7,3]  R1526     -1.0387932062149048e+00
    phi[7,3]  R1527     -1.4165586233139038e+00
    phi[7,3]  R1528     -4.8767790198326111e-01
    phi[7,3]  R1529     -2.2541556358337402e+00
    phi[7,3]  R1530     -1.6244801282882690e+00
    phi[7,3]  R1531     -1.0569058656692505e+00
    phi[7,3]  R1532     -5.2110075950622559e-01
    phi[7,3]  R1533     -9.8713082075119019e-01
    phi[7,3]  R1534     9.0025734901428223e-01
    phi[7,3]  R1535     1.0605969429016113e+00
    phi[7,3]  R1536     1.8920346498489380e+00
    phi[7,3]  R1537     3.8706502318382263e-01
    phi[7,3]  R1538     2.0736405849456787e+00
    phi[7,3]  R1539     2.3381197452545166e+00
    phi[7,3]  R1540     2.5461647510528564e+00
    phi[7,3]  R1541     2.1254689693450928e+00
    phi[7,3]  R1542     1.6688864231109619e+00
    phi[7,3]  R1543     2.8265070915222168e+00
    phi[7,3]  R1544     -1.8422288894653320e+00
    phi[7,3]  R1545     -1.8020691871643066e+00
    phi[7,3]  R1546     -0.253984659910202
    phi[7,3]  R1547     -9.0316408872604370e-01
    phi[7,3]  R1548     -1.18865168094635
    phi[7,3]  R1549     -7.1086090803146362e-01
    phi[7,3]  R1550     -1.9460805654525757e+00
    phi[7,3]  R1551     -2.5952296257019043e+00
    phi[7,3]  R1552     -1.1347218751907349e+00
    phi[7,3]  R1553     -9.6284967660903931e-01
    phi[7,3]  R1554     1.3753581047058105e+00
    phi[7,3]  R1555     -3.3623225688934326e+00
    phi[7,3]  R1556     -1.4756593108177185e-01
    phi[7,3]  R1557     -3.7570407390594482e+00
    phi[7,3]  R1558     -3.2858762741088867e+00
    phi[7,3]  R1559     -1.0282185077667236e+00
    phi[7,3]  R1560     -8.3390957117080688e-01
    phi[7,3]  R1561     -1.7055542469024658e+00
    phi[7,3]  R1562     1.0807485878467560e-01
    phi[7,3]  R1563     -2.3921124935150146e+00
    phi[7,3]  R1564     -1.8905744552612305e+00
    phi[7,3]  R1565     -1.2648417949676514e+00
    phi[7,3]  R1566     -3.2647356986999512e+00
    phi[7,3]  R1567     -2.5097584724426270e+00
    phi[7,3]  R1568     -1.0411006212234497e+00
    phi[7,3]  R1569     -1.4013190269470215e+00
    phi[7,3]  R1570     -1.4764014482498169e+00
    phi[7,3]  R1571     9.8951049149036407e-02
    phi[7,3]  R1572     -1.4446837902069092e+00
    phi[7,3]  R1573     -7.1867114305496216e-01
    phi[7,3]  R1574     8.2380151748657227e-01
    phi[7,3]  R1575     -7.0742887258529663e-01
    phi[7,3]  R1576     -2.6190855503082275e+00
    phi[7,3]  R1577     -1.3313853740692139e+00
    phi[7,3]  R1578     -2.2638657093048096e+00
    phi[7,3]  R1579     -2.7738561630249023e+00
    phi[7,3]  R1580     -0.759874701499939
    phi[7,3]  R1581     -1.9779274463653564e+00
    phi[7,3]  R1582     -1.1714207381010056e-01
    phi[7,3]  R1583     -1.5422806143760681e-01
    phi[7,3]  R1584     -2.0958421230316162e+00
    phi[7,3]  R1585     -2.01777982711792
    phi[7,3]  R1586     -1.7183429002761841e+00
    phi[7,3]  R1587     -1.5953238010406494e+00
    phi[7,3]  R1588     0.580449104309082
    phi[7,3]  R1589     -6.1701989173889160e-01
    phi[7,3]  R1590     -0.416536808013916
    phi[7,3]  R1591     5.4069352149963379e-01
    phi[7,3]  R1592     -8.5856938362121582e-01
    phi[7,3]  R1593     8.3861315250396729e-01
    phi[7,3]  R1594     -2.3076042532920837e-01
    phi[7,3]  R1595     -2.0889606475830078e+00
    phi[7,3]  R1596     -1.8290075063705444e+00
    phi[7,3]  R1597     -7.4344366788864136e-01
    phi[7,3]  R1598     -7.9874575138092041e-01
    phi[7,3]  R1599     -2.0243305712938309e-02
    phi[7,3]  R1600     -6.0688573122024536e-01
    phi[7,3]  R1601     -3.9562520384788513e-01
    phi[7,3]  R1602     -3.4328062534332275e+00
    phi[7,3]  R1603     1.1214677095413208e+00
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R29       -8.4712564880147179e-01
    phi[3,9]  R30       -1.4068509057788878e+00
    phi[3,9]  R31       1.1598911621112240e-01
    phi[3,9]  R32       -3.3840290506970705e-01
    phi[3,9]  R33       -2.7303100849715150e+00
    phi[3,9]  R34       -3.8858765544074547e-01
    phi[3,9]  R35       -2.1393204627349696e+00
    phi[3,9]  R73       -1
    phi[3,9]  R1604     -3.94712555343404
    phi[3,9]  R1605     -2.2528742558310966e+00
    phi[3,9]  R1606     -3.6468509153156310e+00
    phi[3,9]  R1607     -8.3314910375785534e-01
    phi[3,9]  R1608     -2.9840107884214460e+00
    phi[3,9]  R1609     -3.2159890208436908e+00
    phi[3,9]  R1610     -2.9084028383125049e+00
    phi[3,9]  R1611     -2.2315970281730908e+00
    phi[3,9]  R1612     -5.8303099896040838e+00
    phi[3,9]  R1613     -3.6968981966105341e-01
    phi[3,9]  R1614     -2.4785875696100570e+00
    phi[3,9]  R1615     -1.7014122587285661e+00
    phi[3,9]  R1616     -5.2393203673675384e+00
    phi[3,9]  R1617     -9.6067944189759880e-01
    phi[3,9]  R1618     -2.7247533340753649e-01
    phi[3,9]  R1619     -2.7732566212287568e-01
    phi[3,9]  R1620     -2.8928700273797814e-01
    phi[3,9]  R1621     -2.9562104246686771e-01
    phi[3,9]  R1622     -3.1452209023172539e-01
    phi[3,9]  R1623     -3.2402287938484253e-01
    phi[3,9]  R1624     -3.2588879054290576e-01
    phi[3,9]  R1625     -3.2596604478415436e-01
    phi[3,9]  R1626     -3.2671124181260813e-01
    phi[3,9]  R1627     -3.2917860916422637e-01
    phi[3,9]  R1628     -2.8304858126400223e-01
    phi[3,9]  R1629     -2.8795404698638594e-01
    phi[3,9]  R1630     -2.9091253333484468e-01
    phi[3,9]  R1631     -2.9466243197890418e-01
    phi[3,9]  R1632     -3.0071147023834821e-01
    phi[3,9]  R1633     -3.0103220889943683e-01
    phi[3,9]  R1634     -3.0385345871882019e-01
    phi[3,9]  R1635     -3.0415357821054689e-01
    phi[3,9]  R1636     -3.0498904027339979e-01
    phi[3,9]  R1637     -3.1636872609994859e-01
    phi[3,9]  R1638     -2.6052825595043494e-01
    phi[3,9]  R1639     -0.911675044666806
    phi[3,9]  R1640     -6.6784688138448733e-01
    phi[3,9]  R1641     -1.0712618348596008e+00
    phi[3,9]  R1642     -1.2870079490765354e+00
    phi[3,9]  R1643     -5.5833817105810524e-01
    phi[3,9]  R1644     -1.0439057477260183e+00
    phi[3,9]  R1645     -1.5452038176231855e+00
    phi[3,9]  R1646     -3.6217385395853391e-01
    phi[3,9]  R1647     -1.4056394003464390e+00
    phi[3,9]  R1648     -4.2622210479167477e-01
    phi[3,9]  R1649     -2.9318418131756219e-01
    phi[3,9]  R1650     -5.7417330055671112e-01
    phi[3,9]  R1651     -3.3538624020635366e-01
    phi[3,9]  R1652     -0.338145721634011
    phi[3,9]  R1653     -1.5033418298270234e+00
    phi[3,9]  R1654     -3.5090270599384166e-01
    phi[3,9]  R1655     -3.5106530454579332e-01
    phi[3,9]  R1656     -0.374439508437161
    phi[3,9]  R1657     -6.5471514074863413e-01
    phi[3,9]  R1658     -2.8207971570896762e-01
    phi[3,9]  R1659     -1.3009769509984004e+00
    phi[3,9]  R1660     -1.0376765894883422e+00
    phi[3,9]  R1661     -3.2727943696391870e-01
    phi[3,9]  R1662     -1.0504162325946773e+00
    phi[3,9]  R1663     -3.3379563362449982e-01
    phi[3,9]  R1664     -3.3759853132300455e-01
    phi[3,9]  R1665     -3.4119153322081552e-01
    phi[3,9]  R1666     -3.4231680817357096e-01
    phi[3,9]  R1667     -3.4981588461123581e-01
    phi[3,9]  R1668     -0.62432128558615
    phi[3,9]  R1669     -1.4433873007065205e+00
    phi[3,9]  R1670     -1.0692472504959178e+00
    phi[3,9]  R1671     -1.1073639813400746e+00
    phi[3,9]  R1672     -9.7498930123019578e-01
    phi[3,9]  R1673     -1.2821166376895861e+00
    phi[3,9]  R1674     -3.5850982607731452e-01
    phi[3,9]  R1675     -3.7342617650945586e-01
    phi[3,9]  R1676     -1.0035875783414463e+00
    phi[3,9]  R1677     -3.7648000633509349e-01
    phi[3,9]  R1678     -2.7376201207037776e-01
    phi[3,9]  R1679     -9.6937528414402752e-01
    phi[3,9]  R1680     -1.3075112966895277e+00
    phi[3,9]  R1681     -1.1455905369749986e+00
    phi[3,9]  R1682     -0.348598618965188
    phi[3,9]  R1683     -3.1472147626225866e-01
    phi[3,9]  R1684     -3.1602635501373250e-01
    phi[3,9]  R1685     -6.8695534918698886e-01
    phi[3,9]  R1686     -3.3388468719229714e-01
    phi[3,9]  R1687     -3.3797080320757722e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1688     -3.0999999046325684e+00
    phi[4,5]  R1689     -3.0999999046325684e+00
    phi[4,5]  R1690     -2.2400000095367432e+00
    phi[4,5]  R1691     -2.2400000095367432e+00
    phi[4,5]  R1692     -3.0999999046325684e+00
    phi[4,5]  R1693     -3.0999999046325684e+00
    phi[4,5]  R1694     -2.5699999332427979e+00
    phi[4,5]  R1695     -2.5699999332427979e+00
    phi[4,5]  R1696     -3.0999999046325684e+00
    phi[4,5]  R1697     -3.0999999046325684e+00
    phi[4,5]  R1698     -2.0899999141693115e+00
    phi[4,5]  R1699     -2.0899999141693115e+00
    phi[4,5]  R1700     -3.0999999046325684e+00
    phi[4,5]  R1701     -3.0999999046325684e+00
    phi[4,5]  R1702     1.2876926660537720e+00
    phi[4,5]  R1703     1.7858449220657349e+00
    phi[4,5]  R1704     1.2794536352157593e+00
    phi[4,5]  R1705     6.0153192281723022e-01
    phi[4,5]  R1706     2.2252583503723145e+00
    phi[4,5]  R1707     0.828194260597229
    phi[4,5]  R1708     9.5010602474212646e-01
    phi[4,5]  R1709     2.1598362922668457e+00
    phi[4,5]  R1710     1.2177836894989014e+00
    phi[4,5]  R1711     6.2312108278274536e-01
    phi[4,5]  R1712     -9.5100885629653931e-01
    phi[4,5]  R1713     -3.3563313484191895e+00
    phi[4,5]  R1714     -2.0805172920227051e+00
    phi[4,5]  R1715     -3.2488257884979248e+00
    phi[4,5]  R1716     -4.0639810562133789e+00
    phi[4,5]  R1717     -3.6794190406799316e+00
    phi[4,5]  R1718     -1.6260633468627930e+00
    phi[4,5]  R1719     -2.5315217971801758e+00
    phi[4,5]  R1720     -2.3085432052612305e+00
    phi[4,5]  R1721     -2.4476613998413086e+00
    phi[4,5]  R1722     -2.5149133205413818e+00
    phi[4,5]  R1723     -9.9706232547760010e-01
    phi[4,5]  R1724     -7.7825969457626343e-01
    phi[4,5]  R1725     -2.2911386489868164e+00
    phi[4,5]  R1726     1.3851609826087952e-01
    phi[4,5]  R1727     -4.2769312858581543e-04
    phi[4,5]  R1728     -3.7595915794372559e-01
    phi[4,5]  R1729     -2.6977107524871826e+00
    phi[4,5]  R1730     -2.2754948139190674e+00
    phi[4,5]  R1731     -5.6862151622772217e-01
    phi[4,5]  R1732     -1.4224802255630493e+00
    phi[4,5]  R1733     -0.834635317325592
    phi[4,5]  R1734     -1.4658658504486084e+00
    phi[4,5]  R1735     -1.4826879501342773e+00
    phi[4,5]  R1736     1.2372667789459229e+00
    phi[4,5]  R1737     -6.8143361806869507e-01
    phi[4,5]  R1738     -2.8161978721618652e-01
    phi[4,5]  R1739     -8.2134252786636353e-01
    phi[4,5]  R1740     -1.9720678329467773e+00
    phi[4,5]  R1741     -2.2614393234252930e+00
    phi[4,5]  R1742     -9.2362242937088013e-01
    phi[4,5]  R1743     -9.3353599309921265e-01
    phi[4,5]  R1744     -2.8592083454132080e+00
    phi[4,5]  R1745     9.9744945764541626e-01
    phi[4,5]  R1746     -9.3784385919570923e-01
    phi[4,5]  R1747     -1.8985871970653534e-01
    phi[4,5]  R1748     -0.11457559466362
    phi[4,5]  R1749     -0.611226499080658
    phi[4,5]  R1750     -8.4949588775634766e-01
    phi[4,5]  R1751     -2.0525836944580078e+00
    phi[4,5]  R1752     -4.8115390539169312e-01
    phi[4,5]  R1753     1.3090106844902039e-01
    phi[4,5]  R1754     0.150233194231987
    phi[4,5]  R1755     -2.5207295417785645e+00
    phi[4,5]  R1756     -3.3459177017211914e+00
    phi[4,5]  R1757     -1.4203413724899292e+00
    phi[4,5]  R1758     -0.198886901140213
    phi[4,5]  R1759     -1.3393635749816895e+00
    phi[4,5]  R1760     -2.7078204154968262e+00
    phi[4,5]  R1761     -1.3536406755447388e+00
    phi[4,5]  R1762     9.2417567968368530e-01
    phi[4,5]  R1763     -2.5498208999633789e+00
    phi[4,5]  R1764     8.7446987628936768e-01
    phi[4,5]  R1765     1.5119456052780151e+00
    phi[4,5]  R1766     -1.8385847806930542e+00
    phi[4,5]  R1767     -2.2482223510742188e+00
    phi[4,5]  R1768     -1.2958370447158813e+00
    phi[4,5]  R1769     -8.0106329917907715e-01
    phi[4,5]  R1770     9.7039178013801575e-02
    phi[4,5]  R1771     -2.2740507125854492e+00
    phi[4,5]  R1772     -4.6221889555454254e-02
    phi[4,5]  R1773     5.8612763881683350e-01
    phi[4,5]  R1774     1.8060906231403351e-01
    phi[4,5]  R1775     7.2762691974639893e-01
    phi[4,5]  R1776     -9.6866947412490845e-01
    phi[4,5]  R1777     3.7237685173749924e-03
    phi[4,5]  R1778     -3.8075485825538635e-01
    phi[4,5]  R1779     2.3247180879116058e-01
    phi[4,5]  R1780     8.5076552629470825e-01
    phi[4,5]  R1781     -1.2772547006607056e+00
    phi[4,5]  R1782     3.5862150788307190e-01
    phi[4,5]  R1783     -8.8397532701492310e-02
    phi[4,5]  R1784     -2.3632271289825439e+00
    phi[4,5]  R1785     -1.6439291238784790e+00
    phi[4,5]  R1786     -5.5766832828521729e-01
    phi[4,5]  R1787     4.1910272836685181e-01
    phi[4,5]  R1788     0.538382351398468
    phi[4,5]  R1789     4.2780020833015442e-01
    phi[4,5]  R1790     9.2371094226837158e-01
    phi[4,5]  R1791     -4.9513936042785645e-01
    phi[4,5]  R1792     -3.7828025817871094e+00
    phi[4,5]  R1793     -1.0869710445404053e+00
    phi[4,5]  R1794     -2.1998443603515625e+00
    phi[4,5]  R1795     -2.2529246807098389e+00
    phi[4,5]  R1796     -3.3244824409484863e+00
    phi[4,5]  R1797     -1.7207760810852051e+00
    phi[4,5]  R1798     -1.2366402149200439e+00
    phi[4,5]  R1799     -2.2820990085601807e+00
    phi[4,5]  R1800     -9.0117925405502319e-01
    phi[4,5]  R1801     1.01506769657135
    phi[4,5]  R1802     -1.0205707550048828e+00
    phi[4,5]  R1803     -2.5271527767181396e+00
    phi[4,5]  R1804     -3.2483839988708496e+00
    phi[4,5]  R1805     -1.7225369215011597e+00
    phi[4,5]  R1806     -2.0456347465515137e+00
    phi[4,5]  R1807     1.3176333904266357e-01
    phi[4,5]  R1808     -1.4420702457427979e+00
    phi[4,5]  R1809     -1.2058852910995483e+00
    phi[4,5]  R1810     -1.6367682218551636e+00
    phi[4,5]  R1811     -9.8614972829818726e-01
    phi[4,5]  R1812     -2.0370001792907715e+00
    phi[4,5]  R1813     -1.0286095142364502e+00
    phi[4,5]  R1814     -0.334529846906662
    phi[4,5]  R1815     -1.6693704128265381e+00
    phi[4,5]  R1816     -2.0915732383728027e+00
    phi[4,5]  R1817     -1.4981856346130371e+00
    phi[4,5]  R1818     -3.2042825222015381e-01
    phi[4,5]  R1819     -1.4067845046520233e-01
    phi[4,5]  R1820     6.2854802608489990e-01
    phi[4,5]  R1821     4.0614315867424011e-01
    phi[4,5]  R1822     -1.4917596578598022e+00
    phi[4,5]  R1823     -1.2277196645736694e+00
    phi[4,5]  R1824     -0.97231525182724
    phi[4,5]  R1825     -5.2728354930877686e-01
    phi[4,5]  R1826     -6.3815675675868988e-02
    phi[4,5]  R1827     2.1822267770767212e-01
    phi[4,5]  R1828     0.81246018409729
    phi[4,5]  R1829     -1.0950099229812622e+00
    phi[4,5]  R1830     9.7735381126403809e-01
    phi[4,5]  R1831     -1.2340433597564697e+00
    phi[4,5]  R1832     -1.3304902315139771e+00
    phi[4,5]  R1833     -1.6969020366668701e+00
    phi[4,5]  R1834     -0.729495108127594
    phi[4,5]  R1835     3.6927068233489990e-01
    phi[4,5]  R1836     -1.3265398740768433e+00
    phi[4,5]  R1837     5.9096527099609375e-01
    phi[4,5]  R1838     4.0344056487083435e-01
    phi[4,5]  R1839     -1.0654102563858032e+00
    phi[4,5]  R1840     -9.7947669029235840e-01
    phi[4,5]  R1841     -7.9193478822708130e-01
    phi[4,5]  R1842     -1.4723758697509766e+00
    phi[4,5]  R1843     -1.9478726387023926e+00
    phi[4,5]  R1844     -3.0355346202850342e+00
    phi[4,5]  R1845     -1.4996035397052765e-01
    phi[4,5]  R1846     -1.5929557085037231e+00
    phi[4,5]  R1847     -4.45606803894043
    phi[4,5]  R1848     3.6826890707015991e-01
    phi[4,5]  R1849     -5.6327456235885620e-01
    phi[4,5]  R1850     2.0189964771270752e-01
    phi[4,5]  R1851     -1.1730509996414185e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R1852     -3.0999999046325684e+00
    phi[5,4]  R1853     -3.0999999046325684e+00
    phi[5,4]  R1854     -2.2400000095367432e+00
    phi[5,4]  R1855     -2.2400000095367432e+00
    phi[5,4]  R1856     -3.0999999046325684e+00
    phi[5,4]  R1857     -3.0999999046325684e+00
    phi[5,4]  R1858     -2.5699999332427979e+00
    phi[5,4]  R1859     -2.5699999332427979e+00
    phi[5,4]  R1860     -3.0999999046325684e+00
    phi[5,4]  R1861     -3.0999999046325684e+00
    phi[5,4]  R1862     -2.0899999141693115e+00
    phi[5,4]  R1863     -2.0899999141693115e+00
    phi[5,4]  R1864     -3.0999999046325684e+00
    phi[5,4]  R1865     -3.0999999046325684e+00
    phi[5,4]  R1866     3.5862150788307190e-01
    phi[5,4]  R1867     -8.8397532701492310e-02
    phi[5,4]  R1868     -2.3632271289825439e+00
    phi[5,4]  R1869     -1.6439291238784790e+00
    phi[5,4]  R1870     -5.5766832828521729e-01
    phi[5,4]  R1871     4.1910272836685181e-01
    phi[5,4]  R1872     0.538382351398468
    phi[5,4]  R1873     4.2780020833015442e-01
    phi[5,4]  R1874     9.2371094226837158e-01
    phi[5,4]  R1875     -4.9513936042785645e-01
    phi[5,4]  R1876     -3.7828025817871094e+00
    phi[5,4]  R1877     -1.0869710445404053e+00
    phi[5,4]  R1878     -2.1998443603515625e+00
    phi[5,4]  R1879     -2.2529246807098389e+00
    phi[5,4]  R1880     -3.3244824409484863e+00
    phi[5,4]  R1881     -1.7207760810852051e+00
    phi[5,4]  R1882     -1.2366402149200439e+00
    phi[5,4]  R1883     -2.2820990085601807e+00
    phi[5,4]  R1884     -9.0117925405502319e-01
    phi[5,4]  R1885     1.01506769657135
    phi[5,4]  R1886     -1.0205707550048828e+00
    phi[5,4]  R1887     -2.5271527767181396e+00
    phi[5,4]  R1888     -3.2483839988708496e+00
    phi[5,4]  R1889     -1.7225369215011597e+00
    phi[5,4]  R1890     -2.0456347465515137e+00
    phi[5,4]  R1891     1.3176333904266357e-01
    phi[5,4]  R1892     -1.4420702457427979e+00
    phi[5,4]  R1893     -1.2058852910995483e+00
    phi[5,4]  R1894     -1.6367682218551636e+00
    phi[5,4]  R1895     -9.8614972829818726e-01
    phi[5,4]  R1896     -2.0370001792907715e+00
    phi[5,4]  R1897     -1.0286095142364502e+00
    phi[5,4]  R1898     -0.334529846906662
    phi[5,4]  R1899     -1.6693704128265381e+00
    phi[5,4]  R1900     -2.0915732383728027e+00
    phi[5,4]  R1901     -1.4981856346130371e+00
    phi[5,4]  R1902     -3.2042825222015381e-01
    phi[5,4]  R1903     -1.4067845046520233e-01
    phi[5,4]  R1904     6.2854802608489990e-01
    phi[5,4]  R1905     4.0614315867424011e-01
    phi[5,4]  R1906     -1.4917596578598022e+00
    phi[5,4]  R1907     -1.2277196645736694e+00
    phi[5,4]  R1908     -0.97231525182724
    phi[5,4]  R1909     -5.2728354930877686e-01
    phi[5,4]  R1910     -6.3815675675868988e-02
    phi[5,4]  R1911     2.1822267770767212e-01
    phi[5,4]  R1912     0.81246018409729
    phi[5,4]  R1913     -1.0950099229812622e+00
    phi[5,4]  R1914     9.7735381126403809e-01
    phi[5,4]  R1915     -1.2340433597564697e+00
    phi[5,4]  R1916     -1.3304902315139771e+00
    phi[5,4]  R1917     -1.6969020366668701e+00
    phi[5,4]  R1918     -0.729495108127594
    phi[5,4]  R1919     3.6927068233489990e-01
    phi[5,4]  R1920     -1.3265398740768433e+00
    phi[5,4]  R1921     5.9096527099609375e-01
    phi[5,4]  R1922     4.0344056487083435e-01
    phi[5,4]  R1923     -1.0654102563858032e+00
    phi[5,4]  R1924     -9.7947669029235840e-01
    phi[5,4]  R1925     -7.9193478822708130e-01
    phi[5,4]  R1926     -1.4723758697509766e+00
    phi[5,4]  R1927     -1.9478726387023926e+00
    phi[5,4]  R1928     -3.0355346202850342e+00
    phi[5,4]  R1929     -1.4996035397052765e-01
    phi[5,4]  R1930     -1.5929557085037231e+00
    phi[5,4]  R1931     -4.45606803894043
    phi[5,4]  R1932     3.6826890707015991e-01
    phi[5,4]  R1933     -5.6327456235885620e-01
    phi[5,4]  R1934     2.0189964771270752e-01
    phi[5,4]  R1935     -1.1730509996414185e+00
    phi[5,4]  R1936     1.2876926660537720e+00
    phi[5,4]  R1937     1.7858449220657349e+00
    phi[5,4]  R1938     1.2794536352157593e+00
    phi[5,4]  R1939     6.0153192281723022e-01
    phi[5,4]  R1940     2.2252583503723145e+00
    phi[5,4]  R1941     0.828194260597229
    phi[5,4]  R1942     9.5010602474212646e-01
    phi[5,4]  R1943     2.1598362922668457e+00
    phi[5,4]  R1944     1.2177836894989014e+00
    phi[5,4]  R1945     6.2312108278274536e-01
    phi[5,4]  R1946     -9.5100885629653931e-01
    phi[5,4]  R1947     -3.3563313484191895e+00
    phi[5,4]  R1948     -2.0805172920227051e+00
    phi[5,4]  R1949     -3.2488257884979248e+00
    phi[5,4]  R1950     -4.0639810562133789e+00
    phi[5,4]  R1951     -3.6794190406799316e+00
    phi[5,4]  R1952     -1.6260633468627930e+00
    phi[5,4]  R1953     -2.5315217971801758e+00
    phi[5,4]  R1954     -2.3085432052612305e+00
    phi[5,4]  R1955     -2.4476613998413086e+00
    phi[5,4]  R1956     -2.5149133205413818e+00
    phi[5,4]  R1957     -9.9706232547760010e-01
    phi[5,4]  R1958     -7.7825969457626343e-01
    phi[5,4]  R1959     -2.2911386489868164e+00
    phi[5,4]  R1960     1.3851609826087952e-01
    phi[5,4]  R1961     -4.2769312858581543e-04
    phi[5,4]  R1962     -3.7595915794372559e-01
    phi[5,4]  R1963     -2.6977107524871826e+00
    phi[5,4]  R1964     -2.2754948139190674e+00
    phi[5,4]  R1965     -5.6862151622772217e-01
    phi[5,4]  R1966     -1.4224802255630493e+00
    phi[5,4]  R1967     -0.834635317325592
    phi[5,4]  R1968     -1.4658658504486084e+00
    phi[5,4]  R1969     -1.4826879501342773e+00
    phi[5,4]  R1970     1.2372667789459229e+00
    phi[5,4]  R1971     -6.8143361806869507e-01
    phi[5,4]  R1972     -2.8161978721618652e-01
    phi[5,4]  R1973     -8.2134252786636353e-01
    phi[5,4]  R1974     -1.9720678329467773e+00
    phi[5,4]  R1975     -2.2614393234252930e+00
    phi[5,4]  R1976     -9.2362242937088013e-01
    phi[5,4]  R1977     -9.3353599309921265e-01
    phi[5,4]  R1978     -2.8592083454132080e+00
    phi[5,4]  R1979     9.9744945764541626e-01
    phi[5,4]  R1980     -9.3784385919570923e-01
    phi[5,4]  R1981     -1.8985871970653534e-01
    phi[5,4]  R1982     -0.11457559466362
    phi[5,4]  R1983     -0.611226499080658
    phi[5,4]  R1984     -8.4949588775634766e-01
    phi[5,4]  R1985     -2.0525836944580078e+00
    phi[5,4]  R1986     -4.8115390539169312e-01
    phi[5,4]  R1987     1.3090106844902039e-01
    phi[5,4]  R1988     0.150233194231987
    phi[5,4]  R1989     -2.5207295417785645e+00
    phi[5,4]  R1990     -3.3459177017211914e+00
    phi[5,4]  R1991     -1.4203413724899292e+00
    phi[5,4]  R1992     -0.198886901140213
    phi[5,4]  R1993     -1.3393635749816895e+00
    phi[5,4]  R1994     -2.7078204154968262e+00
    phi[5,4]  R1995     -1.3536406755447388e+00
    phi[5,4]  R1996     9.2417567968368530e-01
    phi[5,4]  R1997     -2.5498208999633789e+00
    phi[5,4]  R1998     8.7446987628936768e-01
    phi[5,4]  R1999     1.5119456052780151e+00
    phi[5,4]  R2000     -1.8385847806930542e+00
    phi[5,4]  R2001     -2.2482223510742188e+00
    phi[5,4]  R2002     -1.2958370447158813e+00
    phi[5,4]  R2003     -8.0106329917907715e-01
    phi[5,4]  R2004     9.7039178013801575e-02
    phi[5,4]  R2005     -2.2740507125854492e+00
    phi[5,4]  R2006     -4.6221889555454254e-02
    phi[5,4]  R2007     5.8612763881683350e-01
    phi[5,4]  R2008     1.8060906231403351e-01
    phi[5,4]  R2009     7.2762691974639893e-01
    phi[5,4]  R2010     -9.6866947412490845e-01
    phi[5,4]  R2011     3.7237685173749924e-03
    phi[5,4]  R2012     -3.8075485825538635e-01
    phi[5,4]  R2013     2.3247180879116058e-01
    phi[5,4]  R2014     8.5076552629470825e-01
    phi[5,4]  R2015     -1.2772547006607056e+00
    phi[8,4]  R36       -1
    phi[8,4]  R38       1.3567283072419181e+00
    phi[8,4]  R39       -1.7372120413499115e-02
    phi[8,4]  R40       -2.4839895291357847e+00
    phi[8,4]  R41       2.4987097719418014e+00
    phi[8,4]  R42       1.7682589915159661e+00
    phi[8,4]  R43       -3.5276147398467406e-01
    phi[8,4]  R44       8.9427933357589140e-01
    phi[8,4]  R72       1
    phi[8,4]  R2016     -4.4567282118744860e+00
    phi[8,4]  R2017     -1.7432715973906503e+00
    phi[8,4]  R2018     -2.2226278891232440e+00
    phi[8,4]  R2019     -2.2573721299502423e+00
    phi[8,4]  R2020     -6.1601037549678361e-01
    phi[8,4]  R2021     -5.5839894337683535e+00
    phi[8,4]  R2022     -5.0687097051845988e+00
    phi[8,4]  R2023     -7.1290161300996413e-02
    phi[8,4]  R2024     -4.8682588961485340e+00
    phi[8,4]  R2025     -1.3317409131166023e+00
    phi[8,4]  R2026     -1.7372384401846375e+00
    phi[8,4]  R2027     -2.4427613881539854e+00
    phi[8,4]  R2028     -3.9942792382084598e+00
    phi[8,4]  R2029     -2.2057205710566770e+00
    phi[8,4]  R2030     -3.8211910302633778e-01
    phi[8,4]  R2031     -3.0122163127707369e-01
    phi[8,4]  R2032     -3.0969836018151353e-01
    phi[8,4]  R2033     -3.2638725918177125e-01
    phi[8,4]  R2034     -3.2969373994432472e-01
    phi[8,4]  R2035     -3.4566268946005518e-01
    phi[8,4]  R2036     -3.6521278810623947e-01
    phi[8,4]  R2037     -0.376379457166637
    phi[8,4]  R2038     -3.7693105781890290e-01
    phi[8,4]  R2039     -4.0611554011327433e-01
    phi[8,4]  R2040     -3.4363218622861691e-01
    phi[8,4]  R2041     -1.1702001580180021e+00
    phi[8,4]  R2042     -3.8743563996540842e-01
    phi[8,4]  R2043     -1.2257731852961116e+00
    phi[8,4]  R2044     -1.3026326696447645e+00
    phi[8,4]  R2045     -4.3272004707822109e-01
    phi[8,4]  R2046     -1.4031874266308850e+00
    phi[8,4]  R2047     -0.471417654951912
    phi[8,4]  R2048     -5.4226804052981770e-01
    phi[8,4]  R2049     -5.5479011240743548e-01
    phi[8,4]  R2050     -2.4535319841341745e+00
    phi[8,4]  R2051     -6.9418834102865512e-01
    phi[8,4]  R2052     -7.1264761715170388e-01
    phi[8,4]  R2053     -7.3169843049663941e-01
    phi[8,4]  R2054     -7.4019948698945370e-01
    phi[8,4]  R2055     -0.800707139467479
    phi[8,4]  R2056     -8.0475964130711986e-01
    phi[8,4]  R2057     -8.2549283797430761e-01
    phi[8,4]  R2058     -8.2736038570489390e-01
    phi[8,4]  R2059     -8.3084151714686616e-01
    phi[8,4]  R2060     -1.2746408614393985e+00
    phi[8,4]  R2061     -3.1080279753067819e-01
    phi[8,4]  R2062     -3.1274233248913563e-01
    phi[8,4]  R2063     -3.2098858264853880e-01
    phi[8,4]  R2064     -3.4207872694736574e-01
    phi[8,4]  R2065     -8.7120282432637708e-01
    phi[8,4]  R2066     -4.5901581117781409e-01
    phi[8,4]  R2067     -6.7353908709905430e-01
    phi[8,4]  R2068     -0.495920168437852
    phi[8,4]  R2069     -4.9604994353167586e-01
    phi[8,4]  R2070     -0.32089753396361
    phi[8,4]  R2071     -1.21738390544574
    phi[8,4]  R2072     -0.434860637675488
    phi[8,4]  R2073     -4.5245715435167533e-01
    phi[8,4]  R2074     -4.6353266527418996e-01
    phi[8,4]  R2075     -4.6548326883437774e-01
    phi[8,4]  R2076     -6.1202919287153512e-01
    phi[8,4]  R2077     -7.0534544745533534e-01
    phi[8,4]  R2078     -7.0609663720229421e-01
    phi[8,4]  R2079     -7.0874416709487176e-01
    phi[8,4]  R2080     -2.4080821457935736e-01
    phi[8,4]  R2081     -3.6898429518159254e-01
    phi[8,4]  R2082     -3.8098361165837380e-01
    phi[8,4]  R2083     -0.386026531594843
    phi[8,4]  R2084     -4.9149166839900582e-01
    phi[8,4]  R2085     -4.9590984876929123e-01
    phi[8,4]  R2086     -5.5776864159790507e-01
    phi[8,4]  R2087     -6.5511603238791438e-01
    phi[8,4]  R2088     -6.6381156219474269e-01
    phi[8,4]  R2089     -7.0177200425190334e-01
    phi[8,4]  R2090     -0.3416856908885
    phi[8,4]  R2091     -3.9184289036897635e-01
    phi[8,4]  R2092     -3.9628552075315016e-01
    phi[8,4]  R2093     -4.7002045521591973e-01
    phi[8,4]  R2094     -4.7714642769302107e-01
    phi[8,4]  R2095     -5.4623612412928990e-01
    phi[8,4]  R2096     -5.5806234343345273e-01
    phi[8,4]  R2097     -0.570188075256106
    phi[8,4]  R2098     -5.9765650931568226e-01
    phi[8,4]  R2099     -6.0549395330408950e-01
    phi[8,4]  R2100     -2.0129511949657120e-01
    phi[8,4]  R2101     -3.0238083881732281e-01
    phi[8,4]  R2102     -3.7354937607029193e-01
    phi[8,4]  R2103     -3.8923153356063267e-01
    phi[8,4]  R2104     -8.0032000277524984e-01
    phi[8,4]  R2105     -8.1729467122601085e-01
    phi[8,4]  R2106     -8.6776994444325406e-01
    phi[8,4]  R2107     -8.6819713637225626e-01
    phi[8,4]  R2108     -8.7650886070259082e-01
    phi[8,4]  R2109     -8.7651591959562880e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2110     -3.0999999046325684e+00
    phi[5,6]  R2111     -3.0999999046325684e+00
    phi[5,6]  R2112     -2.2400000095367432e+00
    phi[5,6]  R2113     -2.2400000095367432e+00
    phi[5,6]  R2114     -3.0999999046325684e+00
    phi[5,6]  R2115     -3.0999999046325684e+00
    phi[5,6]  R2116     -2.5699999332427979e+00
    phi[5,6]  R2117     -2.5699999332427979e+00
    phi[5,6]  R2118     -3.0999999046325684e+00
    phi[5,6]  R2119     -3.0999999046325684e+00
    phi[5,6]  R2120     -2.0899999141693115e+00
    phi[5,6]  R2121     -2.0899999141693115e+00
    phi[5,6]  R2122     -3.0999999046325684e+00
    phi[5,6]  R2123     -3.0999999046325684e+00
    phi[5,6]  R2124     3.5862150788307190e-01
    phi[5,6]  R2125     -8.8397532701492310e-02
    phi[5,6]  R2126     -2.3632271289825439e+00
    phi[5,6]  R2127     -1.6439291238784790e+00
    phi[5,6]  R2128     -5.5766832828521729e-01
    phi[5,6]  R2129     4.1910272836685181e-01
    phi[5,6]  R2130     0.538382351398468
    phi[5,6]  R2131     4.2780020833015442e-01
    phi[5,6]  R2132     9.2371094226837158e-01
    phi[5,6]  R2133     -4.9513936042785645e-01
    phi[5,6]  R2134     -3.7828025817871094e+00
    phi[5,6]  R2135     -1.0869710445404053e+00
    phi[5,6]  R2136     -2.1998443603515625e+00
    phi[5,6]  R2137     -2.2529246807098389e+00
    phi[5,6]  R2138     -3.3244824409484863e+00
    phi[5,6]  R2139     -1.7207760810852051e+00
    phi[5,6]  R2140     -1.2366402149200439e+00
    phi[5,6]  R2141     -2.2820990085601807e+00
    phi[5,6]  R2142     -9.0117925405502319e-01
    phi[5,6]  R2143     1.01506769657135
    phi[5,6]  R2144     -1.0205707550048828e+00
    phi[5,6]  R2145     -2.5271527767181396e+00
    phi[5,6]  R2146     -3.2483839988708496e+00
    phi[5,6]  R2147     -1.7225369215011597e+00
    phi[5,6]  R2148     -2.0456347465515137e+00
    phi[5,6]  R2149     1.3176333904266357e-01
    phi[5,6]  R2150     -1.4420702457427979e+00
    phi[5,6]  R2151     -1.2058852910995483e+00
    phi[5,6]  R2152     -1.6367682218551636e+00
    phi[5,6]  R2153     -9.8614972829818726e-01
    phi[5,6]  R2154     -2.0370001792907715e+00
    phi[5,6]  R2155     -1.0286095142364502e+00
    phi[5,6]  R2156     -0.334529846906662
    phi[5,6]  R2157     -1.6693704128265381e+00
    phi[5,6]  R2158     -2.0915732383728027e+00
    phi[5,6]  R2159     -1.4981856346130371e+00
    phi[5,6]  R2160     -3.2042825222015381e-01
    phi[5,6]  R2161     -1.4067845046520233e-01
    phi[5,6]  R2162     6.2854802608489990e-01
    phi[5,6]  R2163     4.0614315867424011e-01
    phi[5,6]  R2164     -1.4917596578598022e+00
    phi[5,6]  R2165     -1.2277196645736694e+00
    phi[5,6]  R2166     -0.97231525182724
    phi[5,6]  R2167     -5.2728354930877686e-01
    phi[5,6]  R2168     -6.3815675675868988e-02
    phi[5,6]  R2169     2.1822267770767212e-01
    phi[5,6]  R2170     0.81246018409729
    phi[5,6]  R2171     -1.0950099229812622e+00
    phi[5,6]  R2172     9.7735381126403809e-01
    phi[5,6]  R2173     -1.2340433597564697e+00
    phi[5,6]  R2174     -1.3304902315139771e+00
    phi[5,6]  R2175     -1.6969020366668701e+00
    phi[5,6]  R2176     -0.729495108127594
    phi[5,6]  R2177     3.6927068233489990e-01
    phi[5,6]  R2178     -1.3265398740768433e+00
    phi[5,6]  R2179     5.9096527099609375e-01
    phi[5,6]  R2180     4.0344056487083435e-01
    phi[5,6]  R2181     -1.0654102563858032e+00
    phi[5,6]  R2182     -9.7947669029235840e-01
    phi[5,6]  R2183     -7.9193478822708130e-01
    phi[5,6]  R2184     -1.4723758697509766e+00
    phi[5,6]  R2185     -1.9478726387023926e+00
    phi[5,6]  R2186     -3.0355346202850342e+00
    phi[5,6]  R2187     -1.4996035397052765e-01
    phi[5,6]  R2188     -1.5929557085037231e+00
    phi[5,6]  R2189     -4.45606803894043
    phi[5,6]  R2190     3.6826890707015991e-01
    phi[5,6]  R2191     -5.6327456235885620e-01
    phi[5,6]  R2192     2.0189964771270752e-01
    phi[5,6]  R2193     -1.1730509996414185e+00
    phi[5,6]  R2194     1.5093492269515991e+00
    phi[5,6]  R2195     6.3041388988494873e-01
    phi[5,6]  R2196     2.2777254581451416e+00
    phi[5,6]  R2197     -1.0910432785749435e-02
    phi[5,6]  R2198     -0.984565019607544
    phi[5,6]  R2199     6.9346177577972412e-01
    phi[5,6]  R2200     -2.1284873783588409e-01
    phi[5,6]  R2201     -6.6894513368606567e-01
    phi[5,6]  R2202     0.4108866751194
    phi[5,6]  R2203     -1.8077449798583984e+00
    phi[5,6]  R2204     -1.8253020048141479e+00
    phi[5,6]  R2205     -4.9667525291442871e-01
    phi[5,6]  R2206     -1.2402451038360596e+00
    phi[5,6]  R2207     1.9479639828205109e-01
    phi[5,6]  R2208     -2.2038569450378418e+00
    phi[5,6]  R2209     -1.6567741632461548e+00
    phi[5,6]  R2210     -1.3183394670486450e+00
    phi[5,6]  R2211     -2.3902807235717773e+00
    phi[5,6]  R2212     -2.4996149539947510e+00
    phi[5,6]  R2213     -2.8021783828735352e+00
    phi[5,6]  R2214     -1.8186682462692261e+00
    phi[5,6]  R2215     -1.5118502378463745e+00
    phi[5,6]  R2216     -1.9107353687286377e+00
    phi[5,6]  R2217     -1.9671398401260376e+00
    phi[5,6]  R2218     -9.1071200370788574e-01
    phi[5,6]  R2219     -1.5515978336334229e+00
    phi[5,6]  R2220     -2.7778413295745850e+00
    phi[5,6]  R2221     -9.2749917507171631e-01
    phi[5,6]  R2222     -2.0440232753753662e+00
    phi[5,6]  R2223     -2.0575180053710938e+00
    phi[5,6]  R2224     -2.7537002563476562e+00
    phi[5,6]  R2225     -1.5726110935211182e+00
    phi[5,6]  R2226     -7.1176630258560181e-01
    phi[5,6]  R2227     -1.4822098016738892e+00
    phi[5,6]  R2228     -1.1258481740951538e+00
    phi[5,6]  R2229     -1.0191771984100342e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2230     -3.0999999046325684e+00
    phi[6,5]  R2231     -3.0999999046325684e+00
    phi[6,5]  R2232     -2.2400000095367432e+00
    phi[6,5]  R2233     -2.2400000095367432e+00
    phi[6,5]  R2234     -3.0999999046325684e+00
    phi[6,5]  R2235     -3.0999999046325684e+00
    phi[6,5]  R2236     -2.5699999332427979e+00
    phi[6,5]  R2237     -2.5699999332427979e+00
    phi[6,5]  R2238     -3.0999999046325684e+00
    phi[6,5]  R2239     -3.0999999046325684e+00
    phi[6,5]  R2240     -2.0899999141693115e+00
    phi[6,5]  R2241     -2.0899999141693115e+00
    phi[6,5]  R2242     -3.0999999046325684e+00
    phi[6,5]  R2243     -3.0999999046325684e+00
    phi[6,5]  R2244     1.5093492269515991e+00
    phi[6,5]  R2245     6.3041388988494873e-01
    phi[6,5]  R2246     2.2777254581451416e+00
    phi[6,5]  R2247     -1.0910432785749435e-02
    phi[6,5]  R2248     -0.984565019607544
    phi[6,5]  R2249     6.9346177577972412e-01
    phi[6,5]  R2250     -2.1284873783588409e-01
    phi[6,5]  R2251     -6.6894513368606567e-01
    phi[6,5]  R2252     0.4108866751194
    phi[6,5]  R2253     -1.8077449798583984e+00
    phi[6,5]  R2254     -1.8253020048141479e+00
    phi[6,5]  R2255     -4.9667525291442871e-01
    phi[6,5]  R2256     -1.2402451038360596e+00
    phi[6,5]  R2257     1.9479639828205109e-01
    phi[6,5]  R2258     -2.2038569450378418e+00
    phi[6,5]  R2259     -1.6567741632461548e+00
    phi[6,5]  R2260     -1.3183394670486450e+00
    phi[6,5]  R2261     -2.3902807235717773e+00
    phi[6,5]  R2262     -2.4996149539947510e+00
    phi[6,5]  R2263     -2.8021783828735352e+00
    phi[6,5]  R2264     -1.8186682462692261e+00
    phi[6,5]  R2265     -1.5118502378463745e+00
    phi[6,5]  R2266     -1.9107353687286377e+00
    phi[6,5]  R2267     -1.9671398401260376e+00
    phi[6,5]  R2268     -9.1071200370788574e-01
    phi[6,5]  R2269     -1.5515978336334229e+00
    phi[6,5]  R2270     -2.7778413295745850e+00
    phi[6,5]  R2271     -9.2749917507171631e-01
    phi[6,5]  R2272     -2.0440232753753662e+00
    phi[6,5]  R2273     -2.0575180053710938e+00
    phi[6,5]  R2274     -2.7537002563476562e+00
    phi[6,5]  R2275     -1.5726110935211182e+00
    phi[6,5]  R2276     -7.1176630258560181e-01
    phi[6,5]  R2277     -1.4822098016738892e+00
    phi[6,5]  R2278     -1.1258481740951538e+00
    phi[6,5]  R2279     -1.0191771984100342e+00
    phi[6,5]  R2280     3.5862150788307190e-01
    phi[6,5]  R2281     -8.8397532701492310e-02
    phi[6,5]  R2282     -2.3632271289825439e+00
    phi[6,5]  R2283     -1.6439291238784790e+00
    phi[6,5]  R2284     -5.5766832828521729e-01
    phi[6,5]  R2285     4.1910272836685181e-01
    phi[6,5]  R2286     0.538382351398468
    phi[6,5]  R2287     4.2780020833015442e-01
    phi[6,5]  R2288     9.2371094226837158e-01
    phi[6,5]  R2289     -4.9513936042785645e-01
    phi[6,5]  R2290     -3.7828025817871094e+00
    phi[6,5]  R2291     -1.0869710445404053e+00
    phi[6,5]  R2292     -2.1998443603515625e+00
    phi[6,5]  R2293     -2.2529246807098389e+00
    phi[6,5]  R2294     -3.3244824409484863e+00
    phi[6,5]  R2295     -1.7207760810852051e+00
    phi[6,5]  R2296     -1.2366402149200439e+00
    phi[6,5]  R2297     -2.2820990085601807e+00
    phi[6,5]  R2298     -9.0117925405502319e-01
    phi[6,5]  R2299     1.01506769657135
    phi[6,5]  R2300     -1.0205707550048828e+00
    phi[6,5]  R2301     -2.5271527767181396e+00
    phi[6,5]  R2302     -3.2483839988708496e+00
    phi[6,5]  R2303     -1.7225369215011597e+00
    phi[6,5]  R2304     -2.0456347465515137e+00
    phi[6,5]  R2305     1.3176333904266357e-01
    phi[6,5]  R2306     -1.4420702457427979e+00
    phi[6,5]  R2307     -1.2058852910995483e+00
    phi[6,5]  R2308     -1.6367682218551636e+00
    phi[6,5]  R2309     -9.8614972829818726e-01
    phi[6,5]  R2310     -2.0370001792907715e+00
    phi[6,5]  R2311     -1.0286095142364502e+00
    phi[6,5]  R2312     -0.334529846906662
    phi[6,5]  R2313     -1.6693704128265381e+00
    phi[6,5]  R2314     -2.0915732383728027e+00
    phi[6,5]  R2315     -1.4981856346130371e+00
    phi[6,5]  R2316     -3.2042825222015381e-01
    phi[6,5]  R2317     -1.4067845046520233e-01
    phi[6,5]  R2318     6.2854802608489990e-01
    phi[6,5]  R2319     4.0614315867424011e-01
    phi[6,5]  R2320     -1.4917596578598022e+00
    phi[6,5]  R2321     -1.2277196645736694e+00
    phi[6,5]  R2322     -0.97231525182724
    phi[6,5]  R2323     -5.2728354930877686e-01
    phi[6,5]  R2324     -6.3815675675868988e-02
    phi[6,5]  R2325     2.1822267770767212e-01
    phi[6,5]  R2326     0.81246018409729
    phi[6,5]  R2327     -1.0950099229812622e+00
    phi[6,5]  R2328     9.7735381126403809e-01
    phi[6,5]  R2329     -1.2340433597564697e+00
    phi[6,5]  R2330     -1.3304902315139771e+00
    phi[6,5]  R2331     -1.6969020366668701e+00
    phi[6,5]  R2332     -0.729495108127594
    phi[6,5]  R2333     3.6927068233489990e-01
    phi[6,5]  R2334     -1.3265398740768433e+00
    phi[6,5]  R2335     5.9096527099609375e-01
    phi[6,5]  R2336     4.0344056487083435e-01
    phi[6,5]  R2337     -1.0654102563858032e+00
    phi[6,5]  R2338     -9.7947669029235840e-01
    phi[6,5]  R2339     -7.9193478822708130e-01
    phi[6,5]  R2340     -1.4723758697509766e+00
    phi[6,5]  R2341     -1.9478726387023926e+00
    phi[6,5]  R2342     -3.0355346202850342e+00
    phi[6,5]  R2343     -1.4996035397052765e-01
    phi[6,5]  R2344     -1.5929557085037231e+00
    phi[6,5]  R2345     -4.45606803894043
    phi[6,5]  R2346     3.6826890707015991e-01
    phi[6,5]  R2347     -5.6327456235885620e-01
    phi[6,5]  R2348     2.0189964771270752e-01
    phi[6,5]  R2349     -1.1730509996414185e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2350     -3.0999999046325684e+00
    phi[6,7]  R2351     -3.0999999046325684e+00
    phi[6,7]  R2352     -2.2400000095367432e+00
    phi[6,7]  R2353     -2.2400000095367432e+00
    phi[6,7]  R2354     -3.0999999046325684e+00
    phi[6,7]  R2355     -3.0999999046325684e+00
    phi[6,7]  R2356     -2.5699999332427979e+00
    phi[6,7]  R2357     -2.5699999332427979e+00
    phi[6,7]  R2358     -3.0999999046325684e+00
    phi[6,7]  R2359     -3.0999999046325684e+00
    phi[6,7]  R2360     -2.0899999141693115e+00
    phi[6,7]  R2361     -2.0899999141693115e+00
    phi[6,7]  R2362     -3.0999999046325684e+00
    phi[6,7]  R2363     -3.0999999046325684e+00
    phi[6,7]  R2364     1.5093492269515991e+00
    phi[6,7]  R2365     6.3041388988494873e-01
    phi[6,7]  R2366     2.2777254581451416e+00
    phi[6,7]  R2367     -1.0910432785749435e-02
    phi[6,7]  R2368     -0.984565019607544
    phi[6,7]  R2369     6.9346177577972412e-01
    phi[6,7]  R2370     -2.1284873783588409e-01
    phi[6,7]  R2371     -6.6894513368606567e-01
    phi[6,7]  R2372     0.4108866751194
    phi[6,7]  R2373     -1.8077449798583984e+00
    phi[6,7]  R2374     -1.8253020048141479e+00
    phi[6,7]  R2375     -4.9667525291442871e-01
    phi[6,7]  R2376     -1.2402451038360596e+00
    phi[6,7]  R2377     1.9479639828205109e-01
    phi[6,7]  R2378     -2.2038569450378418e+00
    phi[6,7]  R2379     -1.6567741632461548e+00
    phi[6,7]  R2380     -1.3183394670486450e+00
    phi[6,7]  R2381     -2.3902807235717773e+00
    phi[6,7]  R2382     -2.4996149539947510e+00
    phi[6,7]  R2383     -2.8021783828735352e+00
    phi[6,7]  R2384     -1.8186682462692261e+00
    phi[6,7]  R2385     -1.5118502378463745e+00
    phi[6,7]  R2386     -1.9107353687286377e+00
    phi[6,7]  R2387     -1.9671398401260376e+00
    phi[6,7]  R2388     -9.1071200370788574e-01
    phi[6,7]  R2389     -1.5515978336334229e+00
    phi[6,7]  R2390     -2.7778413295745850e+00
    phi[6,7]  R2391     -9.2749917507171631e-01
    phi[6,7]  R2392     -2.0440232753753662e+00
    phi[6,7]  R2393     -2.0575180053710938e+00
    phi[6,7]  R2394     -2.7537002563476562e+00
    phi[6,7]  R2395     -1.5726110935211182e+00
    phi[6,7]  R2396     -7.1176630258560181e-01
    phi[6,7]  R2397     -1.4822098016738892e+00
    phi[6,7]  R2398     -1.1258481740951538e+00
    phi[6,7]  R2399     -1.0191771984100342e+00
    phi[6,7]  R2400     1.5157955884933472e+00
    phi[6,7]  R2401     1.4524074792861938e+00
    phi[6,7]  R2402     1.9572380781173706e+00
    phi[6,7]  R2403     7.0032197237014771e-01
    phi[6,7]  R2404     3.6809897422790527e-01
    phi[6,7]  R2405     1.8319376707077026e+00
    phi[6,7]  R2406     1.1818906068801880e+00
    phi[6,7]  R2407     0.0642305240035057
    phi[6,7]  R2408     -1.2609101533889771e+00
    phi[6,7]  R2409     2.9697136878967285e+00
    phi[6,7]  R2410     2.2100695967674255e-01
    phi[6,7]  R2411     -1.5630285739898682e+00
    phi[6,7]  R2412     -5.5848407745361328e-01
    phi[6,7]  R2413     3.8759194314479828e-02
    phi[6,7]  R2414     -1.9457818269729614e+00
    phi[6,7]  R2415     1.9051110744476318e-01
    phi[6,7]  R2416     -1.0537143945693970e+00
    phi[6,7]  R2417     -8.2304340600967407e-01
    phi[6,7]  R2418     -1.1463737487792969e+00
    phi[6,7]  R2419     -1.0232319831848145e+00
    phi[6,7]  R2420     2.0703089237213135e+00
    phi[6,7]  R2421     -1.0858736038208008e+00
    phi[6,7]  R2422     -9.0961617231369019e-01
    phi[6,7]  R2423     -6.7851436138153076e-01
    phi[6,7]  R2424     -1.7182477712631226e+00
    phi[6,7]  R2425     -1.4546529054641724e+00
    phi[6,7]  R2426     -1.2674812078475952e+00
    phi[6,7]  R2427     9.9343806505203247e-01
    phi[6,7]  R2428     -3.0663328170776367e+00
    phi[6,7]  R2429     -8.6945533752441406e-01
    phi[6,7]  R2430     -1.2644258737564087e+00
    phi[6,7]  R2431     -8.7993699312210083e-01
    phi[6,7]  R2432     3.1222975254058838e-01
    phi[6,7]  R2433     -2.2932727336883545e+00
    phi[6,7]  R2434     1.7466973066329956e+00
    phi[6,7]  R2435     -1.1367386579513550e+00
    phi[6,7]  R2436     3.8913464546203613e-01
    phi[6,7]  R2437     -4.3696403503417969e-01
    phi[6,7]  R2438     1.6298514604568481e+00
    phi[6,7]  R2439     1.9558619260787964e+00
    phi[6,7]  R2440     7.2932803630828857e-01
    phi[6,7]  R2441     1.5361700057983398e+00
    phi[6,7]  R2442     -4.6852782368659973e-02
    phi[6,7]  R2443     -5.5777156352996826e-01
    phi[6,7]  R2444     5.6770741939544678e-02
    phi[6,7]  R2445     -5.3308892250061035e-01
    phi[6,7]  R2446     1.3279511928558350e+00
    phi[6,7]  R2447     -1.7660877704620361e+00
    phi[6,7]  R2448     -1.2284924983978271e+00
    phi[6,7]  R2449     -1.8811229467391968e+00
    phi[6,7]  R2450     -1.9472305774688721e+00
    phi[6,7]  R2451     -2.1569206714630127e+00
    phi[6,7]  R2452     -1.0387932062149048e+00
    phi[6,7]  R2453     -1.4165586233139038e+00
    phi[6,7]  R2454     -4.8767790198326111e-01
    phi[6,7]  R2455     -2.2541556358337402e+00
    phi[6,7]  R2456     -1.6244801282882690e+00
    phi[6,7]  R2457     -1.0569058656692505e+00
    phi[6,7]  R2458     -5.2110075950622559e-01
    phi[6,7]  R2459     -9.8713082075119019e-01
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2460     -3.0999999046325684e+00
    phi[7,6]  R2461     -3.0999999046325684e+00
    phi[7,6]  R2462     -2.2400000095367432e+00
    phi[7,6]  R2463     -2.2400000095367432e+00
    phi[7,6]  R2464     -3.0999999046325684e+00
    phi[7,6]  R2465     -3.0999999046325684e+00
    phi[7,6]  R2466     -2.5699999332427979e+00
    phi[7,6]  R2467     -2.5699999332427979e+00
    phi[7,6]  R2468     -3.0999999046325684e+00
    phi[7,6]  R2469     -3.0999999046325684e+00
    phi[7,6]  R2470     -2.0899999141693115e+00
    phi[7,6]  R2471     -2.0899999141693115e+00
    phi[7,6]  R2472     -3.0999999046325684e+00
    phi[7,6]  R2473     -3.0999999046325684e+00
    phi[7,6]  R2474     1.5157955884933472e+00
    phi[7,6]  R2475     1.4524074792861938e+00
    phi[7,6]  R2476     1.9572380781173706e+00
    phi[7,6]  R2477     7.0032197237014771e-01
    phi[7,6]  R2478     3.6809897422790527e-01
    phi[7,6]  R2479     1.8319376707077026e+00
    phi[7,6]  R2480     1.1818906068801880e+00
    phi[7,6]  R2481     0.0642305240035057
    phi[7,6]  R2482     -1.2609101533889771e+00
    phi[7,6]  R2483     2.9697136878967285e+00
    phi[7,6]  R2484     2.2100695967674255e-01
    phi[7,6]  R2485     -1.5630285739898682e+00
    phi[7,6]  R2486     -5.5848407745361328e-01
    phi[7,6]  R2487     3.8759194314479828e-02
    phi[7,6]  R2488     -1.9457818269729614e+00
    phi[7,6]  R2489     1.9051110744476318e-01
    phi[7,6]  R2490     -1.0537143945693970e+00
    phi[7,6]  R2491     -8.2304340600967407e-01
    phi[7,6]  R2492     -1.1463737487792969e+00
    phi[7,6]  R2493     -1.0232319831848145e+00
    phi[7,6]  R2494     2.0703089237213135e+00
    phi[7,6]  R2495     -1.0858736038208008e+00
    phi[7,6]  R2496     -9.0961617231369019e-01
    phi[7,6]  R2497     -6.7851436138153076e-01
    phi[7,6]  R2498     -1.7182477712631226e+00
    phi[7,6]  R2499     -1.4546529054641724e+00
    phi[7,6]  R2500     -1.2674812078475952e+00
    phi[7,6]  R2501     9.9343806505203247e-01
    phi[7,6]  R2502     -3.0663328170776367e+00
    phi[7,6]  R2503     -8.6945533752441406e-01
    phi[7,6]  R2504     -1.2644258737564087e+00
    phi[7,6]  R2505     -8.7993699312210083e-01
    phi[7,6]  R2506     3.1222975254058838e-01
    phi[7,6]  R2507     -2.2932727336883545e+00
    phi[7,6]  R2508     1.7466973066329956e+00
    phi[7,6]  R2509     -1.1367386579513550e+00
    phi[7,6]  R2510     3.8913464546203613e-01
    phi[7,6]  R2511     -4.3696403503417969e-01
    phi[7,6]  R2512     1.6298514604568481e+00
    phi[7,6]  R2513     1.9558619260787964e+00
    phi[7,6]  R2514     7.2932803630828857e-01
    phi[7,6]  R2515     1.5361700057983398e+00
    phi[7,6]  R2516     -4.6852782368659973e-02
    phi[7,6]  R2517     -5.5777156352996826e-01
    phi[7,6]  R2518     5.6770741939544678e-02
    phi[7,6]  R2519     -5.3308892250061035e-01
    phi[7,6]  R2520     1.3279511928558350e+00
    phi[7,6]  R2521     -1.7660877704620361e+00
    phi[7,6]  R2522     -1.2284924983978271e+00
    phi[7,6]  R2523     -1.8811229467391968e+00
    phi[7,6]  R2524     -1.9472305774688721e+00
    phi[7,6]  R2525     -2.1569206714630127e+00
    phi[7,6]  R2526     -1.0387932062149048e+00
    phi[7,6]  R2527     -1.4165586233139038e+00
    phi[7,6]  R2528     -4.8767790198326111e-01
    phi[7,6]  R2529     -2.2541556358337402e+00
    phi[7,6]  R2530     -1.6244801282882690e+00
    phi[7,6]  R2531     -1.0569058656692505e+00
    phi[7,6]  R2532     -5.2110075950622559e-01
    phi[7,6]  R2533     -9.8713082075119019e-01
    phi[7,6]  R2534     1.5093492269515991e+00
    phi[7,6]  R2535     6.3041388988494873e-01
    phi[7,6]  R2536     2.2777254581451416e+00
    phi[7,6]  R2537     -1.0910432785749435e-02
    phi[7,6]  R2538     -0.984565019607544
    phi[7,6]  R2539     6.9346177577972412e-01
    phi[7,6]  R2540     -2.1284873783588409e-01
    phi[7,6]  R2541     -6.6894513368606567e-01
    phi[7,6]  R2542     0.4108866751194
    phi[7,6]  R2543     -1.8077449798583984e+00
    phi[7,6]  R2544     -1.8253020048141479e+00
    phi[7,6]  R2545     -4.9667525291442871e-01
    phi[7,6]  R2546     -1.2402451038360596e+00
    phi[7,6]  R2547     1.9479639828205109e-01
    phi[7,6]  R2548     -2.2038569450378418e+00
    phi[7,6]  R2549     -1.6567741632461548e+00
    phi[7,6]  R2550     -1.3183394670486450e+00
    phi[7,6]  R2551     -2.3902807235717773e+00
    phi[7,6]  R2552     -2.4996149539947510e+00
    phi[7,6]  R2553     -2.8021783828735352e+00
    phi[7,6]  R2554     -1.8186682462692261e+00
    phi[7,6]  R2555     -1.5118502378463745e+00
    phi[7,6]  R2556     -1.9107353687286377e+00
    phi[7,6]  R2557     -1.9671398401260376e+00
    phi[7,6]  R2558     -9.1071200370788574e-01
    phi[7,6]  R2559     -1.5515978336334229e+00
    phi[7,6]  R2560     -2.7778413295745850e+00
    phi[7,6]  R2561     -9.2749917507171631e-01
    phi[7,6]  R2562     -2.0440232753753662e+00
    phi[7,6]  R2563     -2.0575180053710938e+00
    phi[7,6]  R2564     -2.7537002563476562e+00
    phi[7,6]  R2565     -1.5726110935211182e+00
    phi[7,6]  R2566     -7.1176630258560181e-01
    phi[7,6]  R2567     -1.4822098016738892e+00
    phi[7,6]  R2568     -1.1258481740951538e+00
    phi[7,6]  R2569     -1.0191771984100342e+00
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       -8.4712564880147179e-01
    phi[7,9]  R66       -1.4068509057788878e+00
    phi[7,9]  R67       1.1598911621112240e-01
    phi[7,9]  R68       -3.3840290506970705e-01
    phi[7,9]  R69       -2.7303100849715150e+00
    phi[7,9]  R70       -3.8858765544074547e-01
    phi[7,9]  R71       -2.1393204627349696e+00
    phi[7,9]  R73       -1
    phi[7,9]  R2570     -3.94712555343404
    phi[7,9]  R2571     -2.2528742558310966e+00
    phi[7,9]  R2572     -3.6468509153156310e+00
    phi[7,9]  R2573     -8.3314910375785534e-01
    phi[7,9]  R2574     -2.9840107884214460e+00
    phi[7,9]  R2575     -3.2159890208436908e+00
    phi[7,9]  R2576     -2.9084028383125049e+00
    phi[7,9]  R2577     -2.2315970281730908e+00
    phi[7,9]  R2578     -5.8303099896040838e+00
    phi[7,9]  R2579     -3.6968981966105341e-01
    phi[7,9]  R2580     -2.4785875696100570e+00
    phi[7,9]  R2581     -1.7014122587285661e+00
    phi[7,9]  R2582     -5.2393203673675384e+00
    phi[7,9]  R2583     -9.6067944189759880e-01
    phi[7,9]  R2584     -2.2869319199395277e-01
    phi[7,9]  R2585     -2.7276784351969496e-01
    phi[7,9]  R2586     -2.7284480158090973e-01
    phi[7,9]  R2587     -2.7984936131686089e-01
    phi[7,9]  R2588     -0.282862343284892
    phi[7,9]  R2589     -2.8379366607684053e-01
    phi[7,9]  R2590     -2.8399686178958294e-01
    phi[7,9]  R2591     -2.9887580600402658e-01
    phi[7,9]  R2592     -3.0638155486911722e-01
    phi[7,9]  R2593     -3.0952315807885622e-01
    phi[7,9]  R2594     -2.3598116170293726e-01
    phi[7,9]  R2595     -2.4343825848686973e-01
    phi[7,9]  R2596     -2.6664910963717547e-01
    phi[7,9]  R2597     -2.6699527815076851e-01
    phi[7,9]  R2598     -2.6930794726362861e-01
    phi[7,9]  R2599     -2.7379248294441183e-01
    phi[7,9]  R2600     -2.7396622582078889e-01
    phi[7,9]  R2601     -2.7646908559028693e-01
    phi[7,9]  R2602     -2.8048253426312963e-01
    phi[7,9]  R2603     -2.9004844980442857e-01
    phi[7,9]  R2604     -2.0877653835825649e-01
    phi[7,9]  R2605     -2.1897895011205637e-01
    phi[7,9]  R2606     -2.2114944410119830e-01
    phi[7,9]  R2607     -2.2416343988381332e-01
    phi[7,9]  R2608     -2.3534823497153612e-01
    phi[7,9]  R2609     -2.3603118458285111e-01
    phi[7,9]  R2610     -2.3844140650217449e-01
    phi[7,9]  R2611     -2.4642340950769070e-01
    phi[7,9]  R2612     -2.5017539988163184e-01
    phi[7,9]  R2613     -2.5065519787762147e-01
    phi[7,9]  R2614     -1.9727858966621592e-01
    phi[7,9]  R2615     -2.2551096779406177e-01
    phi[7,9]  R2616     -2.2669308184169745e-01
    phi[7,9]  R2617     -2.4680732699636154e-01
    phi[7,9]  R2618     -2.5667269213757615e-01
    phi[7,9]  R2619     -2.5963227653233434e-01
    phi[7,9]  R2620     -2.6115809058614159e-01
    phi[7,9]  R2621     -2.6897002347530619e-01
    phi[7,9]  R2622     -2.8929858678285569e-01
    phi[7,9]  R2623     -3.0381675358123506e-01
    phi[7,9]  R2624     -1.9278229445980388e-01
    phi[7,9]  R2625     -2.3162835114449809e-01
    phi[7,9]  R2626     -2.3958147704710087e-01
    phi[7,9]  R2627     -2.3959564971991393e-01
    phi[7,9]  R2628     -0.24302967052406
    phi[7,9]  R2629     -7.8094084507729034e-01
    phi[7,9]  R2630     -2.7549391927677558e-01
    phi[7,9]  R2631     -3.0717444746942224e-01
    phi[7,9]  R2632     -1.18490651923774
    phi[7,9]  R2633     -1.0016022372238045e+00
    phi[7,9]  R2634     -2.1211980961049903e-01
    phi[7,9]  R2635     -2.5813594294317088e-01
    phi[7,9]  R2636     -2.7330724264264061e-01
    phi[7,9]  R2637     -1.3044334519158685e+00
    phi[7,9]  R2638     -8.0687608489057272e-01
    phi[7,9]  R2639     -1.2284001484416633e+00
    phi[7,9]  R2640     -4.7956525028448049e-01
    phi[7,9]  R2641     -1.0578314492000964e+00
    phi[7,9]  R2642     -5.3008307391159759e-01
    phi[7,9]  R2643     -7.7834975580597310e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       1.7100869119167328e-01
    z[0,1,0]  R89       5.5702650547027588e-01
    z[0,1,0]  R90       2.7477458119392395e-01
    z[0,1,0]  R91       0.0161072239279747
    z[0,1,0]  R92       2.3288173973560333e-01
    z[0,1,0]  R93       -4.1363561153411865e-01
    z[0,1,0]  R94       6.4785279333591461e-02
    z[0,1,0]  R95       -1.8434689939022064e-01
    z[0,1,0]  R96       2.4861548840999603e-01
    z[0,1,0]  R97       -3.9969703555107117e-01
    z[0,1,0]  R98       2.2537778317928314e-01
    z[0,1,0]  R99       -1.6907557845115662e-01
    z[0,1,0]  R100      3.8456264138221741e-01
    z[0,1,0]  R101      4.2606998234987259e-02
    z[0,1,0]  R102      1.5546953678131104e-01
    z[0,1,0]  R103      1.5194568037986755e-01
    z[0,1,0]  R104      9.8743841052055359e-02
    z[0,1,0]  R105      1.5659880638122559e-01
    z[0,1,0]  R106      4.4227278232574463e-01
    z[0,1,0]  R107      2.9409646987915039e-01
    z[0,1,0]  R108      6.7874324321746826e-01
    z[0,1,0]  R109      -2.6537823677062988e-01
    z[0,1,0]  R110      -8.6096087470650673e-03
    z[0,1,0]  R111      -1.4754873514175415e-01
    z[0,1,0]  R112      -1.3693846762180328e-01
    z[0,1,0]  R113      -6.1380922794342041e-01
    z[0,1,0]  R114      1.0916613787412643e-01
    z[0,1,0]  R115      -4.5338609814643860e-01
    z[0,1,0]  R116      -2.4482056498527527e-01
    z[0,1,0]  R117      -4.1672316193580627e-01
    z[0,1,0]  R118      7.4712353944778442e-01
    z[0,1,0]  R119      -4.8969838023185730e-01
    z[0,1,0]  R120      1.5534083545207977e-01
    z[0,1,0]  R121      -6.7616707086563110e-01
    z[0,1,0]  R122      -5.5766785144805908e-01
    z[0,1,0]  R123      2.8004637360572815e-01
    z[0,1,0]  R124      -1.9828376173973083e-01
    z[0,1,0]  R125      -8.5096381604671478e-02
    z[0,1,0]  R126      -0.393048495054245
    z[0,1,0]  R127      -1.2451636791229248e-01
    z[0,1,0]  R128      8.4260833263397217e-01
    z[0,1,0]  R129      2.4188110232353210e-01
    z[0,1,0]  R130      1.1477822810411453e-01
    z[0,1,0]  R131      -1.5447893738746643e-01
    z[0,1,0]  R132      -2.0491238683462143e-02
    z[0,1,0]  R133      1.6565407812595367e-01
    z[0,1,0]  R134      -1.5606896579265594e-01
    z[0,1,0]  R135      -3.8013646006584167e-01
    z[0,1,0]  R136      7.9477488994598389e-02
    z[0,1,0]  R137      1.5868206322193146e-01
    z[0,1,0]  R138      4.2231917381286621e-01
    z[0,1,0]  R139      -1.0622905939817429e-01
    z[0,1,0]  R140      -1.1425952613353729e-01
    z[0,1,0]  R141      -5.4170143604278564e-01
    z[0,1,0]  R142      -0.0959658995270729
    z[0,1,0]  R143      -1.1131045222282410e-01
    z[0,1,0]  R144      -5.2563261985778809e-01
    z[0,1,0]  R145      -6.2662810087203979e-01
    z[0,1,0]  R146      -0.735031247138977
    z[0,1,0]  R147      -6.4145928621292114e-01
    z[0,1,0]  R148      -8.7314969301223755e-01
    z[0,1,0]  R149      -7.1911793947219849e-01
    z[0,1,0]  R150      -6.6781973838806152e-01
    z[0,1,0]  R151      -6.0775339603424072e-01
    z[0,1,0]  R152      5.4935562610626221e-01
    z[0,1,0]  R153      4.4997698068618774e-01
    z[0,1,0]  R154      5.5023741722106934e-01
    z[0,1,0]  R155      6.2460505962371826e-01
    z[0,1,0]  R156      5.3648352622985840e-01
    z[0,1,0]  R157      4.3952482938766479e-01
    z[0,1,0]  R158      -2.1675482392311096e-01
    z[0,1,0]  R159      -2.7263683080673218e-01
    z[0,1,0]  R160      -2.3004268109798431e-01
    z[0,1,0]  R161      4.8230504989624023e-01
    z[0,1,0]  R162      -5.2062119357287884e-03
    z[0,1,0]  R163      1.5500935912132263e-01
    z[0,1,0]  R164      2.4142050743103027e-01
    z[0,1,0]  R165      2.1509313583374023e-01
    z[0,1,0]  R166      3.4782573580741882e-01
    z[0,1,0]  R167      0.562000036239624
    z[0,1,0]  R168      4.4336032867431641e-01
    z[0,1,0]  R169      8.4264105558395386e-01
    z[0,1,0]  R170      -2.1403899788856506e-01
    z[0,1,0]  R171      6.7912155389785767e-01
    z[0,1,0]  R172      -8.2067124545574188e-02
    z[0,1,0]  R173      3.4387308359146118e-01
    z[0,1,0]  R174      -2.5361815094947815e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       0.364397794008255
    z[0,1,1]  R89       0.59727543592453
    z[0,1,1]  R90       2.2113518416881561e-01
    z[0,1,1]  R91       5.1349848508834839e-01
    z[0,1,1]  R92       3.0965054035186768e-01
    z[0,1,1]  R93       5.9379267692565918e-01
    z[0,1,1]  R94       3.3784812688827515e-01
    z[0,1,1]  R95       4.4527783989906311e-01
    z[0,1,1]  R96       5.1362925767898560e-01
    z[0,1,1]  R97       -0.673263430595398
    z[0,1,1]  R98       -8.0944615602493286e-01
    z[0,1,1]  R99       -9.0964114665985107e-01
    z[0,1,1]  R100      -8.4404426813125610e-01
    z[0,1,1]  R101      -8.1154882907867432e-01
    z[0,1,1]  R102      -0.852180004119873
    z[0,1,1]  R103      -0.802143394947052
    z[0,1,1]  R104      -8.2273662090301514e-01
    z[0,1,1]  R105      -8.1920778751373291e-01
    z[0,1,1]  R106      -8.2633709907531738e-01
    z[0,1,1]  R107      -7.8579616546630859e-01
    z[0,1,1]  R108      2.2106523811817169e-01
    z[0,1,1]  R109      -5.3301107883453369e-01
    z[0,1,1]  R110      -9.3082493543624878e-01
    z[0,1,1]  R111      -0.639501690864563
    z[0,1,1]  R112      -7.5223529338836670e-01
    z[0,1,1]  R113      -0.611943244934082
    z[0,1,1]  R114      -7.5828351080417633e-02
    z[0,1,1]  R115      4.5163372159004211e-01
    z[0,1,1]  R116      2.5264132022857666e-01
    z[0,1,1]  R117      2.2036257386207581e-01
    z[0,1,1]  R118      -1.4292629063129425e-01
    z[0,1,1]  R119      -4.9250790476799011e-01
    z[0,1,1]  R120      -8.6433261632919312e-01
    z[0,1,1]  R121      -5.4577279090881348e-01
    z[0,1,1]  R122      -4.0878617763519287e-01
    z[0,1,1]  R123      -8.1643259525299072e-01
    z[0,1,1]  R124      -0.767369270324707
    z[0,1,1]  R125      -7.9266226291656494e-01
    z[0,1,1]  R126      -6.5824913978576660e-01
    z[0,1,1]  R127      -6.7528587579727173e-01
    z[0,1,1]  R128      1.8896445631980896e-01
    z[0,1,1]  R129      -4.8006501793861389e-01
    z[0,1,1]  R130      6.3000261783599854e-01
    z[0,1,1]  R131      6.3745582103729248e-01
    z[0,1,1]  R132      -9.4899761676788330e-01
    z[0,1,1]  R133      -9.0974158048629761e-01
    z[0,1,1]  R134      -9.3185275793075562e-01
    z[0,1,1]  R135      -4.6076655387878418e-01
    z[0,1,1]  R136      -6.8318635225296021e-01
    z[0,1,1]  R137      7.7136307954788208e-02
    z[0,1,1]  R138      -3.6867281794548035e-01
    z[0,1,1]  R139      -8.0004745721817017e-01
    z[0,1,1]  R140      -5.4384297132492065e-01
    z[0,1,1]  R141      -6.3243098556995392e-02
    z[0,1,1]  R142      -8.4444028139114380e-01
    z[0,1,1]  R143      -6.6713988780975342e-01
    z[0,1,1]  R144      -1.4305049180984497e-01
    z[0,1,1]  R145      -6.0757622122764587e-02
    z[0,1,1]  R146      -1.3459648191928864e-01
    z[0,1,1]  R147      -1.4120139181613922e-01
    z[0,1,1]  R148      -2.4379432201385498e-01
    z[0,1,1]  R149      -2.2934935986995697e-01
    z[0,1,1]  R150      -0.321400910615921
    z[0,1,1]  R151      -5.2542246878147125e-02
    z[0,1,1]  R152      3.1723433732986450e-01
    z[0,1,1]  R153      -2.3725772276520729e-02
    z[0,1,1]  R154      9.8788812756538391e-02
    z[0,1,1]  R155      3.8652196526527405e-01
    z[0,1,1]  R156      -5.1489561796188354e-01
    z[0,1,1]  R157      1.6857534646987915e-02
    z[0,1,1]  R158      5.4728990793228149e-01
    z[0,1,1]  R159      6.3247776031494141e-01
    z[0,1,1]  R160      5.0224870443344116e-01
    z[0,1,1]  R161      5.5295862257480621e-02
    z[0,1,1]  R162      4.1310203075408936e-01
    z[0,1,1]  R163      5.5382519960403442e-01
    z[0,1,1]  R164      -5.5219709873199463e-01
    z[0,1,1]  R165      -0.627499520778656
    z[0,1,1]  R166      -4.1637489199638367e-01
    z[0,1,1]  R167      -2.5099787116050720e-01
    z[0,1,1]  R168      1.7124684154987335e-01
    z[0,1,1]  R169      2.5005084276199341e-01
    z[0,1,1]  R170      0.42324098944664
    z[0,1,1]  R171      1.9040256738662720e-02
    z[0,1,1]  R172      -0.0722082108259201
    z[0,1,1]  R173      2.5022500753402710e-01
    z[0,1,1]  R174      5.8972829580307007e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       8.1947362422943115e-01
    z[0,1,2]  R89       6.5707027912139893e-02
    z[0,1,2]  R90       7.1899324655532837e-01
    z[0,1,2]  R91       5.0596338510513306e-01
    z[0,1,2]  R92       7.4975913763046265e-01
    z[0,1,2]  R93       5.8152687549591064e-01
    z[0,1,2]  R94       5.9093868732452393e-01
    z[0,1,2]  R95       7.2123205661773682e-01
    z[0,1,2]  R96       0.237759068608284
    z[0,1,2]  R97       4.4213291257619858e-03
    z[0,1,2]  R98       -3.4749990701675415e-01
    z[0,1,2]  R99       1.0062158852815628e-01
    z[0,1,2]  R100      1.5836326405405998e-02
    z[0,1,2]  R101      -1.9477196037769318e-01
    z[0,1,2]  R102      -1.5739586949348450e-01
    z[0,1,2]  R103      -2.1539069712162018e-01
    z[0,1,2]  R104      -1.7674618959426880e-01
    z[0,1,2]  R105      -1.3218337297439575e-01
    z[0,1,2]  R106      -2.0232470333576202e-01
    z[0,1,2]  R107      -2.4495676159858704e-01
    z[0,1,2]  R108      -2.9079401493072510e-01
    z[0,1,2]  R109      -8.0045007169246674e-02
    z[0,1,2]  R110      -6.1496417969465256e-02
    z[0,1,2]  R111      -0.351165771484375
    z[0,1,2]  R112      3.1412267684936523e-01
    z[0,1,2]  R113      -9.4151444733142853e-02
    z[0,1,2]  R114      -1.7917390167713165e-01
    z[0,1,2]  R115      -5.0620126724243164e-01
    z[0,1,2]  R116      -5.0399070978164673e-01
    z[0,1,2]  R117      -0.363391250371933
    z[0,1,2]  R118      -0.0655822828412056
    z[0,1,2]  R119      4.0806770324707031e-01
    z[0,1,2]  R120      3.1533968448638916e-01
    z[0,1,2]  R121      3.5414081811904907e-01
    z[0,1,2]  R122      -1.3705284893512726e-01
    z[0,1,2]  R123      -2.4633088707923889e-01
    z[0,1,2]  R124      -3.4460136294364929e-01
    z[0,1,2]  R125      1.4858037233352661e-01
    z[0,1,2]  R126      -4.9796235561370850e-01
    z[0,1,2]  R127      -3.4064370393753052e-01
    z[0,1,2]  R128      -6.6855573095381260e-03
    z[0,1,2]  R129      9.8814904689788818e-02
    z[0,1,2]  R130      -2.5099816918373108e-01
    z[0,1,2]  R131      -1.6343134641647339e-01
    z[0,1,2]  R132      -1.2185386568307877e-01
    z[0,1,2]  R133      -3.2223123311996460e-01
    z[0,1,2]  R134      -2.6625648140907288e-01
    z[0,1,2]  R135      1.0322643071413040e-01
    z[0,1,2]  R136      -4.9273246526718140e-01
    z[0,1,2]  R137      1.5159864723682404e-01
    z[0,1,2]  R138      2.7118667960166931e-01
    z[0,1,2]  R139      2.5700709223747253e-01
    z[0,1,2]  R140      1.4827635884284973e-01
    z[0,1,2]  R141      -1.3728782534599304e-01
    z[0,1,2]  R142      -6.3559204339981079e-02
    z[0,1,2]  R143      -5.7696157693862915e-01
    z[0,1,2]  R144      -6.8022996187210083e-01
    z[0,1,2]  R145      -5.4369497299194336e-01
    z[0,1,2]  R146      -0.588640034198761
    z[0,1,2]  R147      -6.3312333822250366e-01
    z[0,1,2]  R148      3.3912312239408493e-02
    z[0,1,2]  R149      -2.1556296944618225e-01
    z[0,1,2]  R150      4.7245416045188904e-01
    z[0,1,2]  R151      -4.6791471540927887e-02
    z[0,1,2]  R152      8.0904394388198853e-02
    z[0,1,2]  R153      4.8915353417396545e-01
    z[0,1,2]  R154      5.3377203643321991e-02
    z[0,1,2]  R155      7.6720081269741058e-03
    z[0,1,2]  R156      2.0588225126266479e-01
    z[0,1,2]  R157      6.4833855628967285e-01
    z[0,1,2]  R158      5.4666930809617043e-03
    z[0,1,2]  R159      -4.9795752763748169e-01
    z[0,1,2]  R160      -1.0970401018857956e-01
    z[0,1,2]  R161      4.3045702576637268e-01
    z[0,1,2]  R162      -0.309946745634079
    z[0,1,2]  R163      -3.0110391974449158e-01
    z[0,1,2]  R164      -2.9382395744323730e-01
    z[0,1,2]  R165      -1.7092472314834595e-01
    z[0,1,2]  R166      -4.8073044419288635e-01
    z[0,1,2]  R167      -0.640221893787384
    z[0,1,2]  R168      -0.0763794332742691
    z[0,1,2]  R169      -2.2934117913246155e-01
    z[0,1,2]  R170      0.157013937830925
    z[0,1,2]  R171      3.5703918337821960e-01
    z[0,1,2]  R172      4.9444994330406189e-01
    z[0,1,2]  R173      -3.4975919127464294e-01
    z[0,1,2]  R174      -4.5922389626502991e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       8.5660547018051147e-02
    z[0,1,3]  R89       2.7198737859725952e-01
    z[0,1,3]  R90       1.6805322468280792e-01
    z[0,1,3]  R91       2.0597749948501587e-01
    z[0,1,3]  R92       -1.6725739464163780e-02
    z[0,1,3]  R93       2.5260123610496521e-01
    z[0,1,3]  R94       1.8239581584930420e-01
    z[0,1,3]  R95       1.4585982263088226e-01
    z[0,1,3]  R96       -7.8262068331241608e-02
    z[0,1,3]  R97       1.1281822808086872e-02
    z[0,1,3]  R98       7.2790971025824547e-03
    z[0,1,3]  R99       4.0342751890420914e-02
    z[0,1,3]  R100      3.6678362637758255e-02
    z[0,1,3]  R101      -5.0640669651329517e-03
    z[0,1,3]  R102      -6.6116988658905029e-02
    z[0,1,3]  R103      2.4095119908452034e-02
    z[0,1,3]  R104      0.00373685359954834
    z[0,1,3]  R105      4.3788827024400234e-03
    z[0,1,3]  R106      -9.2257685959339142e-02
    z[0,1,3]  R107      -3.5431653261184692e-02
    z[0,1,3]  R108      -3.1329861283302307e-01
    z[0,1,3]  R109      9.6256427466869354e-02
    z[0,1,3]  R110      1.3446553051471710e-01
    z[0,1,3]  R111      2.2640231251716614e-01
    z[0,1,3]  R112      9.3737974762916565e-02
    z[0,1,3]  R113      2.7037955820560455e-02
    z[0,1,3]  R114      1.2076328694820404e-01
    z[0,1,3]  R115      -3.6070051789283752e-01
    z[0,1,3]  R116      -6.0981345176696777e-01
    z[0,1,3]  R117      -5.5927598476409912e-01
    z[0,1,3]  R118      4.4853985309600830e-02
    z[0,1,3]  R119      1.1449429392814636e-01
    z[0,1,3]  R120      9.5849819481372833e-02
    z[0,1,3]  R121      1.7167614400386810e-01
    z[0,1,3]  R122      1.0390021651983261e-01
    z[0,1,3]  R123      1.6754738986492157e-02
    z[0,1,3]  R124      4.7868089750409126e-03
    z[0,1,3]  R125      9.9124103784561157e-02
    z[0,1,3]  R126      1.4544361270964146e-02
    z[0,1,3]  R127      6.7582853138446808e-02
    z[0,1,3]  R128      -8.6285084486007690e-02
    z[0,1,3]  R129      1.9811521470546722e-01
    z[0,1,3]  R130      -3.3602741360664368e-01
    z[0,1,3]  R131      -2.7378478646278381e-01
    z[0,1,3]  R132      -7.5606115162372589e-02
    z[0,1,3]  R133      -2.4072457104921341e-02
    z[0,1,3]  R134      -1.0722508281469345e-01
    z[0,1,3]  R135      3.7878003716468811e-01
    z[0,1,3]  R136      1.1484664678573608e-01
    z[0,1,3]  R137      -8.5799562931060791e-01
    z[0,1,3]  R138      3.3663338422775269e-01
    z[0,1,3]  R139      2.6797682046890259e-01
    z[0,1,3]  R140      1.3685268163681030e-01
    z[0,1,3]  R141      1.2173786759376526e-01
    z[0,1,3]  R142      3.9388176053762436e-02
    z[0,1,3]  R143      5.8200873434543610e-02
    z[0,1,3]  R144      -0.351654976606369
    z[0,1,3]  R145      -3.7919861078262329e-01
    z[0,1,3]  R146      -2.6014360785484314e-01
    z[0,1,3]  R147      -3.0291095376014709e-01
    z[0,1,3]  R148      -1.6805936396121979e-01
    z[0,1,3]  R149      -4.7248509526252747e-01
    z[0,1,3]  R150      -1.1511293053627014e-01
    z[0,1,3]  R151      -7.5418412685394287e-02
    z[0,1,3]  R152      -3.5622778534889221e-01
    z[0,1,3]  R153      -4.7691002488136292e-01
    z[0,1,3]  R154      -4.3441405892372131e-01
    z[0,1,3]  R155      -1.7295217514038086e-01
    z[0,1,3]  R156      -5.0518423318862915e-01
    z[0,1,3]  R157      2.4070739746093750e-01
    z[0,1,3]  R158      6.5755927562713623e-01
    z[0,1,3]  R159      3.6037364602088928e-01
    z[0,1,3]  R160      6.9393843412399292e-01
    z[0,1,3]  R161      2.2118794918060303e-01
    z[0,1,3]  R162      5.6181758642196655e-01
    z[0,1,3]  R163      0.0750875174999237
    z[0,1,3]  R164      5.7986301183700562e-01
    z[0,1,3]  R165      6.6029745340347290e-01
    z[0,1,3]  R166      3.5390517115592957e-01
    z[0,1,3]  R167      3.8755786418914795e-01
    z[0,1,3]  R168      -2.6661860942840576e-01
    z[0,1,3]  R169      5.9386178851127625e-02
    z[0,1,3]  R170      7.5733649730682373e-01
    z[0,1,3]  R171      3.6607436835765839e-02
    z[0,1,3]  R172      5.0470304489135742e-01
    z[0,1,3]  R173      -6.7365425825119019e-01
    z[0,1,3]  R174      4.7751367092132568e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       1.6381217539310455e-01
    z[0,1,4]  R89       2.7178052067756653e-01
    z[0,1,4]  R90       2.5117889046669006e-01
    z[0,1,4]  R91       -3.7221035361289978e-01
    z[0,1,4]  R92       -4.3140459060668945e-01
    z[0,1,4]  R93       1.1651613563299179e-01
    z[0,1,4]  R94       -0.594077467918396
    z[0,1,4]  R95       -4.7356334328651428e-01
    z[0,1,4]  R96       -6.4592367410659790e-01
    z[0,1,4]  R97       -1.8489469587802887e-01
    z[0,1,4]  R98       -3.5218980908393860e-01
    z[0,1,4]  R99       3.1666931509971619e-01
    z[0,1,4]  R100      -8.3939999341964722e-02
    z[0,1,4]  R101      3.5732370615005493e-01
    z[0,1,4]  R102      -2.0779301226139069e-01
    z[0,1,4]  R103      -5.6297097355127335e-02
    z[0,1,4]  R104      0.0520341582596302
    z[0,1,4]  R105      4.5179638266563416e-01
    z[0,1,4]  R106      1.8847376108169556e-01
    z[0,1,4]  R107      4.7834178805351257e-01
    z[0,1,4]  R108      7.8083015978336334e-02
    z[0,1,4]  R109      6.0871785879135132e-01
    z[0,1,4]  R110      -1.9667983055114746e-02
    z[0,1,4]  R111      2.3853531479835510e-01
    z[0,1,4]  R112      -3.9662539958953857e-01
    z[0,1,4]  R113      -1.1603917926549911e-01
    z[0,1,4]  R114      5.0484424829483032e-01
    z[0,1,4]  R115      -2.9431957751512527e-02
    z[0,1,4]  R116      -1.1342797428369522e-01
    z[0,1,4]  R117      -4.3735250830650330e-02
    z[0,1,4]  R118      -4.9066543579101562e-02
    z[0,1,4]  R119      1.7202247679233551e-01
    z[0,1,4]  R120      2.0369161665439606e-01
    z[0,1,4]  R121      1.4570695161819458e-01
    z[0,1,4]  R122      0.510697066783905
    z[0,1,4]  R123      4.2817533016204834e-01
    z[0,1,4]  R124      -6.2248710542917252e-02
    z[0,1,4]  R125      -1.7212116718292236e-01
    z[0,1,4]  R126      -1.5582512319087982e-01
    z[0,1,4]  R127      -2.1015605330467224e-01
    z[0,1,4]  R128      -1.9098210334777832e-01
    z[0,1,4]  R129      5.4872775077819824e-01
    z[0,1,4]  R130      -1.6331200301647186e-01
    z[0,1,4]  R131      4.4019460678100586e-01
    z[0,1,4]  R132      -1.5691466629505157e-02
    z[0,1,4]  R133      1.5748563408851624e-01
    z[0,1,4]  R134      1.0603963583707809e-01
    z[0,1,4]  R135      2.3172182962298393e-02
    z[0,1,4]  R136      -1.8282647430896759e-01
    z[0,1,4]  R137      3.6729222536087036e-01
    z[0,1,4]  R138      3.0288836359977722e-01
    z[0,1,4]  R139      2.7664214372634888e-01
    z[0,1,4]  R140      3.7263301014900208e-01
    z[0,1,4]  R141      6.0452502965927124e-01
    z[0,1,4]  R142      -1.9241786003112793e-01
    z[0,1,4]  R143      3.1464549899101257e-01
    z[0,1,4]  R144      -6.0030579566955566e-02
    z[0,1,4]  R145      -8.0049656331539154e-02
    z[0,1,4]  R146      -6.9107718765735626e-02
    z[0,1,4]  R147      1.2726886570453644e-01
    z[0,1,4]  R148      -3.5162156820297241e-01
    z[0,1,4]  R149      3.5999134182929993e-01
    z[0,1,4]  R150      1.3808570802211761e-01
    z[0,1,4]  R151      3.6242789030075073e-01
    z[0,1,4]  R152      2.3739543557167053e-01
    z[0,1,4]  R153      -1.6379849612712860e-01
    z[0,1,4]  R154      1.4983379840850830e-01
    z[0,1,4]  R155      6.0889708995819092e-01
    z[0,1,4]  R156      -2.4703058600425720e-01
    z[0,1,4]  R157      3.0834496021270752e-01
    z[0,1,4]  R158      -8.5020549595355988e-02
    z[0,1,4]  R159      1.6559921205043793e-02
    z[0,1,4]  R160      1.7816863954067230e-01
    z[0,1,4]  R161      -1.6855482757091522e-01
    z[0,1,4]  R162      -5.9320521354675293e-01
    z[0,1,4]  R163      -7.4704706668853760e-01
    z[0,1,4]  R164      -2.1361015737056732e-01
    z[0,1,4]  R165      2.6117104291915894e-01
    z[0,1,4]  R166      3.0422362685203552e-01
    z[0,1,4]  R167      9.3214645981788635e-02
    z[0,1,4]  R168      3.2586145401000977e-01
    z[0,1,4]  R169      -3.7242567539215088e-01
    z[0,1,4]  R170      -3.3418461680412292e-01
    z[0,1,4]  R171      3.9609670639038086e-01
    z[0,1,4]  R172      0.0793774202466011
    z[0,1,4]  R173      -3.2611221075057983e-01
    z[0,1,4]  R174      1.2232114374637604e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       -1.7492744326591492e-01
    z[0,1,5]  R89       3.2663241028785706e-01
    z[0,1,5]  R90       -1.6068068146705627e-01
    z[0,1,5]  R91       1.0876525938510895e-01
    z[0,1,5]  R92       -3.1814646720886230e-01
    z[0,1,5]  R93       2.4606071412563324e-01
    z[0,1,5]  R94       2.2672069072723389e-01
    z[0,1,5]  R95       4.3682102113962173e-02
    z[0,1,5]  R96       -2.5896748900413513e-01
    z[0,1,5]  R97       -2.4546343833208084e-02
    z[0,1,5]  R98       2.0347313582897186e-01
    z[0,1,5]  R99       4.8144187778234482e-02
    z[0,1,5]  R100      1.1396773904561996e-01
    z[0,1,5]  R101      -4.8214205889962614e-04
    z[0,1,5]  R102      -1.2855327129364014e-01
    z[0,1,5]  R103      2.3646475374698639e-01
    z[0,1,5]  R104      -1.7903022468090057e-01
    z[0,1,5]  R105      -2.6337078213691711e-01
    z[0,1,5]  R106      -1.2136088311672211e-01
    z[0,1,5]  R107      -3.8589175790548325e-02
    z[0,1,5]  R108      -5.4918748140335083e-01
    z[0,1,5]  R109      -1.4547589235007763e-02
    z[0,1,5]  R110      3.1602028012275696e-01
    z[0,1,5]  R111      0.510955274105072
    z[0,1,5]  R112      4.3707564473152161e-02
    z[0,1,5]  R113      1.1700762063264847e-01
    z[0,1,5]  R114      3.6962375044822693e-01
    z[0,1,5]  R115      4.0672972798347473e-01
    z[0,1,5]  R116      0.487321138381958
    z[0,1,5]  R117      5.1651990413665771e-01
    z[0,1,5]  R118      1.7020761966705322e-01
    z[0,1,5]  R119      -0.555191159248352
    z[0,1,5]  R120      -2.4275766313076019e-01
    z[0,1,5]  R121      2.4373291432857513e-01
    z[0,1,5]  R122      1.4232157170772552e-01
    z[0,1,5]  R123      -1.9320044666528702e-02
    z[0,1,5]  R124      0.00600613234564662
    z[0,1,5]  R125      5.5288810282945633e-02
    z[0,1,5]  R126      3.4333890676498413e-01
    z[0,1,5]  R127      -2.4083672463893890e-01
    z[0,1,5]  R128      -1.3166481256484985e-01
    z[0,1,5]  R129      3.3198451995849609e-01
    z[0,1,5]  R130      -4.2954063415527344e-01
    z[0,1,5]  R131      -5.1770615577697754e-01
    z[0,1,5]  R132      -1.2514603137969971e-01
    z[0,1,5]  R133      4.0554400533437729e-02
    z[0,1,5]  R134      -5.5437948554754257e-02
    z[0,1,5]  R135      6.7175167798995972e-01
    z[0,1,5]  R136      3.6202329397201538e-01
    z[0,1,5]  R137      2.5308024883270264e-01
    z[0,1,5]  R138      5.1114994287490845e-01
    z[0,1,5]  R139      3.5662892460823059e-01
    z[0,1,5]  R140      -7.1113187074661255e-01
    z[0,1,5]  R141      -4.1240021586418152e-01
    z[0,1,5]  R142      1.6171183437108994e-02
    z[0,1,5]  R143      3.2572954893112183e-01
    z[0,1,5]  R144      -3.2344126701354980e-01
    z[0,1,5]  R145      -3.8070490956306458e-01
    z[0,1,5]  R146      -1.5041446685791016e-01
    z[0,1,5]  R147      -2.4250821769237518e-01
    z[0,1,5]  R148      1.2961870431900024e-01
    z[0,1,5]  R149      1.6045066714286804e-01
    z[0,1,5]  R150      -3.9478784799575806e-01
    z[0,1,5]  R151      -5.4924523830413818e-01
    z[0,1,5]  R152      -5.7758718729019165e-01
    z[0,1,5]  R153      -0.53410404920578
    z[0,1,5]  R154      -4.2254528962075710e-03
    z[0,1,5]  R155      2.2024048864841461e-01
    z[0,1,5]  R156      9.7692899405956268e-02
    z[0,1,5]  R157      -1.6185204684734344e-01
    z[0,1,5]  R158      -1.6028022393584251e-02
    z[0,1,5]  R159      1.5007193386554718e-01
    z[0,1,5]  R160      4.0822145342826843e-01
    z[0,1,5]  R161      1.1324766278266907e-01
    z[0,1,5]  R162      1.0664886236190796e-01
    z[0,1,5]  R163      -6.9709710776805878e-02
    z[0,1,5]  R164      -4.0737521648406982e-01
    z[0,1,5]  R165      -7.0643156766891479e-02
    z[0,1,5]  R166      -3.6483255028724670e-01
    z[0,1,5]  R167      -5.6257039308547974e-02
    z[0,1,5]  R168      -5.9323471784591675e-01
    z[0,1,5]  R169      -1.3628005981445312e-01
    z[0,1,5]  R170      -1.2858848273754120e-01
    z[0,1,5]  R171      -4.9038168787956238e-01
    z[0,1,5]  R172      6.9194871187210083e-01
    z[0,1,5]  R173      7.1098648011684418e-02
    z[0,1,5]  R174      3.6602234840393066e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       3.1884399056434631e-01
    z[0,1,6]  R89       -2.7227851748466492e-01
    z[0,1,6]  R90       -4.9142214655876160e-01
    z[0,1,6]  R91       -5.3596991300582886e-01
    z[0,1,6]  R92       1.1703094467520714e-02
    z[0,1,6]  R93       0.0146006615832448
    z[0,1,6]  R94       3.0798447132110596e-01
    z[0,1,6]  R95       -1.1080397292971611e-02
    z[0,1,6]  R96       -3.5698670148849487e-01
    z[0,1,6]  R97       -0.593315601348877
    z[0,1,6]  R98       8.8053919374942780e-02
    z[0,1,6]  R99       1.7209558188915253e-01
    z[0,1,6]  R100      3.4361341595649719e-01
    z[0,1,6]  R101      4.1705024242401123e-01
    z[0,1,6]  R102      4.0096101164817810e-01
    z[0,1,6]  R103      0.476885586977005
    z[0,1,6]  R104      4.9733448028564453e-01
    z[0,1,6]  R105      1.1575733125209808e-01
    z[0,1,6]  R106      1.4786525070667267e-01
    z[0,1,6]  R107      6.6876187920570374e-02
    z[0,1,6]  R108      -4.0917722508311272e-03
    z[0,1,6]  R109      -0.508971631526947
    z[0,1,6]  R110      1.0664170980453491e-01
    z[0,1,6]  R111      -2.7697867155075073e-01
    z[0,1,6]  R112      -3.8562685251235962e-01
    z[0,1,6]  R113      4.6044796705245972e-01
    z[0,1,6]  R114      7.3766958713531494e-01
    z[0,1,6]  R115      -1.9449464976787567e-01
    z[0,1,6]  R116      -2.8869467787444592e-03
    z[0,1,6]  R117      2.5344389677047729e-01
    z[0,1,6]  R118      6.1942511796951294e-01
    z[0,1,6]  R119      1.3202281668782234e-02
    z[0,1,6]  R120      1.4053647220134735e-01
    z[0,1,6]  R121      9.6981525421142578e-02
    z[0,1,6]  R122      4.5962461829185486e-01
    z[0,1,6]  R123      -1.0170855373144150e-01
    z[0,1,6]  R124      4.9914318323135376e-01
    z[0,1,6]  R125      -5.4759550094604492e-01
    z[0,1,6]  R126      1.4791837334632874e-01
    z[0,1,6]  R127      -0.552911639213562
    z[0,1,6]  R128      4.3932226300239563e-01
    z[0,1,6]  R129      5.0070071220397949e-01
    z[0,1,6]  R130      4.5036903023719788e-01
    z[0,1,6]  R131      -7.9545125365257263e-02
    z[0,1,6]  R132      -2.5002273917198181e-01
    z[0,1,6]  R133      -1.1861776560544968e-01
    z[0,1,6]  R134      1.0288503021001816e-01
    z[0,1,6]  R135      -1.9306229054927826e-01
    z[0,1,6]  R136      -0.326310396194458
    z[0,1,6]  R137      -1.0381789505481720e-01
    z[0,1,6]  R138      3.8189920783042908e-01
    z[0,1,6]  R139      -8.4024742245674133e-02
    z[0,1,6]  R140      -7.6818592846393585e-02
    z[0,1,6]  R141      -3.6519506573677063e-01
    z[0,1,6]  R142      4.8459663987159729e-01
    z[0,1,6]  R143      -3.4069389104843140e-02
    z[0,1,6]  R144      -9.3032263219356537e-02
    z[0,1,6]  R145      1.1360388994216919e-01
    z[0,1,6]  R146      -6.3811009749770164e-03
    z[0,1,6]  R147      3.1372848898172379e-02
    z[0,1,6]  R148      -9.1330170631408691e-02
    z[0,1,6]  R149      7.2253830730915070e-02
    z[0,1,6]  R150      -1.9831590354442596e-01
    z[0,1,6]  R151      4.3240424990653992e-01
    z[0,1,6]  R152      2.7232986688613892e-01
    z[0,1,6]  R153      -1.3470865786075592e-01
    z[0,1,6]  R154      6.8807476758956909e-01
    z[0,1,6]  R155      -1.0600224882364273e-01
    z[0,1,6]  R156      2.8089359402656555e-01
    z[0,1,6]  R157      4.5494848489761353e-01
    z[0,1,6]  R158      -4.6215969324111938e-01
    z[0,1,6]  R159      -3.5357350111007690e-01
    z[0,1,6]  R160      5.3406346589326859e-02
    z[0,1,6]  R161      -6.9919317960739136e-01
    z[0,1,6]  R162      2.3312492668628693e-01
    z[0,1,6]  R163      -1.0004618018865585e-01
    z[0,1,6]  R164      -5.1352199167013168e-02
    z[0,1,6]  R165      -1.4686885476112366e-01
    z[0,1,6]  R166      -3.5163024067878723e-01
    z[0,1,6]  R167      -2.2184905409812927e-01
    z[0,1,6]  R168      -4.8895165324211121e-01
    z[0,1,6]  R169      -1.1846186965703964e-01
    z[0,1,6]  R170      -2.2051757574081421e-01
    z[0,1,6]  R171      -1.1066807806491852e-01
    z[0,1,6]  R172      0.0612468495965004
    z[0,1,6]  R173      -3.6275735497474670e-01
    z[0,1,6]  R174      -7.5998269021511078e-03
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R175      -1
    z[1,0,0]  R176      1
    z[1,0,0]  R189      -8.7314969301223755e-01
    z[1,0,0]  R190      -7.1911793947219849e-01
    z[1,0,0]  R191      -6.6781973838806152e-01
    z[1,0,0]  R192      -6.0775339603424072e-01
    z[1,0,0]  R193      5.4935562610626221e-01
    z[1,0,0]  R194      4.4997698068618774e-01
    z[1,0,0]  R195      5.5023741722106934e-01
    z[1,0,0]  R196      6.2460505962371826e-01
    z[1,0,0]  R197      5.3648352622985840e-01
    z[1,0,0]  R198      4.3952482938766479e-01
    z[1,0,0]  R199      -2.1675482392311096e-01
    z[1,0,0]  R200      -2.7263683080673218e-01
    z[1,0,0]  R201      -2.3004268109798431e-01
    z[1,0,0]  R202      4.8230504989624023e-01
    z[1,0,0]  R203      -5.2062119357287884e-03
    z[1,0,0]  R204      1.5500935912132263e-01
    z[1,0,0]  R205      2.4142050743103027e-01
    z[1,0,0]  R206      2.1509313583374023e-01
    z[1,0,0]  R207      3.4782573580741882e-01
    z[1,0,0]  R208      0.562000036239624
    z[1,0,0]  R209      4.4336032867431641e-01
    z[1,0,0]  R210      8.4264105558395386e-01
    z[1,0,0]  R211      -2.1403899788856506e-01
    z[1,0,0]  R212      6.7912155389785767e-01
    z[1,0,0]  R213      -8.2067124545574188e-02
    z[1,0,0]  R214      3.4387308359146118e-01
    z[1,0,0]  R215      -2.5361815094947815e-01
    z[1,0,0]  R216      1.7100869119167328e-01
    z[1,0,0]  R217      5.5702650547027588e-01
    z[1,0,0]  R218      2.7477458119392395e-01
    z[1,0,0]  R219      0.0161072239279747
    z[1,0,0]  R220      2.3288173973560333e-01
    z[1,0,0]  R221      -4.1363561153411865e-01
    z[1,0,0]  R222      6.4785279333591461e-02
    z[1,0,0]  R223      -1.8434689939022064e-01
    z[1,0,0]  R224      2.4861548840999603e-01
    z[1,0,0]  R225      -3.9969703555107117e-01
    z[1,0,0]  R226      2.2537778317928314e-01
    z[1,0,0]  R227      -1.6907557845115662e-01
    z[1,0,0]  R228      3.8456264138221741e-01
    z[1,0,0]  R229      4.2606998234987259e-02
    z[1,0,0]  R230      1.5546953678131104e-01
    z[1,0,0]  R231      1.5194568037986755e-01
    z[1,0,0]  R232      9.8743841052055359e-02
    z[1,0,0]  R233      1.5659880638122559e-01
    z[1,0,0]  R234      4.4227278232574463e-01
    z[1,0,0]  R235      2.9409646987915039e-01
    z[1,0,0]  R236      6.7874324321746826e-01
    z[1,0,0]  R237      -2.6537823677062988e-01
    z[1,0,0]  R238      -8.6096087470650673e-03
    z[1,0,0]  R239      -1.4754873514175415e-01
    z[1,0,0]  R240      -1.3693846762180328e-01
    z[1,0,0]  R241      -6.1380922794342041e-01
    z[1,0,0]  R242      1.0916613787412643e-01
    z[1,0,0]  R243      -4.5338609814643860e-01
    z[1,0,0]  R244      -2.4482056498527527e-01
    z[1,0,0]  R245      -4.1672316193580627e-01
    z[1,0,0]  R246      7.4712353944778442e-01
    z[1,0,0]  R247      -4.8969838023185730e-01
    z[1,0,0]  R248      1.5534083545207977e-01
    z[1,0,0]  R249      -6.7616707086563110e-01
    z[1,0,0]  R250      -5.5766785144805908e-01
    z[1,0,0]  R251      2.8004637360572815e-01
    z[1,0,0]  R252      -1.9828376173973083e-01
    z[1,0,0]  R253      -8.5096381604671478e-02
    z[1,0,0]  R254      -0.393048495054245
    z[1,0,0]  R255      -1.2451636791229248e-01
    z[1,0,0]  R256      8.4260833263397217e-01
    z[1,0,0]  R257      2.4188110232353210e-01
    z[1,0,0]  R258      1.1477822810411453e-01
    z[1,0,0]  R259      -1.5447893738746643e-01
    z[1,0,0]  R260      -2.0491238683462143e-02
    z[1,0,0]  R261      1.6565407812595367e-01
    z[1,0,0]  R262      -1.5606896579265594e-01
    z[1,0,0]  R263      -3.8013646006584167e-01
    z[1,0,0]  R264      7.9477488994598389e-02
    z[1,0,0]  R265      1.5868206322193146e-01
    z[1,0,0]  R266      4.2231917381286621e-01
    z[1,0,0]  R267      -1.0622905939817429e-01
    z[1,0,0]  R268      -1.1425952613353729e-01
    z[1,0,0]  R269      -5.4170143604278564e-01
    z[1,0,0]  R270      -0.0959658995270729
    z[1,0,0]  R271      -1.1131045222282410e-01
    z[1,0,0]  R272      -5.2563261985778809e-01
    z[1,0,0]  R273      -6.2662810087203979e-01
    z[1,0,0]  R274      -0.735031247138977
    z[1,0,0]  R275      -6.4145928621292114e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R177      -1
    z[1,0,1]  R178      1
    z[1,0,1]  R189      -2.4379432201385498e-01
    z[1,0,1]  R190      -2.2934935986995697e-01
    z[1,0,1]  R191      -0.321400910615921
    z[1,0,1]  R192      -5.2542246878147125e-02
    z[1,0,1]  R193      3.1723433732986450e-01
    z[1,0,1]  R194      -2.3725772276520729e-02
    z[1,0,1]  R195      9.8788812756538391e-02
    z[1,0,1]  R196      3.8652196526527405e-01
    z[1,0,1]  R197      -5.1489561796188354e-01
    z[1,0,1]  R198      1.6857534646987915e-02
    z[1,0,1]  R199      5.4728990793228149e-01
    z[1,0,1]  R200      6.3247776031494141e-01
    z[1,0,1]  R201      5.0224870443344116e-01
    z[1,0,1]  R202      5.5295862257480621e-02
    z[1,0,1]  R203      4.1310203075408936e-01
    z[1,0,1]  R204      5.5382519960403442e-01
    z[1,0,1]  R205      -5.5219709873199463e-01
    z[1,0,1]  R206      -0.627499520778656
    z[1,0,1]  R207      -4.1637489199638367e-01
    z[1,0,1]  R208      -2.5099787116050720e-01
    z[1,0,1]  R209      1.7124684154987335e-01
    z[1,0,1]  R210      2.5005084276199341e-01
    z[1,0,1]  R211      0.42324098944664
    z[1,0,1]  R212      1.9040256738662720e-02
    z[1,0,1]  R213      -0.0722082108259201
    z[1,0,1]  R214      2.5022500753402710e-01
    z[1,0,1]  R215      5.8972829580307007e-01
    z[1,0,1]  R216      0.364397794008255
    z[1,0,1]  R217      0.59727543592453
    z[1,0,1]  R218      2.2113518416881561e-01
    z[1,0,1]  R219      5.1349848508834839e-01
    z[1,0,1]  R220      3.0965054035186768e-01
    z[1,0,1]  R221      5.9379267692565918e-01
    z[1,0,1]  R222      3.3784812688827515e-01
    z[1,0,1]  R223      4.4527783989906311e-01
    z[1,0,1]  R224      5.1362925767898560e-01
    z[1,0,1]  R225      -0.673263430595398
    z[1,0,1]  R226      -8.0944615602493286e-01
    z[1,0,1]  R227      -9.0964114665985107e-01
    z[1,0,1]  R228      -8.4404426813125610e-01
    z[1,0,1]  R229      -8.1154882907867432e-01
    z[1,0,1]  R230      -0.852180004119873
    z[1,0,1]  R231      -0.802143394947052
    z[1,0,1]  R232      -8.2273662090301514e-01
    z[1,0,1]  R233      -8.1920778751373291e-01
    z[1,0,1]  R234      -8.2633709907531738e-01
    z[1,0,1]  R235      -7.8579616546630859e-01
    z[1,0,1]  R236      2.2106523811817169e-01
    z[1,0,1]  R237      -5.3301107883453369e-01
    z[1,0,1]  R238      -9.3082493543624878e-01
    z[1,0,1]  R239      -0.639501690864563
    z[1,0,1]  R240      -7.5223529338836670e-01
    z[1,0,1]  R241      -0.611943244934082
    z[1,0,1]  R242      -7.5828351080417633e-02
    z[1,0,1]  R243      4.5163372159004211e-01
    z[1,0,1]  R244      2.5264132022857666e-01
    z[1,0,1]  R245      2.2036257386207581e-01
    z[1,0,1]  R246      -1.4292629063129425e-01
    z[1,0,1]  R247      -4.9250790476799011e-01
    z[1,0,1]  R248      -8.6433261632919312e-01
    z[1,0,1]  R249      -5.4577279090881348e-01
    z[1,0,1]  R250      -4.0878617763519287e-01
    z[1,0,1]  R251      -8.1643259525299072e-01
    z[1,0,1]  R252      -0.767369270324707
    z[1,0,1]  R253      -7.9266226291656494e-01
    z[1,0,1]  R254      -6.5824913978576660e-01
    z[1,0,1]  R255      -6.7528587579727173e-01
    z[1,0,1]  R256      1.8896445631980896e-01
    z[1,0,1]  R257      -4.8006501793861389e-01
    z[1,0,1]  R258      6.3000261783599854e-01
    z[1,0,1]  R259      6.3745582103729248e-01
    z[1,0,1]  R260      -9.4899761676788330e-01
    z[1,0,1]  R261      -9.0974158048629761e-01
    z[1,0,1]  R262      -9.3185275793075562e-01
    z[1,0,1]  R263      -4.6076655387878418e-01
    z[1,0,1]  R264      -6.8318635225296021e-01
    z[1,0,1]  R265      7.7136307954788208e-02
    z[1,0,1]  R266      -3.6867281794548035e-01
    z[1,0,1]  R267      -8.0004745721817017e-01
    z[1,0,1]  R268      -5.4384297132492065e-01
    z[1,0,1]  R269      -6.3243098556995392e-02
    z[1,0,1]  R270      -8.4444028139114380e-01
    z[1,0,1]  R271      -6.6713988780975342e-01
    z[1,0,1]  R272      -1.4305049180984497e-01
    z[1,0,1]  R273      -6.0757622122764587e-02
    z[1,0,1]  R274      -1.3459648191928864e-01
    z[1,0,1]  R275      -1.4120139181613922e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R179      -1
    z[1,0,2]  R180      1
    z[1,0,2]  R189      3.3912312239408493e-02
    z[1,0,2]  R190      -2.1556296944618225e-01
    z[1,0,2]  R191      4.7245416045188904e-01
    z[1,0,2]  R192      -4.6791471540927887e-02
    z[1,0,2]  R193      8.0904394388198853e-02
    z[1,0,2]  R194      4.8915353417396545e-01
    z[1,0,2]  R195      5.3377203643321991e-02
    z[1,0,2]  R196      7.6720081269741058e-03
    z[1,0,2]  R197      2.0588225126266479e-01
    z[1,0,2]  R198      6.4833855628967285e-01
    z[1,0,2]  R199      5.4666930809617043e-03
    z[1,0,2]  R200      -4.9795752763748169e-01
    z[1,0,2]  R201      -1.0970401018857956e-01
    z[1,0,2]  R202      4.3045702576637268e-01
    z[1,0,2]  R203      -0.309946745634079
    z[1,0,2]  R204      -3.0110391974449158e-01
    z[1,0,2]  R205      -2.9382395744323730e-01
    z[1,0,2]  R206      -1.7092472314834595e-01
    z[1,0,2]  R207      -4.8073044419288635e-01
    z[1,0,2]  R208      -0.640221893787384
    z[1,0,2]  R209      -0.0763794332742691
    z[1,0,2]  R210      -2.2934117913246155e-01
    z[1,0,2]  R211      0.157013937830925
    z[1,0,2]  R212      3.5703918337821960e-01
    z[1,0,2]  R213      4.9444994330406189e-01
    z[1,0,2]  R214      -3.4975919127464294e-01
    z[1,0,2]  R215      -4.5922389626502991e-01
    z[1,0,2]  R216      8.1947362422943115e-01
    z[1,0,2]  R217      6.5707027912139893e-02
    z[1,0,2]  R218      7.1899324655532837e-01
    z[1,0,2]  R219      5.0596338510513306e-01
    z[1,0,2]  R220      7.4975913763046265e-01
    z[1,0,2]  R221      5.8152687549591064e-01
    z[1,0,2]  R222      5.9093868732452393e-01
    z[1,0,2]  R223      7.2123205661773682e-01
    z[1,0,2]  R224      0.237759068608284
    z[1,0,2]  R225      4.4213291257619858e-03
    z[1,0,2]  R226      -3.4749990701675415e-01
    z[1,0,2]  R227      1.0062158852815628e-01
    z[1,0,2]  R228      1.5836326405405998e-02
    z[1,0,2]  R229      -1.9477196037769318e-01
    z[1,0,2]  R230      -1.5739586949348450e-01
    z[1,0,2]  R231      -2.1539069712162018e-01
    z[1,0,2]  R232      -1.7674618959426880e-01
    z[1,0,2]  R233      -1.3218337297439575e-01
    z[1,0,2]  R234      -2.0232470333576202e-01
    z[1,0,2]  R235      -2.4495676159858704e-01
    z[1,0,2]  R236      -2.9079401493072510e-01
    z[1,0,2]  R237      -8.0045007169246674e-02
    z[1,0,2]  R238      -6.1496417969465256e-02
    z[1,0,2]  R239      -0.351165771484375
    z[1,0,2]  R240      3.1412267684936523e-01
    z[1,0,2]  R241      -9.4151444733142853e-02
    z[1,0,2]  R242      -1.7917390167713165e-01
    z[1,0,2]  R243      -5.0620126724243164e-01
    z[1,0,2]  R244      -5.0399070978164673e-01
    z[1,0,2]  R245      -0.363391250371933
    z[1,0,2]  R246      -0.0655822828412056
    z[1,0,2]  R247      4.0806770324707031e-01
    z[1,0,2]  R248      3.1533968448638916e-01
    z[1,0,2]  R249      3.5414081811904907e-01
    z[1,0,2]  R250      -1.3705284893512726e-01
    z[1,0,2]  R251      -2.4633088707923889e-01
    z[1,0,2]  R252      -3.4460136294364929e-01
    z[1,0,2]  R253      1.4858037233352661e-01
    z[1,0,2]  R254      -4.9796235561370850e-01
    z[1,0,2]  R255      -3.4064370393753052e-01
    z[1,0,2]  R256      -6.6855573095381260e-03
    z[1,0,2]  R257      9.8814904689788818e-02
    z[1,0,2]  R258      -2.5099816918373108e-01
    z[1,0,2]  R259      -1.6343134641647339e-01
    z[1,0,2]  R260      -1.2185386568307877e-01
    z[1,0,2]  R261      -3.2223123311996460e-01
    z[1,0,2]  R262      -2.6625648140907288e-01
    z[1,0,2]  R263      1.0322643071413040e-01
    z[1,0,2]  R264      -4.9273246526718140e-01
    z[1,0,2]  R265      1.5159864723682404e-01
    z[1,0,2]  R266      2.7118667960166931e-01
    z[1,0,2]  R267      2.5700709223747253e-01
    z[1,0,2]  R268      1.4827635884284973e-01
    z[1,0,2]  R269      -1.3728782534599304e-01
    z[1,0,2]  R270      -6.3559204339981079e-02
    z[1,0,2]  R271      -5.7696157693862915e-01
    z[1,0,2]  R272      -6.8022996187210083e-01
    z[1,0,2]  R273      -5.4369497299194336e-01
    z[1,0,2]  R274      -0.588640034198761
    z[1,0,2]  R275      -6.3312333822250366e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R181      -1
    z[1,0,3]  R182      1
    z[1,0,3]  R189      -1.6805936396121979e-01
    z[1,0,3]  R190      -4.7248509526252747e-01
    z[1,0,3]  R191      -1.1511293053627014e-01
    z[1,0,3]  R192      -7.5418412685394287e-02
    z[1,0,3]  R193      -3.5622778534889221e-01
    z[1,0,3]  R194      -4.7691002488136292e-01
    z[1,0,3]  R195      -4.3441405892372131e-01
    z[1,0,3]  R196      -1.7295217514038086e-01
    z[1,0,3]  R197      -5.0518423318862915e-01
    z[1,0,3]  R198      2.4070739746093750e-01
    z[1,0,3]  R199      6.5755927562713623e-01
    z[1,0,3]  R200      3.6037364602088928e-01
    z[1,0,3]  R201      6.9393843412399292e-01
    z[1,0,3]  R202      2.2118794918060303e-01
    z[1,0,3]  R203      5.6181758642196655e-01
    z[1,0,3]  R204      0.0750875174999237
    z[1,0,3]  R205      5.7986301183700562e-01
    z[1,0,3]  R206      6.6029745340347290e-01
    z[1,0,3]  R207      3.5390517115592957e-01
    z[1,0,3]  R208      3.8755786418914795e-01
    z[1,0,3]  R209      -2.6661860942840576e-01
    z[1,0,3]  R210      5.9386178851127625e-02
    z[1,0,3]  R211      7.5733649730682373e-01
    z[1,0,3]  R212      3.6607436835765839e-02
    z[1,0,3]  R213      5.0470304489135742e-01
    z[1,0,3]  R214      -6.7365425825119019e-01
    z[1,0,3]  R215      4.7751367092132568e-01
    z[1,0,3]  R216      8.5660547018051147e-02
    z[1,0,3]  R217      2.7198737859725952e-01
    z[1,0,3]  R218      1.6805322468280792e-01
    z[1,0,3]  R219      2.0597749948501587e-01
    z[1,0,3]  R220      -1.6725739464163780e-02
    z[1,0,3]  R221      2.5260123610496521e-01
    z[1,0,3]  R222      1.8239581584930420e-01
    z[1,0,3]  R223      1.4585982263088226e-01
    z[1,0,3]  R224      -7.8262068331241608e-02
    z[1,0,3]  R225      1.1281822808086872e-02
    z[1,0,3]  R226      7.2790971025824547e-03
    z[1,0,3]  R227      4.0342751890420914e-02
    z[1,0,3]  R228      3.6678362637758255e-02
    z[1,0,3]  R229      -5.0640669651329517e-03
    z[1,0,3]  R230      -6.6116988658905029e-02
    z[1,0,3]  R231      2.4095119908452034e-02
    z[1,0,3]  R232      0.00373685359954834
    z[1,0,3]  R233      4.3788827024400234e-03
    z[1,0,3]  R234      -9.2257685959339142e-02
    z[1,0,3]  R235      -3.5431653261184692e-02
    z[1,0,3]  R236      -3.1329861283302307e-01
    z[1,0,3]  R237      9.6256427466869354e-02
    z[1,0,3]  R238      1.3446553051471710e-01
    z[1,0,3]  R239      2.2640231251716614e-01
    z[1,0,3]  R240      9.3737974762916565e-02
    z[1,0,3]  R241      2.7037955820560455e-02
    z[1,0,3]  R242      1.2076328694820404e-01
    z[1,0,3]  R243      -3.6070051789283752e-01
    z[1,0,3]  R244      -6.0981345176696777e-01
    z[1,0,3]  R245      -5.5927598476409912e-01
    z[1,0,3]  R246      4.4853985309600830e-02
    z[1,0,3]  R247      1.1449429392814636e-01
    z[1,0,3]  R248      9.5849819481372833e-02
    z[1,0,3]  R249      1.7167614400386810e-01
    z[1,0,3]  R250      1.0390021651983261e-01
    z[1,0,3]  R251      1.6754738986492157e-02
    z[1,0,3]  R252      4.7868089750409126e-03
    z[1,0,3]  R253      9.9124103784561157e-02
    z[1,0,3]  R254      1.4544361270964146e-02
    z[1,0,3]  R255      6.7582853138446808e-02
    z[1,0,3]  R256      -8.6285084486007690e-02
    z[1,0,3]  R257      1.9811521470546722e-01
    z[1,0,3]  R258      -3.3602741360664368e-01
    z[1,0,3]  R259      -2.7378478646278381e-01
    z[1,0,3]  R260      -7.5606115162372589e-02
    z[1,0,3]  R261      -2.4072457104921341e-02
    z[1,0,3]  R262      -1.0722508281469345e-01
    z[1,0,3]  R263      3.7878003716468811e-01
    z[1,0,3]  R264      1.1484664678573608e-01
    z[1,0,3]  R265      -8.5799562931060791e-01
    z[1,0,3]  R266      3.3663338422775269e-01
    z[1,0,3]  R267      2.6797682046890259e-01
    z[1,0,3]  R268      1.3685268163681030e-01
    z[1,0,3]  R269      1.2173786759376526e-01
    z[1,0,3]  R270      3.9388176053762436e-02
    z[1,0,3]  R271      5.8200873434543610e-02
    z[1,0,3]  R272      -0.351654976606369
    z[1,0,3]  R273      -3.7919861078262329e-01
    z[1,0,3]  R274      -2.6014360785484314e-01
    z[1,0,3]  R275      -3.0291095376014709e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R183      -1
    z[1,0,4]  R184      1
    z[1,0,4]  R189      -3.5162156820297241e-01
    z[1,0,4]  R190      3.5999134182929993e-01
    z[1,0,4]  R191      1.3808570802211761e-01
    z[1,0,4]  R192      3.6242789030075073e-01
    z[1,0,4]  R193      2.3739543557167053e-01
    z[1,0,4]  R194      -1.6379849612712860e-01
    z[1,0,4]  R195      1.4983379840850830e-01
    z[1,0,4]  R196      6.0889708995819092e-01
    z[1,0,4]  R197      -2.4703058600425720e-01
    z[1,0,4]  R198      3.0834496021270752e-01
    z[1,0,4]  R199      -8.5020549595355988e-02
    z[1,0,4]  R200      1.6559921205043793e-02
    z[1,0,4]  R201      1.7816863954067230e-01
    z[1,0,4]  R202      -1.6855482757091522e-01
    z[1,0,4]  R203      -5.9320521354675293e-01
    z[1,0,4]  R204      -7.4704706668853760e-01
    z[1,0,4]  R205      -2.1361015737056732e-01
    z[1,0,4]  R206      2.6117104291915894e-01
    z[1,0,4]  R207      3.0422362685203552e-01
    z[1,0,4]  R208      9.3214645981788635e-02
    z[1,0,4]  R209      3.2586145401000977e-01
    z[1,0,4]  R210      -3.7242567539215088e-01
    z[1,0,4]  R211      -3.3418461680412292e-01
    z[1,0,4]  R212      3.9609670639038086e-01
    z[1,0,4]  R213      0.0793774202466011
    z[1,0,4]  R214      -3.2611221075057983e-01
    z[1,0,4]  R215      1.2232114374637604e-01
    z[1,0,4]  R216      1.6381217539310455e-01
    z[1,0,4]  R217      2.7178052067756653e-01
    z[1,0,4]  R218      2.5117889046669006e-01
    z[1,0,4]  R219      -3.7221035361289978e-01
    z[1,0,4]  R220      -4.3140459060668945e-01
    z[1,0,4]  R221      1.1651613563299179e-01
    z[1,0,4]  R222      -0.594077467918396
    z[1,0,4]  R223      -4.7356334328651428e-01
    z[1,0,4]  R224      -6.4592367410659790e-01
    z[1,0,4]  R225      -1.8489469587802887e-01
    z[1,0,4]  R226      -3.5218980908393860e-01
    z[1,0,4]  R227      3.1666931509971619e-01
    z[1,0,4]  R228      -8.3939999341964722e-02
    z[1,0,4]  R229      3.5732370615005493e-01
    z[1,0,4]  R230      -2.0779301226139069e-01
    z[1,0,4]  R231      -5.6297097355127335e-02
    z[1,0,4]  R232      0.0520341582596302
    z[1,0,4]  R233      4.5179638266563416e-01
    z[1,0,4]  R234      1.8847376108169556e-01
    z[1,0,4]  R235      4.7834178805351257e-01
    z[1,0,4]  R236      7.8083015978336334e-02
    z[1,0,4]  R237      6.0871785879135132e-01
    z[1,0,4]  R238      -1.9667983055114746e-02
    z[1,0,4]  R239      2.3853531479835510e-01
    z[1,0,4]  R240      -3.9662539958953857e-01
    z[1,0,4]  R241      -1.1603917926549911e-01
    z[1,0,4]  R242      5.0484424829483032e-01
    z[1,0,4]  R243      -2.9431957751512527e-02
    z[1,0,4]  R244      -1.1342797428369522e-01
    z[1,0,4]  R245      -4.3735250830650330e-02
    z[1,0,4]  R246      -4.9066543579101562e-02
    z[1,0,4]  R247      1.7202247679233551e-01
    z[1,0,4]  R248      2.0369161665439606e-01
    z[1,0,4]  R249      1.4570695161819458e-01
    z[1,0,4]  R250      0.510697066783905
    z[1,0,4]  R251      4.2817533016204834e-01
    z[1,0,4]  R252      -6.2248710542917252e-02
    z[1,0,4]  R253      -1.7212116718292236e-01
    z[1,0,4]  R254      -1.5582512319087982e-01
    z[1,0,4]  R255      -2.1015605330467224e-01
    z[1,0,4]  R256      -1.9098210334777832e-01
    z[1,0,4]  R257      5.4872775077819824e-01
    z[1,0,4]  R258      -1.6331200301647186e-01
    z[1,0,4]  R259      4.4019460678100586e-01
    z[1,0,4]  R260      -1.5691466629505157e-02
    z[1,0,4]  R261      1.5748563408851624e-01
    z[1,0,4]  R262      1.0603963583707809e-01
    z[1,0,4]  R263      2.3172182962298393e-02
    z[1,0,4]  R264      -1.8282647430896759e-01
    z[1,0,4]  R265      3.6729222536087036e-01
    z[1,0,4]  R266      3.0288836359977722e-01
    z[1,0,4]  R267      2.7664214372634888e-01
    z[1,0,4]  R268      3.7263301014900208e-01
    z[1,0,4]  R269      6.0452502965927124e-01
    z[1,0,4]  R270      -1.9241786003112793e-01
    z[1,0,4]  R271      3.1464549899101257e-01
    z[1,0,4]  R272      -6.0030579566955566e-02
    z[1,0,4]  R273      -8.0049656331539154e-02
    z[1,0,4]  R274      -6.9107718765735626e-02
    z[1,0,4]  R275      1.2726886570453644e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R185      -1
    z[1,0,5]  R186      1
    z[1,0,5]  R189      1.2961870431900024e-01
    z[1,0,5]  R190      1.6045066714286804e-01
    z[1,0,5]  R191      -3.9478784799575806e-01
    z[1,0,5]  R192      -5.4924523830413818e-01
    z[1,0,5]  R193      -5.7758718729019165e-01
    z[1,0,5]  R194      -0.53410404920578
    z[1,0,5]  R195      -4.2254528962075710e-03
    z[1,0,5]  R196      2.2024048864841461e-01
    z[1,0,5]  R197      9.7692899405956268e-02
    z[1,0,5]  R198      -1.6185204684734344e-01
    z[1,0,5]  R199      -1.6028022393584251e-02
    z[1,0,5]  R200      1.5007193386554718e-01
    z[1,0,5]  R201      4.0822145342826843e-01
    z[1,0,5]  R202      1.1324766278266907e-01
    z[1,0,5]  R203      1.0664886236190796e-01
    z[1,0,5]  R204      -6.9709710776805878e-02
    z[1,0,5]  R205      -4.0737521648406982e-01
    z[1,0,5]  R206      -7.0643156766891479e-02
    z[1,0,5]  R207      -3.6483255028724670e-01
    z[1,0,5]  R208      -5.6257039308547974e-02
    z[1,0,5]  R209      -5.9323471784591675e-01
    z[1,0,5]  R210      -1.3628005981445312e-01
    z[1,0,5]  R211      -1.2858848273754120e-01
    z[1,0,5]  R212      -4.9038168787956238e-01
    z[1,0,5]  R213      6.9194871187210083e-01
    z[1,0,5]  R214      7.1098648011684418e-02
    z[1,0,5]  R215      3.6602234840393066e-01
    z[1,0,5]  R216      -1.7492744326591492e-01
    z[1,0,5]  R217      3.2663241028785706e-01
    z[1,0,5]  R218      -1.6068068146705627e-01
    z[1,0,5]  R219      1.0876525938510895e-01
    z[1,0,5]  R220      -3.1814646720886230e-01
    z[1,0,5]  R221      2.4606071412563324e-01
    z[1,0,5]  R222      2.2672069072723389e-01
    z[1,0,5]  R223      4.3682102113962173e-02
    z[1,0,5]  R224      -2.5896748900413513e-01
    z[1,0,5]  R225      -2.4546343833208084e-02
    z[1,0,5]  R226      2.0347313582897186e-01
    z[1,0,5]  R227      4.8144187778234482e-02
    z[1,0,5]  R228      1.1396773904561996e-01
    z[1,0,5]  R229      -4.8214205889962614e-04
    z[1,0,5]  R230      -1.2855327129364014e-01
    z[1,0,5]  R231      2.3646475374698639e-01
    z[1,0,5]  R232      -1.7903022468090057e-01
    z[1,0,5]  R233      -2.6337078213691711e-01
    z[1,0,5]  R234      -1.2136088311672211e-01
    z[1,0,5]  R235      -3.8589175790548325e-02
    z[1,0,5]  R236      -5.4918748140335083e-01
    z[1,0,5]  R237      -1.4547589235007763e-02
    z[1,0,5]  R238      3.1602028012275696e-01
    z[1,0,5]  R239      0.510955274105072
    z[1,0,5]  R240      4.3707564473152161e-02
    z[1,0,5]  R241      1.1700762063264847e-01
    z[1,0,5]  R242      3.6962375044822693e-01
    z[1,0,5]  R243      4.0672972798347473e-01
    z[1,0,5]  R244      0.487321138381958
    z[1,0,5]  R245      5.1651990413665771e-01
    z[1,0,5]  R246      1.7020761966705322e-01
    z[1,0,5]  R247      -0.555191159248352
    z[1,0,5]  R248      -2.4275766313076019e-01
    z[1,0,5]  R249      2.4373291432857513e-01
    z[1,0,5]  R250      1.4232157170772552e-01
    z[1,0,5]  R251      -1.9320044666528702e-02
    z[1,0,5]  R252      0.00600613234564662
    z[1,0,5]  R253      5.5288810282945633e-02
    z[1,0,5]  R254      3.4333890676498413e-01
    z[1,0,5]  R255      -2.4083672463893890e-01
    z[1,0,5]  R256      -1.3166481256484985e-01
    z[1,0,5]  R257      3.3198451995849609e-01
    z[1,0,5]  R258      -4.2954063415527344e-01
    z[1,0,5]  R259      -5.1770615577697754e-01
    z[1,0,5]  R260      -1.2514603137969971e-01
    z[1,0,5]  R261      4.0554400533437729e-02
    z[1,0,5]  R262      -5.5437948554754257e-02
    z[1,0,5]  R263      6.7175167798995972e-01
    z[1,0,5]  R264      3.6202329397201538e-01
    z[1,0,5]  R265      2.5308024883270264e-01
    z[1,0,5]  R266      5.1114994287490845e-01
    z[1,0,5]  R267      3.5662892460823059e-01
    z[1,0,5]  R268      -7.1113187074661255e-01
    z[1,0,5]  R269      -4.1240021586418152e-01
    z[1,0,5]  R270      1.6171183437108994e-02
    z[1,0,5]  R271      3.2572954893112183e-01
    z[1,0,5]  R272      -3.2344126701354980e-01
    z[1,0,5]  R273      -3.8070490956306458e-01
    z[1,0,5]  R274      -1.5041446685791016e-01
    z[1,0,5]  R275      -2.4250821769237518e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R187      -1
    z[1,0,6]  R188      1
    z[1,0,6]  R189      -9.1330170631408691e-02
    z[1,0,6]  R190      7.2253830730915070e-02
    z[1,0,6]  R191      -1.9831590354442596e-01
    z[1,0,6]  R192      4.3240424990653992e-01
    z[1,0,6]  R193      2.7232986688613892e-01
    z[1,0,6]  R194      -1.3470865786075592e-01
    z[1,0,6]  R195      6.8807476758956909e-01
    z[1,0,6]  R196      -1.0600224882364273e-01
    z[1,0,6]  R197      2.8089359402656555e-01
    z[1,0,6]  R198      4.5494848489761353e-01
    z[1,0,6]  R199      -4.6215969324111938e-01
    z[1,0,6]  R200      -3.5357350111007690e-01
    z[1,0,6]  R201      5.3406346589326859e-02
    z[1,0,6]  R202      -6.9919317960739136e-01
    z[1,0,6]  R203      2.3312492668628693e-01
    z[1,0,6]  R204      -1.0004618018865585e-01
    z[1,0,6]  R205      -5.1352199167013168e-02
    z[1,0,6]  R206      -1.4686885476112366e-01
    z[1,0,6]  R207      -3.5163024067878723e-01
    z[1,0,6]  R208      -2.2184905409812927e-01
    z[1,0,6]  R209      -4.8895165324211121e-01
    z[1,0,6]  R210      -1.1846186965703964e-01
    z[1,0,6]  R211      -2.2051757574081421e-01
    z[1,0,6]  R212      -1.1066807806491852e-01
    z[1,0,6]  R213      0.0612468495965004
    z[1,0,6]  R214      -3.6275735497474670e-01
    z[1,0,6]  R215      -7.5998269021511078e-03
    z[1,0,6]  R216      3.1884399056434631e-01
    z[1,0,6]  R217      -2.7227851748466492e-01
    z[1,0,6]  R218      -4.9142214655876160e-01
    z[1,0,6]  R219      -5.3596991300582886e-01
    z[1,0,6]  R220      1.1703094467520714e-02
    z[1,0,6]  R221      0.0146006615832448
    z[1,0,6]  R222      3.0798447132110596e-01
    z[1,0,6]  R223      -1.1080397292971611e-02
    z[1,0,6]  R224      -3.5698670148849487e-01
    z[1,0,6]  R225      -0.593315601348877
    z[1,0,6]  R226      8.8053919374942780e-02
    z[1,0,6]  R227      1.7209558188915253e-01
    z[1,0,6]  R228      3.4361341595649719e-01
    z[1,0,6]  R229      4.1705024242401123e-01
    z[1,0,6]  R230      4.0096101164817810e-01
    z[1,0,6]  R231      0.476885586977005
    z[1,0,6]  R232      4.9733448028564453e-01
    z[1,0,6]  R233      1.1575733125209808e-01
    z[1,0,6]  R234      1.4786525070667267e-01
    z[1,0,6]  R235      6.6876187920570374e-02
    z[1,0,6]  R236      -4.0917722508311272e-03
    z[1,0,6]  R237      -0.508971631526947
    z[1,0,6]  R238      1.0664170980453491e-01
    z[1,0,6]  R239      -2.7697867155075073e-01
    z[1,0,6]  R240      -3.8562685251235962e-01
    z[1,0,6]  R241      4.6044796705245972e-01
    z[1,0,6]  R242      7.3766958713531494e-01
    z[1,0,6]  R243      -1.9449464976787567e-01
    z[1,0,6]  R244      -2.8869467787444592e-03
    z[1,0,6]  R245      2.5344389677047729e-01
    z[1,0,6]  R246      6.1942511796951294e-01
    z[1,0,6]  R247      1.3202281668782234e-02
    z[1,0,6]  R248      1.4053647220134735e-01
    z[1,0,6]  R249      9.6981525421142578e-02
    z[1,0,6]  R250      4.5962461829185486e-01
    z[1,0,6]  R251      -1.0170855373144150e-01
    z[1,0,6]  R252      4.9914318323135376e-01
    z[1,0,6]  R253      -5.4759550094604492e-01
    z[1,0,6]  R254      1.4791837334632874e-01
    z[1,0,6]  R255      -0.552911639213562
    z[1,0,6]  R256      4.3932226300239563e-01
    z[1,0,6]  R257      5.0070071220397949e-01
    z[1,0,6]  R258      4.5036903023719788e-01
    z[1,0,6]  R259      -7.9545125365257263e-02
    z[1,0,6]  R260      -2.5002273917198181e-01
    z[1,0,6]  R261      -1.1861776560544968e-01
    z[1,0,6]  R262      1.0288503021001816e-01
    z[1,0,6]  R263      -1.9306229054927826e-01
    z[1,0,6]  R264      -0.326310396194458
    z[1,0,6]  R265      -1.0381789505481720e-01
    z[1,0,6]  R266      3.8189920783042908e-01
    z[1,0,6]  R267      -8.4024742245674133e-02
    z[1,0,6]  R268      -7.6818592846393585e-02
    z[1,0,6]  R269      -3.6519506573677063e-01
    z[1,0,6]  R270      4.8459663987159729e-01
    z[1,0,6]  R271      -3.4069389104843140e-02
    z[1,0,6]  R272      -9.3032263219356537e-02
    z[1,0,6]  R273      1.1360388994216919e-01
    z[1,0,6]  R274      -6.3811009749770164e-03
    z[1,0,6]  R275      3.1372848898172379e-02
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R276      -1
    z[0,4,0]  R277      1
    z[0,4,0]  R290      1.7100869119167328e-01
    z[0,4,0]  R291      5.5702650547027588e-01
    z[0,4,0]  R292      2.7477458119392395e-01
    z[0,4,0]  R293      0.0161072239279747
    z[0,4,0]  R294      2.3288173973560333e-01
    z[0,4,0]  R295      -4.1363561153411865e-01
    z[0,4,0]  R296      6.4785279333591461e-02
    z[0,4,0]  R297      -1.8434689939022064e-01
    z[0,4,0]  R298      2.4861548840999603e-01
    z[0,4,0]  R299      -3.9969703555107117e-01
    z[0,4,0]  R300      2.2537778317928314e-01
    z[0,4,0]  R301      -1.6907557845115662e-01
    z[0,4,0]  R302      3.8456264138221741e-01
    z[0,4,0]  R303      4.2606998234987259e-02
    z[0,4,0]  R304      1.5546953678131104e-01
    z[0,4,0]  R305      1.5194568037986755e-01
    z[0,4,0]  R306      9.8743841052055359e-02
    z[0,4,0]  R307      1.5659880638122559e-01
    z[0,4,0]  R308      4.4227278232574463e-01
    z[0,4,0]  R309      2.9409646987915039e-01
    z[0,4,0]  R310      6.7874324321746826e-01
    z[0,4,0]  R311      -2.6537823677062988e-01
    z[0,4,0]  R312      -8.6096087470650673e-03
    z[0,4,0]  R313      -1.4754873514175415e-01
    z[0,4,0]  R314      -1.3693846762180328e-01
    z[0,4,0]  R315      -6.1380922794342041e-01
    z[0,4,0]  R316      1.0916613787412643e-01
    z[0,4,0]  R317      -4.5338609814643860e-01
    z[0,4,0]  R318      -2.4482056498527527e-01
    z[0,4,0]  R319      -4.1672316193580627e-01
    z[0,4,0]  R320      7.4712353944778442e-01
    z[0,4,0]  R321      -4.8969838023185730e-01
    z[0,4,0]  R322      1.5534083545207977e-01
    z[0,4,0]  R323      -6.7616707086563110e-01
    z[0,4,0]  R324      -5.5766785144805908e-01
    z[0,4,0]  R325      2.8004637360572815e-01
    z[0,4,0]  R326      -1.9828376173973083e-01
    z[0,4,0]  R327      -8.5096381604671478e-02
    z[0,4,0]  R328      -0.393048495054245
    z[0,4,0]  R329      -1.2451636791229248e-01
    z[0,4,0]  R330      8.4260833263397217e-01
    z[0,4,0]  R331      2.4188110232353210e-01
    z[0,4,0]  R332      1.1477822810411453e-01
    z[0,4,0]  R333      -1.5447893738746643e-01
    z[0,4,0]  R334      -2.0491238683462143e-02
    z[0,4,0]  R335      1.6565407812595367e-01
    z[0,4,0]  R336      -1.5606896579265594e-01
    z[0,4,0]  R337      -3.8013646006584167e-01
    z[0,4,0]  R338      7.9477488994598389e-02
    z[0,4,0]  R339      1.5868206322193146e-01
    z[0,4,0]  R340      4.2231917381286621e-01
    z[0,4,0]  R341      -1.0622905939817429e-01
    z[0,4,0]  R342      -1.1425952613353729e-01
    z[0,4,0]  R343      -5.4170143604278564e-01
    z[0,4,0]  R344      -0.0959658995270729
    z[0,4,0]  R345      -1.1131045222282410e-01
    z[0,4,0]  R346      -5.2563261985778809e-01
    z[0,4,0]  R347      -6.2662810087203979e-01
    z[0,4,0]  R348      -0.735031247138977
    z[0,4,0]  R349      -6.4145928621292114e-01
    z[0,4,0]  R350      -1.0769873857498169e-01
    z[0,4,0]  R351      4.4023630023002625e-01
    z[0,4,0]  R352      1.5612202882766724e-01
    z[0,4,0]  R353      1.0710169374942780e-01
    z[0,4,0]  R354      1.4449438452720642e-01
    z[0,4,0]  R355      3.6898839473724365e-01
    z[0,4,0]  R356      3.5365390777587891e-01
    z[0,4,0]  R357      2.2610253095626831e-01
    z[0,4,0]  R358      3.7432238459587097e-01
    z[0,4,0]  R359      4.5319777727127075e-01
    z[0,4,0]  R360      4.2977181077003479e-01
    z[0,4,0]  R361      8.7702494859695435e-01
    z[0,4,0]  R362      4.8994666337966919e-01
    z[0,4,0]  R363      7.9518508911132812e-01
    z[0,4,0]  R364      7.8260397911071777e-01
    z[0,4,0]  R365      6.9906884431838989e-01
    z[0,4,0]  R366      8.0059701204299927e-01
    z[0,4,0]  R367      7.1674311161041260e-01
    z[0,4,0]  R368      1.7772741615772247e-01
    z[0,4,0]  R369      3.0831113457679749e-01
    z[0,4,0]  R370      0.0574665404856205
    z[0,4,0]  R371      -1.6069617867469788e-01
    z[0,4,0]  R372      -1.8466311693191528e-01
    z[0,4,0]  R373      2.6367574930191040e-01
    z[0,4,0]  R374      -3.7643620371818542e-01
    z[0,4,0]  R375      -4.2276340723037720e-01
    z[0,4,0]  R376      -2.7800530195236206e-01
    z[0,4,0]  R377      -3.9284005761146545e-01
    z[0,4,0]  R378      -2.9538375139236450e-01
    z[0,4,0]  R379      -2.8193703293800354e-01
    z[0,4,0]  R380      3.2031199336051941e-01
    z[0,4,0]  R381      0.64688640832901
    z[0,4,0]  R382      4.9982777237892151e-01
    z[0,4,0]  R383      5.6988584995269775e-01
    z[0,4,0]  R384      3.5082665085792542e-01
    z[0,4,0]  R385      7.1311330795288086e-01
    z[0,4,0]  R386      6.9980710744857788e-01
    z[0,4,0]  R387      6.9062197208404541e-01
    z[0,4,0]  R388      7.6047849655151367e-01
    z[0,4,0]  R389      8.7697041034698486e-01
    z[0,4,0]  R390      4.1299268603324890e-01
    z[0,4,0]  R391      0.889885663986206
    z[0,4,0]  R392      1.6321896016597748e-01
    z[0,4,0]  R393      -2.9290360212326050e-01
    z[0,4,0]  R394      -2.1908316761255264e-02
    z[0,4,0]  R395      8.1645774841308594e-01
    z[0,4,0]  R396      -2.7878215909004211e-01
    z[0,4,0]  R397      -7.4276372790336609e-02
    z[0,4,0]  R398      -0.558233380317688
    z[0,4,0]  R399      1.1558765172958374e-01
    z[0,4,0]  R400      0.0573107935488224
    z[0,4,0]  R401      7.9961299896240234e-01
    z[0,4,0]  R402      2.4737431108951569e-01
    z[0,4,0]  R403      6.1655020713806152e-01
    z[0,4,0]  R404      1.5405617654323578e-01
    z[0,4,0]  R405      6.4512962102890015e-01
    z[0,4,0]  R406      -4.4343182444572449e-01
    z[0,4,0]  R407      3.7412993609905243e-02
    z[0,4,0]  R408      3.1464582681655884e-01
    z[0,4,0]  R409      3.0606740713119507e-01
    z[0,4,0]  R410      4.7941152006387711e-02
    z[0,4,0]  R411      2.8697720170021057e-01
    z[0,4,0]  R412      -4.5842775143682957e-03
    z[0,4,0]  R413      3.2030594348907471e-01
    z[0,4,0]  R414      3.5250097513198853e-01
    z[0,4,0]  R415      2.0658531785011292e-01
    z[0,4,0]  R416      8.9794412255287170e-02
    z[0,4,0]  R417      -8.2716733217239380e-02
    z[0,4,0]  R418      -8.0401289463043213e-01
    z[0,4,0]  R419      -4.5728474855422974e-01
    z[0,4,0]  R420      -1.7456750571727753e-01
    z[0,4,0]  R421      -5.2107536792755127e-01
    z[0,4,0]  R422      6.4120548963546753e-01
    z[0,4,0]  R423      -6.3968378305435181e-01
    z[0,4,0]  R424      -0.747021496295929
    z[0,4,0]  R425      -7.5739741325378418e-01
    z[0,4,0]  R426      -7.6824188232421875e-01
    z[0,4,0]  R427      -7.7754920721054077e-01
    z[0,4,0]  R428      -0.503307044506073
    z[0,4,0]  R429      -6.0108578205108643e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R278      -1
    z[0,4,1]  R279      1
    z[0,4,1]  R290      0.364397794008255
    z[0,4,1]  R291      0.59727543592453
    z[0,4,1]  R292      2.2113518416881561e-01
    z[0,4,1]  R293      5.1349848508834839e-01
    z[0,4,1]  R294      3.0965054035186768e-01
    z[0,4,1]  R295      5.9379267692565918e-01
    z[0,4,1]  R296      3.3784812688827515e-01
    z[0,4,1]  R297      4.4527783989906311e-01
    z[0,4,1]  R298      5.1362925767898560e-01
    z[0,4,1]  R299      -0.673263430595398
    z[0,4,1]  R300      -8.0944615602493286e-01
    z[0,4,1]  R301      -9.0964114665985107e-01
    z[0,4,1]  R302      -8.4404426813125610e-01
    z[0,4,1]  R303      -8.1154882907867432e-01
    z[0,4,1]  R304      -0.852180004119873
    z[0,4,1]  R305      -0.802143394947052
    z[0,4,1]  R306      -8.2273662090301514e-01
    z[0,4,1]  R307      -8.1920778751373291e-01
    z[0,4,1]  R308      -8.2633709907531738e-01
    z[0,4,1]  R309      -7.8579616546630859e-01
    z[0,4,1]  R310      2.2106523811817169e-01
    z[0,4,1]  R311      -5.3301107883453369e-01
    z[0,4,1]  R312      -9.3082493543624878e-01
    z[0,4,1]  R313      -0.639501690864563
    z[0,4,1]  R314      -7.5223529338836670e-01
    z[0,4,1]  R315      -0.611943244934082
    z[0,4,1]  R316      -7.5828351080417633e-02
    z[0,4,1]  R317      4.5163372159004211e-01
    z[0,4,1]  R318      2.5264132022857666e-01
    z[0,4,1]  R319      2.2036257386207581e-01
    z[0,4,1]  R320      -1.4292629063129425e-01
    z[0,4,1]  R321      -4.9250790476799011e-01
    z[0,4,1]  R322      -8.6433261632919312e-01
    z[0,4,1]  R323      -5.4577279090881348e-01
    z[0,4,1]  R324      -4.0878617763519287e-01
    z[0,4,1]  R325      -8.1643259525299072e-01
    z[0,4,1]  R326      -0.767369270324707
    z[0,4,1]  R327      -7.9266226291656494e-01
    z[0,4,1]  R328      -6.5824913978576660e-01
    z[0,4,1]  R329      -6.7528587579727173e-01
    z[0,4,1]  R330      1.8896445631980896e-01
    z[0,4,1]  R331      -4.8006501793861389e-01
    z[0,4,1]  R332      6.3000261783599854e-01
    z[0,4,1]  R333      6.3745582103729248e-01
    z[0,4,1]  R334      -9.4899761676788330e-01
    z[0,4,1]  R335      -9.0974158048629761e-01
    z[0,4,1]  R336      -9.3185275793075562e-01
    z[0,4,1]  R337      -4.6076655387878418e-01
    z[0,4,1]  R338      -6.8318635225296021e-01
    z[0,4,1]  R339      7.7136307954788208e-02
    z[0,4,1]  R340      -3.6867281794548035e-01
    z[0,4,1]  R341      -8.0004745721817017e-01
    z[0,4,1]  R342      -5.4384297132492065e-01
    z[0,4,1]  R343      -6.3243098556995392e-02
    z[0,4,1]  R344      -8.4444028139114380e-01
    z[0,4,1]  R345      -6.6713988780975342e-01
    z[0,4,1]  R346      -1.4305049180984497e-01
    z[0,4,1]  R347      -6.0757622122764587e-02
    z[0,4,1]  R348      -1.3459648191928864e-01
    z[0,4,1]  R349      -1.4120139181613922e-01
    z[0,4,1]  R350      -7.5980699062347412e-01
    z[0,4,1]  R351      5.7655000686645508e-01
    z[0,4,1]  R352      3.6562508344650269e-01
    z[0,4,1]  R353      5.0436949729919434e-01
    z[0,4,1]  R354      3.5136339068412781e-01
    z[0,4,1]  R355      3.3590036630630493e-01
    z[0,4,1]  R356      3.6449325084686279e-01
    z[0,4,1]  R357      2.8012299537658691e-01
    z[0,4,1]  R358      3.7272053956985474e-01
    z[0,4,1]  R359      -8.8489063084125519e-02
    z[0,4,1]  R360      3.6328908801078796e-01
    z[0,4,1]  R361      -2.6171383261680603e-01
    z[0,4,1]  R362      1.7946556210517883e-01
    z[0,4,1]  R363      -1.1190539598464966e-01
    z[0,4,1]  R364      -2.1723881363868713e-03
    z[0,4,1]  R365      2.4210011959075928e-01
    z[0,4,1]  R366      -4.1312709450721741e-01
    z[0,4,1]  R367      2.6052770018577576e-01
    z[0,4,1]  R368      -7.6499587297439575e-01
    z[0,4,1]  R369      -8.0215257406234741e-01
    z[0,4,1]  R370      -6.0057377815246582e-01
    z[0,4,1]  R371      -6.4692658185958862e-01
    z[0,4,1]  R372      9.0139198303222656e-01
    z[0,4,1]  R373      -5.3246569633483887e-01
    z[0,4,1]  R374      -6.7894893884658813e-01
    z[0,4,1]  R375      8.1930369138717651e-01
    z[0,4,1]  R376      7.5480204820632935e-01
    z[0,4,1]  R377      -5.7989561557769775e-01
    z[0,4,1]  R378      7.5166279077529907e-01
    z[0,4,1]  R379      7.2597855329513550e-01
    z[0,4,1]  R380      -0.900971531867981
    z[0,4,1]  R381      3.5553914308547974e-01
    z[0,4,1]  R382      3.0239078402519226e-01
    z[0,4,1]  R383      7.8953355550765991e-01
    z[0,4,1]  R384      1.0615737736225128e-01
    z[0,4,1]  R385      -0.314377099275589
    z[0,4,1]  R386      -1.5062569081783295e-01
    z[0,4,1]  R387      -1.0727320611476898e-01
    z[0,4,1]  R388      -3.8941238075494766e-02
    z[0,4,1]  R389      0.0747273862361908
    z[0,4,1]  R390      6.7456549406051636e-01
    z[0,4,1]  R391      4.9455105327069759e-03
    z[0,4,1]  R392      -4.4741186499595642e-01
    z[0,4,1]  R393      -4.7400176525115967e-01
    z[0,4,1]  R394      6.2695342302322388e-01
    z[0,4,1]  R395      -1.0745301097631454e-01
    z[0,4,1]  R396      -8.1280374526977539e-01
    z[0,4,1]  R397      -7.5216662883758545e-01
    z[0,4,1]  R398      -7.0853632688522339e-01
    z[0,4,1]  R399      -7.3085999488830566e-01
    z[0,4,1]  R400      -1.8043406307697296e-02
    z[0,4,1]  R401      9.9392943084239960e-02
    z[0,4,1]  R402      -6.2044060230255127e-01
    z[0,4,1]  R403      1.7024628818035126e-01
    z[0,4,1]  R404      -3.3160951733589172e-01
    z[0,4,1]  R405      -6.8393266201019287e-01
    z[0,4,1]  R406      -8.8236892223358154e-01
    z[0,4,1]  R407      -8.0494534969329834e-01
    z[0,4,1]  R408      -7.3241299390792847e-01
    z[0,4,1]  R409      -7.4001210927963257e-01
    z[0,4,1]  R410      8.2478791475296021e-01
    z[0,4,1]  R411      -5.0706952810287476e-01
    z[0,4,1]  R412      -8.8635720312595367e-02
    z[0,4,1]  R413      -5.9026145935058594e-01
    z[0,4,1]  R414      -4.6090030670166016e-01
    z[0,4,1]  R415      -8.1325441598892212e-01
    z[0,4,1]  R416      -8.2056128978729248e-01
    z[0,4,1]  R417      -7.8597873449325562e-01
    z[0,4,1]  R418      -0.0318484753370285
    z[0,4,1]  R419      -3.4133437275886536e-01
    z[0,4,1]  R420      -4.9273166060447693e-01
    z[0,4,1]  R421      6.4521151781082153e-01
    z[0,4,1]  R422      -1.0454971343278885e-01
    z[0,4,1]  R423      2.5759446620941162e-01
    z[0,4,1]  R424      -1.0024883598089218e-01
    z[0,4,1]  R425      6.7785056307911873e-03
    z[0,4,1]  R426      8.4484659135341644e-02
    z[0,4,1]  R427      -4.8546131700277328e-02
    z[0,4,1]  R428      1.1268686503171921e-01
    z[0,4,1]  R429      -0.0511755645275116
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R280      -1
    z[0,4,2]  R281      1
    z[0,4,2]  R290      8.1947362422943115e-01
    z[0,4,2]  R291      6.5707027912139893e-02
    z[0,4,2]  R292      7.1899324655532837e-01
    z[0,4,2]  R293      5.0596338510513306e-01
    z[0,4,2]  R294      7.4975913763046265e-01
    z[0,4,2]  R295      5.8152687549591064e-01
    z[0,4,2]  R296      5.9093868732452393e-01
    z[0,4,2]  R297      7.2123205661773682e-01
    z[0,4,2]  R298      0.237759068608284
    z[0,4,2]  R299      4.4213291257619858e-03
    z[0,4,2]  R300      -3.4749990701675415e-01
    z[0,4,2]  R301      1.0062158852815628e-01
    z[0,4,2]  R302      1.5836326405405998e-02
    z[0,4,2]  R303      -1.9477196037769318e-01
    z[0,4,2]  R304      -1.5739586949348450e-01
    z[0,4,2]  R305      -2.1539069712162018e-01
    z[0,4,2]  R306      -1.7674618959426880e-01
    z[0,4,2]  R307      -1.3218337297439575e-01
    z[0,4,2]  R308      -2.0232470333576202e-01
    z[0,4,2]  R309      -2.4495676159858704e-01
    z[0,4,2]  R310      -2.9079401493072510e-01
    z[0,4,2]  R311      -8.0045007169246674e-02
    z[0,4,2]  R312      -6.1496417969465256e-02
    z[0,4,2]  R313      -0.351165771484375
    z[0,4,2]  R314      3.1412267684936523e-01
    z[0,4,2]  R315      -9.4151444733142853e-02
    z[0,4,2]  R316      -1.7917390167713165e-01
    z[0,4,2]  R317      -5.0620126724243164e-01
    z[0,4,2]  R318      -5.0399070978164673e-01
    z[0,4,2]  R319      -0.363391250371933
    z[0,4,2]  R320      -0.0655822828412056
    z[0,4,2]  R321      4.0806770324707031e-01
    z[0,4,2]  R322      3.1533968448638916e-01
    z[0,4,2]  R323      3.5414081811904907e-01
    z[0,4,2]  R324      -1.3705284893512726e-01
    z[0,4,2]  R325      -2.4633088707923889e-01
    z[0,4,2]  R326      -3.4460136294364929e-01
    z[0,4,2]  R327      1.4858037233352661e-01
    z[0,4,2]  R328      -4.9796235561370850e-01
    z[0,4,2]  R329      -3.4064370393753052e-01
    z[0,4,2]  R330      -6.6855573095381260e-03
    z[0,4,2]  R331      9.8814904689788818e-02
    z[0,4,2]  R332      -2.5099816918373108e-01
    z[0,4,2]  R333      -1.6343134641647339e-01
    z[0,4,2]  R334      -1.2185386568307877e-01
    z[0,4,2]  R335      -3.2223123311996460e-01
    z[0,4,2]  R336      -2.6625648140907288e-01
    z[0,4,2]  R337      1.0322643071413040e-01
    z[0,4,2]  R338      -4.9273246526718140e-01
    z[0,4,2]  R339      1.5159864723682404e-01
    z[0,4,2]  R340      2.7118667960166931e-01
    z[0,4,2]  R341      2.5700709223747253e-01
    z[0,4,2]  R342      1.4827635884284973e-01
    z[0,4,2]  R343      -1.3728782534599304e-01
    z[0,4,2]  R344      -6.3559204339981079e-02
    z[0,4,2]  R345      -5.7696157693862915e-01
    z[0,4,2]  R346      -6.8022996187210083e-01
    z[0,4,2]  R347      -5.4369497299194336e-01
    z[0,4,2]  R348      -0.588640034198761
    z[0,4,2]  R349      -6.3312333822250366e-01
    z[0,4,2]  R350      4.2846021056175232e-01
    z[0,4,2]  R351      4.7197285294532776e-01
    z[0,4,2]  R352      8.7361693382263184e-01
    z[0,4,2]  R353      7.1127218008041382e-01
    z[0,4,2]  R354      8.0955666303634644e-01
    z[0,4,2]  R355      5.6911766529083252e-01
    z[0,4,2]  R356      4.0934070944786072e-01
    z[0,4,2]  R357      7.1070623397827148e-01
    z[0,4,2]  R358      5.7346224784851074e-01
    z[0,4,2]  R359      7.3634207248687744e-01
    z[0,4,2]  R360      1.9641520082950592e-01
    z[0,4,2]  R361      -1.2724100053310394e-01
    z[0,4,2]  R362      0.371624618768692
    z[0,4,2]  R363      -9.8497465252876282e-02
    z[0,4,2]  R364      -4.4014319777488708e-02
    z[0,4,2]  R365      -7.1682795882225037e-02
    z[0,4,2]  R366      -1.1576101183891296e-01
    z[0,4,2]  R367      -1.6678930819034576e-01
    z[0,4,2]  R368      -3.3565798401832581e-01
    z[0,4,2]  R369      -1.0911931097507477e-01
    z[0,4,2]  R370      -9.6833752468228340e-03
    z[0,4,2]  R371      -5.0400024652481079e-01
    z[0,4,2]  R372      -2.5089514255523682e-01
    z[0,4,2]  R373      -5.4853504896163940e-01
    z[0,4,2]  R374      -1.8029215931892395e-01
    z[0,4,2]  R375      -1.6667243838310242e-01
    z[0,4,2]  R376      -4.2241996526718140e-01
    z[0,4,2]  R377      -3.4912031888961792e-01
    z[0,4,2]  R378      -3.4621769189834595e-01
    z[0,4,2]  R379      -3.2184126973152161e-01
    z[0,4,2]  R380      -1.1219297349452972e-01
    z[0,4,2]  R381      5.5161285400390625e-01
    z[0,4,2]  R382      4.4495663046836853e-01
    z[0,4,2]  R383      0.0851961150765419
    z[0,4,2]  R384      8.0610948801040649e-01
    z[0,4,2]  R385      5.7804727554321289e-01
    z[0,4,2]  R386      3.2496452331542969e-02
    z[0,4,2]  R387      -4.9097468145191669e-03
    z[0,4,2]  R388      -1.1313035339117050e-01
    z[0,4,2]  R389      -2.0541571080684662e-01
    z[0,4,2]  R390      2.0228993892669678e-01
    z[0,4,2]  R391      0.352448970079422
    z[0,4,2]  R392      1.8935729563236237e-01
    z[0,4,2]  R393      0.316108375787735
    z[0,4,2]  R394      2.9753330349922180e-01
    z[0,4,2]  R395      1.9822779297828674e-01
    z[0,4,2]  R396      5.1628995686769485e-02
    z[0,4,2]  R397      -4.0192636847496033e-01
    z[0,4,2]  R398      -4.1487923264503479e-01
    z[0,4,2]  R399      -3.2615345716476440e-01
    z[0,4,2]  R400      4.5415255427360535e-01
    z[0,4,2]  R401      2.1178849041461945e-01
    z[0,4,2]  R402      3.1848031282424927e-01
    z[0,4,2]  R403      2.0725689828395844e-01
    z[0,4,2]  R404      -2.5462964177131653e-01
    z[0,4,2]  R405      9.5716238021850586e-02
    z[0,4,2]  R406      -1.0808206349611282e-01
    z[0,4,2]  R407      -2.2758223116397858e-01
    z[0,4,2]  R408      -3.3036249876022339e-01
    z[0,4,2]  R409      -4.9515508115291595e-02
    z[0,4,2]  R410      3.7481376528739929e-01
    z[0,4,2]  R411      8.0753460526466370e-02
    z[0,4,2]  R412      5.3348565101623535e-01
    z[0,4,2]  R413      4.6799808740615845e-01
    z[0,4,2]  R414      -3.8040125370025635e-01
    z[0,4,2]  R415      -2.5340586900711060e-01
    z[0,4,2]  R416      -3.2903066277503967e-01
    z[0,4,2]  R417      -4.6661749482154846e-01
    z[0,4,2]  R418      1.2670126557350159e-01
    z[0,4,2]  R419      -9.6945315599441528e-02
    z[0,4,2]  R420      6.2912482023239136e-01
    z[0,4,2]  R421      4.5185607671737671e-01
    z[0,4,2]  R422      6.8789505958557129e-01
    z[0,4,2]  R423      4.1986843943595886e-01
    z[0,4,2]  R424      -5.8373087644577026e-01
    z[0,4,2]  R425      -5.1679015159606934e-01
    z[0,4,2]  R426      -0.415141761302948
    z[0,4,2]  R427      -3.8516268134117126e-01
    z[0,4,2]  R428      -1.2402106076478958e-01
    z[0,4,2]  R429      -5.1551944017410278e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R282      -1
    z[0,4,3]  R283      1
    z[0,4,3]  R290      8.5660547018051147e-02
    z[0,4,3]  R291      2.7198737859725952e-01
    z[0,4,3]  R292      1.6805322468280792e-01
    z[0,4,3]  R293      2.0597749948501587e-01
    z[0,4,3]  R294      -1.6725739464163780e-02
    z[0,4,3]  R295      2.5260123610496521e-01
    z[0,4,3]  R296      1.8239581584930420e-01
    z[0,4,3]  R297      1.4585982263088226e-01
    z[0,4,3]  R298      -7.8262068331241608e-02
    z[0,4,3]  R299      1.1281822808086872e-02
    z[0,4,3]  R300      7.2790971025824547e-03
    z[0,4,3]  R301      4.0342751890420914e-02
    z[0,4,3]  R302      3.6678362637758255e-02
    z[0,4,3]  R303      -5.0640669651329517e-03
    z[0,4,3]  R304      -6.6116988658905029e-02
    z[0,4,3]  R305      2.4095119908452034e-02
    z[0,4,3]  R306      0.00373685359954834
    z[0,4,3]  R307      4.3788827024400234e-03
    z[0,4,3]  R308      -9.2257685959339142e-02
    z[0,4,3]  R309      -3.5431653261184692e-02
    z[0,4,3]  R310      -3.1329861283302307e-01
    z[0,4,3]  R311      9.6256427466869354e-02
    z[0,4,3]  R312      1.3446553051471710e-01
    z[0,4,3]  R313      2.2640231251716614e-01
    z[0,4,3]  R314      9.3737974762916565e-02
    z[0,4,3]  R315      2.7037955820560455e-02
    z[0,4,3]  R316      1.2076328694820404e-01
    z[0,4,3]  R317      -3.6070051789283752e-01
    z[0,4,3]  R318      -6.0981345176696777e-01
    z[0,4,3]  R319      -5.5927598476409912e-01
    z[0,4,3]  R320      4.4853985309600830e-02
    z[0,4,3]  R321      1.1449429392814636e-01
    z[0,4,3]  R322      9.5849819481372833e-02
    z[0,4,3]  R323      1.7167614400386810e-01
    z[0,4,3]  R324      1.0390021651983261e-01
    z[0,4,3]  R325      1.6754738986492157e-02
    z[0,4,3]  R326      4.7868089750409126e-03
    z[0,4,3]  R327      9.9124103784561157e-02
    z[0,4,3]  R328      1.4544361270964146e-02
    z[0,4,3]  R329      6.7582853138446808e-02
    z[0,4,3]  R330      -8.6285084486007690e-02
    z[0,4,3]  R331      1.9811521470546722e-01
    z[0,4,3]  R332      -3.3602741360664368e-01
    z[0,4,3]  R333      -2.7378478646278381e-01
    z[0,4,3]  R334      -7.5606115162372589e-02
    z[0,4,3]  R335      -2.4072457104921341e-02
    z[0,4,3]  R336      -1.0722508281469345e-01
    z[0,4,3]  R337      3.7878003716468811e-01
    z[0,4,3]  R338      1.1484664678573608e-01
    z[0,4,3]  R339      -8.5799562931060791e-01
    z[0,4,3]  R340      3.3663338422775269e-01
    z[0,4,3]  R341      2.6797682046890259e-01
    z[0,4,3]  R342      1.3685268163681030e-01
    z[0,4,3]  R343      1.2173786759376526e-01
    z[0,4,3]  R344      3.9388176053762436e-02
    z[0,4,3]  R345      5.8200873434543610e-02
    z[0,4,3]  R346      -0.351654976606369
    z[0,4,3]  R347      -3.7919861078262329e-01
    z[0,4,3]  R348      -2.6014360785484314e-01
    z[0,4,3]  R349      -3.0291095376014709e-01
    z[0,4,3]  R350      -1.1365080624818802e-01
    z[0,4,3]  R351      -2.6653057336807251e-01
    z[0,4,3]  R352      -1.6158398240804672e-02
    z[0,4,3]  R353      8.7386779487133026e-02
    z[0,4,3]  R354      -2.4195969104766846e-01
    z[0,4,3]  R355      -5.4229967296123505e-02
    z[0,4,3]  R356      -2.1973271667957306e-01
    z[0,4,3]  R357      -2.1441173553466797e-01
    z[0,4,3]  R358      -4.2974729090929031e-02
    z[0,4,3]  R359      6.2710449099540710e-02
    z[0,4,3]  R360      1.4789845049381256e-01
    z[0,4,3]  R361      0.0894770473241806
    z[0,4,3]  R362      3.9945179224014282e-01
    z[0,4,3]  R363      8.7021932005882263e-02
    z[0,4,3]  R364      2.2188428044319153e-01
    z[0,4,3]  R365      5.1621246337890625e-01
    z[0,4,3]  R366      -2.7530366182327271e-01
    z[0,4,3]  R367      1.9655907154083252e-01
    z[0,4,3]  R368      1.9867390394210815e-01
    z[0,4,3]  R369      3.1789278984069824e-01
    z[0,4,3]  R370      -4.6466785669326782e-01
    z[0,4,3]  R371      5.3142286837100983e-02
    z[0,4,3]  R372      -1.5477515757083893e-01
    z[0,4,3]  R373      1.5464648604393005e-01
    z[0,4,3]  R374      8.9399078860878944e-03
    z[0,4,3]  R375      -2.6493254303932190e-01
    z[0,4,3]  R376      -2.5016868114471436e-01
    z[0,4,3]  R377      3.1325221061706543e-01
    z[0,4,3]  R378      5.5311530828475952e-02
    z[0,4,3]  R379      -3.7594158202409744e-02
    z[0,4,3]  R380      -2.2050699591636658e-01
    z[0,4,3]  R381      2.3014302551746368e-01
    z[0,4,3]  R382      3.7489798665046692e-01
    z[0,4,3]  R383      1.4491407573223114e-01
    z[0,4,3]  R384      -1.3750021345913410e-02
    z[0,4,3]  R385      2.0133394747972488e-02
    z[0,4,3]  R386      -3.9063658565282822e-02
    z[0,4,3]  R387      3.6451440304517746e-02
    z[0,4,3]  R388      2.4458234012126923e-01
    z[0,4,3]  R389      2.4195723235607147e-01
    z[0,4,3]  R390      1.6079044342041016e-01
    z[0,4,3]  R391      -2.1304486691951752e-01
    z[0,4,3]  R392      5.1672559976577759e-01
    z[0,4,3]  R393      1.3092531263828278e-01
    z[0,4,3]  R394      6.0761805623769760e-02
    z[0,4,3]  R395      -1.6981713473796844e-02
    z[0,4,3]  R396      8.4242507815361023e-02
    z[0,4,3]  R397      -4.7782354056835175e-02
    z[0,4,3]  R398      -3.9128664880990982e-02
    z[0,4,3]  R399      2.5848546624183655e-01
    z[0,4,3]  R400      0.193464457988739
    z[0,4,3]  R401      -5.1578204147517681e-03
    z[0,4,3]  R402      -2.1298509091138840e-02
    z[0,4,3]  R403      3.7492990493774414e-01
    z[0,4,3]  R404      4.2187440395355225e-01
    z[0,4,3]  R405      2.2648863494396210e-01
    z[0,4,3]  R406      -1.3462702045217156e-03
    z[0,4,3]  R407      1.5759870409965515e-01
    z[0,4,3]  R408      3.5399022698402405e-01
    z[0,4,3]  R409      2.3068022727966309e-01
    z[0,4,3]  R410      -1.2059453874826431e-01
    z[0,4,3]  R411      4.1977667808532715e-01
    z[0,4,3]  R412      1.2259480357170105e-01
    z[0,4,3]  R413      -1.3393211364746094e-01
    z[0,4,3]  R414      1.0628718882799149e-01
    z[0,4,3]  R415      3.2748955488204956e-01
    z[0,4,3]  R416      1.0601244121789932e-01
    z[0,4,3]  R417      -4.3967794626951218e-02
    z[0,4,3]  R418      8.8841117918491364e-02
    z[0,4,3]  R419      3.3085581660270691e-01
    z[0,4,3]  R420      2.6332038640975952e-01
    z[0,4,3]  R421      1.8129470944404602e-01
    z[0,4,3]  R422      1.5514270961284637e-01
    z[0,4,3]  R423      1.6484937071800232e-01
    z[0,4,3]  R424      -1.1773931980133057e-01
    z[0,4,3]  R425      -2.8462055325508118e-01
    z[0,4,3]  R426      -2.1530902385711670e-01
    z[0,4,3]  R427      -3.1624028086662292e-01
    z[0,4,3]  R428      6.2884055078029633e-02
    z[0,4,3]  R429      -2.1473422646522522e-02
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R284      -1
    z[0,4,4]  R285      1
    z[0,4,4]  R290      1.6381217539310455e-01
    z[0,4,4]  R291      2.7178052067756653e-01
    z[0,4,4]  R292      2.5117889046669006e-01
    z[0,4,4]  R293      -3.7221035361289978e-01
    z[0,4,4]  R294      -4.3140459060668945e-01
    z[0,4,4]  R295      1.1651613563299179e-01
    z[0,4,4]  R296      -0.594077467918396
    z[0,4,4]  R297      -4.7356334328651428e-01
    z[0,4,4]  R298      -6.4592367410659790e-01
    z[0,4,4]  R299      -1.8489469587802887e-01
    z[0,4,4]  R300      -3.5218980908393860e-01
    z[0,4,4]  R301      3.1666931509971619e-01
    z[0,4,4]  R302      -8.3939999341964722e-02
    z[0,4,4]  R303      3.5732370615005493e-01
    z[0,4,4]  R304      -2.0779301226139069e-01
    z[0,4,4]  R305      -5.6297097355127335e-02
    z[0,4,4]  R306      0.0520341582596302
    z[0,4,4]  R307      4.5179638266563416e-01
    z[0,4,4]  R308      1.8847376108169556e-01
    z[0,4,4]  R309      4.7834178805351257e-01
    z[0,4,4]  R310      7.8083015978336334e-02
    z[0,4,4]  R311      6.0871785879135132e-01
    z[0,4,4]  R312      -1.9667983055114746e-02
    z[0,4,4]  R313      2.3853531479835510e-01
    z[0,4,4]  R314      -3.9662539958953857e-01
    z[0,4,4]  R315      -1.1603917926549911e-01
    z[0,4,4]  R316      5.0484424829483032e-01
    z[0,4,4]  R317      -2.9431957751512527e-02
    z[0,4,4]  R318      -1.1342797428369522e-01
    z[0,4,4]  R319      -4.3735250830650330e-02
    z[0,4,4]  R320      -4.9066543579101562e-02
    z[0,4,4]  R321      1.7202247679233551e-01
    z[0,4,4]  R322      2.0369161665439606e-01
    z[0,4,4]  R323      1.4570695161819458e-01
    z[0,4,4]  R324      0.510697066783905
    z[0,4,4]  R325      4.2817533016204834e-01
    z[0,4,4]  R326      -6.2248710542917252e-02
    z[0,4,4]  R327      -1.7212116718292236e-01
    z[0,4,4]  R328      -1.5582512319087982e-01
    z[0,4,4]  R329      -2.1015605330467224e-01
    z[0,4,4]  R330      -1.9098210334777832e-01
    z[0,4,4]  R331      5.4872775077819824e-01
    z[0,4,4]  R332      -1.6331200301647186e-01
    z[0,4,4]  R333      4.4019460678100586e-01
    z[0,4,4]  R334      -1.5691466629505157e-02
    z[0,4,4]  R335      1.5748563408851624e-01
    z[0,4,4]  R336      1.0603963583707809e-01
    z[0,4,4]  R337      2.3172182962298393e-02
    z[0,4,4]  R338      -1.8282647430896759e-01
    z[0,4,4]  R339      3.6729222536087036e-01
    z[0,4,4]  R340      3.0288836359977722e-01
    z[0,4,4]  R341      2.7664214372634888e-01
    z[0,4,4]  R342      3.7263301014900208e-01
    z[0,4,4]  R343      6.0452502965927124e-01
    z[0,4,4]  R344      -1.9241786003112793e-01
    z[0,4,4]  R345      3.1464549899101257e-01
    z[0,4,4]  R346      -6.0030579566955566e-02
    z[0,4,4]  R347      -8.0049656331539154e-02
    z[0,4,4]  R348      -6.9107718765735626e-02
    z[0,4,4]  R349      1.2726886570453644e-01
    z[0,4,4]  R350      -8.0058827996253967e-02
    z[0,4,4]  R351      -3.2889395952224731e-01
    z[0,4,4]  R352      1.6888274252414703e-01
    z[0,4,4]  R353      3.0916187912225723e-02
    z[0,4,4]  R354      6.0891564935445786e-02
    z[0,4,4]  R355      -7.6807349920272827e-02
    z[0,4,4]  R356      2.4496786296367645e-01
    z[0,4,4]  R357      -2.2143848240375519e-01
    z[0,4,4]  R358      -4.8559615015983582e-01
    z[0,4,4]  R359      1.0496097803115845e-01
    z[0,4,4]  R360      4.4029909372329712e-01
    z[0,4,4]  R361      2.6183375716209412e-01
    z[0,4,4]  R362      4.5810022950172424e-01
    z[0,4,4]  R363      2.1041291952133179e-01
    z[0,4,4]  R364      3.3806860446929932e-01
    z[0,4,4]  R365      3.3798319101333618e-01
    z[0,4,4]  R366      -1.4776277542114258e-01
    z[0,4,4]  R367      3.2203400135040283e-01
    z[0,4,4]  R368      2.7713969349861145e-01
    z[0,4,4]  R369      3.3040383458137512e-01
    z[0,4,4]  R370      0.390125036239624
    z[0,4,4]  R371      -2.9339954257011414e-01
    z[0,4,4]  R372      1.7583616077899933e-02
    z[0,4,4]  R373      -3.6412519216537476e-01
    z[0,4,4]  R374      -3.0620199441909790e-01
    z[0,4,4]  R375      2.9648987576365471e-02
    z[0,4,4]  R376      -1.4477708935737610e-01
    z[0,4,4]  R377      1.4104658365249634e-01
    z[0,4,4]  R378      4.3017297983169556e-01
    z[0,4,4]  R379      -4.6514311432838440e-01
    z[0,4,4]  R380      -6.4739942550659180e-02
    z[0,4,4]  R381      2.5175625085830688e-01
    z[0,4,4]  R382      7.0959888398647308e-02
    z[0,4,4]  R383      1.3857199251651764e-01
    z[0,4,4]  R384      4.2542789131402969e-02
    z[0,4,4]  R385      1.5082585811614990e-01
    z[0,4,4]  R386      -2.6541644334793091e-01
    z[0,4,4]  R387      -6.5167438983917236e-01
    z[0,4,4]  R388      -2.3809868097305298e-01
    z[0,4,4]  R389      -0.270989328622818
    z[0,4,4]  R390      -1.4751519262790680e-01
    z[0,4,4]  R391      -1.9519133493304253e-02
    z[0,4,4]  R392      6.2137889862060547e-01
    z[0,4,4]  R393      0.0629318356513977
    z[0,4,4]  R394      7.0032423734664917e-01
    z[0,4,4]  R395      -2.3135535418987274e-01
    z[0,4,4]  R396      4.7309298068284988e-02
    z[0,4,4]  R397      -5.1250267028808594e-01
    z[0,4,4]  R398      -4.1086863726377487e-02
    z[0,4,4]  R399      -3.5745996236801147e-01
    z[0,4,4]  R400      5.9184902906417847e-01
    z[0,4,4]  R401      -5.3945183753967285e-01
    z[0,4,4]  R402      2.9631805419921875e-01
    z[0,4,4]  R403      5.0382214784622192e-01
    z[0,4,4]  R404      0.403598815202713
    z[0,4,4]  R405      -3.8055527955293655e-02
    z[0,4,4]  R406      -6.3370861113071442e-02
    z[0,4,4]  R407      -2.5565892457962036e-01
    z[0,4,4]  R408      -1.9228948652744293e-01
    z[0,4,4]  R409      -4.3697637319564819e-01
    z[0,4,4]  R410      -1.7640747129917145e-01
    z[0,4,4]  R411      4.3317991495132446e-01
    z[0,4,4]  R412      2.0805180072784424e-01
    z[0,4,4]  R413      -3.6709362268447876e-01
    z[0,4,4]  R414      -6.5922670066356659e-02
    z[0,4,4]  R415      -1.8420684337615967e-01
    z[0,4,4]  R416      -1.3740763068199158e-01
    z[0,4,4]  R417      -3.3324441313743591e-01
    z[0,4,4]  R418      2.2193701565265656e-01
    z[0,4,4]  R419      4.1295105218887329e-01
    z[0,4,4]  R420      3.7466433644294739e-01
    z[0,4,4]  R421      2.1136064827442169e-01
    z[0,4,4]  R422      -1.1301765590906143e-01
    z[0,4,4]  R423      -7.4604131281375885e-02
    z[0,4,4]  R424      -1.2201914936304092e-01
    z[0,4,4]  R425      -2.5154781341552734e-01
    z[0,4,4]  R426      2.3446790874004364e-02
    z[0,4,4]  R427      -4.3253622949123383e-02
    z[0,4,4]  R428      -7.5459247827529907e-01
    z[0,4,4]  R429      -2.3766717314720154e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R286      -1
    z[0,4,5]  R287      1
    z[0,4,5]  R290      -1.7492744326591492e-01
    z[0,4,5]  R291      3.2663241028785706e-01
    z[0,4,5]  R292      -1.6068068146705627e-01
    z[0,4,5]  R293      1.0876525938510895e-01
    z[0,4,5]  R294      -3.1814646720886230e-01
    z[0,4,5]  R295      2.4606071412563324e-01
    z[0,4,5]  R296      2.2672069072723389e-01
    z[0,4,5]  R297      4.3682102113962173e-02
    z[0,4,5]  R298      -2.5896748900413513e-01
    z[0,4,5]  R299      -2.4546343833208084e-02
    z[0,4,5]  R300      2.0347313582897186e-01
    z[0,4,5]  R301      4.8144187778234482e-02
    z[0,4,5]  R302      1.1396773904561996e-01
    z[0,4,5]  R303      -4.8214205889962614e-04
    z[0,4,5]  R304      -1.2855327129364014e-01
    z[0,4,5]  R305      2.3646475374698639e-01
    z[0,4,5]  R306      -1.7903022468090057e-01
    z[0,4,5]  R307      -2.6337078213691711e-01
    z[0,4,5]  R308      -1.2136088311672211e-01
    z[0,4,5]  R309      -3.8589175790548325e-02
    z[0,4,5]  R310      -5.4918748140335083e-01
    z[0,4,5]  R311      -1.4547589235007763e-02
    z[0,4,5]  R312      3.1602028012275696e-01
    z[0,4,5]  R313      0.510955274105072
    z[0,4,5]  R314      4.3707564473152161e-02
    z[0,4,5]  R315      1.1700762063264847e-01
    z[0,4,5]  R316      3.6962375044822693e-01
    z[0,4,5]  R317      4.0672972798347473e-01
    z[0,4,5]  R318      0.487321138381958
    z[0,4,5]  R319      5.1651990413665771e-01
    z[0,4,5]  R320      1.7020761966705322e-01
    z[0,4,5]  R321      -0.555191159248352
    z[0,4,5]  R322      -2.4275766313076019e-01
    z[0,4,5]  R323      2.4373291432857513e-01
    z[0,4,5]  R324      1.4232157170772552e-01
    z[0,4,5]  R325      -1.9320044666528702e-02
    z[0,4,5]  R326      0.00600613234564662
    z[0,4,5]  R327      5.5288810282945633e-02
    z[0,4,5]  R328      3.4333890676498413e-01
    z[0,4,5]  R329      -2.4083672463893890e-01
    z[0,4,5]  R330      -1.3166481256484985e-01
    z[0,4,5]  R331      3.3198451995849609e-01
    z[0,4,5]  R332      -4.2954063415527344e-01
    z[0,4,5]  R333      -5.1770615577697754e-01
    z[0,4,5]  R334      -1.2514603137969971e-01
    z[0,4,5]  R335      4.0554400533437729e-02
    z[0,4,5]  R336      -5.5437948554754257e-02
    z[0,4,5]  R337      6.7175167798995972e-01
    z[0,4,5]  R338      3.6202329397201538e-01
    z[0,4,5]  R339      2.5308024883270264e-01
    z[0,4,5]  R340      5.1114994287490845e-01
    z[0,4,5]  R341      3.5662892460823059e-01
    z[0,4,5]  R342      -7.1113187074661255e-01
    z[0,4,5]  R343      -4.1240021586418152e-01
    z[0,4,5]  R344      1.6171183437108994e-02
    z[0,4,5]  R345      3.2572954893112183e-01
    z[0,4,5]  R346      -3.2344126701354980e-01
    z[0,4,5]  R347      -3.8070490956306458e-01
    z[0,4,5]  R348      -1.5041446685791016e-01
    z[0,4,5]  R349      -2.4250821769237518e-01
    z[0,4,5]  R350      4.3996194005012512e-01
    z[0,4,5]  R351      1.3638377189636230e-01
    z[0,4,5]  R352      1.2953966856002808e-01
    z[0,4,5]  R353      -2.9613199830055237e-01
    z[0,4,5]  R354      3.4899991750717163e-01
    z[0,4,5]  R355      5.9517753124237061e-01
    z[0,4,5]  R356      2.3161128163337708e-01
    z[0,4,5]  R357      -4.0721100568771362e-01
    z[0,4,5]  R358      -3.4148707985877991e-01
    z[0,4,5]  R359      -3.5778522491455078e-01
    z[0,4,5]  R360      2.3346321284770966e-01
    z[0,4,5]  R361      2.4932387471199036e-01
    z[0,4,5]  R362      -0.468799889087677
    z[0,4,5]  R363      -5.3434497117996216e-01
    z[0,4,5]  R364      -2.7919512987136841e-01
    z[0,4,5]  R365      -1.7638374119997025e-02
    z[0,4,5]  R366      2.4123069643974304e-01
    z[0,4,5]  R367      4.2480829358100891e-01
    z[0,4,5]  R368      3.2849079370498657e-01
    z[0,4,5]  R369      4.7065045684576035e-02
    z[0,4,5]  R370      -4.1814845800399780e-01
    z[0,4,5]  R371      -1.1946523189544678e-01
    z[0,4,5]  R372      2.0657652616500854e-01
    z[0,4,5]  R373      3.6275589466094971e-01
    z[0,4,5]  R374      -2.6349839568138123e-01
    z[0,4,5]  R375      -2.0331963896751404e-01
    z[0,4,5]  R376      -1.1794500052928925e-01
    z[0,4,5]  R377      -2.4451753497123718e-01
    z[0,4,5]  R378      -1.9577954709529877e-01
    z[0,4,5]  R379      -1.5811967849731445e-01
    z[0,4,5]  R380      -1.3639576733112335e-01
    z[0,4,5]  R381      -1.7367477715015411e-01
    z[0,4,5]  R382      -7.1926325559616089e-02
    z[0,4,5]  R383      5.8834481984376907e-02
    z[0,4,5]  R384      -3.8575258851051331e-01
    z[0,4,5]  R385      1.8640126287937164e-01
    z[0,4,5]  R386      -1.9208908081054688e-01
    z[0,4,5]  R387      9.4959894195199013e-03
    z[0,4,5]  R388      -4.9050965905189514e-01
    z[0,4,5]  R389      -1.8015022575855255e-01
    z[0,4,5]  R390      1.3386167585849762e-01
    z[0,4,5]  R391      1.9392508268356323e-01
    z[0,4,5]  R392      -1.4710029959678650e-01
    z[0,4,5]  R393      3.9358285069465637e-01
    z[0,4,5]  R394      1.0863801091909409e-01
    z[0,4,5]  R395      2.9338070750236511e-01
    z[0,4,5]  R396      -2.4932403862476349e-01
    z[0,4,5]  R397      0.0312016773968935
    z[0,4,5]  R398      -1.0448420047760010e-01
    z[0,4,5]  R399      -2.6090928912162781e-01
    z[0,4,5]  R400      -4.5123159885406494e-01
    z[0,4,5]  R401      1.0680218786001205e-01
    z[0,4,5]  R402      3.6879318952560425e-01
    z[0,4,5]  R403      3.6878335475921631e-01
    z[0,4,5]  R404      4.9595287442207336e-01
    z[0,4,5]  R405      0.0912671834230423
    z[0,4,5]  R406      -8.0275140702724457e-02
    z[0,4,5]  R407      -4.5369642972946167e-01
    z[0,4,5]  R408      -2.5563132762908936e-01
    z[0,4,5]  R409      -2.3328320682048798e-01
    z[0,4,5]  R410      -3.4196230769157410e-01
    z[0,4,5]  R411      4.2532852292060852e-01
    z[0,4,5]  R412      6.9031155109405518e-01
    z[0,4,5]  R413      -1.7529079318046570e-01
    z[0,4,5]  R414      7.0834594964981079e-01
    z[0,4,5]  R415      -0.0642034187912941
    z[0,4,5]  R416      -2.3047627508640289e-01
    z[0,4,5]  R417      2.0053030550479889e-01
    z[0,4,5]  R418      4.4623672962188721e-01
    z[0,4,5]  R419      -5.2082806825637817e-01
    z[0,4,5]  R420      -1.2185101397335529e-02
    z[0,4,5]  R421      -1.5581482648849487e-01
    z[0,4,5]  R422      1.8800030648708344e-01
    z[0,4,5]  R423      -5.2067607641220093e-02
    z[0,4,5]  R424      -9.7791932523250580e-02
    z[0,4,5]  R425      -1.1437275260686874e-01
    z[0,4,5]  R426      -4.0624892711639404e-01
    z[0,4,5]  R427      -2.7359002828598022e-01
    z[0,4,5]  R428      3.7848973274230957e-01
    z[0,4,5]  R429      -4.9476027488708496e-01
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R288      -1
    z[0,4,6]  R289      1
    z[0,4,6]  R290      3.1884399056434631e-01
    z[0,4,6]  R291      -2.7227851748466492e-01
    z[0,4,6]  R292      -4.9142214655876160e-01
    z[0,4,6]  R293      -5.3596991300582886e-01
    z[0,4,6]  R294      1.1703094467520714e-02
    z[0,4,6]  R295      0.0146006615832448
    z[0,4,6]  R296      3.0798447132110596e-01
    z[0,4,6]  R297      -1.1080397292971611e-02
    z[0,4,6]  R298      -3.5698670148849487e-01
    z[0,4,6]  R299      -0.593315601348877
    z[0,4,6]  R300      8.8053919374942780e-02
    z[0,4,6]  R301      1.7209558188915253e-01
    z[0,4,6]  R302      3.4361341595649719e-01
    z[0,4,6]  R303      4.1705024242401123e-01
    z[0,4,6]  R304      4.0096101164817810e-01
    z[0,4,6]  R305      0.476885586977005
    z[0,4,6]  R306      4.9733448028564453e-01
    z[0,4,6]  R307      1.1575733125209808e-01
    z[0,4,6]  R308      1.4786525070667267e-01
    z[0,4,6]  R309      6.6876187920570374e-02
    z[0,4,6]  R310      -4.0917722508311272e-03
    z[0,4,6]  R311      -0.508971631526947
    z[0,4,6]  R312      1.0664170980453491e-01
    z[0,4,6]  R313      -2.7697867155075073e-01
    z[0,4,6]  R314      -3.8562685251235962e-01
    z[0,4,6]  R315      4.6044796705245972e-01
    z[0,4,6]  R316      7.3766958713531494e-01
    z[0,4,6]  R317      -1.9449464976787567e-01
    z[0,4,6]  R318      -2.8869467787444592e-03
    z[0,4,6]  R319      2.5344389677047729e-01
    z[0,4,6]  R320      6.1942511796951294e-01
    z[0,4,6]  R321      1.3202281668782234e-02
    z[0,4,6]  R322      1.4053647220134735e-01
    z[0,4,6]  R323      9.6981525421142578e-02
    z[0,4,6]  R324      4.5962461829185486e-01
    z[0,4,6]  R325      -1.0170855373144150e-01
    z[0,4,6]  R326      4.9914318323135376e-01
    z[0,4,6]  R327      -5.4759550094604492e-01
    z[0,4,6]  R328      1.4791837334632874e-01
    z[0,4,6]  R329      -0.552911639213562
    z[0,4,6]  R330      4.3932226300239563e-01
    z[0,4,6]  R331      5.0070071220397949e-01
    z[0,4,6]  R332      4.5036903023719788e-01
    z[0,4,6]  R333      -7.9545125365257263e-02
    z[0,4,6]  R334      -2.5002273917198181e-01
    z[0,4,6]  R335      -1.1861776560544968e-01
    z[0,4,6]  R336      1.0288503021001816e-01
    z[0,4,6]  R337      -1.9306229054927826e-01
    z[0,4,6]  R338      -0.326310396194458
    z[0,4,6]  R339      -1.0381789505481720e-01
    z[0,4,6]  R340      3.8189920783042908e-01
    z[0,4,6]  R341      -8.4024742245674133e-02
    z[0,4,6]  R342      -7.6818592846393585e-02
    z[0,4,6]  R343      -3.6519506573677063e-01
    z[0,4,6]  R344      4.8459663987159729e-01
    z[0,4,6]  R345      -3.4069389104843140e-02
    z[0,4,6]  R346      -9.3032263219356537e-02
    z[0,4,6]  R347      1.1360388994216919e-01
    z[0,4,6]  R348      -6.3811009749770164e-03
    z[0,4,6]  R349      3.1372848898172379e-02
    z[0,4,6]  R350      1.2092879414558411e-01
    z[0,4,6]  R351      -2.3068059980869293e-01
    z[0,4,6]  R352      1.8213900923728943e-01
    z[0,4,6]  R353      3.6324393749237061e-01
    z[0,4,6]  R354      -1.2739732861518860e-01
    z[0,4,6]  R355      2.5307485461235046e-01
    z[0,4,6]  R356      -6.4232259988784790e-01
    z[0,4,6]  R357      -3.2322937250137329e-01
    z[0,4,6]  R358      1.9452343881130219e-01
    z[0,4,6]  R359      -0.318782240152359
    z[0,4,6]  R360      -6.1196070909500122e-01
    z[0,4,6]  R361      0.0861247330904007
    z[0,4,6]  R362      -2.1181281656026840e-02
    z[0,4,6]  R363      -8.9917801320552826e-02
    z[0,4,6]  R364      3.7962636351585388e-01
    z[0,4,6]  R365      2.5793942809104919e-01
    z[0,4,6]  R366      -1.3838969171047211e-01
    z[0,4,6]  R367      -2.6035052537918091e-01
    z[0,4,6]  R368      -2.1527664363384247e-01
    z[0,4,6]  R369      -1.9274526834487915e-01
    z[0,4,6]  R370      3.0488187074661255e-01
    z[0,4,6]  R371      -4.4549646973609924e-01
    z[0,4,6]  R372      1.5331450104713440e-01
    z[0,4,6]  R373      2.4077013134956360e-01
    z[0,4,6]  R374      -4.4894075393676758e-01
    z[0,4,6]  R375      -9.9124290049076080e-02
    z[0,4,6]  R376      -2.7765509486198425e-01
    z[0,4,6]  R377      4.5793330669403076e-01
    z[0,4,6]  R378      3.8040235638618469e-02
    z[0,4,6]  R379      2.1705214679241180e-01
    z[0,4,6]  R380      4.0557637810707092e-02
    z[0,4,6]  R381      -6.5903581678867340e-02
    z[0,4,6]  R382      5.5676591396331787e-01
    z[0,4,6]  R383      3.0735790729522705e-02
    z[0,4,6]  R384      -2.5501903891563416e-01
    z[0,4,6]  R385      2.4466918781399727e-02
    z[0,4,6]  R386      -6.1453711986541748e-01
    z[0,4,6]  R387      2.9225218296051025e-01
    z[0,4,6]  R388      -2.2415725886821747e-01
    z[0,4,6]  R389      -1.3678628206253052e-01
    z[0,4,6]  R390      5.1763290166854858e-01
    z[0,4,6]  R391      2.1968476474285126e-02
    z[0,4,6]  R392      2.5014054775238037e-01
    z[0,4,6]  R393      -6.4311426877975464e-01
    z[0,4,6]  R394      -1.0943056643009186e-01
    z[0,4,6]  R395      -3.7771737575531006e-01
    z[0,4,6]  R396      -4.3297520279884338e-01
    z[0,4,6]  R397      3.5609375685453415e-02
    z[0,4,6]  R398      -9.5370374619960785e-03
    z[0,4,6]  R399      2.8886166214942932e-01
    z[0,4,6]  R400      -4.4588279724121094e-01
    z[0,4,6]  R401      -5.8686070144176483e-02
    z[0,4,6]  R402      -4.7766438126564026e-01
    z[0,4,6]  R403      1.3234890997409821e-01
    z[0,4,6]  R404      4.6327769756317139e-01
    z[0,4,6]  R405      -2.1402609348297119e-01
    z[0,4,6]  R406      5.1475517451763153e-02
    z[0,4,6]  R407      -5.3200449794530869e-02
    z[0,4,6]  R408      1.6672787070274353e-01
    z[0,4,6]  R409      2.4014633893966675e-01
    z[0,4,6]  R410      1.1975119262933731e-01
    z[0,4,6]  R411      3.3051747083663940e-01
    z[0,4,6]  R412      -4.1553658246994019e-01
    z[0,4,6]  R413      -3.8281965255737305e-01
    z[0,4,6]  R414      3.4816227853298187e-02
    z[0,4,6]  R415      2.9397544264793396e-01
    z[0,4,6]  R416      -3.5653370618820190e-01
    z[0,4,6]  R417      -6.6828310489654541e-02
    z[0,4,6]  R418      2.8323090076446533e-01
    z[0,4,6]  R419      3.3723458647727966e-01
    z[0,4,6]  R420      3.4797167778015137e-01
    z[0,4,6]  R421      7.8672267496585846e-02
    z[0,4,6]  R422      1.8038541078567505e-01
    z[0,4,6]  R423      5.5920296907424927e-01
    z[0,4,6]  R424      2.2989727556705475e-01
    z[0,4,6]  R425      4.3185658752918243e-02
    z[0,4,6]  R426      -1.3556602597236633e-01
    z[0,4,6]  R427      -0.26072958111763
    z[0,4,6]  R428      -4.4539049267768860e-02
    z[0,4,6]  R429      2.6188188791275024e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R430      -1
    z[4,0,0]  R431      1
    z[4,0,0]  R444      -1.0769873857498169e-01
    z[4,0,0]  R445      4.4023630023002625e-01
    z[4,0,0]  R446      1.5612202882766724e-01
    z[4,0,0]  R447      1.0710169374942780e-01
    z[4,0,0]  R448      1.4449438452720642e-01
    z[4,0,0]  R449      3.6898839473724365e-01
    z[4,0,0]  R450      3.5365390777587891e-01
    z[4,0,0]  R451      2.2610253095626831e-01
    z[4,0,0]  R452      3.7432238459587097e-01
    z[4,0,0]  R453      4.5319777727127075e-01
    z[4,0,0]  R454      4.2977181077003479e-01
    z[4,0,0]  R455      8.7702494859695435e-01
    z[4,0,0]  R456      4.8994666337966919e-01
    z[4,0,0]  R457      7.9518508911132812e-01
    z[4,0,0]  R458      7.8260397911071777e-01
    z[4,0,0]  R459      6.9906884431838989e-01
    z[4,0,0]  R460      8.0059701204299927e-01
    z[4,0,0]  R461      7.1674311161041260e-01
    z[4,0,0]  R462      1.7772741615772247e-01
    z[4,0,0]  R463      3.0831113457679749e-01
    z[4,0,0]  R464      0.0574665404856205
    z[4,0,0]  R465      -1.6069617867469788e-01
    z[4,0,0]  R466      -1.8466311693191528e-01
    z[4,0,0]  R467      2.6367574930191040e-01
    z[4,0,0]  R468      -3.7643620371818542e-01
    z[4,0,0]  R469      -4.2276340723037720e-01
    z[4,0,0]  R470      -2.7800530195236206e-01
    z[4,0,0]  R471      -3.9284005761146545e-01
    z[4,0,0]  R472      -2.9538375139236450e-01
    z[4,0,0]  R473      -2.8193703293800354e-01
    z[4,0,0]  R474      3.2031199336051941e-01
    z[4,0,0]  R475      0.64688640832901
    z[4,0,0]  R476      4.9982777237892151e-01
    z[4,0,0]  R477      5.6988584995269775e-01
    z[4,0,0]  R478      3.5082665085792542e-01
    z[4,0,0]  R479      7.1311330795288086e-01
    z[4,0,0]  R480      6.9980710744857788e-01
    z[4,0,0]  R481      6.9062197208404541e-01
    z[4,0,0]  R482      7.6047849655151367e-01
    z[4,0,0]  R483      8.7697041034698486e-01
    z[4,0,0]  R484      4.1299268603324890e-01
    z[4,0,0]  R485      0.889885663986206
    z[4,0,0]  R486      1.6321896016597748e-01
    z[4,0,0]  R487      -2.9290360212326050e-01
    z[4,0,0]  R488      -2.1908316761255264e-02
    z[4,0,0]  R489      8.1645774841308594e-01
    z[4,0,0]  R490      -2.7878215909004211e-01
    z[4,0,0]  R491      -7.4276372790336609e-02
    z[4,0,0]  R492      -0.558233380317688
    z[4,0,0]  R493      1.1558765172958374e-01
    z[4,0,0]  R494      0.0573107935488224
    z[4,0,0]  R495      7.9961299896240234e-01
    z[4,0,0]  R496      2.4737431108951569e-01
    z[4,0,0]  R497      6.1655020713806152e-01
    z[4,0,0]  R498      1.5405617654323578e-01
    z[4,0,0]  R499      6.4512962102890015e-01
    z[4,0,0]  R500      -4.4343182444572449e-01
    z[4,0,0]  R501      3.7412993609905243e-02
    z[4,0,0]  R502      3.1464582681655884e-01
    z[4,0,0]  R503      3.0606740713119507e-01
    z[4,0,0]  R504      4.7941152006387711e-02
    z[4,0,0]  R505      2.8697720170021057e-01
    z[4,0,0]  R506      -4.5842775143682957e-03
    z[4,0,0]  R507      3.2030594348907471e-01
    z[4,0,0]  R508      3.5250097513198853e-01
    z[4,0,0]  R509      2.0658531785011292e-01
    z[4,0,0]  R510      8.9794412255287170e-02
    z[4,0,0]  R511      -8.2716733217239380e-02
    z[4,0,0]  R512      -8.0401289463043213e-01
    z[4,0,0]  R513      -4.5728474855422974e-01
    z[4,0,0]  R514      -1.7456750571727753e-01
    z[4,0,0]  R515      -5.2107536792755127e-01
    z[4,0,0]  R516      6.4120548963546753e-01
    z[4,0,0]  R517      -6.3968378305435181e-01
    z[4,0,0]  R518      -0.747021496295929
    z[4,0,0]  R519      -7.5739741325378418e-01
    z[4,0,0]  R520      -7.6824188232421875e-01
    z[4,0,0]  R521      -7.7754920721054077e-01
    z[4,0,0]  R522      -0.503307044506073
    z[4,0,0]  R523      -6.0108578205108643e-01
    z[4,0,0]  R524      1.7100869119167328e-01
    z[4,0,0]  R525      5.5702650547027588e-01
    z[4,0,0]  R526      2.7477458119392395e-01
    z[4,0,0]  R527      0.0161072239279747
    z[4,0,0]  R528      2.3288173973560333e-01
    z[4,0,0]  R529      -4.1363561153411865e-01
    z[4,0,0]  R530      6.4785279333591461e-02
    z[4,0,0]  R531      -1.8434689939022064e-01
    z[4,0,0]  R532      2.4861548840999603e-01
    z[4,0,0]  R533      -3.9969703555107117e-01
    z[4,0,0]  R534      2.2537778317928314e-01
    z[4,0,0]  R535      -1.6907557845115662e-01
    z[4,0,0]  R536      3.8456264138221741e-01
    z[4,0,0]  R537      4.2606998234987259e-02
    z[4,0,0]  R538      1.5546953678131104e-01
    z[4,0,0]  R539      1.5194568037986755e-01
    z[4,0,0]  R540      9.8743841052055359e-02
    z[4,0,0]  R541      1.5659880638122559e-01
    z[4,0,0]  R542      4.4227278232574463e-01
    z[4,0,0]  R543      2.9409646987915039e-01
    z[4,0,0]  R544      6.7874324321746826e-01
    z[4,0,0]  R545      -2.6537823677062988e-01
    z[4,0,0]  R546      -8.6096087470650673e-03
    z[4,0,0]  R547      -1.4754873514175415e-01
    z[4,0,0]  R548      -1.3693846762180328e-01
    z[4,0,0]  R549      -6.1380922794342041e-01
    z[4,0,0]  R550      1.0916613787412643e-01
    z[4,0,0]  R551      -4.5338609814643860e-01
    z[4,0,0]  R552      -2.4482056498527527e-01
    z[4,0,0]  R553      -4.1672316193580627e-01
    z[4,0,0]  R554      7.4712353944778442e-01
    z[4,0,0]  R555      -4.8969838023185730e-01
    z[4,0,0]  R556      1.5534083545207977e-01
    z[4,0,0]  R557      -6.7616707086563110e-01
    z[4,0,0]  R558      -5.5766785144805908e-01
    z[4,0,0]  R559      2.8004637360572815e-01
    z[4,0,0]  R560      -1.9828376173973083e-01
    z[4,0,0]  R561      -8.5096381604671478e-02
    z[4,0,0]  R562      -0.393048495054245
    z[4,0,0]  R563      -1.2451636791229248e-01
    z[4,0,0]  R564      8.4260833263397217e-01
    z[4,0,0]  R565      2.4188110232353210e-01
    z[4,0,0]  R566      1.1477822810411453e-01
    z[4,0,0]  R567      -1.5447893738746643e-01
    z[4,0,0]  R568      -2.0491238683462143e-02
    z[4,0,0]  R569      1.6565407812595367e-01
    z[4,0,0]  R570      -1.5606896579265594e-01
    z[4,0,0]  R571      -3.8013646006584167e-01
    z[4,0,0]  R572      7.9477488994598389e-02
    z[4,0,0]  R573      1.5868206322193146e-01
    z[4,0,0]  R574      4.2231917381286621e-01
    z[4,0,0]  R575      -1.0622905939817429e-01
    z[4,0,0]  R576      -1.1425952613353729e-01
    z[4,0,0]  R577      -5.4170143604278564e-01
    z[4,0,0]  R578      -0.0959658995270729
    z[4,0,0]  R579      -1.1131045222282410e-01
    z[4,0,0]  R580      -5.2563261985778809e-01
    z[4,0,0]  R581      -6.2662810087203979e-01
    z[4,0,0]  R582      -0.735031247138977
    z[4,0,0]  R583      -6.4145928621292114e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R432      -1
    z[4,0,1]  R433      1
    z[4,0,1]  R444      -7.5980699062347412e-01
    z[4,0,1]  R445      5.7655000686645508e-01
    z[4,0,1]  R446      3.6562508344650269e-01
    z[4,0,1]  R447      5.0436949729919434e-01
    z[4,0,1]  R448      3.5136339068412781e-01
    z[4,0,1]  R449      3.3590036630630493e-01
    z[4,0,1]  R450      3.6449325084686279e-01
    z[4,0,1]  R451      2.8012299537658691e-01
    z[4,0,1]  R452      3.7272053956985474e-01
    z[4,0,1]  R453      -8.8489063084125519e-02
    z[4,0,1]  R454      3.6328908801078796e-01
    z[4,0,1]  R455      -2.6171383261680603e-01
    z[4,0,1]  R456      1.7946556210517883e-01
    z[4,0,1]  R457      -1.1190539598464966e-01
    z[4,0,1]  R458      -2.1723881363868713e-03
    z[4,0,1]  R459      2.4210011959075928e-01
    z[4,0,1]  R460      -4.1312709450721741e-01
    z[4,0,1]  R461      2.6052770018577576e-01
    z[4,0,1]  R462      -7.6499587297439575e-01
    z[4,0,1]  R463      -8.0215257406234741e-01
    z[4,0,1]  R464      -6.0057377815246582e-01
    z[4,0,1]  R465      -6.4692658185958862e-01
    z[4,0,1]  R466      9.0139198303222656e-01
    z[4,0,1]  R467      -5.3246569633483887e-01
    z[4,0,1]  R468      -6.7894893884658813e-01
    z[4,0,1]  R469      8.1930369138717651e-01
    z[4,0,1]  R470      7.5480204820632935e-01
    z[4,0,1]  R471      -5.7989561557769775e-01
    z[4,0,1]  R472      7.5166279077529907e-01
    z[4,0,1]  R473      7.2597855329513550e-01
    z[4,0,1]  R474      -0.900971531867981
    z[4,0,1]  R475      3.5553914308547974e-01
    z[4,0,1]  R476      3.0239078402519226e-01
    z[4,0,1]  R477      7.8953355550765991e-01
    z[4,0,1]  R478      1.0615737736225128e-01
    z[4,0,1]  R479      -0.314377099275589
    z[4,0,1]  R480      -1.5062569081783295e-01
    z[4,0,1]  R481      -1.0727320611476898e-01
    z[4,0,1]  R482      -3.8941238075494766e-02
    z[4,0,1]  R483      0.0747273862361908
    z[4,0,1]  R484      6.7456549406051636e-01
    z[4,0,1]  R485      4.9455105327069759e-03
    z[4,0,1]  R486      -4.4741186499595642e-01
    z[4,0,1]  R487      -4.7400176525115967e-01
    z[4,0,1]  R488      6.2695342302322388e-01
    z[4,0,1]  R489      -1.0745301097631454e-01
    z[4,0,1]  R490      -8.1280374526977539e-01
    z[4,0,1]  R491      -7.5216662883758545e-01
    z[4,0,1]  R492      -7.0853632688522339e-01
    z[4,0,1]  R493      -7.3085999488830566e-01
    z[4,0,1]  R494      -1.8043406307697296e-02
    z[4,0,1]  R495      9.9392943084239960e-02
    z[4,0,1]  R496      -6.2044060230255127e-01
    z[4,0,1]  R497      1.7024628818035126e-01
    z[4,0,1]  R498      -3.3160951733589172e-01
    z[4,0,1]  R499      -6.8393266201019287e-01
    z[4,0,1]  R500      -8.8236892223358154e-01
    z[4,0,1]  R501      -8.0494534969329834e-01
    z[4,0,1]  R502      -7.3241299390792847e-01
    z[4,0,1]  R503      -7.4001210927963257e-01
    z[4,0,1]  R504      8.2478791475296021e-01
    z[4,0,1]  R505      -5.0706952810287476e-01
    z[4,0,1]  R506      -8.8635720312595367e-02
    z[4,0,1]  R507      -5.9026145935058594e-01
    z[4,0,1]  R508      -4.6090030670166016e-01
    z[4,0,1]  R509      -8.1325441598892212e-01
    z[4,0,1]  R510      -8.2056128978729248e-01
    z[4,0,1]  R511      -7.8597873449325562e-01
    z[4,0,1]  R512      -0.0318484753370285
    z[4,0,1]  R513      -3.4133437275886536e-01
    z[4,0,1]  R514      -4.9273166060447693e-01
    z[4,0,1]  R515      6.4521151781082153e-01
    z[4,0,1]  R516      -1.0454971343278885e-01
    z[4,0,1]  R517      2.5759446620941162e-01
    z[4,0,1]  R518      -1.0024883598089218e-01
    z[4,0,1]  R519      6.7785056307911873e-03
    z[4,0,1]  R520      8.4484659135341644e-02
    z[4,0,1]  R521      -4.8546131700277328e-02
    z[4,0,1]  R522      1.1268686503171921e-01
    z[4,0,1]  R523      -0.0511755645275116
    z[4,0,1]  R524      0.364397794008255
    z[4,0,1]  R525      0.59727543592453
    z[4,0,1]  R526      2.2113518416881561e-01
    z[4,0,1]  R527      5.1349848508834839e-01
    z[4,0,1]  R528      3.0965054035186768e-01
    z[4,0,1]  R529      5.9379267692565918e-01
    z[4,0,1]  R530      3.3784812688827515e-01
    z[4,0,1]  R531      4.4527783989906311e-01
    z[4,0,1]  R532      5.1362925767898560e-01
    z[4,0,1]  R533      -0.673263430595398
    z[4,0,1]  R534      -8.0944615602493286e-01
    z[4,0,1]  R535      -9.0964114665985107e-01
    z[4,0,1]  R536      -8.4404426813125610e-01
    z[4,0,1]  R537      -8.1154882907867432e-01
    z[4,0,1]  R538      -0.852180004119873
    z[4,0,1]  R539      -0.802143394947052
    z[4,0,1]  R540      -8.2273662090301514e-01
    z[4,0,1]  R541      -8.1920778751373291e-01
    z[4,0,1]  R542      -8.2633709907531738e-01
    z[4,0,1]  R543      -7.8579616546630859e-01
    z[4,0,1]  R544      2.2106523811817169e-01
    z[4,0,1]  R545      -5.3301107883453369e-01
    z[4,0,1]  R546      -9.3082493543624878e-01
    z[4,0,1]  R547      -0.639501690864563
    z[4,0,1]  R548      -7.5223529338836670e-01
    z[4,0,1]  R549      -0.611943244934082
    z[4,0,1]  R550      -7.5828351080417633e-02
    z[4,0,1]  R551      4.5163372159004211e-01
    z[4,0,1]  R552      2.5264132022857666e-01
    z[4,0,1]  R553      2.2036257386207581e-01
    z[4,0,1]  R554      -1.4292629063129425e-01
    z[4,0,1]  R555      -4.9250790476799011e-01
    z[4,0,1]  R556      -8.6433261632919312e-01
    z[4,0,1]  R557      -5.4577279090881348e-01
    z[4,0,1]  R558      -4.0878617763519287e-01
    z[4,0,1]  R559      -8.1643259525299072e-01
    z[4,0,1]  R560      -0.767369270324707
    z[4,0,1]  R561      -7.9266226291656494e-01
    z[4,0,1]  R562      -6.5824913978576660e-01
    z[4,0,1]  R563      -6.7528587579727173e-01
    z[4,0,1]  R564      1.8896445631980896e-01
    z[4,0,1]  R565      -4.8006501793861389e-01
    z[4,0,1]  R566      6.3000261783599854e-01
    z[4,0,1]  R567      6.3745582103729248e-01
    z[4,0,1]  R568      -9.4899761676788330e-01
    z[4,0,1]  R569      -9.0974158048629761e-01
    z[4,0,1]  R570      -9.3185275793075562e-01
    z[4,0,1]  R571      -4.6076655387878418e-01
    z[4,0,1]  R572      -6.8318635225296021e-01
    z[4,0,1]  R573      7.7136307954788208e-02
    z[4,0,1]  R574      -3.6867281794548035e-01
    z[4,0,1]  R575      -8.0004745721817017e-01
    z[4,0,1]  R576      -5.4384297132492065e-01
    z[4,0,1]  R577      -6.3243098556995392e-02
    z[4,0,1]  R578      -8.4444028139114380e-01
    z[4,0,1]  R579      -6.6713988780975342e-01
    z[4,0,1]  R580      -1.4305049180984497e-01
    z[4,0,1]  R581      -6.0757622122764587e-02
    z[4,0,1]  R582      -1.3459648191928864e-01
    z[4,0,1]  R583      -1.4120139181613922e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R434      -1
    z[4,0,2]  R435      1
    z[4,0,2]  R444      4.2846021056175232e-01
    z[4,0,2]  R445      4.7197285294532776e-01
    z[4,0,2]  R446      8.7361693382263184e-01
    z[4,0,2]  R447      7.1127218008041382e-01
    z[4,0,2]  R448      8.0955666303634644e-01
    z[4,0,2]  R449      5.6911766529083252e-01
    z[4,0,2]  R450      4.0934070944786072e-01
    z[4,0,2]  R451      7.1070623397827148e-01
    z[4,0,2]  R452      5.7346224784851074e-01
    z[4,0,2]  R453      7.3634207248687744e-01
    z[4,0,2]  R454      1.9641520082950592e-01
    z[4,0,2]  R455      -1.2724100053310394e-01
    z[4,0,2]  R456      0.371624618768692
    z[4,0,2]  R457      -9.8497465252876282e-02
    z[4,0,2]  R458      -4.4014319777488708e-02
    z[4,0,2]  R459      -7.1682795882225037e-02
    z[4,0,2]  R460      -1.1576101183891296e-01
    z[4,0,2]  R461      -1.6678930819034576e-01
    z[4,0,2]  R462      -3.3565798401832581e-01
    z[4,0,2]  R463      -1.0911931097507477e-01
    z[4,0,2]  R464      -9.6833752468228340e-03
    z[4,0,2]  R465      -5.0400024652481079e-01
    z[4,0,2]  R466      -2.5089514255523682e-01
    z[4,0,2]  R467      -5.4853504896163940e-01
    z[4,0,2]  R468      -1.8029215931892395e-01
    z[4,0,2]  R469      -1.6667243838310242e-01
    z[4,0,2]  R470      -4.2241996526718140e-01
    z[4,0,2]  R471      -3.4912031888961792e-01
    z[4,0,2]  R472      -3.4621769189834595e-01
    z[4,0,2]  R473      -3.2184126973152161e-01
    z[4,0,2]  R474      -1.1219297349452972e-01
    z[4,0,2]  R475      5.5161285400390625e-01
    z[4,0,2]  R476      4.4495663046836853e-01
    z[4,0,2]  R477      0.0851961150765419
    z[4,0,2]  R478      8.0610948801040649e-01
    z[4,0,2]  R479      5.7804727554321289e-01
    z[4,0,2]  R480      3.2496452331542969e-02
    z[4,0,2]  R481      -4.9097468145191669e-03
    z[4,0,2]  R482      -1.1313035339117050e-01
    z[4,0,2]  R483      -2.0541571080684662e-01
    z[4,0,2]  R484      2.0228993892669678e-01
    z[4,0,2]  R485      0.352448970079422
    z[4,0,2]  R486      1.8935729563236237e-01
    z[4,0,2]  R487      0.316108375787735
    z[4,0,2]  R488      2.9753330349922180e-01
    z[4,0,2]  R489      1.9822779297828674e-01
    z[4,0,2]  R490      5.1628995686769485e-02
    z[4,0,2]  R491      -4.0192636847496033e-01
    z[4,0,2]  R492      -4.1487923264503479e-01
    z[4,0,2]  R493      -3.2615345716476440e-01
    z[4,0,2]  R494      4.5415255427360535e-01
    z[4,0,2]  R495      2.1178849041461945e-01
    z[4,0,2]  R496      3.1848031282424927e-01
    z[4,0,2]  R497      2.0725689828395844e-01
    z[4,0,2]  R498      -2.5462964177131653e-01
    z[4,0,2]  R499      9.5716238021850586e-02
    z[4,0,2]  R500      -1.0808206349611282e-01
    z[4,0,2]  R501      -2.2758223116397858e-01
    z[4,0,2]  R502      -3.3036249876022339e-01
    z[4,0,2]  R503      -4.9515508115291595e-02
    z[4,0,2]  R504      3.7481376528739929e-01
    z[4,0,2]  R505      8.0753460526466370e-02
    z[4,0,2]  R506      5.3348565101623535e-01
    z[4,0,2]  R507      4.6799808740615845e-01
    z[4,0,2]  R508      -3.8040125370025635e-01
    z[4,0,2]  R509      -2.5340586900711060e-01
    z[4,0,2]  R510      -3.2903066277503967e-01
    z[4,0,2]  R511      -4.6661749482154846e-01
    z[4,0,2]  R512      1.2670126557350159e-01
    z[4,0,2]  R513      -9.6945315599441528e-02
    z[4,0,2]  R514      6.2912482023239136e-01
    z[4,0,2]  R515      4.5185607671737671e-01
    z[4,0,2]  R516      6.8789505958557129e-01
    z[4,0,2]  R517      4.1986843943595886e-01
    z[4,0,2]  R518      -5.8373087644577026e-01
    z[4,0,2]  R519      -5.1679015159606934e-01
    z[4,0,2]  R520      -0.415141761302948
    z[4,0,2]  R521      -3.8516268134117126e-01
    z[4,0,2]  R522      -1.2402106076478958e-01
    z[4,0,2]  R523      -5.1551944017410278e-01
    z[4,0,2]  R524      8.1947362422943115e-01
    z[4,0,2]  R525      6.5707027912139893e-02
    z[4,0,2]  R526      7.1899324655532837e-01
    z[4,0,2]  R527      5.0596338510513306e-01
    z[4,0,2]  R528      7.4975913763046265e-01
    z[4,0,2]  R529      5.8152687549591064e-01
    z[4,0,2]  R530      5.9093868732452393e-01
    z[4,0,2]  R531      7.2123205661773682e-01
    z[4,0,2]  R532      0.237759068608284
    z[4,0,2]  R533      4.4213291257619858e-03
    z[4,0,2]  R534      -3.4749990701675415e-01
    z[4,0,2]  R535      1.0062158852815628e-01
    z[4,0,2]  R536      1.5836326405405998e-02
    z[4,0,2]  R537      -1.9477196037769318e-01
    z[4,0,2]  R538      -1.5739586949348450e-01
    z[4,0,2]  R539      -2.1539069712162018e-01
    z[4,0,2]  R540      -1.7674618959426880e-01
    z[4,0,2]  R541      -1.3218337297439575e-01
    z[4,0,2]  R542      -2.0232470333576202e-01
    z[4,0,2]  R543      -2.4495676159858704e-01
    z[4,0,2]  R544      -2.9079401493072510e-01
    z[4,0,2]  R545      -8.0045007169246674e-02
    z[4,0,2]  R546      -6.1496417969465256e-02
    z[4,0,2]  R547      -0.351165771484375
    z[4,0,2]  R548      3.1412267684936523e-01
    z[4,0,2]  R549      -9.4151444733142853e-02
    z[4,0,2]  R550      -1.7917390167713165e-01
    z[4,0,2]  R551      -5.0620126724243164e-01
    z[4,0,2]  R552      -5.0399070978164673e-01
    z[4,0,2]  R553      -0.363391250371933
    z[4,0,2]  R554      -0.0655822828412056
    z[4,0,2]  R555      4.0806770324707031e-01
    z[4,0,2]  R556      3.1533968448638916e-01
    z[4,0,2]  R557      3.5414081811904907e-01
    z[4,0,2]  R558      -1.3705284893512726e-01
    z[4,0,2]  R559      -2.4633088707923889e-01
    z[4,0,2]  R560      -3.4460136294364929e-01
    z[4,0,2]  R561      1.4858037233352661e-01
    z[4,0,2]  R562      -4.9796235561370850e-01
    z[4,0,2]  R563      -3.4064370393753052e-01
    z[4,0,2]  R564      -6.6855573095381260e-03
    z[4,0,2]  R565      9.8814904689788818e-02
    z[4,0,2]  R566      -2.5099816918373108e-01
    z[4,0,2]  R567      -1.6343134641647339e-01
    z[4,0,2]  R568      -1.2185386568307877e-01
    z[4,0,2]  R569      -3.2223123311996460e-01
    z[4,0,2]  R570      -2.6625648140907288e-01
    z[4,0,2]  R571      1.0322643071413040e-01
    z[4,0,2]  R572      -4.9273246526718140e-01
    z[4,0,2]  R573      1.5159864723682404e-01
    z[4,0,2]  R574      2.7118667960166931e-01
    z[4,0,2]  R575      2.5700709223747253e-01
    z[4,0,2]  R576      1.4827635884284973e-01
    z[4,0,2]  R577      -1.3728782534599304e-01
    z[4,0,2]  R578      -6.3559204339981079e-02
    z[4,0,2]  R579      -5.7696157693862915e-01
    z[4,0,2]  R580      -6.8022996187210083e-01
    z[4,0,2]  R581      -5.4369497299194336e-01
    z[4,0,2]  R582      -0.588640034198761
    z[4,0,2]  R583      -6.3312333822250366e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R436      -1
    z[4,0,3]  R437      1
    z[4,0,3]  R444      -1.1365080624818802e-01
    z[4,0,3]  R445      -2.6653057336807251e-01
    z[4,0,3]  R446      -1.6158398240804672e-02
    z[4,0,3]  R447      8.7386779487133026e-02
    z[4,0,3]  R448      -2.4195969104766846e-01
    z[4,0,3]  R449      -5.4229967296123505e-02
    z[4,0,3]  R450      -2.1973271667957306e-01
    z[4,0,3]  R451      -2.1441173553466797e-01
    z[4,0,3]  R452      -4.2974729090929031e-02
    z[4,0,3]  R453      6.2710449099540710e-02
    z[4,0,3]  R454      1.4789845049381256e-01
    z[4,0,3]  R455      0.0894770473241806
    z[4,0,3]  R456      3.9945179224014282e-01
    z[4,0,3]  R457      8.7021932005882263e-02
    z[4,0,3]  R458      2.2188428044319153e-01
    z[4,0,3]  R459      5.1621246337890625e-01
    z[4,0,3]  R460      -2.7530366182327271e-01
    z[4,0,3]  R461      1.9655907154083252e-01
    z[4,0,3]  R462      1.9867390394210815e-01
    z[4,0,3]  R463      3.1789278984069824e-01
    z[4,0,3]  R464      -4.6466785669326782e-01
    z[4,0,3]  R465      5.3142286837100983e-02
    z[4,0,3]  R466      -1.5477515757083893e-01
    z[4,0,3]  R467      1.5464648604393005e-01
    z[4,0,3]  R468      8.9399078860878944e-03
    z[4,0,3]  R469      -2.6493254303932190e-01
    z[4,0,3]  R470      -2.5016868114471436e-01
    z[4,0,3]  R471      3.1325221061706543e-01
    z[4,0,3]  R472      5.5311530828475952e-02
    z[4,0,3]  R473      -3.7594158202409744e-02
    z[4,0,3]  R474      -2.2050699591636658e-01
    z[4,0,3]  R475      2.3014302551746368e-01
    z[4,0,3]  R476      3.7489798665046692e-01
    z[4,0,3]  R477      1.4491407573223114e-01
    z[4,0,3]  R478      -1.3750021345913410e-02
    z[4,0,3]  R479      2.0133394747972488e-02
    z[4,0,3]  R480      -3.9063658565282822e-02
    z[4,0,3]  R481      3.6451440304517746e-02
    z[4,0,3]  R482      2.4458234012126923e-01
    z[4,0,3]  R483      2.4195723235607147e-01
    z[4,0,3]  R484      1.6079044342041016e-01
    z[4,0,3]  R485      -2.1304486691951752e-01
    z[4,0,3]  R486      5.1672559976577759e-01
    z[4,0,3]  R487      1.3092531263828278e-01
    z[4,0,3]  R488      6.0761805623769760e-02
    z[4,0,3]  R489      -1.6981713473796844e-02
    z[4,0,3]  R490      8.4242507815361023e-02
    z[4,0,3]  R491      -4.7782354056835175e-02
    z[4,0,3]  R492      -3.9128664880990982e-02
    z[4,0,3]  R493      2.5848546624183655e-01
    z[4,0,3]  R494      0.193464457988739
    z[4,0,3]  R495      -5.1578204147517681e-03
    z[4,0,3]  R496      -2.1298509091138840e-02
    z[4,0,3]  R497      3.7492990493774414e-01
    z[4,0,3]  R498      4.2187440395355225e-01
    z[4,0,3]  R499      2.2648863494396210e-01
    z[4,0,3]  R500      -1.3462702045217156e-03
    z[4,0,3]  R501      1.5759870409965515e-01
    z[4,0,3]  R502      3.5399022698402405e-01
    z[4,0,3]  R503      2.3068022727966309e-01
    z[4,0,3]  R504      -1.2059453874826431e-01
    z[4,0,3]  R505      4.1977667808532715e-01
    z[4,0,3]  R506      1.2259480357170105e-01
    z[4,0,3]  R507      -1.3393211364746094e-01
    z[4,0,3]  R508      1.0628718882799149e-01
    z[4,0,3]  R509      3.2748955488204956e-01
    z[4,0,3]  R510      1.0601244121789932e-01
    z[4,0,3]  R511      -4.3967794626951218e-02
    z[4,0,3]  R512      8.8841117918491364e-02
    z[4,0,3]  R513      3.3085581660270691e-01
    z[4,0,3]  R514      2.6332038640975952e-01
    z[4,0,3]  R515      1.8129470944404602e-01
    z[4,0,3]  R516      1.5514270961284637e-01
    z[4,0,3]  R517      1.6484937071800232e-01
    z[4,0,3]  R518      -1.1773931980133057e-01
    z[4,0,3]  R519      -2.8462055325508118e-01
    z[4,0,3]  R520      -2.1530902385711670e-01
    z[4,0,3]  R521      -3.1624028086662292e-01
    z[4,0,3]  R522      6.2884055078029633e-02
    z[4,0,3]  R523      -2.1473422646522522e-02
    z[4,0,3]  R524      8.5660547018051147e-02
    z[4,0,3]  R525      2.7198737859725952e-01
    z[4,0,3]  R526      1.6805322468280792e-01
    z[4,0,3]  R527      2.0597749948501587e-01
    z[4,0,3]  R528      -1.6725739464163780e-02
    z[4,0,3]  R529      2.5260123610496521e-01
    z[4,0,3]  R530      1.8239581584930420e-01
    z[4,0,3]  R531      1.4585982263088226e-01
    z[4,0,3]  R532      -7.8262068331241608e-02
    z[4,0,3]  R533      1.1281822808086872e-02
    z[4,0,3]  R534      7.2790971025824547e-03
    z[4,0,3]  R535      4.0342751890420914e-02
    z[4,0,3]  R536      3.6678362637758255e-02
    z[4,0,3]  R537      -5.0640669651329517e-03
    z[4,0,3]  R538      -6.6116988658905029e-02
    z[4,0,3]  R539      2.4095119908452034e-02
    z[4,0,3]  R540      0.00373685359954834
    z[4,0,3]  R541      4.3788827024400234e-03
    z[4,0,3]  R542      -9.2257685959339142e-02
    z[4,0,3]  R543      -3.5431653261184692e-02
    z[4,0,3]  R544      -3.1329861283302307e-01
    z[4,0,3]  R545      9.6256427466869354e-02
    z[4,0,3]  R546      1.3446553051471710e-01
    z[4,0,3]  R547      2.2640231251716614e-01
    z[4,0,3]  R548      9.3737974762916565e-02
    z[4,0,3]  R549      2.7037955820560455e-02
    z[4,0,3]  R550      1.2076328694820404e-01
    z[4,0,3]  R551      -3.6070051789283752e-01
    z[4,0,3]  R552      -6.0981345176696777e-01
    z[4,0,3]  R553      -5.5927598476409912e-01
    z[4,0,3]  R554      4.4853985309600830e-02
    z[4,0,3]  R555      1.1449429392814636e-01
    z[4,0,3]  R556      9.5849819481372833e-02
    z[4,0,3]  R557      1.7167614400386810e-01
    z[4,0,3]  R558      1.0390021651983261e-01
    z[4,0,3]  R559      1.6754738986492157e-02
    z[4,0,3]  R560      4.7868089750409126e-03
    z[4,0,3]  R561      9.9124103784561157e-02
    z[4,0,3]  R562      1.4544361270964146e-02
    z[4,0,3]  R563      6.7582853138446808e-02
    z[4,0,3]  R564      -8.6285084486007690e-02
    z[4,0,3]  R565      1.9811521470546722e-01
    z[4,0,3]  R566      -3.3602741360664368e-01
    z[4,0,3]  R567      -2.7378478646278381e-01
    z[4,0,3]  R568      -7.5606115162372589e-02
    z[4,0,3]  R569      -2.4072457104921341e-02
    z[4,0,3]  R570      -1.0722508281469345e-01
    z[4,0,3]  R571      3.7878003716468811e-01
    z[4,0,3]  R572      1.1484664678573608e-01
    z[4,0,3]  R573      -8.5799562931060791e-01
    z[4,0,3]  R574      3.3663338422775269e-01
    z[4,0,3]  R575      2.6797682046890259e-01
    z[4,0,3]  R576      1.3685268163681030e-01
    z[4,0,3]  R577      1.2173786759376526e-01
    z[4,0,3]  R578      3.9388176053762436e-02
    z[4,0,3]  R579      5.8200873434543610e-02
    z[4,0,3]  R580      -0.351654976606369
    z[4,0,3]  R581      -3.7919861078262329e-01
    z[4,0,3]  R582      -2.6014360785484314e-01
    z[4,0,3]  R583      -3.0291095376014709e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R438      -1
    z[4,0,4]  R439      1
    z[4,0,4]  R444      -8.0058827996253967e-02
    z[4,0,4]  R445      -3.2889395952224731e-01
    z[4,0,4]  R446      1.6888274252414703e-01
    z[4,0,4]  R447      3.0916187912225723e-02
    z[4,0,4]  R448      6.0891564935445786e-02
    z[4,0,4]  R449      -7.6807349920272827e-02
    z[4,0,4]  R450      2.4496786296367645e-01
    z[4,0,4]  R451      -2.2143848240375519e-01
    z[4,0,4]  R452      -4.8559615015983582e-01
    z[4,0,4]  R453      1.0496097803115845e-01
    z[4,0,4]  R454      4.4029909372329712e-01
    z[4,0,4]  R455      2.6183375716209412e-01
    z[4,0,4]  R456      4.5810022950172424e-01
    z[4,0,4]  R457      2.1041291952133179e-01
    z[4,0,4]  R458      3.3806860446929932e-01
    z[4,0,4]  R459      3.3798319101333618e-01
    z[4,0,4]  R460      -1.4776277542114258e-01
    z[4,0,4]  R461      3.2203400135040283e-01
    z[4,0,4]  R462      2.7713969349861145e-01
    z[4,0,4]  R463      3.3040383458137512e-01
    z[4,0,4]  R464      0.390125036239624
    z[4,0,4]  R465      -2.9339954257011414e-01
    z[4,0,4]  R466      1.7583616077899933e-02
    z[4,0,4]  R467      -3.6412519216537476e-01
    z[4,0,4]  R468      -3.0620199441909790e-01
    z[4,0,4]  R469      2.9648987576365471e-02
    z[4,0,4]  R470      -1.4477708935737610e-01
    z[4,0,4]  R471      1.4104658365249634e-01
    z[4,0,4]  R472      4.3017297983169556e-01
    z[4,0,4]  R473      -4.6514311432838440e-01
    z[4,0,4]  R474      -6.4739942550659180e-02
    z[4,0,4]  R475      2.5175625085830688e-01
    z[4,0,4]  R476      7.0959888398647308e-02
    z[4,0,4]  R477      1.3857199251651764e-01
    z[4,0,4]  R478      4.2542789131402969e-02
    z[4,0,4]  R479      1.5082585811614990e-01
    z[4,0,4]  R480      -2.6541644334793091e-01
    z[4,0,4]  R481      -6.5167438983917236e-01
    z[4,0,4]  R482      -2.3809868097305298e-01
    z[4,0,4]  R483      -0.270989328622818
    z[4,0,4]  R484      -1.4751519262790680e-01
    z[4,0,4]  R485      -1.9519133493304253e-02
    z[4,0,4]  R486      6.2137889862060547e-01
    z[4,0,4]  R487      0.0629318356513977
    z[4,0,4]  R488      7.0032423734664917e-01
    z[4,0,4]  R489      -2.3135535418987274e-01
    z[4,0,4]  R490      4.7309298068284988e-02
    z[4,0,4]  R491      -5.1250267028808594e-01
    z[4,0,4]  R492      -4.1086863726377487e-02
    z[4,0,4]  R493      -3.5745996236801147e-01
    z[4,0,4]  R494      5.9184902906417847e-01
    z[4,0,4]  R495      -5.3945183753967285e-01
    z[4,0,4]  R496      2.9631805419921875e-01
    z[4,0,4]  R497      5.0382214784622192e-01
    z[4,0,4]  R498      0.403598815202713
    z[4,0,4]  R499      -3.8055527955293655e-02
    z[4,0,4]  R500      -6.3370861113071442e-02
    z[4,0,4]  R501      -2.5565892457962036e-01
    z[4,0,4]  R502      -1.9228948652744293e-01
    z[4,0,4]  R503      -4.3697637319564819e-01
    z[4,0,4]  R504      -1.7640747129917145e-01
    z[4,0,4]  R505      4.3317991495132446e-01
    z[4,0,4]  R506      2.0805180072784424e-01
    z[4,0,4]  R507      -3.6709362268447876e-01
    z[4,0,4]  R508      -6.5922670066356659e-02
    z[4,0,4]  R509      -1.8420684337615967e-01
    z[4,0,4]  R510      -1.3740763068199158e-01
    z[4,0,4]  R511      -3.3324441313743591e-01
    z[4,0,4]  R512      2.2193701565265656e-01
    z[4,0,4]  R513      4.1295105218887329e-01
    z[4,0,4]  R514      3.7466433644294739e-01
    z[4,0,4]  R515      2.1136064827442169e-01
    z[4,0,4]  R516      -1.1301765590906143e-01
    z[4,0,4]  R517      -7.4604131281375885e-02
    z[4,0,4]  R518      -1.2201914936304092e-01
    z[4,0,4]  R519      -2.5154781341552734e-01
    z[4,0,4]  R520      2.3446790874004364e-02
    z[4,0,4]  R521      -4.3253622949123383e-02
    z[4,0,4]  R522      -7.5459247827529907e-01
    z[4,0,4]  R523      -2.3766717314720154e-01
    z[4,0,4]  R524      1.6381217539310455e-01
    z[4,0,4]  R525      2.7178052067756653e-01
    z[4,0,4]  R526      2.5117889046669006e-01
    z[4,0,4]  R527      -3.7221035361289978e-01
    z[4,0,4]  R528      -4.3140459060668945e-01
    z[4,0,4]  R529      1.1651613563299179e-01
    z[4,0,4]  R530      -0.594077467918396
    z[4,0,4]  R531      -4.7356334328651428e-01
    z[4,0,4]  R532      -6.4592367410659790e-01
    z[4,0,4]  R533      -1.8489469587802887e-01
    z[4,0,4]  R534      -3.5218980908393860e-01
    z[4,0,4]  R535      3.1666931509971619e-01
    z[4,0,4]  R536      -8.3939999341964722e-02
    z[4,0,4]  R537      3.5732370615005493e-01
    z[4,0,4]  R538      -2.0779301226139069e-01
    z[4,0,4]  R539      -5.6297097355127335e-02
    z[4,0,4]  R540      0.0520341582596302
    z[4,0,4]  R541      4.5179638266563416e-01
    z[4,0,4]  R542      1.8847376108169556e-01
    z[4,0,4]  R543      4.7834178805351257e-01
    z[4,0,4]  R544      7.8083015978336334e-02
    z[4,0,4]  R545      6.0871785879135132e-01
    z[4,0,4]  R546      -1.9667983055114746e-02
    z[4,0,4]  R547      2.3853531479835510e-01
    z[4,0,4]  R548      -3.9662539958953857e-01
    z[4,0,4]  R549      -1.1603917926549911e-01
    z[4,0,4]  R550      5.0484424829483032e-01
    z[4,0,4]  R551      -2.9431957751512527e-02
    z[4,0,4]  R552      -1.1342797428369522e-01
    z[4,0,4]  R553      -4.3735250830650330e-02
    z[4,0,4]  R554      -4.9066543579101562e-02
    z[4,0,4]  R555      1.7202247679233551e-01
    z[4,0,4]  R556      2.0369161665439606e-01
    z[4,0,4]  R557      1.4570695161819458e-01
    z[4,0,4]  R558      0.510697066783905
    z[4,0,4]  R559      4.2817533016204834e-01
    z[4,0,4]  R560      -6.2248710542917252e-02
    z[4,0,4]  R561      -1.7212116718292236e-01
    z[4,0,4]  R562      -1.5582512319087982e-01
    z[4,0,4]  R563      -2.1015605330467224e-01
    z[4,0,4]  R564      -1.9098210334777832e-01
    z[4,0,4]  R565      5.4872775077819824e-01
    z[4,0,4]  R566      -1.6331200301647186e-01
    z[4,0,4]  R567      4.4019460678100586e-01
    z[4,0,4]  R568      -1.5691466629505157e-02
    z[4,0,4]  R569      1.5748563408851624e-01
    z[4,0,4]  R570      1.0603963583707809e-01
    z[4,0,4]  R571      2.3172182962298393e-02
    z[4,0,4]  R572      -1.8282647430896759e-01
    z[4,0,4]  R573      3.6729222536087036e-01
    z[4,0,4]  R574      3.0288836359977722e-01
    z[4,0,4]  R575      2.7664214372634888e-01
    z[4,0,4]  R576      3.7263301014900208e-01
    z[4,0,4]  R577      6.0452502965927124e-01
    z[4,0,4]  R578      -1.9241786003112793e-01
    z[4,0,4]  R579      3.1464549899101257e-01
    z[4,0,4]  R580      -6.0030579566955566e-02
    z[4,0,4]  R581      -8.0049656331539154e-02
    z[4,0,4]  R582      -6.9107718765735626e-02
    z[4,0,4]  R583      1.2726886570453644e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R440      -1
    z[4,0,5]  R441      1
    z[4,0,5]  R444      4.3996194005012512e-01
    z[4,0,5]  R445      1.3638377189636230e-01
    z[4,0,5]  R446      1.2953966856002808e-01
    z[4,0,5]  R447      -2.9613199830055237e-01
    z[4,0,5]  R448      3.4899991750717163e-01
    z[4,0,5]  R449      5.9517753124237061e-01
    z[4,0,5]  R450      2.3161128163337708e-01
    z[4,0,5]  R451      -4.0721100568771362e-01
    z[4,0,5]  R452      -3.4148707985877991e-01
    z[4,0,5]  R453      -3.5778522491455078e-01
    z[4,0,5]  R454      2.3346321284770966e-01
    z[4,0,5]  R455      2.4932387471199036e-01
    z[4,0,5]  R456      -0.468799889087677
    z[4,0,5]  R457      -5.3434497117996216e-01
    z[4,0,5]  R458      -2.7919512987136841e-01
    z[4,0,5]  R459      -1.7638374119997025e-02
    z[4,0,5]  R460      2.4123069643974304e-01
    z[4,0,5]  R461      4.2480829358100891e-01
    z[4,0,5]  R462      3.2849079370498657e-01
    z[4,0,5]  R463      4.7065045684576035e-02
    z[4,0,5]  R464      -4.1814845800399780e-01
    z[4,0,5]  R465      -1.1946523189544678e-01
    z[4,0,5]  R466      2.0657652616500854e-01
    z[4,0,5]  R467      3.6275589466094971e-01
    z[4,0,5]  R468      -2.6349839568138123e-01
    z[4,0,5]  R469      -2.0331963896751404e-01
    z[4,0,5]  R470      -1.1794500052928925e-01
    z[4,0,5]  R471      -2.4451753497123718e-01
    z[4,0,5]  R472      -1.9577954709529877e-01
    z[4,0,5]  R473      -1.5811967849731445e-01
    z[4,0,5]  R474      -1.3639576733112335e-01
    z[4,0,5]  R475      -1.7367477715015411e-01
    z[4,0,5]  R476      -7.1926325559616089e-02
    z[4,0,5]  R477      5.8834481984376907e-02
    z[4,0,5]  R478      -3.8575258851051331e-01
    z[4,0,5]  R479      1.8640126287937164e-01
    z[4,0,5]  R480      -1.9208908081054688e-01
    z[4,0,5]  R481      9.4959894195199013e-03
    z[4,0,5]  R482      -4.9050965905189514e-01
    z[4,0,5]  R483      -1.8015022575855255e-01
    z[4,0,5]  R484      1.3386167585849762e-01
    z[4,0,5]  R485      1.9392508268356323e-01
    z[4,0,5]  R486      -1.4710029959678650e-01
    z[4,0,5]  R487      3.9358285069465637e-01
    z[4,0,5]  R488      1.0863801091909409e-01
    z[4,0,5]  R489      2.9338070750236511e-01
    z[4,0,5]  R490      -2.4932403862476349e-01
    z[4,0,5]  R491      0.0312016773968935
    z[4,0,5]  R492      -1.0448420047760010e-01
    z[4,0,5]  R493      -2.6090928912162781e-01
    z[4,0,5]  R494      -4.5123159885406494e-01
    z[4,0,5]  R495      1.0680218786001205e-01
    z[4,0,5]  R496      3.6879318952560425e-01
    z[4,0,5]  R497      3.6878335475921631e-01
    z[4,0,5]  R498      4.9595287442207336e-01
    z[4,0,5]  R499      0.0912671834230423
    z[4,0,5]  R500      -8.0275140702724457e-02
    z[4,0,5]  R501      -4.5369642972946167e-01
    z[4,0,5]  R502      -2.5563132762908936e-01
    z[4,0,5]  R503      -2.3328320682048798e-01
    z[4,0,5]  R504      -3.4196230769157410e-01
    z[4,0,5]  R505      4.2532852292060852e-01
    z[4,0,5]  R506      6.9031155109405518e-01
    z[4,0,5]  R507      -1.7529079318046570e-01
    z[4,0,5]  R508      7.0834594964981079e-01
    z[4,0,5]  R509      -0.0642034187912941
    z[4,0,5]  R510      -2.3047627508640289e-01
    z[4,0,5]  R511      2.0053030550479889e-01
    z[4,0,5]  R512      4.4623672962188721e-01
    z[4,0,5]  R513      -5.2082806825637817e-01
    z[4,0,5]  R514      -1.2185101397335529e-02
    z[4,0,5]  R515      -1.5581482648849487e-01
    z[4,0,5]  R516      1.8800030648708344e-01
    z[4,0,5]  R517      -5.2067607641220093e-02
    z[4,0,5]  R518      -9.7791932523250580e-02
    z[4,0,5]  R519      -1.1437275260686874e-01
    z[4,0,5]  R520      -4.0624892711639404e-01
    z[4,0,5]  R521      -2.7359002828598022e-01
    z[4,0,5]  R522      3.7848973274230957e-01
    z[4,0,5]  R523      -4.9476027488708496e-01
    z[4,0,5]  R524      -1.7492744326591492e-01
    z[4,0,5]  R525      3.2663241028785706e-01
    z[4,0,5]  R526      -1.6068068146705627e-01
    z[4,0,5]  R527      1.0876525938510895e-01
    z[4,0,5]  R528      -3.1814646720886230e-01
    z[4,0,5]  R529      2.4606071412563324e-01
    z[4,0,5]  R530      2.2672069072723389e-01
    z[4,0,5]  R531      4.3682102113962173e-02
    z[4,0,5]  R532      -2.5896748900413513e-01
    z[4,0,5]  R533      -2.4546343833208084e-02
    z[4,0,5]  R534      2.0347313582897186e-01
    z[4,0,5]  R535      4.8144187778234482e-02
    z[4,0,5]  R536      1.1396773904561996e-01
    z[4,0,5]  R537      -4.8214205889962614e-04
    z[4,0,5]  R538      -1.2855327129364014e-01
    z[4,0,5]  R539      2.3646475374698639e-01
    z[4,0,5]  R540      -1.7903022468090057e-01
    z[4,0,5]  R541      -2.6337078213691711e-01
    z[4,0,5]  R542      -1.2136088311672211e-01
    z[4,0,5]  R543      -3.8589175790548325e-02
    z[4,0,5]  R544      -5.4918748140335083e-01
    z[4,0,5]  R545      -1.4547589235007763e-02
    z[4,0,5]  R546      3.1602028012275696e-01
    z[4,0,5]  R547      0.510955274105072
    z[4,0,5]  R548      4.3707564473152161e-02
    z[4,0,5]  R549      1.1700762063264847e-01
    z[4,0,5]  R550      3.6962375044822693e-01
    z[4,0,5]  R551      4.0672972798347473e-01
    z[4,0,5]  R552      0.487321138381958
    z[4,0,5]  R553      5.1651990413665771e-01
    z[4,0,5]  R554      1.7020761966705322e-01
    z[4,0,5]  R555      -0.555191159248352
    z[4,0,5]  R556      -2.4275766313076019e-01
    z[4,0,5]  R557      2.4373291432857513e-01
    z[4,0,5]  R558      1.4232157170772552e-01
    z[4,0,5]  R559      -1.9320044666528702e-02
    z[4,0,5]  R560      0.00600613234564662
    z[4,0,5]  R561      5.5288810282945633e-02
    z[4,0,5]  R562      3.4333890676498413e-01
    z[4,0,5]  R563      -2.4083672463893890e-01
    z[4,0,5]  R564      -1.3166481256484985e-01
    z[4,0,5]  R565      3.3198451995849609e-01
    z[4,0,5]  R566      -4.2954063415527344e-01
    z[4,0,5]  R567      -5.1770615577697754e-01
    z[4,0,5]  R568      -1.2514603137969971e-01
    z[4,0,5]  R569      4.0554400533437729e-02
    z[4,0,5]  R570      -5.5437948554754257e-02
    z[4,0,5]  R571      6.7175167798995972e-01
    z[4,0,5]  R572      3.6202329397201538e-01
    z[4,0,5]  R573      2.5308024883270264e-01
    z[4,0,5]  R574      5.1114994287490845e-01
    z[4,0,5]  R575      3.5662892460823059e-01
    z[4,0,5]  R576      -7.1113187074661255e-01
    z[4,0,5]  R577      -4.1240021586418152e-01
    z[4,0,5]  R578      1.6171183437108994e-02
    z[4,0,5]  R579      3.2572954893112183e-01
    z[4,0,5]  R580      -3.2344126701354980e-01
    z[4,0,5]  R581      -3.8070490956306458e-01
    z[4,0,5]  R582      -1.5041446685791016e-01
    z[4,0,5]  R583      -2.4250821769237518e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R442      -1
    z[4,0,6]  R443      1
    z[4,0,6]  R444      1.2092879414558411e-01
    z[4,0,6]  R445      -2.3068059980869293e-01
    z[4,0,6]  R446      1.8213900923728943e-01
    z[4,0,6]  R447      3.6324393749237061e-01
    z[4,0,6]  R448      -1.2739732861518860e-01
    z[4,0,6]  R449      2.5307485461235046e-01
    z[4,0,6]  R450      -6.4232259988784790e-01
    z[4,0,6]  R451      -3.2322937250137329e-01
    z[4,0,6]  R452      1.9452343881130219e-01
    z[4,0,6]  R453      -0.318782240152359
    z[4,0,6]  R454      -6.1196070909500122e-01
    z[4,0,6]  R455      0.0861247330904007
    z[4,0,6]  R456      -2.1181281656026840e-02
    z[4,0,6]  R457      -8.9917801320552826e-02
    z[4,0,6]  R458      3.7962636351585388e-01
    z[4,0,6]  R459      2.5793942809104919e-01
    z[4,0,6]  R460      -1.3838969171047211e-01
    z[4,0,6]  R461      -2.6035052537918091e-01
    z[4,0,6]  R462      -2.1527664363384247e-01
    z[4,0,6]  R463      -1.9274526834487915e-01
    z[4,0,6]  R464      3.0488187074661255e-01
    z[4,0,6]  R465      -4.4549646973609924e-01
    z[4,0,6]  R466      1.5331450104713440e-01
    z[4,0,6]  R467      2.4077013134956360e-01
    z[4,0,6]  R468      -4.4894075393676758e-01
    z[4,0,6]  R469      -9.9124290049076080e-02
    z[4,0,6]  R470      -2.7765509486198425e-01
    z[4,0,6]  R471      4.5793330669403076e-01
    z[4,0,6]  R472      3.8040235638618469e-02
    z[4,0,6]  R473      2.1705214679241180e-01
    z[4,0,6]  R474      4.0557637810707092e-02
    z[4,0,6]  R475      -6.5903581678867340e-02
    z[4,0,6]  R476      5.5676591396331787e-01
    z[4,0,6]  R477      3.0735790729522705e-02
    z[4,0,6]  R478      -2.5501903891563416e-01
    z[4,0,6]  R479      2.4466918781399727e-02
    z[4,0,6]  R480      -6.1453711986541748e-01
    z[4,0,6]  R481      2.9225218296051025e-01
    z[4,0,6]  R482      -2.2415725886821747e-01
    z[4,0,6]  R483      -1.3678628206253052e-01
    z[4,0,6]  R484      5.1763290166854858e-01
    z[4,0,6]  R485      2.1968476474285126e-02
    z[4,0,6]  R486      2.5014054775238037e-01
    z[4,0,6]  R487      -6.4311426877975464e-01
    z[4,0,6]  R488      -1.0943056643009186e-01
    z[4,0,6]  R489      -3.7771737575531006e-01
    z[4,0,6]  R490      -4.3297520279884338e-01
    z[4,0,6]  R491      3.5609375685453415e-02
    z[4,0,6]  R492      -9.5370374619960785e-03
    z[4,0,6]  R493      2.8886166214942932e-01
    z[4,0,6]  R494      -4.4588279724121094e-01
    z[4,0,6]  R495      -5.8686070144176483e-02
    z[4,0,6]  R496      -4.7766438126564026e-01
    z[4,0,6]  R497      1.3234890997409821e-01
    z[4,0,6]  R498      4.6327769756317139e-01
    z[4,0,6]  R499      -2.1402609348297119e-01
    z[4,0,6]  R500      5.1475517451763153e-02
    z[4,0,6]  R501      -5.3200449794530869e-02
    z[4,0,6]  R502      1.6672787070274353e-01
    z[4,0,6]  R503      2.4014633893966675e-01
    z[4,0,6]  R504      1.1975119262933731e-01
    z[4,0,6]  R505      3.3051747083663940e-01
    z[4,0,6]  R506      -4.1553658246994019e-01
    z[4,0,6]  R507      -3.8281965255737305e-01
    z[4,0,6]  R508      3.4816227853298187e-02
    z[4,0,6]  R509      2.9397544264793396e-01
    z[4,0,6]  R510      -3.5653370618820190e-01
    z[4,0,6]  R511      -6.6828310489654541e-02
    z[4,0,6]  R512      2.8323090076446533e-01
    z[4,0,6]  R513      3.3723458647727966e-01
    z[4,0,6]  R514      3.4797167778015137e-01
    z[4,0,6]  R515      7.8672267496585846e-02
    z[4,0,6]  R516      1.8038541078567505e-01
    z[4,0,6]  R517      5.5920296907424927e-01
    z[4,0,6]  R518      2.2989727556705475e-01
    z[4,0,6]  R519      4.3185658752918243e-02
    z[4,0,6]  R520      -1.3556602597236633e-01
    z[4,0,6]  R521      -0.26072958111763
    z[4,0,6]  R522      -4.4539049267768860e-02
    z[4,0,6]  R523      2.6188188791275024e-01
    z[4,0,6]  R524      3.1884399056434631e-01
    z[4,0,6]  R525      -2.7227851748466492e-01
    z[4,0,6]  R526      -4.9142214655876160e-01
    z[4,0,6]  R527      -5.3596991300582886e-01
    z[4,0,6]  R528      1.1703094467520714e-02
    z[4,0,6]  R529      0.0146006615832448
    z[4,0,6]  R530      3.0798447132110596e-01
    z[4,0,6]  R531      -1.1080397292971611e-02
    z[4,0,6]  R532      -3.5698670148849487e-01
    z[4,0,6]  R533      -0.593315601348877
    z[4,0,6]  R534      8.8053919374942780e-02
    z[4,0,6]  R535      1.7209558188915253e-01
    z[4,0,6]  R536      3.4361341595649719e-01
    z[4,0,6]  R537      4.1705024242401123e-01
    z[4,0,6]  R538      4.0096101164817810e-01
    z[4,0,6]  R539      0.476885586977005
    z[4,0,6]  R540      4.9733448028564453e-01
    z[4,0,6]  R541      1.1575733125209808e-01
    z[4,0,6]  R542      1.4786525070667267e-01
    z[4,0,6]  R543      6.6876187920570374e-02
    z[4,0,6]  R544      -4.0917722508311272e-03
    z[4,0,6]  R545      -0.508971631526947
    z[4,0,6]  R546      1.0664170980453491e-01
    z[4,0,6]  R547      -2.7697867155075073e-01
    z[4,0,6]  R548      -3.8562685251235962e-01
    z[4,0,6]  R549      4.6044796705245972e-01
    z[4,0,6]  R550      7.3766958713531494e-01
    z[4,0,6]  R551      -1.9449464976787567e-01
    z[4,0,6]  R552      -2.8869467787444592e-03
    z[4,0,6]  R553      2.5344389677047729e-01
    z[4,0,6]  R554      6.1942511796951294e-01
    z[4,0,6]  R555      1.3202281668782234e-02
    z[4,0,6]  R556      1.4053647220134735e-01
    z[4,0,6]  R557      9.6981525421142578e-02
    z[4,0,6]  R558      4.5962461829185486e-01
    z[4,0,6]  R559      -1.0170855373144150e-01
    z[4,0,6]  R560      4.9914318323135376e-01
    z[4,0,6]  R561      -5.4759550094604492e-01
    z[4,0,6]  R562      1.4791837334632874e-01
    z[4,0,6]  R563      -0.552911639213562
    z[4,0,6]  R564      4.3932226300239563e-01
    z[4,0,6]  R565      5.0070071220397949e-01
    z[4,0,6]  R566      4.5036903023719788e-01
    z[4,0,6]  R567      -7.9545125365257263e-02
    z[4,0,6]  R568      -2.5002273917198181e-01
    z[4,0,6]  R569      -1.1861776560544968e-01
    z[4,0,6]  R570      1.0288503021001816e-01
    z[4,0,6]  R571      -1.9306229054927826e-01
    z[4,0,6]  R572      -0.326310396194458
    z[4,0,6]  R573      -1.0381789505481720e-01
    z[4,0,6]  R574      3.8189920783042908e-01
    z[4,0,6]  R575      -8.4024742245674133e-02
    z[4,0,6]  R576      -7.6818592846393585e-02
    z[4,0,6]  R577      -3.6519506573677063e-01
    z[4,0,6]  R578      4.8459663987159729e-01
    z[4,0,6]  R579      -3.4069389104843140e-02
    z[4,0,6]  R580      -9.3032263219356537e-02
    z[4,0,6]  R581      1.1360388994216919e-01
    z[4,0,6]  R582      -6.3811009749770164e-03
    z[4,0,6]  R583      3.1372848898172379e-02
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R584      -1
    z[0,5,0]  R585      1
    z[0,5,0]  R598      1.7100869119167328e-01
    z[0,5,0]  R599      5.5702650547027588e-01
    z[0,5,0]  R600      2.7477458119392395e-01
    z[0,5,0]  R601      0.0161072239279747
    z[0,5,0]  R602      2.3288173973560333e-01
    z[0,5,0]  R603      -4.1363561153411865e-01
    z[0,5,0]  R604      6.4785279333591461e-02
    z[0,5,0]  R605      -1.8434689939022064e-01
    z[0,5,0]  R606      2.4861548840999603e-01
    z[0,5,0]  R607      -3.9969703555107117e-01
    z[0,5,0]  R608      2.2537778317928314e-01
    z[0,5,0]  R609      -1.6907557845115662e-01
    z[0,5,0]  R610      3.8456264138221741e-01
    z[0,5,0]  R611      4.2606998234987259e-02
    z[0,5,0]  R612      1.5546953678131104e-01
    z[0,5,0]  R613      1.5194568037986755e-01
    z[0,5,0]  R614      9.8743841052055359e-02
    z[0,5,0]  R615      1.5659880638122559e-01
    z[0,5,0]  R616      4.4227278232574463e-01
    z[0,5,0]  R617      2.9409646987915039e-01
    z[0,5,0]  R618      6.7874324321746826e-01
    z[0,5,0]  R619      -2.6537823677062988e-01
    z[0,5,0]  R620      -8.6096087470650673e-03
    z[0,5,0]  R621      -1.4754873514175415e-01
    z[0,5,0]  R622      -1.3693846762180328e-01
    z[0,5,0]  R623      -6.1380922794342041e-01
    z[0,5,0]  R624      1.0916613787412643e-01
    z[0,5,0]  R625      -4.5338609814643860e-01
    z[0,5,0]  R626      -2.4482056498527527e-01
    z[0,5,0]  R627      -4.1672316193580627e-01
    z[0,5,0]  R628      7.4712353944778442e-01
    z[0,5,0]  R629      -4.8969838023185730e-01
    z[0,5,0]  R630      1.5534083545207977e-01
    z[0,5,0]  R631      -6.7616707086563110e-01
    z[0,5,0]  R632      -5.5766785144805908e-01
    z[0,5,0]  R633      2.8004637360572815e-01
    z[0,5,0]  R634      -1.9828376173973083e-01
    z[0,5,0]  R635      -8.5096381604671478e-02
    z[0,5,0]  R636      -0.393048495054245
    z[0,5,0]  R637      -1.2451636791229248e-01
    z[0,5,0]  R638      8.4260833263397217e-01
    z[0,5,0]  R639      2.4188110232353210e-01
    z[0,5,0]  R640      1.1477822810411453e-01
    z[0,5,0]  R641      -1.5447893738746643e-01
    z[0,5,0]  R642      -2.0491238683462143e-02
    z[0,5,0]  R643      1.6565407812595367e-01
    z[0,5,0]  R644      -1.5606896579265594e-01
    z[0,5,0]  R645      -3.8013646006584167e-01
    z[0,5,0]  R646      7.9477488994598389e-02
    z[0,5,0]  R647      1.5868206322193146e-01
    z[0,5,0]  R648      4.2231917381286621e-01
    z[0,5,0]  R649      -1.0622905939817429e-01
    z[0,5,0]  R650      -1.1425952613353729e-01
    z[0,5,0]  R651      -5.4170143604278564e-01
    z[0,5,0]  R652      -0.0959658995270729
    z[0,5,0]  R653      -1.1131045222282410e-01
    z[0,5,0]  R654      -5.2563261985778809e-01
    z[0,5,0]  R655      -6.2662810087203979e-01
    z[0,5,0]  R656      -0.735031247138977
    z[0,5,0]  R657      -6.4145928621292114e-01
    z[0,5,0]  R658      2.3319423198699951e-01
    z[0,5,0]  R659      3.1212385743856430e-02
    z[0,5,0]  R660      5.0146347284317017e-01
    z[0,5,0]  R661      -3.9650425314903259e-02
    z[0,5,0]  R662      3.2497721910476685e-01
    z[0,5,0]  R663      -4.7212675213813782e-01
    z[0,5,0]  R664      -3.6578410863876343e-01
    z[0,5,0]  R665      -2.6424747705459595e-01
    z[0,5,0]  R666      -4.2607155442237854e-01
    z[0,5,0]  R667      -4.7789987921714783e-01
    z[0,5,0]  R668      8.5370033979415894e-01
    z[0,5,0]  R669      7.5417733192443848e-01
    z[0,5,0]  R670      3.1483504176139832e-01
    z[0,5,0]  R671      5.8094173669815063e-01
    z[0,5,0]  R672      3.3036491274833679e-01
    z[0,5,0]  R673      6.6223418712615967e-01
    z[0,5,0]  R674      6.2715351581573486e-01
    z[0,5,0]  R675      5.4246836900711060e-01
    z[0,5,0]  R676      5.1179546117782593e-01
    z[0,5,0]  R677      -8.4287482500076294e-01
    z[0,5,0]  R678      5.6227583438158035e-02
    z[0,5,0]  R679      0.466959148645401
    z[0,5,0]  R680      4.4979009032249451e-01
    z[0,5,0]  R681      -2.8108501434326172e-01
    z[0,5,0]  R682      -2.9995483160018921e-01
    z[0,5,0]  R683      -0.602034330368042
    z[0,5,0]  R684      -1.1290226131677628e-01
    z[0,5,0]  R685      -1.3753145933151245e-01
    z[0,5,0]  R686      3.4224852919578552e-01
    z[0,5,0]  R687      -3.2606214284896851e-02
    z[0,5,0]  R688      1.9191227853298187e-01
    z[0,5,0]  R689      5.6973749399185181e-01
    z[0,5,0]  R690      5.6437432765960693e-01
    z[0,5,0]  R691      1.7782148718833923e-01
    z[0,5,0]  R692      6.2057304382324219e-01
    z[0,5,0]  R693      -4.2226108908653259e-01
    z[0,5,0]  R694      3.5937055945396423e-01
    z[0,5,0]  R695      -6.2501597404479980e-01
    z[0,5,0]  R696      -8.5845166444778442e-01
    z[0,5,0]  R697      -8.0257123708724976e-01
    z[0,5,0]  R698      5.3197562694549561e-01
    z[0,5,0]  R699      -0.451295405626297
    z[0,5,0]  R700      1.1656672693789005e-02
    z[0,5,0]  R701      -1.8033067882061005e-01
    z[0,5,0]  R702      3.9501029253005981e-01
    z[0,5,0]  R703      -8.9244616031646729e-01
    z[0,5,0]  R704      -9.4487506151199341e-01
    z[0,5,0]  R705      4.1145300865173340e-01
    z[0,5,0]  R706      -7.8592562675476074e-01
    z[0,5,0]  R707      -8.4297996759414673e-01
    z[0,5,0]  R708      8.0484122037887573e-01
    z[0,5,0]  R709      6.7473107576370239e-01
    z[0,5,0]  R710      -1.7581452429294586e-01
    z[0,5,0]  R711      -5.6763684749603271e-01
    z[0,5,0]  R712      3.8825148344039917e-01
    z[0,5,0]  R713      -8.9772361516952515e-01
    z[0,5,0]  R714      -9.2428743839263916e-01
    z[0,5,0]  R715      0.092893086373806
    z[0,5,0]  R716      7.4307754635810852e-02
    z[0,5,0]  R717      0.00360292661935091
    z[0,5,0]  R718      5.5153167247772217e-01
    z[0,5,0]  R719      4.4846823811531067e-01
    z[0,5,0]  R720      6.7341423034667969e-01
    z[0,5,0]  R721      1.3346501626074314e-02
    z[0,5,0]  R722      -1.4611147344112396e-01
    z[0,5,0]  R723      1.4871416985988617e-01
    z[0,5,0]  R724      -5.1569759845733643e-01
    z[0,5,0]  R725      4.4647574424743652e-01
    z[0,5,0]  R726      -8.4457063674926758e-01
    z[0,5,0]  R727      2.1097144484519958e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R586      -1
    z[0,5,1]  R587      1
    z[0,5,1]  R598      0.364397794008255
    z[0,5,1]  R599      0.59727543592453
    z[0,5,1]  R600      2.2113518416881561e-01
    z[0,5,1]  R601      5.1349848508834839e-01
    z[0,5,1]  R602      3.0965054035186768e-01
    z[0,5,1]  R603      5.9379267692565918e-01
    z[0,5,1]  R604      3.3784812688827515e-01
    z[0,5,1]  R605      4.4527783989906311e-01
    z[0,5,1]  R606      5.1362925767898560e-01
    z[0,5,1]  R607      -0.673263430595398
    z[0,5,1]  R608      -8.0944615602493286e-01
    z[0,5,1]  R609      -9.0964114665985107e-01
    z[0,5,1]  R610      -8.4404426813125610e-01
    z[0,5,1]  R611      -8.1154882907867432e-01
    z[0,5,1]  R612      -0.852180004119873
    z[0,5,1]  R613      -0.802143394947052
    z[0,5,1]  R614      -8.2273662090301514e-01
    z[0,5,1]  R615      -8.1920778751373291e-01
    z[0,5,1]  R616      -8.2633709907531738e-01
    z[0,5,1]  R617      -7.8579616546630859e-01
    z[0,5,1]  R618      2.2106523811817169e-01
    z[0,5,1]  R619      -5.3301107883453369e-01
    z[0,5,1]  R620      -9.3082493543624878e-01
    z[0,5,1]  R621      -0.639501690864563
    z[0,5,1]  R622      -7.5223529338836670e-01
    z[0,5,1]  R623      -0.611943244934082
    z[0,5,1]  R624      -7.5828351080417633e-02
    z[0,5,1]  R625      4.5163372159004211e-01
    z[0,5,1]  R626      2.5264132022857666e-01
    z[0,5,1]  R627      2.2036257386207581e-01
    z[0,5,1]  R628      -1.4292629063129425e-01
    z[0,5,1]  R629      -4.9250790476799011e-01
    z[0,5,1]  R630      -8.6433261632919312e-01
    z[0,5,1]  R631      -5.4577279090881348e-01
    z[0,5,1]  R632      -4.0878617763519287e-01
    z[0,5,1]  R633      -8.1643259525299072e-01
    z[0,5,1]  R634      -0.767369270324707
    z[0,5,1]  R635      -7.9266226291656494e-01
    z[0,5,1]  R636      -6.5824913978576660e-01
    z[0,5,1]  R637      -6.7528587579727173e-01
    z[0,5,1]  R638      1.8896445631980896e-01
    z[0,5,1]  R639      -4.8006501793861389e-01
    z[0,5,1]  R640      6.3000261783599854e-01
    z[0,5,1]  R641      6.3745582103729248e-01
    z[0,5,1]  R642      -9.4899761676788330e-01
    z[0,5,1]  R643      -9.0974158048629761e-01
    z[0,5,1]  R644      -9.3185275793075562e-01
    z[0,5,1]  R645      -4.6076655387878418e-01
    z[0,5,1]  R646      -6.8318635225296021e-01
    z[0,5,1]  R647      7.7136307954788208e-02
    z[0,5,1]  R648      -3.6867281794548035e-01
    z[0,5,1]  R649      -8.0004745721817017e-01
    z[0,5,1]  R650      -5.4384297132492065e-01
    z[0,5,1]  R651      -6.3243098556995392e-02
    z[0,5,1]  R652      -8.4444028139114380e-01
    z[0,5,1]  R653      -6.6713988780975342e-01
    z[0,5,1]  R654      -1.4305049180984497e-01
    z[0,5,1]  R655      -6.0757622122764587e-02
    z[0,5,1]  R656      -1.3459648191928864e-01
    z[0,5,1]  R657      -1.4120139181613922e-01
    z[0,5,1]  R658      -1.7011912167072296e-01
    z[0,5,1]  R659      -8.6639535427093506e-01
    z[0,5,1]  R660      -3.2488226890563965e-01
    z[0,5,1]  R661      1.2755459547042847e-01
    z[0,5,1]  R662      2.5161633267998695e-02
    z[0,5,1]  R663      7.1684432029724121e-01
    z[0,5,1]  R664      6.4251607656478882e-01
    z[0,5,1]  R665      8.6258381605148315e-01
    z[0,5,1]  R666      6.1642372608184814e-01
    z[0,5,1]  R667      5.8614504337310791e-01
    z[0,5,1]  R668      4.1367597877979279e-02
    z[0,5,1]  R669      -4.5734432339668274e-01
    z[0,5,1]  R670      5.3213047981262207e-01
    z[0,5,1]  R671      6.7137241363525391e-01
    z[0,5,1]  R672      -1.1954019963741302e-01
    z[0,5,1]  R673      5.8716768026351929e-01
    z[0,5,1]  R674      5.6276440620422363e-01
    z[0,5,1]  R675      6.0371154546737671e-01
    z[0,5,1]  R676      5.2918326854705811e-01
    z[0,5,1]  R677      -1.8518170714378357e-01
    z[0,5,1]  R678      -6.4127451181411743e-01
    z[0,5,1]  R679      -7.6162025332450867e-02
    z[0,5,1]  R680      -1.2833869457244873e-01
    z[0,5,1]  R681      3.6129736900329590e-01
    z[0,5,1]  R682      1.2361064553260803e-01
    z[0,5,1]  R683      3.2340753078460693e-01
    z[0,5,1]  R684      3.2106035947799683e-01
    z[0,5,1]  R685      4.2450046539306641e-01
    z[0,5,1]  R686      -7.9346306622028351e-02
    z[0,5,1]  R687      6.7537516355514526e-01
    z[0,5,1]  R688      -6.3041225075721741e-02
    z[0,5,1]  R689      -3.1974253058433533e-01
    z[0,5,1]  R690      -1.6818445920944214e-01
    z[0,5,1]  R691      0.717118501663208
    z[0,5,1]  R692      6.3430160284042358e-01
    z[0,5,1]  R693      7.5796818733215332e-01
    z[0,5,1]  R694      0.55787593126297
    z[0,5,1]  R695      5.8910822868347168e-01
    z[0,5,1]  R696      -1.9215551018714905e-01
    z[0,5,1]  R697      -1.7271377146244049e-01
    z[0,5,1]  R698      -2.1072624251246452e-02
    z[0,5,1]  R699      5.2754455804824829e-01
    z[0,5,1]  R700      8.9360141754150391e-01
    z[0,5,1]  R701      5.8269160985946655e-01
    z[0,5,1]  R702      4.3497118353843689e-01
    z[0,5,1]  R703      -2.5367984175682068e-01
    z[0,5,1]  R704      -2.0710146427154541e-01
    z[0,5,1]  R705      6.7916643619537354e-01
    z[0,5,1]  R706      -1.5099413692951202e-01
    z[0,5,1]  R707      -2.0377218723297119e-01
    z[0,5,1]  R708      -1.9711072742938995e-01
    z[0,5,1]  R709      -5.8636730909347534e-01
    z[0,5,1]  R710      4.9011856317520142e-01
    z[0,5,1]  R711      6.4338010549545288e-01
    z[0,5,1]  R712      5.1117801666259766e-01
    z[0,5,1]  R713      -2.8135138750076294e-01
    z[0,5,1]  R714      -9.9034756422042847e-02
    z[0,5,1]  R715      6.2226468324661255e-01
    z[0,5,1]  R716      0.603766918182373
    z[0,5,1]  R717      3.4518954157829285e-01
    z[0,5,1]  R718      -2.0193326473236084e-01
    z[0,5,1]  R719      2.3295342922210693e-01
    z[0,5,1]  R720      -2.8062483668327332e-01
    z[0,5,1]  R721      -0.732764482498169
    z[0,5,1]  R722      4.3333226442337036e-01
    z[0,5,1]  R723      -4.5113921165466309e-01
    z[0,5,1]  R724      7.9712599515914917e-01
    z[0,5,1]  R725      5.5384212732315063e-01
    z[0,5,1]  R726      -3.7367174029350281e-01
    z[0,5,1]  R727      5.1363587379455566e-01
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R588      -1
    z[0,5,2]  R589      1
    z[0,5,2]  R598      8.1947362422943115e-01
    z[0,5,2]  R599      6.5707027912139893e-02
    z[0,5,2]  R600      7.1899324655532837e-01
    z[0,5,2]  R601      5.0596338510513306e-01
    z[0,5,2]  R602      7.4975913763046265e-01
    z[0,5,2]  R603      5.8152687549591064e-01
    z[0,5,2]  R604      5.9093868732452393e-01
    z[0,5,2]  R605      7.2123205661773682e-01
    z[0,5,2]  R606      0.237759068608284
    z[0,5,2]  R607      4.4213291257619858e-03
    z[0,5,2]  R608      -3.4749990701675415e-01
    z[0,5,2]  R609      1.0062158852815628e-01
    z[0,5,2]  R610      1.5836326405405998e-02
    z[0,5,2]  R611      -1.9477196037769318e-01
    z[0,5,2]  R612      -1.5739586949348450e-01
    z[0,5,2]  R613      -2.1539069712162018e-01
    z[0,5,2]  R614      -1.7674618959426880e-01
    z[0,5,2]  R615      -1.3218337297439575e-01
    z[0,5,2]  R616      -2.0232470333576202e-01
    z[0,5,2]  R617      -2.4495676159858704e-01
    z[0,5,2]  R618      -2.9079401493072510e-01
    z[0,5,2]  R619      -8.0045007169246674e-02
    z[0,5,2]  R620      -6.1496417969465256e-02
    z[0,5,2]  R621      -0.351165771484375
    z[0,5,2]  R622      3.1412267684936523e-01
    z[0,5,2]  R623      -9.4151444733142853e-02
    z[0,5,2]  R624      -1.7917390167713165e-01
    z[0,5,2]  R625      -5.0620126724243164e-01
    z[0,5,2]  R626      -5.0399070978164673e-01
    z[0,5,2]  R627      -0.363391250371933
    z[0,5,2]  R628      -0.0655822828412056
    z[0,5,2]  R629      4.0806770324707031e-01
    z[0,5,2]  R630      3.1533968448638916e-01
    z[0,5,2]  R631      3.5414081811904907e-01
    z[0,5,2]  R632      -1.3705284893512726e-01
    z[0,5,2]  R633      -2.4633088707923889e-01
    z[0,5,2]  R634      -3.4460136294364929e-01
    z[0,5,2]  R635      1.4858037233352661e-01
    z[0,5,2]  R636      -4.9796235561370850e-01
    z[0,5,2]  R637      -3.4064370393753052e-01
    z[0,5,2]  R638      -6.6855573095381260e-03
    z[0,5,2]  R639      9.8814904689788818e-02
    z[0,5,2]  R640      -2.5099816918373108e-01
    z[0,5,2]  R641      -1.6343134641647339e-01
    z[0,5,2]  R642      -1.2185386568307877e-01
    z[0,5,2]  R643      -3.2223123311996460e-01
    z[0,5,2]  R644      -2.6625648140907288e-01
    z[0,5,2]  R645      1.0322643071413040e-01
    z[0,5,2]  R646      -4.9273246526718140e-01
    z[0,5,2]  R647      1.5159864723682404e-01
    z[0,5,2]  R648      2.7118667960166931e-01
    z[0,5,2]  R649      2.5700709223747253e-01
    z[0,5,2]  R650      1.4827635884284973e-01
    z[0,5,2]  R651      -1.3728782534599304e-01
    z[0,5,2]  R652      -6.3559204339981079e-02
    z[0,5,2]  R653      -5.7696157693862915e-01
    z[0,5,2]  R654      -6.8022996187210083e-01
    z[0,5,2]  R655      -5.4369497299194336e-01
    z[0,5,2]  R656      -0.588640034198761
    z[0,5,2]  R657      -6.3312333822250366e-01
    z[0,5,2]  R658      -4.4515646994113922e-02
    z[0,5,2]  R659      -6.7482399754226208e-03
    z[0,5,2]  R660      3.0095195770263672e-01
    z[0,5,2]  R661      -1.4778596162796021e-01
    z[0,5,2]  R662      -2.0170383155345917e-01
    z[0,5,2]  R663      2.2534139454364777e-01
    z[0,5,2]  R664      2.0300704240798950e-01
    z[0,5,2]  R665      3.9781138300895691e-02
    z[0,5,2]  R666      1.1528802663087845e-01
    z[0,5,2]  R667      1.4067694544792175e-01
    z[0,5,2]  R668      -2.7100220322608948e-01
    z[0,5,2]  R669      1.5467441082000732e-01
    z[0,5,2]  R670      1.6633830964565277e-01
    z[0,5,2]  R671      5.3234919905662537e-02
    z[0,5,2]  R672      7.6274409890174866e-02
    z[0,5,2]  R673      1.8836699426174164e-01
    z[0,5,2]  R674      9.8673895001411438e-02
    z[0,5,2]  R675      2.5525781512260437e-01
    z[0,5,2]  R676      4.3276599049568176e-01
    z[0,5,2]  R677      -0.0498683899641037
    z[0,5,2]  R678      -7.8489862382411957e-02
    z[0,5,2]  R679      -5.3640075027942657e-02
    z[0,5,2]  R680      2.6360502839088440e-01
    z[0,5,2]  R681      -0.015627421438694
    z[0,5,2]  R682      8.6594857275485992e-02
    z[0,5,2]  R683      2.0107630640268326e-02
    z[0,5,2]  R684      1.3167257606983185e-01
    z[0,5,2]  R685      2.3699508607387543e-01
    z[0,5,2]  R686      1.5364913642406464e-01
    z[0,5,2]  R687      9.4399198889732361e-02
    z[0,5,2]  R688      1.7879419028759003e-01
    z[0,5,2]  R689      2.7754855155944824e-01
    z[0,5,2]  R690      2.4555955827236176e-01
    z[0,5,2]  R691      1.0720190405845642e-01
    z[0,5,2]  R692      3.3301401138305664e-01
    z[0,5,2]  R693      -1.0970806330442429e-01
    z[0,5,2]  R694      6.7490625381469727e-01
    z[0,5,2]  R695      -2.3787726461887360e-01
    z[0,5,2]  R696      -1.8049703538417816e-01
    z[0,5,2]  R697      -1.7838594317436218e-01
    z[0,5,2]  R698      1.4784198999404907e-01
    z[0,5,2]  R699      -6.0977645218372345e-02
    z[0,5,2]  R700      3.1624818220734596e-03
    z[0,5,2]  R701      9.3205235898494720e-02
    z[0,5,2]  R702      5.4300391674041748e-01
    z[0,5,2]  R703      -2.6401841640472412e-01
    z[0,5,2]  R704      -1.2462133914232254e-01
    z[0,5,2]  R705      -1.3151612877845764e-01
    z[0,5,2]  R706      -1.8843559920787811e-01
    z[0,5,2]  R707      -2.3226018249988556e-01
    z[0,5,2]  R708      2.9141888022422791e-01
    z[0,5,2]  R709      2.0411417353898287e-03
    z[0,5,2]  R710      1.5482509136199951e-01
    z[0,5,2]  R711      -3.1458556652069092e-01
    z[0,5,2]  R712      6.1313390731811523e-01
    z[0,5,2]  R713      -1.8113890290260315e-01
    z[0,5,2]  R714      -2.2429031133651733e-01
    z[0,5,2]  R715      0.0309981070458889
    z[0,5,2]  R716      -1.3802379369735718e-02
    z[0,5,2]  R717      -6.5438352525234222e-02
    z[0,5,2]  R718      2.1384723484516144e-02
    z[0,5,2]  R719      -5.4391520097851753e-03
    z[0,5,2]  R720      1.1843720823526382e-01
    z[0,5,2]  R721      5.1741704344749451e-02
    z[0,5,2]  R722      -7.8318662941455841e-02
    z[0,5,2]  R723      -4.4125726819038391e-01
    z[0,5,2]  R724      -1.6930712759494781e-01
    z[0,5,2]  R725      0.553565502166748
    z[0,5,2]  R726      -2.5422206521034241e-01
    z[0,5,2]  R727      -7.4339248239994049e-02
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R590      -1
    z[0,5,3]  R591      1
    z[0,5,3]  R598      8.5660547018051147e-02
    z[0,5,3]  R599      2.7198737859725952e-01
    z[0,5,3]  R600      1.6805322468280792e-01
    z[0,5,3]  R601      2.0597749948501587e-01
    z[0,5,3]  R602      -1.6725739464163780e-02
    z[0,5,3]  R603      2.5260123610496521e-01
    z[0,5,3]  R604      1.8239581584930420e-01
    z[0,5,3]  R605      1.4585982263088226e-01
    z[0,5,3]  R606      -7.8262068331241608e-02
    z[0,5,3]  R607      1.1281822808086872e-02
    z[0,5,3]  R608      7.2790971025824547e-03
    z[0,5,3]  R609      4.0342751890420914e-02
    z[0,5,3]  R610      3.6678362637758255e-02
    z[0,5,3]  R611      -5.0640669651329517e-03
    z[0,5,3]  R612      -6.6116988658905029e-02
    z[0,5,3]  R613      2.4095119908452034e-02
    z[0,5,3]  R614      0.00373685359954834
    z[0,5,3]  R615      4.3788827024400234e-03
    z[0,5,3]  R616      -9.2257685959339142e-02
    z[0,5,3]  R617      -3.5431653261184692e-02
    z[0,5,3]  R618      -3.1329861283302307e-01
    z[0,5,3]  R619      9.6256427466869354e-02
    z[0,5,3]  R620      1.3446553051471710e-01
    z[0,5,3]  R621      2.2640231251716614e-01
    z[0,5,3]  R622      9.3737974762916565e-02
    z[0,5,3]  R623      2.7037955820560455e-02
    z[0,5,3]  R624      1.2076328694820404e-01
    z[0,5,3]  R625      -3.6070051789283752e-01
    z[0,5,3]  R626      -6.0981345176696777e-01
    z[0,5,3]  R627      -5.5927598476409912e-01
    z[0,5,3]  R628      4.4853985309600830e-02
    z[0,5,3]  R629      1.1449429392814636e-01
    z[0,5,3]  R630      9.5849819481372833e-02
    z[0,5,3]  R631      1.7167614400386810e-01
    z[0,5,3]  R632      1.0390021651983261e-01
    z[0,5,3]  R633      1.6754738986492157e-02
    z[0,5,3]  R634      4.7868089750409126e-03
    z[0,5,3]  R635      9.9124103784561157e-02
    z[0,5,3]  R636      1.4544361270964146e-02
    z[0,5,3]  R637      6.7582853138446808e-02
    z[0,5,3]  R638      -8.6285084486007690e-02
    z[0,5,3]  R639      1.9811521470546722e-01
    z[0,5,3]  R640      -3.3602741360664368e-01
    z[0,5,3]  R641      -2.7378478646278381e-01
    z[0,5,3]  R642      -7.5606115162372589e-02
    z[0,5,3]  R643      -2.4072457104921341e-02
    z[0,5,3]  R644      -1.0722508281469345e-01
    z[0,5,3]  R645      3.7878003716468811e-01
    z[0,5,3]  R646      1.1484664678573608e-01
    z[0,5,3]  R647      -8.5799562931060791e-01
    z[0,5,3]  R648      3.3663338422775269e-01
    z[0,5,3]  R649      2.6797682046890259e-01
    z[0,5,3]  R650      1.3685268163681030e-01
    z[0,5,3]  R651      1.2173786759376526e-01
    z[0,5,3]  R652      3.9388176053762436e-02
    z[0,5,3]  R653      5.8200873434543610e-02
    z[0,5,3]  R654      -0.351654976606369
    z[0,5,3]  R655      -3.7919861078262329e-01
    z[0,5,3]  R656      -2.6014360785484314e-01
    z[0,5,3]  R657      -3.0291095376014709e-01
    z[0,5,3]  R658      7.3701679706573486e-01
    z[0,5,3]  R659      -2.5402450561523438e-01
    z[0,5,3]  R660      4.9658772349357605e-01
    z[0,5,3]  R661      6.9725221395492554e-01
    z[0,5,3]  R662      3.9002344012260437e-01
    z[0,5,3]  R663      3.8173970580101013e-01
    z[0,5,3]  R664      4.8316952586174011e-01
    z[0,5,3]  R665      2.3315073549747467e-01
    z[0,5,3]  R666      5.0997787714004517e-01
    z[0,5,3]  R667      5.1632338762283325e-01
    z[0,5,3]  R668      -4.0670718997716904e-02
    z[0,5,3]  R669      -2.7080744504928589e-01
    z[0,5,3]  R670      0.29147869348526
    z[0,5,3]  R671      -1.2598313391208649e-01
    z[0,5,3]  R672      -2.4649222195148468e-01
    z[0,5,3]  R673      -3.7062340974807739e-01
    z[0,5,3]  R674      -2.8882077336311340e-01
    z[0,5,3]  R675      -4.2581576108932495e-01
    z[0,5,3]  R676      -2.8204908967018127e-01
    z[0,5,3]  R677      -2.2921943664550781e-01
    z[0,5,3]  R678      4.6231511235237122e-01
    z[0,5,3]  R679      5.7530981302261353e-01
    z[0,5,3]  R680      -3.0505027621984482e-02
    z[0,5,3]  R681      0.747157871723175
    z[0,5,3]  R682      6.8595755100250244e-01
    z[0,5,3]  R683      0.518020510673523
    z[0,5,3]  R684      4.2831945419311523e-01
    z[0,5,3]  R685      2.5988447666168213e-01
    z[0,5,3]  R686      1.5684854984283447e-01
    z[0,5,3]  R687      4.8331776261329651e-01
    z[0,5,3]  R688      6.0230517387390137e-01
    z[0,5,3]  R689      0.170273557305336
    z[0,5,3]  R690      0.139985129237175
    z[0,5,3]  R691      4.7819033265113831e-01
    z[0,5,3]  R692      -1.2592312693595886e-01
    z[0,5,3]  R693      7.7215313911437988e-02
    z[0,5,3]  R694      -1.8931412696838379e-01
    z[0,5,3]  R695      -3.3788260817527771e-01
    z[0,5,3]  R696      2.4014195799827576e-01
    z[0,5,3]  R697      -0.408211886882782
    z[0,5,3]  R698      -1.3090525567531586e-01
    z[0,5,3]  R699      5.7941854000091553e-01
    z[0,5,3]  R700      2.6890572905540466e-01
    z[0,5,3]  R701      4.4059857726097107e-01
    z[0,5,3]  R702      3.4857034683227539e-02
    z[0,5,3]  R703      2.7813278138637543e-02
    z[0,5,3]  R704      0.123990997672081
    z[0,5,3]  R705      -4.2569947242736816e-01
    z[0,5,3]  R706      8.7250366806983948e-02
    z[0,5,3]  R707      3.5420853644609451e-02
    z[0,5,3]  R708      -2.3585051298141479e-01
    z[0,5,3]  R709      9.0801984071731567e-02
    z[0,5,3]  R710      4.4118198752403259e-01
    z[0,5,3]  R711      0.0428534559905529
    z[0,5,3]  R712      2.3797746002674103e-01
    z[0,5,3]  R713      -3.7355388049036264e-03
    z[0,5,3]  R714      -2.3232486844062805e-01
    z[0,5,3]  R715      -0.715779185295105
    z[0,5,3]  R716      -7.7900612354278564e-01
    z[0,5,3]  R717      -0.923267126083374
    z[0,5,3]  R718      6.0994488000869751e-01
    z[0,5,3]  R719      7.4652409553527832e-01
    z[0,5,3]  R720      -1.1623510718345642e-01
    z[0,5,3]  R721      -0.557176411151886
    z[0,5,3]  R722      8.3671528100967407e-01
    z[0,5,3]  R723      5.7553607970476151e-02
    z[0,5,3]  R724      2.1857085824012756e-01
    z[0,5,3]  R725      -9.8399199545383453e-02
    z[0,5,3]  R726      2.3236854374408722e-01
    z[0,5,3]  R727      -7.4198341369628906e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R592      -1
    z[0,5,4]  R593      1
    z[0,5,4]  R598      1.6381217539310455e-01
    z[0,5,4]  R599      2.7178052067756653e-01
    z[0,5,4]  R600      2.5117889046669006e-01
    z[0,5,4]  R601      -3.7221035361289978e-01
    z[0,5,4]  R602      -4.3140459060668945e-01
    z[0,5,4]  R603      1.1651613563299179e-01
    z[0,5,4]  R604      -0.594077467918396
    z[0,5,4]  R605      -4.7356334328651428e-01
    z[0,5,4]  R606      -6.4592367410659790e-01
    z[0,5,4]  R607      -1.8489469587802887e-01
    z[0,5,4]  R608      -3.5218980908393860e-01
    z[0,5,4]  R609      3.1666931509971619e-01
    z[0,5,4]  R610      -8.3939999341964722e-02
    z[0,5,4]  R611      3.5732370615005493e-01
    z[0,5,4]  R612      -2.0779301226139069e-01
    z[0,5,4]  R613      -5.6297097355127335e-02
    z[0,5,4]  R614      0.0520341582596302
    z[0,5,4]  R615      4.5179638266563416e-01
    z[0,5,4]  R616      1.8847376108169556e-01
    z[0,5,4]  R617      4.7834178805351257e-01
    z[0,5,4]  R618      7.8083015978336334e-02
    z[0,5,4]  R619      6.0871785879135132e-01
    z[0,5,4]  R620      -1.9667983055114746e-02
    z[0,5,4]  R621      2.3853531479835510e-01
    z[0,5,4]  R622      -3.9662539958953857e-01
    z[0,5,4]  R623      -1.1603917926549911e-01
    z[0,5,4]  R624      5.0484424829483032e-01
    z[0,5,4]  R625      -2.9431957751512527e-02
    z[0,5,4]  R626      -1.1342797428369522e-01
    z[0,5,4]  R627      -4.3735250830650330e-02
    z[0,5,4]  R628      -4.9066543579101562e-02
    z[0,5,4]  R629      1.7202247679233551e-01
    z[0,5,4]  R630      2.0369161665439606e-01
    z[0,5,4]  R631      1.4570695161819458e-01
    z[0,5,4]  R632      0.510697066783905
    z[0,5,4]  R633      4.2817533016204834e-01
    z[0,5,4]  R634      -6.2248710542917252e-02
    z[0,5,4]  R635      -1.7212116718292236e-01
    z[0,5,4]  R636      -1.5582512319087982e-01
    z[0,5,4]  R637      -2.1015605330467224e-01
    z[0,5,4]  R638      -1.9098210334777832e-01
    z[0,5,4]  R639      5.4872775077819824e-01
    z[0,5,4]  R640      -1.6331200301647186e-01
    z[0,5,4]  R641      4.4019460678100586e-01
    z[0,5,4]  R642      -1.5691466629505157e-02
    z[0,5,4]  R643      1.5748563408851624e-01
    z[0,5,4]  R644      1.0603963583707809e-01
    z[0,5,4]  R645      2.3172182962298393e-02
    z[0,5,4]  R646      -1.8282647430896759e-01
    z[0,5,4]  R647      3.6729222536087036e-01
    z[0,5,4]  R648      3.0288836359977722e-01
    z[0,5,4]  R649      2.7664214372634888e-01
    z[0,5,4]  R650      3.7263301014900208e-01
    z[0,5,4]  R651      6.0452502965927124e-01
    z[0,5,4]  R652      -1.9241786003112793e-01
    z[0,5,4]  R653      3.1464549899101257e-01
    z[0,5,4]  R654      -6.0030579566955566e-02
    z[0,5,4]  R655      -8.0049656331539154e-02
    z[0,5,4]  R656      -6.9107718765735626e-02
    z[0,5,4]  R657      1.2726886570453644e-01
    z[0,5,4]  R658      -4.9649411439895630e-01
    z[0,5,4]  R659      1.1810000985860825e-01
    z[0,5,4]  R660      1.3310475647449493e-01
    z[0,5,4]  R661      8.4359832108020782e-02
    z[0,5,4]  R662      -4.6351256966590881e-01
    z[0,5,4]  R663      3.5189583897590637e-02
    z[0,5,4]  R664      -4.7536338679492474e-03
    z[0,5,4]  R665      -3.2184287905693054e-01
    z[0,5,4]  R666      -2.9385346174240112e-01
    z[0,5,4]  R667      1.8281698226928711e-01
    z[0,5,4]  R668      3.9884322881698608e-01
    z[0,5,4]  R669      -2.9343074560165405e-01
    z[0,5,4]  R670      3.8863825798034668e-01
    z[0,5,4]  R671      2.7067816257476807e-01
    z[0,5,4]  R672      4.4900488853454590e-01
    z[0,5,4]  R673      -8.3619825541973114e-02
    z[0,5,4]  R674      -2.3037960752844810e-02
    z[0,5,4]  R675      3.0328243970870972e-01
    z[0,5,4]  R676      3.40327387675643e-05
    z[0,5,4]  R677      -3.4083715081214905e-01
    z[0,5,4]  R678      -7.6309517025947571e-02
    z[0,5,4]  R679      5.1374042034149170e-01
    z[0,5,4]  R680      7.8781759738922119e-01
    z[0,5,4]  R681      4.6057271957397461e-01
    z[0,5,4]  R682      5.6694155931472778e-01
    z[0,5,4]  R683      -2.1398362517356873e-01
    z[0,5,4]  R684      4.3669030070304871e-01
    z[0,5,4]  R685      1.5598259866237640e-01
    z[0,5,4]  R686      3.8553100824356079e-01
    z[0,5,4]  R687      -1.8345834314823151e-01
    z[0,5,4]  R688      0.532383382320404
    z[0,5,4]  R689      -4.1586235165596008e-02
    z[0,5,4]  R690      -5.6828784942626953e-01
    z[0,5,4]  R691      2.2176005877554417e-03
    z[0,5,4]  R692      2.5891074538230896e-01
    z[0,5,4]  R693      3.6979028582572937e-01
    z[0,5,4]  R694      -1.9570612907409668e-01
    z[0,5,4]  R695      1.4526385068893433e-01
    z[0,5,4]  R696      -0.0417962521314621
    z[0,5,4]  R697      -4.1301891207695007e-02
    z[0,5,4]  R698      -3.4136778116226196e-01
    z[0,5,4]  R699      2.4779860675334930e-01
    z[0,5,4]  R700      1.4272421598434448e-01
    z[0,5,4]  R701      -2.8095895051956177e-01
    z[0,5,4]  R702      -3.1539839506149292e-01
    z[0,5,4]  R703      2.5853142142295837e-02
    z[0,5,4]  R704      -9.9958963692188263e-02
    z[0,5,4]  R705      -1.9605672359466553e-01
    z[0,5,4]  R706      -5.3230029344558716e-01
    z[0,5,4]  R707      2.0194664597511292e-01
    z[0,5,4]  R708      -1.1229781806468964e-01
    z[0,5,4]  R709      6.3080765306949615e-02
    z[0,5,4]  R710      -1.8942435085773468e-01
    z[0,5,4]  R711      -0.02197265625
    z[0,5,4]  R712      -3.7384482566267252e-03
    z[0,5,4]  R713      -1.7954805493354797e-01
    z[0,5,4]  R714      -8.7438896298408508e-02
    z[0,5,4]  R715      -1.2091485410928726e-01
    z[0,5,4]  R716      4.8610851168632507e-02
    z[0,5,4]  R717      -0.0319192036986351
    z[0,5,4]  R718      -2.9788926243782043e-01
    z[0,5,4]  R719      -7.0884138345718384e-02
    z[0,5,4]  R720      5.1153737306594849e-01
    z[0,5,4]  R721      -1.3111691176891327e-01
    z[0,5,4]  R722      2.8514513373374939e-01
    z[0,5,4]  R723      7.4714952707290649e-01
    z[0,5,4]  R724      -5.2574608474969864e-02
    z[0,5,4]  R725      -7.8257076442241669e-02
    z[0,5,4]  R726      -1.4152601361274719e-01
    z[0,5,4]  R727      1.4653564989566803e-01
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R594      -1
    z[0,5,5]  R595      1
    z[0,5,5]  R598      -1.7492744326591492e-01
    z[0,5,5]  R599      3.2663241028785706e-01
    z[0,5,5]  R600      -1.6068068146705627e-01
    z[0,5,5]  R601      1.0876525938510895e-01
    z[0,5,5]  R602      -3.1814646720886230e-01
    z[0,5,5]  R603      2.4606071412563324e-01
    z[0,5,5]  R604      2.2672069072723389e-01
    z[0,5,5]  R605      4.3682102113962173e-02
    z[0,5,5]  R606      -2.5896748900413513e-01
    z[0,5,5]  R607      -2.4546343833208084e-02
    z[0,5,5]  R608      2.0347313582897186e-01
    z[0,5,5]  R609      4.8144187778234482e-02
    z[0,5,5]  R610      1.1396773904561996e-01
    z[0,5,5]  R611      -4.8214205889962614e-04
    z[0,5,5]  R612      -1.2855327129364014e-01
    z[0,5,5]  R613      2.3646475374698639e-01
    z[0,5,5]  R614      -1.7903022468090057e-01
    z[0,5,5]  R615      -2.6337078213691711e-01
    z[0,5,5]  R616      -1.2136088311672211e-01
    z[0,5,5]  R617      -3.8589175790548325e-02
    z[0,5,5]  R618      -5.4918748140335083e-01
    z[0,5,5]  R619      -1.4547589235007763e-02
    z[0,5,5]  R620      3.1602028012275696e-01
    z[0,5,5]  R621      0.510955274105072
    z[0,5,5]  R622      4.3707564473152161e-02
    z[0,5,5]  R623      1.1700762063264847e-01
    z[0,5,5]  R624      3.6962375044822693e-01
    z[0,5,5]  R625      4.0672972798347473e-01
    z[0,5,5]  R626      0.487321138381958
    z[0,5,5]  R627      5.1651990413665771e-01
    z[0,5,5]  R628      1.7020761966705322e-01
    z[0,5,5]  R629      -0.555191159248352
    z[0,5,5]  R630      -2.4275766313076019e-01
    z[0,5,5]  R631      2.4373291432857513e-01
    z[0,5,5]  R632      1.4232157170772552e-01
    z[0,5,5]  R633      -1.9320044666528702e-02
    z[0,5,5]  R634      0.00600613234564662
    z[0,5,5]  R635      5.5288810282945633e-02
    z[0,5,5]  R636      3.4333890676498413e-01
    z[0,5,5]  R637      -2.4083672463893890e-01
    z[0,5,5]  R638      -1.3166481256484985e-01
    z[0,5,5]  R639      3.3198451995849609e-01
    z[0,5,5]  R640      -4.2954063415527344e-01
    z[0,5,5]  R641      -5.1770615577697754e-01
    z[0,5,5]  R642      -1.2514603137969971e-01
    z[0,5,5]  R643      4.0554400533437729e-02
    z[0,5,5]  R644      -5.5437948554754257e-02
    z[0,5,5]  R645      6.7175167798995972e-01
    z[0,5,5]  R646      3.6202329397201538e-01
    z[0,5,5]  R647      2.5308024883270264e-01
    z[0,5,5]  R648      5.1114994287490845e-01
    z[0,5,5]  R649      3.5662892460823059e-01
    z[0,5,5]  R650      -7.1113187074661255e-01
    z[0,5,5]  R651      -4.1240021586418152e-01
    z[0,5,5]  R652      1.6171183437108994e-02
    z[0,5,5]  R653      3.2572954893112183e-01
    z[0,5,5]  R654      -3.2344126701354980e-01
    z[0,5,5]  R655      -3.8070490956306458e-01
    z[0,5,5]  R656      -1.5041446685791016e-01
    z[0,5,5]  R657      -2.4250821769237518e-01
    z[0,5,5]  R658      -7.8130595386028290e-02
    z[0,5,5]  R659      1.4234589040279388e-01
    z[0,5,5]  R660      -3.3693760633468628e-01
    z[0,5,5]  R661      5.5766922235488892e-01
    z[0,5,5]  R662      6.7910814285278320e-01
    z[0,5,5]  R663      -1.8487884104251862e-01
    z[0,5,5]  R664      1.3950876891613007e-01
    z[0,5,5]  R665      5.5017095059156418e-02
    z[0,5,5]  R666      2.2003208100795746e-01
    z[0,5,5]  R667      3.1087648868560791e-01
    z[0,5,5]  R668      -1.1001148819923401e-01
    z[0,5,5]  R669      8.1487350165843964e-02
    z[0,5,5]  R670      -5.5850189924240112e-01
    z[0,5,5]  R671      3.2151535153388977e-01
    z[0,5,5]  R672      4.4339734315872192e-01
    z[0,5,5]  R673      -1.7229861021041870e-01
    z[0,5,5]  R674      1.3593678176403046e-01
    z[0,5,5]  R675      3.6164857447147369e-02
    z[0,5,5]  R676      2.2967378795146942e-01
    z[0,5,5]  R677      -2.3985219001770020e-01
    z[0,5,5]  R678      5.4262804985046387e-01
    z[0,5,5]  R679      3.1515711545944214e-01
    z[0,5,5]  R680      -2.7135422825813293e-01
    z[0,5,5]  R681      -1.4030887186527252e-01
    z[0,5,5]  R682      -2.7354758977890015e-01
    z[0,5,5]  R683      -3.7637513875961304e-01
    z[0,5,5]  R684      -0.635583221912384
    z[0,5,5]  R685      -7.9247075319290161e-01
    z[0,5,5]  R686      -5.3739106655120850e-01
    z[0,5,5]  R687      -4.6171960234642029e-01
    z[0,5,5]  R688      -4.7379118204116821e-01
    z[0,5,5]  R689      -6.2867230176925659e-01
    z[0,5,5]  R690      -4.7461655735969543e-01
    z[0,5,5]  R691      -3.1075629591941833e-01
    z[0,5,5]  R692      -0.0666750892996788
    z[0,5,5]  R693      1.2726147472858429e-01
    z[0,5,5]  R694      -1.4552277512848377e-02
    z[0,5,5]  R695      2.5573673844337463e-01
    z[0,5,5]  R696      -2.8836706653237343e-02
    z[0,5,5]  R697      -3.0305409431457520e-01
    z[0,5,5]  R698      1.4619396626949310e-01
    z[0,5,5]  R699      8.3432635292410851e-03
    z[0,5,5]  R700      -3.1873792409896851e-01
    z[0,5,5]  R701      -0.412521094083786
    z[0,5,5]  R702      3.8313734531402588e-01
    z[0,5,5]  R703      2.5273540616035461e-01
    z[0,5,5]  R704      -9.6924573183059692e-02
    z[0,5,5]  R705      3.6326035857200623e-01
    z[0,5,5]  R706      0.0503445640206337
    z[0,5,5]  R707      9.8870471119880676e-02
    z[0,5,5]  R708      -3.9066934585571289e-01
    z[0,5,5]  R709      4.0133652091026306e-01
    z[0,5,5]  R710      -5.3068125247955322e-01
    z[0,5,5]  R711      3.6689648032188416e-01
    z[0,5,5]  R712      3.8520210981369019e-01
    z[0,5,5]  R713      -2.2283075749874115e-01
    z[0,5,5]  R714      7.2753116488456726e-02
    z[0,5,5]  R715      -6.6692255437374115e-02
    z[0,5,5]  R716      -9.6957378089427948e-02
    z[0,5,5]  R717      1.5190611779689789e-01
    z[0,5,5]  R718      3.0472227931022644e-01
    z[0,5,5]  R719      2.5635793805122375e-01
    z[0,5,5]  R720      3.2530602812767029e-01
    z[0,5,5]  R721      2.4582125246524811e-01
    z[0,5,5]  R722      4.6398699283599854e-02
    z[0,5,5]  R723      -7.9258419573307037e-02
    z[0,5,5]  R724      -0.0792100802063942
    z[0,5,5]  R725      2.5551852583885193e-01
    z[0,5,5]  R726      -4.8923354595899582e-02
    z[0,5,5]  R727      6.8519569933414459e-02
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R596      -1
    z[0,5,6]  R597      1
    z[0,5,6]  R598      3.1884399056434631e-01
    z[0,5,6]  R599      -2.7227851748466492e-01
    z[0,5,6]  R600      -4.9142214655876160e-01
    z[0,5,6]  R601      -5.3596991300582886e-01
    z[0,5,6]  R602      1.1703094467520714e-02
    z[0,5,6]  R603      0.0146006615832448
    z[0,5,6]  R604      3.0798447132110596e-01
    z[0,5,6]  R605      -1.1080397292971611e-02
    z[0,5,6]  R606      -3.5698670148849487e-01
    z[0,5,6]  R607      -0.593315601348877
    z[0,5,6]  R608      8.8053919374942780e-02
    z[0,5,6]  R609      1.7209558188915253e-01
    z[0,5,6]  R610      3.4361341595649719e-01
    z[0,5,6]  R611      4.1705024242401123e-01
    z[0,5,6]  R612      4.0096101164817810e-01
    z[0,5,6]  R613      0.476885586977005
    z[0,5,6]  R614      4.9733448028564453e-01
    z[0,5,6]  R615      1.1575733125209808e-01
    z[0,5,6]  R616      1.4786525070667267e-01
    z[0,5,6]  R617      6.6876187920570374e-02
    z[0,5,6]  R618      -4.0917722508311272e-03
    z[0,5,6]  R619      -0.508971631526947
    z[0,5,6]  R620      1.0664170980453491e-01
    z[0,5,6]  R621      -2.7697867155075073e-01
    z[0,5,6]  R622      -3.8562685251235962e-01
    z[0,5,6]  R623      4.6044796705245972e-01
    z[0,5,6]  R624      7.3766958713531494e-01
    z[0,5,6]  R625      -1.9449464976787567e-01
    z[0,5,6]  R626      -2.8869467787444592e-03
    z[0,5,6]  R627      2.5344389677047729e-01
    z[0,5,6]  R628      6.1942511796951294e-01
    z[0,5,6]  R629      1.3202281668782234e-02
    z[0,5,6]  R630      1.4053647220134735e-01
    z[0,5,6]  R631      9.6981525421142578e-02
    z[0,5,6]  R632      4.5962461829185486e-01
    z[0,5,6]  R633      -1.0170855373144150e-01
    z[0,5,6]  R634      4.9914318323135376e-01
    z[0,5,6]  R635      -5.4759550094604492e-01
    z[0,5,6]  R636      1.4791837334632874e-01
    z[0,5,6]  R637      -0.552911639213562
    z[0,5,6]  R638      4.3932226300239563e-01
    z[0,5,6]  R639      5.0070071220397949e-01
    z[0,5,6]  R640      4.5036903023719788e-01
    z[0,5,6]  R641      -7.9545125365257263e-02
    z[0,5,6]  R642      -2.5002273917198181e-01
    z[0,5,6]  R643      -1.1861776560544968e-01
    z[0,5,6]  R644      1.0288503021001816e-01
    z[0,5,6]  R645      -1.9306229054927826e-01
    z[0,5,6]  R646      -0.326310396194458
    z[0,5,6]  R647      -1.0381789505481720e-01
    z[0,5,6]  R648      3.8189920783042908e-01
    z[0,5,6]  R649      -8.4024742245674133e-02
    z[0,5,6]  R650      -7.6818592846393585e-02
    z[0,5,6]  R651      -3.6519506573677063e-01
    z[0,5,6]  R652      4.8459663987159729e-01
    z[0,5,6]  R653      -3.4069389104843140e-02
    z[0,5,6]  R654      -9.3032263219356537e-02
    z[0,5,6]  R655      1.1360388994216919e-01
    z[0,5,6]  R656      -6.3811009749770164e-03
    z[0,5,6]  R657      3.1372848898172379e-02
    z[0,5,6]  R658      -3.4480971097946167e-01
    z[0,5,6]  R659      -3.8678294420242310e-01
    z[0,5,6]  R660      4.1781640052795410e-01
    z[0,5,6]  R661      3.9502507448196411e-01
    z[0,5,6]  R662      1.5786762535572052e-01
    z[0,5,6]  R663      -1.7694112658500671e-01
    z[0,5,6]  R664      -3.9903020858764648e-01
    z[0,5,6]  R665      1.5352848172187805e-01
    z[0,5,6]  R666      -1.7421814799308777e-01
    z[0,5,6]  R667      1.0770173370838165e-01
    z[0,5,6]  R668      -1.5234698355197906e-01
    z[0,5,6]  R669      1.7902514338493347e-01
    z[0,5,6]  R670      -2.0524072647094727e-01
    z[0,5,6]  R671      -1.2814530730247498e-01
    z[0,5,6]  R672      6.4170587062835693e-01
    z[0,5,6]  R673      8.4600344300270081e-02
    z[0,5,6]  R674      -4.2167651653289795e-01
    z[0,5,6]  R675      3.8686826825141907e-02
    z[0,5,6]  R676      -3.7207841873168945e-01
    z[0,5,6]  R677      1.6291812062263489e-01
    z[0,5,6]  R678      2.5581473112106323e-01
    z[0,5,6]  R679      -2.8113466501235962e-01
    z[0,5,6]  R680      1.2849248945713043e-01
    z[0,5,6]  R681      1.2341749854385853e-02
    z[0,5,6]  R682      1.4303857088088989e-01
    z[0,5,6]  R683      2.7706572413444519e-01
    z[0,5,6]  R684      -2.9784819483757019e-01
    z[0,5,6]  R685      1.5759864449501038e-01
    z[0,5,6]  R686      -6.2524974346160889e-01
    z[0,5,6]  R687      0.231205552816391
    z[0,5,6]  R688      -2.3779509961605072e-01
    z[0,5,6]  R689      -0.264913946390152
    z[0,5,6]  R690      1.5839265286922455e-01
    z[0,5,6]  R691      3.4261947870254517e-01
    z[0,5,6]  R692      -1.1964618414640427e-01
    z[0,5,6]  R693      2.7611851692199707e-01
    z[0,5,6]  R694      -1.7255797982215881e-01
    z[0,5,6]  R695      -7.1088634431362152e-02
    z[0,5,6]  R696      -3.6511799693107605e-01
    z[0,5,6]  R697      -1.8450810015201569e-01
    z[0,5,6]  R698      7.3461544513702393e-01
    z[0,5,6]  R699      3.4221544861793518e-01
    z[0,5,6]  R700      -8.4001637995243073e-02
    z[0,5,6]  R701      4.1955387592315674e-01
    z[0,5,6]  R702      -3.3530315756797791e-01
    z[0,5,6]  R703      -6.4525239169597626e-02
    z[0,5,6]  R704      -1.1844666302204132e-01
    z[0,5,6]  R705      2.2946875542402267e-02
    z[0,5,6]  R706      1.7470799386501312e-01
    z[0,5,6]  R707      3.7696731090545654e-01
    z[0,5,6]  R708      8.7144136428833008e-02
    z[0,5,6]  R709      -1.6616840660572052e-01
    z[0,5,6]  R710      4.3904036283493042e-01
    z[0,5,6]  R711      -1.6719458997249603e-01
    z[0,5,6]  R712      8.3646379411220551e-02
    z[0,5,6]  R713      -1.4737313613295555e-02
    z[0,5,6]  R714      1.3662087917327881e-01
    z[0,5,6]  R715      2.6793381571769714e-01
    z[0,5,6]  R716      -1.0554116219282150e-01
    z[0,5,6]  R717      -5.7056136429309845e-03
    z[0,5,6]  R718      3.1772968173027039e-01
    z[0,5,6]  R719      3.4137552976608276e-01
    z[0,5,6]  R720      2.6968577504158020e-01
    z[0,5,6]  R721      2.6858061552047729e-01
    z[0,5,6]  R722      3.4463077783584595e-02
    z[0,5,6]  R723      1.0873294621706009e-01
    z[0,5,6]  R724      -1.1475966870784760e-01
    z[0,5,6]  R725      -3.2617077231407166e-01
    z[0,5,6]  R726      -7.7605910599231720e-02
    z[0,5,6]  R727      -3.3081090450286865e-01
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R728      -1
    z[5,0,0]  R729      1
    z[5,0,0]  R742      2.3319423198699951e-01
    z[5,0,0]  R743      3.1212385743856430e-02
    z[5,0,0]  R744      5.0146347284317017e-01
    z[5,0,0]  R745      -3.9650425314903259e-02
    z[5,0,0]  R746      3.2497721910476685e-01
    z[5,0,0]  R747      -4.7212675213813782e-01
    z[5,0,0]  R748      -3.6578410863876343e-01
    z[5,0,0]  R749      -2.6424747705459595e-01
    z[5,0,0]  R750      -4.2607155442237854e-01
    z[5,0,0]  R751      -4.7789987921714783e-01
    z[5,0,0]  R752      8.5370033979415894e-01
    z[5,0,0]  R753      7.5417733192443848e-01
    z[5,0,0]  R754      3.1483504176139832e-01
    z[5,0,0]  R755      5.8094173669815063e-01
    z[5,0,0]  R756      3.3036491274833679e-01
    z[5,0,0]  R757      6.6223418712615967e-01
    z[5,0,0]  R758      6.2715351581573486e-01
    z[5,0,0]  R759      5.4246836900711060e-01
    z[5,0,0]  R760      5.1179546117782593e-01
    z[5,0,0]  R761      -8.4287482500076294e-01
    z[5,0,0]  R762      5.6227583438158035e-02
    z[5,0,0]  R763      0.466959148645401
    z[5,0,0]  R764      4.4979009032249451e-01
    z[5,0,0]  R765      -2.8108501434326172e-01
    z[5,0,0]  R766      -2.9995483160018921e-01
    z[5,0,0]  R767      -0.602034330368042
    z[5,0,0]  R768      -1.1290226131677628e-01
    z[5,0,0]  R769      -1.3753145933151245e-01
    z[5,0,0]  R770      3.4224852919578552e-01
    z[5,0,0]  R771      -3.2606214284896851e-02
    z[5,0,0]  R772      1.9191227853298187e-01
    z[5,0,0]  R773      5.6973749399185181e-01
    z[5,0,0]  R774      5.6437432765960693e-01
    z[5,0,0]  R775      1.7782148718833923e-01
    z[5,0,0]  R776      6.2057304382324219e-01
    z[5,0,0]  R777      -4.2226108908653259e-01
    z[5,0,0]  R778      3.5937055945396423e-01
    z[5,0,0]  R779      -6.2501597404479980e-01
    z[5,0,0]  R780      -8.5845166444778442e-01
    z[5,0,0]  R781      -8.0257123708724976e-01
    z[5,0,0]  R782      5.3197562694549561e-01
    z[5,0,0]  R783      -0.451295405626297
    z[5,0,0]  R784      1.1656672693789005e-02
    z[5,0,0]  R785      -1.8033067882061005e-01
    z[5,0,0]  R786      3.9501029253005981e-01
    z[5,0,0]  R787      -8.9244616031646729e-01
    z[5,0,0]  R788      -9.4487506151199341e-01
    z[5,0,0]  R789      4.1145300865173340e-01
    z[5,0,0]  R790      -7.8592562675476074e-01
    z[5,0,0]  R791      -8.4297996759414673e-01
    z[5,0,0]  R792      8.0484122037887573e-01
    z[5,0,0]  R793      6.7473107576370239e-01
    z[5,0,0]  R794      -1.7581452429294586e-01
    z[5,0,0]  R795      -5.6763684749603271e-01
    z[5,0,0]  R796      3.8825148344039917e-01
    z[5,0,0]  R797      -8.9772361516952515e-01
    z[5,0,0]  R798      -9.2428743839263916e-01
    z[5,0,0]  R799      0.092893086373806
    z[5,0,0]  R800      7.4307754635810852e-02
    z[5,0,0]  R801      0.00360292661935091
    z[5,0,0]  R802      5.5153167247772217e-01
    z[5,0,0]  R803      4.4846823811531067e-01
    z[5,0,0]  R804      6.7341423034667969e-01
    z[5,0,0]  R805      1.3346501626074314e-02
    z[5,0,0]  R806      -1.4611147344112396e-01
    z[5,0,0]  R807      1.4871416985988617e-01
    z[5,0,0]  R808      -5.1569759845733643e-01
    z[5,0,0]  R809      4.4647574424743652e-01
    z[5,0,0]  R810      -8.4457063674926758e-01
    z[5,0,0]  R811      2.1097144484519958e-01
    z[5,0,0]  R812      1.7100869119167328e-01
    z[5,0,0]  R813      5.5702650547027588e-01
    z[5,0,0]  R814      2.7477458119392395e-01
    z[5,0,0]  R815      0.0161072239279747
    z[5,0,0]  R816      2.3288173973560333e-01
    z[5,0,0]  R817      -4.1363561153411865e-01
    z[5,0,0]  R818      6.4785279333591461e-02
    z[5,0,0]  R819      -1.8434689939022064e-01
    z[5,0,0]  R820      2.4861548840999603e-01
    z[5,0,0]  R821      -3.9969703555107117e-01
    z[5,0,0]  R822      2.2537778317928314e-01
    z[5,0,0]  R823      -1.6907557845115662e-01
    z[5,0,0]  R824      3.8456264138221741e-01
    z[5,0,0]  R825      4.2606998234987259e-02
    z[5,0,0]  R826      1.5546953678131104e-01
    z[5,0,0]  R827      1.5194568037986755e-01
    z[5,0,0]  R828      9.8743841052055359e-02
    z[5,0,0]  R829      1.5659880638122559e-01
    z[5,0,0]  R830      4.4227278232574463e-01
    z[5,0,0]  R831      2.9409646987915039e-01
    z[5,0,0]  R832      6.7874324321746826e-01
    z[5,0,0]  R833      -2.6537823677062988e-01
    z[5,0,0]  R834      -8.6096087470650673e-03
    z[5,0,0]  R835      -1.4754873514175415e-01
    z[5,0,0]  R836      -1.3693846762180328e-01
    z[5,0,0]  R837      -6.1380922794342041e-01
    z[5,0,0]  R838      1.0916613787412643e-01
    z[5,0,0]  R839      -4.5338609814643860e-01
    z[5,0,0]  R840      -2.4482056498527527e-01
    z[5,0,0]  R841      -4.1672316193580627e-01
    z[5,0,0]  R842      7.4712353944778442e-01
    z[5,0,0]  R843      -4.8969838023185730e-01
    z[5,0,0]  R844      1.5534083545207977e-01
    z[5,0,0]  R845      -6.7616707086563110e-01
    z[5,0,0]  R846      -5.5766785144805908e-01
    z[5,0,0]  R847      2.8004637360572815e-01
    z[5,0,0]  R848      -1.9828376173973083e-01
    z[5,0,0]  R849      -8.5096381604671478e-02
    z[5,0,0]  R850      -0.393048495054245
    z[5,0,0]  R851      -1.2451636791229248e-01
    z[5,0,0]  R852      8.4260833263397217e-01
    z[5,0,0]  R853      2.4188110232353210e-01
    z[5,0,0]  R854      1.1477822810411453e-01
    z[5,0,0]  R855      -1.5447893738746643e-01
    z[5,0,0]  R856      -2.0491238683462143e-02
    z[5,0,0]  R857      1.6565407812595367e-01
    z[5,0,0]  R858      -1.5606896579265594e-01
    z[5,0,0]  R859      -3.8013646006584167e-01
    z[5,0,0]  R860      7.9477488994598389e-02
    z[5,0,0]  R861      1.5868206322193146e-01
    z[5,0,0]  R862      4.2231917381286621e-01
    z[5,0,0]  R863      -1.0622905939817429e-01
    z[5,0,0]  R864      -1.1425952613353729e-01
    z[5,0,0]  R865      -5.4170143604278564e-01
    z[5,0,0]  R866      -0.0959658995270729
    z[5,0,0]  R867      -1.1131045222282410e-01
    z[5,0,0]  R868      -5.2563261985778809e-01
    z[5,0,0]  R869      -6.2662810087203979e-01
    z[5,0,0]  R870      -0.735031247138977
    z[5,0,0]  R871      -6.4145928621292114e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R730      -1
    z[5,0,1]  R731      1
    z[5,0,1]  R742      -1.7011912167072296e-01
    z[5,0,1]  R743      -8.6639535427093506e-01
    z[5,0,1]  R744      -3.2488226890563965e-01
    z[5,0,1]  R745      1.2755459547042847e-01
    z[5,0,1]  R746      2.5161633267998695e-02
    z[5,0,1]  R747      7.1684432029724121e-01
    z[5,0,1]  R748      6.4251607656478882e-01
    z[5,0,1]  R749      8.6258381605148315e-01
    z[5,0,1]  R750      6.1642372608184814e-01
    z[5,0,1]  R751      5.8614504337310791e-01
    z[5,0,1]  R752      4.1367597877979279e-02
    z[5,0,1]  R753      -4.5734432339668274e-01
    z[5,0,1]  R754      5.3213047981262207e-01
    z[5,0,1]  R755      6.7137241363525391e-01
    z[5,0,1]  R756      -1.1954019963741302e-01
    z[5,0,1]  R757      5.8716768026351929e-01
    z[5,0,1]  R758      5.6276440620422363e-01
    z[5,0,1]  R759      6.0371154546737671e-01
    z[5,0,1]  R760      5.2918326854705811e-01
    z[5,0,1]  R761      -1.8518170714378357e-01
    z[5,0,1]  R762      -6.4127451181411743e-01
    z[5,0,1]  R763      -7.6162025332450867e-02
    z[5,0,1]  R764      -1.2833869457244873e-01
    z[5,0,1]  R765      3.6129736900329590e-01
    z[5,0,1]  R766      1.2361064553260803e-01
    z[5,0,1]  R767      3.2340753078460693e-01
    z[5,0,1]  R768      3.2106035947799683e-01
    z[5,0,1]  R769      4.2450046539306641e-01
    z[5,0,1]  R770      -7.9346306622028351e-02
    z[5,0,1]  R771      6.7537516355514526e-01
    z[5,0,1]  R772      -6.3041225075721741e-02
    z[5,0,1]  R773      -3.1974253058433533e-01
    z[5,0,1]  R774      -1.6818445920944214e-01
    z[5,0,1]  R775      0.717118501663208
    z[5,0,1]  R776      6.3430160284042358e-01
    z[5,0,1]  R777      7.5796818733215332e-01
    z[5,0,1]  R778      0.55787593126297
    z[5,0,1]  R779      5.8910822868347168e-01
    z[5,0,1]  R780      -1.9215551018714905e-01
    z[5,0,1]  R781      -1.7271377146244049e-01
    z[5,0,1]  R782      -2.1072624251246452e-02
    z[5,0,1]  R783      5.2754455804824829e-01
    z[5,0,1]  R784      8.9360141754150391e-01
    z[5,0,1]  R785      5.8269160985946655e-01
    z[5,0,1]  R786      4.3497118353843689e-01
    z[5,0,1]  R787      -2.5367984175682068e-01
    z[5,0,1]  R788      -2.0710146427154541e-01
    z[5,0,1]  R789      6.7916643619537354e-01
    z[5,0,1]  R790      -1.5099413692951202e-01
    z[5,0,1]  R791      -2.0377218723297119e-01
    z[5,0,1]  R792      -1.9711072742938995e-01
    z[5,0,1]  R793      -5.8636730909347534e-01
    z[5,0,1]  R794      4.9011856317520142e-01
    z[5,0,1]  R795      6.4338010549545288e-01
    z[5,0,1]  R796      5.1117801666259766e-01
    z[5,0,1]  R797      -2.8135138750076294e-01
    z[5,0,1]  R798      -9.9034756422042847e-02
    z[5,0,1]  R799      6.2226468324661255e-01
    z[5,0,1]  R800      0.603766918182373
    z[5,0,1]  R801      3.4518954157829285e-01
    z[5,0,1]  R802      -2.0193326473236084e-01
    z[5,0,1]  R803      2.3295342922210693e-01
    z[5,0,1]  R804      -2.8062483668327332e-01
    z[5,0,1]  R805      -0.732764482498169
    z[5,0,1]  R806      4.3333226442337036e-01
    z[5,0,1]  R807      -4.5113921165466309e-01
    z[5,0,1]  R808      7.9712599515914917e-01
    z[5,0,1]  R809      5.5384212732315063e-01
    z[5,0,1]  R810      -3.7367174029350281e-01
    z[5,0,1]  R811      5.1363587379455566e-01
    z[5,0,1]  R812      0.364397794008255
    z[5,0,1]  R813      0.59727543592453
    z[5,0,1]  R814      2.2113518416881561e-01
    z[5,0,1]  R815      5.1349848508834839e-01
    z[5,0,1]  R816      3.0965054035186768e-01
    z[5,0,1]  R817      5.9379267692565918e-01
    z[5,0,1]  R818      3.3784812688827515e-01
    z[5,0,1]  R819      4.4527783989906311e-01
    z[5,0,1]  R820      5.1362925767898560e-01
    z[5,0,1]  R821      -0.673263430595398
    z[5,0,1]  R822      -8.0944615602493286e-01
    z[5,0,1]  R823      -9.0964114665985107e-01
    z[5,0,1]  R824      -8.4404426813125610e-01
    z[5,0,1]  R825      -8.1154882907867432e-01
    z[5,0,1]  R826      -0.852180004119873
    z[5,0,1]  R827      -0.802143394947052
    z[5,0,1]  R828      -8.2273662090301514e-01
    z[5,0,1]  R829      -8.1920778751373291e-01
    z[5,0,1]  R830      -8.2633709907531738e-01
    z[5,0,1]  R831      -7.8579616546630859e-01
    z[5,0,1]  R832      2.2106523811817169e-01
    z[5,0,1]  R833      -5.3301107883453369e-01
    z[5,0,1]  R834      -9.3082493543624878e-01
    z[5,0,1]  R835      -0.639501690864563
    z[5,0,1]  R836      -7.5223529338836670e-01
    z[5,0,1]  R837      -0.611943244934082
    z[5,0,1]  R838      -7.5828351080417633e-02
    z[5,0,1]  R839      4.5163372159004211e-01
    z[5,0,1]  R840      2.5264132022857666e-01
    z[5,0,1]  R841      2.2036257386207581e-01
    z[5,0,1]  R842      -1.4292629063129425e-01
    z[5,0,1]  R843      -4.9250790476799011e-01
    z[5,0,1]  R844      -8.6433261632919312e-01
    z[5,0,1]  R845      -5.4577279090881348e-01
    z[5,0,1]  R846      -4.0878617763519287e-01
    z[5,0,1]  R847      -8.1643259525299072e-01
    z[5,0,1]  R848      -0.767369270324707
    z[5,0,1]  R849      -7.9266226291656494e-01
    z[5,0,1]  R850      -6.5824913978576660e-01
    z[5,0,1]  R851      -6.7528587579727173e-01
    z[5,0,1]  R852      1.8896445631980896e-01
    z[5,0,1]  R853      -4.8006501793861389e-01
    z[5,0,1]  R854      6.3000261783599854e-01
    z[5,0,1]  R855      6.3745582103729248e-01
    z[5,0,1]  R856      -9.4899761676788330e-01
    z[5,0,1]  R857      -9.0974158048629761e-01
    z[5,0,1]  R858      -9.3185275793075562e-01
    z[5,0,1]  R859      -4.6076655387878418e-01
    z[5,0,1]  R860      -6.8318635225296021e-01
    z[5,0,1]  R861      7.7136307954788208e-02
    z[5,0,1]  R862      -3.6867281794548035e-01
    z[5,0,1]  R863      -8.0004745721817017e-01
    z[5,0,1]  R864      -5.4384297132492065e-01
    z[5,0,1]  R865      -6.3243098556995392e-02
    z[5,0,1]  R866      -8.4444028139114380e-01
    z[5,0,1]  R867      -6.6713988780975342e-01
    z[5,0,1]  R868      -1.4305049180984497e-01
    z[5,0,1]  R869      -6.0757622122764587e-02
    z[5,0,1]  R870      -1.3459648191928864e-01
    z[5,0,1]  R871      -1.4120139181613922e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R732      -1
    z[5,0,2]  R733      1
    z[5,0,2]  R742      -4.4515646994113922e-02
    z[5,0,2]  R743      -6.7482399754226208e-03
    z[5,0,2]  R744      3.0095195770263672e-01
    z[5,0,2]  R745      -1.4778596162796021e-01
    z[5,0,2]  R746      -2.0170383155345917e-01
    z[5,0,2]  R747      2.2534139454364777e-01
    z[5,0,2]  R748      2.0300704240798950e-01
    z[5,0,2]  R749      3.9781138300895691e-02
    z[5,0,2]  R750      1.1528802663087845e-01
    z[5,0,2]  R751      1.4067694544792175e-01
    z[5,0,2]  R752      -2.7100220322608948e-01
    z[5,0,2]  R753      1.5467441082000732e-01
    z[5,0,2]  R754      1.6633830964565277e-01
    z[5,0,2]  R755      5.3234919905662537e-02
    z[5,0,2]  R756      7.6274409890174866e-02
    z[5,0,2]  R757      1.8836699426174164e-01
    z[5,0,2]  R758      9.8673895001411438e-02
    z[5,0,2]  R759      2.5525781512260437e-01
    z[5,0,2]  R760      4.3276599049568176e-01
    z[5,0,2]  R761      -0.0498683899641037
    z[5,0,2]  R762      -7.8489862382411957e-02
    z[5,0,2]  R763      -5.3640075027942657e-02
    z[5,0,2]  R764      2.6360502839088440e-01
    z[5,0,2]  R765      -0.015627421438694
    z[5,0,2]  R766      8.6594857275485992e-02
    z[5,0,2]  R767      2.0107630640268326e-02
    z[5,0,2]  R768      1.3167257606983185e-01
    z[5,0,2]  R769      2.3699508607387543e-01
    z[5,0,2]  R770      1.5364913642406464e-01
    z[5,0,2]  R771      9.4399198889732361e-02
    z[5,0,2]  R772      1.7879419028759003e-01
    z[5,0,2]  R773      2.7754855155944824e-01
    z[5,0,2]  R774      2.4555955827236176e-01
    z[5,0,2]  R775      1.0720190405845642e-01
    z[5,0,2]  R776      3.3301401138305664e-01
    z[5,0,2]  R777      -1.0970806330442429e-01
    z[5,0,2]  R778      6.7490625381469727e-01
    z[5,0,2]  R779      -2.3787726461887360e-01
    z[5,0,2]  R780      -1.8049703538417816e-01
    z[5,0,2]  R781      -1.7838594317436218e-01
    z[5,0,2]  R782      1.4784198999404907e-01
    z[5,0,2]  R783      -6.0977645218372345e-02
    z[5,0,2]  R784      3.1624818220734596e-03
    z[5,0,2]  R785      9.3205235898494720e-02
    z[5,0,2]  R786      5.4300391674041748e-01
    z[5,0,2]  R787      -2.6401841640472412e-01
    z[5,0,2]  R788      -1.2462133914232254e-01
    z[5,0,2]  R789      -1.3151612877845764e-01
    z[5,0,2]  R790      -1.8843559920787811e-01
    z[5,0,2]  R791      -2.3226018249988556e-01
    z[5,0,2]  R792      2.9141888022422791e-01
    z[5,0,2]  R793      2.0411417353898287e-03
    z[5,0,2]  R794      1.5482509136199951e-01
    z[5,0,2]  R795      -3.1458556652069092e-01
    z[5,0,2]  R796      6.1313390731811523e-01
    z[5,0,2]  R797      -1.8113890290260315e-01
    z[5,0,2]  R798      -2.2429031133651733e-01
    z[5,0,2]  R799      0.0309981070458889
    z[5,0,2]  R800      -1.3802379369735718e-02
    z[5,0,2]  R801      -6.5438352525234222e-02
    z[5,0,2]  R802      2.1384723484516144e-02
    z[5,0,2]  R803      -5.4391520097851753e-03
    z[5,0,2]  R804      1.1843720823526382e-01
    z[5,0,2]  R805      5.1741704344749451e-02
    z[5,0,2]  R806      -7.8318662941455841e-02
    z[5,0,2]  R807      -4.4125726819038391e-01
    z[5,0,2]  R808      -1.6930712759494781e-01
    z[5,0,2]  R809      0.553565502166748
    z[5,0,2]  R810      -2.5422206521034241e-01
    z[5,0,2]  R811      -7.4339248239994049e-02
    z[5,0,2]  R812      8.1947362422943115e-01
    z[5,0,2]  R813      6.5707027912139893e-02
    z[5,0,2]  R814      7.1899324655532837e-01
    z[5,0,2]  R815      5.0596338510513306e-01
    z[5,0,2]  R816      7.4975913763046265e-01
    z[5,0,2]  R817      5.8152687549591064e-01
    z[5,0,2]  R818      5.9093868732452393e-01
    z[5,0,2]  R819      7.2123205661773682e-01
    z[5,0,2]  R820      0.237759068608284
    z[5,0,2]  R821      4.4213291257619858e-03
    z[5,0,2]  R822      -3.4749990701675415e-01
    z[5,0,2]  R823      1.0062158852815628e-01
    z[5,0,2]  R824      1.5836326405405998e-02
    z[5,0,2]  R825      -1.9477196037769318e-01
    z[5,0,2]  R826      -1.5739586949348450e-01
    z[5,0,2]  R827      -2.1539069712162018e-01
    z[5,0,2]  R828      -1.7674618959426880e-01
    z[5,0,2]  R829      -1.3218337297439575e-01
    z[5,0,2]  R830      -2.0232470333576202e-01
    z[5,0,2]  R831      -2.4495676159858704e-01
    z[5,0,2]  R832      -2.9079401493072510e-01
    z[5,0,2]  R833      -8.0045007169246674e-02
    z[5,0,2]  R834      -6.1496417969465256e-02
    z[5,0,2]  R835      -0.351165771484375
    z[5,0,2]  R836      3.1412267684936523e-01
    z[5,0,2]  R837      -9.4151444733142853e-02
    z[5,0,2]  R838      -1.7917390167713165e-01
    z[5,0,2]  R839      -5.0620126724243164e-01
    z[5,0,2]  R840      -5.0399070978164673e-01
    z[5,0,2]  R841      -0.363391250371933
    z[5,0,2]  R842      -0.0655822828412056
    z[5,0,2]  R843      4.0806770324707031e-01
    z[5,0,2]  R844      3.1533968448638916e-01
    z[5,0,2]  R845      3.5414081811904907e-01
    z[5,0,2]  R846      -1.3705284893512726e-01
    z[5,0,2]  R847      -2.4633088707923889e-01
    z[5,0,2]  R848      -3.4460136294364929e-01
    z[5,0,2]  R849      1.4858037233352661e-01
    z[5,0,2]  R850      -4.9796235561370850e-01
    z[5,0,2]  R851      -3.4064370393753052e-01
    z[5,0,2]  R852      -6.6855573095381260e-03
    z[5,0,2]  R853      9.8814904689788818e-02
    z[5,0,2]  R854      -2.5099816918373108e-01
    z[5,0,2]  R855      -1.6343134641647339e-01
    z[5,0,2]  R856      -1.2185386568307877e-01
    z[5,0,2]  R857      -3.2223123311996460e-01
    z[5,0,2]  R858      -2.6625648140907288e-01
    z[5,0,2]  R859      1.0322643071413040e-01
    z[5,0,2]  R860      -4.9273246526718140e-01
    z[5,0,2]  R861      1.5159864723682404e-01
    z[5,0,2]  R862      2.7118667960166931e-01
    z[5,0,2]  R863      2.5700709223747253e-01
    z[5,0,2]  R864      1.4827635884284973e-01
    z[5,0,2]  R865      -1.3728782534599304e-01
    z[5,0,2]  R866      -6.3559204339981079e-02
    z[5,0,2]  R867      -5.7696157693862915e-01
    z[5,0,2]  R868      -6.8022996187210083e-01
    z[5,0,2]  R869      -5.4369497299194336e-01
    z[5,0,2]  R870      -0.588640034198761
    z[5,0,2]  R871      -6.3312333822250366e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R734      -1
    z[5,0,3]  R735      1
    z[5,0,3]  R742      7.3701679706573486e-01
    z[5,0,3]  R743      -2.5402450561523438e-01
    z[5,0,3]  R744      4.9658772349357605e-01
    z[5,0,3]  R745      6.9725221395492554e-01
    z[5,0,3]  R746      3.9002344012260437e-01
    z[5,0,3]  R747      3.8173970580101013e-01
    z[5,0,3]  R748      4.8316952586174011e-01
    z[5,0,3]  R749      2.3315073549747467e-01
    z[5,0,3]  R750      5.0997787714004517e-01
    z[5,0,3]  R751      5.1632338762283325e-01
    z[5,0,3]  R752      -4.0670718997716904e-02
    z[5,0,3]  R753      -2.7080744504928589e-01
    z[5,0,3]  R754      0.29147869348526
    z[5,0,3]  R755      -1.2598313391208649e-01
    z[5,0,3]  R756      -2.4649222195148468e-01
    z[5,0,3]  R757      -3.7062340974807739e-01
    z[5,0,3]  R758      -2.8882077336311340e-01
    z[5,0,3]  R759      -4.2581576108932495e-01
    z[5,0,3]  R760      -2.8204908967018127e-01
    z[5,0,3]  R761      -2.2921943664550781e-01
    z[5,0,3]  R762      4.6231511235237122e-01
    z[5,0,3]  R763      5.7530981302261353e-01
    z[5,0,3]  R764      -3.0505027621984482e-02
    z[5,0,3]  R765      0.747157871723175
    z[5,0,3]  R766      6.8595755100250244e-01
    z[5,0,3]  R767      0.518020510673523
    z[5,0,3]  R768      4.2831945419311523e-01
    z[5,0,3]  R769      2.5988447666168213e-01
    z[5,0,3]  R770      1.5684854984283447e-01
    z[5,0,3]  R771      4.8331776261329651e-01
    z[5,0,3]  R772      6.0230517387390137e-01
    z[5,0,3]  R773      0.170273557305336
    z[5,0,3]  R774      0.139985129237175
    z[5,0,3]  R775      4.7819033265113831e-01
    z[5,0,3]  R776      -1.2592312693595886e-01
    z[5,0,3]  R777      7.7215313911437988e-02
    z[5,0,3]  R778      -1.8931412696838379e-01
    z[5,0,3]  R779      -3.3788260817527771e-01
    z[5,0,3]  R780      2.4014195799827576e-01
    z[5,0,3]  R781      -0.408211886882782
    z[5,0,3]  R782      -1.3090525567531586e-01
    z[5,0,3]  R783      5.7941854000091553e-01
    z[5,0,3]  R784      2.6890572905540466e-01
    z[5,0,3]  R785      4.4059857726097107e-01
    z[5,0,3]  R786      3.4857034683227539e-02
    z[5,0,3]  R787      2.7813278138637543e-02
    z[5,0,3]  R788      0.123990997672081
    z[5,0,3]  R789      -4.2569947242736816e-01
    z[5,0,3]  R790      8.7250366806983948e-02
    z[5,0,3]  R791      3.5420853644609451e-02
    z[5,0,3]  R792      -2.3585051298141479e-01
    z[5,0,3]  R793      9.0801984071731567e-02
    z[5,0,3]  R794      4.4118198752403259e-01
    z[5,0,3]  R795      0.0428534559905529
    z[5,0,3]  R796      2.3797746002674103e-01
    z[5,0,3]  R797      -3.7355388049036264e-03
    z[5,0,3]  R798      -2.3232486844062805e-01
    z[5,0,3]  R799      -0.715779185295105
    z[5,0,3]  R800      -7.7900612354278564e-01
    z[5,0,3]  R801      -0.923267126083374
    z[5,0,3]  R802      6.0994488000869751e-01
    z[5,0,3]  R803      7.4652409553527832e-01
    z[5,0,3]  R804      -1.1623510718345642e-01
    z[5,0,3]  R805      -0.557176411151886
    z[5,0,3]  R806      8.3671528100967407e-01
    z[5,0,3]  R807      5.7553607970476151e-02
    z[5,0,3]  R808      2.1857085824012756e-01
    z[5,0,3]  R809      -9.8399199545383453e-02
    z[5,0,3]  R810      2.3236854374408722e-01
    z[5,0,3]  R811      -7.4198341369628906e-01
    z[5,0,3]  R812      8.5660547018051147e-02
    z[5,0,3]  R813      2.7198737859725952e-01
    z[5,0,3]  R814      1.6805322468280792e-01
    z[5,0,3]  R815      2.0597749948501587e-01
    z[5,0,3]  R816      -1.6725739464163780e-02
    z[5,0,3]  R817      2.5260123610496521e-01
    z[5,0,3]  R818      1.8239581584930420e-01
    z[5,0,3]  R819      1.4585982263088226e-01
    z[5,0,3]  R820      -7.8262068331241608e-02
    z[5,0,3]  R821      1.1281822808086872e-02
    z[5,0,3]  R822      7.2790971025824547e-03
    z[5,0,3]  R823      4.0342751890420914e-02
    z[5,0,3]  R824      3.6678362637758255e-02
    z[5,0,3]  R825      -5.0640669651329517e-03
    z[5,0,3]  R826      -6.6116988658905029e-02
    z[5,0,3]  R827      2.4095119908452034e-02
    z[5,0,3]  R828      0.00373685359954834
    z[5,0,3]  R829      4.3788827024400234e-03
    z[5,0,3]  R830      -9.2257685959339142e-02
    z[5,0,3]  R831      -3.5431653261184692e-02
    z[5,0,3]  R832      -3.1329861283302307e-01
    z[5,0,3]  R833      9.6256427466869354e-02
    z[5,0,3]  R834      1.3446553051471710e-01
    z[5,0,3]  R835      2.2640231251716614e-01
    z[5,0,3]  R836      9.3737974762916565e-02
    z[5,0,3]  R837      2.7037955820560455e-02
    z[5,0,3]  R838      1.2076328694820404e-01
    z[5,0,3]  R839      -3.6070051789283752e-01
    z[5,0,3]  R840      -6.0981345176696777e-01
    z[5,0,3]  R841      -5.5927598476409912e-01
    z[5,0,3]  R842      4.4853985309600830e-02
    z[5,0,3]  R843      1.1449429392814636e-01
    z[5,0,3]  R844      9.5849819481372833e-02
    z[5,0,3]  R845      1.7167614400386810e-01
    z[5,0,3]  R846      1.0390021651983261e-01
    z[5,0,3]  R847      1.6754738986492157e-02
    z[5,0,3]  R848      4.7868089750409126e-03
    z[5,0,3]  R849      9.9124103784561157e-02
    z[5,0,3]  R850      1.4544361270964146e-02
    z[5,0,3]  R851      6.7582853138446808e-02
    z[5,0,3]  R852      -8.6285084486007690e-02
    z[5,0,3]  R853      1.9811521470546722e-01
    z[5,0,3]  R854      -3.3602741360664368e-01
    z[5,0,3]  R855      -2.7378478646278381e-01
    z[5,0,3]  R856      -7.5606115162372589e-02
    z[5,0,3]  R857      -2.4072457104921341e-02
    z[5,0,3]  R858      -1.0722508281469345e-01
    z[5,0,3]  R859      3.7878003716468811e-01
    z[5,0,3]  R860      1.1484664678573608e-01
    z[5,0,3]  R861      -8.5799562931060791e-01
    z[5,0,3]  R862      3.3663338422775269e-01
    z[5,0,3]  R863      2.6797682046890259e-01
    z[5,0,3]  R864      1.3685268163681030e-01
    z[5,0,3]  R865      1.2173786759376526e-01
    z[5,0,3]  R866      3.9388176053762436e-02
    z[5,0,3]  R867      5.8200873434543610e-02
    z[5,0,3]  R868      -0.351654976606369
    z[5,0,3]  R869      -3.7919861078262329e-01
    z[5,0,3]  R870      -2.6014360785484314e-01
    z[5,0,3]  R871      -3.0291095376014709e-01
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R736      -1
    z[5,0,4]  R737      1
    z[5,0,4]  R742      -4.9649411439895630e-01
    z[5,0,4]  R743      1.1810000985860825e-01
    z[5,0,4]  R744      1.3310475647449493e-01
    z[5,0,4]  R745      8.4359832108020782e-02
    z[5,0,4]  R746      -4.6351256966590881e-01
    z[5,0,4]  R747      3.5189583897590637e-02
    z[5,0,4]  R748      -4.7536338679492474e-03
    z[5,0,4]  R749      -3.2184287905693054e-01
    z[5,0,4]  R750      -2.9385346174240112e-01
    z[5,0,4]  R751      1.8281698226928711e-01
    z[5,0,4]  R752      3.9884322881698608e-01
    z[5,0,4]  R753      -2.9343074560165405e-01
    z[5,0,4]  R754      3.8863825798034668e-01
    z[5,0,4]  R755      2.7067816257476807e-01
    z[5,0,4]  R756      4.4900488853454590e-01
    z[5,0,4]  R757      -8.3619825541973114e-02
    z[5,0,4]  R758      -2.3037960752844810e-02
    z[5,0,4]  R759      3.0328243970870972e-01
    z[5,0,4]  R760      3.40327387675643e-05
    z[5,0,4]  R761      -3.4083715081214905e-01
    z[5,0,4]  R762      -7.6309517025947571e-02
    z[5,0,4]  R763      5.1374042034149170e-01
    z[5,0,4]  R764      7.8781759738922119e-01
    z[5,0,4]  R765      4.6057271957397461e-01
    z[5,0,4]  R766      5.6694155931472778e-01
    z[5,0,4]  R767      -2.1398362517356873e-01
    z[5,0,4]  R768      4.3669030070304871e-01
    z[5,0,4]  R769      1.5598259866237640e-01
    z[5,0,4]  R770      3.8553100824356079e-01
    z[5,0,4]  R771      -1.8345834314823151e-01
    z[5,0,4]  R772      0.532383382320404
    z[5,0,4]  R773      -4.1586235165596008e-02
    z[5,0,4]  R774      -5.6828784942626953e-01
    z[5,0,4]  R775      2.2176005877554417e-03
    z[5,0,4]  R776      2.5891074538230896e-01
    z[5,0,4]  R777      3.6979028582572937e-01
    z[5,0,4]  R778      -1.9570612907409668e-01
    z[5,0,4]  R779      1.4526385068893433e-01
    z[5,0,4]  R780      -0.0417962521314621
    z[5,0,4]  R781      -4.1301891207695007e-02
    z[5,0,4]  R782      -3.4136778116226196e-01
    z[5,0,4]  R783      2.4779860675334930e-01
    z[5,0,4]  R784      1.4272421598434448e-01
    z[5,0,4]  R785      -2.8095895051956177e-01
    z[5,0,4]  R786      -3.1539839506149292e-01
    z[5,0,4]  R787      2.5853142142295837e-02
    z[5,0,4]  R788      -9.9958963692188263e-02
    z[5,0,4]  R789      -1.9605672359466553e-01
    z[5,0,4]  R790      -5.3230029344558716e-01
    z[5,0,4]  R791      2.0194664597511292e-01
    z[5,0,4]  R792      -1.1229781806468964e-01
    z[5,0,4]  R793      6.3080765306949615e-02
    z[5,0,4]  R794      -1.8942435085773468e-01
    z[5,0,4]  R795      -0.02197265625
    z[5,0,4]  R796      -3.7384482566267252e-03
    z[5,0,4]  R797      -1.7954805493354797e-01
    z[5,0,4]  R798      -8.7438896298408508e-02
    z[5,0,4]  R799      -1.2091485410928726e-01
    z[5,0,4]  R800      4.8610851168632507e-02
    z[5,0,4]  R801      -0.0319192036986351
    z[5,0,4]  R802      -2.9788926243782043e-01
    z[5,0,4]  R803      -7.0884138345718384e-02
    z[5,0,4]  R804      5.1153737306594849e-01
    z[5,0,4]  R805      -1.3111691176891327e-01
    z[5,0,4]  R806      2.8514513373374939e-01
    z[5,0,4]  R807      7.4714952707290649e-01
    z[5,0,4]  R808      -5.2574608474969864e-02
    z[5,0,4]  R809      -7.8257076442241669e-02
    z[5,0,4]  R810      -1.4152601361274719e-01
    z[5,0,4]  R811      1.4653564989566803e-01
    z[5,0,4]  R812      1.6381217539310455e-01
    z[5,0,4]  R813      2.7178052067756653e-01
    z[5,0,4]  R814      2.5117889046669006e-01
    z[5,0,4]  R815      -3.7221035361289978e-01
    z[5,0,4]  R816      -4.3140459060668945e-01
    z[5,0,4]  R817      1.1651613563299179e-01
    z[5,0,4]  R818      -0.594077467918396
    z[5,0,4]  R819      -4.7356334328651428e-01
    z[5,0,4]  R820      -6.4592367410659790e-01
    z[5,0,4]  R821      -1.8489469587802887e-01
    z[5,0,4]  R822      -3.5218980908393860e-01
    z[5,0,4]  R823      3.1666931509971619e-01
    z[5,0,4]  R824      -8.3939999341964722e-02
    z[5,0,4]  R825      3.5732370615005493e-01
    z[5,0,4]  R826      -2.0779301226139069e-01
    z[5,0,4]  R827      -5.6297097355127335e-02
    z[5,0,4]  R828      0.0520341582596302
    z[5,0,4]  R829      4.5179638266563416e-01
    z[5,0,4]  R830      1.8847376108169556e-01
    z[5,0,4]  R831      4.7834178805351257e-01
    z[5,0,4]  R832      7.8083015978336334e-02
    z[5,0,4]  R833      6.0871785879135132e-01
    z[5,0,4]  R834      -1.9667983055114746e-02
    z[5,0,4]  R835      2.3853531479835510e-01
    z[5,0,4]  R836      -3.9662539958953857e-01
    z[5,0,4]  R837      -1.1603917926549911e-01
    z[5,0,4]  R838      5.0484424829483032e-01
    z[5,0,4]  R839      -2.9431957751512527e-02
    z[5,0,4]  R840      -1.1342797428369522e-01
    z[5,0,4]  R841      -4.3735250830650330e-02
    z[5,0,4]  R842      -4.9066543579101562e-02
    z[5,0,4]  R843      1.7202247679233551e-01
    z[5,0,4]  R844      2.0369161665439606e-01
    z[5,0,4]  R845      1.4570695161819458e-01
    z[5,0,4]  R846      0.510697066783905
    z[5,0,4]  R847      4.2817533016204834e-01
    z[5,0,4]  R848      -6.2248710542917252e-02
    z[5,0,4]  R849      -1.7212116718292236e-01
    z[5,0,4]  R850      -1.5582512319087982e-01
    z[5,0,4]  R851      -2.1015605330467224e-01
    z[5,0,4]  R852      -1.9098210334777832e-01
    z[5,0,4]  R853      5.4872775077819824e-01
    z[5,0,4]  R854      -1.6331200301647186e-01
    z[5,0,4]  R855      4.4019460678100586e-01
    z[5,0,4]  R856      -1.5691466629505157e-02
    z[5,0,4]  R857      1.5748563408851624e-01
    z[5,0,4]  R858      1.0603963583707809e-01
    z[5,0,4]  R859      2.3172182962298393e-02
    z[5,0,4]  R860      -1.8282647430896759e-01
    z[5,0,4]  R861      3.6729222536087036e-01
    z[5,0,4]  R862      3.0288836359977722e-01
    z[5,0,4]  R863      2.7664214372634888e-01
    z[5,0,4]  R864      3.7263301014900208e-01
    z[5,0,4]  R865      6.0452502965927124e-01
    z[5,0,4]  R866      -1.9241786003112793e-01
    z[5,0,4]  R867      3.1464549899101257e-01
    z[5,0,4]  R868      -6.0030579566955566e-02
    z[5,0,4]  R869      -8.0049656331539154e-02
    z[5,0,4]  R870      -6.9107718765735626e-02
    z[5,0,4]  R871      1.2726886570453644e-01
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R738      -1
    z[5,0,5]  R739      1
    z[5,0,5]  R742      -7.8130595386028290e-02
    z[5,0,5]  R743      1.4234589040279388e-01
    z[5,0,5]  R744      -3.3693760633468628e-01
    z[5,0,5]  R745      5.5766922235488892e-01
    z[5,0,5]  R746      6.7910814285278320e-01
    z[5,0,5]  R747      -1.8487884104251862e-01
    z[5,0,5]  R748      1.3950876891613007e-01
    z[5,0,5]  R749      5.5017095059156418e-02
    z[5,0,5]  R750      2.2003208100795746e-01
    z[5,0,5]  R751      3.1087648868560791e-01
    z[5,0,5]  R752      -1.1001148819923401e-01
    z[5,0,5]  R753      8.1487350165843964e-02
    z[5,0,5]  R754      -5.5850189924240112e-01
    z[5,0,5]  R755      3.2151535153388977e-01
    z[5,0,5]  R756      4.4339734315872192e-01
    z[5,0,5]  R757      -1.7229861021041870e-01
    z[5,0,5]  R758      1.3593678176403046e-01
    z[5,0,5]  R759      3.6164857447147369e-02
    z[5,0,5]  R760      2.2967378795146942e-01
    z[5,0,5]  R761      -2.3985219001770020e-01
    z[5,0,5]  R762      5.4262804985046387e-01
    z[5,0,5]  R763      3.1515711545944214e-01
    z[5,0,5]  R764      -2.7135422825813293e-01
    z[5,0,5]  R765      -1.4030887186527252e-01
    z[5,0,5]  R766      -2.7354758977890015e-01
    z[5,0,5]  R767      -3.7637513875961304e-01
    z[5,0,5]  R768      -0.635583221912384
    z[5,0,5]  R769      -7.9247075319290161e-01
    z[5,0,5]  R770      -5.3739106655120850e-01
    z[5,0,5]  R771      -4.6171960234642029e-01
    z[5,0,5]  R772      -4.7379118204116821e-01
    z[5,0,5]  R773      -6.2867230176925659e-01
    z[5,0,5]  R774      -4.7461655735969543e-01
    z[5,0,5]  R775      -3.1075629591941833e-01
    z[5,0,5]  R776      -0.0666750892996788
    z[5,0,5]  R777      1.2726147472858429e-01
    z[5,0,5]  R778      -1.4552277512848377e-02
    z[5,0,5]  R779      2.5573673844337463e-01
    z[5,0,5]  R780      -2.8836706653237343e-02
    z[5,0,5]  R781      -3.0305409431457520e-01
    z[5,0,5]  R782      1.4619396626949310e-01
    z[5,0,5]  R783      8.3432635292410851e-03
    z[5,0,5]  R784      -3.1873792409896851e-01
    z[5,0,5]  R785      -0.412521094083786
    z[5,0,5]  R786      3.8313734531402588e-01
    z[5,0,5]  R787      2.5273540616035461e-01
    z[5,0,5]  R788      -9.6924573183059692e-02
    z[5,0,5]  R789      3.6326035857200623e-01
    z[5,0,5]  R790      0.0503445640206337
    z[5,0,5]  R791      9.8870471119880676e-02
    z[5,0,5]  R792      -3.9066934585571289e-01
    z[5,0,5]  R793      4.0133652091026306e-01
    z[5,0,5]  R794      -5.3068125247955322e-01
    z[5,0,5]  R795      3.6689648032188416e-01
    z[5,0,5]  R796      3.8520210981369019e-01
    z[5,0,5]  R797      -2.2283075749874115e-01
    z[5,0,5]  R798      7.2753116488456726e-02
    z[5,0,5]  R799      -6.6692255437374115e-02
    z[5,0,5]  R800      -9.6957378089427948e-02
    z[5,0,5]  R801      1.5190611779689789e-01
    z[5,0,5]  R802      3.0472227931022644e-01
    z[5,0,5]  R803      2.5635793805122375e-01
    z[5,0,5]  R804      3.2530602812767029e-01
    z[5,0,5]  R805      2.4582125246524811e-01
    z[5,0,5]  R806      4.6398699283599854e-02
    z[5,0,5]  R807      -7.9258419573307037e-02
    z[5,0,5]  R808      -0.0792100802063942
    z[5,0,5]  R809      2.5551852583885193e-01
    z[5,0,5]  R810      -4.8923354595899582e-02
    z[5,0,5]  R811      6.8519569933414459e-02
    z[5,0,5]  R812      -1.7492744326591492e-01
    z[5,0,5]  R813      3.2663241028785706e-01
    z[5,0,5]  R814      -1.6068068146705627e-01
    z[5,0,5]  R815      1.0876525938510895e-01
    z[5,0,5]  R816      -3.1814646720886230e-01
    z[5,0,5]  R817      2.4606071412563324e-01
    z[5,0,5]  R818      2.2672069072723389e-01
    z[5,0,5]  R819      4.3682102113962173e-02
    z[5,0,5]  R820      -2.5896748900413513e-01
    z[5,0,5]  R821      -2.4546343833208084e-02
    z[5,0,5]  R822      2.0347313582897186e-01
    z[5,0,5]  R823      4.8144187778234482e-02
    z[5,0,5]  R824      1.1396773904561996e-01
    z[5,0,5]  R825      -4.8214205889962614e-04
    z[5,0,5]  R826      -1.2855327129364014e-01
    z[5,0,5]  R827      2.3646475374698639e-01
    z[5,0,5]  R828      -1.7903022468090057e-01
    z[5,0,5]  R829      -2.6337078213691711e-01
    z[5,0,5]  R830      -1.2136088311672211e-01
    z[5,0,5]  R831      -3.8589175790548325e-02
    z[5,0,5]  R832      -5.4918748140335083e-01
    z[5,0,5]  R833      -1.4547589235007763e-02
    z[5,0,5]  R834      3.1602028012275696e-01
    z[5,0,5]  R835      0.510955274105072
    z[5,0,5]  R836      4.3707564473152161e-02
    z[5,0,5]  R837      1.1700762063264847e-01
    z[5,0,5]  R838      3.6962375044822693e-01
    z[5,0,5]  R839      4.0672972798347473e-01
    z[5,0,5]  R840      0.487321138381958
    z[5,0,5]  R841      5.1651990413665771e-01
    z[5,0,5]  R842      1.7020761966705322e-01
    z[5,0,5]  R843      -0.555191159248352
    z[5,0,5]  R844      -2.4275766313076019e-01
    z[5,0,5]  R845      2.4373291432857513e-01
    z[5,0,5]  R846      1.4232157170772552e-01
    z[5,0,5]  R847      -1.9320044666528702e-02
    z[5,0,5]  R848      0.00600613234564662
    z[5,0,5]  R849      5.5288810282945633e-02
    z[5,0,5]  R850      3.4333890676498413e-01
    z[5,0,5]  R851      -2.4083672463893890e-01
    z[5,0,5]  R852      -1.3166481256484985e-01
    z[5,0,5]  R853      3.3198451995849609e-01
    z[5,0,5]  R854      -4.2954063415527344e-01
    z[5,0,5]  R855      -5.1770615577697754e-01
    z[5,0,5]  R856      -1.2514603137969971e-01
    z[5,0,5]  R857      4.0554400533437729e-02
    z[5,0,5]  R858      -5.5437948554754257e-02
    z[5,0,5]  R859      6.7175167798995972e-01
    z[5,0,5]  R860      3.6202329397201538e-01
    z[5,0,5]  R861      2.5308024883270264e-01
    z[5,0,5]  R862      5.1114994287490845e-01
    z[5,0,5]  R863      3.5662892460823059e-01
    z[5,0,5]  R864      -7.1113187074661255e-01
    z[5,0,5]  R865      -4.1240021586418152e-01
    z[5,0,5]  R866      1.6171183437108994e-02
    z[5,0,5]  R867      3.2572954893112183e-01
    z[5,0,5]  R868      -3.2344126701354980e-01
    z[5,0,5]  R869      -3.8070490956306458e-01
    z[5,0,5]  R870      -1.5041446685791016e-01
    z[5,0,5]  R871      -2.4250821769237518e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R740      -1
    z[5,0,6]  R741      1
    z[5,0,6]  R742      -3.4480971097946167e-01
    z[5,0,6]  R743      -3.8678294420242310e-01
    z[5,0,6]  R744      4.1781640052795410e-01
    z[5,0,6]  R745      3.9502507448196411e-01
    z[5,0,6]  R746      1.5786762535572052e-01
    z[5,0,6]  R747      -1.7694112658500671e-01
    z[5,0,6]  R748      -3.9903020858764648e-01
    z[5,0,6]  R749      1.5352848172187805e-01
    z[5,0,6]  R750      -1.7421814799308777e-01
    z[5,0,6]  R751      1.0770173370838165e-01
    z[5,0,6]  R752      -1.5234698355197906e-01
    z[5,0,6]  R753      1.7902514338493347e-01
    z[5,0,6]  R754      -2.0524072647094727e-01
    z[5,0,6]  R755      -1.2814530730247498e-01
    z[5,0,6]  R756      6.4170587062835693e-01
    z[5,0,6]  R757      8.4600344300270081e-02
    z[5,0,6]  R758      -4.2167651653289795e-01
    z[5,0,6]  R759      3.8686826825141907e-02
    z[5,0,6]  R760      -3.7207841873168945e-01
    z[5,0,6]  R761      1.6291812062263489e-01
    z[5,0,6]  R762      2.5581473112106323e-01
    z[5,0,6]  R763      -2.8113466501235962e-01
    z[5,0,6]  R764      1.2849248945713043e-01
    z[5,0,6]  R765      1.2341749854385853e-02
    z[5,0,6]  R766      1.4303857088088989e-01
    z[5,0,6]  R767      2.7706572413444519e-01
    z[5,0,6]  R768      -2.9784819483757019e-01
    z[5,0,6]  R769      1.5759864449501038e-01
    z[5,0,6]  R770      -6.2524974346160889e-01
    z[5,0,6]  R771      0.231205552816391
    z[5,0,6]  R772      -2.3779509961605072e-01
    z[5,0,6]  R773      -0.264913946390152
    z[5,0,6]  R774      1.5839265286922455e-01
    z[5,0,6]  R775      3.4261947870254517e-01
    z[5,0,6]  R776      -1.1964618414640427e-01
    z[5,0,6]  R777      2.7611851692199707e-01
    z[5,0,6]  R778      -1.7255797982215881e-01
    z[5,0,6]  R779      -7.1088634431362152e-02
    z[5,0,6]  R780      -3.6511799693107605e-01
    z[5,0,6]  R781      -1.8450810015201569e-01
    z[5,0,6]  R782      7.3461544513702393e-01
    z[5,0,6]  R783      3.4221544861793518e-01
    z[5,0,6]  R784      -8.4001637995243073e-02
    z[5,0,6]  R785      4.1955387592315674e-01
    z[5,0,6]  R786      -3.3530315756797791e-01
    z[5,0,6]  R787      -6.4525239169597626e-02
    z[5,0,6]  R788      -1.1844666302204132e-01
    z[5,0,6]  R789      2.2946875542402267e-02
    z[5,0,6]  R790      1.7470799386501312e-01
    z[5,0,6]  R791      3.7696731090545654e-01
    z[5,0,6]  R792      8.7144136428833008e-02
    z[5,0,6]  R793      -1.6616840660572052e-01
    z[5,0,6]  R794      4.3904036283493042e-01
    z[5,0,6]  R795      -1.6719458997249603e-01
    z[5,0,6]  R796      8.3646379411220551e-02
    z[5,0,6]  R797      -1.4737313613295555e-02
    z[5,0,6]  R798      1.3662087917327881e-01
    z[5,0,6]  R799      2.6793381571769714e-01
    z[5,0,6]  R800      -1.0554116219282150e-01
    z[5,0,6]  R801      -5.7056136429309845e-03
    z[5,0,6]  R802      3.1772968173027039e-01
    z[5,0,6]  R803      3.4137552976608276e-01
    z[5,0,6]  R804      2.6968577504158020e-01
    z[5,0,6]  R805      2.6858061552047729e-01
    z[5,0,6]  R806      3.4463077783584595e-02
    z[5,0,6]  R807      1.0873294621706009e-01
    z[5,0,6]  R808      -1.1475966870784760e-01
    z[5,0,6]  R809      -3.2617077231407166e-01
    z[5,0,6]  R810      -7.7605910599231720e-02
    z[5,0,6]  R811      -3.3081090450286865e-01
    z[5,0,6]  R812      3.1884399056434631e-01
    z[5,0,6]  R813      -2.7227851748466492e-01
    z[5,0,6]  R814      -4.9142214655876160e-01
    z[5,0,6]  R815      -5.3596991300582886e-01
    z[5,0,6]  R816      1.1703094467520714e-02
    z[5,0,6]  R817      0.0146006615832448
    z[5,0,6]  R818      3.0798447132110596e-01
    z[5,0,6]  R819      -1.1080397292971611e-02
    z[5,0,6]  R820      -3.5698670148849487e-01
    z[5,0,6]  R821      -0.593315601348877
    z[5,0,6]  R822      8.8053919374942780e-02
    z[5,0,6]  R823      1.7209558188915253e-01
    z[5,0,6]  R824      3.4361341595649719e-01
    z[5,0,6]  R825      4.1705024242401123e-01
    z[5,0,6]  R826      4.0096101164817810e-01
    z[5,0,6]  R827      0.476885586977005
    z[5,0,6]  R828      4.9733448028564453e-01
    z[5,0,6]  R829      1.1575733125209808e-01
    z[5,0,6]  R830      1.4786525070667267e-01
    z[5,0,6]  R831      6.6876187920570374e-02
    z[5,0,6]  R832      -4.0917722508311272e-03
    z[5,0,6]  R833      -0.508971631526947
    z[5,0,6]  R834      1.0664170980453491e-01
    z[5,0,6]  R835      -2.7697867155075073e-01
    z[5,0,6]  R836      -3.8562685251235962e-01
    z[5,0,6]  R837      4.6044796705245972e-01
    z[5,0,6]  R838      7.3766958713531494e-01
    z[5,0,6]  R839      -1.9449464976787567e-01
    z[5,0,6]  R840      -2.8869467787444592e-03
    z[5,0,6]  R841      2.5344389677047729e-01
    z[5,0,6]  R842      6.1942511796951294e-01
    z[5,0,6]  R843      1.3202281668782234e-02
    z[5,0,6]  R844      1.4053647220134735e-01
    z[5,0,6]  R845      9.6981525421142578e-02
    z[5,0,6]  R846      4.5962461829185486e-01
    z[5,0,6]  R847      -1.0170855373144150e-01
    z[5,0,6]  R848      4.9914318323135376e-01
    z[5,0,6]  R849      -5.4759550094604492e-01
    z[5,0,6]  R850      1.4791837334632874e-01
    z[5,0,6]  R851      -0.552911639213562
    z[5,0,6]  R852      4.3932226300239563e-01
    z[5,0,6]  R853      5.0070071220397949e-01
    z[5,0,6]  R854      4.5036903023719788e-01
    z[5,0,6]  R855      -7.9545125365257263e-02
    z[5,0,6]  R856      -2.5002273917198181e-01
    z[5,0,6]  R857      -1.1861776560544968e-01
    z[5,0,6]  R858      1.0288503021001816e-01
    z[5,0,6]  R859      -1.9306229054927826e-01
    z[5,0,6]  R860      -0.326310396194458
    z[5,0,6]  R861      -1.0381789505481720e-01
    z[5,0,6]  R862      3.8189920783042908e-01
    z[5,0,6]  R863      -8.4024742245674133e-02
    z[5,0,6]  R864      -7.6818592846393585e-02
    z[5,0,6]  R865      -3.6519506573677063e-01
    z[5,0,6]  R866      4.8459663987159729e-01
    z[5,0,6]  R867      -3.4069389104843140e-02
    z[5,0,6]  R868      -9.3032263219356537e-02
    z[5,0,6]  R869      1.1360388994216919e-01
    z[5,0,6]  R870      -6.3811009749770164e-03
    z[5,0,6]  R871      3.1372848898172379e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R946      -1
    z[1,2,0]  R947      1
    z[1,2,0]  R960      -8.7314969301223755e-01
    z[1,2,0]  R961      -7.1911793947219849e-01
    z[1,2,0]  R962      -6.6781973838806152e-01
    z[1,2,0]  R963      -6.0775339603424072e-01
    z[1,2,0]  R964      5.4935562610626221e-01
    z[1,2,0]  R965      4.4997698068618774e-01
    z[1,2,0]  R966      5.5023741722106934e-01
    z[1,2,0]  R967      6.2460505962371826e-01
    z[1,2,0]  R968      5.3648352622985840e-01
    z[1,2,0]  R969      4.3952482938766479e-01
    z[1,2,0]  R970      -2.1675482392311096e-01
    z[1,2,0]  R971      -2.7263683080673218e-01
    z[1,2,0]  R972      -2.3004268109798431e-01
    z[1,2,0]  R973      4.8230504989624023e-01
    z[1,2,0]  R974      -5.2062119357287884e-03
    z[1,2,0]  R975      1.5500935912132263e-01
    z[1,2,0]  R976      2.4142050743103027e-01
    z[1,2,0]  R977      2.1509313583374023e-01
    z[1,2,0]  R978      3.4782573580741882e-01
    z[1,2,0]  R979      0.562000036239624
    z[1,2,0]  R980      4.4336032867431641e-01
    z[1,2,0]  R981      8.4264105558395386e-01
    z[1,2,0]  R982      -2.1403899788856506e-01
    z[1,2,0]  R983      6.7912155389785767e-01
    z[1,2,0]  R984      -8.2067124545574188e-02
    z[1,2,0]  R985      3.4387308359146118e-01
    z[1,2,0]  R986      -2.5361815094947815e-01
    z[1,2,0]  R987      -7.5763440132141113e-01
    z[1,2,0]  R988      -3.5594639182090759e-01
    z[1,2,0]  R989      -3.3674496412277222e-01
    z[1,2,0]  R990      -4.6896842122077942e-01
    z[1,2,0]  R991      -3.4761473536491394e-01
    z[1,2,0]  R992      6.3949227333068848e-01
    z[1,2,0]  R993      5.7122337818145752e-01
    z[1,2,0]  R994      5.5334341526031494e-01
    z[1,2,0]  R995      6.2901252508163452e-01
    z[1,2,0]  R996      6.4777708053588867e-01
    z[1,2,0]  R997      8.9310312271118164e-01
    z[1,2,0]  R998      6.7466163635253906e-01
    z[1,2,0]  R999      4.7219786047935486e-01
    z[1,2,0]  R1000     3.4431955218315125e-01
    z[1,2,0]  R1001     4.4713634252548218e-01
    z[1,2,0]  R1002     2.8827935457229614e-01
    z[1,2,0]  R1003     5.7758674025535583e-02
    z[1,2,0]  R1004     -1.9007632136344910e-01
    z[1,2,0]  R1005     -3.2289337366819382e-02
    z[1,2,0]  R1006     4.1105908155441284e-01
    z[1,2,0]  R1007     1.5849551558494568e-01
    z[1,2,0]  R1008     -5.3203213214874268e-01
    z[1,2,0]  R1009     -1.8916991539299488e-03
    z[1,2,0]  R1010     8.5165905952453613e-01
    z[1,2,0]  R1011     3.1775584816932678e-01
    z[1,2,0]  R1012     6.9684040546417236e-01
    z[1,2,0]  R1013     6.7209112644195557e-01
    z[1,2,0]  R1014     5.7442098855972290e-01
    z[1,2,0]  R1015     7.3271125555038452e-01
    z[1,2,0]  R1016     7.4017584323883057e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R948      -1
    z[1,2,1]  R949      1
    z[1,2,1]  R960      -2.4379432201385498e-01
    z[1,2,1]  R961      -2.2934935986995697e-01
    z[1,2,1]  R962      -0.321400910615921
    z[1,2,1]  R963      -5.2542246878147125e-02
    z[1,2,1]  R964      3.1723433732986450e-01
    z[1,2,1]  R965      -2.3725772276520729e-02
    z[1,2,1]  R966      9.8788812756538391e-02
    z[1,2,1]  R967      3.8652196526527405e-01
    z[1,2,1]  R968      -5.1489561796188354e-01
    z[1,2,1]  R969      1.6857534646987915e-02
    z[1,2,1]  R970      5.4728990793228149e-01
    z[1,2,1]  R971      6.3247776031494141e-01
    z[1,2,1]  R972      5.0224870443344116e-01
    z[1,2,1]  R973      5.5295862257480621e-02
    z[1,2,1]  R974      4.1310203075408936e-01
    z[1,2,1]  R975      5.5382519960403442e-01
    z[1,2,1]  R976      -5.5219709873199463e-01
    z[1,2,1]  R977      -0.627499520778656
    z[1,2,1]  R978      -4.1637489199638367e-01
    z[1,2,1]  R979      -2.5099787116050720e-01
    z[1,2,1]  R980      1.7124684154987335e-01
    z[1,2,1]  R981      2.5005084276199341e-01
    z[1,2,1]  R982      0.42324098944664
    z[1,2,1]  R983      1.9040256738662720e-02
    z[1,2,1]  R984      -0.0722082108259201
    z[1,2,1]  R985      2.5022500753402710e-01
    z[1,2,1]  R986      5.8972829580307007e-01
    z[1,2,1]  R987      -5.7247555255889893e-01
    z[1,2,1]  R988      -1.9509056210517883e-01
    z[1,2,1]  R989      -1.3002958893775940e-01
    z[1,2,1]  R990      7.6499380171298981e-02
    z[1,2,1]  R991      -6.3221082091331482e-02
    z[1,2,1]  R992      2.0963333547115326e-01
    z[1,2,1]  R993      -2.9543524980545044e-01
    z[1,2,1]  R994      1.5673731267452240e-01
    z[1,2,1]  R995      3.5808345675468445e-01
    z[1,2,1]  R996      -1.4877294003963470e-01
    z[1,2,1]  R997      2.1393451094627380e-01
    z[1,2,1]  R998      1.0662592202425003e-01
    z[1,2,1]  R999      -1.2335491180419922e-01
    z[1,2,1]  R1000     3.4935352206230164e-01
    z[1,2,1]  R1001     -1.6240717470645905e-01
    z[1,2,1]  R1002     -4.1114783287048340e-01
    z[1,2,1]  R1003     -3.5746926069259644e-01
    z[1,2,1]  R1004     6.5801191329956055e-01
    z[1,2,1]  R1005     5.5531173944473267e-01
    z[1,2,1]  R1006     -5.3824466466903687e-01
    z[1,2,1]  R1007     -7.4476402997970581e-01
    z[1,2,1]  R1008     1.4811581932008266e-02
    z[1,2,1]  R1009     -5.6641560792922974e-01
    z[1,2,1]  R1010     -7.9814761877059937e-02
    z[1,2,1]  R1011     -6.5438163280487061e-01
    z[1,2,1]  R1012     2.6334342360496521e-01
    z[1,2,1]  R1013     -1.6322395205497742e-01
    z[1,2,1]  R1014     -0.0738137811422348
    z[1,2,1]  R1015     1.2664929032325745e-02
    z[1,2,1]  R1016     -6.9266386330127716e-02
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R950      -1
    z[1,2,2]  R951      1
    z[1,2,2]  R960      3.3912312239408493e-02
    z[1,2,2]  R961      -2.1556296944618225e-01
    z[1,2,2]  R962      4.7245416045188904e-01
    z[1,2,2]  R963      -4.6791471540927887e-02
    z[1,2,2]  R964      8.0904394388198853e-02
    z[1,2,2]  R965      4.8915353417396545e-01
    z[1,2,2]  R966      5.3377203643321991e-02
    z[1,2,2]  R967      7.6720081269741058e-03
    z[1,2,2]  R968      2.0588225126266479e-01
    z[1,2,2]  R969      6.4833855628967285e-01
    z[1,2,2]  R970      5.4666930809617043e-03
    z[1,2,2]  R971      -4.9795752763748169e-01
    z[1,2,2]  R972      -1.0970401018857956e-01
    z[1,2,2]  R973      4.3045702576637268e-01
    z[1,2,2]  R974      -0.309946745634079
    z[1,2,2]  R975      -3.0110391974449158e-01
    z[1,2,2]  R976      -2.9382395744323730e-01
    z[1,2,2]  R977      -1.7092472314834595e-01
    z[1,2,2]  R978      -4.8073044419288635e-01
    z[1,2,2]  R979      -0.640221893787384
    z[1,2,2]  R980      -0.0763794332742691
    z[1,2,2]  R981      -2.2934117913246155e-01
    z[1,2,2]  R982      0.157013937830925
    z[1,2,2]  R983      3.5703918337821960e-01
    z[1,2,2]  R984      4.9444994330406189e-01
    z[1,2,2]  R985      -3.4975919127464294e-01
    z[1,2,2]  R986      -4.5922389626502991e-01
    z[1,2,2]  R987      1.7613766714930534e-02
    z[1,2,2]  R988      -3.6670750379562378e-01
    z[1,2,2]  R989      -7.1535122394561768e-01
    z[1,2,2]  R990      -8.2804977893829346e-02
    z[1,2,2]  R991      0.569068968296051
    z[1,2,2]  R992      5.2692568302154541e-01
    z[1,2,2]  R993      6.3493561744689941e-01
    z[1,2,2]  R994      5.9334945678710938e-01
    z[1,2,2]  R995      5.3470802307128906e-01
    z[1,2,2]  R996      -4.5478877425193787e-01
    z[1,2,2]  R997      -2.4710918962955475e-01
    z[1,2,2]  R998      2.9505258798599243e-01
    z[1,2,2]  R999      -1.2673631310462952e-01
    z[1,2,2]  R1000     3.2020923495292664e-01
    z[1,2,2]  R1001     1.0764550417661667e-01
    z[1,2,2]  R1002     5.8421516418457031e-01
    z[1,2,2]  R1003     1.5174217522144318e-01
    z[1,2,2]  R1004     -4.8082387447357178e-01
    z[1,2,2]  R1005     -6.7471444606781006e-01
    z[1,2,2]  R1006     2.8716100379824638e-02
    z[1,2,2]  R1007     1.5601059794425964e-01
    z[1,2,2]  R1008     1.1835405975580215e-01
    z[1,2,2]  R1009     -3.1986206769943237e-01
    z[1,2,2]  R1010     2.4501834809780121e-01
    z[1,2,2]  R1011     -2.5280582904815674e-01
    z[1,2,2]  R1012     3.0832657217979431e-01
    z[1,2,2]  R1013     2.2506318986415863e-01
    z[1,2,2]  R1014     -1.4811097085475922e-01
    z[1,2,2]  R1015     1.9597634673118591e-01
    z[1,2,2]  R1016     1.7840493470430374e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R952      -1
    z[1,2,3]  R953      1
    z[1,2,3]  R960      -1.6805936396121979e-01
    z[1,2,3]  R961      -4.7248509526252747e-01
    z[1,2,3]  R962      -1.1511293053627014e-01
    z[1,2,3]  R963      -7.5418412685394287e-02
    z[1,2,3]  R964      -3.5622778534889221e-01
    z[1,2,3]  R965      -4.7691002488136292e-01
    z[1,2,3]  R966      -4.3441405892372131e-01
    z[1,2,3]  R967      -1.7295217514038086e-01
    z[1,2,3]  R968      -5.0518423318862915e-01
    z[1,2,3]  R969      2.4070739746093750e-01
    z[1,2,3]  R970      6.5755927562713623e-01
    z[1,2,3]  R971      3.6037364602088928e-01
    z[1,2,3]  R972      6.9393843412399292e-01
    z[1,2,3]  R973      2.2118794918060303e-01
    z[1,2,3]  R974      5.6181758642196655e-01
    z[1,2,3]  R975      0.0750875174999237
    z[1,2,3]  R976      5.7986301183700562e-01
    z[1,2,3]  R977      6.6029745340347290e-01
    z[1,2,3]  R978      3.5390517115592957e-01
    z[1,2,3]  R979      3.8755786418914795e-01
    z[1,2,3]  R980      -2.6661860942840576e-01
    z[1,2,3]  R981      5.9386178851127625e-02
    z[1,2,3]  R982      7.5733649730682373e-01
    z[1,2,3]  R983      3.6607436835765839e-02
    z[1,2,3]  R984      5.0470304489135742e-01
    z[1,2,3]  R985      -6.7365425825119019e-01
    z[1,2,3]  R986      4.7751367092132568e-01
    z[1,2,3]  R987      -0.163498193025589
    z[1,2,3]  R988      6.8659073114395142e-01
    z[1,2,3]  R989      3.6911368370056152e-02
    z[1,2,3]  R990      -1.1901598423719406e-01
    z[1,2,3]  R991      0.614919126033783
    z[1,2,3]  R992      2.5125920772552490e-01
    z[1,2,3]  R993      -2.8503105044364929e-01
    z[1,2,3]  R994      -0.292032927274704
    z[1,2,3]  R995      1.5039514750242233e-02
    z[1,2,3]  R996      -3.6925175786018372e-01
    z[1,2,3]  R997      2.8051558881998062e-02
    z[1,2,3]  R998      -1.2274982780218124e-01
    z[1,2,3]  R999      -3.4370788931846619e-01
    z[1,2,3]  R1000     -7.5930452346801758e-01
    z[1,2,3]  R1001     0.0903458446264267
    z[1,2,3]  R1002     1.0439489036798477e-02
    z[1,2,3]  R1003     7.2723947465419769e-02
    z[1,2,3]  R1004     1.2909254431724548e-01
    z[1,2,3]  R1005     3.0000284314155579e-01
    z[1,2,3]  R1006     1.7999650537967682e-01
    z[1,2,3]  R1007     2.0185397565364838e-01
    z[1,2,3]  R1008     5.0524938106536865e-01
    z[1,2,3]  R1009     6.9806408882141113e-01
    z[1,2,3]  R1010     -2.5099528953433037e-02
    z[1,2,3]  R1011     -0.358840674161911
    z[1,2,3]  R1012     -3.9803746342658997e-01
    z[1,2,3]  R1013     -5.8572345972061157e-01
    z[1,2,3]  R1014     -5.2110934257507324e-01
    z[1,2,3]  R1015     -3.1147226691246033e-01
    z[1,2,3]  R1016     -0.538877546787262
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R954      -1
    z[1,2,4]  R955      1
    z[1,2,4]  R960      -3.5162156820297241e-01
    z[1,2,4]  R961      3.5999134182929993e-01
    z[1,2,4]  R962      1.3808570802211761e-01
    z[1,2,4]  R963      3.6242789030075073e-01
    z[1,2,4]  R964      2.3739543557167053e-01
    z[1,2,4]  R965      -1.6379849612712860e-01
    z[1,2,4]  R966      1.4983379840850830e-01
    z[1,2,4]  R967      6.0889708995819092e-01
    z[1,2,4]  R968      -2.4703058600425720e-01
    z[1,2,4]  R969      3.0834496021270752e-01
    z[1,2,4]  R970      -8.5020549595355988e-02
    z[1,2,4]  R971      1.6559921205043793e-02
    z[1,2,4]  R972      1.7816863954067230e-01
    z[1,2,4]  R973      -1.6855482757091522e-01
    z[1,2,4]  R974      -5.9320521354675293e-01
    z[1,2,4]  R975      -7.4704706668853760e-01
    z[1,2,4]  R976      -2.1361015737056732e-01
    z[1,2,4]  R977      2.6117104291915894e-01
    z[1,2,4]  R978      3.0422362685203552e-01
    z[1,2,4]  R979      9.3214645981788635e-02
    z[1,2,4]  R980      3.2586145401000977e-01
    z[1,2,4]  R981      -3.7242567539215088e-01
    z[1,2,4]  R982      -3.3418461680412292e-01
    z[1,2,4]  R983      3.9609670639038086e-01
    z[1,2,4]  R984      0.0793774202466011
    z[1,2,4]  R985      -3.2611221075057983e-01
    z[1,2,4]  R986      1.2232114374637604e-01
    z[1,2,4]  R987      -2.4468874931335449e-01
    z[1,2,4]  R988      3.4097969532012939e-01
    z[1,2,4]  R989      4.7816172242164612e-01
    z[1,2,4]  R990      4.7806724905967712e-01
    z[1,2,4]  R991      2.3337726294994354e-01
    z[1,2,4]  R992      2.3619548976421356e-01
    z[1,2,4]  R993      -2.5972619652748108e-01
    z[1,2,4]  R994      4.1397712193429470e-03
    z[1,2,4]  R995      -0.293050080537796
    z[1,2,4]  R996      4.4210076332092285e-01
    z[1,2,4]  R997      2.0535898208618164e-01
    z[1,2,4]  R998      0.147923544049263
    z[1,2,4]  R999      7.8769308328628540e-01
    z[1,2,4]  R1000     -2.9768953099846840e-02
    z[1,2,4]  R1001     6.5864413976669312e-01
    z[1,2,4]  R1002     1.1200571060180664e-01
    z[1,2,4]  R1003     1.2488156557083130e-01
    z[1,2,4]  R1004     -4.2440679669380188e-01
    z[1,2,4]  R1005     -3.5614043474197388e-02
    z[1,2,4]  R1006     -2.4764440953731537e-01
    z[1,2,4]  R1007     3.1631648540496826e-01
    z[1,2,4]  R1008     0.422834575176239
    z[1,2,4]  R1009     0.126910001039505
    z[1,2,4]  R1010     3.3830684423446655e-01
    z[1,2,4]  R1011     2.1739734709262848e-01
    z[1,2,4]  R1012     3.7161913514137268e-01
    z[1,2,4]  R1013     0.201577290892601
    z[1,2,4]  R1014     0.55451899766922
    z[1,2,4]  R1015     -3.8429954648017883e-01
    z[1,2,4]  R1016     5.9853404760360718e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R956      -1
    z[1,2,5]  R957      1
    z[1,2,5]  R960      1.2961870431900024e-01
    z[1,2,5]  R961      1.6045066714286804e-01
    z[1,2,5]  R962      -3.9478784799575806e-01
    z[1,2,5]  R963      -5.4924523830413818e-01
    z[1,2,5]  R964      -5.7758718729019165e-01
    z[1,2,5]  R965      -0.53410404920578
    z[1,2,5]  R966      -4.2254528962075710e-03
    z[1,2,5]  R967      2.2024048864841461e-01
    z[1,2,5]  R968      9.7692899405956268e-02
    z[1,2,5]  R969      -1.6185204684734344e-01
    z[1,2,5]  R970      -1.6028022393584251e-02
    z[1,2,5]  R971      1.5007193386554718e-01
    z[1,2,5]  R972      4.0822145342826843e-01
    z[1,2,5]  R973      1.1324766278266907e-01
    z[1,2,5]  R974      1.0664886236190796e-01
    z[1,2,5]  R975      -6.9709710776805878e-02
    z[1,2,5]  R976      -4.0737521648406982e-01
    z[1,2,5]  R977      -7.0643156766891479e-02
    z[1,2,5]  R978      -3.6483255028724670e-01
    z[1,2,5]  R979      -5.6257039308547974e-02
    z[1,2,5]  R980      -5.9323471784591675e-01
    z[1,2,5]  R981      -1.3628005981445312e-01
    z[1,2,5]  R982      -1.2858848273754120e-01
    z[1,2,5]  R983      -4.9038168787956238e-01
    z[1,2,5]  R984      6.9194871187210083e-01
    z[1,2,5]  R985      7.1098648011684418e-02
    z[1,2,5]  R986      3.6602234840393066e-01
    z[1,2,5]  R987      -1.0244369506835938e-01
    z[1,2,5]  R988      -2.2322522103786469e-01
    z[1,2,5]  R989      2.5354340672492981e-01
    z[1,2,5]  R990      3.4518918395042419e-01
    z[1,2,5]  R991      1.6572073101997375e-01
    z[1,2,5]  R992      -2.5708499550819397e-01
    z[1,2,5]  R993      -1.2364705651998520e-01
    z[1,2,5]  R994      -0.00943324901163578
    z[1,2,5]  R995      -2.9773488640785217e-01
    z[1,2,5]  R996      5.2075169980525970e-02
    z[1,2,5]  R997      -1.4794246852397919e-01
    z[1,2,5]  R998      6.3866508007049561e-01
    z[1,2,5]  R999      -7.0044849999248981e-03
    z[1,2,5]  R1000     -0.265982985496521
    z[1,2,5]  R1001     -5.3537738323211670e-01
    z[1,2,5]  R1002     -6.2748926877975464e-01
    z[1,2,5]  R1003     8.4097337722778320e-01
    z[1,2,5]  R1004     3.1948000192642212e-01
    z[1,2,5]  R1005     3.7596064805984497e-01
    z[1,2,5]  R1006     3.4059843420982361e-01
    z[1,2,5]  R1007     0.386809378862381
    z[1,2,5]  R1008     4.4625782966613770e-01
    z[1,2,5]  R1009     -2.3807963728904724e-01
    z[1,2,5]  R1010     -2.9688081145286560e-01
    z[1,2,5]  R1011     -4.5091417431831360e-01
    z[1,2,5]  R1012     1.4373989403247833e-01
    z[1,2,5]  R1013     -2.5141701102256775e-01
    z[1,2,5]  R1014     -2.4925684928894043e-01
    z[1,2,5]  R1015     -1.8825803697109222e-01
    z[1,2,5]  R1016     3.7017375230789185e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R958      -1
    z[1,2,6]  R959      1
    z[1,2,6]  R960      -9.1330170631408691e-02
    z[1,2,6]  R961      7.2253830730915070e-02
    z[1,2,6]  R962      -1.9831590354442596e-01
    z[1,2,6]  R963      4.3240424990653992e-01
    z[1,2,6]  R964      2.7232986688613892e-01
    z[1,2,6]  R965      -1.3470865786075592e-01
    z[1,2,6]  R966      6.8807476758956909e-01
    z[1,2,6]  R967      -1.0600224882364273e-01
    z[1,2,6]  R968      2.8089359402656555e-01
    z[1,2,6]  R969      4.5494848489761353e-01
    z[1,2,6]  R970      -4.6215969324111938e-01
    z[1,2,6]  R971      -3.5357350111007690e-01
    z[1,2,6]  R972      5.3406346589326859e-02
    z[1,2,6]  R973      -6.9919317960739136e-01
    z[1,2,6]  R974      2.3312492668628693e-01
    z[1,2,6]  R975      -1.0004618018865585e-01
    z[1,2,6]  R976      -5.1352199167013168e-02
    z[1,2,6]  R977      -1.4686885476112366e-01
    z[1,2,6]  R978      -3.5163024067878723e-01
    z[1,2,6]  R979      -2.2184905409812927e-01
    z[1,2,6]  R980      -4.8895165324211121e-01
    z[1,2,6]  R981      -1.1846186965703964e-01
    z[1,2,6]  R982      -2.2051757574081421e-01
    z[1,2,6]  R983      -1.1066807806491852e-01
    z[1,2,6]  R984      0.0612468495965004
    z[1,2,6]  R985      -3.6275735497474670e-01
    z[1,2,6]  R986      -7.5998269021511078e-03
    z[1,2,6]  R987      -2.9199369251728058e-02
    z[1,2,6]  R988      -2.5152340531349182e-01
    z[1,2,6]  R989      -2.5235396623611450e-01
    z[1,2,6]  R990      -6.3678181171417236e-01
    z[1,2,6]  R991      -3.0211547017097473e-01
    z[1,2,6]  R992      -2.9058659076690674e-01
    z[1,2,6]  R993      -1.3888755440711975e-01
    z[1,2,6]  R994      -4.8144727945327759e-01
    z[1,2,6]  R995      -1.2432327866554260e-01
    z[1,2,6]  R996      -1.3002596795558929e-01
    z[1,2,6]  R997      1.7518447339534760e-01
    z[1,2,6]  R998      3.9553910493850708e-02
    z[1,2,6]  R999      -0.0842975378036499
    z[1,2,6]  R1000     -9.3197010457515717e-02
    z[1,2,6]  R1001     -1.8303576111793518e-01
    z[1,2,6]  R1002     1.2165966443717480e-02
    z[1,2,6]  R1003     3.4312316775321960e-01
    z[1,2,6]  R1004     -2.9089670628309250e-02
    z[1,2,6]  R1005     -5.2251618355512619e-02
    z[1,2,6]  R1006     5.7512146234512329e-01
    z[1,2,6]  R1007     3.2472106814384460e-01
    z[1,2,6]  R1008     -2.6363351941108704e-01
    z[1,2,6]  R1009     1.2952478229999542e-01
    z[1,2,6]  R1010     -7.1082763373851776e-02
    z[1,2,6]  R1011     1.6599176824092865e-01
    z[1,2,6]  R1012     -1.8111509084701538e-01
    z[1,2,6]  R1013     1.5518435835838318e-01
    z[1,2,6]  R1014     -3.8468629121780396e-02
    z[1,2,6]  R1015     3.8003259897232056e-01
    z[1,2,6]  R1016     1.2658430635929108e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R1017     -1
    z[2,1,0]  R1018     1
    z[2,1,0]  R1031     -7.5763440132141113e-01
    z[2,1,0]  R1032     -3.5594639182090759e-01
    z[2,1,0]  R1033     -3.3674496412277222e-01
    z[2,1,0]  R1034     -4.6896842122077942e-01
    z[2,1,0]  R1035     -3.4761473536491394e-01
    z[2,1,0]  R1036     6.3949227333068848e-01
    z[2,1,0]  R1037     5.7122337818145752e-01
    z[2,1,0]  R1038     5.5334341526031494e-01
    z[2,1,0]  R1039     6.2901252508163452e-01
    z[2,1,0]  R1040     6.4777708053588867e-01
    z[2,1,0]  R1041     8.9310312271118164e-01
    z[2,1,0]  R1042     6.7466163635253906e-01
    z[2,1,0]  R1043     4.7219786047935486e-01
    z[2,1,0]  R1044     3.4431955218315125e-01
    z[2,1,0]  R1045     4.4713634252548218e-01
    z[2,1,0]  R1046     2.8827935457229614e-01
    z[2,1,0]  R1047     5.7758674025535583e-02
    z[2,1,0]  R1048     -1.9007632136344910e-01
    z[2,1,0]  R1049     -3.2289337366819382e-02
    z[2,1,0]  R1050     4.1105908155441284e-01
    z[2,1,0]  R1051     1.5849551558494568e-01
    z[2,1,0]  R1052     -5.3203213214874268e-01
    z[2,1,0]  R1053     -1.8916991539299488e-03
    z[2,1,0]  R1054     8.5165905952453613e-01
    z[2,1,0]  R1055     3.1775584816932678e-01
    z[2,1,0]  R1056     6.9684040546417236e-01
    z[2,1,0]  R1057     6.7209112644195557e-01
    z[2,1,0]  R1058     5.7442098855972290e-01
    z[2,1,0]  R1059     7.3271125555038452e-01
    z[2,1,0]  R1060     7.4017584323883057e-01
    z[2,1,0]  R1061     -8.7314969301223755e-01
    z[2,1,0]  R1062     -7.1911793947219849e-01
    z[2,1,0]  R1063     -6.6781973838806152e-01
    z[2,1,0]  R1064     -6.0775339603424072e-01
    z[2,1,0]  R1065     5.4935562610626221e-01
    z[2,1,0]  R1066     4.4997698068618774e-01
    z[2,1,0]  R1067     5.5023741722106934e-01
    z[2,1,0]  R1068     6.2460505962371826e-01
    z[2,1,0]  R1069     5.3648352622985840e-01
    z[2,1,0]  R1070     4.3952482938766479e-01
    z[2,1,0]  R1071     -2.1675482392311096e-01
    z[2,1,0]  R1072     -2.7263683080673218e-01
    z[2,1,0]  R1073     -2.3004268109798431e-01
    z[2,1,0]  R1074     4.8230504989624023e-01
    z[2,1,0]  R1075     -5.2062119357287884e-03
    z[2,1,0]  R1076     1.5500935912132263e-01
    z[2,1,0]  R1077     2.4142050743103027e-01
    z[2,1,0]  R1078     2.1509313583374023e-01
    z[2,1,0]  R1079     3.4782573580741882e-01
    z[2,1,0]  R1080     0.562000036239624
    z[2,1,0]  R1081     4.4336032867431641e-01
    z[2,1,0]  R1082     8.4264105558395386e-01
    z[2,1,0]  R1083     -2.1403899788856506e-01
    z[2,1,0]  R1084     6.7912155389785767e-01
    z[2,1,0]  R1085     -8.2067124545574188e-02
    z[2,1,0]  R1086     3.4387308359146118e-01
    z[2,1,0]  R1087     -2.5361815094947815e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R1019     -1
    z[2,1,1]  R1020     1
    z[2,1,1]  R1031     -5.7247555255889893e-01
    z[2,1,1]  R1032     -1.9509056210517883e-01
    z[2,1,1]  R1033     -1.3002958893775940e-01
    z[2,1,1]  R1034     7.6499380171298981e-02
    z[2,1,1]  R1035     -6.3221082091331482e-02
    z[2,1,1]  R1036     2.0963333547115326e-01
    z[2,1,1]  R1037     -2.9543524980545044e-01
    z[2,1,1]  R1038     1.5673731267452240e-01
    z[2,1,1]  R1039     3.5808345675468445e-01
    z[2,1,1]  R1040     -1.4877294003963470e-01
    z[2,1,1]  R1041     2.1393451094627380e-01
    z[2,1,1]  R1042     1.0662592202425003e-01
    z[2,1,1]  R1043     -1.2335491180419922e-01
    z[2,1,1]  R1044     3.4935352206230164e-01
    z[2,1,1]  R1045     -1.6240717470645905e-01
    z[2,1,1]  R1046     -4.1114783287048340e-01
    z[2,1,1]  R1047     -3.5746926069259644e-01
    z[2,1,1]  R1048     6.5801191329956055e-01
    z[2,1,1]  R1049     5.5531173944473267e-01
    z[2,1,1]  R1050     -5.3824466466903687e-01
    z[2,1,1]  R1051     -7.4476402997970581e-01
    z[2,1,1]  R1052     1.4811581932008266e-02
    z[2,1,1]  R1053     -5.6641560792922974e-01
    z[2,1,1]  R1054     -7.9814761877059937e-02
    z[2,1,1]  R1055     -6.5438163280487061e-01
    z[2,1,1]  R1056     2.6334342360496521e-01
    z[2,1,1]  R1057     -1.6322395205497742e-01
    z[2,1,1]  R1058     -0.0738137811422348
    z[2,1,1]  R1059     1.2664929032325745e-02
    z[2,1,1]  R1060     -6.9266386330127716e-02
    z[2,1,1]  R1061     -2.4379432201385498e-01
    z[2,1,1]  R1062     -2.2934935986995697e-01
    z[2,1,1]  R1063     -0.321400910615921
    z[2,1,1]  R1064     -5.2542246878147125e-02
    z[2,1,1]  R1065     3.1723433732986450e-01
    z[2,1,1]  R1066     -2.3725772276520729e-02
    z[2,1,1]  R1067     9.8788812756538391e-02
    z[2,1,1]  R1068     3.8652196526527405e-01
    z[2,1,1]  R1069     -5.1489561796188354e-01
    z[2,1,1]  R1070     1.6857534646987915e-02
    z[2,1,1]  R1071     5.4728990793228149e-01
    z[2,1,1]  R1072     6.3247776031494141e-01
    z[2,1,1]  R1073     5.0224870443344116e-01
    z[2,1,1]  R1074     5.5295862257480621e-02
    z[2,1,1]  R1075     4.1310203075408936e-01
    z[2,1,1]  R1076     5.5382519960403442e-01
    z[2,1,1]  R1077     -5.5219709873199463e-01
    z[2,1,1]  R1078     -0.627499520778656
    z[2,1,1]  R1079     -4.1637489199638367e-01
    z[2,1,1]  R1080     -2.5099787116050720e-01
    z[2,1,1]  R1081     1.7124684154987335e-01
    z[2,1,1]  R1082     2.5005084276199341e-01
    z[2,1,1]  R1083     0.42324098944664
    z[2,1,1]  R1084     1.9040256738662720e-02
    z[2,1,1]  R1085     -0.0722082108259201
    z[2,1,1]  R1086     2.5022500753402710e-01
    z[2,1,1]  R1087     5.8972829580307007e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R1021     -1
    z[2,1,2]  R1022     1
    z[2,1,2]  R1031     1.7613766714930534e-02
    z[2,1,2]  R1032     -3.6670750379562378e-01
    z[2,1,2]  R1033     -7.1535122394561768e-01
    z[2,1,2]  R1034     -8.2804977893829346e-02
    z[2,1,2]  R1035     0.569068968296051
    z[2,1,2]  R1036     5.2692568302154541e-01
    z[2,1,2]  R1037     6.3493561744689941e-01
    z[2,1,2]  R1038     5.9334945678710938e-01
    z[2,1,2]  R1039     5.3470802307128906e-01
    z[2,1,2]  R1040     -4.5478877425193787e-01
    z[2,1,2]  R1041     -2.4710918962955475e-01
    z[2,1,2]  R1042     2.9505258798599243e-01
    z[2,1,2]  R1043     -1.2673631310462952e-01
    z[2,1,2]  R1044     3.2020923495292664e-01
    z[2,1,2]  R1045     1.0764550417661667e-01
    z[2,1,2]  R1046     5.8421516418457031e-01
    z[2,1,2]  R1047     1.5174217522144318e-01
    z[2,1,2]  R1048     -4.8082387447357178e-01
    z[2,1,2]  R1049     -6.7471444606781006e-01
    z[2,1,2]  R1050     2.8716100379824638e-02
    z[2,1,2]  R1051     1.5601059794425964e-01
    z[2,1,2]  R1052     1.1835405975580215e-01
    z[2,1,2]  R1053     -3.1986206769943237e-01
    z[2,1,2]  R1054     2.4501834809780121e-01
    z[2,1,2]  R1055     -2.5280582904815674e-01
    z[2,1,2]  R1056     3.0832657217979431e-01
    z[2,1,2]  R1057     2.2506318986415863e-01
    z[2,1,2]  R1058     -1.4811097085475922e-01
    z[2,1,2]  R1059     1.9597634673118591e-01
    z[2,1,2]  R1060     1.7840493470430374e-02
    z[2,1,2]  R1061     3.3912312239408493e-02
    z[2,1,2]  R1062     -2.1556296944618225e-01
    z[2,1,2]  R1063     4.7245416045188904e-01
    z[2,1,2]  R1064     -4.6791471540927887e-02
    z[2,1,2]  R1065     8.0904394388198853e-02
    z[2,1,2]  R1066     4.8915353417396545e-01
    z[2,1,2]  R1067     5.3377203643321991e-02
    z[2,1,2]  R1068     7.6720081269741058e-03
    z[2,1,2]  R1069     2.0588225126266479e-01
    z[2,1,2]  R1070     6.4833855628967285e-01
    z[2,1,2]  R1071     5.4666930809617043e-03
    z[2,1,2]  R1072     -4.9795752763748169e-01
    z[2,1,2]  R1073     -1.0970401018857956e-01
    z[2,1,2]  R1074     4.3045702576637268e-01
    z[2,1,2]  R1075     -0.309946745634079
    z[2,1,2]  R1076     -3.0110391974449158e-01
    z[2,1,2]  R1077     -2.9382395744323730e-01
    z[2,1,2]  R1078     -1.7092472314834595e-01
    z[2,1,2]  R1079     -4.8073044419288635e-01
    z[2,1,2]  R1080     -0.640221893787384
    z[2,1,2]  R1081     -0.0763794332742691
    z[2,1,2]  R1082     -2.2934117913246155e-01
    z[2,1,2]  R1083     0.157013937830925
    z[2,1,2]  R1084     3.5703918337821960e-01
    z[2,1,2]  R1085     4.9444994330406189e-01
    z[2,1,2]  R1086     -3.4975919127464294e-01
    z[2,1,2]  R1087     -4.5922389626502991e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R1023     -1
    z[2,1,3]  R1024     1
    z[2,1,3]  R1031     -0.163498193025589
    z[2,1,3]  R1032     6.8659073114395142e-01
    z[2,1,3]  R1033     3.6911368370056152e-02
    z[2,1,3]  R1034     -1.1901598423719406e-01
    z[2,1,3]  R1035     0.614919126033783
    z[2,1,3]  R1036     2.5125920772552490e-01
    z[2,1,3]  R1037     -2.8503105044364929e-01
    z[2,1,3]  R1038     -0.292032927274704
    z[2,1,3]  R1039     1.5039514750242233e-02
    z[2,1,3]  R1040     -3.6925175786018372e-01
    z[2,1,3]  R1041     2.8051558881998062e-02
    z[2,1,3]  R1042     -1.2274982780218124e-01
    z[2,1,3]  R1043     -3.4370788931846619e-01
    z[2,1,3]  R1044     -7.5930452346801758e-01
    z[2,1,3]  R1045     0.0903458446264267
    z[2,1,3]  R1046     1.0439489036798477e-02
    z[2,1,3]  R1047     7.2723947465419769e-02
    z[2,1,3]  R1048     1.2909254431724548e-01
    z[2,1,3]  R1049     3.0000284314155579e-01
    z[2,1,3]  R1050     1.7999650537967682e-01
    z[2,1,3]  R1051     2.0185397565364838e-01
    z[2,1,3]  R1052     5.0524938106536865e-01
    z[2,1,3]  R1053     6.9806408882141113e-01
    z[2,1,3]  R1054     -2.5099528953433037e-02
    z[2,1,3]  R1055     -0.358840674161911
    z[2,1,3]  R1056     -3.9803746342658997e-01
    z[2,1,3]  R1057     -5.8572345972061157e-01
    z[2,1,3]  R1058     -5.2110934257507324e-01
    z[2,1,3]  R1059     -3.1147226691246033e-01
    z[2,1,3]  R1060     -0.538877546787262
    z[2,1,3]  R1061     -1.6805936396121979e-01
    z[2,1,3]  R1062     -4.7248509526252747e-01
    z[2,1,3]  R1063     -1.1511293053627014e-01
    z[2,1,3]  R1064     -7.5418412685394287e-02
    z[2,1,3]  R1065     -3.5622778534889221e-01
    z[2,1,3]  R1066     -4.7691002488136292e-01
    z[2,1,3]  R1067     -4.3441405892372131e-01
    z[2,1,3]  R1068     -1.7295217514038086e-01
    z[2,1,3]  R1069     -5.0518423318862915e-01
    z[2,1,3]  R1070     2.4070739746093750e-01
    z[2,1,3]  R1071     6.5755927562713623e-01
    z[2,1,3]  R1072     3.6037364602088928e-01
    z[2,1,3]  R1073     6.9393843412399292e-01
    z[2,1,3]  R1074     2.2118794918060303e-01
    z[2,1,3]  R1075     5.6181758642196655e-01
    z[2,1,3]  R1076     0.0750875174999237
    z[2,1,3]  R1077     5.7986301183700562e-01
    z[2,1,3]  R1078     6.6029745340347290e-01
    z[2,1,3]  R1079     3.5390517115592957e-01
    z[2,1,3]  R1080     3.8755786418914795e-01
    z[2,1,3]  R1081     -2.6661860942840576e-01
    z[2,1,3]  R1082     5.9386178851127625e-02
    z[2,1,3]  R1083     7.5733649730682373e-01
    z[2,1,3]  R1084     3.6607436835765839e-02
    z[2,1,3]  R1085     5.0470304489135742e-01
    z[2,1,3]  R1086     -6.7365425825119019e-01
    z[2,1,3]  R1087     4.7751367092132568e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R1025     -1
    z[2,1,4]  R1026     1
    z[2,1,4]  R1031     -2.4468874931335449e-01
    z[2,1,4]  R1032     3.4097969532012939e-01
    z[2,1,4]  R1033     4.7816172242164612e-01
    z[2,1,4]  R1034     4.7806724905967712e-01
    z[2,1,4]  R1035     2.3337726294994354e-01
    z[2,1,4]  R1036     2.3619548976421356e-01
    z[2,1,4]  R1037     -2.5972619652748108e-01
    z[2,1,4]  R1038     4.1397712193429470e-03
    z[2,1,4]  R1039     -0.293050080537796
    z[2,1,4]  R1040     4.4210076332092285e-01
    z[2,1,4]  R1041     2.0535898208618164e-01
    z[2,1,4]  R1042     0.147923544049263
    z[2,1,4]  R1043     7.8769308328628540e-01
    z[2,1,4]  R1044     -2.9768953099846840e-02
    z[2,1,4]  R1045     6.5864413976669312e-01
    z[2,1,4]  R1046     1.1200571060180664e-01
    z[2,1,4]  R1047     1.2488156557083130e-01
    z[2,1,4]  R1048     -4.2440679669380188e-01
    z[2,1,4]  R1049     -3.5614043474197388e-02
    z[2,1,4]  R1050     -2.4764440953731537e-01
    z[2,1,4]  R1051     3.1631648540496826e-01
    z[2,1,4]  R1052     0.422834575176239
    z[2,1,4]  R1053     0.126910001039505
    z[2,1,4]  R1054     3.3830684423446655e-01
    z[2,1,4]  R1055     2.1739734709262848e-01
    z[2,1,4]  R1056     3.7161913514137268e-01
    z[2,1,4]  R1057     0.201577290892601
    z[2,1,4]  R1058     0.55451899766922
    z[2,1,4]  R1059     -3.8429954648017883e-01
    z[2,1,4]  R1060     5.9853404760360718e-02
    z[2,1,4]  R1061     -3.5162156820297241e-01
    z[2,1,4]  R1062     3.5999134182929993e-01
    z[2,1,4]  R1063     1.3808570802211761e-01
    z[2,1,4]  R1064     3.6242789030075073e-01
    z[2,1,4]  R1065     2.3739543557167053e-01
    z[2,1,4]  R1066     -1.6379849612712860e-01
    z[2,1,4]  R1067     1.4983379840850830e-01
    z[2,1,4]  R1068     6.0889708995819092e-01
    z[2,1,4]  R1069     -2.4703058600425720e-01
    z[2,1,4]  R1070     3.0834496021270752e-01
    z[2,1,4]  R1071     -8.5020549595355988e-02
    z[2,1,4]  R1072     1.6559921205043793e-02
    z[2,1,4]  R1073     1.7816863954067230e-01
    z[2,1,4]  R1074     -1.6855482757091522e-01
    z[2,1,4]  R1075     -5.9320521354675293e-01
    z[2,1,4]  R1076     -7.4704706668853760e-01
    z[2,1,4]  R1077     -2.1361015737056732e-01
    z[2,1,4]  R1078     2.6117104291915894e-01
    z[2,1,4]  R1079     3.0422362685203552e-01
    z[2,1,4]  R1080     9.3214645981788635e-02
    z[2,1,4]  R1081     3.2586145401000977e-01
    z[2,1,4]  R1082     -3.7242567539215088e-01
    z[2,1,4]  R1083     -3.3418461680412292e-01
    z[2,1,4]  R1084     3.9609670639038086e-01
    z[2,1,4]  R1085     0.0793774202466011
    z[2,1,4]  R1086     -3.2611221075057983e-01
    z[2,1,4]  R1087     1.2232114374637604e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R1027     -1
    z[2,1,5]  R1028     1
    z[2,1,5]  R1031     -1.0244369506835938e-01
    z[2,1,5]  R1032     -2.2322522103786469e-01
    z[2,1,5]  R1033     2.5354340672492981e-01
    z[2,1,5]  R1034     3.4518918395042419e-01
    z[2,1,5]  R1035     1.6572073101997375e-01
    z[2,1,5]  R1036     -2.5708499550819397e-01
    z[2,1,5]  R1037     -1.2364705651998520e-01
    z[2,1,5]  R1038     -0.00943324901163578
    z[2,1,5]  R1039     -2.9773488640785217e-01
    z[2,1,5]  R1040     5.2075169980525970e-02
    z[2,1,5]  R1041     -1.4794246852397919e-01
    z[2,1,5]  R1042     6.3866508007049561e-01
    z[2,1,5]  R1043     -7.0044849999248981e-03
    z[2,1,5]  R1044     -0.265982985496521
    z[2,1,5]  R1045     -5.3537738323211670e-01
    z[2,1,5]  R1046     -6.2748926877975464e-01
    z[2,1,5]  R1047     8.4097337722778320e-01
    z[2,1,5]  R1048     3.1948000192642212e-01
    z[2,1,5]  R1049     3.7596064805984497e-01
    z[2,1,5]  R1050     3.4059843420982361e-01
    z[2,1,5]  R1051     0.386809378862381
    z[2,1,5]  R1052     4.4625782966613770e-01
    z[2,1,5]  R1053     -2.3807963728904724e-01
    z[2,1,5]  R1054     -2.9688081145286560e-01
    z[2,1,5]  R1055     -4.5091417431831360e-01
    z[2,1,5]  R1056     1.4373989403247833e-01
    z[2,1,5]  R1057     -2.5141701102256775e-01
    z[2,1,5]  R1058     -2.4925684928894043e-01
    z[2,1,5]  R1059     -1.8825803697109222e-01
    z[2,1,5]  R1060     3.7017375230789185e-01
    z[2,1,5]  R1061     1.2961870431900024e-01
    z[2,1,5]  R1062     1.6045066714286804e-01
    z[2,1,5]  R1063     -3.9478784799575806e-01
    z[2,1,5]  R1064     -5.4924523830413818e-01
    z[2,1,5]  R1065     -5.7758718729019165e-01
    z[2,1,5]  R1066     -0.53410404920578
    z[2,1,5]  R1067     -4.2254528962075710e-03
    z[2,1,5]  R1068     2.2024048864841461e-01
    z[2,1,5]  R1069     9.7692899405956268e-02
    z[2,1,5]  R1070     -1.6185204684734344e-01
    z[2,1,5]  R1071     -1.6028022393584251e-02
    z[2,1,5]  R1072     1.5007193386554718e-01
    z[2,1,5]  R1073     4.0822145342826843e-01
    z[2,1,5]  R1074     1.1324766278266907e-01
    z[2,1,5]  R1075     1.0664886236190796e-01
    z[2,1,5]  R1076     -6.9709710776805878e-02
    z[2,1,5]  R1077     -4.0737521648406982e-01
    z[2,1,5]  R1078     -7.0643156766891479e-02
    z[2,1,5]  R1079     -3.6483255028724670e-01
    z[2,1,5]  R1080     -5.6257039308547974e-02
    z[2,1,5]  R1081     -5.9323471784591675e-01
    z[2,1,5]  R1082     -1.3628005981445312e-01
    z[2,1,5]  R1083     -1.2858848273754120e-01
    z[2,1,5]  R1084     -4.9038168787956238e-01
    z[2,1,5]  R1085     6.9194871187210083e-01
    z[2,1,5]  R1086     7.1098648011684418e-02
    z[2,1,5]  R1087     3.6602234840393066e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R1029     -1
    z[2,1,6]  R1030     1
    z[2,1,6]  R1031     -2.9199369251728058e-02
    z[2,1,6]  R1032     -2.5152340531349182e-01
    z[2,1,6]  R1033     -2.5235396623611450e-01
    z[2,1,6]  R1034     -6.3678181171417236e-01
    z[2,1,6]  R1035     -3.0211547017097473e-01
    z[2,1,6]  R1036     -2.9058659076690674e-01
    z[2,1,6]  R1037     -1.3888755440711975e-01
    z[2,1,6]  R1038     -4.8144727945327759e-01
    z[2,1,6]  R1039     -1.2432327866554260e-01
    z[2,1,6]  R1040     -1.3002596795558929e-01
    z[2,1,6]  R1041     1.7518447339534760e-01
    z[2,1,6]  R1042     3.9553910493850708e-02
    z[2,1,6]  R1043     -0.0842975378036499
    z[2,1,6]  R1044     -9.3197010457515717e-02
    z[2,1,6]  R1045     -1.8303576111793518e-01
    z[2,1,6]  R1046     1.2165966443717480e-02
    z[2,1,6]  R1047     3.4312316775321960e-01
    z[2,1,6]  R1048     -2.9089670628309250e-02
    z[2,1,6]  R1049     -5.2251618355512619e-02
    z[2,1,6]  R1050     5.7512146234512329e-01
    z[2,1,6]  R1051     3.2472106814384460e-01
    z[2,1,6]  R1052     -2.6363351941108704e-01
    z[2,1,6]  R1053     1.2952478229999542e-01
    z[2,1,6]  R1054     -7.1082763373851776e-02
    z[2,1,6]  R1055     1.6599176824092865e-01
    z[2,1,6]  R1056     -1.8111509084701538e-01
    z[2,1,6]  R1057     1.5518435835838318e-01
    z[2,1,6]  R1058     -3.8468629121780396e-02
    z[2,1,6]  R1059     3.8003259897232056e-01
    z[2,1,6]  R1060     1.2658430635929108e-01
    z[2,1,6]  R1061     -9.1330170631408691e-02
    z[2,1,6]  R1062     7.2253830730915070e-02
    z[2,1,6]  R1063     -1.9831590354442596e-01
    z[2,1,6]  R1064     4.3240424990653992e-01
    z[2,1,6]  R1065     2.7232986688613892e-01
    z[2,1,6]  R1066     -1.3470865786075592e-01
    z[2,1,6]  R1067     6.8807476758956909e-01
    z[2,1,6]  R1068     -1.0600224882364273e-01
    z[2,1,6]  R1069     2.8089359402656555e-01
    z[2,1,6]  R1070     4.5494848489761353e-01
    z[2,1,6]  R1071     -4.6215969324111938e-01
    z[2,1,6]  R1072     -3.5357350111007690e-01
    z[2,1,6]  R1073     5.3406346589326859e-02
    z[2,1,6]  R1074     -6.9919317960739136e-01
    z[2,1,6]  R1075     2.3312492668628693e-01
    z[2,1,6]  R1076     -1.0004618018865585e-01
    z[2,1,6]  R1077     -5.1352199167013168e-02
    z[2,1,6]  R1078     -1.4686885476112366e-01
    z[2,1,6]  R1079     -3.5163024067878723e-01
    z[2,1,6]  R1080     -2.2184905409812927e-01
    z[2,1,6]  R1081     -4.8895165324211121e-01
    z[2,1,6]  R1082     -1.1846186965703964e-01
    z[2,1,6]  R1083     -2.2051757574081421e-01
    z[2,1,6]  R1084     -1.1066807806491852e-01
    z[2,1,6]  R1085     0.0612468495965004
    z[2,1,6]  R1086     -3.6275735497474670e-01
    z[2,1,6]  R1087     -7.5998269021511078e-03
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1088     -1
    z[2,3,0]  R1089     1
    z[2,3,0]  R1102     -7.5763440132141113e-01
    z[2,3,0]  R1103     -3.5594639182090759e-01
    z[2,3,0]  R1104     -3.3674496412277222e-01
    z[2,3,0]  R1105     -4.6896842122077942e-01
    z[2,3,0]  R1106     -3.4761473536491394e-01
    z[2,3,0]  R1107     6.3949227333068848e-01
    z[2,3,0]  R1108     5.7122337818145752e-01
    z[2,3,0]  R1109     5.5334341526031494e-01
    z[2,3,0]  R1110     6.2901252508163452e-01
    z[2,3,0]  R1111     6.4777708053588867e-01
    z[2,3,0]  R1112     8.9310312271118164e-01
    z[2,3,0]  R1113     6.7466163635253906e-01
    z[2,3,0]  R1114     4.7219786047935486e-01
    z[2,3,0]  R1115     3.4431955218315125e-01
    z[2,3,0]  R1116     4.4713634252548218e-01
    z[2,3,0]  R1117     2.8827935457229614e-01
    z[2,3,0]  R1118     5.7758674025535583e-02
    z[2,3,0]  R1119     -1.9007632136344910e-01
    z[2,3,0]  R1120     -3.2289337366819382e-02
    z[2,3,0]  R1121     4.1105908155441284e-01
    z[2,3,0]  R1122     1.5849551558494568e-01
    z[2,3,0]  R1123     -5.3203213214874268e-01
    z[2,3,0]  R1124     -1.8916991539299488e-03
    z[2,3,0]  R1125     8.5165905952453613e-01
    z[2,3,0]  R1126     3.1775584816932678e-01
    z[2,3,0]  R1127     6.9684040546417236e-01
    z[2,3,0]  R1128     6.7209112644195557e-01
    z[2,3,0]  R1129     5.7442098855972290e-01
    z[2,3,0]  R1130     7.3271125555038452e-01
    z[2,3,0]  R1131     7.4017584323883057e-01
    z[2,3,0]  R1132     3.9363589882850647e-01
    z[2,3,0]  R1133     -7.7881030738353729e-02
    z[2,3,0]  R1134     1.2821778655052185e-01
    z[2,3,0]  R1135     3.5443133115768433e-01
    z[2,3,0]  R1136     -2.3074150085449219e-01
    z[2,3,0]  R1137     6.7675068974494934e-02
    z[2,3,0]  R1138     -2.4353887140750885e-01
    z[2,3,0]  R1139     -1.4388197660446167e-01
    z[2,3,0]  R1140     -5.3544437885284424e-01
    z[2,3,0]  R1141     1.2710736691951752e-01
    z[2,3,0]  R1142     -7.2518303990364075e-02
    z[2,3,0]  R1143     2.1276114881038666e-01
    z[2,3,0]  R1144     9.2758513987064362e-02
    z[2,3,0]  R1145     -1.2157166004180908e-01
    z[2,3,0]  R1146     1.4774616062641144e-01
    z[2,3,0]  R1147     -0.0848345085978508
    z[2,3,0]  R1148     2.5067931413650513e-01
    z[2,3,0]  R1149     4.2221829295158386e-01
    z[2,3,0]  R1150     -4.6629492193460464e-02
    z[2,3,0]  R1151     -1.1889804154634476e-01
    z[2,3,0]  R1152     2.8773501515388489e-01
    z[2,3,0]  R1153     -0.0851939395070076
    z[2,3,0]  R1154     -2.0846106112003326e-01
    z[2,3,0]  R1155     -1.5841172635555267e-01
    z[2,3,0]  R1156     7.9185582697391510e-02
    z[2,3,0]  R1157     2.4980646371841431e-01
    z[2,3,0]  R1158     1.7832493782043457e-01
    z[2,3,0]  R1159     1.1742538958787918e-01
    z[2,3,0]  R1160     -3.5878166556358337e-01
    z[2,3,0]  R1161     3.6712247133255005e-01
    z[2,3,0]  R1162     1.2598113715648651e-01
    z[2,3,0]  R1163     -2.2572505474090576e-01
    z[2,3,0]  R1164     -1.5283916890621185e-01
    z[2,3,0]  R1165     3.5271936655044556e-01
    z[2,3,0]  R1166     -1.6366019845008850e-01
    z[2,3,0]  R1167     -2.7820643782615662e-01
    z[2,3,0]  R1168     -0.468054860830307
    z[2,3,0]  R1169     -9.4501510262489319e-02
    z[2,3,0]  R1170     3.8991760462522507e-02
    z[2,3,0]  R1171     -2.3824974894523621e-01
    z[2,3,0]  R1172     -1.8255129456520081e-01
    z[2,3,0]  R1173     -0.285730242729187
    z[2,3,0]  R1174     4.2138494551181793e-02
    z[2,3,0]  R1175     -0.242917999625206
    z[2,3,0]  R1176     1.5073123574256897e-01
    z[2,3,0]  R1177     1.1461414396762848e-01
    z[2,3,0]  R1178     -1.9538788124918938e-02
    z[2,3,0]  R1179     -3.9183203130960464e-02
    z[2,3,0]  R1180     1.1523278802633286e-01
    z[2,3,0]  R1181     -1.1464959383010864e-01
    z[2,3,0]  R1182     -2.0538076758384705e-01
    z[2,3,0]  R1183     -2.9686164855957031e-01
    z[2,3,0]  R1184     -3.1057798862457275e-01
    z[2,3,0]  R1185     -5.8969402313232422e-01
    z[2,3,0]  R1186     3.8537446409463882e-02
    z[2,3,0]  R1187     -9.2446170747280121e-02
    z[2,3,0]  R1188     1.3703256845474243e-01
    z[2,3,0]  R1189     4.2776057124137878e-01
    z[2,3,0]  R1190     -1.9621905684471130e-01
    z[2,3,0]  R1191     -2.0587362349033356e-01
    z[2,3,0]  R1192     3.5219132900238037e-02
    z[2,3,0]  R1193     -6.8545721471309662e-02
    z[2,3,0]  R1194     -1.5081923454999924e-02
    z[2,3,0]  R1195     8.9163705706596375e-03
    z[2,3,0]  R1196     1.5945617854595184e-01
    z[2,3,0]  R1197     -8.2971222698688507e-02
    z[2,3,0]  R1198     3.8412243127822876e-01
    z[2,3,0]  R1199     4.4668781757354736e-01
    z[2,3,0]  R1200     2.2310416400432587e-01
    z[2,3,0]  R1201     0.0798686295747757
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1090     -1
    z[2,3,1]  R1091     1
    z[2,3,1]  R1102     -5.7247555255889893e-01
    z[2,3,1]  R1103     -1.9509056210517883e-01
    z[2,3,1]  R1104     -1.3002958893775940e-01
    z[2,3,1]  R1105     7.6499380171298981e-02
    z[2,3,1]  R1106     -6.3221082091331482e-02
    z[2,3,1]  R1107     2.0963333547115326e-01
    z[2,3,1]  R1108     -2.9543524980545044e-01
    z[2,3,1]  R1109     1.5673731267452240e-01
    z[2,3,1]  R1110     3.5808345675468445e-01
    z[2,3,1]  R1111     -1.4877294003963470e-01
    z[2,3,1]  R1112     2.1393451094627380e-01
    z[2,3,1]  R1113     1.0662592202425003e-01
    z[2,3,1]  R1114     -1.2335491180419922e-01
    z[2,3,1]  R1115     3.4935352206230164e-01
    z[2,3,1]  R1116     -1.6240717470645905e-01
    z[2,3,1]  R1117     -4.1114783287048340e-01
    z[2,3,1]  R1118     -3.5746926069259644e-01
    z[2,3,1]  R1119     6.5801191329956055e-01
    z[2,3,1]  R1120     5.5531173944473267e-01
    z[2,3,1]  R1121     -5.3824466466903687e-01
    z[2,3,1]  R1122     -7.4476402997970581e-01
    z[2,3,1]  R1123     1.4811581932008266e-02
    z[2,3,1]  R1124     -5.6641560792922974e-01
    z[2,3,1]  R1125     -7.9814761877059937e-02
    z[2,3,1]  R1126     -6.5438163280487061e-01
    z[2,3,1]  R1127     2.6334342360496521e-01
    z[2,3,1]  R1128     -1.6322395205497742e-01
    z[2,3,1]  R1129     -0.0738137811422348
    z[2,3,1]  R1130     1.2664929032325745e-02
    z[2,3,1]  R1131     -6.9266386330127716e-02
    z[2,3,1]  R1132     -8.4875416755676270e-01
    z[2,3,1]  R1133     -7.6350408792495728e-01
    z[2,3,1]  R1134     -6.9220441579818726e-01
    z[2,3,1]  R1135     -7.5259184837341309e-01
    z[2,3,1]  R1136     -6.5914791822433472e-01
    z[2,3,1]  R1137     -6.3478189706802368e-01
    z[2,3,1]  R1138     -6.9675922393798828e-01
    z[2,3,1]  R1139     -6.8594950437545776e-01
    z[2,3,1]  R1140     -0.720085084438324
    z[2,3,1]  R1141     -0.654482364654541
    z[2,3,1]  R1142     5.3756970167160034e-01
    z[2,3,1]  R1143     6.7018610239028931e-01
    z[2,3,1]  R1144     5.2114909887313843e-01
    z[2,3,1]  R1145     8.0826961994171143e-01
    z[2,3,1]  R1146     5.2093577384948730e-01
    z[2,3,1]  R1147     0.766403079032898
    z[2,3,1]  R1148     5.3823846578598022e-01
    z[2,3,1]  R1149     5.6191658973693848e-01
    z[2,3,1]  R1150     6.8640989065170288e-01
    z[2,3,1]  R1151     5.8817285299301147e-01
    z[2,3,1]  R1152     -7.7654361724853516e-01
    z[2,3,1]  R1153     8.1427836418151855e-01
    z[2,3,1]  R1154     8.0048912763595581e-01
    z[2,3,1]  R1155     7.3714506626129150e-01
    z[2,3,1]  R1156     7.5503402948379517e-01
    z[2,3,1]  R1157     7.5513535737991333e-01
    z[2,3,1]  R1158     0.715343713760376
    z[2,3,1]  R1159     2.7329745888710022e-01
    z[2,3,1]  R1160     -0.789559006690979
    z[2,3,1]  R1161     0.406112939119339
    z[2,3,1]  R1162     8.8111555576324463e-01
    z[2,3,1]  R1163     7.5951015949249268e-01
    z[2,3,1]  R1164     7.7988177537918091e-01
    z[2,3,1]  R1165     8.7794524431228638e-01
    z[2,3,1]  R1166     -7.8032869100570679e-01
    z[2,3,1]  R1167     3.7118464708328247e-01
    z[2,3,1]  R1168     8.0645316839218140e-01
    z[2,3,1]  R1169     -6.7775064706802368e-01
    z[2,3,1]  R1170     -6.1478763818740845e-01
    z[2,3,1]  R1171     -0.553998589515686
    z[2,3,1]  R1172     -9.1400617361068726e-01
    z[2,3,1]  R1173     3.2584023475646973e-01
    z[2,3,1]  R1174     7.8695756196975708e-01
    z[2,3,1]  R1175     8.8433420658111572e-01
    z[2,3,1]  R1176     4.0293261408805847e-01
    z[2,3,1]  R1177     8.5626173019409180e-01
    z[2,3,1]  R1178     0.377754271030426
    z[2,3,1]  R1179     7.8552317619323730e-01
    z[2,3,1]  R1180     2.9795980453491211e-01
    z[2,3,1]  R1181     -7.5245392322540283e-01
    z[2,3,1]  R1182     8.6704850196838379e-01
    z[2,3,1]  R1183     8.2125717401504517e-01
    z[2,3,1]  R1184     7.3972302675247192e-01
    z[2,3,1]  R1185     5.6195092201232910e-01
    z[2,3,1]  R1186     4.4921347498893738e-01
    z[2,3,1]  R1187     3.6589628458023071e-01
    z[2,3,1]  R1188     6.1605077981948853e-01
    z[2,3,1]  R1189     3.1889653205871582e-01
    z[2,3,1]  R1190     4.2207670211791992e-01
    z[2,3,1]  R1191     -3.0615600943565369e-01
    z[2,3,1]  R1192     -8.5200399160385132e-01
    z[2,3,1]  R1193     7.9975503683090210e-01
    z[2,3,1]  R1194     6.9973438978195190e-01
    z[2,3,1]  R1195     5.4913687705993652e-01
    z[2,3,1]  R1196     7.5766873359680176e-01
    z[2,3,1]  R1197     8.5975813865661621e-01
    z[2,3,1]  R1198     -7.4762952327728271e-01
    z[2,3,1]  R1199     0.659613847732544
    z[2,3,1]  R1200     7.3501503467559814e-01
    z[2,3,1]  R1201     3.9458429813385010e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1092     -1
    z[2,3,2]  R1093     1
    z[2,3,2]  R1102     1.7613766714930534e-02
    z[2,3,2]  R1103     -3.6670750379562378e-01
    z[2,3,2]  R1104     -7.1535122394561768e-01
    z[2,3,2]  R1105     -8.2804977893829346e-02
    z[2,3,2]  R1106     0.569068968296051
    z[2,3,2]  R1107     5.2692568302154541e-01
    z[2,3,2]  R1108     6.3493561744689941e-01
    z[2,3,2]  R1109     5.9334945678710938e-01
    z[2,3,2]  R1110     5.3470802307128906e-01
    z[2,3,2]  R1111     -4.5478877425193787e-01
    z[2,3,2]  R1112     -2.4710918962955475e-01
    z[2,3,2]  R1113     2.9505258798599243e-01
    z[2,3,2]  R1114     -1.2673631310462952e-01
    z[2,3,2]  R1115     3.2020923495292664e-01
    z[2,3,2]  R1116     1.0764550417661667e-01
    z[2,3,2]  R1117     5.8421516418457031e-01
    z[2,3,2]  R1118     1.5174217522144318e-01
    z[2,3,2]  R1119     -4.8082387447357178e-01
    z[2,3,2]  R1120     -6.7471444606781006e-01
    z[2,3,2]  R1121     2.8716100379824638e-02
    z[2,3,2]  R1122     1.5601059794425964e-01
    z[2,3,2]  R1123     1.1835405975580215e-01
    z[2,3,2]  R1124     -3.1986206769943237e-01
    z[2,3,2]  R1125     2.4501834809780121e-01
    z[2,3,2]  R1126     -2.5280582904815674e-01
    z[2,3,2]  R1127     3.0832657217979431e-01
    z[2,3,2]  R1128     2.2506318986415863e-01
    z[2,3,2]  R1129     -1.4811097085475922e-01
    z[2,3,2]  R1130     1.9597634673118591e-01
    z[2,3,2]  R1131     1.7840493470430374e-02
    z[2,3,2]  R1132     -1.7875541746616364e-01
    z[2,3,2]  R1133     1.6437128186225891e-01
    z[2,3,2]  R1134     3.1386566162109375e-01
    z[2,3,2]  R1135     -3.5817819833755493e-01
    z[2,3,2]  R1136     3.0280584096908569e-01
    z[2,3,2]  R1137     -1.0577351599931717e-01
    z[2,3,2]  R1138     -1.2380877882242203e-01
    z[2,3,2]  R1139     -4.0357332676649094e-02
    z[2,3,2]  R1140     2.0476941764354706e-01
    z[2,3,2]  R1141     -6.9687180221080780e-02
    z[2,3,2]  R1142     -3.6673773080110550e-02
    z[2,3,2]  R1143     2.2529596462845802e-02
    z[2,3,2]  R1144     8.5387177765369415e-02
    z[2,3,2]  R1145     2.0524667203426361e-01
    z[2,3,2]  R1146     -0.329296350479126
    z[2,3,2]  R1147     -3.9191302657127380e-01
    z[2,3,2]  R1148     2.7171965688467026e-02
    z[2,3,2]  R1149     8.4818713366985321e-02
    z[2,3,2]  R1150     2.1026635169982910e-01
    z[2,3,2]  R1151     -2.5847575068473816e-01
    z[2,3,2]  R1152     1.1799214035272598e-01
    z[2,3,2]  R1153     2.5016331672668457e-01
    z[2,3,2]  R1154     2.2700999677181244e-01
    z[2,3,2]  R1155     -3.5879313945770264e-01
    z[2,3,2]  R1156     1.7400035262107849e-01
    z[2,3,2]  R1157     9.2336907982826233e-02
    z[2,3,2]  R1158     3.8307376205921173e-02
    z[2,3,2]  R1159     -7.4331218004226685e-01
    z[2,3,2]  R1160     -2.6634940505027771e-01
    z[2,3,2]  R1161     -0.789828896522522
    z[2,3,2]  R1162     1.3020043261349201e-02
    z[2,3,2]  R1163     -1.8992304801940918e-01
    z[2,3,2]  R1164     4.8273853957653046e-02
    z[2,3,2]  R1165     -6.0649521648883820e-02
    z[2,3,2]  R1166     0.0107242651283741
    z[2,3,2]  R1167     -7.5354951620101929e-01
    z[2,3,2]  R1168     0.287629097700119
    z[2,3,2]  R1169     5.4602712392807007e-01
    z[2,3,2]  R1170     -3.6274090409278870e-01
    z[2,3,2]  R1171     3.0183085799217224e-01
    z[2,3,2]  R1172     0.10428436845541
    z[2,3,2]  R1173     -8.4632897377014160e-01
    z[2,3,2]  R1174     -3.0057021975517273e-01
    z[2,3,2]  R1175     2.6213493943214417e-01
    z[2,3,2]  R1176     -0.735084056854248
    z[2,3,2]  R1177     -7.4791461229324341e-02
    z[2,3,2]  R1178     -7.0140624046325684e-01
    z[2,3,2]  R1179     3.8788110017776489e-01
    z[2,3,2]  R1180     -5.3228235244750977e-01
    z[2,3,2]  R1181     -3.9501330256462097e-01
    z[2,3,2]  R1182     2.4233403801918030e-01
    z[2,3,2]  R1183     -2.6138958334922791e-01
    z[2,3,2]  R1184     -9.5918755978345871e-03
    z[2,3,2]  R1185     -4.9447363615036011e-01
    z[2,3,2]  R1186     -3.5375642776489258e-01
    z[2,3,2]  R1187     -6.2617915868759155e-01
    z[2,3,2]  R1188     -1.7028453946113586e-01
    z[2,3,2]  R1189     -5.8189177513122559e-01
    z[2,3,2]  R1190     -3.6266106367111206e-01
    z[2,3,2]  R1191     6.6317516565322876e-01
    z[2,3,2]  R1192     -2.1971271932125092e-01
    z[2,3,2]  R1193     -5.5164462327957153e-01
    z[2,3,2]  R1194     -6.9032943248748779e-01
    z[2,3,2]  R1195     -5.0332820415496826e-01
    z[2,3,2]  R1196     -1.4362642168998718e-01
    z[2,3,2]  R1197     2.4596190452575684e-01
    z[2,3,2]  R1198     2.1174457669258118e-01
    z[2,3,2]  R1199     -3.6526271700859070e-01
    z[2,3,2]  R1200     1.2382742762565613e-01
    z[2,3,2]  R1201     -0.558544933795929
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1094     -1
    z[2,3,3]  R1095     1
    z[2,3,3]  R1102     -0.163498193025589
    z[2,3,3]  R1103     6.8659073114395142e-01
    z[2,3,3]  R1104     3.6911368370056152e-02
    z[2,3,3]  R1105     -1.1901598423719406e-01
    z[2,3,3]  R1106     0.614919126033783
    z[2,3,3]  R1107     2.5125920772552490e-01
    z[2,3,3]  R1108     -2.8503105044364929e-01
    z[2,3,3]  R1109     -0.292032927274704
    z[2,3,3]  R1110     1.5039514750242233e-02
    z[2,3,3]  R1111     -3.6925175786018372e-01
    z[2,3,3]  R1112     2.8051558881998062e-02
    z[2,3,3]  R1113     -1.2274982780218124e-01
    z[2,3,3]  R1114     -3.4370788931846619e-01
    z[2,3,3]  R1115     -7.5930452346801758e-01
    z[2,3,3]  R1116     0.0903458446264267
    z[2,3,3]  R1117     1.0439489036798477e-02
    z[2,3,3]  R1118     7.2723947465419769e-02
    z[2,3,3]  R1119     1.2909254431724548e-01
    z[2,3,3]  R1120     3.0000284314155579e-01
    z[2,3,3]  R1121     1.7999650537967682e-01
    z[2,3,3]  R1122     2.0185397565364838e-01
    z[2,3,3]  R1123     5.0524938106536865e-01
    z[2,3,3]  R1124     6.9806408882141113e-01
    z[2,3,3]  R1125     -2.5099528953433037e-02
    z[2,3,3]  R1126     -0.358840674161911
    z[2,3,3]  R1127     -3.9803746342658997e-01
    z[2,3,3]  R1128     -5.8572345972061157e-01
    z[2,3,3]  R1129     -5.2110934257507324e-01
    z[2,3,3]  R1130     -3.1147226691246033e-01
    z[2,3,3]  R1131     -0.538877546787262
    z[2,3,3]  R1132     -2.3181436955928802e-01
    z[2,3,3]  R1133     -4.4772112369537354e-01
    z[2,3,3]  R1134     -4.0277552604675293e-01
    z[2,3,3]  R1135     3.4380894899368286e-01
    z[2,3,3]  R1136     -0.393984854221344
    z[2,3,3]  R1137     -4.3403938412666321e-01
    z[2,3,3]  R1138     -3.7225216627120972e-01
    z[2,3,3]  R1139     -0.436993807554245
    z[2,3,3]  R1140     -3.0460822582244873e-01
    z[2,3,3]  R1141     -0.345674991607666
    z[2,3,3]  R1142     7.9763191938400269e-01
    z[2,3,3]  R1143     6.6494739055633545e-01
    z[2,3,3]  R1144     6.6684925556182861e-01
    z[2,3,3]  R1145     3.7392199039459229e-01
    z[2,3,3]  R1146     7.5536668300628662e-01
    z[2,3,3]  R1147     3.7185427546501160e-01
    z[2,3,3]  R1148     5.7558345794677734e-01
    z[2,3,3]  R1149     5.6364989280700684e-01
    z[2,3,3]  R1150     3.1432849168777466e-01
    z[2,3,3]  R1151     0.601999044418335
    z[2,3,3]  R1152     -4.2582151293754578e-01
    z[2,3,3]  R1153     -1.5460880100727081e-01
    z[2,3,3]  R1154     -1.9523912668228149e-01
    z[2,3,3]  R1155     9.0477697551250458e-02
    z[2,3,3]  R1156     -5.2065807580947876e-01
    z[2,3,3]  R1157     -1.8150655925273895e-01
    z[2,3,3]  R1158     -2.5736436247825623e-01
    z[2,3,3]  R1159     -6.2611490488052368e-02
    z[2,3,3]  R1160     -6.5198026597499847e-02
    z[2,3,3]  R1161     -1.1997640132904053e-01
    z[2,3,3]  R1162     2.7967724204063416e-01
    z[2,3,3]  R1163     5.3419440984725952e-01
    z[2,3,3]  R1164     8.6413323879241943e-02
    z[2,3,3]  R1165     2.2495500743389130e-01
    z[2,3,3]  R1166     -6.5599568188190460e-02
    z[2,3,3]  R1167     -6.9331027567386627e-02
    z[2,3,3]  R1168     7.2255417704582214e-02
    z[2,3,3]  R1169     3.0335399508476257e-01
    z[2,3,3]  R1170     4.1781830787658691e-01
    z[2,3,3]  R1171     -5.6925421953201294e-01
    z[2,3,3]  R1172     -1.6221408545970917e-01
    z[2,3,3]  R1173     2.3226570338010788e-02
    z[2,3,3]  R1174     -2.8599998354911804e-01
    z[2,3,3]  R1175     -2.3139625787734985e-02
    z[2,3,3]  R1176     2.3291775584220886e-01
    z[2,3,3]  R1177     2.2588601708412170e-01
    z[2,3,3]  R1178     5.4531472921371460e-01
    z[2,3,3]  R1179     1.6942591965198517e-01
    z[2,3,3]  R1180     5.3970688581466675e-01
    z[2,3,3]  R1181     1.5945779159665108e-03
    z[2,3,3]  R1182     7.2592481970787048e-02
    z[2,3,3]  R1183     -3.9525586366653442e-01
    z[2,3,3]  R1184     -4.1620454192161560e-01
    z[2,3,3]  R1185     1.8690448999404907e-01
    z[2,3,3]  R1186     6.6859899088740349e-03
    z[2,3,3]  R1187     -6.8584673106670380e-02
    z[2,3,3]  R1188     3.2622119784355164e-01
    z[2,3,3]  R1189     2.0877651870250702e-01
    z[2,3,3]  R1190     2.0125991106033325e-01
    z[2,3,3]  R1191     -6.1015486717224121e-01
    z[2,3,3]  R1192     1.4422349631786346e-01
    z[2,3,3]  R1193     1.1832524836063385e-01
    z[2,3,3]  R1194     -6.7909307777881622e-02
    z[2,3,3]  R1195     8.2499362528324127e-02
    z[2,3,3]  R1196     3.1887543201446533e-01
    z[2,3,3]  R1197     3.2872881740331650e-02
    z[2,3,3]  R1198     2.8650152683258057e-01
    z[2,3,3]  R1199     2.9154961928725243e-02
    z[2,3,3]  R1200     3.1599089503288269e-01
    z[2,3,3]  R1201     3.0711406469345093e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1096     -1
    z[2,3,4]  R1097     1
    z[2,3,4]  R1102     -2.4468874931335449e-01
    z[2,3,4]  R1103     3.4097969532012939e-01
    z[2,3,4]  R1104     4.7816172242164612e-01
    z[2,3,4]  R1105     4.7806724905967712e-01
    z[2,3,4]  R1106     2.3337726294994354e-01
    z[2,3,4]  R1107     2.3619548976421356e-01
    z[2,3,4]  R1108     -2.5972619652748108e-01
    z[2,3,4]  R1109     4.1397712193429470e-03
    z[2,3,4]  R1110     -0.293050080537796
    z[2,3,4]  R1111     4.4210076332092285e-01
    z[2,3,4]  R1112     2.0535898208618164e-01
    z[2,3,4]  R1113     0.147923544049263
    z[2,3,4]  R1114     7.8769308328628540e-01
    z[2,3,4]  R1115     -2.9768953099846840e-02
    z[2,3,4]  R1116     6.5864413976669312e-01
    z[2,3,4]  R1117     1.1200571060180664e-01
    z[2,3,4]  R1118     1.2488156557083130e-01
    z[2,3,4]  R1119     -4.2440679669380188e-01
    z[2,3,4]  R1120     -3.5614043474197388e-02
    z[2,3,4]  R1121     -2.4764440953731537e-01
    z[2,3,4]  R1122     3.1631648540496826e-01
    z[2,3,4]  R1123     0.422834575176239
    z[2,3,4]  R1124     0.126910001039505
    z[2,3,4]  R1125     3.3830684423446655e-01
    z[2,3,4]  R1126     2.1739734709262848e-01
    z[2,3,4]  R1127     3.7161913514137268e-01
    z[2,3,4]  R1128     0.201577290892601
    z[2,3,4]  R1129     0.55451899766922
    z[2,3,4]  R1130     -3.8429954648017883e-01
    z[2,3,4]  R1131     5.9853404760360718e-02
    z[2,3,4]  R1132     -4.8964913934469223e-02
    z[2,3,4]  R1133     5.5193908512592316e-02
    z[2,3,4]  R1134     -4.3499651551246643e-01
    z[2,3,4]  R1135     5.3880762308835983e-02
    z[2,3,4]  R1136     -6.8078011274337769e-02
    z[2,3,4]  R1137     -1.6763618588447571e-01
    z[2,3,4]  R1138     -1.6528154909610748e-01
    z[2,3,4]  R1139     -4.5524783432483673e-02
    z[2,3,4]  R1140     0.0381888784468174
    z[2,3,4]  R1141     -4.9342054128646851e-01
    z[2,3,4]  R1142     1.1767548322677612e-01
    z[2,3,4]  R1143     1.7249056696891785e-01
    z[2,3,4]  R1144     -2.6817208528518677e-01
    z[2,3,4]  R1145     -3.3016937971115112e-01
    z[2,3,4]  R1146     -5.6820875033736229e-03
    z[2,3,4]  R1147     -1.5482572838664055e-02
    z[2,3,4]  R1148     -1.2258156388998032e-01
    z[2,3,4]  R1149     2.3047678172588348e-01
    z[2,3,4]  R1150     2.7015358209609985e-01
    z[2,3,4]  R1151     -3.2794106006622314e-01
    z[2,3,4]  R1152     -1.9003254175186157e-01
    z[2,3,4]  R1153     1.6714981198310852e-01
    z[2,3,4]  R1154     -3.6104834079742432e-01
    z[2,3,4]  R1155     3.3447524905204773e-01
    z[2,3,4]  R1156     1.3892273604869843e-01
    z[2,3,4]  R1157     -1.2286851555109024e-01
    z[2,3,4]  R1158     -0.516867995262146
    z[2,3,4]  R1159     -3.9206707477569580e-01
    z[2,3,4]  R1160     3.8908639550209045e-01
    z[2,3,4]  R1161     -6.9490373134613037e-02
    z[2,3,4]  R1162     -1.2628835439682007e-01
    z[2,3,4]  R1163     -1.5086817741394043e-01
    z[2,3,4]  R1164     5.0990754365921021e-01
    z[2,3,4]  R1165     0.221954807639122
    z[2,3,4]  R1166     3.9529573917388916e-01
    z[2,3,4]  R1167     -2.4070492386817932e-01
    z[2,3,4]  R1168     1.9609211385250092e-01
    z[2,3,4]  R1169     3.3434832096099854e-01
    z[2,3,4]  R1170     2.4741759896278381e-01
    z[2,3,4]  R1171     3.8723891973495483e-01
    z[2,3,4]  R1172     -7.8918620944023132e-02
    z[2,3,4]  R1173     -2.8224804997444153e-01
    z[2,3,4]  R1174     3.5960423946380615e-01
    z[2,3,4]  R1175     1.7976656556129456e-01
    z[2,3,4]  R1176     -0.0944976955652237
    z[2,3,4]  R1177     4.1586112976074219e-01
    z[2,3,4]  R1178     0.0369749441742897
    z[2,3,4]  R1179     -8.0548338592052460e-02
    z[2,3,4]  R1180     -3.3165144920349121e-01
    z[2,3,4]  R1181     3.9381337165832520e-01
    z[2,3,4]  R1182     -1.0884880274534225e-01
    z[2,3,4]  R1183     -5.6445185095071793e-02
    z[2,3,4]  R1184     1.8267078697681427e-01
    z[2,3,4]  R1185     -1.2607282400131226e-01
    z[2,3,4]  R1186     -7.9346001148223877e-01
    z[2,3,4]  R1187     -3.8210639357566833e-01
    z[2,3,4]  R1188     -3.9536821842193604e-01
    z[2,3,4]  R1189     -2.9035148024559021e-01
    z[2,3,4]  R1190     -4.5989876985549927e-01
    z[2,3,4]  R1191     -0.0334247350692749
    z[2,3,4]  R1192     2.0210993289947510e-01
    z[2,3,4]  R1193     -1.2239823117852211e-02
    z[2,3,4]  R1194     -1.5212576091289520e-01
    z[2,3,4]  R1195     -6.2422102689743042e-01
    z[2,3,4]  R1196     -3.2902446389198303e-01
    z[2,3,4]  R1197     -3.5859817266464233e-01
    z[2,3,4]  R1198     3.8695797324180603e-01
    z[2,3,4]  R1199     -4.1047602891921997e-01
    z[2,3,4]  R1200     2.9874143004417419e-01
    z[2,3,4]  R1201     -0.427390456199646
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1098     -1
    z[2,3,5]  R1099     1
    z[2,3,5]  R1102     -1.0244369506835938e-01
    z[2,3,5]  R1103     -2.2322522103786469e-01
    z[2,3,5]  R1104     2.5354340672492981e-01
    z[2,3,5]  R1105     3.4518918395042419e-01
    z[2,3,5]  R1106     1.6572073101997375e-01
    z[2,3,5]  R1107     -2.5708499550819397e-01
    z[2,3,5]  R1108     -1.2364705651998520e-01
    z[2,3,5]  R1109     -0.00943324901163578
    z[2,3,5]  R1110     -2.9773488640785217e-01
    z[2,3,5]  R1111     5.2075169980525970e-02
    z[2,3,5]  R1112     -1.4794246852397919e-01
    z[2,3,5]  R1113     6.3866508007049561e-01
    z[2,3,5]  R1114     -7.0044849999248981e-03
    z[2,3,5]  R1115     -0.265982985496521
    z[2,3,5]  R1116     -5.3537738323211670e-01
    z[2,3,5]  R1117     -6.2748926877975464e-01
    z[2,3,5]  R1118     8.4097337722778320e-01
    z[2,3,5]  R1119     3.1948000192642212e-01
    z[2,3,5]  R1120     3.7596064805984497e-01
    z[2,3,5]  R1121     3.4059843420982361e-01
    z[2,3,5]  R1122     0.386809378862381
    z[2,3,5]  R1123     4.4625782966613770e-01
    z[2,3,5]  R1124     -2.3807963728904724e-01
    z[2,3,5]  R1125     -2.9688081145286560e-01
    z[2,3,5]  R1126     -4.5091417431831360e-01
    z[2,3,5]  R1127     1.4373989403247833e-01
    z[2,3,5]  R1128     -2.5141701102256775e-01
    z[2,3,5]  R1129     -2.4925684928894043e-01
    z[2,3,5]  R1130     -1.8825803697109222e-01
    z[2,3,5]  R1131     3.7017375230789185e-01
    z[2,3,5]  R1132     1.7014965415000916e-01
    z[2,3,5]  R1133     -4.2478391528129578e-01
    z[2,3,5]  R1134     2.3235505819320679e-01
    z[2,3,5]  R1135     1.9555102288722992e-01
    z[2,3,5]  R1136     2.1225447952747345e-01
    z[2,3,5]  R1137     1.0172709822654724e-01
    z[2,3,5]  R1138     -1.7702551186084747e-01
    z[2,3,5]  R1139     1.4993183314800262e-01
    z[2,3,5]  R1140     2.3352034389972687e-02
    z[2,3,5]  R1141     7.1231603622436523e-02
    z[2,3,5]  R1142     -1.7235511541366577e-01
    z[2,3,5]  R1143     9.0874463319778442e-02
    z[2,3,5]  R1144     -4.3601825833320618e-01
    z[2,3,5]  R1145     1.3626746833324432e-01
    z[2,3,5]  R1146     -1.3970367610454559e-01
    z[2,3,5]  R1147     -1.0332430899143219e-01
    z[2,3,5]  R1148     -0.326092928647995
    z[2,3,5]  R1149     -2.9079735279083252e-01
    z[2,3,5]  R1150     -4.3435847759246826e-01
    z[2,3,5]  R1151     -1.2726742029190063e-01
    z[2,3,5]  R1152     -2.8780168294906616e-01
    z[2,3,5]  R1153     3.0216421931982040e-02
    z[2,3,5]  R1154     2.1535606682300568e-01
    z[2,3,5]  R1155     -1.5049597620964050e-01
    z[2,3,5]  R1156     2.0277952717151493e-04
    z[2,3,5]  R1157     -5.5093520879745483e-01
    z[2,3,5]  R1158     3.4875091910362244e-01
    z[2,3,5]  R1159     3.7186926603317261e-01
    z[2,3,5]  R1160     1.2121313810348511e-01
    z[2,3,5]  R1161     -1.8821124732494354e-01
    z[2,3,5]  R1162     3.1642279028892517e-01
    z[2,3,5]  R1163     -0.0658579170703888
    z[2,3,5]  R1164     3.0122599005699158e-01
    z[2,3,5]  R1165     2.2972339764237404e-02
    z[2,3,5]  R1166     -1.2041824311017990e-01
    z[2,3,5]  R1167     3.9197036623954773e-01
    z[2,3,5]  R1168     -1.9379844889044762e-02
    z[2,3,5]  R1169     -6.1678741127252579e-02
    z[2,3,5]  R1170     -6.3429638743400574e-02
    z[2,3,5]  R1171     2.6149657368659973e-01
    z[2,3,5]  R1172     1.3480226695537567e-01
    z[2,3,5]  R1173     9.2387810349464417e-02
    z[2,3,5]  R1174     -2.0555862784385681e-01
    z[2,3,5]  R1175     -1.2378104031085968e-01
    z[2,3,5]  R1176     -3.0704462528228760e-01
    z[2,3,5]  R1177     -1.5496802330017090e-01
    z[2,3,5]  R1178     1.0670841485261917e-01
    z[2,3,5]  R1179     -1.9605213403701782e-01
    z[2,3,5]  R1180     4.4633254408836365e-01
    z[2,3,5]  R1181     3.0406826734542847e-01
    z[2,3,5]  R1182     -7.4417233467102051e-02
    z[2,3,5]  R1183     8.5203811526298523e-02
    z[2,3,5]  R1184     2.7012443542480469e-01
    z[2,3,5]  R1185     9.4676263630390167e-02
    z[2,3,5]  R1186     1.8872748315334320e-01
    z[2,3,5]  R1187     5.4099857807159424e-01
    z[2,3,5]  R1188     -5.4565286636352539e-01
    z[2,3,5]  R1189     -1.6689732670783997e-01
    z[2,3,5]  R1190     6.1263066530227661e-01
    z[2,3,5]  R1191     1.7487421631813049e-01
    z[2,3,5]  R1192     -2.8541627526283264e-01
    z[2,3,5]  R1193     -1.9115678966045380e-01
    z[2,3,5]  R1194     5.5060341954231262e-02
    z[2,3,5]  R1195     -5.4392233490943909e-02
    z[2,3,5]  R1196     -4.0359079837799072e-01
    z[2,3,5]  R1197     -1.8619143962860107e-01
    z[2,3,5]  R1198     -1.2645585834980011e-01
    z[2,3,5]  R1199     -1.0071890056133270e-01
    z[2,3,5]  R1200     -5.6475242599844933e-03
    z[2,3,5]  R1201     -0.109067901968956
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1100     -1
    z[2,3,6]  R1101     1
    z[2,3,6]  R1102     -2.9199369251728058e-02
    z[2,3,6]  R1103     -2.5152340531349182e-01
    z[2,3,6]  R1104     -2.5235396623611450e-01
    z[2,3,6]  R1105     -6.3678181171417236e-01
    z[2,3,6]  R1106     -3.0211547017097473e-01
    z[2,3,6]  R1107     -2.9058659076690674e-01
    z[2,3,6]  R1108     -1.3888755440711975e-01
    z[2,3,6]  R1109     -4.8144727945327759e-01
    z[2,3,6]  R1110     -1.2432327866554260e-01
    z[2,3,6]  R1111     -1.3002596795558929e-01
    z[2,3,6]  R1112     1.7518447339534760e-01
    z[2,3,6]  R1113     3.9553910493850708e-02
    z[2,3,6]  R1114     -0.0842975378036499
    z[2,3,6]  R1115     -9.3197010457515717e-02
    z[2,3,6]  R1116     -1.8303576111793518e-01
    z[2,3,6]  R1117     1.2165966443717480e-02
    z[2,3,6]  R1118     3.4312316775321960e-01
    z[2,3,6]  R1119     -2.9089670628309250e-02
    z[2,3,6]  R1120     -5.2251618355512619e-02
    z[2,3,6]  R1121     5.7512146234512329e-01
    z[2,3,6]  R1122     3.2472106814384460e-01
    z[2,3,6]  R1123     -2.6363351941108704e-01
    z[2,3,6]  R1124     1.2952478229999542e-01
    z[2,3,6]  R1125     -7.1082763373851776e-02
    z[2,3,6]  R1126     1.6599176824092865e-01
    z[2,3,6]  R1127     -1.8111509084701538e-01
    z[2,3,6]  R1128     1.5518435835838318e-01
    z[2,3,6]  R1129     -3.8468629121780396e-02
    z[2,3,6]  R1130     3.8003259897232056e-01
    z[2,3,6]  R1131     1.2658430635929108e-01
    z[2,3,6]  R1132     -8.7334677577018738e-02
    z[2,3,6]  R1133     -6.0142739675939083e-03
    z[2,3,6]  R1134     -2.1511197090148926e-02
    z[2,3,6]  R1135     -1.4263409376144409e-01
    z[2,3,6]  R1136     -4.6441400051116943e-01
    z[2,3,6]  R1137     -5.9535163640975952e-01
    z[2,3,6]  R1138     -4.9260437488555908e-01
    z[2,3,6]  R1139     -5.4002481698989868e-01
    z[2,3,6]  R1140     -2.4094898998737335e-01
    z[2,3,6]  R1141     -4.2733040452003479e-01
    z[2,3,6]  R1142     1.5698526799678802e-01
    z[2,3,6]  R1143     -1.5782795846462250e-01
    z[2,3,6]  R1144     -7.6108537614345551e-02
    z[2,3,6]  R1145     1.4965327084064484e-01
    z[2,3,6]  R1146     -9.0734608471393585e-02
    z[2,3,6]  R1147     -3.2037842273712158e-01
    z[2,3,6]  R1148     4.4052439928054810e-01
    z[2,3,6]  R1149     2.0833517611026764e-01
    z[2,3,6]  R1150     -3.4928861260414124e-01
    z[2,3,6]  R1151     2.9489165544509888e-01
    z[2,3,6]  R1152     6.1515177367255092e-04
    z[2,3,6]  R1153     4.6298485994338989e-01
    z[2,3,6]  R1154     -2.2220499813556671e-01
    z[2,3,6]  R1155     4.0010184049606323e-01
    z[2,3,6]  R1156     3.2092493772506714e-01
    z[2,3,6]  R1157     -8.5266232490539551e-02
    z[2,3,6]  R1158     -1.0100036161020398e-04
    z[2,3,6]  R1159     2.5116398930549622e-01
    z[2,3,6]  R1160     -8.1232629716396332e-02
    z[2,3,6]  R1161     1.4770555496215820e-01
    z[2,3,6]  R1162     1.1533907800912857e-01
    z[2,3,6]  R1163     1.5381710231304169e-01
    z[2,3,6]  R1164     8.8793292641639709e-02
    z[2,3,6]  R1165     -2.6950512081384659e-02
    z[2,3,6]  R1166     4.3488475680351257e-01
    z[2,3,6]  R1167     2.4490984156727791e-02
    z[2,3,6]  R1168     -6.1473004519939423e-02
    z[2,3,6]  R1169     -1.6112464666366577e-01
    z[2,3,6]  R1170     4.9912306666374207e-01
    z[2,3,6]  R1171     5.3253639489412308e-02
    z[2,3,6]  R1172     2.6396813988685608e-01
    z[2,3,6]  R1173     -8.4703646600246429e-02
    z[2,3,6]  R1174     -1.8765434622764587e-01
    z[2,3,6]  R1175     -2.0507527887821198e-01
    z[2,3,6]  R1176     3.4222784638404846e-01
    z[2,3,6]  R1177     -1.0279571637511253e-02
    z[2,3,6]  R1178     -2.3415200412273407e-01
    z[2,3,6]  R1179     0.39665687084198
    z[2,3,6]  R1180     -1.1886099725961685e-01
    z[2,3,6]  R1181     -1.3070569932460785e-01
    z[2,3,6]  R1182     3.5307818651199341e-01
    z[2,3,6]  R1183     -4.9115438014268875e-02
    z[2,3,6]  R1184     -2.7694234251976013e-01
    z[2,3,6]  R1185     1.7937886714935303e-01
    z[2,3,6]  R1186     -7.9604998230934143e-02
    z[2,3,6]  R1187     -1.4860881865024567e-01
    z[2,3,6]  R1188     1.1060429364442825e-01
    z[2,3,6]  R1189     -4.7008684277534485e-01
    z[2,3,6]  R1190     1.5651646256446838e-01
    z[2,3,6]  R1191     -1.4176055788993835e-01
    z[2,3,6]  R1192     2.8541889786720276e-01
    z[2,3,6]  R1193     2.6265071704983711e-02
    z[2,3,6]  R1194     -5.2953604608774185e-02
    z[2,3,6]  R1195     2.1357278525829315e-01
    z[2,3,6]  R1196     8.4018506109714508e-02
    z[2,3,6]  R1197     -1.7056916654109955e-01
    z[2,3,6]  R1198     -2.9217815026640892e-02
    z[2,3,6]  R1199     -2.2908061742782593e-01
    z[2,3,6]  R1200     4.5333832502365112e-01
    z[2,3,6]  R1201     -4.8690277338027954e-01
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1202     -1
    z[3,2,0]  R1203     1
    z[3,2,0]  R1216     3.9363589882850647e-01
    z[3,2,0]  R1217     -7.7881030738353729e-02
    z[3,2,0]  R1218     1.2821778655052185e-01
    z[3,2,0]  R1219     3.5443133115768433e-01
    z[3,2,0]  R1220     -2.3074150085449219e-01
    z[3,2,0]  R1221     6.7675068974494934e-02
    z[3,2,0]  R1222     -2.4353887140750885e-01
    z[3,2,0]  R1223     -1.4388197660446167e-01
    z[3,2,0]  R1224     -5.3544437885284424e-01
    z[3,2,0]  R1225     1.2710736691951752e-01
    z[3,2,0]  R1226     -7.2518303990364075e-02
    z[3,2,0]  R1227     2.1276114881038666e-01
    z[3,2,0]  R1228     9.2758513987064362e-02
    z[3,2,0]  R1229     -1.2157166004180908e-01
    z[3,2,0]  R1230     1.4774616062641144e-01
    z[3,2,0]  R1231     -0.0848345085978508
    z[3,2,0]  R1232     2.5067931413650513e-01
    z[3,2,0]  R1233     4.2221829295158386e-01
    z[3,2,0]  R1234     -4.6629492193460464e-02
    z[3,2,0]  R1235     -1.1889804154634476e-01
    z[3,2,0]  R1236     2.8773501515388489e-01
    z[3,2,0]  R1237     -0.0851939395070076
    z[3,2,0]  R1238     -2.0846106112003326e-01
    z[3,2,0]  R1239     -1.5841172635555267e-01
    z[3,2,0]  R1240     7.9185582697391510e-02
    z[3,2,0]  R1241     2.4980646371841431e-01
    z[3,2,0]  R1242     1.7832493782043457e-01
    z[3,2,0]  R1243     1.1742538958787918e-01
    z[3,2,0]  R1244     -3.5878166556358337e-01
    z[3,2,0]  R1245     3.6712247133255005e-01
    z[3,2,0]  R1246     1.2598113715648651e-01
    z[3,2,0]  R1247     -2.2572505474090576e-01
    z[3,2,0]  R1248     -1.5283916890621185e-01
    z[3,2,0]  R1249     3.5271936655044556e-01
    z[3,2,0]  R1250     -1.6366019845008850e-01
    z[3,2,0]  R1251     -2.7820643782615662e-01
    z[3,2,0]  R1252     -0.468054860830307
    z[3,2,0]  R1253     -9.4501510262489319e-02
    z[3,2,0]  R1254     3.8991760462522507e-02
    z[3,2,0]  R1255     -2.3824974894523621e-01
    z[3,2,0]  R1256     -1.8255129456520081e-01
    z[3,2,0]  R1257     -0.285730242729187
    z[3,2,0]  R1258     4.2138494551181793e-02
    z[3,2,0]  R1259     -0.242917999625206
    z[3,2,0]  R1260     1.5073123574256897e-01
    z[3,2,0]  R1261     1.1461414396762848e-01
    z[3,2,0]  R1262     -1.9538788124918938e-02
    z[3,2,0]  R1263     -3.9183203130960464e-02
    z[3,2,0]  R1264     1.1523278802633286e-01
    z[3,2,0]  R1265     -1.1464959383010864e-01
    z[3,2,0]  R1266     -2.0538076758384705e-01
    z[3,2,0]  R1267     -2.9686164855957031e-01
    z[3,2,0]  R1268     -3.1057798862457275e-01
    z[3,2,0]  R1269     -5.8969402313232422e-01
    z[3,2,0]  R1270     3.8537446409463882e-02
    z[3,2,0]  R1271     -9.2446170747280121e-02
    z[3,2,0]  R1272     1.3703256845474243e-01
    z[3,2,0]  R1273     4.2776057124137878e-01
    z[3,2,0]  R1274     -1.9621905684471130e-01
    z[3,2,0]  R1275     -2.0587362349033356e-01
    z[3,2,0]  R1276     3.5219132900238037e-02
    z[3,2,0]  R1277     -6.8545721471309662e-02
    z[3,2,0]  R1278     -1.5081923454999924e-02
    z[3,2,0]  R1279     8.9163705706596375e-03
    z[3,2,0]  R1280     1.5945617854595184e-01
    z[3,2,0]  R1281     -8.2971222698688507e-02
    z[3,2,0]  R1282     3.8412243127822876e-01
    z[3,2,0]  R1283     4.4668781757354736e-01
    z[3,2,0]  R1284     2.2310416400432587e-01
    z[3,2,0]  R1285     0.0798686295747757
    z[3,2,0]  R1286     -7.5763440132141113e-01
    z[3,2,0]  R1287     -3.5594639182090759e-01
    z[3,2,0]  R1288     -3.3674496412277222e-01
    z[3,2,0]  R1289     -4.6896842122077942e-01
    z[3,2,0]  R1290     -3.4761473536491394e-01
    z[3,2,0]  R1291     6.3949227333068848e-01
    z[3,2,0]  R1292     5.7122337818145752e-01
    z[3,2,0]  R1293     5.5334341526031494e-01
    z[3,2,0]  R1294     6.2901252508163452e-01
    z[3,2,0]  R1295     6.4777708053588867e-01
    z[3,2,0]  R1296     8.9310312271118164e-01
    z[3,2,0]  R1297     6.7466163635253906e-01
    z[3,2,0]  R1298     4.7219786047935486e-01
    z[3,2,0]  R1299     3.4431955218315125e-01
    z[3,2,0]  R1300     4.4713634252548218e-01
    z[3,2,0]  R1301     2.8827935457229614e-01
    z[3,2,0]  R1302     5.7758674025535583e-02
    z[3,2,0]  R1303     -1.9007632136344910e-01
    z[3,2,0]  R1304     -3.2289337366819382e-02
    z[3,2,0]  R1305     4.1105908155441284e-01
    z[3,2,0]  R1306     1.5849551558494568e-01
    z[3,2,0]  R1307     -5.3203213214874268e-01
    z[3,2,0]  R1308     -1.8916991539299488e-03
    z[3,2,0]  R1309     8.5165905952453613e-01
    z[3,2,0]  R1310     3.1775584816932678e-01
    z[3,2,0]  R1311     6.9684040546417236e-01
    z[3,2,0]  R1312     6.7209112644195557e-01
    z[3,2,0]  R1313     5.7442098855972290e-01
    z[3,2,0]  R1314     7.3271125555038452e-01
    z[3,2,0]  R1315     7.4017584323883057e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1204     -1
    z[3,2,1]  R1205     1
    z[3,2,1]  R1216     -8.4875416755676270e-01
    z[3,2,1]  R1217     -7.6350408792495728e-01
    z[3,2,1]  R1218     -6.9220441579818726e-01
    z[3,2,1]  R1219     -7.5259184837341309e-01
    z[3,2,1]  R1220     -6.5914791822433472e-01
    z[3,2,1]  R1221     -6.3478189706802368e-01
    z[3,2,1]  R1222     -6.9675922393798828e-01
    z[3,2,1]  R1223     -6.8594950437545776e-01
    z[3,2,1]  R1224     -0.720085084438324
    z[3,2,1]  R1225     -0.654482364654541
    z[3,2,1]  R1226     5.3756970167160034e-01
    z[3,2,1]  R1227     6.7018610239028931e-01
    z[3,2,1]  R1228     5.2114909887313843e-01
    z[3,2,1]  R1229     8.0826961994171143e-01
    z[3,2,1]  R1230     5.2093577384948730e-01
    z[3,2,1]  R1231     0.766403079032898
    z[3,2,1]  R1232     5.3823846578598022e-01
    z[3,2,1]  R1233     5.6191658973693848e-01
    z[3,2,1]  R1234     6.8640989065170288e-01
    z[3,2,1]  R1235     5.8817285299301147e-01
    z[3,2,1]  R1236     -7.7654361724853516e-01
    z[3,2,1]  R1237     8.1427836418151855e-01
    z[3,2,1]  R1238     8.0048912763595581e-01
    z[3,2,1]  R1239     7.3714506626129150e-01
    z[3,2,1]  R1240     7.5503402948379517e-01
    z[3,2,1]  R1241     7.5513535737991333e-01
    z[3,2,1]  R1242     0.715343713760376
    z[3,2,1]  R1243     2.7329745888710022e-01
    z[3,2,1]  R1244     -0.789559006690979
    z[3,2,1]  R1245     0.406112939119339
    z[3,2,1]  R1246     8.8111555576324463e-01
    z[3,2,1]  R1247     7.5951015949249268e-01
    z[3,2,1]  R1248     7.7988177537918091e-01
    z[3,2,1]  R1249     8.7794524431228638e-01
    z[3,2,1]  R1250     -7.8032869100570679e-01
    z[3,2,1]  R1251     3.7118464708328247e-01
    z[3,2,1]  R1252     8.0645316839218140e-01
    z[3,2,1]  R1253     -6.7775064706802368e-01
    z[3,2,1]  R1254     -6.1478763818740845e-01
    z[3,2,1]  R1255     -0.553998589515686
    z[3,2,1]  R1256     -9.1400617361068726e-01
    z[3,2,1]  R1257     3.2584023475646973e-01
    z[3,2,1]  R1258     7.8695756196975708e-01
    z[3,2,1]  R1259     8.8433420658111572e-01
    z[3,2,1]  R1260     4.0293261408805847e-01
    z[3,2,1]  R1261     8.5626173019409180e-01
    z[3,2,1]  R1262     0.377754271030426
    z[3,2,1]  R1263     7.8552317619323730e-01
    z[3,2,1]  R1264     2.9795980453491211e-01
    z[3,2,1]  R1265     -7.5245392322540283e-01
    z[3,2,1]  R1266     8.6704850196838379e-01
    z[3,2,1]  R1267     8.2125717401504517e-01
    z[3,2,1]  R1268     7.3972302675247192e-01
    z[3,2,1]  R1269     5.6195092201232910e-01
    z[3,2,1]  R1270     4.4921347498893738e-01
    z[3,2,1]  R1271     3.6589628458023071e-01
    z[3,2,1]  R1272     6.1605077981948853e-01
    z[3,2,1]  R1273     3.1889653205871582e-01
    z[3,2,1]  R1274     4.2207670211791992e-01
    z[3,2,1]  R1275     -3.0615600943565369e-01
    z[3,2,1]  R1276     -8.5200399160385132e-01
    z[3,2,1]  R1277     7.9975503683090210e-01
    z[3,2,1]  R1278     6.9973438978195190e-01
    z[3,2,1]  R1279     5.4913687705993652e-01
    z[3,2,1]  R1280     7.5766873359680176e-01
    z[3,2,1]  R1281     8.5975813865661621e-01
    z[3,2,1]  R1282     -7.4762952327728271e-01
    z[3,2,1]  R1283     0.659613847732544
    z[3,2,1]  R1284     7.3501503467559814e-01
    z[3,2,1]  R1285     3.9458429813385010e-01
    z[3,2,1]  R1286     -5.7247555255889893e-01
    z[3,2,1]  R1287     -1.9509056210517883e-01
    z[3,2,1]  R1288     -1.3002958893775940e-01
    z[3,2,1]  R1289     7.6499380171298981e-02
    z[3,2,1]  R1290     -6.3221082091331482e-02
    z[3,2,1]  R1291     2.0963333547115326e-01
    z[3,2,1]  R1292     -2.9543524980545044e-01
    z[3,2,1]  R1293     1.5673731267452240e-01
    z[3,2,1]  R1294     3.5808345675468445e-01
    z[3,2,1]  R1295     -1.4877294003963470e-01
    z[3,2,1]  R1296     2.1393451094627380e-01
    z[3,2,1]  R1297     1.0662592202425003e-01
    z[3,2,1]  R1298     -1.2335491180419922e-01
    z[3,2,1]  R1299     3.4935352206230164e-01
    z[3,2,1]  R1300     -1.6240717470645905e-01
    z[3,2,1]  R1301     -4.1114783287048340e-01
    z[3,2,1]  R1302     -3.5746926069259644e-01
    z[3,2,1]  R1303     6.5801191329956055e-01
    z[3,2,1]  R1304     5.5531173944473267e-01
    z[3,2,1]  R1305     -5.3824466466903687e-01
    z[3,2,1]  R1306     -7.4476402997970581e-01
    z[3,2,1]  R1307     1.4811581932008266e-02
    z[3,2,1]  R1308     -5.6641560792922974e-01
    z[3,2,1]  R1309     -7.9814761877059937e-02
    z[3,2,1]  R1310     -6.5438163280487061e-01
    z[3,2,1]  R1311     2.6334342360496521e-01
    z[3,2,1]  R1312     -1.6322395205497742e-01
    z[3,2,1]  R1313     -0.0738137811422348
    z[3,2,1]  R1314     1.2664929032325745e-02
    z[3,2,1]  R1315     -6.9266386330127716e-02
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1206     -1
    z[3,2,2]  R1207     1
    z[3,2,2]  R1216     -1.7875541746616364e-01
    z[3,2,2]  R1217     1.6437128186225891e-01
    z[3,2,2]  R1218     3.1386566162109375e-01
    z[3,2,2]  R1219     -3.5817819833755493e-01
    z[3,2,2]  R1220     3.0280584096908569e-01
    z[3,2,2]  R1221     -1.0577351599931717e-01
    z[3,2,2]  R1222     -1.2380877882242203e-01
    z[3,2,2]  R1223     -4.0357332676649094e-02
    z[3,2,2]  R1224     2.0476941764354706e-01
    z[3,2,2]  R1225     -6.9687180221080780e-02
    z[3,2,2]  R1226     -3.6673773080110550e-02
    z[3,2,2]  R1227     2.2529596462845802e-02
    z[3,2,2]  R1228     8.5387177765369415e-02
    z[3,2,2]  R1229     2.0524667203426361e-01
    z[3,2,2]  R1230     -0.329296350479126
    z[3,2,2]  R1231     -3.9191302657127380e-01
    z[3,2,2]  R1232     2.7171965688467026e-02
    z[3,2,2]  R1233     8.4818713366985321e-02
    z[3,2,2]  R1234     2.1026635169982910e-01
    z[3,2,2]  R1235     -2.5847575068473816e-01
    z[3,2,2]  R1236     1.1799214035272598e-01
    z[3,2,2]  R1237     2.5016331672668457e-01
    z[3,2,2]  R1238     2.2700999677181244e-01
    z[3,2,2]  R1239     -3.5879313945770264e-01
    z[3,2,2]  R1240     1.7400035262107849e-01
    z[3,2,2]  R1241     9.2336907982826233e-02
    z[3,2,2]  R1242     3.8307376205921173e-02
    z[3,2,2]  R1243     -7.4331218004226685e-01
    z[3,2,2]  R1244     -2.6634940505027771e-01
    z[3,2,2]  R1245     -0.789828896522522
    z[3,2,2]  R1246     1.3020043261349201e-02
    z[3,2,2]  R1247     -1.8992304801940918e-01
    z[3,2,2]  R1248     4.8273853957653046e-02
    z[3,2,2]  R1249     -6.0649521648883820e-02
    z[3,2,2]  R1250     0.0107242651283741
    z[3,2,2]  R1251     -7.5354951620101929e-01
    z[3,2,2]  R1252     0.287629097700119
    z[3,2,2]  R1253     5.4602712392807007e-01
    z[3,2,2]  R1254     -3.6274090409278870e-01
    z[3,2,2]  R1255     3.0183085799217224e-01
    z[3,2,2]  R1256     0.10428436845541
    z[3,2,2]  R1257     -8.4632897377014160e-01
    z[3,2,2]  R1258     -3.0057021975517273e-01
    z[3,2,2]  R1259     2.6213493943214417e-01
    z[3,2,2]  R1260     -0.735084056854248
    z[3,2,2]  R1261     -7.4791461229324341e-02
    z[3,2,2]  R1262     -7.0140624046325684e-01
    z[3,2,2]  R1263     3.8788110017776489e-01
    z[3,2,2]  R1264     -5.3228235244750977e-01
    z[3,2,2]  R1265     -3.9501330256462097e-01
    z[3,2,2]  R1266     2.4233403801918030e-01
    z[3,2,2]  R1267     -2.6138958334922791e-01
    z[3,2,2]  R1268     -9.5918755978345871e-03
    z[3,2,2]  R1269     -4.9447363615036011e-01
    z[3,2,2]  R1270     -3.5375642776489258e-01
    z[3,2,2]  R1271     -6.2617915868759155e-01
    z[3,2,2]  R1272     -1.7028453946113586e-01
    z[3,2,2]  R1273     -5.8189177513122559e-01
    z[3,2,2]  R1274     -3.6266106367111206e-01
    z[3,2,2]  R1275     6.6317516565322876e-01
    z[3,2,2]  R1276     -2.1971271932125092e-01
    z[3,2,2]  R1277     -5.5164462327957153e-01
    z[3,2,2]  R1278     -6.9032943248748779e-01
    z[3,2,2]  R1279     -5.0332820415496826e-01
    z[3,2,2]  R1280     -1.4362642168998718e-01
    z[3,2,2]  R1281     2.4596190452575684e-01
    z[3,2,2]  R1282     2.1174457669258118e-01
    z[3,2,2]  R1283     -3.6526271700859070e-01
    z[3,2,2]  R1284     1.2382742762565613e-01
    z[3,2,2]  R1285     -0.558544933795929
    z[3,2,2]  R1286     1.7613766714930534e-02
    z[3,2,2]  R1287     -3.6670750379562378e-01
    z[3,2,2]  R1288     -7.1535122394561768e-01
    z[3,2,2]  R1289     -8.2804977893829346e-02
    z[3,2,2]  R1290     0.569068968296051
    z[3,2,2]  R1291     5.2692568302154541e-01
    z[3,2,2]  R1292     6.3493561744689941e-01
    z[3,2,2]  R1293     5.9334945678710938e-01
    z[3,2,2]  R1294     5.3470802307128906e-01
    z[3,2,2]  R1295     -4.5478877425193787e-01
    z[3,2,2]  R1296     -2.4710918962955475e-01
    z[3,2,2]  R1297     2.9505258798599243e-01
    z[3,2,2]  R1298     -1.2673631310462952e-01
    z[3,2,2]  R1299     3.2020923495292664e-01
    z[3,2,2]  R1300     1.0764550417661667e-01
    z[3,2,2]  R1301     5.8421516418457031e-01
    z[3,2,2]  R1302     1.5174217522144318e-01
    z[3,2,2]  R1303     -4.8082387447357178e-01
    z[3,2,2]  R1304     -6.7471444606781006e-01
    z[3,2,2]  R1305     2.8716100379824638e-02
    z[3,2,2]  R1306     1.5601059794425964e-01
    z[3,2,2]  R1307     1.1835405975580215e-01
    z[3,2,2]  R1308     -3.1986206769943237e-01
    z[3,2,2]  R1309     2.4501834809780121e-01
    z[3,2,2]  R1310     -2.5280582904815674e-01
    z[3,2,2]  R1311     3.0832657217979431e-01
    z[3,2,2]  R1312     2.2506318986415863e-01
    z[3,2,2]  R1313     -1.4811097085475922e-01
    z[3,2,2]  R1314     1.9597634673118591e-01
    z[3,2,2]  R1315     1.7840493470430374e-02
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1208     -1
    z[3,2,3]  R1209     1
    z[3,2,3]  R1216     -2.3181436955928802e-01
    z[3,2,3]  R1217     -4.4772112369537354e-01
    z[3,2,3]  R1218     -4.0277552604675293e-01
    z[3,2,3]  R1219     3.4380894899368286e-01
    z[3,2,3]  R1220     -0.393984854221344
    z[3,2,3]  R1221     -4.3403938412666321e-01
    z[3,2,3]  R1222     -3.7225216627120972e-01
    z[3,2,3]  R1223     -0.436993807554245
    z[3,2,3]  R1224     -3.0460822582244873e-01
    z[3,2,3]  R1225     -0.345674991607666
    z[3,2,3]  R1226     7.9763191938400269e-01
    z[3,2,3]  R1227     6.6494739055633545e-01
    z[3,2,3]  R1228     6.6684925556182861e-01
    z[3,2,3]  R1229     3.7392199039459229e-01
    z[3,2,3]  R1230     7.5536668300628662e-01
    z[3,2,3]  R1231     3.7185427546501160e-01
    z[3,2,3]  R1232     5.7558345794677734e-01
    z[3,2,3]  R1233     5.6364989280700684e-01
    z[3,2,3]  R1234     3.1432849168777466e-01
    z[3,2,3]  R1235     0.601999044418335
    z[3,2,3]  R1236     -4.2582151293754578e-01
    z[3,2,3]  R1237     -1.5460880100727081e-01
    z[3,2,3]  R1238     -1.9523912668228149e-01
    z[3,2,3]  R1239     9.0477697551250458e-02
    z[3,2,3]  R1240     -5.2065807580947876e-01
    z[3,2,3]  R1241     -1.8150655925273895e-01
    z[3,2,3]  R1242     -2.5736436247825623e-01
    z[3,2,3]  R1243     -6.2611490488052368e-02
    z[3,2,3]  R1244     -6.5198026597499847e-02
    z[3,2,3]  R1245     -1.1997640132904053e-01
    z[3,2,3]  R1246     2.7967724204063416e-01
    z[3,2,3]  R1247     5.3419440984725952e-01
    z[3,2,3]  R1248     8.6413323879241943e-02
    z[3,2,3]  R1249     2.2495500743389130e-01
    z[3,2,3]  R1250     -6.5599568188190460e-02
    z[3,2,3]  R1251     -6.9331027567386627e-02
    z[3,2,3]  R1252     7.2255417704582214e-02
    z[3,2,3]  R1253     3.0335399508476257e-01
    z[3,2,3]  R1254     4.1781830787658691e-01
    z[3,2,3]  R1255     -5.6925421953201294e-01
    z[3,2,3]  R1256     -1.6221408545970917e-01
    z[3,2,3]  R1257     2.3226570338010788e-02
    z[3,2,3]  R1258     -2.8599998354911804e-01
    z[3,2,3]  R1259     -2.3139625787734985e-02
    z[3,2,3]  R1260     2.3291775584220886e-01
    z[3,2,3]  R1261     2.2588601708412170e-01
    z[3,2,3]  R1262     5.4531472921371460e-01
    z[3,2,3]  R1263     1.6942591965198517e-01
    z[3,2,3]  R1264     5.3970688581466675e-01
    z[3,2,3]  R1265     1.5945779159665108e-03
    z[3,2,3]  R1266     7.2592481970787048e-02
    z[3,2,3]  R1267     -3.9525586366653442e-01
    z[3,2,3]  R1268     -4.1620454192161560e-01
    z[3,2,3]  R1269     1.8690448999404907e-01
    z[3,2,3]  R1270     6.6859899088740349e-03
    z[3,2,3]  R1271     -6.8584673106670380e-02
    z[3,2,3]  R1272     3.2622119784355164e-01
    z[3,2,3]  R1273     2.0877651870250702e-01
    z[3,2,3]  R1274     2.0125991106033325e-01
    z[3,2,3]  R1275     -6.1015486717224121e-01
    z[3,2,3]  R1276     1.4422349631786346e-01
    z[3,2,3]  R1277     1.1832524836063385e-01
    z[3,2,3]  R1278     -6.7909307777881622e-02
    z[3,2,3]  R1279     8.2499362528324127e-02
    z[3,2,3]  R1280     3.1887543201446533e-01
    z[3,2,3]  R1281     3.2872881740331650e-02
    z[3,2,3]  R1282     2.8650152683258057e-01
    z[3,2,3]  R1283     2.9154961928725243e-02
    z[3,2,3]  R1284     3.1599089503288269e-01
    z[3,2,3]  R1285     3.0711406469345093e-01
    z[3,2,3]  R1286     -0.163498193025589
    z[3,2,3]  R1287     6.8659073114395142e-01
    z[3,2,3]  R1288     3.6911368370056152e-02
    z[3,2,3]  R1289     -1.1901598423719406e-01
    z[3,2,3]  R1290     0.614919126033783
    z[3,2,3]  R1291     2.5125920772552490e-01
    z[3,2,3]  R1292     -2.8503105044364929e-01
    z[3,2,3]  R1293     -0.292032927274704
    z[3,2,3]  R1294     1.5039514750242233e-02
    z[3,2,3]  R1295     -3.6925175786018372e-01
    z[3,2,3]  R1296     2.8051558881998062e-02
    z[3,2,3]  R1297     -1.2274982780218124e-01
    z[3,2,3]  R1298     -3.4370788931846619e-01
    z[3,2,3]  R1299     -7.5930452346801758e-01
    z[3,2,3]  R1300     0.0903458446264267
    z[3,2,3]  R1301     1.0439489036798477e-02
    z[3,2,3]  R1302     7.2723947465419769e-02
    z[3,2,3]  R1303     1.2909254431724548e-01
    z[3,2,3]  R1304     3.0000284314155579e-01
    z[3,2,3]  R1305     1.7999650537967682e-01
    z[3,2,3]  R1306     2.0185397565364838e-01
    z[3,2,3]  R1307     5.0524938106536865e-01
    z[3,2,3]  R1308     6.9806408882141113e-01
    z[3,2,3]  R1309     -2.5099528953433037e-02
    z[3,2,3]  R1310     -0.358840674161911
    z[3,2,3]  R1311     -3.9803746342658997e-01
    z[3,2,3]  R1312     -5.8572345972061157e-01
    z[3,2,3]  R1313     -5.2110934257507324e-01
    z[3,2,3]  R1314     -3.1147226691246033e-01
    z[3,2,3]  R1315     -0.538877546787262
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1210     -1
    z[3,2,4]  R1211     1
    z[3,2,4]  R1216     -4.8964913934469223e-02
    z[3,2,4]  R1217     5.5193908512592316e-02
    z[3,2,4]  R1218     -4.3499651551246643e-01
    z[3,2,4]  R1219     5.3880762308835983e-02
    z[3,2,4]  R1220     -6.8078011274337769e-02
    z[3,2,4]  R1221     -1.6763618588447571e-01
    z[3,2,4]  R1222     -1.6528154909610748e-01
    z[3,2,4]  R1223     -4.5524783432483673e-02
    z[3,2,4]  R1224     0.0381888784468174
    z[3,2,4]  R1225     -4.9342054128646851e-01
    z[3,2,4]  R1226     1.1767548322677612e-01
    z[3,2,4]  R1227     1.7249056696891785e-01
    z[3,2,4]  R1228     -2.6817208528518677e-01
    z[3,2,4]  R1229     -3.3016937971115112e-01
    z[3,2,4]  R1230     -5.6820875033736229e-03
    z[3,2,4]  R1231     -1.5482572838664055e-02
    z[3,2,4]  R1232     -1.2258156388998032e-01
    z[3,2,4]  R1233     2.3047678172588348e-01
    z[3,2,4]  R1234     2.7015358209609985e-01
    z[3,2,4]  R1235     -3.2794106006622314e-01
    z[3,2,4]  R1236     -1.9003254175186157e-01
    z[3,2,4]  R1237     1.6714981198310852e-01
    z[3,2,4]  R1238     -3.6104834079742432e-01
    z[3,2,4]  R1239     3.3447524905204773e-01
    z[3,2,4]  R1240     1.3892273604869843e-01
    z[3,2,4]  R1241     -1.2286851555109024e-01
    z[3,2,4]  R1242     -0.516867995262146
    z[3,2,4]  R1243     -3.9206707477569580e-01
    z[3,2,4]  R1244     3.8908639550209045e-01
    z[3,2,4]  R1245     -6.9490373134613037e-02
    z[3,2,4]  R1246     -1.2628835439682007e-01
    z[3,2,4]  R1247     -1.5086817741394043e-01
    z[3,2,4]  R1248     5.0990754365921021e-01
    z[3,2,4]  R1249     0.221954807639122
    z[3,2,4]  R1250     3.9529573917388916e-01
    z[3,2,4]  R1251     -2.4070492386817932e-01
    z[3,2,4]  R1252     1.9609211385250092e-01
    z[3,2,4]  R1253     3.3434832096099854e-01
    z[3,2,4]  R1254     2.4741759896278381e-01
    z[3,2,4]  R1255     3.8723891973495483e-01
    z[3,2,4]  R1256     -7.8918620944023132e-02
    z[3,2,4]  R1257     -2.8224804997444153e-01
    z[3,2,4]  R1258     3.5960423946380615e-01
    z[3,2,4]  R1259     1.7976656556129456e-01
    z[3,2,4]  R1260     -0.0944976955652237
    z[3,2,4]  R1261     4.1586112976074219e-01
    z[3,2,4]  R1262     0.0369749441742897
    z[3,2,4]  R1263     -8.0548338592052460e-02
    z[3,2,4]  R1264     -3.3165144920349121e-01
    z[3,2,4]  R1265     3.9381337165832520e-01
    z[3,2,4]  R1266     -1.0884880274534225e-01
    z[3,2,4]  R1267     -5.6445185095071793e-02
    z[3,2,4]  R1268     1.8267078697681427e-01
    z[3,2,4]  R1269     -1.2607282400131226e-01
    z[3,2,4]  R1270     -7.9346001148223877e-01
    z[3,2,4]  R1271     -3.8210639357566833e-01
    z[3,2,4]  R1272     -3.9536821842193604e-01
    z[3,2,4]  R1273     -2.9035148024559021e-01
    z[3,2,4]  R1274     -4.5989876985549927e-01
    z[3,2,4]  R1275     -0.0334247350692749
    z[3,2,4]  R1276     2.0210993289947510e-01
    z[3,2,4]  R1277     -1.2239823117852211e-02
    z[3,2,4]  R1278     -1.5212576091289520e-01
    z[3,2,4]  R1279     -6.2422102689743042e-01
    z[3,2,4]  R1280     -3.2902446389198303e-01
    z[3,2,4]  R1281     -3.5859817266464233e-01
    z[3,2,4]  R1282     3.8695797324180603e-01
    z[3,2,4]  R1283     -4.1047602891921997e-01
    z[3,2,4]  R1284     2.9874143004417419e-01
    z[3,2,4]  R1285     -0.427390456199646
    z[3,2,4]  R1286     -2.4468874931335449e-01
    z[3,2,4]  R1287     3.4097969532012939e-01
    z[3,2,4]  R1288     4.7816172242164612e-01
    z[3,2,4]  R1289     4.7806724905967712e-01
    z[3,2,4]  R1290     2.3337726294994354e-01
    z[3,2,4]  R1291     2.3619548976421356e-01
    z[3,2,4]  R1292     -2.5972619652748108e-01
    z[3,2,4]  R1293     4.1397712193429470e-03
    z[3,2,4]  R1294     -0.293050080537796
    z[3,2,4]  R1295     4.4210076332092285e-01
    z[3,2,4]  R1296     2.0535898208618164e-01
    z[3,2,4]  R1297     0.147923544049263
    z[3,2,4]  R1298     7.8769308328628540e-01
    z[3,2,4]  R1299     -2.9768953099846840e-02
    z[3,2,4]  R1300     6.5864413976669312e-01
    z[3,2,4]  R1301     1.1200571060180664e-01
    z[3,2,4]  R1302     1.2488156557083130e-01
    z[3,2,4]  R1303     -4.2440679669380188e-01
    z[3,2,4]  R1304     -3.5614043474197388e-02
    z[3,2,4]  R1305     -2.4764440953731537e-01
    z[3,2,4]  R1306     3.1631648540496826e-01
    z[3,2,4]  R1307     0.422834575176239
    z[3,2,4]  R1308     0.126910001039505
    z[3,2,4]  R1309     3.3830684423446655e-01
    z[3,2,4]  R1310     2.1739734709262848e-01
    z[3,2,4]  R1311     3.7161913514137268e-01
    z[3,2,4]  R1312     0.201577290892601
    z[3,2,4]  R1313     0.55451899766922
    z[3,2,4]  R1314     -3.8429954648017883e-01
    z[3,2,4]  R1315     5.9853404760360718e-02
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1212     -1
    z[3,2,5]  R1213     1
    z[3,2,5]  R1216     1.7014965415000916e-01
    z[3,2,5]  R1217     -4.2478391528129578e-01
    z[3,2,5]  R1218     2.3235505819320679e-01
    z[3,2,5]  R1219     1.9555102288722992e-01
    z[3,2,5]  R1220     2.1225447952747345e-01
    z[3,2,5]  R1221     1.0172709822654724e-01
    z[3,2,5]  R1222     -1.7702551186084747e-01
    z[3,2,5]  R1223     1.4993183314800262e-01
    z[3,2,5]  R1224     2.3352034389972687e-02
    z[3,2,5]  R1225     7.1231603622436523e-02
    z[3,2,5]  R1226     -1.7235511541366577e-01
    z[3,2,5]  R1227     9.0874463319778442e-02
    z[3,2,5]  R1228     -4.3601825833320618e-01
    z[3,2,5]  R1229     1.3626746833324432e-01
    z[3,2,5]  R1230     -1.3970367610454559e-01
    z[3,2,5]  R1231     -1.0332430899143219e-01
    z[3,2,5]  R1232     -0.326092928647995
    z[3,2,5]  R1233     -2.9079735279083252e-01
    z[3,2,5]  R1234     -4.3435847759246826e-01
    z[3,2,5]  R1235     -1.2726742029190063e-01
    z[3,2,5]  R1236     -2.8780168294906616e-01
    z[3,2,5]  R1237     3.0216421931982040e-02
    z[3,2,5]  R1238     2.1535606682300568e-01
    z[3,2,5]  R1239     -1.5049597620964050e-01
    z[3,2,5]  R1240     2.0277952717151493e-04
    z[3,2,5]  R1241     -5.5093520879745483e-01
    z[3,2,5]  R1242     3.4875091910362244e-01
    z[3,2,5]  R1243     3.7186926603317261e-01
    z[3,2,5]  R1244     1.2121313810348511e-01
    z[3,2,5]  R1245     -1.8821124732494354e-01
    z[3,2,5]  R1246     3.1642279028892517e-01
    z[3,2,5]  R1247     -0.0658579170703888
    z[3,2,5]  R1248     3.0122599005699158e-01
    z[3,2,5]  R1249     2.2972339764237404e-02
    z[3,2,5]  R1250     -1.2041824311017990e-01
    z[3,2,5]  R1251     3.9197036623954773e-01
    z[3,2,5]  R1252     -1.9379844889044762e-02
    z[3,2,5]  R1253     -6.1678741127252579e-02
    z[3,2,5]  R1254     -6.3429638743400574e-02
    z[3,2,5]  R1255     2.6149657368659973e-01
    z[3,2,5]  R1256     1.3480226695537567e-01
    z[3,2,5]  R1257     9.2387810349464417e-02
    z[3,2,5]  R1258     -2.0555862784385681e-01
    z[3,2,5]  R1259     -1.2378104031085968e-01
    z[3,2,5]  R1260     -3.0704462528228760e-01
    z[3,2,5]  R1261     -1.5496802330017090e-01
    z[3,2,5]  R1262     1.0670841485261917e-01
    z[3,2,5]  R1263     -1.9605213403701782e-01
    z[3,2,5]  R1264     4.4633254408836365e-01
    z[3,2,5]  R1265     3.0406826734542847e-01
    z[3,2,5]  R1266     -7.4417233467102051e-02
    z[3,2,5]  R1267     8.5203811526298523e-02
    z[3,2,5]  R1268     2.7012443542480469e-01
    z[3,2,5]  R1269     9.4676263630390167e-02
    z[3,2,5]  R1270     1.8872748315334320e-01
    z[3,2,5]  R1271     5.4099857807159424e-01
    z[3,2,5]  R1272     -5.4565286636352539e-01
    z[3,2,5]  R1273     -1.6689732670783997e-01
    z[3,2,5]  R1274     6.1263066530227661e-01
    z[3,2,5]  R1275     1.7487421631813049e-01
    z[3,2,5]  R1276     -2.8541627526283264e-01
    z[3,2,5]  R1277     -1.9115678966045380e-01
    z[3,2,5]  R1278     5.5060341954231262e-02
    z[3,2,5]  R1279     -5.4392233490943909e-02
    z[3,2,5]  R1280     -4.0359079837799072e-01
    z[3,2,5]  R1281     -1.8619143962860107e-01
    z[3,2,5]  R1282     -1.2645585834980011e-01
    z[3,2,5]  R1283     -1.0071890056133270e-01
    z[3,2,5]  R1284     -5.6475242599844933e-03
    z[3,2,5]  R1285     -0.109067901968956
    z[3,2,5]  R1286     -1.0244369506835938e-01
    z[3,2,5]  R1287     -2.2322522103786469e-01
    z[3,2,5]  R1288     2.5354340672492981e-01
    z[3,2,5]  R1289     3.4518918395042419e-01
    z[3,2,5]  R1290     1.6572073101997375e-01
    z[3,2,5]  R1291     -2.5708499550819397e-01
    z[3,2,5]  R1292     -1.2364705651998520e-01
    z[3,2,5]  R1293     -0.00943324901163578
    z[3,2,5]  R1294     -2.9773488640785217e-01
    z[3,2,5]  R1295     5.2075169980525970e-02
    z[3,2,5]  R1296     -1.4794246852397919e-01
    z[3,2,5]  R1297     6.3866508007049561e-01
    z[3,2,5]  R1298     -7.0044849999248981e-03
    z[3,2,5]  R1299     -0.265982985496521
    z[3,2,5]  R1300     -5.3537738323211670e-01
    z[3,2,5]  R1301     -6.2748926877975464e-01
    z[3,2,5]  R1302     8.4097337722778320e-01
    z[3,2,5]  R1303     3.1948000192642212e-01
    z[3,2,5]  R1304     3.7596064805984497e-01
    z[3,2,5]  R1305     3.4059843420982361e-01
    z[3,2,5]  R1306     0.386809378862381
    z[3,2,5]  R1307     4.4625782966613770e-01
    z[3,2,5]  R1308     -2.3807963728904724e-01
    z[3,2,5]  R1309     -2.9688081145286560e-01
    z[3,2,5]  R1310     -4.5091417431831360e-01
    z[3,2,5]  R1311     1.4373989403247833e-01
    z[3,2,5]  R1312     -2.5141701102256775e-01
    z[3,2,5]  R1313     -2.4925684928894043e-01
    z[3,2,5]  R1314     -1.8825803697109222e-01
    z[3,2,5]  R1315     3.7017375230789185e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1214     -1
    z[3,2,6]  R1215     1
    z[3,2,6]  R1216     -8.7334677577018738e-02
    z[3,2,6]  R1217     -6.0142739675939083e-03
    z[3,2,6]  R1218     -2.1511197090148926e-02
    z[3,2,6]  R1219     -1.4263409376144409e-01
    z[3,2,6]  R1220     -4.6441400051116943e-01
    z[3,2,6]  R1221     -5.9535163640975952e-01
    z[3,2,6]  R1222     -4.9260437488555908e-01
    z[3,2,6]  R1223     -5.4002481698989868e-01
    z[3,2,6]  R1224     -2.4094898998737335e-01
    z[3,2,6]  R1225     -4.2733040452003479e-01
    z[3,2,6]  R1226     1.5698526799678802e-01
    z[3,2,6]  R1227     -1.5782795846462250e-01
    z[3,2,6]  R1228     -7.6108537614345551e-02
    z[3,2,6]  R1229     1.4965327084064484e-01
    z[3,2,6]  R1230     -9.0734608471393585e-02
    z[3,2,6]  R1231     -3.2037842273712158e-01
    z[3,2,6]  R1232     4.4052439928054810e-01
    z[3,2,6]  R1233     2.0833517611026764e-01
    z[3,2,6]  R1234     -3.4928861260414124e-01
    z[3,2,6]  R1235     2.9489165544509888e-01
    z[3,2,6]  R1236     6.1515177367255092e-04
    z[3,2,6]  R1237     4.6298485994338989e-01
    z[3,2,6]  R1238     -2.2220499813556671e-01
    z[3,2,6]  R1239     4.0010184049606323e-01
    z[3,2,6]  R1240     3.2092493772506714e-01
    z[3,2,6]  R1241     -8.5266232490539551e-02
    z[3,2,6]  R1242     -1.0100036161020398e-04
    z[3,2,6]  R1243     2.5116398930549622e-01
    z[3,2,6]  R1244     -8.1232629716396332e-02
    z[3,2,6]  R1245     1.4770555496215820e-01
    z[3,2,6]  R1246     1.1533907800912857e-01
    z[3,2,6]  R1247     1.5381710231304169e-01
    z[3,2,6]  R1248     8.8793292641639709e-02
    z[3,2,6]  R1249     -2.6950512081384659e-02
    z[3,2,6]  R1250     4.3488475680351257e-01
    z[3,2,6]  R1251     2.4490984156727791e-02
    z[3,2,6]  R1252     -6.1473004519939423e-02
    z[3,2,6]  R1253     -1.6112464666366577e-01
    z[3,2,6]  R1254     4.9912306666374207e-01
    z[3,2,6]  R1255     5.3253639489412308e-02
    z[3,2,6]  R1256     2.6396813988685608e-01
    z[3,2,6]  R1257     -8.4703646600246429e-02
    z[3,2,6]  R1258     -1.8765434622764587e-01
    z[3,2,6]  R1259     -2.0507527887821198e-01
    z[3,2,6]  R1260     3.4222784638404846e-01
    z[3,2,6]  R1261     -1.0279571637511253e-02
    z[3,2,6]  R1262     -2.3415200412273407e-01
    z[3,2,6]  R1263     0.39665687084198
    z[3,2,6]  R1264     -1.1886099725961685e-01
    z[3,2,6]  R1265     -1.3070569932460785e-01
    z[3,2,6]  R1266     3.5307818651199341e-01
    z[3,2,6]  R1267     -4.9115438014268875e-02
    z[3,2,6]  R1268     -2.7694234251976013e-01
    z[3,2,6]  R1269     1.7937886714935303e-01
    z[3,2,6]  R1270     -7.9604998230934143e-02
    z[3,2,6]  R1271     -1.4860881865024567e-01
    z[3,2,6]  R1272     1.1060429364442825e-01
    z[3,2,6]  R1273     -4.7008684277534485e-01
    z[3,2,6]  R1274     1.5651646256446838e-01
    z[3,2,6]  R1275     -1.4176055788993835e-01
    z[3,2,6]  R1276     2.8541889786720276e-01
    z[3,2,6]  R1277     2.6265071704983711e-02
    z[3,2,6]  R1278     -5.2953604608774185e-02
    z[3,2,6]  R1279     2.1357278525829315e-01
    z[3,2,6]  R1280     8.4018506109714508e-02
    z[3,2,6]  R1281     -1.7056916654109955e-01
    z[3,2,6]  R1282     -2.9217815026640892e-02
    z[3,2,6]  R1283     -2.2908061742782593e-01
    z[3,2,6]  R1284     4.5333832502365112e-01
    z[3,2,6]  R1285     -4.8690277338027954e-01
    z[3,2,6]  R1286     -2.9199369251728058e-02
    z[3,2,6]  R1287     -2.5152340531349182e-01
    z[3,2,6]  R1288     -2.5235396623611450e-01
    z[3,2,6]  R1289     -6.3678181171417236e-01
    z[3,2,6]  R1290     -3.0211547017097473e-01
    z[3,2,6]  R1291     -2.9058659076690674e-01
    z[3,2,6]  R1292     -1.3888755440711975e-01
    z[3,2,6]  R1293     -4.8144727945327759e-01
    z[3,2,6]  R1294     -1.2432327866554260e-01
    z[3,2,6]  R1295     -1.3002596795558929e-01
    z[3,2,6]  R1296     1.7518447339534760e-01
    z[3,2,6]  R1297     3.9553910493850708e-02
    z[3,2,6]  R1298     -0.0842975378036499
    z[3,2,6]  R1299     -9.3197010457515717e-02
    z[3,2,6]  R1300     -1.8303576111793518e-01
    z[3,2,6]  R1301     1.2165966443717480e-02
    z[3,2,6]  R1302     3.4312316775321960e-01
    z[3,2,6]  R1303     -2.9089670628309250e-02
    z[3,2,6]  R1304     -5.2251618355512619e-02
    z[3,2,6]  R1305     5.7512146234512329e-01
    z[3,2,6]  R1306     3.2472106814384460e-01
    z[3,2,6]  R1307     -2.6363351941108704e-01
    z[3,2,6]  R1308     1.2952478229999542e-01
    z[3,2,6]  R1309     -7.1082763373851776e-02
    z[3,2,6]  R1310     1.6599176824092865e-01
    z[3,2,6]  R1311     -1.8111509084701538e-01
    z[3,2,6]  R1312     1.5518435835838318e-01
    z[3,2,6]  R1313     -3.8468629121780396e-02
    z[3,2,6]  R1314     3.8003259897232056e-01
    z[3,2,6]  R1315     1.2658430635929108e-01
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1316     -1
    z[3,7,0]  R1317     1
    z[3,7,0]  R1330     3.9363589882850647e-01
    z[3,7,0]  R1331     -7.7881030738353729e-02
    z[3,7,0]  R1332     1.2821778655052185e-01
    z[3,7,0]  R1333     3.5443133115768433e-01
    z[3,7,0]  R1334     -2.3074150085449219e-01
    z[3,7,0]  R1335     6.7675068974494934e-02
    z[3,7,0]  R1336     -2.4353887140750885e-01
    z[3,7,0]  R1337     -1.4388197660446167e-01
    z[3,7,0]  R1338     -5.3544437885284424e-01
    z[3,7,0]  R1339     1.2710736691951752e-01
    z[3,7,0]  R1340     -7.2518303990364075e-02
    z[3,7,0]  R1341     2.1276114881038666e-01
    z[3,7,0]  R1342     9.2758513987064362e-02
    z[3,7,0]  R1343     -1.2157166004180908e-01
    z[3,7,0]  R1344     1.4774616062641144e-01
    z[3,7,0]  R1345     -0.0848345085978508
    z[3,7,0]  R1346     2.5067931413650513e-01
    z[3,7,0]  R1347     4.2221829295158386e-01
    z[3,7,0]  R1348     -4.6629492193460464e-02
    z[3,7,0]  R1349     -1.1889804154634476e-01
    z[3,7,0]  R1350     2.8773501515388489e-01
    z[3,7,0]  R1351     -0.0851939395070076
    z[3,7,0]  R1352     -2.0846106112003326e-01
    z[3,7,0]  R1353     -1.5841172635555267e-01
    z[3,7,0]  R1354     7.9185582697391510e-02
    z[3,7,0]  R1355     2.4980646371841431e-01
    z[3,7,0]  R1356     1.7832493782043457e-01
    z[3,7,0]  R1357     1.1742538958787918e-01
    z[3,7,0]  R1358     -3.5878166556358337e-01
    z[3,7,0]  R1359     3.6712247133255005e-01
    z[3,7,0]  R1360     1.2598113715648651e-01
    z[3,7,0]  R1361     -2.2572505474090576e-01
    z[3,7,0]  R1362     -1.5283916890621185e-01
    z[3,7,0]  R1363     3.5271936655044556e-01
    z[3,7,0]  R1364     -1.6366019845008850e-01
    z[3,7,0]  R1365     -2.7820643782615662e-01
    z[3,7,0]  R1366     -0.468054860830307
    z[3,7,0]  R1367     -9.4501510262489319e-02
    z[3,7,0]  R1368     3.8991760462522507e-02
    z[3,7,0]  R1369     -2.3824974894523621e-01
    z[3,7,0]  R1370     -1.8255129456520081e-01
    z[3,7,0]  R1371     -0.285730242729187
    z[3,7,0]  R1372     4.2138494551181793e-02
    z[3,7,0]  R1373     -0.242917999625206
    z[3,7,0]  R1374     1.5073123574256897e-01
    z[3,7,0]  R1375     1.1461414396762848e-01
    z[3,7,0]  R1376     -1.9538788124918938e-02
    z[3,7,0]  R1377     -3.9183203130960464e-02
    z[3,7,0]  R1378     1.1523278802633286e-01
    z[3,7,0]  R1379     -1.1464959383010864e-01
    z[3,7,0]  R1380     -2.0538076758384705e-01
    z[3,7,0]  R1381     -2.9686164855957031e-01
    z[3,7,0]  R1382     -3.1057798862457275e-01
    z[3,7,0]  R1383     -5.8969402313232422e-01
    z[3,7,0]  R1384     3.8537446409463882e-02
    z[3,7,0]  R1385     -9.2446170747280121e-02
    z[3,7,0]  R1386     1.3703256845474243e-01
    z[3,7,0]  R1387     4.2776057124137878e-01
    z[3,7,0]  R1388     -1.9621905684471130e-01
    z[3,7,0]  R1389     -2.0587362349033356e-01
    z[3,7,0]  R1390     3.5219132900238037e-02
    z[3,7,0]  R1391     -6.8545721471309662e-02
    z[3,7,0]  R1392     -1.5081923454999924e-02
    z[3,7,0]  R1393     8.9163705706596375e-03
    z[3,7,0]  R1394     1.5945617854595184e-01
    z[3,7,0]  R1395     -8.2971222698688507e-02
    z[3,7,0]  R1396     3.8412243127822876e-01
    z[3,7,0]  R1397     4.4668781757354736e-01
    z[3,7,0]  R1398     2.2310416400432587e-01
    z[3,7,0]  R1399     0.0798686295747757
    z[3,7,0]  R1400     -4.0147697925567627e-01
    z[3,7,0]  R1401     -2.7795320749282837e-01
    z[3,7,0]  R1402     4.7752074897289276e-04
    z[3,7,0]  R1403     7.9634189605712891e-02
    z[3,7,0]  R1404     -1.6077496111392975e-01
    z[3,7,0]  R1405     -2.4796119332313538e-01
    z[3,7,0]  R1406     -2.7985778450965881e-01
    z[3,7,0]  R1407     -7.9454638063907623e-02
    z[3,7,0]  R1408     2.3005454242229462e-01
    z[3,7,0]  R1409     -2.9637056589126587e-01
    z[3,7,0]  R1410     -4.5852547883987427e-01
    z[3,7,0]  R1411     2.1899484097957611e-01
    z[3,7,0]  R1412     -2.5554949045181274e-01
    z[3,7,0]  R1413     -1.4372719824314117e-01
    z[3,7,0]  R1414     -0.145126074552536
    z[3,7,0]  R1415     -8.3650238811969757e-03
    z[3,7,0]  R1416     -1.2346358271315694e-03
    z[3,7,0]  R1417     9.3800291419029236e-02
    z[3,7,0]  R1418     -2.1994057297706604e-01
    z[3,7,0]  R1419     4.4037255644798279e-01
    z[3,7,0]  R1420     1.0263575240969658e-02
    z[3,7,0]  R1421     -1.1668379604816437e-01
    z[3,7,0]  R1422     1.0058578848838806e-01
    z[3,7,0]  R1423     2.2934967279434204e-01
    z[3,7,0]  R1424     4.3210152536630630e-02
    z[3,7,0]  R1425     7.5677320361137390e-02
    z[3,7,0]  R1426     4.0831130743026733e-01
    z[3,7,0]  R1427     -2.7307519316673279e-01
    z[3,7,0]  R1428     1.2010221928358078e-01
    z[3,7,0]  R1429     -1.7229756712913513e-01
    z[3,7,0]  R1430     3.0183336138725281e-01
    z[3,7,0]  R1431     1.2099771946668625e-01
    z[3,7,0]  R1432     -5.6635860353708267e-02
    z[3,7,0]  R1433     -1.4152922667562962e-02
    z[3,7,0]  R1434     -1.4258608222007751e-01
    z[3,7,0]  R1435     -2.2895622253417969e-01
    z[3,7,0]  R1436     -2.5274334475398064e-02
    z[3,7,0]  R1437     2.6467061042785645e-01
    z[3,7,0]  R1438     -2.0422524213790894e-01
    z[3,7,0]  R1439     -1.0240741074085236e-01
    z[3,7,0]  R1440     -2.5584363937377930e-01
    z[3,7,0]  R1441     2.0791180431842804e-01
    z[3,7,0]  R1442     1.1191520839929581e-02
    z[3,7,0]  R1443     -2.5737819075584412e-01
    z[3,7,0]  R1444     -5.8369133621454239e-02
    z[3,7,0]  R1445     -0.169291153550148
    z[3,7,0]  R1446     -8.6377680301666260e-02
    z[3,7,0]  R1447     4.8517894744873047e-01
    z[3,7,0]  R1448     8.3977186679840088e-01
    z[3,7,0]  R1449     8.7542843818664551e-01
    z[3,7,0]  R1450     1.7060812562704086e-02
    z[3,7,0]  R1451     -1.5379984676837921e-01
    z[3,7,0]  R1452     4.6583107113838196e-01
    z[3,7,0]  R1453     8.7543791532516479e-01
    z[3,7,0]  R1454     8.6454147100448608e-01
    z[3,7,0]  R1455     9.3073451519012451e-01
    z[3,7,0]  R1456     8.6799871921539307e-01
    z[3,7,0]  R1457     8.6702954769134521e-01
    z[3,7,0]  R1458     0.69090735912323
    z[3,7,0]  R1459     7.6937586069107056e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1318     -1
    z[3,7,1]  R1319     1
    z[3,7,1]  R1330     -8.4875416755676270e-01
    z[3,7,1]  R1331     -7.6350408792495728e-01
    z[3,7,1]  R1332     -6.9220441579818726e-01
    z[3,7,1]  R1333     -7.5259184837341309e-01
    z[3,7,1]  R1334     -6.5914791822433472e-01
    z[3,7,1]  R1335     -6.3478189706802368e-01
    z[3,7,1]  R1336     -6.9675922393798828e-01
    z[3,7,1]  R1337     -6.8594950437545776e-01
    z[3,7,1]  R1338     -0.720085084438324
    z[3,7,1]  R1339     -0.654482364654541
    z[3,7,1]  R1340     5.3756970167160034e-01
    z[3,7,1]  R1341     6.7018610239028931e-01
    z[3,7,1]  R1342     5.2114909887313843e-01
    z[3,7,1]  R1343     8.0826961994171143e-01
    z[3,7,1]  R1344     5.2093577384948730e-01
    z[3,7,1]  R1345     0.766403079032898
    z[3,7,1]  R1346     5.3823846578598022e-01
    z[3,7,1]  R1347     5.6191658973693848e-01
    z[3,7,1]  R1348     6.8640989065170288e-01
    z[3,7,1]  R1349     5.8817285299301147e-01
    z[3,7,1]  R1350     -7.7654361724853516e-01
    z[3,7,1]  R1351     8.1427836418151855e-01
    z[3,7,1]  R1352     8.0048912763595581e-01
    z[3,7,1]  R1353     7.3714506626129150e-01
    z[3,7,1]  R1354     7.5503402948379517e-01
    z[3,7,1]  R1355     7.5513535737991333e-01
    z[3,7,1]  R1356     0.715343713760376
    z[3,7,1]  R1357     2.7329745888710022e-01
    z[3,7,1]  R1358     -0.789559006690979
    z[3,7,1]  R1359     0.406112939119339
    z[3,7,1]  R1360     8.8111555576324463e-01
    z[3,7,1]  R1361     7.5951015949249268e-01
    z[3,7,1]  R1362     7.7988177537918091e-01
    z[3,7,1]  R1363     8.7794524431228638e-01
    z[3,7,1]  R1364     -7.8032869100570679e-01
    z[3,7,1]  R1365     3.7118464708328247e-01
    z[3,7,1]  R1366     8.0645316839218140e-01
    z[3,7,1]  R1367     -6.7775064706802368e-01
    z[3,7,1]  R1368     -6.1478763818740845e-01
    z[3,7,1]  R1369     -0.553998589515686
    z[3,7,1]  R1370     -9.1400617361068726e-01
    z[3,7,1]  R1371     3.2584023475646973e-01
    z[3,7,1]  R1372     7.8695756196975708e-01
    z[3,7,1]  R1373     8.8433420658111572e-01
    z[3,7,1]  R1374     4.0293261408805847e-01
    z[3,7,1]  R1375     8.5626173019409180e-01
    z[3,7,1]  R1376     0.377754271030426
    z[3,7,1]  R1377     7.8552317619323730e-01
    z[3,7,1]  R1378     2.9795980453491211e-01
    z[3,7,1]  R1379     -7.5245392322540283e-01
    z[3,7,1]  R1380     8.6704850196838379e-01
    z[3,7,1]  R1381     8.2125717401504517e-01
    z[3,7,1]  R1382     7.3972302675247192e-01
    z[3,7,1]  R1383     5.6195092201232910e-01
    z[3,7,1]  R1384     4.4921347498893738e-01
    z[3,7,1]  R1385     3.6589628458023071e-01
    z[3,7,1]  R1386     6.1605077981948853e-01
    z[3,7,1]  R1387     3.1889653205871582e-01
    z[3,7,1]  R1388     4.2207670211791992e-01
    z[3,7,1]  R1389     -3.0615600943565369e-01
    z[3,7,1]  R1390     -8.5200399160385132e-01
    z[3,7,1]  R1391     7.9975503683090210e-01
    z[3,7,1]  R1392     6.9973438978195190e-01
    z[3,7,1]  R1393     5.4913687705993652e-01
    z[3,7,1]  R1394     7.5766873359680176e-01
    z[3,7,1]  R1395     8.5975813865661621e-01
    z[3,7,1]  R1396     -7.4762952327728271e-01
    z[3,7,1]  R1397     0.659613847732544
    z[3,7,1]  R1398     7.3501503467559814e-01
    z[3,7,1]  R1399     3.9458429813385010e-01
    z[3,7,1]  R1400     -0.792862057685852
    z[3,7,1]  R1401     -8.1954658031463623e-01
    z[3,7,1]  R1402     -6.6718286275863647e-01
    z[3,7,1]  R1403     -6.7747443914413452e-01
    z[3,7,1]  R1404     2.8316763043403625e-01
    z[3,7,1]  R1405     -7.3923337459564209e-01
    z[3,7,1]  R1406     -6.8647295236587524e-01
    z[3,7,1]  R1407     -7.0364880561828613e-01
    z[3,7,1]  R1408     3.2303416728973389e-01
    z[3,7,1]  R1409     -5.6314653158187866e-01
    z[3,7,1]  R1410     6.8391436338424683e-01
    z[3,7,1]  R1411     8.6980056762695312e-01
    z[3,7,1]  R1412     7.7416473627090454e-01
    z[3,7,1]  R1413     8.3667856454849243e-01
    z[3,7,1]  R1414     8.3614146709442139e-01
    z[3,7,1]  R1415     8.0098909139633179e-01
    z[3,7,1]  R1416     6.5583300590515137e-01
    z[3,7,1]  R1417     8.5407376289367676e-01
    z[3,7,1]  R1418     9.0580403804779053e-01
    z[3,7,1]  R1419     7.8876417875289917e-01
    z[3,7,1]  R1420     -0.846510648727417
    z[3,7,1]  R1421     0.522493302822113
    z[3,7,1]  R1422     6.8824869394302368e-01
    z[3,7,1]  R1423     0.554186999797821
    z[3,7,1]  R1424     6.6140025854110718e-01
    z[3,7,1]  R1425     8.2619863748550415e-01
    z[3,7,1]  R1426     6.1974310874938965e-01
    z[3,7,1]  R1427     5.3694736957550049e-01
    z[3,7,1]  R1428     8.2902026176452637e-01
    z[3,7,1]  R1429     -6.7995643615722656e-01
    z[3,7,1]  R1430     8.4084117412567139e-01
    z[3,7,1]  R1431     5.5545192956924438e-01
    z[3,7,1]  R1432     -7.8371101617813110e-01
    z[3,7,1]  R1433     9.0411221981048584e-01
    z[3,7,1]  R1434     -7.2659420967102051e-01
    z[3,7,1]  R1435     7.7271562814712524e-01
    z[3,7,1]  R1436     0.766904354095459
    z[3,7,1]  R1437     -7.4562501907348633e-01
    z[3,7,1]  R1438     -6.0926431417465210e-01
    z[3,7,1]  R1439     -6.2725478410720825e-01
    z[3,7,1]  R1440     -9.0961802005767822e-01
    z[3,7,1]  R1441     -8.6140263080596924e-01
    z[3,7,1]  R1442     -7.8772956132888794e-01
    z[3,7,1]  R1443     -7.0141094923019409e-01
    z[3,7,1]  R1444     -0.740615963935852
    z[3,7,1]  R1445     7.6043474674224854e-01
    z[3,7,1]  R1446     0.636716902256012
    z[3,7,1]  R1447     -6.6063940525054932e-01
    z[3,7,1]  R1448     -8.4272943437099457e-02
    z[3,7,1]  R1449     9.9190972745418549e-02
    z[3,7,1]  R1450     7.1808320283889771e-01
    z[3,7,1]  R1451     0.739051103591919
    z[3,7,1]  R1452     -7.6281589269638062e-01
    z[3,7,1]  R1453     9.3487896025180817e-02
    z[3,7,1]  R1454     -1.1479447595775127e-02
    z[3,7,1]  R1455     1.2435419112443924e-01
    z[3,7,1]  R1456     -2.7331715449690819e-02
    z[3,7,1]  R1457     -5.5350143462419510e-02
    z[3,7,1]  R1458     -1.9552321732044220e-01
    z[3,7,1]  R1459     -4.2967148125171661e-02
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1320     -1
    z[3,7,2]  R1321     1
    z[3,7,2]  R1330     -1.7875541746616364e-01
    z[3,7,2]  R1331     1.6437128186225891e-01
    z[3,7,2]  R1332     3.1386566162109375e-01
    z[3,7,2]  R1333     -3.5817819833755493e-01
    z[3,7,2]  R1334     3.0280584096908569e-01
    z[3,7,2]  R1335     -1.0577351599931717e-01
    z[3,7,2]  R1336     -1.2380877882242203e-01
    z[3,7,2]  R1337     -4.0357332676649094e-02
    z[3,7,2]  R1338     2.0476941764354706e-01
    z[3,7,2]  R1339     -6.9687180221080780e-02
    z[3,7,2]  R1340     -3.6673773080110550e-02
    z[3,7,2]  R1341     2.2529596462845802e-02
    z[3,7,2]  R1342     8.5387177765369415e-02
    z[3,7,2]  R1343     2.0524667203426361e-01
    z[3,7,2]  R1344     -0.329296350479126
    z[3,7,2]  R1345     -3.9191302657127380e-01
    z[3,7,2]  R1346     2.7171965688467026e-02
    z[3,7,2]  R1347     8.4818713366985321e-02
    z[3,7,2]  R1348     2.1026635169982910e-01
    z[3,7,2]  R1349     -2.5847575068473816e-01
    z[3,7,2]  R1350     1.1799214035272598e-01
    z[3,7,2]  R1351     2.5016331672668457e-01
    z[3,7,2]  R1352     2.2700999677181244e-01
    z[3,7,2]  R1353     -3.5879313945770264e-01
    z[3,7,2]  R1354     1.7400035262107849e-01
    z[3,7,2]  R1355     9.2336907982826233e-02
    z[3,7,2]  R1356     3.8307376205921173e-02
    z[3,7,2]  R1357     -7.4331218004226685e-01
    z[3,7,2]  R1358     -2.6634940505027771e-01
    z[3,7,2]  R1359     -0.789828896522522
    z[3,7,2]  R1360     1.3020043261349201e-02
    z[3,7,2]  R1361     -1.8992304801940918e-01
    z[3,7,2]  R1362     4.8273853957653046e-02
    z[3,7,2]  R1363     -6.0649521648883820e-02
    z[3,7,2]  R1364     0.0107242651283741
    z[3,7,2]  R1365     -7.5354951620101929e-01
    z[3,7,2]  R1366     0.287629097700119
    z[3,7,2]  R1367     5.4602712392807007e-01
    z[3,7,2]  R1368     -3.6274090409278870e-01
    z[3,7,2]  R1369     3.0183085799217224e-01
    z[3,7,2]  R1370     0.10428436845541
    z[3,7,2]  R1371     -8.4632897377014160e-01
    z[3,7,2]  R1372     -3.0057021975517273e-01
    z[3,7,2]  R1373     2.6213493943214417e-01
    z[3,7,2]  R1374     -0.735084056854248
    z[3,7,2]  R1375     -7.4791461229324341e-02
    z[3,7,2]  R1376     -7.0140624046325684e-01
    z[3,7,2]  R1377     3.8788110017776489e-01
    z[3,7,2]  R1378     -5.3228235244750977e-01
    z[3,7,2]  R1379     -3.9501330256462097e-01
    z[3,7,2]  R1380     2.4233403801918030e-01
    z[3,7,2]  R1381     -2.6138958334922791e-01
    z[3,7,2]  R1382     -9.5918755978345871e-03
    z[3,7,2]  R1383     -4.9447363615036011e-01
    z[3,7,2]  R1384     -3.5375642776489258e-01
    z[3,7,2]  R1385     -6.2617915868759155e-01
    z[3,7,2]  R1386     -1.7028453946113586e-01
    z[3,7,2]  R1387     -5.8189177513122559e-01
    z[3,7,2]  R1388     -3.6266106367111206e-01
    z[3,7,2]  R1389     6.6317516565322876e-01
    z[3,7,2]  R1390     -2.1971271932125092e-01
    z[3,7,2]  R1391     -5.5164462327957153e-01
    z[3,7,2]  R1392     -6.9032943248748779e-01
    z[3,7,2]  R1393     -5.0332820415496826e-01
    z[3,7,2]  R1394     -1.4362642168998718e-01
    z[3,7,2]  R1395     2.4596190452575684e-01
    z[3,7,2]  R1396     2.1174457669258118e-01
    z[3,7,2]  R1397     -3.6526271700859070e-01
    z[3,7,2]  R1398     1.2382742762565613e-01
    z[3,7,2]  R1399     -0.558544933795929
    z[3,7,2]  R1400     -3.1393519043922424e-01
    z[3,7,2]  R1401     2.6484060287475586e-01
    z[3,7,2]  R1402     3.9245903491973877e-01
    z[3,7,2]  R1403     -2.4120378494262695e-01
    z[3,7,2]  R1404     2.0590874552726746e-01
    z[3,7,2]  R1405     -0.0811953991651535
    z[3,7,2]  R1406     1.0469920188188553e-01
    z[3,7,2]  R1407     -3.9110708236694336e-01
    z[3,7,2]  R1408     -2.0833921432495117e-01
    z[3,7,2]  R1409     1.2931351363658905e-01
    z[3,7,2]  R1410     -1.3372267782688141e-01
    z[3,7,2]  R1411     4.0922638773918152e-01
    z[3,7,2]  R1412     3.1756168603897095e-01
    z[3,7,2]  R1413     0.203582301735878
    z[3,7,2]  R1414     1.8200094997882843e-01
    z[3,7,2]  R1415     -2.1236424148082733e-01
    z[3,7,2]  R1416     0.50497967004776
    z[3,7,2]  R1417     9.3543119728565216e-02
    z[3,7,2]  R1418     -8.2484386861324310e-02
    z[3,7,2]  R1419     4.8659324645996094e-02
    z[3,7,2]  R1420     3.2083711028099060e-01
    z[3,7,2]  R1421     9.2939190566539764e-02
    z[3,7,2]  R1422     -1.5390649437904358e-01
    z[3,7,2]  R1423     1.6410119831562042e-01
    z[3,7,2]  R1424     5.7167984545230865e-02
    z[3,7,2]  R1425     -3.9061662554740906e-01
    z[3,7,2]  R1426     5.6848201900720596e-02
    z[3,7,2]  R1427     -5.4133731871843338e-02
    z[3,7,2]  R1428     -2.2056396305561066e-01
    z[3,7,2]  R1429     1.7317201197147369e-01
    z[3,7,2]  R1430     5.1693990826606750e-02
    z[3,7,2]  R1431     4.4829097390174866e-01
    z[3,7,2]  R1432     -3.3350110054016113e-01
    z[3,7,2]  R1433     -3.5054117441177368e-02
    z[3,7,2]  R1434     -4.1754251718521118e-01
    z[3,7,2]  R1435     -3.0168288946151733e-01
    z[3,7,2]  R1436     2.8850439190864563e-01
    z[3,7,2]  R1437     1.4658813178539276e-01
    z[3,7,2]  R1438     0.429653137922287
    z[3,7,2]  R1439     -1.5571160614490509e-01
    z[3,7,2]  R1440     -3.1941803172230721e-03
    z[3,7,2]  R1441     5.2502267062664032e-02
    z[3,7,2]  R1442     3.3713912963867188e-01
    z[3,7,2]  R1443     -1.2892647087574005e-01
    z[3,7,2]  R1444     2.1969152987003326e-01
    z[3,7,2]  R1445     1.4927808940410614e-01
    z[3,7,2]  R1446     3.3755195140838623e-01
    z[3,7,2]  R1447     1.3285375200212002e-02
    z[3,7,2]  R1448     8.9557290077209473e-02
    z[3,7,2]  R1449     1.7660225927829742e-01
    z[3,7,2]  R1450     -3.9753105491399765e-02
    z[3,7,2]  R1451     3.1530502438545227e-01
    z[3,7,2]  R1452     2.7472989633679390e-02
    z[3,7,2]  R1453     -1.7919382452964783e-01
    z[3,7,2]  R1454     1.3483686745166779e-01
    z[3,7,2]  R1455     3.9303582161664963e-02
    z[3,7,2]  R1456     1.8700802326202393e-01
    z[3,7,2]  R1457     4.3138301372528076e-01
    z[3,7,2]  R1458     -1.2253466248512268e-01
    z[3,7,2]  R1459     4.8997050523757935e-01
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1322     -1
    z[3,7,3]  R1323     1
    z[3,7,3]  R1330     -2.3181436955928802e-01
    z[3,7,3]  R1331     -4.4772112369537354e-01
    z[3,7,3]  R1332     -4.0277552604675293e-01
    z[3,7,3]  R1333     3.4380894899368286e-01
    z[3,7,3]  R1334     -0.393984854221344
    z[3,7,3]  R1335     -4.3403938412666321e-01
    z[3,7,3]  R1336     -3.7225216627120972e-01
    z[3,7,3]  R1337     -0.436993807554245
    z[3,7,3]  R1338     -3.0460822582244873e-01
    z[3,7,3]  R1339     -0.345674991607666
    z[3,7,3]  R1340     7.9763191938400269e-01
    z[3,7,3]  R1341     6.6494739055633545e-01
    z[3,7,3]  R1342     6.6684925556182861e-01
    z[3,7,3]  R1343     3.7392199039459229e-01
    z[3,7,3]  R1344     7.5536668300628662e-01
    z[3,7,3]  R1345     3.7185427546501160e-01
    z[3,7,3]  R1346     5.7558345794677734e-01
    z[3,7,3]  R1347     5.6364989280700684e-01
    z[3,7,3]  R1348     3.1432849168777466e-01
    z[3,7,3]  R1349     0.601999044418335
    z[3,7,3]  R1350     -4.2582151293754578e-01
    z[3,7,3]  R1351     -1.5460880100727081e-01
    z[3,7,3]  R1352     -1.9523912668228149e-01
    z[3,7,3]  R1353     9.0477697551250458e-02
    z[3,7,3]  R1354     -5.2065807580947876e-01
    z[3,7,3]  R1355     -1.8150655925273895e-01
    z[3,7,3]  R1356     -2.5736436247825623e-01
    z[3,7,3]  R1357     -6.2611490488052368e-02
    z[3,7,3]  R1358     -6.5198026597499847e-02
    z[3,7,3]  R1359     -1.1997640132904053e-01
    z[3,7,3]  R1360     2.7967724204063416e-01
    z[3,7,3]  R1361     5.3419440984725952e-01
    z[3,7,3]  R1362     8.6413323879241943e-02
    z[3,7,3]  R1363     2.2495500743389130e-01
    z[3,7,3]  R1364     -6.5599568188190460e-02
    z[3,7,3]  R1365     -6.9331027567386627e-02
    z[3,7,3]  R1366     7.2255417704582214e-02
    z[3,7,3]  R1367     3.0335399508476257e-01
    z[3,7,3]  R1368     4.1781830787658691e-01
    z[3,7,3]  R1369     -5.6925421953201294e-01
    z[3,7,3]  R1370     -1.6221408545970917e-01
    z[3,7,3]  R1371     2.3226570338010788e-02
    z[3,7,3]  R1372     -2.8599998354911804e-01
    z[3,7,3]  R1373     -2.3139625787734985e-02
    z[3,7,3]  R1374     2.3291775584220886e-01
    z[3,7,3]  R1375     2.2588601708412170e-01
    z[3,7,3]  R1376     5.4531472921371460e-01
    z[3,7,3]  R1377     1.6942591965198517e-01
    z[3,7,3]  R1378     5.3970688581466675e-01
    z[3,7,3]  R1379     1.5945779159665108e-03
    z[3,7,3]  R1380     7.2592481970787048e-02
    z[3,7,3]  R1381     -3.9525586366653442e-01
    z[3,7,3]  R1382     -4.1620454192161560e-01
    z[3,7,3]  R1383     1.8690448999404907e-01
    z[3,7,3]  R1384     6.6859899088740349e-03
    z[3,7,3]  R1385     -6.8584673106670380e-02
    z[3,7,3]  R1386     3.2622119784355164e-01
    z[3,7,3]  R1387     2.0877651870250702e-01
    z[3,7,3]  R1388     2.0125991106033325e-01
    z[3,7,3]  R1389     -6.1015486717224121e-01
    z[3,7,3]  R1390     1.4422349631786346e-01
    z[3,7,3]  R1391     1.1832524836063385e-01
    z[3,7,3]  R1392     -6.7909307777881622e-02
    z[3,7,3]  R1393     8.2499362528324127e-02
    z[3,7,3]  R1394     3.1887543201446533e-01
    z[3,7,3]  R1395     3.2872881740331650e-02
    z[3,7,3]  R1396     2.8650152683258057e-01
    z[3,7,3]  R1397     2.9154961928725243e-02
    z[3,7,3]  R1398     3.1599089503288269e-01
    z[3,7,3]  R1399     3.0711406469345093e-01
    z[3,7,3]  R1400     4.6277437359094620e-02
    z[3,7,3]  R1401     -3.1967076659202576e-01
    z[3,7,3]  R1402     3.6842370033264160e-01
    z[3,7,3]  R1403     4.1894102096557617e-01
    z[3,7,3]  R1404     6.6029459238052368e-01
    z[3,7,3]  R1405     -5.6565958261489868e-01
    z[3,7,3]  R1406     -6.3447332382202148e-01
    z[3,7,3]  R1407     -4.1860821843147278e-01
    z[3,7,3]  R1408     6.9805681705474854e-01
    z[3,7,3]  R1409     -4.4370630383491516e-01
    z[3,7,3]  R1410     3.6959937214851379e-01
    z[3,7,3]  R1411     5.9318460524082184e-02
    z[3,7,3]  R1412     0.158525750041008
    z[3,7,3]  R1413     -2.3253539577126503e-02
    z[3,7,3]  R1414     2.3231007158756256e-01
    z[3,7,3]  R1415     -2.7718707919120789e-01
    z[3,7,3]  R1416     3.6711797118186951e-01
    z[3,7,3]  R1417     -0.226178377866745
    z[3,7,3]  R1418     -2.4011158943176270e-01
    z[3,7,3]  R1419     -2.7301368117332458e-01
    z[3,7,3]  R1420     -1.0322096198797226e-01
    z[3,7,3]  R1421     7.7387273311614990e-01
    z[3,7,3]  R1422     4.7139909863471985e-01
    z[3,7,3]  R1423     6.5096491575241089e-01
    z[3,7,3]  R1424     3.3719608187675476e-01
    z[3,7,3]  R1425     1.1057198047637939e-01
    z[3,7,3]  R1426     3.6398065090179443e-01
    z[3,7,3]  R1427     3.2900294661521912e-01
    z[3,7,3]  R1428     2.7178165316581726e-01
    z[3,7,3]  R1429     1.6171573102474213e-01
    z[3,7,3]  R1430     2.5542613863945007e-01
    z[3,7,3]  R1431     6.7297476530075073e-01
    z[3,7,3]  R1432     -3.4470504522323608e-01
    z[3,7,3]  R1433     0.0698728859424591
    z[3,7,3]  R1434     -0.00604488980025053
    z[3,7,3]  R1435     1.5375986695289612e-01
    z[3,7,3]  R1436     -1.3334222137928009e-01
    z[3,7,3]  R1437     4.6870082616806030e-01
    z[3,7,3]  R1438     5.1685118675231934e-01
    z[3,7,3]  R1439     -6.7933744192123413e-01
    z[3,7,3]  R1440     2.7467393875122070e-01
    z[3,7,3]  R1441     9.6514336764812469e-03
    z[3,7,3]  R1442     -1.6247574985027313e-01
    z[3,7,3]  R1443     -3.9134703576564789e-02
    z[3,7,3]  R1444     2.7464474551379681e-03
    z[3,7,3]  R1445     2.9281333088874817e-01
    z[3,7,3]  R1446     1.1872097849845886e-02
    z[3,7,3]  R1447     -1.6546325758099556e-02
    z[3,7,3]  R1448     -4.2227837443351746e-01
    z[3,7,3]  R1449     -2.3480325937271118e-01
    z[3,7,3]  R1450     6.3135528564453125e-01
    z[3,7,3]  R1451     3.2478424906730652e-01
    z[3,7,3]  R1452     1.4172525145113468e-02
    z[3,7,3]  R1453     -3.9085391163825989e-01
    z[3,7,3]  R1454     -1.7862078547477722e-01
    z[3,7,3]  R1455     -2.5062507390975952e-01
    z[3,7,3]  R1456     -3.4189638495445251e-01
    z[3,7,3]  R1457     1.4157831668853760e-01
    z[3,7,3]  R1458     -0.558853030204773
    z[3,7,3]  R1459     -2.4432018399238586e-01
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1324     -1
    z[3,7,4]  R1325     1
    z[3,7,4]  R1330     -4.8964913934469223e-02
    z[3,7,4]  R1331     5.5193908512592316e-02
    z[3,7,4]  R1332     -4.3499651551246643e-01
    z[3,7,4]  R1333     5.3880762308835983e-02
    z[3,7,4]  R1334     -6.8078011274337769e-02
    z[3,7,4]  R1335     -1.6763618588447571e-01
    z[3,7,4]  R1336     -1.6528154909610748e-01
    z[3,7,4]  R1337     -4.5524783432483673e-02
    z[3,7,4]  R1338     0.0381888784468174
    z[3,7,4]  R1339     -4.9342054128646851e-01
    z[3,7,4]  R1340     1.1767548322677612e-01
    z[3,7,4]  R1341     1.7249056696891785e-01
    z[3,7,4]  R1342     -2.6817208528518677e-01
    z[3,7,4]  R1343     -3.3016937971115112e-01
    z[3,7,4]  R1344     -5.6820875033736229e-03
    z[3,7,4]  R1345     -1.5482572838664055e-02
    z[3,7,4]  R1346     -1.2258156388998032e-01
    z[3,7,4]  R1347     2.3047678172588348e-01
    z[3,7,4]  R1348     2.7015358209609985e-01
    z[3,7,4]  R1349     -3.2794106006622314e-01
    z[3,7,4]  R1350     -1.9003254175186157e-01
    z[3,7,4]  R1351     1.6714981198310852e-01
    z[3,7,4]  R1352     -3.6104834079742432e-01
    z[3,7,4]  R1353     3.3447524905204773e-01
    z[3,7,4]  R1354     1.3892273604869843e-01
    z[3,7,4]  R1355     -1.2286851555109024e-01
    z[3,7,4]  R1356     -0.516867995262146
    z[3,7,4]  R1357     -3.9206707477569580e-01
    z[3,7,4]  R1358     3.8908639550209045e-01
    z[3,7,4]  R1359     -6.9490373134613037e-02
    z[3,7,4]  R1360     -1.2628835439682007e-01
    z[3,7,4]  R1361     -1.5086817741394043e-01
    z[3,7,4]  R1362     5.0990754365921021e-01
    z[3,7,4]  R1363     0.221954807639122
    z[3,7,4]  R1364     3.9529573917388916e-01
    z[3,7,4]  R1365     -2.4070492386817932e-01
    z[3,7,4]  R1366     1.9609211385250092e-01
    z[3,7,4]  R1367     3.3434832096099854e-01
    z[3,7,4]  R1368     2.4741759896278381e-01
    z[3,7,4]  R1369     3.8723891973495483e-01
    z[3,7,4]  R1370     -7.8918620944023132e-02
    z[3,7,4]  R1371     -2.8224804997444153e-01
    z[3,7,4]  R1372     3.5960423946380615e-01
    z[3,7,4]  R1373     1.7976656556129456e-01
    z[3,7,4]  R1374     -0.0944976955652237
    z[3,7,4]  R1375     4.1586112976074219e-01
    z[3,7,4]  R1376     0.0369749441742897
    z[3,7,4]  R1377     -8.0548338592052460e-02
    z[3,7,4]  R1378     -3.3165144920349121e-01
    z[3,7,4]  R1379     3.9381337165832520e-01
    z[3,7,4]  R1380     -1.0884880274534225e-01
    z[3,7,4]  R1381     -5.6445185095071793e-02
    z[3,7,4]  R1382     1.8267078697681427e-01
    z[3,7,4]  R1383     -1.2607282400131226e-01
    z[3,7,4]  R1384     -7.9346001148223877e-01
    z[3,7,4]  R1385     -3.8210639357566833e-01
    z[3,7,4]  R1386     -3.9536821842193604e-01
    z[3,7,4]  R1387     -2.9035148024559021e-01
    z[3,7,4]  R1388     -4.5989876985549927e-01
    z[3,7,4]  R1389     -0.0334247350692749
    z[3,7,4]  R1390     2.0210993289947510e-01
    z[3,7,4]  R1391     -1.2239823117852211e-02
    z[3,7,4]  R1392     -1.5212576091289520e-01
    z[3,7,4]  R1393     -6.2422102689743042e-01
    z[3,7,4]  R1394     -3.2902446389198303e-01
    z[3,7,4]  R1395     -3.5859817266464233e-01
    z[3,7,4]  R1396     3.8695797324180603e-01
    z[3,7,4]  R1397     -4.1047602891921997e-01
    z[3,7,4]  R1398     2.9874143004417419e-01
    z[3,7,4]  R1399     -0.427390456199646
    z[3,7,4]  R1400     5.3448425605893135e-03
    z[3,7,4]  R1401     7.1973830461502075e-02
    z[3,7,4]  R1402     -4.8017600178718567e-01
    z[3,7,4]  R1403     -1.9535413384437561e-01
    z[3,7,4]  R1404     -1.4793622493743896e-01
    z[3,7,4]  R1405     -2.0826685428619385e-01
    z[3,7,4]  R1406     -1.2676788866519928e-01
    z[3,7,4]  R1407     0.075748011469841
    z[3,7,4]  R1408     -3.0495241284370422e-01
    z[3,7,4]  R1409     -3.5932940244674683e-01
    z[3,7,4]  R1410     -3.7670621275901794e-01
    z[3,7,4]  R1411     8.1031396985054016e-02
    z[3,7,4]  R1412     -1.0515597462654114e-01
    z[3,7,4]  R1413     -3.5539028048515320e-01
    z[3,7,4]  R1414     1.5031726658344269e-01
    z[3,7,4]  R1415     -4.6373081207275391e-01
    z[3,7,4]  R1416     -7.2809509932994843e-02
    z[3,7,4]  R1417     1.7562508583068848e-02
    z[3,7,4]  R1418     2.8269737958908081e-02
    z[3,7,4]  R1419     -3.1315669417381287e-01
    z[3,7,4]  R1420     -3.0388814210891724e-01
    z[3,7,4]  R1421     2.6128491386771202e-02
    z[3,7,4]  R1422     -4.3060481548309326e-01
    z[3,7,4]  R1423     -3.5561460256576538e-01
    z[3,7,4]  R1424     3.0817720293998718e-01
    z[3,7,4]  R1425     -2.5788927078247070e-01
    z[3,7,4]  R1426     -0.136447012424469
    z[3,7,4]  R1427     -0.397080659866333
    z[3,7,4]  R1428     2.9640036821365356e-01
    z[3,7,4]  R1429     4.8846226930618286e-01
    z[3,7,4]  R1430     -1.9163309037685394e-01
    z[3,7,4]  R1431     -1.0979609936475754e-01
    z[3,7,4]  R1432     4.2299106717109680e-02
    z[3,7,4]  R1433     3.5171234607696533e-01
    z[3,7,4]  R1434     -4.8808288574218750e-01
    z[3,7,4]  R1435     1.0107087343931198e-01
    z[3,7,4]  R1436     -2.2987291216850281e-01
    z[3,7,4]  R1437     1.7197330296039581e-01
    z[3,7,4]  R1438     -1.2985230982303619e-01
    z[3,7,4]  R1439     -1.8230605125427246e-01
    z[3,7,4]  R1440     1.2664791941642761e-01
    z[3,7,4]  R1441     -1.9079525768756866e-01
    z[3,7,4]  R1442     0.421440452337265
    z[3,7,4]  R1443     6.2770366668701172e-01
    z[3,7,4]  R1444     5.0600588321685791e-01
    z[3,7,4]  R1445     -8.1653788685798645e-02
    z[3,7,4]  R1446     -5.7408052682876587e-01
    z[3,7,4]  R1447     4.3769359588623047e-01
    z[3,7,4]  R1448     -4.2954739183187485e-02
    z[3,7,4]  R1449     -4.6383373439311981e-02
    z[3,7,4]  R1450     -4.4163081794977188e-02
    z[3,7,4]  R1451     4.4525933265686035e-01
    z[3,7,4]  R1452     3.0113452672958374e-01
    z[3,7,4]  R1453     -1.1861461400985718e-01
    z[3,7,4]  R1454     -4.3670544028282166e-01
    z[3,7,4]  R1455     1.7355741560459137e-01
    z[3,7,4]  R1456     -2.5035262107849121e-02
    z[3,7,4]  R1457     -1.7194424569606781e-01
    z[3,7,4]  R1458     -2.7346280217170715e-01
    z[3,7,4]  R1459     8.6590789258480072e-02
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1326     -1
    z[3,7,5]  R1327     1
    z[3,7,5]  R1330     1.7014965415000916e-01
    z[3,7,5]  R1331     -4.2478391528129578e-01
    z[3,7,5]  R1332     2.3235505819320679e-01
    z[3,7,5]  R1333     1.9555102288722992e-01
    z[3,7,5]  R1334     2.1225447952747345e-01
    z[3,7,5]  R1335     1.0172709822654724e-01
    z[3,7,5]  R1336     -1.7702551186084747e-01
    z[3,7,5]  R1337     1.4993183314800262e-01
    z[3,7,5]  R1338     2.3352034389972687e-02
    z[3,7,5]  R1339     7.1231603622436523e-02
    z[3,7,5]  R1340     -1.7235511541366577e-01
    z[3,7,5]  R1341     9.0874463319778442e-02
    z[3,7,5]  R1342     -4.3601825833320618e-01
    z[3,7,5]  R1343     1.3626746833324432e-01
    z[3,7,5]  R1344     -1.3970367610454559e-01
    z[3,7,5]  R1345     -1.0332430899143219e-01
    z[3,7,5]  R1346     -0.326092928647995
    z[3,7,5]  R1347     -2.9079735279083252e-01
    z[3,7,5]  R1348     -4.3435847759246826e-01
    z[3,7,5]  R1349     -1.2726742029190063e-01
    z[3,7,5]  R1350     -2.8780168294906616e-01
    z[3,7,5]  R1351     3.0216421931982040e-02
    z[3,7,5]  R1352     2.1535606682300568e-01
    z[3,7,5]  R1353     -1.5049597620964050e-01
    z[3,7,5]  R1354     2.0277952717151493e-04
    z[3,7,5]  R1355     -5.5093520879745483e-01
    z[3,7,5]  R1356     3.4875091910362244e-01
    z[3,7,5]  R1357     3.7186926603317261e-01
    z[3,7,5]  R1358     1.2121313810348511e-01
    z[3,7,5]  R1359     -1.8821124732494354e-01
    z[3,7,5]  R1360     3.1642279028892517e-01
    z[3,7,5]  R1361     -0.0658579170703888
    z[3,7,5]  R1362     3.0122599005699158e-01
    z[3,7,5]  R1363     2.2972339764237404e-02
    z[3,7,5]  R1364     -1.2041824311017990e-01
    z[3,7,5]  R1365     3.9197036623954773e-01
    z[3,7,5]  R1366     -1.9379844889044762e-02
    z[3,7,5]  R1367     -6.1678741127252579e-02
    z[3,7,5]  R1368     -6.3429638743400574e-02
    z[3,7,5]  R1369     2.6149657368659973e-01
    z[3,7,5]  R1370     1.3480226695537567e-01
    z[3,7,5]  R1371     9.2387810349464417e-02
    z[3,7,5]  R1372     -2.0555862784385681e-01
    z[3,7,5]  R1373     -1.2378104031085968e-01
    z[3,7,5]  R1374     -3.0704462528228760e-01
    z[3,7,5]  R1375     -1.5496802330017090e-01
    z[3,7,5]  R1376     1.0670841485261917e-01
    z[3,7,5]  R1377     -1.9605213403701782e-01
    z[3,7,5]  R1378     4.4633254408836365e-01
    z[3,7,5]  R1379     3.0406826734542847e-01
    z[3,7,5]  R1380     -7.4417233467102051e-02
    z[3,7,5]  R1381     8.5203811526298523e-02
    z[3,7,5]  R1382     2.7012443542480469e-01
    z[3,7,5]  R1383     9.4676263630390167e-02
    z[3,7,5]  R1384     1.8872748315334320e-01
    z[3,7,5]  R1385     5.4099857807159424e-01
    z[3,7,5]  R1386     -5.4565286636352539e-01
    z[3,7,5]  R1387     -1.6689732670783997e-01
    z[3,7,5]  R1388     6.1263066530227661e-01
    z[3,7,5]  R1389     1.7487421631813049e-01
    z[3,7,5]  R1390     -2.8541627526283264e-01
    z[3,7,5]  R1391     -1.9115678966045380e-01
    z[3,7,5]  R1392     5.5060341954231262e-02
    z[3,7,5]  R1393     -5.4392233490943909e-02
    z[3,7,5]  R1394     -4.0359079837799072e-01
    z[3,7,5]  R1395     -1.8619143962860107e-01
    z[3,7,5]  R1396     -1.2645585834980011e-01
    z[3,7,5]  R1397     -1.0071890056133270e-01
    z[3,7,5]  R1398     -5.6475242599844933e-03
    z[3,7,5]  R1399     -0.109067901968956
    z[3,7,5]  R1400     -0.31219482421875
    z[3,7,5]  R1401     -2.3086293041706085e-01
    z[3,7,5]  R1402     1.7589475214481354e-01
    z[3,7,5]  R1403     -4.6738073229789734e-01
    z[3,7,5]  R1404     -5.8575284481048584e-01
    z[3,7,5]  R1405     1.2727017700672150e-01
    z[3,7,5]  R1406     4.8118501901626587e-02
    z[3,7,5]  R1407     0.347350537776947
    z[3,7,5]  R1408     -1.6113558411598206e-01
    z[3,7,5]  R1409     -1.2302889674901962e-01
    z[3,7,5]  R1410     1.3189418613910675e-01
    z[3,7,5]  R1411     6.9038402289152145e-03
    z[3,7,5]  R1412     3.8950878381729126e-01
    z[3,7,5]  R1413     2.5515630841255188e-01
    z[3,7,5]  R1414     4.1244697570800781e-01
    z[3,7,5]  R1415     -1.0995906591415405e-01
    z[3,7,5]  R1416     4.1062346100807190e-01
    z[3,7,5]  R1417     -3.6728653311729431e-01
    z[3,7,5]  R1418     2.1188862621784210e-01
    z[3,7,5]  R1419     3.0348362401127815e-02
    z[3,7,5]  R1420     2.4304036796092987e-01
    z[3,7,5]  R1421     -0.323932021856308
    z[3,7,5]  R1422     5.7969961315393448e-02
    z[3,7,5]  R1423     -1.9923089444637299e-01
    z[3,7,5]  R1424     -5.8258390426635742e-01
    z[3,7,5]  R1425     2.3948390036821365e-02
    z[3,7,5]  R1426     -5.2788370847702026e-01
    z[3,7,5]  R1427     -5.4126250743865967e-01
    z[3,7,5]  R1428     -2.6952026411890984e-02
    z[3,7,5]  R1429     4.5434519648551941e-01
    z[3,7,5]  R1430     -2.9925969243049622e-01
    z[3,7,5]  R1431     -9.9724262952804565e-02
    z[3,7,5]  R1432     3.2728222012519836e-01
    z[3,7,5]  R1433     -2.2290121018886566e-01
    z[3,7,5]  R1434     0.0622372180223465
    z[3,7,5]  R1435     -4.6589246392250061e-01
    z[3,7,5]  R1436     -2.9143321514129639e-01
    z[3,7,5]  R1437     -2.3345613479614258e-01
    z[3,7,5]  R1438     -2.1432501077651978e-01
    z[3,7,5]  R1439     -1.2208786606788635e-01
    z[3,7,5]  R1440     1.1788544803857803e-01
    z[3,7,5]  R1441     -4.1838833689689636e-01
    z[3,7,5]  R1442     2.2229743003845215e-01
    z[3,7,5]  R1443     -1.6100279986858368e-01
    z[3,7,5]  R1444     -0.317974716424942
    z[3,7,5]  R1445     1.4082056283950806e-01
    z[3,7,5]  R1446     -0.0612872950732708
    z[3,7,5]  R1447     2.7239572955295444e-04
    z[3,7,5]  R1448     2.6067218184471130e-01
    z[3,7,5]  R1449     3.6580806970596313e-01
    z[3,7,5]  R1450     9.9663458764553070e-02
    z[3,7,5]  R1451     6.3331179320812225e-02
    z[3,7,5]  R1452     -1.1396781355142593e-01
    z[3,7,5]  R1453     3.1341653317213058e-02
    z[3,7,5]  R1454     3.1393431127071381e-02
    z[3,7,5]  R1455     -6.8679951131343842e-02
    z[3,7,5]  R1456     5.4897193331271410e-04
    z[3,7,5]  R1457     3.0671315267682076e-02
    z[3,7,5]  R1458     -2.3857496678829193e-02
    z[3,7,5]  R1459     -0.260144978761673
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1328     -1
    z[3,7,6]  R1329     1
    z[3,7,6]  R1330     -8.7334677577018738e-02
    z[3,7,6]  R1331     -6.0142739675939083e-03
    z[3,7,6]  R1332     -2.1511197090148926e-02
    z[3,7,6]  R1333     -1.4263409376144409e-01
    z[3,7,6]  R1334     -4.6441400051116943e-01
    z[3,7,6]  R1335     -5.9535163640975952e-01
    z[3,7,6]  R1336     -4.9260437488555908e-01
    z[3,7,6]  R1337     -5.4002481698989868e-01
    z[3,7,6]  R1338     -2.4094898998737335e-01
    z[3,7,6]  R1339     -4.2733040452003479e-01
    z[3,7,6]  R1340     1.5698526799678802e-01
    z[3,7,6]  R1341     -1.5782795846462250e-01
    z[3,7,6]  R1342     -7.6108537614345551e-02
    z[3,7,6]  R1343     1.4965327084064484e-01
    z[3,7,6]  R1344     -9.0734608471393585e-02
    z[3,7,6]  R1345     -3.2037842273712158e-01
    z[3,7,6]  R1346     4.4052439928054810e-01
    z[3,7,6]  R1347     2.0833517611026764e-01
    z[3,7,6]  R1348     -3.4928861260414124e-01
    z[3,7,6]  R1349     2.9489165544509888e-01
    z[3,7,6]  R1350     6.1515177367255092e-04
    z[3,7,6]  R1351     4.6298485994338989e-01
    z[3,7,6]  R1352     -2.2220499813556671e-01
    z[3,7,6]  R1353     4.0010184049606323e-01
    z[3,7,6]  R1354     3.2092493772506714e-01
    z[3,7,6]  R1355     -8.5266232490539551e-02
    z[3,7,6]  R1356     -1.0100036161020398e-04
    z[3,7,6]  R1357     2.5116398930549622e-01
    z[3,7,6]  R1358     -8.1232629716396332e-02
    z[3,7,6]  R1359     1.4770555496215820e-01
    z[3,7,6]  R1360     1.1533907800912857e-01
    z[3,7,6]  R1361     1.5381710231304169e-01
    z[3,7,6]  R1362     8.8793292641639709e-02
    z[3,7,6]  R1363     -2.6950512081384659e-02
    z[3,7,6]  R1364     4.3488475680351257e-01
    z[3,7,6]  R1365     2.4490984156727791e-02
    z[3,7,6]  R1366     -6.1473004519939423e-02
    z[3,7,6]  R1367     -1.6112464666366577e-01
    z[3,7,6]  R1368     4.9912306666374207e-01
    z[3,7,6]  R1369     5.3253639489412308e-02
    z[3,7,6]  R1370     2.6396813988685608e-01
    z[3,7,6]  R1371     -8.4703646600246429e-02
    z[3,7,6]  R1372     -1.8765434622764587e-01
    z[3,7,6]  R1373     -2.0507527887821198e-01
    z[3,7,6]  R1374     3.4222784638404846e-01
    z[3,7,6]  R1375     -1.0279571637511253e-02
    z[3,7,6]  R1376     -2.3415200412273407e-01
    z[3,7,6]  R1377     0.39665687084198
    z[3,7,6]  R1378     -1.1886099725961685e-01
    z[3,7,6]  R1379     -1.3070569932460785e-01
    z[3,7,6]  R1380     3.5307818651199341e-01
    z[3,7,6]  R1381     -4.9115438014268875e-02
    z[3,7,6]  R1382     -2.7694234251976013e-01
    z[3,7,6]  R1383     1.7937886714935303e-01
    z[3,7,6]  R1384     -7.9604998230934143e-02
    z[3,7,6]  R1385     -1.4860881865024567e-01
    z[3,7,6]  R1386     1.1060429364442825e-01
    z[3,7,6]  R1387     -4.7008684277534485e-01
    z[3,7,6]  R1388     1.5651646256446838e-01
    z[3,7,6]  R1389     -1.4176055788993835e-01
    z[3,7,6]  R1390     2.8541889786720276e-01
    z[3,7,6]  R1391     2.6265071704983711e-02
    z[3,7,6]  R1392     -5.2953604608774185e-02
    z[3,7,6]  R1393     2.1357278525829315e-01
    z[3,7,6]  R1394     8.4018506109714508e-02
    z[3,7,6]  R1395     -1.7056916654109955e-01
    z[3,7,6]  R1396     -2.9217815026640892e-02
    z[3,7,6]  R1397     -2.2908061742782593e-01
    z[3,7,6]  R1398     4.5333832502365112e-01
    z[3,7,6]  R1399     -4.8690277338027954e-01
    z[3,7,6]  R1400     -0.109520822763443
    z[3,7,6]  R1401     -1.4239962399005890e-01
    z[3,7,6]  R1402     -5.9989333152770996e-02
    z[3,7,6]  R1403     2.1068461239337921e-01
    z[3,7,6]  R1404     -2.2491894662380219e-01
    z[3,7,6]  R1405     -7.6896086335182190e-02
    z[3,7,6]  R1406     1.3612794876098633e-01
    z[3,7,6]  R1407     2.0970821380615234e-01
    z[3,7,6]  R1408     4.3940261006355286e-01
    z[3,7,6]  R1409     -0.487010657787323
    z[3,7,6]  R1410     -9.0700075030326843e-02
    z[3,7,6]  R1411     -1.3375128805637360e-01
    z[3,7,6]  R1412     -2.1589969098567963e-01
    z[3,7,6]  R1413     -2.1428486704826355e-01
    z[3,7,6]  R1414     -2.3845452815294266e-03
    z[3,7,6]  R1415     -9.6321694552898407e-02
    z[3,7,6]  R1416     -7.8668676316738129e-02
    z[3,7,6]  R1417     -2.5815647840499878e-01
    z[3,7,6]  R1418     -1.4488619565963745e-01
    z[3,7,6]  R1419     8.9614205062389374e-02
    z[3,7,6]  R1420     -1.3530252873897552e-01
    z[3,7,6]  R1421     1.5942711383104324e-02
    z[3,7,6]  R1422     2.8550121188163757e-01
    z[3,7,6]  R1423     1.5308916568756104e-01
    z[3,7,6]  R1424     -0.0966232642531395
    z[3,7,6]  R1425     2.8245496749877930e-01
    z[3,7,6]  R1426     1.2730962038040161e-01
    z[3,7,6]  R1427     -2.7441918849945068e-01
    z[3,7,6]  R1428     2.9530939459800720e-01
    z[3,7,6]  R1429     8.2507394254207611e-02
    z[3,7,6]  R1430     0.0876837819814682
    z[3,7,6]  R1431     -3.1188886612653732e-02
    z[3,7,6]  R1432     2.0890679955482483e-01
    z[3,7,6]  R1433     -5.3696759045124054e-02
    z[3,7,6]  R1434     1.8775881826877594e-01
    z[3,7,6]  R1435     -9.2540644109249115e-02
    z[3,7,6]  R1436     -4.1524580121040344e-01
    z[3,7,6]  R1437     2.2078908979892731e-01
    z[3,7,6]  R1438     -2.6936089992523193e-01
    z[3,7,6]  R1439     -2.4935486912727356e-01
    z[3,7,6]  R1440     4.1789177805185318e-02
    z[3,7,6]  R1441     -2.1374231204390526e-02
    z[3,7,6]  R1442     -1.1075932532548904e-01
    z[3,7,6]  R1443     -6.0759719461202621e-02
    z[3,7,6]  R1444     -2.0654113590717316e-01
    z[3,7,6]  R1445     -5.0848603248596191e-01
    z[3,7,6]  R1446     -3.7379625439643860e-01
    z[3,7,6]  R1447     3.6895927786827087e-01
    z[3,7,6]  R1448     -1.7761395871639252e-01
    z[3,7,6]  R1449     3.8708765059709549e-02
    z[3,7,6]  R1450     0.268314003944397
    z[3,7,6]  R1451     -1.5159203112125397e-01
    z[3,7,6]  R1452     3.1062346696853638e-01
    z[3,7,6]  R1453     -1.5792258083820343e-01
    z[3,7,6]  R1454     1.0321221500635147e-01
    z[3,7,6]  R1455     -1.3810354471206665e-01
    z[3,7,6]  R1456     3.0551424622535706e-01
    z[3,7,6]  R1457     -9.2492602765560150e-02
    z[3,7,6]  R1458     2.8589364886283875e-01
    z[3,7,6]  R1459     -1.7685487866401672e-01
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1460     -1
    z[7,3,0]  R1461     1
    z[7,3,0]  R1474     -4.0147697925567627e-01
    z[7,3,0]  R1475     -2.7795320749282837e-01
    z[7,3,0]  R1476     4.7752074897289276e-04
    z[7,3,0]  R1477     7.9634189605712891e-02
    z[7,3,0]  R1478     -1.6077496111392975e-01
    z[7,3,0]  R1479     -2.4796119332313538e-01
    z[7,3,0]  R1480     -2.7985778450965881e-01
    z[7,3,0]  R1481     -7.9454638063907623e-02
    z[7,3,0]  R1482     2.3005454242229462e-01
    z[7,3,0]  R1483     -2.9637056589126587e-01
    z[7,3,0]  R1484     -4.5852547883987427e-01
    z[7,3,0]  R1485     2.1899484097957611e-01
    z[7,3,0]  R1486     -2.5554949045181274e-01
    z[7,3,0]  R1487     -1.4372719824314117e-01
    z[7,3,0]  R1488     -0.145126074552536
    z[7,3,0]  R1489     -8.3650238811969757e-03
    z[7,3,0]  R1490     -1.2346358271315694e-03
    z[7,3,0]  R1491     9.3800291419029236e-02
    z[7,3,0]  R1492     -2.1994057297706604e-01
    z[7,3,0]  R1493     4.4037255644798279e-01
    z[7,3,0]  R1494     1.0263575240969658e-02
    z[7,3,0]  R1495     -1.1668379604816437e-01
    z[7,3,0]  R1496     1.0058578848838806e-01
    z[7,3,0]  R1497     2.2934967279434204e-01
    z[7,3,0]  R1498     4.3210152536630630e-02
    z[7,3,0]  R1499     7.5677320361137390e-02
    z[7,3,0]  R1500     4.0831130743026733e-01
    z[7,3,0]  R1501     -2.7307519316673279e-01
    z[7,3,0]  R1502     1.2010221928358078e-01
    z[7,3,0]  R1503     -1.7229756712913513e-01
    z[7,3,0]  R1504     3.0183336138725281e-01
    z[7,3,0]  R1505     1.2099771946668625e-01
    z[7,3,0]  R1506     -5.6635860353708267e-02
    z[7,3,0]  R1507     -1.4152922667562962e-02
    z[7,3,0]  R1508     -1.4258608222007751e-01
    z[7,3,0]  R1509     -2.2895622253417969e-01
    z[7,3,0]  R1510     -2.5274334475398064e-02
    z[7,3,0]  R1511     2.6467061042785645e-01
    z[7,3,0]  R1512     -2.0422524213790894e-01
    z[7,3,0]  R1513     -1.0240741074085236e-01
    z[7,3,0]  R1514     -2.5584363937377930e-01
    z[7,3,0]  R1515     2.0791180431842804e-01
    z[7,3,0]  R1516     1.1191520839929581e-02
    z[7,3,0]  R1517     -2.5737819075584412e-01
    z[7,3,0]  R1518     -5.8369133621454239e-02
    z[7,3,0]  R1519     -0.169291153550148
    z[7,3,0]  R1520     -8.6377680301666260e-02
    z[7,3,0]  R1521     4.8517894744873047e-01
    z[7,3,0]  R1522     8.3977186679840088e-01
    z[7,3,0]  R1523     8.7542843818664551e-01
    z[7,3,0]  R1524     1.7060812562704086e-02
    z[7,3,0]  R1525     -1.5379984676837921e-01
    z[7,3,0]  R1526     4.6583107113838196e-01
    z[7,3,0]  R1527     8.7543791532516479e-01
    z[7,3,0]  R1528     8.6454147100448608e-01
    z[7,3,0]  R1529     9.3073451519012451e-01
    z[7,3,0]  R1530     8.6799871921539307e-01
    z[7,3,0]  R1531     8.6702954769134521e-01
    z[7,3,0]  R1532     0.69090735912323
    z[7,3,0]  R1533     7.6937586069107056e-01
    z[7,3,0]  R1534     3.9363589882850647e-01
    z[7,3,0]  R1535     -7.7881030738353729e-02
    z[7,3,0]  R1536     1.2821778655052185e-01
    z[7,3,0]  R1537     3.5443133115768433e-01
    z[7,3,0]  R1538     -2.3074150085449219e-01
    z[7,3,0]  R1539     6.7675068974494934e-02
    z[7,3,0]  R1540     -2.4353887140750885e-01
    z[7,3,0]  R1541     -1.4388197660446167e-01
    z[7,3,0]  R1542     -5.3544437885284424e-01
    z[7,3,0]  R1543     1.2710736691951752e-01
    z[7,3,0]  R1544     -7.2518303990364075e-02
    z[7,3,0]  R1545     2.1276114881038666e-01
    z[7,3,0]  R1546     9.2758513987064362e-02
    z[7,3,0]  R1547     -1.2157166004180908e-01
    z[7,3,0]  R1548     1.4774616062641144e-01
    z[7,3,0]  R1549     -0.0848345085978508
    z[7,3,0]  R1550     2.5067931413650513e-01
    z[7,3,0]  R1551     4.2221829295158386e-01
    z[7,3,0]  R1552     -4.6629492193460464e-02
    z[7,3,0]  R1553     -1.1889804154634476e-01
    z[7,3,0]  R1554     2.8773501515388489e-01
    z[7,3,0]  R1555     -0.0851939395070076
    z[7,3,0]  R1556     -2.0846106112003326e-01
    z[7,3,0]  R1557     -1.5841172635555267e-01
    z[7,3,0]  R1558     7.9185582697391510e-02
    z[7,3,0]  R1559     2.4980646371841431e-01
    z[7,3,0]  R1560     1.7832493782043457e-01
    z[7,3,0]  R1561     1.1742538958787918e-01
    z[7,3,0]  R1562     -3.5878166556358337e-01
    z[7,3,0]  R1563     3.6712247133255005e-01
    z[7,3,0]  R1564     1.2598113715648651e-01
    z[7,3,0]  R1565     -2.2572505474090576e-01
    z[7,3,0]  R1566     -1.5283916890621185e-01
    z[7,3,0]  R1567     3.5271936655044556e-01
    z[7,3,0]  R1568     -1.6366019845008850e-01
    z[7,3,0]  R1569     -2.7820643782615662e-01
    z[7,3,0]  R1570     -0.468054860830307
    z[7,3,0]  R1571     -9.4501510262489319e-02
    z[7,3,0]  R1572     3.8991760462522507e-02
    z[7,3,0]  R1573     -2.3824974894523621e-01
    z[7,3,0]  R1574     -1.8255129456520081e-01
    z[7,3,0]  R1575     -0.285730242729187
    z[7,3,0]  R1576     4.2138494551181793e-02
    z[7,3,0]  R1577     -0.242917999625206
    z[7,3,0]  R1578     1.5073123574256897e-01
    z[7,3,0]  R1579     1.1461414396762848e-01
    z[7,3,0]  R1580     -1.9538788124918938e-02
    z[7,3,0]  R1581     -3.9183203130960464e-02
    z[7,3,0]  R1582     1.1523278802633286e-01
    z[7,3,0]  R1583     -1.1464959383010864e-01
    z[7,3,0]  R1584     -2.0538076758384705e-01
    z[7,3,0]  R1585     -2.9686164855957031e-01
    z[7,3,0]  R1586     -3.1057798862457275e-01
    z[7,3,0]  R1587     -5.8969402313232422e-01
    z[7,3,0]  R1588     3.8537446409463882e-02
    z[7,3,0]  R1589     -9.2446170747280121e-02
    z[7,3,0]  R1590     1.3703256845474243e-01
    z[7,3,0]  R1591     4.2776057124137878e-01
    z[7,3,0]  R1592     -1.9621905684471130e-01
    z[7,3,0]  R1593     -2.0587362349033356e-01
    z[7,3,0]  R1594     3.5219132900238037e-02
    z[7,3,0]  R1595     -6.8545721471309662e-02
    z[7,3,0]  R1596     -1.5081923454999924e-02
    z[7,3,0]  R1597     8.9163705706596375e-03
    z[7,3,0]  R1598     1.5945617854595184e-01
    z[7,3,0]  R1599     -8.2971222698688507e-02
    z[7,3,0]  R1600     3.8412243127822876e-01
    z[7,3,0]  R1601     4.4668781757354736e-01
    z[7,3,0]  R1602     2.2310416400432587e-01
    z[7,3,0]  R1603     0.0798686295747757
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1462     -1
    z[7,3,1]  R1463     1
    z[7,3,1]  R1474     -0.792862057685852
    z[7,3,1]  R1475     -8.1954658031463623e-01
    z[7,3,1]  R1476     -6.6718286275863647e-01
    z[7,3,1]  R1477     -6.7747443914413452e-01
    z[7,3,1]  R1478     2.8316763043403625e-01
    z[7,3,1]  R1479     -7.3923337459564209e-01
    z[7,3,1]  R1480     -6.8647295236587524e-01
    z[7,3,1]  R1481     -7.0364880561828613e-01
    z[7,3,1]  R1482     3.2303416728973389e-01
    z[7,3,1]  R1483     -5.6314653158187866e-01
    z[7,3,1]  R1484     6.8391436338424683e-01
    z[7,3,1]  R1485     8.6980056762695312e-01
    z[7,3,1]  R1486     7.7416473627090454e-01
    z[7,3,1]  R1487     8.3667856454849243e-01
    z[7,3,1]  R1488     8.3614146709442139e-01
    z[7,3,1]  R1489     8.0098909139633179e-01
    z[7,3,1]  R1490     6.5583300590515137e-01
    z[7,3,1]  R1491     8.5407376289367676e-01
    z[7,3,1]  R1492     9.0580403804779053e-01
    z[7,3,1]  R1493     7.8876417875289917e-01
    z[7,3,1]  R1494     -0.846510648727417
    z[7,3,1]  R1495     0.522493302822113
    z[7,3,1]  R1496     6.8824869394302368e-01
    z[7,3,1]  R1497     0.554186999797821
    z[7,3,1]  R1498     6.6140025854110718e-01
    z[7,3,1]  R1499     8.2619863748550415e-01
    z[7,3,1]  R1500     6.1974310874938965e-01
    z[7,3,1]  R1501     5.3694736957550049e-01
    z[7,3,1]  R1502     8.2902026176452637e-01
    z[7,3,1]  R1503     -6.7995643615722656e-01
    z[7,3,1]  R1504     8.4084117412567139e-01
    z[7,3,1]  R1505     5.5545192956924438e-01
    z[7,3,1]  R1506     -7.8371101617813110e-01
    z[7,3,1]  R1507     9.0411221981048584e-01
    z[7,3,1]  R1508     -7.2659420967102051e-01
    z[7,3,1]  R1509     7.7271562814712524e-01
    z[7,3,1]  R1510     0.766904354095459
    z[7,3,1]  R1511     -7.4562501907348633e-01
    z[7,3,1]  R1512     -6.0926431417465210e-01
    z[7,3,1]  R1513     -6.2725478410720825e-01
    z[7,3,1]  R1514     -9.0961802005767822e-01
    z[7,3,1]  R1515     -8.6140263080596924e-01
    z[7,3,1]  R1516     -7.8772956132888794e-01
    z[7,3,1]  R1517     -7.0141094923019409e-01
    z[7,3,1]  R1518     -0.740615963935852
    z[7,3,1]  R1519     7.6043474674224854e-01
    z[7,3,1]  R1520     0.636716902256012
    z[7,3,1]  R1521     -6.6063940525054932e-01
    z[7,3,1]  R1522     -8.4272943437099457e-02
    z[7,3,1]  R1523     9.9190972745418549e-02
    z[7,3,1]  R1524     7.1808320283889771e-01
    z[7,3,1]  R1525     0.739051103591919
    z[7,3,1]  R1526     -7.6281589269638062e-01
    z[7,3,1]  R1527     9.3487896025180817e-02
    z[7,3,1]  R1528     -1.1479447595775127e-02
    z[7,3,1]  R1529     1.2435419112443924e-01
    z[7,3,1]  R1530     -2.7331715449690819e-02
    z[7,3,1]  R1531     -5.5350143462419510e-02
    z[7,3,1]  R1532     -1.9552321732044220e-01
    z[7,3,1]  R1533     -4.2967148125171661e-02
    z[7,3,1]  R1534     -8.4875416755676270e-01
    z[7,3,1]  R1535     -7.6350408792495728e-01
    z[7,3,1]  R1536     -6.9220441579818726e-01
    z[7,3,1]  R1537     -7.5259184837341309e-01
    z[7,3,1]  R1538     -6.5914791822433472e-01
    z[7,3,1]  R1539     -6.3478189706802368e-01
    z[7,3,1]  R1540     -6.9675922393798828e-01
    z[7,3,1]  R1541     -6.8594950437545776e-01
    z[7,3,1]  R1542     -0.720085084438324
    z[7,3,1]  R1543     -0.654482364654541
    z[7,3,1]  R1544     5.3756970167160034e-01
    z[7,3,1]  R1545     6.7018610239028931e-01
    z[7,3,1]  R1546     5.2114909887313843e-01
    z[7,3,1]  R1547     8.0826961994171143e-01
    z[7,3,1]  R1548     5.2093577384948730e-01
    z[7,3,1]  R1549     0.766403079032898
    z[7,3,1]  R1550     5.3823846578598022e-01
    z[7,3,1]  R1551     5.6191658973693848e-01
    z[7,3,1]  R1552     6.8640989065170288e-01
    z[7,3,1]  R1553     5.8817285299301147e-01
    z[7,3,1]  R1554     -7.7654361724853516e-01
    z[7,3,1]  R1555     8.1427836418151855e-01
    z[7,3,1]  R1556     8.0048912763595581e-01
    z[7,3,1]  R1557     7.3714506626129150e-01
    z[7,3,1]  R1558     7.5503402948379517e-01
    z[7,3,1]  R1559     7.5513535737991333e-01
    z[7,3,1]  R1560     0.715343713760376
    z[7,3,1]  R1561     2.7329745888710022e-01
    z[7,3,1]  R1562     -0.789559006690979
    z[7,3,1]  R1563     0.406112939119339
    z[7,3,1]  R1564     8.8111555576324463e-01
    z[7,3,1]  R1565     7.5951015949249268e-01
    z[7,3,1]  R1566     7.7988177537918091e-01
    z[7,3,1]  R1567     8.7794524431228638e-01
    z[7,3,1]  R1568     -7.8032869100570679e-01
    z[7,3,1]  R1569     3.7118464708328247e-01
    z[7,3,1]  R1570     8.0645316839218140e-01
    z[7,3,1]  R1571     -6.7775064706802368e-01
    z[7,3,1]  R1572     -6.1478763818740845e-01
    z[7,3,1]  R1573     -0.553998589515686
    z[7,3,1]  R1574     -9.1400617361068726e-01
    z[7,3,1]  R1575     3.2584023475646973e-01
    z[7,3,1]  R1576     7.8695756196975708e-01
    z[7,3,1]  R1577     8.8433420658111572e-01
    z[7,3,1]  R1578     4.0293261408805847e-01
    z[7,3,1]  R1579     8.5626173019409180e-01
    z[7,3,1]  R1580     0.377754271030426
    z[7,3,1]  R1581     7.8552317619323730e-01
    z[7,3,1]  R1582     2.9795980453491211e-01
    z[7,3,1]  R1583     -7.5245392322540283e-01
    z[7,3,1]  R1584     8.6704850196838379e-01
    z[7,3,1]  R1585     8.2125717401504517e-01
    z[7,3,1]  R1586     7.3972302675247192e-01
    z[7,3,1]  R1587     5.6195092201232910e-01
    z[7,3,1]  R1588     4.4921347498893738e-01
    z[7,3,1]  R1589     3.6589628458023071e-01
    z[7,3,1]  R1590     6.1605077981948853e-01
    z[7,3,1]  R1591     3.1889653205871582e-01
    z[7,3,1]  R1592     4.2207670211791992e-01
    z[7,3,1]  R1593     -3.0615600943565369e-01
    z[7,3,1]  R1594     -8.5200399160385132e-01
    z[7,3,1]  R1595     7.9975503683090210e-01
    z[7,3,1]  R1596     6.9973438978195190e-01
    z[7,3,1]  R1597     5.4913687705993652e-01
    z[7,3,1]  R1598     7.5766873359680176e-01
    z[7,3,1]  R1599     8.5975813865661621e-01
    z[7,3,1]  R1600     -7.4762952327728271e-01
    z[7,3,1]  R1601     0.659613847732544
    z[7,3,1]  R1602     7.3501503467559814e-01
    z[7,3,1]  R1603     3.9458429813385010e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1464     -1
    z[7,3,2]  R1465     1
    z[7,3,2]  R1474     -3.1393519043922424e-01
    z[7,3,2]  R1475     2.6484060287475586e-01
    z[7,3,2]  R1476     3.9245903491973877e-01
    z[7,3,2]  R1477     -2.4120378494262695e-01
    z[7,3,2]  R1478     2.0590874552726746e-01
    z[7,3,2]  R1479     -0.0811953991651535
    z[7,3,2]  R1480     1.0469920188188553e-01
    z[7,3,2]  R1481     -3.9110708236694336e-01
    z[7,3,2]  R1482     -2.0833921432495117e-01
    z[7,3,2]  R1483     1.2931351363658905e-01
    z[7,3,2]  R1484     -1.3372267782688141e-01
    z[7,3,2]  R1485     4.0922638773918152e-01
    z[7,3,2]  R1486     3.1756168603897095e-01
    z[7,3,2]  R1487     0.203582301735878
    z[7,3,2]  R1488     1.8200094997882843e-01
    z[7,3,2]  R1489     -2.1236424148082733e-01
    z[7,3,2]  R1490     0.50497967004776
    z[7,3,2]  R1491     9.3543119728565216e-02
    z[7,3,2]  R1492     -8.2484386861324310e-02
    z[7,3,2]  R1493     4.8659324645996094e-02
    z[7,3,2]  R1494     3.2083711028099060e-01
    z[7,3,2]  R1495     9.2939190566539764e-02
    z[7,3,2]  R1496     -1.5390649437904358e-01
    z[7,3,2]  R1497     1.6410119831562042e-01
    z[7,3,2]  R1498     5.7167984545230865e-02
    z[7,3,2]  R1499     -3.9061662554740906e-01
    z[7,3,2]  R1500     5.6848201900720596e-02
    z[7,3,2]  R1501     -5.4133731871843338e-02
    z[7,3,2]  R1502     -2.2056396305561066e-01
    z[7,3,2]  R1503     1.7317201197147369e-01
    z[7,3,2]  R1504     5.1693990826606750e-02
    z[7,3,2]  R1505     4.4829097390174866e-01
    z[7,3,2]  R1506     -3.3350110054016113e-01
    z[7,3,2]  R1507     -3.5054117441177368e-02
    z[7,3,2]  R1508     -4.1754251718521118e-01
    z[7,3,2]  R1509     -3.0168288946151733e-01
    z[7,3,2]  R1510     2.8850439190864563e-01
    z[7,3,2]  R1511     1.4658813178539276e-01
    z[7,3,2]  R1512     0.429653137922287
    z[7,3,2]  R1513     -1.5571160614490509e-01
    z[7,3,2]  R1514     -3.1941803172230721e-03
    z[7,3,2]  R1515     5.2502267062664032e-02
    z[7,3,2]  R1516     3.3713912963867188e-01
    z[7,3,2]  R1517     -1.2892647087574005e-01
    z[7,3,2]  R1518     2.1969152987003326e-01
    z[7,3,2]  R1519     1.4927808940410614e-01
    z[7,3,2]  R1520     3.3755195140838623e-01
    z[7,3,2]  R1521     1.3285375200212002e-02
    z[7,3,2]  R1522     8.9557290077209473e-02
    z[7,3,2]  R1523     1.7660225927829742e-01
    z[7,3,2]  R1524     -3.9753105491399765e-02
    z[7,3,2]  R1525     3.1530502438545227e-01
    z[7,3,2]  R1526     2.7472989633679390e-02
    z[7,3,2]  R1527     -1.7919382452964783e-01
    z[7,3,2]  R1528     1.3483686745166779e-01
    z[7,3,2]  R1529     3.9303582161664963e-02
    z[7,3,2]  R1530     1.8700802326202393e-01
    z[7,3,2]  R1531     4.3138301372528076e-01
    z[7,3,2]  R1532     -1.2253466248512268e-01
    z[7,3,2]  R1533     4.8997050523757935e-01
    z[7,3,2]  R1534     -1.7875541746616364e-01
    z[7,3,2]  R1535     1.6437128186225891e-01
    z[7,3,2]  R1536     3.1386566162109375e-01
    z[7,3,2]  R1537     -3.5817819833755493e-01
    z[7,3,2]  R1538     3.0280584096908569e-01
    z[7,3,2]  R1539     -1.0577351599931717e-01
    z[7,3,2]  R1540     -1.2380877882242203e-01
    z[7,3,2]  R1541     -4.0357332676649094e-02
    z[7,3,2]  R1542     2.0476941764354706e-01
    z[7,3,2]  R1543     -6.9687180221080780e-02
    z[7,3,2]  R1544     -3.6673773080110550e-02
    z[7,3,2]  R1545     2.2529596462845802e-02
    z[7,3,2]  R1546     8.5387177765369415e-02
    z[7,3,2]  R1547     2.0524667203426361e-01
    z[7,3,2]  R1548     -0.329296350479126
    z[7,3,2]  R1549     -3.9191302657127380e-01
    z[7,3,2]  R1550     2.7171965688467026e-02
    z[7,3,2]  R1551     8.4818713366985321e-02
    z[7,3,2]  R1552     2.1026635169982910e-01
    z[7,3,2]  R1553     -2.5847575068473816e-01
    z[7,3,2]  R1554     1.1799214035272598e-01
    z[7,3,2]  R1555     2.5016331672668457e-01
    z[7,3,2]  R1556     2.2700999677181244e-01
    z[7,3,2]  R1557     -3.5879313945770264e-01
    z[7,3,2]  R1558     1.7400035262107849e-01
    z[7,3,2]  R1559     9.2336907982826233e-02
    z[7,3,2]  R1560     3.8307376205921173e-02
    z[7,3,2]  R1561     -7.4331218004226685e-01
    z[7,3,2]  R1562     -2.6634940505027771e-01
    z[7,3,2]  R1563     -0.789828896522522
    z[7,3,2]  R1564     1.3020043261349201e-02
    z[7,3,2]  R1565     -1.8992304801940918e-01
    z[7,3,2]  R1566     4.8273853957653046e-02
    z[7,3,2]  R1567     -6.0649521648883820e-02
    z[7,3,2]  R1568     0.0107242651283741
    z[7,3,2]  R1569     -7.5354951620101929e-01
    z[7,3,2]  R1570     0.287629097700119
    z[7,3,2]  R1571     5.4602712392807007e-01
    z[7,3,2]  R1572     -3.6274090409278870e-01
    z[7,3,2]  R1573     3.0183085799217224e-01
    z[7,3,2]  R1574     0.10428436845541
    z[7,3,2]  R1575     -8.4632897377014160e-01
    z[7,3,2]  R1576     -3.0057021975517273e-01
    z[7,3,2]  R1577     2.6213493943214417e-01
    z[7,3,2]  R1578     -0.735084056854248
    z[7,3,2]  R1579     -7.4791461229324341e-02
    z[7,3,2]  R1580     -7.0140624046325684e-01
    z[7,3,2]  R1581     3.8788110017776489e-01
    z[7,3,2]  R1582     -5.3228235244750977e-01
    z[7,3,2]  R1583     -3.9501330256462097e-01
    z[7,3,2]  R1584     2.4233403801918030e-01
    z[7,3,2]  R1585     -2.6138958334922791e-01
    z[7,3,2]  R1586     -9.5918755978345871e-03
    z[7,3,2]  R1587     -4.9447363615036011e-01
    z[7,3,2]  R1588     -3.5375642776489258e-01
    z[7,3,2]  R1589     -6.2617915868759155e-01
    z[7,3,2]  R1590     -1.7028453946113586e-01
    z[7,3,2]  R1591     -5.8189177513122559e-01
    z[7,3,2]  R1592     -3.6266106367111206e-01
    z[7,3,2]  R1593     6.6317516565322876e-01
    z[7,3,2]  R1594     -2.1971271932125092e-01
    z[7,3,2]  R1595     -5.5164462327957153e-01
    z[7,3,2]  R1596     -6.9032943248748779e-01
    z[7,3,2]  R1597     -5.0332820415496826e-01
    z[7,3,2]  R1598     -1.4362642168998718e-01
    z[7,3,2]  R1599     2.4596190452575684e-01
    z[7,3,2]  R1600     2.1174457669258118e-01
    z[7,3,2]  R1601     -3.6526271700859070e-01
    z[7,3,2]  R1602     1.2382742762565613e-01
    z[7,3,2]  R1603     -0.558544933795929
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1466     -1
    z[7,3,3]  R1467     1
    z[7,3,3]  R1474     4.6277437359094620e-02
    z[7,3,3]  R1475     -3.1967076659202576e-01
    z[7,3,3]  R1476     3.6842370033264160e-01
    z[7,3,3]  R1477     4.1894102096557617e-01
    z[7,3,3]  R1478     6.6029459238052368e-01
    z[7,3,3]  R1479     -5.6565958261489868e-01
    z[7,3,3]  R1480     -6.3447332382202148e-01
    z[7,3,3]  R1481     -4.1860821843147278e-01
    z[7,3,3]  R1482     6.9805681705474854e-01
    z[7,3,3]  R1483     -4.4370630383491516e-01
    z[7,3,3]  R1484     3.6959937214851379e-01
    z[7,3,3]  R1485     5.9318460524082184e-02
    z[7,3,3]  R1486     0.158525750041008
    z[7,3,3]  R1487     -2.3253539577126503e-02
    z[7,3,3]  R1488     2.3231007158756256e-01
    z[7,3,3]  R1489     -2.7718707919120789e-01
    z[7,3,3]  R1490     3.6711797118186951e-01
    z[7,3,3]  R1491     -0.226178377866745
    z[7,3,3]  R1492     -2.4011158943176270e-01
    z[7,3,3]  R1493     -2.7301368117332458e-01
    z[7,3,3]  R1494     -1.0322096198797226e-01
    z[7,3,3]  R1495     7.7387273311614990e-01
    z[7,3,3]  R1496     4.7139909863471985e-01
    z[7,3,3]  R1497     6.5096491575241089e-01
    z[7,3,3]  R1498     3.3719608187675476e-01
    z[7,3,3]  R1499     1.1057198047637939e-01
    z[7,3,3]  R1500     3.6398065090179443e-01
    z[7,3,3]  R1501     3.2900294661521912e-01
    z[7,3,3]  R1502     2.7178165316581726e-01
    z[7,3,3]  R1503     1.6171573102474213e-01
    z[7,3,3]  R1504     2.5542613863945007e-01
    z[7,3,3]  R1505     6.7297476530075073e-01
    z[7,3,3]  R1506     -3.4470504522323608e-01
    z[7,3,3]  R1507     0.0698728859424591
    z[7,3,3]  R1508     -0.00604488980025053
    z[7,3,3]  R1509     1.5375986695289612e-01
    z[7,3,3]  R1510     -1.3334222137928009e-01
    z[7,3,3]  R1511     4.6870082616806030e-01
    z[7,3,3]  R1512     5.1685118675231934e-01
    z[7,3,3]  R1513     -6.7933744192123413e-01
    z[7,3,3]  R1514     2.7467393875122070e-01
    z[7,3,3]  R1515     9.6514336764812469e-03
    z[7,3,3]  R1516     -1.6247574985027313e-01
    z[7,3,3]  R1517     -3.9134703576564789e-02
    z[7,3,3]  R1518     2.7464474551379681e-03
    z[7,3,3]  R1519     2.9281333088874817e-01
    z[7,3,3]  R1520     1.1872097849845886e-02
    z[7,3,3]  R1521     -1.6546325758099556e-02
    z[7,3,3]  R1522     -4.2227837443351746e-01
    z[7,3,3]  R1523     -2.3480325937271118e-01
    z[7,3,3]  R1524     6.3135528564453125e-01
    z[7,3,3]  R1525     3.2478424906730652e-01
    z[7,3,3]  R1526     1.4172525145113468e-02
    z[7,3,3]  R1527     -3.9085391163825989e-01
    z[7,3,3]  R1528     -1.7862078547477722e-01
    z[7,3,3]  R1529     -2.5062507390975952e-01
    z[7,3,3]  R1530     -3.4189638495445251e-01
    z[7,3,3]  R1531     1.4157831668853760e-01
    z[7,3,3]  R1532     -0.558853030204773
    z[7,3,3]  R1533     -2.4432018399238586e-01
    z[7,3,3]  R1534     -2.3181436955928802e-01
    z[7,3,3]  R1535     -4.4772112369537354e-01
    z[7,3,3]  R1536     -4.0277552604675293e-01
    z[7,3,3]  R1537     3.4380894899368286e-01
    z[7,3,3]  R1538     -0.393984854221344
    z[7,3,3]  R1539     -4.3403938412666321e-01
    z[7,3,3]  R1540     -3.7225216627120972e-01
    z[7,3,3]  R1541     -0.436993807554245
    z[7,3,3]  R1542     -3.0460822582244873e-01
    z[7,3,3]  R1543     -0.345674991607666
    z[7,3,3]  R1544     7.9763191938400269e-01
    z[7,3,3]  R1545     6.6494739055633545e-01
    z[7,3,3]  R1546     6.6684925556182861e-01
    z[7,3,3]  R1547     3.7392199039459229e-01
    z[7,3,3]  R1548     7.5536668300628662e-01
    z[7,3,3]  R1549     3.7185427546501160e-01
    z[7,3,3]  R1550     5.7558345794677734e-01
    z[7,3,3]  R1551     5.6364989280700684e-01
    z[7,3,3]  R1552     3.1432849168777466e-01
    z[7,3,3]  R1553     0.601999044418335
    z[7,3,3]  R1554     -4.2582151293754578e-01
    z[7,3,3]  R1555     -1.5460880100727081e-01
    z[7,3,3]  R1556     -1.9523912668228149e-01
    z[7,3,3]  R1557     9.0477697551250458e-02
    z[7,3,3]  R1558     -5.2065807580947876e-01
    z[7,3,3]  R1559     -1.8150655925273895e-01
    z[7,3,3]  R1560     -2.5736436247825623e-01
    z[7,3,3]  R1561     -6.2611490488052368e-02
    z[7,3,3]  R1562     -6.5198026597499847e-02
    z[7,3,3]  R1563     -1.1997640132904053e-01
    z[7,3,3]  R1564     2.7967724204063416e-01
    z[7,3,3]  R1565     5.3419440984725952e-01
    z[7,3,3]  R1566     8.6413323879241943e-02
    z[7,3,3]  R1567     2.2495500743389130e-01
    z[7,3,3]  R1568     -6.5599568188190460e-02
    z[7,3,3]  R1569     -6.9331027567386627e-02
    z[7,3,3]  R1570     7.2255417704582214e-02
    z[7,3,3]  R1571     3.0335399508476257e-01
    z[7,3,3]  R1572     4.1781830787658691e-01
    z[7,3,3]  R1573     -5.6925421953201294e-01
    z[7,3,3]  R1574     -1.6221408545970917e-01
    z[7,3,3]  R1575     2.3226570338010788e-02
    z[7,3,3]  R1576     -2.8599998354911804e-01
    z[7,3,3]  R1577     -2.3139625787734985e-02
    z[7,3,3]  R1578     2.3291775584220886e-01
    z[7,3,3]  R1579     2.2588601708412170e-01
    z[7,3,3]  R1580     5.4531472921371460e-01
    z[7,3,3]  R1581     1.6942591965198517e-01
    z[7,3,3]  R1582     5.3970688581466675e-01
    z[7,3,3]  R1583     1.5945779159665108e-03
    z[7,3,3]  R1584     7.2592481970787048e-02
    z[7,3,3]  R1585     -3.9525586366653442e-01
    z[7,3,3]  R1586     -4.1620454192161560e-01
    z[7,3,3]  R1587     1.8690448999404907e-01
    z[7,3,3]  R1588     6.6859899088740349e-03
    z[7,3,3]  R1589     -6.8584673106670380e-02
    z[7,3,3]  R1590     3.2622119784355164e-01
    z[7,3,3]  R1591     2.0877651870250702e-01
    z[7,3,3]  R1592     2.0125991106033325e-01
    z[7,3,3]  R1593     -6.1015486717224121e-01
    z[7,3,3]  R1594     1.4422349631786346e-01
    z[7,3,3]  R1595     1.1832524836063385e-01
    z[7,3,3]  R1596     -6.7909307777881622e-02
    z[7,3,3]  R1597     8.2499362528324127e-02
    z[7,3,3]  R1598     3.1887543201446533e-01
    z[7,3,3]  R1599     3.2872881740331650e-02
    z[7,3,3]  R1600     2.8650152683258057e-01
    z[7,3,3]  R1601     2.9154961928725243e-02
    z[7,3,3]  R1602     3.1599089503288269e-01
    z[7,3,3]  R1603     3.0711406469345093e-01
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1468     -1
    z[7,3,4]  R1469     1
    z[7,3,4]  R1474     5.3448425605893135e-03
    z[7,3,4]  R1475     7.1973830461502075e-02
    z[7,3,4]  R1476     -4.8017600178718567e-01
    z[7,3,4]  R1477     -1.9535413384437561e-01
    z[7,3,4]  R1478     -1.4793622493743896e-01
    z[7,3,4]  R1479     -2.0826685428619385e-01
    z[7,3,4]  R1480     -1.2676788866519928e-01
    z[7,3,4]  R1481     0.075748011469841
    z[7,3,4]  R1482     -3.0495241284370422e-01
    z[7,3,4]  R1483     -3.5932940244674683e-01
    z[7,3,4]  R1484     -3.7670621275901794e-01
    z[7,3,4]  R1485     8.1031396985054016e-02
    z[7,3,4]  R1486     -1.0515597462654114e-01
    z[7,3,4]  R1487     -3.5539028048515320e-01
    z[7,3,4]  R1488     1.5031726658344269e-01
    z[7,3,4]  R1489     -4.6373081207275391e-01
    z[7,3,4]  R1490     -7.2809509932994843e-02
    z[7,3,4]  R1491     1.7562508583068848e-02
    z[7,3,4]  R1492     2.8269737958908081e-02
    z[7,3,4]  R1493     -3.1315669417381287e-01
    z[7,3,4]  R1494     -3.0388814210891724e-01
    z[7,3,4]  R1495     2.6128491386771202e-02
    z[7,3,4]  R1496     -4.3060481548309326e-01
    z[7,3,4]  R1497     -3.5561460256576538e-01
    z[7,3,4]  R1498     3.0817720293998718e-01
    z[7,3,4]  R1499     -2.5788927078247070e-01
    z[7,3,4]  R1500     -0.136447012424469
    z[7,3,4]  R1501     -0.397080659866333
    z[7,3,4]  R1502     2.9640036821365356e-01
    z[7,3,4]  R1503     4.8846226930618286e-01
    z[7,3,4]  R1504     -1.9163309037685394e-01
    z[7,3,4]  R1505     -1.0979609936475754e-01
    z[7,3,4]  R1506     4.2299106717109680e-02
    z[7,3,4]  R1507     3.5171234607696533e-01
    z[7,3,4]  R1508     -4.8808288574218750e-01
    z[7,3,4]  R1509     1.0107087343931198e-01
    z[7,3,4]  R1510     -2.2987291216850281e-01
    z[7,3,4]  R1511     1.7197330296039581e-01
    z[7,3,4]  R1512     -1.2985230982303619e-01
    z[7,3,4]  R1513     -1.8230605125427246e-01
    z[7,3,4]  R1514     1.2664791941642761e-01
    z[7,3,4]  R1515     -1.9079525768756866e-01
    z[7,3,4]  R1516     0.421440452337265
    z[7,3,4]  R1517     6.2770366668701172e-01
    z[7,3,4]  R1518     5.0600588321685791e-01
    z[7,3,4]  R1519     -8.1653788685798645e-02
    z[7,3,4]  R1520     -5.7408052682876587e-01
    z[7,3,4]  R1521     4.3769359588623047e-01
    z[7,3,4]  R1522     -4.2954739183187485e-02
    z[7,3,4]  R1523     -4.6383373439311981e-02
    z[7,3,4]  R1524     -4.4163081794977188e-02
    z[7,3,4]  R1525     4.4525933265686035e-01
    z[7,3,4]  R1526     3.0113452672958374e-01
    z[7,3,4]  R1527     -1.1861461400985718e-01
    z[7,3,4]  R1528     -4.3670544028282166e-01
    z[7,3,4]  R1529     1.7355741560459137e-01
    z[7,3,4]  R1530     -2.5035262107849121e-02
    z[7,3,4]  R1531     -1.7194424569606781e-01
    z[7,3,4]  R1532     -2.7346280217170715e-01
    z[7,3,4]  R1533     8.6590789258480072e-02
    z[7,3,4]  R1534     -4.8964913934469223e-02
    z[7,3,4]  R1535     5.5193908512592316e-02
    z[7,3,4]  R1536     -4.3499651551246643e-01
    z[7,3,4]  R1537     5.3880762308835983e-02
    z[7,3,4]  R1538     -6.8078011274337769e-02
    z[7,3,4]  R1539     -1.6763618588447571e-01
    z[7,3,4]  R1540     -1.6528154909610748e-01
    z[7,3,4]  R1541     -4.5524783432483673e-02
    z[7,3,4]  R1542     0.0381888784468174
    z[7,3,4]  R1543     -4.9342054128646851e-01
    z[7,3,4]  R1544     1.1767548322677612e-01
    z[7,3,4]  R1545     1.7249056696891785e-01
    z[7,3,4]  R1546     -2.6817208528518677e-01
    z[7,3,4]  R1547     -3.3016937971115112e-01
    z[7,3,4]  R1548     -5.6820875033736229e-03
    z[7,3,4]  R1549     -1.5482572838664055e-02
    z[7,3,4]  R1550     -1.2258156388998032e-01
    z[7,3,4]  R1551     2.3047678172588348e-01
    z[7,3,4]  R1552     2.7015358209609985e-01
    z[7,3,4]  R1553     -3.2794106006622314e-01
    z[7,3,4]  R1554     -1.9003254175186157e-01
    z[7,3,4]  R1555     1.6714981198310852e-01
    z[7,3,4]  R1556     -3.6104834079742432e-01
    z[7,3,4]  R1557     3.3447524905204773e-01
    z[7,3,4]  R1558     1.3892273604869843e-01
    z[7,3,4]  R1559     -1.2286851555109024e-01
    z[7,3,4]  R1560     -0.516867995262146
    z[7,3,4]  R1561     -3.9206707477569580e-01
    z[7,3,4]  R1562     3.8908639550209045e-01
    z[7,3,4]  R1563     -6.9490373134613037e-02
    z[7,3,4]  R1564     -1.2628835439682007e-01
    z[7,3,4]  R1565     -1.5086817741394043e-01
    z[7,3,4]  R1566     5.0990754365921021e-01
    z[7,3,4]  R1567     0.221954807639122
    z[7,3,4]  R1568     3.9529573917388916e-01
    z[7,3,4]  R1569     -2.4070492386817932e-01
    z[7,3,4]  R1570     1.9609211385250092e-01
    z[7,3,4]  R1571     3.3434832096099854e-01
    z[7,3,4]  R1572     2.4741759896278381e-01
    z[7,3,4]  R1573     3.8723891973495483e-01
    z[7,3,4]  R1574     -7.8918620944023132e-02
    z[7,3,4]  R1575     -2.8224804997444153e-01
    z[7,3,4]  R1576     3.5960423946380615e-01
    z[7,3,4]  R1577     1.7976656556129456e-01
    z[7,3,4]  R1578     -0.0944976955652237
    z[7,3,4]  R1579     4.1586112976074219e-01
    z[7,3,4]  R1580     0.0369749441742897
    z[7,3,4]  R1581     -8.0548338592052460e-02
    z[7,3,4]  R1582     -3.3165144920349121e-01
    z[7,3,4]  R1583     3.9381337165832520e-01
    z[7,3,4]  R1584     -1.0884880274534225e-01
    z[7,3,4]  R1585     -5.6445185095071793e-02
    z[7,3,4]  R1586     1.8267078697681427e-01
    z[7,3,4]  R1587     -1.2607282400131226e-01
    z[7,3,4]  R1588     -7.9346001148223877e-01
    z[7,3,4]  R1589     -3.8210639357566833e-01
    z[7,3,4]  R1590     -3.9536821842193604e-01
    z[7,3,4]  R1591     -2.9035148024559021e-01
    z[7,3,4]  R1592     -4.5989876985549927e-01
    z[7,3,4]  R1593     -0.0334247350692749
    z[7,3,4]  R1594     2.0210993289947510e-01
    z[7,3,4]  R1595     -1.2239823117852211e-02
    z[7,3,4]  R1596     -1.5212576091289520e-01
    z[7,3,4]  R1597     -6.2422102689743042e-01
    z[7,3,4]  R1598     -3.2902446389198303e-01
    z[7,3,4]  R1599     -3.5859817266464233e-01
    z[7,3,4]  R1600     3.8695797324180603e-01
    z[7,3,4]  R1601     -4.1047602891921997e-01
    z[7,3,4]  R1602     2.9874143004417419e-01
    z[7,3,4]  R1603     -0.427390456199646
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1470     -1
    z[7,3,5]  R1471     1
    z[7,3,5]  R1474     -0.31219482421875
    z[7,3,5]  R1475     -2.3086293041706085e-01
    z[7,3,5]  R1476     1.7589475214481354e-01
    z[7,3,5]  R1477     -4.6738073229789734e-01
    z[7,3,5]  R1478     -5.8575284481048584e-01
    z[7,3,5]  R1479     1.2727017700672150e-01
    z[7,3,5]  R1480     4.8118501901626587e-02
    z[7,3,5]  R1481     0.347350537776947
    z[7,3,5]  R1482     -1.6113558411598206e-01
    z[7,3,5]  R1483     -1.2302889674901962e-01
    z[7,3,5]  R1484     1.3189418613910675e-01
    z[7,3,5]  R1485     6.9038402289152145e-03
    z[7,3,5]  R1486     3.8950878381729126e-01
    z[7,3,5]  R1487     2.5515630841255188e-01
    z[7,3,5]  R1488     4.1244697570800781e-01
    z[7,3,5]  R1489     -1.0995906591415405e-01
    z[7,3,5]  R1490     4.1062346100807190e-01
    z[7,3,5]  R1491     -3.6728653311729431e-01
    z[7,3,5]  R1492     2.1188862621784210e-01
    z[7,3,5]  R1493     3.0348362401127815e-02
    z[7,3,5]  R1494     2.4304036796092987e-01
    z[7,3,5]  R1495     -0.323932021856308
    z[7,3,5]  R1496     5.7969961315393448e-02
    z[7,3,5]  R1497     -1.9923089444637299e-01
    z[7,3,5]  R1498     -5.8258390426635742e-01
    z[7,3,5]  R1499     2.3948390036821365e-02
    z[7,3,5]  R1500     -5.2788370847702026e-01
    z[7,3,5]  R1501     -5.4126250743865967e-01
    z[7,3,5]  R1502     -2.6952026411890984e-02
    z[7,3,5]  R1503     4.5434519648551941e-01
    z[7,3,5]  R1504     -2.9925969243049622e-01
    z[7,3,5]  R1505     -9.9724262952804565e-02
    z[7,3,5]  R1506     3.2728222012519836e-01
    z[7,3,5]  R1507     -2.2290121018886566e-01
    z[7,3,5]  R1508     0.0622372180223465
    z[7,3,5]  R1509     -4.6589246392250061e-01
    z[7,3,5]  R1510     -2.9143321514129639e-01
    z[7,3,5]  R1511     -2.3345613479614258e-01
    z[7,3,5]  R1512     -2.1432501077651978e-01
    z[7,3,5]  R1513     -1.2208786606788635e-01
    z[7,3,5]  R1514     1.1788544803857803e-01
    z[7,3,5]  R1515     -4.1838833689689636e-01
    z[7,3,5]  R1516     2.2229743003845215e-01
    z[7,3,5]  R1517     -1.6100279986858368e-01
    z[7,3,5]  R1518     -0.317974716424942
    z[7,3,5]  R1519     1.4082056283950806e-01
    z[7,3,5]  R1520     -0.0612872950732708
    z[7,3,5]  R1521     2.7239572955295444e-04
    z[7,3,5]  R1522     2.6067218184471130e-01
    z[7,3,5]  R1523     3.6580806970596313e-01
    z[7,3,5]  R1524     9.9663458764553070e-02
    z[7,3,5]  R1525     6.3331179320812225e-02
    z[7,3,5]  R1526     -1.1396781355142593e-01
    z[7,3,5]  R1527     3.1341653317213058e-02
    z[7,3,5]  R1528     3.1393431127071381e-02
    z[7,3,5]  R1529     -6.8679951131343842e-02
    z[7,3,5]  R1530     5.4897193331271410e-04
    z[7,3,5]  R1531     3.0671315267682076e-02
    z[7,3,5]  R1532     -2.3857496678829193e-02
    z[7,3,5]  R1533     -0.260144978761673
    z[7,3,5]  R1534     1.7014965415000916e-01
    z[7,3,5]  R1535     -4.2478391528129578e-01
    z[7,3,5]  R1536     2.3235505819320679e-01
    z[7,3,5]  R1537     1.9555102288722992e-01
    z[7,3,5]  R1538     2.1225447952747345e-01
    z[7,3,5]  R1539     1.0172709822654724e-01
    z[7,3,5]  R1540     -1.7702551186084747e-01
    z[7,3,5]  R1541     1.4993183314800262e-01
    z[7,3,5]  R1542     2.3352034389972687e-02
    z[7,3,5]  R1543     7.1231603622436523e-02
    z[7,3,5]  R1544     -1.7235511541366577e-01
    z[7,3,5]  R1545     9.0874463319778442e-02
    z[7,3,5]  R1546     -4.3601825833320618e-01
    z[7,3,5]  R1547     1.3626746833324432e-01
    z[7,3,5]  R1548     -1.3970367610454559e-01
    z[7,3,5]  R1549     -1.0332430899143219e-01
    z[7,3,5]  R1550     -0.326092928647995
    z[7,3,5]  R1551     -2.9079735279083252e-01
    z[7,3,5]  R1552     -4.3435847759246826e-01
    z[7,3,5]  R1553     -1.2726742029190063e-01
    z[7,3,5]  R1554     -2.8780168294906616e-01
    z[7,3,5]  R1555     3.0216421931982040e-02
    z[7,3,5]  R1556     2.1535606682300568e-01
    z[7,3,5]  R1557     -1.5049597620964050e-01
    z[7,3,5]  R1558     2.0277952717151493e-04
    z[7,3,5]  R1559     -5.5093520879745483e-01
    z[7,3,5]  R1560     3.4875091910362244e-01
    z[7,3,5]  R1561     3.7186926603317261e-01
    z[7,3,5]  R1562     1.2121313810348511e-01
    z[7,3,5]  R1563     -1.8821124732494354e-01
    z[7,3,5]  R1564     3.1642279028892517e-01
    z[7,3,5]  R1565     -0.0658579170703888
    z[7,3,5]  R1566     3.0122599005699158e-01
    z[7,3,5]  R1567     2.2972339764237404e-02
    z[7,3,5]  R1568     -1.2041824311017990e-01
    z[7,3,5]  R1569     3.9197036623954773e-01
    z[7,3,5]  R1570     -1.9379844889044762e-02
    z[7,3,5]  R1571     -6.1678741127252579e-02
    z[7,3,5]  R1572     -6.3429638743400574e-02
    z[7,3,5]  R1573     2.6149657368659973e-01
    z[7,3,5]  R1574     1.3480226695537567e-01
    z[7,3,5]  R1575     9.2387810349464417e-02
    z[7,3,5]  R1576     -2.0555862784385681e-01
    z[7,3,5]  R1577     -1.2378104031085968e-01
    z[7,3,5]  R1578     -3.0704462528228760e-01
    z[7,3,5]  R1579     -1.5496802330017090e-01
    z[7,3,5]  R1580     1.0670841485261917e-01
    z[7,3,5]  R1581     -1.9605213403701782e-01
    z[7,3,5]  R1582     4.4633254408836365e-01
    z[7,3,5]  R1583     3.0406826734542847e-01
    z[7,3,5]  R1584     -7.4417233467102051e-02
    z[7,3,5]  R1585     8.5203811526298523e-02
    z[7,3,5]  R1586     2.7012443542480469e-01
    z[7,3,5]  R1587     9.4676263630390167e-02
    z[7,3,5]  R1588     1.8872748315334320e-01
    z[7,3,5]  R1589     5.4099857807159424e-01
    z[7,3,5]  R1590     -5.4565286636352539e-01
    z[7,3,5]  R1591     -1.6689732670783997e-01
    z[7,3,5]  R1592     6.1263066530227661e-01
    z[7,3,5]  R1593     1.7487421631813049e-01
    z[7,3,5]  R1594     -2.8541627526283264e-01
    z[7,3,5]  R1595     -1.9115678966045380e-01
    z[7,3,5]  R1596     5.5060341954231262e-02
    z[7,3,5]  R1597     -5.4392233490943909e-02
    z[7,3,5]  R1598     -4.0359079837799072e-01
    z[7,3,5]  R1599     -1.8619143962860107e-01
    z[7,3,5]  R1600     -1.2645585834980011e-01
    z[7,3,5]  R1601     -1.0071890056133270e-01
    z[7,3,5]  R1602     -5.6475242599844933e-03
    z[7,3,5]  R1603     -0.109067901968956
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1472     -1
    z[7,3,6]  R1473     1
    z[7,3,6]  R1474     -0.109520822763443
    z[7,3,6]  R1475     -1.4239962399005890e-01
    z[7,3,6]  R1476     -5.9989333152770996e-02
    z[7,3,6]  R1477     2.1068461239337921e-01
    z[7,3,6]  R1478     -2.2491894662380219e-01
    z[7,3,6]  R1479     -7.6896086335182190e-02
    z[7,3,6]  R1480     1.3612794876098633e-01
    z[7,3,6]  R1481     2.0970821380615234e-01
    z[7,3,6]  R1482     4.3940261006355286e-01
    z[7,3,6]  R1483     -0.487010657787323
    z[7,3,6]  R1484     -9.0700075030326843e-02
    z[7,3,6]  R1485     -1.3375128805637360e-01
    z[7,3,6]  R1486     -2.1589969098567963e-01
    z[7,3,6]  R1487     -2.1428486704826355e-01
    z[7,3,6]  R1488     -2.3845452815294266e-03
    z[7,3,6]  R1489     -9.6321694552898407e-02
    z[7,3,6]  R1490     -7.8668676316738129e-02
    z[7,3,6]  R1491     -2.5815647840499878e-01
    z[7,3,6]  R1492     -1.4488619565963745e-01
    z[7,3,6]  R1493     8.9614205062389374e-02
    z[7,3,6]  R1494     -1.3530252873897552e-01
    z[7,3,6]  R1495     1.5942711383104324e-02
    z[7,3,6]  R1496     2.8550121188163757e-01
    z[7,3,6]  R1497     1.5308916568756104e-01
    z[7,3,6]  R1498     -0.0966232642531395
    z[7,3,6]  R1499     2.8245496749877930e-01
    z[7,3,6]  R1500     1.2730962038040161e-01
    z[7,3,6]  R1501     -2.7441918849945068e-01
    z[7,3,6]  R1502     2.9530939459800720e-01
    z[7,3,6]  R1503     8.2507394254207611e-02
    z[7,3,6]  R1504     0.0876837819814682
    z[7,3,6]  R1505     -3.1188886612653732e-02
    z[7,3,6]  R1506     2.0890679955482483e-01
    z[7,3,6]  R1507     -5.3696759045124054e-02
    z[7,3,6]  R1508     1.8775881826877594e-01
    z[7,3,6]  R1509     -9.2540644109249115e-02
    z[7,3,6]  R1510     -4.1524580121040344e-01
    z[7,3,6]  R1511     2.2078908979892731e-01
    z[7,3,6]  R1512     -2.6936089992523193e-01
    z[7,3,6]  R1513     -2.4935486912727356e-01
    z[7,3,6]  R1514     4.1789177805185318e-02
    z[7,3,6]  R1515     -2.1374231204390526e-02
    z[7,3,6]  R1516     -1.1075932532548904e-01
    z[7,3,6]  R1517     -6.0759719461202621e-02
    z[7,3,6]  R1518     -2.0654113590717316e-01
    z[7,3,6]  R1519     -5.0848603248596191e-01
    z[7,3,6]  R1520     -3.7379625439643860e-01
    z[7,3,6]  R1521     3.6895927786827087e-01
    z[7,3,6]  R1522     -1.7761395871639252e-01
    z[7,3,6]  R1523     3.8708765059709549e-02
    z[7,3,6]  R1524     0.268314003944397
    z[7,3,6]  R1525     -1.5159203112125397e-01
    z[7,3,6]  R1526     3.1062346696853638e-01
    z[7,3,6]  R1527     -1.5792258083820343e-01
    z[7,3,6]  R1528     1.0321221500635147e-01
    z[7,3,6]  R1529     -1.3810354471206665e-01
    z[7,3,6]  R1530     3.0551424622535706e-01
    z[7,3,6]  R1531     -9.2492602765560150e-02
    z[7,3,6]  R1532     2.8589364886283875e-01
    z[7,3,6]  R1533     -1.7685487866401672e-01
    z[7,3,6]  R1534     -8.7334677577018738e-02
    z[7,3,6]  R1535     -6.0142739675939083e-03
    z[7,3,6]  R1536     -2.1511197090148926e-02
    z[7,3,6]  R1537     -1.4263409376144409e-01
    z[7,3,6]  R1538     -4.6441400051116943e-01
    z[7,3,6]  R1539     -5.9535163640975952e-01
    z[7,3,6]  R1540     -4.9260437488555908e-01
    z[7,3,6]  R1541     -5.4002481698989868e-01
    z[7,3,6]  R1542     -2.4094898998737335e-01
    z[7,3,6]  R1543     -4.2733040452003479e-01
    z[7,3,6]  R1544     1.5698526799678802e-01
    z[7,3,6]  R1545     -1.5782795846462250e-01
    z[7,3,6]  R1546     -7.6108537614345551e-02
    z[7,3,6]  R1547     1.4965327084064484e-01
    z[7,3,6]  R1548     -9.0734608471393585e-02
    z[7,3,6]  R1549     -3.2037842273712158e-01
    z[7,3,6]  R1550     4.4052439928054810e-01
    z[7,3,6]  R1551     2.0833517611026764e-01
    z[7,3,6]  R1552     -3.4928861260414124e-01
    z[7,3,6]  R1553     2.9489165544509888e-01
    z[7,3,6]  R1554     6.1515177367255092e-04
    z[7,3,6]  R1555     4.6298485994338989e-01
    z[7,3,6]  R1556     -2.2220499813556671e-01
    z[7,3,6]  R1557     4.0010184049606323e-01
    z[7,3,6]  R1558     3.2092493772506714e-01
    z[7,3,6]  R1559     -8.5266232490539551e-02
    z[7,3,6]  R1560     -1.0100036161020398e-04
    z[7,3,6]  R1561     2.5116398930549622e-01
    z[7,3,6]  R1562     -8.1232629716396332e-02
    z[7,3,6]  R1563     1.4770555496215820e-01
    z[7,3,6]  R1564     1.1533907800912857e-01
    z[7,3,6]  R1565     1.5381710231304169e-01
    z[7,3,6]  R1566     8.8793292641639709e-02
    z[7,3,6]  R1567     -2.6950512081384659e-02
    z[7,3,6]  R1568     4.3488475680351257e-01
    z[7,3,6]  R1569     2.4490984156727791e-02
    z[7,3,6]  R1570     -6.1473004519939423e-02
    z[7,3,6]  R1571     -1.6112464666366577e-01
    z[7,3,6]  R1572     4.9912306666374207e-01
    z[7,3,6]  R1573     5.3253639489412308e-02
    z[7,3,6]  R1574     2.6396813988685608e-01
    z[7,3,6]  R1575     -8.4703646600246429e-02
    z[7,3,6]  R1576     -1.8765434622764587e-01
    z[7,3,6]  R1577     -2.0507527887821198e-01
    z[7,3,6]  R1578     3.4222784638404846e-01
    z[7,3,6]  R1579     -1.0279571637511253e-02
    z[7,3,6]  R1580     -2.3415200412273407e-01
    z[7,3,6]  R1581     0.39665687084198
    z[7,3,6]  R1582     -1.1886099725961685e-01
    z[7,3,6]  R1583     -1.3070569932460785e-01
    z[7,3,6]  R1584     3.5307818651199341e-01
    z[7,3,6]  R1585     -4.9115438014268875e-02
    z[7,3,6]  R1586     -2.7694234251976013e-01
    z[7,3,6]  R1587     1.7937886714935303e-01
    z[7,3,6]  R1588     -7.9604998230934143e-02
    z[7,3,6]  R1589     -1.4860881865024567e-01
    z[7,3,6]  R1590     1.1060429364442825e-01
    z[7,3,6]  R1591     -4.7008684277534485e-01
    z[7,3,6]  R1592     1.5651646256446838e-01
    z[7,3,6]  R1593     -1.4176055788993835e-01
    z[7,3,6]  R1594     2.8541889786720276e-01
    z[7,3,6]  R1595     2.6265071704983711e-02
    z[7,3,6]  R1596     -5.2953604608774185e-02
    z[7,3,6]  R1597     2.1357278525829315e-01
    z[7,3,6]  R1598     8.4018506109714508e-02
    z[7,3,6]  R1599     -1.7056916654109955e-01
    z[7,3,6]  R1600     -2.9217815026640892e-02
    z[7,3,6]  R1601     -2.2908061742782593e-01
    z[7,3,6]  R1602     4.5333832502365112e-01
    z[7,3,6]  R1603     -4.8690277338027954e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1688     -1
    z[4,5,0]  R1689     1
    z[4,5,0]  R1702     -1.0769873857498169e-01
    z[4,5,0]  R1703     4.4023630023002625e-01
    z[4,5,0]  R1704     1.5612202882766724e-01
    z[4,5,0]  R1705     1.0710169374942780e-01
    z[4,5,0]  R1706     1.4449438452720642e-01
    z[4,5,0]  R1707     3.6898839473724365e-01
    z[4,5,0]  R1708     3.5365390777587891e-01
    z[4,5,0]  R1709     2.2610253095626831e-01
    z[4,5,0]  R1710     3.7432238459587097e-01
    z[4,5,0]  R1711     4.5319777727127075e-01
    z[4,5,0]  R1712     4.2977181077003479e-01
    z[4,5,0]  R1713     8.7702494859695435e-01
    z[4,5,0]  R1714     4.8994666337966919e-01
    z[4,5,0]  R1715     7.9518508911132812e-01
    z[4,5,0]  R1716     7.8260397911071777e-01
    z[4,5,0]  R1717     6.9906884431838989e-01
    z[4,5,0]  R1718     8.0059701204299927e-01
    z[4,5,0]  R1719     7.1674311161041260e-01
    z[4,5,0]  R1720     1.7772741615772247e-01
    z[4,5,0]  R1721     3.0831113457679749e-01
    z[4,5,0]  R1722     0.0574665404856205
    z[4,5,0]  R1723     -1.6069617867469788e-01
    z[4,5,0]  R1724     -1.8466311693191528e-01
    z[4,5,0]  R1725     2.6367574930191040e-01
    z[4,5,0]  R1726     -3.7643620371818542e-01
    z[4,5,0]  R1727     -4.2276340723037720e-01
    z[4,5,0]  R1728     -2.7800530195236206e-01
    z[4,5,0]  R1729     -3.9284005761146545e-01
    z[4,5,0]  R1730     -2.9538375139236450e-01
    z[4,5,0]  R1731     -2.8193703293800354e-01
    z[4,5,0]  R1732     3.2031199336051941e-01
    z[4,5,0]  R1733     0.64688640832901
    z[4,5,0]  R1734     4.9982777237892151e-01
    z[4,5,0]  R1735     5.6988584995269775e-01
    z[4,5,0]  R1736     3.5082665085792542e-01
    z[4,5,0]  R1737     7.1311330795288086e-01
    z[4,5,0]  R1738     6.9980710744857788e-01
    z[4,5,0]  R1739     6.9062197208404541e-01
    z[4,5,0]  R1740     7.6047849655151367e-01
    z[4,5,0]  R1741     8.7697041034698486e-01
    z[4,5,0]  R1742     4.1299268603324890e-01
    z[4,5,0]  R1743     0.889885663986206
    z[4,5,0]  R1744     1.6321896016597748e-01
    z[4,5,0]  R1745     -2.9290360212326050e-01
    z[4,5,0]  R1746     -2.1908316761255264e-02
    z[4,5,0]  R1747     8.1645774841308594e-01
    z[4,5,0]  R1748     -2.7878215909004211e-01
    z[4,5,0]  R1749     -7.4276372790336609e-02
    z[4,5,0]  R1750     -0.558233380317688
    z[4,5,0]  R1751     1.1558765172958374e-01
    z[4,5,0]  R1752     0.0573107935488224
    z[4,5,0]  R1753     7.9961299896240234e-01
    z[4,5,0]  R1754     2.4737431108951569e-01
    z[4,5,0]  R1755     6.1655020713806152e-01
    z[4,5,0]  R1756     1.5405617654323578e-01
    z[4,5,0]  R1757     6.4512962102890015e-01
    z[4,5,0]  R1758     -4.4343182444572449e-01
    z[4,5,0]  R1759     3.7412993609905243e-02
    z[4,5,0]  R1760     3.1464582681655884e-01
    z[4,5,0]  R1761     3.0606740713119507e-01
    z[4,5,0]  R1762     4.7941152006387711e-02
    z[4,5,0]  R1763     2.8697720170021057e-01
    z[4,5,0]  R1764     -4.5842775143682957e-03
    z[4,5,0]  R1765     3.2030594348907471e-01
    z[4,5,0]  R1766     3.5250097513198853e-01
    z[4,5,0]  R1767     2.0658531785011292e-01
    z[4,5,0]  R1768     8.9794412255287170e-02
    z[4,5,0]  R1769     -8.2716733217239380e-02
    z[4,5,0]  R1770     -8.0401289463043213e-01
    z[4,5,0]  R1771     -4.5728474855422974e-01
    z[4,5,0]  R1772     -1.7456750571727753e-01
    z[4,5,0]  R1773     -5.2107536792755127e-01
    z[4,5,0]  R1774     6.4120548963546753e-01
    z[4,5,0]  R1775     -6.3968378305435181e-01
    z[4,5,0]  R1776     -0.747021496295929
    z[4,5,0]  R1777     -7.5739741325378418e-01
    z[4,5,0]  R1778     -7.6824188232421875e-01
    z[4,5,0]  R1779     -7.7754920721054077e-01
    z[4,5,0]  R1780     -0.503307044506073
    z[4,5,0]  R1781     -6.0108578205108643e-01
    z[4,5,0]  R1782     2.3319423198699951e-01
    z[4,5,0]  R1783     3.1212385743856430e-02
    z[4,5,0]  R1784     5.0146347284317017e-01
    z[4,5,0]  R1785     -3.9650425314903259e-02
    z[4,5,0]  R1786     3.2497721910476685e-01
    z[4,5,0]  R1787     -4.7212675213813782e-01
    z[4,5,0]  R1788     -3.6578410863876343e-01
    z[4,5,0]  R1789     -2.6424747705459595e-01
    z[4,5,0]  R1790     -4.2607155442237854e-01
    z[4,5,0]  R1791     -4.7789987921714783e-01
    z[4,5,0]  R1792     8.5370033979415894e-01
    z[4,5,0]  R1793     7.5417733192443848e-01
    z[4,5,0]  R1794     3.1483504176139832e-01
    z[4,5,0]  R1795     5.8094173669815063e-01
    z[4,5,0]  R1796     3.3036491274833679e-01
    z[4,5,0]  R1797     6.6223418712615967e-01
    z[4,5,0]  R1798     6.2715351581573486e-01
    z[4,5,0]  R1799     5.4246836900711060e-01
    z[4,5,0]  R1800     5.1179546117782593e-01
    z[4,5,0]  R1801     -8.4287482500076294e-01
    z[4,5,0]  R1802     5.6227583438158035e-02
    z[4,5,0]  R1803     0.466959148645401
    z[4,5,0]  R1804     4.4979009032249451e-01
    z[4,5,0]  R1805     -2.8108501434326172e-01
    z[4,5,0]  R1806     -2.9995483160018921e-01
    z[4,5,0]  R1807     -0.602034330368042
    z[4,5,0]  R1808     -1.1290226131677628e-01
    z[4,5,0]  R1809     -1.3753145933151245e-01
    z[4,5,0]  R1810     3.4224852919578552e-01
    z[4,5,0]  R1811     -3.2606214284896851e-02
    z[4,5,0]  R1812     1.9191227853298187e-01
    z[4,5,0]  R1813     5.6973749399185181e-01
    z[4,5,0]  R1814     5.6437432765960693e-01
    z[4,5,0]  R1815     1.7782148718833923e-01
    z[4,5,0]  R1816     6.2057304382324219e-01
    z[4,5,0]  R1817     -4.2226108908653259e-01
    z[4,5,0]  R1818     3.5937055945396423e-01
    z[4,5,0]  R1819     -6.2501597404479980e-01
    z[4,5,0]  R1820     -8.5845166444778442e-01
    z[4,5,0]  R1821     -8.0257123708724976e-01
    z[4,5,0]  R1822     5.3197562694549561e-01
    z[4,5,0]  R1823     -0.451295405626297
    z[4,5,0]  R1824     1.1656672693789005e-02
    z[4,5,0]  R1825     -1.8033067882061005e-01
    z[4,5,0]  R1826     3.9501029253005981e-01
    z[4,5,0]  R1827     -8.9244616031646729e-01
    z[4,5,0]  R1828     -9.4487506151199341e-01
    z[4,5,0]  R1829     4.1145300865173340e-01
    z[4,5,0]  R1830     -7.8592562675476074e-01
    z[4,5,0]  R1831     -8.4297996759414673e-01
    z[4,5,0]  R1832     8.0484122037887573e-01
    z[4,5,0]  R1833     6.7473107576370239e-01
    z[4,5,0]  R1834     -1.7581452429294586e-01
    z[4,5,0]  R1835     -5.6763684749603271e-01
    z[4,5,0]  R1836     3.8825148344039917e-01
    z[4,5,0]  R1837     -8.9772361516952515e-01
    z[4,5,0]  R1838     -9.2428743839263916e-01
    z[4,5,0]  R1839     0.092893086373806
    z[4,5,0]  R1840     7.4307754635810852e-02
    z[4,5,0]  R1841     0.00360292661935091
    z[4,5,0]  R1842     5.5153167247772217e-01
    z[4,5,0]  R1843     4.4846823811531067e-01
    z[4,5,0]  R1844     6.7341423034667969e-01
    z[4,5,0]  R1845     1.3346501626074314e-02
    z[4,5,0]  R1846     -1.4611147344112396e-01
    z[4,5,0]  R1847     1.4871416985988617e-01
    z[4,5,0]  R1848     -5.1569759845733643e-01
    z[4,5,0]  R1849     4.4647574424743652e-01
    z[4,5,0]  R1850     -8.4457063674926758e-01
    z[4,5,0]  R1851     2.1097144484519958e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1690     -1
    z[4,5,1]  R1691     1
    z[4,5,1]  R1702     -7.5980699062347412e-01
    z[4,5,1]  R1703     5.7655000686645508e-01
    z[4,5,1]  R1704     3.6562508344650269e-01
    z[4,5,1]  R1705     5.0436949729919434e-01
    z[4,5,1]  R1706     3.5136339068412781e-01
    z[4,5,1]  R1707     3.3590036630630493e-01
    z[4,5,1]  R1708     3.6449325084686279e-01
    z[4,5,1]  R1709     2.8012299537658691e-01
    z[4,5,1]  R1710     3.7272053956985474e-01
    z[4,5,1]  R1711     -8.8489063084125519e-02
    z[4,5,1]  R1712     3.6328908801078796e-01
    z[4,5,1]  R1713     -2.6171383261680603e-01
    z[4,5,1]  R1714     1.7946556210517883e-01
    z[4,5,1]  R1715     -1.1190539598464966e-01
    z[4,5,1]  R1716     -2.1723881363868713e-03
    z[4,5,1]  R1717     2.4210011959075928e-01
    z[4,5,1]  R1718     -4.1312709450721741e-01
    z[4,5,1]  R1719     2.6052770018577576e-01
    z[4,5,1]  R1720     -7.6499587297439575e-01
    z[4,5,1]  R1721     -8.0215257406234741e-01
    z[4,5,1]  R1722     -6.0057377815246582e-01
    z[4,5,1]  R1723     -6.4692658185958862e-01
    z[4,5,1]  R1724     9.0139198303222656e-01
    z[4,5,1]  R1725     -5.3246569633483887e-01
    z[4,5,1]  R1726     -6.7894893884658813e-01
    z[4,5,1]  R1727     8.1930369138717651e-01
    z[4,5,1]  R1728     7.5480204820632935e-01
    z[4,5,1]  R1729     -5.7989561557769775e-01
    z[4,5,1]  R1730     7.5166279077529907e-01
    z[4,5,1]  R1731     7.2597855329513550e-01
    z[4,5,1]  R1732     -0.900971531867981
    z[4,5,1]  R1733     3.5553914308547974e-01
    z[4,5,1]  R1734     3.0239078402519226e-01
    z[4,5,1]  R1735     7.8953355550765991e-01
    z[4,5,1]  R1736     1.0615737736225128e-01
    z[4,5,1]  R1737     -0.314377099275589
    z[4,5,1]  R1738     -1.5062569081783295e-01
    z[4,5,1]  R1739     -1.0727320611476898e-01
    z[4,5,1]  R1740     -3.8941238075494766e-02
    z[4,5,1]  R1741     0.0747273862361908
    z[4,5,1]  R1742     6.7456549406051636e-01
    z[4,5,1]  R1743     4.9455105327069759e-03
    z[4,5,1]  R1744     -4.4741186499595642e-01
    z[4,5,1]  R1745     -4.7400176525115967e-01
    z[4,5,1]  R1746     6.2695342302322388e-01
    z[4,5,1]  R1747     -1.0745301097631454e-01
    z[4,5,1]  R1748     -8.1280374526977539e-01
    z[4,5,1]  R1749     -7.5216662883758545e-01
    z[4,5,1]  R1750     -7.0853632688522339e-01
    z[4,5,1]  R1751     -7.3085999488830566e-01
    z[4,5,1]  R1752     -1.8043406307697296e-02
    z[4,5,1]  R1753     9.9392943084239960e-02
    z[4,5,1]  R1754     -6.2044060230255127e-01
    z[4,5,1]  R1755     1.7024628818035126e-01
    z[4,5,1]  R1756     -3.3160951733589172e-01
    z[4,5,1]  R1757     -6.8393266201019287e-01
    z[4,5,1]  R1758     -8.8236892223358154e-01
    z[4,5,1]  R1759     -8.0494534969329834e-01
    z[4,5,1]  R1760     -7.3241299390792847e-01
    z[4,5,1]  R1761     -7.4001210927963257e-01
    z[4,5,1]  R1762     8.2478791475296021e-01
    z[4,5,1]  R1763     -5.0706952810287476e-01
    z[4,5,1]  R1764     -8.8635720312595367e-02
    z[4,5,1]  R1765     -5.9026145935058594e-01
    z[4,5,1]  R1766     -4.6090030670166016e-01
    z[4,5,1]  R1767     -8.1325441598892212e-01
    z[4,5,1]  R1768     -8.2056128978729248e-01
    z[4,5,1]  R1769     -7.8597873449325562e-01
    z[4,5,1]  R1770     -0.0318484753370285
    z[4,5,1]  R1771     -3.4133437275886536e-01
    z[4,5,1]  R1772     -4.9273166060447693e-01
    z[4,5,1]  R1773     6.4521151781082153e-01
    z[4,5,1]  R1774     -1.0454971343278885e-01
    z[4,5,1]  R1775     2.5759446620941162e-01
    z[4,5,1]  R1776     -1.0024883598089218e-01
    z[4,5,1]  R1777     6.7785056307911873e-03
    z[4,5,1]  R1778     8.4484659135341644e-02
    z[4,5,1]  R1779     -4.8546131700277328e-02
    z[4,5,1]  R1780     1.1268686503171921e-01
    z[4,5,1]  R1781     -0.0511755645275116
    z[4,5,1]  R1782     -1.7011912167072296e-01
    z[4,5,1]  R1783     -8.6639535427093506e-01
    z[4,5,1]  R1784     -3.2488226890563965e-01
    z[4,5,1]  R1785     1.2755459547042847e-01
    z[4,5,1]  R1786     2.5161633267998695e-02
    z[4,5,1]  R1787     7.1684432029724121e-01
    z[4,5,1]  R1788     6.4251607656478882e-01
    z[4,5,1]  R1789     8.6258381605148315e-01
    z[4,5,1]  R1790     6.1642372608184814e-01
    z[4,5,1]  R1791     5.8614504337310791e-01
    z[4,5,1]  R1792     4.1367597877979279e-02
    z[4,5,1]  R1793     -4.5734432339668274e-01
    z[4,5,1]  R1794     5.3213047981262207e-01
    z[4,5,1]  R1795     6.7137241363525391e-01
    z[4,5,1]  R1796     -1.1954019963741302e-01
    z[4,5,1]  R1797     5.8716768026351929e-01
    z[4,5,1]  R1798     5.6276440620422363e-01
    z[4,5,1]  R1799     6.0371154546737671e-01
    z[4,5,1]  R1800     5.2918326854705811e-01
    z[4,5,1]  R1801     -1.8518170714378357e-01
    z[4,5,1]  R1802     -6.4127451181411743e-01
    z[4,5,1]  R1803     -7.6162025332450867e-02
    z[4,5,1]  R1804     -1.2833869457244873e-01
    z[4,5,1]  R1805     3.6129736900329590e-01
    z[4,5,1]  R1806     1.2361064553260803e-01
    z[4,5,1]  R1807     3.2340753078460693e-01
    z[4,5,1]  R1808     3.2106035947799683e-01
    z[4,5,1]  R1809     4.2450046539306641e-01
    z[4,5,1]  R1810     -7.9346306622028351e-02
    z[4,5,1]  R1811     6.7537516355514526e-01
    z[4,5,1]  R1812     -6.3041225075721741e-02
    z[4,5,1]  R1813     -3.1974253058433533e-01
    z[4,5,1]  R1814     -1.6818445920944214e-01
    z[4,5,1]  R1815     0.717118501663208
    z[4,5,1]  R1816     6.3430160284042358e-01
    z[4,5,1]  R1817     7.5796818733215332e-01
    z[4,5,1]  R1818     0.55787593126297
    z[4,5,1]  R1819     5.8910822868347168e-01
    z[4,5,1]  R1820     -1.9215551018714905e-01
    z[4,5,1]  R1821     -1.7271377146244049e-01
    z[4,5,1]  R1822     -2.1072624251246452e-02
    z[4,5,1]  R1823     5.2754455804824829e-01
    z[4,5,1]  R1824     8.9360141754150391e-01
    z[4,5,1]  R1825     5.8269160985946655e-01
    z[4,5,1]  R1826     4.3497118353843689e-01
    z[4,5,1]  R1827     -2.5367984175682068e-01
    z[4,5,1]  R1828     -2.0710146427154541e-01
    z[4,5,1]  R1829     6.7916643619537354e-01
    z[4,5,1]  R1830     -1.5099413692951202e-01
    z[4,5,1]  R1831     -2.0377218723297119e-01
    z[4,5,1]  R1832     -1.9711072742938995e-01
    z[4,5,1]  R1833     -5.8636730909347534e-01
    z[4,5,1]  R1834     4.9011856317520142e-01
    z[4,5,1]  R1835     6.4338010549545288e-01
    z[4,5,1]  R1836     5.1117801666259766e-01
    z[4,5,1]  R1837     -2.8135138750076294e-01
    z[4,5,1]  R1838     -9.9034756422042847e-02
    z[4,5,1]  R1839     6.2226468324661255e-01
    z[4,5,1]  R1840     0.603766918182373
    z[4,5,1]  R1841     3.4518954157829285e-01
    z[4,5,1]  R1842     -2.0193326473236084e-01
    z[4,5,1]  R1843     2.3295342922210693e-01
    z[4,5,1]  R1844     -2.8062483668327332e-01
    z[4,5,1]  R1845     -0.732764482498169
    z[4,5,1]  R1846     4.3333226442337036e-01
    z[4,5,1]  R1847     -4.5113921165466309e-01
    z[4,5,1]  R1848     7.9712599515914917e-01
    z[4,5,1]  R1849     5.5384212732315063e-01
    z[4,5,1]  R1850     -3.7367174029350281e-01
    z[4,5,1]  R1851     5.1363587379455566e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1692     -1
    z[4,5,2]  R1693     1
    z[4,5,2]  R1702     4.2846021056175232e-01
    z[4,5,2]  R1703     4.7197285294532776e-01
    z[4,5,2]  R1704     8.7361693382263184e-01
    z[4,5,2]  R1705     7.1127218008041382e-01
    z[4,5,2]  R1706     8.0955666303634644e-01
    z[4,5,2]  R1707     5.6911766529083252e-01
    z[4,5,2]  R1708     4.0934070944786072e-01
    z[4,5,2]  R1709     7.1070623397827148e-01
    z[4,5,2]  R1710     5.7346224784851074e-01
    z[4,5,2]  R1711     7.3634207248687744e-01
    z[4,5,2]  R1712     1.9641520082950592e-01
    z[4,5,2]  R1713     -1.2724100053310394e-01
    z[4,5,2]  R1714     0.371624618768692
    z[4,5,2]  R1715     -9.8497465252876282e-02
    z[4,5,2]  R1716     -4.4014319777488708e-02
    z[4,5,2]  R1717     -7.1682795882225037e-02
    z[4,5,2]  R1718     -1.1576101183891296e-01
    z[4,5,2]  R1719     -1.6678930819034576e-01
    z[4,5,2]  R1720     -3.3565798401832581e-01
    z[4,5,2]  R1721     -1.0911931097507477e-01
    z[4,5,2]  R1722     -9.6833752468228340e-03
    z[4,5,2]  R1723     -5.0400024652481079e-01
    z[4,5,2]  R1724     -2.5089514255523682e-01
    z[4,5,2]  R1725     -5.4853504896163940e-01
    z[4,5,2]  R1726     -1.8029215931892395e-01
    z[4,5,2]  R1727     -1.6667243838310242e-01
    z[4,5,2]  R1728     -4.2241996526718140e-01
    z[4,5,2]  R1729     -3.4912031888961792e-01
    z[4,5,2]  R1730     -3.4621769189834595e-01
    z[4,5,2]  R1731     -3.2184126973152161e-01
    z[4,5,2]  R1732     -1.1219297349452972e-01
    z[4,5,2]  R1733     5.5161285400390625e-01
    z[4,5,2]  R1734     4.4495663046836853e-01
    z[4,5,2]  R1735     0.0851961150765419
    z[4,5,2]  R1736     8.0610948801040649e-01
    z[4,5,2]  R1737     5.7804727554321289e-01
    z[4,5,2]  R1738     3.2496452331542969e-02
    z[4,5,2]  R1739     -4.9097468145191669e-03
    z[4,5,2]  R1740     -1.1313035339117050e-01
    z[4,5,2]  R1741     -2.0541571080684662e-01
    z[4,5,2]  R1742     2.0228993892669678e-01
    z[4,5,2]  R1743     0.352448970079422
    z[4,5,2]  R1744     1.8935729563236237e-01
    z[4,5,2]  R1745     0.316108375787735
    z[4,5,2]  R1746     2.9753330349922180e-01
    z[4,5,2]  R1747     1.9822779297828674e-01
    z[4,5,2]  R1748     5.1628995686769485e-02
    z[4,5,2]  R1749     -4.0192636847496033e-01
    z[4,5,2]  R1750     -4.1487923264503479e-01
    z[4,5,2]  R1751     -3.2615345716476440e-01
    z[4,5,2]  R1752     4.5415255427360535e-01
    z[4,5,2]  R1753     2.1178849041461945e-01
    z[4,5,2]  R1754     3.1848031282424927e-01
    z[4,5,2]  R1755     2.0725689828395844e-01
    z[4,5,2]  R1756     -2.5462964177131653e-01
    z[4,5,2]  R1757     9.5716238021850586e-02
    z[4,5,2]  R1758     -1.0808206349611282e-01
    z[4,5,2]  R1759     -2.2758223116397858e-01
    z[4,5,2]  R1760     -3.3036249876022339e-01
    z[4,5,2]  R1761     -4.9515508115291595e-02
    z[4,5,2]  R1762     3.7481376528739929e-01
    z[4,5,2]  R1763     8.0753460526466370e-02
    z[4,5,2]  R1764     5.3348565101623535e-01
    z[4,5,2]  R1765     4.6799808740615845e-01
    z[4,5,2]  R1766     -3.8040125370025635e-01
    z[4,5,2]  R1767     -2.5340586900711060e-01
    z[4,5,2]  R1768     -3.2903066277503967e-01
    z[4,5,2]  R1769     -4.6661749482154846e-01
    z[4,5,2]  R1770     1.2670126557350159e-01
    z[4,5,2]  R1771     -9.6945315599441528e-02
    z[4,5,2]  R1772     6.2912482023239136e-01
    z[4,5,2]  R1773     4.5185607671737671e-01
    z[4,5,2]  R1774     6.8789505958557129e-01
    z[4,5,2]  R1775     4.1986843943595886e-01
    z[4,5,2]  R1776     -5.8373087644577026e-01
    z[4,5,2]  R1777     -5.1679015159606934e-01
    z[4,5,2]  R1778     -0.415141761302948
    z[4,5,2]  R1779     -3.8516268134117126e-01
    z[4,5,2]  R1780     -1.2402106076478958e-01
    z[4,5,2]  R1781     -5.1551944017410278e-01
    z[4,5,2]  R1782     -4.4515646994113922e-02
    z[4,5,2]  R1783     -6.7482399754226208e-03
    z[4,5,2]  R1784     3.0095195770263672e-01
    z[4,5,2]  R1785     -1.4778596162796021e-01
    z[4,5,2]  R1786     -2.0170383155345917e-01
    z[4,5,2]  R1787     2.2534139454364777e-01
    z[4,5,2]  R1788     2.0300704240798950e-01
    z[4,5,2]  R1789     3.9781138300895691e-02
    z[4,5,2]  R1790     1.1528802663087845e-01
    z[4,5,2]  R1791     1.4067694544792175e-01
    z[4,5,2]  R1792     -2.7100220322608948e-01
    z[4,5,2]  R1793     1.5467441082000732e-01
    z[4,5,2]  R1794     1.6633830964565277e-01
    z[4,5,2]  R1795     5.3234919905662537e-02
    z[4,5,2]  R1796     7.6274409890174866e-02
    z[4,5,2]  R1797     1.8836699426174164e-01
    z[4,5,2]  R1798     9.8673895001411438e-02
    z[4,5,2]  R1799     2.5525781512260437e-01
    z[4,5,2]  R1800     4.3276599049568176e-01
    z[4,5,2]  R1801     -0.0498683899641037
    z[4,5,2]  R1802     -7.8489862382411957e-02
    z[4,5,2]  R1803     -5.3640075027942657e-02
    z[4,5,2]  R1804     2.6360502839088440e-01
    z[4,5,2]  R1805     -0.015627421438694
    z[4,5,2]  R1806     8.6594857275485992e-02
    z[4,5,2]  R1807     2.0107630640268326e-02
    z[4,5,2]  R1808     1.3167257606983185e-01
    z[4,5,2]  R1809     2.3699508607387543e-01
    z[4,5,2]  R1810     1.5364913642406464e-01
    z[4,5,2]  R1811     9.4399198889732361e-02
    z[4,5,2]  R1812     1.7879419028759003e-01
    z[4,5,2]  R1813     2.7754855155944824e-01
    z[4,5,2]  R1814     2.4555955827236176e-01
    z[4,5,2]  R1815     1.0720190405845642e-01
    z[4,5,2]  R1816     3.3301401138305664e-01
    z[4,5,2]  R1817     -1.0970806330442429e-01
    z[4,5,2]  R1818     6.7490625381469727e-01
    z[4,5,2]  R1819     -2.3787726461887360e-01
    z[4,5,2]  R1820     -1.8049703538417816e-01
    z[4,5,2]  R1821     -1.7838594317436218e-01
    z[4,5,2]  R1822     1.4784198999404907e-01
    z[4,5,2]  R1823     -6.0977645218372345e-02
    z[4,5,2]  R1824     3.1624818220734596e-03
    z[4,5,2]  R1825     9.3205235898494720e-02
    z[4,5,2]  R1826     5.4300391674041748e-01
    z[4,5,2]  R1827     -2.6401841640472412e-01
    z[4,5,2]  R1828     -1.2462133914232254e-01
    z[4,5,2]  R1829     -1.3151612877845764e-01
    z[4,5,2]  R1830     -1.8843559920787811e-01
    z[4,5,2]  R1831     -2.3226018249988556e-01
    z[4,5,2]  R1832     2.9141888022422791e-01
    z[4,5,2]  R1833     2.0411417353898287e-03
    z[4,5,2]  R1834     1.5482509136199951e-01
    z[4,5,2]  R1835     -3.1458556652069092e-01
    z[4,5,2]  R1836     6.1313390731811523e-01
    z[4,5,2]  R1837     -1.8113890290260315e-01
    z[4,5,2]  R1838     -2.2429031133651733e-01
    z[4,5,2]  R1839     0.0309981070458889
    z[4,5,2]  R1840     -1.3802379369735718e-02
    z[4,5,2]  R1841     -6.5438352525234222e-02
    z[4,5,2]  R1842     2.1384723484516144e-02
    z[4,5,2]  R1843     -5.4391520097851753e-03
    z[4,5,2]  R1844     1.1843720823526382e-01
    z[4,5,2]  R1845     5.1741704344749451e-02
    z[4,5,2]  R1846     -7.8318662941455841e-02
    z[4,5,2]  R1847     -4.4125726819038391e-01
    z[4,5,2]  R1848     -1.6930712759494781e-01
    z[4,5,2]  R1849     0.553565502166748
    z[4,5,2]  R1850     -2.5422206521034241e-01
    z[4,5,2]  R1851     -7.4339248239994049e-02
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1694     -1
    z[4,5,3]  R1695     1
    z[4,5,3]  R1702     -1.1365080624818802e-01
    z[4,5,3]  R1703     -2.6653057336807251e-01
    z[4,5,3]  R1704     -1.6158398240804672e-02
    z[4,5,3]  R1705     8.7386779487133026e-02
    z[4,5,3]  R1706     -2.4195969104766846e-01
    z[4,5,3]  R1707     -5.4229967296123505e-02
    z[4,5,3]  R1708     -2.1973271667957306e-01
    z[4,5,3]  R1709     -2.1441173553466797e-01
    z[4,5,3]  R1710     -4.2974729090929031e-02
    z[4,5,3]  R1711     6.2710449099540710e-02
    z[4,5,3]  R1712     1.4789845049381256e-01
    z[4,5,3]  R1713     0.0894770473241806
    z[4,5,3]  R1714     3.9945179224014282e-01
    z[4,5,3]  R1715     8.7021932005882263e-02
    z[4,5,3]  R1716     2.2188428044319153e-01
    z[4,5,3]  R1717     5.1621246337890625e-01
    z[4,5,3]  R1718     -2.7530366182327271e-01
    z[4,5,3]  R1719     1.9655907154083252e-01
    z[4,5,3]  R1720     1.9867390394210815e-01
    z[4,5,3]  R1721     3.1789278984069824e-01
    z[4,5,3]  R1722     -4.6466785669326782e-01
    z[4,5,3]  R1723     5.3142286837100983e-02
    z[4,5,3]  R1724     -1.5477515757083893e-01
    z[4,5,3]  R1725     1.5464648604393005e-01
    z[4,5,3]  R1726     8.9399078860878944e-03
    z[4,5,3]  R1727     -2.6493254303932190e-01
    z[4,5,3]  R1728     -2.5016868114471436e-01
    z[4,5,3]  R1729     3.1325221061706543e-01
    z[4,5,3]  R1730     5.5311530828475952e-02
    z[4,5,3]  R1731     -3.7594158202409744e-02
    z[4,5,3]  R1732     -2.2050699591636658e-01
    z[4,5,3]  R1733     2.3014302551746368e-01
    z[4,5,3]  R1734     3.7489798665046692e-01
    z[4,5,3]  R1735     1.4491407573223114e-01
    z[4,5,3]  R1736     -1.3750021345913410e-02
    z[4,5,3]  R1737     2.0133394747972488e-02
    z[4,5,3]  R1738     -3.9063658565282822e-02
    z[4,5,3]  R1739     3.6451440304517746e-02
    z[4,5,3]  R1740     2.4458234012126923e-01
    z[4,5,3]  R1741     2.4195723235607147e-01
    z[4,5,3]  R1742     1.6079044342041016e-01
    z[4,5,3]  R1743     -2.1304486691951752e-01
    z[4,5,3]  R1744     5.1672559976577759e-01
    z[4,5,3]  R1745     1.3092531263828278e-01
    z[4,5,3]  R1746     6.0761805623769760e-02
    z[4,5,3]  R1747     -1.6981713473796844e-02
    z[4,5,3]  R1748     8.4242507815361023e-02
    z[4,5,3]  R1749     -4.7782354056835175e-02
    z[4,5,3]  R1750     -3.9128664880990982e-02
    z[4,5,3]  R1751     2.5848546624183655e-01
    z[4,5,3]  R1752     0.193464457988739
    z[4,5,3]  R1753     -5.1578204147517681e-03
    z[4,5,3]  R1754     -2.1298509091138840e-02
    z[4,5,3]  R1755     3.7492990493774414e-01
    z[4,5,3]  R1756     4.2187440395355225e-01
    z[4,5,3]  R1757     2.2648863494396210e-01
    z[4,5,3]  R1758     -1.3462702045217156e-03
    z[4,5,3]  R1759     1.5759870409965515e-01
    z[4,5,3]  R1760     3.5399022698402405e-01
    z[4,5,3]  R1761     2.3068022727966309e-01
    z[4,5,3]  R1762     -1.2059453874826431e-01
    z[4,5,3]  R1763     4.1977667808532715e-01
    z[4,5,3]  R1764     1.2259480357170105e-01
    z[4,5,3]  R1765     -1.3393211364746094e-01
    z[4,5,3]  R1766     1.0628718882799149e-01
    z[4,5,3]  R1767     3.2748955488204956e-01
    z[4,5,3]  R1768     1.0601244121789932e-01
    z[4,5,3]  R1769     -4.3967794626951218e-02
    z[4,5,3]  R1770     8.8841117918491364e-02
    z[4,5,3]  R1771     3.3085581660270691e-01
    z[4,5,3]  R1772     2.6332038640975952e-01
    z[4,5,3]  R1773     1.8129470944404602e-01
    z[4,5,3]  R1774     1.5514270961284637e-01
    z[4,5,3]  R1775     1.6484937071800232e-01
    z[4,5,3]  R1776     -1.1773931980133057e-01
    z[4,5,3]  R1777     -2.8462055325508118e-01
    z[4,5,3]  R1778     -2.1530902385711670e-01
    z[4,5,3]  R1779     -3.1624028086662292e-01
    z[4,5,3]  R1780     6.2884055078029633e-02
    z[4,5,3]  R1781     -2.1473422646522522e-02
    z[4,5,3]  R1782     7.3701679706573486e-01
    z[4,5,3]  R1783     -2.5402450561523438e-01
    z[4,5,3]  R1784     4.9658772349357605e-01
    z[4,5,3]  R1785     6.9725221395492554e-01
    z[4,5,3]  R1786     3.9002344012260437e-01
    z[4,5,3]  R1787     3.8173970580101013e-01
    z[4,5,3]  R1788     4.8316952586174011e-01
    z[4,5,3]  R1789     2.3315073549747467e-01
    z[4,5,3]  R1790     5.0997787714004517e-01
    z[4,5,3]  R1791     5.1632338762283325e-01
    z[4,5,3]  R1792     -4.0670718997716904e-02
    z[4,5,3]  R1793     -2.7080744504928589e-01
    z[4,5,3]  R1794     0.29147869348526
    z[4,5,3]  R1795     -1.2598313391208649e-01
    z[4,5,3]  R1796     -2.4649222195148468e-01
    z[4,5,3]  R1797     -3.7062340974807739e-01
    z[4,5,3]  R1798     -2.8882077336311340e-01
    z[4,5,3]  R1799     -4.2581576108932495e-01
    z[4,5,3]  R1800     -2.8204908967018127e-01
    z[4,5,3]  R1801     -2.2921943664550781e-01
    z[4,5,3]  R1802     4.6231511235237122e-01
    z[4,5,3]  R1803     5.7530981302261353e-01
    z[4,5,3]  R1804     -3.0505027621984482e-02
    z[4,5,3]  R1805     0.747157871723175
    z[4,5,3]  R1806     6.8595755100250244e-01
    z[4,5,3]  R1807     0.518020510673523
    z[4,5,3]  R1808     4.2831945419311523e-01
    z[4,5,3]  R1809     2.5988447666168213e-01
    z[4,5,3]  R1810     1.5684854984283447e-01
    z[4,5,3]  R1811     4.8331776261329651e-01
    z[4,5,3]  R1812     6.0230517387390137e-01
    z[4,5,3]  R1813     0.170273557305336
    z[4,5,3]  R1814     0.139985129237175
    z[4,5,3]  R1815     4.7819033265113831e-01
    z[4,5,3]  R1816     -1.2592312693595886e-01
    z[4,5,3]  R1817     7.7215313911437988e-02
    z[4,5,3]  R1818     -1.8931412696838379e-01
    z[4,5,3]  R1819     -3.3788260817527771e-01
    z[4,5,3]  R1820     2.4014195799827576e-01
    z[4,5,3]  R1821     -0.408211886882782
    z[4,5,3]  R1822     -1.3090525567531586e-01
    z[4,5,3]  R1823     5.7941854000091553e-01
    z[4,5,3]  R1824     2.6890572905540466e-01
    z[4,5,3]  R1825     4.4059857726097107e-01
    z[4,5,3]  R1826     3.4857034683227539e-02
    z[4,5,3]  R1827     2.7813278138637543e-02
    z[4,5,3]  R1828     0.123990997672081
    z[4,5,3]  R1829     -4.2569947242736816e-01
    z[4,5,3]  R1830     8.7250366806983948e-02
    z[4,5,3]  R1831     3.5420853644609451e-02
    z[4,5,3]  R1832     -2.3585051298141479e-01
    z[4,5,3]  R1833     9.0801984071731567e-02
    z[4,5,3]  R1834     4.4118198752403259e-01
    z[4,5,3]  R1835     0.0428534559905529
    z[4,5,3]  R1836     2.3797746002674103e-01
    z[4,5,3]  R1837     -3.7355388049036264e-03
    z[4,5,3]  R1838     -2.3232486844062805e-01
    z[4,5,3]  R1839     -0.715779185295105
    z[4,5,3]  R1840     -7.7900612354278564e-01
    z[4,5,3]  R1841     -0.923267126083374
    z[4,5,3]  R1842     6.0994488000869751e-01
    z[4,5,3]  R1843     7.4652409553527832e-01
    z[4,5,3]  R1844     -1.1623510718345642e-01
    z[4,5,3]  R1845     -0.557176411151886
    z[4,5,3]  R1846     8.3671528100967407e-01
    z[4,5,3]  R1847     5.7553607970476151e-02
    z[4,5,3]  R1848     2.1857085824012756e-01
    z[4,5,3]  R1849     -9.8399199545383453e-02
    z[4,5,3]  R1850     2.3236854374408722e-01
    z[4,5,3]  R1851     -7.4198341369628906e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1696     -1
    z[4,5,4]  R1697     1
    z[4,5,4]  R1702     -8.0058827996253967e-02
    z[4,5,4]  R1703     -3.2889395952224731e-01
    z[4,5,4]  R1704     1.6888274252414703e-01
    z[4,5,4]  R1705     3.0916187912225723e-02
    z[4,5,4]  R1706     6.0891564935445786e-02
    z[4,5,4]  R1707     -7.6807349920272827e-02
    z[4,5,4]  R1708     2.4496786296367645e-01
    z[4,5,4]  R1709     -2.2143848240375519e-01
    z[4,5,4]  R1710     -4.8559615015983582e-01
    z[4,5,4]  R1711     1.0496097803115845e-01
    z[4,5,4]  R1712     4.4029909372329712e-01
    z[4,5,4]  R1713     2.6183375716209412e-01
    z[4,5,4]  R1714     4.5810022950172424e-01
    z[4,5,4]  R1715     2.1041291952133179e-01
    z[4,5,4]  R1716     3.3806860446929932e-01
    z[4,5,4]  R1717     3.3798319101333618e-01
    z[4,5,4]  R1718     -1.4776277542114258e-01
    z[4,5,4]  R1719     3.2203400135040283e-01
    z[4,5,4]  R1720     2.7713969349861145e-01
    z[4,5,4]  R1721     3.3040383458137512e-01
    z[4,5,4]  R1722     0.390125036239624
    z[4,5,4]  R1723     -2.9339954257011414e-01
    z[4,5,4]  R1724     1.7583616077899933e-02
    z[4,5,4]  R1725     -3.6412519216537476e-01
    z[4,5,4]  R1726     -3.0620199441909790e-01
    z[4,5,4]  R1727     2.9648987576365471e-02
    z[4,5,4]  R1728     -1.4477708935737610e-01
    z[4,5,4]  R1729     1.4104658365249634e-01
    z[4,5,4]  R1730     4.3017297983169556e-01
    z[4,5,4]  R1731     -4.6514311432838440e-01
    z[4,5,4]  R1732     -6.4739942550659180e-02
    z[4,5,4]  R1733     2.5175625085830688e-01
    z[4,5,4]  R1734     7.0959888398647308e-02
    z[4,5,4]  R1735     1.3857199251651764e-01
    z[4,5,4]  R1736     4.2542789131402969e-02
    z[4,5,4]  R1737     1.5082585811614990e-01
    z[4,5,4]  R1738     -2.6541644334793091e-01
    z[4,5,4]  R1739     -6.5167438983917236e-01
    z[4,5,4]  R1740     -2.3809868097305298e-01
    z[4,5,4]  R1741     -0.270989328622818
    z[4,5,4]  R1742     -1.4751519262790680e-01
    z[4,5,4]  R1743     -1.9519133493304253e-02
    z[4,5,4]  R1744     6.2137889862060547e-01
    z[4,5,4]  R1745     0.0629318356513977
    z[4,5,4]  R1746     7.0032423734664917e-01
    z[4,5,4]  R1747     -2.3135535418987274e-01
    z[4,5,4]  R1748     4.7309298068284988e-02
    z[4,5,4]  R1749     -5.1250267028808594e-01
    z[4,5,4]  R1750     -4.1086863726377487e-02
    z[4,5,4]  R1751     -3.5745996236801147e-01
    z[4,5,4]  R1752     5.9184902906417847e-01
    z[4,5,4]  R1753     -5.3945183753967285e-01
    z[4,5,4]  R1754     2.9631805419921875e-01
    z[4,5,4]  R1755     5.0382214784622192e-01
    z[4,5,4]  R1756     0.403598815202713
    z[4,5,4]  R1757     -3.8055527955293655e-02
    z[4,5,4]  R1758     -6.3370861113071442e-02
    z[4,5,4]  R1759     -2.5565892457962036e-01
    z[4,5,4]  R1760     -1.9228948652744293e-01
    z[4,5,4]  R1761     -4.3697637319564819e-01
    z[4,5,4]  R1762     -1.7640747129917145e-01
    z[4,5,4]  R1763     4.3317991495132446e-01
    z[4,5,4]  R1764     2.0805180072784424e-01
    z[4,5,4]  R1765     -3.6709362268447876e-01
    z[4,5,4]  R1766     -6.5922670066356659e-02
    z[4,5,4]  R1767     -1.8420684337615967e-01
    z[4,5,4]  R1768     -1.3740763068199158e-01
    z[4,5,4]  R1769     -3.3324441313743591e-01
    z[4,5,4]  R1770     2.2193701565265656e-01
    z[4,5,4]  R1771     4.1295105218887329e-01
    z[4,5,4]  R1772     3.7466433644294739e-01
    z[4,5,4]  R1773     2.1136064827442169e-01
    z[4,5,4]  R1774     -1.1301765590906143e-01
    z[4,5,4]  R1775     -7.4604131281375885e-02
    z[4,5,4]  R1776     -1.2201914936304092e-01
    z[4,5,4]  R1777     -2.5154781341552734e-01
    z[4,5,4]  R1778     2.3446790874004364e-02
    z[4,5,4]  R1779     -4.3253622949123383e-02
    z[4,5,4]  R1780     -7.5459247827529907e-01
    z[4,5,4]  R1781     -2.3766717314720154e-01
    z[4,5,4]  R1782     -4.9649411439895630e-01
    z[4,5,4]  R1783     1.1810000985860825e-01
    z[4,5,4]  R1784     1.3310475647449493e-01
    z[4,5,4]  R1785     8.4359832108020782e-02
    z[4,5,4]  R1786     -4.6351256966590881e-01
    z[4,5,4]  R1787     3.5189583897590637e-02
    z[4,5,4]  R1788     -4.7536338679492474e-03
    z[4,5,4]  R1789     -3.2184287905693054e-01
    z[4,5,4]  R1790     -2.9385346174240112e-01
    z[4,5,4]  R1791     1.8281698226928711e-01
    z[4,5,4]  R1792     3.9884322881698608e-01
    z[4,5,4]  R1793     -2.9343074560165405e-01
    z[4,5,4]  R1794     3.8863825798034668e-01
    z[4,5,4]  R1795     2.7067816257476807e-01
    z[4,5,4]  R1796     4.4900488853454590e-01
    z[4,5,4]  R1797     -8.3619825541973114e-02
    z[4,5,4]  R1798     -2.3037960752844810e-02
    z[4,5,4]  R1799     3.0328243970870972e-01
    z[4,5,4]  R1800     3.40327387675643e-05
    z[4,5,4]  R1801     -3.4083715081214905e-01
    z[4,5,4]  R1802     -7.6309517025947571e-02
    z[4,5,4]  R1803     5.1374042034149170e-01
    z[4,5,4]  R1804     7.8781759738922119e-01
    z[4,5,4]  R1805     4.6057271957397461e-01
    z[4,5,4]  R1806     5.6694155931472778e-01
    z[4,5,4]  R1807     -2.1398362517356873e-01
    z[4,5,4]  R1808     4.3669030070304871e-01
    z[4,5,4]  R1809     1.5598259866237640e-01
    z[4,5,4]  R1810     3.8553100824356079e-01
    z[4,5,4]  R1811     -1.8345834314823151e-01
    z[4,5,4]  R1812     0.532383382320404
    z[4,5,4]  R1813     -4.1586235165596008e-02
    z[4,5,4]  R1814     -5.6828784942626953e-01
    z[4,5,4]  R1815     2.2176005877554417e-03
    z[4,5,4]  R1816     2.5891074538230896e-01
    z[4,5,4]  R1817     3.6979028582572937e-01
    z[4,5,4]  R1818     -1.9570612907409668e-01
    z[4,5,4]  R1819     1.4526385068893433e-01
    z[4,5,4]  R1820     -0.0417962521314621
    z[4,5,4]  R1821     -4.1301891207695007e-02
    z[4,5,4]  R1822     -3.4136778116226196e-01
    z[4,5,4]  R1823     2.4779860675334930e-01
    z[4,5,4]  R1824     1.4272421598434448e-01
    z[4,5,4]  R1825     -2.8095895051956177e-01
    z[4,5,4]  R1826     -3.1539839506149292e-01
    z[4,5,4]  R1827     2.5853142142295837e-02
    z[4,5,4]  R1828     -9.9958963692188263e-02
    z[4,5,4]  R1829     -1.9605672359466553e-01
    z[4,5,4]  R1830     -5.3230029344558716e-01
    z[4,5,4]  R1831     2.0194664597511292e-01
    z[4,5,4]  R1832     -1.1229781806468964e-01
    z[4,5,4]  R1833     6.3080765306949615e-02
    z[4,5,4]  R1834     -1.8942435085773468e-01
    z[4,5,4]  R1835     -0.02197265625
    z[4,5,4]  R1836     -3.7384482566267252e-03
    z[4,5,4]  R1837     -1.7954805493354797e-01
    z[4,5,4]  R1838     -8.7438896298408508e-02
    z[4,5,4]  R1839     -1.2091485410928726e-01
    z[4,5,4]  R1840     4.8610851168632507e-02
    z[4,5,4]  R1841     -0.0319192036986351
    z[4,5,4]  R1842     -2.9788926243782043e-01
    z[4,5,4]  R1843     -7.0884138345718384e-02
    z[4,5,4]  R1844     5.1153737306594849e-01
    z[4,5,4]  R1845     -1.3111691176891327e-01
    z[4,5,4]  R1846     2.8514513373374939e-01
    z[4,5,4]  R1847     7.4714952707290649e-01
    z[4,5,4]  R1848     -5.2574608474969864e-02
    z[4,5,4]  R1849     -7.8257076442241669e-02
    z[4,5,4]  R1850     -1.4152601361274719e-01
    z[4,5,4]  R1851     1.4653564989566803e-01
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1698     -1
    z[4,5,5]  R1699     1
    z[4,5,5]  R1702     4.3996194005012512e-01
    z[4,5,5]  R1703     1.3638377189636230e-01
    z[4,5,5]  R1704     1.2953966856002808e-01
    z[4,5,5]  R1705     -2.9613199830055237e-01
    z[4,5,5]  R1706     3.4899991750717163e-01
    z[4,5,5]  R1707     5.9517753124237061e-01
    z[4,5,5]  R1708     2.3161128163337708e-01
    z[4,5,5]  R1709     -4.0721100568771362e-01
    z[4,5,5]  R1710     -3.4148707985877991e-01
    z[4,5,5]  R1711     -3.5778522491455078e-01
    z[4,5,5]  R1712     2.3346321284770966e-01
    z[4,5,5]  R1713     2.4932387471199036e-01
    z[4,5,5]  R1714     -0.468799889087677
    z[4,5,5]  R1715     -5.3434497117996216e-01
    z[4,5,5]  R1716     -2.7919512987136841e-01
    z[4,5,5]  R1717     -1.7638374119997025e-02
    z[4,5,5]  R1718     2.4123069643974304e-01
    z[4,5,5]  R1719     4.2480829358100891e-01
    z[4,5,5]  R1720     3.2849079370498657e-01
    z[4,5,5]  R1721     4.7065045684576035e-02
    z[4,5,5]  R1722     -4.1814845800399780e-01
    z[4,5,5]  R1723     -1.1946523189544678e-01
    z[4,5,5]  R1724     2.0657652616500854e-01
    z[4,5,5]  R1725     3.6275589466094971e-01
    z[4,5,5]  R1726     -2.6349839568138123e-01
    z[4,5,5]  R1727     -2.0331963896751404e-01
    z[4,5,5]  R1728     -1.1794500052928925e-01
    z[4,5,5]  R1729     -2.4451753497123718e-01
    z[4,5,5]  R1730     -1.9577954709529877e-01
    z[4,5,5]  R1731     -1.5811967849731445e-01
    z[4,5,5]  R1732     -1.3639576733112335e-01
    z[4,5,5]  R1733     -1.7367477715015411e-01
    z[4,5,5]  R1734     -7.1926325559616089e-02
    z[4,5,5]  R1735     5.8834481984376907e-02
    z[4,5,5]  R1736     -3.8575258851051331e-01
    z[4,5,5]  R1737     1.8640126287937164e-01
    z[4,5,5]  R1738     -1.9208908081054688e-01
    z[4,5,5]  R1739     9.4959894195199013e-03
    z[4,5,5]  R1740     -4.9050965905189514e-01
    z[4,5,5]  R1741     -1.8015022575855255e-01
    z[4,5,5]  R1742     1.3386167585849762e-01
    z[4,5,5]  R1743     1.9392508268356323e-01
    z[4,5,5]  R1744     -1.4710029959678650e-01
    z[4,5,5]  R1745     3.9358285069465637e-01
    z[4,5,5]  R1746     1.0863801091909409e-01
    z[4,5,5]  R1747     2.9338070750236511e-01
    z[4,5,5]  R1748     -2.4932403862476349e-01
    z[4,5,5]  R1749     0.0312016773968935
    z[4,5,5]  R1750     -1.0448420047760010e-01
    z[4,5,5]  R1751     -2.6090928912162781e-01
    z[4,5,5]  R1752     -4.5123159885406494e-01
    z[4,5,5]  R1753     1.0680218786001205e-01
    z[4,5,5]  R1754     3.6879318952560425e-01
    z[4,5,5]  R1755     3.6878335475921631e-01
    z[4,5,5]  R1756     4.9595287442207336e-01
    z[4,5,5]  R1757     0.0912671834230423
    z[4,5,5]  R1758     -8.0275140702724457e-02
    z[4,5,5]  R1759     -4.5369642972946167e-01
    z[4,5,5]  R1760     -2.5563132762908936e-01
    z[4,5,5]  R1761     -2.3328320682048798e-01
    z[4,5,5]  R1762     -3.4196230769157410e-01
    z[4,5,5]  R1763     4.2532852292060852e-01
    z[4,5,5]  R1764     6.9031155109405518e-01
    z[4,5,5]  R1765     -1.7529079318046570e-01
    z[4,5,5]  R1766     7.0834594964981079e-01
    z[4,5,5]  R1767     -0.0642034187912941
    z[4,5,5]  R1768     -2.3047627508640289e-01
    z[4,5,5]  R1769     2.0053030550479889e-01
    z[4,5,5]  R1770     4.4623672962188721e-01
    z[4,5,5]  R1771     -5.2082806825637817e-01
    z[4,5,5]  R1772     -1.2185101397335529e-02
    z[4,5,5]  R1773     -1.5581482648849487e-01
    z[4,5,5]  R1774     1.8800030648708344e-01
    z[4,5,5]  R1775     -5.2067607641220093e-02
    z[4,5,5]  R1776     -9.7791932523250580e-02
    z[4,5,5]  R1777     -1.1437275260686874e-01
    z[4,5,5]  R1778     -4.0624892711639404e-01
    z[4,5,5]  R1779     -2.7359002828598022e-01
    z[4,5,5]  R1780     3.7848973274230957e-01
    z[4,5,5]  R1781     -4.9476027488708496e-01
    z[4,5,5]  R1782     -7.8130595386028290e-02
    z[4,5,5]  R1783     1.4234589040279388e-01
    z[4,5,5]  R1784     -3.3693760633468628e-01
    z[4,5,5]  R1785     5.5766922235488892e-01
    z[4,5,5]  R1786     6.7910814285278320e-01
    z[4,5,5]  R1787     -1.8487884104251862e-01
    z[4,5,5]  R1788     1.3950876891613007e-01
    z[4,5,5]  R1789     5.5017095059156418e-02
    z[4,5,5]  R1790     2.2003208100795746e-01
    z[4,5,5]  R1791     3.1087648868560791e-01
    z[4,5,5]  R1792     -1.1001148819923401e-01
    z[4,5,5]  R1793     8.1487350165843964e-02
    z[4,5,5]  R1794     -5.5850189924240112e-01
    z[4,5,5]  R1795     3.2151535153388977e-01
    z[4,5,5]  R1796     4.4339734315872192e-01
    z[4,5,5]  R1797     -1.7229861021041870e-01
    z[4,5,5]  R1798     1.3593678176403046e-01
    z[4,5,5]  R1799     3.6164857447147369e-02
    z[4,5,5]  R1800     2.2967378795146942e-01
    z[4,5,5]  R1801     -2.3985219001770020e-01
    z[4,5,5]  R1802     5.4262804985046387e-01
    z[4,5,5]  R1803     3.1515711545944214e-01
    z[4,5,5]  R1804     -2.7135422825813293e-01
    z[4,5,5]  R1805     -1.4030887186527252e-01
    z[4,5,5]  R1806     -2.7354758977890015e-01
    z[4,5,5]  R1807     -3.7637513875961304e-01
    z[4,5,5]  R1808     -0.635583221912384
    z[4,5,5]  R1809     -7.9247075319290161e-01
    z[4,5,5]  R1810     -5.3739106655120850e-01
    z[4,5,5]  R1811     -4.6171960234642029e-01
    z[4,5,5]  R1812     -4.7379118204116821e-01
    z[4,5,5]  R1813     -6.2867230176925659e-01
    z[4,5,5]  R1814     -4.7461655735969543e-01
    z[4,5,5]  R1815     -3.1075629591941833e-01
    z[4,5,5]  R1816     -0.0666750892996788
    z[4,5,5]  R1817     1.2726147472858429e-01
    z[4,5,5]  R1818     -1.4552277512848377e-02
    z[4,5,5]  R1819     2.5573673844337463e-01
    z[4,5,5]  R1820     -2.8836706653237343e-02
    z[4,5,5]  R1821     -3.0305409431457520e-01
    z[4,5,5]  R1822     1.4619396626949310e-01
    z[4,5,5]  R1823     8.3432635292410851e-03
    z[4,5,5]  R1824     -3.1873792409896851e-01
    z[4,5,5]  R1825     -0.412521094083786
    z[4,5,5]  R1826     3.8313734531402588e-01
    z[4,5,5]  R1827     2.5273540616035461e-01
    z[4,5,5]  R1828     -9.6924573183059692e-02
    z[4,5,5]  R1829     3.6326035857200623e-01
    z[4,5,5]  R1830     0.0503445640206337
    z[4,5,5]  R1831     9.8870471119880676e-02
    z[4,5,5]  R1832     -3.9066934585571289e-01
    z[4,5,5]  R1833     4.0133652091026306e-01
    z[4,5,5]  R1834     -5.3068125247955322e-01
    z[4,5,5]  R1835     3.6689648032188416e-01
    z[4,5,5]  R1836     3.8520210981369019e-01
    z[4,5,5]  R1837     -2.2283075749874115e-01
    z[4,5,5]  R1838     7.2753116488456726e-02
    z[4,5,5]  R1839     -6.6692255437374115e-02
    z[4,5,5]  R1840     -9.6957378089427948e-02
    z[4,5,5]  R1841     1.5190611779689789e-01
    z[4,5,5]  R1842     3.0472227931022644e-01
    z[4,5,5]  R1843     2.5635793805122375e-01
    z[4,5,5]  R1844     3.2530602812767029e-01
    z[4,5,5]  R1845     2.4582125246524811e-01
    z[4,5,5]  R1846     4.6398699283599854e-02
    z[4,5,5]  R1847     -7.9258419573307037e-02
    z[4,5,5]  R1848     -0.0792100802063942
    z[4,5,5]  R1849     2.5551852583885193e-01
    z[4,5,5]  R1850     -4.8923354595899582e-02
    z[4,5,5]  R1851     6.8519569933414459e-02
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1700     -1
    z[4,5,6]  R1701     1
    z[4,5,6]  R1702     1.2092879414558411e-01
    z[4,5,6]  R1703     -2.3068059980869293e-01
    z[4,5,6]  R1704     1.8213900923728943e-01
    z[4,5,6]  R1705     3.6324393749237061e-01
    z[4,5,6]  R1706     -1.2739732861518860e-01
    z[4,5,6]  R1707     2.5307485461235046e-01
    z[4,5,6]  R1708     -6.4232259988784790e-01
    z[4,5,6]  R1709     -3.2322937250137329e-01
    z[4,5,6]  R1710     1.9452343881130219e-01
    z[4,5,6]  R1711     -0.318782240152359
    z[4,5,6]  R1712     -6.1196070909500122e-01
    z[4,5,6]  R1713     0.0861247330904007
    z[4,5,6]  R1714     -2.1181281656026840e-02
    z[4,5,6]  R1715     -8.9917801320552826e-02
    z[4,5,6]  R1716     3.7962636351585388e-01
    z[4,5,6]  R1717     2.5793942809104919e-01
    z[4,5,6]  R1718     -1.3838969171047211e-01
    z[4,5,6]  R1719     -2.6035052537918091e-01
    z[4,5,6]  R1720     -2.1527664363384247e-01
    z[4,5,6]  R1721     -1.9274526834487915e-01
    z[4,5,6]  R1722     3.0488187074661255e-01
    z[4,5,6]  R1723     -4.4549646973609924e-01
    z[4,5,6]  R1724     1.5331450104713440e-01
    z[4,5,6]  R1725     2.4077013134956360e-01
    z[4,5,6]  R1726     -4.4894075393676758e-01
    z[4,5,6]  R1727     -9.9124290049076080e-02
    z[4,5,6]  R1728     -2.7765509486198425e-01
    z[4,5,6]  R1729     4.5793330669403076e-01
    z[4,5,6]  R1730     3.8040235638618469e-02
    z[4,5,6]  R1731     2.1705214679241180e-01
    z[4,5,6]  R1732     4.0557637810707092e-02
    z[4,5,6]  R1733     -6.5903581678867340e-02
    z[4,5,6]  R1734     5.5676591396331787e-01
    z[4,5,6]  R1735     3.0735790729522705e-02
    z[4,5,6]  R1736     -2.5501903891563416e-01
    z[4,5,6]  R1737     2.4466918781399727e-02
    z[4,5,6]  R1738     -6.1453711986541748e-01
    z[4,5,6]  R1739     2.9225218296051025e-01
    z[4,5,6]  R1740     -2.2415725886821747e-01
    z[4,5,6]  R1741     -1.3678628206253052e-01
    z[4,5,6]  R1742     5.1763290166854858e-01
    z[4,5,6]  R1743     2.1968476474285126e-02
    z[4,5,6]  R1744     2.5014054775238037e-01
    z[4,5,6]  R1745     -6.4311426877975464e-01
    z[4,5,6]  R1746     -1.0943056643009186e-01
    z[4,5,6]  R1747     -3.7771737575531006e-01
    z[4,5,6]  R1748     -4.3297520279884338e-01
    z[4,5,6]  R1749     3.5609375685453415e-02
    z[4,5,6]  R1750     -9.5370374619960785e-03
    z[4,5,6]  R1751     2.8886166214942932e-01
    z[4,5,6]  R1752     -4.4588279724121094e-01
    z[4,5,6]  R1753     -5.8686070144176483e-02
    z[4,5,6]  R1754     -4.7766438126564026e-01
    z[4,5,6]  R1755     1.3234890997409821e-01
    z[4,5,6]  R1756     4.6327769756317139e-01
    z[4,5,6]  R1757     -2.1402609348297119e-01
    z[4,5,6]  R1758     5.1475517451763153e-02
    z[4,5,6]  R1759     -5.3200449794530869e-02
    z[4,5,6]  R1760     1.6672787070274353e-01
    z[4,5,6]  R1761     2.4014633893966675e-01
    z[4,5,6]  R1762     1.1975119262933731e-01
    z[4,5,6]  R1763     3.3051747083663940e-01
    z[4,5,6]  R1764     -4.1553658246994019e-01
    z[4,5,6]  R1765     -3.8281965255737305e-01
    z[4,5,6]  R1766     3.4816227853298187e-02
    z[4,5,6]  R1767     2.9397544264793396e-01
    z[4,5,6]  R1768     -3.5653370618820190e-01
    z[4,5,6]  R1769     -6.6828310489654541e-02
    z[4,5,6]  R1770     2.8323090076446533e-01
    z[4,5,6]  R1771     3.3723458647727966e-01
    z[4,5,6]  R1772     3.4797167778015137e-01
    z[4,5,6]  R1773     7.8672267496585846e-02
    z[4,5,6]  R1774     1.8038541078567505e-01
    z[4,5,6]  R1775     5.5920296907424927e-01
    z[4,5,6]  R1776     2.2989727556705475e-01
    z[4,5,6]  R1777     4.3185658752918243e-02
    z[4,5,6]  R1778     -1.3556602597236633e-01
    z[4,5,6]  R1779     -0.26072958111763
    z[4,5,6]  R1780     -4.4539049267768860e-02
    z[4,5,6]  R1781     2.6188188791275024e-01
    z[4,5,6]  R1782     -3.4480971097946167e-01
    z[4,5,6]  R1783     -3.8678294420242310e-01
    z[4,5,6]  R1784     4.1781640052795410e-01
    z[4,5,6]  R1785     3.9502507448196411e-01
    z[4,5,6]  R1786     1.5786762535572052e-01
    z[4,5,6]  R1787     -1.7694112658500671e-01
    z[4,5,6]  R1788     -3.9903020858764648e-01
    z[4,5,6]  R1789     1.5352848172187805e-01
    z[4,5,6]  R1790     -1.7421814799308777e-01
    z[4,5,6]  R1791     1.0770173370838165e-01
    z[4,5,6]  R1792     -1.5234698355197906e-01
    z[4,5,6]  R1793     1.7902514338493347e-01
    z[4,5,6]  R1794     -2.0524072647094727e-01
    z[4,5,6]  R1795     -1.2814530730247498e-01
    z[4,5,6]  R1796     6.4170587062835693e-01
    z[4,5,6]  R1797     8.4600344300270081e-02
    z[4,5,6]  R1798     -4.2167651653289795e-01
    z[4,5,6]  R1799     3.8686826825141907e-02
    z[4,5,6]  R1800     -3.7207841873168945e-01
    z[4,5,6]  R1801     1.6291812062263489e-01
    z[4,5,6]  R1802     2.5581473112106323e-01
    z[4,5,6]  R1803     -2.8113466501235962e-01
    z[4,5,6]  R1804     1.2849248945713043e-01
    z[4,5,6]  R1805     1.2341749854385853e-02
    z[4,5,6]  R1806     1.4303857088088989e-01
    z[4,5,6]  R1807     2.7706572413444519e-01
    z[4,5,6]  R1808     -2.9784819483757019e-01
    z[4,5,6]  R1809     1.5759864449501038e-01
    z[4,5,6]  R1810     -6.2524974346160889e-01
    z[4,5,6]  R1811     0.231205552816391
    z[4,5,6]  R1812     -2.3779509961605072e-01
    z[4,5,6]  R1813     -0.264913946390152
    z[4,5,6]  R1814     1.5839265286922455e-01
    z[4,5,6]  R1815     3.4261947870254517e-01
    z[4,5,6]  R1816     -1.1964618414640427e-01
    z[4,5,6]  R1817     2.7611851692199707e-01
    z[4,5,6]  R1818     -1.7255797982215881e-01
    z[4,5,6]  R1819     -7.1088634431362152e-02
    z[4,5,6]  R1820     -3.6511799693107605e-01
    z[4,5,6]  R1821     -1.8450810015201569e-01
    z[4,5,6]  R1822     7.3461544513702393e-01
    z[4,5,6]  R1823     3.4221544861793518e-01
    z[4,5,6]  R1824     -8.4001637995243073e-02
    z[4,5,6]  R1825     4.1955387592315674e-01
    z[4,5,6]  R1826     -3.3530315756797791e-01
    z[4,5,6]  R1827     -6.4525239169597626e-02
    z[4,5,6]  R1828     -1.1844666302204132e-01
    z[4,5,6]  R1829     2.2946875542402267e-02
    z[4,5,6]  R1830     1.7470799386501312e-01
    z[4,5,6]  R1831     3.7696731090545654e-01
    z[4,5,6]  R1832     8.7144136428833008e-02
    z[4,5,6]  R1833     -1.6616840660572052e-01
    z[4,5,6]  R1834     4.3904036283493042e-01
    z[4,5,6]  R1835     -1.6719458997249603e-01
    z[4,5,6]  R1836     8.3646379411220551e-02
    z[4,5,6]  R1837     -1.4737313613295555e-02
    z[4,5,6]  R1838     1.3662087917327881e-01
    z[4,5,6]  R1839     2.6793381571769714e-01
    z[4,5,6]  R1840     -1.0554116219282150e-01
    z[4,5,6]  R1841     -5.7056136429309845e-03
    z[4,5,6]  R1842     3.1772968173027039e-01
    z[4,5,6]  R1843     3.4137552976608276e-01
    z[4,5,6]  R1844     2.6968577504158020e-01
    z[4,5,6]  R1845     2.6858061552047729e-01
    z[4,5,6]  R1846     3.4463077783584595e-02
    z[4,5,6]  R1847     1.0873294621706009e-01
    z[4,5,6]  R1848     -1.1475966870784760e-01
    z[4,5,6]  R1849     -3.2617077231407166e-01
    z[4,5,6]  R1850     -7.7605910599231720e-02
    z[4,5,6]  R1851     -3.3081090450286865e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R1852     -1
    z[5,4,0]  R1853     1
    z[5,4,0]  R1866     2.3319423198699951e-01
    z[5,4,0]  R1867     3.1212385743856430e-02
    z[5,4,0]  R1868     5.0146347284317017e-01
    z[5,4,0]  R1869     -3.9650425314903259e-02
    z[5,4,0]  R1870     3.2497721910476685e-01
    z[5,4,0]  R1871     -4.7212675213813782e-01
    z[5,4,0]  R1872     -3.6578410863876343e-01
    z[5,4,0]  R1873     -2.6424747705459595e-01
    z[5,4,0]  R1874     -4.2607155442237854e-01
    z[5,4,0]  R1875     -4.7789987921714783e-01
    z[5,4,0]  R1876     8.5370033979415894e-01
    z[5,4,0]  R1877     7.5417733192443848e-01
    z[5,4,0]  R1878     3.1483504176139832e-01
    z[5,4,0]  R1879     5.8094173669815063e-01
    z[5,4,0]  R1880     3.3036491274833679e-01
    z[5,4,0]  R1881     6.6223418712615967e-01
    z[5,4,0]  R1882     6.2715351581573486e-01
    z[5,4,0]  R1883     5.4246836900711060e-01
    z[5,4,0]  R1884     5.1179546117782593e-01
    z[5,4,0]  R1885     -8.4287482500076294e-01
    z[5,4,0]  R1886     5.6227583438158035e-02
    z[5,4,0]  R1887     0.466959148645401
    z[5,4,0]  R1888     4.4979009032249451e-01
    z[5,4,0]  R1889     -2.8108501434326172e-01
    z[5,4,0]  R1890     -2.9995483160018921e-01
    z[5,4,0]  R1891     -0.602034330368042
    z[5,4,0]  R1892     -1.1290226131677628e-01
    z[5,4,0]  R1893     -1.3753145933151245e-01
    z[5,4,0]  R1894     3.4224852919578552e-01
    z[5,4,0]  R1895     -3.2606214284896851e-02
    z[5,4,0]  R1896     1.9191227853298187e-01
    z[5,4,0]  R1897     5.6973749399185181e-01
    z[5,4,0]  R1898     5.6437432765960693e-01
    z[5,4,0]  R1899     1.7782148718833923e-01
    z[5,4,0]  R1900     6.2057304382324219e-01
    z[5,4,0]  R1901     -4.2226108908653259e-01
    z[5,4,0]  R1902     3.5937055945396423e-01
    z[5,4,0]  R1903     -6.2501597404479980e-01
    z[5,4,0]  R1904     -8.5845166444778442e-01
    z[5,4,0]  R1905     -8.0257123708724976e-01
    z[5,4,0]  R1906     5.3197562694549561e-01
    z[5,4,0]  R1907     -0.451295405626297
    z[5,4,0]  R1908     1.1656672693789005e-02
    z[5,4,0]  R1909     -1.8033067882061005e-01
    z[5,4,0]  R1910     3.9501029253005981e-01
    z[5,4,0]  R1911     -8.9244616031646729e-01
    z[5,4,0]  R1912     -9.4487506151199341e-01
    z[5,4,0]  R1913     4.1145300865173340e-01
    z[5,4,0]  R1914     -7.8592562675476074e-01
    z[5,4,0]  R1915     -8.4297996759414673e-01
    z[5,4,0]  R1916     8.0484122037887573e-01
    z[5,4,0]  R1917     6.7473107576370239e-01
    z[5,4,0]  R1918     -1.7581452429294586e-01
    z[5,4,0]  R1919     -5.6763684749603271e-01
    z[5,4,0]  R1920     3.8825148344039917e-01
    z[5,4,0]  R1921     -8.9772361516952515e-01
    z[5,4,0]  R1922     -9.2428743839263916e-01
    z[5,4,0]  R1923     0.092893086373806
    z[5,4,0]  R1924     7.4307754635810852e-02
    z[5,4,0]  R1925     0.00360292661935091
    z[5,4,0]  R1926     5.5153167247772217e-01
    z[5,4,0]  R1927     4.4846823811531067e-01
    z[5,4,0]  R1928     6.7341423034667969e-01
    z[5,4,0]  R1929     1.3346501626074314e-02
    z[5,4,0]  R1930     -1.4611147344112396e-01
    z[5,4,0]  R1931     1.4871416985988617e-01
    z[5,4,0]  R1932     -5.1569759845733643e-01
    z[5,4,0]  R1933     4.4647574424743652e-01
    z[5,4,0]  R1934     -8.4457063674926758e-01
    z[5,4,0]  R1935     2.1097144484519958e-01
    z[5,4,0]  R1936     -1.0769873857498169e-01
    z[5,4,0]  R1937     4.4023630023002625e-01
    z[5,4,0]  R1938     1.5612202882766724e-01
    z[5,4,0]  R1939     1.0710169374942780e-01
    z[5,4,0]  R1940     1.4449438452720642e-01
    z[5,4,0]  R1941     3.6898839473724365e-01
    z[5,4,0]  R1942     3.5365390777587891e-01
    z[5,4,0]  R1943     2.2610253095626831e-01
    z[5,4,0]  R1944     3.7432238459587097e-01
    z[5,4,0]  R1945     4.5319777727127075e-01
    z[5,4,0]  R1946     4.2977181077003479e-01
    z[5,4,0]  R1947     8.7702494859695435e-01
    z[5,4,0]  R1948     4.8994666337966919e-01
    z[5,4,0]  R1949     7.9518508911132812e-01
    z[5,4,0]  R1950     7.8260397911071777e-01
    z[5,4,0]  R1951     6.9906884431838989e-01
    z[5,4,0]  R1952     8.0059701204299927e-01
    z[5,4,0]  R1953     7.1674311161041260e-01
    z[5,4,0]  R1954     1.7772741615772247e-01
    z[5,4,0]  R1955     3.0831113457679749e-01
    z[5,4,0]  R1956     0.0574665404856205
    z[5,4,0]  R1957     -1.6069617867469788e-01
    z[5,4,0]  R1958     -1.8466311693191528e-01
    z[5,4,0]  R1959     2.6367574930191040e-01
    z[5,4,0]  R1960     -3.7643620371818542e-01
    z[5,4,0]  R1961     -4.2276340723037720e-01
    z[5,4,0]  R1962     -2.7800530195236206e-01
    z[5,4,0]  R1963     -3.9284005761146545e-01
    z[5,4,0]  R1964     -2.9538375139236450e-01
    z[5,4,0]  R1965     -2.8193703293800354e-01
    z[5,4,0]  R1966     3.2031199336051941e-01
    z[5,4,0]  R1967     0.64688640832901
    z[5,4,0]  R1968     4.9982777237892151e-01
    z[5,4,0]  R1969     5.6988584995269775e-01
    z[5,4,0]  R1970     3.5082665085792542e-01
    z[5,4,0]  R1971     7.1311330795288086e-01
    z[5,4,0]  R1972     6.9980710744857788e-01
    z[5,4,0]  R1973     6.9062197208404541e-01
    z[5,4,0]  R1974     7.6047849655151367e-01
    z[5,4,0]  R1975     8.7697041034698486e-01
    z[5,4,0]  R1976     4.1299268603324890e-01
    z[5,4,0]  R1977     0.889885663986206
    z[5,4,0]  R1978     1.6321896016597748e-01
    z[5,4,0]  R1979     -2.9290360212326050e-01
    z[5,4,0]  R1980     -2.1908316761255264e-02
    z[5,4,0]  R1981     8.1645774841308594e-01
    z[5,4,0]  R1982     -2.7878215909004211e-01
    z[5,4,0]  R1983     -7.4276372790336609e-02
    z[5,4,0]  R1984     -0.558233380317688
    z[5,4,0]  R1985     1.1558765172958374e-01
    z[5,4,0]  R1986     0.0573107935488224
    z[5,4,0]  R1987     7.9961299896240234e-01
    z[5,4,0]  R1988     2.4737431108951569e-01
    z[5,4,0]  R1989     6.1655020713806152e-01
    z[5,4,0]  R1990     1.5405617654323578e-01
    z[5,4,0]  R1991     6.4512962102890015e-01
    z[5,4,0]  R1992     -4.4343182444572449e-01
    z[5,4,0]  R1993     3.7412993609905243e-02
    z[5,4,0]  R1994     3.1464582681655884e-01
    z[5,4,0]  R1995     3.0606740713119507e-01
    z[5,4,0]  R1996     4.7941152006387711e-02
    z[5,4,0]  R1997     2.8697720170021057e-01
    z[5,4,0]  R1998     -4.5842775143682957e-03
    z[5,4,0]  R1999     3.2030594348907471e-01
    z[5,4,0]  R2000     3.5250097513198853e-01
    z[5,4,0]  R2001     2.0658531785011292e-01
    z[5,4,0]  R2002     8.9794412255287170e-02
    z[5,4,0]  R2003     -8.2716733217239380e-02
    z[5,4,0]  R2004     -8.0401289463043213e-01
    z[5,4,0]  R2005     -4.5728474855422974e-01
    z[5,4,0]  R2006     -1.7456750571727753e-01
    z[5,4,0]  R2007     -5.2107536792755127e-01
    z[5,4,0]  R2008     6.4120548963546753e-01
    z[5,4,0]  R2009     -6.3968378305435181e-01
    z[5,4,0]  R2010     -0.747021496295929
    z[5,4,0]  R2011     -7.5739741325378418e-01
    z[5,4,0]  R2012     -7.6824188232421875e-01
    z[5,4,0]  R2013     -7.7754920721054077e-01
    z[5,4,0]  R2014     -0.503307044506073
    z[5,4,0]  R2015     -6.0108578205108643e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R1854     -1
    z[5,4,1]  R1855     1
    z[5,4,1]  R1866     -1.7011912167072296e-01
    z[5,4,1]  R1867     -8.6639535427093506e-01
    z[5,4,1]  R1868     -3.2488226890563965e-01
    z[5,4,1]  R1869     1.2755459547042847e-01
    z[5,4,1]  R1870     2.5161633267998695e-02
    z[5,4,1]  R1871     7.1684432029724121e-01
    z[5,4,1]  R1872     6.4251607656478882e-01
    z[5,4,1]  R1873     8.6258381605148315e-01
    z[5,4,1]  R1874     6.1642372608184814e-01
    z[5,4,1]  R1875     5.8614504337310791e-01
    z[5,4,1]  R1876     4.1367597877979279e-02
    z[5,4,1]  R1877     -4.5734432339668274e-01
    z[5,4,1]  R1878     5.3213047981262207e-01
    z[5,4,1]  R1879     6.7137241363525391e-01
    z[5,4,1]  R1880     -1.1954019963741302e-01
    z[5,4,1]  R1881     5.8716768026351929e-01
    z[5,4,1]  R1882     5.6276440620422363e-01
    z[5,4,1]  R1883     6.0371154546737671e-01
    z[5,4,1]  R1884     5.2918326854705811e-01
    z[5,4,1]  R1885     -1.8518170714378357e-01
    z[5,4,1]  R1886     -6.4127451181411743e-01
    z[5,4,1]  R1887     -7.6162025332450867e-02
    z[5,4,1]  R1888     -1.2833869457244873e-01
    z[5,4,1]  R1889     3.6129736900329590e-01
    z[5,4,1]  R1890     1.2361064553260803e-01
    z[5,4,1]  R1891     3.2340753078460693e-01
    z[5,4,1]  R1892     3.2106035947799683e-01
    z[5,4,1]  R1893     4.2450046539306641e-01
    z[5,4,1]  R1894     -7.9346306622028351e-02
    z[5,4,1]  R1895     6.7537516355514526e-01
    z[5,4,1]  R1896     -6.3041225075721741e-02
    z[5,4,1]  R1897     -3.1974253058433533e-01
    z[5,4,1]  R1898     -1.6818445920944214e-01
    z[5,4,1]  R1899     0.717118501663208
    z[5,4,1]  R1900     6.3430160284042358e-01
    z[5,4,1]  R1901     7.5796818733215332e-01
    z[5,4,1]  R1902     0.55787593126297
    z[5,4,1]  R1903     5.8910822868347168e-01
    z[5,4,1]  R1904     -1.9215551018714905e-01
    z[5,4,1]  R1905     -1.7271377146244049e-01
    z[5,4,1]  R1906     -2.1072624251246452e-02
    z[5,4,1]  R1907     5.2754455804824829e-01
    z[5,4,1]  R1908     8.9360141754150391e-01
    z[5,4,1]  R1909     5.8269160985946655e-01
    z[5,4,1]  R1910     4.3497118353843689e-01
    z[5,4,1]  R1911     -2.5367984175682068e-01
    z[5,4,1]  R1912     -2.0710146427154541e-01
    z[5,4,1]  R1913     6.7916643619537354e-01
    z[5,4,1]  R1914     -1.5099413692951202e-01
    z[5,4,1]  R1915     -2.0377218723297119e-01
    z[5,4,1]  R1916     -1.9711072742938995e-01
    z[5,4,1]  R1917     -5.8636730909347534e-01
    z[5,4,1]  R1918     4.9011856317520142e-01
    z[5,4,1]  R1919     6.4338010549545288e-01
    z[5,4,1]  R1920     5.1117801666259766e-01
    z[5,4,1]  R1921     -2.8135138750076294e-01
    z[5,4,1]  R1922     -9.9034756422042847e-02
    z[5,4,1]  R1923     6.2226468324661255e-01
    z[5,4,1]  R1924     0.603766918182373
    z[5,4,1]  R1925     3.4518954157829285e-01
    z[5,4,1]  R1926     -2.0193326473236084e-01
    z[5,4,1]  R1927     2.3295342922210693e-01
    z[5,4,1]  R1928     -2.8062483668327332e-01
    z[5,4,1]  R1929     -0.732764482498169
    z[5,4,1]  R1930     4.3333226442337036e-01
    z[5,4,1]  R1931     -4.5113921165466309e-01
    z[5,4,1]  R1932     7.9712599515914917e-01
    z[5,4,1]  R1933     5.5384212732315063e-01
    z[5,4,1]  R1934     -3.7367174029350281e-01
    z[5,4,1]  R1935     5.1363587379455566e-01
    z[5,4,1]  R1936     -7.5980699062347412e-01
    z[5,4,1]  R1937     5.7655000686645508e-01
    z[5,4,1]  R1938     3.6562508344650269e-01
    z[5,4,1]  R1939     5.0436949729919434e-01
    z[5,4,1]  R1940     3.5136339068412781e-01
    z[5,4,1]  R1941     3.3590036630630493e-01
    z[5,4,1]  R1942     3.6449325084686279e-01
    z[5,4,1]  R1943     2.8012299537658691e-01
    z[5,4,1]  R1944     3.7272053956985474e-01
    z[5,4,1]  R1945     -8.8489063084125519e-02
    z[5,4,1]  R1946     3.6328908801078796e-01
    z[5,4,1]  R1947     -2.6171383261680603e-01
    z[5,4,1]  R1948     1.7946556210517883e-01
    z[5,4,1]  R1949     -1.1190539598464966e-01
    z[5,4,1]  R1950     -2.1723881363868713e-03
    z[5,4,1]  R1951     2.4210011959075928e-01
    z[5,4,1]  R1952     -4.1312709450721741e-01
    z[5,4,1]  R1953     2.6052770018577576e-01
    z[5,4,1]  R1954     -7.6499587297439575e-01
    z[5,4,1]  R1955     -8.0215257406234741e-01
    z[5,4,1]  R1956     -6.0057377815246582e-01
    z[5,4,1]  R1957     -6.4692658185958862e-01
    z[5,4,1]  R1958     9.0139198303222656e-01
    z[5,4,1]  R1959     -5.3246569633483887e-01
    z[5,4,1]  R1960     -6.7894893884658813e-01
    z[5,4,1]  R1961     8.1930369138717651e-01
    z[5,4,1]  R1962     7.5480204820632935e-01
    z[5,4,1]  R1963     -5.7989561557769775e-01
    z[5,4,1]  R1964     7.5166279077529907e-01
    z[5,4,1]  R1965     7.2597855329513550e-01
    z[5,4,1]  R1966     -0.900971531867981
    z[5,4,1]  R1967     3.5553914308547974e-01
    z[5,4,1]  R1968     3.0239078402519226e-01
    z[5,4,1]  R1969     7.8953355550765991e-01
    z[5,4,1]  R1970     1.0615737736225128e-01
    z[5,4,1]  R1971     -0.314377099275589
    z[5,4,1]  R1972     -1.5062569081783295e-01
    z[5,4,1]  R1973     -1.0727320611476898e-01
    z[5,4,1]  R1974     -3.8941238075494766e-02
    z[5,4,1]  R1975     0.0747273862361908
    z[5,4,1]  R1976     6.7456549406051636e-01
    z[5,4,1]  R1977     4.9455105327069759e-03
    z[5,4,1]  R1978     -4.4741186499595642e-01
    z[5,4,1]  R1979     -4.7400176525115967e-01
    z[5,4,1]  R1980     6.2695342302322388e-01
    z[5,4,1]  R1981     -1.0745301097631454e-01
    z[5,4,1]  R1982     -8.1280374526977539e-01
    z[5,4,1]  R1983     -7.5216662883758545e-01
    z[5,4,1]  R1984     -7.0853632688522339e-01
    z[5,4,1]  R1985     -7.3085999488830566e-01
    z[5,4,1]  R1986     -1.8043406307697296e-02
    z[5,4,1]  R1987     9.9392943084239960e-02
    z[5,4,1]  R1988     -6.2044060230255127e-01
    z[5,4,1]  R1989     1.7024628818035126e-01
    z[5,4,1]  R1990     -3.3160951733589172e-01
    z[5,4,1]  R1991     -6.8393266201019287e-01
    z[5,4,1]  R1992     -8.8236892223358154e-01
    z[5,4,1]  R1993     -8.0494534969329834e-01
    z[5,4,1]  R1994     -7.3241299390792847e-01
    z[5,4,1]  R1995     -7.4001210927963257e-01
    z[5,4,1]  R1996     8.2478791475296021e-01
    z[5,4,1]  R1997     -5.0706952810287476e-01
    z[5,4,1]  R1998     -8.8635720312595367e-02
    z[5,4,1]  R1999     -5.9026145935058594e-01
    z[5,4,1]  R2000     -4.6090030670166016e-01
    z[5,4,1]  R2001     -8.1325441598892212e-01
    z[5,4,1]  R2002     -8.2056128978729248e-01
    z[5,4,1]  R2003     -7.8597873449325562e-01
    z[5,4,1]  R2004     -0.0318484753370285
    z[5,4,1]  R2005     -3.4133437275886536e-01
    z[5,4,1]  R2006     -4.9273166060447693e-01
    z[5,4,1]  R2007     6.4521151781082153e-01
    z[5,4,1]  R2008     -1.0454971343278885e-01
    z[5,4,1]  R2009     2.5759446620941162e-01
    z[5,4,1]  R2010     -1.0024883598089218e-01
    z[5,4,1]  R2011     6.7785056307911873e-03
    z[5,4,1]  R2012     8.4484659135341644e-02
    z[5,4,1]  R2013     -4.8546131700277328e-02
    z[5,4,1]  R2014     1.1268686503171921e-01
    z[5,4,1]  R2015     -0.0511755645275116
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R1856     -1
    z[5,4,2]  R1857     1
    z[5,4,2]  R1866     -4.4515646994113922e-02
    z[5,4,2]  R1867     -6.7482399754226208e-03
    z[5,4,2]  R1868     3.0095195770263672e-01
    z[5,4,2]  R1869     -1.4778596162796021e-01
    z[5,4,2]  R1870     -2.0170383155345917e-01
    z[5,4,2]  R1871     2.2534139454364777e-01
    z[5,4,2]  R1872     2.0300704240798950e-01
    z[5,4,2]  R1873     3.9781138300895691e-02
    z[5,4,2]  R1874     1.1528802663087845e-01
    z[5,4,2]  R1875     1.4067694544792175e-01
    z[5,4,2]  R1876     -2.7100220322608948e-01
    z[5,4,2]  R1877     1.5467441082000732e-01
    z[5,4,2]  R1878     1.6633830964565277e-01
    z[5,4,2]  R1879     5.3234919905662537e-02
    z[5,4,2]  R1880     7.6274409890174866e-02
    z[5,4,2]  R1881     1.8836699426174164e-01
    z[5,4,2]  R1882     9.8673895001411438e-02
    z[5,4,2]  R1883     2.5525781512260437e-01
    z[5,4,2]  R1884     4.3276599049568176e-01
    z[5,4,2]  R1885     -0.0498683899641037
    z[5,4,2]  R1886     -7.8489862382411957e-02
    z[5,4,2]  R1887     -5.3640075027942657e-02
    z[5,4,2]  R1888     2.6360502839088440e-01
    z[5,4,2]  R1889     -0.015627421438694
    z[5,4,2]  R1890     8.6594857275485992e-02
    z[5,4,2]  R1891     2.0107630640268326e-02
    z[5,4,2]  R1892     1.3167257606983185e-01
    z[5,4,2]  R1893     2.3699508607387543e-01
    z[5,4,2]  R1894     1.5364913642406464e-01
    z[5,4,2]  R1895     9.4399198889732361e-02
    z[5,4,2]  R1896     1.7879419028759003e-01
    z[5,4,2]  R1897     2.7754855155944824e-01
    z[5,4,2]  R1898     2.4555955827236176e-01
    z[5,4,2]  R1899     1.0720190405845642e-01
    z[5,4,2]  R1900     3.3301401138305664e-01
    z[5,4,2]  R1901     -1.0970806330442429e-01
    z[5,4,2]  R1902     6.7490625381469727e-01
    z[5,4,2]  R1903     -2.3787726461887360e-01
    z[5,4,2]  R1904     -1.8049703538417816e-01
    z[5,4,2]  R1905     -1.7838594317436218e-01
    z[5,4,2]  R1906     1.4784198999404907e-01
    z[5,4,2]  R1907     -6.0977645218372345e-02
    z[5,4,2]  R1908     3.1624818220734596e-03
    z[5,4,2]  R1909     9.3205235898494720e-02
    z[5,4,2]  R1910     5.4300391674041748e-01
    z[5,4,2]  R1911     -2.6401841640472412e-01
    z[5,4,2]  R1912     -1.2462133914232254e-01
    z[5,4,2]  R1913     -1.3151612877845764e-01
    z[5,4,2]  R1914     -1.8843559920787811e-01
    z[5,4,2]  R1915     -2.3226018249988556e-01
    z[5,4,2]  R1916     2.9141888022422791e-01
    z[5,4,2]  R1917     2.0411417353898287e-03
    z[5,4,2]  R1918     1.5482509136199951e-01
    z[5,4,2]  R1919     -3.1458556652069092e-01
    z[5,4,2]  R1920     6.1313390731811523e-01
    z[5,4,2]  R1921     -1.8113890290260315e-01
    z[5,4,2]  R1922     -2.2429031133651733e-01
    z[5,4,2]  R1923     0.0309981070458889
    z[5,4,2]  R1924     -1.3802379369735718e-02
    z[5,4,2]  R1925     -6.5438352525234222e-02
    z[5,4,2]  R1926     2.1384723484516144e-02
    z[5,4,2]  R1927     -5.4391520097851753e-03
    z[5,4,2]  R1928     1.1843720823526382e-01
    z[5,4,2]  R1929     5.1741704344749451e-02
    z[5,4,2]  R1930     -7.8318662941455841e-02
    z[5,4,2]  R1931     -4.4125726819038391e-01
    z[5,4,2]  R1932     -1.6930712759494781e-01
    z[5,4,2]  R1933     0.553565502166748
    z[5,4,2]  R1934     -2.5422206521034241e-01
    z[5,4,2]  R1935     -7.4339248239994049e-02
    z[5,4,2]  R1936     4.2846021056175232e-01
    z[5,4,2]  R1937     4.7197285294532776e-01
    z[5,4,2]  R1938     8.7361693382263184e-01
    z[5,4,2]  R1939     7.1127218008041382e-01
    z[5,4,2]  R1940     8.0955666303634644e-01
    z[5,4,2]  R1941     5.6911766529083252e-01
    z[5,4,2]  R1942     4.0934070944786072e-01
    z[5,4,2]  R1943     7.1070623397827148e-01
    z[5,4,2]  R1944     5.7346224784851074e-01
    z[5,4,2]  R1945     7.3634207248687744e-01
    z[5,4,2]  R1946     1.9641520082950592e-01
    z[5,4,2]  R1947     -1.2724100053310394e-01
    z[5,4,2]  R1948     0.371624618768692
    z[5,4,2]  R1949     -9.8497465252876282e-02
    z[5,4,2]  R1950     -4.4014319777488708e-02
    z[5,4,2]  R1951     -7.1682795882225037e-02
    z[5,4,2]  R1952     -1.1576101183891296e-01
    z[5,4,2]  R1953     -1.6678930819034576e-01
    z[5,4,2]  R1954     -3.3565798401832581e-01
    z[5,4,2]  R1955     -1.0911931097507477e-01
    z[5,4,2]  R1956     -9.6833752468228340e-03
    z[5,4,2]  R1957     -5.0400024652481079e-01
    z[5,4,2]  R1958     -2.5089514255523682e-01
    z[5,4,2]  R1959     -5.4853504896163940e-01
    z[5,4,2]  R1960     -1.8029215931892395e-01
    z[5,4,2]  R1961     -1.6667243838310242e-01
    z[5,4,2]  R1962     -4.2241996526718140e-01
    z[5,4,2]  R1963     -3.4912031888961792e-01
    z[5,4,2]  R1964     -3.4621769189834595e-01
    z[5,4,2]  R1965     -3.2184126973152161e-01
    z[5,4,2]  R1966     -1.1219297349452972e-01
    z[5,4,2]  R1967     5.5161285400390625e-01
    z[5,4,2]  R1968     4.4495663046836853e-01
    z[5,4,2]  R1969     0.0851961150765419
    z[5,4,2]  R1970     8.0610948801040649e-01
    z[5,4,2]  R1971     5.7804727554321289e-01
    z[5,4,2]  R1972     3.2496452331542969e-02
    z[5,4,2]  R1973     -4.9097468145191669e-03
    z[5,4,2]  R1974     -1.1313035339117050e-01
    z[5,4,2]  R1975     -2.0541571080684662e-01
    z[5,4,2]  R1976     2.0228993892669678e-01
    z[5,4,2]  R1977     0.352448970079422
    z[5,4,2]  R1978     1.8935729563236237e-01
    z[5,4,2]  R1979     0.316108375787735
    z[5,4,2]  R1980     2.9753330349922180e-01
    z[5,4,2]  R1981     1.9822779297828674e-01
    z[5,4,2]  R1982     5.1628995686769485e-02
    z[5,4,2]  R1983     -4.0192636847496033e-01
    z[5,4,2]  R1984     -4.1487923264503479e-01
    z[5,4,2]  R1985     -3.2615345716476440e-01
    z[5,4,2]  R1986     4.5415255427360535e-01
    z[5,4,2]  R1987     2.1178849041461945e-01
    z[5,4,2]  R1988     3.1848031282424927e-01
    z[5,4,2]  R1989     2.0725689828395844e-01
    z[5,4,2]  R1990     -2.5462964177131653e-01
    z[5,4,2]  R1991     9.5716238021850586e-02
    z[5,4,2]  R1992     -1.0808206349611282e-01
    z[5,4,2]  R1993     -2.2758223116397858e-01
    z[5,4,2]  R1994     -3.3036249876022339e-01
    z[5,4,2]  R1995     -4.9515508115291595e-02
    z[5,4,2]  R1996     3.7481376528739929e-01
    z[5,4,2]  R1997     8.0753460526466370e-02
    z[5,4,2]  R1998     5.3348565101623535e-01
    z[5,4,2]  R1999     4.6799808740615845e-01
    z[5,4,2]  R2000     -3.8040125370025635e-01
    z[5,4,2]  R2001     -2.5340586900711060e-01
    z[5,4,2]  R2002     -3.2903066277503967e-01
    z[5,4,2]  R2003     -4.6661749482154846e-01
    z[5,4,2]  R2004     1.2670126557350159e-01
    z[5,4,2]  R2005     -9.6945315599441528e-02
    z[5,4,2]  R2006     6.2912482023239136e-01
    z[5,4,2]  R2007     4.5185607671737671e-01
    z[5,4,2]  R2008     6.8789505958557129e-01
    z[5,4,2]  R2009     4.1986843943595886e-01
    z[5,4,2]  R2010     -5.8373087644577026e-01
    z[5,4,2]  R2011     -5.1679015159606934e-01
    z[5,4,2]  R2012     -0.415141761302948
    z[5,4,2]  R2013     -3.8516268134117126e-01
    z[5,4,2]  R2014     -1.2402106076478958e-01
    z[5,4,2]  R2015     -5.1551944017410278e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R1858     -1
    z[5,4,3]  R1859     1
    z[5,4,3]  R1866     7.3701679706573486e-01
    z[5,4,3]  R1867     -2.5402450561523438e-01
    z[5,4,3]  R1868     4.9658772349357605e-01
    z[5,4,3]  R1869     6.9725221395492554e-01
    z[5,4,3]  R1870     3.9002344012260437e-01
    z[5,4,3]  R1871     3.8173970580101013e-01
    z[5,4,3]  R1872     4.8316952586174011e-01
    z[5,4,3]  R1873     2.3315073549747467e-01
    z[5,4,3]  R1874     5.0997787714004517e-01
    z[5,4,3]  R1875     5.1632338762283325e-01
    z[5,4,3]  R1876     -4.0670718997716904e-02
    z[5,4,3]  R1877     -2.7080744504928589e-01
    z[5,4,3]  R1878     0.29147869348526
    z[5,4,3]  R1879     -1.2598313391208649e-01
    z[5,4,3]  R1880     -2.4649222195148468e-01
    z[5,4,3]  R1881     -3.7062340974807739e-01
    z[5,4,3]  R1882     -2.8882077336311340e-01
    z[5,4,3]  R1883     -4.2581576108932495e-01
    z[5,4,3]  R1884     -2.8204908967018127e-01
    z[5,4,3]  R1885     -2.2921943664550781e-01
    z[5,4,3]  R1886     4.6231511235237122e-01
    z[5,4,3]  R1887     5.7530981302261353e-01
    z[5,4,3]  R1888     -3.0505027621984482e-02
    z[5,4,3]  R1889     0.747157871723175
    z[5,4,3]  R1890     6.8595755100250244e-01
    z[5,4,3]  R1891     0.518020510673523
    z[5,4,3]  R1892     4.2831945419311523e-01
    z[5,4,3]  R1893     2.5988447666168213e-01
    z[5,4,3]  R1894     1.5684854984283447e-01
    z[5,4,3]  R1895     4.8331776261329651e-01
    z[5,4,3]  R1896     6.0230517387390137e-01
    z[5,4,3]  R1897     0.170273557305336
    z[5,4,3]  R1898     0.139985129237175
    z[5,4,3]  R1899     4.7819033265113831e-01
    z[5,4,3]  R1900     -1.2592312693595886e-01
    z[5,4,3]  R1901     7.7215313911437988e-02
    z[5,4,3]  R1902     -1.8931412696838379e-01
    z[5,4,3]  R1903     -3.3788260817527771e-01
    z[5,4,3]  R1904     2.4014195799827576e-01
    z[5,4,3]  R1905     -0.408211886882782
    z[5,4,3]  R1906     -1.3090525567531586e-01
    z[5,4,3]  R1907     5.7941854000091553e-01
    z[5,4,3]  R1908     2.6890572905540466e-01
    z[5,4,3]  R1909     4.4059857726097107e-01
    z[5,4,3]  R1910     3.4857034683227539e-02
    z[5,4,3]  R1911     2.7813278138637543e-02
    z[5,4,3]  R1912     0.123990997672081
    z[5,4,3]  R1913     -4.2569947242736816e-01
    z[5,4,3]  R1914     8.7250366806983948e-02
    z[5,4,3]  R1915     3.5420853644609451e-02
    z[5,4,3]  R1916     -2.3585051298141479e-01
    z[5,4,3]  R1917     9.0801984071731567e-02
    z[5,4,3]  R1918     4.4118198752403259e-01
    z[5,4,3]  R1919     0.0428534559905529
    z[5,4,3]  R1920     2.3797746002674103e-01
    z[5,4,3]  R1921     -3.7355388049036264e-03
    z[5,4,3]  R1922     -2.3232486844062805e-01
    z[5,4,3]  R1923     -0.715779185295105
    z[5,4,3]  R1924     -7.7900612354278564e-01
    z[5,4,3]  R1925     -0.923267126083374
    z[5,4,3]  R1926     6.0994488000869751e-01
    z[5,4,3]  R1927     7.4652409553527832e-01
    z[5,4,3]  R1928     -1.1623510718345642e-01
    z[5,4,3]  R1929     -0.557176411151886
    z[5,4,3]  R1930     8.3671528100967407e-01
    z[5,4,3]  R1931     5.7553607970476151e-02
    z[5,4,3]  R1932     2.1857085824012756e-01
    z[5,4,3]  R1933     -9.8399199545383453e-02
    z[5,4,3]  R1934     2.3236854374408722e-01
    z[5,4,3]  R1935     -7.4198341369628906e-01
    z[5,4,3]  R1936     -1.1365080624818802e-01
    z[5,4,3]  R1937     -2.6653057336807251e-01
    z[5,4,3]  R1938     -1.6158398240804672e-02
    z[5,4,3]  R1939     8.7386779487133026e-02
    z[5,4,3]  R1940     -2.4195969104766846e-01
    z[5,4,3]  R1941     -5.4229967296123505e-02
    z[5,4,3]  R1942     -2.1973271667957306e-01
    z[5,4,3]  R1943     -2.1441173553466797e-01
    z[5,4,3]  R1944     -4.2974729090929031e-02
    z[5,4,3]  R1945     6.2710449099540710e-02
    z[5,4,3]  R1946     1.4789845049381256e-01
    z[5,4,3]  R1947     0.0894770473241806
    z[5,4,3]  R1948     3.9945179224014282e-01
    z[5,4,3]  R1949     8.7021932005882263e-02
    z[5,4,3]  R1950     2.2188428044319153e-01
    z[5,4,3]  R1951     5.1621246337890625e-01
    z[5,4,3]  R1952     -2.7530366182327271e-01
    z[5,4,3]  R1953     1.9655907154083252e-01
    z[5,4,3]  R1954     1.9867390394210815e-01
    z[5,4,3]  R1955     3.1789278984069824e-01
    z[5,4,3]  R1956     -4.6466785669326782e-01
    z[5,4,3]  R1957     5.3142286837100983e-02
    z[5,4,3]  R1958     -1.5477515757083893e-01
    z[5,4,3]  R1959     1.5464648604393005e-01
    z[5,4,3]  R1960     8.9399078860878944e-03
    z[5,4,3]  R1961     -2.6493254303932190e-01
    z[5,4,3]  R1962     -2.5016868114471436e-01
    z[5,4,3]  R1963     3.1325221061706543e-01
    z[5,4,3]  R1964     5.5311530828475952e-02
    z[5,4,3]  R1965     -3.7594158202409744e-02
    z[5,4,3]  R1966     -2.2050699591636658e-01
    z[5,4,3]  R1967     2.3014302551746368e-01
    z[5,4,3]  R1968     3.7489798665046692e-01
    z[5,4,3]  R1969     1.4491407573223114e-01
    z[5,4,3]  R1970     -1.3750021345913410e-02
    z[5,4,3]  R1971     2.0133394747972488e-02
    z[5,4,3]  R1972     -3.9063658565282822e-02
    z[5,4,3]  R1973     3.6451440304517746e-02
    z[5,4,3]  R1974     2.4458234012126923e-01
    z[5,4,3]  R1975     2.4195723235607147e-01
    z[5,4,3]  R1976     1.6079044342041016e-01
    z[5,4,3]  R1977     -2.1304486691951752e-01
    z[5,4,3]  R1978     5.1672559976577759e-01
    z[5,4,3]  R1979     1.3092531263828278e-01
    z[5,4,3]  R1980     6.0761805623769760e-02
    z[5,4,3]  R1981     -1.6981713473796844e-02
    z[5,4,3]  R1982     8.4242507815361023e-02
    z[5,4,3]  R1983     -4.7782354056835175e-02
    z[5,4,3]  R1984     -3.9128664880990982e-02
    z[5,4,3]  R1985     2.5848546624183655e-01
    z[5,4,3]  R1986     0.193464457988739
    z[5,4,3]  R1987     -5.1578204147517681e-03
    z[5,4,3]  R1988     -2.1298509091138840e-02
    z[5,4,3]  R1989     3.7492990493774414e-01
    z[5,4,3]  R1990     4.2187440395355225e-01
    z[5,4,3]  R1991     2.2648863494396210e-01
    z[5,4,3]  R1992     -1.3462702045217156e-03
    z[5,4,3]  R1993     1.5759870409965515e-01
    z[5,4,3]  R1994     3.5399022698402405e-01
    z[5,4,3]  R1995     2.3068022727966309e-01
    z[5,4,3]  R1996     -1.2059453874826431e-01
    z[5,4,3]  R1997     4.1977667808532715e-01
    z[5,4,3]  R1998     1.2259480357170105e-01
    z[5,4,3]  R1999     -1.3393211364746094e-01
    z[5,4,3]  R2000     1.0628718882799149e-01
    z[5,4,3]  R2001     3.2748955488204956e-01
    z[5,4,3]  R2002     1.0601244121789932e-01
    z[5,4,3]  R2003     -4.3967794626951218e-02
    z[5,4,3]  R2004     8.8841117918491364e-02
    z[5,4,3]  R2005     3.3085581660270691e-01
    z[5,4,3]  R2006     2.6332038640975952e-01
    z[5,4,3]  R2007     1.8129470944404602e-01
    z[5,4,3]  R2008     1.5514270961284637e-01
    z[5,4,3]  R2009     1.6484937071800232e-01
    z[5,4,3]  R2010     -1.1773931980133057e-01
    z[5,4,3]  R2011     -2.8462055325508118e-01
    z[5,4,3]  R2012     -2.1530902385711670e-01
    z[5,4,3]  R2013     -3.1624028086662292e-01
    z[5,4,3]  R2014     6.2884055078029633e-02
    z[5,4,3]  R2015     -2.1473422646522522e-02
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R1860     -1
    z[5,4,4]  R1861     1
    z[5,4,4]  R1866     -4.9649411439895630e-01
    z[5,4,4]  R1867     1.1810000985860825e-01
    z[5,4,4]  R1868     1.3310475647449493e-01
    z[5,4,4]  R1869     8.4359832108020782e-02
    z[5,4,4]  R1870     -4.6351256966590881e-01
    z[5,4,4]  R1871     3.5189583897590637e-02
    z[5,4,4]  R1872     -4.7536338679492474e-03
    z[5,4,4]  R1873     -3.2184287905693054e-01
    z[5,4,4]  R1874     -2.9385346174240112e-01
    z[5,4,4]  R1875     1.8281698226928711e-01
    z[5,4,4]  R1876     3.9884322881698608e-01
    z[5,4,4]  R1877     -2.9343074560165405e-01
    z[5,4,4]  R1878     3.8863825798034668e-01
    z[5,4,4]  R1879     2.7067816257476807e-01
    z[5,4,4]  R1880     4.4900488853454590e-01
    z[5,4,4]  R1881     -8.3619825541973114e-02
    z[5,4,4]  R1882     -2.3037960752844810e-02
    z[5,4,4]  R1883     3.0328243970870972e-01
    z[5,4,4]  R1884     3.40327387675643e-05
    z[5,4,4]  R1885     -3.4083715081214905e-01
    z[5,4,4]  R1886     -7.6309517025947571e-02
    z[5,4,4]  R1887     5.1374042034149170e-01
    z[5,4,4]  R1888     7.8781759738922119e-01
    z[5,4,4]  R1889     4.6057271957397461e-01
    z[5,4,4]  R1890     5.6694155931472778e-01
    z[5,4,4]  R1891     -2.1398362517356873e-01
    z[5,4,4]  R1892     4.3669030070304871e-01
    z[5,4,4]  R1893     1.5598259866237640e-01
    z[5,4,4]  R1894     3.8553100824356079e-01
    z[5,4,4]  R1895     -1.8345834314823151e-01
    z[5,4,4]  R1896     0.532383382320404
    z[5,4,4]  R1897     -4.1586235165596008e-02
    z[5,4,4]  R1898     -5.6828784942626953e-01
    z[5,4,4]  R1899     2.2176005877554417e-03
    z[5,4,4]  R1900     2.5891074538230896e-01
    z[5,4,4]  R1901     3.6979028582572937e-01
    z[5,4,4]  R1902     -1.9570612907409668e-01
    z[5,4,4]  R1903     1.4526385068893433e-01
    z[5,4,4]  R1904     -0.0417962521314621
    z[5,4,4]  R1905     -4.1301891207695007e-02
    z[5,4,4]  R1906     -3.4136778116226196e-01
    z[5,4,4]  R1907     2.4779860675334930e-01
    z[5,4,4]  R1908     1.4272421598434448e-01
    z[5,4,4]  R1909     -2.8095895051956177e-01
    z[5,4,4]  R1910     -3.1539839506149292e-01
    z[5,4,4]  R1911     2.5853142142295837e-02
    z[5,4,4]  R1912     -9.9958963692188263e-02
    z[5,4,4]  R1913     -1.9605672359466553e-01
    z[5,4,4]  R1914     -5.3230029344558716e-01
    z[5,4,4]  R1915     2.0194664597511292e-01
    z[5,4,4]  R1916     -1.1229781806468964e-01
    z[5,4,4]  R1917     6.3080765306949615e-02
    z[5,4,4]  R1918     -1.8942435085773468e-01
    z[5,4,4]  R1919     -0.02197265625
    z[5,4,4]  R1920     -3.7384482566267252e-03
    z[5,4,4]  R1921     -1.7954805493354797e-01
    z[5,4,4]  R1922     -8.7438896298408508e-02
    z[5,4,4]  R1923     -1.2091485410928726e-01
    z[5,4,4]  R1924     4.8610851168632507e-02
    z[5,4,4]  R1925     -0.0319192036986351
    z[5,4,4]  R1926     -2.9788926243782043e-01
    z[5,4,4]  R1927     -7.0884138345718384e-02
    z[5,4,4]  R1928     5.1153737306594849e-01
    z[5,4,4]  R1929     -1.3111691176891327e-01
    z[5,4,4]  R1930     2.8514513373374939e-01
    z[5,4,4]  R1931     7.4714952707290649e-01
    z[5,4,4]  R1932     -5.2574608474969864e-02
    z[5,4,4]  R1933     -7.8257076442241669e-02
    z[5,4,4]  R1934     -1.4152601361274719e-01
    z[5,4,4]  R1935     1.4653564989566803e-01
    z[5,4,4]  R1936     -8.0058827996253967e-02
    z[5,4,4]  R1937     -3.2889395952224731e-01
    z[5,4,4]  R1938     1.6888274252414703e-01
    z[5,4,4]  R1939     3.0916187912225723e-02
    z[5,4,4]  R1940     6.0891564935445786e-02
    z[5,4,4]  R1941     -7.6807349920272827e-02
    z[5,4,4]  R1942     2.4496786296367645e-01
    z[5,4,4]  R1943     -2.2143848240375519e-01
    z[5,4,4]  R1944     -4.8559615015983582e-01
    z[5,4,4]  R1945     1.0496097803115845e-01
    z[5,4,4]  R1946     4.4029909372329712e-01
    z[5,4,4]  R1947     2.6183375716209412e-01
    z[5,4,4]  R1948     4.5810022950172424e-01
    z[5,4,4]  R1949     2.1041291952133179e-01
    z[5,4,4]  R1950     3.3806860446929932e-01
    z[5,4,4]  R1951     3.3798319101333618e-01
    z[5,4,4]  R1952     -1.4776277542114258e-01
    z[5,4,4]  R1953     3.2203400135040283e-01
    z[5,4,4]  R1954     2.7713969349861145e-01
    z[5,4,4]  R1955     3.3040383458137512e-01
    z[5,4,4]  R1956     0.390125036239624
    z[5,4,4]  R1957     -2.9339954257011414e-01
    z[5,4,4]  R1958     1.7583616077899933e-02
    z[5,4,4]  R1959     -3.6412519216537476e-01
    z[5,4,4]  R1960     -3.0620199441909790e-01
    z[5,4,4]  R1961     2.9648987576365471e-02
    z[5,4,4]  R1962     -1.4477708935737610e-01
    z[5,4,4]  R1963     1.4104658365249634e-01
    z[5,4,4]  R1964     4.3017297983169556e-01
    z[5,4,4]  R1965     -4.6514311432838440e-01
    z[5,4,4]  R1966     -6.4739942550659180e-02
    z[5,4,4]  R1967     2.5175625085830688e-01
    z[5,4,4]  R1968     7.0959888398647308e-02
    z[5,4,4]  R1969     1.3857199251651764e-01
    z[5,4,4]  R1970     4.2542789131402969e-02
    z[5,4,4]  R1971     1.5082585811614990e-01
    z[5,4,4]  R1972     -2.6541644334793091e-01
    z[5,4,4]  R1973     -6.5167438983917236e-01
    z[5,4,4]  R1974     -2.3809868097305298e-01
    z[5,4,4]  R1975     -0.270989328622818
    z[5,4,4]  R1976     -1.4751519262790680e-01
    z[5,4,4]  R1977     -1.9519133493304253e-02
    z[5,4,4]  R1978     6.2137889862060547e-01
    z[5,4,4]  R1979     0.0629318356513977
    z[5,4,4]  R1980     7.0032423734664917e-01
    z[5,4,4]  R1981     -2.3135535418987274e-01
    z[5,4,4]  R1982     4.7309298068284988e-02
    z[5,4,4]  R1983     -5.1250267028808594e-01
    z[5,4,4]  R1984     -4.1086863726377487e-02
    z[5,4,4]  R1985     -3.5745996236801147e-01
    z[5,4,4]  R1986     5.9184902906417847e-01
    z[5,4,4]  R1987     -5.3945183753967285e-01
    z[5,4,4]  R1988     2.9631805419921875e-01
    z[5,4,4]  R1989     5.0382214784622192e-01
    z[5,4,4]  R1990     0.403598815202713
    z[5,4,4]  R1991     -3.8055527955293655e-02
    z[5,4,4]  R1992     -6.3370861113071442e-02
    z[5,4,4]  R1993     -2.5565892457962036e-01
    z[5,4,4]  R1994     -1.9228948652744293e-01
    z[5,4,4]  R1995     -4.3697637319564819e-01
    z[5,4,4]  R1996     -1.7640747129917145e-01
    z[5,4,4]  R1997     4.3317991495132446e-01
    z[5,4,4]  R1998     2.0805180072784424e-01
    z[5,4,4]  R1999     -3.6709362268447876e-01
    z[5,4,4]  R2000     -6.5922670066356659e-02
    z[5,4,4]  R2001     -1.8420684337615967e-01
    z[5,4,4]  R2002     -1.3740763068199158e-01
    z[5,4,4]  R2003     -3.3324441313743591e-01
    z[5,4,4]  R2004     2.2193701565265656e-01
    z[5,4,4]  R2005     4.1295105218887329e-01
    z[5,4,4]  R2006     3.7466433644294739e-01
    z[5,4,4]  R2007     2.1136064827442169e-01
    z[5,4,4]  R2008     -1.1301765590906143e-01
    z[5,4,4]  R2009     -7.4604131281375885e-02
    z[5,4,4]  R2010     -1.2201914936304092e-01
    z[5,4,4]  R2011     -2.5154781341552734e-01
    z[5,4,4]  R2012     2.3446790874004364e-02
    z[5,4,4]  R2013     -4.3253622949123383e-02
    z[5,4,4]  R2014     -7.5459247827529907e-01
    z[5,4,4]  R2015     -2.3766717314720154e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R1862     -1
    z[5,4,5]  R1863     1
    z[5,4,5]  R1866     -7.8130595386028290e-02
    z[5,4,5]  R1867     1.4234589040279388e-01
    z[5,4,5]  R1868     -3.3693760633468628e-01
    z[5,4,5]  R1869     5.5766922235488892e-01
    z[5,4,5]  R1870     6.7910814285278320e-01
    z[5,4,5]  R1871     -1.8487884104251862e-01
    z[5,4,5]  R1872     1.3950876891613007e-01
    z[5,4,5]  R1873     5.5017095059156418e-02
    z[5,4,5]  R1874     2.2003208100795746e-01
    z[5,4,5]  R1875     3.1087648868560791e-01
    z[5,4,5]  R1876     -1.1001148819923401e-01
    z[5,4,5]  R1877     8.1487350165843964e-02
    z[5,4,5]  R1878     -5.5850189924240112e-01
    z[5,4,5]  R1879     3.2151535153388977e-01
    z[5,4,5]  R1880     4.4339734315872192e-01
    z[5,4,5]  R1881     -1.7229861021041870e-01
    z[5,4,5]  R1882     1.3593678176403046e-01
    z[5,4,5]  R1883     3.6164857447147369e-02
    z[5,4,5]  R1884     2.2967378795146942e-01
    z[5,4,5]  R1885     -2.3985219001770020e-01
    z[5,4,5]  R1886     5.4262804985046387e-01
    z[5,4,5]  R1887     3.1515711545944214e-01
    z[5,4,5]  R1888     -2.7135422825813293e-01
    z[5,4,5]  R1889     -1.4030887186527252e-01
    z[5,4,5]  R1890     -2.7354758977890015e-01
    z[5,4,5]  R1891     -3.7637513875961304e-01
    z[5,4,5]  R1892     -0.635583221912384
    z[5,4,5]  R1893     -7.9247075319290161e-01
    z[5,4,5]  R1894     -5.3739106655120850e-01
    z[5,4,5]  R1895     -4.6171960234642029e-01
    z[5,4,5]  R1896     -4.7379118204116821e-01
    z[5,4,5]  R1897     -6.2867230176925659e-01
    z[5,4,5]  R1898     -4.7461655735969543e-01
    z[5,4,5]  R1899     -3.1075629591941833e-01
    z[5,4,5]  R1900     -0.0666750892996788
    z[5,4,5]  R1901     1.2726147472858429e-01
    z[5,4,5]  R1902     -1.4552277512848377e-02
    z[5,4,5]  R1903     2.5573673844337463e-01
    z[5,4,5]  R1904     -2.8836706653237343e-02
    z[5,4,5]  R1905     -3.0305409431457520e-01
    z[5,4,5]  R1906     1.4619396626949310e-01
    z[5,4,5]  R1907     8.3432635292410851e-03
    z[5,4,5]  R1908     -3.1873792409896851e-01
    z[5,4,5]  R1909     -0.412521094083786
    z[5,4,5]  R1910     3.8313734531402588e-01
    z[5,4,5]  R1911     2.5273540616035461e-01
    z[5,4,5]  R1912     -9.6924573183059692e-02
    z[5,4,5]  R1913     3.6326035857200623e-01
    z[5,4,5]  R1914     0.0503445640206337
    z[5,4,5]  R1915     9.8870471119880676e-02
    z[5,4,5]  R1916     -3.9066934585571289e-01
    z[5,4,5]  R1917     4.0133652091026306e-01
    z[5,4,5]  R1918     -5.3068125247955322e-01
    z[5,4,5]  R1919     3.6689648032188416e-01
    z[5,4,5]  R1920     3.8520210981369019e-01
    z[5,4,5]  R1921     -2.2283075749874115e-01
    z[5,4,5]  R1922     7.2753116488456726e-02
    z[5,4,5]  R1923     -6.6692255437374115e-02
    z[5,4,5]  R1924     -9.6957378089427948e-02
    z[5,4,5]  R1925     1.5190611779689789e-01
    z[5,4,5]  R1926     3.0472227931022644e-01
    z[5,4,5]  R1927     2.5635793805122375e-01
    z[5,4,5]  R1928     3.2530602812767029e-01
    z[5,4,5]  R1929     2.4582125246524811e-01
    z[5,4,5]  R1930     4.6398699283599854e-02
    z[5,4,5]  R1931     -7.9258419573307037e-02
    z[5,4,5]  R1932     -0.0792100802063942
    z[5,4,5]  R1933     2.5551852583885193e-01
    z[5,4,5]  R1934     -4.8923354595899582e-02
    z[5,4,5]  R1935     6.8519569933414459e-02
    z[5,4,5]  R1936     4.3996194005012512e-01
    z[5,4,5]  R1937     1.3638377189636230e-01
    z[5,4,5]  R1938     1.2953966856002808e-01
    z[5,4,5]  R1939     -2.9613199830055237e-01
    z[5,4,5]  R1940     3.4899991750717163e-01
    z[5,4,5]  R1941     5.9517753124237061e-01
    z[5,4,5]  R1942     2.3161128163337708e-01
    z[5,4,5]  R1943     -4.0721100568771362e-01
    z[5,4,5]  R1944     -3.4148707985877991e-01
    z[5,4,5]  R1945     -3.5778522491455078e-01
    z[5,4,5]  R1946     2.3346321284770966e-01
    z[5,4,5]  R1947     2.4932387471199036e-01
    z[5,4,5]  R1948     -0.468799889087677
    z[5,4,5]  R1949     -5.3434497117996216e-01
    z[5,4,5]  R1950     -2.7919512987136841e-01
    z[5,4,5]  R1951     -1.7638374119997025e-02
    z[5,4,5]  R1952     2.4123069643974304e-01
    z[5,4,5]  R1953     4.2480829358100891e-01
    z[5,4,5]  R1954     3.2849079370498657e-01
    z[5,4,5]  R1955     4.7065045684576035e-02
    z[5,4,5]  R1956     -4.1814845800399780e-01
    z[5,4,5]  R1957     -1.1946523189544678e-01
    z[5,4,5]  R1958     2.0657652616500854e-01
    z[5,4,5]  R1959     3.6275589466094971e-01
    z[5,4,5]  R1960     -2.6349839568138123e-01
    z[5,4,5]  R1961     -2.0331963896751404e-01
    z[5,4,5]  R1962     -1.1794500052928925e-01
    z[5,4,5]  R1963     -2.4451753497123718e-01
    z[5,4,5]  R1964     -1.9577954709529877e-01
    z[5,4,5]  R1965     -1.5811967849731445e-01
    z[5,4,5]  R1966     -1.3639576733112335e-01
    z[5,4,5]  R1967     -1.7367477715015411e-01
    z[5,4,5]  R1968     -7.1926325559616089e-02
    z[5,4,5]  R1969     5.8834481984376907e-02
    z[5,4,5]  R1970     -3.8575258851051331e-01
    z[5,4,5]  R1971     1.8640126287937164e-01
    z[5,4,5]  R1972     -1.9208908081054688e-01
    z[5,4,5]  R1973     9.4959894195199013e-03
    z[5,4,5]  R1974     -4.9050965905189514e-01
    z[5,4,5]  R1975     -1.8015022575855255e-01
    z[5,4,5]  R1976     1.3386167585849762e-01
    z[5,4,5]  R1977     1.9392508268356323e-01
    z[5,4,5]  R1978     -1.4710029959678650e-01
    z[5,4,5]  R1979     3.9358285069465637e-01
    z[5,4,5]  R1980     1.0863801091909409e-01
    z[5,4,5]  R1981     2.9338070750236511e-01
    z[5,4,5]  R1982     -2.4932403862476349e-01
    z[5,4,5]  R1983     0.0312016773968935
    z[5,4,5]  R1984     -1.0448420047760010e-01
    z[5,4,5]  R1985     -2.6090928912162781e-01
    z[5,4,5]  R1986     -4.5123159885406494e-01
    z[5,4,5]  R1987     1.0680218786001205e-01
    z[5,4,5]  R1988     3.6879318952560425e-01
    z[5,4,5]  R1989     3.6878335475921631e-01
    z[5,4,5]  R1990     4.9595287442207336e-01
    z[5,4,5]  R1991     0.0912671834230423
    z[5,4,5]  R1992     -8.0275140702724457e-02
    z[5,4,5]  R1993     -4.5369642972946167e-01
    z[5,4,5]  R1994     -2.5563132762908936e-01
    z[5,4,5]  R1995     -2.3328320682048798e-01
    z[5,4,5]  R1996     -3.4196230769157410e-01
    z[5,4,5]  R1997     4.2532852292060852e-01
    z[5,4,5]  R1998     6.9031155109405518e-01
    z[5,4,5]  R1999     -1.7529079318046570e-01
    z[5,4,5]  R2000     7.0834594964981079e-01
    z[5,4,5]  R2001     -0.0642034187912941
    z[5,4,5]  R2002     -2.3047627508640289e-01
    z[5,4,5]  R2003     2.0053030550479889e-01
    z[5,4,5]  R2004     4.4623672962188721e-01
    z[5,4,5]  R2005     -5.2082806825637817e-01
    z[5,4,5]  R2006     -1.2185101397335529e-02
    z[5,4,5]  R2007     -1.5581482648849487e-01
    z[5,4,5]  R2008     1.8800030648708344e-01
    z[5,4,5]  R2009     -5.2067607641220093e-02
    z[5,4,5]  R2010     -9.7791932523250580e-02
    z[5,4,5]  R2011     -1.1437275260686874e-01
    z[5,4,5]  R2012     -4.0624892711639404e-01
    z[5,4,5]  R2013     -2.7359002828598022e-01
    z[5,4,5]  R2014     3.7848973274230957e-01
    z[5,4,5]  R2015     -4.9476027488708496e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R1864     -1
    z[5,4,6]  R1865     1
    z[5,4,6]  R1866     -3.4480971097946167e-01
    z[5,4,6]  R1867     -3.8678294420242310e-01
    z[5,4,6]  R1868     4.1781640052795410e-01
    z[5,4,6]  R1869     3.9502507448196411e-01
    z[5,4,6]  R1870     1.5786762535572052e-01
    z[5,4,6]  R1871     -1.7694112658500671e-01
    z[5,4,6]  R1872     -3.9903020858764648e-01
    z[5,4,6]  R1873     1.5352848172187805e-01
    z[5,4,6]  R1874     -1.7421814799308777e-01
    z[5,4,6]  R1875     1.0770173370838165e-01
    z[5,4,6]  R1876     -1.5234698355197906e-01
    z[5,4,6]  R1877     1.7902514338493347e-01
    z[5,4,6]  R1878     -2.0524072647094727e-01
    z[5,4,6]  R1879     -1.2814530730247498e-01
    z[5,4,6]  R1880     6.4170587062835693e-01
    z[5,4,6]  R1881     8.4600344300270081e-02
    z[5,4,6]  R1882     -4.2167651653289795e-01
    z[5,4,6]  R1883     3.8686826825141907e-02
    z[5,4,6]  R1884     -3.7207841873168945e-01
    z[5,4,6]  R1885     1.6291812062263489e-01
    z[5,4,6]  R1886     2.5581473112106323e-01
    z[5,4,6]  R1887     -2.8113466501235962e-01
    z[5,4,6]  R1888     1.2849248945713043e-01
    z[5,4,6]  R1889     1.2341749854385853e-02
    z[5,4,6]  R1890     1.4303857088088989e-01
    z[5,4,6]  R1891     2.7706572413444519e-01
    z[5,4,6]  R1892     -2.9784819483757019e-01
    z[5,4,6]  R1893     1.5759864449501038e-01
    z[5,4,6]  R1894     -6.2524974346160889e-01
    z[5,4,6]  R1895     0.231205552816391
    z[5,4,6]  R1896     -2.3779509961605072e-01
    z[5,4,6]  R1897     -0.264913946390152
    z[5,4,6]  R1898     1.5839265286922455e-01
    z[5,4,6]  R1899     3.4261947870254517e-01
    z[5,4,6]  R1900     -1.1964618414640427e-01
    z[5,4,6]  R1901     2.7611851692199707e-01
    z[5,4,6]  R1902     -1.7255797982215881e-01
    z[5,4,6]  R1903     -7.1088634431362152e-02
    z[5,4,6]  R1904     -3.6511799693107605e-01
    z[5,4,6]  R1905     -1.8450810015201569e-01
    z[5,4,6]  R1906     7.3461544513702393e-01
    z[5,4,6]  R1907     3.4221544861793518e-01
    z[5,4,6]  R1908     -8.4001637995243073e-02
    z[5,4,6]  R1909     4.1955387592315674e-01
    z[5,4,6]  R1910     -3.3530315756797791e-01
    z[5,4,6]  R1911     -6.4525239169597626e-02
    z[5,4,6]  R1912     -1.1844666302204132e-01
    z[5,4,6]  R1913     2.2946875542402267e-02
    z[5,4,6]  R1914     1.7470799386501312e-01
    z[5,4,6]  R1915     3.7696731090545654e-01
    z[5,4,6]  R1916     8.7144136428833008e-02
    z[5,4,6]  R1917     -1.6616840660572052e-01
    z[5,4,6]  R1918     4.3904036283493042e-01
    z[5,4,6]  R1919     -1.6719458997249603e-01
    z[5,4,6]  R1920     8.3646379411220551e-02
    z[5,4,6]  R1921     -1.4737313613295555e-02
    z[5,4,6]  R1922     1.3662087917327881e-01
    z[5,4,6]  R1923     2.6793381571769714e-01
    z[5,4,6]  R1924     -1.0554116219282150e-01
    z[5,4,6]  R1925     -5.7056136429309845e-03
    z[5,4,6]  R1926     3.1772968173027039e-01
    z[5,4,6]  R1927     3.4137552976608276e-01
    z[5,4,6]  R1928     2.6968577504158020e-01
    z[5,4,6]  R1929     2.6858061552047729e-01
    z[5,4,6]  R1930     3.4463077783584595e-02
    z[5,4,6]  R1931     1.0873294621706009e-01
    z[5,4,6]  R1932     -1.1475966870784760e-01
    z[5,4,6]  R1933     -3.2617077231407166e-01
    z[5,4,6]  R1934     -7.7605910599231720e-02
    z[5,4,6]  R1935     -3.3081090450286865e-01
    z[5,4,6]  R1936     1.2092879414558411e-01
    z[5,4,6]  R1937     -2.3068059980869293e-01
    z[5,4,6]  R1938     1.8213900923728943e-01
    z[5,4,6]  R1939     3.6324393749237061e-01
    z[5,4,6]  R1940     -1.2739732861518860e-01
    z[5,4,6]  R1941     2.5307485461235046e-01
    z[5,4,6]  R1942     -6.4232259988784790e-01
    z[5,4,6]  R1943     -3.2322937250137329e-01
    z[5,4,6]  R1944     1.9452343881130219e-01
    z[5,4,6]  R1945     -0.318782240152359
    z[5,4,6]  R1946     -6.1196070909500122e-01
    z[5,4,6]  R1947     0.0861247330904007
    z[5,4,6]  R1948     -2.1181281656026840e-02
    z[5,4,6]  R1949     -8.9917801320552826e-02
    z[5,4,6]  R1950     3.7962636351585388e-01
    z[5,4,6]  R1951     2.5793942809104919e-01
    z[5,4,6]  R1952     -1.3838969171047211e-01
    z[5,4,6]  R1953     -2.6035052537918091e-01
    z[5,4,6]  R1954     -2.1527664363384247e-01
    z[5,4,6]  R1955     -1.9274526834487915e-01
    z[5,4,6]  R1956     3.0488187074661255e-01
    z[5,4,6]  R1957     -4.4549646973609924e-01
    z[5,4,6]  R1958     1.5331450104713440e-01
    z[5,4,6]  R1959     2.4077013134956360e-01
    z[5,4,6]  R1960     -4.4894075393676758e-01
    z[5,4,6]  R1961     -9.9124290049076080e-02
    z[5,4,6]  R1962     -2.7765509486198425e-01
    z[5,4,6]  R1963     4.5793330669403076e-01
    z[5,4,6]  R1964     3.8040235638618469e-02
    z[5,4,6]  R1965     2.1705214679241180e-01
    z[5,4,6]  R1966     4.0557637810707092e-02
    z[5,4,6]  R1967     -6.5903581678867340e-02
    z[5,4,6]  R1968     5.5676591396331787e-01
    z[5,4,6]  R1969     3.0735790729522705e-02
    z[5,4,6]  R1970     -2.5501903891563416e-01
    z[5,4,6]  R1971     2.4466918781399727e-02
    z[5,4,6]  R1972     -6.1453711986541748e-01
    z[5,4,6]  R1973     2.9225218296051025e-01
    z[5,4,6]  R1974     -2.2415725886821747e-01
    z[5,4,6]  R1975     -1.3678628206253052e-01
    z[5,4,6]  R1976     5.1763290166854858e-01
    z[5,4,6]  R1977     2.1968476474285126e-02
    z[5,4,6]  R1978     2.5014054775238037e-01
    z[5,4,6]  R1979     -6.4311426877975464e-01
    z[5,4,6]  R1980     -1.0943056643009186e-01
    z[5,4,6]  R1981     -3.7771737575531006e-01
    z[5,4,6]  R1982     -4.3297520279884338e-01
    z[5,4,6]  R1983     3.5609375685453415e-02
    z[5,4,6]  R1984     -9.5370374619960785e-03
    z[5,4,6]  R1985     2.8886166214942932e-01
    z[5,4,6]  R1986     -4.4588279724121094e-01
    z[5,4,6]  R1987     -5.8686070144176483e-02
    z[5,4,6]  R1988     -4.7766438126564026e-01
    z[5,4,6]  R1989     1.3234890997409821e-01
    z[5,4,6]  R1990     4.6327769756317139e-01
    z[5,4,6]  R1991     -2.1402609348297119e-01
    z[5,4,6]  R1992     5.1475517451763153e-02
    z[5,4,6]  R1993     -5.3200449794530869e-02
    z[5,4,6]  R1994     1.6672787070274353e-01
    z[5,4,6]  R1995     2.4014633893966675e-01
    z[5,4,6]  R1996     1.1975119262933731e-01
    z[5,4,6]  R1997     3.3051747083663940e-01
    z[5,4,6]  R1998     -4.1553658246994019e-01
    z[5,4,6]  R1999     -3.8281965255737305e-01
    z[5,4,6]  R2000     3.4816227853298187e-02
    z[5,4,6]  R2001     2.9397544264793396e-01
    z[5,4,6]  R2002     -3.5653370618820190e-01
    z[5,4,6]  R2003     -6.6828310489654541e-02
    z[5,4,6]  R2004     2.8323090076446533e-01
    z[5,4,6]  R2005     3.3723458647727966e-01
    z[5,4,6]  R2006     3.4797167778015137e-01
    z[5,4,6]  R2007     7.8672267496585846e-02
    z[5,4,6]  R2008     1.8038541078567505e-01
    z[5,4,6]  R2009     5.5920296907424927e-01
    z[5,4,6]  R2010     2.2989727556705475e-01
    z[5,4,6]  R2011     4.3185658752918243e-02
    z[5,4,6]  R2012     -1.3556602597236633e-01
    z[5,4,6]  R2013     -0.26072958111763
    z[5,4,6]  R2014     -4.4539049267768860e-02
    z[5,4,6]  R2015     2.6188188791275024e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2110     -1
    z[5,6,0]  R2111     1
    z[5,6,0]  R2124     2.3319423198699951e-01
    z[5,6,0]  R2125     3.1212385743856430e-02
    z[5,6,0]  R2126     5.0146347284317017e-01
    z[5,6,0]  R2127     -3.9650425314903259e-02
    z[5,6,0]  R2128     3.2497721910476685e-01
    z[5,6,0]  R2129     -4.7212675213813782e-01
    z[5,6,0]  R2130     -3.6578410863876343e-01
    z[5,6,0]  R2131     -2.6424747705459595e-01
    z[5,6,0]  R2132     -4.2607155442237854e-01
    z[5,6,0]  R2133     -4.7789987921714783e-01
    z[5,6,0]  R2134     8.5370033979415894e-01
    z[5,6,0]  R2135     7.5417733192443848e-01
    z[5,6,0]  R2136     3.1483504176139832e-01
    z[5,6,0]  R2137     5.8094173669815063e-01
    z[5,6,0]  R2138     3.3036491274833679e-01
    z[5,6,0]  R2139     6.6223418712615967e-01
    z[5,6,0]  R2140     6.2715351581573486e-01
    z[5,6,0]  R2141     5.4246836900711060e-01
    z[5,6,0]  R2142     5.1179546117782593e-01
    z[5,6,0]  R2143     -8.4287482500076294e-01
    z[5,6,0]  R2144     5.6227583438158035e-02
    z[5,6,0]  R2145     0.466959148645401
    z[5,6,0]  R2146     4.4979009032249451e-01
    z[5,6,0]  R2147     -2.8108501434326172e-01
    z[5,6,0]  R2148     -2.9995483160018921e-01
    z[5,6,0]  R2149     -0.602034330368042
    z[5,6,0]  R2150     -1.1290226131677628e-01
    z[5,6,0]  R2151     -1.3753145933151245e-01
    z[5,6,0]  R2152     3.4224852919578552e-01
    z[5,6,0]  R2153     -3.2606214284896851e-02
    z[5,6,0]  R2154     1.9191227853298187e-01
    z[5,6,0]  R2155     5.6973749399185181e-01
    z[5,6,0]  R2156     5.6437432765960693e-01
    z[5,6,0]  R2157     1.7782148718833923e-01
    z[5,6,0]  R2158     6.2057304382324219e-01
    z[5,6,0]  R2159     -4.2226108908653259e-01
    z[5,6,0]  R2160     3.5937055945396423e-01
    z[5,6,0]  R2161     -6.2501597404479980e-01
    z[5,6,0]  R2162     -8.5845166444778442e-01
    z[5,6,0]  R2163     -8.0257123708724976e-01
    z[5,6,0]  R2164     5.3197562694549561e-01
    z[5,6,0]  R2165     -0.451295405626297
    z[5,6,0]  R2166     1.1656672693789005e-02
    z[5,6,0]  R2167     -1.8033067882061005e-01
    z[5,6,0]  R2168     3.9501029253005981e-01
    z[5,6,0]  R2169     -8.9244616031646729e-01
    z[5,6,0]  R2170     -9.4487506151199341e-01
    z[5,6,0]  R2171     4.1145300865173340e-01
    z[5,6,0]  R2172     -7.8592562675476074e-01
    z[5,6,0]  R2173     -8.4297996759414673e-01
    z[5,6,0]  R2174     8.0484122037887573e-01
    z[5,6,0]  R2175     6.7473107576370239e-01
    z[5,6,0]  R2176     -1.7581452429294586e-01
    z[5,6,0]  R2177     -5.6763684749603271e-01
    z[5,6,0]  R2178     3.8825148344039917e-01
    z[5,6,0]  R2179     -8.9772361516952515e-01
    z[5,6,0]  R2180     -9.2428743839263916e-01
    z[5,6,0]  R2181     0.092893086373806
    z[5,6,0]  R2182     7.4307754635810852e-02
    z[5,6,0]  R2183     0.00360292661935091
    z[5,6,0]  R2184     5.5153167247772217e-01
    z[5,6,0]  R2185     4.4846823811531067e-01
    z[5,6,0]  R2186     6.7341423034667969e-01
    z[5,6,0]  R2187     1.3346501626074314e-02
    z[5,6,0]  R2188     -1.4611147344112396e-01
    z[5,6,0]  R2189     1.4871416985988617e-01
    z[5,6,0]  R2190     -5.1569759845733643e-01
    z[5,6,0]  R2191     4.4647574424743652e-01
    z[5,6,0]  R2192     -8.4457063674926758e-01
    z[5,6,0]  R2193     2.1097144484519958e-01
    z[5,6,0]  R2194     -9.5095962285995483e-01
    z[5,6,0]  R2195     -3.8825187087059021e-01
    z[5,6,0]  R2196     -2.3978874087333679e-01
    z[5,6,0]  R2197     1.6710342466831207e-01
    z[5,6,0]  R2198     2.8404712677001953e-01
    z[5,6,0]  R2199     2.9723849892616272e-01
    z[5,6,0]  R2200     6.2656593322753906e-01
    z[5,6,0]  R2201     1.1219176463782787e-02
    z[5,6,0]  R2202     1.8677452206611633e-01
    z[5,6,0]  R2203     0.550543487071991
    z[5,6,0]  R2204     1.8886448442935944e-01
    z[5,6,0]  R2205     -6.4570712856948376e-03
    z[5,6,0]  R2206     2.7725443243980408e-01
    z[5,6,0]  R2207     2.5733324885368347e-01
    z[5,6,0]  R2208     7.8082323074340820e-02
    z[5,6,0]  R2209     5.3646814823150635e-01
    z[5,6,0]  R2210     5.1410341262817383e-01
    z[5,6,0]  R2211     2.5004863739013672e-01
    z[5,6,0]  R2212     1.8717832863330841e-01
    z[5,6,0]  R2213     4.9351686239242554e-01
    z[5,6,0]  R2214     0.843866765499115
    z[5,6,0]  R2215     9.6066212654113770e-01
    z[5,6,0]  R2216     7.6397955417633057e-01
    z[5,6,0]  R2217     6.9568783044815063e-01
    z[5,6,0]  R2218     6.3381779193878174e-01
    z[5,6,0]  R2219     0.615824282169342
    z[5,6,0]  R2220     8.6231148242950439e-01
    z[5,6,0]  R2221     7.6351469755172729e-01
    z[5,6,0]  R2222     7.1476262807846069e-01
    z[5,6,0]  R2223     8.1911158561706543e-01
    z[5,6,0]  R2224     1.2703747488558292e-02
    z[5,6,0]  R2225     -9.0676330029964447e-02
    z[5,6,0]  R2226     3.0208784341812134e-01
    z[5,6,0]  R2227     8.7010359764099121e-01
    z[5,6,0]  R2228     7.5612837076187134e-01
    z[5,6,0]  R2229     1.2356323748826981e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2112     -1
    z[5,6,1]  R2113     1
    z[5,6,1]  R2124     -1.7011912167072296e-01
    z[5,6,1]  R2125     -8.6639535427093506e-01
    z[5,6,1]  R2126     -3.2488226890563965e-01
    z[5,6,1]  R2127     1.2755459547042847e-01
    z[5,6,1]  R2128     2.5161633267998695e-02
    z[5,6,1]  R2129     7.1684432029724121e-01
    z[5,6,1]  R2130     6.4251607656478882e-01
    z[5,6,1]  R2131     8.6258381605148315e-01
    z[5,6,1]  R2132     6.1642372608184814e-01
    z[5,6,1]  R2133     5.8614504337310791e-01
    z[5,6,1]  R2134     4.1367597877979279e-02
    z[5,6,1]  R2135     -4.5734432339668274e-01
    z[5,6,1]  R2136     5.3213047981262207e-01
    z[5,6,1]  R2137     6.7137241363525391e-01
    z[5,6,1]  R2138     -1.1954019963741302e-01
    z[5,6,1]  R2139     5.8716768026351929e-01
    z[5,6,1]  R2140     5.6276440620422363e-01
    z[5,6,1]  R2141     6.0371154546737671e-01
    z[5,6,1]  R2142     5.2918326854705811e-01
    z[5,6,1]  R2143     -1.8518170714378357e-01
    z[5,6,1]  R2144     -6.4127451181411743e-01
    z[5,6,1]  R2145     -7.6162025332450867e-02
    z[5,6,1]  R2146     -1.2833869457244873e-01
    z[5,6,1]  R2147     3.6129736900329590e-01
    z[5,6,1]  R2148     1.2361064553260803e-01
    z[5,6,1]  R2149     3.2340753078460693e-01
    z[5,6,1]  R2150     3.2106035947799683e-01
    z[5,6,1]  R2151     4.2450046539306641e-01
    z[5,6,1]  R2152     -7.9346306622028351e-02
    z[5,6,1]  R2153     6.7537516355514526e-01
    z[5,6,1]  R2154     -6.3041225075721741e-02
    z[5,6,1]  R2155     -3.1974253058433533e-01
    z[5,6,1]  R2156     -1.6818445920944214e-01
    z[5,6,1]  R2157     0.717118501663208
    z[5,6,1]  R2158     6.3430160284042358e-01
    z[5,6,1]  R2159     7.5796818733215332e-01
    z[5,6,1]  R2160     0.55787593126297
    z[5,6,1]  R2161     5.8910822868347168e-01
    z[5,6,1]  R2162     -1.9215551018714905e-01
    z[5,6,1]  R2163     -1.7271377146244049e-01
    z[5,6,1]  R2164     -2.1072624251246452e-02
    z[5,6,1]  R2165     5.2754455804824829e-01
    z[5,6,1]  R2166     8.9360141754150391e-01
    z[5,6,1]  R2167     5.8269160985946655e-01
    z[5,6,1]  R2168     4.3497118353843689e-01
    z[5,6,1]  R2169     -2.5367984175682068e-01
    z[5,6,1]  R2170     -2.0710146427154541e-01
    z[5,6,1]  R2171     6.7916643619537354e-01
    z[5,6,1]  R2172     -1.5099413692951202e-01
    z[5,6,1]  R2173     -2.0377218723297119e-01
    z[5,6,1]  R2174     -1.9711072742938995e-01
    z[5,6,1]  R2175     -5.8636730909347534e-01
    z[5,6,1]  R2176     4.9011856317520142e-01
    z[5,6,1]  R2177     6.4338010549545288e-01
    z[5,6,1]  R2178     5.1117801666259766e-01
    z[5,6,1]  R2179     -2.8135138750076294e-01
    z[5,6,1]  R2180     -9.9034756422042847e-02
    z[5,6,1]  R2181     6.2226468324661255e-01
    z[5,6,1]  R2182     0.603766918182373
    z[5,6,1]  R2183     3.4518954157829285e-01
    z[5,6,1]  R2184     -2.0193326473236084e-01
    z[5,6,1]  R2185     2.3295342922210693e-01
    z[5,6,1]  R2186     -2.8062483668327332e-01
    z[5,6,1]  R2187     -0.732764482498169
    z[5,6,1]  R2188     4.3333226442337036e-01
    z[5,6,1]  R2189     -4.5113921165466309e-01
    z[5,6,1]  R2190     7.9712599515914917e-01
    z[5,6,1]  R2191     5.5384212732315063e-01
    z[5,6,1]  R2192     -3.7367174029350281e-01
    z[5,6,1]  R2193     5.1363587379455566e-01
    z[5,6,1]  R2194     -0.0722980722784996
    z[5,6,1]  R2195     2.5028016418218613e-02
    z[5,6,1]  R2196     -1.0088376700878143e-01
    z[5,6,1]  R2197     -3.6120381951332092e-01
    z[5,6,1]  R2198     4.4236129522323608e-01
    z[5,6,1]  R2199     3.1871113181114197e-01
    z[5,6,1]  R2200     1.7556801438331604e-01
    z[5,6,1]  R2201     5.0601953268051147e-01
    z[5,6,1]  R2202     1.9762180745601654e-01
    z[5,6,1]  R2203     3.1977954506874084e-01
    z[5,6,1]  R2204     -2.9250057414174080e-02
    z[5,6,1]  R2205     0.819765567779541
    z[5,6,1]  R2206     5.5359399318695068e-01
    z[5,6,1]  R2207     6.2025868892669678e-01
    z[5,6,1]  R2208     6.3615089654922485e-01
    z[5,6,1]  R2209     7.1187084913253784e-01
    z[5,6,1]  R2210     7.2879642248153687e-01
    z[5,6,1]  R2211     8.9415103197097778e-01
    z[5,6,1]  R2212     7.7592229843139648e-01
    z[5,6,1]  R2213     6.9921773672103882e-01
    z[5,6,1]  R2214     1.6418632864952087e-01
    z[5,6,1]  R2215     1.1350983381271362e-01
    z[5,6,1]  R2216     1.4374969527125359e-02
    z[5,6,1]  R2217     1.8896361812949181e-02
    z[5,6,1]  R2218     -1.0968899726867676e-01
    z[5,6,1]  R2219     7.9908914864063263e-02
    z[5,6,1]  R2220     1.2101335078477859e-01
    z[5,6,1]  R2221     2.3778489232063293e-01
    z[5,6,1]  R2222     -3.0566531419754028e-01
    z[5,6,1]  R2223     1.9193220138549805e-01
    z[5,6,1]  R2224     -2.0066377520561218e-01
    z[5,6,1]  R2225     -4.3721985816955566e-01
    z[5,6,1]  R2226     3.8895231485366821e-01
    z[5,6,1]  R2227     4.8471488058567047e-02
    z[5,6,1]  R2228     7.3918804526329041e-02
    z[5,6,1]  R2229     -8.6846387386322021e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2114     -1
    z[5,6,2]  R2115     1
    z[5,6,2]  R2124     -4.4515646994113922e-02
    z[5,6,2]  R2125     -6.7482399754226208e-03
    z[5,6,2]  R2126     3.0095195770263672e-01
    z[5,6,2]  R2127     -1.4778596162796021e-01
    z[5,6,2]  R2128     -2.0170383155345917e-01
    z[5,6,2]  R2129     2.2534139454364777e-01
    z[5,6,2]  R2130     2.0300704240798950e-01
    z[5,6,2]  R2131     3.9781138300895691e-02
    z[5,6,2]  R2132     1.1528802663087845e-01
    z[5,6,2]  R2133     1.4067694544792175e-01
    z[5,6,2]  R2134     -2.7100220322608948e-01
    z[5,6,2]  R2135     1.5467441082000732e-01
    z[5,6,2]  R2136     1.6633830964565277e-01
    z[5,6,2]  R2137     5.3234919905662537e-02
    z[5,6,2]  R2138     7.6274409890174866e-02
    z[5,6,2]  R2139     1.8836699426174164e-01
    z[5,6,2]  R2140     9.8673895001411438e-02
    z[5,6,2]  R2141     2.5525781512260437e-01
    z[5,6,2]  R2142     4.3276599049568176e-01
    z[5,6,2]  R2143     -0.0498683899641037
    z[5,6,2]  R2144     -7.8489862382411957e-02
    z[5,6,2]  R2145     -5.3640075027942657e-02
    z[5,6,2]  R2146     2.6360502839088440e-01
    z[5,6,2]  R2147     -0.015627421438694
    z[5,6,2]  R2148     8.6594857275485992e-02
    z[5,6,2]  R2149     2.0107630640268326e-02
    z[5,6,2]  R2150     1.3167257606983185e-01
    z[5,6,2]  R2151     2.3699508607387543e-01
    z[5,6,2]  R2152     1.5364913642406464e-01
    z[5,6,2]  R2153     9.4399198889732361e-02
    z[5,6,2]  R2154     1.7879419028759003e-01
    z[5,6,2]  R2155     2.7754855155944824e-01
    z[5,6,2]  R2156     2.4555955827236176e-01
    z[5,6,2]  R2157     1.0720190405845642e-01
    z[5,6,2]  R2158     3.3301401138305664e-01
    z[5,6,2]  R2159     -1.0970806330442429e-01
    z[5,6,2]  R2160     6.7490625381469727e-01
    z[5,6,2]  R2161     -2.3787726461887360e-01
    z[5,6,2]  R2162     -1.8049703538417816e-01
    z[5,6,2]  R2163     -1.7838594317436218e-01
    z[5,6,2]  R2164     1.4784198999404907e-01
    z[5,6,2]  R2165     -6.0977645218372345e-02
    z[5,6,2]  R2166     3.1624818220734596e-03
    z[5,6,2]  R2167     9.3205235898494720e-02
    z[5,6,2]  R2168     5.4300391674041748e-01
    z[5,6,2]  R2169     -2.6401841640472412e-01
    z[5,6,2]  R2170     -1.2462133914232254e-01
    z[5,6,2]  R2171     -1.3151612877845764e-01
    z[5,6,2]  R2172     -1.8843559920787811e-01
    z[5,6,2]  R2173     -2.3226018249988556e-01
    z[5,6,2]  R2174     2.9141888022422791e-01
    z[5,6,2]  R2175     2.0411417353898287e-03
    z[5,6,2]  R2176     1.5482509136199951e-01
    z[5,6,2]  R2177     -3.1458556652069092e-01
    z[5,6,2]  R2178     6.1313390731811523e-01
    z[5,6,2]  R2179     -1.8113890290260315e-01
    z[5,6,2]  R2180     -2.2429031133651733e-01
    z[5,6,2]  R2181     0.0309981070458889
    z[5,6,2]  R2182     -1.3802379369735718e-02
    z[5,6,2]  R2183     -6.5438352525234222e-02
    z[5,6,2]  R2184     2.1384723484516144e-02
    z[5,6,2]  R2185     -5.4391520097851753e-03
    z[5,6,2]  R2186     1.1843720823526382e-01
    z[5,6,2]  R2187     5.1741704344749451e-02
    z[5,6,2]  R2188     -7.8318662941455841e-02
    z[5,6,2]  R2189     -4.4125726819038391e-01
    z[5,6,2]  R2190     -1.6930712759494781e-01
    z[5,6,2]  R2191     0.553565502166748
    z[5,6,2]  R2192     -2.5422206521034241e-01
    z[5,6,2]  R2193     -7.4339248239994049e-02
    z[5,6,2]  R2194     0.0282979104667902
    z[5,6,2]  R2195     -5.2341473102569580e-01
    z[5,6,2]  R2196     -4.5216062664985657e-01
    z[5,6,2]  R2197     -4.9157671630382538e-02
    z[5,6,2]  R2198     -5.1734607666730881e-02
    z[5,6,2]  R2199     4.8853954672813416e-01
    z[5,6,2]  R2200     4.7413924336433411e-01
    z[5,6,2]  R2201     -1.3056895136833191e-01
    z[5,6,2]  R2202     8.2681870460510254e-01
    z[5,6,2]  R2203     -2.5275078415870667e-01
    z[5,6,2]  R2204     -8.0532139539718628e-01
    z[5,6,2]  R2205     3.8588073849678040e-01
    z[5,6,2]  R2206     4.0774497389793396e-01
    z[5,6,2]  R2207     2.1162730455398560e-01
    z[5,6,2]  R2208     3.0113062262535095e-01
    z[5,6,2]  R2209     3.3778265118598938e-02
    z[5,6,2]  R2210     1.5527984499931335e-01
    z[5,6,2]  R2211     1.5874303877353668e-01
    z[5,6,2]  R2212     -2.2881576418876648e-01
    z[5,6,2]  R2213     -1.0315708070993423e-01
    z[5,6,2]  R2214     6.4307831227779388e-02
    z[5,6,2]  R2215     1.1087056249380112e-01
    z[5,6,2]  R2216     0.446425199508667
    z[5,6,2]  R2217     1.3924829661846161e-01
    z[5,6,2]  R2218     1.8533541262149811e-01
    z[5,6,2]  R2219     -2.3447409272193909e-01
    z[5,6,2]  R2220     3.3492076396942139e-01
    z[5,6,2]  R2221     5.4997056722640991e-01
    z[5,6,2]  R2222     1.4580713585019112e-02
    z[5,6,2]  R2223     1.8778862431645393e-02
    z[5,6,2]  R2224     5.2083246409893036e-02
    z[5,6,2]  R2225     -1.2135914713144302e-01
    z[5,6,2]  R2226     -1.8801812827587128e-01
    z[5,6,2]  R2227     3.1984856724739075e-01
    z[5,6,2]  R2228     6.3478773832321167e-01
    z[5,6,2]  R2229     9.6467465162277222e-02
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2116     -1
    z[5,6,3]  R2117     1
    z[5,6,3]  R2124     7.3701679706573486e-01
    z[5,6,3]  R2125     -2.5402450561523438e-01
    z[5,6,3]  R2126     4.9658772349357605e-01
    z[5,6,3]  R2127     6.9725221395492554e-01
    z[5,6,3]  R2128     3.9002344012260437e-01
    z[5,6,3]  R2129     3.8173970580101013e-01
    z[5,6,3]  R2130     4.8316952586174011e-01
    z[5,6,3]  R2131     2.3315073549747467e-01
    z[5,6,3]  R2132     5.0997787714004517e-01
    z[5,6,3]  R2133     5.1632338762283325e-01
    z[5,6,3]  R2134     -4.0670718997716904e-02
    z[5,6,3]  R2135     -2.7080744504928589e-01
    z[5,6,3]  R2136     0.29147869348526
    z[5,6,3]  R2137     -1.2598313391208649e-01
    z[5,6,3]  R2138     -2.4649222195148468e-01
    z[5,6,3]  R2139     -3.7062340974807739e-01
    z[5,6,3]  R2140     -2.8882077336311340e-01
    z[5,6,3]  R2141     -4.2581576108932495e-01
    z[5,6,3]  R2142     -2.8204908967018127e-01
    z[5,6,3]  R2143     -2.2921943664550781e-01
    z[5,6,3]  R2144     4.6231511235237122e-01
    z[5,6,3]  R2145     5.7530981302261353e-01
    z[5,6,3]  R2146     -3.0505027621984482e-02
    z[5,6,3]  R2147     0.747157871723175
    z[5,6,3]  R2148     6.8595755100250244e-01
    z[5,6,3]  R2149     0.518020510673523
    z[5,6,3]  R2150     4.2831945419311523e-01
    z[5,6,3]  R2151     2.5988447666168213e-01
    z[5,6,3]  R2152     1.5684854984283447e-01
    z[5,6,3]  R2153     4.8331776261329651e-01
    z[5,6,3]  R2154     6.0230517387390137e-01
    z[5,6,3]  R2155     0.170273557305336
    z[5,6,3]  R2156     0.139985129237175
    z[5,6,3]  R2157     4.7819033265113831e-01
    z[5,6,3]  R2158     -1.2592312693595886e-01
    z[5,6,3]  R2159     7.7215313911437988e-02
    z[5,6,3]  R2160     -1.8931412696838379e-01
    z[5,6,3]  R2161     -3.3788260817527771e-01
    z[5,6,3]  R2162     2.4014195799827576e-01
    z[5,6,3]  R2163     -0.408211886882782
    z[5,6,3]  R2164     -1.3090525567531586e-01
    z[5,6,3]  R2165     5.7941854000091553e-01
    z[5,6,3]  R2166     2.6890572905540466e-01
    z[5,6,3]  R2167     4.4059857726097107e-01
    z[5,6,3]  R2168     3.4857034683227539e-02
    z[5,6,3]  R2169     2.7813278138637543e-02
    z[5,6,3]  R2170     0.123990997672081
    z[5,6,3]  R2171     -4.2569947242736816e-01
    z[5,6,3]  R2172     8.7250366806983948e-02
    z[5,6,3]  R2173     3.5420853644609451e-02
    z[5,6,3]  R2174     -2.3585051298141479e-01
    z[5,6,3]  R2175     9.0801984071731567e-02
    z[5,6,3]  R2176     4.4118198752403259e-01
    z[5,6,3]  R2177     0.0428534559905529
    z[5,6,3]  R2178     2.3797746002674103e-01
    z[5,6,3]  R2179     -3.7355388049036264e-03
    z[5,6,3]  R2180     -2.3232486844062805e-01
    z[5,6,3]  R2181     -0.715779185295105
    z[5,6,3]  R2182     -7.7900612354278564e-01
    z[5,6,3]  R2183     -0.923267126083374
    z[5,6,3]  R2184     6.0994488000869751e-01
    z[5,6,3]  R2185     7.4652409553527832e-01
    z[5,6,3]  R2186     -1.1623510718345642e-01
    z[5,6,3]  R2187     -0.557176411151886
    z[5,6,3]  R2188     8.3671528100967407e-01
    z[5,6,3]  R2189     5.7553607970476151e-02
    z[5,6,3]  R2190     2.1857085824012756e-01
    z[5,6,3]  R2191     -9.8399199545383453e-02
    z[5,6,3]  R2192     2.3236854374408722e-01
    z[5,6,3]  R2193     -7.4198341369628906e-01
    z[5,6,3]  R2194     0.267132967710495
    z[5,6,3]  R2195     3.0779607594013214e-02
    z[5,6,3]  R2196     -3.4272590279579163e-01
    z[5,6,3]  R2197     6.7486268281936646e-01
    z[5,6,3]  R2198     1.5228098630905151e-01
    z[5,6,3]  R2199     1.2622157111763954e-02
    z[5,6,3]  R2200     -4.7008475661277771e-01
    z[5,6,3]  R2201     -4.0756049752235413e-01
    z[5,6,3]  R2202     1.7771768569946289e-01
    z[5,6,3]  R2203     -0.618504524230957
    z[5,6,3]  R2204     2.6850801706314087e-01
    z[5,6,3]  R2205     1.0088116675615311e-01
    z[5,6,3]  R2206     6.4829981327056885e-01
    z[5,6,3]  R2207     3.2371506094932556e-01
    z[5,6,3]  R2208     5.2549237012863159e-01
    z[5,6,3]  R2209     2.0769503712654114e-01
    z[5,6,3]  R2210     4.4571187347173691e-02
    z[5,6,3]  R2211     -1.3205616176128387e-01
    z[5,6,3]  R2212     0.346235990524292
    z[5,6,3]  R2213     4.0246415138244629e-01
    z[5,6,3]  R2214     -4.9635097384452820e-01
    z[5,6,3]  R2215     -1.0132275521755219e-01
    z[5,6,3]  R2216     -1.4031672477722168e-01
    z[5,6,3]  R2217     -6.2467378377914429e-01
    z[5,6,3]  R2218     -5.6475871801376343e-01
    z[5,6,3]  R2219     -0.703062117099762
    z[5,6,3]  R2220     -2.5502547621726990e-02
    z[5,6,3]  R2221     1.4709733426570892e-02
    z[5,6,3]  R2222     -3.2916980981826782e-01
    z[5,6,3]  R2223     -2.3925596848130226e-02
    z[5,6,3]  R2224     3.0170187354087830e-01
    z[5,6,3]  R2225     -3.6702793836593628e-01
    z[5,6,3]  R2226     0.603222131729126
    z[5,6,3]  R2227     1.5608014538884163e-02
    z[5,6,3]  R2228     0.00205458072014153
    z[5,6,3]  R2229     -1.8647766113281250e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2118     -1
    z[5,6,4]  R2119     1
    z[5,6,4]  R2124     -4.9649411439895630e-01
    z[5,6,4]  R2125     1.1810000985860825e-01
    z[5,6,4]  R2126     1.3310475647449493e-01
    z[5,6,4]  R2127     8.4359832108020782e-02
    z[5,6,4]  R2128     -4.6351256966590881e-01
    z[5,6,4]  R2129     3.5189583897590637e-02
    z[5,6,4]  R2130     -4.7536338679492474e-03
    z[5,6,4]  R2131     -3.2184287905693054e-01
    z[5,6,4]  R2132     -2.9385346174240112e-01
    z[5,6,4]  R2133     1.8281698226928711e-01
    z[5,6,4]  R2134     3.9884322881698608e-01
    z[5,6,4]  R2135     -2.9343074560165405e-01
    z[5,6,4]  R2136     3.8863825798034668e-01
    z[5,6,4]  R2137     2.7067816257476807e-01
    z[5,6,4]  R2138     4.4900488853454590e-01
    z[5,6,4]  R2139     -8.3619825541973114e-02
    z[5,6,4]  R2140     -2.3037960752844810e-02
    z[5,6,4]  R2141     3.0328243970870972e-01
    z[5,6,4]  R2142     3.40327387675643e-05
    z[5,6,4]  R2143     -3.4083715081214905e-01
    z[5,6,4]  R2144     -7.6309517025947571e-02
    z[5,6,4]  R2145     5.1374042034149170e-01
    z[5,6,4]  R2146     7.8781759738922119e-01
    z[5,6,4]  R2147     4.6057271957397461e-01
    z[5,6,4]  R2148     5.6694155931472778e-01
    z[5,6,4]  R2149     -2.1398362517356873e-01
    z[5,6,4]  R2150     4.3669030070304871e-01
    z[5,6,4]  R2151     1.5598259866237640e-01
    z[5,6,4]  R2152     3.8553100824356079e-01
    z[5,6,4]  R2153     -1.8345834314823151e-01
    z[5,6,4]  R2154     0.532383382320404
    z[5,6,4]  R2155     -4.1586235165596008e-02
    z[5,6,4]  R2156     -5.6828784942626953e-01
    z[5,6,4]  R2157     2.2176005877554417e-03
    z[5,6,4]  R2158     2.5891074538230896e-01
    z[5,6,4]  R2159     3.6979028582572937e-01
    z[5,6,4]  R2160     -1.9570612907409668e-01
    z[5,6,4]  R2161     1.4526385068893433e-01
    z[5,6,4]  R2162     -0.0417962521314621
    z[5,6,4]  R2163     -4.1301891207695007e-02
    z[5,6,4]  R2164     -3.4136778116226196e-01
    z[5,6,4]  R2165     2.4779860675334930e-01
    z[5,6,4]  R2166     1.4272421598434448e-01
    z[5,6,4]  R2167     -2.8095895051956177e-01
    z[5,6,4]  R2168     -3.1539839506149292e-01
    z[5,6,4]  R2169     2.5853142142295837e-02
    z[5,6,4]  R2170     -9.9958963692188263e-02
    z[5,6,4]  R2171     -1.9605672359466553e-01
    z[5,6,4]  R2172     -5.3230029344558716e-01
    z[5,6,4]  R2173     2.0194664597511292e-01
    z[5,6,4]  R2174     -1.1229781806468964e-01
    z[5,6,4]  R2175     6.3080765306949615e-02
    z[5,6,4]  R2176     -1.8942435085773468e-01
    z[5,6,4]  R2177     -0.02197265625
    z[5,6,4]  R2178     -3.7384482566267252e-03
    z[5,6,4]  R2179     -1.7954805493354797e-01
    z[5,6,4]  R2180     -8.7438896298408508e-02
    z[5,6,4]  R2181     -1.2091485410928726e-01
    z[5,6,4]  R2182     4.8610851168632507e-02
    z[5,6,4]  R2183     -0.0319192036986351
    z[5,6,4]  R2184     -2.9788926243782043e-01
    z[5,6,4]  R2185     -7.0884138345718384e-02
    z[5,6,4]  R2186     5.1153737306594849e-01
    z[5,6,4]  R2187     -1.3111691176891327e-01
    z[5,6,4]  R2188     2.8514513373374939e-01
    z[5,6,4]  R2189     7.4714952707290649e-01
    z[5,6,4]  R2190     -5.2574608474969864e-02
    z[5,6,4]  R2191     -7.8257076442241669e-02
    z[5,6,4]  R2192     -1.4152601361274719e-01
    z[5,6,4]  R2193     1.4653564989566803e-01
    z[5,6,4]  R2194     3.3808510750532150e-02
    z[5,6,4]  R2195     -4.5581620931625366e-01
    z[5,6,4]  R2196     -5.5690342187881470e-01
    z[5,6,4]  R2197     -1.4532133936882019e-01
    z[5,6,4]  R2198     6.2799870967864990e-02
    z[5,6,4]  R2199     -6.7526477575302124e-01
    z[5,6,4]  R2200     -3.2386317849159241e-01
    z[5,6,4]  R2201     0.0595785453915596
    z[5,6,4]  R2202     -1.4970295131206512e-01
    z[5,6,4]  R2203     8.8510274887084961e-02
    z[5,6,4]  R2204     3.0084443092346191e-01
    z[5,6,4]  R2205     -2.2026547789573669e-01
    z[5,6,4]  R2206     -7.0162400603294373e-02
    z[5,6,4]  R2207     -5.7761085033416748e-01
    z[5,6,4]  R2208     1.5189734101295471e-01
    z[5,6,4]  R2209     -2.0933844149112701e-01
    z[5,6,4]  R2210     -3.1712394952774048e-01
    z[5,6,4]  R2211     1.5083143115043640e-01
    z[5,6,4]  R2212     1.1382985860109329e-01
    z[5,6,4]  R2213     1.6336791217327118e-02
    z[5,6,4]  R2214     5.3791604936122894e-02
    z[5,6,4]  R2215     -1.8090879917144775e-01
    z[5,6,4]  R2216     4.5561593025922775e-02
    z[5,6,4]  R2217     3.0517336726188660e-01
    z[5,6,4]  R2218     -1.1205385625362396e-01
    z[5,6,4]  R2219     -1.6169063746929169e-02
    z[5,6,4]  R2220     3.0408045649528503e-01
    z[5,6,4]  R2221     -2.3713871836662292e-01
    z[5,6,4]  R2222     2.9085591435432434e-01
    z[5,6,4]  R2223     -2.2088031470775604e-01
    z[5,6,4]  R2224     6.3076955080032349e-01
    z[5,6,4]  R2225     5.7797265052795410e-01
    z[5,6,4]  R2226     -3.6340436339378357e-01
    z[5,6,4]  R2227     -2.0283286273479462e-01
    z[5,6,4]  R2228     -0.0535733737051487
    z[5,6,4]  R2229     -2.2956177592277527e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2120     -1
    z[5,6,5]  R2121     1
    z[5,6,5]  R2124     -7.8130595386028290e-02
    z[5,6,5]  R2125     1.4234589040279388e-01
    z[5,6,5]  R2126     -3.3693760633468628e-01
    z[5,6,5]  R2127     5.5766922235488892e-01
    z[5,6,5]  R2128     6.7910814285278320e-01
    z[5,6,5]  R2129     -1.8487884104251862e-01
    z[5,6,5]  R2130     1.3950876891613007e-01
    z[5,6,5]  R2131     5.5017095059156418e-02
    z[5,6,5]  R2132     2.2003208100795746e-01
    z[5,6,5]  R2133     3.1087648868560791e-01
    z[5,6,5]  R2134     -1.1001148819923401e-01
    z[5,6,5]  R2135     8.1487350165843964e-02
    z[5,6,5]  R2136     -5.5850189924240112e-01
    z[5,6,5]  R2137     3.2151535153388977e-01
    z[5,6,5]  R2138     4.4339734315872192e-01
    z[5,6,5]  R2139     -1.7229861021041870e-01
    z[5,6,5]  R2140     1.3593678176403046e-01
    z[5,6,5]  R2141     3.6164857447147369e-02
    z[5,6,5]  R2142     2.2967378795146942e-01
    z[5,6,5]  R2143     -2.3985219001770020e-01
    z[5,6,5]  R2144     5.4262804985046387e-01
    z[5,6,5]  R2145     3.1515711545944214e-01
    z[5,6,5]  R2146     -2.7135422825813293e-01
    z[5,6,5]  R2147     -1.4030887186527252e-01
    z[5,6,5]  R2148     -2.7354758977890015e-01
    z[5,6,5]  R2149     -3.7637513875961304e-01
    z[5,6,5]  R2150     -0.635583221912384
    z[5,6,5]  R2151     -7.9247075319290161e-01
    z[5,6,5]  R2152     -5.3739106655120850e-01
    z[5,6,5]  R2153     -4.6171960234642029e-01
    z[5,6,5]  R2154     -4.7379118204116821e-01
    z[5,6,5]  R2155     -6.2867230176925659e-01
    z[5,6,5]  R2156     -4.7461655735969543e-01
    z[5,6,5]  R2157     -3.1075629591941833e-01
    z[5,6,5]  R2158     -0.0666750892996788
    z[5,6,5]  R2159     1.2726147472858429e-01
    z[5,6,5]  R2160     -1.4552277512848377e-02
    z[5,6,5]  R2161     2.5573673844337463e-01
    z[5,6,5]  R2162     -2.8836706653237343e-02
    z[5,6,5]  R2163     -3.0305409431457520e-01
    z[5,6,5]  R2164     1.4619396626949310e-01
    z[5,6,5]  R2165     8.3432635292410851e-03
    z[5,6,5]  R2166     -3.1873792409896851e-01
    z[5,6,5]  R2167     -0.412521094083786
    z[5,6,5]  R2168     3.8313734531402588e-01
    z[5,6,5]  R2169     2.5273540616035461e-01
    z[5,6,5]  R2170     -9.6924573183059692e-02
    z[5,6,5]  R2171     3.6326035857200623e-01
    z[5,6,5]  R2172     0.0503445640206337
    z[5,6,5]  R2173     9.8870471119880676e-02
    z[5,6,5]  R2174     -3.9066934585571289e-01
    z[5,6,5]  R2175     4.0133652091026306e-01
    z[5,6,5]  R2176     -5.3068125247955322e-01
    z[5,6,5]  R2177     3.6689648032188416e-01
    z[5,6,5]  R2178     3.8520210981369019e-01
    z[5,6,5]  R2179     -2.2283075749874115e-01
    z[5,6,5]  R2180     7.2753116488456726e-02
    z[5,6,5]  R2181     -6.6692255437374115e-02
    z[5,6,5]  R2182     -9.6957378089427948e-02
    z[5,6,5]  R2183     1.5190611779689789e-01
    z[5,6,5]  R2184     3.0472227931022644e-01
    z[5,6,5]  R2185     2.5635793805122375e-01
    z[5,6,5]  R2186     3.2530602812767029e-01
    z[5,6,5]  R2187     2.4582125246524811e-01
    z[5,6,5]  R2188     4.6398699283599854e-02
    z[5,6,5]  R2189     -7.9258419573307037e-02
    z[5,6,5]  R2190     -0.0792100802063942
    z[5,6,5]  R2191     2.5551852583885193e-01
    z[5,6,5]  R2192     -4.8923354595899582e-02
    z[5,6,5]  R2193     6.8519569933414459e-02
    z[5,6,5]  R2194     -1.1698494106531143e-01
    z[5,6,5]  R2195     2.9426884651184082e-01
    z[5,6,5]  R2196     9.1682516038417816e-02
    z[5,6,5]  R2197     3.1403458118438721e-01
    z[5,6,5]  R2198     -8.0576866865158081e-01
    z[5,6,5]  R2199     3.3729836344718933e-01
    z[5,6,5]  R2200     1.5026065707206726e-01
    z[5,6,5]  R2201     -7.4081754684448242e-01
    z[5,6,5]  R2202     -1.6764244437217712e-01
    z[5,6,5]  R2203     -3.5321637988090515e-01
    z[5,6,5]  R2204     -3.3381393551826477e-01
    z[5,6,5]  R2205     -2.0318450033664703e-01
    z[5,6,5]  R2206     -1.5508468449115753e-01
    z[5,6,5]  R2207     9.6587009727954865e-02
    z[5,6,5]  R2208     -2.7794990688562393e-02
    z[5,6,5]  R2209     0.245323047041893
    z[5,6,5]  R2210     2.7847883105278015e-01
    z[5,6,5]  R2211     2.3506443202495575e-01
    z[5,6,5]  R2212     3.2918974757194519e-01
    z[5,6,5]  R2213     3.0537724494934082e-01
    z[5,6,5]  R2214     -3.2110888510942459e-02
    z[5,6,5]  R2215     6.4072795212268829e-02
    z[5,6,5]  R2216     3.2031017541885376e-01
    z[5,6,5]  R2217     1.0843108594417572e-01
    z[5,6,5]  R2218     4.6417227387428284e-01
    z[5,6,5]  R2219     1.3952548801898956e-01
    z[5,6,5]  R2220     -4.7300036996603012e-02
    z[5,6,5]  R2221     -0.0384240597486496
    z[5,6,5]  R2222     4.0608367323875427e-01
    z[5,6,5]  R2223     1.7650359869003296e-01
    z[5,6,5]  R2224     2.8615635633468628e-01
    z[5,6,5]  R2225     5.1913696527481079e-01
    z[5,6,5]  R2226     -4.7515466809272766e-01
    z[5,6,5]  R2227     2.8119641542434692e-01
    z[5,6,5]  R2228     8.9034624397754669e-02
    z[5,6,5]  R2229     -2.8502097725868225e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2122     -1
    z[5,6,6]  R2123     1
    z[5,6,6]  R2124     -3.4480971097946167e-01
    z[5,6,6]  R2125     -3.8678294420242310e-01
    z[5,6,6]  R2126     4.1781640052795410e-01
    z[5,6,6]  R2127     3.9502507448196411e-01
    z[5,6,6]  R2128     1.5786762535572052e-01
    z[5,6,6]  R2129     -1.7694112658500671e-01
    z[5,6,6]  R2130     -3.9903020858764648e-01
    z[5,6,6]  R2131     1.5352848172187805e-01
    z[5,6,6]  R2132     -1.7421814799308777e-01
    z[5,6,6]  R2133     1.0770173370838165e-01
    z[5,6,6]  R2134     -1.5234698355197906e-01
    z[5,6,6]  R2135     1.7902514338493347e-01
    z[5,6,6]  R2136     -2.0524072647094727e-01
    z[5,6,6]  R2137     -1.2814530730247498e-01
    z[5,6,6]  R2138     6.4170587062835693e-01
    z[5,6,6]  R2139     8.4600344300270081e-02
    z[5,6,6]  R2140     -4.2167651653289795e-01
    z[5,6,6]  R2141     3.8686826825141907e-02
    z[5,6,6]  R2142     -3.7207841873168945e-01
    z[5,6,6]  R2143     1.6291812062263489e-01
    z[5,6,6]  R2144     2.5581473112106323e-01
    z[5,6,6]  R2145     -2.8113466501235962e-01
    z[5,6,6]  R2146     1.2849248945713043e-01
    z[5,6,6]  R2147     1.2341749854385853e-02
    z[5,6,6]  R2148     1.4303857088088989e-01
    z[5,6,6]  R2149     2.7706572413444519e-01
    z[5,6,6]  R2150     -2.9784819483757019e-01
    z[5,6,6]  R2151     1.5759864449501038e-01
    z[5,6,6]  R2152     -6.2524974346160889e-01
    z[5,6,6]  R2153     0.231205552816391
    z[5,6,6]  R2154     -2.3779509961605072e-01
    z[5,6,6]  R2155     -0.264913946390152
    z[5,6,6]  R2156     1.5839265286922455e-01
    z[5,6,6]  R2157     3.4261947870254517e-01
    z[5,6,6]  R2158     -1.1964618414640427e-01
    z[5,6,6]  R2159     2.7611851692199707e-01
    z[5,6,6]  R2160     -1.7255797982215881e-01
    z[5,6,6]  R2161     -7.1088634431362152e-02
    z[5,6,6]  R2162     -3.6511799693107605e-01
    z[5,6,6]  R2163     -1.8450810015201569e-01
    z[5,6,6]  R2164     7.3461544513702393e-01
    z[5,6,6]  R2165     3.4221544861793518e-01
    z[5,6,6]  R2166     -8.4001637995243073e-02
    z[5,6,6]  R2167     4.1955387592315674e-01
    z[5,6,6]  R2168     -3.3530315756797791e-01
    z[5,6,6]  R2169     -6.4525239169597626e-02
    z[5,6,6]  R2170     -1.1844666302204132e-01
    z[5,6,6]  R2171     2.2946875542402267e-02
    z[5,6,6]  R2172     1.7470799386501312e-01
    z[5,6,6]  R2173     3.7696731090545654e-01
    z[5,6,6]  R2174     8.7144136428833008e-02
    z[5,6,6]  R2175     -1.6616840660572052e-01
    z[5,6,6]  R2176     4.3904036283493042e-01
    z[5,6,6]  R2177     -1.6719458997249603e-01
    z[5,6,6]  R2178     8.3646379411220551e-02
    z[5,6,6]  R2179     -1.4737313613295555e-02
    z[5,6,6]  R2180     1.3662087917327881e-01
    z[5,6,6]  R2181     2.6793381571769714e-01
    z[5,6,6]  R2182     -1.0554116219282150e-01
    z[5,6,6]  R2183     -5.7056136429309845e-03
    z[5,6,6]  R2184     3.1772968173027039e-01
    z[5,6,6]  R2185     3.4137552976608276e-01
    z[5,6,6]  R2186     2.6968577504158020e-01
    z[5,6,6]  R2187     2.6858061552047729e-01
    z[5,6,6]  R2188     3.4463077783584595e-02
    z[5,6,6]  R2189     1.0873294621706009e-01
    z[5,6,6]  R2190     -1.1475966870784760e-01
    z[5,6,6]  R2191     -3.2617077231407166e-01
    z[5,6,6]  R2192     -7.7605910599231720e-02
    z[5,6,6]  R2193     -3.3081090450286865e-01
    z[5,6,6]  R2194     -5.8817837387323380e-02
    z[5,6,6]  R2195     5.2854627370834351e-01
    z[5,6,6]  R2196     -5.4024678468704224e-01
    z[5,6,6]  R2197     -0.513824999332428
    z[5,6,6]  R2198     -2.1109430491924286e-01
    z[5,6,6]  R2199     -0.0385933518409729
    z[5,6,6]  R2200     5.7772211730480194e-02
    z[5,6,6]  R2201     9.1128058731555939e-02
    z[5,6,6]  R2202     -4.0041634440422058e-01
    z[5,6,6]  R2203     1.2496497482061386e-01
    z[5,6,6]  R2204     -2.0222863554954529e-01
    z[5,6,6]  R2205     2.8117766976356506e-01
    z[5,6,6]  R2206     -3.3778324723243713e-02
    z[5,6,6]  R2207     -2.3773482441902161e-01
    z[5,6,6]  R2208     4.4558718800544739e-01
    z[5,6,6]  R2209     -2.3907680809497833e-01
    z[5,6,6]  R2210     -1.8357668071985245e-02
    z[5,6,6]  R2211     1.3162803649902344e-01
    z[5,6,6]  R2212     -2.6334342360496521e-01
    z[5,6,6]  R2213     0.037345040589571
    z[5,6,6]  R2214     8.0668188631534576e-02
    z[5,6,6]  R2215     -6.9654747843742371e-02
    z[5,6,6]  R2216     3.0408850312232971e-01
    z[5,6,6]  R2217     -3.4142650663852692e-02
    z[5,6,6]  R2218     7.0212408900260925e-02
    z[5,6,6]  R2219     2.1300657093524933e-01
    z[5,6,6]  R2220     1.8506847321987152e-01
    z[5,6,6]  R2221     1.0416140779852867e-02
    z[5,6,6]  R2222     -1.9394992291927338e-01
    z[5,6,6]  R2223     0.459729939699173
    z[5,6,6]  R2224     6.2135362625122070e-01
    z[5,6,6]  R2225     2.1822814643383026e-01
    z[5,6,6]  R2226     1.9914092496037483e-02
    z[5,6,6]  R2227     1.3345773518085480e-01
    z[5,6,6]  R2228     -9.5125131309032440e-02
    z[5,6,6]  R2229     2.2910065948963165e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2230     -1
    z[6,5,0]  R2231     1
    z[6,5,0]  R2244     -9.5095962285995483e-01
    z[6,5,0]  R2245     -3.8825187087059021e-01
    z[6,5,0]  R2246     -2.3978874087333679e-01
    z[6,5,0]  R2247     1.6710342466831207e-01
    z[6,5,0]  R2248     2.8404712677001953e-01
    z[6,5,0]  R2249     2.9723849892616272e-01
    z[6,5,0]  R2250     6.2656593322753906e-01
    z[6,5,0]  R2251     1.1219176463782787e-02
    z[6,5,0]  R2252     1.8677452206611633e-01
    z[6,5,0]  R2253     0.550543487071991
    z[6,5,0]  R2254     1.8886448442935944e-01
    z[6,5,0]  R2255     -6.4570712856948376e-03
    z[6,5,0]  R2256     2.7725443243980408e-01
    z[6,5,0]  R2257     2.5733324885368347e-01
    z[6,5,0]  R2258     7.8082323074340820e-02
    z[6,5,0]  R2259     5.3646814823150635e-01
    z[6,5,0]  R2260     5.1410341262817383e-01
    z[6,5,0]  R2261     2.5004863739013672e-01
    z[6,5,0]  R2262     1.8717832863330841e-01
    z[6,5,0]  R2263     4.9351686239242554e-01
    z[6,5,0]  R2264     0.843866765499115
    z[6,5,0]  R2265     9.6066212654113770e-01
    z[6,5,0]  R2266     7.6397955417633057e-01
    z[6,5,0]  R2267     6.9568783044815063e-01
    z[6,5,0]  R2268     6.3381779193878174e-01
    z[6,5,0]  R2269     0.615824282169342
    z[6,5,0]  R2270     8.6231148242950439e-01
    z[6,5,0]  R2271     7.6351469755172729e-01
    z[6,5,0]  R2272     7.1476262807846069e-01
    z[6,5,0]  R2273     8.1911158561706543e-01
    z[6,5,0]  R2274     1.2703747488558292e-02
    z[6,5,0]  R2275     -9.0676330029964447e-02
    z[6,5,0]  R2276     3.0208784341812134e-01
    z[6,5,0]  R2277     8.7010359764099121e-01
    z[6,5,0]  R2278     7.5612837076187134e-01
    z[6,5,0]  R2279     1.2356323748826981e-01
    z[6,5,0]  R2280     2.3319423198699951e-01
    z[6,5,0]  R2281     3.1212385743856430e-02
    z[6,5,0]  R2282     5.0146347284317017e-01
    z[6,5,0]  R2283     -3.9650425314903259e-02
    z[6,5,0]  R2284     3.2497721910476685e-01
    z[6,5,0]  R2285     -4.7212675213813782e-01
    z[6,5,0]  R2286     -3.6578410863876343e-01
    z[6,5,0]  R2287     -2.6424747705459595e-01
    z[6,5,0]  R2288     -4.2607155442237854e-01
    z[6,5,0]  R2289     -4.7789987921714783e-01
    z[6,5,0]  R2290     8.5370033979415894e-01
    z[6,5,0]  R2291     7.5417733192443848e-01
    z[6,5,0]  R2292     3.1483504176139832e-01
    z[6,5,0]  R2293     5.8094173669815063e-01
    z[6,5,0]  R2294     3.3036491274833679e-01
    z[6,5,0]  R2295     6.6223418712615967e-01
    z[6,5,0]  R2296     6.2715351581573486e-01
    z[6,5,0]  R2297     5.4246836900711060e-01
    z[6,5,0]  R2298     5.1179546117782593e-01
    z[6,5,0]  R2299     -8.4287482500076294e-01
    z[6,5,0]  R2300     5.6227583438158035e-02
    z[6,5,0]  R2301     0.466959148645401
    z[6,5,0]  R2302     4.4979009032249451e-01
    z[6,5,0]  R2303     -2.8108501434326172e-01
    z[6,5,0]  R2304     -2.9995483160018921e-01
    z[6,5,0]  R2305     -0.602034330368042
    z[6,5,0]  R2306     -1.1290226131677628e-01
    z[6,5,0]  R2307     -1.3753145933151245e-01
    z[6,5,0]  R2308     3.4224852919578552e-01
    z[6,5,0]  R2309     -3.2606214284896851e-02
    z[6,5,0]  R2310     1.9191227853298187e-01
    z[6,5,0]  R2311     5.6973749399185181e-01
    z[6,5,0]  R2312     5.6437432765960693e-01
    z[6,5,0]  R2313     1.7782148718833923e-01
    z[6,5,0]  R2314     6.2057304382324219e-01
    z[6,5,0]  R2315     -4.2226108908653259e-01
    z[6,5,0]  R2316     3.5937055945396423e-01
    z[6,5,0]  R2317     -6.2501597404479980e-01
    z[6,5,0]  R2318     -8.5845166444778442e-01
    z[6,5,0]  R2319     -8.0257123708724976e-01
    z[6,5,0]  R2320     5.3197562694549561e-01
    z[6,5,0]  R2321     -0.451295405626297
    z[6,5,0]  R2322     1.1656672693789005e-02
    z[6,5,0]  R2323     -1.8033067882061005e-01
    z[6,5,0]  R2324     3.9501029253005981e-01
    z[6,5,0]  R2325     -8.9244616031646729e-01
    z[6,5,0]  R2326     -9.4487506151199341e-01
    z[6,5,0]  R2327     4.1145300865173340e-01
    z[6,5,0]  R2328     -7.8592562675476074e-01
    z[6,5,0]  R2329     -8.4297996759414673e-01
    z[6,5,0]  R2330     8.0484122037887573e-01
    z[6,5,0]  R2331     6.7473107576370239e-01
    z[6,5,0]  R2332     -1.7581452429294586e-01
    z[6,5,0]  R2333     -5.6763684749603271e-01
    z[6,5,0]  R2334     3.8825148344039917e-01
    z[6,5,0]  R2335     -8.9772361516952515e-01
    z[6,5,0]  R2336     -9.2428743839263916e-01
    z[6,5,0]  R2337     0.092893086373806
    z[6,5,0]  R2338     7.4307754635810852e-02
    z[6,5,0]  R2339     0.00360292661935091
    z[6,5,0]  R2340     5.5153167247772217e-01
    z[6,5,0]  R2341     4.4846823811531067e-01
    z[6,5,0]  R2342     6.7341423034667969e-01
    z[6,5,0]  R2343     1.3346501626074314e-02
    z[6,5,0]  R2344     -1.4611147344112396e-01
    z[6,5,0]  R2345     1.4871416985988617e-01
    z[6,5,0]  R2346     -5.1569759845733643e-01
    z[6,5,0]  R2347     4.4647574424743652e-01
    z[6,5,0]  R2348     -8.4457063674926758e-01
    z[6,5,0]  R2349     2.1097144484519958e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2232     -1
    z[6,5,1]  R2233     1
    z[6,5,1]  R2244     -0.0722980722784996
    z[6,5,1]  R2245     2.5028016418218613e-02
    z[6,5,1]  R2246     -1.0088376700878143e-01
    z[6,5,1]  R2247     -3.6120381951332092e-01
    z[6,5,1]  R2248     4.4236129522323608e-01
    z[6,5,1]  R2249     3.1871113181114197e-01
    z[6,5,1]  R2250     1.7556801438331604e-01
    z[6,5,1]  R2251     5.0601953268051147e-01
    z[6,5,1]  R2252     1.9762180745601654e-01
    z[6,5,1]  R2253     3.1977954506874084e-01
    z[6,5,1]  R2254     -2.9250057414174080e-02
    z[6,5,1]  R2255     0.819765567779541
    z[6,5,1]  R2256     5.5359399318695068e-01
    z[6,5,1]  R2257     6.2025868892669678e-01
    z[6,5,1]  R2258     6.3615089654922485e-01
    z[6,5,1]  R2259     7.1187084913253784e-01
    z[6,5,1]  R2260     7.2879642248153687e-01
    z[6,5,1]  R2261     8.9415103197097778e-01
    z[6,5,1]  R2262     7.7592229843139648e-01
    z[6,5,1]  R2263     6.9921773672103882e-01
    z[6,5,1]  R2264     1.6418632864952087e-01
    z[6,5,1]  R2265     1.1350983381271362e-01
    z[6,5,1]  R2266     1.4374969527125359e-02
    z[6,5,1]  R2267     1.8896361812949181e-02
    z[6,5,1]  R2268     -1.0968899726867676e-01
    z[6,5,1]  R2269     7.9908914864063263e-02
    z[6,5,1]  R2270     1.2101335078477859e-01
    z[6,5,1]  R2271     2.3778489232063293e-01
    z[6,5,1]  R2272     -3.0566531419754028e-01
    z[6,5,1]  R2273     1.9193220138549805e-01
    z[6,5,1]  R2274     -2.0066377520561218e-01
    z[6,5,1]  R2275     -4.3721985816955566e-01
    z[6,5,1]  R2276     3.8895231485366821e-01
    z[6,5,1]  R2277     4.8471488058567047e-02
    z[6,5,1]  R2278     7.3918804526329041e-02
    z[6,5,1]  R2279     -8.6846387386322021e-01
    z[6,5,1]  R2280     -1.7011912167072296e-01
    z[6,5,1]  R2281     -8.6639535427093506e-01
    z[6,5,1]  R2282     -3.2488226890563965e-01
    z[6,5,1]  R2283     1.2755459547042847e-01
    z[6,5,1]  R2284     2.5161633267998695e-02
    z[6,5,1]  R2285     7.1684432029724121e-01
    z[6,5,1]  R2286     6.4251607656478882e-01
    z[6,5,1]  R2287     8.6258381605148315e-01
    z[6,5,1]  R2288     6.1642372608184814e-01
    z[6,5,1]  R2289     5.8614504337310791e-01
    z[6,5,1]  R2290     4.1367597877979279e-02
    z[6,5,1]  R2291     -4.5734432339668274e-01
    z[6,5,1]  R2292     5.3213047981262207e-01
    z[6,5,1]  R2293     6.7137241363525391e-01
    z[6,5,1]  R2294     -1.1954019963741302e-01
    z[6,5,1]  R2295     5.8716768026351929e-01
    z[6,5,1]  R2296     5.6276440620422363e-01
    z[6,5,1]  R2297     6.0371154546737671e-01
    z[6,5,1]  R2298     5.2918326854705811e-01
    z[6,5,1]  R2299     -1.8518170714378357e-01
    z[6,5,1]  R2300     -6.4127451181411743e-01
    z[6,5,1]  R2301     -7.6162025332450867e-02
    z[6,5,1]  R2302     -1.2833869457244873e-01
    z[6,5,1]  R2303     3.6129736900329590e-01
    z[6,5,1]  R2304     1.2361064553260803e-01
    z[6,5,1]  R2305     3.2340753078460693e-01
    z[6,5,1]  R2306     3.2106035947799683e-01
    z[6,5,1]  R2307     4.2450046539306641e-01
    z[6,5,1]  R2308     -7.9346306622028351e-02
    z[6,5,1]  R2309     6.7537516355514526e-01
    z[6,5,1]  R2310     -6.3041225075721741e-02
    z[6,5,1]  R2311     -3.1974253058433533e-01
    z[6,5,1]  R2312     -1.6818445920944214e-01
    z[6,5,1]  R2313     0.717118501663208
    z[6,5,1]  R2314     6.3430160284042358e-01
    z[6,5,1]  R2315     7.5796818733215332e-01
    z[6,5,1]  R2316     0.55787593126297
    z[6,5,1]  R2317     5.8910822868347168e-01
    z[6,5,1]  R2318     -1.9215551018714905e-01
    z[6,5,1]  R2319     -1.7271377146244049e-01
    z[6,5,1]  R2320     -2.1072624251246452e-02
    z[6,5,1]  R2321     5.2754455804824829e-01
    z[6,5,1]  R2322     8.9360141754150391e-01
    z[6,5,1]  R2323     5.8269160985946655e-01
    z[6,5,1]  R2324     4.3497118353843689e-01
    z[6,5,1]  R2325     -2.5367984175682068e-01
    z[6,5,1]  R2326     -2.0710146427154541e-01
    z[6,5,1]  R2327     6.7916643619537354e-01
    z[6,5,1]  R2328     -1.5099413692951202e-01
    z[6,5,1]  R2329     -2.0377218723297119e-01
    z[6,5,1]  R2330     -1.9711072742938995e-01
    z[6,5,1]  R2331     -5.8636730909347534e-01
    z[6,5,1]  R2332     4.9011856317520142e-01
    z[6,5,1]  R2333     6.4338010549545288e-01
    z[6,5,1]  R2334     5.1117801666259766e-01
    z[6,5,1]  R2335     -2.8135138750076294e-01
    z[6,5,1]  R2336     -9.9034756422042847e-02
    z[6,5,1]  R2337     6.2226468324661255e-01
    z[6,5,1]  R2338     0.603766918182373
    z[6,5,1]  R2339     3.4518954157829285e-01
    z[6,5,1]  R2340     -2.0193326473236084e-01
    z[6,5,1]  R2341     2.3295342922210693e-01
    z[6,5,1]  R2342     -2.8062483668327332e-01
    z[6,5,1]  R2343     -0.732764482498169
    z[6,5,1]  R2344     4.3333226442337036e-01
    z[6,5,1]  R2345     -4.5113921165466309e-01
    z[6,5,1]  R2346     7.9712599515914917e-01
    z[6,5,1]  R2347     5.5384212732315063e-01
    z[6,5,1]  R2348     -3.7367174029350281e-01
    z[6,5,1]  R2349     5.1363587379455566e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2234     -1
    z[6,5,2]  R2235     1
    z[6,5,2]  R2244     0.0282979104667902
    z[6,5,2]  R2245     -5.2341473102569580e-01
    z[6,5,2]  R2246     -4.5216062664985657e-01
    z[6,5,2]  R2247     -4.9157671630382538e-02
    z[6,5,2]  R2248     -5.1734607666730881e-02
    z[6,5,2]  R2249     4.8853954672813416e-01
    z[6,5,2]  R2250     4.7413924336433411e-01
    z[6,5,2]  R2251     -1.3056895136833191e-01
    z[6,5,2]  R2252     8.2681870460510254e-01
    z[6,5,2]  R2253     -2.5275078415870667e-01
    z[6,5,2]  R2254     -8.0532139539718628e-01
    z[6,5,2]  R2255     3.8588073849678040e-01
    z[6,5,2]  R2256     4.0774497389793396e-01
    z[6,5,2]  R2257     2.1162730455398560e-01
    z[6,5,2]  R2258     3.0113062262535095e-01
    z[6,5,2]  R2259     3.3778265118598938e-02
    z[6,5,2]  R2260     1.5527984499931335e-01
    z[6,5,2]  R2261     1.5874303877353668e-01
    z[6,5,2]  R2262     -2.2881576418876648e-01
    z[6,5,2]  R2263     -1.0315708070993423e-01
    z[6,5,2]  R2264     6.4307831227779388e-02
    z[6,5,2]  R2265     1.1087056249380112e-01
    z[6,5,2]  R2266     0.446425199508667
    z[6,5,2]  R2267     1.3924829661846161e-01
    z[6,5,2]  R2268     1.8533541262149811e-01
    z[6,5,2]  R2269     -2.3447409272193909e-01
    z[6,5,2]  R2270     3.3492076396942139e-01
    z[6,5,2]  R2271     5.4997056722640991e-01
    z[6,5,2]  R2272     1.4580713585019112e-02
    z[6,5,2]  R2273     1.8778862431645393e-02
    z[6,5,2]  R2274     5.2083246409893036e-02
    z[6,5,2]  R2275     -1.2135914713144302e-01
    z[6,5,2]  R2276     -1.8801812827587128e-01
    z[6,5,2]  R2277     3.1984856724739075e-01
    z[6,5,2]  R2278     6.3478773832321167e-01
    z[6,5,2]  R2279     9.6467465162277222e-02
    z[6,5,2]  R2280     -4.4515646994113922e-02
    z[6,5,2]  R2281     -6.7482399754226208e-03
    z[6,5,2]  R2282     3.0095195770263672e-01
    z[6,5,2]  R2283     -1.4778596162796021e-01
    z[6,5,2]  R2284     -2.0170383155345917e-01
    z[6,5,2]  R2285     2.2534139454364777e-01
    z[6,5,2]  R2286     2.0300704240798950e-01
    z[6,5,2]  R2287     3.9781138300895691e-02
    z[6,5,2]  R2288     1.1528802663087845e-01
    z[6,5,2]  R2289     1.4067694544792175e-01
    z[6,5,2]  R2290     -2.7100220322608948e-01
    z[6,5,2]  R2291     1.5467441082000732e-01
    z[6,5,2]  R2292     1.6633830964565277e-01
    z[6,5,2]  R2293     5.3234919905662537e-02
    z[6,5,2]  R2294     7.6274409890174866e-02
    z[6,5,2]  R2295     1.8836699426174164e-01
    z[6,5,2]  R2296     9.8673895001411438e-02
    z[6,5,2]  R2297     2.5525781512260437e-01
    z[6,5,2]  R2298     4.3276599049568176e-01
    z[6,5,2]  R2299     -0.0498683899641037
    z[6,5,2]  R2300     -7.8489862382411957e-02
    z[6,5,2]  R2301     -5.3640075027942657e-02
    z[6,5,2]  R2302     2.6360502839088440e-01
    z[6,5,2]  R2303     -0.015627421438694
    z[6,5,2]  R2304     8.6594857275485992e-02
    z[6,5,2]  R2305     2.0107630640268326e-02
    z[6,5,2]  R2306     1.3167257606983185e-01
    z[6,5,2]  R2307     2.3699508607387543e-01
    z[6,5,2]  R2308     1.5364913642406464e-01
    z[6,5,2]  R2309     9.4399198889732361e-02
    z[6,5,2]  R2310     1.7879419028759003e-01
    z[6,5,2]  R2311     2.7754855155944824e-01
    z[6,5,2]  R2312     2.4555955827236176e-01
    z[6,5,2]  R2313     1.0720190405845642e-01
    z[6,5,2]  R2314     3.3301401138305664e-01
    z[6,5,2]  R2315     -1.0970806330442429e-01
    z[6,5,2]  R2316     6.7490625381469727e-01
    z[6,5,2]  R2317     -2.3787726461887360e-01
    z[6,5,2]  R2318     -1.8049703538417816e-01
    z[6,5,2]  R2319     -1.7838594317436218e-01
    z[6,5,2]  R2320     1.4784198999404907e-01
    z[6,5,2]  R2321     -6.0977645218372345e-02
    z[6,5,2]  R2322     3.1624818220734596e-03
    z[6,5,2]  R2323     9.3205235898494720e-02
    z[6,5,2]  R2324     5.4300391674041748e-01
    z[6,5,2]  R2325     -2.6401841640472412e-01
    z[6,5,2]  R2326     -1.2462133914232254e-01
    z[6,5,2]  R2327     -1.3151612877845764e-01
    z[6,5,2]  R2328     -1.8843559920787811e-01
    z[6,5,2]  R2329     -2.3226018249988556e-01
    z[6,5,2]  R2330     2.9141888022422791e-01
    z[6,5,2]  R2331     2.0411417353898287e-03
    z[6,5,2]  R2332     1.5482509136199951e-01
    z[6,5,2]  R2333     -3.1458556652069092e-01
    z[6,5,2]  R2334     6.1313390731811523e-01
    z[6,5,2]  R2335     -1.8113890290260315e-01
    z[6,5,2]  R2336     -2.2429031133651733e-01
    z[6,5,2]  R2337     0.0309981070458889
    z[6,5,2]  R2338     -1.3802379369735718e-02
    z[6,5,2]  R2339     -6.5438352525234222e-02
    z[6,5,2]  R2340     2.1384723484516144e-02
    z[6,5,2]  R2341     -5.4391520097851753e-03
    z[6,5,2]  R2342     1.1843720823526382e-01
    z[6,5,2]  R2343     5.1741704344749451e-02
    z[6,5,2]  R2344     -7.8318662941455841e-02
    z[6,5,2]  R2345     -4.4125726819038391e-01
    z[6,5,2]  R2346     -1.6930712759494781e-01
    z[6,5,2]  R2347     0.553565502166748
    z[6,5,2]  R2348     -2.5422206521034241e-01
    z[6,5,2]  R2349     -7.4339248239994049e-02
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2236     -1
    z[6,5,3]  R2237     1
    z[6,5,3]  R2244     0.267132967710495
    z[6,5,3]  R2245     3.0779607594013214e-02
    z[6,5,3]  R2246     -3.4272590279579163e-01
    z[6,5,3]  R2247     6.7486268281936646e-01
    z[6,5,3]  R2248     1.5228098630905151e-01
    z[6,5,3]  R2249     1.2622157111763954e-02
    z[6,5,3]  R2250     -4.7008475661277771e-01
    z[6,5,3]  R2251     -4.0756049752235413e-01
    z[6,5,3]  R2252     1.7771768569946289e-01
    z[6,5,3]  R2253     -0.618504524230957
    z[6,5,3]  R2254     2.6850801706314087e-01
    z[6,5,3]  R2255     1.0088116675615311e-01
    z[6,5,3]  R2256     6.4829981327056885e-01
    z[6,5,3]  R2257     3.2371506094932556e-01
    z[6,5,3]  R2258     5.2549237012863159e-01
    z[6,5,3]  R2259     2.0769503712654114e-01
    z[6,5,3]  R2260     4.4571187347173691e-02
    z[6,5,3]  R2261     -1.3205616176128387e-01
    z[6,5,3]  R2262     0.346235990524292
    z[6,5,3]  R2263     4.0246415138244629e-01
    z[6,5,3]  R2264     -4.9635097384452820e-01
    z[6,5,3]  R2265     -1.0132275521755219e-01
    z[6,5,3]  R2266     -1.4031672477722168e-01
    z[6,5,3]  R2267     -6.2467378377914429e-01
    z[6,5,3]  R2268     -5.6475871801376343e-01
    z[6,5,3]  R2269     -0.703062117099762
    z[6,5,3]  R2270     -2.5502547621726990e-02
    z[6,5,3]  R2271     1.4709733426570892e-02
    z[6,5,3]  R2272     -3.2916980981826782e-01
    z[6,5,3]  R2273     -2.3925596848130226e-02
    z[6,5,3]  R2274     3.0170187354087830e-01
    z[6,5,3]  R2275     -3.6702793836593628e-01
    z[6,5,3]  R2276     0.603222131729126
    z[6,5,3]  R2277     1.5608014538884163e-02
    z[6,5,3]  R2278     0.00205458072014153
    z[6,5,3]  R2279     -1.8647766113281250e-01
    z[6,5,3]  R2280     7.3701679706573486e-01
    z[6,5,3]  R2281     -2.5402450561523438e-01
    z[6,5,3]  R2282     4.9658772349357605e-01
    z[6,5,3]  R2283     6.9725221395492554e-01
    z[6,5,3]  R2284     3.9002344012260437e-01
    z[6,5,3]  R2285     3.8173970580101013e-01
    z[6,5,3]  R2286     4.8316952586174011e-01
    z[6,5,3]  R2287     2.3315073549747467e-01
    z[6,5,3]  R2288     5.0997787714004517e-01
    z[6,5,3]  R2289     5.1632338762283325e-01
    z[6,5,3]  R2290     -4.0670718997716904e-02
    z[6,5,3]  R2291     -2.7080744504928589e-01
    z[6,5,3]  R2292     0.29147869348526
    z[6,5,3]  R2293     -1.2598313391208649e-01
    z[6,5,3]  R2294     -2.4649222195148468e-01
    z[6,5,3]  R2295     -3.7062340974807739e-01
    z[6,5,3]  R2296     -2.8882077336311340e-01
    z[6,5,3]  R2297     -4.2581576108932495e-01
    z[6,5,3]  R2298     -2.8204908967018127e-01
    z[6,5,3]  R2299     -2.2921943664550781e-01
    z[6,5,3]  R2300     4.6231511235237122e-01
    z[6,5,3]  R2301     5.7530981302261353e-01
    z[6,5,3]  R2302     -3.0505027621984482e-02
    z[6,5,3]  R2303     0.747157871723175
    z[6,5,3]  R2304     6.8595755100250244e-01
    z[6,5,3]  R2305     0.518020510673523
    z[6,5,3]  R2306     4.2831945419311523e-01
    z[6,5,3]  R2307     2.5988447666168213e-01
    z[6,5,3]  R2308     1.5684854984283447e-01
    z[6,5,3]  R2309     4.8331776261329651e-01
    z[6,5,3]  R2310     6.0230517387390137e-01
    z[6,5,3]  R2311     0.170273557305336
    z[6,5,3]  R2312     0.139985129237175
    z[6,5,3]  R2313     4.7819033265113831e-01
    z[6,5,3]  R2314     -1.2592312693595886e-01
    z[6,5,3]  R2315     7.7215313911437988e-02
    z[6,5,3]  R2316     -1.8931412696838379e-01
    z[6,5,3]  R2317     -3.3788260817527771e-01
    z[6,5,3]  R2318     2.4014195799827576e-01
    z[6,5,3]  R2319     -0.408211886882782
    z[6,5,3]  R2320     -1.3090525567531586e-01
    z[6,5,3]  R2321     5.7941854000091553e-01
    z[6,5,3]  R2322     2.6890572905540466e-01
    z[6,5,3]  R2323     4.4059857726097107e-01
    z[6,5,3]  R2324     3.4857034683227539e-02
    z[6,5,3]  R2325     2.7813278138637543e-02
    z[6,5,3]  R2326     0.123990997672081
    z[6,5,3]  R2327     -4.2569947242736816e-01
    z[6,5,3]  R2328     8.7250366806983948e-02
    z[6,5,3]  R2329     3.5420853644609451e-02
    z[6,5,3]  R2330     -2.3585051298141479e-01
    z[6,5,3]  R2331     9.0801984071731567e-02
    z[6,5,3]  R2332     4.4118198752403259e-01
    z[6,5,3]  R2333     0.0428534559905529
    z[6,5,3]  R2334     2.3797746002674103e-01
    z[6,5,3]  R2335     -3.7355388049036264e-03
    z[6,5,3]  R2336     -2.3232486844062805e-01
    z[6,5,3]  R2337     -0.715779185295105
    z[6,5,3]  R2338     -7.7900612354278564e-01
    z[6,5,3]  R2339     -0.923267126083374
    z[6,5,3]  R2340     6.0994488000869751e-01
    z[6,5,3]  R2341     7.4652409553527832e-01
    z[6,5,3]  R2342     -1.1623510718345642e-01
    z[6,5,3]  R2343     -0.557176411151886
    z[6,5,3]  R2344     8.3671528100967407e-01
    z[6,5,3]  R2345     5.7553607970476151e-02
    z[6,5,3]  R2346     2.1857085824012756e-01
    z[6,5,3]  R2347     -9.8399199545383453e-02
    z[6,5,3]  R2348     2.3236854374408722e-01
    z[6,5,3]  R2349     -7.4198341369628906e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2238     -1
    z[6,5,4]  R2239     1
    z[6,5,4]  R2244     3.3808510750532150e-02
    z[6,5,4]  R2245     -4.5581620931625366e-01
    z[6,5,4]  R2246     -5.5690342187881470e-01
    z[6,5,4]  R2247     -1.4532133936882019e-01
    z[6,5,4]  R2248     6.2799870967864990e-02
    z[6,5,4]  R2249     -6.7526477575302124e-01
    z[6,5,4]  R2250     -3.2386317849159241e-01
    z[6,5,4]  R2251     0.0595785453915596
    z[6,5,4]  R2252     -1.4970295131206512e-01
    z[6,5,4]  R2253     8.8510274887084961e-02
    z[6,5,4]  R2254     3.0084443092346191e-01
    z[6,5,4]  R2255     -2.2026547789573669e-01
    z[6,5,4]  R2256     -7.0162400603294373e-02
    z[6,5,4]  R2257     -5.7761085033416748e-01
    z[6,5,4]  R2258     1.5189734101295471e-01
    z[6,5,4]  R2259     -2.0933844149112701e-01
    z[6,5,4]  R2260     -3.1712394952774048e-01
    z[6,5,4]  R2261     1.5083143115043640e-01
    z[6,5,4]  R2262     1.1382985860109329e-01
    z[6,5,4]  R2263     1.6336791217327118e-02
    z[6,5,4]  R2264     5.3791604936122894e-02
    z[6,5,4]  R2265     -1.8090879917144775e-01
    z[6,5,4]  R2266     4.5561593025922775e-02
    z[6,5,4]  R2267     3.0517336726188660e-01
    z[6,5,4]  R2268     -1.1205385625362396e-01
    z[6,5,4]  R2269     -1.6169063746929169e-02
    z[6,5,4]  R2270     3.0408045649528503e-01
    z[6,5,4]  R2271     -2.3713871836662292e-01
    z[6,5,4]  R2272     2.9085591435432434e-01
    z[6,5,4]  R2273     -2.2088031470775604e-01
    z[6,5,4]  R2274     6.3076955080032349e-01
    z[6,5,4]  R2275     5.7797265052795410e-01
    z[6,5,4]  R2276     -3.6340436339378357e-01
    z[6,5,4]  R2277     -2.0283286273479462e-01
    z[6,5,4]  R2278     -0.0535733737051487
    z[6,5,4]  R2279     -2.2956177592277527e-01
    z[6,5,4]  R2280     -4.9649411439895630e-01
    z[6,5,4]  R2281     1.1810000985860825e-01
    z[6,5,4]  R2282     1.3310475647449493e-01
    z[6,5,4]  R2283     8.4359832108020782e-02
    z[6,5,4]  R2284     -4.6351256966590881e-01
    z[6,5,4]  R2285     3.5189583897590637e-02
    z[6,5,4]  R2286     -4.7536338679492474e-03
    z[6,5,4]  R2287     -3.2184287905693054e-01
    z[6,5,4]  R2288     -2.9385346174240112e-01
    z[6,5,4]  R2289     1.8281698226928711e-01
    z[6,5,4]  R2290     3.9884322881698608e-01
    z[6,5,4]  R2291     -2.9343074560165405e-01
    z[6,5,4]  R2292     3.8863825798034668e-01
    z[6,5,4]  R2293     2.7067816257476807e-01
    z[6,5,4]  R2294     4.4900488853454590e-01
    z[6,5,4]  R2295     -8.3619825541973114e-02
    z[6,5,4]  R2296     -2.3037960752844810e-02
    z[6,5,4]  R2297     3.0328243970870972e-01
    z[6,5,4]  R2298     3.40327387675643e-05
    z[6,5,4]  R2299     -3.4083715081214905e-01
    z[6,5,4]  R2300     -7.6309517025947571e-02
    z[6,5,4]  R2301     5.1374042034149170e-01
    z[6,5,4]  R2302     7.8781759738922119e-01
    z[6,5,4]  R2303     4.6057271957397461e-01
    z[6,5,4]  R2304     5.6694155931472778e-01
    z[6,5,4]  R2305     -2.1398362517356873e-01
    z[6,5,4]  R2306     4.3669030070304871e-01
    z[6,5,4]  R2307     1.5598259866237640e-01
    z[6,5,4]  R2308     3.8553100824356079e-01
    z[6,5,4]  R2309     -1.8345834314823151e-01
    z[6,5,4]  R2310     0.532383382320404
    z[6,5,4]  R2311     -4.1586235165596008e-02
    z[6,5,4]  R2312     -5.6828784942626953e-01
    z[6,5,4]  R2313     2.2176005877554417e-03
    z[6,5,4]  R2314     2.5891074538230896e-01
    z[6,5,4]  R2315     3.6979028582572937e-01
    z[6,5,4]  R2316     -1.9570612907409668e-01
    z[6,5,4]  R2317     1.4526385068893433e-01
    z[6,5,4]  R2318     -0.0417962521314621
    z[6,5,4]  R2319     -4.1301891207695007e-02
    z[6,5,4]  R2320     -3.4136778116226196e-01
    z[6,5,4]  R2321     2.4779860675334930e-01
    z[6,5,4]  R2322     1.4272421598434448e-01
    z[6,5,4]  R2323     -2.8095895051956177e-01
    z[6,5,4]  R2324     -3.1539839506149292e-01
    z[6,5,4]  R2325     2.5853142142295837e-02
    z[6,5,4]  R2326     -9.9958963692188263e-02
    z[6,5,4]  R2327     -1.9605672359466553e-01
    z[6,5,4]  R2328     -5.3230029344558716e-01
    z[6,5,4]  R2329     2.0194664597511292e-01
    z[6,5,4]  R2330     -1.1229781806468964e-01
    z[6,5,4]  R2331     6.3080765306949615e-02
    z[6,5,4]  R2332     -1.8942435085773468e-01
    z[6,5,4]  R2333     -0.02197265625
    z[6,5,4]  R2334     -3.7384482566267252e-03
    z[6,5,4]  R2335     -1.7954805493354797e-01
    z[6,5,4]  R2336     -8.7438896298408508e-02
    z[6,5,4]  R2337     -1.2091485410928726e-01
    z[6,5,4]  R2338     4.8610851168632507e-02
    z[6,5,4]  R2339     -0.0319192036986351
    z[6,5,4]  R2340     -2.9788926243782043e-01
    z[6,5,4]  R2341     -7.0884138345718384e-02
    z[6,5,4]  R2342     5.1153737306594849e-01
    z[6,5,4]  R2343     -1.3111691176891327e-01
    z[6,5,4]  R2344     2.8514513373374939e-01
    z[6,5,4]  R2345     7.4714952707290649e-01
    z[6,5,4]  R2346     -5.2574608474969864e-02
    z[6,5,4]  R2347     -7.8257076442241669e-02
    z[6,5,4]  R2348     -1.4152601361274719e-01
    z[6,5,4]  R2349     1.4653564989566803e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2240     -1
    z[6,5,5]  R2241     1
    z[6,5,5]  R2244     -1.1698494106531143e-01
    z[6,5,5]  R2245     2.9426884651184082e-01
    z[6,5,5]  R2246     9.1682516038417816e-02
    z[6,5,5]  R2247     3.1403458118438721e-01
    z[6,5,5]  R2248     -8.0576866865158081e-01
    z[6,5,5]  R2249     3.3729836344718933e-01
    z[6,5,5]  R2250     1.5026065707206726e-01
    z[6,5,5]  R2251     -7.4081754684448242e-01
    z[6,5,5]  R2252     -1.6764244437217712e-01
    z[6,5,5]  R2253     -3.5321637988090515e-01
    z[6,5,5]  R2254     -3.3381393551826477e-01
    z[6,5,5]  R2255     -2.0318450033664703e-01
    z[6,5,5]  R2256     -1.5508468449115753e-01
    z[6,5,5]  R2257     9.6587009727954865e-02
    z[6,5,5]  R2258     -2.7794990688562393e-02
    z[6,5,5]  R2259     0.245323047041893
    z[6,5,5]  R2260     2.7847883105278015e-01
    z[6,5,5]  R2261     2.3506443202495575e-01
    z[6,5,5]  R2262     3.2918974757194519e-01
    z[6,5,5]  R2263     3.0537724494934082e-01
    z[6,5,5]  R2264     -3.2110888510942459e-02
    z[6,5,5]  R2265     6.4072795212268829e-02
    z[6,5,5]  R2266     3.2031017541885376e-01
    z[6,5,5]  R2267     1.0843108594417572e-01
    z[6,5,5]  R2268     4.6417227387428284e-01
    z[6,5,5]  R2269     1.3952548801898956e-01
    z[6,5,5]  R2270     -4.7300036996603012e-02
    z[6,5,5]  R2271     -0.0384240597486496
    z[6,5,5]  R2272     4.0608367323875427e-01
    z[6,5,5]  R2273     1.7650359869003296e-01
    z[6,5,5]  R2274     2.8615635633468628e-01
    z[6,5,5]  R2275     5.1913696527481079e-01
    z[6,5,5]  R2276     -4.7515466809272766e-01
    z[6,5,5]  R2277     2.8119641542434692e-01
    z[6,5,5]  R2278     8.9034624397754669e-02
    z[6,5,5]  R2279     -2.8502097725868225e-01
    z[6,5,5]  R2280     -7.8130595386028290e-02
    z[6,5,5]  R2281     1.4234589040279388e-01
    z[6,5,5]  R2282     -3.3693760633468628e-01
    z[6,5,5]  R2283     5.5766922235488892e-01
    z[6,5,5]  R2284     6.7910814285278320e-01
    z[6,5,5]  R2285     -1.8487884104251862e-01
    z[6,5,5]  R2286     1.3950876891613007e-01
    z[6,5,5]  R2287     5.5017095059156418e-02
    z[6,5,5]  R2288     2.2003208100795746e-01
    z[6,5,5]  R2289     3.1087648868560791e-01
    z[6,5,5]  R2290     -1.1001148819923401e-01
    z[6,5,5]  R2291     8.1487350165843964e-02
    z[6,5,5]  R2292     -5.5850189924240112e-01
    z[6,5,5]  R2293     3.2151535153388977e-01
    z[6,5,5]  R2294     4.4339734315872192e-01
    z[6,5,5]  R2295     -1.7229861021041870e-01
    z[6,5,5]  R2296     1.3593678176403046e-01
    z[6,5,5]  R2297     3.6164857447147369e-02
    z[6,5,5]  R2298     2.2967378795146942e-01
    z[6,5,5]  R2299     -2.3985219001770020e-01
    z[6,5,5]  R2300     5.4262804985046387e-01
    z[6,5,5]  R2301     3.1515711545944214e-01
    z[6,5,5]  R2302     -2.7135422825813293e-01
    z[6,5,5]  R2303     -1.4030887186527252e-01
    z[6,5,5]  R2304     -2.7354758977890015e-01
    z[6,5,5]  R2305     -3.7637513875961304e-01
    z[6,5,5]  R2306     -0.635583221912384
    z[6,5,5]  R2307     -7.9247075319290161e-01
    z[6,5,5]  R2308     -5.3739106655120850e-01
    z[6,5,5]  R2309     -4.6171960234642029e-01
    z[6,5,5]  R2310     -4.7379118204116821e-01
    z[6,5,5]  R2311     -6.2867230176925659e-01
    z[6,5,5]  R2312     -4.7461655735969543e-01
    z[6,5,5]  R2313     -3.1075629591941833e-01
    z[6,5,5]  R2314     -0.0666750892996788
    z[6,5,5]  R2315     1.2726147472858429e-01
    z[6,5,5]  R2316     -1.4552277512848377e-02
    z[6,5,5]  R2317     2.5573673844337463e-01
    z[6,5,5]  R2318     -2.8836706653237343e-02
    z[6,5,5]  R2319     -3.0305409431457520e-01
    z[6,5,5]  R2320     1.4619396626949310e-01
    z[6,5,5]  R2321     8.3432635292410851e-03
    z[6,5,5]  R2322     -3.1873792409896851e-01
    z[6,5,5]  R2323     -0.412521094083786
    z[6,5,5]  R2324     3.8313734531402588e-01
    z[6,5,5]  R2325     2.5273540616035461e-01
    z[6,5,5]  R2326     -9.6924573183059692e-02
    z[6,5,5]  R2327     3.6326035857200623e-01
    z[6,5,5]  R2328     0.0503445640206337
    z[6,5,5]  R2329     9.8870471119880676e-02
    z[6,5,5]  R2330     -3.9066934585571289e-01
    z[6,5,5]  R2331     4.0133652091026306e-01
    z[6,5,5]  R2332     -5.3068125247955322e-01
    z[6,5,5]  R2333     3.6689648032188416e-01
    z[6,5,5]  R2334     3.8520210981369019e-01
    z[6,5,5]  R2335     -2.2283075749874115e-01
    z[6,5,5]  R2336     7.2753116488456726e-02
    z[6,5,5]  R2337     -6.6692255437374115e-02
    z[6,5,5]  R2338     -9.6957378089427948e-02
    z[6,5,5]  R2339     1.5190611779689789e-01
    z[6,5,5]  R2340     3.0472227931022644e-01
    z[6,5,5]  R2341     2.5635793805122375e-01
    z[6,5,5]  R2342     3.2530602812767029e-01
    z[6,5,5]  R2343     2.4582125246524811e-01
    z[6,5,5]  R2344     4.6398699283599854e-02
    z[6,5,5]  R2345     -7.9258419573307037e-02
    z[6,5,5]  R2346     -0.0792100802063942
    z[6,5,5]  R2347     2.5551852583885193e-01
    z[6,5,5]  R2348     -4.8923354595899582e-02
    z[6,5,5]  R2349     6.8519569933414459e-02
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2242     -1
    z[6,5,6]  R2243     1
    z[6,5,6]  R2244     -5.8817837387323380e-02
    z[6,5,6]  R2245     5.2854627370834351e-01
    z[6,5,6]  R2246     -5.4024678468704224e-01
    z[6,5,6]  R2247     -0.513824999332428
    z[6,5,6]  R2248     -2.1109430491924286e-01
    z[6,5,6]  R2249     -0.0385933518409729
    z[6,5,6]  R2250     5.7772211730480194e-02
    z[6,5,6]  R2251     9.1128058731555939e-02
    z[6,5,6]  R2252     -4.0041634440422058e-01
    z[6,5,6]  R2253     1.2496497482061386e-01
    z[6,5,6]  R2254     -2.0222863554954529e-01
    z[6,5,6]  R2255     2.8117766976356506e-01
    z[6,5,6]  R2256     -3.3778324723243713e-02
    z[6,5,6]  R2257     -2.3773482441902161e-01
    z[6,5,6]  R2258     4.4558718800544739e-01
    z[6,5,6]  R2259     -2.3907680809497833e-01
    z[6,5,6]  R2260     -1.8357668071985245e-02
    z[6,5,6]  R2261     1.3162803649902344e-01
    z[6,5,6]  R2262     -2.6334342360496521e-01
    z[6,5,6]  R2263     0.037345040589571
    z[6,5,6]  R2264     8.0668188631534576e-02
    z[6,5,6]  R2265     -6.9654747843742371e-02
    z[6,5,6]  R2266     3.0408850312232971e-01
    z[6,5,6]  R2267     -3.4142650663852692e-02
    z[6,5,6]  R2268     7.0212408900260925e-02
    z[6,5,6]  R2269     2.1300657093524933e-01
    z[6,5,6]  R2270     1.8506847321987152e-01
    z[6,5,6]  R2271     1.0416140779852867e-02
    z[6,5,6]  R2272     -1.9394992291927338e-01
    z[6,5,6]  R2273     0.459729939699173
    z[6,5,6]  R2274     6.2135362625122070e-01
    z[6,5,6]  R2275     2.1822814643383026e-01
    z[6,5,6]  R2276     1.9914092496037483e-02
    z[6,5,6]  R2277     1.3345773518085480e-01
    z[6,5,6]  R2278     -9.5125131309032440e-02
    z[6,5,6]  R2279     2.2910065948963165e-01
    z[6,5,6]  R2280     -3.4480971097946167e-01
    z[6,5,6]  R2281     -3.8678294420242310e-01
    z[6,5,6]  R2282     4.1781640052795410e-01
    z[6,5,6]  R2283     3.9502507448196411e-01
    z[6,5,6]  R2284     1.5786762535572052e-01
    z[6,5,6]  R2285     -1.7694112658500671e-01
    z[6,5,6]  R2286     -3.9903020858764648e-01
    z[6,5,6]  R2287     1.5352848172187805e-01
    z[6,5,6]  R2288     -1.7421814799308777e-01
    z[6,5,6]  R2289     1.0770173370838165e-01
    z[6,5,6]  R2290     -1.5234698355197906e-01
    z[6,5,6]  R2291     1.7902514338493347e-01
    z[6,5,6]  R2292     -2.0524072647094727e-01
    z[6,5,6]  R2293     -1.2814530730247498e-01
    z[6,5,6]  R2294     6.4170587062835693e-01
    z[6,5,6]  R2295     8.4600344300270081e-02
    z[6,5,6]  R2296     -4.2167651653289795e-01
    z[6,5,6]  R2297     3.8686826825141907e-02
    z[6,5,6]  R2298     -3.7207841873168945e-01
    z[6,5,6]  R2299     1.6291812062263489e-01
    z[6,5,6]  R2300     2.5581473112106323e-01
    z[6,5,6]  R2301     -2.8113466501235962e-01
    z[6,5,6]  R2302     1.2849248945713043e-01
    z[6,5,6]  R2303     1.2341749854385853e-02
    z[6,5,6]  R2304     1.4303857088088989e-01
    z[6,5,6]  R2305     2.7706572413444519e-01
    z[6,5,6]  R2306     -2.9784819483757019e-01
    z[6,5,6]  R2307     1.5759864449501038e-01
    z[6,5,6]  R2308     -6.2524974346160889e-01
    z[6,5,6]  R2309     0.231205552816391
    z[6,5,6]  R2310     -2.3779509961605072e-01
    z[6,5,6]  R2311     -0.264913946390152
    z[6,5,6]  R2312     1.5839265286922455e-01
    z[6,5,6]  R2313     3.4261947870254517e-01
    z[6,5,6]  R2314     -1.1964618414640427e-01
    z[6,5,6]  R2315     2.7611851692199707e-01
    z[6,5,6]  R2316     -1.7255797982215881e-01
    z[6,5,6]  R2317     -7.1088634431362152e-02
    z[6,5,6]  R2318     -3.6511799693107605e-01
    z[6,5,6]  R2319     -1.8450810015201569e-01
    z[6,5,6]  R2320     7.3461544513702393e-01
    z[6,5,6]  R2321     3.4221544861793518e-01
    z[6,5,6]  R2322     -8.4001637995243073e-02
    z[6,5,6]  R2323     4.1955387592315674e-01
    z[6,5,6]  R2324     -3.3530315756797791e-01
    z[6,5,6]  R2325     -6.4525239169597626e-02
    z[6,5,6]  R2326     -1.1844666302204132e-01
    z[6,5,6]  R2327     2.2946875542402267e-02
    z[6,5,6]  R2328     1.7470799386501312e-01
    z[6,5,6]  R2329     3.7696731090545654e-01
    z[6,5,6]  R2330     8.7144136428833008e-02
    z[6,5,6]  R2331     -1.6616840660572052e-01
    z[6,5,6]  R2332     4.3904036283493042e-01
    z[6,5,6]  R2333     -1.6719458997249603e-01
    z[6,5,6]  R2334     8.3646379411220551e-02
    z[6,5,6]  R2335     -1.4737313613295555e-02
    z[6,5,6]  R2336     1.3662087917327881e-01
    z[6,5,6]  R2337     2.6793381571769714e-01
    z[6,5,6]  R2338     -1.0554116219282150e-01
    z[6,5,6]  R2339     -5.7056136429309845e-03
    z[6,5,6]  R2340     3.1772968173027039e-01
    z[6,5,6]  R2341     3.4137552976608276e-01
    z[6,5,6]  R2342     2.6968577504158020e-01
    z[6,5,6]  R2343     2.6858061552047729e-01
    z[6,5,6]  R2344     3.4463077783584595e-02
    z[6,5,6]  R2345     1.0873294621706009e-01
    z[6,5,6]  R2346     -1.1475966870784760e-01
    z[6,5,6]  R2347     -3.2617077231407166e-01
    z[6,5,6]  R2348     -7.7605910599231720e-02
    z[6,5,6]  R2349     -3.3081090450286865e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2350     -1
    z[6,7,0]  R2351     1
    z[6,7,0]  R2364     -9.5095962285995483e-01
    z[6,7,0]  R2365     -3.8825187087059021e-01
    z[6,7,0]  R2366     -2.3978874087333679e-01
    z[6,7,0]  R2367     1.6710342466831207e-01
    z[6,7,0]  R2368     2.8404712677001953e-01
    z[6,7,0]  R2369     2.9723849892616272e-01
    z[6,7,0]  R2370     6.2656593322753906e-01
    z[6,7,0]  R2371     1.1219176463782787e-02
    z[6,7,0]  R2372     1.8677452206611633e-01
    z[6,7,0]  R2373     0.550543487071991
    z[6,7,0]  R2374     1.8886448442935944e-01
    z[6,7,0]  R2375     -6.4570712856948376e-03
    z[6,7,0]  R2376     2.7725443243980408e-01
    z[6,7,0]  R2377     2.5733324885368347e-01
    z[6,7,0]  R2378     7.8082323074340820e-02
    z[6,7,0]  R2379     5.3646814823150635e-01
    z[6,7,0]  R2380     5.1410341262817383e-01
    z[6,7,0]  R2381     2.5004863739013672e-01
    z[6,7,0]  R2382     1.8717832863330841e-01
    z[6,7,0]  R2383     4.9351686239242554e-01
    z[6,7,0]  R2384     0.843866765499115
    z[6,7,0]  R2385     9.6066212654113770e-01
    z[6,7,0]  R2386     7.6397955417633057e-01
    z[6,7,0]  R2387     6.9568783044815063e-01
    z[6,7,0]  R2388     6.3381779193878174e-01
    z[6,7,0]  R2389     0.615824282169342
    z[6,7,0]  R2390     8.6231148242950439e-01
    z[6,7,0]  R2391     7.6351469755172729e-01
    z[6,7,0]  R2392     7.1476262807846069e-01
    z[6,7,0]  R2393     8.1911158561706543e-01
    z[6,7,0]  R2394     1.2703747488558292e-02
    z[6,7,0]  R2395     -9.0676330029964447e-02
    z[6,7,0]  R2396     3.0208784341812134e-01
    z[6,7,0]  R2397     8.7010359764099121e-01
    z[6,7,0]  R2398     7.5612837076187134e-01
    z[6,7,0]  R2399     1.2356323748826981e-01
    z[6,7,0]  R2400     -4.0147697925567627e-01
    z[6,7,0]  R2401     -2.7795320749282837e-01
    z[6,7,0]  R2402     4.7752074897289276e-04
    z[6,7,0]  R2403     7.9634189605712891e-02
    z[6,7,0]  R2404     -1.6077496111392975e-01
    z[6,7,0]  R2405     -2.4796119332313538e-01
    z[6,7,0]  R2406     -2.7985778450965881e-01
    z[6,7,0]  R2407     -7.9454638063907623e-02
    z[6,7,0]  R2408     2.3005454242229462e-01
    z[6,7,0]  R2409     -2.9637056589126587e-01
    z[6,7,0]  R2410     -4.5852547883987427e-01
    z[6,7,0]  R2411     2.1899484097957611e-01
    z[6,7,0]  R2412     -2.5554949045181274e-01
    z[6,7,0]  R2413     -1.4372719824314117e-01
    z[6,7,0]  R2414     -0.145126074552536
    z[6,7,0]  R2415     -8.3650238811969757e-03
    z[6,7,0]  R2416     -1.2346358271315694e-03
    z[6,7,0]  R2417     9.3800291419029236e-02
    z[6,7,0]  R2418     -2.1994057297706604e-01
    z[6,7,0]  R2419     4.4037255644798279e-01
    z[6,7,0]  R2420     1.0263575240969658e-02
    z[6,7,0]  R2421     -1.1668379604816437e-01
    z[6,7,0]  R2422     1.0058578848838806e-01
    z[6,7,0]  R2423     2.2934967279434204e-01
    z[6,7,0]  R2424     4.3210152536630630e-02
    z[6,7,0]  R2425     7.5677320361137390e-02
    z[6,7,0]  R2426     4.0831130743026733e-01
    z[6,7,0]  R2427     -2.7307519316673279e-01
    z[6,7,0]  R2428     1.2010221928358078e-01
    z[6,7,0]  R2429     -1.7229756712913513e-01
    z[6,7,0]  R2430     3.0183336138725281e-01
    z[6,7,0]  R2431     1.2099771946668625e-01
    z[6,7,0]  R2432     -5.6635860353708267e-02
    z[6,7,0]  R2433     -1.4152922667562962e-02
    z[6,7,0]  R2434     -1.4258608222007751e-01
    z[6,7,0]  R2435     -2.2895622253417969e-01
    z[6,7,0]  R2436     -2.5274334475398064e-02
    z[6,7,0]  R2437     2.6467061042785645e-01
    z[6,7,0]  R2438     -2.0422524213790894e-01
    z[6,7,0]  R2439     -1.0240741074085236e-01
    z[6,7,0]  R2440     -2.5584363937377930e-01
    z[6,7,0]  R2441     2.0791180431842804e-01
    z[6,7,0]  R2442     1.1191520839929581e-02
    z[6,7,0]  R2443     -2.5737819075584412e-01
    z[6,7,0]  R2444     -5.8369133621454239e-02
    z[6,7,0]  R2445     -0.169291153550148
    z[6,7,0]  R2446     -8.6377680301666260e-02
    z[6,7,0]  R2447     4.8517894744873047e-01
    z[6,7,0]  R2448     8.3977186679840088e-01
    z[6,7,0]  R2449     8.7542843818664551e-01
    z[6,7,0]  R2450     1.7060812562704086e-02
    z[6,7,0]  R2451     -1.5379984676837921e-01
    z[6,7,0]  R2452     4.6583107113838196e-01
    z[6,7,0]  R2453     8.7543791532516479e-01
    z[6,7,0]  R2454     8.6454147100448608e-01
    z[6,7,0]  R2455     9.3073451519012451e-01
    z[6,7,0]  R2456     8.6799871921539307e-01
    z[6,7,0]  R2457     8.6702954769134521e-01
    z[6,7,0]  R2458     0.69090735912323
    z[6,7,0]  R2459     7.6937586069107056e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2352     -1
    z[6,7,1]  R2353     1
    z[6,7,1]  R2364     -0.0722980722784996
    z[6,7,1]  R2365     2.5028016418218613e-02
    z[6,7,1]  R2366     -1.0088376700878143e-01
    z[6,7,1]  R2367     -3.6120381951332092e-01
    z[6,7,1]  R2368     4.4236129522323608e-01
    z[6,7,1]  R2369     3.1871113181114197e-01
    z[6,7,1]  R2370     1.7556801438331604e-01
    z[6,7,1]  R2371     5.0601953268051147e-01
    z[6,7,1]  R2372     1.9762180745601654e-01
    z[6,7,1]  R2373     3.1977954506874084e-01
    z[6,7,1]  R2374     -2.9250057414174080e-02
    z[6,7,1]  R2375     0.819765567779541
    z[6,7,1]  R2376     5.5359399318695068e-01
    z[6,7,1]  R2377     6.2025868892669678e-01
    z[6,7,1]  R2378     6.3615089654922485e-01
    z[6,7,1]  R2379     7.1187084913253784e-01
    z[6,7,1]  R2380     7.2879642248153687e-01
    z[6,7,1]  R2381     8.9415103197097778e-01
    z[6,7,1]  R2382     7.7592229843139648e-01
    z[6,7,1]  R2383     6.9921773672103882e-01
    z[6,7,1]  R2384     1.6418632864952087e-01
    z[6,7,1]  R2385     1.1350983381271362e-01
    z[6,7,1]  R2386     1.4374969527125359e-02
    z[6,7,1]  R2387     1.8896361812949181e-02
    z[6,7,1]  R2388     -1.0968899726867676e-01
    z[6,7,1]  R2389     7.9908914864063263e-02
    z[6,7,1]  R2390     1.2101335078477859e-01
    z[6,7,1]  R2391     2.3778489232063293e-01
    z[6,7,1]  R2392     -3.0566531419754028e-01
    z[6,7,1]  R2393     1.9193220138549805e-01
    z[6,7,1]  R2394     -2.0066377520561218e-01
    z[6,7,1]  R2395     -4.3721985816955566e-01
    z[6,7,1]  R2396     3.8895231485366821e-01
    z[6,7,1]  R2397     4.8471488058567047e-02
    z[6,7,1]  R2398     7.3918804526329041e-02
    z[6,7,1]  R2399     -8.6846387386322021e-01
    z[6,7,1]  R2400     -0.792862057685852
    z[6,7,1]  R2401     -8.1954658031463623e-01
    z[6,7,1]  R2402     -6.6718286275863647e-01
    z[6,7,1]  R2403     -6.7747443914413452e-01
    z[6,7,1]  R2404     2.8316763043403625e-01
    z[6,7,1]  R2405     -7.3923337459564209e-01
    z[6,7,1]  R2406     -6.8647295236587524e-01
    z[6,7,1]  R2407     -7.0364880561828613e-01
    z[6,7,1]  R2408     3.2303416728973389e-01
    z[6,7,1]  R2409     -5.6314653158187866e-01
    z[6,7,1]  R2410     6.8391436338424683e-01
    z[6,7,1]  R2411     8.6980056762695312e-01
    z[6,7,1]  R2412     7.7416473627090454e-01
    z[6,7,1]  R2413     8.3667856454849243e-01
    z[6,7,1]  R2414     8.3614146709442139e-01
    z[6,7,1]  R2415     8.0098909139633179e-01
    z[6,7,1]  R2416     6.5583300590515137e-01
    z[6,7,1]  R2417     8.5407376289367676e-01
    z[6,7,1]  R2418     9.0580403804779053e-01
    z[6,7,1]  R2419     7.8876417875289917e-01
    z[6,7,1]  R2420     -0.846510648727417
    z[6,7,1]  R2421     0.522493302822113
    z[6,7,1]  R2422     6.8824869394302368e-01
    z[6,7,1]  R2423     0.554186999797821
    z[6,7,1]  R2424     6.6140025854110718e-01
    z[6,7,1]  R2425     8.2619863748550415e-01
    z[6,7,1]  R2426     6.1974310874938965e-01
    z[6,7,1]  R2427     5.3694736957550049e-01
    z[6,7,1]  R2428     8.2902026176452637e-01
    z[6,7,1]  R2429     -6.7995643615722656e-01
    z[6,7,1]  R2430     8.4084117412567139e-01
    z[6,7,1]  R2431     5.5545192956924438e-01
    z[6,7,1]  R2432     -7.8371101617813110e-01
    z[6,7,1]  R2433     9.0411221981048584e-01
    z[6,7,1]  R2434     -7.2659420967102051e-01
    z[6,7,1]  R2435     7.7271562814712524e-01
    z[6,7,1]  R2436     0.766904354095459
    z[6,7,1]  R2437     -7.4562501907348633e-01
    z[6,7,1]  R2438     -6.0926431417465210e-01
    z[6,7,1]  R2439     -6.2725478410720825e-01
    z[6,7,1]  R2440     -9.0961802005767822e-01
    z[6,7,1]  R2441     -8.6140263080596924e-01
    z[6,7,1]  R2442     -7.8772956132888794e-01
    z[6,7,1]  R2443     -7.0141094923019409e-01
    z[6,7,1]  R2444     -0.740615963935852
    z[6,7,1]  R2445     7.6043474674224854e-01
    z[6,7,1]  R2446     0.636716902256012
    z[6,7,1]  R2447     -6.6063940525054932e-01
    z[6,7,1]  R2448     -8.4272943437099457e-02
    z[6,7,1]  R2449     9.9190972745418549e-02
    z[6,7,1]  R2450     7.1808320283889771e-01
    z[6,7,1]  R2451     0.739051103591919
    z[6,7,1]  R2452     -7.6281589269638062e-01
    z[6,7,1]  R2453     9.3487896025180817e-02
    z[6,7,1]  R2454     -1.1479447595775127e-02
    z[6,7,1]  R2455     1.2435419112443924e-01
    z[6,7,1]  R2456     -2.7331715449690819e-02
    z[6,7,1]  R2457     -5.5350143462419510e-02
    z[6,7,1]  R2458     -1.9552321732044220e-01
    z[6,7,1]  R2459     -4.2967148125171661e-02
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2354     -1
    z[6,7,2]  R2355     1
    z[6,7,2]  R2364     0.0282979104667902
    z[6,7,2]  R2365     -5.2341473102569580e-01
    z[6,7,2]  R2366     -4.5216062664985657e-01
    z[6,7,2]  R2367     -4.9157671630382538e-02
    z[6,7,2]  R2368     -5.1734607666730881e-02
    z[6,7,2]  R2369     4.8853954672813416e-01
    z[6,7,2]  R2370     4.7413924336433411e-01
    z[6,7,2]  R2371     -1.3056895136833191e-01
    z[6,7,2]  R2372     8.2681870460510254e-01
    z[6,7,2]  R2373     -2.5275078415870667e-01
    z[6,7,2]  R2374     -8.0532139539718628e-01
    z[6,7,2]  R2375     3.8588073849678040e-01
    z[6,7,2]  R2376     4.0774497389793396e-01
    z[6,7,2]  R2377     2.1162730455398560e-01
    z[6,7,2]  R2378     3.0113062262535095e-01
    z[6,7,2]  R2379     3.3778265118598938e-02
    z[6,7,2]  R2380     1.5527984499931335e-01
    z[6,7,2]  R2381     1.5874303877353668e-01
    z[6,7,2]  R2382     -2.2881576418876648e-01
    z[6,7,2]  R2383     -1.0315708070993423e-01
    z[6,7,2]  R2384     6.4307831227779388e-02
    z[6,7,2]  R2385     1.1087056249380112e-01
    z[6,7,2]  R2386     0.446425199508667
    z[6,7,2]  R2387     1.3924829661846161e-01
    z[6,7,2]  R2388     1.8533541262149811e-01
    z[6,7,2]  R2389     -2.3447409272193909e-01
    z[6,7,2]  R2390     3.3492076396942139e-01
    z[6,7,2]  R2391     5.4997056722640991e-01
    z[6,7,2]  R2392     1.4580713585019112e-02
    z[6,7,2]  R2393     1.8778862431645393e-02
    z[6,7,2]  R2394     5.2083246409893036e-02
    z[6,7,2]  R2395     -1.2135914713144302e-01
    z[6,7,2]  R2396     -1.8801812827587128e-01
    z[6,7,2]  R2397     3.1984856724739075e-01
    z[6,7,2]  R2398     6.3478773832321167e-01
    z[6,7,2]  R2399     9.6467465162277222e-02
    z[6,7,2]  R2400     -3.1393519043922424e-01
    z[6,7,2]  R2401     2.6484060287475586e-01
    z[6,7,2]  R2402     3.9245903491973877e-01
    z[6,7,2]  R2403     -2.4120378494262695e-01
    z[6,7,2]  R2404     2.0590874552726746e-01
    z[6,7,2]  R2405     -0.0811953991651535
    z[6,7,2]  R2406     1.0469920188188553e-01
    z[6,7,2]  R2407     -3.9110708236694336e-01
    z[6,7,2]  R2408     -2.0833921432495117e-01
    z[6,7,2]  R2409     1.2931351363658905e-01
    z[6,7,2]  R2410     -1.3372267782688141e-01
    z[6,7,2]  R2411     4.0922638773918152e-01
    z[6,7,2]  R2412     3.1756168603897095e-01
    z[6,7,2]  R2413     0.203582301735878
    z[6,7,2]  R2414     1.8200094997882843e-01
    z[6,7,2]  R2415     -2.1236424148082733e-01
    z[6,7,2]  R2416     0.50497967004776
    z[6,7,2]  R2417     9.3543119728565216e-02
    z[6,7,2]  R2418     -8.2484386861324310e-02
    z[6,7,2]  R2419     4.8659324645996094e-02
    z[6,7,2]  R2420     3.2083711028099060e-01
    z[6,7,2]  R2421     9.2939190566539764e-02
    z[6,7,2]  R2422     -1.5390649437904358e-01
    z[6,7,2]  R2423     1.6410119831562042e-01
    z[6,7,2]  R2424     5.7167984545230865e-02
    z[6,7,2]  R2425     -3.9061662554740906e-01
    z[6,7,2]  R2426     5.6848201900720596e-02
    z[6,7,2]  R2427     -5.4133731871843338e-02
    z[6,7,2]  R2428     -2.2056396305561066e-01
    z[6,7,2]  R2429     1.7317201197147369e-01
    z[6,7,2]  R2430     5.1693990826606750e-02
    z[6,7,2]  R2431     4.4829097390174866e-01
    z[6,7,2]  R2432     -3.3350110054016113e-01
    z[6,7,2]  R2433     -3.5054117441177368e-02
    z[6,7,2]  R2434     -4.1754251718521118e-01
    z[6,7,2]  R2435     -3.0168288946151733e-01
    z[6,7,2]  R2436     2.8850439190864563e-01
    z[6,7,2]  R2437     1.4658813178539276e-01
    z[6,7,2]  R2438     0.429653137922287
    z[6,7,2]  R2439     -1.5571160614490509e-01
    z[6,7,2]  R2440     -3.1941803172230721e-03
    z[6,7,2]  R2441     5.2502267062664032e-02
    z[6,7,2]  R2442     3.3713912963867188e-01
    z[6,7,2]  R2443     -1.2892647087574005e-01
    z[6,7,2]  R2444     2.1969152987003326e-01
    z[6,7,2]  R2445     1.4927808940410614e-01
    z[6,7,2]  R2446     3.3755195140838623e-01
    z[6,7,2]  R2447     1.3285375200212002e-02
    z[6,7,2]  R2448     8.9557290077209473e-02
    z[6,7,2]  R2449     1.7660225927829742e-01
    z[6,7,2]  R2450     -3.9753105491399765e-02
    z[6,7,2]  R2451     3.1530502438545227e-01
    z[6,7,2]  R2452     2.7472989633679390e-02
    z[6,7,2]  R2453     -1.7919382452964783e-01
    z[6,7,2]  R2454     1.3483686745166779e-01
    z[6,7,2]  R2455     3.9303582161664963e-02
    z[6,7,2]  R2456     1.8700802326202393e-01
    z[6,7,2]  R2457     4.3138301372528076e-01
    z[6,7,2]  R2458     -1.2253466248512268e-01
    z[6,7,2]  R2459     4.8997050523757935e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2356     -1
    z[6,7,3]  R2357     1
    z[6,7,3]  R2364     0.267132967710495
    z[6,7,3]  R2365     3.0779607594013214e-02
    z[6,7,3]  R2366     -3.4272590279579163e-01
    z[6,7,3]  R2367     6.7486268281936646e-01
    z[6,7,3]  R2368     1.5228098630905151e-01
    z[6,7,3]  R2369     1.2622157111763954e-02
    z[6,7,3]  R2370     -4.7008475661277771e-01
    z[6,7,3]  R2371     -4.0756049752235413e-01
    z[6,7,3]  R2372     1.7771768569946289e-01
    z[6,7,3]  R2373     -0.618504524230957
    z[6,7,3]  R2374     2.6850801706314087e-01
    z[6,7,3]  R2375     1.0088116675615311e-01
    z[6,7,3]  R2376     6.4829981327056885e-01
    z[6,7,3]  R2377     3.2371506094932556e-01
    z[6,7,3]  R2378     5.2549237012863159e-01
    z[6,7,3]  R2379     2.0769503712654114e-01
    z[6,7,3]  R2380     4.4571187347173691e-02
    z[6,7,3]  R2381     -1.3205616176128387e-01
    z[6,7,3]  R2382     0.346235990524292
    z[6,7,3]  R2383     4.0246415138244629e-01
    z[6,7,3]  R2384     -4.9635097384452820e-01
    z[6,7,3]  R2385     -1.0132275521755219e-01
    z[6,7,3]  R2386     -1.4031672477722168e-01
    z[6,7,3]  R2387     -6.2467378377914429e-01
    z[6,7,3]  R2388     -5.6475871801376343e-01
    z[6,7,3]  R2389     -0.703062117099762
    z[6,7,3]  R2390     -2.5502547621726990e-02
    z[6,7,3]  R2391     1.4709733426570892e-02
    z[6,7,3]  R2392     -3.2916980981826782e-01
    z[6,7,3]  R2393     -2.3925596848130226e-02
    z[6,7,3]  R2394     3.0170187354087830e-01
    z[6,7,3]  R2395     -3.6702793836593628e-01
    z[6,7,3]  R2396     0.603222131729126
    z[6,7,3]  R2397     1.5608014538884163e-02
    z[6,7,3]  R2398     0.00205458072014153
    z[6,7,3]  R2399     -1.8647766113281250e-01
    z[6,7,3]  R2400     4.6277437359094620e-02
    z[6,7,3]  R2401     -3.1967076659202576e-01
    z[6,7,3]  R2402     3.6842370033264160e-01
    z[6,7,3]  R2403     4.1894102096557617e-01
    z[6,7,3]  R2404     6.6029459238052368e-01
    z[6,7,3]  R2405     -5.6565958261489868e-01
    z[6,7,3]  R2406     -6.3447332382202148e-01
    z[6,7,3]  R2407     -4.1860821843147278e-01
    z[6,7,3]  R2408     6.9805681705474854e-01
    z[6,7,3]  R2409     -4.4370630383491516e-01
    z[6,7,3]  R2410     3.6959937214851379e-01
    z[6,7,3]  R2411     5.9318460524082184e-02
    z[6,7,3]  R2412     0.158525750041008
    z[6,7,3]  R2413     -2.3253539577126503e-02
    z[6,7,3]  R2414     2.3231007158756256e-01
    z[6,7,3]  R2415     -2.7718707919120789e-01
    z[6,7,3]  R2416     3.6711797118186951e-01
    z[6,7,3]  R2417     -0.226178377866745
    z[6,7,3]  R2418     -2.4011158943176270e-01
    z[6,7,3]  R2419     -2.7301368117332458e-01
    z[6,7,3]  R2420     -1.0322096198797226e-01
    z[6,7,3]  R2421     7.7387273311614990e-01
    z[6,7,3]  R2422     4.7139909863471985e-01
    z[6,7,3]  R2423     6.5096491575241089e-01
    z[6,7,3]  R2424     3.3719608187675476e-01
    z[6,7,3]  R2425     1.1057198047637939e-01
    z[6,7,3]  R2426     3.6398065090179443e-01
    z[6,7,3]  R2427     3.2900294661521912e-01
    z[6,7,3]  R2428     2.7178165316581726e-01
    z[6,7,3]  R2429     1.6171573102474213e-01
    z[6,7,3]  R2430     2.5542613863945007e-01
    z[6,7,3]  R2431     6.7297476530075073e-01
    z[6,7,3]  R2432     -3.4470504522323608e-01
    z[6,7,3]  R2433     0.0698728859424591
    z[6,7,3]  R2434     -0.00604488980025053
    z[6,7,3]  R2435     1.5375986695289612e-01
    z[6,7,3]  R2436     -1.3334222137928009e-01
    z[6,7,3]  R2437     4.6870082616806030e-01
    z[6,7,3]  R2438     5.1685118675231934e-01
    z[6,7,3]  R2439     -6.7933744192123413e-01
    z[6,7,3]  R2440     2.7467393875122070e-01
    z[6,7,3]  R2441     9.6514336764812469e-03
    z[6,7,3]  R2442     -1.6247574985027313e-01
    z[6,7,3]  R2443     -3.9134703576564789e-02
    z[6,7,3]  R2444     2.7464474551379681e-03
    z[6,7,3]  R2445     2.9281333088874817e-01
    z[6,7,3]  R2446     1.1872097849845886e-02
    z[6,7,3]  R2447     -1.6546325758099556e-02
    z[6,7,3]  R2448     -4.2227837443351746e-01
    z[6,7,3]  R2449     -2.3480325937271118e-01
    z[6,7,3]  R2450     6.3135528564453125e-01
    z[6,7,3]  R2451     3.2478424906730652e-01
    z[6,7,3]  R2452     1.4172525145113468e-02
    z[6,7,3]  R2453     -3.9085391163825989e-01
    z[6,7,3]  R2454     -1.7862078547477722e-01
    z[6,7,3]  R2455     -2.5062507390975952e-01
    z[6,7,3]  R2456     -3.4189638495445251e-01
    z[6,7,3]  R2457     1.4157831668853760e-01
    z[6,7,3]  R2458     -0.558853030204773
    z[6,7,3]  R2459     -2.4432018399238586e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2358     -1
    z[6,7,4]  R2359     1
    z[6,7,4]  R2364     3.3808510750532150e-02
    z[6,7,4]  R2365     -4.5581620931625366e-01
    z[6,7,4]  R2366     -5.5690342187881470e-01
    z[6,7,4]  R2367     -1.4532133936882019e-01
    z[6,7,4]  R2368     6.2799870967864990e-02
    z[6,7,4]  R2369     -6.7526477575302124e-01
    z[6,7,4]  R2370     -3.2386317849159241e-01
    z[6,7,4]  R2371     0.0595785453915596
    z[6,7,4]  R2372     -1.4970295131206512e-01
    z[6,7,4]  R2373     8.8510274887084961e-02
    z[6,7,4]  R2374     3.0084443092346191e-01
    z[6,7,4]  R2375     -2.2026547789573669e-01
    z[6,7,4]  R2376     -7.0162400603294373e-02
    z[6,7,4]  R2377     -5.7761085033416748e-01
    z[6,7,4]  R2378     1.5189734101295471e-01
    z[6,7,4]  R2379     -2.0933844149112701e-01
    z[6,7,4]  R2380     -3.1712394952774048e-01
    z[6,7,4]  R2381     1.5083143115043640e-01
    z[6,7,4]  R2382     1.1382985860109329e-01
    z[6,7,4]  R2383     1.6336791217327118e-02
    z[6,7,4]  R2384     5.3791604936122894e-02
    z[6,7,4]  R2385     -1.8090879917144775e-01
    z[6,7,4]  R2386     4.5561593025922775e-02
    z[6,7,4]  R2387     3.0517336726188660e-01
    z[6,7,4]  R2388     -1.1205385625362396e-01
    z[6,7,4]  R2389     -1.6169063746929169e-02
    z[6,7,4]  R2390     3.0408045649528503e-01
    z[6,7,4]  R2391     -2.3713871836662292e-01
    z[6,7,4]  R2392     2.9085591435432434e-01
    z[6,7,4]  R2393     -2.2088031470775604e-01
    z[6,7,4]  R2394     6.3076955080032349e-01
    z[6,7,4]  R2395     5.7797265052795410e-01
    z[6,7,4]  R2396     -3.6340436339378357e-01
    z[6,7,4]  R2397     -2.0283286273479462e-01
    z[6,7,4]  R2398     -0.0535733737051487
    z[6,7,4]  R2399     -2.2956177592277527e-01
    z[6,7,4]  R2400     5.3448425605893135e-03
    z[6,7,4]  R2401     7.1973830461502075e-02
    z[6,7,4]  R2402     -4.8017600178718567e-01
    z[6,7,4]  R2403     -1.9535413384437561e-01
    z[6,7,4]  R2404     -1.4793622493743896e-01
    z[6,7,4]  R2405     -2.0826685428619385e-01
    z[6,7,4]  R2406     -1.2676788866519928e-01
    z[6,7,4]  R2407     0.075748011469841
    z[6,7,4]  R2408     -3.0495241284370422e-01
    z[6,7,4]  R2409     -3.5932940244674683e-01
    z[6,7,4]  R2410     -3.7670621275901794e-01
    z[6,7,4]  R2411     8.1031396985054016e-02
    z[6,7,4]  R2412     -1.0515597462654114e-01
    z[6,7,4]  R2413     -3.5539028048515320e-01
    z[6,7,4]  R2414     1.5031726658344269e-01
    z[6,7,4]  R2415     -4.6373081207275391e-01
    z[6,7,4]  R2416     -7.2809509932994843e-02
    z[6,7,4]  R2417     1.7562508583068848e-02
    z[6,7,4]  R2418     2.8269737958908081e-02
    z[6,7,4]  R2419     -3.1315669417381287e-01
    z[6,7,4]  R2420     -3.0388814210891724e-01
    z[6,7,4]  R2421     2.6128491386771202e-02
    z[6,7,4]  R2422     -4.3060481548309326e-01
    z[6,7,4]  R2423     -3.5561460256576538e-01
    z[6,7,4]  R2424     3.0817720293998718e-01
    z[6,7,4]  R2425     -2.5788927078247070e-01
    z[6,7,4]  R2426     -0.136447012424469
    z[6,7,4]  R2427     -0.397080659866333
    z[6,7,4]  R2428     2.9640036821365356e-01
    z[6,7,4]  R2429     4.8846226930618286e-01
    z[6,7,4]  R2430     -1.9163309037685394e-01
    z[6,7,4]  R2431     -1.0979609936475754e-01
    z[6,7,4]  R2432     4.2299106717109680e-02
    z[6,7,4]  R2433     3.5171234607696533e-01
    z[6,7,4]  R2434     -4.8808288574218750e-01
    z[6,7,4]  R2435     1.0107087343931198e-01
    z[6,7,4]  R2436     -2.2987291216850281e-01
    z[6,7,4]  R2437     1.7197330296039581e-01
    z[6,7,4]  R2438     -1.2985230982303619e-01
    z[6,7,4]  R2439     -1.8230605125427246e-01
    z[6,7,4]  R2440     1.2664791941642761e-01
    z[6,7,4]  R2441     -1.9079525768756866e-01
    z[6,7,4]  R2442     0.421440452337265
    z[6,7,4]  R2443     6.2770366668701172e-01
    z[6,7,4]  R2444     5.0600588321685791e-01
    z[6,7,4]  R2445     -8.1653788685798645e-02
    z[6,7,4]  R2446     -5.7408052682876587e-01
    z[6,7,4]  R2447     4.3769359588623047e-01
    z[6,7,4]  R2448     -4.2954739183187485e-02
    z[6,7,4]  R2449     -4.6383373439311981e-02
    z[6,7,4]  R2450     -4.4163081794977188e-02
    z[6,7,4]  R2451     4.4525933265686035e-01
    z[6,7,4]  R2452     3.0113452672958374e-01
    z[6,7,4]  R2453     -1.1861461400985718e-01
    z[6,7,4]  R2454     -4.3670544028282166e-01
    z[6,7,4]  R2455     1.7355741560459137e-01
    z[6,7,4]  R2456     -2.5035262107849121e-02
    z[6,7,4]  R2457     -1.7194424569606781e-01
    z[6,7,4]  R2458     -2.7346280217170715e-01
    z[6,7,4]  R2459     8.6590789258480072e-02
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2360     -1
    z[6,7,5]  R2361     1
    z[6,7,5]  R2364     -1.1698494106531143e-01
    z[6,7,5]  R2365     2.9426884651184082e-01
    z[6,7,5]  R2366     9.1682516038417816e-02
    z[6,7,5]  R2367     3.1403458118438721e-01
    z[6,7,5]  R2368     -8.0576866865158081e-01
    z[6,7,5]  R2369     3.3729836344718933e-01
    z[6,7,5]  R2370     1.5026065707206726e-01
    z[6,7,5]  R2371     -7.4081754684448242e-01
    z[6,7,5]  R2372     -1.6764244437217712e-01
    z[6,7,5]  R2373     -3.5321637988090515e-01
    z[6,7,5]  R2374     -3.3381393551826477e-01
    z[6,7,5]  R2375     -2.0318450033664703e-01
    z[6,7,5]  R2376     -1.5508468449115753e-01
    z[6,7,5]  R2377     9.6587009727954865e-02
    z[6,7,5]  R2378     -2.7794990688562393e-02
    z[6,7,5]  R2379     0.245323047041893
    z[6,7,5]  R2380     2.7847883105278015e-01
    z[6,7,5]  R2381     2.3506443202495575e-01
    z[6,7,5]  R2382     3.2918974757194519e-01
    z[6,7,5]  R2383     3.0537724494934082e-01
    z[6,7,5]  R2384     -3.2110888510942459e-02
    z[6,7,5]  R2385     6.4072795212268829e-02
    z[6,7,5]  R2386     3.2031017541885376e-01
    z[6,7,5]  R2387     1.0843108594417572e-01
    z[6,7,5]  R2388     4.6417227387428284e-01
    z[6,7,5]  R2389     1.3952548801898956e-01
    z[6,7,5]  R2390     -4.7300036996603012e-02
    z[6,7,5]  R2391     -0.0384240597486496
    z[6,7,5]  R2392     4.0608367323875427e-01
    z[6,7,5]  R2393     1.7650359869003296e-01
    z[6,7,5]  R2394     2.8615635633468628e-01
    z[6,7,5]  R2395     5.1913696527481079e-01
    z[6,7,5]  R2396     -4.7515466809272766e-01
    z[6,7,5]  R2397     2.8119641542434692e-01
    z[6,7,5]  R2398     8.9034624397754669e-02
    z[6,7,5]  R2399     -2.8502097725868225e-01
    z[6,7,5]  R2400     -0.31219482421875
    z[6,7,5]  R2401     -2.3086293041706085e-01
    z[6,7,5]  R2402     1.7589475214481354e-01
    z[6,7,5]  R2403     -4.6738073229789734e-01
    z[6,7,5]  R2404     -5.8575284481048584e-01
    z[6,7,5]  R2405     1.2727017700672150e-01
    z[6,7,5]  R2406     4.8118501901626587e-02
    z[6,7,5]  R2407     0.347350537776947
    z[6,7,5]  R2408     -1.6113558411598206e-01
    z[6,7,5]  R2409     -1.2302889674901962e-01
    z[6,7,5]  R2410     1.3189418613910675e-01
    z[6,7,5]  R2411     6.9038402289152145e-03
    z[6,7,5]  R2412     3.8950878381729126e-01
    z[6,7,5]  R2413     2.5515630841255188e-01
    z[6,7,5]  R2414     4.1244697570800781e-01
    z[6,7,5]  R2415     -1.0995906591415405e-01
    z[6,7,5]  R2416     4.1062346100807190e-01
    z[6,7,5]  R2417     -3.6728653311729431e-01
    z[6,7,5]  R2418     2.1188862621784210e-01
    z[6,7,5]  R2419     3.0348362401127815e-02
    z[6,7,5]  R2420     2.4304036796092987e-01
    z[6,7,5]  R2421     -0.323932021856308
    z[6,7,5]  R2422     5.7969961315393448e-02
    z[6,7,5]  R2423     -1.9923089444637299e-01
    z[6,7,5]  R2424     -5.8258390426635742e-01
    z[6,7,5]  R2425     2.3948390036821365e-02
    z[6,7,5]  R2426     -5.2788370847702026e-01
    z[6,7,5]  R2427     -5.4126250743865967e-01
    z[6,7,5]  R2428     -2.6952026411890984e-02
    z[6,7,5]  R2429     4.5434519648551941e-01
    z[6,7,5]  R2430     -2.9925969243049622e-01
    z[6,7,5]  R2431     -9.9724262952804565e-02
    z[6,7,5]  R2432     3.2728222012519836e-01
    z[6,7,5]  R2433     -2.2290121018886566e-01
    z[6,7,5]  R2434     0.0622372180223465
    z[6,7,5]  R2435     -4.6589246392250061e-01
    z[6,7,5]  R2436     -2.9143321514129639e-01
    z[6,7,5]  R2437     -2.3345613479614258e-01
    z[6,7,5]  R2438     -2.1432501077651978e-01
    z[6,7,5]  R2439     -1.2208786606788635e-01
    z[6,7,5]  R2440     1.1788544803857803e-01
    z[6,7,5]  R2441     -4.1838833689689636e-01
    z[6,7,5]  R2442     2.2229743003845215e-01
    z[6,7,5]  R2443     -1.6100279986858368e-01
    z[6,7,5]  R2444     -0.317974716424942
    z[6,7,5]  R2445     1.4082056283950806e-01
    z[6,7,5]  R2446     -0.0612872950732708
    z[6,7,5]  R2447     2.7239572955295444e-04
    z[6,7,5]  R2448     2.6067218184471130e-01
    z[6,7,5]  R2449     3.6580806970596313e-01
    z[6,7,5]  R2450     9.9663458764553070e-02
    z[6,7,5]  R2451     6.3331179320812225e-02
    z[6,7,5]  R2452     -1.1396781355142593e-01
    z[6,7,5]  R2453     3.1341653317213058e-02
    z[6,7,5]  R2454     3.1393431127071381e-02
    z[6,7,5]  R2455     -6.8679951131343842e-02
    z[6,7,5]  R2456     5.4897193331271410e-04
    z[6,7,5]  R2457     3.0671315267682076e-02
    z[6,7,5]  R2458     -2.3857496678829193e-02
    z[6,7,5]  R2459     -0.260144978761673
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2362     -1
    z[6,7,6]  R2363     1
    z[6,7,6]  R2364     -5.8817837387323380e-02
    z[6,7,6]  R2365     5.2854627370834351e-01
    z[6,7,6]  R2366     -5.4024678468704224e-01
    z[6,7,6]  R2367     -0.513824999332428
    z[6,7,6]  R2368     -2.1109430491924286e-01
    z[6,7,6]  R2369     -0.0385933518409729
    z[6,7,6]  R2370     5.7772211730480194e-02
    z[6,7,6]  R2371     9.1128058731555939e-02
    z[6,7,6]  R2372     -4.0041634440422058e-01
    z[6,7,6]  R2373     1.2496497482061386e-01
    z[6,7,6]  R2374     -2.0222863554954529e-01
    z[6,7,6]  R2375     2.8117766976356506e-01
    z[6,7,6]  R2376     -3.3778324723243713e-02
    z[6,7,6]  R2377     -2.3773482441902161e-01
    z[6,7,6]  R2378     4.4558718800544739e-01
    z[6,7,6]  R2379     -2.3907680809497833e-01
    z[6,7,6]  R2380     -1.8357668071985245e-02
    z[6,7,6]  R2381     1.3162803649902344e-01
    z[6,7,6]  R2382     -2.6334342360496521e-01
    z[6,7,6]  R2383     0.037345040589571
    z[6,7,6]  R2384     8.0668188631534576e-02
    z[6,7,6]  R2385     -6.9654747843742371e-02
    z[6,7,6]  R2386     3.0408850312232971e-01
    z[6,7,6]  R2387     -3.4142650663852692e-02
    z[6,7,6]  R2388     7.0212408900260925e-02
    z[6,7,6]  R2389     2.1300657093524933e-01
    z[6,7,6]  R2390     1.8506847321987152e-01
    z[6,7,6]  R2391     1.0416140779852867e-02
    z[6,7,6]  R2392     -1.9394992291927338e-01
    z[6,7,6]  R2393     0.459729939699173
    z[6,7,6]  R2394     6.2135362625122070e-01
    z[6,7,6]  R2395     2.1822814643383026e-01
    z[6,7,6]  R2396     1.9914092496037483e-02
    z[6,7,6]  R2397     1.3345773518085480e-01
    z[6,7,6]  R2398     -9.5125131309032440e-02
    z[6,7,6]  R2399     2.2910065948963165e-01
    z[6,7,6]  R2400     -0.109520822763443
    z[6,7,6]  R2401     -1.4239962399005890e-01
    z[6,7,6]  R2402     -5.9989333152770996e-02
    z[6,7,6]  R2403     2.1068461239337921e-01
    z[6,7,6]  R2404     -2.2491894662380219e-01
    z[6,7,6]  R2405     -7.6896086335182190e-02
    z[6,7,6]  R2406     1.3612794876098633e-01
    z[6,7,6]  R2407     2.0970821380615234e-01
    z[6,7,6]  R2408     4.3940261006355286e-01
    z[6,7,6]  R2409     -0.487010657787323
    z[6,7,6]  R2410     -9.0700075030326843e-02
    z[6,7,6]  R2411     -1.3375128805637360e-01
    z[6,7,6]  R2412     -2.1589969098567963e-01
    z[6,7,6]  R2413     -2.1428486704826355e-01
    z[6,7,6]  R2414     -2.3845452815294266e-03
    z[6,7,6]  R2415     -9.6321694552898407e-02
    z[6,7,6]  R2416     -7.8668676316738129e-02
    z[6,7,6]  R2417     -2.5815647840499878e-01
    z[6,7,6]  R2418     -1.4488619565963745e-01
    z[6,7,6]  R2419     8.9614205062389374e-02
    z[6,7,6]  R2420     -1.3530252873897552e-01
    z[6,7,6]  R2421     1.5942711383104324e-02
    z[6,7,6]  R2422     2.8550121188163757e-01
    z[6,7,6]  R2423     1.5308916568756104e-01
    z[6,7,6]  R2424     -0.0966232642531395
    z[6,7,6]  R2425     2.8245496749877930e-01
    z[6,7,6]  R2426     1.2730962038040161e-01
    z[6,7,6]  R2427     -2.7441918849945068e-01
    z[6,7,6]  R2428     2.9530939459800720e-01
    z[6,7,6]  R2429     8.2507394254207611e-02
    z[6,7,6]  R2430     0.0876837819814682
    z[6,7,6]  R2431     -3.1188886612653732e-02
    z[6,7,6]  R2432     2.0890679955482483e-01
    z[6,7,6]  R2433     -5.3696759045124054e-02
    z[6,7,6]  R2434     1.8775881826877594e-01
    z[6,7,6]  R2435     -9.2540644109249115e-02
    z[6,7,6]  R2436     -4.1524580121040344e-01
    z[6,7,6]  R2437     2.2078908979892731e-01
    z[6,7,6]  R2438     -2.6936089992523193e-01
    z[6,7,6]  R2439     -2.4935486912727356e-01
    z[6,7,6]  R2440     4.1789177805185318e-02
    z[6,7,6]  R2441     -2.1374231204390526e-02
    z[6,7,6]  R2442     -1.1075932532548904e-01
    z[6,7,6]  R2443     -6.0759719461202621e-02
    z[6,7,6]  R2444     -2.0654113590717316e-01
    z[6,7,6]  R2445     -5.0848603248596191e-01
    z[6,7,6]  R2446     -3.7379625439643860e-01
    z[6,7,6]  R2447     3.6895927786827087e-01
    z[6,7,6]  R2448     -1.7761395871639252e-01
    z[6,7,6]  R2449     3.8708765059709549e-02
    z[6,7,6]  R2450     0.268314003944397
    z[6,7,6]  R2451     -1.5159203112125397e-01
    z[6,7,6]  R2452     3.1062346696853638e-01
    z[6,7,6]  R2453     -1.5792258083820343e-01
    z[6,7,6]  R2454     1.0321221500635147e-01
    z[6,7,6]  R2455     -1.3810354471206665e-01
    z[6,7,6]  R2456     3.0551424622535706e-01
    z[6,7,6]  R2457     -9.2492602765560150e-02
    z[6,7,6]  R2458     2.8589364886283875e-01
    z[6,7,6]  R2459     -1.7685487866401672e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2460     -1
    z[7,6,0]  R2461     1
    z[7,6,0]  R2474     -4.0147697925567627e-01
    z[7,6,0]  R2475     -2.7795320749282837e-01
    z[7,6,0]  R2476     4.7752074897289276e-04
    z[7,6,0]  R2477     7.9634189605712891e-02
    z[7,6,0]  R2478     -1.6077496111392975e-01
    z[7,6,0]  R2479     -2.4796119332313538e-01
    z[7,6,0]  R2480     -2.7985778450965881e-01
    z[7,6,0]  R2481     -7.9454638063907623e-02
    z[7,6,0]  R2482     2.3005454242229462e-01
    z[7,6,0]  R2483     -2.9637056589126587e-01
    z[7,6,0]  R2484     -4.5852547883987427e-01
    z[7,6,0]  R2485     2.1899484097957611e-01
    z[7,6,0]  R2486     -2.5554949045181274e-01
    z[7,6,0]  R2487     -1.4372719824314117e-01
    z[7,6,0]  R2488     -0.145126074552536
    z[7,6,0]  R2489     -8.3650238811969757e-03
    z[7,6,0]  R2490     -1.2346358271315694e-03
    z[7,6,0]  R2491     9.3800291419029236e-02
    z[7,6,0]  R2492     -2.1994057297706604e-01
    z[7,6,0]  R2493     4.4037255644798279e-01
    z[7,6,0]  R2494     1.0263575240969658e-02
    z[7,6,0]  R2495     -1.1668379604816437e-01
    z[7,6,0]  R2496     1.0058578848838806e-01
    z[7,6,0]  R2497     2.2934967279434204e-01
    z[7,6,0]  R2498     4.3210152536630630e-02
    z[7,6,0]  R2499     7.5677320361137390e-02
    z[7,6,0]  R2500     4.0831130743026733e-01
    z[7,6,0]  R2501     -2.7307519316673279e-01
    z[7,6,0]  R2502     1.2010221928358078e-01
    z[7,6,0]  R2503     -1.7229756712913513e-01
    z[7,6,0]  R2504     3.0183336138725281e-01
    z[7,6,0]  R2505     1.2099771946668625e-01
    z[7,6,0]  R2506     -5.6635860353708267e-02
    z[7,6,0]  R2507     -1.4152922667562962e-02
    z[7,6,0]  R2508     -1.4258608222007751e-01
    z[7,6,0]  R2509     -2.2895622253417969e-01
    z[7,6,0]  R2510     -2.5274334475398064e-02
    z[7,6,0]  R2511     2.6467061042785645e-01
    z[7,6,0]  R2512     -2.0422524213790894e-01
    z[7,6,0]  R2513     -1.0240741074085236e-01
    z[7,6,0]  R2514     -2.5584363937377930e-01
    z[7,6,0]  R2515     2.0791180431842804e-01
    z[7,6,0]  R2516     1.1191520839929581e-02
    z[7,6,0]  R2517     -2.5737819075584412e-01
    z[7,6,0]  R2518     -5.8369133621454239e-02
    z[7,6,0]  R2519     -0.169291153550148
    z[7,6,0]  R2520     -8.6377680301666260e-02
    z[7,6,0]  R2521     4.8517894744873047e-01
    z[7,6,0]  R2522     8.3977186679840088e-01
    z[7,6,0]  R2523     8.7542843818664551e-01
    z[7,6,0]  R2524     1.7060812562704086e-02
    z[7,6,0]  R2525     -1.5379984676837921e-01
    z[7,6,0]  R2526     4.6583107113838196e-01
    z[7,6,0]  R2527     8.7543791532516479e-01
    z[7,6,0]  R2528     8.6454147100448608e-01
    z[7,6,0]  R2529     9.3073451519012451e-01
    z[7,6,0]  R2530     8.6799871921539307e-01
    z[7,6,0]  R2531     8.6702954769134521e-01
    z[7,6,0]  R2532     0.69090735912323
    z[7,6,0]  R2533     7.6937586069107056e-01
    z[7,6,0]  R2534     -9.5095962285995483e-01
    z[7,6,0]  R2535     -3.8825187087059021e-01
    z[7,6,0]  R2536     -2.3978874087333679e-01
    z[7,6,0]  R2537     1.6710342466831207e-01
    z[7,6,0]  R2538     2.8404712677001953e-01
    z[7,6,0]  R2539     2.9723849892616272e-01
    z[7,6,0]  R2540     6.2656593322753906e-01
    z[7,6,0]  R2541     1.1219176463782787e-02
    z[7,6,0]  R2542     1.8677452206611633e-01
    z[7,6,0]  R2543     0.550543487071991
    z[7,6,0]  R2544     1.8886448442935944e-01
    z[7,6,0]  R2545     -6.4570712856948376e-03
    z[7,6,0]  R2546     2.7725443243980408e-01
    z[7,6,0]  R2547     2.5733324885368347e-01
    z[7,6,0]  R2548     7.8082323074340820e-02
    z[7,6,0]  R2549     5.3646814823150635e-01
    z[7,6,0]  R2550     5.1410341262817383e-01
    z[7,6,0]  R2551     2.5004863739013672e-01
    z[7,6,0]  R2552     1.8717832863330841e-01
    z[7,6,0]  R2553     4.9351686239242554e-01
    z[7,6,0]  R2554     0.843866765499115
    z[7,6,0]  R2555     9.6066212654113770e-01
    z[7,6,0]  R2556     7.6397955417633057e-01
    z[7,6,0]  R2557     6.9568783044815063e-01
    z[7,6,0]  R2558     6.3381779193878174e-01
    z[7,6,0]  R2559     0.615824282169342
    z[7,6,0]  R2560     8.6231148242950439e-01
    z[7,6,0]  R2561     7.6351469755172729e-01
    z[7,6,0]  R2562     7.1476262807846069e-01
    z[7,6,0]  R2563     8.1911158561706543e-01
    z[7,6,0]  R2564     1.2703747488558292e-02
    z[7,6,0]  R2565     -9.0676330029964447e-02
    z[7,6,0]  R2566     3.0208784341812134e-01
    z[7,6,0]  R2567     8.7010359764099121e-01
    z[7,6,0]  R2568     7.5612837076187134e-01
    z[7,6,0]  R2569     1.2356323748826981e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2462     -1
    z[7,6,1]  R2463     1
    z[7,6,1]  R2474     -0.792862057685852
    z[7,6,1]  R2475     -8.1954658031463623e-01
    z[7,6,1]  R2476     -6.6718286275863647e-01
    z[7,6,1]  R2477     -6.7747443914413452e-01
    z[7,6,1]  R2478     2.8316763043403625e-01
    z[7,6,1]  R2479     -7.3923337459564209e-01
    z[7,6,1]  R2480     -6.8647295236587524e-01
    z[7,6,1]  R2481     -7.0364880561828613e-01
    z[7,6,1]  R2482     3.2303416728973389e-01
    z[7,6,1]  R2483     -5.6314653158187866e-01
    z[7,6,1]  R2484     6.8391436338424683e-01
    z[7,6,1]  R2485     8.6980056762695312e-01
    z[7,6,1]  R2486     7.7416473627090454e-01
    z[7,6,1]  R2487     8.3667856454849243e-01
    z[7,6,1]  R2488     8.3614146709442139e-01
    z[7,6,1]  R2489     8.0098909139633179e-01
    z[7,6,1]  R2490     6.5583300590515137e-01
    z[7,6,1]  R2491     8.5407376289367676e-01
    z[7,6,1]  R2492     9.0580403804779053e-01
    z[7,6,1]  R2493     7.8876417875289917e-01
    z[7,6,1]  R2494     -0.846510648727417
    z[7,6,1]  R2495     0.522493302822113
    z[7,6,1]  R2496     6.8824869394302368e-01
    z[7,6,1]  R2497     0.554186999797821
    z[7,6,1]  R2498     6.6140025854110718e-01
    z[7,6,1]  R2499     8.2619863748550415e-01
    z[7,6,1]  R2500     6.1974310874938965e-01
    z[7,6,1]  R2501     5.3694736957550049e-01
    z[7,6,1]  R2502     8.2902026176452637e-01
    z[7,6,1]  R2503     -6.7995643615722656e-01
    z[7,6,1]  R2504     8.4084117412567139e-01
    z[7,6,1]  R2505     5.5545192956924438e-01
    z[7,6,1]  R2506     -7.8371101617813110e-01
    z[7,6,1]  R2507     9.0411221981048584e-01
    z[7,6,1]  R2508     -7.2659420967102051e-01
    z[7,6,1]  R2509     7.7271562814712524e-01
    z[7,6,1]  R2510     0.766904354095459
    z[7,6,1]  R2511     -7.4562501907348633e-01
    z[7,6,1]  R2512     -6.0926431417465210e-01
    z[7,6,1]  R2513     -6.2725478410720825e-01
    z[7,6,1]  R2514     -9.0961802005767822e-01
    z[7,6,1]  R2515     -8.6140263080596924e-01
    z[7,6,1]  R2516     -7.8772956132888794e-01
    z[7,6,1]  R2517     -7.0141094923019409e-01
    z[7,6,1]  R2518     -0.740615963935852
    z[7,6,1]  R2519     7.6043474674224854e-01
    z[7,6,1]  R2520     0.636716902256012
    z[7,6,1]  R2521     -6.6063940525054932e-01
    z[7,6,1]  R2522     -8.4272943437099457e-02
    z[7,6,1]  R2523     9.9190972745418549e-02
    z[7,6,1]  R2524     7.1808320283889771e-01
    z[7,6,1]  R2525     0.739051103591919
    z[7,6,1]  R2526     -7.6281589269638062e-01
    z[7,6,1]  R2527     9.3487896025180817e-02
    z[7,6,1]  R2528     -1.1479447595775127e-02
    z[7,6,1]  R2529     1.2435419112443924e-01
    z[7,6,1]  R2530     -2.7331715449690819e-02
    z[7,6,1]  R2531     -5.5350143462419510e-02
    z[7,6,1]  R2532     -1.9552321732044220e-01
    z[7,6,1]  R2533     -4.2967148125171661e-02
    z[7,6,1]  R2534     -0.0722980722784996
    z[7,6,1]  R2535     2.5028016418218613e-02
    z[7,6,1]  R2536     -1.0088376700878143e-01
    z[7,6,1]  R2537     -3.6120381951332092e-01
    z[7,6,1]  R2538     4.4236129522323608e-01
    z[7,6,1]  R2539     3.1871113181114197e-01
    z[7,6,1]  R2540     1.7556801438331604e-01
    z[7,6,1]  R2541     5.0601953268051147e-01
    z[7,6,1]  R2542     1.9762180745601654e-01
    z[7,6,1]  R2543     3.1977954506874084e-01
    z[7,6,1]  R2544     -2.9250057414174080e-02
    z[7,6,1]  R2545     0.819765567779541
    z[7,6,1]  R2546     5.5359399318695068e-01
    z[7,6,1]  R2547     6.2025868892669678e-01
    z[7,6,1]  R2548     6.3615089654922485e-01
    z[7,6,1]  R2549     7.1187084913253784e-01
    z[7,6,1]  R2550     7.2879642248153687e-01
    z[7,6,1]  R2551     8.9415103197097778e-01
    z[7,6,1]  R2552     7.7592229843139648e-01
    z[7,6,1]  R2553     6.9921773672103882e-01
    z[7,6,1]  R2554     1.6418632864952087e-01
    z[7,6,1]  R2555     1.1350983381271362e-01
    z[7,6,1]  R2556     1.4374969527125359e-02
    z[7,6,1]  R2557     1.8896361812949181e-02
    z[7,6,1]  R2558     -1.0968899726867676e-01
    z[7,6,1]  R2559     7.9908914864063263e-02
    z[7,6,1]  R2560     1.2101335078477859e-01
    z[7,6,1]  R2561     2.3778489232063293e-01
    z[7,6,1]  R2562     -3.0566531419754028e-01
    z[7,6,1]  R2563     1.9193220138549805e-01
    z[7,6,1]  R2564     -2.0066377520561218e-01
    z[7,6,1]  R2565     -4.3721985816955566e-01
    z[7,6,1]  R2566     3.8895231485366821e-01
    z[7,6,1]  R2567     4.8471488058567047e-02
    z[7,6,1]  R2568     7.3918804526329041e-02
    z[7,6,1]  R2569     -8.6846387386322021e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2464     -1
    z[7,6,2]  R2465     1
    z[7,6,2]  R2474     -3.1393519043922424e-01
    z[7,6,2]  R2475     2.6484060287475586e-01
    z[7,6,2]  R2476     3.9245903491973877e-01
    z[7,6,2]  R2477     -2.4120378494262695e-01
    z[7,6,2]  R2478     2.0590874552726746e-01
    z[7,6,2]  R2479     -0.0811953991651535
    z[7,6,2]  R2480     1.0469920188188553e-01
    z[7,6,2]  R2481     -3.9110708236694336e-01
    z[7,6,2]  R2482     -2.0833921432495117e-01
    z[7,6,2]  R2483     1.2931351363658905e-01
    z[7,6,2]  R2484     -1.3372267782688141e-01
    z[7,6,2]  R2485     4.0922638773918152e-01
    z[7,6,2]  R2486     3.1756168603897095e-01
    z[7,6,2]  R2487     0.203582301735878
    z[7,6,2]  R2488     1.8200094997882843e-01
    z[7,6,2]  R2489     -2.1236424148082733e-01
    z[7,6,2]  R2490     0.50497967004776
    z[7,6,2]  R2491     9.3543119728565216e-02
    z[7,6,2]  R2492     -8.2484386861324310e-02
    z[7,6,2]  R2493     4.8659324645996094e-02
    z[7,6,2]  R2494     3.2083711028099060e-01
    z[7,6,2]  R2495     9.2939190566539764e-02
    z[7,6,2]  R2496     -1.5390649437904358e-01
    z[7,6,2]  R2497     1.6410119831562042e-01
    z[7,6,2]  R2498     5.7167984545230865e-02
    z[7,6,2]  R2499     -3.9061662554740906e-01
    z[7,6,2]  R2500     5.6848201900720596e-02
    z[7,6,2]  R2501     -5.4133731871843338e-02
    z[7,6,2]  R2502     -2.2056396305561066e-01
    z[7,6,2]  R2503     1.7317201197147369e-01
    z[7,6,2]  R2504     5.1693990826606750e-02
    z[7,6,2]  R2505     4.4829097390174866e-01
    z[7,6,2]  R2506     -3.3350110054016113e-01
    z[7,6,2]  R2507     -3.5054117441177368e-02
    z[7,6,2]  R2508     -4.1754251718521118e-01
    z[7,6,2]  R2509     -3.0168288946151733e-01
    z[7,6,2]  R2510     2.8850439190864563e-01
    z[7,6,2]  R2511     1.4658813178539276e-01
    z[7,6,2]  R2512     0.429653137922287
    z[7,6,2]  R2513     -1.5571160614490509e-01
    z[7,6,2]  R2514     -3.1941803172230721e-03
    z[7,6,2]  R2515     5.2502267062664032e-02
    z[7,6,2]  R2516     3.3713912963867188e-01
    z[7,6,2]  R2517     -1.2892647087574005e-01
    z[7,6,2]  R2518     2.1969152987003326e-01
    z[7,6,2]  R2519     1.4927808940410614e-01
    z[7,6,2]  R2520     3.3755195140838623e-01
    z[7,6,2]  R2521     1.3285375200212002e-02
    z[7,6,2]  R2522     8.9557290077209473e-02
    z[7,6,2]  R2523     1.7660225927829742e-01
    z[7,6,2]  R2524     -3.9753105491399765e-02
    z[7,6,2]  R2525     3.1530502438545227e-01
    z[7,6,2]  R2526     2.7472989633679390e-02
    z[7,6,2]  R2527     -1.7919382452964783e-01
    z[7,6,2]  R2528     1.3483686745166779e-01
    z[7,6,2]  R2529     3.9303582161664963e-02
    z[7,6,2]  R2530     1.8700802326202393e-01
    z[7,6,2]  R2531     4.3138301372528076e-01
    z[7,6,2]  R2532     -1.2253466248512268e-01
    z[7,6,2]  R2533     4.8997050523757935e-01
    z[7,6,2]  R2534     0.0282979104667902
    z[7,6,2]  R2535     -5.2341473102569580e-01
    z[7,6,2]  R2536     -4.5216062664985657e-01
    z[7,6,2]  R2537     -4.9157671630382538e-02
    z[7,6,2]  R2538     -5.1734607666730881e-02
    z[7,6,2]  R2539     4.8853954672813416e-01
    z[7,6,2]  R2540     4.7413924336433411e-01
    z[7,6,2]  R2541     -1.3056895136833191e-01
    z[7,6,2]  R2542     8.2681870460510254e-01
    z[7,6,2]  R2543     -2.5275078415870667e-01
    z[7,6,2]  R2544     -8.0532139539718628e-01
    z[7,6,2]  R2545     3.8588073849678040e-01
    z[7,6,2]  R2546     4.0774497389793396e-01
    z[7,6,2]  R2547     2.1162730455398560e-01
    z[7,6,2]  R2548     3.0113062262535095e-01
    z[7,6,2]  R2549     3.3778265118598938e-02
    z[7,6,2]  R2550     1.5527984499931335e-01
    z[7,6,2]  R2551     1.5874303877353668e-01
    z[7,6,2]  R2552     -2.2881576418876648e-01
    z[7,6,2]  R2553     -1.0315708070993423e-01
    z[7,6,2]  R2554     6.4307831227779388e-02
    z[7,6,2]  R2555     1.1087056249380112e-01
    z[7,6,2]  R2556     0.446425199508667
    z[7,6,2]  R2557     1.3924829661846161e-01
    z[7,6,2]  R2558     1.8533541262149811e-01
    z[7,6,2]  R2559     -2.3447409272193909e-01
    z[7,6,2]  R2560     3.3492076396942139e-01
    z[7,6,2]  R2561     5.4997056722640991e-01
    z[7,6,2]  R2562     1.4580713585019112e-02
    z[7,6,2]  R2563     1.8778862431645393e-02
    z[7,6,2]  R2564     5.2083246409893036e-02
    z[7,6,2]  R2565     -1.2135914713144302e-01
    z[7,6,2]  R2566     -1.8801812827587128e-01
    z[7,6,2]  R2567     3.1984856724739075e-01
    z[7,6,2]  R2568     6.3478773832321167e-01
    z[7,6,2]  R2569     9.6467465162277222e-02
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2466     -1
    z[7,6,3]  R2467     1
    z[7,6,3]  R2474     4.6277437359094620e-02
    z[7,6,3]  R2475     -3.1967076659202576e-01
    z[7,6,3]  R2476     3.6842370033264160e-01
    z[7,6,3]  R2477     4.1894102096557617e-01
    z[7,6,3]  R2478     6.6029459238052368e-01
    z[7,6,3]  R2479     -5.6565958261489868e-01
    z[7,6,3]  R2480     -6.3447332382202148e-01
    z[7,6,3]  R2481     -4.1860821843147278e-01
    z[7,6,3]  R2482     6.9805681705474854e-01
    z[7,6,3]  R2483     -4.4370630383491516e-01
    z[7,6,3]  R2484     3.6959937214851379e-01
    z[7,6,3]  R2485     5.9318460524082184e-02
    z[7,6,3]  R2486     0.158525750041008
    z[7,6,3]  R2487     -2.3253539577126503e-02
    z[7,6,3]  R2488     2.3231007158756256e-01
    z[7,6,3]  R2489     -2.7718707919120789e-01
    z[7,6,3]  R2490     3.6711797118186951e-01
    z[7,6,3]  R2491     -0.226178377866745
    z[7,6,3]  R2492     -2.4011158943176270e-01
    z[7,6,3]  R2493     -2.7301368117332458e-01
    z[7,6,3]  R2494     -1.0322096198797226e-01
    z[7,6,3]  R2495     7.7387273311614990e-01
    z[7,6,3]  R2496     4.7139909863471985e-01
    z[7,6,3]  R2497     6.5096491575241089e-01
    z[7,6,3]  R2498     3.3719608187675476e-01
    z[7,6,3]  R2499     1.1057198047637939e-01
    z[7,6,3]  R2500     3.6398065090179443e-01
    z[7,6,3]  R2501     3.2900294661521912e-01
    z[7,6,3]  R2502     2.7178165316581726e-01
    z[7,6,3]  R2503     1.6171573102474213e-01
    z[7,6,3]  R2504     2.5542613863945007e-01
    z[7,6,3]  R2505     6.7297476530075073e-01
    z[7,6,3]  R2506     -3.4470504522323608e-01
    z[7,6,3]  R2507     0.0698728859424591
    z[7,6,3]  R2508     -0.00604488980025053
    z[7,6,3]  R2509     1.5375986695289612e-01
    z[7,6,3]  R2510     -1.3334222137928009e-01
    z[7,6,3]  R2511     4.6870082616806030e-01
    z[7,6,3]  R2512     5.1685118675231934e-01
    z[7,6,3]  R2513     -6.7933744192123413e-01
    z[7,6,3]  R2514     2.7467393875122070e-01
    z[7,6,3]  R2515     9.6514336764812469e-03
    z[7,6,3]  R2516     -1.6247574985027313e-01
    z[7,6,3]  R2517     -3.9134703576564789e-02
    z[7,6,3]  R2518     2.7464474551379681e-03
    z[7,6,3]  R2519     2.9281333088874817e-01
    z[7,6,3]  R2520     1.1872097849845886e-02
    z[7,6,3]  R2521     -1.6546325758099556e-02
    z[7,6,3]  R2522     -4.2227837443351746e-01
    z[7,6,3]  R2523     -2.3480325937271118e-01
    z[7,6,3]  R2524     6.3135528564453125e-01
    z[7,6,3]  R2525     3.2478424906730652e-01
    z[7,6,3]  R2526     1.4172525145113468e-02
    z[7,6,3]  R2527     -3.9085391163825989e-01
    z[7,6,3]  R2528     -1.7862078547477722e-01
    z[7,6,3]  R2529     -2.5062507390975952e-01
    z[7,6,3]  R2530     -3.4189638495445251e-01
    z[7,6,3]  R2531     1.4157831668853760e-01
    z[7,6,3]  R2532     -0.558853030204773
    z[7,6,3]  R2533     -2.4432018399238586e-01
    z[7,6,3]  R2534     0.267132967710495
    z[7,6,3]  R2535     3.0779607594013214e-02
    z[7,6,3]  R2536     -3.4272590279579163e-01
    z[7,6,3]  R2537     6.7486268281936646e-01
    z[7,6,3]  R2538     1.5228098630905151e-01
    z[7,6,3]  R2539     1.2622157111763954e-02
    z[7,6,3]  R2540     -4.7008475661277771e-01
    z[7,6,3]  R2541     -4.0756049752235413e-01
    z[7,6,3]  R2542     1.7771768569946289e-01
    z[7,6,3]  R2543     -0.618504524230957
    z[7,6,3]  R2544     2.6850801706314087e-01
    z[7,6,3]  R2545     1.0088116675615311e-01
    z[7,6,3]  R2546     6.4829981327056885e-01
    z[7,6,3]  R2547     3.2371506094932556e-01
    z[7,6,3]  R2548     5.2549237012863159e-01
    z[7,6,3]  R2549     2.0769503712654114e-01
    z[7,6,3]  R2550     4.4571187347173691e-02
    z[7,6,3]  R2551     -1.3205616176128387e-01
    z[7,6,3]  R2552     0.346235990524292
    z[7,6,3]  R2553     4.0246415138244629e-01
    z[7,6,3]  R2554     -4.9635097384452820e-01
    z[7,6,3]  R2555     -1.0132275521755219e-01
    z[7,6,3]  R2556     -1.4031672477722168e-01
    z[7,6,3]  R2557     -6.2467378377914429e-01
    z[7,6,3]  R2558     -5.6475871801376343e-01
    z[7,6,3]  R2559     -0.703062117099762
    z[7,6,3]  R2560     -2.5502547621726990e-02
    z[7,6,3]  R2561     1.4709733426570892e-02
    z[7,6,3]  R2562     -3.2916980981826782e-01
    z[7,6,3]  R2563     -2.3925596848130226e-02
    z[7,6,3]  R2564     3.0170187354087830e-01
    z[7,6,3]  R2565     -3.6702793836593628e-01
    z[7,6,3]  R2566     0.603222131729126
    z[7,6,3]  R2567     1.5608014538884163e-02
    z[7,6,3]  R2568     0.00205458072014153
    z[7,6,3]  R2569     -1.8647766113281250e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2468     -1
    z[7,6,4]  R2469     1
    z[7,6,4]  R2474     5.3448425605893135e-03
    z[7,6,4]  R2475     7.1973830461502075e-02
    z[7,6,4]  R2476     -4.8017600178718567e-01
    z[7,6,4]  R2477     -1.9535413384437561e-01
    z[7,6,4]  R2478     -1.4793622493743896e-01
    z[7,6,4]  R2479     -2.0826685428619385e-01
    z[7,6,4]  R2480     -1.2676788866519928e-01
    z[7,6,4]  R2481     0.075748011469841
    z[7,6,4]  R2482     -3.0495241284370422e-01
    z[7,6,4]  R2483     -3.5932940244674683e-01
    z[7,6,4]  R2484     -3.7670621275901794e-01
    z[7,6,4]  R2485     8.1031396985054016e-02
    z[7,6,4]  R2486     -1.0515597462654114e-01
    z[7,6,4]  R2487     -3.5539028048515320e-01
    z[7,6,4]  R2488     1.5031726658344269e-01
    z[7,6,4]  R2489     -4.6373081207275391e-01
    z[7,6,4]  R2490     -7.2809509932994843e-02
    z[7,6,4]  R2491     1.7562508583068848e-02
    z[7,6,4]  R2492     2.8269737958908081e-02
    z[7,6,4]  R2493     -3.1315669417381287e-01
    z[7,6,4]  R2494     -3.0388814210891724e-01
    z[7,6,4]  R2495     2.6128491386771202e-02
    z[7,6,4]  R2496     -4.3060481548309326e-01
    z[7,6,4]  R2497     -3.5561460256576538e-01
    z[7,6,4]  R2498     3.0817720293998718e-01
    z[7,6,4]  R2499     -2.5788927078247070e-01
    z[7,6,4]  R2500     -0.136447012424469
    z[7,6,4]  R2501     -0.397080659866333
    z[7,6,4]  R2502     2.9640036821365356e-01
    z[7,6,4]  R2503     4.8846226930618286e-01
    z[7,6,4]  R2504     -1.9163309037685394e-01
    z[7,6,4]  R2505     -1.0979609936475754e-01
    z[7,6,4]  R2506     4.2299106717109680e-02
    z[7,6,4]  R2507     3.5171234607696533e-01
    z[7,6,4]  R2508     -4.8808288574218750e-01
    z[7,6,4]  R2509     1.0107087343931198e-01
    z[7,6,4]  R2510     -2.2987291216850281e-01
    z[7,6,4]  R2511     1.7197330296039581e-01
    z[7,6,4]  R2512     -1.2985230982303619e-01
    z[7,6,4]  R2513     -1.8230605125427246e-01
    z[7,6,4]  R2514     1.2664791941642761e-01
    z[7,6,4]  R2515     -1.9079525768756866e-01
    z[7,6,4]  R2516     0.421440452337265
    z[7,6,4]  R2517     6.2770366668701172e-01
    z[7,6,4]  R2518     5.0600588321685791e-01
    z[7,6,4]  R2519     -8.1653788685798645e-02
    z[7,6,4]  R2520     -5.7408052682876587e-01
    z[7,6,4]  R2521     4.3769359588623047e-01
    z[7,6,4]  R2522     -4.2954739183187485e-02
    z[7,6,4]  R2523     -4.6383373439311981e-02
    z[7,6,4]  R2524     -4.4163081794977188e-02
    z[7,6,4]  R2525     4.4525933265686035e-01
    z[7,6,4]  R2526     3.0113452672958374e-01
    z[7,6,4]  R2527     -1.1861461400985718e-01
    z[7,6,4]  R2528     -4.3670544028282166e-01
    z[7,6,4]  R2529     1.7355741560459137e-01
    z[7,6,4]  R2530     -2.5035262107849121e-02
    z[7,6,4]  R2531     -1.7194424569606781e-01
    z[7,6,4]  R2532     -2.7346280217170715e-01
    z[7,6,4]  R2533     8.6590789258480072e-02
    z[7,6,4]  R2534     3.3808510750532150e-02
    z[7,6,4]  R2535     -4.5581620931625366e-01
    z[7,6,4]  R2536     -5.5690342187881470e-01
    z[7,6,4]  R2537     -1.4532133936882019e-01
    z[7,6,4]  R2538     6.2799870967864990e-02
    z[7,6,4]  R2539     -6.7526477575302124e-01
    z[7,6,4]  R2540     -3.2386317849159241e-01
    z[7,6,4]  R2541     0.0595785453915596
    z[7,6,4]  R2542     -1.4970295131206512e-01
    z[7,6,4]  R2543     8.8510274887084961e-02
    z[7,6,4]  R2544     3.0084443092346191e-01
    z[7,6,4]  R2545     -2.2026547789573669e-01
    z[7,6,4]  R2546     -7.0162400603294373e-02
    z[7,6,4]  R2547     -5.7761085033416748e-01
    z[7,6,4]  R2548     1.5189734101295471e-01
    z[7,6,4]  R2549     -2.0933844149112701e-01
    z[7,6,4]  R2550     -3.1712394952774048e-01
    z[7,6,4]  R2551     1.5083143115043640e-01
    z[7,6,4]  R2552     1.1382985860109329e-01
    z[7,6,4]  R2553     1.6336791217327118e-02
    z[7,6,4]  R2554     5.3791604936122894e-02
    z[7,6,4]  R2555     -1.8090879917144775e-01
    z[7,6,4]  R2556     4.5561593025922775e-02
    z[7,6,4]  R2557     3.0517336726188660e-01
    z[7,6,4]  R2558     -1.1205385625362396e-01
    z[7,6,4]  R2559     -1.6169063746929169e-02
    z[7,6,4]  R2560     3.0408045649528503e-01
    z[7,6,4]  R2561     -2.3713871836662292e-01
    z[7,6,4]  R2562     2.9085591435432434e-01
    z[7,6,4]  R2563     -2.2088031470775604e-01
    z[7,6,4]  R2564     6.3076955080032349e-01
    z[7,6,4]  R2565     5.7797265052795410e-01
    z[7,6,4]  R2566     -3.6340436339378357e-01
    z[7,6,4]  R2567     -2.0283286273479462e-01
    z[7,6,4]  R2568     -0.0535733737051487
    z[7,6,4]  R2569     -2.2956177592277527e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2470     -1
    z[7,6,5]  R2471     1
    z[7,6,5]  R2474     -0.31219482421875
    z[7,6,5]  R2475     -2.3086293041706085e-01
    z[7,6,5]  R2476     1.7589475214481354e-01
    z[7,6,5]  R2477     -4.6738073229789734e-01
    z[7,6,5]  R2478     -5.8575284481048584e-01
    z[7,6,5]  R2479     1.2727017700672150e-01
    z[7,6,5]  R2480     4.8118501901626587e-02
    z[7,6,5]  R2481     0.347350537776947
    z[7,6,5]  R2482     -1.6113558411598206e-01
    z[7,6,5]  R2483     -1.2302889674901962e-01
    z[7,6,5]  R2484     1.3189418613910675e-01
    z[7,6,5]  R2485     6.9038402289152145e-03
    z[7,6,5]  R2486     3.8950878381729126e-01
    z[7,6,5]  R2487     2.5515630841255188e-01
    z[7,6,5]  R2488     4.1244697570800781e-01
    z[7,6,5]  R2489     -1.0995906591415405e-01
    z[7,6,5]  R2490     4.1062346100807190e-01
    z[7,6,5]  R2491     -3.6728653311729431e-01
    z[7,6,5]  R2492     2.1188862621784210e-01
    z[7,6,5]  R2493     3.0348362401127815e-02
    z[7,6,5]  R2494     2.4304036796092987e-01
    z[7,6,5]  R2495     -0.323932021856308
    z[7,6,5]  R2496     5.7969961315393448e-02
    z[7,6,5]  R2497     -1.9923089444637299e-01
    z[7,6,5]  R2498     -5.8258390426635742e-01
    z[7,6,5]  R2499     2.3948390036821365e-02
    z[7,6,5]  R2500     -5.2788370847702026e-01
    z[7,6,5]  R2501     -5.4126250743865967e-01
    z[7,6,5]  R2502     -2.6952026411890984e-02
    z[7,6,5]  R2503     4.5434519648551941e-01
    z[7,6,5]  R2504     -2.9925969243049622e-01
    z[7,6,5]  R2505     -9.9724262952804565e-02
    z[7,6,5]  R2506     3.2728222012519836e-01
    z[7,6,5]  R2507     -2.2290121018886566e-01
    z[7,6,5]  R2508     0.0622372180223465
    z[7,6,5]  R2509     -4.6589246392250061e-01
    z[7,6,5]  R2510     -2.9143321514129639e-01
    z[7,6,5]  R2511     -2.3345613479614258e-01
    z[7,6,5]  R2512     -2.1432501077651978e-01
    z[7,6,5]  R2513     -1.2208786606788635e-01
    z[7,6,5]  R2514     1.1788544803857803e-01
    z[7,6,5]  R2515     -4.1838833689689636e-01
    z[7,6,5]  R2516     2.2229743003845215e-01
    z[7,6,5]  R2517     -1.6100279986858368e-01
    z[7,6,5]  R2518     -0.317974716424942
    z[7,6,5]  R2519     1.4082056283950806e-01
    z[7,6,5]  R2520     -0.0612872950732708
    z[7,6,5]  R2521     2.7239572955295444e-04
    z[7,6,5]  R2522     2.6067218184471130e-01
    z[7,6,5]  R2523     3.6580806970596313e-01
    z[7,6,5]  R2524     9.9663458764553070e-02
    z[7,6,5]  R2525     6.3331179320812225e-02
    z[7,6,5]  R2526     -1.1396781355142593e-01
    z[7,6,5]  R2527     3.1341653317213058e-02
    z[7,6,5]  R2528     3.1393431127071381e-02
    z[7,6,5]  R2529     -6.8679951131343842e-02
    z[7,6,5]  R2530     5.4897193331271410e-04
    z[7,6,5]  R2531     3.0671315267682076e-02
    z[7,6,5]  R2532     -2.3857496678829193e-02
    z[7,6,5]  R2533     -0.260144978761673
    z[7,6,5]  R2534     -1.1698494106531143e-01
    z[7,6,5]  R2535     2.9426884651184082e-01
    z[7,6,5]  R2536     9.1682516038417816e-02
    z[7,6,5]  R2537     3.1403458118438721e-01
    z[7,6,5]  R2538     -8.0576866865158081e-01
    z[7,6,5]  R2539     3.3729836344718933e-01
    z[7,6,5]  R2540     1.5026065707206726e-01
    z[7,6,5]  R2541     -7.4081754684448242e-01
    z[7,6,5]  R2542     -1.6764244437217712e-01
    z[7,6,5]  R2543     -3.5321637988090515e-01
    z[7,6,5]  R2544     -3.3381393551826477e-01
    z[7,6,5]  R2545     -2.0318450033664703e-01
    z[7,6,5]  R2546     -1.5508468449115753e-01
    z[7,6,5]  R2547     9.6587009727954865e-02
    z[7,6,5]  R2548     -2.7794990688562393e-02
    z[7,6,5]  R2549     0.245323047041893
    z[7,6,5]  R2550     2.7847883105278015e-01
    z[7,6,5]  R2551     2.3506443202495575e-01
    z[7,6,5]  R2552     3.2918974757194519e-01
    z[7,6,5]  R2553     3.0537724494934082e-01
    z[7,6,5]  R2554     -3.2110888510942459e-02
    z[7,6,5]  R2555     6.4072795212268829e-02
    z[7,6,5]  R2556     3.2031017541885376e-01
    z[7,6,5]  R2557     1.0843108594417572e-01
    z[7,6,5]  R2558     4.6417227387428284e-01
    z[7,6,5]  R2559     1.3952548801898956e-01
    z[7,6,5]  R2560     -4.7300036996603012e-02
    z[7,6,5]  R2561     -0.0384240597486496
    z[7,6,5]  R2562     4.0608367323875427e-01
    z[7,6,5]  R2563     1.7650359869003296e-01
    z[7,6,5]  R2564     2.8615635633468628e-01
    z[7,6,5]  R2565     5.1913696527481079e-01
    z[7,6,5]  R2566     -4.7515466809272766e-01
    z[7,6,5]  R2567     2.8119641542434692e-01
    z[7,6,5]  R2568     8.9034624397754669e-02
    z[7,6,5]  R2569     -2.8502097725868225e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2472     -1
    z[7,6,6]  R2473     1
    z[7,6,6]  R2474     -0.109520822763443
    z[7,6,6]  R2475     -1.4239962399005890e-01
    z[7,6,6]  R2476     -5.9989333152770996e-02
    z[7,6,6]  R2477     2.1068461239337921e-01
    z[7,6,6]  R2478     -2.2491894662380219e-01
    z[7,6,6]  R2479     -7.6896086335182190e-02
    z[7,6,6]  R2480     1.3612794876098633e-01
    z[7,6,6]  R2481     2.0970821380615234e-01
    z[7,6,6]  R2482     4.3940261006355286e-01
    z[7,6,6]  R2483     -0.487010657787323
    z[7,6,6]  R2484     -9.0700075030326843e-02
    z[7,6,6]  R2485     -1.3375128805637360e-01
    z[7,6,6]  R2486     -2.1589969098567963e-01
    z[7,6,6]  R2487     -2.1428486704826355e-01
    z[7,6,6]  R2488     -2.3845452815294266e-03
    z[7,6,6]  R2489     -9.6321694552898407e-02
    z[7,6,6]  R2490     -7.8668676316738129e-02
    z[7,6,6]  R2491     -2.5815647840499878e-01
    z[7,6,6]  R2492     -1.4488619565963745e-01
    z[7,6,6]  R2493     8.9614205062389374e-02
    z[7,6,6]  R2494     -1.3530252873897552e-01
    z[7,6,6]  R2495     1.5942711383104324e-02
    z[7,6,6]  R2496     2.8550121188163757e-01
    z[7,6,6]  R2497     1.5308916568756104e-01
    z[7,6,6]  R2498     -0.0966232642531395
    z[7,6,6]  R2499     2.8245496749877930e-01
    z[7,6,6]  R2500     1.2730962038040161e-01
    z[7,6,6]  R2501     -2.7441918849945068e-01
    z[7,6,6]  R2502     2.9530939459800720e-01
    z[7,6,6]  R2503     8.2507394254207611e-02
    z[7,6,6]  R2504     0.0876837819814682
    z[7,6,6]  R2505     -3.1188886612653732e-02
    z[7,6,6]  R2506     2.0890679955482483e-01
    z[7,6,6]  R2507     -5.3696759045124054e-02
    z[7,6,6]  R2508     1.8775881826877594e-01
    z[7,6,6]  R2509     -9.2540644109249115e-02
    z[7,6,6]  R2510     -4.1524580121040344e-01
    z[7,6,6]  R2511     2.2078908979892731e-01
    z[7,6,6]  R2512     -2.6936089992523193e-01
    z[7,6,6]  R2513     -2.4935486912727356e-01
    z[7,6,6]  R2514     4.1789177805185318e-02
    z[7,6,6]  R2515     -2.1374231204390526e-02
    z[7,6,6]  R2516     -1.1075932532548904e-01
    z[7,6,6]  R2517     -6.0759719461202621e-02
    z[7,6,6]  R2518     -2.0654113590717316e-01
    z[7,6,6]  R2519     -5.0848603248596191e-01
    z[7,6,6]  R2520     -3.7379625439643860e-01
    z[7,6,6]  R2521     3.6895927786827087e-01
    z[7,6,6]  R2522     -1.7761395871639252e-01
    z[7,6,6]  R2523     3.8708765059709549e-02
    z[7,6,6]  R2524     0.268314003944397
    z[7,6,6]  R2525     -1.5159203112125397e-01
    z[7,6,6]  R2526     3.1062346696853638e-01
    z[7,6,6]  R2527     -1.5792258083820343e-01
    z[7,6,6]  R2528     1.0321221500635147e-01
    z[7,6,6]  R2529     -1.3810354471206665e-01
    z[7,6,6]  R2530     3.0551424622535706e-01
    z[7,6,6]  R2531     -9.2492602765560150e-02
    z[7,6,6]  R2532     2.8589364886283875e-01
    z[7,6,6]  R2533     -1.7685487866401672e-01
    z[7,6,6]  R2534     -5.8817837387323380e-02
    z[7,6,6]  R2535     5.2854627370834351e-01
    z[7,6,6]  R2536     -5.4024678468704224e-01
    z[7,6,6]  R2537     -0.513824999332428
    z[7,6,6]  R2538     -2.1109430491924286e-01
    z[7,6,6]  R2539     -0.0385933518409729
    z[7,6,6]  R2540     5.7772211730480194e-02
    z[7,6,6]  R2541     9.1128058731555939e-02
    z[7,6,6]  R2542     -4.0041634440422058e-01
    z[7,6,6]  R2543     1.2496497482061386e-01
    z[7,6,6]  R2544     -2.0222863554954529e-01
    z[7,6,6]  R2545     2.8117766976356506e-01
    z[7,6,6]  R2546     -3.3778324723243713e-02
    z[7,6,6]  R2547     -2.3773482441902161e-01
    z[7,6,6]  R2548     4.4558718800544739e-01
    z[7,6,6]  R2549     -2.3907680809497833e-01
    z[7,6,6]  R2550     -1.8357668071985245e-02
    z[7,6,6]  R2551     1.3162803649902344e-01
    z[7,6,6]  R2552     -2.6334342360496521e-01
    z[7,6,6]  R2553     0.037345040589571
    z[7,6,6]  R2554     8.0668188631534576e-02
    z[7,6,6]  R2555     -6.9654747843742371e-02
    z[7,6,6]  R2556     3.0408850312232971e-01
    z[7,6,6]  R2557     -3.4142650663852692e-02
    z[7,6,6]  R2558     7.0212408900260925e-02
    z[7,6,6]  R2559     2.1300657093524933e-01
    z[7,6,6]  R2560     1.8506847321987152e-01
    z[7,6,6]  R2561     1.0416140779852867e-02
    z[7,6,6]  R2562     -1.9394992291927338e-01
    z[7,6,6]  R2563     0.459729939699173
    z[7,6,6]  R2564     6.2135362625122070e-01
    z[7,6,6]  R2565     2.1822814643383026e-01
    z[7,6,6]  R2566     1.9914092496037483e-02
    z[7,6,6]  R2567     1.3345773518085480e-01
    z[7,6,6]  R2568     -9.5125131309032440e-02
    z[7,6,6]  R2569     2.2910065948963165e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,9]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[8,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
