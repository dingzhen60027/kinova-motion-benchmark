NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  R2874   
 L  R2875   
 L  R2876   
 L  R2877   
 L  R2878   
 L  R2879   
 L  R2880   
 L  R2881   
 L  R2882   
 L  R2883   
 L  R2884   
 L  R2885   
 L  R2886   
 L  R2887   
 L  R2888   
 L  R2889   
 L  R2890   
 L  R2891   
 L  R2892   
 L  R2893   
 L  R2894   
 L  R2895   
 L  R2896   
 L  R2897   
 L  R2898   
 L  R2899   
 L  R2900   
 L  R2901   
 L  R2902   
 L  R2903   
 L  R2904   
 L  R2905   
 L  R2906   
 L  R2907   
 L  R2908   
 L  R2909   
 L  R2910   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       2.0427973270416260e+00
    phi[0,1]  R89       2.2757694721221924e+00
    phi[0,1]  R90       1.6986162662506104e+00
    phi[0,1]  R91       3.8067259788513184e+00
    phi[0,1]  R92       2.6815977096557617e+00
    phi[0,1]  R93       2.5233860015869141e+00
    phi[0,1]  R94       1.5551637411117554e+00
    phi[0,1]  R95       3.0698518753051758e+00
    phi[0,1]  R96       1.2796058654785156e+00
    phi[0,1]  R97       -8.4185725450515747e-01
    phi[0,1]  R98       -2.7376434803009033e+00
    phi[0,1]  R99       -9.4681429862976074e-01
    phi[0,1]  R100      -8.7943130731582642e-01
    phi[0,1]  R101      -1.3914676904678345e+00
    phi[0,1]  R102      -2.8627681732177734e+00
    phi[0,1]  R103      -1.0149374008178711e+00
    phi[0,1]  R104      -2.3210048675537109e+00
    phi[0,1]  R105      -9.6770006418228149e-01
    phi[0,1]  R106      4.0703853964805603e-01
    phi[0,1]  R107      3.9552378654479980e+00
    phi[0,1]  R108      2.5381388664245605e+00
    phi[0,1]  R109      2.4268648624420166e+00
    phi[0,1]  R110      1.2342888116836548e+00
    phi[0,1]  R111      -8.5438555479049683e-01
    phi[0,1]  R112      6.3741654157638550e-01
    phi[0,1]  R113      -4.4352538883686066e-02
    phi[0,1]  R114      -6.9652348756790161e-01
    phi[0,1]  R115      -4.7616913914680481e-01
    phi[0,1]  R116      2.4117159843444824e+00
    phi[0,1]  R117      1.5765570402145386e+00
    phi[0,1]  R118      1.6320879459381104e+00
    phi[0,1]  R119      5.0067889690399170e-01
    phi[0,1]  R120      1.8667125701904297e+00
    phi[0,1]  R121      7.7196162939071655e-01
    phi[0,1]  R122      1.7154006958007812e+00
    phi[0,1]  R123      2.2591309547424316e+00
    phi[0,1]  R124      1.6325143575668335e+00
    phi[0,1]  R125      1.3616846799850464e+00
    phi[0,1]  R126      0.684239387512207
    phi[0,1]  R127      -3.2590997219085693e+00
    phi[0,1]  R128      2.1323163509368896e+00
    phi[0,1]  R129      2.9252562522888184e+00
    phi[0,1]  R130      2.4478802680969238e+00
    phi[0,1]  R131      1.5936561822891235e+00
    phi[0,1]  R132      1.2575318813323975e+00
    phi[0,1]  R133      1.1573538780212402e+00
    phi[0,1]  R134      8.5372859239578247e-01
    phi[0,1]  R135      4.9510776996612549e-02
    phi[0,1]  R136      2.6940586566925049e+00
    phi[0,1]  R137      -1.9242057800292969e+00
    phi[0,1]  R138      2.2580431401729584e-01
    phi[0,1]  R139      -2.8023431301116943e+00
    phi[0,1]  R140      -8.5919326543807983e-01
    phi[0,1]  R141      -1.7874330282211304e+00
    phi[0,1]  R142      -1.1359305381774902e+00
    phi[0,1]  R143      -1.4676218032836914e+00
    phi[0,1]  R144      -1.9183627367019653e+00
    phi[0,1]  R145      -3.0257632732391357e+00
    phi[0,1]  R146      -3.5881071090698242e+00
    phi[0,1]  R147      -9.9329793453216553e-01
    phi[0,1]  R148      -5.7472509145736694e-01
    phi[0,1]  R149      2.5801005959510803e-01
    phi[0,1]  R150      1.4462624788284302e+00
    phi[0,1]  R151      -2.8182554244995117e+00
    phi[0,1]  R152      -2.3441600799560547e-01
    phi[0,1]  R153      -1.7814552783966064e+00
    phi[0,1]  R154      -3.4424442052841187e-01
    phi[0,1]  R155      -3.7713727355003357e-01
    phi[0,1]  R156      3.5252150893211365e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R157      -3.0999999046325684e+00
    phi[1,0]  R158      -3.0999999046325684e+00
    phi[1,0]  R159      -2.2400000095367432e+00
    phi[1,0]  R160      -2.2400000095367432e+00
    phi[1,0]  R161      -3.0999999046325684e+00
    phi[1,0]  R162      -3.0999999046325684e+00
    phi[1,0]  R163      -2.5699999332427979e+00
    phi[1,0]  R164      -2.5699999332427979e+00
    phi[1,0]  R165      -3.0999999046325684e+00
    phi[1,0]  R166      -3.0999999046325684e+00
    phi[1,0]  R167      -2.0899999141693115e+00
    phi[1,0]  R168      -2.0899999141693115e+00
    phi[1,0]  R169      -3.0999999046325684e+00
    phi[1,0]  R170      -3.0999999046325684e+00
    phi[1,0]  R171      1.5765570402145386e+00
    phi[1,0]  R172      1.6320879459381104e+00
    phi[1,0]  R173      5.0067889690399170e-01
    phi[1,0]  R174      1.8667125701904297e+00
    phi[1,0]  R175      7.7196162939071655e-01
    phi[1,0]  R176      1.7154006958007812e+00
    phi[1,0]  R177      2.2591309547424316e+00
    phi[1,0]  R178      1.6325143575668335e+00
    phi[1,0]  R179      1.3616846799850464e+00
    phi[1,0]  R180      0.684239387512207
    phi[1,0]  R181      -3.2590997219085693e+00
    phi[1,0]  R182      2.1323163509368896e+00
    phi[1,0]  R183      2.9252562522888184e+00
    phi[1,0]  R184      2.4478802680969238e+00
    phi[1,0]  R185      1.5936561822891235e+00
    phi[1,0]  R186      1.2575318813323975e+00
    phi[1,0]  R187      1.1573538780212402e+00
    phi[1,0]  R188      8.5372859239578247e-01
    phi[1,0]  R189      4.9510776996612549e-02
    phi[1,0]  R190      2.6940586566925049e+00
    phi[1,0]  R191      -1.9242057800292969e+00
    phi[1,0]  R192      2.2580431401729584e-01
    phi[1,0]  R193      -2.8023431301116943e+00
    phi[1,0]  R194      -8.5919326543807983e-01
    phi[1,0]  R195      -1.7874330282211304e+00
    phi[1,0]  R196      -1.1359305381774902e+00
    phi[1,0]  R197      -1.4676218032836914e+00
    phi[1,0]  R198      -1.9183627367019653e+00
    phi[1,0]  R199      -3.0257632732391357e+00
    phi[1,0]  R200      -3.5881071090698242e+00
    phi[1,0]  R201      -9.9329793453216553e-01
    phi[1,0]  R202      -5.7472509145736694e-01
    phi[1,0]  R203      2.5801005959510803e-01
    phi[1,0]  R204      1.4462624788284302e+00
    phi[1,0]  R205      -2.8182554244995117e+00
    phi[1,0]  R206      -2.3441600799560547e-01
    phi[1,0]  R207      -1.7814552783966064e+00
    phi[1,0]  R208      -3.4424442052841187e-01
    phi[1,0]  R209      -3.7713727355003357e-01
    phi[1,0]  R210      3.5252150893211365e-01
    phi[1,0]  R211      2.0427973270416260e+00
    phi[1,0]  R212      2.2757694721221924e+00
    phi[1,0]  R213      1.6986162662506104e+00
    phi[1,0]  R214      3.8067259788513184e+00
    phi[1,0]  R215      2.6815977096557617e+00
    phi[1,0]  R216      2.5233860015869141e+00
    phi[1,0]  R217      1.5551637411117554e+00
    phi[1,0]  R218      3.0698518753051758e+00
    phi[1,0]  R219      1.2796058654785156e+00
    phi[1,0]  R220      -8.4185725450515747e-01
    phi[1,0]  R221      -2.7376434803009033e+00
    phi[1,0]  R222      -9.4681429862976074e-01
    phi[1,0]  R223      -8.7943130731582642e-01
    phi[1,0]  R224      -1.3914676904678345e+00
    phi[1,0]  R225      -2.8627681732177734e+00
    phi[1,0]  R226      -1.0149374008178711e+00
    phi[1,0]  R227      -2.3210048675537109e+00
    phi[1,0]  R228      -9.6770006418228149e-01
    phi[1,0]  R229      4.0703853964805603e-01
    phi[1,0]  R230      3.9552378654479980e+00
    phi[1,0]  R231      2.5381388664245605e+00
    phi[1,0]  R232      2.4268648624420166e+00
    phi[1,0]  R233      1.2342888116836548e+00
    phi[1,0]  R234      -8.5438555479049683e-01
    phi[1,0]  R235      6.3741654157638550e-01
    phi[1,0]  R236      -4.4352538883686066e-02
    phi[1,0]  R237      -6.9652348756790161e-01
    phi[1,0]  R238      -4.7616913914680481e-01
    phi[1,0]  R239      2.4117159843444824e+00
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R240      -3.0999999046325684e+00
    phi[0,5]  R241      -3.0999999046325684e+00
    phi[0,5]  R242      -2.2400000095367432e+00
    phi[0,5]  R243      -2.2400000095367432e+00
    phi[0,5]  R244      -3.0999999046325684e+00
    phi[0,5]  R245      -3.0999999046325684e+00
    phi[0,5]  R246      -2.5699999332427979e+00
    phi[0,5]  R247      -2.5699999332427979e+00
    phi[0,5]  R248      -3.0999999046325684e+00
    phi[0,5]  R249      -3.0999999046325684e+00
    phi[0,5]  R250      -2.0899999141693115e+00
    phi[0,5]  R251      -2.0899999141693115e+00
    phi[0,5]  R252      -3.0999999046325684e+00
    phi[0,5]  R253      -3.0999999046325684e+00
    phi[0,5]  R254      2.0427973270416260e+00
    phi[0,5]  R255      2.2757694721221924e+00
    phi[0,5]  R256      1.6986162662506104e+00
    phi[0,5]  R257      3.8067259788513184e+00
    phi[0,5]  R258      2.6815977096557617e+00
    phi[0,5]  R259      2.5233860015869141e+00
    phi[0,5]  R260      1.5551637411117554e+00
    phi[0,5]  R261      3.0698518753051758e+00
    phi[0,5]  R262      1.2796058654785156e+00
    phi[0,5]  R263      -8.4185725450515747e-01
    phi[0,5]  R264      -2.7376434803009033e+00
    phi[0,5]  R265      -9.4681429862976074e-01
    phi[0,5]  R266      -8.7943130731582642e-01
    phi[0,5]  R267      -1.3914676904678345e+00
    phi[0,5]  R268      -2.8627681732177734e+00
    phi[0,5]  R269      -1.0149374008178711e+00
    phi[0,5]  R270      -2.3210048675537109e+00
    phi[0,5]  R271      -9.6770006418228149e-01
    phi[0,5]  R272      4.0703853964805603e-01
    phi[0,5]  R273      3.9552378654479980e+00
    phi[0,5]  R274      2.5381388664245605e+00
    phi[0,5]  R275      2.4268648624420166e+00
    phi[0,5]  R276      1.2342888116836548e+00
    phi[0,5]  R277      -8.5438555479049683e-01
    phi[0,5]  R278      6.3741654157638550e-01
    phi[0,5]  R279      -4.4352538883686066e-02
    phi[0,5]  R280      -6.9652348756790161e-01
    phi[0,5]  R281      -4.7616913914680481e-01
    phi[0,5]  R282      2.4117159843444824e+00
    phi[0,5]  R283      1.8164458274841309e+00
    phi[0,5]  R284      1.8318803310394287e+00
    phi[0,5]  R285      2.6805303096771240e+00
    phi[0,5]  R286      3.1378457546234131e+00
    phi[0,5]  R287      1.6333773136138916e+00
    phi[0,5]  R288      3.1371634006500244e+00
    phi[0,5]  R289      2.1908650398254395e+00
    phi[0,5]  R290      1.8168040513992310e+00
    phi[0,5]  R291      2.7592725753784180e+00
    phi[0,5]  R292      3.3667798042297363e+00
    phi[0,5]  R293      -2.9324169158935547e+00
    phi[0,5]  R294      -0.565557062625885
    phi[0,5]  R295      6.4368438720703125e-01
    phi[0,5]  R296      7.4732547998428345e-01
    phi[0,5]  R297      -2.5832197666168213e+00
    phi[0,5]  R298      1.3125869035720825e+00
    phi[0,5]  R299      -2.6062109470367432e+00
    phi[0,5]  R300      0.457389771938324
    phi[0,5]  R301      -2.7732777595520020e+00
    phi[0,5]  R302      -2.9012253284454346e+00
    phi[0,5]  R303      -1.4401623010635376e+00
    phi[0,5]  R304      -1.9682992696762085e+00
    phi[0,5]  R305      -2.0095534324645996e+00
    phi[0,5]  R306      -1.4318299293518066e+00
    phi[0,5]  R307      -1.8964453935623169e+00
    phi[0,5]  R308      2.8923410922288895e-02
    phi[0,5]  R309      2.4327416718006134e-01
    phi[0,5]  R310      -1.5997023582458496e+00
    phi[0,5]  R311      -3.2220003008842468e-01
    phi[0,5]  R312      -1.6942701339721680e+00
    phi[0,5]  R313      1.0142395645380020e-01
    phi[0,5]  R314      1.3020439147949219e+00
    phi[0,5]  R315      1.4210131168365479e+00
    phi[0,5]  R316      -9.2495054006576538e-01
    phi[0,5]  R317      -1.0616614818572998e+00
    phi[0,5]  R318      -1.7967464029788971e-01
    phi[0,5]  R319      2.1905419826507568e+00
    phi[0,5]  R320      1.6220375299453735e+00
    phi[0,5]  R321      -1.9336706399917603e-01
    phi[0,5]  R322      1.1039793491363525e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R323      -3.0999999046325684e+00
    phi[5,0]  R324      -3.0999999046325684e+00
    phi[5,0]  R325      -2.2400000095367432e+00
    phi[5,0]  R326      -2.2400000095367432e+00
    phi[5,0]  R327      -3.0999999046325684e+00
    phi[5,0]  R328      -3.0999999046325684e+00
    phi[5,0]  R329      -2.5699999332427979e+00
    phi[5,0]  R330      -2.5699999332427979e+00
    phi[5,0]  R331      -3.0999999046325684e+00
    phi[5,0]  R332      -3.0999999046325684e+00
    phi[5,0]  R333      -2.0899999141693115e+00
    phi[5,0]  R334      -2.0899999141693115e+00
    phi[5,0]  R335      -3.0999999046325684e+00
    phi[5,0]  R336      -3.0999999046325684e+00
    phi[5,0]  R337      1.8164458274841309e+00
    phi[5,0]  R338      1.8318803310394287e+00
    phi[5,0]  R339      2.6805303096771240e+00
    phi[5,0]  R340      3.1378457546234131e+00
    phi[5,0]  R341      1.6333773136138916e+00
    phi[5,0]  R342      3.1371634006500244e+00
    phi[5,0]  R343      2.1908650398254395e+00
    phi[5,0]  R344      1.8168040513992310e+00
    phi[5,0]  R345      2.7592725753784180e+00
    phi[5,0]  R346      3.3667798042297363e+00
    phi[5,0]  R347      -2.9324169158935547e+00
    phi[5,0]  R348      -0.565557062625885
    phi[5,0]  R349      6.4368438720703125e-01
    phi[5,0]  R350      7.4732547998428345e-01
    phi[5,0]  R351      -2.5832197666168213e+00
    phi[5,0]  R352      1.3125869035720825e+00
    phi[5,0]  R353      -2.6062109470367432e+00
    phi[5,0]  R354      0.457389771938324
    phi[5,0]  R355      -2.7732777595520020e+00
    phi[5,0]  R356      -2.9012253284454346e+00
    phi[5,0]  R357      -1.4401623010635376e+00
    phi[5,0]  R358      -1.9682992696762085e+00
    phi[5,0]  R359      -2.0095534324645996e+00
    phi[5,0]  R360      -1.4318299293518066e+00
    phi[5,0]  R361      -1.8964453935623169e+00
    phi[5,0]  R362      2.8923410922288895e-02
    phi[5,0]  R363      2.4327416718006134e-01
    phi[5,0]  R364      -1.5997023582458496e+00
    phi[5,0]  R365      -3.2220003008842468e-01
    phi[5,0]  R366      -1.6942701339721680e+00
    phi[5,0]  R367      1.0142395645380020e-01
    phi[5,0]  R368      1.3020439147949219e+00
    phi[5,0]  R369      1.4210131168365479e+00
    phi[5,0]  R370      -9.2495054006576538e-01
    phi[5,0]  R371      -1.0616614818572998e+00
    phi[5,0]  R372      -1.7967464029788971e-01
    phi[5,0]  R373      2.1905419826507568e+00
    phi[5,0]  R374      1.6220375299453735e+00
    phi[5,0]  R375      -1.9336706399917603e-01
    phi[5,0]  R376      1.1039793491363525e+00
    phi[5,0]  R377      2.0427973270416260e+00
    phi[5,0]  R378      2.2757694721221924e+00
    phi[5,0]  R379      1.6986162662506104e+00
    phi[5,0]  R380      3.8067259788513184e+00
    phi[5,0]  R381      2.6815977096557617e+00
    phi[5,0]  R382      2.5233860015869141e+00
    phi[5,0]  R383      1.5551637411117554e+00
    phi[5,0]  R384      3.0698518753051758e+00
    phi[5,0]  R385      1.2796058654785156e+00
    phi[5,0]  R386      -8.4185725450515747e-01
    phi[5,0]  R387      -2.7376434803009033e+00
    phi[5,0]  R388      -9.4681429862976074e-01
    phi[5,0]  R389      -8.7943130731582642e-01
    phi[5,0]  R390      -1.3914676904678345e+00
    phi[5,0]  R391      -2.8627681732177734e+00
    phi[5,0]  R392      -1.0149374008178711e+00
    phi[5,0]  R393      -2.3210048675537109e+00
    phi[5,0]  R394      -9.6770006418228149e-01
    phi[5,0]  R395      4.0703853964805603e-01
    phi[5,0]  R396      3.9552378654479980e+00
    phi[5,0]  R397      2.5381388664245605e+00
    phi[5,0]  R398      2.4268648624420166e+00
    phi[5,0]  R399      1.2342888116836548e+00
    phi[5,0]  R400      -8.5438555479049683e-01
    phi[5,0]  R401      6.3741654157638550e-01
    phi[5,0]  R402      -4.4352538883686066e-02
    phi[5,0]  R403      -6.9652348756790161e-01
    phi[5,0]  R404      -4.7616913914680481e-01
    phi[5,0]  R405      2.4117159843444824e+00
    phi[8,0]  R0        -1
    phi[8,0]  R2        2.4280373490850491e+00
    phi[8,0]  R3        -1.3132209009369293e+00
    phi[8,0]  R4        1.9351976823299606e+00
    phi[8,0]  R5        4.4194927199437695e-01
    phi[8,0]  R6        1.7853737027742844e+00
    phi[8,0]  R7        1.4309910660578291e+00
    phi[8,0]  R8        -2.6744558564763574e+00
    phi[8,0]  R72       1
    phi[8,0]  R406      -5.5280372537176170e+00
    phi[8,0]  R407      -6.7196255554751927e-01
    phi[8,0]  R408      -9.2677910859981383e-01
    phi[8,0]  R409      -3.5532209104736725e+00
    phi[8,0]  R410      -5.0351975869625285e+00
    phi[8,0]  R411      -1.1648022223026078e+00
    phi[8,0]  R412      -3.0119492052371748e+00
    phi[8,0]  R413      -2.1280506612484209e+00
    phi[8,0]  R414      -4.8853736074068532e+00
    phi[8,0]  R415      -1.3146262018582839e+00
    phi[8,0]  R416      -3.5209909802271406e+00
    phi[8,0]  R417      -6.5900884811148241e-01
    phi[8,0]  R418      -4.2554404815621094e-01
    phi[8,0]  R419      -5.7744557611089258e+00
    phi[8,0]  R420      -4.3160285463801795e-02
    phi[8,0]  R421      -4.3229958286601367e-02
    phi[8,0]  R422      -5.4262726474519685e-02
    phi[8,0]  R423      -5.9678134624257417e-02
    phi[8,0]  R424      -6.2457643146027753e-02
    phi[8,0]  R425      -7.0777507367321135e-02
    phi[8,0]  R426      -8.7740762531520744e-02
    phi[8,0]  R427      -9.7623751848000762e-02
    phi[8,0]  R428      -1.4246508459647522e-01
    phi[8,0]  R429      -1.5007082507089153e-01
    phi[8,0]  R430      -2.2220016479660210e-02
    phi[8,0]  R431      -4.0144816067069877e-02
    phi[8,0]  R432      -4.6904577785390589e-02
    phi[8,0]  R433      -5.7947682470380180e-02
    phi[8,0]  R434      -7.9690641180498289e-02
    phi[8,0]  R435      -1.1718650724284529e-01
    phi[8,0]  R436      -1.3129689162826974e-01
    phi[8,0]  R437      -9.4430905937574550e-01
    phi[8,0]  R438      -0.807619007293745
    phi[8,0]  R439      -2.0241673209668853e-02
    phi[8,0]  R440      -2.8633546075846894e-02
    phi[8,0]  R441      -3.3542726993276872e-02
    phi[8,0]  R442      -0.0353039071294039
    phi[8,0]  R443      -5.8565554000532760e-02
    phi[8,0]  R444      -6.0114756983919881e-02
    phi[8,0]  R445      -6.4883599298165562e-02
    phi[8,0]  R446      -6.8872850240724759e-02
    phi[8,0]  R447      -7.2813479594125874e-02
    phi[8,0]  R448      -0.0730724001513865
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R449      -3.0999999046325684e+00
    phi[1,2]  R450      -3.0999999046325684e+00
    phi[1,2]  R451      -2.2400000095367432e+00
    phi[1,2]  R452      -2.2400000095367432e+00
    phi[1,2]  R453      -3.0999999046325684e+00
    phi[1,2]  R454      -3.0999999046325684e+00
    phi[1,2]  R455      -2.5699999332427979e+00
    phi[1,2]  R456      -2.5699999332427979e+00
    phi[1,2]  R457      -3.0999999046325684e+00
    phi[1,2]  R458      -3.0999999046325684e+00
    phi[1,2]  R459      -2.0899999141693115e+00
    phi[1,2]  R460      -2.0899999141693115e+00
    phi[1,2]  R461      -3.0999999046325684e+00
    phi[1,2]  R462      -3.0999999046325684e+00
    phi[1,2]  R463      1.5765570402145386e+00
    phi[1,2]  R464      1.6320879459381104e+00
    phi[1,2]  R465      5.0067889690399170e-01
    phi[1,2]  R466      1.8667125701904297e+00
    phi[1,2]  R467      7.7196162939071655e-01
    phi[1,2]  R468      1.7154006958007812e+00
    phi[1,2]  R469      2.2591309547424316e+00
    phi[1,2]  R470      1.6325143575668335e+00
    phi[1,2]  R471      1.3616846799850464e+00
    phi[1,2]  R472      0.684239387512207
    phi[1,2]  R473      -3.2590997219085693e+00
    phi[1,2]  R474      2.1323163509368896e+00
    phi[1,2]  R475      2.9252562522888184e+00
    phi[1,2]  R476      2.4478802680969238e+00
    phi[1,2]  R477      1.5936561822891235e+00
    phi[1,2]  R478      1.2575318813323975e+00
    phi[1,2]  R479      1.1573538780212402e+00
    phi[1,2]  R480      8.5372859239578247e-01
    phi[1,2]  R481      4.9510776996612549e-02
    phi[1,2]  R482      2.6940586566925049e+00
    phi[1,2]  R483      -1.9242057800292969e+00
    phi[1,2]  R484      2.2580431401729584e-01
    phi[1,2]  R485      -2.8023431301116943e+00
    phi[1,2]  R486      -8.5919326543807983e-01
    phi[1,2]  R487      -1.7874330282211304e+00
    phi[1,2]  R488      -1.1359305381774902e+00
    phi[1,2]  R489      -1.4676218032836914e+00
    phi[1,2]  R490      -1.9183627367019653e+00
    phi[1,2]  R491      -3.0257632732391357e+00
    phi[1,2]  R492      -3.5881071090698242e+00
    phi[1,2]  R493      -9.9329793453216553e-01
    phi[1,2]  R494      -5.7472509145736694e-01
    phi[1,2]  R495      2.5801005959510803e-01
    phi[1,2]  R496      1.4462624788284302e+00
    phi[1,2]  R497      -2.8182554244995117e+00
    phi[1,2]  R498      -2.3441600799560547e-01
    phi[1,2]  R499      -1.7814552783966064e+00
    phi[1,2]  R500      -3.4424442052841187e-01
    phi[1,2]  R501      -3.7713727355003357e-01
    phi[1,2]  R502      3.5252150893211365e-01
    phi[1,2]  R503      6.6751681268215179e-02
    phi[1,2]  R504      2.1529221534729004e+00
    phi[1,2]  R505      1.3592885732650757e+00
    phi[1,2]  R506      -1.1100682020187378e+00
    phi[1,2]  R507      -0.377239465713501
    phi[1,2]  R508      -1.5075632333755493e+00
    phi[1,2]  R509      -2.8117433190345764e-01
    phi[1,2]  R510      6.1604022979736328e-01
    phi[1,2]  R511      1.1352250576019287e+00
    phi[1,2]  R512      7.6257783174514771e-01
    phi[1,2]  R513      -7.2680443525314331e-01
    phi[1,2]  R514      -3.8788786530494690e-01
    phi[1,2]  R515      -1.6665056943893433e+00
    phi[1,2]  R516      -2.1840353012084961e+00
    phi[1,2]  R517      -2.9117641448974609e+00
    phi[1,2]  R518      -2.1517713069915771e+00
    phi[1,2]  R519      -1.6230702400207520e+00
    phi[1,2]  R520      -1.7654137611389160e+00
    phi[1,2]  R521      -1.85004723072052
    phi[1,2]  R522      -1.5196650028228760e+00
    phi[1,2]  R523      -5.3928512334823608e-01
    phi[1,2]  R524      -2.1782326698303223e+00
    phi[1,2]  R525      2.6196840405464172e-01
    phi[1,2]  R526      -2.0811834335327148e+00
    phi[1,2]  R527      -5.4254758358001709e-01
    phi[1,2]  R528      -8.7234598398208618e-01
    phi[1,2]  R529      -2.7398548126220703e+00
    phi[1,2]  R530      5.0222057104110718e-01
    phi[1,2]  R531      -3.5139522552490234e+00
    phi[1,2]  R532      -9.2963731288909912e-01
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R533      -3.0999999046325684e+00
    phi[2,1]  R534      -3.0999999046325684e+00
    phi[2,1]  R535      -2.2400000095367432e+00
    phi[2,1]  R536      -2.2400000095367432e+00
    phi[2,1]  R537      -3.0999999046325684e+00
    phi[2,1]  R538      -3.0999999046325684e+00
    phi[2,1]  R539      -2.5699999332427979e+00
    phi[2,1]  R540      -2.5699999332427979e+00
    phi[2,1]  R541      -3.0999999046325684e+00
    phi[2,1]  R542      -3.0999999046325684e+00
    phi[2,1]  R543      -2.0899999141693115e+00
    phi[2,1]  R544      -2.0899999141693115e+00
    phi[2,1]  R545      -3.0999999046325684e+00
    phi[2,1]  R546      -3.0999999046325684e+00
    phi[2,1]  R547      6.6751681268215179e-02
    phi[2,1]  R548      2.1529221534729004e+00
    phi[2,1]  R549      1.3592885732650757e+00
    phi[2,1]  R550      -1.1100682020187378e+00
    phi[2,1]  R551      -0.377239465713501
    phi[2,1]  R552      -1.5075632333755493e+00
    phi[2,1]  R553      -2.8117433190345764e-01
    phi[2,1]  R554      6.1604022979736328e-01
    phi[2,1]  R555      1.1352250576019287e+00
    phi[2,1]  R556      7.6257783174514771e-01
    phi[2,1]  R557      -7.2680443525314331e-01
    phi[2,1]  R558      -3.8788786530494690e-01
    phi[2,1]  R559      -1.6665056943893433e+00
    phi[2,1]  R560      -2.1840353012084961e+00
    phi[2,1]  R561      -2.9117641448974609e+00
    phi[2,1]  R562      -2.1517713069915771e+00
    phi[2,1]  R563      -1.6230702400207520e+00
    phi[2,1]  R564      -1.7654137611389160e+00
    phi[2,1]  R565      -1.85004723072052
    phi[2,1]  R566      -1.5196650028228760e+00
    phi[2,1]  R567      -5.3928512334823608e-01
    phi[2,1]  R568      -2.1782326698303223e+00
    phi[2,1]  R569      2.6196840405464172e-01
    phi[2,1]  R570      -2.0811834335327148e+00
    phi[2,1]  R571      -5.4254758358001709e-01
    phi[2,1]  R572      -8.7234598398208618e-01
    phi[2,1]  R573      -2.7398548126220703e+00
    phi[2,1]  R574      5.0222057104110718e-01
    phi[2,1]  R575      -3.5139522552490234e+00
    phi[2,1]  R576      -9.2963731288909912e-01
    phi[2,1]  R577      1.5765570402145386e+00
    phi[2,1]  R578      1.6320879459381104e+00
    phi[2,1]  R579      5.0067889690399170e-01
    phi[2,1]  R580      1.8667125701904297e+00
    phi[2,1]  R581      7.7196162939071655e-01
    phi[2,1]  R582      1.7154006958007812e+00
    phi[2,1]  R583      2.2591309547424316e+00
    phi[2,1]  R584      1.6325143575668335e+00
    phi[2,1]  R585      1.3616846799850464e+00
    phi[2,1]  R586      0.684239387512207
    phi[2,1]  R587      -3.2590997219085693e+00
    phi[2,1]  R588      2.1323163509368896e+00
    phi[2,1]  R589      2.9252562522888184e+00
    phi[2,1]  R590      2.4478802680969238e+00
    phi[2,1]  R591      1.5936561822891235e+00
    phi[2,1]  R592      1.2575318813323975e+00
    phi[2,1]  R593      1.1573538780212402e+00
    phi[2,1]  R594      8.5372859239578247e-01
    phi[2,1]  R595      4.9510776996612549e-02
    phi[2,1]  R596      2.6940586566925049e+00
    phi[2,1]  R597      -1.9242057800292969e+00
    phi[2,1]  R598      2.2580431401729584e-01
    phi[2,1]  R599      -2.8023431301116943e+00
    phi[2,1]  R600      -8.5919326543807983e-01
    phi[2,1]  R601      -1.7874330282211304e+00
    phi[2,1]  R602      -1.1359305381774902e+00
    phi[2,1]  R603      -1.4676218032836914e+00
    phi[2,1]  R604      -1.9183627367019653e+00
    phi[2,1]  R605      -3.0257632732391357e+00
    phi[2,1]  R606      -3.5881071090698242e+00
    phi[2,1]  R607      -9.9329793453216553e-01
    phi[2,1]  R608      -5.7472509145736694e-01
    phi[2,1]  R609      2.5801005959510803e-01
    phi[2,1]  R610      1.4462624788284302e+00
    phi[2,1]  R611      -2.8182554244995117e+00
    phi[2,1]  R612      -2.3441600799560547e-01
    phi[2,1]  R613      -1.7814552783966064e+00
    phi[2,1]  R614      -3.4424442052841187e-01
    phi[2,1]  R615      -3.7713727355003357e-01
    phi[2,1]  R616      3.5252150893211365e-01
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R617      -3.0999999046325684e+00
    phi[1,5]  R618      -3.0999999046325684e+00
    phi[1,5]  R619      -2.2400000095367432e+00
    phi[1,5]  R620      -2.2400000095367432e+00
    phi[1,5]  R621      -3.0999999046325684e+00
    phi[1,5]  R622      -3.0999999046325684e+00
    phi[1,5]  R623      -2.5699999332427979e+00
    phi[1,5]  R624      -2.5699999332427979e+00
    phi[1,5]  R625      -3.0999999046325684e+00
    phi[1,5]  R626      -3.0999999046325684e+00
    phi[1,5]  R627      -2.0899999141693115e+00
    phi[1,5]  R628      -2.0899999141693115e+00
    phi[1,5]  R629      -3.0999999046325684e+00
    phi[1,5]  R630      -3.0999999046325684e+00
    phi[1,5]  R631      1.5765570402145386e+00
    phi[1,5]  R632      1.6320879459381104e+00
    phi[1,5]  R633      5.0067889690399170e-01
    phi[1,5]  R634      1.8667125701904297e+00
    phi[1,5]  R635      7.7196162939071655e-01
    phi[1,5]  R636      1.7154006958007812e+00
    phi[1,5]  R637      2.2591309547424316e+00
    phi[1,5]  R638      1.6325143575668335e+00
    phi[1,5]  R639      1.3616846799850464e+00
    phi[1,5]  R640      0.684239387512207
    phi[1,5]  R641      -3.2590997219085693e+00
    phi[1,5]  R642      2.1323163509368896e+00
    phi[1,5]  R643      2.9252562522888184e+00
    phi[1,5]  R644      2.4478802680969238e+00
    phi[1,5]  R645      1.5936561822891235e+00
    phi[1,5]  R646      1.2575318813323975e+00
    phi[1,5]  R647      1.1573538780212402e+00
    phi[1,5]  R648      8.5372859239578247e-01
    phi[1,5]  R649      4.9510776996612549e-02
    phi[1,5]  R650      2.6940586566925049e+00
    phi[1,5]  R651      -1.9242057800292969e+00
    phi[1,5]  R652      2.2580431401729584e-01
    phi[1,5]  R653      -2.8023431301116943e+00
    phi[1,5]  R654      -8.5919326543807983e-01
    phi[1,5]  R655      -1.7874330282211304e+00
    phi[1,5]  R656      -1.1359305381774902e+00
    phi[1,5]  R657      -1.4676218032836914e+00
    phi[1,5]  R658      -1.9183627367019653e+00
    phi[1,5]  R659      -3.0257632732391357e+00
    phi[1,5]  R660      -3.5881071090698242e+00
    phi[1,5]  R661      -9.9329793453216553e-01
    phi[1,5]  R662      -5.7472509145736694e-01
    phi[1,5]  R663      2.5801005959510803e-01
    phi[1,5]  R664      1.4462624788284302e+00
    phi[1,5]  R665      -2.8182554244995117e+00
    phi[1,5]  R666      -2.3441600799560547e-01
    phi[1,5]  R667      -1.7814552783966064e+00
    phi[1,5]  R668      -3.4424442052841187e-01
    phi[1,5]  R669      -3.7713727355003357e-01
    phi[1,5]  R670      3.5252150893211365e-01
    phi[1,5]  R671      1.8164458274841309e+00
    phi[1,5]  R672      1.8318803310394287e+00
    phi[1,5]  R673      2.6805303096771240e+00
    phi[1,5]  R674      3.1378457546234131e+00
    phi[1,5]  R675      1.6333773136138916e+00
    phi[1,5]  R676      3.1371634006500244e+00
    phi[1,5]  R677      2.1908650398254395e+00
    phi[1,5]  R678      1.8168040513992310e+00
    phi[1,5]  R679      2.7592725753784180e+00
    phi[1,5]  R680      3.3667798042297363e+00
    phi[1,5]  R681      -2.9324169158935547e+00
    phi[1,5]  R682      -0.565557062625885
    phi[1,5]  R683      6.4368438720703125e-01
    phi[1,5]  R684      7.4732547998428345e-01
    phi[1,5]  R685      -2.5832197666168213e+00
    phi[1,5]  R686      1.3125869035720825e+00
    phi[1,5]  R687      -2.6062109470367432e+00
    phi[1,5]  R688      0.457389771938324
    phi[1,5]  R689      -2.7732777595520020e+00
    phi[1,5]  R690      -2.9012253284454346e+00
    phi[1,5]  R691      -1.4401623010635376e+00
    phi[1,5]  R692      -1.9682992696762085e+00
    phi[1,5]  R693      -2.0095534324645996e+00
    phi[1,5]  R694      -1.4318299293518066e+00
    phi[1,5]  R695      -1.8964453935623169e+00
    phi[1,5]  R696      2.8923410922288895e-02
    phi[1,5]  R697      2.4327416718006134e-01
    phi[1,5]  R698      -1.5997023582458496e+00
    phi[1,5]  R699      -3.2220003008842468e-01
    phi[1,5]  R700      -1.6942701339721680e+00
    phi[1,5]  R701      1.0142395645380020e-01
    phi[1,5]  R702      1.3020439147949219e+00
    phi[1,5]  R703      1.4210131168365479e+00
    phi[1,5]  R704      -9.2495054006576538e-01
    phi[1,5]  R705      -1.0616614818572998e+00
    phi[1,5]  R706      -1.7967464029788971e-01
    phi[1,5]  R707      2.1905419826507568e+00
    phi[1,5]  R708      1.6220375299453735e+00
    phi[1,5]  R709      -1.9336706399917603e-01
    phi[1,5]  R710      1.1039793491363525e+00
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R711      -3.0999999046325684e+00
    phi[5,1]  R712      -3.0999999046325684e+00
    phi[5,1]  R713      -2.2400000095367432e+00
    phi[5,1]  R714      -2.2400000095367432e+00
    phi[5,1]  R715      -3.0999999046325684e+00
    phi[5,1]  R716      -3.0999999046325684e+00
    phi[5,1]  R717      -2.5699999332427979e+00
    phi[5,1]  R718      -2.5699999332427979e+00
    phi[5,1]  R719      -3.0999999046325684e+00
    phi[5,1]  R720      -3.0999999046325684e+00
    phi[5,1]  R721      -2.0899999141693115e+00
    phi[5,1]  R722      -2.0899999141693115e+00
    phi[5,1]  R723      -3.0999999046325684e+00
    phi[5,1]  R724      -3.0999999046325684e+00
    phi[5,1]  R725      1.8164458274841309e+00
    phi[5,1]  R726      1.8318803310394287e+00
    phi[5,1]  R727      2.6805303096771240e+00
    phi[5,1]  R728      3.1378457546234131e+00
    phi[5,1]  R729      1.6333773136138916e+00
    phi[5,1]  R730      3.1371634006500244e+00
    phi[5,1]  R731      2.1908650398254395e+00
    phi[5,1]  R732      1.8168040513992310e+00
    phi[5,1]  R733      2.7592725753784180e+00
    phi[5,1]  R734      3.3667798042297363e+00
    phi[5,1]  R735      -2.9324169158935547e+00
    phi[5,1]  R736      -0.565557062625885
    phi[5,1]  R737      6.4368438720703125e-01
    phi[5,1]  R738      7.4732547998428345e-01
    phi[5,1]  R739      -2.5832197666168213e+00
    phi[5,1]  R740      1.3125869035720825e+00
    phi[5,1]  R741      -2.6062109470367432e+00
    phi[5,1]  R742      0.457389771938324
    phi[5,1]  R743      -2.7732777595520020e+00
    phi[5,1]  R744      -2.9012253284454346e+00
    phi[5,1]  R745      -1.4401623010635376e+00
    phi[5,1]  R746      -1.9682992696762085e+00
    phi[5,1]  R747      -2.0095534324645996e+00
    phi[5,1]  R748      -1.4318299293518066e+00
    phi[5,1]  R749      -1.8964453935623169e+00
    phi[5,1]  R750      2.8923410922288895e-02
    phi[5,1]  R751      2.4327416718006134e-01
    phi[5,1]  R752      -1.5997023582458496e+00
    phi[5,1]  R753      -3.2220003008842468e-01
    phi[5,1]  R754      -1.6942701339721680e+00
    phi[5,1]  R755      1.0142395645380020e-01
    phi[5,1]  R756      1.3020439147949219e+00
    phi[5,1]  R757      1.4210131168365479e+00
    phi[5,1]  R758      -9.2495054006576538e-01
    phi[5,1]  R759      -1.0616614818572998e+00
    phi[5,1]  R760      -1.7967464029788971e-01
    phi[5,1]  R761      2.1905419826507568e+00
    phi[5,1]  R762      1.6220375299453735e+00
    phi[5,1]  R763      -1.9336706399917603e-01
    phi[5,1]  R764      1.1039793491363525e+00
    phi[5,1]  R765      1.5765570402145386e+00
    phi[5,1]  R766      1.6320879459381104e+00
    phi[5,1]  R767      5.0067889690399170e-01
    phi[5,1]  R768      1.8667125701904297e+00
    phi[5,1]  R769      7.7196162939071655e-01
    phi[5,1]  R770      1.7154006958007812e+00
    phi[5,1]  R771      2.2591309547424316e+00
    phi[5,1]  R772      1.6325143575668335e+00
    phi[5,1]  R773      1.3616846799850464e+00
    phi[5,1]  R774      0.684239387512207
    phi[5,1]  R775      -3.2590997219085693e+00
    phi[5,1]  R776      2.1323163509368896e+00
    phi[5,1]  R777      2.9252562522888184e+00
    phi[5,1]  R778      2.4478802680969238e+00
    phi[5,1]  R779      1.5936561822891235e+00
    phi[5,1]  R780      1.2575318813323975e+00
    phi[5,1]  R781      1.1573538780212402e+00
    phi[5,1]  R782      8.5372859239578247e-01
    phi[5,1]  R783      4.9510776996612549e-02
    phi[5,1]  R784      2.6940586566925049e+00
    phi[5,1]  R785      -1.9242057800292969e+00
    phi[5,1]  R786      2.2580431401729584e-01
    phi[5,1]  R787      -2.8023431301116943e+00
    phi[5,1]  R788      -8.5919326543807983e-01
    phi[5,1]  R789      -1.7874330282211304e+00
    phi[5,1]  R790      -1.1359305381774902e+00
    phi[5,1]  R791      -1.4676218032836914e+00
    phi[5,1]  R792      -1.9183627367019653e+00
    phi[5,1]  R793      -3.0257632732391357e+00
    phi[5,1]  R794      -3.5881071090698242e+00
    phi[5,1]  R795      -9.9329793453216553e-01
    phi[5,1]  R796      -5.7472509145736694e-01
    phi[5,1]  R797      2.5801005959510803e-01
    phi[5,1]  R798      1.4462624788284302e+00
    phi[5,1]  R799      -2.8182554244995117e+00
    phi[5,1]  R800      -2.3441600799560547e-01
    phi[5,1]  R801      -1.7814552783966064e+00
    phi[5,1]  R802      -3.4424442052841187e-01
    phi[5,1]  R803      -3.7713727355003357e-01
    phi[5,1]  R804      3.5252150893211365e-01
    phi[1,6]  R9        1
    phi[1,6]  R10       1
    phi[1,6]  R54       -1
    phi[1,6]  R805      -3.0999999046325684e+00
    phi[1,6]  R806      -3.0999999046325684e+00
    phi[1,6]  R807      -2.2400000095367432e+00
    phi[1,6]  R808      -2.2400000095367432e+00
    phi[1,6]  R809      -3.0999999046325684e+00
    phi[1,6]  R810      -3.0999999046325684e+00
    phi[1,6]  R811      -2.5699999332427979e+00
    phi[1,6]  R812      -2.5699999332427979e+00
    phi[1,6]  R813      -3.0999999046325684e+00
    phi[1,6]  R814      -3.0999999046325684e+00
    phi[1,6]  R815      -2.0899999141693115e+00
    phi[1,6]  R816      -2.0899999141693115e+00
    phi[1,6]  R817      -3.0999999046325684e+00
    phi[1,6]  R818      -3.0999999046325684e+00
    phi[1,6]  R819      1.5765570402145386e+00
    phi[1,6]  R820      1.6320879459381104e+00
    phi[1,6]  R821      5.0067889690399170e-01
    phi[1,6]  R822      1.8667125701904297e+00
    phi[1,6]  R823      7.7196162939071655e-01
    phi[1,6]  R824      1.7154006958007812e+00
    phi[1,6]  R825      2.2591309547424316e+00
    phi[1,6]  R826      1.6325143575668335e+00
    phi[1,6]  R827      1.3616846799850464e+00
    phi[1,6]  R828      0.684239387512207
    phi[1,6]  R829      -3.2590997219085693e+00
    phi[1,6]  R830      2.1323163509368896e+00
    phi[1,6]  R831      2.9252562522888184e+00
    phi[1,6]  R832      2.4478802680969238e+00
    phi[1,6]  R833      1.5936561822891235e+00
    phi[1,6]  R834      1.2575318813323975e+00
    phi[1,6]  R835      1.1573538780212402e+00
    phi[1,6]  R836      8.5372859239578247e-01
    phi[1,6]  R837      4.9510776996612549e-02
    phi[1,6]  R838      2.6940586566925049e+00
    phi[1,6]  R839      -1.9242057800292969e+00
    phi[1,6]  R840      2.2580431401729584e-01
    phi[1,6]  R841      -2.8023431301116943e+00
    phi[1,6]  R842      -8.5919326543807983e-01
    phi[1,6]  R843      -1.7874330282211304e+00
    phi[1,6]  R844      -1.1359305381774902e+00
    phi[1,6]  R845      -1.4676218032836914e+00
    phi[1,6]  R846      -1.9183627367019653e+00
    phi[1,6]  R847      -3.0257632732391357e+00
    phi[1,6]  R848      -3.5881071090698242e+00
    phi[1,6]  R849      -9.9329793453216553e-01
    phi[1,6]  R850      -5.7472509145736694e-01
    phi[1,6]  R851      2.5801005959510803e-01
    phi[1,6]  R852      1.4462624788284302e+00
    phi[1,6]  R853      -2.8182554244995117e+00
    phi[1,6]  R854      -2.3441600799560547e-01
    phi[1,6]  R855      -1.7814552783966064e+00
    phi[1,6]  R856      -3.4424442052841187e-01
    phi[1,6]  R857      -3.7713727355003357e-01
    phi[1,6]  R858      3.5252150893211365e-01
    phi[1,6]  R859      2.6076083183288574e+00
    phi[1,6]  R860      6.8630856275558472e-01
    phi[1,6]  R861      2.1156513690948486e+00
    phi[1,6]  R862      1.4403879642486572e+00
    phi[1,6]  R863      1.9452199935913086e+00
    phi[1,6]  R864      1.8707634508609772e-01
    phi[1,6]  R865      9.6376115083694458e-01
    phi[1,6]  R866      1.2372753620147705e+00
    phi[1,6]  R867      1.5879375934600830e+00
    phi[1,6]  R868      1.2061446905136108e+00
    phi[1,6]  R869      -4.9308747053146362e-01
    phi[1,6]  R870      -3.1541643142700195e+00
    phi[1,6]  R871      -1.2181717157363892e+00
    phi[1,6]  R872      -6.5937983989715576e-01
    phi[1,6]  R873      -2.4126670360565186e+00
    phi[1,6]  R874      7.0902451872825623e-02
    phi[1,6]  R875      -4.1423029899597168e+00
    phi[1,6]  R876      -3.1070941686630249e-01
    phi[1,6]  R877      -1.9834290742874146e+00
    phi[1,6]  R878      -1.1414165496826172e+00
    phi[1,6]  R879      -1.6809436082839966e+00
    phi[1,6]  R880      6.7658799886703491e-01
    phi[1,6]  R881      3.9080739021301270e-02
    phi[1,6]  R882      -3.2035019397735596e+00
    phi[1,6]  R883      -2.5811049938201904e+00
    phi[1,6]  R884      -1.6233938932418823e+00
    phi[1,6]  R885      -1.0524587631225586e+00
    phi[1,6]  R886      -1.4967588186264038e+00
    phi[1,6]  R887      -2.1295061111450195e+00
    phi[1,6]  R888      4.0459814667701721e-01
    phi[1,6]  R889      -1.4126646518707275e-01
    phi[1,6]  R890      -1.4084001779556274e+00
    phi[1,6]  R891      6.4347761869430542e-01
    phi[1,6]  R892      -1.1718202829360962e+00
    phi[1,6]  R893      -2.3882064819335938e+00
    phi[1,6]  R894      -1.5724831819534302e+00
    phi[1,6]  R895      -1.1874619722366333e+00
    phi[1,6]  R896      -3.3879095315933228e-01
    phi[1,6]  R897      -1.1181638240814209e+00
    phi[1,6]  R898      -3.6107069253921509e-01
    phi[6,1]  R9        -1
    phi[6,1]  R54       1
    phi[6,1]  R55       1
    phi[6,1]  R899      -3.0999999046325684e+00
    phi[6,1]  R900      -3.0999999046325684e+00
    phi[6,1]  R901      -2.2400000095367432e+00
    phi[6,1]  R902      -2.2400000095367432e+00
    phi[6,1]  R903      -3.0999999046325684e+00
    phi[6,1]  R904      -3.0999999046325684e+00
    phi[6,1]  R905      -2.5699999332427979e+00
    phi[6,1]  R906      -2.5699999332427979e+00
    phi[6,1]  R907      -3.0999999046325684e+00
    phi[6,1]  R908      -3.0999999046325684e+00
    phi[6,1]  R909      -2.0899999141693115e+00
    phi[6,1]  R910      -2.0899999141693115e+00
    phi[6,1]  R911      -3.0999999046325684e+00
    phi[6,1]  R912      -3.0999999046325684e+00
    phi[6,1]  R913      2.6076083183288574e+00
    phi[6,1]  R914      6.8630856275558472e-01
    phi[6,1]  R915      2.1156513690948486e+00
    phi[6,1]  R916      1.4403879642486572e+00
    phi[6,1]  R917      1.9452199935913086e+00
    phi[6,1]  R918      1.8707634508609772e-01
    phi[6,1]  R919      9.6376115083694458e-01
    phi[6,1]  R920      1.2372753620147705e+00
    phi[6,1]  R921      1.5879375934600830e+00
    phi[6,1]  R922      1.2061446905136108e+00
    phi[6,1]  R923      -4.9308747053146362e-01
    phi[6,1]  R924      -3.1541643142700195e+00
    phi[6,1]  R925      -1.2181717157363892e+00
    phi[6,1]  R926      -6.5937983989715576e-01
    phi[6,1]  R927      -2.4126670360565186e+00
    phi[6,1]  R928      7.0902451872825623e-02
    phi[6,1]  R929      -4.1423029899597168e+00
    phi[6,1]  R930      -3.1070941686630249e-01
    phi[6,1]  R931      -1.9834290742874146e+00
    phi[6,1]  R932      -1.1414165496826172e+00
    phi[6,1]  R933      -1.6809436082839966e+00
    phi[6,1]  R934      6.7658799886703491e-01
    phi[6,1]  R935      3.9080739021301270e-02
    phi[6,1]  R936      -3.2035019397735596e+00
    phi[6,1]  R937      -2.5811049938201904e+00
    phi[6,1]  R938      -1.6233938932418823e+00
    phi[6,1]  R939      -1.0524587631225586e+00
    phi[6,1]  R940      -1.4967588186264038e+00
    phi[6,1]  R941      -2.1295061111450195e+00
    phi[6,1]  R942      4.0459814667701721e-01
    phi[6,1]  R943      -1.4126646518707275e-01
    phi[6,1]  R944      -1.4084001779556274e+00
    phi[6,1]  R945      6.4347761869430542e-01
    phi[6,1]  R946      -1.1718202829360962e+00
    phi[6,1]  R947      -2.3882064819335938e+00
    phi[6,1]  R948      -1.5724831819534302e+00
    phi[6,1]  R949      -1.1874619722366333e+00
    phi[6,1]  R950      -3.3879095315933228e-01
    phi[6,1]  R951      -1.1181638240814209e+00
    phi[6,1]  R952      -3.6107069253921509e-01
    phi[6,1]  R953      1.5765570402145386e+00
    phi[6,1]  R954      1.6320879459381104e+00
    phi[6,1]  R955      5.0067889690399170e-01
    phi[6,1]  R956      1.8667125701904297e+00
    phi[6,1]  R957      7.7196162939071655e-01
    phi[6,1]  R958      1.7154006958007812e+00
    phi[6,1]  R959      2.2591309547424316e+00
    phi[6,1]  R960      1.6325143575668335e+00
    phi[6,1]  R961      1.3616846799850464e+00
    phi[6,1]  R962      0.684239387512207
    phi[6,1]  R963      -3.2590997219085693e+00
    phi[6,1]  R964      2.1323163509368896e+00
    phi[6,1]  R965      2.9252562522888184e+00
    phi[6,1]  R966      2.4478802680969238e+00
    phi[6,1]  R967      1.5936561822891235e+00
    phi[6,1]  R968      1.2575318813323975e+00
    phi[6,1]  R969      1.1573538780212402e+00
    phi[6,1]  R970      8.5372859239578247e-01
    phi[6,1]  R971      4.9510776996612549e-02
    phi[6,1]  R972      2.6940586566925049e+00
    phi[6,1]  R973      -1.9242057800292969e+00
    phi[6,1]  R974      2.2580431401729584e-01
    phi[6,1]  R975      -2.8023431301116943e+00
    phi[6,1]  R976      -8.5919326543807983e-01
    phi[6,1]  R977      -1.7874330282211304e+00
    phi[6,1]  R978      -1.1359305381774902e+00
    phi[6,1]  R979      -1.4676218032836914e+00
    phi[6,1]  R980      -1.9183627367019653e+00
    phi[6,1]  R981      -3.0257632732391357e+00
    phi[6,1]  R982      -3.5881071090698242e+00
    phi[6,1]  R983      -9.9329793453216553e-01
    phi[6,1]  R984      -5.7472509145736694e-01
    phi[6,1]  R985      2.5801005959510803e-01
    phi[6,1]  R986      1.4462624788284302e+00
    phi[6,1]  R987      -2.8182554244995117e+00
    phi[6,1]  R988      -2.3441600799560547e-01
    phi[6,1]  R989      -1.7814552783966064e+00
    phi[6,1]  R990      -3.4424442052841187e-01
    phi[6,1]  R991      -3.7713727355003357e-01
    phi[6,1]  R992      3.5252150893211365e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R993      -3.0999999046325684e+00
    phi[2,3]  R994      -3.0999999046325684e+00
    phi[2,3]  R995      -2.2400000095367432e+00
    phi[2,3]  R996      -2.2400000095367432e+00
    phi[2,3]  R997      -3.0999999046325684e+00
    phi[2,3]  R998      -3.0999999046325684e+00
    phi[2,3]  R999      -2.5699999332427979e+00
    phi[2,3]  R1000     -2.5699999332427979e+00
    phi[2,3]  R1001     -3.0999999046325684e+00
    phi[2,3]  R1002     -3.0999999046325684e+00
    phi[2,3]  R1003     -2.0899999141693115e+00
    phi[2,3]  R1004     -2.0899999141693115e+00
    phi[2,3]  R1005     -3.0999999046325684e+00
    phi[2,3]  R1006     -3.0999999046325684e+00
    phi[2,3]  R1007     6.6751681268215179e-02
    phi[2,3]  R1008     2.1529221534729004e+00
    phi[2,3]  R1009     1.3592885732650757e+00
    phi[2,3]  R1010     -1.1100682020187378e+00
    phi[2,3]  R1011     -0.377239465713501
    phi[2,3]  R1012     -1.5075632333755493e+00
    phi[2,3]  R1013     -2.8117433190345764e-01
    phi[2,3]  R1014     6.1604022979736328e-01
    phi[2,3]  R1015     1.1352250576019287e+00
    phi[2,3]  R1016     7.6257783174514771e-01
    phi[2,3]  R1017     -7.2680443525314331e-01
    phi[2,3]  R1018     -3.8788786530494690e-01
    phi[2,3]  R1019     -1.6665056943893433e+00
    phi[2,3]  R1020     -2.1840353012084961e+00
    phi[2,3]  R1021     -2.9117641448974609e+00
    phi[2,3]  R1022     -2.1517713069915771e+00
    phi[2,3]  R1023     -1.6230702400207520e+00
    phi[2,3]  R1024     -1.7654137611389160e+00
    phi[2,3]  R1025     -1.85004723072052
    phi[2,3]  R1026     -1.5196650028228760e+00
    phi[2,3]  R1027     -5.3928512334823608e-01
    phi[2,3]  R1028     -2.1782326698303223e+00
    phi[2,3]  R1029     2.6196840405464172e-01
    phi[2,3]  R1030     -2.0811834335327148e+00
    phi[2,3]  R1031     -5.4254758358001709e-01
    phi[2,3]  R1032     -8.7234598398208618e-01
    phi[2,3]  R1033     -2.7398548126220703e+00
    phi[2,3]  R1034     5.0222057104110718e-01
    phi[2,3]  R1035     -3.5139522552490234e+00
    phi[2,3]  R1036     -9.2963731288909912e-01
    phi[2,3]  R1037     -2.2560708224773407e-01
    phi[2,3]  R1038     -4.1494026780128479e-01
    phi[2,3]  R1039     -6.8411421775817871e-01
    phi[2,3]  R1040     -7.1868991851806641e-01
    phi[2,3]  R1041     -3.8774913549423218e-01
    phi[2,3]  R1042     1.1471464633941650e+00
    phi[2,3]  R1043     1.2405275106430054e+00
    phi[2,3]  R1044     5.1728922128677368e-01
    phi[2,3]  R1045     2.4305722117424011e-01
    phi[2,3]  R1046     9.7399193048477173e-01
    phi[2,3]  R1047     -1.0350724309682846e-01
    phi[2,3]  R1048     -5.3493452072143555e-01
    phi[2,3]  R1049     1.4137096703052521e-01
    phi[2,3]  R1050     -8.7300115823745728e-01
    phi[2,3]  R1051     -1.0423594713211060e+00
    phi[2,3]  R1052     -3.8083705306053162e-01
    phi[2,3]  R1053     -8.7494438886642456e-01
    phi[2,3]  R1054     -6.5482038259506226e-01
    phi[2,3]  R1055     -0.0467756912112236
    phi[2,3]  R1056     3.5126274824142456e-01
    phi[2,3]  R1057     -1.6171251237392426e-01
    phi[2,3]  R1058     -1.2060434818267822e+00
    phi[2,3]  R1059     -3.3578922748565674e+00
    phi[2,3]  R1060     9.5429325103759766e-01
    phi[2,3]  R1061     5.7618981599807739e-01
    phi[2,3]  R1062     -2.0623319149017334e+00
    phi[2,3]  R1063     -6.3202768564224243e-01
    phi[2,3]  R1064     7.9295247793197632e-01
    phi[2,3]  R1065     9.6014821529388428e-01
    phi[2,3]  R1066     -4.2407852411270142e-01
    phi[2,3]  R1067     -2.2695252895355225e+00
    phi[2,3]  R1068     -1.8623422384262085e+00
    phi[2,3]  R1069     -3.0852394104003906e+00
    phi[2,3]  R1070     -7.9981499910354614e-01
    phi[2,3]  R1071     -7.8781938552856445e-01
    phi[2,3]  R1072     -2.1223945617675781e+00
    phi[2,3]  R1073     -4.9403226375579834e-01
    phi[2,3]  R1074     -0.777820885181427
    phi[2,3]  R1075     -1.2320812940597534e+00
    phi[2,3]  R1076     -1.3441033363342285e+00
    phi[2,3]  R1077     -7.4051588773727417e-02
    phi[2,3]  R1078     -1.4660637378692627e+00
    phi[2,3]  R1079     -1.8688694238662720e+00
    phi[2,3]  R1080     8.9952695369720459e-01
    phi[2,3]  R1081     -1.0251793861389160e+00
    phi[2,3]  R1082     -2.4361248314380646e-01
    phi[2,3]  R1083     -1.9769359827041626e+00
    phi[2,3]  R1084     -1.3273369073867798e+00
    phi[2,3]  R1085     -3.5716748237609863e-01
    phi[2,3]  R1086     -0.960620641708374
    phi[2,3]  R1087     -2.5011034011840820e+00
    phi[2,3]  R1088     9.2747963964939117e-02
    phi[2,3]  R1089     -1.4066746234893799e+00
    phi[2,3]  R1090     6.9785058498382568e-01
    phi[2,3]  R1091     1.3858495950698853e+00
    phi[2,3]  R1092     -2.1608285903930664e+00
    phi[2,3]  R1093     -4.9587965011596680e-02
    phi[2,3]  R1094     -1.7300007343292236e+00
    phi[2,3]  R1095     -1.4087241888046265e+00
    phi[2,3]  R1096     -2.5405454635620117e+00
    phi[2,3]  R1097     -1.0632543563842773e+00
    phi[2,3]  R1098     -1.2075016647577286e-01
    phi[2,3]  R1099     -4.1495648026466370e-01
    phi[2,3]  R1100     -3.4901756048202515e-01
    phi[2,3]  R1101     -1.2548009157180786e+00
    phi[2,3]  R1102     -2.4236304759979248e+00
    phi[2,3]  R1103     -1.0867643356323242e+00
    phi[2,3]  R1104     -2.4787235260009766e+00
    phi[2,3]  R1105     -2.0590219497680664e+00
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1106     -3.0999999046325684e+00
    phi[3,2]  R1107     -3.0999999046325684e+00
    phi[3,2]  R1108     -2.2400000095367432e+00
    phi[3,2]  R1109     -2.2400000095367432e+00
    phi[3,2]  R1110     -3.0999999046325684e+00
    phi[3,2]  R1111     -3.0999999046325684e+00
    phi[3,2]  R1112     -2.5699999332427979e+00
    phi[3,2]  R1113     -2.5699999332427979e+00
    phi[3,2]  R1114     -3.0999999046325684e+00
    phi[3,2]  R1115     -3.0999999046325684e+00
    phi[3,2]  R1116     -2.0899999141693115e+00
    phi[3,2]  R1117     -2.0899999141693115e+00
    phi[3,2]  R1118     -3.0999999046325684e+00
    phi[3,2]  R1119     -3.0999999046325684e+00
    phi[3,2]  R1120     -2.2560708224773407e-01
    phi[3,2]  R1121     -4.1494026780128479e-01
    phi[3,2]  R1122     -6.8411421775817871e-01
    phi[3,2]  R1123     -7.1868991851806641e-01
    phi[3,2]  R1124     -3.8774913549423218e-01
    phi[3,2]  R1125     1.1471464633941650e+00
    phi[3,2]  R1126     1.2405275106430054e+00
    phi[3,2]  R1127     5.1728922128677368e-01
    phi[3,2]  R1128     2.4305722117424011e-01
    phi[3,2]  R1129     9.7399193048477173e-01
    phi[3,2]  R1130     -1.0350724309682846e-01
    phi[3,2]  R1131     -5.3493452072143555e-01
    phi[3,2]  R1132     1.4137096703052521e-01
    phi[3,2]  R1133     -8.7300115823745728e-01
    phi[3,2]  R1134     -1.0423594713211060e+00
    phi[3,2]  R1135     -3.8083705306053162e-01
    phi[3,2]  R1136     -8.7494438886642456e-01
    phi[3,2]  R1137     -6.5482038259506226e-01
    phi[3,2]  R1138     -0.0467756912112236
    phi[3,2]  R1139     3.5126274824142456e-01
    phi[3,2]  R1140     -1.6171251237392426e-01
    phi[3,2]  R1141     -1.2060434818267822e+00
    phi[3,2]  R1142     -3.3578922748565674e+00
    phi[3,2]  R1143     9.5429325103759766e-01
    phi[3,2]  R1144     5.7618981599807739e-01
    phi[3,2]  R1145     -2.0623319149017334e+00
    phi[3,2]  R1146     -6.3202768564224243e-01
    phi[3,2]  R1147     7.9295247793197632e-01
    phi[3,2]  R1148     9.6014821529388428e-01
    phi[3,2]  R1149     -4.2407852411270142e-01
    phi[3,2]  R1150     -2.2695252895355225e+00
    phi[3,2]  R1151     -1.8623422384262085e+00
    phi[3,2]  R1152     -3.0852394104003906e+00
    phi[3,2]  R1153     -7.9981499910354614e-01
    phi[3,2]  R1154     -7.8781938552856445e-01
    phi[3,2]  R1155     -2.1223945617675781e+00
    phi[3,2]  R1156     -4.9403226375579834e-01
    phi[3,2]  R1157     -0.777820885181427
    phi[3,2]  R1158     -1.2320812940597534e+00
    phi[3,2]  R1159     -1.3441033363342285e+00
    phi[3,2]  R1160     -7.4051588773727417e-02
    phi[3,2]  R1161     -1.4660637378692627e+00
    phi[3,2]  R1162     -1.8688694238662720e+00
    phi[3,2]  R1163     8.9952695369720459e-01
    phi[3,2]  R1164     -1.0251793861389160e+00
    phi[3,2]  R1165     -2.4361248314380646e-01
    phi[3,2]  R1166     -1.9769359827041626e+00
    phi[3,2]  R1167     -1.3273369073867798e+00
    phi[3,2]  R1168     -3.5716748237609863e-01
    phi[3,2]  R1169     -0.960620641708374
    phi[3,2]  R1170     -2.5011034011840820e+00
    phi[3,2]  R1171     9.2747963964939117e-02
    phi[3,2]  R1172     -1.4066746234893799e+00
    phi[3,2]  R1173     6.9785058498382568e-01
    phi[3,2]  R1174     1.3858495950698853e+00
    phi[3,2]  R1175     -2.1608285903930664e+00
    phi[3,2]  R1176     -4.9587965011596680e-02
    phi[3,2]  R1177     -1.7300007343292236e+00
    phi[3,2]  R1178     -1.4087241888046265e+00
    phi[3,2]  R1179     -2.5405454635620117e+00
    phi[3,2]  R1180     -1.0632543563842773e+00
    phi[3,2]  R1181     -1.2075016647577286e-01
    phi[3,2]  R1182     -4.1495648026466370e-01
    phi[3,2]  R1183     -3.4901756048202515e-01
    phi[3,2]  R1184     -1.2548009157180786e+00
    phi[3,2]  R1185     -2.4236304759979248e+00
    phi[3,2]  R1186     -1.0867643356323242e+00
    phi[3,2]  R1187     -2.4787235260009766e+00
    phi[3,2]  R1188     -2.0590219497680664e+00
    phi[3,2]  R1189     6.6751681268215179e-02
    phi[3,2]  R1190     2.1529221534729004e+00
    phi[3,2]  R1191     1.3592885732650757e+00
    phi[3,2]  R1192     -1.1100682020187378e+00
    phi[3,2]  R1193     -0.377239465713501
    phi[3,2]  R1194     -1.5075632333755493e+00
    phi[3,2]  R1195     -2.8117433190345764e-01
    phi[3,2]  R1196     6.1604022979736328e-01
    phi[3,2]  R1197     1.1352250576019287e+00
    phi[3,2]  R1198     7.6257783174514771e-01
    phi[3,2]  R1199     -7.2680443525314331e-01
    phi[3,2]  R1200     -3.8788786530494690e-01
    phi[3,2]  R1201     -1.6665056943893433e+00
    phi[3,2]  R1202     -2.1840353012084961e+00
    phi[3,2]  R1203     -2.9117641448974609e+00
    phi[3,2]  R1204     -2.1517713069915771e+00
    phi[3,2]  R1205     -1.6230702400207520e+00
    phi[3,2]  R1206     -1.7654137611389160e+00
    phi[3,2]  R1207     -1.85004723072052
    phi[3,2]  R1208     -1.5196650028228760e+00
    phi[3,2]  R1209     -5.3928512334823608e-01
    phi[3,2]  R1210     -2.1782326698303223e+00
    phi[3,2]  R1211     2.6196840405464172e-01
    phi[3,2]  R1212     -2.0811834335327148e+00
    phi[3,2]  R1213     -5.4254758358001709e-01
    phi[3,2]  R1214     -8.7234598398208618e-01
    phi[3,2]  R1215     -2.7398548126220703e+00
    phi[3,2]  R1216     5.0222057104110718e-01
    phi[3,2]  R1217     -3.5139522552490234e+00
    phi[3,2]  R1218     -9.2963731288909912e-01
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1219     -3.0999999046325684e+00
    phi[2,6]  R1220     -3.0999999046325684e+00
    phi[2,6]  R1221     -2.2400000095367432e+00
    phi[2,6]  R1222     -2.2400000095367432e+00
    phi[2,6]  R1223     -3.0999999046325684e+00
    phi[2,6]  R1224     -3.0999999046325684e+00
    phi[2,6]  R1225     -2.5699999332427979e+00
    phi[2,6]  R1226     -2.5699999332427979e+00
    phi[2,6]  R1227     -3.0999999046325684e+00
    phi[2,6]  R1228     -3.0999999046325684e+00
    phi[2,6]  R1229     -2.0899999141693115e+00
    phi[2,6]  R1230     -2.0899999141693115e+00
    phi[2,6]  R1231     -3.0999999046325684e+00
    phi[2,6]  R1232     -3.0999999046325684e+00
    phi[2,6]  R1233     6.6751681268215179e-02
    phi[2,6]  R1234     2.1529221534729004e+00
    phi[2,6]  R1235     1.3592885732650757e+00
    phi[2,6]  R1236     -1.1100682020187378e+00
    phi[2,6]  R1237     -0.377239465713501
    phi[2,6]  R1238     -1.5075632333755493e+00
    phi[2,6]  R1239     -2.8117433190345764e-01
    phi[2,6]  R1240     6.1604022979736328e-01
    phi[2,6]  R1241     1.1352250576019287e+00
    phi[2,6]  R1242     7.6257783174514771e-01
    phi[2,6]  R1243     -7.2680443525314331e-01
    phi[2,6]  R1244     -3.8788786530494690e-01
    phi[2,6]  R1245     -1.6665056943893433e+00
    phi[2,6]  R1246     -2.1840353012084961e+00
    phi[2,6]  R1247     -2.9117641448974609e+00
    phi[2,6]  R1248     -2.1517713069915771e+00
    phi[2,6]  R1249     -1.6230702400207520e+00
    phi[2,6]  R1250     -1.7654137611389160e+00
    phi[2,6]  R1251     -1.85004723072052
    phi[2,6]  R1252     -1.5196650028228760e+00
    phi[2,6]  R1253     -5.3928512334823608e-01
    phi[2,6]  R1254     -2.1782326698303223e+00
    phi[2,6]  R1255     2.6196840405464172e-01
    phi[2,6]  R1256     -2.0811834335327148e+00
    phi[2,6]  R1257     -5.4254758358001709e-01
    phi[2,6]  R1258     -8.7234598398208618e-01
    phi[2,6]  R1259     -2.7398548126220703e+00
    phi[2,6]  R1260     5.0222057104110718e-01
    phi[2,6]  R1261     -3.5139522552490234e+00
    phi[2,6]  R1262     -9.2963731288909912e-01
    phi[2,6]  R1263     2.6076083183288574e+00
    phi[2,6]  R1264     6.8630856275558472e-01
    phi[2,6]  R1265     2.1156513690948486e+00
    phi[2,6]  R1266     1.4403879642486572e+00
    phi[2,6]  R1267     1.9452199935913086e+00
    phi[2,6]  R1268     1.8707634508609772e-01
    phi[2,6]  R1269     9.6376115083694458e-01
    phi[2,6]  R1270     1.2372753620147705e+00
    phi[2,6]  R1271     1.5879375934600830e+00
    phi[2,6]  R1272     1.2061446905136108e+00
    phi[2,6]  R1273     -4.9308747053146362e-01
    phi[2,6]  R1274     -3.1541643142700195e+00
    phi[2,6]  R1275     -1.2181717157363892e+00
    phi[2,6]  R1276     -6.5937983989715576e-01
    phi[2,6]  R1277     -2.4126670360565186e+00
    phi[2,6]  R1278     7.0902451872825623e-02
    phi[2,6]  R1279     -4.1423029899597168e+00
    phi[2,6]  R1280     -3.1070941686630249e-01
    phi[2,6]  R1281     -1.9834290742874146e+00
    phi[2,6]  R1282     -1.1414165496826172e+00
    phi[2,6]  R1283     -1.6809436082839966e+00
    phi[2,6]  R1284     6.7658799886703491e-01
    phi[2,6]  R1285     3.9080739021301270e-02
    phi[2,6]  R1286     -3.2035019397735596e+00
    phi[2,6]  R1287     -2.5811049938201904e+00
    phi[2,6]  R1288     -1.6233938932418823e+00
    phi[2,6]  R1289     -1.0524587631225586e+00
    phi[2,6]  R1290     -1.4967588186264038e+00
    phi[2,6]  R1291     -2.1295061111450195e+00
    phi[2,6]  R1292     4.0459814667701721e-01
    phi[2,6]  R1293     -1.4126646518707275e-01
    phi[2,6]  R1294     -1.4084001779556274e+00
    phi[2,6]  R1295     6.4347761869430542e-01
    phi[2,6]  R1296     -1.1718202829360962e+00
    phi[2,6]  R1297     -2.3882064819335938e+00
    phi[2,6]  R1298     -1.5724831819534302e+00
    phi[2,6]  R1299     -1.1874619722366333e+00
    phi[2,6]  R1300     -3.3879095315933228e-01
    phi[2,6]  R1301     -1.1181638240814209e+00
    phi[2,6]  R1302     -3.6107069253921509e-01
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1303     -3.0999999046325684e+00
    phi[6,2]  R1304     -3.0999999046325684e+00
    phi[6,2]  R1305     -2.2400000095367432e+00
    phi[6,2]  R1306     -2.2400000095367432e+00
    phi[6,2]  R1307     -3.0999999046325684e+00
    phi[6,2]  R1308     -3.0999999046325684e+00
    phi[6,2]  R1309     -2.5699999332427979e+00
    phi[6,2]  R1310     -2.5699999332427979e+00
    phi[6,2]  R1311     -3.0999999046325684e+00
    phi[6,2]  R1312     -3.0999999046325684e+00
    phi[6,2]  R1313     -2.0899999141693115e+00
    phi[6,2]  R1314     -2.0899999141693115e+00
    phi[6,2]  R1315     -3.0999999046325684e+00
    phi[6,2]  R1316     -3.0999999046325684e+00
    phi[6,2]  R1317     2.6076083183288574e+00
    phi[6,2]  R1318     6.8630856275558472e-01
    phi[6,2]  R1319     2.1156513690948486e+00
    phi[6,2]  R1320     1.4403879642486572e+00
    phi[6,2]  R1321     1.9452199935913086e+00
    phi[6,2]  R1322     1.8707634508609772e-01
    phi[6,2]  R1323     9.6376115083694458e-01
    phi[6,2]  R1324     1.2372753620147705e+00
    phi[6,2]  R1325     1.5879375934600830e+00
    phi[6,2]  R1326     1.2061446905136108e+00
    phi[6,2]  R1327     -4.9308747053146362e-01
    phi[6,2]  R1328     -3.1541643142700195e+00
    phi[6,2]  R1329     -1.2181717157363892e+00
    phi[6,2]  R1330     -6.5937983989715576e-01
    phi[6,2]  R1331     -2.4126670360565186e+00
    phi[6,2]  R1332     7.0902451872825623e-02
    phi[6,2]  R1333     -4.1423029899597168e+00
    phi[6,2]  R1334     -3.1070941686630249e-01
    phi[6,2]  R1335     -1.9834290742874146e+00
    phi[6,2]  R1336     -1.1414165496826172e+00
    phi[6,2]  R1337     -1.6809436082839966e+00
    phi[6,2]  R1338     6.7658799886703491e-01
    phi[6,2]  R1339     3.9080739021301270e-02
    phi[6,2]  R1340     -3.2035019397735596e+00
    phi[6,2]  R1341     -2.5811049938201904e+00
    phi[6,2]  R1342     -1.6233938932418823e+00
    phi[6,2]  R1343     -1.0524587631225586e+00
    phi[6,2]  R1344     -1.4967588186264038e+00
    phi[6,2]  R1345     -2.1295061111450195e+00
    phi[6,2]  R1346     4.0459814667701721e-01
    phi[6,2]  R1347     -1.4126646518707275e-01
    phi[6,2]  R1348     -1.4084001779556274e+00
    phi[6,2]  R1349     6.4347761869430542e-01
    phi[6,2]  R1350     -1.1718202829360962e+00
    phi[6,2]  R1351     -2.3882064819335938e+00
    phi[6,2]  R1352     -1.5724831819534302e+00
    phi[6,2]  R1353     -1.1874619722366333e+00
    phi[6,2]  R1354     -3.3879095315933228e-01
    phi[6,2]  R1355     -1.1181638240814209e+00
    phi[6,2]  R1356     -3.6107069253921509e-01
    phi[6,2]  R1357     6.6751681268215179e-02
    phi[6,2]  R1358     2.1529221534729004e+00
    phi[6,2]  R1359     1.3592885732650757e+00
    phi[6,2]  R1360     -1.1100682020187378e+00
    phi[6,2]  R1361     -0.377239465713501
    phi[6,2]  R1362     -1.5075632333755493e+00
    phi[6,2]  R1363     -2.8117433190345764e-01
    phi[6,2]  R1364     6.1604022979736328e-01
    phi[6,2]  R1365     1.1352250576019287e+00
    phi[6,2]  R1366     7.6257783174514771e-01
    phi[6,2]  R1367     -7.2680443525314331e-01
    phi[6,2]  R1368     -3.8788786530494690e-01
    phi[6,2]  R1369     -1.6665056943893433e+00
    phi[6,2]  R1370     -2.1840353012084961e+00
    phi[6,2]  R1371     -2.9117641448974609e+00
    phi[6,2]  R1372     -2.1517713069915771e+00
    phi[6,2]  R1373     -1.6230702400207520e+00
    phi[6,2]  R1374     -1.7654137611389160e+00
    phi[6,2]  R1375     -1.85004723072052
    phi[6,2]  R1376     -1.5196650028228760e+00
    phi[6,2]  R1377     -5.3928512334823608e-01
    phi[6,2]  R1378     -2.1782326698303223e+00
    phi[6,2]  R1379     2.6196840405464172e-01
    phi[6,2]  R1380     -2.0811834335327148e+00
    phi[6,2]  R1381     -5.4254758358001709e-01
    phi[6,2]  R1382     -8.7234598398208618e-01
    phi[6,2]  R1383     -2.7398548126220703e+00
    phi[6,2]  R1384     5.0222057104110718e-01
    phi[6,2]  R1385     -3.5139522552490234e+00
    phi[6,2]  R1386     -9.2963731288909912e-01
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R63       -1
    phi[2,7]  R1387     -3.0999999046325684e+00
    phi[2,7]  R1388     -3.0999999046325684e+00
    phi[2,7]  R1389     -2.2400000095367432e+00
    phi[2,7]  R1390     -2.2400000095367432e+00
    phi[2,7]  R1391     -3.0999999046325684e+00
    phi[2,7]  R1392     -3.0999999046325684e+00
    phi[2,7]  R1393     -2.5699999332427979e+00
    phi[2,7]  R1394     -2.5699999332427979e+00
    phi[2,7]  R1395     -3.0999999046325684e+00
    phi[2,7]  R1396     -3.0999999046325684e+00
    phi[2,7]  R1397     -2.0899999141693115e+00
    phi[2,7]  R1398     -2.0899999141693115e+00
    phi[2,7]  R1399     -3.0999999046325684e+00
    phi[2,7]  R1400     -3.0999999046325684e+00
    phi[2,7]  R1401     6.6751681268215179e-02
    phi[2,7]  R1402     2.1529221534729004e+00
    phi[2,7]  R1403     1.3592885732650757e+00
    phi[2,7]  R1404     -1.1100682020187378e+00
    phi[2,7]  R1405     -0.377239465713501
    phi[2,7]  R1406     -1.5075632333755493e+00
    phi[2,7]  R1407     -2.8117433190345764e-01
    phi[2,7]  R1408     6.1604022979736328e-01
    phi[2,7]  R1409     1.1352250576019287e+00
    phi[2,7]  R1410     7.6257783174514771e-01
    phi[2,7]  R1411     -7.2680443525314331e-01
    phi[2,7]  R1412     -3.8788786530494690e-01
    phi[2,7]  R1413     -1.6665056943893433e+00
    phi[2,7]  R1414     -2.1840353012084961e+00
    phi[2,7]  R1415     -2.9117641448974609e+00
    phi[2,7]  R1416     -2.1517713069915771e+00
    phi[2,7]  R1417     -1.6230702400207520e+00
    phi[2,7]  R1418     -1.7654137611389160e+00
    phi[2,7]  R1419     -1.85004723072052
    phi[2,7]  R1420     -1.5196650028228760e+00
    phi[2,7]  R1421     -5.3928512334823608e-01
    phi[2,7]  R1422     -2.1782326698303223e+00
    phi[2,7]  R1423     2.6196840405464172e-01
    phi[2,7]  R1424     -2.0811834335327148e+00
    phi[2,7]  R1425     -5.4254758358001709e-01
    phi[2,7]  R1426     -8.7234598398208618e-01
    phi[2,7]  R1427     -2.7398548126220703e+00
    phi[2,7]  R1428     5.0222057104110718e-01
    phi[2,7]  R1429     -3.5139522552490234e+00
    phi[2,7]  R1430     -9.2963731288909912e-01
    phi[2,7]  R1431     9.9413096904754639e-02
    phi[2,7]  R1432     -1.7032012343406677e-01
    phi[2,7]  R1433     1.9676467403769493e-02
    phi[2,7]  R1434     2.3302994668483734e-01
    phi[2,7]  R1435     -2.2324560582637787e-01
    phi[2,7]  R1436     4.8189321160316467e-01
    phi[2,7]  R1437     -3.7492558360099792e-01
    phi[2,7]  R1438     8.4481149911880493e-01
    phi[2,7]  R1439     0.840761661529541
    phi[2,7]  R1440     -1.2594033479690552e+00
    phi[2,7]  R1441     5.2686792612075806e-01
    phi[2,7]  R1442     1.1709102988243103e-01
    phi[2,7]  R1443     2.5978749617934227e-02
    phi[2,7]  R1444     -2.3088788986206055e-01
    phi[2,7]  R1445     -5.9526139497756958e-01
    phi[2,7]  R1446     6.4458596706390381e-01
    phi[2,7]  R1447     -5.9742921590805054e-01
    phi[2,7]  R1448     0.427736759185791
    phi[2,7]  R1449     -1.2762162685394287e+00
    phi[2,7]  R1450     -1.0009621381759644e+00
    phi[2,7]  R1451     -1.6633864641189575e+00
    phi[2,7]  R1452     -1.5523450374603271e+00
    phi[2,7]  R1453     -7.3273056745529175e-01
    phi[2,7]  R1454     -4.1974949836730957e-01
    phi[2,7]  R1455     -7.2979968786239624e-01
    phi[2,7]  R1456     -1.5292568206787109e+00
    phi[2,7]  R1457     -1.7716504335403442e+00
    phi[2,7]  R1458     -1.5031944513320923e+00
    phi[2,7]  R1459     -7.7915364503860474e-01
    phi[2,7]  R1460     -1.1290464401245117e+00
    phi[2,7]  R1461     -2.6159355640411377e+00
    phi[2,7]  R1462     -5.9536463022232056e-01
    phi[2,7]  R1463     -1.4354993104934692e+00
    phi[2,7]  R1464     -2.5630605220794678e+00
    phi[2,7]  R1465     5.4828107357025146e-01
    phi[2,7]  R1466     -4.1488805413246155e-01
    phi[2,7]  R1467     -8.3401310443878174e-01
    phi[2,7]  R1468     -5.0063955783843994e-01
    phi[2,7]  R1469     -3.5572871565818787e-01
    phi[2,7]  R1470     1.1481480598449707e+00
    phi[7,2]  R18       -1
    phi[7,2]  R63       1
    phi[7,2]  R64       1
    phi[7,2]  R1471     -3.0999999046325684e+00
    phi[7,2]  R1472     -3.0999999046325684e+00
    phi[7,2]  R1473     -2.2400000095367432e+00
    phi[7,2]  R1474     -2.2400000095367432e+00
    phi[7,2]  R1475     -3.0999999046325684e+00
    phi[7,2]  R1476     -3.0999999046325684e+00
    phi[7,2]  R1477     -2.5699999332427979e+00
    phi[7,2]  R1478     -2.5699999332427979e+00
    phi[7,2]  R1479     -3.0999999046325684e+00
    phi[7,2]  R1480     -3.0999999046325684e+00
    phi[7,2]  R1481     -2.0899999141693115e+00
    phi[7,2]  R1482     -2.0899999141693115e+00
    phi[7,2]  R1483     -3.0999999046325684e+00
    phi[7,2]  R1484     -3.0999999046325684e+00
    phi[7,2]  R1485     9.9413096904754639e-02
    phi[7,2]  R1486     -1.7032012343406677e-01
    phi[7,2]  R1487     1.9676467403769493e-02
    phi[7,2]  R1488     2.3302994668483734e-01
    phi[7,2]  R1489     -2.2324560582637787e-01
    phi[7,2]  R1490     4.8189321160316467e-01
    phi[7,2]  R1491     -3.7492558360099792e-01
    phi[7,2]  R1492     8.4481149911880493e-01
    phi[7,2]  R1493     0.840761661529541
    phi[7,2]  R1494     -1.2594033479690552e+00
    phi[7,2]  R1495     5.2686792612075806e-01
    phi[7,2]  R1496     1.1709102988243103e-01
    phi[7,2]  R1497     2.5978749617934227e-02
    phi[7,2]  R1498     -2.3088788986206055e-01
    phi[7,2]  R1499     -5.9526139497756958e-01
    phi[7,2]  R1500     6.4458596706390381e-01
    phi[7,2]  R1501     -5.9742921590805054e-01
    phi[7,2]  R1502     0.427736759185791
    phi[7,2]  R1503     -1.2762162685394287e+00
    phi[7,2]  R1504     -1.0009621381759644e+00
    phi[7,2]  R1505     -1.6633864641189575e+00
    phi[7,2]  R1506     -1.5523450374603271e+00
    phi[7,2]  R1507     -7.3273056745529175e-01
    phi[7,2]  R1508     -4.1974949836730957e-01
    phi[7,2]  R1509     -7.2979968786239624e-01
    phi[7,2]  R1510     -1.5292568206787109e+00
    phi[7,2]  R1511     -1.7716504335403442e+00
    phi[7,2]  R1512     -1.5031944513320923e+00
    phi[7,2]  R1513     -7.7915364503860474e-01
    phi[7,2]  R1514     -1.1290464401245117e+00
    phi[7,2]  R1515     -2.6159355640411377e+00
    phi[7,2]  R1516     -5.9536463022232056e-01
    phi[7,2]  R1517     -1.4354993104934692e+00
    phi[7,2]  R1518     -2.5630605220794678e+00
    phi[7,2]  R1519     5.4828107357025146e-01
    phi[7,2]  R1520     -4.1488805413246155e-01
    phi[7,2]  R1521     -8.3401310443878174e-01
    phi[7,2]  R1522     -5.0063955783843994e-01
    phi[7,2]  R1523     -3.5572871565818787e-01
    phi[7,2]  R1524     1.1481480598449707e+00
    phi[7,2]  R1525     6.6751681268215179e-02
    phi[7,2]  R1526     2.1529221534729004e+00
    phi[7,2]  R1527     1.3592885732650757e+00
    phi[7,2]  R1528     -1.1100682020187378e+00
    phi[7,2]  R1529     -0.377239465713501
    phi[7,2]  R1530     -1.5075632333755493e+00
    phi[7,2]  R1531     -2.8117433190345764e-01
    phi[7,2]  R1532     6.1604022979736328e-01
    phi[7,2]  R1533     1.1352250576019287e+00
    phi[7,2]  R1534     7.6257783174514771e-01
    phi[7,2]  R1535     -7.2680443525314331e-01
    phi[7,2]  R1536     -3.8788786530494690e-01
    phi[7,2]  R1537     -1.6665056943893433e+00
    phi[7,2]  R1538     -2.1840353012084961e+00
    phi[7,2]  R1539     -2.9117641448974609e+00
    phi[7,2]  R1540     -2.1517713069915771e+00
    phi[7,2]  R1541     -1.6230702400207520e+00
    phi[7,2]  R1542     -1.7654137611389160e+00
    phi[7,2]  R1543     -1.85004723072052
    phi[7,2]  R1544     -1.5196650028228760e+00
    phi[7,2]  R1545     -5.3928512334823608e-01
    phi[7,2]  R1546     -2.1782326698303223e+00
    phi[7,2]  R1547     2.6196840405464172e-01
    phi[7,2]  R1548     -2.0811834335327148e+00
    phi[7,2]  R1549     -5.4254758358001709e-01
    phi[7,2]  R1550     -8.7234598398208618e-01
    phi[7,2]  R1551     -2.7398548126220703e+00
    phi[7,2]  R1552     5.0222057104110718e-01
    phi[7,2]  R1553     -3.5139522552490234e+00
    phi[7,2]  R1554     -9.2963731288909912e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1555     -3.0999999046325684e+00
    phi[3,4]  R1556     -3.0999999046325684e+00
    phi[3,4]  R1557     -2.2400000095367432e+00
    phi[3,4]  R1558     -2.2400000095367432e+00
    phi[3,4]  R1559     -3.0999999046325684e+00
    phi[3,4]  R1560     -3.0999999046325684e+00
    phi[3,4]  R1561     -2.5699999332427979e+00
    phi[3,4]  R1562     -2.5699999332427979e+00
    phi[3,4]  R1563     -3.0999999046325684e+00
    phi[3,4]  R1564     -3.0999999046325684e+00
    phi[3,4]  R1565     -2.0899999141693115e+00
    phi[3,4]  R1566     -2.0899999141693115e+00
    phi[3,4]  R1567     -3.0999999046325684e+00
    phi[3,4]  R1568     -3.0999999046325684e+00
    phi[3,4]  R1569     -2.2560708224773407e-01
    phi[3,4]  R1570     -4.1494026780128479e-01
    phi[3,4]  R1571     -6.8411421775817871e-01
    phi[3,4]  R1572     -7.1868991851806641e-01
    phi[3,4]  R1573     -3.8774913549423218e-01
    phi[3,4]  R1574     1.1471464633941650e+00
    phi[3,4]  R1575     1.2405275106430054e+00
    phi[3,4]  R1576     5.1728922128677368e-01
    phi[3,4]  R1577     2.4305722117424011e-01
    phi[3,4]  R1578     9.7399193048477173e-01
    phi[3,4]  R1579     -1.0350724309682846e-01
    phi[3,4]  R1580     -5.3493452072143555e-01
    phi[3,4]  R1581     1.4137096703052521e-01
    phi[3,4]  R1582     -8.7300115823745728e-01
    phi[3,4]  R1583     -1.0423594713211060e+00
    phi[3,4]  R1584     -3.8083705306053162e-01
    phi[3,4]  R1585     -8.7494438886642456e-01
    phi[3,4]  R1586     -6.5482038259506226e-01
    phi[3,4]  R1587     -0.0467756912112236
    phi[3,4]  R1588     3.5126274824142456e-01
    phi[3,4]  R1589     -1.6171251237392426e-01
    phi[3,4]  R1590     -1.2060434818267822e+00
    phi[3,4]  R1591     -3.3578922748565674e+00
    phi[3,4]  R1592     9.5429325103759766e-01
    phi[3,4]  R1593     5.7618981599807739e-01
    phi[3,4]  R1594     -2.0623319149017334e+00
    phi[3,4]  R1595     -6.3202768564224243e-01
    phi[3,4]  R1596     7.9295247793197632e-01
    phi[3,4]  R1597     9.6014821529388428e-01
    phi[3,4]  R1598     -4.2407852411270142e-01
    phi[3,4]  R1599     -2.2695252895355225e+00
    phi[3,4]  R1600     -1.8623422384262085e+00
    phi[3,4]  R1601     -3.0852394104003906e+00
    phi[3,4]  R1602     -7.9981499910354614e-01
    phi[3,4]  R1603     -7.8781938552856445e-01
    phi[3,4]  R1604     -2.1223945617675781e+00
    phi[3,4]  R1605     -4.9403226375579834e-01
    phi[3,4]  R1606     -0.777820885181427
    phi[3,4]  R1607     -1.2320812940597534e+00
    phi[3,4]  R1608     -1.3441033363342285e+00
    phi[3,4]  R1609     -7.4051588773727417e-02
    phi[3,4]  R1610     -1.4660637378692627e+00
    phi[3,4]  R1611     -1.8688694238662720e+00
    phi[3,4]  R1612     8.9952695369720459e-01
    phi[3,4]  R1613     -1.0251793861389160e+00
    phi[3,4]  R1614     -2.4361248314380646e-01
    phi[3,4]  R1615     -1.9769359827041626e+00
    phi[3,4]  R1616     -1.3273369073867798e+00
    phi[3,4]  R1617     -3.5716748237609863e-01
    phi[3,4]  R1618     -0.960620641708374
    phi[3,4]  R1619     -2.5011034011840820e+00
    phi[3,4]  R1620     9.2747963964939117e-02
    phi[3,4]  R1621     -1.4066746234893799e+00
    phi[3,4]  R1622     6.9785058498382568e-01
    phi[3,4]  R1623     1.3858495950698853e+00
    phi[3,4]  R1624     -2.1608285903930664e+00
    phi[3,4]  R1625     -4.9587965011596680e-02
    phi[3,4]  R1626     -1.7300007343292236e+00
    phi[3,4]  R1627     -1.4087241888046265e+00
    phi[3,4]  R1628     -2.5405454635620117e+00
    phi[3,4]  R1629     -1.0632543563842773e+00
    phi[3,4]  R1630     -1.2075016647577286e-01
    phi[3,4]  R1631     -4.1495648026466370e-01
    phi[3,4]  R1632     -3.4901756048202515e-01
    phi[3,4]  R1633     -1.2548009157180786e+00
    phi[3,4]  R1634     -2.4236304759979248e+00
    phi[3,4]  R1635     -1.0867643356323242e+00
    phi[3,4]  R1636     -2.4787235260009766e+00
    phi[3,4]  R1637     -2.0590219497680664e+00
    phi[3,4]  R1638     2.4655783176422119e+00
    phi[3,4]  R1639     1.8349212408065796e+00
    phi[3,4]  R1640     2.7130825519561768e+00
    phi[3,4]  R1641     4.4555360078811646e-01
    phi[3,4]  R1642     2.2862565517425537e+00
    phi[3,4]  R1643     1.7113311290740967e+00
    phi[3,4]  R1644     -1.5530730783939362e-01
    phi[3,4]  R1645     -1.1701208353042603e+00
    phi[3,4]  R1646     1.4742127656936646e+00
    phi[3,4]  R1647     1.0188047885894775e+00
    phi[3,4]  R1648     -2.4243121147155762e+00
    phi[3,4]  R1649     -2.2649476528167725e+00
    phi[3,4]  R1650     -2.6346583366394043e+00
    phi[3,4]  R1651     -2.0034878253936768e+00
    phi[3,4]  R1652     -1.2315746545791626e+00
    phi[3,4]  R1653     -1.6972101926803589e+00
    phi[3,4]  R1654     -0.830448567867279
    phi[3,4]  R1655     -2.3374280929565430e+00
    phi[3,4]  R1656     -3.5891635417938232e+00
    phi[3,4]  R1657     -2.4512956142425537e+00
    phi[3,4]  R1658     -8.6009031534194946e-01
    phi[3,4]  R1659     -2.2004370689392090e+00
    phi[3,4]  R1660     -2.3644518852233887e+00
    phi[3,4]  R1661     -2.5680489540100098e+00
    phi[3,4]  R1662     -3.1614201068878174e+00
    phi[3,4]  R1663     -1.4101479053497314e+00
    phi[3,4]  R1664     -2.0169723033905029e+00
    phi[3,4]  R1665     -1.5530717372894287e+00
    phi[3,4]  R1666     -1.9962453842163086e+00
    phi[3,4]  R1667     -2.30719256401062
    phi[3,4]  R1668     -1.4108206033706665e+00
    phi[3,4]  R1669     -1.0566641092300415e+00
    phi[3,4]  R1670     -1.2490376234054565e+00
    phi[3,4]  R1671     -2.9005851745605469e+00
    phi[3,4]  R1672     -2.6873855590820312e+00
    phi[3,4]  R1673     -3.2630155086517334e+00
    phi[3,4]  R1674     -1.8153613805770874e+00
    phi[3,4]  R1675     -3.0504553318023682e+00
    phi[3,4]  R1676     -2.2559545040130615e+00
    phi[3,4]  R1677     -3.7274265289306641e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1678     -3.0999999046325684e+00
    phi[4,3]  R1679     -3.0999999046325684e+00
    phi[4,3]  R1680     -2.2400000095367432e+00
    phi[4,3]  R1681     -2.2400000095367432e+00
    phi[4,3]  R1682     -3.0999999046325684e+00
    phi[4,3]  R1683     -3.0999999046325684e+00
    phi[4,3]  R1684     -2.5699999332427979e+00
    phi[4,3]  R1685     -2.5699999332427979e+00
    phi[4,3]  R1686     -3.0999999046325684e+00
    phi[4,3]  R1687     -3.0999999046325684e+00
    phi[4,3]  R1688     -2.0899999141693115e+00
    phi[4,3]  R1689     -2.0899999141693115e+00
    phi[4,3]  R1690     -3.0999999046325684e+00
    phi[4,3]  R1691     -3.0999999046325684e+00
    phi[4,3]  R1692     2.4655783176422119e+00
    phi[4,3]  R1693     1.8349212408065796e+00
    phi[4,3]  R1694     2.7130825519561768e+00
    phi[4,3]  R1695     4.4555360078811646e-01
    phi[4,3]  R1696     2.2862565517425537e+00
    phi[4,3]  R1697     1.7113311290740967e+00
    phi[4,3]  R1698     -1.5530730783939362e-01
    phi[4,3]  R1699     -1.1701208353042603e+00
    phi[4,3]  R1700     1.4742127656936646e+00
    phi[4,3]  R1701     1.0188047885894775e+00
    phi[4,3]  R1702     -2.4243121147155762e+00
    phi[4,3]  R1703     -2.2649476528167725e+00
    phi[4,3]  R1704     -2.6346583366394043e+00
    phi[4,3]  R1705     -2.0034878253936768e+00
    phi[4,3]  R1706     -1.2315746545791626e+00
    phi[4,3]  R1707     -1.6972101926803589e+00
    phi[4,3]  R1708     -0.830448567867279
    phi[4,3]  R1709     -2.3374280929565430e+00
    phi[4,3]  R1710     -3.5891635417938232e+00
    phi[4,3]  R1711     -2.4512956142425537e+00
    phi[4,3]  R1712     -8.6009031534194946e-01
    phi[4,3]  R1713     -2.2004370689392090e+00
    phi[4,3]  R1714     -2.3644518852233887e+00
    phi[4,3]  R1715     -2.5680489540100098e+00
    phi[4,3]  R1716     -3.1614201068878174e+00
    phi[4,3]  R1717     -1.4101479053497314e+00
    phi[4,3]  R1718     -2.0169723033905029e+00
    phi[4,3]  R1719     -1.5530717372894287e+00
    phi[4,3]  R1720     -1.9962453842163086e+00
    phi[4,3]  R1721     -2.30719256401062
    phi[4,3]  R1722     -1.4108206033706665e+00
    phi[4,3]  R1723     -1.0566641092300415e+00
    phi[4,3]  R1724     -1.2490376234054565e+00
    phi[4,3]  R1725     -2.9005851745605469e+00
    phi[4,3]  R1726     -2.6873855590820312e+00
    phi[4,3]  R1727     -3.2630155086517334e+00
    phi[4,3]  R1728     -1.8153613805770874e+00
    phi[4,3]  R1729     -3.0504553318023682e+00
    phi[4,3]  R1730     -2.2559545040130615e+00
    phi[4,3]  R1731     -3.7274265289306641e+00
    phi[4,3]  R1732     -2.2560708224773407e-01
    phi[4,3]  R1733     -4.1494026780128479e-01
    phi[4,3]  R1734     -6.8411421775817871e-01
    phi[4,3]  R1735     -7.1868991851806641e-01
    phi[4,3]  R1736     -3.8774913549423218e-01
    phi[4,3]  R1737     1.1471464633941650e+00
    phi[4,3]  R1738     1.2405275106430054e+00
    phi[4,3]  R1739     5.1728922128677368e-01
    phi[4,3]  R1740     2.4305722117424011e-01
    phi[4,3]  R1741     9.7399193048477173e-01
    phi[4,3]  R1742     -1.0350724309682846e-01
    phi[4,3]  R1743     -5.3493452072143555e-01
    phi[4,3]  R1744     1.4137096703052521e-01
    phi[4,3]  R1745     -8.7300115823745728e-01
    phi[4,3]  R1746     -1.0423594713211060e+00
    phi[4,3]  R1747     -3.8083705306053162e-01
    phi[4,3]  R1748     -8.7494438886642456e-01
    phi[4,3]  R1749     -6.5482038259506226e-01
    phi[4,3]  R1750     -0.0467756912112236
    phi[4,3]  R1751     3.5126274824142456e-01
    phi[4,3]  R1752     -1.6171251237392426e-01
    phi[4,3]  R1753     -1.2060434818267822e+00
    phi[4,3]  R1754     -3.3578922748565674e+00
    phi[4,3]  R1755     9.5429325103759766e-01
    phi[4,3]  R1756     5.7618981599807739e-01
    phi[4,3]  R1757     -2.0623319149017334e+00
    phi[4,3]  R1758     -6.3202768564224243e-01
    phi[4,3]  R1759     7.9295247793197632e-01
    phi[4,3]  R1760     9.6014821529388428e-01
    phi[4,3]  R1761     -4.2407852411270142e-01
    phi[4,3]  R1762     -2.2695252895355225e+00
    phi[4,3]  R1763     -1.8623422384262085e+00
    phi[4,3]  R1764     -3.0852394104003906e+00
    phi[4,3]  R1765     -7.9981499910354614e-01
    phi[4,3]  R1766     -7.8781938552856445e-01
    phi[4,3]  R1767     -2.1223945617675781e+00
    phi[4,3]  R1768     -4.9403226375579834e-01
    phi[4,3]  R1769     -0.777820885181427
    phi[4,3]  R1770     -1.2320812940597534e+00
    phi[4,3]  R1771     -1.3441033363342285e+00
    phi[4,3]  R1772     -7.4051588773727417e-02
    phi[4,3]  R1773     -1.4660637378692627e+00
    phi[4,3]  R1774     -1.8688694238662720e+00
    phi[4,3]  R1775     8.9952695369720459e-01
    phi[4,3]  R1776     -1.0251793861389160e+00
    phi[4,3]  R1777     -2.4361248314380646e-01
    phi[4,3]  R1778     -1.9769359827041626e+00
    phi[4,3]  R1779     -1.3273369073867798e+00
    phi[4,3]  R1780     -3.5716748237609863e-01
    phi[4,3]  R1781     -0.960620641708374
    phi[4,3]  R1782     -2.5011034011840820e+00
    phi[4,3]  R1783     9.2747963964939117e-02
    phi[4,3]  R1784     -1.4066746234893799e+00
    phi[4,3]  R1785     6.9785058498382568e-01
    phi[4,3]  R1786     1.3858495950698853e+00
    phi[4,3]  R1787     -2.1608285903930664e+00
    phi[4,3]  R1788     -4.9587965011596680e-02
    phi[4,3]  R1789     -1.7300007343292236e+00
    phi[4,3]  R1790     -1.4087241888046265e+00
    phi[4,3]  R1791     -2.5405454635620117e+00
    phi[4,3]  R1792     -1.0632543563842773e+00
    phi[4,3]  R1793     -1.2075016647577286e-01
    phi[4,3]  R1794     -4.1495648026466370e-01
    phi[4,3]  R1795     -3.4901756048202515e-01
    phi[4,3]  R1796     -1.2548009157180786e+00
    phi[4,3]  R1797     -2.4236304759979248e+00
    phi[4,3]  R1798     -1.0867643356323242e+00
    phi[4,3]  R1799     -2.4787235260009766e+00
    phi[4,3]  R1800     -2.0590219497680664e+00
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1801     -3.0999999046325684e+00
    phi[3,6]  R1802     -3.0999999046325684e+00
    phi[3,6]  R1803     -2.2400000095367432e+00
    phi[3,6]  R1804     -2.2400000095367432e+00
    phi[3,6]  R1805     -3.0999999046325684e+00
    phi[3,6]  R1806     -3.0999999046325684e+00
    phi[3,6]  R1807     -2.5699999332427979e+00
    phi[3,6]  R1808     -2.5699999332427979e+00
    phi[3,6]  R1809     -3.0999999046325684e+00
    phi[3,6]  R1810     -3.0999999046325684e+00
    phi[3,6]  R1811     -2.0899999141693115e+00
    phi[3,6]  R1812     -2.0899999141693115e+00
    phi[3,6]  R1813     -3.0999999046325684e+00
    phi[3,6]  R1814     -3.0999999046325684e+00
    phi[3,6]  R1815     -2.2560708224773407e-01
    phi[3,6]  R1816     -4.1494026780128479e-01
    phi[3,6]  R1817     -6.8411421775817871e-01
    phi[3,6]  R1818     -7.1868991851806641e-01
    phi[3,6]  R1819     -3.8774913549423218e-01
    phi[3,6]  R1820     1.1471464633941650e+00
    phi[3,6]  R1821     1.2405275106430054e+00
    phi[3,6]  R1822     5.1728922128677368e-01
    phi[3,6]  R1823     2.4305722117424011e-01
    phi[3,6]  R1824     9.7399193048477173e-01
    phi[3,6]  R1825     -1.0350724309682846e-01
    phi[3,6]  R1826     -5.3493452072143555e-01
    phi[3,6]  R1827     1.4137096703052521e-01
    phi[3,6]  R1828     -8.7300115823745728e-01
    phi[3,6]  R1829     -1.0423594713211060e+00
    phi[3,6]  R1830     -3.8083705306053162e-01
    phi[3,6]  R1831     -8.7494438886642456e-01
    phi[3,6]  R1832     -6.5482038259506226e-01
    phi[3,6]  R1833     -0.0467756912112236
    phi[3,6]  R1834     3.5126274824142456e-01
    phi[3,6]  R1835     -1.6171251237392426e-01
    phi[3,6]  R1836     -1.2060434818267822e+00
    phi[3,6]  R1837     -3.3578922748565674e+00
    phi[3,6]  R1838     9.5429325103759766e-01
    phi[3,6]  R1839     5.7618981599807739e-01
    phi[3,6]  R1840     -2.0623319149017334e+00
    phi[3,6]  R1841     -6.3202768564224243e-01
    phi[3,6]  R1842     7.9295247793197632e-01
    phi[3,6]  R1843     9.6014821529388428e-01
    phi[3,6]  R1844     -4.2407852411270142e-01
    phi[3,6]  R1845     -2.2695252895355225e+00
    phi[3,6]  R1846     -1.8623422384262085e+00
    phi[3,6]  R1847     -3.0852394104003906e+00
    phi[3,6]  R1848     -7.9981499910354614e-01
    phi[3,6]  R1849     -7.8781938552856445e-01
    phi[3,6]  R1850     -2.1223945617675781e+00
    phi[3,6]  R1851     -4.9403226375579834e-01
    phi[3,6]  R1852     -0.777820885181427
    phi[3,6]  R1853     -1.2320812940597534e+00
    phi[3,6]  R1854     -1.3441033363342285e+00
    phi[3,6]  R1855     -7.4051588773727417e-02
    phi[3,6]  R1856     -1.4660637378692627e+00
    phi[3,6]  R1857     -1.8688694238662720e+00
    phi[3,6]  R1858     8.9952695369720459e-01
    phi[3,6]  R1859     -1.0251793861389160e+00
    phi[3,6]  R1860     -2.4361248314380646e-01
    phi[3,6]  R1861     -1.9769359827041626e+00
    phi[3,6]  R1862     -1.3273369073867798e+00
    phi[3,6]  R1863     -3.5716748237609863e-01
    phi[3,6]  R1864     -0.960620641708374
    phi[3,6]  R1865     -2.5011034011840820e+00
    phi[3,6]  R1866     9.2747963964939117e-02
    phi[3,6]  R1867     -1.4066746234893799e+00
    phi[3,6]  R1868     6.9785058498382568e-01
    phi[3,6]  R1869     1.3858495950698853e+00
    phi[3,6]  R1870     -2.1608285903930664e+00
    phi[3,6]  R1871     -4.9587965011596680e-02
    phi[3,6]  R1872     -1.7300007343292236e+00
    phi[3,6]  R1873     -1.4087241888046265e+00
    phi[3,6]  R1874     -2.5405454635620117e+00
    phi[3,6]  R1875     -1.0632543563842773e+00
    phi[3,6]  R1876     -1.2075016647577286e-01
    phi[3,6]  R1877     -4.1495648026466370e-01
    phi[3,6]  R1878     -3.4901756048202515e-01
    phi[3,6]  R1879     -1.2548009157180786e+00
    phi[3,6]  R1880     -2.4236304759979248e+00
    phi[3,6]  R1881     -1.0867643356323242e+00
    phi[3,6]  R1882     -2.4787235260009766e+00
    phi[3,6]  R1883     -2.0590219497680664e+00
    phi[3,6]  R1884     2.6076083183288574e+00
    phi[3,6]  R1885     6.8630856275558472e-01
    phi[3,6]  R1886     2.1156513690948486e+00
    phi[3,6]  R1887     1.4403879642486572e+00
    phi[3,6]  R1888     1.9452199935913086e+00
    phi[3,6]  R1889     1.8707634508609772e-01
    phi[3,6]  R1890     9.6376115083694458e-01
    phi[3,6]  R1891     1.2372753620147705e+00
    phi[3,6]  R1892     1.5879375934600830e+00
    phi[3,6]  R1893     1.2061446905136108e+00
    phi[3,6]  R1894     -4.9308747053146362e-01
    phi[3,6]  R1895     -3.1541643142700195e+00
    phi[3,6]  R1896     -1.2181717157363892e+00
    phi[3,6]  R1897     -6.5937983989715576e-01
    phi[3,6]  R1898     -2.4126670360565186e+00
    phi[3,6]  R1899     7.0902451872825623e-02
    phi[3,6]  R1900     -4.1423029899597168e+00
    phi[3,6]  R1901     -3.1070941686630249e-01
    phi[3,6]  R1902     -1.9834290742874146e+00
    phi[3,6]  R1903     -1.1414165496826172e+00
    phi[3,6]  R1904     -1.6809436082839966e+00
    phi[3,6]  R1905     6.7658799886703491e-01
    phi[3,6]  R1906     3.9080739021301270e-02
    phi[3,6]  R1907     -3.2035019397735596e+00
    phi[3,6]  R1908     -2.5811049938201904e+00
    phi[3,6]  R1909     -1.6233938932418823e+00
    phi[3,6]  R1910     -1.0524587631225586e+00
    phi[3,6]  R1911     -1.4967588186264038e+00
    phi[3,6]  R1912     -2.1295061111450195e+00
    phi[3,6]  R1913     4.0459814667701721e-01
    phi[3,6]  R1914     -1.4126646518707275e-01
    phi[3,6]  R1915     -1.4084001779556274e+00
    phi[3,6]  R1916     6.4347761869430542e-01
    phi[3,6]  R1917     -1.1718202829360962e+00
    phi[3,6]  R1918     -2.3882064819335938e+00
    phi[3,6]  R1919     -1.5724831819534302e+00
    phi[3,6]  R1920     -1.1874619722366333e+00
    phi[3,6]  R1921     -3.3879095315933228e-01
    phi[3,6]  R1922     -1.1181638240814209e+00
    phi[3,6]  R1923     -3.6107069253921509e-01
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1924     -3.0999999046325684e+00
    phi[6,3]  R1925     -3.0999999046325684e+00
    phi[6,3]  R1926     -2.2400000095367432e+00
    phi[6,3]  R1927     -2.2400000095367432e+00
    phi[6,3]  R1928     -3.0999999046325684e+00
    phi[6,3]  R1929     -3.0999999046325684e+00
    phi[6,3]  R1930     -2.5699999332427979e+00
    phi[6,3]  R1931     -2.5699999332427979e+00
    phi[6,3]  R1932     -3.0999999046325684e+00
    phi[6,3]  R1933     -3.0999999046325684e+00
    phi[6,3]  R1934     -2.0899999141693115e+00
    phi[6,3]  R1935     -2.0899999141693115e+00
    phi[6,3]  R1936     -3.0999999046325684e+00
    phi[6,3]  R1937     -3.0999999046325684e+00
    phi[6,3]  R1938     2.6076083183288574e+00
    phi[6,3]  R1939     6.8630856275558472e-01
    phi[6,3]  R1940     2.1156513690948486e+00
    phi[6,3]  R1941     1.4403879642486572e+00
    phi[6,3]  R1942     1.9452199935913086e+00
    phi[6,3]  R1943     1.8707634508609772e-01
    phi[6,3]  R1944     9.6376115083694458e-01
    phi[6,3]  R1945     1.2372753620147705e+00
    phi[6,3]  R1946     1.5879375934600830e+00
    phi[6,3]  R1947     1.2061446905136108e+00
    phi[6,3]  R1948     -4.9308747053146362e-01
    phi[6,3]  R1949     -3.1541643142700195e+00
    phi[6,3]  R1950     -1.2181717157363892e+00
    phi[6,3]  R1951     -6.5937983989715576e-01
    phi[6,3]  R1952     -2.4126670360565186e+00
    phi[6,3]  R1953     7.0902451872825623e-02
    phi[6,3]  R1954     -4.1423029899597168e+00
    phi[6,3]  R1955     -3.1070941686630249e-01
    phi[6,3]  R1956     -1.9834290742874146e+00
    phi[6,3]  R1957     -1.1414165496826172e+00
    phi[6,3]  R1958     -1.6809436082839966e+00
    phi[6,3]  R1959     6.7658799886703491e-01
    phi[6,3]  R1960     3.9080739021301270e-02
    phi[6,3]  R1961     -3.2035019397735596e+00
    phi[6,3]  R1962     -2.5811049938201904e+00
    phi[6,3]  R1963     -1.6233938932418823e+00
    phi[6,3]  R1964     -1.0524587631225586e+00
    phi[6,3]  R1965     -1.4967588186264038e+00
    phi[6,3]  R1966     -2.1295061111450195e+00
    phi[6,3]  R1967     4.0459814667701721e-01
    phi[6,3]  R1968     -1.4126646518707275e-01
    phi[6,3]  R1969     -1.4084001779556274e+00
    phi[6,3]  R1970     6.4347761869430542e-01
    phi[6,3]  R1971     -1.1718202829360962e+00
    phi[6,3]  R1972     -2.3882064819335938e+00
    phi[6,3]  R1973     -1.5724831819534302e+00
    phi[6,3]  R1974     -1.1874619722366333e+00
    phi[6,3]  R1975     -3.3879095315933228e-01
    phi[6,3]  R1976     -1.1181638240814209e+00
    phi[6,3]  R1977     -3.6107069253921509e-01
    phi[6,3]  R1978     -2.2560708224773407e-01
    phi[6,3]  R1979     -4.1494026780128479e-01
    phi[6,3]  R1980     -6.8411421775817871e-01
    phi[6,3]  R1981     -7.1868991851806641e-01
    phi[6,3]  R1982     -3.8774913549423218e-01
    phi[6,3]  R1983     1.1471464633941650e+00
    phi[6,3]  R1984     1.2405275106430054e+00
    phi[6,3]  R1985     5.1728922128677368e-01
    phi[6,3]  R1986     2.4305722117424011e-01
    phi[6,3]  R1987     9.7399193048477173e-01
    phi[6,3]  R1988     -1.0350724309682846e-01
    phi[6,3]  R1989     -5.3493452072143555e-01
    phi[6,3]  R1990     1.4137096703052521e-01
    phi[6,3]  R1991     -8.7300115823745728e-01
    phi[6,3]  R1992     -1.0423594713211060e+00
    phi[6,3]  R1993     -3.8083705306053162e-01
    phi[6,3]  R1994     -8.7494438886642456e-01
    phi[6,3]  R1995     -6.5482038259506226e-01
    phi[6,3]  R1996     -0.0467756912112236
    phi[6,3]  R1997     3.5126274824142456e-01
    phi[6,3]  R1998     -1.6171251237392426e-01
    phi[6,3]  R1999     -1.2060434818267822e+00
    phi[6,3]  R2000     -3.3578922748565674e+00
    phi[6,3]  R2001     9.5429325103759766e-01
    phi[6,3]  R2002     5.7618981599807739e-01
    phi[6,3]  R2003     -2.0623319149017334e+00
    phi[6,3]  R2004     -6.3202768564224243e-01
    phi[6,3]  R2005     7.9295247793197632e-01
    phi[6,3]  R2006     9.6014821529388428e-01
    phi[6,3]  R2007     -4.2407852411270142e-01
    phi[6,3]  R2008     -2.2695252895355225e+00
    phi[6,3]  R2009     -1.8623422384262085e+00
    phi[6,3]  R2010     -3.0852394104003906e+00
    phi[6,3]  R2011     -7.9981499910354614e-01
    phi[6,3]  R2012     -7.8781938552856445e-01
    phi[6,3]  R2013     -2.1223945617675781e+00
    phi[6,3]  R2014     -4.9403226375579834e-01
    phi[6,3]  R2015     -0.777820885181427
    phi[6,3]  R2016     -1.2320812940597534e+00
    phi[6,3]  R2017     -1.3441033363342285e+00
    phi[6,3]  R2018     -7.4051588773727417e-02
    phi[6,3]  R2019     -1.4660637378692627e+00
    phi[6,3]  R2020     -1.8688694238662720e+00
    phi[6,3]  R2021     8.9952695369720459e-01
    phi[6,3]  R2022     -1.0251793861389160e+00
    phi[6,3]  R2023     -2.4361248314380646e-01
    phi[6,3]  R2024     -1.9769359827041626e+00
    phi[6,3]  R2025     -1.3273369073867798e+00
    phi[6,3]  R2026     -3.5716748237609863e-01
    phi[6,3]  R2027     -0.960620641708374
    phi[6,3]  R2028     -2.5011034011840820e+00
    phi[6,3]  R2029     9.2747963964939117e-02
    phi[6,3]  R2030     -1.4066746234893799e+00
    phi[6,3]  R2031     6.9785058498382568e-01
    phi[6,3]  R2032     1.3858495950698853e+00
    phi[6,3]  R2033     -2.1608285903930664e+00
    phi[6,3]  R2034     -4.9587965011596680e-02
    phi[6,3]  R2035     -1.7300007343292236e+00
    phi[6,3]  R2036     -1.4087241888046265e+00
    phi[6,3]  R2037     -2.5405454635620117e+00
    phi[6,3]  R2038     -1.0632543563842773e+00
    phi[6,3]  R2039     -1.2075016647577286e-01
    phi[6,3]  R2040     -4.1495648026466370e-01
    phi[6,3]  R2041     -3.4901756048202515e-01
    phi[6,3]  R2042     -1.2548009157180786e+00
    phi[6,3]  R2043     -2.4236304759979248e+00
    phi[6,3]  R2044     -1.0867643356323242e+00
    phi[6,3]  R2045     -2.4787235260009766e+00
    phi[6,3]  R2046     -2.0590219497680664e+00
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R2047     -3.0999999046325684e+00
    phi[3,7]  R2048     -3.0999999046325684e+00
    phi[3,7]  R2049     -2.2400000095367432e+00
    phi[3,7]  R2050     -2.2400000095367432e+00
    phi[3,7]  R2051     -3.0999999046325684e+00
    phi[3,7]  R2052     -3.0999999046325684e+00
    phi[3,7]  R2053     -2.5699999332427979e+00
    phi[3,7]  R2054     -2.5699999332427979e+00
    phi[3,7]  R2055     -3.0999999046325684e+00
    phi[3,7]  R2056     -3.0999999046325684e+00
    phi[3,7]  R2057     -2.0899999141693115e+00
    phi[3,7]  R2058     -2.0899999141693115e+00
    phi[3,7]  R2059     -3.0999999046325684e+00
    phi[3,7]  R2060     -3.0999999046325684e+00
    phi[3,7]  R2061     -2.2560708224773407e-01
    phi[3,7]  R2062     -4.1494026780128479e-01
    phi[3,7]  R2063     -6.8411421775817871e-01
    phi[3,7]  R2064     -7.1868991851806641e-01
    phi[3,7]  R2065     -3.8774913549423218e-01
    phi[3,7]  R2066     1.1471464633941650e+00
    phi[3,7]  R2067     1.2405275106430054e+00
    phi[3,7]  R2068     5.1728922128677368e-01
    phi[3,7]  R2069     2.4305722117424011e-01
    phi[3,7]  R2070     9.7399193048477173e-01
    phi[3,7]  R2071     -1.0350724309682846e-01
    phi[3,7]  R2072     -5.3493452072143555e-01
    phi[3,7]  R2073     1.4137096703052521e-01
    phi[3,7]  R2074     -8.7300115823745728e-01
    phi[3,7]  R2075     -1.0423594713211060e+00
    phi[3,7]  R2076     -3.8083705306053162e-01
    phi[3,7]  R2077     -8.7494438886642456e-01
    phi[3,7]  R2078     -6.5482038259506226e-01
    phi[3,7]  R2079     -0.0467756912112236
    phi[3,7]  R2080     3.5126274824142456e-01
    phi[3,7]  R2081     -1.6171251237392426e-01
    phi[3,7]  R2082     -1.2060434818267822e+00
    phi[3,7]  R2083     -3.3578922748565674e+00
    phi[3,7]  R2084     9.5429325103759766e-01
    phi[3,7]  R2085     5.7618981599807739e-01
    phi[3,7]  R2086     -2.0623319149017334e+00
    phi[3,7]  R2087     -6.3202768564224243e-01
    phi[3,7]  R2088     7.9295247793197632e-01
    phi[3,7]  R2089     9.6014821529388428e-01
    phi[3,7]  R2090     -4.2407852411270142e-01
    phi[3,7]  R2091     -2.2695252895355225e+00
    phi[3,7]  R2092     -1.8623422384262085e+00
    phi[3,7]  R2093     -3.0852394104003906e+00
    phi[3,7]  R2094     -7.9981499910354614e-01
    phi[3,7]  R2095     -7.8781938552856445e-01
    phi[3,7]  R2096     -2.1223945617675781e+00
    phi[3,7]  R2097     -4.9403226375579834e-01
    phi[3,7]  R2098     -0.777820885181427
    phi[3,7]  R2099     -1.2320812940597534e+00
    phi[3,7]  R2100     -1.3441033363342285e+00
    phi[3,7]  R2101     -7.4051588773727417e-02
    phi[3,7]  R2102     -1.4660637378692627e+00
    phi[3,7]  R2103     -1.8688694238662720e+00
    phi[3,7]  R2104     8.9952695369720459e-01
    phi[3,7]  R2105     -1.0251793861389160e+00
    phi[3,7]  R2106     -2.4361248314380646e-01
    phi[3,7]  R2107     -1.9769359827041626e+00
    phi[3,7]  R2108     -1.3273369073867798e+00
    phi[3,7]  R2109     -3.5716748237609863e-01
    phi[3,7]  R2110     -0.960620641708374
    phi[3,7]  R2111     -2.5011034011840820e+00
    phi[3,7]  R2112     9.2747963964939117e-02
    phi[3,7]  R2113     -1.4066746234893799e+00
    phi[3,7]  R2114     6.9785058498382568e-01
    phi[3,7]  R2115     1.3858495950698853e+00
    phi[3,7]  R2116     -2.1608285903930664e+00
    phi[3,7]  R2117     -4.9587965011596680e-02
    phi[3,7]  R2118     -1.7300007343292236e+00
    phi[3,7]  R2119     -1.4087241888046265e+00
    phi[3,7]  R2120     -2.5405454635620117e+00
    phi[3,7]  R2121     -1.0632543563842773e+00
    phi[3,7]  R2122     -1.2075016647577286e-01
    phi[3,7]  R2123     -4.1495648026466370e-01
    phi[3,7]  R2124     -3.4901756048202515e-01
    phi[3,7]  R2125     -1.2548009157180786e+00
    phi[3,7]  R2126     -2.4236304759979248e+00
    phi[3,7]  R2127     -1.0867643356323242e+00
    phi[3,7]  R2128     -2.4787235260009766e+00
    phi[3,7]  R2129     -2.0590219497680664e+00
    phi[3,7]  R2130     9.9413096904754639e-02
    phi[3,7]  R2131     -1.7032012343406677e-01
    phi[3,7]  R2132     1.9676467403769493e-02
    phi[3,7]  R2133     2.3302994668483734e-01
    phi[3,7]  R2134     -2.2324560582637787e-01
    phi[3,7]  R2135     4.8189321160316467e-01
    phi[3,7]  R2136     -3.7492558360099792e-01
    phi[3,7]  R2137     8.4481149911880493e-01
    phi[3,7]  R2138     0.840761661529541
    phi[3,7]  R2139     -1.2594033479690552e+00
    phi[3,7]  R2140     5.2686792612075806e-01
    phi[3,7]  R2141     1.1709102988243103e-01
    phi[3,7]  R2142     2.5978749617934227e-02
    phi[3,7]  R2143     -2.3088788986206055e-01
    phi[3,7]  R2144     -5.9526139497756958e-01
    phi[3,7]  R2145     6.4458596706390381e-01
    phi[3,7]  R2146     -5.9742921590805054e-01
    phi[3,7]  R2147     0.427736759185791
    phi[3,7]  R2148     -1.2762162685394287e+00
    phi[3,7]  R2149     -1.0009621381759644e+00
    phi[3,7]  R2150     -1.6633864641189575e+00
    phi[3,7]  R2151     -1.5523450374603271e+00
    phi[3,7]  R2152     -7.3273056745529175e-01
    phi[3,7]  R2153     -4.1974949836730957e-01
    phi[3,7]  R2154     -7.2979968786239624e-01
    phi[3,7]  R2155     -1.5292568206787109e+00
    phi[3,7]  R2156     -1.7716504335403442e+00
    phi[3,7]  R2157     -1.5031944513320923e+00
    phi[3,7]  R2158     -7.7915364503860474e-01
    phi[3,7]  R2159     -1.1290464401245117e+00
    phi[3,7]  R2160     -2.6159355640411377e+00
    phi[3,7]  R2161     -5.9536463022232056e-01
    phi[3,7]  R2162     -1.4354993104934692e+00
    phi[3,7]  R2163     -2.5630605220794678e+00
    phi[3,7]  R2164     5.4828107357025146e-01
    phi[3,7]  R2165     -4.1488805413246155e-01
    phi[3,7]  R2166     -8.3401310443878174e-01
    phi[3,7]  R2167     -5.0063955783843994e-01
    phi[3,7]  R2168     -3.5572871565818787e-01
    phi[3,7]  R2169     1.1481480598449707e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R2170     -3.0999999046325684e+00
    phi[7,3]  R2171     -3.0999999046325684e+00
    phi[7,3]  R2172     -2.2400000095367432e+00
    phi[7,3]  R2173     -2.2400000095367432e+00
    phi[7,3]  R2174     -3.0999999046325684e+00
    phi[7,3]  R2175     -3.0999999046325684e+00
    phi[7,3]  R2176     -2.5699999332427979e+00
    phi[7,3]  R2177     -2.5699999332427979e+00
    phi[7,3]  R2178     -3.0999999046325684e+00
    phi[7,3]  R2179     -3.0999999046325684e+00
    phi[7,3]  R2180     -2.0899999141693115e+00
    phi[7,3]  R2181     -2.0899999141693115e+00
    phi[7,3]  R2182     -3.0999999046325684e+00
    phi[7,3]  R2183     -3.0999999046325684e+00
    phi[7,3]  R2184     9.9413096904754639e-02
    phi[7,3]  R2185     -1.7032012343406677e-01
    phi[7,3]  R2186     1.9676467403769493e-02
    phi[7,3]  R2187     2.3302994668483734e-01
    phi[7,3]  R2188     -2.2324560582637787e-01
    phi[7,3]  R2189     4.8189321160316467e-01
    phi[7,3]  R2190     -3.7492558360099792e-01
    phi[7,3]  R2191     8.4481149911880493e-01
    phi[7,3]  R2192     0.840761661529541
    phi[7,3]  R2193     -1.2594033479690552e+00
    phi[7,3]  R2194     5.2686792612075806e-01
    phi[7,3]  R2195     1.1709102988243103e-01
    phi[7,3]  R2196     2.5978749617934227e-02
    phi[7,3]  R2197     -2.3088788986206055e-01
    phi[7,3]  R2198     -5.9526139497756958e-01
    phi[7,3]  R2199     6.4458596706390381e-01
    phi[7,3]  R2200     -5.9742921590805054e-01
    phi[7,3]  R2201     0.427736759185791
    phi[7,3]  R2202     -1.2762162685394287e+00
    phi[7,3]  R2203     -1.0009621381759644e+00
    phi[7,3]  R2204     -1.6633864641189575e+00
    phi[7,3]  R2205     -1.5523450374603271e+00
    phi[7,3]  R2206     -7.3273056745529175e-01
    phi[7,3]  R2207     -4.1974949836730957e-01
    phi[7,3]  R2208     -7.2979968786239624e-01
    phi[7,3]  R2209     -1.5292568206787109e+00
    phi[7,3]  R2210     -1.7716504335403442e+00
    phi[7,3]  R2211     -1.5031944513320923e+00
    phi[7,3]  R2212     -7.7915364503860474e-01
    phi[7,3]  R2213     -1.1290464401245117e+00
    phi[7,3]  R2214     -2.6159355640411377e+00
    phi[7,3]  R2215     -5.9536463022232056e-01
    phi[7,3]  R2216     -1.4354993104934692e+00
    phi[7,3]  R2217     -2.5630605220794678e+00
    phi[7,3]  R2218     5.4828107357025146e-01
    phi[7,3]  R2219     -4.1488805413246155e-01
    phi[7,3]  R2220     -8.3401310443878174e-01
    phi[7,3]  R2221     -5.0063955783843994e-01
    phi[7,3]  R2222     -3.5572871565818787e-01
    phi[7,3]  R2223     1.1481480598449707e+00
    phi[7,3]  R2224     -2.2560708224773407e-01
    phi[7,3]  R2225     -4.1494026780128479e-01
    phi[7,3]  R2226     -6.8411421775817871e-01
    phi[7,3]  R2227     -7.1868991851806641e-01
    phi[7,3]  R2228     -3.8774913549423218e-01
    phi[7,3]  R2229     1.1471464633941650e+00
    phi[7,3]  R2230     1.2405275106430054e+00
    phi[7,3]  R2231     5.1728922128677368e-01
    phi[7,3]  R2232     2.4305722117424011e-01
    phi[7,3]  R2233     9.7399193048477173e-01
    phi[7,3]  R2234     -1.0350724309682846e-01
    phi[7,3]  R2235     -5.3493452072143555e-01
    phi[7,3]  R2236     1.4137096703052521e-01
    phi[7,3]  R2237     -8.7300115823745728e-01
    phi[7,3]  R2238     -1.0423594713211060e+00
    phi[7,3]  R2239     -3.8083705306053162e-01
    phi[7,3]  R2240     -8.7494438886642456e-01
    phi[7,3]  R2241     -6.5482038259506226e-01
    phi[7,3]  R2242     -0.0467756912112236
    phi[7,3]  R2243     3.5126274824142456e-01
    phi[7,3]  R2244     -1.6171251237392426e-01
    phi[7,3]  R2245     -1.2060434818267822e+00
    phi[7,3]  R2246     -3.3578922748565674e+00
    phi[7,3]  R2247     9.5429325103759766e-01
    phi[7,3]  R2248     5.7618981599807739e-01
    phi[7,3]  R2249     -2.0623319149017334e+00
    phi[7,3]  R2250     -6.3202768564224243e-01
    phi[7,3]  R2251     7.9295247793197632e-01
    phi[7,3]  R2252     9.6014821529388428e-01
    phi[7,3]  R2253     -4.2407852411270142e-01
    phi[7,3]  R2254     -2.2695252895355225e+00
    phi[7,3]  R2255     -1.8623422384262085e+00
    phi[7,3]  R2256     -3.0852394104003906e+00
    phi[7,3]  R2257     -7.9981499910354614e-01
    phi[7,3]  R2258     -7.8781938552856445e-01
    phi[7,3]  R2259     -2.1223945617675781e+00
    phi[7,3]  R2260     -4.9403226375579834e-01
    phi[7,3]  R2261     -0.777820885181427
    phi[7,3]  R2262     -1.2320812940597534e+00
    phi[7,3]  R2263     -1.3441033363342285e+00
    phi[7,3]  R2264     -7.4051588773727417e-02
    phi[7,3]  R2265     -1.4660637378692627e+00
    phi[7,3]  R2266     -1.8688694238662720e+00
    phi[7,3]  R2267     8.9952695369720459e-01
    phi[7,3]  R2268     -1.0251793861389160e+00
    phi[7,3]  R2269     -2.4361248314380646e-01
    phi[7,3]  R2270     -1.9769359827041626e+00
    phi[7,3]  R2271     -1.3273369073867798e+00
    phi[7,3]  R2272     -3.5716748237609863e-01
    phi[7,3]  R2273     -0.960620641708374
    phi[7,3]  R2274     -2.5011034011840820e+00
    phi[7,3]  R2275     9.2747963964939117e-02
    phi[7,3]  R2276     -1.4066746234893799e+00
    phi[7,3]  R2277     6.9785058498382568e-01
    phi[7,3]  R2278     1.3858495950698853e+00
    phi[7,3]  R2279     -2.1608285903930664e+00
    phi[7,3]  R2280     -4.9587965011596680e-02
    phi[7,3]  R2281     -1.7300007343292236e+00
    phi[7,3]  R2282     -1.4087241888046265e+00
    phi[7,3]  R2283     -2.5405454635620117e+00
    phi[7,3]  R2284     -1.0632543563842773e+00
    phi[7,3]  R2285     -1.2075016647577286e-01
    phi[7,3]  R2286     -4.1495648026466370e-01
    phi[7,3]  R2287     -3.4901756048202515e-01
    phi[7,3]  R2288     -1.2548009157180786e+00
    phi[7,3]  R2289     -2.4236304759979248e+00
    phi[7,3]  R2290     -1.0867643356323242e+00
    phi[7,3]  R2291     -2.4787235260009766e+00
    phi[7,3]  R2292     -2.0590219497680664e+00
    phi[4,7]  R36       1
    phi[4,7]  R37       1
    phi[4,7]  R63       -1
    phi[4,7]  R2293     -3.0999999046325684e+00
    phi[4,7]  R2294     -3.0999999046325684e+00
    phi[4,7]  R2295     -2.2400000095367432e+00
    phi[4,7]  R2296     -2.2400000095367432e+00
    phi[4,7]  R2297     -3.0999999046325684e+00
    phi[4,7]  R2298     -3.0999999046325684e+00
    phi[4,7]  R2299     -2.5699999332427979e+00
    phi[4,7]  R2300     -2.5699999332427979e+00
    phi[4,7]  R2301     -3.0999999046325684e+00
    phi[4,7]  R2302     -3.0999999046325684e+00
    phi[4,7]  R2303     -2.0899999141693115e+00
    phi[4,7]  R2304     -2.0899999141693115e+00
    phi[4,7]  R2305     -3.0999999046325684e+00
    phi[4,7]  R2306     -3.0999999046325684e+00
    phi[4,7]  R2307     2.4655783176422119e+00
    phi[4,7]  R2308     1.8349212408065796e+00
    phi[4,7]  R2309     2.7130825519561768e+00
    phi[4,7]  R2310     4.4555360078811646e-01
    phi[4,7]  R2311     2.2862565517425537e+00
    phi[4,7]  R2312     1.7113311290740967e+00
    phi[4,7]  R2313     -1.5530730783939362e-01
    phi[4,7]  R2314     -1.1701208353042603e+00
    phi[4,7]  R2315     1.4742127656936646e+00
    phi[4,7]  R2316     1.0188047885894775e+00
    phi[4,7]  R2317     -2.4243121147155762e+00
    phi[4,7]  R2318     -2.2649476528167725e+00
    phi[4,7]  R2319     -2.6346583366394043e+00
    phi[4,7]  R2320     -2.0034878253936768e+00
    phi[4,7]  R2321     -1.2315746545791626e+00
    phi[4,7]  R2322     -1.6972101926803589e+00
    phi[4,7]  R2323     -0.830448567867279
    phi[4,7]  R2324     -2.3374280929565430e+00
    phi[4,7]  R2325     -3.5891635417938232e+00
    phi[4,7]  R2326     -2.4512956142425537e+00
    phi[4,7]  R2327     -8.6009031534194946e-01
    phi[4,7]  R2328     -2.2004370689392090e+00
    phi[4,7]  R2329     -2.3644518852233887e+00
    phi[4,7]  R2330     -2.5680489540100098e+00
    phi[4,7]  R2331     -3.1614201068878174e+00
    phi[4,7]  R2332     -1.4101479053497314e+00
    phi[4,7]  R2333     -2.0169723033905029e+00
    phi[4,7]  R2334     -1.5530717372894287e+00
    phi[4,7]  R2335     -1.9962453842163086e+00
    phi[4,7]  R2336     -2.30719256401062
    phi[4,7]  R2337     -1.4108206033706665e+00
    phi[4,7]  R2338     -1.0566641092300415e+00
    phi[4,7]  R2339     -1.2490376234054565e+00
    phi[4,7]  R2340     -2.9005851745605469e+00
    phi[4,7]  R2341     -2.6873855590820312e+00
    phi[4,7]  R2342     -3.2630155086517334e+00
    phi[4,7]  R2343     -1.8153613805770874e+00
    phi[4,7]  R2344     -3.0504553318023682e+00
    phi[4,7]  R2345     -2.2559545040130615e+00
    phi[4,7]  R2346     -3.7274265289306641e+00
    phi[4,7]  R2347     9.9413096904754639e-02
    phi[4,7]  R2348     -1.7032012343406677e-01
    phi[4,7]  R2349     1.9676467403769493e-02
    phi[4,7]  R2350     2.3302994668483734e-01
    phi[4,7]  R2351     -2.2324560582637787e-01
    phi[4,7]  R2352     4.8189321160316467e-01
    phi[4,7]  R2353     -3.7492558360099792e-01
    phi[4,7]  R2354     8.4481149911880493e-01
    phi[4,7]  R2355     0.840761661529541
    phi[4,7]  R2356     -1.2594033479690552e+00
    phi[4,7]  R2357     5.2686792612075806e-01
    phi[4,7]  R2358     1.1709102988243103e-01
    phi[4,7]  R2359     2.5978749617934227e-02
    phi[4,7]  R2360     -2.3088788986206055e-01
    phi[4,7]  R2361     -5.9526139497756958e-01
    phi[4,7]  R2362     6.4458596706390381e-01
    phi[4,7]  R2363     -5.9742921590805054e-01
    phi[4,7]  R2364     0.427736759185791
    phi[4,7]  R2365     -1.2762162685394287e+00
    phi[4,7]  R2366     -1.0009621381759644e+00
    phi[4,7]  R2367     -1.6633864641189575e+00
    phi[4,7]  R2368     -1.5523450374603271e+00
    phi[4,7]  R2369     -7.3273056745529175e-01
    phi[4,7]  R2370     -4.1974949836730957e-01
    phi[4,7]  R2371     -7.2979968786239624e-01
    phi[4,7]  R2372     -1.5292568206787109e+00
    phi[4,7]  R2373     -1.7716504335403442e+00
    phi[4,7]  R2374     -1.5031944513320923e+00
    phi[4,7]  R2375     -7.7915364503860474e-01
    phi[4,7]  R2376     -1.1290464401245117e+00
    phi[4,7]  R2377     -2.6159355640411377e+00
    phi[4,7]  R2378     -5.9536463022232056e-01
    phi[4,7]  R2379     -1.4354993104934692e+00
    phi[4,7]  R2380     -2.5630605220794678e+00
    phi[4,7]  R2381     5.4828107357025146e-01
    phi[4,7]  R2382     -4.1488805413246155e-01
    phi[4,7]  R2383     -8.3401310443878174e-01
    phi[4,7]  R2384     -5.0063955783843994e-01
    phi[4,7]  R2385     -3.5572871565818787e-01
    phi[4,7]  R2386     1.1481480598449707e+00
    phi[7,4]  R36       -1
    phi[7,4]  R63       1
    phi[7,4]  R64       1
    phi[7,4]  R2387     -3.0999999046325684e+00
    phi[7,4]  R2388     -3.0999999046325684e+00
    phi[7,4]  R2389     -2.2400000095367432e+00
    phi[7,4]  R2390     -2.2400000095367432e+00
    phi[7,4]  R2391     -3.0999999046325684e+00
    phi[7,4]  R2392     -3.0999999046325684e+00
    phi[7,4]  R2393     -2.5699999332427979e+00
    phi[7,4]  R2394     -2.5699999332427979e+00
    phi[7,4]  R2395     -3.0999999046325684e+00
    phi[7,4]  R2396     -3.0999999046325684e+00
    phi[7,4]  R2397     -2.0899999141693115e+00
    phi[7,4]  R2398     -2.0899999141693115e+00
    phi[7,4]  R2399     -3.0999999046325684e+00
    phi[7,4]  R2400     -3.0999999046325684e+00
    phi[7,4]  R2401     9.9413096904754639e-02
    phi[7,4]  R2402     -1.7032012343406677e-01
    phi[7,4]  R2403     1.9676467403769493e-02
    phi[7,4]  R2404     2.3302994668483734e-01
    phi[7,4]  R2405     -2.2324560582637787e-01
    phi[7,4]  R2406     4.8189321160316467e-01
    phi[7,4]  R2407     -3.7492558360099792e-01
    phi[7,4]  R2408     8.4481149911880493e-01
    phi[7,4]  R2409     0.840761661529541
    phi[7,4]  R2410     -1.2594033479690552e+00
    phi[7,4]  R2411     5.2686792612075806e-01
    phi[7,4]  R2412     1.1709102988243103e-01
    phi[7,4]  R2413     2.5978749617934227e-02
    phi[7,4]  R2414     -2.3088788986206055e-01
    phi[7,4]  R2415     -5.9526139497756958e-01
    phi[7,4]  R2416     6.4458596706390381e-01
    phi[7,4]  R2417     -5.9742921590805054e-01
    phi[7,4]  R2418     0.427736759185791
    phi[7,4]  R2419     -1.2762162685394287e+00
    phi[7,4]  R2420     -1.0009621381759644e+00
    phi[7,4]  R2421     -1.6633864641189575e+00
    phi[7,4]  R2422     -1.5523450374603271e+00
    phi[7,4]  R2423     -7.3273056745529175e-01
    phi[7,4]  R2424     -4.1974949836730957e-01
    phi[7,4]  R2425     -7.2979968786239624e-01
    phi[7,4]  R2426     -1.5292568206787109e+00
    phi[7,4]  R2427     -1.7716504335403442e+00
    phi[7,4]  R2428     -1.5031944513320923e+00
    phi[7,4]  R2429     -7.7915364503860474e-01
    phi[7,4]  R2430     -1.1290464401245117e+00
    phi[7,4]  R2431     -2.6159355640411377e+00
    phi[7,4]  R2432     -5.9536463022232056e-01
    phi[7,4]  R2433     -1.4354993104934692e+00
    phi[7,4]  R2434     -2.5630605220794678e+00
    phi[7,4]  R2435     5.4828107357025146e-01
    phi[7,4]  R2436     -4.1488805413246155e-01
    phi[7,4]  R2437     -8.3401310443878174e-01
    phi[7,4]  R2438     -5.0063955783843994e-01
    phi[7,4]  R2439     -3.5572871565818787e-01
    phi[7,4]  R2440     1.1481480598449707e+00
    phi[7,4]  R2441     2.4655783176422119e+00
    phi[7,4]  R2442     1.8349212408065796e+00
    phi[7,4]  R2443     2.7130825519561768e+00
    phi[7,4]  R2444     4.4555360078811646e-01
    phi[7,4]  R2445     2.2862565517425537e+00
    phi[7,4]  R2446     1.7113311290740967e+00
    phi[7,4]  R2447     -1.5530730783939362e-01
    phi[7,4]  R2448     -1.1701208353042603e+00
    phi[7,4]  R2449     1.4742127656936646e+00
    phi[7,4]  R2450     1.0188047885894775e+00
    phi[7,4]  R2451     -2.4243121147155762e+00
    phi[7,4]  R2452     -2.2649476528167725e+00
    phi[7,4]  R2453     -2.6346583366394043e+00
    phi[7,4]  R2454     -2.0034878253936768e+00
    phi[7,4]  R2455     -1.2315746545791626e+00
    phi[7,4]  R2456     -1.6972101926803589e+00
    phi[7,4]  R2457     -0.830448567867279
    phi[7,4]  R2458     -2.3374280929565430e+00
    phi[7,4]  R2459     -3.5891635417938232e+00
    phi[7,4]  R2460     -2.4512956142425537e+00
    phi[7,4]  R2461     -8.6009031534194946e-01
    phi[7,4]  R2462     -2.2004370689392090e+00
    phi[7,4]  R2463     -2.3644518852233887e+00
    phi[7,4]  R2464     -2.5680489540100098e+00
    phi[7,4]  R2465     -3.1614201068878174e+00
    phi[7,4]  R2466     -1.4101479053497314e+00
    phi[7,4]  R2467     -2.0169723033905029e+00
    phi[7,4]  R2468     -1.5530717372894287e+00
    phi[7,4]  R2469     -1.9962453842163086e+00
    phi[7,4]  R2470     -2.30719256401062
    phi[7,4]  R2471     -1.4108206033706665e+00
    phi[7,4]  R2472     -1.0566641092300415e+00
    phi[7,4]  R2473     -1.2490376234054565e+00
    phi[7,4]  R2474     -2.9005851745605469e+00
    phi[7,4]  R2475     -2.6873855590820312e+00
    phi[7,4]  R2476     -3.2630155086517334e+00
    phi[7,4]  R2477     -1.8153613805770874e+00
    phi[7,4]  R2478     -3.0504553318023682e+00
    phi[7,4]  R2479     -2.2559545040130615e+00
    phi[7,4]  R2480     -3.7274265289306641e+00
    phi[4,9]  R36       1
    phi[4,9]  R37       1
    phi[4,9]  R38       -3.6125030636116495e-01
    phi[4,9]  R39       -2.6452461679205763e-01
    phi[4,9]  R40       3.9996641791024690e-01
    phi[4,9]  R41       -2.0124799360511054e+00
    phi[4,9]  R42       -1.9260572018111559e+00
    phi[4,9]  R43       9.5054969885883667e-01
    phi[4,9]  R44       2.3352610789010457e+00
    phi[4,9]  R73       -1
    phi[4,9]  R2481     -3.4612502109937333e+00
    phi[4,9]  R2482     -2.7387495982714034e+00
    phi[4,9]  R2483     -2.5045246263288008e+00
    phi[4,9]  R2484     -1.9754753927446855e+00
    phi[4,9]  R2485     -2.7000334867223215e+00
    phi[4,9]  R2486     -3.4999663225428153e+00
    phi[4,9]  R2487     -4.5824798692939037e+00
    phi[4,9]  R2488     -5.5751999719169243e-01
    phi[4,9]  R2489     -5.0260571064437247e+00
    phi[4,9]  R2490     -1.1739427028214124e+00
    phi[4,9]  R2491     -1.1394502153104749e+00
    phi[4,9]  R2492     -3.0405496130281482e+00
    phi[4,9]  R2493     -7.6473882573152263e-01
    phi[4,9]  R2494     -5.4352609835336141e+00
    phi[4,9]  R2495     -3.9837473326389983e-02
    phi[4,9]  R2496     -4.4777962338543809e-02
    phi[4,9]  R2497     -4.5743730159583773e-02
    phi[4,9]  R2498     -5.4011069823416080e-02
    phi[4,9]  R2499     -5.9606468084463238e-02
    phi[4,9]  R2500     -7.7470789493852221e-02
    phi[4,9]  R2501     -1.2704043066923083e+00
    phi[4,9]  R2502     -1.1518915166405781e+00
    phi[4,9]  R2503     -8.2206747807695413e-01
    phi[4,9]  R2504     -5.1639085311997612e-01
    phi[4,9]  R2505     -0.190151576111095
    phi[4,9]  R2506     -2.0442502614892355e-01
    phi[4,9]  R2507     -2.1624349052279568e-01
    phi[4,9]  R2508     -3.9342282966917663e-01
    phi[4,9]  R2509     -4.1352231110909865e-01
    phi[4,9]  R2510     -4.4655816860886688e-01
    phi[4,9]  R2511     -1.7390430515258777e+00
    phi[4,9]  R2512     -1.1110688536016353e+00
    phi[4,9]  R2513     -1.1321413298555556e+00
    phi[4,9]  R2514     -1.1338850538466438e+00
    phi[4,9]  R2515     -1.1557452967456807e+00
    phi[4,9]  R2516     -1.7131388715625968e+00
    phi[4,9]  R2517     -1.7387656347577114e+00
    phi[4,9]  R2518     -8.4677166823737049e-01
    phi[4,9]  R2519     -8.7986014980154081e-01
    phi[4,9]  R2520     -8.9501136325284714e-01
    phi[4,9]  R2521     -9.2337340303449023e-01
    phi[4,9]  R2522     -9.3628395378050322e-01
    phi[4,9]  R2523     -9.5360971823865959e-01
    phi[4,9]  R2524     -0.981122679553819
    phi[4,9]  R2525     -0.788748649682413
    phi[4,9]  R2526     -8.0974563077080275e-01
    phi[4,9]  R2527     -8.1583857917284874e-01
    phi[4,9]  R2528     -8.3174485477010140e-01
    phi[4,9]  R2529     -8.5980604006664052e-01
    phi[4,9]  R2530     -8.6260708251832074e-01
    phi[4,9]  R2531     -9.0906379327307674e-01
    phi[4,9]  R2532     -9.3312000123898420e-01
    phi[4,9]  R2533     -9.9111748118494880e-01
    phi[4,9]  R2534     -1.0068455346206457e+00
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2535     -3.0999999046325684e+00
    phi[5,6]  R2536     -3.0999999046325684e+00
    phi[5,6]  R2537     -2.2400000095367432e+00
    phi[5,6]  R2538     -2.2400000095367432e+00
    phi[5,6]  R2539     -3.0999999046325684e+00
    phi[5,6]  R2540     -3.0999999046325684e+00
    phi[5,6]  R2541     -2.5699999332427979e+00
    phi[5,6]  R2542     -2.5699999332427979e+00
    phi[5,6]  R2543     -3.0999999046325684e+00
    phi[5,6]  R2544     -3.0999999046325684e+00
    phi[5,6]  R2545     -2.0899999141693115e+00
    phi[5,6]  R2546     -2.0899999141693115e+00
    phi[5,6]  R2547     -3.0999999046325684e+00
    phi[5,6]  R2548     -3.0999999046325684e+00
    phi[5,6]  R2549     1.8164458274841309e+00
    phi[5,6]  R2550     1.8318803310394287e+00
    phi[5,6]  R2551     2.6805303096771240e+00
    phi[5,6]  R2552     3.1378457546234131e+00
    phi[5,6]  R2553     1.6333773136138916e+00
    phi[5,6]  R2554     3.1371634006500244e+00
    phi[5,6]  R2555     2.1908650398254395e+00
    phi[5,6]  R2556     1.8168040513992310e+00
    phi[5,6]  R2557     2.7592725753784180e+00
    phi[5,6]  R2558     3.3667798042297363e+00
    phi[5,6]  R2559     -2.9324169158935547e+00
    phi[5,6]  R2560     -0.565557062625885
    phi[5,6]  R2561     6.4368438720703125e-01
    phi[5,6]  R2562     7.4732547998428345e-01
    phi[5,6]  R2563     -2.5832197666168213e+00
    phi[5,6]  R2564     1.3125869035720825e+00
    phi[5,6]  R2565     -2.6062109470367432e+00
    phi[5,6]  R2566     0.457389771938324
    phi[5,6]  R2567     -2.7732777595520020e+00
    phi[5,6]  R2568     -2.9012253284454346e+00
    phi[5,6]  R2569     -1.4401623010635376e+00
    phi[5,6]  R2570     -1.9682992696762085e+00
    phi[5,6]  R2571     -2.0095534324645996e+00
    phi[5,6]  R2572     -1.4318299293518066e+00
    phi[5,6]  R2573     -1.8964453935623169e+00
    phi[5,6]  R2574     2.8923410922288895e-02
    phi[5,6]  R2575     2.4327416718006134e-01
    phi[5,6]  R2576     -1.5997023582458496e+00
    phi[5,6]  R2577     -3.2220003008842468e-01
    phi[5,6]  R2578     -1.6942701339721680e+00
    phi[5,6]  R2579     1.0142395645380020e-01
    phi[5,6]  R2580     1.3020439147949219e+00
    phi[5,6]  R2581     1.4210131168365479e+00
    phi[5,6]  R2582     -9.2495054006576538e-01
    phi[5,6]  R2583     -1.0616614818572998e+00
    phi[5,6]  R2584     -1.7967464029788971e-01
    phi[5,6]  R2585     2.1905419826507568e+00
    phi[5,6]  R2586     1.6220375299453735e+00
    phi[5,6]  R2587     -1.9336706399917603e-01
    phi[5,6]  R2588     1.1039793491363525e+00
    phi[5,6]  R2589     2.6076083183288574e+00
    phi[5,6]  R2590     6.8630856275558472e-01
    phi[5,6]  R2591     2.1156513690948486e+00
    phi[5,6]  R2592     1.4403879642486572e+00
    phi[5,6]  R2593     1.9452199935913086e+00
    phi[5,6]  R2594     1.8707634508609772e-01
    phi[5,6]  R2595     9.6376115083694458e-01
    phi[5,6]  R2596     1.2372753620147705e+00
    phi[5,6]  R2597     1.5879375934600830e+00
    phi[5,6]  R2598     1.2061446905136108e+00
    phi[5,6]  R2599     -4.9308747053146362e-01
    phi[5,6]  R2600     -3.1541643142700195e+00
    phi[5,6]  R2601     -1.2181717157363892e+00
    phi[5,6]  R2602     -6.5937983989715576e-01
    phi[5,6]  R2603     -2.4126670360565186e+00
    phi[5,6]  R2604     7.0902451872825623e-02
    phi[5,6]  R2605     -4.1423029899597168e+00
    phi[5,6]  R2606     -3.1070941686630249e-01
    phi[5,6]  R2607     -1.9834290742874146e+00
    phi[5,6]  R2608     -1.1414165496826172e+00
    phi[5,6]  R2609     -1.6809436082839966e+00
    phi[5,6]  R2610     6.7658799886703491e-01
    phi[5,6]  R2611     3.9080739021301270e-02
    phi[5,6]  R2612     -3.2035019397735596e+00
    phi[5,6]  R2613     -2.5811049938201904e+00
    phi[5,6]  R2614     -1.6233938932418823e+00
    phi[5,6]  R2615     -1.0524587631225586e+00
    phi[5,6]  R2616     -1.4967588186264038e+00
    phi[5,6]  R2617     -2.1295061111450195e+00
    phi[5,6]  R2618     4.0459814667701721e-01
    phi[5,6]  R2619     -1.4126646518707275e-01
    phi[5,6]  R2620     -1.4084001779556274e+00
    phi[5,6]  R2621     6.4347761869430542e-01
    phi[5,6]  R2622     -1.1718202829360962e+00
    phi[5,6]  R2623     -2.3882064819335938e+00
    phi[5,6]  R2624     -1.5724831819534302e+00
    phi[5,6]  R2625     -1.1874619722366333e+00
    phi[5,6]  R2626     -3.3879095315933228e-01
    phi[5,6]  R2627     -1.1181638240814209e+00
    phi[5,6]  R2628     -3.6107069253921509e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2629     -3.0999999046325684e+00
    phi[6,5]  R2630     -3.0999999046325684e+00
    phi[6,5]  R2631     -2.2400000095367432e+00
    phi[6,5]  R2632     -2.2400000095367432e+00
    phi[6,5]  R2633     -3.0999999046325684e+00
    phi[6,5]  R2634     -3.0999999046325684e+00
    phi[6,5]  R2635     -2.5699999332427979e+00
    phi[6,5]  R2636     -2.5699999332427979e+00
    phi[6,5]  R2637     -3.0999999046325684e+00
    phi[6,5]  R2638     -3.0999999046325684e+00
    phi[6,5]  R2639     -2.0899999141693115e+00
    phi[6,5]  R2640     -2.0899999141693115e+00
    phi[6,5]  R2641     -3.0999999046325684e+00
    phi[6,5]  R2642     -3.0999999046325684e+00
    phi[6,5]  R2643     2.6076083183288574e+00
    phi[6,5]  R2644     6.8630856275558472e-01
    phi[6,5]  R2645     2.1156513690948486e+00
    phi[6,5]  R2646     1.4403879642486572e+00
    phi[6,5]  R2647     1.9452199935913086e+00
    phi[6,5]  R2648     1.8707634508609772e-01
    phi[6,5]  R2649     9.6376115083694458e-01
    phi[6,5]  R2650     1.2372753620147705e+00
    phi[6,5]  R2651     1.5879375934600830e+00
    phi[6,5]  R2652     1.2061446905136108e+00
    phi[6,5]  R2653     -4.9308747053146362e-01
    phi[6,5]  R2654     -3.1541643142700195e+00
    phi[6,5]  R2655     -1.2181717157363892e+00
    phi[6,5]  R2656     -6.5937983989715576e-01
    phi[6,5]  R2657     -2.4126670360565186e+00
    phi[6,5]  R2658     7.0902451872825623e-02
    phi[6,5]  R2659     -4.1423029899597168e+00
    phi[6,5]  R2660     -3.1070941686630249e-01
    phi[6,5]  R2661     -1.9834290742874146e+00
    phi[6,5]  R2662     -1.1414165496826172e+00
    phi[6,5]  R2663     -1.6809436082839966e+00
    phi[6,5]  R2664     6.7658799886703491e-01
    phi[6,5]  R2665     3.9080739021301270e-02
    phi[6,5]  R2666     -3.2035019397735596e+00
    phi[6,5]  R2667     -2.5811049938201904e+00
    phi[6,5]  R2668     -1.6233938932418823e+00
    phi[6,5]  R2669     -1.0524587631225586e+00
    phi[6,5]  R2670     -1.4967588186264038e+00
    phi[6,5]  R2671     -2.1295061111450195e+00
    phi[6,5]  R2672     4.0459814667701721e-01
    phi[6,5]  R2673     -1.4126646518707275e-01
    phi[6,5]  R2674     -1.4084001779556274e+00
    phi[6,5]  R2675     6.4347761869430542e-01
    phi[6,5]  R2676     -1.1718202829360962e+00
    phi[6,5]  R2677     -2.3882064819335938e+00
    phi[6,5]  R2678     -1.5724831819534302e+00
    phi[6,5]  R2679     -1.1874619722366333e+00
    phi[6,5]  R2680     -3.3879095315933228e-01
    phi[6,5]  R2681     -1.1181638240814209e+00
    phi[6,5]  R2682     -3.6107069253921509e-01
    phi[6,5]  R2683     1.8164458274841309e+00
    phi[6,5]  R2684     1.8318803310394287e+00
    phi[6,5]  R2685     2.6805303096771240e+00
    phi[6,5]  R2686     3.1378457546234131e+00
    phi[6,5]  R2687     1.6333773136138916e+00
    phi[6,5]  R2688     3.1371634006500244e+00
    phi[6,5]  R2689     2.1908650398254395e+00
    phi[6,5]  R2690     1.8168040513992310e+00
    phi[6,5]  R2691     2.7592725753784180e+00
    phi[6,5]  R2692     3.3667798042297363e+00
    phi[6,5]  R2693     -2.9324169158935547e+00
    phi[6,5]  R2694     -0.565557062625885
    phi[6,5]  R2695     6.4368438720703125e-01
    phi[6,5]  R2696     7.4732547998428345e-01
    phi[6,5]  R2697     -2.5832197666168213e+00
    phi[6,5]  R2698     1.3125869035720825e+00
    phi[6,5]  R2699     -2.6062109470367432e+00
    phi[6,5]  R2700     0.457389771938324
    phi[6,5]  R2701     -2.7732777595520020e+00
    phi[6,5]  R2702     -2.9012253284454346e+00
    phi[6,5]  R2703     -1.4401623010635376e+00
    phi[6,5]  R2704     -1.9682992696762085e+00
    phi[6,5]  R2705     -2.0095534324645996e+00
    phi[6,5]  R2706     -1.4318299293518066e+00
    phi[6,5]  R2707     -1.8964453935623169e+00
    phi[6,5]  R2708     2.8923410922288895e-02
    phi[6,5]  R2709     2.4327416718006134e-01
    phi[6,5]  R2710     -1.5997023582458496e+00
    phi[6,5]  R2711     -3.2220003008842468e-01
    phi[6,5]  R2712     -1.6942701339721680e+00
    phi[6,5]  R2713     1.0142395645380020e-01
    phi[6,5]  R2714     1.3020439147949219e+00
    phi[6,5]  R2715     1.4210131168365479e+00
    phi[6,5]  R2716     -9.2495054006576538e-01
    phi[6,5]  R2717     -1.0616614818572998e+00
    phi[6,5]  R2718     -1.7967464029788971e-01
    phi[6,5]  R2719     2.1905419826507568e+00
    phi[6,5]  R2720     1.6220375299453735e+00
    phi[6,5]  R2721     -1.9336706399917603e-01
    phi[6,5]  R2722     1.1039793491363525e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2723     -3.0999999046325684e+00
    phi[6,7]  R2724     -3.0999999046325684e+00
    phi[6,7]  R2725     -2.2400000095367432e+00
    phi[6,7]  R2726     -2.2400000095367432e+00
    phi[6,7]  R2727     -3.0999999046325684e+00
    phi[6,7]  R2728     -3.0999999046325684e+00
    phi[6,7]  R2729     -2.5699999332427979e+00
    phi[6,7]  R2730     -2.5699999332427979e+00
    phi[6,7]  R2731     -3.0999999046325684e+00
    phi[6,7]  R2732     -3.0999999046325684e+00
    phi[6,7]  R2733     -2.0899999141693115e+00
    phi[6,7]  R2734     -2.0899999141693115e+00
    phi[6,7]  R2735     -3.0999999046325684e+00
    phi[6,7]  R2736     -3.0999999046325684e+00
    phi[6,7]  R2737     2.6076083183288574e+00
    phi[6,7]  R2738     6.8630856275558472e-01
    phi[6,7]  R2739     2.1156513690948486e+00
    phi[6,7]  R2740     1.4403879642486572e+00
    phi[6,7]  R2741     1.9452199935913086e+00
    phi[6,7]  R2742     1.8707634508609772e-01
    phi[6,7]  R2743     9.6376115083694458e-01
    phi[6,7]  R2744     1.2372753620147705e+00
    phi[6,7]  R2745     1.5879375934600830e+00
    phi[6,7]  R2746     1.2061446905136108e+00
    phi[6,7]  R2747     -4.9308747053146362e-01
    phi[6,7]  R2748     -3.1541643142700195e+00
    phi[6,7]  R2749     -1.2181717157363892e+00
    phi[6,7]  R2750     -6.5937983989715576e-01
    phi[6,7]  R2751     -2.4126670360565186e+00
    phi[6,7]  R2752     7.0902451872825623e-02
    phi[6,7]  R2753     -4.1423029899597168e+00
    phi[6,7]  R2754     -3.1070941686630249e-01
    phi[6,7]  R2755     -1.9834290742874146e+00
    phi[6,7]  R2756     -1.1414165496826172e+00
    phi[6,7]  R2757     -1.6809436082839966e+00
    phi[6,7]  R2758     6.7658799886703491e-01
    phi[6,7]  R2759     3.9080739021301270e-02
    phi[6,7]  R2760     -3.2035019397735596e+00
    phi[6,7]  R2761     -2.5811049938201904e+00
    phi[6,7]  R2762     -1.6233938932418823e+00
    phi[6,7]  R2763     -1.0524587631225586e+00
    phi[6,7]  R2764     -1.4967588186264038e+00
    phi[6,7]  R2765     -2.1295061111450195e+00
    phi[6,7]  R2766     4.0459814667701721e-01
    phi[6,7]  R2767     -1.4126646518707275e-01
    phi[6,7]  R2768     -1.4084001779556274e+00
    phi[6,7]  R2769     6.4347761869430542e-01
    phi[6,7]  R2770     -1.1718202829360962e+00
    phi[6,7]  R2771     -2.3882064819335938e+00
    phi[6,7]  R2772     -1.5724831819534302e+00
    phi[6,7]  R2773     -1.1874619722366333e+00
    phi[6,7]  R2774     -3.3879095315933228e-01
    phi[6,7]  R2775     -1.1181638240814209e+00
    phi[6,7]  R2776     -3.6107069253921509e-01
    phi[6,7]  R2777     9.9413096904754639e-02
    phi[6,7]  R2778     -1.7032012343406677e-01
    phi[6,7]  R2779     1.9676467403769493e-02
    phi[6,7]  R2780     2.3302994668483734e-01
    phi[6,7]  R2781     -2.2324560582637787e-01
    phi[6,7]  R2782     4.8189321160316467e-01
    phi[6,7]  R2783     -3.7492558360099792e-01
    phi[6,7]  R2784     8.4481149911880493e-01
    phi[6,7]  R2785     0.840761661529541
    phi[6,7]  R2786     -1.2594033479690552e+00
    phi[6,7]  R2787     5.2686792612075806e-01
    phi[6,7]  R2788     1.1709102988243103e-01
    phi[6,7]  R2789     2.5978749617934227e-02
    phi[6,7]  R2790     -2.3088788986206055e-01
    phi[6,7]  R2791     -5.9526139497756958e-01
    phi[6,7]  R2792     6.4458596706390381e-01
    phi[6,7]  R2793     -5.9742921590805054e-01
    phi[6,7]  R2794     0.427736759185791
    phi[6,7]  R2795     -1.2762162685394287e+00
    phi[6,7]  R2796     -1.0009621381759644e+00
    phi[6,7]  R2797     -1.6633864641189575e+00
    phi[6,7]  R2798     -1.5523450374603271e+00
    phi[6,7]  R2799     -7.3273056745529175e-01
    phi[6,7]  R2800     -4.1974949836730957e-01
    phi[6,7]  R2801     -7.2979968786239624e-01
    phi[6,7]  R2802     -1.5292568206787109e+00
    phi[6,7]  R2803     -1.7716504335403442e+00
    phi[6,7]  R2804     -1.5031944513320923e+00
    phi[6,7]  R2805     -7.7915364503860474e-01
    phi[6,7]  R2806     -1.1290464401245117e+00
    phi[6,7]  R2807     -2.6159355640411377e+00
    phi[6,7]  R2808     -5.9536463022232056e-01
    phi[6,7]  R2809     -1.4354993104934692e+00
    phi[6,7]  R2810     -2.5630605220794678e+00
    phi[6,7]  R2811     5.4828107357025146e-01
    phi[6,7]  R2812     -4.1488805413246155e-01
    phi[6,7]  R2813     -8.3401310443878174e-01
    phi[6,7]  R2814     -5.0063955783843994e-01
    phi[6,7]  R2815     -3.5572871565818787e-01
    phi[6,7]  R2816     1.1481480598449707e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2817     -3.0999999046325684e+00
    phi[7,6]  R2818     -3.0999999046325684e+00
    phi[7,6]  R2819     -2.2400000095367432e+00
    phi[7,6]  R2820     -2.2400000095367432e+00
    phi[7,6]  R2821     -3.0999999046325684e+00
    phi[7,6]  R2822     -3.0999999046325684e+00
    phi[7,6]  R2823     -2.5699999332427979e+00
    phi[7,6]  R2824     -2.5699999332427979e+00
    phi[7,6]  R2825     -3.0999999046325684e+00
    phi[7,6]  R2826     -3.0999999046325684e+00
    phi[7,6]  R2827     -2.0899999141693115e+00
    phi[7,6]  R2828     -2.0899999141693115e+00
    phi[7,6]  R2829     -3.0999999046325684e+00
    phi[7,6]  R2830     -3.0999999046325684e+00
    phi[7,6]  R2831     9.9413096904754639e-02
    phi[7,6]  R2832     -1.7032012343406677e-01
    phi[7,6]  R2833     1.9676467403769493e-02
    phi[7,6]  R2834     2.3302994668483734e-01
    phi[7,6]  R2835     -2.2324560582637787e-01
    phi[7,6]  R2836     4.8189321160316467e-01
    phi[7,6]  R2837     -3.7492558360099792e-01
    phi[7,6]  R2838     8.4481149911880493e-01
    phi[7,6]  R2839     0.840761661529541
    phi[7,6]  R2840     -1.2594033479690552e+00
    phi[7,6]  R2841     5.2686792612075806e-01
    phi[7,6]  R2842     1.1709102988243103e-01
    phi[7,6]  R2843     2.5978749617934227e-02
    phi[7,6]  R2844     -2.3088788986206055e-01
    phi[7,6]  R2845     -5.9526139497756958e-01
    phi[7,6]  R2846     6.4458596706390381e-01
    phi[7,6]  R2847     -5.9742921590805054e-01
    phi[7,6]  R2848     0.427736759185791
    phi[7,6]  R2849     -1.2762162685394287e+00
    phi[7,6]  R2850     -1.0009621381759644e+00
    phi[7,6]  R2851     -1.6633864641189575e+00
    phi[7,6]  R2852     -1.5523450374603271e+00
    phi[7,6]  R2853     -7.3273056745529175e-01
    phi[7,6]  R2854     -4.1974949836730957e-01
    phi[7,6]  R2855     -7.2979968786239624e-01
    phi[7,6]  R2856     -1.5292568206787109e+00
    phi[7,6]  R2857     -1.7716504335403442e+00
    phi[7,6]  R2858     -1.5031944513320923e+00
    phi[7,6]  R2859     -7.7915364503860474e-01
    phi[7,6]  R2860     -1.1290464401245117e+00
    phi[7,6]  R2861     -2.6159355640411377e+00
    phi[7,6]  R2862     -5.9536463022232056e-01
    phi[7,6]  R2863     -1.4354993104934692e+00
    phi[7,6]  R2864     -2.5630605220794678e+00
    phi[7,6]  R2865     5.4828107357025146e-01
    phi[7,6]  R2866     -4.1488805413246155e-01
    phi[7,6]  R2867     -8.3401310443878174e-01
    phi[7,6]  R2868     -5.0063955783843994e-01
    phi[7,6]  R2869     -3.5572871565818787e-01
    phi[7,6]  R2870     1.1481480598449707e+00
    phi[7,6]  R2871     2.6076083183288574e+00
    phi[7,6]  R2872     6.8630856275558472e-01
    phi[7,6]  R2873     2.1156513690948486e+00
    phi[7,6]  R2874     1.4403879642486572e+00
    phi[7,6]  R2875     1.9452199935913086e+00
    phi[7,6]  R2876     1.8707634508609772e-01
    phi[7,6]  R2877     9.6376115083694458e-01
    phi[7,6]  R2878     1.2372753620147705e+00
    phi[7,6]  R2879     1.5879375934600830e+00
    phi[7,6]  R2880     1.2061446905136108e+00
    phi[7,6]  R2881     -4.9308747053146362e-01
    phi[7,6]  R2882     -3.1541643142700195e+00
    phi[7,6]  R2883     -1.2181717157363892e+00
    phi[7,6]  R2884     -6.5937983989715576e-01
    phi[7,6]  R2885     -2.4126670360565186e+00
    phi[7,6]  R2886     7.0902451872825623e-02
    phi[7,6]  R2887     -4.1423029899597168e+00
    phi[7,6]  R2888     -3.1070941686630249e-01
    phi[7,6]  R2889     -1.9834290742874146e+00
    phi[7,6]  R2890     -1.1414165496826172e+00
    phi[7,6]  R2891     -1.6809436082839966e+00
    phi[7,6]  R2892     6.7658799886703491e-01
    phi[7,6]  R2893     3.9080739021301270e-02
    phi[7,6]  R2894     -3.2035019397735596e+00
    phi[7,6]  R2895     -2.5811049938201904e+00
    phi[7,6]  R2896     -1.6233938932418823e+00
    phi[7,6]  R2897     -1.0524587631225586e+00
    phi[7,6]  R2898     -1.4967588186264038e+00
    phi[7,6]  R2899     -2.1295061111450195e+00
    phi[7,6]  R2900     4.0459814667701721e-01
    phi[7,6]  R2901     -1.4126646518707275e-01
    phi[7,6]  R2902     -1.4084001779556274e+00
    phi[7,6]  R2903     6.4347761869430542e-01
    phi[7,6]  R2904     -1.1718202829360962e+00
    phi[7,6]  R2905     -2.3882064819335938e+00
    phi[7,6]  R2906     -1.5724831819534302e+00
    phi[7,6]  R2907     -1.1874619722366333e+00
    phi[7,6]  R2908     -3.3879095315933228e-01
    phi[7,6]  R2909     -1.1181638240814209e+00
    phi[7,6]  R2910     -3.6107069253921509e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       -3.4287452697753906e-01
    z[0,1,0]  R89       -4.0462991595268250e-01
    z[0,1,0]  R90       3.7694208323955536e-02
    z[0,1,0]  R91       -2.1607734262943268e-01
    z[0,1,0]  R92       7.0514534600079060e-03
    z[0,1,0]  R93       -9.2090949416160583e-02
    z[0,1,0]  R94       -3.0757073312997818e-02
    z[0,1,0]  R95       -4.2781847715377808e-01
    z[0,1,0]  R96       1.9809107482433319e-01
    z[0,1,0]  R97       -0.52741938829422
    z[0,1,0]  R98       5.3257548809051514e-01
    z[0,1,0]  R99       -4.4982209801673889e-01
    z[0,1,0]  R100      -6.2833124399185181e-01
    z[0,1,0]  R101      6.3420593738555908e-01
    z[0,1,0]  R102      4.4936975836753845e-01
    z[0,1,0]  R103      3.0873997602611780e-03
    z[0,1,0]  R104      7.9878136515617371e-02
    z[0,1,0]  R105      -4.8687633126974106e-02
    z[0,1,0]  R106      -1.1559718102216721e-01
    z[0,1,0]  R107      -8.0589324235916138e-01
    z[0,1,0]  R108      -3.6386001110076904e-01
    z[0,1,0]  R109      -1.4979280531406403e-01
    z[0,1,0]  R110      -0.760092556476593
    z[0,1,0]  R111      1.8498468399047852e-01
    z[0,1,0]  R112      -5.6739991903305054e-01
    z[0,1,0]  R113      5.0882941484451294e-01
    z[0,1,0]  R114      2.8322085738182068e-01
    z[0,1,0]  R115      -3.1851518154144287e-01
    z[0,1,0]  R116      -2.6721498370170593e-01
    z[0,1,0]  R117      1.4682796597480774e-01
    z[0,1,0]  R118      -1.9448599219322205e-01
    z[0,1,0]  R119      -7.6547443866729736e-01
    z[0,1,0]  R120      -7.8703552484512329e-01
    z[0,1,0]  R121      -7.6065880060195923e-01
    z[0,1,0]  R122      -6.8503272533416748e-01
    z[0,1,0]  R123      -6.9114369153976440e-01
    z[0,1,0]  R124      -6.5381234884262085e-01
    z[0,1,0]  R125      -9.3975865840911865e-01
    z[0,1,0]  R126      -8.9000082015991211e-01
    z[0,1,0]  R127      1.1959818750619888e-01
    z[0,1,0]  R128      -2.8266675770282745e-02
    z[0,1,0]  R129      -3.5147402435541153e-02
    z[0,1,0]  R130      -5.2857872098684311e-02
    z[0,1,0]  R131      2.5732627511024475e-01
    z[0,1,0]  R132      3.3204281330108643e-01
    z[0,1,0]  R133      0.0271154772490263
    z[0,1,0]  R134      2.2598467767238617e-01
    z[0,1,0]  R135      -2.0111760124564171e-02
    z[0,1,0]  R136      4.0740448981523514e-02
    z[0,1,0]  R137      -9.2747874557971954e-02
    z[0,1,0]  R138      -2.0706218481063843e-01
    z[0,1,0]  R139      -1.4613938517868519e-02
    z[0,1,0]  R140      -2.3697561025619507e-01
    z[0,1,0]  R141      4.6550330519676208e-01
    z[0,1,0]  R142      3.2529163360595703e-01
    z[0,1,0]  R143      1.3015180826187134e-01
    z[0,1,0]  R144      2.8493487834930420e-01
    z[0,1,0]  R145      3.9687082171440125e-02
    z[0,1,0]  R146      -2.0952665805816650e-01
    z[0,1,0]  R147      -1.8916824460029602e-01
    z[0,1,0]  R148      -2.1669808030128479e-01
    z[0,1,0]  R149      -4.5104026794433594e-02
    z[0,1,0]  R150      3.3271864056587219e-02
    z[0,1,0]  R151      -3.1536030769348145e-01
    z[0,1,0]  R152      -2.4552899599075317e-01
    z[0,1,0]  R153      2.7699765563011169e-01
    z[0,1,0]  R154      2.2148096561431885e-01
    z[0,1,0]  R155      -9.6354849636554718e-02
    z[0,1,0]  R156      -9.6015587449073792e-02
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       -2.1722352504730225e-01
    z[0,1,1]  R89       -3.3881747722625732e-01
    z[0,1,1]  R90       -3.5317912697792053e-01
    z[0,1,1]  R91       -1.1785881221294403e-01
    z[0,1,1]  R92       1.5025387704372406e-01
    z[0,1,1]  R93       -1.1684845387935638e-01
    z[0,1,1]  R94       -1.2291974574327469e-01
    z[0,1,1]  R95       7.0135104656219482e-01
    z[0,1,1]  R96       3.1342241168022156e-01
    z[0,1,1]  R97       -3.4877327084541321e-01
    z[0,1,1]  R98       -6.9436973333358765e-01
    z[0,1,1]  R99       -6.0412913560867310e-01
    z[0,1,1]  R100      1.9119927287101746e-01
    z[0,1,1]  R101      5.9598058462142944e-01
    z[0,1,1]  R102      4.9876987934112549e-01
    z[0,1,1]  R103      3.9404088258743286e-01
    z[0,1,1]  R104      4.5466876029968262e-01
    z[0,1,1]  R105      -3.1880775094032288e-01
    z[0,1,1]  R106      -2.8397932648658752e-01
    z[0,1,1]  R107      2.0254749059677124e-01
    z[0,1,1]  R108      4.8817163705825806e-01
    z[0,1,1]  R109      -1.1145620793104172e-01
    z[0,1,1]  R110      1.0701826214790344e-01
    z[0,1,1]  R111      6.8404936790466309e-01
    z[0,1,1]  R112      -5.0725072622299194e-01
    z[0,1,1]  R113      5.4800343513488770e-01
    z[0,1,1]  R114      6.8713134527206421e-01
    z[0,1,1]  R115      -0.327234148979187
    z[0,1,1]  R116      -2.9164829850196838e-01
    z[0,1,1]  R117      9.7079819440841675e-01
    z[0,1,1]  R118      6.4031040668487549e-01
    z[0,1,1]  R119      -0.138684943318367
    z[0,1,1]  R120      -1.3560040295124054e-01
    z[0,1,1]  R121      -5.1290322095155716e-02
    z[0,1,1]  R122      -0.0711161345243454
    z[0,1,1]  R123      1.1851778626441956e-01
    z[0,1,1]  R124      1.6843172907829285e-01
    z[0,1,1]  R125      9.2258296906948090e-02
    z[0,1,1]  R126      -1.0521542280912399e-01
    z[0,1,1]  R127      1.1808297038078308e-01
    z[0,1,1]  R128      -1.7224618792533875e-01
    z[0,1,1]  R129      -2.3573809862136841e-01
    z[0,1,1]  R130      -1.2717759609222412e-01
    z[0,1,1]  R131      -3.2212957739830017e-01
    z[0,1,1]  R132      -2.7359953522682190e-01
    z[0,1,1]  R133      -2.7333667874336243e-01
    z[0,1,1]  R134      -4.5951792597770691e-01
    z[0,1,1]  R135      -4.3252980709075928e-01
    z[0,1,1]  R136      -1.1579956859350204e-01
    z[0,1,1]  R137      -9.5399028062820435e-01
    z[0,1,1]  R138      -7.8108400106430054e-01
    z[0,1,1]  R139      -8.0746436119079590e-01
    z[0,1,1]  R140      -7.8210854530334473e-01
    z[0,1,1]  R141      -7.1410173177719116e-01
    z[0,1,1]  R142      -7.8637742996215820e-01
    z[0,1,1]  R143      -7.4421435594558716e-01
    z[0,1,1]  R144      -0.700564444065094
    z[0,1,1]  R145      -6.8744331598281860e-01
    z[0,1,1]  R146      -7.0553278923034668e-01
    z[0,1,1]  R147      5.8930778503417969e-01
    z[0,1,1]  R148      5.5380409955978394e-01
    z[0,1,1]  R149      -7.1062213182449341e-01
    z[0,1,1]  R150      7.0085096359252930e-01
    z[0,1,1]  R151      -6.4749735593795776e-01
    z[0,1,1]  R152      -5.9957367181777954e-01
    z[0,1,1]  R153      5.0419336557388306e-01
    z[0,1,1]  R154      0.506360650062561
    z[0,1,1]  R155      5.4126524925231934e-01
    z[0,1,1]  R156      -3.6219015717506409e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       1.4503470063209534e-01
    z[0,1,2]  R89       -6.9570106267929077e-01
    z[0,1,2]  R90       -4.1466781497001648e-01
    z[0,1,2]  R91       -4.6698024868965149e-01
    z[0,1,2]  R92       -3.9024350047111511e-01
    z[0,1,2]  R93       6.9275557994842529e-02
    z[0,1,2]  R94       2.3258070647716522e-01
    z[0,1,2]  R95       1.1849571019411087e-02
    z[0,1,2]  R96       3.8501378148794174e-02
    z[0,1,2]  R97       4.6703982353210449e-01
    z[0,1,2]  R98       -1.9645893573760986e-01
    z[0,1,2]  R99       -1.5505827963352203e-01
    z[0,1,2]  R100      2.2549276053905487e-01
    z[0,1,2]  R101      -1.1909014731645584e-01
    z[0,1,2]  R102      1.3621711730957031e-01
    z[0,1,2]  R103      3.0358494259417057e-03
    z[0,1,2]  R104      5.9022486209869385e-01
    z[0,1,2]  R105      -1.7114135622978210e-01
    z[0,1,2]  R106      -1.5432457625865936e-01
    z[0,1,2]  R107      -1.3052079081535339e-01
    z[0,1,2]  R108      -4.7506070137023926e-01
    z[0,1,2]  R109      -5.8543598651885986e-01
    z[0,1,2]  R110      9.7700776532292366e-03
    z[0,1,2]  R111      -9.1965541243553162e-02
    z[0,1,2]  R112      5.2086919546127319e-02
    z[0,1,2]  R113      -2.5898671150207520e-01
    z[0,1,2]  R114      3.7725397944450378e-01
    z[0,1,2]  R115      2.9562157392501831e-01
    z[0,1,2]  R116      -3.5007035732269287e-01
    z[0,1,2]  R117      -2.8458578512072563e-02
    z[0,1,2]  R118      9.8333068192005157e-02
    z[0,1,2]  R119      1.6744644939899445e-01
    z[0,1,2]  R120      -3.2325658202171326e-01
    z[0,1,2]  R121      9.7997933626174927e-02
    z[0,1,2]  R122      -5.4415683262050152e-03
    z[0,1,2]  R123      -0.257853627204895
    z[0,1,2]  R124      -3.0794674158096313e-01
    z[0,1,2]  R125      -2.4678991734981537e-01
    z[0,1,2]  R126      2.6114261150360107e-01
    z[0,1,2]  R127      0.527817964553833
    z[0,1,2]  R128      -4.0941774845123291e-01
    z[0,1,2]  R129      -4.9897426366806030e-01
    z[0,1,2]  R130      -7.5336736440658569e-01
    z[0,1,2]  R131      -4.1837871074676514e-01
    z[0,1,2]  R132      -6.3643521070480347e-01
    z[0,1,2]  R133      -3.6294567584991455e-01
    z[0,1,2]  R134      -6.7835921049118042e-01
    z[0,1,2]  R135      -2.8625974059104919e-01
    z[0,1,2]  R136      -0.603752076625824
    z[0,1,2]  R137      6.9415479898452759e-02
    z[0,1,2]  R138      -2.3059016466140747e-01
    z[0,1,2]  R139      3.4395694732666016e-01
    z[0,1,2]  R140      3.1662932038307190e-01
    z[0,1,2]  R141      -1.4114160835742950e-01
    z[0,1,2]  R142      -6.4147412776947021e-02
    z[0,1,2]  R143      -4.0544936060905457e-01
    z[0,1,2]  R144      7.3663949966430664e-02
    z[0,1,2]  R145      2.8105584904551506e-02
    z[0,1,2]  R146      4.0016758441925049e-01
    z[0,1,2]  R147      0.273367315530777
    z[0,1,2]  R148      7.4711114168167114e-01
    z[0,1,2]  R149      -4.7318261861801147e-01
    z[0,1,2]  R150      2.1705015003681183e-01
    z[0,1,2]  R151      3.5083245486021042e-02
    z[0,1,2]  R152      2.7878111600875854e-01
    z[0,1,2]  R153      2.4471163749694824e-01
    z[0,1,2]  R154      -1.4625380933284760e-01
    z[0,1,2]  R155      1.8711602687835693e-01
    z[0,1,2]  R156      -2.6298427581787109e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       5.2300405502319336e-01
    z[0,1,3]  R89       -1.0115691274404526e-01
    z[0,1,3]  R90       4.6715912222862244e-01
    z[0,1,3]  R91       -1.5212836861610413e-01
    z[0,1,3]  R92       -0.165887251496315
    z[0,1,3]  R93       3.8981422781944275e-01
    z[0,1,3]  R94       2.3801697790622711e-01
    z[0,1,3]  R95       -4.4040897488594055e-01
    z[0,1,3]  R96       -2.2600656747817993e-01
    z[0,1,3]  R97       4.4847515225410461e-01
    z[0,1,3]  R98       3.3983027935028076e-01
    z[0,1,3]  R99       -1.5335313975811005e-01
    z[0,1,3]  R100      7.5554080307483673e-02
    z[0,1,3]  R101      -1.5334862470626831e-01
    z[0,1,3]  R102      -1.7881637811660767e-01
    z[0,1,3]  R103      8.0032050609588623e-01
    z[0,1,3]  R104      2.5405695661902428e-02
    z[0,1,3]  R105      -4.0245819091796875e-01
    z[0,1,3]  R106      -0.374159038066864
    z[0,1,3]  R107      -5.9671744704246521e-02
    z[0,1,3]  R108      5.9326660633087158e-01
    z[0,1,3]  R109      0.532675564289093
    z[0,1,3]  R110      2.8765746951103210e-01
    z[0,1,3]  R111      -3.7605494260787964e-01
    z[0,1,3]  R112      2.7694469690322876e-01
    z[0,1,3]  R113      -4.3913671374320984e-01
    z[0,1,3]  R114      -1.7861096560955048e-01
    z[0,1,3]  R115      3.9464709162712097e-01
    z[0,1,3]  R116      3.3547837287187576e-02
    z[0,1,3]  R117      -1.0652960836887360e-01
    z[0,1,3]  R118      -3.7224423885345459e-01
    z[0,1,3]  R119      5.8253329992294312e-01
    z[0,1,3]  R120      4.3245518207550049e-01
    z[0,1,3]  R121      4.9656990170478821e-01
    z[0,1,3]  R122      5.7550114393234253e-01
    z[0,1,3]  R123      5.2948659658432007e-01
    z[0,1,3]  R124      6.5426230430603027e-01
    z[0,1,3]  R125      9.0064838528633118e-02
    z[0,1,3]  R126      1.2413965165615082e-01
    z[0,1,3]  R127      7.1115463972091675e-02
    z[0,1,3]  R128      6.2369710206985474e-01
    z[0,1,3]  R129      4.5309442281723022e-01
    z[0,1,3]  R130      3.4645467996597290e-01
    z[0,1,3]  R131      5.4036104679107666e-01
    z[0,1,3]  R132      2.8364226222038269e-01
    z[0,1,3]  R133      7.6607018709182739e-01
    z[0,1,3]  R134      0.468136727809906
    z[0,1,3]  R135      2.8573292493820190e-01
    z[0,1,3]  R136      1.3243648409843445e-01
    z[0,1,3]  R137      1.1205623298883438e-01
    z[0,1,3]  R138      3.3471721410751343e-01
    z[0,1,3]  R139      4.3947091698646545e-01
    z[0,1,3]  R140      3.9231842756271362e-01
    z[0,1,3]  R141      3.9689761400222778e-01
    z[0,1,3]  R142      -7.3697227053344250e-03
    z[0,1,3]  R143      -1.6436351463198662e-02
    z[0,1,3]  R144      -4.0541672706604004e-01
    z[0,1,3]  R145      -6.1854767799377441e-01
    z[0,1,3]  R146      -3.1052476167678833e-01
    z[0,1,3]  R147      -4.6811640262603760e-01
    z[0,1,3]  R148      -2.9047888517379761e-01
    z[0,1,3]  R149      -4.2592954635620117e-01
    z[0,1,3]  R150      -5.0239515304565430e-01
    z[0,1,3]  R151      1.1542630381882191e-02
    z[0,1,3]  R152      -3.5988822579383850e-01
    z[0,1,3]  R153      -5.7506734132766724e-01
    z[0,1,3]  R154      -6.6924935579299927e-01
    z[0,1,3]  R155      -3.9783358573913574e-01
    z[0,1,3]  R156      4.7208401560783386e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       7.8019194304943085e-02
    z[0,1,4]  R89       3.0334141850471497e-01
    z[0,1,4]  R90       -1.7769330739974976e-01
    z[0,1,4]  R91       -0.672885000705719
    z[0,1,4]  R92       -0.227244034409523
    z[0,1,4]  R93       -4.9227970838546753e-01
    z[0,1,4]  R94       -7.8103309869766235e-01
    z[0,1,4]  R95       -2.8709790110588074e-01
    z[0,1,4]  R96       -6.3240557909011841e-01
    z[0,1,4]  R97       1.2078670412302017e-01
    z[0,1,4]  R98       -4.0066551417112350e-02
    z[0,1,4]  R99       -1.0748336464166641e-01
    z[0,1,4]  R100      3.1558805704116821e-01
    z[0,1,4]  R101      4.1970506310462952e-01
    z[0,1,4]  R102      1.4935132116079330e-02
    z[0,1,4]  R103      -1.1886394768953323e-01
    z[0,1,4]  R104      4.9540087580680847e-01
    z[0,1,4]  R105      7.4773132801055908e-01
    z[0,1,4]  R106      5.3252893686294556e-01
    z[0,1,4]  R107      -2.0493234694004059e-01
    z[0,1,4]  R108      5.5696006864309311e-02
    z[0,1,4]  R109      -4.3959099054336548e-01
    z[0,1,4]  R110      -2.9392856359481812e-01
    z[0,1,4]  R111      1.6512106359004974e-01
    z[0,1,4]  R112      3.9310356974601746e-01
    z[0,1,4]  R113      -2.5381135940551758e-01
    z[0,1,4]  R114      2.4333505425602198e-03
    z[0,1,4]  R115      -4.3560588359832764e-01
    z[0,1,4]  R116      3.8866540789604187e-01
    z[0,1,4]  R117      -4.2701106518507004e-02
    z[0,1,4]  R118      -1.0903651267290115e-01
    z[0,1,4]  R119      -3.8109406828880310e-02
    z[0,1,4]  R120      -2.6365658640861511e-01
    z[0,1,4]  R121      -1.0086496174335480e-01
    z[0,1,4]  R122      -4.2758235335350037e-01
    z[0,1,4]  R123      -0.0987108051776886
    z[0,1,4]  R124      -1.8443804234266281e-02
    z[0,1,4]  R125      -8.4633342921733856e-02
    z[0,1,4]  R126      -1.1293911933898926e-01
    z[0,1,4]  R127      0.827197790145874
    z[0,1,4]  R128      -6.3351714611053467e-01
    z[0,1,4]  R129      -6.4652818441390991e-01
    z[0,1,4]  R130      -4.9971318244934082e-01
    z[0,1,4]  R131      -4.7033041715621948e-01
    z[0,1,4]  R132      -3.9395216107368469e-01
    z[0,1,4]  R133      -3.5066959261894226e-01
    z[0,1,4]  R134      -1.9051505625247955e-01
    z[0,1,4]  R135      -4.0630677342414856e-01
    z[0,1,4]  R136      -7.6303946971893311e-01
    z[0,1,4]  R137      3.2096426934003830e-02
    z[0,1,4]  R138      -1.1262485384941101e-01
    z[0,1,4]  R139      -1.1069152504205704e-02
    z[0,1,4]  R140      -8.4059886634349823e-02
    z[0,1,4]  R141      -0.0471460185945034
    z[0,1,4]  R142      -1.4118281193077564e-02
    z[0,1,4]  R143      4.1445949673652649e-01
    z[0,1,4]  R144      -5.0145995616912842e-01
    z[0,1,4]  R145      3.1634697318077087e-01
    z[0,1,4]  R146      3.2800965011119843e-02
    z[0,1,4]  R147      3.9694914221763611e-01
    z[0,1,4]  R148      -1.3578631915152073e-02
    z[0,1,4]  R149      -2.8430971503257751e-01
    z[0,1,4]  R150      -3.9041060209274292e-01
    z[0,1,4]  R151      4.7830536961555481e-01
    z[0,1,4]  R152      -2.0111978054046631e-01
    z[0,1,4]  R153      2.9851067066192627e-01
    z[0,1,4]  R154      -2.3639839142560959e-02
    z[0,1,4]  R155      -1.8404923379421234e-01
    z[0,1,4]  R156      -0.517731785774231
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       -4.4263872504234314e-01
    z[0,1,5]  R89       -3.2308492064476013e-01
    z[0,1,5]  R90       -6.4944040775299072e-01
    z[0,1,5]  R91       4.9100711476057768e-04
    z[0,1,5]  R92       -0.862942636013031
    z[0,1,5]  R93       5.4489824920892715e-02
    z[0,1,5]  R94       -0.509451687335968
    z[0,1,5]  R95       3.9412174373865128e-02
    z[0,1,5]  R96       -6.0844719409942627e-01
    z[0,1,5]  R97       0.385626882314682
    z[0,1,5]  R98       5.3227208554744720e-02
    z[0,1,5]  R99       1.0986543446779251e-01
    z[0,1,5]  R100      -8.7742723524570465e-02
    z[0,1,5]  R101      1.6445071995258331e-01
    z[0,1,5]  R102      3.7852725386619568e-01
    z[0,1,5]  R103      7.9666912555694580e-02
    z[0,1,5]  R104      -2.6526296138763428e-01
    z[0,1,5]  R105      -6.9492459297180176e-02
    z[0,1,5]  R106      -5.6996160745620728e-01
    z[0,1,5]  R107      -4.6937185525894165e-01
    z[0,1,5]  R108      -2.0916087925434113e-01
    z[0,1,5]  R109      -3.8129898905754089e-01
    z[0,1,5]  R110      4.6436417102813721e-01
    z[0,1,5]  R111      5.2960163354873657e-01
    z[0,1,5]  R112      1.3235104084014893e-01
    z[0,1,5]  R113      -1.4744228124618530e-01
    z[0,1,5]  R114      -4.2876243591308594e-01
    z[0,1,5]  R115      5.9810662269592285e-01
    z[0,1,5]  R116      -2.3030030727386475e-01
    z[0,1,5]  R117      -1.3769541680812836e-01
    z[0,1,5]  R118      -0.563877522945404
    z[0,1,5]  R119      8.5845552384853363e-03
    z[0,1,5]  R120      0.00700989319011569
    z[0,1,5]  R121      -5.6152928620576859e-02
    z[0,1,5]  R122      9.8681680858135223e-02
    z[0,1,5]  R123      -3.2476380467414856e-01
    z[0,1,5]  R124      7.6823040843009949e-02
    z[0,1,5]  R125      3.4556340426206589e-02
    z[0,1,5]  R126      -2.9272469878196716e-01
    z[0,1,5]  R127      -1.5474167652428150e-02
    z[0,1,5]  R128      1.0599581152200699e-01
    z[0,1,5]  R129      -2.5980386137962341e-01
    z[0,1,5]  R130      1.1180879175662994e-01
    z[0,1,5]  R131      0.0648990347981453
    z[0,1,5]  R132      2.8234541416168213e-01
    z[0,1,5]  R133      2.7899768948554993e-01
    z[0,1,5]  R134      1.2590293586254120e-01
    z[0,1,5]  R135      6.7350721359252930e-01
    z[0,1,5]  R136      9.8208189010620117e-02
    z[0,1,5]  R137      2.0516207814216614e-01
    z[0,1,5]  R138      -0.364769846200943
    z[0,1,5]  R139      8.3711095154285431e-02
    z[0,1,5]  R140      -2.5648900866508484e-01
    z[0,1,5]  R141      -2.9499495029449463e-01
    z[0,1,5]  R142      -1.0593015700578690e-01
    z[0,1,5]  R143      -2.6589006185531616e-01
    z[0,1,5]  R144      -7.9941317439079285e-02
    z[0,1,5]  R145      2.0427992939949036e-01
    z[0,1,5]  R146      1.9457958638668060e-01
    z[0,1,5]  R147      -7.8477680683135986e-02
    z[0,1,5]  R148      -1.4952444471418858e-02
    z[0,1,5]  R149      -7.9793877899646759e-02
    z[0,1,5]  R150      -0.0723300352692604
    z[0,1,5]  R151      2.5796961784362793e-01
    z[0,1,5]  R152      -5.6732857227325439e-01
    z[0,1,5]  R153      3.7883457541465759e-01
    z[0,1,5]  R154      4.5789572596549988e-01
    z[0,1,5]  R155      6.8522137403488159e-01
    z[0,1,5]  R156      5.4043656587600708e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       5.8195066452026367e-01
    z[0,1,6]  R89       1.7562672495841980e-01
    z[0,1,6]  R90       0.174094557762146
    z[0,1,6]  R91       4.9541077017784119e-01
    z[0,1,6]  R92       3.5434953868389130e-02
    z[0,1,6]  R93       7.5881689786911011e-01
    z[0,1,6]  R94       6.0374997556209564e-02
    z[0,1,6]  R95       2.1679243445396423e-01
    z[0,1,6]  R96       -0.199550062417984
    z[0,1,6]  R97       1.3278649747371674e-01
    z[0,1,6]  R98       -2.7512687444686890e-01
    z[0,1,6]  R99       -6.0125261545181274e-01
    z[0,1,6]  R100      -6.3623321056365967e-01
    z[0,1,6]  R101      4.1176278144121170e-02
    z[0,1,6]  R102      -5.9603631496429443e-01
    z[0,1,6]  R103      -4.2863118648529053e-01
    z[0,1,6]  R104      -3.4942615032196045e-01
    z[0,1,6]  R105      3.7523031234741211e-01
    z[0,1,6]  R106      3.6570286750793457e-01
    z[0,1,6]  R107      1.6311649978160858e-01
    z[0,1,6]  R108      6.9254361093044281e-02
    z[0,1,6]  R109      5.6397481821477413e-03
    z[0,1,6]  R110      -1.6104708611965179e-01
    z[0,1,6]  R111      -2.0059740543365479e-01
    z[0,1,6]  R112      4.1145539283752441e-01
    z[0,1,6]  R113      -3.0775046348571777e-01
    z[0,1,6]  R114      -2.9928398132324219e-01
    z[0,1,6]  R115      2.9043078422546387e-02
    z[0,1,6]  R116      7.1816682815551758e-01
    z[0,1,6]  R117      -5.5232111364603043e-02
    z[0,1,6]  R118      -2.7220547199249268e-01
    z[0,1,6]  R119      1.6095350682735443e-01
    z[0,1,6]  R120      -3.3334780484437943e-02
    z[0,1,6]  R121      -3.8633573055267334e-01
    z[0,1,6]  R122      -4.3321792036294937e-02
    z[0,1,6]  R123      2.1497417986392975e-01
    z[0,1,6]  R124      1.2258848547935486e-01
    z[0,1,6]  R125      -1.7597796022891998e-01
    z[0,1,6]  R126      -1.2156955152750015e-01
    z[0,1,6]  R127      -0.0600656233727932
    z[0,1,6]  R128      -1.8227970227599144e-02
    z[0,1,6]  R129      5.8530010282993317e-02
    z[0,1,6]  R130      -1.7670390009880066e-01
    z[0,1,6]  R131      3.7089386582374573e-01
    z[0,1,6]  R132      3.0736133456230164e-01
    z[0,1,6]  R133      7.1762762963771820e-02
    z[0,1,6]  R134      7.9394921660423279e-02
    z[0,1,6]  R135      1.7386290431022644e-01
    z[0,1,6]  R136      1.0488359630107880e-01
    z[0,1,6]  R137      1.4423468708992004e-01
    z[0,1,6]  R138      -1.8995878100395203e-01
    z[0,1,6]  R139      -1.7092873156070709e-01
    z[0,1,6]  R140      7.1612037718296051e-02
    z[0,1,6]  R141      -8.1680983304977417e-02
    z[0,1,6]  R142      5.1010406017303467e-01
    z[0,1,6]  R143      -1.4856582880020142e-01
    z[0,1,6]  R144      -1.9486727192997932e-02
    z[0,1,6]  R145      2.5488814339041710e-02
    z[0,1,6]  R146      -0.40351602435112
    z[0,1,6]  R147      -3.9917615056037903e-01
    z[0,1,6]  R148      5.8154135942459106e-02
    z[0,1,6]  R149      2.1559296175837517e-02
    z[0,1,6]  R150      2.2480469942092896e-01
    z[0,1,6]  R151      -4.2965874075889587e-01
    z[0,1,6]  R152      1.0333219915628433e-01
    z[0,1,6]  R153      2.1412852406501770e-01
    z[0,1,6]  R154      1.2260851263999939e-01
    z[0,1,6]  R155      3.2578937709331512e-02
    z[0,1,6]  R156      -8.6356140673160553e-02
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R157      -1
    z[1,0,0]  R158      1
    z[1,0,0]  R171      1.4682796597480774e-01
    z[1,0,0]  R172      -1.9448599219322205e-01
    z[1,0,0]  R173      -7.6547443866729736e-01
    z[1,0,0]  R174      -7.8703552484512329e-01
    z[1,0,0]  R175      -7.6065880060195923e-01
    z[1,0,0]  R176      -6.8503272533416748e-01
    z[1,0,0]  R177      -6.9114369153976440e-01
    z[1,0,0]  R178      -6.5381234884262085e-01
    z[1,0,0]  R179      -9.3975865840911865e-01
    z[1,0,0]  R180      -8.9000082015991211e-01
    z[1,0,0]  R181      1.1959818750619888e-01
    z[1,0,0]  R182      -2.8266675770282745e-02
    z[1,0,0]  R183      -3.5147402435541153e-02
    z[1,0,0]  R184      -5.2857872098684311e-02
    z[1,0,0]  R185      2.5732627511024475e-01
    z[1,0,0]  R186      3.3204281330108643e-01
    z[1,0,0]  R187      0.0271154772490263
    z[1,0,0]  R188      2.2598467767238617e-01
    z[1,0,0]  R189      -2.0111760124564171e-02
    z[1,0,0]  R190      4.0740448981523514e-02
    z[1,0,0]  R191      -9.2747874557971954e-02
    z[1,0,0]  R192      -2.0706218481063843e-01
    z[1,0,0]  R193      -1.4613938517868519e-02
    z[1,0,0]  R194      -2.3697561025619507e-01
    z[1,0,0]  R195      4.6550330519676208e-01
    z[1,0,0]  R196      3.2529163360595703e-01
    z[1,0,0]  R197      1.3015180826187134e-01
    z[1,0,0]  R198      2.8493487834930420e-01
    z[1,0,0]  R199      3.9687082171440125e-02
    z[1,0,0]  R200      -2.0952665805816650e-01
    z[1,0,0]  R201      -1.8916824460029602e-01
    z[1,0,0]  R202      -2.1669808030128479e-01
    z[1,0,0]  R203      -4.5104026794433594e-02
    z[1,0,0]  R204      3.3271864056587219e-02
    z[1,0,0]  R205      -3.1536030769348145e-01
    z[1,0,0]  R206      -2.4552899599075317e-01
    z[1,0,0]  R207      2.7699765563011169e-01
    z[1,0,0]  R208      2.2148096561431885e-01
    z[1,0,0]  R209      -9.6354849636554718e-02
    z[1,0,0]  R210      -9.6015587449073792e-02
    z[1,0,0]  R211      -3.4287452697753906e-01
    z[1,0,0]  R212      -4.0462991595268250e-01
    z[1,0,0]  R213      3.7694208323955536e-02
    z[1,0,0]  R214      -2.1607734262943268e-01
    z[1,0,0]  R215      7.0514534600079060e-03
    z[1,0,0]  R216      -9.2090949416160583e-02
    z[1,0,0]  R217      -3.0757073312997818e-02
    z[1,0,0]  R218      -4.2781847715377808e-01
    z[1,0,0]  R219      1.9809107482433319e-01
    z[1,0,0]  R220      -0.52741938829422
    z[1,0,0]  R221      5.3257548809051514e-01
    z[1,0,0]  R222      -4.4982209801673889e-01
    z[1,0,0]  R223      -6.2833124399185181e-01
    z[1,0,0]  R224      6.3420593738555908e-01
    z[1,0,0]  R225      4.4936975836753845e-01
    z[1,0,0]  R226      3.0873997602611780e-03
    z[1,0,0]  R227      7.9878136515617371e-02
    z[1,0,0]  R228      -4.8687633126974106e-02
    z[1,0,0]  R229      -1.1559718102216721e-01
    z[1,0,0]  R230      -8.0589324235916138e-01
    z[1,0,0]  R231      -3.6386001110076904e-01
    z[1,0,0]  R232      -1.4979280531406403e-01
    z[1,0,0]  R233      -0.760092556476593
    z[1,0,0]  R234      1.8498468399047852e-01
    z[1,0,0]  R235      -5.6739991903305054e-01
    z[1,0,0]  R236      5.0882941484451294e-01
    z[1,0,0]  R237      2.8322085738182068e-01
    z[1,0,0]  R238      -3.1851518154144287e-01
    z[1,0,0]  R239      -2.6721498370170593e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R159      -1
    z[1,0,1]  R160      1
    z[1,0,1]  R171      9.7079819440841675e-01
    z[1,0,1]  R172      6.4031040668487549e-01
    z[1,0,1]  R173      -0.138684943318367
    z[1,0,1]  R174      -1.3560040295124054e-01
    z[1,0,1]  R175      -5.1290322095155716e-02
    z[1,0,1]  R176      -0.0711161345243454
    z[1,0,1]  R177      1.1851778626441956e-01
    z[1,0,1]  R178      1.6843172907829285e-01
    z[1,0,1]  R179      9.2258296906948090e-02
    z[1,0,1]  R180      -1.0521542280912399e-01
    z[1,0,1]  R181      1.1808297038078308e-01
    z[1,0,1]  R182      -1.7224618792533875e-01
    z[1,0,1]  R183      -2.3573809862136841e-01
    z[1,0,1]  R184      -1.2717759609222412e-01
    z[1,0,1]  R185      -3.2212957739830017e-01
    z[1,0,1]  R186      -2.7359953522682190e-01
    z[1,0,1]  R187      -2.7333667874336243e-01
    z[1,0,1]  R188      -4.5951792597770691e-01
    z[1,0,1]  R189      -4.3252980709075928e-01
    z[1,0,1]  R190      -1.1579956859350204e-01
    z[1,0,1]  R191      -9.5399028062820435e-01
    z[1,0,1]  R192      -7.8108400106430054e-01
    z[1,0,1]  R193      -8.0746436119079590e-01
    z[1,0,1]  R194      -7.8210854530334473e-01
    z[1,0,1]  R195      -7.1410173177719116e-01
    z[1,0,1]  R196      -7.8637742996215820e-01
    z[1,0,1]  R197      -7.4421435594558716e-01
    z[1,0,1]  R198      -0.700564444065094
    z[1,0,1]  R199      -6.8744331598281860e-01
    z[1,0,1]  R200      -7.0553278923034668e-01
    z[1,0,1]  R201      5.8930778503417969e-01
    z[1,0,1]  R202      5.5380409955978394e-01
    z[1,0,1]  R203      -7.1062213182449341e-01
    z[1,0,1]  R204      7.0085096359252930e-01
    z[1,0,1]  R205      -6.4749735593795776e-01
    z[1,0,1]  R206      -5.9957367181777954e-01
    z[1,0,1]  R207      5.0419336557388306e-01
    z[1,0,1]  R208      0.506360650062561
    z[1,0,1]  R209      5.4126524925231934e-01
    z[1,0,1]  R210      -3.6219015717506409e-01
    z[1,0,1]  R211      -2.1722352504730225e-01
    z[1,0,1]  R212      -3.3881747722625732e-01
    z[1,0,1]  R213      -3.5317912697792053e-01
    z[1,0,1]  R214      -1.1785881221294403e-01
    z[1,0,1]  R215      1.5025387704372406e-01
    z[1,0,1]  R216      -1.1684845387935638e-01
    z[1,0,1]  R217      -1.2291974574327469e-01
    z[1,0,1]  R218      7.0135104656219482e-01
    z[1,0,1]  R219      3.1342241168022156e-01
    z[1,0,1]  R220      -3.4877327084541321e-01
    z[1,0,1]  R221      -6.9436973333358765e-01
    z[1,0,1]  R222      -6.0412913560867310e-01
    z[1,0,1]  R223      1.9119927287101746e-01
    z[1,0,1]  R224      5.9598058462142944e-01
    z[1,0,1]  R225      4.9876987934112549e-01
    z[1,0,1]  R226      3.9404088258743286e-01
    z[1,0,1]  R227      4.5466876029968262e-01
    z[1,0,1]  R228      -3.1880775094032288e-01
    z[1,0,1]  R229      -2.8397932648658752e-01
    z[1,0,1]  R230      2.0254749059677124e-01
    z[1,0,1]  R231      4.8817163705825806e-01
    z[1,0,1]  R232      -1.1145620793104172e-01
    z[1,0,1]  R233      1.0701826214790344e-01
    z[1,0,1]  R234      6.8404936790466309e-01
    z[1,0,1]  R235      -5.0725072622299194e-01
    z[1,0,1]  R236      5.4800343513488770e-01
    z[1,0,1]  R237      6.8713134527206421e-01
    z[1,0,1]  R238      -0.327234148979187
    z[1,0,1]  R239      -2.9164829850196838e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R161      -1
    z[1,0,2]  R162      1
    z[1,0,2]  R171      -2.8458578512072563e-02
    z[1,0,2]  R172      9.8333068192005157e-02
    z[1,0,2]  R173      1.6744644939899445e-01
    z[1,0,2]  R174      -3.2325658202171326e-01
    z[1,0,2]  R175      9.7997933626174927e-02
    z[1,0,2]  R176      -5.4415683262050152e-03
    z[1,0,2]  R177      -0.257853627204895
    z[1,0,2]  R178      -3.0794674158096313e-01
    z[1,0,2]  R179      -2.4678991734981537e-01
    z[1,0,2]  R180      2.6114261150360107e-01
    z[1,0,2]  R181      0.527817964553833
    z[1,0,2]  R182      -4.0941774845123291e-01
    z[1,0,2]  R183      -4.9897426366806030e-01
    z[1,0,2]  R184      -7.5336736440658569e-01
    z[1,0,2]  R185      -4.1837871074676514e-01
    z[1,0,2]  R186      -6.3643521070480347e-01
    z[1,0,2]  R187      -3.6294567584991455e-01
    z[1,0,2]  R188      -6.7835921049118042e-01
    z[1,0,2]  R189      -2.8625974059104919e-01
    z[1,0,2]  R190      -0.603752076625824
    z[1,0,2]  R191      6.9415479898452759e-02
    z[1,0,2]  R192      -2.3059016466140747e-01
    z[1,0,2]  R193      3.4395694732666016e-01
    z[1,0,2]  R194      3.1662932038307190e-01
    z[1,0,2]  R195      -1.4114160835742950e-01
    z[1,0,2]  R196      -6.4147412776947021e-02
    z[1,0,2]  R197      -4.0544936060905457e-01
    z[1,0,2]  R198      7.3663949966430664e-02
    z[1,0,2]  R199      2.8105584904551506e-02
    z[1,0,2]  R200      4.0016758441925049e-01
    z[1,0,2]  R201      0.273367315530777
    z[1,0,2]  R202      7.4711114168167114e-01
    z[1,0,2]  R203      -4.7318261861801147e-01
    z[1,0,2]  R204      2.1705015003681183e-01
    z[1,0,2]  R205      3.5083245486021042e-02
    z[1,0,2]  R206      2.7878111600875854e-01
    z[1,0,2]  R207      2.4471163749694824e-01
    z[1,0,2]  R208      -1.4625380933284760e-01
    z[1,0,2]  R209      1.8711602687835693e-01
    z[1,0,2]  R210      -2.6298427581787109e-01
    z[1,0,2]  R211      1.4503470063209534e-01
    z[1,0,2]  R212      -6.9570106267929077e-01
    z[1,0,2]  R213      -4.1466781497001648e-01
    z[1,0,2]  R214      -4.6698024868965149e-01
    z[1,0,2]  R215      -3.9024350047111511e-01
    z[1,0,2]  R216      6.9275557994842529e-02
    z[1,0,2]  R217      2.3258070647716522e-01
    z[1,0,2]  R218      1.1849571019411087e-02
    z[1,0,2]  R219      3.8501378148794174e-02
    z[1,0,2]  R220      4.6703982353210449e-01
    z[1,0,2]  R221      -1.9645893573760986e-01
    z[1,0,2]  R222      -1.5505827963352203e-01
    z[1,0,2]  R223      2.2549276053905487e-01
    z[1,0,2]  R224      -1.1909014731645584e-01
    z[1,0,2]  R225      1.3621711730957031e-01
    z[1,0,2]  R226      3.0358494259417057e-03
    z[1,0,2]  R227      5.9022486209869385e-01
    z[1,0,2]  R228      -1.7114135622978210e-01
    z[1,0,2]  R229      -1.5432457625865936e-01
    z[1,0,2]  R230      -1.3052079081535339e-01
    z[1,0,2]  R231      -4.7506070137023926e-01
    z[1,0,2]  R232      -5.8543598651885986e-01
    z[1,0,2]  R233      9.7700776532292366e-03
    z[1,0,2]  R234      -9.1965541243553162e-02
    z[1,0,2]  R235      5.2086919546127319e-02
    z[1,0,2]  R236      -2.5898671150207520e-01
    z[1,0,2]  R237      3.7725397944450378e-01
    z[1,0,2]  R238      2.9562157392501831e-01
    z[1,0,2]  R239      -3.5007035732269287e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R163      -1
    z[1,0,3]  R164      1
    z[1,0,3]  R171      -1.0652960836887360e-01
    z[1,0,3]  R172      -3.7224423885345459e-01
    z[1,0,3]  R173      5.8253329992294312e-01
    z[1,0,3]  R174      4.3245518207550049e-01
    z[1,0,3]  R175      4.9656990170478821e-01
    z[1,0,3]  R176      5.7550114393234253e-01
    z[1,0,3]  R177      5.2948659658432007e-01
    z[1,0,3]  R178      6.5426230430603027e-01
    z[1,0,3]  R179      9.0064838528633118e-02
    z[1,0,3]  R180      1.2413965165615082e-01
    z[1,0,3]  R181      7.1115463972091675e-02
    z[1,0,3]  R182      6.2369710206985474e-01
    z[1,0,3]  R183      4.5309442281723022e-01
    z[1,0,3]  R184      3.4645467996597290e-01
    z[1,0,3]  R185      5.4036104679107666e-01
    z[1,0,3]  R186      2.8364226222038269e-01
    z[1,0,3]  R187      7.6607018709182739e-01
    z[1,0,3]  R188      0.468136727809906
    z[1,0,3]  R189      2.8573292493820190e-01
    z[1,0,3]  R190      1.3243648409843445e-01
    z[1,0,3]  R191      1.1205623298883438e-01
    z[1,0,3]  R192      3.3471721410751343e-01
    z[1,0,3]  R193      4.3947091698646545e-01
    z[1,0,3]  R194      3.9231842756271362e-01
    z[1,0,3]  R195      3.9689761400222778e-01
    z[1,0,3]  R196      -7.3697227053344250e-03
    z[1,0,3]  R197      -1.6436351463198662e-02
    z[1,0,3]  R198      -4.0541672706604004e-01
    z[1,0,3]  R199      -6.1854767799377441e-01
    z[1,0,3]  R200      -3.1052476167678833e-01
    z[1,0,3]  R201      -4.6811640262603760e-01
    z[1,0,3]  R202      -2.9047888517379761e-01
    z[1,0,3]  R203      -4.2592954635620117e-01
    z[1,0,3]  R204      -5.0239515304565430e-01
    z[1,0,3]  R205      1.1542630381882191e-02
    z[1,0,3]  R206      -3.5988822579383850e-01
    z[1,0,3]  R207      -5.7506734132766724e-01
    z[1,0,3]  R208      -6.6924935579299927e-01
    z[1,0,3]  R209      -3.9783358573913574e-01
    z[1,0,3]  R210      4.7208401560783386e-01
    z[1,0,3]  R211      5.2300405502319336e-01
    z[1,0,3]  R212      -1.0115691274404526e-01
    z[1,0,3]  R213      4.6715912222862244e-01
    z[1,0,3]  R214      -1.5212836861610413e-01
    z[1,0,3]  R215      -0.165887251496315
    z[1,0,3]  R216      3.8981422781944275e-01
    z[1,0,3]  R217      2.3801697790622711e-01
    z[1,0,3]  R218      -4.4040897488594055e-01
    z[1,0,3]  R219      -2.2600656747817993e-01
    z[1,0,3]  R220      4.4847515225410461e-01
    z[1,0,3]  R221      3.3983027935028076e-01
    z[1,0,3]  R222      -1.5335313975811005e-01
    z[1,0,3]  R223      7.5554080307483673e-02
    z[1,0,3]  R224      -1.5334862470626831e-01
    z[1,0,3]  R225      -1.7881637811660767e-01
    z[1,0,3]  R226      8.0032050609588623e-01
    z[1,0,3]  R227      2.5405695661902428e-02
    z[1,0,3]  R228      -4.0245819091796875e-01
    z[1,0,3]  R229      -0.374159038066864
    z[1,0,3]  R230      -5.9671744704246521e-02
    z[1,0,3]  R231      5.9326660633087158e-01
    z[1,0,3]  R232      0.532675564289093
    z[1,0,3]  R233      2.8765746951103210e-01
    z[1,0,3]  R234      -3.7605494260787964e-01
    z[1,0,3]  R235      2.7694469690322876e-01
    z[1,0,3]  R236      -4.3913671374320984e-01
    z[1,0,3]  R237      -1.7861096560955048e-01
    z[1,0,3]  R238      3.9464709162712097e-01
    z[1,0,3]  R239      3.3547837287187576e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R165      -1
    z[1,0,4]  R166      1
    z[1,0,4]  R171      -4.2701106518507004e-02
    z[1,0,4]  R172      -1.0903651267290115e-01
    z[1,0,4]  R173      -3.8109406828880310e-02
    z[1,0,4]  R174      -2.6365658640861511e-01
    z[1,0,4]  R175      -1.0086496174335480e-01
    z[1,0,4]  R176      -4.2758235335350037e-01
    z[1,0,4]  R177      -0.0987108051776886
    z[1,0,4]  R178      -1.8443804234266281e-02
    z[1,0,4]  R179      -8.4633342921733856e-02
    z[1,0,4]  R180      -1.1293911933898926e-01
    z[1,0,4]  R181      0.827197790145874
    z[1,0,4]  R182      -6.3351714611053467e-01
    z[1,0,4]  R183      -6.4652818441390991e-01
    z[1,0,4]  R184      -4.9971318244934082e-01
    z[1,0,4]  R185      -4.7033041715621948e-01
    z[1,0,4]  R186      -3.9395216107368469e-01
    z[1,0,4]  R187      -3.5066959261894226e-01
    z[1,0,4]  R188      -1.9051505625247955e-01
    z[1,0,4]  R189      -4.0630677342414856e-01
    z[1,0,4]  R190      -7.6303946971893311e-01
    z[1,0,4]  R191      3.2096426934003830e-02
    z[1,0,4]  R192      -1.1262485384941101e-01
    z[1,0,4]  R193      -1.1069152504205704e-02
    z[1,0,4]  R194      -8.4059886634349823e-02
    z[1,0,4]  R195      -0.0471460185945034
    z[1,0,4]  R196      -1.4118281193077564e-02
    z[1,0,4]  R197      4.1445949673652649e-01
    z[1,0,4]  R198      -5.0145995616912842e-01
    z[1,0,4]  R199      3.1634697318077087e-01
    z[1,0,4]  R200      3.2800965011119843e-02
    z[1,0,4]  R201      3.9694914221763611e-01
    z[1,0,4]  R202      -1.3578631915152073e-02
    z[1,0,4]  R203      -2.8430971503257751e-01
    z[1,0,4]  R204      -3.9041060209274292e-01
    z[1,0,4]  R205      4.7830536961555481e-01
    z[1,0,4]  R206      -2.0111978054046631e-01
    z[1,0,4]  R207      2.9851067066192627e-01
    z[1,0,4]  R208      -2.3639839142560959e-02
    z[1,0,4]  R209      -1.8404923379421234e-01
    z[1,0,4]  R210      -0.517731785774231
    z[1,0,4]  R211      7.8019194304943085e-02
    z[1,0,4]  R212      3.0334141850471497e-01
    z[1,0,4]  R213      -1.7769330739974976e-01
    z[1,0,4]  R214      -0.672885000705719
    z[1,0,4]  R215      -0.227244034409523
    z[1,0,4]  R216      -4.9227970838546753e-01
    z[1,0,4]  R217      -7.8103309869766235e-01
    z[1,0,4]  R218      -2.8709790110588074e-01
    z[1,0,4]  R219      -6.3240557909011841e-01
    z[1,0,4]  R220      1.2078670412302017e-01
    z[1,0,4]  R221      -4.0066551417112350e-02
    z[1,0,4]  R222      -1.0748336464166641e-01
    z[1,0,4]  R223      3.1558805704116821e-01
    z[1,0,4]  R224      4.1970506310462952e-01
    z[1,0,4]  R225      1.4935132116079330e-02
    z[1,0,4]  R226      -1.1886394768953323e-01
    z[1,0,4]  R227      4.9540087580680847e-01
    z[1,0,4]  R228      7.4773132801055908e-01
    z[1,0,4]  R229      5.3252893686294556e-01
    z[1,0,4]  R230      -2.0493234694004059e-01
    z[1,0,4]  R231      5.5696006864309311e-02
    z[1,0,4]  R232      -4.3959099054336548e-01
    z[1,0,4]  R233      -2.9392856359481812e-01
    z[1,0,4]  R234      1.6512106359004974e-01
    z[1,0,4]  R235      3.9310356974601746e-01
    z[1,0,4]  R236      -2.5381135940551758e-01
    z[1,0,4]  R237      2.4333505425602198e-03
    z[1,0,4]  R238      -4.3560588359832764e-01
    z[1,0,4]  R239      3.8866540789604187e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R167      -1
    z[1,0,5]  R168      1
    z[1,0,5]  R171      -1.3769541680812836e-01
    z[1,0,5]  R172      -0.563877522945404
    z[1,0,5]  R173      8.5845552384853363e-03
    z[1,0,5]  R174      0.00700989319011569
    z[1,0,5]  R175      -5.6152928620576859e-02
    z[1,0,5]  R176      9.8681680858135223e-02
    z[1,0,5]  R177      -3.2476380467414856e-01
    z[1,0,5]  R178      7.6823040843009949e-02
    z[1,0,5]  R179      3.4556340426206589e-02
    z[1,0,5]  R180      -2.9272469878196716e-01
    z[1,0,5]  R181      -1.5474167652428150e-02
    z[1,0,5]  R182      1.0599581152200699e-01
    z[1,0,5]  R183      -2.5980386137962341e-01
    z[1,0,5]  R184      1.1180879175662994e-01
    z[1,0,5]  R185      0.0648990347981453
    z[1,0,5]  R186      2.8234541416168213e-01
    z[1,0,5]  R187      2.7899768948554993e-01
    z[1,0,5]  R188      1.2590293586254120e-01
    z[1,0,5]  R189      6.7350721359252930e-01
    z[1,0,5]  R190      9.8208189010620117e-02
    z[1,0,5]  R191      2.0516207814216614e-01
    z[1,0,5]  R192      -0.364769846200943
    z[1,0,5]  R193      8.3711095154285431e-02
    z[1,0,5]  R194      -2.5648900866508484e-01
    z[1,0,5]  R195      -2.9499495029449463e-01
    z[1,0,5]  R196      -1.0593015700578690e-01
    z[1,0,5]  R197      -2.6589006185531616e-01
    z[1,0,5]  R198      -7.9941317439079285e-02
    z[1,0,5]  R199      2.0427992939949036e-01
    z[1,0,5]  R200      1.9457958638668060e-01
    z[1,0,5]  R201      -7.8477680683135986e-02
    z[1,0,5]  R202      -1.4952444471418858e-02
    z[1,0,5]  R203      -7.9793877899646759e-02
    z[1,0,5]  R204      -0.0723300352692604
    z[1,0,5]  R205      2.5796961784362793e-01
    z[1,0,5]  R206      -5.6732857227325439e-01
    z[1,0,5]  R207      3.7883457541465759e-01
    z[1,0,5]  R208      4.5789572596549988e-01
    z[1,0,5]  R209      6.8522137403488159e-01
    z[1,0,5]  R210      5.4043656587600708e-01
    z[1,0,5]  R211      -4.4263872504234314e-01
    z[1,0,5]  R212      -3.2308492064476013e-01
    z[1,0,5]  R213      -6.4944040775299072e-01
    z[1,0,5]  R214      4.9100711476057768e-04
    z[1,0,5]  R215      -0.862942636013031
    z[1,0,5]  R216      5.4489824920892715e-02
    z[1,0,5]  R217      -0.509451687335968
    z[1,0,5]  R218      3.9412174373865128e-02
    z[1,0,5]  R219      -6.0844719409942627e-01
    z[1,0,5]  R220      0.385626882314682
    z[1,0,5]  R221      5.3227208554744720e-02
    z[1,0,5]  R222      1.0986543446779251e-01
    z[1,0,5]  R223      -8.7742723524570465e-02
    z[1,0,5]  R224      1.6445071995258331e-01
    z[1,0,5]  R225      3.7852725386619568e-01
    z[1,0,5]  R226      7.9666912555694580e-02
    z[1,0,5]  R227      -2.6526296138763428e-01
    z[1,0,5]  R228      -6.9492459297180176e-02
    z[1,0,5]  R229      -5.6996160745620728e-01
    z[1,0,5]  R230      -4.6937185525894165e-01
    z[1,0,5]  R231      -2.0916087925434113e-01
    z[1,0,5]  R232      -3.8129898905754089e-01
    z[1,0,5]  R233      4.6436417102813721e-01
    z[1,0,5]  R234      5.2960163354873657e-01
    z[1,0,5]  R235      1.3235104084014893e-01
    z[1,0,5]  R236      -1.4744228124618530e-01
    z[1,0,5]  R237      -4.2876243591308594e-01
    z[1,0,5]  R238      5.9810662269592285e-01
    z[1,0,5]  R239      -2.3030030727386475e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R169      -1
    z[1,0,6]  R170      1
    z[1,0,6]  R171      -5.5232111364603043e-02
    z[1,0,6]  R172      -2.7220547199249268e-01
    z[1,0,6]  R173      1.6095350682735443e-01
    z[1,0,6]  R174      -3.3334780484437943e-02
    z[1,0,6]  R175      -3.8633573055267334e-01
    z[1,0,6]  R176      -4.3321792036294937e-02
    z[1,0,6]  R177      2.1497417986392975e-01
    z[1,0,6]  R178      1.2258848547935486e-01
    z[1,0,6]  R179      -1.7597796022891998e-01
    z[1,0,6]  R180      -1.2156955152750015e-01
    z[1,0,6]  R181      -0.0600656233727932
    z[1,0,6]  R182      -1.8227970227599144e-02
    z[1,0,6]  R183      5.8530010282993317e-02
    z[1,0,6]  R184      -1.7670390009880066e-01
    z[1,0,6]  R185      3.7089386582374573e-01
    z[1,0,6]  R186      3.0736133456230164e-01
    z[1,0,6]  R187      7.1762762963771820e-02
    z[1,0,6]  R188      7.9394921660423279e-02
    z[1,0,6]  R189      1.7386290431022644e-01
    z[1,0,6]  R190      1.0488359630107880e-01
    z[1,0,6]  R191      1.4423468708992004e-01
    z[1,0,6]  R192      -1.8995878100395203e-01
    z[1,0,6]  R193      -1.7092873156070709e-01
    z[1,0,6]  R194      7.1612037718296051e-02
    z[1,0,6]  R195      -8.1680983304977417e-02
    z[1,0,6]  R196      5.1010406017303467e-01
    z[1,0,6]  R197      -1.4856582880020142e-01
    z[1,0,6]  R198      -1.9486727192997932e-02
    z[1,0,6]  R199      2.5488814339041710e-02
    z[1,0,6]  R200      -0.40351602435112
    z[1,0,6]  R201      -3.9917615056037903e-01
    z[1,0,6]  R202      5.8154135942459106e-02
    z[1,0,6]  R203      2.1559296175837517e-02
    z[1,0,6]  R204      2.2480469942092896e-01
    z[1,0,6]  R205      -4.2965874075889587e-01
    z[1,0,6]  R206      1.0333219915628433e-01
    z[1,0,6]  R207      2.1412852406501770e-01
    z[1,0,6]  R208      1.2260851263999939e-01
    z[1,0,6]  R209      3.2578937709331512e-02
    z[1,0,6]  R210      -8.6356140673160553e-02
    z[1,0,6]  R211      5.8195066452026367e-01
    z[1,0,6]  R212      1.7562672495841980e-01
    z[1,0,6]  R213      0.174094557762146
    z[1,0,6]  R214      4.9541077017784119e-01
    z[1,0,6]  R215      3.5434953868389130e-02
    z[1,0,6]  R216      7.5881689786911011e-01
    z[1,0,6]  R217      6.0374997556209564e-02
    z[1,0,6]  R218      2.1679243445396423e-01
    z[1,0,6]  R219      -0.199550062417984
    z[1,0,6]  R220      1.3278649747371674e-01
    z[1,0,6]  R221      -2.7512687444686890e-01
    z[1,0,6]  R222      -6.0125261545181274e-01
    z[1,0,6]  R223      -6.3623321056365967e-01
    z[1,0,6]  R224      4.1176278144121170e-02
    z[1,0,6]  R225      -5.9603631496429443e-01
    z[1,0,6]  R226      -4.2863118648529053e-01
    z[1,0,6]  R227      -3.4942615032196045e-01
    z[1,0,6]  R228      3.7523031234741211e-01
    z[1,0,6]  R229      3.6570286750793457e-01
    z[1,0,6]  R230      1.6311649978160858e-01
    z[1,0,6]  R231      6.9254361093044281e-02
    z[1,0,6]  R232      5.6397481821477413e-03
    z[1,0,6]  R233      -1.6104708611965179e-01
    z[1,0,6]  R234      -2.0059740543365479e-01
    z[1,0,6]  R235      4.1145539283752441e-01
    z[1,0,6]  R236      -3.0775046348571777e-01
    z[1,0,6]  R237      -2.9928398132324219e-01
    z[1,0,6]  R238      2.9043078422546387e-02
    z[1,0,6]  R239      7.1816682815551758e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R240      -1
    z[0,5,0]  R241      1
    z[0,5,0]  R254      -3.4287452697753906e-01
    z[0,5,0]  R255      -4.0462991595268250e-01
    z[0,5,0]  R256      3.7694208323955536e-02
    z[0,5,0]  R257      -2.1607734262943268e-01
    z[0,5,0]  R258      7.0514534600079060e-03
    z[0,5,0]  R259      -9.2090949416160583e-02
    z[0,5,0]  R260      -3.0757073312997818e-02
    z[0,5,0]  R261      -4.2781847715377808e-01
    z[0,5,0]  R262      1.9809107482433319e-01
    z[0,5,0]  R263      -0.52741938829422
    z[0,5,0]  R264      5.3257548809051514e-01
    z[0,5,0]  R265      -4.4982209801673889e-01
    z[0,5,0]  R266      -6.2833124399185181e-01
    z[0,5,0]  R267      6.3420593738555908e-01
    z[0,5,0]  R268      4.4936975836753845e-01
    z[0,5,0]  R269      3.0873997602611780e-03
    z[0,5,0]  R270      7.9878136515617371e-02
    z[0,5,0]  R271      -4.8687633126974106e-02
    z[0,5,0]  R272      -1.1559718102216721e-01
    z[0,5,0]  R273      -8.0589324235916138e-01
    z[0,5,0]  R274      -3.6386001110076904e-01
    z[0,5,0]  R275      -1.4979280531406403e-01
    z[0,5,0]  R276      -0.760092556476593
    z[0,5,0]  R277      1.8498468399047852e-01
    z[0,5,0]  R278      -5.6739991903305054e-01
    z[0,5,0]  R279      5.0882941484451294e-01
    z[0,5,0]  R280      2.8322085738182068e-01
    z[0,5,0]  R281      -3.1851518154144287e-01
    z[0,5,0]  R282      -2.6721498370170593e-01
    z[0,5,0]  R283      -2.4731977283954620e-01
    z[0,5,0]  R284      0.085629403591156
    z[0,5,0]  R285      5.9188399463891983e-02
    z[0,5,0]  R286      -1.6589473187923431e-01
    z[0,5,0]  R287      -1.7032325267791748e-02
    z[0,5,0]  R288      -4.5395351946353912e-02
    z[0,5,0]  R289      -1.6201204061508179e-01
    z[0,5,0]  R290      -1.8934737890958786e-02
    z[0,5,0]  R291      0.150125190615654
    z[0,5,0]  R292      -3.8735404610633850e-01
    z[0,5,0]  R293      -2.1382641792297363e-01
    z[0,5,0]  R294      -3.5925221443176270e-01
    z[0,5,0]  R295      -3.9004248380661011e-01
    z[0,5,0]  R296      -8.7264098227024078e-02
    z[0,5,0]  R297      1.8645381554961205e-02
    z[0,5,0]  R298      -3.1487077474594116e-01
    z[0,5,0]  R299      -6.3983634114265442e-02
    z[0,5,0]  R300      3.1601474620401859e-03
    z[0,5,0]  R301      2.7315232157707214e-01
    z[0,5,0]  R302      -1.1055515706539154e-01
    z[0,5,0]  R303      -5.3513408638536930e-03
    z[0,5,0]  R304      1.9580383598804474e-01
    z[0,5,0]  R305      4.4064730405807495e-01
    z[0,5,0]  R306      2.6081116870045662e-02
    z[0,5,0]  R307      2.1425299346446991e-01
    z[0,5,0]  R308      -2.5385084748268127e-01
    z[0,5,0]  R309      -5.7478111237287521e-02
    z[0,5,0]  R310      8.5354052484035492e-02
    z[0,5,0]  R311      2.3851613700389862e-01
    z[0,5,0]  R312      -1.3423493504524231e-01
    z[0,5,0]  R313      -3.6913685500621796e-02
    z[0,5,0]  R314      -2.1532289683818817e-01
    z[0,5,0]  R315      -2.3875330388545990e-01
    z[0,5,0]  R316      9.2885173857212067e-02
    z[0,5,0]  R317      5.3868040442466736e-02
    z[0,5,0]  R318      1.3729308545589447e-01
    z[0,5,0]  R319      1.9400085508823395e-01
    z[0,5,0]  R320      2.4801792204380035e-01
    z[0,5,0]  R321      5.0494468212127686e-01
    z[0,5,0]  R322      2.1552659571170807e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R242      -1
    z[0,5,1]  R243      1
    z[0,5,1]  R254      -2.1722352504730225e-01
    z[0,5,1]  R255      -3.3881747722625732e-01
    z[0,5,1]  R256      -3.5317912697792053e-01
    z[0,5,1]  R257      -1.1785881221294403e-01
    z[0,5,1]  R258      1.5025387704372406e-01
    z[0,5,1]  R259      -1.1684845387935638e-01
    z[0,5,1]  R260      -1.2291974574327469e-01
    z[0,5,1]  R261      7.0135104656219482e-01
    z[0,5,1]  R262      3.1342241168022156e-01
    z[0,5,1]  R263      -3.4877327084541321e-01
    z[0,5,1]  R264      -6.9436973333358765e-01
    z[0,5,1]  R265      -6.0412913560867310e-01
    z[0,5,1]  R266      1.9119927287101746e-01
    z[0,5,1]  R267      5.9598058462142944e-01
    z[0,5,1]  R268      4.9876987934112549e-01
    z[0,5,1]  R269      3.9404088258743286e-01
    z[0,5,1]  R270      4.5466876029968262e-01
    z[0,5,1]  R271      -3.1880775094032288e-01
    z[0,5,1]  R272      -2.8397932648658752e-01
    z[0,5,1]  R273      2.0254749059677124e-01
    z[0,5,1]  R274      4.8817163705825806e-01
    z[0,5,1]  R275      -1.1145620793104172e-01
    z[0,5,1]  R276      1.0701826214790344e-01
    z[0,5,1]  R277      6.8404936790466309e-01
    z[0,5,1]  R278      -5.0725072622299194e-01
    z[0,5,1]  R279      5.4800343513488770e-01
    z[0,5,1]  R280      6.8713134527206421e-01
    z[0,5,1]  R281      -0.327234148979187
    z[0,5,1]  R282      -2.9164829850196838e-01
    z[0,5,1]  R283      9.2446643114089966e-01
    z[0,5,1]  R284      9.8886710405349731e-01
    z[0,5,1]  R285      -3.0416840687394142e-02
    z[0,5,1]  R286      6.3676489517092705e-03
    z[0,5,1]  R287      5.7651054859161377e-01
    z[0,5,1]  R288      -3.4543506801128387e-02
    z[0,5,1]  R289      -0.0232999287545681
    z[0,5,1]  R290      -3.5011786967515945e-02
    z[0,5,1]  R291      -6.4352788031101227e-02
    z[0,5,1]  R292      -5.5713269859552383e-02
    z[0,5,1]  R293      -6.2276363372802734e-01
    z[0,5,1]  R294      -6.0613393783569336e-01
    z[0,5,1]  R295      -0.557383120059967
    z[0,5,1]  R296      -5.5232745409011841e-01
    z[0,5,1]  R297      -5.3412622213363647e-01
    z[0,5,1]  R298      -5.6050300598144531e-01
    z[0,5,1]  R299      -4.9303579330444336e-01
    z[0,5,1]  R300      -5.4293894767761230e-01
    z[0,5,1]  R301      -5.5307763814926147e-01
    z[0,5,1]  R302      -4.9725890159606934e-01
    z[0,5,1]  R303      -9.8264390230178833e-01
    z[0,5,1]  R304      -7.9808372259140015e-01
    z[0,5,1]  R305      -6.5045034885406494e-01
    z[0,5,1]  R306      -4.5593962073326111e-01
    z[0,5,1]  R307      0.483502060174942
    z[0,5,1]  R308      6.7729687690734863e-01
    z[0,5,1]  R309      5.8949595689773560e-01
    z[0,5,1]  R310      3.5691463947296143e-01
    z[0,5,1]  R311      7.8776067495346069e-01
    z[0,5,1]  R312      5.6254655122756958e-01
    z[0,5,1]  R313      0.73489910364151
    z[0,5,1]  R314      0.717809796333313
    z[0,5,1]  R315      8.3352595567703247e-01
    z[0,5,1]  R316      7.7697873115539551e-01
    z[0,5,1]  R317      6.3356381654739380e-01
    z[0,5,1]  R318      6.9384175539016724e-01
    z[0,5,1]  R319      7.0997720956802368e-01
    z[0,5,1]  R320      7.7718651294708252e-01
    z[0,5,1]  R321      -2.2949238121509552e-01
    z[0,5,1]  R322      -7.7543258666992188e-02
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R244      -1
    z[0,5,2]  R245      1
    z[0,5,2]  R254      1.4503470063209534e-01
    z[0,5,2]  R255      -6.9570106267929077e-01
    z[0,5,2]  R256      -4.1466781497001648e-01
    z[0,5,2]  R257      -4.6698024868965149e-01
    z[0,5,2]  R258      -3.9024350047111511e-01
    z[0,5,2]  R259      6.9275557994842529e-02
    z[0,5,2]  R260      2.3258070647716522e-01
    z[0,5,2]  R261      1.1849571019411087e-02
    z[0,5,2]  R262      3.8501378148794174e-02
    z[0,5,2]  R263      4.6703982353210449e-01
    z[0,5,2]  R264      -1.9645893573760986e-01
    z[0,5,2]  R265      -1.5505827963352203e-01
    z[0,5,2]  R266      2.2549276053905487e-01
    z[0,5,2]  R267      -1.1909014731645584e-01
    z[0,5,2]  R268      1.3621711730957031e-01
    z[0,5,2]  R269      3.0358494259417057e-03
    z[0,5,2]  R270      5.9022486209869385e-01
    z[0,5,2]  R271      -1.7114135622978210e-01
    z[0,5,2]  R272      -1.5432457625865936e-01
    z[0,5,2]  R273      -1.3052079081535339e-01
    z[0,5,2]  R274      -4.7506070137023926e-01
    z[0,5,2]  R275      -5.8543598651885986e-01
    z[0,5,2]  R276      9.7700776532292366e-03
    z[0,5,2]  R277      -9.1965541243553162e-02
    z[0,5,2]  R278      5.2086919546127319e-02
    z[0,5,2]  R279      -2.5898671150207520e-01
    z[0,5,2]  R280      3.7725397944450378e-01
    z[0,5,2]  R281      2.9562157392501831e-01
    z[0,5,2]  R282      -3.5007035732269287e-01
    z[0,5,2]  R283      8.9352488517761230e-02
    z[0,5,2]  R284      -0.0491953007876873
    z[0,5,2]  R285      -7.9013854265213013e-01
    z[0,5,2]  R286      -6.8222486972808838e-01
    z[0,5,2]  R287      -1.4217109978199005e-01
    z[0,5,2]  R288      -5.9088891744613647e-01
    z[0,5,2]  R289      -8.1355655193328857e-01
    z[0,5,2]  R290      -5.0917977094650269e-01
    z[0,5,2]  R291      -4.6965035796165466e-01
    z[0,5,2]  R292      -6.6920286417007446e-01
    z[0,5,2]  R293      1.2158872932195663e-01
    z[0,5,2]  R294      4.0791156888008118e-01
    z[0,5,2]  R295      -3.8222637772560120e-01
    z[0,5,2]  R296      -5.6150525808334351e-01
    z[0,5,2]  R297      -3.2182133197784424e-01
    z[0,5,2]  R298      -5.4858695715665817e-02
    z[0,5,2]  R299      -2.4375198781490326e-01
    z[0,5,2]  R300      -1.9812296330928802e-01
    z[0,5,2]  R301      3.9448940753936768e-01
    z[0,5,2]  R302      5.7450169324874878e-01
    z[0,5,2]  R303      -0.0683421716094017
    z[0,5,2]  R304      -2.9872161149978638e-01
    z[0,5,2]  R305      -3.4258782863616943e-02
    z[0,5,2]  R306      -2.4924477934837341e-01
    z[0,5,2]  R307      4.2520549893379211e-01
    z[0,5,2]  R308      3.0196332931518555e-01
    z[0,5,2]  R309      4.8791524767875671e-01
    z[0,5,2]  R310      6.5476822853088379e-01
    z[0,5,2]  R311      3.7515634298324585e-01
    z[0,5,2]  R312      5.4492139816284180e-01
    z[0,5,2]  R313      5.1817828416824341e-01
    z[0,5,2]  R314      2.5820646435022354e-02
    z[0,5,2]  R315      4.3365576863288879e-01
    z[0,5,2]  R316      2.0073603093624115e-01
    z[0,5,2]  R317      4.8572579026222229e-01
    z[0,5,2]  R318      -2.1406058967113495e-01
    z[0,5,2]  R319      1.0951752215623856e-01
    z[0,5,2]  R320      -3.0360126495361328e-01
    z[0,5,2]  R321      -5.7654780149459839e-01
    z[0,5,2]  R322      -4.5599821209907532e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R246      -1
    z[0,5,3]  R247      1
    z[0,5,3]  R254      5.2300405502319336e-01
    z[0,5,3]  R255      -1.0115691274404526e-01
    z[0,5,3]  R256      4.6715912222862244e-01
    z[0,5,3]  R257      -1.5212836861610413e-01
    z[0,5,3]  R258      -0.165887251496315
    z[0,5,3]  R259      3.8981422781944275e-01
    z[0,5,3]  R260      2.3801697790622711e-01
    z[0,5,3]  R261      -4.4040897488594055e-01
    z[0,5,3]  R262      -2.2600656747817993e-01
    z[0,5,3]  R263      4.4847515225410461e-01
    z[0,5,3]  R264      3.3983027935028076e-01
    z[0,5,3]  R265      -1.5335313975811005e-01
    z[0,5,3]  R266      7.5554080307483673e-02
    z[0,5,3]  R267      -1.5334862470626831e-01
    z[0,5,3]  R268      -1.7881637811660767e-01
    z[0,5,3]  R269      8.0032050609588623e-01
    z[0,5,3]  R270      2.5405695661902428e-02
    z[0,5,3]  R271      -4.0245819091796875e-01
    z[0,5,3]  R272      -0.374159038066864
    z[0,5,3]  R273      -5.9671744704246521e-02
    z[0,5,3]  R274      5.9326660633087158e-01
    z[0,5,3]  R275      0.532675564289093
    z[0,5,3]  R276      2.8765746951103210e-01
    z[0,5,3]  R277      -3.7605494260787964e-01
    z[0,5,3]  R278      2.7694469690322876e-01
    z[0,5,3]  R279      -4.3913671374320984e-01
    z[0,5,3]  R280      -1.7861096560955048e-01
    z[0,5,3]  R281      3.9464709162712097e-01
    z[0,5,3]  R282      3.3547837287187576e-02
    z[0,5,3]  R283      -0.0918092280626297
    z[0,5,3]  R284      -5.7513605803251266e-02
    z[0,5,3]  R285      4.5418307185173035e-01
    z[0,5,3]  R286      7.7439472079277039e-02
    z[0,5,3]  R287      -4.7017872333526611e-01
    z[0,5,3]  R288      2.1625219285488129e-01
    z[0,5,3]  R289      1.2432087957859039e-01
    z[0,5,3]  R290      8.0524575710296631e-01
    z[0,5,3]  R291      2.2533978521823883e-01
    z[0,5,3]  R292      3.7645533680915833e-01
    z[0,5,3]  R293      -5.7087731361389160e-01
    z[0,5,3]  R294      3.2693132758140564e-01
    z[0,5,3]  R295      2.0445835590362549e-01
    z[0,5,3]  R296      -4.2540755122900009e-02
    z[0,5,3]  R297      1.0242677479982376e-01
    z[0,5,3]  R298      5.6630659103393555e-01
    z[0,5,3]  R299      -3.0235049128532410e-01
    z[0,5,3]  R300      4.3067130446434021e-01
    z[0,5,3]  R301      -4.3552737683057785e-02
    z[0,5,3]  R302      -1.7985163629055023e-01
    z[0,5,3]  R303      -3.1912997364997864e-02
    z[0,5,3]  R304      3.0458664894104004e-01
    z[0,5,3]  R305      -4.7390836477279663e-01
    z[0,5,3]  R306      -4.9928811192512512e-01
    z[0,5,3]  R307      -3.4362620115280151e-01
    z[0,5,3]  R308      -5.4417955875396729e-01
    z[0,5,3]  R309      -5.6571716070175171e-01
    z[0,5,3]  R310      -5.5515849590301514e-01
    z[0,5,3]  R311      -1.1362207680940628e-01
    z[0,5,3]  R312      -2.1862530708312988e-01
    z[0,5,3]  R313      -8.9182555675506592e-02
    z[0,5,3]  R314      -5.4975038766860962e-01
    z[0,5,3]  R315      -7.8502416610717773e-02
    z[0,5,3]  R316      -3.4554621577262878e-01
    z[0,5,3]  R317      -0.526281476020813
    z[0,5,3]  R318      -4.1011002659797668e-01
    z[0,5,3]  R319      -2.1180368959903717e-01
    z[0,5,3]  R320      -1.5986070036888123e-01
    z[0,5,3]  R321      8.8934656232595444e-03
    z[0,5,3]  R322      1.7634023725986481e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R248      -1
    z[0,5,4]  R249      1
    z[0,5,4]  R254      7.8019194304943085e-02
    z[0,5,4]  R255      3.0334141850471497e-01
    z[0,5,4]  R256      -1.7769330739974976e-01
    z[0,5,4]  R257      -0.672885000705719
    z[0,5,4]  R258      -0.227244034409523
    z[0,5,4]  R259      -4.9227970838546753e-01
    z[0,5,4]  R260      -7.8103309869766235e-01
    z[0,5,4]  R261      -2.8709790110588074e-01
    z[0,5,4]  R262      -6.3240557909011841e-01
    z[0,5,4]  R263      1.2078670412302017e-01
    z[0,5,4]  R264      -4.0066551417112350e-02
    z[0,5,4]  R265      -1.0748336464166641e-01
    z[0,5,4]  R266      3.1558805704116821e-01
    z[0,5,4]  R267      4.1970506310462952e-01
    z[0,5,4]  R268      1.4935132116079330e-02
    z[0,5,4]  R269      -1.1886394768953323e-01
    z[0,5,4]  R270      4.9540087580680847e-01
    z[0,5,4]  R271      7.4773132801055908e-01
    z[0,5,4]  R272      5.3252893686294556e-01
    z[0,5,4]  R273      -2.0493234694004059e-01
    z[0,5,4]  R274      5.5696006864309311e-02
    z[0,5,4]  R275      -4.3959099054336548e-01
    z[0,5,4]  R276      -2.9392856359481812e-01
    z[0,5,4]  R277      1.6512106359004974e-01
    z[0,5,4]  R278      3.9310356974601746e-01
    z[0,5,4]  R279      -2.5381135940551758e-01
    z[0,5,4]  R280      2.4333505425602198e-03
    z[0,5,4]  R281      -4.3560588359832764e-01
    z[0,5,4]  R282      3.8866540789604187e-01
    z[0,5,4]  R283      -1.0070706158876419e-01
    z[0,5,4]  R284      -1.3634567148983479e-02
    z[0,5,4]  R285      -3.9490780234336853e-01
    z[0,5,4]  R286      -7.0081901550292969e-01
    z[0,5,4]  R287      -2.7202382683753967e-01
    z[0,5,4]  R288      -7.1624511480331421e-01
    z[0,5,4]  R289      -3.6926794052124023e-01
    z[0,5,4]  R290      -2.2502495348453522e-01
    z[0,5,4]  R291      -7.4040561914443970e-01
    z[0,5,4]  R292      -4.0332981944084167e-01
    z[0,5,4]  R293      1.3444192707538605e-01
    z[0,5,4]  R294      -3.1734594702720642e-01
    z[0,5,4]  R295      -2.3484092950820923e-01
    z[0,5,4]  R296      -2.9067406058311462e-01
    z[0,5,4]  R297      6.3229000568389893e-01
    z[0,5,4]  R298      -5.0736343860626221e-01
    z[0,5,4]  R299      0.506917417049408
    z[0,5,4]  R300      -7.7919833362102509e-02
    z[0,5,4]  R301      3.9742198586463928e-01
    z[0,5,4]  R302      1.0552708804607391e-01
    z[0,5,4]  R303      -1.6130340099334717e-01
    z[0,5,4]  R304      3.4851184487342834e-01
    z[0,5,4]  R305      -6.9361016154289246e-02
    z[0,5,4]  R306      1.2959606945514679e-01
    z[0,5,4]  R307      5.6489646434783936e-01
    z[0,5,4]  R308      4.8991441726684570e-03
    z[0,5,4]  R309      -2.3312436044216156e-01
    z[0,5,4]  R310      1.7073912918567657e-01
    z[0,5,4]  R311      2.7820253372192383e-01
    z[0,5,4]  R312      4.2034569382667542e-01
    z[0,5,4]  R313      1.9361329078674316e-01
    z[0,5,4]  R314      -2.8481376171112061e-01
    z[0,5,4]  R315      -2.1803827583789825e-01
    z[0,5,4]  R316      4.5129823684692383e-01
    z[0,5,4]  R317      1.5675261616706848e-01
    z[0,5,4]  R318      2.2391228377819061e-01
    z[0,5,4]  R319      -4.6196451783180237e-01
    z[0,5,4]  R320      -1.4771398901939392e-01
    z[0,5,4]  R321      -5.1097828149795532e-01
    z[0,5,4]  R322      -5.4421371221542358e-01
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R250      -1
    z[0,5,5]  R251      1
    z[0,5,5]  R254      -4.4263872504234314e-01
    z[0,5,5]  R255      -3.2308492064476013e-01
    z[0,5,5]  R256      -6.4944040775299072e-01
    z[0,5,5]  R257      4.9100711476057768e-04
    z[0,5,5]  R258      -0.862942636013031
    z[0,5,5]  R259      5.4489824920892715e-02
    z[0,5,5]  R260      -0.509451687335968
    z[0,5,5]  R261      3.9412174373865128e-02
    z[0,5,5]  R262      -6.0844719409942627e-01
    z[0,5,5]  R263      0.385626882314682
    z[0,5,5]  R264      5.3227208554744720e-02
    z[0,5,5]  R265      1.0986543446779251e-01
    z[0,5,5]  R266      -8.7742723524570465e-02
    z[0,5,5]  R267      1.6445071995258331e-01
    z[0,5,5]  R268      3.7852725386619568e-01
    z[0,5,5]  R269      7.9666912555694580e-02
    z[0,5,5]  R270      -2.6526296138763428e-01
    z[0,5,5]  R271      -6.9492459297180176e-02
    z[0,5,5]  R272      -5.6996160745620728e-01
    z[0,5,5]  R273      -4.6937185525894165e-01
    z[0,5,5]  R274      -2.0916087925434113e-01
    z[0,5,5]  R275      -3.8129898905754089e-01
    z[0,5,5]  R276      4.6436417102813721e-01
    z[0,5,5]  R277      5.2960163354873657e-01
    z[0,5,5]  R278      1.3235104084014893e-01
    z[0,5,5]  R279      -1.4744228124618530e-01
    z[0,5,5]  R280      -4.2876243591308594e-01
    z[0,5,5]  R281      5.9810662269592285e-01
    z[0,5,5]  R282      -2.3030030727386475e-01
    z[0,5,5]  R283      -5.0800494849681854e-02
    z[0,5,5]  R284      -9.4277925789356232e-02
    z[0,5,5]  R285      9.2811174690723419e-02
    z[0,5,5]  R286      3.6907397210597992e-02
    z[0,5,5]  R287      -0.507040798664093
    z[0,5,5]  R288      1.0643025487661362e-01
    z[0,5,5]  R289      1.7220909893512726e-01
    z[0,5,5]  R290      -1.8397654639557004e-03
    z[0,5,5]  R291      7.0711962878704071e-02
    z[0,5,5]  R292      -3.0457055568695068e-01
    z[0,5,5]  R293      3.8770747184753418e-01
    z[0,5,5]  R294      2.7283772826194763e-01
    z[0,5,5]  R295      -1.4870515465736389e-01
    z[0,5,5]  R296      -3.4204626083374023e-01
    z[0,5,5]  R297      0.234819233417511
    z[0,5,5]  R298      5.3635202348232269e-03
    z[0,5,5]  R299      -3.6725349724292755e-02
    z[0,5,5]  R300      -6.6040062904357910e-01
    z[0,5,5]  R301      -5.4062157869338989e-01
    z[0,5,5]  R302      5.1187169551849365e-01
    z[0,5,5]  R303      -3.2207533717155457e-02
    z[0,5,5]  R304      1.4508533477783203e-01
    z[0,5,5]  R305      1.7681367695331573e-02
    z[0,5,5]  R306      -4.5329424738883972e-01
    z[0,5,5]  R307      -3.1563788652420044e-01
    z[0,5,5]  R308      -0.0409686341881752
    z[0,5,5]  R309      -1.5406748652458191e-01
    z[0,5,5]  R310      -2.9729914665222168e-01
    z[0,5,5]  R311      3.2862354069948196e-02
    z[0,5,5]  R312      3.7902233004570007e-01
    z[0,5,5]  R313      -3.7913236021995544e-01
    z[0,5,5]  R314      4.6682532876729965e-02
    z[0,5,5]  R315      1.8612703308463097e-02
    z[0,5,5]  R316      1.2646466493606567e-01
    z[0,5,5]  R317      1.7543736100196838e-01
    z[0,5,5]  R318      4.8359864950180054e-01
    z[0,5,5]  R319      -2.4371019005775452e-01
    z[0,5,5]  R320      3.6099547147750854e-01
    z[0,5,5]  R321      3.1019651889801025e-01
    z[0,5,5]  R322      5.7240617275238037e-01
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R252      -1
    z[0,5,6]  R253      1
    z[0,5,6]  R254      5.8195066452026367e-01
    z[0,5,6]  R255      1.7562672495841980e-01
    z[0,5,6]  R256      0.174094557762146
    z[0,5,6]  R257      4.9541077017784119e-01
    z[0,5,6]  R258      3.5434953868389130e-02
    z[0,5,6]  R259      7.5881689786911011e-01
    z[0,5,6]  R260      6.0374997556209564e-02
    z[0,5,6]  R261      2.1679243445396423e-01
    z[0,5,6]  R262      -0.199550062417984
    z[0,5,6]  R263      1.3278649747371674e-01
    z[0,5,6]  R264      -2.7512687444686890e-01
    z[0,5,6]  R265      -6.0125261545181274e-01
    z[0,5,6]  R266      -6.3623321056365967e-01
    z[0,5,6]  R267      4.1176278144121170e-02
    z[0,5,6]  R268      -5.9603631496429443e-01
    z[0,5,6]  R269      -4.2863118648529053e-01
    z[0,5,6]  R270      -3.4942615032196045e-01
    z[0,5,6]  R271      3.7523031234741211e-01
    z[0,5,6]  R272      3.6570286750793457e-01
    z[0,5,6]  R273      1.6311649978160858e-01
    z[0,5,6]  R274      6.9254361093044281e-02
    z[0,5,6]  R275      5.6397481821477413e-03
    z[0,5,6]  R276      -1.6104708611965179e-01
    z[0,5,6]  R277      -2.0059740543365479e-01
    z[0,5,6]  R278      4.1145539283752441e-01
    z[0,5,6]  R279      -3.0775046348571777e-01
    z[0,5,6]  R280      -2.9928398132324219e-01
    z[0,5,6]  R281      2.9043078422546387e-02
    z[0,5,6]  R282      7.1816682815551758e-01
    z[0,5,6]  R283      -2.3464743793010712e-01
    z[0,5,6]  R284      -0.00269176228903234
    z[0,5,6]  R285      -2.0108632743358612e-02
    z[0,5,6]  R286      -9.2202380299568176e-02
    z[0,5,6]  R287      -3.0818411707878113e-01
    z[0,5,6]  R288      2.7658066153526306e-01
    z[0,5,6]  R289      -3.6036711931228638e-01
    z[0,5,6]  R290      -2.0022788643836975e-01
    z[0,5,6]  R291      3.8570842146873474e-01
    z[0,5,6]  R292      4.3169371783733368e-02
    z[0,5,6]  R293      -2.3951490223407745e-01
    z[0,5,6]  R294      2.3476506769657135e-01
    z[0,5,6]  R295      -5.2156221866607666e-01
    z[0,5,6]  R296      -4.1077283024787903e-01
    z[0,5,6]  R297      -3.8127502799034119e-01
    z[0,5,6]  R298      7.4389182031154633e-02
    z[0,5,6]  R299      -5.8623957633972168e-01
    z[0,5,6]  R300      -1.9564349949359894e-01
    z[0,5,6]  R301      1.0843480378389359e-01
    z[0,5,6]  R302      3.2398089766502380e-01
    z[0,5,6]  R303      4.0459696203470230e-02
    z[0,5,6]  R304      1.4328195713460445e-02
    z[0,5,6]  R305      3.8968941569328308e-01
    z[0,5,6]  R306      -5.0769710540771484e-01
    z[0,5,6]  R307      -5.2033182233572006e-02
    z[0,5,6]  R308      -2.9633262753486633e-01
    z[0,5,6]  R309      1.1406043171882629e-01
    z[0,5,6]  R310      1.0423842817544937e-01
    z[0,5,6]  R311      3.0068987607955933e-01
    z[0,5,6]  R312      2.0920639857649803e-02
    z[0,5,6]  R313      -2.9510427266359329e-02
    z[0,5,6]  R314      -2.2846154868602753e-01
    z[0,5,6]  R315      7.8258194029331207e-02
    z[0,5,6]  R316      -9.1191329061985016e-02
    z[0,5,6]  R317      1.6566129028797150e-01
    z[0,5,6]  R318      -4.1446119546890259e-02
    z[0,5,6]  R319      3.5865768790245056e-01
    z[0,5,6]  R320      2.5416895747184753e-01
    z[0,5,6]  R321      -5.0566267222166061e-02
    z[0,5,6]  R322      2.9101157188415527e-01
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R323      -1
    z[5,0,0]  R324      1
    z[5,0,0]  R337      -2.4731977283954620e-01
    z[5,0,0]  R338      0.085629403591156
    z[5,0,0]  R339      5.9188399463891983e-02
    z[5,0,0]  R340      -1.6589473187923431e-01
    z[5,0,0]  R341      -1.7032325267791748e-02
    z[5,0,0]  R342      -4.5395351946353912e-02
    z[5,0,0]  R343      -1.6201204061508179e-01
    z[5,0,0]  R344      -1.8934737890958786e-02
    z[5,0,0]  R345      0.150125190615654
    z[5,0,0]  R346      -3.8735404610633850e-01
    z[5,0,0]  R347      -2.1382641792297363e-01
    z[5,0,0]  R348      -3.5925221443176270e-01
    z[5,0,0]  R349      -3.9004248380661011e-01
    z[5,0,0]  R350      -8.7264098227024078e-02
    z[5,0,0]  R351      1.8645381554961205e-02
    z[5,0,0]  R352      -3.1487077474594116e-01
    z[5,0,0]  R353      -6.3983634114265442e-02
    z[5,0,0]  R354      3.1601474620401859e-03
    z[5,0,0]  R355      2.7315232157707214e-01
    z[5,0,0]  R356      -1.1055515706539154e-01
    z[5,0,0]  R357      -5.3513408638536930e-03
    z[5,0,0]  R358      1.9580383598804474e-01
    z[5,0,0]  R359      4.4064730405807495e-01
    z[5,0,0]  R360      2.6081116870045662e-02
    z[5,0,0]  R361      2.1425299346446991e-01
    z[5,0,0]  R362      -2.5385084748268127e-01
    z[5,0,0]  R363      -5.7478111237287521e-02
    z[5,0,0]  R364      8.5354052484035492e-02
    z[5,0,0]  R365      2.3851613700389862e-01
    z[5,0,0]  R366      -1.3423493504524231e-01
    z[5,0,0]  R367      -3.6913685500621796e-02
    z[5,0,0]  R368      -2.1532289683818817e-01
    z[5,0,0]  R369      -2.3875330388545990e-01
    z[5,0,0]  R370      9.2885173857212067e-02
    z[5,0,0]  R371      5.3868040442466736e-02
    z[5,0,0]  R372      1.3729308545589447e-01
    z[5,0,0]  R373      1.9400085508823395e-01
    z[5,0,0]  R374      2.4801792204380035e-01
    z[5,0,0]  R375      5.0494468212127686e-01
    z[5,0,0]  R376      2.1552659571170807e-01
    z[5,0,0]  R377      -3.4287452697753906e-01
    z[5,0,0]  R378      -4.0462991595268250e-01
    z[5,0,0]  R379      3.7694208323955536e-02
    z[5,0,0]  R380      -2.1607734262943268e-01
    z[5,0,0]  R381      7.0514534600079060e-03
    z[5,0,0]  R382      -9.2090949416160583e-02
    z[5,0,0]  R383      -3.0757073312997818e-02
    z[5,0,0]  R384      -4.2781847715377808e-01
    z[5,0,0]  R385      1.9809107482433319e-01
    z[5,0,0]  R386      -0.52741938829422
    z[5,0,0]  R387      5.3257548809051514e-01
    z[5,0,0]  R388      -4.4982209801673889e-01
    z[5,0,0]  R389      -6.2833124399185181e-01
    z[5,0,0]  R390      6.3420593738555908e-01
    z[5,0,0]  R391      4.4936975836753845e-01
    z[5,0,0]  R392      3.0873997602611780e-03
    z[5,0,0]  R393      7.9878136515617371e-02
    z[5,0,0]  R394      -4.8687633126974106e-02
    z[5,0,0]  R395      -1.1559718102216721e-01
    z[5,0,0]  R396      -8.0589324235916138e-01
    z[5,0,0]  R397      -3.6386001110076904e-01
    z[5,0,0]  R398      -1.4979280531406403e-01
    z[5,0,0]  R399      -0.760092556476593
    z[5,0,0]  R400      1.8498468399047852e-01
    z[5,0,0]  R401      -5.6739991903305054e-01
    z[5,0,0]  R402      5.0882941484451294e-01
    z[5,0,0]  R403      2.8322085738182068e-01
    z[5,0,0]  R404      -3.1851518154144287e-01
    z[5,0,0]  R405      -2.6721498370170593e-01
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R325      -1
    z[5,0,1]  R326      1
    z[5,0,1]  R337      9.2446643114089966e-01
    z[5,0,1]  R338      9.8886710405349731e-01
    z[5,0,1]  R339      -3.0416840687394142e-02
    z[5,0,1]  R340      6.3676489517092705e-03
    z[5,0,1]  R341      5.7651054859161377e-01
    z[5,0,1]  R342      -3.4543506801128387e-02
    z[5,0,1]  R343      -0.0232999287545681
    z[5,0,1]  R344      -3.5011786967515945e-02
    z[5,0,1]  R345      -6.4352788031101227e-02
    z[5,0,1]  R346      -5.5713269859552383e-02
    z[5,0,1]  R347      -6.2276363372802734e-01
    z[5,0,1]  R348      -6.0613393783569336e-01
    z[5,0,1]  R349      -0.557383120059967
    z[5,0,1]  R350      -5.5232745409011841e-01
    z[5,0,1]  R351      -5.3412622213363647e-01
    z[5,0,1]  R352      -5.6050300598144531e-01
    z[5,0,1]  R353      -4.9303579330444336e-01
    z[5,0,1]  R354      -5.4293894767761230e-01
    z[5,0,1]  R355      -5.5307763814926147e-01
    z[5,0,1]  R356      -4.9725890159606934e-01
    z[5,0,1]  R357      -9.8264390230178833e-01
    z[5,0,1]  R358      -7.9808372259140015e-01
    z[5,0,1]  R359      -6.5045034885406494e-01
    z[5,0,1]  R360      -4.5593962073326111e-01
    z[5,0,1]  R361      0.483502060174942
    z[5,0,1]  R362      6.7729687690734863e-01
    z[5,0,1]  R363      5.8949595689773560e-01
    z[5,0,1]  R364      3.5691463947296143e-01
    z[5,0,1]  R365      7.8776067495346069e-01
    z[5,0,1]  R366      5.6254655122756958e-01
    z[5,0,1]  R367      0.73489910364151
    z[5,0,1]  R368      0.717809796333313
    z[5,0,1]  R369      8.3352595567703247e-01
    z[5,0,1]  R370      7.7697873115539551e-01
    z[5,0,1]  R371      6.3356381654739380e-01
    z[5,0,1]  R372      6.9384175539016724e-01
    z[5,0,1]  R373      7.0997720956802368e-01
    z[5,0,1]  R374      7.7718651294708252e-01
    z[5,0,1]  R375      -2.2949238121509552e-01
    z[5,0,1]  R376      -7.7543258666992188e-02
    z[5,0,1]  R377      -2.1722352504730225e-01
    z[5,0,1]  R378      -3.3881747722625732e-01
    z[5,0,1]  R379      -3.5317912697792053e-01
    z[5,0,1]  R380      -1.1785881221294403e-01
    z[5,0,1]  R381      1.5025387704372406e-01
    z[5,0,1]  R382      -1.1684845387935638e-01
    z[5,0,1]  R383      -1.2291974574327469e-01
    z[5,0,1]  R384      7.0135104656219482e-01
    z[5,0,1]  R385      3.1342241168022156e-01
    z[5,0,1]  R386      -3.4877327084541321e-01
    z[5,0,1]  R387      -6.9436973333358765e-01
    z[5,0,1]  R388      -6.0412913560867310e-01
    z[5,0,1]  R389      1.9119927287101746e-01
    z[5,0,1]  R390      5.9598058462142944e-01
    z[5,0,1]  R391      4.9876987934112549e-01
    z[5,0,1]  R392      3.9404088258743286e-01
    z[5,0,1]  R393      4.5466876029968262e-01
    z[5,0,1]  R394      -3.1880775094032288e-01
    z[5,0,1]  R395      -2.8397932648658752e-01
    z[5,0,1]  R396      2.0254749059677124e-01
    z[5,0,1]  R397      4.8817163705825806e-01
    z[5,0,1]  R398      -1.1145620793104172e-01
    z[5,0,1]  R399      1.0701826214790344e-01
    z[5,0,1]  R400      6.8404936790466309e-01
    z[5,0,1]  R401      -5.0725072622299194e-01
    z[5,0,1]  R402      5.4800343513488770e-01
    z[5,0,1]  R403      6.8713134527206421e-01
    z[5,0,1]  R404      -0.327234148979187
    z[5,0,1]  R405      -2.9164829850196838e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R327      -1
    z[5,0,2]  R328      1
    z[5,0,2]  R337      8.9352488517761230e-02
    z[5,0,2]  R338      -0.0491953007876873
    z[5,0,2]  R339      -7.9013854265213013e-01
    z[5,0,2]  R340      -6.8222486972808838e-01
    z[5,0,2]  R341      -1.4217109978199005e-01
    z[5,0,2]  R342      -5.9088891744613647e-01
    z[5,0,2]  R343      -8.1355655193328857e-01
    z[5,0,2]  R344      -5.0917977094650269e-01
    z[5,0,2]  R345      -4.6965035796165466e-01
    z[5,0,2]  R346      -6.6920286417007446e-01
    z[5,0,2]  R347      1.2158872932195663e-01
    z[5,0,2]  R348      4.0791156888008118e-01
    z[5,0,2]  R349      -3.8222637772560120e-01
    z[5,0,2]  R350      -5.6150525808334351e-01
    z[5,0,2]  R351      -3.2182133197784424e-01
    z[5,0,2]  R352      -5.4858695715665817e-02
    z[5,0,2]  R353      -2.4375198781490326e-01
    z[5,0,2]  R354      -1.9812296330928802e-01
    z[5,0,2]  R355      3.9448940753936768e-01
    z[5,0,2]  R356      5.7450169324874878e-01
    z[5,0,2]  R357      -0.0683421716094017
    z[5,0,2]  R358      -2.9872161149978638e-01
    z[5,0,2]  R359      -3.4258782863616943e-02
    z[5,0,2]  R360      -2.4924477934837341e-01
    z[5,0,2]  R361      4.2520549893379211e-01
    z[5,0,2]  R362      3.0196332931518555e-01
    z[5,0,2]  R363      4.8791524767875671e-01
    z[5,0,2]  R364      6.5476822853088379e-01
    z[5,0,2]  R365      3.7515634298324585e-01
    z[5,0,2]  R366      5.4492139816284180e-01
    z[5,0,2]  R367      5.1817828416824341e-01
    z[5,0,2]  R368      2.5820646435022354e-02
    z[5,0,2]  R369      4.3365576863288879e-01
    z[5,0,2]  R370      2.0073603093624115e-01
    z[5,0,2]  R371      4.8572579026222229e-01
    z[5,0,2]  R372      -2.1406058967113495e-01
    z[5,0,2]  R373      1.0951752215623856e-01
    z[5,0,2]  R374      -3.0360126495361328e-01
    z[5,0,2]  R375      -5.7654780149459839e-01
    z[5,0,2]  R376      -4.5599821209907532e-01
    z[5,0,2]  R377      1.4503470063209534e-01
    z[5,0,2]  R378      -6.9570106267929077e-01
    z[5,0,2]  R379      -4.1466781497001648e-01
    z[5,0,2]  R380      -4.6698024868965149e-01
    z[5,0,2]  R381      -3.9024350047111511e-01
    z[5,0,2]  R382      6.9275557994842529e-02
    z[5,0,2]  R383      2.3258070647716522e-01
    z[5,0,2]  R384      1.1849571019411087e-02
    z[5,0,2]  R385      3.8501378148794174e-02
    z[5,0,2]  R386      4.6703982353210449e-01
    z[5,0,2]  R387      -1.9645893573760986e-01
    z[5,0,2]  R388      -1.5505827963352203e-01
    z[5,0,2]  R389      2.2549276053905487e-01
    z[5,0,2]  R390      -1.1909014731645584e-01
    z[5,0,2]  R391      1.3621711730957031e-01
    z[5,0,2]  R392      3.0358494259417057e-03
    z[5,0,2]  R393      5.9022486209869385e-01
    z[5,0,2]  R394      -1.7114135622978210e-01
    z[5,0,2]  R395      -1.5432457625865936e-01
    z[5,0,2]  R396      -1.3052079081535339e-01
    z[5,0,2]  R397      -4.7506070137023926e-01
    z[5,0,2]  R398      -5.8543598651885986e-01
    z[5,0,2]  R399      9.7700776532292366e-03
    z[5,0,2]  R400      -9.1965541243553162e-02
    z[5,0,2]  R401      5.2086919546127319e-02
    z[5,0,2]  R402      -2.5898671150207520e-01
    z[5,0,2]  R403      3.7725397944450378e-01
    z[5,0,2]  R404      2.9562157392501831e-01
    z[5,0,2]  R405      -3.5007035732269287e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R329      -1
    z[5,0,3]  R330      1
    z[5,0,3]  R337      -0.0918092280626297
    z[5,0,3]  R338      -5.7513605803251266e-02
    z[5,0,3]  R339      4.5418307185173035e-01
    z[5,0,3]  R340      7.7439472079277039e-02
    z[5,0,3]  R341      -4.7017872333526611e-01
    z[5,0,3]  R342      2.1625219285488129e-01
    z[5,0,3]  R343      1.2432087957859039e-01
    z[5,0,3]  R344      8.0524575710296631e-01
    z[5,0,3]  R345      2.2533978521823883e-01
    z[5,0,3]  R346      3.7645533680915833e-01
    z[5,0,3]  R347      -5.7087731361389160e-01
    z[5,0,3]  R348      3.2693132758140564e-01
    z[5,0,3]  R349      2.0445835590362549e-01
    z[5,0,3]  R350      -4.2540755122900009e-02
    z[5,0,3]  R351      1.0242677479982376e-01
    z[5,0,3]  R352      5.6630659103393555e-01
    z[5,0,3]  R353      -3.0235049128532410e-01
    z[5,0,3]  R354      4.3067130446434021e-01
    z[5,0,3]  R355      -4.3552737683057785e-02
    z[5,0,3]  R356      -1.7985163629055023e-01
    z[5,0,3]  R357      -3.1912997364997864e-02
    z[5,0,3]  R358      3.0458664894104004e-01
    z[5,0,3]  R359      -4.7390836477279663e-01
    z[5,0,3]  R360      -4.9928811192512512e-01
    z[5,0,3]  R361      -3.4362620115280151e-01
    z[5,0,3]  R362      -5.4417955875396729e-01
    z[5,0,3]  R363      -5.6571716070175171e-01
    z[5,0,3]  R364      -5.5515849590301514e-01
    z[5,0,3]  R365      -1.1362207680940628e-01
    z[5,0,3]  R366      -2.1862530708312988e-01
    z[5,0,3]  R367      -8.9182555675506592e-02
    z[5,0,3]  R368      -5.4975038766860962e-01
    z[5,0,3]  R369      -7.8502416610717773e-02
    z[5,0,3]  R370      -3.4554621577262878e-01
    z[5,0,3]  R371      -0.526281476020813
    z[5,0,3]  R372      -4.1011002659797668e-01
    z[5,0,3]  R373      -2.1180368959903717e-01
    z[5,0,3]  R374      -1.5986070036888123e-01
    z[5,0,3]  R375      8.8934656232595444e-03
    z[5,0,3]  R376      1.7634023725986481e-01
    z[5,0,3]  R377      5.2300405502319336e-01
    z[5,0,3]  R378      -1.0115691274404526e-01
    z[5,0,3]  R379      4.6715912222862244e-01
    z[5,0,3]  R380      -1.5212836861610413e-01
    z[5,0,3]  R381      -0.165887251496315
    z[5,0,3]  R382      3.8981422781944275e-01
    z[5,0,3]  R383      2.3801697790622711e-01
    z[5,0,3]  R384      -4.4040897488594055e-01
    z[5,0,3]  R385      -2.2600656747817993e-01
    z[5,0,3]  R386      4.4847515225410461e-01
    z[5,0,3]  R387      3.3983027935028076e-01
    z[5,0,3]  R388      -1.5335313975811005e-01
    z[5,0,3]  R389      7.5554080307483673e-02
    z[5,0,3]  R390      -1.5334862470626831e-01
    z[5,0,3]  R391      -1.7881637811660767e-01
    z[5,0,3]  R392      8.0032050609588623e-01
    z[5,0,3]  R393      2.5405695661902428e-02
    z[5,0,3]  R394      -4.0245819091796875e-01
    z[5,0,3]  R395      -0.374159038066864
    z[5,0,3]  R396      -5.9671744704246521e-02
    z[5,0,3]  R397      5.9326660633087158e-01
    z[5,0,3]  R398      0.532675564289093
    z[5,0,3]  R399      2.8765746951103210e-01
    z[5,0,3]  R400      -3.7605494260787964e-01
    z[5,0,3]  R401      2.7694469690322876e-01
    z[5,0,3]  R402      -4.3913671374320984e-01
    z[5,0,3]  R403      -1.7861096560955048e-01
    z[5,0,3]  R404      3.9464709162712097e-01
    z[5,0,3]  R405      3.3547837287187576e-02
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R331      -1
    z[5,0,4]  R332      1
    z[5,0,4]  R337      -1.0070706158876419e-01
    z[5,0,4]  R338      -1.3634567148983479e-02
    z[5,0,4]  R339      -3.9490780234336853e-01
    z[5,0,4]  R340      -7.0081901550292969e-01
    z[5,0,4]  R341      -2.7202382683753967e-01
    z[5,0,4]  R342      -7.1624511480331421e-01
    z[5,0,4]  R343      -3.6926794052124023e-01
    z[5,0,4]  R344      -2.2502495348453522e-01
    z[5,0,4]  R345      -7.4040561914443970e-01
    z[5,0,4]  R346      -4.0332981944084167e-01
    z[5,0,4]  R347      1.3444192707538605e-01
    z[5,0,4]  R348      -3.1734594702720642e-01
    z[5,0,4]  R349      -2.3484092950820923e-01
    z[5,0,4]  R350      -2.9067406058311462e-01
    z[5,0,4]  R351      6.3229000568389893e-01
    z[5,0,4]  R352      -5.0736343860626221e-01
    z[5,0,4]  R353      0.506917417049408
    z[5,0,4]  R354      -7.7919833362102509e-02
    z[5,0,4]  R355      3.9742198586463928e-01
    z[5,0,4]  R356      1.0552708804607391e-01
    z[5,0,4]  R357      -1.6130340099334717e-01
    z[5,0,4]  R358      3.4851184487342834e-01
    z[5,0,4]  R359      -6.9361016154289246e-02
    z[5,0,4]  R360      1.2959606945514679e-01
    z[5,0,4]  R361      5.6489646434783936e-01
    z[5,0,4]  R362      4.8991441726684570e-03
    z[5,0,4]  R363      -2.3312436044216156e-01
    z[5,0,4]  R364      1.7073912918567657e-01
    z[5,0,4]  R365      2.7820253372192383e-01
    z[5,0,4]  R366      4.2034569382667542e-01
    z[5,0,4]  R367      1.9361329078674316e-01
    z[5,0,4]  R368      -2.8481376171112061e-01
    z[5,0,4]  R369      -2.1803827583789825e-01
    z[5,0,4]  R370      4.5129823684692383e-01
    z[5,0,4]  R371      1.5675261616706848e-01
    z[5,0,4]  R372      2.2391228377819061e-01
    z[5,0,4]  R373      -4.6196451783180237e-01
    z[5,0,4]  R374      -1.4771398901939392e-01
    z[5,0,4]  R375      -5.1097828149795532e-01
    z[5,0,4]  R376      -5.4421371221542358e-01
    z[5,0,4]  R377      7.8019194304943085e-02
    z[5,0,4]  R378      3.0334141850471497e-01
    z[5,0,4]  R379      -1.7769330739974976e-01
    z[5,0,4]  R380      -0.672885000705719
    z[5,0,4]  R381      -0.227244034409523
    z[5,0,4]  R382      -4.9227970838546753e-01
    z[5,0,4]  R383      -7.8103309869766235e-01
    z[5,0,4]  R384      -2.8709790110588074e-01
    z[5,0,4]  R385      -6.3240557909011841e-01
    z[5,0,4]  R386      1.2078670412302017e-01
    z[5,0,4]  R387      -4.0066551417112350e-02
    z[5,0,4]  R388      -1.0748336464166641e-01
    z[5,0,4]  R389      3.1558805704116821e-01
    z[5,0,4]  R390      4.1970506310462952e-01
    z[5,0,4]  R391      1.4935132116079330e-02
    z[5,0,4]  R392      -1.1886394768953323e-01
    z[5,0,4]  R393      4.9540087580680847e-01
    z[5,0,4]  R394      7.4773132801055908e-01
    z[5,0,4]  R395      5.3252893686294556e-01
    z[5,0,4]  R396      -2.0493234694004059e-01
    z[5,0,4]  R397      5.5696006864309311e-02
    z[5,0,4]  R398      -4.3959099054336548e-01
    z[5,0,4]  R399      -2.9392856359481812e-01
    z[5,0,4]  R400      1.6512106359004974e-01
    z[5,0,4]  R401      3.9310356974601746e-01
    z[5,0,4]  R402      -2.5381135940551758e-01
    z[5,0,4]  R403      2.4333505425602198e-03
    z[5,0,4]  R404      -4.3560588359832764e-01
    z[5,0,4]  R405      3.8866540789604187e-01
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R333      -1
    z[5,0,5]  R334      1
    z[5,0,5]  R337      -5.0800494849681854e-02
    z[5,0,5]  R338      -9.4277925789356232e-02
    z[5,0,5]  R339      9.2811174690723419e-02
    z[5,0,5]  R340      3.6907397210597992e-02
    z[5,0,5]  R341      -0.507040798664093
    z[5,0,5]  R342      1.0643025487661362e-01
    z[5,0,5]  R343      1.7220909893512726e-01
    z[5,0,5]  R344      -1.8397654639557004e-03
    z[5,0,5]  R345      7.0711962878704071e-02
    z[5,0,5]  R346      -3.0457055568695068e-01
    z[5,0,5]  R347      3.8770747184753418e-01
    z[5,0,5]  R348      2.7283772826194763e-01
    z[5,0,5]  R349      -1.4870515465736389e-01
    z[5,0,5]  R350      -3.4204626083374023e-01
    z[5,0,5]  R351      0.234819233417511
    z[5,0,5]  R352      5.3635202348232269e-03
    z[5,0,5]  R353      -3.6725349724292755e-02
    z[5,0,5]  R354      -6.6040062904357910e-01
    z[5,0,5]  R355      -5.4062157869338989e-01
    z[5,0,5]  R356      5.1187169551849365e-01
    z[5,0,5]  R357      -3.2207533717155457e-02
    z[5,0,5]  R358      1.4508533477783203e-01
    z[5,0,5]  R359      1.7681367695331573e-02
    z[5,0,5]  R360      -4.5329424738883972e-01
    z[5,0,5]  R361      -3.1563788652420044e-01
    z[5,0,5]  R362      -0.0409686341881752
    z[5,0,5]  R363      -1.5406748652458191e-01
    z[5,0,5]  R364      -2.9729914665222168e-01
    z[5,0,5]  R365      3.2862354069948196e-02
    z[5,0,5]  R366      3.7902233004570007e-01
    z[5,0,5]  R367      -3.7913236021995544e-01
    z[5,0,5]  R368      4.6682532876729965e-02
    z[5,0,5]  R369      1.8612703308463097e-02
    z[5,0,5]  R370      1.2646466493606567e-01
    z[5,0,5]  R371      1.7543736100196838e-01
    z[5,0,5]  R372      4.8359864950180054e-01
    z[5,0,5]  R373      -2.4371019005775452e-01
    z[5,0,5]  R374      3.6099547147750854e-01
    z[5,0,5]  R375      3.1019651889801025e-01
    z[5,0,5]  R376      5.7240617275238037e-01
    z[5,0,5]  R377      -4.4263872504234314e-01
    z[5,0,5]  R378      -3.2308492064476013e-01
    z[5,0,5]  R379      -6.4944040775299072e-01
    z[5,0,5]  R380      4.9100711476057768e-04
    z[5,0,5]  R381      -0.862942636013031
    z[5,0,5]  R382      5.4489824920892715e-02
    z[5,0,5]  R383      -0.509451687335968
    z[5,0,5]  R384      3.9412174373865128e-02
    z[5,0,5]  R385      -6.0844719409942627e-01
    z[5,0,5]  R386      0.385626882314682
    z[5,0,5]  R387      5.3227208554744720e-02
    z[5,0,5]  R388      1.0986543446779251e-01
    z[5,0,5]  R389      -8.7742723524570465e-02
    z[5,0,5]  R390      1.6445071995258331e-01
    z[5,0,5]  R391      3.7852725386619568e-01
    z[5,0,5]  R392      7.9666912555694580e-02
    z[5,0,5]  R393      -2.6526296138763428e-01
    z[5,0,5]  R394      -6.9492459297180176e-02
    z[5,0,5]  R395      -5.6996160745620728e-01
    z[5,0,5]  R396      -4.6937185525894165e-01
    z[5,0,5]  R397      -2.0916087925434113e-01
    z[5,0,5]  R398      -3.8129898905754089e-01
    z[5,0,5]  R399      4.6436417102813721e-01
    z[5,0,5]  R400      5.2960163354873657e-01
    z[5,0,5]  R401      1.3235104084014893e-01
    z[5,0,5]  R402      -1.4744228124618530e-01
    z[5,0,5]  R403      -4.2876243591308594e-01
    z[5,0,5]  R404      5.9810662269592285e-01
    z[5,0,5]  R405      -2.3030030727386475e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R335      -1
    z[5,0,6]  R336      1
    z[5,0,6]  R337      -2.3464743793010712e-01
    z[5,0,6]  R338      -0.00269176228903234
    z[5,0,6]  R339      -2.0108632743358612e-02
    z[5,0,6]  R340      -9.2202380299568176e-02
    z[5,0,6]  R341      -3.0818411707878113e-01
    z[5,0,6]  R342      2.7658066153526306e-01
    z[5,0,6]  R343      -3.6036711931228638e-01
    z[5,0,6]  R344      -2.0022788643836975e-01
    z[5,0,6]  R345      3.8570842146873474e-01
    z[5,0,6]  R346      4.3169371783733368e-02
    z[5,0,6]  R347      -2.3951490223407745e-01
    z[5,0,6]  R348      2.3476506769657135e-01
    z[5,0,6]  R349      -5.2156221866607666e-01
    z[5,0,6]  R350      -4.1077283024787903e-01
    z[5,0,6]  R351      -3.8127502799034119e-01
    z[5,0,6]  R352      7.4389182031154633e-02
    z[5,0,6]  R353      -5.8623957633972168e-01
    z[5,0,6]  R354      -1.9564349949359894e-01
    z[5,0,6]  R355      1.0843480378389359e-01
    z[5,0,6]  R356      3.2398089766502380e-01
    z[5,0,6]  R357      4.0459696203470230e-02
    z[5,0,6]  R358      1.4328195713460445e-02
    z[5,0,6]  R359      3.8968941569328308e-01
    z[5,0,6]  R360      -5.0769710540771484e-01
    z[5,0,6]  R361      -5.2033182233572006e-02
    z[5,0,6]  R362      -2.9633262753486633e-01
    z[5,0,6]  R363      1.1406043171882629e-01
    z[5,0,6]  R364      1.0423842817544937e-01
    z[5,0,6]  R365      3.0068987607955933e-01
    z[5,0,6]  R366      2.0920639857649803e-02
    z[5,0,6]  R367      -2.9510427266359329e-02
    z[5,0,6]  R368      -2.2846154868602753e-01
    z[5,0,6]  R369      7.8258194029331207e-02
    z[5,0,6]  R370      -9.1191329061985016e-02
    z[5,0,6]  R371      1.6566129028797150e-01
    z[5,0,6]  R372      -4.1446119546890259e-02
    z[5,0,6]  R373      3.5865768790245056e-01
    z[5,0,6]  R374      2.5416895747184753e-01
    z[5,0,6]  R375      -5.0566267222166061e-02
    z[5,0,6]  R376      2.9101157188415527e-01
    z[5,0,6]  R377      5.8195066452026367e-01
    z[5,0,6]  R378      1.7562672495841980e-01
    z[5,0,6]  R379      0.174094557762146
    z[5,0,6]  R380      4.9541077017784119e-01
    z[5,0,6]  R381      3.5434953868389130e-02
    z[5,0,6]  R382      7.5881689786911011e-01
    z[5,0,6]  R383      6.0374997556209564e-02
    z[5,0,6]  R384      2.1679243445396423e-01
    z[5,0,6]  R385      -0.199550062417984
    z[5,0,6]  R386      1.3278649747371674e-01
    z[5,0,6]  R387      -2.7512687444686890e-01
    z[5,0,6]  R388      -6.0125261545181274e-01
    z[5,0,6]  R389      -6.3623321056365967e-01
    z[5,0,6]  R390      4.1176278144121170e-02
    z[5,0,6]  R391      -5.9603631496429443e-01
    z[5,0,6]  R392      -4.2863118648529053e-01
    z[5,0,6]  R393      -3.4942615032196045e-01
    z[5,0,6]  R394      3.7523031234741211e-01
    z[5,0,6]  R395      3.6570286750793457e-01
    z[5,0,6]  R396      1.6311649978160858e-01
    z[5,0,6]  R397      6.9254361093044281e-02
    z[5,0,6]  R398      5.6397481821477413e-03
    z[5,0,6]  R399      -1.6104708611965179e-01
    z[5,0,6]  R400      -2.0059740543365479e-01
    z[5,0,6]  R401      4.1145539283752441e-01
    z[5,0,6]  R402      -3.0775046348571777e-01
    z[5,0,6]  R403      -2.9928398132324219e-01
    z[5,0,6]  R404      2.9043078422546387e-02
    z[5,0,6]  R405      7.1816682815551758e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R449      -1
    z[1,2,0]  R450      1
    z[1,2,0]  R463      1.4682796597480774e-01
    z[1,2,0]  R464      -1.9448599219322205e-01
    z[1,2,0]  R465      -7.6547443866729736e-01
    z[1,2,0]  R466      -7.8703552484512329e-01
    z[1,2,0]  R467      -7.6065880060195923e-01
    z[1,2,0]  R468      -6.8503272533416748e-01
    z[1,2,0]  R469      -6.9114369153976440e-01
    z[1,2,0]  R470      -6.5381234884262085e-01
    z[1,2,0]  R471      -9.3975865840911865e-01
    z[1,2,0]  R472      -8.9000082015991211e-01
    z[1,2,0]  R473      1.1959818750619888e-01
    z[1,2,0]  R474      -2.8266675770282745e-02
    z[1,2,0]  R475      -3.5147402435541153e-02
    z[1,2,0]  R476      -5.2857872098684311e-02
    z[1,2,0]  R477      2.5732627511024475e-01
    z[1,2,0]  R478      3.3204281330108643e-01
    z[1,2,0]  R479      0.0271154772490263
    z[1,2,0]  R480      2.2598467767238617e-01
    z[1,2,0]  R481      -2.0111760124564171e-02
    z[1,2,0]  R482      4.0740448981523514e-02
    z[1,2,0]  R483      -9.2747874557971954e-02
    z[1,2,0]  R484      -2.0706218481063843e-01
    z[1,2,0]  R485      -1.4613938517868519e-02
    z[1,2,0]  R486      -2.3697561025619507e-01
    z[1,2,0]  R487      4.6550330519676208e-01
    z[1,2,0]  R488      3.2529163360595703e-01
    z[1,2,0]  R489      1.3015180826187134e-01
    z[1,2,0]  R490      2.8493487834930420e-01
    z[1,2,0]  R491      3.9687082171440125e-02
    z[1,2,0]  R492      -2.0952665805816650e-01
    z[1,2,0]  R493      -1.8916824460029602e-01
    z[1,2,0]  R494      -2.1669808030128479e-01
    z[1,2,0]  R495      -4.5104026794433594e-02
    z[1,2,0]  R496      3.3271864056587219e-02
    z[1,2,0]  R497      -3.1536030769348145e-01
    z[1,2,0]  R498      -2.4552899599075317e-01
    z[1,2,0]  R499      2.7699765563011169e-01
    z[1,2,0]  R500      2.2148096561431885e-01
    z[1,2,0]  R501      -9.6354849636554718e-02
    z[1,2,0]  R502      -9.6015587449073792e-02
    z[1,2,0]  R503      -5.8756476640701294e-01
    z[1,2,0]  R504      -7.9760897159576416e-01
    z[1,2,0]  R505      -5.8294034004211426e-01
    z[1,2,0]  R506      -6.3656675815582275e-01
    z[1,2,0]  R507      0.000665637431666255
    z[1,2,0]  R508      3.4158188104629517e-01
    z[1,2,0]  R509      3.1974050402641296e-01
    z[1,2,0]  R510      3.4665313363075256e-01
    z[1,2,0]  R511      1.9608055055141449e-01
    z[1,2,0]  R512      6.2233191728591919e-01
    z[1,2,0]  R513      1.2805898487567902e-01
    z[1,2,0]  R514      2.9837599396705627e-01
    z[1,2,0]  R515      5.3156417608261108e-01
    z[1,2,0]  R516      3.4490948915481567e-01
    z[1,2,0]  R517      5.7030439376831055e-01
    z[1,2,0]  R518      9.3179166316986084e-01
    z[1,2,0]  R519      8.4341913461685181e-01
    z[1,2,0]  R520      8.8378113508224487e-01
    z[1,2,0]  R521      8.3961808681488037e-01
    z[1,2,0]  R522      8.8593792915344238e-01
    z[1,2,0]  R523      1.4354000985622406e-01
    z[1,2,0]  R524      0.34108966588974
    z[1,2,0]  R525      1.1674237251281738e-01
    z[1,2,0]  R526      1.1136688292026520e-01
    z[1,2,0]  R527      4.5378932356834412e-01
    z[1,2,0]  R528      4.1349762678146362e-01
    z[1,2,0]  R529      6.7828559875488281e-01
    z[1,2,0]  R530      4.8787105083465576e-01
    z[1,2,0]  R531      3.5431259870529175e-01
    z[1,2,0]  R532      8.2129406929016113e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R451      -1
    z[1,2,1]  R452      1
    z[1,2,1]  R463      9.7079819440841675e-01
    z[1,2,1]  R464      6.4031040668487549e-01
    z[1,2,1]  R465      -0.138684943318367
    z[1,2,1]  R466      -1.3560040295124054e-01
    z[1,2,1]  R467      -5.1290322095155716e-02
    z[1,2,1]  R468      -0.0711161345243454
    z[1,2,1]  R469      1.1851778626441956e-01
    z[1,2,1]  R470      1.6843172907829285e-01
    z[1,2,1]  R471      9.2258296906948090e-02
    z[1,2,1]  R472      -1.0521542280912399e-01
    z[1,2,1]  R473      1.1808297038078308e-01
    z[1,2,1]  R474      -1.7224618792533875e-01
    z[1,2,1]  R475      -2.3573809862136841e-01
    z[1,2,1]  R476      -1.2717759609222412e-01
    z[1,2,1]  R477      -3.2212957739830017e-01
    z[1,2,1]  R478      -2.7359953522682190e-01
    z[1,2,1]  R479      -2.7333667874336243e-01
    z[1,2,1]  R480      -4.5951792597770691e-01
    z[1,2,1]  R481      -4.3252980709075928e-01
    z[1,2,1]  R482      -1.1579956859350204e-01
    z[1,2,1]  R483      -9.5399028062820435e-01
    z[1,2,1]  R484      -7.8108400106430054e-01
    z[1,2,1]  R485      -8.0746436119079590e-01
    z[1,2,1]  R486      -7.8210854530334473e-01
    z[1,2,1]  R487      -7.1410173177719116e-01
    z[1,2,1]  R488      -7.8637742996215820e-01
    z[1,2,1]  R489      -7.4421435594558716e-01
    z[1,2,1]  R490      -0.700564444065094
    z[1,2,1]  R491      -6.8744331598281860e-01
    z[1,2,1]  R492      -7.0553278923034668e-01
    z[1,2,1]  R493      5.8930778503417969e-01
    z[1,2,1]  R494      5.5380409955978394e-01
    z[1,2,1]  R495      -7.1062213182449341e-01
    z[1,2,1]  R496      7.0085096359252930e-01
    z[1,2,1]  R497      -6.4749735593795776e-01
    z[1,2,1]  R498      -5.9957367181777954e-01
    z[1,2,1]  R499      5.0419336557388306e-01
    z[1,2,1]  R500      0.506360650062561
    z[1,2,1]  R501      5.4126524925231934e-01
    z[1,2,1]  R502      -3.6219015717506409e-01
    z[1,2,1]  R503      -3.0761319398880005e-01
    z[1,2,1]  R504      -2.1458260715007782e-02
    z[1,2,1]  R505      -1.5686792135238647e-01
    z[1,2,1]  R506      -1.1779581010341644e-01
    z[1,2,1]  R507      -6.7735219001770020e-01
    z[1,2,1]  R508      0.693505585193634
    z[1,2,1]  R509      5.1017683744430542e-01
    z[1,2,1]  R510      0.678641140460968
    z[1,2,1]  R511      4.3037557601928711e-01
    z[1,2,1]  R512      -9.2120125889778137e-02
    z[1,2,1]  R513      7.4141013622283936e-01
    z[1,2,1]  R514      7.4333906173706055e-01
    z[1,2,1]  R515      6.6982412338256836e-01
    z[1,2,1]  R516      -5.7433068752288818e-01
    z[1,2,1]  R517      -4.5757806301116943e-01
    z[1,2,1]  R518      4.9543965607881546e-02
    z[1,2,1]  R519      2.1142403781414032e-01
    z[1,2,1]  R520      1.2041904032230377e-01
    z[1,2,1]  R521      1.6735802590847015e-01
    z[1,2,1]  R522      3.4211522340774536e-01
    z[1,2,1]  R523      8.5066372156143188e-01
    z[1,2,1]  R524      6.7517876625061035e-01
    z[1,2,1]  R525      7.0113706588745117e-01
    z[1,2,1]  R526      0.666340172290802
    z[1,2,1]  R527      -4.4583463668823242e-01
    z[1,2,1]  R528      -5.0902652740478516e-01
    z[1,2,1]  R529      -4.3175652623176575e-01
    z[1,2,1]  R530      -1.7618516087532043e-01
    z[1,2,1]  R531      -5.4970139265060425e-01
    z[1,2,1]  R532      -6.8831346929073334e-02
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R453      -1
    z[1,2,2]  R454      1
    z[1,2,2]  R463      -2.8458578512072563e-02
    z[1,2,2]  R464      9.8333068192005157e-02
    z[1,2,2]  R465      1.6744644939899445e-01
    z[1,2,2]  R466      -3.2325658202171326e-01
    z[1,2,2]  R467      9.7997933626174927e-02
    z[1,2,2]  R468      -5.4415683262050152e-03
    z[1,2,2]  R469      -0.257853627204895
    z[1,2,2]  R470      -3.0794674158096313e-01
    z[1,2,2]  R471      -2.4678991734981537e-01
    z[1,2,2]  R472      2.6114261150360107e-01
    z[1,2,2]  R473      0.527817964553833
    z[1,2,2]  R474      -4.0941774845123291e-01
    z[1,2,2]  R475      -4.9897426366806030e-01
    z[1,2,2]  R476      -7.5336736440658569e-01
    z[1,2,2]  R477      -4.1837871074676514e-01
    z[1,2,2]  R478      -6.3643521070480347e-01
    z[1,2,2]  R479      -3.6294567584991455e-01
    z[1,2,2]  R480      -6.7835921049118042e-01
    z[1,2,2]  R481      -2.8625974059104919e-01
    z[1,2,2]  R482      -0.603752076625824
    z[1,2,2]  R483      6.9415479898452759e-02
    z[1,2,2]  R484      -2.3059016466140747e-01
    z[1,2,2]  R485      3.4395694732666016e-01
    z[1,2,2]  R486      3.1662932038307190e-01
    z[1,2,2]  R487      -1.4114160835742950e-01
    z[1,2,2]  R488      -6.4147412776947021e-02
    z[1,2,2]  R489      -4.0544936060905457e-01
    z[1,2,2]  R490      7.3663949966430664e-02
    z[1,2,2]  R491      2.8105584904551506e-02
    z[1,2,2]  R492      4.0016758441925049e-01
    z[1,2,2]  R493      0.273367315530777
    z[1,2,2]  R494      7.4711114168167114e-01
    z[1,2,2]  R495      -4.7318261861801147e-01
    z[1,2,2]  R496      2.1705015003681183e-01
    z[1,2,2]  R497      3.5083245486021042e-02
    z[1,2,2]  R498      2.7878111600875854e-01
    z[1,2,2]  R499      2.4471163749694824e-01
    z[1,2,2]  R500      -1.4625380933284760e-01
    z[1,2,2]  R501      1.8711602687835693e-01
    z[1,2,2]  R502      -2.6298427581787109e-01
    z[1,2,2]  R503      2.5536981225013733e-01
    z[1,2,2]  R504      -8.0873884260654449e-02
    z[1,2,2]  R505      -7.4643611907958984e-01
    z[1,2,2]  R506      2.6601186394691467e-01
    z[1,2,2]  R507      -3.3538267016410828e-01
    z[1,2,2]  R508      3.3730635046958923e-01
    z[1,2,2]  R509      -5.7383030652999878e-01
    z[1,2,2]  R510      2.3722781240940094e-01
    z[1,2,2]  R511      -1.4183494448661804e-01
    z[1,2,2]  R512      -3.5477694869041443e-01
    z[1,2,2]  R513      -3.4747142344713211e-02
    z[1,2,2]  R514      4.0809872746467590e-01
    z[1,2,2]  R515      -1.4974361658096313e-01
    z[1,2,2]  R516      1.4509527385234833e-01
    z[1,2,2]  R517      2.3709741234779358e-01
    z[1,2,2]  R518      3.8914494216442108e-02
    z[1,2,2]  R519      8.1839226186275482e-02
    z[1,2,2]  R520      2.6590687036514282e-01
    z[1,2,2]  R521      1.2773790955543518e-01
    z[1,2,2]  R522      2.6197027415037155e-02
    z[1,2,2]  R523      -1.7921912670135498e-01
    z[1,2,2]  R524      -3.5935276746749878e-01
    z[1,2,2]  R525      2.6201415061950684e-01
    z[1,2,2]  R526      5.6552481651306152e-01
    z[1,2,2]  R527      -1.4974561333656311e-01
    z[1,2,2]  R528      -2.2675932943820953e-01
    z[1,2,2]  R529      -4.1336383670568466e-02
    z[1,2,2]  R530      1.3642235100269318e-01
    z[1,2,2]  R531      6.8221598863601685e-01
    z[1,2,2]  R532      -7.2196260094642639e-02
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R455      -1
    z[1,2,3]  R456      1
    z[1,2,3]  R463      -1.0652960836887360e-01
    z[1,2,3]  R464      -3.7224423885345459e-01
    z[1,2,3]  R465      5.8253329992294312e-01
    z[1,2,3]  R466      4.3245518207550049e-01
    z[1,2,3]  R467      4.9656990170478821e-01
    z[1,2,3]  R468      5.7550114393234253e-01
    z[1,2,3]  R469      5.2948659658432007e-01
    z[1,2,3]  R470      6.5426230430603027e-01
    z[1,2,3]  R471      9.0064838528633118e-02
    z[1,2,3]  R472      1.2413965165615082e-01
    z[1,2,3]  R473      7.1115463972091675e-02
    z[1,2,3]  R474      6.2369710206985474e-01
    z[1,2,3]  R475      4.5309442281723022e-01
    z[1,2,3]  R476      3.4645467996597290e-01
    z[1,2,3]  R477      5.4036104679107666e-01
    z[1,2,3]  R478      2.8364226222038269e-01
    z[1,2,3]  R479      7.6607018709182739e-01
    z[1,2,3]  R480      0.468136727809906
    z[1,2,3]  R481      2.8573292493820190e-01
    z[1,2,3]  R482      1.3243648409843445e-01
    z[1,2,3]  R483      1.1205623298883438e-01
    z[1,2,3]  R484      3.3471721410751343e-01
    z[1,2,3]  R485      4.3947091698646545e-01
    z[1,2,3]  R486      3.9231842756271362e-01
    z[1,2,3]  R487      3.9689761400222778e-01
    z[1,2,3]  R488      -7.3697227053344250e-03
    z[1,2,3]  R489      -1.6436351463198662e-02
    z[1,2,3]  R490      -4.0541672706604004e-01
    z[1,2,3]  R491      -6.1854767799377441e-01
    z[1,2,3]  R492      -3.1052476167678833e-01
    z[1,2,3]  R493      -4.6811640262603760e-01
    z[1,2,3]  R494      -2.9047888517379761e-01
    z[1,2,3]  R495      -4.2592954635620117e-01
    z[1,2,3]  R496      -5.0239515304565430e-01
    z[1,2,3]  R497      1.1542630381882191e-02
    z[1,2,3]  R498      -3.5988822579383850e-01
    z[1,2,3]  R499      -5.7506734132766724e-01
    z[1,2,3]  R500      -6.6924935579299927e-01
    z[1,2,3]  R501      -3.9783358573913574e-01
    z[1,2,3]  R502      4.7208401560783386e-01
    z[1,2,3]  R503      6.9872546195983887e-01
    z[1,2,3]  R504      -1.4361524581909180e-01
    z[1,2,3]  R505      -1.6800025105476379e-01
    z[1,2,3]  R506      -3.9234411716461182e-01
    z[1,2,3]  R507      -1.6036370769143105e-02
    z[1,2,3]  R508      3.7227776646614075e-01
    z[1,2,3]  R509      3.9219167828559875e-01
    z[1,2,3]  R510      2.6986068487167358e-01
    z[1,2,3]  R511      3.6536210775375366e-01
    z[1,2,3]  R512      2.0269700884819031e-01
    z[1,2,3]  R513      -3.0786329880356789e-02
    z[1,2,3]  R514      -3.0556395649909973e-01
    z[1,2,3]  R515      -2.9215618968009949e-01
    z[1,2,3]  R516      -3.1286829710006714e-01
    z[1,2,3]  R517      1.5310217440128326e-01
    z[1,2,3]  R518      -2.8971329331398010e-01
    z[1,2,3]  R519      -3.9567741751670837e-01
    z[1,2,3]  R520      -3.3423423767089844e-01
    z[1,2,3]  R521      -3.4821224212646484e-01
    z[1,2,3]  R522      -2.6191130280494690e-01
    z[1,2,3]  R523      8.6467579007148743e-02
    z[1,2,3]  R524      1.3405305147171021e-01
    z[1,2,3]  R525      1.1523726396262646e-02
    z[1,2,3]  R526      1.6345396637916565e-01
    z[1,2,3]  R527      1.2899482250213623e-01
    z[1,2,3]  R528      6.1010837554931641e-02
    z[1,2,3]  R529      2.9394409060478210e-01
    z[1,2,3]  R530      0.0871608629822731
    z[1,2,3]  R531      -2.4624569714069366e-01
    z[1,2,3]  R532      -1.4056387543678284e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R457      -1
    z[1,2,4]  R458      1
    z[1,2,4]  R463      -4.2701106518507004e-02
    z[1,2,4]  R464      -1.0903651267290115e-01
    z[1,2,4]  R465      -3.8109406828880310e-02
    z[1,2,4]  R466      -2.6365658640861511e-01
    z[1,2,4]  R467      -1.0086496174335480e-01
    z[1,2,4]  R468      -4.2758235335350037e-01
    z[1,2,4]  R469      -0.0987108051776886
    z[1,2,4]  R470      -1.8443804234266281e-02
    z[1,2,4]  R471      -8.4633342921733856e-02
    z[1,2,4]  R472      -1.1293911933898926e-01
    z[1,2,4]  R473      0.827197790145874
    z[1,2,4]  R474      -6.3351714611053467e-01
    z[1,2,4]  R475      -6.4652818441390991e-01
    z[1,2,4]  R476      -4.9971318244934082e-01
    z[1,2,4]  R477      -4.7033041715621948e-01
    z[1,2,4]  R478      -3.9395216107368469e-01
    z[1,2,4]  R479      -3.5066959261894226e-01
    z[1,2,4]  R480      -1.9051505625247955e-01
    z[1,2,4]  R481      -4.0630677342414856e-01
    z[1,2,4]  R482      -7.6303946971893311e-01
    z[1,2,4]  R483      3.2096426934003830e-02
    z[1,2,4]  R484      -1.1262485384941101e-01
    z[1,2,4]  R485      -1.1069152504205704e-02
    z[1,2,4]  R486      -8.4059886634349823e-02
    z[1,2,4]  R487      -0.0471460185945034
    z[1,2,4]  R488      -1.4118281193077564e-02
    z[1,2,4]  R489      4.1445949673652649e-01
    z[1,2,4]  R490      -5.0145995616912842e-01
    z[1,2,4]  R491      3.1634697318077087e-01
    z[1,2,4]  R492      3.2800965011119843e-02
    z[1,2,4]  R493      3.9694914221763611e-01
    z[1,2,4]  R494      -1.3578631915152073e-02
    z[1,2,4]  R495      -2.8430971503257751e-01
    z[1,2,4]  R496      -3.9041060209274292e-01
    z[1,2,4]  R497      4.7830536961555481e-01
    z[1,2,4]  R498      -2.0111978054046631e-01
    z[1,2,4]  R499      2.9851067066192627e-01
    z[1,2,4]  R500      -2.3639839142560959e-02
    z[1,2,4]  R501      -1.8404923379421234e-01
    z[1,2,4]  R502      -0.517731785774231
    z[1,2,4]  R503      -2.9354941099882126e-02
    z[1,2,4]  R504      -2.7737346291542053e-01
    z[1,2,4]  R505      -3.6460742354393005e-02
    z[1,2,4]  R506      3.5273800604045391e-03
    z[1,2,4]  R507      -2.1476107835769653e-01
    z[1,2,4]  R508      -2.2934643551707268e-02
    z[1,2,4]  R509      -7.9072043299674988e-02
    z[1,2,4]  R510      -3.5760810971260071e-01
    z[1,2,4]  R511      -7.7128744125366211e-01
    z[1,2,4]  R512      -3.8145750761032104e-01
    z[1,2,4]  R513      7.3071740567684174e-02
    z[1,2,4]  R514      -1.4902658760547638e-01
    z[1,2,4]  R515      3.9553143084049225e-02
    z[1,2,4]  R516      2.0750153809785843e-02
    z[1,2,4]  R517      2.4105429649353027e-01
    z[1,2,4]  R518      1.7101193964481354e-01
    z[1,2,4]  R519      0.0950782373547554
    z[1,2,4]  R520      -1.0960499197244644e-01
    z[1,2,4]  R521      1.5725545585155487e-01
    z[1,2,4]  R522      1.2200789898633957e-01
    z[1,2,4]  R523      2.8890535235404968e-01
    z[1,2,4]  R524      4.3241629004478455e-01
    z[1,2,4]  R525      -6.0956722497940063e-01
    z[1,2,4]  R526      3.5223352909088135e-01
    z[1,2,4]  R527      -1.6913086175918579e-01
    z[1,2,4]  R528      1.9742825627326965e-01
    z[1,2,4]  R529      0.330597460269928
    z[1,2,4]  R530      -7.7031159400939941e-01
    z[1,2,4]  R531      8.4561698138713837e-02
    z[1,2,4]  R532      3.0646726489067078e-02
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R459      -1
    z[1,2,5]  R460      1
    z[1,2,5]  R463      -1.3769541680812836e-01
    z[1,2,5]  R464      -0.563877522945404
    z[1,2,5]  R465      8.5845552384853363e-03
    z[1,2,5]  R466      0.00700989319011569
    z[1,2,5]  R467      -5.6152928620576859e-02
    z[1,2,5]  R468      9.8681680858135223e-02
    z[1,2,5]  R469      -3.2476380467414856e-01
    z[1,2,5]  R470      7.6823040843009949e-02
    z[1,2,5]  R471      3.4556340426206589e-02
    z[1,2,5]  R472      -2.9272469878196716e-01
    z[1,2,5]  R473      -1.5474167652428150e-02
    z[1,2,5]  R474      1.0599581152200699e-01
    z[1,2,5]  R475      -2.5980386137962341e-01
    z[1,2,5]  R476      1.1180879175662994e-01
    z[1,2,5]  R477      0.0648990347981453
    z[1,2,5]  R478      2.8234541416168213e-01
    z[1,2,5]  R479      2.7899768948554993e-01
    z[1,2,5]  R480      1.2590293586254120e-01
    z[1,2,5]  R481      6.7350721359252930e-01
    z[1,2,5]  R482      9.8208189010620117e-02
    z[1,2,5]  R483      2.0516207814216614e-01
    z[1,2,5]  R484      -0.364769846200943
    z[1,2,5]  R485      8.3711095154285431e-02
    z[1,2,5]  R486      -2.5648900866508484e-01
    z[1,2,5]  R487      -2.9499495029449463e-01
    z[1,2,5]  R488      -1.0593015700578690e-01
    z[1,2,5]  R489      -2.6589006185531616e-01
    z[1,2,5]  R490      -7.9941317439079285e-02
    z[1,2,5]  R491      2.0427992939949036e-01
    z[1,2,5]  R492      1.9457958638668060e-01
    z[1,2,5]  R493      -7.8477680683135986e-02
    z[1,2,5]  R494      -1.4952444471418858e-02
    z[1,2,5]  R495      -7.9793877899646759e-02
    z[1,2,5]  R496      -0.0723300352692604
    z[1,2,5]  R497      2.5796961784362793e-01
    z[1,2,5]  R498      -5.6732857227325439e-01
    z[1,2,5]  R499      3.7883457541465759e-01
    z[1,2,5]  R500      4.5789572596549988e-01
    z[1,2,5]  R501      6.8522137403488159e-01
    z[1,2,5]  R502      5.4043656587600708e-01
    z[1,2,5]  R503      3.7134058773517609e-02
    z[1,2,5]  R504      -4.3836227059364319e-01
    z[1,2,5]  R505      1.6207601130008698e-01
    z[1,2,5]  R506      2.8912666440010071e-01
    z[1,2,5]  R507      1.7371119558811188e-01
    z[1,2,5]  R508      -2.8155824542045593e-01
    z[1,2,5]  R509      -3.3294427394866943e-01
    z[1,2,5]  R510      -3.1217607855796814e-01
    z[1,2,5]  R511      1.6681528091430664e-01
    z[1,2,5]  R512      -7.6324068009853363e-02
    z[1,2,5]  R513      5.9478396177291870e-01
    z[1,2,5]  R514      1.4739955961704254e-01
    z[1,2,5]  R515      3.1917652487754822e-01
    z[1,2,5]  R516      -1.3296452164649963e-01
    z[1,2,5]  R517      2.2613622248172760e-02
    z[1,2,5]  R518      -1.2087034434080124e-01
    z[1,2,5]  R519      -2.4794960021972656e-01
    z[1,2,5]  R520      -0.0900367721915245
    z[1,2,5]  R521      -2.2938187420368195e-01
    z[1,2,5]  R522      -9.6857078373432159e-02
    z[1,2,5]  R523      -2.5553047657012939e-01
    z[1,2,5]  R524      2.6781976222991943e-01
    z[1,2,5]  R525      1.7074239253997803e-01
    z[1,2,5]  R526      1.9964082539081573e-01
    z[1,2,5]  R527      -3.0739307403564453e-02
    z[1,2,5]  R528      -5.4868847131729126e-01
    z[1,2,5]  R529      1.5081061422824860e-01
    z[1,2,5]  R530      5.5249845609068871e-03
    z[1,2,5]  R531      -8.0237448215484619e-02
    z[1,2,5]  R532      -5.4287576675415039e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R461      -1
    z[1,2,6]  R462      1
    z[1,2,6]  R463      -5.5232111364603043e-02
    z[1,2,6]  R464      -2.7220547199249268e-01
    z[1,2,6]  R465      1.6095350682735443e-01
    z[1,2,6]  R466      -3.3334780484437943e-02
    z[1,2,6]  R467      -3.8633573055267334e-01
    z[1,2,6]  R468      -4.3321792036294937e-02
    z[1,2,6]  R469      2.1497417986392975e-01
    z[1,2,6]  R470      1.2258848547935486e-01
    z[1,2,6]  R471      -1.7597796022891998e-01
    z[1,2,6]  R472      -1.2156955152750015e-01
    z[1,2,6]  R473      -0.0600656233727932
    z[1,2,6]  R474      -1.8227970227599144e-02
    z[1,2,6]  R475      5.8530010282993317e-02
    z[1,2,6]  R476      -1.7670390009880066e-01
    z[1,2,6]  R477      3.7089386582374573e-01
    z[1,2,6]  R478      3.0736133456230164e-01
    z[1,2,6]  R479      7.1762762963771820e-02
    z[1,2,6]  R480      7.9394921660423279e-02
    z[1,2,6]  R481      1.7386290431022644e-01
    z[1,2,6]  R482      1.0488359630107880e-01
    z[1,2,6]  R483      1.4423468708992004e-01
    z[1,2,6]  R484      -1.8995878100395203e-01
    z[1,2,6]  R485      -1.7092873156070709e-01
    z[1,2,6]  R486      7.1612037718296051e-02
    z[1,2,6]  R487      -8.1680983304977417e-02
    z[1,2,6]  R488      5.1010406017303467e-01
    z[1,2,6]  R489      -1.4856582880020142e-01
    z[1,2,6]  R490      -1.9486727192997932e-02
    z[1,2,6]  R491      2.5488814339041710e-02
    z[1,2,6]  R492      -0.40351602435112
    z[1,2,6]  R493      -3.9917615056037903e-01
    z[1,2,6]  R494      5.8154135942459106e-02
    z[1,2,6]  R495      2.1559296175837517e-02
    z[1,2,6]  R496      2.2480469942092896e-01
    z[1,2,6]  R497      -4.2965874075889587e-01
    z[1,2,6]  R498      1.0333219915628433e-01
    z[1,2,6]  R499      2.1412852406501770e-01
    z[1,2,6]  R500      1.2260851263999939e-01
    z[1,2,6]  R501      3.2578937709331512e-02
    z[1,2,6]  R502      -8.6356140673160553e-02
    z[1,2,6]  R503      6.6858351230621338e-02
    z[1,2,6]  R504      0.259028822183609
    z[1,2,6]  R505      1.5027964115142822e-01
    z[1,2,6]  R506      -5.2211493253707886e-01
    z[1,2,6]  R507      -5.9342807531356812e-01
    z[1,2,6]  R508      -2.6496127247810364e-01
    z[1,2,6]  R509      -1.9309477508068085e-01
    z[1,2,6]  R510      2.5463435053825378e-01
    z[1,2,6]  R511      -3.3253121655434370e-03
    z[1,2,6]  R512      5.3472322225570679e-01
    z[1,2,6]  R513      2.6953560113906860e-01
    z[1,2,6]  R514      2.3360078036785126e-01
    z[1,2,6]  R515      -2.3991394042968750e-01
    z[1,2,6]  R516      6.4353114366531372e-01
    z[1,2,6]  R517      5.7192766666412354e-01
    z[1,2,6]  R518      -2.5998631026595831e-03
    z[1,2,6]  R519      -1.0083127021789551e-01
    z[1,2,6]  R520      -4.3489582836627960e-02
    z[1,2,6]  R521      2.2829528152942657e-01
    z[1,2,6]  R522      6.7231371998786926e-02
    z[1,2,6]  R523      2.5963285565376282e-01
    z[1,2,6]  R524      -1.4824126660823822e-01
    z[1,2,6]  R525      -1.5896141529083252e-01
    z[1,2,6]  R526      1.8201065063476562e-01
    z[1,2,6]  R527      7.2573626041412354e-01
    z[1,2,6]  R528      4.1801032423973083e-01
    z[1,2,6]  R529      3.6519128084182739e-01
    z[1,2,6]  R530      3.3364954590797424e-01
    z[1,2,6]  R531      1.8068379163742065e-01
    z[1,2,6]  R532      -1.0695316828787327e-02
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R533      -1
    z[2,1,0]  R534      1
    z[2,1,0]  R547      -5.8756476640701294e-01
    z[2,1,0]  R548      -7.9760897159576416e-01
    z[2,1,0]  R549      -5.8294034004211426e-01
    z[2,1,0]  R550      -6.3656675815582275e-01
    z[2,1,0]  R551      0.000665637431666255
    z[2,1,0]  R552      3.4158188104629517e-01
    z[2,1,0]  R553      3.1974050402641296e-01
    z[2,1,0]  R554      3.4665313363075256e-01
    z[2,1,0]  R555      1.9608055055141449e-01
    z[2,1,0]  R556      6.2233191728591919e-01
    z[2,1,0]  R557      1.2805898487567902e-01
    z[2,1,0]  R558      2.9837599396705627e-01
    z[2,1,0]  R559      5.3156417608261108e-01
    z[2,1,0]  R560      3.4490948915481567e-01
    z[2,1,0]  R561      5.7030439376831055e-01
    z[2,1,0]  R562      9.3179166316986084e-01
    z[2,1,0]  R563      8.4341913461685181e-01
    z[2,1,0]  R564      8.8378113508224487e-01
    z[2,1,0]  R565      8.3961808681488037e-01
    z[2,1,0]  R566      8.8593792915344238e-01
    z[2,1,0]  R567      1.4354000985622406e-01
    z[2,1,0]  R568      0.34108966588974
    z[2,1,0]  R569      1.1674237251281738e-01
    z[2,1,0]  R570      1.1136688292026520e-01
    z[2,1,0]  R571      4.5378932356834412e-01
    z[2,1,0]  R572      4.1349762678146362e-01
    z[2,1,0]  R573      6.7828559875488281e-01
    z[2,1,0]  R574      4.8787105083465576e-01
    z[2,1,0]  R575      3.5431259870529175e-01
    z[2,1,0]  R576      8.2129406929016113e-01
    z[2,1,0]  R577      1.4682796597480774e-01
    z[2,1,0]  R578      -1.9448599219322205e-01
    z[2,1,0]  R579      -7.6547443866729736e-01
    z[2,1,0]  R580      -7.8703552484512329e-01
    z[2,1,0]  R581      -7.6065880060195923e-01
    z[2,1,0]  R582      -6.8503272533416748e-01
    z[2,1,0]  R583      -6.9114369153976440e-01
    z[2,1,0]  R584      -6.5381234884262085e-01
    z[2,1,0]  R585      -9.3975865840911865e-01
    z[2,1,0]  R586      -8.9000082015991211e-01
    z[2,1,0]  R587      1.1959818750619888e-01
    z[2,1,0]  R588      -2.8266675770282745e-02
    z[2,1,0]  R589      -3.5147402435541153e-02
    z[2,1,0]  R590      -5.2857872098684311e-02
    z[2,1,0]  R591      2.5732627511024475e-01
    z[2,1,0]  R592      3.3204281330108643e-01
    z[2,1,0]  R593      0.0271154772490263
    z[2,1,0]  R594      2.2598467767238617e-01
    z[2,1,0]  R595      -2.0111760124564171e-02
    z[2,1,0]  R596      4.0740448981523514e-02
    z[2,1,0]  R597      -9.2747874557971954e-02
    z[2,1,0]  R598      -2.0706218481063843e-01
    z[2,1,0]  R599      -1.4613938517868519e-02
    z[2,1,0]  R600      -2.3697561025619507e-01
    z[2,1,0]  R601      4.6550330519676208e-01
    z[2,1,0]  R602      3.2529163360595703e-01
    z[2,1,0]  R603      1.3015180826187134e-01
    z[2,1,0]  R604      2.8493487834930420e-01
    z[2,1,0]  R605      3.9687082171440125e-02
    z[2,1,0]  R606      -2.0952665805816650e-01
    z[2,1,0]  R607      -1.8916824460029602e-01
    z[2,1,0]  R608      -2.1669808030128479e-01
    z[2,1,0]  R609      -4.5104026794433594e-02
    z[2,1,0]  R610      3.3271864056587219e-02
    z[2,1,0]  R611      -3.1536030769348145e-01
    z[2,1,0]  R612      -2.4552899599075317e-01
    z[2,1,0]  R613      2.7699765563011169e-01
    z[2,1,0]  R614      2.2148096561431885e-01
    z[2,1,0]  R615      -9.6354849636554718e-02
    z[2,1,0]  R616      -9.6015587449073792e-02
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R535      -1
    z[2,1,1]  R536      1
    z[2,1,1]  R547      -3.0761319398880005e-01
    z[2,1,1]  R548      -2.1458260715007782e-02
    z[2,1,1]  R549      -1.5686792135238647e-01
    z[2,1,1]  R550      -1.1779581010341644e-01
    z[2,1,1]  R551      -6.7735219001770020e-01
    z[2,1,1]  R552      0.693505585193634
    z[2,1,1]  R553      5.1017683744430542e-01
    z[2,1,1]  R554      0.678641140460968
    z[2,1,1]  R555      4.3037557601928711e-01
    z[2,1,1]  R556      -9.2120125889778137e-02
    z[2,1,1]  R557      7.4141013622283936e-01
    z[2,1,1]  R558      7.4333906173706055e-01
    z[2,1,1]  R559      6.6982412338256836e-01
    z[2,1,1]  R560      -5.7433068752288818e-01
    z[2,1,1]  R561      -4.5757806301116943e-01
    z[2,1,1]  R562      4.9543965607881546e-02
    z[2,1,1]  R563      2.1142403781414032e-01
    z[2,1,1]  R564      1.2041904032230377e-01
    z[2,1,1]  R565      1.6735802590847015e-01
    z[2,1,1]  R566      3.4211522340774536e-01
    z[2,1,1]  R567      8.5066372156143188e-01
    z[2,1,1]  R568      6.7517876625061035e-01
    z[2,1,1]  R569      7.0113706588745117e-01
    z[2,1,1]  R570      0.666340172290802
    z[2,1,1]  R571      -4.4583463668823242e-01
    z[2,1,1]  R572      -5.0902652740478516e-01
    z[2,1,1]  R573      -4.3175652623176575e-01
    z[2,1,1]  R574      -1.7618516087532043e-01
    z[2,1,1]  R575      -5.4970139265060425e-01
    z[2,1,1]  R576      -6.8831346929073334e-02
    z[2,1,1]  R577      9.7079819440841675e-01
    z[2,1,1]  R578      6.4031040668487549e-01
    z[2,1,1]  R579      -0.138684943318367
    z[2,1,1]  R580      -1.3560040295124054e-01
    z[2,1,1]  R581      -5.1290322095155716e-02
    z[2,1,1]  R582      -0.0711161345243454
    z[2,1,1]  R583      1.1851778626441956e-01
    z[2,1,1]  R584      1.6843172907829285e-01
    z[2,1,1]  R585      9.2258296906948090e-02
    z[2,1,1]  R586      -1.0521542280912399e-01
    z[2,1,1]  R587      1.1808297038078308e-01
    z[2,1,1]  R588      -1.7224618792533875e-01
    z[2,1,1]  R589      -2.3573809862136841e-01
    z[2,1,1]  R590      -1.2717759609222412e-01
    z[2,1,1]  R591      -3.2212957739830017e-01
    z[2,1,1]  R592      -2.7359953522682190e-01
    z[2,1,1]  R593      -2.7333667874336243e-01
    z[2,1,1]  R594      -4.5951792597770691e-01
    z[2,1,1]  R595      -4.3252980709075928e-01
    z[2,1,1]  R596      -1.1579956859350204e-01
    z[2,1,1]  R597      -9.5399028062820435e-01
    z[2,1,1]  R598      -7.8108400106430054e-01
    z[2,1,1]  R599      -8.0746436119079590e-01
    z[2,1,1]  R600      -7.8210854530334473e-01
    z[2,1,1]  R601      -7.1410173177719116e-01
    z[2,1,1]  R602      -7.8637742996215820e-01
    z[2,1,1]  R603      -7.4421435594558716e-01
    z[2,1,1]  R604      -0.700564444065094
    z[2,1,1]  R605      -6.8744331598281860e-01
    z[2,1,1]  R606      -7.0553278923034668e-01
    z[2,1,1]  R607      5.8930778503417969e-01
    z[2,1,1]  R608      5.5380409955978394e-01
    z[2,1,1]  R609      -7.1062213182449341e-01
    z[2,1,1]  R610      7.0085096359252930e-01
    z[2,1,1]  R611      -6.4749735593795776e-01
    z[2,1,1]  R612      -5.9957367181777954e-01
    z[2,1,1]  R613      5.0419336557388306e-01
    z[2,1,1]  R614      0.506360650062561
    z[2,1,1]  R615      5.4126524925231934e-01
    z[2,1,1]  R616      -3.6219015717506409e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R537      -1
    z[2,1,2]  R538      1
    z[2,1,2]  R547      2.5536981225013733e-01
    z[2,1,2]  R548      -8.0873884260654449e-02
    z[2,1,2]  R549      -7.4643611907958984e-01
    z[2,1,2]  R550      2.6601186394691467e-01
    z[2,1,2]  R551      -3.3538267016410828e-01
    z[2,1,2]  R552      3.3730635046958923e-01
    z[2,1,2]  R553      -5.7383030652999878e-01
    z[2,1,2]  R554      2.3722781240940094e-01
    z[2,1,2]  R555      -1.4183494448661804e-01
    z[2,1,2]  R556      -3.5477694869041443e-01
    z[2,1,2]  R557      -3.4747142344713211e-02
    z[2,1,2]  R558      4.0809872746467590e-01
    z[2,1,2]  R559      -1.4974361658096313e-01
    z[2,1,2]  R560      1.4509527385234833e-01
    z[2,1,2]  R561      2.3709741234779358e-01
    z[2,1,2]  R562      3.8914494216442108e-02
    z[2,1,2]  R563      8.1839226186275482e-02
    z[2,1,2]  R564      2.6590687036514282e-01
    z[2,1,2]  R565      1.2773790955543518e-01
    z[2,1,2]  R566      2.6197027415037155e-02
    z[2,1,2]  R567      -1.7921912670135498e-01
    z[2,1,2]  R568      -3.5935276746749878e-01
    z[2,1,2]  R569      2.6201415061950684e-01
    z[2,1,2]  R570      5.6552481651306152e-01
    z[2,1,2]  R571      -1.4974561333656311e-01
    z[2,1,2]  R572      -2.2675932943820953e-01
    z[2,1,2]  R573      -4.1336383670568466e-02
    z[2,1,2]  R574      1.3642235100269318e-01
    z[2,1,2]  R575      6.8221598863601685e-01
    z[2,1,2]  R576      -7.2196260094642639e-02
    z[2,1,2]  R577      -2.8458578512072563e-02
    z[2,1,2]  R578      9.8333068192005157e-02
    z[2,1,2]  R579      1.6744644939899445e-01
    z[2,1,2]  R580      -3.2325658202171326e-01
    z[2,1,2]  R581      9.7997933626174927e-02
    z[2,1,2]  R582      -5.4415683262050152e-03
    z[2,1,2]  R583      -0.257853627204895
    z[2,1,2]  R584      -3.0794674158096313e-01
    z[2,1,2]  R585      -2.4678991734981537e-01
    z[2,1,2]  R586      2.6114261150360107e-01
    z[2,1,2]  R587      0.527817964553833
    z[2,1,2]  R588      -4.0941774845123291e-01
    z[2,1,2]  R589      -4.9897426366806030e-01
    z[2,1,2]  R590      -7.5336736440658569e-01
    z[2,1,2]  R591      -4.1837871074676514e-01
    z[2,1,2]  R592      -6.3643521070480347e-01
    z[2,1,2]  R593      -3.6294567584991455e-01
    z[2,1,2]  R594      -6.7835921049118042e-01
    z[2,1,2]  R595      -2.8625974059104919e-01
    z[2,1,2]  R596      -0.603752076625824
    z[2,1,2]  R597      6.9415479898452759e-02
    z[2,1,2]  R598      -2.3059016466140747e-01
    z[2,1,2]  R599      3.4395694732666016e-01
    z[2,1,2]  R600      3.1662932038307190e-01
    z[2,1,2]  R601      -1.4114160835742950e-01
    z[2,1,2]  R602      -6.4147412776947021e-02
    z[2,1,2]  R603      -4.0544936060905457e-01
    z[2,1,2]  R604      7.3663949966430664e-02
    z[2,1,2]  R605      2.8105584904551506e-02
    z[2,1,2]  R606      4.0016758441925049e-01
    z[2,1,2]  R607      0.273367315530777
    z[2,1,2]  R608      7.4711114168167114e-01
    z[2,1,2]  R609      -4.7318261861801147e-01
    z[2,1,2]  R610      2.1705015003681183e-01
    z[2,1,2]  R611      3.5083245486021042e-02
    z[2,1,2]  R612      2.7878111600875854e-01
    z[2,1,2]  R613      2.4471163749694824e-01
    z[2,1,2]  R614      -1.4625380933284760e-01
    z[2,1,2]  R615      1.8711602687835693e-01
    z[2,1,2]  R616      -2.6298427581787109e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R539      -1
    z[2,1,3]  R540      1
    z[2,1,3]  R547      6.9872546195983887e-01
    z[2,1,3]  R548      -1.4361524581909180e-01
    z[2,1,3]  R549      -1.6800025105476379e-01
    z[2,1,3]  R550      -3.9234411716461182e-01
    z[2,1,3]  R551      -1.6036370769143105e-02
    z[2,1,3]  R552      3.7227776646614075e-01
    z[2,1,3]  R553      3.9219167828559875e-01
    z[2,1,3]  R554      2.6986068487167358e-01
    z[2,1,3]  R555      3.6536210775375366e-01
    z[2,1,3]  R556      2.0269700884819031e-01
    z[2,1,3]  R557      -3.0786329880356789e-02
    z[2,1,3]  R558      -3.0556395649909973e-01
    z[2,1,3]  R559      -2.9215618968009949e-01
    z[2,1,3]  R560      -3.1286829710006714e-01
    z[2,1,3]  R561      1.5310217440128326e-01
    z[2,1,3]  R562      -2.8971329331398010e-01
    z[2,1,3]  R563      -3.9567741751670837e-01
    z[2,1,3]  R564      -3.3423423767089844e-01
    z[2,1,3]  R565      -3.4821224212646484e-01
    z[2,1,3]  R566      -2.6191130280494690e-01
    z[2,1,3]  R567      8.6467579007148743e-02
    z[2,1,3]  R568      1.3405305147171021e-01
    z[2,1,3]  R569      1.1523726396262646e-02
    z[2,1,3]  R570      1.6345396637916565e-01
    z[2,1,3]  R571      1.2899482250213623e-01
    z[2,1,3]  R572      6.1010837554931641e-02
    z[2,1,3]  R573      2.9394409060478210e-01
    z[2,1,3]  R574      0.0871608629822731
    z[2,1,3]  R575      -2.4624569714069366e-01
    z[2,1,3]  R576      -1.4056387543678284e-01
    z[2,1,3]  R577      -1.0652960836887360e-01
    z[2,1,3]  R578      -3.7224423885345459e-01
    z[2,1,3]  R579      5.8253329992294312e-01
    z[2,1,3]  R580      4.3245518207550049e-01
    z[2,1,3]  R581      4.9656990170478821e-01
    z[2,1,3]  R582      5.7550114393234253e-01
    z[2,1,3]  R583      5.2948659658432007e-01
    z[2,1,3]  R584      6.5426230430603027e-01
    z[2,1,3]  R585      9.0064838528633118e-02
    z[2,1,3]  R586      1.2413965165615082e-01
    z[2,1,3]  R587      7.1115463972091675e-02
    z[2,1,3]  R588      6.2369710206985474e-01
    z[2,1,3]  R589      4.5309442281723022e-01
    z[2,1,3]  R590      3.4645467996597290e-01
    z[2,1,3]  R591      5.4036104679107666e-01
    z[2,1,3]  R592      2.8364226222038269e-01
    z[2,1,3]  R593      7.6607018709182739e-01
    z[2,1,3]  R594      0.468136727809906
    z[2,1,3]  R595      2.8573292493820190e-01
    z[2,1,3]  R596      1.3243648409843445e-01
    z[2,1,3]  R597      1.1205623298883438e-01
    z[2,1,3]  R598      3.3471721410751343e-01
    z[2,1,3]  R599      4.3947091698646545e-01
    z[2,1,3]  R600      3.9231842756271362e-01
    z[2,1,3]  R601      3.9689761400222778e-01
    z[2,1,3]  R602      -7.3697227053344250e-03
    z[2,1,3]  R603      -1.6436351463198662e-02
    z[2,1,3]  R604      -4.0541672706604004e-01
    z[2,1,3]  R605      -6.1854767799377441e-01
    z[2,1,3]  R606      -3.1052476167678833e-01
    z[2,1,3]  R607      -4.6811640262603760e-01
    z[2,1,3]  R608      -2.9047888517379761e-01
    z[2,1,3]  R609      -4.2592954635620117e-01
    z[2,1,3]  R610      -5.0239515304565430e-01
    z[2,1,3]  R611      1.1542630381882191e-02
    z[2,1,3]  R612      -3.5988822579383850e-01
    z[2,1,3]  R613      -5.7506734132766724e-01
    z[2,1,3]  R614      -6.6924935579299927e-01
    z[2,1,3]  R615      -3.9783358573913574e-01
    z[2,1,3]  R616      4.7208401560783386e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R541      -1
    z[2,1,4]  R542      1
    z[2,1,4]  R547      -2.9354941099882126e-02
    z[2,1,4]  R548      -2.7737346291542053e-01
    z[2,1,4]  R549      -3.6460742354393005e-02
    z[2,1,4]  R550      3.5273800604045391e-03
    z[2,1,4]  R551      -2.1476107835769653e-01
    z[2,1,4]  R552      -2.2934643551707268e-02
    z[2,1,4]  R553      -7.9072043299674988e-02
    z[2,1,4]  R554      -3.5760810971260071e-01
    z[2,1,4]  R555      -7.7128744125366211e-01
    z[2,1,4]  R556      -3.8145750761032104e-01
    z[2,1,4]  R557      7.3071740567684174e-02
    z[2,1,4]  R558      -1.4902658760547638e-01
    z[2,1,4]  R559      3.9553143084049225e-02
    z[2,1,4]  R560      2.0750153809785843e-02
    z[2,1,4]  R561      2.4105429649353027e-01
    z[2,1,4]  R562      1.7101193964481354e-01
    z[2,1,4]  R563      0.0950782373547554
    z[2,1,4]  R564      -1.0960499197244644e-01
    z[2,1,4]  R565      1.5725545585155487e-01
    z[2,1,4]  R566      1.2200789898633957e-01
    z[2,1,4]  R567      2.8890535235404968e-01
    z[2,1,4]  R568      4.3241629004478455e-01
    z[2,1,4]  R569      -6.0956722497940063e-01
    z[2,1,4]  R570      3.5223352909088135e-01
    z[2,1,4]  R571      -1.6913086175918579e-01
    z[2,1,4]  R572      1.9742825627326965e-01
    z[2,1,4]  R573      0.330597460269928
    z[2,1,4]  R574      -7.7031159400939941e-01
    z[2,1,4]  R575      8.4561698138713837e-02
    z[2,1,4]  R576      3.0646726489067078e-02
    z[2,1,4]  R577      -4.2701106518507004e-02
    z[2,1,4]  R578      -1.0903651267290115e-01
    z[2,1,4]  R579      -3.8109406828880310e-02
    z[2,1,4]  R580      -2.6365658640861511e-01
    z[2,1,4]  R581      -1.0086496174335480e-01
    z[2,1,4]  R582      -4.2758235335350037e-01
    z[2,1,4]  R583      -0.0987108051776886
    z[2,1,4]  R584      -1.8443804234266281e-02
    z[2,1,4]  R585      -8.4633342921733856e-02
    z[2,1,4]  R586      -1.1293911933898926e-01
    z[2,1,4]  R587      0.827197790145874
    z[2,1,4]  R588      -6.3351714611053467e-01
    z[2,1,4]  R589      -6.4652818441390991e-01
    z[2,1,4]  R590      -4.9971318244934082e-01
    z[2,1,4]  R591      -4.7033041715621948e-01
    z[2,1,4]  R592      -3.9395216107368469e-01
    z[2,1,4]  R593      -3.5066959261894226e-01
    z[2,1,4]  R594      -1.9051505625247955e-01
    z[2,1,4]  R595      -4.0630677342414856e-01
    z[2,1,4]  R596      -7.6303946971893311e-01
    z[2,1,4]  R597      3.2096426934003830e-02
    z[2,1,4]  R598      -1.1262485384941101e-01
    z[2,1,4]  R599      -1.1069152504205704e-02
    z[2,1,4]  R600      -8.4059886634349823e-02
    z[2,1,4]  R601      -0.0471460185945034
    z[2,1,4]  R602      -1.4118281193077564e-02
    z[2,1,4]  R603      4.1445949673652649e-01
    z[2,1,4]  R604      -5.0145995616912842e-01
    z[2,1,4]  R605      3.1634697318077087e-01
    z[2,1,4]  R606      3.2800965011119843e-02
    z[2,1,4]  R607      3.9694914221763611e-01
    z[2,1,4]  R608      -1.3578631915152073e-02
    z[2,1,4]  R609      -2.8430971503257751e-01
    z[2,1,4]  R610      -3.9041060209274292e-01
    z[2,1,4]  R611      4.7830536961555481e-01
    z[2,1,4]  R612      -2.0111978054046631e-01
    z[2,1,4]  R613      2.9851067066192627e-01
    z[2,1,4]  R614      -2.3639839142560959e-02
    z[2,1,4]  R615      -1.8404923379421234e-01
    z[2,1,4]  R616      -0.517731785774231
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R543      -1
    z[2,1,5]  R544      1
    z[2,1,5]  R547      3.7134058773517609e-02
    z[2,1,5]  R548      -4.3836227059364319e-01
    z[2,1,5]  R549      1.6207601130008698e-01
    z[2,1,5]  R550      2.8912666440010071e-01
    z[2,1,5]  R551      1.7371119558811188e-01
    z[2,1,5]  R552      -2.8155824542045593e-01
    z[2,1,5]  R553      -3.3294427394866943e-01
    z[2,1,5]  R554      -3.1217607855796814e-01
    z[2,1,5]  R555      1.6681528091430664e-01
    z[2,1,5]  R556      -7.6324068009853363e-02
    z[2,1,5]  R557      5.9478396177291870e-01
    z[2,1,5]  R558      1.4739955961704254e-01
    z[2,1,5]  R559      3.1917652487754822e-01
    z[2,1,5]  R560      -1.3296452164649963e-01
    z[2,1,5]  R561      2.2613622248172760e-02
    z[2,1,5]  R562      -1.2087034434080124e-01
    z[2,1,5]  R563      -2.4794960021972656e-01
    z[2,1,5]  R564      -0.0900367721915245
    z[2,1,5]  R565      -2.2938187420368195e-01
    z[2,1,5]  R566      -9.6857078373432159e-02
    z[2,1,5]  R567      -2.5553047657012939e-01
    z[2,1,5]  R568      2.6781976222991943e-01
    z[2,1,5]  R569      1.7074239253997803e-01
    z[2,1,5]  R570      1.9964082539081573e-01
    z[2,1,5]  R571      -3.0739307403564453e-02
    z[2,1,5]  R572      -5.4868847131729126e-01
    z[2,1,5]  R573      1.5081061422824860e-01
    z[2,1,5]  R574      5.5249845609068871e-03
    z[2,1,5]  R575      -8.0237448215484619e-02
    z[2,1,5]  R576      -5.4287576675415039e-01
    z[2,1,5]  R577      -1.3769541680812836e-01
    z[2,1,5]  R578      -0.563877522945404
    z[2,1,5]  R579      8.5845552384853363e-03
    z[2,1,5]  R580      0.00700989319011569
    z[2,1,5]  R581      -5.6152928620576859e-02
    z[2,1,5]  R582      9.8681680858135223e-02
    z[2,1,5]  R583      -3.2476380467414856e-01
    z[2,1,5]  R584      7.6823040843009949e-02
    z[2,1,5]  R585      3.4556340426206589e-02
    z[2,1,5]  R586      -2.9272469878196716e-01
    z[2,1,5]  R587      -1.5474167652428150e-02
    z[2,1,5]  R588      1.0599581152200699e-01
    z[2,1,5]  R589      -2.5980386137962341e-01
    z[2,1,5]  R590      1.1180879175662994e-01
    z[2,1,5]  R591      0.0648990347981453
    z[2,1,5]  R592      2.8234541416168213e-01
    z[2,1,5]  R593      2.7899768948554993e-01
    z[2,1,5]  R594      1.2590293586254120e-01
    z[2,1,5]  R595      6.7350721359252930e-01
    z[2,1,5]  R596      9.8208189010620117e-02
    z[2,1,5]  R597      2.0516207814216614e-01
    z[2,1,5]  R598      -0.364769846200943
    z[2,1,5]  R599      8.3711095154285431e-02
    z[2,1,5]  R600      -2.5648900866508484e-01
    z[2,1,5]  R601      -2.9499495029449463e-01
    z[2,1,5]  R602      -1.0593015700578690e-01
    z[2,1,5]  R603      -2.6589006185531616e-01
    z[2,1,5]  R604      -7.9941317439079285e-02
    z[2,1,5]  R605      2.0427992939949036e-01
    z[2,1,5]  R606      1.9457958638668060e-01
    z[2,1,5]  R607      -7.8477680683135986e-02
    z[2,1,5]  R608      -1.4952444471418858e-02
    z[2,1,5]  R609      -7.9793877899646759e-02
    z[2,1,5]  R610      -0.0723300352692604
    z[2,1,5]  R611      2.5796961784362793e-01
    z[2,1,5]  R612      -5.6732857227325439e-01
    z[2,1,5]  R613      3.7883457541465759e-01
    z[2,1,5]  R614      4.5789572596549988e-01
    z[2,1,5]  R615      6.8522137403488159e-01
    z[2,1,5]  R616      5.4043656587600708e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R545      -1
    z[2,1,6]  R546      1
    z[2,1,6]  R547      6.6858351230621338e-02
    z[2,1,6]  R548      0.259028822183609
    z[2,1,6]  R549      1.5027964115142822e-01
    z[2,1,6]  R550      -5.2211493253707886e-01
    z[2,1,6]  R551      -5.9342807531356812e-01
    z[2,1,6]  R552      -2.6496127247810364e-01
    z[2,1,6]  R553      -1.9309477508068085e-01
    z[2,1,6]  R554      2.5463435053825378e-01
    z[2,1,6]  R555      -3.3253121655434370e-03
    z[2,1,6]  R556      5.3472322225570679e-01
    z[2,1,6]  R557      2.6953560113906860e-01
    z[2,1,6]  R558      2.3360078036785126e-01
    z[2,1,6]  R559      -2.3991394042968750e-01
    z[2,1,6]  R560      6.4353114366531372e-01
    z[2,1,6]  R561      5.7192766666412354e-01
    z[2,1,6]  R562      -2.5998631026595831e-03
    z[2,1,6]  R563      -1.0083127021789551e-01
    z[2,1,6]  R564      -4.3489582836627960e-02
    z[2,1,6]  R565      2.2829528152942657e-01
    z[2,1,6]  R566      6.7231371998786926e-02
    z[2,1,6]  R567      2.5963285565376282e-01
    z[2,1,6]  R568      -1.4824126660823822e-01
    z[2,1,6]  R569      -1.5896141529083252e-01
    z[2,1,6]  R570      1.8201065063476562e-01
    z[2,1,6]  R571      7.2573626041412354e-01
    z[2,1,6]  R572      4.1801032423973083e-01
    z[2,1,6]  R573      3.6519128084182739e-01
    z[2,1,6]  R574      3.3364954590797424e-01
    z[2,1,6]  R575      1.8068379163742065e-01
    z[2,1,6]  R576      -1.0695316828787327e-02
    z[2,1,6]  R577      -5.5232111364603043e-02
    z[2,1,6]  R578      -2.7220547199249268e-01
    z[2,1,6]  R579      1.6095350682735443e-01
    z[2,1,6]  R580      -3.3334780484437943e-02
    z[2,1,6]  R581      -3.8633573055267334e-01
    z[2,1,6]  R582      -4.3321792036294937e-02
    z[2,1,6]  R583      2.1497417986392975e-01
    z[2,1,6]  R584      1.2258848547935486e-01
    z[2,1,6]  R585      -1.7597796022891998e-01
    z[2,1,6]  R586      -1.2156955152750015e-01
    z[2,1,6]  R587      -0.0600656233727932
    z[2,1,6]  R588      -1.8227970227599144e-02
    z[2,1,6]  R589      5.8530010282993317e-02
    z[2,1,6]  R590      -1.7670390009880066e-01
    z[2,1,6]  R591      3.7089386582374573e-01
    z[2,1,6]  R592      3.0736133456230164e-01
    z[2,1,6]  R593      7.1762762963771820e-02
    z[2,1,6]  R594      7.9394921660423279e-02
    z[2,1,6]  R595      1.7386290431022644e-01
    z[2,1,6]  R596      1.0488359630107880e-01
    z[2,1,6]  R597      1.4423468708992004e-01
    z[2,1,6]  R598      -1.8995878100395203e-01
    z[2,1,6]  R599      -1.7092873156070709e-01
    z[2,1,6]  R600      7.1612037718296051e-02
    z[2,1,6]  R601      -8.1680983304977417e-02
    z[2,1,6]  R602      5.1010406017303467e-01
    z[2,1,6]  R603      -1.4856582880020142e-01
    z[2,1,6]  R604      -1.9486727192997932e-02
    z[2,1,6]  R605      2.5488814339041710e-02
    z[2,1,6]  R606      -0.40351602435112
    z[2,1,6]  R607      -3.9917615056037903e-01
    z[2,1,6]  R608      5.8154135942459106e-02
    z[2,1,6]  R609      2.1559296175837517e-02
    z[2,1,6]  R610      2.2480469942092896e-01
    z[2,1,6]  R611      -4.2965874075889587e-01
    z[2,1,6]  R612      1.0333219915628433e-01
    z[2,1,6]  R613      2.1412852406501770e-01
    z[2,1,6]  R614      1.2260851263999939e-01
    z[2,1,6]  R615      3.2578937709331512e-02
    z[2,1,6]  R616      -8.6356140673160553e-02
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R617      -1
    z[1,5,0]  R618      1
    z[1,5,0]  R631      1.4682796597480774e-01
    z[1,5,0]  R632      -1.9448599219322205e-01
    z[1,5,0]  R633      -7.6547443866729736e-01
    z[1,5,0]  R634      -7.8703552484512329e-01
    z[1,5,0]  R635      -7.6065880060195923e-01
    z[1,5,0]  R636      -6.8503272533416748e-01
    z[1,5,0]  R637      -6.9114369153976440e-01
    z[1,5,0]  R638      -6.5381234884262085e-01
    z[1,5,0]  R639      -9.3975865840911865e-01
    z[1,5,0]  R640      -8.9000082015991211e-01
    z[1,5,0]  R641      1.1959818750619888e-01
    z[1,5,0]  R642      -2.8266675770282745e-02
    z[1,5,0]  R643      -3.5147402435541153e-02
    z[1,5,0]  R644      -5.2857872098684311e-02
    z[1,5,0]  R645      2.5732627511024475e-01
    z[1,5,0]  R646      3.3204281330108643e-01
    z[1,5,0]  R647      0.0271154772490263
    z[1,5,0]  R648      2.2598467767238617e-01
    z[1,5,0]  R649      -2.0111760124564171e-02
    z[1,5,0]  R650      4.0740448981523514e-02
    z[1,5,0]  R651      -9.2747874557971954e-02
    z[1,5,0]  R652      -2.0706218481063843e-01
    z[1,5,0]  R653      -1.4613938517868519e-02
    z[1,5,0]  R654      -2.3697561025619507e-01
    z[1,5,0]  R655      4.6550330519676208e-01
    z[1,5,0]  R656      3.2529163360595703e-01
    z[1,5,0]  R657      1.3015180826187134e-01
    z[1,5,0]  R658      2.8493487834930420e-01
    z[1,5,0]  R659      3.9687082171440125e-02
    z[1,5,0]  R660      -2.0952665805816650e-01
    z[1,5,0]  R661      -1.8916824460029602e-01
    z[1,5,0]  R662      -2.1669808030128479e-01
    z[1,5,0]  R663      -4.5104026794433594e-02
    z[1,5,0]  R664      3.3271864056587219e-02
    z[1,5,0]  R665      -3.1536030769348145e-01
    z[1,5,0]  R666      -2.4552899599075317e-01
    z[1,5,0]  R667      2.7699765563011169e-01
    z[1,5,0]  R668      2.2148096561431885e-01
    z[1,5,0]  R669      -9.6354849636554718e-02
    z[1,5,0]  R670      -9.6015587449073792e-02
    z[1,5,0]  R671      -2.4731977283954620e-01
    z[1,5,0]  R672      0.085629403591156
    z[1,5,0]  R673      5.9188399463891983e-02
    z[1,5,0]  R674      -1.6589473187923431e-01
    z[1,5,0]  R675      -1.7032325267791748e-02
    z[1,5,0]  R676      -4.5395351946353912e-02
    z[1,5,0]  R677      -1.6201204061508179e-01
    z[1,5,0]  R678      -1.8934737890958786e-02
    z[1,5,0]  R679      0.150125190615654
    z[1,5,0]  R680      -3.8735404610633850e-01
    z[1,5,0]  R681      -2.1382641792297363e-01
    z[1,5,0]  R682      -3.5925221443176270e-01
    z[1,5,0]  R683      -3.9004248380661011e-01
    z[1,5,0]  R684      -8.7264098227024078e-02
    z[1,5,0]  R685      1.8645381554961205e-02
    z[1,5,0]  R686      -3.1487077474594116e-01
    z[1,5,0]  R687      -6.3983634114265442e-02
    z[1,5,0]  R688      3.1601474620401859e-03
    z[1,5,0]  R689      2.7315232157707214e-01
    z[1,5,0]  R690      -1.1055515706539154e-01
    z[1,5,0]  R691      -5.3513408638536930e-03
    z[1,5,0]  R692      1.9580383598804474e-01
    z[1,5,0]  R693      4.4064730405807495e-01
    z[1,5,0]  R694      2.6081116870045662e-02
    z[1,5,0]  R695      2.1425299346446991e-01
    z[1,5,0]  R696      -2.5385084748268127e-01
    z[1,5,0]  R697      -5.7478111237287521e-02
    z[1,5,0]  R698      8.5354052484035492e-02
    z[1,5,0]  R699      2.3851613700389862e-01
    z[1,5,0]  R700      -1.3423493504524231e-01
    z[1,5,0]  R701      -3.6913685500621796e-02
    z[1,5,0]  R702      -2.1532289683818817e-01
    z[1,5,0]  R703      -2.3875330388545990e-01
    z[1,5,0]  R704      9.2885173857212067e-02
    z[1,5,0]  R705      5.3868040442466736e-02
    z[1,5,0]  R706      1.3729308545589447e-01
    z[1,5,0]  R707      1.9400085508823395e-01
    z[1,5,0]  R708      2.4801792204380035e-01
    z[1,5,0]  R709      5.0494468212127686e-01
    z[1,5,0]  R710      2.1552659571170807e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R619      -1
    z[1,5,1]  R620      1
    z[1,5,1]  R631      9.7079819440841675e-01
    z[1,5,1]  R632      6.4031040668487549e-01
    z[1,5,1]  R633      -0.138684943318367
    z[1,5,1]  R634      -1.3560040295124054e-01
    z[1,5,1]  R635      -5.1290322095155716e-02
    z[1,5,1]  R636      -0.0711161345243454
    z[1,5,1]  R637      1.1851778626441956e-01
    z[1,5,1]  R638      1.6843172907829285e-01
    z[1,5,1]  R639      9.2258296906948090e-02
    z[1,5,1]  R640      -1.0521542280912399e-01
    z[1,5,1]  R641      1.1808297038078308e-01
    z[1,5,1]  R642      -1.7224618792533875e-01
    z[1,5,1]  R643      -2.3573809862136841e-01
    z[1,5,1]  R644      -1.2717759609222412e-01
    z[1,5,1]  R645      -3.2212957739830017e-01
    z[1,5,1]  R646      -2.7359953522682190e-01
    z[1,5,1]  R647      -2.7333667874336243e-01
    z[1,5,1]  R648      -4.5951792597770691e-01
    z[1,5,1]  R649      -4.3252980709075928e-01
    z[1,5,1]  R650      -1.1579956859350204e-01
    z[1,5,1]  R651      -9.5399028062820435e-01
    z[1,5,1]  R652      -7.8108400106430054e-01
    z[1,5,1]  R653      -8.0746436119079590e-01
    z[1,5,1]  R654      -7.8210854530334473e-01
    z[1,5,1]  R655      -7.1410173177719116e-01
    z[1,5,1]  R656      -7.8637742996215820e-01
    z[1,5,1]  R657      -7.4421435594558716e-01
    z[1,5,1]  R658      -0.700564444065094
    z[1,5,1]  R659      -6.8744331598281860e-01
    z[1,5,1]  R660      -7.0553278923034668e-01
    z[1,5,1]  R661      5.8930778503417969e-01
    z[1,5,1]  R662      5.5380409955978394e-01
    z[1,5,1]  R663      -7.1062213182449341e-01
    z[1,5,1]  R664      7.0085096359252930e-01
    z[1,5,1]  R665      -6.4749735593795776e-01
    z[1,5,1]  R666      -5.9957367181777954e-01
    z[1,5,1]  R667      5.0419336557388306e-01
    z[1,5,1]  R668      0.506360650062561
    z[1,5,1]  R669      5.4126524925231934e-01
    z[1,5,1]  R670      -3.6219015717506409e-01
    z[1,5,1]  R671      9.2446643114089966e-01
    z[1,5,1]  R672      9.8886710405349731e-01
    z[1,5,1]  R673      -3.0416840687394142e-02
    z[1,5,1]  R674      6.3676489517092705e-03
    z[1,5,1]  R675      5.7651054859161377e-01
    z[1,5,1]  R676      -3.4543506801128387e-02
    z[1,5,1]  R677      -0.0232999287545681
    z[1,5,1]  R678      -3.5011786967515945e-02
    z[1,5,1]  R679      -6.4352788031101227e-02
    z[1,5,1]  R680      -5.5713269859552383e-02
    z[1,5,1]  R681      -6.2276363372802734e-01
    z[1,5,1]  R682      -6.0613393783569336e-01
    z[1,5,1]  R683      -0.557383120059967
    z[1,5,1]  R684      -5.5232745409011841e-01
    z[1,5,1]  R685      -5.3412622213363647e-01
    z[1,5,1]  R686      -5.6050300598144531e-01
    z[1,5,1]  R687      -4.9303579330444336e-01
    z[1,5,1]  R688      -5.4293894767761230e-01
    z[1,5,1]  R689      -5.5307763814926147e-01
    z[1,5,1]  R690      -4.9725890159606934e-01
    z[1,5,1]  R691      -9.8264390230178833e-01
    z[1,5,1]  R692      -7.9808372259140015e-01
    z[1,5,1]  R693      -6.5045034885406494e-01
    z[1,5,1]  R694      -4.5593962073326111e-01
    z[1,5,1]  R695      0.483502060174942
    z[1,5,1]  R696      6.7729687690734863e-01
    z[1,5,1]  R697      5.8949595689773560e-01
    z[1,5,1]  R698      3.5691463947296143e-01
    z[1,5,1]  R699      7.8776067495346069e-01
    z[1,5,1]  R700      5.6254655122756958e-01
    z[1,5,1]  R701      0.73489910364151
    z[1,5,1]  R702      0.717809796333313
    z[1,5,1]  R703      8.3352595567703247e-01
    z[1,5,1]  R704      7.7697873115539551e-01
    z[1,5,1]  R705      6.3356381654739380e-01
    z[1,5,1]  R706      6.9384175539016724e-01
    z[1,5,1]  R707      7.0997720956802368e-01
    z[1,5,1]  R708      7.7718651294708252e-01
    z[1,5,1]  R709      -2.2949238121509552e-01
    z[1,5,1]  R710      -7.7543258666992188e-02
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R621      -1
    z[1,5,2]  R622      1
    z[1,5,2]  R631      -2.8458578512072563e-02
    z[1,5,2]  R632      9.8333068192005157e-02
    z[1,5,2]  R633      1.6744644939899445e-01
    z[1,5,2]  R634      -3.2325658202171326e-01
    z[1,5,2]  R635      9.7997933626174927e-02
    z[1,5,2]  R636      -5.4415683262050152e-03
    z[1,5,2]  R637      -0.257853627204895
    z[1,5,2]  R638      -3.0794674158096313e-01
    z[1,5,2]  R639      -2.4678991734981537e-01
    z[1,5,2]  R640      2.6114261150360107e-01
    z[1,5,2]  R641      0.527817964553833
    z[1,5,2]  R642      -4.0941774845123291e-01
    z[1,5,2]  R643      -4.9897426366806030e-01
    z[1,5,2]  R644      -7.5336736440658569e-01
    z[1,5,2]  R645      -4.1837871074676514e-01
    z[1,5,2]  R646      -6.3643521070480347e-01
    z[1,5,2]  R647      -3.6294567584991455e-01
    z[1,5,2]  R648      -6.7835921049118042e-01
    z[1,5,2]  R649      -2.8625974059104919e-01
    z[1,5,2]  R650      -0.603752076625824
    z[1,5,2]  R651      6.9415479898452759e-02
    z[1,5,2]  R652      -2.3059016466140747e-01
    z[1,5,2]  R653      3.4395694732666016e-01
    z[1,5,2]  R654      3.1662932038307190e-01
    z[1,5,2]  R655      -1.4114160835742950e-01
    z[1,5,2]  R656      -6.4147412776947021e-02
    z[1,5,2]  R657      -4.0544936060905457e-01
    z[1,5,2]  R658      7.3663949966430664e-02
    z[1,5,2]  R659      2.8105584904551506e-02
    z[1,5,2]  R660      4.0016758441925049e-01
    z[1,5,2]  R661      0.273367315530777
    z[1,5,2]  R662      7.4711114168167114e-01
    z[1,5,2]  R663      -4.7318261861801147e-01
    z[1,5,2]  R664      2.1705015003681183e-01
    z[1,5,2]  R665      3.5083245486021042e-02
    z[1,5,2]  R666      2.7878111600875854e-01
    z[1,5,2]  R667      2.4471163749694824e-01
    z[1,5,2]  R668      -1.4625380933284760e-01
    z[1,5,2]  R669      1.8711602687835693e-01
    z[1,5,2]  R670      -2.6298427581787109e-01
    z[1,5,2]  R671      8.9352488517761230e-02
    z[1,5,2]  R672      -0.0491953007876873
    z[1,5,2]  R673      -7.9013854265213013e-01
    z[1,5,2]  R674      -6.8222486972808838e-01
    z[1,5,2]  R675      -1.4217109978199005e-01
    z[1,5,2]  R676      -5.9088891744613647e-01
    z[1,5,2]  R677      -8.1355655193328857e-01
    z[1,5,2]  R678      -5.0917977094650269e-01
    z[1,5,2]  R679      -4.6965035796165466e-01
    z[1,5,2]  R680      -6.6920286417007446e-01
    z[1,5,2]  R681      1.2158872932195663e-01
    z[1,5,2]  R682      4.0791156888008118e-01
    z[1,5,2]  R683      -3.8222637772560120e-01
    z[1,5,2]  R684      -5.6150525808334351e-01
    z[1,5,2]  R685      -3.2182133197784424e-01
    z[1,5,2]  R686      -5.4858695715665817e-02
    z[1,5,2]  R687      -2.4375198781490326e-01
    z[1,5,2]  R688      -1.9812296330928802e-01
    z[1,5,2]  R689      3.9448940753936768e-01
    z[1,5,2]  R690      5.7450169324874878e-01
    z[1,5,2]  R691      -0.0683421716094017
    z[1,5,2]  R692      -2.9872161149978638e-01
    z[1,5,2]  R693      -3.4258782863616943e-02
    z[1,5,2]  R694      -2.4924477934837341e-01
    z[1,5,2]  R695      4.2520549893379211e-01
    z[1,5,2]  R696      3.0196332931518555e-01
    z[1,5,2]  R697      4.8791524767875671e-01
    z[1,5,2]  R698      6.5476822853088379e-01
    z[1,5,2]  R699      3.7515634298324585e-01
    z[1,5,2]  R700      5.4492139816284180e-01
    z[1,5,2]  R701      5.1817828416824341e-01
    z[1,5,2]  R702      2.5820646435022354e-02
    z[1,5,2]  R703      4.3365576863288879e-01
    z[1,5,2]  R704      2.0073603093624115e-01
    z[1,5,2]  R705      4.8572579026222229e-01
    z[1,5,2]  R706      -2.1406058967113495e-01
    z[1,5,2]  R707      1.0951752215623856e-01
    z[1,5,2]  R708      -3.0360126495361328e-01
    z[1,5,2]  R709      -5.7654780149459839e-01
    z[1,5,2]  R710      -4.5599821209907532e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R623      -1
    z[1,5,3]  R624      1
    z[1,5,3]  R631      -1.0652960836887360e-01
    z[1,5,3]  R632      -3.7224423885345459e-01
    z[1,5,3]  R633      5.8253329992294312e-01
    z[1,5,3]  R634      4.3245518207550049e-01
    z[1,5,3]  R635      4.9656990170478821e-01
    z[1,5,3]  R636      5.7550114393234253e-01
    z[1,5,3]  R637      5.2948659658432007e-01
    z[1,5,3]  R638      6.5426230430603027e-01
    z[1,5,3]  R639      9.0064838528633118e-02
    z[1,5,3]  R640      1.2413965165615082e-01
    z[1,5,3]  R641      7.1115463972091675e-02
    z[1,5,3]  R642      6.2369710206985474e-01
    z[1,5,3]  R643      4.5309442281723022e-01
    z[1,5,3]  R644      3.4645467996597290e-01
    z[1,5,3]  R645      5.4036104679107666e-01
    z[1,5,3]  R646      2.8364226222038269e-01
    z[1,5,3]  R647      7.6607018709182739e-01
    z[1,5,3]  R648      0.468136727809906
    z[1,5,3]  R649      2.8573292493820190e-01
    z[1,5,3]  R650      1.3243648409843445e-01
    z[1,5,3]  R651      1.1205623298883438e-01
    z[1,5,3]  R652      3.3471721410751343e-01
    z[1,5,3]  R653      4.3947091698646545e-01
    z[1,5,3]  R654      3.9231842756271362e-01
    z[1,5,3]  R655      3.9689761400222778e-01
    z[1,5,3]  R656      -7.3697227053344250e-03
    z[1,5,3]  R657      -1.6436351463198662e-02
    z[1,5,3]  R658      -4.0541672706604004e-01
    z[1,5,3]  R659      -6.1854767799377441e-01
    z[1,5,3]  R660      -3.1052476167678833e-01
    z[1,5,3]  R661      -4.6811640262603760e-01
    z[1,5,3]  R662      -2.9047888517379761e-01
    z[1,5,3]  R663      -4.2592954635620117e-01
    z[1,5,3]  R664      -5.0239515304565430e-01
    z[1,5,3]  R665      1.1542630381882191e-02
    z[1,5,3]  R666      -3.5988822579383850e-01
    z[1,5,3]  R667      -5.7506734132766724e-01
    z[1,5,3]  R668      -6.6924935579299927e-01
    z[1,5,3]  R669      -3.9783358573913574e-01
    z[1,5,3]  R670      4.7208401560783386e-01
    z[1,5,3]  R671      -0.0918092280626297
    z[1,5,3]  R672      -5.7513605803251266e-02
    z[1,5,3]  R673      4.5418307185173035e-01
    z[1,5,3]  R674      7.7439472079277039e-02
    z[1,5,3]  R675      -4.7017872333526611e-01
    z[1,5,3]  R676      2.1625219285488129e-01
    z[1,5,3]  R677      1.2432087957859039e-01
    z[1,5,3]  R678      8.0524575710296631e-01
    z[1,5,3]  R679      2.2533978521823883e-01
    z[1,5,3]  R680      3.7645533680915833e-01
    z[1,5,3]  R681      -5.7087731361389160e-01
    z[1,5,3]  R682      3.2693132758140564e-01
    z[1,5,3]  R683      2.0445835590362549e-01
    z[1,5,3]  R684      -4.2540755122900009e-02
    z[1,5,3]  R685      1.0242677479982376e-01
    z[1,5,3]  R686      5.6630659103393555e-01
    z[1,5,3]  R687      -3.0235049128532410e-01
    z[1,5,3]  R688      4.3067130446434021e-01
    z[1,5,3]  R689      -4.3552737683057785e-02
    z[1,5,3]  R690      -1.7985163629055023e-01
    z[1,5,3]  R691      -3.1912997364997864e-02
    z[1,5,3]  R692      3.0458664894104004e-01
    z[1,5,3]  R693      -4.7390836477279663e-01
    z[1,5,3]  R694      -4.9928811192512512e-01
    z[1,5,3]  R695      -3.4362620115280151e-01
    z[1,5,3]  R696      -5.4417955875396729e-01
    z[1,5,3]  R697      -5.6571716070175171e-01
    z[1,5,3]  R698      -5.5515849590301514e-01
    z[1,5,3]  R699      -1.1362207680940628e-01
    z[1,5,3]  R700      -2.1862530708312988e-01
    z[1,5,3]  R701      -8.9182555675506592e-02
    z[1,5,3]  R702      -5.4975038766860962e-01
    z[1,5,3]  R703      -7.8502416610717773e-02
    z[1,5,3]  R704      -3.4554621577262878e-01
    z[1,5,3]  R705      -0.526281476020813
    z[1,5,3]  R706      -4.1011002659797668e-01
    z[1,5,3]  R707      -2.1180368959903717e-01
    z[1,5,3]  R708      -1.5986070036888123e-01
    z[1,5,3]  R709      8.8934656232595444e-03
    z[1,5,3]  R710      1.7634023725986481e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R625      -1
    z[1,5,4]  R626      1
    z[1,5,4]  R631      -4.2701106518507004e-02
    z[1,5,4]  R632      -1.0903651267290115e-01
    z[1,5,4]  R633      -3.8109406828880310e-02
    z[1,5,4]  R634      -2.6365658640861511e-01
    z[1,5,4]  R635      -1.0086496174335480e-01
    z[1,5,4]  R636      -4.2758235335350037e-01
    z[1,5,4]  R637      -0.0987108051776886
    z[1,5,4]  R638      -1.8443804234266281e-02
    z[1,5,4]  R639      -8.4633342921733856e-02
    z[1,5,4]  R640      -1.1293911933898926e-01
    z[1,5,4]  R641      0.827197790145874
    z[1,5,4]  R642      -6.3351714611053467e-01
    z[1,5,4]  R643      -6.4652818441390991e-01
    z[1,5,4]  R644      -4.9971318244934082e-01
    z[1,5,4]  R645      -4.7033041715621948e-01
    z[1,5,4]  R646      -3.9395216107368469e-01
    z[1,5,4]  R647      -3.5066959261894226e-01
    z[1,5,4]  R648      -1.9051505625247955e-01
    z[1,5,4]  R649      -4.0630677342414856e-01
    z[1,5,4]  R650      -7.6303946971893311e-01
    z[1,5,4]  R651      3.2096426934003830e-02
    z[1,5,4]  R652      -1.1262485384941101e-01
    z[1,5,4]  R653      -1.1069152504205704e-02
    z[1,5,4]  R654      -8.4059886634349823e-02
    z[1,5,4]  R655      -0.0471460185945034
    z[1,5,4]  R656      -1.4118281193077564e-02
    z[1,5,4]  R657      4.1445949673652649e-01
    z[1,5,4]  R658      -5.0145995616912842e-01
    z[1,5,4]  R659      3.1634697318077087e-01
    z[1,5,4]  R660      3.2800965011119843e-02
    z[1,5,4]  R661      3.9694914221763611e-01
    z[1,5,4]  R662      -1.3578631915152073e-02
    z[1,5,4]  R663      -2.8430971503257751e-01
    z[1,5,4]  R664      -3.9041060209274292e-01
    z[1,5,4]  R665      4.7830536961555481e-01
    z[1,5,4]  R666      -2.0111978054046631e-01
    z[1,5,4]  R667      2.9851067066192627e-01
    z[1,5,4]  R668      -2.3639839142560959e-02
    z[1,5,4]  R669      -1.8404923379421234e-01
    z[1,5,4]  R670      -0.517731785774231
    z[1,5,4]  R671      -1.0070706158876419e-01
    z[1,5,4]  R672      -1.3634567148983479e-02
    z[1,5,4]  R673      -3.9490780234336853e-01
    z[1,5,4]  R674      -7.0081901550292969e-01
    z[1,5,4]  R675      -2.7202382683753967e-01
    z[1,5,4]  R676      -7.1624511480331421e-01
    z[1,5,4]  R677      -3.6926794052124023e-01
    z[1,5,4]  R678      -2.2502495348453522e-01
    z[1,5,4]  R679      -7.4040561914443970e-01
    z[1,5,4]  R680      -4.0332981944084167e-01
    z[1,5,4]  R681      1.3444192707538605e-01
    z[1,5,4]  R682      -3.1734594702720642e-01
    z[1,5,4]  R683      -2.3484092950820923e-01
    z[1,5,4]  R684      -2.9067406058311462e-01
    z[1,5,4]  R685      6.3229000568389893e-01
    z[1,5,4]  R686      -5.0736343860626221e-01
    z[1,5,4]  R687      0.506917417049408
    z[1,5,4]  R688      -7.7919833362102509e-02
    z[1,5,4]  R689      3.9742198586463928e-01
    z[1,5,4]  R690      1.0552708804607391e-01
    z[1,5,4]  R691      -1.6130340099334717e-01
    z[1,5,4]  R692      3.4851184487342834e-01
    z[1,5,4]  R693      -6.9361016154289246e-02
    z[1,5,4]  R694      1.2959606945514679e-01
    z[1,5,4]  R695      5.6489646434783936e-01
    z[1,5,4]  R696      4.8991441726684570e-03
    z[1,5,4]  R697      -2.3312436044216156e-01
    z[1,5,4]  R698      1.7073912918567657e-01
    z[1,5,4]  R699      2.7820253372192383e-01
    z[1,5,4]  R700      4.2034569382667542e-01
    z[1,5,4]  R701      1.9361329078674316e-01
    z[1,5,4]  R702      -2.8481376171112061e-01
    z[1,5,4]  R703      -2.1803827583789825e-01
    z[1,5,4]  R704      4.5129823684692383e-01
    z[1,5,4]  R705      1.5675261616706848e-01
    z[1,5,4]  R706      2.2391228377819061e-01
    z[1,5,4]  R707      -4.6196451783180237e-01
    z[1,5,4]  R708      -1.4771398901939392e-01
    z[1,5,4]  R709      -5.1097828149795532e-01
    z[1,5,4]  R710      -5.4421371221542358e-01
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R627      -1
    z[1,5,5]  R628      1
    z[1,5,5]  R631      -1.3769541680812836e-01
    z[1,5,5]  R632      -0.563877522945404
    z[1,5,5]  R633      8.5845552384853363e-03
    z[1,5,5]  R634      0.00700989319011569
    z[1,5,5]  R635      -5.6152928620576859e-02
    z[1,5,5]  R636      9.8681680858135223e-02
    z[1,5,5]  R637      -3.2476380467414856e-01
    z[1,5,5]  R638      7.6823040843009949e-02
    z[1,5,5]  R639      3.4556340426206589e-02
    z[1,5,5]  R640      -2.9272469878196716e-01
    z[1,5,5]  R641      -1.5474167652428150e-02
    z[1,5,5]  R642      1.0599581152200699e-01
    z[1,5,5]  R643      -2.5980386137962341e-01
    z[1,5,5]  R644      1.1180879175662994e-01
    z[1,5,5]  R645      0.0648990347981453
    z[1,5,5]  R646      2.8234541416168213e-01
    z[1,5,5]  R647      2.7899768948554993e-01
    z[1,5,5]  R648      1.2590293586254120e-01
    z[1,5,5]  R649      6.7350721359252930e-01
    z[1,5,5]  R650      9.8208189010620117e-02
    z[1,5,5]  R651      2.0516207814216614e-01
    z[1,5,5]  R652      -0.364769846200943
    z[1,5,5]  R653      8.3711095154285431e-02
    z[1,5,5]  R654      -2.5648900866508484e-01
    z[1,5,5]  R655      -2.9499495029449463e-01
    z[1,5,5]  R656      -1.0593015700578690e-01
    z[1,5,5]  R657      -2.6589006185531616e-01
    z[1,5,5]  R658      -7.9941317439079285e-02
    z[1,5,5]  R659      2.0427992939949036e-01
    z[1,5,5]  R660      1.9457958638668060e-01
    z[1,5,5]  R661      -7.8477680683135986e-02
    z[1,5,5]  R662      -1.4952444471418858e-02
    z[1,5,5]  R663      -7.9793877899646759e-02
    z[1,5,5]  R664      -0.0723300352692604
    z[1,5,5]  R665      2.5796961784362793e-01
    z[1,5,5]  R666      -5.6732857227325439e-01
    z[1,5,5]  R667      3.7883457541465759e-01
    z[1,5,5]  R668      4.5789572596549988e-01
    z[1,5,5]  R669      6.8522137403488159e-01
    z[1,5,5]  R670      5.4043656587600708e-01
    z[1,5,5]  R671      -5.0800494849681854e-02
    z[1,5,5]  R672      -9.4277925789356232e-02
    z[1,5,5]  R673      9.2811174690723419e-02
    z[1,5,5]  R674      3.6907397210597992e-02
    z[1,5,5]  R675      -0.507040798664093
    z[1,5,5]  R676      1.0643025487661362e-01
    z[1,5,5]  R677      1.7220909893512726e-01
    z[1,5,5]  R678      -1.8397654639557004e-03
    z[1,5,5]  R679      7.0711962878704071e-02
    z[1,5,5]  R680      -3.0457055568695068e-01
    z[1,5,5]  R681      3.8770747184753418e-01
    z[1,5,5]  R682      2.7283772826194763e-01
    z[1,5,5]  R683      -1.4870515465736389e-01
    z[1,5,5]  R684      -3.4204626083374023e-01
    z[1,5,5]  R685      0.234819233417511
    z[1,5,5]  R686      5.3635202348232269e-03
    z[1,5,5]  R687      -3.6725349724292755e-02
    z[1,5,5]  R688      -6.6040062904357910e-01
    z[1,5,5]  R689      -5.4062157869338989e-01
    z[1,5,5]  R690      5.1187169551849365e-01
    z[1,5,5]  R691      -3.2207533717155457e-02
    z[1,5,5]  R692      1.4508533477783203e-01
    z[1,5,5]  R693      1.7681367695331573e-02
    z[1,5,5]  R694      -4.5329424738883972e-01
    z[1,5,5]  R695      -3.1563788652420044e-01
    z[1,5,5]  R696      -0.0409686341881752
    z[1,5,5]  R697      -1.5406748652458191e-01
    z[1,5,5]  R698      -2.9729914665222168e-01
    z[1,5,5]  R699      3.2862354069948196e-02
    z[1,5,5]  R700      3.7902233004570007e-01
    z[1,5,5]  R701      -3.7913236021995544e-01
    z[1,5,5]  R702      4.6682532876729965e-02
    z[1,5,5]  R703      1.8612703308463097e-02
    z[1,5,5]  R704      1.2646466493606567e-01
    z[1,5,5]  R705      1.7543736100196838e-01
    z[1,5,5]  R706      4.8359864950180054e-01
    z[1,5,5]  R707      -2.4371019005775452e-01
    z[1,5,5]  R708      3.6099547147750854e-01
    z[1,5,5]  R709      3.1019651889801025e-01
    z[1,5,5]  R710      5.7240617275238037e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R629      -1
    z[1,5,6]  R630      1
    z[1,5,6]  R631      -5.5232111364603043e-02
    z[1,5,6]  R632      -2.7220547199249268e-01
    z[1,5,6]  R633      1.6095350682735443e-01
    z[1,5,6]  R634      -3.3334780484437943e-02
    z[1,5,6]  R635      -3.8633573055267334e-01
    z[1,5,6]  R636      -4.3321792036294937e-02
    z[1,5,6]  R637      2.1497417986392975e-01
    z[1,5,6]  R638      1.2258848547935486e-01
    z[1,5,6]  R639      -1.7597796022891998e-01
    z[1,5,6]  R640      -1.2156955152750015e-01
    z[1,5,6]  R641      -0.0600656233727932
    z[1,5,6]  R642      -1.8227970227599144e-02
    z[1,5,6]  R643      5.8530010282993317e-02
    z[1,5,6]  R644      -1.7670390009880066e-01
    z[1,5,6]  R645      3.7089386582374573e-01
    z[1,5,6]  R646      3.0736133456230164e-01
    z[1,5,6]  R647      7.1762762963771820e-02
    z[1,5,6]  R648      7.9394921660423279e-02
    z[1,5,6]  R649      1.7386290431022644e-01
    z[1,5,6]  R650      1.0488359630107880e-01
    z[1,5,6]  R651      1.4423468708992004e-01
    z[1,5,6]  R652      -1.8995878100395203e-01
    z[1,5,6]  R653      -1.7092873156070709e-01
    z[1,5,6]  R654      7.1612037718296051e-02
    z[1,5,6]  R655      -8.1680983304977417e-02
    z[1,5,6]  R656      5.1010406017303467e-01
    z[1,5,6]  R657      -1.4856582880020142e-01
    z[1,5,6]  R658      -1.9486727192997932e-02
    z[1,5,6]  R659      2.5488814339041710e-02
    z[1,5,6]  R660      -0.40351602435112
    z[1,5,6]  R661      -3.9917615056037903e-01
    z[1,5,6]  R662      5.8154135942459106e-02
    z[1,5,6]  R663      2.1559296175837517e-02
    z[1,5,6]  R664      2.2480469942092896e-01
    z[1,5,6]  R665      -4.2965874075889587e-01
    z[1,5,6]  R666      1.0333219915628433e-01
    z[1,5,6]  R667      2.1412852406501770e-01
    z[1,5,6]  R668      1.2260851263999939e-01
    z[1,5,6]  R669      3.2578937709331512e-02
    z[1,5,6]  R670      -8.6356140673160553e-02
    z[1,5,6]  R671      -2.3464743793010712e-01
    z[1,5,6]  R672      -0.00269176228903234
    z[1,5,6]  R673      -2.0108632743358612e-02
    z[1,5,6]  R674      -9.2202380299568176e-02
    z[1,5,6]  R675      -3.0818411707878113e-01
    z[1,5,6]  R676      2.7658066153526306e-01
    z[1,5,6]  R677      -3.6036711931228638e-01
    z[1,5,6]  R678      -2.0022788643836975e-01
    z[1,5,6]  R679      3.8570842146873474e-01
    z[1,5,6]  R680      4.3169371783733368e-02
    z[1,5,6]  R681      -2.3951490223407745e-01
    z[1,5,6]  R682      2.3476506769657135e-01
    z[1,5,6]  R683      -5.2156221866607666e-01
    z[1,5,6]  R684      -4.1077283024787903e-01
    z[1,5,6]  R685      -3.8127502799034119e-01
    z[1,5,6]  R686      7.4389182031154633e-02
    z[1,5,6]  R687      -5.8623957633972168e-01
    z[1,5,6]  R688      -1.9564349949359894e-01
    z[1,5,6]  R689      1.0843480378389359e-01
    z[1,5,6]  R690      3.2398089766502380e-01
    z[1,5,6]  R691      4.0459696203470230e-02
    z[1,5,6]  R692      1.4328195713460445e-02
    z[1,5,6]  R693      3.8968941569328308e-01
    z[1,5,6]  R694      -5.0769710540771484e-01
    z[1,5,6]  R695      -5.2033182233572006e-02
    z[1,5,6]  R696      -2.9633262753486633e-01
    z[1,5,6]  R697      1.1406043171882629e-01
    z[1,5,6]  R698      1.0423842817544937e-01
    z[1,5,6]  R699      3.0068987607955933e-01
    z[1,5,6]  R700      2.0920639857649803e-02
    z[1,5,6]  R701      -2.9510427266359329e-02
    z[1,5,6]  R702      -2.2846154868602753e-01
    z[1,5,6]  R703      7.8258194029331207e-02
    z[1,5,6]  R704      -9.1191329061985016e-02
    z[1,5,6]  R705      1.6566129028797150e-01
    z[1,5,6]  R706      -4.1446119546890259e-02
    z[1,5,6]  R707      3.5865768790245056e-01
    z[1,5,6]  R708      2.5416895747184753e-01
    z[1,5,6]  R709      -5.0566267222166061e-02
    z[1,5,6]  R710      2.9101157188415527e-01
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R711      -1
    z[5,1,0]  R712      1
    z[5,1,0]  R725      -2.4731977283954620e-01
    z[5,1,0]  R726      0.085629403591156
    z[5,1,0]  R727      5.9188399463891983e-02
    z[5,1,0]  R728      -1.6589473187923431e-01
    z[5,1,0]  R729      -1.7032325267791748e-02
    z[5,1,0]  R730      -4.5395351946353912e-02
    z[5,1,0]  R731      -1.6201204061508179e-01
    z[5,1,0]  R732      -1.8934737890958786e-02
    z[5,1,0]  R733      0.150125190615654
    z[5,1,0]  R734      -3.8735404610633850e-01
    z[5,1,0]  R735      -2.1382641792297363e-01
    z[5,1,0]  R736      -3.5925221443176270e-01
    z[5,1,0]  R737      -3.9004248380661011e-01
    z[5,1,0]  R738      -8.7264098227024078e-02
    z[5,1,0]  R739      1.8645381554961205e-02
    z[5,1,0]  R740      -3.1487077474594116e-01
    z[5,1,0]  R741      -6.3983634114265442e-02
    z[5,1,0]  R742      3.1601474620401859e-03
    z[5,1,0]  R743      2.7315232157707214e-01
    z[5,1,0]  R744      -1.1055515706539154e-01
    z[5,1,0]  R745      -5.3513408638536930e-03
    z[5,1,0]  R746      1.9580383598804474e-01
    z[5,1,0]  R747      4.4064730405807495e-01
    z[5,1,0]  R748      2.6081116870045662e-02
    z[5,1,0]  R749      2.1425299346446991e-01
    z[5,1,0]  R750      -2.5385084748268127e-01
    z[5,1,0]  R751      -5.7478111237287521e-02
    z[5,1,0]  R752      8.5354052484035492e-02
    z[5,1,0]  R753      2.3851613700389862e-01
    z[5,1,0]  R754      -1.3423493504524231e-01
    z[5,1,0]  R755      -3.6913685500621796e-02
    z[5,1,0]  R756      -2.1532289683818817e-01
    z[5,1,0]  R757      -2.3875330388545990e-01
    z[5,1,0]  R758      9.2885173857212067e-02
    z[5,1,0]  R759      5.3868040442466736e-02
    z[5,1,0]  R760      1.3729308545589447e-01
    z[5,1,0]  R761      1.9400085508823395e-01
    z[5,1,0]  R762      2.4801792204380035e-01
    z[5,1,0]  R763      5.0494468212127686e-01
    z[5,1,0]  R764      2.1552659571170807e-01
    z[5,1,0]  R765      1.4682796597480774e-01
    z[5,1,0]  R766      -1.9448599219322205e-01
    z[5,1,0]  R767      -7.6547443866729736e-01
    z[5,1,0]  R768      -7.8703552484512329e-01
    z[5,1,0]  R769      -7.6065880060195923e-01
    z[5,1,0]  R770      -6.8503272533416748e-01
    z[5,1,0]  R771      -6.9114369153976440e-01
    z[5,1,0]  R772      -6.5381234884262085e-01
    z[5,1,0]  R773      -9.3975865840911865e-01
    z[5,1,0]  R774      -8.9000082015991211e-01
    z[5,1,0]  R775      1.1959818750619888e-01
    z[5,1,0]  R776      -2.8266675770282745e-02
    z[5,1,0]  R777      -3.5147402435541153e-02
    z[5,1,0]  R778      -5.2857872098684311e-02
    z[5,1,0]  R779      2.5732627511024475e-01
    z[5,1,0]  R780      3.3204281330108643e-01
    z[5,1,0]  R781      0.0271154772490263
    z[5,1,0]  R782      2.2598467767238617e-01
    z[5,1,0]  R783      -2.0111760124564171e-02
    z[5,1,0]  R784      4.0740448981523514e-02
    z[5,1,0]  R785      -9.2747874557971954e-02
    z[5,1,0]  R786      -2.0706218481063843e-01
    z[5,1,0]  R787      -1.4613938517868519e-02
    z[5,1,0]  R788      -2.3697561025619507e-01
    z[5,1,0]  R789      4.6550330519676208e-01
    z[5,1,0]  R790      3.2529163360595703e-01
    z[5,1,0]  R791      1.3015180826187134e-01
    z[5,1,0]  R792      2.8493487834930420e-01
    z[5,1,0]  R793      3.9687082171440125e-02
    z[5,1,0]  R794      -2.0952665805816650e-01
    z[5,1,0]  R795      -1.8916824460029602e-01
    z[5,1,0]  R796      -2.1669808030128479e-01
    z[5,1,0]  R797      -4.5104026794433594e-02
    z[5,1,0]  R798      3.3271864056587219e-02
    z[5,1,0]  R799      -3.1536030769348145e-01
    z[5,1,0]  R800      -2.4552899599075317e-01
    z[5,1,0]  R801      2.7699765563011169e-01
    z[5,1,0]  R802      2.2148096561431885e-01
    z[5,1,0]  R803      -9.6354849636554718e-02
    z[5,1,0]  R804      -9.6015587449073792e-02
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R713      -1
    z[5,1,1]  R714      1
    z[5,1,1]  R725      9.2446643114089966e-01
    z[5,1,1]  R726      9.8886710405349731e-01
    z[5,1,1]  R727      -3.0416840687394142e-02
    z[5,1,1]  R728      6.3676489517092705e-03
    z[5,1,1]  R729      5.7651054859161377e-01
    z[5,1,1]  R730      -3.4543506801128387e-02
    z[5,1,1]  R731      -0.0232999287545681
    z[5,1,1]  R732      -3.5011786967515945e-02
    z[5,1,1]  R733      -6.4352788031101227e-02
    z[5,1,1]  R734      -5.5713269859552383e-02
    z[5,1,1]  R735      -6.2276363372802734e-01
    z[5,1,1]  R736      -6.0613393783569336e-01
    z[5,1,1]  R737      -0.557383120059967
    z[5,1,1]  R738      -5.5232745409011841e-01
    z[5,1,1]  R739      -5.3412622213363647e-01
    z[5,1,1]  R740      -5.6050300598144531e-01
    z[5,1,1]  R741      -4.9303579330444336e-01
    z[5,1,1]  R742      -5.4293894767761230e-01
    z[5,1,1]  R743      -5.5307763814926147e-01
    z[5,1,1]  R744      -4.9725890159606934e-01
    z[5,1,1]  R745      -9.8264390230178833e-01
    z[5,1,1]  R746      -7.9808372259140015e-01
    z[5,1,1]  R747      -6.5045034885406494e-01
    z[5,1,1]  R748      -4.5593962073326111e-01
    z[5,1,1]  R749      0.483502060174942
    z[5,1,1]  R750      6.7729687690734863e-01
    z[5,1,1]  R751      5.8949595689773560e-01
    z[5,1,1]  R752      3.5691463947296143e-01
    z[5,1,1]  R753      7.8776067495346069e-01
    z[5,1,1]  R754      5.6254655122756958e-01
    z[5,1,1]  R755      0.73489910364151
    z[5,1,1]  R756      0.717809796333313
    z[5,1,1]  R757      8.3352595567703247e-01
    z[5,1,1]  R758      7.7697873115539551e-01
    z[5,1,1]  R759      6.3356381654739380e-01
    z[5,1,1]  R760      6.9384175539016724e-01
    z[5,1,1]  R761      7.0997720956802368e-01
    z[5,1,1]  R762      7.7718651294708252e-01
    z[5,1,1]  R763      -2.2949238121509552e-01
    z[5,1,1]  R764      -7.7543258666992188e-02
    z[5,1,1]  R765      9.7079819440841675e-01
    z[5,1,1]  R766      6.4031040668487549e-01
    z[5,1,1]  R767      -0.138684943318367
    z[5,1,1]  R768      -1.3560040295124054e-01
    z[5,1,1]  R769      -5.1290322095155716e-02
    z[5,1,1]  R770      -0.0711161345243454
    z[5,1,1]  R771      1.1851778626441956e-01
    z[5,1,1]  R772      1.6843172907829285e-01
    z[5,1,1]  R773      9.2258296906948090e-02
    z[5,1,1]  R774      -1.0521542280912399e-01
    z[5,1,1]  R775      1.1808297038078308e-01
    z[5,1,1]  R776      -1.7224618792533875e-01
    z[5,1,1]  R777      -2.3573809862136841e-01
    z[5,1,1]  R778      -1.2717759609222412e-01
    z[5,1,1]  R779      -3.2212957739830017e-01
    z[5,1,1]  R780      -2.7359953522682190e-01
    z[5,1,1]  R781      -2.7333667874336243e-01
    z[5,1,1]  R782      -4.5951792597770691e-01
    z[5,1,1]  R783      -4.3252980709075928e-01
    z[5,1,1]  R784      -1.1579956859350204e-01
    z[5,1,1]  R785      -9.5399028062820435e-01
    z[5,1,1]  R786      -7.8108400106430054e-01
    z[5,1,1]  R787      -8.0746436119079590e-01
    z[5,1,1]  R788      -7.8210854530334473e-01
    z[5,1,1]  R789      -7.1410173177719116e-01
    z[5,1,1]  R790      -7.8637742996215820e-01
    z[5,1,1]  R791      -7.4421435594558716e-01
    z[5,1,1]  R792      -0.700564444065094
    z[5,1,1]  R793      -6.8744331598281860e-01
    z[5,1,1]  R794      -7.0553278923034668e-01
    z[5,1,1]  R795      5.8930778503417969e-01
    z[5,1,1]  R796      5.5380409955978394e-01
    z[5,1,1]  R797      -7.1062213182449341e-01
    z[5,1,1]  R798      7.0085096359252930e-01
    z[5,1,1]  R799      -6.4749735593795776e-01
    z[5,1,1]  R800      -5.9957367181777954e-01
    z[5,1,1]  R801      5.0419336557388306e-01
    z[5,1,1]  R802      0.506360650062561
    z[5,1,1]  R803      5.4126524925231934e-01
    z[5,1,1]  R804      -3.6219015717506409e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R715      -1
    z[5,1,2]  R716      1
    z[5,1,2]  R725      8.9352488517761230e-02
    z[5,1,2]  R726      -0.0491953007876873
    z[5,1,2]  R727      -7.9013854265213013e-01
    z[5,1,2]  R728      -6.8222486972808838e-01
    z[5,1,2]  R729      -1.4217109978199005e-01
    z[5,1,2]  R730      -5.9088891744613647e-01
    z[5,1,2]  R731      -8.1355655193328857e-01
    z[5,1,2]  R732      -5.0917977094650269e-01
    z[5,1,2]  R733      -4.6965035796165466e-01
    z[5,1,2]  R734      -6.6920286417007446e-01
    z[5,1,2]  R735      1.2158872932195663e-01
    z[5,1,2]  R736      4.0791156888008118e-01
    z[5,1,2]  R737      -3.8222637772560120e-01
    z[5,1,2]  R738      -5.6150525808334351e-01
    z[5,1,2]  R739      -3.2182133197784424e-01
    z[5,1,2]  R740      -5.4858695715665817e-02
    z[5,1,2]  R741      -2.4375198781490326e-01
    z[5,1,2]  R742      -1.9812296330928802e-01
    z[5,1,2]  R743      3.9448940753936768e-01
    z[5,1,2]  R744      5.7450169324874878e-01
    z[5,1,2]  R745      -0.0683421716094017
    z[5,1,2]  R746      -2.9872161149978638e-01
    z[5,1,2]  R747      -3.4258782863616943e-02
    z[5,1,2]  R748      -2.4924477934837341e-01
    z[5,1,2]  R749      4.2520549893379211e-01
    z[5,1,2]  R750      3.0196332931518555e-01
    z[5,1,2]  R751      4.8791524767875671e-01
    z[5,1,2]  R752      6.5476822853088379e-01
    z[5,1,2]  R753      3.7515634298324585e-01
    z[5,1,2]  R754      5.4492139816284180e-01
    z[5,1,2]  R755      5.1817828416824341e-01
    z[5,1,2]  R756      2.5820646435022354e-02
    z[5,1,2]  R757      4.3365576863288879e-01
    z[5,1,2]  R758      2.0073603093624115e-01
    z[5,1,2]  R759      4.8572579026222229e-01
    z[5,1,2]  R760      -2.1406058967113495e-01
    z[5,1,2]  R761      1.0951752215623856e-01
    z[5,1,2]  R762      -3.0360126495361328e-01
    z[5,1,2]  R763      -5.7654780149459839e-01
    z[5,1,2]  R764      -4.5599821209907532e-01
    z[5,1,2]  R765      -2.8458578512072563e-02
    z[5,1,2]  R766      9.8333068192005157e-02
    z[5,1,2]  R767      1.6744644939899445e-01
    z[5,1,2]  R768      -3.2325658202171326e-01
    z[5,1,2]  R769      9.7997933626174927e-02
    z[5,1,2]  R770      -5.4415683262050152e-03
    z[5,1,2]  R771      -0.257853627204895
    z[5,1,2]  R772      -3.0794674158096313e-01
    z[5,1,2]  R773      -2.4678991734981537e-01
    z[5,1,2]  R774      2.6114261150360107e-01
    z[5,1,2]  R775      0.527817964553833
    z[5,1,2]  R776      -4.0941774845123291e-01
    z[5,1,2]  R777      -4.9897426366806030e-01
    z[5,1,2]  R778      -7.5336736440658569e-01
    z[5,1,2]  R779      -4.1837871074676514e-01
    z[5,1,2]  R780      -6.3643521070480347e-01
    z[5,1,2]  R781      -3.6294567584991455e-01
    z[5,1,2]  R782      -6.7835921049118042e-01
    z[5,1,2]  R783      -2.8625974059104919e-01
    z[5,1,2]  R784      -0.603752076625824
    z[5,1,2]  R785      6.9415479898452759e-02
    z[5,1,2]  R786      -2.3059016466140747e-01
    z[5,1,2]  R787      3.4395694732666016e-01
    z[5,1,2]  R788      3.1662932038307190e-01
    z[5,1,2]  R789      -1.4114160835742950e-01
    z[5,1,2]  R790      -6.4147412776947021e-02
    z[5,1,2]  R791      -4.0544936060905457e-01
    z[5,1,2]  R792      7.3663949966430664e-02
    z[5,1,2]  R793      2.8105584904551506e-02
    z[5,1,2]  R794      4.0016758441925049e-01
    z[5,1,2]  R795      0.273367315530777
    z[5,1,2]  R796      7.4711114168167114e-01
    z[5,1,2]  R797      -4.7318261861801147e-01
    z[5,1,2]  R798      2.1705015003681183e-01
    z[5,1,2]  R799      3.5083245486021042e-02
    z[5,1,2]  R800      2.7878111600875854e-01
    z[5,1,2]  R801      2.4471163749694824e-01
    z[5,1,2]  R802      -1.4625380933284760e-01
    z[5,1,2]  R803      1.8711602687835693e-01
    z[5,1,2]  R804      -2.6298427581787109e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R717      -1
    z[5,1,3]  R718      1
    z[5,1,3]  R725      -0.0918092280626297
    z[5,1,3]  R726      -5.7513605803251266e-02
    z[5,1,3]  R727      4.5418307185173035e-01
    z[5,1,3]  R728      7.7439472079277039e-02
    z[5,1,3]  R729      -4.7017872333526611e-01
    z[5,1,3]  R730      2.1625219285488129e-01
    z[5,1,3]  R731      1.2432087957859039e-01
    z[5,1,3]  R732      8.0524575710296631e-01
    z[5,1,3]  R733      2.2533978521823883e-01
    z[5,1,3]  R734      3.7645533680915833e-01
    z[5,1,3]  R735      -5.7087731361389160e-01
    z[5,1,3]  R736      3.2693132758140564e-01
    z[5,1,3]  R737      2.0445835590362549e-01
    z[5,1,3]  R738      -4.2540755122900009e-02
    z[5,1,3]  R739      1.0242677479982376e-01
    z[5,1,3]  R740      5.6630659103393555e-01
    z[5,1,3]  R741      -3.0235049128532410e-01
    z[5,1,3]  R742      4.3067130446434021e-01
    z[5,1,3]  R743      -4.3552737683057785e-02
    z[5,1,3]  R744      -1.7985163629055023e-01
    z[5,1,3]  R745      -3.1912997364997864e-02
    z[5,1,3]  R746      3.0458664894104004e-01
    z[5,1,3]  R747      -4.7390836477279663e-01
    z[5,1,3]  R748      -4.9928811192512512e-01
    z[5,1,3]  R749      -3.4362620115280151e-01
    z[5,1,3]  R750      -5.4417955875396729e-01
    z[5,1,3]  R751      -5.6571716070175171e-01
    z[5,1,3]  R752      -5.5515849590301514e-01
    z[5,1,3]  R753      -1.1362207680940628e-01
    z[5,1,3]  R754      -2.1862530708312988e-01
    z[5,1,3]  R755      -8.9182555675506592e-02
    z[5,1,3]  R756      -5.4975038766860962e-01
    z[5,1,3]  R757      -7.8502416610717773e-02
    z[5,1,3]  R758      -3.4554621577262878e-01
    z[5,1,3]  R759      -0.526281476020813
    z[5,1,3]  R760      -4.1011002659797668e-01
    z[5,1,3]  R761      -2.1180368959903717e-01
    z[5,1,3]  R762      -1.5986070036888123e-01
    z[5,1,3]  R763      8.8934656232595444e-03
    z[5,1,3]  R764      1.7634023725986481e-01
    z[5,1,3]  R765      -1.0652960836887360e-01
    z[5,1,3]  R766      -3.7224423885345459e-01
    z[5,1,3]  R767      5.8253329992294312e-01
    z[5,1,3]  R768      4.3245518207550049e-01
    z[5,1,3]  R769      4.9656990170478821e-01
    z[5,1,3]  R770      5.7550114393234253e-01
    z[5,1,3]  R771      5.2948659658432007e-01
    z[5,1,3]  R772      6.5426230430603027e-01
    z[5,1,3]  R773      9.0064838528633118e-02
    z[5,1,3]  R774      1.2413965165615082e-01
    z[5,1,3]  R775      7.1115463972091675e-02
    z[5,1,3]  R776      6.2369710206985474e-01
    z[5,1,3]  R777      4.5309442281723022e-01
    z[5,1,3]  R778      3.4645467996597290e-01
    z[5,1,3]  R779      5.4036104679107666e-01
    z[5,1,3]  R780      2.8364226222038269e-01
    z[5,1,3]  R781      7.6607018709182739e-01
    z[5,1,3]  R782      0.468136727809906
    z[5,1,3]  R783      2.8573292493820190e-01
    z[5,1,3]  R784      1.3243648409843445e-01
    z[5,1,3]  R785      1.1205623298883438e-01
    z[5,1,3]  R786      3.3471721410751343e-01
    z[5,1,3]  R787      4.3947091698646545e-01
    z[5,1,3]  R788      3.9231842756271362e-01
    z[5,1,3]  R789      3.9689761400222778e-01
    z[5,1,3]  R790      -7.3697227053344250e-03
    z[5,1,3]  R791      -1.6436351463198662e-02
    z[5,1,3]  R792      -4.0541672706604004e-01
    z[5,1,3]  R793      -6.1854767799377441e-01
    z[5,1,3]  R794      -3.1052476167678833e-01
    z[5,1,3]  R795      -4.6811640262603760e-01
    z[5,1,3]  R796      -2.9047888517379761e-01
    z[5,1,3]  R797      -4.2592954635620117e-01
    z[5,1,3]  R798      -5.0239515304565430e-01
    z[5,1,3]  R799      1.1542630381882191e-02
    z[5,1,3]  R800      -3.5988822579383850e-01
    z[5,1,3]  R801      -5.7506734132766724e-01
    z[5,1,3]  R802      -6.6924935579299927e-01
    z[5,1,3]  R803      -3.9783358573913574e-01
    z[5,1,3]  R804      4.7208401560783386e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R719      -1
    z[5,1,4]  R720      1
    z[5,1,4]  R725      -1.0070706158876419e-01
    z[5,1,4]  R726      -1.3634567148983479e-02
    z[5,1,4]  R727      -3.9490780234336853e-01
    z[5,1,4]  R728      -7.0081901550292969e-01
    z[5,1,4]  R729      -2.7202382683753967e-01
    z[5,1,4]  R730      -7.1624511480331421e-01
    z[5,1,4]  R731      -3.6926794052124023e-01
    z[5,1,4]  R732      -2.2502495348453522e-01
    z[5,1,4]  R733      -7.4040561914443970e-01
    z[5,1,4]  R734      -4.0332981944084167e-01
    z[5,1,4]  R735      1.3444192707538605e-01
    z[5,1,4]  R736      -3.1734594702720642e-01
    z[5,1,4]  R737      -2.3484092950820923e-01
    z[5,1,4]  R738      -2.9067406058311462e-01
    z[5,1,4]  R739      6.3229000568389893e-01
    z[5,1,4]  R740      -5.0736343860626221e-01
    z[5,1,4]  R741      0.506917417049408
    z[5,1,4]  R742      -7.7919833362102509e-02
    z[5,1,4]  R743      3.9742198586463928e-01
    z[5,1,4]  R744      1.0552708804607391e-01
    z[5,1,4]  R745      -1.6130340099334717e-01
    z[5,1,4]  R746      3.4851184487342834e-01
    z[5,1,4]  R747      -6.9361016154289246e-02
    z[5,1,4]  R748      1.2959606945514679e-01
    z[5,1,4]  R749      5.6489646434783936e-01
    z[5,1,4]  R750      4.8991441726684570e-03
    z[5,1,4]  R751      -2.3312436044216156e-01
    z[5,1,4]  R752      1.7073912918567657e-01
    z[5,1,4]  R753      2.7820253372192383e-01
    z[5,1,4]  R754      4.2034569382667542e-01
    z[5,1,4]  R755      1.9361329078674316e-01
    z[5,1,4]  R756      -2.8481376171112061e-01
    z[5,1,4]  R757      -2.1803827583789825e-01
    z[5,1,4]  R758      4.5129823684692383e-01
    z[5,1,4]  R759      1.5675261616706848e-01
    z[5,1,4]  R760      2.2391228377819061e-01
    z[5,1,4]  R761      -4.6196451783180237e-01
    z[5,1,4]  R762      -1.4771398901939392e-01
    z[5,1,4]  R763      -5.1097828149795532e-01
    z[5,1,4]  R764      -5.4421371221542358e-01
    z[5,1,4]  R765      -4.2701106518507004e-02
    z[5,1,4]  R766      -1.0903651267290115e-01
    z[5,1,4]  R767      -3.8109406828880310e-02
    z[5,1,4]  R768      -2.6365658640861511e-01
    z[5,1,4]  R769      -1.0086496174335480e-01
    z[5,1,4]  R770      -4.2758235335350037e-01
    z[5,1,4]  R771      -0.0987108051776886
    z[5,1,4]  R772      -1.8443804234266281e-02
    z[5,1,4]  R773      -8.4633342921733856e-02
    z[5,1,4]  R774      -1.1293911933898926e-01
    z[5,1,4]  R775      0.827197790145874
    z[5,1,4]  R776      -6.3351714611053467e-01
    z[5,1,4]  R777      -6.4652818441390991e-01
    z[5,1,4]  R778      -4.9971318244934082e-01
    z[5,1,4]  R779      -4.7033041715621948e-01
    z[5,1,4]  R780      -3.9395216107368469e-01
    z[5,1,4]  R781      -3.5066959261894226e-01
    z[5,1,4]  R782      -1.9051505625247955e-01
    z[5,1,4]  R783      -4.0630677342414856e-01
    z[5,1,4]  R784      -7.6303946971893311e-01
    z[5,1,4]  R785      3.2096426934003830e-02
    z[5,1,4]  R786      -1.1262485384941101e-01
    z[5,1,4]  R787      -1.1069152504205704e-02
    z[5,1,4]  R788      -8.4059886634349823e-02
    z[5,1,4]  R789      -0.0471460185945034
    z[5,1,4]  R790      -1.4118281193077564e-02
    z[5,1,4]  R791      4.1445949673652649e-01
    z[5,1,4]  R792      -5.0145995616912842e-01
    z[5,1,4]  R793      3.1634697318077087e-01
    z[5,1,4]  R794      3.2800965011119843e-02
    z[5,1,4]  R795      3.9694914221763611e-01
    z[5,1,4]  R796      -1.3578631915152073e-02
    z[5,1,4]  R797      -2.8430971503257751e-01
    z[5,1,4]  R798      -3.9041060209274292e-01
    z[5,1,4]  R799      4.7830536961555481e-01
    z[5,1,4]  R800      -2.0111978054046631e-01
    z[5,1,4]  R801      2.9851067066192627e-01
    z[5,1,4]  R802      -2.3639839142560959e-02
    z[5,1,4]  R803      -1.8404923379421234e-01
    z[5,1,4]  R804      -0.517731785774231
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R721      -1
    z[5,1,5]  R722      1
    z[5,1,5]  R725      -5.0800494849681854e-02
    z[5,1,5]  R726      -9.4277925789356232e-02
    z[5,1,5]  R727      9.2811174690723419e-02
    z[5,1,5]  R728      3.6907397210597992e-02
    z[5,1,5]  R729      -0.507040798664093
    z[5,1,5]  R730      1.0643025487661362e-01
    z[5,1,5]  R731      1.7220909893512726e-01
    z[5,1,5]  R732      -1.8397654639557004e-03
    z[5,1,5]  R733      7.0711962878704071e-02
    z[5,1,5]  R734      -3.0457055568695068e-01
    z[5,1,5]  R735      3.8770747184753418e-01
    z[5,1,5]  R736      2.7283772826194763e-01
    z[5,1,5]  R737      -1.4870515465736389e-01
    z[5,1,5]  R738      -3.4204626083374023e-01
    z[5,1,5]  R739      0.234819233417511
    z[5,1,5]  R740      5.3635202348232269e-03
    z[5,1,5]  R741      -3.6725349724292755e-02
    z[5,1,5]  R742      -6.6040062904357910e-01
    z[5,1,5]  R743      -5.4062157869338989e-01
    z[5,1,5]  R744      5.1187169551849365e-01
    z[5,1,5]  R745      -3.2207533717155457e-02
    z[5,1,5]  R746      1.4508533477783203e-01
    z[5,1,5]  R747      1.7681367695331573e-02
    z[5,1,5]  R748      -4.5329424738883972e-01
    z[5,1,5]  R749      -3.1563788652420044e-01
    z[5,1,5]  R750      -0.0409686341881752
    z[5,1,5]  R751      -1.5406748652458191e-01
    z[5,1,5]  R752      -2.9729914665222168e-01
    z[5,1,5]  R753      3.2862354069948196e-02
    z[5,1,5]  R754      3.7902233004570007e-01
    z[5,1,5]  R755      -3.7913236021995544e-01
    z[5,1,5]  R756      4.6682532876729965e-02
    z[5,1,5]  R757      1.8612703308463097e-02
    z[5,1,5]  R758      1.2646466493606567e-01
    z[5,1,5]  R759      1.7543736100196838e-01
    z[5,1,5]  R760      4.8359864950180054e-01
    z[5,1,5]  R761      -2.4371019005775452e-01
    z[5,1,5]  R762      3.6099547147750854e-01
    z[5,1,5]  R763      3.1019651889801025e-01
    z[5,1,5]  R764      5.7240617275238037e-01
    z[5,1,5]  R765      -1.3769541680812836e-01
    z[5,1,5]  R766      -0.563877522945404
    z[5,1,5]  R767      8.5845552384853363e-03
    z[5,1,5]  R768      0.00700989319011569
    z[5,1,5]  R769      -5.6152928620576859e-02
    z[5,1,5]  R770      9.8681680858135223e-02
    z[5,1,5]  R771      -3.2476380467414856e-01
    z[5,1,5]  R772      7.6823040843009949e-02
    z[5,1,5]  R773      3.4556340426206589e-02
    z[5,1,5]  R774      -2.9272469878196716e-01
    z[5,1,5]  R775      -1.5474167652428150e-02
    z[5,1,5]  R776      1.0599581152200699e-01
    z[5,1,5]  R777      -2.5980386137962341e-01
    z[5,1,5]  R778      1.1180879175662994e-01
    z[5,1,5]  R779      0.0648990347981453
    z[5,1,5]  R780      2.8234541416168213e-01
    z[5,1,5]  R781      2.7899768948554993e-01
    z[5,1,5]  R782      1.2590293586254120e-01
    z[5,1,5]  R783      6.7350721359252930e-01
    z[5,1,5]  R784      9.8208189010620117e-02
    z[5,1,5]  R785      2.0516207814216614e-01
    z[5,1,5]  R786      -0.364769846200943
    z[5,1,5]  R787      8.3711095154285431e-02
    z[5,1,5]  R788      -2.5648900866508484e-01
    z[5,1,5]  R789      -2.9499495029449463e-01
    z[5,1,5]  R790      -1.0593015700578690e-01
    z[5,1,5]  R791      -2.6589006185531616e-01
    z[5,1,5]  R792      -7.9941317439079285e-02
    z[5,1,5]  R793      2.0427992939949036e-01
    z[5,1,5]  R794      1.9457958638668060e-01
    z[5,1,5]  R795      -7.8477680683135986e-02
    z[5,1,5]  R796      -1.4952444471418858e-02
    z[5,1,5]  R797      -7.9793877899646759e-02
    z[5,1,5]  R798      -0.0723300352692604
    z[5,1,5]  R799      2.5796961784362793e-01
    z[5,1,5]  R800      -5.6732857227325439e-01
    z[5,1,5]  R801      3.7883457541465759e-01
    z[5,1,5]  R802      4.5789572596549988e-01
    z[5,1,5]  R803      6.8522137403488159e-01
    z[5,1,5]  R804      5.4043656587600708e-01
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R723      -1
    z[5,1,6]  R724      1
    z[5,1,6]  R725      -2.3464743793010712e-01
    z[5,1,6]  R726      -0.00269176228903234
    z[5,1,6]  R727      -2.0108632743358612e-02
    z[5,1,6]  R728      -9.2202380299568176e-02
    z[5,1,6]  R729      -3.0818411707878113e-01
    z[5,1,6]  R730      2.7658066153526306e-01
    z[5,1,6]  R731      -3.6036711931228638e-01
    z[5,1,6]  R732      -2.0022788643836975e-01
    z[5,1,6]  R733      3.8570842146873474e-01
    z[5,1,6]  R734      4.3169371783733368e-02
    z[5,1,6]  R735      -2.3951490223407745e-01
    z[5,1,6]  R736      2.3476506769657135e-01
    z[5,1,6]  R737      -5.2156221866607666e-01
    z[5,1,6]  R738      -4.1077283024787903e-01
    z[5,1,6]  R739      -3.8127502799034119e-01
    z[5,1,6]  R740      7.4389182031154633e-02
    z[5,1,6]  R741      -5.8623957633972168e-01
    z[5,1,6]  R742      -1.9564349949359894e-01
    z[5,1,6]  R743      1.0843480378389359e-01
    z[5,1,6]  R744      3.2398089766502380e-01
    z[5,1,6]  R745      4.0459696203470230e-02
    z[5,1,6]  R746      1.4328195713460445e-02
    z[5,1,6]  R747      3.8968941569328308e-01
    z[5,1,6]  R748      -5.0769710540771484e-01
    z[5,1,6]  R749      -5.2033182233572006e-02
    z[5,1,6]  R750      -2.9633262753486633e-01
    z[5,1,6]  R751      1.1406043171882629e-01
    z[5,1,6]  R752      1.0423842817544937e-01
    z[5,1,6]  R753      3.0068987607955933e-01
    z[5,1,6]  R754      2.0920639857649803e-02
    z[5,1,6]  R755      -2.9510427266359329e-02
    z[5,1,6]  R756      -2.2846154868602753e-01
    z[5,1,6]  R757      7.8258194029331207e-02
    z[5,1,6]  R758      -9.1191329061985016e-02
    z[5,1,6]  R759      1.6566129028797150e-01
    z[5,1,6]  R760      -4.1446119546890259e-02
    z[5,1,6]  R761      3.5865768790245056e-01
    z[5,1,6]  R762      2.5416895747184753e-01
    z[5,1,6]  R763      -5.0566267222166061e-02
    z[5,1,6]  R764      2.9101157188415527e-01
    z[5,1,6]  R765      -5.5232111364603043e-02
    z[5,1,6]  R766      -2.7220547199249268e-01
    z[5,1,6]  R767      1.6095350682735443e-01
    z[5,1,6]  R768      -3.3334780484437943e-02
    z[5,1,6]  R769      -3.8633573055267334e-01
    z[5,1,6]  R770      -4.3321792036294937e-02
    z[5,1,6]  R771      2.1497417986392975e-01
    z[5,1,6]  R772      1.2258848547935486e-01
    z[5,1,6]  R773      -1.7597796022891998e-01
    z[5,1,6]  R774      -1.2156955152750015e-01
    z[5,1,6]  R775      -0.0600656233727932
    z[5,1,6]  R776      -1.8227970227599144e-02
    z[5,1,6]  R777      5.8530010282993317e-02
    z[5,1,6]  R778      -1.7670390009880066e-01
    z[5,1,6]  R779      3.7089386582374573e-01
    z[5,1,6]  R780      3.0736133456230164e-01
    z[5,1,6]  R781      7.1762762963771820e-02
    z[5,1,6]  R782      7.9394921660423279e-02
    z[5,1,6]  R783      1.7386290431022644e-01
    z[5,1,6]  R784      1.0488359630107880e-01
    z[5,1,6]  R785      1.4423468708992004e-01
    z[5,1,6]  R786      -1.8995878100395203e-01
    z[5,1,6]  R787      -1.7092873156070709e-01
    z[5,1,6]  R788      7.1612037718296051e-02
    z[5,1,6]  R789      -8.1680983304977417e-02
    z[5,1,6]  R790      5.1010406017303467e-01
    z[5,1,6]  R791      -1.4856582880020142e-01
    z[5,1,6]  R792      -1.9486727192997932e-02
    z[5,1,6]  R793      2.5488814339041710e-02
    z[5,1,6]  R794      -0.40351602435112
    z[5,1,6]  R795      -3.9917615056037903e-01
    z[5,1,6]  R796      5.8154135942459106e-02
    z[5,1,6]  R797      2.1559296175837517e-02
    z[5,1,6]  R798      2.2480469942092896e-01
    z[5,1,6]  R799      -4.2965874075889587e-01
    z[5,1,6]  R800      1.0333219915628433e-01
    z[5,1,6]  R801      2.1412852406501770e-01
    z[5,1,6]  R802      1.2260851263999939e-01
    z[5,1,6]  R803      3.2578937709331512e-02
    z[5,1,6]  R804      -8.6356140673160553e-02
    z[1,6,0]  R11       -1
    z[1,6,0]  R56       1
    z[1,6,0]  R805      -1
    z[1,6,0]  R806      1
    z[1,6,0]  R819      1.4682796597480774e-01
    z[1,6,0]  R820      -1.9448599219322205e-01
    z[1,6,0]  R821      -7.6547443866729736e-01
    z[1,6,0]  R822      -7.8703552484512329e-01
    z[1,6,0]  R823      -7.6065880060195923e-01
    z[1,6,0]  R824      -6.8503272533416748e-01
    z[1,6,0]  R825      -6.9114369153976440e-01
    z[1,6,0]  R826      -6.5381234884262085e-01
    z[1,6,0]  R827      -9.3975865840911865e-01
    z[1,6,0]  R828      -8.9000082015991211e-01
    z[1,6,0]  R829      1.1959818750619888e-01
    z[1,6,0]  R830      -2.8266675770282745e-02
    z[1,6,0]  R831      -3.5147402435541153e-02
    z[1,6,0]  R832      -5.2857872098684311e-02
    z[1,6,0]  R833      2.5732627511024475e-01
    z[1,6,0]  R834      3.3204281330108643e-01
    z[1,6,0]  R835      0.0271154772490263
    z[1,6,0]  R836      2.2598467767238617e-01
    z[1,6,0]  R837      -2.0111760124564171e-02
    z[1,6,0]  R838      4.0740448981523514e-02
    z[1,6,0]  R839      -9.2747874557971954e-02
    z[1,6,0]  R840      -2.0706218481063843e-01
    z[1,6,0]  R841      -1.4613938517868519e-02
    z[1,6,0]  R842      -2.3697561025619507e-01
    z[1,6,0]  R843      4.6550330519676208e-01
    z[1,6,0]  R844      3.2529163360595703e-01
    z[1,6,0]  R845      1.3015180826187134e-01
    z[1,6,0]  R846      2.8493487834930420e-01
    z[1,6,0]  R847      3.9687082171440125e-02
    z[1,6,0]  R848      -2.0952665805816650e-01
    z[1,6,0]  R849      -1.8916824460029602e-01
    z[1,6,0]  R850      -2.1669808030128479e-01
    z[1,6,0]  R851      -4.5104026794433594e-02
    z[1,6,0]  R852      3.3271864056587219e-02
    z[1,6,0]  R853      -3.1536030769348145e-01
    z[1,6,0]  R854      -2.4552899599075317e-01
    z[1,6,0]  R855      2.7699765563011169e-01
    z[1,6,0]  R856      2.2148096561431885e-01
    z[1,6,0]  R857      -9.6354849636554718e-02
    z[1,6,0]  R858      -9.6015587449073792e-02
    z[1,6,0]  R859      -2.1240970492362976e-01
    z[1,6,0]  R860      5.6615126132965088e-01
    z[1,6,0]  R861      -0.287582129240036
    z[1,6,0]  R862      3.9139175415039062e-01
    z[1,6,0]  R863      8.9847363531589508e-02
    z[1,6,0]  R864      -1.3517257571220398e-01
    z[1,6,0]  R865      6.2380012124776840e-02
    z[1,6,0]  R866      -3.1546853482723236e-02
    z[1,6,0]  R867      -3.2627135515213013e-01
    z[1,6,0]  R868      3.7415587902069092e-01
    z[1,6,0]  R869      -2.1480867266654968e-01
    z[1,6,0]  R870      -2.4702057242393494e-01
    z[1,6,0]  R871      0.0647042840719223
    z[1,6,0]  R872      -0.0897059440612793
    z[1,6,0]  R873      7.5556194782257080e-01
    z[1,6,0]  R874      -6.9648653268814087e-01
    z[1,6,0]  R875      4.2574423551559448e-01
    z[1,6,0]  R876      -8.8941919803619385e-01
    z[1,6,0]  R877      6.2374550104141235e-01
    z[1,6,0]  R878      -5.0331413745880127e-01
    z[1,6,0]  R879      2.9560112953186035e-01
    z[1,6,0]  R880      -1.8875746428966522e-01
    z[1,6,0]  R881      -3.9666953682899475e-01
    z[1,6,0]  R882      -1.5260013937950134e-01
    z[1,6,0]  R883      4.4463074207305908e-01
    z[1,6,0]  R884      1.3967847824096680e-01
    z[1,6,0]  R885      -5.1141440868377686e-01
    z[1,6,0]  R886      -3.6340034008026123e-01
    z[1,6,0]  R887      2.8061848878860474e-01
    z[1,6,0]  R888      1.1992813646793365e-01
    z[1,6,0]  R889      -1.1969466507434845e-01
    z[1,6,0]  R890      0.891903281211853
    z[1,6,0]  R891      -0.0440092533826828
    z[1,6,0]  R892      6.9294106960296631e-01
    z[1,6,0]  R893      6.0244774818420410e-01
    z[1,6,0]  R894      -8.1641167402267456e-02
    z[1,6,0]  R895      5.6040030717849731e-01
    z[1,6,0]  R896      4.0766561031341553e-01
    z[1,6,0]  R897      3.1279277754947543e-04
    z[1,6,0]  R898      4.6923488378524780e-01
    z[1,6,1]  R12       -1
    z[1,6,1]  R57       1
    z[1,6,1]  R807      -1
    z[1,6,1]  R808      1
    z[1,6,1]  R819      9.7079819440841675e-01
    z[1,6,1]  R820      6.4031040668487549e-01
    z[1,6,1]  R821      -0.138684943318367
    z[1,6,1]  R822      -1.3560040295124054e-01
    z[1,6,1]  R823      -5.1290322095155716e-02
    z[1,6,1]  R824      -0.0711161345243454
    z[1,6,1]  R825      1.1851778626441956e-01
    z[1,6,1]  R826      1.6843172907829285e-01
    z[1,6,1]  R827      9.2258296906948090e-02
    z[1,6,1]  R828      -1.0521542280912399e-01
    z[1,6,1]  R829      1.1808297038078308e-01
    z[1,6,1]  R830      -1.7224618792533875e-01
    z[1,6,1]  R831      -2.3573809862136841e-01
    z[1,6,1]  R832      -1.2717759609222412e-01
    z[1,6,1]  R833      -3.2212957739830017e-01
    z[1,6,1]  R834      -2.7359953522682190e-01
    z[1,6,1]  R835      -2.7333667874336243e-01
    z[1,6,1]  R836      -4.5951792597770691e-01
    z[1,6,1]  R837      -4.3252980709075928e-01
    z[1,6,1]  R838      -1.1579956859350204e-01
    z[1,6,1]  R839      -9.5399028062820435e-01
    z[1,6,1]  R840      -7.8108400106430054e-01
    z[1,6,1]  R841      -8.0746436119079590e-01
    z[1,6,1]  R842      -7.8210854530334473e-01
    z[1,6,1]  R843      -7.1410173177719116e-01
    z[1,6,1]  R844      -7.8637742996215820e-01
    z[1,6,1]  R845      -7.4421435594558716e-01
    z[1,6,1]  R846      -0.700564444065094
    z[1,6,1]  R847      -6.8744331598281860e-01
    z[1,6,1]  R848      -7.0553278923034668e-01
    z[1,6,1]  R849      5.8930778503417969e-01
    z[1,6,1]  R850      5.5380409955978394e-01
    z[1,6,1]  R851      -7.1062213182449341e-01
    z[1,6,1]  R852      7.0085096359252930e-01
    z[1,6,1]  R853      -6.4749735593795776e-01
    z[1,6,1]  R854      -5.9957367181777954e-01
    z[1,6,1]  R855      5.0419336557388306e-01
    z[1,6,1]  R856      0.506360650062561
    z[1,6,1]  R857      5.4126524925231934e-01
    z[1,6,1]  R858      -3.6219015717506409e-01
    z[1,6,1]  R859      -4.4346127659082413e-02
    z[1,6,1]  R860      -9.0379834175109863e-02
    z[1,6,1]  R861      -1.5228827297687531e-01
    z[1,6,1]  R862      -1.0052482783794403e-01
    z[1,6,1]  R863      -3.9079539477825165e-02
    z[1,6,1]  R864      -1.6333429515361786e-01
    z[1,6,1]  R865      -5.1454100757837296e-02
    z[1,6,1]  R866      -5.8109525591135025e-02
    z[1,6,1]  R867      9.2844374477863312e-02
    z[1,6,1]  R868      -8.1013187766075134e-02
    z[1,6,1]  R869      8.1758999824523926e-01
    z[1,6,1]  R870      -2.7423635125160217e-01
    z[1,6,1]  R871      9.2157393693923950e-01
    z[1,6,1]  R872      9.1725713014602661e-01
    z[1,6,1]  R873      -3.1591439247131348e-01
    z[1,6,1]  R874      -4.2140522599220276e-01
    z[1,6,1]  R875      -2.1396489441394806e-01
    z[1,6,1]  R876      -0.283568799495697
    z[1,6,1]  R877      3.6306354403495789e-01
    z[1,6,1]  R878      -5.2217030525207520e-01
    z[1,6,1]  R879      -7.4705088138580322e-01
    z[1,6,1]  R880      -6.0879707336425781e-01
    z[1,6,1]  R881      -6.1021369695663452e-01
    z[1,6,1]  R882      -5.2069664001464844e-01
    z[1,6,1]  R883      -5.0037395954132080e-01
    z[1,6,1]  R884      -5.1626527309417725e-01
    z[1,6,1]  R885      -4.8499128222465515e-01
    z[1,6,1]  R886      -4.2986959218978882e-01
    z[1,6,1]  R887      -4.6784445643424988e-01
    z[1,6,1]  R888      -5.2109575271606445e-01
    z[1,6,1]  R889      -6.4972156286239624e-01
    z[1,6,1]  R890      1.3706804811954498e-01
    z[1,6,1]  R891      -5.5932825803756714e-01
    z[1,6,1]  R892      4.6786937862634659e-02
    z[1,6,1]  R893      -2.8206637501716614e-01
    z[1,6,1]  R894      -0.646415650844574
    z[1,6,1]  R895      4.0782818198204041e-01
    z[1,6,1]  R896      1.4009904861450195e-01
    z[1,6,1]  R897      -2.5747969746589661e-01
    z[1,6,1]  R898      2.2282439470291138e-01
    z[1,6,2]  R13       -1
    z[1,6,2]  R58       1
    z[1,6,2]  R809      -1
    z[1,6,2]  R810      1
    z[1,6,2]  R819      -2.8458578512072563e-02
    z[1,6,2]  R820      9.8333068192005157e-02
    z[1,6,2]  R821      1.6744644939899445e-01
    z[1,6,2]  R822      -3.2325658202171326e-01
    z[1,6,2]  R823      9.7997933626174927e-02
    z[1,6,2]  R824      -5.4415683262050152e-03
    z[1,6,2]  R825      -0.257853627204895
    z[1,6,2]  R826      -3.0794674158096313e-01
    z[1,6,2]  R827      -2.4678991734981537e-01
    z[1,6,2]  R828      2.6114261150360107e-01
    z[1,6,2]  R829      0.527817964553833
    z[1,6,2]  R830      -4.0941774845123291e-01
    z[1,6,2]  R831      -4.9897426366806030e-01
    z[1,6,2]  R832      -7.5336736440658569e-01
    z[1,6,2]  R833      -4.1837871074676514e-01
    z[1,6,2]  R834      -6.3643521070480347e-01
    z[1,6,2]  R835      -3.6294567584991455e-01
    z[1,6,2]  R836      -6.7835921049118042e-01
    z[1,6,2]  R837      -2.8625974059104919e-01
    z[1,6,2]  R838      -0.603752076625824
    z[1,6,2]  R839      6.9415479898452759e-02
    z[1,6,2]  R840      -2.3059016466140747e-01
    z[1,6,2]  R841      3.4395694732666016e-01
    z[1,6,2]  R842      3.1662932038307190e-01
    z[1,6,2]  R843      -1.4114160835742950e-01
    z[1,6,2]  R844      -6.4147412776947021e-02
    z[1,6,2]  R845      -4.0544936060905457e-01
    z[1,6,2]  R846      7.3663949966430664e-02
    z[1,6,2]  R847      2.8105584904551506e-02
    z[1,6,2]  R848      4.0016758441925049e-01
    z[1,6,2]  R849      0.273367315530777
    z[1,6,2]  R850      7.4711114168167114e-01
    z[1,6,2]  R851      -4.7318261861801147e-01
    z[1,6,2]  R852      2.1705015003681183e-01
    z[1,6,2]  R853      3.5083245486021042e-02
    z[1,6,2]  R854      2.7878111600875854e-01
    z[1,6,2]  R855      2.4471163749694824e-01
    z[1,6,2]  R856      -1.4625380933284760e-01
    z[1,6,2]  R857      1.8711602687835693e-01
    z[1,6,2]  R858      -2.6298427581787109e-01
    z[1,6,2]  R859      -6.2255424261093140e-01
    z[1,6,2]  R860      -7.4332630634307861e-01
    z[1,6,2]  R861      -8.0464816093444824e-01
    z[1,6,2]  R862      -6.0049152374267578e-01
    z[1,6,2]  R863      -1.8468938767910004e-01
    z[1,6,2]  R864      -7.3881131410598755e-01
    z[1,6,2]  R865      -6.4745169878005981e-01
    z[1,6,2]  R866      -8.3255708217620850e-01
    z[1,6,2]  R867      -8.3497482538223267e-01
    z[1,6,2]  R868      -3.6337402462959290e-01
    z[1,6,2]  R869      3.0558711290359497e-01
    z[1,6,2]  R870      5.8320814371109009e-01
    z[1,6,2]  R871      2.4961875379085541e-01
    z[1,6,2]  R872      2.9769837856292725e-01
    z[1,6,2]  R873      2.1694932878017426e-01
    z[1,6,2]  R874      2.8463923931121826e-01
    z[1,6,2]  R875      2.0543260872364044e-01
    z[1,6,2]  R876      2.0874388515949249e-01
    z[1,6,2]  R877      0.381873220205307
    z[1,6,2]  R878      3.4576156735420227e-01
    z[1,6,2]  R879      1.0945479571819305e-01
    z[1,6,2]  R880      -3.2285865396261215e-02
    z[1,6,2]  R881      -5.2841058932244778e-03
    z[1,6,2]  R882      2.2360880672931671e-01
    z[1,6,2]  R883      3.1841287016868591e-01
    z[1,6,2]  R884      -3.3113136887550354e-01
    z[1,6,2]  R885      1.0439525544643402e-01
    z[1,6,2]  R886      2.3203656077384949e-01
    z[1,6,2]  R887      -1.0930939763784409e-01
    z[1,6,2]  R888      2.4682506918907166e-01
    z[1,6,2]  R889      -6.2499684095382690e-01
    z[1,6,2]  R890      -2.2313027083873749e-01
    z[1,6,2]  R891      -9.5440290868282318e-02
    z[1,6,2]  R892      -6.9622255861759186e-02
    z[1,6,2]  R893      -1.8771840631961823e-01
    z[1,6,2]  R894      -2.8977859020233154e-01
    z[1,6,2]  R895      0.0358751118183136
    z[1,6,2]  R896      -1.8994650244712830e-01
    z[1,6,2]  R897      -4.9565258622169495e-01
    z[1,6,2]  R898      1.5451537072658539e-01
    z[1,6,3]  R14       -1
    z[1,6,3]  R59       1
    z[1,6,3]  R811      -1
    z[1,6,3]  R812      1
    z[1,6,3]  R819      -1.0652960836887360e-01
    z[1,6,3]  R820      -3.7224423885345459e-01
    z[1,6,3]  R821      5.8253329992294312e-01
    z[1,6,3]  R822      4.3245518207550049e-01
    z[1,6,3]  R823      4.9656990170478821e-01
    z[1,6,3]  R824      5.7550114393234253e-01
    z[1,6,3]  R825      5.2948659658432007e-01
    z[1,6,3]  R826      6.5426230430603027e-01
    z[1,6,3]  R827      9.0064838528633118e-02
    z[1,6,3]  R828      1.2413965165615082e-01
    z[1,6,3]  R829      7.1115463972091675e-02
    z[1,6,3]  R830      6.2369710206985474e-01
    z[1,6,3]  R831      4.5309442281723022e-01
    z[1,6,3]  R832      3.4645467996597290e-01
    z[1,6,3]  R833      5.4036104679107666e-01
    z[1,6,3]  R834      2.8364226222038269e-01
    z[1,6,3]  R835      7.6607018709182739e-01
    z[1,6,3]  R836      0.468136727809906
    z[1,6,3]  R837      2.8573292493820190e-01
    z[1,6,3]  R838      1.3243648409843445e-01
    z[1,6,3]  R839      1.1205623298883438e-01
    z[1,6,3]  R840      3.3471721410751343e-01
    z[1,6,3]  R841      4.3947091698646545e-01
    z[1,6,3]  R842      3.9231842756271362e-01
    z[1,6,3]  R843      3.9689761400222778e-01
    z[1,6,3]  R844      -7.3697227053344250e-03
    z[1,6,3]  R845      -1.6436351463198662e-02
    z[1,6,3]  R846      -4.0541672706604004e-01
    z[1,6,3]  R847      -6.1854767799377441e-01
    z[1,6,3]  R848      -3.1052476167678833e-01
    z[1,6,3]  R849      -4.6811640262603760e-01
    z[1,6,3]  R850      -2.9047888517379761e-01
    z[1,6,3]  R851      -4.2592954635620117e-01
    z[1,6,3]  R852      -5.0239515304565430e-01
    z[1,6,3]  R853      1.1542630381882191e-02
    z[1,6,3]  R854      -3.5988822579383850e-01
    z[1,6,3]  R855      -5.7506734132766724e-01
    z[1,6,3]  R856      -6.6924935579299927e-01
    z[1,6,3]  R857      -3.9783358573913574e-01
    z[1,6,3]  R858      4.7208401560783386e-01
    z[1,6,3]  R859      -1.8421080708503723e-01
    z[1,6,3]  R860      -2.9413759708404541e-02
    z[1,6,3]  R861      1.6060025990009308e-01
    z[1,6,3]  R862      1.5337137877941132e-01
    z[1,6,3]  R863      3.9470937848091125e-01
    z[1,6,3]  R864      1.2312074750661850e-01
    z[1,6,3]  R865      -0.366982102394104
    z[1,6,3]  R866      1.2864798307418823e-01
    z[1,6,3]  R867      -8.5663378238677979e-02
    z[1,6,3]  R868      -3.0126622319221497e-01
    z[1,6,3]  R869      3.9039561152458191e-01
    z[1,6,3]  R870      -4.7683459520339966e-01
    z[1,6,3]  R871      -1.6152353584766388e-01
    z[1,6,3]  R872      -2.0118415355682373e-01
    z[1,6,3]  R873      3.3191543817520142e-01
    z[1,6,3]  R874      4.8919060826301575e-01
    z[1,6,3]  R875      -6.1220663785934448e-01
    z[1,6,3]  R876      1.7509926855564117e-01
    z[1,6,3]  R877      -4.7625014185905457e-01
    z[1,6,3]  R878      4.8647928237915039e-01
    z[1,6,3]  R879      -2.3330879211425781e-01
    z[1,6,3]  R880      -6.9764018058776855e-02
    z[1,6,3]  R881      2.6782515645027161e-01
    z[1,6,3]  R882      -0.405845582485199
    z[1,6,3]  R883      6.4888454973697662e-02
    z[1,6,3]  R884      -3.8919255137443542e-01
    z[1,6,3]  R885      1.6290649771690369e-01
    z[1,6,3]  R886      -3.8584843277931213e-01
    z[1,6,3]  R887      8.2914769649505615e-02
    z[1,6,3]  R888      3.1777891516685486e-01
    z[1,6,3]  R889      -2.1474552154541016e-01
    z[1,6,3]  R890      1.8357586860656738e-01
    z[1,6,3]  R891      6.8477582931518555e-01
    z[1,6,3]  R892      1.3806837797164917e-01
    z[1,6,3]  R893      -6.0245178639888763e-02
    z[1,6,3]  R894      2.5885561108589172e-01
    z[1,6,3]  R895      -4.7876462340354919e-01
    z[1,6,3]  R896      -0.363491028547287
    z[1,6,3]  R897      5.1065343618392944e-01
    z[1,6,3]  R898      -3.0907431617379189e-02
    z[1,6,4]  R15       -1
    z[1,6,4]  R60       1
    z[1,6,4]  R813      -1
    z[1,6,4]  R814      1
    z[1,6,4]  R819      -4.2701106518507004e-02
    z[1,6,4]  R820      -1.0903651267290115e-01
    z[1,6,4]  R821      -3.8109406828880310e-02
    z[1,6,4]  R822      -2.6365658640861511e-01
    z[1,6,4]  R823      -1.0086496174335480e-01
    z[1,6,4]  R824      -4.2758235335350037e-01
    z[1,6,4]  R825      -0.0987108051776886
    z[1,6,4]  R826      -1.8443804234266281e-02
    z[1,6,4]  R827      -8.4633342921733856e-02
    z[1,6,4]  R828      -1.1293911933898926e-01
    z[1,6,4]  R829      0.827197790145874
    z[1,6,4]  R830      -6.3351714611053467e-01
    z[1,6,4]  R831      -6.4652818441390991e-01
    z[1,6,4]  R832      -4.9971318244934082e-01
    z[1,6,4]  R833      -4.7033041715621948e-01
    z[1,6,4]  R834      -3.9395216107368469e-01
    z[1,6,4]  R835      -3.5066959261894226e-01
    z[1,6,4]  R836      -1.9051505625247955e-01
    z[1,6,4]  R837      -4.0630677342414856e-01
    z[1,6,4]  R838      -7.6303946971893311e-01
    z[1,6,4]  R839      3.2096426934003830e-02
    z[1,6,4]  R840      -1.1262485384941101e-01
    z[1,6,4]  R841      -1.1069152504205704e-02
    z[1,6,4]  R842      -8.4059886634349823e-02
    z[1,6,4]  R843      -0.0471460185945034
    z[1,6,4]  R844      -1.4118281193077564e-02
    z[1,6,4]  R845      4.1445949673652649e-01
    z[1,6,4]  R846      -5.0145995616912842e-01
    z[1,6,4]  R847      3.1634697318077087e-01
    z[1,6,4]  R848      3.2800965011119843e-02
    z[1,6,4]  R849      3.9694914221763611e-01
    z[1,6,4]  R850      -1.3578631915152073e-02
    z[1,6,4]  R851      -2.8430971503257751e-01
    z[1,6,4]  R852      -3.9041060209274292e-01
    z[1,6,4]  R853      4.7830536961555481e-01
    z[1,6,4]  R854      -2.0111978054046631e-01
    z[1,6,4]  R855      2.9851067066192627e-01
    z[1,6,4]  R856      -2.3639839142560959e-02
    z[1,6,4]  R857      -1.8404923379421234e-01
    z[1,6,4]  R858      -0.517731785774231
    z[1,6,4]  R859      -6.3743394613265991e-01
    z[1,6,4]  R860      -1.3657073676586151e-01
    z[1,6,4]  R861      -2.7995908260345459e-01
    z[1,6,4]  R862      -5.8870977163314819e-01
    z[1,6,4]  R863      -8.1852513551712036e-01
    z[1,6,4]  R864      8.7458200752735138e-02
    z[1,6,4]  R865      -4.6370047330856323e-01
    z[1,6,4]  R866      1.2290842831134796e-01
    z[1,6,4]  R867      -6.2325045466423035e-02
    z[1,6,4]  R868      -7.8452903032302856e-01
    z[1,6,4]  R869      8.9119784533977509e-02
    z[1,6,4]  R870      1.4148251712322235e-01
    z[1,6,4]  R871      1.2777429819107056e-01
    z[1,6,4]  R872      1.1681786179542542e-01
    z[1,6,4]  R873      3.0304929614067078e-01
    z[1,6,4]  R874      -6.9315090775489807e-02
    z[1,6,4]  R875      4.2483016848564148e-01
    z[1,6,4]  R876      1.8962581455707550e-01
    z[1,6,4]  R877      1.5284567140042782e-02
    z[1,6,4]  R878      2.2329214215278625e-01
    z[1,6,4]  R879      -3.4885589033365250e-02
    z[1,6,4]  R880      -5.6437385082244873e-01
    z[1,6,4]  R881      -3.9155066013336182e-01
    z[1,6,4]  R882      6.4252310991287231e-01
    z[1,6,4]  R883      -1.9448530673980713e-01
    z[1,6,4]  R884      -5.9565279632806778e-02
    z[1,6,4]  R885      4.3613232672214508e-02
    z[1,6,4]  R886      -1.6706696152687073e-01
    z[1,6,4]  R887      1.5945152938365936e-01
    z[1,6,4]  R888      -0.700086772441864
    z[1,6,4]  R889      -8.6237683892250061e-02
    z[1,6,4]  R890      2.8281274437904358e-01
    z[1,6,4]  R891      -1.9821323454380035e-01
    z[1,6,4]  R892      -1.6417573392391205e-01
    z[1,6,4]  R893      1.9250491261482239e-01
    z[1,6,4]  R894      5.5724793672561646e-01
    z[1,6,4]  R895      2.7393159270286560e-01
    z[1,6,4]  R896      1.7277634143829346e-01
    z[1,6,4]  R897      0.624572217464447
    z[1,6,4]  R898      0.0839446485042572
    z[1,6,5]  R16       -1
    z[1,6,5]  R61       1
    z[1,6,5]  R815      -1
    z[1,6,5]  R816      1
    z[1,6,5]  R819      -1.3769541680812836e-01
    z[1,6,5]  R820      -0.563877522945404
    z[1,6,5]  R821      8.5845552384853363e-03
    z[1,6,5]  R822      0.00700989319011569
    z[1,6,5]  R823      -5.6152928620576859e-02
    z[1,6,5]  R824      9.8681680858135223e-02
    z[1,6,5]  R825      -3.2476380467414856e-01
    z[1,6,5]  R826      7.6823040843009949e-02
    z[1,6,5]  R827      3.4556340426206589e-02
    z[1,6,5]  R828      -2.9272469878196716e-01
    z[1,6,5]  R829      -1.5474167652428150e-02
    z[1,6,5]  R830      1.0599581152200699e-01
    z[1,6,5]  R831      -2.5980386137962341e-01
    z[1,6,5]  R832      1.1180879175662994e-01
    z[1,6,5]  R833      0.0648990347981453
    z[1,6,5]  R834      2.8234541416168213e-01
    z[1,6,5]  R835      2.7899768948554993e-01
    z[1,6,5]  R836      1.2590293586254120e-01
    z[1,6,5]  R837      6.7350721359252930e-01
    z[1,6,5]  R838      9.8208189010620117e-02
    z[1,6,5]  R839      2.0516207814216614e-01
    z[1,6,5]  R840      -0.364769846200943
    z[1,6,5]  R841      8.3711095154285431e-02
    z[1,6,5]  R842      -2.5648900866508484e-01
    z[1,6,5]  R843      -2.9499495029449463e-01
    z[1,6,5]  R844      -1.0593015700578690e-01
    z[1,6,5]  R845      -2.6589006185531616e-01
    z[1,6,5]  R846      -7.9941317439079285e-02
    z[1,6,5]  R847      2.0427992939949036e-01
    z[1,6,5]  R848      1.9457958638668060e-01
    z[1,6,5]  R849      -7.8477680683135986e-02
    z[1,6,5]  R850      -1.4952444471418858e-02
    z[1,6,5]  R851      -7.9793877899646759e-02
    z[1,6,5]  R852      -0.0723300352692604
    z[1,6,5]  R853      2.5796961784362793e-01
    z[1,6,5]  R854      -5.6732857227325439e-01
    z[1,6,5]  R855      3.7883457541465759e-01
    z[1,6,5]  R856      4.5789572596549988e-01
    z[1,6,5]  R857      6.8522137403488159e-01
    z[1,6,5]  R858      5.4043656587600708e-01
    z[1,6,5]  R859      2.0146530866622925e-01
    z[1,6,5]  R860      1.3990907371044159e-01
    z[1,6,5]  R861      3.3354374766349792e-01
    z[1,6,5]  R862      3.0304759740829468e-01
    z[1,6,5]  R863      3.3876052498817444e-01
    z[1,6,5]  R864      3.4586733579635620e-01
    z[1,6,5]  R865      2.0835934579372406e-01
    z[1,6,5]  R866      2.6599800586700439e-01
    z[1,6,5]  R867      4.1952362656593323e-01
    z[1,6,5]  R868      4.9756024032831192e-02
    z[1,6,5]  R869      -1.2804748117923737e-01
    z[1,6,5]  R870      5.2556627988815308e-01
    z[1,6,5]  R871      -1.1099065840244293e-01
    z[1,6,5]  R872      -5.7539731264114380e-02
    z[1,6,5]  R873      -2.8323435783386230e-01
    z[1,6,5]  R874      -1.1019649356603622e-01
    z[1,6,5]  R875      3.2817018032073975e-01
    z[1,6,5]  R876      -1.2396162748336792e-01
    z[1,6,5]  R877      -1.2915004789829254e-01
    z[1,6,5]  R878      -2.5686267018318176e-01
    z[1,6,5]  R879      -3.6452582478523254e-01
    z[1,6,5]  R880      5.6535284966230392e-02
    z[1,6,5]  R881      4.9025887250900269e-01
    z[1,6,5]  R882      -2.7779844403266907e-01
    z[1,6,5]  R883      6.3344120979309082e-01
    z[1,6,5]  R884      6.5751016139984131e-01
    z[1,6,5]  R885      -6.4349383115768433e-02
    z[1,6,5]  R886      -1.0267642885446548e-01
    z[1,6,5]  R887      7.5395655632019043e-01
    z[1,6,5]  R888      -2.2027517855167389e-01
    z[1,6,5]  R889      -1.9749562442302704e-01
    z[1,6,5]  R890      1.4104568958282471e-01
    z[1,6,5]  R891      -8.9955426752567291e-02
    z[1,6,5]  R892      1.8768961727619171e-01
    z[1,6,5]  R893      -4.1778244078159332e-02
    z[1,6,5]  R894      -2.9994806647300720e-01
    z[1,6,5]  R895      -1.2022332102060318e-01
    z[1,6,5]  R896      -1.8738360702991486e-01
    z[1,6,5]  R897      1.8032878637313843e-01
    z[1,6,5]  R898      -1.3821698725223541e-01
    z[1,6,6]  R17       -1
    z[1,6,6]  R62       1
    z[1,6,6]  R817      -1
    z[1,6,6]  R818      1
    z[1,6,6]  R819      -5.5232111364603043e-02
    z[1,6,6]  R820      -2.7220547199249268e-01
    z[1,6,6]  R821      1.6095350682735443e-01
    z[1,6,6]  R822      -3.3334780484437943e-02
    z[1,6,6]  R823      -3.8633573055267334e-01
    z[1,6,6]  R824      -4.3321792036294937e-02
    z[1,6,6]  R825      2.1497417986392975e-01
    z[1,6,6]  R826      1.2258848547935486e-01
    z[1,6,6]  R827      -1.7597796022891998e-01
    z[1,6,6]  R828      -1.2156955152750015e-01
    z[1,6,6]  R829      -0.0600656233727932
    z[1,6,6]  R830      -1.8227970227599144e-02
    z[1,6,6]  R831      5.8530010282993317e-02
    z[1,6,6]  R832      -1.7670390009880066e-01
    z[1,6,6]  R833      3.7089386582374573e-01
    z[1,6,6]  R834      3.0736133456230164e-01
    z[1,6,6]  R835      7.1762762963771820e-02
    z[1,6,6]  R836      7.9394921660423279e-02
    z[1,6,6]  R837      1.7386290431022644e-01
    z[1,6,6]  R838      1.0488359630107880e-01
    z[1,6,6]  R839      1.4423468708992004e-01
    z[1,6,6]  R840      -1.8995878100395203e-01
    z[1,6,6]  R841      -1.7092873156070709e-01
    z[1,6,6]  R842      7.1612037718296051e-02
    z[1,6,6]  R843      -8.1680983304977417e-02
    z[1,6,6]  R844      5.1010406017303467e-01
    z[1,6,6]  R845      -1.4856582880020142e-01
    z[1,6,6]  R846      -1.9486727192997932e-02
    z[1,6,6]  R847      2.5488814339041710e-02
    z[1,6,6]  R848      -0.40351602435112
    z[1,6,6]  R849      -3.9917615056037903e-01
    z[1,6,6]  R850      5.8154135942459106e-02
    z[1,6,6]  R851      2.1559296175837517e-02
    z[1,6,6]  R852      2.2480469942092896e-01
    z[1,6,6]  R853      -4.2965874075889587e-01
    z[1,6,6]  R854      1.0333219915628433e-01
    z[1,6,6]  R855      2.1412852406501770e-01
    z[1,6,6]  R856      1.2260851263999939e-01
    z[1,6,6]  R857      3.2578937709331512e-02
    z[1,6,6]  R858      -8.6356140673160553e-02
    z[1,6,6]  R859      2.9068502783775330e-01
    z[1,6,6]  R860      2.8227454423904419e-01
    z[1,6,6]  R861      1.7670619487762451e-01
    z[1,6,6]  R862      -1.1906898766756058e-01
    z[1,6,6]  R863      -1.2550881505012512e-01
    z[1,6,6]  R864      -5.1650381088256836e-01
    z[1,6,6]  R865      -4.2562881112098694e-01
    z[1,6,6]  R866      0.447286456823349
    z[1,6,6]  R867      -2.2831052541732788e-02
    z[1,6,6]  R868      -1.1260929703712463e-01
    z[1,6,6]  R869      1.2358459830284119e-01
    z[1,6,6]  R870      0.00592637388035655
    z[1,6,6]  R871      -1.7166891694068909e-01
    z[1,6,6]  R872      6.7347057163715363e-02
    z[1,6,6]  R873      5.3730695508420467e-03
    z[1,6,6]  R874      -7.0308116264641285e-03
    z[1,6,6]  R875      -2.6035559177398682e-01
    z[1,6,6]  R876      -5.4442346096038818e-02
    z[1,6,6]  R877      -2.9928541183471680e-01
    z[1,6,6]  R878      -4.4294662773609161e-02
    z[1,6,6]  R879      3.9246085286140442e-01
    z[1,6,6]  R880      5.1586157083511353e-01
    z[1,6,6]  R881      6.9776542484760284e-02
    z[1,6,6]  R882      2.9474783688783646e-02
    z[1,6,6]  R883      -8.5204273462295532e-02
    z[1,6,6]  R884      1.3028287887573242e-01
    z[1,6,6]  R885      -6.7805522680282593e-01
    z[1,6,6]  R886      -6.6481471061706543e-01
    z[1,6,6]  R887      0.299459844827652
    z[1,6,6]  R888      -1.1630912870168686e-01
    z[1,6,6]  R889      -2.8347286581993103e-01
    z[1,6,6]  R890      -4.8547599464654922e-02
    z[1,6,6]  R891      3.9975982904434204e-01
    z[1,6,6]  R892      -6.5692657232284546e-01
    z[1,6,6]  R893      -6.9269323348999023e-01
    z[1,6,6]  R894      1.5495055913925171e-01
    z[1,6,6]  R895      4.4680300354957581e-01
    z[1,6,6]  R896      7.6224094629287720e-01
    z[1,6,6]  R897      -6.8241044878959656e-02
    z[1,6,6]  R898      8.2412803173065186e-01
    z[6,1,0]  R11       1
    z[6,1,0]  R56       -1
    z[6,1,0]  R899      -1
    z[6,1,0]  R900      1
    z[6,1,0]  R913      -2.1240970492362976e-01
    z[6,1,0]  R914      5.6615126132965088e-01
    z[6,1,0]  R915      -0.287582129240036
    z[6,1,0]  R916      3.9139175415039062e-01
    z[6,1,0]  R917      8.9847363531589508e-02
    z[6,1,0]  R918      -1.3517257571220398e-01
    z[6,1,0]  R919      6.2380012124776840e-02
    z[6,1,0]  R920      -3.1546853482723236e-02
    z[6,1,0]  R921      -3.2627135515213013e-01
    z[6,1,0]  R922      3.7415587902069092e-01
    z[6,1,0]  R923      -2.1480867266654968e-01
    z[6,1,0]  R924      -2.4702057242393494e-01
    z[6,1,0]  R925      0.0647042840719223
    z[6,1,0]  R926      -0.0897059440612793
    z[6,1,0]  R927      7.5556194782257080e-01
    z[6,1,0]  R928      -6.9648653268814087e-01
    z[6,1,0]  R929      4.2574423551559448e-01
    z[6,1,0]  R930      -8.8941919803619385e-01
    z[6,1,0]  R931      6.2374550104141235e-01
    z[6,1,0]  R932      -5.0331413745880127e-01
    z[6,1,0]  R933      2.9560112953186035e-01
    z[6,1,0]  R934      -1.8875746428966522e-01
    z[6,1,0]  R935      -3.9666953682899475e-01
    z[6,1,0]  R936      -1.5260013937950134e-01
    z[6,1,0]  R937      4.4463074207305908e-01
    z[6,1,0]  R938      1.3967847824096680e-01
    z[6,1,0]  R939      -5.1141440868377686e-01
    z[6,1,0]  R940      -3.6340034008026123e-01
    z[6,1,0]  R941      2.8061848878860474e-01
    z[6,1,0]  R942      1.1992813646793365e-01
    z[6,1,0]  R943      -1.1969466507434845e-01
    z[6,1,0]  R944      0.891903281211853
    z[6,1,0]  R945      -0.0440092533826828
    z[6,1,0]  R946      6.9294106960296631e-01
    z[6,1,0]  R947      6.0244774818420410e-01
    z[6,1,0]  R948      -8.1641167402267456e-02
    z[6,1,0]  R949      5.6040030717849731e-01
    z[6,1,0]  R950      4.0766561031341553e-01
    z[6,1,0]  R951      3.1279277754947543e-04
    z[6,1,0]  R952      4.6923488378524780e-01
    z[6,1,0]  R953      1.4682796597480774e-01
    z[6,1,0]  R954      -1.9448599219322205e-01
    z[6,1,0]  R955      -7.6547443866729736e-01
    z[6,1,0]  R956      -7.8703552484512329e-01
    z[6,1,0]  R957      -7.6065880060195923e-01
    z[6,1,0]  R958      -6.8503272533416748e-01
    z[6,1,0]  R959      -6.9114369153976440e-01
    z[6,1,0]  R960      -6.5381234884262085e-01
    z[6,1,0]  R961      -9.3975865840911865e-01
    z[6,1,0]  R962      -8.9000082015991211e-01
    z[6,1,0]  R963      1.1959818750619888e-01
    z[6,1,0]  R964      -2.8266675770282745e-02
    z[6,1,0]  R965      -3.5147402435541153e-02
    z[6,1,0]  R966      -5.2857872098684311e-02
    z[6,1,0]  R967      2.5732627511024475e-01
    z[6,1,0]  R968      3.3204281330108643e-01
    z[6,1,0]  R969      0.0271154772490263
    z[6,1,0]  R970      2.2598467767238617e-01
    z[6,1,0]  R971      -2.0111760124564171e-02
    z[6,1,0]  R972      4.0740448981523514e-02
    z[6,1,0]  R973      -9.2747874557971954e-02
    z[6,1,0]  R974      -2.0706218481063843e-01
    z[6,1,0]  R975      -1.4613938517868519e-02
    z[6,1,0]  R976      -2.3697561025619507e-01
    z[6,1,0]  R977      4.6550330519676208e-01
    z[6,1,0]  R978      3.2529163360595703e-01
    z[6,1,0]  R979      1.3015180826187134e-01
    z[6,1,0]  R980      2.8493487834930420e-01
    z[6,1,0]  R981      3.9687082171440125e-02
    z[6,1,0]  R982      -2.0952665805816650e-01
    z[6,1,0]  R983      -1.8916824460029602e-01
    z[6,1,0]  R984      -2.1669808030128479e-01
    z[6,1,0]  R985      -4.5104026794433594e-02
    z[6,1,0]  R986      3.3271864056587219e-02
    z[6,1,0]  R987      -3.1536030769348145e-01
    z[6,1,0]  R988      -2.4552899599075317e-01
    z[6,1,0]  R989      2.7699765563011169e-01
    z[6,1,0]  R990      2.2148096561431885e-01
    z[6,1,0]  R991      -9.6354849636554718e-02
    z[6,1,0]  R992      -9.6015587449073792e-02
    z[6,1,1]  R12       1
    z[6,1,1]  R57       -1
    z[6,1,1]  R901      -1
    z[6,1,1]  R902      1
    z[6,1,1]  R913      -4.4346127659082413e-02
    z[6,1,1]  R914      -9.0379834175109863e-02
    z[6,1,1]  R915      -1.5228827297687531e-01
    z[6,1,1]  R916      -1.0052482783794403e-01
    z[6,1,1]  R917      -3.9079539477825165e-02
    z[6,1,1]  R918      -1.6333429515361786e-01
    z[6,1,1]  R919      -5.1454100757837296e-02
    z[6,1,1]  R920      -5.8109525591135025e-02
    z[6,1,1]  R921      9.2844374477863312e-02
    z[6,1,1]  R922      -8.1013187766075134e-02
    z[6,1,1]  R923      8.1758999824523926e-01
    z[6,1,1]  R924      -2.7423635125160217e-01
    z[6,1,1]  R925      9.2157393693923950e-01
    z[6,1,1]  R926      9.1725713014602661e-01
    z[6,1,1]  R927      -3.1591439247131348e-01
    z[6,1,1]  R928      -4.2140522599220276e-01
    z[6,1,1]  R929      -2.1396489441394806e-01
    z[6,1,1]  R930      -0.283568799495697
    z[6,1,1]  R931      3.6306354403495789e-01
    z[6,1,1]  R932      -5.2217030525207520e-01
    z[6,1,1]  R933      -7.4705088138580322e-01
    z[6,1,1]  R934      -6.0879707336425781e-01
    z[6,1,1]  R935      -6.1021369695663452e-01
    z[6,1,1]  R936      -5.2069664001464844e-01
    z[6,1,1]  R937      -5.0037395954132080e-01
    z[6,1,1]  R938      -5.1626527309417725e-01
    z[6,1,1]  R939      -4.8499128222465515e-01
    z[6,1,1]  R940      -4.2986959218978882e-01
    z[6,1,1]  R941      -4.6784445643424988e-01
    z[6,1,1]  R942      -5.2109575271606445e-01
    z[6,1,1]  R943      -6.4972156286239624e-01
    z[6,1,1]  R944      1.3706804811954498e-01
    z[6,1,1]  R945      -5.5932825803756714e-01
    z[6,1,1]  R946      4.6786937862634659e-02
    z[6,1,1]  R947      -2.8206637501716614e-01
    z[6,1,1]  R948      -0.646415650844574
    z[6,1,1]  R949      4.0782818198204041e-01
    z[6,1,1]  R950      1.4009904861450195e-01
    z[6,1,1]  R951      -2.5747969746589661e-01
    z[6,1,1]  R952      2.2282439470291138e-01
    z[6,1,1]  R953      9.7079819440841675e-01
    z[6,1,1]  R954      6.4031040668487549e-01
    z[6,1,1]  R955      -0.138684943318367
    z[6,1,1]  R956      -1.3560040295124054e-01
    z[6,1,1]  R957      -5.1290322095155716e-02
    z[6,1,1]  R958      -0.0711161345243454
    z[6,1,1]  R959      1.1851778626441956e-01
    z[6,1,1]  R960      1.6843172907829285e-01
    z[6,1,1]  R961      9.2258296906948090e-02
    z[6,1,1]  R962      -1.0521542280912399e-01
    z[6,1,1]  R963      1.1808297038078308e-01
    z[6,1,1]  R964      -1.7224618792533875e-01
    z[6,1,1]  R965      -2.3573809862136841e-01
    z[6,1,1]  R966      -1.2717759609222412e-01
    z[6,1,1]  R967      -3.2212957739830017e-01
    z[6,1,1]  R968      -2.7359953522682190e-01
    z[6,1,1]  R969      -2.7333667874336243e-01
    z[6,1,1]  R970      -4.5951792597770691e-01
    z[6,1,1]  R971      -4.3252980709075928e-01
    z[6,1,1]  R972      -1.1579956859350204e-01
    z[6,1,1]  R973      -9.5399028062820435e-01
    z[6,1,1]  R974      -7.8108400106430054e-01
    z[6,1,1]  R975      -8.0746436119079590e-01
    z[6,1,1]  R976      -7.8210854530334473e-01
    z[6,1,1]  R977      -7.1410173177719116e-01
    z[6,1,1]  R978      -7.8637742996215820e-01
    z[6,1,1]  R979      -7.4421435594558716e-01
    z[6,1,1]  R980      -0.700564444065094
    z[6,1,1]  R981      -6.8744331598281860e-01
    z[6,1,1]  R982      -7.0553278923034668e-01
    z[6,1,1]  R983      5.8930778503417969e-01
    z[6,1,1]  R984      5.5380409955978394e-01
    z[6,1,1]  R985      -7.1062213182449341e-01
    z[6,1,1]  R986      7.0085096359252930e-01
    z[6,1,1]  R987      -6.4749735593795776e-01
    z[6,1,1]  R988      -5.9957367181777954e-01
    z[6,1,1]  R989      5.0419336557388306e-01
    z[6,1,1]  R990      0.506360650062561
    z[6,1,1]  R991      5.4126524925231934e-01
    z[6,1,1]  R992      -3.6219015717506409e-01
    z[6,1,2]  R13       1
    z[6,1,2]  R58       -1
    z[6,1,2]  R903      -1
    z[6,1,2]  R904      1
    z[6,1,2]  R913      -6.2255424261093140e-01
    z[6,1,2]  R914      -7.4332630634307861e-01
    z[6,1,2]  R915      -8.0464816093444824e-01
    z[6,1,2]  R916      -6.0049152374267578e-01
    z[6,1,2]  R917      -1.8468938767910004e-01
    z[6,1,2]  R918      -7.3881131410598755e-01
    z[6,1,2]  R919      -6.4745169878005981e-01
    z[6,1,2]  R920      -8.3255708217620850e-01
    z[6,1,2]  R921      -8.3497482538223267e-01
    z[6,1,2]  R922      -3.6337402462959290e-01
    z[6,1,2]  R923      3.0558711290359497e-01
    z[6,1,2]  R924      5.8320814371109009e-01
    z[6,1,2]  R925      2.4961875379085541e-01
    z[6,1,2]  R926      2.9769837856292725e-01
    z[6,1,2]  R927      2.1694932878017426e-01
    z[6,1,2]  R928      2.8463923931121826e-01
    z[6,1,2]  R929      2.0543260872364044e-01
    z[6,1,2]  R930      2.0874388515949249e-01
    z[6,1,2]  R931      0.381873220205307
    z[6,1,2]  R932      3.4576156735420227e-01
    z[6,1,2]  R933      1.0945479571819305e-01
    z[6,1,2]  R934      -3.2285865396261215e-02
    z[6,1,2]  R935      -5.2841058932244778e-03
    z[6,1,2]  R936      2.2360880672931671e-01
    z[6,1,2]  R937      3.1841287016868591e-01
    z[6,1,2]  R938      -3.3113136887550354e-01
    z[6,1,2]  R939      1.0439525544643402e-01
    z[6,1,2]  R940      2.3203656077384949e-01
    z[6,1,2]  R941      -1.0930939763784409e-01
    z[6,1,2]  R942      2.4682506918907166e-01
    z[6,1,2]  R943      -6.2499684095382690e-01
    z[6,1,2]  R944      -2.2313027083873749e-01
    z[6,1,2]  R945      -9.5440290868282318e-02
    z[6,1,2]  R946      -6.9622255861759186e-02
    z[6,1,2]  R947      -1.8771840631961823e-01
    z[6,1,2]  R948      -2.8977859020233154e-01
    z[6,1,2]  R949      0.0358751118183136
    z[6,1,2]  R950      -1.8994650244712830e-01
    z[6,1,2]  R951      -4.9565258622169495e-01
    z[6,1,2]  R952      1.5451537072658539e-01
    z[6,1,2]  R953      -2.8458578512072563e-02
    z[6,1,2]  R954      9.8333068192005157e-02
    z[6,1,2]  R955      1.6744644939899445e-01
    z[6,1,2]  R956      -3.2325658202171326e-01
    z[6,1,2]  R957      9.7997933626174927e-02
    z[6,1,2]  R958      -5.4415683262050152e-03
    z[6,1,2]  R959      -0.257853627204895
    z[6,1,2]  R960      -3.0794674158096313e-01
    z[6,1,2]  R961      -2.4678991734981537e-01
    z[6,1,2]  R962      2.6114261150360107e-01
    z[6,1,2]  R963      0.527817964553833
    z[6,1,2]  R964      -4.0941774845123291e-01
    z[6,1,2]  R965      -4.9897426366806030e-01
    z[6,1,2]  R966      -7.5336736440658569e-01
    z[6,1,2]  R967      -4.1837871074676514e-01
    z[6,1,2]  R968      -6.3643521070480347e-01
    z[6,1,2]  R969      -3.6294567584991455e-01
    z[6,1,2]  R970      -6.7835921049118042e-01
    z[6,1,2]  R971      -2.8625974059104919e-01
    z[6,1,2]  R972      -0.603752076625824
    z[6,1,2]  R973      6.9415479898452759e-02
    z[6,1,2]  R974      -2.3059016466140747e-01
    z[6,1,2]  R975      3.4395694732666016e-01
    z[6,1,2]  R976      3.1662932038307190e-01
    z[6,1,2]  R977      -1.4114160835742950e-01
    z[6,1,2]  R978      -6.4147412776947021e-02
    z[6,1,2]  R979      -4.0544936060905457e-01
    z[6,1,2]  R980      7.3663949966430664e-02
    z[6,1,2]  R981      2.8105584904551506e-02
    z[6,1,2]  R982      4.0016758441925049e-01
    z[6,1,2]  R983      0.273367315530777
    z[6,1,2]  R984      7.4711114168167114e-01
    z[6,1,2]  R985      -4.7318261861801147e-01
    z[6,1,2]  R986      2.1705015003681183e-01
    z[6,1,2]  R987      3.5083245486021042e-02
    z[6,1,2]  R988      2.7878111600875854e-01
    z[6,1,2]  R989      2.4471163749694824e-01
    z[6,1,2]  R990      -1.4625380933284760e-01
    z[6,1,2]  R991      1.8711602687835693e-01
    z[6,1,2]  R992      -2.6298427581787109e-01
    z[6,1,3]  R14       1
    z[6,1,3]  R59       -1
    z[6,1,3]  R905      -1
    z[6,1,3]  R906      1
    z[6,1,3]  R913      -1.8421080708503723e-01
    z[6,1,3]  R914      -2.9413759708404541e-02
    z[6,1,3]  R915      1.6060025990009308e-01
    z[6,1,3]  R916      1.5337137877941132e-01
    z[6,1,3]  R917      3.9470937848091125e-01
    z[6,1,3]  R918      1.2312074750661850e-01
    z[6,1,3]  R919      -0.366982102394104
    z[6,1,3]  R920      1.2864798307418823e-01
    z[6,1,3]  R921      -8.5663378238677979e-02
    z[6,1,3]  R922      -3.0126622319221497e-01
    z[6,1,3]  R923      3.9039561152458191e-01
    z[6,1,3]  R924      -4.7683459520339966e-01
    z[6,1,3]  R925      -1.6152353584766388e-01
    z[6,1,3]  R926      -2.0118415355682373e-01
    z[6,1,3]  R927      3.3191543817520142e-01
    z[6,1,3]  R928      4.8919060826301575e-01
    z[6,1,3]  R929      -6.1220663785934448e-01
    z[6,1,3]  R930      1.7509926855564117e-01
    z[6,1,3]  R931      -4.7625014185905457e-01
    z[6,1,3]  R932      4.8647928237915039e-01
    z[6,1,3]  R933      -2.3330879211425781e-01
    z[6,1,3]  R934      -6.9764018058776855e-02
    z[6,1,3]  R935      2.6782515645027161e-01
    z[6,1,3]  R936      -0.405845582485199
    z[6,1,3]  R937      6.4888454973697662e-02
    z[6,1,3]  R938      -3.8919255137443542e-01
    z[6,1,3]  R939      1.6290649771690369e-01
    z[6,1,3]  R940      -3.8584843277931213e-01
    z[6,1,3]  R941      8.2914769649505615e-02
    z[6,1,3]  R942      3.1777891516685486e-01
    z[6,1,3]  R943      -2.1474552154541016e-01
    z[6,1,3]  R944      1.8357586860656738e-01
    z[6,1,3]  R945      6.8477582931518555e-01
    z[6,1,3]  R946      1.3806837797164917e-01
    z[6,1,3]  R947      -6.0245178639888763e-02
    z[6,1,3]  R948      2.5885561108589172e-01
    z[6,1,3]  R949      -4.7876462340354919e-01
    z[6,1,3]  R950      -0.363491028547287
    z[6,1,3]  R951      5.1065343618392944e-01
    z[6,1,3]  R952      -3.0907431617379189e-02
    z[6,1,3]  R953      -1.0652960836887360e-01
    z[6,1,3]  R954      -3.7224423885345459e-01
    z[6,1,3]  R955      5.8253329992294312e-01
    z[6,1,3]  R956      4.3245518207550049e-01
    z[6,1,3]  R957      4.9656990170478821e-01
    z[6,1,3]  R958      5.7550114393234253e-01
    z[6,1,3]  R959      5.2948659658432007e-01
    z[6,1,3]  R960      6.5426230430603027e-01
    z[6,1,3]  R961      9.0064838528633118e-02
    z[6,1,3]  R962      1.2413965165615082e-01
    z[6,1,3]  R963      7.1115463972091675e-02
    z[6,1,3]  R964      6.2369710206985474e-01
    z[6,1,3]  R965      4.5309442281723022e-01
    z[6,1,3]  R966      3.4645467996597290e-01
    z[6,1,3]  R967      5.4036104679107666e-01
    z[6,1,3]  R968      2.8364226222038269e-01
    z[6,1,3]  R969      7.6607018709182739e-01
    z[6,1,3]  R970      0.468136727809906
    z[6,1,3]  R971      2.8573292493820190e-01
    z[6,1,3]  R972      1.3243648409843445e-01
    z[6,1,3]  R973      1.1205623298883438e-01
    z[6,1,3]  R974      3.3471721410751343e-01
    z[6,1,3]  R975      4.3947091698646545e-01
    z[6,1,3]  R976      3.9231842756271362e-01
    z[6,1,3]  R977      3.9689761400222778e-01
    z[6,1,3]  R978      -7.3697227053344250e-03
    z[6,1,3]  R979      -1.6436351463198662e-02
    z[6,1,3]  R980      -4.0541672706604004e-01
    z[6,1,3]  R981      -6.1854767799377441e-01
    z[6,1,3]  R982      -3.1052476167678833e-01
    z[6,1,3]  R983      -4.6811640262603760e-01
    z[6,1,3]  R984      -2.9047888517379761e-01
    z[6,1,3]  R985      -4.2592954635620117e-01
    z[6,1,3]  R986      -5.0239515304565430e-01
    z[6,1,3]  R987      1.1542630381882191e-02
    z[6,1,3]  R988      -3.5988822579383850e-01
    z[6,1,3]  R989      -5.7506734132766724e-01
    z[6,1,3]  R990      -6.6924935579299927e-01
    z[6,1,3]  R991      -3.9783358573913574e-01
    z[6,1,3]  R992      4.7208401560783386e-01
    z[6,1,4]  R15       1
    z[6,1,4]  R60       -1
    z[6,1,4]  R907      -1
    z[6,1,4]  R908      1
    z[6,1,4]  R913      -6.3743394613265991e-01
    z[6,1,4]  R914      -1.3657073676586151e-01
    z[6,1,4]  R915      -2.7995908260345459e-01
    z[6,1,4]  R916      -5.8870977163314819e-01
    z[6,1,4]  R917      -8.1852513551712036e-01
    z[6,1,4]  R918      8.7458200752735138e-02
    z[6,1,4]  R919      -4.6370047330856323e-01
    z[6,1,4]  R920      1.2290842831134796e-01
    z[6,1,4]  R921      -6.2325045466423035e-02
    z[6,1,4]  R922      -7.8452903032302856e-01
    z[6,1,4]  R923      8.9119784533977509e-02
    z[6,1,4]  R924      1.4148251712322235e-01
    z[6,1,4]  R925      1.2777429819107056e-01
    z[6,1,4]  R926      1.1681786179542542e-01
    z[6,1,4]  R927      3.0304929614067078e-01
    z[6,1,4]  R928      -6.9315090775489807e-02
    z[6,1,4]  R929      4.2483016848564148e-01
    z[6,1,4]  R930      1.8962581455707550e-01
    z[6,1,4]  R931      1.5284567140042782e-02
    z[6,1,4]  R932      2.2329214215278625e-01
    z[6,1,4]  R933      -3.4885589033365250e-02
    z[6,1,4]  R934      -5.6437385082244873e-01
    z[6,1,4]  R935      -3.9155066013336182e-01
    z[6,1,4]  R936      6.4252310991287231e-01
    z[6,1,4]  R937      -1.9448530673980713e-01
    z[6,1,4]  R938      -5.9565279632806778e-02
    z[6,1,4]  R939      4.3613232672214508e-02
    z[6,1,4]  R940      -1.6706696152687073e-01
    z[6,1,4]  R941      1.5945152938365936e-01
    z[6,1,4]  R942      -0.700086772441864
    z[6,1,4]  R943      -8.6237683892250061e-02
    z[6,1,4]  R944      2.8281274437904358e-01
    z[6,1,4]  R945      -1.9821323454380035e-01
    z[6,1,4]  R946      -1.6417573392391205e-01
    z[6,1,4]  R947      1.9250491261482239e-01
    z[6,1,4]  R948      5.5724793672561646e-01
    z[6,1,4]  R949      2.7393159270286560e-01
    z[6,1,4]  R950      1.7277634143829346e-01
    z[6,1,4]  R951      0.624572217464447
    z[6,1,4]  R952      0.0839446485042572
    z[6,1,4]  R953      -4.2701106518507004e-02
    z[6,1,4]  R954      -1.0903651267290115e-01
    z[6,1,4]  R955      -3.8109406828880310e-02
    z[6,1,4]  R956      -2.6365658640861511e-01
    z[6,1,4]  R957      -1.0086496174335480e-01
    z[6,1,4]  R958      -4.2758235335350037e-01
    z[6,1,4]  R959      -0.0987108051776886
    z[6,1,4]  R960      -1.8443804234266281e-02
    z[6,1,4]  R961      -8.4633342921733856e-02
    z[6,1,4]  R962      -1.1293911933898926e-01
    z[6,1,4]  R963      0.827197790145874
    z[6,1,4]  R964      -6.3351714611053467e-01
    z[6,1,4]  R965      -6.4652818441390991e-01
    z[6,1,4]  R966      -4.9971318244934082e-01
    z[6,1,4]  R967      -4.7033041715621948e-01
    z[6,1,4]  R968      -3.9395216107368469e-01
    z[6,1,4]  R969      -3.5066959261894226e-01
    z[6,1,4]  R970      -1.9051505625247955e-01
    z[6,1,4]  R971      -4.0630677342414856e-01
    z[6,1,4]  R972      -7.6303946971893311e-01
    z[6,1,4]  R973      3.2096426934003830e-02
    z[6,1,4]  R974      -1.1262485384941101e-01
    z[6,1,4]  R975      -1.1069152504205704e-02
    z[6,1,4]  R976      -8.4059886634349823e-02
    z[6,1,4]  R977      -0.0471460185945034
    z[6,1,4]  R978      -1.4118281193077564e-02
    z[6,1,4]  R979      4.1445949673652649e-01
    z[6,1,4]  R980      -5.0145995616912842e-01
    z[6,1,4]  R981      3.1634697318077087e-01
    z[6,1,4]  R982      3.2800965011119843e-02
    z[6,1,4]  R983      3.9694914221763611e-01
    z[6,1,4]  R984      -1.3578631915152073e-02
    z[6,1,4]  R985      -2.8430971503257751e-01
    z[6,1,4]  R986      -3.9041060209274292e-01
    z[6,1,4]  R987      4.7830536961555481e-01
    z[6,1,4]  R988      -2.0111978054046631e-01
    z[6,1,4]  R989      2.9851067066192627e-01
    z[6,1,4]  R990      -2.3639839142560959e-02
    z[6,1,4]  R991      -1.8404923379421234e-01
    z[6,1,4]  R992      -0.517731785774231
    z[6,1,5]  R16       1
    z[6,1,5]  R61       -1
    z[6,1,5]  R909      -1
    z[6,1,5]  R910      1
    z[6,1,5]  R913      2.0146530866622925e-01
    z[6,1,5]  R914      1.3990907371044159e-01
    z[6,1,5]  R915      3.3354374766349792e-01
    z[6,1,5]  R916      3.0304759740829468e-01
    z[6,1,5]  R917      3.3876052498817444e-01
    z[6,1,5]  R918      3.4586733579635620e-01
    z[6,1,5]  R919      2.0835934579372406e-01
    z[6,1,5]  R920      2.6599800586700439e-01
    z[6,1,5]  R921      4.1952362656593323e-01
    z[6,1,5]  R922      4.9756024032831192e-02
    z[6,1,5]  R923      -1.2804748117923737e-01
    z[6,1,5]  R924      5.2556627988815308e-01
    z[6,1,5]  R925      -1.1099065840244293e-01
    z[6,1,5]  R926      -5.7539731264114380e-02
    z[6,1,5]  R927      -2.8323435783386230e-01
    z[6,1,5]  R928      -1.1019649356603622e-01
    z[6,1,5]  R929      3.2817018032073975e-01
    z[6,1,5]  R930      -1.2396162748336792e-01
    z[6,1,5]  R931      -1.2915004789829254e-01
    z[6,1,5]  R932      -2.5686267018318176e-01
    z[6,1,5]  R933      -3.6452582478523254e-01
    z[6,1,5]  R934      5.6535284966230392e-02
    z[6,1,5]  R935      4.9025887250900269e-01
    z[6,1,5]  R936      -2.7779844403266907e-01
    z[6,1,5]  R937      6.3344120979309082e-01
    z[6,1,5]  R938      6.5751016139984131e-01
    z[6,1,5]  R939      -6.4349383115768433e-02
    z[6,1,5]  R940      -1.0267642885446548e-01
    z[6,1,5]  R941      7.5395655632019043e-01
    z[6,1,5]  R942      -2.2027517855167389e-01
    z[6,1,5]  R943      -1.9749562442302704e-01
    z[6,1,5]  R944      1.4104568958282471e-01
    z[6,1,5]  R945      -8.9955426752567291e-02
    z[6,1,5]  R946      1.8768961727619171e-01
    z[6,1,5]  R947      -4.1778244078159332e-02
    z[6,1,5]  R948      -2.9994806647300720e-01
    z[6,1,5]  R949      -1.2022332102060318e-01
    z[6,1,5]  R950      -1.8738360702991486e-01
    z[6,1,5]  R951      1.8032878637313843e-01
    z[6,1,5]  R952      -1.3821698725223541e-01
    z[6,1,5]  R953      -1.3769541680812836e-01
    z[6,1,5]  R954      -0.563877522945404
    z[6,1,5]  R955      8.5845552384853363e-03
    z[6,1,5]  R956      0.00700989319011569
    z[6,1,5]  R957      -5.6152928620576859e-02
    z[6,1,5]  R958      9.8681680858135223e-02
    z[6,1,5]  R959      -3.2476380467414856e-01
    z[6,1,5]  R960      7.6823040843009949e-02
    z[6,1,5]  R961      3.4556340426206589e-02
    z[6,1,5]  R962      -2.9272469878196716e-01
    z[6,1,5]  R963      -1.5474167652428150e-02
    z[6,1,5]  R964      1.0599581152200699e-01
    z[6,1,5]  R965      -2.5980386137962341e-01
    z[6,1,5]  R966      1.1180879175662994e-01
    z[6,1,5]  R967      0.0648990347981453
    z[6,1,5]  R968      2.8234541416168213e-01
    z[6,1,5]  R969      2.7899768948554993e-01
    z[6,1,5]  R970      1.2590293586254120e-01
    z[6,1,5]  R971      6.7350721359252930e-01
    z[6,1,5]  R972      9.8208189010620117e-02
    z[6,1,5]  R973      2.0516207814216614e-01
    z[6,1,5]  R974      -0.364769846200943
    z[6,1,5]  R975      8.3711095154285431e-02
    z[6,1,5]  R976      -2.5648900866508484e-01
    z[6,1,5]  R977      -2.9499495029449463e-01
    z[6,1,5]  R978      -1.0593015700578690e-01
    z[6,1,5]  R979      -2.6589006185531616e-01
    z[6,1,5]  R980      -7.9941317439079285e-02
    z[6,1,5]  R981      2.0427992939949036e-01
    z[6,1,5]  R982      1.9457958638668060e-01
    z[6,1,5]  R983      -7.8477680683135986e-02
    z[6,1,5]  R984      -1.4952444471418858e-02
    z[6,1,5]  R985      -7.9793877899646759e-02
    z[6,1,5]  R986      -0.0723300352692604
    z[6,1,5]  R987      2.5796961784362793e-01
    z[6,1,5]  R988      -5.6732857227325439e-01
    z[6,1,5]  R989      3.7883457541465759e-01
    z[6,1,5]  R990      4.5789572596549988e-01
    z[6,1,5]  R991      6.8522137403488159e-01
    z[6,1,5]  R992      5.4043656587600708e-01
    z[6,1,6]  R17       1
    z[6,1,6]  R62       -1
    z[6,1,6]  R911      -1
    z[6,1,6]  R912      1
    z[6,1,6]  R913      2.9068502783775330e-01
    z[6,1,6]  R914      2.8227454423904419e-01
    z[6,1,6]  R915      1.7670619487762451e-01
    z[6,1,6]  R916      -1.1906898766756058e-01
    z[6,1,6]  R917      -1.2550881505012512e-01
    z[6,1,6]  R918      -5.1650381088256836e-01
    z[6,1,6]  R919      -4.2562881112098694e-01
    z[6,1,6]  R920      0.447286456823349
    z[6,1,6]  R921      -2.2831052541732788e-02
    z[6,1,6]  R922      -1.1260929703712463e-01
    z[6,1,6]  R923      1.2358459830284119e-01
    z[6,1,6]  R924      0.00592637388035655
    z[6,1,6]  R925      -1.7166891694068909e-01
    z[6,1,6]  R926      6.7347057163715363e-02
    z[6,1,6]  R927      5.3730695508420467e-03
    z[6,1,6]  R928      -7.0308116264641285e-03
    z[6,1,6]  R929      -2.6035559177398682e-01
    z[6,1,6]  R930      -5.4442346096038818e-02
    z[6,1,6]  R931      -2.9928541183471680e-01
    z[6,1,6]  R932      -4.4294662773609161e-02
    z[6,1,6]  R933      3.9246085286140442e-01
    z[6,1,6]  R934      5.1586157083511353e-01
    z[6,1,6]  R935      6.9776542484760284e-02
    z[6,1,6]  R936      2.9474783688783646e-02
    z[6,1,6]  R937      -8.5204273462295532e-02
    z[6,1,6]  R938      1.3028287887573242e-01
    z[6,1,6]  R939      -6.7805522680282593e-01
    z[6,1,6]  R940      -6.6481471061706543e-01
    z[6,1,6]  R941      0.299459844827652
    z[6,1,6]  R942      -1.1630912870168686e-01
    z[6,1,6]  R943      -2.8347286581993103e-01
    z[6,1,6]  R944      -4.8547599464654922e-02
    z[6,1,6]  R945      3.9975982904434204e-01
    z[6,1,6]  R946      -6.5692657232284546e-01
    z[6,1,6]  R947      -6.9269323348999023e-01
    z[6,1,6]  R948      1.5495055913925171e-01
    z[6,1,6]  R949      4.4680300354957581e-01
    z[6,1,6]  R950      7.6224094629287720e-01
    z[6,1,6]  R951      -6.8241044878959656e-02
    z[6,1,6]  R952      8.2412803173065186e-01
    z[6,1,6]  R953      -5.5232111364603043e-02
    z[6,1,6]  R954      -2.7220547199249268e-01
    z[6,1,6]  R955      1.6095350682735443e-01
    z[6,1,6]  R956      -3.3334780484437943e-02
    z[6,1,6]  R957      -3.8633573055267334e-01
    z[6,1,6]  R958      -4.3321792036294937e-02
    z[6,1,6]  R959      2.1497417986392975e-01
    z[6,1,6]  R960      1.2258848547935486e-01
    z[6,1,6]  R961      -1.7597796022891998e-01
    z[6,1,6]  R962      -1.2156955152750015e-01
    z[6,1,6]  R963      -0.0600656233727932
    z[6,1,6]  R964      -1.8227970227599144e-02
    z[6,1,6]  R965      5.8530010282993317e-02
    z[6,1,6]  R966      -1.7670390009880066e-01
    z[6,1,6]  R967      3.7089386582374573e-01
    z[6,1,6]  R968      3.0736133456230164e-01
    z[6,1,6]  R969      7.1762762963771820e-02
    z[6,1,6]  R970      7.9394921660423279e-02
    z[6,1,6]  R971      1.7386290431022644e-01
    z[6,1,6]  R972      1.0488359630107880e-01
    z[6,1,6]  R973      1.4423468708992004e-01
    z[6,1,6]  R974      -1.8995878100395203e-01
    z[6,1,6]  R975      -1.7092873156070709e-01
    z[6,1,6]  R976      7.1612037718296051e-02
    z[6,1,6]  R977      -8.1680983304977417e-02
    z[6,1,6]  R978      5.1010406017303467e-01
    z[6,1,6]  R979      -1.4856582880020142e-01
    z[6,1,6]  R980      -1.9486727192997932e-02
    z[6,1,6]  R981      2.5488814339041710e-02
    z[6,1,6]  R982      -0.40351602435112
    z[6,1,6]  R983      -3.9917615056037903e-01
    z[6,1,6]  R984      5.8154135942459106e-02
    z[6,1,6]  R985      2.1559296175837517e-02
    z[6,1,6]  R986      2.2480469942092896e-01
    z[6,1,6]  R987      -4.2965874075889587e-01
    z[6,1,6]  R988      1.0333219915628433e-01
    z[6,1,6]  R989      2.1412852406501770e-01
    z[6,1,6]  R990      1.2260851263999939e-01
    z[6,1,6]  R991      3.2578937709331512e-02
    z[6,1,6]  R992      -8.6356140673160553e-02
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R993      -1
    z[2,3,0]  R994      1
    z[2,3,0]  R1007     -5.8756476640701294e-01
    z[2,3,0]  R1008     -7.9760897159576416e-01
    z[2,3,0]  R1009     -5.8294034004211426e-01
    z[2,3,0]  R1010     -6.3656675815582275e-01
    z[2,3,0]  R1011     0.000665637431666255
    z[2,3,0]  R1012     3.4158188104629517e-01
    z[2,3,0]  R1013     3.1974050402641296e-01
    z[2,3,0]  R1014     3.4665313363075256e-01
    z[2,3,0]  R1015     1.9608055055141449e-01
    z[2,3,0]  R1016     6.2233191728591919e-01
    z[2,3,0]  R1017     1.2805898487567902e-01
    z[2,3,0]  R1018     2.9837599396705627e-01
    z[2,3,0]  R1019     5.3156417608261108e-01
    z[2,3,0]  R1020     3.4490948915481567e-01
    z[2,3,0]  R1021     5.7030439376831055e-01
    z[2,3,0]  R1022     9.3179166316986084e-01
    z[2,3,0]  R1023     8.4341913461685181e-01
    z[2,3,0]  R1024     8.8378113508224487e-01
    z[2,3,0]  R1025     8.3961808681488037e-01
    z[2,3,0]  R1026     8.8593792915344238e-01
    z[2,3,0]  R1027     1.4354000985622406e-01
    z[2,3,0]  R1028     0.34108966588974
    z[2,3,0]  R1029     1.1674237251281738e-01
    z[2,3,0]  R1030     1.1136688292026520e-01
    z[2,3,0]  R1031     4.5378932356834412e-01
    z[2,3,0]  R1032     4.1349762678146362e-01
    z[2,3,0]  R1033     6.7828559875488281e-01
    z[2,3,0]  R1034     4.8787105083465576e-01
    z[2,3,0]  R1035     3.5431259870529175e-01
    z[2,3,0]  R1036     8.2129406929016113e-01
    z[2,3,0]  R1037     3.7067100405693054e-02
    z[2,3,0]  R1038     3.7179496884346008e-01
    z[2,3,0]  R1039     -4.1181966662406921e-01
    z[2,3,0]  R1040     5.1207607984542847e-01
    z[2,3,0]  R1041     -6.3994753360748291e-01
    z[2,3,0]  R1042     -0.316124826669693
    z[2,3,0]  R1043     -4.0294739603996277e-01
    z[2,3,0]  R1044     5.3729891777038574e-01
    z[2,3,0]  R1045     -4.6869885921478271e-01
    z[2,3,0]  R1046     -4.5559534430503845e-01
    z[2,3,0]  R1047     7.8173793852329254e-02
    z[2,3,0]  R1048     -1.7945900559425354e-01
    z[2,3,0]  R1049     -1.2135547585785389e-03
    z[2,3,0]  R1050     -0.0807340145111084
    z[2,3,0]  R1051     -2.4226111173629761e-01
    z[2,3,0]  R1052     -2.3268264532089233e-01
    z[2,3,0]  R1053     -5.3354259580373764e-02
    z[2,3,0]  R1054     -3.0456345528364182e-02
    z[2,3,0]  R1055     -2.2064997255802155e-01
    z[2,3,0]  R1056     -4.6148531138896942e-02
    z[2,3,0]  R1057     6.5666645765304565e-02
    z[2,3,0]  R1058     -1.9799323379993439e-01
    z[2,3,0]  R1059     3.2701876759529114e-01
    z[2,3,0]  R1060     -1.4233329892158508e-01
    z[2,3,0]  R1061     1.9304735586047173e-02
    z[2,3,0]  R1062     -1.5847027301788330e-01
    z[2,3,0]  R1063     5.3673553466796875e-01
    z[2,3,0]  R1064     3.6323402076959610e-02
    z[2,3,0]  R1065     -3.4531587362289429e-01
    z[2,3,0]  R1066     -1.6749443113803864e-01
    z[2,3,0]  R1067     -2.3113049566745758e-01
    z[2,3,0]  R1068     -4.3012022972106934e-02
    z[2,3,0]  R1069     4.8231253027915955e-01
    z[2,3,0]  R1070     2.5550296530127525e-02
    z[2,3,0]  R1071     -2.0028276741504669e-01
    z[2,3,0]  R1072     -4.8691046237945557e-01
    z[2,3,0]  R1073     -1.2682755291461945e-01
    z[2,3,0]  R1074     2.6874890923500061e-01
    z[2,3,0]  R1075     1.3006573915481567e-01
    z[2,3,0]  R1076     3.6033737659454346e-01
    z[2,3,0]  R1077     5.9692794084548950e-01
    z[2,3,0]  R1078     3.9397379755973816e-01
    z[2,3,0]  R1079     -1.7629776895046234e-01
    z[2,3,0]  R1080     1.2649475038051605e-01
    z[2,3,0]  R1081     5.8065932244062424e-02
    z[2,3,0]  R1082     -2.4579444527626038e-01
    z[2,3,0]  R1083     6.5198093652725220e-02
    z[2,3,0]  R1084     5.4943734407424927e-01
    z[2,3,0]  R1085     -1.5163809061050415e-01
    z[2,3,0]  R1086     -2.2004279494285583e-01
    z[2,3,0]  R1087     -1.1727644503116608e-01
    z[2,3,0]  R1088     1.9039590656757355e-01
    z[2,3,0]  R1089     2.9173459857702255e-02
    z[2,3,0]  R1090     -5.5233038961887360e-02
    z[2,3,0]  R1091     -1.4811183512210846e-01
    z[2,3,0]  R1092     9.3578584492206573e-02
    z[2,3,0]  R1093     -9.8985306918621063e-02
    z[2,3,0]  R1094     -1.3010847568511963e-01
    z[2,3,0]  R1095     1.1820724606513977e-01
    z[2,3,0]  R1096     -2.2255496680736542e-01
    z[2,3,0]  R1097     -1.2191570550203323e-01
    z[2,3,0]  R1098     -3.0332719907164574e-02
    z[2,3,0]  R1099     -8.1705629825592041e-02
    z[2,3,0]  R1100     -3.3933378756046295e-02
    z[2,3,0]  R1101     4.9755383282899857e-02
    z[2,3,0]  R1102     1.3494296371936798e-01
    z[2,3,0]  R1103     0.0110483942553401
    z[2,3,0]  R1104     1.4044113457202911e-01
    z[2,3,0]  R1105     0.590168297290802
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R995      -1
    z[2,3,1]  R996      1
    z[2,3,1]  R1007     -3.0761319398880005e-01
    z[2,3,1]  R1008     -2.1458260715007782e-02
    z[2,3,1]  R1009     -1.5686792135238647e-01
    z[2,3,1]  R1010     -1.1779581010341644e-01
    z[2,3,1]  R1011     -6.7735219001770020e-01
    z[2,3,1]  R1012     0.693505585193634
    z[2,3,1]  R1013     5.1017683744430542e-01
    z[2,3,1]  R1014     0.678641140460968
    z[2,3,1]  R1015     4.3037557601928711e-01
    z[2,3,1]  R1016     -9.2120125889778137e-02
    z[2,3,1]  R1017     7.4141013622283936e-01
    z[2,3,1]  R1018     7.4333906173706055e-01
    z[2,3,1]  R1019     6.6982412338256836e-01
    z[2,3,1]  R1020     -5.7433068752288818e-01
    z[2,3,1]  R1021     -4.5757806301116943e-01
    z[2,3,1]  R1022     4.9543965607881546e-02
    z[2,3,1]  R1023     2.1142403781414032e-01
    z[2,3,1]  R1024     1.2041904032230377e-01
    z[2,3,1]  R1025     1.6735802590847015e-01
    z[2,3,1]  R1026     3.4211522340774536e-01
    z[2,3,1]  R1027     8.5066372156143188e-01
    z[2,3,1]  R1028     6.7517876625061035e-01
    z[2,3,1]  R1029     7.0113706588745117e-01
    z[2,3,1]  R1030     0.666340172290802
    z[2,3,1]  R1031     -4.4583463668823242e-01
    z[2,3,1]  R1032     -5.0902652740478516e-01
    z[2,3,1]  R1033     -4.3175652623176575e-01
    z[2,3,1]  R1034     -1.7618516087532043e-01
    z[2,3,1]  R1035     -5.4970139265060425e-01
    z[2,3,1]  R1036     -6.8831346929073334e-02
    z[2,3,1]  R1037     6.9367986917495728e-01
    z[2,3,1]  R1038     6.6264796257019043e-01
    z[2,3,1]  R1039     -4.9712666869163513e-01
    z[2,3,1]  R1040     4.0542349219322205e-01
    z[2,3,1]  R1041     -0.443347305059433
    z[2,3,1]  R1042     -5.1285165548324585e-01
    z[2,3,1]  R1043     -0.450613796710968
    z[2,3,1]  R1044     6.5254640579223633e-01
    z[2,3,1]  R1045     -6.2381881475448608e-01
    z[2,3,1]  R1046     7.0405995845794678e-01
    z[2,3,1]  R1047     -9.6634417772293091e-01
    z[2,3,1]  R1048     -8.2638806104660034e-01
    z[2,3,1]  R1049     -8.3274024724960327e-01
    z[2,3,1]  R1050     -9.4393610954284668e-01
    z[2,3,1]  R1051     -8.9501363039016724e-01
    z[2,3,1]  R1052     -8.5856539011001587e-01
    z[2,3,1]  R1053     -9.3438696861267090e-01
    z[2,3,1]  R1054     -8.9354443550109863e-01
    z[2,3,1]  R1055     -8.9741677045822144e-01
    z[2,3,1]  R1056     -8.6780643463134766e-01
    z[2,3,1]  R1057     9.0192121267318726e-01
    z[2,3,1]  R1058     0.6239013671875
    z[2,3,1]  R1059     3.4472694993019104e-01
    z[2,3,1]  R1060     0.70050448179245
    z[2,3,1]  R1061     4.5671561360359192e-01
    z[2,3,1]  R1062     0.627260684967041
    z[2,3,1]  R1063     7.8109733294695616e-04
    z[2,3,1]  R1064     -7.5922125577926636e-01
    z[2,3,1]  R1065     -0.715255618095398
    z[2,3,1]  R1066     -5.2114403247833252e-01
    z[2,3,1]  R1067     7.6005853712558746e-02
    z[2,3,1]  R1068     0.802408754825592
    z[2,3,1]  R1069     -0.0430334135890007
    z[2,3,1]  R1070     4.5041911303997040e-02
    z[2,3,1]  R1071     3.0691778659820557e-01
    z[2,3,1]  R1072     2.6438814401626587e-01
    z[2,3,1]  R1073     -5.6059908866882324e-01
    z[2,3,1]  R1074     -6.6544133424758911e-01
    z[2,3,1]  R1075     -6.2691295146942139e-01
    z[2,3,1]  R1076     -6.3844412565231323e-01
    z[2,3,1]  R1077     1.4414748549461365e-01
    z[2,3,1]  R1078     3.5924646258354187e-01
    z[2,3,1]  R1079     4.2892915010452271e-01
    z[2,3,1]  R1080     7.6178300380706787e-01
    z[2,3,1]  R1081     8.5596400499343872e-01
    z[2,3,1]  R1082     5.7058918476104736e-01
    z[2,3,1]  R1083     0.0888204276561737
    z[2,3,1]  R1084     0.0500313900411129
    z[2,3,1]  R1085     -7.8557604551315308e-01
    z[2,3,1]  R1086     -6.9789052009582520e-01
    z[2,3,1]  R1087     5.8851748704910278e-01
    z[2,3,1]  R1088     3.6812219023704529e-01
    z[2,3,1]  R1089     7.0105659961700439e-01
    z[2,3,1]  R1090     6.9236093759536743e-01
    z[2,3,1]  R1091     7.4410974979400635e-01
    z[2,3,1]  R1092     -7.9978233575820923e-01
    z[2,3,1]  R1093     -6.6857415437698364e-01
    z[2,3,1]  R1094     -7.6604461669921875e-01
    z[2,3,1]  R1095     -8.1263101100921631e-01
    z[2,3,1]  R1096     2.2216621041297913e-01
    z[2,3,1]  R1097     8.7879288196563721e-01
    z[2,3,1]  R1098     6.9568967819213867e-01
    z[2,3,1]  R1099     -7.6769274473190308e-01
    z[2,3,1]  R1100     -0.793660581111908
    z[2,3,1]  R1101     -8.9406061172485352e-01
    z[2,3,1]  R1102     -0.69505375623703
    z[2,3,1]  R1103     -6.0580420494079590e-01
    z[2,3,1]  R1104     -4.4465139508247375e-03
    z[2,3,1]  R1105     1.0688560083508492e-02
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R997      -1
    z[2,3,2]  R998      1
    z[2,3,2]  R1007     2.5536981225013733e-01
    z[2,3,2]  R1008     -8.0873884260654449e-02
    z[2,3,2]  R1009     -7.4643611907958984e-01
    z[2,3,2]  R1010     2.6601186394691467e-01
    z[2,3,2]  R1011     -3.3538267016410828e-01
    z[2,3,2]  R1012     3.3730635046958923e-01
    z[2,3,2]  R1013     -5.7383030652999878e-01
    z[2,3,2]  R1014     2.3722781240940094e-01
    z[2,3,2]  R1015     -1.4183494448661804e-01
    z[2,3,2]  R1016     -3.5477694869041443e-01
    z[2,3,2]  R1017     -3.4747142344713211e-02
    z[2,3,2]  R1018     4.0809872746467590e-01
    z[2,3,2]  R1019     -1.4974361658096313e-01
    z[2,3,2]  R1020     1.4509527385234833e-01
    z[2,3,2]  R1021     2.3709741234779358e-01
    z[2,3,2]  R1022     3.8914494216442108e-02
    z[2,3,2]  R1023     8.1839226186275482e-02
    z[2,3,2]  R1024     2.6590687036514282e-01
    z[2,3,2]  R1025     1.2773790955543518e-01
    z[2,3,2]  R1026     2.6197027415037155e-02
    z[2,3,2]  R1027     -1.7921912670135498e-01
    z[2,3,2]  R1028     -3.5935276746749878e-01
    z[2,3,2]  R1029     2.6201415061950684e-01
    z[2,3,2]  R1030     5.6552481651306152e-01
    z[2,3,2]  R1031     -1.4974561333656311e-01
    z[2,3,2]  R1032     -2.2675932943820953e-01
    z[2,3,2]  R1033     -4.1336383670568466e-02
    z[2,3,2]  R1034     1.3642235100269318e-01
    z[2,3,2]  R1035     6.8221598863601685e-01
    z[2,3,2]  R1036     -7.2196260094642639e-02
    z[2,3,2]  R1037     3.7445166707038879e-01
    z[2,3,2]  R1038     -2.4146245419979095e-01
    z[2,3,2]  R1039     -6.5644830465316772e-01
    z[2,3,2]  R1040     -1.2594206631183624e-01
    z[2,3,2]  R1041     -5.0185889005661011e-01
    z[2,3,2]  R1042     -3.9556607604026794e-01
    z[2,3,2]  R1043     -4.8620283603668213e-01
    z[2,3,2]  R1044     -5.1303360611200333e-02
    z[2,3,2]  R1045     -1.8828479945659637e-01
    z[2,3,2]  R1046     -1.8435798585414886e-01
    z[2,3,2]  R1047     1.3297490775585175e-01
    z[2,3,2]  R1048     -1.6308559570461512e-03
    z[2,3,2]  R1049     -7.8419208526611328e-02
    z[2,3,2]  R1050     1.8751381337642670e-01
    z[2,3,2]  R1051     1.4740787446498871e-01
    z[2,3,2]  R1052     3.0041760206222534e-01
    z[2,3,2]  R1053     3.2278785109519958e-01
    z[2,3,2]  R1054     1.4655736088752747e-01
    z[2,3,2]  R1055     -4.4597167521715164e-02
    z[2,3,2]  R1056     2.1245136857032776e-01
    z[2,3,2]  R1057     -1.2600612640380859e-01
    z[2,3,2]  R1058     -2.3675315082073212e-01
    z[2,3,2]  R1059     -1.9854129850864410e-01
    z[2,3,2]  R1060     -8.3444461226463318e-02
    z[2,3,2]  R1061     -2.7143913507461548e-01
    z[2,3,2]  R1062     -2.6291960477828979e-01
    z[2,3,2]  R1063     -0.0666758269071579
    z[2,3,2]  R1064     -1.8733938038349152e-01
    z[2,3,2]  R1065     -0.0946456640958786
    z[2,3,2]  R1066     -1.4219684898853302e-01
    z[2,3,2]  R1067     2.4438938498497009e-01
    z[2,3,2]  R1068     -3.3602195978164673e-01
    z[2,3,2]  R1069     -5.1875356584787369e-03
    z[2,3,2]  R1070     2.1833754144608974e-03
    z[2,3,2]  R1071     -2.4139027297496796e-01
    z[2,3,2]  R1072     -1.5233443677425385e-01
    z[2,3,2]  R1073     -4.3736910820007324e-01
    z[2,3,2]  R1074     -2.3348213732242584e-01
    z[2,3,2]  R1075     -4.5843631029129028e-01
    z[2,3,2]  R1076     1.5957817435264587e-01
    z[2,3,2]  R1077     2.9598847031593323e-01
    z[2,3,2]  R1078     2.7041327953338623e-01
    z[2,3,2]  R1079     -2.4659752845764160e-01
    z[2,3,2]  R1080     -4.6603524684906006e-01
    z[2,3,2]  R1081     -0.0762200802564621
    z[2,3,2]  R1082     2.4485167115926743e-02
    z[2,3,2]  R1083     2.6378279551863670e-02
    z[2,3,2]  R1084     -3.3334141969680786e-01
    z[2,3,2]  R1085     -9.0231351554393768e-02
    z[2,3,2]  R1086     -3.5453933477401733e-01
    z[2,3,2]  R1087     4.3191414326429367e-02
    z[2,3,2]  R1088     -0.341232031583786
    z[2,3,2]  R1089     -4.0100088715553284e-01
    z[2,3,2]  R1090     -7.8620567917823792e-02
    z[2,3,2]  R1091     -1.0464297980070114e-01
    z[2,3,2]  R1092     -2.4717628955841064e-01
    z[2,3,2]  R1093     -3.3976930379867554e-01
    z[2,3,2]  R1094     -1.2700571119785309e-01
    z[2,3,2]  R1095     1.9309714436531067e-01
    z[2,3,2]  R1096     7.5070065259933472e-01
    z[2,3,2]  R1097     -2.0854748785495758e-01
    z[2,3,2]  R1098     2.2803038358688354e-01
    z[2,3,2]  R1099     -1.6927412152290344e-01
    z[2,3,2]  R1100     -3.2806521654129028e-01
    z[2,3,2]  R1101     7.4264849536120892e-03
    z[2,3,2]  R1102     -2.3701396584510803e-01
    z[2,3,2]  R1103     1.0115970671176910e-01
    z[2,3,2]  R1104     0.692564845085144
    z[2,3,2]  R1105     3.3201807737350464e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R999      -1
    z[2,3,3]  R1000     1
    z[2,3,3]  R1007     6.9872546195983887e-01
    z[2,3,3]  R1008     -1.4361524581909180e-01
    z[2,3,3]  R1009     -1.6800025105476379e-01
    z[2,3,3]  R1010     -3.9234411716461182e-01
    z[2,3,3]  R1011     -1.6036370769143105e-02
    z[2,3,3]  R1012     3.7227776646614075e-01
    z[2,3,3]  R1013     3.9219167828559875e-01
    z[2,3,3]  R1014     2.6986068487167358e-01
    z[2,3,3]  R1015     3.6536210775375366e-01
    z[2,3,3]  R1016     2.0269700884819031e-01
    z[2,3,3]  R1017     -3.0786329880356789e-02
    z[2,3,3]  R1018     -3.0556395649909973e-01
    z[2,3,3]  R1019     -2.9215618968009949e-01
    z[2,3,3]  R1020     -3.1286829710006714e-01
    z[2,3,3]  R1021     1.5310217440128326e-01
    z[2,3,3]  R1022     -2.8971329331398010e-01
    z[2,3,3]  R1023     -3.9567741751670837e-01
    z[2,3,3]  R1024     -3.3423423767089844e-01
    z[2,3,3]  R1025     -3.4821224212646484e-01
    z[2,3,3]  R1026     -2.6191130280494690e-01
    z[2,3,3]  R1027     8.6467579007148743e-02
    z[2,3,3]  R1028     1.3405305147171021e-01
    z[2,3,3]  R1029     1.1523726396262646e-02
    z[2,3,3]  R1030     1.6345396637916565e-01
    z[2,3,3]  R1031     1.2899482250213623e-01
    z[2,3,3]  R1032     6.1010837554931641e-02
    z[2,3,3]  R1033     2.9394409060478210e-01
    z[2,3,3]  R1034     0.0871608629822731
    z[2,3,3]  R1035     -2.4624569714069366e-01
    z[2,3,3]  R1036     -1.4056387543678284e-01
    z[2,3,3]  R1037     4.9024832248687744e-01
    z[2,3,3]  R1038     5.2322983741760254e-01
    z[2,3,3]  R1039     -2.6184621453285217e-01
    z[2,3,3]  R1040     5.5958682298660278e-01
    z[2,3,3]  R1041     6.1362501233816147e-02
    z[2,3,3]  R1042     -4.5997259020805359e-01
    z[2,3,3]  R1043     -1.9809435307979584e-01
    z[2,3,3]  R1044     -0.0729481503367424
    z[2,3,3]  R1045     -1.1497498303651810e-01
    z[2,3,3]  R1046     2.1794460713863373e-01
    z[2,3,3]  R1047     -1.2271368503570557e-01
    z[2,3,3]  R1048     -1.6657491028308868e-01
    z[2,3,3]  R1049     -1.7226240038871765e-01
    z[2,3,3]  R1050     -2.4263501167297363e-01
    z[2,3,3]  R1051     -2.9438859224319458e-01
    z[2,3,3]  R1052     -1.4323222637176514e-01
    z[2,3,3]  R1053     5.3854927420616150e-02
    z[2,3,3]  R1054     8.3793297410011292e-02
    z[2,3,3]  R1055     5.9439826756715775e-02
    z[2,3,3]  R1056     2.2096496820449829e-01
    z[2,3,3]  R1057     -3.3231475949287415e-01
    z[2,3,3]  R1058     8.5544362664222717e-02
    z[2,3,3]  R1059     5.4995030164718628e-02
    z[2,3,3]  R1060     -2.5623863935470581e-01
    z[2,3,3]  R1061     1.4718367159366608e-01
    z[2,3,3]  R1062     -4.7586208581924438e-01
    z[2,3,3]  R1063     5.7744556665420532e-01
    z[2,3,3]  R1064     -3.7982547283172607e-01
    z[2,3,3]  R1065     -3.8820537924766541e-01
    z[2,3,3]  R1066     -6.8278080224990845e-01
    z[2,3,3]  R1067     5.6001764535903931e-01
    z[2,3,3]  R1068     -8.2615956664085388e-02
    z[2,3,3]  R1069     5.9955221414566040e-01
    z[2,3,3]  R1070     5.5213242769241333e-01
    z[2,3,3]  R1071     6.8202984333038330e-01
    z[2,3,3]  R1072     0.567356526851654
    z[2,3,3]  R1073     -3.3254262804985046e-01
    z[2,3,3]  R1074     -6.4255464076995850e-01
    z[2,3,3]  R1075     -4.6182984113693237e-01
    z[2,3,3]  R1076     -5.4322427511215210e-01
    z[2,3,3]  R1077     3.8676840066909790e-01
    z[2,3,3]  R1078     -1.4344982802867889e-01
    z[2,3,3]  R1079     6.5242147445678711e-01
    z[2,3,3]  R1080     -2.0302671939134598e-02
    z[2,3,3]  R1081     -3.8734534382820129e-01
    z[2,3,3]  R1082     2.6633885502815247e-01
    z[2,3,3]  R1083     9.2679816484451294e-01
    z[2,3,3]  R1084     4.9930948019027710e-01
    z[2,3,3]  R1085     -2.5792637467384338e-01
    z[2,3,3]  R1086     -3.6546853184700012e-01
    z[2,3,3]  R1087     5.7596552371978760e-01
    z[2,3,3]  R1088     5.1674467325210571e-01
    z[2,3,3]  R1089     8.7929308414459229e-02
    z[2,3,3]  R1090     3.7946559488773346e-02
    z[2,3,3]  R1091     -3.0083081126213074e-01
    z[2,3,3]  R1092     -1.4255067706108093e-01
    z[2,3,3]  R1093     -5.8918052911758423e-01
    z[2,3,3]  R1094     -1.2219463288784027e-01
    z[2,3,3]  R1095     2.0624296367168427e-01
    z[2,3,3]  R1096     -3.6771920323371887e-01
    z[2,3,3]  R1097     1.7160816490650177e-01
    z[2,3,3]  R1098     -1.2418014556169510e-01
    z[2,3,3]  R1099     -5.4831933975219727e-01
    z[2,3,3]  R1100     -3.3369067311286926e-01
    z[2,3,3]  R1101     2.8668698668479919e-01
    z[2,3,3]  R1102     -2.9597437381744385e-01
    z[2,3,3]  R1103     -6.3257539272308350e-01
    z[2,3,3]  R1104     -0.566639244556427
    z[2,3,3]  R1105     -6.5333527326583862e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1001     -1
    z[2,3,4]  R1002     1
    z[2,3,4]  R1007     -2.9354941099882126e-02
    z[2,3,4]  R1008     -2.7737346291542053e-01
    z[2,3,4]  R1009     -3.6460742354393005e-02
    z[2,3,4]  R1010     3.5273800604045391e-03
    z[2,3,4]  R1011     -2.1476107835769653e-01
    z[2,3,4]  R1012     -2.2934643551707268e-02
    z[2,3,4]  R1013     -7.9072043299674988e-02
    z[2,3,4]  R1014     -3.5760810971260071e-01
    z[2,3,4]  R1015     -7.7128744125366211e-01
    z[2,3,4]  R1016     -3.8145750761032104e-01
    z[2,3,4]  R1017     7.3071740567684174e-02
    z[2,3,4]  R1018     -1.4902658760547638e-01
    z[2,3,4]  R1019     3.9553143084049225e-02
    z[2,3,4]  R1020     2.0750153809785843e-02
    z[2,3,4]  R1021     2.4105429649353027e-01
    z[2,3,4]  R1022     1.7101193964481354e-01
    z[2,3,4]  R1023     0.0950782373547554
    z[2,3,4]  R1024     -1.0960499197244644e-01
    z[2,3,4]  R1025     1.5725545585155487e-01
    z[2,3,4]  R1026     1.2200789898633957e-01
    z[2,3,4]  R1027     2.8890535235404968e-01
    z[2,3,4]  R1028     4.3241629004478455e-01
    z[2,3,4]  R1029     -6.0956722497940063e-01
    z[2,3,4]  R1030     3.5223352909088135e-01
    z[2,3,4]  R1031     -1.6913086175918579e-01
    z[2,3,4]  R1032     1.9742825627326965e-01
    z[2,3,4]  R1033     0.330597460269928
    z[2,3,4]  R1034     -7.7031159400939941e-01
    z[2,3,4]  R1035     8.4561698138713837e-02
    z[2,3,4]  R1036     3.0646726489067078e-02
    z[2,3,4]  R1037     -2.3091910779476166e-01
    z[2,3,4]  R1038     -1.9820597767829895e-01
    z[2,3,4]  R1039     -0.223605215549469
    z[2,3,4]  R1040     -3.1431868672370911e-01
    z[2,3,4]  R1041     -3.4318295121192932e-01
    z[2,3,4]  R1042     -4.1663515567779541e-01
    z[2,3,4]  R1043     -3.9054206013679504e-01
    z[2,3,4]  R1044     -8.2912124693393707e-02
    z[2,3,4]  R1045     -5.5594122409820557e-01
    z[2,3,4]  R1046     -2.8605180978775024e-01
    z[2,3,4]  R1047     -1.5274184942245483e-01
    z[2,3,4]  R1048     -1.1104546487331390e-01
    z[2,3,4]  R1049     -2.5291544198989868e-01
    z[2,3,4]  R1050     8.7573297321796417e-02
    z[2,3,4]  R1051     0.0885215625166893
    z[2,3,4]  R1052     -1.4982230961322784e-01
    z[2,3,4]  R1053     2.2073255851864815e-02
    z[2,3,4]  R1054     -9.8633743822574615e-02
    z[2,3,4]  R1055     -1.6097214818000793e-01
    z[2,3,4]  R1056     -3.5569289326667786e-01
    z[2,3,4]  R1057     3.1154308468103409e-02
    z[2,3,4]  R1058     -1.8996725976467133e-01
    z[2,3,4]  R1059     7.9639393091201782e-01
    z[2,3,4]  R1060     8.2627013325691223e-03
    z[2,3,4]  R1061     2.2096820175647736e-01
    z[2,3,4]  R1062     3.2409203052520752e-01
    z[2,3,4]  R1063     2.6137617230415344e-01
    z[2,3,4]  R1064     -4.2287570238113403e-01
    z[2,3,4]  R1065     -2.0530524849891663e-01
    z[2,3,4]  R1066     -5.1775805652141571e-02
    z[2,3,4]  R1067     0.721405565738678
    z[2,3,4]  R1068     3.3904662728309631e-01
    z[2,3,4]  R1069     0.536944568157196
    z[2,3,4]  R1070     5.3472465276718140e-01
    z[2,3,4]  R1071     3.1423911452293396e-01
    z[2,3,4]  R1072     3.7826636433601379e-01
    z[2,3,4]  R1073     -1.6794683039188385e-01
    z[2,3,4]  R1074     2.4229032918810844e-02
    z[2,3,4]  R1075     2.3647651076316833e-01
    z[2,3,4]  R1076     5.2013982087373734e-02
    z[2,3,4]  R1077     3.5284776240587234e-02
    z[2,3,4]  R1078     4.6251362562179565e-01
    z[2,3,4]  R1079     3.9560711383819580e-01
    z[2,3,4]  R1080     -1.7187000811100006e-01
    z[2,3,4]  R1081     8.7326399981975555e-02
    z[2,3,4]  R1082     3.7959685921669006e-01
    z[2,3,4]  R1083     2.2575959563255310e-01
    z[2,3,4]  R1084     4.5889419317245483e-01
    z[2,3,4]  R1085     -3.0037787556648254e-01
    z[2,3,4]  R1086     1.6902795433998108e-01
    z[2,3,4]  R1087     4.5079541206359863e-01
    z[2,3,4]  R1088     2.2691859304904938e-01
    z[2,3,4]  R1089     5.3960567712783813e-01
    z[2,3,4]  R1090     1.1950118094682693e-01
    z[2,3,4]  R1091     -0.562481164932251
    z[2,3,4]  R1092     4.0394267439842224e-01
    z[2,3,4]  R1093     -1.9072486320510507e-03
    z[2,3,4]  R1094     0.494154691696167
    z[2,3,4]  R1095     -1.9802886247634888e-01
    z[2,3,4]  R1096     2.0406669378280640e-01
    z[2,3,4]  R1097     3.5650530457496643e-01
    z[2,3,4]  R1098     -3.6467918753623962e-01
    z[2,3,4]  R1099     -8.4266647696495056e-02
    z[2,3,4]  R1100     -4.7175593674182892e-02
    z[2,3,4]  R1101     -1.6847534105181694e-02
    z[2,3,4]  R1102     5.5132389068603516e-01
    z[2,3,4]  R1103     0.340406596660614
    z[2,3,4]  R1104     1.7809723317623138e-01
    z[2,3,4]  R1105     -2.5065923109650612e-02
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1003     -1
    z[2,3,5]  R1004     1
    z[2,3,5]  R1007     3.7134058773517609e-02
    z[2,3,5]  R1008     -4.3836227059364319e-01
    z[2,3,5]  R1009     1.6207601130008698e-01
    z[2,3,5]  R1010     2.8912666440010071e-01
    z[2,3,5]  R1011     1.7371119558811188e-01
    z[2,3,5]  R1012     -2.8155824542045593e-01
    z[2,3,5]  R1013     -3.3294427394866943e-01
    z[2,3,5]  R1014     -3.1217607855796814e-01
    z[2,3,5]  R1015     1.6681528091430664e-01
    z[2,3,5]  R1016     -7.6324068009853363e-02
    z[2,3,5]  R1017     5.9478396177291870e-01
    z[2,3,5]  R1018     1.4739955961704254e-01
    z[2,3,5]  R1019     3.1917652487754822e-01
    z[2,3,5]  R1020     -1.3296452164649963e-01
    z[2,3,5]  R1021     2.2613622248172760e-02
    z[2,3,5]  R1022     -1.2087034434080124e-01
    z[2,3,5]  R1023     -2.4794960021972656e-01
    z[2,3,5]  R1024     -0.0900367721915245
    z[2,3,5]  R1025     -2.2938187420368195e-01
    z[2,3,5]  R1026     -9.6857078373432159e-02
    z[2,3,5]  R1027     -2.5553047657012939e-01
    z[2,3,5]  R1028     2.6781976222991943e-01
    z[2,3,5]  R1029     1.7074239253997803e-01
    z[2,3,5]  R1030     1.9964082539081573e-01
    z[2,3,5]  R1031     -3.0739307403564453e-02
    z[2,3,5]  R1032     -5.4868847131729126e-01
    z[2,3,5]  R1033     1.5081061422824860e-01
    z[2,3,5]  R1034     5.5249845609068871e-03
    z[2,3,5]  R1035     -8.0237448215484619e-02
    z[2,3,5]  R1036     -5.4287576675415039e-01
    z[2,3,5]  R1037     -2.7438384294509888e-01
    z[2,3,5]  R1038     1.9655370712280273e-01
    z[2,3,5]  R1039     9.9414110183715820e-02
    z[2,3,5]  R1040     1.8051995337009430e-01
    z[2,3,5]  R1041     1.2213288247585297e-01
    z[2,3,5]  R1042     -8.3527758717536926e-02
    z[2,3,5]  R1043     -2.8987939003854990e-03
    z[2,3,5]  R1044     -3.8450825214385986e-01
    z[2,3,5]  R1045     -1.7510086297988892e-01
    z[2,3,5]  R1046     0.253398597240448
    z[2,3,5]  R1047     0.00825007539242506
    z[2,3,5]  R1048     4.9329242110252380e-01
    z[2,3,5]  R1049     4.4502985477447510e-01
    z[2,3,5]  R1050     -1.3583134859800339e-02
    z[2,3,5]  R1051     5.4998189210891724e-02
    z[2,3,5]  R1052     2.7247005701065063e-01
    z[2,3,5]  R1053     1.1730955541133881e-01
    z[2,3,5]  R1054     4.0171834826469421e-01
    z[2,3,5]  R1055     3.2744646072387695e-01
    z[2,3,5]  R1056     0.0937584787607193
    z[2,3,5]  R1057     1.3725067675113678e-01
    z[2,3,5]  R1058     3.8609090447425842e-01
    z[2,3,5]  R1059     -4.2861010879278183e-02
    z[2,3,5]  R1060     -2.5508111715316772e-01
    z[2,3,5]  R1061     -4.9958512187004089e-02
    z[2,3,5]  R1062     0.0769592747092247
    z[2,3,5]  R1063     -1.3457165658473969e-01
    z[2,3,5]  R1064     2.4149735271930695e-01
    z[2,3,5]  R1065     1.6522608697414398e-01
    z[2,3,5]  R1066     4.5957455039024353e-01
    z[2,3,5]  R1067     -1.4389362931251526e-01
    z[2,3,5]  R1068     1.6535639762878418e-01
    z[2,3,5]  R1069     3.1621418893337250e-02
    z[2,3,5]  R1070     -1.0094086080789566e-01
    z[2,3,5]  R1071     0.306438684463501
    z[2,3,5]  R1072     4.3003073334693909e-01
    z[2,3,5]  R1073     5.4396629333496094e-01
    z[2,3,5]  R1074     6.4435862004756927e-02
    z[2,3,5]  R1075     3.2721394300460815e-01
    z[2,3,5]  R1076     -2.8444245457649231e-01
    z[2,3,5]  R1077     -5.0231266021728516e-01
    z[2,3,5]  R1078     -6.2959247827529907e-01
    z[2,3,5]  R1079     3.7279227375984192e-01
    z[2,3,5]  R1080     1.6531041264533997e-01
    z[2,3,5]  R1081     -1.9833190739154816e-01
    z[2,3,5]  R1082     -1.8671898543834686e-01
    z[2,3,5]  R1083     2.3983092606067657e-01
    z[2,3,5]  R1084     9.2646442353725433e-02
    z[2,3,5]  R1085     3.4028777480125427e-01
    z[2,3,5]  R1086     4.1649112105369568e-01
    z[2,3,5]  R1087     8.1165522336959839e-02
    z[2,3,5]  R1088     1.4363476634025574e-01
    z[2,3,5]  R1089     1.0789851844310760e-01
    z[2,3,5]  R1090     -2.3141042888164520e-01
    z[2,3,5]  R1091     -1.7139554023742676e-02
    z[2,3,5]  R1092     -0.318229079246521
    z[2,3,5]  R1093     2.6526167988777161e-01
    z[2,3,5]  R1094     -2.1993994712829590e-01
    z[2,3,5]  R1095     1.5587139129638672e-01
    z[2,3,5]  R1096     3.8067254424095154e-01
    z[2,3,5]  R1097     3.0121762305498123e-02
    z[2,3,5]  R1098     5.5897551774978638e-01
    z[2,3,5]  R1099     2.1398428082466125e-01
    z[2,3,5]  R1100     3.8329538702964783e-01
    z[2,3,5]  R1101     2.9617869853973389e-01
    z[2,3,5]  R1102     0.158024862408638
    z[2,3,5]  R1103     -2.8970161080360413e-01
    z[2,3,5]  R1104     3.5380387306213379e-01
    z[2,3,5]  R1105     3.3629050850868225e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1005     -1
    z[2,3,6]  R1006     1
    z[2,3,6]  R1007     6.6858351230621338e-02
    z[2,3,6]  R1008     0.259028822183609
    z[2,3,6]  R1009     1.5027964115142822e-01
    z[2,3,6]  R1010     -5.2211493253707886e-01
    z[2,3,6]  R1011     -5.9342807531356812e-01
    z[2,3,6]  R1012     -2.6496127247810364e-01
    z[2,3,6]  R1013     -1.9309477508068085e-01
    z[2,3,6]  R1014     2.5463435053825378e-01
    z[2,3,6]  R1015     -3.3253121655434370e-03
    z[2,3,6]  R1016     5.3472322225570679e-01
    z[2,3,6]  R1017     2.6953560113906860e-01
    z[2,3,6]  R1018     2.3360078036785126e-01
    z[2,3,6]  R1019     -2.3991394042968750e-01
    z[2,3,6]  R1020     6.4353114366531372e-01
    z[2,3,6]  R1021     5.7192766666412354e-01
    z[2,3,6]  R1022     -2.5998631026595831e-03
    z[2,3,6]  R1023     -1.0083127021789551e-01
    z[2,3,6]  R1024     -4.3489582836627960e-02
    z[2,3,6]  R1025     2.2829528152942657e-01
    z[2,3,6]  R1026     6.7231371998786926e-02
    z[2,3,6]  R1027     2.5963285565376282e-01
    z[2,3,6]  R1028     -1.4824126660823822e-01
    z[2,3,6]  R1029     -1.5896141529083252e-01
    z[2,3,6]  R1030     1.8201065063476562e-01
    z[2,3,6]  R1031     7.2573626041412354e-01
    z[2,3,6]  R1032     4.1801032423973083e-01
    z[2,3,6]  R1033     3.6519128084182739e-01
    z[2,3,6]  R1034     3.3364954590797424e-01
    z[2,3,6]  R1035     1.8068379163742065e-01
    z[2,3,6]  R1036     -1.0695316828787327e-02
    z[2,3,6]  R1037     -9.0920627117156982e-02
    z[2,3,6]  R1038     -1.1257733404636383e-01
    z[2,3,6]  R1039     -1.5459421277046204e-01
    z[2,3,6]  R1040     -3.3619552850723267e-01
    z[2,3,6]  R1041     -7.4777096509933472e-02
    z[2,3,6]  R1042     2.9738730192184448e-01
    z[2,3,6]  R1043     4.5432859659194946e-01
    z[2,3,6]  R1044     3.5045480728149414e-01
    z[2,3,6]  R1045     -0.0526314415037632
    z[2,3,6]  R1046     2.6307487487792969e-01
    z[2,3,6]  R1047     6.2678828835487366e-02
    z[2,3,6]  R1048     -3.8197159767150879e-02
    z[2,3,6]  R1049     9.3276090919971466e-02
    z[2,3,6]  R1050     -2.4080686271190643e-02
    z[2,3,6]  R1051     -1.4493295550346375e-01
    z[2,3,6]  R1052     3.5655535757541656e-02
    z[2,3,6]  R1053     0.0522799976170063
    z[2,3,6]  R1054     3.2310735434293747e-02
    z[2,3,6]  R1055     8.5448555648326874e-02
    z[2,3,6]  R1056     1.2455178052186966e-01
    z[2,3,6]  R1057     1.9001878798007965e-01
    z[2,3,6]  R1058     -5.6835031509399414e-01
    z[2,3,6]  R1059     -3.0935180187225342e-01
    z[2,3,6]  R1060     5.9268784523010254e-01
    z[2,3,6]  R1061     8.0272859334945679e-01
    z[2,3,6]  R1062     -4.1821199655532837e-01
    z[2,3,6]  R1063     5.3628188371658325e-01
    z[2,3,6]  R1064     7.5863644480705261e-02
    z[2,3,6]  R1065     3.7423965334892273e-01
    z[2,3,6]  R1066     7.4497717432677746e-03
    z[2,3,6]  R1067     1.6224814951419830e-01
    z[2,3,6]  R1068     -3.0374118685722351e-01
    z[2,3,6]  R1069     -3.4164834022521973e-01
    z[2,3,6]  R1070     6.2955850362777710e-01
    z[2,3,6]  R1071     3.8678586483001709e-01
    z[2,3,6]  R1072     -1.4108885824680328e-01
    z[2,3,6]  R1073     -2.0895342528820038e-01
    z[2,3,6]  R1074     -1.1328030377626419e-01
    z[2,3,6]  R1075     -0.0601862333714962
    z[2,3,6]  R1076     -2.4160975217819214e-01
    z[2,3,6]  R1077     3.6350575089454651e-01
    z[2,3,6]  R1078     1.0825856775045395e-01
    z[2,3,6]  R1079     -5.4732393473386765e-02
    z[2,3,6]  R1080     3.5946875810623169e-01
    z[2,3,6]  R1081     -2.4727845191955566e-01
    z[2,3,6]  R1082     6.0292577743530273e-01
    z[2,3,6]  R1083     -1.4043906331062317e-01
    z[2,3,6]  R1084     3.4061953425407410e-01
    z[2,3,6]  R1085     -0.281399667263031
    z[2,3,6]  R1086     -5.6827016174793243e-02
    z[2,3,6]  R1087     -3.1062424182891846e-01
    z[2,3,6]  R1088     6.1044901609420776e-01
    z[2,3,6]  R1089     1.9057519733905792e-01
    z[2,3,6]  R1090     6.6493093967437744e-01
    z[2,3,6]  R1091     7.8965082764625549e-02
    z[2,3,6]  R1092     7.5730517506599426e-02
    z[2,3,6]  R1093     1.0132216662168503e-01
    z[2,3,6]  R1094     2.6948660612106323e-01
    z[2,3,6]  R1095     -4.2699408531188965e-01
    z[2,3,6]  R1096     1.2564989924430847e-01
    z[2,3,6]  R1097     1.0915504395961761e-01
    z[2,3,6]  R1098     4.7250889241695404e-02
    z[2,3,6]  R1099     -1.4756020903587341e-01
    z[2,3,6]  R1100     -0.0288847703486681
    z[2,3,6]  R1101     -1.6712214052677155e-01
    z[2,3,6]  R1102     -1.6119672358036041e-01
    z[2,3,6]  R1103     1.5063390135765076e-01
    z[2,3,6]  R1104     1.5044826269149780e-01
    z[2,3,6]  R1105     2.8009437024593353e-02
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1106     -1
    z[3,2,0]  R1107     1
    z[3,2,0]  R1120     3.7067100405693054e-02
    z[3,2,0]  R1121     3.7179496884346008e-01
    z[3,2,0]  R1122     -4.1181966662406921e-01
    z[3,2,0]  R1123     5.1207607984542847e-01
    z[3,2,0]  R1124     -6.3994753360748291e-01
    z[3,2,0]  R1125     -0.316124826669693
    z[3,2,0]  R1126     -4.0294739603996277e-01
    z[3,2,0]  R1127     5.3729891777038574e-01
    z[3,2,0]  R1128     -4.6869885921478271e-01
    z[3,2,0]  R1129     -4.5559534430503845e-01
    z[3,2,0]  R1130     7.8173793852329254e-02
    z[3,2,0]  R1131     -1.7945900559425354e-01
    z[3,2,0]  R1132     -1.2135547585785389e-03
    z[3,2,0]  R1133     -0.0807340145111084
    z[3,2,0]  R1134     -2.4226111173629761e-01
    z[3,2,0]  R1135     -2.3268264532089233e-01
    z[3,2,0]  R1136     -5.3354259580373764e-02
    z[3,2,0]  R1137     -3.0456345528364182e-02
    z[3,2,0]  R1138     -2.2064997255802155e-01
    z[3,2,0]  R1139     -4.6148531138896942e-02
    z[3,2,0]  R1140     6.5666645765304565e-02
    z[3,2,0]  R1141     -1.9799323379993439e-01
    z[3,2,0]  R1142     3.2701876759529114e-01
    z[3,2,0]  R1143     -1.4233329892158508e-01
    z[3,2,0]  R1144     1.9304735586047173e-02
    z[3,2,0]  R1145     -1.5847027301788330e-01
    z[3,2,0]  R1146     5.3673553466796875e-01
    z[3,2,0]  R1147     3.6323402076959610e-02
    z[3,2,0]  R1148     -3.4531587362289429e-01
    z[3,2,0]  R1149     -1.6749443113803864e-01
    z[3,2,0]  R1150     -2.3113049566745758e-01
    z[3,2,0]  R1151     -4.3012022972106934e-02
    z[3,2,0]  R1152     4.8231253027915955e-01
    z[3,2,0]  R1153     2.5550296530127525e-02
    z[3,2,0]  R1154     -2.0028276741504669e-01
    z[3,2,0]  R1155     -4.8691046237945557e-01
    z[3,2,0]  R1156     -1.2682755291461945e-01
    z[3,2,0]  R1157     2.6874890923500061e-01
    z[3,2,0]  R1158     1.3006573915481567e-01
    z[3,2,0]  R1159     3.6033737659454346e-01
    z[3,2,0]  R1160     5.9692794084548950e-01
    z[3,2,0]  R1161     3.9397379755973816e-01
    z[3,2,0]  R1162     -1.7629776895046234e-01
    z[3,2,0]  R1163     1.2649475038051605e-01
    z[3,2,0]  R1164     5.8065932244062424e-02
    z[3,2,0]  R1165     -2.4579444527626038e-01
    z[3,2,0]  R1166     6.5198093652725220e-02
    z[3,2,0]  R1167     5.4943734407424927e-01
    z[3,2,0]  R1168     -1.5163809061050415e-01
    z[3,2,0]  R1169     -2.2004279494285583e-01
    z[3,2,0]  R1170     -1.1727644503116608e-01
    z[3,2,0]  R1171     1.9039590656757355e-01
    z[3,2,0]  R1172     2.9173459857702255e-02
    z[3,2,0]  R1173     -5.5233038961887360e-02
    z[3,2,0]  R1174     -1.4811183512210846e-01
    z[3,2,0]  R1175     9.3578584492206573e-02
    z[3,2,0]  R1176     -9.8985306918621063e-02
    z[3,2,0]  R1177     -1.3010847568511963e-01
    z[3,2,0]  R1178     1.1820724606513977e-01
    z[3,2,0]  R1179     -2.2255496680736542e-01
    z[3,2,0]  R1180     -1.2191570550203323e-01
    z[3,2,0]  R1181     -3.0332719907164574e-02
    z[3,2,0]  R1182     -8.1705629825592041e-02
    z[3,2,0]  R1183     -3.3933378756046295e-02
    z[3,2,0]  R1184     4.9755383282899857e-02
    z[3,2,0]  R1185     1.3494296371936798e-01
    z[3,2,0]  R1186     0.0110483942553401
    z[3,2,0]  R1187     1.4044113457202911e-01
    z[3,2,0]  R1188     0.590168297290802
    z[3,2,0]  R1189     -5.8756476640701294e-01
    z[3,2,0]  R1190     -7.9760897159576416e-01
    z[3,2,0]  R1191     -5.8294034004211426e-01
    z[3,2,0]  R1192     -6.3656675815582275e-01
    z[3,2,0]  R1193     0.000665637431666255
    z[3,2,0]  R1194     3.4158188104629517e-01
    z[3,2,0]  R1195     3.1974050402641296e-01
    z[3,2,0]  R1196     3.4665313363075256e-01
    z[3,2,0]  R1197     1.9608055055141449e-01
    z[3,2,0]  R1198     6.2233191728591919e-01
    z[3,2,0]  R1199     1.2805898487567902e-01
    z[3,2,0]  R1200     2.9837599396705627e-01
    z[3,2,0]  R1201     5.3156417608261108e-01
    z[3,2,0]  R1202     3.4490948915481567e-01
    z[3,2,0]  R1203     5.7030439376831055e-01
    z[3,2,0]  R1204     9.3179166316986084e-01
    z[3,2,0]  R1205     8.4341913461685181e-01
    z[3,2,0]  R1206     8.8378113508224487e-01
    z[3,2,0]  R1207     8.3961808681488037e-01
    z[3,2,0]  R1208     8.8593792915344238e-01
    z[3,2,0]  R1209     1.4354000985622406e-01
    z[3,2,0]  R1210     0.34108966588974
    z[3,2,0]  R1211     1.1674237251281738e-01
    z[3,2,0]  R1212     1.1136688292026520e-01
    z[3,2,0]  R1213     4.5378932356834412e-01
    z[3,2,0]  R1214     4.1349762678146362e-01
    z[3,2,0]  R1215     6.7828559875488281e-01
    z[3,2,0]  R1216     4.8787105083465576e-01
    z[3,2,0]  R1217     3.5431259870529175e-01
    z[3,2,0]  R1218     8.2129406929016113e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1108     -1
    z[3,2,1]  R1109     1
    z[3,2,1]  R1120     6.9367986917495728e-01
    z[3,2,1]  R1121     6.6264796257019043e-01
    z[3,2,1]  R1122     -4.9712666869163513e-01
    z[3,2,1]  R1123     4.0542349219322205e-01
    z[3,2,1]  R1124     -0.443347305059433
    z[3,2,1]  R1125     -5.1285165548324585e-01
    z[3,2,1]  R1126     -0.450613796710968
    z[3,2,1]  R1127     6.5254640579223633e-01
    z[3,2,1]  R1128     -6.2381881475448608e-01
    z[3,2,1]  R1129     7.0405995845794678e-01
    z[3,2,1]  R1130     -9.6634417772293091e-01
    z[3,2,1]  R1131     -8.2638806104660034e-01
    z[3,2,1]  R1132     -8.3274024724960327e-01
    z[3,2,1]  R1133     -9.4393610954284668e-01
    z[3,2,1]  R1134     -8.9501363039016724e-01
    z[3,2,1]  R1135     -8.5856539011001587e-01
    z[3,2,1]  R1136     -9.3438696861267090e-01
    z[3,2,1]  R1137     -8.9354443550109863e-01
    z[3,2,1]  R1138     -8.9741677045822144e-01
    z[3,2,1]  R1139     -8.6780643463134766e-01
    z[3,2,1]  R1140     9.0192121267318726e-01
    z[3,2,1]  R1141     0.6239013671875
    z[3,2,1]  R1142     3.4472694993019104e-01
    z[3,2,1]  R1143     0.70050448179245
    z[3,2,1]  R1144     4.5671561360359192e-01
    z[3,2,1]  R1145     0.627260684967041
    z[3,2,1]  R1146     7.8109733294695616e-04
    z[3,2,1]  R1147     -7.5922125577926636e-01
    z[3,2,1]  R1148     -0.715255618095398
    z[3,2,1]  R1149     -5.2114403247833252e-01
    z[3,2,1]  R1150     7.6005853712558746e-02
    z[3,2,1]  R1151     0.802408754825592
    z[3,2,1]  R1152     -0.0430334135890007
    z[3,2,1]  R1153     4.5041911303997040e-02
    z[3,2,1]  R1154     3.0691778659820557e-01
    z[3,2,1]  R1155     2.6438814401626587e-01
    z[3,2,1]  R1156     -5.6059908866882324e-01
    z[3,2,1]  R1157     -6.6544133424758911e-01
    z[3,2,1]  R1158     -6.2691295146942139e-01
    z[3,2,1]  R1159     -6.3844412565231323e-01
    z[3,2,1]  R1160     1.4414748549461365e-01
    z[3,2,1]  R1161     3.5924646258354187e-01
    z[3,2,1]  R1162     4.2892915010452271e-01
    z[3,2,1]  R1163     7.6178300380706787e-01
    z[3,2,1]  R1164     8.5596400499343872e-01
    z[3,2,1]  R1165     5.7058918476104736e-01
    z[3,2,1]  R1166     0.0888204276561737
    z[3,2,1]  R1167     0.0500313900411129
    z[3,2,1]  R1168     -7.8557604551315308e-01
    z[3,2,1]  R1169     -6.9789052009582520e-01
    z[3,2,1]  R1170     5.8851748704910278e-01
    z[3,2,1]  R1171     3.6812219023704529e-01
    z[3,2,1]  R1172     7.0105659961700439e-01
    z[3,2,1]  R1173     6.9236093759536743e-01
    z[3,2,1]  R1174     7.4410974979400635e-01
    z[3,2,1]  R1175     -7.9978233575820923e-01
    z[3,2,1]  R1176     -6.6857415437698364e-01
    z[3,2,1]  R1177     -7.6604461669921875e-01
    z[3,2,1]  R1178     -8.1263101100921631e-01
    z[3,2,1]  R1179     2.2216621041297913e-01
    z[3,2,1]  R1180     8.7879288196563721e-01
    z[3,2,1]  R1181     6.9568967819213867e-01
    z[3,2,1]  R1182     -7.6769274473190308e-01
    z[3,2,1]  R1183     -0.793660581111908
    z[3,2,1]  R1184     -8.9406061172485352e-01
    z[3,2,1]  R1185     -0.69505375623703
    z[3,2,1]  R1186     -6.0580420494079590e-01
    z[3,2,1]  R1187     -4.4465139508247375e-03
    z[3,2,1]  R1188     1.0688560083508492e-02
    z[3,2,1]  R1189     -3.0761319398880005e-01
    z[3,2,1]  R1190     -2.1458260715007782e-02
    z[3,2,1]  R1191     -1.5686792135238647e-01
    z[3,2,1]  R1192     -1.1779581010341644e-01
    z[3,2,1]  R1193     -6.7735219001770020e-01
    z[3,2,1]  R1194     0.693505585193634
    z[3,2,1]  R1195     5.1017683744430542e-01
    z[3,2,1]  R1196     0.678641140460968
    z[3,2,1]  R1197     4.3037557601928711e-01
    z[3,2,1]  R1198     -9.2120125889778137e-02
    z[3,2,1]  R1199     7.4141013622283936e-01
    z[3,2,1]  R1200     7.4333906173706055e-01
    z[3,2,1]  R1201     6.6982412338256836e-01
    z[3,2,1]  R1202     -5.7433068752288818e-01
    z[3,2,1]  R1203     -4.5757806301116943e-01
    z[3,2,1]  R1204     4.9543965607881546e-02
    z[3,2,1]  R1205     2.1142403781414032e-01
    z[3,2,1]  R1206     1.2041904032230377e-01
    z[3,2,1]  R1207     1.6735802590847015e-01
    z[3,2,1]  R1208     3.4211522340774536e-01
    z[3,2,1]  R1209     8.5066372156143188e-01
    z[3,2,1]  R1210     6.7517876625061035e-01
    z[3,2,1]  R1211     7.0113706588745117e-01
    z[3,2,1]  R1212     0.666340172290802
    z[3,2,1]  R1213     -4.4583463668823242e-01
    z[3,2,1]  R1214     -5.0902652740478516e-01
    z[3,2,1]  R1215     -4.3175652623176575e-01
    z[3,2,1]  R1216     -1.7618516087532043e-01
    z[3,2,1]  R1217     -5.4970139265060425e-01
    z[3,2,1]  R1218     -6.8831346929073334e-02
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1110     -1
    z[3,2,2]  R1111     1
    z[3,2,2]  R1120     3.7445166707038879e-01
    z[3,2,2]  R1121     -2.4146245419979095e-01
    z[3,2,2]  R1122     -6.5644830465316772e-01
    z[3,2,2]  R1123     -1.2594206631183624e-01
    z[3,2,2]  R1124     -5.0185889005661011e-01
    z[3,2,2]  R1125     -3.9556607604026794e-01
    z[3,2,2]  R1126     -4.8620283603668213e-01
    z[3,2,2]  R1127     -5.1303360611200333e-02
    z[3,2,2]  R1128     -1.8828479945659637e-01
    z[3,2,2]  R1129     -1.8435798585414886e-01
    z[3,2,2]  R1130     1.3297490775585175e-01
    z[3,2,2]  R1131     -1.6308559570461512e-03
    z[3,2,2]  R1132     -7.8419208526611328e-02
    z[3,2,2]  R1133     1.8751381337642670e-01
    z[3,2,2]  R1134     1.4740787446498871e-01
    z[3,2,2]  R1135     3.0041760206222534e-01
    z[3,2,2]  R1136     3.2278785109519958e-01
    z[3,2,2]  R1137     1.4655736088752747e-01
    z[3,2,2]  R1138     -4.4597167521715164e-02
    z[3,2,2]  R1139     2.1245136857032776e-01
    z[3,2,2]  R1140     -1.2600612640380859e-01
    z[3,2,2]  R1141     -2.3675315082073212e-01
    z[3,2,2]  R1142     -1.9854129850864410e-01
    z[3,2,2]  R1143     -8.3444461226463318e-02
    z[3,2,2]  R1144     -2.7143913507461548e-01
    z[3,2,2]  R1145     -2.6291960477828979e-01
    z[3,2,2]  R1146     -0.0666758269071579
    z[3,2,2]  R1147     -1.8733938038349152e-01
    z[3,2,2]  R1148     -0.0946456640958786
    z[3,2,2]  R1149     -1.4219684898853302e-01
    z[3,2,2]  R1150     2.4438938498497009e-01
    z[3,2,2]  R1151     -3.3602195978164673e-01
    z[3,2,2]  R1152     -5.1875356584787369e-03
    z[3,2,2]  R1153     2.1833754144608974e-03
    z[3,2,2]  R1154     -2.4139027297496796e-01
    z[3,2,2]  R1155     -1.5233443677425385e-01
    z[3,2,2]  R1156     -4.3736910820007324e-01
    z[3,2,2]  R1157     -2.3348213732242584e-01
    z[3,2,2]  R1158     -4.5843631029129028e-01
    z[3,2,2]  R1159     1.5957817435264587e-01
    z[3,2,2]  R1160     2.9598847031593323e-01
    z[3,2,2]  R1161     2.7041327953338623e-01
    z[3,2,2]  R1162     -2.4659752845764160e-01
    z[3,2,2]  R1163     -4.6603524684906006e-01
    z[3,2,2]  R1164     -0.0762200802564621
    z[3,2,2]  R1165     2.4485167115926743e-02
    z[3,2,2]  R1166     2.6378279551863670e-02
    z[3,2,2]  R1167     -3.3334141969680786e-01
    z[3,2,2]  R1168     -9.0231351554393768e-02
    z[3,2,2]  R1169     -3.5453933477401733e-01
    z[3,2,2]  R1170     4.3191414326429367e-02
    z[3,2,2]  R1171     -0.341232031583786
    z[3,2,2]  R1172     -4.0100088715553284e-01
    z[3,2,2]  R1173     -7.8620567917823792e-02
    z[3,2,2]  R1174     -1.0464297980070114e-01
    z[3,2,2]  R1175     -2.4717628955841064e-01
    z[3,2,2]  R1176     -3.3976930379867554e-01
    z[3,2,2]  R1177     -1.2700571119785309e-01
    z[3,2,2]  R1178     1.9309714436531067e-01
    z[3,2,2]  R1179     7.5070065259933472e-01
    z[3,2,2]  R1180     -2.0854748785495758e-01
    z[3,2,2]  R1181     2.2803038358688354e-01
    z[3,2,2]  R1182     -1.6927412152290344e-01
    z[3,2,2]  R1183     -3.2806521654129028e-01
    z[3,2,2]  R1184     7.4264849536120892e-03
    z[3,2,2]  R1185     -2.3701396584510803e-01
    z[3,2,2]  R1186     1.0115970671176910e-01
    z[3,2,2]  R1187     0.692564845085144
    z[3,2,2]  R1188     3.3201807737350464e-01
    z[3,2,2]  R1189     2.5536981225013733e-01
    z[3,2,2]  R1190     -8.0873884260654449e-02
    z[3,2,2]  R1191     -7.4643611907958984e-01
    z[3,2,2]  R1192     2.6601186394691467e-01
    z[3,2,2]  R1193     -3.3538267016410828e-01
    z[3,2,2]  R1194     3.3730635046958923e-01
    z[3,2,2]  R1195     -5.7383030652999878e-01
    z[3,2,2]  R1196     2.3722781240940094e-01
    z[3,2,2]  R1197     -1.4183494448661804e-01
    z[3,2,2]  R1198     -3.5477694869041443e-01
    z[3,2,2]  R1199     -3.4747142344713211e-02
    z[3,2,2]  R1200     4.0809872746467590e-01
    z[3,2,2]  R1201     -1.4974361658096313e-01
    z[3,2,2]  R1202     1.4509527385234833e-01
    z[3,2,2]  R1203     2.3709741234779358e-01
    z[3,2,2]  R1204     3.8914494216442108e-02
    z[3,2,2]  R1205     8.1839226186275482e-02
    z[3,2,2]  R1206     2.6590687036514282e-01
    z[3,2,2]  R1207     1.2773790955543518e-01
    z[3,2,2]  R1208     2.6197027415037155e-02
    z[3,2,2]  R1209     -1.7921912670135498e-01
    z[3,2,2]  R1210     -3.5935276746749878e-01
    z[3,2,2]  R1211     2.6201415061950684e-01
    z[3,2,2]  R1212     5.6552481651306152e-01
    z[3,2,2]  R1213     -1.4974561333656311e-01
    z[3,2,2]  R1214     -2.2675932943820953e-01
    z[3,2,2]  R1215     -4.1336383670568466e-02
    z[3,2,2]  R1216     1.3642235100269318e-01
    z[3,2,2]  R1217     6.8221598863601685e-01
    z[3,2,2]  R1218     -7.2196260094642639e-02
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1112     -1
    z[3,2,3]  R1113     1
    z[3,2,3]  R1120     4.9024832248687744e-01
    z[3,2,3]  R1121     5.2322983741760254e-01
    z[3,2,3]  R1122     -2.6184621453285217e-01
    z[3,2,3]  R1123     5.5958682298660278e-01
    z[3,2,3]  R1124     6.1362501233816147e-02
    z[3,2,3]  R1125     -4.5997259020805359e-01
    z[3,2,3]  R1126     -1.9809435307979584e-01
    z[3,2,3]  R1127     -0.0729481503367424
    z[3,2,3]  R1128     -1.1497498303651810e-01
    z[3,2,3]  R1129     2.1794460713863373e-01
    z[3,2,3]  R1130     -1.2271368503570557e-01
    z[3,2,3]  R1131     -1.6657491028308868e-01
    z[3,2,3]  R1132     -1.7226240038871765e-01
    z[3,2,3]  R1133     -2.4263501167297363e-01
    z[3,2,3]  R1134     -2.9438859224319458e-01
    z[3,2,3]  R1135     -1.4323222637176514e-01
    z[3,2,3]  R1136     5.3854927420616150e-02
    z[3,2,3]  R1137     8.3793297410011292e-02
    z[3,2,3]  R1138     5.9439826756715775e-02
    z[3,2,3]  R1139     2.2096496820449829e-01
    z[3,2,3]  R1140     -3.3231475949287415e-01
    z[3,2,3]  R1141     8.5544362664222717e-02
    z[3,2,3]  R1142     5.4995030164718628e-02
    z[3,2,3]  R1143     -2.5623863935470581e-01
    z[3,2,3]  R1144     1.4718367159366608e-01
    z[3,2,3]  R1145     -4.7586208581924438e-01
    z[3,2,3]  R1146     5.7744556665420532e-01
    z[3,2,3]  R1147     -3.7982547283172607e-01
    z[3,2,3]  R1148     -3.8820537924766541e-01
    z[3,2,3]  R1149     -6.8278080224990845e-01
    z[3,2,3]  R1150     5.6001764535903931e-01
    z[3,2,3]  R1151     -8.2615956664085388e-02
    z[3,2,3]  R1152     5.9955221414566040e-01
    z[3,2,3]  R1153     5.5213242769241333e-01
    z[3,2,3]  R1154     6.8202984333038330e-01
    z[3,2,3]  R1155     0.567356526851654
    z[3,2,3]  R1156     -3.3254262804985046e-01
    z[3,2,3]  R1157     -6.4255464076995850e-01
    z[3,2,3]  R1158     -4.6182984113693237e-01
    z[3,2,3]  R1159     -5.4322427511215210e-01
    z[3,2,3]  R1160     3.8676840066909790e-01
    z[3,2,3]  R1161     -1.4344982802867889e-01
    z[3,2,3]  R1162     6.5242147445678711e-01
    z[3,2,3]  R1163     -2.0302671939134598e-02
    z[3,2,3]  R1164     -3.8734534382820129e-01
    z[3,2,3]  R1165     2.6633885502815247e-01
    z[3,2,3]  R1166     9.2679816484451294e-01
    z[3,2,3]  R1167     4.9930948019027710e-01
    z[3,2,3]  R1168     -2.5792637467384338e-01
    z[3,2,3]  R1169     -3.6546853184700012e-01
    z[3,2,3]  R1170     5.7596552371978760e-01
    z[3,2,3]  R1171     5.1674467325210571e-01
    z[3,2,3]  R1172     8.7929308414459229e-02
    z[3,2,3]  R1173     3.7946559488773346e-02
    z[3,2,3]  R1174     -3.0083081126213074e-01
    z[3,2,3]  R1175     -1.4255067706108093e-01
    z[3,2,3]  R1176     -5.8918052911758423e-01
    z[3,2,3]  R1177     -1.2219463288784027e-01
    z[3,2,3]  R1178     2.0624296367168427e-01
    z[3,2,3]  R1179     -3.6771920323371887e-01
    z[3,2,3]  R1180     1.7160816490650177e-01
    z[3,2,3]  R1181     -1.2418014556169510e-01
    z[3,2,3]  R1182     -5.4831933975219727e-01
    z[3,2,3]  R1183     -3.3369067311286926e-01
    z[3,2,3]  R1184     2.8668698668479919e-01
    z[3,2,3]  R1185     -2.9597437381744385e-01
    z[3,2,3]  R1186     -6.3257539272308350e-01
    z[3,2,3]  R1187     -0.566639244556427
    z[3,2,3]  R1188     -6.5333527326583862e-01
    z[3,2,3]  R1189     6.9872546195983887e-01
    z[3,2,3]  R1190     -1.4361524581909180e-01
    z[3,2,3]  R1191     -1.6800025105476379e-01
    z[3,2,3]  R1192     -3.9234411716461182e-01
    z[3,2,3]  R1193     -1.6036370769143105e-02
    z[3,2,3]  R1194     3.7227776646614075e-01
    z[3,2,3]  R1195     3.9219167828559875e-01
    z[3,2,3]  R1196     2.6986068487167358e-01
    z[3,2,3]  R1197     3.6536210775375366e-01
    z[3,2,3]  R1198     2.0269700884819031e-01
    z[3,2,3]  R1199     -3.0786329880356789e-02
    z[3,2,3]  R1200     -3.0556395649909973e-01
    z[3,2,3]  R1201     -2.9215618968009949e-01
    z[3,2,3]  R1202     -3.1286829710006714e-01
    z[3,2,3]  R1203     1.5310217440128326e-01
    z[3,2,3]  R1204     -2.8971329331398010e-01
    z[3,2,3]  R1205     -3.9567741751670837e-01
    z[3,2,3]  R1206     -3.3423423767089844e-01
    z[3,2,3]  R1207     -3.4821224212646484e-01
    z[3,2,3]  R1208     -2.6191130280494690e-01
    z[3,2,3]  R1209     8.6467579007148743e-02
    z[3,2,3]  R1210     1.3405305147171021e-01
    z[3,2,3]  R1211     1.1523726396262646e-02
    z[3,2,3]  R1212     1.6345396637916565e-01
    z[3,2,3]  R1213     1.2899482250213623e-01
    z[3,2,3]  R1214     6.1010837554931641e-02
    z[3,2,3]  R1215     2.9394409060478210e-01
    z[3,2,3]  R1216     0.0871608629822731
    z[3,2,3]  R1217     -2.4624569714069366e-01
    z[3,2,3]  R1218     -1.4056387543678284e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1114     -1
    z[3,2,4]  R1115     1
    z[3,2,4]  R1120     -2.3091910779476166e-01
    z[3,2,4]  R1121     -1.9820597767829895e-01
    z[3,2,4]  R1122     -0.223605215549469
    z[3,2,4]  R1123     -3.1431868672370911e-01
    z[3,2,4]  R1124     -3.4318295121192932e-01
    z[3,2,4]  R1125     -4.1663515567779541e-01
    z[3,2,4]  R1126     -3.9054206013679504e-01
    z[3,2,4]  R1127     -8.2912124693393707e-02
    z[3,2,4]  R1128     -5.5594122409820557e-01
    z[3,2,4]  R1129     -2.8605180978775024e-01
    z[3,2,4]  R1130     -1.5274184942245483e-01
    z[3,2,4]  R1131     -1.1104546487331390e-01
    z[3,2,4]  R1132     -2.5291544198989868e-01
    z[3,2,4]  R1133     8.7573297321796417e-02
    z[3,2,4]  R1134     0.0885215625166893
    z[3,2,4]  R1135     -1.4982230961322784e-01
    z[3,2,4]  R1136     2.2073255851864815e-02
    z[3,2,4]  R1137     -9.8633743822574615e-02
    z[3,2,4]  R1138     -1.6097214818000793e-01
    z[3,2,4]  R1139     -3.5569289326667786e-01
    z[3,2,4]  R1140     3.1154308468103409e-02
    z[3,2,4]  R1141     -1.8996725976467133e-01
    z[3,2,4]  R1142     7.9639393091201782e-01
    z[3,2,4]  R1143     8.2627013325691223e-03
    z[3,2,4]  R1144     2.2096820175647736e-01
    z[3,2,4]  R1145     3.2409203052520752e-01
    z[3,2,4]  R1146     2.6137617230415344e-01
    z[3,2,4]  R1147     -4.2287570238113403e-01
    z[3,2,4]  R1148     -2.0530524849891663e-01
    z[3,2,4]  R1149     -5.1775805652141571e-02
    z[3,2,4]  R1150     0.721405565738678
    z[3,2,4]  R1151     3.3904662728309631e-01
    z[3,2,4]  R1152     0.536944568157196
    z[3,2,4]  R1153     5.3472465276718140e-01
    z[3,2,4]  R1154     3.1423911452293396e-01
    z[3,2,4]  R1155     3.7826636433601379e-01
    z[3,2,4]  R1156     -1.6794683039188385e-01
    z[3,2,4]  R1157     2.4229032918810844e-02
    z[3,2,4]  R1158     2.3647651076316833e-01
    z[3,2,4]  R1159     5.2013982087373734e-02
    z[3,2,4]  R1160     3.5284776240587234e-02
    z[3,2,4]  R1161     4.6251362562179565e-01
    z[3,2,4]  R1162     3.9560711383819580e-01
    z[3,2,4]  R1163     -1.7187000811100006e-01
    z[3,2,4]  R1164     8.7326399981975555e-02
    z[3,2,4]  R1165     3.7959685921669006e-01
    z[3,2,4]  R1166     2.2575959563255310e-01
    z[3,2,4]  R1167     4.5889419317245483e-01
    z[3,2,4]  R1168     -3.0037787556648254e-01
    z[3,2,4]  R1169     1.6902795433998108e-01
    z[3,2,4]  R1170     4.5079541206359863e-01
    z[3,2,4]  R1171     2.2691859304904938e-01
    z[3,2,4]  R1172     5.3960567712783813e-01
    z[3,2,4]  R1173     1.1950118094682693e-01
    z[3,2,4]  R1174     -0.562481164932251
    z[3,2,4]  R1175     4.0394267439842224e-01
    z[3,2,4]  R1176     -1.9072486320510507e-03
    z[3,2,4]  R1177     0.494154691696167
    z[3,2,4]  R1178     -1.9802886247634888e-01
    z[3,2,4]  R1179     2.0406669378280640e-01
    z[3,2,4]  R1180     3.5650530457496643e-01
    z[3,2,4]  R1181     -3.6467918753623962e-01
    z[3,2,4]  R1182     -8.4266647696495056e-02
    z[3,2,4]  R1183     -4.7175593674182892e-02
    z[3,2,4]  R1184     -1.6847534105181694e-02
    z[3,2,4]  R1185     5.5132389068603516e-01
    z[3,2,4]  R1186     0.340406596660614
    z[3,2,4]  R1187     1.7809723317623138e-01
    z[3,2,4]  R1188     -2.5065923109650612e-02
    z[3,2,4]  R1189     -2.9354941099882126e-02
    z[3,2,4]  R1190     -2.7737346291542053e-01
    z[3,2,4]  R1191     -3.6460742354393005e-02
    z[3,2,4]  R1192     3.5273800604045391e-03
    z[3,2,4]  R1193     -2.1476107835769653e-01
    z[3,2,4]  R1194     -2.2934643551707268e-02
    z[3,2,4]  R1195     -7.9072043299674988e-02
    z[3,2,4]  R1196     -3.5760810971260071e-01
    z[3,2,4]  R1197     -7.7128744125366211e-01
    z[3,2,4]  R1198     -3.8145750761032104e-01
    z[3,2,4]  R1199     7.3071740567684174e-02
    z[3,2,4]  R1200     -1.4902658760547638e-01
    z[3,2,4]  R1201     3.9553143084049225e-02
    z[3,2,4]  R1202     2.0750153809785843e-02
    z[3,2,4]  R1203     2.4105429649353027e-01
    z[3,2,4]  R1204     1.7101193964481354e-01
    z[3,2,4]  R1205     0.0950782373547554
    z[3,2,4]  R1206     -1.0960499197244644e-01
    z[3,2,4]  R1207     1.5725545585155487e-01
    z[3,2,4]  R1208     1.2200789898633957e-01
    z[3,2,4]  R1209     2.8890535235404968e-01
    z[3,2,4]  R1210     4.3241629004478455e-01
    z[3,2,4]  R1211     -6.0956722497940063e-01
    z[3,2,4]  R1212     3.5223352909088135e-01
    z[3,2,4]  R1213     -1.6913086175918579e-01
    z[3,2,4]  R1214     1.9742825627326965e-01
    z[3,2,4]  R1215     0.330597460269928
    z[3,2,4]  R1216     -7.7031159400939941e-01
    z[3,2,4]  R1217     8.4561698138713837e-02
    z[3,2,4]  R1218     3.0646726489067078e-02
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1116     -1
    z[3,2,5]  R1117     1
    z[3,2,5]  R1120     -2.7438384294509888e-01
    z[3,2,5]  R1121     1.9655370712280273e-01
    z[3,2,5]  R1122     9.9414110183715820e-02
    z[3,2,5]  R1123     1.8051995337009430e-01
    z[3,2,5]  R1124     1.2213288247585297e-01
    z[3,2,5]  R1125     -8.3527758717536926e-02
    z[3,2,5]  R1126     -2.8987939003854990e-03
    z[3,2,5]  R1127     -3.8450825214385986e-01
    z[3,2,5]  R1128     -1.7510086297988892e-01
    z[3,2,5]  R1129     0.253398597240448
    z[3,2,5]  R1130     0.00825007539242506
    z[3,2,5]  R1131     4.9329242110252380e-01
    z[3,2,5]  R1132     4.4502985477447510e-01
    z[3,2,5]  R1133     -1.3583134859800339e-02
    z[3,2,5]  R1134     5.4998189210891724e-02
    z[3,2,5]  R1135     2.7247005701065063e-01
    z[3,2,5]  R1136     1.1730955541133881e-01
    z[3,2,5]  R1137     4.0171834826469421e-01
    z[3,2,5]  R1138     3.2744646072387695e-01
    z[3,2,5]  R1139     0.0937584787607193
    z[3,2,5]  R1140     1.3725067675113678e-01
    z[3,2,5]  R1141     3.8609090447425842e-01
    z[3,2,5]  R1142     -4.2861010879278183e-02
    z[3,2,5]  R1143     -2.5508111715316772e-01
    z[3,2,5]  R1144     -4.9958512187004089e-02
    z[3,2,5]  R1145     0.0769592747092247
    z[3,2,5]  R1146     -1.3457165658473969e-01
    z[3,2,5]  R1147     2.4149735271930695e-01
    z[3,2,5]  R1148     1.6522608697414398e-01
    z[3,2,5]  R1149     4.5957455039024353e-01
    z[3,2,5]  R1150     -1.4389362931251526e-01
    z[3,2,5]  R1151     1.6535639762878418e-01
    z[3,2,5]  R1152     3.1621418893337250e-02
    z[3,2,5]  R1153     -1.0094086080789566e-01
    z[3,2,5]  R1154     0.306438684463501
    z[3,2,5]  R1155     4.3003073334693909e-01
    z[3,2,5]  R1156     5.4396629333496094e-01
    z[3,2,5]  R1157     6.4435862004756927e-02
    z[3,2,5]  R1158     3.2721394300460815e-01
    z[3,2,5]  R1159     -2.8444245457649231e-01
    z[3,2,5]  R1160     -5.0231266021728516e-01
    z[3,2,5]  R1161     -6.2959247827529907e-01
    z[3,2,5]  R1162     3.7279227375984192e-01
    z[3,2,5]  R1163     1.6531041264533997e-01
    z[3,2,5]  R1164     -1.9833190739154816e-01
    z[3,2,5]  R1165     -1.8671898543834686e-01
    z[3,2,5]  R1166     2.3983092606067657e-01
    z[3,2,5]  R1167     9.2646442353725433e-02
    z[3,2,5]  R1168     3.4028777480125427e-01
    z[3,2,5]  R1169     4.1649112105369568e-01
    z[3,2,5]  R1170     8.1165522336959839e-02
    z[3,2,5]  R1171     1.4363476634025574e-01
    z[3,2,5]  R1172     1.0789851844310760e-01
    z[3,2,5]  R1173     -2.3141042888164520e-01
    z[3,2,5]  R1174     -1.7139554023742676e-02
    z[3,2,5]  R1175     -0.318229079246521
    z[3,2,5]  R1176     2.6526167988777161e-01
    z[3,2,5]  R1177     -2.1993994712829590e-01
    z[3,2,5]  R1178     1.5587139129638672e-01
    z[3,2,5]  R1179     3.8067254424095154e-01
    z[3,2,5]  R1180     3.0121762305498123e-02
    z[3,2,5]  R1181     5.5897551774978638e-01
    z[3,2,5]  R1182     2.1398428082466125e-01
    z[3,2,5]  R1183     3.8329538702964783e-01
    z[3,2,5]  R1184     2.9617869853973389e-01
    z[3,2,5]  R1185     0.158024862408638
    z[3,2,5]  R1186     -2.8970161080360413e-01
    z[3,2,5]  R1187     3.5380387306213379e-01
    z[3,2,5]  R1188     3.3629050850868225e-01
    z[3,2,5]  R1189     3.7134058773517609e-02
    z[3,2,5]  R1190     -4.3836227059364319e-01
    z[3,2,5]  R1191     1.6207601130008698e-01
    z[3,2,5]  R1192     2.8912666440010071e-01
    z[3,2,5]  R1193     1.7371119558811188e-01
    z[3,2,5]  R1194     -2.8155824542045593e-01
    z[3,2,5]  R1195     -3.3294427394866943e-01
    z[3,2,5]  R1196     -3.1217607855796814e-01
    z[3,2,5]  R1197     1.6681528091430664e-01
    z[3,2,5]  R1198     -7.6324068009853363e-02
    z[3,2,5]  R1199     5.9478396177291870e-01
    z[3,2,5]  R1200     1.4739955961704254e-01
    z[3,2,5]  R1201     3.1917652487754822e-01
    z[3,2,5]  R1202     -1.3296452164649963e-01
    z[3,2,5]  R1203     2.2613622248172760e-02
    z[3,2,5]  R1204     -1.2087034434080124e-01
    z[3,2,5]  R1205     -2.4794960021972656e-01
    z[3,2,5]  R1206     -0.0900367721915245
    z[3,2,5]  R1207     -2.2938187420368195e-01
    z[3,2,5]  R1208     -9.6857078373432159e-02
    z[3,2,5]  R1209     -2.5553047657012939e-01
    z[3,2,5]  R1210     2.6781976222991943e-01
    z[3,2,5]  R1211     1.7074239253997803e-01
    z[3,2,5]  R1212     1.9964082539081573e-01
    z[3,2,5]  R1213     -3.0739307403564453e-02
    z[3,2,5]  R1214     -5.4868847131729126e-01
    z[3,2,5]  R1215     1.5081061422824860e-01
    z[3,2,5]  R1216     5.5249845609068871e-03
    z[3,2,5]  R1217     -8.0237448215484619e-02
    z[3,2,5]  R1218     -5.4287576675415039e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1118     -1
    z[3,2,6]  R1119     1
    z[3,2,6]  R1120     -9.0920627117156982e-02
    z[3,2,6]  R1121     -1.1257733404636383e-01
    z[3,2,6]  R1122     -1.5459421277046204e-01
    z[3,2,6]  R1123     -3.3619552850723267e-01
    z[3,2,6]  R1124     -7.4777096509933472e-02
    z[3,2,6]  R1125     2.9738730192184448e-01
    z[3,2,6]  R1126     4.5432859659194946e-01
    z[3,2,6]  R1127     3.5045480728149414e-01
    z[3,2,6]  R1128     -0.0526314415037632
    z[3,2,6]  R1129     2.6307487487792969e-01
    z[3,2,6]  R1130     6.2678828835487366e-02
    z[3,2,6]  R1131     -3.8197159767150879e-02
    z[3,2,6]  R1132     9.3276090919971466e-02
    z[3,2,6]  R1133     -2.4080686271190643e-02
    z[3,2,6]  R1134     -1.4493295550346375e-01
    z[3,2,6]  R1135     3.5655535757541656e-02
    z[3,2,6]  R1136     0.0522799976170063
    z[3,2,6]  R1137     3.2310735434293747e-02
    z[3,2,6]  R1138     8.5448555648326874e-02
    z[3,2,6]  R1139     1.2455178052186966e-01
    z[3,2,6]  R1140     1.9001878798007965e-01
    z[3,2,6]  R1141     -5.6835031509399414e-01
    z[3,2,6]  R1142     -3.0935180187225342e-01
    z[3,2,6]  R1143     5.9268784523010254e-01
    z[3,2,6]  R1144     8.0272859334945679e-01
    z[3,2,6]  R1145     -4.1821199655532837e-01
    z[3,2,6]  R1146     5.3628188371658325e-01
    z[3,2,6]  R1147     7.5863644480705261e-02
    z[3,2,6]  R1148     3.7423965334892273e-01
    z[3,2,6]  R1149     7.4497717432677746e-03
    z[3,2,6]  R1150     1.6224814951419830e-01
    z[3,2,6]  R1151     -3.0374118685722351e-01
    z[3,2,6]  R1152     -3.4164834022521973e-01
    z[3,2,6]  R1153     6.2955850362777710e-01
    z[3,2,6]  R1154     3.8678586483001709e-01
    z[3,2,6]  R1155     -1.4108885824680328e-01
    z[3,2,6]  R1156     -2.0895342528820038e-01
    z[3,2,6]  R1157     -1.1328030377626419e-01
    z[3,2,6]  R1158     -0.0601862333714962
    z[3,2,6]  R1159     -2.4160975217819214e-01
    z[3,2,6]  R1160     3.6350575089454651e-01
    z[3,2,6]  R1161     1.0825856775045395e-01
    z[3,2,6]  R1162     -5.4732393473386765e-02
    z[3,2,6]  R1163     3.5946875810623169e-01
    z[3,2,6]  R1164     -2.4727845191955566e-01
    z[3,2,6]  R1165     6.0292577743530273e-01
    z[3,2,6]  R1166     -1.4043906331062317e-01
    z[3,2,6]  R1167     3.4061953425407410e-01
    z[3,2,6]  R1168     -0.281399667263031
    z[3,2,6]  R1169     -5.6827016174793243e-02
    z[3,2,6]  R1170     -3.1062424182891846e-01
    z[3,2,6]  R1171     6.1044901609420776e-01
    z[3,2,6]  R1172     1.9057519733905792e-01
    z[3,2,6]  R1173     6.6493093967437744e-01
    z[3,2,6]  R1174     7.8965082764625549e-02
    z[3,2,6]  R1175     7.5730517506599426e-02
    z[3,2,6]  R1176     1.0132216662168503e-01
    z[3,2,6]  R1177     2.6948660612106323e-01
    z[3,2,6]  R1178     -4.2699408531188965e-01
    z[3,2,6]  R1179     1.2564989924430847e-01
    z[3,2,6]  R1180     1.0915504395961761e-01
    z[3,2,6]  R1181     4.7250889241695404e-02
    z[3,2,6]  R1182     -1.4756020903587341e-01
    z[3,2,6]  R1183     -0.0288847703486681
    z[3,2,6]  R1184     -1.6712214052677155e-01
    z[3,2,6]  R1185     -1.6119672358036041e-01
    z[3,2,6]  R1186     1.5063390135765076e-01
    z[3,2,6]  R1187     1.5044826269149780e-01
    z[3,2,6]  R1188     2.8009437024593353e-02
    z[3,2,6]  R1189     6.6858351230621338e-02
    z[3,2,6]  R1190     0.259028822183609
    z[3,2,6]  R1191     1.5027964115142822e-01
    z[3,2,6]  R1192     -5.2211493253707886e-01
    z[3,2,6]  R1193     -5.9342807531356812e-01
    z[3,2,6]  R1194     -2.6496127247810364e-01
    z[3,2,6]  R1195     -1.9309477508068085e-01
    z[3,2,6]  R1196     2.5463435053825378e-01
    z[3,2,6]  R1197     -3.3253121655434370e-03
    z[3,2,6]  R1198     5.3472322225570679e-01
    z[3,2,6]  R1199     2.6953560113906860e-01
    z[3,2,6]  R1200     2.3360078036785126e-01
    z[3,2,6]  R1201     -2.3991394042968750e-01
    z[3,2,6]  R1202     6.4353114366531372e-01
    z[3,2,6]  R1203     5.7192766666412354e-01
    z[3,2,6]  R1204     -2.5998631026595831e-03
    z[3,2,6]  R1205     -1.0083127021789551e-01
    z[3,2,6]  R1206     -4.3489582836627960e-02
    z[3,2,6]  R1207     2.2829528152942657e-01
    z[3,2,6]  R1208     6.7231371998786926e-02
    z[3,2,6]  R1209     2.5963285565376282e-01
    z[3,2,6]  R1210     -1.4824126660823822e-01
    z[3,2,6]  R1211     -1.5896141529083252e-01
    z[3,2,6]  R1212     1.8201065063476562e-01
    z[3,2,6]  R1213     7.2573626041412354e-01
    z[3,2,6]  R1214     4.1801032423973083e-01
    z[3,2,6]  R1215     3.6519128084182739e-01
    z[3,2,6]  R1216     3.3364954590797424e-01
    z[3,2,6]  R1217     1.8068379163742065e-01
    z[3,2,6]  R1218     -1.0695316828787327e-02
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1219     -1
    z[2,6,0]  R1220     1
    z[2,6,0]  R1233     -5.8756476640701294e-01
    z[2,6,0]  R1234     -7.9760897159576416e-01
    z[2,6,0]  R1235     -5.8294034004211426e-01
    z[2,6,0]  R1236     -6.3656675815582275e-01
    z[2,6,0]  R1237     0.000665637431666255
    z[2,6,0]  R1238     3.4158188104629517e-01
    z[2,6,0]  R1239     3.1974050402641296e-01
    z[2,6,0]  R1240     3.4665313363075256e-01
    z[2,6,0]  R1241     1.9608055055141449e-01
    z[2,6,0]  R1242     6.2233191728591919e-01
    z[2,6,0]  R1243     1.2805898487567902e-01
    z[2,6,0]  R1244     2.9837599396705627e-01
    z[2,6,0]  R1245     5.3156417608261108e-01
    z[2,6,0]  R1246     3.4490948915481567e-01
    z[2,6,0]  R1247     5.7030439376831055e-01
    z[2,6,0]  R1248     9.3179166316986084e-01
    z[2,6,0]  R1249     8.4341913461685181e-01
    z[2,6,0]  R1250     8.8378113508224487e-01
    z[2,6,0]  R1251     8.3961808681488037e-01
    z[2,6,0]  R1252     8.8593792915344238e-01
    z[2,6,0]  R1253     1.4354000985622406e-01
    z[2,6,0]  R1254     0.34108966588974
    z[2,6,0]  R1255     1.1674237251281738e-01
    z[2,6,0]  R1256     1.1136688292026520e-01
    z[2,6,0]  R1257     4.5378932356834412e-01
    z[2,6,0]  R1258     4.1349762678146362e-01
    z[2,6,0]  R1259     6.7828559875488281e-01
    z[2,6,0]  R1260     4.8787105083465576e-01
    z[2,6,0]  R1261     3.5431259870529175e-01
    z[2,6,0]  R1262     8.2129406929016113e-01
    z[2,6,0]  R1263     -2.1240970492362976e-01
    z[2,6,0]  R1264     5.6615126132965088e-01
    z[2,6,0]  R1265     -0.287582129240036
    z[2,6,0]  R1266     3.9139175415039062e-01
    z[2,6,0]  R1267     8.9847363531589508e-02
    z[2,6,0]  R1268     -1.3517257571220398e-01
    z[2,6,0]  R1269     6.2380012124776840e-02
    z[2,6,0]  R1270     -3.1546853482723236e-02
    z[2,6,0]  R1271     -3.2627135515213013e-01
    z[2,6,0]  R1272     3.7415587902069092e-01
    z[2,6,0]  R1273     -2.1480867266654968e-01
    z[2,6,0]  R1274     -2.4702057242393494e-01
    z[2,6,0]  R1275     0.0647042840719223
    z[2,6,0]  R1276     -0.0897059440612793
    z[2,6,0]  R1277     7.5556194782257080e-01
    z[2,6,0]  R1278     -6.9648653268814087e-01
    z[2,6,0]  R1279     4.2574423551559448e-01
    z[2,6,0]  R1280     -8.8941919803619385e-01
    z[2,6,0]  R1281     6.2374550104141235e-01
    z[2,6,0]  R1282     -5.0331413745880127e-01
    z[2,6,0]  R1283     2.9560112953186035e-01
    z[2,6,0]  R1284     -1.8875746428966522e-01
    z[2,6,0]  R1285     -3.9666953682899475e-01
    z[2,6,0]  R1286     -1.5260013937950134e-01
    z[2,6,0]  R1287     4.4463074207305908e-01
    z[2,6,0]  R1288     1.3967847824096680e-01
    z[2,6,0]  R1289     -5.1141440868377686e-01
    z[2,6,0]  R1290     -3.6340034008026123e-01
    z[2,6,0]  R1291     2.8061848878860474e-01
    z[2,6,0]  R1292     1.1992813646793365e-01
    z[2,6,0]  R1293     -1.1969466507434845e-01
    z[2,6,0]  R1294     0.891903281211853
    z[2,6,0]  R1295     -0.0440092533826828
    z[2,6,0]  R1296     6.9294106960296631e-01
    z[2,6,0]  R1297     6.0244774818420410e-01
    z[2,6,0]  R1298     -8.1641167402267456e-02
    z[2,6,0]  R1299     5.6040030717849731e-01
    z[2,6,0]  R1300     4.0766561031341553e-01
    z[2,6,0]  R1301     3.1279277754947543e-04
    z[2,6,0]  R1302     4.6923488378524780e-01
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1221     -1
    z[2,6,1]  R1222     1
    z[2,6,1]  R1233     -3.0761319398880005e-01
    z[2,6,1]  R1234     -2.1458260715007782e-02
    z[2,6,1]  R1235     -1.5686792135238647e-01
    z[2,6,1]  R1236     -1.1779581010341644e-01
    z[2,6,1]  R1237     -6.7735219001770020e-01
    z[2,6,1]  R1238     0.693505585193634
    z[2,6,1]  R1239     5.1017683744430542e-01
    z[2,6,1]  R1240     0.678641140460968
    z[2,6,1]  R1241     4.3037557601928711e-01
    z[2,6,1]  R1242     -9.2120125889778137e-02
    z[2,6,1]  R1243     7.4141013622283936e-01
    z[2,6,1]  R1244     7.4333906173706055e-01
    z[2,6,1]  R1245     6.6982412338256836e-01
    z[2,6,1]  R1246     -5.7433068752288818e-01
    z[2,6,1]  R1247     -4.5757806301116943e-01
    z[2,6,1]  R1248     4.9543965607881546e-02
    z[2,6,1]  R1249     2.1142403781414032e-01
    z[2,6,1]  R1250     1.2041904032230377e-01
    z[2,6,1]  R1251     1.6735802590847015e-01
    z[2,6,1]  R1252     3.4211522340774536e-01
    z[2,6,1]  R1253     8.5066372156143188e-01
    z[2,6,1]  R1254     6.7517876625061035e-01
    z[2,6,1]  R1255     7.0113706588745117e-01
    z[2,6,1]  R1256     0.666340172290802
    z[2,6,1]  R1257     -4.4583463668823242e-01
    z[2,6,1]  R1258     -5.0902652740478516e-01
    z[2,6,1]  R1259     -4.3175652623176575e-01
    z[2,6,1]  R1260     -1.7618516087532043e-01
    z[2,6,1]  R1261     -5.4970139265060425e-01
    z[2,6,1]  R1262     -6.8831346929073334e-02
    z[2,6,1]  R1263     -4.4346127659082413e-02
    z[2,6,1]  R1264     -9.0379834175109863e-02
    z[2,6,1]  R1265     -1.5228827297687531e-01
    z[2,6,1]  R1266     -1.0052482783794403e-01
    z[2,6,1]  R1267     -3.9079539477825165e-02
    z[2,6,1]  R1268     -1.6333429515361786e-01
    z[2,6,1]  R1269     -5.1454100757837296e-02
    z[2,6,1]  R1270     -5.8109525591135025e-02
    z[2,6,1]  R1271     9.2844374477863312e-02
    z[2,6,1]  R1272     -8.1013187766075134e-02
    z[2,6,1]  R1273     8.1758999824523926e-01
    z[2,6,1]  R1274     -2.7423635125160217e-01
    z[2,6,1]  R1275     9.2157393693923950e-01
    z[2,6,1]  R1276     9.1725713014602661e-01
    z[2,6,1]  R1277     -3.1591439247131348e-01
    z[2,6,1]  R1278     -4.2140522599220276e-01
    z[2,6,1]  R1279     -2.1396489441394806e-01
    z[2,6,1]  R1280     -0.283568799495697
    z[2,6,1]  R1281     3.6306354403495789e-01
    z[2,6,1]  R1282     -5.2217030525207520e-01
    z[2,6,1]  R1283     -7.4705088138580322e-01
    z[2,6,1]  R1284     -6.0879707336425781e-01
    z[2,6,1]  R1285     -6.1021369695663452e-01
    z[2,6,1]  R1286     -5.2069664001464844e-01
    z[2,6,1]  R1287     -5.0037395954132080e-01
    z[2,6,1]  R1288     -5.1626527309417725e-01
    z[2,6,1]  R1289     -4.8499128222465515e-01
    z[2,6,1]  R1290     -4.2986959218978882e-01
    z[2,6,1]  R1291     -4.6784445643424988e-01
    z[2,6,1]  R1292     -5.2109575271606445e-01
    z[2,6,1]  R1293     -6.4972156286239624e-01
    z[2,6,1]  R1294     1.3706804811954498e-01
    z[2,6,1]  R1295     -5.5932825803756714e-01
    z[2,6,1]  R1296     4.6786937862634659e-02
    z[2,6,1]  R1297     -2.8206637501716614e-01
    z[2,6,1]  R1298     -0.646415650844574
    z[2,6,1]  R1299     4.0782818198204041e-01
    z[2,6,1]  R1300     1.4009904861450195e-01
    z[2,6,1]  R1301     -2.5747969746589661e-01
    z[2,6,1]  R1302     2.2282439470291138e-01
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1223     -1
    z[2,6,2]  R1224     1
    z[2,6,2]  R1233     2.5536981225013733e-01
    z[2,6,2]  R1234     -8.0873884260654449e-02
    z[2,6,2]  R1235     -7.4643611907958984e-01
    z[2,6,2]  R1236     2.6601186394691467e-01
    z[2,6,2]  R1237     -3.3538267016410828e-01
    z[2,6,2]  R1238     3.3730635046958923e-01
    z[2,6,2]  R1239     -5.7383030652999878e-01
    z[2,6,2]  R1240     2.3722781240940094e-01
    z[2,6,2]  R1241     -1.4183494448661804e-01
    z[2,6,2]  R1242     -3.5477694869041443e-01
    z[2,6,2]  R1243     -3.4747142344713211e-02
    z[2,6,2]  R1244     4.0809872746467590e-01
    z[2,6,2]  R1245     -1.4974361658096313e-01
    z[2,6,2]  R1246     1.4509527385234833e-01
    z[2,6,2]  R1247     2.3709741234779358e-01
    z[2,6,2]  R1248     3.8914494216442108e-02
    z[2,6,2]  R1249     8.1839226186275482e-02
    z[2,6,2]  R1250     2.6590687036514282e-01
    z[2,6,2]  R1251     1.2773790955543518e-01
    z[2,6,2]  R1252     2.6197027415037155e-02
    z[2,6,2]  R1253     -1.7921912670135498e-01
    z[2,6,2]  R1254     -3.5935276746749878e-01
    z[2,6,2]  R1255     2.6201415061950684e-01
    z[2,6,2]  R1256     5.6552481651306152e-01
    z[2,6,2]  R1257     -1.4974561333656311e-01
    z[2,6,2]  R1258     -2.2675932943820953e-01
    z[2,6,2]  R1259     -4.1336383670568466e-02
    z[2,6,2]  R1260     1.3642235100269318e-01
    z[2,6,2]  R1261     6.8221598863601685e-01
    z[2,6,2]  R1262     -7.2196260094642639e-02
    z[2,6,2]  R1263     -6.2255424261093140e-01
    z[2,6,2]  R1264     -7.4332630634307861e-01
    z[2,6,2]  R1265     -8.0464816093444824e-01
    z[2,6,2]  R1266     -6.0049152374267578e-01
    z[2,6,2]  R1267     -1.8468938767910004e-01
    z[2,6,2]  R1268     -7.3881131410598755e-01
    z[2,6,2]  R1269     -6.4745169878005981e-01
    z[2,6,2]  R1270     -8.3255708217620850e-01
    z[2,6,2]  R1271     -8.3497482538223267e-01
    z[2,6,2]  R1272     -3.6337402462959290e-01
    z[2,6,2]  R1273     3.0558711290359497e-01
    z[2,6,2]  R1274     5.8320814371109009e-01
    z[2,6,2]  R1275     2.4961875379085541e-01
    z[2,6,2]  R1276     2.9769837856292725e-01
    z[2,6,2]  R1277     2.1694932878017426e-01
    z[2,6,2]  R1278     2.8463923931121826e-01
    z[2,6,2]  R1279     2.0543260872364044e-01
    z[2,6,2]  R1280     2.0874388515949249e-01
    z[2,6,2]  R1281     0.381873220205307
    z[2,6,2]  R1282     3.4576156735420227e-01
    z[2,6,2]  R1283     1.0945479571819305e-01
    z[2,6,2]  R1284     -3.2285865396261215e-02
    z[2,6,2]  R1285     -5.2841058932244778e-03
    z[2,6,2]  R1286     2.2360880672931671e-01
    z[2,6,2]  R1287     3.1841287016868591e-01
    z[2,6,2]  R1288     -3.3113136887550354e-01
    z[2,6,2]  R1289     1.0439525544643402e-01
    z[2,6,2]  R1290     2.3203656077384949e-01
    z[2,6,2]  R1291     -1.0930939763784409e-01
    z[2,6,2]  R1292     2.4682506918907166e-01
    z[2,6,2]  R1293     -6.2499684095382690e-01
    z[2,6,2]  R1294     -2.2313027083873749e-01
    z[2,6,2]  R1295     -9.5440290868282318e-02
    z[2,6,2]  R1296     -6.9622255861759186e-02
    z[2,6,2]  R1297     -1.8771840631961823e-01
    z[2,6,2]  R1298     -2.8977859020233154e-01
    z[2,6,2]  R1299     0.0358751118183136
    z[2,6,2]  R1300     -1.8994650244712830e-01
    z[2,6,2]  R1301     -4.9565258622169495e-01
    z[2,6,2]  R1302     1.5451537072658539e-01
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1225     -1
    z[2,6,3]  R1226     1
    z[2,6,3]  R1233     6.9872546195983887e-01
    z[2,6,3]  R1234     -1.4361524581909180e-01
    z[2,6,3]  R1235     -1.6800025105476379e-01
    z[2,6,3]  R1236     -3.9234411716461182e-01
    z[2,6,3]  R1237     -1.6036370769143105e-02
    z[2,6,3]  R1238     3.7227776646614075e-01
    z[2,6,3]  R1239     3.9219167828559875e-01
    z[2,6,3]  R1240     2.6986068487167358e-01
    z[2,6,3]  R1241     3.6536210775375366e-01
    z[2,6,3]  R1242     2.0269700884819031e-01
    z[2,6,3]  R1243     -3.0786329880356789e-02
    z[2,6,3]  R1244     -3.0556395649909973e-01
    z[2,6,3]  R1245     -2.9215618968009949e-01
    z[2,6,3]  R1246     -3.1286829710006714e-01
    z[2,6,3]  R1247     1.5310217440128326e-01
    z[2,6,3]  R1248     -2.8971329331398010e-01
    z[2,6,3]  R1249     -3.9567741751670837e-01
    z[2,6,3]  R1250     -3.3423423767089844e-01
    z[2,6,3]  R1251     -3.4821224212646484e-01
    z[2,6,3]  R1252     -2.6191130280494690e-01
    z[2,6,3]  R1253     8.6467579007148743e-02
    z[2,6,3]  R1254     1.3405305147171021e-01
    z[2,6,3]  R1255     1.1523726396262646e-02
    z[2,6,3]  R1256     1.6345396637916565e-01
    z[2,6,3]  R1257     1.2899482250213623e-01
    z[2,6,3]  R1258     6.1010837554931641e-02
    z[2,6,3]  R1259     2.9394409060478210e-01
    z[2,6,3]  R1260     0.0871608629822731
    z[2,6,3]  R1261     -2.4624569714069366e-01
    z[2,6,3]  R1262     -1.4056387543678284e-01
    z[2,6,3]  R1263     -1.8421080708503723e-01
    z[2,6,3]  R1264     -2.9413759708404541e-02
    z[2,6,3]  R1265     1.6060025990009308e-01
    z[2,6,3]  R1266     1.5337137877941132e-01
    z[2,6,3]  R1267     3.9470937848091125e-01
    z[2,6,3]  R1268     1.2312074750661850e-01
    z[2,6,3]  R1269     -0.366982102394104
    z[2,6,3]  R1270     1.2864798307418823e-01
    z[2,6,3]  R1271     -8.5663378238677979e-02
    z[2,6,3]  R1272     -3.0126622319221497e-01
    z[2,6,3]  R1273     3.9039561152458191e-01
    z[2,6,3]  R1274     -4.7683459520339966e-01
    z[2,6,3]  R1275     -1.6152353584766388e-01
    z[2,6,3]  R1276     -2.0118415355682373e-01
    z[2,6,3]  R1277     3.3191543817520142e-01
    z[2,6,3]  R1278     4.8919060826301575e-01
    z[2,6,3]  R1279     -6.1220663785934448e-01
    z[2,6,3]  R1280     1.7509926855564117e-01
    z[2,6,3]  R1281     -4.7625014185905457e-01
    z[2,6,3]  R1282     4.8647928237915039e-01
    z[2,6,3]  R1283     -2.3330879211425781e-01
    z[2,6,3]  R1284     -6.9764018058776855e-02
    z[2,6,3]  R1285     2.6782515645027161e-01
    z[2,6,3]  R1286     -0.405845582485199
    z[2,6,3]  R1287     6.4888454973697662e-02
    z[2,6,3]  R1288     -3.8919255137443542e-01
    z[2,6,3]  R1289     1.6290649771690369e-01
    z[2,6,3]  R1290     -3.8584843277931213e-01
    z[2,6,3]  R1291     8.2914769649505615e-02
    z[2,6,3]  R1292     3.1777891516685486e-01
    z[2,6,3]  R1293     -2.1474552154541016e-01
    z[2,6,3]  R1294     1.8357586860656738e-01
    z[2,6,3]  R1295     6.8477582931518555e-01
    z[2,6,3]  R1296     1.3806837797164917e-01
    z[2,6,3]  R1297     -6.0245178639888763e-02
    z[2,6,3]  R1298     2.5885561108589172e-01
    z[2,6,3]  R1299     -4.7876462340354919e-01
    z[2,6,3]  R1300     -0.363491028547287
    z[2,6,3]  R1301     5.1065343618392944e-01
    z[2,6,3]  R1302     -3.0907431617379189e-02
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1227     -1
    z[2,6,4]  R1228     1
    z[2,6,4]  R1233     -2.9354941099882126e-02
    z[2,6,4]  R1234     -2.7737346291542053e-01
    z[2,6,4]  R1235     -3.6460742354393005e-02
    z[2,6,4]  R1236     3.5273800604045391e-03
    z[2,6,4]  R1237     -2.1476107835769653e-01
    z[2,6,4]  R1238     -2.2934643551707268e-02
    z[2,6,4]  R1239     -7.9072043299674988e-02
    z[2,6,4]  R1240     -3.5760810971260071e-01
    z[2,6,4]  R1241     -7.7128744125366211e-01
    z[2,6,4]  R1242     -3.8145750761032104e-01
    z[2,6,4]  R1243     7.3071740567684174e-02
    z[2,6,4]  R1244     -1.4902658760547638e-01
    z[2,6,4]  R1245     3.9553143084049225e-02
    z[2,6,4]  R1246     2.0750153809785843e-02
    z[2,6,4]  R1247     2.4105429649353027e-01
    z[2,6,4]  R1248     1.7101193964481354e-01
    z[2,6,4]  R1249     0.0950782373547554
    z[2,6,4]  R1250     -1.0960499197244644e-01
    z[2,6,4]  R1251     1.5725545585155487e-01
    z[2,6,4]  R1252     1.2200789898633957e-01
    z[2,6,4]  R1253     2.8890535235404968e-01
    z[2,6,4]  R1254     4.3241629004478455e-01
    z[2,6,4]  R1255     -6.0956722497940063e-01
    z[2,6,4]  R1256     3.5223352909088135e-01
    z[2,6,4]  R1257     -1.6913086175918579e-01
    z[2,6,4]  R1258     1.9742825627326965e-01
    z[2,6,4]  R1259     0.330597460269928
    z[2,6,4]  R1260     -7.7031159400939941e-01
    z[2,6,4]  R1261     8.4561698138713837e-02
    z[2,6,4]  R1262     3.0646726489067078e-02
    z[2,6,4]  R1263     -6.3743394613265991e-01
    z[2,6,4]  R1264     -1.3657073676586151e-01
    z[2,6,4]  R1265     -2.7995908260345459e-01
    z[2,6,4]  R1266     -5.8870977163314819e-01
    z[2,6,4]  R1267     -8.1852513551712036e-01
    z[2,6,4]  R1268     8.7458200752735138e-02
    z[2,6,4]  R1269     -4.6370047330856323e-01
    z[2,6,4]  R1270     1.2290842831134796e-01
    z[2,6,4]  R1271     -6.2325045466423035e-02
    z[2,6,4]  R1272     -7.8452903032302856e-01
    z[2,6,4]  R1273     8.9119784533977509e-02
    z[2,6,4]  R1274     1.4148251712322235e-01
    z[2,6,4]  R1275     1.2777429819107056e-01
    z[2,6,4]  R1276     1.1681786179542542e-01
    z[2,6,4]  R1277     3.0304929614067078e-01
    z[2,6,4]  R1278     -6.9315090775489807e-02
    z[2,6,4]  R1279     4.2483016848564148e-01
    z[2,6,4]  R1280     1.8962581455707550e-01
    z[2,6,4]  R1281     1.5284567140042782e-02
    z[2,6,4]  R1282     2.2329214215278625e-01
    z[2,6,4]  R1283     -3.4885589033365250e-02
    z[2,6,4]  R1284     -5.6437385082244873e-01
    z[2,6,4]  R1285     -3.9155066013336182e-01
    z[2,6,4]  R1286     6.4252310991287231e-01
    z[2,6,4]  R1287     -1.9448530673980713e-01
    z[2,6,4]  R1288     -5.9565279632806778e-02
    z[2,6,4]  R1289     4.3613232672214508e-02
    z[2,6,4]  R1290     -1.6706696152687073e-01
    z[2,6,4]  R1291     1.5945152938365936e-01
    z[2,6,4]  R1292     -0.700086772441864
    z[2,6,4]  R1293     -8.6237683892250061e-02
    z[2,6,4]  R1294     2.8281274437904358e-01
    z[2,6,4]  R1295     -1.9821323454380035e-01
    z[2,6,4]  R1296     -1.6417573392391205e-01
    z[2,6,4]  R1297     1.9250491261482239e-01
    z[2,6,4]  R1298     5.5724793672561646e-01
    z[2,6,4]  R1299     2.7393159270286560e-01
    z[2,6,4]  R1300     1.7277634143829346e-01
    z[2,6,4]  R1301     0.624572217464447
    z[2,6,4]  R1302     0.0839446485042572
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1229     -1
    z[2,6,5]  R1230     1
    z[2,6,5]  R1233     3.7134058773517609e-02
    z[2,6,5]  R1234     -4.3836227059364319e-01
    z[2,6,5]  R1235     1.6207601130008698e-01
    z[2,6,5]  R1236     2.8912666440010071e-01
    z[2,6,5]  R1237     1.7371119558811188e-01
    z[2,6,5]  R1238     -2.8155824542045593e-01
    z[2,6,5]  R1239     -3.3294427394866943e-01
    z[2,6,5]  R1240     -3.1217607855796814e-01
    z[2,6,5]  R1241     1.6681528091430664e-01
    z[2,6,5]  R1242     -7.6324068009853363e-02
    z[2,6,5]  R1243     5.9478396177291870e-01
    z[2,6,5]  R1244     1.4739955961704254e-01
    z[2,6,5]  R1245     3.1917652487754822e-01
    z[2,6,5]  R1246     -1.3296452164649963e-01
    z[2,6,5]  R1247     2.2613622248172760e-02
    z[2,6,5]  R1248     -1.2087034434080124e-01
    z[2,6,5]  R1249     -2.4794960021972656e-01
    z[2,6,5]  R1250     -0.0900367721915245
    z[2,6,5]  R1251     -2.2938187420368195e-01
    z[2,6,5]  R1252     -9.6857078373432159e-02
    z[2,6,5]  R1253     -2.5553047657012939e-01
    z[2,6,5]  R1254     2.6781976222991943e-01
    z[2,6,5]  R1255     1.7074239253997803e-01
    z[2,6,5]  R1256     1.9964082539081573e-01
    z[2,6,5]  R1257     -3.0739307403564453e-02
    z[2,6,5]  R1258     -5.4868847131729126e-01
    z[2,6,5]  R1259     1.5081061422824860e-01
    z[2,6,5]  R1260     5.5249845609068871e-03
    z[2,6,5]  R1261     -8.0237448215484619e-02
    z[2,6,5]  R1262     -5.4287576675415039e-01
    z[2,6,5]  R1263     2.0146530866622925e-01
    z[2,6,5]  R1264     1.3990907371044159e-01
    z[2,6,5]  R1265     3.3354374766349792e-01
    z[2,6,5]  R1266     3.0304759740829468e-01
    z[2,6,5]  R1267     3.3876052498817444e-01
    z[2,6,5]  R1268     3.4586733579635620e-01
    z[2,6,5]  R1269     2.0835934579372406e-01
    z[2,6,5]  R1270     2.6599800586700439e-01
    z[2,6,5]  R1271     4.1952362656593323e-01
    z[2,6,5]  R1272     4.9756024032831192e-02
    z[2,6,5]  R1273     -1.2804748117923737e-01
    z[2,6,5]  R1274     5.2556627988815308e-01
    z[2,6,5]  R1275     -1.1099065840244293e-01
    z[2,6,5]  R1276     -5.7539731264114380e-02
    z[2,6,5]  R1277     -2.8323435783386230e-01
    z[2,6,5]  R1278     -1.1019649356603622e-01
    z[2,6,5]  R1279     3.2817018032073975e-01
    z[2,6,5]  R1280     -1.2396162748336792e-01
    z[2,6,5]  R1281     -1.2915004789829254e-01
    z[2,6,5]  R1282     -2.5686267018318176e-01
    z[2,6,5]  R1283     -3.6452582478523254e-01
    z[2,6,5]  R1284     5.6535284966230392e-02
    z[2,6,5]  R1285     4.9025887250900269e-01
    z[2,6,5]  R1286     -2.7779844403266907e-01
    z[2,6,5]  R1287     6.3344120979309082e-01
    z[2,6,5]  R1288     6.5751016139984131e-01
    z[2,6,5]  R1289     -6.4349383115768433e-02
    z[2,6,5]  R1290     -1.0267642885446548e-01
    z[2,6,5]  R1291     7.5395655632019043e-01
    z[2,6,5]  R1292     -2.2027517855167389e-01
    z[2,6,5]  R1293     -1.9749562442302704e-01
    z[2,6,5]  R1294     1.4104568958282471e-01
    z[2,6,5]  R1295     -8.9955426752567291e-02
    z[2,6,5]  R1296     1.8768961727619171e-01
    z[2,6,5]  R1297     -4.1778244078159332e-02
    z[2,6,5]  R1298     -2.9994806647300720e-01
    z[2,6,5]  R1299     -1.2022332102060318e-01
    z[2,6,5]  R1300     -1.8738360702991486e-01
    z[2,6,5]  R1301     1.8032878637313843e-01
    z[2,6,5]  R1302     -1.3821698725223541e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1231     -1
    z[2,6,6]  R1232     1
    z[2,6,6]  R1233     6.6858351230621338e-02
    z[2,6,6]  R1234     0.259028822183609
    z[2,6,6]  R1235     1.5027964115142822e-01
    z[2,6,6]  R1236     -5.2211493253707886e-01
    z[2,6,6]  R1237     -5.9342807531356812e-01
    z[2,6,6]  R1238     -2.6496127247810364e-01
    z[2,6,6]  R1239     -1.9309477508068085e-01
    z[2,6,6]  R1240     2.5463435053825378e-01
    z[2,6,6]  R1241     -3.3253121655434370e-03
    z[2,6,6]  R1242     5.3472322225570679e-01
    z[2,6,6]  R1243     2.6953560113906860e-01
    z[2,6,6]  R1244     2.3360078036785126e-01
    z[2,6,6]  R1245     -2.3991394042968750e-01
    z[2,6,6]  R1246     6.4353114366531372e-01
    z[2,6,6]  R1247     5.7192766666412354e-01
    z[2,6,6]  R1248     -2.5998631026595831e-03
    z[2,6,6]  R1249     -1.0083127021789551e-01
    z[2,6,6]  R1250     -4.3489582836627960e-02
    z[2,6,6]  R1251     2.2829528152942657e-01
    z[2,6,6]  R1252     6.7231371998786926e-02
    z[2,6,6]  R1253     2.5963285565376282e-01
    z[2,6,6]  R1254     -1.4824126660823822e-01
    z[2,6,6]  R1255     -1.5896141529083252e-01
    z[2,6,6]  R1256     1.8201065063476562e-01
    z[2,6,6]  R1257     7.2573626041412354e-01
    z[2,6,6]  R1258     4.1801032423973083e-01
    z[2,6,6]  R1259     3.6519128084182739e-01
    z[2,6,6]  R1260     3.3364954590797424e-01
    z[2,6,6]  R1261     1.8068379163742065e-01
    z[2,6,6]  R1262     -1.0695316828787327e-02
    z[2,6,6]  R1263     2.9068502783775330e-01
    z[2,6,6]  R1264     2.8227454423904419e-01
    z[2,6,6]  R1265     1.7670619487762451e-01
    z[2,6,6]  R1266     -1.1906898766756058e-01
    z[2,6,6]  R1267     -1.2550881505012512e-01
    z[2,6,6]  R1268     -5.1650381088256836e-01
    z[2,6,6]  R1269     -4.2562881112098694e-01
    z[2,6,6]  R1270     0.447286456823349
    z[2,6,6]  R1271     -2.2831052541732788e-02
    z[2,6,6]  R1272     -1.1260929703712463e-01
    z[2,6,6]  R1273     1.2358459830284119e-01
    z[2,6,6]  R1274     0.00592637388035655
    z[2,6,6]  R1275     -1.7166891694068909e-01
    z[2,6,6]  R1276     6.7347057163715363e-02
    z[2,6,6]  R1277     5.3730695508420467e-03
    z[2,6,6]  R1278     -7.0308116264641285e-03
    z[2,6,6]  R1279     -2.6035559177398682e-01
    z[2,6,6]  R1280     -5.4442346096038818e-02
    z[2,6,6]  R1281     -2.9928541183471680e-01
    z[2,6,6]  R1282     -4.4294662773609161e-02
    z[2,6,6]  R1283     3.9246085286140442e-01
    z[2,6,6]  R1284     5.1586157083511353e-01
    z[2,6,6]  R1285     6.9776542484760284e-02
    z[2,6,6]  R1286     2.9474783688783646e-02
    z[2,6,6]  R1287     -8.5204273462295532e-02
    z[2,6,6]  R1288     1.3028287887573242e-01
    z[2,6,6]  R1289     -6.7805522680282593e-01
    z[2,6,6]  R1290     -6.6481471061706543e-01
    z[2,6,6]  R1291     0.299459844827652
    z[2,6,6]  R1292     -1.1630912870168686e-01
    z[2,6,6]  R1293     -2.8347286581993103e-01
    z[2,6,6]  R1294     -4.8547599464654922e-02
    z[2,6,6]  R1295     3.9975982904434204e-01
    z[2,6,6]  R1296     -6.5692657232284546e-01
    z[2,6,6]  R1297     -6.9269323348999023e-01
    z[2,6,6]  R1298     1.5495055913925171e-01
    z[2,6,6]  R1299     4.4680300354957581e-01
    z[2,6,6]  R1300     7.6224094629287720e-01
    z[2,6,6]  R1301     -6.8241044878959656e-02
    z[2,6,6]  R1302     8.2412803173065186e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1303     -1
    z[6,2,0]  R1304     1
    z[6,2,0]  R1317     -2.1240970492362976e-01
    z[6,2,0]  R1318     5.6615126132965088e-01
    z[6,2,0]  R1319     -0.287582129240036
    z[6,2,0]  R1320     3.9139175415039062e-01
    z[6,2,0]  R1321     8.9847363531589508e-02
    z[6,2,0]  R1322     -1.3517257571220398e-01
    z[6,2,0]  R1323     6.2380012124776840e-02
    z[6,2,0]  R1324     -3.1546853482723236e-02
    z[6,2,0]  R1325     -3.2627135515213013e-01
    z[6,2,0]  R1326     3.7415587902069092e-01
    z[6,2,0]  R1327     -2.1480867266654968e-01
    z[6,2,0]  R1328     -2.4702057242393494e-01
    z[6,2,0]  R1329     0.0647042840719223
    z[6,2,0]  R1330     -0.0897059440612793
    z[6,2,0]  R1331     7.5556194782257080e-01
    z[6,2,0]  R1332     -6.9648653268814087e-01
    z[6,2,0]  R1333     4.2574423551559448e-01
    z[6,2,0]  R1334     -8.8941919803619385e-01
    z[6,2,0]  R1335     6.2374550104141235e-01
    z[6,2,0]  R1336     -5.0331413745880127e-01
    z[6,2,0]  R1337     2.9560112953186035e-01
    z[6,2,0]  R1338     -1.8875746428966522e-01
    z[6,2,0]  R1339     -3.9666953682899475e-01
    z[6,2,0]  R1340     -1.5260013937950134e-01
    z[6,2,0]  R1341     4.4463074207305908e-01
    z[6,2,0]  R1342     1.3967847824096680e-01
    z[6,2,0]  R1343     -5.1141440868377686e-01
    z[6,2,0]  R1344     -3.6340034008026123e-01
    z[6,2,0]  R1345     2.8061848878860474e-01
    z[6,2,0]  R1346     1.1992813646793365e-01
    z[6,2,0]  R1347     -1.1969466507434845e-01
    z[6,2,0]  R1348     0.891903281211853
    z[6,2,0]  R1349     -0.0440092533826828
    z[6,2,0]  R1350     6.9294106960296631e-01
    z[6,2,0]  R1351     6.0244774818420410e-01
    z[6,2,0]  R1352     -8.1641167402267456e-02
    z[6,2,0]  R1353     5.6040030717849731e-01
    z[6,2,0]  R1354     4.0766561031341553e-01
    z[6,2,0]  R1355     3.1279277754947543e-04
    z[6,2,0]  R1356     4.6923488378524780e-01
    z[6,2,0]  R1357     -5.8756476640701294e-01
    z[6,2,0]  R1358     -7.9760897159576416e-01
    z[6,2,0]  R1359     -5.8294034004211426e-01
    z[6,2,0]  R1360     -6.3656675815582275e-01
    z[6,2,0]  R1361     0.000665637431666255
    z[6,2,0]  R1362     3.4158188104629517e-01
    z[6,2,0]  R1363     3.1974050402641296e-01
    z[6,2,0]  R1364     3.4665313363075256e-01
    z[6,2,0]  R1365     1.9608055055141449e-01
    z[6,2,0]  R1366     6.2233191728591919e-01
    z[6,2,0]  R1367     1.2805898487567902e-01
    z[6,2,0]  R1368     2.9837599396705627e-01
    z[6,2,0]  R1369     5.3156417608261108e-01
    z[6,2,0]  R1370     3.4490948915481567e-01
    z[6,2,0]  R1371     5.7030439376831055e-01
    z[6,2,0]  R1372     9.3179166316986084e-01
    z[6,2,0]  R1373     8.4341913461685181e-01
    z[6,2,0]  R1374     8.8378113508224487e-01
    z[6,2,0]  R1375     8.3961808681488037e-01
    z[6,2,0]  R1376     8.8593792915344238e-01
    z[6,2,0]  R1377     1.4354000985622406e-01
    z[6,2,0]  R1378     0.34108966588974
    z[6,2,0]  R1379     1.1674237251281738e-01
    z[6,2,0]  R1380     1.1136688292026520e-01
    z[6,2,0]  R1381     4.5378932356834412e-01
    z[6,2,0]  R1382     4.1349762678146362e-01
    z[6,2,0]  R1383     6.7828559875488281e-01
    z[6,2,0]  R1384     4.8787105083465576e-01
    z[6,2,0]  R1385     3.5431259870529175e-01
    z[6,2,0]  R1386     8.2129406929016113e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1305     -1
    z[6,2,1]  R1306     1
    z[6,2,1]  R1317     -4.4346127659082413e-02
    z[6,2,1]  R1318     -9.0379834175109863e-02
    z[6,2,1]  R1319     -1.5228827297687531e-01
    z[6,2,1]  R1320     -1.0052482783794403e-01
    z[6,2,1]  R1321     -3.9079539477825165e-02
    z[6,2,1]  R1322     -1.6333429515361786e-01
    z[6,2,1]  R1323     -5.1454100757837296e-02
    z[6,2,1]  R1324     -5.8109525591135025e-02
    z[6,2,1]  R1325     9.2844374477863312e-02
    z[6,2,1]  R1326     -8.1013187766075134e-02
    z[6,2,1]  R1327     8.1758999824523926e-01
    z[6,2,1]  R1328     -2.7423635125160217e-01
    z[6,2,1]  R1329     9.2157393693923950e-01
    z[6,2,1]  R1330     9.1725713014602661e-01
    z[6,2,1]  R1331     -3.1591439247131348e-01
    z[6,2,1]  R1332     -4.2140522599220276e-01
    z[6,2,1]  R1333     -2.1396489441394806e-01
    z[6,2,1]  R1334     -0.283568799495697
    z[6,2,1]  R1335     3.6306354403495789e-01
    z[6,2,1]  R1336     -5.2217030525207520e-01
    z[6,2,1]  R1337     -7.4705088138580322e-01
    z[6,2,1]  R1338     -6.0879707336425781e-01
    z[6,2,1]  R1339     -6.1021369695663452e-01
    z[6,2,1]  R1340     -5.2069664001464844e-01
    z[6,2,1]  R1341     -5.0037395954132080e-01
    z[6,2,1]  R1342     -5.1626527309417725e-01
    z[6,2,1]  R1343     -4.8499128222465515e-01
    z[6,2,1]  R1344     -4.2986959218978882e-01
    z[6,2,1]  R1345     -4.6784445643424988e-01
    z[6,2,1]  R1346     -5.2109575271606445e-01
    z[6,2,1]  R1347     -6.4972156286239624e-01
    z[6,2,1]  R1348     1.3706804811954498e-01
    z[6,2,1]  R1349     -5.5932825803756714e-01
    z[6,2,1]  R1350     4.6786937862634659e-02
    z[6,2,1]  R1351     -2.8206637501716614e-01
    z[6,2,1]  R1352     -0.646415650844574
    z[6,2,1]  R1353     4.0782818198204041e-01
    z[6,2,1]  R1354     1.4009904861450195e-01
    z[6,2,1]  R1355     -2.5747969746589661e-01
    z[6,2,1]  R1356     2.2282439470291138e-01
    z[6,2,1]  R1357     -3.0761319398880005e-01
    z[6,2,1]  R1358     -2.1458260715007782e-02
    z[6,2,1]  R1359     -1.5686792135238647e-01
    z[6,2,1]  R1360     -1.1779581010341644e-01
    z[6,2,1]  R1361     -6.7735219001770020e-01
    z[6,2,1]  R1362     0.693505585193634
    z[6,2,1]  R1363     5.1017683744430542e-01
    z[6,2,1]  R1364     0.678641140460968
    z[6,2,1]  R1365     4.3037557601928711e-01
    z[6,2,1]  R1366     -9.2120125889778137e-02
    z[6,2,1]  R1367     7.4141013622283936e-01
    z[6,2,1]  R1368     7.4333906173706055e-01
    z[6,2,1]  R1369     6.6982412338256836e-01
    z[6,2,1]  R1370     -5.7433068752288818e-01
    z[6,2,1]  R1371     -4.5757806301116943e-01
    z[6,2,1]  R1372     4.9543965607881546e-02
    z[6,2,1]  R1373     2.1142403781414032e-01
    z[6,2,1]  R1374     1.2041904032230377e-01
    z[6,2,1]  R1375     1.6735802590847015e-01
    z[6,2,1]  R1376     3.4211522340774536e-01
    z[6,2,1]  R1377     8.5066372156143188e-01
    z[6,2,1]  R1378     6.7517876625061035e-01
    z[6,2,1]  R1379     7.0113706588745117e-01
    z[6,2,1]  R1380     0.666340172290802
    z[6,2,1]  R1381     -4.4583463668823242e-01
    z[6,2,1]  R1382     -5.0902652740478516e-01
    z[6,2,1]  R1383     -4.3175652623176575e-01
    z[6,2,1]  R1384     -1.7618516087532043e-01
    z[6,2,1]  R1385     -5.4970139265060425e-01
    z[6,2,1]  R1386     -6.8831346929073334e-02
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1307     -1
    z[6,2,2]  R1308     1
    z[6,2,2]  R1317     -6.2255424261093140e-01
    z[6,2,2]  R1318     -7.4332630634307861e-01
    z[6,2,2]  R1319     -8.0464816093444824e-01
    z[6,2,2]  R1320     -6.0049152374267578e-01
    z[6,2,2]  R1321     -1.8468938767910004e-01
    z[6,2,2]  R1322     -7.3881131410598755e-01
    z[6,2,2]  R1323     -6.4745169878005981e-01
    z[6,2,2]  R1324     -8.3255708217620850e-01
    z[6,2,2]  R1325     -8.3497482538223267e-01
    z[6,2,2]  R1326     -3.6337402462959290e-01
    z[6,2,2]  R1327     3.0558711290359497e-01
    z[6,2,2]  R1328     5.8320814371109009e-01
    z[6,2,2]  R1329     2.4961875379085541e-01
    z[6,2,2]  R1330     2.9769837856292725e-01
    z[6,2,2]  R1331     2.1694932878017426e-01
    z[6,2,2]  R1332     2.8463923931121826e-01
    z[6,2,2]  R1333     2.0543260872364044e-01
    z[6,2,2]  R1334     2.0874388515949249e-01
    z[6,2,2]  R1335     0.381873220205307
    z[6,2,2]  R1336     3.4576156735420227e-01
    z[6,2,2]  R1337     1.0945479571819305e-01
    z[6,2,2]  R1338     -3.2285865396261215e-02
    z[6,2,2]  R1339     -5.2841058932244778e-03
    z[6,2,2]  R1340     2.2360880672931671e-01
    z[6,2,2]  R1341     3.1841287016868591e-01
    z[6,2,2]  R1342     -3.3113136887550354e-01
    z[6,2,2]  R1343     1.0439525544643402e-01
    z[6,2,2]  R1344     2.3203656077384949e-01
    z[6,2,2]  R1345     -1.0930939763784409e-01
    z[6,2,2]  R1346     2.4682506918907166e-01
    z[6,2,2]  R1347     -6.2499684095382690e-01
    z[6,2,2]  R1348     -2.2313027083873749e-01
    z[6,2,2]  R1349     -9.5440290868282318e-02
    z[6,2,2]  R1350     -6.9622255861759186e-02
    z[6,2,2]  R1351     -1.8771840631961823e-01
    z[6,2,2]  R1352     -2.8977859020233154e-01
    z[6,2,2]  R1353     0.0358751118183136
    z[6,2,2]  R1354     -1.8994650244712830e-01
    z[6,2,2]  R1355     -4.9565258622169495e-01
    z[6,2,2]  R1356     1.5451537072658539e-01
    z[6,2,2]  R1357     2.5536981225013733e-01
    z[6,2,2]  R1358     -8.0873884260654449e-02
    z[6,2,2]  R1359     -7.4643611907958984e-01
    z[6,2,2]  R1360     2.6601186394691467e-01
    z[6,2,2]  R1361     -3.3538267016410828e-01
    z[6,2,2]  R1362     3.3730635046958923e-01
    z[6,2,2]  R1363     -5.7383030652999878e-01
    z[6,2,2]  R1364     2.3722781240940094e-01
    z[6,2,2]  R1365     -1.4183494448661804e-01
    z[6,2,2]  R1366     -3.5477694869041443e-01
    z[6,2,2]  R1367     -3.4747142344713211e-02
    z[6,2,2]  R1368     4.0809872746467590e-01
    z[6,2,2]  R1369     -1.4974361658096313e-01
    z[6,2,2]  R1370     1.4509527385234833e-01
    z[6,2,2]  R1371     2.3709741234779358e-01
    z[6,2,2]  R1372     3.8914494216442108e-02
    z[6,2,2]  R1373     8.1839226186275482e-02
    z[6,2,2]  R1374     2.6590687036514282e-01
    z[6,2,2]  R1375     1.2773790955543518e-01
    z[6,2,2]  R1376     2.6197027415037155e-02
    z[6,2,2]  R1377     -1.7921912670135498e-01
    z[6,2,2]  R1378     -3.5935276746749878e-01
    z[6,2,2]  R1379     2.6201415061950684e-01
    z[6,2,2]  R1380     5.6552481651306152e-01
    z[6,2,2]  R1381     -1.4974561333656311e-01
    z[6,2,2]  R1382     -2.2675932943820953e-01
    z[6,2,2]  R1383     -4.1336383670568466e-02
    z[6,2,2]  R1384     1.3642235100269318e-01
    z[6,2,2]  R1385     6.8221598863601685e-01
    z[6,2,2]  R1386     -7.2196260094642639e-02
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1309     -1
    z[6,2,3]  R1310     1
    z[6,2,3]  R1317     -1.8421080708503723e-01
    z[6,2,3]  R1318     -2.9413759708404541e-02
    z[6,2,3]  R1319     1.6060025990009308e-01
    z[6,2,3]  R1320     1.5337137877941132e-01
    z[6,2,3]  R1321     3.9470937848091125e-01
    z[6,2,3]  R1322     1.2312074750661850e-01
    z[6,2,3]  R1323     -0.366982102394104
    z[6,2,3]  R1324     1.2864798307418823e-01
    z[6,2,3]  R1325     -8.5663378238677979e-02
    z[6,2,3]  R1326     -3.0126622319221497e-01
    z[6,2,3]  R1327     3.9039561152458191e-01
    z[6,2,3]  R1328     -4.7683459520339966e-01
    z[6,2,3]  R1329     -1.6152353584766388e-01
    z[6,2,3]  R1330     -2.0118415355682373e-01
    z[6,2,3]  R1331     3.3191543817520142e-01
    z[6,2,3]  R1332     4.8919060826301575e-01
    z[6,2,3]  R1333     -6.1220663785934448e-01
    z[6,2,3]  R1334     1.7509926855564117e-01
    z[6,2,3]  R1335     -4.7625014185905457e-01
    z[6,2,3]  R1336     4.8647928237915039e-01
    z[6,2,3]  R1337     -2.3330879211425781e-01
    z[6,2,3]  R1338     -6.9764018058776855e-02
    z[6,2,3]  R1339     2.6782515645027161e-01
    z[6,2,3]  R1340     -0.405845582485199
    z[6,2,3]  R1341     6.4888454973697662e-02
    z[6,2,3]  R1342     -3.8919255137443542e-01
    z[6,2,3]  R1343     1.6290649771690369e-01
    z[6,2,3]  R1344     -3.8584843277931213e-01
    z[6,2,3]  R1345     8.2914769649505615e-02
    z[6,2,3]  R1346     3.1777891516685486e-01
    z[6,2,3]  R1347     -2.1474552154541016e-01
    z[6,2,3]  R1348     1.8357586860656738e-01
    z[6,2,3]  R1349     6.8477582931518555e-01
    z[6,2,3]  R1350     1.3806837797164917e-01
    z[6,2,3]  R1351     -6.0245178639888763e-02
    z[6,2,3]  R1352     2.5885561108589172e-01
    z[6,2,3]  R1353     -4.7876462340354919e-01
    z[6,2,3]  R1354     -0.363491028547287
    z[6,2,3]  R1355     5.1065343618392944e-01
    z[6,2,3]  R1356     -3.0907431617379189e-02
    z[6,2,3]  R1357     6.9872546195983887e-01
    z[6,2,3]  R1358     -1.4361524581909180e-01
    z[6,2,3]  R1359     -1.6800025105476379e-01
    z[6,2,3]  R1360     -3.9234411716461182e-01
    z[6,2,3]  R1361     -1.6036370769143105e-02
    z[6,2,3]  R1362     3.7227776646614075e-01
    z[6,2,3]  R1363     3.9219167828559875e-01
    z[6,2,3]  R1364     2.6986068487167358e-01
    z[6,2,3]  R1365     3.6536210775375366e-01
    z[6,2,3]  R1366     2.0269700884819031e-01
    z[6,2,3]  R1367     -3.0786329880356789e-02
    z[6,2,3]  R1368     -3.0556395649909973e-01
    z[6,2,3]  R1369     -2.9215618968009949e-01
    z[6,2,3]  R1370     -3.1286829710006714e-01
    z[6,2,3]  R1371     1.5310217440128326e-01
    z[6,2,3]  R1372     -2.8971329331398010e-01
    z[6,2,3]  R1373     -3.9567741751670837e-01
    z[6,2,3]  R1374     -3.3423423767089844e-01
    z[6,2,3]  R1375     -3.4821224212646484e-01
    z[6,2,3]  R1376     -2.6191130280494690e-01
    z[6,2,3]  R1377     8.6467579007148743e-02
    z[6,2,3]  R1378     1.3405305147171021e-01
    z[6,2,3]  R1379     1.1523726396262646e-02
    z[6,2,3]  R1380     1.6345396637916565e-01
    z[6,2,3]  R1381     1.2899482250213623e-01
    z[6,2,3]  R1382     6.1010837554931641e-02
    z[6,2,3]  R1383     2.9394409060478210e-01
    z[6,2,3]  R1384     0.0871608629822731
    z[6,2,3]  R1385     -2.4624569714069366e-01
    z[6,2,3]  R1386     -1.4056387543678284e-01
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1311     -1
    z[6,2,4]  R1312     1
    z[6,2,4]  R1317     -6.3743394613265991e-01
    z[6,2,4]  R1318     -1.3657073676586151e-01
    z[6,2,4]  R1319     -2.7995908260345459e-01
    z[6,2,4]  R1320     -5.8870977163314819e-01
    z[6,2,4]  R1321     -8.1852513551712036e-01
    z[6,2,4]  R1322     8.7458200752735138e-02
    z[6,2,4]  R1323     -4.6370047330856323e-01
    z[6,2,4]  R1324     1.2290842831134796e-01
    z[6,2,4]  R1325     -6.2325045466423035e-02
    z[6,2,4]  R1326     -7.8452903032302856e-01
    z[6,2,4]  R1327     8.9119784533977509e-02
    z[6,2,4]  R1328     1.4148251712322235e-01
    z[6,2,4]  R1329     1.2777429819107056e-01
    z[6,2,4]  R1330     1.1681786179542542e-01
    z[6,2,4]  R1331     3.0304929614067078e-01
    z[6,2,4]  R1332     -6.9315090775489807e-02
    z[6,2,4]  R1333     4.2483016848564148e-01
    z[6,2,4]  R1334     1.8962581455707550e-01
    z[6,2,4]  R1335     1.5284567140042782e-02
    z[6,2,4]  R1336     2.2329214215278625e-01
    z[6,2,4]  R1337     -3.4885589033365250e-02
    z[6,2,4]  R1338     -5.6437385082244873e-01
    z[6,2,4]  R1339     -3.9155066013336182e-01
    z[6,2,4]  R1340     6.4252310991287231e-01
    z[6,2,4]  R1341     -1.9448530673980713e-01
    z[6,2,4]  R1342     -5.9565279632806778e-02
    z[6,2,4]  R1343     4.3613232672214508e-02
    z[6,2,4]  R1344     -1.6706696152687073e-01
    z[6,2,4]  R1345     1.5945152938365936e-01
    z[6,2,4]  R1346     -0.700086772441864
    z[6,2,4]  R1347     -8.6237683892250061e-02
    z[6,2,4]  R1348     2.8281274437904358e-01
    z[6,2,4]  R1349     -1.9821323454380035e-01
    z[6,2,4]  R1350     -1.6417573392391205e-01
    z[6,2,4]  R1351     1.9250491261482239e-01
    z[6,2,4]  R1352     5.5724793672561646e-01
    z[6,2,4]  R1353     2.7393159270286560e-01
    z[6,2,4]  R1354     1.7277634143829346e-01
    z[6,2,4]  R1355     0.624572217464447
    z[6,2,4]  R1356     0.0839446485042572
    z[6,2,4]  R1357     -2.9354941099882126e-02
    z[6,2,4]  R1358     -2.7737346291542053e-01
    z[6,2,4]  R1359     -3.6460742354393005e-02
    z[6,2,4]  R1360     3.5273800604045391e-03
    z[6,2,4]  R1361     -2.1476107835769653e-01
    z[6,2,4]  R1362     -2.2934643551707268e-02
    z[6,2,4]  R1363     -7.9072043299674988e-02
    z[6,2,4]  R1364     -3.5760810971260071e-01
    z[6,2,4]  R1365     -7.7128744125366211e-01
    z[6,2,4]  R1366     -3.8145750761032104e-01
    z[6,2,4]  R1367     7.3071740567684174e-02
    z[6,2,4]  R1368     -1.4902658760547638e-01
    z[6,2,4]  R1369     3.9553143084049225e-02
    z[6,2,4]  R1370     2.0750153809785843e-02
    z[6,2,4]  R1371     2.4105429649353027e-01
    z[6,2,4]  R1372     1.7101193964481354e-01
    z[6,2,4]  R1373     0.0950782373547554
    z[6,2,4]  R1374     -1.0960499197244644e-01
    z[6,2,4]  R1375     1.5725545585155487e-01
    z[6,2,4]  R1376     1.2200789898633957e-01
    z[6,2,4]  R1377     2.8890535235404968e-01
    z[6,2,4]  R1378     4.3241629004478455e-01
    z[6,2,4]  R1379     -6.0956722497940063e-01
    z[6,2,4]  R1380     3.5223352909088135e-01
    z[6,2,4]  R1381     -1.6913086175918579e-01
    z[6,2,4]  R1382     1.9742825627326965e-01
    z[6,2,4]  R1383     0.330597460269928
    z[6,2,4]  R1384     -7.7031159400939941e-01
    z[6,2,4]  R1385     8.4561698138713837e-02
    z[6,2,4]  R1386     3.0646726489067078e-02
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1313     -1
    z[6,2,5]  R1314     1
    z[6,2,5]  R1317     2.0146530866622925e-01
    z[6,2,5]  R1318     1.3990907371044159e-01
    z[6,2,5]  R1319     3.3354374766349792e-01
    z[6,2,5]  R1320     3.0304759740829468e-01
    z[6,2,5]  R1321     3.3876052498817444e-01
    z[6,2,5]  R1322     3.4586733579635620e-01
    z[6,2,5]  R1323     2.0835934579372406e-01
    z[6,2,5]  R1324     2.6599800586700439e-01
    z[6,2,5]  R1325     4.1952362656593323e-01
    z[6,2,5]  R1326     4.9756024032831192e-02
    z[6,2,5]  R1327     -1.2804748117923737e-01
    z[6,2,5]  R1328     5.2556627988815308e-01
    z[6,2,5]  R1329     -1.1099065840244293e-01
    z[6,2,5]  R1330     -5.7539731264114380e-02
    z[6,2,5]  R1331     -2.8323435783386230e-01
    z[6,2,5]  R1332     -1.1019649356603622e-01
    z[6,2,5]  R1333     3.2817018032073975e-01
    z[6,2,5]  R1334     -1.2396162748336792e-01
    z[6,2,5]  R1335     -1.2915004789829254e-01
    z[6,2,5]  R1336     -2.5686267018318176e-01
    z[6,2,5]  R1337     -3.6452582478523254e-01
    z[6,2,5]  R1338     5.6535284966230392e-02
    z[6,2,5]  R1339     4.9025887250900269e-01
    z[6,2,5]  R1340     -2.7779844403266907e-01
    z[6,2,5]  R1341     6.3344120979309082e-01
    z[6,2,5]  R1342     6.5751016139984131e-01
    z[6,2,5]  R1343     -6.4349383115768433e-02
    z[6,2,5]  R1344     -1.0267642885446548e-01
    z[6,2,5]  R1345     7.5395655632019043e-01
    z[6,2,5]  R1346     -2.2027517855167389e-01
    z[6,2,5]  R1347     -1.9749562442302704e-01
    z[6,2,5]  R1348     1.4104568958282471e-01
    z[6,2,5]  R1349     -8.9955426752567291e-02
    z[6,2,5]  R1350     1.8768961727619171e-01
    z[6,2,5]  R1351     -4.1778244078159332e-02
    z[6,2,5]  R1352     -2.9994806647300720e-01
    z[6,2,5]  R1353     -1.2022332102060318e-01
    z[6,2,5]  R1354     -1.8738360702991486e-01
    z[6,2,5]  R1355     1.8032878637313843e-01
    z[6,2,5]  R1356     -1.3821698725223541e-01
    z[6,2,5]  R1357     3.7134058773517609e-02
    z[6,2,5]  R1358     -4.3836227059364319e-01
    z[6,2,5]  R1359     1.6207601130008698e-01
    z[6,2,5]  R1360     2.8912666440010071e-01
    z[6,2,5]  R1361     1.7371119558811188e-01
    z[6,2,5]  R1362     -2.8155824542045593e-01
    z[6,2,5]  R1363     -3.3294427394866943e-01
    z[6,2,5]  R1364     -3.1217607855796814e-01
    z[6,2,5]  R1365     1.6681528091430664e-01
    z[6,2,5]  R1366     -7.6324068009853363e-02
    z[6,2,5]  R1367     5.9478396177291870e-01
    z[6,2,5]  R1368     1.4739955961704254e-01
    z[6,2,5]  R1369     3.1917652487754822e-01
    z[6,2,5]  R1370     -1.3296452164649963e-01
    z[6,2,5]  R1371     2.2613622248172760e-02
    z[6,2,5]  R1372     -1.2087034434080124e-01
    z[6,2,5]  R1373     -2.4794960021972656e-01
    z[6,2,5]  R1374     -0.0900367721915245
    z[6,2,5]  R1375     -2.2938187420368195e-01
    z[6,2,5]  R1376     -9.6857078373432159e-02
    z[6,2,5]  R1377     -2.5553047657012939e-01
    z[6,2,5]  R1378     2.6781976222991943e-01
    z[6,2,5]  R1379     1.7074239253997803e-01
    z[6,2,5]  R1380     1.9964082539081573e-01
    z[6,2,5]  R1381     -3.0739307403564453e-02
    z[6,2,5]  R1382     -5.4868847131729126e-01
    z[6,2,5]  R1383     1.5081061422824860e-01
    z[6,2,5]  R1384     5.5249845609068871e-03
    z[6,2,5]  R1385     -8.0237448215484619e-02
    z[6,2,5]  R1386     -5.4287576675415039e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1315     -1
    z[6,2,6]  R1316     1
    z[6,2,6]  R1317     2.9068502783775330e-01
    z[6,2,6]  R1318     2.8227454423904419e-01
    z[6,2,6]  R1319     1.7670619487762451e-01
    z[6,2,6]  R1320     -1.1906898766756058e-01
    z[6,2,6]  R1321     -1.2550881505012512e-01
    z[6,2,6]  R1322     -5.1650381088256836e-01
    z[6,2,6]  R1323     -4.2562881112098694e-01
    z[6,2,6]  R1324     0.447286456823349
    z[6,2,6]  R1325     -2.2831052541732788e-02
    z[6,2,6]  R1326     -1.1260929703712463e-01
    z[6,2,6]  R1327     1.2358459830284119e-01
    z[6,2,6]  R1328     0.00592637388035655
    z[6,2,6]  R1329     -1.7166891694068909e-01
    z[6,2,6]  R1330     6.7347057163715363e-02
    z[6,2,6]  R1331     5.3730695508420467e-03
    z[6,2,6]  R1332     -7.0308116264641285e-03
    z[6,2,6]  R1333     -2.6035559177398682e-01
    z[6,2,6]  R1334     -5.4442346096038818e-02
    z[6,2,6]  R1335     -2.9928541183471680e-01
    z[6,2,6]  R1336     -4.4294662773609161e-02
    z[6,2,6]  R1337     3.9246085286140442e-01
    z[6,2,6]  R1338     5.1586157083511353e-01
    z[6,2,6]  R1339     6.9776542484760284e-02
    z[6,2,6]  R1340     2.9474783688783646e-02
    z[6,2,6]  R1341     -8.5204273462295532e-02
    z[6,2,6]  R1342     1.3028287887573242e-01
    z[6,2,6]  R1343     -6.7805522680282593e-01
    z[6,2,6]  R1344     -6.6481471061706543e-01
    z[6,2,6]  R1345     0.299459844827652
    z[6,2,6]  R1346     -1.1630912870168686e-01
    z[6,2,6]  R1347     -2.8347286581993103e-01
    z[6,2,6]  R1348     -4.8547599464654922e-02
    z[6,2,6]  R1349     3.9975982904434204e-01
    z[6,2,6]  R1350     -6.5692657232284546e-01
    z[6,2,6]  R1351     -6.9269323348999023e-01
    z[6,2,6]  R1352     1.5495055913925171e-01
    z[6,2,6]  R1353     4.4680300354957581e-01
    z[6,2,6]  R1354     7.6224094629287720e-01
    z[6,2,6]  R1355     -6.8241044878959656e-02
    z[6,2,6]  R1356     8.2412803173065186e-01
    z[6,2,6]  R1357     6.6858351230621338e-02
    z[6,2,6]  R1358     0.259028822183609
    z[6,2,6]  R1359     1.5027964115142822e-01
    z[6,2,6]  R1360     -5.2211493253707886e-01
    z[6,2,6]  R1361     -5.9342807531356812e-01
    z[6,2,6]  R1362     -2.6496127247810364e-01
    z[6,2,6]  R1363     -1.9309477508068085e-01
    z[6,2,6]  R1364     2.5463435053825378e-01
    z[6,2,6]  R1365     -3.3253121655434370e-03
    z[6,2,6]  R1366     5.3472322225570679e-01
    z[6,2,6]  R1367     2.6953560113906860e-01
    z[6,2,6]  R1368     2.3360078036785126e-01
    z[6,2,6]  R1369     -2.3991394042968750e-01
    z[6,2,6]  R1370     6.4353114366531372e-01
    z[6,2,6]  R1371     5.7192766666412354e-01
    z[6,2,6]  R1372     -2.5998631026595831e-03
    z[6,2,6]  R1373     -1.0083127021789551e-01
    z[6,2,6]  R1374     -4.3489582836627960e-02
    z[6,2,6]  R1375     2.2829528152942657e-01
    z[6,2,6]  R1376     6.7231371998786926e-02
    z[6,2,6]  R1377     2.5963285565376282e-01
    z[6,2,6]  R1378     -1.4824126660823822e-01
    z[6,2,6]  R1379     -1.5896141529083252e-01
    z[6,2,6]  R1380     1.8201065063476562e-01
    z[6,2,6]  R1381     7.2573626041412354e-01
    z[6,2,6]  R1382     4.1801032423973083e-01
    z[6,2,6]  R1383     3.6519128084182739e-01
    z[6,2,6]  R1384     3.3364954590797424e-01
    z[6,2,6]  R1385     1.8068379163742065e-01
    z[6,2,6]  R1386     -1.0695316828787327e-02
    z[2,7,0]  R20       -1
    z[2,7,0]  R65       1
    z[2,7,0]  R1387     -1
    z[2,7,0]  R1388     1
    z[2,7,0]  R1401     -5.8756476640701294e-01
    z[2,7,0]  R1402     -7.9760897159576416e-01
    z[2,7,0]  R1403     -5.8294034004211426e-01
    z[2,7,0]  R1404     -6.3656675815582275e-01
    z[2,7,0]  R1405     0.000665637431666255
    z[2,7,0]  R1406     3.4158188104629517e-01
    z[2,7,0]  R1407     3.1974050402641296e-01
    z[2,7,0]  R1408     3.4665313363075256e-01
    z[2,7,0]  R1409     1.9608055055141449e-01
    z[2,7,0]  R1410     6.2233191728591919e-01
    z[2,7,0]  R1411     1.2805898487567902e-01
    z[2,7,0]  R1412     2.9837599396705627e-01
    z[2,7,0]  R1413     5.3156417608261108e-01
    z[2,7,0]  R1414     3.4490948915481567e-01
    z[2,7,0]  R1415     5.7030439376831055e-01
    z[2,7,0]  R1416     9.3179166316986084e-01
    z[2,7,0]  R1417     8.4341913461685181e-01
    z[2,7,0]  R1418     8.8378113508224487e-01
    z[2,7,0]  R1419     8.3961808681488037e-01
    z[2,7,0]  R1420     8.8593792915344238e-01
    z[2,7,0]  R1421     1.4354000985622406e-01
    z[2,7,0]  R1422     0.34108966588974
    z[2,7,0]  R1423     1.1674237251281738e-01
    z[2,7,0]  R1424     1.1136688292026520e-01
    z[2,7,0]  R1425     4.5378932356834412e-01
    z[2,7,0]  R1426     4.1349762678146362e-01
    z[2,7,0]  R1427     6.7828559875488281e-01
    z[2,7,0]  R1428     4.8787105083465576e-01
    z[2,7,0]  R1429     3.5431259870529175e-01
    z[2,7,0]  R1430     8.2129406929016113e-01
    z[2,7,0]  R1431     3.5147759318351746e-01
    z[2,7,0]  R1432     4.0883067995309830e-02
    z[2,7,0]  R1433     2.7442533522844315e-02
    z[2,7,0]  R1434     -2.2505679726600647e-01
    z[2,7,0]  R1435     -1.7047492787241936e-02
    z[2,7,0]  R1436     -3.7297993898391724e-01
    z[2,7,0]  R1437     -2.7726629376411438e-01
    z[2,7,0]  R1438     -3.5951441526412964e-01
    z[2,7,0]  R1439     -9.3873977661132812e-02
    z[2,7,0]  R1440     2.9853138327598572e-01
    z[2,7,0]  R1441     -4.2799907922744751e-01
    z[2,7,0]  R1442     -6.0560190677642822e-01
    z[2,7,0]  R1443     -5.3953188657760620e-01
    z[2,7,0]  R1444     -2.5984960794448853e-01
    z[2,7,0]  R1445     -6.4778298139572144e-01
    z[2,7,0]  R1446     -4.1700929403305054e-01
    z[2,7,0]  R1447     -0.385744571685791
    z[2,7,0]  R1448     -1.8221004307270050e-01
    z[2,7,0]  R1449     -4.7696086764335632e-01
    z[2,7,0]  R1450     -3.6791044473648071e-01
    z[2,7,0]  R1451     -3.4008061885833740e-01
    z[2,7,0]  R1452     -2.2818570956587791e-02
    z[2,7,0]  R1453     3.9294874668121338e-01
    z[2,7,0]  R1454     -3.0102510005235672e-02
    z[2,7,0]  R1455     -0.400037944316864
    z[2,7,0]  R1456     -5.7290811091661453e-02
    z[2,7,0]  R1457     -6.6945418715476990e-02
    z[2,7,0]  R1458     -2.1001422405242920e-01
    z[2,7,0]  R1459     -4.1027206182479858e-01
    z[2,7,0]  R1460     -2.4204806983470917e-01
    z[2,7,0]  R1461     4.5590800046920776e-01
    z[2,7,0]  R1462     6.5800681710243225e-02
    z[2,7,0]  R1463     -6.0763758420944214e-01
    z[2,7,0]  R1464     -3.2962110638618469e-01
    z[2,7,0]  R1465     1.6704581677913666e-01
    z[2,7,0]  R1466     -2.8840294480323792e-01
    z[2,7,0]  R1467     -1.5888524055480957e-01
    z[2,7,0]  R1468     1.8819020688533783e-01
    z[2,7,0]  R1469     -6.0815680772066116e-03
    z[2,7,0]  R1470     -3.5370126366615295e-01
    z[2,7,1]  R21       -1
    z[2,7,1]  R66       1
    z[2,7,1]  R1389     -1
    z[2,7,1]  R1390     1
    z[2,7,1]  R1401     -3.0761319398880005e-01
    z[2,7,1]  R1402     -2.1458260715007782e-02
    z[2,7,1]  R1403     -1.5686792135238647e-01
    z[2,7,1]  R1404     -1.1779581010341644e-01
    z[2,7,1]  R1405     -6.7735219001770020e-01
    z[2,7,1]  R1406     0.693505585193634
    z[2,7,1]  R1407     5.1017683744430542e-01
    z[2,7,1]  R1408     0.678641140460968
    z[2,7,1]  R1409     4.3037557601928711e-01
    z[2,7,1]  R1410     -9.2120125889778137e-02
    z[2,7,1]  R1411     7.4141013622283936e-01
    z[2,7,1]  R1412     7.4333906173706055e-01
    z[2,7,1]  R1413     6.6982412338256836e-01
    z[2,7,1]  R1414     -5.7433068752288818e-01
    z[2,7,1]  R1415     -4.5757806301116943e-01
    z[2,7,1]  R1416     4.9543965607881546e-02
    z[2,7,1]  R1417     2.1142403781414032e-01
    z[2,7,1]  R1418     1.2041904032230377e-01
    z[2,7,1]  R1419     1.6735802590847015e-01
    z[2,7,1]  R1420     3.4211522340774536e-01
    z[2,7,1]  R1421     8.5066372156143188e-01
    z[2,7,1]  R1422     6.7517876625061035e-01
    z[2,7,1]  R1423     7.0113706588745117e-01
    z[2,7,1]  R1424     0.666340172290802
    z[2,7,1]  R1425     -4.4583463668823242e-01
    z[2,7,1]  R1426     -5.0902652740478516e-01
    z[2,7,1]  R1427     -4.3175652623176575e-01
    z[2,7,1]  R1428     -1.7618516087532043e-01
    z[2,7,1]  R1429     -5.4970139265060425e-01
    z[2,7,1]  R1430     -6.8831346929073334e-02
    z[2,7,1]  R1431     5.3772604465484619e-01
    z[2,7,1]  R1432     7.2924906015396118e-01
    z[2,7,1]  R1433     9.2543345689773560e-01
    z[2,7,1]  R1434     6.6633814573287964e-01
    z[2,7,1]  R1435     6.6368007659912109e-01
    z[2,7,1]  R1436     0.721071183681488
    z[2,7,1]  R1437     5.9860116243362427e-01
    z[2,7,1]  R1438     4.9381405115127563e-01
    z[2,7,1]  R1439     6.9966787099838257e-01
    z[2,7,1]  R1440     7.3879170417785645e-01
    z[2,7,1]  R1441     -5.5943650007247925e-01
    z[2,7,1]  R1442     -6.1637800931930542e-01
    z[2,7,1]  R1443     -4.9711513519287109e-01
    z[2,7,1]  R1444     -6.9946968555450439e-01
    z[2,7,1]  R1445     -4.3509474396705627e-01
    z[2,7,1]  R1446     -0.527397096157074
    z[2,7,1]  R1447     -6.5380924940109253e-01
    z[2,7,1]  R1448     -3.6172983050346375e-01
    z[2,7,1]  R1449     -6.5000897645950317e-01
    z[2,7,1]  R1450     -4.8431155085563660e-01
    z[2,7,1]  R1451     -8.0435746908187866e-01
    z[2,7,1]  R1452     -8.4212523698806763e-01
    z[2,7,1]  R1453     2.9639837145805359e-01
    z[2,7,1]  R1454     -0.961946427822113
    z[2,7,1]  R1455     -7.6187348365783691e-01
    z[2,7,1]  R1456     -7.0618337392807007e-01
    z[2,7,1]  R1457     -0.890663206577301
    z[2,7,1]  R1458     -7.6029217243194580e-01
    z[2,7,1]  R1459     -8.0137866735458374e-01
    z[2,7,1]  R1460     -7.0838910341262817e-01
    z[2,7,1]  R1461     5.2064180374145508e-01
    z[2,7,1]  R1462     5.1355838775634766e-01
    z[2,7,1]  R1463     4.3847480416297913e-01
    z[2,7,1]  R1464     1.5662458539009094e-01
    z[2,7,1]  R1465     3.8802614808082581e-01
    z[2,7,1]  R1466     -8.2546448707580566e-01
    z[2,7,1]  R1467     -8.1400001049041748e-01
    z[2,7,1]  R1468     -1.3649834692478180e-01
    z[2,7,1]  R1469     -7.3540627956390381e-01
    z[2,7,1]  R1470     -7.2362780570983887e-01
    z[2,7,2]  R22       -1
    z[2,7,2]  R67       1
    z[2,7,2]  R1391     -1
    z[2,7,2]  R1392     1
    z[2,7,2]  R1401     2.5536981225013733e-01
    z[2,7,2]  R1402     -8.0873884260654449e-02
    z[2,7,2]  R1403     -7.4643611907958984e-01
    z[2,7,2]  R1404     2.6601186394691467e-01
    z[2,7,2]  R1405     -3.3538267016410828e-01
    z[2,7,2]  R1406     3.3730635046958923e-01
    z[2,7,2]  R1407     -5.7383030652999878e-01
    z[2,7,2]  R1408     2.3722781240940094e-01
    z[2,7,2]  R1409     -1.4183494448661804e-01
    z[2,7,2]  R1410     -3.5477694869041443e-01
    z[2,7,2]  R1411     -3.4747142344713211e-02
    z[2,7,2]  R1412     4.0809872746467590e-01
    z[2,7,2]  R1413     -1.4974361658096313e-01
    z[2,7,2]  R1414     1.4509527385234833e-01
    z[2,7,2]  R1415     2.3709741234779358e-01
    z[2,7,2]  R1416     3.8914494216442108e-02
    z[2,7,2]  R1417     8.1839226186275482e-02
    z[2,7,2]  R1418     2.6590687036514282e-01
    z[2,7,2]  R1419     1.2773790955543518e-01
    z[2,7,2]  R1420     2.6197027415037155e-02
    z[2,7,2]  R1421     -1.7921912670135498e-01
    z[2,7,2]  R1422     -3.5935276746749878e-01
    z[2,7,2]  R1423     2.6201415061950684e-01
    z[2,7,2]  R1424     5.6552481651306152e-01
    z[2,7,2]  R1425     -1.4974561333656311e-01
    z[2,7,2]  R1426     -2.2675932943820953e-01
    z[2,7,2]  R1427     -4.1336383670568466e-02
    z[2,7,2]  R1428     1.3642235100269318e-01
    z[2,7,2]  R1429     6.8221598863601685e-01
    z[2,7,2]  R1430     -7.2196260094642639e-02
    z[2,7,2]  R1431     -4.1262698173522949e-01
    z[2,7,2]  R1432     0.0496567003428936
    z[2,7,2]  R1433     4.4755268841981888e-02
    z[2,7,2]  R1434     -1.4815372228622437e-01
    z[2,7,2]  R1435     4.2813235521316528e-01
    z[2,7,2]  R1436     4.5968118309974670e-01
    z[2,7,2]  R1437     4.1569215059280396e-01
    z[2,7,2]  R1438     7.5898277573287487e-03
    z[2,7,2]  R1439     4.0898427367210388e-01
    z[2,7,2]  R1440     1.3869714736938477e-01
    z[2,7,2]  R1441     -5.3591018915176392e-01
    z[2,7,2]  R1442     -2.2801041603088379e-01
    z[2,7,2]  R1443     -0.516657292842865
    z[2,7,2]  R1444     -4.0650996565818787e-01
    z[2,7,2]  R1445     -5.9381824731826782e-01
    z[2,7,2]  R1446     -2.7623388171195984e-01
    z[2,7,2]  R1447     -5.0986176729202271e-01
    z[2,7,2]  R1448     -6.9064414501190186e-01
    z[2,7,2]  R1449     -4.5217093825340271e-01
    z[2,7,2]  R1450     -0.56244957447052
    z[2,7,2]  R1451     1.9406144320964813e-01
    z[2,7,2]  R1452     2.8965404629707336e-01
    z[2,7,2]  R1453     3.4909170120954514e-02
    z[2,7,2]  R1454     6.5579958260059357e-02
    z[2,7,2]  R1455     3.9618015289306641e-01
    z[2,7,2]  R1456     -2.8757303953170776e-01
    z[2,7,2]  R1457     1.5739649534225464e-01
    z[2,7,2]  R1458     4.0723752975463867e-01
    z[2,7,2]  R1459     3.6946651339530945e-01
    z[2,7,2]  R1460     2.5820541381835938e-01
    z[2,7,2]  R1461     0.0326387919485569
    z[2,7,2]  R1462     6.7335285246372223e-02
    z[2,7,2]  R1463     2.7764764428138733e-01
    z[2,7,2]  R1464     5.3151077032089233e-01
    z[2,7,2]  R1465     -2.2476732730865479e-01
    z[2,7,2]  R1466     1.9603857398033142e-01
    z[2,7,2]  R1467     -3.0395476147532463e-02
    z[2,7,2]  R1468     1.5812179446220398e-01
    z[2,7,2]  R1469     -1.8200913071632385e-01
    z[2,7,2]  R1470     7.9307332634925842e-03
    z[2,7,3]  R23       -1
    z[2,7,3]  R68       1
    z[2,7,3]  R1393     -1
    z[2,7,3]  R1394     1
    z[2,7,3]  R1401     6.9872546195983887e-01
    z[2,7,3]  R1402     -1.4361524581909180e-01
    z[2,7,3]  R1403     -1.6800025105476379e-01
    z[2,7,3]  R1404     -3.9234411716461182e-01
    z[2,7,3]  R1405     -1.6036370769143105e-02
    z[2,7,3]  R1406     3.7227776646614075e-01
    z[2,7,3]  R1407     3.9219167828559875e-01
    z[2,7,3]  R1408     2.6986068487167358e-01
    z[2,7,3]  R1409     3.6536210775375366e-01
    z[2,7,3]  R1410     2.0269700884819031e-01
    z[2,7,3]  R1411     -3.0786329880356789e-02
    z[2,7,3]  R1412     -3.0556395649909973e-01
    z[2,7,3]  R1413     -2.9215618968009949e-01
    z[2,7,3]  R1414     -3.1286829710006714e-01
    z[2,7,3]  R1415     1.5310217440128326e-01
    z[2,7,3]  R1416     -2.8971329331398010e-01
    z[2,7,3]  R1417     -3.9567741751670837e-01
    z[2,7,3]  R1418     -3.3423423767089844e-01
    z[2,7,3]  R1419     -3.4821224212646484e-01
    z[2,7,3]  R1420     -2.6191130280494690e-01
    z[2,7,3]  R1421     8.6467579007148743e-02
    z[2,7,3]  R1422     1.3405305147171021e-01
    z[2,7,3]  R1423     1.1523726396262646e-02
    z[2,7,3]  R1424     1.6345396637916565e-01
    z[2,7,3]  R1425     1.2899482250213623e-01
    z[2,7,3]  R1426     6.1010837554931641e-02
    z[2,7,3]  R1427     2.9394409060478210e-01
    z[2,7,3]  R1428     0.0871608629822731
    z[2,7,3]  R1429     -2.4624569714069366e-01
    z[2,7,3]  R1430     -1.4056387543678284e-01
    z[2,7,3]  R1431     4.5000296831130981e-01
    z[2,7,3]  R1432     6.3621246814727783e-01
    z[2,7,3]  R1433     -1.7492806538939476e-02
    z[2,7,3]  R1434     2.7972223237156868e-02
    z[2,7,3]  R1435     3.7851759791374207e-01
    z[2,7,3]  R1436     1.3253663666546345e-02
    z[2,7,3]  R1437     4.3476754426956177e-01
    z[2,7,3]  R1438     4.7934412956237793e-01
    z[2,7,3]  R1439     1.6339744627475739e-01
    z[2,7,3]  R1440     4.8957455158233643e-01
    z[2,7,3]  R1441     -1.4709731936454773e-01
    z[2,7,3]  R1442     -2.5882723927497864e-01
    z[2,7,3]  R1443     -2.1688246726989746e-01
    z[2,7,3]  R1444     -4.6647912263870239e-01
    z[2,7,3]  R1445     -8.3207428455352783e-02
    z[2,7,3]  R1446     -5.6877774000167847e-01
    z[2,7,3]  R1447     -3.0903410911560059e-01
    z[2,7,3]  R1448     -4.6563339233398438e-01
    z[2,7,3]  R1449     -3.3741500973701477e-01
    z[2,7,3]  R1450     -5.4462337493896484e-01
    z[2,7,3]  R1451     -1.7232039570808411e-01
    z[2,7,3]  R1452     -2.1759833395481110e-01
    z[2,7,3]  R1453     -6.5985542535781860e-01
    z[2,7,3]  R1454     2.0762298256158829e-02
    z[2,7,3]  R1455     -7.8155420720577240e-02
    z[2,7,3]  R1456     -0.406417578458786
    z[2,7,3]  R1457     6.5221287310123444e-02
    z[2,7,3]  R1458     0.0881512239575386
    z[2,7,3]  R1459     1.3524082303047180e-01
    z[2,7,3]  R1460     -2.6688039302825928e-01
    z[2,7,3]  R1461     0.33226278424263
    z[2,7,3]  R1462     3.9146417379379272e-01
    z[2,7,3]  R1463     -8.0085076391696930e-02
    z[2,7,3]  R1464     1.9872041046619415e-01
    z[2,7,3]  R1465     -4.8493242263793945e-01
    z[2,7,3]  R1466     -4.0307980775833130e-01
    z[2,7,3]  R1467     -4.5969793200492859e-01
    z[2,7,3]  R1468     7.2684627771377563e-01
    z[2,7,3]  R1469     -6.3669097423553467e-01
    z[2,7,3]  R1470     -0.288517564535141
    z[2,7,4]  R24       -1
    z[2,7,4]  R69       1
    z[2,7,4]  R1395     -1
    z[2,7,4]  R1396     1
    z[2,7,4]  R1401     -2.9354941099882126e-02
    z[2,7,4]  R1402     -2.7737346291542053e-01
    z[2,7,4]  R1403     -3.6460742354393005e-02
    z[2,7,4]  R1404     3.5273800604045391e-03
    z[2,7,4]  R1405     -2.1476107835769653e-01
    z[2,7,4]  R1406     -2.2934643551707268e-02
    z[2,7,4]  R1407     -7.9072043299674988e-02
    z[2,7,4]  R1408     -3.5760810971260071e-01
    z[2,7,4]  R1409     -7.7128744125366211e-01
    z[2,7,4]  R1410     -3.8145750761032104e-01
    z[2,7,4]  R1411     7.3071740567684174e-02
    z[2,7,4]  R1412     -1.4902658760547638e-01
    z[2,7,4]  R1413     3.9553143084049225e-02
    z[2,7,4]  R1414     2.0750153809785843e-02
    z[2,7,4]  R1415     2.4105429649353027e-01
    z[2,7,4]  R1416     1.7101193964481354e-01
    z[2,7,4]  R1417     0.0950782373547554
    z[2,7,4]  R1418     -1.0960499197244644e-01
    z[2,7,4]  R1419     1.5725545585155487e-01
    z[2,7,4]  R1420     1.2200789898633957e-01
    z[2,7,4]  R1421     2.8890535235404968e-01
    z[2,7,4]  R1422     4.3241629004478455e-01
    z[2,7,4]  R1423     -6.0956722497940063e-01
    z[2,7,4]  R1424     3.5223352909088135e-01
    z[2,7,4]  R1425     -1.6913086175918579e-01
    z[2,7,4]  R1426     1.9742825627326965e-01
    z[2,7,4]  R1427     0.330597460269928
    z[2,7,4]  R1428     -7.7031159400939941e-01
    z[2,7,4]  R1429     8.4561698138713837e-02
    z[2,7,4]  R1430     3.0646726489067078e-02
    z[2,7,4]  R1431     1.3001147657632828e-02
    z[2,7,4]  R1432     -8.7179347872734070e-02
    z[2,7,4]  R1433     1.6161532700061798e-01
    z[2,7,4]  R1434     2.5822514295578003e-01
    z[2,7,4]  R1435     -2.0004893839359283e-01
    z[2,7,4]  R1436     -2.4194066226482391e-01
    z[2,7,4]  R1437     2.6647615432739258e-01
    z[2,7,4]  R1438     -7.0569347590208054e-03
    z[2,7,4]  R1439     -0.457533061504364
    z[2,7,4]  R1440     2.6290962100028992e-01
    z[2,7,4]  R1441     -4.0289908647537231e-01
    z[2,7,4]  R1442     -3.5442799329757690e-01
    z[2,7,4]  R1443     -1.9329233467578888e-01
    z[2,7,4]  R1444     -2.1037788689136505e-01
    z[2,7,4]  R1445     -6.5850298851728439e-03
    z[2,7,4]  R1446     -3.7085208296775818e-01
    z[2,7,4]  R1447     6.4554825425148010e-02
    z[2,7,4]  R1448     -3.6159214377403259e-01
    z[2,7,4]  R1449     5.0317924469709396e-02
    z[2,7,4]  R1450     2.5089766830205917e-02
    z[2,7,4]  R1451     3.2245415449142456e-01
    z[2,7,4]  R1452     2.0978122949600220e-01
    z[2,7,4]  R1453     -4.8044338822364807e-01
    z[2,7,4]  R1454     -2.4499568343162537e-01
    z[2,7,4]  R1455     2.1332244575023651e-01
    z[2,7,4]  R1456     2.6873627305030823e-01
    z[2,7,4]  R1457     4.2627118527889252e-03
    z[2,7,4]  R1458     4.1220989823341370e-01
    z[2,7,4]  R1459     1.0254800319671631e-01
    z[2,7,4]  R1460     -3.0259862542152405e-01
    z[2,7,4]  R1461     4.2819178104400635e-01
    z[2,7,4]  R1462     -0.486828088760376
    z[2,7,4]  R1463     1.7520861327648163e-01
    z[2,7,4]  R1464     6.8648862838745117e-01
    z[2,7,4]  R1465     -5.6398731470108032e-01
    z[2,7,4]  R1466     2.6229554787278175e-02
    z[2,7,4]  R1467     2.8796127438545227e-01
    z[2,7,4]  R1468     3.1456348299980164e-01
    z[2,7,4]  R1469     -4.3707441538572311e-02
    z[2,7,4]  R1470     -4.1453507542610168e-01
    z[2,7,5]  R25       -1
    z[2,7,5]  R70       1
    z[2,7,5]  R1397     -1
    z[2,7,5]  R1398     1
    z[2,7,5]  R1401     3.7134058773517609e-02
    z[2,7,5]  R1402     -4.3836227059364319e-01
    z[2,7,5]  R1403     1.6207601130008698e-01
    z[2,7,5]  R1404     2.8912666440010071e-01
    z[2,7,5]  R1405     1.7371119558811188e-01
    z[2,7,5]  R1406     -2.8155824542045593e-01
    z[2,7,5]  R1407     -3.3294427394866943e-01
    z[2,7,5]  R1408     -3.1217607855796814e-01
    z[2,7,5]  R1409     1.6681528091430664e-01
    z[2,7,5]  R1410     -7.6324068009853363e-02
    z[2,7,5]  R1411     5.9478396177291870e-01
    z[2,7,5]  R1412     1.4739955961704254e-01
    z[2,7,5]  R1413     3.1917652487754822e-01
    z[2,7,5]  R1414     -1.3296452164649963e-01
    z[2,7,5]  R1415     2.2613622248172760e-02
    z[2,7,5]  R1416     -1.2087034434080124e-01
    z[2,7,5]  R1417     -2.4794960021972656e-01
    z[2,7,5]  R1418     -0.0900367721915245
    z[2,7,5]  R1419     -2.2938187420368195e-01
    z[2,7,5]  R1420     -9.6857078373432159e-02
    z[2,7,5]  R1421     -2.5553047657012939e-01
    z[2,7,5]  R1422     2.6781976222991943e-01
    z[2,7,5]  R1423     1.7074239253997803e-01
    z[2,7,5]  R1424     1.9964082539081573e-01
    z[2,7,5]  R1425     -3.0739307403564453e-02
    z[2,7,5]  R1426     -5.4868847131729126e-01
    z[2,7,5]  R1427     1.5081061422824860e-01
    z[2,7,5]  R1428     5.5249845609068871e-03
    z[2,7,5]  R1429     -8.0237448215484619e-02
    z[2,7,5]  R1430     -5.4287576675415039e-01
    z[2,7,5]  R1431     -1.0507623106241226e-01
    z[2,7,5]  R1432     -1.3714969158172607e-01
    z[2,7,5]  R1433     1.7076972126960754e-01
    z[2,7,5]  R1434     -8.8459923863410950e-02
    z[2,7,5]  R1435     0.258756548166275
    z[2,7,5]  R1436     -4.9505833536386490e-02
    z[2,7,5]  R1437     4.6881463378667831e-02
    z[2,7,5]  R1438     -3.4698281437158585e-02
    z[2,7,5]  R1439     5.5712736211717129e-03
    z[2,7,5]  R1440     1.3792365789413452e-01
    z[2,7,5]  R1441     8.8033504784107208e-02
    z[2,7,5]  R1442     -9.3164615333080292e-02
    z[2,7,5]  R1443     -1.9087509810924530e-01
    z[2,7,5]  R1444     7.0396237075328827e-02
    z[2,7,5]  R1445     6.9680221378803253e-02
    z[2,7,5]  R1446     1.0128123313188553e-01
    z[2,7,5]  R1447     2.5151568651199341e-01
    z[2,7,5]  R1448     8.0217964947223663e-02
    z[2,7,5]  R1449     -1.5398536622524261e-01
    z[2,7,5]  R1450     -1.0147435218095779e-01
    z[2,7,5]  R1451     -2.5306597352027893e-01
    z[2,7,5]  R1452     1.6864615678787231e-01
    z[2,7,5]  R1453     -1.0216084867715836e-01
    z[2,7,5]  R1454     -8.7392807006835938e-02
    z[2,7,5]  R1455     2.1890738606452942e-01
    z[2,7,5]  R1456     -3.8237354159355164e-01
    z[2,7,5]  R1457     -4.0125495195388794e-01
    z[2,7,5]  R1458     1.8512722849845886e-01
    z[2,7,5]  R1459     -2.5003109127283096e-02
    z[2,7,5]  R1460     -2.5611430406570435e-01
    z[2,7,5]  R1461     -2.9676118493080139e-01
    z[2,7,5]  R1462     -5.1403272151947021e-01
    z[2,7,5]  R1463     -5.5768877267837524e-01
    z[2,7,5]  R1464     -0.166483074426651
    z[2,7,5]  R1465     -3.2608771324157715e-01
    z[2,7,5]  R1466     1.6494846343994141e-01
    z[2,7,5]  R1467     9.2028222978115082e-02
    z[2,7,5]  R1468     0.362809956073761
    z[2,7,5]  R1469     1.2219491600990295e-01
    z[2,7,5]  R1470     1.9462847709655762e-01
    z[2,7,6]  R26       -1
    z[2,7,6]  R71       1
    z[2,7,6]  R1399     -1
    z[2,7,6]  R1400     1
    z[2,7,6]  R1401     6.6858351230621338e-02
    z[2,7,6]  R1402     0.259028822183609
    z[2,7,6]  R1403     1.5027964115142822e-01
    z[2,7,6]  R1404     -5.2211493253707886e-01
    z[2,7,6]  R1405     -5.9342807531356812e-01
    z[2,7,6]  R1406     -2.6496127247810364e-01
    z[2,7,6]  R1407     -1.9309477508068085e-01
    z[2,7,6]  R1408     2.5463435053825378e-01
    z[2,7,6]  R1409     -3.3253121655434370e-03
    z[2,7,6]  R1410     5.3472322225570679e-01
    z[2,7,6]  R1411     2.6953560113906860e-01
    z[2,7,6]  R1412     2.3360078036785126e-01
    z[2,7,6]  R1413     -2.3991394042968750e-01
    z[2,7,6]  R1414     6.4353114366531372e-01
    z[2,7,6]  R1415     5.7192766666412354e-01
    z[2,7,6]  R1416     -2.5998631026595831e-03
    z[2,7,6]  R1417     -1.0083127021789551e-01
    z[2,7,6]  R1418     -4.3489582836627960e-02
    z[2,7,6]  R1419     2.2829528152942657e-01
    z[2,7,6]  R1420     6.7231371998786926e-02
    z[2,7,6]  R1421     2.5963285565376282e-01
    z[2,7,6]  R1422     -1.4824126660823822e-01
    z[2,7,6]  R1423     -1.5896141529083252e-01
    z[2,7,6]  R1424     1.8201065063476562e-01
    z[2,7,6]  R1425     7.2573626041412354e-01
    z[2,7,6]  R1426     4.1801032423973083e-01
    z[2,7,6]  R1427     3.6519128084182739e-01
    z[2,7,6]  R1428     3.3364954590797424e-01
    z[2,7,6]  R1429     1.8068379163742065e-01
    z[2,7,6]  R1430     -1.0695316828787327e-02
    z[2,7,6]  R1431     4.5093291997909546e-01
    z[2,7,6]  R1432     1.8133418262004852e-01
    z[2,7,6]  R1433     2.9193994402885437e-01
    z[2,7,6]  R1434     6.3883143663406372e-01
    z[2,7,6]  R1435     -3.5452902317047119e-01
    z[2,7,6]  R1436     2.6167482137680054e-01
    z[2,7,6]  R1437     3.6023595929145813e-01
    z[2,7,6]  R1438     0.629138171672821
    z[2,7,6]  R1439     3.1355720758438110e-01
    z[2,7,6]  R1440     -1.3416926562786102e-01
    z[2,7,6]  R1441     1.5790063142776489e-01
    z[2,7,6]  R1442     6.7301634699106216e-03
    z[2,7,6]  R1443     2.7205497026443481e-01
    z[2,7,6]  R1444     -1.0560656338930130e-01
    z[2,7,6]  R1445     1.6317966580390930e-01
    z[2,7,6]  R1446     -1.8791554495692253e-02
    z[2,7,6]  R1447     2.9086660593748093e-02
    z[2,7,6]  R1448     7.0451624691486359e-02
    z[2,7,6]  R1449     -7.3795504868030548e-02
    z[2,7,6]  R1450     -7.8698962926864624e-02
    z[2,7,6]  R1451     4.4508766382932663e-02
    z[2,7,6]  R1452     -2.9428917169570923e-01
    z[2,7,6]  R1453     -2.8257521986961365e-01
    z[2,7,6]  R1454     3.6888431757688522e-02
    z[2,7,6]  R1455     5.4996378719806671e-02
    z[2,7,6]  R1456     1.7810256779193878e-01
    z[2,7,6]  R1457     -1.1039060354232788e-01
    z[2,7,6]  R1458     6.9044865667819977e-03
    z[2,7,6]  R1459     1.5340237319469452e-01
    z[2,7,6]  R1460     -3.8018664717674255e-01
    z[2,7,6]  R1461     -3.7175354361534119e-01
    z[2,7,6]  R1462     -2.7003440260887146e-01
    z[2,7,6]  R1463     -1.1532482504844666e-01
    z[2,7,6]  R1464     -2.1410727500915527e-01
    z[2,7,6]  R1465     3.3382120728492737e-01
    z[2,7,6]  R1466     -8.1435024738311768e-02
    z[2,7,6]  R1467     9.2316776514053345e-02
    z[2,7,6]  R1468     4.0257081389427185e-01
    z[2,7,6]  R1469     -6.1611879616975784e-02
    z[2,7,6]  R1470     2.4131615459918976e-01
    z[7,2,0]  R20       1
    z[7,2,0]  R65       -1
    z[7,2,0]  R1471     -1
    z[7,2,0]  R1472     1
    z[7,2,0]  R1485     3.5147759318351746e-01
    z[7,2,0]  R1486     4.0883067995309830e-02
    z[7,2,0]  R1487     2.7442533522844315e-02
    z[7,2,0]  R1488     -2.2505679726600647e-01
    z[7,2,0]  R1489     -1.7047492787241936e-02
    z[7,2,0]  R1490     -3.7297993898391724e-01
    z[7,2,0]  R1491     -2.7726629376411438e-01
    z[7,2,0]  R1492     -3.5951441526412964e-01
    z[7,2,0]  R1493     -9.3873977661132812e-02
    z[7,2,0]  R1494     2.9853138327598572e-01
    z[7,2,0]  R1495     -4.2799907922744751e-01
    z[7,2,0]  R1496     -6.0560190677642822e-01
    z[7,2,0]  R1497     -5.3953188657760620e-01
    z[7,2,0]  R1498     -2.5984960794448853e-01
    z[7,2,0]  R1499     -6.4778298139572144e-01
    z[7,2,0]  R1500     -4.1700929403305054e-01
    z[7,2,0]  R1501     -0.385744571685791
    z[7,2,0]  R1502     -1.8221004307270050e-01
    z[7,2,0]  R1503     -4.7696086764335632e-01
    z[7,2,0]  R1504     -3.6791044473648071e-01
    z[7,2,0]  R1505     -3.4008061885833740e-01
    z[7,2,0]  R1506     -2.2818570956587791e-02
    z[7,2,0]  R1507     3.9294874668121338e-01
    z[7,2,0]  R1508     -3.0102510005235672e-02
    z[7,2,0]  R1509     -0.400037944316864
    z[7,2,0]  R1510     -5.7290811091661453e-02
    z[7,2,0]  R1511     -6.6945418715476990e-02
    z[7,2,0]  R1512     -2.1001422405242920e-01
    z[7,2,0]  R1513     -4.1027206182479858e-01
    z[7,2,0]  R1514     -2.4204806983470917e-01
    z[7,2,0]  R1515     4.5590800046920776e-01
    z[7,2,0]  R1516     6.5800681710243225e-02
    z[7,2,0]  R1517     -6.0763758420944214e-01
    z[7,2,0]  R1518     -3.2962110638618469e-01
    z[7,2,0]  R1519     1.6704581677913666e-01
    z[7,2,0]  R1520     -2.8840294480323792e-01
    z[7,2,0]  R1521     -1.5888524055480957e-01
    z[7,2,0]  R1522     1.8819020688533783e-01
    z[7,2,0]  R1523     -6.0815680772066116e-03
    z[7,2,0]  R1524     -3.5370126366615295e-01
    z[7,2,0]  R1525     -5.8756476640701294e-01
    z[7,2,0]  R1526     -7.9760897159576416e-01
    z[7,2,0]  R1527     -5.8294034004211426e-01
    z[7,2,0]  R1528     -6.3656675815582275e-01
    z[7,2,0]  R1529     0.000665637431666255
    z[7,2,0]  R1530     3.4158188104629517e-01
    z[7,2,0]  R1531     3.1974050402641296e-01
    z[7,2,0]  R1532     3.4665313363075256e-01
    z[7,2,0]  R1533     1.9608055055141449e-01
    z[7,2,0]  R1534     6.2233191728591919e-01
    z[7,2,0]  R1535     1.2805898487567902e-01
    z[7,2,0]  R1536     2.9837599396705627e-01
    z[7,2,0]  R1537     5.3156417608261108e-01
    z[7,2,0]  R1538     3.4490948915481567e-01
    z[7,2,0]  R1539     5.7030439376831055e-01
    z[7,2,0]  R1540     9.3179166316986084e-01
    z[7,2,0]  R1541     8.4341913461685181e-01
    z[7,2,0]  R1542     8.8378113508224487e-01
    z[7,2,0]  R1543     8.3961808681488037e-01
    z[7,2,0]  R1544     8.8593792915344238e-01
    z[7,2,0]  R1545     1.4354000985622406e-01
    z[7,2,0]  R1546     0.34108966588974
    z[7,2,0]  R1547     1.1674237251281738e-01
    z[7,2,0]  R1548     1.1136688292026520e-01
    z[7,2,0]  R1549     4.5378932356834412e-01
    z[7,2,0]  R1550     4.1349762678146362e-01
    z[7,2,0]  R1551     6.7828559875488281e-01
    z[7,2,0]  R1552     4.8787105083465576e-01
    z[7,2,0]  R1553     3.5431259870529175e-01
    z[7,2,0]  R1554     8.2129406929016113e-01
    z[7,2,1]  R21       1
    z[7,2,1]  R66       -1
    z[7,2,1]  R1473     -1
    z[7,2,1]  R1474     1
    z[7,2,1]  R1485     5.3772604465484619e-01
    z[7,2,1]  R1486     7.2924906015396118e-01
    z[7,2,1]  R1487     9.2543345689773560e-01
    z[7,2,1]  R1488     6.6633814573287964e-01
    z[7,2,1]  R1489     6.6368007659912109e-01
    z[7,2,1]  R1490     0.721071183681488
    z[7,2,1]  R1491     5.9860116243362427e-01
    z[7,2,1]  R1492     4.9381405115127563e-01
    z[7,2,1]  R1493     6.9966787099838257e-01
    z[7,2,1]  R1494     7.3879170417785645e-01
    z[7,2,1]  R1495     -5.5943650007247925e-01
    z[7,2,1]  R1496     -6.1637800931930542e-01
    z[7,2,1]  R1497     -4.9711513519287109e-01
    z[7,2,1]  R1498     -6.9946968555450439e-01
    z[7,2,1]  R1499     -4.3509474396705627e-01
    z[7,2,1]  R1500     -0.527397096157074
    z[7,2,1]  R1501     -6.5380924940109253e-01
    z[7,2,1]  R1502     -3.6172983050346375e-01
    z[7,2,1]  R1503     -6.5000897645950317e-01
    z[7,2,1]  R1504     -4.8431155085563660e-01
    z[7,2,1]  R1505     -8.0435746908187866e-01
    z[7,2,1]  R1506     -8.4212523698806763e-01
    z[7,2,1]  R1507     2.9639837145805359e-01
    z[7,2,1]  R1508     -0.961946427822113
    z[7,2,1]  R1509     -7.6187348365783691e-01
    z[7,2,1]  R1510     -7.0618337392807007e-01
    z[7,2,1]  R1511     -0.890663206577301
    z[7,2,1]  R1512     -7.6029217243194580e-01
    z[7,2,1]  R1513     -8.0137866735458374e-01
    z[7,2,1]  R1514     -7.0838910341262817e-01
    z[7,2,1]  R1515     5.2064180374145508e-01
    z[7,2,1]  R1516     5.1355838775634766e-01
    z[7,2,1]  R1517     4.3847480416297913e-01
    z[7,2,1]  R1518     1.5662458539009094e-01
    z[7,2,1]  R1519     3.8802614808082581e-01
    z[7,2,1]  R1520     -8.2546448707580566e-01
    z[7,2,1]  R1521     -8.1400001049041748e-01
    z[7,2,1]  R1522     -1.3649834692478180e-01
    z[7,2,1]  R1523     -7.3540627956390381e-01
    z[7,2,1]  R1524     -7.2362780570983887e-01
    z[7,2,1]  R1525     -3.0761319398880005e-01
    z[7,2,1]  R1526     -2.1458260715007782e-02
    z[7,2,1]  R1527     -1.5686792135238647e-01
    z[7,2,1]  R1528     -1.1779581010341644e-01
    z[7,2,1]  R1529     -6.7735219001770020e-01
    z[7,2,1]  R1530     0.693505585193634
    z[7,2,1]  R1531     5.1017683744430542e-01
    z[7,2,1]  R1532     0.678641140460968
    z[7,2,1]  R1533     4.3037557601928711e-01
    z[7,2,1]  R1534     -9.2120125889778137e-02
    z[7,2,1]  R1535     7.4141013622283936e-01
    z[7,2,1]  R1536     7.4333906173706055e-01
    z[7,2,1]  R1537     6.6982412338256836e-01
    z[7,2,1]  R1538     -5.7433068752288818e-01
    z[7,2,1]  R1539     -4.5757806301116943e-01
    z[7,2,1]  R1540     4.9543965607881546e-02
    z[7,2,1]  R1541     2.1142403781414032e-01
    z[7,2,1]  R1542     1.2041904032230377e-01
    z[7,2,1]  R1543     1.6735802590847015e-01
    z[7,2,1]  R1544     3.4211522340774536e-01
    z[7,2,1]  R1545     8.5066372156143188e-01
    z[7,2,1]  R1546     6.7517876625061035e-01
    z[7,2,1]  R1547     7.0113706588745117e-01
    z[7,2,1]  R1548     0.666340172290802
    z[7,2,1]  R1549     -4.4583463668823242e-01
    z[7,2,1]  R1550     -5.0902652740478516e-01
    z[7,2,1]  R1551     -4.3175652623176575e-01
    z[7,2,1]  R1552     -1.7618516087532043e-01
    z[7,2,1]  R1553     -5.4970139265060425e-01
    z[7,2,1]  R1554     -6.8831346929073334e-02
    z[7,2,2]  R22       1
    z[7,2,2]  R67       -1
    z[7,2,2]  R1475     -1
    z[7,2,2]  R1476     1
    z[7,2,2]  R1485     -4.1262698173522949e-01
    z[7,2,2]  R1486     0.0496567003428936
    z[7,2,2]  R1487     4.4755268841981888e-02
    z[7,2,2]  R1488     -1.4815372228622437e-01
    z[7,2,2]  R1489     4.2813235521316528e-01
    z[7,2,2]  R1490     4.5968118309974670e-01
    z[7,2,2]  R1491     4.1569215059280396e-01
    z[7,2,2]  R1492     7.5898277573287487e-03
    z[7,2,2]  R1493     4.0898427367210388e-01
    z[7,2,2]  R1494     1.3869714736938477e-01
    z[7,2,2]  R1495     -5.3591018915176392e-01
    z[7,2,2]  R1496     -2.2801041603088379e-01
    z[7,2,2]  R1497     -0.516657292842865
    z[7,2,2]  R1498     -4.0650996565818787e-01
    z[7,2,2]  R1499     -5.9381824731826782e-01
    z[7,2,2]  R1500     -2.7623388171195984e-01
    z[7,2,2]  R1501     -5.0986176729202271e-01
    z[7,2,2]  R1502     -6.9064414501190186e-01
    z[7,2,2]  R1503     -4.5217093825340271e-01
    z[7,2,2]  R1504     -0.56244957447052
    z[7,2,2]  R1505     1.9406144320964813e-01
    z[7,2,2]  R1506     2.8965404629707336e-01
    z[7,2,2]  R1507     3.4909170120954514e-02
    z[7,2,2]  R1508     6.5579958260059357e-02
    z[7,2,2]  R1509     3.9618015289306641e-01
    z[7,2,2]  R1510     -2.8757303953170776e-01
    z[7,2,2]  R1511     1.5739649534225464e-01
    z[7,2,2]  R1512     4.0723752975463867e-01
    z[7,2,2]  R1513     3.6946651339530945e-01
    z[7,2,2]  R1514     2.5820541381835938e-01
    z[7,2,2]  R1515     0.0326387919485569
    z[7,2,2]  R1516     6.7335285246372223e-02
    z[7,2,2]  R1517     2.7764764428138733e-01
    z[7,2,2]  R1518     5.3151077032089233e-01
    z[7,2,2]  R1519     -2.2476732730865479e-01
    z[7,2,2]  R1520     1.9603857398033142e-01
    z[7,2,2]  R1521     -3.0395476147532463e-02
    z[7,2,2]  R1522     1.5812179446220398e-01
    z[7,2,2]  R1523     -1.8200913071632385e-01
    z[7,2,2]  R1524     7.9307332634925842e-03
    z[7,2,2]  R1525     2.5536981225013733e-01
    z[7,2,2]  R1526     -8.0873884260654449e-02
    z[7,2,2]  R1527     -7.4643611907958984e-01
    z[7,2,2]  R1528     2.6601186394691467e-01
    z[7,2,2]  R1529     -3.3538267016410828e-01
    z[7,2,2]  R1530     3.3730635046958923e-01
    z[7,2,2]  R1531     -5.7383030652999878e-01
    z[7,2,2]  R1532     2.3722781240940094e-01
    z[7,2,2]  R1533     -1.4183494448661804e-01
    z[7,2,2]  R1534     -3.5477694869041443e-01
    z[7,2,2]  R1535     -3.4747142344713211e-02
    z[7,2,2]  R1536     4.0809872746467590e-01
    z[7,2,2]  R1537     -1.4974361658096313e-01
    z[7,2,2]  R1538     1.4509527385234833e-01
    z[7,2,2]  R1539     2.3709741234779358e-01
    z[7,2,2]  R1540     3.8914494216442108e-02
    z[7,2,2]  R1541     8.1839226186275482e-02
    z[7,2,2]  R1542     2.6590687036514282e-01
    z[7,2,2]  R1543     1.2773790955543518e-01
    z[7,2,2]  R1544     2.6197027415037155e-02
    z[7,2,2]  R1545     -1.7921912670135498e-01
    z[7,2,2]  R1546     -3.5935276746749878e-01
    z[7,2,2]  R1547     2.6201415061950684e-01
    z[7,2,2]  R1548     5.6552481651306152e-01
    z[7,2,2]  R1549     -1.4974561333656311e-01
    z[7,2,2]  R1550     -2.2675932943820953e-01
    z[7,2,2]  R1551     -4.1336383670568466e-02
    z[7,2,2]  R1552     1.3642235100269318e-01
    z[7,2,2]  R1553     6.8221598863601685e-01
    z[7,2,2]  R1554     -7.2196260094642639e-02
    z[7,2,3]  R23       1
    z[7,2,3]  R68       -1
    z[7,2,3]  R1477     -1
    z[7,2,3]  R1478     1
    z[7,2,3]  R1485     4.5000296831130981e-01
    z[7,2,3]  R1486     6.3621246814727783e-01
    z[7,2,3]  R1487     -1.7492806538939476e-02
    z[7,2,3]  R1488     2.7972223237156868e-02
    z[7,2,3]  R1489     3.7851759791374207e-01
    z[7,2,3]  R1490     1.3253663666546345e-02
    z[7,2,3]  R1491     4.3476754426956177e-01
    z[7,2,3]  R1492     4.7934412956237793e-01
    z[7,2,3]  R1493     1.6339744627475739e-01
    z[7,2,3]  R1494     4.8957455158233643e-01
    z[7,2,3]  R1495     -1.4709731936454773e-01
    z[7,2,3]  R1496     -2.5882723927497864e-01
    z[7,2,3]  R1497     -2.1688246726989746e-01
    z[7,2,3]  R1498     -4.6647912263870239e-01
    z[7,2,3]  R1499     -8.3207428455352783e-02
    z[7,2,3]  R1500     -5.6877774000167847e-01
    z[7,2,3]  R1501     -3.0903410911560059e-01
    z[7,2,3]  R1502     -4.6563339233398438e-01
    z[7,2,3]  R1503     -3.3741500973701477e-01
    z[7,2,3]  R1504     -5.4462337493896484e-01
    z[7,2,3]  R1505     -1.7232039570808411e-01
    z[7,2,3]  R1506     -2.1759833395481110e-01
    z[7,2,3]  R1507     -6.5985542535781860e-01
    z[7,2,3]  R1508     2.0762298256158829e-02
    z[7,2,3]  R1509     -7.8155420720577240e-02
    z[7,2,3]  R1510     -0.406417578458786
    z[7,2,3]  R1511     6.5221287310123444e-02
    z[7,2,3]  R1512     0.0881512239575386
    z[7,2,3]  R1513     1.3524082303047180e-01
    z[7,2,3]  R1514     -2.6688039302825928e-01
    z[7,2,3]  R1515     0.33226278424263
    z[7,2,3]  R1516     3.9146417379379272e-01
    z[7,2,3]  R1517     -8.0085076391696930e-02
    z[7,2,3]  R1518     1.9872041046619415e-01
    z[7,2,3]  R1519     -4.8493242263793945e-01
    z[7,2,3]  R1520     -4.0307980775833130e-01
    z[7,2,3]  R1521     -4.5969793200492859e-01
    z[7,2,3]  R1522     7.2684627771377563e-01
    z[7,2,3]  R1523     -6.3669097423553467e-01
    z[7,2,3]  R1524     -0.288517564535141
    z[7,2,3]  R1525     6.9872546195983887e-01
    z[7,2,3]  R1526     -1.4361524581909180e-01
    z[7,2,3]  R1527     -1.6800025105476379e-01
    z[7,2,3]  R1528     -3.9234411716461182e-01
    z[7,2,3]  R1529     -1.6036370769143105e-02
    z[7,2,3]  R1530     3.7227776646614075e-01
    z[7,2,3]  R1531     3.9219167828559875e-01
    z[7,2,3]  R1532     2.6986068487167358e-01
    z[7,2,3]  R1533     3.6536210775375366e-01
    z[7,2,3]  R1534     2.0269700884819031e-01
    z[7,2,3]  R1535     -3.0786329880356789e-02
    z[7,2,3]  R1536     -3.0556395649909973e-01
    z[7,2,3]  R1537     -2.9215618968009949e-01
    z[7,2,3]  R1538     -3.1286829710006714e-01
    z[7,2,3]  R1539     1.5310217440128326e-01
    z[7,2,3]  R1540     -2.8971329331398010e-01
    z[7,2,3]  R1541     -3.9567741751670837e-01
    z[7,2,3]  R1542     -3.3423423767089844e-01
    z[7,2,3]  R1543     -3.4821224212646484e-01
    z[7,2,3]  R1544     -2.6191130280494690e-01
    z[7,2,3]  R1545     8.6467579007148743e-02
    z[7,2,3]  R1546     1.3405305147171021e-01
    z[7,2,3]  R1547     1.1523726396262646e-02
    z[7,2,3]  R1548     1.6345396637916565e-01
    z[7,2,3]  R1549     1.2899482250213623e-01
    z[7,2,3]  R1550     6.1010837554931641e-02
    z[7,2,3]  R1551     2.9394409060478210e-01
    z[7,2,3]  R1552     0.0871608629822731
    z[7,2,3]  R1553     -2.4624569714069366e-01
    z[7,2,3]  R1554     -1.4056387543678284e-01
    z[7,2,4]  R24       1
    z[7,2,4]  R69       -1
    z[7,2,4]  R1479     -1
    z[7,2,4]  R1480     1
    z[7,2,4]  R1485     1.3001147657632828e-02
    z[7,2,4]  R1486     -8.7179347872734070e-02
    z[7,2,4]  R1487     1.6161532700061798e-01
    z[7,2,4]  R1488     2.5822514295578003e-01
    z[7,2,4]  R1489     -2.0004893839359283e-01
    z[7,2,4]  R1490     -2.4194066226482391e-01
    z[7,2,4]  R1491     2.6647615432739258e-01
    z[7,2,4]  R1492     -7.0569347590208054e-03
    z[7,2,4]  R1493     -0.457533061504364
    z[7,2,4]  R1494     2.6290962100028992e-01
    z[7,2,4]  R1495     -4.0289908647537231e-01
    z[7,2,4]  R1496     -3.5442799329757690e-01
    z[7,2,4]  R1497     -1.9329233467578888e-01
    z[7,2,4]  R1498     -2.1037788689136505e-01
    z[7,2,4]  R1499     -6.5850298851728439e-03
    z[7,2,4]  R1500     -3.7085208296775818e-01
    z[7,2,4]  R1501     6.4554825425148010e-02
    z[7,2,4]  R1502     -3.6159214377403259e-01
    z[7,2,4]  R1503     5.0317924469709396e-02
    z[7,2,4]  R1504     2.5089766830205917e-02
    z[7,2,4]  R1505     3.2245415449142456e-01
    z[7,2,4]  R1506     2.0978122949600220e-01
    z[7,2,4]  R1507     -4.8044338822364807e-01
    z[7,2,4]  R1508     -2.4499568343162537e-01
    z[7,2,4]  R1509     2.1332244575023651e-01
    z[7,2,4]  R1510     2.6873627305030823e-01
    z[7,2,4]  R1511     4.2627118527889252e-03
    z[7,2,4]  R1512     4.1220989823341370e-01
    z[7,2,4]  R1513     1.0254800319671631e-01
    z[7,2,4]  R1514     -3.0259862542152405e-01
    z[7,2,4]  R1515     4.2819178104400635e-01
    z[7,2,4]  R1516     -0.486828088760376
    z[7,2,4]  R1517     1.7520861327648163e-01
    z[7,2,4]  R1518     6.8648862838745117e-01
    z[7,2,4]  R1519     -5.6398731470108032e-01
    z[7,2,4]  R1520     2.6229554787278175e-02
    z[7,2,4]  R1521     2.8796127438545227e-01
    z[7,2,4]  R1522     3.1456348299980164e-01
    z[7,2,4]  R1523     -4.3707441538572311e-02
    z[7,2,4]  R1524     -4.1453507542610168e-01
    z[7,2,4]  R1525     -2.9354941099882126e-02
    z[7,2,4]  R1526     -2.7737346291542053e-01
    z[7,2,4]  R1527     -3.6460742354393005e-02
    z[7,2,4]  R1528     3.5273800604045391e-03
    z[7,2,4]  R1529     -2.1476107835769653e-01
    z[7,2,4]  R1530     -2.2934643551707268e-02
    z[7,2,4]  R1531     -7.9072043299674988e-02
    z[7,2,4]  R1532     -3.5760810971260071e-01
    z[7,2,4]  R1533     -7.7128744125366211e-01
    z[7,2,4]  R1534     -3.8145750761032104e-01
    z[7,2,4]  R1535     7.3071740567684174e-02
    z[7,2,4]  R1536     -1.4902658760547638e-01
    z[7,2,4]  R1537     3.9553143084049225e-02
    z[7,2,4]  R1538     2.0750153809785843e-02
    z[7,2,4]  R1539     2.4105429649353027e-01
    z[7,2,4]  R1540     1.7101193964481354e-01
    z[7,2,4]  R1541     0.0950782373547554
    z[7,2,4]  R1542     -1.0960499197244644e-01
    z[7,2,4]  R1543     1.5725545585155487e-01
    z[7,2,4]  R1544     1.2200789898633957e-01
    z[7,2,4]  R1545     2.8890535235404968e-01
    z[7,2,4]  R1546     4.3241629004478455e-01
    z[7,2,4]  R1547     -6.0956722497940063e-01
    z[7,2,4]  R1548     3.5223352909088135e-01
    z[7,2,4]  R1549     -1.6913086175918579e-01
    z[7,2,4]  R1550     1.9742825627326965e-01
    z[7,2,4]  R1551     0.330597460269928
    z[7,2,4]  R1552     -7.7031159400939941e-01
    z[7,2,4]  R1553     8.4561698138713837e-02
    z[7,2,4]  R1554     3.0646726489067078e-02
    z[7,2,5]  R25       1
    z[7,2,5]  R70       -1
    z[7,2,5]  R1481     -1
    z[7,2,5]  R1482     1
    z[7,2,5]  R1485     -1.0507623106241226e-01
    z[7,2,5]  R1486     -1.3714969158172607e-01
    z[7,2,5]  R1487     1.7076972126960754e-01
    z[7,2,5]  R1488     -8.8459923863410950e-02
    z[7,2,5]  R1489     0.258756548166275
    z[7,2,5]  R1490     -4.9505833536386490e-02
    z[7,2,5]  R1491     4.6881463378667831e-02
    z[7,2,5]  R1492     -3.4698281437158585e-02
    z[7,2,5]  R1493     5.5712736211717129e-03
    z[7,2,5]  R1494     1.3792365789413452e-01
    z[7,2,5]  R1495     8.8033504784107208e-02
    z[7,2,5]  R1496     -9.3164615333080292e-02
    z[7,2,5]  R1497     -1.9087509810924530e-01
    z[7,2,5]  R1498     7.0396237075328827e-02
    z[7,2,5]  R1499     6.9680221378803253e-02
    z[7,2,5]  R1500     1.0128123313188553e-01
    z[7,2,5]  R1501     2.5151568651199341e-01
    z[7,2,5]  R1502     8.0217964947223663e-02
    z[7,2,5]  R1503     -1.5398536622524261e-01
    z[7,2,5]  R1504     -1.0147435218095779e-01
    z[7,2,5]  R1505     -2.5306597352027893e-01
    z[7,2,5]  R1506     1.6864615678787231e-01
    z[7,2,5]  R1507     -1.0216084867715836e-01
    z[7,2,5]  R1508     -8.7392807006835938e-02
    z[7,2,5]  R1509     2.1890738606452942e-01
    z[7,2,5]  R1510     -3.8237354159355164e-01
    z[7,2,5]  R1511     -4.0125495195388794e-01
    z[7,2,5]  R1512     1.8512722849845886e-01
    z[7,2,5]  R1513     -2.5003109127283096e-02
    z[7,2,5]  R1514     -2.5611430406570435e-01
    z[7,2,5]  R1515     -2.9676118493080139e-01
    z[7,2,5]  R1516     -5.1403272151947021e-01
    z[7,2,5]  R1517     -5.5768877267837524e-01
    z[7,2,5]  R1518     -0.166483074426651
    z[7,2,5]  R1519     -3.2608771324157715e-01
    z[7,2,5]  R1520     1.6494846343994141e-01
    z[7,2,5]  R1521     9.2028222978115082e-02
    z[7,2,5]  R1522     0.362809956073761
    z[7,2,5]  R1523     1.2219491600990295e-01
    z[7,2,5]  R1524     1.9462847709655762e-01
    z[7,2,5]  R1525     3.7134058773517609e-02
    z[7,2,5]  R1526     -4.3836227059364319e-01
    z[7,2,5]  R1527     1.6207601130008698e-01
    z[7,2,5]  R1528     2.8912666440010071e-01
    z[7,2,5]  R1529     1.7371119558811188e-01
    z[7,2,5]  R1530     -2.8155824542045593e-01
    z[7,2,5]  R1531     -3.3294427394866943e-01
    z[7,2,5]  R1532     -3.1217607855796814e-01
    z[7,2,5]  R1533     1.6681528091430664e-01
    z[7,2,5]  R1534     -7.6324068009853363e-02
    z[7,2,5]  R1535     5.9478396177291870e-01
    z[7,2,5]  R1536     1.4739955961704254e-01
    z[7,2,5]  R1537     3.1917652487754822e-01
    z[7,2,5]  R1538     -1.3296452164649963e-01
    z[7,2,5]  R1539     2.2613622248172760e-02
    z[7,2,5]  R1540     -1.2087034434080124e-01
    z[7,2,5]  R1541     -2.4794960021972656e-01
    z[7,2,5]  R1542     -0.0900367721915245
    z[7,2,5]  R1543     -2.2938187420368195e-01
    z[7,2,5]  R1544     -9.6857078373432159e-02
    z[7,2,5]  R1545     -2.5553047657012939e-01
    z[7,2,5]  R1546     2.6781976222991943e-01
    z[7,2,5]  R1547     1.7074239253997803e-01
    z[7,2,5]  R1548     1.9964082539081573e-01
    z[7,2,5]  R1549     -3.0739307403564453e-02
    z[7,2,5]  R1550     -5.4868847131729126e-01
    z[7,2,5]  R1551     1.5081061422824860e-01
    z[7,2,5]  R1552     5.5249845609068871e-03
    z[7,2,5]  R1553     -8.0237448215484619e-02
    z[7,2,5]  R1554     -5.4287576675415039e-01
    z[7,2,6]  R26       1
    z[7,2,6]  R71       -1
    z[7,2,6]  R1483     -1
    z[7,2,6]  R1484     1
    z[7,2,6]  R1485     4.5093291997909546e-01
    z[7,2,6]  R1486     1.8133418262004852e-01
    z[7,2,6]  R1487     2.9193994402885437e-01
    z[7,2,6]  R1488     6.3883143663406372e-01
    z[7,2,6]  R1489     -3.5452902317047119e-01
    z[7,2,6]  R1490     2.6167482137680054e-01
    z[7,2,6]  R1491     3.6023595929145813e-01
    z[7,2,6]  R1492     0.629138171672821
    z[7,2,6]  R1493     3.1355720758438110e-01
    z[7,2,6]  R1494     -1.3416926562786102e-01
    z[7,2,6]  R1495     1.5790063142776489e-01
    z[7,2,6]  R1496     6.7301634699106216e-03
    z[7,2,6]  R1497     2.7205497026443481e-01
    z[7,2,6]  R1498     -1.0560656338930130e-01
    z[7,2,6]  R1499     1.6317966580390930e-01
    z[7,2,6]  R1500     -1.8791554495692253e-02
    z[7,2,6]  R1501     2.9086660593748093e-02
    z[7,2,6]  R1502     7.0451624691486359e-02
    z[7,2,6]  R1503     -7.3795504868030548e-02
    z[7,2,6]  R1504     -7.8698962926864624e-02
    z[7,2,6]  R1505     4.4508766382932663e-02
    z[7,2,6]  R1506     -2.9428917169570923e-01
    z[7,2,6]  R1507     -2.8257521986961365e-01
    z[7,2,6]  R1508     3.6888431757688522e-02
    z[7,2,6]  R1509     5.4996378719806671e-02
    z[7,2,6]  R1510     1.7810256779193878e-01
    z[7,2,6]  R1511     -1.1039060354232788e-01
    z[7,2,6]  R1512     6.9044865667819977e-03
    z[7,2,6]  R1513     1.5340237319469452e-01
    z[7,2,6]  R1514     -3.8018664717674255e-01
    z[7,2,6]  R1515     -3.7175354361534119e-01
    z[7,2,6]  R1516     -2.7003440260887146e-01
    z[7,2,6]  R1517     -1.1532482504844666e-01
    z[7,2,6]  R1518     -2.1410727500915527e-01
    z[7,2,6]  R1519     3.3382120728492737e-01
    z[7,2,6]  R1520     -8.1435024738311768e-02
    z[7,2,6]  R1521     9.2316776514053345e-02
    z[7,2,6]  R1522     4.0257081389427185e-01
    z[7,2,6]  R1523     -6.1611879616975784e-02
    z[7,2,6]  R1524     2.4131615459918976e-01
    z[7,2,6]  R1525     6.6858351230621338e-02
    z[7,2,6]  R1526     0.259028822183609
    z[7,2,6]  R1527     1.5027964115142822e-01
    z[7,2,6]  R1528     -5.2211493253707886e-01
    z[7,2,6]  R1529     -5.9342807531356812e-01
    z[7,2,6]  R1530     -2.6496127247810364e-01
    z[7,2,6]  R1531     -1.9309477508068085e-01
    z[7,2,6]  R1532     2.5463435053825378e-01
    z[7,2,6]  R1533     -3.3253121655434370e-03
    z[7,2,6]  R1534     5.3472322225570679e-01
    z[7,2,6]  R1535     2.6953560113906860e-01
    z[7,2,6]  R1536     2.3360078036785126e-01
    z[7,2,6]  R1537     -2.3991394042968750e-01
    z[7,2,6]  R1538     6.4353114366531372e-01
    z[7,2,6]  R1539     5.7192766666412354e-01
    z[7,2,6]  R1540     -2.5998631026595831e-03
    z[7,2,6]  R1541     -1.0083127021789551e-01
    z[7,2,6]  R1542     -4.3489582836627960e-02
    z[7,2,6]  R1543     2.2829528152942657e-01
    z[7,2,6]  R1544     6.7231371998786926e-02
    z[7,2,6]  R1545     2.5963285565376282e-01
    z[7,2,6]  R1546     -1.4824126660823822e-01
    z[7,2,6]  R1547     -1.5896141529083252e-01
    z[7,2,6]  R1548     1.8201065063476562e-01
    z[7,2,6]  R1549     7.2573626041412354e-01
    z[7,2,6]  R1550     4.1801032423973083e-01
    z[7,2,6]  R1551     3.6519128084182739e-01
    z[7,2,6]  R1552     3.3364954590797424e-01
    z[7,2,6]  R1553     1.8068379163742065e-01
    z[7,2,6]  R1554     -1.0695316828787327e-02
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1555     -1
    z[3,4,0]  R1556     1
    z[3,4,0]  R1569     3.7067100405693054e-02
    z[3,4,0]  R1570     3.7179496884346008e-01
    z[3,4,0]  R1571     -4.1181966662406921e-01
    z[3,4,0]  R1572     5.1207607984542847e-01
    z[3,4,0]  R1573     -6.3994753360748291e-01
    z[3,4,0]  R1574     -0.316124826669693
    z[3,4,0]  R1575     -4.0294739603996277e-01
    z[3,4,0]  R1576     5.3729891777038574e-01
    z[3,4,0]  R1577     -4.6869885921478271e-01
    z[3,4,0]  R1578     -4.5559534430503845e-01
    z[3,4,0]  R1579     7.8173793852329254e-02
    z[3,4,0]  R1580     -1.7945900559425354e-01
    z[3,4,0]  R1581     -1.2135547585785389e-03
    z[3,4,0]  R1582     -0.0807340145111084
    z[3,4,0]  R1583     -2.4226111173629761e-01
    z[3,4,0]  R1584     -2.3268264532089233e-01
    z[3,4,0]  R1585     -5.3354259580373764e-02
    z[3,4,0]  R1586     -3.0456345528364182e-02
    z[3,4,0]  R1587     -2.2064997255802155e-01
    z[3,4,0]  R1588     -4.6148531138896942e-02
    z[3,4,0]  R1589     6.5666645765304565e-02
    z[3,4,0]  R1590     -1.9799323379993439e-01
    z[3,4,0]  R1591     3.2701876759529114e-01
    z[3,4,0]  R1592     -1.4233329892158508e-01
    z[3,4,0]  R1593     1.9304735586047173e-02
    z[3,4,0]  R1594     -1.5847027301788330e-01
    z[3,4,0]  R1595     5.3673553466796875e-01
    z[3,4,0]  R1596     3.6323402076959610e-02
    z[3,4,0]  R1597     -3.4531587362289429e-01
    z[3,4,0]  R1598     -1.6749443113803864e-01
    z[3,4,0]  R1599     -2.3113049566745758e-01
    z[3,4,0]  R1600     -4.3012022972106934e-02
    z[3,4,0]  R1601     4.8231253027915955e-01
    z[3,4,0]  R1602     2.5550296530127525e-02
    z[3,4,0]  R1603     -2.0028276741504669e-01
    z[3,4,0]  R1604     -4.8691046237945557e-01
    z[3,4,0]  R1605     -1.2682755291461945e-01
    z[3,4,0]  R1606     2.6874890923500061e-01
    z[3,4,0]  R1607     1.3006573915481567e-01
    z[3,4,0]  R1608     3.6033737659454346e-01
    z[3,4,0]  R1609     5.9692794084548950e-01
    z[3,4,0]  R1610     3.9397379755973816e-01
    z[3,4,0]  R1611     -1.7629776895046234e-01
    z[3,4,0]  R1612     1.2649475038051605e-01
    z[3,4,0]  R1613     5.8065932244062424e-02
    z[3,4,0]  R1614     -2.4579444527626038e-01
    z[3,4,0]  R1615     6.5198093652725220e-02
    z[3,4,0]  R1616     5.4943734407424927e-01
    z[3,4,0]  R1617     -1.5163809061050415e-01
    z[3,4,0]  R1618     -2.2004279494285583e-01
    z[3,4,0]  R1619     -1.1727644503116608e-01
    z[3,4,0]  R1620     1.9039590656757355e-01
    z[3,4,0]  R1621     2.9173459857702255e-02
    z[3,4,0]  R1622     -5.5233038961887360e-02
    z[3,4,0]  R1623     -1.4811183512210846e-01
    z[3,4,0]  R1624     9.3578584492206573e-02
    z[3,4,0]  R1625     -9.8985306918621063e-02
    z[3,4,0]  R1626     -1.3010847568511963e-01
    z[3,4,0]  R1627     1.1820724606513977e-01
    z[3,4,0]  R1628     -2.2255496680736542e-01
    z[3,4,0]  R1629     -1.2191570550203323e-01
    z[3,4,0]  R1630     -3.0332719907164574e-02
    z[3,4,0]  R1631     -8.1705629825592041e-02
    z[3,4,0]  R1632     -3.3933378756046295e-02
    z[3,4,0]  R1633     4.9755383282899857e-02
    z[3,4,0]  R1634     1.3494296371936798e-01
    z[3,4,0]  R1635     0.0110483942553401
    z[3,4,0]  R1636     1.4044113457202911e-01
    z[3,4,0]  R1637     0.590168297290802
    z[3,4,0]  R1638     1.1057145148515701e-01
    z[3,4,0]  R1639     4.1727516055107117e-01
    z[3,4,0]  R1640     2.3384353518486023e-01
    z[3,4,0]  R1641     1.9234964251518250e-01
    z[3,4,0]  R1642     5.4365879297256470e-01
    z[3,4,0]  R1643     3.6887899041175842e-01
    z[3,4,0]  R1644     -6.3091731071472168e-01
    z[3,4,0]  R1645     -6.5363544225692749e-01
    z[3,4,0]  R1646     -3.6788159608840942e-01
    z[3,4,0]  R1647     -5.4095560312271118e-01
    z[3,4,0]  R1648     3.3544310927391052e-01
    z[3,4,0]  R1649     0.445083886384964
    z[3,4,0]  R1650     5.9949624538421631e-01
    z[3,4,0]  R1651     -1.0904526337981224e-02
    z[3,4,0]  R1652     -1.9388508796691895e-01
    z[3,4,0]  R1653     -4.3607071042060852e-01
    z[3,4,0]  R1654     -2.3525188863277435e-01
    z[3,4,0]  R1655     -8.3016566932201385e-03
    z[3,4,0]  R1656     -1.6211374104022980e-01
    z[3,4,0]  R1657     -0.299001544713974
    z[3,4,0]  R1658     -4.3869003653526306e-01
    z[3,4,0]  R1659     -3.7246486544609070e-01
    z[3,4,0]  R1660     1.8723241984844208e-01
    z[3,4,0]  R1661     -4.7213220596313477e-01
    z[3,4,0]  R1662     -2.7378988265991211e-01
    z[3,4,0]  R1663     1.4399564266204834e-01
    z[3,4,0]  R1664     -4.4520506262779236e-01
    z[3,4,0]  R1665     -2.6701837778091431e-01
    z[3,4,0]  R1666     2.3060111701488495e-01
    z[3,4,0]  R1667     -1.7048522830009460e-01
    z[3,4,0]  R1668     -2.3564680013805628e-03
    z[3,4,0]  R1669     2.5751056149601936e-02
    z[3,4,0]  R1670     -2.6718097925186157e-01
    z[3,4,0]  R1671     -5.3210258483886719e-01
    z[3,4,0]  R1672     -0.392514169216156
    z[3,4,0]  R1673     -3.9334365725517273e-01
    z[3,4,0]  R1674     -4.2745375633239746e-01
    z[3,4,0]  R1675     0.0908120647072792
    z[3,4,0]  R1676     3.8633909821510315e-01
    z[3,4,0]  R1677     -2.6486802101135254e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1557     -1
    z[3,4,1]  R1558     1
    z[3,4,1]  R1569     6.9367986917495728e-01
    z[3,4,1]  R1570     6.6264796257019043e-01
    z[3,4,1]  R1571     -4.9712666869163513e-01
    z[3,4,1]  R1572     4.0542349219322205e-01
    z[3,4,1]  R1573     -0.443347305059433
    z[3,4,1]  R1574     -5.1285165548324585e-01
    z[3,4,1]  R1575     -0.450613796710968
    z[3,4,1]  R1576     6.5254640579223633e-01
    z[3,4,1]  R1577     -6.2381881475448608e-01
    z[3,4,1]  R1578     7.0405995845794678e-01
    z[3,4,1]  R1579     -9.6634417772293091e-01
    z[3,4,1]  R1580     -8.2638806104660034e-01
    z[3,4,1]  R1581     -8.3274024724960327e-01
    z[3,4,1]  R1582     -9.4393610954284668e-01
    z[3,4,1]  R1583     -8.9501363039016724e-01
    z[3,4,1]  R1584     -8.5856539011001587e-01
    z[3,4,1]  R1585     -9.3438696861267090e-01
    z[3,4,1]  R1586     -8.9354443550109863e-01
    z[3,4,1]  R1587     -8.9741677045822144e-01
    z[3,4,1]  R1588     -8.6780643463134766e-01
    z[3,4,1]  R1589     9.0192121267318726e-01
    z[3,4,1]  R1590     0.6239013671875
    z[3,4,1]  R1591     3.4472694993019104e-01
    z[3,4,1]  R1592     0.70050448179245
    z[3,4,1]  R1593     4.5671561360359192e-01
    z[3,4,1]  R1594     0.627260684967041
    z[3,4,1]  R1595     7.8109733294695616e-04
    z[3,4,1]  R1596     -7.5922125577926636e-01
    z[3,4,1]  R1597     -0.715255618095398
    z[3,4,1]  R1598     -5.2114403247833252e-01
    z[3,4,1]  R1599     7.6005853712558746e-02
    z[3,4,1]  R1600     0.802408754825592
    z[3,4,1]  R1601     -0.0430334135890007
    z[3,4,1]  R1602     4.5041911303997040e-02
    z[3,4,1]  R1603     3.0691778659820557e-01
    z[3,4,1]  R1604     2.6438814401626587e-01
    z[3,4,1]  R1605     -5.6059908866882324e-01
    z[3,4,1]  R1606     -6.6544133424758911e-01
    z[3,4,1]  R1607     -6.2691295146942139e-01
    z[3,4,1]  R1608     -6.3844412565231323e-01
    z[3,4,1]  R1609     1.4414748549461365e-01
    z[3,4,1]  R1610     3.5924646258354187e-01
    z[3,4,1]  R1611     4.2892915010452271e-01
    z[3,4,1]  R1612     7.6178300380706787e-01
    z[3,4,1]  R1613     8.5596400499343872e-01
    z[3,4,1]  R1614     5.7058918476104736e-01
    z[3,4,1]  R1615     0.0888204276561737
    z[3,4,1]  R1616     0.0500313900411129
    z[3,4,1]  R1617     -7.8557604551315308e-01
    z[3,4,1]  R1618     -6.9789052009582520e-01
    z[3,4,1]  R1619     5.8851748704910278e-01
    z[3,4,1]  R1620     3.6812219023704529e-01
    z[3,4,1]  R1621     7.0105659961700439e-01
    z[3,4,1]  R1622     6.9236093759536743e-01
    z[3,4,1]  R1623     7.4410974979400635e-01
    z[3,4,1]  R1624     -7.9978233575820923e-01
    z[3,4,1]  R1625     -6.6857415437698364e-01
    z[3,4,1]  R1626     -7.6604461669921875e-01
    z[3,4,1]  R1627     -8.1263101100921631e-01
    z[3,4,1]  R1628     2.2216621041297913e-01
    z[3,4,1]  R1629     8.7879288196563721e-01
    z[3,4,1]  R1630     6.9568967819213867e-01
    z[3,4,1]  R1631     -7.6769274473190308e-01
    z[3,4,1]  R1632     -0.793660581111908
    z[3,4,1]  R1633     -8.9406061172485352e-01
    z[3,4,1]  R1634     -0.69505375623703
    z[3,4,1]  R1635     -6.0580420494079590e-01
    z[3,4,1]  R1636     -4.4465139508247375e-03
    z[3,4,1]  R1637     1.0688560083508492e-02
    z[3,4,1]  R1638     0.130645290017128
    z[3,4,1]  R1639     -3.6773982644081116e-01
    z[3,4,1]  R1640     2.6268604397773743e-01
    z[3,4,1]  R1641     -5.1379489898681641e-01
    z[3,4,1]  R1642     2.4627435952425003e-02
    z[3,4,1]  R1643     1.4645354449748993e-01
    z[3,4,1]  R1644     -5.5749481916427612e-01
    z[3,4,1]  R1645     -4.8125651478767395e-01
    z[3,4,1]  R1646     -4.1433036327362061e-01
    z[3,4,1]  R1647     -3.8606163859367371e-01
    z[3,4,1]  R1648     5.6183934211730957e-01
    z[3,4,1]  R1649     2.4856026470661163e-01
    z[3,4,1]  R1650     4.4114881753921509e-01
    z[3,4,1]  R1651     8.5515290498733521e-01
    z[3,4,1]  R1652     0.806327760219574
    z[3,4,1]  R1653     7.7940917015075684e-01
    z[3,4,1]  R1654     -2.1536909043788910e-01
    z[3,4,1]  R1655     -3.5275441408157349e-01
    z[3,4,1]  R1656     -7.1298718452453613e-02
    z[3,4,1]  R1657     -3.2652860879898071e-01
    z[3,4,1]  R1658     -5.2660995721817017e-01
    z[3,4,1]  R1659     -3.6260443925857544e-01
    z[3,4,1]  R1660     -6.5382492542266846e-01
    z[3,4,1]  R1661     2.8144272044301033e-02
    z[3,4,1]  R1662     -2.3942266404628754e-01
    z[3,4,1]  R1663     2.6355481147766113e-01
    z[3,4,1]  R1664     -6.8916711024940014e-03
    z[3,4,1]  R1665     9.4218976795673370e-02
    z[3,4,1]  R1666     -3.7219020724296570e-01
    z[3,4,1]  R1667     -2.7761897444725037e-01
    z[3,4,1]  R1668     1.7800673842430115e-01
    z[3,4,1]  R1669     -2.5634220242500305e-01
    z[3,4,1]  R1670     2.1152906119823456e-01
    z[3,4,1]  R1671     2.9970075935125351e-02
    z[3,4,1]  R1672     -4.8902123235166073e-03
    z[3,4,1]  R1673     -1.8356233835220337e-01
    z[3,4,1]  R1674     -0.253077894449234
    z[3,4,1]  R1675     -5.9396427869796753e-01
    z[3,4,1]  R1676     -3.2510635256767273e-01
    z[3,4,1]  R1677     -1.5003034472465515e-01
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1559     -1
    z[3,4,2]  R1560     1
    z[3,4,2]  R1569     3.7445166707038879e-01
    z[3,4,2]  R1570     -2.4146245419979095e-01
    z[3,4,2]  R1571     -6.5644830465316772e-01
    z[3,4,2]  R1572     -1.2594206631183624e-01
    z[3,4,2]  R1573     -5.0185889005661011e-01
    z[3,4,2]  R1574     -3.9556607604026794e-01
    z[3,4,2]  R1575     -4.8620283603668213e-01
    z[3,4,2]  R1576     -5.1303360611200333e-02
    z[3,4,2]  R1577     -1.8828479945659637e-01
    z[3,4,2]  R1578     -1.8435798585414886e-01
    z[3,4,2]  R1579     1.3297490775585175e-01
    z[3,4,2]  R1580     -1.6308559570461512e-03
    z[3,4,2]  R1581     -7.8419208526611328e-02
    z[3,4,2]  R1582     1.8751381337642670e-01
    z[3,4,2]  R1583     1.4740787446498871e-01
    z[3,4,2]  R1584     3.0041760206222534e-01
    z[3,4,2]  R1585     3.2278785109519958e-01
    z[3,4,2]  R1586     1.4655736088752747e-01
    z[3,4,2]  R1587     -4.4597167521715164e-02
    z[3,4,2]  R1588     2.1245136857032776e-01
    z[3,4,2]  R1589     -1.2600612640380859e-01
    z[3,4,2]  R1590     -2.3675315082073212e-01
    z[3,4,2]  R1591     -1.9854129850864410e-01
    z[3,4,2]  R1592     -8.3444461226463318e-02
    z[3,4,2]  R1593     -2.7143913507461548e-01
    z[3,4,2]  R1594     -2.6291960477828979e-01
    z[3,4,2]  R1595     -0.0666758269071579
    z[3,4,2]  R1596     -1.8733938038349152e-01
    z[3,4,2]  R1597     -0.0946456640958786
    z[3,4,2]  R1598     -1.4219684898853302e-01
    z[3,4,2]  R1599     2.4438938498497009e-01
    z[3,4,2]  R1600     -3.3602195978164673e-01
    z[3,4,2]  R1601     -5.1875356584787369e-03
    z[3,4,2]  R1602     2.1833754144608974e-03
    z[3,4,2]  R1603     -2.4139027297496796e-01
    z[3,4,2]  R1604     -1.5233443677425385e-01
    z[3,4,2]  R1605     -4.3736910820007324e-01
    z[3,4,2]  R1606     -2.3348213732242584e-01
    z[3,4,2]  R1607     -4.5843631029129028e-01
    z[3,4,2]  R1608     1.5957817435264587e-01
    z[3,4,2]  R1609     2.9598847031593323e-01
    z[3,4,2]  R1610     2.7041327953338623e-01
    z[3,4,2]  R1611     -2.4659752845764160e-01
    z[3,4,2]  R1612     -4.6603524684906006e-01
    z[3,4,2]  R1613     -0.0762200802564621
    z[3,4,2]  R1614     2.4485167115926743e-02
    z[3,4,2]  R1615     2.6378279551863670e-02
    z[3,4,2]  R1616     -3.3334141969680786e-01
    z[3,4,2]  R1617     -9.0231351554393768e-02
    z[3,4,2]  R1618     -3.5453933477401733e-01
    z[3,4,2]  R1619     4.3191414326429367e-02
    z[3,4,2]  R1620     -0.341232031583786
    z[3,4,2]  R1621     -4.0100088715553284e-01
    z[3,4,2]  R1622     -7.8620567917823792e-02
    z[3,4,2]  R1623     -1.0464297980070114e-01
    z[3,4,2]  R1624     -2.4717628955841064e-01
    z[3,4,2]  R1625     -3.3976930379867554e-01
    z[3,4,2]  R1626     -1.2700571119785309e-01
    z[3,4,2]  R1627     1.9309714436531067e-01
    z[3,4,2]  R1628     7.5070065259933472e-01
    z[3,4,2]  R1629     -2.0854748785495758e-01
    z[3,4,2]  R1630     2.2803038358688354e-01
    z[3,4,2]  R1631     -1.6927412152290344e-01
    z[3,4,2]  R1632     -3.2806521654129028e-01
    z[3,4,2]  R1633     7.4264849536120892e-03
    z[3,4,2]  R1634     -2.3701396584510803e-01
    z[3,4,2]  R1635     1.0115970671176910e-01
    z[3,4,2]  R1636     0.692564845085144
    z[3,4,2]  R1637     3.3201807737350464e-01
    z[3,4,2]  R1638     5.3853130340576172e-01
    z[3,4,2]  R1639     4.5679494738578796e-01
    z[3,4,2]  R1640     3.0801385641098022e-01
    z[3,4,2]  R1641     6.5136075019836426e-01
    z[3,4,2]  R1642     -4.6572912484407425e-02
    z[3,4,2]  R1643     -4.5000651478767395e-01
    z[3,4,2]  R1644     -4.6828472614288330e-01
    z[3,4,2]  R1645     -5.4492324590682983e-01
    z[3,4,2]  R1646     -0.384880930185318
    z[3,4,2]  R1647     -2.2524002194404602e-01
    z[3,4,2]  R1648     4.2095446586608887e-01
    z[3,4,2]  R1649     2.4210751056671143e-01
    z[3,4,2]  R1650     -3.2490931451320648e-02
    z[3,4,2]  R1651     -1.3517902791500092e-01
    z[3,4,2]  R1652     -4.4970061630010605e-02
    z[3,4,2]  R1653     6.9062080001458526e-05
    z[3,4,2]  R1654     -3.5839927196502686e-01
    z[3,4,2]  R1655     1.2573441490530968e-02
    z[3,4,2]  R1656     -4.2000892758369446e-01
    z[3,4,2]  R1657     -7.6218426227569580e-02
    z[3,4,2]  R1658     -3.3413589000701904e-01
    z[3,4,2]  R1659     -6.0285800695419312e-01
    z[3,4,2]  R1660     -4.9539190530776978e-01
    z[3,4,2]  R1661     -4.5029523968696594e-01
    z[3,4,2]  R1662     -2.0784315466880798e-01
    z[3,4,2]  R1663     -5.2851992845535278e-01
    z[3,4,2]  R1664     -2.1390576660633087e-01
    z[3,4,2]  R1665     -5.9472084045410156e-01
    z[3,4,2]  R1666     -4.9029859900474548e-01
    z[3,4,2]  R1667     1.1751763522624969e-01
    z[3,4,2]  R1668     -5.4794090986251831e-01
    z[3,4,2]  R1669     -4.1816940903663635e-01
    z[3,4,2]  R1670     -5.2481925487518311e-01
    z[3,4,2]  R1671     -4.2251008749008179e-01
    z[3,4,2]  R1672     -2.9979768395423889e-01
    z[3,4,2]  R1673     -4.4982945919036865e-01
    z[3,4,2]  R1674     -4.6862161159515381e-01
    z[3,4,2]  R1675     -3.9316442608833313e-01
    z[3,4,2]  R1676     -5.0399243831634521e-01
    z[3,4,2]  R1677     -1.1587807536125183e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1561     -1
    z[3,4,3]  R1562     1
    z[3,4,3]  R1569     4.9024832248687744e-01
    z[3,4,3]  R1570     5.2322983741760254e-01
    z[3,4,3]  R1571     -2.6184621453285217e-01
    z[3,4,3]  R1572     5.5958682298660278e-01
    z[3,4,3]  R1573     6.1362501233816147e-02
    z[3,4,3]  R1574     -4.5997259020805359e-01
    z[3,4,3]  R1575     -1.9809435307979584e-01
    z[3,4,3]  R1576     -0.0729481503367424
    z[3,4,3]  R1577     -1.1497498303651810e-01
    z[3,4,3]  R1578     2.1794460713863373e-01
    z[3,4,3]  R1579     -1.2271368503570557e-01
    z[3,4,3]  R1580     -1.6657491028308868e-01
    z[3,4,3]  R1581     -1.7226240038871765e-01
    z[3,4,3]  R1582     -2.4263501167297363e-01
    z[3,4,3]  R1583     -2.9438859224319458e-01
    z[3,4,3]  R1584     -1.4323222637176514e-01
    z[3,4,3]  R1585     5.3854927420616150e-02
    z[3,4,3]  R1586     8.3793297410011292e-02
    z[3,4,3]  R1587     5.9439826756715775e-02
    z[3,4,3]  R1588     2.2096496820449829e-01
    z[3,4,3]  R1589     -3.3231475949287415e-01
    z[3,4,3]  R1590     8.5544362664222717e-02
    z[3,4,3]  R1591     5.4995030164718628e-02
    z[3,4,3]  R1592     -2.5623863935470581e-01
    z[3,4,3]  R1593     1.4718367159366608e-01
    z[3,4,3]  R1594     -4.7586208581924438e-01
    z[3,4,3]  R1595     5.7744556665420532e-01
    z[3,4,3]  R1596     -3.7982547283172607e-01
    z[3,4,3]  R1597     -3.8820537924766541e-01
    z[3,4,3]  R1598     -6.8278080224990845e-01
    z[3,4,3]  R1599     5.6001764535903931e-01
    z[3,4,3]  R1600     -8.2615956664085388e-02
    z[3,4,3]  R1601     5.9955221414566040e-01
    z[3,4,3]  R1602     5.5213242769241333e-01
    z[3,4,3]  R1603     6.8202984333038330e-01
    z[3,4,3]  R1604     0.567356526851654
    z[3,4,3]  R1605     -3.3254262804985046e-01
    z[3,4,3]  R1606     -6.4255464076995850e-01
    z[3,4,3]  R1607     -4.6182984113693237e-01
    z[3,4,3]  R1608     -5.4322427511215210e-01
    z[3,4,3]  R1609     3.8676840066909790e-01
    z[3,4,3]  R1610     -1.4344982802867889e-01
    z[3,4,3]  R1611     6.5242147445678711e-01
    z[3,4,3]  R1612     -2.0302671939134598e-02
    z[3,4,3]  R1613     -3.8734534382820129e-01
    z[3,4,3]  R1614     2.6633885502815247e-01
    z[3,4,3]  R1615     9.2679816484451294e-01
    z[3,4,3]  R1616     4.9930948019027710e-01
    z[3,4,3]  R1617     -2.5792637467384338e-01
    z[3,4,3]  R1618     -3.6546853184700012e-01
    z[3,4,3]  R1619     5.7596552371978760e-01
    z[3,4,3]  R1620     5.1674467325210571e-01
    z[3,4,3]  R1621     8.7929308414459229e-02
    z[3,4,3]  R1622     3.7946559488773346e-02
    z[3,4,3]  R1623     -3.0083081126213074e-01
    z[3,4,3]  R1624     -1.4255067706108093e-01
    z[3,4,3]  R1625     -5.8918052911758423e-01
    z[3,4,3]  R1626     -1.2219463288784027e-01
    z[3,4,3]  R1627     2.0624296367168427e-01
    z[3,4,3]  R1628     -3.6771920323371887e-01
    z[3,4,3]  R1629     1.7160816490650177e-01
    z[3,4,3]  R1630     -1.2418014556169510e-01
    z[3,4,3]  R1631     -5.4831933975219727e-01
    z[3,4,3]  R1632     -3.3369067311286926e-01
    z[3,4,3]  R1633     2.8668698668479919e-01
    z[3,4,3]  R1634     -2.9597437381744385e-01
    z[3,4,3]  R1635     -6.3257539272308350e-01
    z[3,4,3]  R1636     -0.566639244556427
    z[3,4,3]  R1637     -6.5333527326583862e-01
    z[3,4,3]  R1638     -6.6944444179534912e-01
    z[3,4,3]  R1639     -2.2743774950504303e-01
    z[3,4,3]  R1640     -6.2280791997909546e-01
    z[3,4,3]  R1641     -2.3109762370586395e-01
    z[3,4,3]  R1642     -0.391855388879776
    z[3,4,3]  R1643     -4.1402736306190491e-01
    z[3,4,3]  R1644     -8.5958838462829590e-02
    z[3,4,3]  R1645     1.1629532277584076e-01
    z[3,4,3]  R1646     -4.0571384131908417e-02
    z[3,4,3]  R1647     2.2374625504016876e-01
    z[3,4,3]  R1648     2.3730051517486572e-01
    z[3,4,3]  R1649     -1.6322648152709007e-02
    z[3,4,3]  R1650     5.9212759137153625e-02
    z[3,4,3]  R1651     -1.0154701769351959e-01
    z[3,4,3]  R1652     -1.0773303359746933e-01
    z[3,4,3]  R1653     2.3034097626805305e-02
    z[3,4,3]  R1654     -4.6928000450134277e-01
    z[3,4,3]  R1655     4.3289911746978760e-01
    z[3,4,3]  R1656     6.4842063188552856e-01
    z[3,4,3]  R1657     5.8338105678558350e-01
    z[3,4,3]  R1658     -1.3787488453090191e-02
    z[3,4,3]  R1659     -2.5685107707977295e-01
    z[3,4,3]  R1660     -1.9629356265068054e-01
    z[3,4,3]  R1661     6.2076830863952637e-01
    z[3,4,3]  R1662     0.618816614151001
    z[3,4,3]  R1663     5.8165395259857178e-01
    z[3,4,3]  R1664     5.9145528078079224e-01
    z[3,4,3]  R1665     5.5927777290344238e-01
    z[3,4,3]  R1666     5.6667649745941162e-01
    z[3,4,3]  R1667     5.4406929016113281e-01
    z[3,4,3]  R1668     6.5865945816040039e-01
    z[3,4,3]  R1669     0.662432074546814
    z[3,4,3]  R1670     6.5003538131713867e-01
    z[3,4,3]  R1671     6.3249212503433228e-01
    z[3,4,3]  R1672     6.2142062187194824e-01
    z[3,4,3]  R1673     6.7430156469345093e-01
    z[3,4,3]  R1674     6.3411563634872437e-01
    z[3,4,3]  R1675     5.6758403778076172e-01
    z[3,4,3]  R1676     5.3503137826919556e-01
    z[3,4,3]  R1677     6.4338076114654541e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1563     -1
    z[3,4,4]  R1564     1
    z[3,4,4]  R1569     -2.3091910779476166e-01
    z[3,4,4]  R1570     -1.9820597767829895e-01
    z[3,4,4]  R1571     -0.223605215549469
    z[3,4,4]  R1572     -3.1431868672370911e-01
    z[3,4,4]  R1573     -3.4318295121192932e-01
    z[3,4,4]  R1574     -4.1663515567779541e-01
    z[3,4,4]  R1575     -3.9054206013679504e-01
    z[3,4,4]  R1576     -8.2912124693393707e-02
    z[3,4,4]  R1577     -5.5594122409820557e-01
    z[3,4,4]  R1578     -2.8605180978775024e-01
    z[3,4,4]  R1579     -1.5274184942245483e-01
    z[3,4,4]  R1580     -1.1104546487331390e-01
    z[3,4,4]  R1581     -2.5291544198989868e-01
    z[3,4,4]  R1582     8.7573297321796417e-02
    z[3,4,4]  R1583     0.0885215625166893
    z[3,4,4]  R1584     -1.4982230961322784e-01
    z[3,4,4]  R1585     2.2073255851864815e-02
    z[3,4,4]  R1586     -9.8633743822574615e-02
    z[3,4,4]  R1587     -1.6097214818000793e-01
    z[3,4,4]  R1588     -3.5569289326667786e-01
    z[3,4,4]  R1589     3.1154308468103409e-02
    z[3,4,4]  R1590     -1.8996725976467133e-01
    z[3,4,4]  R1591     7.9639393091201782e-01
    z[3,4,4]  R1592     8.2627013325691223e-03
    z[3,4,4]  R1593     2.2096820175647736e-01
    z[3,4,4]  R1594     3.2409203052520752e-01
    z[3,4,4]  R1595     2.6137617230415344e-01
    z[3,4,4]  R1596     -4.2287570238113403e-01
    z[3,4,4]  R1597     -2.0530524849891663e-01
    z[3,4,4]  R1598     -5.1775805652141571e-02
    z[3,4,4]  R1599     0.721405565738678
    z[3,4,4]  R1600     3.3904662728309631e-01
    z[3,4,4]  R1601     0.536944568157196
    z[3,4,4]  R1602     5.3472465276718140e-01
    z[3,4,4]  R1603     3.1423911452293396e-01
    z[3,4,4]  R1604     3.7826636433601379e-01
    z[3,4,4]  R1605     -1.6794683039188385e-01
    z[3,4,4]  R1606     2.4229032918810844e-02
    z[3,4,4]  R1607     2.3647651076316833e-01
    z[3,4,4]  R1608     5.2013982087373734e-02
    z[3,4,4]  R1609     3.5284776240587234e-02
    z[3,4,4]  R1610     4.6251362562179565e-01
    z[3,4,4]  R1611     3.9560711383819580e-01
    z[3,4,4]  R1612     -1.7187000811100006e-01
    z[3,4,4]  R1613     8.7326399981975555e-02
    z[3,4,4]  R1614     3.7959685921669006e-01
    z[3,4,4]  R1615     2.2575959563255310e-01
    z[3,4,4]  R1616     4.5889419317245483e-01
    z[3,4,4]  R1617     -3.0037787556648254e-01
    z[3,4,4]  R1618     1.6902795433998108e-01
    z[3,4,4]  R1619     4.5079541206359863e-01
    z[3,4,4]  R1620     2.2691859304904938e-01
    z[3,4,4]  R1621     5.3960567712783813e-01
    z[3,4,4]  R1622     1.1950118094682693e-01
    z[3,4,4]  R1623     -0.562481164932251
    z[3,4,4]  R1624     4.0394267439842224e-01
    z[3,4,4]  R1625     -1.9072486320510507e-03
    z[3,4,4]  R1626     0.494154691696167
    z[3,4,4]  R1627     -1.9802886247634888e-01
    z[3,4,4]  R1628     2.0406669378280640e-01
    z[3,4,4]  R1629     3.5650530457496643e-01
    z[3,4,4]  R1630     -3.6467918753623962e-01
    z[3,4,4]  R1631     -8.4266647696495056e-02
    z[3,4,4]  R1632     -4.7175593674182892e-02
    z[3,4,4]  R1633     -1.6847534105181694e-02
    z[3,4,4]  R1634     5.5132389068603516e-01
    z[3,4,4]  R1635     0.340406596660614
    z[3,4,4]  R1636     1.7809723317623138e-01
    z[3,4,4]  R1637     -2.5065923109650612e-02
    z[3,4,4]  R1638     -3.7347182631492615e-01
    z[3,4,4]  R1639     -4.3055397272109985e-01
    z[3,4,4]  R1640     2.2676877677440643e-02
    z[3,4,4]  R1641     -7.1557931602001190e-02
    z[3,4,4]  R1642     -6.9433611631393433e-01
    z[3,4,4]  R1643     -5.7911306619644165e-01
    z[3,4,4]  R1644     -0.0732896476984024
    z[3,4,4]  R1645     -1.2858195602893829e-01
    z[3,4,4]  R1646     -4.0163826942443848e-01
    z[3,4,4]  R1647     -6.4065003395080566e-01
    z[3,4,4]  R1648     2.7452877163887024e-01
    z[3,4,4]  R1649     4.4084548950195312e-01
    z[3,4,4]  R1650     5.1864463090896606e-01
    z[3,4,4]  R1651     2.4805767834186554e-01
    z[3,4,4]  R1652     -4.6411193907260895e-02
    z[3,4,4]  R1653     0.329597145318985
    z[3,4,4]  R1654     -1.4363935589790344e-01
    z[3,4,4]  R1655     7.1478348970413208e-01
    z[3,4,4]  R1656     5.4629105329513550e-01
    z[3,4,4]  R1657     5.3774231672286987e-01
    z[3,4,4]  R1658     -4.0136259794235229e-01
    z[3,4,4]  R1659     2.0788341760635376e-02
    z[3,4,4]  R1660     4.5161384344100952e-01
    z[3,4,4]  R1661     4.1718937456607819e-02
    z[3,4,4]  R1662     -0.203811913728714
    z[3,4,4]  R1663     1.4877521991729736e-01
    z[3,4,4]  R1664     -2.0560060441493988e-01
    z[3,4,4]  R1665     2.3319673538208008e-01
    z[3,4,4]  R1666     1.9234456121921539e-01
    z[3,4,4]  R1667     6.6936874389648438e-01
    z[3,4,4]  R1668     1.0328670591115952e-01
    z[3,4,4]  R1669     5.5827479809522629e-02
    z[3,4,4]  R1670     0.00386149063706398
    z[3,4,4]  R1671     1.9641930237412453e-02
    z[3,4,4]  R1672     -1.2796667218208313e-01
    z[3,4,4]  R1673     5.3986251354217529e-02
    z[3,4,4]  R1674     1.5775239467620850e-01
    z[3,4,4]  R1675     -3.1440962105989456e-02
    z[3,4,4]  R1676     1.8580880761146545e-01
    z[3,4,4]  R1677     6.8503051996231079e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1565     -1
    z[3,4,5]  R1566     1
    z[3,4,5]  R1569     -2.7438384294509888e-01
    z[3,4,5]  R1570     1.9655370712280273e-01
    z[3,4,5]  R1571     9.9414110183715820e-02
    z[3,4,5]  R1572     1.8051995337009430e-01
    z[3,4,5]  R1573     1.2213288247585297e-01
    z[3,4,5]  R1574     -8.3527758717536926e-02
    z[3,4,5]  R1575     -2.8987939003854990e-03
    z[3,4,5]  R1576     -3.8450825214385986e-01
    z[3,4,5]  R1577     -1.7510086297988892e-01
    z[3,4,5]  R1578     0.253398597240448
    z[3,4,5]  R1579     0.00825007539242506
    z[3,4,5]  R1580     4.9329242110252380e-01
    z[3,4,5]  R1581     4.4502985477447510e-01
    z[3,4,5]  R1582     -1.3583134859800339e-02
    z[3,4,5]  R1583     5.4998189210891724e-02
    z[3,4,5]  R1584     2.7247005701065063e-01
    z[3,4,5]  R1585     1.1730955541133881e-01
    z[3,4,5]  R1586     4.0171834826469421e-01
    z[3,4,5]  R1587     3.2744646072387695e-01
    z[3,4,5]  R1588     0.0937584787607193
    z[3,4,5]  R1589     1.3725067675113678e-01
    z[3,4,5]  R1590     3.8609090447425842e-01
    z[3,4,5]  R1591     -4.2861010879278183e-02
    z[3,4,5]  R1592     -2.5508111715316772e-01
    z[3,4,5]  R1593     -4.9958512187004089e-02
    z[3,4,5]  R1594     0.0769592747092247
    z[3,4,5]  R1595     -1.3457165658473969e-01
    z[3,4,5]  R1596     2.4149735271930695e-01
    z[3,4,5]  R1597     1.6522608697414398e-01
    z[3,4,5]  R1598     4.5957455039024353e-01
    z[3,4,5]  R1599     -1.4389362931251526e-01
    z[3,4,5]  R1600     1.6535639762878418e-01
    z[3,4,5]  R1601     3.1621418893337250e-02
    z[3,4,5]  R1602     -1.0094086080789566e-01
    z[3,4,5]  R1603     0.306438684463501
    z[3,4,5]  R1604     4.3003073334693909e-01
    z[3,4,5]  R1605     5.4396629333496094e-01
    z[3,4,5]  R1606     6.4435862004756927e-02
    z[3,4,5]  R1607     3.2721394300460815e-01
    z[3,4,5]  R1608     -2.8444245457649231e-01
    z[3,4,5]  R1609     -5.0231266021728516e-01
    z[3,4,5]  R1610     -6.2959247827529907e-01
    z[3,4,5]  R1611     3.7279227375984192e-01
    z[3,4,5]  R1612     1.6531041264533997e-01
    z[3,4,5]  R1613     -1.9833190739154816e-01
    z[3,4,5]  R1614     -1.8671898543834686e-01
    z[3,4,5]  R1615     2.3983092606067657e-01
    z[3,4,5]  R1616     9.2646442353725433e-02
    z[3,4,5]  R1617     3.4028777480125427e-01
    z[3,4,5]  R1618     4.1649112105369568e-01
    z[3,4,5]  R1619     8.1165522336959839e-02
    z[3,4,5]  R1620     1.4363476634025574e-01
    z[3,4,5]  R1621     1.0789851844310760e-01
    z[3,4,5]  R1622     -2.3141042888164520e-01
    z[3,4,5]  R1623     -1.7139554023742676e-02
    z[3,4,5]  R1624     -0.318229079246521
    z[3,4,5]  R1625     2.6526167988777161e-01
    z[3,4,5]  R1626     -2.1993994712829590e-01
    z[3,4,5]  R1627     1.5587139129638672e-01
    z[3,4,5]  R1628     3.8067254424095154e-01
    z[3,4,5]  R1629     3.0121762305498123e-02
    z[3,4,5]  R1630     5.5897551774978638e-01
    z[3,4,5]  R1631     2.1398428082466125e-01
    z[3,4,5]  R1632     3.8329538702964783e-01
    z[3,4,5]  R1633     2.9617869853973389e-01
    z[3,4,5]  R1634     0.158024862408638
    z[3,4,5]  R1635     -2.8970161080360413e-01
    z[3,4,5]  R1636     3.5380387306213379e-01
    z[3,4,5]  R1637     3.3629050850868225e-01
    z[3,4,5]  R1638     3.0502617359161377e-01
    z[3,4,5]  R1639     4.9484741687774658e-01
    z[3,4,5]  R1640     2.5460910797119141e-01
    z[3,4,5]  R1641     3.3628630638122559e-01
    z[3,4,5]  R1642     -1.0812437534332275e-01
    z[3,4,5]  R1643     3.5929408669471741e-01
    z[3,4,5]  R1644     0.0888829231262207
    z[3,4,5]  R1645     6.2359537929296494e-02
    z[3,4,5]  R1646     -8.1958241760730743e-02
    z[3,4,5]  R1647     1.0259815305471420e-01
    z[3,4,5]  R1648     -4.0154001116752625e-01
    z[3,4,5]  R1649     -0.666703999042511
    z[3,4,5]  R1650     1.5759790316224098e-02
    z[3,4,5]  R1651     -1.9583757221698761e-01
    z[3,4,5]  R1652     -5.0340473651885986e-01
    z[3,4,5]  R1653     1.3030278682708740e-01
    z[3,4,5]  R1654     -7.1038591861724854e-01
    z[3,4,5]  R1655     -5.6272368878126144e-02
    z[3,4,5]  R1656     -2.5221112370491028e-01
    z[3,4,5]  R1657     -1.6141898930072784e-01
    z[3,4,5]  R1658     -0.500432014465332
    z[3,4,5]  R1659     -5.0948232412338257e-01
    z[3,4,5]  R1660     -2.1376492083072662e-01
    z[3,4,5]  R1661     -4.3151828646659851e-01
    z[3,4,5]  R1662     -0.416143000125885
    z[3,4,5]  R1663     8.0096609890460968e-02
    z[3,4,5]  R1664     4.8506391048431396e-01
    z[3,4,5]  R1665     1.5715818107128143e-01
    z[3,4,5]  R1666     4.4791880249977112e-01
    z[3,4,5]  R1667     1.6610497608780861e-02
    z[3,4,5]  R1668     8.6551554501056671e-02
    z[3,4,5]  R1669     4.0178185701370239e-01
    z[3,4,5]  R1670     2.5812906026840210e-01
    z[3,4,5]  R1671     7.6234221458435059e-02
    z[3,4,5]  R1672     -5.8103847503662109e-01
    z[3,4,5]  R1673     -5.1187396049499512e-02
    z[3,4,5]  R1674     -9.4732657074928284e-02
    z[3,4,5]  R1675     -9.8502397537231445e-02
    z[3,4,5]  R1676     -2.8530222177505493e-01
    z[3,4,5]  R1677     -9.2689990997314453e-02
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1567     -1
    z[3,4,6]  R1568     1
    z[3,4,6]  R1569     -9.0920627117156982e-02
    z[3,4,6]  R1570     -1.1257733404636383e-01
    z[3,4,6]  R1571     -1.5459421277046204e-01
    z[3,4,6]  R1572     -3.3619552850723267e-01
    z[3,4,6]  R1573     -7.4777096509933472e-02
    z[3,4,6]  R1574     2.9738730192184448e-01
    z[3,4,6]  R1575     4.5432859659194946e-01
    z[3,4,6]  R1576     3.5045480728149414e-01
    z[3,4,6]  R1577     -0.0526314415037632
    z[3,4,6]  R1578     2.6307487487792969e-01
    z[3,4,6]  R1579     6.2678828835487366e-02
    z[3,4,6]  R1580     -3.8197159767150879e-02
    z[3,4,6]  R1581     9.3276090919971466e-02
    z[3,4,6]  R1582     -2.4080686271190643e-02
    z[3,4,6]  R1583     -1.4493295550346375e-01
    z[3,4,6]  R1584     3.5655535757541656e-02
    z[3,4,6]  R1585     0.0522799976170063
    z[3,4,6]  R1586     3.2310735434293747e-02
    z[3,4,6]  R1587     8.5448555648326874e-02
    z[3,4,6]  R1588     1.2455178052186966e-01
    z[3,4,6]  R1589     1.9001878798007965e-01
    z[3,4,6]  R1590     -5.6835031509399414e-01
    z[3,4,6]  R1591     -3.0935180187225342e-01
    z[3,4,6]  R1592     5.9268784523010254e-01
    z[3,4,6]  R1593     8.0272859334945679e-01
    z[3,4,6]  R1594     -4.1821199655532837e-01
    z[3,4,6]  R1595     5.3628188371658325e-01
    z[3,4,6]  R1596     7.5863644480705261e-02
    z[3,4,6]  R1597     3.7423965334892273e-01
    z[3,4,6]  R1598     7.4497717432677746e-03
    z[3,4,6]  R1599     1.6224814951419830e-01
    z[3,4,6]  R1600     -3.0374118685722351e-01
    z[3,4,6]  R1601     -3.4164834022521973e-01
    z[3,4,6]  R1602     6.2955850362777710e-01
    z[3,4,6]  R1603     3.8678586483001709e-01
    z[3,4,6]  R1604     -1.4108885824680328e-01
    z[3,4,6]  R1605     -2.0895342528820038e-01
    z[3,4,6]  R1606     -1.1328030377626419e-01
    z[3,4,6]  R1607     -0.0601862333714962
    z[3,4,6]  R1608     -2.4160975217819214e-01
    z[3,4,6]  R1609     3.6350575089454651e-01
    z[3,4,6]  R1610     1.0825856775045395e-01
    z[3,4,6]  R1611     -5.4732393473386765e-02
    z[3,4,6]  R1612     3.5946875810623169e-01
    z[3,4,6]  R1613     -2.4727845191955566e-01
    z[3,4,6]  R1614     6.0292577743530273e-01
    z[3,4,6]  R1615     -1.4043906331062317e-01
    z[3,4,6]  R1616     3.4061953425407410e-01
    z[3,4,6]  R1617     -0.281399667263031
    z[3,4,6]  R1618     -5.6827016174793243e-02
    z[3,4,6]  R1619     -3.1062424182891846e-01
    z[3,4,6]  R1620     6.1044901609420776e-01
    z[3,4,6]  R1621     1.9057519733905792e-01
    z[3,4,6]  R1622     6.6493093967437744e-01
    z[3,4,6]  R1623     7.8965082764625549e-02
    z[3,4,6]  R1624     7.5730517506599426e-02
    z[3,4,6]  R1625     1.0132216662168503e-01
    z[3,4,6]  R1626     2.6948660612106323e-01
    z[3,4,6]  R1627     -4.2699408531188965e-01
    z[3,4,6]  R1628     1.2564989924430847e-01
    z[3,4,6]  R1629     1.0915504395961761e-01
    z[3,4,6]  R1630     4.7250889241695404e-02
    z[3,4,6]  R1631     -1.4756020903587341e-01
    z[3,4,6]  R1632     -0.0288847703486681
    z[3,4,6]  R1633     -1.6712214052677155e-01
    z[3,4,6]  R1634     -1.6119672358036041e-01
    z[3,4,6]  R1635     1.5063390135765076e-01
    z[3,4,6]  R1636     1.5044826269149780e-01
    z[3,4,6]  R1637     2.8009437024593353e-02
    z[3,4,6]  R1638     3.4300554543733597e-03
    z[3,4,6]  R1639     -2.9553198255598545e-03
    z[3,4,6]  R1640     5.7289695739746094e-01
    z[3,4,6]  R1641     -3.2113909721374512e-01
    z[3,4,6]  R1642     2.3305638134479523e-01
    z[3,4,6]  R1643     -6.3961118459701538e-02
    z[3,4,6]  R1644     2.2625601291656494e-01
    z[3,4,6]  R1645     -1.0131567716598511e-01
    z[3,4,6]  R1646     6.1252242326736450e-01
    z[3,4,6]  R1647     1.9123022258281708e-01
    z[3,4,6]  R1648     -3.1890419125556946e-01
    z[3,4,6]  R1649     -2.0590442419052124e-01
    z[3,4,6]  R1650     -0.414957195520401
    z[3,4,6]  R1651     -3.7433198094367981e-01
    z[3,4,6]  R1652     -2.0747286081314087e-01
    z[3,4,6]  R1653     -2.7607965469360352e-01
    z[3,4,6]  R1654     1.5594394505023956e-01
    z[3,4,6]  R1655     4.1695764660835266e-01
    z[3,4,6]  R1656     9.8663009703159332e-02
    z[3,4,6]  R1657     3.7763953208923340e-01
    z[3,4,6]  R1658     -8.2898207008838654e-02
    z[3,4,6]  R1659     -2.0093081891536713e-01
    z[3,4,6]  R1660     0.0621473453938961
    z[3,4,6]  R1661     1.5214161947369576e-02
    z[3,4,6]  R1662     -4.7630748152732849e-01
    z[3,4,6]  R1663     5.1341992616653442e-01
    z[3,4,6]  R1664     -3.5862424969673157e-01
    z[3,4,6]  R1665     0.41744464635849
    z[3,4,6]  R1666     9.5681458711624146e-02
    z[3,4,6]  R1667     3.6838880181312561e-01
    z[3,4,6]  R1668     4.6484112739562988e-01
    z[3,4,6]  R1669     3.9420583844184875e-01
    z[3,4,6]  R1670     3.4531581401824951e-01
    z[3,4,6]  R1671     -3.6222934722900391e-01
    z[3,4,6]  R1672     -1.2603670358657837e-01
    z[3,4,6]  R1673     -3.8603344559669495e-01
    z[3,4,6]  R1674     3.1251555681228638e-01
    z[3,4,6]  R1675     -3.8927948474884033e-01
    z[3,4,6]  R1676     2.9809162020683289e-01
    z[3,4,6]  R1677     -4.5947216451168060e-02
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1678     -1
    z[4,3,0]  R1679     1
    z[4,3,0]  R1692     1.1057145148515701e-01
    z[4,3,0]  R1693     4.1727516055107117e-01
    z[4,3,0]  R1694     2.3384353518486023e-01
    z[4,3,0]  R1695     1.9234964251518250e-01
    z[4,3,0]  R1696     5.4365879297256470e-01
    z[4,3,0]  R1697     3.6887899041175842e-01
    z[4,3,0]  R1698     -6.3091731071472168e-01
    z[4,3,0]  R1699     -6.5363544225692749e-01
    z[4,3,0]  R1700     -3.6788159608840942e-01
    z[4,3,0]  R1701     -5.4095560312271118e-01
    z[4,3,0]  R1702     3.3544310927391052e-01
    z[4,3,0]  R1703     0.445083886384964
    z[4,3,0]  R1704     5.9949624538421631e-01
    z[4,3,0]  R1705     -1.0904526337981224e-02
    z[4,3,0]  R1706     -1.9388508796691895e-01
    z[4,3,0]  R1707     -4.3607071042060852e-01
    z[4,3,0]  R1708     -2.3525188863277435e-01
    z[4,3,0]  R1709     -8.3016566932201385e-03
    z[4,3,0]  R1710     -1.6211374104022980e-01
    z[4,3,0]  R1711     -0.299001544713974
    z[4,3,0]  R1712     -4.3869003653526306e-01
    z[4,3,0]  R1713     -3.7246486544609070e-01
    z[4,3,0]  R1714     1.8723241984844208e-01
    z[4,3,0]  R1715     -4.7213220596313477e-01
    z[4,3,0]  R1716     -2.7378988265991211e-01
    z[4,3,0]  R1717     1.4399564266204834e-01
    z[4,3,0]  R1718     -4.4520506262779236e-01
    z[4,3,0]  R1719     -2.6701837778091431e-01
    z[4,3,0]  R1720     2.3060111701488495e-01
    z[4,3,0]  R1721     -1.7048522830009460e-01
    z[4,3,0]  R1722     -2.3564680013805628e-03
    z[4,3,0]  R1723     2.5751056149601936e-02
    z[4,3,0]  R1724     -2.6718097925186157e-01
    z[4,3,0]  R1725     -5.3210258483886719e-01
    z[4,3,0]  R1726     -0.392514169216156
    z[4,3,0]  R1727     -3.9334365725517273e-01
    z[4,3,0]  R1728     -4.2745375633239746e-01
    z[4,3,0]  R1729     0.0908120647072792
    z[4,3,0]  R1730     3.8633909821510315e-01
    z[4,3,0]  R1731     -2.6486802101135254e-01
    z[4,3,0]  R1732     3.7067100405693054e-02
    z[4,3,0]  R1733     3.7179496884346008e-01
    z[4,3,0]  R1734     -4.1181966662406921e-01
    z[4,3,0]  R1735     5.1207607984542847e-01
    z[4,3,0]  R1736     -6.3994753360748291e-01
    z[4,3,0]  R1737     -0.316124826669693
    z[4,3,0]  R1738     -4.0294739603996277e-01
    z[4,3,0]  R1739     5.3729891777038574e-01
    z[4,3,0]  R1740     -4.6869885921478271e-01
    z[4,3,0]  R1741     -4.5559534430503845e-01
    z[4,3,0]  R1742     7.8173793852329254e-02
    z[4,3,0]  R1743     -1.7945900559425354e-01
    z[4,3,0]  R1744     -1.2135547585785389e-03
    z[4,3,0]  R1745     -0.0807340145111084
    z[4,3,0]  R1746     -2.4226111173629761e-01
    z[4,3,0]  R1747     -2.3268264532089233e-01
    z[4,3,0]  R1748     -5.3354259580373764e-02
    z[4,3,0]  R1749     -3.0456345528364182e-02
    z[4,3,0]  R1750     -2.2064997255802155e-01
    z[4,3,0]  R1751     -4.6148531138896942e-02
    z[4,3,0]  R1752     6.5666645765304565e-02
    z[4,3,0]  R1753     -1.9799323379993439e-01
    z[4,3,0]  R1754     3.2701876759529114e-01
    z[4,3,0]  R1755     -1.4233329892158508e-01
    z[4,3,0]  R1756     1.9304735586047173e-02
    z[4,3,0]  R1757     -1.5847027301788330e-01
    z[4,3,0]  R1758     5.3673553466796875e-01
    z[4,3,0]  R1759     3.6323402076959610e-02
    z[4,3,0]  R1760     -3.4531587362289429e-01
    z[4,3,0]  R1761     -1.6749443113803864e-01
    z[4,3,0]  R1762     -2.3113049566745758e-01
    z[4,3,0]  R1763     -4.3012022972106934e-02
    z[4,3,0]  R1764     4.8231253027915955e-01
    z[4,3,0]  R1765     2.5550296530127525e-02
    z[4,3,0]  R1766     -2.0028276741504669e-01
    z[4,3,0]  R1767     -4.8691046237945557e-01
    z[4,3,0]  R1768     -1.2682755291461945e-01
    z[4,3,0]  R1769     2.6874890923500061e-01
    z[4,3,0]  R1770     1.3006573915481567e-01
    z[4,3,0]  R1771     3.6033737659454346e-01
    z[4,3,0]  R1772     5.9692794084548950e-01
    z[4,3,0]  R1773     3.9397379755973816e-01
    z[4,3,0]  R1774     -1.7629776895046234e-01
    z[4,3,0]  R1775     1.2649475038051605e-01
    z[4,3,0]  R1776     5.8065932244062424e-02
    z[4,3,0]  R1777     -2.4579444527626038e-01
    z[4,3,0]  R1778     6.5198093652725220e-02
    z[4,3,0]  R1779     5.4943734407424927e-01
    z[4,3,0]  R1780     -1.5163809061050415e-01
    z[4,3,0]  R1781     -2.2004279494285583e-01
    z[4,3,0]  R1782     -1.1727644503116608e-01
    z[4,3,0]  R1783     1.9039590656757355e-01
    z[4,3,0]  R1784     2.9173459857702255e-02
    z[4,3,0]  R1785     -5.5233038961887360e-02
    z[4,3,0]  R1786     -1.4811183512210846e-01
    z[4,3,0]  R1787     9.3578584492206573e-02
    z[4,3,0]  R1788     -9.8985306918621063e-02
    z[4,3,0]  R1789     -1.3010847568511963e-01
    z[4,3,0]  R1790     1.1820724606513977e-01
    z[4,3,0]  R1791     -2.2255496680736542e-01
    z[4,3,0]  R1792     -1.2191570550203323e-01
    z[4,3,0]  R1793     -3.0332719907164574e-02
    z[4,3,0]  R1794     -8.1705629825592041e-02
    z[4,3,0]  R1795     -3.3933378756046295e-02
    z[4,3,0]  R1796     4.9755383282899857e-02
    z[4,3,0]  R1797     1.3494296371936798e-01
    z[4,3,0]  R1798     0.0110483942553401
    z[4,3,0]  R1799     1.4044113457202911e-01
    z[4,3,0]  R1800     0.590168297290802
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1680     -1
    z[4,3,1]  R1681     1
    z[4,3,1]  R1692     0.130645290017128
    z[4,3,1]  R1693     -3.6773982644081116e-01
    z[4,3,1]  R1694     2.6268604397773743e-01
    z[4,3,1]  R1695     -5.1379489898681641e-01
    z[4,3,1]  R1696     2.4627435952425003e-02
    z[4,3,1]  R1697     1.4645354449748993e-01
    z[4,3,1]  R1698     -5.5749481916427612e-01
    z[4,3,1]  R1699     -4.8125651478767395e-01
    z[4,3,1]  R1700     -4.1433036327362061e-01
    z[4,3,1]  R1701     -3.8606163859367371e-01
    z[4,3,1]  R1702     5.6183934211730957e-01
    z[4,3,1]  R1703     2.4856026470661163e-01
    z[4,3,1]  R1704     4.4114881753921509e-01
    z[4,3,1]  R1705     8.5515290498733521e-01
    z[4,3,1]  R1706     0.806327760219574
    z[4,3,1]  R1707     7.7940917015075684e-01
    z[4,3,1]  R1708     -2.1536909043788910e-01
    z[4,3,1]  R1709     -3.5275441408157349e-01
    z[4,3,1]  R1710     -7.1298718452453613e-02
    z[4,3,1]  R1711     -3.2652860879898071e-01
    z[4,3,1]  R1712     -5.2660995721817017e-01
    z[4,3,1]  R1713     -3.6260443925857544e-01
    z[4,3,1]  R1714     -6.5382492542266846e-01
    z[4,3,1]  R1715     2.8144272044301033e-02
    z[4,3,1]  R1716     -2.3942266404628754e-01
    z[4,3,1]  R1717     2.6355481147766113e-01
    z[4,3,1]  R1718     -6.8916711024940014e-03
    z[4,3,1]  R1719     9.4218976795673370e-02
    z[4,3,1]  R1720     -3.7219020724296570e-01
    z[4,3,1]  R1721     -2.7761897444725037e-01
    z[4,3,1]  R1722     1.7800673842430115e-01
    z[4,3,1]  R1723     -2.5634220242500305e-01
    z[4,3,1]  R1724     2.1152906119823456e-01
    z[4,3,1]  R1725     2.9970075935125351e-02
    z[4,3,1]  R1726     -4.8902123235166073e-03
    z[4,3,1]  R1727     -1.8356233835220337e-01
    z[4,3,1]  R1728     -0.253077894449234
    z[4,3,1]  R1729     -5.9396427869796753e-01
    z[4,3,1]  R1730     -3.2510635256767273e-01
    z[4,3,1]  R1731     -1.5003034472465515e-01
    z[4,3,1]  R1732     6.9367986917495728e-01
    z[4,3,1]  R1733     6.6264796257019043e-01
    z[4,3,1]  R1734     -4.9712666869163513e-01
    z[4,3,1]  R1735     4.0542349219322205e-01
    z[4,3,1]  R1736     -0.443347305059433
    z[4,3,1]  R1737     -5.1285165548324585e-01
    z[4,3,1]  R1738     -0.450613796710968
    z[4,3,1]  R1739     6.5254640579223633e-01
    z[4,3,1]  R1740     -6.2381881475448608e-01
    z[4,3,1]  R1741     7.0405995845794678e-01
    z[4,3,1]  R1742     -9.6634417772293091e-01
    z[4,3,1]  R1743     -8.2638806104660034e-01
    z[4,3,1]  R1744     -8.3274024724960327e-01
    z[4,3,1]  R1745     -9.4393610954284668e-01
    z[4,3,1]  R1746     -8.9501363039016724e-01
    z[4,3,1]  R1747     -8.5856539011001587e-01
    z[4,3,1]  R1748     -9.3438696861267090e-01
    z[4,3,1]  R1749     -8.9354443550109863e-01
    z[4,3,1]  R1750     -8.9741677045822144e-01
    z[4,3,1]  R1751     -8.6780643463134766e-01
    z[4,3,1]  R1752     9.0192121267318726e-01
    z[4,3,1]  R1753     0.6239013671875
    z[4,3,1]  R1754     3.4472694993019104e-01
    z[4,3,1]  R1755     0.70050448179245
    z[4,3,1]  R1756     4.5671561360359192e-01
    z[4,3,1]  R1757     0.627260684967041
    z[4,3,1]  R1758     7.8109733294695616e-04
    z[4,3,1]  R1759     -7.5922125577926636e-01
    z[4,3,1]  R1760     -0.715255618095398
    z[4,3,1]  R1761     -5.2114403247833252e-01
    z[4,3,1]  R1762     7.6005853712558746e-02
    z[4,3,1]  R1763     0.802408754825592
    z[4,3,1]  R1764     -0.0430334135890007
    z[4,3,1]  R1765     4.5041911303997040e-02
    z[4,3,1]  R1766     3.0691778659820557e-01
    z[4,3,1]  R1767     2.6438814401626587e-01
    z[4,3,1]  R1768     -5.6059908866882324e-01
    z[4,3,1]  R1769     -6.6544133424758911e-01
    z[4,3,1]  R1770     -6.2691295146942139e-01
    z[4,3,1]  R1771     -6.3844412565231323e-01
    z[4,3,1]  R1772     1.4414748549461365e-01
    z[4,3,1]  R1773     3.5924646258354187e-01
    z[4,3,1]  R1774     4.2892915010452271e-01
    z[4,3,1]  R1775     7.6178300380706787e-01
    z[4,3,1]  R1776     8.5596400499343872e-01
    z[4,3,1]  R1777     5.7058918476104736e-01
    z[4,3,1]  R1778     0.0888204276561737
    z[4,3,1]  R1779     0.0500313900411129
    z[4,3,1]  R1780     -7.8557604551315308e-01
    z[4,3,1]  R1781     -6.9789052009582520e-01
    z[4,3,1]  R1782     5.8851748704910278e-01
    z[4,3,1]  R1783     3.6812219023704529e-01
    z[4,3,1]  R1784     7.0105659961700439e-01
    z[4,3,1]  R1785     6.9236093759536743e-01
    z[4,3,1]  R1786     7.4410974979400635e-01
    z[4,3,1]  R1787     -7.9978233575820923e-01
    z[4,3,1]  R1788     -6.6857415437698364e-01
    z[4,3,1]  R1789     -7.6604461669921875e-01
    z[4,3,1]  R1790     -8.1263101100921631e-01
    z[4,3,1]  R1791     2.2216621041297913e-01
    z[4,3,1]  R1792     8.7879288196563721e-01
    z[4,3,1]  R1793     6.9568967819213867e-01
    z[4,3,1]  R1794     -7.6769274473190308e-01
    z[4,3,1]  R1795     -0.793660581111908
    z[4,3,1]  R1796     -8.9406061172485352e-01
    z[4,3,1]  R1797     -0.69505375623703
    z[4,3,1]  R1798     -6.0580420494079590e-01
    z[4,3,1]  R1799     -4.4465139508247375e-03
    z[4,3,1]  R1800     1.0688560083508492e-02
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1682     -1
    z[4,3,2]  R1683     1
    z[4,3,2]  R1692     5.3853130340576172e-01
    z[4,3,2]  R1693     4.5679494738578796e-01
    z[4,3,2]  R1694     3.0801385641098022e-01
    z[4,3,2]  R1695     6.5136075019836426e-01
    z[4,3,2]  R1696     -4.6572912484407425e-02
    z[4,3,2]  R1697     -4.5000651478767395e-01
    z[4,3,2]  R1698     -4.6828472614288330e-01
    z[4,3,2]  R1699     -5.4492324590682983e-01
    z[4,3,2]  R1700     -0.384880930185318
    z[4,3,2]  R1701     -2.2524002194404602e-01
    z[4,3,2]  R1702     4.2095446586608887e-01
    z[4,3,2]  R1703     2.4210751056671143e-01
    z[4,3,2]  R1704     -3.2490931451320648e-02
    z[4,3,2]  R1705     -1.3517902791500092e-01
    z[4,3,2]  R1706     -4.4970061630010605e-02
    z[4,3,2]  R1707     6.9062080001458526e-05
    z[4,3,2]  R1708     -3.5839927196502686e-01
    z[4,3,2]  R1709     1.2573441490530968e-02
    z[4,3,2]  R1710     -4.2000892758369446e-01
    z[4,3,2]  R1711     -7.6218426227569580e-02
    z[4,3,2]  R1712     -3.3413589000701904e-01
    z[4,3,2]  R1713     -6.0285800695419312e-01
    z[4,3,2]  R1714     -4.9539190530776978e-01
    z[4,3,2]  R1715     -4.5029523968696594e-01
    z[4,3,2]  R1716     -2.0784315466880798e-01
    z[4,3,2]  R1717     -5.2851992845535278e-01
    z[4,3,2]  R1718     -2.1390576660633087e-01
    z[4,3,2]  R1719     -5.9472084045410156e-01
    z[4,3,2]  R1720     -4.9029859900474548e-01
    z[4,3,2]  R1721     1.1751763522624969e-01
    z[4,3,2]  R1722     -5.4794090986251831e-01
    z[4,3,2]  R1723     -4.1816940903663635e-01
    z[4,3,2]  R1724     -5.2481925487518311e-01
    z[4,3,2]  R1725     -4.2251008749008179e-01
    z[4,3,2]  R1726     -2.9979768395423889e-01
    z[4,3,2]  R1727     -4.4982945919036865e-01
    z[4,3,2]  R1728     -4.6862161159515381e-01
    z[4,3,2]  R1729     -3.9316442608833313e-01
    z[4,3,2]  R1730     -5.0399243831634521e-01
    z[4,3,2]  R1731     -1.1587807536125183e-01
    z[4,3,2]  R1732     3.7445166707038879e-01
    z[4,3,2]  R1733     -2.4146245419979095e-01
    z[4,3,2]  R1734     -6.5644830465316772e-01
    z[4,3,2]  R1735     -1.2594206631183624e-01
    z[4,3,2]  R1736     -5.0185889005661011e-01
    z[4,3,2]  R1737     -3.9556607604026794e-01
    z[4,3,2]  R1738     -4.8620283603668213e-01
    z[4,3,2]  R1739     -5.1303360611200333e-02
    z[4,3,2]  R1740     -1.8828479945659637e-01
    z[4,3,2]  R1741     -1.8435798585414886e-01
    z[4,3,2]  R1742     1.3297490775585175e-01
    z[4,3,2]  R1743     -1.6308559570461512e-03
    z[4,3,2]  R1744     -7.8419208526611328e-02
    z[4,3,2]  R1745     1.8751381337642670e-01
    z[4,3,2]  R1746     1.4740787446498871e-01
    z[4,3,2]  R1747     3.0041760206222534e-01
    z[4,3,2]  R1748     3.2278785109519958e-01
    z[4,3,2]  R1749     1.4655736088752747e-01
    z[4,3,2]  R1750     -4.4597167521715164e-02
    z[4,3,2]  R1751     2.1245136857032776e-01
    z[4,3,2]  R1752     -1.2600612640380859e-01
    z[4,3,2]  R1753     -2.3675315082073212e-01
    z[4,3,2]  R1754     -1.9854129850864410e-01
    z[4,3,2]  R1755     -8.3444461226463318e-02
    z[4,3,2]  R1756     -2.7143913507461548e-01
    z[4,3,2]  R1757     -2.6291960477828979e-01
    z[4,3,2]  R1758     -0.0666758269071579
    z[4,3,2]  R1759     -1.8733938038349152e-01
    z[4,3,2]  R1760     -0.0946456640958786
    z[4,3,2]  R1761     -1.4219684898853302e-01
    z[4,3,2]  R1762     2.4438938498497009e-01
    z[4,3,2]  R1763     -3.3602195978164673e-01
    z[4,3,2]  R1764     -5.1875356584787369e-03
    z[4,3,2]  R1765     2.1833754144608974e-03
    z[4,3,2]  R1766     -2.4139027297496796e-01
    z[4,3,2]  R1767     -1.5233443677425385e-01
    z[4,3,2]  R1768     -4.3736910820007324e-01
    z[4,3,2]  R1769     -2.3348213732242584e-01
    z[4,3,2]  R1770     -4.5843631029129028e-01
    z[4,3,2]  R1771     1.5957817435264587e-01
    z[4,3,2]  R1772     2.9598847031593323e-01
    z[4,3,2]  R1773     2.7041327953338623e-01
    z[4,3,2]  R1774     -2.4659752845764160e-01
    z[4,3,2]  R1775     -4.6603524684906006e-01
    z[4,3,2]  R1776     -0.0762200802564621
    z[4,3,2]  R1777     2.4485167115926743e-02
    z[4,3,2]  R1778     2.6378279551863670e-02
    z[4,3,2]  R1779     -3.3334141969680786e-01
    z[4,3,2]  R1780     -9.0231351554393768e-02
    z[4,3,2]  R1781     -3.5453933477401733e-01
    z[4,3,2]  R1782     4.3191414326429367e-02
    z[4,3,2]  R1783     -0.341232031583786
    z[4,3,2]  R1784     -4.0100088715553284e-01
    z[4,3,2]  R1785     -7.8620567917823792e-02
    z[4,3,2]  R1786     -1.0464297980070114e-01
    z[4,3,2]  R1787     -2.4717628955841064e-01
    z[4,3,2]  R1788     -3.3976930379867554e-01
    z[4,3,2]  R1789     -1.2700571119785309e-01
    z[4,3,2]  R1790     1.9309714436531067e-01
    z[4,3,2]  R1791     7.5070065259933472e-01
    z[4,3,2]  R1792     -2.0854748785495758e-01
    z[4,3,2]  R1793     2.2803038358688354e-01
    z[4,3,2]  R1794     -1.6927412152290344e-01
    z[4,3,2]  R1795     -3.2806521654129028e-01
    z[4,3,2]  R1796     7.4264849536120892e-03
    z[4,3,2]  R1797     -2.3701396584510803e-01
    z[4,3,2]  R1798     1.0115970671176910e-01
    z[4,3,2]  R1799     0.692564845085144
    z[4,3,2]  R1800     3.3201807737350464e-01
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1684     -1
    z[4,3,3]  R1685     1
    z[4,3,3]  R1692     -6.6944444179534912e-01
    z[4,3,3]  R1693     -2.2743774950504303e-01
    z[4,3,3]  R1694     -6.2280791997909546e-01
    z[4,3,3]  R1695     -2.3109762370586395e-01
    z[4,3,3]  R1696     -0.391855388879776
    z[4,3,3]  R1697     -4.1402736306190491e-01
    z[4,3,3]  R1698     -8.5958838462829590e-02
    z[4,3,3]  R1699     1.1629532277584076e-01
    z[4,3,3]  R1700     -4.0571384131908417e-02
    z[4,3,3]  R1701     2.2374625504016876e-01
    z[4,3,3]  R1702     2.3730051517486572e-01
    z[4,3,3]  R1703     -1.6322648152709007e-02
    z[4,3,3]  R1704     5.9212759137153625e-02
    z[4,3,3]  R1705     -1.0154701769351959e-01
    z[4,3,3]  R1706     -1.0773303359746933e-01
    z[4,3,3]  R1707     2.3034097626805305e-02
    z[4,3,3]  R1708     -4.6928000450134277e-01
    z[4,3,3]  R1709     4.3289911746978760e-01
    z[4,3,3]  R1710     6.4842063188552856e-01
    z[4,3,3]  R1711     5.8338105678558350e-01
    z[4,3,3]  R1712     -1.3787488453090191e-02
    z[4,3,3]  R1713     -2.5685107707977295e-01
    z[4,3,3]  R1714     -1.9629356265068054e-01
    z[4,3,3]  R1715     6.2076830863952637e-01
    z[4,3,3]  R1716     0.618816614151001
    z[4,3,3]  R1717     5.8165395259857178e-01
    z[4,3,3]  R1718     5.9145528078079224e-01
    z[4,3,3]  R1719     5.5927777290344238e-01
    z[4,3,3]  R1720     5.6667649745941162e-01
    z[4,3,3]  R1721     5.4406929016113281e-01
    z[4,3,3]  R1722     6.5865945816040039e-01
    z[4,3,3]  R1723     0.662432074546814
    z[4,3,3]  R1724     6.5003538131713867e-01
    z[4,3,3]  R1725     6.3249212503433228e-01
    z[4,3,3]  R1726     6.2142062187194824e-01
    z[4,3,3]  R1727     6.7430156469345093e-01
    z[4,3,3]  R1728     6.3411563634872437e-01
    z[4,3,3]  R1729     5.6758403778076172e-01
    z[4,3,3]  R1730     5.3503137826919556e-01
    z[4,3,3]  R1731     6.4338076114654541e-01
    z[4,3,3]  R1732     4.9024832248687744e-01
    z[4,3,3]  R1733     5.2322983741760254e-01
    z[4,3,3]  R1734     -2.6184621453285217e-01
    z[4,3,3]  R1735     5.5958682298660278e-01
    z[4,3,3]  R1736     6.1362501233816147e-02
    z[4,3,3]  R1737     -4.5997259020805359e-01
    z[4,3,3]  R1738     -1.9809435307979584e-01
    z[4,3,3]  R1739     -0.0729481503367424
    z[4,3,3]  R1740     -1.1497498303651810e-01
    z[4,3,3]  R1741     2.1794460713863373e-01
    z[4,3,3]  R1742     -1.2271368503570557e-01
    z[4,3,3]  R1743     -1.6657491028308868e-01
    z[4,3,3]  R1744     -1.7226240038871765e-01
    z[4,3,3]  R1745     -2.4263501167297363e-01
    z[4,3,3]  R1746     -2.9438859224319458e-01
    z[4,3,3]  R1747     -1.4323222637176514e-01
    z[4,3,3]  R1748     5.3854927420616150e-02
    z[4,3,3]  R1749     8.3793297410011292e-02
    z[4,3,3]  R1750     5.9439826756715775e-02
    z[4,3,3]  R1751     2.2096496820449829e-01
    z[4,3,3]  R1752     -3.3231475949287415e-01
    z[4,3,3]  R1753     8.5544362664222717e-02
    z[4,3,3]  R1754     5.4995030164718628e-02
    z[4,3,3]  R1755     -2.5623863935470581e-01
    z[4,3,3]  R1756     1.4718367159366608e-01
    z[4,3,3]  R1757     -4.7586208581924438e-01
    z[4,3,3]  R1758     5.7744556665420532e-01
    z[4,3,3]  R1759     -3.7982547283172607e-01
    z[4,3,3]  R1760     -3.8820537924766541e-01
    z[4,3,3]  R1761     -6.8278080224990845e-01
    z[4,3,3]  R1762     5.6001764535903931e-01
    z[4,3,3]  R1763     -8.2615956664085388e-02
    z[4,3,3]  R1764     5.9955221414566040e-01
    z[4,3,3]  R1765     5.5213242769241333e-01
    z[4,3,3]  R1766     6.8202984333038330e-01
    z[4,3,3]  R1767     0.567356526851654
    z[4,3,3]  R1768     -3.3254262804985046e-01
    z[4,3,3]  R1769     -6.4255464076995850e-01
    z[4,3,3]  R1770     -4.6182984113693237e-01
    z[4,3,3]  R1771     -5.4322427511215210e-01
    z[4,3,3]  R1772     3.8676840066909790e-01
    z[4,3,3]  R1773     -1.4344982802867889e-01
    z[4,3,3]  R1774     6.5242147445678711e-01
    z[4,3,3]  R1775     -2.0302671939134598e-02
    z[4,3,3]  R1776     -3.8734534382820129e-01
    z[4,3,3]  R1777     2.6633885502815247e-01
    z[4,3,3]  R1778     9.2679816484451294e-01
    z[4,3,3]  R1779     4.9930948019027710e-01
    z[4,3,3]  R1780     -2.5792637467384338e-01
    z[4,3,3]  R1781     -3.6546853184700012e-01
    z[4,3,3]  R1782     5.7596552371978760e-01
    z[4,3,3]  R1783     5.1674467325210571e-01
    z[4,3,3]  R1784     8.7929308414459229e-02
    z[4,3,3]  R1785     3.7946559488773346e-02
    z[4,3,3]  R1786     -3.0083081126213074e-01
    z[4,3,3]  R1787     -1.4255067706108093e-01
    z[4,3,3]  R1788     -5.8918052911758423e-01
    z[4,3,3]  R1789     -1.2219463288784027e-01
    z[4,3,3]  R1790     2.0624296367168427e-01
    z[4,3,3]  R1791     -3.6771920323371887e-01
    z[4,3,3]  R1792     1.7160816490650177e-01
    z[4,3,3]  R1793     -1.2418014556169510e-01
    z[4,3,3]  R1794     -5.4831933975219727e-01
    z[4,3,3]  R1795     -3.3369067311286926e-01
    z[4,3,3]  R1796     2.8668698668479919e-01
    z[4,3,3]  R1797     -2.9597437381744385e-01
    z[4,3,3]  R1798     -6.3257539272308350e-01
    z[4,3,3]  R1799     -0.566639244556427
    z[4,3,3]  R1800     -6.5333527326583862e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1686     -1
    z[4,3,4]  R1687     1
    z[4,3,4]  R1692     -3.7347182631492615e-01
    z[4,3,4]  R1693     -4.3055397272109985e-01
    z[4,3,4]  R1694     2.2676877677440643e-02
    z[4,3,4]  R1695     -7.1557931602001190e-02
    z[4,3,4]  R1696     -6.9433611631393433e-01
    z[4,3,4]  R1697     -5.7911306619644165e-01
    z[4,3,4]  R1698     -0.0732896476984024
    z[4,3,4]  R1699     -1.2858195602893829e-01
    z[4,3,4]  R1700     -4.0163826942443848e-01
    z[4,3,4]  R1701     -6.4065003395080566e-01
    z[4,3,4]  R1702     2.7452877163887024e-01
    z[4,3,4]  R1703     4.4084548950195312e-01
    z[4,3,4]  R1704     5.1864463090896606e-01
    z[4,3,4]  R1705     2.4805767834186554e-01
    z[4,3,4]  R1706     -4.6411193907260895e-02
    z[4,3,4]  R1707     0.329597145318985
    z[4,3,4]  R1708     -1.4363935589790344e-01
    z[4,3,4]  R1709     7.1478348970413208e-01
    z[4,3,4]  R1710     5.4629105329513550e-01
    z[4,3,4]  R1711     5.3774231672286987e-01
    z[4,3,4]  R1712     -4.0136259794235229e-01
    z[4,3,4]  R1713     2.0788341760635376e-02
    z[4,3,4]  R1714     4.5161384344100952e-01
    z[4,3,4]  R1715     4.1718937456607819e-02
    z[4,3,4]  R1716     -0.203811913728714
    z[4,3,4]  R1717     1.4877521991729736e-01
    z[4,3,4]  R1718     -2.0560060441493988e-01
    z[4,3,4]  R1719     2.3319673538208008e-01
    z[4,3,4]  R1720     1.9234456121921539e-01
    z[4,3,4]  R1721     6.6936874389648438e-01
    z[4,3,4]  R1722     1.0328670591115952e-01
    z[4,3,4]  R1723     5.5827479809522629e-02
    z[4,3,4]  R1724     0.00386149063706398
    z[4,3,4]  R1725     1.9641930237412453e-02
    z[4,3,4]  R1726     -1.2796667218208313e-01
    z[4,3,4]  R1727     5.3986251354217529e-02
    z[4,3,4]  R1728     1.5775239467620850e-01
    z[4,3,4]  R1729     -3.1440962105989456e-02
    z[4,3,4]  R1730     1.8580880761146545e-01
    z[4,3,4]  R1731     6.8503051996231079e-01
    z[4,3,4]  R1732     -2.3091910779476166e-01
    z[4,3,4]  R1733     -1.9820597767829895e-01
    z[4,3,4]  R1734     -0.223605215549469
    z[4,3,4]  R1735     -3.1431868672370911e-01
    z[4,3,4]  R1736     -3.4318295121192932e-01
    z[4,3,4]  R1737     -4.1663515567779541e-01
    z[4,3,4]  R1738     -3.9054206013679504e-01
    z[4,3,4]  R1739     -8.2912124693393707e-02
    z[4,3,4]  R1740     -5.5594122409820557e-01
    z[4,3,4]  R1741     -2.8605180978775024e-01
    z[4,3,4]  R1742     -1.5274184942245483e-01
    z[4,3,4]  R1743     -1.1104546487331390e-01
    z[4,3,4]  R1744     -2.5291544198989868e-01
    z[4,3,4]  R1745     8.7573297321796417e-02
    z[4,3,4]  R1746     0.0885215625166893
    z[4,3,4]  R1747     -1.4982230961322784e-01
    z[4,3,4]  R1748     2.2073255851864815e-02
    z[4,3,4]  R1749     -9.8633743822574615e-02
    z[4,3,4]  R1750     -1.6097214818000793e-01
    z[4,3,4]  R1751     -3.5569289326667786e-01
    z[4,3,4]  R1752     3.1154308468103409e-02
    z[4,3,4]  R1753     -1.8996725976467133e-01
    z[4,3,4]  R1754     7.9639393091201782e-01
    z[4,3,4]  R1755     8.2627013325691223e-03
    z[4,3,4]  R1756     2.2096820175647736e-01
    z[4,3,4]  R1757     3.2409203052520752e-01
    z[4,3,4]  R1758     2.6137617230415344e-01
    z[4,3,4]  R1759     -4.2287570238113403e-01
    z[4,3,4]  R1760     -2.0530524849891663e-01
    z[4,3,4]  R1761     -5.1775805652141571e-02
    z[4,3,4]  R1762     0.721405565738678
    z[4,3,4]  R1763     3.3904662728309631e-01
    z[4,3,4]  R1764     0.536944568157196
    z[4,3,4]  R1765     5.3472465276718140e-01
    z[4,3,4]  R1766     3.1423911452293396e-01
    z[4,3,4]  R1767     3.7826636433601379e-01
    z[4,3,4]  R1768     -1.6794683039188385e-01
    z[4,3,4]  R1769     2.4229032918810844e-02
    z[4,3,4]  R1770     2.3647651076316833e-01
    z[4,3,4]  R1771     5.2013982087373734e-02
    z[4,3,4]  R1772     3.5284776240587234e-02
    z[4,3,4]  R1773     4.6251362562179565e-01
    z[4,3,4]  R1774     3.9560711383819580e-01
    z[4,3,4]  R1775     -1.7187000811100006e-01
    z[4,3,4]  R1776     8.7326399981975555e-02
    z[4,3,4]  R1777     3.7959685921669006e-01
    z[4,3,4]  R1778     2.2575959563255310e-01
    z[4,3,4]  R1779     4.5889419317245483e-01
    z[4,3,4]  R1780     -3.0037787556648254e-01
    z[4,3,4]  R1781     1.6902795433998108e-01
    z[4,3,4]  R1782     4.5079541206359863e-01
    z[4,3,4]  R1783     2.2691859304904938e-01
    z[4,3,4]  R1784     5.3960567712783813e-01
    z[4,3,4]  R1785     1.1950118094682693e-01
    z[4,3,4]  R1786     -0.562481164932251
    z[4,3,4]  R1787     4.0394267439842224e-01
    z[4,3,4]  R1788     -1.9072486320510507e-03
    z[4,3,4]  R1789     0.494154691696167
    z[4,3,4]  R1790     -1.9802886247634888e-01
    z[4,3,4]  R1791     2.0406669378280640e-01
    z[4,3,4]  R1792     3.5650530457496643e-01
    z[4,3,4]  R1793     -3.6467918753623962e-01
    z[4,3,4]  R1794     -8.4266647696495056e-02
    z[4,3,4]  R1795     -4.7175593674182892e-02
    z[4,3,4]  R1796     -1.6847534105181694e-02
    z[4,3,4]  R1797     5.5132389068603516e-01
    z[4,3,4]  R1798     0.340406596660614
    z[4,3,4]  R1799     1.7809723317623138e-01
    z[4,3,4]  R1800     -2.5065923109650612e-02
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1688     -1
    z[4,3,5]  R1689     1
    z[4,3,5]  R1692     3.0502617359161377e-01
    z[4,3,5]  R1693     4.9484741687774658e-01
    z[4,3,5]  R1694     2.5460910797119141e-01
    z[4,3,5]  R1695     3.3628630638122559e-01
    z[4,3,5]  R1696     -1.0812437534332275e-01
    z[4,3,5]  R1697     3.5929408669471741e-01
    z[4,3,5]  R1698     0.0888829231262207
    z[4,3,5]  R1699     6.2359537929296494e-02
    z[4,3,5]  R1700     -8.1958241760730743e-02
    z[4,3,5]  R1701     1.0259815305471420e-01
    z[4,3,5]  R1702     -4.0154001116752625e-01
    z[4,3,5]  R1703     -0.666703999042511
    z[4,3,5]  R1704     1.5759790316224098e-02
    z[4,3,5]  R1705     -1.9583757221698761e-01
    z[4,3,5]  R1706     -5.0340473651885986e-01
    z[4,3,5]  R1707     1.3030278682708740e-01
    z[4,3,5]  R1708     -7.1038591861724854e-01
    z[4,3,5]  R1709     -5.6272368878126144e-02
    z[4,3,5]  R1710     -2.5221112370491028e-01
    z[4,3,5]  R1711     -1.6141898930072784e-01
    z[4,3,5]  R1712     -0.500432014465332
    z[4,3,5]  R1713     -5.0948232412338257e-01
    z[4,3,5]  R1714     -2.1376492083072662e-01
    z[4,3,5]  R1715     -4.3151828646659851e-01
    z[4,3,5]  R1716     -0.416143000125885
    z[4,3,5]  R1717     8.0096609890460968e-02
    z[4,3,5]  R1718     4.8506391048431396e-01
    z[4,3,5]  R1719     1.5715818107128143e-01
    z[4,3,5]  R1720     4.4791880249977112e-01
    z[4,3,5]  R1721     1.6610497608780861e-02
    z[4,3,5]  R1722     8.6551554501056671e-02
    z[4,3,5]  R1723     4.0178185701370239e-01
    z[4,3,5]  R1724     2.5812906026840210e-01
    z[4,3,5]  R1725     7.6234221458435059e-02
    z[4,3,5]  R1726     -5.8103847503662109e-01
    z[4,3,5]  R1727     -5.1187396049499512e-02
    z[4,3,5]  R1728     -9.4732657074928284e-02
    z[4,3,5]  R1729     -9.8502397537231445e-02
    z[4,3,5]  R1730     -2.8530222177505493e-01
    z[4,3,5]  R1731     -9.2689990997314453e-02
    z[4,3,5]  R1732     -2.7438384294509888e-01
    z[4,3,5]  R1733     1.9655370712280273e-01
    z[4,3,5]  R1734     9.9414110183715820e-02
    z[4,3,5]  R1735     1.8051995337009430e-01
    z[4,3,5]  R1736     1.2213288247585297e-01
    z[4,3,5]  R1737     -8.3527758717536926e-02
    z[4,3,5]  R1738     -2.8987939003854990e-03
    z[4,3,5]  R1739     -3.8450825214385986e-01
    z[4,3,5]  R1740     -1.7510086297988892e-01
    z[4,3,5]  R1741     0.253398597240448
    z[4,3,5]  R1742     0.00825007539242506
    z[4,3,5]  R1743     4.9329242110252380e-01
    z[4,3,5]  R1744     4.4502985477447510e-01
    z[4,3,5]  R1745     -1.3583134859800339e-02
    z[4,3,5]  R1746     5.4998189210891724e-02
    z[4,3,5]  R1747     2.7247005701065063e-01
    z[4,3,5]  R1748     1.1730955541133881e-01
    z[4,3,5]  R1749     4.0171834826469421e-01
    z[4,3,5]  R1750     3.2744646072387695e-01
    z[4,3,5]  R1751     0.0937584787607193
    z[4,3,5]  R1752     1.3725067675113678e-01
    z[4,3,5]  R1753     3.8609090447425842e-01
    z[4,3,5]  R1754     -4.2861010879278183e-02
    z[4,3,5]  R1755     -2.5508111715316772e-01
    z[4,3,5]  R1756     -4.9958512187004089e-02
    z[4,3,5]  R1757     0.0769592747092247
    z[4,3,5]  R1758     -1.3457165658473969e-01
    z[4,3,5]  R1759     2.4149735271930695e-01
    z[4,3,5]  R1760     1.6522608697414398e-01
    z[4,3,5]  R1761     4.5957455039024353e-01
    z[4,3,5]  R1762     -1.4389362931251526e-01
    z[4,3,5]  R1763     1.6535639762878418e-01
    z[4,3,5]  R1764     3.1621418893337250e-02
    z[4,3,5]  R1765     -1.0094086080789566e-01
    z[4,3,5]  R1766     0.306438684463501
    z[4,3,5]  R1767     4.3003073334693909e-01
    z[4,3,5]  R1768     5.4396629333496094e-01
    z[4,3,5]  R1769     6.4435862004756927e-02
    z[4,3,5]  R1770     3.2721394300460815e-01
    z[4,3,5]  R1771     -2.8444245457649231e-01
    z[4,3,5]  R1772     -5.0231266021728516e-01
    z[4,3,5]  R1773     -6.2959247827529907e-01
    z[4,3,5]  R1774     3.7279227375984192e-01
    z[4,3,5]  R1775     1.6531041264533997e-01
    z[4,3,5]  R1776     -1.9833190739154816e-01
    z[4,3,5]  R1777     -1.8671898543834686e-01
    z[4,3,5]  R1778     2.3983092606067657e-01
    z[4,3,5]  R1779     9.2646442353725433e-02
    z[4,3,5]  R1780     3.4028777480125427e-01
    z[4,3,5]  R1781     4.1649112105369568e-01
    z[4,3,5]  R1782     8.1165522336959839e-02
    z[4,3,5]  R1783     1.4363476634025574e-01
    z[4,3,5]  R1784     1.0789851844310760e-01
    z[4,3,5]  R1785     -2.3141042888164520e-01
    z[4,3,5]  R1786     -1.7139554023742676e-02
    z[4,3,5]  R1787     -0.318229079246521
    z[4,3,5]  R1788     2.6526167988777161e-01
    z[4,3,5]  R1789     -2.1993994712829590e-01
    z[4,3,5]  R1790     1.5587139129638672e-01
    z[4,3,5]  R1791     3.8067254424095154e-01
    z[4,3,5]  R1792     3.0121762305498123e-02
    z[4,3,5]  R1793     5.5897551774978638e-01
    z[4,3,5]  R1794     2.1398428082466125e-01
    z[4,3,5]  R1795     3.8329538702964783e-01
    z[4,3,5]  R1796     2.9617869853973389e-01
    z[4,3,5]  R1797     0.158024862408638
    z[4,3,5]  R1798     -2.8970161080360413e-01
    z[4,3,5]  R1799     3.5380387306213379e-01
    z[4,3,5]  R1800     3.3629050850868225e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1690     -1
    z[4,3,6]  R1691     1
    z[4,3,6]  R1692     3.4300554543733597e-03
    z[4,3,6]  R1693     -2.9553198255598545e-03
    z[4,3,6]  R1694     5.7289695739746094e-01
    z[4,3,6]  R1695     -3.2113909721374512e-01
    z[4,3,6]  R1696     2.3305638134479523e-01
    z[4,3,6]  R1697     -6.3961118459701538e-02
    z[4,3,6]  R1698     2.2625601291656494e-01
    z[4,3,6]  R1699     -1.0131567716598511e-01
    z[4,3,6]  R1700     6.1252242326736450e-01
    z[4,3,6]  R1701     1.9123022258281708e-01
    z[4,3,6]  R1702     -3.1890419125556946e-01
    z[4,3,6]  R1703     -2.0590442419052124e-01
    z[4,3,6]  R1704     -0.414957195520401
    z[4,3,6]  R1705     -3.7433198094367981e-01
    z[4,3,6]  R1706     -2.0747286081314087e-01
    z[4,3,6]  R1707     -2.7607965469360352e-01
    z[4,3,6]  R1708     1.5594394505023956e-01
    z[4,3,6]  R1709     4.1695764660835266e-01
    z[4,3,6]  R1710     9.8663009703159332e-02
    z[4,3,6]  R1711     3.7763953208923340e-01
    z[4,3,6]  R1712     -8.2898207008838654e-02
    z[4,3,6]  R1713     -2.0093081891536713e-01
    z[4,3,6]  R1714     0.0621473453938961
    z[4,3,6]  R1715     1.5214161947369576e-02
    z[4,3,6]  R1716     -4.7630748152732849e-01
    z[4,3,6]  R1717     5.1341992616653442e-01
    z[4,3,6]  R1718     -3.5862424969673157e-01
    z[4,3,6]  R1719     0.41744464635849
    z[4,3,6]  R1720     9.5681458711624146e-02
    z[4,3,6]  R1721     3.6838880181312561e-01
    z[4,3,6]  R1722     4.6484112739562988e-01
    z[4,3,6]  R1723     3.9420583844184875e-01
    z[4,3,6]  R1724     3.4531581401824951e-01
    z[4,3,6]  R1725     -3.6222934722900391e-01
    z[4,3,6]  R1726     -1.2603670358657837e-01
    z[4,3,6]  R1727     -3.8603344559669495e-01
    z[4,3,6]  R1728     3.1251555681228638e-01
    z[4,3,6]  R1729     -3.8927948474884033e-01
    z[4,3,6]  R1730     2.9809162020683289e-01
    z[4,3,6]  R1731     -4.5947216451168060e-02
    z[4,3,6]  R1732     -9.0920627117156982e-02
    z[4,3,6]  R1733     -1.1257733404636383e-01
    z[4,3,6]  R1734     -1.5459421277046204e-01
    z[4,3,6]  R1735     -3.3619552850723267e-01
    z[4,3,6]  R1736     -7.4777096509933472e-02
    z[4,3,6]  R1737     2.9738730192184448e-01
    z[4,3,6]  R1738     4.5432859659194946e-01
    z[4,3,6]  R1739     3.5045480728149414e-01
    z[4,3,6]  R1740     -0.0526314415037632
    z[4,3,6]  R1741     2.6307487487792969e-01
    z[4,3,6]  R1742     6.2678828835487366e-02
    z[4,3,6]  R1743     -3.8197159767150879e-02
    z[4,3,6]  R1744     9.3276090919971466e-02
    z[4,3,6]  R1745     -2.4080686271190643e-02
    z[4,3,6]  R1746     -1.4493295550346375e-01
    z[4,3,6]  R1747     3.5655535757541656e-02
    z[4,3,6]  R1748     0.0522799976170063
    z[4,3,6]  R1749     3.2310735434293747e-02
    z[4,3,6]  R1750     8.5448555648326874e-02
    z[4,3,6]  R1751     1.2455178052186966e-01
    z[4,3,6]  R1752     1.9001878798007965e-01
    z[4,3,6]  R1753     -5.6835031509399414e-01
    z[4,3,6]  R1754     -3.0935180187225342e-01
    z[4,3,6]  R1755     5.9268784523010254e-01
    z[4,3,6]  R1756     8.0272859334945679e-01
    z[4,3,6]  R1757     -4.1821199655532837e-01
    z[4,3,6]  R1758     5.3628188371658325e-01
    z[4,3,6]  R1759     7.5863644480705261e-02
    z[4,3,6]  R1760     3.7423965334892273e-01
    z[4,3,6]  R1761     7.4497717432677746e-03
    z[4,3,6]  R1762     1.6224814951419830e-01
    z[4,3,6]  R1763     -3.0374118685722351e-01
    z[4,3,6]  R1764     -3.4164834022521973e-01
    z[4,3,6]  R1765     6.2955850362777710e-01
    z[4,3,6]  R1766     3.8678586483001709e-01
    z[4,3,6]  R1767     -1.4108885824680328e-01
    z[4,3,6]  R1768     -2.0895342528820038e-01
    z[4,3,6]  R1769     -1.1328030377626419e-01
    z[4,3,6]  R1770     -0.0601862333714962
    z[4,3,6]  R1771     -2.4160975217819214e-01
    z[4,3,6]  R1772     3.6350575089454651e-01
    z[4,3,6]  R1773     1.0825856775045395e-01
    z[4,3,6]  R1774     -5.4732393473386765e-02
    z[4,3,6]  R1775     3.5946875810623169e-01
    z[4,3,6]  R1776     -2.4727845191955566e-01
    z[4,3,6]  R1777     6.0292577743530273e-01
    z[4,3,6]  R1778     -1.4043906331062317e-01
    z[4,3,6]  R1779     3.4061953425407410e-01
    z[4,3,6]  R1780     -0.281399667263031
    z[4,3,6]  R1781     -5.6827016174793243e-02
    z[4,3,6]  R1782     -3.1062424182891846e-01
    z[4,3,6]  R1783     6.1044901609420776e-01
    z[4,3,6]  R1784     1.9057519733905792e-01
    z[4,3,6]  R1785     6.6493093967437744e-01
    z[4,3,6]  R1786     7.8965082764625549e-02
    z[4,3,6]  R1787     7.5730517506599426e-02
    z[4,3,6]  R1788     1.0132216662168503e-01
    z[4,3,6]  R1789     2.6948660612106323e-01
    z[4,3,6]  R1790     -4.2699408531188965e-01
    z[4,3,6]  R1791     1.2564989924430847e-01
    z[4,3,6]  R1792     1.0915504395961761e-01
    z[4,3,6]  R1793     4.7250889241695404e-02
    z[4,3,6]  R1794     -1.4756020903587341e-01
    z[4,3,6]  R1795     -0.0288847703486681
    z[4,3,6]  R1796     -1.6712214052677155e-01
    z[4,3,6]  R1797     -1.6119672358036041e-01
    z[4,3,6]  R1798     1.5063390135765076e-01
    z[4,3,6]  R1799     1.5044826269149780e-01
    z[4,3,6]  R1800     2.8009437024593353e-02
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1801     -1
    z[3,6,0]  R1802     1
    z[3,6,0]  R1815     3.7067100405693054e-02
    z[3,6,0]  R1816     3.7179496884346008e-01
    z[3,6,0]  R1817     -4.1181966662406921e-01
    z[3,6,0]  R1818     5.1207607984542847e-01
    z[3,6,0]  R1819     -6.3994753360748291e-01
    z[3,6,0]  R1820     -0.316124826669693
    z[3,6,0]  R1821     -4.0294739603996277e-01
    z[3,6,0]  R1822     5.3729891777038574e-01
    z[3,6,0]  R1823     -4.6869885921478271e-01
    z[3,6,0]  R1824     -4.5559534430503845e-01
    z[3,6,0]  R1825     7.8173793852329254e-02
    z[3,6,0]  R1826     -1.7945900559425354e-01
    z[3,6,0]  R1827     -1.2135547585785389e-03
    z[3,6,0]  R1828     -0.0807340145111084
    z[3,6,0]  R1829     -2.4226111173629761e-01
    z[3,6,0]  R1830     -2.3268264532089233e-01
    z[3,6,0]  R1831     -5.3354259580373764e-02
    z[3,6,0]  R1832     -3.0456345528364182e-02
    z[3,6,0]  R1833     -2.2064997255802155e-01
    z[3,6,0]  R1834     -4.6148531138896942e-02
    z[3,6,0]  R1835     6.5666645765304565e-02
    z[3,6,0]  R1836     -1.9799323379993439e-01
    z[3,6,0]  R1837     3.2701876759529114e-01
    z[3,6,0]  R1838     -1.4233329892158508e-01
    z[3,6,0]  R1839     1.9304735586047173e-02
    z[3,6,0]  R1840     -1.5847027301788330e-01
    z[3,6,0]  R1841     5.3673553466796875e-01
    z[3,6,0]  R1842     3.6323402076959610e-02
    z[3,6,0]  R1843     -3.4531587362289429e-01
    z[3,6,0]  R1844     -1.6749443113803864e-01
    z[3,6,0]  R1845     -2.3113049566745758e-01
    z[3,6,0]  R1846     -4.3012022972106934e-02
    z[3,6,0]  R1847     4.8231253027915955e-01
    z[3,6,0]  R1848     2.5550296530127525e-02
    z[3,6,0]  R1849     -2.0028276741504669e-01
    z[3,6,0]  R1850     -4.8691046237945557e-01
    z[3,6,0]  R1851     -1.2682755291461945e-01
    z[3,6,0]  R1852     2.6874890923500061e-01
    z[3,6,0]  R1853     1.3006573915481567e-01
    z[3,6,0]  R1854     3.6033737659454346e-01
    z[3,6,0]  R1855     5.9692794084548950e-01
    z[3,6,0]  R1856     3.9397379755973816e-01
    z[3,6,0]  R1857     -1.7629776895046234e-01
    z[3,6,0]  R1858     1.2649475038051605e-01
    z[3,6,0]  R1859     5.8065932244062424e-02
    z[3,6,0]  R1860     -2.4579444527626038e-01
    z[3,6,0]  R1861     6.5198093652725220e-02
    z[3,6,0]  R1862     5.4943734407424927e-01
    z[3,6,0]  R1863     -1.5163809061050415e-01
    z[3,6,0]  R1864     -2.2004279494285583e-01
    z[3,6,0]  R1865     -1.1727644503116608e-01
    z[3,6,0]  R1866     1.9039590656757355e-01
    z[3,6,0]  R1867     2.9173459857702255e-02
    z[3,6,0]  R1868     -5.5233038961887360e-02
    z[3,6,0]  R1869     -1.4811183512210846e-01
    z[3,6,0]  R1870     9.3578584492206573e-02
    z[3,6,0]  R1871     -9.8985306918621063e-02
    z[3,6,0]  R1872     -1.3010847568511963e-01
    z[3,6,0]  R1873     1.1820724606513977e-01
    z[3,6,0]  R1874     -2.2255496680736542e-01
    z[3,6,0]  R1875     -1.2191570550203323e-01
    z[3,6,0]  R1876     -3.0332719907164574e-02
    z[3,6,0]  R1877     -8.1705629825592041e-02
    z[3,6,0]  R1878     -3.3933378756046295e-02
    z[3,6,0]  R1879     4.9755383282899857e-02
    z[3,6,0]  R1880     1.3494296371936798e-01
    z[3,6,0]  R1881     0.0110483942553401
    z[3,6,0]  R1882     1.4044113457202911e-01
    z[3,6,0]  R1883     0.590168297290802
    z[3,6,0]  R1884     -2.1240970492362976e-01
    z[3,6,0]  R1885     5.6615126132965088e-01
    z[3,6,0]  R1886     -0.287582129240036
    z[3,6,0]  R1887     3.9139175415039062e-01
    z[3,6,0]  R1888     8.9847363531589508e-02
    z[3,6,0]  R1889     -1.3517257571220398e-01
    z[3,6,0]  R1890     6.2380012124776840e-02
    z[3,6,0]  R1891     -3.1546853482723236e-02
    z[3,6,0]  R1892     -3.2627135515213013e-01
    z[3,6,0]  R1893     3.7415587902069092e-01
    z[3,6,0]  R1894     -2.1480867266654968e-01
    z[3,6,0]  R1895     -2.4702057242393494e-01
    z[3,6,0]  R1896     0.0647042840719223
    z[3,6,0]  R1897     -0.0897059440612793
    z[3,6,0]  R1898     7.5556194782257080e-01
    z[3,6,0]  R1899     -6.9648653268814087e-01
    z[3,6,0]  R1900     4.2574423551559448e-01
    z[3,6,0]  R1901     -8.8941919803619385e-01
    z[3,6,0]  R1902     6.2374550104141235e-01
    z[3,6,0]  R1903     -5.0331413745880127e-01
    z[3,6,0]  R1904     2.9560112953186035e-01
    z[3,6,0]  R1905     -1.8875746428966522e-01
    z[3,6,0]  R1906     -3.9666953682899475e-01
    z[3,6,0]  R1907     -1.5260013937950134e-01
    z[3,6,0]  R1908     4.4463074207305908e-01
    z[3,6,0]  R1909     1.3967847824096680e-01
    z[3,6,0]  R1910     -5.1141440868377686e-01
    z[3,6,0]  R1911     -3.6340034008026123e-01
    z[3,6,0]  R1912     2.8061848878860474e-01
    z[3,6,0]  R1913     1.1992813646793365e-01
    z[3,6,0]  R1914     -1.1969466507434845e-01
    z[3,6,0]  R1915     0.891903281211853
    z[3,6,0]  R1916     -0.0440092533826828
    z[3,6,0]  R1917     6.9294106960296631e-01
    z[3,6,0]  R1918     6.0244774818420410e-01
    z[3,6,0]  R1919     -8.1641167402267456e-02
    z[3,6,0]  R1920     5.6040030717849731e-01
    z[3,6,0]  R1921     4.0766561031341553e-01
    z[3,6,0]  R1922     3.1279277754947543e-04
    z[3,6,0]  R1923     4.6923488378524780e-01
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1803     -1
    z[3,6,1]  R1804     1
    z[3,6,1]  R1815     6.9367986917495728e-01
    z[3,6,1]  R1816     6.6264796257019043e-01
    z[3,6,1]  R1817     -4.9712666869163513e-01
    z[3,6,1]  R1818     4.0542349219322205e-01
    z[3,6,1]  R1819     -0.443347305059433
    z[3,6,1]  R1820     -5.1285165548324585e-01
    z[3,6,1]  R1821     -0.450613796710968
    z[3,6,1]  R1822     6.5254640579223633e-01
    z[3,6,1]  R1823     -6.2381881475448608e-01
    z[3,6,1]  R1824     7.0405995845794678e-01
    z[3,6,1]  R1825     -9.6634417772293091e-01
    z[3,6,1]  R1826     -8.2638806104660034e-01
    z[3,6,1]  R1827     -8.3274024724960327e-01
    z[3,6,1]  R1828     -9.4393610954284668e-01
    z[3,6,1]  R1829     -8.9501363039016724e-01
    z[3,6,1]  R1830     -8.5856539011001587e-01
    z[3,6,1]  R1831     -9.3438696861267090e-01
    z[3,6,1]  R1832     -8.9354443550109863e-01
    z[3,6,1]  R1833     -8.9741677045822144e-01
    z[3,6,1]  R1834     -8.6780643463134766e-01
    z[3,6,1]  R1835     9.0192121267318726e-01
    z[3,6,1]  R1836     0.6239013671875
    z[3,6,1]  R1837     3.4472694993019104e-01
    z[3,6,1]  R1838     0.70050448179245
    z[3,6,1]  R1839     4.5671561360359192e-01
    z[3,6,1]  R1840     0.627260684967041
    z[3,6,1]  R1841     7.8109733294695616e-04
    z[3,6,1]  R1842     -7.5922125577926636e-01
    z[3,6,1]  R1843     -0.715255618095398
    z[3,6,1]  R1844     -5.2114403247833252e-01
    z[3,6,1]  R1845     7.6005853712558746e-02
    z[3,6,1]  R1846     0.802408754825592
    z[3,6,1]  R1847     -0.0430334135890007
    z[3,6,1]  R1848     4.5041911303997040e-02
    z[3,6,1]  R1849     3.0691778659820557e-01
    z[3,6,1]  R1850     2.6438814401626587e-01
    z[3,6,1]  R1851     -5.6059908866882324e-01
    z[3,6,1]  R1852     -6.6544133424758911e-01
    z[3,6,1]  R1853     -6.2691295146942139e-01
    z[3,6,1]  R1854     -6.3844412565231323e-01
    z[3,6,1]  R1855     1.4414748549461365e-01
    z[3,6,1]  R1856     3.5924646258354187e-01
    z[3,6,1]  R1857     4.2892915010452271e-01
    z[3,6,1]  R1858     7.6178300380706787e-01
    z[3,6,1]  R1859     8.5596400499343872e-01
    z[3,6,1]  R1860     5.7058918476104736e-01
    z[3,6,1]  R1861     0.0888204276561737
    z[3,6,1]  R1862     0.0500313900411129
    z[3,6,1]  R1863     -7.8557604551315308e-01
    z[3,6,1]  R1864     -6.9789052009582520e-01
    z[3,6,1]  R1865     5.8851748704910278e-01
    z[3,6,1]  R1866     3.6812219023704529e-01
    z[3,6,1]  R1867     7.0105659961700439e-01
    z[3,6,1]  R1868     6.9236093759536743e-01
    z[3,6,1]  R1869     7.4410974979400635e-01
    z[3,6,1]  R1870     -7.9978233575820923e-01
    z[3,6,1]  R1871     -6.6857415437698364e-01
    z[3,6,1]  R1872     -7.6604461669921875e-01
    z[3,6,1]  R1873     -8.1263101100921631e-01
    z[3,6,1]  R1874     2.2216621041297913e-01
    z[3,6,1]  R1875     8.7879288196563721e-01
    z[3,6,1]  R1876     6.9568967819213867e-01
    z[3,6,1]  R1877     -7.6769274473190308e-01
    z[3,6,1]  R1878     -0.793660581111908
    z[3,6,1]  R1879     -8.9406061172485352e-01
    z[3,6,1]  R1880     -0.69505375623703
    z[3,6,1]  R1881     -6.0580420494079590e-01
    z[3,6,1]  R1882     -4.4465139508247375e-03
    z[3,6,1]  R1883     1.0688560083508492e-02
    z[3,6,1]  R1884     -4.4346127659082413e-02
    z[3,6,1]  R1885     -9.0379834175109863e-02
    z[3,6,1]  R1886     -1.5228827297687531e-01
    z[3,6,1]  R1887     -1.0052482783794403e-01
    z[3,6,1]  R1888     -3.9079539477825165e-02
    z[3,6,1]  R1889     -1.6333429515361786e-01
    z[3,6,1]  R1890     -5.1454100757837296e-02
    z[3,6,1]  R1891     -5.8109525591135025e-02
    z[3,6,1]  R1892     9.2844374477863312e-02
    z[3,6,1]  R1893     -8.1013187766075134e-02
    z[3,6,1]  R1894     8.1758999824523926e-01
    z[3,6,1]  R1895     -2.7423635125160217e-01
    z[3,6,1]  R1896     9.2157393693923950e-01
    z[3,6,1]  R1897     9.1725713014602661e-01
    z[3,6,1]  R1898     -3.1591439247131348e-01
    z[3,6,1]  R1899     -4.2140522599220276e-01
    z[3,6,1]  R1900     -2.1396489441394806e-01
    z[3,6,1]  R1901     -0.283568799495697
    z[3,6,1]  R1902     3.6306354403495789e-01
    z[3,6,1]  R1903     -5.2217030525207520e-01
    z[3,6,1]  R1904     -7.4705088138580322e-01
    z[3,6,1]  R1905     -6.0879707336425781e-01
    z[3,6,1]  R1906     -6.1021369695663452e-01
    z[3,6,1]  R1907     -5.2069664001464844e-01
    z[3,6,1]  R1908     -5.0037395954132080e-01
    z[3,6,1]  R1909     -5.1626527309417725e-01
    z[3,6,1]  R1910     -4.8499128222465515e-01
    z[3,6,1]  R1911     -4.2986959218978882e-01
    z[3,6,1]  R1912     -4.6784445643424988e-01
    z[3,6,1]  R1913     -5.2109575271606445e-01
    z[3,6,1]  R1914     -6.4972156286239624e-01
    z[3,6,1]  R1915     1.3706804811954498e-01
    z[3,6,1]  R1916     -5.5932825803756714e-01
    z[3,6,1]  R1917     4.6786937862634659e-02
    z[3,6,1]  R1918     -2.8206637501716614e-01
    z[3,6,1]  R1919     -0.646415650844574
    z[3,6,1]  R1920     4.0782818198204041e-01
    z[3,6,1]  R1921     1.4009904861450195e-01
    z[3,6,1]  R1922     -2.5747969746589661e-01
    z[3,6,1]  R1923     2.2282439470291138e-01
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1805     -1
    z[3,6,2]  R1806     1
    z[3,6,2]  R1815     3.7445166707038879e-01
    z[3,6,2]  R1816     -2.4146245419979095e-01
    z[3,6,2]  R1817     -6.5644830465316772e-01
    z[3,6,2]  R1818     -1.2594206631183624e-01
    z[3,6,2]  R1819     -5.0185889005661011e-01
    z[3,6,2]  R1820     -3.9556607604026794e-01
    z[3,6,2]  R1821     -4.8620283603668213e-01
    z[3,6,2]  R1822     -5.1303360611200333e-02
    z[3,6,2]  R1823     -1.8828479945659637e-01
    z[3,6,2]  R1824     -1.8435798585414886e-01
    z[3,6,2]  R1825     1.3297490775585175e-01
    z[3,6,2]  R1826     -1.6308559570461512e-03
    z[3,6,2]  R1827     -7.8419208526611328e-02
    z[3,6,2]  R1828     1.8751381337642670e-01
    z[3,6,2]  R1829     1.4740787446498871e-01
    z[3,6,2]  R1830     3.0041760206222534e-01
    z[3,6,2]  R1831     3.2278785109519958e-01
    z[3,6,2]  R1832     1.4655736088752747e-01
    z[3,6,2]  R1833     -4.4597167521715164e-02
    z[3,6,2]  R1834     2.1245136857032776e-01
    z[3,6,2]  R1835     -1.2600612640380859e-01
    z[3,6,2]  R1836     -2.3675315082073212e-01
    z[3,6,2]  R1837     -1.9854129850864410e-01
    z[3,6,2]  R1838     -8.3444461226463318e-02
    z[3,6,2]  R1839     -2.7143913507461548e-01
    z[3,6,2]  R1840     -2.6291960477828979e-01
    z[3,6,2]  R1841     -0.0666758269071579
    z[3,6,2]  R1842     -1.8733938038349152e-01
    z[3,6,2]  R1843     -0.0946456640958786
    z[3,6,2]  R1844     -1.4219684898853302e-01
    z[3,6,2]  R1845     2.4438938498497009e-01
    z[3,6,2]  R1846     -3.3602195978164673e-01
    z[3,6,2]  R1847     -5.1875356584787369e-03
    z[3,6,2]  R1848     2.1833754144608974e-03
    z[3,6,2]  R1849     -2.4139027297496796e-01
    z[3,6,2]  R1850     -1.5233443677425385e-01
    z[3,6,2]  R1851     -4.3736910820007324e-01
    z[3,6,2]  R1852     -2.3348213732242584e-01
    z[3,6,2]  R1853     -4.5843631029129028e-01
    z[3,6,2]  R1854     1.5957817435264587e-01
    z[3,6,2]  R1855     2.9598847031593323e-01
    z[3,6,2]  R1856     2.7041327953338623e-01
    z[3,6,2]  R1857     -2.4659752845764160e-01
    z[3,6,2]  R1858     -4.6603524684906006e-01
    z[3,6,2]  R1859     -0.0762200802564621
    z[3,6,2]  R1860     2.4485167115926743e-02
    z[3,6,2]  R1861     2.6378279551863670e-02
    z[3,6,2]  R1862     -3.3334141969680786e-01
    z[3,6,2]  R1863     -9.0231351554393768e-02
    z[3,6,2]  R1864     -3.5453933477401733e-01
    z[3,6,2]  R1865     4.3191414326429367e-02
    z[3,6,2]  R1866     -0.341232031583786
    z[3,6,2]  R1867     -4.0100088715553284e-01
    z[3,6,2]  R1868     -7.8620567917823792e-02
    z[3,6,2]  R1869     -1.0464297980070114e-01
    z[3,6,2]  R1870     -2.4717628955841064e-01
    z[3,6,2]  R1871     -3.3976930379867554e-01
    z[3,6,2]  R1872     -1.2700571119785309e-01
    z[3,6,2]  R1873     1.9309714436531067e-01
    z[3,6,2]  R1874     7.5070065259933472e-01
    z[3,6,2]  R1875     -2.0854748785495758e-01
    z[3,6,2]  R1876     2.2803038358688354e-01
    z[3,6,2]  R1877     -1.6927412152290344e-01
    z[3,6,2]  R1878     -3.2806521654129028e-01
    z[3,6,2]  R1879     7.4264849536120892e-03
    z[3,6,2]  R1880     -2.3701396584510803e-01
    z[3,6,2]  R1881     1.0115970671176910e-01
    z[3,6,2]  R1882     0.692564845085144
    z[3,6,2]  R1883     3.3201807737350464e-01
    z[3,6,2]  R1884     -6.2255424261093140e-01
    z[3,6,2]  R1885     -7.4332630634307861e-01
    z[3,6,2]  R1886     -8.0464816093444824e-01
    z[3,6,2]  R1887     -6.0049152374267578e-01
    z[3,6,2]  R1888     -1.8468938767910004e-01
    z[3,6,2]  R1889     -7.3881131410598755e-01
    z[3,6,2]  R1890     -6.4745169878005981e-01
    z[3,6,2]  R1891     -8.3255708217620850e-01
    z[3,6,2]  R1892     -8.3497482538223267e-01
    z[3,6,2]  R1893     -3.6337402462959290e-01
    z[3,6,2]  R1894     3.0558711290359497e-01
    z[3,6,2]  R1895     5.8320814371109009e-01
    z[3,6,2]  R1896     2.4961875379085541e-01
    z[3,6,2]  R1897     2.9769837856292725e-01
    z[3,6,2]  R1898     2.1694932878017426e-01
    z[3,6,2]  R1899     2.8463923931121826e-01
    z[3,6,2]  R1900     2.0543260872364044e-01
    z[3,6,2]  R1901     2.0874388515949249e-01
    z[3,6,2]  R1902     0.381873220205307
    z[3,6,2]  R1903     3.4576156735420227e-01
    z[3,6,2]  R1904     1.0945479571819305e-01
    z[3,6,2]  R1905     -3.2285865396261215e-02
    z[3,6,2]  R1906     -5.2841058932244778e-03
    z[3,6,2]  R1907     2.2360880672931671e-01
    z[3,6,2]  R1908     3.1841287016868591e-01
    z[3,6,2]  R1909     -3.3113136887550354e-01
    z[3,6,2]  R1910     1.0439525544643402e-01
    z[3,6,2]  R1911     2.3203656077384949e-01
    z[3,6,2]  R1912     -1.0930939763784409e-01
    z[3,6,2]  R1913     2.4682506918907166e-01
    z[3,6,2]  R1914     -6.2499684095382690e-01
    z[3,6,2]  R1915     -2.2313027083873749e-01
    z[3,6,2]  R1916     -9.5440290868282318e-02
    z[3,6,2]  R1917     -6.9622255861759186e-02
    z[3,6,2]  R1918     -1.8771840631961823e-01
    z[3,6,2]  R1919     -2.8977859020233154e-01
    z[3,6,2]  R1920     0.0358751118183136
    z[3,6,2]  R1921     -1.8994650244712830e-01
    z[3,6,2]  R1922     -4.9565258622169495e-01
    z[3,6,2]  R1923     1.5451537072658539e-01
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1807     -1
    z[3,6,3]  R1808     1
    z[3,6,3]  R1815     4.9024832248687744e-01
    z[3,6,3]  R1816     5.2322983741760254e-01
    z[3,6,3]  R1817     -2.6184621453285217e-01
    z[3,6,3]  R1818     5.5958682298660278e-01
    z[3,6,3]  R1819     6.1362501233816147e-02
    z[3,6,3]  R1820     -4.5997259020805359e-01
    z[3,6,3]  R1821     -1.9809435307979584e-01
    z[3,6,3]  R1822     -0.0729481503367424
    z[3,6,3]  R1823     -1.1497498303651810e-01
    z[3,6,3]  R1824     2.1794460713863373e-01
    z[3,6,3]  R1825     -1.2271368503570557e-01
    z[3,6,3]  R1826     -1.6657491028308868e-01
    z[3,6,3]  R1827     -1.7226240038871765e-01
    z[3,6,3]  R1828     -2.4263501167297363e-01
    z[3,6,3]  R1829     -2.9438859224319458e-01
    z[3,6,3]  R1830     -1.4323222637176514e-01
    z[3,6,3]  R1831     5.3854927420616150e-02
    z[3,6,3]  R1832     8.3793297410011292e-02
    z[3,6,3]  R1833     5.9439826756715775e-02
    z[3,6,3]  R1834     2.2096496820449829e-01
    z[3,6,3]  R1835     -3.3231475949287415e-01
    z[3,6,3]  R1836     8.5544362664222717e-02
    z[3,6,3]  R1837     5.4995030164718628e-02
    z[3,6,3]  R1838     -2.5623863935470581e-01
    z[3,6,3]  R1839     1.4718367159366608e-01
    z[3,6,3]  R1840     -4.7586208581924438e-01
    z[3,6,3]  R1841     5.7744556665420532e-01
    z[3,6,3]  R1842     -3.7982547283172607e-01
    z[3,6,3]  R1843     -3.8820537924766541e-01
    z[3,6,3]  R1844     -6.8278080224990845e-01
    z[3,6,3]  R1845     5.6001764535903931e-01
    z[3,6,3]  R1846     -8.2615956664085388e-02
    z[3,6,3]  R1847     5.9955221414566040e-01
    z[3,6,3]  R1848     5.5213242769241333e-01
    z[3,6,3]  R1849     6.8202984333038330e-01
    z[3,6,3]  R1850     0.567356526851654
    z[3,6,3]  R1851     -3.3254262804985046e-01
    z[3,6,3]  R1852     -6.4255464076995850e-01
    z[3,6,3]  R1853     -4.6182984113693237e-01
    z[3,6,3]  R1854     -5.4322427511215210e-01
    z[3,6,3]  R1855     3.8676840066909790e-01
    z[3,6,3]  R1856     -1.4344982802867889e-01
    z[3,6,3]  R1857     6.5242147445678711e-01
    z[3,6,3]  R1858     -2.0302671939134598e-02
    z[3,6,3]  R1859     -3.8734534382820129e-01
    z[3,6,3]  R1860     2.6633885502815247e-01
    z[3,6,3]  R1861     9.2679816484451294e-01
    z[3,6,3]  R1862     4.9930948019027710e-01
    z[3,6,3]  R1863     -2.5792637467384338e-01
    z[3,6,3]  R1864     -3.6546853184700012e-01
    z[3,6,3]  R1865     5.7596552371978760e-01
    z[3,6,3]  R1866     5.1674467325210571e-01
    z[3,6,3]  R1867     8.7929308414459229e-02
    z[3,6,3]  R1868     3.7946559488773346e-02
    z[3,6,3]  R1869     -3.0083081126213074e-01
    z[3,6,3]  R1870     -1.4255067706108093e-01
    z[3,6,3]  R1871     -5.8918052911758423e-01
    z[3,6,3]  R1872     -1.2219463288784027e-01
    z[3,6,3]  R1873     2.0624296367168427e-01
    z[3,6,3]  R1874     -3.6771920323371887e-01
    z[3,6,3]  R1875     1.7160816490650177e-01
    z[3,6,3]  R1876     -1.2418014556169510e-01
    z[3,6,3]  R1877     -5.4831933975219727e-01
    z[3,6,3]  R1878     -3.3369067311286926e-01
    z[3,6,3]  R1879     2.8668698668479919e-01
    z[3,6,3]  R1880     -2.9597437381744385e-01
    z[3,6,3]  R1881     -6.3257539272308350e-01
    z[3,6,3]  R1882     -0.566639244556427
    z[3,6,3]  R1883     -6.5333527326583862e-01
    z[3,6,3]  R1884     -1.8421080708503723e-01
    z[3,6,3]  R1885     -2.9413759708404541e-02
    z[3,6,3]  R1886     1.6060025990009308e-01
    z[3,6,3]  R1887     1.5337137877941132e-01
    z[3,6,3]  R1888     3.9470937848091125e-01
    z[3,6,3]  R1889     1.2312074750661850e-01
    z[3,6,3]  R1890     -0.366982102394104
    z[3,6,3]  R1891     1.2864798307418823e-01
    z[3,6,3]  R1892     -8.5663378238677979e-02
    z[3,6,3]  R1893     -3.0126622319221497e-01
    z[3,6,3]  R1894     3.9039561152458191e-01
    z[3,6,3]  R1895     -4.7683459520339966e-01
    z[3,6,3]  R1896     -1.6152353584766388e-01
    z[3,6,3]  R1897     -2.0118415355682373e-01
    z[3,6,3]  R1898     3.3191543817520142e-01
    z[3,6,3]  R1899     4.8919060826301575e-01
    z[3,6,3]  R1900     -6.1220663785934448e-01
    z[3,6,3]  R1901     1.7509926855564117e-01
    z[3,6,3]  R1902     -4.7625014185905457e-01
    z[3,6,3]  R1903     4.8647928237915039e-01
    z[3,6,3]  R1904     -2.3330879211425781e-01
    z[3,6,3]  R1905     -6.9764018058776855e-02
    z[3,6,3]  R1906     2.6782515645027161e-01
    z[3,6,3]  R1907     -0.405845582485199
    z[3,6,3]  R1908     6.4888454973697662e-02
    z[3,6,3]  R1909     -3.8919255137443542e-01
    z[3,6,3]  R1910     1.6290649771690369e-01
    z[3,6,3]  R1911     -3.8584843277931213e-01
    z[3,6,3]  R1912     8.2914769649505615e-02
    z[3,6,3]  R1913     3.1777891516685486e-01
    z[3,6,3]  R1914     -2.1474552154541016e-01
    z[3,6,3]  R1915     1.8357586860656738e-01
    z[3,6,3]  R1916     6.8477582931518555e-01
    z[3,6,3]  R1917     1.3806837797164917e-01
    z[3,6,3]  R1918     -6.0245178639888763e-02
    z[3,6,3]  R1919     2.5885561108589172e-01
    z[3,6,3]  R1920     -4.7876462340354919e-01
    z[3,6,3]  R1921     -0.363491028547287
    z[3,6,3]  R1922     5.1065343618392944e-01
    z[3,6,3]  R1923     -3.0907431617379189e-02
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1809     -1
    z[3,6,4]  R1810     1
    z[3,6,4]  R1815     -2.3091910779476166e-01
    z[3,6,4]  R1816     -1.9820597767829895e-01
    z[3,6,4]  R1817     -0.223605215549469
    z[3,6,4]  R1818     -3.1431868672370911e-01
    z[3,6,4]  R1819     -3.4318295121192932e-01
    z[3,6,4]  R1820     -4.1663515567779541e-01
    z[3,6,4]  R1821     -3.9054206013679504e-01
    z[3,6,4]  R1822     -8.2912124693393707e-02
    z[3,6,4]  R1823     -5.5594122409820557e-01
    z[3,6,4]  R1824     -2.8605180978775024e-01
    z[3,6,4]  R1825     -1.5274184942245483e-01
    z[3,6,4]  R1826     -1.1104546487331390e-01
    z[3,6,4]  R1827     -2.5291544198989868e-01
    z[3,6,4]  R1828     8.7573297321796417e-02
    z[3,6,4]  R1829     0.0885215625166893
    z[3,6,4]  R1830     -1.4982230961322784e-01
    z[3,6,4]  R1831     2.2073255851864815e-02
    z[3,6,4]  R1832     -9.8633743822574615e-02
    z[3,6,4]  R1833     -1.6097214818000793e-01
    z[3,6,4]  R1834     -3.5569289326667786e-01
    z[3,6,4]  R1835     3.1154308468103409e-02
    z[3,6,4]  R1836     -1.8996725976467133e-01
    z[3,6,4]  R1837     7.9639393091201782e-01
    z[3,6,4]  R1838     8.2627013325691223e-03
    z[3,6,4]  R1839     2.2096820175647736e-01
    z[3,6,4]  R1840     3.2409203052520752e-01
    z[3,6,4]  R1841     2.6137617230415344e-01
    z[3,6,4]  R1842     -4.2287570238113403e-01
    z[3,6,4]  R1843     -2.0530524849891663e-01
    z[3,6,4]  R1844     -5.1775805652141571e-02
    z[3,6,4]  R1845     0.721405565738678
    z[3,6,4]  R1846     3.3904662728309631e-01
    z[3,6,4]  R1847     0.536944568157196
    z[3,6,4]  R1848     5.3472465276718140e-01
    z[3,6,4]  R1849     3.1423911452293396e-01
    z[3,6,4]  R1850     3.7826636433601379e-01
    z[3,6,4]  R1851     -1.6794683039188385e-01
    z[3,6,4]  R1852     2.4229032918810844e-02
    z[3,6,4]  R1853     2.3647651076316833e-01
    z[3,6,4]  R1854     5.2013982087373734e-02
    z[3,6,4]  R1855     3.5284776240587234e-02
    z[3,6,4]  R1856     4.6251362562179565e-01
    z[3,6,4]  R1857     3.9560711383819580e-01
    z[3,6,4]  R1858     -1.7187000811100006e-01
    z[3,6,4]  R1859     8.7326399981975555e-02
    z[3,6,4]  R1860     3.7959685921669006e-01
    z[3,6,4]  R1861     2.2575959563255310e-01
    z[3,6,4]  R1862     4.5889419317245483e-01
    z[3,6,4]  R1863     -3.0037787556648254e-01
    z[3,6,4]  R1864     1.6902795433998108e-01
    z[3,6,4]  R1865     4.5079541206359863e-01
    z[3,6,4]  R1866     2.2691859304904938e-01
    z[3,6,4]  R1867     5.3960567712783813e-01
    z[3,6,4]  R1868     1.1950118094682693e-01
    z[3,6,4]  R1869     -0.562481164932251
    z[3,6,4]  R1870     4.0394267439842224e-01
    z[3,6,4]  R1871     -1.9072486320510507e-03
    z[3,6,4]  R1872     0.494154691696167
    z[3,6,4]  R1873     -1.9802886247634888e-01
    z[3,6,4]  R1874     2.0406669378280640e-01
    z[3,6,4]  R1875     3.5650530457496643e-01
    z[3,6,4]  R1876     -3.6467918753623962e-01
    z[3,6,4]  R1877     -8.4266647696495056e-02
    z[3,6,4]  R1878     -4.7175593674182892e-02
    z[3,6,4]  R1879     -1.6847534105181694e-02
    z[3,6,4]  R1880     5.5132389068603516e-01
    z[3,6,4]  R1881     0.340406596660614
    z[3,6,4]  R1882     1.7809723317623138e-01
    z[3,6,4]  R1883     -2.5065923109650612e-02
    z[3,6,4]  R1884     -6.3743394613265991e-01
    z[3,6,4]  R1885     -1.3657073676586151e-01
    z[3,6,4]  R1886     -2.7995908260345459e-01
    z[3,6,4]  R1887     -5.8870977163314819e-01
    z[3,6,4]  R1888     -8.1852513551712036e-01
    z[3,6,4]  R1889     8.7458200752735138e-02
    z[3,6,4]  R1890     -4.6370047330856323e-01
    z[3,6,4]  R1891     1.2290842831134796e-01
    z[3,6,4]  R1892     -6.2325045466423035e-02
    z[3,6,4]  R1893     -7.8452903032302856e-01
    z[3,6,4]  R1894     8.9119784533977509e-02
    z[3,6,4]  R1895     1.4148251712322235e-01
    z[3,6,4]  R1896     1.2777429819107056e-01
    z[3,6,4]  R1897     1.1681786179542542e-01
    z[3,6,4]  R1898     3.0304929614067078e-01
    z[3,6,4]  R1899     -6.9315090775489807e-02
    z[3,6,4]  R1900     4.2483016848564148e-01
    z[3,6,4]  R1901     1.8962581455707550e-01
    z[3,6,4]  R1902     1.5284567140042782e-02
    z[3,6,4]  R1903     2.2329214215278625e-01
    z[3,6,4]  R1904     -3.4885589033365250e-02
    z[3,6,4]  R1905     -5.6437385082244873e-01
    z[3,6,4]  R1906     -3.9155066013336182e-01
    z[3,6,4]  R1907     6.4252310991287231e-01
    z[3,6,4]  R1908     -1.9448530673980713e-01
    z[3,6,4]  R1909     -5.9565279632806778e-02
    z[3,6,4]  R1910     4.3613232672214508e-02
    z[3,6,4]  R1911     -1.6706696152687073e-01
    z[3,6,4]  R1912     1.5945152938365936e-01
    z[3,6,4]  R1913     -0.700086772441864
    z[3,6,4]  R1914     -8.6237683892250061e-02
    z[3,6,4]  R1915     2.8281274437904358e-01
    z[3,6,4]  R1916     -1.9821323454380035e-01
    z[3,6,4]  R1917     -1.6417573392391205e-01
    z[3,6,4]  R1918     1.9250491261482239e-01
    z[3,6,4]  R1919     5.5724793672561646e-01
    z[3,6,4]  R1920     2.7393159270286560e-01
    z[3,6,4]  R1921     1.7277634143829346e-01
    z[3,6,4]  R1922     0.624572217464447
    z[3,6,4]  R1923     0.0839446485042572
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1811     -1
    z[3,6,5]  R1812     1
    z[3,6,5]  R1815     -2.7438384294509888e-01
    z[3,6,5]  R1816     1.9655370712280273e-01
    z[3,6,5]  R1817     9.9414110183715820e-02
    z[3,6,5]  R1818     1.8051995337009430e-01
    z[3,6,5]  R1819     1.2213288247585297e-01
    z[3,6,5]  R1820     -8.3527758717536926e-02
    z[3,6,5]  R1821     -2.8987939003854990e-03
    z[3,6,5]  R1822     -3.8450825214385986e-01
    z[3,6,5]  R1823     -1.7510086297988892e-01
    z[3,6,5]  R1824     0.253398597240448
    z[3,6,5]  R1825     0.00825007539242506
    z[3,6,5]  R1826     4.9329242110252380e-01
    z[3,6,5]  R1827     4.4502985477447510e-01
    z[3,6,5]  R1828     -1.3583134859800339e-02
    z[3,6,5]  R1829     5.4998189210891724e-02
    z[3,6,5]  R1830     2.7247005701065063e-01
    z[3,6,5]  R1831     1.1730955541133881e-01
    z[3,6,5]  R1832     4.0171834826469421e-01
    z[3,6,5]  R1833     3.2744646072387695e-01
    z[3,6,5]  R1834     0.0937584787607193
    z[3,6,5]  R1835     1.3725067675113678e-01
    z[3,6,5]  R1836     3.8609090447425842e-01
    z[3,6,5]  R1837     -4.2861010879278183e-02
    z[3,6,5]  R1838     -2.5508111715316772e-01
    z[3,6,5]  R1839     -4.9958512187004089e-02
    z[3,6,5]  R1840     0.0769592747092247
    z[3,6,5]  R1841     -1.3457165658473969e-01
    z[3,6,5]  R1842     2.4149735271930695e-01
    z[3,6,5]  R1843     1.6522608697414398e-01
    z[3,6,5]  R1844     4.5957455039024353e-01
    z[3,6,5]  R1845     -1.4389362931251526e-01
    z[3,6,5]  R1846     1.6535639762878418e-01
    z[3,6,5]  R1847     3.1621418893337250e-02
    z[3,6,5]  R1848     -1.0094086080789566e-01
    z[3,6,5]  R1849     0.306438684463501
    z[3,6,5]  R1850     4.3003073334693909e-01
    z[3,6,5]  R1851     5.4396629333496094e-01
    z[3,6,5]  R1852     6.4435862004756927e-02
    z[3,6,5]  R1853     3.2721394300460815e-01
    z[3,6,5]  R1854     -2.8444245457649231e-01
    z[3,6,5]  R1855     -5.0231266021728516e-01
    z[3,6,5]  R1856     -6.2959247827529907e-01
    z[3,6,5]  R1857     3.7279227375984192e-01
    z[3,6,5]  R1858     1.6531041264533997e-01
    z[3,6,5]  R1859     -1.9833190739154816e-01
    z[3,6,5]  R1860     -1.8671898543834686e-01
    z[3,6,5]  R1861     2.3983092606067657e-01
    z[3,6,5]  R1862     9.2646442353725433e-02
    z[3,6,5]  R1863     3.4028777480125427e-01
    z[3,6,5]  R1864     4.1649112105369568e-01
    z[3,6,5]  R1865     8.1165522336959839e-02
    z[3,6,5]  R1866     1.4363476634025574e-01
    z[3,6,5]  R1867     1.0789851844310760e-01
    z[3,6,5]  R1868     -2.3141042888164520e-01
    z[3,6,5]  R1869     -1.7139554023742676e-02
    z[3,6,5]  R1870     -0.318229079246521
    z[3,6,5]  R1871     2.6526167988777161e-01
    z[3,6,5]  R1872     -2.1993994712829590e-01
    z[3,6,5]  R1873     1.5587139129638672e-01
    z[3,6,5]  R1874     3.8067254424095154e-01
    z[3,6,5]  R1875     3.0121762305498123e-02
    z[3,6,5]  R1876     5.5897551774978638e-01
    z[3,6,5]  R1877     2.1398428082466125e-01
    z[3,6,5]  R1878     3.8329538702964783e-01
    z[3,6,5]  R1879     2.9617869853973389e-01
    z[3,6,5]  R1880     0.158024862408638
    z[3,6,5]  R1881     -2.8970161080360413e-01
    z[3,6,5]  R1882     3.5380387306213379e-01
    z[3,6,5]  R1883     3.3629050850868225e-01
    z[3,6,5]  R1884     2.0146530866622925e-01
    z[3,6,5]  R1885     1.3990907371044159e-01
    z[3,6,5]  R1886     3.3354374766349792e-01
    z[3,6,5]  R1887     3.0304759740829468e-01
    z[3,6,5]  R1888     3.3876052498817444e-01
    z[3,6,5]  R1889     3.4586733579635620e-01
    z[3,6,5]  R1890     2.0835934579372406e-01
    z[3,6,5]  R1891     2.6599800586700439e-01
    z[3,6,5]  R1892     4.1952362656593323e-01
    z[3,6,5]  R1893     4.9756024032831192e-02
    z[3,6,5]  R1894     -1.2804748117923737e-01
    z[3,6,5]  R1895     5.2556627988815308e-01
    z[3,6,5]  R1896     -1.1099065840244293e-01
    z[3,6,5]  R1897     -5.7539731264114380e-02
    z[3,6,5]  R1898     -2.8323435783386230e-01
    z[3,6,5]  R1899     -1.1019649356603622e-01
    z[3,6,5]  R1900     3.2817018032073975e-01
    z[3,6,5]  R1901     -1.2396162748336792e-01
    z[3,6,5]  R1902     -1.2915004789829254e-01
    z[3,6,5]  R1903     -2.5686267018318176e-01
    z[3,6,5]  R1904     -3.6452582478523254e-01
    z[3,6,5]  R1905     5.6535284966230392e-02
    z[3,6,5]  R1906     4.9025887250900269e-01
    z[3,6,5]  R1907     -2.7779844403266907e-01
    z[3,6,5]  R1908     6.3344120979309082e-01
    z[3,6,5]  R1909     6.5751016139984131e-01
    z[3,6,5]  R1910     -6.4349383115768433e-02
    z[3,6,5]  R1911     -1.0267642885446548e-01
    z[3,6,5]  R1912     7.5395655632019043e-01
    z[3,6,5]  R1913     -2.2027517855167389e-01
    z[3,6,5]  R1914     -1.9749562442302704e-01
    z[3,6,5]  R1915     1.4104568958282471e-01
    z[3,6,5]  R1916     -8.9955426752567291e-02
    z[3,6,5]  R1917     1.8768961727619171e-01
    z[3,6,5]  R1918     -4.1778244078159332e-02
    z[3,6,5]  R1919     -2.9994806647300720e-01
    z[3,6,5]  R1920     -1.2022332102060318e-01
    z[3,6,5]  R1921     -1.8738360702991486e-01
    z[3,6,5]  R1922     1.8032878637313843e-01
    z[3,6,5]  R1923     -1.3821698725223541e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1813     -1
    z[3,6,6]  R1814     1
    z[3,6,6]  R1815     -9.0920627117156982e-02
    z[3,6,6]  R1816     -1.1257733404636383e-01
    z[3,6,6]  R1817     -1.5459421277046204e-01
    z[3,6,6]  R1818     -3.3619552850723267e-01
    z[3,6,6]  R1819     -7.4777096509933472e-02
    z[3,6,6]  R1820     2.9738730192184448e-01
    z[3,6,6]  R1821     4.5432859659194946e-01
    z[3,6,6]  R1822     3.5045480728149414e-01
    z[3,6,6]  R1823     -0.0526314415037632
    z[3,6,6]  R1824     2.6307487487792969e-01
    z[3,6,6]  R1825     6.2678828835487366e-02
    z[3,6,6]  R1826     -3.8197159767150879e-02
    z[3,6,6]  R1827     9.3276090919971466e-02
    z[3,6,6]  R1828     -2.4080686271190643e-02
    z[3,6,6]  R1829     -1.4493295550346375e-01
    z[3,6,6]  R1830     3.5655535757541656e-02
    z[3,6,6]  R1831     0.0522799976170063
    z[3,6,6]  R1832     3.2310735434293747e-02
    z[3,6,6]  R1833     8.5448555648326874e-02
    z[3,6,6]  R1834     1.2455178052186966e-01
    z[3,6,6]  R1835     1.9001878798007965e-01
    z[3,6,6]  R1836     -5.6835031509399414e-01
    z[3,6,6]  R1837     -3.0935180187225342e-01
    z[3,6,6]  R1838     5.9268784523010254e-01
    z[3,6,6]  R1839     8.0272859334945679e-01
    z[3,6,6]  R1840     -4.1821199655532837e-01
    z[3,6,6]  R1841     5.3628188371658325e-01
    z[3,6,6]  R1842     7.5863644480705261e-02
    z[3,6,6]  R1843     3.7423965334892273e-01
    z[3,6,6]  R1844     7.4497717432677746e-03
    z[3,6,6]  R1845     1.6224814951419830e-01
    z[3,6,6]  R1846     -3.0374118685722351e-01
    z[3,6,6]  R1847     -3.4164834022521973e-01
    z[3,6,6]  R1848     6.2955850362777710e-01
    z[3,6,6]  R1849     3.8678586483001709e-01
    z[3,6,6]  R1850     -1.4108885824680328e-01
    z[3,6,6]  R1851     -2.0895342528820038e-01
    z[3,6,6]  R1852     -1.1328030377626419e-01
    z[3,6,6]  R1853     -0.0601862333714962
    z[3,6,6]  R1854     -2.4160975217819214e-01
    z[3,6,6]  R1855     3.6350575089454651e-01
    z[3,6,6]  R1856     1.0825856775045395e-01
    z[3,6,6]  R1857     -5.4732393473386765e-02
    z[3,6,6]  R1858     3.5946875810623169e-01
    z[3,6,6]  R1859     -2.4727845191955566e-01
    z[3,6,6]  R1860     6.0292577743530273e-01
    z[3,6,6]  R1861     -1.4043906331062317e-01
    z[3,6,6]  R1862     3.4061953425407410e-01
    z[3,6,6]  R1863     -0.281399667263031
    z[3,6,6]  R1864     -5.6827016174793243e-02
    z[3,6,6]  R1865     -3.1062424182891846e-01
    z[3,6,6]  R1866     6.1044901609420776e-01
    z[3,6,6]  R1867     1.9057519733905792e-01
    z[3,6,6]  R1868     6.6493093967437744e-01
    z[3,6,6]  R1869     7.8965082764625549e-02
    z[3,6,6]  R1870     7.5730517506599426e-02
    z[3,6,6]  R1871     1.0132216662168503e-01
    z[3,6,6]  R1872     2.6948660612106323e-01
    z[3,6,6]  R1873     -4.2699408531188965e-01
    z[3,6,6]  R1874     1.2564989924430847e-01
    z[3,6,6]  R1875     1.0915504395961761e-01
    z[3,6,6]  R1876     4.7250889241695404e-02
    z[3,6,6]  R1877     -1.4756020903587341e-01
    z[3,6,6]  R1878     -0.0288847703486681
    z[3,6,6]  R1879     -1.6712214052677155e-01
    z[3,6,6]  R1880     -1.6119672358036041e-01
    z[3,6,6]  R1881     1.5063390135765076e-01
    z[3,6,6]  R1882     1.5044826269149780e-01
    z[3,6,6]  R1883     2.8009437024593353e-02
    z[3,6,6]  R1884     2.9068502783775330e-01
    z[3,6,6]  R1885     2.8227454423904419e-01
    z[3,6,6]  R1886     1.7670619487762451e-01
    z[3,6,6]  R1887     -1.1906898766756058e-01
    z[3,6,6]  R1888     -1.2550881505012512e-01
    z[3,6,6]  R1889     -5.1650381088256836e-01
    z[3,6,6]  R1890     -4.2562881112098694e-01
    z[3,6,6]  R1891     0.447286456823349
    z[3,6,6]  R1892     -2.2831052541732788e-02
    z[3,6,6]  R1893     -1.1260929703712463e-01
    z[3,6,6]  R1894     1.2358459830284119e-01
    z[3,6,6]  R1895     0.00592637388035655
    z[3,6,6]  R1896     -1.7166891694068909e-01
    z[3,6,6]  R1897     6.7347057163715363e-02
    z[3,6,6]  R1898     5.3730695508420467e-03
    z[3,6,6]  R1899     -7.0308116264641285e-03
    z[3,6,6]  R1900     -2.6035559177398682e-01
    z[3,6,6]  R1901     -5.4442346096038818e-02
    z[3,6,6]  R1902     -2.9928541183471680e-01
    z[3,6,6]  R1903     -4.4294662773609161e-02
    z[3,6,6]  R1904     3.9246085286140442e-01
    z[3,6,6]  R1905     5.1586157083511353e-01
    z[3,6,6]  R1906     6.9776542484760284e-02
    z[3,6,6]  R1907     2.9474783688783646e-02
    z[3,6,6]  R1908     -8.5204273462295532e-02
    z[3,6,6]  R1909     1.3028287887573242e-01
    z[3,6,6]  R1910     -6.7805522680282593e-01
    z[3,6,6]  R1911     -6.6481471061706543e-01
    z[3,6,6]  R1912     0.299459844827652
    z[3,6,6]  R1913     -1.1630912870168686e-01
    z[3,6,6]  R1914     -2.8347286581993103e-01
    z[3,6,6]  R1915     -4.8547599464654922e-02
    z[3,6,6]  R1916     3.9975982904434204e-01
    z[3,6,6]  R1917     -6.5692657232284546e-01
    z[3,6,6]  R1918     -6.9269323348999023e-01
    z[3,6,6]  R1919     1.5495055913925171e-01
    z[3,6,6]  R1920     4.4680300354957581e-01
    z[3,6,6]  R1921     7.6224094629287720e-01
    z[3,6,6]  R1922     -6.8241044878959656e-02
    z[3,6,6]  R1923     8.2412803173065186e-01
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1924     -1
    z[6,3,0]  R1925     1
    z[6,3,0]  R1938     -2.1240970492362976e-01
    z[6,3,0]  R1939     5.6615126132965088e-01
    z[6,3,0]  R1940     -0.287582129240036
    z[6,3,0]  R1941     3.9139175415039062e-01
    z[6,3,0]  R1942     8.9847363531589508e-02
    z[6,3,0]  R1943     -1.3517257571220398e-01
    z[6,3,0]  R1944     6.2380012124776840e-02
    z[6,3,0]  R1945     -3.1546853482723236e-02
    z[6,3,0]  R1946     -3.2627135515213013e-01
    z[6,3,0]  R1947     3.7415587902069092e-01
    z[6,3,0]  R1948     -2.1480867266654968e-01
    z[6,3,0]  R1949     -2.4702057242393494e-01
    z[6,3,0]  R1950     0.0647042840719223
    z[6,3,0]  R1951     -0.0897059440612793
    z[6,3,0]  R1952     7.5556194782257080e-01
    z[6,3,0]  R1953     -6.9648653268814087e-01
    z[6,3,0]  R1954     4.2574423551559448e-01
    z[6,3,0]  R1955     -8.8941919803619385e-01
    z[6,3,0]  R1956     6.2374550104141235e-01
    z[6,3,0]  R1957     -5.0331413745880127e-01
    z[6,3,0]  R1958     2.9560112953186035e-01
    z[6,3,0]  R1959     -1.8875746428966522e-01
    z[6,3,0]  R1960     -3.9666953682899475e-01
    z[6,3,0]  R1961     -1.5260013937950134e-01
    z[6,3,0]  R1962     4.4463074207305908e-01
    z[6,3,0]  R1963     1.3967847824096680e-01
    z[6,3,0]  R1964     -5.1141440868377686e-01
    z[6,3,0]  R1965     -3.6340034008026123e-01
    z[6,3,0]  R1966     2.8061848878860474e-01
    z[6,3,0]  R1967     1.1992813646793365e-01
    z[6,3,0]  R1968     -1.1969466507434845e-01
    z[6,3,0]  R1969     0.891903281211853
    z[6,3,0]  R1970     -0.0440092533826828
    z[6,3,0]  R1971     6.9294106960296631e-01
    z[6,3,0]  R1972     6.0244774818420410e-01
    z[6,3,0]  R1973     -8.1641167402267456e-02
    z[6,3,0]  R1974     5.6040030717849731e-01
    z[6,3,0]  R1975     4.0766561031341553e-01
    z[6,3,0]  R1976     3.1279277754947543e-04
    z[6,3,0]  R1977     4.6923488378524780e-01
    z[6,3,0]  R1978     3.7067100405693054e-02
    z[6,3,0]  R1979     3.7179496884346008e-01
    z[6,3,0]  R1980     -4.1181966662406921e-01
    z[6,3,0]  R1981     5.1207607984542847e-01
    z[6,3,0]  R1982     -6.3994753360748291e-01
    z[6,3,0]  R1983     -0.316124826669693
    z[6,3,0]  R1984     -4.0294739603996277e-01
    z[6,3,0]  R1985     5.3729891777038574e-01
    z[6,3,0]  R1986     -4.6869885921478271e-01
    z[6,3,0]  R1987     -4.5559534430503845e-01
    z[6,3,0]  R1988     7.8173793852329254e-02
    z[6,3,0]  R1989     -1.7945900559425354e-01
    z[6,3,0]  R1990     -1.2135547585785389e-03
    z[6,3,0]  R1991     -0.0807340145111084
    z[6,3,0]  R1992     -2.4226111173629761e-01
    z[6,3,0]  R1993     -2.3268264532089233e-01
    z[6,3,0]  R1994     -5.3354259580373764e-02
    z[6,3,0]  R1995     -3.0456345528364182e-02
    z[6,3,0]  R1996     -2.2064997255802155e-01
    z[6,3,0]  R1997     -4.6148531138896942e-02
    z[6,3,0]  R1998     6.5666645765304565e-02
    z[6,3,0]  R1999     -1.9799323379993439e-01
    z[6,3,0]  R2000     3.2701876759529114e-01
    z[6,3,0]  R2001     -1.4233329892158508e-01
    z[6,3,0]  R2002     1.9304735586047173e-02
    z[6,3,0]  R2003     -1.5847027301788330e-01
    z[6,3,0]  R2004     5.3673553466796875e-01
    z[6,3,0]  R2005     3.6323402076959610e-02
    z[6,3,0]  R2006     -3.4531587362289429e-01
    z[6,3,0]  R2007     -1.6749443113803864e-01
    z[6,3,0]  R2008     -2.3113049566745758e-01
    z[6,3,0]  R2009     -4.3012022972106934e-02
    z[6,3,0]  R2010     4.8231253027915955e-01
    z[6,3,0]  R2011     2.5550296530127525e-02
    z[6,3,0]  R2012     -2.0028276741504669e-01
    z[6,3,0]  R2013     -4.8691046237945557e-01
    z[6,3,0]  R2014     -1.2682755291461945e-01
    z[6,3,0]  R2015     2.6874890923500061e-01
    z[6,3,0]  R2016     1.3006573915481567e-01
    z[6,3,0]  R2017     3.6033737659454346e-01
    z[6,3,0]  R2018     5.9692794084548950e-01
    z[6,3,0]  R2019     3.9397379755973816e-01
    z[6,3,0]  R2020     -1.7629776895046234e-01
    z[6,3,0]  R2021     1.2649475038051605e-01
    z[6,3,0]  R2022     5.8065932244062424e-02
    z[6,3,0]  R2023     -2.4579444527626038e-01
    z[6,3,0]  R2024     6.5198093652725220e-02
    z[6,3,0]  R2025     5.4943734407424927e-01
    z[6,3,0]  R2026     -1.5163809061050415e-01
    z[6,3,0]  R2027     -2.2004279494285583e-01
    z[6,3,0]  R2028     -1.1727644503116608e-01
    z[6,3,0]  R2029     1.9039590656757355e-01
    z[6,3,0]  R2030     2.9173459857702255e-02
    z[6,3,0]  R2031     -5.5233038961887360e-02
    z[6,3,0]  R2032     -1.4811183512210846e-01
    z[6,3,0]  R2033     9.3578584492206573e-02
    z[6,3,0]  R2034     -9.8985306918621063e-02
    z[6,3,0]  R2035     -1.3010847568511963e-01
    z[6,3,0]  R2036     1.1820724606513977e-01
    z[6,3,0]  R2037     -2.2255496680736542e-01
    z[6,3,0]  R2038     -1.2191570550203323e-01
    z[6,3,0]  R2039     -3.0332719907164574e-02
    z[6,3,0]  R2040     -8.1705629825592041e-02
    z[6,3,0]  R2041     -3.3933378756046295e-02
    z[6,3,0]  R2042     4.9755383282899857e-02
    z[6,3,0]  R2043     1.3494296371936798e-01
    z[6,3,0]  R2044     0.0110483942553401
    z[6,3,0]  R2045     1.4044113457202911e-01
    z[6,3,0]  R2046     0.590168297290802
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1926     -1
    z[6,3,1]  R1927     1
    z[6,3,1]  R1938     -4.4346127659082413e-02
    z[6,3,1]  R1939     -9.0379834175109863e-02
    z[6,3,1]  R1940     -1.5228827297687531e-01
    z[6,3,1]  R1941     -1.0052482783794403e-01
    z[6,3,1]  R1942     -3.9079539477825165e-02
    z[6,3,1]  R1943     -1.6333429515361786e-01
    z[6,3,1]  R1944     -5.1454100757837296e-02
    z[6,3,1]  R1945     -5.8109525591135025e-02
    z[6,3,1]  R1946     9.2844374477863312e-02
    z[6,3,1]  R1947     -8.1013187766075134e-02
    z[6,3,1]  R1948     8.1758999824523926e-01
    z[6,3,1]  R1949     -2.7423635125160217e-01
    z[6,3,1]  R1950     9.2157393693923950e-01
    z[6,3,1]  R1951     9.1725713014602661e-01
    z[6,3,1]  R1952     -3.1591439247131348e-01
    z[6,3,1]  R1953     -4.2140522599220276e-01
    z[6,3,1]  R1954     -2.1396489441394806e-01
    z[6,3,1]  R1955     -0.283568799495697
    z[6,3,1]  R1956     3.6306354403495789e-01
    z[6,3,1]  R1957     -5.2217030525207520e-01
    z[6,3,1]  R1958     -7.4705088138580322e-01
    z[6,3,1]  R1959     -6.0879707336425781e-01
    z[6,3,1]  R1960     -6.1021369695663452e-01
    z[6,3,1]  R1961     -5.2069664001464844e-01
    z[6,3,1]  R1962     -5.0037395954132080e-01
    z[6,3,1]  R1963     -5.1626527309417725e-01
    z[6,3,1]  R1964     -4.8499128222465515e-01
    z[6,3,1]  R1965     -4.2986959218978882e-01
    z[6,3,1]  R1966     -4.6784445643424988e-01
    z[6,3,1]  R1967     -5.2109575271606445e-01
    z[6,3,1]  R1968     -6.4972156286239624e-01
    z[6,3,1]  R1969     1.3706804811954498e-01
    z[6,3,1]  R1970     -5.5932825803756714e-01
    z[6,3,1]  R1971     4.6786937862634659e-02
    z[6,3,1]  R1972     -2.8206637501716614e-01
    z[6,3,1]  R1973     -0.646415650844574
    z[6,3,1]  R1974     4.0782818198204041e-01
    z[6,3,1]  R1975     1.4009904861450195e-01
    z[6,3,1]  R1976     -2.5747969746589661e-01
    z[6,3,1]  R1977     2.2282439470291138e-01
    z[6,3,1]  R1978     6.9367986917495728e-01
    z[6,3,1]  R1979     6.6264796257019043e-01
    z[6,3,1]  R1980     -4.9712666869163513e-01
    z[6,3,1]  R1981     4.0542349219322205e-01
    z[6,3,1]  R1982     -0.443347305059433
    z[6,3,1]  R1983     -5.1285165548324585e-01
    z[6,3,1]  R1984     -0.450613796710968
    z[6,3,1]  R1985     6.5254640579223633e-01
    z[6,3,1]  R1986     -6.2381881475448608e-01
    z[6,3,1]  R1987     7.0405995845794678e-01
    z[6,3,1]  R1988     -9.6634417772293091e-01
    z[6,3,1]  R1989     -8.2638806104660034e-01
    z[6,3,1]  R1990     -8.3274024724960327e-01
    z[6,3,1]  R1991     -9.4393610954284668e-01
    z[6,3,1]  R1992     -8.9501363039016724e-01
    z[6,3,1]  R1993     -8.5856539011001587e-01
    z[6,3,1]  R1994     -9.3438696861267090e-01
    z[6,3,1]  R1995     -8.9354443550109863e-01
    z[6,3,1]  R1996     -8.9741677045822144e-01
    z[6,3,1]  R1997     -8.6780643463134766e-01
    z[6,3,1]  R1998     9.0192121267318726e-01
    z[6,3,1]  R1999     0.6239013671875
    z[6,3,1]  R2000     3.4472694993019104e-01
    z[6,3,1]  R2001     0.70050448179245
    z[6,3,1]  R2002     4.5671561360359192e-01
    z[6,3,1]  R2003     0.627260684967041
    z[6,3,1]  R2004     7.8109733294695616e-04
    z[6,3,1]  R2005     -7.5922125577926636e-01
    z[6,3,1]  R2006     -0.715255618095398
    z[6,3,1]  R2007     -5.2114403247833252e-01
    z[6,3,1]  R2008     7.6005853712558746e-02
    z[6,3,1]  R2009     0.802408754825592
    z[6,3,1]  R2010     -0.0430334135890007
    z[6,3,1]  R2011     4.5041911303997040e-02
    z[6,3,1]  R2012     3.0691778659820557e-01
    z[6,3,1]  R2013     2.6438814401626587e-01
    z[6,3,1]  R2014     -5.6059908866882324e-01
    z[6,3,1]  R2015     -6.6544133424758911e-01
    z[6,3,1]  R2016     -6.2691295146942139e-01
    z[6,3,1]  R2017     -6.3844412565231323e-01
    z[6,3,1]  R2018     1.4414748549461365e-01
    z[6,3,1]  R2019     3.5924646258354187e-01
    z[6,3,1]  R2020     4.2892915010452271e-01
    z[6,3,1]  R2021     7.6178300380706787e-01
    z[6,3,1]  R2022     8.5596400499343872e-01
    z[6,3,1]  R2023     5.7058918476104736e-01
    z[6,3,1]  R2024     0.0888204276561737
    z[6,3,1]  R2025     0.0500313900411129
    z[6,3,1]  R2026     -7.8557604551315308e-01
    z[6,3,1]  R2027     -6.9789052009582520e-01
    z[6,3,1]  R2028     5.8851748704910278e-01
    z[6,3,1]  R2029     3.6812219023704529e-01
    z[6,3,1]  R2030     7.0105659961700439e-01
    z[6,3,1]  R2031     6.9236093759536743e-01
    z[6,3,1]  R2032     7.4410974979400635e-01
    z[6,3,1]  R2033     -7.9978233575820923e-01
    z[6,3,1]  R2034     -6.6857415437698364e-01
    z[6,3,1]  R2035     -7.6604461669921875e-01
    z[6,3,1]  R2036     -8.1263101100921631e-01
    z[6,3,1]  R2037     2.2216621041297913e-01
    z[6,3,1]  R2038     8.7879288196563721e-01
    z[6,3,1]  R2039     6.9568967819213867e-01
    z[6,3,1]  R2040     -7.6769274473190308e-01
    z[6,3,1]  R2041     -0.793660581111908
    z[6,3,1]  R2042     -8.9406061172485352e-01
    z[6,3,1]  R2043     -0.69505375623703
    z[6,3,1]  R2044     -6.0580420494079590e-01
    z[6,3,1]  R2045     -4.4465139508247375e-03
    z[6,3,1]  R2046     1.0688560083508492e-02
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1928     -1
    z[6,3,2]  R1929     1
    z[6,3,2]  R1938     -6.2255424261093140e-01
    z[6,3,2]  R1939     -7.4332630634307861e-01
    z[6,3,2]  R1940     -8.0464816093444824e-01
    z[6,3,2]  R1941     -6.0049152374267578e-01
    z[6,3,2]  R1942     -1.8468938767910004e-01
    z[6,3,2]  R1943     -7.3881131410598755e-01
    z[6,3,2]  R1944     -6.4745169878005981e-01
    z[6,3,2]  R1945     -8.3255708217620850e-01
    z[6,3,2]  R1946     -8.3497482538223267e-01
    z[6,3,2]  R1947     -3.6337402462959290e-01
    z[6,3,2]  R1948     3.0558711290359497e-01
    z[6,3,2]  R1949     5.8320814371109009e-01
    z[6,3,2]  R1950     2.4961875379085541e-01
    z[6,3,2]  R1951     2.9769837856292725e-01
    z[6,3,2]  R1952     2.1694932878017426e-01
    z[6,3,2]  R1953     2.8463923931121826e-01
    z[6,3,2]  R1954     2.0543260872364044e-01
    z[6,3,2]  R1955     2.0874388515949249e-01
    z[6,3,2]  R1956     0.381873220205307
    z[6,3,2]  R1957     3.4576156735420227e-01
    z[6,3,2]  R1958     1.0945479571819305e-01
    z[6,3,2]  R1959     -3.2285865396261215e-02
    z[6,3,2]  R1960     -5.2841058932244778e-03
    z[6,3,2]  R1961     2.2360880672931671e-01
    z[6,3,2]  R1962     3.1841287016868591e-01
    z[6,3,2]  R1963     -3.3113136887550354e-01
    z[6,3,2]  R1964     1.0439525544643402e-01
    z[6,3,2]  R1965     2.3203656077384949e-01
    z[6,3,2]  R1966     -1.0930939763784409e-01
    z[6,3,2]  R1967     2.4682506918907166e-01
    z[6,3,2]  R1968     -6.2499684095382690e-01
    z[6,3,2]  R1969     -2.2313027083873749e-01
    z[6,3,2]  R1970     -9.5440290868282318e-02
    z[6,3,2]  R1971     -6.9622255861759186e-02
    z[6,3,2]  R1972     -1.8771840631961823e-01
    z[6,3,2]  R1973     -2.8977859020233154e-01
    z[6,3,2]  R1974     0.0358751118183136
    z[6,3,2]  R1975     -1.8994650244712830e-01
    z[6,3,2]  R1976     -4.9565258622169495e-01
    z[6,3,2]  R1977     1.5451537072658539e-01
    z[6,3,2]  R1978     3.7445166707038879e-01
    z[6,3,2]  R1979     -2.4146245419979095e-01
    z[6,3,2]  R1980     -6.5644830465316772e-01
    z[6,3,2]  R1981     -1.2594206631183624e-01
    z[6,3,2]  R1982     -5.0185889005661011e-01
    z[6,3,2]  R1983     -3.9556607604026794e-01
    z[6,3,2]  R1984     -4.8620283603668213e-01
    z[6,3,2]  R1985     -5.1303360611200333e-02
    z[6,3,2]  R1986     -1.8828479945659637e-01
    z[6,3,2]  R1987     -1.8435798585414886e-01
    z[6,3,2]  R1988     1.3297490775585175e-01
    z[6,3,2]  R1989     -1.6308559570461512e-03
    z[6,3,2]  R1990     -7.8419208526611328e-02
    z[6,3,2]  R1991     1.8751381337642670e-01
    z[6,3,2]  R1992     1.4740787446498871e-01
    z[6,3,2]  R1993     3.0041760206222534e-01
    z[6,3,2]  R1994     3.2278785109519958e-01
    z[6,3,2]  R1995     1.4655736088752747e-01
    z[6,3,2]  R1996     -4.4597167521715164e-02
    z[6,3,2]  R1997     2.1245136857032776e-01
    z[6,3,2]  R1998     -1.2600612640380859e-01
    z[6,3,2]  R1999     -2.3675315082073212e-01
    z[6,3,2]  R2000     -1.9854129850864410e-01
    z[6,3,2]  R2001     -8.3444461226463318e-02
    z[6,3,2]  R2002     -2.7143913507461548e-01
    z[6,3,2]  R2003     -2.6291960477828979e-01
    z[6,3,2]  R2004     -0.0666758269071579
    z[6,3,2]  R2005     -1.8733938038349152e-01
    z[6,3,2]  R2006     -0.0946456640958786
    z[6,3,2]  R2007     -1.4219684898853302e-01
    z[6,3,2]  R2008     2.4438938498497009e-01
    z[6,3,2]  R2009     -3.3602195978164673e-01
    z[6,3,2]  R2010     -5.1875356584787369e-03
    z[6,3,2]  R2011     2.1833754144608974e-03
    z[6,3,2]  R2012     -2.4139027297496796e-01
    z[6,3,2]  R2013     -1.5233443677425385e-01
    z[6,3,2]  R2014     -4.3736910820007324e-01
    z[6,3,2]  R2015     -2.3348213732242584e-01
    z[6,3,2]  R2016     -4.5843631029129028e-01
    z[6,3,2]  R2017     1.5957817435264587e-01
    z[6,3,2]  R2018     2.9598847031593323e-01
    z[6,3,2]  R2019     2.7041327953338623e-01
    z[6,3,2]  R2020     -2.4659752845764160e-01
    z[6,3,2]  R2021     -4.6603524684906006e-01
    z[6,3,2]  R2022     -0.0762200802564621
    z[6,3,2]  R2023     2.4485167115926743e-02
    z[6,3,2]  R2024     2.6378279551863670e-02
    z[6,3,2]  R2025     -3.3334141969680786e-01
    z[6,3,2]  R2026     -9.0231351554393768e-02
    z[6,3,2]  R2027     -3.5453933477401733e-01
    z[6,3,2]  R2028     4.3191414326429367e-02
    z[6,3,2]  R2029     -0.341232031583786
    z[6,3,2]  R2030     -4.0100088715553284e-01
    z[6,3,2]  R2031     -7.8620567917823792e-02
    z[6,3,2]  R2032     -1.0464297980070114e-01
    z[6,3,2]  R2033     -2.4717628955841064e-01
    z[6,3,2]  R2034     -3.3976930379867554e-01
    z[6,3,2]  R2035     -1.2700571119785309e-01
    z[6,3,2]  R2036     1.9309714436531067e-01
    z[6,3,2]  R2037     7.5070065259933472e-01
    z[6,3,2]  R2038     -2.0854748785495758e-01
    z[6,3,2]  R2039     2.2803038358688354e-01
    z[6,3,2]  R2040     -1.6927412152290344e-01
    z[6,3,2]  R2041     -3.2806521654129028e-01
    z[6,3,2]  R2042     7.4264849536120892e-03
    z[6,3,2]  R2043     -2.3701396584510803e-01
    z[6,3,2]  R2044     1.0115970671176910e-01
    z[6,3,2]  R2045     0.692564845085144
    z[6,3,2]  R2046     3.3201807737350464e-01
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1930     -1
    z[6,3,3]  R1931     1
    z[6,3,3]  R1938     -1.8421080708503723e-01
    z[6,3,3]  R1939     -2.9413759708404541e-02
    z[6,3,3]  R1940     1.6060025990009308e-01
    z[6,3,3]  R1941     1.5337137877941132e-01
    z[6,3,3]  R1942     3.9470937848091125e-01
    z[6,3,3]  R1943     1.2312074750661850e-01
    z[6,3,3]  R1944     -0.366982102394104
    z[6,3,3]  R1945     1.2864798307418823e-01
    z[6,3,3]  R1946     -8.5663378238677979e-02
    z[6,3,3]  R1947     -3.0126622319221497e-01
    z[6,3,3]  R1948     3.9039561152458191e-01
    z[6,3,3]  R1949     -4.7683459520339966e-01
    z[6,3,3]  R1950     -1.6152353584766388e-01
    z[6,3,3]  R1951     -2.0118415355682373e-01
    z[6,3,3]  R1952     3.3191543817520142e-01
    z[6,3,3]  R1953     4.8919060826301575e-01
    z[6,3,3]  R1954     -6.1220663785934448e-01
    z[6,3,3]  R1955     1.7509926855564117e-01
    z[6,3,3]  R1956     -4.7625014185905457e-01
    z[6,3,3]  R1957     4.8647928237915039e-01
    z[6,3,3]  R1958     -2.3330879211425781e-01
    z[6,3,3]  R1959     -6.9764018058776855e-02
    z[6,3,3]  R1960     2.6782515645027161e-01
    z[6,3,3]  R1961     -0.405845582485199
    z[6,3,3]  R1962     6.4888454973697662e-02
    z[6,3,3]  R1963     -3.8919255137443542e-01
    z[6,3,3]  R1964     1.6290649771690369e-01
    z[6,3,3]  R1965     -3.8584843277931213e-01
    z[6,3,3]  R1966     8.2914769649505615e-02
    z[6,3,3]  R1967     3.1777891516685486e-01
    z[6,3,3]  R1968     -2.1474552154541016e-01
    z[6,3,3]  R1969     1.8357586860656738e-01
    z[6,3,3]  R1970     6.8477582931518555e-01
    z[6,3,3]  R1971     1.3806837797164917e-01
    z[6,3,3]  R1972     -6.0245178639888763e-02
    z[6,3,3]  R1973     2.5885561108589172e-01
    z[6,3,3]  R1974     -4.7876462340354919e-01
    z[6,3,3]  R1975     -0.363491028547287
    z[6,3,3]  R1976     5.1065343618392944e-01
    z[6,3,3]  R1977     -3.0907431617379189e-02
    z[6,3,3]  R1978     4.9024832248687744e-01
    z[6,3,3]  R1979     5.2322983741760254e-01
    z[6,3,3]  R1980     -2.6184621453285217e-01
    z[6,3,3]  R1981     5.5958682298660278e-01
    z[6,3,3]  R1982     6.1362501233816147e-02
    z[6,3,3]  R1983     -4.5997259020805359e-01
    z[6,3,3]  R1984     -1.9809435307979584e-01
    z[6,3,3]  R1985     -0.0729481503367424
    z[6,3,3]  R1986     -1.1497498303651810e-01
    z[6,3,3]  R1987     2.1794460713863373e-01
    z[6,3,3]  R1988     -1.2271368503570557e-01
    z[6,3,3]  R1989     -1.6657491028308868e-01
    z[6,3,3]  R1990     -1.7226240038871765e-01
    z[6,3,3]  R1991     -2.4263501167297363e-01
    z[6,3,3]  R1992     -2.9438859224319458e-01
    z[6,3,3]  R1993     -1.4323222637176514e-01
    z[6,3,3]  R1994     5.3854927420616150e-02
    z[6,3,3]  R1995     8.3793297410011292e-02
    z[6,3,3]  R1996     5.9439826756715775e-02
    z[6,3,3]  R1997     2.2096496820449829e-01
    z[6,3,3]  R1998     -3.3231475949287415e-01
    z[6,3,3]  R1999     8.5544362664222717e-02
    z[6,3,3]  R2000     5.4995030164718628e-02
    z[6,3,3]  R2001     -2.5623863935470581e-01
    z[6,3,3]  R2002     1.4718367159366608e-01
    z[6,3,3]  R2003     -4.7586208581924438e-01
    z[6,3,3]  R2004     5.7744556665420532e-01
    z[6,3,3]  R2005     -3.7982547283172607e-01
    z[6,3,3]  R2006     -3.8820537924766541e-01
    z[6,3,3]  R2007     -6.8278080224990845e-01
    z[6,3,3]  R2008     5.6001764535903931e-01
    z[6,3,3]  R2009     -8.2615956664085388e-02
    z[6,3,3]  R2010     5.9955221414566040e-01
    z[6,3,3]  R2011     5.5213242769241333e-01
    z[6,3,3]  R2012     6.8202984333038330e-01
    z[6,3,3]  R2013     0.567356526851654
    z[6,3,3]  R2014     -3.3254262804985046e-01
    z[6,3,3]  R2015     -6.4255464076995850e-01
    z[6,3,3]  R2016     -4.6182984113693237e-01
    z[6,3,3]  R2017     -5.4322427511215210e-01
    z[6,3,3]  R2018     3.8676840066909790e-01
    z[6,3,3]  R2019     -1.4344982802867889e-01
    z[6,3,3]  R2020     6.5242147445678711e-01
    z[6,3,3]  R2021     -2.0302671939134598e-02
    z[6,3,3]  R2022     -3.8734534382820129e-01
    z[6,3,3]  R2023     2.6633885502815247e-01
    z[6,3,3]  R2024     9.2679816484451294e-01
    z[6,3,3]  R2025     4.9930948019027710e-01
    z[6,3,3]  R2026     -2.5792637467384338e-01
    z[6,3,3]  R2027     -3.6546853184700012e-01
    z[6,3,3]  R2028     5.7596552371978760e-01
    z[6,3,3]  R2029     5.1674467325210571e-01
    z[6,3,3]  R2030     8.7929308414459229e-02
    z[6,3,3]  R2031     3.7946559488773346e-02
    z[6,3,3]  R2032     -3.0083081126213074e-01
    z[6,3,3]  R2033     -1.4255067706108093e-01
    z[6,3,3]  R2034     -5.8918052911758423e-01
    z[6,3,3]  R2035     -1.2219463288784027e-01
    z[6,3,3]  R2036     2.0624296367168427e-01
    z[6,3,3]  R2037     -3.6771920323371887e-01
    z[6,3,3]  R2038     1.7160816490650177e-01
    z[6,3,3]  R2039     -1.2418014556169510e-01
    z[6,3,3]  R2040     -5.4831933975219727e-01
    z[6,3,3]  R2041     -3.3369067311286926e-01
    z[6,3,3]  R2042     2.8668698668479919e-01
    z[6,3,3]  R2043     -2.9597437381744385e-01
    z[6,3,3]  R2044     -6.3257539272308350e-01
    z[6,3,3]  R2045     -0.566639244556427
    z[6,3,3]  R2046     -6.5333527326583862e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1932     -1
    z[6,3,4]  R1933     1
    z[6,3,4]  R1938     -6.3743394613265991e-01
    z[6,3,4]  R1939     -1.3657073676586151e-01
    z[6,3,4]  R1940     -2.7995908260345459e-01
    z[6,3,4]  R1941     -5.8870977163314819e-01
    z[6,3,4]  R1942     -8.1852513551712036e-01
    z[6,3,4]  R1943     8.7458200752735138e-02
    z[6,3,4]  R1944     -4.6370047330856323e-01
    z[6,3,4]  R1945     1.2290842831134796e-01
    z[6,3,4]  R1946     -6.2325045466423035e-02
    z[6,3,4]  R1947     -7.8452903032302856e-01
    z[6,3,4]  R1948     8.9119784533977509e-02
    z[6,3,4]  R1949     1.4148251712322235e-01
    z[6,3,4]  R1950     1.2777429819107056e-01
    z[6,3,4]  R1951     1.1681786179542542e-01
    z[6,3,4]  R1952     3.0304929614067078e-01
    z[6,3,4]  R1953     -6.9315090775489807e-02
    z[6,3,4]  R1954     4.2483016848564148e-01
    z[6,3,4]  R1955     1.8962581455707550e-01
    z[6,3,4]  R1956     1.5284567140042782e-02
    z[6,3,4]  R1957     2.2329214215278625e-01
    z[6,3,4]  R1958     -3.4885589033365250e-02
    z[6,3,4]  R1959     -5.6437385082244873e-01
    z[6,3,4]  R1960     -3.9155066013336182e-01
    z[6,3,4]  R1961     6.4252310991287231e-01
    z[6,3,4]  R1962     -1.9448530673980713e-01
    z[6,3,4]  R1963     -5.9565279632806778e-02
    z[6,3,4]  R1964     4.3613232672214508e-02
    z[6,3,4]  R1965     -1.6706696152687073e-01
    z[6,3,4]  R1966     1.5945152938365936e-01
    z[6,3,4]  R1967     -0.700086772441864
    z[6,3,4]  R1968     -8.6237683892250061e-02
    z[6,3,4]  R1969     2.8281274437904358e-01
    z[6,3,4]  R1970     -1.9821323454380035e-01
    z[6,3,4]  R1971     -1.6417573392391205e-01
    z[6,3,4]  R1972     1.9250491261482239e-01
    z[6,3,4]  R1973     5.5724793672561646e-01
    z[6,3,4]  R1974     2.7393159270286560e-01
    z[6,3,4]  R1975     1.7277634143829346e-01
    z[6,3,4]  R1976     0.624572217464447
    z[6,3,4]  R1977     0.0839446485042572
    z[6,3,4]  R1978     -2.3091910779476166e-01
    z[6,3,4]  R1979     -1.9820597767829895e-01
    z[6,3,4]  R1980     -0.223605215549469
    z[6,3,4]  R1981     -3.1431868672370911e-01
    z[6,3,4]  R1982     -3.4318295121192932e-01
    z[6,3,4]  R1983     -4.1663515567779541e-01
    z[6,3,4]  R1984     -3.9054206013679504e-01
    z[6,3,4]  R1985     -8.2912124693393707e-02
    z[6,3,4]  R1986     -5.5594122409820557e-01
    z[6,3,4]  R1987     -2.8605180978775024e-01
    z[6,3,4]  R1988     -1.5274184942245483e-01
    z[6,3,4]  R1989     -1.1104546487331390e-01
    z[6,3,4]  R1990     -2.5291544198989868e-01
    z[6,3,4]  R1991     8.7573297321796417e-02
    z[6,3,4]  R1992     0.0885215625166893
    z[6,3,4]  R1993     -1.4982230961322784e-01
    z[6,3,4]  R1994     2.2073255851864815e-02
    z[6,3,4]  R1995     -9.8633743822574615e-02
    z[6,3,4]  R1996     -1.6097214818000793e-01
    z[6,3,4]  R1997     -3.5569289326667786e-01
    z[6,3,4]  R1998     3.1154308468103409e-02
    z[6,3,4]  R1999     -1.8996725976467133e-01
    z[6,3,4]  R2000     7.9639393091201782e-01
    z[6,3,4]  R2001     8.2627013325691223e-03
    z[6,3,4]  R2002     2.2096820175647736e-01
    z[6,3,4]  R2003     3.2409203052520752e-01
    z[6,3,4]  R2004     2.6137617230415344e-01
    z[6,3,4]  R2005     -4.2287570238113403e-01
    z[6,3,4]  R2006     -2.0530524849891663e-01
    z[6,3,4]  R2007     -5.1775805652141571e-02
    z[6,3,4]  R2008     0.721405565738678
    z[6,3,4]  R2009     3.3904662728309631e-01
    z[6,3,4]  R2010     0.536944568157196
    z[6,3,4]  R2011     5.3472465276718140e-01
    z[6,3,4]  R2012     3.1423911452293396e-01
    z[6,3,4]  R2013     3.7826636433601379e-01
    z[6,3,4]  R2014     -1.6794683039188385e-01
    z[6,3,4]  R2015     2.4229032918810844e-02
    z[6,3,4]  R2016     2.3647651076316833e-01
    z[6,3,4]  R2017     5.2013982087373734e-02
    z[6,3,4]  R2018     3.5284776240587234e-02
    z[6,3,4]  R2019     4.6251362562179565e-01
    z[6,3,4]  R2020     3.9560711383819580e-01
    z[6,3,4]  R2021     -1.7187000811100006e-01
    z[6,3,4]  R2022     8.7326399981975555e-02
    z[6,3,4]  R2023     3.7959685921669006e-01
    z[6,3,4]  R2024     2.2575959563255310e-01
    z[6,3,4]  R2025     4.5889419317245483e-01
    z[6,3,4]  R2026     -3.0037787556648254e-01
    z[6,3,4]  R2027     1.6902795433998108e-01
    z[6,3,4]  R2028     4.5079541206359863e-01
    z[6,3,4]  R2029     2.2691859304904938e-01
    z[6,3,4]  R2030     5.3960567712783813e-01
    z[6,3,4]  R2031     1.1950118094682693e-01
    z[6,3,4]  R2032     -0.562481164932251
    z[6,3,4]  R2033     4.0394267439842224e-01
    z[6,3,4]  R2034     -1.9072486320510507e-03
    z[6,3,4]  R2035     0.494154691696167
    z[6,3,4]  R2036     -1.9802886247634888e-01
    z[6,3,4]  R2037     2.0406669378280640e-01
    z[6,3,4]  R2038     3.5650530457496643e-01
    z[6,3,4]  R2039     -3.6467918753623962e-01
    z[6,3,4]  R2040     -8.4266647696495056e-02
    z[6,3,4]  R2041     -4.7175593674182892e-02
    z[6,3,4]  R2042     -1.6847534105181694e-02
    z[6,3,4]  R2043     5.5132389068603516e-01
    z[6,3,4]  R2044     0.340406596660614
    z[6,3,4]  R2045     1.7809723317623138e-01
    z[6,3,4]  R2046     -2.5065923109650612e-02
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1934     -1
    z[6,3,5]  R1935     1
    z[6,3,5]  R1938     2.0146530866622925e-01
    z[6,3,5]  R1939     1.3990907371044159e-01
    z[6,3,5]  R1940     3.3354374766349792e-01
    z[6,3,5]  R1941     3.0304759740829468e-01
    z[6,3,5]  R1942     3.3876052498817444e-01
    z[6,3,5]  R1943     3.4586733579635620e-01
    z[6,3,5]  R1944     2.0835934579372406e-01
    z[6,3,5]  R1945     2.6599800586700439e-01
    z[6,3,5]  R1946     4.1952362656593323e-01
    z[6,3,5]  R1947     4.9756024032831192e-02
    z[6,3,5]  R1948     -1.2804748117923737e-01
    z[6,3,5]  R1949     5.2556627988815308e-01
    z[6,3,5]  R1950     -1.1099065840244293e-01
    z[6,3,5]  R1951     -5.7539731264114380e-02
    z[6,3,5]  R1952     -2.8323435783386230e-01
    z[6,3,5]  R1953     -1.1019649356603622e-01
    z[6,3,5]  R1954     3.2817018032073975e-01
    z[6,3,5]  R1955     -1.2396162748336792e-01
    z[6,3,5]  R1956     -1.2915004789829254e-01
    z[6,3,5]  R1957     -2.5686267018318176e-01
    z[6,3,5]  R1958     -3.6452582478523254e-01
    z[6,3,5]  R1959     5.6535284966230392e-02
    z[6,3,5]  R1960     4.9025887250900269e-01
    z[6,3,5]  R1961     -2.7779844403266907e-01
    z[6,3,5]  R1962     6.3344120979309082e-01
    z[6,3,5]  R1963     6.5751016139984131e-01
    z[6,3,5]  R1964     -6.4349383115768433e-02
    z[6,3,5]  R1965     -1.0267642885446548e-01
    z[6,3,5]  R1966     7.5395655632019043e-01
    z[6,3,5]  R1967     -2.2027517855167389e-01
    z[6,3,5]  R1968     -1.9749562442302704e-01
    z[6,3,5]  R1969     1.4104568958282471e-01
    z[6,3,5]  R1970     -8.9955426752567291e-02
    z[6,3,5]  R1971     1.8768961727619171e-01
    z[6,3,5]  R1972     -4.1778244078159332e-02
    z[6,3,5]  R1973     -2.9994806647300720e-01
    z[6,3,5]  R1974     -1.2022332102060318e-01
    z[6,3,5]  R1975     -1.8738360702991486e-01
    z[6,3,5]  R1976     1.8032878637313843e-01
    z[6,3,5]  R1977     -1.3821698725223541e-01
    z[6,3,5]  R1978     -2.7438384294509888e-01
    z[6,3,5]  R1979     1.9655370712280273e-01
    z[6,3,5]  R1980     9.9414110183715820e-02
    z[6,3,5]  R1981     1.8051995337009430e-01
    z[6,3,5]  R1982     1.2213288247585297e-01
    z[6,3,5]  R1983     -8.3527758717536926e-02
    z[6,3,5]  R1984     -2.8987939003854990e-03
    z[6,3,5]  R1985     -3.8450825214385986e-01
    z[6,3,5]  R1986     -1.7510086297988892e-01
    z[6,3,5]  R1987     0.253398597240448
    z[6,3,5]  R1988     0.00825007539242506
    z[6,3,5]  R1989     4.9329242110252380e-01
    z[6,3,5]  R1990     4.4502985477447510e-01
    z[6,3,5]  R1991     -1.3583134859800339e-02
    z[6,3,5]  R1992     5.4998189210891724e-02
    z[6,3,5]  R1993     2.7247005701065063e-01
    z[6,3,5]  R1994     1.1730955541133881e-01
    z[6,3,5]  R1995     4.0171834826469421e-01
    z[6,3,5]  R1996     3.2744646072387695e-01
    z[6,3,5]  R1997     0.0937584787607193
    z[6,3,5]  R1998     1.3725067675113678e-01
    z[6,3,5]  R1999     3.8609090447425842e-01
    z[6,3,5]  R2000     -4.2861010879278183e-02
    z[6,3,5]  R2001     -2.5508111715316772e-01
    z[6,3,5]  R2002     -4.9958512187004089e-02
    z[6,3,5]  R2003     0.0769592747092247
    z[6,3,5]  R2004     -1.3457165658473969e-01
    z[6,3,5]  R2005     2.4149735271930695e-01
    z[6,3,5]  R2006     1.6522608697414398e-01
    z[6,3,5]  R2007     4.5957455039024353e-01
    z[6,3,5]  R2008     -1.4389362931251526e-01
    z[6,3,5]  R2009     1.6535639762878418e-01
    z[6,3,5]  R2010     3.1621418893337250e-02
    z[6,3,5]  R2011     -1.0094086080789566e-01
    z[6,3,5]  R2012     0.306438684463501
    z[6,3,5]  R2013     4.3003073334693909e-01
    z[6,3,5]  R2014     5.4396629333496094e-01
    z[6,3,5]  R2015     6.4435862004756927e-02
    z[6,3,5]  R2016     3.2721394300460815e-01
    z[6,3,5]  R2017     -2.8444245457649231e-01
    z[6,3,5]  R2018     -5.0231266021728516e-01
    z[6,3,5]  R2019     -6.2959247827529907e-01
    z[6,3,5]  R2020     3.7279227375984192e-01
    z[6,3,5]  R2021     1.6531041264533997e-01
    z[6,3,5]  R2022     -1.9833190739154816e-01
    z[6,3,5]  R2023     -1.8671898543834686e-01
    z[6,3,5]  R2024     2.3983092606067657e-01
    z[6,3,5]  R2025     9.2646442353725433e-02
    z[6,3,5]  R2026     3.4028777480125427e-01
    z[6,3,5]  R2027     4.1649112105369568e-01
    z[6,3,5]  R2028     8.1165522336959839e-02
    z[6,3,5]  R2029     1.4363476634025574e-01
    z[6,3,5]  R2030     1.0789851844310760e-01
    z[6,3,5]  R2031     -2.3141042888164520e-01
    z[6,3,5]  R2032     -1.7139554023742676e-02
    z[6,3,5]  R2033     -0.318229079246521
    z[6,3,5]  R2034     2.6526167988777161e-01
    z[6,3,5]  R2035     -2.1993994712829590e-01
    z[6,3,5]  R2036     1.5587139129638672e-01
    z[6,3,5]  R2037     3.8067254424095154e-01
    z[6,3,5]  R2038     3.0121762305498123e-02
    z[6,3,5]  R2039     5.5897551774978638e-01
    z[6,3,5]  R2040     2.1398428082466125e-01
    z[6,3,5]  R2041     3.8329538702964783e-01
    z[6,3,5]  R2042     2.9617869853973389e-01
    z[6,3,5]  R2043     0.158024862408638
    z[6,3,5]  R2044     -2.8970161080360413e-01
    z[6,3,5]  R2045     3.5380387306213379e-01
    z[6,3,5]  R2046     3.3629050850868225e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1936     -1
    z[6,3,6]  R1937     1
    z[6,3,6]  R1938     2.9068502783775330e-01
    z[6,3,6]  R1939     2.8227454423904419e-01
    z[6,3,6]  R1940     1.7670619487762451e-01
    z[6,3,6]  R1941     -1.1906898766756058e-01
    z[6,3,6]  R1942     -1.2550881505012512e-01
    z[6,3,6]  R1943     -5.1650381088256836e-01
    z[6,3,6]  R1944     -4.2562881112098694e-01
    z[6,3,6]  R1945     0.447286456823349
    z[6,3,6]  R1946     -2.2831052541732788e-02
    z[6,3,6]  R1947     -1.1260929703712463e-01
    z[6,3,6]  R1948     1.2358459830284119e-01
    z[6,3,6]  R1949     0.00592637388035655
    z[6,3,6]  R1950     -1.7166891694068909e-01
    z[6,3,6]  R1951     6.7347057163715363e-02
    z[6,3,6]  R1952     5.3730695508420467e-03
    z[6,3,6]  R1953     -7.0308116264641285e-03
    z[6,3,6]  R1954     -2.6035559177398682e-01
    z[6,3,6]  R1955     -5.4442346096038818e-02
    z[6,3,6]  R1956     -2.9928541183471680e-01
    z[6,3,6]  R1957     -4.4294662773609161e-02
    z[6,3,6]  R1958     3.9246085286140442e-01
    z[6,3,6]  R1959     5.1586157083511353e-01
    z[6,3,6]  R1960     6.9776542484760284e-02
    z[6,3,6]  R1961     2.9474783688783646e-02
    z[6,3,6]  R1962     -8.5204273462295532e-02
    z[6,3,6]  R1963     1.3028287887573242e-01
    z[6,3,6]  R1964     -6.7805522680282593e-01
    z[6,3,6]  R1965     -6.6481471061706543e-01
    z[6,3,6]  R1966     0.299459844827652
    z[6,3,6]  R1967     -1.1630912870168686e-01
    z[6,3,6]  R1968     -2.8347286581993103e-01
    z[6,3,6]  R1969     -4.8547599464654922e-02
    z[6,3,6]  R1970     3.9975982904434204e-01
    z[6,3,6]  R1971     -6.5692657232284546e-01
    z[6,3,6]  R1972     -6.9269323348999023e-01
    z[6,3,6]  R1973     1.5495055913925171e-01
    z[6,3,6]  R1974     4.4680300354957581e-01
    z[6,3,6]  R1975     7.6224094629287720e-01
    z[6,3,6]  R1976     -6.8241044878959656e-02
    z[6,3,6]  R1977     8.2412803173065186e-01
    z[6,3,6]  R1978     -9.0920627117156982e-02
    z[6,3,6]  R1979     -1.1257733404636383e-01
    z[6,3,6]  R1980     -1.5459421277046204e-01
    z[6,3,6]  R1981     -3.3619552850723267e-01
    z[6,3,6]  R1982     -7.4777096509933472e-02
    z[6,3,6]  R1983     2.9738730192184448e-01
    z[6,3,6]  R1984     4.5432859659194946e-01
    z[6,3,6]  R1985     3.5045480728149414e-01
    z[6,3,6]  R1986     -0.0526314415037632
    z[6,3,6]  R1987     2.6307487487792969e-01
    z[6,3,6]  R1988     6.2678828835487366e-02
    z[6,3,6]  R1989     -3.8197159767150879e-02
    z[6,3,6]  R1990     9.3276090919971466e-02
    z[6,3,6]  R1991     -2.4080686271190643e-02
    z[6,3,6]  R1992     -1.4493295550346375e-01
    z[6,3,6]  R1993     3.5655535757541656e-02
    z[6,3,6]  R1994     0.0522799976170063
    z[6,3,6]  R1995     3.2310735434293747e-02
    z[6,3,6]  R1996     8.5448555648326874e-02
    z[6,3,6]  R1997     1.2455178052186966e-01
    z[6,3,6]  R1998     1.9001878798007965e-01
    z[6,3,6]  R1999     -5.6835031509399414e-01
    z[6,3,6]  R2000     -3.0935180187225342e-01
    z[6,3,6]  R2001     5.9268784523010254e-01
    z[6,3,6]  R2002     8.0272859334945679e-01
    z[6,3,6]  R2003     -4.1821199655532837e-01
    z[6,3,6]  R2004     5.3628188371658325e-01
    z[6,3,6]  R2005     7.5863644480705261e-02
    z[6,3,6]  R2006     3.7423965334892273e-01
    z[6,3,6]  R2007     7.4497717432677746e-03
    z[6,3,6]  R2008     1.6224814951419830e-01
    z[6,3,6]  R2009     -3.0374118685722351e-01
    z[6,3,6]  R2010     -3.4164834022521973e-01
    z[6,3,6]  R2011     6.2955850362777710e-01
    z[6,3,6]  R2012     3.8678586483001709e-01
    z[6,3,6]  R2013     -1.4108885824680328e-01
    z[6,3,6]  R2014     -2.0895342528820038e-01
    z[6,3,6]  R2015     -1.1328030377626419e-01
    z[6,3,6]  R2016     -0.0601862333714962
    z[6,3,6]  R2017     -2.4160975217819214e-01
    z[6,3,6]  R2018     3.6350575089454651e-01
    z[6,3,6]  R2019     1.0825856775045395e-01
    z[6,3,6]  R2020     -5.4732393473386765e-02
    z[6,3,6]  R2021     3.5946875810623169e-01
    z[6,3,6]  R2022     -2.4727845191955566e-01
    z[6,3,6]  R2023     6.0292577743530273e-01
    z[6,3,6]  R2024     -1.4043906331062317e-01
    z[6,3,6]  R2025     3.4061953425407410e-01
    z[6,3,6]  R2026     -0.281399667263031
    z[6,3,6]  R2027     -5.6827016174793243e-02
    z[6,3,6]  R2028     -3.1062424182891846e-01
    z[6,3,6]  R2029     6.1044901609420776e-01
    z[6,3,6]  R2030     1.9057519733905792e-01
    z[6,3,6]  R2031     6.6493093967437744e-01
    z[6,3,6]  R2032     7.8965082764625549e-02
    z[6,3,6]  R2033     7.5730517506599426e-02
    z[6,3,6]  R2034     1.0132216662168503e-01
    z[6,3,6]  R2035     2.6948660612106323e-01
    z[6,3,6]  R2036     -4.2699408531188965e-01
    z[6,3,6]  R2037     1.2564989924430847e-01
    z[6,3,6]  R2038     1.0915504395961761e-01
    z[6,3,6]  R2039     4.7250889241695404e-02
    z[6,3,6]  R2040     -1.4756020903587341e-01
    z[6,3,6]  R2041     -0.0288847703486681
    z[6,3,6]  R2042     -1.6712214052677155e-01
    z[6,3,6]  R2043     -1.6119672358036041e-01
    z[6,3,6]  R2044     1.5063390135765076e-01
    z[6,3,6]  R2045     1.5044826269149780e-01
    z[6,3,6]  R2046     2.8009437024593353e-02
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R2047     -1
    z[3,7,0]  R2048     1
    z[3,7,0]  R2061     3.7067100405693054e-02
    z[3,7,0]  R2062     3.7179496884346008e-01
    z[3,7,0]  R2063     -4.1181966662406921e-01
    z[3,7,0]  R2064     5.1207607984542847e-01
    z[3,7,0]  R2065     -6.3994753360748291e-01
    z[3,7,0]  R2066     -0.316124826669693
    z[3,7,0]  R2067     -4.0294739603996277e-01
    z[3,7,0]  R2068     5.3729891777038574e-01
    z[3,7,0]  R2069     -4.6869885921478271e-01
    z[3,7,0]  R2070     -4.5559534430503845e-01
    z[3,7,0]  R2071     7.8173793852329254e-02
    z[3,7,0]  R2072     -1.7945900559425354e-01
    z[3,7,0]  R2073     -1.2135547585785389e-03
    z[3,7,0]  R2074     -0.0807340145111084
    z[3,7,0]  R2075     -2.4226111173629761e-01
    z[3,7,0]  R2076     -2.3268264532089233e-01
    z[3,7,0]  R2077     -5.3354259580373764e-02
    z[3,7,0]  R2078     -3.0456345528364182e-02
    z[3,7,0]  R2079     -2.2064997255802155e-01
    z[3,7,0]  R2080     -4.6148531138896942e-02
    z[3,7,0]  R2081     6.5666645765304565e-02
    z[3,7,0]  R2082     -1.9799323379993439e-01
    z[3,7,0]  R2083     3.2701876759529114e-01
    z[3,7,0]  R2084     -1.4233329892158508e-01
    z[3,7,0]  R2085     1.9304735586047173e-02
    z[3,7,0]  R2086     -1.5847027301788330e-01
    z[3,7,0]  R2087     5.3673553466796875e-01
    z[3,7,0]  R2088     3.6323402076959610e-02
    z[3,7,0]  R2089     -3.4531587362289429e-01
    z[3,7,0]  R2090     -1.6749443113803864e-01
    z[3,7,0]  R2091     -2.3113049566745758e-01
    z[3,7,0]  R2092     -4.3012022972106934e-02
    z[3,7,0]  R2093     4.8231253027915955e-01
    z[3,7,0]  R2094     2.5550296530127525e-02
    z[3,7,0]  R2095     -2.0028276741504669e-01
    z[3,7,0]  R2096     -4.8691046237945557e-01
    z[3,7,0]  R2097     -1.2682755291461945e-01
    z[3,7,0]  R2098     2.6874890923500061e-01
    z[3,7,0]  R2099     1.3006573915481567e-01
    z[3,7,0]  R2100     3.6033737659454346e-01
    z[3,7,0]  R2101     5.9692794084548950e-01
    z[3,7,0]  R2102     3.9397379755973816e-01
    z[3,7,0]  R2103     -1.7629776895046234e-01
    z[3,7,0]  R2104     1.2649475038051605e-01
    z[3,7,0]  R2105     5.8065932244062424e-02
    z[3,7,0]  R2106     -2.4579444527626038e-01
    z[3,7,0]  R2107     6.5198093652725220e-02
    z[3,7,0]  R2108     5.4943734407424927e-01
    z[3,7,0]  R2109     -1.5163809061050415e-01
    z[3,7,0]  R2110     -2.2004279494285583e-01
    z[3,7,0]  R2111     -1.1727644503116608e-01
    z[3,7,0]  R2112     1.9039590656757355e-01
    z[3,7,0]  R2113     2.9173459857702255e-02
    z[3,7,0]  R2114     -5.5233038961887360e-02
    z[3,7,0]  R2115     -1.4811183512210846e-01
    z[3,7,0]  R2116     9.3578584492206573e-02
    z[3,7,0]  R2117     -9.8985306918621063e-02
    z[3,7,0]  R2118     -1.3010847568511963e-01
    z[3,7,0]  R2119     1.1820724606513977e-01
    z[3,7,0]  R2120     -2.2255496680736542e-01
    z[3,7,0]  R2121     -1.2191570550203323e-01
    z[3,7,0]  R2122     -3.0332719907164574e-02
    z[3,7,0]  R2123     -8.1705629825592041e-02
    z[3,7,0]  R2124     -3.3933378756046295e-02
    z[3,7,0]  R2125     4.9755383282899857e-02
    z[3,7,0]  R2126     1.3494296371936798e-01
    z[3,7,0]  R2127     0.0110483942553401
    z[3,7,0]  R2128     1.4044113457202911e-01
    z[3,7,0]  R2129     0.590168297290802
    z[3,7,0]  R2130     3.5147759318351746e-01
    z[3,7,0]  R2131     4.0883067995309830e-02
    z[3,7,0]  R2132     2.7442533522844315e-02
    z[3,7,0]  R2133     -2.2505679726600647e-01
    z[3,7,0]  R2134     -1.7047492787241936e-02
    z[3,7,0]  R2135     -3.7297993898391724e-01
    z[3,7,0]  R2136     -2.7726629376411438e-01
    z[3,7,0]  R2137     -3.5951441526412964e-01
    z[3,7,0]  R2138     -9.3873977661132812e-02
    z[3,7,0]  R2139     2.9853138327598572e-01
    z[3,7,0]  R2140     -4.2799907922744751e-01
    z[3,7,0]  R2141     -6.0560190677642822e-01
    z[3,7,0]  R2142     -5.3953188657760620e-01
    z[3,7,0]  R2143     -2.5984960794448853e-01
    z[3,7,0]  R2144     -6.4778298139572144e-01
    z[3,7,0]  R2145     -4.1700929403305054e-01
    z[3,7,0]  R2146     -0.385744571685791
    z[3,7,0]  R2147     -1.8221004307270050e-01
    z[3,7,0]  R2148     -4.7696086764335632e-01
    z[3,7,0]  R2149     -3.6791044473648071e-01
    z[3,7,0]  R2150     -3.4008061885833740e-01
    z[3,7,0]  R2151     -2.2818570956587791e-02
    z[3,7,0]  R2152     3.9294874668121338e-01
    z[3,7,0]  R2153     -3.0102510005235672e-02
    z[3,7,0]  R2154     -0.400037944316864
    z[3,7,0]  R2155     -5.7290811091661453e-02
    z[3,7,0]  R2156     -6.6945418715476990e-02
    z[3,7,0]  R2157     -2.1001422405242920e-01
    z[3,7,0]  R2158     -4.1027206182479858e-01
    z[3,7,0]  R2159     -2.4204806983470917e-01
    z[3,7,0]  R2160     4.5590800046920776e-01
    z[3,7,0]  R2161     6.5800681710243225e-02
    z[3,7,0]  R2162     -6.0763758420944214e-01
    z[3,7,0]  R2163     -3.2962110638618469e-01
    z[3,7,0]  R2164     1.6704581677913666e-01
    z[3,7,0]  R2165     -2.8840294480323792e-01
    z[3,7,0]  R2166     -1.5888524055480957e-01
    z[3,7,0]  R2167     1.8819020688533783e-01
    z[3,7,0]  R2168     -6.0815680772066116e-03
    z[3,7,0]  R2169     -3.5370126366615295e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R2049     -1
    z[3,7,1]  R2050     1
    z[3,7,1]  R2061     6.9367986917495728e-01
    z[3,7,1]  R2062     6.6264796257019043e-01
    z[3,7,1]  R2063     -4.9712666869163513e-01
    z[3,7,1]  R2064     4.0542349219322205e-01
    z[3,7,1]  R2065     -0.443347305059433
    z[3,7,1]  R2066     -5.1285165548324585e-01
    z[3,7,1]  R2067     -0.450613796710968
    z[3,7,1]  R2068     6.5254640579223633e-01
    z[3,7,1]  R2069     -6.2381881475448608e-01
    z[3,7,1]  R2070     7.0405995845794678e-01
    z[3,7,1]  R2071     -9.6634417772293091e-01
    z[3,7,1]  R2072     -8.2638806104660034e-01
    z[3,7,1]  R2073     -8.3274024724960327e-01
    z[3,7,1]  R2074     -9.4393610954284668e-01
    z[3,7,1]  R2075     -8.9501363039016724e-01
    z[3,7,1]  R2076     -8.5856539011001587e-01
    z[3,7,1]  R2077     -9.3438696861267090e-01
    z[3,7,1]  R2078     -8.9354443550109863e-01
    z[3,7,1]  R2079     -8.9741677045822144e-01
    z[3,7,1]  R2080     -8.6780643463134766e-01
    z[3,7,1]  R2081     9.0192121267318726e-01
    z[3,7,1]  R2082     0.6239013671875
    z[3,7,1]  R2083     3.4472694993019104e-01
    z[3,7,1]  R2084     0.70050448179245
    z[3,7,1]  R2085     4.5671561360359192e-01
    z[3,7,1]  R2086     0.627260684967041
    z[3,7,1]  R2087     7.8109733294695616e-04
    z[3,7,1]  R2088     -7.5922125577926636e-01
    z[3,7,1]  R2089     -0.715255618095398
    z[3,7,1]  R2090     -5.2114403247833252e-01
    z[3,7,1]  R2091     7.6005853712558746e-02
    z[3,7,1]  R2092     0.802408754825592
    z[3,7,1]  R2093     -0.0430334135890007
    z[3,7,1]  R2094     4.5041911303997040e-02
    z[3,7,1]  R2095     3.0691778659820557e-01
    z[3,7,1]  R2096     2.6438814401626587e-01
    z[3,7,1]  R2097     -5.6059908866882324e-01
    z[3,7,1]  R2098     -6.6544133424758911e-01
    z[3,7,1]  R2099     -6.2691295146942139e-01
    z[3,7,1]  R2100     -6.3844412565231323e-01
    z[3,7,1]  R2101     1.4414748549461365e-01
    z[3,7,1]  R2102     3.5924646258354187e-01
    z[3,7,1]  R2103     4.2892915010452271e-01
    z[3,7,1]  R2104     7.6178300380706787e-01
    z[3,7,1]  R2105     8.5596400499343872e-01
    z[3,7,1]  R2106     5.7058918476104736e-01
    z[3,7,1]  R2107     0.0888204276561737
    z[3,7,1]  R2108     0.0500313900411129
    z[3,7,1]  R2109     -7.8557604551315308e-01
    z[3,7,1]  R2110     -6.9789052009582520e-01
    z[3,7,1]  R2111     5.8851748704910278e-01
    z[3,7,1]  R2112     3.6812219023704529e-01
    z[3,7,1]  R2113     7.0105659961700439e-01
    z[3,7,1]  R2114     6.9236093759536743e-01
    z[3,7,1]  R2115     7.4410974979400635e-01
    z[3,7,1]  R2116     -7.9978233575820923e-01
    z[3,7,1]  R2117     -6.6857415437698364e-01
    z[3,7,1]  R2118     -7.6604461669921875e-01
    z[3,7,1]  R2119     -8.1263101100921631e-01
    z[3,7,1]  R2120     2.2216621041297913e-01
    z[3,7,1]  R2121     8.7879288196563721e-01
    z[3,7,1]  R2122     6.9568967819213867e-01
    z[3,7,1]  R2123     -7.6769274473190308e-01
    z[3,7,1]  R2124     -0.793660581111908
    z[3,7,1]  R2125     -8.9406061172485352e-01
    z[3,7,1]  R2126     -0.69505375623703
    z[3,7,1]  R2127     -6.0580420494079590e-01
    z[3,7,1]  R2128     -4.4465139508247375e-03
    z[3,7,1]  R2129     1.0688560083508492e-02
    z[3,7,1]  R2130     5.3772604465484619e-01
    z[3,7,1]  R2131     7.2924906015396118e-01
    z[3,7,1]  R2132     9.2543345689773560e-01
    z[3,7,1]  R2133     6.6633814573287964e-01
    z[3,7,1]  R2134     6.6368007659912109e-01
    z[3,7,1]  R2135     0.721071183681488
    z[3,7,1]  R2136     5.9860116243362427e-01
    z[3,7,1]  R2137     4.9381405115127563e-01
    z[3,7,1]  R2138     6.9966787099838257e-01
    z[3,7,1]  R2139     7.3879170417785645e-01
    z[3,7,1]  R2140     -5.5943650007247925e-01
    z[3,7,1]  R2141     -6.1637800931930542e-01
    z[3,7,1]  R2142     -4.9711513519287109e-01
    z[3,7,1]  R2143     -6.9946968555450439e-01
    z[3,7,1]  R2144     -4.3509474396705627e-01
    z[3,7,1]  R2145     -0.527397096157074
    z[3,7,1]  R2146     -6.5380924940109253e-01
    z[3,7,1]  R2147     -3.6172983050346375e-01
    z[3,7,1]  R2148     -6.5000897645950317e-01
    z[3,7,1]  R2149     -4.8431155085563660e-01
    z[3,7,1]  R2150     -8.0435746908187866e-01
    z[3,7,1]  R2151     -8.4212523698806763e-01
    z[3,7,1]  R2152     2.9639837145805359e-01
    z[3,7,1]  R2153     -0.961946427822113
    z[3,7,1]  R2154     -7.6187348365783691e-01
    z[3,7,1]  R2155     -7.0618337392807007e-01
    z[3,7,1]  R2156     -0.890663206577301
    z[3,7,1]  R2157     -7.6029217243194580e-01
    z[3,7,1]  R2158     -8.0137866735458374e-01
    z[3,7,1]  R2159     -7.0838910341262817e-01
    z[3,7,1]  R2160     5.2064180374145508e-01
    z[3,7,1]  R2161     5.1355838775634766e-01
    z[3,7,1]  R2162     4.3847480416297913e-01
    z[3,7,1]  R2163     1.5662458539009094e-01
    z[3,7,1]  R2164     3.8802614808082581e-01
    z[3,7,1]  R2165     -8.2546448707580566e-01
    z[3,7,1]  R2166     -8.1400001049041748e-01
    z[3,7,1]  R2167     -1.3649834692478180e-01
    z[3,7,1]  R2168     -7.3540627956390381e-01
    z[3,7,1]  R2169     -7.2362780570983887e-01
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R2051     -1
    z[3,7,2]  R2052     1
    z[3,7,2]  R2061     3.7445166707038879e-01
    z[3,7,2]  R2062     -2.4146245419979095e-01
    z[3,7,2]  R2063     -6.5644830465316772e-01
    z[3,7,2]  R2064     -1.2594206631183624e-01
    z[3,7,2]  R2065     -5.0185889005661011e-01
    z[3,7,2]  R2066     -3.9556607604026794e-01
    z[3,7,2]  R2067     -4.8620283603668213e-01
    z[3,7,2]  R2068     -5.1303360611200333e-02
    z[3,7,2]  R2069     -1.8828479945659637e-01
    z[3,7,2]  R2070     -1.8435798585414886e-01
    z[3,7,2]  R2071     1.3297490775585175e-01
    z[3,7,2]  R2072     -1.6308559570461512e-03
    z[3,7,2]  R2073     -7.8419208526611328e-02
    z[3,7,2]  R2074     1.8751381337642670e-01
    z[3,7,2]  R2075     1.4740787446498871e-01
    z[3,7,2]  R2076     3.0041760206222534e-01
    z[3,7,2]  R2077     3.2278785109519958e-01
    z[3,7,2]  R2078     1.4655736088752747e-01
    z[3,7,2]  R2079     -4.4597167521715164e-02
    z[3,7,2]  R2080     2.1245136857032776e-01
    z[3,7,2]  R2081     -1.2600612640380859e-01
    z[3,7,2]  R2082     -2.3675315082073212e-01
    z[3,7,2]  R2083     -1.9854129850864410e-01
    z[3,7,2]  R2084     -8.3444461226463318e-02
    z[3,7,2]  R2085     -2.7143913507461548e-01
    z[3,7,2]  R2086     -2.6291960477828979e-01
    z[3,7,2]  R2087     -0.0666758269071579
    z[3,7,2]  R2088     -1.8733938038349152e-01
    z[3,7,2]  R2089     -0.0946456640958786
    z[3,7,2]  R2090     -1.4219684898853302e-01
    z[3,7,2]  R2091     2.4438938498497009e-01
    z[3,7,2]  R2092     -3.3602195978164673e-01
    z[3,7,2]  R2093     -5.1875356584787369e-03
    z[3,7,2]  R2094     2.1833754144608974e-03
    z[3,7,2]  R2095     -2.4139027297496796e-01
    z[3,7,2]  R2096     -1.5233443677425385e-01
    z[3,7,2]  R2097     -4.3736910820007324e-01
    z[3,7,2]  R2098     -2.3348213732242584e-01
    z[3,7,2]  R2099     -4.5843631029129028e-01
    z[3,7,2]  R2100     1.5957817435264587e-01
    z[3,7,2]  R2101     2.9598847031593323e-01
    z[3,7,2]  R2102     2.7041327953338623e-01
    z[3,7,2]  R2103     -2.4659752845764160e-01
    z[3,7,2]  R2104     -4.6603524684906006e-01
    z[3,7,2]  R2105     -0.0762200802564621
    z[3,7,2]  R2106     2.4485167115926743e-02
    z[3,7,2]  R2107     2.6378279551863670e-02
    z[3,7,2]  R2108     -3.3334141969680786e-01
    z[3,7,2]  R2109     -9.0231351554393768e-02
    z[3,7,2]  R2110     -3.5453933477401733e-01
    z[3,7,2]  R2111     4.3191414326429367e-02
    z[3,7,2]  R2112     -0.341232031583786
    z[3,7,2]  R2113     -4.0100088715553284e-01
    z[3,7,2]  R2114     -7.8620567917823792e-02
    z[3,7,2]  R2115     -1.0464297980070114e-01
    z[3,7,2]  R2116     -2.4717628955841064e-01
    z[3,7,2]  R2117     -3.3976930379867554e-01
    z[3,7,2]  R2118     -1.2700571119785309e-01
    z[3,7,2]  R2119     1.9309714436531067e-01
    z[3,7,2]  R2120     7.5070065259933472e-01
    z[3,7,2]  R2121     -2.0854748785495758e-01
    z[3,7,2]  R2122     2.2803038358688354e-01
    z[3,7,2]  R2123     -1.6927412152290344e-01
    z[3,7,2]  R2124     -3.2806521654129028e-01
    z[3,7,2]  R2125     7.4264849536120892e-03
    z[3,7,2]  R2126     -2.3701396584510803e-01
    z[3,7,2]  R2127     1.0115970671176910e-01
    z[3,7,2]  R2128     0.692564845085144
    z[3,7,2]  R2129     3.3201807737350464e-01
    z[3,7,2]  R2130     -4.1262698173522949e-01
    z[3,7,2]  R2131     0.0496567003428936
    z[3,7,2]  R2132     4.4755268841981888e-02
    z[3,7,2]  R2133     -1.4815372228622437e-01
    z[3,7,2]  R2134     4.2813235521316528e-01
    z[3,7,2]  R2135     4.5968118309974670e-01
    z[3,7,2]  R2136     4.1569215059280396e-01
    z[3,7,2]  R2137     7.5898277573287487e-03
    z[3,7,2]  R2138     4.0898427367210388e-01
    z[3,7,2]  R2139     1.3869714736938477e-01
    z[3,7,2]  R2140     -5.3591018915176392e-01
    z[3,7,2]  R2141     -2.2801041603088379e-01
    z[3,7,2]  R2142     -0.516657292842865
    z[3,7,2]  R2143     -4.0650996565818787e-01
    z[3,7,2]  R2144     -5.9381824731826782e-01
    z[3,7,2]  R2145     -2.7623388171195984e-01
    z[3,7,2]  R2146     -5.0986176729202271e-01
    z[3,7,2]  R2147     -6.9064414501190186e-01
    z[3,7,2]  R2148     -4.5217093825340271e-01
    z[3,7,2]  R2149     -0.56244957447052
    z[3,7,2]  R2150     1.9406144320964813e-01
    z[3,7,2]  R2151     2.8965404629707336e-01
    z[3,7,2]  R2152     3.4909170120954514e-02
    z[3,7,2]  R2153     6.5579958260059357e-02
    z[3,7,2]  R2154     3.9618015289306641e-01
    z[3,7,2]  R2155     -2.8757303953170776e-01
    z[3,7,2]  R2156     1.5739649534225464e-01
    z[3,7,2]  R2157     4.0723752975463867e-01
    z[3,7,2]  R2158     3.6946651339530945e-01
    z[3,7,2]  R2159     2.5820541381835938e-01
    z[3,7,2]  R2160     0.0326387919485569
    z[3,7,2]  R2161     6.7335285246372223e-02
    z[3,7,2]  R2162     2.7764764428138733e-01
    z[3,7,2]  R2163     5.3151077032089233e-01
    z[3,7,2]  R2164     -2.2476732730865479e-01
    z[3,7,2]  R2165     1.9603857398033142e-01
    z[3,7,2]  R2166     -3.0395476147532463e-02
    z[3,7,2]  R2167     1.5812179446220398e-01
    z[3,7,2]  R2168     -1.8200913071632385e-01
    z[3,7,2]  R2169     7.9307332634925842e-03
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R2053     -1
    z[3,7,3]  R2054     1
    z[3,7,3]  R2061     4.9024832248687744e-01
    z[3,7,3]  R2062     5.2322983741760254e-01
    z[3,7,3]  R2063     -2.6184621453285217e-01
    z[3,7,3]  R2064     5.5958682298660278e-01
    z[3,7,3]  R2065     6.1362501233816147e-02
    z[3,7,3]  R2066     -4.5997259020805359e-01
    z[3,7,3]  R2067     -1.9809435307979584e-01
    z[3,7,3]  R2068     -0.0729481503367424
    z[3,7,3]  R2069     -1.1497498303651810e-01
    z[3,7,3]  R2070     2.1794460713863373e-01
    z[3,7,3]  R2071     -1.2271368503570557e-01
    z[3,7,3]  R2072     -1.6657491028308868e-01
    z[3,7,3]  R2073     -1.7226240038871765e-01
    z[3,7,3]  R2074     -2.4263501167297363e-01
    z[3,7,3]  R2075     -2.9438859224319458e-01
    z[3,7,3]  R2076     -1.4323222637176514e-01
    z[3,7,3]  R2077     5.3854927420616150e-02
    z[3,7,3]  R2078     8.3793297410011292e-02
    z[3,7,3]  R2079     5.9439826756715775e-02
    z[3,7,3]  R2080     2.2096496820449829e-01
    z[3,7,3]  R2081     -3.3231475949287415e-01
    z[3,7,3]  R2082     8.5544362664222717e-02
    z[3,7,3]  R2083     5.4995030164718628e-02
    z[3,7,3]  R2084     -2.5623863935470581e-01
    z[3,7,3]  R2085     1.4718367159366608e-01
    z[3,7,3]  R2086     -4.7586208581924438e-01
    z[3,7,3]  R2087     5.7744556665420532e-01
    z[3,7,3]  R2088     -3.7982547283172607e-01
    z[3,7,3]  R2089     -3.8820537924766541e-01
    z[3,7,3]  R2090     -6.8278080224990845e-01
    z[3,7,3]  R2091     5.6001764535903931e-01
    z[3,7,3]  R2092     -8.2615956664085388e-02
    z[3,7,3]  R2093     5.9955221414566040e-01
    z[3,7,3]  R2094     5.5213242769241333e-01
    z[3,7,3]  R2095     6.8202984333038330e-01
    z[3,7,3]  R2096     0.567356526851654
    z[3,7,3]  R2097     -3.3254262804985046e-01
    z[3,7,3]  R2098     -6.4255464076995850e-01
    z[3,7,3]  R2099     -4.6182984113693237e-01
    z[3,7,3]  R2100     -5.4322427511215210e-01
    z[3,7,3]  R2101     3.8676840066909790e-01
    z[3,7,3]  R2102     -1.4344982802867889e-01
    z[3,7,3]  R2103     6.5242147445678711e-01
    z[3,7,3]  R2104     -2.0302671939134598e-02
    z[3,7,3]  R2105     -3.8734534382820129e-01
    z[3,7,3]  R2106     2.6633885502815247e-01
    z[3,7,3]  R2107     9.2679816484451294e-01
    z[3,7,3]  R2108     4.9930948019027710e-01
    z[3,7,3]  R2109     -2.5792637467384338e-01
    z[3,7,3]  R2110     -3.6546853184700012e-01
    z[3,7,3]  R2111     5.7596552371978760e-01
    z[3,7,3]  R2112     5.1674467325210571e-01
    z[3,7,3]  R2113     8.7929308414459229e-02
    z[3,7,3]  R2114     3.7946559488773346e-02
    z[3,7,3]  R2115     -3.0083081126213074e-01
    z[3,7,3]  R2116     -1.4255067706108093e-01
    z[3,7,3]  R2117     -5.8918052911758423e-01
    z[3,7,3]  R2118     -1.2219463288784027e-01
    z[3,7,3]  R2119     2.0624296367168427e-01
    z[3,7,3]  R2120     -3.6771920323371887e-01
    z[3,7,3]  R2121     1.7160816490650177e-01
    z[3,7,3]  R2122     -1.2418014556169510e-01
    z[3,7,3]  R2123     -5.4831933975219727e-01
    z[3,7,3]  R2124     -3.3369067311286926e-01
    z[3,7,3]  R2125     2.8668698668479919e-01
    z[3,7,3]  R2126     -2.9597437381744385e-01
    z[3,7,3]  R2127     -6.3257539272308350e-01
    z[3,7,3]  R2128     -0.566639244556427
    z[3,7,3]  R2129     -6.5333527326583862e-01
    z[3,7,3]  R2130     4.5000296831130981e-01
    z[3,7,3]  R2131     6.3621246814727783e-01
    z[3,7,3]  R2132     -1.7492806538939476e-02
    z[3,7,3]  R2133     2.7972223237156868e-02
    z[3,7,3]  R2134     3.7851759791374207e-01
    z[3,7,3]  R2135     1.3253663666546345e-02
    z[3,7,3]  R2136     4.3476754426956177e-01
    z[3,7,3]  R2137     4.7934412956237793e-01
    z[3,7,3]  R2138     1.6339744627475739e-01
    z[3,7,3]  R2139     4.8957455158233643e-01
    z[3,7,3]  R2140     -1.4709731936454773e-01
    z[3,7,3]  R2141     -2.5882723927497864e-01
    z[3,7,3]  R2142     -2.1688246726989746e-01
    z[3,7,3]  R2143     -4.6647912263870239e-01
    z[3,7,3]  R2144     -8.3207428455352783e-02
    z[3,7,3]  R2145     -5.6877774000167847e-01
    z[3,7,3]  R2146     -3.0903410911560059e-01
    z[3,7,3]  R2147     -4.6563339233398438e-01
    z[3,7,3]  R2148     -3.3741500973701477e-01
    z[3,7,3]  R2149     -5.4462337493896484e-01
    z[3,7,3]  R2150     -1.7232039570808411e-01
    z[3,7,3]  R2151     -2.1759833395481110e-01
    z[3,7,3]  R2152     -6.5985542535781860e-01
    z[3,7,3]  R2153     2.0762298256158829e-02
    z[3,7,3]  R2154     -7.8155420720577240e-02
    z[3,7,3]  R2155     -0.406417578458786
    z[3,7,3]  R2156     6.5221287310123444e-02
    z[3,7,3]  R2157     0.0881512239575386
    z[3,7,3]  R2158     1.3524082303047180e-01
    z[3,7,3]  R2159     -2.6688039302825928e-01
    z[3,7,3]  R2160     0.33226278424263
    z[3,7,3]  R2161     3.9146417379379272e-01
    z[3,7,3]  R2162     -8.0085076391696930e-02
    z[3,7,3]  R2163     1.9872041046619415e-01
    z[3,7,3]  R2164     -4.8493242263793945e-01
    z[3,7,3]  R2165     -4.0307980775833130e-01
    z[3,7,3]  R2166     -4.5969793200492859e-01
    z[3,7,3]  R2167     7.2684627771377563e-01
    z[3,7,3]  R2168     -6.3669097423553467e-01
    z[3,7,3]  R2169     -0.288517564535141
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R2055     -1
    z[3,7,4]  R2056     1
    z[3,7,4]  R2061     -2.3091910779476166e-01
    z[3,7,4]  R2062     -1.9820597767829895e-01
    z[3,7,4]  R2063     -0.223605215549469
    z[3,7,4]  R2064     -3.1431868672370911e-01
    z[3,7,4]  R2065     -3.4318295121192932e-01
    z[3,7,4]  R2066     -4.1663515567779541e-01
    z[3,7,4]  R2067     -3.9054206013679504e-01
    z[3,7,4]  R2068     -8.2912124693393707e-02
    z[3,7,4]  R2069     -5.5594122409820557e-01
    z[3,7,4]  R2070     -2.8605180978775024e-01
    z[3,7,4]  R2071     -1.5274184942245483e-01
    z[3,7,4]  R2072     -1.1104546487331390e-01
    z[3,7,4]  R2073     -2.5291544198989868e-01
    z[3,7,4]  R2074     8.7573297321796417e-02
    z[3,7,4]  R2075     0.0885215625166893
    z[3,7,4]  R2076     -1.4982230961322784e-01
    z[3,7,4]  R2077     2.2073255851864815e-02
    z[3,7,4]  R2078     -9.8633743822574615e-02
    z[3,7,4]  R2079     -1.6097214818000793e-01
    z[3,7,4]  R2080     -3.5569289326667786e-01
    z[3,7,4]  R2081     3.1154308468103409e-02
    z[3,7,4]  R2082     -1.8996725976467133e-01
    z[3,7,4]  R2083     7.9639393091201782e-01
    z[3,7,4]  R2084     8.2627013325691223e-03
    z[3,7,4]  R2085     2.2096820175647736e-01
    z[3,7,4]  R2086     3.2409203052520752e-01
    z[3,7,4]  R2087     2.6137617230415344e-01
    z[3,7,4]  R2088     -4.2287570238113403e-01
    z[3,7,4]  R2089     -2.0530524849891663e-01
    z[3,7,4]  R2090     -5.1775805652141571e-02
    z[3,7,4]  R2091     0.721405565738678
    z[3,7,4]  R2092     3.3904662728309631e-01
    z[3,7,4]  R2093     0.536944568157196
    z[3,7,4]  R2094     5.3472465276718140e-01
    z[3,7,4]  R2095     3.1423911452293396e-01
    z[3,7,4]  R2096     3.7826636433601379e-01
    z[3,7,4]  R2097     -1.6794683039188385e-01
    z[3,7,4]  R2098     2.4229032918810844e-02
    z[3,7,4]  R2099     2.3647651076316833e-01
    z[3,7,4]  R2100     5.2013982087373734e-02
    z[3,7,4]  R2101     3.5284776240587234e-02
    z[3,7,4]  R2102     4.6251362562179565e-01
    z[3,7,4]  R2103     3.9560711383819580e-01
    z[3,7,4]  R2104     -1.7187000811100006e-01
    z[3,7,4]  R2105     8.7326399981975555e-02
    z[3,7,4]  R2106     3.7959685921669006e-01
    z[3,7,4]  R2107     2.2575959563255310e-01
    z[3,7,4]  R2108     4.5889419317245483e-01
    z[3,7,4]  R2109     -3.0037787556648254e-01
    z[3,7,4]  R2110     1.6902795433998108e-01
    z[3,7,4]  R2111     4.5079541206359863e-01
    z[3,7,4]  R2112     2.2691859304904938e-01
    z[3,7,4]  R2113     5.3960567712783813e-01
    z[3,7,4]  R2114     1.1950118094682693e-01
    z[3,7,4]  R2115     -0.562481164932251
    z[3,7,4]  R2116     4.0394267439842224e-01
    z[3,7,4]  R2117     -1.9072486320510507e-03
    z[3,7,4]  R2118     0.494154691696167
    z[3,7,4]  R2119     -1.9802886247634888e-01
    z[3,7,4]  R2120     2.0406669378280640e-01
    z[3,7,4]  R2121     3.5650530457496643e-01
    z[3,7,4]  R2122     -3.6467918753623962e-01
    z[3,7,4]  R2123     -8.4266647696495056e-02
    z[3,7,4]  R2124     -4.7175593674182892e-02
    z[3,7,4]  R2125     -1.6847534105181694e-02
    z[3,7,4]  R2126     5.5132389068603516e-01
    z[3,7,4]  R2127     0.340406596660614
    z[3,7,4]  R2128     1.7809723317623138e-01
    z[3,7,4]  R2129     -2.5065923109650612e-02
    z[3,7,4]  R2130     1.3001147657632828e-02
    z[3,7,4]  R2131     -8.7179347872734070e-02
    z[3,7,4]  R2132     1.6161532700061798e-01
    z[3,7,4]  R2133     2.5822514295578003e-01
    z[3,7,4]  R2134     -2.0004893839359283e-01
    z[3,7,4]  R2135     -2.4194066226482391e-01
    z[3,7,4]  R2136     2.6647615432739258e-01
    z[3,7,4]  R2137     -7.0569347590208054e-03
    z[3,7,4]  R2138     -0.457533061504364
    z[3,7,4]  R2139     2.6290962100028992e-01
    z[3,7,4]  R2140     -4.0289908647537231e-01
    z[3,7,4]  R2141     -3.5442799329757690e-01
    z[3,7,4]  R2142     -1.9329233467578888e-01
    z[3,7,4]  R2143     -2.1037788689136505e-01
    z[3,7,4]  R2144     -6.5850298851728439e-03
    z[3,7,4]  R2145     -3.7085208296775818e-01
    z[3,7,4]  R2146     6.4554825425148010e-02
    z[3,7,4]  R2147     -3.6159214377403259e-01
    z[3,7,4]  R2148     5.0317924469709396e-02
    z[3,7,4]  R2149     2.5089766830205917e-02
    z[3,7,4]  R2150     3.2245415449142456e-01
    z[3,7,4]  R2151     2.0978122949600220e-01
    z[3,7,4]  R2152     -4.8044338822364807e-01
    z[3,7,4]  R2153     -2.4499568343162537e-01
    z[3,7,4]  R2154     2.1332244575023651e-01
    z[3,7,4]  R2155     2.6873627305030823e-01
    z[3,7,4]  R2156     4.2627118527889252e-03
    z[3,7,4]  R2157     4.1220989823341370e-01
    z[3,7,4]  R2158     1.0254800319671631e-01
    z[3,7,4]  R2159     -3.0259862542152405e-01
    z[3,7,4]  R2160     4.2819178104400635e-01
    z[3,7,4]  R2161     -0.486828088760376
    z[3,7,4]  R2162     1.7520861327648163e-01
    z[3,7,4]  R2163     6.8648862838745117e-01
    z[3,7,4]  R2164     -5.6398731470108032e-01
    z[3,7,4]  R2165     2.6229554787278175e-02
    z[3,7,4]  R2166     2.8796127438545227e-01
    z[3,7,4]  R2167     3.1456348299980164e-01
    z[3,7,4]  R2168     -4.3707441538572311e-02
    z[3,7,4]  R2169     -4.1453507542610168e-01
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R2057     -1
    z[3,7,5]  R2058     1
    z[3,7,5]  R2061     -2.7438384294509888e-01
    z[3,7,5]  R2062     1.9655370712280273e-01
    z[3,7,5]  R2063     9.9414110183715820e-02
    z[3,7,5]  R2064     1.8051995337009430e-01
    z[3,7,5]  R2065     1.2213288247585297e-01
    z[3,7,5]  R2066     -8.3527758717536926e-02
    z[3,7,5]  R2067     -2.8987939003854990e-03
    z[3,7,5]  R2068     -3.8450825214385986e-01
    z[3,7,5]  R2069     -1.7510086297988892e-01
    z[3,7,5]  R2070     0.253398597240448
    z[3,7,5]  R2071     0.00825007539242506
    z[3,7,5]  R2072     4.9329242110252380e-01
    z[3,7,5]  R2073     4.4502985477447510e-01
    z[3,7,5]  R2074     -1.3583134859800339e-02
    z[3,7,5]  R2075     5.4998189210891724e-02
    z[3,7,5]  R2076     2.7247005701065063e-01
    z[3,7,5]  R2077     1.1730955541133881e-01
    z[3,7,5]  R2078     4.0171834826469421e-01
    z[3,7,5]  R2079     3.2744646072387695e-01
    z[3,7,5]  R2080     0.0937584787607193
    z[3,7,5]  R2081     1.3725067675113678e-01
    z[3,7,5]  R2082     3.8609090447425842e-01
    z[3,7,5]  R2083     -4.2861010879278183e-02
    z[3,7,5]  R2084     -2.5508111715316772e-01
    z[3,7,5]  R2085     -4.9958512187004089e-02
    z[3,7,5]  R2086     0.0769592747092247
    z[3,7,5]  R2087     -1.3457165658473969e-01
    z[3,7,5]  R2088     2.4149735271930695e-01
    z[3,7,5]  R2089     1.6522608697414398e-01
    z[3,7,5]  R2090     4.5957455039024353e-01
    z[3,7,5]  R2091     -1.4389362931251526e-01
    z[3,7,5]  R2092     1.6535639762878418e-01
    z[3,7,5]  R2093     3.1621418893337250e-02
    z[3,7,5]  R2094     -1.0094086080789566e-01
    z[3,7,5]  R2095     0.306438684463501
    z[3,7,5]  R2096     4.3003073334693909e-01
    z[3,7,5]  R2097     5.4396629333496094e-01
    z[3,7,5]  R2098     6.4435862004756927e-02
    z[3,7,5]  R2099     3.2721394300460815e-01
    z[3,7,5]  R2100     -2.8444245457649231e-01
    z[3,7,5]  R2101     -5.0231266021728516e-01
    z[3,7,5]  R2102     -6.2959247827529907e-01
    z[3,7,5]  R2103     3.7279227375984192e-01
    z[3,7,5]  R2104     1.6531041264533997e-01
    z[3,7,5]  R2105     -1.9833190739154816e-01
    z[3,7,5]  R2106     -1.8671898543834686e-01
    z[3,7,5]  R2107     2.3983092606067657e-01
    z[3,7,5]  R2108     9.2646442353725433e-02
    z[3,7,5]  R2109     3.4028777480125427e-01
    z[3,7,5]  R2110     4.1649112105369568e-01
    z[3,7,5]  R2111     8.1165522336959839e-02
    z[3,7,5]  R2112     1.4363476634025574e-01
    z[3,7,5]  R2113     1.0789851844310760e-01
    z[3,7,5]  R2114     -2.3141042888164520e-01
    z[3,7,5]  R2115     -1.7139554023742676e-02
    z[3,7,5]  R2116     -0.318229079246521
    z[3,7,5]  R2117     2.6526167988777161e-01
    z[3,7,5]  R2118     -2.1993994712829590e-01
    z[3,7,5]  R2119     1.5587139129638672e-01
    z[3,7,5]  R2120     3.8067254424095154e-01
    z[3,7,5]  R2121     3.0121762305498123e-02
    z[3,7,5]  R2122     5.5897551774978638e-01
    z[3,7,5]  R2123     2.1398428082466125e-01
    z[3,7,5]  R2124     3.8329538702964783e-01
    z[3,7,5]  R2125     2.9617869853973389e-01
    z[3,7,5]  R2126     0.158024862408638
    z[3,7,5]  R2127     -2.8970161080360413e-01
    z[3,7,5]  R2128     3.5380387306213379e-01
    z[3,7,5]  R2129     3.3629050850868225e-01
    z[3,7,5]  R2130     -1.0507623106241226e-01
    z[3,7,5]  R2131     -1.3714969158172607e-01
    z[3,7,5]  R2132     1.7076972126960754e-01
    z[3,7,5]  R2133     -8.8459923863410950e-02
    z[3,7,5]  R2134     0.258756548166275
    z[3,7,5]  R2135     -4.9505833536386490e-02
    z[3,7,5]  R2136     4.6881463378667831e-02
    z[3,7,5]  R2137     -3.4698281437158585e-02
    z[3,7,5]  R2138     5.5712736211717129e-03
    z[3,7,5]  R2139     1.3792365789413452e-01
    z[3,7,5]  R2140     8.8033504784107208e-02
    z[3,7,5]  R2141     -9.3164615333080292e-02
    z[3,7,5]  R2142     -1.9087509810924530e-01
    z[3,7,5]  R2143     7.0396237075328827e-02
    z[3,7,5]  R2144     6.9680221378803253e-02
    z[3,7,5]  R2145     1.0128123313188553e-01
    z[3,7,5]  R2146     2.5151568651199341e-01
    z[3,7,5]  R2147     8.0217964947223663e-02
    z[3,7,5]  R2148     -1.5398536622524261e-01
    z[3,7,5]  R2149     -1.0147435218095779e-01
    z[3,7,5]  R2150     -2.5306597352027893e-01
    z[3,7,5]  R2151     1.6864615678787231e-01
    z[3,7,5]  R2152     -1.0216084867715836e-01
    z[3,7,5]  R2153     -8.7392807006835938e-02
    z[3,7,5]  R2154     2.1890738606452942e-01
    z[3,7,5]  R2155     -3.8237354159355164e-01
    z[3,7,5]  R2156     -4.0125495195388794e-01
    z[3,7,5]  R2157     1.8512722849845886e-01
    z[3,7,5]  R2158     -2.5003109127283096e-02
    z[3,7,5]  R2159     -2.5611430406570435e-01
    z[3,7,5]  R2160     -2.9676118493080139e-01
    z[3,7,5]  R2161     -5.1403272151947021e-01
    z[3,7,5]  R2162     -5.5768877267837524e-01
    z[3,7,5]  R2163     -0.166483074426651
    z[3,7,5]  R2164     -3.2608771324157715e-01
    z[3,7,5]  R2165     1.6494846343994141e-01
    z[3,7,5]  R2166     9.2028222978115082e-02
    z[3,7,5]  R2167     0.362809956073761
    z[3,7,5]  R2168     1.2219491600990295e-01
    z[3,7,5]  R2169     1.9462847709655762e-01
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R2059     -1
    z[3,7,6]  R2060     1
    z[3,7,6]  R2061     -9.0920627117156982e-02
    z[3,7,6]  R2062     -1.1257733404636383e-01
    z[3,7,6]  R2063     -1.5459421277046204e-01
    z[3,7,6]  R2064     -3.3619552850723267e-01
    z[3,7,6]  R2065     -7.4777096509933472e-02
    z[3,7,6]  R2066     2.9738730192184448e-01
    z[3,7,6]  R2067     4.5432859659194946e-01
    z[3,7,6]  R2068     3.5045480728149414e-01
    z[3,7,6]  R2069     -0.0526314415037632
    z[3,7,6]  R2070     2.6307487487792969e-01
    z[3,7,6]  R2071     6.2678828835487366e-02
    z[3,7,6]  R2072     -3.8197159767150879e-02
    z[3,7,6]  R2073     9.3276090919971466e-02
    z[3,7,6]  R2074     -2.4080686271190643e-02
    z[3,7,6]  R2075     -1.4493295550346375e-01
    z[3,7,6]  R2076     3.5655535757541656e-02
    z[3,7,6]  R2077     0.0522799976170063
    z[3,7,6]  R2078     3.2310735434293747e-02
    z[3,7,6]  R2079     8.5448555648326874e-02
    z[3,7,6]  R2080     1.2455178052186966e-01
    z[3,7,6]  R2081     1.9001878798007965e-01
    z[3,7,6]  R2082     -5.6835031509399414e-01
    z[3,7,6]  R2083     -3.0935180187225342e-01
    z[3,7,6]  R2084     5.9268784523010254e-01
    z[3,7,6]  R2085     8.0272859334945679e-01
    z[3,7,6]  R2086     -4.1821199655532837e-01
    z[3,7,6]  R2087     5.3628188371658325e-01
    z[3,7,6]  R2088     7.5863644480705261e-02
    z[3,7,6]  R2089     3.7423965334892273e-01
    z[3,7,6]  R2090     7.4497717432677746e-03
    z[3,7,6]  R2091     1.6224814951419830e-01
    z[3,7,6]  R2092     -3.0374118685722351e-01
    z[3,7,6]  R2093     -3.4164834022521973e-01
    z[3,7,6]  R2094     6.2955850362777710e-01
    z[3,7,6]  R2095     3.8678586483001709e-01
    z[3,7,6]  R2096     -1.4108885824680328e-01
    z[3,7,6]  R2097     -2.0895342528820038e-01
    z[3,7,6]  R2098     -1.1328030377626419e-01
    z[3,7,6]  R2099     -0.0601862333714962
    z[3,7,6]  R2100     -2.4160975217819214e-01
    z[3,7,6]  R2101     3.6350575089454651e-01
    z[3,7,6]  R2102     1.0825856775045395e-01
    z[3,7,6]  R2103     -5.4732393473386765e-02
    z[3,7,6]  R2104     3.5946875810623169e-01
    z[3,7,6]  R2105     -2.4727845191955566e-01
    z[3,7,6]  R2106     6.0292577743530273e-01
    z[3,7,6]  R2107     -1.4043906331062317e-01
    z[3,7,6]  R2108     3.4061953425407410e-01
    z[3,7,6]  R2109     -0.281399667263031
    z[3,7,6]  R2110     -5.6827016174793243e-02
    z[3,7,6]  R2111     -3.1062424182891846e-01
    z[3,7,6]  R2112     6.1044901609420776e-01
    z[3,7,6]  R2113     1.9057519733905792e-01
    z[3,7,6]  R2114     6.6493093967437744e-01
    z[3,7,6]  R2115     7.8965082764625549e-02
    z[3,7,6]  R2116     7.5730517506599426e-02
    z[3,7,6]  R2117     1.0132216662168503e-01
    z[3,7,6]  R2118     2.6948660612106323e-01
    z[3,7,6]  R2119     -4.2699408531188965e-01
    z[3,7,6]  R2120     1.2564989924430847e-01
    z[3,7,6]  R2121     1.0915504395961761e-01
    z[3,7,6]  R2122     4.7250889241695404e-02
    z[3,7,6]  R2123     -1.4756020903587341e-01
    z[3,7,6]  R2124     -0.0288847703486681
    z[3,7,6]  R2125     -1.6712214052677155e-01
    z[3,7,6]  R2126     -1.6119672358036041e-01
    z[3,7,6]  R2127     1.5063390135765076e-01
    z[3,7,6]  R2128     1.5044826269149780e-01
    z[3,7,6]  R2129     2.8009437024593353e-02
    z[3,7,6]  R2130     4.5093291997909546e-01
    z[3,7,6]  R2131     1.8133418262004852e-01
    z[3,7,6]  R2132     2.9193994402885437e-01
    z[3,7,6]  R2133     6.3883143663406372e-01
    z[3,7,6]  R2134     -3.5452902317047119e-01
    z[3,7,6]  R2135     2.6167482137680054e-01
    z[3,7,6]  R2136     3.6023595929145813e-01
    z[3,7,6]  R2137     0.629138171672821
    z[3,7,6]  R2138     3.1355720758438110e-01
    z[3,7,6]  R2139     -1.3416926562786102e-01
    z[3,7,6]  R2140     1.5790063142776489e-01
    z[3,7,6]  R2141     6.7301634699106216e-03
    z[3,7,6]  R2142     2.7205497026443481e-01
    z[3,7,6]  R2143     -1.0560656338930130e-01
    z[3,7,6]  R2144     1.6317966580390930e-01
    z[3,7,6]  R2145     -1.8791554495692253e-02
    z[3,7,6]  R2146     2.9086660593748093e-02
    z[3,7,6]  R2147     7.0451624691486359e-02
    z[3,7,6]  R2148     -7.3795504868030548e-02
    z[3,7,6]  R2149     -7.8698962926864624e-02
    z[3,7,6]  R2150     4.4508766382932663e-02
    z[3,7,6]  R2151     -2.9428917169570923e-01
    z[3,7,6]  R2152     -2.8257521986961365e-01
    z[3,7,6]  R2153     3.6888431757688522e-02
    z[3,7,6]  R2154     5.4996378719806671e-02
    z[3,7,6]  R2155     1.7810256779193878e-01
    z[3,7,6]  R2156     -1.1039060354232788e-01
    z[3,7,6]  R2157     6.9044865667819977e-03
    z[3,7,6]  R2158     1.5340237319469452e-01
    z[3,7,6]  R2159     -3.8018664717674255e-01
    z[3,7,6]  R2160     -3.7175354361534119e-01
    z[3,7,6]  R2161     -2.7003440260887146e-01
    z[3,7,6]  R2162     -1.1532482504844666e-01
    z[3,7,6]  R2163     -2.1410727500915527e-01
    z[3,7,6]  R2164     3.3382120728492737e-01
    z[3,7,6]  R2165     -8.1435024738311768e-02
    z[3,7,6]  R2166     9.2316776514053345e-02
    z[3,7,6]  R2167     4.0257081389427185e-01
    z[3,7,6]  R2168     -6.1611879616975784e-02
    z[3,7,6]  R2169     2.4131615459918976e-01
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R2170     -1
    z[7,3,0]  R2171     1
    z[7,3,0]  R2184     3.5147759318351746e-01
    z[7,3,0]  R2185     4.0883067995309830e-02
    z[7,3,0]  R2186     2.7442533522844315e-02
    z[7,3,0]  R2187     -2.2505679726600647e-01
    z[7,3,0]  R2188     -1.7047492787241936e-02
    z[7,3,0]  R2189     -3.7297993898391724e-01
    z[7,3,0]  R2190     -2.7726629376411438e-01
    z[7,3,0]  R2191     -3.5951441526412964e-01
    z[7,3,0]  R2192     -9.3873977661132812e-02
    z[7,3,0]  R2193     2.9853138327598572e-01
    z[7,3,0]  R2194     -4.2799907922744751e-01
    z[7,3,0]  R2195     -6.0560190677642822e-01
    z[7,3,0]  R2196     -5.3953188657760620e-01
    z[7,3,0]  R2197     -2.5984960794448853e-01
    z[7,3,0]  R2198     -6.4778298139572144e-01
    z[7,3,0]  R2199     -4.1700929403305054e-01
    z[7,3,0]  R2200     -0.385744571685791
    z[7,3,0]  R2201     -1.8221004307270050e-01
    z[7,3,0]  R2202     -4.7696086764335632e-01
    z[7,3,0]  R2203     -3.6791044473648071e-01
    z[7,3,0]  R2204     -3.4008061885833740e-01
    z[7,3,0]  R2205     -2.2818570956587791e-02
    z[7,3,0]  R2206     3.9294874668121338e-01
    z[7,3,0]  R2207     -3.0102510005235672e-02
    z[7,3,0]  R2208     -0.400037944316864
    z[7,3,0]  R2209     -5.7290811091661453e-02
    z[7,3,0]  R2210     -6.6945418715476990e-02
    z[7,3,0]  R2211     -2.1001422405242920e-01
    z[7,3,0]  R2212     -4.1027206182479858e-01
    z[7,3,0]  R2213     -2.4204806983470917e-01
    z[7,3,0]  R2214     4.5590800046920776e-01
    z[7,3,0]  R2215     6.5800681710243225e-02
    z[7,3,0]  R2216     -6.0763758420944214e-01
    z[7,3,0]  R2217     -3.2962110638618469e-01
    z[7,3,0]  R2218     1.6704581677913666e-01
    z[7,3,0]  R2219     -2.8840294480323792e-01
    z[7,3,0]  R2220     -1.5888524055480957e-01
    z[7,3,0]  R2221     1.8819020688533783e-01
    z[7,3,0]  R2222     -6.0815680772066116e-03
    z[7,3,0]  R2223     -3.5370126366615295e-01
    z[7,3,0]  R2224     3.7067100405693054e-02
    z[7,3,0]  R2225     3.7179496884346008e-01
    z[7,3,0]  R2226     -4.1181966662406921e-01
    z[7,3,0]  R2227     5.1207607984542847e-01
    z[7,3,0]  R2228     -6.3994753360748291e-01
    z[7,3,0]  R2229     -0.316124826669693
    z[7,3,0]  R2230     -4.0294739603996277e-01
    z[7,3,0]  R2231     5.3729891777038574e-01
    z[7,3,0]  R2232     -4.6869885921478271e-01
    z[7,3,0]  R2233     -4.5559534430503845e-01
    z[7,3,0]  R2234     7.8173793852329254e-02
    z[7,3,0]  R2235     -1.7945900559425354e-01
    z[7,3,0]  R2236     -1.2135547585785389e-03
    z[7,3,0]  R2237     -0.0807340145111084
    z[7,3,0]  R2238     -2.4226111173629761e-01
    z[7,3,0]  R2239     -2.3268264532089233e-01
    z[7,3,0]  R2240     -5.3354259580373764e-02
    z[7,3,0]  R2241     -3.0456345528364182e-02
    z[7,3,0]  R2242     -2.2064997255802155e-01
    z[7,3,0]  R2243     -4.6148531138896942e-02
    z[7,3,0]  R2244     6.5666645765304565e-02
    z[7,3,0]  R2245     -1.9799323379993439e-01
    z[7,3,0]  R2246     3.2701876759529114e-01
    z[7,3,0]  R2247     -1.4233329892158508e-01
    z[7,3,0]  R2248     1.9304735586047173e-02
    z[7,3,0]  R2249     -1.5847027301788330e-01
    z[7,3,0]  R2250     5.3673553466796875e-01
    z[7,3,0]  R2251     3.6323402076959610e-02
    z[7,3,0]  R2252     -3.4531587362289429e-01
    z[7,3,0]  R2253     -1.6749443113803864e-01
    z[7,3,0]  R2254     -2.3113049566745758e-01
    z[7,3,0]  R2255     -4.3012022972106934e-02
    z[7,3,0]  R2256     4.8231253027915955e-01
    z[7,3,0]  R2257     2.5550296530127525e-02
    z[7,3,0]  R2258     -2.0028276741504669e-01
    z[7,3,0]  R2259     -4.8691046237945557e-01
    z[7,3,0]  R2260     -1.2682755291461945e-01
    z[7,3,0]  R2261     2.6874890923500061e-01
    z[7,3,0]  R2262     1.3006573915481567e-01
    z[7,3,0]  R2263     3.6033737659454346e-01
    z[7,3,0]  R2264     5.9692794084548950e-01
    z[7,3,0]  R2265     3.9397379755973816e-01
    z[7,3,0]  R2266     -1.7629776895046234e-01
    z[7,3,0]  R2267     1.2649475038051605e-01
    z[7,3,0]  R2268     5.8065932244062424e-02
    z[7,3,0]  R2269     -2.4579444527626038e-01
    z[7,3,0]  R2270     6.5198093652725220e-02
    z[7,3,0]  R2271     5.4943734407424927e-01
    z[7,3,0]  R2272     -1.5163809061050415e-01
    z[7,3,0]  R2273     -2.2004279494285583e-01
    z[7,3,0]  R2274     -1.1727644503116608e-01
    z[7,3,0]  R2275     1.9039590656757355e-01
    z[7,3,0]  R2276     2.9173459857702255e-02
    z[7,3,0]  R2277     -5.5233038961887360e-02
    z[7,3,0]  R2278     -1.4811183512210846e-01
    z[7,3,0]  R2279     9.3578584492206573e-02
    z[7,3,0]  R2280     -9.8985306918621063e-02
    z[7,3,0]  R2281     -1.3010847568511963e-01
    z[7,3,0]  R2282     1.1820724606513977e-01
    z[7,3,0]  R2283     -2.2255496680736542e-01
    z[7,3,0]  R2284     -1.2191570550203323e-01
    z[7,3,0]  R2285     -3.0332719907164574e-02
    z[7,3,0]  R2286     -8.1705629825592041e-02
    z[7,3,0]  R2287     -3.3933378756046295e-02
    z[7,3,0]  R2288     4.9755383282899857e-02
    z[7,3,0]  R2289     1.3494296371936798e-01
    z[7,3,0]  R2290     0.0110483942553401
    z[7,3,0]  R2291     1.4044113457202911e-01
    z[7,3,0]  R2292     0.590168297290802
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R2172     -1
    z[7,3,1]  R2173     1
    z[7,3,1]  R2184     5.3772604465484619e-01
    z[7,3,1]  R2185     7.2924906015396118e-01
    z[7,3,1]  R2186     9.2543345689773560e-01
    z[7,3,1]  R2187     6.6633814573287964e-01
    z[7,3,1]  R2188     6.6368007659912109e-01
    z[7,3,1]  R2189     0.721071183681488
    z[7,3,1]  R2190     5.9860116243362427e-01
    z[7,3,1]  R2191     4.9381405115127563e-01
    z[7,3,1]  R2192     6.9966787099838257e-01
    z[7,3,1]  R2193     7.3879170417785645e-01
    z[7,3,1]  R2194     -5.5943650007247925e-01
    z[7,3,1]  R2195     -6.1637800931930542e-01
    z[7,3,1]  R2196     -4.9711513519287109e-01
    z[7,3,1]  R2197     -6.9946968555450439e-01
    z[7,3,1]  R2198     -4.3509474396705627e-01
    z[7,3,1]  R2199     -0.527397096157074
    z[7,3,1]  R2200     -6.5380924940109253e-01
    z[7,3,1]  R2201     -3.6172983050346375e-01
    z[7,3,1]  R2202     -6.5000897645950317e-01
    z[7,3,1]  R2203     -4.8431155085563660e-01
    z[7,3,1]  R2204     -8.0435746908187866e-01
    z[7,3,1]  R2205     -8.4212523698806763e-01
    z[7,3,1]  R2206     2.9639837145805359e-01
    z[7,3,1]  R2207     -0.961946427822113
    z[7,3,1]  R2208     -7.6187348365783691e-01
    z[7,3,1]  R2209     -7.0618337392807007e-01
    z[7,3,1]  R2210     -0.890663206577301
    z[7,3,1]  R2211     -7.6029217243194580e-01
    z[7,3,1]  R2212     -8.0137866735458374e-01
    z[7,3,1]  R2213     -7.0838910341262817e-01
    z[7,3,1]  R2214     5.2064180374145508e-01
    z[7,3,1]  R2215     5.1355838775634766e-01
    z[7,3,1]  R2216     4.3847480416297913e-01
    z[7,3,1]  R2217     1.5662458539009094e-01
    z[7,3,1]  R2218     3.8802614808082581e-01
    z[7,3,1]  R2219     -8.2546448707580566e-01
    z[7,3,1]  R2220     -8.1400001049041748e-01
    z[7,3,1]  R2221     -1.3649834692478180e-01
    z[7,3,1]  R2222     -7.3540627956390381e-01
    z[7,3,1]  R2223     -7.2362780570983887e-01
    z[7,3,1]  R2224     6.9367986917495728e-01
    z[7,3,1]  R2225     6.6264796257019043e-01
    z[7,3,1]  R2226     -4.9712666869163513e-01
    z[7,3,1]  R2227     4.0542349219322205e-01
    z[7,3,1]  R2228     -0.443347305059433
    z[7,3,1]  R2229     -5.1285165548324585e-01
    z[7,3,1]  R2230     -0.450613796710968
    z[7,3,1]  R2231     6.5254640579223633e-01
    z[7,3,1]  R2232     -6.2381881475448608e-01
    z[7,3,1]  R2233     7.0405995845794678e-01
    z[7,3,1]  R2234     -9.6634417772293091e-01
    z[7,3,1]  R2235     -8.2638806104660034e-01
    z[7,3,1]  R2236     -8.3274024724960327e-01
    z[7,3,1]  R2237     -9.4393610954284668e-01
    z[7,3,1]  R2238     -8.9501363039016724e-01
    z[7,3,1]  R2239     -8.5856539011001587e-01
    z[7,3,1]  R2240     -9.3438696861267090e-01
    z[7,3,1]  R2241     -8.9354443550109863e-01
    z[7,3,1]  R2242     -8.9741677045822144e-01
    z[7,3,1]  R2243     -8.6780643463134766e-01
    z[7,3,1]  R2244     9.0192121267318726e-01
    z[7,3,1]  R2245     0.6239013671875
    z[7,3,1]  R2246     3.4472694993019104e-01
    z[7,3,1]  R2247     0.70050448179245
    z[7,3,1]  R2248     4.5671561360359192e-01
    z[7,3,1]  R2249     0.627260684967041
    z[7,3,1]  R2250     7.8109733294695616e-04
    z[7,3,1]  R2251     -7.5922125577926636e-01
    z[7,3,1]  R2252     -0.715255618095398
    z[7,3,1]  R2253     -5.2114403247833252e-01
    z[7,3,1]  R2254     7.6005853712558746e-02
    z[7,3,1]  R2255     0.802408754825592
    z[7,3,1]  R2256     -0.0430334135890007
    z[7,3,1]  R2257     4.5041911303997040e-02
    z[7,3,1]  R2258     3.0691778659820557e-01
    z[7,3,1]  R2259     2.6438814401626587e-01
    z[7,3,1]  R2260     -5.6059908866882324e-01
    z[7,3,1]  R2261     -6.6544133424758911e-01
    z[7,3,1]  R2262     -6.2691295146942139e-01
    z[7,3,1]  R2263     -6.3844412565231323e-01
    z[7,3,1]  R2264     1.4414748549461365e-01
    z[7,3,1]  R2265     3.5924646258354187e-01
    z[7,3,1]  R2266     4.2892915010452271e-01
    z[7,3,1]  R2267     7.6178300380706787e-01
    z[7,3,1]  R2268     8.5596400499343872e-01
    z[7,3,1]  R2269     5.7058918476104736e-01
    z[7,3,1]  R2270     0.0888204276561737
    z[7,3,1]  R2271     0.0500313900411129
    z[7,3,1]  R2272     -7.8557604551315308e-01
    z[7,3,1]  R2273     -6.9789052009582520e-01
    z[7,3,1]  R2274     5.8851748704910278e-01
    z[7,3,1]  R2275     3.6812219023704529e-01
    z[7,3,1]  R2276     7.0105659961700439e-01
    z[7,3,1]  R2277     6.9236093759536743e-01
    z[7,3,1]  R2278     7.4410974979400635e-01
    z[7,3,1]  R2279     -7.9978233575820923e-01
    z[7,3,1]  R2280     -6.6857415437698364e-01
    z[7,3,1]  R2281     -7.6604461669921875e-01
    z[7,3,1]  R2282     -8.1263101100921631e-01
    z[7,3,1]  R2283     2.2216621041297913e-01
    z[7,3,1]  R2284     8.7879288196563721e-01
    z[7,3,1]  R2285     6.9568967819213867e-01
    z[7,3,1]  R2286     -7.6769274473190308e-01
    z[7,3,1]  R2287     -0.793660581111908
    z[7,3,1]  R2288     -8.9406061172485352e-01
    z[7,3,1]  R2289     -0.69505375623703
    z[7,3,1]  R2290     -6.0580420494079590e-01
    z[7,3,1]  R2291     -4.4465139508247375e-03
    z[7,3,1]  R2292     1.0688560083508492e-02
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R2174     -1
    z[7,3,2]  R2175     1
    z[7,3,2]  R2184     -4.1262698173522949e-01
    z[7,3,2]  R2185     0.0496567003428936
    z[7,3,2]  R2186     4.4755268841981888e-02
    z[7,3,2]  R2187     -1.4815372228622437e-01
    z[7,3,2]  R2188     4.2813235521316528e-01
    z[7,3,2]  R2189     4.5968118309974670e-01
    z[7,3,2]  R2190     4.1569215059280396e-01
    z[7,3,2]  R2191     7.5898277573287487e-03
    z[7,3,2]  R2192     4.0898427367210388e-01
    z[7,3,2]  R2193     1.3869714736938477e-01
    z[7,3,2]  R2194     -5.3591018915176392e-01
    z[7,3,2]  R2195     -2.2801041603088379e-01
    z[7,3,2]  R2196     -0.516657292842865
    z[7,3,2]  R2197     -4.0650996565818787e-01
    z[7,3,2]  R2198     -5.9381824731826782e-01
    z[7,3,2]  R2199     -2.7623388171195984e-01
    z[7,3,2]  R2200     -5.0986176729202271e-01
    z[7,3,2]  R2201     -6.9064414501190186e-01
    z[7,3,2]  R2202     -4.5217093825340271e-01
    z[7,3,2]  R2203     -0.56244957447052
    z[7,3,2]  R2204     1.9406144320964813e-01
    z[7,3,2]  R2205     2.8965404629707336e-01
    z[7,3,2]  R2206     3.4909170120954514e-02
    z[7,3,2]  R2207     6.5579958260059357e-02
    z[7,3,2]  R2208     3.9618015289306641e-01
    z[7,3,2]  R2209     -2.8757303953170776e-01
    z[7,3,2]  R2210     1.5739649534225464e-01
    z[7,3,2]  R2211     4.0723752975463867e-01
    z[7,3,2]  R2212     3.6946651339530945e-01
    z[7,3,2]  R2213     2.5820541381835938e-01
    z[7,3,2]  R2214     0.0326387919485569
    z[7,3,2]  R2215     6.7335285246372223e-02
    z[7,3,2]  R2216     2.7764764428138733e-01
    z[7,3,2]  R2217     5.3151077032089233e-01
    z[7,3,2]  R2218     -2.2476732730865479e-01
    z[7,3,2]  R2219     1.9603857398033142e-01
    z[7,3,2]  R2220     -3.0395476147532463e-02
    z[7,3,2]  R2221     1.5812179446220398e-01
    z[7,3,2]  R2222     -1.8200913071632385e-01
    z[7,3,2]  R2223     7.9307332634925842e-03
    z[7,3,2]  R2224     3.7445166707038879e-01
    z[7,3,2]  R2225     -2.4146245419979095e-01
    z[7,3,2]  R2226     -6.5644830465316772e-01
    z[7,3,2]  R2227     -1.2594206631183624e-01
    z[7,3,2]  R2228     -5.0185889005661011e-01
    z[7,3,2]  R2229     -3.9556607604026794e-01
    z[7,3,2]  R2230     -4.8620283603668213e-01
    z[7,3,2]  R2231     -5.1303360611200333e-02
    z[7,3,2]  R2232     -1.8828479945659637e-01
    z[7,3,2]  R2233     -1.8435798585414886e-01
    z[7,3,2]  R2234     1.3297490775585175e-01
    z[7,3,2]  R2235     -1.6308559570461512e-03
    z[7,3,2]  R2236     -7.8419208526611328e-02
    z[7,3,2]  R2237     1.8751381337642670e-01
    z[7,3,2]  R2238     1.4740787446498871e-01
    z[7,3,2]  R2239     3.0041760206222534e-01
    z[7,3,2]  R2240     3.2278785109519958e-01
    z[7,3,2]  R2241     1.4655736088752747e-01
    z[7,3,2]  R2242     -4.4597167521715164e-02
    z[7,3,2]  R2243     2.1245136857032776e-01
    z[7,3,2]  R2244     -1.2600612640380859e-01
    z[7,3,2]  R2245     -2.3675315082073212e-01
    z[7,3,2]  R2246     -1.9854129850864410e-01
    z[7,3,2]  R2247     -8.3444461226463318e-02
    z[7,3,2]  R2248     -2.7143913507461548e-01
    z[7,3,2]  R2249     -2.6291960477828979e-01
    z[7,3,2]  R2250     -0.0666758269071579
    z[7,3,2]  R2251     -1.8733938038349152e-01
    z[7,3,2]  R2252     -0.0946456640958786
    z[7,3,2]  R2253     -1.4219684898853302e-01
    z[7,3,2]  R2254     2.4438938498497009e-01
    z[7,3,2]  R2255     -3.3602195978164673e-01
    z[7,3,2]  R2256     -5.1875356584787369e-03
    z[7,3,2]  R2257     2.1833754144608974e-03
    z[7,3,2]  R2258     -2.4139027297496796e-01
    z[7,3,2]  R2259     -1.5233443677425385e-01
    z[7,3,2]  R2260     -4.3736910820007324e-01
    z[7,3,2]  R2261     -2.3348213732242584e-01
    z[7,3,2]  R2262     -4.5843631029129028e-01
    z[7,3,2]  R2263     1.5957817435264587e-01
    z[7,3,2]  R2264     2.9598847031593323e-01
    z[7,3,2]  R2265     2.7041327953338623e-01
    z[7,3,2]  R2266     -2.4659752845764160e-01
    z[7,3,2]  R2267     -4.6603524684906006e-01
    z[7,3,2]  R2268     -0.0762200802564621
    z[7,3,2]  R2269     2.4485167115926743e-02
    z[7,3,2]  R2270     2.6378279551863670e-02
    z[7,3,2]  R2271     -3.3334141969680786e-01
    z[7,3,2]  R2272     -9.0231351554393768e-02
    z[7,3,2]  R2273     -3.5453933477401733e-01
    z[7,3,2]  R2274     4.3191414326429367e-02
    z[7,3,2]  R2275     -0.341232031583786
    z[7,3,2]  R2276     -4.0100088715553284e-01
    z[7,3,2]  R2277     -7.8620567917823792e-02
    z[7,3,2]  R2278     -1.0464297980070114e-01
    z[7,3,2]  R2279     -2.4717628955841064e-01
    z[7,3,2]  R2280     -3.3976930379867554e-01
    z[7,3,2]  R2281     -1.2700571119785309e-01
    z[7,3,2]  R2282     1.9309714436531067e-01
    z[7,3,2]  R2283     7.5070065259933472e-01
    z[7,3,2]  R2284     -2.0854748785495758e-01
    z[7,3,2]  R2285     2.2803038358688354e-01
    z[7,3,2]  R2286     -1.6927412152290344e-01
    z[7,3,2]  R2287     -3.2806521654129028e-01
    z[7,3,2]  R2288     7.4264849536120892e-03
    z[7,3,2]  R2289     -2.3701396584510803e-01
    z[7,3,2]  R2290     1.0115970671176910e-01
    z[7,3,2]  R2291     0.692564845085144
    z[7,3,2]  R2292     3.3201807737350464e-01
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R2176     -1
    z[7,3,3]  R2177     1
    z[7,3,3]  R2184     4.5000296831130981e-01
    z[7,3,3]  R2185     6.3621246814727783e-01
    z[7,3,3]  R2186     -1.7492806538939476e-02
    z[7,3,3]  R2187     2.7972223237156868e-02
    z[7,3,3]  R2188     3.7851759791374207e-01
    z[7,3,3]  R2189     1.3253663666546345e-02
    z[7,3,3]  R2190     4.3476754426956177e-01
    z[7,3,3]  R2191     4.7934412956237793e-01
    z[7,3,3]  R2192     1.6339744627475739e-01
    z[7,3,3]  R2193     4.8957455158233643e-01
    z[7,3,3]  R2194     -1.4709731936454773e-01
    z[7,3,3]  R2195     -2.5882723927497864e-01
    z[7,3,3]  R2196     -2.1688246726989746e-01
    z[7,3,3]  R2197     -4.6647912263870239e-01
    z[7,3,3]  R2198     -8.3207428455352783e-02
    z[7,3,3]  R2199     -5.6877774000167847e-01
    z[7,3,3]  R2200     -3.0903410911560059e-01
    z[7,3,3]  R2201     -4.6563339233398438e-01
    z[7,3,3]  R2202     -3.3741500973701477e-01
    z[7,3,3]  R2203     -5.4462337493896484e-01
    z[7,3,3]  R2204     -1.7232039570808411e-01
    z[7,3,3]  R2205     -2.1759833395481110e-01
    z[7,3,3]  R2206     -6.5985542535781860e-01
    z[7,3,3]  R2207     2.0762298256158829e-02
    z[7,3,3]  R2208     -7.8155420720577240e-02
    z[7,3,3]  R2209     -0.406417578458786
    z[7,3,3]  R2210     6.5221287310123444e-02
    z[7,3,3]  R2211     0.0881512239575386
    z[7,3,3]  R2212     1.3524082303047180e-01
    z[7,3,3]  R2213     -2.6688039302825928e-01
    z[7,3,3]  R2214     0.33226278424263
    z[7,3,3]  R2215     3.9146417379379272e-01
    z[7,3,3]  R2216     -8.0085076391696930e-02
    z[7,3,3]  R2217     1.9872041046619415e-01
    z[7,3,3]  R2218     -4.8493242263793945e-01
    z[7,3,3]  R2219     -4.0307980775833130e-01
    z[7,3,3]  R2220     -4.5969793200492859e-01
    z[7,3,3]  R2221     7.2684627771377563e-01
    z[7,3,3]  R2222     -6.3669097423553467e-01
    z[7,3,3]  R2223     -0.288517564535141
    z[7,3,3]  R2224     4.9024832248687744e-01
    z[7,3,3]  R2225     5.2322983741760254e-01
    z[7,3,3]  R2226     -2.6184621453285217e-01
    z[7,3,3]  R2227     5.5958682298660278e-01
    z[7,3,3]  R2228     6.1362501233816147e-02
    z[7,3,3]  R2229     -4.5997259020805359e-01
    z[7,3,3]  R2230     -1.9809435307979584e-01
    z[7,3,3]  R2231     -0.0729481503367424
    z[7,3,3]  R2232     -1.1497498303651810e-01
    z[7,3,3]  R2233     2.1794460713863373e-01
    z[7,3,3]  R2234     -1.2271368503570557e-01
    z[7,3,3]  R2235     -1.6657491028308868e-01
    z[7,3,3]  R2236     -1.7226240038871765e-01
    z[7,3,3]  R2237     -2.4263501167297363e-01
    z[7,3,3]  R2238     -2.9438859224319458e-01
    z[7,3,3]  R2239     -1.4323222637176514e-01
    z[7,3,3]  R2240     5.3854927420616150e-02
    z[7,3,3]  R2241     8.3793297410011292e-02
    z[7,3,3]  R2242     5.9439826756715775e-02
    z[7,3,3]  R2243     2.2096496820449829e-01
    z[7,3,3]  R2244     -3.3231475949287415e-01
    z[7,3,3]  R2245     8.5544362664222717e-02
    z[7,3,3]  R2246     5.4995030164718628e-02
    z[7,3,3]  R2247     -2.5623863935470581e-01
    z[7,3,3]  R2248     1.4718367159366608e-01
    z[7,3,3]  R2249     -4.7586208581924438e-01
    z[7,3,3]  R2250     5.7744556665420532e-01
    z[7,3,3]  R2251     -3.7982547283172607e-01
    z[7,3,3]  R2252     -3.8820537924766541e-01
    z[7,3,3]  R2253     -6.8278080224990845e-01
    z[7,3,3]  R2254     5.6001764535903931e-01
    z[7,3,3]  R2255     -8.2615956664085388e-02
    z[7,3,3]  R2256     5.9955221414566040e-01
    z[7,3,3]  R2257     5.5213242769241333e-01
    z[7,3,3]  R2258     6.8202984333038330e-01
    z[7,3,3]  R2259     0.567356526851654
    z[7,3,3]  R2260     -3.3254262804985046e-01
    z[7,3,3]  R2261     -6.4255464076995850e-01
    z[7,3,3]  R2262     -4.6182984113693237e-01
    z[7,3,3]  R2263     -5.4322427511215210e-01
    z[7,3,3]  R2264     3.8676840066909790e-01
    z[7,3,3]  R2265     -1.4344982802867889e-01
    z[7,3,3]  R2266     6.5242147445678711e-01
    z[7,3,3]  R2267     -2.0302671939134598e-02
    z[7,3,3]  R2268     -3.8734534382820129e-01
    z[7,3,3]  R2269     2.6633885502815247e-01
    z[7,3,3]  R2270     9.2679816484451294e-01
    z[7,3,3]  R2271     4.9930948019027710e-01
    z[7,3,3]  R2272     -2.5792637467384338e-01
    z[7,3,3]  R2273     -3.6546853184700012e-01
    z[7,3,3]  R2274     5.7596552371978760e-01
    z[7,3,3]  R2275     5.1674467325210571e-01
    z[7,3,3]  R2276     8.7929308414459229e-02
    z[7,3,3]  R2277     3.7946559488773346e-02
    z[7,3,3]  R2278     -3.0083081126213074e-01
    z[7,3,3]  R2279     -1.4255067706108093e-01
    z[7,3,3]  R2280     -5.8918052911758423e-01
    z[7,3,3]  R2281     -1.2219463288784027e-01
    z[7,3,3]  R2282     2.0624296367168427e-01
    z[7,3,3]  R2283     -3.6771920323371887e-01
    z[7,3,3]  R2284     1.7160816490650177e-01
    z[7,3,3]  R2285     -1.2418014556169510e-01
    z[7,3,3]  R2286     -5.4831933975219727e-01
    z[7,3,3]  R2287     -3.3369067311286926e-01
    z[7,3,3]  R2288     2.8668698668479919e-01
    z[7,3,3]  R2289     -2.9597437381744385e-01
    z[7,3,3]  R2290     -6.3257539272308350e-01
    z[7,3,3]  R2291     -0.566639244556427
    z[7,3,3]  R2292     -6.5333527326583862e-01
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R2178     -1
    z[7,3,4]  R2179     1
    z[7,3,4]  R2184     1.3001147657632828e-02
    z[7,3,4]  R2185     -8.7179347872734070e-02
    z[7,3,4]  R2186     1.6161532700061798e-01
    z[7,3,4]  R2187     2.5822514295578003e-01
    z[7,3,4]  R2188     -2.0004893839359283e-01
    z[7,3,4]  R2189     -2.4194066226482391e-01
    z[7,3,4]  R2190     2.6647615432739258e-01
    z[7,3,4]  R2191     -7.0569347590208054e-03
    z[7,3,4]  R2192     -0.457533061504364
    z[7,3,4]  R2193     2.6290962100028992e-01
    z[7,3,4]  R2194     -4.0289908647537231e-01
    z[7,3,4]  R2195     -3.5442799329757690e-01
    z[7,3,4]  R2196     -1.9329233467578888e-01
    z[7,3,4]  R2197     -2.1037788689136505e-01
    z[7,3,4]  R2198     -6.5850298851728439e-03
    z[7,3,4]  R2199     -3.7085208296775818e-01
    z[7,3,4]  R2200     6.4554825425148010e-02
    z[7,3,4]  R2201     -3.6159214377403259e-01
    z[7,3,4]  R2202     5.0317924469709396e-02
    z[7,3,4]  R2203     2.5089766830205917e-02
    z[7,3,4]  R2204     3.2245415449142456e-01
    z[7,3,4]  R2205     2.0978122949600220e-01
    z[7,3,4]  R2206     -4.8044338822364807e-01
    z[7,3,4]  R2207     -2.4499568343162537e-01
    z[7,3,4]  R2208     2.1332244575023651e-01
    z[7,3,4]  R2209     2.6873627305030823e-01
    z[7,3,4]  R2210     4.2627118527889252e-03
    z[7,3,4]  R2211     4.1220989823341370e-01
    z[7,3,4]  R2212     1.0254800319671631e-01
    z[7,3,4]  R2213     -3.0259862542152405e-01
    z[7,3,4]  R2214     4.2819178104400635e-01
    z[7,3,4]  R2215     -0.486828088760376
    z[7,3,4]  R2216     1.7520861327648163e-01
    z[7,3,4]  R2217     6.8648862838745117e-01
    z[7,3,4]  R2218     -5.6398731470108032e-01
    z[7,3,4]  R2219     2.6229554787278175e-02
    z[7,3,4]  R2220     2.8796127438545227e-01
    z[7,3,4]  R2221     3.1456348299980164e-01
    z[7,3,4]  R2222     -4.3707441538572311e-02
    z[7,3,4]  R2223     -4.1453507542610168e-01
    z[7,3,4]  R2224     -2.3091910779476166e-01
    z[7,3,4]  R2225     -1.9820597767829895e-01
    z[7,3,4]  R2226     -0.223605215549469
    z[7,3,4]  R2227     -3.1431868672370911e-01
    z[7,3,4]  R2228     -3.4318295121192932e-01
    z[7,3,4]  R2229     -4.1663515567779541e-01
    z[7,3,4]  R2230     -3.9054206013679504e-01
    z[7,3,4]  R2231     -8.2912124693393707e-02
    z[7,3,4]  R2232     -5.5594122409820557e-01
    z[7,3,4]  R2233     -2.8605180978775024e-01
    z[7,3,4]  R2234     -1.5274184942245483e-01
    z[7,3,4]  R2235     -1.1104546487331390e-01
    z[7,3,4]  R2236     -2.5291544198989868e-01
    z[7,3,4]  R2237     8.7573297321796417e-02
    z[7,3,4]  R2238     0.0885215625166893
    z[7,3,4]  R2239     -1.4982230961322784e-01
    z[7,3,4]  R2240     2.2073255851864815e-02
    z[7,3,4]  R2241     -9.8633743822574615e-02
    z[7,3,4]  R2242     -1.6097214818000793e-01
    z[7,3,4]  R2243     -3.5569289326667786e-01
    z[7,3,4]  R2244     3.1154308468103409e-02
    z[7,3,4]  R2245     -1.8996725976467133e-01
    z[7,3,4]  R2246     7.9639393091201782e-01
    z[7,3,4]  R2247     8.2627013325691223e-03
    z[7,3,4]  R2248     2.2096820175647736e-01
    z[7,3,4]  R2249     3.2409203052520752e-01
    z[7,3,4]  R2250     2.6137617230415344e-01
    z[7,3,4]  R2251     -4.2287570238113403e-01
    z[7,3,4]  R2252     -2.0530524849891663e-01
    z[7,3,4]  R2253     -5.1775805652141571e-02
    z[7,3,4]  R2254     0.721405565738678
    z[7,3,4]  R2255     3.3904662728309631e-01
    z[7,3,4]  R2256     0.536944568157196
    z[7,3,4]  R2257     5.3472465276718140e-01
    z[7,3,4]  R2258     3.1423911452293396e-01
    z[7,3,4]  R2259     3.7826636433601379e-01
    z[7,3,4]  R2260     -1.6794683039188385e-01
    z[7,3,4]  R2261     2.4229032918810844e-02
    z[7,3,4]  R2262     2.3647651076316833e-01
    z[7,3,4]  R2263     5.2013982087373734e-02
    z[7,3,4]  R2264     3.5284776240587234e-02
    z[7,3,4]  R2265     4.6251362562179565e-01
    z[7,3,4]  R2266     3.9560711383819580e-01
    z[7,3,4]  R2267     -1.7187000811100006e-01
    z[7,3,4]  R2268     8.7326399981975555e-02
    z[7,3,4]  R2269     3.7959685921669006e-01
    z[7,3,4]  R2270     2.2575959563255310e-01
    z[7,3,4]  R2271     4.5889419317245483e-01
    z[7,3,4]  R2272     -3.0037787556648254e-01
    z[7,3,4]  R2273     1.6902795433998108e-01
    z[7,3,4]  R2274     4.5079541206359863e-01
    z[7,3,4]  R2275     2.2691859304904938e-01
    z[7,3,4]  R2276     5.3960567712783813e-01
    z[7,3,4]  R2277     1.1950118094682693e-01
    z[7,3,4]  R2278     -0.562481164932251
    z[7,3,4]  R2279     4.0394267439842224e-01
    z[7,3,4]  R2280     -1.9072486320510507e-03
    z[7,3,4]  R2281     0.494154691696167
    z[7,3,4]  R2282     -1.9802886247634888e-01
    z[7,3,4]  R2283     2.0406669378280640e-01
    z[7,3,4]  R2284     3.5650530457496643e-01
    z[7,3,4]  R2285     -3.6467918753623962e-01
    z[7,3,4]  R2286     -8.4266647696495056e-02
    z[7,3,4]  R2287     -4.7175593674182892e-02
    z[7,3,4]  R2288     -1.6847534105181694e-02
    z[7,3,4]  R2289     5.5132389068603516e-01
    z[7,3,4]  R2290     0.340406596660614
    z[7,3,4]  R2291     1.7809723317623138e-01
    z[7,3,4]  R2292     -2.5065923109650612e-02
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R2180     -1
    z[7,3,5]  R2181     1
    z[7,3,5]  R2184     -1.0507623106241226e-01
    z[7,3,5]  R2185     -1.3714969158172607e-01
    z[7,3,5]  R2186     1.7076972126960754e-01
    z[7,3,5]  R2187     -8.8459923863410950e-02
    z[7,3,5]  R2188     0.258756548166275
    z[7,3,5]  R2189     -4.9505833536386490e-02
    z[7,3,5]  R2190     4.6881463378667831e-02
    z[7,3,5]  R2191     -3.4698281437158585e-02
    z[7,3,5]  R2192     5.5712736211717129e-03
    z[7,3,5]  R2193     1.3792365789413452e-01
    z[7,3,5]  R2194     8.8033504784107208e-02
    z[7,3,5]  R2195     -9.3164615333080292e-02
    z[7,3,5]  R2196     -1.9087509810924530e-01
    z[7,3,5]  R2197     7.0396237075328827e-02
    z[7,3,5]  R2198     6.9680221378803253e-02
    z[7,3,5]  R2199     1.0128123313188553e-01
    z[7,3,5]  R2200     2.5151568651199341e-01
    z[7,3,5]  R2201     8.0217964947223663e-02
    z[7,3,5]  R2202     -1.5398536622524261e-01
    z[7,3,5]  R2203     -1.0147435218095779e-01
    z[7,3,5]  R2204     -2.5306597352027893e-01
    z[7,3,5]  R2205     1.6864615678787231e-01
    z[7,3,5]  R2206     -1.0216084867715836e-01
    z[7,3,5]  R2207     -8.7392807006835938e-02
    z[7,3,5]  R2208     2.1890738606452942e-01
    z[7,3,5]  R2209     -3.8237354159355164e-01
    z[7,3,5]  R2210     -4.0125495195388794e-01
    z[7,3,5]  R2211     1.8512722849845886e-01
    z[7,3,5]  R2212     -2.5003109127283096e-02
    z[7,3,5]  R2213     -2.5611430406570435e-01
    z[7,3,5]  R2214     -2.9676118493080139e-01
    z[7,3,5]  R2215     -5.1403272151947021e-01
    z[7,3,5]  R2216     -5.5768877267837524e-01
    z[7,3,5]  R2217     -0.166483074426651
    z[7,3,5]  R2218     -3.2608771324157715e-01
    z[7,3,5]  R2219     1.6494846343994141e-01
    z[7,3,5]  R2220     9.2028222978115082e-02
    z[7,3,5]  R2221     0.362809956073761
    z[7,3,5]  R2222     1.2219491600990295e-01
    z[7,3,5]  R2223     1.9462847709655762e-01
    z[7,3,5]  R2224     -2.7438384294509888e-01
    z[7,3,5]  R2225     1.9655370712280273e-01
    z[7,3,5]  R2226     9.9414110183715820e-02
    z[7,3,5]  R2227     1.8051995337009430e-01
    z[7,3,5]  R2228     1.2213288247585297e-01
    z[7,3,5]  R2229     -8.3527758717536926e-02
    z[7,3,5]  R2230     -2.8987939003854990e-03
    z[7,3,5]  R2231     -3.8450825214385986e-01
    z[7,3,5]  R2232     -1.7510086297988892e-01
    z[7,3,5]  R2233     0.253398597240448
    z[7,3,5]  R2234     0.00825007539242506
    z[7,3,5]  R2235     4.9329242110252380e-01
    z[7,3,5]  R2236     4.4502985477447510e-01
    z[7,3,5]  R2237     -1.3583134859800339e-02
    z[7,3,5]  R2238     5.4998189210891724e-02
    z[7,3,5]  R2239     2.7247005701065063e-01
    z[7,3,5]  R2240     1.1730955541133881e-01
    z[7,3,5]  R2241     4.0171834826469421e-01
    z[7,3,5]  R2242     3.2744646072387695e-01
    z[7,3,5]  R2243     0.0937584787607193
    z[7,3,5]  R2244     1.3725067675113678e-01
    z[7,3,5]  R2245     3.8609090447425842e-01
    z[7,3,5]  R2246     -4.2861010879278183e-02
    z[7,3,5]  R2247     -2.5508111715316772e-01
    z[7,3,5]  R2248     -4.9958512187004089e-02
    z[7,3,5]  R2249     0.0769592747092247
    z[7,3,5]  R2250     -1.3457165658473969e-01
    z[7,3,5]  R2251     2.4149735271930695e-01
    z[7,3,5]  R2252     1.6522608697414398e-01
    z[7,3,5]  R2253     4.5957455039024353e-01
    z[7,3,5]  R2254     -1.4389362931251526e-01
    z[7,3,5]  R2255     1.6535639762878418e-01
    z[7,3,5]  R2256     3.1621418893337250e-02
    z[7,3,5]  R2257     -1.0094086080789566e-01
    z[7,3,5]  R2258     0.306438684463501
    z[7,3,5]  R2259     4.3003073334693909e-01
    z[7,3,5]  R2260     5.4396629333496094e-01
    z[7,3,5]  R2261     6.4435862004756927e-02
    z[7,3,5]  R2262     3.2721394300460815e-01
    z[7,3,5]  R2263     -2.8444245457649231e-01
    z[7,3,5]  R2264     -5.0231266021728516e-01
    z[7,3,5]  R2265     -6.2959247827529907e-01
    z[7,3,5]  R2266     3.7279227375984192e-01
    z[7,3,5]  R2267     1.6531041264533997e-01
    z[7,3,5]  R2268     -1.9833190739154816e-01
    z[7,3,5]  R2269     -1.8671898543834686e-01
    z[7,3,5]  R2270     2.3983092606067657e-01
    z[7,3,5]  R2271     9.2646442353725433e-02
    z[7,3,5]  R2272     3.4028777480125427e-01
    z[7,3,5]  R2273     4.1649112105369568e-01
    z[7,3,5]  R2274     8.1165522336959839e-02
    z[7,3,5]  R2275     1.4363476634025574e-01
    z[7,3,5]  R2276     1.0789851844310760e-01
    z[7,3,5]  R2277     -2.3141042888164520e-01
    z[7,3,5]  R2278     -1.7139554023742676e-02
    z[7,3,5]  R2279     -0.318229079246521
    z[7,3,5]  R2280     2.6526167988777161e-01
    z[7,3,5]  R2281     -2.1993994712829590e-01
    z[7,3,5]  R2282     1.5587139129638672e-01
    z[7,3,5]  R2283     3.8067254424095154e-01
    z[7,3,5]  R2284     3.0121762305498123e-02
    z[7,3,5]  R2285     5.5897551774978638e-01
    z[7,3,5]  R2286     2.1398428082466125e-01
    z[7,3,5]  R2287     3.8329538702964783e-01
    z[7,3,5]  R2288     2.9617869853973389e-01
    z[7,3,5]  R2289     0.158024862408638
    z[7,3,5]  R2290     -2.8970161080360413e-01
    z[7,3,5]  R2291     3.5380387306213379e-01
    z[7,3,5]  R2292     3.3629050850868225e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R2182     -1
    z[7,3,6]  R2183     1
    z[7,3,6]  R2184     4.5093291997909546e-01
    z[7,3,6]  R2185     1.8133418262004852e-01
    z[7,3,6]  R2186     2.9193994402885437e-01
    z[7,3,6]  R2187     6.3883143663406372e-01
    z[7,3,6]  R2188     -3.5452902317047119e-01
    z[7,3,6]  R2189     2.6167482137680054e-01
    z[7,3,6]  R2190     3.6023595929145813e-01
    z[7,3,6]  R2191     0.629138171672821
    z[7,3,6]  R2192     3.1355720758438110e-01
    z[7,3,6]  R2193     -1.3416926562786102e-01
    z[7,3,6]  R2194     1.5790063142776489e-01
    z[7,3,6]  R2195     6.7301634699106216e-03
    z[7,3,6]  R2196     2.7205497026443481e-01
    z[7,3,6]  R2197     -1.0560656338930130e-01
    z[7,3,6]  R2198     1.6317966580390930e-01
    z[7,3,6]  R2199     -1.8791554495692253e-02
    z[7,3,6]  R2200     2.9086660593748093e-02
    z[7,3,6]  R2201     7.0451624691486359e-02
    z[7,3,6]  R2202     -7.3795504868030548e-02
    z[7,3,6]  R2203     -7.8698962926864624e-02
    z[7,3,6]  R2204     4.4508766382932663e-02
    z[7,3,6]  R2205     -2.9428917169570923e-01
    z[7,3,6]  R2206     -2.8257521986961365e-01
    z[7,3,6]  R2207     3.6888431757688522e-02
    z[7,3,6]  R2208     5.4996378719806671e-02
    z[7,3,6]  R2209     1.7810256779193878e-01
    z[7,3,6]  R2210     -1.1039060354232788e-01
    z[7,3,6]  R2211     6.9044865667819977e-03
    z[7,3,6]  R2212     1.5340237319469452e-01
    z[7,3,6]  R2213     -3.8018664717674255e-01
    z[7,3,6]  R2214     -3.7175354361534119e-01
    z[7,3,6]  R2215     -2.7003440260887146e-01
    z[7,3,6]  R2216     -1.1532482504844666e-01
    z[7,3,6]  R2217     -2.1410727500915527e-01
    z[7,3,6]  R2218     3.3382120728492737e-01
    z[7,3,6]  R2219     -8.1435024738311768e-02
    z[7,3,6]  R2220     9.2316776514053345e-02
    z[7,3,6]  R2221     4.0257081389427185e-01
    z[7,3,6]  R2222     -6.1611879616975784e-02
    z[7,3,6]  R2223     2.4131615459918976e-01
    z[7,3,6]  R2224     -9.0920627117156982e-02
    z[7,3,6]  R2225     -1.1257733404636383e-01
    z[7,3,6]  R2226     -1.5459421277046204e-01
    z[7,3,6]  R2227     -3.3619552850723267e-01
    z[7,3,6]  R2228     -7.4777096509933472e-02
    z[7,3,6]  R2229     2.9738730192184448e-01
    z[7,3,6]  R2230     4.5432859659194946e-01
    z[7,3,6]  R2231     3.5045480728149414e-01
    z[7,3,6]  R2232     -0.0526314415037632
    z[7,3,6]  R2233     2.6307487487792969e-01
    z[7,3,6]  R2234     6.2678828835487366e-02
    z[7,3,6]  R2235     -3.8197159767150879e-02
    z[7,3,6]  R2236     9.3276090919971466e-02
    z[7,3,6]  R2237     -2.4080686271190643e-02
    z[7,3,6]  R2238     -1.4493295550346375e-01
    z[7,3,6]  R2239     3.5655535757541656e-02
    z[7,3,6]  R2240     0.0522799976170063
    z[7,3,6]  R2241     3.2310735434293747e-02
    z[7,3,6]  R2242     8.5448555648326874e-02
    z[7,3,6]  R2243     1.2455178052186966e-01
    z[7,3,6]  R2244     1.9001878798007965e-01
    z[7,3,6]  R2245     -5.6835031509399414e-01
    z[7,3,6]  R2246     -3.0935180187225342e-01
    z[7,3,6]  R2247     5.9268784523010254e-01
    z[7,3,6]  R2248     8.0272859334945679e-01
    z[7,3,6]  R2249     -4.1821199655532837e-01
    z[7,3,6]  R2250     5.3628188371658325e-01
    z[7,3,6]  R2251     7.5863644480705261e-02
    z[7,3,6]  R2252     3.7423965334892273e-01
    z[7,3,6]  R2253     7.4497717432677746e-03
    z[7,3,6]  R2254     1.6224814951419830e-01
    z[7,3,6]  R2255     -3.0374118685722351e-01
    z[7,3,6]  R2256     -3.4164834022521973e-01
    z[7,3,6]  R2257     6.2955850362777710e-01
    z[7,3,6]  R2258     3.8678586483001709e-01
    z[7,3,6]  R2259     -1.4108885824680328e-01
    z[7,3,6]  R2260     -2.0895342528820038e-01
    z[7,3,6]  R2261     -1.1328030377626419e-01
    z[7,3,6]  R2262     -0.0601862333714962
    z[7,3,6]  R2263     -2.4160975217819214e-01
    z[7,3,6]  R2264     3.6350575089454651e-01
    z[7,3,6]  R2265     1.0825856775045395e-01
    z[7,3,6]  R2266     -5.4732393473386765e-02
    z[7,3,6]  R2267     3.5946875810623169e-01
    z[7,3,6]  R2268     -2.4727845191955566e-01
    z[7,3,6]  R2269     6.0292577743530273e-01
    z[7,3,6]  R2270     -1.4043906331062317e-01
    z[7,3,6]  R2271     3.4061953425407410e-01
    z[7,3,6]  R2272     -0.281399667263031
    z[7,3,6]  R2273     -5.6827016174793243e-02
    z[7,3,6]  R2274     -3.1062424182891846e-01
    z[7,3,6]  R2275     6.1044901609420776e-01
    z[7,3,6]  R2276     1.9057519733905792e-01
    z[7,3,6]  R2277     6.6493093967437744e-01
    z[7,3,6]  R2278     7.8965082764625549e-02
    z[7,3,6]  R2279     7.5730517506599426e-02
    z[7,3,6]  R2280     1.0132216662168503e-01
    z[7,3,6]  R2281     2.6948660612106323e-01
    z[7,3,6]  R2282     -4.2699408531188965e-01
    z[7,3,6]  R2283     1.2564989924430847e-01
    z[7,3,6]  R2284     1.0915504395961761e-01
    z[7,3,6]  R2285     4.7250889241695404e-02
    z[7,3,6]  R2286     -1.4756020903587341e-01
    z[7,3,6]  R2287     -0.0288847703486681
    z[7,3,6]  R2288     -1.6712214052677155e-01
    z[7,3,6]  R2289     -1.6119672358036041e-01
    z[7,3,6]  R2290     1.5063390135765076e-01
    z[7,3,6]  R2291     1.5044826269149780e-01
    z[7,3,6]  R2292     2.8009437024593353e-02
    z[4,7,0]  R38       -1
    z[4,7,0]  R65       1
    z[4,7,0]  R2293     -1
    z[4,7,0]  R2294     1
    z[4,7,0]  R2307     1.1057145148515701e-01
    z[4,7,0]  R2308     4.1727516055107117e-01
    z[4,7,0]  R2309     2.3384353518486023e-01
    z[4,7,0]  R2310     1.9234964251518250e-01
    z[4,7,0]  R2311     5.4365879297256470e-01
    z[4,7,0]  R2312     3.6887899041175842e-01
    z[4,7,0]  R2313     -6.3091731071472168e-01
    z[4,7,0]  R2314     -6.5363544225692749e-01
    z[4,7,0]  R2315     -3.6788159608840942e-01
    z[4,7,0]  R2316     -5.4095560312271118e-01
    z[4,7,0]  R2317     3.3544310927391052e-01
    z[4,7,0]  R2318     0.445083886384964
    z[4,7,0]  R2319     5.9949624538421631e-01
    z[4,7,0]  R2320     -1.0904526337981224e-02
    z[4,7,0]  R2321     -1.9388508796691895e-01
    z[4,7,0]  R2322     -4.3607071042060852e-01
    z[4,7,0]  R2323     -2.3525188863277435e-01
    z[4,7,0]  R2324     -8.3016566932201385e-03
    z[4,7,0]  R2325     -1.6211374104022980e-01
    z[4,7,0]  R2326     -0.299001544713974
    z[4,7,0]  R2327     -4.3869003653526306e-01
    z[4,7,0]  R2328     -3.7246486544609070e-01
    z[4,7,0]  R2329     1.8723241984844208e-01
    z[4,7,0]  R2330     -4.7213220596313477e-01
    z[4,7,0]  R2331     -2.7378988265991211e-01
    z[4,7,0]  R2332     1.4399564266204834e-01
    z[4,7,0]  R2333     -4.4520506262779236e-01
    z[4,7,0]  R2334     -2.6701837778091431e-01
    z[4,7,0]  R2335     2.3060111701488495e-01
    z[4,7,0]  R2336     -1.7048522830009460e-01
    z[4,7,0]  R2337     -2.3564680013805628e-03
    z[4,7,0]  R2338     2.5751056149601936e-02
    z[4,7,0]  R2339     -2.6718097925186157e-01
    z[4,7,0]  R2340     -5.3210258483886719e-01
    z[4,7,0]  R2341     -0.392514169216156
    z[4,7,0]  R2342     -3.9334365725517273e-01
    z[4,7,0]  R2343     -4.2745375633239746e-01
    z[4,7,0]  R2344     0.0908120647072792
    z[4,7,0]  R2345     3.8633909821510315e-01
    z[4,7,0]  R2346     -2.6486802101135254e-01
    z[4,7,0]  R2347     3.5147759318351746e-01
    z[4,7,0]  R2348     4.0883067995309830e-02
    z[4,7,0]  R2349     2.7442533522844315e-02
    z[4,7,0]  R2350     -2.2505679726600647e-01
    z[4,7,0]  R2351     -1.7047492787241936e-02
    z[4,7,0]  R2352     -3.7297993898391724e-01
    z[4,7,0]  R2353     -2.7726629376411438e-01
    z[4,7,0]  R2354     -3.5951441526412964e-01
    z[4,7,0]  R2355     -9.3873977661132812e-02
    z[4,7,0]  R2356     2.9853138327598572e-01
    z[4,7,0]  R2357     -4.2799907922744751e-01
    z[4,7,0]  R2358     -6.0560190677642822e-01
    z[4,7,0]  R2359     -5.3953188657760620e-01
    z[4,7,0]  R2360     -2.5984960794448853e-01
    z[4,7,0]  R2361     -6.4778298139572144e-01
    z[4,7,0]  R2362     -4.1700929403305054e-01
    z[4,7,0]  R2363     -0.385744571685791
    z[4,7,0]  R2364     -1.8221004307270050e-01
    z[4,7,0]  R2365     -4.7696086764335632e-01
    z[4,7,0]  R2366     -3.6791044473648071e-01
    z[4,7,0]  R2367     -3.4008061885833740e-01
    z[4,7,0]  R2368     -2.2818570956587791e-02
    z[4,7,0]  R2369     3.9294874668121338e-01
    z[4,7,0]  R2370     -3.0102510005235672e-02
    z[4,7,0]  R2371     -0.400037944316864
    z[4,7,0]  R2372     -5.7290811091661453e-02
    z[4,7,0]  R2373     -6.6945418715476990e-02
    z[4,7,0]  R2374     -2.1001422405242920e-01
    z[4,7,0]  R2375     -4.1027206182479858e-01
    z[4,7,0]  R2376     -2.4204806983470917e-01
    z[4,7,0]  R2377     4.5590800046920776e-01
    z[4,7,0]  R2378     6.5800681710243225e-02
    z[4,7,0]  R2379     -6.0763758420944214e-01
    z[4,7,0]  R2380     -3.2962110638618469e-01
    z[4,7,0]  R2381     1.6704581677913666e-01
    z[4,7,0]  R2382     -2.8840294480323792e-01
    z[4,7,0]  R2383     -1.5888524055480957e-01
    z[4,7,0]  R2384     1.8819020688533783e-01
    z[4,7,0]  R2385     -6.0815680772066116e-03
    z[4,7,0]  R2386     -3.5370126366615295e-01
    z[4,7,1]  R39       -1
    z[4,7,1]  R66       1
    z[4,7,1]  R2295     -1
    z[4,7,1]  R2296     1
    z[4,7,1]  R2307     0.130645290017128
    z[4,7,1]  R2308     -3.6773982644081116e-01
    z[4,7,1]  R2309     2.6268604397773743e-01
    z[4,7,1]  R2310     -5.1379489898681641e-01
    z[4,7,1]  R2311     2.4627435952425003e-02
    z[4,7,1]  R2312     1.4645354449748993e-01
    z[4,7,1]  R2313     -5.5749481916427612e-01
    z[4,7,1]  R2314     -4.8125651478767395e-01
    z[4,7,1]  R2315     -4.1433036327362061e-01
    z[4,7,1]  R2316     -3.8606163859367371e-01
    z[4,7,1]  R2317     5.6183934211730957e-01
    z[4,7,1]  R2318     2.4856026470661163e-01
    z[4,7,1]  R2319     4.4114881753921509e-01
    z[4,7,1]  R2320     8.5515290498733521e-01
    z[4,7,1]  R2321     0.806327760219574
    z[4,7,1]  R2322     7.7940917015075684e-01
    z[4,7,1]  R2323     -2.1536909043788910e-01
    z[4,7,1]  R2324     -3.5275441408157349e-01
    z[4,7,1]  R2325     -7.1298718452453613e-02
    z[4,7,1]  R2326     -3.2652860879898071e-01
    z[4,7,1]  R2327     -5.2660995721817017e-01
    z[4,7,1]  R2328     -3.6260443925857544e-01
    z[4,7,1]  R2329     -6.5382492542266846e-01
    z[4,7,1]  R2330     2.8144272044301033e-02
    z[4,7,1]  R2331     -2.3942266404628754e-01
    z[4,7,1]  R2332     2.6355481147766113e-01
    z[4,7,1]  R2333     -6.8916711024940014e-03
    z[4,7,1]  R2334     9.4218976795673370e-02
    z[4,7,1]  R2335     -3.7219020724296570e-01
    z[4,7,1]  R2336     -2.7761897444725037e-01
    z[4,7,1]  R2337     1.7800673842430115e-01
    z[4,7,1]  R2338     -2.5634220242500305e-01
    z[4,7,1]  R2339     2.1152906119823456e-01
    z[4,7,1]  R2340     2.9970075935125351e-02
    z[4,7,1]  R2341     -4.8902123235166073e-03
    z[4,7,1]  R2342     -1.8356233835220337e-01
    z[4,7,1]  R2343     -0.253077894449234
    z[4,7,1]  R2344     -5.9396427869796753e-01
    z[4,7,1]  R2345     -3.2510635256767273e-01
    z[4,7,1]  R2346     -1.5003034472465515e-01
    z[4,7,1]  R2347     5.3772604465484619e-01
    z[4,7,1]  R2348     7.2924906015396118e-01
    z[4,7,1]  R2349     9.2543345689773560e-01
    z[4,7,1]  R2350     6.6633814573287964e-01
    z[4,7,1]  R2351     6.6368007659912109e-01
    z[4,7,1]  R2352     0.721071183681488
    z[4,7,1]  R2353     5.9860116243362427e-01
    z[4,7,1]  R2354     4.9381405115127563e-01
    z[4,7,1]  R2355     6.9966787099838257e-01
    z[4,7,1]  R2356     7.3879170417785645e-01
    z[4,7,1]  R2357     -5.5943650007247925e-01
    z[4,7,1]  R2358     -6.1637800931930542e-01
    z[4,7,1]  R2359     -4.9711513519287109e-01
    z[4,7,1]  R2360     -6.9946968555450439e-01
    z[4,7,1]  R2361     -4.3509474396705627e-01
    z[4,7,1]  R2362     -0.527397096157074
    z[4,7,1]  R2363     -6.5380924940109253e-01
    z[4,7,1]  R2364     -3.6172983050346375e-01
    z[4,7,1]  R2365     -6.5000897645950317e-01
    z[4,7,1]  R2366     -4.8431155085563660e-01
    z[4,7,1]  R2367     -8.0435746908187866e-01
    z[4,7,1]  R2368     -8.4212523698806763e-01
    z[4,7,1]  R2369     2.9639837145805359e-01
    z[4,7,1]  R2370     -0.961946427822113
    z[4,7,1]  R2371     -7.6187348365783691e-01
    z[4,7,1]  R2372     -7.0618337392807007e-01
    z[4,7,1]  R2373     -0.890663206577301
    z[4,7,1]  R2374     -7.6029217243194580e-01
    z[4,7,1]  R2375     -8.0137866735458374e-01
    z[4,7,1]  R2376     -7.0838910341262817e-01
    z[4,7,1]  R2377     5.2064180374145508e-01
    z[4,7,1]  R2378     5.1355838775634766e-01
    z[4,7,1]  R2379     4.3847480416297913e-01
    z[4,7,1]  R2380     1.5662458539009094e-01
    z[4,7,1]  R2381     3.8802614808082581e-01
    z[4,7,1]  R2382     -8.2546448707580566e-01
    z[4,7,1]  R2383     -8.1400001049041748e-01
    z[4,7,1]  R2384     -1.3649834692478180e-01
    z[4,7,1]  R2385     -7.3540627956390381e-01
    z[4,7,1]  R2386     -7.2362780570983887e-01
    z[4,7,2]  R40       -1
    z[4,7,2]  R67       1
    z[4,7,2]  R2297     -1
    z[4,7,2]  R2298     1
    z[4,7,2]  R2307     5.3853130340576172e-01
    z[4,7,2]  R2308     4.5679494738578796e-01
    z[4,7,2]  R2309     3.0801385641098022e-01
    z[4,7,2]  R2310     6.5136075019836426e-01
    z[4,7,2]  R2311     -4.6572912484407425e-02
    z[4,7,2]  R2312     -4.5000651478767395e-01
    z[4,7,2]  R2313     -4.6828472614288330e-01
    z[4,7,2]  R2314     -5.4492324590682983e-01
    z[4,7,2]  R2315     -0.384880930185318
    z[4,7,2]  R2316     -2.2524002194404602e-01
    z[4,7,2]  R2317     4.2095446586608887e-01
    z[4,7,2]  R2318     2.4210751056671143e-01
    z[4,7,2]  R2319     -3.2490931451320648e-02
    z[4,7,2]  R2320     -1.3517902791500092e-01
    z[4,7,2]  R2321     -4.4970061630010605e-02
    z[4,7,2]  R2322     6.9062080001458526e-05
    z[4,7,2]  R2323     -3.5839927196502686e-01
    z[4,7,2]  R2324     1.2573441490530968e-02
    z[4,7,2]  R2325     -4.2000892758369446e-01
    z[4,7,2]  R2326     -7.6218426227569580e-02
    z[4,7,2]  R2327     -3.3413589000701904e-01
    z[4,7,2]  R2328     -6.0285800695419312e-01
    z[4,7,2]  R2329     -4.9539190530776978e-01
    z[4,7,2]  R2330     -4.5029523968696594e-01
    z[4,7,2]  R2331     -2.0784315466880798e-01
    z[4,7,2]  R2332     -5.2851992845535278e-01
    z[4,7,2]  R2333     -2.1390576660633087e-01
    z[4,7,2]  R2334     -5.9472084045410156e-01
    z[4,7,2]  R2335     -4.9029859900474548e-01
    z[4,7,2]  R2336     1.1751763522624969e-01
    z[4,7,2]  R2337     -5.4794090986251831e-01
    z[4,7,2]  R2338     -4.1816940903663635e-01
    z[4,7,2]  R2339     -5.2481925487518311e-01
    z[4,7,2]  R2340     -4.2251008749008179e-01
    z[4,7,2]  R2341     -2.9979768395423889e-01
    z[4,7,2]  R2342     -4.4982945919036865e-01
    z[4,7,2]  R2343     -4.6862161159515381e-01
    z[4,7,2]  R2344     -3.9316442608833313e-01
    z[4,7,2]  R2345     -5.0399243831634521e-01
    z[4,7,2]  R2346     -1.1587807536125183e-01
    z[4,7,2]  R2347     -4.1262698173522949e-01
    z[4,7,2]  R2348     0.0496567003428936
    z[4,7,2]  R2349     4.4755268841981888e-02
    z[4,7,2]  R2350     -1.4815372228622437e-01
    z[4,7,2]  R2351     4.2813235521316528e-01
    z[4,7,2]  R2352     4.5968118309974670e-01
    z[4,7,2]  R2353     4.1569215059280396e-01
    z[4,7,2]  R2354     7.5898277573287487e-03
    z[4,7,2]  R2355     4.0898427367210388e-01
    z[4,7,2]  R2356     1.3869714736938477e-01
    z[4,7,2]  R2357     -5.3591018915176392e-01
    z[4,7,2]  R2358     -2.2801041603088379e-01
    z[4,7,2]  R2359     -0.516657292842865
    z[4,7,2]  R2360     -4.0650996565818787e-01
    z[4,7,2]  R2361     -5.9381824731826782e-01
    z[4,7,2]  R2362     -2.7623388171195984e-01
    z[4,7,2]  R2363     -5.0986176729202271e-01
    z[4,7,2]  R2364     -6.9064414501190186e-01
    z[4,7,2]  R2365     -4.5217093825340271e-01
    z[4,7,2]  R2366     -0.56244957447052
    z[4,7,2]  R2367     1.9406144320964813e-01
    z[4,7,2]  R2368     2.8965404629707336e-01
    z[4,7,2]  R2369     3.4909170120954514e-02
    z[4,7,2]  R2370     6.5579958260059357e-02
    z[4,7,2]  R2371     3.9618015289306641e-01
    z[4,7,2]  R2372     -2.8757303953170776e-01
    z[4,7,2]  R2373     1.5739649534225464e-01
    z[4,7,2]  R2374     4.0723752975463867e-01
    z[4,7,2]  R2375     3.6946651339530945e-01
    z[4,7,2]  R2376     2.5820541381835938e-01
    z[4,7,2]  R2377     0.0326387919485569
    z[4,7,2]  R2378     6.7335285246372223e-02
    z[4,7,2]  R2379     2.7764764428138733e-01
    z[4,7,2]  R2380     5.3151077032089233e-01
    z[4,7,2]  R2381     -2.2476732730865479e-01
    z[4,7,2]  R2382     1.9603857398033142e-01
    z[4,7,2]  R2383     -3.0395476147532463e-02
    z[4,7,2]  R2384     1.5812179446220398e-01
    z[4,7,2]  R2385     -1.8200913071632385e-01
    z[4,7,2]  R2386     7.9307332634925842e-03
    z[4,7,3]  R41       -1
    z[4,7,3]  R68       1
    z[4,7,3]  R2299     -1
    z[4,7,3]  R2300     1
    z[4,7,3]  R2307     -6.6944444179534912e-01
    z[4,7,3]  R2308     -2.2743774950504303e-01
    z[4,7,3]  R2309     -6.2280791997909546e-01
    z[4,7,3]  R2310     -2.3109762370586395e-01
    z[4,7,3]  R2311     -0.391855388879776
    z[4,7,3]  R2312     -4.1402736306190491e-01
    z[4,7,3]  R2313     -8.5958838462829590e-02
    z[4,7,3]  R2314     1.1629532277584076e-01
    z[4,7,3]  R2315     -4.0571384131908417e-02
    z[4,7,3]  R2316     2.2374625504016876e-01
    z[4,7,3]  R2317     2.3730051517486572e-01
    z[4,7,3]  R2318     -1.6322648152709007e-02
    z[4,7,3]  R2319     5.9212759137153625e-02
    z[4,7,3]  R2320     -1.0154701769351959e-01
    z[4,7,3]  R2321     -1.0773303359746933e-01
    z[4,7,3]  R2322     2.3034097626805305e-02
    z[4,7,3]  R2323     -4.6928000450134277e-01
    z[4,7,3]  R2324     4.3289911746978760e-01
    z[4,7,3]  R2325     6.4842063188552856e-01
    z[4,7,3]  R2326     5.8338105678558350e-01
    z[4,7,3]  R2327     -1.3787488453090191e-02
    z[4,7,3]  R2328     -2.5685107707977295e-01
    z[4,7,3]  R2329     -1.9629356265068054e-01
    z[4,7,3]  R2330     6.2076830863952637e-01
    z[4,7,3]  R2331     0.618816614151001
    z[4,7,3]  R2332     5.8165395259857178e-01
    z[4,7,3]  R2333     5.9145528078079224e-01
    z[4,7,3]  R2334     5.5927777290344238e-01
    z[4,7,3]  R2335     5.6667649745941162e-01
    z[4,7,3]  R2336     5.4406929016113281e-01
    z[4,7,3]  R2337     6.5865945816040039e-01
    z[4,7,3]  R2338     0.662432074546814
    z[4,7,3]  R2339     6.5003538131713867e-01
    z[4,7,3]  R2340     6.3249212503433228e-01
    z[4,7,3]  R2341     6.2142062187194824e-01
    z[4,7,3]  R2342     6.7430156469345093e-01
    z[4,7,3]  R2343     6.3411563634872437e-01
    z[4,7,3]  R2344     5.6758403778076172e-01
    z[4,7,3]  R2345     5.3503137826919556e-01
    z[4,7,3]  R2346     6.4338076114654541e-01
    z[4,7,3]  R2347     4.5000296831130981e-01
    z[4,7,3]  R2348     6.3621246814727783e-01
    z[4,7,3]  R2349     -1.7492806538939476e-02
    z[4,7,3]  R2350     2.7972223237156868e-02
    z[4,7,3]  R2351     3.7851759791374207e-01
    z[4,7,3]  R2352     1.3253663666546345e-02
    z[4,7,3]  R2353     4.3476754426956177e-01
    z[4,7,3]  R2354     4.7934412956237793e-01
    z[4,7,3]  R2355     1.6339744627475739e-01
    z[4,7,3]  R2356     4.8957455158233643e-01
    z[4,7,3]  R2357     -1.4709731936454773e-01
    z[4,7,3]  R2358     -2.5882723927497864e-01
    z[4,7,3]  R2359     -2.1688246726989746e-01
    z[4,7,3]  R2360     -4.6647912263870239e-01
    z[4,7,3]  R2361     -8.3207428455352783e-02
    z[4,7,3]  R2362     -5.6877774000167847e-01
    z[4,7,3]  R2363     -3.0903410911560059e-01
    z[4,7,3]  R2364     -4.6563339233398438e-01
    z[4,7,3]  R2365     -3.3741500973701477e-01
    z[4,7,3]  R2366     -5.4462337493896484e-01
    z[4,7,3]  R2367     -1.7232039570808411e-01
    z[4,7,3]  R2368     -2.1759833395481110e-01
    z[4,7,3]  R2369     -6.5985542535781860e-01
    z[4,7,3]  R2370     2.0762298256158829e-02
    z[4,7,3]  R2371     -7.8155420720577240e-02
    z[4,7,3]  R2372     -0.406417578458786
    z[4,7,3]  R2373     6.5221287310123444e-02
    z[4,7,3]  R2374     0.0881512239575386
    z[4,7,3]  R2375     1.3524082303047180e-01
    z[4,7,3]  R2376     -2.6688039302825928e-01
    z[4,7,3]  R2377     0.33226278424263
    z[4,7,3]  R2378     3.9146417379379272e-01
    z[4,7,3]  R2379     -8.0085076391696930e-02
    z[4,7,3]  R2380     1.9872041046619415e-01
    z[4,7,3]  R2381     -4.8493242263793945e-01
    z[4,7,3]  R2382     -4.0307980775833130e-01
    z[4,7,3]  R2383     -4.5969793200492859e-01
    z[4,7,3]  R2384     7.2684627771377563e-01
    z[4,7,3]  R2385     -6.3669097423553467e-01
    z[4,7,3]  R2386     -0.288517564535141
    z[4,7,4]  R42       -1
    z[4,7,4]  R69       1
    z[4,7,4]  R2301     -1
    z[4,7,4]  R2302     1
    z[4,7,4]  R2307     -3.7347182631492615e-01
    z[4,7,4]  R2308     -4.3055397272109985e-01
    z[4,7,4]  R2309     2.2676877677440643e-02
    z[4,7,4]  R2310     -7.1557931602001190e-02
    z[4,7,4]  R2311     -6.9433611631393433e-01
    z[4,7,4]  R2312     -5.7911306619644165e-01
    z[4,7,4]  R2313     -0.0732896476984024
    z[4,7,4]  R2314     -1.2858195602893829e-01
    z[4,7,4]  R2315     -4.0163826942443848e-01
    z[4,7,4]  R2316     -6.4065003395080566e-01
    z[4,7,4]  R2317     2.7452877163887024e-01
    z[4,7,4]  R2318     4.4084548950195312e-01
    z[4,7,4]  R2319     5.1864463090896606e-01
    z[4,7,4]  R2320     2.4805767834186554e-01
    z[4,7,4]  R2321     -4.6411193907260895e-02
    z[4,7,4]  R2322     0.329597145318985
    z[4,7,4]  R2323     -1.4363935589790344e-01
    z[4,7,4]  R2324     7.1478348970413208e-01
    z[4,7,4]  R2325     5.4629105329513550e-01
    z[4,7,4]  R2326     5.3774231672286987e-01
    z[4,7,4]  R2327     -4.0136259794235229e-01
    z[4,7,4]  R2328     2.0788341760635376e-02
    z[4,7,4]  R2329     4.5161384344100952e-01
    z[4,7,4]  R2330     4.1718937456607819e-02
    z[4,7,4]  R2331     -0.203811913728714
    z[4,7,4]  R2332     1.4877521991729736e-01
    z[4,7,4]  R2333     -2.0560060441493988e-01
    z[4,7,4]  R2334     2.3319673538208008e-01
    z[4,7,4]  R2335     1.9234456121921539e-01
    z[4,7,4]  R2336     6.6936874389648438e-01
    z[4,7,4]  R2337     1.0328670591115952e-01
    z[4,7,4]  R2338     5.5827479809522629e-02
    z[4,7,4]  R2339     0.00386149063706398
    z[4,7,4]  R2340     1.9641930237412453e-02
    z[4,7,4]  R2341     -1.2796667218208313e-01
    z[4,7,4]  R2342     5.3986251354217529e-02
    z[4,7,4]  R2343     1.5775239467620850e-01
    z[4,7,4]  R2344     -3.1440962105989456e-02
    z[4,7,4]  R2345     1.8580880761146545e-01
    z[4,7,4]  R2346     6.8503051996231079e-01
    z[4,7,4]  R2347     1.3001147657632828e-02
    z[4,7,4]  R2348     -8.7179347872734070e-02
    z[4,7,4]  R2349     1.6161532700061798e-01
    z[4,7,4]  R2350     2.5822514295578003e-01
    z[4,7,4]  R2351     -2.0004893839359283e-01
    z[4,7,4]  R2352     -2.4194066226482391e-01
    z[4,7,4]  R2353     2.6647615432739258e-01
    z[4,7,4]  R2354     -7.0569347590208054e-03
    z[4,7,4]  R2355     -0.457533061504364
    z[4,7,4]  R2356     2.6290962100028992e-01
    z[4,7,4]  R2357     -4.0289908647537231e-01
    z[4,7,4]  R2358     -3.5442799329757690e-01
    z[4,7,4]  R2359     -1.9329233467578888e-01
    z[4,7,4]  R2360     -2.1037788689136505e-01
    z[4,7,4]  R2361     -6.5850298851728439e-03
    z[4,7,4]  R2362     -3.7085208296775818e-01
    z[4,7,4]  R2363     6.4554825425148010e-02
    z[4,7,4]  R2364     -3.6159214377403259e-01
    z[4,7,4]  R2365     5.0317924469709396e-02
    z[4,7,4]  R2366     2.5089766830205917e-02
    z[4,7,4]  R2367     3.2245415449142456e-01
    z[4,7,4]  R2368     2.0978122949600220e-01
    z[4,7,4]  R2369     -4.8044338822364807e-01
    z[4,7,4]  R2370     -2.4499568343162537e-01
    z[4,7,4]  R2371     2.1332244575023651e-01
    z[4,7,4]  R2372     2.6873627305030823e-01
    z[4,7,4]  R2373     4.2627118527889252e-03
    z[4,7,4]  R2374     4.1220989823341370e-01
    z[4,7,4]  R2375     1.0254800319671631e-01
    z[4,7,4]  R2376     -3.0259862542152405e-01
    z[4,7,4]  R2377     4.2819178104400635e-01
    z[4,7,4]  R2378     -0.486828088760376
    z[4,7,4]  R2379     1.7520861327648163e-01
    z[4,7,4]  R2380     6.8648862838745117e-01
    z[4,7,4]  R2381     -5.6398731470108032e-01
    z[4,7,4]  R2382     2.6229554787278175e-02
    z[4,7,4]  R2383     2.8796127438545227e-01
    z[4,7,4]  R2384     3.1456348299980164e-01
    z[4,7,4]  R2385     -4.3707441538572311e-02
    z[4,7,4]  R2386     -4.1453507542610168e-01
    z[4,7,5]  R43       -1
    z[4,7,5]  R70       1
    z[4,7,5]  R2303     -1
    z[4,7,5]  R2304     1
    z[4,7,5]  R2307     3.0502617359161377e-01
    z[4,7,5]  R2308     4.9484741687774658e-01
    z[4,7,5]  R2309     2.5460910797119141e-01
    z[4,7,5]  R2310     3.3628630638122559e-01
    z[4,7,5]  R2311     -1.0812437534332275e-01
    z[4,7,5]  R2312     3.5929408669471741e-01
    z[4,7,5]  R2313     0.0888829231262207
    z[4,7,5]  R2314     6.2359537929296494e-02
    z[4,7,5]  R2315     -8.1958241760730743e-02
    z[4,7,5]  R2316     1.0259815305471420e-01
    z[4,7,5]  R2317     -4.0154001116752625e-01
    z[4,7,5]  R2318     -0.666703999042511
    z[4,7,5]  R2319     1.5759790316224098e-02
    z[4,7,5]  R2320     -1.9583757221698761e-01
    z[4,7,5]  R2321     -5.0340473651885986e-01
    z[4,7,5]  R2322     1.3030278682708740e-01
    z[4,7,5]  R2323     -7.1038591861724854e-01
    z[4,7,5]  R2324     -5.6272368878126144e-02
    z[4,7,5]  R2325     -2.5221112370491028e-01
    z[4,7,5]  R2326     -1.6141898930072784e-01
    z[4,7,5]  R2327     -0.500432014465332
    z[4,7,5]  R2328     -5.0948232412338257e-01
    z[4,7,5]  R2329     -2.1376492083072662e-01
    z[4,7,5]  R2330     -4.3151828646659851e-01
    z[4,7,5]  R2331     -0.416143000125885
    z[4,7,5]  R2332     8.0096609890460968e-02
    z[4,7,5]  R2333     4.8506391048431396e-01
    z[4,7,5]  R2334     1.5715818107128143e-01
    z[4,7,5]  R2335     4.4791880249977112e-01
    z[4,7,5]  R2336     1.6610497608780861e-02
    z[4,7,5]  R2337     8.6551554501056671e-02
    z[4,7,5]  R2338     4.0178185701370239e-01
    z[4,7,5]  R2339     2.5812906026840210e-01
    z[4,7,5]  R2340     7.6234221458435059e-02
    z[4,7,5]  R2341     -5.8103847503662109e-01
    z[4,7,5]  R2342     -5.1187396049499512e-02
    z[4,7,5]  R2343     -9.4732657074928284e-02
    z[4,7,5]  R2344     -9.8502397537231445e-02
    z[4,7,5]  R2345     -2.8530222177505493e-01
    z[4,7,5]  R2346     -9.2689990997314453e-02
    z[4,7,5]  R2347     -1.0507623106241226e-01
    z[4,7,5]  R2348     -1.3714969158172607e-01
    z[4,7,5]  R2349     1.7076972126960754e-01
    z[4,7,5]  R2350     -8.8459923863410950e-02
    z[4,7,5]  R2351     0.258756548166275
    z[4,7,5]  R2352     -4.9505833536386490e-02
    z[4,7,5]  R2353     4.6881463378667831e-02
    z[4,7,5]  R2354     -3.4698281437158585e-02
    z[4,7,5]  R2355     5.5712736211717129e-03
    z[4,7,5]  R2356     1.3792365789413452e-01
    z[4,7,5]  R2357     8.8033504784107208e-02
    z[4,7,5]  R2358     -9.3164615333080292e-02
    z[4,7,5]  R2359     -1.9087509810924530e-01
    z[4,7,5]  R2360     7.0396237075328827e-02
    z[4,7,5]  R2361     6.9680221378803253e-02
    z[4,7,5]  R2362     1.0128123313188553e-01
    z[4,7,5]  R2363     2.5151568651199341e-01
    z[4,7,5]  R2364     8.0217964947223663e-02
    z[4,7,5]  R2365     -1.5398536622524261e-01
    z[4,7,5]  R2366     -1.0147435218095779e-01
    z[4,7,5]  R2367     -2.5306597352027893e-01
    z[4,7,5]  R2368     1.6864615678787231e-01
    z[4,7,5]  R2369     -1.0216084867715836e-01
    z[4,7,5]  R2370     -8.7392807006835938e-02
    z[4,7,5]  R2371     2.1890738606452942e-01
    z[4,7,5]  R2372     -3.8237354159355164e-01
    z[4,7,5]  R2373     -4.0125495195388794e-01
    z[4,7,5]  R2374     1.8512722849845886e-01
    z[4,7,5]  R2375     -2.5003109127283096e-02
    z[4,7,5]  R2376     -2.5611430406570435e-01
    z[4,7,5]  R2377     -2.9676118493080139e-01
    z[4,7,5]  R2378     -5.1403272151947021e-01
    z[4,7,5]  R2379     -5.5768877267837524e-01
    z[4,7,5]  R2380     -0.166483074426651
    z[4,7,5]  R2381     -3.2608771324157715e-01
    z[4,7,5]  R2382     1.6494846343994141e-01
    z[4,7,5]  R2383     9.2028222978115082e-02
    z[4,7,5]  R2384     0.362809956073761
    z[4,7,5]  R2385     1.2219491600990295e-01
    z[4,7,5]  R2386     1.9462847709655762e-01
    z[4,7,6]  R44       -1
    z[4,7,6]  R71       1
    z[4,7,6]  R2305     -1
    z[4,7,6]  R2306     1
    z[4,7,6]  R2307     3.4300554543733597e-03
    z[4,7,6]  R2308     -2.9553198255598545e-03
    z[4,7,6]  R2309     5.7289695739746094e-01
    z[4,7,6]  R2310     -3.2113909721374512e-01
    z[4,7,6]  R2311     2.3305638134479523e-01
    z[4,7,6]  R2312     -6.3961118459701538e-02
    z[4,7,6]  R2313     2.2625601291656494e-01
    z[4,7,6]  R2314     -1.0131567716598511e-01
    z[4,7,6]  R2315     6.1252242326736450e-01
    z[4,7,6]  R2316     1.9123022258281708e-01
    z[4,7,6]  R2317     -3.1890419125556946e-01
    z[4,7,6]  R2318     -2.0590442419052124e-01
    z[4,7,6]  R2319     -0.414957195520401
    z[4,7,6]  R2320     -3.7433198094367981e-01
    z[4,7,6]  R2321     -2.0747286081314087e-01
    z[4,7,6]  R2322     -2.7607965469360352e-01
    z[4,7,6]  R2323     1.5594394505023956e-01
    z[4,7,6]  R2324     4.1695764660835266e-01
    z[4,7,6]  R2325     9.8663009703159332e-02
    z[4,7,6]  R2326     3.7763953208923340e-01
    z[4,7,6]  R2327     -8.2898207008838654e-02
    z[4,7,6]  R2328     -2.0093081891536713e-01
    z[4,7,6]  R2329     0.0621473453938961
    z[4,7,6]  R2330     1.5214161947369576e-02
    z[4,7,6]  R2331     -4.7630748152732849e-01
    z[4,7,6]  R2332     5.1341992616653442e-01
    z[4,7,6]  R2333     -3.5862424969673157e-01
    z[4,7,6]  R2334     0.41744464635849
    z[4,7,6]  R2335     9.5681458711624146e-02
    z[4,7,6]  R2336     3.6838880181312561e-01
    z[4,7,6]  R2337     4.6484112739562988e-01
    z[4,7,6]  R2338     3.9420583844184875e-01
    z[4,7,6]  R2339     3.4531581401824951e-01
    z[4,7,6]  R2340     -3.6222934722900391e-01
    z[4,7,6]  R2341     -1.2603670358657837e-01
    z[4,7,6]  R2342     -3.8603344559669495e-01
    z[4,7,6]  R2343     3.1251555681228638e-01
    z[4,7,6]  R2344     -3.8927948474884033e-01
    z[4,7,6]  R2345     2.9809162020683289e-01
    z[4,7,6]  R2346     -4.5947216451168060e-02
    z[4,7,6]  R2347     4.5093291997909546e-01
    z[4,7,6]  R2348     1.8133418262004852e-01
    z[4,7,6]  R2349     2.9193994402885437e-01
    z[4,7,6]  R2350     6.3883143663406372e-01
    z[4,7,6]  R2351     -3.5452902317047119e-01
    z[4,7,6]  R2352     2.6167482137680054e-01
    z[4,7,6]  R2353     3.6023595929145813e-01
    z[4,7,6]  R2354     0.629138171672821
    z[4,7,6]  R2355     3.1355720758438110e-01
    z[4,7,6]  R2356     -1.3416926562786102e-01
    z[4,7,6]  R2357     1.5790063142776489e-01
    z[4,7,6]  R2358     6.7301634699106216e-03
    z[4,7,6]  R2359     2.7205497026443481e-01
    z[4,7,6]  R2360     -1.0560656338930130e-01
    z[4,7,6]  R2361     1.6317966580390930e-01
    z[4,7,6]  R2362     -1.8791554495692253e-02
    z[4,7,6]  R2363     2.9086660593748093e-02
    z[4,7,6]  R2364     7.0451624691486359e-02
    z[4,7,6]  R2365     -7.3795504868030548e-02
    z[4,7,6]  R2366     -7.8698962926864624e-02
    z[4,7,6]  R2367     4.4508766382932663e-02
    z[4,7,6]  R2368     -2.9428917169570923e-01
    z[4,7,6]  R2369     -2.8257521986961365e-01
    z[4,7,6]  R2370     3.6888431757688522e-02
    z[4,7,6]  R2371     5.4996378719806671e-02
    z[4,7,6]  R2372     1.7810256779193878e-01
    z[4,7,6]  R2373     -1.1039060354232788e-01
    z[4,7,6]  R2374     6.9044865667819977e-03
    z[4,7,6]  R2375     1.5340237319469452e-01
    z[4,7,6]  R2376     -3.8018664717674255e-01
    z[4,7,6]  R2377     -3.7175354361534119e-01
    z[4,7,6]  R2378     -2.7003440260887146e-01
    z[4,7,6]  R2379     -1.1532482504844666e-01
    z[4,7,6]  R2380     -2.1410727500915527e-01
    z[4,7,6]  R2381     3.3382120728492737e-01
    z[4,7,6]  R2382     -8.1435024738311768e-02
    z[4,7,6]  R2383     9.2316776514053345e-02
    z[4,7,6]  R2384     4.0257081389427185e-01
    z[4,7,6]  R2385     -6.1611879616975784e-02
    z[4,7,6]  R2386     2.4131615459918976e-01
    z[7,4,0]  R38       1
    z[7,4,0]  R65       -1
    z[7,4,0]  R2387     -1
    z[7,4,0]  R2388     1
    z[7,4,0]  R2401     3.5147759318351746e-01
    z[7,4,0]  R2402     4.0883067995309830e-02
    z[7,4,0]  R2403     2.7442533522844315e-02
    z[7,4,0]  R2404     -2.2505679726600647e-01
    z[7,4,0]  R2405     -1.7047492787241936e-02
    z[7,4,0]  R2406     -3.7297993898391724e-01
    z[7,4,0]  R2407     -2.7726629376411438e-01
    z[7,4,0]  R2408     -3.5951441526412964e-01
    z[7,4,0]  R2409     -9.3873977661132812e-02
    z[7,4,0]  R2410     2.9853138327598572e-01
    z[7,4,0]  R2411     -4.2799907922744751e-01
    z[7,4,0]  R2412     -6.0560190677642822e-01
    z[7,4,0]  R2413     -5.3953188657760620e-01
    z[7,4,0]  R2414     -2.5984960794448853e-01
    z[7,4,0]  R2415     -6.4778298139572144e-01
    z[7,4,0]  R2416     -4.1700929403305054e-01
    z[7,4,0]  R2417     -0.385744571685791
    z[7,4,0]  R2418     -1.8221004307270050e-01
    z[7,4,0]  R2419     -4.7696086764335632e-01
    z[7,4,0]  R2420     -3.6791044473648071e-01
    z[7,4,0]  R2421     -3.4008061885833740e-01
    z[7,4,0]  R2422     -2.2818570956587791e-02
    z[7,4,0]  R2423     3.9294874668121338e-01
    z[7,4,0]  R2424     -3.0102510005235672e-02
    z[7,4,0]  R2425     -0.400037944316864
    z[7,4,0]  R2426     -5.7290811091661453e-02
    z[7,4,0]  R2427     -6.6945418715476990e-02
    z[7,4,0]  R2428     -2.1001422405242920e-01
    z[7,4,0]  R2429     -4.1027206182479858e-01
    z[7,4,0]  R2430     -2.4204806983470917e-01
    z[7,4,0]  R2431     4.5590800046920776e-01
    z[7,4,0]  R2432     6.5800681710243225e-02
    z[7,4,0]  R2433     -6.0763758420944214e-01
    z[7,4,0]  R2434     -3.2962110638618469e-01
    z[7,4,0]  R2435     1.6704581677913666e-01
    z[7,4,0]  R2436     -2.8840294480323792e-01
    z[7,4,0]  R2437     -1.5888524055480957e-01
    z[7,4,0]  R2438     1.8819020688533783e-01
    z[7,4,0]  R2439     -6.0815680772066116e-03
    z[7,4,0]  R2440     -3.5370126366615295e-01
    z[7,4,0]  R2441     1.1057145148515701e-01
    z[7,4,0]  R2442     4.1727516055107117e-01
    z[7,4,0]  R2443     2.3384353518486023e-01
    z[7,4,0]  R2444     1.9234964251518250e-01
    z[7,4,0]  R2445     5.4365879297256470e-01
    z[7,4,0]  R2446     3.6887899041175842e-01
    z[7,4,0]  R2447     -6.3091731071472168e-01
    z[7,4,0]  R2448     -6.5363544225692749e-01
    z[7,4,0]  R2449     -3.6788159608840942e-01
    z[7,4,0]  R2450     -5.4095560312271118e-01
    z[7,4,0]  R2451     3.3544310927391052e-01
    z[7,4,0]  R2452     0.445083886384964
    z[7,4,0]  R2453     5.9949624538421631e-01
    z[7,4,0]  R2454     -1.0904526337981224e-02
    z[7,4,0]  R2455     -1.9388508796691895e-01
    z[7,4,0]  R2456     -4.3607071042060852e-01
    z[7,4,0]  R2457     -2.3525188863277435e-01
    z[7,4,0]  R2458     -8.3016566932201385e-03
    z[7,4,0]  R2459     -1.6211374104022980e-01
    z[7,4,0]  R2460     -0.299001544713974
    z[7,4,0]  R2461     -4.3869003653526306e-01
    z[7,4,0]  R2462     -3.7246486544609070e-01
    z[7,4,0]  R2463     1.8723241984844208e-01
    z[7,4,0]  R2464     -4.7213220596313477e-01
    z[7,4,0]  R2465     -2.7378988265991211e-01
    z[7,4,0]  R2466     1.4399564266204834e-01
    z[7,4,0]  R2467     -4.4520506262779236e-01
    z[7,4,0]  R2468     -2.6701837778091431e-01
    z[7,4,0]  R2469     2.3060111701488495e-01
    z[7,4,0]  R2470     -1.7048522830009460e-01
    z[7,4,0]  R2471     -2.3564680013805628e-03
    z[7,4,0]  R2472     2.5751056149601936e-02
    z[7,4,0]  R2473     -2.6718097925186157e-01
    z[7,4,0]  R2474     -5.3210258483886719e-01
    z[7,4,0]  R2475     -0.392514169216156
    z[7,4,0]  R2476     -3.9334365725517273e-01
    z[7,4,0]  R2477     -4.2745375633239746e-01
    z[7,4,0]  R2478     0.0908120647072792
    z[7,4,0]  R2479     3.8633909821510315e-01
    z[7,4,0]  R2480     -2.6486802101135254e-01
    z[7,4,1]  R39       1
    z[7,4,1]  R66       -1
    z[7,4,1]  R2389     -1
    z[7,4,1]  R2390     1
    z[7,4,1]  R2401     5.3772604465484619e-01
    z[7,4,1]  R2402     7.2924906015396118e-01
    z[7,4,1]  R2403     9.2543345689773560e-01
    z[7,4,1]  R2404     6.6633814573287964e-01
    z[7,4,1]  R2405     6.6368007659912109e-01
    z[7,4,1]  R2406     0.721071183681488
    z[7,4,1]  R2407     5.9860116243362427e-01
    z[7,4,1]  R2408     4.9381405115127563e-01
    z[7,4,1]  R2409     6.9966787099838257e-01
    z[7,4,1]  R2410     7.3879170417785645e-01
    z[7,4,1]  R2411     -5.5943650007247925e-01
    z[7,4,1]  R2412     -6.1637800931930542e-01
    z[7,4,1]  R2413     -4.9711513519287109e-01
    z[7,4,1]  R2414     -6.9946968555450439e-01
    z[7,4,1]  R2415     -4.3509474396705627e-01
    z[7,4,1]  R2416     -0.527397096157074
    z[7,4,1]  R2417     -6.5380924940109253e-01
    z[7,4,1]  R2418     -3.6172983050346375e-01
    z[7,4,1]  R2419     -6.5000897645950317e-01
    z[7,4,1]  R2420     -4.8431155085563660e-01
    z[7,4,1]  R2421     -8.0435746908187866e-01
    z[7,4,1]  R2422     -8.4212523698806763e-01
    z[7,4,1]  R2423     2.9639837145805359e-01
    z[7,4,1]  R2424     -0.961946427822113
    z[7,4,1]  R2425     -7.6187348365783691e-01
    z[7,4,1]  R2426     -7.0618337392807007e-01
    z[7,4,1]  R2427     -0.890663206577301
    z[7,4,1]  R2428     -7.6029217243194580e-01
    z[7,4,1]  R2429     -8.0137866735458374e-01
    z[7,4,1]  R2430     -7.0838910341262817e-01
    z[7,4,1]  R2431     5.2064180374145508e-01
    z[7,4,1]  R2432     5.1355838775634766e-01
    z[7,4,1]  R2433     4.3847480416297913e-01
    z[7,4,1]  R2434     1.5662458539009094e-01
    z[7,4,1]  R2435     3.8802614808082581e-01
    z[7,4,1]  R2436     -8.2546448707580566e-01
    z[7,4,1]  R2437     -8.1400001049041748e-01
    z[7,4,1]  R2438     -1.3649834692478180e-01
    z[7,4,1]  R2439     -7.3540627956390381e-01
    z[7,4,1]  R2440     -7.2362780570983887e-01
    z[7,4,1]  R2441     0.130645290017128
    z[7,4,1]  R2442     -3.6773982644081116e-01
    z[7,4,1]  R2443     2.6268604397773743e-01
    z[7,4,1]  R2444     -5.1379489898681641e-01
    z[7,4,1]  R2445     2.4627435952425003e-02
    z[7,4,1]  R2446     1.4645354449748993e-01
    z[7,4,1]  R2447     -5.5749481916427612e-01
    z[7,4,1]  R2448     -4.8125651478767395e-01
    z[7,4,1]  R2449     -4.1433036327362061e-01
    z[7,4,1]  R2450     -3.8606163859367371e-01
    z[7,4,1]  R2451     5.6183934211730957e-01
    z[7,4,1]  R2452     2.4856026470661163e-01
    z[7,4,1]  R2453     4.4114881753921509e-01
    z[7,4,1]  R2454     8.5515290498733521e-01
    z[7,4,1]  R2455     0.806327760219574
    z[7,4,1]  R2456     7.7940917015075684e-01
    z[7,4,1]  R2457     -2.1536909043788910e-01
    z[7,4,1]  R2458     -3.5275441408157349e-01
    z[7,4,1]  R2459     -7.1298718452453613e-02
    z[7,4,1]  R2460     -3.2652860879898071e-01
    z[7,4,1]  R2461     -5.2660995721817017e-01
    z[7,4,1]  R2462     -3.6260443925857544e-01
    z[7,4,1]  R2463     -6.5382492542266846e-01
    z[7,4,1]  R2464     2.8144272044301033e-02
    z[7,4,1]  R2465     -2.3942266404628754e-01
    z[7,4,1]  R2466     2.6355481147766113e-01
    z[7,4,1]  R2467     -6.8916711024940014e-03
    z[7,4,1]  R2468     9.4218976795673370e-02
    z[7,4,1]  R2469     -3.7219020724296570e-01
    z[7,4,1]  R2470     -2.7761897444725037e-01
    z[7,4,1]  R2471     1.7800673842430115e-01
    z[7,4,1]  R2472     -2.5634220242500305e-01
    z[7,4,1]  R2473     2.1152906119823456e-01
    z[7,4,1]  R2474     2.9970075935125351e-02
    z[7,4,1]  R2475     -4.8902123235166073e-03
    z[7,4,1]  R2476     -1.8356233835220337e-01
    z[7,4,1]  R2477     -0.253077894449234
    z[7,4,1]  R2478     -5.9396427869796753e-01
    z[7,4,1]  R2479     -3.2510635256767273e-01
    z[7,4,1]  R2480     -1.5003034472465515e-01
    z[7,4,2]  R40       1
    z[7,4,2]  R67       -1
    z[7,4,2]  R2391     -1
    z[7,4,2]  R2392     1
    z[7,4,2]  R2401     -4.1262698173522949e-01
    z[7,4,2]  R2402     0.0496567003428936
    z[7,4,2]  R2403     4.4755268841981888e-02
    z[7,4,2]  R2404     -1.4815372228622437e-01
    z[7,4,2]  R2405     4.2813235521316528e-01
    z[7,4,2]  R2406     4.5968118309974670e-01
    z[7,4,2]  R2407     4.1569215059280396e-01
    z[7,4,2]  R2408     7.5898277573287487e-03
    z[7,4,2]  R2409     4.0898427367210388e-01
    z[7,4,2]  R2410     1.3869714736938477e-01
    z[7,4,2]  R2411     -5.3591018915176392e-01
    z[7,4,2]  R2412     -2.2801041603088379e-01
    z[7,4,2]  R2413     -0.516657292842865
    z[7,4,2]  R2414     -4.0650996565818787e-01
    z[7,4,2]  R2415     -5.9381824731826782e-01
    z[7,4,2]  R2416     -2.7623388171195984e-01
    z[7,4,2]  R2417     -5.0986176729202271e-01
    z[7,4,2]  R2418     -6.9064414501190186e-01
    z[7,4,2]  R2419     -4.5217093825340271e-01
    z[7,4,2]  R2420     -0.56244957447052
    z[7,4,2]  R2421     1.9406144320964813e-01
    z[7,4,2]  R2422     2.8965404629707336e-01
    z[7,4,2]  R2423     3.4909170120954514e-02
    z[7,4,2]  R2424     6.5579958260059357e-02
    z[7,4,2]  R2425     3.9618015289306641e-01
    z[7,4,2]  R2426     -2.8757303953170776e-01
    z[7,4,2]  R2427     1.5739649534225464e-01
    z[7,4,2]  R2428     4.0723752975463867e-01
    z[7,4,2]  R2429     3.6946651339530945e-01
    z[7,4,2]  R2430     2.5820541381835938e-01
    z[7,4,2]  R2431     0.0326387919485569
    z[7,4,2]  R2432     6.7335285246372223e-02
    z[7,4,2]  R2433     2.7764764428138733e-01
    z[7,4,2]  R2434     5.3151077032089233e-01
    z[7,4,2]  R2435     -2.2476732730865479e-01
    z[7,4,2]  R2436     1.9603857398033142e-01
    z[7,4,2]  R2437     -3.0395476147532463e-02
    z[7,4,2]  R2438     1.5812179446220398e-01
    z[7,4,2]  R2439     -1.8200913071632385e-01
    z[7,4,2]  R2440     7.9307332634925842e-03
    z[7,4,2]  R2441     5.3853130340576172e-01
    z[7,4,2]  R2442     4.5679494738578796e-01
    z[7,4,2]  R2443     3.0801385641098022e-01
    z[7,4,2]  R2444     6.5136075019836426e-01
    z[7,4,2]  R2445     -4.6572912484407425e-02
    z[7,4,2]  R2446     -4.5000651478767395e-01
    z[7,4,2]  R2447     -4.6828472614288330e-01
    z[7,4,2]  R2448     -5.4492324590682983e-01
    z[7,4,2]  R2449     -0.384880930185318
    z[7,4,2]  R2450     -2.2524002194404602e-01
    z[7,4,2]  R2451     4.2095446586608887e-01
    z[7,4,2]  R2452     2.4210751056671143e-01
    z[7,4,2]  R2453     -3.2490931451320648e-02
    z[7,4,2]  R2454     -1.3517902791500092e-01
    z[7,4,2]  R2455     -4.4970061630010605e-02
    z[7,4,2]  R2456     6.9062080001458526e-05
    z[7,4,2]  R2457     -3.5839927196502686e-01
    z[7,4,2]  R2458     1.2573441490530968e-02
    z[7,4,2]  R2459     -4.2000892758369446e-01
    z[7,4,2]  R2460     -7.6218426227569580e-02
    z[7,4,2]  R2461     -3.3413589000701904e-01
    z[7,4,2]  R2462     -6.0285800695419312e-01
    z[7,4,2]  R2463     -4.9539190530776978e-01
    z[7,4,2]  R2464     -4.5029523968696594e-01
    z[7,4,2]  R2465     -2.0784315466880798e-01
    z[7,4,2]  R2466     -5.2851992845535278e-01
    z[7,4,2]  R2467     -2.1390576660633087e-01
    z[7,4,2]  R2468     -5.9472084045410156e-01
    z[7,4,2]  R2469     -4.9029859900474548e-01
    z[7,4,2]  R2470     1.1751763522624969e-01
    z[7,4,2]  R2471     -5.4794090986251831e-01
    z[7,4,2]  R2472     -4.1816940903663635e-01
    z[7,4,2]  R2473     -5.2481925487518311e-01
    z[7,4,2]  R2474     -4.2251008749008179e-01
    z[7,4,2]  R2475     -2.9979768395423889e-01
    z[7,4,2]  R2476     -4.4982945919036865e-01
    z[7,4,2]  R2477     -4.6862161159515381e-01
    z[7,4,2]  R2478     -3.9316442608833313e-01
    z[7,4,2]  R2479     -5.0399243831634521e-01
    z[7,4,2]  R2480     -1.1587807536125183e-01
    z[7,4,3]  R41       1
    z[7,4,3]  R68       -1
    z[7,4,3]  R2393     -1
    z[7,4,3]  R2394     1
    z[7,4,3]  R2401     4.5000296831130981e-01
    z[7,4,3]  R2402     6.3621246814727783e-01
    z[7,4,3]  R2403     -1.7492806538939476e-02
    z[7,4,3]  R2404     2.7972223237156868e-02
    z[7,4,3]  R2405     3.7851759791374207e-01
    z[7,4,3]  R2406     1.3253663666546345e-02
    z[7,4,3]  R2407     4.3476754426956177e-01
    z[7,4,3]  R2408     4.7934412956237793e-01
    z[7,4,3]  R2409     1.6339744627475739e-01
    z[7,4,3]  R2410     4.8957455158233643e-01
    z[7,4,3]  R2411     -1.4709731936454773e-01
    z[7,4,3]  R2412     -2.5882723927497864e-01
    z[7,4,3]  R2413     -2.1688246726989746e-01
    z[7,4,3]  R2414     -4.6647912263870239e-01
    z[7,4,3]  R2415     -8.3207428455352783e-02
    z[7,4,3]  R2416     -5.6877774000167847e-01
    z[7,4,3]  R2417     -3.0903410911560059e-01
    z[7,4,3]  R2418     -4.6563339233398438e-01
    z[7,4,3]  R2419     -3.3741500973701477e-01
    z[7,4,3]  R2420     -5.4462337493896484e-01
    z[7,4,3]  R2421     -1.7232039570808411e-01
    z[7,4,3]  R2422     -2.1759833395481110e-01
    z[7,4,3]  R2423     -6.5985542535781860e-01
    z[7,4,3]  R2424     2.0762298256158829e-02
    z[7,4,3]  R2425     -7.8155420720577240e-02
    z[7,4,3]  R2426     -0.406417578458786
    z[7,4,3]  R2427     6.5221287310123444e-02
    z[7,4,3]  R2428     0.0881512239575386
    z[7,4,3]  R2429     1.3524082303047180e-01
    z[7,4,3]  R2430     -2.6688039302825928e-01
    z[7,4,3]  R2431     0.33226278424263
    z[7,4,3]  R2432     3.9146417379379272e-01
    z[7,4,3]  R2433     -8.0085076391696930e-02
    z[7,4,3]  R2434     1.9872041046619415e-01
    z[7,4,3]  R2435     -4.8493242263793945e-01
    z[7,4,3]  R2436     -4.0307980775833130e-01
    z[7,4,3]  R2437     -4.5969793200492859e-01
    z[7,4,3]  R2438     7.2684627771377563e-01
    z[7,4,3]  R2439     -6.3669097423553467e-01
    z[7,4,3]  R2440     -0.288517564535141
    z[7,4,3]  R2441     -6.6944444179534912e-01
    z[7,4,3]  R2442     -2.2743774950504303e-01
    z[7,4,3]  R2443     -6.2280791997909546e-01
    z[7,4,3]  R2444     -2.3109762370586395e-01
    z[7,4,3]  R2445     -0.391855388879776
    z[7,4,3]  R2446     -4.1402736306190491e-01
    z[7,4,3]  R2447     -8.5958838462829590e-02
    z[7,4,3]  R2448     1.1629532277584076e-01
    z[7,4,3]  R2449     -4.0571384131908417e-02
    z[7,4,3]  R2450     2.2374625504016876e-01
    z[7,4,3]  R2451     2.3730051517486572e-01
    z[7,4,3]  R2452     -1.6322648152709007e-02
    z[7,4,3]  R2453     5.9212759137153625e-02
    z[7,4,3]  R2454     -1.0154701769351959e-01
    z[7,4,3]  R2455     -1.0773303359746933e-01
    z[7,4,3]  R2456     2.3034097626805305e-02
    z[7,4,3]  R2457     -4.6928000450134277e-01
    z[7,4,3]  R2458     4.3289911746978760e-01
    z[7,4,3]  R2459     6.4842063188552856e-01
    z[7,4,3]  R2460     5.8338105678558350e-01
    z[7,4,3]  R2461     -1.3787488453090191e-02
    z[7,4,3]  R2462     -2.5685107707977295e-01
    z[7,4,3]  R2463     -1.9629356265068054e-01
    z[7,4,3]  R2464     6.2076830863952637e-01
    z[7,4,3]  R2465     0.618816614151001
    z[7,4,3]  R2466     5.8165395259857178e-01
    z[7,4,3]  R2467     5.9145528078079224e-01
    z[7,4,3]  R2468     5.5927777290344238e-01
    z[7,4,3]  R2469     5.6667649745941162e-01
    z[7,4,3]  R2470     5.4406929016113281e-01
    z[7,4,3]  R2471     6.5865945816040039e-01
    z[7,4,3]  R2472     0.662432074546814
    z[7,4,3]  R2473     6.5003538131713867e-01
    z[7,4,3]  R2474     6.3249212503433228e-01
    z[7,4,3]  R2475     6.2142062187194824e-01
    z[7,4,3]  R2476     6.7430156469345093e-01
    z[7,4,3]  R2477     6.3411563634872437e-01
    z[7,4,3]  R2478     5.6758403778076172e-01
    z[7,4,3]  R2479     5.3503137826919556e-01
    z[7,4,3]  R2480     6.4338076114654541e-01
    z[7,4,4]  R42       1
    z[7,4,4]  R69       -1
    z[7,4,4]  R2395     -1
    z[7,4,4]  R2396     1
    z[7,4,4]  R2401     1.3001147657632828e-02
    z[7,4,4]  R2402     -8.7179347872734070e-02
    z[7,4,4]  R2403     1.6161532700061798e-01
    z[7,4,4]  R2404     2.5822514295578003e-01
    z[7,4,4]  R2405     -2.0004893839359283e-01
    z[7,4,4]  R2406     -2.4194066226482391e-01
    z[7,4,4]  R2407     2.6647615432739258e-01
    z[7,4,4]  R2408     -7.0569347590208054e-03
    z[7,4,4]  R2409     -0.457533061504364
    z[7,4,4]  R2410     2.6290962100028992e-01
    z[7,4,4]  R2411     -4.0289908647537231e-01
    z[7,4,4]  R2412     -3.5442799329757690e-01
    z[7,4,4]  R2413     -1.9329233467578888e-01
    z[7,4,4]  R2414     -2.1037788689136505e-01
    z[7,4,4]  R2415     -6.5850298851728439e-03
    z[7,4,4]  R2416     -3.7085208296775818e-01
    z[7,4,4]  R2417     6.4554825425148010e-02
    z[7,4,4]  R2418     -3.6159214377403259e-01
    z[7,4,4]  R2419     5.0317924469709396e-02
    z[7,4,4]  R2420     2.5089766830205917e-02
    z[7,4,4]  R2421     3.2245415449142456e-01
    z[7,4,4]  R2422     2.0978122949600220e-01
    z[7,4,4]  R2423     -4.8044338822364807e-01
    z[7,4,4]  R2424     -2.4499568343162537e-01
    z[7,4,4]  R2425     2.1332244575023651e-01
    z[7,4,4]  R2426     2.6873627305030823e-01
    z[7,4,4]  R2427     4.2627118527889252e-03
    z[7,4,4]  R2428     4.1220989823341370e-01
    z[7,4,4]  R2429     1.0254800319671631e-01
    z[7,4,4]  R2430     -3.0259862542152405e-01
    z[7,4,4]  R2431     4.2819178104400635e-01
    z[7,4,4]  R2432     -0.486828088760376
    z[7,4,4]  R2433     1.7520861327648163e-01
    z[7,4,4]  R2434     6.8648862838745117e-01
    z[7,4,4]  R2435     -5.6398731470108032e-01
    z[7,4,4]  R2436     2.6229554787278175e-02
    z[7,4,4]  R2437     2.8796127438545227e-01
    z[7,4,4]  R2438     3.1456348299980164e-01
    z[7,4,4]  R2439     -4.3707441538572311e-02
    z[7,4,4]  R2440     -4.1453507542610168e-01
    z[7,4,4]  R2441     -3.7347182631492615e-01
    z[7,4,4]  R2442     -4.3055397272109985e-01
    z[7,4,4]  R2443     2.2676877677440643e-02
    z[7,4,4]  R2444     -7.1557931602001190e-02
    z[7,4,4]  R2445     -6.9433611631393433e-01
    z[7,4,4]  R2446     -5.7911306619644165e-01
    z[7,4,4]  R2447     -0.0732896476984024
    z[7,4,4]  R2448     -1.2858195602893829e-01
    z[7,4,4]  R2449     -4.0163826942443848e-01
    z[7,4,4]  R2450     -6.4065003395080566e-01
    z[7,4,4]  R2451     2.7452877163887024e-01
    z[7,4,4]  R2452     4.4084548950195312e-01
    z[7,4,4]  R2453     5.1864463090896606e-01
    z[7,4,4]  R2454     2.4805767834186554e-01
    z[7,4,4]  R2455     -4.6411193907260895e-02
    z[7,4,4]  R2456     0.329597145318985
    z[7,4,4]  R2457     -1.4363935589790344e-01
    z[7,4,4]  R2458     7.1478348970413208e-01
    z[7,4,4]  R2459     5.4629105329513550e-01
    z[7,4,4]  R2460     5.3774231672286987e-01
    z[7,4,4]  R2461     -4.0136259794235229e-01
    z[7,4,4]  R2462     2.0788341760635376e-02
    z[7,4,4]  R2463     4.5161384344100952e-01
    z[7,4,4]  R2464     4.1718937456607819e-02
    z[7,4,4]  R2465     -0.203811913728714
    z[7,4,4]  R2466     1.4877521991729736e-01
    z[7,4,4]  R2467     -2.0560060441493988e-01
    z[7,4,4]  R2468     2.3319673538208008e-01
    z[7,4,4]  R2469     1.9234456121921539e-01
    z[7,4,4]  R2470     6.6936874389648438e-01
    z[7,4,4]  R2471     1.0328670591115952e-01
    z[7,4,4]  R2472     5.5827479809522629e-02
    z[7,4,4]  R2473     0.00386149063706398
    z[7,4,4]  R2474     1.9641930237412453e-02
    z[7,4,4]  R2475     -1.2796667218208313e-01
    z[7,4,4]  R2476     5.3986251354217529e-02
    z[7,4,4]  R2477     1.5775239467620850e-01
    z[7,4,4]  R2478     -3.1440962105989456e-02
    z[7,4,4]  R2479     1.8580880761146545e-01
    z[7,4,4]  R2480     6.8503051996231079e-01
    z[7,4,5]  R43       1
    z[7,4,5]  R70       -1
    z[7,4,5]  R2397     -1
    z[7,4,5]  R2398     1
    z[7,4,5]  R2401     -1.0507623106241226e-01
    z[7,4,5]  R2402     -1.3714969158172607e-01
    z[7,4,5]  R2403     1.7076972126960754e-01
    z[7,4,5]  R2404     -8.8459923863410950e-02
    z[7,4,5]  R2405     0.258756548166275
    z[7,4,5]  R2406     -4.9505833536386490e-02
    z[7,4,5]  R2407     4.6881463378667831e-02
    z[7,4,5]  R2408     -3.4698281437158585e-02
    z[7,4,5]  R2409     5.5712736211717129e-03
    z[7,4,5]  R2410     1.3792365789413452e-01
    z[7,4,5]  R2411     8.8033504784107208e-02
    z[7,4,5]  R2412     -9.3164615333080292e-02
    z[7,4,5]  R2413     -1.9087509810924530e-01
    z[7,4,5]  R2414     7.0396237075328827e-02
    z[7,4,5]  R2415     6.9680221378803253e-02
    z[7,4,5]  R2416     1.0128123313188553e-01
    z[7,4,5]  R2417     2.5151568651199341e-01
    z[7,4,5]  R2418     8.0217964947223663e-02
    z[7,4,5]  R2419     -1.5398536622524261e-01
    z[7,4,5]  R2420     -1.0147435218095779e-01
    z[7,4,5]  R2421     -2.5306597352027893e-01
    z[7,4,5]  R2422     1.6864615678787231e-01
    z[7,4,5]  R2423     -1.0216084867715836e-01
    z[7,4,5]  R2424     -8.7392807006835938e-02
    z[7,4,5]  R2425     2.1890738606452942e-01
    z[7,4,5]  R2426     -3.8237354159355164e-01
    z[7,4,5]  R2427     -4.0125495195388794e-01
    z[7,4,5]  R2428     1.8512722849845886e-01
    z[7,4,5]  R2429     -2.5003109127283096e-02
    z[7,4,5]  R2430     -2.5611430406570435e-01
    z[7,4,5]  R2431     -2.9676118493080139e-01
    z[7,4,5]  R2432     -5.1403272151947021e-01
    z[7,4,5]  R2433     -5.5768877267837524e-01
    z[7,4,5]  R2434     -0.166483074426651
    z[7,4,5]  R2435     -3.2608771324157715e-01
    z[7,4,5]  R2436     1.6494846343994141e-01
    z[7,4,5]  R2437     9.2028222978115082e-02
    z[7,4,5]  R2438     0.362809956073761
    z[7,4,5]  R2439     1.2219491600990295e-01
    z[7,4,5]  R2440     1.9462847709655762e-01
    z[7,4,5]  R2441     3.0502617359161377e-01
    z[7,4,5]  R2442     4.9484741687774658e-01
    z[7,4,5]  R2443     2.5460910797119141e-01
    z[7,4,5]  R2444     3.3628630638122559e-01
    z[7,4,5]  R2445     -1.0812437534332275e-01
    z[7,4,5]  R2446     3.5929408669471741e-01
    z[7,4,5]  R2447     0.0888829231262207
    z[7,4,5]  R2448     6.2359537929296494e-02
    z[7,4,5]  R2449     -8.1958241760730743e-02
    z[7,4,5]  R2450     1.0259815305471420e-01
    z[7,4,5]  R2451     -4.0154001116752625e-01
    z[7,4,5]  R2452     -0.666703999042511
    z[7,4,5]  R2453     1.5759790316224098e-02
    z[7,4,5]  R2454     -1.9583757221698761e-01
    z[7,4,5]  R2455     -5.0340473651885986e-01
    z[7,4,5]  R2456     1.3030278682708740e-01
    z[7,4,5]  R2457     -7.1038591861724854e-01
    z[7,4,5]  R2458     -5.6272368878126144e-02
    z[7,4,5]  R2459     -2.5221112370491028e-01
    z[7,4,5]  R2460     -1.6141898930072784e-01
    z[7,4,5]  R2461     -0.500432014465332
    z[7,4,5]  R2462     -5.0948232412338257e-01
    z[7,4,5]  R2463     -2.1376492083072662e-01
    z[7,4,5]  R2464     -4.3151828646659851e-01
    z[7,4,5]  R2465     -0.416143000125885
    z[7,4,5]  R2466     8.0096609890460968e-02
    z[7,4,5]  R2467     4.8506391048431396e-01
    z[7,4,5]  R2468     1.5715818107128143e-01
    z[7,4,5]  R2469     4.4791880249977112e-01
    z[7,4,5]  R2470     1.6610497608780861e-02
    z[7,4,5]  R2471     8.6551554501056671e-02
    z[7,4,5]  R2472     4.0178185701370239e-01
    z[7,4,5]  R2473     2.5812906026840210e-01
    z[7,4,5]  R2474     7.6234221458435059e-02
    z[7,4,5]  R2475     -5.8103847503662109e-01
    z[7,4,5]  R2476     -5.1187396049499512e-02
    z[7,4,5]  R2477     -9.4732657074928284e-02
    z[7,4,5]  R2478     -9.8502397537231445e-02
    z[7,4,5]  R2479     -2.8530222177505493e-01
    z[7,4,5]  R2480     -9.2689990997314453e-02
    z[7,4,6]  R44       1
    z[7,4,6]  R71       -1
    z[7,4,6]  R2399     -1
    z[7,4,6]  R2400     1
    z[7,4,6]  R2401     4.5093291997909546e-01
    z[7,4,6]  R2402     1.8133418262004852e-01
    z[7,4,6]  R2403     2.9193994402885437e-01
    z[7,4,6]  R2404     6.3883143663406372e-01
    z[7,4,6]  R2405     -3.5452902317047119e-01
    z[7,4,6]  R2406     2.6167482137680054e-01
    z[7,4,6]  R2407     3.6023595929145813e-01
    z[7,4,6]  R2408     0.629138171672821
    z[7,4,6]  R2409     3.1355720758438110e-01
    z[7,4,6]  R2410     -1.3416926562786102e-01
    z[7,4,6]  R2411     1.5790063142776489e-01
    z[7,4,6]  R2412     6.7301634699106216e-03
    z[7,4,6]  R2413     2.7205497026443481e-01
    z[7,4,6]  R2414     -1.0560656338930130e-01
    z[7,4,6]  R2415     1.6317966580390930e-01
    z[7,4,6]  R2416     -1.8791554495692253e-02
    z[7,4,6]  R2417     2.9086660593748093e-02
    z[7,4,6]  R2418     7.0451624691486359e-02
    z[7,4,6]  R2419     -7.3795504868030548e-02
    z[7,4,6]  R2420     -7.8698962926864624e-02
    z[7,4,6]  R2421     4.4508766382932663e-02
    z[7,4,6]  R2422     -2.9428917169570923e-01
    z[7,4,6]  R2423     -2.8257521986961365e-01
    z[7,4,6]  R2424     3.6888431757688522e-02
    z[7,4,6]  R2425     5.4996378719806671e-02
    z[7,4,6]  R2426     1.7810256779193878e-01
    z[7,4,6]  R2427     -1.1039060354232788e-01
    z[7,4,6]  R2428     6.9044865667819977e-03
    z[7,4,6]  R2429     1.5340237319469452e-01
    z[7,4,6]  R2430     -3.8018664717674255e-01
    z[7,4,6]  R2431     -3.7175354361534119e-01
    z[7,4,6]  R2432     -2.7003440260887146e-01
    z[7,4,6]  R2433     -1.1532482504844666e-01
    z[7,4,6]  R2434     -2.1410727500915527e-01
    z[7,4,6]  R2435     3.3382120728492737e-01
    z[7,4,6]  R2436     -8.1435024738311768e-02
    z[7,4,6]  R2437     9.2316776514053345e-02
    z[7,4,6]  R2438     4.0257081389427185e-01
    z[7,4,6]  R2439     -6.1611879616975784e-02
    z[7,4,6]  R2440     2.4131615459918976e-01
    z[7,4,6]  R2441     3.4300554543733597e-03
    z[7,4,6]  R2442     -2.9553198255598545e-03
    z[7,4,6]  R2443     5.7289695739746094e-01
    z[7,4,6]  R2444     -3.2113909721374512e-01
    z[7,4,6]  R2445     2.3305638134479523e-01
    z[7,4,6]  R2446     -6.3961118459701538e-02
    z[7,4,6]  R2447     2.2625601291656494e-01
    z[7,4,6]  R2448     -1.0131567716598511e-01
    z[7,4,6]  R2449     6.1252242326736450e-01
    z[7,4,6]  R2450     1.9123022258281708e-01
    z[7,4,6]  R2451     -3.1890419125556946e-01
    z[7,4,6]  R2452     -2.0590442419052124e-01
    z[7,4,6]  R2453     -0.414957195520401
    z[7,4,6]  R2454     -3.7433198094367981e-01
    z[7,4,6]  R2455     -2.0747286081314087e-01
    z[7,4,6]  R2456     -2.7607965469360352e-01
    z[7,4,6]  R2457     1.5594394505023956e-01
    z[7,4,6]  R2458     4.1695764660835266e-01
    z[7,4,6]  R2459     9.8663009703159332e-02
    z[7,4,6]  R2460     3.7763953208923340e-01
    z[7,4,6]  R2461     -8.2898207008838654e-02
    z[7,4,6]  R2462     -2.0093081891536713e-01
    z[7,4,6]  R2463     0.0621473453938961
    z[7,4,6]  R2464     1.5214161947369576e-02
    z[7,4,6]  R2465     -4.7630748152732849e-01
    z[7,4,6]  R2466     5.1341992616653442e-01
    z[7,4,6]  R2467     -3.5862424969673157e-01
    z[7,4,6]  R2468     0.41744464635849
    z[7,4,6]  R2469     9.5681458711624146e-02
    z[7,4,6]  R2470     3.6838880181312561e-01
    z[7,4,6]  R2471     4.6484112739562988e-01
    z[7,4,6]  R2472     3.9420583844184875e-01
    z[7,4,6]  R2473     3.4531581401824951e-01
    z[7,4,6]  R2474     -3.6222934722900391e-01
    z[7,4,6]  R2475     -1.2603670358657837e-01
    z[7,4,6]  R2476     -3.8603344559669495e-01
    z[7,4,6]  R2477     3.1251555681228638e-01
    z[7,4,6]  R2478     -3.8927948474884033e-01
    z[7,4,6]  R2479     2.9809162020683289e-01
    z[7,4,6]  R2480     -4.5947216451168060e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2535     -1
    z[5,6,0]  R2536     1
    z[5,6,0]  R2549     -2.4731977283954620e-01
    z[5,6,0]  R2550     0.085629403591156
    z[5,6,0]  R2551     5.9188399463891983e-02
    z[5,6,0]  R2552     -1.6589473187923431e-01
    z[5,6,0]  R2553     -1.7032325267791748e-02
    z[5,6,0]  R2554     -4.5395351946353912e-02
    z[5,6,0]  R2555     -1.6201204061508179e-01
    z[5,6,0]  R2556     -1.8934737890958786e-02
    z[5,6,0]  R2557     0.150125190615654
    z[5,6,0]  R2558     -3.8735404610633850e-01
    z[5,6,0]  R2559     -2.1382641792297363e-01
    z[5,6,0]  R2560     -3.5925221443176270e-01
    z[5,6,0]  R2561     -3.9004248380661011e-01
    z[5,6,0]  R2562     -8.7264098227024078e-02
    z[5,6,0]  R2563     1.8645381554961205e-02
    z[5,6,0]  R2564     -3.1487077474594116e-01
    z[5,6,0]  R2565     -6.3983634114265442e-02
    z[5,6,0]  R2566     3.1601474620401859e-03
    z[5,6,0]  R2567     2.7315232157707214e-01
    z[5,6,0]  R2568     -1.1055515706539154e-01
    z[5,6,0]  R2569     -5.3513408638536930e-03
    z[5,6,0]  R2570     1.9580383598804474e-01
    z[5,6,0]  R2571     4.4064730405807495e-01
    z[5,6,0]  R2572     2.6081116870045662e-02
    z[5,6,0]  R2573     2.1425299346446991e-01
    z[5,6,0]  R2574     -2.5385084748268127e-01
    z[5,6,0]  R2575     -5.7478111237287521e-02
    z[5,6,0]  R2576     8.5354052484035492e-02
    z[5,6,0]  R2577     2.3851613700389862e-01
    z[5,6,0]  R2578     -1.3423493504524231e-01
    z[5,6,0]  R2579     -3.6913685500621796e-02
    z[5,6,0]  R2580     -2.1532289683818817e-01
    z[5,6,0]  R2581     -2.3875330388545990e-01
    z[5,6,0]  R2582     9.2885173857212067e-02
    z[5,6,0]  R2583     5.3868040442466736e-02
    z[5,6,0]  R2584     1.3729308545589447e-01
    z[5,6,0]  R2585     1.9400085508823395e-01
    z[5,6,0]  R2586     2.4801792204380035e-01
    z[5,6,0]  R2587     5.0494468212127686e-01
    z[5,6,0]  R2588     2.1552659571170807e-01
    z[5,6,0]  R2589     -2.1240970492362976e-01
    z[5,6,0]  R2590     5.6615126132965088e-01
    z[5,6,0]  R2591     -0.287582129240036
    z[5,6,0]  R2592     3.9139175415039062e-01
    z[5,6,0]  R2593     8.9847363531589508e-02
    z[5,6,0]  R2594     -1.3517257571220398e-01
    z[5,6,0]  R2595     6.2380012124776840e-02
    z[5,6,0]  R2596     -3.1546853482723236e-02
    z[5,6,0]  R2597     -3.2627135515213013e-01
    z[5,6,0]  R2598     3.7415587902069092e-01
    z[5,6,0]  R2599     -2.1480867266654968e-01
    z[5,6,0]  R2600     -2.4702057242393494e-01
    z[5,6,0]  R2601     0.0647042840719223
    z[5,6,0]  R2602     -0.0897059440612793
    z[5,6,0]  R2603     7.5556194782257080e-01
    z[5,6,0]  R2604     -6.9648653268814087e-01
    z[5,6,0]  R2605     4.2574423551559448e-01
    z[5,6,0]  R2606     -8.8941919803619385e-01
    z[5,6,0]  R2607     6.2374550104141235e-01
    z[5,6,0]  R2608     -5.0331413745880127e-01
    z[5,6,0]  R2609     2.9560112953186035e-01
    z[5,6,0]  R2610     -1.8875746428966522e-01
    z[5,6,0]  R2611     -3.9666953682899475e-01
    z[5,6,0]  R2612     -1.5260013937950134e-01
    z[5,6,0]  R2613     4.4463074207305908e-01
    z[5,6,0]  R2614     1.3967847824096680e-01
    z[5,6,0]  R2615     -5.1141440868377686e-01
    z[5,6,0]  R2616     -3.6340034008026123e-01
    z[5,6,0]  R2617     2.8061848878860474e-01
    z[5,6,0]  R2618     1.1992813646793365e-01
    z[5,6,0]  R2619     -1.1969466507434845e-01
    z[5,6,0]  R2620     0.891903281211853
    z[5,6,0]  R2621     -0.0440092533826828
    z[5,6,0]  R2622     6.9294106960296631e-01
    z[5,6,0]  R2623     6.0244774818420410e-01
    z[5,6,0]  R2624     -8.1641167402267456e-02
    z[5,6,0]  R2625     5.6040030717849731e-01
    z[5,6,0]  R2626     4.0766561031341553e-01
    z[5,6,0]  R2627     3.1279277754947543e-04
    z[5,6,0]  R2628     4.6923488378524780e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2537     -1
    z[5,6,1]  R2538     1
    z[5,6,1]  R2549     9.2446643114089966e-01
    z[5,6,1]  R2550     9.8886710405349731e-01
    z[5,6,1]  R2551     -3.0416840687394142e-02
    z[5,6,1]  R2552     6.3676489517092705e-03
    z[5,6,1]  R2553     5.7651054859161377e-01
    z[5,6,1]  R2554     -3.4543506801128387e-02
    z[5,6,1]  R2555     -0.0232999287545681
    z[5,6,1]  R2556     -3.5011786967515945e-02
    z[5,6,1]  R2557     -6.4352788031101227e-02
    z[5,6,1]  R2558     -5.5713269859552383e-02
    z[5,6,1]  R2559     -6.2276363372802734e-01
    z[5,6,1]  R2560     -6.0613393783569336e-01
    z[5,6,1]  R2561     -0.557383120059967
    z[5,6,1]  R2562     -5.5232745409011841e-01
    z[5,6,1]  R2563     -5.3412622213363647e-01
    z[5,6,1]  R2564     -5.6050300598144531e-01
    z[5,6,1]  R2565     -4.9303579330444336e-01
    z[5,6,1]  R2566     -5.4293894767761230e-01
    z[5,6,1]  R2567     -5.5307763814926147e-01
    z[5,6,1]  R2568     -4.9725890159606934e-01
    z[5,6,1]  R2569     -9.8264390230178833e-01
    z[5,6,1]  R2570     -7.9808372259140015e-01
    z[5,6,1]  R2571     -6.5045034885406494e-01
    z[5,6,1]  R2572     -4.5593962073326111e-01
    z[5,6,1]  R2573     0.483502060174942
    z[5,6,1]  R2574     6.7729687690734863e-01
    z[5,6,1]  R2575     5.8949595689773560e-01
    z[5,6,1]  R2576     3.5691463947296143e-01
    z[5,6,1]  R2577     7.8776067495346069e-01
    z[5,6,1]  R2578     5.6254655122756958e-01
    z[5,6,1]  R2579     0.73489910364151
    z[5,6,1]  R2580     0.717809796333313
    z[5,6,1]  R2581     8.3352595567703247e-01
    z[5,6,1]  R2582     7.7697873115539551e-01
    z[5,6,1]  R2583     6.3356381654739380e-01
    z[5,6,1]  R2584     6.9384175539016724e-01
    z[5,6,1]  R2585     7.0997720956802368e-01
    z[5,6,1]  R2586     7.7718651294708252e-01
    z[5,6,1]  R2587     -2.2949238121509552e-01
    z[5,6,1]  R2588     -7.7543258666992188e-02
    z[5,6,1]  R2589     -4.4346127659082413e-02
    z[5,6,1]  R2590     -9.0379834175109863e-02
    z[5,6,1]  R2591     -1.5228827297687531e-01
    z[5,6,1]  R2592     -1.0052482783794403e-01
    z[5,6,1]  R2593     -3.9079539477825165e-02
    z[5,6,1]  R2594     -1.6333429515361786e-01
    z[5,6,1]  R2595     -5.1454100757837296e-02
    z[5,6,1]  R2596     -5.8109525591135025e-02
    z[5,6,1]  R2597     9.2844374477863312e-02
    z[5,6,1]  R2598     -8.1013187766075134e-02
    z[5,6,1]  R2599     8.1758999824523926e-01
    z[5,6,1]  R2600     -2.7423635125160217e-01
    z[5,6,1]  R2601     9.2157393693923950e-01
    z[5,6,1]  R2602     9.1725713014602661e-01
    z[5,6,1]  R2603     -3.1591439247131348e-01
    z[5,6,1]  R2604     -4.2140522599220276e-01
    z[5,6,1]  R2605     -2.1396489441394806e-01
    z[5,6,1]  R2606     -0.283568799495697
    z[5,6,1]  R2607     3.6306354403495789e-01
    z[5,6,1]  R2608     -5.2217030525207520e-01
    z[5,6,1]  R2609     -7.4705088138580322e-01
    z[5,6,1]  R2610     -6.0879707336425781e-01
    z[5,6,1]  R2611     -6.1021369695663452e-01
    z[5,6,1]  R2612     -5.2069664001464844e-01
    z[5,6,1]  R2613     -5.0037395954132080e-01
    z[5,6,1]  R2614     -5.1626527309417725e-01
    z[5,6,1]  R2615     -4.8499128222465515e-01
    z[5,6,1]  R2616     -4.2986959218978882e-01
    z[5,6,1]  R2617     -4.6784445643424988e-01
    z[5,6,1]  R2618     -5.2109575271606445e-01
    z[5,6,1]  R2619     -6.4972156286239624e-01
    z[5,6,1]  R2620     1.3706804811954498e-01
    z[5,6,1]  R2621     -5.5932825803756714e-01
    z[5,6,1]  R2622     4.6786937862634659e-02
    z[5,6,1]  R2623     -2.8206637501716614e-01
    z[5,6,1]  R2624     -0.646415650844574
    z[5,6,1]  R2625     4.0782818198204041e-01
    z[5,6,1]  R2626     1.4009904861450195e-01
    z[5,6,1]  R2627     -2.5747969746589661e-01
    z[5,6,1]  R2628     2.2282439470291138e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2539     -1
    z[5,6,2]  R2540     1
    z[5,6,2]  R2549     8.9352488517761230e-02
    z[5,6,2]  R2550     -0.0491953007876873
    z[5,6,2]  R2551     -7.9013854265213013e-01
    z[5,6,2]  R2552     -6.8222486972808838e-01
    z[5,6,2]  R2553     -1.4217109978199005e-01
    z[5,6,2]  R2554     -5.9088891744613647e-01
    z[5,6,2]  R2555     -8.1355655193328857e-01
    z[5,6,2]  R2556     -5.0917977094650269e-01
    z[5,6,2]  R2557     -4.6965035796165466e-01
    z[5,6,2]  R2558     -6.6920286417007446e-01
    z[5,6,2]  R2559     1.2158872932195663e-01
    z[5,6,2]  R2560     4.0791156888008118e-01
    z[5,6,2]  R2561     -3.8222637772560120e-01
    z[5,6,2]  R2562     -5.6150525808334351e-01
    z[5,6,2]  R2563     -3.2182133197784424e-01
    z[5,6,2]  R2564     -5.4858695715665817e-02
    z[5,6,2]  R2565     -2.4375198781490326e-01
    z[5,6,2]  R2566     -1.9812296330928802e-01
    z[5,6,2]  R2567     3.9448940753936768e-01
    z[5,6,2]  R2568     5.7450169324874878e-01
    z[5,6,2]  R2569     -0.0683421716094017
    z[5,6,2]  R2570     -2.9872161149978638e-01
    z[5,6,2]  R2571     -3.4258782863616943e-02
    z[5,6,2]  R2572     -2.4924477934837341e-01
    z[5,6,2]  R2573     4.2520549893379211e-01
    z[5,6,2]  R2574     3.0196332931518555e-01
    z[5,6,2]  R2575     4.8791524767875671e-01
    z[5,6,2]  R2576     6.5476822853088379e-01
    z[5,6,2]  R2577     3.7515634298324585e-01
    z[5,6,2]  R2578     5.4492139816284180e-01
    z[5,6,2]  R2579     5.1817828416824341e-01
    z[5,6,2]  R2580     2.5820646435022354e-02
    z[5,6,2]  R2581     4.3365576863288879e-01
    z[5,6,2]  R2582     2.0073603093624115e-01
    z[5,6,2]  R2583     4.8572579026222229e-01
    z[5,6,2]  R2584     -2.1406058967113495e-01
    z[5,6,2]  R2585     1.0951752215623856e-01
    z[5,6,2]  R2586     -3.0360126495361328e-01
    z[5,6,2]  R2587     -5.7654780149459839e-01
    z[5,6,2]  R2588     -4.5599821209907532e-01
    z[5,6,2]  R2589     -6.2255424261093140e-01
    z[5,6,2]  R2590     -7.4332630634307861e-01
    z[5,6,2]  R2591     -8.0464816093444824e-01
    z[5,6,2]  R2592     -6.0049152374267578e-01
    z[5,6,2]  R2593     -1.8468938767910004e-01
    z[5,6,2]  R2594     -7.3881131410598755e-01
    z[5,6,2]  R2595     -6.4745169878005981e-01
    z[5,6,2]  R2596     -8.3255708217620850e-01
    z[5,6,2]  R2597     -8.3497482538223267e-01
    z[5,6,2]  R2598     -3.6337402462959290e-01
    z[5,6,2]  R2599     3.0558711290359497e-01
    z[5,6,2]  R2600     5.8320814371109009e-01
    z[5,6,2]  R2601     2.4961875379085541e-01
    z[5,6,2]  R2602     2.9769837856292725e-01
    z[5,6,2]  R2603     2.1694932878017426e-01
    z[5,6,2]  R2604     2.8463923931121826e-01
    z[5,6,2]  R2605     2.0543260872364044e-01
    z[5,6,2]  R2606     2.0874388515949249e-01
    z[5,6,2]  R2607     0.381873220205307
    z[5,6,2]  R2608     3.4576156735420227e-01
    z[5,6,2]  R2609     1.0945479571819305e-01
    z[5,6,2]  R2610     -3.2285865396261215e-02
    z[5,6,2]  R2611     -5.2841058932244778e-03
    z[5,6,2]  R2612     2.2360880672931671e-01
    z[5,6,2]  R2613     3.1841287016868591e-01
    z[5,6,2]  R2614     -3.3113136887550354e-01
    z[5,6,2]  R2615     1.0439525544643402e-01
    z[5,6,2]  R2616     2.3203656077384949e-01
    z[5,6,2]  R2617     -1.0930939763784409e-01
    z[5,6,2]  R2618     2.4682506918907166e-01
    z[5,6,2]  R2619     -6.2499684095382690e-01
    z[5,6,2]  R2620     -2.2313027083873749e-01
    z[5,6,2]  R2621     -9.5440290868282318e-02
    z[5,6,2]  R2622     -6.9622255861759186e-02
    z[5,6,2]  R2623     -1.8771840631961823e-01
    z[5,6,2]  R2624     -2.8977859020233154e-01
    z[5,6,2]  R2625     0.0358751118183136
    z[5,6,2]  R2626     -1.8994650244712830e-01
    z[5,6,2]  R2627     -4.9565258622169495e-01
    z[5,6,2]  R2628     1.5451537072658539e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2541     -1
    z[5,6,3]  R2542     1
    z[5,6,3]  R2549     -0.0918092280626297
    z[5,6,3]  R2550     -5.7513605803251266e-02
    z[5,6,3]  R2551     4.5418307185173035e-01
    z[5,6,3]  R2552     7.7439472079277039e-02
    z[5,6,3]  R2553     -4.7017872333526611e-01
    z[5,6,3]  R2554     2.1625219285488129e-01
    z[5,6,3]  R2555     1.2432087957859039e-01
    z[5,6,3]  R2556     8.0524575710296631e-01
    z[5,6,3]  R2557     2.2533978521823883e-01
    z[5,6,3]  R2558     3.7645533680915833e-01
    z[5,6,3]  R2559     -5.7087731361389160e-01
    z[5,6,3]  R2560     3.2693132758140564e-01
    z[5,6,3]  R2561     2.0445835590362549e-01
    z[5,6,3]  R2562     -4.2540755122900009e-02
    z[5,6,3]  R2563     1.0242677479982376e-01
    z[5,6,3]  R2564     5.6630659103393555e-01
    z[5,6,3]  R2565     -3.0235049128532410e-01
    z[5,6,3]  R2566     4.3067130446434021e-01
    z[5,6,3]  R2567     -4.3552737683057785e-02
    z[5,6,3]  R2568     -1.7985163629055023e-01
    z[5,6,3]  R2569     -3.1912997364997864e-02
    z[5,6,3]  R2570     3.0458664894104004e-01
    z[5,6,3]  R2571     -4.7390836477279663e-01
    z[5,6,3]  R2572     -4.9928811192512512e-01
    z[5,6,3]  R2573     -3.4362620115280151e-01
    z[5,6,3]  R2574     -5.4417955875396729e-01
    z[5,6,3]  R2575     -5.6571716070175171e-01
    z[5,6,3]  R2576     -5.5515849590301514e-01
    z[5,6,3]  R2577     -1.1362207680940628e-01
    z[5,6,3]  R2578     -2.1862530708312988e-01
    z[5,6,3]  R2579     -8.9182555675506592e-02
    z[5,6,3]  R2580     -5.4975038766860962e-01
    z[5,6,3]  R2581     -7.8502416610717773e-02
    z[5,6,3]  R2582     -3.4554621577262878e-01
    z[5,6,3]  R2583     -0.526281476020813
    z[5,6,3]  R2584     -4.1011002659797668e-01
    z[5,6,3]  R2585     -2.1180368959903717e-01
    z[5,6,3]  R2586     -1.5986070036888123e-01
    z[5,6,3]  R2587     8.8934656232595444e-03
    z[5,6,3]  R2588     1.7634023725986481e-01
    z[5,6,3]  R2589     -1.8421080708503723e-01
    z[5,6,3]  R2590     -2.9413759708404541e-02
    z[5,6,3]  R2591     1.6060025990009308e-01
    z[5,6,3]  R2592     1.5337137877941132e-01
    z[5,6,3]  R2593     3.9470937848091125e-01
    z[5,6,3]  R2594     1.2312074750661850e-01
    z[5,6,3]  R2595     -0.366982102394104
    z[5,6,3]  R2596     1.2864798307418823e-01
    z[5,6,3]  R2597     -8.5663378238677979e-02
    z[5,6,3]  R2598     -3.0126622319221497e-01
    z[5,6,3]  R2599     3.9039561152458191e-01
    z[5,6,3]  R2600     -4.7683459520339966e-01
    z[5,6,3]  R2601     -1.6152353584766388e-01
    z[5,6,3]  R2602     -2.0118415355682373e-01
    z[5,6,3]  R2603     3.3191543817520142e-01
    z[5,6,3]  R2604     4.8919060826301575e-01
    z[5,6,3]  R2605     -6.1220663785934448e-01
    z[5,6,3]  R2606     1.7509926855564117e-01
    z[5,6,3]  R2607     -4.7625014185905457e-01
    z[5,6,3]  R2608     4.8647928237915039e-01
    z[5,6,3]  R2609     -2.3330879211425781e-01
    z[5,6,3]  R2610     -6.9764018058776855e-02
    z[5,6,3]  R2611     2.6782515645027161e-01
    z[5,6,3]  R2612     -0.405845582485199
    z[5,6,3]  R2613     6.4888454973697662e-02
    z[5,6,3]  R2614     -3.8919255137443542e-01
    z[5,6,3]  R2615     1.6290649771690369e-01
    z[5,6,3]  R2616     -3.8584843277931213e-01
    z[5,6,3]  R2617     8.2914769649505615e-02
    z[5,6,3]  R2618     3.1777891516685486e-01
    z[5,6,3]  R2619     -2.1474552154541016e-01
    z[5,6,3]  R2620     1.8357586860656738e-01
    z[5,6,3]  R2621     6.8477582931518555e-01
    z[5,6,3]  R2622     1.3806837797164917e-01
    z[5,6,3]  R2623     -6.0245178639888763e-02
    z[5,6,3]  R2624     2.5885561108589172e-01
    z[5,6,3]  R2625     -4.7876462340354919e-01
    z[5,6,3]  R2626     -0.363491028547287
    z[5,6,3]  R2627     5.1065343618392944e-01
    z[5,6,3]  R2628     -3.0907431617379189e-02
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2543     -1
    z[5,6,4]  R2544     1
    z[5,6,4]  R2549     -1.0070706158876419e-01
    z[5,6,4]  R2550     -1.3634567148983479e-02
    z[5,6,4]  R2551     -3.9490780234336853e-01
    z[5,6,4]  R2552     -7.0081901550292969e-01
    z[5,6,4]  R2553     -2.7202382683753967e-01
    z[5,6,4]  R2554     -7.1624511480331421e-01
    z[5,6,4]  R2555     -3.6926794052124023e-01
    z[5,6,4]  R2556     -2.2502495348453522e-01
    z[5,6,4]  R2557     -7.4040561914443970e-01
    z[5,6,4]  R2558     -4.0332981944084167e-01
    z[5,6,4]  R2559     1.3444192707538605e-01
    z[5,6,4]  R2560     -3.1734594702720642e-01
    z[5,6,4]  R2561     -2.3484092950820923e-01
    z[5,6,4]  R2562     -2.9067406058311462e-01
    z[5,6,4]  R2563     6.3229000568389893e-01
    z[5,6,4]  R2564     -5.0736343860626221e-01
    z[5,6,4]  R2565     0.506917417049408
    z[5,6,4]  R2566     -7.7919833362102509e-02
    z[5,6,4]  R2567     3.9742198586463928e-01
    z[5,6,4]  R2568     1.0552708804607391e-01
    z[5,6,4]  R2569     -1.6130340099334717e-01
    z[5,6,4]  R2570     3.4851184487342834e-01
    z[5,6,4]  R2571     -6.9361016154289246e-02
    z[5,6,4]  R2572     1.2959606945514679e-01
    z[5,6,4]  R2573     5.6489646434783936e-01
    z[5,6,4]  R2574     4.8991441726684570e-03
    z[5,6,4]  R2575     -2.3312436044216156e-01
    z[5,6,4]  R2576     1.7073912918567657e-01
    z[5,6,4]  R2577     2.7820253372192383e-01
    z[5,6,4]  R2578     4.2034569382667542e-01
    z[5,6,4]  R2579     1.9361329078674316e-01
    z[5,6,4]  R2580     -2.8481376171112061e-01
    z[5,6,4]  R2581     -2.1803827583789825e-01
    z[5,6,4]  R2582     4.5129823684692383e-01
    z[5,6,4]  R2583     1.5675261616706848e-01
    z[5,6,4]  R2584     2.2391228377819061e-01
    z[5,6,4]  R2585     -4.6196451783180237e-01
    z[5,6,4]  R2586     -1.4771398901939392e-01
    z[5,6,4]  R2587     -5.1097828149795532e-01
    z[5,6,4]  R2588     -5.4421371221542358e-01
    z[5,6,4]  R2589     -6.3743394613265991e-01
    z[5,6,4]  R2590     -1.3657073676586151e-01
    z[5,6,4]  R2591     -2.7995908260345459e-01
    z[5,6,4]  R2592     -5.8870977163314819e-01
    z[5,6,4]  R2593     -8.1852513551712036e-01
    z[5,6,4]  R2594     8.7458200752735138e-02
    z[5,6,4]  R2595     -4.6370047330856323e-01
    z[5,6,4]  R2596     1.2290842831134796e-01
    z[5,6,4]  R2597     -6.2325045466423035e-02
    z[5,6,4]  R2598     -7.8452903032302856e-01
    z[5,6,4]  R2599     8.9119784533977509e-02
    z[5,6,4]  R2600     1.4148251712322235e-01
    z[5,6,4]  R2601     1.2777429819107056e-01
    z[5,6,4]  R2602     1.1681786179542542e-01
    z[5,6,4]  R2603     3.0304929614067078e-01
    z[5,6,4]  R2604     -6.9315090775489807e-02
    z[5,6,4]  R2605     4.2483016848564148e-01
    z[5,6,4]  R2606     1.8962581455707550e-01
    z[5,6,4]  R2607     1.5284567140042782e-02
    z[5,6,4]  R2608     2.2329214215278625e-01
    z[5,6,4]  R2609     -3.4885589033365250e-02
    z[5,6,4]  R2610     -5.6437385082244873e-01
    z[5,6,4]  R2611     -3.9155066013336182e-01
    z[5,6,4]  R2612     6.4252310991287231e-01
    z[5,6,4]  R2613     -1.9448530673980713e-01
    z[5,6,4]  R2614     -5.9565279632806778e-02
    z[5,6,4]  R2615     4.3613232672214508e-02
    z[5,6,4]  R2616     -1.6706696152687073e-01
    z[5,6,4]  R2617     1.5945152938365936e-01
    z[5,6,4]  R2618     -0.700086772441864
    z[5,6,4]  R2619     -8.6237683892250061e-02
    z[5,6,4]  R2620     2.8281274437904358e-01
    z[5,6,4]  R2621     -1.9821323454380035e-01
    z[5,6,4]  R2622     -1.6417573392391205e-01
    z[5,6,4]  R2623     1.9250491261482239e-01
    z[5,6,4]  R2624     5.5724793672561646e-01
    z[5,6,4]  R2625     2.7393159270286560e-01
    z[5,6,4]  R2626     1.7277634143829346e-01
    z[5,6,4]  R2627     0.624572217464447
    z[5,6,4]  R2628     0.0839446485042572
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2545     -1
    z[5,6,5]  R2546     1
    z[5,6,5]  R2549     -5.0800494849681854e-02
    z[5,6,5]  R2550     -9.4277925789356232e-02
    z[5,6,5]  R2551     9.2811174690723419e-02
    z[5,6,5]  R2552     3.6907397210597992e-02
    z[5,6,5]  R2553     -0.507040798664093
    z[5,6,5]  R2554     1.0643025487661362e-01
    z[5,6,5]  R2555     1.7220909893512726e-01
    z[5,6,5]  R2556     -1.8397654639557004e-03
    z[5,6,5]  R2557     7.0711962878704071e-02
    z[5,6,5]  R2558     -3.0457055568695068e-01
    z[5,6,5]  R2559     3.8770747184753418e-01
    z[5,6,5]  R2560     2.7283772826194763e-01
    z[5,6,5]  R2561     -1.4870515465736389e-01
    z[5,6,5]  R2562     -3.4204626083374023e-01
    z[5,6,5]  R2563     0.234819233417511
    z[5,6,5]  R2564     5.3635202348232269e-03
    z[5,6,5]  R2565     -3.6725349724292755e-02
    z[5,6,5]  R2566     -6.6040062904357910e-01
    z[5,6,5]  R2567     -5.4062157869338989e-01
    z[5,6,5]  R2568     5.1187169551849365e-01
    z[5,6,5]  R2569     -3.2207533717155457e-02
    z[5,6,5]  R2570     1.4508533477783203e-01
    z[5,6,5]  R2571     1.7681367695331573e-02
    z[5,6,5]  R2572     -4.5329424738883972e-01
    z[5,6,5]  R2573     -3.1563788652420044e-01
    z[5,6,5]  R2574     -0.0409686341881752
    z[5,6,5]  R2575     -1.5406748652458191e-01
    z[5,6,5]  R2576     -2.9729914665222168e-01
    z[5,6,5]  R2577     3.2862354069948196e-02
    z[5,6,5]  R2578     3.7902233004570007e-01
    z[5,6,5]  R2579     -3.7913236021995544e-01
    z[5,6,5]  R2580     4.6682532876729965e-02
    z[5,6,5]  R2581     1.8612703308463097e-02
    z[5,6,5]  R2582     1.2646466493606567e-01
    z[5,6,5]  R2583     1.7543736100196838e-01
    z[5,6,5]  R2584     4.8359864950180054e-01
    z[5,6,5]  R2585     -2.4371019005775452e-01
    z[5,6,5]  R2586     3.6099547147750854e-01
    z[5,6,5]  R2587     3.1019651889801025e-01
    z[5,6,5]  R2588     5.7240617275238037e-01
    z[5,6,5]  R2589     2.0146530866622925e-01
    z[5,6,5]  R2590     1.3990907371044159e-01
    z[5,6,5]  R2591     3.3354374766349792e-01
    z[5,6,5]  R2592     3.0304759740829468e-01
    z[5,6,5]  R2593     3.3876052498817444e-01
    z[5,6,5]  R2594     3.4586733579635620e-01
    z[5,6,5]  R2595     2.0835934579372406e-01
    z[5,6,5]  R2596     2.6599800586700439e-01
    z[5,6,5]  R2597     4.1952362656593323e-01
    z[5,6,5]  R2598     4.9756024032831192e-02
    z[5,6,5]  R2599     -1.2804748117923737e-01
    z[5,6,5]  R2600     5.2556627988815308e-01
    z[5,6,5]  R2601     -1.1099065840244293e-01
    z[5,6,5]  R2602     -5.7539731264114380e-02
    z[5,6,5]  R2603     -2.8323435783386230e-01
    z[5,6,5]  R2604     -1.1019649356603622e-01
    z[5,6,5]  R2605     3.2817018032073975e-01
    z[5,6,5]  R2606     -1.2396162748336792e-01
    z[5,6,5]  R2607     -1.2915004789829254e-01
    z[5,6,5]  R2608     -2.5686267018318176e-01
    z[5,6,5]  R2609     -3.6452582478523254e-01
    z[5,6,5]  R2610     5.6535284966230392e-02
    z[5,6,5]  R2611     4.9025887250900269e-01
    z[5,6,5]  R2612     -2.7779844403266907e-01
    z[5,6,5]  R2613     6.3344120979309082e-01
    z[5,6,5]  R2614     6.5751016139984131e-01
    z[5,6,5]  R2615     -6.4349383115768433e-02
    z[5,6,5]  R2616     -1.0267642885446548e-01
    z[5,6,5]  R2617     7.5395655632019043e-01
    z[5,6,5]  R2618     -2.2027517855167389e-01
    z[5,6,5]  R2619     -1.9749562442302704e-01
    z[5,6,5]  R2620     1.4104568958282471e-01
    z[5,6,5]  R2621     -8.9955426752567291e-02
    z[5,6,5]  R2622     1.8768961727619171e-01
    z[5,6,5]  R2623     -4.1778244078159332e-02
    z[5,6,5]  R2624     -2.9994806647300720e-01
    z[5,6,5]  R2625     -1.2022332102060318e-01
    z[5,6,5]  R2626     -1.8738360702991486e-01
    z[5,6,5]  R2627     1.8032878637313843e-01
    z[5,6,5]  R2628     -1.3821698725223541e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2547     -1
    z[5,6,6]  R2548     1
    z[5,6,6]  R2549     -2.3464743793010712e-01
    z[5,6,6]  R2550     -0.00269176228903234
    z[5,6,6]  R2551     -2.0108632743358612e-02
    z[5,6,6]  R2552     -9.2202380299568176e-02
    z[5,6,6]  R2553     -3.0818411707878113e-01
    z[5,6,6]  R2554     2.7658066153526306e-01
    z[5,6,6]  R2555     -3.6036711931228638e-01
    z[5,6,6]  R2556     -2.0022788643836975e-01
    z[5,6,6]  R2557     3.8570842146873474e-01
    z[5,6,6]  R2558     4.3169371783733368e-02
    z[5,6,6]  R2559     -2.3951490223407745e-01
    z[5,6,6]  R2560     2.3476506769657135e-01
    z[5,6,6]  R2561     -5.2156221866607666e-01
    z[5,6,6]  R2562     -4.1077283024787903e-01
    z[5,6,6]  R2563     -3.8127502799034119e-01
    z[5,6,6]  R2564     7.4389182031154633e-02
    z[5,6,6]  R2565     -5.8623957633972168e-01
    z[5,6,6]  R2566     -1.9564349949359894e-01
    z[5,6,6]  R2567     1.0843480378389359e-01
    z[5,6,6]  R2568     3.2398089766502380e-01
    z[5,6,6]  R2569     4.0459696203470230e-02
    z[5,6,6]  R2570     1.4328195713460445e-02
    z[5,6,6]  R2571     3.8968941569328308e-01
    z[5,6,6]  R2572     -5.0769710540771484e-01
    z[5,6,6]  R2573     -5.2033182233572006e-02
    z[5,6,6]  R2574     -2.9633262753486633e-01
    z[5,6,6]  R2575     1.1406043171882629e-01
    z[5,6,6]  R2576     1.0423842817544937e-01
    z[5,6,6]  R2577     3.0068987607955933e-01
    z[5,6,6]  R2578     2.0920639857649803e-02
    z[5,6,6]  R2579     -2.9510427266359329e-02
    z[5,6,6]  R2580     -2.2846154868602753e-01
    z[5,6,6]  R2581     7.8258194029331207e-02
    z[5,6,6]  R2582     -9.1191329061985016e-02
    z[5,6,6]  R2583     1.6566129028797150e-01
    z[5,6,6]  R2584     -4.1446119546890259e-02
    z[5,6,6]  R2585     3.5865768790245056e-01
    z[5,6,6]  R2586     2.5416895747184753e-01
    z[5,6,6]  R2587     -5.0566267222166061e-02
    z[5,6,6]  R2588     2.9101157188415527e-01
    z[5,6,6]  R2589     2.9068502783775330e-01
    z[5,6,6]  R2590     2.8227454423904419e-01
    z[5,6,6]  R2591     1.7670619487762451e-01
    z[5,6,6]  R2592     -1.1906898766756058e-01
    z[5,6,6]  R2593     -1.2550881505012512e-01
    z[5,6,6]  R2594     -5.1650381088256836e-01
    z[5,6,6]  R2595     -4.2562881112098694e-01
    z[5,6,6]  R2596     0.447286456823349
    z[5,6,6]  R2597     -2.2831052541732788e-02
    z[5,6,6]  R2598     -1.1260929703712463e-01
    z[5,6,6]  R2599     1.2358459830284119e-01
    z[5,6,6]  R2600     0.00592637388035655
    z[5,6,6]  R2601     -1.7166891694068909e-01
    z[5,6,6]  R2602     6.7347057163715363e-02
    z[5,6,6]  R2603     5.3730695508420467e-03
    z[5,6,6]  R2604     -7.0308116264641285e-03
    z[5,6,6]  R2605     -2.6035559177398682e-01
    z[5,6,6]  R2606     -5.4442346096038818e-02
    z[5,6,6]  R2607     -2.9928541183471680e-01
    z[5,6,6]  R2608     -4.4294662773609161e-02
    z[5,6,6]  R2609     3.9246085286140442e-01
    z[5,6,6]  R2610     5.1586157083511353e-01
    z[5,6,6]  R2611     6.9776542484760284e-02
    z[5,6,6]  R2612     2.9474783688783646e-02
    z[5,6,6]  R2613     -8.5204273462295532e-02
    z[5,6,6]  R2614     1.3028287887573242e-01
    z[5,6,6]  R2615     -6.7805522680282593e-01
    z[5,6,6]  R2616     -6.6481471061706543e-01
    z[5,6,6]  R2617     0.299459844827652
    z[5,6,6]  R2618     -1.1630912870168686e-01
    z[5,6,6]  R2619     -2.8347286581993103e-01
    z[5,6,6]  R2620     -4.8547599464654922e-02
    z[5,6,6]  R2621     3.9975982904434204e-01
    z[5,6,6]  R2622     -6.5692657232284546e-01
    z[5,6,6]  R2623     -6.9269323348999023e-01
    z[5,6,6]  R2624     1.5495055913925171e-01
    z[5,6,6]  R2625     4.4680300354957581e-01
    z[5,6,6]  R2626     7.6224094629287720e-01
    z[5,6,6]  R2627     -6.8241044878959656e-02
    z[5,6,6]  R2628     8.2412803173065186e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2629     -1
    z[6,5,0]  R2630     1
    z[6,5,0]  R2643     -2.1240970492362976e-01
    z[6,5,0]  R2644     5.6615126132965088e-01
    z[6,5,0]  R2645     -0.287582129240036
    z[6,5,0]  R2646     3.9139175415039062e-01
    z[6,5,0]  R2647     8.9847363531589508e-02
    z[6,5,0]  R2648     -1.3517257571220398e-01
    z[6,5,0]  R2649     6.2380012124776840e-02
    z[6,5,0]  R2650     -3.1546853482723236e-02
    z[6,5,0]  R2651     -3.2627135515213013e-01
    z[6,5,0]  R2652     3.7415587902069092e-01
    z[6,5,0]  R2653     -2.1480867266654968e-01
    z[6,5,0]  R2654     -2.4702057242393494e-01
    z[6,5,0]  R2655     0.0647042840719223
    z[6,5,0]  R2656     -0.0897059440612793
    z[6,5,0]  R2657     7.5556194782257080e-01
    z[6,5,0]  R2658     -6.9648653268814087e-01
    z[6,5,0]  R2659     4.2574423551559448e-01
    z[6,5,0]  R2660     -8.8941919803619385e-01
    z[6,5,0]  R2661     6.2374550104141235e-01
    z[6,5,0]  R2662     -5.0331413745880127e-01
    z[6,5,0]  R2663     2.9560112953186035e-01
    z[6,5,0]  R2664     -1.8875746428966522e-01
    z[6,5,0]  R2665     -3.9666953682899475e-01
    z[6,5,0]  R2666     -1.5260013937950134e-01
    z[6,5,0]  R2667     4.4463074207305908e-01
    z[6,5,0]  R2668     1.3967847824096680e-01
    z[6,5,0]  R2669     -5.1141440868377686e-01
    z[6,5,0]  R2670     -3.6340034008026123e-01
    z[6,5,0]  R2671     2.8061848878860474e-01
    z[6,5,0]  R2672     1.1992813646793365e-01
    z[6,5,0]  R2673     -1.1969466507434845e-01
    z[6,5,0]  R2674     0.891903281211853
    z[6,5,0]  R2675     -0.0440092533826828
    z[6,5,0]  R2676     6.9294106960296631e-01
    z[6,5,0]  R2677     6.0244774818420410e-01
    z[6,5,0]  R2678     -8.1641167402267456e-02
    z[6,5,0]  R2679     5.6040030717849731e-01
    z[6,5,0]  R2680     4.0766561031341553e-01
    z[6,5,0]  R2681     3.1279277754947543e-04
    z[6,5,0]  R2682     4.6923488378524780e-01
    z[6,5,0]  R2683     -2.4731977283954620e-01
    z[6,5,0]  R2684     0.085629403591156
    z[6,5,0]  R2685     5.9188399463891983e-02
    z[6,5,0]  R2686     -1.6589473187923431e-01
    z[6,5,0]  R2687     -1.7032325267791748e-02
    z[6,5,0]  R2688     -4.5395351946353912e-02
    z[6,5,0]  R2689     -1.6201204061508179e-01
    z[6,5,0]  R2690     -1.8934737890958786e-02
    z[6,5,0]  R2691     0.150125190615654
    z[6,5,0]  R2692     -3.8735404610633850e-01
    z[6,5,0]  R2693     -2.1382641792297363e-01
    z[6,5,0]  R2694     -3.5925221443176270e-01
    z[6,5,0]  R2695     -3.9004248380661011e-01
    z[6,5,0]  R2696     -8.7264098227024078e-02
    z[6,5,0]  R2697     1.8645381554961205e-02
    z[6,5,0]  R2698     -3.1487077474594116e-01
    z[6,5,0]  R2699     -6.3983634114265442e-02
    z[6,5,0]  R2700     3.1601474620401859e-03
    z[6,5,0]  R2701     2.7315232157707214e-01
    z[6,5,0]  R2702     -1.1055515706539154e-01
    z[6,5,0]  R2703     -5.3513408638536930e-03
    z[6,5,0]  R2704     1.9580383598804474e-01
    z[6,5,0]  R2705     4.4064730405807495e-01
    z[6,5,0]  R2706     2.6081116870045662e-02
    z[6,5,0]  R2707     2.1425299346446991e-01
    z[6,5,0]  R2708     -2.5385084748268127e-01
    z[6,5,0]  R2709     -5.7478111237287521e-02
    z[6,5,0]  R2710     8.5354052484035492e-02
    z[6,5,0]  R2711     2.3851613700389862e-01
    z[6,5,0]  R2712     -1.3423493504524231e-01
    z[6,5,0]  R2713     -3.6913685500621796e-02
    z[6,5,0]  R2714     -2.1532289683818817e-01
    z[6,5,0]  R2715     -2.3875330388545990e-01
    z[6,5,0]  R2716     9.2885173857212067e-02
    z[6,5,0]  R2717     5.3868040442466736e-02
    z[6,5,0]  R2718     1.3729308545589447e-01
    z[6,5,0]  R2719     1.9400085508823395e-01
    z[6,5,0]  R2720     2.4801792204380035e-01
    z[6,5,0]  R2721     5.0494468212127686e-01
    z[6,5,0]  R2722     2.1552659571170807e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2631     -1
    z[6,5,1]  R2632     1
    z[6,5,1]  R2643     -4.4346127659082413e-02
    z[6,5,1]  R2644     -9.0379834175109863e-02
    z[6,5,1]  R2645     -1.5228827297687531e-01
    z[6,5,1]  R2646     -1.0052482783794403e-01
    z[6,5,1]  R2647     -3.9079539477825165e-02
    z[6,5,1]  R2648     -1.6333429515361786e-01
    z[6,5,1]  R2649     -5.1454100757837296e-02
    z[6,5,1]  R2650     -5.8109525591135025e-02
    z[6,5,1]  R2651     9.2844374477863312e-02
    z[6,5,1]  R2652     -8.1013187766075134e-02
    z[6,5,1]  R2653     8.1758999824523926e-01
    z[6,5,1]  R2654     -2.7423635125160217e-01
    z[6,5,1]  R2655     9.2157393693923950e-01
    z[6,5,1]  R2656     9.1725713014602661e-01
    z[6,5,1]  R2657     -3.1591439247131348e-01
    z[6,5,1]  R2658     -4.2140522599220276e-01
    z[6,5,1]  R2659     -2.1396489441394806e-01
    z[6,5,1]  R2660     -0.283568799495697
    z[6,5,1]  R2661     3.6306354403495789e-01
    z[6,5,1]  R2662     -5.2217030525207520e-01
    z[6,5,1]  R2663     -7.4705088138580322e-01
    z[6,5,1]  R2664     -6.0879707336425781e-01
    z[6,5,1]  R2665     -6.1021369695663452e-01
    z[6,5,1]  R2666     -5.2069664001464844e-01
    z[6,5,1]  R2667     -5.0037395954132080e-01
    z[6,5,1]  R2668     -5.1626527309417725e-01
    z[6,5,1]  R2669     -4.8499128222465515e-01
    z[6,5,1]  R2670     -4.2986959218978882e-01
    z[6,5,1]  R2671     -4.6784445643424988e-01
    z[6,5,1]  R2672     -5.2109575271606445e-01
    z[6,5,1]  R2673     -6.4972156286239624e-01
    z[6,5,1]  R2674     1.3706804811954498e-01
    z[6,5,1]  R2675     -5.5932825803756714e-01
    z[6,5,1]  R2676     4.6786937862634659e-02
    z[6,5,1]  R2677     -2.8206637501716614e-01
    z[6,5,1]  R2678     -0.646415650844574
    z[6,5,1]  R2679     4.0782818198204041e-01
    z[6,5,1]  R2680     1.4009904861450195e-01
    z[6,5,1]  R2681     -2.5747969746589661e-01
    z[6,5,1]  R2682     2.2282439470291138e-01
    z[6,5,1]  R2683     9.2446643114089966e-01
    z[6,5,1]  R2684     9.8886710405349731e-01
    z[6,5,1]  R2685     -3.0416840687394142e-02
    z[6,5,1]  R2686     6.3676489517092705e-03
    z[6,5,1]  R2687     5.7651054859161377e-01
    z[6,5,1]  R2688     -3.4543506801128387e-02
    z[6,5,1]  R2689     -0.0232999287545681
    z[6,5,1]  R2690     -3.5011786967515945e-02
    z[6,5,1]  R2691     -6.4352788031101227e-02
    z[6,5,1]  R2692     -5.5713269859552383e-02
    z[6,5,1]  R2693     -6.2276363372802734e-01
    z[6,5,1]  R2694     -6.0613393783569336e-01
    z[6,5,1]  R2695     -0.557383120059967
    z[6,5,1]  R2696     -5.5232745409011841e-01
    z[6,5,1]  R2697     -5.3412622213363647e-01
    z[6,5,1]  R2698     -5.6050300598144531e-01
    z[6,5,1]  R2699     -4.9303579330444336e-01
    z[6,5,1]  R2700     -5.4293894767761230e-01
    z[6,5,1]  R2701     -5.5307763814926147e-01
    z[6,5,1]  R2702     -4.9725890159606934e-01
    z[6,5,1]  R2703     -9.8264390230178833e-01
    z[6,5,1]  R2704     -7.9808372259140015e-01
    z[6,5,1]  R2705     -6.5045034885406494e-01
    z[6,5,1]  R2706     -4.5593962073326111e-01
    z[6,5,1]  R2707     0.483502060174942
    z[6,5,1]  R2708     6.7729687690734863e-01
    z[6,5,1]  R2709     5.8949595689773560e-01
    z[6,5,1]  R2710     3.5691463947296143e-01
    z[6,5,1]  R2711     7.8776067495346069e-01
    z[6,5,1]  R2712     5.6254655122756958e-01
    z[6,5,1]  R2713     0.73489910364151
    z[6,5,1]  R2714     0.717809796333313
    z[6,5,1]  R2715     8.3352595567703247e-01
    z[6,5,1]  R2716     7.7697873115539551e-01
    z[6,5,1]  R2717     6.3356381654739380e-01
    z[6,5,1]  R2718     6.9384175539016724e-01
    z[6,5,1]  R2719     7.0997720956802368e-01
    z[6,5,1]  R2720     7.7718651294708252e-01
    z[6,5,1]  R2721     -2.2949238121509552e-01
    z[6,5,1]  R2722     -7.7543258666992188e-02
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2633     -1
    z[6,5,2]  R2634     1
    z[6,5,2]  R2643     -6.2255424261093140e-01
    z[6,5,2]  R2644     -7.4332630634307861e-01
    z[6,5,2]  R2645     -8.0464816093444824e-01
    z[6,5,2]  R2646     -6.0049152374267578e-01
    z[6,5,2]  R2647     -1.8468938767910004e-01
    z[6,5,2]  R2648     -7.3881131410598755e-01
    z[6,5,2]  R2649     -6.4745169878005981e-01
    z[6,5,2]  R2650     -8.3255708217620850e-01
    z[6,5,2]  R2651     -8.3497482538223267e-01
    z[6,5,2]  R2652     -3.6337402462959290e-01
    z[6,5,2]  R2653     3.0558711290359497e-01
    z[6,5,2]  R2654     5.8320814371109009e-01
    z[6,5,2]  R2655     2.4961875379085541e-01
    z[6,5,2]  R2656     2.9769837856292725e-01
    z[6,5,2]  R2657     2.1694932878017426e-01
    z[6,5,2]  R2658     2.8463923931121826e-01
    z[6,5,2]  R2659     2.0543260872364044e-01
    z[6,5,2]  R2660     2.0874388515949249e-01
    z[6,5,2]  R2661     0.381873220205307
    z[6,5,2]  R2662     3.4576156735420227e-01
    z[6,5,2]  R2663     1.0945479571819305e-01
    z[6,5,2]  R2664     -3.2285865396261215e-02
    z[6,5,2]  R2665     -5.2841058932244778e-03
    z[6,5,2]  R2666     2.2360880672931671e-01
    z[6,5,2]  R2667     3.1841287016868591e-01
    z[6,5,2]  R2668     -3.3113136887550354e-01
    z[6,5,2]  R2669     1.0439525544643402e-01
    z[6,5,2]  R2670     2.3203656077384949e-01
    z[6,5,2]  R2671     -1.0930939763784409e-01
    z[6,5,2]  R2672     2.4682506918907166e-01
    z[6,5,2]  R2673     -6.2499684095382690e-01
    z[6,5,2]  R2674     -2.2313027083873749e-01
    z[6,5,2]  R2675     -9.5440290868282318e-02
    z[6,5,2]  R2676     -6.9622255861759186e-02
    z[6,5,2]  R2677     -1.8771840631961823e-01
    z[6,5,2]  R2678     -2.8977859020233154e-01
    z[6,5,2]  R2679     0.0358751118183136
    z[6,5,2]  R2680     -1.8994650244712830e-01
    z[6,5,2]  R2681     -4.9565258622169495e-01
    z[6,5,2]  R2682     1.5451537072658539e-01
    z[6,5,2]  R2683     8.9352488517761230e-02
    z[6,5,2]  R2684     -0.0491953007876873
    z[6,5,2]  R2685     -7.9013854265213013e-01
    z[6,5,2]  R2686     -6.8222486972808838e-01
    z[6,5,2]  R2687     -1.4217109978199005e-01
    z[6,5,2]  R2688     -5.9088891744613647e-01
    z[6,5,2]  R2689     -8.1355655193328857e-01
    z[6,5,2]  R2690     -5.0917977094650269e-01
    z[6,5,2]  R2691     -4.6965035796165466e-01
    z[6,5,2]  R2692     -6.6920286417007446e-01
    z[6,5,2]  R2693     1.2158872932195663e-01
    z[6,5,2]  R2694     4.0791156888008118e-01
    z[6,5,2]  R2695     -3.8222637772560120e-01
    z[6,5,2]  R2696     -5.6150525808334351e-01
    z[6,5,2]  R2697     -3.2182133197784424e-01
    z[6,5,2]  R2698     -5.4858695715665817e-02
    z[6,5,2]  R2699     -2.4375198781490326e-01
    z[6,5,2]  R2700     -1.9812296330928802e-01
    z[6,5,2]  R2701     3.9448940753936768e-01
    z[6,5,2]  R2702     5.7450169324874878e-01
    z[6,5,2]  R2703     -0.0683421716094017
    z[6,5,2]  R2704     -2.9872161149978638e-01
    z[6,5,2]  R2705     -3.4258782863616943e-02
    z[6,5,2]  R2706     -2.4924477934837341e-01
    z[6,5,2]  R2707     4.2520549893379211e-01
    z[6,5,2]  R2708     3.0196332931518555e-01
    z[6,5,2]  R2709     4.8791524767875671e-01
    z[6,5,2]  R2710     6.5476822853088379e-01
    z[6,5,2]  R2711     3.7515634298324585e-01
    z[6,5,2]  R2712     5.4492139816284180e-01
    z[6,5,2]  R2713     5.1817828416824341e-01
    z[6,5,2]  R2714     2.5820646435022354e-02
    z[6,5,2]  R2715     4.3365576863288879e-01
    z[6,5,2]  R2716     2.0073603093624115e-01
    z[6,5,2]  R2717     4.8572579026222229e-01
    z[6,5,2]  R2718     -2.1406058967113495e-01
    z[6,5,2]  R2719     1.0951752215623856e-01
    z[6,5,2]  R2720     -3.0360126495361328e-01
    z[6,5,2]  R2721     -5.7654780149459839e-01
    z[6,5,2]  R2722     -4.5599821209907532e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2635     -1
    z[6,5,3]  R2636     1
    z[6,5,3]  R2643     -1.8421080708503723e-01
    z[6,5,3]  R2644     -2.9413759708404541e-02
    z[6,5,3]  R2645     1.6060025990009308e-01
    z[6,5,3]  R2646     1.5337137877941132e-01
    z[6,5,3]  R2647     3.9470937848091125e-01
    z[6,5,3]  R2648     1.2312074750661850e-01
    z[6,5,3]  R2649     -0.366982102394104
    z[6,5,3]  R2650     1.2864798307418823e-01
    z[6,5,3]  R2651     -8.5663378238677979e-02
    z[6,5,3]  R2652     -3.0126622319221497e-01
    z[6,5,3]  R2653     3.9039561152458191e-01
    z[6,5,3]  R2654     -4.7683459520339966e-01
    z[6,5,3]  R2655     -1.6152353584766388e-01
    z[6,5,3]  R2656     -2.0118415355682373e-01
    z[6,5,3]  R2657     3.3191543817520142e-01
    z[6,5,3]  R2658     4.8919060826301575e-01
    z[6,5,3]  R2659     -6.1220663785934448e-01
    z[6,5,3]  R2660     1.7509926855564117e-01
    z[6,5,3]  R2661     -4.7625014185905457e-01
    z[6,5,3]  R2662     4.8647928237915039e-01
    z[6,5,3]  R2663     -2.3330879211425781e-01
    z[6,5,3]  R2664     -6.9764018058776855e-02
    z[6,5,3]  R2665     2.6782515645027161e-01
    z[6,5,3]  R2666     -0.405845582485199
    z[6,5,3]  R2667     6.4888454973697662e-02
    z[6,5,3]  R2668     -3.8919255137443542e-01
    z[6,5,3]  R2669     1.6290649771690369e-01
    z[6,5,3]  R2670     -3.8584843277931213e-01
    z[6,5,3]  R2671     8.2914769649505615e-02
    z[6,5,3]  R2672     3.1777891516685486e-01
    z[6,5,3]  R2673     -2.1474552154541016e-01
    z[6,5,3]  R2674     1.8357586860656738e-01
    z[6,5,3]  R2675     6.8477582931518555e-01
    z[6,5,3]  R2676     1.3806837797164917e-01
    z[6,5,3]  R2677     -6.0245178639888763e-02
    z[6,5,3]  R2678     2.5885561108589172e-01
    z[6,5,3]  R2679     -4.7876462340354919e-01
    z[6,5,3]  R2680     -0.363491028547287
    z[6,5,3]  R2681     5.1065343618392944e-01
    z[6,5,3]  R2682     -3.0907431617379189e-02
    z[6,5,3]  R2683     -0.0918092280626297
    z[6,5,3]  R2684     -5.7513605803251266e-02
    z[6,5,3]  R2685     4.5418307185173035e-01
    z[6,5,3]  R2686     7.7439472079277039e-02
    z[6,5,3]  R2687     -4.7017872333526611e-01
    z[6,5,3]  R2688     2.1625219285488129e-01
    z[6,5,3]  R2689     1.2432087957859039e-01
    z[6,5,3]  R2690     8.0524575710296631e-01
    z[6,5,3]  R2691     2.2533978521823883e-01
    z[6,5,3]  R2692     3.7645533680915833e-01
    z[6,5,3]  R2693     -5.7087731361389160e-01
    z[6,5,3]  R2694     3.2693132758140564e-01
    z[6,5,3]  R2695     2.0445835590362549e-01
    z[6,5,3]  R2696     -4.2540755122900009e-02
    z[6,5,3]  R2697     1.0242677479982376e-01
    z[6,5,3]  R2698     5.6630659103393555e-01
    z[6,5,3]  R2699     -3.0235049128532410e-01
    z[6,5,3]  R2700     4.3067130446434021e-01
    z[6,5,3]  R2701     -4.3552737683057785e-02
    z[6,5,3]  R2702     -1.7985163629055023e-01
    z[6,5,3]  R2703     -3.1912997364997864e-02
    z[6,5,3]  R2704     3.0458664894104004e-01
    z[6,5,3]  R2705     -4.7390836477279663e-01
    z[6,5,3]  R2706     -4.9928811192512512e-01
    z[6,5,3]  R2707     -3.4362620115280151e-01
    z[6,5,3]  R2708     -5.4417955875396729e-01
    z[6,5,3]  R2709     -5.6571716070175171e-01
    z[6,5,3]  R2710     -5.5515849590301514e-01
    z[6,5,3]  R2711     -1.1362207680940628e-01
    z[6,5,3]  R2712     -2.1862530708312988e-01
    z[6,5,3]  R2713     -8.9182555675506592e-02
    z[6,5,3]  R2714     -5.4975038766860962e-01
    z[6,5,3]  R2715     -7.8502416610717773e-02
    z[6,5,3]  R2716     -3.4554621577262878e-01
    z[6,5,3]  R2717     -0.526281476020813
    z[6,5,3]  R2718     -4.1011002659797668e-01
    z[6,5,3]  R2719     -2.1180368959903717e-01
    z[6,5,3]  R2720     -1.5986070036888123e-01
    z[6,5,3]  R2721     8.8934656232595444e-03
    z[6,5,3]  R2722     1.7634023725986481e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2637     -1
    z[6,5,4]  R2638     1
    z[6,5,4]  R2643     -6.3743394613265991e-01
    z[6,5,4]  R2644     -1.3657073676586151e-01
    z[6,5,4]  R2645     -2.7995908260345459e-01
    z[6,5,4]  R2646     -5.8870977163314819e-01
    z[6,5,4]  R2647     -8.1852513551712036e-01
    z[6,5,4]  R2648     8.7458200752735138e-02
    z[6,5,4]  R2649     -4.6370047330856323e-01
    z[6,5,4]  R2650     1.2290842831134796e-01
    z[6,5,4]  R2651     -6.2325045466423035e-02
    z[6,5,4]  R2652     -7.8452903032302856e-01
    z[6,5,4]  R2653     8.9119784533977509e-02
    z[6,5,4]  R2654     1.4148251712322235e-01
    z[6,5,4]  R2655     1.2777429819107056e-01
    z[6,5,4]  R2656     1.1681786179542542e-01
    z[6,5,4]  R2657     3.0304929614067078e-01
    z[6,5,4]  R2658     -6.9315090775489807e-02
    z[6,5,4]  R2659     4.2483016848564148e-01
    z[6,5,4]  R2660     1.8962581455707550e-01
    z[6,5,4]  R2661     1.5284567140042782e-02
    z[6,5,4]  R2662     2.2329214215278625e-01
    z[6,5,4]  R2663     -3.4885589033365250e-02
    z[6,5,4]  R2664     -5.6437385082244873e-01
    z[6,5,4]  R2665     -3.9155066013336182e-01
    z[6,5,4]  R2666     6.4252310991287231e-01
    z[6,5,4]  R2667     -1.9448530673980713e-01
    z[6,5,4]  R2668     -5.9565279632806778e-02
    z[6,5,4]  R2669     4.3613232672214508e-02
    z[6,5,4]  R2670     -1.6706696152687073e-01
    z[6,5,4]  R2671     1.5945152938365936e-01
    z[6,5,4]  R2672     -0.700086772441864
    z[6,5,4]  R2673     -8.6237683892250061e-02
    z[6,5,4]  R2674     2.8281274437904358e-01
    z[6,5,4]  R2675     -1.9821323454380035e-01
    z[6,5,4]  R2676     -1.6417573392391205e-01
    z[6,5,4]  R2677     1.9250491261482239e-01
    z[6,5,4]  R2678     5.5724793672561646e-01
    z[6,5,4]  R2679     2.7393159270286560e-01
    z[6,5,4]  R2680     1.7277634143829346e-01
    z[6,5,4]  R2681     0.624572217464447
    z[6,5,4]  R2682     0.0839446485042572
    z[6,5,4]  R2683     -1.0070706158876419e-01
    z[6,5,4]  R2684     -1.3634567148983479e-02
    z[6,5,4]  R2685     -3.9490780234336853e-01
    z[6,5,4]  R2686     -7.0081901550292969e-01
    z[6,5,4]  R2687     -2.7202382683753967e-01
    z[6,5,4]  R2688     -7.1624511480331421e-01
    z[6,5,4]  R2689     -3.6926794052124023e-01
    z[6,5,4]  R2690     -2.2502495348453522e-01
    z[6,5,4]  R2691     -7.4040561914443970e-01
    z[6,5,4]  R2692     -4.0332981944084167e-01
    z[6,5,4]  R2693     1.3444192707538605e-01
    z[6,5,4]  R2694     -3.1734594702720642e-01
    z[6,5,4]  R2695     -2.3484092950820923e-01
    z[6,5,4]  R2696     -2.9067406058311462e-01
    z[6,5,4]  R2697     6.3229000568389893e-01
    z[6,5,4]  R2698     -5.0736343860626221e-01
    z[6,5,4]  R2699     0.506917417049408
    z[6,5,4]  R2700     -7.7919833362102509e-02
    z[6,5,4]  R2701     3.9742198586463928e-01
    z[6,5,4]  R2702     1.0552708804607391e-01
    z[6,5,4]  R2703     -1.6130340099334717e-01
    z[6,5,4]  R2704     3.4851184487342834e-01
    z[6,5,4]  R2705     -6.9361016154289246e-02
    z[6,5,4]  R2706     1.2959606945514679e-01
    z[6,5,4]  R2707     5.6489646434783936e-01
    z[6,5,4]  R2708     4.8991441726684570e-03
    z[6,5,4]  R2709     -2.3312436044216156e-01
    z[6,5,4]  R2710     1.7073912918567657e-01
    z[6,5,4]  R2711     2.7820253372192383e-01
    z[6,5,4]  R2712     4.2034569382667542e-01
    z[6,5,4]  R2713     1.9361329078674316e-01
    z[6,5,4]  R2714     -2.8481376171112061e-01
    z[6,5,4]  R2715     -2.1803827583789825e-01
    z[6,5,4]  R2716     4.5129823684692383e-01
    z[6,5,4]  R2717     1.5675261616706848e-01
    z[6,5,4]  R2718     2.2391228377819061e-01
    z[6,5,4]  R2719     -4.6196451783180237e-01
    z[6,5,4]  R2720     -1.4771398901939392e-01
    z[6,5,4]  R2721     -5.1097828149795532e-01
    z[6,5,4]  R2722     -5.4421371221542358e-01
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2639     -1
    z[6,5,5]  R2640     1
    z[6,5,5]  R2643     2.0146530866622925e-01
    z[6,5,5]  R2644     1.3990907371044159e-01
    z[6,5,5]  R2645     3.3354374766349792e-01
    z[6,5,5]  R2646     3.0304759740829468e-01
    z[6,5,5]  R2647     3.3876052498817444e-01
    z[6,5,5]  R2648     3.4586733579635620e-01
    z[6,5,5]  R2649     2.0835934579372406e-01
    z[6,5,5]  R2650     2.6599800586700439e-01
    z[6,5,5]  R2651     4.1952362656593323e-01
    z[6,5,5]  R2652     4.9756024032831192e-02
    z[6,5,5]  R2653     -1.2804748117923737e-01
    z[6,5,5]  R2654     5.2556627988815308e-01
    z[6,5,5]  R2655     -1.1099065840244293e-01
    z[6,5,5]  R2656     -5.7539731264114380e-02
    z[6,5,5]  R2657     -2.8323435783386230e-01
    z[6,5,5]  R2658     -1.1019649356603622e-01
    z[6,5,5]  R2659     3.2817018032073975e-01
    z[6,5,5]  R2660     -1.2396162748336792e-01
    z[6,5,5]  R2661     -1.2915004789829254e-01
    z[6,5,5]  R2662     -2.5686267018318176e-01
    z[6,5,5]  R2663     -3.6452582478523254e-01
    z[6,5,5]  R2664     5.6535284966230392e-02
    z[6,5,5]  R2665     4.9025887250900269e-01
    z[6,5,5]  R2666     -2.7779844403266907e-01
    z[6,5,5]  R2667     6.3344120979309082e-01
    z[6,5,5]  R2668     6.5751016139984131e-01
    z[6,5,5]  R2669     -6.4349383115768433e-02
    z[6,5,5]  R2670     -1.0267642885446548e-01
    z[6,5,5]  R2671     7.5395655632019043e-01
    z[6,5,5]  R2672     -2.2027517855167389e-01
    z[6,5,5]  R2673     -1.9749562442302704e-01
    z[6,5,5]  R2674     1.4104568958282471e-01
    z[6,5,5]  R2675     -8.9955426752567291e-02
    z[6,5,5]  R2676     1.8768961727619171e-01
    z[6,5,5]  R2677     -4.1778244078159332e-02
    z[6,5,5]  R2678     -2.9994806647300720e-01
    z[6,5,5]  R2679     -1.2022332102060318e-01
    z[6,5,5]  R2680     -1.8738360702991486e-01
    z[6,5,5]  R2681     1.8032878637313843e-01
    z[6,5,5]  R2682     -1.3821698725223541e-01
    z[6,5,5]  R2683     -5.0800494849681854e-02
    z[6,5,5]  R2684     -9.4277925789356232e-02
    z[6,5,5]  R2685     9.2811174690723419e-02
    z[6,5,5]  R2686     3.6907397210597992e-02
    z[6,5,5]  R2687     -0.507040798664093
    z[6,5,5]  R2688     1.0643025487661362e-01
    z[6,5,5]  R2689     1.7220909893512726e-01
    z[6,5,5]  R2690     -1.8397654639557004e-03
    z[6,5,5]  R2691     7.0711962878704071e-02
    z[6,5,5]  R2692     -3.0457055568695068e-01
    z[6,5,5]  R2693     3.8770747184753418e-01
    z[6,5,5]  R2694     2.7283772826194763e-01
    z[6,5,5]  R2695     -1.4870515465736389e-01
    z[6,5,5]  R2696     -3.4204626083374023e-01
    z[6,5,5]  R2697     0.234819233417511
    z[6,5,5]  R2698     5.3635202348232269e-03
    z[6,5,5]  R2699     -3.6725349724292755e-02
    z[6,5,5]  R2700     -6.6040062904357910e-01
    z[6,5,5]  R2701     -5.4062157869338989e-01
    z[6,5,5]  R2702     5.1187169551849365e-01
    z[6,5,5]  R2703     -3.2207533717155457e-02
    z[6,5,5]  R2704     1.4508533477783203e-01
    z[6,5,5]  R2705     1.7681367695331573e-02
    z[6,5,5]  R2706     -4.5329424738883972e-01
    z[6,5,5]  R2707     -3.1563788652420044e-01
    z[6,5,5]  R2708     -0.0409686341881752
    z[6,5,5]  R2709     -1.5406748652458191e-01
    z[6,5,5]  R2710     -2.9729914665222168e-01
    z[6,5,5]  R2711     3.2862354069948196e-02
    z[6,5,5]  R2712     3.7902233004570007e-01
    z[6,5,5]  R2713     -3.7913236021995544e-01
    z[6,5,5]  R2714     4.6682532876729965e-02
    z[6,5,5]  R2715     1.8612703308463097e-02
    z[6,5,5]  R2716     1.2646466493606567e-01
    z[6,5,5]  R2717     1.7543736100196838e-01
    z[6,5,5]  R2718     4.8359864950180054e-01
    z[6,5,5]  R2719     -2.4371019005775452e-01
    z[6,5,5]  R2720     3.6099547147750854e-01
    z[6,5,5]  R2721     3.1019651889801025e-01
    z[6,5,5]  R2722     5.7240617275238037e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2641     -1
    z[6,5,6]  R2642     1
    z[6,5,6]  R2643     2.9068502783775330e-01
    z[6,5,6]  R2644     2.8227454423904419e-01
    z[6,5,6]  R2645     1.7670619487762451e-01
    z[6,5,6]  R2646     -1.1906898766756058e-01
    z[6,5,6]  R2647     -1.2550881505012512e-01
    z[6,5,6]  R2648     -5.1650381088256836e-01
    z[6,5,6]  R2649     -4.2562881112098694e-01
    z[6,5,6]  R2650     0.447286456823349
    z[6,5,6]  R2651     -2.2831052541732788e-02
    z[6,5,6]  R2652     -1.1260929703712463e-01
    z[6,5,6]  R2653     1.2358459830284119e-01
    z[6,5,6]  R2654     0.00592637388035655
    z[6,5,6]  R2655     -1.7166891694068909e-01
    z[6,5,6]  R2656     6.7347057163715363e-02
    z[6,5,6]  R2657     5.3730695508420467e-03
    z[6,5,6]  R2658     -7.0308116264641285e-03
    z[6,5,6]  R2659     -2.6035559177398682e-01
    z[6,5,6]  R2660     -5.4442346096038818e-02
    z[6,5,6]  R2661     -2.9928541183471680e-01
    z[6,5,6]  R2662     -4.4294662773609161e-02
    z[6,5,6]  R2663     3.9246085286140442e-01
    z[6,5,6]  R2664     5.1586157083511353e-01
    z[6,5,6]  R2665     6.9776542484760284e-02
    z[6,5,6]  R2666     2.9474783688783646e-02
    z[6,5,6]  R2667     -8.5204273462295532e-02
    z[6,5,6]  R2668     1.3028287887573242e-01
    z[6,5,6]  R2669     -6.7805522680282593e-01
    z[6,5,6]  R2670     -6.6481471061706543e-01
    z[6,5,6]  R2671     0.299459844827652
    z[6,5,6]  R2672     -1.1630912870168686e-01
    z[6,5,6]  R2673     -2.8347286581993103e-01
    z[6,5,6]  R2674     -4.8547599464654922e-02
    z[6,5,6]  R2675     3.9975982904434204e-01
    z[6,5,6]  R2676     -6.5692657232284546e-01
    z[6,5,6]  R2677     -6.9269323348999023e-01
    z[6,5,6]  R2678     1.5495055913925171e-01
    z[6,5,6]  R2679     4.4680300354957581e-01
    z[6,5,6]  R2680     7.6224094629287720e-01
    z[6,5,6]  R2681     -6.8241044878959656e-02
    z[6,5,6]  R2682     8.2412803173065186e-01
    z[6,5,6]  R2683     -2.3464743793010712e-01
    z[6,5,6]  R2684     -0.00269176228903234
    z[6,5,6]  R2685     -2.0108632743358612e-02
    z[6,5,6]  R2686     -9.2202380299568176e-02
    z[6,5,6]  R2687     -3.0818411707878113e-01
    z[6,5,6]  R2688     2.7658066153526306e-01
    z[6,5,6]  R2689     -3.6036711931228638e-01
    z[6,5,6]  R2690     -2.0022788643836975e-01
    z[6,5,6]  R2691     3.8570842146873474e-01
    z[6,5,6]  R2692     4.3169371783733368e-02
    z[6,5,6]  R2693     -2.3951490223407745e-01
    z[6,5,6]  R2694     2.3476506769657135e-01
    z[6,5,6]  R2695     -5.2156221866607666e-01
    z[6,5,6]  R2696     -4.1077283024787903e-01
    z[6,5,6]  R2697     -3.8127502799034119e-01
    z[6,5,6]  R2698     7.4389182031154633e-02
    z[6,5,6]  R2699     -5.8623957633972168e-01
    z[6,5,6]  R2700     -1.9564349949359894e-01
    z[6,5,6]  R2701     1.0843480378389359e-01
    z[6,5,6]  R2702     3.2398089766502380e-01
    z[6,5,6]  R2703     4.0459696203470230e-02
    z[6,5,6]  R2704     1.4328195713460445e-02
    z[6,5,6]  R2705     3.8968941569328308e-01
    z[6,5,6]  R2706     -5.0769710540771484e-01
    z[6,5,6]  R2707     -5.2033182233572006e-02
    z[6,5,6]  R2708     -2.9633262753486633e-01
    z[6,5,6]  R2709     1.1406043171882629e-01
    z[6,5,6]  R2710     1.0423842817544937e-01
    z[6,5,6]  R2711     3.0068987607955933e-01
    z[6,5,6]  R2712     2.0920639857649803e-02
    z[6,5,6]  R2713     -2.9510427266359329e-02
    z[6,5,6]  R2714     -2.2846154868602753e-01
    z[6,5,6]  R2715     7.8258194029331207e-02
    z[6,5,6]  R2716     -9.1191329061985016e-02
    z[6,5,6]  R2717     1.6566129028797150e-01
    z[6,5,6]  R2718     -4.1446119546890259e-02
    z[6,5,6]  R2719     3.5865768790245056e-01
    z[6,5,6]  R2720     2.5416895747184753e-01
    z[6,5,6]  R2721     -5.0566267222166061e-02
    z[6,5,6]  R2722     2.9101157188415527e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2723     -1
    z[6,7,0]  R2724     1
    z[6,7,0]  R2737     -2.1240970492362976e-01
    z[6,7,0]  R2738     5.6615126132965088e-01
    z[6,7,0]  R2739     -0.287582129240036
    z[6,7,0]  R2740     3.9139175415039062e-01
    z[6,7,0]  R2741     8.9847363531589508e-02
    z[6,7,0]  R2742     -1.3517257571220398e-01
    z[6,7,0]  R2743     6.2380012124776840e-02
    z[6,7,0]  R2744     -3.1546853482723236e-02
    z[6,7,0]  R2745     -3.2627135515213013e-01
    z[6,7,0]  R2746     3.7415587902069092e-01
    z[6,7,0]  R2747     -2.1480867266654968e-01
    z[6,7,0]  R2748     -2.4702057242393494e-01
    z[6,7,0]  R2749     0.0647042840719223
    z[6,7,0]  R2750     -0.0897059440612793
    z[6,7,0]  R2751     7.5556194782257080e-01
    z[6,7,0]  R2752     -6.9648653268814087e-01
    z[6,7,0]  R2753     4.2574423551559448e-01
    z[6,7,0]  R2754     -8.8941919803619385e-01
    z[6,7,0]  R2755     6.2374550104141235e-01
    z[6,7,0]  R2756     -5.0331413745880127e-01
    z[6,7,0]  R2757     2.9560112953186035e-01
    z[6,7,0]  R2758     -1.8875746428966522e-01
    z[6,7,0]  R2759     -3.9666953682899475e-01
    z[6,7,0]  R2760     -1.5260013937950134e-01
    z[6,7,0]  R2761     4.4463074207305908e-01
    z[6,7,0]  R2762     1.3967847824096680e-01
    z[6,7,0]  R2763     -5.1141440868377686e-01
    z[6,7,0]  R2764     -3.6340034008026123e-01
    z[6,7,0]  R2765     2.8061848878860474e-01
    z[6,7,0]  R2766     1.1992813646793365e-01
    z[6,7,0]  R2767     -1.1969466507434845e-01
    z[6,7,0]  R2768     0.891903281211853
    z[6,7,0]  R2769     -0.0440092533826828
    z[6,7,0]  R2770     6.9294106960296631e-01
    z[6,7,0]  R2771     6.0244774818420410e-01
    z[6,7,0]  R2772     -8.1641167402267456e-02
    z[6,7,0]  R2773     5.6040030717849731e-01
    z[6,7,0]  R2774     4.0766561031341553e-01
    z[6,7,0]  R2775     3.1279277754947543e-04
    z[6,7,0]  R2776     4.6923488378524780e-01
    z[6,7,0]  R2777     3.5147759318351746e-01
    z[6,7,0]  R2778     4.0883067995309830e-02
    z[6,7,0]  R2779     2.7442533522844315e-02
    z[6,7,0]  R2780     -2.2505679726600647e-01
    z[6,7,0]  R2781     -1.7047492787241936e-02
    z[6,7,0]  R2782     -3.7297993898391724e-01
    z[6,7,0]  R2783     -2.7726629376411438e-01
    z[6,7,0]  R2784     -3.5951441526412964e-01
    z[6,7,0]  R2785     -9.3873977661132812e-02
    z[6,7,0]  R2786     2.9853138327598572e-01
    z[6,7,0]  R2787     -4.2799907922744751e-01
    z[6,7,0]  R2788     -6.0560190677642822e-01
    z[6,7,0]  R2789     -5.3953188657760620e-01
    z[6,7,0]  R2790     -2.5984960794448853e-01
    z[6,7,0]  R2791     -6.4778298139572144e-01
    z[6,7,0]  R2792     -4.1700929403305054e-01
    z[6,7,0]  R2793     -0.385744571685791
    z[6,7,0]  R2794     -1.8221004307270050e-01
    z[6,7,0]  R2795     -4.7696086764335632e-01
    z[6,7,0]  R2796     -3.6791044473648071e-01
    z[6,7,0]  R2797     -3.4008061885833740e-01
    z[6,7,0]  R2798     -2.2818570956587791e-02
    z[6,7,0]  R2799     3.9294874668121338e-01
    z[6,7,0]  R2800     -3.0102510005235672e-02
    z[6,7,0]  R2801     -0.400037944316864
    z[6,7,0]  R2802     -5.7290811091661453e-02
    z[6,7,0]  R2803     -6.6945418715476990e-02
    z[6,7,0]  R2804     -2.1001422405242920e-01
    z[6,7,0]  R2805     -4.1027206182479858e-01
    z[6,7,0]  R2806     -2.4204806983470917e-01
    z[6,7,0]  R2807     4.5590800046920776e-01
    z[6,7,0]  R2808     6.5800681710243225e-02
    z[6,7,0]  R2809     -6.0763758420944214e-01
    z[6,7,0]  R2810     -3.2962110638618469e-01
    z[6,7,0]  R2811     1.6704581677913666e-01
    z[6,7,0]  R2812     -2.8840294480323792e-01
    z[6,7,0]  R2813     -1.5888524055480957e-01
    z[6,7,0]  R2814     1.8819020688533783e-01
    z[6,7,0]  R2815     -6.0815680772066116e-03
    z[6,7,0]  R2816     -3.5370126366615295e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2725     -1
    z[6,7,1]  R2726     1
    z[6,7,1]  R2737     -4.4346127659082413e-02
    z[6,7,1]  R2738     -9.0379834175109863e-02
    z[6,7,1]  R2739     -1.5228827297687531e-01
    z[6,7,1]  R2740     -1.0052482783794403e-01
    z[6,7,1]  R2741     -3.9079539477825165e-02
    z[6,7,1]  R2742     -1.6333429515361786e-01
    z[6,7,1]  R2743     -5.1454100757837296e-02
    z[6,7,1]  R2744     -5.8109525591135025e-02
    z[6,7,1]  R2745     9.2844374477863312e-02
    z[6,7,1]  R2746     -8.1013187766075134e-02
    z[6,7,1]  R2747     8.1758999824523926e-01
    z[6,7,1]  R2748     -2.7423635125160217e-01
    z[6,7,1]  R2749     9.2157393693923950e-01
    z[6,7,1]  R2750     9.1725713014602661e-01
    z[6,7,1]  R2751     -3.1591439247131348e-01
    z[6,7,1]  R2752     -4.2140522599220276e-01
    z[6,7,1]  R2753     -2.1396489441394806e-01
    z[6,7,1]  R2754     -0.283568799495697
    z[6,7,1]  R2755     3.6306354403495789e-01
    z[6,7,1]  R2756     -5.2217030525207520e-01
    z[6,7,1]  R2757     -7.4705088138580322e-01
    z[6,7,1]  R2758     -6.0879707336425781e-01
    z[6,7,1]  R2759     -6.1021369695663452e-01
    z[6,7,1]  R2760     -5.2069664001464844e-01
    z[6,7,1]  R2761     -5.0037395954132080e-01
    z[6,7,1]  R2762     -5.1626527309417725e-01
    z[6,7,1]  R2763     -4.8499128222465515e-01
    z[6,7,1]  R2764     -4.2986959218978882e-01
    z[6,7,1]  R2765     -4.6784445643424988e-01
    z[6,7,1]  R2766     -5.2109575271606445e-01
    z[6,7,1]  R2767     -6.4972156286239624e-01
    z[6,7,1]  R2768     1.3706804811954498e-01
    z[6,7,1]  R2769     -5.5932825803756714e-01
    z[6,7,1]  R2770     4.6786937862634659e-02
    z[6,7,1]  R2771     -2.8206637501716614e-01
    z[6,7,1]  R2772     -0.646415650844574
    z[6,7,1]  R2773     4.0782818198204041e-01
    z[6,7,1]  R2774     1.4009904861450195e-01
    z[6,7,1]  R2775     -2.5747969746589661e-01
    z[6,7,1]  R2776     2.2282439470291138e-01
    z[6,7,1]  R2777     5.3772604465484619e-01
    z[6,7,1]  R2778     7.2924906015396118e-01
    z[6,7,1]  R2779     9.2543345689773560e-01
    z[6,7,1]  R2780     6.6633814573287964e-01
    z[6,7,1]  R2781     6.6368007659912109e-01
    z[6,7,1]  R2782     0.721071183681488
    z[6,7,1]  R2783     5.9860116243362427e-01
    z[6,7,1]  R2784     4.9381405115127563e-01
    z[6,7,1]  R2785     6.9966787099838257e-01
    z[6,7,1]  R2786     7.3879170417785645e-01
    z[6,7,1]  R2787     -5.5943650007247925e-01
    z[6,7,1]  R2788     -6.1637800931930542e-01
    z[6,7,1]  R2789     -4.9711513519287109e-01
    z[6,7,1]  R2790     -6.9946968555450439e-01
    z[6,7,1]  R2791     -4.3509474396705627e-01
    z[6,7,1]  R2792     -0.527397096157074
    z[6,7,1]  R2793     -6.5380924940109253e-01
    z[6,7,1]  R2794     -3.6172983050346375e-01
    z[6,7,1]  R2795     -6.5000897645950317e-01
    z[6,7,1]  R2796     -4.8431155085563660e-01
    z[6,7,1]  R2797     -8.0435746908187866e-01
    z[6,7,1]  R2798     -8.4212523698806763e-01
    z[6,7,1]  R2799     2.9639837145805359e-01
    z[6,7,1]  R2800     -0.961946427822113
    z[6,7,1]  R2801     -7.6187348365783691e-01
    z[6,7,1]  R2802     -7.0618337392807007e-01
    z[6,7,1]  R2803     -0.890663206577301
    z[6,7,1]  R2804     -7.6029217243194580e-01
    z[6,7,1]  R2805     -8.0137866735458374e-01
    z[6,7,1]  R2806     -7.0838910341262817e-01
    z[6,7,1]  R2807     5.2064180374145508e-01
    z[6,7,1]  R2808     5.1355838775634766e-01
    z[6,7,1]  R2809     4.3847480416297913e-01
    z[6,7,1]  R2810     1.5662458539009094e-01
    z[6,7,1]  R2811     3.8802614808082581e-01
    z[6,7,1]  R2812     -8.2546448707580566e-01
    z[6,7,1]  R2813     -8.1400001049041748e-01
    z[6,7,1]  R2814     -1.3649834692478180e-01
    z[6,7,1]  R2815     -7.3540627956390381e-01
    z[6,7,1]  R2816     -7.2362780570983887e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2727     -1
    z[6,7,2]  R2728     1
    z[6,7,2]  R2737     -6.2255424261093140e-01
    z[6,7,2]  R2738     -7.4332630634307861e-01
    z[6,7,2]  R2739     -8.0464816093444824e-01
    z[6,7,2]  R2740     -6.0049152374267578e-01
    z[6,7,2]  R2741     -1.8468938767910004e-01
    z[6,7,2]  R2742     -7.3881131410598755e-01
    z[6,7,2]  R2743     -6.4745169878005981e-01
    z[6,7,2]  R2744     -8.3255708217620850e-01
    z[6,7,2]  R2745     -8.3497482538223267e-01
    z[6,7,2]  R2746     -3.6337402462959290e-01
    z[6,7,2]  R2747     3.0558711290359497e-01
    z[6,7,2]  R2748     5.8320814371109009e-01
    z[6,7,2]  R2749     2.4961875379085541e-01
    z[6,7,2]  R2750     2.9769837856292725e-01
    z[6,7,2]  R2751     2.1694932878017426e-01
    z[6,7,2]  R2752     2.8463923931121826e-01
    z[6,7,2]  R2753     2.0543260872364044e-01
    z[6,7,2]  R2754     2.0874388515949249e-01
    z[6,7,2]  R2755     0.381873220205307
    z[6,7,2]  R2756     3.4576156735420227e-01
    z[6,7,2]  R2757     1.0945479571819305e-01
    z[6,7,2]  R2758     -3.2285865396261215e-02
    z[6,7,2]  R2759     -5.2841058932244778e-03
    z[6,7,2]  R2760     2.2360880672931671e-01
    z[6,7,2]  R2761     3.1841287016868591e-01
    z[6,7,2]  R2762     -3.3113136887550354e-01
    z[6,7,2]  R2763     1.0439525544643402e-01
    z[6,7,2]  R2764     2.3203656077384949e-01
    z[6,7,2]  R2765     -1.0930939763784409e-01
    z[6,7,2]  R2766     2.4682506918907166e-01
    z[6,7,2]  R2767     -6.2499684095382690e-01
    z[6,7,2]  R2768     -2.2313027083873749e-01
    z[6,7,2]  R2769     -9.5440290868282318e-02
    z[6,7,2]  R2770     -6.9622255861759186e-02
    z[6,7,2]  R2771     -1.8771840631961823e-01
    z[6,7,2]  R2772     -2.8977859020233154e-01
    z[6,7,2]  R2773     0.0358751118183136
    z[6,7,2]  R2774     -1.8994650244712830e-01
    z[6,7,2]  R2775     -4.9565258622169495e-01
    z[6,7,2]  R2776     1.5451537072658539e-01
    z[6,7,2]  R2777     -4.1262698173522949e-01
    z[6,7,2]  R2778     0.0496567003428936
    z[6,7,2]  R2779     4.4755268841981888e-02
    z[6,7,2]  R2780     -1.4815372228622437e-01
    z[6,7,2]  R2781     4.2813235521316528e-01
    z[6,7,2]  R2782     4.5968118309974670e-01
    z[6,7,2]  R2783     4.1569215059280396e-01
    z[6,7,2]  R2784     7.5898277573287487e-03
    z[6,7,2]  R2785     4.0898427367210388e-01
    z[6,7,2]  R2786     1.3869714736938477e-01
    z[6,7,2]  R2787     -5.3591018915176392e-01
    z[6,7,2]  R2788     -2.2801041603088379e-01
    z[6,7,2]  R2789     -0.516657292842865
    z[6,7,2]  R2790     -4.0650996565818787e-01
    z[6,7,2]  R2791     -5.9381824731826782e-01
    z[6,7,2]  R2792     -2.7623388171195984e-01
    z[6,7,2]  R2793     -5.0986176729202271e-01
    z[6,7,2]  R2794     -6.9064414501190186e-01
    z[6,7,2]  R2795     -4.5217093825340271e-01
    z[6,7,2]  R2796     -0.56244957447052
    z[6,7,2]  R2797     1.9406144320964813e-01
    z[6,7,2]  R2798     2.8965404629707336e-01
    z[6,7,2]  R2799     3.4909170120954514e-02
    z[6,7,2]  R2800     6.5579958260059357e-02
    z[6,7,2]  R2801     3.9618015289306641e-01
    z[6,7,2]  R2802     -2.8757303953170776e-01
    z[6,7,2]  R2803     1.5739649534225464e-01
    z[6,7,2]  R2804     4.0723752975463867e-01
    z[6,7,2]  R2805     3.6946651339530945e-01
    z[6,7,2]  R2806     2.5820541381835938e-01
    z[6,7,2]  R2807     0.0326387919485569
    z[6,7,2]  R2808     6.7335285246372223e-02
    z[6,7,2]  R2809     2.7764764428138733e-01
    z[6,7,2]  R2810     5.3151077032089233e-01
    z[6,7,2]  R2811     -2.2476732730865479e-01
    z[6,7,2]  R2812     1.9603857398033142e-01
    z[6,7,2]  R2813     -3.0395476147532463e-02
    z[6,7,2]  R2814     1.5812179446220398e-01
    z[6,7,2]  R2815     -1.8200913071632385e-01
    z[6,7,2]  R2816     7.9307332634925842e-03
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2729     -1
    z[6,7,3]  R2730     1
    z[6,7,3]  R2737     -1.8421080708503723e-01
    z[6,7,3]  R2738     -2.9413759708404541e-02
    z[6,7,3]  R2739     1.6060025990009308e-01
    z[6,7,3]  R2740     1.5337137877941132e-01
    z[6,7,3]  R2741     3.9470937848091125e-01
    z[6,7,3]  R2742     1.2312074750661850e-01
    z[6,7,3]  R2743     -0.366982102394104
    z[6,7,3]  R2744     1.2864798307418823e-01
    z[6,7,3]  R2745     -8.5663378238677979e-02
    z[6,7,3]  R2746     -3.0126622319221497e-01
    z[6,7,3]  R2747     3.9039561152458191e-01
    z[6,7,3]  R2748     -4.7683459520339966e-01
    z[6,7,3]  R2749     -1.6152353584766388e-01
    z[6,7,3]  R2750     -2.0118415355682373e-01
    z[6,7,3]  R2751     3.3191543817520142e-01
    z[6,7,3]  R2752     4.8919060826301575e-01
    z[6,7,3]  R2753     -6.1220663785934448e-01
    z[6,7,3]  R2754     1.7509926855564117e-01
    z[6,7,3]  R2755     -4.7625014185905457e-01
    z[6,7,3]  R2756     4.8647928237915039e-01
    z[6,7,3]  R2757     -2.3330879211425781e-01
    z[6,7,3]  R2758     -6.9764018058776855e-02
    z[6,7,3]  R2759     2.6782515645027161e-01
    z[6,7,3]  R2760     -0.405845582485199
    z[6,7,3]  R2761     6.4888454973697662e-02
    z[6,7,3]  R2762     -3.8919255137443542e-01
    z[6,7,3]  R2763     1.6290649771690369e-01
    z[6,7,3]  R2764     -3.8584843277931213e-01
    z[6,7,3]  R2765     8.2914769649505615e-02
    z[6,7,3]  R2766     3.1777891516685486e-01
    z[6,7,3]  R2767     -2.1474552154541016e-01
    z[6,7,3]  R2768     1.8357586860656738e-01
    z[6,7,3]  R2769     6.8477582931518555e-01
    z[6,7,3]  R2770     1.3806837797164917e-01
    z[6,7,3]  R2771     -6.0245178639888763e-02
    z[6,7,3]  R2772     2.5885561108589172e-01
    z[6,7,3]  R2773     -4.7876462340354919e-01
    z[6,7,3]  R2774     -0.363491028547287
    z[6,7,3]  R2775     5.1065343618392944e-01
    z[6,7,3]  R2776     -3.0907431617379189e-02
    z[6,7,3]  R2777     4.5000296831130981e-01
    z[6,7,3]  R2778     6.3621246814727783e-01
    z[6,7,3]  R2779     -1.7492806538939476e-02
    z[6,7,3]  R2780     2.7972223237156868e-02
    z[6,7,3]  R2781     3.7851759791374207e-01
    z[6,7,3]  R2782     1.3253663666546345e-02
    z[6,7,3]  R2783     4.3476754426956177e-01
    z[6,7,3]  R2784     4.7934412956237793e-01
    z[6,7,3]  R2785     1.6339744627475739e-01
    z[6,7,3]  R2786     4.8957455158233643e-01
    z[6,7,3]  R2787     -1.4709731936454773e-01
    z[6,7,3]  R2788     -2.5882723927497864e-01
    z[6,7,3]  R2789     -2.1688246726989746e-01
    z[6,7,3]  R2790     -4.6647912263870239e-01
    z[6,7,3]  R2791     -8.3207428455352783e-02
    z[6,7,3]  R2792     -5.6877774000167847e-01
    z[6,7,3]  R2793     -3.0903410911560059e-01
    z[6,7,3]  R2794     -4.6563339233398438e-01
    z[6,7,3]  R2795     -3.3741500973701477e-01
    z[6,7,3]  R2796     -5.4462337493896484e-01
    z[6,7,3]  R2797     -1.7232039570808411e-01
    z[6,7,3]  R2798     -2.1759833395481110e-01
    z[6,7,3]  R2799     -6.5985542535781860e-01
    z[6,7,3]  R2800     2.0762298256158829e-02
    z[6,7,3]  R2801     -7.8155420720577240e-02
    z[6,7,3]  R2802     -0.406417578458786
    z[6,7,3]  R2803     6.5221287310123444e-02
    z[6,7,3]  R2804     0.0881512239575386
    z[6,7,3]  R2805     1.3524082303047180e-01
    z[6,7,3]  R2806     -2.6688039302825928e-01
    z[6,7,3]  R2807     0.33226278424263
    z[6,7,3]  R2808     3.9146417379379272e-01
    z[6,7,3]  R2809     -8.0085076391696930e-02
    z[6,7,3]  R2810     1.9872041046619415e-01
    z[6,7,3]  R2811     -4.8493242263793945e-01
    z[6,7,3]  R2812     -4.0307980775833130e-01
    z[6,7,3]  R2813     -4.5969793200492859e-01
    z[6,7,3]  R2814     7.2684627771377563e-01
    z[6,7,3]  R2815     -6.3669097423553467e-01
    z[6,7,3]  R2816     -0.288517564535141
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2731     -1
    z[6,7,4]  R2732     1
    z[6,7,4]  R2737     -6.3743394613265991e-01
    z[6,7,4]  R2738     -1.3657073676586151e-01
    z[6,7,4]  R2739     -2.7995908260345459e-01
    z[6,7,4]  R2740     -5.8870977163314819e-01
    z[6,7,4]  R2741     -8.1852513551712036e-01
    z[6,7,4]  R2742     8.7458200752735138e-02
    z[6,7,4]  R2743     -4.6370047330856323e-01
    z[6,7,4]  R2744     1.2290842831134796e-01
    z[6,7,4]  R2745     -6.2325045466423035e-02
    z[6,7,4]  R2746     -7.8452903032302856e-01
    z[6,7,4]  R2747     8.9119784533977509e-02
    z[6,7,4]  R2748     1.4148251712322235e-01
    z[6,7,4]  R2749     1.2777429819107056e-01
    z[6,7,4]  R2750     1.1681786179542542e-01
    z[6,7,4]  R2751     3.0304929614067078e-01
    z[6,7,4]  R2752     -6.9315090775489807e-02
    z[6,7,4]  R2753     4.2483016848564148e-01
    z[6,7,4]  R2754     1.8962581455707550e-01
    z[6,7,4]  R2755     1.5284567140042782e-02
    z[6,7,4]  R2756     2.2329214215278625e-01
    z[6,7,4]  R2757     -3.4885589033365250e-02
    z[6,7,4]  R2758     -5.6437385082244873e-01
    z[6,7,4]  R2759     -3.9155066013336182e-01
    z[6,7,4]  R2760     6.4252310991287231e-01
    z[6,7,4]  R2761     -1.9448530673980713e-01
    z[6,7,4]  R2762     -5.9565279632806778e-02
    z[6,7,4]  R2763     4.3613232672214508e-02
    z[6,7,4]  R2764     -1.6706696152687073e-01
    z[6,7,4]  R2765     1.5945152938365936e-01
    z[6,7,4]  R2766     -0.700086772441864
    z[6,7,4]  R2767     -8.6237683892250061e-02
    z[6,7,4]  R2768     2.8281274437904358e-01
    z[6,7,4]  R2769     -1.9821323454380035e-01
    z[6,7,4]  R2770     -1.6417573392391205e-01
    z[6,7,4]  R2771     1.9250491261482239e-01
    z[6,7,4]  R2772     5.5724793672561646e-01
    z[6,7,4]  R2773     2.7393159270286560e-01
    z[6,7,4]  R2774     1.7277634143829346e-01
    z[6,7,4]  R2775     0.624572217464447
    z[6,7,4]  R2776     0.0839446485042572
    z[6,7,4]  R2777     1.3001147657632828e-02
    z[6,7,4]  R2778     -8.7179347872734070e-02
    z[6,7,4]  R2779     1.6161532700061798e-01
    z[6,7,4]  R2780     2.5822514295578003e-01
    z[6,7,4]  R2781     -2.0004893839359283e-01
    z[6,7,4]  R2782     -2.4194066226482391e-01
    z[6,7,4]  R2783     2.6647615432739258e-01
    z[6,7,4]  R2784     -7.0569347590208054e-03
    z[6,7,4]  R2785     -0.457533061504364
    z[6,7,4]  R2786     2.6290962100028992e-01
    z[6,7,4]  R2787     -4.0289908647537231e-01
    z[6,7,4]  R2788     -3.5442799329757690e-01
    z[6,7,4]  R2789     -1.9329233467578888e-01
    z[6,7,4]  R2790     -2.1037788689136505e-01
    z[6,7,4]  R2791     -6.5850298851728439e-03
    z[6,7,4]  R2792     -3.7085208296775818e-01
    z[6,7,4]  R2793     6.4554825425148010e-02
    z[6,7,4]  R2794     -3.6159214377403259e-01
    z[6,7,4]  R2795     5.0317924469709396e-02
    z[6,7,4]  R2796     2.5089766830205917e-02
    z[6,7,4]  R2797     3.2245415449142456e-01
    z[6,7,4]  R2798     2.0978122949600220e-01
    z[6,7,4]  R2799     -4.8044338822364807e-01
    z[6,7,4]  R2800     -2.4499568343162537e-01
    z[6,7,4]  R2801     2.1332244575023651e-01
    z[6,7,4]  R2802     2.6873627305030823e-01
    z[6,7,4]  R2803     4.2627118527889252e-03
    z[6,7,4]  R2804     4.1220989823341370e-01
    z[6,7,4]  R2805     1.0254800319671631e-01
    z[6,7,4]  R2806     -3.0259862542152405e-01
    z[6,7,4]  R2807     4.2819178104400635e-01
    z[6,7,4]  R2808     -0.486828088760376
    z[6,7,4]  R2809     1.7520861327648163e-01
    z[6,7,4]  R2810     6.8648862838745117e-01
    z[6,7,4]  R2811     -5.6398731470108032e-01
    z[6,7,4]  R2812     2.6229554787278175e-02
    z[6,7,4]  R2813     2.8796127438545227e-01
    z[6,7,4]  R2814     3.1456348299980164e-01
    z[6,7,4]  R2815     -4.3707441538572311e-02
    z[6,7,4]  R2816     -4.1453507542610168e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2733     -1
    z[6,7,5]  R2734     1
    z[6,7,5]  R2737     2.0146530866622925e-01
    z[6,7,5]  R2738     1.3990907371044159e-01
    z[6,7,5]  R2739     3.3354374766349792e-01
    z[6,7,5]  R2740     3.0304759740829468e-01
    z[6,7,5]  R2741     3.3876052498817444e-01
    z[6,7,5]  R2742     3.4586733579635620e-01
    z[6,7,5]  R2743     2.0835934579372406e-01
    z[6,7,5]  R2744     2.6599800586700439e-01
    z[6,7,5]  R2745     4.1952362656593323e-01
    z[6,7,5]  R2746     4.9756024032831192e-02
    z[6,7,5]  R2747     -1.2804748117923737e-01
    z[6,7,5]  R2748     5.2556627988815308e-01
    z[6,7,5]  R2749     -1.1099065840244293e-01
    z[6,7,5]  R2750     -5.7539731264114380e-02
    z[6,7,5]  R2751     -2.8323435783386230e-01
    z[6,7,5]  R2752     -1.1019649356603622e-01
    z[6,7,5]  R2753     3.2817018032073975e-01
    z[6,7,5]  R2754     -1.2396162748336792e-01
    z[6,7,5]  R2755     -1.2915004789829254e-01
    z[6,7,5]  R2756     -2.5686267018318176e-01
    z[6,7,5]  R2757     -3.6452582478523254e-01
    z[6,7,5]  R2758     5.6535284966230392e-02
    z[6,7,5]  R2759     4.9025887250900269e-01
    z[6,7,5]  R2760     -2.7779844403266907e-01
    z[6,7,5]  R2761     6.3344120979309082e-01
    z[6,7,5]  R2762     6.5751016139984131e-01
    z[6,7,5]  R2763     -6.4349383115768433e-02
    z[6,7,5]  R2764     -1.0267642885446548e-01
    z[6,7,5]  R2765     7.5395655632019043e-01
    z[6,7,5]  R2766     -2.2027517855167389e-01
    z[6,7,5]  R2767     -1.9749562442302704e-01
    z[6,7,5]  R2768     1.4104568958282471e-01
    z[6,7,5]  R2769     -8.9955426752567291e-02
    z[6,7,5]  R2770     1.8768961727619171e-01
    z[6,7,5]  R2771     -4.1778244078159332e-02
    z[6,7,5]  R2772     -2.9994806647300720e-01
    z[6,7,5]  R2773     -1.2022332102060318e-01
    z[6,7,5]  R2774     -1.8738360702991486e-01
    z[6,7,5]  R2775     1.8032878637313843e-01
    z[6,7,5]  R2776     -1.3821698725223541e-01
    z[6,7,5]  R2777     -1.0507623106241226e-01
    z[6,7,5]  R2778     -1.3714969158172607e-01
    z[6,7,5]  R2779     1.7076972126960754e-01
    z[6,7,5]  R2780     -8.8459923863410950e-02
    z[6,7,5]  R2781     0.258756548166275
    z[6,7,5]  R2782     -4.9505833536386490e-02
    z[6,7,5]  R2783     4.6881463378667831e-02
    z[6,7,5]  R2784     -3.4698281437158585e-02
    z[6,7,5]  R2785     5.5712736211717129e-03
    z[6,7,5]  R2786     1.3792365789413452e-01
    z[6,7,5]  R2787     8.8033504784107208e-02
    z[6,7,5]  R2788     -9.3164615333080292e-02
    z[6,7,5]  R2789     -1.9087509810924530e-01
    z[6,7,5]  R2790     7.0396237075328827e-02
    z[6,7,5]  R2791     6.9680221378803253e-02
    z[6,7,5]  R2792     1.0128123313188553e-01
    z[6,7,5]  R2793     2.5151568651199341e-01
    z[6,7,5]  R2794     8.0217964947223663e-02
    z[6,7,5]  R2795     -1.5398536622524261e-01
    z[6,7,5]  R2796     -1.0147435218095779e-01
    z[6,7,5]  R2797     -2.5306597352027893e-01
    z[6,7,5]  R2798     1.6864615678787231e-01
    z[6,7,5]  R2799     -1.0216084867715836e-01
    z[6,7,5]  R2800     -8.7392807006835938e-02
    z[6,7,5]  R2801     2.1890738606452942e-01
    z[6,7,5]  R2802     -3.8237354159355164e-01
    z[6,7,5]  R2803     -4.0125495195388794e-01
    z[6,7,5]  R2804     1.8512722849845886e-01
    z[6,7,5]  R2805     -2.5003109127283096e-02
    z[6,7,5]  R2806     -2.5611430406570435e-01
    z[6,7,5]  R2807     -2.9676118493080139e-01
    z[6,7,5]  R2808     -5.1403272151947021e-01
    z[6,7,5]  R2809     -5.5768877267837524e-01
    z[6,7,5]  R2810     -0.166483074426651
    z[6,7,5]  R2811     -3.2608771324157715e-01
    z[6,7,5]  R2812     1.6494846343994141e-01
    z[6,7,5]  R2813     9.2028222978115082e-02
    z[6,7,5]  R2814     0.362809956073761
    z[6,7,5]  R2815     1.2219491600990295e-01
    z[6,7,5]  R2816     1.9462847709655762e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2735     -1
    z[6,7,6]  R2736     1
    z[6,7,6]  R2737     2.9068502783775330e-01
    z[6,7,6]  R2738     2.8227454423904419e-01
    z[6,7,6]  R2739     1.7670619487762451e-01
    z[6,7,6]  R2740     -1.1906898766756058e-01
    z[6,7,6]  R2741     -1.2550881505012512e-01
    z[6,7,6]  R2742     -5.1650381088256836e-01
    z[6,7,6]  R2743     -4.2562881112098694e-01
    z[6,7,6]  R2744     0.447286456823349
    z[6,7,6]  R2745     -2.2831052541732788e-02
    z[6,7,6]  R2746     -1.1260929703712463e-01
    z[6,7,6]  R2747     1.2358459830284119e-01
    z[6,7,6]  R2748     0.00592637388035655
    z[6,7,6]  R2749     -1.7166891694068909e-01
    z[6,7,6]  R2750     6.7347057163715363e-02
    z[6,7,6]  R2751     5.3730695508420467e-03
    z[6,7,6]  R2752     -7.0308116264641285e-03
    z[6,7,6]  R2753     -2.6035559177398682e-01
    z[6,7,6]  R2754     -5.4442346096038818e-02
    z[6,7,6]  R2755     -2.9928541183471680e-01
    z[6,7,6]  R2756     -4.4294662773609161e-02
    z[6,7,6]  R2757     3.9246085286140442e-01
    z[6,7,6]  R2758     5.1586157083511353e-01
    z[6,7,6]  R2759     6.9776542484760284e-02
    z[6,7,6]  R2760     2.9474783688783646e-02
    z[6,7,6]  R2761     -8.5204273462295532e-02
    z[6,7,6]  R2762     1.3028287887573242e-01
    z[6,7,6]  R2763     -6.7805522680282593e-01
    z[6,7,6]  R2764     -6.6481471061706543e-01
    z[6,7,6]  R2765     0.299459844827652
    z[6,7,6]  R2766     -1.1630912870168686e-01
    z[6,7,6]  R2767     -2.8347286581993103e-01
    z[6,7,6]  R2768     -4.8547599464654922e-02
    z[6,7,6]  R2769     3.9975982904434204e-01
    z[6,7,6]  R2770     -6.5692657232284546e-01
    z[6,7,6]  R2771     -6.9269323348999023e-01
    z[6,7,6]  R2772     1.5495055913925171e-01
    z[6,7,6]  R2773     4.4680300354957581e-01
    z[6,7,6]  R2774     7.6224094629287720e-01
    z[6,7,6]  R2775     -6.8241044878959656e-02
    z[6,7,6]  R2776     8.2412803173065186e-01
    z[6,7,6]  R2777     4.5093291997909546e-01
    z[6,7,6]  R2778     1.8133418262004852e-01
    z[6,7,6]  R2779     2.9193994402885437e-01
    z[6,7,6]  R2780     6.3883143663406372e-01
    z[6,7,6]  R2781     -3.5452902317047119e-01
    z[6,7,6]  R2782     2.6167482137680054e-01
    z[6,7,6]  R2783     3.6023595929145813e-01
    z[6,7,6]  R2784     0.629138171672821
    z[6,7,6]  R2785     3.1355720758438110e-01
    z[6,7,6]  R2786     -1.3416926562786102e-01
    z[6,7,6]  R2787     1.5790063142776489e-01
    z[6,7,6]  R2788     6.7301634699106216e-03
    z[6,7,6]  R2789     2.7205497026443481e-01
    z[6,7,6]  R2790     -1.0560656338930130e-01
    z[6,7,6]  R2791     1.6317966580390930e-01
    z[6,7,6]  R2792     -1.8791554495692253e-02
    z[6,7,6]  R2793     2.9086660593748093e-02
    z[6,7,6]  R2794     7.0451624691486359e-02
    z[6,7,6]  R2795     -7.3795504868030548e-02
    z[6,7,6]  R2796     -7.8698962926864624e-02
    z[6,7,6]  R2797     4.4508766382932663e-02
    z[6,7,6]  R2798     -2.9428917169570923e-01
    z[6,7,6]  R2799     -2.8257521986961365e-01
    z[6,7,6]  R2800     3.6888431757688522e-02
    z[6,7,6]  R2801     5.4996378719806671e-02
    z[6,7,6]  R2802     1.7810256779193878e-01
    z[6,7,6]  R2803     -1.1039060354232788e-01
    z[6,7,6]  R2804     6.9044865667819977e-03
    z[6,7,6]  R2805     1.5340237319469452e-01
    z[6,7,6]  R2806     -3.8018664717674255e-01
    z[6,7,6]  R2807     -3.7175354361534119e-01
    z[6,7,6]  R2808     -2.7003440260887146e-01
    z[6,7,6]  R2809     -1.1532482504844666e-01
    z[6,7,6]  R2810     -2.1410727500915527e-01
    z[6,7,6]  R2811     3.3382120728492737e-01
    z[6,7,6]  R2812     -8.1435024738311768e-02
    z[6,7,6]  R2813     9.2316776514053345e-02
    z[6,7,6]  R2814     4.0257081389427185e-01
    z[6,7,6]  R2815     -6.1611879616975784e-02
    z[6,7,6]  R2816     2.4131615459918976e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2817     -1
    z[7,6,0]  R2818     1
    z[7,6,0]  R2831     3.5147759318351746e-01
    z[7,6,0]  R2832     4.0883067995309830e-02
    z[7,6,0]  R2833     2.7442533522844315e-02
    z[7,6,0]  R2834     -2.2505679726600647e-01
    z[7,6,0]  R2835     -1.7047492787241936e-02
    z[7,6,0]  R2836     -3.7297993898391724e-01
    z[7,6,0]  R2837     -2.7726629376411438e-01
    z[7,6,0]  R2838     -3.5951441526412964e-01
    z[7,6,0]  R2839     -9.3873977661132812e-02
    z[7,6,0]  R2840     2.9853138327598572e-01
    z[7,6,0]  R2841     -4.2799907922744751e-01
    z[7,6,0]  R2842     -6.0560190677642822e-01
    z[7,6,0]  R2843     -5.3953188657760620e-01
    z[7,6,0]  R2844     -2.5984960794448853e-01
    z[7,6,0]  R2845     -6.4778298139572144e-01
    z[7,6,0]  R2846     -4.1700929403305054e-01
    z[7,6,0]  R2847     -0.385744571685791
    z[7,6,0]  R2848     -1.8221004307270050e-01
    z[7,6,0]  R2849     -4.7696086764335632e-01
    z[7,6,0]  R2850     -3.6791044473648071e-01
    z[7,6,0]  R2851     -3.4008061885833740e-01
    z[7,6,0]  R2852     -2.2818570956587791e-02
    z[7,6,0]  R2853     3.9294874668121338e-01
    z[7,6,0]  R2854     -3.0102510005235672e-02
    z[7,6,0]  R2855     -0.400037944316864
    z[7,6,0]  R2856     -5.7290811091661453e-02
    z[7,6,0]  R2857     -6.6945418715476990e-02
    z[7,6,0]  R2858     -2.1001422405242920e-01
    z[7,6,0]  R2859     -4.1027206182479858e-01
    z[7,6,0]  R2860     -2.4204806983470917e-01
    z[7,6,0]  R2861     4.5590800046920776e-01
    z[7,6,0]  R2862     6.5800681710243225e-02
    z[7,6,0]  R2863     -6.0763758420944214e-01
    z[7,6,0]  R2864     -3.2962110638618469e-01
    z[7,6,0]  R2865     1.6704581677913666e-01
    z[7,6,0]  R2866     -2.8840294480323792e-01
    z[7,6,0]  R2867     -1.5888524055480957e-01
    z[7,6,0]  R2868     1.8819020688533783e-01
    z[7,6,0]  R2869     -6.0815680772066116e-03
    z[7,6,0]  R2870     -3.5370126366615295e-01
    z[7,6,0]  R2871     -2.1240970492362976e-01
    z[7,6,0]  R2872     5.6615126132965088e-01
    z[7,6,0]  R2873     -0.287582129240036
    z[7,6,0]  R2874     3.9139175415039062e-01
    z[7,6,0]  R2875     8.9847363531589508e-02
    z[7,6,0]  R2876     -1.3517257571220398e-01
    z[7,6,0]  R2877     6.2380012124776840e-02
    z[7,6,0]  R2878     -3.1546853482723236e-02
    z[7,6,0]  R2879     -3.2627135515213013e-01
    z[7,6,0]  R2880     3.7415587902069092e-01
    z[7,6,0]  R2881     -2.1480867266654968e-01
    z[7,6,0]  R2882     -2.4702057242393494e-01
    z[7,6,0]  R2883     0.0647042840719223
    z[7,6,0]  R2884     -0.0897059440612793
    z[7,6,0]  R2885     7.5556194782257080e-01
    z[7,6,0]  R2886     -6.9648653268814087e-01
    z[7,6,0]  R2887     4.2574423551559448e-01
    z[7,6,0]  R2888     -8.8941919803619385e-01
    z[7,6,0]  R2889     6.2374550104141235e-01
    z[7,6,0]  R2890     -5.0331413745880127e-01
    z[7,6,0]  R2891     2.9560112953186035e-01
    z[7,6,0]  R2892     -1.8875746428966522e-01
    z[7,6,0]  R2893     -3.9666953682899475e-01
    z[7,6,0]  R2894     -1.5260013937950134e-01
    z[7,6,0]  R2895     4.4463074207305908e-01
    z[7,6,0]  R2896     1.3967847824096680e-01
    z[7,6,0]  R2897     -5.1141440868377686e-01
    z[7,6,0]  R2898     -3.6340034008026123e-01
    z[7,6,0]  R2899     2.8061848878860474e-01
    z[7,6,0]  R2900     1.1992813646793365e-01
    z[7,6,0]  R2901     -1.1969466507434845e-01
    z[7,6,0]  R2902     0.891903281211853
    z[7,6,0]  R2903     -0.0440092533826828
    z[7,6,0]  R2904     6.9294106960296631e-01
    z[7,6,0]  R2905     6.0244774818420410e-01
    z[7,6,0]  R2906     -8.1641167402267456e-02
    z[7,6,0]  R2907     5.6040030717849731e-01
    z[7,6,0]  R2908     4.0766561031341553e-01
    z[7,6,0]  R2909     3.1279277754947543e-04
    z[7,6,0]  R2910     4.6923488378524780e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2819     -1
    z[7,6,1]  R2820     1
    z[7,6,1]  R2831     5.3772604465484619e-01
    z[7,6,1]  R2832     7.2924906015396118e-01
    z[7,6,1]  R2833     9.2543345689773560e-01
    z[7,6,1]  R2834     6.6633814573287964e-01
    z[7,6,1]  R2835     6.6368007659912109e-01
    z[7,6,1]  R2836     0.721071183681488
    z[7,6,1]  R2837     5.9860116243362427e-01
    z[7,6,1]  R2838     4.9381405115127563e-01
    z[7,6,1]  R2839     6.9966787099838257e-01
    z[7,6,1]  R2840     7.3879170417785645e-01
    z[7,6,1]  R2841     -5.5943650007247925e-01
    z[7,6,1]  R2842     -6.1637800931930542e-01
    z[7,6,1]  R2843     -4.9711513519287109e-01
    z[7,6,1]  R2844     -6.9946968555450439e-01
    z[7,6,1]  R2845     -4.3509474396705627e-01
    z[7,6,1]  R2846     -0.527397096157074
    z[7,6,1]  R2847     -6.5380924940109253e-01
    z[7,6,1]  R2848     -3.6172983050346375e-01
    z[7,6,1]  R2849     -6.5000897645950317e-01
    z[7,6,1]  R2850     -4.8431155085563660e-01
    z[7,6,1]  R2851     -8.0435746908187866e-01
    z[7,6,1]  R2852     -8.4212523698806763e-01
    z[7,6,1]  R2853     2.9639837145805359e-01
    z[7,6,1]  R2854     -0.961946427822113
    z[7,6,1]  R2855     -7.6187348365783691e-01
    z[7,6,1]  R2856     -7.0618337392807007e-01
    z[7,6,1]  R2857     -0.890663206577301
    z[7,6,1]  R2858     -7.6029217243194580e-01
    z[7,6,1]  R2859     -8.0137866735458374e-01
    z[7,6,1]  R2860     -7.0838910341262817e-01
    z[7,6,1]  R2861     5.2064180374145508e-01
    z[7,6,1]  R2862     5.1355838775634766e-01
    z[7,6,1]  R2863     4.3847480416297913e-01
    z[7,6,1]  R2864     1.5662458539009094e-01
    z[7,6,1]  R2865     3.8802614808082581e-01
    z[7,6,1]  R2866     -8.2546448707580566e-01
    z[7,6,1]  R2867     -8.1400001049041748e-01
    z[7,6,1]  R2868     -1.3649834692478180e-01
    z[7,6,1]  R2869     -7.3540627956390381e-01
    z[7,6,1]  R2870     -7.2362780570983887e-01
    z[7,6,1]  R2871     -4.4346127659082413e-02
    z[7,6,1]  R2872     -9.0379834175109863e-02
    z[7,6,1]  R2873     -1.5228827297687531e-01
    z[7,6,1]  R2874     -1.0052482783794403e-01
    z[7,6,1]  R2875     -3.9079539477825165e-02
    z[7,6,1]  R2876     -1.6333429515361786e-01
    z[7,6,1]  R2877     -5.1454100757837296e-02
    z[7,6,1]  R2878     -5.8109525591135025e-02
    z[7,6,1]  R2879     9.2844374477863312e-02
    z[7,6,1]  R2880     -8.1013187766075134e-02
    z[7,6,1]  R2881     8.1758999824523926e-01
    z[7,6,1]  R2882     -2.7423635125160217e-01
    z[7,6,1]  R2883     9.2157393693923950e-01
    z[7,6,1]  R2884     9.1725713014602661e-01
    z[7,6,1]  R2885     -3.1591439247131348e-01
    z[7,6,1]  R2886     -4.2140522599220276e-01
    z[7,6,1]  R2887     -2.1396489441394806e-01
    z[7,6,1]  R2888     -0.283568799495697
    z[7,6,1]  R2889     3.6306354403495789e-01
    z[7,6,1]  R2890     -5.2217030525207520e-01
    z[7,6,1]  R2891     -7.4705088138580322e-01
    z[7,6,1]  R2892     -6.0879707336425781e-01
    z[7,6,1]  R2893     -6.1021369695663452e-01
    z[7,6,1]  R2894     -5.2069664001464844e-01
    z[7,6,1]  R2895     -5.0037395954132080e-01
    z[7,6,1]  R2896     -5.1626527309417725e-01
    z[7,6,1]  R2897     -4.8499128222465515e-01
    z[7,6,1]  R2898     -4.2986959218978882e-01
    z[7,6,1]  R2899     -4.6784445643424988e-01
    z[7,6,1]  R2900     -5.2109575271606445e-01
    z[7,6,1]  R2901     -6.4972156286239624e-01
    z[7,6,1]  R2902     1.3706804811954498e-01
    z[7,6,1]  R2903     -5.5932825803756714e-01
    z[7,6,1]  R2904     4.6786937862634659e-02
    z[7,6,1]  R2905     -2.8206637501716614e-01
    z[7,6,1]  R2906     -0.646415650844574
    z[7,6,1]  R2907     4.0782818198204041e-01
    z[7,6,1]  R2908     1.4009904861450195e-01
    z[7,6,1]  R2909     -2.5747969746589661e-01
    z[7,6,1]  R2910     2.2282439470291138e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2821     -1
    z[7,6,2]  R2822     1
    z[7,6,2]  R2831     -4.1262698173522949e-01
    z[7,6,2]  R2832     0.0496567003428936
    z[7,6,2]  R2833     4.4755268841981888e-02
    z[7,6,2]  R2834     -1.4815372228622437e-01
    z[7,6,2]  R2835     4.2813235521316528e-01
    z[7,6,2]  R2836     4.5968118309974670e-01
    z[7,6,2]  R2837     4.1569215059280396e-01
    z[7,6,2]  R2838     7.5898277573287487e-03
    z[7,6,2]  R2839     4.0898427367210388e-01
    z[7,6,2]  R2840     1.3869714736938477e-01
    z[7,6,2]  R2841     -5.3591018915176392e-01
    z[7,6,2]  R2842     -2.2801041603088379e-01
    z[7,6,2]  R2843     -0.516657292842865
    z[7,6,2]  R2844     -4.0650996565818787e-01
    z[7,6,2]  R2845     -5.9381824731826782e-01
    z[7,6,2]  R2846     -2.7623388171195984e-01
    z[7,6,2]  R2847     -5.0986176729202271e-01
    z[7,6,2]  R2848     -6.9064414501190186e-01
    z[7,6,2]  R2849     -4.5217093825340271e-01
    z[7,6,2]  R2850     -0.56244957447052
    z[7,6,2]  R2851     1.9406144320964813e-01
    z[7,6,2]  R2852     2.8965404629707336e-01
    z[7,6,2]  R2853     3.4909170120954514e-02
    z[7,6,2]  R2854     6.5579958260059357e-02
    z[7,6,2]  R2855     3.9618015289306641e-01
    z[7,6,2]  R2856     -2.8757303953170776e-01
    z[7,6,2]  R2857     1.5739649534225464e-01
    z[7,6,2]  R2858     4.0723752975463867e-01
    z[7,6,2]  R2859     3.6946651339530945e-01
    z[7,6,2]  R2860     2.5820541381835938e-01
    z[7,6,2]  R2861     0.0326387919485569
    z[7,6,2]  R2862     6.7335285246372223e-02
    z[7,6,2]  R2863     2.7764764428138733e-01
    z[7,6,2]  R2864     5.3151077032089233e-01
    z[7,6,2]  R2865     -2.2476732730865479e-01
    z[7,6,2]  R2866     1.9603857398033142e-01
    z[7,6,2]  R2867     -3.0395476147532463e-02
    z[7,6,2]  R2868     1.5812179446220398e-01
    z[7,6,2]  R2869     -1.8200913071632385e-01
    z[7,6,2]  R2870     7.9307332634925842e-03
    z[7,6,2]  R2871     -6.2255424261093140e-01
    z[7,6,2]  R2872     -7.4332630634307861e-01
    z[7,6,2]  R2873     -8.0464816093444824e-01
    z[7,6,2]  R2874     -6.0049152374267578e-01
    z[7,6,2]  R2875     -1.8468938767910004e-01
    z[7,6,2]  R2876     -7.3881131410598755e-01
    z[7,6,2]  R2877     -6.4745169878005981e-01
    z[7,6,2]  R2878     -8.3255708217620850e-01
    z[7,6,2]  R2879     -8.3497482538223267e-01
    z[7,6,2]  R2880     -3.6337402462959290e-01
    z[7,6,2]  R2881     3.0558711290359497e-01
    z[7,6,2]  R2882     5.8320814371109009e-01
    z[7,6,2]  R2883     2.4961875379085541e-01
    z[7,6,2]  R2884     2.9769837856292725e-01
    z[7,6,2]  R2885     2.1694932878017426e-01
    z[7,6,2]  R2886     2.8463923931121826e-01
    z[7,6,2]  R2887     2.0543260872364044e-01
    z[7,6,2]  R2888     2.0874388515949249e-01
    z[7,6,2]  R2889     0.381873220205307
    z[7,6,2]  R2890     3.4576156735420227e-01
    z[7,6,2]  R2891     1.0945479571819305e-01
    z[7,6,2]  R2892     -3.2285865396261215e-02
    z[7,6,2]  R2893     -5.2841058932244778e-03
    z[7,6,2]  R2894     2.2360880672931671e-01
    z[7,6,2]  R2895     3.1841287016868591e-01
    z[7,6,2]  R2896     -3.3113136887550354e-01
    z[7,6,2]  R2897     1.0439525544643402e-01
    z[7,6,2]  R2898     2.3203656077384949e-01
    z[7,6,2]  R2899     -1.0930939763784409e-01
    z[7,6,2]  R2900     2.4682506918907166e-01
    z[7,6,2]  R2901     -6.2499684095382690e-01
    z[7,6,2]  R2902     -2.2313027083873749e-01
    z[7,6,2]  R2903     -9.5440290868282318e-02
    z[7,6,2]  R2904     -6.9622255861759186e-02
    z[7,6,2]  R2905     -1.8771840631961823e-01
    z[7,6,2]  R2906     -2.8977859020233154e-01
    z[7,6,2]  R2907     0.0358751118183136
    z[7,6,2]  R2908     -1.8994650244712830e-01
    z[7,6,2]  R2909     -4.9565258622169495e-01
    z[7,6,2]  R2910     1.5451537072658539e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2823     -1
    z[7,6,3]  R2824     1
    z[7,6,3]  R2831     4.5000296831130981e-01
    z[7,6,3]  R2832     6.3621246814727783e-01
    z[7,6,3]  R2833     -1.7492806538939476e-02
    z[7,6,3]  R2834     2.7972223237156868e-02
    z[7,6,3]  R2835     3.7851759791374207e-01
    z[7,6,3]  R2836     1.3253663666546345e-02
    z[7,6,3]  R2837     4.3476754426956177e-01
    z[7,6,3]  R2838     4.7934412956237793e-01
    z[7,6,3]  R2839     1.6339744627475739e-01
    z[7,6,3]  R2840     4.8957455158233643e-01
    z[7,6,3]  R2841     -1.4709731936454773e-01
    z[7,6,3]  R2842     -2.5882723927497864e-01
    z[7,6,3]  R2843     -2.1688246726989746e-01
    z[7,6,3]  R2844     -4.6647912263870239e-01
    z[7,6,3]  R2845     -8.3207428455352783e-02
    z[7,6,3]  R2846     -5.6877774000167847e-01
    z[7,6,3]  R2847     -3.0903410911560059e-01
    z[7,6,3]  R2848     -4.6563339233398438e-01
    z[7,6,3]  R2849     -3.3741500973701477e-01
    z[7,6,3]  R2850     -5.4462337493896484e-01
    z[7,6,3]  R2851     -1.7232039570808411e-01
    z[7,6,3]  R2852     -2.1759833395481110e-01
    z[7,6,3]  R2853     -6.5985542535781860e-01
    z[7,6,3]  R2854     2.0762298256158829e-02
    z[7,6,3]  R2855     -7.8155420720577240e-02
    z[7,6,3]  R2856     -0.406417578458786
    z[7,6,3]  R2857     6.5221287310123444e-02
    z[7,6,3]  R2858     0.0881512239575386
    z[7,6,3]  R2859     1.3524082303047180e-01
    z[7,6,3]  R2860     -2.6688039302825928e-01
    z[7,6,3]  R2861     0.33226278424263
    z[7,6,3]  R2862     3.9146417379379272e-01
    z[7,6,3]  R2863     -8.0085076391696930e-02
    z[7,6,3]  R2864     1.9872041046619415e-01
    z[7,6,3]  R2865     -4.8493242263793945e-01
    z[7,6,3]  R2866     -4.0307980775833130e-01
    z[7,6,3]  R2867     -4.5969793200492859e-01
    z[7,6,3]  R2868     7.2684627771377563e-01
    z[7,6,3]  R2869     -6.3669097423553467e-01
    z[7,6,3]  R2870     -0.288517564535141
    z[7,6,3]  R2871     -1.8421080708503723e-01
    z[7,6,3]  R2872     -2.9413759708404541e-02
    z[7,6,3]  R2873     1.6060025990009308e-01
    z[7,6,3]  R2874     1.5337137877941132e-01
    z[7,6,3]  R2875     3.9470937848091125e-01
    z[7,6,3]  R2876     1.2312074750661850e-01
    z[7,6,3]  R2877     -0.366982102394104
    z[7,6,3]  R2878     1.2864798307418823e-01
    z[7,6,3]  R2879     -8.5663378238677979e-02
    z[7,6,3]  R2880     -3.0126622319221497e-01
    z[7,6,3]  R2881     3.9039561152458191e-01
    z[7,6,3]  R2882     -4.7683459520339966e-01
    z[7,6,3]  R2883     -1.6152353584766388e-01
    z[7,6,3]  R2884     -2.0118415355682373e-01
    z[7,6,3]  R2885     3.3191543817520142e-01
    z[7,6,3]  R2886     4.8919060826301575e-01
    z[7,6,3]  R2887     -6.1220663785934448e-01
    z[7,6,3]  R2888     1.7509926855564117e-01
    z[7,6,3]  R2889     -4.7625014185905457e-01
    z[7,6,3]  R2890     4.8647928237915039e-01
    z[7,6,3]  R2891     -2.3330879211425781e-01
    z[7,6,3]  R2892     -6.9764018058776855e-02
    z[7,6,3]  R2893     2.6782515645027161e-01
    z[7,6,3]  R2894     -0.405845582485199
    z[7,6,3]  R2895     6.4888454973697662e-02
    z[7,6,3]  R2896     -3.8919255137443542e-01
    z[7,6,3]  R2897     1.6290649771690369e-01
    z[7,6,3]  R2898     -3.8584843277931213e-01
    z[7,6,3]  R2899     8.2914769649505615e-02
    z[7,6,3]  R2900     3.1777891516685486e-01
    z[7,6,3]  R2901     -2.1474552154541016e-01
    z[7,6,3]  R2902     1.8357586860656738e-01
    z[7,6,3]  R2903     6.8477582931518555e-01
    z[7,6,3]  R2904     1.3806837797164917e-01
    z[7,6,3]  R2905     -6.0245178639888763e-02
    z[7,6,3]  R2906     2.5885561108589172e-01
    z[7,6,3]  R2907     -4.7876462340354919e-01
    z[7,6,3]  R2908     -0.363491028547287
    z[7,6,3]  R2909     5.1065343618392944e-01
    z[7,6,3]  R2910     -3.0907431617379189e-02
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2825     -1
    z[7,6,4]  R2826     1
    z[7,6,4]  R2831     1.3001147657632828e-02
    z[7,6,4]  R2832     -8.7179347872734070e-02
    z[7,6,4]  R2833     1.6161532700061798e-01
    z[7,6,4]  R2834     2.5822514295578003e-01
    z[7,6,4]  R2835     -2.0004893839359283e-01
    z[7,6,4]  R2836     -2.4194066226482391e-01
    z[7,6,4]  R2837     2.6647615432739258e-01
    z[7,6,4]  R2838     -7.0569347590208054e-03
    z[7,6,4]  R2839     -0.457533061504364
    z[7,6,4]  R2840     2.6290962100028992e-01
    z[7,6,4]  R2841     -4.0289908647537231e-01
    z[7,6,4]  R2842     -3.5442799329757690e-01
    z[7,6,4]  R2843     -1.9329233467578888e-01
    z[7,6,4]  R2844     -2.1037788689136505e-01
    z[7,6,4]  R2845     -6.5850298851728439e-03
    z[7,6,4]  R2846     -3.7085208296775818e-01
    z[7,6,4]  R2847     6.4554825425148010e-02
    z[7,6,4]  R2848     -3.6159214377403259e-01
    z[7,6,4]  R2849     5.0317924469709396e-02
    z[7,6,4]  R2850     2.5089766830205917e-02
    z[7,6,4]  R2851     3.2245415449142456e-01
    z[7,6,4]  R2852     2.0978122949600220e-01
    z[7,6,4]  R2853     -4.8044338822364807e-01
    z[7,6,4]  R2854     -2.4499568343162537e-01
    z[7,6,4]  R2855     2.1332244575023651e-01
    z[7,6,4]  R2856     2.6873627305030823e-01
    z[7,6,4]  R2857     4.2627118527889252e-03
    z[7,6,4]  R2858     4.1220989823341370e-01
    z[7,6,4]  R2859     1.0254800319671631e-01
    z[7,6,4]  R2860     -3.0259862542152405e-01
    z[7,6,4]  R2861     4.2819178104400635e-01
    z[7,6,4]  R2862     -0.486828088760376
    z[7,6,4]  R2863     1.7520861327648163e-01
    z[7,6,4]  R2864     6.8648862838745117e-01
    z[7,6,4]  R2865     -5.6398731470108032e-01
    z[7,6,4]  R2866     2.6229554787278175e-02
    z[7,6,4]  R2867     2.8796127438545227e-01
    z[7,6,4]  R2868     3.1456348299980164e-01
    z[7,6,4]  R2869     -4.3707441538572311e-02
    z[7,6,4]  R2870     -4.1453507542610168e-01
    z[7,6,4]  R2871     -6.3743394613265991e-01
    z[7,6,4]  R2872     -1.3657073676586151e-01
    z[7,6,4]  R2873     -2.7995908260345459e-01
    z[7,6,4]  R2874     -5.8870977163314819e-01
    z[7,6,4]  R2875     -8.1852513551712036e-01
    z[7,6,4]  R2876     8.7458200752735138e-02
    z[7,6,4]  R2877     -4.6370047330856323e-01
    z[7,6,4]  R2878     1.2290842831134796e-01
    z[7,6,4]  R2879     -6.2325045466423035e-02
    z[7,6,4]  R2880     -7.8452903032302856e-01
    z[7,6,4]  R2881     8.9119784533977509e-02
    z[7,6,4]  R2882     1.4148251712322235e-01
    z[7,6,4]  R2883     1.2777429819107056e-01
    z[7,6,4]  R2884     1.1681786179542542e-01
    z[7,6,4]  R2885     3.0304929614067078e-01
    z[7,6,4]  R2886     -6.9315090775489807e-02
    z[7,6,4]  R2887     4.2483016848564148e-01
    z[7,6,4]  R2888     1.8962581455707550e-01
    z[7,6,4]  R2889     1.5284567140042782e-02
    z[7,6,4]  R2890     2.2329214215278625e-01
    z[7,6,4]  R2891     -3.4885589033365250e-02
    z[7,6,4]  R2892     -5.6437385082244873e-01
    z[7,6,4]  R2893     -3.9155066013336182e-01
    z[7,6,4]  R2894     6.4252310991287231e-01
    z[7,6,4]  R2895     -1.9448530673980713e-01
    z[7,6,4]  R2896     -5.9565279632806778e-02
    z[7,6,4]  R2897     4.3613232672214508e-02
    z[7,6,4]  R2898     -1.6706696152687073e-01
    z[7,6,4]  R2899     1.5945152938365936e-01
    z[7,6,4]  R2900     -0.700086772441864
    z[7,6,4]  R2901     -8.6237683892250061e-02
    z[7,6,4]  R2902     2.8281274437904358e-01
    z[7,6,4]  R2903     -1.9821323454380035e-01
    z[7,6,4]  R2904     -1.6417573392391205e-01
    z[7,6,4]  R2905     1.9250491261482239e-01
    z[7,6,4]  R2906     5.5724793672561646e-01
    z[7,6,4]  R2907     2.7393159270286560e-01
    z[7,6,4]  R2908     1.7277634143829346e-01
    z[7,6,4]  R2909     0.624572217464447
    z[7,6,4]  R2910     0.0839446485042572
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2827     -1
    z[7,6,5]  R2828     1
    z[7,6,5]  R2831     -1.0507623106241226e-01
    z[7,6,5]  R2832     -1.3714969158172607e-01
    z[7,6,5]  R2833     1.7076972126960754e-01
    z[7,6,5]  R2834     -8.8459923863410950e-02
    z[7,6,5]  R2835     0.258756548166275
    z[7,6,5]  R2836     -4.9505833536386490e-02
    z[7,6,5]  R2837     4.6881463378667831e-02
    z[7,6,5]  R2838     -3.4698281437158585e-02
    z[7,6,5]  R2839     5.5712736211717129e-03
    z[7,6,5]  R2840     1.3792365789413452e-01
    z[7,6,5]  R2841     8.8033504784107208e-02
    z[7,6,5]  R2842     -9.3164615333080292e-02
    z[7,6,5]  R2843     -1.9087509810924530e-01
    z[7,6,5]  R2844     7.0396237075328827e-02
    z[7,6,5]  R2845     6.9680221378803253e-02
    z[7,6,5]  R2846     1.0128123313188553e-01
    z[7,6,5]  R2847     2.5151568651199341e-01
    z[7,6,5]  R2848     8.0217964947223663e-02
    z[7,6,5]  R2849     -1.5398536622524261e-01
    z[7,6,5]  R2850     -1.0147435218095779e-01
    z[7,6,5]  R2851     -2.5306597352027893e-01
    z[7,6,5]  R2852     1.6864615678787231e-01
    z[7,6,5]  R2853     -1.0216084867715836e-01
    z[7,6,5]  R2854     -8.7392807006835938e-02
    z[7,6,5]  R2855     2.1890738606452942e-01
    z[7,6,5]  R2856     -3.8237354159355164e-01
    z[7,6,5]  R2857     -4.0125495195388794e-01
    z[7,6,5]  R2858     1.8512722849845886e-01
    z[7,6,5]  R2859     -2.5003109127283096e-02
    z[7,6,5]  R2860     -2.5611430406570435e-01
    z[7,6,5]  R2861     -2.9676118493080139e-01
    z[7,6,5]  R2862     -5.1403272151947021e-01
    z[7,6,5]  R2863     -5.5768877267837524e-01
    z[7,6,5]  R2864     -0.166483074426651
    z[7,6,5]  R2865     -3.2608771324157715e-01
    z[7,6,5]  R2866     1.6494846343994141e-01
    z[7,6,5]  R2867     9.2028222978115082e-02
    z[7,6,5]  R2868     0.362809956073761
    z[7,6,5]  R2869     1.2219491600990295e-01
    z[7,6,5]  R2870     1.9462847709655762e-01
    z[7,6,5]  R2871     2.0146530866622925e-01
    z[7,6,5]  R2872     1.3990907371044159e-01
    z[7,6,5]  R2873     3.3354374766349792e-01
    z[7,6,5]  R2874     3.0304759740829468e-01
    z[7,6,5]  R2875     3.3876052498817444e-01
    z[7,6,5]  R2876     3.4586733579635620e-01
    z[7,6,5]  R2877     2.0835934579372406e-01
    z[7,6,5]  R2878     2.6599800586700439e-01
    z[7,6,5]  R2879     4.1952362656593323e-01
    z[7,6,5]  R2880     4.9756024032831192e-02
    z[7,6,5]  R2881     -1.2804748117923737e-01
    z[7,6,5]  R2882     5.2556627988815308e-01
    z[7,6,5]  R2883     -1.1099065840244293e-01
    z[7,6,5]  R2884     -5.7539731264114380e-02
    z[7,6,5]  R2885     -2.8323435783386230e-01
    z[7,6,5]  R2886     -1.1019649356603622e-01
    z[7,6,5]  R2887     3.2817018032073975e-01
    z[7,6,5]  R2888     -1.2396162748336792e-01
    z[7,6,5]  R2889     -1.2915004789829254e-01
    z[7,6,5]  R2890     -2.5686267018318176e-01
    z[7,6,5]  R2891     -3.6452582478523254e-01
    z[7,6,5]  R2892     5.6535284966230392e-02
    z[7,6,5]  R2893     4.9025887250900269e-01
    z[7,6,5]  R2894     -2.7779844403266907e-01
    z[7,6,5]  R2895     6.3344120979309082e-01
    z[7,6,5]  R2896     6.5751016139984131e-01
    z[7,6,5]  R2897     -6.4349383115768433e-02
    z[7,6,5]  R2898     -1.0267642885446548e-01
    z[7,6,5]  R2899     7.5395655632019043e-01
    z[7,6,5]  R2900     -2.2027517855167389e-01
    z[7,6,5]  R2901     -1.9749562442302704e-01
    z[7,6,5]  R2902     1.4104568958282471e-01
    z[7,6,5]  R2903     -8.9955426752567291e-02
    z[7,6,5]  R2904     1.8768961727619171e-01
    z[7,6,5]  R2905     -4.1778244078159332e-02
    z[7,6,5]  R2906     -2.9994806647300720e-01
    z[7,6,5]  R2907     -1.2022332102060318e-01
    z[7,6,5]  R2908     -1.8738360702991486e-01
    z[7,6,5]  R2909     1.8032878637313843e-01
    z[7,6,5]  R2910     -1.3821698725223541e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2829     -1
    z[7,6,6]  R2830     1
    z[7,6,6]  R2831     4.5093291997909546e-01
    z[7,6,6]  R2832     1.8133418262004852e-01
    z[7,6,6]  R2833     2.9193994402885437e-01
    z[7,6,6]  R2834     6.3883143663406372e-01
    z[7,6,6]  R2835     -3.5452902317047119e-01
    z[7,6,6]  R2836     2.6167482137680054e-01
    z[7,6,6]  R2837     3.6023595929145813e-01
    z[7,6,6]  R2838     0.629138171672821
    z[7,6,6]  R2839     3.1355720758438110e-01
    z[7,6,6]  R2840     -1.3416926562786102e-01
    z[7,6,6]  R2841     1.5790063142776489e-01
    z[7,6,6]  R2842     6.7301634699106216e-03
    z[7,6,6]  R2843     2.7205497026443481e-01
    z[7,6,6]  R2844     -1.0560656338930130e-01
    z[7,6,6]  R2845     1.6317966580390930e-01
    z[7,6,6]  R2846     -1.8791554495692253e-02
    z[7,6,6]  R2847     2.9086660593748093e-02
    z[7,6,6]  R2848     7.0451624691486359e-02
    z[7,6,6]  R2849     -7.3795504868030548e-02
    z[7,6,6]  R2850     -7.8698962926864624e-02
    z[7,6,6]  R2851     4.4508766382932663e-02
    z[7,6,6]  R2852     -2.9428917169570923e-01
    z[7,6,6]  R2853     -2.8257521986961365e-01
    z[7,6,6]  R2854     3.6888431757688522e-02
    z[7,6,6]  R2855     5.4996378719806671e-02
    z[7,6,6]  R2856     1.7810256779193878e-01
    z[7,6,6]  R2857     -1.1039060354232788e-01
    z[7,6,6]  R2858     6.9044865667819977e-03
    z[7,6,6]  R2859     1.5340237319469452e-01
    z[7,6,6]  R2860     -3.8018664717674255e-01
    z[7,6,6]  R2861     -3.7175354361534119e-01
    z[7,6,6]  R2862     -2.7003440260887146e-01
    z[7,6,6]  R2863     -1.1532482504844666e-01
    z[7,6,6]  R2864     -2.1410727500915527e-01
    z[7,6,6]  R2865     3.3382120728492737e-01
    z[7,6,6]  R2866     -8.1435024738311768e-02
    z[7,6,6]  R2867     9.2316776514053345e-02
    z[7,6,6]  R2868     4.0257081389427185e-01
    z[7,6,6]  R2869     -6.1611879616975784e-02
    z[7,6,6]  R2870     2.4131615459918976e-01
    z[7,6,6]  R2871     2.9068502783775330e-01
    z[7,6,6]  R2872     2.8227454423904419e-01
    z[7,6,6]  R2873     1.7670619487762451e-01
    z[7,6,6]  R2874     -1.1906898766756058e-01
    z[7,6,6]  R2875     -1.2550881505012512e-01
    z[7,6,6]  R2876     -5.1650381088256836e-01
    z[7,6,6]  R2877     -4.2562881112098694e-01
    z[7,6,6]  R2878     0.447286456823349
    z[7,6,6]  R2879     -2.2831052541732788e-02
    z[7,6,6]  R2880     -1.1260929703712463e-01
    z[7,6,6]  R2881     1.2358459830284119e-01
    z[7,6,6]  R2882     0.00592637388035655
    z[7,6,6]  R2883     -1.7166891694068909e-01
    z[7,6,6]  R2884     6.7347057163715363e-02
    z[7,6,6]  R2885     5.3730695508420467e-03
    z[7,6,6]  R2886     -7.0308116264641285e-03
    z[7,6,6]  R2887     -2.6035559177398682e-01
    z[7,6,6]  R2888     -5.4442346096038818e-02
    z[7,6,6]  R2889     -2.9928541183471680e-01
    z[7,6,6]  R2890     -4.4294662773609161e-02
    z[7,6,6]  R2891     3.9246085286140442e-01
    z[7,6,6]  R2892     5.1586157083511353e-01
    z[7,6,6]  R2893     6.9776542484760284e-02
    z[7,6,6]  R2894     2.9474783688783646e-02
    z[7,6,6]  R2895     -8.5204273462295532e-02
    z[7,6,6]  R2896     1.3028287887573242e-01
    z[7,6,6]  R2897     -6.7805522680282593e-01
    z[7,6,6]  R2898     -6.6481471061706543e-01
    z[7,6,6]  R2899     0.299459844827652
    z[7,6,6]  R2900     -1.1630912870168686e-01
    z[7,6,6]  R2901     -2.8347286581993103e-01
    z[7,6,6]  R2902     -4.8547599464654922e-02
    z[7,6,6]  R2903     3.9975982904434204e-01
    z[7,6,6]  R2904     -6.5692657232284546e-01
    z[7,6,6]  R2905     -6.9269323348999023e-01
    z[7,6,6]  R2906     1.5495055913925171e-01
    z[7,6,6]  R2907     4.4680300354957581e-01
    z[7,6,6]  R2908     7.6224094629287720e-01
    z[7,6,6]  R2909     -6.8241044878959656e-02
    z[7,6,6]  R2910     8.2412803173065186e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[1,6]
 BV BND1      phi[6,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[2,7]
 BV BND1      phi[7,2]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[4,7]
 BV BND1      phi[7,4]
 BV BND1      phi[4,9]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[1,6,0]
 FR BND1      z[1,6,1]
 FR BND1      z[1,6,2]
 FR BND1      z[1,6,3]
 FR BND1      z[1,6,4]
 FR BND1      z[1,6,5]
 FR BND1      z[1,6,6]
 FR BND1      z[6,1,0]
 FR BND1      z[6,1,1]
 FR BND1      z[6,1,2]
 FR BND1      z[6,1,3]
 FR BND1      z[6,1,4]
 FR BND1      z[6,1,5]
 FR BND1      z[6,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[2,7,0]
 FR BND1      z[2,7,1]
 FR BND1      z[2,7,2]
 FR BND1      z[2,7,3]
 FR BND1      z[2,7,4]
 FR BND1      z[2,7,5]
 FR BND1      z[2,7,6]
 FR BND1      z[7,2,0]
 FR BND1      z[7,2,1]
 FR BND1      z[7,2,2]
 FR BND1      z[7,2,3]
 FR BND1      z[7,2,4]
 FR BND1      z[7,2,5]
 FR BND1      z[7,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,7,0]
 FR BND1      z[4,7,1]
 FR BND1      z[4,7,2]
 FR BND1      z[4,7,3]
 FR BND1      z[4,7,4]
 FR BND1      z[4,7,5]
 FR BND1      z[4,7,6]
 FR BND1      z[7,4,0]
 FR BND1      z[7,4,1]
 FR BND1      z[7,4,2]
 FR BND1      z[7,4,3]
 FR BND1      z[7,4,4]
 FR BND1      z[7,4,5]
 FR BND1      z[7,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
