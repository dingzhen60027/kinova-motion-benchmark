NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  R2796   
 L  R2797   
 L  R2798   
 L  R2799   
 L  R2800   
 L  R2801   
 L  R2802   
 L  R2803   
 L  R2804   
 L  R2805   
 L  R2806   
 L  R2807   
 L  R2808   
 L  R2809   
 L  R2810   
 L  R2811   
 L  R2812   
 L  R2813   
 L  R2814   
 L  R2815   
 L  R2816   
 L  R2817   
 L  R2818   
 L  R2819   
 L  R2820   
 L  R2821   
 L  R2822   
 L  R2823   
 L  R2824   
 L  R2825   
 L  R2826   
 L  R2827   
 L  R2828   
 L  R2829   
 L  R2830   
 L  R2831   
 L  R2832   
 L  R2833   
 L  R2834   
 L  R2835   
 L  R2836   
 L  R2837   
 L  R2838   
 L  R2839   
 L  R2840   
 L  R2841   
 L  R2842   
 L  R2843   
 L  R2844   
 L  R2845   
 L  R2846   
 L  R2847   
 L  R2848   
 L  R2849   
 L  R2850   
 L  R2851   
 L  R2852   
 L  R2853   
 L  R2854   
 L  R2855   
 L  R2856   
 L  R2857   
 L  R2858   
 L  R2859   
 L  R2860   
 L  R2861   
 L  R2862   
 L  R2863   
 L  R2864   
 L  R2865   
 L  R2866   
 L  R2867   
 L  R2868   
 L  R2869   
 L  R2870   
 L  R2871   
 L  R2872   
 L  R2873   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       3.6565604805946350e-01
    phi[0,1]  R89       1.9332622289657593e+00
    phi[0,1]  R90       0.784713864326477
    phi[0,1]  R91       2.7247107028961182e+00
    phi[0,1]  R92       1.5234142541885376e+00
    phi[0,1]  R93       0.533897340297699
    phi[0,1]  R94       2.1584606170654297e+00
    phi[0,1]  R95       -7.5138753652572632e-01
    phi[0,1]  R96       1.9573984146118164e+00
    phi[0,1]  R97       -1.2342028617858887e+00
    phi[0,1]  R98       -2.80871319770813
    phi[0,1]  R99       -2.1054463386535645e+00
    phi[0,1]  R100      -1.8104027509689331e+00
    phi[0,1]  R101      -1.6505955457687378e+00
    phi[0,1]  R102      -2.1557338237762451e+00
    phi[0,1]  R103      -1.3589400053024292e+00
    phi[0,1]  R104      -6.7530733346939087e-01
    phi[0,1]  R105      2.5282242894172668e-01
    phi[0,1]  R106      -7.5058871507644653e-01
    phi[0,1]  R107      -5.7320779561996460e-01
    phi[0,1]  R108      -7.9436165094375610e-01
    phi[0,1]  R109      -4.0606668591499329e-01
    phi[0,1]  R110      -1.9706475734710693e+00
    phi[0,1]  R111      -8.1208193302154541e-01
    phi[0,1]  R112      -1.8418477773666382e+00
    phi[0,1]  R113      1.8309482336044312e+00
    phi[0,1]  R114      -2.1911011636257172e-01
    phi[0,1]  R115      7.2433924674987793e-01
    phi[0,1]  R116      -4.5891442894935608e-01
    phi[0,1]  R117      1.5939671993255615e+00
    phi[0,1]  R118      -1.2307243794202805e-01
    phi[0,1]  R119      -1.3281011581420898e+00
    phi[0,1]  R120      3.0297225713729858e-01
    phi[0,1]  R121      1.0238726139068604e+00
    phi[0,1]  R122      1.3548754453659058e+00
    phi[0,1]  R123      1.0993119478225708e+00
    phi[0,1]  R124      1.4702049493789673e+00
    phi[0,1]  R125      2.7420988678932190e-01
    phi[0,1]  R126      1.1812584847211838e-01
    phi[0,1]  R127      -3.0493801832199097e-01
    phi[0,1]  R128      -2.9540972709655762e+00
    phi[0,1]  R129      -2.1569049358367920e+00
    phi[0,1]  R130      8.7015762925148010e-02
    phi[0,1]  R131      -1.8190245330333710e-01
    phi[0,1]  R132      -2.2479051724076271e-02
    phi[0,1]  R133      8.8917158544063568e-02
    phi[0,1]  R134      -0.763283371925354
    phi[0,1]  R135      0.5245361328125
    phi[0,1]  R136      -1.5604711771011353e+00
    phi[0,1]  R137      5.8831655979156494e-01
    phi[0,1]  R138      7.7987539768218994e-01
    phi[0,1]  R139      -0.664688229560852
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R140      -3.0999999046325684e+00
    phi[1,0]  R141      -3.0999999046325684e+00
    phi[1,0]  R142      -2.2400000095367432e+00
    phi[1,0]  R143      -2.2400000095367432e+00
    phi[1,0]  R144      -3.0999999046325684e+00
    phi[1,0]  R145      -3.0999999046325684e+00
    phi[1,0]  R146      -2.5699999332427979e+00
    phi[1,0]  R147      -2.5699999332427979e+00
    phi[1,0]  R148      -3.0999999046325684e+00
    phi[1,0]  R149      -3.0999999046325684e+00
    phi[1,0]  R150      -2.0899999141693115e+00
    phi[1,0]  R151      -2.0899999141693115e+00
    phi[1,0]  R152      -3.0999999046325684e+00
    phi[1,0]  R153      -3.0999999046325684e+00
    phi[1,0]  R154      -1.2307243794202805e-01
    phi[1,0]  R155      -1.3281011581420898e+00
    phi[1,0]  R156      3.0297225713729858e-01
    phi[1,0]  R157      1.0238726139068604e+00
    phi[1,0]  R158      1.3548754453659058e+00
    phi[1,0]  R159      1.0993119478225708e+00
    phi[1,0]  R160      1.4702049493789673e+00
    phi[1,0]  R161      2.7420988678932190e-01
    phi[1,0]  R162      1.1812584847211838e-01
    phi[1,0]  R163      -3.0493801832199097e-01
    phi[1,0]  R164      -2.9540972709655762e+00
    phi[1,0]  R165      -2.1569049358367920e+00
    phi[1,0]  R166      8.7015762925148010e-02
    phi[1,0]  R167      -1.8190245330333710e-01
    phi[1,0]  R168      -2.2479051724076271e-02
    phi[1,0]  R169      8.8917158544063568e-02
    phi[1,0]  R170      -0.763283371925354
    phi[1,0]  R171      0.5245361328125
    phi[1,0]  R172      -1.5604711771011353e+00
    phi[1,0]  R173      5.8831655979156494e-01
    phi[1,0]  R174      7.7987539768218994e-01
    phi[1,0]  R175      -0.664688229560852
    phi[1,0]  R176      3.6565604805946350e-01
    phi[1,0]  R177      1.9332622289657593e+00
    phi[1,0]  R178      0.784713864326477
    phi[1,0]  R179      2.7247107028961182e+00
    phi[1,0]  R180      1.5234142541885376e+00
    phi[1,0]  R181      0.533897340297699
    phi[1,0]  R182      2.1584606170654297e+00
    phi[1,0]  R183      -7.5138753652572632e-01
    phi[1,0]  R184      1.9573984146118164e+00
    phi[1,0]  R185      -1.2342028617858887e+00
    phi[1,0]  R186      -2.80871319770813
    phi[1,0]  R187      -2.1054463386535645e+00
    phi[1,0]  R188      -1.8104027509689331e+00
    phi[1,0]  R189      -1.6505955457687378e+00
    phi[1,0]  R190      -2.1557338237762451e+00
    phi[1,0]  R191      -1.3589400053024292e+00
    phi[1,0]  R192      -6.7530733346939087e-01
    phi[1,0]  R193      2.5282242894172668e-01
    phi[1,0]  R194      -7.5058871507644653e-01
    phi[1,0]  R195      -5.7320779561996460e-01
    phi[1,0]  R196      -7.9436165094375610e-01
    phi[1,0]  R197      -4.0606668591499329e-01
    phi[1,0]  R198      -1.9706475734710693e+00
    phi[1,0]  R199      -8.1208193302154541e-01
    phi[1,0]  R200      -1.8418477773666382e+00
    phi[1,0]  R201      1.8309482336044312e+00
    phi[1,0]  R202      -2.1911011636257172e-01
    phi[1,0]  R203      7.2433924674987793e-01
    phi[1,0]  R204      -4.5891442894935608e-01
    phi[1,0]  R205      1.5939671993255615e+00
    phi[0,3]  R0        1
    phi[0,3]  R1        1
    phi[0,3]  R27       -1
    phi[0,3]  R206      -3.0999999046325684e+00
    phi[0,3]  R207      -3.0999999046325684e+00
    phi[0,3]  R208      -2.2400000095367432e+00
    phi[0,3]  R209      -2.2400000095367432e+00
    phi[0,3]  R210      -3.0999999046325684e+00
    phi[0,3]  R211      -3.0999999046325684e+00
    phi[0,3]  R212      -2.5699999332427979e+00
    phi[0,3]  R213      -2.5699999332427979e+00
    phi[0,3]  R214      -3.0999999046325684e+00
    phi[0,3]  R215      -3.0999999046325684e+00
    phi[0,3]  R216      -2.0899999141693115e+00
    phi[0,3]  R217      -2.0899999141693115e+00
    phi[0,3]  R218      -3.0999999046325684e+00
    phi[0,3]  R219      -3.0999999046325684e+00
    phi[0,3]  R220      3.6565604805946350e-01
    phi[0,3]  R221      1.9332622289657593e+00
    phi[0,3]  R222      0.784713864326477
    phi[0,3]  R223      2.7247107028961182e+00
    phi[0,3]  R224      1.5234142541885376e+00
    phi[0,3]  R225      0.533897340297699
    phi[0,3]  R226      2.1584606170654297e+00
    phi[0,3]  R227      -7.5138753652572632e-01
    phi[0,3]  R228      1.9573984146118164e+00
    phi[0,3]  R229      -1.2342028617858887e+00
    phi[0,3]  R230      -2.80871319770813
    phi[0,3]  R231      -2.1054463386535645e+00
    phi[0,3]  R232      -1.8104027509689331e+00
    phi[0,3]  R233      -1.6505955457687378e+00
    phi[0,3]  R234      -2.1557338237762451e+00
    phi[0,3]  R235      -1.3589400053024292e+00
    phi[0,3]  R236      -6.7530733346939087e-01
    phi[0,3]  R237      2.5282242894172668e-01
    phi[0,3]  R238      -7.5058871507644653e-01
    phi[0,3]  R239      -5.7320779561996460e-01
    phi[0,3]  R240      -7.9436165094375610e-01
    phi[0,3]  R241      -4.0606668591499329e-01
    phi[0,3]  R242      -1.9706475734710693e+00
    phi[0,3]  R243      -8.1208193302154541e-01
    phi[0,3]  R244      -1.8418477773666382e+00
    phi[0,3]  R245      1.8309482336044312e+00
    phi[0,3]  R246      -2.1911011636257172e-01
    phi[0,3]  R247      7.2433924674987793e-01
    phi[0,3]  R248      -4.5891442894935608e-01
    phi[0,3]  R249      1.5939671993255615e+00
    phi[0,3]  R250      5.9527075290679932e-01
    phi[0,3]  R251      -1.2242138385772705e+00
    phi[0,3]  R252      -5.2230614423751831e-01
    phi[0,3]  R253      2.5616529583930969e-01
    phi[0,3]  R254      -1.1316685676574707e+00
    phi[0,3]  R255      -1.3367012143135071e-03
    phi[0,3]  R256      -3.0023804306983948e-01
    phi[0,3]  R257      -5.2288264036178589e-01
    phi[0,3]  R258      0.738461434841156
    phi[0,3]  R259      0.313499391078949
    phi[0,3]  R260      4.6208846569061279e-01
    phi[0,3]  R261      7.1242183446884155e-01
    phi[0,3]  R262      0.861029863357544
    phi[0,3]  R263      1.7670917510986328e-01
    phi[0,3]  R264      4.3525347113609314e-01
    phi[0,3]  R265      5.8949780464172363e-01
    phi[0,3]  R266      5.3670644760131836e-01
    phi[0,3]  R267      -1.4095088839530945e-01
    phi[0,3]  R268      -1.4175664633512497e-02
    phi[0,3]  R269      -8.9108355343341827e-02
    phi[0,3]  R270      -1.7962698936462402e+00
    phi[0,3]  R271      -1.2218828201293945e+00
    phi[0,3]  R272      -1.3819094896316528e+00
    phi[0,3]  R273      -2.1596841812133789e+00
    phi[0,3]  R274      -1.9297324419021606e+00
    phi[0,3]  R275      -2.2597465515136719e+00
    phi[0,3]  R276      -2.6438345909118652e+00
    phi[0,3]  R277      -1.72129225730896
    phi[0,3]  R278      -1.1417835950851440e+00
    phi[0,3]  R279      -2.7227144241333008e+00
    phi[0,3]  R280      -1.3136377334594727e+00
    phi[0,3]  R281      -2.1711030602455139e-01
    phi[0,3]  R282      -1.2693651020526886e-01
    phi[0,3]  R283      -3.5147583484649658e-01
    phi[0,3]  R284      -2.8442423343658447e+00
    phi[0,3]  R285      -1.9939849376678467e+00
    phi[0,3]  R286      -1.2495437860488892e+00
    phi[0,3]  R287      -6.8911772966384888e-01
    phi[0,3]  R288      -1.6764041185379028e+00
    phi[0,3]  R289      -1.6778661012649536e+00
    phi[0,3]  R290      -2.9824137687683105e-01
    phi[0,3]  R291      -8.8157355785369873e-01
    phi[0,3]  R292      -1.1656290292739868e+00
    phi[0,3]  R293      9.0937864780426025e-01
    phi[0,3]  R294      -0.851057767868042
    phi[0,3]  R295      4.7243535518646240e-02
    phi[0,3]  R296      5.9957861900329590e-02
    phi[0,3]  R297      -3.2177748680114746e+00
    phi[0,3]  R298      -5.5479711294174194e-01
    phi[0,3]  R299      -4.5398325920104980e+00
    phi[0,3]  R300      -1.4329981803894043e+00
    phi[0,3]  R301      -1.5248183012008667e+00
    phi[0,3]  R302      2.9120454192161560e-01
    phi[0,3]  R303      -8.6056822538375854e-01
    phi[0,3]  R304      -2.1684589385986328e+00
    phi[0,3]  R305      -2.7242195606231689e+00
    phi[0,3]  R306      -3.2590880393981934e+00
    phi[0,3]  R307      -2.2550034523010254e+00
    phi[0,3]  R308      -3.5106179714202881e+00
    phi[0,3]  R309      -3.5556530952453613e+00
    phi[0,3]  R310      -7.4543547630310059e-01
    phi[0,3]  R311      -2.6229693889617920e+00
    phi[0,3]  R312      -0.424740731716156
    phi[0,3]  R313      -2.9630592465400696e-01
    phi[0,3]  R314      -1.2757879495620728e+00
    phi[0,3]  R315      -1.5019226074218750e+00
    phi[0,3]  R316      -1.7658958435058594e+00
    phi[0,3]  R317      -1.3697912693023682e+00
    phi[0,3]  R318      -1.4962083101272583e+00
    phi[0,3]  R319      -1.9053051471710205e+00
    phi[3,0]  R0        -1
    phi[3,0]  R27       1
    phi[3,0]  R28       1
    phi[3,0]  R320      -3.0999999046325684e+00
    phi[3,0]  R321      -3.0999999046325684e+00
    phi[3,0]  R322      -2.2400000095367432e+00
    phi[3,0]  R323      -2.2400000095367432e+00
    phi[3,0]  R324      -3.0999999046325684e+00
    phi[3,0]  R325      -3.0999999046325684e+00
    phi[3,0]  R326      -2.5699999332427979e+00
    phi[3,0]  R327      -2.5699999332427979e+00
    phi[3,0]  R328      -3.0999999046325684e+00
    phi[3,0]  R329      -3.0999999046325684e+00
    phi[3,0]  R330      -2.0899999141693115e+00
    phi[3,0]  R331      -2.0899999141693115e+00
    phi[3,0]  R332      -3.0999999046325684e+00
    phi[3,0]  R333      -3.0999999046325684e+00
    phi[3,0]  R334      5.9527075290679932e-01
    phi[3,0]  R335      -1.2242138385772705e+00
    phi[3,0]  R336      -5.2230614423751831e-01
    phi[3,0]  R337      2.5616529583930969e-01
    phi[3,0]  R338      -1.1316685676574707e+00
    phi[3,0]  R339      -1.3367012143135071e-03
    phi[3,0]  R340      -3.0023804306983948e-01
    phi[3,0]  R341      -5.2288264036178589e-01
    phi[3,0]  R342      0.738461434841156
    phi[3,0]  R343      0.313499391078949
    phi[3,0]  R344      4.6208846569061279e-01
    phi[3,0]  R345      7.1242183446884155e-01
    phi[3,0]  R346      0.861029863357544
    phi[3,0]  R347      1.7670917510986328e-01
    phi[3,0]  R348      4.3525347113609314e-01
    phi[3,0]  R349      5.8949780464172363e-01
    phi[3,0]  R350      5.3670644760131836e-01
    phi[3,0]  R351      -1.4095088839530945e-01
    phi[3,0]  R352      -1.4175664633512497e-02
    phi[3,0]  R353      -8.9108355343341827e-02
    phi[3,0]  R354      -1.7962698936462402e+00
    phi[3,0]  R355      -1.2218828201293945e+00
    phi[3,0]  R356      -1.3819094896316528e+00
    phi[3,0]  R357      -2.1596841812133789e+00
    phi[3,0]  R358      -1.9297324419021606e+00
    phi[3,0]  R359      -2.2597465515136719e+00
    phi[3,0]  R360      -2.6438345909118652e+00
    phi[3,0]  R361      -1.72129225730896
    phi[3,0]  R362      -1.1417835950851440e+00
    phi[3,0]  R363      -2.7227144241333008e+00
    phi[3,0]  R364      -1.3136377334594727e+00
    phi[3,0]  R365      -2.1711030602455139e-01
    phi[3,0]  R366      -1.2693651020526886e-01
    phi[3,0]  R367      -3.5147583484649658e-01
    phi[3,0]  R368      -2.8442423343658447e+00
    phi[3,0]  R369      -1.9939849376678467e+00
    phi[3,0]  R370      -1.2495437860488892e+00
    phi[3,0]  R371      -6.8911772966384888e-01
    phi[3,0]  R372      -1.6764041185379028e+00
    phi[3,0]  R373      -1.6778661012649536e+00
    phi[3,0]  R374      -2.9824137687683105e-01
    phi[3,0]  R375      -8.8157355785369873e-01
    phi[3,0]  R376      -1.1656290292739868e+00
    phi[3,0]  R377      9.0937864780426025e-01
    phi[3,0]  R378      -0.851057767868042
    phi[3,0]  R379      4.7243535518646240e-02
    phi[3,0]  R380      5.9957861900329590e-02
    phi[3,0]  R381      -3.2177748680114746e+00
    phi[3,0]  R382      -5.5479711294174194e-01
    phi[3,0]  R383      -4.5398325920104980e+00
    phi[3,0]  R384      -1.4329981803894043e+00
    phi[3,0]  R385      -1.5248183012008667e+00
    phi[3,0]  R386      2.9120454192161560e-01
    phi[3,0]  R387      -8.6056822538375854e-01
    phi[3,0]  R388      -2.1684589385986328e+00
    phi[3,0]  R389      -2.7242195606231689e+00
    phi[3,0]  R390      -3.2590880393981934e+00
    phi[3,0]  R391      -2.2550034523010254e+00
    phi[3,0]  R392      -3.5106179714202881e+00
    phi[3,0]  R393      -3.5556530952453613e+00
    phi[3,0]  R394      -7.4543547630310059e-01
    phi[3,0]  R395      -2.6229693889617920e+00
    phi[3,0]  R396      -0.424740731716156
    phi[3,0]  R397      -2.9630592465400696e-01
    phi[3,0]  R398      -1.2757879495620728e+00
    phi[3,0]  R399      -1.5019226074218750e+00
    phi[3,0]  R400      -1.7658958435058594e+00
    phi[3,0]  R401      -1.3697912693023682e+00
    phi[3,0]  R402      -1.4962083101272583e+00
    phi[3,0]  R403      -1.9053051471710205e+00
    phi[3,0]  R404      3.6565604805946350e-01
    phi[3,0]  R405      1.9332622289657593e+00
    phi[3,0]  R406      0.784713864326477
    phi[3,0]  R407      2.7247107028961182e+00
    phi[3,0]  R408      1.5234142541885376e+00
    phi[3,0]  R409      0.533897340297699
    phi[3,0]  R410      2.1584606170654297e+00
    phi[3,0]  R411      -7.5138753652572632e-01
    phi[3,0]  R412      1.9573984146118164e+00
    phi[3,0]  R413      -1.2342028617858887e+00
    phi[3,0]  R414      -2.80871319770813
    phi[3,0]  R415      -2.1054463386535645e+00
    phi[3,0]  R416      -1.8104027509689331e+00
    phi[3,0]  R417      -1.6505955457687378e+00
    phi[3,0]  R418      -2.1557338237762451e+00
    phi[3,0]  R419      -1.3589400053024292e+00
    phi[3,0]  R420      -6.7530733346939087e-01
    phi[3,0]  R421      2.5282242894172668e-01
    phi[3,0]  R422      -7.5058871507644653e-01
    phi[3,0]  R423      -5.7320779561996460e-01
    phi[3,0]  R424      -7.9436165094375610e-01
    phi[3,0]  R425      -4.0606668591499329e-01
    phi[3,0]  R426      -1.9706475734710693e+00
    phi[3,0]  R427      -8.1208193302154541e-01
    phi[3,0]  R428      -1.8418477773666382e+00
    phi[3,0]  R429      1.8309482336044312e+00
    phi[3,0]  R430      -2.1911011636257172e-01
    phi[3,0]  R431      7.2433924674987793e-01
    phi[3,0]  R432      -4.5891442894935608e-01
    phi[3,0]  R433      1.5939671993255615e+00
    phi[8,0]  R0        -1
    phi[8,0]  R2        -1.5628191065611610e+00
    phi[8,0]  R3        8.7158482804489124e-01
    phi[8,0]  R4        1.6610267623504416e+00
    phi[8,0]  R5        4.0355834465094942e-01
    phi[8,0]  R6        -2.7933367649454182e+00
    phi[8,0]  R7        -1.5668018520973472e+00
    phi[8,0]  R8        -2.6620762100774162e+00
    phi[8,0]  R72       1
    phi[8,0]  R434      -1.5371807980714074e+00
    phi[8,0]  R435      -4.6628190111937293e+00
    phi[8,0]  R436      -3.1115848375816344e+00
    phi[8,0]  R437      -1.3684151814918519e+00
    phi[8,0]  R438      -4.76102666698301
    phi[8,0]  R439      -1.4389731422821268e+00
    phi[8,0]  R440      -2.9735582778937473e+00
    phi[8,0]  R441      -2.1664415885918484e+00
    phi[8,0]  R442      -3.0666313968715020e-01
    phi[8,0]  R443      -5.8933366695779865e+00
    phi[8,0]  R444      -5.2319806207196429e-01
    phi[8,0]  R445      -3.6568017662666588e+00
    phi[8,0]  R446      -4.3792369455515212e-01
    phi[8,0]  R447      -5.7620761147099842e+00
    phi[8,0]  R448      -1.2151904437961609e+00
    phi[8,0]  R449      -7.7786377099048121e-02
    phi[8,0]  R450      -1.21489039535752
    phi[8,0]  R451      -4.8663098346476952e-01
    phi[8,0]  R452      -3.4506835115708934e-01
    phi[8,0]  R453      -4.0562241307161861e-01
    phi[8,0]  R454      -4.4605929832820834e-01
    phi[8,0]  R455      -5.1496079080383139e-01
    phi[8,0]  R456      -6.3850356125698671e-01
    phi[8,0]  R457      -8.2406111700684570e-01
    phi[8,0]  R458      -6.2720604908835575e-02
    phi[8,0]  R459      -2.5832928645697706e-01
    phi[8,0]  R460      -3.4422637566579017e-01
    phi[8,0]  R461      -3.5116929300519084e-01
    phi[8,0]  R462      -3.5712134742766333e-01
    phi[8,0]  R463      -3.6485667708312297e-01
    phi[8,0]  R464      -3.7629004916730407e-01
    phi[8,0]  R465      -3.8875544060855860e-01
    phi[8,0]  R466      -3.9118944426726621e-01
    phi[8,0]  R467      -4.0128808907422509e-01
    phi[8,0]  R468      -3.4646732651543966e-01
    phi[8,0]  R469      -0.40488765830711
    phi[8,0]  R470      -4.3159906513036606e-01
    phi[8,0]  R471      -4.6321970772614784e-01
    phi[8,0]  R472      -4.9722365953480230e-01
    phi[8,0]  R473      -5.0395920544060546e-01
    phi[8,0]  R474      -5.0499912077934384e-01
    phi[8,0]  R475      -5.1611917189600764e-01
    phi[8,0]  R476      -5.2566583224417673e-01
    phi[8,0]  R477      -0.530499607390015
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R478      -3.0999999046325684e+00
    phi[1,2]  R479      -3.0999999046325684e+00
    phi[1,2]  R480      -2.2400000095367432e+00
    phi[1,2]  R481      -2.2400000095367432e+00
    phi[1,2]  R482      -3.0999999046325684e+00
    phi[1,2]  R483      -3.0999999046325684e+00
    phi[1,2]  R484      -2.5699999332427979e+00
    phi[1,2]  R485      -2.5699999332427979e+00
    phi[1,2]  R486      -3.0999999046325684e+00
    phi[1,2]  R487      -3.0999999046325684e+00
    phi[1,2]  R488      -2.0899999141693115e+00
    phi[1,2]  R489      -2.0899999141693115e+00
    phi[1,2]  R490      -3.0999999046325684e+00
    phi[1,2]  R491      -3.0999999046325684e+00
    phi[1,2]  R492      -1.2307243794202805e-01
    phi[1,2]  R493      -1.3281011581420898e+00
    phi[1,2]  R494      3.0297225713729858e-01
    phi[1,2]  R495      1.0238726139068604e+00
    phi[1,2]  R496      1.3548754453659058e+00
    phi[1,2]  R497      1.0993119478225708e+00
    phi[1,2]  R498      1.4702049493789673e+00
    phi[1,2]  R499      2.7420988678932190e-01
    phi[1,2]  R500      1.1812584847211838e-01
    phi[1,2]  R501      -3.0493801832199097e-01
    phi[1,2]  R502      -2.9540972709655762e+00
    phi[1,2]  R503      -2.1569049358367920e+00
    phi[1,2]  R504      8.7015762925148010e-02
    phi[1,2]  R505      -1.8190245330333710e-01
    phi[1,2]  R506      -2.2479051724076271e-02
    phi[1,2]  R507      8.8917158544063568e-02
    phi[1,2]  R508      -0.763283371925354
    phi[1,2]  R509      0.5245361328125
    phi[1,2]  R510      -1.5604711771011353e+00
    phi[1,2]  R511      5.8831655979156494e-01
    phi[1,2]  R512      7.7987539768218994e-01
    phi[1,2]  R513      -0.664688229560852
    phi[1,2]  R514      1.3411812782287598e+00
    phi[1,2]  R515      5.0479370355606079e-01
    phi[1,2]  R516      1.3042377233505249e+00
    phi[1,2]  R517      2.6819040998816490e-02
    phi[1,2]  R518      -1.6842150688171387e-01
    phi[1,2]  R519      1.9785778522491455e+00
    phi[1,2]  R520      1.2087980508804321e+00
    phi[1,2]  R521      1.61650550365448
    phi[1,2]  R522      2.6933724880218506e+00
    phi[1,2]  R523      1.5383818149566650e+00
    phi[1,2]  R524      -1.1290540695190430e+00
    phi[1,2]  R525      -1.4497593641281128e+00
    phi[1,2]  R526      -1.0711253881454468e+00
    phi[1,2]  R527      -2.0975923538208008e+00
    phi[1,2]  R528      -1.6927391290664673e+00
    phi[1,2]  R529      -1.5782698392868042e+00
    phi[1,2]  R530      -2.5271096229553223e+00
    phi[1,2]  R531      -2.4926989078521729e+00
    phi[1,2]  R532      -2.7118947505950928e+00
    phi[1,2]  R533      -2.7348563671112061e+00
    phi[1,2]  R534      -3.6486701965332031e+00
    phi[1,2]  R535      -2.4000954627990723e+00
    phi[1,2]  R536      -2.4701709747314453e+00
    phi[1,2]  R537      -2.01944637298584
    phi[1,2]  R538      -2.5340330600738525e+00
    phi[1,2]  R539      -1.34540855884552
    phi[1,2]  R540      -1.3305389881134033e+00
    phi[1,2]  R541      -9.2121815681457520e-01
    phi[1,2]  R542      -1.3872380256652832e+00
    phi[1,2]  R543      3.8704064488410950e-01
    phi[1,2]  R544      5.5207714438438416e-02
    phi[1,2]  R545      -2.7320110797882080e+00
    phi[1,2]  R546      -1.1515014171600342e+00
    phi[1,2]  R547      -7.0801854133605957e-01
    phi[1,2]  R548      -1.8779934644699097e+00
    phi[1,2]  R549      -0.0931970626115799
    phi[1,2]  R550      -7.3168873786926270e-01
    phi[1,2]  R551      -1.7565588951110840e+00
    phi[1,2]  R552      -1.1734273433685303e+00
    phi[1,2]  R553      -1.1119202375411987e+00
    phi[1,2]  R554      -0.941415548324585
    phi[1,2]  R555      -1.5495136976242065e+00
    phi[1,2]  R556      -6.6499310731887817e-01
    phi[1,2]  R557      -7.2379785776138306e-01
    phi[1,2]  R558      -2.5985779762268066e+00
    phi[1,2]  R559      1.3108997046947479e-01
    phi[1,2]  R560      -1.1551762819290161e+00
    phi[1,2]  R561      -3.6746627092361450e-01
    phi[1,2]  R562      -3.7078714370727539e-01
    phi[1,2]  R563      1.0979274511337280e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R564      -3.0999999046325684e+00
    phi[2,1]  R565      -3.0999999046325684e+00
    phi[2,1]  R566      -2.2400000095367432e+00
    phi[2,1]  R567      -2.2400000095367432e+00
    phi[2,1]  R568      -3.0999999046325684e+00
    phi[2,1]  R569      -3.0999999046325684e+00
    phi[2,1]  R570      -2.5699999332427979e+00
    phi[2,1]  R571      -2.5699999332427979e+00
    phi[2,1]  R572      -3.0999999046325684e+00
    phi[2,1]  R573      -3.0999999046325684e+00
    phi[2,1]  R574      -2.0899999141693115e+00
    phi[2,1]  R575      -2.0899999141693115e+00
    phi[2,1]  R576      -3.0999999046325684e+00
    phi[2,1]  R577      -3.0999999046325684e+00
    phi[2,1]  R578      1.3411812782287598e+00
    phi[2,1]  R579      5.0479370355606079e-01
    phi[2,1]  R580      1.3042377233505249e+00
    phi[2,1]  R581      2.6819040998816490e-02
    phi[2,1]  R582      -1.6842150688171387e-01
    phi[2,1]  R583      1.9785778522491455e+00
    phi[2,1]  R584      1.2087980508804321e+00
    phi[2,1]  R585      1.61650550365448
    phi[2,1]  R586      2.6933724880218506e+00
    phi[2,1]  R587      1.5383818149566650e+00
    phi[2,1]  R588      -1.1290540695190430e+00
    phi[2,1]  R589      -1.4497593641281128e+00
    phi[2,1]  R590      -1.0711253881454468e+00
    phi[2,1]  R591      -2.0975923538208008e+00
    phi[2,1]  R592      -1.6927391290664673e+00
    phi[2,1]  R593      -1.5782698392868042e+00
    phi[2,1]  R594      -2.5271096229553223e+00
    phi[2,1]  R595      -2.4926989078521729e+00
    phi[2,1]  R596      -2.7118947505950928e+00
    phi[2,1]  R597      -2.7348563671112061e+00
    phi[2,1]  R598      -3.6486701965332031e+00
    phi[2,1]  R599      -2.4000954627990723e+00
    phi[2,1]  R600      -2.4701709747314453e+00
    phi[2,1]  R601      -2.01944637298584
    phi[2,1]  R602      -2.5340330600738525e+00
    phi[2,1]  R603      -1.34540855884552
    phi[2,1]  R604      -1.3305389881134033e+00
    phi[2,1]  R605      -9.2121815681457520e-01
    phi[2,1]  R606      -1.3872380256652832e+00
    phi[2,1]  R607      3.8704064488410950e-01
    phi[2,1]  R608      5.5207714438438416e-02
    phi[2,1]  R609      -2.7320110797882080e+00
    phi[2,1]  R610      -1.1515014171600342e+00
    phi[2,1]  R611      -7.0801854133605957e-01
    phi[2,1]  R612      -1.8779934644699097e+00
    phi[2,1]  R613      -0.0931970626115799
    phi[2,1]  R614      -7.3168873786926270e-01
    phi[2,1]  R615      -1.7565588951110840e+00
    phi[2,1]  R616      -1.1734273433685303e+00
    phi[2,1]  R617      -1.1119202375411987e+00
    phi[2,1]  R618      -0.941415548324585
    phi[2,1]  R619      -1.5495136976242065e+00
    phi[2,1]  R620      -6.6499310731887817e-01
    phi[2,1]  R621      -7.2379785776138306e-01
    phi[2,1]  R622      -2.5985779762268066e+00
    phi[2,1]  R623      1.3108997046947479e-01
    phi[2,1]  R624      -1.1551762819290161e+00
    phi[2,1]  R625      -3.6746627092361450e-01
    phi[2,1]  R626      -3.7078714370727539e-01
    phi[2,1]  R627      1.0979274511337280e+00
    phi[2,1]  R628      -1.2307243794202805e-01
    phi[2,1]  R629      -1.3281011581420898e+00
    phi[2,1]  R630      3.0297225713729858e-01
    phi[2,1]  R631      1.0238726139068604e+00
    phi[2,1]  R632      1.3548754453659058e+00
    phi[2,1]  R633      1.0993119478225708e+00
    phi[2,1]  R634      1.4702049493789673e+00
    phi[2,1]  R635      2.7420988678932190e-01
    phi[2,1]  R636      1.1812584847211838e-01
    phi[2,1]  R637      -3.0493801832199097e-01
    phi[2,1]  R638      -2.9540972709655762e+00
    phi[2,1]  R639      -2.1569049358367920e+00
    phi[2,1]  R640      8.7015762925148010e-02
    phi[2,1]  R641      -1.8190245330333710e-01
    phi[2,1]  R642      -2.2479051724076271e-02
    phi[2,1]  R643      8.8917158544063568e-02
    phi[2,1]  R644      -0.763283371925354
    phi[2,1]  R645      0.5245361328125
    phi[2,1]  R646      -1.5604711771011353e+00
    phi[2,1]  R647      5.8831655979156494e-01
    phi[2,1]  R648      7.7987539768218994e-01
    phi[2,1]  R649      -0.664688229560852
    phi[1,6]  R9        1
    phi[1,6]  R10       1
    phi[1,6]  R54       -1
    phi[1,6]  R650      -3.0999999046325684e+00
    phi[1,6]  R651      -3.0999999046325684e+00
    phi[1,6]  R652      -2.2400000095367432e+00
    phi[1,6]  R653      -2.2400000095367432e+00
    phi[1,6]  R654      -3.0999999046325684e+00
    phi[1,6]  R655      -3.0999999046325684e+00
    phi[1,6]  R656      -2.5699999332427979e+00
    phi[1,6]  R657      -2.5699999332427979e+00
    phi[1,6]  R658      -3.0999999046325684e+00
    phi[1,6]  R659      -3.0999999046325684e+00
    phi[1,6]  R660      -2.0899999141693115e+00
    phi[1,6]  R661      -2.0899999141693115e+00
    phi[1,6]  R662      -3.0999999046325684e+00
    phi[1,6]  R663      -3.0999999046325684e+00
    phi[1,6]  R664      -1.2307243794202805e-01
    phi[1,6]  R665      -1.3281011581420898e+00
    phi[1,6]  R666      3.0297225713729858e-01
    phi[1,6]  R667      1.0238726139068604e+00
    phi[1,6]  R668      1.3548754453659058e+00
    phi[1,6]  R669      1.0993119478225708e+00
    phi[1,6]  R670      1.4702049493789673e+00
    phi[1,6]  R671      2.7420988678932190e-01
    phi[1,6]  R672      1.1812584847211838e-01
    phi[1,6]  R673      -3.0493801832199097e-01
    phi[1,6]  R674      -2.9540972709655762e+00
    phi[1,6]  R675      -2.1569049358367920e+00
    phi[1,6]  R676      8.7015762925148010e-02
    phi[1,6]  R677      -1.8190245330333710e-01
    phi[1,6]  R678      -2.2479051724076271e-02
    phi[1,6]  R679      8.8917158544063568e-02
    phi[1,6]  R680      -0.763283371925354
    phi[1,6]  R681      0.5245361328125
    phi[1,6]  R682      -1.5604711771011353e+00
    phi[1,6]  R683      5.8831655979156494e-01
    phi[1,6]  R684      7.7987539768218994e-01
    phi[1,6]  R685      -0.664688229560852
    phi[1,6]  R686      8.7495046854019165e-01
    phi[1,6]  R687      2.5037071108818054e-01
    phi[1,6]  R688      9.6400880813598633e-01
    phi[1,6]  R689      -0.683203399181366
    phi[1,6]  R690      -4.3127548694610596e-01
    phi[1,6]  R691      -4.1872116923332214e-01
    phi[1,6]  R692      -2.5344082713127136e-01
    phi[1,6]  R693      5.6889337301254272e-01
    phi[1,6]  R694      -0.0974901095032692
    phi[1,6]  R695      1.6245014965534210e-01
    phi[1,6]  R696      -6.9860112667083740e-01
    phi[1,6]  R697      -7.5105029344558716e-01
    phi[1,6]  R698      3.8314312696456909e-01
    phi[1,6]  R699      -7.9122078418731689e-01
    phi[1,6]  R700      -7.8868812322616577e-01
    phi[1,6]  R701      -2.7147397398948669e-01
    phi[1,6]  R702      -4.5832499861717224e-02
    phi[1,6]  R703      -1.2700741291046143e+00
    phi[1,6]  R704      6.6759502887725830e-01
    phi[1,6]  R705      -1.8772035837173462e-01
    phi[1,6]  R706      -1.6135376691818237e+00
    phi[1,6]  R707      -1.0463728904724121e+00
    phi[1,6]  R708      -1.0189625024795532e+00
    phi[1,6]  R709      -0.934546172618866
    phi[1,6]  R710      -1.5581166744232178e+00
    phi[1,6]  R711      -1.0969597101211548e+00
    phi[1,6]  R712      -1.8437557220458984e+00
    phi[1,6]  R713      -1.5544735193252563e+00
    phi[1,6]  R714      -2.4562385082244873e+00
    phi[1,6]  R715      -6.5518438816070557e-01
    phi[1,6]  R716      -7.4301064014434814e-01
    phi[1,6]  R717      -7.4649810791015625e-01
    phi[1,6]  R718      7.5020968914031982e-01
    phi[1,6]  R719      -1.1850737333297729e+00
    phi[1,6]  R720      1.2056404352188110e+00
    phi[1,6]  R721      -3.8494008779525757e-01
    phi[1,6]  R722      -2.1036255359649658e+00
    phi[1,6]  R723      8.2493638992309570e-01
    phi[1,6]  R724      9.3966341018676758e-01
    phi[1,6]  R725      -1.2300194501876831e+00
    phi[1,6]  R726      -5.7208657264709473e-01
    phi[1,6]  R727      -9.0483617782592773e-01
    phi[1,6]  R728      -1.2728774547576904e+00
    phi[1,6]  R729      -1.1681164503097534e+00
    phi[1,6]  R730      -4.6655675768852234e-01
    phi[1,6]  R731      -7.1714675426483154e-01
    phi[1,6]  R732      2.3341160267591476e-03
    phi[1,6]  R733      -3.7110872566699982e-02
    phi[1,6]  R734      7.8503608703613281e-01
    phi[1,6]  R735      -1.1091300249099731e+00
    phi[1,6]  R736      -9.4535386562347412e-01
    phi[1,6]  R737      -2.2036793231964111e+00
    phi[1,6]  R738      -1.0869821310043335e+00
    phi[1,6]  R739      -1.5344493389129639e+00
    phi[1,6]  R740      -1.3530472517013550e+00
    phi[1,6]  R741      -1.9872808456420898e+00
    phi[1,6]  R742      -2.5382058620452881e+00
    phi[1,6]  R743      1.0747820138931274e+00
    phi[1,6]  R744      -2.1947214603424072e+00
    phi[1,6]  R745      -2.4837484359741211e+00
    phi[6,1]  R9        -1
    phi[6,1]  R54       1
    phi[6,1]  R55       1
    phi[6,1]  R746      -3.0999999046325684e+00
    phi[6,1]  R747      -3.0999999046325684e+00
    phi[6,1]  R748      -2.2400000095367432e+00
    phi[6,1]  R749      -2.2400000095367432e+00
    phi[6,1]  R750      -3.0999999046325684e+00
    phi[6,1]  R751      -3.0999999046325684e+00
    phi[6,1]  R752      -2.5699999332427979e+00
    phi[6,1]  R753      -2.5699999332427979e+00
    phi[6,1]  R754      -3.0999999046325684e+00
    phi[6,1]  R755      -3.0999999046325684e+00
    phi[6,1]  R756      -2.0899999141693115e+00
    phi[6,1]  R757      -2.0899999141693115e+00
    phi[6,1]  R758      -3.0999999046325684e+00
    phi[6,1]  R759      -3.0999999046325684e+00
    phi[6,1]  R760      8.7495046854019165e-01
    phi[6,1]  R761      2.5037071108818054e-01
    phi[6,1]  R762      9.6400880813598633e-01
    phi[6,1]  R763      -0.683203399181366
    phi[6,1]  R764      -4.3127548694610596e-01
    phi[6,1]  R765      -4.1872116923332214e-01
    phi[6,1]  R766      -2.5344082713127136e-01
    phi[6,1]  R767      5.6889337301254272e-01
    phi[6,1]  R768      -0.0974901095032692
    phi[6,1]  R769      1.6245014965534210e-01
    phi[6,1]  R770      -6.9860112667083740e-01
    phi[6,1]  R771      -7.5105029344558716e-01
    phi[6,1]  R772      3.8314312696456909e-01
    phi[6,1]  R773      -7.9122078418731689e-01
    phi[6,1]  R774      -7.8868812322616577e-01
    phi[6,1]  R775      -2.7147397398948669e-01
    phi[6,1]  R776      -4.5832499861717224e-02
    phi[6,1]  R777      -1.2700741291046143e+00
    phi[6,1]  R778      6.6759502887725830e-01
    phi[6,1]  R779      -1.8772035837173462e-01
    phi[6,1]  R780      -1.6135376691818237e+00
    phi[6,1]  R781      -1.0463728904724121e+00
    phi[6,1]  R782      -1.0189625024795532e+00
    phi[6,1]  R783      -0.934546172618866
    phi[6,1]  R784      -1.5581166744232178e+00
    phi[6,1]  R785      -1.0969597101211548e+00
    phi[6,1]  R786      -1.8437557220458984e+00
    phi[6,1]  R787      -1.5544735193252563e+00
    phi[6,1]  R788      -2.4562385082244873e+00
    phi[6,1]  R789      -6.5518438816070557e-01
    phi[6,1]  R790      -7.4301064014434814e-01
    phi[6,1]  R791      -7.4649810791015625e-01
    phi[6,1]  R792      7.5020968914031982e-01
    phi[6,1]  R793      -1.1850737333297729e+00
    phi[6,1]  R794      1.2056404352188110e+00
    phi[6,1]  R795      -3.8494008779525757e-01
    phi[6,1]  R796      -2.1036255359649658e+00
    phi[6,1]  R797      8.2493638992309570e-01
    phi[6,1]  R798      9.3966341018676758e-01
    phi[6,1]  R799      -1.2300194501876831e+00
    phi[6,1]  R800      -5.7208657264709473e-01
    phi[6,1]  R801      -9.0483617782592773e-01
    phi[6,1]  R802      -1.2728774547576904e+00
    phi[6,1]  R803      -1.1681164503097534e+00
    phi[6,1]  R804      -4.6655675768852234e-01
    phi[6,1]  R805      -7.1714675426483154e-01
    phi[6,1]  R806      2.3341160267591476e-03
    phi[6,1]  R807      -3.7110872566699982e-02
    phi[6,1]  R808      7.8503608703613281e-01
    phi[6,1]  R809      -1.1091300249099731e+00
    phi[6,1]  R810      -9.4535386562347412e-01
    phi[6,1]  R811      -2.2036793231964111e+00
    phi[6,1]  R812      -1.0869821310043335e+00
    phi[6,1]  R813      -1.5344493389129639e+00
    phi[6,1]  R814      -1.3530472517013550e+00
    phi[6,1]  R815      -1.9872808456420898e+00
    phi[6,1]  R816      -2.5382058620452881e+00
    phi[6,1]  R817      1.0747820138931274e+00
    phi[6,1]  R818      -2.1947214603424072e+00
    phi[6,1]  R819      -2.4837484359741211e+00
    phi[6,1]  R820      -1.2307243794202805e-01
    phi[6,1]  R821      -1.3281011581420898e+00
    phi[6,1]  R822      3.0297225713729858e-01
    phi[6,1]  R823      1.0238726139068604e+00
    phi[6,1]  R824      1.3548754453659058e+00
    phi[6,1]  R825      1.0993119478225708e+00
    phi[6,1]  R826      1.4702049493789673e+00
    phi[6,1]  R827      2.7420988678932190e-01
    phi[6,1]  R828      1.1812584847211838e-01
    phi[6,1]  R829      -3.0493801832199097e-01
    phi[6,1]  R830      -2.9540972709655762e+00
    phi[6,1]  R831      -2.1569049358367920e+00
    phi[6,1]  R832      8.7015762925148010e-02
    phi[6,1]  R833      -1.8190245330333710e-01
    phi[6,1]  R834      -2.2479051724076271e-02
    phi[6,1]  R835      8.8917158544063568e-02
    phi[6,1]  R836      -0.763283371925354
    phi[6,1]  R837      0.5245361328125
    phi[6,1]  R838      -1.5604711771011353e+00
    phi[6,1]  R839      5.8831655979156494e-01
    phi[6,1]  R840      7.7987539768218994e-01
    phi[6,1]  R841      -0.664688229560852
    phi[1,7]  R9        1
    phi[1,7]  R10       1
    phi[1,7]  R63       -1
    phi[1,7]  R842      -3.0999999046325684e+00
    phi[1,7]  R843      -3.0999999046325684e+00
    phi[1,7]  R844      -2.2400000095367432e+00
    phi[1,7]  R845      -2.2400000095367432e+00
    phi[1,7]  R846      -3.0999999046325684e+00
    phi[1,7]  R847      -3.0999999046325684e+00
    phi[1,7]  R848      -2.5699999332427979e+00
    phi[1,7]  R849      -2.5699999332427979e+00
    phi[1,7]  R850      -3.0999999046325684e+00
    phi[1,7]  R851      -3.0999999046325684e+00
    phi[1,7]  R852      -2.0899999141693115e+00
    phi[1,7]  R853      -2.0899999141693115e+00
    phi[1,7]  R854      -3.0999999046325684e+00
    phi[1,7]  R855      -3.0999999046325684e+00
    phi[1,7]  R856      -1.2307243794202805e-01
    phi[1,7]  R857      -1.3281011581420898e+00
    phi[1,7]  R858      3.0297225713729858e-01
    phi[1,7]  R859      1.0238726139068604e+00
    phi[1,7]  R860      1.3548754453659058e+00
    phi[1,7]  R861      1.0993119478225708e+00
    phi[1,7]  R862      1.4702049493789673e+00
    phi[1,7]  R863      2.7420988678932190e-01
    phi[1,7]  R864      1.1812584847211838e-01
    phi[1,7]  R865      -3.0493801832199097e-01
    phi[1,7]  R866      -2.9540972709655762e+00
    phi[1,7]  R867      -2.1569049358367920e+00
    phi[1,7]  R868      8.7015762925148010e-02
    phi[1,7]  R869      -1.8190245330333710e-01
    phi[1,7]  R870      -2.2479051724076271e-02
    phi[1,7]  R871      8.8917158544063568e-02
    phi[1,7]  R872      -0.763283371925354
    phi[1,7]  R873      0.5245361328125
    phi[1,7]  R874      -1.5604711771011353e+00
    phi[1,7]  R875      5.8831655979156494e-01
    phi[1,7]  R876      7.7987539768218994e-01
    phi[1,7]  R877      -0.664688229560852
    phi[1,7]  R878      2.1144406795501709e+00
    phi[1,7]  R879      1.9792606830596924e+00
    phi[1,7]  R880      1.6833561658859253e+00
    phi[1,7]  R881      1.2780048847198486e+00
    phi[1,7]  R882      1.2308484315872192e+00
    phi[1,7]  R883      2.6121463775634766e+00
    phi[1,7]  R884      -1.1800391674041748e+00
    phi[1,7]  R885      1.5402199029922485e+00
    phi[1,7]  R886      -1.3601590394973755e+00
    phi[1,7]  R887      2.6271450519561768e+00
    phi[1,7]  R888      -0.482153058052063
    phi[1,7]  R889      -2.8904716968536377e+00
    phi[1,7]  R890      -1.0741604119539261e-01
    phi[1,7]  R891      -1.7980536445975304e-02
    phi[1,7]  R892      -1.3092075288295746e-01
    phi[1,7]  R893      -2.3870782852172852e+00
    phi[1,7]  R894      6.8550604581832886e-01
    phi[1,7]  R895      -7.9667592048645020e-01
    phi[1,7]  R896      2.1459615230560303e-01
    phi[1,7]  R897      -7.2295659780502319e-01
    phi[1,7]  R898      -2.2008411884307861e+00
    phi[1,7]  R899      -2.2994735240936279e+00
    phi[1,7]  R900      -2.1309275627136230e+00
    phi[1,7]  R901      -7.9687809944152832e-01
    phi[1,7]  R902      2.7907836437225342e-01
    phi[1,7]  R903      -8.8418483734130859e-01
    phi[1,7]  R904      1.1598582267761230e+00
    phi[1,7]  R905      1.9396108388900757e+00
    phi[1,7]  R906      -5.7032382488250732e-01
    phi[1,7]  R907      -2.4599859714508057e+00
    phi[1,7]  R908      -1.2117483615875244e+00
    phi[1,7]  R909      -2.2240478992462158e+00
    phi[1,7]  R910      -2.0070824623107910e+00
    phi[1,7]  R911      1.8383126258850098e+00
    phi[1,7]  R912      -1.2903361320495605e+00
    phi[1,7]  R913      -1.4911212921142578e+00
    phi[1,7]  R914      -3.8724322319030762e+00
    phi[1,7]  R915      1.1478208303451538e+00
    phi[1,7]  R916      1.2953896522521973e+00
    phi[1,7]  R917      -2.7801849842071533e+00
    phi[1,7]  R918      -0.404674768447876
    phi[1,7]  R919      2.8939750045537949e-02
    phi[1,7]  R920      1.3138391971588135e+00
    phi[1,7]  R921      1.1891628503799438e+00
    phi[1,7]  R922      -0.842751681804657
    phi[1,7]  R923      -1.8913617134094238e+00
    phi[1,7]  R924      -7.2160124778747559e-01
    phi[1,7]  R925      -8.7981241941452026e-01
    phi[1,7]  R926      -9.8258769512176514e-01
    phi[1,7]  R927      -3.6123269796371460e-01
    phi[1,7]  R928      5.0934630632400513e-01
    phi[1,7]  R929      -1.1067686080932617e+00
    phi[1,7]  R930      -2.4848613739013672e+00
    phi[1,7]  R931      1.1282860040664673e+00
    phi[1,7]  R932      1.5288903377950191e-02
    phi[1,7]  R933      -0.517637312412262
    phi[1,7]  R934      -6.2668913602828979e-01
    phi[1,7]  R935      -1.9982647895812988e+00
    phi[1,7]  R936      -1.8644151687622070e+00
    phi[1,7]  R937      2.7569028735160828e-01
    phi[1,7]  R938      1.8489221334457397e+00
    phi[1,7]  R939      1.4827425479888916e+00
    phi[1,7]  R940      -4.3252408504486084e-01
    phi[1,7]  R941      -2.4905292987823486e+00
    phi[1,7]  R942      -1.9626625776290894e+00
    phi[1,7]  R943      -3.2300956249237061e+00
    phi[1,7]  R944      -2.4864916801452637e+00
    phi[1,7]  R945      -1.4207725524902344e+00
    phi[1,7]  R946      2.0508810877799988e-01
    phi[1,7]  R947      -1.1864368915557861e+00
    phi[7,1]  R9        -1
    phi[7,1]  R63       1
    phi[7,1]  R64       1
    phi[7,1]  R948      -3.0999999046325684e+00
    phi[7,1]  R949      -3.0999999046325684e+00
    phi[7,1]  R950      -2.2400000095367432e+00
    phi[7,1]  R951      -2.2400000095367432e+00
    phi[7,1]  R952      -3.0999999046325684e+00
    phi[7,1]  R953      -3.0999999046325684e+00
    phi[7,1]  R954      -2.5699999332427979e+00
    phi[7,1]  R955      -2.5699999332427979e+00
    phi[7,1]  R956      -3.0999999046325684e+00
    phi[7,1]  R957      -3.0999999046325684e+00
    phi[7,1]  R958      -2.0899999141693115e+00
    phi[7,1]  R959      -2.0899999141693115e+00
    phi[7,1]  R960      -3.0999999046325684e+00
    phi[7,1]  R961      -3.0999999046325684e+00
    phi[7,1]  R962      2.1144406795501709e+00
    phi[7,1]  R963      1.9792606830596924e+00
    phi[7,1]  R964      1.6833561658859253e+00
    phi[7,1]  R965      1.2780048847198486e+00
    phi[7,1]  R966      1.2308484315872192e+00
    phi[7,1]  R967      2.6121463775634766e+00
    phi[7,1]  R968      -1.1800391674041748e+00
    phi[7,1]  R969      1.5402199029922485e+00
    phi[7,1]  R970      -1.3601590394973755e+00
    phi[7,1]  R971      2.6271450519561768e+00
    phi[7,1]  R972      -0.482153058052063
    phi[7,1]  R973      -2.8904716968536377e+00
    phi[7,1]  R974      -1.0741604119539261e-01
    phi[7,1]  R975      -1.7980536445975304e-02
    phi[7,1]  R976      -1.3092075288295746e-01
    phi[7,1]  R977      -2.3870782852172852e+00
    phi[7,1]  R978      6.8550604581832886e-01
    phi[7,1]  R979      -7.9667592048645020e-01
    phi[7,1]  R980      2.1459615230560303e-01
    phi[7,1]  R981      -7.2295659780502319e-01
    phi[7,1]  R982      -2.2008411884307861e+00
    phi[7,1]  R983      -2.2994735240936279e+00
    phi[7,1]  R984      -2.1309275627136230e+00
    phi[7,1]  R985      -7.9687809944152832e-01
    phi[7,1]  R986      2.7907836437225342e-01
    phi[7,1]  R987      -8.8418483734130859e-01
    phi[7,1]  R988      1.1598582267761230e+00
    phi[7,1]  R989      1.9396108388900757e+00
    phi[7,1]  R990      -5.7032382488250732e-01
    phi[7,1]  R991      -2.4599859714508057e+00
    phi[7,1]  R992      -1.2117483615875244e+00
    phi[7,1]  R993      -2.2240478992462158e+00
    phi[7,1]  R994      -2.0070824623107910e+00
    phi[7,1]  R995      1.8383126258850098e+00
    phi[7,1]  R996      -1.2903361320495605e+00
    phi[7,1]  R997      -1.4911212921142578e+00
    phi[7,1]  R998      -3.8724322319030762e+00
    phi[7,1]  R999      1.1478208303451538e+00
    phi[7,1]  R1000     1.2953896522521973e+00
    phi[7,1]  R1001     -2.7801849842071533e+00
    phi[7,1]  R1002     -0.404674768447876
    phi[7,1]  R1003     2.8939750045537949e-02
    phi[7,1]  R1004     1.3138391971588135e+00
    phi[7,1]  R1005     1.1891628503799438e+00
    phi[7,1]  R1006     -0.842751681804657
    phi[7,1]  R1007     -1.8913617134094238e+00
    phi[7,1]  R1008     -7.2160124778747559e-01
    phi[7,1]  R1009     -8.7981241941452026e-01
    phi[7,1]  R1010     -9.8258769512176514e-01
    phi[7,1]  R1011     -3.6123269796371460e-01
    phi[7,1]  R1012     5.0934630632400513e-01
    phi[7,1]  R1013     -1.1067686080932617e+00
    phi[7,1]  R1014     -2.4848613739013672e+00
    phi[7,1]  R1015     1.1282860040664673e+00
    phi[7,1]  R1016     1.5288903377950191e-02
    phi[7,1]  R1017     -0.517637312412262
    phi[7,1]  R1018     -6.2668913602828979e-01
    phi[7,1]  R1019     -1.9982647895812988e+00
    phi[7,1]  R1020     -1.8644151687622070e+00
    phi[7,1]  R1021     2.7569028735160828e-01
    phi[7,1]  R1022     1.8489221334457397e+00
    phi[7,1]  R1023     1.4827425479888916e+00
    phi[7,1]  R1024     -4.3252408504486084e-01
    phi[7,1]  R1025     -2.4905292987823486e+00
    phi[7,1]  R1026     -1.9626625776290894e+00
    phi[7,1]  R1027     -3.2300956249237061e+00
    phi[7,1]  R1028     -2.4864916801452637e+00
    phi[7,1]  R1029     -1.4207725524902344e+00
    phi[7,1]  R1030     2.0508810877799988e-01
    phi[7,1]  R1031     -1.1864368915557861e+00
    phi[7,1]  R1032     -1.2307243794202805e-01
    phi[7,1]  R1033     -1.3281011581420898e+00
    phi[7,1]  R1034     3.0297225713729858e-01
    phi[7,1]  R1035     1.0238726139068604e+00
    phi[7,1]  R1036     1.3548754453659058e+00
    phi[7,1]  R1037     1.0993119478225708e+00
    phi[7,1]  R1038     1.4702049493789673e+00
    phi[7,1]  R1039     2.7420988678932190e-01
    phi[7,1]  R1040     1.1812584847211838e-01
    phi[7,1]  R1041     -3.0493801832199097e-01
    phi[7,1]  R1042     -2.9540972709655762e+00
    phi[7,1]  R1043     -2.1569049358367920e+00
    phi[7,1]  R1044     8.7015762925148010e-02
    phi[7,1]  R1045     -1.8190245330333710e-01
    phi[7,1]  R1046     -2.2479051724076271e-02
    phi[7,1]  R1047     8.8917158544063568e-02
    phi[7,1]  R1048     -0.763283371925354
    phi[7,1]  R1049     0.5245361328125
    phi[7,1]  R1050     -1.5604711771011353e+00
    phi[7,1]  R1051     5.8831655979156494e-01
    phi[7,1]  R1052     7.7987539768218994e-01
    phi[7,1]  R1053     -0.664688229560852
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1054     -3.0999999046325684e+00
    phi[2,6]  R1055     -3.0999999046325684e+00
    phi[2,6]  R1056     -2.2400000095367432e+00
    phi[2,6]  R1057     -2.2400000095367432e+00
    phi[2,6]  R1058     -3.0999999046325684e+00
    phi[2,6]  R1059     -3.0999999046325684e+00
    phi[2,6]  R1060     -2.5699999332427979e+00
    phi[2,6]  R1061     -2.5699999332427979e+00
    phi[2,6]  R1062     -3.0999999046325684e+00
    phi[2,6]  R1063     -3.0999999046325684e+00
    phi[2,6]  R1064     -2.0899999141693115e+00
    phi[2,6]  R1065     -2.0899999141693115e+00
    phi[2,6]  R1066     -3.0999999046325684e+00
    phi[2,6]  R1067     -3.0999999046325684e+00
    phi[2,6]  R1068     1.3411812782287598e+00
    phi[2,6]  R1069     5.0479370355606079e-01
    phi[2,6]  R1070     1.3042377233505249e+00
    phi[2,6]  R1071     2.6819040998816490e-02
    phi[2,6]  R1072     -1.6842150688171387e-01
    phi[2,6]  R1073     1.9785778522491455e+00
    phi[2,6]  R1074     1.2087980508804321e+00
    phi[2,6]  R1075     1.61650550365448
    phi[2,6]  R1076     2.6933724880218506e+00
    phi[2,6]  R1077     1.5383818149566650e+00
    phi[2,6]  R1078     -1.1290540695190430e+00
    phi[2,6]  R1079     -1.4497593641281128e+00
    phi[2,6]  R1080     -1.0711253881454468e+00
    phi[2,6]  R1081     -2.0975923538208008e+00
    phi[2,6]  R1082     -1.6927391290664673e+00
    phi[2,6]  R1083     -1.5782698392868042e+00
    phi[2,6]  R1084     -2.5271096229553223e+00
    phi[2,6]  R1085     -2.4926989078521729e+00
    phi[2,6]  R1086     -2.7118947505950928e+00
    phi[2,6]  R1087     -2.7348563671112061e+00
    phi[2,6]  R1088     -3.6486701965332031e+00
    phi[2,6]  R1089     -2.4000954627990723e+00
    phi[2,6]  R1090     -2.4701709747314453e+00
    phi[2,6]  R1091     -2.01944637298584
    phi[2,6]  R1092     -2.5340330600738525e+00
    phi[2,6]  R1093     -1.34540855884552
    phi[2,6]  R1094     -1.3305389881134033e+00
    phi[2,6]  R1095     -9.2121815681457520e-01
    phi[2,6]  R1096     -1.3872380256652832e+00
    phi[2,6]  R1097     3.8704064488410950e-01
    phi[2,6]  R1098     5.5207714438438416e-02
    phi[2,6]  R1099     -2.7320110797882080e+00
    phi[2,6]  R1100     -1.1515014171600342e+00
    phi[2,6]  R1101     -7.0801854133605957e-01
    phi[2,6]  R1102     -1.8779934644699097e+00
    phi[2,6]  R1103     -0.0931970626115799
    phi[2,6]  R1104     -7.3168873786926270e-01
    phi[2,6]  R1105     -1.7565588951110840e+00
    phi[2,6]  R1106     -1.1734273433685303e+00
    phi[2,6]  R1107     -1.1119202375411987e+00
    phi[2,6]  R1108     -0.941415548324585
    phi[2,6]  R1109     -1.5495136976242065e+00
    phi[2,6]  R1110     -6.6499310731887817e-01
    phi[2,6]  R1111     -7.2379785776138306e-01
    phi[2,6]  R1112     -2.5985779762268066e+00
    phi[2,6]  R1113     1.3108997046947479e-01
    phi[2,6]  R1114     -1.1551762819290161e+00
    phi[2,6]  R1115     -3.6746627092361450e-01
    phi[2,6]  R1116     -3.7078714370727539e-01
    phi[2,6]  R1117     1.0979274511337280e+00
    phi[2,6]  R1118     8.7495046854019165e-01
    phi[2,6]  R1119     2.5037071108818054e-01
    phi[2,6]  R1120     9.6400880813598633e-01
    phi[2,6]  R1121     -0.683203399181366
    phi[2,6]  R1122     -4.3127548694610596e-01
    phi[2,6]  R1123     -4.1872116923332214e-01
    phi[2,6]  R1124     -2.5344082713127136e-01
    phi[2,6]  R1125     5.6889337301254272e-01
    phi[2,6]  R1126     -0.0974901095032692
    phi[2,6]  R1127     1.6245014965534210e-01
    phi[2,6]  R1128     -6.9860112667083740e-01
    phi[2,6]  R1129     -7.5105029344558716e-01
    phi[2,6]  R1130     3.8314312696456909e-01
    phi[2,6]  R1131     -7.9122078418731689e-01
    phi[2,6]  R1132     -7.8868812322616577e-01
    phi[2,6]  R1133     -2.7147397398948669e-01
    phi[2,6]  R1134     -4.5832499861717224e-02
    phi[2,6]  R1135     -1.2700741291046143e+00
    phi[2,6]  R1136     6.6759502887725830e-01
    phi[2,6]  R1137     -1.8772035837173462e-01
    phi[2,6]  R1138     -1.6135376691818237e+00
    phi[2,6]  R1139     -1.0463728904724121e+00
    phi[2,6]  R1140     -1.0189625024795532e+00
    phi[2,6]  R1141     -0.934546172618866
    phi[2,6]  R1142     -1.5581166744232178e+00
    phi[2,6]  R1143     -1.0969597101211548e+00
    phi[2,6]  R1144     -1.8437557220458984e+00
    phi[2,6]  R1145     -1.5544735193252563e+00
    phi[2,6]  R1146     -2.4562385082244873e+00
    phi[2,6]  R1147     -6.5518438816070557e-01
    phi[2,6]  R1148     -7.4301064014434814e-01
    phi[2,6]  R1149     -7.4649810791015625e-01
    phi[2,6]  R1150     7.5020968914031982e-01
    phi[2,6]  R1151     -1.1850737333297729e+00
    phi[2,6]  R1152     1.2056404352188110e+00
    phi[2,6]  R1153     -3.8494008779525757e-01
    phi[2,6]  R1154     -2.1036255359649658e+00
    phi[2,6]  R1155     8.2493638992309570e-01
    phi[2,6]  R1156     9.3966341018676758e-01
    phi[2,6]  R1157     -1.2300194501876831e+00
    phi[2,6]  R1158     -5.7208657264709473e-01
    phi[2,6]  R1159     -9.0483617782592773e-01
    phi[2,6]  R1160     -1.2728774547576904e+00
    phi[2,6]  R1161     -1.1681164503097534e+00
    phi[2,6]  R1162     -4.6655675768852234e-01
    phi[2,6]  R1163     -7.1714675426483154e-01
    phi[2,6]  R1164     2.3341160267591476e-03
    phi[2,6]  R1165     -3.7110872566699982e-02
    phi[2,6]  R1166     7.8503608703613281e-01
    phi[2,6]  R1167     -1.1091300249099731e+00
    phi[2,6]  R1168     -9.4535386562347412e-01
    phi[2,6]  R1169     -2.2036793231964111e+00
    phi[2,6]  R1170     -1.0869821310043335e+00
    phi[2,6]  R1171     -1.5344493389129639e+00
    phi[2,6]  R1172     -1.3530472517013550e+00
    phi[2,6]  R1173     -1.9872808456420898e+00
    phi[2,6]  R1174     -2.5382058620452881e+00
    phi[2,6]  R1175     1.0747820138931274e+00
    phi[2,6]  R1176     -2.1947214603424072e+00
    phi[2,6]  R1177     -2.4837484359741211e+00
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1178     -3.0999999046325684e+00
    phi[6,2]  R1179     -3.0999999046325684e+00
    phi[6,2]  R1180     -2.2400000095367432e+00
    phi[6,2]  R1181     -2.2400000095367432e+00
    phi[6,2]  R1182     -3.0999999046325684e+00
    phi[6,2]  R1183     -3.0999999046325684e+00
    phi[6,2]  R1184     -2.5699999332427979e+00
    phi[6,2]  R1185     -2.5699999332427979e+00
    phi[6,2]  R1186     -3.0999999046325684e+00
    phi[6,2]  R1187     -3.0999999046325684e+00
    phi[6,2]  R1188     -2.0899999141693115e+00
    phi[6,2]  R1189     -2.0899999141693115e+00
    phi[6,2]  R1190     -3.0999999046325684e+00
    phi[6,2]  R1191     -3.0999999046325684e+00
    phi[6,2]  R1192     8.7495046854019165e-01
    phi[6,2]  R1193     2.5037071108818054e-01
    phi[6,2]  R1194     9.6400880813598633e-01
    phi[6,2]  R1195     -0.683203399181366
    phi[6,2]  R1196     -4.3127548694610596e-01
    phi[6,2]  R1197     -4.1872116923332214e-01
    phi[6,2]  R1198     -2.5344082713127136e-01
    phi[6,2]  R1199     5.6889337301254272e-01
    phi[6,2]  R1200     -0.0974901095032692
    phi[6,2]  R1201     1.6245014965534210e-01
    phi[6,2]  R1202     -6.9860112667083740e-01
    phi[6,2]  R1203     -7.5105029344558716e-01
    phi[6,2]  R1204     3.8314312696456909e-01
    phi[6,2]  R1205     -7.9122078418731689e-01
    phi[6,2]  R1206     -7.8868812322616577e-01
    phi[6,2]  R1207     -2.7147397398948669e-01
    phi[6,2]  R1208     -4.5832499861717224e-02
    phi[6,2]  R1209     -1.2700741291046143e+00
    phi[6,2]  R1210     6.6759502887725830e-01
    phi[6,2]  R1211     -1.8772035837173462e-01
    phi[6,2]  R1212     -1.6135376691818237e+00
    phi[6,2]  R1213     -1.0463728904724121e+00
    phi[6,2]  R1214     -1.0189625024795532e+00
    phi[6,2]  R1215     -0.934546172618866
    phi[6,2]  R1216     -1.5581166744232178e+00
    phi[6,2]  R1217     -1.0969597101211548e+00
    phi[6,2]  R1218     -1.8437557220458984e+00
    phi[6,2]  R1219     -1.5544735193252563e+00
    phi[6,2]  R1220     -2.4562385082244873e+00
    phi[6,2]  R1221     -6.5518438816070557e-01
    phi[6,2]  R1222     -7.4301064014434814e-01
    phi[6,2]  R1223     -7.4649810791015625e-01
    phi[6,2]  R1224     7.5020968914031982e-01
    phi[6,2]  R1225     -1.1850737333297729e+00
    phi[6,2]  R1226     1.2056404352188110e+00
    phi[6,2]  R1227     -3.8494008779525757e-01
    phi[6,2]  R1228     -2.1036255359649658e+00
    phi[6,2]  R1229     8.2493638992309570e-01
    phi[6,2]  R1230     9.3966341018676758e-01
    phi[6,2]  R1231     -1.2300194501876831e+00
    phi[6,2]  R1232     -5.7208657264709473e-01
    phi[6,2]  R1233     -9.0483617782592773e-01
    phi[6,2]  R1234     -1.2728774547576904e+00
    phi[6,2]  R1235     -1.1681164503097534e+00
    phi[6,2]  R1236     -4.6655675768852234e-01
    phi[6,2]  R1237     -7.1714675426483154e-01
    phi[6,2]  R1238     2.3341160267591476e-03
    phi[6,2]  R1239     -3.7110872566699982e-02
    phi[6,2]  R1240     7.8503608703613281e-01
    phi[6,2]  R1241     -1.1091300249099731e+00
    phi[6,2]  R1242     -9.4535386562347412e-01
    phi[6,2]  R1243     -2.2036793231964111e+00
    phi[6,2]  R1244     -1.0869821310043335e+00
    phi[6,2]  R1245     -1.5344493389129639e+00
    phi[6,2]  R1246     -1.3530472517013550e+00
    phi[6,2]  R1247     -1.9872808456420898e+00
    phi[6,2]  R1248     -2.5382058620452881e+00
    phi[6,2]  R1249     1.0747820138931274e+00
    phi[6,2]  R1250     -2.1947214603424072e+00
    phi[6,2]  R1251     -2.4837484359741211e+00
    phi[6,2]  R1252     1.3411812782287598e+00
    phi[6,2]  R1253     5.0479370355606079e-01
    phi[6,2]  R1254     1.3042377233505249e+00
    phi[6,2]  R1255     2.6819040998816490e-02
    phi[6,2]  R1256     -1.6842150688171387e-01
    phi[6,2]  R1257     1.9785778522491455e+00
    phi[6,2]  R1258     1.2087980508804321e+00
    phi[6,2]  R1259     1.61650550365448
    phi[6,2]  R1260     2.6933724880218506e+00
    phi[6,2]  R1261     1.5383818149566650e+00
    phi[6,2]  R1262     -1.1290540695190430e+00
    phi[6,2]  R1263     -1.4497593641281128e+00
    phi[6,2]  R1264     -1.0711253881454468e+00
    phi[6,2]  R1265     -2.0975923538208008e+00
    phi[6,2]  R1266     -1.6927391290664673e+00
    phi[6,2]  R1267     -1.5782698392868042e+00
    phi[6,2]  R1268     -2.5271096229553223e+00
    phi[6,2]  R1269     -2.4926989078521729e+00
    phi[6,2]  R1270     -2.7118947505950928e+00
    phi[6,2]  R1271     -2.7348563671112061e+00
    phi[6,2]  R1272     -3.6486701965332031e+00
    phi[6,2]  R1273     -2.4000954627990723e+00
    phi[6,2]  R1274     -2.4701709747314453e+00
    phi[6,2]  R1275     -2.01944637298584
    phi[6,2]  R1276     -2.5340330600738525e+00
    phi[6,2]  R1277     -1.34540855884552
    phi[6,2]  R1278     -1.3305389881134033e+00
    phi[6,2]  R1279     -9.2121815681457520e-01
    phi[6,2]  R1280     -1.3872380256652832e+00
    phi[6,2]  R1281     3.8704064488410950e-01
    phi[6,2]  R1282     5.5207714438438416e-02
    phi[6,2]  R1283     -2.7320110797882080e+00
    phi[6,2]  R1284     -1.1515014171600342e+00
    phi[6,2]  R1285     -7.0801854133605957e-01
    phi[6,2]  R1286     -1.8779934644699097e+00
    phi[6,2]  R1287     -0.0931970626115799
    phi[6,2]  R1288     -7.3168873786926270e-01
    phi[6,2]  R1289     -1.7565588951110840e+00
    phi[6,2]  R1290     -1.1734273433685303e+00
    phi[6,2]  R1291     -1.1119202375411987e+00
    phi[6,2]  R1292     -0.941415548324585
    phi[6,2]  R1293     -1.5495136976242065e+00
    phi[6,2]  R1294     -6.6499310731887817e-01
    phi[6,2]  R1295     -7.2379785776138306e-01
    phi[6,2]  R1296     -2.5985779762268066e+00
    phi[6,2]  R1297     1.3108997046947479e-01
    phi[6,2]  R1298     -1.1551762819290161e+00
    phi[6,2]  R1299     -3.6746627092361450e-01
    phi[6,2]  R1300     -3.7078714370727539e-01
    phi[6,2]  R1301     1.0979274511337280e+00
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R63       -1
    phi[2,7]  R1302     -3.0999999046325684e+00
    phi[2,7]  R1303     -3.0999999046325684e+00
    phi[2,7]  R1304     -2.2400000095367432e+00
    phi[2,7]  R1305     -2.2400000095367432e+00
    phi[2,7]  R1306     -3.0999999046325684e+00
    phi[2,7]  R1307     -3.0999999046325684e+00
    phi[2,7]  R1308     -2.5699999332427979e+00
    phi[2,7]  R1309     -2.5699999332427979e+00
    phi[2,7]  R1310     -3.0999999046325684e+00
    phi[2,7]  R1311     -3.0999999046325684e+00
    phi[2,7]  R1312     -2.0899999141693115e+00
    phi[2,7]  R1313     -2.0899999141693115e+00
    phi[2,7]  R1314     -3.0999999046325684e+00
    phi[2,7]  R1315     -3.0999999046325684e+00
    phi[2,7]  R1316     1.3411812782287598e+00
    phi[2,7]  R1317     5.0479370355606079e-01
    phi[2,7]  R1318     1.3042377233505249e+00
    phi[2,7]  R1319     2.6819040998816490e-02
    phi[2,7]  R1320     -1.6842150688171387e-01
    phi[2,7]  R1321     1.9785778522491455e+00
    phi[2,7]  R1322     1.2087980508804321e+00
    phi[2,7]  R1323     1.61650550365448
    phi[2,7]  R1324     2.6933724880218506e+00
    phi[2,7]  R1325     1.5383818149566650e+00
    phi[2,7]  R1326     -1.1290540695190430e+00
    phi[2,7]  R1327     -1.4497593641281128e+00
    phi[2,7]  R1328     -1.0711253881454468e+00
    phi[2,7]  R1329     -2.0975923538208008e+00
    phi[2,7]  R1330     -1.6927391290664673e+00
    phi[2,7]  R1331     -1.5782698392868042e+00
    phi[2,7]  R1332     -2.5271096229553223e+00
    phi[2,7]  R1333     -2.4926989078521729e+00
    phi[2,7]  R1334     -2.7118947505950928e+00
    phi[2,7]  R1335     -2.7348563671112061e+00
    phi[2,7]  R1336     -3.6486701965332031e+00
    phi[2,7]  R1337     -2.4000954627990723e+00
    phi[2,7]  R1338     -2.4701709747314453e+00
    phi[2,7]  R1339     -2.01944637298584
    phi[2,7]  R1340     -2.5340330600738525e+00
    phi[2,7]  R1341     -1.34540855884552
    phi[2,7]  R1342     -1.3305389881134033e+00
    phi[2,7]  R1343     -9.2121815681457520e-01
    phi[2,7]  R1344     -1.3872380256652832e+00
    phi[2,7]  R1345     3.8704064488410950e-01
    phi[2,7]  R1346     5.5207714438438416e-02
    phi[2,7]  R1347     -2.7320110797882080e+00
    phi[2,7]  R1348     -1.1515014171600342e+00
    phi[2,7]  R1349     -7.0801854133605957e-01
    phi[2,7]  R1350     -1.8779934644699097e+00
    phi[2,7]  R1351     -0.0931970626115799
    phi[2,7]  R1352     -7.3168873786926270e-01
    phi[2,7]  R1353     -1.7565588951110840e+00
    phi[2,7]  R1354     -1.1734273433685303e+00
    phi[2,7]  R1355     -1.1119202375411987e+00
    phi[2,7]  R1356     -0.941415548324585
    phi[2,7]  R1357     -1.5495136976242065e+00
    phi[2,7]  R1358     -6.6499310731887817e-01
    phi[2,7]  R1359     -7.2379785776138306e-01
    phi[2,7]  R1360     -2.5985779762268066e+00
    phi[2,7]  R1361     1.3108997046947479e-01
    phi[2,7]  R1362     -1.1551762819290161e+00
    phi[2,7]  R1363     -3.6746627092361450e-01
    phi[2,7]  R1364     -3.7078714370727539e-01
    phi[2,7]  R1365     1.0979274511337280e+00
    phi[2,7]  R1366     2.1144406795501709e+00
    phi[2,7]  R1367     1.9792606830596924e+00
    phi[2,7]  R1368     1.6833561658859253e+00
    phi[2,7]  R1369     1.2780048847198486e+00
    phi[2,7]  R1370     1.2308484315872192e+00
    phi[2,7]  R1371     2.6121463775634766e+00
    phi[2,7]  R1372     -1.1800391674041748e+00
    phi[2,7]  R1373     1.5402199029922485e+00
    phi[2,7]  R1374     -1.3601590394973755e+00
    phi[2,7]  R1375     2.6271450519561768e+00
    phi[2,7]  R1376     -0.482153058052063
    phi[2,7]  R1377     -2.8904716968536377e+00
    phi[2,7]  R1378     -1.0741604119539261e-01
    phi[2,7]  R1379     -1.7980536445975304e-02
    phi[2,7]  R1380     -1.3092075288295746e-01
    phi[2,7]  R1381     -2.3870782852172852e+00
    phi[2,7]  R1382     6.8550604581832886e-01
    phi[2,7]  R1383     -7.9667592048645020e-01
    phi[2,7]  R1384     2.1459615230560303e-01
    phi[2,7]  R1385     -7.2295659780502319e-01
    phi[2,7]  R1386     -2.2008411884307861e+00
    phi[2,7]  R1387     -2.2994735240936279e+00
    phi[2,7]  R1388     -2.1309275627136230e+00
    phi[2,7]  R1389     -7.9687809944152832e-01
    phi[2,7]  R1390     2.7907836437225342e-01
    phi[2,7]  R1391     -8.8418483734130859e-01
    phi[2,7]  R1392     1.1598582267761230e+00
    phi[2,7]  R1393     1.9396108388900757e+00
    phi[2,7]  R1394     -5.7032382488250732e-01
    phi[2,7]  R1395     -2.4599859714508057e+00
    phi[2,7]  R1396     -1.2117483615875244e+00
    phi[2,7]  R1397     -2.2240478992462158e+00
    phi[2,7]  R1398     -2.0070824623107910e+00
    phi[2,7]  R1399     1.8383126258850098e+00
    phi[2,7]  R1400     -1.2903361320495605e+00
    phi[2,7]  R1401     -1.4911212921142578e+00
    phi[2,7]  R1402     -3.8724322319030762e+00
    phi[2,7]  R1403     1.1478208303451538e+00
    phi[2,7]  R1404     1.2953896522521973e+00
    phi[2,7]  R1405     -2.7801849842071533e+00
    phi[2,7]  R1406     -0.404674768447876
    phi[2,7]  R1407     2.8939750045537949e-02
    phi[2,7]  R1408     1.3138391971588135e+00
    phi[2,7]  R1409     1.1891628503799438e+00
    phi[2,7]  R1410     -0.842751681804657
    phi[2,7]  R1411     -1.8913617134094238e+00
    phi[2,7]  R1412     -7.2160124778747559e-01
    phi[2,7]  R1413     -8.7981241941452026e-01
    phi[2,7]  R1414     -9.8258769512176514e-01
    phi[2,7]  R1415     -3.6123269796371460e-01
    phi[2,7]  R1416     5.0934630632400513e-01
    phi[2,7]  R1417     -1.1067686080932617e+00
    phi[2,7]  R1418     -2.4848613739013672e+00
    phi[2,7]  R1419     1.1282860040664673e+00
    phi[2,7]  R1420     1.5288903377950191e-02
    phi[2,7]  R1421     -0.517637312412262
    phi[2,7]  R1422     -6.2668913602828979e-01
    phi[2,7]  R1423     -1.9982647895812988e+00
    phi[2,7]  R1424     -1.8644151687622070e+00
    phi[2,7]  R1425     2.7569028735160828e-01
    phi[2,7]  R1426     1.8489221334457397e+00
    phi[2,7]  R1427     1.4827425479888916e+00
    phi[2,7]  R1428     -4.3252408504486084e-01
    phi[2,7]  R1429     -2.4905292987823486e+00
    phi[2,7]  R1430     -1.9626625776290894e+00
    phi[2,7]  R1431     -3.2300956249237061e+00
    phi[2,7]  R1432     -2.4864916801452637e+00
    phi[2,7]  R1433     -1.4207725524902344e+00
    phi[2,7]  R1434     2.0508810877799988e-01
    phi[2,7]  R1435     -1.1864368915557861e+00
    phi[7,2]  R18       -1
    phi[7,2]  R63       1
    phi[7,2]  R64       1
    phi[7,2]  R1436     -3.0999999046325684e+00
    phi[7,2]  R1437     -3.0999999046325684e+00
    phi[7,2]  R1438     -2.2400000095367432e+00
    phi[7,2]  R1439     -2.2400000095367432e+00
    phi[7,2]  R1440     -3.0999999046325684e+00
    phi[7,2]  R1441     -3.0999999046325684e+00
    phi[7,2]  R1442     -2.5699999332427979e+00
    phi[7,2]  R1443     -2.5699999332427979e+00
    phi[7,2]  R1444     -3.0999999046325684e+00
    phi[7,2]  R1445     -3.0999999046325684e+00
    phi[7,2]  R1446     -2.0899999141693115e+00
    phi[7,2]  R1447     -2.0899999141693115e+00
    phi[7,2]  R1448     -3.0999999046325684e+00
    phi[7,2]  R1449     -3.0999999046325684e+00
    phi[7,2]  R1450     2.1144406795501709e+00
    phi[7,2]  R1451     1.9792606830596924e+00
    phi[7,2]  R1452     1.6833561658859253e+00
    phi[7,2]  R1453     1.2780048847198486e+00
    phi[7,2]  R1454     1.2308484315872192e+00
    phi[7,2]  R1455     2.6121463775634766e+00
    phi[7,2]  R1456     -1.1800391674041748e+00
    phi[7,2]  R1457     1.5402199029922485e+00
    phi[7,2]  R1458     -1.3601590394973755e+00
    phi[7,2]  R1459     2.6271450519561768e+00
    phi[7,2]  R1460     -0.482153058052063
    phi[7,2]  R1461     -2.8904716968536377e+00
    phi[7,2]  R1462     -1.0741604119539261e-01
    phi[7,2]  R1463     -1.7980536445975304e-02
    phi[7,2]  R1464     -1.3092075288295746e-01
    phi[7,2]  R1465     -2.3870782852172852e+00
    phi[7,2]  R1466     6.8550604581832886e-01
    phi[7,2]  R1467     -7.9667592048645020e-01
    phi[7,2]  R1468     2.1459615230560303e-01
    phi[7,2]  R1469     -7.2295659780502319e-01
    phi[7,2]  R1470     -2.2008411884307861e+00
    phi[7,2]  R1471     -2.2994735240936279e+00
    phi[7,2]  R1472     -2.1309275627136230e+00
    phi[7,2]  R1473     -7.9687809944152832e-01
    phi[7,2]  R1474     2.7907836437225342e-01
    phi[7,2]  R1475     -8.8418483734130859e-01
    phi[7,2]  R1476     1.1598582267761230e+00
    phi[7,2]  R1477     1.9396108388900757e+00
    phi[7,2]  R1478     -5.7032382488250732e-01
    phi[7,2]  R1479     -2.4599859714508057e+00
    phi[7,2]  R1480     -1.2117483615875244e+00
    phi[7,2]  R1481     -2.2240478992462158e+00
    phi[7,2]  R1482     -2.0070824623107910e+00
    phi[7,2]  R1483     1.8383126258850098e+00
    phi[7,2]  R1484     -1.2903361320495605e+00
    phi[7,2]  R1485     -1.4911212921142578e+00
    phi[7,2]  R1486     -3.8724322319030762e+00
    phi[7,2]  R1487     1.1478208303451538e+00
    phi[7,2]  R1488     1.2953896522521973e+00
    phi[7,2]  R1489     -2.7801849842071533e+00
    phi[7,2]  R1490     -0.404674768447876
    phi[7,2]  R1491     2.8939750045537949e-02
    phi[7,2]  R1492     1.3138391971588135e+00
    phi[7,2]  R1493     1.1891628503799438e+00
    phi[7,2]  R1494     -0.842751681804657
    phi[7,2]  R1495     -1.8913617134094238e+00
    phi[7,2]  R1496     -7.2160124778747559e-01
    phi[7,2]  R1497     -8.7981241941452026e-01
    phi[7,2]  R1498     -9.8258769512176514e-01
    phi[7,2]  R1499     -3.6123269796371460e-01
    phi[7,2]  R1500     5.0934630632400513e-01
    phi[7,2]  R1501     -1.1067686080932617e+00
    phi[7,2]  R1502     -2.4848613739013672e+00
    phi[7,2]  R1503     1.1282860040664673e+00
    phi[7,2]  R1504     1.5288903377950191e-02
    phi[7,2]  R1505     -0.517637312412262
    phi[7,2]  R1506     -6.2668913602828979e-01
    phi[7,2]  R1507     -1.9982647895812988e+00
    phi[7,2]  R1508     -1.8644151687622070e+00
    phi[7,2]  R1509     2.7569028735160828e-01
    phi[7,2]  R1510     1.8489221334457397e+00
    phi[7,2]  R1511     1.4827425479888916e+00
    phi[7,2]  R1512     -4.3252408504486084e-01
    phi[7,2]  R1513     -2.4905292987823486e+00
    phi[7,2]  R1514     -1.9626625776290894e+00
    phi[7,2]  R1515     -3.2300956249237061e+00
    phi[7,2]  R1516     -2.4864916801452637e+00
    phi[7,2]  R1517     -1.4207725524902344e+00
    phi[7,2]  R1518     2.0508810877799988e-01
    phi[7,2]  R1519     -1.1864368915557861e+00
    phi[7,2]  R1520     1.3411812782287598e+00
    phi[7,2]  R1521     5.0479370355606079e-01
    phi[7,2]  R1522     1.3042377233505249e+00
    phi[7,2]  R1523     2.6819040998816490e-02
    phi[7,2]  R1524     -1.6842150688171387e-01
    phi[7,2]  R1525     1.9785778522491455e+00
    phi[7,2]  R1526     1.2087980508804321e+00
    phi[7,2]  R1527     1.61650550365448
    phi[7,2]  R1528     2.6933724880218506e+00
    phi[7,2]  R1529     1.5383818149566650e+00
    phi[7,2]  R1530     -1.1290540695190430e+00
    phi[7,2]  R1531     -1.4497593641281128e+00
    phi[7,2]  R1532     -1.0711253881454468e+00
    phi[7,2]  R1533     -2.0975923538208008e+00
    phi[7,2]  R1534     -1.6927391290664673e+00
    phi[7,2]  R1535     -1.5782698392868042e+00
    phi[7,2]  R1536     -2.5271096229553223e+00
    phi[7,2]  R1537     -2.4926989078521729e+00
    phi[7,2]  R1538     -2.7118947505950928e+00
    phi[7,2]  R1539     -2.7348563671112061e+00
    phi[7,2]  R1540     -3.6486701965332031e+00
    phi[7,2]  R1541     -2.4000954627990723e+00
    phi[7,2]  R1542     -2.4701709747314453e+00
    phi[7,2]  R1543     -2.01944637298584
    phi[7,2]  R1544     -2.5340330600738525e+00
    phi[7,2]  R1545     -1.34540855884552
    phi[7,2]  R1546     -1.3305389881134033e+00
    phi[7,2]  R1547     -9.2121815681457520e-01
    phi[7,2]  R1548     -1.3872380256652832e+00
    phi[7,2]  R1549     3.8704064488410950e-01
    phi[7,2]  R1550     5.5207714438438416e-02
    phi[7,2]  R1551     -2.7320110797882080e+00
    phi[7,2]  R1552     -1.1515014171600342e+00
    phi[7,2]  R1553     -7.0801854133605957e-01
    phi[7,2]  R1554     -1.8779934644699097e+00
    phi[7,2]  R1555     -0.0931970626115799
    phi[7,2]  R1556     -7.3168873786926270e-01
    phi[7,2]  R1557     -1.7565588951110840e+00
    phi[7,2]  R1558     -1.1734273433685303e+00
    phi[7,2]  R1559     -1.1119202375411987e+00
    phi[7,2]  R1560     -0.941415548324585
    phi[7,2]  R1561     -1.5495136976242065e+00
    phi[7,2]  R1562     -6.6499310731887817e-01
    phi[7,2]  R1563     -7.2379785776138306e-01
    phi[7,2]  R1564     -2.5985779762268066e+00
    phi[7,2]  R1565     1.3108997046947479e-01
    phi[7,2]  R1566     -1.1551762819290161e+00
    phi[7,2]  R1567     -3.6746627092361450e-01
    phi[7,2]  R1568     -3.7078714370727539e-01
    phi[7,2]  R1569     1.0979274511337280e+00
    phi[2,9]  R18       1
    phi[2,9]  R19       1
    phi[2,9]  R20       -9.4460122301227534e-01
    phi[2,9]  R21       -1.4291691576399819e+00
    phi[2,9]  R22       1.1304541663499073e+00
    phi[2,9]  R23       2.0912087166344810e+00
    phi[2,9]  R24       -2.5280964866515778e+00
    phi[2,9]  R25       1.1466629496106244e+00
    phi[2,9]  R26       -1.8064002773600429e+00
    phi[2,9]  R73       -1
    phi[2,9]  R1570     -4.0446011276448441e+00
    phi[2,9]  R1571     -2.1553986816202930e+00
    phi[2,9]  R1572     -3.6691691671767250e+00
    phi[2,9]  R1573     -8.1083085189676130e-01
    phi[2,9]  R1574     -1.9695457382826611e+00
    phi[2,9]  R1575     -4.2304540709824758e+00
    phi[2,9]  R1576     -4.7879121660831681e-01
    phi[2,9]  R1577     -4.6612086498772793e+00
    phi[2,9]  R1578     -5.6280963912841457e+00
    phi[2,9]  R1579     -5.7190341798099054e-01
    phi[2,9]  R1580     -9.4333696455868710e-01
    phi[2,9]  R1581     -3.2366628637799360e+00
    phi[2,9]  R1582     -4.9064001819926109e+00
    phi[2,9]  R1583     -1.2935996272725254e+00
    phi[2,9]  R1584     -9.3617060641432293e-01
    phi[2,9]  R1585     -4.0844640024725132e-01
    phi[2,9]  R1586     -2.3500438715356875e-01
    phi[2,9]  R1587     -7.1914256325579762e-01
    phi[2,9]  R1588     -6.3173129756577528e-01
    phi[2,9]  R1589     -2.6149332314388296e-01
    phi[2,9]  R1590     -2.8540504195164718e-01
    phi[2,9]  R1591     -2.8573114758362816e-01
    phi[2,9]  R1592     -2.9161881072271623e-01
    phi[2,9]  R1593     -3.1116272796805777e-01
    phi[2,9]  R1594     -2.8979531134928949e-01
    phi[2,9]  R1595     -0.296575111305059
    phi[2,9]  R1596     -2.9963553672818510e-01
    phi[2,9]  R1597     -3.0270571105093880e-01
    phi[2,9]  R1598     -3.0627092902344066e-01
    phi[2,9]  R1599     -3.0714790913844592e-01
    phi[2,9]  R1600     -3.0780448446244346e-01
    phi[2,9]  R1601     -3.0963533286086165e-01
    phi[2,9]  R1602     -3.2269190515060542e-01
    phi[2,9]  R1603     -3.8913835508243988e-01
    phi[2,9]  R1604     -3.1882914224593151e-01
    phi[2,9]  R1605     -1.1713899773901688e+00
    phi[2,9]  R1606     -1.7781169904255472e+00
    phi[2,9]  R1607     -1.9674659047641656e+00
    phi[2,9]  R1608     -1.7080066053048717e+00
    phi[2,9]  R1609     -1.2609008674998765e+00
    phi[2,9]  R1610     -6.1773866234380426e-01
    phi[2,9]  R1611     -6.2199528943077520e-01
    phi[2,9]  R1612     -1.5657432772079913e+00
    phi[2,9]  R1613     -6.3517166108438849e-01
    phi[2,9]  R1614     -2.5608201224905841e-01
    phi[2,9]  R1615     -2.8434490505758747e-01
    phi[2,9]  R1616     -1.7682744646730466e+00
    phi[2,9]  R1617     -1.2512013517932987e+00
    phi[2,9]  R1618     -5.1948280830625726e-01
    phi[2,9]  R1619     -2.1975266006599066e+00
    phi[2,9]  R1620     -1.1871444158928881e+00
    phi[2,9]  R1621     -1.5936724015882193e+00
    phi[2,9]  R1622     -1.7629600723865713e+00
    phi[2,9]  R1623     -2.1018521963539971e+00
    phi[2,9]  R1624     -2.7093324622549608e-01
    phi[2,9]  R1625     -1.8783518887346666e+00
    phi[2,9]  R1626     -2.9711266231695621e-01
    phi[2,9]  R1627     -9.1051971740306648e-01
    phi[2,9]  R1628     -1.9396299368768357e+00
    phi[2,9]  R1629     -5.3736777197967811e-01
    phi[2,9]  R1630     -5.6945160834240738e-01
    phi[2,9]  R1631     -5.7204921601638725e-01
    phi[2,9]  R1632     -6.4048277732079339e-01
    phi[2,9]  R1633     -6.8670087415740677e-01
    phi[3,4]  R27       1
    phi[3,4]  R28       1
    phi[3,4]  R36       -1
    phi[3,4]  R1634     -3.0999999046325684e+00
    phi[3,4]  R1635     -3.0999999046325684e+00
    phi[3,4]  R1636     -2.2400000095367432e+00
    phi[3,4]  R1637     -2.2400000095367432e+00
    phi[3,4]  R1638     -3.0999999046325684e+00
    phi[3,4]  R1639     -3.0999999046325684e+00
    phi[3,4]  R1640     -2.5699999332427979e+00
    phi[3,4]  R1641     -2.5699999332427979e+00
    phi[3,4]  R1642     -3.0999999046325684e+00
    phi[3,4]  R1643     -3.0999999046325684e+00
    phi[3,4]  R1644     -2.0899999141693115e+00
    phi[3,4]  R1645     -2.0899999141693115e+00
    phi[3,4]  R1646     -3.0999999046325684e+00
    phi[3,4]  R1647     -3.0999999046325684e+00
    phi[3,4]  R1648     5.9527075290679932e-01
    phi[3,4]  R1649     -1.2242138385772705e+00
    phi[3,4]  R1650     -5.2230614423751831e-01
    phi[3,4]  R1651     2.5616529583930969e-01
    phi[3,4]  R1652     -1.1316685676574707e+00
    phi[3,4]  R1653     -1.3367012143135071e-03
    phi[3,4]  R1654     -3.0023804306983948e-01
    phi[3,4]  R1655     -5.2288264036178589e-01
    phi[3,4]  R1656     0.738461434841156
    phi[3,4]  R1657     0.313499391078949
    phi[3,4]  R1658     4.6208846569061279e-01
    phi[3,4]  R1659     7.1242183446884155e-01
    phi[3,4]  R1660     0.861029863357544
    phi[3,4]  R1661     1.7670917510986328e-01
    phi[3,4]  R1662     4.3525347113609314e-01
    phi[3,4]  R1663     5.8949780464172363e-01
    phi[3,4]  R1664     5.3670644760131836e-01
    phi[3,4]  R1665     -1.4095088839530945e-01
    phi[3,4]  R1666     -1.4175664633512497e-02
    phi[3,4]  R1667     -8.9108355343341827e-02
    phi[3,4]  R1668     -1.7962698936462402e+00
    phi[3,4]  R1669     -1.2218828201293945e+00
    phi[3,4]  R1670     -1.3819094896316528e+00
    phi[3,4]  R1671     -2.1596841812133789e+00
    phi[3,4]  R1672     -1.9297324419021606e+00
    phi[3,4]  R1673     -2.2597465515136719e+00
    phi[3,4]  R1674     -2.6438345909118652e+00
    phi[3,4]  R1675     -1.72129225730896
    phi[3,4]  R1676     -1.1417835950851440e+00
    phi[3,4]  R1677     -2.7227144241333008e+00
    phi[3,4]  R1678     -1.3136377334594727e+00
    phi[3,4]  R1679     -2.1711030602455139e-01
    phi[3,4]  R1680     -1.2693651020526886e-01
    phi[3,4]  R1681     -3.5147583484649658e-01
    phi[3,4]  R1682     -2.8442423343658447e+00
    phi[3,4]  R1683     -1.9939849376678467e+00
    phi[3,4]  R1684     -1.2495437860488892e+00
    phi[3,4]  R1685     -6.8911772966384888e-01
    phi[3,4]  R1686     -1.6764041185379028e+00
    phi[3,4]  R1687     -1.6778661012649536e+00
    phi[3,4]  R1688     -2.9824137687683105e-01
    phi[3,4]  R1689     -8.8157355785369873e-01
    phi[3,4]  R1690     -1.1656290292739868e+00
    phi[3,4]  R1691     9.0937864780426025e-01
    phi[3,4]  R1692     -0.851057767868042
    phi[3,4]  R1693     4.7243535518646240e-02
    phi[3,4]  R1694     5.9957861900329590e-02
    phi[3,4]  R1695     -3.2177748680114746e+00
    phi[3,4]  R1696     -5.5479711294174194e-01
    phi[3,4]  R1697     -4.5398325920104980e+00
    phi[3,4]  R1698     -1.4329981803894043e+00
    phi[3,4]  R1699     -1.5248183012008667e+00
    phi[3,4]  R1700     2.9120454192161560e-01
    phi[3,4]  R1701     -8.6056822538375854e-01
    phi[3,4]  R1702     -2.1684589385986328e+00
    phi[3,4]  R1703     -2.7242195606231689e+00
    phi[3,4]  R1704     -3.2590880393981934e+00
    phi[3,4]  R1705     -2.2550034523010254e+00
    phi[3,4]  R1706     -3.5106179714202881e+00
    phi[3,4]  R1707     -3.5556530952453613e+00
    phi[3,4]  R1708     -7.4543547630310059e-01
    phi[3,4]  R1709     -2.6229693889617920e+00
    phi[3,4]  R1710     -0.424740731716156
    phi[3,4]  R1711     -2.9630592465400696e-01
    phi[3,4]  R1712     -1.2757879495620728e+00
    phi[3,4]  R1713     -1.5019226074218750e+00
    phi[3,4]  R1714     -1.7658958435058594e+00
    phi[3,4]  R1715     -1.3697912693023682e+00
    phi[3,4]  R1716     -1.4962083101272583e+00
    phi[3,4]  R1717     -1.9053051471710205e+00
    phi[3,4]  R1718     -7.8508466482162476e-01
    phi[3,4]  R1719     -5.1997500658035278e-01
    phi[3,4]  R1720     6.4010882377624512e-01
    phi[3,4]  R1721     -4.0571711957454681e-02
    phi[3,4]  R1722     -2.9632845893502235e-02
    phi[3,4]  R1723     1.1813132762908936e+00
    phi[3,4]  R1724     -1.5176676213741302e-01
    phi[3,4]  R1725     -1.7516860961914062e+00
    phi[3,4]  R1726     1.1704502105712891e+00
    phi[3,4]  R1727     -5.9080272912979126e-02
    phi[3,4]  R1728     -1.8483695387840271e-01
    phi[3,4]  R1729     -2.5625308975577354e-02
    phi[3,4]  R1730     -4.5478093624114990e-01
    phi[3,4]  R1731     -3.5632127523422241e-01
    phi[3,4]  R1732     5.4885923862457275e-01
    phi[3,4]  R1733     -1.2570542097091675e+00
    phi[3,4]  R1734     -0.295238733291626
    phi[3,4]  R1735     -1.4434279203414917e+00
    phi[3,4]  R1736     -2.2017064690589905e-01
    phi[3,4]  R1737     1.1756540834903717e-01
    phi[3,4]  R1738     3.1871041655540466e-01
    phi[3,4]  R1739     -1.6698848009109497e+00
    phi[3,4]  R1740     -1.6190886497497559e+00
    phi[3,4]  R1741     -1.7845983505249023e+00
    phi[3,4]  R1742     -2.5907552242279053e+00
    phi[3,4]  R1743     -2.0156347751617432e+00
    phi[3,4]  R1744     -7.3129886388778687e-01
    phi[3,4]  R1745     -1.1050709486007690e+00
    phi[3,4]  R1746     -1.0818986892700195e+00
    phi[3,4]  R1747     -2.27558970451355
    phi[3,4]  R1748     -4.3302237987518311e-01
    phi[3,4]  R1749     -1.4588509798049927e+00
    phi[3,4]  R1750     1.7947022616863251e-01
    phi[3,4]  R1751     1.1154740303754807e-01
    phi[3,4]  R1752     -1.4516246318817139e+00
    phi[3,4]  R1753     -1.5570936203002930e+00
    phi[3,4]  R1754     -7.2951054573059082e-01
    phi[3,4]  R1755     -1.0774593353271484e+00
    phi[3,4]  R1756     -1.3859319686889648e+00
    phi[3,4]  R1757     -2.5347602367401123e+00
    phi[3,4]  R1758     -8.4801310300827026e-01
    phi[3,4]  R1759     -2.8138086199760437e-01
    phi[3,4]  R1760     -1.1965223550796509e+00
    phi[3,4]  R1761     -7.4471610784530640e-01
    phi[3,4]  R1762     -1.9084149599075317e+00
    phi[3,4]  R1763     -1.6722594499588013e+00
    phi[3,4]  R1764     -1.5332285165786743e+00
    phi[3,4]  R1765     -2.7082989215850830e+00
    phi[3,4]  R1766     -1.72310471534729
    phi[3,4]  R1767     -2.9929523468017578e+00
    phi[4,3]  R27       -1
    phi[4,3]  R36       1
    phi[4,3]  R37       1
    phi[4,3]  R1768     -3.0999999046325684e+00
    phi[4,3]  R1769     -3.0999999046325684e+00
    phi[4,3]  R1770     -2.2400000095367432e+00
    phi[4,3]  R1771     -2.2400000095367432e+00
    phi[4,3]  R1772     -3.0999999046325684e+00
    phi[4,3]  R1773     -3.0999999046325684e+00
    phi[4,3]  R1774     -2.5699999332427979e+00
    phi[4,3]  R1775     -2.5699999332427979e+00
    phi[4,3]  R1776     -3.0999999046325684e+00
    phi[4,3]  R1777     -3.0999999046325684e+00
    phi[4,3]  R1778     -2.0899999141693115e+00
    phi[4,3]  R1779     -2.0899999141693115e+00
    phi[4,3]  R1780     -3.0999999046325684e+00
    phi[4,3]  R1781     -3.0999999046325684e+00
    phi[4,3]  R1782     -7.8508466482162476e-01
    phi[4,3]  R1783     -5.1997500658035278e-01
    phi[4,3]  R1784     6.4010882377624512e-01
    phi[4,3]  R1785     -4.0571711957454681e-02
    phi[4,3]  R1786     -2.9632845893502235e-02
    phi[4,3]  R1787     1.1813132762908936e+00
    phi[4,3]  R1788     -1.5176676213741302e-01
    phi[4,3]  R1789     -1.7516860961914062e+00
    phi[4,3]  R1790     1.1704502105712891e+00
    phi[4,3]  R1791     -5.9080272912979126e-02
    phi[4,3]  R1792     -1.8483695387840271e-01
    phi[4,3]  R1793     -2.5625308975577354e-02
    phi[4,3]  R1794     -4.5478093624114990e-01
    phi[4,3]  R1795     -3.5632127523422241e-01
    phi[4,3]  R1796     5.4885923862457275e-01
    phi[4,3]  R1797     -1.2570542097091675e+00
    phi[4,3]  R1798     -0.295238733291626
    phi[4,3]  R1799     -1.4434279203414917e+00
    phi[4,3]  R1800     -2.2017064690589905e-01
    phi[4,3]  R1801     1.1756540834903717e-01
    phi[4,3]  R1802     3.1871041655540466e-01
    phi[4,3]  R1803     -1.6698848009109497e+00
    phi[4,3]  R1804     -1.6190886497497559e+00
    phi[4,3]  R1805     -1.7845983505249023e+00
    phi[4,3]  R1806     -2.5907552242279053e+00
    phi[4,3]  R1807     -2.0156347751617432e+00
    phi[4,3]  R1808     -7.3129886388778687e-01
    phi[4,3]  R1809     -1.1050709486007690e+00
    phi[4,3]  R1810     -1.0818986892700195e+00
    phi[4,3]  R1811     -2.27558970451355
    phi[4,3]  R1812     -4.3302237987518311e-01
    phi[4,3]  R1813     -1.4588509798049927e+00
    phi[4,3]  R1814     1.7947022616863251e-01
    phi[4,3]  R1815     1.1154740303754807e-01
    phi[4,3]  R1816     -1.4516246318817139e+00
    phi[4,3]  R1817     -1.5570936203002930e+00
    phi[4,3]  R1818     -7.2951054573059082e-01
    phi[4,3]  R1819     -1.0774593353271484e+00
    phi[4,3]  R1820     -1.3859319686889648e+00
    phi[4,3]  R1821     -2.5347602367401123e+00
    phi[4,3]  R1822     -8.4801310300827026e-01
    phi[4,3]  R1823     -2.8138086199760437e-01
    phi[4,3]  R1824     -1.1965223550796509e+00
    phi[4,3]  R1825     -7.4471610784530640e-01
    phi[4,3]  R1826     -1.9084149599075317e+00
    phi[4,3]  R1827     -1.6722594499588013e+00
    phi[4,3]  R1828     -1.5332285165786743e+00
    phi[4,3]  R1829     -2.7082989215850830e+00
    phi[4,3]  R1830     -1.72310471534729
    phi[4,3]  R1831     -2.9929523468017578e+00
    phi[4,3]  R1832     5.9527075290679932e-01
    phi[4,3]  R1833     -1.2242138385772705e+00
    phi[4,3]  R1834     -5.2230614423751831e-01
    phi[4,3]  R1835     2.5616529583930969e-01
    phi[4,3]  R1836     -1.1316685676574707e+00
    phi[4,3]  R1837     -1.3367012143135071e-03
    phi[4,3]  R1838     -3.0023804306983948e-01
    phi[4,3]  R1839     -5.2288264036178589e-01
    phi[4,3]  R1840     0.738461434841156
    phi[4,3]  R1841     0.313499391078949
    phi[4,3]  R1842     4.6208846569061279e-01
    phi[4,3]  R1843     7.1242183446884155e-01
    phi[4,3]  R1844     0.861029863357544
    phi[4,3]  R1845     1.7670917510986328e-01
    phi[4,3]  R1846     4.3525347113609314e-01
    phi[4,3]  R1847     5.8949780464172363e-01
    phi[4,3]  R1848     5.3670644760131836e-01
    phi[4,3]  R1849     -1.4095088839530945e-01
    phi[4,3]  R1850     -1.4175664633512497e-02
    phi[4,3]  R1851     -8.9108355343341827e-02
    phi[4,3]  R1852     -1.7962698936462402e+00
    phi[4,3]  R1853     -1.2218828201293945e+00
    phi[4,3]  R1854     -1.3819094896316528e+00
    phi[4,3]  R1855     -2.1596841812133789e+00
    phi[4,3]  R1856     -1.9297324419021606e+00
    phi[4,3]  R1857     -2.2597465515136719e+00
    phi[4,3]  R1858     -2.6438345909118652e+00
    phi[4,3]  R1859     -1.72129225730896
    phi[4,3]  R1860     -1.1417835950851440e+00
    phi[4,3]  R1861     -2.7227144241333008e+00
    phi[4,3]  R1862     -1.3136377334594727e+00
    phi[4,3]  R1863     -2.1711030602455139e-01
    phi[4,3]  R1864     -1.2693651020526886e-01
    phi[4,3]  R1865     -3.5147583484649658e-01
    phi[4,3]  R1866     -2.8442423343658447e+00
    phi[4,3]  R1867     -1.9939849376678467e+00
    phi[4,3]  R1868     -1.2495437860488892e+00
    phi[4,3]  R1869     -6.8911772966384888e-01
    phi[4,3]  R1870     -1.6764041185379028e+00
    phi[4,3]  R1871     -1.6778661012649536e+00
    phi[4,3]  R1872     -2.9824137687683105e-01
    phi[4,3]  R1873     -8.8157355785369873e-01
    phi[4,3]  R1874     -1.1656290292739868e+00
    phi[4,3]  R1875     9.0937864780426025e-01
    phi[4,3]  R1876     -0.851057767868042
    phi[4,3]  R1877     4.7243535518646240e-02
    phi[4,3]  R1878     5.9957861900329590e-02
    phi[4,3]  R1879     -3.2177748680114746e+00
    phi[4,3]  R1880     -5.5479711294174194e-01
    phi[4,3]  R1881     -4.5398325920104980e+00
    phi[4,3]  R1882     -1.4329981803894043e+00
    phi[4,3]  R1883     -1.5248183012008667e+00
    phi[4,3]  R1884     2.9120454192161560e-01
    phi[4,3]  R1885     -8.6056822538375854e-01
    phi[4,3]  R1886     -2.1684589385986328e+00
    phi[4,3]  R1887     -2.7242195606231689e+00
    phi[4,3]  R1888     -3.2590880393981934e+00
    phi[4,3]  R1889     -2.2550034523010254e+00
    phi[4,3]  R1890     -3.5106179714202881e+00
    phi[4,3]  R1891     -3.5556530952453613e+00
    phi[4,3]  R1892     -7.4543547630310059e-01
    phi[4,3]  R1893     -2.6229693889617920e+00
    phi[4,3]  R1894     -0.424740731716156
    phi[4,3]  R1895     -2.9630592465400696e-01
    phi[4,3]  R1896     -1.2757879495620728e+00
    phi[4,3]  R1897     -1.5019226074218750e+00
    phi[4,3]  R1898     -1.7658958435058594e+00
    phi[4,3]  R1899     -1.3697912693023682e+00
    phi[4,3]  R1900     -1.4962083101272583e+00
    phi[4,3]  R1901     -1.9053051471710205e+00
    phi[8,3]  R27       -1
    phi[8,3]  R29       -1.5628191065611610e+00
    phi[8,3]  R30       8.7158482804489124e-01
    phi[8,3]  R31       1.6610267623504416e+00
    phi[8,3]  R32       4.0355834465094942e-01
    phi[8,3]  R33       -2.7933367649454182e+00
    phi[8,3]  R34       -1.5668018520973472e+00
    phi[8,3]  R35       -2.6620762100774162e+00
    phi[8,3]  R72       1
    phi[8,3]  R1902     -1.5371807980714074e+00
    phi[8,3]  R1903     -4.6628190111937293e+00
    phi[8,3]  R1904     -3.1115848375816344e+00
    phi[8,3]  R1905     -1.3684151814918519e+00
    phi[8,3]  R1906     -4.76102666698301
    phi[8,3]  R1907     -1.4389731422821268e+00
    phi[8,3]  R1908     -2.9735582778937473e+00
    phi[8,3]  R1909     -2.1664415885918484e+00
    phi[8,3]  R1910     -3.0666313968715020e-01
    phi[8,3]  R1911     -5.8933366695779865e+00
    phi[8,3]  R1912     -5.2319806207196429e-01
    phi[8,3]  R1913     -3.6568017662666588e+00
    phi[8,3]  R1914     -4.3792369455515212e-01
    phi[8,3]  R1915     -5.7620761147099842e+00
    phi[8,3]  R1916     -1.7030635446384532e+00
    phi[8,3]  R1917     -0.537914113880074
    phi[8,3]  R1918     -1.1043581226380086e+00
    phi[8,3]  R1919     -2.1257144495221159e+00
    phi[8,3]  R1920     -7.2506949040596624e-01
    phi[8,3]  R1921     -1.0206056231198257e+00
    phi[8,3]  R1922     -1.1820813542663049e+00
    phi[8,3]  R1923     -1.3778680780758639e+00
    phi[8,3]  R1924     -1.7804339798315914e+00
    phi[8,3]  R1925     -1.6588715908975904e+00
    phi[8,3]  R1926     -4.8771073478302640e-01
    phi[8,3]  R1927     -4.8832185669614714e-01
    phi[8,3]  R1928     -4.9222851080628871e-01
    phi[8,3]  R1929     -5.0310363775429590e-01
    phi[8,3]  R1930     -5.0403914734099731e-01
    phi[8,3]  R1931     -5.2144746607135328e-01
    phi[8,3]  R1932     -5.3407401600030480e-01
    phi[8,3]  R1933     -5.3929690836311794e-01
    phi[8,3]  R1934     -0.561955246591185
    phi[8,3]  R1935     -0.562243936391835
    phi[8,3]  R1936     -4.6740723019184971e-01
    phi[8,3]  R1937     -6.3220229173077980e-01
    phi[8,3]  R1938     -9.0843066164375541e-01
    phi[8,3]  R1939     -9.0989573641211674e-01
    phi[8,3]  R1940     -9.1579203611419935e-01
    phi[8,3]  R1941     -0.922583031730551
    phi[8,3]  R1942     -9.2397654651949246e-01
    phi[8,3]  R1943     -9.2628505546914686e-01
    phi[8,3]  R1944     -9.3387187611059042e-01
    phi[8,3]  R1945     -9.3918326265018548e-01
    phi[8,3]  R1946     -4.8842706347436160e-01
    phi[8,3]  R1947     -7.6999666351023111e-01
    phi[8,3]  R1948     -1.0340088910884253e+00
    phi[8,3]  R1949     -1.1104345554413779e+00
    phi[8,3]  R1950     -1.1112438520713961e+00
    phi[8,3]  R1951     -1.1210610734337827e+00
    phi[8,3]  R1952     -1.6677106068336127e+00
    phi[8,3]  R1953     -1.9092203874645692e+00
    phi[8,3]  R1954     -1.1589842089609910e+00
    phi[8,3]  R1955     -1.1714217161324503e+00
    phi[8,3]  R1956     -5.5920770319992930e-01
    phi[8,3]  R1957     -5.9259866496189029e-01
    phi[8,3]  R1958     -0.640426509598375
    phi[8,3]  R1959     -6.8669766415880384e-01
    phi[8,3]  R1960     -7.0652467361321158e-01
    phi[8,3]  R1961     -7.3956617828676063e-01
    phi[8,3]  R1962     -1.0467243611950656e+00
    phi[8,3]  R1963     -1.0507292918986257e+00
    phi[8,3]  R1964     -1.0786089111265484e+00
    phi[8,3]  R1965     -1.1317824258170588e+00
    phi[8,3]  R1966     -6.7339102908851278e-01
    phi[8,3]  R1967     -6.8453413963907284e-01
    phi[8,3]  R1968     -7.3845263837586117e-01
    phi[8,3]  R1969     -7.6904312036090872e-01
    phi[8,3]  R1970     -9.7158045753103850e-01
    phi[8,3]  R1971     -0.989692232900969
    phi[8,3]  R1972     -9.9499202930561426e-01
    phi[8,3]  R1973     -1.0075532027364824e+00
    phi[8,3]  R1974     -1.0226434273232625e+00
    phi[8,3]  R1975     -1.0257102458718586e+00
    phi[8,3]  R1976     -5.4192441747711562e-01
    phi[8,3]  R1977     -5.4545096485481182e-01
    phi[8,3]  R1978     -5.8742711398606862e-01
    phi[8,3]  R1979     -8.2755202002282713e-01
    phi[8,3]  R1980     -0.951918622363023
    phi[8,3]  R1981     -1.1473121249016249e+00
    phi[8,3]  R1982     -1.1679646043301295e+00
    phi[8,3]  R1983     -1.2638295548684901e+00
    phi[8,3]  R1984     -1.2644116087386794e+00
    phi[8,3]  R1985     -1.6389603654977543e+00
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R1986     -3.0999999046325684e+00
    phi[4,5]  R1987     -3.0999999046325684e+00
    phi[4,5]  R1988     -2.2400000095367432e+00
    phi[4,5]  R1989     -2.2400000095367432e+00
    phi[4,5]  R1990     -3.0999999046325684e+00
    phi[4,5]  R1991     -3.0999999046325684e+00
    phi[4,5]  R1992     -2.5699999332427979e+00
    phi[4,5]  R1993     -2.5699999332427979e+00
    phi[4,5]  R1994     -3.0999999046325684e+00
    phi[4,5]  R1995     -3.0999999046325684e+00
    phi[4,5]  R1996     -2.0899999141693115e+00
    phi[4,5]  R1997     -2.0899999141693115e+00
    phi[4,5]  R1998     -3.0999999046325684e+00
    phi[4,5]  R1999     -3.0999999046325684e+00
    phi[4,5]  R2000     -7.8508466482162476e-01
    phi[4,5]  R2001     -5.1997500658035278e-01
    phi[4,5]  R2002     6.4010882377624512e-01
    phi[4,5]  R2003     -4.0571711957454681e-02
    phi[4,5]  R2004     -2.9632845893502235e-02
    phi[4,5]  R2005     1.1813132762908936e+00
    phi[4,5]  R2006     -1.5176676213741302e-01
    phi[4,5]  R2007     -1.7516860961914062e+00
    phi[4,5]  R2008     1.1704502105712891e+00
    phi[4,5]  R2009     -5.9080272912979126e-02
    phi[4,5]  R2010     -1.8483695387840271e-01
    phi[4,5]  R2011     -2.5625308975577354e-02
    phi[4,5]  R2012     -4.5478093624114990e-01
    phi[4,5]  R2013     -3.5632127523422241e-01
    phi[4,5]  R2014     5.4885923862457275e-01
    phi[4,5]  R2015     -1.2570542097091675e+00
    phi[4,5]  R2016     -0.295238733291626
    phi[4,5]  R2017     -1.4434279203414917e+00
    phi[4,5]  R2018     -2.2017064690589905e-01
    phi[4,5]  R2019     1.1756540834903717e-01
    phi[4,5]  R2020     3.1871041655540466e-01
    phi[4,5]  R2021     -1.6698848009109497e+00
    phi[4,5]  R2022     -1.6190886497497559e+00
    phi[4,5]  R2023     -1.7845983505249023e+00
    phi[4,5]  R2024     -2.5907552242279053e+00
    phi[4,5]  R2025     -2.0156347751617432e+00
    phi[4,5]  R2026     -7.3129886388778687e-01
    phi[4,5]  R2027     -1.1050709486007690e+00
    phi[4,5]  R2028     -1.0818986892700195e+00
    phi[4,5]  R2029     -2.27558970451355
    phi[4,5]  R2030     -4.3302237987518311e-01
    phi[4,5]  R2031     -1.4588509798049927e+00
    phi[4,5]  R2032     1.7947022616863251e-01
    phi[4,5]  R2033     1.1154740303754807e-01
    phi[4,5]  R2034     -1.4516246318817139e+00
    phi[4,5]  R2035     -1.5570936203002930e+00
    phi[4,5]  R2036     -7.2951054573059082e-01
    phi[4,5]  R2037     -1.0774593353271484e+00
    phi[4,5]  R2038     -1.3859319686889648e+00
    phi[4,5]  R2039     -2.5347602367401123e+00
    phi[4,5]  R2040     -8.4801310300827026e-01
    phi[4,5]  R2041     -2.8138086199760437e-01
    phi[4,5]  R2042     -1.1965223550796509e+00
    phi[4,5]  R2043     -7.4471610784530640e-01
    phi[4,5]  R2044     -1.9084149599075317e+00
    phi[4,5]  R2045     -1.6722594499588013e+00
    phi[4,5]  R2046     -1.5332285165786743e+00
    phi[4,5]  R2047     -2.7082989215850830e+00
    phi[4,5]  R2048     -1.72310471534729
    phi[4,5]  R2049     -2.9929523468017578e+00
    phi[4,5]  R2050     3.4386795014142990e-02
    phi[4,5]  R2051     -0.62140953540802
    phi[4,5]  R2052     -3.7470346689224243e-01
    phi[4,5]  R2053     -4.9196749925613403e-01
    phi[4,5]  R2054     -7.1503426879644394e-03
    phi[4,5]  R2055     -1.4194753170013428e+00
    phi[4,5]  R2056     4.3751189112663269e-01
    phi[4,5]  R2057     -5.5792808532714844e-01
    phi[4,5]  R2058     8.3608680963516235e-01
    phi[4,5]  R2059     2.7456194162368774e-01
    phi[4,5]  R2060     -8.4476906061172485e-01
    phi[4,5]  R2061     -1.4108133316040039e+00
    phi[4,5]  R2062     -7.7097469568252563e-01
    phi[4,5]  R2063     -1.3429486751556396e-01
    phi[4,5]  R2064     -7.6471495628356934e-01
    phi[4,5]  R2065     -4.8342508077621460e-01
    phi[4,5]  R2066     -9.5141971111297607e-01
    phi[4,5]  R2067     -1.4694503545761108e+00
    phi[4,5]  R2068     -1.3129730224609375e+00
    phi[4,5]  R2069     -6.1131179332733154e-01
    phi[4,5]  R2070     -5.7475298643112183e-01
    phi[4,5]  R2071     -0.0602109432220459
    phi[4,5]  R2072     -2.0045632123947144e-01
    phi[4,5]  R2073     3.5689070820808411e-01
    phi[4,5]  R2074     9.6928042173385620e-01
    phi[4,5]  R2075     -9.9091672897338867e-01
    phi[4,5]  R2076     -1.3292185068130493e+00
    phi[4,5]  R2077     -7.8927302360534668e-01
    phi[4,5]  R2078     -9.9628305435180664e-01
    phi[4,5]  R2079     -1.4922291040420532e+00
    phi[4,5]  R2080     -4.5100271701812744e-02
    phi[4,5]  R2081     -3.2245662808418274e-01
    phi[4,5]  R2082     -5.9130573272705078e-01
    phi[4,5]  R2083     0.323188453912735
    phi[4,5]  R2084     -7.5393432378768921e-01
    phi[4,5]  R2085     -1.9086773693561554e-01
    phi[4,5]  R2086     -0.544402539730072
    phi[4,5]  R2087     -2.0832555294036865e+00
    phi[4,5]  R2088     -4.5927613973617554e-02
    phi[4,5]  R2089     -1.6103824377059937e+00
    phi[4,5]  R2090     0.0961042195558548
    phi[4,5]  R2091     -4.7840368747711182e-01
    phi[4,5]  R2092     6.9385856389999390e-01
    phi[4,5]  R2093     -2.2398479282855988e-01
    phi[4,5]  R2094     7.9571940004825592e-02
    phi[4,5]  R2095     2.4791909754276276e-01
    phi[4,5]  R2096     -8.8429886102676392e-01
    phi[4,5]  R2097     -9.0032309293746948e-01
    phi[4,5]  R2098     -6.0442274808883667e-01
    phi[4,5]  R2099     -2.5431082248687744e+00
    phi[4,5]  R2100     -4.5384001731872559e-01
    phi[4,5]  R2101     9.9865108728408813e-01
    phi[4,5]  R2102     -2.6034954190254211e-01
    phi[4,5]  R2103     -1.1987470388412476e+00
    phi[4,5]  R2104     -2.1423285007476807e+00
    phi[4,5]  R2105     -2.0626258850097656e+00
    phi[4,5]  R2106     -2.3136346340179443e+00
    phi[4,5]  R2107     -5.6574237346649170e-01
    phi[4,5]  R2108     -1.9238525629043579e+00
    phi[4,5]  R2109     -2.6541097164154053e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2110     -3.0999999046325684e+00
    phi[5,4]  R2111     -3.0999999046325684e+00
    phi[5,4]  R2112     -2.2400000095367432e+00
    phi[5,4]  R2113     -2.2400000095367432e+00
    phi[5,4]  R2114     -3.0999999046325684e+00
    phi[5,4]  R2115     -3.0999999046325684e+00
    phi[5,4]  R2116     -2.5699999332427979e+00
    phi[5,4]  R2117     -2.5699999332427979e+00
    phi[5,4]  R2118     -3.0999999046325684e+00
    phi[5,4]  R2119     -3.0999999046325684e+00
    phi[5,4]  R2120     -2.0899999141693115e+00
    phi[5,4]  R2121     -2.0899999141693115e+00
    phi[5,4]  R2122     -3.0999999046325684e+00
    phi[5,4]  R2123     -3.0999999046325684e+00
    phi[5,4]  R2124     3.4386795014142990e-02
    phi[5,4]  R2125     -0.62140953540802
    phi[5,4]  R2126     -3.7470346689224243e-01
    phi[5,4]  R2127     -4.9196749925613403e-01
    phi[5,4]  R2128     -7.1503426879644394e-03
    phi[5,4]  R2129     -1.4194753170013428e+00
    phi[5,4]  R2130     4.3751189112663269e-01
    phi[5,4]  R2131     -5.5792808532714844e-01
    phi[5,4]  R2132     8.3608680963516235e-01
    phi[5,4]  R2133     2.7456194162368774e-01
    phi[5,4]  R2134     -8.4476906061172485e-01
    phi[5,4]  R2135     -1.4108133316040039e+00
    phi[5,4]  R2136     -7.7097469568252563e-01
    phi[5,4]  R2137     -1.3429486751556396e-01
    phi[5,4]  R2138     -7.6471495628356934e-01
    phi[5,4]  R2139     -4.8342508077621460e-01
    phi[5,4]  R2140     -9.5141971111297607e-01
    phi[5,4]  R2141     -1.4694503545761108e+00
    phi[5,4]  R2142     -1.3129730224609375e+00
    phi[5,4]  R2143     -6.1131179332733154e-01
    phi[5,4]  R2144     -5.7475298643112183e-01
    phi[5,4]  R2145     -0.0602109432220459
    phi[5,4]  R2146     -2.0045632123947144e-01
    phi[5,4]  R2147     3.5689070820808411e-01
    phi[5,4]  R2148     9.6928042173385620e-01
    phi[5,4]  R2149     -9.9091672897338867e-01
    phi[5,4]  R2150     -1.3292185068130493e+00
    phi[5,4]  R2151     -7.8927302360534668e-01
    phi[5,4]  R2152     -9.9628305435180664e-01
    phi[5,4]  R2153     -1.4922291040420532e+00
    phi[5,4]  R2154     -4.5100271701812744e-02
    phi[5,4]  R2155     -3.2245662808418274e-01
    phi[5,4]  R2156     -5.9130573272705078e-01
    phi[5,4]  R2157     0.323188453912735
    phi[5,4]  R2158     -7.5393432378768921e-01
    phi[5,4]  R2159     -1.9086773693561554e-01
    phi[5,4]  R2160     -0.544402539730072
    phi[5,4]  R2161     -2.0832555294036865e+00
    phi[5,4]  R2162     -4.5927613973617554e-02
    phi[5,4]  R2163     -1.6103824377059937e+00
    phi[5,4]  R2164     0.0961042195558548
    phi[5,4]  R2165     -4.7840368747711182e-01
    phi[5,4]  R2166     6.9385856389999390e-01
    phi[5,4]  R2167     -2.2398479282855988e-01
    phi[5,4]  R2168     7.9571940004825592e-02
    phi[5,4]  R2169     2.4791909754276276e-01
    phi[5,4]  R2170     -8.8429886102676392e-01
    phi[5,4]  R2171     -9.0032309293746948e-01
    phi[5,4]  R2172     -6.0442274808883667e-01
    phi[5,4]  R2173     -2.5431082248687744e+00
    phi[5,4]  R2174     -4.5384001731872559e-01
    phi[5,4]  R2175     9.9865108728408813e-01
    phi[5,4]  R2176     -2.6034954190254211e-01
    phi[5,4]  R2177     -1.1987470388412476e+00
    phi[5,4]  R2178     -2.1423285007476807e+00
    phi[5,4]  R2179     -2.0626258850097656e+00
    phi[5,4]  R2180     -2.3136346340179443e+00
    phi[5,4]  R2181     -5.6574237346649170e-01
    phi[5,4]  R2182     -1.9238525629043579e+00
    phi[5,4]  R2183     -2.6541097164154053e+00
    phi[5,4]  R2184     -7.8508466482162476e-01
    phi[5,4]  R2185     -5.1997500658035278e-01
    phi[5,4]  R2186     6.4010882377624512e-01
    phi[5,4]  R2187     -4.0571711957454681e-02
    phi[5,4]  R2188     -2.9632845893502235e-02
    phi[5,4]  R2189     1.1813132762908936e+00
    phi[5,4]  R2190     -1.5176676213741302e-01
    phi[5,4]  R2191     -1.7516860961914062e+00
    phi[5,4]  R2192     1.1704502105712891e+00
    phi[5,4]  R2193     -5.9080272912979126e-02
    phi[5,4]  R2194     -1.8483695387840271e-01
    phi[5,4]  R2195     -2.5625308975577354e-02
    phi[5,4]  R2196     -4.5478093624114990e-01
    phi[5,4]  R2197     -3.5632127523422241e-01
    phi[5,4]  R2198     5.4885923862457275e-01
    phi[5,4]  R2199     -1.2570542097091675e+00
    phi[5,4]  R2200     -0.295238733291626
    phi[5,4]  R2201     -1.4434279203414917e+00
    phi[5,4]  R2202     -2.2017064690589905e-01
    phi[5,4]  R2203     1.1756540834903717e-01
    phi[5,4]  R2204     3.1871041655540466e-01
    phi[5,4]  R2205     -1.6698848009109497e+00
    phi[5,4]  R2206     -1.6190886497497559e+00
    phi[5,4]  R2207     -1.7845983505249023e+00
    phi[5,4]  R2208     -2.5907552242279053e+00
    phi[5,4]  R2209     -2.0156347751617432e+00
    phi[5,4]  R2210     -7.3129886388778687e-01
    phi[5,4]  R2211     -1.1050709486007690e+00
    phi[5,4]  R2212     -1.0818986892700195e+00
    phi[5,4]  R2213     -2.27558970451355
    phi[5,4]  R2214     -4.3302237987518311e-01
    phi[5,4]  R2215     -1.4588509798049927e+00
    phi[5,4]  R2216     1.7947022616863251e-01
    phi[5,4]  R2217     1.1154740303754807e-01
    phi[5,4]  R2218     -1.4516246318817139e+00
    phi[5,4]  R2219     -1.5570936203002930e+00
    phi[5,4]  R2220     -7.2951054573059082e-01
    phi[5,4]  R2221     -1.0774593353271484e+00
    phi[5,4]  R2222     -1.3859319686889648e+00
    phi[5,4]  R2223     -2.5347602367401123e+00
    phi[5,4]  R2224     -8.4801310300827026e-01
    phi[5,4]  R2225     -2.8138086199760437e-01
    phi[5,4]  R2226     -1.1965223550796509e+00
    phi[5,4]  R2227     -7.4471610784530640e-01
    phi[5,4]  R2228     -1.9084149599075317e+00
    phi[5,4]  R2229     -1.6722594499588013e+00
    phi[5,4]  R2230     -1.5332285165786743e+00
    phi[5,4]  R2231     -2.7082989215850830e+00
    phi[5,4]  R2232     -1.72310471534729
    phi[5,4]  R2233     -2.9929523468017578e+00
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2234     -3.0999999046325684e+00
    phi[5,6]  R2235     -3.0999999046325684e+00
    phi[5,6]  R2236     -2.2400000095367432e+00
    phi[5,6]  R2237     -2.2400000095367432e+00
    phi[5,6]  R2238     -3.0999999046325684e+00
    phi[5,6]  R2239     -3.0999999046325684e+00
    phi[5,6]  R2240     -2.5699999332427979e+00
    phi[5,6]  R2241     -2.5699999332427979e+00
    phi[5,6]  R2242     -3.0999999046325684e+00
    phi[5,6]  R2243     -3.0999999046325684e+00
    phi[5,6]  R2244     -2.0899999141693115e+00
    phi[5,6]  R2245     -2.0899999141693115e+00
    phi[5,6]  R2246     -3.0999999046325684e+00
    phi[5,6]  R2247     -3.0999999046325684e+00
    phi[5,6]  R2248     3.4386795014142990e-02
    phi[5,6]  R2249     -0.62140953540802
    phi[5,6]  R2250     -3.7470346689224243e-01
    phi[5,6]  R2251     -4.9196749925613403e-01
    phi[5,6]  R2252     -7.1503426879644394e-03
    phi[5,6]  R2253     -1.4194753170013428e+00
    phi[5,6]  R2254     4.3751189112663269e-01
    phi[5,6]  R2255     -5.5792808532714844e-01
    phi[5,6]  R2256     8.3608680963516235e-01
    phi[5,6]  R2257     2.7456194162368774e-01
    phi[5,6]  R2258     -8.4476906061172485e-01
    phi[5,6]  R2259     -1.4108133316040039e+00
    phi[5,6]  R2260     -7.7097469568252563e-01
    phi[5,6]  R2261     -1.3429486751556396e-01
    phi[5,6]  R2262     -7.6471495628356934e-01
    phi[5,6]  R2263     -4.8342508077621460e-01
    phi[5,6]  R2264     -9.5141971111297607e-01
    phi[5,6]  R2265     -1.4694503545761108e+00
    phi[5,6]  R2266     -1.3129730224609375e+00
    phi[5,6]  R2267     -6.1131179332733154e-01
    phi[5,6]  R2268     -5.7475298643112183e-01
    phi[5,6]  R2269     -0.0602109432220459
    phi[5,6]  R2270     -2.0045632123947144e-01
    phi[5,6]  R2271     3.5689070820808411e-01
    phi[5,6]  R2272     9.6928042173385620e-01
    phi[5,6]  R2273     -9.9091672897338867e-01
    phi[5,6]  R2274     -1.3292185068130493e+00
    phi[5,6]  R2275     -7.8927302360534668e-01
    phi[5,6]  R2276     -9.9628305435180664e-01
    phi[5,6]  R2277     -1.4922291040420532e+00
    phi[5,6]  R2278     -4.5100271701812744e-02
    phi[5,6]  R2279     -3.2245662808418274e-01
    phi[5,6]  R2280     -5.9130573272705078e-01
    phi[5,6]  R2281     0.323188453912735
    phi[5,6]  R2282     -7.5393432378768921e-01
    phi[5,6]  R2283     -1.9086773693561554e-01
    phi[5,6]  R2284     -0.544402539730072
    phi[5,6]  R2285     -2.0832555294036865e+00
    phi[5,6]  R2286     -4.5927613973617554e-02
    phi[5,6]  R2287     -1.6103824377059937e+00
    phi[5,6]  R2288     0.0961042195558548
    phi[5,6]  R2289     -4.7840368747711182e-01
    phi[5,6]  R2290     6.9385856389999390e-01
    phi[5,6]  R2291     -2.2398479282855988e-01
    phi[5,6]  R2292     7.9571940004825592e-02
    phi[5,6]  R2293     2.4791909754276276e-01
    phi[5,6]  R2294     -8.8429886102676392e-01
    phi[5,6]  R2295     -9.0032309293746948e-01
    phi[5,6]  R2296     -6.0442274808883667e-01
    phi[5,6]  R2297     -2.5431082248687744e+00
    phi[5,6]  R2298     -4.5384001731872559e-01
    phi[5,6]  R2299     9.9865108728408813e-01
    phi[5,6]  R2300     -2.6034954190254211e-01
    phi[5,6]  R2301     -1.1987470388412476e+00
    phi[5,6]  R2302     -2.1423285007476807e+00
    phi[5,6]  R2303     -2.0626258850097656e+00
    phi[5,6]  R2304     -2.3136346340179443e+00
    phi[5,6]  R2305     -5.6574237346649170e-01
    phi[5,6]  R2306     -1.9238525629043579e+00
    phi[5,6]  R2307     -2.6541097164154053e+00
    phi[5,6]  R2308     8.7495046854019165e-01
    phi[5,6]  R2309     2.5037071108818054e-01
    phi[5,6]  R2310     9.6400880813598633e-01
    phi[5,6]  R2311     -0.683203399181366
    phi[5,6]  R2312     -4.3127548694610596e-01
    phi[5,6]  R2313     -4.1872116923332214e-01
    phi[5,6]  R2314     -2.5344082713127136e-01
    phi[5,6]  R2315     5.6889337301254272e-01
    phi[5,6]  R2316     -0.0974901095032692
    phi[5,6]  R2317     1.6245014965534210e-01
    phi[5,6]  R2318     -6.9860112667083740e-01
    phi[5,6]  R2319     -7.5105029344558716e-01
    phi[5,6]  R2320     3.8314312696456909e-01
    phi[5,6]  R2321     -7.9122078418731689e-01
    phi[5,6]  R2322     -7.8868812322616577e-01
    phi[5,6]  R2323     -2.7147397398948669e-01
    phi[5,6]  R2324     -4.5832499861717224e-02
    phi[5,6]  R2325     -1.2700741291046143e+00
    phi[5,6]  R2326     6.6759502887725830e-01
    phi[5,6]  R2327     -1.8772035837173462e-01
    phi[5,6]  R2328     -1.6135376691818237e+00
    phi[5,6]  R2329     -1.0463728904724121e+00
    phi[5,6]  R2330     -1.0189625024795532e+00
    phi[5,6]  R2331     -0.934546172618866
    phi[5,6]  R2332     -1.5581166744232178e+00
    phi[5,6]  R2333     -1.0969597101211548e+00
    phi[5,6]  R2334     -1.8437557220458984e+00
    phi[5,6]  R2335     -1.5544735193252563e+00
    phi[5,6]  R2336     -2.4562385082244873e+00
    phi[5,6]  R2337     -6.5518438816070557e-01
    phi[5,6]  R2338     -7.4301064014434814e-01
    phi[5,6]  R2339     -7.4649810791015625e-01
    phi[5,6]  R2340     7.5020968914031982e-01
    phi[5,6]  R2341     -1.1850737333297729e+00
    phi[5,6]  R2342     1.2056404352188110e+00
    phi[5,6]  R2343     -3.8494008779525757e-01
    phi[5,6]  R2344     -2.1036255359649658e+00
    phi[5,6]  R2345     8.2493638992309570e-01
    phi[5,6]  R2346     9.3966341018676758e-01
    phi[5,6]  R2347     -1.2300194501876831e+00
    phi[5,6]  R2348     -5.7208657264709473e-01
    phi[5,6]  R2349     -9.0483617782592773e-01
    phi[5,6]  R2350     -1.2728774547576904e+00
    phi[5,6]  R2351     -1.1681164503097534e+00
    phi[5,6]  R2352     -4.6655675768852234e-01
    phi[5,6]  R2353     -7.1714675426483154e-01
    phi[5,6]  R2354     2.3341160267591476e-03
    phi[5,6]  R2355     -3.7110872566699982e-02
    phi[5,6]  R2356     7.8503608703613281e-01
    phi[5,6]  R2357     -1.1091300249099731e+00
    phi[5,6]  R2358     -9.4535386562347412e-01
    phi[5,6]  R2359     -2.2036793231964111e+00
    phi[5,6]  R2360     -1.0869821310043335e+00
    phi[5,6]  R2361     -1.5344493389129639e+00
    phi[5,6]  R2362     -1.3530472517013550e+00
    phi[5,6]  R2363     -1.9872808456420898e+00
    phi[5,6]  R2364     -2.5382058620452881e+00
    phi[5,6]  R2365     1.0747820138931274e+00
    phi[5,6]  R2366     -2.1947214603424072e+00
    phi[5,6]  R2367     -2.4837484359741211e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2368     -3.0999999046325684e+00
    phi[6,5]  R2369     -3.0999999046325684e+00
    phi[6,5]  R2370     -2.2400000095367432e+00
    phi[6,5]  R2371     -2.2400000095367432e+00
    phi[6,5]  R2372     -3.0999999046325684e+00
    phi[6,5]  R2373     -3.0999999046325684e+00
    phi[6,5]  R2374     -2.5699999332427979e+00
    phi[6,5]  R2375     -2.5699999332427979e+00
    phi[6,5]  R2376     -3.0999999046325684e+00
    phi[6,5]  R2377     -3.0999999046325684e+00
    phi[6,5]  R2378     -2.0899999141693115e+00
    phi[6,5]  R2379     -2.0899999141693115e+00
    phi[6,5]  R2380     -3.0999999046325684e+00
    phi[6,5]  R2381     -3.0999999046325684e+00
    phi[6,5]  R2382     8.7495046854019165e-01
    phi[6,5]  R2383     2.5037071108818054e-01
    phi[6,5]  R2384     9.6400880813598633e-01
    phi[6,5]  R2385     -0.683203399181366
    phi[6,5]  R2386     -4.3127548694610596e-01
    phi[6,5]  R2387     -4.1872116923332214e-01
    phi[6,5]  R2388     -2.5344082713127136e-01
    phi[6,5]  R2389     5.6889337301254272e-01
    phi[6,5]  R2390     -0.0974901095032692
    phi[6,5]  R2391     1.6245014965534210e-01
    phi[6,5]  R2392     -6.9860112667083740e-01
    phi[6,5]  R2393     -7.5105029344558716e-01
    phi[6,5]  R2394     3.8314312696456909e-01
    phi[6,5]  R2395     -7.9122078418731689e-01
    phi[6,5]  R2396     -7.8868812322616577e-01
    phi[6,5]  R2397     -2.7147397398948669e-01
    phi[6,5]  R2398     -4.5832499861717224e-02
    phi[6,5]  R2399     -1.2700741291046143e+00
    phi[6,5]  R2400     6.6759502887725830e-01
    phi[6,5]  R2401     -1.8772035837173462e-01
    phi[6,5]  R2402     -1.6135376691818237e+00
    phi[6,5]  R2403     -1.0463728904724121e+00
    phi[6,5]  R2404     -1.0189625024795532e+00
    phi[6,5]  R2405     -0.934546172618866
    phi[6,5]  R2406     -1.5581166744232178e+00
    phi[6,5]  R2407     -1.0969597101211548e+00
    phi[6,5]  R2408     -1.8437557220458984e+00
    phi[6,5]  R2409     -1.5544735193252563e+00
    phi[6,5]  R2410     -2.4562385082244873e+00
    phi[6,5]  R2411     -6.5518438816070557e-01
    phi[6,5]  R2412     -7.4301064014434814e-01
    phi[6,5]  R2413     -7.4649810791015625e-01
    phi[6,5]  R2414     7.5020968914031982e-01
    phi[6,5]  R2415     -1.1850737333297729e+00
    phi[6,5]  R2416     1.2056404352188110e+00
    phi[6,5]  R2417     -3.8494008779525757e-01
    phi[6,5]  R2418     -2.1036255359649658e+00
    phi[6,5]  R2419     8.2493638992309570e-01
    phi[6,5]  R2420     9.3966341018676758e-01
    phi[6,5]  R2421     -1.2300194501876831e+00
    phi[6,5]  R2422     -5.7208657264709473e-01
    phi[6,5]  R2423     -9.0483617782592773e-01
    phi[6,5]  R2424     -1.2728774547576904e+00
    phi[6,5]  R2425     -1.1681164503097534e+00
    phi[6,5]  R2426     -4.6655675768852234e-01
    phi[6,5]  R2427     -7.1714675426483154e-01
    phi[6,5]  R2428     2.3341160267591476e-03
    phi[6,5]  R2429     -3.7110872566699982e-02
    phi[6,5]  R2430     7.8503608703613281e-01
    phi[6,5]  R2431     -1.1091300249099731e+00
    phi[6,5]  R2432     -9.4535386562347412e-01
    phi[6,5]  R2433     -2.2036793231964111e+00
    phi[6,5]  R2434     -1.0869821310043335e+00
    phi[6,5]  R2435     -1.5344493389129639e+00
    phi[6,5]  R2436     -1.3530472517013550e+00
    phi[6,5]  R2437     -1.9872808456420898e+00
    phi[6,5]  R2438     -2.5382058620452881e+00
    phi[6,5]  R2439     1.0747820138931274e+00
    phi[6,5]  R2440     -2.1947214603424072e+00
    phi[6,5]  R2441     -2.4837484359741211e+00
    phi[6,5]  R2442     3.4386795014142990e-02
    phi[6,5]  R2443     -0.62140953540802
    phi[6,5]  R2444     -3.7470346689224243e-01
    phi[6,5]  R2445     -4.9196749925613403e-01
    phi[6,5]  R2446     -7.1503426879644394e-03
    phi[6,5]  R2447     -1.4194753170013428e+00
    phi[6,5]  R2448     4.3751189112663269e-01
    phi[6,5]  R2449     -5.5792808532714844e-01
    phi[6,5]  R2450     8.3608680963516235e-01
    phi[6,5]  R2451     2.7456194162368774e-01
    phi[6,5]  R2452     -8.4476906061172485e-01
    phi[6,5]  R2453     -1.4108133316040039e+00
    phi[6,5]  R2454     -7.7097469568252563e-01
    phi[6,5]  R2455     -1.3429486751556396e-01
    phi[6,5]  R2456     -7.6471495628356934e-01
    phi[6,5]  R2457     -4.8342508077621460e-01
    phi[6,5]  R2458     -9.5141971111297607e-01
    phi[6,5]  R2459     -1.4694503545761108e+00
    phi[6,5]  R2460     -1.3129730224609375e+00
    phi[6,5]  R2461     -6.1131179332733154e-01
    phi[6,5]  R2462     -5.7475298643112183e-01
    phi[6,5]  R2463     -0.0602109432220459
    phi[6,5]  R2464     -2.0045632123947144e-01
    phi[6,5]  R2465     3.5689070820808411e-01
    phi[6,5]  R2466     9.6928042173385620e-01
    phi[6,5]  R2467     -9.9091672897338867e-01
    phi[6,5]  R2468     -1.3292185068130493e+00
    phi[6,5]  R2469     -7.8927302360534668e-01
    phi[6,5]  R2470     -9.9628305435180664e-01
    phi[6,5]  R2471     -1.4922291040420532e+00
    phi[6,5]  R2472     -4.5100271701812744e-02
    phi[6,5]  R2473     -3.2245662808418274e-01
    phi[6,5]  R2474     -5.9130573272705078e-01
    phi[6,5]  R2475     0.323188453912735
    phi[6,5]  R2476     -7.5393432378768921e-01
    phi[6,5]  R2477     -1.9086773693561554e-01
    phi[6,5]  R2478     -0.544402539730072
    phi[6,5]  R2479     -2.0832555294036865e+00
    phi[6,5]  R2480     -4.5927613973617554e-02
    phi[6,5]  R2481     -1.6103824377059937e+00
    phi[6,5]  R2482     0.0961042195558548
    phi[6,5]  R2483     -4.7840368747711182e-01
    phi[6,5]  R2484     6.9385856389999390e-01
    phi[6,5]  R2485     -2.2398479282855988e-01
    phi[6,5]  R2486     7.9571940004825592e-02
    phi[6,5]  R2487     2.4791909754276276e-01
    phi[6,5]  R2488     -8.8429886102676392e-01
    phi[6,5]  R2489     -9.0032309293746948e-01
    phi[6,5]  R2490     -6.0442274808883667e-01
    phi[6,5]  R2491     -2.5431082248687744e+00
    phi[6,5]  R2492     -4.5384001731872559e-01
    phi[6,5]  R2493     9.9865108728408813e-01
    phi[6,5]  R2494     -2.6034954190254211e-01
    phi[6,5]  R2495     -1.1987470388412476e+00
    phi[6,5]  R2496     -2.1423285007476807e+00
    phi[6,5]  R2497     -2.0626258850097656e+00
    phi[6,5]  R2498     -2.3136346340179443e+00
    phi[6,5]  R2499     -5.6574237346649170e-01
    phi[6,5]  R2500     -1.9238525629043579e+00
    phi[6,5]  R2501     -2.6541097164154053e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2502     -3.0999999046325684e+00
    phi[6,7]  R2503     -3.0999999046325684e+00
    phi[6,7]  R2504     -2.2400000095367432e+00
    phi[6,7]  R2505     -2.2400000095367432e+00
    phi[6,7]  R2506     -3.0999999046325684e+00
    phi[6,7]  R2507     -3.0999999046325684e+00
    phi[6,7]  R2508     -2.5699999332427979e+00
    phi[6,7]  R2509     -2.5699999332427979e+00
    phi[6,7]  R2510     -3.0999999046325684e+00
    phi[6,7]  R2511     -3.0999999046325684e+00
    phi[6,7]  R2512     -2.0899999141693115e+00
    phi[6,7]  R2513     -2.0899999141693115e+00
    phi[6,7]  R2514     -3.0999999046325684e+00
    phi[6,7]  R2515     -3.0999999046325684e+00
    phi[6,7]  R2516     8.7495046854019165e-01
    phi[6,7]  R2517     2.5037071108818054e-01
    phi[6,7]  R2518     9.6400880813598633e-01
    phi[6,7]  R2519     -0.683203399181366
    phi[6,7]  R2520     -4.3127548694610596e-01
    phi[6,7]  R2521     -4.1872116923332214e-01
    phi[6,7]  R2522     -2.5344082713127136e-01
    phi[6,7]  R2523     5.6889337301254272e-01
    phi[6,7]  R2524     -0.0974901095032692
    phi[6,7]  R2525     1.6245014965534210e-01
    phi[6,7]  R2526     -6.9860112667083740e-01
    phi[6,7]  R2527     -7.5105029344558716e-01
    phi[6,7]  R2528     3.8314312696456909e-01
    phi[6,7]  R2529     -7.9122078418731689e-01
    phi[6,7]  R2530     -7.8868812322616577e-01
    phi[6,7]  R2531     -2.7147397398948669e-01
    phi[6,7]  R2532     -4.5832499861717224e-02
    phi[6,7]  R2533     -1.2700741291046143e+00
    phi[6,7]  R2534     6.6759502887725830e-01
    phi[6,7]  R2535     -1.8772035837173462e-01
    phi[6,7]  R2536     -1.6135376691818237e+00
    phi[6,7]  R2537     -1.0463728904724121e+00
    phi[6,7]  R2538     -1.0189625024795532e+00
    phi[6,7]  R2539     -0.934546172618866
    phi[6,7]  R2540     -1.5581166744232178e+00
    phi[6,7]  R2541     -1.0969597101211548e+00
    phi[6,7]  R2542     -1.8437557220458984e+00
    phi[6,7]  R2543     -1.5544735193252563e+00
    phi[6,7]  R2544     -2.4562385082244873e+00
    phi[6,7]  R2545     -6.5518438816070557e-01
    phi[6,7]  R2546     -7.4301064014434814e-01
    phi[6,7]  R2547     -7.4649810791015625e-01
    phi[6,7]  R2548     7.5020968914031982e-01
    phi[6,7]  R2549     -1.1850737333297729e+00
    phi[6,7]  R2550     1.2056404352188110e+00
    phi[6,7]  R2551     -3.8494008779525757e-01
    phi[6,7]  R2552     -2.1036255359649658e+00
    phi[6,7]  R2553     8.2493638992309570e-01
    phi[6,7]  R2554     9.3966341018676758e-01
    phi[6,7]  R2555     -1.2300194501876831e+00
    phi[6,7]  R2556     -5.7208657264709473e-01
    phi[6,7]  R2557     -9.0483617782592773e-01
    phi[6,7]  R2558     -1.2728774547576904e+00
    phi[6,7]  R2559     -1.1681164503097534e+00
    phi[6,7]  R2560     -4.6655675768852234e-01
    phi[6,7]  R2561     -7.1714675426483154e-01
    phi[6,7]  R2562     2.3341160267591476e-03
    phi[6,7]  R2563     -3.7110872566699982e-02
    phi[6,7]  R2564     7.8503608703613281e-01
    phi[6,7]  R2565     -1.1091300249099731e+00
    phi[6,7]  R2566     -9.4535386562347412e-01
    phi[6,7]  R2567     -2.2036793231964111e+00
    phi[6,7]  R2568     -1.0869821310043335e+00
    phi[6,7]  R2569     -1.5344493389129639e+00
    phi[6,7]  R2570     -1.3530472517013550e+00
    phi[6,7]  R2571     -1.9872808456420898e+00
    phi[6,7]  R2572     -2.5382058620452881e+00
    phi[6,7]  R2573     1.0747820138931274e+00
    phi[6,7]  R2574     -2.1947214603424072e+00
    phi[6,7]  R2575     -2.4837484359741211e+00
    phi[6,7]  R2576     2.1144406795501709e+00
    phi[6,7]  R2577     1.9792606830596924e+00
    phi[6,7]  R2578     1.6833561658859253e+00
    phi[6,7]  R2579     1.2780048847198486e+00
    phi[6,7]  R2580     1.2308484315872192e+00
    phi[6,7]  R2581     2.6121463775634766e+00
    phi[6,7]  R2582     -1.1800391674041748e+00
    phi[6,7]  R2583     1.5402199029922485e+00
    phi[6,7]  R2584     -1.3601590394973755e+00
    phi[6,7]  R2585     2.6271450519561768e+00
    phi[6,7]  R2586     -0.482153058052063
    phi[6,7]  R2587     -2.8904716968536377e+00
    phi[6,7]  R2588     -1.0741604119539261e-01
    phi[6,7]  R2589     -1.7980536445975304e-02
    phi[6,7]  R2590     -1.3092075288295746e-01
    phi[6,7]  R2591     -2.3870782852172852e+00
    phi[6,7]  R2592     6.8550604581832886e-01
    phi[6,7]  R2593     -7.9667592048645020e-01
    phi[6,7]  R2594     2.1459615230560303e-01
    phi[6,7]  R2595     -7.2295659780502319e-01
    phi[6,7]  R2596     -2.2008411884307861e+00
    phi[6,7]  R2597     -2.2994735240936279e+00
    phi[6,7]  R2598     -2.1309275627136230e+00
    phi[6,7]  R2599     -7.9687809944152832e-01
    phi[6,7]  R2600     2.7907836437225342e-01
    phi[6,7]  R2601     -8.8418483734130859e-01
    phi[6,7]  R2602     1.1598582267761230e+00
    phi[6,7]  R2603     1.9396108388900757e+00
    phi[6,7]  R2604     -5.7032382488250732e-01
    phi[6,7]  R2605     -2.4599859714508057e+00
    phi[6,7]  R2606     -1.2117483615875244e+00
    phi[6,7]  R2607     -2.2240478992462158e+00
    phi[6,7]  R2608     -2.0070824623107910e+00
    phi[6,7]  R2609     1.8383126258850098e+00
    phi[6,7]  R2610     -1.2903361320495605e+00
    phi[6,7]  R2611     -1.4911212921142578e+00
    phi[6,7]  R2612     -3.8724322319030762e+00
    phi[6,7]  R2613     1.1478208303451538e+00
    phi[6,7]  R2614     1.2953896522521973e+00
    phi[6,7]  R2615     -2.7801849842071533e+00
    phi[6,7]  R2616     -0.404674768447876
    phi[6,7]  R2617     2.8939750045537949e-02
    phi[6,7]  R2618     1.3138391971588135e+00
    phi[6,7]  R2619     1.1891628503799438e+00
    phi[6,7]  R2620     -0.842751681804657
    phi[6,7]  R2621     -1.8913617134094238e+00
    phi[6,7]  R2622     -7.2160124778747559e-01
    phi[6,7]  R2623     -8.7981241941452026e-01
    phi[6,7]  R2624     -9.8258769512176514e-01
    phi[6,7]  R2625     -3.6123269796371460e-01
    phi[6,7]  R2626     5.0934630632400513e-01
    phi[6,7]  R2627     -1.1067686080932617e+00
    phi[6,7]  R2628     -2.4848613739013672e+00
    phi[6,7]  R2629     1.1282860040664673e+00
    phi[6,7]  R2630     1.5288903377950191e-02
    phi[6,7]  R2631     -0.517637312412262
    phi[6,7]  R2632     -6.2668913602828979e-01
    phi[6,7]  R2633     -1.9982647895812988e+00
    phi[6,7]  R2634     -1.8644151687622070e+00
    phi[6,7]  R2635     2.7569028735160828e-01
    phi[6,7]  R2636     1.8489221334457397e+00
    phi[6,7]  R2637     1.4827425479888916e+00
    phi[6,7]  R2638     -4.3252408504486084e-01
    phi[6,7]  R2639     -2.4905292987823486e+00
    phi[6,7]  R2640     -1.9626625776290894e+00
    phi[6,7]  R2641     -3.2300956249237061e+00
    phi[6,7]  R2642     -2.4864916801452637e+00
    phi[6,7]  R2643     -1.4207725524902344e+00
    phi[6,7]  R2644     2.0508810877799988e-01
    phi[6,7]  R2645     -1.1864368915557861e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2646     -3.0999999046325684e+00
    phi[7,6]  R2647     -3.0999999046325684e+00
    phi[7,6]  R2648     -2.2400000095367432e+00
    phi[7,6]  R2649     -2.2400000095367432e+00
    phi[7,6]  R2650     -3.0999999046325684e+00
    phi[7,6]  R2651     -3.0999999046325684e+00
    phi[7,6]  R2652     -2.5699999332427979e+00
    phi[7,6]  R2653     -2.5699999332427979e+00
    phi[7,6]  R2654     -3.0999999046325684e+00
    phi[7,6]  R2655     -3.0999999046325684e+00
    phi[7,6]  R2656     -2.0899999141693115e+00
    phi[7,6]  R2657     -2.0899999141693115e+00
    phi[7,6]  R2658     -3.0999999046325684e+00
    phi[7,6]  R2659     -3.0999999046325684e+00
    phi[7,6]  R2660     2.1144406795501709e+00
    phi[7,6]  R2661     1.9792606830596924e+00
    phi[7,6]  R2662     1.6833561658859253e+00
    phi[7,6]  R2663     1.2780048847198486e+00
    phi[7,6]  R2664     1.2308484315872192e+00
    phi[7,6]  R2665     2.6121463775634766e+00
    phi[7,6]  R2666     -1.1800391674041748e+00
    phi[7,6]  R2667     1.5402199029922485e+00
    phi[7,6]  R2668     -1.3601590394973755e+00
    phi[7,6]  R2669     2.6271450519561768e+00
    phi[7,6]  R2670     -0.482153058052063
    phi[7,6]  R2671     -2.8904716968536377e+00
    phi[7,6]  R2672     -1.0741604119539261e-01
    phi[7,6]  R2673     -1.7980536445975304e-02
    phi[7,6]  R2674     -1.3092075288295746e-01
    phi[7,6]  R2675     -2.3870782852172852e+00
    phi[7,6]  R2676     6.8550604581832886e-01
    phi[7,6]  R2677     -7.9667592048645020e-01
    phi[7,6]  R2678     2.1459615230560303e-01
    phi[7,6]  R2679     -7.2295659780502319e-01
    phi[7,6]  R2680     -2.2008411884307861e+00
    phi[7,6]  R2681     -2.2994735240936279e+00
    phi[7,6]  R2682     -2.1309275627136230e+00
    phi[7,6]  R2683     -7.9687809944152832e-01
    phi[7,6]  R2684     2.7907836437225342e-01
    phi[7,6]  R2685     -8.8418483734130859e-01
    phi[7,6]  R2686     1.1598582267761230e+00
    phi[7,6]  R2687     1.9396108388900757e+00
    phi[7,6]  R2688     -5.7032382488250732e-01
    phi[7,6]  R2689     -2.4599859714508057e+00
    phi[7,6]  R2690     -1.2117483615875244e+00
    phi[7,6]  R2691     -2.2240478992462158e+00
    phi[7,6]  R2692     -2.0070824623107910e+00
    phi[7,6]  R2693     1.8383126258850098e+00
    phi[7,6]  R2694     -1.2903361320495605e+00
    phi[7,6]  R2695     -1.4911212921142578e+00
    phi[7,6]  R2696     -3.8724322319030762e+00
    phi[7,6]  R2697     1.1478208303451538e+00
    phi[7,6]  R2698     1.2953896522521973e+00
    phi[7,6]  R2699     -2.7801849842071533e+00
    phi[7,6]  R2700     -0.404674768447876
    phi[7,6]  R2701     2.8939750045537949e-02
    phi[7,6]  R2702     1.3138391971588135e+00
    phi[7,6]  R2703     1.1891628503799438e+00
    phi[7,6]  R2704     -0.842751681804657
    phi[7,6]  R2705     -1.8913617134094238e+00
    phi[7,6]  R2706     -7.2160124778747559e-01
    phi[7,6]  R2707     -8.7981241941452026e-01
    phi[7,6]  R2708     -9.8258769512176514e-01
    phi[7,6]  R2709     -3.6123269796371460e-01
    phi[7,6]  R2710     5.0934630632400513e-01
    phi[7,6]  R2711     -1.1067686080932617e+00
    phi[7,6]  R2712     -2.4848613739013672e+00
    phi[7,6]  R2713     1.1282860040664673e+00
    phi[7,6]  R2714     1.5288903377950191e-02
    phi[7,6]  R2715     -0.517637312412262
    phi[7,6]  R2716     -6.2668913602828979e-01
    phi[7,6]  R2717     -1.9982647895812988e+00
    phi[7,6]  R2718     -1.8644151687622070e+00
    phi[7,6]  R2719     2.7569028735160828e-01
    phi[7,6]  R2720     1.8489221334457397e+00
    phi[7,6]  R2721     1.4827425479888916e+00
    phi[7,6]  R2722     -4.3252408504486084e-01
    phi[7,6]  R2723     -2.4905292987823486e+00
    phi[7,6]  R2724     -1.9626625776290894e+00
    phi[7,6]  R2725     -3.2300956249237061e+00
    phi[7,6]  R2726     -2.4864916801452637e+00
    phi[7,6]  R2727     -1.4207725524902344e+00
    phi[7,6]  R2728     2.0508810877799988e-01
    phi[7,6]  R2729     -1.1864368915557861e+00
    phi[7,6]  R2730     8.7495046854019165e-01
    phi[7,6]  R2731     2.5037071108818054e-01
    phi[7,6]  R2732     9.6400880813598633e-01
    phi[7,6]  R2733     -0.683203399181366
    phi[7,6]  R2734     -4.3127548694610596e-01
    phi[7,6]  R2735     -4.1872116923332214e-01
    phi[7,6]  R2736     -2.5344082713127136e-01
    phi[7,6]  R2737     5.6889337301254272e-01
    phi[7,6]  R2738     -0.0974901095032692
    phi[7,6]  R2739     1.6245014965534210e-01
    phi[7,6]  R2740     -6.9860112667083740e-01
    phi[7,6]  R2741     -7.5105029344558716e-01
    phi[7,6]  R2742     3.8314312696456909e-01
    phi[7,6]  R2743     -7.9122078418731689e-01
    phi[7,6]  R2744     -7.8868812322616577e-01
    phi[7,6]  R2745     -2.7147397398948669e-01
    phi[7,6]  R2746     -4.5832499861717224e-02
    phi[7,6]  R2747     -1.2700741291046143e+00
    phi[7,6]  R2748     6.6759502887725830e-01
    phi[7,6]  R2749     -1.8772035837173462e-01
    phi[7,6]  R2750     -1.6135376691818237e+00
    phi[7,6]  R2751     -1.0463728904724121e+00
    phi[7,6]  R2752     -1.0189625024795532e+00
    phi[7,6]  R2753     -0.934546172618866
    phi[7,6]  R2754     -1.5581166744232178e+00
    phi[7,6]  R2755     -1.0969597101211548e+00
    phi[7,6]  R2756     -1.8437557220458984e+00
    phi[7,6]  R2757     -1.5544735193252563e+00
    phi[7,6]  R2758     -2.4562385082244873e+00
    phi[7,6]  R2759     -6.5518438816070557e-01
    phi[7,6]  R2760     -7.4301064014434814e-01
    phi[7,6]  R2761     -7.4649810791015625e-01
    phi[7,6]  R2762     7.5020968914031982e-01
    phi[7,6]  R2763     -1.1850737333297729e+00
    phi[7,6]  R2764     1.2056404352188110e+00
    phi[7,6]  R2765     -3.8494008779525757e-01
    phi[7,6]  R2766     -2.1036255359649658e+00
    phi[7,6]  R2767     8.2493638992309570e-01
    phi[7,6]  R2768     9.3966341018676758e-01
    phi[7,6]  R2769     -1.2300194501876831e+00
    phi[7,6]  R2770     -5.7208657264709473e-01
    phi[7,6]  R2771     -9.0483617782592773e-01
    phi[7,6]  R2772     -1.2728774547576904e+00
    phi[7,6]  R2773     -1.1681164503097534e+00
    phi[7,6]  R2774     -4.6655675768852234e-01
    phi[7,6]  R2775     -7.1714675426483154e-01
    phi[7,6]  R2776     2.3341160267591476e-03
    phi[7,6]  R2777     -3.7110872566699982e-02
    phi[7,6]  R2778     7.8503608703613281e-01
    phi[7,6]  R2779     -1.1091300249099731e+00
    phi[7,6]  R2780     -9.4535386562347412e-01
    phi[7,6]  R2781     -2.2036793231964111e+00
    phi[7,6]  R2782     -1.0869821310043335e+00
    phi[7,6]  R2783     -1.5344493389129639e+00
    phi[7,6]  R2784     -1.3530472517013550e+00
    phi[7,6]  R2785     -1.9872808456420898e+00
    phi[7,6]  R2786     -2.5382058620452881e+00
    phi[7,6]  R2787     1.0747820138931274e+00
    phi[7,6]  R2788     -2.1947214603424072e+00
    phi[7,6]  R2789     -2.4837484359741211e+00
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       -9.4460122301227534e-01
    phi[7,9]  R66       -1.4291691576399819e+00
    phi[7,9]  R67       1.1304541663499073e+00
    phi[7,9]  R68       2.0912087166344810e+00
    phi[7,9]  R69       -2.5280964866515778e+00
    phi[7,9]  R70       1.1466629496106244e+00
    phi[7,9]  R71       -1.8064002773600429e+00
    phi[7,9]  R73       -1
    phi[7,9]  R2790     -4.0446011276448441e+00
    phi[7,9]  R2791     -2.1553986816202930e+00
    phi[7,9]  R2792     -3.6691691671767250e+00
    phi[7,9]  R2793     -8.1083085189676130e-01
    phi[7,9]  R2794     -1.9695457382826611e+00
    phi[7,9]  R2795     -4.2304540709824758e+00
    phi[7,9]  R2796     -4.7879121660831681e-01
    phi[7,9]  R2797     -4.6612086498772793e+00
    phi[7,9]  R2798     -5.6280963912841457e+00
    phi[7,9]  R2799     -5.7190341798099054e-01
    phi[7,9]  R2800     -9.4333696455868710e-01
    phi[7,9]  R2801     -3.2366628637799360e+00
    phi[7,9]  R2802     -4.9064001819926109e+00
    phi[7,9]  R2803     -1.2935996272725254e+00
    phi[7,9]  R2804     -2.6307505189358560e-01
    phi[7,9]  R2805     -2.6491307195702163e-01
    phi[7,9]  R2806     -2.7230346064407041e-01
    phi[7,9]  R2807     -2.7620990587496541e-01
    phi[7,9]  R2808     -2.8037459835769662e-01
    phi[7,9]  R2809     -2.8520031606294083e-01
    phi[7,9]  R2810     -2.8595501505357113e-01
    phi[7,9]  R2811     -2.8673243208436472e-01
    phi[7,9]  R2812     -2.9896914714524225e-01
    phi[7,9]  R2813     -3.0252621204897823e-01
    phi[7,9]  R2814     -5.8439001429829318e-01
    phi[7,9]  R2815     -5.8641545685563390e-01
    phi[7,9]  R2816     -6.0438691061887040e-01
    phi[7,9]  R2817     -6.0860968636049761e-01
    phi[7,9]  R2818     -6.1744928183496706e-01
    phi[7,9]  R2819     -6.4254755729358237e-01
    phi[7,9]  R2820     -6.6104532498967816e-01
    phi[7,9]  R2821     -6.7769121213423555e-01
    phi[7,9]  R2822     -6.7993058149753471e-01
    phi[7,9]  R2823     -6.8298233772613715e-01
    phi[7,9]  R2824     -3.6811309342733223e-01
    phi[7,9]  R2825     -3.7240435225397039e-01
    phi[7,9]  R2826     -4.5413696263570857e-01
    phi[7,9]  R2827     -4.7757722134414948e-01
    phi[7,9]  R2828     -4.8103062114230033e-01
    phi[7,9]  R2829     -4.8181422304445243e-01
    phi[7,9]  R2830     -4.8835297953468038e-01
    phi[7,9]  R2831     -8.4469811836976039e-01
    phi[7,9]  R2832     -6.5590570786075686e-01
    phi[7,9]  R2833     -7.0123197083670252e-01
    phi[7,9]  R2834     -3.1307926061510516e-01
    phi[7,9]  R2835     -3.2936606936578183e-01
    phi[7,9]  R2836     -3.4688819562379170e-01
    phi[7,9]  R2837     -3.7621196162690218e-01
    phi[7,9]  R2838     -3.9120755663527140e-01
    phi[7,9]  R2839     -4.0215327046301685e-01
    phi[7,9]  R2840     -4.1621179362785554e-01
    phi[7,9]  R2841     -0.426793284116606
    phi[7,9]  R2842     -6.4353611600966132e-01
    phi[7,9]  R2843     -6.5474057228687510e-01
    phi[7,9]  R2844     -3.6879322934562864e-01
    phi[7,9]  R2845     -5.3973860508810656e-01
    phi[7,9]  R2846     -6.2931814717445755e-01
    phi[7,9]  R2847     -6.6013961797356036e-01
    phi[7,9]  R2848     -6.8215446327386209e-01
    phi[7,9]  R2849     -6.9065175815762259e-01
    phi[7,9]  R2850     -7.0258446389160067e-01
    phi[7,9]  R2851     -7.0355412593913524e-01
    phi[7,9]  R2852     -7.1550086699276583e-01
    phi[7,9]  R2853     -7.3009291930922660e-01
    phi[7,9]  R2854     -3.4873582006379966e-01
    phi[7,9]  R2855     -4.4384966118810221e-01
    phi[7,9]  R2856     -4.8630391923892669e-01
    phi[7,9]  R2857     -6.3853904217757806e-01
    phi[7,9]  R2858     -6.4926602897288777e-01
    phi[7,9]  R2859     -6.8361457559788907e-01
    phi[7,9]  R2860     -6.9321334364480836e-01
    phi[7,9]  R2861     -7.0383330325030458e-01
    phi[7,9]  R2862     -7.0693770082780638e-01
    phi[7,9]  R2863     -7.4950622069013972e-01
    phi[7,9]  R2864     -4.2618174802179709e-01
    phi[7,9]  R2865     -5.1812492629078477e-01
    phi[7,9]  R2866     -6.7264533805874649e-01
    phi[7,9]  R2867     -6.8703188646235969e-01
    phi[7,9]  R2868     -1.0092721790414956e+00
    phi[7,9]  R2869     -8.4651453130559018e-01
    phi[7,9]  R2870     -8.6845539607735933e-01
    phi[7,9]  R2871     -1.4657106801330591e+00
    phi[7,9]  R2872     -1.3912216992918347e+00
    phi[7,9]  R2873     -1.2131626938214586e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       5.8140856027603149e-01
    z[0,1,0]  R89       -1.9250120222568512e-01
    z[0,1,0]  R90       5.9856560081243515e-02
    z[0,1,0]  R91       -4.9915939569473267e-02
    z[0,1,0]  R92       -3.6315965652465820e-01
    z[0,1,0]  R93       5.3551656007766724e-01
    z[0,1,0]  R94       3.1531623005867004e-01
    z[0,1,0]  R95       -2.2023370862007141e-01
    z[0,1,0]  R96       2.2594654560089111e-01
    z[0,1,0]  R97       0.123531773686409
    z[0,1,0]  R98       1.8905134499073029e-01
    z[0,1,0]  R99       -2.6604864001274109e-01
    z[0,1,0]  R100      -1.4337065815925598e-01
    z[0,1,0]  R101      -3.0445605516433716e-01
    z[0,1,0]  R102      -3.7949305772781372e-01
    z[0,1,0]  R103      -3.9805746078491211e-01
    z[0,1,0]  R104      -3.2808291912078857e-01
    z[0,1,0]  R105      -2.6863589882850647e-01
    z[0,1,0]  R106      -3.7944170832633972e-01
    z[0,1,0]  R107      -3.1133583188056946e-01
    z[0,1,0]  R108      -5.1333421468734741e-01
    z[0,1,0]  R109      3.9979004859924316e-01
    z[0,1,0]  R110      -0.0194241926074028
    z[0,1,0]  R111      2.9889246821403503e-01
    z[0,1,0]  R112      -4.0776455402374268e-01
    z[0,1,0]  R113      1.8535171449184418e-01
    z[0,1,0]  R114      -7.6386652654036880e-04
    z[0,1,0]  R115      2.3205760121345520e-01
    z[0,1,0]  R116      -0.0546276830136776
    z[0,1,0]  R117      9.5886774361133575e-02
    z[0,1,0]  R118      -7.5755953788757324e-01
    z[0,1,0]  R119      6.1774069070816040e-01
    z[0,1,0]  R120      -3.3967691659927368e-01
    z[0,1,0]  R121      -7.4591761827468872e-01
    z[0,1,0]  R122      -6.3562631607055664e-01
    z[0,1,0]  R123      -6.7685276269912720e-01
    z[0,1,0]  R124      -7.6198214292526245e-01
    z[0,1,0]  R125      1.2019499391317368e-01
    z[0,1,0]  R126      0.0736149400472641
    z[0,1,0]  R127      -1.8352362513542175e-01
    z[0,1,0]  R128      -2.1915476024150848e-01
    z[0,1,0]  R129      2.4370449781417847e-01
    z[0,1,0]  R130      -3.2098489999771118e-01
    z[0,1,0]  R131      3.3063909411430359e-01
    z[0,1,0]  R132      1.8062606453895569e-01
    z[0,1,0]  R133      -1.9695401191711426e-02
    z[0,1,0]  R134      -2.9621289577335119e-03
    z[0,1,0]  R135      1.9050359725952148e-01
    z[0,1,0]  R136      0.629289448261261
    z[0,1,0]  R137      4.6556234359741211e-02
    z[0,1,0]  R138      -3.0931890010833740e-02
    z[0,1,0]  R139      2.0336858928203583e-02
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       2.2264511883258820e-01
    z[0,1,1]  R89       1.6231055557727814e-01
    z[0,1,1]  R90       1.1129427701234818e-01
    z[0,1,1]  R91       6.8842776119709015e-02
    z[0,1,1]  R92       -1.0296688415110111e-02
    z[0,1,1]  R93       -7.9762744903564453e-01
    z[0,1,1]  R94       -8.2727664709091187e-01
    z[0,1,1]  R95       -6.1877506971359253e-01
    z[0,1,1]  R96       -5.4082858562469482e-01
    z[0,1,1]  R97       2.2063447535037994e-01
    z[0,1,1]  R98       2.8825476765632629e-01
    z[0,1,1]  R99       6.5079480409622192e-01
    z[0,1,1]  R100      6.5550971031188965e-01
    z[0,1,1]  R101      0.504782497882843
    z[0,1,1]  R102      5.9593433141708374e-01
    z[0,1,1]  R103      7.0695358514785767e-01
    z[0,1,1]  R104      5.6116998195648193e-01
    z[0,1,1]  R105      2.5891184806823730e-01
    z[0,1,1]  R106      3.4656202793121338e-01
    z[0,1,1]  R107      4.3070918321609497e-01
    z[0,1,1]  R108      4.3959498405456543e-01
    z[0,1,1]  R109      -3.9317718148231506e-01
    z[0,1,1]  R110      -0.618119478225708
    z[0,1,1]  R111      -2.8242516517639160e-01
    z[0,1,1]  R112      -3.9775301702320576e-03
    z[0,1,1]  R113      -8.8265210390090942e-01
    z[0,1,1]  R114      -4.8212072253227234e-01
    z[0,1,1]  R115      -8.5552811622619629e-01
    z[0,1,1]  R116      -2.3137611150741577e-01
    z[0,1,1]  R117      -7.6621663570404053e-01
    z[0,1,1]  R118      8.1886142492294312e-02
    z[0,1,1]  R119      9.7055546939373016e-02
    z[0,1,1]  R120      1.2865361571311951e-01
    z[0,1,1]  R121      6.0638375580310822e-02
    z[0,1,1]  R122      5.5151361972093582e-02
    z[0,1,1]  R123      -4.3803101778030396e-01
    z[0,1,1]  R124      -5.0843238830566406e-01
    z[0,1,1]  R125      -7.6586097478866577e-01
    z[0,1,1]  R126      -6.9656598567962646e-01
    z[0,1,1]  R127      -0.386089026927948
    z[0,1,1]  R128      8.7825745344161987e-01
    z[0,1,1]  R129      0.83925461769104
    z[0,1,1]  R130      6.3452881574630737e-01
    z[0,1,1]  R131      1.6306184232234955e-01
    z[0,1,1]  R132      -8.0407577753067017e-01
    z[0,1,1]  R133      -6.3214516639709473e-01
    z[0,1,1]  R134      -4.4627717137336731e-01
    z[0,1,1]  R135      1.5261571109294891e-01
    z[0,1,1]  R136      0.0878714844584465
    z[0,1,1]  R137      -8.7257444858551025e-01
    z[0,1,1]  R138      -8.7358325719833374e-01
    z[0,1,1]  R139      -5.4689502716064453e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       -3.2770600914955139e-01
    z[0,1,2]  R89       -6.7050859332084656e-02
    z[0,1,2]  R90       -5.1336042582988739e-02
    z[0,1,2]  R91       -8.1323289871215820e-01
    z[0,1,2]  R92       1.1117040365934372e-01
    z[0,1,2]  R93       6.7289404571056366e-02
    z[0,1,2]  R94       -3.7855041027069092e-01
    z[0,1,2]  R95       1.3529086112976074e-01
    z[0,1,2]  R96       2.1808530390262604e-01
    z[0,1,2]  R97       5.0742077827453613e-01
    z[0,1,2]  R98       6.6660559177398682e-01
    z[0,1,2]  R99       1.3948100805282593e-01
    z[0,1,2]  R100      -4.5719772577285767e-01
    z[0,1,2]  R101      -2.4878266453742981e-01
    z[0,1,2]  R102      -2.1776770055294037e-01
    z[0,1,2]  R103      -3.2101023197174072e-01
    z[0,1,2]  R104      -3.1241452693939209e-01
    z[0,1,2]  R105      -2.9116892814636230e-01
    z[0,1,2]  R106      -5.6948333978652954e-01
    z[0,1,2]  R107      -7.1742653846740723e-01
    z[0,1,2]  R108      2.8313699364662170e-01
    z[0,1,2]  R109      -3.8030885625630617e-03
    z[0,1,2]  R110      1.9267649948596954e-01
    z[0,1,2]  R111      4.2524451017379761e-01
    z[0,1,2]  R112      1.6295653581619263e-01
    z[0,1,2]  R113      4.6793825924396515e-02
    z[0,1,2]  R114      2.1531592309474945e-01
    z[0,1,2]  R115      -4.7669090330600739e-02
    z[0,1,2]  R116      1.0567907989025116e-01
    z[0,1,2]  R117      -0.103363998234272
    z[0,1,2]  R118      2.1614845097064972e-01
    z[0,1,2]  R119      -7.2414785623550415e-02
    z[0,1,2]  R120      1.6746085882186890e-01
    z[0,1,2]  R121      -0.552842915058136
    z[0,1,2]  R122      -6.1426943540573120e-01
    z[0,1,2]  R123      1.5637424588203430e-01
    z[0,1,2]  R124      1.4649611711502075e-01
    z[0,1,2]  R125      5.8397012948989868e-01
    z[0,1,2]  R126      6.7283588647842407e-01
    z[0,1,2]  R127      7.0392948389053345e-01
    z[0,1,2]  R128      1.3838779926300049e-01
    z[0,1,2]  R129      -5.0884738564491272e-02
    z[0,1,2]  R130      2.9170921072363853e-02
    z[0,1,2]  R131      -4.9306163191795349e-01
    z[0,1,2]  R132      -3.4111782908439636e-01
    z[0,1,2]  R133      -4.5788824558258057e-01
    z[0,1,2]  R134      -0.519756555557251
    z[0,1,2]  R135      -2.6853203773498535e-01
    z[0,1,2]  R136      5.8138924837112427e-01
    z[0,1,2]  R137      -2.0634530484676361e-01
    z[0,1,2]  R138      -3.3708235621452332e-01
    z[0,1,2]  R139      -3.9220988750457764e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       2.7934342622756958e-01
    z[0,1,3]  R89       -8.4370121359825134e-02
    z[0,1,3]  R90       -8.4217202663421631e-01
    z[0,1,3]  R91       -6.1375718563795090e-02
    z[0,1,3]  R92       1.5079474449157715e-01
    z[0,1,3]  R93       1.8788080662488937e-02
    z[0,1,3]  R94       -2.0441633462905884e-01
    z[0,1,3]  R95       7.2195190191268921e-01
    z[0,1,3]  R96       4.6824315190315247e-01
    z[0,1,3]  R97       7.0662492513656616e-01
    z[0,1,3]  R98       -2.9991081357002258e-01
    z[0,1,3]  R99       6.6542893648147583e-01
    z[0,1,3]  R100      2.3609901964664459e-01
    z[0,1,3]  R101      -3.6476698517799377e-01
    z[0,1,3]  R102      -4.5867305994033813e-01
    z[0,1,3]  R103      -3.0604410171508789e-01
    z[0,1,3]  R104      -6.4286214113235474e-01
    z[0,1,3]  R105      -4.8425009846687317e-01
    z[0,1,3]  R106      -7.2110451757907867e-02
    z[0,1,3]  R107      -2.3390905559062958e-01
    z[0,1,3]  R108      -2.8752577304840088e-01
    z[0,1,3]  R109      6.7420721054077148e-01
    z[0,1,3]  R110      4.7530794143676758e-01
    z[0,1,3]  R111      0.771931529045105
    z[0,1,3]  R112      -4.4618120789527893e-01
    z[0,1,3]  R113      -3.6692906171083450e-02
    z[0,1,3]  R114      4.5206043124198914e-01
    z[0,1,3]  R115      -1.7114739120006561e-01
    z[0,1,3]  R116      8.5708844661712646e-01
    z[0,1,3]  R117      -1.7338600754737854e-01
    z[0,1,3]  R118      -4.0729328989982605e-01
    z[0,1,3]  R119      5.4033064842224121e-01
    z[0,1,3]  R120      -4.8166982829570770e-02
    z[0,1,3]  R121      2.7853947877883911e-01
    z[0,1,3]  R122      -6.4410172402858734e-02
    z[0,1,3]  R123      -3.2127812504768372e-01
    z[0,1,3]  R124      -3.1471493840217590e-01
    z[0,1,3]  R125      -5.5975690484046936e-02
    z[0,1,3]  R126      -9.0436212718486786e-02
    z[0,1,3]  R127      -4.9013805389404297e-01
    z[0,1,3]  R128      -1.2913604080677032e-01
    z[0,1,3]  R129      -2.6757690310478210e-01
    z[0,1,3]  R130      0.289849191904068
    z[0,1,3]  R131      1.5617226064205170e-01
    z[0,1,3]  R132      -2.3016671836376190e-01
    z[0,1,3]  R133      7.4717029929161072e-02
    z[0,1,3]  R134      -3.6574643850326538e-01
    z[0,1,3]  R135      6.8892216682434082e-01
    z[0,1,3]  R136      -0.0466042086482048
    z[0,1,3]  R137      -1.7337203025817871e-01
    z[0,1,3]  R138      5.4751407355070114e-02
    z[0,1,3]  R139      -5.2775126695632935e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       -4.0652030706405640e-01
    z[0,1,4]  R89       8.7469917535781860e-01
    z[0,1,4]  R90       0.202260360121727
    z[0,1,4]  R91       0.550208568572998
    z[0,1,4]  R92       2.4215830862522125e-01
    z[0,1,4]  R93       -9.3159534037113190e-02
    z[0,1,4]  R94       1.4329020678997040e-01
    z[0,1,4]  R95       5.7947766035795212e-02
    z[0,1,4]  R96       0.171248197555542
    z[0,1,4]  R97       -1.0985486954450607e-01
    z[0,1,4]  R98       -3.5780131816864014e-01
    z[0,1,4]  R99       -6.8329066038131714e-02
    z[0,1,4]  R100      -5.2520078420639038e-01
    z[0,1,4]  R101      -5.4033118486404419e-01
    z[0,1,4]  R102      -3.5473233461380005e-01
    z[0,1,4]  R103      -2.8986307978630066e-01
    z[0,1,4]  R104      -2.0128530263900757e-01
    z[0,1,4]  R105      -3.9078646898269653e-01
    z[0,1,4]  R106      -2.6295730471611023e-01
    z[0,1,4]  R107      -2.4100056290626526e-01
    z[0,1,4]  R108      -3.0672853812575340e-02
    z[0,1,4]  R109      1.5795344114303589e-01
    z[0,1,4]  R110      -2.8742568567395210e-02
    z[0,1,4]  R111      -1.1610026657581329e-01
    z[0,1,4]  R112      4.3195828795433044e-02
    z[0,1,4]  R113      1.6449637711048126e-01
    z[0,1,4]  R114      -4.0860839188098907e-02
    z[0,1,4]  R115      -1.5690515935420990e-01
    z[0,1,4]  R116      4.7893274575471878e-02
    z[0,1,4]  R117      -7.0245601236820221e-02
    z[0,1,4]  R118      -2.0273748040199280e-01
    z[0,1,4]  R119      -1.8839581310749054e-01
    z[0,1,4]  R120      -0.280404657125473
    z[0,1,4]  R121      -2.0461490750312805e-01
    z[0,1,4]  R122      -2.5542688369750977e-01
    z[0,1,4]  R123      -2.3426280915737152e-01
    z[0,1,4]  R124      1.6930826008319855e-01
    z[0,1,4]  R125      -1.2058027833700180e-01
    z[0,1,4]  R126      1.4223098754882812e-01
    z[0,1,4]  R127      -1.2113583087921143e-01
    z[0,1,4]  R128      -3.1754605472087860e-02
    z[0,1,4]  R129      -1.3101170957088470e-01
    z[0,1,4]  R130      5.9391045570373535e-01
    z[0,1,4]  R131      -9.2241771519184113e-02
    z[0,1,4]  R132      -2.6756340265274048e-01
    z[0,1,4]  R133      2.6170569658279419e-01
    z[0,1,4]  R134      6.4118497073650360e-02
    z[0,1,4]  R135      -3.7524932622909546e-01
    z[0,1,4]  R136      1.2699003517627716e-01
    z[0,1,4]  R137      -3.5339277982711792e-01
    z[0,1,4]  R138      5.5316165089607239e-02
    z[0,1,4]  R139      -1.0436274856328964e-01
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       2.0829458534717560e-01
    z[0,1,5]  R89       -3.6475688219070435e-01
    z[0,1,5]  R90       4.6943750977516174e-01
    z[0,1,5]  R91       1.1270909570157528e-02
    z[0,1,5]  R92       8.4247022867202759e-01
    z[0,1,5]  R93       -2.4377481639385223e-01
    z[0,1,5]  R94       3.5951547324657440e-03
    z[0,1,5]  R95       -1.4926959574222565e-01
    z[0,1,5]  R96       2.4945066869258881e-01
    z[0,1,5]  R97       -3.8165751844644547e-02
    z[0,1,5]  R98       -4.6699997782707214e-01
    z[0,1,5]  R99       1.3425664603710175e-01
    z[0,1,5]  R100      9.5400094985961914e-02
    z[0,1,5]  R101      4.0605971217155457e-01
    z[0,1,5]  R102      2.4746602773666382e-01
    z[0,1,5]  R103      2.4702483415603638e-01
    z[0,1,5]  R104      1.1016698926687241e-01
    z[0,1,5]  R105      5.3191280364990234e-01
    z[0,1,5]  R106      5.4213577508926392e-01
    z[0,1,5]  R107      2.7041015028953552e-01
    z[0,1,5]  R108      6.1038345098495483e-01
    z[0,1,5]  R109      -4.1404014825820923e-01
    z[0,1,5]  R110      -5.5174940824508667e-01
    z[0,1,5]  R111      -1.0935736447572708e-01
    z[0,1,5]  R112      5.1671421527862549e-01
    z[0,1,5]  R113      3.8030853867530823e-01
    z[0,1,5]  R114      -5.1567190885543823e-01
    z[0,1,5]  R115      3.9104467630386353e-01
    z[0,1,5]  R116      -3.1359159946441650e-01
    z[0,1,5]  R117      5.8405381441116333e-01
    z[0,1,5]  R118      -3.5724973678588867e-01
    z[0,1,5]  R119      -5.2501040697097778e-01
    z[0,1,5]  R120      8.2306081056594849e-01
    z[0,1,5]  R121      7.4455350637435913e-02
    z[0,1,5]  R122      3.4165728092193604e-01
    z[0,1,5]  R123      -2.6723784208297729e-01
    z[0,1,5]  R124      1.0493505001068115e-01
    z[0,1,5]  R125      -1.0127409547567368e-01
    z[0,1,5]  R126      -1.6792723536491394e-01
    z[0,1,5]  R127      -1.8255116045475006e-01
    z[0,1,5]  R128      -8.7863765656948090e-02
    z[0,1,5]  R129      -3.8030883669853210e-01
    z[0,1,5]  R130      2.3301929235458374e-01
    z[0,1,5]  R131      7.4577951431274414e-01
    z[0,1,5]  R132      3.5087481141090393e-02
    z[0,1,5]  R133      -2.8743150830268860e-01
    z[0,1,5]  R134      -3.0452570319175720e-01
    z[0,1,5]  R135      2.1698819100856781e-01
    z[0,1,5]  R136      4.7764277458190918e-01
    z[0,1,5]  R137      1.8217791616916656e-01
    z[0,1,5]  R138      -1.3483242690563202e-01
    z[0,1,5]  R139      -2.0405036211013794e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       4.6725142002105713e-01
    z[0,1,6]  R89       1.6382379829883575e-01
    z[0,1,6]  R90       1.0421517491340637e-01
    z[0,1,6]  R91       1.5747340023517609e-01
    z[0,1,6]  R92       2.5399681925773621e-01
    z[0,1,6]  R93       6.3457474112510681e-02
    z[0,1,6]  R94       1.0275022685527802e-01
    z[0,1,6]  R95       5.8797508478164673e-02
    z[0,1,6]  R96       5.4597449302673340e-01
    z[0,1,6]  R97       4.0711298584938049e-01
    z[0,1,6]  R98       -2.7359450235962868e-02
    z[0,1,6]  R99       -1.4401340484619141e-01
    z[0,1,6]  R100      -6.5099443309009075e-03
    z[0,1,6]  R101      -2.6664644479751587e-02
    z[0,1,6]  R102      -2.3657806217670441e-01
    z[0,1,6]  R103      3.7983467336744070e-03
    z[0,1,6]  R104      1.1799464374780655e-01
    z[0,1,6]  R105      3.2538682222366333e-01
    z[0,1,6]  R106      -2.0820635557174683e-01
    z[0,1,6]  R107      -1.3016252219676971e-01
    z[0,1,6]  R108      8.3052806556224823e-02
    z[0,1,6]  R109      -1.8609504401683807e-01
    z[0,1,6]  R110      -2.2193601727485657e-01
    z[0,1,6]  R111      1.6955780982971191e-01
    z[0,1,6]  R112      -5.8242619037628174e-01
    z[0,1,6]  R113      1.0649064928293228e-01
    z[0,1,6]  R114      4.9925157427787781e-01
    z[0,1,6]  R115      -7.1567870676517487e-02
    z[0,1,6]  R116      3.1157466769218445e-01
    z[0,1,6]  R117      1.3006825745105743e-01
    z[0,1,6]  R118      1.9509072601795197e-01
    z[0,1,6]  R119      -2.5431713089346886e-02
    z[0,1,6]  R120      2.8574258089065552e-01
    z[0,1,6]  R121      9.6433833241462708e-02
    z[0,1,6]  R122      1.7172423005104065e-01
    z[0,1,6]  R123      3.0988961458206177e-01
    z[0,1,6]  R124      2.6388822123408318e-02
    z[0,1,6]  R125      1.7337700724601746e-01
    z[0,1,6]  R126      -7.7882311306893826e-03
    z[0,1,6]  R127      1.8303962051868439e-01
    z[0,1,6]  R128      -3.6888930201530457e-01
    z[0,1,6]  R129      -1.6560163348913193e-02
    z[0,1,6]  R130      -4.9504969269037247e-02
    z[0,1,6]  R131      -1.7858718335628510e-01
    z[0,1,6]  R132      -2.8049442172050476e-01
    z[0,1,6]  R133      -0.483377069234848
    z[0,1,6]  R134      -0.547780454158783
    z[0,1,6]  R135      4.5364937186241150e-01
    z[0,1,6]  R136      -1.0871516168117523e-01
    z[0,1,6]  R137      -7.5729645788669586e-02
    z[0,1,6]  R138      -0.313103049993515
    z[0,1,6]  R139      -4.6434280276298523e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R140      -1
    z[1,0,0]  R141      1
    z[1,0,0]  R154      -7.5755953788757324e-01
    z[1,0,0]  R155      6.1774069070816040e-01
    z[1,0,0]  R156      -3.3967691659927368e-01
    z[1,0,0]  R157      -7.4591761827468872e-01
    z[1,0,0]  R158      -6.3562631607055664e-01
    z[1,0,0]  R159      -6.7685276269912720e-01
    z[1,0,0]  R160      -7.6198214292526245e-01
    z[1,0,0]  R161      1.2019499391317368e-01
    z[1,0,0]  R162      0.0736149400472641
    z[1,0,0]  R163      -1.8352362513542175e-01
    z[1,0,0]  R164      -2.1915476024150848e-01
    z[1,0,0]  R165      2.4370449781417847e-01
    z[1,0,0]  R166      -3.2098489999771118e-01
    z[1,0,0]  R167      3.3063909411430359e-01
    z[1,0,0]  R168      1.8062606453895569e-01
    z[1,0,0]  R169      -1.9695401191711426e-02
    z[1,0,0]  R170      -2.9621289577335119e-03
    z[1,0,0]  R171      1.9050359725952148e-01
    z[1,0,0]  R172      0.629289448261261
    z[1,0,0]  R173      4.6556234359741211e-02
    z[1,0,0]  R174      -3.0931890010833740e-02
    z[1,0,0]  R175      2.0336858928203583e-02
    z[1,0,0]  R176      5.8140856027603149e-01
    z[1,0,0]  R177      -1.9250120222568512e-01
    z[1,0,0]  R178      5.9856560081243515e-02
    z[1,0,0]  R179      -4.9915939569473267e-02
    z[1,0,0]  R180      -3.6315965652465820e-01
    z[1,0,0]  R181      5.3551656007766724e-01
    z[1,0,0]  R182      3.1531623005867004e-01
    z[1,0,0]  R183      -2.2023370862007141e-01
    z[1,0,0]  R184      2.2594654560089111e-01
    z[1,0,0]  R185      0.123531773686409
    z[1,0,0]  R186      1.8905134499073029e-01
    z[1,0,0]  R187      -2.6604864001274109e-01
    z[1,0,0]  R188      -1.4337065815925598e-01
    z[1,0,0]  R189      -3.0445605516433716e-01
    z[1,0,0]  R190      -3.7949305772781372e-01
    z[1,0,0]  R191      -3.9805746078491211e-01
    z[1,0,0]  R192      -3.2808291912078857e-01
    z[1,0,0]  R193      -2.6863589882850647e-01
    z[1,0,0]  R194      -3.7944170832633972e-01
    z[1,0,0]  R195      -3.1133583188056946e-01
    z[1,0,0]  R196      -5.1333421468734741e-01
    z[1,0,0]  R197      3.9979004859924316e-01
    z[1,0,0]  R198      -0.0194241926074028
    z[1,0,0]  R199      2.9889246821403503e-01
    z[1,0,0]  R200      -4.0776455402374268e-01
    z[1,0,0]  R201      1.8535171449184418e-01
    z[1,0,0]  R202      -7.6386652654036880e-04
    z[1,0,0]  R203      2.3205760121345520e-01
    z[1,0,0]  R204      -0.0546276830136776
    z[1,0,0]  R205      9.5886774361133575e-02
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R142      -1
    z[1,0,1]  R143      1
    z[1,0,1]  R154      8.1886142492294312e-02
    z[1,0,1]  R155      9.7055546939373016e-02
    z[1,0,1]  R156      1.2865361571311951e-01
    z[1,0,1]  R157      6.0638375580310822e-02
    z[1,0,1]  R158      5.5151361972093582e-02
    z[1,0,1]  R159      -4.3803101778030396e-01
    z[1,0,1]  R160      -5.0843238830566406e-01
    z[1,0,1]  R161      -7.6586097478866577e-01
    z[1,0,1]  R162      -6.9656598567962646e-01
    z[1,0,1]  R163      -0.386089026927948
    z[1,0,1]  R164      8.7825745344161987e-01
    z[1,0,1]  R165      0.83925461769104
    z[1,0,1]  R166      6.3452881574630737e-01
    z[1,0,1]  R167      1.6306184232234955e-01
    z[1,0,1]  R168      -8.0407577753067017e-01
    z[1,0,1]  R169      -6.3214516639709473e-01
    z[1,0,1]  R170      -4.4627717137336731e-01
    z[1,0,1]  R171      1.5261571109294891e-01
    z[1,0,1]  R172      0.0878714844584465
    z[1,0,1]  R173      -8.7257444858551025e-01
    z[1,0,1]  R174      -8.7358325719833374e-01
    z[1,0,1]  R175      -5.4689502716064453e-01
    z[1,0,1]  R176      2.2264511883258820e-01
    z[1,0,1]  R177      1.6231055557727814e-01
    z[1,0,1]  R178      1.1129427701234818e-01
    z[1,0,1]  R179      6.8842776119709015e-02
    z[1,0,1]  R180      -1.0296688415110111e-02
    z[1,0,1]  R181      -7.9762744903564453e-01
    z[1,0,1]  R182      -8.2727664709091187e-01
    z[1,0,1]  R183      -6.1877506971359253e-01
    z[1,0,1]  R184      -5.4082858562469482e-01
    z[1,0,1]  R185      2.2063447535037994e-01
    z[1,0,1]  R186      2.8825476765632629e-01
    z[1,0,1]  R187      6.5079480409622192e-01
    z[1,0,1]  R188      6.5550971031188965e-01
    z[1,0,1]  R189      0.504782497882843
    z[1,0,1]  R190      5.9593433141708374e-01
    z[1,0,1]  R191      7.0695358514785767e-01
    z[1,0,1]  R192      5.6116998195648193e-01
    z[1,0,1]  R193      2.5891184806823730e-01
    z[1,0,1]  R194      3.4656202793121338e-01
    z[1,0,1]  R195      4.3070918321609497e-01
    z[1,0,1]  R196      4.3959498405456543e-01
    z[1,0,1]  R197      -3.9317718148231506e-01
    z[1,0,1]  R198      -0.618119478225708
    z[1,0,1]  R199      -2.8242516517639160e-01
    z[1,0,1]  R200      -3.9775301702320576e-03
    z[1,0,1]  R201      -8.8265210390090942e-01
    z[1,0,1]  R202      -4.8212072253227234e-01
    z[1,0,1]  R203      -8.5552811622619629e-01
    z[1,0,1]  R204      -2.3137611150741577e-01
    z[1,0,1]  R205      -7.6621663570404053e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R144      -1
    z[1,0,2]  R145      1
    z[1,0,2]  R154      2.1614845097064972e-01
    z[1,0,2]  R155      -7.2414785623550415e-02
    z[1,0,2]  R156      1.6746085882186890e-01
    z[1,0,2]  R157      -0.552842915058136
    z[1,0,2]  R158      -6.1426943540573120e-01
    z[1,0,2]  R159      1.5637424588203430e-01
    z[1,0,2]  R160      1.4649611711502075e-01
    z[1,0,2]  R161      5.8397012948989868e-01
    z[1,0,2]  R162      6.7283588647842407e-01
    z[1,0,2]  R163      7.0392948389053345e-01
    z[1,0,2]  R164      1.3838779926300049e-01
    z[1,0,2]  R165      -5.0884738564491272e-02
    z[1,0,2]  R166      2.9170921072363853e-02
    z[1,0,2]  R167      -4.9306163191795349e-01
    z[1,0,2]  R168      -3.4111782908439636e-01
    z[1,0,2]  R169      -4.5788824558258057e-01
    z[1,0,2]  R170      -0.519756555557251
    z[1,0,2]  R171      -2.6853203773498535e-01
    z[1,0,2]  R172      5.8138924837112427e-01
    z[1,0,2]  R173      -2.0634530484676361e-01
    z[1,0,2]  R174      -3.3708235621452332e-01
    z[1,0,2]  R175      -3.9220988750457764e-01
    z[1,0,2]  R176      -3.2770600914955139e-01
    z[1,0,2]  R177      -6.7050859332084656e-02
    z[1,0,2]  R178      -5.1336042582988739e-02
    z[1,0,2]  R179      -8.1323289871215820e-01
    z[1,0,2]  R180      1.1117040365934372e-01
    z[1,0,2]  R181      6.7289404571056366e-02
    z[1,0,2]  R182      -3.7855041027069092e-01
    z[1,0,2]  R183      1.3529086112976074e-01
    z[1,0,2]  R184      2.1808530390262604e-01
    z[1,0,2]  R185      5.0742077827453613e-01
    z[1,0,2]  R186      6.6660559177398682e-01
    z[1,0,2]  R187      1.3948100805282593e-01
    z[1,0,2]  R188      -4.5719772577285767e-01
    z[1,0,2]  R189      -2.4878266453742981e-01
    z[1,0,2]  R190      -2.1776770055294037e-01
    z[1,0,2]  R191      -3.2101023197174072e-01
    z[1,0,2]  R192      -3.1241452693939209e-01
    z[1,0,2]  R193      -2.9116892814636230e-01
    z[1,0,2]  R194      -5.6948333978652954e-01
    z[1,0,2]  R195      -7.1742653846740723e-01
    z[1,0,2]  R196      2.8313699364662170e-01
    z[1,0,2]  R197      -3.8030885625630617e-03
    z[1,0,2]  R198      1.9267649948596954e-01
    z[1,0,2]  R199      4.2524451017379761e-01
    z[1,0,2]  R200      1.6295653581619263e-01
    z[1,0,2]  R201      4.6793825924396515e-02
    z[1,0,2]  R202      2.1531592309474945e-01
    z[1,0,2]  R203      -4.7669090330600739e-02
    z[1,0,2]  R204      1.0567907989025116e-01
    z[1,0,2]  R205      -0.103363998234272
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R146      -1
    z[1,0,3]  R147      1
    z[1,0,3]  R154      -4.0729328989982605e-01
    z[1,0,3]  R155      5.4033064842224121e-01
    z[1,0,3]  R156      -4.8166982829570770e-02
    z[1,0,3]  R157      2.7853947877883911e-01
    z[1,0,3]  R158      -6.4410172402858734e-02
    z[1,0,3]  R159      -3.2127812504768372e-01
    z[1,0,3]  R160      -3.1471493840217590e-01
    z[1,0,3]  R161      -5.5975690484046936e-02
    z[1,0,3]  R162      -9.0436212718486786e-02
    z[1,0,3]  R163      -4.9013805389404297e-01
    z[1,0,3]  R164      -1.2913604080677032e-01
    z[1,0,3]  R165      -2.6757690310478210e-01
    z[1,0,3]  R166      0.289849191904068
    z[1,0,3]  R167      1.5617226064205170e-01
    z[1,0,3]  R168      -2.3016671836376190e-01
    z[1,0,3]  R169      7.4717029929161072e-02
    z[1,0,3]  R170      -3.6574643850326538e-01
    z[1,0,3]  R171      6.8892216682434082e-01
    z[1,0,3]  R172      -0.0466042086482048
    z[1,0,3]  R173      -1.7337203025817871e-01
    z[1,0,3]  R174      5.4751407355070114e-02
    z[1,0,3]  R175      -5.2775126695632935e-01
    z[1,0,3]  R176      2.7934342622756958e-01
    z[1,0,3]  R177      -8.4370121359825134e-02
    z[1,0,3]  R178      -8.4217202663421631e-01
    z[1,0,3]  R179      -6.1375718563795090e-02
    z[1,0,3]  R180      1.5079474449157715e-01
    z[1,0,3]  R181      1.8788080662488937e-02
    z[1,0,3]  R182      -2.0441633462905884e-01
    z[1,0,3]  R183      7.2195190191268921e-01
    z[1,0,3]  R184      4.6824315190315247e-01
    z[1,0,3]  R185      7.0662492513656616e-01
    z[1,0,3]  R186      -2.9991081357002258e-01
    z[1,0,3]  R187      6.6542893648147583e-01
    z[1,0,3]  R188      2.3609901964664459e-01
    z[1,0,3]  R189      -3.6476698517799377e-01
    z[1,0,3]  R190      -4.5867305994033813e-01
    z[1,0,3]  R191      -3.0604410171508789e-01
    z[1,0,3]  R192      -6.4286214113235474e-01
    z[1,0,3]  R193      -4.8425009846687317e-01
    z[1,0,3]  R194      -7.2110451757907867e-02
    z[1,0,3]  R195      -2.3390905559062958e-01
    z[1,0,3]  R196      -2.8752577304840088e-01
    z[1,0,3]  R197      6.7420721054077148e-01
    z[1,0,3]  R198      4.7530794143676758e-01
    z[1,0,3]  R199      0.771931529045105
    z[1,0,3]  R200      -4.4618120789527893e-01
    z[1,0,3]  R201      -3.6692906171083450e-02
    z[1,0,3]  R202      4.5206043124198914e-01
    z[1,0,3]  R203      -1.7114739120006561e-01
    z[1,0,3]  R204      8.5708844661712646e-01
    z[1,0,3]  R205      -1.7338600754737854e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R148      -1
    z[1,0,4]  R149      1
    z[1,0,4]  R154      -2.0273748040199280e-01
    z[1,0,4]  R155      -1.8839581310749054e-01
    z[1,0,4]  R156      -0.280404657125473
    z[1,0,4]  R157      -2.0461490750312805e-01
    z[1,0,4]  R158      -2.5542688369750977e-01
    z[1,0,4]  R159      -2.3426280915737152e-01
    z[1,0,4]  R160      1.6930826008319855e-01
    z[1,0,4]  R161      -1.2058027833700180e-01
    z[1,0,4]  R162      1.4223098754882812e-01
    z[1,0,4]  R163      -1.2113583087921143e-01
    z[1,0,4]  R164      -3.1754605472087860e-02
    z[1,0,4]  R165      -1.3101170957088470e-01
    z[1,0,4]  R166      5.9391045570373535e-01
    z[1,0,4]  R167      -9.2241771519184113e-02
    z[1,0,4]  R168      -2.6756340265274048e-01
    z[1,0,4]  R169      2.6170569658279419e-01
    z[1,0,4]  R170      6.4118497073650360e-02
    z[1,0,4]  R171      -3.7524932622909546e-01
    z[1,0,4]  R172      1.2699003517627716e-01
    z[1,0,4]  R173      -3.5339277982711792e-01
    z[1,0,4]  R174      5.5316165089607239e-02
    z[1,0,4]  R175      -1.0436274856328964e-01
    z[1,0,4]  R176      -4.0652030706405640e-01
    z[1,0,4]  R177      8.7469917535781860e-01
    z[1,0,4]  R178      0.202260360121727
    z[1,0,4]  R179      0.550208568572998
    z[1,0,4]  R180      2.4215830862522125e-01
    z[1,0,4]  R181      -9.3159534037113190e-02
    z[1,0,4]  R182      1.4329020678997040e-01
    z[1,0,4]  R183      5.7947766035795212e-02
    z[1,0,4]  R184      0.171248197555542
    z[1,0,4]  R185      -1.0985486954450607e-01
    z[1,0,4]  R186      -3.5780131816864014e-01
    z[1,0,4]  R187      -6.8329066038131714e-02
    z[1,0,4]  R188      -5.2520078420639038e-01
    z[1,0,4]  R189      -5.4033118486404419e-01
    z[1,0,4]  R190      -3.5473233461380005e-01
    z[1,0,4]  R191      -2.8986307978630066e-01
    z[1,0,4]  R192      -2.0128530263900757e-01
    z[1,0,4]  R193      -3.9078646898269653e-01
    z[1,0,4]  R194      -2.6295730471611023e-01
    z[1,0,4]  R195      -2.4100056290626526e-01
    z[1,0,4]  R196      -3.0672853812575340e-02
    z[1,0,4]  R197      1.5795344114303589e-01
    z[1,0,4]  R198      -2.8742568567395210e-02
    z[1,0,4]  R199      -1.1610026657581329e-01
    z[1,0,4]  R200      4.3195828795433044e-02
    z[1,0,4]  R201      1.6449637711048126e-01
    z[1,0,4]  R202      -4.0860839188098907e-02
    z[1,0,4]  R203      -1.5690515935420990e-01
    z[1,0,4]  R204      4.7893274575471878e-02
    z[1,0,4]  R205      -7.0245601236820221e-02
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R150      -1
    z[1,0,5]  R151      1
    z[1,0,5]  R154      -3.5724973678588867e-01
    z[1,0,5]  R155      -5.2501040697097778e-01
    z[1,0,5]  R156      8.2306081056594849e-01
    z[1,0,5]  R157      7.4455350637435913e-02
    z[1,0,5]  R158      3.4165728092193604e-01
    z[1,0,5]  R159      -2.6723784208297729e-01
    z[1,0,5]  R160      1.0493505001068115e-01
    z[1,0,5]  R161      -1.0127409547567368e-01
    z[1,0,5]  R162      -1.6792723536491394e-01
    z[1,0,5]  R163      -1.8255116045475006e-01
    z[1,0,5]  R164      -8.7863765656948090e-02
    z[1,0,5]  R165      -3.8030883669853210e-01
    z[1,0,5]  R166      2.3301929235458374e-01
    z[1,0,5]  R167      7.4577951431274414e-01
    z[1,0,5]  R168      3.5087481141090393e-02
    z[1,0,5]  R169      -2.8743150830268860e-01
    z[1,0,5]  R170      -3.0452570319175720e-01
    z[1,0,5]  R171      2.1698819100856781e-01
    z[1,0,5]  R172      4.7764277458190918e-01
    z[1,0,5]  R173      1.8217791616916656e-01
    z[1,0,5]  R174      -1.3483242690563202e-01
    z[1,0,5]  R175      -2.0405036211013794e-01
    z[1,0,5]  R176      2.0829458534717560e-01
    z[1,0,5]  R177      -3.6475688219070435e-01
    z[1,0,5]  R178      4.6943750977516174e-01
    z[1,0,5]  R179      1.1270909570157528e-02
    z[1,0,5]  R180      8.4247022867202759e-01
    z[1,0,5]  R181      -2.4377481639385223e-01
    z[1,0,5]  R182      3.5951547324657440e-03
    z[1,0,5]  R183      -1.4926959574222565e-01
    z[1,0,5]  R184      2.4945066869258881e-01
    z[1,0,5]  R185      -3.8165751844644547e-02
    z[1,0,5]  R186      -4.6699997782707214e-01
    z[1,0,5]  R187      1.3425664603710175e-01
    z[1,0,5]  R188      9.5400094985961914e-02
    z[1,0,5]  R189      4.0605971217155457e-01
    z[1,0,5]  R190      2.4746602773666382e-01
    z[1,0,5]  R191      2.4702483415603638e-01
    z[1,0,5]  R192      1.1016698926687241e-01
    z[1,0,5]  R193      5.3191280364990234e-01
    z[1,0,5]  R194      5.4213577508926392e-01
    z[1,0,5]  R195      2.7041015028953552e-01
    z[1,0,5]  R196      6.1038345098495483e-01
    z[1,0,5]  R197      -4.1404014825820923e-01
    z[1,0,5]  R198      -5.5174940824508667e-01
    z[1,0,5]  R199      -1.0935736447572708e-01
    z[1,0,5]  R200      5.1671421527862549e-01
    z[1,0,5]  R201      3.8030853867530823e-01
    z[1,0,5]  R202      -5.1567190885543823e-01
    z[1,0,5]  R203      3.9104467630386353e-01
    z[1,0,5]  R204      -3.1359159946441650e-01
    z[1,0,5]  R205      5.8405381441116333e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R152      -1
    z[1,0,6]  R153      1
    z[1,0,6]  R154      1.9509072601795197e-01
    z[1,0,6]  R155      -2.5431713089346886e-02
    z[1,0,6]  R156      2.8574258089065552e-01
    z[1,0,6]  R157      9.6433833241462708e-02
    z[1,0,6]  R158      1.7172423005104065e-01
    z[1,0,6]  R159      3.0988961458206177e-01
    z[1,0,6]  R160      2.6388822123408318e-02
    z[1,0,6]  R161      1.7337700724601746e-01
    z[1,0,6]  R162      -7.7882311306893826e-03
    z[1,0,6]  R163      1.8303962051868439e-01
    z[1,0,6]  R164      -3.6888930201530457e-01
    z[1,0,6]  R165      -1.6560163348913193e-02
    z[1,0,6]  R166      -4.9504969269037247e-02
    z[1,0,6]  R167      -1.7858718335628510e-01
    z[1,0,6]  R168      -2.8049442172050476e-01
    z[1,0,6]  R169      -0.483377069234848
    z[1,0,6]  R170      -0.547780454158783
    z[1,0,6]  R171      4.5364937186241150e-01
    z[1,0,6]  R172      -1.0871516168117523e-01
    z[1,0,6]  R173      -7.5729645788669586e-02
    z[1,0,6]  R174      -0.313103049993515
    z[1,0,6]  R175      -4.6434280276298523e-01
    z[1,0,6]  R176      4.6725142002105713e-01
    z[1,0,6]  R177      1.6382379829883575e-01
    z[1,0,6]  R178      1.0421517491340637e-01
    z[1,0,6]  R179      1.5747340023517609e-01
    z[1,0,6]  R180      2.5399681925773621e-01
    z[1,0,6]  R181      6.3457474112510681e-02
    z[1,0,6]  R182      1.0275022685527802e-01
    z[1,0,6]  R183      5.8797508478164673e-02
    z[1,0,6]  R184      5.4597449302673340e-01
    z[1,0,6]  R185      4.0711298584938049e-01
    z[1,0,6]  R186      -2.7359450235962868e-02
    z[1,0,6]  R187      -1.4401340484619141e-01
    z[1,0,6]  R188      -6.5099443309009075e-03
    z[1,0,6]  R189      -2.6664644479751587e-02
    z[1,0,6]  R190      -2.3657806217670441e-01
    z[1,0,6]  R191      3.7983467336744070e-03
    z[1,0,6]  R192      1.1799464374780655e-01
    z[1,0,6]  R193      3.2538682222366333e-01
    z[1,0,6]  R194      -2.0820635557174683e-01
    z[1,0,6]  R195      -1.3016252219676971e-01
    z[1,0,6]  R196      8.3052806556224823e-02
    z[1,0,6]  R197      -1.8609504401683807e-01
    z[1,0,6]  R198      -2.2193601727485657e-01
    z[1,0,6]  R199      1.6955780982971191e-01
    z[1,0,6]  R200      -5.8242619037628174e-01
    z[1,0,6]  R201      1.0649064928293228e-01
    z[1,0,6]  R202      4.9925157427787781e-01
    z[1,0,6]  R203      -7.1567870676517487e-02
    z[1,0,6]  R204      3.1157466769218445e-01
    z[1,0,6]  R205      1.3006825745105743e-01
    z[0,3,0]  R2        -1
    z[0,3,0]  R29       1
    z[0,3,0]  R206      -1
    z[0,3,0]  R207      1
    z[0,3,0]  R220      5.8140856027603149e-01
    z[0,3,0]  R221      -1.9250120222568512e-01
    z[0,3,0]  R222      5.9856560081243515e-02
    z[0,3,0]  R223      -4.9915939569473267e-02
    z[0,3,0]  R224      -3.6315965652465820e-01
    z[0,3,0]  R225      5.3551656007766724e-01
    z[0,3,0]  R226      3.1531623005867004e-01
    z[0,3,0]  R227      -2.2023370862007141e-01
    z[0,3,0]  R228      2.2594654560089111e-01
    z[0,3,0]  R229      0.123531773686409
    z[0,3,0]  R230      1.8905134499073029e-01
    z[0,3,0]  R231      -2.6604864001274109e-01
    z[0,3,0]  R232      -1.4337065815925598e-01
    z[0,3,0]  R233      -3.0445605516433716e-01
    z[0,3,0]  R234      -3.7949305772781372e-01
    z[0,3,0]  R235      -3.9805746078491211e-01
    z[0,3,0]  R236      -3.2808291912078857e-01
    z[0,3,0]  R237      -2.6863589882850647e-01
    z[0,3,0]  R238      -3.7944170832633972e-01
    z[0,3,0]  R239      -3.1133583188056946e-01
    z[0,3,0]  R240      -5.1333421468734741e-01
    z[0,3,0]  R241      3.9979004859924316e-01
    z[0,3,0]  R242      -0.0194241926074028
    z[0,3,0]  R243      2.9889246821403503e-01
    z[0,3,0]  R244      -4.0776455402374268e-01
    z[0,3,0]  R245      1.8535171449184418e-01
    z[0,3,0]  R246      -7.6386652654036880e-04
    z[0,3,0]  R247      2.3205760121345520e-01
    z[0,3,0]  R248      -0.0546276830136776
    z[0,3,0]  R249      9.5886774361133575e-02
    z[0,3,0]  R250      4.3805766105651855e-01
    z[0,3,0]  R251      0.417502224445343
    z[0,3,0]  R252      0.575057327747345
    z[0,3,0]  R253      7.2431176900863647e-02
    z[0,3,0]  R254      1.5262040495872498e-01
    z[0,3,0]  R255      4.0876439213752747e-01
    z[0,3,0]  R256      2.4220088124275208e-01
    z[0,3,0]  R257      2.1401388943195343e-01
    z[0,3,0]  R258      4.3158498406410217e-01
    z[0,3,0]  R259      7.0104628801345825e-01
    z[0,3,0]  R260      8.0959171056747437e-01
    z[0,3,0]  R261      6.4698415994644165e-01
    z[0,3,0]  R262      7.3615294694900513e-01
    z[0,3,0]  R263      7.3598664999008179e-01
    z[0,3,0]  R264      7.0550125837326050e-01
    z[0,3,0]  R265      6.3437575101852417e-01
    z[0,3,0]  R266      5.7536059617996216e-01
    z[0,3,0]  R267      5.6623983383178711e-01
    z[0,3,0]  R268      6.3096511363983154e-01
    z[0,3,0]  R269      6.5490937232971191e-01
    z[0,3,0]  R270      -1.9726440310478210e-01
    z[0,3,0]  R271      -1.0529028624296188e-01
    z[0,3,0]  R272      -7.1863353252410889e-01
    z[0,3,0]  R273      -7.8457134962081909e-01
    z[0,3,0]  R274      -0.79290771484375
    z[0,3,0]  R275      -7.3468130826950073e-01
    z[0,3,0]  R276      -6.3682740926742554e-01
    z[0,3,0]  R277      -6.2035316228866577e-01
    z[0,3,0]  R278      -6.7900937795639038e-01
    z[0,3,0]  R279      -6.7543321847915649e-01
    z[0,3,0]  R280      4.1349714994430542e-01
    z[0,3,0]  R281      5.1700967550277710e-01
    z[0,3,0]  R282      -1.0512983798980713e-01
    z[0,3,0]  R283      -1.7748099565505981e-01
    z[0,3,0]  R284      -7.1416527032852173e-01
    z[0,3,0]  R285      -7.9319137334823608e-01
    z[0,3,0]  R286      -1.2548317201435566e-02
    z[0,3,0]  R287      -7.7411487698554993e-02
    z[0,3,0]  R288      -8.6458724737167358e-01
    z[0,3,0]  R289      -9.1031205654144287e-01
    z[0,3,0]  R290      7.3104846477508545e-01
    z[0,3,0]  R291      2.9177516698837280e-01
    z[0,3,0]  R292      2.8340291976928711e-01
    z[0,3,0]  R293      -4.5324318110942841e-02
    z[0,3,0]  R294      1.8512003123760223e-01
    z[0,3,0]  R295      -1.1372501403093338e-01
    z[0,3,0]  R296      5.3195875138044357e-02
    z[0,3,0]  R297      -6.2801039218902588e-01
    z[0,3,0]  R298      1.1845371872186661e-01
    z[0,3,0]  R299      -7.9882496595382690e-01
    z[0,3,0]  R300      0.524105429649353
    z[0,3,0]  R301      4.0315771102905273e-01
    z[0,3,0]  R302      2.0439341664314270e-01
    z[0,3,0]  R303      0.686012327671051
    z[0,3,0]  R304      -7.8146022558212280e-01
    z[0,3,0]  R305      -8.6590969562530518e-01
    z[0,3,0]  R306      -7.6497918367385864e-01
    z[0,3,0]  R307      -8.5123002529144287e-01
    z[0,3,0]  R308      -8.9121866226196289e-01
    z[0,3,0]  R309      -0.826116681098938
    z[0,3,0]  R310      5.2226793766021729e-01
    z[0,3,0]  R311      4.6512582898139954e-01
    z[0,3,0]  R312      1.1516742408275604e-01
    z[0,3,0]  R313      3.5153231024742126e-01
    z[0,3,0]  R314      5.0296396017074585e-01
    z[0,3,0]  R315      -5.8018577098846436e-01
    z[0,3,0]  R316      -8.2047873735427856e-01
    z[0,3,0]  R317      -8.1746226549148560e-01
    z[0,3,0]  R318      -8.9487850666046143e-01
    z[0,3,0]  R319      8.7175302207469940e-02
    z[0,3,1]  R3        -1
    z[0,3,1]  R30       1
    z[0,3,1]  R208      -1
    z[0,3,1]  R209      1
    z[0,3,1]  R220      2.2264511883258820e-01
    z[0,3,1]  R221      1.6231055557727814e-01
    z[0,3,1]  R222      1.1129427701234818e-01
    z[0,3,1]  R223      6.8842776119709015e-02
    z[0,3,1]  R224      -1.0296688415110111e-02
    z[0,3,1]  R225      -7.9762744903564453e-01
    z[0,3,1]  R226      -8.2727664709091187e-01
    z[0,3,1]  R227      -6.1877506971359253e-01
    z[0,3,1]  R228      -5.4082858562469482e-01
    z[0,3,1]  R229      2.2063447535037994e-01
    z[0,3,1]  R230      2.8825476765632629e-01
    z[0,3,1]  R231      6.5079480409622192e-01
    z[0,3,1]  R232      6.5550971031188965e-01
    z[0,3,1]  R233      0.504782497882843
    z[0,3,1]  R234      5.9593433141708374e-01
    z[0,3,1]  R235      7.0695358514785767e-01
    z[0,3,1]  R236      5.6116998195648193e-01
    z[0,3,1]  R237      2.5891184806823730e-01
    z[0,3,1]  R238      3.4656202793121338e-01
    z[0,3,1]  R239      4.3070918321609497e-01
    z[0,3,1]  R240      4.3959498405456543e-01
    z[0,3,1]  R241      -3.9317718148231506e-01
    z[0,3,1]  R242      -0.618119478225708
    z[0,3,1]  R243      -2.8242516517639160e-01
    z[0,3,1]  R244      -3.9775301702320576e-03
    z[0,3,1]  R245      -8.8265210390090942e-01
    z[0,3,1]  R246      -4.8212072253227234e-01
    z[0,3,1]  R247      -8.5552811622619629e-01
    z[0,3,1]  R248      -2.3137611150741577e-01
    z[0,3,1]  R249      -7.6621663570404053e-01
    z[0,3,1]  R250      -7.4315059185028076e-01
    z[0,3,1]  R251      -6.4629071950912476e-01
    z[0,3,1]  R252      -5.4676425457000732e-01
    z[0,3,1]  R253      -7.6116353273391724e-01
    z[0,3,1]  R254      -6.2137299776077271e-01
    z[0,3,1]  R255      -4.7046065330505371e-01
    z[0,3,1]  R256      -4.7412568330764771e-01
    z[0,3,1]  R257      -5.4200416803359985e-01
    z[0,3,1]  R258      -3.9279901981353760e-01
    z[0,3,1]  R259      -4.4781142473220825e-01
    z[0,3,1]  R260      4.3983411788940430e-01
    z[0,3,1]  R261      4.2036175727844238e-01
    z[0,3,1]  R262      5.3850877285003662e-01
    z[0,3,1]  R263      2.9302990436553955e-01
    z[0,3,1]  R264      4.8259556293487549e-01
    z[0,3,1]  R265      4.1428366303443909e-01
    z[0,3,1]  R266      6.3172364234924316e-01
    z[0,3,1]  R267      4.1547408699989319e-01
    z[0,3,1]  R268      3.5577812790870667e-01
    z[0,3,1]  R269      5.5575639009475708e-01
    z[0,3,1]  R270      -5.0551635026931763e-01
    z[0,3,1]  R271      -6.2404167652130127e-01
    z[0,3,1]  R272      3.2444596290588379e-01
    z[0,3,1]  R273      1.3832947611808777e-01
    z[0,3,1]  R274      3.6259597539901733e-01
    z[0,3,1]  R275      0.476630836725235
    z[0,3,1]  R276      5.2922356128692627e-01
    z[0,3,1]  R277      4.3140381574630737e-01
    z[0,3,1]  R278      5.2916640043258667e-01
    z[0,3,1]  R279      5.5091768503189087e-01
    z[0,3,1]  R280      -2.2911764681339264e-01
    z[0,3,1]  R281      3.1199318170547485e-01
    z[0,3,1]  R282      3.6908298730850220e-01
    z[0,3,1]  R283      0.517268180847168
    z[0,3,1]  R284      3.4748798608779907e-01
    z[0,3,1]  R285      -0.525443971157074
    z[0,3,1]  R286      -2.8569707274436951e-01
    z[0,3,1]  R287      -2.5481000542640686e-01
    z[0,3,1]  R288      -3.9693346619606018e-01
    z[0,3,1]  R289      -2.4970203638076782e-01
    z[0,3,1]  R290      3.6790484189987183e-01
    z[0,3,1]  R291      4.9255335330963135e-01
    z[0,3,1]  R292      8.3790290355682373e-01
    z[0,3,1]  R293      0.460196852684021
    z[0,3,1]  R294      -4.7581657767295837e-02
    z[0,3,1]  R295      3.6662113666534424e-01
    z[0,3,1]  R296      5.3846889734268188e-01
    z[0,3,1]  R297      3.4729701280593872e-01
    z[0,3,1]  R298      5.4520481824874878e-01
    z[0,3,1]  R299      1.6787196695804596e-01
    z[0,3,1]  R300      -5.1416093111038208e-01
    z[0,3,1]  R301      -1.9312760233879089e-01
    z[0,3,1]  R302      6.2209200859069824e-01
    z[0,3,1]  R303      -0.256678968667984
    z[0,3,1]  R304      3.0892390012741089e-01
    z[0,3,1]  R305      1.2741953134536743e-01
    z[0,3,1]  R306      4.0049365162849426e-01
    z[0,3,1]  R307      3.3169683814048767e-01
    z[0,3,1]  R308      1.0963108390569687e-01
    z[0,3,1]  R309      2.1821531653404236e-01
    z[0,3,1]  R310      -3.7440881133079529e-01
    z[0,3,1]  R311      -0.374693363904953
    z[0,3,1]  R312      -4.1260075569152832e-01
    z[0,3,1]  R313      0.281189888715744
    z[0,3,1]  R314      -2.9525252059102058e-02
    z[0,3,1]  R315      -2.7286946773529053e-01
    z[0,3,1]  R316      -4.3413645029067993e-01
    z[0,3,1]  R317      0.0749564915895462
    z[0,3,1]  R318      -2.5474876165390015e-01
    z[0,3,1]  R319      -3.6620470881462097e-01
    z[0,3,2]  R4        -1
    z[0,3,2]  R31       1
    z[0,3,2]  R210      -1
    z[0,3,2]  R211      1
    z[0,3,2]  R220      -3.2770600914955139e-01
    z[0,3,2]  R221      -6.7050859332084656e-02
    z[0,3,2]  R222      -5.1336042582988739e-02
    z[0,3,2]  R223      -8.1323289871215820e-01
    z[0,3,2]  R224      1.1117040365934372e-01
    z[0,3,2]  R225      6.7289404571056366e-02
    z[0,3,2]  R226      -3.7855041027069092e-01
    z[0,3,2]  R227      1.3529086112976074e-01
    z[0,3,2]  R228      2.1808530390262604e-01
    z[0,3,2]  R229      5.0742077827453613e-01
    z[0,3,2]  R230      6.6660559177398682e-01
    z[0,3,2]  R231      1.3948100805282593e-01
    z[0,3,2]  R232      -4.5719772577285767e-01
    z[0,3,2]  R233      -2.4878266453742981e-01
    z[0,3,2]  R234      -2.1776770055294037e-01
    z[0,3,2]  R235      -3.2101023197174072e-01
    z[0,3,2]  R236      -3.1241452693939209e-01
    z[0,3,2]  R237      -2.9116892814636230e-01
    z[0,3,2]  R238      -5.6948333978652954e-01
    z[0,3,2]  R239      -7.1742653846740723e-01
    z[0,3,2]  R240      2.8313699364662170e-01
    z[0,3,2]  R241      -3.8030885625630617e-03
    z[0,3,2]  R242      1.9267649948596954e-01
    z[0,3,2]  R243      4.2524451017379761e-01
    z[0,3,2]  R244      1.6295653581619263e-01
    z[0,3,2]  R245      4.6793825924396515e-02
    z[0,3,2]  R246      2.1531592309474945e-01
    z[0,3,2]  R247      -4.7669090330600739e-02
    z[0,3,2]  R248      1.0567907989025116e-01
    z[0,3,2]  R249      -0.103363998234272
    z[0,3,2]  R250      -2.5924375653266907e-01
    z[0,3,2]  R251      9.1730482876300812e-02
    z[0,3,2]  R252      4.8309704661369324e-01
    z[0,3,2]  R253      9.3876376748085022e-02
    z[0,3,2]  R254      3.8764795660972595e-01
    z[0,3,2]  R255      -0.00233491905964911
    z[0,3,2]  R256      -0.00865908246487379
    z[0,3,2]  R257      5.1715171337127686e-01
    z[0,3,2]  R258      8.3564911037683487e-03
    z[0,3,2]  R259      1.9294353201985359e-02
    z[0,3,2]  R260      -2.1823914349079132e-01
    z[0,3,2]  R261      -3.9614400267601013e-01
    z[0,3,2]  R262      -3.5059735178947449e-01
    z[0,3,2]  R263      -3.1809780001640320e-01
    z[0,3,2]  R264      -3.2828783988952637e-01
    z[0,3,2]  R265      -5.7305407524108887e-01
    z[0,3,2]  R266      1.7797026038169861e-01
    z[0,3,2]  R267      3.8262477517127991e-01
    z[0,3,2]  R268      1.4956396818161011e-01
    z[0,3,2]  R269      2.2001340985298157e-01
    z[0,3,2]  R270      3.6332961916923523e-01
    z[0,3,2]  R271      -2.7133089303970337e-01
    z[0,3,2]  R272      -1.6312594711780548e-01
    z[0,3,2]  R273      -4.2357784695923328e-03
    z[0,3,2]  R274      -1.2825167179107666e-01
    z[0,3,2]  R275      1.2461613118648529e-01
    z[0,3,2]  R276      8.4123559296131134e-02
    z[0,3,2]  R277      1.0180328786373138e-01
    z[0,3,2]  R278      -1.1466205865144730e-01
    z[0,3,2]  R279      1.6040942072868347e-01
    z[0,3,2]  R280      2.4013815820217133e-01
    z[0,3,2]  R281      3.6817422509193420e-01
    z[0,3,2]  R282      -1.8781460821628571e-01
    z[0,3,2]  R283      -2.0988664031028748e-01
    z[0,3,2]  R284      -5.1806366443634033e-01
    z[0,3,2]  R285      -1.5469801425933838e-01
    z[0,3,2]  R286      -3.6768436431884766e-01
    z[0,3,2]  R287      -3.9628565311431885e-01
    z[0,3,2]  R288      -1.6091901063919067e-01
    z[0,3,2]  R289      -1.0736337304115295e-01
    z[0,3,2]  R290      3.1245386600494385e-01
    z[0,3,2]  R291      9.0317949652671814e-02
    z[0,3,2]  R292      1.5061146020889282e-01
    z[0,3,2]  R293      -7.1832996606826782e-01
    z[0,3,2]  R294      1.0902821272611618e-01
    z[0,3,2]  R295      -4.9349340796470642e-01
    z[0,3,2]  R296      -2.2480714321136475e-01
    z[0,3,2]  R297      0.60881507396698
    z[0,3,2]  R298      -3.0338427051901817e-02
    z[0,3,2]  R299      4.3201163411140442e-01
    z[0,3,2]  R300      -8.8836506009101868e-02
    z[0,3,2]  R301      -3.0723696947097778e-01
    z[0,3,2]  R302      -3.7479674816131592e-01
    z[0,3,2]  R303      1.1668688803911209e-01
    z[0,3,2]  R304      -2.1206364035606384e-01
    z[0,3,2]  R305      -3.5514822602272034e-01
    z[0,3,2]  R306      3.0323070287704468e-01
    z[0,3,2]  R307      -5.6406762450933456e-03
    z[0,3,2]  R308      2.9734751582145691e-01
    z[0,3,2]  R309      -2.9981845617294312e-01
    z[0,3,2]  R310      -9.7930260002613068e-02
    z[0,3,2]  R311      1.9548104703426361e-01
    z[0,3,2]  R312      -4.7278085350990295e-01
    z[0,3,2]  R313      -3.1819036602973938e-01
    z[0,3,2]  R314      5.8277076482772827e-01
    z[0,3,2]  R315      -2.1691782400012016e-02
    z[0,3,2]  R316      -9.2265717685222626e-02
    z[0,3,2]  R317      3.5283961892127991e-01
    z[0,3,2]  R318      8.4181100130081177e-02
    z[0,3,2]  R319      5.7402491569519043e-02
    z[0,3,3]  R5        -1
    z[0,3,3]  R32       1
    z[0,3,3]  R212      -1
    z[0,3,3]  R213      1
    z[0,3,3]  R220      2.7934342622756958e-01
    z[0,3,3]  R221      -8.4370121359825134e-02
    z[0,3,3]  R222      -8.4217202663421631e-01
    z[0,3,3]  R223      -6.1375718563795090e-02
    z[0,3,3]  R224      1.5079474449157715e-01
    z[0,3,3]  R225      1.8788080662488937e-02
    z[0,3,3]  R226      -2.0441633462905884e-01
    z[0,3,3]  R227      7.2195190191268921e-01
    z[0,3,3]  R228      4.6824315190315247e-01
    z[0,3,3]  R229      7.0662492513656616e-01
    z[0,3,3]  R230      -2.9991081357002258e-01
    z[0,3,3]  R231      6.6542893648147583e-01
    z[0,3,3]  R232      2.3609901964664459e-01
    z[0,3,3]  R233      -3.6476698517799377e-01
    z[0,3,3]  R234      -4.5867305994033813e-01
    z[0,3,3]  R235      -3.0604410171508789e-01
    z[0,3,3]  R236      -6.4286214113235474e-01
    z[0,3,3]  R237      -4.8425009846687317e-01
    z[0,3,3]  R238      -7.2110451757907867e-02
    z[0,3,3]  R239      -2.3390905559062958e-01
    z[0,3,3]  R240      -2.8752577304840088e-01
    z[0,3,3]  R241      6.7420721054077148e-01
    z[0,3,3]  R242      4.7530794143676758e-01
    z[0,3,3]  R243      0.771931529045105
    z[0,3,3]  R244      -4.4618120789527893e-01
    z[0,3,3]  R245      -3.6692906171083450e-02
    z[0,3,3]  R246      4.5206043124198914e-01
    z[0,3,3]  R247      -1.7114739120006561e-01
    z[0,3,3]  R248      8.5708844661712646e-01
    z[0,3,3]  R249      -1.7338600754737854e-01
    z[0,3,3]  R250      -2.3028573393821716e-01
    z[0,3,3]  R251      -3.9770260453224182e-01
    z[0,3,3]  R252      -1.9360916316509247e-01
    z[0,3,3]  R253      -0.411496102809906
    z[0,3,3]  R254      -0.531631350517273
    z[0,3,3]  R255      -6.0601687431335449e-01
    z[0,3,3]  R256      -8.1906592845916748e-01
    z[0,3,3]  R257      -5.9192508459091187e-01
    z[0,3,3]  R258      -6.6998499631881714e-01
    z[0,3,3]  R259      -5.4565912485122681e-01
    z[0,3,3]  R260      2.2777134180068970e-01
    z[0,3,3]  R261      4.9239867925643921e-01
    z[0,3,3]  R262      1.3949842751026154e-01
    z[0,3,3]  R263      4.3091511726379395e-01
    z[0,3,3]  R264      2.8371140360832214e-01
    z[0,3,3]  R265      9.3603268265724182e-02
    z[0,3,3]  R266      3.9086464047431946e-01
    z[0,3,3]  R267      5.6015163660049438e-01
    z[0,3,3]  R268      5.0423681735992432e-01
    z[0,3,3]  R269      0.244984433054924
    z[0,3,3]  R270      7.1642976999282837e-01
    z[0,3,3]  R271      5.9662669897079468e-01
    z[0,3,3]  R272      -5.3482079505920410e-01
    z[0,3,3]  R273      -5.9529459476470947e-01
    z[0,3,3]  R274      -3.5588398575782776e-01
    z[0,3,3]  R275      -3.5378125309944153e-01
    z[0,3,3]  R276      -5.3700417280197144e-01
    z[0,3,3]  R277      -5.7328951358795166e-01
    z[0,3,3]  R278      -4.2559444904327393e-01
    z[0,3,3]  R279      -3.9520761370658875e-01
    z[0,3,3]  R280      4.8846620321273804e-01
    z[0,3,3]  R281      -2.5209185481071472e-01
    z[0,3,3]  R282      3.9737510681152344e-01
    z[0,3,3]  R283      2.4219667911529541e-01
    z[0,3,3]  R284      -2.5597441941499710e-02
    z[0,3,3]  R285      -2.1603195369243622e-01
    z[0,3,3]  R286      -1.7789797484874725e-01
    z[0,3,3]  R287      -2.3374319076538086e-01
    z[0,3,3]  R288      4.4634109362959862e-03
    z[0,3,3]  R289      -6.6339030861854553e-02
    z[0,3,3]  R290      -4.6688544750213623e-01
    z[0,3,3]  R291      -1.5835982561111450e-01
    z[0,3,3]  R292      -1.8619684875011444e-01
    z[0,3,3]  R293      1.5709747374057770e-01
    z[0,3,3]  R294      9.1810613870620728e-01
    z[0,3,3]  R295      2.7690944075584412e-01
    z[0,3,3]  R296      -5.3713542222976685e-01
    z[0,3,3]  R297      -3.0108150839805603e-01
    z[0,3,3]  R298      -5.8500421047210693e-01
    z[0,3,3]  R299      -9.2559941112995148e-02
    z[0,3,3]  R300      4.6010515093803406e-01
    z[0,3,3]  R301      5.2026033401489258e-01
    z[0,3,3]  R302      -4.6925750374794006e-01
    z[0,3,3]  R303      0.349550724029541
    z[0,3,3]  R304      -2.4423709511756897e-01
    z[0,3,3]  R305      -1.5320216119289398e-01
    z[0,3,3]  R306      -1.4417918026447296e-01
    z[0,3,3]  R307      -2.4125318974256516e-02
    z[0,3,3]  R308      -1.8347722291946411e-01
    z[0,3,3]  R309      -9.7090564668178558e-02
    z[0,3,3]  R310      6.2152963876724243e-01
    z[0,3,3]  R311      5.3341861814260483e-02
    z[0,3,3]  R312      4.5880961418151855e-01
    z[0,3,3]  R313      -7.9395341873168945e-01
    z[0,3,3]  R314      3.8047265261411667e-02
    z[0,3,3]  R315      6.0204431414604187e-02
    z[0,3,3]  R316      2.0130556821823120e-01
    z[0,3,3]  R317      -1.3111500442028046e-01
    z[0,3,3]  R318      1.4534957706928253e-01
    z[0,3,3]  R319      1.8573263287544250e-01
    z[0,3,4]  R6        -1
    z[0,3,4]  R33       1
    z[0,3,4]  R214      -1
    z[0,3,4]  R215      1
    z[0,3,4]  R220      -4.0652030706405640e-01
    z[0,3,4]  R221      8.7469917535781860e-01
    z[0,3,4]  R222      0.202260360121727
    z[0,3,4]  R223      0.550208568572998
    z[0,3,4]  R224      2.4215830862522125e-01
    z[0,3,4]  R225      -9.3159534037113190e-02
    z[0,3,4]  R226      1.4329020678997040e-01
    z[0,3,4]  R227      5.7947766035795212e-02
    z[0,3,4]  R228      0.171248197555542
    z[0,3,4]  R229      -1.0985486954450607e-01
    z[0,3,4]  R230      -3.5780131816864014e-01
    z[0,3,4]  R231      -6.8329066038131714e-02
    z[0,3,4]  R232      -5.2520078420639038e-01
    z[0,3,4]  R233      -5.4033118486404419e-01
    z[0,3,4]  R234      -3.5473233461380005e-01
    z[0,3,4]  R235      -2.8986307978630066e-01
    z[0,3,4]  R236      -2.0128530263900757e-01
    z[0,3,4]  R237      -3.9078646898269653e-01
    z[0,3,4]  R238      -2.6295730471611023e-01
    z[0,3,4]  R239      -2.4100056290626526e-01
    z[0,3,4]  R240      -3.0672853812575340e-02
    z[0,3,4]  R241      1.5795344114303589e-01
    z[0,3,4]  R242      -2.8742568567395210e-02
    z[0,3,4]  R243      -1.1610026657581329e-01
    z[0,3,4]  R244      4.3195828795433044e-02
    z[0,3,4]  R245      1.6449637711048126e-01
    z[0,3,4]  R246      -4.0860839188098907e-02
    z[0,3,4]  R247      -1.5690515935420990e-01
    z[0,3,4]  R248      4.7893274575471878e-02
    z[0,3,4]  R249      -7.0245601236820221e-02
    z[0,3,4]  R250      0.313882052898407
    z[0,3,4]  R251      -0.17757648229599
    z[0,3,4]  R252      2.2189372777938843e-01
    z[0,3,4]  R253      1.3936987519264221e-01
    z[0,3,4]  R254      8.0580234527587891e-02
    z[0,3,4]  R255      3.1831413507461548e-01
    z[0,3,4]  R256      -0.0188454482704401
    z[0,3,4]  R257      1.6043645143508911e-01
    z[0,3,4]  R258      3.3634293079376221e-01
    z[0,3,4]  R259      5.3304746747016907e-02
    z[0,3,4]  R260      -4.5975916087627411e-02
    z[0,3,4]  R261      4.6409916132688522e-02
    z[0,3,4]  R262      1.0899879038333893e-01
    z[0,3,4]  R263      -2.2519369423389435e-01
    z[0,3,4]  R264      -1.8193525075912476e-01
    z[0,3,4]  R265      -1.2886960804462433e-01
    z[0,3,4]  R266      2.3661321401596069e-01
    z[0,3,4]  R267      6.2497023493051529e-02
    z[0,3,4]  R268      7.5856409966945648e-02
    z[0,3,4]  R269      -1.9202180206775665e-01
    z[0,3,4]  R270      1.3539313338696957e-02
    z[0,3,4]  R271      -0.0705077275633812
    z[0,3,4]  R272      2.4219135940074921e-01
    z[0,3,4]  R273      4.8514604568481445e-02
    z[0,3,4]  R274      -0.034210454672575
    z[0,3,4]  R275      -1.3851335644721985e-01
    z[0,3,4]  R276      -9.0229168534278870e-02
    z[0,3,4]  R277      2.8347185254096985e-01
    z[0,3,4]  R278      7.8540280461311340e-02
    z[0,3,4]  R279      -0.149052694439888
    z[0,3,4]  R280      -3.3165118098258972e-01
    z[0,3,4]  R281      4.7080585360527039e-01
    z[0,3,4]  R282      1.0023064911365509e-01
    z[0,3,4]  R283      -1.9911248981952667e-01
    z[0,3,4]  R284      -2.5786471366882324e-01
    z[0,3,4]  R285      -1.5476179122924805e-01
    z[0,3,4]  R286      -5.5405050516128540e-01
    z[0,3,4]  R287      -2.6255378127098083e-01
    z[0,3,4]  R288      4.4327285140752792e-03
    z[0,3,4]  R289      -1.2686847150325775e-01
    z[0,3,4]  R290      4.2611941695213318e-02
    z[0,3,4]  R291      -2.5303918123245239e-01
    z[0,3,4]  R292      -9.9313586950302124e-02
    z[0,3,4]  R293      1.6156564652919769e-01
    z[0,3,4]  R294      -1.4396056532859802e-01
    z[0,3,4]  R295      -2.7360531687736511e-01
    z[0,3,4]  R296      2.3966661095619202e-01
    z[0,3,4]  R297      1.1521905660629272e-01
    z[0,3,4]  R298      -2.0077142119407654e-01
    z[0,3,4]  R299      -2.2211013734340668e-01
    z[0,3,4]  R300      -2.8791356086730957e-01
    z[0,3,4]  R301      2.1502962335944176e-02
    z[0,3,4]  R302      -1.7876857519149780e-01
    z[0,3,4]  R303      2.1146588027477264e-01
    z[0,3,4]  R304      -1.4546494185924530e-01
    z[0,3,4]  R305      -2.7341198921203613e-01
    z[0,3,4]  R306      -4.8977032303810120e-02
    z[0,3,4]  R307      1.4836145937442780e-01
    z[0,3,4]  R308      -2.3469938337802887e-01
    z[0,3,4]  R309      -1.5348145365715027e-01
    z[0,3,4]  R310      3.1884219497442245e-02
    z[0,3,4]  R311      -3.7615177035331726e-01
    z[0,3,4]  R312      1.6664399206638336e-01
    z[0,3,4]  R313      -9.2443741858005524e-02
    z[0,3,4]  R314      1.8520836532115936e-01
    z[0,3,4]  R315      1.2274316698312759e-01
    z[0,3,4]  R316      -0.0294036865234375
    z[0,3,4]  R317      2.8596383333206177e-01
    z[0,3,4]  R318      0.30115807056427
    z[0,3,4]  R319      -4.5189487934112549e-01
    z[0,3,5]  R7        -1
    z[0,3,5]  R34       1
    z[0,3,5]  R216      -1
    z[0,3,5]  R217      1
    z[0,3,5]  R220      2.0829458534717560e-01
    z[0,3,5]  R221      -3.6475688219070435e-01
    z[0,3,5]  R222      4.6943750977516174e-01
    z[0,3,5]  R223      1.1270909570157528e-02
    z[0,3,5]  R224      8.4247022867202759e-01
    z[0,3,5]  R225      -2.4377481639385223e-01
    z[0,3,5]  R226      3.5951547324657440e-03
    z[0,3,5]  R227      -1.4926959574222565e-01
    z[0,3,5]  R228      2.4945066869258881e-01
    z[0,3,5]  R229      -3.8165751844644547e-02
    z[0,3,5]  R230      -4.6699997782707214e-01
    z[0,3,5]  R231      1.3425664603710175e-01
    z[0,3,5]  R232      9.5400094985961914e-02
    z[0,3,5]  R233      4.0605971217155457e-01
    z[0,3,5]  R234      2.4746602773666382e-01
    z[0,3,5]  R235      2.4702483415603638e-01
    z[0,3,5]  R236      1.1016698926687241e-01
    z[0,3,5]  R237      5.3191280364990234e-01
    z[0,3,5]  R238      5.4213577508926392e-01
    z[0,3,5]  R239      2.7041015028953552e-01
    z[0,3,5]  R240      6.1038345098495483e-01
    z[0,3,5]  R241      -4.1404014825820923e-01
    z[0,3,5]  R242      -5.5174940824508667e-01
    z[0,3,5]  R243      -1.0935736447572708e-01
    z[0,3,5]  R244      5.1671421527862549e-01
    z[0,3,5]  R245      3.8030853867530823e-01
    z[0,3,5]  R246      -5.1567190885543823e-01
    z[0,3,5]  R247      3.9104467630386353e-01
    z[0,3,5]  R248      -3.1359159946441650e-01
    z[0,3,5]  R249      5.8405381441116333e-01
    z[0,3,5]  R250      -1.8468056619167328e-01
    z[0,3,5]  R251      -2.4679200351238251e-01
    z[0,3,5]  R252      -9.3075439333915710e-02
    z[0,3,5]  R253      -2.2437015548348427e-02
    z[0,3,5]  R254      3.1480625271797180e-02
    z[0,3,5]  R255      -1.7917092144489288e-01
    z[0,3,5]  R256      -2.0761974155902863e-01
    z[0,3,5]  R257      1.2972506880760193e-01
    z[0,3,5]  R258      -2.0474882423877716e-01
    z[0,3,5]  R259      -3.4563150256872177e-02
    z[0,3,5]  R260      1.7839744687080383e-01
    z[0,3,5]  R261      -5.3027976304292679e-02
    z[0,3,5]  R262      6.5192244946956635e-02
    z[0,3,5]  R263      1.6985410451889038e-01
    z[0,3,5]  R264      -1.0913661867380142e-01
    z[0,3,5]  R265      -2.4268977344036102e-01
    z[0,3,5]  R266      4.9006618559360504e-02
    z[0,3,5]  R267      8.3451326936483383e-03
    z[0,3,5]  R268      -3.5888835787773132e-01
    z[0,3,5]  R269      2.9074522852897644e-01
    z[0,3,5]  R270      -0.226058229804039
    z[0,3,5]  R271      -3.7904545664787292e-01
    z[0,3,5]  R272      -7.0306479930877686e-02
    z[0,3,5]  R273      -4.7628339380025864e-02
    z[0,3,5]  R274      -2.0866043865680695e-01
    z[0,3,5]  R275      2.4772900342941284e-01
    z[0,3,5]  R276      7.1531340479850769e-02
    z[0,3,5]  R277      -5.2819490432739258e-02
    z[0,3,5]  R278      1.6068877279758453e-01
    z[0,3,5]  R279      -9.9442936480045319e-02
    z[0,3,5]  R280      -0.54718416929245
    z[0,3,5]  R281      -0.462632954120636
    z[0,3,5]  R282      7.9853492975234985e-01
    z[0,3,5]  R283      7.0025348663330078e-01
    z[0,3,5]  R284      -1.6692537069320679e-01
    z[0,3,5]  R285      -1.2781160883605480e-02
    z[0,3,5]  R286      0.666630208492279
    z[0,3,5]  R287      8.0307203531265259e-01
    z[0,3,5]  R288      -1.8419317901134491e-01
    z[0,3,5]  R289      1.7388838529586792e-01
    z[0,3,5]  R290      -5.7286724448204041e-02
    z[0,3,5]  R291      0.718159019947052
    z[0,3,5]  R292      3.6404278874397278e-01
    z[0,3,5]  R293      0.460068941116333
    z[0,3,5]  R294      2.9649391770362854e-01
    z[0,3,5]  R295      6.6731852293014526e-01
    z[0,3,5]  R296      -4.3767508864402771e-01
    z[0,3,5]  R297      -5.4317567497491837e-02
    z[0,3,5]  R298      5.4549443721771240e-01
    z[0,3,5]  R299      4.6343334019184113e-02
    z[0,3,5]  R300      -1.0235474258661270e-01
    z[0,3,5]  R301      -4.3656334280967712e-01
    z[0,3,5]  R302      4.0708357095718384e-01
    z[0,3,5]  R303      -2.6709970831871033e-01
    z[0,3,5]  R304      3.8735663890838623e-01
    z[0,3,5]  R305      -9.8011508584022522e-02
    z[0,3,5]  R306      -3.4187024831771851e-01
    z[0,3,5]  R307      3.1506073474884033e-01
    z[0,3,5]  R308      1.2127444893121719e-01
    z[0,3,5]  R309      -1.1943063884973526e-01
    z[0,3,5]  R310      -2.2009097039699554e-01
    z[0,3,5]  R311      -0.613559365272522
    z[0,3,5]  R312      -5.5540448427200317e-01
    z[0,3,5]  R313      -2.3913922905921936e-01
    z[0,3,5]  R314      3.8042879104614258e-01
    z[0,3,5]  R315      -6.5704119205474854e-01
    z[0,3,5]  R316      0.292542964220047
    z[0,3,5]  R317      1.0635441541671753e-01
    z[0,3,5]  R318      -1.6225801780819893e-02
    z[0,3,5]  R319      7.6356399059295654e-01
    z[0,3,6]  R8        -1
    z[0,3,6]  R35       1
    z[0,3,6]  R218      -1
    z[0,3,6]  R219      1
    z[0,3,6]  R220      4.6725142002105713e-01
    z[0,3,6]  R221      1.6382379829883575e-01
    z[0,3,6]  R222      1.0421517491340637e-01
    z[0,3,6]  R223      1.5747340023517609e-01
    z[0,3,6]  R224      2.5399681925773621e-01
    z[0,3,6]  R225      6.3457474112510681e-02
    z[0,3,6]  R226      1.0275022685527802e-01
    z[0,3,6]  R227      5.8797508478164673e-02
    z[0,3,6]  R228      5.4597449302673340e-01
    z[0,3,6]  R229      4.0711298584938049e-01
    z[0,3,6]  R230      -2.7359450235962868e-02
    z[0,3,6]  R231      -1.4401340484619141e-01
    z[0,3,6]  R232      -6.5099443309009075e-03
    z[0,3,6]  R233      -2.6664644479751587e-02
    z[0,3,6]  R234      -2.3657806217670441e-01
    z[0,3,6]  R235      3.7983467336744070e-03
    z[0,3,6]  R236      1.1799464374780655e-01
    z[0,3,6]  R237      3.2538682222366333e-01
    z[0,3,6]  R238      -2.0820635557174683e-01
    z[0,3,6]  R239      -1.3016252219676971e-01
    z[0,3,6]  R240      8.3052806556224823e-02
    z[0,3,6]  R241      -1.8609504401683807e-01
    z[0,3,6]  R242      -2.2193601727485657e-01
    z[0,3,6]  R243      1.6955780982971191e-01
    z[0,3,6]  R244      -5.8242619037628174e-01
    z[0,3,6]  R245      1.0649064928293228e-01
    z[0,3,6]  R246      4.9925157427787781e-01
    z[0,3,6]  R247      -7.1567870676517487e-02
    z[0,3,6]  R248      3.1157466769218445e-01
    z[0,3,6]  R249      1.3006825745105743e-01
    z[0,3,6]  R250      -5.4451610893011093e-02
    z[0,3,6]  R251      -0.385977566242218
    z[0,3,6]  R252      -2.0393805205821991e-01
    z[0,3,6]  R253      4.6617004275321960e-01
    z[0,3,6]  R254      -0.387576699256897
    z[0,3,6]  R255      -3.3300212025642395e-01
    z[0,3,6]  R256      4.6243309974670410e-02
    z[0,3,6]  R257      6.3250800594687462e-03
    z[0,3,6]  R258      2.3546755313873291e-01
    z[0,3,6]  R259      7.6464921236038208e-02
    z[0,3,6]  R260      -1.3288977742195129e-01
    z[0,3,6]  R261      1.8841318786144257e-02
    z[0,3,6]  R262      -9.7866818308830261e-02
    z[0,3,6]  R263      -0.0775921568274498
    z[0,3,6]  R264      1.8998172879219055e-01
    z[0,3,6]  R265      1.1523085087537766e-01
    z[0,3,6]  R266      1.6446661949157715e-01
    z[0,3,6]  R267      2.0641405880451202e-01
    z[0,3,6]  R268      2.5323063135147095e-01
    z[0,3,6]  R269      1.8000033497810364e-01
    z[0,3,6]  R270      -9.4732239842414856e-02
    z[0,3,6]  R271      -1.4579197764396667e-01
    z[0,3,6]  R272      -4.5361623167991638e-02
    z[0,3,6]  R273      -7.9353392124176025e-02
    z[0,3,6]  R274      2.2805716097354889e-01
    z[0,3,6]  R275      1.0872198641300201e-01
    z[0,3,6]  R276      -7.5266361236572266e-02
    z[0,3,6]  R277      -8.2955874502658844e-02
    z[0,3,6]  R278      1.8072535097599030e-01
    z[0,3,6]  R279      1.6203030943870544e-01
    z[0,3,6]  R280      2.6618912816047668e-01
    z[0,3,6]  R281      -2.3902162909507751e-02
    z[0,3,6]  R282      -1.0881227999925613e-01
    z[0,3,6]  R283      2.6119291782379150e-01
    z[0,3,6]  R284      -7.6266713440418243e-02
    z[0,3,6]  R285      6.3522164709866047e-03
    z[0,3,6]  R286      3.5366213414818048e-03
    z[0,3,6]  R287      -5.9513486921787262e-02
    z[0,3,6]  R288      1.8727298080921173e-01
    z[0,3,6]  R289      2.1614888310432434e-01
    z[0,3,6]  R290      -9.7504250705242157e-02
    z[0,3,6]  R291      -2.4339678883552551e-01
    z[0,3,6]  R292      -1.3363434374332428e-01
    z[0,3,6]  R293      -8.7864056229591370e-02
    z[0,3,6]  R294      5.2130836993455887e-03
    z[0,3,6]  R295      1.1075641214847565e-01
    z[0,3,6]  R296      3.4520891308784485e-01
    z[0,3,6]  R297      -8.6348660290241241e-02
    z[0,3,6]  R298      8.7730973958969116e-02
    z[0,3,6]  R299      -0.294983834028244
    z[0,3,6]  R300      -3.8469800353050232e-01
    z[0,3,6]  R301      -4.9401441216468811e-01
    z[0,3,6]  R302      1.1346577107906342e-01
    z[0,3,6]  R303      -4.6004495024681091e-01
    z[0,3,6]  R304      -1.3438005745410919e-01
    z[0,3,6]  R305      -1.7469539307057858e-03
    z[0,3,6]  R306      1.4967045187950134e-01
    z[0,3,6]  R307      -2.0855763554573059e-01
    z[0,3,6]  R308      -4.2886976152658463e-02
    z[0,3,6]  R309      -3.6438378691673279e-01
    z[0,3,6]  R310      -3.7644156813621521e-01
    z[0,3,6]  R311      -0.290274441242218
    z[0,3,6]  R312      -2.1499957144260406e-01
    z[0,3,6]  R313      4.1045309044420719e-03
    z[0,3,6]  R314      -4.7545540332794189e-01
    z[0,3,6]  R315      3.7156778573989868e-01
    z[0,3,6]  R316      -0.0534537211060524
    z[0,3,6]  R317      3.0226361751556396e-01
    z[0,3,6]  R318      1.2297625839710236e-01
    z[0,3,6]  R319      -1.8238408863544464e-01
    z[3,0,0]  R2        1
    z[3,0,0]  R29       -1
    z[3,0,0]  R320      -1
    z[3,0,0]  R321      1
    z[3,0,0]  R334      4.3805766105651855e-01
    z[3,0,0]  R335      0.417502224445343
    z[3,0,0]  R336      0.575057327747345
    z[3,0,0]  R337      7.2431176900863647e-02
    z[3,0,0]  R338      1.5262040495872498e-01
    z[3,0,0]  R339      4.0876439213752747e-01
    z[3,0,0]  R340      2.4220088124275208e-01
    z[3,0,0]  R341      2.1401388943195343e-01
    z[3,0,0]  R342      4.3158498406410217e-01
    z[3,0,0]  R343      7.0104628801345825e-01
    z[3,0,0]  R344      8.0959171056747437e-01
    z[3,0,0]  R345      6.4698415994644165e-01
    z[3,0,0]  R346      7.3615294694900513e-01
    z[3,0,0]  R347      7.3598664999008179e-01
    z[3,0,0]  R348      7.0550125837326050e-01
    z[3,0,0]  R349      6.3437575101852417e-01
    z[3,0,0]  R350      5.7536059617996216e-01
    z[3,0,0]  R351      5.6623983383178711e-01
    z[3,0,0]  R352      6.3096511363983154e-01
    z[3,0,0]  R353      6.5490937232971191e-01
    z[3,0,0]  R354      -1.9726440310478210e-01
    z[3,0,0]  R355      -1.0529028624296188e-01
    z[3,0,0]  R356      -7.1863353252410889e-01
    z[3,0,0]  R357      -7.8457134962081909e-01
    z[3,0,0]  R358      -0.79290771484375
    z[3,0,0]  R359      -7.3468130826950073e-01
    z[3,0,0]  R360      -6.3682740926742554e-01
    z[3,0,0]  R361      -6.2035316228866577e-01
    z[3,0,0]  R362      -6.7900937795639038e-01
    z[3,0,0]  R363      -6.7543321847915649e-01
    z[3,0,0]  R364      4.1349714994430542e-01
    z[3,0,0]  R365      5.1700967550277710e-01
    z[3,0,0]  R366      -1.0512983798980713e-01
    z[3,0,0]  R367      -1.7748099565505981e-01
    z[3,0,0]  R368      -7.1416527032852173e-01
    z[3,0,0]  R369      -7.9319137334823608e-01
    z[3,0,0]  R370      -1.2548317201435566e-02
    z[3,0,0]  R371      -7.7411487698554993e-02
    z[3,0,0]  R372      -8.6458724737167358e-01
    z[3,0,0]  R373      -9.1031205654144287e-01
    z[3,0,0]  R374      7.3104846477508545e-01
    z[3,0,0]  R375      2.9177516698837280e-01
    z[3,0,0]  R376      2.8340291976928711e-01
    z[3,0,0]  R377      -4.5324318110942841e-02
    z[3,0,0]  R378      1.8512003123760223e-01
    z[3,0,0]  R379      -1.1372501403093338e-01
    z[3,0,0]  R380      5.3195875138044357e-02
    z[3,0,0]  R381      -6.2801039218902588e-01
    z[3,0,0]  R382      1.1845371872186661e-01
    z[3,0,0]  R383      -7.9882496595382690e-01
    z[3,0,0]  R384      0.524105429649353
    z[3,0,0]  R385      4.0315771102905273e-01
    z[3,0,0]  R386      2.0439341664314270e-01
    z[3,0,0]  R387      0.686012327671051
    z[3,0,0]  R388      -7.8146022558212280e-01
    z[3,0,0]  R389      -8.6590969562530518e-01
    z[3,0,0]  R390      -7.6497918367385864e-01
    z[3,0,0]  R391      -8.5123002529144287e-01
    z[3,0,0]  R392      -8.9121866226196289e-01
    z[3,0,0]  R393      -0.826116681098938
    z[3,0,0]  R394      5.2226793766021729e-01
    z[3,0,0]  R395      4.6512582898139954e-01
    z[3,0,0]  R396      1.1516742408275604e-01
    z[3,0,0]  R397      3.5153231024742126e-01
    z[3,0,0]  R398      5.0296396017074585e-01
    z[3,0,0]  R399      -5.8018577098846436e-01
    z[3,0,0]  R400      -8.2047873735427856e-01
    z[3,0,0]  R401      -8.1746226549148560e-01
    z[3,0,0]  R402      -8.9487850666046143e-01
    z[3,0,0]  R403      8.7175302207469940e-02
    z[3,0,0]  R404      5.8140856027603149e-01
    z[3,0,0]  R405      -1.9250120222568512e-01
    z[3,0,0]  R406      5.9856560081243515e-02
    z[3,0,0]  R407      -4.9915939569473267e-02
    z[3,0,0]  R408      -3.6315965652465820e-01
    z[3,0,0]  R409      5.3551656007766724e-01
    z[3,0,0]  R410      3.1531623005867004e-01
    z[3,0,0]  R411      -2.2023370862007141e-01
    z[3,0,0]  R412      2.2594654560089111e-01
    z[3,0,0]  R413      0.123531773686409
    z[3,0,0]  R414      1.8905134499073029e-01
    z[3,0,0]  R415      -2.6604864001274109e-01
    z[3,0,0]  R416      -1.4337065815925598e-01
    z[3,0,0]  R417      -3.0445605516433716e-01
    z[3,0,0]  R418      -3.7949305772781372e-01
    z[3,0,0]  R419      -3.9805746078491211e-01
    z[3,0,0]  R420      -3.2808291912078857e-01
    z[3,0,0]  R421      -2.6863589882850647e-01
    z[3,0,0]  R422      -3.7944170832633972e-01
    z[3,0,0]  R423      -3.1133583188056946e-01
    z[3,0,0]  R424      -5.1333421468734741e-01
    z[3,0,0]  R425      3.9979004859924316e-01
    z[3,0,0]  R426      -0.0194241926074028
    z[3,0,0]  R427      2.9889246821403503e-01
    z[3,0,0]  R428      -4.0776455402374268e-01
    z[3,0,0]  R429      1.8535171449184418e-01
    z[3,0,0]  R430      -7.6386652654036880e-04
    z[3,0,0]  R431      2.3205760121345520e-01
    z[3,0,0]  R432      -0.0546276830136776
    z[3,0,0]  R433      9.5886774361133575e-02
    z[3,0,1]  R3        1
    z[3,0,1]  R30       -1
    z[3,0,1]  R322      -1
    z[3,0,1]  R323      1
    z[3,0,1]  R334      -7.4315059185028076e-01
    z[3,0,1]  R335      -6.4629071950912476e-01
    z[3,0,1]  R336      -5.4676425457000732e-01
    z[3,0,1]  R337      -7.6116353273391724e-01
    z[3,0,1]  R338      -6.2137299776077271e-01
    z[3,0,1]  R339      -4.7046065330505371e-01
    z[3,0,1]  R340      -4.7412568330764771e-01
    z[3,0,1]  R341      -5.4200416803359985e-01
    z[3,0,1]  R342      -3.9279901981353760e-01
    z[3,0,1]  R343      -4.4781142473220825e-01
    z[3,0,1]  R344      4.3983411788940430e-01
    z[3,0,1]  R345      4.2036175727844238e-01
    z[3,0,1]  R346      5.3850877285003662e-01
    z[3,0,1]  R347      2.9302990436553955e-01
    z[3,0,1]  R348      4.8259556293487549e-01
    z[3,0,1]  R349      4.1428366303443909e-01
    z[3,0,1]  R350      6.3172364234924316e-01
    z[3,0,1]  R351      4.1547408699989319e-01
    z[3,0,1]  R352      3.5577812790870667e-01
    z[3,0,1]  R353      5.5575639009475708e-01
    z[3,0,1]  R354      -5.0551635026931763e-01
    z[3,0,1]  R355      -6.2404167652130127e-01
    z[3,0,1]  R356      3.2444596290588379e-01
    z[3,0,1]  R357      1.3832947611808777e-01
    z[3,0,1]  R358      3.6259597539901733e-01
    z[3,0,1]  R359      0.476630836725235
    z[3,0,1]  R360      5.2922356128692627e-01
    z[3,0,1]  R361      4.3140381574630737e-01
    z[3,0,1]  R362      5.2916640043258667e-01
    z[3,0,1]  R363      5.5091768503189087e-01
    z[3,0,1]  R364      -2.2911764681339264e-01
    z[3,0,1]  R365      3.1199318170547485e-01
    z[3,0,1]  R366      3.6908298730850220e-01
    z[3,0,1]  R367      0.517268180847168
    z[3,0,1]  R368      3.4748798608779907e-01
    z[3,0,1]  R369      -0.525443971157074
    z[3,0,1]  R370      -2.8569707274436951e-01
    z[3,0,1]  R371      -2.5481000542640686e-01
    z[3,0,1]  R372      -3.9693346619606018e-01
    z[3,0,1]  R373      -2.4970203638076782e-01
    z[3,0,1]  R374      3.6790484189987183e-01
    z[3,0,1]  R375      4.9255335330963135e-01
    z[3,0,1]  R376      8.3790290355682373e-01
    z[3,0,1]  R377      0.460196852684021
    z[3,0,1]  R378      -4.7581657767295837e-02
    z[3,0,1]  R379      3.6662113666534424e-01
    z[3,0,1]  R380      5.3846889734268188e-01
    z[3,0,1]  R381      3.4729701280593872e-01
    z[3,0,1]  R382      5.4520481824874878e-01
    z[3,0,1]  R383      1.6787196695804596e-01
    z[3,0,1]  R384      -5.1416093111038208e-01
    z[3,0,1]  R385      -1.9312760233879089e-01
    z[3,0,1]  R386      6.2209200859069824e-01
    z[3,0,1]  R387      -0.256678968667984
    z[3,0,1]  R388      3.0892390012741089e-01
    z[3,0,1]  R389      1.2741953134536743e-01
    z[3,0,1]  R390      4.0049365162849426e-01
    z[3,0,1]  R391      3.3169683814048767e-01
    z[3,0,1]  R392      1.0963108390569687e-01
    z[3,0,1]  R393      2.1821531653404236e-01
    z[3,0,1]  R394      -3.7440881133079529e-01
    z[3,0,1]  R395      -0.374693363904953
    z[3,0,1]  R396      -4.1260075569152832e-01
    z[3,0,1]  R397      0.281189888715744
    z[3,0,1]  R398      -2.9525252059102058e-02
    z[3,0,1]  R399      -2.7286946773529053e-01
    z[3,0,1]  R400      -4.3413645029067993e-01
    z[3,0,1]  R401      0.0749564915895462
    z[3,0,1]  R402      -2.5474876165390015e-01
    z[3,0,1]  R403      -3.6620470881462097e-01
    z[3,0,1]  R404      2.2264511883258820e-01
    z[3,0,1]  R405      1.6231055557727814e-01
    z[3,0,1]  R406      1.1129427701234818e-01
    z[3,0,1]  R407      6.8842776119709015e-02
    z[3,0,1]  R408      -1.0296688415110111e-02
    z[3,0,1]  R409      -7.9762744903564453e-01
    z[3,0,1]  R410      -8.2727664709091187e-01
    z[3,0,1]  R411      -6.1877506971359253e-01
    z[3,0,1]  R412      -5.4082858562469482e-01
    z[3,0,1]  R413      2.2063447535037994e-01
    z[3,0,1]  R414      2.8825476765632629e-01
    z[3,0,1]  R415      6.5079480409622192e-01
    z[3,0,1]  R416      6.5550971031188965e-01
    z[3,0,1]  R417      0.504782497882843
    z[3,0,1]  R418      5.9593433141708374e-01
    z[3,0,1]  R419      7.0695358514785767e-01
    z[3,0,1]  R420      5.6116998195648193e-01
    z[3,0,1]  R421      2.5891184806823730e-01
    z[3,0,1]  R422      3.4656202793121338e-01
    z[3,0,1]  R423      4.3070918321609497e-01
    z[3,0,1]  R424      4.3959498405456543e-01
    z[3,0,1]  R425      -3.9317718148231506e-01
    z[3,0,1]  R426      -0.618119478225708
    z[3,0,1]  R427      -2.8242516517639160e-01
    z[3,0,1]  R428      -3.9775301702320576e-03
    z[3,0,1]  R429      -8.8265210390090942e-01
    z[3,0,1]  R430      -4.8212072253227234e-01
    z[3,0,1]  R431      -8.5552811622619629e-01
    z[3,0,1]  R432      -2.3137611150741577e-01
    z[3,0,1]  R433      -7.6621663570404053e-01
    z[3,0,2]  R4        1
    z[3,0,2]  R31       -1
    z[3,0,2]  R324      -1
    z[3,0,2]  R325      1
    z[3,0,2]  R334      -2.5924375653266907e-01
    z[3,0,2]  R335      9.1730482876300812e-02
    z[3,0,2]  R336      4.8309704661369324e-01
    z[3,0,2]  R337      9.3876376748085022e-02
    z[3,0,2]  R338      3.8764795660972595e-01
    z[3,0,2]  R339      -0.00233491905964911
    z[3,0,2]  R340      -0.00865908246487379
    z[3,0,2]  R341      5.1715171337127686e-01
    z[3,0,2]  R342      8.3564911037683487e-03
    z[3,0,2]  R343      1.9294353201985359e-02
    z[3,0,2]  R344      -2.1823914349079132e-01
    z[3,0,2]  R345      -3.9614400267601013e-01
    z[3,0,2]  R346      -3.5059735178947449e-01
    z[3,0,2]  R347      -3.1809780001640320e-01
    z[3,0,2]  R348      -3.2828783988952637e-01
    z[3,0,2]  R349      -5.7305407524108887e-01
    z[3,0,2]  R350      1.7797026038169861e-01
    z[3,0,2]  R351      3.8262477517127991e-01
    z[3,0,2]  R352      1.4956396818161011e-01
    z[3,0,2]  R353      2.2001340985298157e-01
    z[3,0,2]  R354      3.6332961916923523e-01
    z[3,0,2]  R355      -2.7133089303970337e-01
    z[3,0,2]  R356      -1.6312594711780548e-01
    z[3,0,2]  R357      -4.2357784695923328e-03
    z[3,0,2]  R358      -1.2825167179107666e-01
    z[3,0,2]  R359      1.2461613118648529e-01
    z[3,0,2]  R360      8.4123559296131134e-02
    z[3,0,2]  R361      1.0180328786373138e-01
    z[3,0,2]  R362      -1.1466205865144730e-01
    z[3,0,2]  R363      1.6040942072868347e-01
    z[3,0,2]  R364      2.4013815820217133e-01
    z[3,0,2]  R365      3.6817422509193420e-01
    z[3,0,2]  R366      -1.8781460821628571e-01
    z[3,0,2]  R367      -2.0988664031028748e-01
    z[3,0,2]  R368      -5.1806366443634033e-01
    z[3,0,2]  R369      -1.5469801425933838e-01
    z[3,0,2]  R370      -3.6768436431884766e-01
    z[3,0,2]  R371      -3.9628565311431885e-01
    z[3,0,2]  R372      -1.6091901063919067e-01
    z[3,0,2]  R373      -1.0736337304115295e-01
    z[3,0,2]  R374      3.1245386600494385e-01
    z[3,0,2]  R375      9.0317949652671814e-02
    z[3,0,2]  R376      1.5061146020889282e-01
    z[3,0,2]  R377      -7.1832996606826782e-01
    z[3,0,2]  R378      1.0902821272611618e-01
    z[3,0,2]  R379      -4.9349340796470642e-01
    z[3,0,2]  R380      -2.2480714321136475e-01
    z[3,0,2]  R381      0.60881507396698
    z[3,0,2]  R382      -3.0338427051901817e-02
    z[3,0,2]  R383      4.3201163411140442e-01
    z[3,0,2]  R384      -8.8836506009101868e-02
    z[3,0,2]  R385      -3.0723696947097778e-01
    z[3,0,2]  R386      -3.7479674816131592e-01
    z[3,0,2]  R387      1.1668688803911209e-01
    z[3,0,2]  R388      -2.1206364035606384e-01
    z[3,0,2]  R389      -3.5514822602272034e-01
    z[3,0,2]  R390      3.0323070287704468e-01
    z[3,0,2]  R391      -5.6406762450933456e-03
    z[3,0,2]  R392      2.9734751582145691e-01
    z[3,0,2]  R393      -2.9981845617294312e-01
    z[3,0,2]  R394      -9.7930260002613068e-02
    z[3,0,2]  R395      1.9548104703426361e-01
    z[3,0,2]  R396      -4.7278085350990295e-01
    z[3,0,2]  R397      -3.1819036602973938e-01
    z[3,0,2]  R398      5.8277076482772827e-01
    z[3,0,2]  R399      -2.1691782400012016e-02
    z[3,0,2]  R400      -9.2265717685222626e-02
    z[3,0,2]  R401      3.5283961892127991e-01
    z[3,0,2]  R402      8.4181100130081177e-02
    z[3,0,2]  R403      5.7402491569519043e-02
    z[3,0,2]  R404      -3.2770600914955139e-01
    z[3,0,2]  R405      -6.7050859332084656e-02
    z[3,0,2]  R406      -5.1336042582988739e-02
    z[3,0,2]  R407      -8.1323289871215820e-01
    z[3,0,2]  R408      1.1117040365934372e-01
    z[3,0,2]  R409      6.7289404571056366e-02
    z[3,0,2]  R410      -3.7855041027069092e-01
    z[3,0,2]  R411      1.3529086112976074e-01
    z[3,0,2]  R412      2.1808530390262604e-01
    z[3,0,2]  R413      5.0742077827453613e-01
    z[3,0,2]  R414      6.6660559177398682e-01
    z[3,0,2]  R415      1.3948100805282593e-01
    z[3,0,2]  R416      -4.5719772577285767e-01
    z[3,0,2]  R417      -2.4878266453742981e-01
    z[3,0,2]  R418      -2.1776770055294037e-01
    z[3,0,2]  R419      -3.2101023197174072e-01
    z[3,0,2]  R420      -3.1241452693939209e-01
    z[3,0,2]  R421      -2.9116892814636230e-01
    z[3,0,2]  R422      -5.6948333978652954e-01
    z[3,0,2]  R423      -7.1742653846740723e-01
    z[3,0,2]  R424      2.8313699364662170e-01
    z[3,0,2]  R425      -3.8030885625630617e-03
    z[3,0,2]  R426      1.9267649948596954e-01
    z[3,0,2]  R427      4.2524451017379761e-01
    z[3,0,2]  R428      1.6295653581619263e-01
    z[3,0,2]  R429      4.6793825924396515e-02
    z[3,0,2]  R430      2.1531592309474945e-01
    z[3,0,2]  R431      -4.7669090330600739e-02
    z[3,0,2]  R432      1.0567907989025116e-01
    z[3,0,2]  R433      -0.103363998234272
    z[3,0,3]  R5        1
    z[3,0,3]  R32       -1
    z[3,0,3]  R326      -1
    z[3,0,3]  R327      1
    z[3,0,3]  R334      -2.3028573393821716e-01
    z[3,0,3]  R335      -3.9770260453224182e-01
    z[3,0,3]  R336      -1.9360916316509247e-01
    z[3,0,3]  R337      -0.411496102809906
    z[3,0,3]  R338      -0.531631350517273
    z[3,0,3]  R339      -6.0601687431335449e-01
    z[3,0,3]  R340      -8.1906592845916748e-01
    z[3,0,3]  R341      -5.9192508459091187e-01
    z[3,0,3]  R342      -6.6998499631881714e-01
    z[3,0,3]  R343      -5.4565912485122681e-01
    z[3,0,3]  R344      2.2777134180068970e-01
    z[3,0,3]  R345      4.9239867925643921e-01
    z[3,0,3]  R346      1.3949842751026154e-01
    z[3,0,3]  R347      4.3091511726379395e-01
    z[3,0,3]  R348      2.8371140360832214e-01
    z[3,0,3]  R349      9.3603268265724182e-02
    z[3,0,3]  R350      3.9086464047431946e-01
    z[3,0,3]  R351      5.6015163660049438e-01
    z[3,0,3]  R352      5.0423681735992432e-01
    z[3,0,3]  R353      0.244984433054924
    z[3,0,3]  R354      7.1642976999282837e-01
    z[3,0,3]  R355      5.9662669897079468e-01
    z[3,0,3]  R356      -5.3482079505920410e-01
    z[3,0,3]  R357      -5.9529459476470947e-01
    z[3,0,3]  R358      -3.5588398575782776e-01
    z[3,0,3]  R359      -3.5378125309944153e-01
    z[3,0,3]  R360      -5.3700417280197144e-01
    z[3,0,3]  R361      -5.7328951358795166e-01
    z[3,0,3]  R362      -4.2559444904327393e-01
    z[3,0,3]  R363      -3.9520761370658875e-01
    z[3,0,3]  R364      4.8846620321273804e-01
    z[3,0,3]  R365      -2.5209185481071472e-01
    z[3,0,3]  R366      3.9737510681152344e-01
    z[3,0,3]  R367      2.4219667911529541e-01
    z[3,0,3]  R368      -2.5597441941499710e-02
    z[3,0,3]  R369      -2.1603195369243622e-01
    z[3,0,3]  R370      -1.7789797484874725e-01
    z[3,0,3]  R371      -2.3374319076538086e-01
    z[3,0,3]  R372      4.4634109362959862e-03
    z[3,0,3]  R373      -6.6339030861854553e-02
    z[3,0,3]  R374      -4.6688544750213623e-01
    z[3,0,3]  R375      -1.5835982561111450e-01
    z[3,0,3]  R376      -1.8619684875011444e-01
    z[3,0,3]  R377      1.5709747374057770e-01
    z[3,0,3]  R378      9.1810613870620728e-01
    z[3,0,3]  R379      2.7690944075584412e-01
    z[3,0,3]  R380      -5.3713542222976685e-01
    z[3,0,3]  R381      -3.0108150839805603e-01
    z[3,0,3]  R382      -5.8500421047210693e-01
    z[3,0,3]  R383      -9.2559941112995148e-02
    z[3,0,3]  R384      4.6010515093803406e-01
    z[3,0,3]  R385      5.2026033401489258e-01
    z[3,0,3]  R386      -4.6925750374794006e-01
    z[3,0,3]  R387      0.349550724029541
    z[3,0,3]  R388      -2.4423709511756897e-01
    z[3,0,3]  R389      -1.5320216119289398e-01
    z[3,0,3]  R390      -1.4417918026447296e-01
    z[3,0,3]  R391      -2.4125318974256516e-02
    z[3,0,3]  R392      -1.8347722291946411e-01
    z[3,0,3]  R393      -9.7090564668178558e-02
    z[3,0,3]  R394      6.2152963876724243e-01
    z[3,0,3]  R395      5.3341861814260483e-02
    z[3,0,3]  R396      4.5880961418151855e-01
    z[3,0,3]  R397      -7.9395341873168945e-01
    z[3,0,3]  R398      3.8047265261411667e-02
    z[3,0,3]  R399      6.0204431414604187e-02
    z[3,0,3]  R400      2.0130556821823120e-01
    z[3,0,3]  R401      -1.3111500442028046e-01
    z[3,0,3]  R402      1.4534957706928253e-01
    z[3,0,3]  R403      1.8573263287544250e-01
    z[3,0,3]  R404      2.7934342622756958e-01
    z[3,0,3]  R405      -8.4370121359825134e-02
    z[3,0,3]  R406      -8.4217202663421631e-01
    z[3,0,3]  R407      -6.1375718563795090e-02
    z[3,0,3]  R408      1.5079474449157715e-01
    z[3,0,3]  R409      1.8788080662488937e-02
    z[3,0,3]  R410      -2.0441633462905884e-01
    z[3,0,3]  R411      7.2195190191268921e-01
    z[3,0,3]  R412      4.6824315190315247e-01
    z[3,0,3]  R413      7.0662492513656616e-01
    z[3,0,3]  R414      -2.9991081357002258e-01
    z[3,0,3]  R415      6.6542893648147583e-01
    z[3,0,3]  R416      2.3609901964664459e-01
    z[3,0,3]  R417      -3.6476698517799377e-01
    z[3,0,3]  R418      -4.5867305994033813e-01
    z[3,0,3]  R419      -3.0604410171508789e-01
    z[3,0,3]  R420      -6.4286214113235474e-01
    z[3,0,3]  R421      -4.8425009846687317e-01
    z[3,0,3]  R422      -7.2110451757907867e-02
    z[3,0,3]  R423      -2.3390905559062958e-01
    z[3,0,3]  R424      -2.8752577304840088e-01
    z[3,0,3]  R425      6.7420721054077148e-01
    z[3,0,3]  R426      4.7530794143676758e-01
    z[3,0,3]  R427      0.771931529045105
    z[3,0,3]  R428      -4.4618120789527893e-01
    z[3,0,3]  R429      -3.6692906171083450e-02
    z[3,0,3]  R430      4.5206043124198914e-01
    z[3,0,3]  R431      -1.7114739120006561e-01
    z[3,0,3]  R432      8.5708844661712646e-01
    z[3,0,3]  R433      -1.7338600754737854e-01
    z[3,0,4]  R6        1
    z[3,0,4]  R33       -1
    z[3,0,4]  R328      -1
    z[3,0,4]  R329      1
    z[3,0,4]  R334      0.313882052898407
    z[3,0,4]  R335      -0.17757648229599
    z[3,0,4]  R336      2.2189372777938843e-01
    z[3,0,4]  R337      1.3936987519264221e-01
    z[3,0,4]  R338      8.0580234527587891e-02
    z[3,0,4]  R339      3.1831413507461548e-01
    z[3,0,4]  R340      -0.0188454482704401
    z[3,0,4]  R341      1.6043645143508911e-01
    z[3,0,4]  R342      3.3634293079376221e-01
    z[3,0,4]  R343      5.3304746747016907e-02
    z[3,0,4]  R344      -4.5975916087627411e-02
    z[3,0,4]  R345      4.6409916132688522e-02
    z[3,0,4]  R346      1.0899879038333893e-01
    z[3,0,4]  R347      -2.2519369423389435e-01
    z[3,0,4]  R348      -1.8193525075912476e-01
    z[3,0,4]  R349      -1.2886960804462433e-01
    z[3,0,4]  R350      2.3661321401596069e-01
    z[3,0,4]  R351      6.2497023493051529e-02
    z[3,0,4]  R352      7.5856409966945648e-02
    z[3,0,4]  R353      -1.9202180206775665e-01
    z[3,0,4]  R354      1.3539313338696957e-02
    z[3,0,4]  R355      -0.0705077275633812
    z[3,0,4]  R356      2.4219135940074921e-01
    z[3,0,4]  R357      4.8514604568481445e-02
    z[3,0,4]  R358      -0.034210454672575
    z[3,0,4]  R359      -1.3851335644721985e-01
    z[3,0,4]  R360      -9.0229168534278870e-02
    z[3,0,4]  R361      2.8347185254096985e-01
    z[3,0,4]  R362      7.8540280461311340e-02
    z[3,0,4]  R363      -0.149052694439888
    z[3,0,4]  R364      -3.3165118098258972e-01
    z[3,0,4]  R365      4.7080585360527039e-01
    z[3,0,4]  R366      1.0023064911365509e-01
    z[3,0,4]  R367      -1.9911248981952667e-01
    z[3,0,4]  R368      -2.5786471366882324e-01
    z[3,0,4]  R369      -1.5476179122924805e-01
    z[3,0,4]  R370      -5.5405050516128540e-01
    z[3,0,4]  R371      -2.6255378127098083e-01
    z[3,0,4]  R372      4.4327285140752792e-03
    z[3,0,4]  R373      -1.2686847150325775e-01
    z[3,0,4]  R374      4.2611941695213318e-02
    z[3,0,4]  R375      -2.5303918123245239e-01
    z[3,0,4]  R376      -9.9313586950302124e-02
    z[3,0,4]  R377      1.6156564652919769e-01
    z[3,0,4]  R378      -1.4396056532859802e-01
    z[3,0,4]  R379      -2.7360531687736511e-01
    z[3,0,4]  R380      2.3966661095619202e-01
    z[3,0,4]  R381      1.1521905660629272e-01
    z[3,0,4]  R382      -2.0077142119407654e-01
    z[3,0,4]  R383      -2.2211013734340668e-01
    z[3,0,4]  R384      -2.8791356086730957e-01
    z[3,0,4]  R385      2.1502962335944176e-02
    z[3,0,4]  R386      -1.7876857519149780e-01
    z[3,0,4]  R387      2.1146588027477264e-01
    z[3,0,4]  R388      -1.4546494185924530e-01
    z[3,0,4]  R389      -2.7341198921203613e-01
    z[3,0,4]  R390      -4.8977032303810120e-02
    z[3,0,4]  R391      1.4836145937442780e-01
    z[3,0,4]  R392      -2.3469938337802887e-01
    z[3,0,4]  R393      -1.5348145365715027e-01
    z[3,0,4]  R394      3.1884219497442245e-02
    z[3,0,4]  R395      -3.7615177035331726e-01
    z[3,0,4]  R396      1.6664399206638336e-01
    z[3,0,4]  R397      -9.2443741858005524e-02
    z[3,0,4]  R398      1.8520836532115936e-01
    z[3,0,4]  R399      1.2274316698312759e-01
    z[3,0,4]  R400      -0.0294036865234375
    z[3,0,4]  R401      2.8596383333206177e-01
    z[3,0,4]  R402      0.30115807056427
    z[3,0,4]  R403      -4.5189487934112549e-01
    z[3,0,4]  R404      -4.0652030706405640e-01
    z[3,0,4]  R405      8.7469917535781860e-01
    z[3,0,4]  R406      0.202260360121727
    z[3,0,4]  R407      0.550208568572998
    z[3,0,4]  R408      2.4215830862522125e-01
    z[3,0,4]  R409      -9.3159534037113190e-02
    z[3,0,4]  R410      1.4329020678997040e-01
    z[3,0,4]  R411      5.7947766035795212e-02
    z[3,0,4]  R412      0.171248197555542
    z[3,0,4]  R413      -1.0985486954450607e-01
    z[3,0,4]  R414      -3.5780131816864014e-01
    z[3,0,4]  R415      -6.8329066038131714e-02
    z[3,0,4]  R416      -5.2520078420639038e-01
    z[3,0,4]  R417      -5.4033118486404419e-01
    z[3,0,4]  R418      -3.5473233461380005e-01
    z[3,0,4]  R419      -2.8986307978630066e-01
    z[3,0,4]  R420      -2.0128530263900757e-01
    z[3,0,4]  R421      -3.9078646898269653e-01
    z[3,0,4]  R422      -2.6295730471611023e-01
    z[3,0,4]  R423      -2.4100056290626526e-01
    z[3,0,4]  R424      -3.0672853812575340e-02
    z[3,0,4]  R425      1.5795344114303589e-01
    z[3,0,4]  R426      -2.8742568567395210e-02
    z[3,0,4]  R427      -1.1610026657581329e-01
    z[3,0,4]  R428      4.3195828795433044e-02
    z[3,0,4]  R429      1.6449637711048126e-01
    z[3,0,4]  R430      -4.0860839188098907e-02
    z[3,0,4]  R431      -1.5690515935420990e-01
    z[3,0,4]  R432      4.7893274575471878e-02
    z[3,0,4]  R433      -7.0245601236820221e-02
    z[3,0,5]  R7        1
    z[3,0,5]  R34       -1
    z[3,0,5]  R330      -1
    z[3,0,5]  R331      1
    z[3,0,5]  R334      -1.8468056619167328e-01
    z[3,0,5]  R335      -2.4679200351238251e-01
    z[3,0,5]  R336      -9.3075439333915710e-02
    z[3,0,5]  R337      -2.2437015548348427e-02
    z[3,0,5]  R338      3.1480625271797180e-02
    z[3,0,5]  R339      -1.7917092144489288e-01
    z[3,0,5]  R340      -2.0761974155902863e-01
    z[3,0,5]  R341      1.2972506880760193e-01
    z[3,0,5]  R342      -2.0474882423877716e-01
    z[3,0,5]  R343      -3.4563150256872177e-02
    z[3,0,5]  R344      1.7839744687080383e-01
    z[3,0,5]  R345      -5.3027976304292679e-02
    z[3,0,5]  R346      6.5192244946956635e-02
    z[3,0,5]  R347      1.6985410451889038e-01
    z[3,0,5]  R348      -1.0913661867380142e-01
    z[3,0,5]  R349      -2.4268977344036102e-01
    z[3,0,5]  R350      4.9006618559360504e-02
    z[3,0,5]  R351      8.3451326936483383e-03
    z[3,0,5]  R352      -3.5888835787773132e-01
    z[3,0,5]  R353      2.9074522852897644e-01
    z[3,0,5]  R354      -0.226058229804039
    z[3,0,5]  R355      -3.7904545664787292e-01
    z[3,0,5]  R356      -7.0306479930877686e-02
    z[3,0,5]  R357      -4.7628339380025864e-02
    z[3,0,5]  R358      -2.0866043865680695e-01
    z[3,0,5]  R359      2.4772900342941284e-01
    z[3,0,5]  R360      7.1531340479850769e-02
    z[3,0,5]  R361      -5.2819490432739258e-02
    z[3,0,5]  R362      1.6068877279758453e-01
    z[3,0,5]  R363      -9.9442936480045319e-02
    z[3,0,5]  R364      -0.54718416929245
    z[3,0,5]  R365      -0.462632954120636
    z[3,0,5]  R366      7.9853492975234985e-01
    z[3,0,5]  R367      7.0025348663330078e-01
    z[3,0,5]  R368      -1.6692537069320679e-01
    z[3,0,5]  R369      -1.2781160883605480e-02
    z[3,0,5]  R370      0.666630208492279
    z[3,0,5]  R371      8.0307203531265259e-01
    z[3,0,5]  R372      -1.8419317901134491e-01
    z[3,0,5]  R373      1.7388838529586792e-01
    z[3,0,5]  R374      -5.7286724448204041e-02
    z[3,0,5]  R375      0.718159019947052
    z[3,0,5]  R376      3.6404278874397278e-01
    z[3,0,5]  R377      0.460068941116333
    z[3,0,5]  R378      2.9649391770362854e-01
    z[3,0,5]  R379      6.6731852293014526e-01
    z[3,0,5]  R380      -4.3767508864402771e-01
    z[3,0,5]  R381      -5.4317567497491837e-02
    z[3,0,5]  R382      5.4549443721771240e-01
    z[3,0,5]  R383      4.6343334019184113e-02
    z[3,0,5]  R384      -1.0235474258661270e-01
    z[3,0,5]  R385      -4.3656334280967712e-01
    z[3,0,5]  R386      4.0708357095718384e-01
    z[3,0,5]  R387      -2.6709970831871033e-01
    z[3,0,5]  R388      3.8735663890838623e-01
    z[3,0,5]  R389      -9.8011508584022522e-02
    z[3,0,5]  R390      -3.4187024831771851e-01
    z[3,0,5]  R391      3.1506073474884033e-01
    z[3,0,5]  R392      1.2127444893121719e-01
    z[3,0,5]  R393      -1.1943063884973526e-01
    z[3,0,5]  R394      -2.2009097039699554e-01
    z[3,0,5]  R395      -0.613559365272522
    z[3,0,5]  R396      -5.5540448427200317e-01
    z[3,0,5]  R397      -2.3913922905921936e-01
    z[3,0,5]  R398      3.8042879104614258e-01
    z[3,0,5]  R399      -6.5704119205474854e-01
    z[3,0,5]  R400      0.292542964220047
    z[3,0,5]  R401      1.0635441541671753e-01
    z[3,0,5]  R402      -1.6225801780819893e-02
    z[3,0,5]  R403      7.6356399059295654e-01
    z[3,0,5]  R404      2.0829458534717560e-01
    z[3,0,5]  R405      -3.6475688219070435e-01
    z[3,0,5]  R406      4.6943750977516174e-01
    z[3,0,5]  R407      1.1270909570157528e-02
    z[3,0,5]  R408      8.4247022867202759e-01
    z[3,0,5]  R409      -2.4377481639385223e-01
    z[3,0,5]  R410      3.5951547324657440e-03
    z[3,0,5]  R411      -1.4926959574222565e-01
    z[3,0,5]  R412      2.4945066869258881e-01
    z[3,0,5]  R413      -3.8165751844644547e-02
    z[3,0,5]  R414      -4.6699997782707214e-01
    z[3,0,5]  R415      1.3425664603710175e-01
    z[3,0,5]  R416      9.5400094985961914e-02
    z[3,0,5]  R417      4.0605971217155457e-01
    z[3,0,5]  R418      2.4746602773666382e-01
    z[3,0,5]  R419      2.4702483415603638e-01
    z[3,0,5]  R420      1.1016698926687241e-01
    z[3,0,5]  R421      5.3191280364990234e-01
    z[3,0,5]  R422      5.4213577508926392e-01
    z[3,0,5]  R423      2.7041015028953552e-01
    z[3,0,5]  R424      6.1038345098495483e-01
    z[3,0,5]  R425      -4.1404014825820923e-01
    z[3,0,5]  R426      -5.5174940824508667e-01
    z[3,0,5]  R427      -1.0935736447572708e-01
    z[3,0,5]  R428      5.1671421527862549e-01
    z[3,0,5]  R429      3.8030853867530823e-01
    z[3,0,5]  R430      -5.1567190885543823e-01
    z[3,0,5]  R431      3.9104467630386353e-01
    z[3,0,5]  R432      -3.1359159946441650e-01
    z[3,0,5]  R433      5.8405381441116333e-01
    z[3,0,6]  R8        1
    z[3,0,6]  R35       -1
    z[3,0,6]  R332      -1
    z[3,0,6]  R333      1
    z[3,0,6]  R334      -5.4451610893011093e-02
    z[3,0,6]  R335      -0.385977566242218
    z[3,0,6]  R336      -2.0393805205821991e-01
    z[3,0,6]  R337      4.6617004275321960e-01
    z[3,0,6]  R338      -0.387576699256897
    z[3,0,6]  R339      -3.3300212025642395e-01
    z[3,0,6]  R340      4.6243309974670410e-02
    z[3,0,6]  R341      6.3250800594687462e-03
    z[3,0,6]  R342      2.3546755313873291e-01
    z[3,0,6]  R343      7.6464921236038208e-02
    z[3,0,6]  R344      -1.3288977742195129e-01
    z[3,0,6]  R345      1.8841318786144257e-02
    z[3,0,6]  R346      -9.7866818308830261e-02
    z[3,0,6]  R347      -0.0775921568274498
    z[3,0,6]  R348      1.8998172879219055e-01
    z[3,0,6]  R349      1.1523085087537766e-01
    z[3,0,6]  R350      1.6446661949157715e-01
    z[3,0,6]  R351      2.0641405880451202e-01
    z[3,0,6]  R352      2.5323063135147095e-01
    z[3,0,6]  R353      1.8000033497810364e-01
    z[3,0,6]  R354      -9.4732239842414856e-02
    z[3,0,6]  R355      -1.4579197764396667e-01
    z[3,0,6]  R356      -4.5361623167991638e-02
    z[3,0,6]  R357      -7.9353392124176025e-02
    z[3,0,6]  R358      2.2805716097354889e-01
    z[3,0,6]  R359      1.0872198641300201e-01
    z[3,0,6]  R360      -7.5266361236572266e-02
    z[3,0,6]  R361      -8.2955874502658844e-02
    z[3,0,6]  R362      1.8072535097599030e-01
    z[3,0,6]  R363      1.6203030943870544e-01
    z[3,0,6]  R364      2.6618912816047668e-01
    z[3,0,6]  R365      -2.3902162909507751e-02
    z[3,0,6]  R366      -1.0881227999925613e-01
    z[3,0,6]  R367      2.6119291782379150e-01
    z[3,0,6]  R368      -7.6266713440418243e-02
    z[3,0,6]  R369      6.3522164709866047e-03
    z[3,0,6]  R370      3.5366213414818048e-03
    z[3,0,6]  R371      -5.9513486921787262e-02
    z[3,0,6]  R372      1.8727298080921173e-01
    z[3,0,6]  R373      2.1614888310432434e-01
    z[3,0,6]  R374      -9.7504250705242157e-02
    z[3,0,6]  R375      -2.4339678883552551e-01
    z[3,0,6]  R376      -1.3363434374332428e-01
    z[3,0,6]  R377      -8.7864056229591370e-02
    z[3,0,6]  R378      5.2130836993455887e-03
    z[3,0,6]  R379      1.1075641214847565e-01
    z[3,0,6]  R380      3.4520891308784485e-01
    z[3,0,6]  R381      -8.6348660290241241e-02
    z[3,0,6]  R382      8.7730973958969116e-02
    z[3,0,6]  R383      -0.294983834028244
    z[3,0,6]  R384      -3.8469800353050232e-01
    z[3,0,6]  R385      -4.9401441216468811e-01
    z[3,0,6]  R386      1.1346577107906342e-01
    z[3,0,6]  R387      -4.6004495024681091e-01
    z[3,0,6]  R388      -1.3438005745410919e-01
    z[3,0,6]  R389      -1.7469539307057858e-03
    z[3,0,6]  R390      1.4967045187950134e-01
    z[3,0,6]  R391      -2.0855763554573059e-01
    z[3,0,6]  R392      -4.2886976152658463e-02
    z[3,0,6]  R393      -3.6438378691673279e-01
    z[3,0,6]  R394      -3.7644156813621521e-01
    z[3,0,6]  R395      -0.290274441242218
    z[3,0,6]  R396      -2.1499957144260406e-01
    z[3,0,6]  R397      4.1045309044420719e-03
    z[3,0,6]  R398      -4.7545540332794189e-01
    z[3,0,6]  R399      3.7156778573989868e-01
    z[3,0,6]  R400      -0.0534537211060524
    z[3,0,6]  R401      3.0226361751556396e-01
    z[3,0,6]  R402      1.2297625839710236e-01
    z[3,0,6]  R403      -1.8238408863544464e-01
    z[3,0,6]  R404      4.6725142002105713e-01
    z[3,0,6]  R405      1.6382379829883575e-01
    z[3,0,6]  R406      1.0421517491340637e-01
    z[3,0,6]  R407      1.5747340023517609e-01
    z[3,0,6]  R408      2.5399681925773621e-01
    z[3,0,6]  R409      6.3457474112510681e-02
    z[3,0,6]  R410      1.0275022685527802e-01
    z[3,0,6]  R411      5.8797508478164673e-02
    z[3,0,6]  R412      5.4597449302673340e-01
    z[3,0,6]  R413      4.0711298584938049e-01
    z[3,0,6]  R414      -2.7359450235962868e-02
    z[3,0,6]  R415      -1.4401340484619141e-01
    z[3,0,6]  R416      -6.5099443309009075e-03
    z[3,0,6]  R417      -2.6664644479751587e-02
    z[3,0,6]  R418      -2.3657806217670441e-01
    z[3,0,6]  R419      3.7983467336744070e-03
    z[3,0,6]  R420      1.1799464374780655e-01
    z[3,0,6]  R421      3.2538682222366333e-01
    z[3,0,6]  R422      -2.0820635557174683e-01
    z[3,0,6]  R423      -1.3016252219676971e-01
    z[3,0,6]  R424      8.3052806556224823e-02
    z[3,0,6]  R425      -1.8609504401683807e-01
    z[3,0,6]  R426      -2.2193601727485657e-01
    z[3,0,6]  R427      1.6955780982971191e-01
    z[3,0,6]  R428      -5.8242619037628174e-01
    z[3,0,6]  R429      1.0649064928293228e-01
    z[3,0,6]  R430      4.9925157427787781e-01
    z[3,0,6]  R431      -7.1567870676517487e-02
    z[3,0,6]  R432      3.1157466769218445e-01
    z[3,0,6]  R433      1.3006825745105743e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R478      -1
    z[1,2,0]  R479      1
    z[1,2,0]  R492      -7.5755953788757324e-01
    z[1,2,0]  R493      6.1774069070816040e-01
    z[1,2,0]  R494      -3.3967691659927368e-01
    z[1,2,0]  R495      -7.4591761827468872e-01
    z[1,2,0]  R496      -6.3562631607055664e-01
    z[1,2,0]  R497      -6.7685276269912720e-01
    z[1,2,0]  R498      -7.6198214292526245e-01
    z[1,2,0]  R499      1.2019499391317368e-01
    z[1,2,0]  R500      0.0736149400472641
    z[1,2,0]  R501      -1.8352362513542175e-01
    z[1,2,0]  R502      -2.1915476024150848e-01
    z[1,2,0]  R503      2.4370449781417847e-01
    z[1,2,0]  R504      -3.2098489999771118e-01
    z[1,2,0]  R505      3.3063909411430359e-01
    z[1,2,0]  R506      1.8062606453895569e-01
    z[1,2,0]  R507      -1.9695401191711426e-02
    z[1,2,0]  R508      -2.9621289577335119e-03
    z[1,2,0]  R509      1.9050359725952148e-01
    z[1,2,0]  R510      0.629289448261261
    z[1,2,0]  R511      4.6556234359741211e-02
    z[1,2,0]  R512      -3.0931890010833740e-02
    z[1,2,0]  R513      2.0336858928203583e-02
    z[1,2,0]  R514      -1.4782412350177765e-01
    z[1,2,0]  R515      -2.7121052145957947e-01
    z[1,2,0]  R516      -4.2609363794326782e-01
    z[1,2,0]  R517      8.9835673570632935e-02
    z[1,2,0]  R518      1.5872716903686523e-01
    z[1,2,0]  R519      -4.2676275968551636e-01
    z[1,2,0]  R520      -4.4167912006378174e-01
    z[1,2,0]  R521      -4.8775526881217957e-01
    z[1,2,0]  R522      -4.5682573318481445e-01
    z[1,2,0]  R523      -1.1885754019021988e-01
    z[1,2,0]  R524      3.8897725939750671e-01
    z[1,2,0]  R525      3.5454452037811279e-01
    z[1,2,0]  R526      2.8881320357322693e-01
    z[1,2,0]  R527      4.6142455935478210e-01
    z[1,2,0]  R528      5.3530693054199219e-01
    z[1,2,0]  R529      3.7302318215370178e-01
    z[1,2,0]  R530      4.8588916659355164e-01
    z[1,2,0]  R531      5.7735973596572876e-01
    z[1,2,0]  R532      5.8803540468215942e-01
    z[1,2,0]  R533      5.1394337415695190e-01
    z[1,2,0]  R534      4.3111103773117065e-01
    z[1,2,0]  R535      3.4580138325691223e-01
    z[1,2,0]  R536      0.584464430809021
    z[1,2,0]  R537      0.696518063545227
    z[1,2,0]  R538      6.6535425186157227e-01
    z[1,2,0]  R539      2.6260477304458618e-01
    z[1,2,0]  R540      3.3323770761489868e-01
    z[1,2,0]  R541      2.3147930204868317e-01
    z[1,2,0]  R542      5.5249071121215820e-01
    z[1,2,0]  R543      -2.8479587286710739e-02
    z[1,2,0]  R544      -2.8795897960662842e-01
    z[1,2,0]  R545      1.7002350091934204e-01
    z[1,2,0]  R546      3.7074264883995056e-01
    z[1,2,0]  R547      4.0712225437164307e-01
    z[1,2,0]  R548      2.7213799953460693e-01
    z[1,2,0]  R549      2.5323492288589478e-01
    z[1,2,0]  R550      1.2948262691497803e-01
    z[1,2,0]  R551      6.1186432838439941e-01
    z[1,2,0]  R552      6.2839525938034058e-01
    z[1,2,0]  R553      5.9266000986099243e-01
    z[1,2,0]  R554      -2.9768115282058716e-01
    z[1,2,0]  R555      7.9456394910812378e-01
    z[1,2,0]  R556      1.2260476499795914e-01
    z[1,2,0]  R557      1.8940119445323944e-01
    z[1,2,0]  R558      8.9682662487030029e-01
    z[1,2,0]  R559      1.5533445775508881e-01
    z[1,2,0]  R560      2.3656730353832245e-01
    z[1,2,0]  R561      1.4052592217922211e-01
    z[1,2,0]  R562      1.9808086752891541e-01
    z[1,2,0]  R563      -2.1435850858688354e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R480      -1
    z[1,2,1]  R481      1
    z[1,2,1]  R492      8.1886142492294312e-02
    z[1,2,1]  R493      9.7055546939373016e-02
    z[1,2,1]  R494      1.2865361571311951e-01
    z[1,2,1]  R495      6.0638375580310822e-02
    z[1,2,1]  R496      5.5151361972093582e-02
    z[1,2,1]  R497      -4.3803101778030396e-01
    z[1,2,1]  R498      -5.0843238830566406e-01
    z[1,2,1]  R499      -7.6586097478866577e-01
    z[1,2,1]  R500      -6.9656598567962646e-01
    z[1,2,1]  R501      -0.386089026927948
    z[1,2,1]  R502      8.7825745344161987e-01
    z[1,2,1]  R503      0.83925461769104
    z[1,2,1]  R504      6.3452881574630737e-01
    z[1,2,1]  R505      1.6306184232234955e-01
    z[1,2,1]  R506      -8.0407577753067017e-01
    z[1,2,1]  R507      -6.3214516639709473e-01
    z[1,2,1]  R508      -4.4627717137336731e-01
    z[1,2,1]  R509      1.5261571109294891e-01
    z[1,2,1]  R510      0.0878714844584465
    z[1,2,1]  R511      -8.7257444858551025e-01
    z[1,2,1]  R512      -8.7358325719833374e-01
    z[1,2,1]  R513      -5.4689502716064453e-01
    z[1,2,1]  R514      -0.450273722410202
    z[1,2,1]  R515      -3.6599117517471313e-01
    z[1,2,1]  R516      -1.7743575572967529e-01
    z[1,2,1]  R517      -5.0480651855468750e-01
    z[1,2,1]  R518      -6.7000722885131836e-01
    z[1,2,1]  R519      -8.3980625867843628e-01
    z[1,2,1]  R520      -7.3805534839630127e-01
    z[1,2,1]  R521      -6.8874347209930420e-01
    z[1,2,1]  R522      -0.69554603099823
    z[1,2,1]  R523      -8.4459286928176880e-01
    z[1,2,1]  R524      9.0619117021560669e-02
    z[1,2,1]  R525      3.5812300629913807e-03
    z[1,2,1]  R526      1.0858666896820068e-01
    z[1,2,1]  R527      3.2087564468383789e-01
    z[1,2,1]  R528      3.6810154560953379e-03
    z[1,2,1]  R529      -2.2005392611026764e-01
    z[1,2,1]  R530      4.5547958463430405e-02
    z[1,2,1]  R531      1.2174101918935776e-01
    z[1,2,1]  R532      -7.4106492102146149e-02
    z[1,2,1]  R533      4.8135435581207275e-01
    z[1,2,1]  R534      3.6078253388404846e-01
    z[1,2,1]  R535      5.2687269449234009e-01
    z[1,2,1]  R536      -1.9589845836162567e-01
    z[1,2,1]  R537      -1.6955339908599854e-01
    z[1,2,1]  R538      -1.4765505492687225e-01
    z[1,2,1]  R539      2.3742891848087311e-01
    z[1,2,1]  R540      6.7550569772720337e-01
    z[1,2,1]  R541      6.8556523323059082e-01
    z[1,2,1]  R542      3.7840464711189270e-01
    z[1,2,1]  R543      7.0039027929306030e-01
    z[1,2,1]  R544      3.6631658673286438e-01
    z[1,2,1]  R545      -9.6432730555534363e-02
    z[1,2,1]  R546      -1.7140366137027740e-01
    z[1,2,1]  R547      -1.8234404921531677e-01
    z[1,2,1]  R548      -1.4444039762020111e-01
    z[1,2,1]  R549      -5.5179785937070847e-02
    z[1,2,1]  R550      -7.5423799455165863e-02
    z[1,2,1]  R551      4.8955509066581726e-01
    z[1,2,1]  R552      5.2413874864578247e-01
    z[1,2,1]  R553      4.3968778848648071e-01
    z[1,2,1]  R554      2.2655875980854034e-01
    z[1,2,1]  R555      -2.6407933235168457e-01
    z[1,2,1]  R556      -4.6501386910676956e-02
    z[1,2,1]  R557      1.6103906929492950e-01
    z[1,2,1]  R558      3.6249703168869019e-01
    z[1,2,1]  R559      5.4928815364837646e-01
    z[1,2,1]  R560      7.9501521587371826e-01
    z[1,2,1]  R561      0.604786217212677
    z[1,2,1]  R562      4.5172744989395142e-01
    z[1,2,1]  R563      4.8909822106361389e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R482      -1
    z[1,2,2]  R483      1
    z[1,2,2]  R492      2.1614845097064972e-01
    z[1,2,2]  R493      -7.2414785623550415e-02
    z[1,2,2]  R494      1.6746085882186890e-01
    z[1,2,2]  R495      -0.552842915058136
    z[1,2,2]  R496      -6.1426943540573120e-01
    z[1,2,2]  R497      1.5637424588203430e-01
    z[1,2,2]  R498      1.4649611711502075e-01
    z[1,2,2]  R499      5.8397012948989868e-01
    z[1,2,2]  R500      6.7283588647842407e-01
    z[1,2,2]  R501      7.0392948389053345e-01
    z[1,2,2]  R502      1.3838779926300049e-01
    z[1,2,2]  R503      -5.0884738564491272e-02
    z[1,2,2]  R504      2.9170921072363853e-02
    z[1,2,2]  R505      -4.9306163191795349e-01
    z[1,2,2]  R506      -3.4111782908439636e-01
    z[1,2,2]  R507      -4.5788824558258057e-01
    z[1,2,2]  R508      -0.519756555557251
    z[1,2,2]  R509      -2.6853203773498535e-01
    z[1,2,2]  R510      5.8138924837112427e-01
    z[1,2,2]  R511      -2.0634530484676361e-01
    z[1,2,2]  R512      -3.3708235621452332e-01
    z[1,2,2]  R513      -3.9220988750457764e-01
    z[1,2,2]  R514      6.8378245830535889e-01
    z[1,2,2]  R515      6.3701760768890381e-01
    z[1,2,2]  R516      8.2270896434783936e-01
    z[1,2,2]  R517      7.8873842954635620e-01
    z[1,2,2]  R518      4.9533864855766296e-01
    z[1,2,2]  R519      1.3021484017372131e-01
    z[1,2,2]  R520      1.9035948812961578e-01
    z[1,2,2]  R521      0.517758846282959
    z[1,2,2]  R522      2.3810453712940216e-01
    z[1,2,2]  R523      -1.1931928992271423e-01
    z[1,2,2]  R524      -8.0693596601486206e-01
    z[1,2,2]  R525      -7.6489633321762085e-01
    z[1,2,2]  R526      -6.3491022586822510e-01
    z[1,2,2]  R527      -6.3651943206787109e-01
    z[1,2,2]  R528      -6.1497306823730469e-01
    z[1,2,2]  R529      -5.7035428285598755e-01
    z[1,2,2]  R530      -5.6095844507217407e-01
    z[1,2,2]  R531      -5.2547782659530640e-01
    z[1,2,2]  R532      -6.7329776287078857e-01
    z[1,2,2]  R533      -3.2091107964515686e-01
    z[1,2,2]  R534      2.6161280274391174e-01
    z[1,2,2]  R535      4.5063313841819763e-01
    z[1,2,2]  R536      9.8026670515537262e-02
    z[1,2,2]  R537      -1.2122385203838348e-01
    z[1,2,2]  R538      -1.2712979316711426e-01
    z[1,2,2]  R539      -1.3833381235599518e-01
    z[1,2,2]  R540      -1.5411974489688873e-01
    z[1,2,2]  R541      -2.5532284751534462e-02
    z[1,2,2]  R542      -1.9931019842624664e-01
    z[1,2,2]  R543      -7.1439862251281738e-02
    z[1,2,2]  R544      4.4743287563323975e-01
    z[1,2,2]  R545      3.6612075567245483e-01
    z[1,2,2]  R546      3.0734816193580627e-01
    z[1,2,2]  R547      -9.8225146532058716e-02
    z[1,2,2]  R548      1.1402430245652795e-03
    z[1,2,2]  R549      2.8212782740592957e-01
    z[1,2,2]  R550      -1.5990474820137024e-01
    z[1,2,2]  R551      -3.8946467638015747e-01
    z[1,2,2]  R552      1.6579274833202362e-01
    z[1,2,2]  R553      1.4172625541687012e-01
    z[1,2,2]  R554      3.9897614717483521e-01
    z[1,2,2]  R555      1.8585719168186188e-01
    z[1,2,2]  R556      5.6403100490570068e-02
    z[1,2,2]  R557      3.4615629911422729e-01
    z[1,2,2]  R558      -6.6663399338722229e-02
    z[1,2,2]  R559      -1.8497291207313538e-01
    z[1,2,2]  R560      -1.4014115929603577e-01
    z[1,2,2]  R561      -2.6403433084487915e-01
    z[1,2,2]  R562      -4.2821100354194641e-01
    z[1,2,2]  R563      -0.280825138092041
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R484      -1
    z[1,2,3]  R485      1
    z[1,2,3]  R492      -4.0729328989982605e-01
    z[1,2,3]  R493      5.4033064842224121e-01
    z[1,2,3]  R494      -4.8166982829570770e-02
    z[1,2,3]  R495      2.7853947877883911e-01
    z[1,2,3]  R496      -6.4410172402858734e-02
    z[1,2,3]  R497      -3.2127812504768372e-01
    z[1,2,3]  R498      -3.1471493840217590e-01
    z[1,2,3]  R499      -5.5975690484046936e-02
    z[1,2,3]  R500      -9.0436212718486786e-02
    z[1,2,3]  R501      -4.9013805389404297e-01
    z[1,2,3]  R502      -1.2913604080677032e-01
    z[1,2,3]  R503      -2.6757690310478210e-01
    z[1,2,3]  R504      0.289849191904068
    z[1,2,3]  R505      1.5617226064205170e-01
    z[1,2,3]  R506      -2.3016671836376190e-01
    z[1,2,3]  R507      7.4717029929161072e-02
    z[1,2,3]  R508      -3.6574643850326538e-01
    z[1,2,3]  R509      6.8892216682434082e-01
    z[1,2,3]  R510      -0.0466042086482048
    z[1,2,3]  R511      -1.7337203025817871e-01
    z[1,2,3]  R512      5.4751407355070114e-02
    z[1,2,3]  R513      -5.2775126695632935e-01
    z[1,2,3]  R514      -1.1237671226263046e-01
    z[1,2,3]  R515      -9.2583127319812775e-02
    z[1,2,3]  R516      3.4817929845303297e-03
    z[1,2,3]  R517      5.8322656899690628e-02
    z[1,2,3]  R518      1.2655712664127350e-01
    z[1,2,3]  R519      -7.5186669826507568e-02
    z[1,2,3]  R520      -2.6910807937383652e-02
    z[1,2,3]  R521      9.5883026719093323e-02
    z[1,2,3]  R522      2.2942881286144257e-01
    z[1,2,3]  R523      1.6687752306461334e-01
    z[1,2,3]  R524      1.9492086768150330e-01
    z[1,2,3]  R525      8.3154529333114624e-02
    z[1,2,3]  R526      1.1766187101602554e-01
    z[1,2,3]  R527      1.5138009190559387e-01
    z[1,2,3]  R528      3.8418102264404297e-01
    z[1,2,3]  R529      -3.4220034722238779e-03
    z[1,2,3]  R530      -3.3298607915639877e-02
    z[1,2,3]  R531      0.188424214720726
    z[1,2,3]  R532      -1.5593400597572327e-01
    z[1,2,3]  R533      -5.7853475213050842e-02
    z[1,2,3]  R534      -5.2110069990158081e-01
    z[1,2,3]  R535      -0.59122234582901
    z[1,2,3]  R536      -5.0959432125091553e-01
    z[1,2,3]  R537      -3.4905630350112915e-01
    z[1,2,3]  R538      -4.1432005167007446e-01
    z[1,2,3]  R539      -3.6713162064552307e-01
    z[1,2,3]  R540      4.4533109664916992e-01
    z[1,2,3]  R541      5.5941206216812134e-01
    z[1,2,3]  R542      3.9711400866508484e-01
    z[1,2,3]  R543      0.643405556678772
    z[1,2,3]  R544      -3.2677242159843445e-01
    z[1,2,3]  R545      -7.3861151933670044e-01
    z[1,2,3]  R546      -5.7146298885345459e-01
    z[1,2,3]  R547      1.2318743765354156e-01
    z[1,2,3]  R548      -5.0712424516677856e-01
    z[1,2,3]  R549      -1.5272945165634155e-01
    z[1,2,3]  R550      -6.1037933826446533e-01
    z[1,2,3]  R551      2.3904601112008095e-02
    z[1,2,3]  R552      5.0548028945922852e-01
    z[1,2,3]  R553      0.298697829246521
    z[1,2,3]  R554      -7.8724640607833862e-01
    z[1,2,3]  R555      -5.3819864988327026e-02
    z[1,2,3]  R556      -7.6515994966030121e-02
    z[1,2,3]  R557      1.6152633726596832e-01
    z[1,2,3]  R558      7.2003252804279327e-02
    z[1,2,3]  R559      7.9220914840698242e-01
    z[1,2,3]  R560      5.0273102521896362e-01
    z[1,2,3]  R561      6.5140515565872192e-01
    z[1,2,3]  R562      5.3595691919326782e-01
    z[1,2,3]  R563      0.577110767364502
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R486      -1
    z[1,2,4]  R487      1
    z[1,2,4]  R492      -2.0273748040199280e-01
    z[1,2,4]  R493      -1.8839581310749054e-01
    z[1,2,4]  R494      -0.280404657125473
    z[1,2,4]  R495      -2.0461490750312805e-01
    z[1,2,4]  R496      -2.5542688369750977e-01
    z[1,2,4]  R497      -2.3426280915737152e-01
    z[1,2,4]  R498      1.6930826008319855e-01
    z[1,2,4]  R499      -1.2058027833700180e-01
    z[1,2,4]  R500      1.4223098754882812e-01
    z[1,2,4]  R501      -1.2113583087921143e-01
    z[1,2,4]  R502      -3.1754605472087860e-02
    z[1,2,4]  R503      -1.3101170957088470e-01
    z[1,2,4]  R504      5.9391045570373535e-01
    z[1,2,4]  R505      -9.2241771519184113e-02
    z[1,2,4]  R506      -2.6756340265274048e-01
    z[1,2,4]  R507      2.6170569658279419e-01
    z[1,2,4]  R508      6.4118497073650360e-02
    z[1,2,4]  R509      -3.7524932622909546e-01
    z[1,2,4]  R510      1.2699003517627716e-01
    z[1,2,4]  R511      -3.5339277982711792e-01
    z[1,2,4]  R512      5.5316165089607239e-02
    z[1,2,4]  R513      -1.0436274856328964e-01
    z[1,2,4]  R514      -2.5894564390182495e-01
    z[1,2,4]  R515      -2.9697573184967041e-01
    z[1,2,4]  R516      -1.2680433690547943e-01
    z[1,2,4]  R517      2.6569423079490662e-01
    z[1,2,4]  R518      0.0797264575958252
    z[1,2,4]  R519      -9.9610462784767151e-02
    z[1,2,4]  R520      -2.4736022949218750e-01
    z[1,2,4]  R521      7.5029850006103516e-02
    z[1,2,4]  R522      -1.2354150414466858e-02
    z[1,2,4]  R523      7.8336149454116821e-02
    z[1,2,4]  R524      1.5492191910743713e-01
    z[1,2,4]  R525      0.0875663235783577
    z[1,2,4]  R526      2.2947868704795837e-01
    z[1,2,4]  R527      2.0054118335247040e-01
    z[1,2,4]  R528      3.2300212979316711e-01
    z[1,2,4]  R529      3.6831492185592651e-01
    z[1,2,4]  R530      3.1155723333358765e-01
    z[1,2,4]  R531      4.0080478787422180e-01
    z[1,2,4]  R532      3.9789858460426331e-01
    z[1,2,4]  R533      5.3485298156738281e-01
    z[1,2,4]  R534      2.0066809654235840e-01
    z[1,2,4]  R535      -1.9148169457912445e-01
    z[1,2,4]  R536      -4.1219338774681091e-01
    z[1,2,4]  R537      -5.5085223913192749e-01
    z[1,2,4]  R538      -4.9488613009452820e-01
    z[1,2,4]  R539      -7.1058726310729980e-01
    z[1,2,4]  R540      1.6640616953372955e-01
    z[1,2,4]  R541      3.5721543245017529e-03
    z[1,2,4]  R542      -4.6340253949165344e-01
    z[1,2,4]  R543      -2.2988986968994141e-01
    z[1,2,4]  R544      -3.2883152365684509e-01
    z[1,2,4]  R545      4.7746646404266357e-01
    z[1,2,4]  R546      -1.1411070078611374e-01
    z[1,2,4]  R547      -4.4207006692886353e-01
    z[1,2,4]  R548      4.8652318120002747e-01
    z[1,2,4]  R549      -8.9223784208297729e-01
    z[1,2,4]  R550      -4.0364375710487366e-01
    z[1,2,4]  R551      -4.2736896872520447e-01
    z[1,2,4]  R552      -1.2966082990169525e-01
    z[1,2,4]  R553      -0.33858522772789
    z[1,2,4]  R554      -2.7010414004325867e-01
    z[1,2,4]  R555      -9.6203640103340149e-02
    z[1,2,4]  R556      -8.7878651916980743e-02
    z[1,2,4]  R557      -4.3254595994949341e-01
    z[1,2,4]  R558      -1.5487727522850037e-01
    z[1,2,4]  R559      3.8389221299439669e-03
    z[1,2,4]  R560      -5.9812910854816437e-02
    z[1,2,4]  R561      -2.5321865081787109e-01
    z[1,2,4]  R562      -2.3832413554191589e-01
    z[1,2,4]  R563      -4.2883336544036865e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R488      -1
    z[1,2,5]  R489      1
    z[1,2,5]  R492      -3.5724973678588867e-01
    z[1,2,5]  R493      -5.2501040697097778e-01
    z[1,2,5]  R494      8.2306081056594849e-01
    z[1,2,5]  R495      7.4455350637435913e-02
    z[1,2,5]  R496      3.4165728092193604e-01
    z[1,2,5]  R497      -2.6723784208297729e-01
    z[1,2,5]  R498      1.0493505001068115e-01
    z[1,2,5]  R499      -1.0127409547567368e-01
    z[1,2,5]  R500      -1.6792723536491394e-01
    z[1,2,5]  R501      -1.8255116045475006e-01
    z[1,2,5]  R502      -8.7863765656948090e-02
    z[1,2,5]  R503      -3.8030883669853210e-01
    z[1,2,5]  R504      2.3301929235458374e-01
    z[1,2,5]  R505      7.4577951431274414e-01
    z[1,2,5]  R506      3.5087481141090393e-02
    z[1,2,5]  R507      -2.8743150830268860e-01
    z[1,2,5]  R508      -3.0452570319175720e-01
    z[1,2,5]  R509      2.1698819100856781e-01
    z[1,2,5]  R510      4.7764277458190918e-01
    z[1,2,5]  R511      1.8217791616916656e-01
    z[1,2,5]  R512      -1.3483242690563202e-01
    z[1,2,5]  R513      -2.0405036211013794e-01
    z[1,2,5]  R514      -3.0977943539619446e-01
    z[1,2,5]  R515      -2.3032417893409729e-01
    z[1,2,5]  R516      -3.0635091662406921e-01
    z[1,2,5]  R517      -2.0247609913349152e-01
    z[1,2,5]  R518      -4.3803164362907410e-01
    z[1,2,5]  R519      2.7999192476272583e-01
    z[1,2,5]  R520      -3.2522909343242645e-02
    z[1,2,5]  R521      -5.5692322552204132e-02
    z[1,2,5]  R522      -2.0731480792164803e-02
    z[1,2,5]  R523      -2.1578426659107208e-01
    z[1,2,5]  R524      3.4609884023666382e-01
    z[1,2,5]  R525      4.6551403403282166e-01
    z[1,2,5]  R526      6.5915763378143311e-01
    z[1,2,5]  R527      3.9460220932960510e-01
    z[1,2,5]  R528      0.192719966173172
    z[1,2,5]  R529      5.6872242689132690e-01
    z[1,2,5]  R530      4.4117224216461182e-01
    z[1,2,5]  R531      2.8110796213150024e-01
    z[1,2,5]  R532      1.1208473145961761e-01
    z[1,2,5]  R533      2.7155107259750366e-01
    z[1,2,5]  R534      -4.3861803412437439e-01
    z[1,2,5]  R535      -6.7537024617195129e-02
    z[1,2,5]  R536      1.7103704810142517e-01
    z[1,2,5]  R537      -2.1028815209865570e-01
    z[1,2,5]  R538      -2.4964958429336548e-01
    z[1,2,5]  R539      -4.5664468407630920e-01
    z[1,2,5]  R540      -2.9148340225219727e-01
    z[1,2,5]  R541      -3.8634309172630310e-01
    z[1,2,5]  R542      -3.6803993582725525e-01
    z[1,2,5]  R543      -1.1284297704696655e-01
    z[1,2,5]  R544      -5.3353202342987061e-01
    z[1,2,5]  R545      1.7176094651222229e-01
    z[1,2,5]  R546      4.9098852276802063e-01
    z[1,2,5]  R547      -7.4825161695480347e-01
    z[1,2,5]  R548      -1.3256806135177612e-01
    z[1,2,5]  R549      1.5758083760738373e-01
    z[1,2,5]  R550      -1.8381103873252869e-01
    z[1,2,5]  R551      1.5108172781765461e-02
    z[1,2,5]  R552      1.3056656718254089e-01
    z[1,2,5]  R553      0.481060653924942
    z[1,2,5]  R554      -9.0091437101364136e-02
    z[1,2,5]  R555      -3.0887165665626526e-01
    z[1,2,5]  R556      -9.2239004373550415e-01
    z[1,2,5]  R557      -7.5115984678268433e-01
    z[1,2,5]  R558      1.7373837530612946e-01
    z[1,2,5]  R559      -2.7775179594755173e-02
    z[1,2,5]  R560      -1.8732881546020508e-01
    z[1,2,5]  R561      -1.5532526373863220e-01
    z[1,2,5]  R562      -4.3492570519447327e-01
    z[1,2,5]  R563      3.4181350469589233e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R490      -1
    z[1,2,6]  R491      1
    z[1,2,6]  R492      1.9509072601795197e-01
    z[1,2,6]  R493      -2.5431713089346886e-02
    z[1,2,6]  R494      2.8574258089065552e-01
    z[1,2,6]  R495      9.6433833241462708e-02
    z[1,2,6]  R496      1.7172423005104065e-01
    z[1,2,6]  R497      3.0988961458206177e-01
    z[1,2,6]  R498      2.6388822123408318e-02
    z[1,2,6]  R499      1.7337700724601746e-01
    z[1,2,6]  R500      -7.7882311306893826e-03
    z[1,2,6]  R501      1.8303962051868439e-01
    z[1,2,6]  R502      -3.6888930201530457e-01
    z[1,2,6]  R503      -1.6560163348913193e-02
    z[1,2,6]  R504      -4.9504969269037247e-02
    z[1,2,6]  R505      -1.7858718335628510e-01
    z[1,2,6]  R506      -2.8049442172050476e-01
    z[1,2,6]  R507      -0.483377069234848
    z[1,2,6]  R508      -0.547780454158783
    z[1,2,6]  R509      4.5364937186241150e-01
    z[1,2,6]  R510      -1.0871516168117523e-01
    z[1,2,6]  R511      -7.5729645788669586e-02
    z[1,2,6]  R512      -0.313103049993515
    z[1,2,6]  R513      -4.6434280276298523e-01
    z[1,2,6]  R514      -3.6359116435050964e-01
    z[1,2,6]  R515      4.8671197891235352e-01
    z[1,2,6]  R516      1.2976335361599922e-02
    z[1,2,6]  R517      1.9841415632981807e-04
    z[1,2,6]  R518      2.5747016072273254e-01
    z[1,2,6]  R519      -4.0895272046327591e-02
    z[1,2,6]  R520      4.0123319625854492e-01
    z[1,2,6]  R521      0.0415741428732872
    z[1,2,6]  R522      -4.4453600049018860e-01
    z[1,2,6]  R523      -4.2160528898239136e-01
    z[1,2,6]  R524      -8.6947746574878693e-02
    z[1,2,6]  R525      2.4069288372993469e-01
    z[1,2,6]  R526      2.6291970163583755e-02
    z[1,2,6]  R527      2.4520504474639893e-01
    z[1,2,6]  R528      2.1488258242607117e-01
    z[1,2,6]  R529      1.6737145185470581e-01
    z[1,2,6]  R530      3.9287796616554260e-01
    z[1,2,6]  R531      3.1707757711410522e-01
    z[1,2,6]  R532      -1.3823526911437511e-02
    z[1,2,6]  R533      -1.9499093294143677e-01
    z[1,2,6]  R534      3.3367431163787842e-01
    z[1,2,6]  R535      -9.4794243574142456e-02
    z[1,2,6]  R536      3.8932305574417114e-01
    z[1,2,6]  R537      -4.3811149895191193e-02
    z[1,2,6]  R538      2.0110045373439789e-01
    z[1,2,6]  R539      -8.5356742143630981e-02
    z[1,2,6]  R540      -3.1291925907135010e-01
    z[1,2,6]  R541      -1.1640454828739166e-01
    z[1,2,6]  R542      6.2806069850921631e-02
    z[1,2,6]  R543      -1.5487149357795715e-01
    z[1,2,6]  R544      -2.8832051157951355e-01
    z[1,2,6]  R545      1.5724253654479980e-01
    z[1,2,6]  R546      -3.9755105972290039e-01
    z[1,2,6]  R547      -1.4447268843650818e-01
    z[1,2,6]  R548      -0.627393364906311
    z[1,2,6]  R549      9.4787724316120148e-02
    z[1,2,6]  R550      -0.618626058101654
    z[1,2,6]  R551      -2.2545768320560455e-01
    z[1,2,6]  R552      -1.1636500060558319e-01
    z[1,2,6]  R553      7.9149333760142326e-03
    z[1,2,6]  R554      6.7283022217452526e-03
    z[1,2,6]  R555      -3.9602261781692505e-01
    z[1,2,6]  R556      -3.3947536349296570e-01
    z[1,2,6]  R557      2.0234017074108124e-01
    z[1,2,6]  R558      -2.2302420809864998e-02
    z[1,2,6]  R559      -1.0750397294759750e-01
    z[1,2,6]  R560      3.0643166974186897e-02
    z[1,2,6]  R561      1.7943707108497620e-01
    z[1,2,6]  R562      -2.0033207535743713e-01
    z[1,2,6]  R563      4.6682354062795639e-02
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R564      -1
    z[2,1,0]  R565      1
    z[2,1,0]  R578      -1.4782412350177765e-01
    z[2,1,0]  R579      -2.7121052145957947e-01
    z[2,1,0]  R580      -4.2609363794326782e-01
    z[2,1,0]  R581      8.9835673570632935e-02
    z[2,1,0]  R582      1.5872716903686523e-01
    z[2,1,0]  R583      -4.2676275968551636e-01
    z[2,1,0]  R584      -4.4167912006378174e-01
    z[2,1,0]  R585      -4.8775526881217957e-01
    z[2,1,0]  R586      -4.5682573318481445e-01
    z[2,1,0]  R587      -1.1885754019021988e-01
    z[2,1,0]  R588      3.8897725939750671e-01
    z[2,1,0]  R589      3.5454452037811279e-01
    z[2,1,0]  R590      2.8881320357322693e-01
    z[2,1,0]  R591      4.6142455935478210e-01
    z[2,1,0]  R592      5.3530693054199219e-01
    z[2,1,0]  R593      3.7302318215370178e-01
    z[2,1,0]  R594      4.8588916659355164e-01
    z[2,1,0]  R595      5.7735973596572876e-01
    z[2,1,0]  R596      5.8803540468215942e-01
    z[2,1,0]  R597      5.1394337415695190e-01
    z[2,1,0]  R598      4.3111103773117065e-01
    z[2,1,0]  R599      3.4580138325691223e-01
    z[2,1,0]  R600      0.584464430809021
    z[2,1,0]  R601      0.696518063545227
    z[2,1,0]  R602      6.6535425186157227e-01
    z[2,1,0]  R603      2.6260477304458618e-01
    z[2,1,0]  R604      3.3323770761489868e-01
    z[2,1,0]  R605      2.3147930204868317e-01
    z[2,1,0]  R606      5.5249071121215820e-01
    z[2,1,0]  R607      -2.8479587286710739e-02
    z[2,1,0]  R608      -2.8795897960662842e-01
    z[2,1,0]  R609      1.7002350091934204e-01
    z[2,1,0]  R610      3.7074264883995056e-01
    z[2,1,0]  R611      4.0712225437164307e-01
    z[2,1,0]  R612      2.7213799953460693e-01
    z[2,1,0]  R613      2.5323492288589478e-01
    z[2,1,0]  R614      1.2948262691497803e-01
    z[2,1,0]  R615      6.1186432838439941e-01
    z[2,1,0]  R616      6.2839525938034058e-01
    z[2,1,0]  R617      5.9266000986099243e-01
    z[2,1,0]  R618      -2.9768115282058716e-01
    z[2,1,0]  R619      7.9456394910812378e-01
    z[2,1,0]  R620      1.2260476499795914e-01
    z[2,1,0]  R621      1.8940119445323944e-01
    z[2,1,0]  R622      8.9682662487030029e-01
    z[2,1,0]  R623      1.5533445775508881e-01
    z[2,1,0]  R624      2.3656730353832245e-01
    z[2,1,0]  R625      1.4052592217922211e-01
    z[2,1,0]  R626      1.9808086752891541e-01
    z[2,1,0]  R627      -2.1435850858688354e-01
    z[2,1,0]  R628      -7.5755953788757324e-01
    z[2,1,0]  R629      6.1774069070816040e-01
    z[2,1,0]  R630      -3.3967691659927368e-01
    z[2,1,0]  R631      -7.4591761827468872e-01
    z[2,1,0]  R632      -6.3562631607055664e-01
    z[2,1,0]  R633      -6.7685276269912720e-01
    z[2,1,0]  R634      -7.6198214292526245e-01
    z[2,1,0]  R635      1.2019499391317368e-01
    z[2,1,0]  R636      0.0736149400472641
    z[2,1,0]  R637      -1.8352362513542175e-01
    z[2,1,0]  R638      -2.1915476024150848e-01
    z[2,1,0]  R639      2.4370449781417847e-01
    z[2,1,0]  R640      -3.2098489999771118e-01
    z[2,1,0]  R641      3.3063909411430359e-01
    z[2,1,0]  R642      1.8062606453895569e-01
    z[2,1,0]  R643      -1.9695401191711426e-02
    z[2,1,0]  R644      -2.9621289577335119e-03
    z[2,1,0]  R645      1.9050359725952148e-01
    z[2,1,0]  R646      0.629289448261261
    z[2,1,0]  R647      4.6556234359741211e-02
    z[2,1,0]  R648      -3.0931890010833740e-02
    z[2,1,0]  R649      2.0336858928203583e-02
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R566      -1
    z[2,1,1]  R567      1
    z[2,1,1]  R578      -0.450273722410202
    z[2,1,1]  R579      -3.6599117517471313e-01
    z[2,1,1]  R580      -1.7743575572967529e-01
    z[2,1,1]  R581      -5.0480651855468750e-01
    z[2,1,1]  R582      -6.7000722885131836e-01
    z[2,1,1]  R583      -8.3980625867843628e-01
    z[2,1,1]  R584      -7.3805534839630127e-01
    z[2,1,1]  R585      -6.8874347209930420e-01
    z[2,1,1]  R586      -0.69554603099823
    z[2,1,1]  R587      -8.4459286928176880e-01
    z[2,1,1]  R588      9.0619117021560669e-02
    z[2,1,1]  R589      3.5812300629913807e-03
    z[2,1,1]  R590      1.0858666896820068e-01
    z[2,1,1]  R591      3.2087564468383789e-01
    z[2,1,1]  R592      3.6810154560953379e-03
    z[2,1,1]  R593      -2.2005392611026764e-01
    z[2,1,1]  R594      4.5547958463430405e-02
    z[2,1,1]  R595      1.2174101918935776e-01
    z[2,1,1]  R596      -7.4106492102146149e-02
    z[2,1,1]  R597      4.8135435581207275e-01
    z[2,1,1]  R598      3.6078253388404846e-01
    z[2,1,1]  R599      5.2687269449234009e-01
    z[2,1,1]  R600      -1.9589845836162567e-01
    z[2,1,1]  R601      -1.6955339908599854e-01
    z[2,1,1]  R602      -1.4765505492687225e-01
    z[2,1,1]  R603      2.3742891848087311e-01
    z[2,1,1]  R604      6.7550569772720337e-01
    z[2,1,1]  R605      6.8556523323059082e-01
    z[2,1,1]  R606      3.7840464711189270e-01
    z[2,1,1]  R607      7.0039027929306030e-01
    z[2,1,1]  R608      3.6631658673286438e-01
    z[2,1,1]  R609      -9.6432730555534363e-02
    z[2,1,1]  R610      -1.7140366137027740e-01
    z[2,1,1]  R611      -1.8234404921531677e-01
    z[2,1,1]  R612      -1.4444039762020111e-01
    z[2,1,1]  R613      -5.5179785937070847e-02
    z[2,1,1]  R614      -7.5423799455165863e-02
    z[2,1,1]  R615      4.8955509066581726e-01
    z[2,1,1]  R616      5.2413874864578247e-01
    z[2,1,1]  R617      4.3968778848648071e-01
    z[2,1,1]  R618      2.2655875980854034e-01
    z[2,1,1]  R619      -2.6407933235168457e-01
    z[2,1,1]  R620      -4.6501386910676956e-02
    z[2,1,1]  R621      1.6103906929492950e-01
    z[2,1,1]  R622      3.6249703168869019e-01
    z[2,1,1]  R623      5.4928815364837646e-01
    z[2,1,1]  R624      7.9501521587371826e-01
    z[2,1,1]  R625      0.604786217212677
    z[2,1,1]  R626      4.5172744989395142e-01
    z[2,1,1]  R627      4.8909822106361389e-01
    z[2,1,1]  R628      8.1886142492294312e-02
    z[2,1,1]  R629      9.7055546939373016e-02
    z[2,1,1]  R630      1.2865361571311951e-01
    z[2,1,1]  R631      6.0638375580310822e-02
    z[2,1,1]  R632      5.5151361972093582e-02
    z[2,1,1]  R633      -4.3803101778030396e-01
    z[2,1,1]  R634      -5.0843238830566406e-01
    z[2,1,1]  R635      -7.6586097478866577e-01
    z[2,1,1]  R636      -6.9656598567962646e-01
    z[2,1,1]  R637      -0.386089026927948
    z[2,1,1]  R638      8.7825745344161987e-01
    z[2,1,1]  R639      0.83925461769104
    z[2,1,1]  R640      6.3452881574630737e-01
    z[2,1,1]  R641      1.6306184232234955e-01
    z[2,1,1]  R642      -8.0407577753067017e-01
    z[2,1,1]  R643      -6.3214516639709473e-01
    z[2,1,1]  R644      -4.4627717137336731e-01
    z[2,1,1]  R645      1.5261571109294891e-01
    z[2,1,1]  R646      0.0878714844584465
    z[2,1,1]  R647      -8.7257444858551025e-01
    z[2,1,1]  R648      -8.7358325719833374e-01
    z[2,1,1]  R649      -5.4689502716064453e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R568      -1
    z[2,1,2]  R569      1
    z[2,1,2]  R578      6.8378245830535889e-01
    z[2,1,2]  R579      6.3701760768890381e-01
    z[2,1,2]  R580      8.2270896434783936e-01
    z[2,1,2]  R581      7.8873842954635620e-01
    z[2,1,2]  R582      4.9533864855766296e-01
    z[2,1,2]  R583      1.3021484017372131e-01
    z[2,1,2]  R584      1.9035948812961578e-01
    z[2,1,2]  R585      0.517758846282959
    z[2,1,2]  R586      2.3810453712940216e-01
    z[2,1,2]  R587      -1.1931928992271423e-01
    z[2,1,2]  R588      -8.0693596601486206e-01
    z[2,1,2]  R589      -7.6489633321762085e-01
    z[2,1,2]  R590      -6.3491022586822510e-01
    z[2,1,2]  R591      -6.3651943206787109e-01
    z[2,1,2]  R592      -6.1497306823730469e-01
    z[2,1,2]  R593      -5.7035428285598755e-01
    z[2,1,2]  R594      -5.6095844507217407e-01
    z[2,1,2]  R595      -5.2547782659530640e-01
    z[2,1,2]  R596      -6.7329776287078857e-01
    z[2,1,2]  R597      -3.2091107964515686e-01
    z[2,1,2]  R598      2.6161280274391174e-01
    z[2,1,2]  R599      4.5063313841819763e-01
    z[2,1,2]  R600      9.8026670515537262e-02
    z[2,1,2]  R601      -1.2122385203838348e-01
    z[2,1,2]  R602      -1.2712979316711426e-01
    z[2,1,2]  R603      -1.3833381235599518e-01
    z[2,1,2]  R604      -1.5411974489688873e-01
    z[2,1,2]  R605      -2.5532284751534462e-02
    z[2,1,2]  R606      -1.9931019842624664e-01
    z[2,1,2]  R607      -7.1439862251281738e-02
    z[2,1,2]  R608      4.4743287563323975e-01
    z[2,1,2]  R609      3.6612075567245483e-01
    z[2,1,2]  R610      3.0734816193580627e-01
    z[2,1,2]  R611      -9.8225146532058716e-02
    z[2,1,2]  R612      1.1402430245652795e-03
    z[2,1,2]  R613      2.8212782740592957e-01
    z[2,1,2]  R614      -1.5990474820137024e-01
    z[2,1,2]  R615      -3.8946467638015747e-01
    z[2,1,2]  R616      1.6579274833202362e-01
    z[2,1,2]  R617      1.4172625541687012e-01
    z[2,1,2]  R618      3.9897614717483521e-01
    z[2,1,2]  R619      1.8585719168186188e-01
    z[2,1,2]  R620      5.6403100490570068e-02
    z[2,1,2]  R621      3.4615629911422729e-01
    z[2,1,2]  R622      -6.6663399338722229e-02
    z[2,1,2]  R623      -1.8497291207313538e-01
    z[2,1,2]  R624      -1.4014115929603577e-01
    z[2,1,2]  R625      -2.6403433084487915e-01
    z[2,1,2]  R626      -4.2821100354194641e-01
    z[2,1,2]  R627      -0.280825138092041
    z[2,1,2]  R628      2.1614845097064972e-01
    z[2,1,2]  R629      -7.2414785623550415e-02
    z[2,1,2]  R630      1.6746085882186890e-01
    z[2,1,2]  R631      -0.552842915058136
    z[2,1,2]  R632      -6.1426943540573120e-01
    z[2,1,2]  R633      1.5637424588203430e-01
    z[2,1,2]  R634      1.4649611711502075e-01
    z[2,1,2]  R635      5.8397012948989868e-01
    z[2,1,2]  R636      6.7283588647842407e-01
    z[2,1,2]  R637      7.0392948389053345e-01
    z[2,1,2]  R638      1.3838779926300049e-01
    z[2,1,2]  R639      -5.0884738564491272e-02
    z[2,1,2]  R640      2.9170921072363853e-02
    z[2,1,2]  R641      -4.9306163191795349e-01
    z[2,1,2]  R642      -3.4111782908439636e-01
    z[2,1,2]  R643      -4.5788824558258057e-01
    z[2,1,2]  R644      -0.519756555557251
    z[2,1,2]  R645      -2.6853203773498535e-01
    z[2,1,2]  R646      5.8138924837112427e-01
    z[2,1,2]  R647      -2.0634530484676361e-01
    z[2,1,2]  R648      -3.3708235621452332e-01
    z[2,1,2]  R649      -3.9220988750457764e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R570      -1
    z[2,1,3]  R571      1
    z[2,1,3]  R578      -1.1237671226263046e-01
    z[2,1,3]  R579      -9.2583127319812775e-02
    z[2,1,3]  R580      3.4817929845303297e-03
    z[2,1,3]  R581      5.8322656899690628e-02
    z[2,1,3]  R582      1.2655712664127350e-01
    z[2,1,3]  R583      -7.5186669826507568e-02
    z[2,1,3]  R584      -2.6910807937383652e-02
    z[2,1,3]  R585      9.5883026719093323e-02
    z[2,1,3]  R586      2.2942881286144257e-01
    z[2,1,3]  R587      1.6687752306461334e-01
    z[2,1,3]  R588      1.9492086768150330e-01
    z[2,1,3]  R589      8.3154529333114624e-02
    z[2,1,3]  R590      1.1766187101602554e-01
    z[2,1,3]  R591      1.5138009190559387e-01
    z[2,1,3]  R592      3.8418102264404297e-01
    z[2,1,3]  R593      -3.4220034722238779e-03
    z[2,1,3]  R594      -3.3298607915639877e-02
    z[2,1,3]  R595      0.188424214720726
    z[2,1,3]  R596      -1.5593400597572327e-01
    z[2,1,3]  R597      -5.7853475213050842e-02
    z[2,1,3]  R598      -5.2110069990158081e-01
    z[2,1,3]  R599      -0.59122234582901
    z[2,1,3]  R600      -5.0959432125091553e-01
    z[2,1,3]  R601      -3.4905630350112915e-01
    z[2,1,3]  R602      -4.1432005167007446e-01
    z[2,1,3]  R603      -3.6713162064552307e-01
    z[2,1,3]  R604      4.4533109664916992e-01
    z[2,1,3]  R605      5.5941206216812134e-01
    z[2,1,3]  R606      3.9711400866508484e-01
    z[2,1,3]  R607      0.643405556678772
    z[2,1,3]  R608      -3.2677242159843445e-01
    z[2,1,3]  R609      -7.3861151933670044e-01
    z[2,1,3]  R610      -5.7146298885345459e-01
    z[2,1,3]  R611      1.2318743765354156e-01
    z[2,1,3]  R612      -5.0712424516677856e-01
    z[2,1,3]  R613      -1.5272945165634155e-01
    z[2,1,3]  R614      -6.1037933826446533e-01
    z[2,1,3]  R615      2.3904601112008095e-02
    z[2,1,3]  R616      5.0548028945922852e-01
    z[2,1,3]  R617      0.298697829246521
    z[2,1,3]  R618      -7.8724640607833862e-01
    z[2,1,3]  R619      -5.3819864988327026e-02
    z[2,1,3]  R620      -7.6515994966030121e-02
    z[2,1,3]  R621      1.6152633726596832e-01
    z[2,1,3]  R622      7.2003252804279327e-02
    z[2,1,3]  R623      7.9220914840698242e-01
    z[2,1,3]  R624      5.0273102521896362e-01
    z[2,1,3]  R625      6.5140515565872192e-01
    z[2,1,3]  R626      5.3595691919326782e-01
    z[2,1,3]  R627      0.577110767364502
    z[2,1,3]  R628      -4.0729328989982605e-01
    z[2,1,3]  R629      5.4033064842224121e-01
    z[2,1,3]  R630      -4.8166982829570770e-02
    z[2,1,3]  R631      2.7853947877883911e-01
    z[2,1,3]  R632      -6.4410172402858734e-02
    z[2,1,3]  R633      -3.2127812504768372e-01
    z[2,1,3]  R634      -3.1471493840217590e-01
    z[2,1,3]  R635      -5.5975690484046936e-02
    z[2,1,3]  R636      -9.0436212718486786e-02
    z[2,1,3]  R637      -4.9013805389404297e-01
    z[2,1,3]  R638      -1.2913604080677032e-01
    z[2,1,3]  R639      -2.6757690310478210e-01
    z[2,1,3]  R640      0.289849191904068
    z[2,1,3]  R641      1.5617226064205170e-01
    z[2,1,3]  R642      -2.3016671836376190e-01
    z[2,1,3]  R643      7.4717029929161072e-02
    z[2,1,3]  R644      -3.6574643850326538e-01
    z[2,1,3]  R645      6.8892216682434082e-01
    z[2,1,3]  R646      -0.0466042086482048
    z[2,1,3]  R647      -1.7337203025817871e-01
    z[2,1,3]  R648      5.4751407355070114e-02
    z[2,1,3]  R649      -5.2775126695632935e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R572      -1
    z[2,1,4]  R573      1
    z[2,1,4]  R578      -2.5894564390182495e-01
    z[2,1,4]  R579      -2.9697573184967041e-01
    z[2,1,4]  R580      -1.2680433690547943e-01
    z[2,1,4]  R581      2.6569423079490662e-01
    z[2,1,4]  R582      0.0797264575958252
    z[2,1,4]  R583      -9.9610462784767151e-02
    z[2,1,4]  R584      -2.4736022949218750e-01
    z[2,1,4]  R585      7.5029850006103516e-02
    z[2,1,4]  R586      -1.2354150414466858e-02
    z[2,1,4]  R587      7.8336149454116821e-02
    z[2,1,4]  R588      1.5492191910743713e-01
    z[2,1,4]  R589      0.0875663235783577
    z[2,1,4]  R590      2.2947868704795837e-01
    z[2,1,4]  R591      2.0054118335247040e-01
    z[2,1,4]  R592      3.2300212979316711e-01
    z[2,1,4]  R593      3.6831492185592651e-01
    z[2,1,4]  R594      3.1155723333358765e-01
    z[2,1,4]  R595      4.0080478787422180e-01
    z[2,1,4]  R596      3.9789858460426331e-01
    z[2,1,4]  R597      5.3485298156738281e-01
    z[2,1,4]  R598      2.0066809654235840e-01
    z[2,1,4]  R599      -1.9148169457912445e-01
    z[2,1,4]  R600      -4.1219338774681091e-01
    z[2,1,4]  R601      -5.5085223913192749e-01
    z[2,1,4]  R602      -4.9488613009452820e-01
    z[2,1,4]  R603      -7.1058726310729980e-01
    z[2,1,4]  R604      1.6640616953372955e-01
    z[2,1,4]  R605      3.5721543245017529e-03
    z[2,1,4]  R606      -4.6340253949165344e-01
    z[2,1,4]  R607      -2.2988986968994141e-01
    z[2,1,4]  R608      -3.2883152365684509e-01
    z[2,1,4]  R609      4.7746646404266357e-01
    z[2,1,4]  R610      -1.1411070078611374e-01
    z[2,1,4]  R611      -4.4207006692886353e-01
    z[2,1,4]  R612      4.8652318120002747e-01
    z[2,1,4]  R613      -8.9223784208297729e-01
    z[2,1,4]  R614      -4.0364375710487366e-01
    z[2,1,4]  R615      -4.2736896872520447e-01
    z[2,1,4]  R616      -1.2966082990169525e-01
    z[2,1,4]  R617      -0.33858522772789
    z[2,1,4]  R618      -2.7010414004325867e-01
    z[2,1,4]  R619      -9.6203640103340149e-02
    z[2,1,4]  R620      -8.7878651916980743e-02
    z[2,1,4]  R621      -4.3254595994949341e-01
    z[2,1,4]  R622      -1.5487727522850037e-01
    z[2,1,4]  R623      3.8389221299439669e-03
    z[2,1,4]  R624      -5.9812910854816437e-02
    z[2,1,4]  R625      -2.5321865081787109e-01
    z[2,1,4]  R626      -2.3832413554191589e-01
    z[2,1,4]  R627      -4.2883336544036865e-01
    z[2,1,4]  R628      -2.0273748040199280e-01
    z[2,1,4]  R629      -1.8839581310749054e-01
    z[2,1,4]  R630      -0.280404657125473
    z[2,1,4]  R631      -2.0461490750312805e-01
    z[2,1,4]  R632      -2.5542688369750977e-01
    z[2,1,4]  R633      -2.3426280915737152e-01
    z[2,1,4]  R634      1.6930826008319855e-01
    z[2,1,4]  R635      -1.2058027833700180e-01
    z[2,1,4]  R636      1.4223098754882812e-01
    z[2,1,4]  R637      -1.2113583087921143e-01
    z[2,1,4]  R638      -3.1754605472087860e-02
    z[2,1,4]  R639      -1.3101170957088470e-01
    z[2,1,4]  R640      5.9391045570373535e-01
    z[2,1,4]  R641      -9.2241771519184113e-02
    z[2,1,4]  R642      -2.6756340265274048e-01
    z[2,1,4]  R643      2.6170569658279419e-01
    z[2,1,4]  R644      6.4118497073650360e-02
    z[2,1,4]  R645      -3.7524932622909546e-01
    z[2,1,4]  R646      1.2699003517627716e-01
    z[2,1,4]  R647      -3.5339277982711792e-01
    z[2,1,4]  R648      5.5316165089607239e-02
    z[2,1,4]  R649      -1.0436274856328964e-01
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R574      -1
    z[2,1,5]  R575      1
    z[2,1,5]  R578      -3.0977943539619446e-01
    z[2,1,5]  R579      -2.3032417893409729e-01
    z[2,1,5]  R580      -3.0635091662406921e-01
    z[2,1,5]  R581      -2.0247609913349152e-01
    z[2,1,5]  R582      -4.3803164362907410e-01
    z[2,1,5]  R583      2.7999192476272583e-01
    z[2,1,5]  R584      -3.2522909343242645e-02
    z[2,1,5]  R585      -5.5692322552204132e-02
    z[2,1,5]  R586      -2.0731480792164803e-02
    z[2,1,5]  R587      -2.1578426659107208e-01
    z[2,1,5]  R588      3.4609884023666382e-01
    z[2,1,5]  R589      4.6551403403282166e-01
    z[2,1,5]  R590      6.5915763378143311e-01
    z[2,1,5]  R591      3.9460220932960510e-01
    z[2,1,5]  R592      0.192719966173172
    z[2,1,5]  R593      5.6872242689132690e-01
    z[2,1,5]  R594      4.4117224216461182e-01
    z[2,1,5]  R595      2.8110796213150024e-01
    z[2,1,5]  R596      1.1208473145961761e-01
    z[2,1,5]  R597      2.7155107259750366e-01
    z[2,1,5]  R598      -4.3861803412437439e-01
    z[2,1,5]  R599      -6.7537024617195129e-02
    z[2,1,5]  R600      1.7103704810142517e-01
    z[2,1,5]  R601      -2.1028815209865570e-01
    z[2,1,5]  R602      -2.4964958429336548e-01
    z[2,1,5]  R603      -4.5664468407630920e-01
    z[2,1,5]  R604      -2.9148340225219727e-01
    z[2,1,5]  R605      -3.8634309172630310e-01
    z[2,1,5]  R606      -3.6803993582725525e-01
    z[2,1,5]  R607      -1.1284297704696655e-01
    z[2,1,5]  R608      -5.3353202342987061e-01
    z[2,1,5]  R609      1.7176094651222229e-01
    z[2,1,5]  R610      4.9098852276802063e-01
    z[2,1,5]  R611      -7.4825161695480347e-01
    z[2,1,5]  R612      -1.3256806135177612e-01
    z[2,1,5]  R613      1.5758083760738373e-01
    z[2,1,5]  R614      -1.8381103873252869e-01
    z[2,1,5]  R615      1.5108172781765461e-02
    z[2,1,5]  R616      1.3056656718254089e-01
    z[2,1,5]  R617      0.481060653924942
    z[2,1,5]  R618      -9.0091437101364136e-02
    z[2,1,5]  R619      -3.0887165665626526e-01
    z[2,1,5]  R620      -9.2239004373550415e-01
    z[2,1,5]  R621      -7.5115984678268433e-01
    z[2,1,5]  R622      1.7373837530612946e-01
    z[2,1,5]  R623      -2.7775179594755173e-02
    z[2,1,5]  R624      -1.8732881546020508e-01
    z[2,1,5]  R625      -1.5532526373863220e-01
    z[2,1,5]  R626      -4.3492570519447327e-01
    z[2,1,5]  R627      3.4181350469589233e-01
    z[2,1,5]  R628      -3.5724973678588867e-01
    z[2,1,5]  R629      -5.2501040697097778e-01
    z[2,1,5]  R630      8.2306081056594849e-01
    z[2,1,5]  R631      7.4455350637435913e-02
    z[2,1,5]  R632      3.4165728092193604e-01
    z[2,1,5]  R633      -2.6723784208297729e-01
    z[2,1,5]  R634      1.0493505001068115e-01
    z[2,1,5]  R635      -1.0127409547567368e-01
    z[2,1,5]  R636      -1.6792723536491394e-01
    z[2,1,5]  R637      -1.8255116045475006e-01
    z[2,1,5]  R638      -8.7863765656948090e-02
    z[2,1,5]  R639      -3.8030883669853210e-01
    z[2,1,5]  R640      2.3301929235458374e-01
    z[2,1,5]  R641      7.4577951431274414e-01
    z[2,1,5]  R642      3.5087481141090393e-02
    z[2,1,5]  R643      -2.8743150830268860e-01
    z[2,1,5]  R644      -3.0452570319175720e-01
    z[2,1,5]  R645      2.1698819100856781e-01
    z[2,1,5]  R646      4.7764277458190918e-01
    z[2,1,5]  R647      1.8217791616916656e-01
    z[2,1,5]  R648      -1.3483242690563202e-01
    z[2,1,5]  R649      -2.0405036211013794e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R576      -1
    z[2,1,6]  R577      1
    z[2,1,6]  R578      -3.6359116435050964e-01
    z[2,1,6]  R579      4.8671197891235352e-01
    z[2,1,6]  R580      1.2976335361599922e-02
    z[2,1,6]  R581      1.9841415632981807e-04
    z[2,1,6]  R582      2.5747016072273254e-01
    z[2,1,6]  R583      -4.0895272046327591e-02
    z[2,1,6]  R584      4.0123319625854492e-01
    z[2,1,6]  R585      0.0415741428732872
    z[2,1,6]  R586      -4.4453600049018860e-01
    z[2,1,6]  R587      -4.2160528898239136e-01
    z[2,1,6]  R588      -8.6947746574878693e-02
    z[2,1,6]  R589      2.4069288372993469e-01
    z[2,1,6]  R590      2.6291970163583755e-02
    z[2,1,6]  R591      2.4520504474639893e-01
    z[2,1,6]  R592      2.1488258242607117e-01
    z[2,1,6]  R593      1.6737145185470581e-01
    z[2,1,6]  R594      3.9287796616554260e-01
    z[2,1,6]  R595      3.1707757711410522e-01
    z[2,1,6]  R596      -1.3823526911437511e-02
    z[2,1,6]  R597      -1.9499093294143677e-01
    z[2,1,6]  R598      3.3367431163787842e-01
    z[2,1,6]  R599      -9.4794243574142456e-02
    z[2,1,6]  R600      3.8932305574417114e-01
    z[2,1,6]  R601      -4.3811149895191193e-02
    z[2,1,6]  R602      2.0110045373439789e-01
    z[2,1,6]  R603      -8.5356742143630981e-02
    z[2,1,6]  R604      -3.1291925907135010e-01
    z[2,1,6]  R605      -1.1640454828739166e-01
    z[2,1,6]  R606      6.2806069850921631e-02
    z[2,1,6]  R607      -1.5487149357795715e-01
    z[2,1,6]  R608      -2.8832051157951355e-01
    z[2,1,6]  R609      1.5724253654479980e-01
    z[2,1,6]  R610      -3.9755105972290039e-01
    z[2,1,6]  R611      -1.4447268843650818e-01
    z[2,1,6]  R612      -0.627393364906311
    z[2,1,6]  R613      9.4787724316120148e-02
    z[2,1,6]  R614      -0.618626058101654
    z[2,1,6]  R615      -2.2545768320560455e-01
    z[2,1,6]  R616      -1.1636500060558319e-01
    z[2,1,6]  R617      7.9149333760142326e-03
    z[2,1,6]  R618      6.7283022217452526e-03
    z[2,1,6]  R619      -3.9602261781692505e-01
    z[2,1,6]  R620      -3.3947536349296570e-01
    z[2,1,6]  R621      2.0234017074108124e-01
    z[2,1,6]  R622      -2.2302420809864998e-02
    z[2,1,6]  R623      -1.0750397294759750e-01
    z[2,1,6]  R624      3.0643166974186897e-02
    z[2,1,6]  R625      1.7943707108497620e-01
    z[2,1,6]  R626      -2.0033207535743713e-01
    z[2,1,6]  R627      4.6682354062795639e-02
    z[2,1,6]  R628      1.9509072601795197e-01
    z[2,1,6]  R629      -2.5431713089346886e-02
    z[2,1,6]  R630      2.8574258089065552e-01
    z[2,1,6]  R631      9.6433833241462708e-02
    z[2,1,6]  R632      1.7172423005104065e-01
    z[2,1,6]  R633      3.0988961458206177e-01
    z[2,1,6]  R634      2.6388822123408318e-02
    z[2,1,6]  R635      1.7337700724601746e-01
    z[2,1,6]  R636      -7.7882311306893826e-03
    z[2,1,6]  R637      1.8303962051868439e-01
    z[2,1,6]  R638      -3.6888930201530457e-01
    z[2,1,6]  R639      -1.6560163348913193e-02
    z[2,1,6]  R640      -4.9504969269037247e-02
    z[2,1,6]  R641      -1.7858718335628510e-01
    z[2,1,6]  R642      -2.8049442172050476e-01
    z[2,1,6]  R643      -0.483377069234848
    z[2,1,6]  R644      -0.547780454158783
    z[2,1,6]  R645      4.5364937186241150e-01
    z[2,1,6]  R646      -1.0871516168117523e-01
    z[2,1,6]  R647      -7.5729645788669586e-02
    z[2,1,6]  R648      -0.313103049993515
    z[2,1,6]  R649      -4.6434280276298523e-01
    z[1,6,0]  R11       -1
    z[1,6,0]  R56       1
    z[1,6,0]  R650      -1
    z[1,6,0]  R651      1
    z[1,6,0]  R664      -7.5755953788757324e-01
    z[1,6,0]  R665      6.1774069070816040e-01
    z[1,6,0]  R666      -3.3967691659927368e-01
    z[1,6,0]  R667      -7.4591761827468872e-01
    z[1,6,0]  R668      -6.3562631607055664e-01
    z[1,6,0]  R669      -6.7685276269912720e-01
    z[1,6,0]  R670      -7.6198214292526245e-01
    z[1,6,0]  R671      1.2019499391317368e-01
    z[1,6,0]  R672      0.0736149400472641
    z[1,6,0]  R673      -1.8352362513542175e-01
    z[1,6,0]  R674      -2.1915476024150848e-01
    z[1,6,0]  R675      2.4370449781417847e-01
    z[1,6,0]  R676      -3.2098489999771118e-01
    z[1,6,0]  R677      3.3063909411430359e-01
    z[1,6,0]  R678      1.8062606453895569e-01
    z[1,6,0]  R679      -1.9695401191711426e-02
    z[1,6,0]  R680      -2.9621289577335119e-03
    z[1,6,0]  R681      1.9050359725952148e-01
    z[1,6,0]  R682      0.629289448261261
    z[1,6,0]  R683      4.6556234359741211e-02
    z[1,6,0]  R684      -3.0931890010833740e-02
    z[1,6,0]  R685      2.0336858928203583e-02
    z[1,6,0]  R686      -7.1324408054351807e-03
    z[1,6,0]  R687      -0.609872043132782
    z[1,6,0]  R688      -3.5625150799751282e-01
    z[1,6,0]  R689      3.0565840005874634e-01
    z[1,6,0]  R690      5.8468718081712723e-02
    z[1,6,0]  R691      3.7295544147491455e-01
    z[1,6,0]  R692      -4.7175645828247070e-02
    z[1,6,0]  R693      -3.3855131268501282e-01
    z[1,6,0]  R694      3.1291771680116653e-02
    z[1,6,0]  R695      -2.0230922847986221e-02
    z[1,6,0]  R696      1.5634299814701080e-01
    z[1,6,0]  R697      3.0353438854217529e-01
    z[1,6,0]  R698      -7.5079208612442017e-01
    z[1,6,0]  R699      2.2267715632915497e-01
    z[1,6,0]  R700      4.5826411247253418e-01
    z[1,6,0]  R701      3.4416344761848450e-01
    z[1,6,0]  R702      1.6742998361587524e-01
    z[1,6,0]  R703      5.6998956203460693e-01
    z[1,6,0]  R704      -7.1649444103240967e-01
    z[1,6,0]  R705      -7.2960138320922852e-01
    z[1,6,0]  R706      -3.8719708099961281e-03
    z[1,6,0]  R707      0.377970814704895
    z[1,6,0]  R708      3.6683431267738342e-01
    z[1,6,0]  R709      5.4809135198593140e-01
    z[1,6,0]  R710      3.9708280563354492e-01
    z[1,6,0]  R711      2.5789085030555725e-01
    z[1,6,0]  R712      6.8862646818161011e-01
    z[1,6,0]  R713      -6.4441777765750885e-02
    z[1,6,0]  R714      4.6054384112358093e-01
    z[1,6,0]  R715      -1.5428721904754639e-01
    z[1,6,0]  R716      -1.6341438889503479e-01
    z[1,6,0]  R717      -3.2093605399131775e-01
    z[1,6,0]  R718      -8.8356596231460571e-01
    z[1,6,0]  R719      -1.7391633987426758e-01
    z[1,6,0]  R720      -0.804546594619751
    z[1,6,0]  R721      -8.6530953645706177e-01
    z[1,6,0]  R722      6.3675379753112793e-01
    z[1,6,0]  R723      -0.66482013463974
    z[1,6,0]  R724      -6.4516210556030273e-01
    z[1,6,0]  R725      -3.7745776772499084e-01
    z[1,6,0]  R726      -2.4024908244609833e-01
    z[1,6,0]  R727      -2.0745202898979187e-02
    z[1,6,0]  R728      -3.7880662828683853e-02
    z[1,6,0]  R729      -2.6529708504676819e-01
    z[1,6,0]  R730      0.00278069986961782
    z[1,6,0]  R731      -0.371847540140152
    z[1,6,0]  R732      -8.7815326452255249e-01
    z[1,6,0]  R733      -1.9606430083513260e-02
    z[1,6,0]  R734      -1.5016080439090729e-01
    z[1,6,0]  R735      2.2420510649681091e-01
    z[1,6,0]  R736      -1.9836762547492981e-01
    z[1,6,0]  R737      4.6706837415695190e-01
    z[1,6,0]  R738      -1.8074283376336098e-02
    z[1,6,0]  R739      1.8469411134719849e-01
    z[1,6,0]  R740      -6.5395943820476532e-02
    z[1,6,0]  R741      2.0739491283893585e-01
    z[1,6,0]  R742      9.2153802514076233e-02
    z[1,6,0]  R743      -3.3485004305839539e-01
    z[1,6,0]  R744      5.7475157082080841e-02
    z[1,6,0]  R745      8.2998253405094147e-02
    z[1,6,1]  R12       -1
    z[1,6,1]  R57       1
    z[1,6,1]  R652      -1
    z[1,6,1]  R653      1
    z[1,6,1]  R664      8.1886142492294312e-02
    z[1,6,1]  R665      9.7055546939373016e-02
    z[1,6,1]  R666      1.2865361571311951e-01
    z[1,6,1]  R667      6.0638375580310822e-02
    z[1,6,1]  R668      5.5151361972093582e-02
    z[1,6,1]  R669      -4.3803101778030396e-01
    z[1,6,1]  R670      -5.0843238830566406e-01
    z[1,6,1]  R671      -7.6586097478866577e-01
    z[1,6,1]  R672      -6.9656598567962646e-01
    z[1,6,1]  R673      -0.386089026927948
    z[1,6,1]  R674      8.7825745344161987e-01
    z[1,6,1]  R675      0.83925461769104
    z[1,6,1]  R676      6.3452881574630737e-01
    z[1,6,1]  R677      1.6306184232234955e-01
    z[1,6,1]  R678      -8.0407577753067017e-01
    z[1,6,1]  R679      -6.3214516639709473e-01
    z[1,6,1]  R680      -4.4627717137336731e-01
    z[1,6,1]  R681      1.5261571109294891e-01
    z[1,6,1]  R682      0.0878714844584465
    z[1,6,1]  R683      -8.7257444858551025e-01
    z[1,6,1]  R684      -8.7358325719833374e-01
    z[1,6,1]  R685      -5.4689502716064453e-01
    z[1,6,1]  R686      1.1356388777494431e-01
    z[1,6,1]  R687      -4.9036312103271484e-01
    z[1,6,1]  R688      -0.268771767616272
    z[1,6,1]  R689      -1.7898106575012207e-01
    z[1,6,1]  R690      1.5737524256110191e-02
    z[1,6,1]  R691      9.0887606143951416e-02
    z[1,6,1]  R692      -4.1235667467117310e-01
    z[1,6,1]  R693      1.8914127349853516e-01
    z[1,6,1]  R694      -3.6051037907600403e-01
    z[1,6,1]  R695      -4.4455164670944214e-01
    z[1,6,1]  R696      5.7409924268722534e-01
    z[1,6,1]  R697      0.521532416343689
    z[1,6,1]  R698      4.0930244326591492e-01
    z[1,6,1]  R699      5.2007561922073364e-01
    z[1,6,1]  R700      6.0095995664596558e-01
    z[1,6,1]  R701      4.5345729589462280e-01
    z[1,6,1]  R702      5.4914832115173340e-01
    z[1,6,1]  R703      5.0805473327636719e-01
    z[1,6,1]  R704      5.8904081583023071e-01
    z[1,6,1]  R705      2.8098881244659424e-01
    z[1,6,1]  R706      -8.2848638296127319e-01
    z[1,6,1]  R707      -6.1497098207473755e-01
    z[1,6,1]  R708      -5.0910407304763794e-01
    z[1,6,1]  R709      -6.8660420179367065e-01
    z[1,6,1]  R710      -0.74765944480896
    z[1,6,1]  R711      -7.9350328445434570e-01
    z[1,6,1]  R712      -3.7632763385772705e-01
    z[1,6,1]  R713      -5.1575195789337158e-01
    z[1,6,1]  R714      -6.1419796943664551e-01
    z[1,6,1]  R715      -3.1984734535217285e-01
    z[1,6,1]  R716      -2.7069896459579468e-01
    z[1,6,1]  R717      -4.9074128270149231e-01
    z[1,6,1]  R718      8.4123871056362987e-04
    z[1,6,1]  R719      -5.9279185533523560e-01
    z[1,6,1]  R720      3.5964214801788330e-01
    z[1,6,1]  R721      1.4193475246429443e-01
    z[1,6,1]  R722      -6.0124039649963379e-01
    z[1,6,1]  R723      0.0818859413266182
    z[1,6,1]  R724      -5.1137939095497131e-02
    z[1,6,1]  R725      -5.5152320861816406e-01
    z[1,6,1]  R726      -6.5132069587707520e-01
    z[1,6,1]  R727      -6.1464887857437134e-01
    z[1,6,1]  R728      -2.9878202080726624e-01
    z[1,6,1]  R729      -3.0940631031990051e-01
    z[1,6,1]  R730      -3.6072564125061035e-01
    z[1,6,1]  R731      -0.62802654504776
    z[1,6,1]  R732      2.0927037298679352e-01
    z[1,6,1]  R733      -6.8977546691894531e-01
    z[1,6,1]  R734      -6.4189249277114868e-01
    z[1,6,1]  R735      2.0453146100044250e-01
    z[1,6,1]  R736      -6.6997438669204712e-01
    z[1,6,1]  R737      -3.8101676106452942e-01
    z[1,6,1]  R738      0.609222948551178
    z[1,6,1]  R739      6.8127177655696869e-02
    z[1,6,1]  R740      2.0265281200408936e-01
    z[1,6,1]  R741      4.5337605476379395e-01
    z[1,6,1]  R742      2.0321825146675110e-01
    z[1,6,1]  R743      -5.7266287505626678e-02
    z[1,6,1]  R744      1.5035147964954376e-01
    z[1,6,1]  R745      -1.6053926199674606e-02
    z[1,6,2]  R13       -1
    z[1,6,2]  R58       1
    z[1,6,2]  R654      -1
    z[1,6,2]  R655      1
    z[1,6,2]  R664      2.1614845097064972e-01
    z[1,6,2]  R665      -7.2414785623550415e-02
    z[1,6,2]  R666      1.6746085882186890e-01
    z[1,6,2]  R667      -0.552842915058136
    z[1,6,2]  R668      -6.1426943540573120e-01
    z[1,6,2]  R669      1.5637424588203430e-01
    z[1,6,2]  R670      1.4649611711502075e-01
    z[1,6,2]  R671      5.8397012948989868e-01
    z[1,6,2]  R672      6.7283588647842407e-01
    z[1,6,2]  R673      7.0392948389053345e-01
    z[1,6,2]  R674      1.3838779926300049e-01
    z[1,6,2]  R675      -5.0884738564491272e-02
    z[1,6,2]  R676      2.9170921072363853e-02
    z[1,6,2]  R677      -4.9306163191795349e-01
    z[1,6,2]  R678      -3.4111782908439636e-01
    z[1,6,2]  R679      -4.5788824558258057e-01
    z[1,6,2]  R680      -0.519756555557251
    z[1,6,2]  R681      -2.6853203773498535e-01
    z[1,6,2]  R682      5.8138924837112427e-01
    z[1,6,2]  R683      -2.0634530484676361e-01
    z[1,6,2]  R684      -3.3708235621452332e-01
    z[1,6,2]  R685      -3.9220988750457764e-01
    z[1,6,2]  R686      -6.6207003593444824e-01
    z[1,6,2]  R687      -5.6170988082885742e-01
    z[1,6,2]  R688      -4.9344068765640259e-01
    z[1,6,2]  R689      -7.3885542154312134e-01
    z[1,6,2]  R690      -5.0496435165405273e-01
    z[1,6,2]  R691      -3.2723531126976013e-01
    z[1,6,2]  R692      -6.5867567062377930e-01
    z[1,6,2]  R693      -4.8692572116851807e-01
    z[1,6,2]  R694      -5.9139841794967651e-01
    z[1,6,2]  R695      -5.0206708908081055e-01
    z[1,6,2]  R696      7.6512783765792847e-01
    z[1,6,2]  R697      6.8397843837738037e-01
    z[1,6,2]  R698      3.6982640624046326e-01
    z[1,6,2]  R699      7.0460414886474609e-01
    z[1,6,2]  R700      0.552261471748352
    z[1,6,2]  R701      6.2330263853073120e-01
    z[1,6,2]  R702      6.0658687353134155e-01
    z[1,6,2]  R703      5.6052255630493164e-01
    z[1,6,2]  R704      1.9127818942070007e-01
    z[1,6,2]  R705      4.7686657309532166e-01
    z[1,6,2]  R706      -2.2575299441814423e-01
    z[1,6,2]  R707      -4.3765774369239807e-01
    z[1,6,2]  R708      -3.4211507439613342e-01
    z[1,6,2]  R709      -4.0068873763084412e-01
    z[1,6,2]  R710      -1.5267378091812134e-01
    z[1,6,2]  R711      -3.5434699058532715e-01
    z[1,6,2]  R712      -3.5900583863258362e-01
    z[1,6,2]  R713      -1.2537996470928192e-01
    z[1,6,2]  R714      -1.0073851794004440e-01
    z[1,6,2]  R715      -3.6328250169754028e-01
    z[1,6,2]  R716      -5.9387695789337158e-01
    z[1,6,2]  R717      -3.5038021206855774e-01
    z[1,6,2]  R718      -9.6438162028789520e-02
    z[1,6,2]  R719      -4.6328902244567871e-01
    z[1,6,2]  R720      -2.7555164694786072e-01
    z[1,6,2]  R721      1.7317138612270355e-01
    z[1,6,2]  R722      -3.0879771709442139e-01
    z[1,6,2]  R723      -4.7949111461639404e-01
    z[1,6,2]  R724      -4.8743149638175964e-01
    z[1,6,2]  R725      2.0412076264619827e-02
    z[1,6,2]  R726      -0.616512656211853
    z[1,6,2]  R727      -5.6968605518341064e-01
    z[1,6,2]  R728      -5.5516713857650757e-01
    z[1,6,2]  R729      -5.1011794805526733e-01
    z[1,6,2]  R730      -6.2455916404724121e-01
    z[1,6,2]  R731      -2.4228592216968536e-01
    z[1,6,2]  R732      2.3195035755634308e-01
    z[1,6,2]  R733      -3.4269922971725464e-01
    z[1,6,2]  R734      -4.9695184826850891e-01
    z[1,6,2]  R735      1.2902058660984039e-01
    z[1,6,2]  R736      -2.7538421750068665e-01
    z[1,6,2]  R737      -2.1320012211799622e-01
    z[1,6,2]  R738      4.7804632782936096e-01
    z[1,6,2]  R739      5.1289552450180054e-01
    z[1,6,2]  R740      4.1988608241081238e-01
    z[1,6,2]  R741      -1.2099956721067429e-01
    z[1,6,2]  R742      -4.5156544446945190e-01
    z[1,6,2]  R743      -6.2282466888427734e-01
    z[1,6,2]  R744      2.7554255723953247e-01
    z[1,6,2]  R745      3.4326678514480591e-01
    z[1,6,3]  R14       -1
    z[1,6,3]  R59       1
    z[1,6,3]  R656      -1
    z[1,6,3]  R657      1
    z[1,6,3]  R664      -4.0729328989982605e-01
    z[1,6,3]  R665      5.4033064842224121e-01
    z[1,6,3]  R666      -4.8166982829570770e-02
    z[1,6,3]  R667      2.7853947877883911e-01
    z[1,6,3]  R668      -6.4410172402858734e-02
    z[1,6,3]  R669      -3.2127812504768372e-01
    z[1,6,3]  R670      -3.1471493840217590e-01
    z[1,6,3]  R671      -5.5975690484046936e-02
    z[1,6,3]  R672      -9.0436212718486786e-02
    z[1,6,3]  R673      -4.9013805389404297e-01
    z[1,6,3]  R674      -1.2913604080677032e-01
    z[1,6,3]  R675      -2.6757690310478210e-01
    z[1,6,3]  R676      0.289849191904068
    z[1,6,3]  R677      1.5617226064205170e-01
    z[1,6,3]  R678      -2.3016671836376190e-01
    z[1,6,3]  R679      7.4717029929161072e-02
    z[1,6,3]  R680      -3.6574643850326538e-01
    z[1,6,3]  R681      6.8892216682434082e-01
    z[1,6,3]  R682      -0.0466042086482048
    z[1,6,3]  R683      -1.7337203025817871e-01
    z[1,6,3]  R684      5.4751407355070114e-02
    z[1,6,3]  R685      -5.2775126695632935e-01
    z[1,6,3]  R686      7.0285123586654663e-01
    z[1,6,3]  R687      -1.7225007712841034e-01
    z[1,6,3]  R688      4.4561344385147095e-01
    z[1,6,3]  R689      3.9838501811027527e-01
    z[1,6,3]  R690      3.7805780768394470e-01
    z[1,6,3]  R691      6.2986296415328979e-01
    z[1,6,3]  R692      -1.2511213123798370e-01
    z[1,6,3]  R693      0.42557492852211
    z[1,6,3]  R694      -1.0559994727373123e-01
    z[1,6,3]  R695      2.1751316264271736e-02
    z[1,6,3]  R696      1.7642891407012939e-01
    z[1,6,3]  R697      2.7874562144279480e-01
    z[1,6,3]  R698      1.1768934130668640e-01
    z[1,6,3]  R699      0.139877051115036
    z[1,6,3]  R700      1.7006102204322815e-01
    z[1,6,3]  R701      4.9650269746780396e-01
    z[1,6,3]  R702      4.2137256264686584e-01
    z[1,6,3]  R703      1.0021498799324036e-01
    z[1,6,3]  R704      5.2976712584495544e-02
    z[1,6,3]  R705      2.5871220976114273e-02
    z[1,6,3]  R706      -4.0048643946647644e-01
    z[1,6,3]  R707      -2.1492913365364075e-01
    z[1,6,3]  R708      -1.8450836837291718e-01
    z[1,6,3]  R709      1.2105809897184372e-01
    z[1,6,3]  R710      -1.1410713195800781e-01
    z[1,6,3]  R711      2.2164495661854744e-02
    z[1,6,3]  R712      -4.1962409019470215e-01
    z[1,6,3]  R713      -4.3861925601959229e-01
    z[1,6,3]  R714      -5.0154322385787964e-01
    z[1,6,3]  R715      -3.6153492331504822e-01
    z[1,6,3]  R716      -5.6492835283279419e-01
    z[1,6,3]  R717      -0.350996732711792
    z[1,6,3]  R718      7.1377992630004883e-02
    z[1,6,3]  R719      -3.6774033308029175e-01
    z[1,6,3]  R720      1.1131998151540756e-01
    z[1,6,3]  R721      -2.9271697998046875e-01
    z[1,6,3]  R722      -3.3724820613861084e-01
    z[1,6,3]  R723      1.0116033256053925e-01
    z[1,6,3]  R724      2.8972604870796204e-01
    z[1,6,3]  R725      -2.9796159267425537e-01
    z[1,6,3]  R726      -2.4730089306831360e-01
    z[1,6,3]  R727      -3.6283436417579651e-01
    z[1,6,3]  R728      -6.5098208189010620e-01
    z[1,6,3]  R729      -6.8950426578521729e-01
    z[1,6,3]  R730      -2.6326560974121094e-01
    z[1,6,3]  R731      -2.6847904920578003e-01
    z[1,6,3]  R732      -1.8104347586631775e-01
    z[1,6,3]  R733      2.9219800233840942e-01
    z[1,6,3]  R734      5.3422415256500244e-01
    z[1,6,3]  R735      9.3962311744689941e-02
    z[1,6,3]  R736      -3.1924274563789368e-01
    z[1,6,3]  R737      -6.8487578630447388e-01
    z[1,6,3]  R738      -1.2396093457937241e-01
    z[1,6,3]  R739      1.1860295385122299e-01
    z[1,6,3]  R740      -3.6851714830845594e-03
    z[1,6,3]  R741      3.0113914608955383e-01
    z[1,6,3]  R742      2.2926524281501770e-01
    z[1,6,3]  R743      2.7679237723350525e-01
    z[1,6,3]  R744      -5.6929498910903931e-01
    z[1,6,3]  R745      -5.3526127338409424e-01
    z[1,6,4]  R15       -1
    z[1,6,4]  R60       1
    z[1,6,4]  R658      -1
    z[1,6,4]  R659      1
    z[1,6,4]  R664      -2.0273748040199280e-01
    z[1,6,4]  R665      -1.8839581310749054e-01
    z[1,6,4]  R666      -0.280404657125473
    z[1,6,4]  R667      -2.0461490750312805e-01
    z[1,6,4]  R668      -2.5542688369750977e-01
    z[1,6,4]  R669      -2.3426280915737152e-01
    z[1,6,4]  R670      1.6930826008319855e-01
    z[1,6,4]  R671      -1.2058027833700180e-01
    z[1,6,4]  R672      1.4223098754882812e-01
    z[1,6,4]  R673      -1.2113583087921143e-01
    z[1,6,4]  R674      -3.1754605472087860e-02
    z[1,6,4]  R675      -1.3101170957088470e-01
    z[1,6,4]  R676      5.9391045570373535e-01
    z[1,6,4]  R677      -9.2241771519184113e-02
    z[1,6,4]  R678      -2.6756340265274048e-01
    z[1,6,4]  R679      2.6170569658279419e-01
    z[1,6,4]  R680      6.4118497073650360e-02
    z[1,6,4]  R681      -3.7524932622909546e-01
    z[1,6,4]  R682      1.2699003517627716e-01
    z[1,6,4]  R683      -3.5339277982711792e-01
    z[1,6,4]  R684      5.5316165089607239e-02
    z[1,6,4]  R685      -1.0436274856328964e-01
    z[1,6,4]  R686      7.3707611300051212e-03
    z[1,6,4]  R687      -1.1025711894035339e-01
    z[1,6,4]  R688      2.2705543041229248e-01
    z[1,6,4]  R689      1.8147720396518707e-01
    z[1,6,4]  R690      3.1352239847183228e-01
    z[1,6,4]  R691      3.4658116102218628e-01
    z[1,6,4]  R692      -2.7731582522392273e-01
    z[1,6,4]  R693      2.6809543371200562e-01
    z[1,6,4]  R694      -1.9075492024421692e-01
    z[1,6,4]  R695      -5.3753042221069336e-01
    z[1,6,4]  R696      9.7786642611026764e-02
    z[1,6,4]  R697      2.6051837205886841e-01
    z[1,6,4]  R698      -4.0340710431337357e-02
    z[1,6,4]  R699      -2.0097592473030090e-01
    z[1,6,4]  R700      2.7689328417181969e-02
    z[1,6,4]  R701      2.0092625170946121e-02
    z[1,6,4]  R702      -1.9369050860404968e-01
    z[1,6,4]  R703      0.0772441104054451
    z[1,6,4]  R704      -6.6140934824943542e-02
    z[1,6,4]  R705      2.9915568232536316e-01
    z[1,6,4]  R706      1.8556652963161469e-01
    z[1,6,4]  R707      -1.8377484381198883e-01
    z[1,6,4]  R708      -4.2894887924194336e-01
    z[1,6,4]  R709      6.9989293813705444e-02
    z[1,6,4]  R710      2.6184371113777161e-01
    z[1,6,4]  R711      3.8881441950798035e-01
    z[1,6,4]  R712      -2.6986005902290344e-01
    z[1,6,4]  R713      0.478142648935318
    z[1,6,4]  R714      3.4068933129310608e-01
    z[1,6,4]  R715      -5.9474412351846695e-02
    z[1,6,4]  R716      -2.1574285626411438e-01
    z[1,6,4]  R717      -2.8994113206863403e-01
    z[1,6,4]  R718      -1.7099156975746155e-01
    z[1,6,4]  R719      4.3007937073707581e-01
    z[1,6,4]  R720      -1.8034437298774719e-01
    z[1,6,4]  R721      3.6082316190004349e-02
    z[1,6,4]  R722      1.0241910815238953e-01
    z[1,6,4]  R723      -2.6553717255592346e-01
    z[1,6,4]  R724      8.7884448468685150e-02
    z[1,6,4]  R725      3.7979838252067566e-01
    z[1,6,4]  R726      1.2877424061298370e-01
    z[1,6,4]  R727      -2.3375539481639862e-01
    z[1,6,4]  R728      -3.0089142918586731e-01
    z[1,6,4]  R729      -2.5148290395736694e-01
    z[1,6,4]  R730      8.1425786018371582e-02
    z[1,6,4]  R731      5.4870493710041046e-02
    z[1,6,4]  R732      2.2733654081821442e-01
    z[1,6,4]  R733      9.5197439193725586e-02
    z[1,6,4]  R734      -8.6993388831615448e-02
    z[1,6,4]  R735      -4.7589138150215149e-02
    z[1,6,4]  R736      -2.9893046244978905e-02
    z[1,6,4]  R737      -1.7614772915840149e-01
    z[1,6,4]  R738      -8.7283954024314880e-02
    z[1,6,4]  R739      2.7306738495826721e-01
    z[1,6,4]  R740      2.1143786609172821e-01
    z[1,6,4]  R741      7.3112696409225464e-01
    z[1,6,4]  R742      1.8248160183429718e-01
    z[1,6,4]  R743      -5.6155747175216675e-01
    z[1,6,4]  R744      -5.0185203552246094e-01
    z[1,6,4]  R745      -3.0351039767265320e-01
    z[1,6,5]  R16       -1
    z[1,6,5]  R61       1
    z[1,6,5]  R660      -1
    z[1,6,5]  R661      1
    z[1,6,5]  R664      -3.5724973678588867e-01
    z[1,6,5]  R665      -5.2501040697097778e-01
    z[1,6,5]  R666      8.2306081056594849e-01
    z[1,6,5]  R667      7.4455350637435913e-02
    z[1,6,5]  R668      3.4165728092193604e-01
    z[1,6,5]  R669      -2.6723784208297729e-01
    z[1,6,5]  R670      1.0493505001068115e-01
    z[1,6,5]  R671      -1.0127409547567368e-01
    z[1,6,5]  R672      -1.6792723536491394e-01
    z[1,6,5]  R673      -1.8255116045475006e-01
    z[1,6,5]  R674      -8.7863765656948090e-02
    z[1,6,5]  R675      -3.8030883669853210e-01
    z[1,6,5]  R676      2.3301929235458374e-01
    z[1,6,5]  R677      7.4577951431274414e-01
    z[1,6,5]  R678      3.5087481141090393e-02
    z[1,6,5]  R679      -2.8743150830268860e-01
    z[1,6,5]  R680      -3.0452570319175720e-01
    z[1,6,5]  R681      2.1698819100856781e-01
    z[1,6,5]  R682      4.7764277458190918e-01
    z[1,6,5]  R683      1.8217791616916656e-01
    z[1,6,5]  R684      -1.3483242690563202e-01
    z[1,6,5]  R685      -2.0405036211013794e-01
    z[1,6,5]  R686      2.3018307983875275e-01
    z[1,6,5]  R687      1.7263543605804443e-01
    z[1,6,5]  R688      5.5181562900543213e-01
    z[1,6,5]  R689      3.4368079900741577e-01
    z[1,6,5]  R690      7.0261436700820923e-01
    z[1,6,5]  R691      4.7340282797813416e-01
    z[1,6,5]  R692      -2.5899496674537659e-01
    z[1,6,5]  R693      5.5541670322418213e-01
    z[1,6,5]  R694      4.8063647747039795e-01
    z[1,6,5]  R695      3.3625525236129761e-01
    z[1,6,5]  R696      1.1956129968166351e-01
    z[1,6,5]  R697      -3.9061307907104492e-02
    z[1,6,5]  R698      -2.4524421989917755e-01
    z[1,6,5]  R699      -1.1231366544961929e-01
    z[1,6,5]  R700      1.6097915172576904e-01
    z[1,6,5]  R701      -8.4550447762012482e-02
    z[1,6,5]  R702      -6.6976338624954224e-02
    z[1,6,5]  R703      -1.4751136302947998e-01
    z[1,6,5]  R704      2.2243642807006836e-01
    z[1,6,5]  R705      -2.1594022214412689e-01
    z[1,6,5]  R706      9.0554483234882355e-02
    z[1,6,5]  R707      3.4834283590316772e-01
    z[1,6,5]  R708      4.0248975157737732e-02
    z[1,6,5]  R709      -1.4654375612735748e-02
    z[1,6,5]  R710      1.6400316357612610e-01
    z[1,6,5]  R711      -2.3947756737470627e-02
    z[1,6,5]  R712      6.5748989582061768e-02
    z[1,6,5]  R713      5.3899574279785156e-01
    z[1,6,5]  R714      1.7916370928287506e-01
    z[1,6,5]  R715      7.7944636344909668e-01
    z[1,6,5]  R716      3.2812169194221497e-01
    z[1,6,5]  R717      -2.5396534800529480e-01
    z[1,6,5]  R718      -1.5706744790077209e-01
    z[1,6,5]  R719      -7.3487579822540283e-02
    z[1,6,5]  R720      3.1989347189664841e-02
    z[1,6,5]  R721      -2.9093673825263977e-01
    z[1,6,5]  R722      -1.1443016678094864e-01
    z[1,6,5]  R723      -4.5611268281936646e-01
    z[1,6,5]  R724      -3.9596292376518250e-01
    z[1,6,5]  R725      3.6357650160789490e-01
    z[1,6,5]  R726      -2.4460119009017944e-01
    z[1,6,5]  R727      -2.2914563119411469e-01
    z[1,6,5]  R728      -1.7768631875514984e-01
    z[1,6,5]  R729      -1.5092007815837860e-01
    z[1,6,5]  R730      4.6170303225517273e-01
    z[1,6,5]  R731      1.8440628051757812e-01
    z[1,6,5]  R732      2.1487553417682648e-01
    z[1,6,5]  R733      1.4064885675907135e-01
    z[1,6,5]  R734      7.8019447624683380e-02
    z[1,6,5]  R735      -9.2405569553375244e-01
    z[1,6,5]  R736      1.0758799314498901e-01
    z[1,6,5]  R737      2.9926860332489014e-01
    z[1,6,5]  R738      -5.7398641109466553e-01
    z[1,6,5]  R739      -7.5456231832504272e-01
    z[1,6,5]  R740      -8.5650849342346191e-01
    z[1,6,5]  R741      -4.2700063437223434e-02
    z[1,6,5]  R742      -1.5010915696620941e-01
    z[1,6,5]  R743      3.0066564679145813e-01
    z[1,6,5]  R744      -5.5725187063217163e-01
    z[1,6,5]  R745      -6.9269603490829468e-01
    z[1,6,6]  R17       -1
    z[1,6,6]  R62       1
    z[1,6,6]  R662      -1
    z[1,6,6]  R663      1
    z[1,6,6]  R664      1.9509072601795197e-01
    z[1,6,6]  R665      -2.5431713089346886e-02
    z[1,6,6]  R666      2.8574258089065552e-01
    z[1,6,6]  R667      9.6433833241462708e-02
    z[1,6,6]  R668      1.7172423005104065e-01
    z[1,6,6]  R669      3.0988961458206177e-01
    z[1,6,6]  R670      2.6388822123408318e-02
    z[1,6,6]  R671      1.7337700724601746e-01
    z[1,6,6]  R672      -7.7882311306893826e-03
    z[1,6,6]  R673      1.8303962051868439e-01
    z[1,6,6]  R674      -3.6888930201530457e-01
    z[1,6,6]  R675      -1.6560163348913193e-02
    z[1,6,6]  R676      -4.9504969269037247e-02
    z[1,6,6]  R677      -1.7858718335628510e-01
    z[1,6,6]  R678      -2.8049442172050476e-01
    z[1,6,6]  R679      -0.483377069234848
    z[1,6,6]  R680      -0.547780454158783
    z[1,6,6]  R681      4.5364937186241150e-01
    z[1,6,6]  R682      -1.0871516168117523e-01
    z[1,6,6]  R683      -7.5729645788669586e-02
    z[1,6,6]  R684      -0.313103049993515
    z[1,6,6]  R685      -4.6434280276298523e-01
    z[1,6,6]  R686      -4.0954638272523880e-02
    z[1,6,6]  R687      2.1268339827656746e-02
    z[1,6,6]  R688      5.2315339446067810e-02
    z[1,6,6]  R689      1.3736955821514130e-01
    z[1,6,6]  R690      8.0335631966590881e-02
    z[1,6,6]  R691      6.7857488989830017e-02
    z[1,6,6]  R692      -4.8399096727371216e-01
    z[1,6,6]  R693      -2.2590938210487366e-01
    z[1,6,6]  R694      -4.9066364765167236e-01
    z[1,6,6]  R695      -3.8394466042518616e-01
    z[1,6,6]  R696      7.4578978121280670e-02
    z[1,6,6]  R697      -1.4473941922187805e-01
    z[1,6,6]  R698      2.3746220767498016e-01
    z[1,6,6]  R699      3.3301338553428650e-01
    z[1,6,6]  R700      -2.6124054193496704e-01
    z[1,6,6]  R701      1.8263176083564758e-01
    z[1,6,6]  R702      2.8792208433151245e-01
    z[1,6,6]  R703      -2.5502455234527588e-01
    z[1,6,6]  R704      -2.1545359492301941e-01
    z[1,6,6]  R705      1.5662631392478943e-01
    z[1,6,6]  R706      2.4414452910423279e-01
    z[1,6,6]  R707      2.9341778159141541e-01
    z[1,6,6]  R708      5.1917475461959839e-01
    z[1,6,6]  R709      2.1874819695949554e-01
    z[1,6,6]  R710      3.8928383588790894e-01
    z[1,6,6]  R711      1.6137449443340302e-01
    z[1,6,6]  R712      -4.5322526246309280e-02
    z[1,6,6]  R713      -5.1023606210947037e-02
    z[1,6,6]  R714      2.8241056948900223e-02
    z[1,6,6]  R715      1.1728116311132908e-02
    z[1,6,6]  R716      -2.7198362350463867e-01
    z[1,6,6]  R717      5.1151126623153687e-01
    z[1,6,6]  R718      3.8859617710113525e-01
    z[1,6,6]  R719      -2.7948606014251709e-01
    z[1,6,6]  R720      -3.1858119368553162e-01
    z[1,6,6]  R721      1.7168654501438141e-01
    z[1,6,6]  R722      -1.9448006525635719e-02
    z[1,6,6]  R723      -0.180596262216568
    z[1,6,6]  R724      -3.0839884281158447e-01
    z[1,6,6]  R725      4.3326136469841003e-01
    z[1,6,6]  R726      -2.0089246332645416e-02
    z[1,6,6]  R727      2.4173586070537567e-01
    z[1,6,6]  R728      -2.3494267463684082e-01
    z[1,6,6]  R729      -1.1058136820793152e-01
    z[1,6,6]  R730      -4.3667659163475037e-01
    z[1,6,6]  R731      5.4727697372436523e-01
    z[1,6,6]  R732      2.4932242929935455e-02
    z[1,6,6]  R733      5.4051667451858521e-01
    z[1,6,6]  R734      -1.3933502137660980e-01
    z[1,6,6]  R735      -1.6211152076721191e-01
    z[1,6,6]  R736      5.6706565618515015e-01
    z[1,6,6]  R737      3.9679959416389465e-02
    z[1,6,6]  R738      -2.1805323660373688e-01
    z[1,6,6]  R739      2.0046980679035187e-01
    z[1,6,6]  R740      4.9520316533744335e-03
    z[1,6,6]  R741      -3.3127307891845703e-01
    z[1,6,6]  R742      7.9868882894515991e-01
    z[1,6,6]  R743      1.1968600749969482e-01
    z[1,6,6]  R744      1.0809897631406784e-01
    z[1,6,6]  R745      -1.2872619926929474e-01
    z[6,1,0]  R11       1
    z[6,1,0]  R56       -1
    z[6,1,0]  R746      -1
    z[6,1,0]  R747      1
    z[6,1,0]  R760      -7.1324408054351807e-03
    z[6,1,0]  R761      -0.609872043132782
    z[6,1,0]  R762      -3.5625150799751282e-01
    z[6,1,0]  R763      3.0565840005874634e-01
    z[6,1,0]  R764      5.8468718081712723e-02
    z[6,1,0]  R765      3.7295544147491455e-01
    z[6,1,0]  R766      -4.7175645828247070e-02
    z[6,1,0]  R767      -3.3855131268501282e-01
    z[6,1,0]  R768      3.1291771680116653e-02
    z[6,1,0]  R769      -2.0230922847986221e-02
    z[6,1,0]  R770      1.5634299814701080e-01
    z[6,1,0]  R771      3.0353438854217529e-01
    z[6,1,0]  R772      -7.5079208612442017e-01
    z[6,1,0]  R773      2.2267715632915497e-01
    z[6,1,0]  R774      4.5826411247253418e-01
    z[6,1,0]  R775      3.4416344761848450e-01
    z[6,1,0]  R776      1.6742998361587524e-01
    z[6,1,0]  R777      5.6998956203460693e-01
    z[6,1,0]  R778      -7.1649444103240967e-01
    z[6,1,0]  R779      -7.2960138320922852e-01
    z[6,1,0]  R780      -3.8719708099961281e-03
    z[6,1,0]  R781      0.377970814704895
    z[6,1,0]  R782      3.6683431267738342e-01
    z[6,1,0]  R783      5.4809135198593140e-01
    z[6,1,0]  R784      3.9708280563354492e-01
    z[6,1,0]  R785      2.5789085030555725e-01
    z[6,1,0]  R786      6.8862646818161011e-01
    z[6,1,0]  R787      -6.4441777765750885e-02
    z[6,1,0]  R788      4.6054384112358093e-01
    z[6,1,0]  R789      -1.5428721904754639e-01
    z[6,1,0]  R790      -1.6341438889503479e-01
    z[6,1,0]  R791      -3.2093605399131775e-01
    z[6,1,0]  R792      -8.8356596231460571e-01
    z[6,1,0]  R793      -1.7391633987426758e-01
    z[6,1,0]  R794      -0.804546594619751
    z[6,1,0]  R795      -8.6530953645706177e-01
    z[6,1,0]  R796      6.3675379753112793e-01
    z[6,1,0]  R797      -0.66482013463974
    z[6,1,0]  R798      -6.4516210556030273e-01
    z[6,1,0]  R799      -3.7745776772499084e-01
    z[6,1,0]  R800      -2.4024908244609833e-01
    z[6,1,0]  R801      -2.0745202898979187e-02
    z[6,1,0]  R802      -3.7880662828683853e-02
    z[6,1,0]  R803      -2.6529708504676819e-01
    z[6,1,0]  R804      0.00278069986961782
    z[6,1,0]  R805      -0.371847540140152
    z[6,1,0]  R806      -8.7815326452255249e-01
    z[6,1,0]  R807      -1.9606430083513260e-02
    z[6,1,0]  R808      -1.5016080439090729e-01
    z[6,1,0]  R809      2.2420510649681091e-01
    z[6,1,0]  R810      -1.9836762547492981e-01
    z[6,1,0]  R811      4.6706837415695190e-01
    z[6,1,0]  R812      -1.8074283376336098e-02
    z[6,1,0]  R813      1.8469411134719849e-01
    z[6,1,0]  R814      -6.5395943820476532e-02
    z[6,1,0]  R815      2.0739491283893585e-01
    z[6,1,0]  R816      9.2153802514076233e-02
    z[6,1,0]  R817      -3.3485004305839539e-01
    z[6,1,0]  R818      5.7475157082080841e-02
    z[6,1,0]  R819      8.2998253405094147e-02
    z[6,1,0]  R820      -7.5755953788757324e-01
    z[6,1,0]  R821      6.1774069070816040e-01
    z[6,1,0]  R822      -3.3967691659927368e-01
    z[6,1,0]  R823      -7.4591761827468872e-01
    z[6,1,0]  R824      -6.3562631607055664e-01
    z[6,1,0]  R825      -6.7685276269912720e-01
    z[6,1,0]  R826      -7.6198214292526245e-01
    z[6,1,0]  R827      1.2019499391317368e-01
    z[6,1,0]  R828      0.0736149400472641
    z[6,1,0]  R829      -1.8352362513542175e-01
    z[6,1,0]  R830      -2.1915476024150848e-01
    z[6,1,0]  R831      2.4370449781417847e-01
    z[6,1,0]  R832      -3.2098489999771118e-01
    z[6,1,0]  R833      3.3063909411430359e-01
    z[6,1,0]  R834      1.8062606453895569e-01
    z[6,1,0]  R835      -1.9695401191711426e-02
    z[6,1,0]  R836      -2.9621289577335119e-03
    z[6,1,0]  R837      1.9050359725952148e-01
    z[6,1,0]  R838      0.629289448261261
    z[6,1,0]  R839      4.6556234359741211e-02
    z[6,1,0]  R840      -3.0931890010833740e-02
    z[6,1,0]  R841      2.0336858928203583e-02
    z[6,1,1]  R12       1
    z[6,1,1]  R57       -1
    z[6,1,1]  R748      -1
    z[6,1,1]  R749      1
    z[6,1,1]  R760      1.1356388777494431e-01
    z[6,1,1]  R761      -4.9036312103271484e-01
    z[6,1,1]  R762      -0.268771767616272
    z[6,1,1]  R763      -1.7898106575012207e-01
    z[6,1,1]  R764      1.5737524256110191e-02
    z[6,1,1]  R765      9.0887606143951416e-02
    z[6,1,1]  R766      -4.1235667467117310e-01
    z[6,1,1]  R767      1.8914127349853516e-01
    z[6,1,1]  R768      -3.6051037907600403e-01
    z[6,1,1]  R769      -4.4455164670944214e-01
    z[6,1,1]  R770      5.7409924268722534e-01
    z[6,1,1]  R771      0.521532416343689
    z[6,1,1]  R772      4.0930244326591492e-01
    z[6,1,1]  R773      5.2007561922073364e-01
    z[6,1,1]  R774      6.0095995664596558e-01
    z[6,1,1]  R775      4.5345729589462280e-01
    z[6,1,1]  R776      5.4914832115173340e-01
    z[6,1,1]  R777      5.0805473327636719e-01
    z[6,1,1]  R778      5.8904081583023071e-01
    z[6,1,1]  R779      2.8098881244659424e-01
    z[6,1,1]  R780      -8.2848638296127319e-01
    z[6,1,1]  R781      -6.1497098207473755e-01
    z[6,1,1]  R782      -5.0910407304763794e-01
    z[6,1,1]  R783      -6.8660420179367065e-01
    z[6,1,1]  R784      -0.74765944480896
    z[6,1,1]  R785      -7.9350328445434570e-01
    z[6,1,1]  R786      -3.7632763385772705e-01
    z[6,1,1]  R787      -5.1575195789337158e-01
    z[6,1,1]  R788      -6.1419796943664551e-01
    z[6,1,1]  R789      -3.1984734535217285e-01
    z[6,1,1]  R790      -2.7069896459579468e-01
    z[6,1,1]  R791      -4.9074128270149231e-01
    z[6,1,1]  R792      8.4123871056362987e-04
    z[6,1,1]  R793      -5.9279185533523560e-01
    z[6,1,1]  R794      3.5964214801788330e-01
    z[6,1,1]  R795      1.4193475246429443e-01
    z[6,1,1]  R796      -6.0124039649963379e-01
    z[6,1,1]  R797      0.0818859413266182
    z[6,1,1]  R798      -5.1137939095497131e-02
    z[6,1,1]  R799      -5.5152320861816406e-01
    z[6,1,1]  R800      -6.5132069587707520e-01
    z[6,1,1]  R801      -6.1464887857437134e-01
    z[6,1,1]  R802      -2.9878202080726624e-01
    z[6,1,1]  R803      -3.0940631031990051e-01
    z[6,1,1]  R804      -3.6072564125061035e-01
    z[6,1,1]  R805      -0.62802654504776
    z[6,1,1]  R806      2.0927037298679352e-01
    z[6,1,1]  R807      -6.8977546691894531e-01
    z[6,1,1]  R808      -6.4189249277114868e-01
    z[6,1,1]  R809      2.0453146100044250e-01
    z[6,1,1]  R810      -6.6997438669204712e-01
    z[6,1,1]  R811      -3.8101676106452942e-01
    z[6,1,1]  R812      0.609222948551178
    z[6,1,1]  R813      6.8127177655696869e-02
    z[6,1,1]  R814      2.0265281200408936e-01
    z[6,1,1]  R815      4.5337605476379395e-01
    z[6,1,1]  R816      2.0321825146675110e-01
    z[6,1,1]  R817      -5.7266287505626678e-02
    z[6,1,1]  R818      1.5035147964954376e-01
    z[6,1,1]  R819      -1.6053926199674606e-02
    z[6,1,1]  R820      8.1886142492294312e-02
    z[6,1,1]  R821      9.7055546939373016e-02
    z[6,1,1]  R822      1.2865361571311951e-01
    z[6,1,1]  R823      6.0638375580310822e-02
    z[6,1,1]  R824      5.5151361972093582e-02
    z[6,1,1]  R825      -4.3803101778030396e-01
    z[6,1,1]  R826      -5.0843238830566406e-01
    z[6,1,1]  R827      -7.6586097478866577e-01
    z[6,1,1]  R828      -6.9656598567962646e-01
    z[6,1,1]  R829      -0.386089026927948
    z[6,1,1]  R830      8.7825745344161987e-01
    z[6,1,1]  R831      0.83925461769104
    z[6,1,1]  R832      6.3452881574630737e-01
    z[6,1,1]  R833      1.6306184232234955e-01
    z[6,1,1]  R834      -8.0407577753067017e-01
    z[6,1,1]  R835      -6.3214516639709473e-01
    z[6,1,1]  R836      -4.4627717137336731e-01
    z[6,1,1]  R837      1.5261571109294891e-01
    z[6,1,1]  R838      0.0878714844584465
    z[6,1,1]  R839      -8.7257444858551025e-01
    z[6,1,1]  R840      -8.7358325719833374e-01
    z[6,1,1]  R841      -5.4689502716064453e-01
    z[6,1,2]  R13       1
    z[6,1,2]  R58       -1
    z[6,1,2]  R750      -1
    z[6,1,2]  R751      1
    z[6,1,2]  R760      -6.6207003593444824e-01
    z[6,1,2]  R761      -5.6170988082885742e-01
    z[6,1,2]  R762      -4.9344068765640259e-01
    z[6,1,2]  R763      -7.3885542154312134e-01
    z[6,1,2]  R764      -5.0496435165405273e-01
    z[6,1,2]  R765      -3.2723531126976013e-01
    z[6,1,2]  R766      -6.5867567062377930e-01
    z[6,1,2]  R767      -4.8692572116851807e-01
    z[6,1,2]  R768      -5.9139841794967651e-01
    z[6,1,2]  R769      -5.0206708908081055e-01
    z[6,1,2]  R770      7.6512783765792847e-01
    z[6,1,2]  R771      6.8397843837738037e-01
    z[6,1,2]  R772      3.6982640624046326e-01
    z[6,1,2]  R773      7.0460414886474609e-01
    z[6,1,2]  R774      0.552261471748352
    z[6,1,2]  R775      6.2330263853073120e-01
    z[6,1,2]  R776      6.0658687353134155e-01
    z[6,1,2]  R777      5.6052255630493164e-01
    z[6,1,2]  R778      1.9127818942070007e-01
    z[6,1,2]  R779      4.7686657309532166e-01
    z[6,1,2]  R780      -2.2575299441814423e-01
    z[6,1,2]  R781      -4.3765774369239807e-01
    z[6,1,2]  R782      -3.4211507439613342e-01
    z[6,1,2]  R783      -4.0068873763084412e-01
    z[6,1,2]  R784      -1.5267378091812134e-01
    z[6,1,2]  R785      -3.5434699058532715e-01
    z[6,1,2]  R786      -3.5900583863258362e-01
    z[6,1,2]  R787      -1.2537996470928192e-01
    z[6,1,2]  R788      -1.0073851794004440e-01
    z[6,1,2]  R789      -3.6328250169754028e-01
    z[6,1,2]  R790      -5.9387695789337158e-01
    z[6,1,2]  R791      -3.5038021206855774e-01
    z[6,1,2]  R792      -9.6438162028789520e-02
    z[6,1,2]  R793      -4.6328902244567871e-01
    z[6,1,2]  R794      -2.7555164694786072e-01
    z[6,1,2]  R795      1.7317138612270355e-01
    z[6,1,2]  R796      -3.0879771709442139e-01
    z[6,1,2]  R797      -4.7949111461639404e-01
    z[6,1,2]  R798      -4.8743149638175964e-01
    z[6,1,2]  R799      2.0412076264619827e-02
    z[6,1,2]  R800      -0.616512656211853
    z[6,1,2]  R801      -5.6968605518341064e-01
    z[6,1,2]  R802      -5.5516713857650757e-01
    z[6,1,2]  R803      -5.1011794805526733e-01
    z[6,1,2]  R804      -6.2455916404724121e-01
    z[6,1,2]  R805      -2.4228592216968536e-01
    z[6,1,2]  R806      2.3195035755634308e-01
    z[6,1,2]  R807      -3.4269922971725464e-01
    z[6,1,2]  R808      -4.9695184826850891e-01
    z[6,1,2]  R809      1.2902058660984039e-01
    z[6,1,2]  R810      -2.7538421750068665e-01
    z[6,1,2]  R811      -2.1320012211799622e-01
    z[6,1,2]  R812      4.7804632782936096e-01
    z[6,1,2]  R813      5.1289552450180054e-01
    z[6,1,2]  R814      4.1988608241081238e-01
    z[6,1,2]  R815      -1.2099956721067429e-01
    z[6,1,2]  R816      -4.5156544446945190e-01
    z[6,1,2]  R817      -6.2282466888427734e-01
    z[6,1,2]  R818      2.7554255723953247e-01
    z[6,1,2]  R819      3.4326678514480591e-01
    z[6,1,2]  R820      2.1614845097064972e-01
    z[6,1,2]  R821      -7.2414785623550415e-02
    z[6,1,2]  R822      1.6746085882186890e-01
    z[6,1,2]  R823      -0.552842915058136
    z[6,1,2]  R824      -6.1426943540573120e-01
    z[6,1,2]  R825      1.5637424588203430e-01
    z[6,1,2]  R826      1.4649611711502075e-01
    z[6,1,2]  R827      5.8397012948989868e-01
    z[6,1,2]  R828      6.7283588647842407e-01
    z[6,1,2]  R829      7.0392948389053345e-01
    z[6,1,2]  R830      1.3838779926300049e-01
    z[6,1,2]  R831      -5.0884738564491272e-02
    z[6,1,2]  R832      2.9170921072363853e-02
    z[6,1,2]  R833      -4.9306163191795349e-01
    z[6,1,2]  R834      -3.4111782908439636e-01
    z[6,1,2]  R835      -4.5788824558258057e-01
    z[6,1,2]  R836      -0.519756555557251
    z[6,1,2]  R837      -2.6853203773498535e-01
    z[6,1,2]  R838      5.8138924837112427e-01
    z[6,1,2]  R839      -2.0634530484676361e-01
    z[6,1,2]  R840      -3.3708235621452332e-01
    z[6,1,2]  R841      -3.9220988750457764e-01
    z[6,1,3]  R14       1
    z[6,1,3]  R59       -1
    z[6,1,3]  R752      -1
    z[6,1,3]  R753      1
    z[6,1,3]  R760      7.0285123586654663e-01
    z[6,1,3]  R761      -1.7225007712841034e-01
    z[6,1,3]  R762      4.4561344385147095e-01
    z[6,1,3]  R763      3.9838501811027527e-01
    z[6,1,3]  R764      3.7805780768394470e-01
    z[6,1,3]  R765      6.2986296415328979e-01
    z[6,1,3]  R766      -1.2511213123798370e-01
    z[6,1,3]  R767      0.42557492852211
    z[6,1,3]  R768      -1.0559994727373123e-01
    z[6,1,3]  R769      2.1751316264271736e-02
    z[6,1,3]  R770      1.7642891407012939e-01
    z[6,1,3]  R771      2.7874562144279480e-01
    z[6,1,3]  R772      1.1768934130668640e-01
    z[6,1,3]  R773      0.139877051115036
    z[6,1,3]  R774      1.7006102204322815e-01
    z[6,1,3]  R775      4.9650269746780396e-01
    z[6,1,3]  R776      4.2137256264686584e-01
    z[6,1,3]  R777      1.0021498799324036e-01
    z[6,1,3]  R778      5.2976712584495544e-02
    z[6,1,3]  R779      2.5871220976114273e-02
    z[6,1,3]  R780      -4.0048643946647644e-01
    z[6,1,3]  R781      -2.1492913365364075e-01
    z[6,1,3]  R782      -1.8450836837291718e-01
    z[6,1,3]  R783      1.2105809897184372e-01
    z[6,1,3]  R784      -1.1410713195800781e-01
    z[6,1,3]  R785      2.2164495661854744e-02
    z[6,1,3]  R786      -4.1962409019470215e-01
    z[6,1,3]  R787      -4.3861925601959229e-01
    z[6,1,3]  R788      -5.0154322385787964e-01
    z[6,1,3]  R789      -3.6153492331504822e-01
    z[6,1,3]  R790      -5.6492835283279419e-01
    z[6,1,3]  R791      -0.350996732711792
    z[6,1,3]  R792      7.1377992630004883e-02
    z[6,1,3]  R793      -3.6774033308029175e-01
    z[6,1,3]  R794      1.1131998151540756e-01
    z[6,1,3]  R795      -2.9271697998046875e-01
    z[6,1,3]  R796      -3.3724820613861084e-01
    z[6,1,3]  R797      1.0116033256053925e-01
    z[6,1,3]  R798      2.8972604870796204e-01
    z[6,1,3]  R799      -2.9796159267425537e-01
    z[6,1,3]  R800      -2.4730089306831360e-01
    z[6,1,3]  R801      -3.6283436417579651e-01
    z[6,1,3]  R802      -6.5098208189010620e-01
    z[6,1,3]  R803      -6.8950426578521729e-01
    z[6,1,3]  R804      -2.6326560974121094e-01
    z[6,1,3]  R805      -2.6847904920578003e-01
    z[6,1,3]  R806      -1.8104347586631775e-01
    z[6,1,3]  R807      2.9219800233840942e-01
    z[6,1,3]  R808      5.3422415256500244e-01
    z[6,1,3]  R809      9.3962311744689941e-02
    z[6,1,3]  R810      -3.1924274563789368e-01
    z[6,1,3]  R811      -6.8487578630447388e-01
    z[6,1,3]  R812      -1.2396093457937241e-01
    z[6,1,3]  R813      1.1860295385122299e-01
    z[6,1,3]  R814      -3.6851714830845594e-03
    z[6,1,3]  R815      3.0113914608955383e-01
    z[6,1,3]  R816      2.2926524281501770e-01
    z[6,1,3]  R817      2.7679237723350525e-01
    z[6,1,3]  R818      -5.6929498910903931e-01
    z[6,1,3]  R819      -5.3526127338409424e-01
    z[6,1,3]  R820      -4.0729328989982605e-01
    z[6,1,3]  R821      5.4033064842224121e-01
    z[6,1,3]  R822      -4.8166982829570770e-02
    z[6,1,3]  R823      2.7853947877883911e-01
    z[6,1,3]  R824      -6.4410172402858734e-02
    z[6,1,3]  R825      -3.2127812504768372e-01
    z[6,1,3]  R826      -3.1471493840217590e-01
    z[6,1,3]  R827      -5.5975690484046936e-02
    z[6,1,3]  R828      -9.0436212718486786e-02
    z[6,1,3]  R829      -4.9013805389404297e-01
    z[6,1,3]  R830      -1.2913604080677032e-01
    z[6,1,3]  R831      -2.6757690310478210e-01
    z[6,1,3]  R832      0.289849191904068
    z[6,1,3]  R833      1.5617226064205170e-01
    z[6,1,3]  R834      -2.3016671836376190e-01
    z[6,1,3]  R835      7.4717029929161072e-02
    z[6,1,3]  R836      -3.6574643850326538e-01
    z[6,1,3]  R837      6.8892216682434082e-01
    z[6,1,3]  R838      -0.0466042086482048
    z[6,1,3]  R839      -1.7337203025817871e-01
    z[6,1,3]  R840      5.4751407355070114e-02
    z[6,1,3]  R841      -5.2775126695632935e-01
    z[6,1,4]  R15       1
    z[6,1,4]  R60       -1
    z[6,1,4]  R754      -1
    z[6,1,4]  R755      1
    z[6,1,4]  R760      7.3707611300051212e-03
    z[6,1,4]  R761      -1.1025711894035339e-01
    z[6,1,4]  R762      2.2705543041229248e-01
    z[6,1,4]  R763      1.8147720396518707e-01
    z[6,1,4]  R764      3.1352239847183228e-01
    z[6,1,4]  R765      3.4658116102218628e-01
    z[6,1,4]  R766      -2.7731582522392273e-01
    z[6,1,4]  R767      2.6809543371200562e-01
    z[6,1,4]  R768      -1.9075492024421692e-01
    z[6,1,4]  R769      -5.3753042221069336e-01
    z[6,1,4]  R770      9.7786642611026764e-02
    z[6,1,4]  R771      2.6051837205886841e-01
    z[6,1,4]  R772      -4.0340710431337357e-02
    z[6,1,4]  R773      -2.0097592473030090e-01
    z[6,1,4]  R774      2.7689328417181969e-02
    z[6,1,4]  R775      2.0092625170946121e-02
    z[6,1,4]  R776      -1.9369050860404968e-01
    z[6,1,4]  R777      0.0772441104054451
    z[6,1,4]  R778      -6.6140934824943542e-02
    z[6,1,4]  R779      2.9915568232536316e-01
    z[6,1,4]  R780      1.8556652963161469e-01
    z[6,1,4]  R781      -1.8377484381198883e-01
    z[6,1,4]  R782      -4.2894887924194336e-01
    z[6,1,4]  R783      6.9989293813705444e-02
    z[6,1,4]  R784      2.6184371113777161e-01
    z[6,1,4]  R785      3.8881441950798035e-01
    z[6,1,4]  R786      -2.6986005902290344e-01
    z[6,1,4]  R787      0.478142648935318
    z[6,1,4]  R788      3.4068933129310608e-01
    z[6,1,4]  R789      -5.9474412351846695e-02
    z[6,1,4]  R790      -2.1574285626411438e-01
    z[6,1,4]  R791      -2.8994113206863403e-01
    z[6,1,4]  R792      -1.7099156975746155e-01
    z[6,1,4]  R793      4.3007937073707581e-01
    z[6,1,4]  R794      -1.8034437298774719e-01
    z[6,1,4]  R795      3.6082316190004349e-02
    z[6,1,4]  R796      1.0241910815238953e-01
    z[6,1,4]  R797      -2.6553717255592346e-01
    z[6,1,4]  R798      8.7884448468685150e-02
    z[6,1,4]  R799      3.7979838252067566e-01
    z[6,1,4]  R800      1.2877424061298370e-01
    z[6,1,4]  R801      -2.3375539481639862e-01
    z[6,1,4]  R802      -3.0089142918586731e-01
    z[6,1,4]  R803      -2.5148290395736694e-01
    z[6,1,4]  R804      8.1425786018371582e-02
    z[6,1,4]  R805      5.4870493710041046e-02
    z[6,1,4]  R806      2.2733654081821442e-01
    z[6,1,4]  R807      9.5197439193725586e-02
    z[6,1,4]  R808      -8.6993388831615448e-02
    z[6,1,4]  R809      -4.7589138150215149e-02
    z[6,1,4]  R810      -2.9893046244978905e-02
    z[6,1,4]  R811      -1.7614772915840149e-01
    z[6,1,4]  R812      -8.7283954024314880e-02
    z[6,1,4]  R813      2.7306738495826721e-01
    z[6,1,4]  R814      2.1143786609172821e-01
    z[6,1,4]  R815      7.3112696409225464e-01
    z[6,1,4]  R816      1.8248160183429718e-01
    z[6,1,4]  R817      -5.6155747175216675e-01
    z[6,1,4]  R818      -5.0185203552246094e-01
    z[6,1,4]  R819      -3.0351039767265320e-01
    z[6,1,4]  R820      -2.0273748040199280e-01
    z[6,1,4]  R821      -1.8839581310749054e-01
    z[6,1,4]  R822      -0.280404657125473
    z[6,1,4]  R823      -2.0461490750312805e-01
    z[6,1,4]  R824      -2.5542688369750977e-01
    z[6,1,4]  R825      -2.3426280915737152e-01
    z[6,1,4]  R826      1.6930826008319855e-01
    z[6,1,4]  R827      -1.2058027833700180e-01
    z[6,1,4]  R828      1.4223098754882812e-01
    z[6,1,4]  R829      -1.2113583087921143e-01
    z[6,1,4]  R830      -3.1754605472087860e-02
    z[6,1,4]  R831      -1.3101170957088470e-01
    z[6,1,4]  R832      5.9391045570373535e-01
    z[6,1,4]  R833      -9.2241771519184113e-02
    z[6,1,4]  R834      -2.6756340265274048e-01
    z[6,1,4]  R835      2.6170569658279419e-01
    z[6,1,4]  R836      6.4118497073650360e-02
    z[6,1,4]  R837      -3.7524932622909546e-01
    z[6,1,4]  R838      1.2699003517627716e-01
    z[6,1,4]  R839      -3.5339277982711792e-01
    z[6,1,4]  R840      5.5316165089607239e-02
    z[6,1,4]  R841      -1.0436274856328964e-01
    z[6,1,5]  R16       1
    z[6,1,5]  R61       -1
    z[6,1,5]  R756      -1
    z[6,1,5]  R757      1
    z[6,1,5]  R760      2.3018307983875275e-01
    z[6,1,5]  R761      1.7263543605804443e-01
    z[6,1,5]  R762      5.5181562900543213e-01
    z[6,1,5]  R763      3.4368079900741577e-01
    z[6,1,5]  R764      7.0261436700820923e-01
    z[6,1,5]  R765      4.7340282797813416e-01
    z[6,1,5]  R766      -2.5899496674537659e-01
    z[6,1,5]  R767      5.5541670322418213e-01
    z[6,1,5]  R768      4.8063647747039795e-01
    z[6,1,5]  R769      3.3625525236129761e-01
    z[6,1,5]  R770      1.1956129968166351e-01
    z[6,1,5]  R771      -3.9061307907104492e-02
    z[6,1,5]  R772      -2.4524421989917755e-01
    z[6,1,5]  R773      -1.1231366544961929e-01
    z[6,1,5]  R774      1.6097915172576904e-01
    z[6,1,5]  R775      -8.4550447762012482e-02
    z[6,1,5]  R776      -6.6976338624954224e-02
    z[6,1,5]  R777      -1.4751136302947998e-01
    z[6,1,5]  R778      2.2243642807006836e-01
    z[6,1,5]  R779      -2.1594022214412689e-01
    z[6,1,5]  R780      9.0554483234882355e-02
    z[6,1,5]  R781      3.4834283590316772e-01
    z[6,1,5]  R782      4.0248975157737732e-02
    z[6,1,5]  R783      -1.4654375612735748e-02
    z[6,1,5]  R784      1.6400316357612610e-01
    z[6,1,5]  R785      -2.3947756737470627e-02
    z[6,1,5]  R786      6.5748989582061768e-02
    z[6,1,5]  R787      5.3899574279785156e-01
    z[6,1,5]  R788      1.7916370928287506e-01
    z[6,1,5]  R789      7.7944636344909668e-01
    z[6,1,5]  R790      3.2812169194221497e-01
    z[6,1,5]  R791      -2.5396534800529480e-01
    z[6,1,5]  R792      -1.5706744790077209e-01
    z[6,1,5]  R793      -7.3487579822540283e-02
    z[6,1,5]  R794      3.1989347189664841e-02
    z[6,1,5]  R795      -2.9093673825263977e-01
    z[6,1,5]  R796      -1.1443016678094864e-01
    z[6,1,5]  R797      -4.5611268281936646e-01
    z[6,1,5]  R798      -3.9596292376518250e-01
    z[6,1,5]  R799      3.6357650160789490e-01
    z[6,1,5]  R800      -2.4460119009017944e-01
    z[6,1,5]  R801      -2.2914563119411469e-01
    z[6,1,5]  R802      -1.7768631875514984e-01
    z[6,1,5]  R803      -1.5092007815837860e-01
    z[6,1,5]  R804      4.6170303225517273e-01
    z[6,1,5]  R805      1.8440628051757812e-01
    z[6,1,5]  R806      2.1487553417682648e-01
    z[6,1,5]  R807      1.4064885675907135e-01
    z[6,1,5]  R808      7.8019447624683380e-02
    z[6,1,5]  R809      -9.2405569553375244e-01
    z[6,1,5]  R810      1.0758799314498901e-01
    z[6,1,5]  R811      2.9926860332489014e-01
    z[6,1,5]  R812      -5.7398641109466553e-01
    z[6,1,5]  R813      -7.5456231832504272e-01
    z[6,1,5]  R814      -8.5650849342346191e-01
    z[6,1,5]  R815      -4.2700063437223434e-02
    z[6,1,5]  R816      -1.5010915696620941e-01
    z[6,1,5]  R817      3.0066564679145813e-01
    z[6,1,5]  R818      -5.5725187063217163e-01
    z[6,1,5]  R819      -6.9269603490829468e-01
    z[6,1,5]  R820      -3.5724973678588867e-01
    z[6,1,5]  R821      -5.2501040697097778e-01
    z[6,1,5]  R822      8.2306081056594849e-01
    z[6,1,5]  R823      7.4455350637435913e-02
    z[6,1,5]  R824      3.4165728092193604e-01
    z[6,1,5]  R825      -2.6723784208297729e-01
    z[6,1,5]  R826      1.0493505001068115e-01
    z[6,1,5]  R827      -1.0127409547567368e-01
    z[6,1,5]  R828      -1.6792723536491394e-01
    z[6,1,5]  R829      -1.8255116045475006e-01
    z[6,1,5]  R830      -8.7863765656948090e-02
    z[6,1,5]  R831      -3.8030883669853210e-01
    z[6,1,5]  R832      2.3301929235458374e-01
    z[6,1,5]  R833      7.4577951431274414e-01
    z[6,1,5]  R834      3.5087481141090393e-02
    z[6,1,5]  R835      -2.8743150830268860e-01
    z[6,1,5]  R836      -3.0452570319175720e-01
    z[6,1,5]  R837      2.1698819100856781e-01
    z[6,1,5]  R838      4.7764277458190918e-01
    z[6,1,5]  R839      1.8217791616916656e-01
    z[6,1,5]  R840      -1.3483242690563202e-01
    z[6,1,5]  R841      -2.0405036211013794e-01
    z[6,1,6]  R17       1
    z[6,1,6]  R62       -1
    z[6,1,6]  R758      -1
    z[6,1,6]  R759      1
    z[6,1,6]  R760      -4.0954638272523880e-02
    z[6,1,6]  R761      2.1268339827656746e-02
    z[6,1,6]  R762      5.2315339446067810e-02
    z[6,1,6]  R763      1.3736955821514130e-01
    z[6,1,6]  R764      8.0335631966590881e-02
    z[6,1,6]  R765      6.7857488989830017e-02
    z[6,1,6]  R766      -4.8399096727371216e-01
    z[6,1,6]  R767      -2.2590938210487366e-01
    z[6,1,6]  R768      -4.9066364765167236e-01
    z[6,1,6]  R769      -3.8394466042518616e-01
    z[6,1,6]  R770      7.4578978121280670e-02
    z[6,1,6]  R771      -1.4473941922187805e-01
    z[6,1,6]  R772      2.3746220767498016e-01
    z[6,1,6]  R773      3.3301338553428650e-01
    z[6,1,6]  R774      -2.6124054193496704e-01
    z[6,1,6]  R775      1.8263176083564758e-01
    z[6,1,6]  R776      2.8792208433151245e-01
    z[6,1,6]  R777      -2.5502455234527588e-01
    z[6,1,6]  R778      -2.1545359492301941e-01
    z[6,1,6]  R779      1.5662631392478943e-01
    z[6,1,6]  R780      2.4414452910423279e-01
    z[6,1,6]  R781      2.9341778159141541e-01
    z[6,1,6]  R782      5.1917475461959839e-01
    z[6,1,6]  R783      2.1874819695949554e-01
    z[6,1,6]  R784      3.8928383588790894e-01
    z[6,1,6]  R785      1.6137449443340302e-01
    z[6,1,6]  R786      -4.5322526246309280e-02
    z[6,1,6]  R787      -5.1023606210947037e-02
    z[6,1,6]  R788      2.8241056948900223e-02
    z[6,1,6]  R789      1.1728116311132908e-02
    z[6,1,6]  R790      -2.7198362350463867e-01
    z[6,1,6]  R791      5.1151126623153687e-01
    z[6,1,6]  R792      3.8859617710113525e-01
    z[6,1,6]  R793      -2.7948606014251709e-01
    z[6,1,6]  R794      -3.1858119368553162e-01
    z[6,1,6]  R795      1.7168654501438141e-01
    z[6,1,6]  R796      -1.9448006525635719e-02
    z[6,1,6]  R797      -0.180596262216568
    z[6,1,6]  R798      -3.0839884281158447e-01
    z[6,1,6]  R799      4.3326136469841003e-01
    z[6,1,6]  R800      -2.0089246332645416e-02
    z[6,1,6]  R801      2.4173586070537567e-01
    z[6,1,6]  R802      -2.3494267463684082e-01
    z[6,1,6]  R803      -1.1058136820793152e-01
    z[6,1,6]  R804      -4.3667659163475037e-01
    z[6,1,6]  R805      5.4727697372436523e-01
    z[6,1,6]  R806      2.4932242929935455e-02
    z[6,1,6]  R807      5.4051667451858521e-01
    z[6,1,6]  R808      -1.3933502137660980e-01
    z[6,1,6]  R809      -1.6211152076721191e-01
    z[6,1,6]  R810      5.6706565618515015e-01
    z[6,1,6]  R811      3.9679959416389465e-02
    z[6,1,6]  R812      -2.1805323660373688e-01
    z[6,1,6]  R813      2.0046980679035187e-01
    z[6,1,6]  R814      4.9520316533744335e-03
    z[6,1,6]  R815      -3.3127307891845703e-01
    z[6,1,6]  R816      7.9868882894515991e-01
    z[6,1,6]  R817      1.1968600749969482e-01
    z[6,1,6]  R818      1.0809897631406784e-01
    z[6,1,6]  R819      -1.2872619926929474e-01
    z[6,1,6]  R820      1.9509072601795197e-01
    z[6,1,6]  R821      -2.5431713089346886e-02
    z[6,1,6]  R822      2.8574258089065552e-01
    z[6,1,6]  R823      9.6433833241462708e-02
    z[6,1,6]  R824      1.7172423005104065e-01
    z[6,1,6]  R825      3.0988961458206177e-01
    z[6,1,6]  R826      2.6388822123408318e-02
    z[6,1,6]  R827      1.7337700724601746e-01
    z[6,1,6]  R828      -7.7882311306893826e-03
    z[6,1,6]  R829      1.8303962051868439e-01
    z[6,1,6]  R830      -3.6888930201530457e-01
    z[6,1,6]  R831      -1.6560163348913193e-02
    z[6,1,6]  R832      -4.9504969269037247e-02
    z[6,1,6]  R833      -1.7858718335628510e-01
    z[6,1,6]  R834      -2.8049442172050476e-01
    z[6,1,6]  R835      -0.483377069234848
    z[6,1,6]  R836      -0.547780454158783
    z[6,1,6]  R837      4.5364937186241150e-01
    z[6,1,6]  R838      -1.0871516168117523e-01
    z[6,1,6]  R839      -7.5729645788669586e-02
    z[6,1,6]  R840      -0.313103049993515
    z[6,1,6]  R841      -4.6434280276298523e-01
    z[1,7,0]  R11       -1
    z[1,7,0]  R65       1
    z[1,7,0]  R842      -1
    z[1,7,0]  R843      1
    z[1,7,0]  R856      -7.5755953788757324e-01
    z[1,7,0]  R857      6.1774069070816040e-01
    z[1,7,0]  R858      -3.3967691659927368e-01
    z[1,7,0]  R859      -7.4591761827468872e-01
    z[1,7,0]  R860      -6.3562631607055664e-01
    z[1,7,0]  R861      -6.7685276269912720e-01
    z[1,7,0]  R862      -7.6198214292526245e-01
    z[1,7,0]  R863      1.2019499391317368e-01
    z[1,7,0]  R864      0.0736149400472641
    z[1,7,0]  R865      -1.8352362513542175e-01
    z[1,7,0]  R866      -2.1915476024150848e-01
    z[1,7,0]  R867      2.4370449781417847e-01
    z[1,7,0]  R868      -3.2098489999771118e-01
    z[1,7,0]  R869      3.3063909411430359e-01
    z[1,7,0]  R870      1.8062606453895569e-01
    z[1,7,0]  R871      -1.9695401191711426e-02
    z[1,7,0]  R872      -2.9621289577335119e-03
    z[1,7,0]  R873      1.9050359725952148e-01
    z[1,7,0]  R874      0.629289448261261
    z[1,7,0]  R875      4.6556234359741211e-02
    z[1,7,0]  R876      -3.0931890010833740e-02
    z[1,7,0]  R877      2.0336858928203583e-02
    z[1,7,0]  R878      -5.5729341506958008e-01
    z[1,7,0]  R879      -0.570170521736145
    z[1,7,0]  R880      -0.519062876701355
    z[1,7,0]  R881      -1.5749590098857880e-01
    z[1,7,0]  R882      -2.7505412697792053e-01
    z[1,7,0]  R883      -3.7525451183319092e-01
    z[1,7,0]  R884      2.3901455104351044e-02
    z[1,7,0]  R885      -2.5289878249168396e-01
    z[1,7,0]  R886      4.0116536617279053e-01
    z[1,7,0]  R887      -1.9124847650527954e-01
    z[1,7,0]  R888      -5.3013980388641357e-01
    z[1,7,0]  R889      7.6019114255905151e-01
    z[1,7,0]  R890      -2.5712382793426514e-01
    z[1,7,0]  R891      -3.3564478158950806e-01
    z[1,7,0]  R892      -0.532228410243988
    z[1,7,0]  R893      7.5140100717544556e-01
    z[1,7,0]  R894      -6.1134433746337891e-01
    z[1,7,0]  R895      -7.5698435306549072e-01
    z[1,7,0]  R896      -5.2028256654739380e-01
    z[1,7,0]  R897      1.3251268863677979e-01
    z[1,7,0]  R898      6.0195124149322510e-01
    z[1,7,0]  R899      5.9818547964096069e-01
    z[1,7,0]  R900      6.7245703935623169e-01
    z[1,7,0]  R901      4.9734145402908325e-01
    z[1,7,0]  R902      0.382784366607666
    z[1,7,0]  R903      5.3919726610183716e-01
    z[1,7,0]  R904      0.352083295583725
    z[1,7,0]  R905      1.0322692990303040e-01
    z[1,7,0]  R906      -3.5776447504758835e-02
    z[1,7,0]  R907      -6.2972344458103180e-02
    z[1,7,0]  R908      3.9761614799499512e-01
    z[1,7,0]  R909      3.1109130382537842e-01
    z[1,7,0]  R910      6.0046070814132690e-01
    z[1,7,0]  R911      6.0410302132368088e-02
    z[1,7,0]  R912      -4.0367566980421543e-03
    z[1,7,0]  R913      3.0294919013977051e-01
    z[1,7,0]  R914      5.7300585508346558e-01
    z[1,7,0]  R915      1.5232123434543610e-01
    z[1,7,0]  R916      -5.1245975494384766e-01
    z[1,7,0]  R917      7.1005530655384064e-02
    z[1,7,0]  R918      -1.8540312349796295e-01
    z[1,7,0]  R919      -6.8541193008422852e-01
    z[1,7,0]  R920      -2.7038168907165527e-01
    z[1,7,0]  R921      -0.452766478061676
    z[1,7,0]  R922      -4.6305142343044281e-02
    z[1,7,0]  R923      -7.7871638350188732e-03
    z[1,7,0]  R924      7.7178925275802612e-02
    z[1,7,0]  R925      -2.6318386197090149e-01
    z[1,7,0]  R926      2.7791216969490051e-01
    z[1,7,0]  R927      0.000984802725724876
    z[1,7,0]  R928      2.8282368183135986e-01
    z[1,7,0]  R929      -2.5316581130027771e-01
    z[1,7,0]  R930      1.2265031225979328e-02
    z[1,7,0]  R931      -4.1162014007568359e-01
    z[1,7,0]  R932      -2.6204910874366760e-01
    z[1,7,0]  R933      -6.1397153139114380e-01
    z[1,7,0]  R934      -1.5431550145149231e-01
    z[1,7,0]  R935      2.1453516185283661e-01
    z[1,7,0]  R936      1.5545056760311127e-01
    z[1,7,0]  R937      -5.9662234783172607e-01
    z[1,7,0]  R938      -1.2338148802518845e-01
    z[1,7,0]  R939      -1.2407746165990829e-01
    z[1,7,0]  R940      -3.0643790960311890e-01
    z[1,7,0]  R941      2.3313535749912262e-01
    z[1,7,0]  R942      5.5375963449478149e-01
    z[1,7,0]  R943      -1.8920011818408966e-01
    z[1,7,0]  R944      -5.3123313188552856e-01
    z[1,7,0]  R945      5.9123420715332031e-01
    z[1,7,0]  R946      5.3236150741577148e-01
    z[1,7,0]  R947      3.4476128220558167e-01
    z[1,7,1]  R12       -1
    z[1,7,1]  R66       1
    z[1,7,1]  R844      -1
    z[1,7,1]  R845      1
    z[1,7,1]  R856      8.1886142492294312e-02
    z[1,7,1]  R857      9.7055546939373016e-02
    z[1,7,1]  R858      1.2865361571311951e-01
    z[1,7,1]  R859      6.0638375580310822e-02
    z[1,7,1]  R860      5.5151361972093582e-02
    z[1,7,1]  R861      -4.3803101778030396e-01
    z[1,7,1]  R862      -5.0843238830566406e-01
    z[1,7,1]  R863      -7.6586097478866577e-01
    z[1,7,1]  R864      -6.9656598567962646e-01
    z[1,7,1]  R865      -0.386089026927948
    z[1,7,1]  R866      8.7825745344161987e-01
    z[1,7,1]  R867      0.83925461769104
    z[1,7,1]  R868      6.3452881574630737e-01
    z[1,7,1]  R869      1.6306184232234955e-01
    z[1,7,1]  R870      -8.0407577753067017e-01
    z[1,7,1]  R871      -6.3214516639709473e-01
    z[1,7,1]  R872      -4.4627717137336731e-01
    z[1,7,1]  R873      1.5261571109294891e-01
    z[1,7,1]  R874      0.0878714844584465
    z[1,7,1]  R875      -8.7257444858551025e-01
    z[1,7,1]  R876      -8.7358325719833374e-01
    z[1,7,1]  R877      -5.4689502716064453e-01
    z[1,7,1]  R878      -7.3747581243515015e-01
    z[1,7,1]  R879      -7.4708157777786255e-01
    z[1,7,1]  R880      -7.3020076751708984e-01
    z[1,7,1]  R881      -9.3595254421234131e-01
    z[1,7,1]  R882      -8.7157249450683594e-01
    z[1,7,1]  R883      -8.0742329359054565e-01
    z[1,7,1]  R884      -1.9723260775208473e-02
    z[1,7,1]  R885      -8.6047857999801636e-01
    z[1,7,1]  R886      3.9040920138359070e-01
    z[1,7,1]  R887      -8.3041661977767944e-01
    z[1,7,1]  R888      0.418416827917099
    z[1,7,1]  R889      5.7618740946054459e-02
    z[1,7,1]  R890      3.9711853861808777e-01
    z[1,7,1]  R891      3.7892201542854309e-01
    z[1,7,1]  R892      4.4411951303482056e-01
    z[1,7,1]  R893      -2.7559101581573486e-01
    z[1,7,1]  R894      4.4987294077873230e-01
    z[1,7,1]  R895      3.6728054285049438e-01
    z[1,7,1]  R896      0.534921407699585
    z[1,7,1]  R897      2.6610809564590454e-01
    z[1,7,1]  R898      1.7845438420772552e-01
    z[1,7,1]  R899      -4.6498408913612366e-01
    z[1,7,1]  R900      -2.5442427396774292e-01
    z[1,7,1]  R901      -4.4862989336252213e-02
    z[1,7,1]  R902      -1.2408622354269028e-01
    z[1,7,1]  R903      -3.0851846933364868e-01
    z[1,7,1]  R904      -4.3527570366859436e-01
    z[1,7,1]  R905      3.5347703844308853e-02
    z[1,7,1]  R906      2.0681785047054291e-01
    z[1,7,1]  R907      9.0527945756912231e-01
    z[1,7,1]  R908      -1.1390823125839233e-01
    z[1,7,1]  R909      3.4702695906162262e-02
    z[1,7,1]  R910      -2.0013208687305450e-01
    z[1,7,1]  R911      -3.1605863571166992e-01
    z[1,7,1]  R912      -6.7666035890579224e-01
    z[1,7,1]  R913      3.5550642013549805e-01
    z[1,7,1]  R914      1.4513367414474487e-01
    z[1,7,1]  R915      -1.2593352794647217e-01
    z[1,7,1]  R916      1.0443762689828873e-01
    z[1,7,1]  R917      9.5946002006530762e-01
    z[1,7,1]  R918      -6.5885370969772339e-01
    z[1,7,1]  R919      2.4410164356231689e-01
    z[1,7,1]  R920      2.7930954098701477e-01
    z[1,7,1]  R921      4.5855066180229187e-01
    z[1,7,1]  R922      9.0118712186813354e-01
    z[1,7,1]  R923      9.7862249612808228e-01
    z[1,7,1]  R924      0.916998565196991
    z[1,7,1]  R925      9.1740399599075317e-01
    z[1,7,1]  R926      -5.0423923879861832e-02
    z[1,7,1]  R927      2.1070607006549835e-01
    z[1,7,1]  R928      -4.6093201637268066e-01
    z[1,7,1]  R929      -5.1532387733459473e-01
    z[1,7,1]  R930      -5.8087170124053955e-01
    z[1,7,1]  R931      2.6048794388771057e-01
    z[1,7,1]  R932      1.4729660749435425e-01
    z[1,7,1]  R933      4.6828430891036987e-01
    z[1,7,1]  R934      9.2185807228088379e-01
    z[1,7,1]  R935      8.7684553861618042e-01
    z[1,7,1]  R936      9.4337785243988037e-01
    z[1,7,1]  R937      3.8790026307106018e-01
    z[1,7,1]  R938      0.128950834274292
    z[1,7,1]  R939      -4.7677025198936462e-01
    z[1,7,1]  R940      5.0981199741363525e-01
    z[1,7,1]  R941      9.1037929058074951e-01
    z[1,7,1]  R942      1.2420173734426498e-01
    z[1,7,1]  R943      7.7613222599029541e-01
    z[1,7,1]  R944      7.1518266201019287e-01
    z[1,7,1]  R945      1.3515974581241608e-01
    z[1,7,1]  R946      -1.9805087149143219e-01
    z[1,7,1]  R947      -4.6662919223308563e-02
    z[1,7,2]  R13       -1
    z[1,7,2]  R67       1
    z[1,7,2]  R846      -1
    z[1,7,2]  R847      1
    z[1,7,2]  R856      2.1614845097064972e-01
    z[1,7,2]  R857      -7.2414785623550415e-02
    z[1,7,2]  R858      1.6746085882186890e-01
    z[1,7,2]  R859      -0.552842915058136
    z[1,7,2]  R860      -6.1426943540573120e-01
    z[1,7,2]  R861      1.5637424588203430e-01
    z[1,7,2]  R862      1.4649611711502075e-01
    z[1,7,2]  R863      5.8397012948989868e-01
    z[1,7,2]  R864      6.7283588647842407e-01
    z[1,7,2]  R865      7.0392948389053345e-01
    z[1,7,2]  R866      1.3838779926300049e-01
    z[1,7,2]  R867      -5.0884738564491272e-02
    z[1,7,2]  R868      2.9170921072363853e-02
    z[1,7,2]  R869      -4.9306163191795349e-01
    z[1,7,2]  R870      -3.4111782908439636e-01
    z[1,7,2]  R871      -4.5788824558258057e-01
    z[1,7,2]  R872      -0.519756555557251
    z[1,7,2]  R873      -2.6853203773498535e-01
    z[1,7,2]  R874      5.8138924837112427e-01
    z[1,7,2]  R875      -2.0634530484676361e-01
    z[1,7,2]  R876      -3.3708235621452332e-01
    z[1,7,2]  R877      -3.9220988750457764e-01
    z[1,7,2]  R878      0.298555850982666
    z[1,7,2]  R879      1.8358130753040314e-01
    z[1,7,2]  R880      1.9443720579147339e-01
    z[1,7,2]  R881      1.5707209706306458e-01
    z[1,7,2]  R882      -2.6619702577590942e-01
    z[1,7,2]  R883      -1.0090090334415436e-01
    z[1,7,2]  R884      -7.4030059576034546e-01
    z[1,7,2]  R885      -1.6972111165523529e-01
    z[1,7,2]  R886      -7.7183133363723755e-01
    z[1,7,2]  R887      1.4229343831539154e-01
    z[1,7,2]  R888      5.8528393507003784e-01
    z[1,7,2]  R889      -3.7061061710119247e-02
    z[1,7,2]  R890      8.3552157878875732e-01
    z[1,7,2]  R891      4.7039976716041565e-01
    z[1,7,2]  R892      3.7349972128868103e-01
    z[1,7,2]  R893      5.8752644807100296e-02
    z[1,7,2]  R894      2.3887164890766144e-01
    z[1,7,2]  R895      2.6121550798416138e-01
    z[1,7,2]  R896      3.0541107058525085e-01
    z[1,7,2]  R897      7.8861457109451294e-01
    z[1,7,2]  R898      -1.9163978099822998e-01
    z[1,7,2]  R899      -5.1818495988845825e-01
    z[1,7,2]  R900      -3.6145347356796265e-01
    z[1,7,2]  R901      -5.7662930339574814e-02
    z[1,7,2]  R902      -1.6415746882557869e-02
    z[1,7,2]  R903      -7.3851391673088074e-02
    z[1,7,2]  R904      -2.2096006572246552e-01
    z[1,7,2]  R905      -5.3146738559007645e-02
    z[1,7,2]  R906      -1.4740160107612610e-01
    z[1,7,2]  R907      2.1982432901859283e-01
    z[1,7,2]  R908      -3.8245442509651184e-01
    z[1,7,2]  R909      -2.9966729879379272e-01
    z[1,7,2]  R910      -3.2674607634544373e-01
    z[1,7,2]  R911      -2.6593995094299316e-01
    z[1,7,2]  R912      -4.1883742809295654e-01
    z[1,7,2]  R913      -4.2928963899612427e-01
    z[1,7,2]  R914      -4.4848346710205078e-01
    z[1,7,2]  R915      -3.6271527409553528e-01
    z[1,7,2]  R916      2.6568377017974854e-01
    z[1,7,2]  R917      5.1571227610111237e-02
    z[1,7,2]  R918      -5.2012479305267334e-01
    z[1,7,2]  R919      0.430862158536911
    z[1,7,2]  R920      6.4673972129821777e-01
    z[1,7,2]  R921      5.3898984193801880e-01
    z[1,7,2]  R922      1.5493386983871460e-01
    z[1,7,2]  R923      1.5950405597686768e-01
    z[1,7,2]  R924      1.4847847819328308e-01
    z[1,7,2]  R925      1.4667649567127228e-01
    z[1,7,2]  R926      6.8408769369125366e-01
    z[1,7,2]  R927      5.0998938083648682e-01
    z[1,7,2]  R928      -1.5722635388374329e-01
    z[1,7,2]  R929      -1.3574923574924469e-01
    z[1,7,2]  R930      -4.8064518719911575e-02
    z[1,7,2]  R931      8.1105232238769531e-01
    z[1,7,2]  R932      8.8950288295745850e-01
    z[1,7,2]  R933      5.5517274141311646e-01
    z[1,7,2]  R934      0.0680805891752243
    z[1,7,2]  R935      1.5615177154541016e-01
    z[1,7,2]  R936      1.3400849699974060e-01
    z[1,7,2]  R937      5.0934523344039917e-01
    z[1,7,2]  R938      -4.7807180881500244e-01
    z[1,7,2]  R939      -5.9512192010879517e-01
    z[1,7,2]  R940      4.7363206744194031e-01
    z[1,7,2]  R941      2.0909920334815979e-01
    z[1,7,2]  R942      5.8233773708343506e-01
    z[1,7,2]  R943      -0.0377717949450016
    z[1,7,2]  R944      -2.4989375472068787e-01
    z[1,7,2]  R945      7.7504372596740723e-01
    z[1,7,2]  R946      7.0783507823944092e-01
    z[1,7,2]  R947      8.4468716382980347e-01
    z[1,7,3]  R14       -1
    z[1,7,3]  R68       1
    z[1,7,3]  R848      -1
    z[1,7,3]  R849      1
    z[1,7,3]  R856      -4.0729328989982605e-01
    z[1,7,3]  R857      5.4033064842224121e-01
    z[1,7,3]  R858      -4.8166982829570770e-02
    z[1,7,3]  R859      2.7853947877883911e-01
    z[1,7,3]  R860      -6.4410172402858734e-02
    z[1,7,3]  R861      -3.2127812504768372e-01
    z[1,7,3]  R862      -3.1471493840217590e-01
    z[1,7,3]  R863      -5.5975690484046936e-02
    z[1,7,3]  R864      -9.0436212718486786e-02
    z[1,7,3]  R865      -4.9013805389404297e-01
    z[1,7,3]  R866      -1.2913604080677032e-01
    z[1,7,3]  R867      -2.6757690310478210e-01
    z[1,7,3]  R868      0.289849191904068
    z[1,7,3]  R869      1.5617226064205170e-01
    z[1,7,3]  R870      -2.3016671836376190e-01
    z[1,7,3]  R871      7.4717029929161072e-02
    z[1,7,3]  R872      -3.6574643850326538e-01
    z[1,7,3]  R873      6.8892216682434082e-01
    z[1,7,3]  R874      -0.0466042086482048
    z[1,7,3]  R875      -1.7337203025817871e-01
    z[1,7,3]  R876      5.4751407355070114e-02
    z[1,7,3]  R877      -5.2775126695632935e-01
    z[1,7,3]  R878      2.1336081624031067e-01
    z[1,7,3]  R879      7.9396776854991913e-03
    z[1,7,3]  R880      -1.5130911953747272e-02
    z[1,7,3]  R881      -8.4489017724990845e-02
    z[1,7,3]  R882      1.9082543253898621e-01
    z[1,7,3]  R883      0.310305118560791
    z[1,7,3]  R884      1.1281483806669712e-02
    z[1,7,3]  R885      2.4558851122856140e-01
    z[1,7,3]  R886      2.4062691628932953e-01
    z[1,7,3]  R887      3.6169907450675964e-01
    z[1,7,3]  R888      -9.5866424089763314e-05
    z[1,7,3]  R889      6.2737171538174152e-03
    z[1,7,3]  R890      -4.9242008477449417e-02
    z[1,7,3]  R891      -8.9440263807773590e-02
    z[1,7,3]  R892      -1.2167779356241226e-01
    z[1,7,3]  R893      1.7906905710697174e-01
    z[1,7,3]  R894      1.5895548462867737e-01
    z[1,7,3]  R895      -9.5122829079627991e-02
    z[1,7,3]  R896      -7.8436203300952911e-02
    z[1,7,3]  R897      6.6721066832542419e-03
    z[1,7,3]  R898      3.1728571653366089e-01
    z[1,7,3]  R899      -1.3364253938198090e-01
    z[1,7,3]  R900      -4.9848143011331558e-02
    z[1,7,3]  R901      4.1682282090187073e-01
    z[1,7,3]  R902      6.3563042879104614e-01
    z[1,7,3]  R903      4.5382767915725708e-01
    z[1,7,3]  R904      6.9629192352294922e-01
    z[1,7,3]  R905      7.9223698377609253e-01
    z[1,7,3]  R906      3.2487702369689941e-01
    z[1,7,3]  R907      -1.7021021246910095e-01
    z[1,7,3]  R908      3.3239468932151794e-01
    z[1,7,3]  R909      1.1013448238372803e-01
    z[1,7,3]  R910      5.5118042975664139e-02
    z[1,7,3]  R911      7.5845491886138916e-01
    z[1,7,3]  R912      -4.6045112609863281e-01
    z[1,7,3]  R913      1.1464538425207138e-01
    z[1,7,3]  R914      -2.7030047774314880e-01
    z[1,7,3]  R915      5.3859239816665649e-01
    z[1,7,3]  R916      2.4339058995246887e-01
    z[1,7,3]  R917      -1.8081294000148773e-01
    z[1,7,3]  R918      -4.1440117359161377e-01
    z[1,7,3]  R919      1.3351282104849815e-02
    z[1,7,3]  R920      1.4195926487445831e-01
    z[1,7,3]  R921      7.4260458350181580e-02
    z[1,7,3]  R922      3.7941688299179077e-01
    z[1,7,3]  R923      -0.0711718425154686
    z[1,7,3]  R924      2.7141135931015015e-01
    z[1,7,3]  R925      0.0403439924120903
    z[1,7,3]  R926      -7.0779860019683838e-02
    z[1,7,3]  R927      -1.4947031438350677e-01
    z[1,7,3]  R928      5.7387119531631470e-01
    z[1,7,3]  R929      -1.8258984386920929e-01
    z[1,7,3]  R930      -5.4872053861618042e-01
    z[1,7,3]  R931      1.2046121805906296e-01
    z[1,7,3]  R932      1.4531119167804718e-01
    z[1,7,3]  R933      -2.5036895275115967e-01
    z[1,7,3]  R934      1.3941834867000580e-01
    z[1,7,3]  R935      2.9689857363700867e-01
    z[1,7,3]  R936      1.6956686973571777e-01
    z[1,7,3]  R937      1.1790903657674789e-01
    z[1,7,3]  R938      0.635644793510437
    z[1,7,3]  R939      2.1650105714797974e-01
    z[1,7,3]  R940      -2.8590098023414612e-01
    z[1,7,3]  R941      5.9115849435329437e-02
    z[1,7,3]  R942      -6.6254511475563049e-03
    z[1,7,3]  R943      -0.457742303609848
    z[1,7,3]  R944      1.0660663992166519e-01
    z[1,7,3]  R945      1.0329223424196243e-01
    z[1,7,3]  R946      2.9699310660362244e-01
    z[1,7,3]  R947      1.2285843491554260e-01
    z[1,7,4]  R15       -1
    z[1,7,4]  R69       1
    z[1,7,4]  R850      -1
    z[1,7,4]  R851      1
    z[1,7,4]  R856      -2.0273748040199280e-01
    z[1,7,4]  R857      -1.8839581310749054e-01
    z[1,7,4]  R858      -0.280404657125473
    z[1,7,4]  R859      -2.0461490750312805e-01
    z[1,7,4]  R860      -2.5542688369750977e-01
    z[1,7,4]  R861      -2.3426280915737152e-01
    z[1,7,4]  R862      1.6930826008319855e-01
    z[1,7,4]  R863      -1.2058027833700180e-01
    z[1,7,4]  R864      1.4223098754882812e-01
    z[1,7,4]  R865      -1.2113583087921143e-01
    z[1,7,4]  R866      -3.1754605472087860e-02
    z[1,7,4]  R867      -1.3101170957088470e-01
    z[1,7,4]  R868      5.9391045570373535e-01
    z[1,7,4]  R869      -9.2241771519184113e-02
    z[1,7,4]  R870      -2.6756340265274048e-01
    z[1,7,4]  R871      2.6170569658279419e-01
    z[1,7,4]  R872      6.4118497073650360e-02
    z[1,7,4]  R873      -3.7524932622909546e-01
    z[1,7,4]  R874      1.2699003517627716e-01
    z[1,7,4]  R875      -3.5339277982711792e-01
    z[1,7,4]  R876      5.5316165089607239e-02
    z[1,7,4]  R877      -1.0436274856328964e-01
    z[1,7,4]  R878      5.9422351419925690e-02
    z[1,7,4]  R879      -1.9214452803134918e-01
    z[1,7,4]  R880      2.2768998518586159e-02
    z[1,7,4]  R881      -1.0811345279216766e-01
    z[1,7,4]  R882      2.8450158424675465e-03
    z[1,7,4]  R883      -1.7688177525997162e-01
    z[1,7,4]  R884      3.1629720330238342e-01
    z[1,7,4]  R885      3.7627778947353363e-02
    z[1,7,4]  R886      -1.3504016213119030e-02
    z[1,7,4]  R887      -3.0993264913558960e-01
    z[1,7,4]  R888      -1.5718884766101837e-01
    z[1,7,4]  R889      5.4455578327178955e-01
    z[1,7,4]  R890      -1.5139667689800262e-01
    z[1,7,4]  R891      -5.4010105133056641e-01
    z[1,7,4]  R892      -4.8380544781684875e-01
    z[1,7,4]  R893      4.2592003941535950e-01
    z[1,7,4]  R894      -4.6477150917053223e-01
    z[1,7,4]  R895      1.5552908182144165e-01
    z[1,7,4]  R896      -0.358530193567276
    z[1,7,4]  R897      -1.1168579757213593e-01
    z[1,7,4]  R898      5.5943781137466431e-01
    z[1,7,4]  R899      1.8434017896652222e-01
    z[1,7,4]  R900      3.9101520180702209e-01
    z[1,7,4]  R901      6.2802612781524658e-01
    z[1,7,4]  R902      5.0317895412445068e-01
    z[1,7,4]  R903      1.2057242542505264e-01
    z[1,7,4]  R904      2.1572346985340118e-01
    z[1,7,4]  R905      -2.7864813804626465e-01
    z[1,7,4]  R906      -2.0015962421894073e-01
    z[1,7,4]  R907      -5.9578165411949158e-02
    z[1,7,4]  R908      1.1606896668672562e-01
    z[1,7,4]  R909      5.0491452217102051e-01
    z[1,7,4]  R910      6.3793194293975830e-01
    z[1,7,4]  R911      6.8251579068601131e-03
    z[1,7,4]  R912      3.2291319966316223e-01
    z[1,7,4]  R913      4.9339967966079712e-01
    z[1,7,4]  R914      2.7060031890869141e-01
    z[1,7,4]  R915      2.3952074348926544e-01
    z[1,7,4]  R916      -6.2229067087173462e-01
    z[1,7,4]  R917      7.8987866640090942e-02
    z[1,7,4]  R918      -2.5162476301193237e-01
    z[1,7,4]  R919      -1.6484941542148590e-01
    z[1,7,4]  R920      -4.0740302205085754e-01
    z[1,7,4]  R921      -3.8552686572074890e-01
    z[1,7,4]  R922      4.6498816460371017e-02
    z[1,7,4]  R923      -3.8213570951484144e-04
    z[1,7,4]  R924      -1.7301419377326965e-01
    z[1,7,4]  R925      -6.8801701068878174e-02
    z[1,7,4]  R926      -3.9071694016456604e-02
    z[1,7,4]  R927      -4.2013868689537048e-01
    z[1,7,4]  R928      4.0225276350975037e-01
    z[1,7,4]  R929      7.1406906843185425e-01
    z[1,7,4]  R930      4.3973532319068909e-01
    z[1,7,4]  R931      -7.6233841478824615e-02
    z[1,7,4]  R932      1.1470503360033035e-01
    z[1,7,4]  R933      7.1103684604167938e-02
    z[1,7,4]  R934      -3.1166917085647583e-01
    z[1,7,4]  R935      3.1659644097089767e-02
    z[1,7,4]  R936      1.4390356838703156e-01
    z[1,7,4]  R937      2.5604346394538879e-01
    z[1,7,4]  R938      -1.7262098193168640e-01
    z[1,7,4]  R939      -1.1364775896072388e-01
    z[1,7,4]  R940      -3.3513152599334717e-01
    z[1,7,4]  R941      1.1817936599254608e-01
    z[1,7,4]  R942      -1.2361352145671844e-01
    z[1,7,4]  R943      2.6135078072547913e-01
    z[1,7,4]  R944      3.0776894092559814e-01
    z[1,7,4]  R945      4.1240427643060684e-02
    z[1,7,4]  R946      -1.6916111111640930e-01
    z[1,7,4]  R947      3.8667380809783936e-01
    z[1,7,5]  R16       -1
    z[1,7,5]  R70       1
    z[1,7,5]  R852      -1
    z[1,7,5]  R853      1
    z[1,7,5]  R856      -3.5724973678588867e-01
    z[1,7,5]  R857      -5.2501040697097778e-01
    z[1,7,5]  R858      8.2306081056594849e-01
    z[1,7,5]  R859      7.4455350637435913e-02
    z[1,7,5]  R860      3.4165728092193604e-01
    z[1,7,5]  R861      -2.6723784208297729e-01
    z[1,7,5]  R862      1.0493505001068115e-01
    z[1,7,5]  R863      -1.0127409547567368e-01
    z[1,7,5]  R864      -1.6792723536491394e-01
    z[1,7,5]  R865      -1.8255116045475006e-01
    z[1,7,5]  R866      -8.7863765656948090e-02
    z[1,7,5]  R867      -3.8030883669853210e-01
    z[1,7,5]  R868      2.3301929235458374e-01
    z[1,7,5]  R869      7.4577951431274414e-01
    z[1,7,5]  R870      3.5087481141090393e-02
    z[1,7,5]  R871      -2.8743150830268860e-01
    z[1,7,5]  R872      -3.0452570319175720e-01
    z[1,7,5]  R873      2.1698819100856781e-01
    z[1,7,5]  R874      4.7764277458190918e-01
    z[1,7,5]  R875      1.8217791616916656e-01
    z[1,7,5]  R876      -1.3483242690563202e-01
    z[1,7,5]  R877      -2.0405036211013794e-01
    z[1,7,5]  R878      0.00815114751458168
    z[1,7,5]  R879      1.6097424924373627e-01
    z[1,7,5]  R880      -2.4331073462963104e-01
    z[1,7,5]  R881      -2.3352622985839844e-01
    z[1,7,5]  R882      -2.2083316743373871e-01
    z[1,7,5]  R883      -5.2200831472873688e-02
    z[1,7,5]  R884      5.9199732542037964e-01
    z[1,7,5]  R885      3.0169311165809631e-01
    z[1,7,5]  R886      1.8120923638343811e-01
    z[1,7,5]  R887      -1.6136570274829865e-01
    z[1,7,5]  R888      -3.1965515017509460e-01
    z[1,7,5]  R889      -3.1550022959709167e-01
    z[1,7,5]  R890      -2.1198825538158417e-01
    z[1,7,5]  R891      -4.0874508023262024e-01
    z[1,7,5]  R892      -2.1739758551120758e-01
    z[1,7,5]  R893      -1.3742758333683014e-01
    z[1,7,5]  R894      -3.5361200571060181e-01
    z[1,7,5]  R895      -3.7164643406867981e-01
    z[1,7,5]  R896      -3.7035247683525085e-01
    z[1,7,5]  R897      -5.2202105522155762e-01
    z[1,7,5]  R898      3.2202634215354919e-01
    z[1,7,5]  R899      -1.7131336033344269e-01
    z[1,7,5]  R900      -3.4875169396400452e-01
    z[1,7,5]  R901      1.1485569924116135e-01
    z[1,7,5]  R902      2.5832670927047729e-01
    z[1,7,5]  R903      1.6578520834445953e-01
    z[1,7,5]  R904      1.6976547241210938e-01
    z[1,7,5]  R905      5.2896046638488770e-01
    z[1,7,5]  R906      5.3319811820983887e-01
    z[1,7,5]  R907      -7.9358108341693878e-03
    z[1,7,5]  R908      4.1155338287353516e-01
    z[1,7,5]  R909      5.7823747396469116e-01
    z[1,7,5]  R910      -2.5613831356167793e-02
    z[1,7,5]  R911      5.0028479099273682e-01
    z[1,7,5]  R912      -1.8670815974473953e-02
    z[1,7,5]  R913      1.6047197580337524e-01
    z[1,7,5]  R914      3.6025676876306534e-02
    z[1,7,5]  R915      1.9604517519474030e-01
    z[1,7,5]  R916      -0.429318368434906
    z[1,7,5]  R917      -1.7985065281391144e-01
    z[1,7,5]  R918      -5.0258863717317581e-02
    z[1,7,5]  R919      -0.50553959608078
    z[1,7,5]  R920      -4.1002359986305237e-01
    z[1,7,5]  R921      -2.0191858708858490e-01
    z[1,7,5]  R922      1.1014650017023087e-01
    z[1,7,5]  R923      -2.7247246354818344e-02
    z[1,7,5]  R924      -6.9881081581115723e-02
    z[1,7,5]  R925      2.1768143773078918e-01
    z[1,7,5]  R926      -6.6732531785964966e-01
    z[1,7,5]  R927      -6.9999217987060547e-01
    z[1,7,5]  R928      4.3726280331611633e-01
    z[1,7,5]  R929      1.4854957163333893e-01
    z[1,7,5]  R930      1.5420123934745789e-01
    z[1,7,5]  R931      -0.094334177672863
    z[1,7,5]  R932      -2.8806936740875244e-01
    z[1,7,5]  R933      3.0473349615931511e-02
    z[1,7,5]  R934      7.1793437004089355e-02
    z[1,7,5]  R935      -1.9304917752742767e-01
    z[1,7,5]  R936      1.3385677337646484e-01
    z[1,7,5]  R937      1.9853435456752777e-01
    z[1,7,5]  R938      4.3308857083320618e-01
    z[1,7,5]  R939      0.0741511881351471
    z[1,7,5]  R940      -4.2723512649536133e-01
    z[1,7,5]  R941      5.9995427727699280e-02
    z[1,7,5]  R942      -3.5500192642211914e-01
    z[1,7,5]  R943      2.8033751249313354e-01
    z[1,7,5]  R944      -1.9317139685153961e-01
    z[1,7,5]  R945      4.1094236075878143e-02
    z[1,7,5]  R946      -2.1376991271972656e-01
    z[1,7,5]  R947      -1.1652937391772866e-03
    z[1,7,6]  R17       -1
    z[1,7,6]  R71       1
    z[1,7,6]  R854      -1
    z[1,7,6]  R855      1
    z[1,7,6]  R856      1.9509072601795197e-01
    z[1,7,6]  R857      -2.5431713089346886e-02
    z[1,7,6]  R858      2.8574258089065552e-01
    z[1,7,6]  R859      9.6433833241462708e-02
    z[1,7,6]  R860      1.7172423005104065e-01
    z[1,7,6]  R861      3.0988961458206177e-01
    z[1,7,6]  R862      2.6388822123408318e-02
    z[1,7,6]  R863      1.7337700724601746e-01
    z[1,7,6]  R864      -7.7882311306893826e-03
    z[1,7,6]  R865      1.8303962051868439e-01
    z[1,7,6]  R866      -3.6888930201530457e-01
    z[1,7,6]  R867      -1.6560163348913193e-02
    z[1,7,6]  R868      -4.9504969269037247e-02
    z[1,7,6]  R869      -1.7858718335628510e-01
    z[1,7,6]  R870      -2.8049442172050476e-01
    z[1,7,6]  R871      -0.483377069234848
    z[1,7,6]  R872      -0.547780454158783
    z[1,7,6]  R873      4.5364937186241150e-01
    z[1,7,6]  R874      -1.0871516168117523e-01
    z[1,7,6]  R875      -7.5729645788669586e-02
    z[1,7,6]  R876      -0.313103049993515
    z[1,7,6]  R877      -4.6434280276298523e-01
    z[1,7,6]  R878      -8.5424654185771942e-02
    z[1,7,6]  R879      1.4204651117324829e-01
    z[1,7,6]  R880      -3.1563821434974670e-01
    z[1,7,6]  R881      -3.3982202410697937e-02
    z[1,7,6]  R882      -9.3037769198417664e-02
    z[1,7,6]  R883      -2.5839787721633911e-01
    z[1,7,6]  R884      -1.9042136147618294e-02
    z[1,7,6]  R885      1.1859728395938873e-01
    z[1,7,6]  R886      -1.7192541854456067e-03
    z[1,7,6]  R887      -2.5719583034515381e-02
    z[1,7,6]  R888      0.272826224565506
    z[1,7,6]  R889      -1.4592908322811127e-01
    z[1,7,6]  R890      0.0883352980017662
    z[1,7,6]  R891      2.3601607978343964e-01
    z[1,7,6]  R892      2.8957530856132507e-01
    z[1,7,6]  R893      3.5161668062210083e-01
    z[1,7,6]  R894      -2.2178536280989647e-02
    z[1,7,6]  R895      -2.2910106182098389e-01
    z[1,7,6]  R896      -0.279342383146286
    z[1,7,6]  R897      6.8481385707855225e-02
    z[1,7,6]  R898      2.2746691107749939e-01
    z[1,7,6]  R899      2.7614927291870117e-01
    z[1,7,6]  R900      -2.7461913228034973e-01
    z[1,7,6]  R901      -4.0738663077354431e-01
    z[1,7,6]  R902      -3.3743351697921753e-01
    z[1,7,6]  R903      6.0053861141204834e-01
    z[1,7,6]  R904      -2.7851322293281555e-01
    z[1,7,6]  R905      -1.3669953681528568e-02
    z[1,7,6]  R906      7.1014779806137085e-01
    z[1,7,6]  R907      3.0918738245964050e-01
    z[1,7,6]  R908      6.2395554780960083e-01
    z[1,7,6]  R909      4.5911943912506104e-01
    z[1,7,6]  R910      -2.8632143139839172e-01
    z[1,7,6]  R911      1.2162868864834309e-02
    z[1,7,6]  R912      -2.2372503578662872e-01
    z[1,7,6]  R913      -5.6143510341644287e-01
    z[1,7,6]  R914      5.4943454265594482e-01
    z[1,7,6]  R915      -0.665951132774353
    z[1,7,6]  R916      1.5840151906013489e-01
    z[1,7,6]  R917      -2.1365078166127205e-02
    z[1,7,6]  R918      1.5309567749500275e-01
    z[1,7,6]  R919      4.5373108237981796e-02
    z[1,7,6]  R920      -2.7633062005043030e-01
    z[1,7,6]  R921      -3.1513014435768127e-01
    z[1,7,6]  R922      -5.8834567666053772e-02
    z[1,7,6]  R923      -1.0482275485992432e-01
    z[1,7,6]  R924      -1.5043185651302338e-01
    z[1,7,6]  R925      -1.1765944957733154e-01
    z[1,7,6]  R926      1.9668446853756905e-02
    z[1,7,6]  R927      -8.1644721329212189e-02
    z[1,7,6]  R928      2.2319868206977844e-02
    z[1,7,6]  R929      -2.9431256651878357e-01
    z[1,7,6]  R930      3.7668031454086304e-01
    z[1,7,6]  R931      -2.7511370182037354e-01
    z[1,7,6]  R932      3.4089684486389160e-02
    z[1,7,6]  R933      -1.6389900445938110e-01
    z[1,7,6]  R934      2.8716831002384424e-04
    z[1,7,6]  R935      1.8524080514907837e-01
    z[1,7,6]  R936      -2.3157205432653427e-02
    z[1,7,6]  R937      -3.3950844407081604e-01
    z[1,7,6]  R938      -3.4378501772880554e-01
    z[1,7,6]  R939      -5.8123809099197388e-01
    z[1,7,6]  R940      -2.1278581023216248e-01
    z[1,7,6]  R941      2.2819848358631134e-01
    z[1,7,6]  R942      4.4436073303222656e-01
    z[1,7,6]  R943      6.3039287924766541e-02
    z[1,7,6]  R944      2.1365134045481682e-02
    z[1,7,6]  R945      1.3199381530284882e-01
    z[1,7,6]  R946      -1.1755295097827911e-01
    z[1,7,6]  R947      -2.9218699783086777e-02
    z[7,1,0]  R11       1
    z[7,1,0]  R65       -1
    z[7,1,0]  R948      -1
    z[7,1,0]  R949      1
    z[7,1,0]  R962      -5.5729341506958008e-01
    z[7,1,0]  R963      -0.570170521736145
    z[7,1,0]  R964      -0.519062876701355
    z[7,1,0]  R965      -1.5749590098857880e-01
    z[7,1,0]  R966      -2.7505412697792053e-01
    z[7,1,0]  R967      -3.7525451183319092e-01
    z[7,1,0]  R968      2.3901455104351044e-02
    z[7,1,0]  R969      -2.5289878249168396e-01
    z[7,1,0]  R970      4.0116536617279053e-01
    z[7,1,0]  R971      -1.9124847650527954e-01
    z[7,1,0]  R972      -5.3013980388641357e-01
    z[7,1,0]  R973      7.6019114255905151e-01
    z[7,1,0]  R974      -2.5712382793426514e-01
    z[7,1,0]  R975      -3.3564478158950806e-01
    z[7,1,0]  R976      -0.532228410243988
    z[7,1,0]  R977      7.5140100717544556e-01
    z[7,1,0]  R978      -6.1134433746337891e-01
    z[7,1,0]  R979      -7.5698435306549072e-01
    z[7,1,0]  R980      -5.2028256654739380e-01
    z[7,1,0]  R981      1.3251268863677979e-01
    z[7,1,0]  R982      6.0195124149322510e-01
    z[7,1,0]  R983      5.9818547964096069e-01
    z[7,1,0]  R984      6.7245703935623169e-01
    z[7,1,0]  R985      4.9734145402908325e-01
    z[7,1,0]  R986      0.382784366607666
    z[7,1,0]  R987      5.3919726610183716e-01
    z[7,1,0]  R988      0.352083295583725
    z[7,1,0]  R989      1.0322692990303040e-01
    z[7,1,0]  R990      -3.5776447504758835e-02
    z[7,1,0]  R991      -6.2972344458103180e-02
    z[7,1,0]  R992      3.9761614799499512e-01
    z[7,1,0]  R993      3.1109130382537842e-01
    z[7,1,0]  R994      6.0046070814132690e-01
    z[7,1,0]  R995      6.0410302132368088e-02
    z[7,1,0]  R996      -4.0367566980421543e-03
    z[7,1,0]  R997      3.0294919013977051e-01
    z[7,1,0]  R998      5.7300585508346558e-01
    z[7,1,0]  R999      1.5232123434543610e-01
    z[7,1,0]  R1000     -5.1245975494384766e-01
    z[7,1,0]  R1001     7.1005530655384064e-02
    z[7,1,0]  R1002     -1.8540312349796295e-01
    z[7,1,0]  R1003     -6.8541193008422852e-01
    z[7,1,0]  R1004     -2.7038168907165527e-01
    z[7,1,0]  R1005     -0.452766478061676
    z[7,1,0]  R1006     -4.6305142343044281e-02
    z[7,1,0]  R1007     -7.7871638350188732e-03
    z[7,1,0]  R1008     7.7178925275802612e-02
    z[7,1,0]  R1009     -2.6318386197090149e-01
    z[7,1,0]  R1010     2.7791216969490051e-01
    z[7,1,0]  R1011     0.000984802725724876
    z[7,1,0]  R1012     2.8282368183135986e-01
    z[7,1,0]  R1013     -2.5316581130027771e-01
    z[7,1,0]  R1014     1.2265031225979328e-02
    z[7,1,0]  R1015     -4.1162014007568359e-01
    z[7,1,0]  R1016     -2.6204910874366760e-01
    z[7,1,0]  R1017     -6.1397153139114380e-01
    z[7,1,0]  R1018     -1.5431550145149231e-01
    z[7,1,0]  R1019     2.1453516185283661e-01
    z[7,1,0]  R1020     1.5545056760311127e-01
    z[7,1,0]  R1021     -5.9662234783172607e-01
    z[7,1,0]  R1022     -1.2338148802518845e-01
    z[7,1,0]  R1023     -1.2407746165990829e-01
    z[7,1,0]  R1024     -3.0643790960311890e-01
    z[7,1,0]  R1025     2.3313535749912262e-01
    z[7,1,0]  R1026     5.5375963449478149e-01
    z[7,1,0]  R1027     -1.8920011818408966e-01
    z[7,1,0]  R1028     -5.3123313188552856e-01
    z[7,1,0]  R1029     5.9123420715332031e-01
    z[7,1,0]  R1030     5.3236150741577148e-01
    z[7,1,0]  R1031     3.4476128220558167e-01
    z[7,1,0]  R1032     -7.5755953788757324e-01
    z[7,1,0]  R1033     6.1774069070816040e-01
    z[7,1,0]  R1034     -3.3967691659927368e-01
    z[7,1,0]  R1035     -7.4591761827468872e-01
    z[7,1,0]  R1036     -6.3562631607055664e-01
    z[7,1,0]  R1037     -6.7685276269912720e-01
    z[7,1,0]  R1038     -7.6198214292526245e-01
    z[7,1,0]  R1039     1.2019499391317368e-01
    z[7,1,0]  R1040     0.0736149400472641
    z[7,1,0]  R1041     -1.8352362513542175e-01
    z[7,1,0]  R1042     -2.1915476024150848e-01
    z[7,1,0]  R1043     2.4370449781417847e-01
    z[7,1,0]  R1044     -3.2098489999771118e-01
    z[7,1,0]  R1045     3.3063909411430359e-01
    z[7,1,0]  R1046     1.8062606453895569e-01
    z[7,1,0]  R1047     -1.9695401191711426e-02
    z[7,1,0]  R1048     -2.9621289577335119e-03
    z[7,1,0]  R1049     1.9050359725952148e-01
    z[7,1,0]  R1050     0.629289448261261
    z[7,1,0]  R1051     4.6556234359741211e-02
    z[7,1,0]  R1052     -3.0931890010833740e-02
    z[7,1,0]  R1053     2.0336858928203583e-02
    z[7,1,1]  R12       1
    z[7,1,1]  R66       -1
    z[7,1,1]  R950      -1
    z[7,1,1]  R951      1
    z[7,1,1]  R962      -7.3747581243515015e-01
    z[7,1,1]  R963      -7.4708157777786255e-01
    z[7,1,1]  R964      -7.3020076751708984e-01
    z[7,1,1]  R965      -9.3595254421234131e-01
    z[7,1,1]  R966      -8.7157249450683594e-01
    z[7,1,1]  R967      -8.0742329359054565e-01
    z[7,1,1]  R968      -1.9723260775208473e-02
    z[7,1,1]  R969      -8.6047857999801636e-01
    z[7,1,1]  R970      3.9040920138359070e-01
    z[7,1,1]  R971      -8.3041661977767944e-01
    z[7,1,1]  R972      0.418416827917099
    z[7,1,1]  R973      5.7618740946054459e-02
    z[7,1,1]  R974      3.9711853861808777e-01
    z[7,1,1]  R975      3.7892201542854309e-01
    z[7,1,1]  R976      4.4411951303482056e-01
    z[7,1,1]  R977      -2.7559101581573486e-01
    z[7,1,1]  R978      4.4987294077873230e-01
    z[7,1,1]  R979      3.6728054285049438e-01
    z[7,1,1]  R980      0.534921407699585
    z[7,1,1]  R981      2.6610809564590454e-01
    z[7,1,1]  R982      1.7845438420772552e-01
    z[7,1,1]  R983      -4.6498408913612366e-01
    z[7,1,1]  R984      -2.5442427396774292e-01
    z[7,1,1]  R985      -4.4862989336252213e-02
    z[7,1,1]  R986      -1.2408622354269028e-01
    z[7,1,1]  R987      -3.0851846933364868e-01
    z[7,1,1]  R988      -4.3527570366859436e-01
    z[7,1,1]  R989      3.5347703844308853e-02
    z[7,1,1]  R990      2.0681785047054291e-01
    z[7,1,1]  R991      9.0527945756912231e-01
    z[7,1,1]  R992      -1.1390823125839233e-01
    z[7,1,1]  R993      3.4702695906162262e-02
    z[7,1,1]  R994      -2.0013208687305450e-01
    z[7,1,1]  R995      -3.1605863571166992e-01
    z[7,1,1]  R996      -6.7666035890579224e-01
    z[7,1,1]  R997      3.5550642013549805e-01
    z[7,1,1]  R998      1.4513367414474487e-01
    z[7,1,1]  R999      -1.2593352794647217e-01
    z[7,1,1]  R1000     1.0443762689828873e-01
    z[7,1,1]  R1001     9.5946002006530762e-01
    z[7,1,1]  R1002     -6.5885370969772339e-01
    z[7,1,1]  R1003     2.4410164356231689e-01
    z[7,1,1]  R1004     2.7930954098701477e-01
    z[7,1,1]  R1005     4.5855066180229187e-01
    z[7,1,1]  R1006     9.0118712186813354e-01
    z[7,1,1]  R1007     9.7862249612808228e-01
    z[7,1,1]  R1008     0.916998565196991
    z[7,1,1]  R1009     9.1740399599075317e-01
    z[7,1,1]  R1010     -5.0423923879861832e-02
    z[7,1,1]  R1011     2.1070607006549835e-01
    z[7,1,1]  R1012     -4.6093201637268066e-01
    z[7,1,1]  R1013     -5.1532387733459473e-01
    z[7,1,1]  R1014     -5.8087170124053955e-01
    z[7,1,1]  R1015     2.6048794388771057e-01
    z[7,1,1]  R1016     1.4729660749435425e-01
    z[7,1,1]  R1017     4.6828430891036987e-01
    z[7,1,1]  R1018     9.2185807228088379e-01
    z[7,1,1]  R1019     8.7684553861618042e-01
    z[7,1,1]  R1020     9.4337785243988037e-01
    z[7,1,1]  R1021     3.8790026307106018e-01
    z[7,1,1]  R1022     0.128950834274292
    z[7,1,1]  R1023     -4.7677025198936462e-01
    z[7,1,1]  R1024     5.0981199741363525e-01
    z[7,1,1]  R1025     9.1037929058074951e-01
    z[7,1,1]  R1026     1.2420173734426498e-01
    z[7,1,1]  R1027     7.7613222599029541e-01
    z[7,1,1]  R1028     7.1518266201019287e-01
    z[7,1,1]  R1029     1.3515974581241608e-01
    z[7,1,1]  R1030     -1.9805087149143219e-01
    z[7,1,1]  R1031     -4.6662919223308563e-02
    z[7,1,1]  R1032     8.1886142492294312e-02
    z[7,1,1]  R1033     9.7055546939373016e-02
    z[7,1,1]  R1034     1.2865361571311951e-01
    z[7,1,1]  R1035     6.0638375580310822e-02
    z[7,1,1]  R1036     5.5151361972093582e-02
    z[7,1,1]  R1037     -4.3803101778030396e-01
    z[7,1,1]  R1038     -5.0843238830566406e-01
    z[7,1,1]  R1039     -7.6586097478866577e-01
    z[7,1,1]  R1040     -6.9656598567962646e-01
    z[7,1,1]  R1041     -0.386089026927948
    z[7,1,1]  R1042     8.7825745344161987e-01
    z[7,1,1]  R1043     0.83925461769104
    z[7,1,1]  R1044     6.3452881574630737e-01
    z[7,1,1]  R1045     1.6306184232234955e-01
    z[7,1,1]  R1046     -8.0407577753067017e-01
    z[7,1,1]  R1047     -6.3214516639709473e-01
    z[7,1,1]  R1048     -4.4627717137336731e-01
    z[7,1,1]  R1049     1.5261571109294891e-01
    z[7,1,1]  R1050     0.0878714844584465
    z[7,1,1]  R1051     -8.7257444858551025e-01
    z[7,1,1]  R1052     -8.7358325719833374e-01
    z[7,1,1]  R1053     -5.4689502716064453e-01
    z[7,1,2]  R13       1
    z[7,1,2]  R67       -1
    z[7,1,2]  R952      -1
    z[7,1,2]  R953      1
    z[7,1,2]  R962      0.298555850982666
    z[7,1,2]  R963      1.8358130753040314e-01
    z[7,1,2]  R964      1.9443720579147339e-01
    z[7,1,2]  R965      1.5707209706306458e-01
    z[7,1,2]  R966      -2.6619702577590942e-01
    z[7,1,2]  R967      -1.0090090334415436e-01
    z[7,1,2]  R968      -7.4030059576034546e-01
    z[7,1,2]  R969      -1.6972111165523529e-01
    z[7,1,2]  R970      -7.7183133363723755e-01
    z[7,1,2]  R971      1.4229343831539154e-01
    z[7,1,2]  R972      5.8528393507003784e-01
    z[7,1,2]  R973      -3.7061061710119247e-02
    z[7,1,2]  R974      8.3552157878875732e-01
    z[7,1,2]  R975      4.7039976716041565e-01
    z[7,1,2]  R976      3.7349972128868103e-01
    z[7,1,2]  R977      5.8752644807100296e-02
    z[7,1,2]  R978      2.3887164890766144e-01
    z[7,1,2]  R979      2.6121550798416138e-01
    z[7,1,2]  R980      3.0541107058525085e-01
    z[7,1,2]  R981      7.8861457109451294e-01
    z[7,1,2]  R982      -1.9163978099822998e-01
    z[7,1,2]  R983      -5.1818495988845825e-01
    z[7,1,2]  R984      -3.6145347356796265e-01
    z[7,1,2]  R985      -5.7662930339574814e-02
    z[7,1,2]  R986      -1.6415746882557869e-02
    z[7,1,2]  R987      -7.3851391673088074e-02
    z[7,1,2]  R988      -2.2096006572246552e-01
    z[7,1,2]  R989      -5.3146738559007645e-02
    z[7,1,2]  R990      -1.4740160107612610e-01
    z[7,1,2]  R991      2.1982432901859283e-01
    z[7,1,2]  R992      -3.8245442509651184e-01
    z[7,1,2]  R993      -2.9966729879379272e-01
    z[7,1,2]  R994      -3.2674607634544373e-01
    z[7,1,2]  R995      -2.6593995094299316e-01
    z[7,1,2]  R996      -4.1883742809295654e-01
    z[7,1,2]  R997      -4.2928963899612427e-01
    z[7,1,2]  R998      -4.4848346710205078e-01
    z[7,1,2]  R999      -3.6271527409553528e-01
    z[7,1,2]  R1000     2.6568377017974854e-01
    z[7,1,2]  R1001     5.1571227610111237e-02
    z[7,1,2]  R1002     -5.2012479305267334e-01
    z[7,1,2]  R1003     0.430862158536911
    z[7,1,2]  R1004     6.4673972129821777e-01
    z[7,1,2]  R1005     5.3898984193801880e-01
    z[7,1,2]  R1006     1.5493386983871460e-01
    z[7,1,2]  R1007     1.5950405597686768e-01
    z[7,1,2]  R1008     1.4847847819328308e-01
    z[7,1,2]  R1009     1.4667649567127228e-01
    z[7,1,2]  R1010     6.8408769369125366e-01
    z[7,1,2]  R1011     5.0998938083648682e-01
    z[7,1,2]  R1012     -1.5722635388374329e-01
    z[7,1,2]  R1013     -1.3574923574924469e-01
    z[7,1,2]  R1014     -4.8064518719911575e-02
    z[7,1,2]  R1015     8.1105232238769531e-01
    z[7,1,2]  R1016     8.8950288295745850e-01
    z[7,1,2]  R1017     5.5517274141311646e-01
    z[7,1,2]  R1018     0.0680805891752243
    z[7,1,2]  R1019     1.5615177154541016e-01
    z[7,1,2]  R1020     1.3400849699974060e-01
    z[7,1,2]  R1021     5.0934523344039917e-01
    z[7,1,2]  R1022     -4.7807180881500244e-01
    z[7,1,2]  R1023     -5.9512192010879517e-01
    z[7,1,2]  R1024     4.7363206744194031e-01
    z[7,1,2]  R1025     2.0909920334815979e-01
    z[7,1,2]  R1026     5.8233773708343506e-01
    z[7,1,2]  R1027     -0.0377717949450016
    z[7,1,2]  R1028     -2.4989375472068787e-01
    z[7,1,2]  R1029     7.7504372596740723e-01
    z[7,1,2]  R1030     7.0783507823944092e-01
    z[7,1,2]  R1031     8.4468716382980347e-01
    z[7,1,2]  R1032     2.1614845097064972e-01
    z[7,1,2]  R1033     -7.2414785623550415e-02
    z[7,1,2]  R1034     1.6746085882186890e-01
    z[7,1,2]  R1035     -0.552842915058136
    z[7,1,2]  R1036     -6.1426943540573120e-01
    z[7,1,2]  R1037     1.5637424588203430e-01
    z[7,1,2]  R1038     1.4649611711502075e-01
    z[7,1,2]  R1039     5.8397012948989868e-01
    z[7,1,2]  R1040     6.7283588647842407e-01
    z[7,1,2]  R1041     7.0392948389053345e-01
    z[7,1,2]  R1042     1.3838779926300049e-01
    z[7,1,2]  R1043     -5.0884738564491272e-02
    z[7,1,2]  R1044     2.9170921072363853e-02
    z[7,1,2]  R1045     -4.9306163191795349e-01
    z[7,1,2]  R1046     -3.4111782908439636e-01
    z[7,1,2]  R1047     -4.5788824558258057e-01
    z[7,1,2]  R1048     -0.519756555557251
    z[7,1,2]  R1049     -2.6853203773498535e-01
    z[7,1,2]  R1050     5.8138924837112427e-01
    z[7,1,2]  R1051     -2.0634530484676361e-01
    z[7,1,2]  R1052     -3.3708235621452332e-01
    z[7,1,2]  R1053     -3.9220988750457764e-01
    z[7,1,3]  R14       1
    z[7,1,3]  R68       -1
    z[7,1,3]  R954      -1
    z[7,1,3]  R955      1
    z[7,1,3]  R962      2.1336081624031067e-01
    z[7,1,3]  R963      7.9396776854991913e-03
    z[7,1,3]  R964      -1.5130911953747272e-02
    z[7,1,3]  R965      -8.4489017724990845e-02
    z[7,1,3]  R966      1.9082543253898621e-01
    z[7,1,3]  R967      0.310305118560791
    z[7,1,3]  R968      1.1281483806669712e-02
    z[7,1,3]  R969      2.4558851122856140e-01
    z[7,1,3]  R970      2.4062691628932953e-01
    z[7,1,3]  R971      3.6169907450675964e-01
    z[7,1,3]  R972      -9.5866424089763314e-05
    z[7,1,3]  R973      6.2737171538174152e-03
    z[7,1,3]  R974      -4.9242008477449417e-02
    z[7,1,3]  R975      -8.9440263807773590e-02
    z[7,1,3]  R976      -1.2167779356241226e-01
    z[7,1,3]  R977      1.7906905710697174e-01
    z[7,1,3]  R978      1.5895548462867737e-01
    z[7,1,3]  R979      -9.5122829079627991e-02
    z[7,1,3]  R980      -7.8436203300952911e-02
    z[7,1,3]  R981      6.6721066832542419e-03
    z[7,1,3]  R982      3.1728571653366089e-01
    z[7,1,3]  R983      -1.3364253938198090e-01
    z[7,1,3]  R984      -4.9848143011331558e-02
    z[7,1,3]  R985      4.1682282090187073e-01
    z[7,1,3]  R986      6.3563042879104614e-01
    z[7,1,3]  R987      4.5382767915725708e-01
    z[7,1,3]  R988      6.9629192352294922e-01
    z[7,1,3]  R989      7.9223698377609253e-01
    z[7,1,3]  R990      3.2487702369689941e-01
    z[7,1,3]  R991      -1.7021021246910095e-01
    z[7,1,3]  R992      3.3239468932151794e-01
    z[7,1,3]  R993      1.1013448238372803e-01
    z[7,1,3]  R994      5.5118042975664139e-02
    z[7,1,3]  R995      7.5845491886138916e-01
    z[7,1,3]  R996      -4.6045112609863281e-01
    z[7,1,3]  R997      1.1464538425207138e-01
    z[7,1,3]  R998      -2.7030047774314880e-01
    z[7,1,3]  R999      5.3859239816665649e-01
    z[7,1,3]  R1000     2.4339058995246887e-01
    z[7,1,3]  R1001     -1.8081294000148773e-01
    z[7,1,3]  R1002     -4.1440117359161377e-01
    z[7,1,3]  R1003     1.3351282104849815e-02
    z[7,1,3]  R1004     1.4195926487445831e-01
    z[7,1,3]  R1005     7.4260458350181580e-02
    z[7,1,3]  R1006     3.7941688299179077e-01
    z[7,1,3]  R1007     -0.0711718425154686
    z[7,1,3]  R1008     2.7141135931015015e-01
    z[7,1,3]  R1009     0.0403439924120903
    z[7,1,3]  R1010     -7.0779860019683838e-02
    z[7,1,3]  R1011     -1.4947031438350677e-01
    z[7,1,3]  R1012     5.7387119531631470e-01
    z[7,1,3]  R1013     -1.8258984386920929e-01
    z[7,1,3]  R1014     -5.4872053861618042e-01
    z[7,1,3]  R1015     1.2046121805906296e-01
    z[7,1,3]  R1016     1.4531119167804718e-01
    z[7,1,3]  R1017     -2.5036895275115967e-01
    z[7,1,3]  R1018     1.3941834867000580e-01
    z[7,1,3]  R1019     2.9689857363700867e-01
    z[7,1,3]  R1020     1.6956686973571777e-01
    z[7,1,3]  R1021     1.1790903657674789e-01
    z[7,1,3]  R1022     0.635644793510437
    z[7,1,3]  R1023     2.1650105714797974e-01
    z[7,1,3]  R1024     -2.8590098023414612e-01
    z[7,1,3]  R1025     5.9115849435329437e-02
    z[7,1,3]  R1026     -6.6254511475563049e-03
    z[7,1,3]  R1027     -0.457742303609848
    z[7,1,3]  R1028     1.0660663992166519e-01
    z[7,1,3]  R1029     1.0329223424196243e-01
    z[7,1,3]  R1030     2.9699310660362244e-01
    z[7,1,3]  R1031     1.2285843491554260e-01
    z[7,1,3]  R1032     -4.0729328989982605e-01
    z[7,1,3]  R1033     5.4033064842224121e-01
    z[7,1,3]  R1034     -4.8166982829570770e-02
    z[7,1,3]  R1035     2.7853947877883911e-01
    z[7,1,3]  R1036     -6.4410172402858734e-02
    z[7,1,3]  R1037     -3.2127812504768372e-01
    z[7,1,3]  R1038     -3.1471493840217590e-01
    z[7,1,3]  R1039     -5.5975690484046936e-02
    z[7,1,3]  R1040     -9.0436212718486786e-02
    z[7,1,3]  R1041     -4.9013805389404297e-01
    z[7,1,3]  R1042     -1.2913604080677032e-01
    z[7,1,3]  R1043     -2.6757690310478210e-01
    z[7,1,3]  R1044     0.289849191904068
    z[7,1,3]  R1045     1.5617226064205170e-01
    z[7,1,3]  R1046     -2.3016671836376190e-01
    z[7,1,3]  R1047     7.4717029929161072e-02
    z[7,1,3]  R1048     -3.6574643850326538e-01
    z[7,1,3]  R1049     6.8892216682434082e-01
    z[7,1,3]  R1050     -0.0466042086482048
    z[7,1,3]  R1051     -1.7337203025817871e-01
    z[7,1,3]  R1052     5.4751407355070114e-02
    z[7,1,3]  R1053     -5.2775126695632935e-01
    z[7,1,4]  R15       1
    z[7,1,4]  R69       -1
    z[7,1,4]  R956      -1
    z[7,1,4]  R957      1
    z[7,1,4]  R962      5.9422351419925690e-02
    z[7,1,4]  R963      -1.9214452803134918e-01
    z[7,1,4]  R964      2.2768998518586159e-02
    z[7,1,4]  R965      -1.0811345279216766e-01
    z[7,1,4]  R966      2.8450158424675465e-03
    z[7,1,4]  R967      -1.7688177525997162e-01
    z[7,1,4]  R968      3.1629720330238342e-01
    z[7,1,4]  R969      3.7627778947353363e-02
    z[7,1,4]  R970      -1.3504016213119030e-02
    z[7,1,4]  R971      -3.0993264913558960e-01
    z[7,1,4]  R972      -1.5718884766101837e-01
    z[7,1,4]  R973      5.4455578327178955e-01
    z[7,1,4]  R974      -1.5139667689800262e-01
    z[7,1,4]  R975      -5.4010105133056641e-01
    z[7,1,4]  R976      -4.8380544781684875e-01
    z[7,1,4]  R977      4.2592003941535950e-01
    z[7,1,4]  R978      -4.6477150917053223e-01
    z[7,1,4]  R979      1.5552908182144165e-01
    z[7,1,4]  R980      -0.358530193567276
    z[7,1,4]  R981      -1.1168579757213593e-01
    z[7,1,4]  R982      5.5943781137466431e-01
    z[7,1,4]  R983      1.8434017896652222e-01
    z[7,1,4]  R984      3.9101520180702209e-01
    z[7,1,4]  R985      6.2802612781524658e-01
    z[7,1,4]  R986      5.0317895412445068e-01
    z[7,1,4]  R987      1.2057242542505264e-01
    z[7,1,4]  R988      2.1572346985340118e-01
    z[7,1,4]  R989      -2.7864813804626465e-01
    z[7,1,4]  R990      -2.0015962421894073e-01
    z[7,1,4]  R991      -5.9578165411949158e-02
    z[7,1,4]  R992      1.1606896668672562e-01
    z[7,1,4]  R993      5.0491452217102051e-01
    z[7,1,4]  R994      6.3793194293975830e-01
    z[7,1,4]  R995      6.8251579068601131e-03
    z[7,1,4]  R996      3.2291319966316223e-01
    z[7,1,4]  R997      4.9339967966079712e-01
    z[7,1,4]  R998      2.7060031890869141e-01
    z[7,1,4]  R999      2.3952074348926544e-01
    z[7,1,4]  R1000     -6.2229067087173462e-01
    z[7,1,4]  R1001     7.8987866640090942e-02
    z[7,1,4]  R1002     -2.5162476301193237e-01
    z[7,1,4]  R1003     -1.6484941542148590e-01
    z[7,1,4]  R1004     -4.0740302205085754e-01
    z[7,1,4]  R1005     -3.8552686572074890e-01
    z[7,1,4]  R1006     4.6498816460371017e-02
    z[7,1,4]  R1007     -3.8213570951484144e-04
    z[7,1,4]  R1008     -1.7301419377326965e-01
    z[7,1,4]  R1009     -6.8801701068878174e-02
    z[7,1,4]  R1010     -3.9071694016456604e-02
    z[7,1,4]  R1011     -4.2013868689537048e-01
    z[7,1,4]  R1012     4.0225276350975037e-01
    z[7,1,4]  R1013     7.1406906843185425e-01
    z[7,1,4]  R1014     4.3973532319068909e-01
    z[7,1,4]  R1015     -7.6233841478824615e-02
    z[7,1,4]  R1016     1.1470503360033035e-01
    z[7,1,4]  R1017     7.1103684604167938e-02
    z[7,1,4]  R1018     -3.1166917085647583e-01
    z[7,1,4]  R1019     3.1659644097089767e-02
    z[7,1,4]  R1020     1.4390356838703156e-01
    z[7,1,4]  R1021     2.5604346394538879e-01
    z[7,1,4]  R1022     -1.7262098193168640e-01
    z[7,1,4]  R1023     -1.1364775896072388e-01
    z[7,1,4]  R1024     -3.3513152599334717e-01
    z[7,1,4]  R1025     1.1817936599254608e-01
    z[7,1,4]  R1026     -1.2361352145671844e-01
    z[7,1,4]  R1027     2.6135078072547913e-01
    z[7,1,4]  R1028     3.0776894092559814e-01
    z[7,1,4]  R1029     4.1240427643060684e-02
    z[7,1,4]  R1030     -1.6916111111640930e-01
    z[7,1,4]  R1031     3.8667380809783936e-01
    z[7,1,4]  R1032     -2.0273748040199280e-01
    z[7,1,4]  R1033     -1.8839581310749054e-01
    z[7,1,4]  R1034     -0.280404657125473
    z[7,1,4]  R1035     -2.0461490750312805e-01
    z[7,1,4]  R1036     -2.5542688369750977e-01
    z[7,1,4]  R1037     -2.3426280915737152e-01
    z[7,1,4]  R1038     1.6930826008319855e-01
    z[7,1,4]  R1039     -1.2058027833700180e-01
    z[7,1,4]  R1040     1.4223098754882812e-01
    z[7,1,4]  R1041     -1.2113583087921143e-01
    z[7,1,4]  R1042     -3.1754605472087860e-02
    z[7,1,4]  R1043     -1.3101170957088470e-01
    z[7,1,4]  R1044     5.9391045570373535e-01
    z[7,1,4]  R1045     -9.2241771519184113e-02
    z[7,1,4]  R1046     -2.6756340265274048e-01
    z[7,1,4]  R1047     2.6170569658279419e-01
    z[7,1,4]  R1048     6.4118497073650360e-02
    z[7,1,4]  R1049     -3.7524932622909546e-01
    z[7,1,4]  R1050     1.2699003517627716e-01
    z[7,1,4]  R1051     -3.5339277982711792e-01
    z[7,1,4]  R1052     5.5316165089607239e-02
    z[7,1,4]  R1053     -1.0436274856328964e-01
    z[7,1,5]  R16       1
    z[7,1,5]  R70       -1
    z[7,1,5]  R958      -1
    z[7,1,5]  R959      1
    z[7,1,5]  R962      0.00815114751458168
    z[7,1,5]  R963      1.6097424924373627e-01
    z[7,1,5]  R964      -2.4331073462963104e-01
    z[7,1,5]  R965      -2.3352622985839844e-01
    z[7,1,5]  R966      -2.2083316743373871e-01
    z[7,1,5]  R967      -5.2200831472873688e-02
    z[7,1,5]  R968      5.9199732542037964e-01
    z[7,1,5]  R969      3.0169311165809631e-01
    z[7,1,5]  R970      1.8120923638343811e-01
    z[7,1,5]  R971      -1.6136570274829865e-01
    z[7,1,5]  R972      -3.1965515017509460e-01
    z[7,1,5]  R973      -3.1550022959709167e-01
    z[7,1,5]  R974      -2.1198825538158417e-01
    z[7,1,5]  R975      -4.0874508023262024e-01
    z[7,1,5]  R976      -2.1739758551120758e-01
    z[7,1,5]  R977      -1.3742758333683014e-01
    z[7,1,5]  R978      -3.5361200571060181e-01
    z[7,1,5]  R979      -3.7164643406867981e-01
    z[7,1,5]  R980      -3.7035247683525085e-01
    z[7,1,5]  R981      -5.2202105522155762e-01
    z[7,1,5]  R982      3.2202634215354919e-01
    z[7,1,5]  R983      -1.7131336033344269e-01
    z[7,1,5]  R984      -3.4875169396400452e-01
    z[7,1,5]  R985      1.1485569924116135e-01
    z[7,1,5]  R986      2.5832670927047729e-01
    z[7,1,5]  R987      1.6578520834445953e-01
    z[7,1,5]  R988      1.6976547241210938e-01
    z[7,1,5]  R989      5.2896046638488770e-01
    z[7,1,5]  R990      5.3319811820983887e-01
    z[7,1,5]  R991      -7.9358108341693878e-03
    z[7,1,5]  R992      4.1155338287353516e-01
    z[7,1,5]  R993      5.7823747396469116e-01
    z[7,1,5]  R994      -2.5613831356167793e-02
    z[7,1,5]  R995      5.0028479099273682e-01
    z[7,1,5]  R996      -1.8670815974473953e-02
    z[7,1,5]  R997      1.6047197580337524e-01
    z[7,1,5]  R998      3.6025676876306534e-02
    z[7,1,5]  R999      1.9604517519474030e-01
    z[7,1,5]  R1000     -0.429318368434906
    z[7,1,5]  R1001     -1.7985065281391144e-01
    z[7,1,5]  R1002     -5.0258863717317581e-02
    z[7,1,5]  R1003     -0.50553959608078
    z[7,1,5]  R1004     -4.1002359986305237e-01
    z[7,1,5]  R1005     -2.0191858708858490e-01
    z[7,1,5]  R1006     1.1014650017023087e-01
    z[7,1,5]  R1007     -2.7247246354818344e-02
    z[7,1,5]  R1008     -6.9881081581115723e-02
    z[7,1,5]  R1009     2.1768143773078918e-01
    z[7,1,5]  R1010     -6.6732531785964966e-01
    z[7,1,5]  R1011     -6.9999217987060547e-01
    z[7,1,5]  R1012     4.3726280331611633e-01
    z[7,1,5]  R1013     1.4854957163333893e-01
    z[7,1,5]  R1014     1.5420123934745789e-01
    z[7,1,5]  R1015     -0.094334177672863
    z[7,1,5]  R1016     -2.8806936740875244e-01
    z[7,1,5]  R1017     3.0473349615931511e-02
    z[7,1,5]  R1018     7.1793437004089355e-02
    z[7,1,5]  R1019     -1.9304917752742767e-01
    z[7,1,5]  R1020     1.3385677337646484e-01
    z[7,1,5]  R1021     1.9853435456752777e-01
    z[7,1,5]  R1022     4.3308857083320618e-01
    z[7,1,5]  R1023     0.0741511881351471
    z[7,1,5]  R1024     -4.2723512649536133e-01
    z[7,1,5]  R1025     5.9995427727699280e-02
    z[7,1,5]  R1026     -3.5500192642211914e-01
    z[7,1,5]  R1027     2.8033751249313354e-01
    z[7,1,5]  R1028     -1.9317139685153961e-01
    z[7,1,5]  R1029     4.1094236075878143e-02
    z[7,1,5]  R1030     -2.1376991271972656e-01
    z[7,1,5]  R1031     -1.1652937391772866e-03
    z[7,1,5]  R1032     -3.5724973678588867e-01
    z[7,1,5]  R1033     -5.2501040697097778e-01
    z[7,1,5]  R1034     8.2306081056594849e-01
    z[7,1,5]  R1035     7.4455350637435913e-02
    z[7,1,5]  R1036     3.4165728092193604e-01
    z[7,1,5]  R1037     -2.6723784208297729e-01
    z[7,1,5]  R1038     1.0493505001068115e-01
    z[7,1,5]  R1039     -1.0127409547567368e-01
    z[7,1,5]  R1040     -1.6792723536491394e-01
    z[7,1,5]  R1041     -1.8255116045475006e-01
    z[7,1,5]  R1042     -8.7863765656948090e-02
    z[7,1,5]  R1043     -3.8030883669853210e-01
    z[7,1,5]  R1044     2.3301929235458374e-01
    z[7,1,5]  R1045     7.4577951431274414e-01
    z[7,1,5]  R1046     3.5087481141090393e-02
    z[7,1,5]  R1047     -2.8743150830268860e-01
    z[7,1,5]  R1048     -3.0452570319175720e-01
    z[7,1,5]  R1049     2.1698819100856781e-01
    z[7,1,5]  R1050     4.7764277458190918e-01
    z[7,1,5]  R1051     1.8217791616916656e-01
    z[7,1,5]  R1052     -1.3483242690563202e-01
    z[7,1,5]  R1053     -2.0405036211013794e-01
    z[7,1,6]  R17       1
    z[7,1,6]  R71       -1
    z[7,1,6]  R960      -1
    z[7,1,6]  R961      1
    z[7,1,6]  R962      -8.5424654185771942e-02
    z[7,1,6]  R963      1.4204651117324829e-01
    z[7,1,6]  R964      -3.1563821434974670e-01
    z[7,1,6]  R965      -3.3982202410697937e-02
    z[7,1,6]  R966      -9.3037769198417664e-02
    z[7,1,6]  R967      -2.5839787721633911e-01
    z[7,1,6]  R968      -1.9042136147618294e-02
    z[7,1,6]  R969      1.1859728395938873e-01
    z[7,1,6]  R970      -1.7192541854456067e-03
    z[7,1,6]  R971      -2.5719583034515381e-02
    z[7,1,6]  R972      0.272826224565506
    z[7,1,6]  R973      -1.4592908322811127e-01
    z[7,1,6]  R974      0.0883352980017662
    z[7,1,6]  R975      2.3601607978343964e-01
    z[7,1,6]  R976      2.8957530856132507e-01
    z[7,1,6]  R977      3.5161668062210083e-01
    z[7,1,6]  R978      -2.2178536280989647e-02
    z[7,1,6]  R979      -2.2910106182098389e-01
    z[7,1,6]  R980      -0.279342383146286
    z[7,1,6]  R981      6.8481385707855225e-02
    z[7,1,6]  R982      2.2746691107749939e-01
    z[7,1,6]  R983      2.7614927291870117e-01
    z[7,1,6]  R984      -2.7461913228034973e-01
    z[7,1,6]  R985      -4.0738663077354431e-01
    z[7,1,6]  R986      -3.3743351697921753e-01
    z[7,1,6]  R987      6.0053861141204834e-01
    z[7,1,6]  R988      -2.7851322293281555e-01
    z[7,1,6]  R989      -1.3669953681528568e-02
    z[7,1,6]  R990      7.1014779806137085e-01
    z[7,1,6]  R991      3.0918738245964050e-01
    z[7,1,6]  R992      6.2395554780960083e-01
    z[7,1,6]  R993      4.5911943912506104e-01
    z[7,1,6]  R994      -2.8632143139839172e-01
    z[7,1,6]  R995      1.2162868864834309e-02
    z[7,1,6]  R996      -2.2372503578662872e-01
    z[7,1,6]  R997      -5.6143510341644287e-01
    z[7,1,6]  R998      5.4943454265594482e-01
    z[7,1,6]  R999      -0.665951132774353
    z[7,1,6]  R1000     1.5840151906013489e-01
    z[7,1,6]  R1001     -2.1365078166127205e-02
    z[7,1,6]  R1002     1.5309567749500275e-01
    z[7,1,6]  R1003     4.5373108237981796e-02
    z[7,1,6]  R1004     -2.7633062005043030e-01
    z[7,1,6]  R1005     -3.1513014435768127e-01
    z[7,1,6]  R1006     -5.8834567666053772e-02
    z[7,1,6]  R1007     -1.0482275485992432e-01
    z[7,1,6]  R1008     -1.5043185651302338e-01
    z[7,1,6]  R1009     -1.1765944957733154e-01
    z[7,1,6]  R1010     1.9668446853756905e-02
    z[7,1,6]  R1011     -8.1644721329212189e-02
    z[7,1,6]  R1012     2.2319868206977844e-02
    z[7,1,6]  R1013     -2.9431256651878357e-01
    z[7,1,6]  R1014     3.7668031454086304e-01
    z[7,1,6]  R1015     -2.7511370182037354e-01
    z[7,1,6]  R1016     3.4089684486389160e-02
    z[7,1,6]  R1017     -1.6389900445938110e-01
    z[7,1,6]  R1018     2.8716831002384424e-04
    z[7,1,6]  R1019     1.8524080514907837e-01
    z[7,1,6]  R1020     -2.3157205432653427e-02
    z[7,1,6]  R1021     -3.3950844407081604e-01
    z[7,1,6]  R1022     -3.4378501772880554e-01
    z[7,1,6]  R1023     -5.8123809099197388e-01
    z[7,1,6]  R1024     -2.1278581023216248e-01
    z[7,1,6]  R1025     2.2819848358631134e-01
    z[7,1,6]  R1026     4.4436073303222656e-01
    z[7,1,6]  R1027     6.3039287924766541e-02
    z[7,1,6]  R1028     2.1365134045481682e-02
    z[7,1,6]  R1029     1.3199381530284882e-01
    z[7,1,6]  R1030     -1.1755295097827911e-01
    z[7,1,6]  R1031     -2.9218699783086777e-02
    z[7,1,6]  R1032     1.9509072601795197e-01
    z[7,1,6]  R1033     -2.5431713089346886e-02
    z[7,1,6]  R1034     2.8574258089065552e-01
    z[7,1,6]  R1035     9.6433833241462708e-02
    z[7,1,6]  R1036     1.7172423005104065e-01
    z[7,1,6]  R1037     3.0988961458206177e-01
    z[7,1,6]  R1038     2.6388822123408318e-02
    z[7,1,6]  R1039     1.7337700724601746e-01
    z[7,1,6]  R1040     -7.7882311306893826e-03
    z[7,1,6]  R1041     1.8303962051868439e-01
    z[7,1,6]  R1042     -3.6888930201530457e-01
    z[7,1,6]  R1043     -1.6560163348913193e-02
    z[7,1,6]  R1044     -4.9504969269037247e-02
    z[7,1,6]  R1045     -1.7858718335628510e-01
    z[7,1,6]  R1046     -2.8049442172050476e-01
    z[7,1,6]  R1047     -0.483377069234848
    z[7,1,6]  R1048     -0.547780454158783
    z[7,1,6]  R1049     4.5364937186241150e-01
    z[7,1,6]  R1050     -1.0871516168117523e-01
    z[7,1,6]  R1051     -7.5729645788669586e-02
    z[7,1,6]  R1052     -0.313103049993515
    z[7,1,6]  R1053     -4.6434280276298523e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1054     -1
    z[2,6,0]  R1055     1
    z[2,6,0]  R1068     -1.4782412350177765e-01
    z[2,6,0]  R1069     -2.7121052145957947e-01
    z[2,6,0]  R1070     -4.2609363794326782e-01
    z[2,6,0]  R1071     8.9835673570632935e-02
    z[2,6,0]  R1072     1.5872716903686523e-01
    z[2,6,0]  R1073     -4.2676275968551636e-01
    z[2,6,0]  R1074     -4.4167912006378174e-01
    z[2,6,0]  R1075     -4.8775526881217957e-01
    z[2,6,0]  R1076     -4.5682573318481445e-01
    z[2,6,0]  R1077     -1.1885754019021988e-01
    z[2,6,0]  R1078     3.8897725939750671e-01
    z[2,6,0]  R1079     3.5454452037811279e-01
    z[2,6,0]  R1080     2.8881320357322693e-01
    z[2,6,0]  R1081     4.6142455935478210e-01
    z[2,6,0]  R1082     5.3530693054199219e-01
    z[2,6,0]  R1083     3.7302318215370178e-01
    z[2,6,0]  R1084     4.8588916659355164e-01
    z[2,6,0]  R1085     5.7735973596572876e-01
    z[2,6,0]  R1086     5.8803540468215942e-01
    z[2,6,0]  R1087     5.1394337415695190e-01
    z[2,6,0]  R1088     4.3111103773117065e-01
    z[2,6,0]  R1089     3.4580138325691223e-01
    z[2,6,0]  R1090     0.584464430809021
    z[2,6,0]  R1091     0.696518063545227
    z[2,6,0]  R1092     6.6535425186157227e-01
    z[2,6,0]  R1093     2.6260477304458618e-01
    z[2,6,0]  R1094     3.3323770761489868e-01
    z[2,6,0]  R1095     2.3147930204868317e-01
    z[2,6,0]  R1096     5.5249071121215820e-01
    z[2,6,0]  R1097     -2.8479587286710739e-02
    z[2,6,0]  R1098     -2.8795897960662842e-01
    z[2,6,0]  R1099     1.7002350091934204e-01
    z[2,6,0]  R1100     3.7074264883995056e-01
    z[2,6,0]  R1101     4.0712225437164307e-01
    z[2,6,0]  R1102     2.7213799953460693e-01
    z[2,6,0]  R1103     2.5323492288589478e-01
    z[2,6,0]  R1104     1.2948262691497803e-01
    z[2,6,0]  R1105     6.1186432838439941e-01
    z[2,6,0]  R1106     6.2839525938034058e-01
    z[2,6,0]  R1107     5.9266000986099243e-01
    z[2,6,0]  R1108     -2.9768115282058716e-01
    z[2,6,0]  R1109     7.9456394910812378e-01
    z[2,6,0]  R1110     1.2260476499795914e-01
    z[2,6,0]  R1111     1.8940119445323944e-01
    z[2,6,0]  R1112     8.9682662487030029e-01
    z[2,6,0]  R1113     1.5533445775508881e-01
    z[2,6,0]  R1114     2.3656730353832245e-01
    z[2,6,0]  R1115     1.4052592217922211e-01
    z[2,6,0]  R1116     1.9808086752891541e-01
    z[2,6,0]  R1117     -2.1435850858688354e-01
    z[2,6,0]  R1118     -7.1324408054351807e-03
    z[2,6,0]  R1119     -0.609872043132782
    z[2,6,0]  R1120     -3.5625150799751282e-01
    z[2,6,0]  R1121     3.0565840005874634e-01
    z[2,6,0]  R1122     5.8468718081712723e-02
    z[2,6,0]  R1123     3.7295544147491455e-01
    z[2,6,0]  R1124     -4.7175645828247070e-02
    z[2,6,0]  R1125     -3.3855131268501282e-01
    z[2,6,0]  R1126     3.1291771680116653e-02
    z[2,6,0]  R1127     -2.0230922847986221e-02
    z[2,6,0]  R1128     1.5634299814701080e-01
    z[2,6,0]  R1129     3.0353438854217529e-01
    z[2,6,0]  R1130     -7.5079208612442017e-01
    z[2,6,0]  R1131     2.2267715632915497e-01
    z[2,6,0]  R1132     4.5826411247253418e-01
    z[2,6,0]  R1133     3.4416344761848450e-01
    z[2,6,0]  R1134     1.6742998361587524e-01
    z[2,6,0]  R1135     5.6998956203460693e-01
    z[2,6,0]  R1136     -7.1649444103240967e-01
    z[2,6,0]  R1137     -7.2960138320922852e-01
    z[2,6,0]  R1138     -3.8719708099961281e-03
    z[2,6,0]  R1139     0.377970814704895
    z[2,6,0]  R1140     3.6683431267738342e-01
    z[2,6,0]  R1141     5.4809135198593140e-01
    z[2,6,0]  R1142     3.9708280563354492e-01
    z[2,6,0]  R1143     2.5789085030555725e-01
    z[2,6,0]  R1144     6.8862646818161011e-01
    z[2,6,0]  R1145     -6.4441777765750885e-02
    z[2,6,0]  R1146     4.6054384112358093e-01
    z[2,6,0]  R1147     -1.5428721904754639e-01
    z[2,6,0]  R1148     -1.6341438889503479e-01
    z[2,6,0]  R1149     -3.2093605399131775e-01
    z[2,6,0]  R1150     -8.8356596231460571e-01
    z[2,6,0]  R1151     -1.7391633987426758e-01
    z[2,6,0]  R1152     -0.804546594619751
    z[2,6,0]  R1153     -8.6530953645706177e-01
    z[2,6,0]  R1154     6.3675379753112793e-01
    z[2,6,0]  R1155     -0.66482013463974
    z[2,6,0]  R1156     -6.4516210556030273e-01
    z[2,6,0]  R1157     -3.7745776772499084e-01
    z[2,6,0]  R1158     -2.4024908244609833e-01
    z[2,6,0]  R1159     -2.0745202898979187e-02
    z[2,6,0]  R1160     -3.7880662828683853e-02
    z[2,6,0]  R1161     -2.6529708504676819e-01
    z[2,6,0]  R1162     0.00278069986961782
    z[2,6,0]  R1163     -0.371847540140152
    z[2,6,0]  R1164     -8.7815326452255249e-01
    z[2,6,0]  R1165     -1.9606430083513260e-02
    z[2,6,0]  R1166     -1.5016080439090729e-01
    z[2,6,0]  R1167     2.2420510649681091e-01
    z[2,6,0]  R1168     -1.9836762547492981e-01
    z[2,6,0]  R1169     4.6706837415695190e-01
    z[2,6,0]  R1170     -1.8074283376336098e-02
    z[2,6,0]  R1171     1.8469411134719849e-01
    z[2,6,0]  R1172     -6.5395943820476532e-02
    z[2,6,0]  R1173     2.0739491283893585e-01
    z[2,6,0]  R1174     9.2153802514076233e-02
    z[2,6,0]  R1175     -3.3485004305839539e-01
    z[2,6,0]  R1176     5.7475157082080841e-02
    z[2,6,0]  R1177     8.2998253405094147e-02
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1056     -1
    z[2,6,1]  R1057     1
    z[2,6,1]  R1068     -0.450273722410202
    z[2,6,1]  R1069     -3.6599117517471313e-01
    z[2,6,1]  R1070     -1.7743575572967529e-01
    z[2,6,1]  R1071     -5.0480651855468750e-01
    z[2,6,1]  R1072     -6.7000722885131836e-01
    z[2,6,1]  R1073     -8.3980625867843628e-01
    z[2,6,1]  R1074     -7.3805534839630127e-01
    z[2,6,1]  R1075     -6.8874347209930420e-01
    z[2,6,1]  R1076     -0.69554603099823
    z[2,6,1]  R1077     -8.4459286928176880e-01
    z[2,6,1]  R1078     9.0619117021560669e-02
    z[2,6,1]  R1079     3.5812300629913807e-03
    z[2,6,1]  R1080     1.0858666896820068e-01
    z[2,6,1]  R1081     3.2087564468383789e-01
    z[2,6,1]  R1082     3.6810154560953379e-03
    z[2,6,1]  R1083     -2.2005392611026764e-01
    z[2,6,1]  R1084     4.5547958463430405e-02
    z[2,6,1]  R1085     1.2174101918935776e-01
    z[2,6,1]  R1086     -7.4106492102146149e-02
    z[2,6,1]  R1087     4.8135435581207275e-01
    z[2,6,1]  R1088     3.6078253388404846e-01
    z[2,6,1]  R1089     5.2687269449234009e-01
    z[2,6,1]  R1090     -1.9589845836162567e-01
    z[2,6,1]  R1091     -1.6955339908599854e-01
    z[2,6,1]  R1092     -1.4765505492687225e-01
    z[2,6,1]  R1093     2.3742891848087311e-01
    z[2,6,1]  R1094     6.7550569772720337e-01
    z[2,6,1]  R1095     6.8556523323059082e-01
    z[2,6,1]  R1096     3.7840464711189270e-01
    z[2,6,1]  R1097     7.0039027929306030e-01
    z[2,6,1]  R1098     3.6631658673286438e-01
    z[2,6,1]  R1099     -9.6432730555534363e-02
    z[2,6,1]  R1100     -1.7140366137027740e-01
    z[2,6,1]  R1101     -1.8234404921531677e-01
    z[2,6,1]  R1102     -1.4444039762020111e-01
    z[2,6,1]  R1103     -5.5179785937070847e-02
    z[2,6,1]  R1104     -7.5423799455165863e-02
    z[2,6,1]  R1105     4.8955509066581726e-01
    z[2,6,1]  R1106     5.2413874864578247e-01
    z[2,6,1]  R1107     4.3968778848648071e-01
    z[2,6,1]  R1108     2.2655875980854034e-01
    z[2,6,1]  R1109     -2.6407933235168457e-01
    z[2,6,1]  R1110     -4.6501386910676956e-02
    z[2,6,1]  R1111     1.6103906929492950e-01
    z[2,6,1]  R1112     3.6249703168869019e-01
    z[2,6,1]  R1113     5.4928815364837646e-01
    z[2,6,1]  R1114     7.9501521587371826e-01
    z[2,6,1]  R1115     0.604786217212677
    z[2,6,1]  R1116     4.5172744989395142e-01
    z[2,6,1]  R1117     4.8909822106361389e-01
    z[2,6,1]  R1118     1.1356388777494431e-01
    z[2,6,1]  R1119     -4.9036312103271484e-01
    z[2,6,1]  R1120     -0.268771767616272
    z[2,6,1]  R1121     -1.7898106575012207e-01
    z[2,6,1]  R1122     1.5737524256110191e-02
    z[2,6,1]  R1123     9.0887606143951416e-02
    z[2,6,1]  R1124     -4.1235667467117310e-01
    z[2,6,1]  R1125     1.8914127349853516e-01
    z[2,6,1]  R1126     -3.6051037907600403e-01
    z[2,6,1]  R1127     -4.4455164670944214e-01
    z[2,6,1]  R1128     5.7409924268722534e-01
    z[2,6,1]  R1129     0.521532416343689
    z[2,6,1]  R1130     4.0930244326591492e-01
    z[2,6,1]  R1131     5.2007561922073364e-01
    z[2,6,1]  R1132     6.0095995664596558e-01
    z[2,6,1]  R1133     4.5345729589462280e-01
    z[2,6,1]  R1134     5.4914832115173340e-01
    z[2,6,1]  R1135     5.0805473327636719e-01
    z[2,6,1]  R1136     5.8904081583023071e-01
    z[2,6,1]  R1137     2.8098881244659424e-01
    z[2,6,1]  R1138     -8.2848638296127319e-01
    z[2,6,1]  R1139     -6.1497098207473755e-01
    z[2,6,1]  R1140     -5.0910407304763794e-01
    z[2,6,1]  R1141     -6.8660420179367065e-01
    z[2,6,1]  R1142     -0.74765944480896
    z[2,6,1]  R1143     -7.9350328445434570e-01
    z[2,6,1]  R1144     -3.7632763385772705e-01
    z[2,6,1]  R1145     -5.1575195789337158e-01
    z[2,6,1]  R1146     -6.1419796943664551e-01
    z[2,6,1]  R1147     -3.1984734535217285e-01
    z[2,6,1]  R1148     -2.7069896459579468e-01
    z[2,6,1]  R1149     -4.9074128270149231e-01
    z[2,6,1]  R1150     8.4123871056362987e-04
    z[2,6,1]  R1151     -5.9279185533523560e-01
    z[2,6,1]  R1152     3.5964214801788330e-01
    z[2,6,1]  R1153     1.4193475246429443e-01
    z[2,6,1]  R1154     -6.0124039649963379e-01
    z[2,6,1]  R1155     0.0818859413266182
    z[2,6,1]  R1156     -5.1137939095497131e-02
    z[2,6,1]  R1157     -5.5152320861816406e-01
    z[2,6,1]  R1158     -6.5132069587707520e-01
    z[2,6,1]  R1159     -6.1464887857437134e-01
    z[2,6,1]  R1160     -2.9878202080726624e-01
    z[2,6,1]  R1161     -3.0940631031990051e-01
    z[2,6,1]  R1162     -3.6072564125061035e-01
    z[2,6,1]  R1163     -0.62802654504776
    z[2,6,1]  R1164     2.0927037298679352e-01
    z[2,6,1]  R1165     -6.8977546691894531e-01
    z[2,6,1]  R1166     -6.4189249277114868e-01
    z[2,6,1]  R1167     2.0453146100044250e-01
    z[2,6,1]  R1168     -6.6997438669204712e-01
    z[2,6,1]  R1169     -3.8101676106452942e-01
    z[2,6,1]  R1170     0.609222948551178
    z[2,6,1]  R1171     6.8127177655696869e-02
    z[2,6,1]  R1172     2.0265281200408936e-01
    z[2,6,1]  R1173     4.5337605476379395e-01
    z[2,6,1]  R1174     2.0321825146675110e-01
    z[2,6,1]  R1175     -5.7266287505626678e-02
    z[2,6,1]  R1176     1.5035147964954376e-01
    z[2,6,1]  R1177     -1.6053926199674606e-02
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1058     -1
    z[2,6,2]  R1059     1
    z[2,6,2]  R1068     6.8378245830535889e-01
    z[2,6,2]  R1069     6.3701760768890381e-01
    z[2,6,2]  R1070     8.2270896434783936e-01
    z[2,6,2]  R1071     7.8873842954635620e-01
    z[2,6,2]  R1072     4.9533864855766296e-01
    z[2,6,2]  R1073     1.3021484017372131e-01
    z[2,6,2]  R1074     1.9035948812961578e-01
    z[2,6,2]  R1075     0.517758846282959
    z[2,6,2]  R1076     2.3810453712940216e-01
    z[2,6,2]  R1077     -1.1931928992271423e-01
    z[2,6,2]  R1078     -8.0693596601486206e-01
    z[2,6,2]  R1079     -7.6489633321762085e-01
    z[2,6,2]  R1080     -6.3491022586822510e-01
    z[2,6,2]  R1081     -6.3651943206787109e-01
    z[2,6,2]  R1082     -6.1497306823730469e-01
    z[2,6,2]  R1083     -5.7035428285598755e-01
    z[2,6,2]  R1084     -5.6095844507217407e-01
    z[2,6,2]  R1085     -5.2547782659530640e-01
    z[2,6,2]  R1086     -6.7329776287078857e-01
    z[2,6,2]  R1087     -3.2091107964515686e-01
    z[2,6,2]  R1088     2.6161280274391174e-01
    z[2,6,2]  R1089     4.5063313841819763e-01
    z[2,6,2]  R1090     9.8026670515537262e-02
    z[2,6,2]  R1091     -1.2122385203838348e-01
    z[2,6,2]  R1092     -1.2712979316711426e-01
    z[2,6,2]  R1093     -1.3833381235599518e-01
    z[2,6,2]  R1094     -1.5411974489688873e-01
    z[2,6,2]  R1095     -2.5532284751534462e-02
    z[2,6,2]  R1096     -1.9931019842624664e-01
    z[2,6,2]  R1097     -7.1439862251281738e-02
    z[2,6,2]  R1098     4.4743287563323975e-01
    z[2,6,2]  R1099     3.6612075567245483e-01
    z[2,6,2]  R1100     3.0734816193580627e-01
    z[2,6,2]  R1101     -9.8225146532058716e-02
    z[2,6,2]  R1102     1.1402430245652795e-03
    z[2,6,2]  R1103     2.8212782740592957e-01
    z[2,6,2]  R1104     -1.5990474820137024e-01
    z[2,6,2]  R1105     -3.8946467638015747e-01
    z[2,6,2]  R1106     1.6579274833202362e-01
    z[2,6,2]  R1107     1.4172625541687012e-01
    z[2,6,2]  R1108     3.9897614717483521e-01
    z[2,6,2]  R1109     1.8585719168186188e-01
    z[2,6,2]  R1110     5.6403100490570068e-02
    z[2,6,2]  R1111     3.4615629911422729e-01
    z[2,6,2]  R1112     -6.6663399338722229e-02
    z[2,6,2]  R1113     -1.8497291207313538e-01
    z[2,6,2]  R1114     -1.4014115929603577e-01
    z[2,6,2]  R1115     -2.6403433084487915e-01
    z[2,6,2]  R1116     -4.2821100354194641e-01
    z[2,6,2]  R1117     -0.280825138092041
    z[2,6,2]  R1118     -6.6207003593444824e-01
    z[2,6,2]  R1119     -5.6170988082885742e-01
    z[2,6,2]  R1120     -4.9344068765640259e-01
    z[2,6,2]  R1121     -7.3885542154312134e-01
    z[2,6,2]  R1122     -5.0496435165405273e-01
    z[2,6,2]  R1123     -3.2723531126976013e-01
    z[2,6,2]  R1124     -6.5867567062377930e-01
    z[2,6,2]  R1125     -4.8692572116851807e-01
    z[2,6,2]  R1126     -5.9139841794967651e-01
    z[2,6,2]  R1127     -5.0206708908081055e-01
    z[2,6,2]  R1128     7.6512783765792847e-01
    z[2,6,2]  R1129     6.8397843837738037e-01
    z[2,6,2]  R1130     3.6982640624046326e-01
    z[2,6,2]  R1131     7.0460414886474609e-01
    z[2,6,2]  R1132     0.552261471748352
    z[2,6,2]  R1133     6.2330263853073120e-01
    z[2,6,2]  R1134     6.0658687353134155e-01
    z[2,6,2]  R1135     5.6052255630493164e-01
    z[2,6,2]  R1136     1.9127818942070007e-01
    z[2,6,2]  R1137     4.7686657309532166e-01
    z[2,6,2]  R1138     -2.2575299441814423e-01
    z[2,6,2]  R1139     -4.3765774369239807e-01
    z[2,6,2]  R1140     -3.4211507439613342e-01
    z[2,6,2]  R1141     -4.0068873763084412e-01
    z[2,6,2]  R1142     -1.5267378091812134e-01
    z[2,6,2]  R1143     -3.5434699058532715e-01
    z[2,6,2]  R1144     -3.5900583863258362e-01
    z[2,6,2]  R1145     -1.2537996470928192e-01
    z[2,6,2]  R1146     -1.0073851794004440e-01
    z[2,6,2]  R1147     -3.6328250169754028e-01
    z[2,6,2]  R1148     -5.9387695789337158e-01
    z[2,6,2]  R1149     -3.5038021206855774e-01
    z[2,6,2]  R1150     -9.6438162028789520e-02
    z[2,6,2]  R1151     -4.6328902244567871e-01
    z[2,6,2]  R1152     -2.7555164694786072e-01
    z[2,6,2]  R1153     1.7317138612270355e-01
    z[2,6,2]  R1154     -3.0879771709442139e-01
    z[2,6,2]  R1155     -4.7949111461639404e-01
    z[2,6,2]  R1156     -4.8743149638175964e-01
    z[2,6,2]  R1157     2.0412076264619827e-02
    z[2,6,2]  R1158     -0.616512656211853
    z[2,6,2]  R1159     -5.6968605518341064e-01
    z[2,6,2]  R1160     -5.5516713857650757e-01
    z[2,6,2]  R1161     -5.1011794805526733e-01
    z[2,6,2]  R1162     -6.2455916404724121e-01
    z[2,6,2]  R1163     -2.4228592216968536e-01
    z[2,6,2]  R1164     2.3195035755634308e-01
    z[2,6,2]  R1165     -3.4269922971725464e-01
    z[2,6,2]  R1166     -4.9695184826850891e-01
    z[2,6,2]  R1167     1.2902058660984039e-01
    z[2,6,2]  R1168     -2.7538421750068665e-01
    z[2,6,2]  R1169     -2.1320012211799622e-01
    z[2,6,2]  R1170     4.7804632782936096e-01
    z[2,6,2]  R1171     5.1289552450180054e-01
    z[2,6,2]  R1172     4.1988608241081238e-01
    z[2,6,2]  R1173     -1.2099956721067429e-01
    z[2,6,2]  R1174     -4.5156544446945190e-01
    z[2,6,2]  R1175     -6.2282466888427734e-01
    z[2,6,2]  R1176     2.7554255723953247e-01
    z[2,6,2]  R1177     3.4326678514480591e-01
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1060     -1
    z[2,6,3]  R1061     1
    z[2,6,3]  R1068     -1.1237671226263046e-01
    z[2,6,3]  R1069     -9.2583127319812775e-02
    z[2,6,3]  R1070     3.4817929845303297e-03
    z[2,6,3]  R1071     5.8322656899690628e-02
    z[2,6,3]  R1072     1.2655712664127350e-01
    z[2,6,3]  R1073     -7.5186669826507568e-02
    z[2,6,3]  R1074     -2.6910807937383652e-02
    z[2,6,3]  R1075     9.5883026719093323e-02
    z[2,6,3]  R1076     2.2942881286144257e-01
    z[2,6,3]  R1077     1.6687752306461334e-01
    z[2,6,3]  R1078     1.9492086768150330e-01
    z[2,6,3]  R1079     8.3154529333114624e-02
    z[2,6,3]  R1080     1.1766187101602554e-01
    z[2,6,3]  R1081     1.5138009190559387e-01
    z[2,6,3]  R1082     3.8418102264404297e-01
    z[2,6,3]  R1083     -3.4220034722238779e-03
    z[2,6,3]  R1084     -3.3298607915639877e-02
    z[2,6,3]  R1085     0.188424214720726
    z[2,6,3]  R1086     -1.5593400597572327e-01
    z[2,6,3]  R1087     -5.7853475213050842e-02
    z[2,6,3]  R1088     -5.2110069990158081e-01
    z[2,6,3]  R1089     -0.59122234582901
    z[2,6,3]  R1090     -5.0959432125091553e-01
    z[2,6,3]  R1091     -3.4905630350112915e-01
    z[2,6,3]  R1092     -4.1432005167007446e-01
    z[2,6,3]  R1093     -3.6713162064552307e-01
    z[2,6,3]  R1094     4.4533109664916992e-01
    z[2,6,3]  R1095     5.5941206216812134e-01
    z[2,6,3]  R1096     3.9711400866508484e-01
    z[2,6,3]  R1097     0.643405556678772
    z[2,6,3]  R1098     -3.2677242159843445e-01
    z[2,6,3]  R1099     -7.3861151933670044e-01
    z[2,6,3]  R1100     -5.7146298885345459e-01
    z[2,6,3]  R1101     1.2318743765354156e-01
    z[2,6,3]  R1102     -5.0712424516677856e-01
    z[2,6,3]  R1103     -1.5272945165634155e-01
    z[2,6,3]  R1104     -6.1037933826446533e-01
    z[2,6,3]  R1105     2.3904601112008095e-02
    z[2,6,3]  R1106     5.0548028945922852e-01
    z[2,6,3]  R1107     0.298697829246521
    z[2,6,3]  R1108     -7.8724640607833862e-01
    z[2,6,3]  R1109     -5.3819864988327026e-02
    z[2,6,3]  R1110     -7.6515994966030121e-02
    z[2,6,3]  R1111     1.6152633726596832e-01
    z[2,6,3]  R1112     7.2003252804279327e-02
    z[2,6,3]  R1113     7.9220914840698242e-01
    z[2,6,3]  R1114     5.0273102521896362e-01
    z[2,6,3]  R1115     6.5140515565872192e-01
    z[2,6,3]  R1116     5.3595691919326782e-01
    z[2,6,3]  R1117     0.577110767364502
    z[2,6,3]  R1118     7.0285123586654663e-01
    z[2,6,3]  R1119     -1.7225007712841034e-01
    z[2,6,3]  R1120     4.4561344385147095e-01
    z[2,6,3]  R1121     3.9838501811027527e-01
    z[2,6,3]  R1122     3.7805780768394470e-01
    z[2,6,3]  R1123     6.2986296415328979e-01
    z[2,6,3]  R1124     -1.2511213123798370e-01
    z[2,6,3]  R1125     0.42557492852211
    z[2,6,3]  R1126     -1.0559994727373123e-01
    z[2,6,3]  R1127     2.1751316264271736e-02
    z[2,6,3]  R1128     1.7642891407012939e-01
    z[2,6,3]  R1129     2.7874562144279480e-01
    z[2,6,3]  R1130     1.1768934130668640e-01
    z[2,6,3]  R1131     0.139877051115036
    z[2,6,3]  R1132     1.7006102204322815e-01
    z[2,6,3]  R1133     4.9650269746780396e-01
    z[2,6,3]  R1134     4.2137256264686584e-01
    z[2,6,3]  R1135     1.0021498799324036e-01
    z[2,6,3]  R1136     5.2976712584495544e-02
    z[2,6,3]  R1137     2.5871220976114273e-02
    z[2,6,3]  R1138     -4.0048643946647644e-01
    z[2,6,3]  R1139     -2.1492913365364075e-01
    z[2,6,3]  R1140     -1.8450836837291718e-01
    z[2,6,3]  R1141     1.2105809897184372e-01
    z[2,6,3]  R1142     -1.1410713195800781e-01
    z[2,6,3]  R1143     2.2164495661854744e-02
    z[2,6,3]  R1144     -4.1962409019470215e-01
    z[2,6,3]  R1145     -4.3861925601959229e-01
    z[2,6,3]  R1146     -5.0154322385787964e-01
    z[2,6,3]  R1147     -3.6153492331504822e-01
    z[2,6,3]  R1148     -5.6492835283279419e-01
    z[2,6,3]  R1149     -0.350996732711792
    z[2,6,3]  R1150     7.1377992630004883e-02
    z[2,6,3]  R1151     -3.6774033308029175e-01
    z[2,6,3]  R1152     1.1131998151540756e-01
    z[2,6,3]  R1153     -2.9271697998046875e-01
    z[2,6,3]  R1154     -3.3724820613861084e-01
    z[2,6,3]  R1155     1.0116033256053925e-01
    z[2,6,3]  R1156     2.8972604870796204e-01
    z[2,6,3]  R1157     -2.9796159267425537e-01
    z[2,6,3]  R1158     -2.4730089306831360e-01
    z[2,6,3]  R1159     -3.6283436417579651e-01
    z[2,6,3]  R1160     -6.5098208189010620e-01
    z[2,6,3]  R1161     -6.8950426578521729e-01
    z[2,6,3]  R1162     -2.6326560974121094e-01
    z[2,6,3]  R1163     -2.6847904920578003e-01
    z[2,6,3]  R1164     -1.8104347586631775e-01
    z[2,6,3]  R1165     2.9219800233840942e-01
    z[2,6,3]  R1166     5.3422415256500244e-01
    z[2,6,3]  R1167     9.3962311744689941e-02
    z[2,6,3]  R1168     -3.1924274563789368e-01
    z[2,6,3]  R1169     -6.8487578630447388e-01
    z[2,6,3]  R1170     -1.2396093457937241e-01
    z[2,6,3]  R1171     1.1860295385122299e-01
    z[2,6,3]  R1172     -3.6851714830845594e-03
    z[2,6,3]  R1173     3.0113914608955383e-01
    z[2,6,3]  R1174     2.2926524281501770e-01
    z[2,6,3]  R1175     2.7679237723350525e-01
    z[2,6,3]  R1176     -5.6929498910903931e-01
    z[2,6,3]  R1177     -5.3526127338409424e-01
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1062     -1
    z[2,6,4]  R1063     1
    z[2,6,4]  R1068     -2.5894564390182495e-01
    z[2,6,4]  R1069     -2.9697573184967041e-01
    z[2,6,4]  R1070     -1.2680433690547943e-01
    z[2,6,4]  R1071     2.6569423079490662e-01
    z[2,6,4]  R1072     0.0797264575958252
    z[2,6,4]  R1073     -9.9610462784767151e-02
    z[2,6,4]  R1074     -2.4736022949218750e-01
    z[2,6,4]  R1075     7.5029850006103516e-02
    z[2,6,4]  R1076     -1.2354150414466858e-02
    z[2,6,4]  R1077     7.8336149454116821e-02
    z[2,6,4]  R1078     1.5492191910743713e-01
    z[2,6,4]  R1079     0.0875663235783577
    z[2,6,4]  R1080     2.2947868704795837e-01
    z[2,6,4]  R1081     2.0054118335247040e-01
    z[2,6,4]  R1082     3.2300212979316711e-01
    z[2,6,4]  R1083     3.6831492185592651e-01
    z[2,6,4]  R1084     3.1155723333358765e-01
    z[2,6,4]  R1085     4.0080478787422180e-01
    z[2,6,4]  R1086     3.9789858460426331e-01
    z[2,6,4]  R1087     5.3485298156738281e-01
    z[2,6,4]  R1088     2.0066809654235840e-01
    z[2,6,4]  R1089     -1.9148169457912445e-01
    z[2,6,4]  R1090     -4.1219338774681091e-01
    z[2,6,4]  R1091     -5.5085223913192749e-01
    z[2,6,4]  R1092     -4.9488613009452820e-01
    z[2,6,4]  R1093     -7.1058726310729980e-01
    z[2,6,4]  R1094     1.6640616953372955e-01
    z[2,6,4]  R1095     3.5721543245017529e-03
    z[2,6,4]  R1096     -4.6340253949165344e-01
    z[2,6,4]  R1097     -2.2988986968994141e-01
    z[2,6,4]  R1098     -3.2883152365684509e-01
    z[2,6,4]  R1099     4.7746646404266357e-01
    z[2,6,4]  R1100     -1.1411070078611374e-01
    z[2,6,4]  R1101     -4.4207006692886353e-01
    z[2,6,4]  R1102     4.8652318120002747e-01
    z[2,6,4]  R1103     -8.9223784208297729e-01
    z[2,6,4]  R1104     -4.0364375710487366e-01
    z[2,6,4]  R1105     -4.2736896872520447e-01
    z[2,6,4]  R1106     -1.2966082990169525e-01
    z[2,6,4]  R1107     -0.33858522772789
    z[2,6,4]  R1108     -2.7010414004325867e-01
    z[2,6,4]  R1109     -9.6203640103340149e-02
    z[2,6,4]  R1110     -8.7878651916980743e-02
    z[2,6,4]  R1111     -4.3254595994949341e-01
    z[2,6,4]  R1112     -1.5487727522850037e-01
    z[2,6,4]  R1113     3.8389221299439669e-03
    z[2,6,4]  R1114     -5.9812910854816437e-02
    z[2,6,4]  R1115     -2.5321865081787109e-01
    z[2,6,4]  R1116     -2.3832413554191589e-01
    z[2,6,4]  R1117     -4.2883336544036865e-01
    z[2,6,4]  R1118     7.3707611300051212e-03
    z[2,6,4]  R1119     -1.1025711894035339e-01
    z[2,6,4]  R1120     2.2705543041229248e-01
    z[2,6,4]  R1121     1.8147720396518707e-01
    z[2,6,4]  R1122     3.1352239847183228e-01
    z[2,6,4]  R1123     3.4658116102218628e-01
    z[2,6,4]  R1124     -2.7731582522392273e-01
    z[2,6,4]  R1125     2.6809543371200562e-01
    z[2,6,4]  R1126     -1.9075492024421692e-01
    z[2,6,4]  R1127     -5.3753042221069336e-01
    z[2,6,4]  R1128     9.7786642611026764e-02
    z[2,6,4]  R1129     2.6051837205886841e-01
    z[2,6,4]  R1130     -4.0340710431337357e-02
    z[2,6,4]  R1131     -2.0097592473030090e-01
    z[2,6,4]  R1132     2.7689328417181969e-02
    z[2,6,4]  R1133     2.0092625170946121e-02
    z[2,6,4]  R1134     -1.9369050860404968e-01
    z[2,6,4]  R1135     0.0772441104054451
    z[2,6,4]  R1136     -6.6140934824943542e-02
    z[2,6,4]  R1137     2.9915568232536316e-01
    z[2,6,4]  R1138     1.8556652963161469e-01
    z[2,6,4]  R1139     -1.8377484381198883e-01
    z[2,6,4]  R1140     -4.2894887924194336e-01
    z[2,6,4]  R1141     6.9989293813705444e-02
    z[2,6,4]  R1142     2.6184371113777161e-01
    z[2,6,4]  R1143     3.8881441950798035e-01
    z[2,6,4]  R1144     -2.6986005902290344e-01
    z[2,6,4]  R1145     0.478142648935318
    z[2,6,4]  R1146     3.4068933129310608e-01
    z[2,6,4]  R1147     -5.9474412351846695e-02
    z[2,6,4]  R1148     -2.1574285626411438e-01
    z[2,6,4]  R1149     -2.8994113206863403e-01
    z[2,6,4]  R1150     -1.7099156975746155e-01
    z[2,6,4]  R1151     4.3007937073707581e-01
    z[2,6,4]  R1152     -1.8034437298774719e-01
    z[2,6,4]  R1153     3.6082316190004349e-02
    z[2,6,4]  R1154     1.0241910815238953e-01
    z[2,6,4]  R1155     -2.6553717255592346e-01
    z[2,6,4]  R1156     8.7884448468685150e-02
    z[2,6,4]  R1157     3.7979838252067566e-01
    z[2,6,4]  R1158     1.2877424061298370e-01
    z[2,6,4]  R1159     -2.3375539481639862e-01
    z[2,6,4]  R1160     -3.0089142918586731e-01
    z[2,6,4]  R1161     -2.5148290395736694e-01
    z[2,6,4]  R1162     8.1425786018371582e-02
    z[2,6,4]  R1163     5.4870493710041046e-02
    z[2,6,4]  R1164     2.2733654081821442e-01
    z[2,6,4]  R1165     9.5197439193725586e-02
    z[2,6,4]  R1166     -8.6993388831615448e-02
    z[2,6,4]  R1167     -4.7589138150215149e-02
    z[2,6,4]  R1168     -2.9893046244978905e-02
    z[2,6,4]  R1169     -1.7614772915840149e-01
    z[2,6,4]  R1170     -8.7283954024314880e-02
    z[2,6,4]  R1171     2.7306738495826721e-01
    z[2,6,4]  R1172     2.1143786609172821e-01
    z[2,6,4]  R1173     7.3112696409225464e-01
    z[2,6,4]  R1174     1.8248160183429718e-01
    z[2,6,4]  R1175     -5.6155747175216675e-01
    z[2,6,4]  R1176     -5.0185203552246094e-01
    z[2,6,4]  R1177     -3.0351039767265320e-01
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1064     -1
    z[2,6,5]  R1065     1
    z[2,6,5]  R1068     -3.0977943539619446e-01
    z[2,6,5]  R1069     -2.3032417893409729e-01
    z[2,6,5]  R1070     -3.0635091662406921e-01
    z[2,6,5]  R1071     -2.0247609913349152e-01
    z[2,6,5]  R1072     -4.3803164362907410e-01
    z[2,6,5]  R1073     2.7999192476272583e-01
    z[2,6,5]  R1074     -3.2522909343242645e-02
    z[2,6,5]  R1075     -5.5692322552204132e-02
    z[2,6,5]  R1076     -2.0731480792164803e-02
    z[2,6,5]  R1077     -2.1578426659107208e-01
    z[2,6,5]  R1078     3.4609884023666382e-01
    z[2,6,5]  R1079     4.6551403403282166e-01
    z[2,6,5]  R1080     6.5915763378143311e-01
    z[2,6,5]  R1081     3.9460220932960510e-01
    z[2,6,5]  R1082     0.192719966173172
    z[2,6,5]  R1083     5.6872242689132690e-01
    z[2,6,5]  R1084     4.4117224216461182e-01
    z[2,6,5]  R1085     2.8110796213150024e-01
    z[2,6,5]  R1086     1.1208473145961761e-01
    z[2,6,5]  R1087     2.7155107259750366e-01
    z[2,6,5]  R1088     -4.3861803412437439e-01
    z[2,6,5]  R1089     -6.7537024617195129e-02
    z[2,6,5]  R1090     1.7103704810142517e-01
    z[2,6,5]  R1091     -2.1028815209865570e-01
    z[2,6,5]  R1092     -2.4964958429336548e-01
    z[2,6,5]  R1093     -4.5664468407630920e-01
    z[2,6,5]  R1094     -2.9148340225219727e-01
    z[2,6,5]  R1095     -3.8634309172630310e-01
    z[2,6,5]  R1096     -3.6803993582725525e-01
    z[2,6,5]  R1097     -1.1284297704696655e-01
    z[2,6,5]  R1098     -5.3353202342987061e-01
    z[2,6,5]  R1099     1.7176094651222229e-01
    z[2,6,5]  R1100     4.9098852276802063e-01
    z[2,6,5]  R1101     -7.4825161695480347e-01
    z[2,6,5]  R1102     -1.3256806135177612e-01
    z[2,6,5]  R1103     1.5758083760738373e-01
    z[2,6,5]  R1104     -1.8381103873252869e-01
    z[2,6,5]  R1105     1.5108172781765461e-02
    z[2,6,5]  R1106     1.3056656718254089e-01
    z[2,6,5]  R1107     0.481060653924942
    z[2,6,5]  R1108     -9.0091437101364136e-02
    z[2,6,5]  R1109     -3.0887165665626526e-01
    z[2,6,5]  R1110     -9.2239004373550415e-01
    z[2,6,5]  R1111     -7.5115984678268433e-01
    z[2,6,5]  R1112     1.7373837530612946e-01
    z[2,6,5]  R1113     -2.7775179594755173e-02
    z[2,6,5]  R1114     -1.8732881546020508e-01
    z[2,6,5]  R1115     -1.5532526373863220e-01
    z[2,6,5]  R1116     -4.3492570519447327e-01
    z[2,6,5]  R1117     3.4181350469589233e-01
    z[2,6,5]  R1118     2.3018307983875275e-01
    z[2,6,5]  R1119     1.7263543605804443e-01
    z[2,6,5]  R1120     5.5181562900543213e-01
    z[2,6,5]  R1121     3.4368079900741577e-01
    z[2,6,5]  R1122     7.0261436700820923e-01
    z[2,6,5]  R1123     4.7340282797813416e-01
    z[2,6,5]  R1124     -2.5899496674537659e-01
    z[2,6,5]  R1125     5.5541670322418213e-01
    z[2,6,5]  R1126     4.8063647747039795e-01
    z[2,6,5]  R1127     3.3625525236129761e-01
    z[2,6,5]  R1128     1.1956129968166351e-01
    z[2,6,5]  R1129     -3.9061307907104492e-02
    z[2,6,5]  R1130     -2.4524421989917755e-01
    z[2,6,5]  R1131     -1.1231366544961929e-01
    z[2,6,5]  R1132     1.6097915172576904e-01
    z[2,6,5]  R1133     -8.4550447762012482e-02
    z[2,6,5]  R1134     -6.6976338624954224e-02
    z[2,6,5]  R1135     -1.4751136302947998e-01
    z[2,6,5]  R1136     2.2243642807006836e-01
    z[2,6,5]  R1137     -2.1594022214412689e-01
    z[2,6,5]  R1138     9.0554483234882355e-02
    z[2,6,5]  R1139     3.4834283590316772e-01
    z[2,6,5]  R1140     4.0248975157737732e-02
    z[2,6,5]  R1141     -1.4654375612735748e-02
    z[2,6,5]  R1142     1.6400316357612610e-01
    z[2,6,5]  R1143     -2.3947756737470627e-02
    z[2,6,5]  R1144     6.5748989582061768e-02
    z[2,6,5]  R1145     5.3899574279785156e-01
    z[2,6,5]  R1146     1.7916370928287506e-01
    z[2,6,5]  R1147     7.7944636344909668e-01
    z[2,6,5]  R1148     3.2812169194221497e-01
    z[2,6,5]  R1149     -2.5396534800529480e-01
    z[2,6,5]  R1150     -1.5706744790077209e-01
    z[2,6,5]  R1151     -7.3487579822540283e-02
    z[2,6,5]  R1152     3.1989347189664841e-02
    z[2,6,5]  R1153     -2.9093673825263977e-01
    z[2,6,5]  R1154     -1.1443016678094864e-01
    z[2,6,5]  R1155     -4.5611268281936646e-01
    z[2,6,5]  R1156     -3.9596292376518250e-01
    z[2,6,5]  R1157     3.6357650160789490e-01
    z[2,6,5]  R1158     -2.4460119009017944e-01
    z[2,6,5]  R1159     -2.2914563119411469e-01
    z[2,6,5]  R1160     -1.7768631875514984e-01
    z[2,6,5]  R1161     -1.5092007815837860e-01
    z[2,6,5]  R1162     4.6170303225517273e-01
    z[2,6,5]  R1163     1.8440628051757812e-01
    z[2,6,5]  R1164     2.1487553417682648e-01
    z[2,6,5]  R1165     1.4064885675907135e-01
    z[2,6,5]  R1166     7.8019447624683380e-02
    z[2,6,5]  R1167     -9.2405569553375244e-01
    z[2,6,5]  R1168     1.0758799314498901e-01
    z[2,6,5]  R1169     2.9926860332489014e-01
    z[2,6,5]  R1170     -5.7398641109466553e-01
    z[2,6,5]  R1171     -7.5456231832504272e-01
    z[2,6,5]  R1172     -8.5650849342346191e-01
    z[2,6,5]  R1173     -4.2700063437223434e-02
    z[2,6,5]  R1174     -1.5010915696620941e-01
    z[2,6,5]  R1175     3.0066564679145813e-01
    z[2,6,5]  R1176     -5.5725187063217163e-01
    z[2,6,5]  R1177     -6.9269603490829468e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1066     -1
    z[2,6,6]  R1067     1
    z[2,6,6]  R1068     -3.6359116435050964e-01
    z[2,6,6]  R1069     4.8671197891235352e-01
    z[2,6,6]  R1070     1.2976335361599922e-02
    z[2,6,6]  R1071     1.9841415632981807e-04
    z[2,6,6]  R1072     2.5747016072273254e-01
    z[2,6,6]  R1073     -4.0895272046327591e-02
    z[2,6,6]  R1074     4.0123319625854492e-01
    z[2,6,6]  R1075     0.0415741428732872
    z[2,6,6]  R1076     -4.4453600049018860e-01
    z[2,6,6]  R1077     -4.2160528898239136e-01
    z[2,6,6]  R1078     -8.6947746574878693e-02
    z[2,6,6]  R1079     2.4069288372993469e-01
    z[2,6,6]  R1080     2.6291970163583755e-02
    z[2,6,6]  R1081     2.4520504474639893e-01
    z[2,6,6]  R1082     2.1488258242607117e-01
    z[2,6,6]  R1083     1.6737145185470581e-01
    z[2,6,6]  R1084     3.9287796616554260e-01
    z[2,6,6]  R1085     3.1707757711410522e-01
    z[2,6,6]  R1086     -1.3823526911437511e-02
    z[2,6,6]  R1087     -1.9499093294143677e-01
    z[2,6,6]  R1088     3.3367431163787842e-01
    z[2,6,6]  R1089     -9.4794243574142456e-02
    z[2,6,6]  R1090     3.8932305574417114e-01
    z[2,6,6]  R1091     -4.3811149895191193e-02
    z[2,6,6]  R1092     2.0110045373439789e-01
    z[2,6,6]  R1093     -8.5356742143630981e-02
    z[2,6,6]  R1094     -3.1291925907135010e-01
    z[2,6,6]  R1095     -1.1640454828739166e-01
    z[2,6,6]  R1096     6.2806069850921631e-02
    z[2,6,6]  R1097     -1.5487149357795715e-01
    z[2,6,6]  R1098     -2.8832051157951355e-01
    z[2,6,6]  R1099     1.5724253654479980e-01
    z[2,6,6]  R1100     -3.9755105972290039e-01
    z[2,6,6]  R1101     -1.4447268843650818e-01
    z[2,6,6]  R1102     -0.627393364906311
    z[2,6,6]  R1103     9.4787724316120148e-02
    z[2,6,6]  R1104     -0.618626058101654
    z[2,6,6]  R1105     -2.2545768320560455e-01
    z[2,6,6]  R1106     -1.1636500060558319e-01
    z[2,6,6]  R1107     7.9149333760142326e-03
    z[2,6,6]  R1108     6.7283022217452526e-03
    z[2,6,6]  R1109     -3.9602261781692505e-01
    z[2,6,6]  R1110     -3.3947536349296570e-01
    z[2,6,6]  R1111     2.0234017074108124e-01
    z[2,6,6]  R1112     -2.2302420809864998e-02
    z[2,6,6]  R1113     -1.0750397294759750e-01
    z[2,6,6]  R1114     3.0643166974186897e-02
    z[2,6,6]  R1115     1.7943707108497620e-01
    z[2,6,6]  R1116     -2.0033207535743713e-01
    z[2,6,6]  R1117     4.6682354062795639e-02
    z[2,6,6]  R1118     -4.0954638272523880e-02
    z[2,6,6]  R1119     2.1268339827656746e-02
    z[2,6,6]  R1120     5.2315339446067810e-02
    z[2,6,6]  R1121     1.3736955821514130e-01
    z[2,6,6]  R1122     8.0335631966590881e-02
    z[2,6,6]  R1123     6.7857488989830017e-02
    z[2,6,6]  R1124     -4.8399096727371216e-01
    z[2,6,6]  R1125     -2.2590938210487366e-01
    z[2,6,6]  R1126     -4.9066364765167236e-01
    z[2,6,6]  R1127     -3.8394466042518616e-01
    z[2,6,6]  R1128     7.4578978121280670e-02
    z[2,6,6]  R1129     -1.4473941922187805e-01
    z[2,6,6]  R1130     2.3746220767498016e-01
    z[2,6,6]  R1131     3.3301338553428650e-01
    z[2,6,6]  R1132     -2.6124054193496704e-01
    z[2,6,6]  R1133     1.8263176083564758e-01
    z[2,6,6]  R1134     2.8792208433151245e-01
    z[2,6,6]  R1135     -2.5502455234527588e-01
    z[2,6,6]  R1136     -2.1545359492301941e-01
    z[2,6,6]  R1137     1.5662631392478943e-01
    z[2,6,6]  R1138     2.4414452910423279e-01
    z[2,6,6]  R1139     2.9341778159141541e-01
    z[2,6,6]  R1140     5.1917475461959839e-01
    z[2,6,6]  R1141     2.1874819695949554e-01
    z[2,6,6]  R1142     3.8928383588790894e-01
    z[2,6,6]  R1143     1.6137449443340302e-01
    z[2,6,6]  R1144     -4.5322526246309280e-02
    z[2,6,6]  R1145     -5.1023606210947037e-02
    z[2,6,6]  R1146     2.8241056948900223e-02
    z[2,6,6]  R1147     1.1728116311132908e-02
    z[2,6,6]  R1148     -2.7198362350463867e-01
    z[2,6,6]  R1149     5.1151126623153687e-01
    z[2,6,6]  R1150     3.8859617710113525e-01
    z[2,6,6]  R1151     -2.7948606014251709e-01
    z[2,6,6]  R1152     -3.1858119368553162e-01
    z[2,6,6]  R1153     1.7168654501438141e-01
    z[2,6,6]  R1154     -1.9448006525635719e-02
    z[2,6,6]  R1155     -0.180596262216568
    z[2,6,6]  R1156     -3.0839884281158447e-01
    z[2,6,6]  R1157     4.3326136469841003e-01
    z[2,6,6]  R1158     -2.0089246332645416e-02
    z[2,6,6]  R1159     2.4173586070537567e-01
    z[2,6,6]  R1160     -2.3494267463684082e-01
    z[2,6,6]  R1161     -1.1058136820793152e-01
    z[2,6,6]  R1162     -4.3667659163475037e-01
    z[2,6,6]  R1163     5.4727697372436523e-01
    z[2,6,6]  R1164     2.4932242929935455e-02
    z[2,6,6]  R1165     5.4051667451858521e-01
    z[2,6,6]  R1166     -1.3933502137660980e-01
    z[2,6,6]  R1167     -1.6211152076721191e-01
    z[2,6,6]  R1168     5.6706565618515015e-01
    z[2,6,6]  R1169     3.9679959416389465e-02
    z[2,6,6]  R1170     -2.1805323660373688e-01
    z[2,6,6]  R1171     2.0046980679035187e-01
    z[2,6,6]  R1172     4.9520316533744335e-03
    z[2,6,6]  R1173     -3.3127307891845703e-01
    z[2,6,6]  R1174     7.9868882894515991e-01
    z[2,6,6]  R1175     1.1968600749969482e-01
    z[2,6,6]  R1176     1.0809897631406784e-01
    z[2,6,6]  R1177     -1.2872619926929474e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1178     -1
    z[6,2,0]  R1179     1
    z[6,2,0]  R1192     -7.1324408054351807e-03
    z[6,2,0]  R1193     -0.609872043132782
    z[6,2,0]  R1194     -3.5625150799751282e-01
    z[6,2,0]  R1195     3.0565840005874634e-01
    z[6,2,0]  R1196     5.8468718081712723e-02
    z[6,2,0]  R1197     3.7295544147491455e-01
    z[6,2,0]  R1198     -4.7175645828247070e-02
    z[6,2,0]  R1199     -3.3855131268501282e-01
    z[6,2,0]  R1200     3.1291771680116653e-02
    z[6,2,0]  R1201     -2.0230922847986221e-02
    z[6,2,0]  R1202     1.5634299814701080e-01
    z[6,2,0]  R1203     3.0353438854217529e-01
    z[6,2,0]  R1204     -7.5079208612442017e-01
    z[6,2,0]  R1205     2.2267715632915497e-01
    z[6,2,0]  R1206     4.5826411247253418e-01
    z[6,2,0]  R1207     3.4416344761848450e-01
    z[6,2,0]  R1208     1.6742998361587524e-01
    z[6,2,0]  R1209     5.6998956203460693e-01
    z[6,2,0]  R1210     -7.1649444103240967e-01
    z[6,2,0]  R1211     -7.2960138320922852e-01
    z[6,2,0]  R1212     -3.8719708099961281e-03
    z[6,2,0]  R1213     0.377970814704895
    z[6,2,0]  R1214     3.6683431267738342e-01
    z[6,2,0]  R1215     5.4809135198593140e-01
    z[6,2,0]  R1216     3.9708280563354492e-01
    z[6,2,0]  R1217     2.5789085030555725e-01
    z[6,2,0]  R1218     6.8862646818161011e-01
    z[6,2,0]  R1219     -6.4441777765750885e-02
    z[6,2,0]  R1220     4.6054384112358093e-01
    z[6,2,0]  R1221     -1.5428721904754639e-01
    z[6,2,0]  R1222     -1.6341438889503479e-01
    z[6,2,0]  R1223     -3.2093605399131775e-01
    z[6,2,0]  R1224     -8.8356596231460571e-01
    z[6,2,0]  R1225     -1.7391633987426758e-01
    z[6,2,0]  R1226     -0.804546594619751
    z[6,2,0]  R1227     -8.6530953645706177e-01
    z[6,2,0]  R1228     6.3675379753112793e-01
    z[6,2,0]  R1229     -0.66482013463974
    z[6,2,0]  R1230     -6.4516210556030273e-01
    z[6,2,0]  R1231     -3.7745776772499084e-01
    z[6,2,0]  R1232     -2.4024908244609833e-01
    z[6,2,0]  R1233     -2.0745202898979187e-02
    z[6,2,0]  R1234     -3.7880662828683853e-02
    z[6,2,0]  R1235     -2.6529708504676819e-01
    z[6,2,0]  R1236     0.00278069986961782
    z[6,2,0]  R1237     -0.371847540140152
    z[6,2,0]  R1238     -8.7815326452255249e-01
    z[6,2,0]  R1239     -1.9606430083513260e-02
    z[6,2,0]  R1240     -1.5016080439090729e-01
    z[6,2,0]  R1241     2.2420510649681091e-01
    z[6,2,0]  R1242     -1.9836762547492981e-01
    z[6,2,0]  R1243     4.6706837415695190e-01
    z[6,2,0]  R1244     -1.8074283376336098e-02
    z[6,2,0]  R1245     1.8469411134719849e-01
    z[6,2,0]  R1246     -6.5395943820476532e-02
    z[6,2,0]  R1247     2.0739491283893585e-01
    z[6,2,0]  R1248     9.2153802514076233e-02
    z[6,2,0]  R1249     -3.3485004305839539e-01
    z[6,2,0]  R1250     5.7475157082080841e-02
    z[6,2,0]  R1251     8.2998253405094147e-02
    z[6,2,0]  R1252     -1.4782412350177765e-01
    z[6,2,0]  R1253     -2.7121052145957947e-01
    z[6,2,0]  R1254     -4.2609363794326782e-01
    z[6,2,0]  R1255     8.9835673570632935e-02
    z[6,2,0]  R1256     1.5872716903686523e-01
    z[6,2,0]  R1257     -4.2676275968551636e-01
    z[6,2,0]  R1258     -4.4167912006378174e-01
    z[6,2,0]  R1259     -4.8775526881217957e-01
    z[6,2,0]  R1260     -4.5682573318481445e-01
    z[6,2,0]  R1261     -1.1885754019021988e-01
    z[6,2,0]  R1262     3.8897725939750671e-01
    z[6,2,0]  R1263     3.5454452037811279e-01
    z[6,2,0]  R1264     2.8881320357322693e-01
    z[6,2,0]  R1265     4.6142455935478210e-01
    z[6,2,0]  R1266     5.3530693054199219e-01
    z[6,2,0]  R1267     3.7302318215370178e-01
    z[6,2,0]  R1268     4.8588916659355164e-01
    z[6,2,0]  R1269     5.7735973596572876e-01
    z[6,2,0]  R1270     5.8803540468215942e-01
    z[6,2,0]  R1271     5.1394337415695190e-01
    z[6,2,0]  R1272     4.3111103773117065e-01
    z[6,2,0]  R1273     3.4580138325691223e-01
    z[6,2,0]  R1274     0.584464430809021
    z[6,2,0]  R1275     0.696518063545227
    z[6,2,0]  R1276     6.6535425186157227e-01
    z[6,2,0]  R1277     2.6260477304458618e-01
    z[6,2,0]  R1278     3.3323770761489868e-01
    z[6,2,0]  R1279     2.3147930204868317e-01
    z[6,2,0]  R1280     5.5249071121215820e-01
    z[6,2,0]  R1281     -2.8479587286710739e-02
    z[6,2,0]  R1282     -2.8795897960662842e-01
    z[6,2,0]  R1283     1.7002350091934204e-01
    z[6,2,0]  R1284     3.7074264883995056e-01
    z[6,2,0]  R1285     4.0712225437164307e-01
    z[6,2,0]  R1286     2.7213799953460693e-01
    z[6,2,0]  R1287     2.5323492288589478e-01
    z[6,2,0]  R1288     1.2948262691497803e-01
    z[6,2,0]  R1289     6.1186432838439941e-01
    z[6,2,0]  R1290     6.2839525938034058e-01
    z[6,2,0]  R1291     5.9266000986099243e-01
    z[6,2,0]  R1292     -2.9768115282058716e-01
    z[6,2,0]  R1293     7.9456394910812378e-01
    z[6,2,0]  R1294     1.2260476499795914e-01
    z[6,2,0]  R1295     1.8940119445323944e-01
    z[6,2,0]  R1296     8.9682662487030029e-01
    z[6,2,0]  R1297     1.5533445775508881e-01
    z[6,2,0]  R1298     2.3656730353832245e-01
    z[6,2,0]  R1299     1.4052592217922211e-01
    z[6,2,0]  R1300     1.9808086752891541e-01
    z[6,2,0]  R1301     -2.1435850858688354e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1180     -1
    z[6,2,1]  R1181     1
    z[6,2,1]  R1192     1.1356388777494431e-01
    z[6,2,1]  R1193     -4.9036312103271484e-01
    z[6,2,1]  R1194     -0.268771767616272
    z[6,2,1]  R1195     -1.7898106575012207e-01
    z[6,2,1]  R1196     1.5737524256110191e-02
    z[6,2,1]  R1197     9.0887606143951416e-02
    z[6,2,1]  R1198     -4.1235667467117310e-01
    z[6,2,1]  R1199     1.8914127349853516e-01
    z[6,2,1]  R1200     -3.6051037907600403e-01
    z[6,2,1]  R1201     -4.4455164670944214e-01
    z[6,2,1]  R1202     5.7409924268722534e-01
    z[6,2,1]  R1203     0.521532416343689
    z[6,2,1]  R1204     4.0930244326591492e-01
    z[6,2,1]  R1205     5.2007561922073364e-01
    z[6,2,1]  R1206     6.0095995664596558e-01
    z[6,2,1]  R1207     4.5345729589462280e-01
    z[6,2,1]  R1208     5.4914832115173340e-01
    z[6,2,1]  R1209     5.0805473327636719e-01
    z[6,2,1]  R1210     5.8904081583023071e-01
    z[6,2,1]  R1211     2.8098881244659424e-01
    z[6,2,1]  R1212     -8.2848638296127319e-01
    z[6,2,1]  R1213     -6.1497098207473755e-01
    z[6,2,1]  R1214     -5.0910407304763794e-01
    z[6,2,1]  R1215     -6.8660420179367065e-01
    z[6,2,1]  R1216     -0.74765944480896
    z[6,2,1]  R1217     -7.9350328445434570e-01
    z[6,2,1]  R1218     -3.7632763385772705e-01
    z[6,2,1]  R1219     -5.1575195789337158e-01
    z[6,2,1]  R1220     -6.1419796943664551e-01
    z[6,2,1]  R1221     -3.1984734535217285e-01
    z[6,2,1]  R1222     -2.7069896459579468e-01
    z[6,2,1]  R1223     -4.9074128270149231e-01
    z[6,2,1]  R1224     8.4123871056362987e-04
    z[6,2,1]  R1225     -5.9279185533523560e-01
    z[6,2,1]  R1226     3.5964214801788330e-01
    z[6,2,1]  R1227     1.4193475246429443e-01
    z[6,2,1]  R1228     -6.0124039649963379e-01
    z[6,2,1]  R1229     0.0818859413266182
    z[6,2,1]  R1230     -5.1137939095497131e-02
    z[6,2,1]  R1231     -5.5152320861816406e-01
    z[6,2,1]  R1232     -6.5132069587707520e-01
    z[6,2,1]  R1233     -6.1464887857437134e-01
    z[6,2,1]  R1234     -2.9878202080726624e-01
    z[6,2,1]  R1235     -3.0940631031990051e-01
    z[6,2,1]  R1236     -3.6072564125061035e-01
    z[6,2,1]  R1237     -0.62802654504776
    z[6,2,1]  R1238     2.0927037298679352e-01
    z[6,2,1]  R1239     -6.8977546691894531e-01
    z[6,2,1]  R1240     -6.4189249277114868e-01
    z[6,2,1]  R1241     2.0453146100044250e-01
    z[6,2,1]  R1242     -6.6997438669204712e-01
    z[6,2,1]  R1243     -3.8101676106452942e-01
    z[6,2,1]  R1244     0.609222948551178
    z[6,2,1]  R1245     6.8127177655696869e-02
    z[6,2,1]  R1246     2.0265281200408936e-01
    z[6,2,1]  R1247     4.5337605476379395e-01
    z[6,2,1]  R1248     2.0321825146675110e-01
    z[6,2,1]  R1249     -5.7266287505626678e-02
    z[6,2,1]  R1250     1.5035147964954376e-01
    z[6,2,1]  R1251     -1.6053926199674606e-02
    z[6,2,1]  R1252     -0.450273722410202
    z[6,2,1]  R1253     -3.6599117517471313e-01
    z[6,2,1]  R1254     -1.7743575572967529e-01
    z[6,2,1]  R1255     -5.0480651855468750e-01
    z[6,2,1]  R1256     -6.7000722885131836e-01
    z[6,2,1]  R1257     -8.3980625867843628e-01
    z[6,2,1]  R1258     -7.3805534839630127e-01
    z[6,2,1]  R1259     -6.8874347209930420e-01
    z[6,2,1]  R1260     -0.69554603099823
    z[6,2,1]  R1261     -8.4459286928176880e-01
    z[6,2,1]  R1262     9.0619117021560669e-02
    z[6,2,1]  R1263     3.5812300629913807e-03
    z[6,2,1]  R1264     1.0858666896820068e-01
    z[6,2,1]  R1265     3.2087564468383789e-01
    z[6,2,1]  R1266     3.6810154560953379e-03
    z[6,2,1]  R1267     -2.2005392611026764e-01
    z[6,2,1]  R1268     4.5547958463430405e-02
    z[6,2,1]  R1269     1.2174101918935776e-01
    z[6,2,1]  R1270     -7.4106492102146149e-02
    z[6,2,1]  R1271     4.8135435581207275e-01
    z[6,2,1]  R1272     3.6078253388404846e-01
    z[6,2,1]  R1273     5.2687269449234009e-01
    z[6,2,1]  R1274     -1.9589845836162567e-01
    z[6,2,1]  R1275     -1.6955339908599854e-01
    z[6,2,1]  R1276     -1.4765505492687225e-01
    z[6,2,1]  R1277     2.3742891848087311e-01
    z[6,2,1]  R1278     6.7550569772720337e-01
    z[6,2,1]  R1279     6.8556523323059082e-01
    z[6,2,1]  R1280     3.7840464711189270e-01
    z[6,2,1]  R1281     7.0039027929306030e-01
    z[6,2,1]  R1282     3.6631658673286438e-01
    z[6,2,1]  R1283     -9.6432730555534363e-02
    z[6,2,1]  R1284     -1.7140366137027740e-01
    z[6,2,1]  R1285     -1.8234404921531677e-01
    z[6,2,1]  R1286     -1.4444039762020111e-01
    z[6,2,1]  R1287     -5.5179785937070847e-02
    z[6,2,1]  R1288     -7.5423799455165863e-02
    z[6,2,1]  R1289     4.8955509066581726e-01
    z[6,2,1]  R1290     5.2413874864578247e-01
    z[6,2,1]  R1291     4.3968778848648071e-01
    z[6,2,1]  R1292     2.2655875980854034e-01
    z[6,2,1]  R1293     -2.6407933235168457e-01
    z[6,2,1]  R1294     -4.6501386910676956e-02
    z[6,2,1]  R1295     1.6103906929492950e-01
    z[6,2,1]  R1296     3.6249703168869019e-01
    z[6,2,1]  R1297     5.4928815364837646e-01
    z[6,2,1]  R1298     7.9501521587371826e-01
    z[6,2,1]  R1299     0.604786217212677
    z[6,2,1]  R1300     4.5172744989395142e-01
    z[6,2,1]  R1301     4.8909822106361389e-01
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1182     -1
    z[6,2,2]  R1183     1
    z[6,2,2]  R1192     -6.6207003593444824e-01
    z[6,2,2]  R1193     -5.6170988082885742e-01
    z[6,2,2]  R1194     -4.9344068765640259e-01
    z[6,2,2]  R1195     -7.3885542154312134e-01
    z[6,2,2]  R1196     -5.0496435165405273e-01
    z[6,2,2]  R1197     -3.2723531126976013e-01
    z[6,2,2]  R1198     -6.5867567062377930e-01
    z[6,2,2]  R1199     -4.8692572116851807e-01
    z[6,2,2]  R1200     -5.9139841794967651e-01
    z[6,2,2]  R1201     -5.0206708908081055e-01
    z[6,2,2]  R1202     7.6512783765792847e-01
    z[6,2,2]  R1203     6.8397843837738037e-01
    z[6,2,2]  R1204     3.6982640624046326e-01
    z[6,2,2]  R1205     7.0460414886474609e-01
    z[6,2,2]  R1206     0.552261471748352
    z[6,2,2]  R1207     6.2330263853073120e-01
    z[6,2,2]  R1208     6.0658687353134155e-01
    z[6,2,2]  R1209     5.6052255630493164e-01
    z[6,2,2]  R1210     1.9127818942070007e-01
    z[6,2,2]  R1211     4.7686657309532166e-01
    z[6,2,2]  R1212     -2.2575299441814423e-01
    z[6,2,2]  R1213     -4.3765774369239807e-01
    z[6,2,2]  R1214     -3.4211507439613342e-01
    z[6,2,2]  R1215     -4.0068873763084412e-01
    z[6,2,2]  R1216     -1.5267378091812134e-01
    z[6,2,2]  R1217     -3.5434699058532715e-01
    z[6,2,2]  R1218     -3.5900583863258362e-01
    z[6,2,2]  R1219     -1.2537996470928192e-01
    z[6,2,2]  R1220     -1.0073851794004440e-01
    z[6,2,2]  R1221     -3.6328250169754028e-01
    z[6,2,2]  R1222     -5.9387695789337158e-01
    z[6,2,2]  R1223     -3.5038021206855774e-01
    z[6,2,2]  R1224     -9.6438162028789520e-02
    z[6,2,2]  R1225     -4.6328902244567871e-01
    z[6,2,2]  R1226     -2.7555164694786072e-01
    z[6,2,2]  R1227     1.7317138612270355e-01
    z[6,2,2]  R1228     -3.0879771709442139e-01
    z[6,2,2]  R1229     -4.7949111461639404e-01
    z[6,2,2]  R1230     -4.8743149638175964e-01
    z[6,2,2]  R1231     2.0412076264619827e-02
    z[6,2,2]  R1232     -0.616512656211853
    z[6,2,2]  R1233     -5.6968605518341064e-01
    z[6,2,2]  R1234     -5.5516713857650757e-01
    z[6,2,2]  R1235     -5.1011794805526733e-01
    z[6,2,2]  R1236     -6.2455916404724121e-01
    z[6,2,2]  R1237     -2.4228592216968536e-01
    z[6,2,2]  R1238     2.3195035755634308e-01
    z[6,2,2]  R1239     -3.4269922971725464e-01
    z[6,2,2]  R1240     -4.9695184826850891e-01
    z[6,2,2]  R1241     1.2902058660984039e-01
    z[6,2,2]  R1242     -2.7538421750068665e-01
    z[6,2,2]  R1243     -2.1320012211799622e-01
    z[6,2,2]  R1244     4.7804632782936096e-01
    z[6,2,2]  R1245     5.1289552450180054e-01
    z[6,2,2]  R1246     4.1988608241081238e-01
    z[6,2,2]  R1247     -1.2099956721067429e-01
    z[6,2,2]  R1248     -4.5156544446945190e-01
    z[6,2,2]  R1249     -6.2282466888427734e-01
    z[6,2,2]  R1250     2.7554255723953247e-01
    z[6,2,2]  R1251     3.4326678514480591e-01
    z[6,2,2]  R1252     6.8378245830535889e-01
    z[6,2,2]  R1253     6.3701760768890381e-01
    z[6,2,2]  R1254     8.2270896434783936e-01
    z[6,2,2]  R1255     7.8873842954635620e-01
    z[6,2,2]  R1256     4.9533864855766296e-01
    z[6,2,2]  R1257     1.3021484017372131e-01
    z[6,2,2]  R1258     1.9035948812961578e-01
    z[6,2,2]  R1259     0.517758846282959
    z[6,2,2]  R1260     2.3810453712940216e-01
    z[6,2,2]  R1261     -1.1931928992271423e-01
    z[6,2,2]  R1262     -8.0693596601486206e-01
    z[6,2,2]  R1263     -7.6489633321762085e-01
    z[6,2,2]  R1264     -6.3491022586822510e-01
    z[6,2,2]  R1265     -6.3651943206787109e-01
    z[6,2,2]  R1266     -6.1497306823730469e-01
    z[6,2,2]  R1267     -5.7035428285598755e-01
    z[6,2,2]  R1268     -5.6095844507217407e-01
    z[6,2,2]  R1269     -5.2547782659530640e-01
    z[6,2,2]  R1270     -6.7329776287078857e-01
    z[6,2,2]  R1271     -3.2091107964515686e-01
    z[6,2,2]  R1272     2.6161280274391174e-01
    z[6,2,2]  R1273     4.5063313841819763e-01
    z[6,2,2]  R1274     9.8026670515537262e-02
    z[6,2,2]  R1275     -1.2122385203838348e-01
    z[6,2,2]  R1276     -1.2712979316711426e-01
    z[6,2,2]  R1277     -1.3833381235599518e-01
    z[6,2,2]  R1278     -1.5411974489688873e-01
    z[6,2,2]  R1279     -2.5532284751534462e-02
    z[6,2,2]  R1280     -1.9931019842624664e-01
    z[6,2,2]  R1281     -7.1439862251281738e-02
    z[6,2,2]  R1282     4.4743287563323975e-01
    z[6,2,2]  R1283     3.6612075567245483e-01
    z[6,2,2]  R1284     3.0734816193580627e-01
    z[6,2,2]  R1285     -9.8225146532058716e-02
    z[6,2,2]  R1286     1.1402430245652795e-03
    z[6,2,2]  R1287     2.8212782740592957e-01
    z[6,2,2]  R1288     -1.5990474820137024e-01
    z[6,2,2]  R1289     -3.8946467638015747e-01
    z[6,2,2]  R1290     1.6579274833202362e-01
    z[6,2,2]  R1291     1.4172625541687012e-01
    z[6,2,2]  R1292     3.9897614717483521e-01
    z[6,2,2]  R1293     1.8585719168186188e-01
    z[6,2,2]  R1294     5.6403100490570068e-02
    z[6,2,2]  R1295     3.4615629911422729e-01
    z[6,2,2]  R1296     -6.6663399338722229e-02
    z[6,2,2]  R1297     -1.8497291207313538e-01
    z[6,2,2]  R1298     -1.4014115929603577e-01
    z[6,2,2]  R1299     -2.6403433084487915e-01
    z[6,2,2]  R1300     -4.2821100354194641e-01
    z[6,2,2]  R1301     -0.280825138092041
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1184     -1
    z[6,2,3]  R1185     1
    z[6,2,3]  R1192     7.0285123586654663e-01
    z[6,2,3]  R1193     -1.7225007712841034e-01
    z[6,2,3]  R1194     4.4561344385147095e-01
    z[6,2,3]  R1195     3.9838501811027527e-01
    z[6,2,3]  R1196     3.7805780768394470e-01
    z[6,2,3]  R1197     6.2986296415328979e-01
    z[6,2,3]  R1198     -1.2511213123798370e-01
    z[6,2,3]  R1199     0.42557492852211
    z[6,2,3]  R1200     -1.0559994727373123e-01
    z[6,2,3]  R1201     2.1751316264271736e-02
    z[6,2,3]  R1202     1.7642891407012939e-01
    z[6,2,3]  R1203     2.7874562144279480e-01
    z[6,2,3]  R1204     1.1768934130668640e-01
    z[6,2,3]  R1205     0.139877051115036
    z[6,2,3]  R1206     1.7006102204322815e-01
    z[6,2,3]  R1207     4.9650269746780396e-01
    z[6,2,3]  R1208     4.2137256264686584e-01
    z[6,2,3]  R1209     1.0021498799324036e-01
    z[6,2,3]  R1210     5.2976712584495544e-02
    z[6,2,3]  R1211     2.5871220976114273e-02
    z[6,2,3]  R1212     -4.0048643946647644e-01
    z[6,2,3]  R1213     -2.1492913365364075e-01
    z[6,2,3]  R1214     -1.8450836837291718e-01
    z[6,2,3]  R1215     1.2105809897184372e-01
    z[6,2,3]  R1216     -1.1410713195800781e-01
    z[6,2,3]  R1217     2.2164495661854744e-02
    z[6,2,3]  R1218     -4.1962409019470215e-01
    z[6,2,3]  R1219     -4.3861925601959229e-01
    z[6,2,3]  R1220     -5.0154322385787964e-01
    z[6,2,3]  R1221     -3.6153492331504822e-01
    z[6,2,3]  R1222     -5.6492835283279419e-01
    z[6,2,3]  R1223     -0.350996732711792
    z[6,2,3]  R1224     7.1377992630004883e-02
    z[6,2,3]  R1225     -3.6774033308029175e-01
    z[6,2,3]  R1226     1.1131998151540756e-01
    z[6,2,3]  R1227     -2.9271697998046875e-01
    z[6,2,3]  R1228     -3.3724820613861084e-01
    z[6,2,3]  R1229     1.0116033256053925e-01
    z[6,2,3]  R1230     2.8972604870796204e-01
    z[6,2,3]  R1231     -2.9796159267425537e-01
    z[6,2,3]  R1232     -2.4730089306831360e-01
    z[6,2,3]  R1233     -3.6283436417579651e-01
    z[6,2,3]  R1234     -6.5098208189010620e-01
    z[6,2,3]  R1235     -6.8950426578521729e-01
    z[6,2,3]  R1236     -2.6326560974121094e-01
    z[6,2,3]  R1237     -2.6847904920578003e-01
    z[6,2,3]  R1238     -1.8104347586631775e-01
    z[6,2,3]  R1239     2.9219800233840942e-01
    z[6,2,3]  R1240     5.3422415256500244e-01
    z[6,2,3]  R1241     9.3962311744689941e-02
    z[6,2,3]  R1242     -3.1924274563789368e-01
    z[6,2,3]  R1243     -6.8487578630447388e-01
    z[6,2,3]  R1244     -1.2396093457937241e-01
    z[6,2,3]  R1245     1.1860295385122299e-01
    z[6,2,3]  R1246     -3.6851714830845594e-03
    z[6,2,3]  R1247     3.0113914608955383e-01
    z[6,2,3]  R1248     2.2926524281501770e-01
    z[6,2,3]  R1249     2.7679237723350525e-01
    z[6,2,3]  R1250     -5.6929498910903931e-01
    z[6,2,3]  R1251     -5.3526127338409424e-01
    z[6,2,3]  R1252     -1.1237671226263046e-01
    z[6,2,3]  R1253     -9.2583127319812775e-02
    z[6,2,3]  R1254     3.4817929845303297e-03
    z[6,2,3]  R1255     5.8322656899690628e-02
    z[6,2,3]  R1256     1.2655712664127350e-01
    z[6,2,3]  R1257     -7.5186669826507568e-02
    z[6,2,3]  R1258     -2.6910807937383652e-02
    z[6,2,3]  R1259     9.5883026719093323e-02
    z[6,2,3]  R1260     2.2942881286144257e-01
    z[6,2,3]  R1261     1.6687752306461334e-01
    z[6,2,3]  R1262     1.9492086768150330e-01
    z[6,2,3]  R1263     8.3154529333114624e-02
    z[6,2,3]  R1264     1.1766187101602554e-01
    z[6,2,3]  R1265     1.5138009190559387e-01
    z[6,2,3]  R1266     3.8418102264404297e-01
    z[6,2,3]  R1267     -3.4220034722238779e-03
    z[6,2,3]  R1268     -3.3298607915639877e-02
    z[6,2,3]  R1269     0.188424214720726
    z[6,2,3]  R1270     -1.5593400597572327e-01
    z[6,2,3]  R1271     -5.7853475213050842e-02
    z[6,2,3]  R1272     -5.2110069990158081e-01
    z[6,2,3]  R1273     -0.59122234582901
    z[6,2,3]  R1274     -5.0959432125091553e-01
    z[6,2,3]  R1275     -3.4905630350112915e-01
    z[6,2,3]  R1276     -4.1432005167007446e-01
    z[6,2,3]  R1277     -3.6713162064552307e-01
    z[6,2,3]  R1278     4.4533109664916992e-01
    z[6,2,3]  R1279     5.5941206216812134e-01
    z[6,2,3]  R1280     3.9711400866508484e-01
    z[6,2,3]  R1281     0.643405556678772
    z[6,2,3]  R1282     -3.2677242159843445e-01
    z[6,2,3]  R1283     -7.3861151933670044e-01
    z[6,2,3]  R1284     -5.7146298885345459e-01
    z[6,2,3]  R1285     1.2318743765354156e-01
    z[6,2,3]  R1286     -5.0712424516677856e-01
    z[6,2,3]  R1287     -1.5272945165634155e-01
    z[6,2,3]  R1288     -6.1037933826446533e-01
    z[6,2,3]  R1289     2.3904601112008095e-02
    z[6,2,3]  R1290     5.0548028945922852e-01
    z[6,2,3]  R1291     0.298697829246521
    z[6,2,3]  R1292     -7.8724640607833862e-01
    z[6,2,3]  R1293     -5.3819864988327026e-02
    z[6,2,3]  R1294     -7.6515994966030121e-02
    z[6,2,3]  R1295     1.6152633726596832e-01
    z[6,2,3]  R1296     7.2003252804279327e-02
    z[6,2,3]  R1297     7.9220914840698242e-01
    z[6,2,3]  R1298     5.0273102521896362e-01
    z[6,2,3]  R1299     6.5140515565872192e-01
    z[6,2,3]  R1300     5.3595691919326782e-01
    z[6,2,3]  R1301     0.577110767364502
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1186     -1
    z[6,2,4]  R1187     1
    z[6,2,4]  R1192     7.3707611300051212e-03
    z[6,2,4]  R1193     -1.1025711894035339e-01
    z[6,2,4]  R1194     2.2705543041229248e-01
    z[6,2,4]  R1195     1.8147720396518707e-01
    z[6,2,4]  R1196     3.1352239847183228e-01
    z[6,2,4]  R1197     3.4658116102218628e-01
    z[6,2,4]  R1198     -2.7731582522392273e-01
    z[6,2,4]  R1199     2.6809543371200562e-01
    z[6,2,4]  R1200     -1.9075492024421692e-01
    z[6,2,4]  R1201     -5.3753042221069336e-01
    z[6,2,4]  R1202     9.7786642611026764e-02
    z[6,2,4]  R1203     2.6051837205886841e-01
    z[6,2,4]  R1204     -4.0340710431337357e-02
    z[6,2,4]  R1205     -2.0097592473030090e-01
    z[6,2,4]  R1206     2.7689328417181969e-02
    z[6,2,4]  R1207     2.0092625170946121e-02
    z[6,2,4]  R1208     -1.9369050860404968e-01
    z[6,2,4]  R1209     0.0772441104054451
    z[6,2,4]  R1210     -6.6140934824943542e-02
    z[6,2,4]  R1211     2.9915568232536316e-01
    z[6,2,4]  R1212     1.8556652963161469e-01
    z[6,2,4]  R1213     -1.8377484381198883e-01
    z[6,2,4]  R1214     -4.2894887924194336e-01
    z[6,2,4]  R1215     6.9989293813705444e-02
    z[6,2,4]  R1216     2.6184371113777161e-01
    z[6,2,4]  R1217     3.8881441950798035e-01
    z[6,2,4]  R1218     -2.6986005902290344e-01
    z[6,2,4]  R1219     0.478142648935318
    z[6,2,4]  R1220     3.4068933129310608e-01
    z[6,2,4]  R1221     -5.9474412351846695e-02
    z[6,2,4]  R1222     -2.1574285626411438e-01
    z[6,2,4]  R1223     -2.8994113206863403e-01
    z[6,2,4]  R1224     -1.7099156975746155e-01
    z[6,2,4]  R1225     4.3007937073707581e-01
    z[6,2,4]  R1226     -1.8034437298774719e-01
    z[6,2,4]  R1227     3.6082316190004349e-02
    z[6,2,4]  R1228     1.0241910815238953e-01
    z[6,2,4]  R1229     -2.6553717255592346e-01
    z[6,2,4]  R1230     8.7884448468685150e-02
    z[6,2,4]  R1231     3.7979838252067566e-01
    z[6,2,4]  R1232     1.2877424061298370e-01
    z[6,2,4]  R1233     -2.3375539481639862e-01
    z[6,2,4]  R1234     -3.0089142918586731e-01
    z[6,2,4]  R1235     -2.5148290395736694e-01
    z[6,2,4]  R1236     8.1425786018371582e-02
    z[6,2,4]  R1237     5.4870493710041046e-02
    z[6,2,4]  R1238     2.2733654081821442e-01
    z[6,2,4]  R1239     9.5197439193725586e-02
    z[6,2,4]  R1240     -8.6993388831615448e-02
    z[6,2,4]  R1241     -4.7589138150215149e-02
    z[6,2,4]  R1242     -2.9893046244978905e-02
    z[6,2,4]  R1243     -1.7614772915840149e-01
    z[6,2,4]  R1244     -8.7283954024314880e-02
    z[6,2,4]  R1245     2.7306738495826721e-01
    z[6,2,4]  R1246     2.1143786609172821e-01
    z[6,2,4]  R1247     7.3112696409225464e-01
    z[6,2,4]  R1248     1.8248160183429718e-01
    z[6,2,4]  R1249     -5.6155747175216675e-01
    z[6,2,4]  R1250     -5.0185203552246094e-01
    z[6,2,4]  R1251     -3.0351039767265320e-01
    z[6,2,4]  R1252     -2.5894564390182495e-01
    z[6,2,4]  R1253     -2.9697573184967041e-01
    z[6,2,4]  R1254     -1.2680433690547943e-01
    z[6,2,4]  R1255     2.6569423079490662e-01
    z[6,2,4]  R1256     0.0797264575958252
    z[6,2,4]  R1257     -9.9610462784767151e-02
    z[6,2,4]  R1258     -2.4736022949218750e-01
    z[6,2,4]  R1259     7.5029850006103516e-02
    z[6,2,4]  R1260     -1.2354150414466858e-02
    z[6,2,4]  R1261     7.8336149454116821e-02
    z[6,2,4]  R1262     1.5492191910743713e-01
    z[6,2,4]  R1263     0.0875663235783577
    z[6,2,4]  R1264     2.2947868704795837e-01
    z[6,2,4]  R1265     2.0054118335247040e-01
    z[6,2,4]  R1266     3.2300212979316711e-01
    z[6,2,4]  R1267     3.6831492185592651e-01
    z[6,2,4]  R1268     3.1155723333358765e-01
    z[6,2,4]  R1269     4.0080478787422180e-01
    z[6,2,4]  R1270     3.9789858460426331e-01
    z[6,2,4]  R1271     5.3485298156738281e-01
    z[6,2,4]  R1272     2.0066809654235840e-01
    z[6,2,4]  R1273     -1.9148169457912445e-01
    z[6,2,4]  R1274     -4.1219338774681091e-01
    z[6,2,4]  R1275     -5.5085223913192749e-01
    z[6,2,4]  R1276     -4.9488613009452820e-01
    z[6,2,4]  R1277     -7.1058726310729980e-01
    z[6,2,4]  R1278     1.6640616953372955e-01
    z[6,2,4]  R1279     3.5721543245017529e-03
    z[6,2,4]  R1280     -4.6340253949165344e-01
    z[6,2,4]  R1281     -2.2988986968994141e-01
    z[6,2,4]  R1282     -3.2883152365684509e-01
    z[6,2,4]  R1283     4.7746646404266357e-01
    z[6,2,4]  R1284     -1.1411070078611374e-01
    z[6,2,4]  R1285     -4.4207006692886353e-01
    z[6,2,4]  R1286     4.8652318120002747e-01
    z[6,2,4]  R1287     -8.9223784208297729e-01
    z[6,2,4]  R1288     -4.0364375710487366e-01
    z[6,2,4]  R1289     -4.2736896872520447e-01
    z[6,2,4]  R1290     -1.2966082990169525e-01
    z[6,2,4]  R1291     -0.33858522772789
    z[6,2,4]  R1292     -2.7010414004325867e-01
    z[6,2,4]  R1293     -9.6203640103340149e-02
    z[6,2,4]  R1294     -8.7878651916980743e-02
    z[6,2,4]  R1295     -4.3254595994949341e-01
    z[6,2,4]  R1296     -1.5487727522850037e-01
    z[6,2,4]  R1297     3.8389221299439669e-03
    z[6,2,4]  R1298     -5.9812910854816437e-02
    z[6,2,4]  R1299     -2.5321865081787109e-01
    z[6,2,4]  R1300     -2.3832413554191589e-01
    z[6,2,4]  R1301     -4.2883336544036865e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1188     -1
    z[6,2,5]  R1189     1
    z[6,2,5]  R1192     2.3018307983875275e-01
    z[6,2,5]  R1193     1.7263543605804443e-01
    z[6,2,5]  R1194     5.5181562900543213e-01
    z[6,2,5]  R1195     3.4368079900741577e-01
    z[6,2,5]  R1196     7.0261436700820923e-01
    z[6,2,5]  R1197     4.7340282797813416e-01
    z[6,2,5]  R1198     -2.5899496674537659e-01
    z[6,2,5]  R1199     5.5541670322418213e-01
    z[6,2,5]  R1200     4.8063647747039795e-01
    z[6,2,5]  R1201     3.3625525236129761e-01
    z[6,2,5]  R1202     1.1956129968166351e-01
    z[6,2,5]  R1203     -3.9061307907104492e-02
    z[6,2,5]  R1204     -2.4524421989917755e-01
    z[6,2,5]  R1205     -1.1231366544961929e-01
    z[6,2,5]  R1206     1.6097915172576904e-01
    z[6,2,5]  R1207     -8.4550447762012482e-02
    z[6,2,5]  R1208     -6.6976338624954224e-02
    z[6,2,5]  R1209     -1.4751136302947998e-01
    z[6,2,5]  R1210     2.2243642807006836e-01
    z[6,2,5]  R1211     -2.1594022214412689e-01
    z[6,2,5]  R1212     9.0554483234882355e-02
    z[6,2,5]  R1213     3.4834283590316772e-01
    z[6,2,5]  R1214     4.0248975157737732e-02
    z[6,2,5]  R1215     -1.4654375612735748e-02
    z[6,2,5]  R1216     1.6400316357612610e-01
    z[6,2,5]  R1217     -2.3947756737470627e-02
    z[6,2,5]  R1218     6.5748989582061768e-02
    z[6,2,5]  R1219     5.3899574279785156e-01
    z[6,2,5]  R1220     1.7916370928287506e-01
    z[6,2,5]  R1221     7.7944636344909668e-01
    z[6,2,5]  R1222     3.2812169194221497e-01
    z[6,2,5]  R1223     -2.5396534800529480e-01
    z[6,2,5]  R1224     -1.5706744790077209e-01
    z[6,2,5]  R1225     -7.3487579822540283e-02
    z[6,2,5]  R1226     3.1989347189664841e-02
    z[6,2,5]  R1227     -2.9093673825263977e-01
    z[6,2,5]  R1228     -1.1443016678094864e-01
    z[6,2,5]  R1229     -4.5611268281936646e-01
    z[6,2,5]  R1230     -3.9596292376518250e-01
    z[6,2,5]  R1231     3.6357650160789490e-01
    z[6,2,5]  R1232     -2.4460119009017944e-01
    z[6,2,5]  R1233     -2.2914563119411469e-01
    z[6,2,5]  R1234     -1.7768631875514984e-01
    z[6,2,5]  R1235     -1.5092007815837860e-01
    z[6,2,5]  R1236     4.6170303225517273e-01
    z[6,2,5]  R1237     1.8440628051757812e-01
    z[6,2,5]  R1238     2.1487553417682648e-01
    z[6,2,5]  R1239     1.4064885675907135e-01
    z[6,2,5]  R1240     7.8019447624683380e-02
    z[6,2,5]  R1241     -9.2405569553375244e-01
    z[6,2,5]  R1242     1.0758799314498901e-01
    z[6,2,5]  R1243     2.9926860332489014e-01
    z[6,2,5]  R1244     -5.7398641109466553e-01
    z[6,2,5]  R1245     -7.5456231832504272e-01
    z[6,2,5]  R1246     -8.5650849342346191e-01
    z[6,2,5]  R1247     -4.2700063437223434e-02
    z[6,2,5]  R1248     -1.5010915696620941e-01
    z[6,2,5]  R1249     3.0066564679145813e-01
    z[6,2,5]  R1250     -5.5725187063217163e-01
    z[6,2,5]  R1251     -6.9269603490829468e-01
    z[6,2,5]  R1252     -3.0977943539619446e-01
    z[6,2,5]  R1253     -2.3032417893409729e-01
    z[6,2,5]  R1254     -3.0635091662406921e-01
    z[6,2,5]  R1255     -2.0247609913349152e-01
    z[6,2,5]  R1256     -4.3803164362907410e-01
    z[6,2,5]  R1257     2.7999192476272583e-01
    z[6,2,5]  R1258     -3.2522909343242645e-02
    z[6,2,5]  R1259     -5.5692322552204132e-02
    z[6,2,5]  R1260     -2.0731480792164803e-02
    z[6,2,5]  R1261     -2.1578426659107208e-01
    z[6,2,5]  R1262     3.4609884023666382e-01
    z[6,2,5]  R1263     4.6551403403282166e-01
    z[6,2,5]  R1264     6.5915763378143311e-01
    z[6,2,5]  R1265     3.9460220932960510e-01
    z[6,2,5]  R1266     0.192719966173172
    z[6,2,5]  R1267     5.6872242689132690e-01
    z[6,2,5]  R1268     4.4117224216461182e-01
    z[6,2,5]  R1269     2.8110796213150024e-01
    z[6,2,5]  R1270     1.1208473145961761e-01
    z[6,2,5]  R1271     2.7155107259750366e-01
    z[6,2,5]  R1272     -4.3861803412437439e-01
    z[6,2,5]  R1273     -6.7537024617195129e-02
    z[6,2,5]  R1274     1.7103704810142517e-01
    z[6,2,5]  R1275     -2.1028815209865570e-01
    z[6,2,5]  R1276     -2.4964958429336548e-01
    z[6,2,5]  R1277     -4.5664468407630920e-01
    z[6,2,5]  R1278     -2.9148340225219727e-01
    z[6,2,5]  R1279     -3.8634309172630310e-01
    z[6,2,5]  R1280     -3.6803993582725525e-01
    z[6,2,5]  R1281     -1.1284297704696655e-01
    z[6,2,5]  R1282     -5.3353202342987061e-01
    z[6,2,5]  R1283     1.7176094651222229e-01
    z[6,2,5]  R1284     4.9098852276802063e-01
    z[6,2,5]  R1285     -7.4825161695480347e-01
    z[6,2,5]  R1286     -1.3256806135177612e-01
    z[6,2,5]  R1287     1.5758083760738373e-01
    z[6,2,5]  R1288     -1.8381103873252869e-01
    z[6,2,5]  R1289     1.5108172781765461e-02
    z[6,2,5]  R1290     1.3056656718254089e-01
    z[6,2,5]  R1291     0.481060653924942
    z[6,2,5]  R1292     -9.0091437101364136e-02
    z[6,2,5]  R1293     -3.0887165665626526e-01
    z[6,2,5]  R1294     -9.2239004373550415e-01
    z[6,2,5]  R1295     -7.5115984678268433e-01
    z[6,2,5]  R1296     1.7373837530612946e-01
    z[6,2,5]  R1297     -2.7775179594755173e-02
    z[6,2,5]  R1298     -1.8732881546020508e-01
    z[6,2,5]  R1299     -1.5532526373863220e-01
    z[6,2,5]  R1300     -4.3492570519447327e-01
    z[6,2,5]  R1301     3.4181350469589233e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1190     -1
    z[6,2,6]  R1191     1
    z[6,2,6]  R1192     -4.0954638272523880e-02
    z[6,2,6]  R1193     2.1268339827656746e-02
    z[6,2,6]  R1194     5.2315339446067810e-02
    z[6,2,6]  R1195     1.3736955821514130e-01
    z[6,2,6]  R1196     8.0335631966590881e-02
    z[6,2,6]  R1197     6.7857488989830017e-02
    z[6,2,6]  R1198     -4.8399096727371216e-01
    z[6,2,6]  R1199     -2.2590938210487366e-01
    z[6,2,6]  R1200     -4.9066364765167236e-01
    z[6,2,6]  R1201     -3.8394466042518616e-01
    z[6,2,6]  R1202     7.4578978121280670e-02
    z[6,2,6]  R1203     -1.4473941922187805e-01
    z[6,2,6]  R1204     2.3746220767498016e-01
    z[6,2,6]  R1205     3.3301338553428650e-01
    z[6,2,6]  R1206     -2.6124054193496704e-01
    z[6,2,6]  R1207     1.8263176083564758e-01
    z[6,2,6]  R1208     2.8792208433151245e-01
    z[6,2,6]  R1209     -2.5502455234527588e-01
    z[6,2,6]  R1210     -2.1545359492301941e-01
    z[6,2,6]  R1211     1.5662631392478943e-01
    z[6,2,6]  R1212     2.4414452910423279e-01
    z[6,2,6]  R1213     2.9341778159141541e-01
    z[6,2,6]  R1214     5.1917475461959839e-01
    z[6,2,6]  R1215     2.1874819695949554e-01
    z[6,2,6]  R1216     3.8928383588790894e-01
    z[6,2,6]  R1217     1.6137449443340302e-01
    z[6,2,6]  R1218     -4.5322526246309280e-02
    z[6,2,6]  R1219     -5.1023606210947037e-02
    z[6,2,6]  R1220     2.8241056948900223e-02
    z[6,2,6]  R1221     1.1728116311132908e-02
    z[6,2,6]  R1222     -2.7198362350463867e-01
    z[6,2,6]  R1223     5.1151126623153687e-01
    z[6,2,6]  R1224     3.8859617710113525e-01
    z[6,2,6]  R1225     -2.7948606014251709e-01
    z[6,2,6]  R1226     -3.1858119368553162e-01
    z[6,2,6]  R1227     1.7168654501438141e-01
    z[6,2,6]  R1228     -1.9448006525635719e-02
    z[6,2,6]  R1229     -0.180596262216568
    z[6,2,6]  R1230     -3.0839884281158447e-01
    z[6,2,6]  R1231     4.3326136469841003e-01
    z[6,2,6]  R1232     -2.0089246332645416e-02
    z[6,2,6]  R1233     2.4173586070537567e-01
    z[6,2,6]  R1234     -2.3494267463684082e-01
    z[6,2,6]  R1235     -1.1058136820793152e-01
    z[6,2,6]  R1236     -4.3667659163475037e-01
    z[6,2,6]  R1237     5.4727697372436523e-01
    z[6,2,6]  R1238     2.4932242929935455e-02
    z[6,2,6]  R1239     5.4051667451858521e-01
    z[6,2,6]  R1240     -1.3933502137660980e-01
    z[6,2,6]  R1241     -1.6211152076721191e-01
    z[6,2,6]  R1242     5.6706565618515015e-01
    z[6,2,6]  R1243     3.9679959416389465e-02
    z[6,2,6]  R1244     -2.1805323660373688e-01
    z[6,2,6]  R1245     2.0046980679035187e-01
    z[6,2,6]  R1246     4.9520316533744335e-03
    z[6,2,6]  R1247     -3.3127307891845703e-01
    z[6,2,6]  R1248     7.9868882894515991e-01
    z[6,2,6]  R1249     1.1968600749969482e-01
    z[6,2,6]  R1250     1.0809897631406784e-01
    z[6,2,6]  R1251     -1.2872619926929474e-01
    z[6,2,6]  R1252     -3.6359116435050964e-01
    z[6,2,6]  R1253     4.8671197891235352e-01
    z[6,2,6]  R1254     1.2976335361599922e-02
    z[6,2,6]  R1255     1.9841415632981807e-04
    z[6,2,6]  R1256     2.5747016072273254e-01
    z[6,2,6]  R1257     -4.0895272046327591e-02
    z[6,2,6]  R1258     4.0123319625854492e-01
    z[6,2,6]  R1259     0.0415741428732872
    z[6,2,6]  R1260     -4.4453600049018860e-01
    z[6,2,6]  R1261     -4.2160528898239136e-01
    z[6,2,6]  R1262     -8.6947746574878693e-02
    z[6,2,6]  R1263     2.4069288372993469e-01
    z[6,2,6]  R1264     2.6291970163583755e-02
    z[6,2,6]  R1265     2.4520504474639893e-01
    z[6,2,6]  R1266     2.1488258242607117e-01
    z[6,2,6]  R1267     1.6737145185470581e-01
    z[6,2,6]  R1268     3.9287796616554260e-01
    z[6,2,6]  R1269     3.1707757711410522e-01
    z[6,2,6]  R1270     -1.3823526911437511e-02
    z[6,2,6]  R1271     -1.9499093294143677e-01
    z[6,2,6]  R1272     3.3367431163787842e-01
    z[6,2,6]  R1273     -9.4794243574142456e-02
    z[6,2,6]  R1274     3.8932305574417114e-01
    z[6,2,6]  R1275     -4.3811149895191193e-02
    z[6,2,6]  R1276     2.0110045373439789e-01
    z[6,2,6]  R1277     -8.5356742143630981e-02
    z[6,2,6]  R1278     -3.1291925907135010e-01
    z[6,2,6]  R1279     -1.1640454828739166e-01
    z[6,2,6]  R1280     6.2806069850921631e-02
    z[6,2,6]  R1281     -1.5487149357795715e-01
    z[6,2,6]  R1282     -2.8832051157951355e-01
    z[6,2,6]  R1283     1.5724253654479980e-01
    z[6,2,6]  R1284     -3.9755105972290039e-01
    z[6,2,6]  R1285     -1.4447268843650818e-01
    z[6,2,6]  R1286     -0.627393364906311
    z[6,2,6]  R1287     9.4787724316120148e-02
    z[6,2,6]  R1288     -0.618626058101654
    z[6,2,6]  R1289     -2.2545768320560455e-01
    z[6,2,6]  R1290     -1.1636500060558319e-01
    z[6,2,6]  R1291     7.9149333760142326e-03
    z[6,2,6]  R1292     6.7283022217452526e-03
    z[6,2,6]  R1293     -3.9602261781692505e-01
    z[6,2,6]  R1294     -3.3947536349296570e-01
    z[6,2,6]  R1295     2.0234017074108124e-01
    z[6,2,6]  R1296     -2.2302420809864998e-02
    z[6,2,6]  R1297     -1.0750397294759750e-01
    z[6,2,6]  R1298     3.0643166974186897e-02
    z[6,2,6]  R1299     1.7943707108497620e-01
    z[6,2,6]  R1300     -2.0033207535743713e-01
    z[6,2,6]  R1301     4.6682354062795639e-02
    z[2,7,0]  R20       -1
    z[2,7,0]  R65       1
    z[2,7,0]  R1302     -1
    z[2,7,0]  R1303     1
    z[2,7,0]  R1316     -1.4782412350177765e-01
    z[2,7,0]  R1317     -2.7121052145957947e-01
    z[2,7,0]  R1318     -4.2609363794326782e-01
    z[2,7,0]  R1319     8.9835673570632935e-02
    z[2,7,0]  R1320     1.5872716903686523e-01
    z[2,7,0]  R1321     -4.2676275968551636e-01
    z[2,7,0]  R1322     -4.4167912006378174e-01
    z[2,7,0]  R1323     -4.8775526881217957e-01
    z[2,7,0]  R1324     -4.5682573318481445e-01
    z[2,7,0]  R1325     -1.1885754019021988e-01
    z[2,7,0]  R1326     3.8897725939750671e-01
    z[2,7,0]  R1327     3.5454452037811279e-01
    z[2,7,0]  R1328     2.8881320357322693e-01
    z[2,7,0]  R1329     4.6142455935478210e-01
    z[2,7,0]  R1330     5.3530693054199219e-01
    z[2,7,0]  R1331     3.7302318215370178e-01
    z[2,7,0]  R1332     4.8588916659355164e-01
    z[2,7,0]  R1333     5.7735973596572876e-01
    z[2,7,0]  R1334     5.8803540468215942e-01
    z[2,7,0]  R1335     5.1394337415695190e-01
    z[2,7,0]  R1336     4.3111103773117065e-01
    z[2,7,0]  R1337     3.4580138325691223e-01
    z[2,7,0]  R1338     0.584464430809021
    z[2,7,0]  R1339     0.696518063545227
    z[2,7,0]  R1340     6.6535425186157227e-01
    z[2,7,0]  R1341     2.6260477304458618e-01
    z[2,7,0]  R1342     3.3323770761489868e-01
    z[2,7,0]  R1343     2.3147930204868317e-01
    z[2,7,0]  R1344     5.5249071121215820e-01
    z[2,7,0]  R1345     -2.8479587286710739e-02
    z[2,7,0]  R1346     -2.8795897960662842e-01
    z[2,7,0]  R1347     1.7002350091934204e-01
    z[2,7,0]  R1348     3.7074264883995056e-01
    z[2,7,0]  R1349     4.0712225437164307e-01
    z[2,7,0]  R1350     2.7213799953460693e-01
    z[2,7,0]  R1351     2.5323492288589478e-01
    z[2,7,0]  R1352     1.2948262691497803e-01
    z[2,7,0]  R1353     6.1186432838439941e-01
    z[2,7,0]  R1354     6.2839525938034058e-01
    z[2,7,0]  R1355     5.9266000986099243e-01
    z[2,7,0]  R1356     -2.9768115282058716e-01
    z[2,7,0]  R1357     7.9456394910812378e-01
    z[2,7,0]  R1358     1.2260476499795914e-01
    z[2,7,0]  R1359     1.8940119445323944e-01
    z[2,7,0]  R1360     8.9682662487030029e-01
    z[2,7,0]  R1361     1.5533445775508881e-01
    z[2,7,0]  R1362     2.3656730353832245e-01
    z[2,7,0]  R1363     1.4052592217922211e-01
    z[2,7,0]  R1364     1.9808086752891541e-01
    z[2,7,0]  R1365     -2.1435850858688354e-01
    z[2,7,0]  R1366     -5.5729341506958008e-01
    z[2,7,0]  R1367     -0.570170521736145
    z[2,7,0]  R1368     -0.519062876701355
    z[2,7,0]  R1369     -1.5749590098857880e-01
    z[2,7,0]  R1370     -2.7505412697792053e-01
    z[2,7,0]  R1371     -3.7525451183319092e-01
    z[2,7,0]  R1372     2.3901455104351044e-02
    z[2,7,0]  R1373     -2.5289878249168396e-01
    z[2,7,0]  R1374     4.0116536617279053e-01
    z[2,7,0]  R1375     -1.9124847650527954e-01
    z[2,7,0]  R1376     -5.3013980388641357e-01
    z[2,7,0]  R1377     7.6019114255905151e-01
    z[2,7,0]  R1378     -2.5712382793426514e-01
    z[2,7,0]  R1379     -3.3564478158950806e-01
    z[2,7,0]  R1380     -0.532228410243988
    z[2,7,0]  R1381     7.5140100717544556e-01
    z[2,7,0]  R1382     -6.1134433746337891e-01
    z[2,7,0]  R1383     -7.5698435306549072e-01
    z[2,7,0]  R1384     -5.2028256654739380e-01
    z[2,7,0]  R1385     1.3251268863677979e-01
    z[2,7,0]  R1386     6.0195124149322510e-01
    z[2,7,0]  R1387     5.9818547964096069e-01
    z[2,7,0]  R1388     6.7245703935623169e-01
    z[2,7,0]  R1389     4.9734145402908325e-01
    z[2,7,0]  R1390     0.382784366607666
    z[2,7,0]  R1391     5.3919726610183716e-01
    z[2,7,0]  R1392     0.352083295583725
    z[2,7,0]  R1393     1.0322692990303040e-01
    z[2,7,0]  R1394     -3.5776447504758835e-02
    z[2,7,0]  R1395     -6.2972344458103180e-02
    z[2,7,0]  R1396     3.9761614799499512e-01
    z[2,7,0]  R1397     3.1109130382537842e-01
    z[2,7,0]  R1398     6.0046070814132690e-01
    z[2,7,0]  R1399     6.0410302132368088e-02
    z[2,7,0]  R1400     -4.0367566980421543e-03
    z[2,7,0]  R1401     3.0294919013977051e-01
    z[2,7,0]  R1402     5.7300585508346558e-01
    z[2,7,0]  R1403     1.5232123434543610e-01
    z[2,7,0]  R1404     -5.1245975494384766e-01
    z[2,7,0]  R1405     7.1005530655384064e-02
    z[2,7,0]  R1406     -1.8540312349796295e-01
    z[2,7,0]  R1407     -6.8541193008422852e-01
    z[2,7,0]  R1408     -2.7038168907165527e-01
    z[2,7,0]  R1409     -0.452766478061676
    z[2,7,0]  R1410     -4.6305142343044281e-02
    z[2,7,0]  R1411     -7.7871638350188732e-03
    z[2,7,0]  R1412     7.7178925275802612e-02
    z[2,7,0]  R1413     -2.6318386197090149e-01
    z[2,7,0]  R1414     2.7791216969490051e-01
    z[2,7,0]  R1415     0.000984802725724876
    z[2,7,0]  R1416     2.8282368183135986e-01
    z[2,7,0]  R1417     -2.5316581130027771e-01
    z[2,7,0]  R1418     1.2265031225979328e-02
    z[2,7,0]  R1419     -4.1162014007568359e-01
    z[2,7,0]  R1420     -2.6204910874366760e-01
    z[2,7,0]  R1421     -6.1397153139114380e-01
    z[2,7,0]  R1422     -1.5431550145149231e-01
    z[2,7,0]  R1423     2.1453516185283661e-01
    z[2,7,0]  R1424     1.5545056760311127e-01
    z[2,7,0]  R1425     -5.9662234783172607e-01
    z[2,7,0]  R1426     -1.2338148802518845e-01
    z[2,7,0]  R1427     -1.2407746165990829e-01
    z[2,7,0]  R1428     -3.0643790960311890e-01
    z[2,7,0]  R1429     2.3313535749912262e-01
    z[2,7,0]  R1430     5.5375963449478149e-01
    z[2,7,0]  R1431     -1.8920011818408966e-01
    z[2,7,0]  R1432     -5.3123313188552856e-01
    z[2,7,0]  R1433     5.9123420715332031e-01
    z[2,7,0]  R1434     5.3236150741577148e-01
    z[2,7,0]  R1435     3.4476128220558167e-01
    z[2,7,1]  R21       -1
    z[2,7,1]  R66       1
    z[2,7,1]  R1304     -1
    z[2,7,1]  R1305     1
    z[2,7,1]  R1316     -0.450273722410202
    z[2,7,1]  R1317     -3.6599117517471313e-01
    z[2,7,1]  R1318     -1.7743575572967529e-01
    z[2,7,1]  R1319     -5.0480651855468750e-01
    z[2,7,1]  R1320     -6.7000722885131836e-01
    z[2,7,1]  R1321     -8.3980625867843628e-01
    z[2,7,1]  R1322     -7.3805534839630127e-01
    z[2,7,1]  R1323     -6.8874347209930420e-01
    z[2,7,1]  R1324     -0.69554603099823
    z[2,7,1]  R1325     -8.4459286928176880e-01
    z[2,7,1]  R1326     9.0619117021560669e-02
    z[2,7,1]  R1327     3.5812300629913807e-03
    z[2,7,1]  R1328     1.0858666896820068e-01
    z[2,7,1]  R1329     3.2087564468383789e-01
    z[2,7,1]  R1330     3.6810154560953379e-03
    z[2,7,1]  R1331     -2.2005392611026764e-01
    z[2,7,1]  R1332     4.5547958463430405e-02
    z[2,7,1]  R1333     1.2174101918935776e-01
    z[2,7,1]  R1334     -7.4106492102146149e-02
    z[2,7,1]  R1335     4.8135435581207275e-01
    z[2,7,1]  R1336     3.6078253388404846e-01
    z[2,7,1]  R1337     5.2687269449234009e-01
    z[2,7,1]  R1338     -1.9589845836162567e-01
    z[2,7,1]  R1339     -1.6955339908599854e-01
    z[2,7,1]  R1340     -1.4765505492687225e-01
    z[2,7,1]  R1341     2.3742891848087311e-01
    z[2,7,1]  R1342     6.7550569772720337e-01
    z[2,7,1]  R1343     6.8556523323059082e-01
    z[2,7,1]  R1344     3.7840464711189270e-01
    z[2,7,1]  R1345     7.0039027929306030e-01
    z[2,7,1]  R1346     3.6631658673286438e-01
    z[2,7,1]  R1347     -9.6432730555534363e-02
    z[2,7,1]  R1348     -1.7140366137027740e-01
    z[2,7,1]  R1349     -1.8234404921531677e-01
    z[2,7,1]  R1350     -1.4444039762020111e-01
    z[2,7,1]  R1351     -5.5179785937070847e-02
    z[2,7,1]  R1352     -7.5423799455165863e-02
    z[2,7,1]  R1353     4.8955509066581726e-01
    z[2,7,1]  R1354     5.2413874864578247e-01
    z[2,7,1]  R1355     4.3968778848648071e-01
    z[2,7,1]  R1356     2.2655875980854034e-01
    z[2,7,1]  R1357     -2.6407933235168457e-01
    z[2,7,1]  R1358     -4.6501386910676956e-02
    z[2,7,1]  R1359     1.6103906929492950e-01
    z[2,7,1]  R1360     3.6249703168869019e-01
    z[2,7,1]  R1361     5.4928815364837646e-01
    z[2,7,1]  R1362     7.9501521587371826e-01
    z[2,7,1]  R1363     0.604786217212677
    z[2,7,1]  R1364     4.5172744989395142e-01
    z[2,7,1]  R1365     4.8909822106361389e-01
    z[2,7,1]  R1366     -7.3747581243515015e-01
    z[2,7,1]  R1367     -7.4708157777786255e-01
    z[2,7,1]  R1368     -7.3020076751708984e-01
    z[2,7,1]  R1369     -9.3595254421234131e-01
    z[2,7,1]  R1370     -8.7157249450683594e-01
    z[2,7,1]  R1371     -8.0742329359054565e-01
    z[2,7,1]  R1372     -1.9723260775208473e-02
    z[2,7,1]  R1373     -8.6047857999801636e-01
    z[2,7,1]  R1374     3.9040920138359070e-01
    z[2,7,1]  R1375     -8.3041661977767944e-01
    z[2,7,1]  R1376     0.418416827917099
    z[2,7,1]  R1377     5.7618740946054459e-02
    z[2,7,1]  R1378     3.9711853861808777e-01
    z[2,7,1]  R1379     3.7892201542854309e-01
    z[2,7,1]  R1380     4.4411951303482056e-01
    z[2,7,1]  R1381     -2.7559101581573486e-01
    z[2,7,1]  R1382     4.4987294077873230e-01
    z[2,7,1]  R1383     3.6728054285049438e-01
    z[2,7,1]  R1384     0.534921407699585
    z[2,7,1]  R1385     2.6610809564590454e-01
    z[2,7,1]  R1386     1.7845438420772552e-01
    z[2,7,1]  R1387     -4.6498408913612366e-01
    z[2,7,1]  R1388     -2.5442427396774292e-01
    z[2,7,1]  R1389     -4.4862989336252213e-02
    z[2,7,1]  R1390     -1.2408622354269028e-01
    z[2,7,1]  R1391     -3.0851846933364868e-01
    z[2,7,1]  R1392     -4.3527570366859436e-01
    z[2,7,1]  R1393     3.5347703844308853e-02
    z[2,7,1]  R1394     2.0681785047054291e-01
    z[2,7,1]  R1395     9.0527945756912231e-01
    z[2,7,1]  R1396     -1.1390823125839233e-01
    z[2,7,1]  R1397     3.4702695906162262e-02
    z[2,7,1]  R1398     -2.0013208687305450e-01
    z[2,7,1]  R1399     -3.1605863571166992e-01
    z[2,7,1]  R1400     -6.7666035890579224e-01
    z[2,7,1]  R1401     3.5550642013549805e-01
    z[2,7,1]  R1402     1.4513367414474487e-01
    z[2,7,1]  R1403     -1.2593352794647217e-01
    z[2,7,1]  R1404     1.0443762689828873e-01
    z[2,7,1]  R1405     9.5946002006530762e-01
    z[2,7,1]  R1406     -6.5885370969772339e-01
    z[2,7,1]  R1407     2.4410164356231689e-01
    z[2,7,1]  R1408     2.7930954098701477e-01
    z[2,7,1]  R1409     4.5855066180229187e-01
    z[2,7,1]  R1410     9.0118712186813354e-01
    z[2,7,1]  R1411     9.7862249612808228e-01
    z[2,7,1]  R1412     0.916998565196991
    z[2,7,1]  R1413     9.1740399599075317e-01
    z[2,7,1]  R1414     -5.0423923879861832e-02
    z[2,7,1]  R1415     2.1070607006549835e-01
    z[2,7,1]  R1416     -4.6093201637268066e-01
    z[2,7,1]  R1417     -5.1532387733459473e-01
    z[2,7,1]  R1418     -5.8087170124053955e-01
    z[2,7,1]  R1419     2.6048794388771057e-01
    z[2,7,1]  R1420     1.4729660749435425e-01
    z[2,7,1]  R1421     4.6828430891036987e-01
    z[2,7,1]  R1422     9.2185807228088379e-01
    z[2,7,1]  R1423     8.7684553861618042e-01
    z[2,7,1]  R1424     9.4337785243988037e-01
    z[2,7,1]  R1425     3.8790026307106018e-01
    z[2,7,1]  R1426     0.128950834274292
    z[2,7,1]  R1427     -4.7677025198936462e-01
    z[2,7,1]  R1428     5.0981199741363525e-01
    z[2,7,1]  R1429     9.1037929058074951e-01
    z[2,7,1]  R1430     1.2420173734426498e-01
    z[2,7,1]  R1431     7.7613222599029541e-01
    z[2,7,1]  R1432     7.1518266201019287e-01
    z[2,7,1]  R1433     1.3515974581241608e-01
    z[2,7,1]  R1434     -1.9805087149143219e-01
    z[2,7,1]  R1435     -4.6662919223308563e-02
    z[2,7,2]  R22       -1
    z[2,7,2]  R67       1
    z[2,7,2]  R1306     -1
    z[2,7,2]  R1307     1
    z[2,7,2]  R1316     6.8378245830535889e-01
    z[2,7,2]  R1317     6.3701760768890381e-01
    z[2,7,2]  R1318     8.2270896434783936e-01
    z[2,7,2]  R1319     7.8873842954635620e-01
    z[2,7,2]  R1320     4.9533864855766296e-01
    z[2,7,2]  R1321     1.3021484017372131e-01
    z[2,7,2]  R1322     1.9035948812961578e-01
    z[2,7,2]  R1323     0.517758846282959
    z[2,7,2]  R1324     2.3810453712940216e-01
    z[2,7,2]  R1325     -1.1931928992271423e-01
    z[2,7,2]  R1326     -8.0693596601486206e-01
    z[2,7,2]  R1327     -7.6489633321762085e-01
    z[2,7,2]  R1328     -6.3491022586822510e-01
    z[2,7,2]  R1329     -6.3651943206787109e-01
    z[2,7,2]  R1330     -6.1497306823730469e-01
    z[2,7,2]  R1331     -5.7035428285598755e-01
    z[2,7,2]  R1332     -5.6095844507217407e-01
    z[2,7,2]  R1333     -5.2547782659530640e-01
    z[2,7,2]  R1334     -6.7329776287078857e-01
    z[2,7,2]  R1335     -3.2091107964515686e-01
    z[2,7,2]  R1336     2.6161280274391174e-01
    z[2,7,2]  R1337     4.5063313841819763e-01
    z[2,7,2]  R1338     9.8026670515537262e-02
    z[2,7,2]  R1339     -1.2122385203838348e-01
    z[2,7,2]  R1340     -1.2712979316711426e-01
    z[2,7,2]  R1341     -1.3833381235599518e-01
    z[2,7,2]  R1342     -1.5411974489688873e-01
    z[2,7,2]  R1343     -2.5532284751534462e-02
    z[2,7,2]  R1344     -1.9931019842624664e-01
    z[2,7,2]  R1345     -7.1439862251281738e-02
    z[2,7,2]  R1346     4.4743287563323975e-01
    z[2,7,2]  R1347     3.6612075567245483e-01
    z[2,7,2]  R1348     3.0734816193580627e-01
    z[2,7,2]  R1349     -9.8225146532058716e-02
    z[2,7,2]  R1350     1.1402430245652795e-03
    z[2,7,2]  R1351     2.8212782740592957e-01
    z[2,7,2]  R1352     -1.5990474820137024e-01
    z[2,7,2]  R1353     -3.8946467638015747e-01
    z[2,7,2]  R1354     1.6579274833202362e-01
    z[2,7,2]  R1355     1.4172625541687012e-01
    z[2,7,2]  R1356     3.9897614717483521e-01
    z[2,7,2]  R1357     1.8585719168186188e-01
    z[2,7,2]  R1358     5.6403100490570068e-02
    z[2,7,2]  R1359     3.4615629911422729e-01
    z[2,7,2]  R1360     -6.6663399338722229e-02
    z[2,7,2]  R1361     -1.8497291207313538e-01
    z[2,7,2]  R1362     -1.4014115929603577e-01
    z[2,7,2]  R1363     -2.6403433084487915e-01
    z[2,7,2]  R1364     -4.2821100354194641e-01
    z[2,7,2]  R1365     -0.280825138092041
    z[2,7,2]  R1366     0.298555850982666
    z[2,7,2]  R1367     1.8358130753040314e-01
    z[2,7,2]  R1368     1.9443720579147339e-01
    z[2,7,2]  R1369     1.5707209706306458e-01
    z[2,7,2]  R1370     -2.6619702577590942e-01
    z[2,7,2]  R1371     -1.0090090334415436e-01
    z[2,7,2]  R1372     -7.4030059576034546e-01
    z[2,7,2]  R1373     -1.6972111165523529e-01
    z[2,7,2]  R1374     -7.7183133363723755e-01
    z[2,7,2]  R1375     1.4229343831539154e-01
    z[2,7,2]  R1376     5.8528393507003784e-01
    z[2,7,2]  R1377     -3.7061061710119247e-02
    z[2,7,2]  R1378     8.3552157878875732e-01
    z[2,7,2]  R1379     4.7039976716041565e-01
    z[2,7,2]  R1380     3.7349972128868103e-01
    z[2,7,2]  R1381     5.8752644807100296e-02
    z[2,7,2]  R1382     2.3887164890766144e-01
    z[2,7,2]  R1383     2.6121550798416138e-01
    z[2,7,2]  R1384     3.0541107058525085e-01
    z[2,7,2]  R1385     7.8861457109451294e-01
    z[2,7,2]  R1386     -1.9163978099822998e-01
    z[2,7,2]  R1387     -5.1818495988845825e-01
    z[2,7,2]  R1388     -3.6145347356796265e-01
    z[2,7,2]  R1389     -5.7662930339574814e-02
    z[2,7,2]  R1390     -1.6415746882557869e-02
    z[2,7,2]  R1391     -7.3851391673088074e-02
    z[2,7,2]  R1392     -2.2096006572246552e-01
    z[2,7,2]  R1393     -5.3146738559007645e-02
    z[2,7,2]  R1394     -1.4740160107612610e-01
    z[2,7,2]  R1395     2.1982432901859283e-01
    z[2,7,2]  R1396     -3.8245442509651184e-01
    z[2,7,2]  R1397     -2.9966729879379272e-01
    z[2,7,2]  R1398     -3.2674607634544373e-01
    z[2,7,2]  R1399     -2.6593995094299316e-01
    z[2,7,2]  R1400     -4.1883742809295654e-01
    z[2,7,2]  R1401     -4.2928963899612427e-01
    z[2,7,2]  R1402     -4.4848346710205078e-01
    z[2,7,2]  R1403     -3.6271527409553528e-01
    z[2,7,2]  R1404     2.6568377017974854e-01
    z[2,7,2]  R1405     5.1571227610111237e-02
    z[2,7,2]  R1406     -5.2012479305267334e-01
    z[2,7,2]  R1407     0.430862158536911
    z[2,7,2]  R1408     6.4673972129821777e-01
    z[2,7,2]  R1409     5.3898984193801880e-01
    z[2,7,2]  R1410     1.5493386983871460e-01
    z[2,7,2]  R1411     1.5950405597686768e-01
    z[2,7,2]  R1412     1.4847847819328308e-01
    z[2,7,2]  R1413     1.4667649567127228e-01
    z[2,7,2]  R1414     6.8408769369125366e-01
    z[2,7,2]  R1415     5.0998938083648682e-01
    z[2,7,2]  R1416     -1.5722635388374329e-01
    z[2,7,2]  R1417     -1.3574923574924469e-01
    z[2,7,2]  R1418     -4.8064518719911575e-02
    z[2,7,2]  R1419     8.1105232238769531e-01
    z[2,7,2]  R1420     8.8950288295745850e-01
    z[2,7,2]  R1421     5.5517274141311646e-01
    z[2,7,2]  R1422     0.0680805891752243
    z[2,7,2]  R1423     1.5615177154541016e-01
    z[2,7,2]  R1424     1.3400849699974060e-01
    z[2,7,2]  R1425     5.0934523344039917e-01
    z[2,7,2]  R1426     -4.7807180881500244e-01
    z[2,7,2]  R1427     -5.9512192010879517e-01
    z[2,7,2]  R1428     4.7363206744194031e-01
    z[2,7,2]  R1429     2.0909920334815979e-01
    z[2,7,2]  R1430     5.8233773708343506e-01
    z[2,7,2]  R1431     -0.0377717949450016
    z[2,7,2]  R1432     -2.4989375472068787e-01
    z[2,7,2]  R1433     7.7504372596740723e-01
    z[2,7,2]  R1434     7.0783507823944092e-01
    z[2,7,2]  R1435     8.4468716382980347e-01
    z[2,7,3]  R23       -1
    z[2,7,3]  R68       1
    z[2,7,3]  R1308     -1
    z[2,7,3]  R1309     1
    z[2,7,3]  R1316     -1.1237671226263046e-01
    z[2,7,3]  R1317     -9.2583127319812775e-02
    z[2,7,3]  R1318     3.4817929845303297e-03
    z[2,7,3]  R1319     5.8322656899690628e-02
    z[2,7,3]  R1320     1.2655712664127350e-01
    z[2,7,3]  R1321     -7.5186669826507568e-02
    z[2,7,3]  R1322     -2.6910807937383652e-02
    z[2,7,3]  R1323     9.5883026719093323e-02
    z[2,7,3]  R1324     2.2942881286144257e-01
    z[2,7,3]  R1325     1.6687752306461334e-01
    z[2,7,3]  R1326     1.9492086768150330e-01
    z[2,7,3]  R1327     8.3154529333114624e-02
    z[2,7,3]  R1328     1.1766187101602554e-01
    z[2,7,3]  R1329     1.5138009190559387e-01
    z[2,7,3]  R1330     3.8418102264404297e-01
    z[2,7,3]  R1331     -3.4220034722238779e-03
    z[2,7,3]  R1332     -3.3298607915639877e-02
    z[2,7,3]  R1333     0.188424214720726
    z[2,7,3]  R1334     -1.5593400597572327e-01
    z[2,7,3]  R1335     -5.7853475213050842e-02
    z[2,7,3]  R1336     -5.2110069990158081e-01
    z[2,7,3]  R1337     -0.59122234582901
    z[2,7,3]  R1338     -5.0959432125091553e-01
    z[2,7,3]  R1339     -3.4905630350112915e-01
    z[2,7,3]  R1340     -4.1432005167007446e-01
    z[2,7,3]  R1341     -3.6713162064552307e-01
    z[2,7,3]  R1342     4.4533109664916992e-01
    z[2,7,3]  R1343     5.5941206216812134e-01
    z[2,7,3]  R1344     3.9711400866508484e-01
    z[2,7,3]  R1345     0.643405556678772
    z[2,7,3]  R1346     -3.2677242159843445e-01
    z[2,7,3]  R1347     -7.3861151933670044e-01
    z[2,7,3]  R1348     -5.7146298885345459e-01
    z[2,7,3]  R1349     1.2318743765354156e-01
    z[2,7,3]  R1350     -5.0712424516677856e-01
    z[2,7,3]  R1351     -1.5272945165634155e-01
    z[2,7,3]  R1352     -6.1037933826446533e-01
    z[2,7,3]  R1353     2.3904601112008095e-02
    z[2,7,3]  R1354     5.0548028945922852e-01
    z[2,7,3]  R1355     0.298697829246521
    z[2,7,3]  R1356     -7.8724640607833862e-01
    z[2,7,3]  R1357     -5.3819864988327026e-02
    z[2,7,3]  R1358     -7.6515994966030121e-02
    z[2,7,3]  R1359     1.6152633726596832e-01
    z[2,7,3]  R1360     7.2003252804279327e-02
    z[2,7,3]  R1361     7.9220914840698242e-01
    z[2,7,3]  R1362     5.0273102521896362e-01
    z[2,7,3]  R1363     6.5140515565872192e-01
    z[2,7,3]  R1364     5.3595691919326782e-01
    z[2,7,3]  R1365     0.577110767364502
    z[2,7,3]  R1366     2.1336081624031067e-01
    z[2,7,3]  R1367     7.9396776854991913e-03
    z[2,7,3]  R1368     -1.5130911953747272e-02
    z[2,7,3]  R1369     -8.4489017724990845e-02
    z[2,7,3]  R1370     1.9082543253898621e-01
    z[2,7,3]  R1371     0.310305118560791
    z[2,7,3]  R1372     1.1281483806669712e-02
    z[2,7,3]  R1373     2.4558851122856140e-01
    z[2,7,3]  R1374     2.4062691628932953e-01
    z[2,7,3]  R1375     3.6169907450675964e-01
    z[2,7,3]  R1376     -9.5866424089763314e-05
    z[2,7,3]  R1377     6.2737171538174152e-03
    z[2,7,3]  R1378     -4.9242008477449417e-02
    z[2,7,3]  R1379     -8.9440263807773590e-02
    z[2,7,3]  R1380     -1.2167779356241226e-01
    z[2,7,3]  R1381     1.7906905710697174e-01
    z[2,7,3]  R1382     1.5895548462867737e-01
    z[2,7,3]  R1383     -9.5122829079627991e-02
    z[2,7,3]  R1384     -7.8436203300952911e-02
    z[2,7,3]  R1385     6.6721066832542419e-03
    z[2,7,3]  R1386     3.1728571653366089e-01
    z[2,7,3]  R1387     -1.3364253938198090e-01
    z[2,7,3]  R1388     -4.9848143011331558e-02
    z[2,7,3]  R1389     4.1682282090187073e-01
    z[2,7,3]  R1390     6.3563042879104614e-01
    z[2,7,3]  R1391     4.5382767915725708e-01
    z[2,7,3]  R1392     6.9629192352294922e-01
    z[2,7,3]  R1393     7.9223698377609253e-01
    z[2,7,3]  R1394     3.2487702369689941e-01
    z[2,7,3]  R1395     -1.7021021246910095e-01
    z[2,7,3]  R1396     3.3239468932151794e-01
    z[2,7,3]  R1397     1.1013448238372803e-01
    z[2,7,3]  R1398     5.5118042975664139e-02
    z[2,7,3]  R1399     7.5845491886138916e-01
    z[2,7,3]  R1400     -4.6045112609863281e-01
    z[2,7,3]  R1401     1.1464538425207138e-01
    z[2,7,3]  R1402     -2.7030047774314880e-01
    z[2,7,3]  R1403     5.3859239816665649e-01
    z[2,7,3]  R1404     2.4339058995246887e-01
    z[2,7,3]  R1405     -1.8081294000148773e-01
    z[2,7,3]  R1406     -4.1440117359161377e-01
    z[2,7,3]  R1407     1.3351282104849815e-02
    z[2,7,3]  R1408     1.4195926487445831e-01
    z[2,7,3]  R1409     7.4260458350181580e-02
    z[2,7,3]  R1410     3.7941688299179077e-01
    z[2,7,3]  R1411     -0.0711718425154686
    z[2,7,3]  R1412     2.7141135931015015e-01
    z[2,7,3]  R1413     0.0403439924120903
    z[2,7,3]  R1414     -7.0779860019683838e-02
    z[2,7,3]  R1415     -1.4947031438350677e-01
    z[2,7,3]  R1416     5.7387119531631470e-01
    z[2,7,3]  R1417     -1.8258984386920929e-01
    z[2,7,3]  R1418     -5.4872053861618042e-01
    z[2,7,3]  R1419     1.2046121805906296e-01
    z[2,7,3]  R1420     1.4531119167804718e-01
    z[2,7,3]  R1421     -2.5036895275115967e-01
    z[2,7,3]  R1422     1.3941834867000580e-01
    z[2,7,3]  R1423     2.9689857363700867e-01
    z[2,7,3]  R1424     1.6956686973571777e-01
    z[2,7,3]  R1425     1.1790903657674789e-01
    z[2,7,3]  R1426     0.635644793510437
    z[2,7,3]  R1427     2.1650105714797974e-01
    z[2,7,3]  R1428     -2.8590098023414612e-01
    z[2,7,3]  R1429     5.9115849435329437e-02
    z[2,7,3]  R1430     -6.6254511475563049e-03
    z[2,7,3]  R1431     -0.457742303609848
    z[2,7,3]  R1432     1.0660663992166519e-01
    z[2,7,3]  R1433     1.0329223424196243e-01
    z[2,7,3]  R1434     2.9699310660362244e-01
    z[2,7,3]  R1435     1.2285843491554260e-01
    z[2,7,4]  R24       -1
    z[2,7,4]  R69       1
    z[2,7,4]  R1310     -1
    z[2,7,4]  R1311     1
    z[2,7,4]  R1316     -2.5894564390182495e-01
    z[2,7,4]  R1317     -2.9697573184967041e-01
    z[2,7,4]  R1318     -1.2680433690547943e-01
    z[2,7,4]  R1319     2.6569423079490662e-01
    z[2,7,4]  R1320     0.0797264575958252
    z[2,7,4]  R1321     -9.9610462784767151e-02
    z[2,7,4]  R1322     -2.4736022949218750e-01
    z[2,7,4]  R1323     7.5029850006103516e-02
    z[2,7,4]  R1324     -1.2354150414466858e-02
    z[2,7,4]  R1325     7.8336149454116821e-02
    z[2,7,4]  R1326     1.5492191910743713e-01
    z[2,7,4]  R1327     0.0875663235783577
    z[2,7,4]  R1328     2.2947868704795837e-01
    z[2,7,4]  R1329     2.0054118335247040e-01
    z[2,7,4]  R1330     3.2300212979316711e-01
    z[2,7,4]  R1331     3.6831492185592651e-01
    z[2,7,4]  R1332     3.1155723333358765e-01
    z[2,7,4]  R1333     4.0080478787422180e-01
    z[2,7,4]  R1334     3.9789858460426331e-01
    z[2,7,4]  R1335     5.3485298156738281e-01
    z[2,7,4]  R1336     2.0066809654235840e-01
    z[2,7,4]  R1337     -1.9148169457912445e-01
    z[2,7,4]  R1338     -4.1219338774681091e-01
    z[2,7,4]  R1339     -5.5085223913192749e-01
    z[2,7,4]  R1340     -4.9488613009452820e-01
    z[2,7,4]  R1341     -7.1058726310729980e-01
    z[2,7,4]  R1342     1.6640616953372955e-01
    z[2,7,4]  R1343     3.5721543245017529e-03
    z[2,7,4]  R1344     -4.6340253949165344e-01
    z[2,7,4]  R1345     -2.2988986968994141e-01
    z[2,7,4]  R1346     -3.2883152365684509e-01
    z[2,7,4]  R1347     4.7746646404266357e-01
    z[2,7,4]  R1348     -1.1411070078611374e-01
    z[2,7,4]  R1349     -4.4207006692886353e-01
    z[2,7,4]  R1350     4.8652318120002747e-01
    z[2,7,4]  R1351     -8.9223784208297729e-01
    z[2,7,4]  R1352     -4.0364375710487366e-01
    z[2,7,4]  R1353     -4.2736896872520447e-01
    z[2,7,4]  R1354     -1.2966082990169525e-01
    z[2,7,4]  R1355     -0.33858522772789
    z[2,7,4]  R1356     -2.7010414004325867e-01
    z[2,7,4]  R1357     -9.6203640103340149e-02
    z[2,7,4]  R1358     -8.7878651916980743e-02
    z[2,7,4]  R1359     -4.3254595994949341e-01
    z[2,7,4]  R1360     -1.5487727522850037e-01
    z[2,7,4]  R1361     3.8389221299439669e-03
    z[2,7,4]  R1362     -5.9812910854816437e-02
    z[2,7,4]  R1363     -2.5321865081787109e-01
    z[2,7,4]  R1364     -2.3832413554191589e-01
    z[2,7,4]  R1365     -4.2883336544036865e-01
    z[2,7,4]  R1366     5.9422351419925690e-02
    z[2,7,4]  R1367     -1.9214452803134918e-01
    z[2,7,4]  R1368     2.2768998518586159e-02
    z[2,7,4]  R1369     -1.0811345279216766e-01
    z[2,7,4]  R1370     2.8450158424675465e-03
    z[2,7,4]  R1371     -1.7688177525997162e-01
    z[2,7,4]  R1372     3.1629720330238342e-01
    z[2,7,4]  R1373     3.7627778947353363e-02
    z[2,7,4]  R1374     -1.3504016213119030e-02
    z[2,7,4]  R1375     -3.0993264913558960e-01
    z[2,7,4]  R1376     -1.5718884766101837e-01
    z[2,7,4]  R1377     5.4455578327178955e-01
    z[2,7,4]  R1378     -1.5139667689800262e-01
    z[2,7,4]  R1379     -5.4010105133056641e-01
    z[2,7,4]  R1380     -4.8380544781684875e-01
    z[2,7,4]  R1381     4.2592003941535950e-01
    z[2,7,4]  R1382     -4.6477150917053223e-01
    z[2,7,4]  R1383     1.5552908182144165e-01
    z[2,7,4]  R1384     -0.358530193567276
    z[2,7,4]  R1385     -1.1168579757213593e-01
    z[2,7,4]  R1386     5.5943781137466431e-01
    z[2,7,4]  R1387     1.8434017896652222e-01
    z[2,7,4]  R1388     3.9101520180702209e-01
    z[2,7,4]  R1389     6.2802612781524658e-01
    z[2,7,4]  R1390     5.0317895412445068e-01
    z[2,7,4]  R1391     1.2057242542505264e-01
    z[2,7,4]  R1392     2.1572346985340118e-01
    z[2,7,4]  R1393     -2.7864813804626465e-01
    z[2,7,4]  R1394     -2.0015962421894073e-01
    z[2,7,4]  R1395     -5.9578165411949158e-02
    z[2,7,4]  R1396     1.1606896668672562e-01
    z[2,7,4]  R1397     5.0491452217102051e-01
    z[2,7,4]  R1398     6.3793194293975830e-01
    z[2,7,4]  R1399     6.8251579068601131e-03
    z[2,7,4]  R1400     3.2291319966316223e-01
    z[2,7,4]  R1401     4.9339967966079712e-01
    z[2,7,4]  R1402     2.7060031890869141e-01
    z[2,7,4]  R1403     2.3952074348926544e-01
    z[2,7,4]  R1404     -6.2229067087173462e-01
    z[2,7,4]  R1405     7.8987866640090942e-02
    z[2,7,4]  R1406     -2.5162476301193237e-01
    z[2,7,4]  R1407     -1.6484941542148590e-01
    z[2,7,4]  R1408     -4.0740302205085754e-01
    z[2,7,4]  R1409     -3.8552686572074890e-01
    z[2,7,4]  R1410     4.6498816460371017e-02
    z[2,7,4]  R1411     -3.8213570951484144e-04
    z[2,7,4]  R1412     -1.7301419377326965e-01
    z[2,7,4]  R1413     -6.8801701068878174e-02
    z[2,7,4]  R1414     -3.9071694016456604e-02
    z[2,7,4]  R1415     -4.2013868689537048e-01
    z[2,7,4]  R1416     4.0225276350975037e-01
    z[2,7,4]  R1417     7.1406906843185425e-01
    z[2,7,4]  R1418     4.3973532319068909e-01
    z[2,7,4]  R1419     -7.6233841478824615e-02
    z[2,7,4]  R1420     1.1470503360033035e-01
    z[2,7,4]  R1421     7.1103684604167938e-02
    z[2,7,4]  R1422     -3.1166917085647583e-01
    z[2,7,4]  R1423     3.1659644097089767e-02
    z[2,7,4]  R1424     1.4390356838703156e-01
    z[2,7,4]  R1425     2.5604346394538879e-01
    z[2,7,4]  R1426     -1.7262098193168640e-01
    z[2,7,4]  R1427     -1.1364775896072388e-01
    z[2,7,4]  R1428     -3.3513152599334717e-01
    z[2,7,4]  R1429     1.1817936599254608e-01
    z[2,7,4]  R1430     -1.2361352145671844e-01
    z[2,7,4]  R1431     2.6135078072547913e-01
    z[2,7,4]  R1432     3.0776894092559814e-01
    z[2,7,4]  R1433     4.1240427643060684e-02
    z[2,7,4]  R1434     -1.6916111111640930e-01
    z[2,7,4]  R1435     3.8667380809783936e-01
    z[2,7,5]  R25       -1
    z[2,7,5]  R70       1
    z[2,7,5]  R1312     -1
    z[2,7,5]  R1313     1
    z[2,7,5]  R1316     -3.0977943539619446e-01
    z[2,7,5]  R1317     -2.3032417893409729e-01
    z[2,7,5]  R1318     -3.0635091662406921e-01
    z[2,7,5]  R1319     -2.0247609913349152e-01
    z[2,7,5]  R1320     -4.3803164362907410e-01
    z[2,7,5]  R1321     2.7999192476272583e-01
    z[2,7,5]  R1322     -3.2522909343242645e-02
    z[2,7,5]  R1323     -5.5692322552204132e-02
    z[2,7,5]  R1324     -2.0731480792164803e-02
    z[2,7,5]  R1325     -2.1578426659107208e-01
    z[2,7,5]  R1326     3.4609884023666382e-01
    z[2,7,5]  R1327     4.6551403403282166e-01
    z[2,7,5]  R1328     6.5915763378143311e-01
    z[2,7,5]  R1329     3.9460220932960510e-01
    z[2,7,5]  R1330     0.192719966173172
    z[2,7,5]  R1331     5.6872242689132690e-01
    z[2,7,5]  R1332     4.4117224216461182e-01
    z[2,7,5]  R1333     2.8110796213150024e-01
    z[2,7,5]  R1334     1.1208473145961761e-01
    z[2,7,5]  R1335     2.7155107259750366e-01
    z[2,7,5]  R1336     -4.3861803412437439e-01
    z[2,7,5]  R1337     -6.7537024617195129e-02
    z[2,7,5]  R1338     1.7103704810142517e-01
    z[2,7,5]  R1339     -2.1028815209865570e-01
    z[2,7,5]  R1340     -2.4964958429336548e-01
    z[2,7,5]  R1341     -4.5664468407630920e-01
    z[2,7,5]  R1342     -2.9148340225219727e-01
    z[2,7,5]  R1343     -3.8634309172630310e-01
    z[2,7,5]  R1344     -3.6803993582725525e-01
    z[2,7,5]  R1345     -1.1284297704696655e-01
    z[2,7,5]  R1346     -5.3353202342987061e-01
    z[2,7,5]  R1347     1.7176094651222229e-01
    z[2,7,5]  R1348     4.9098852276802063e-01
    z[2,7,5]  R1349     -7.4825161695480347e-01
    z[2,7,5]  R1350     -1.3256806135177612e-01
    z[2,7,5]  R1351     1.5758083760738373e-01
    z[2,7,5]  R1352     -1.8381103873252869e-01
    z[2,7,5]  R1353     1.5108172781765461e-02
    z[2,7,5]  R1354     1.3056656718254089e-01
    z[2,7,5]  R1355     0.481060653924942
    z[2,7,5]  R1356     -9.0091437101364136e-02
    z[2,7,5]  R1357     -3.0887165665626526e-01
    z[2,7,5]  R1358     -9.2239004373550415e-01
    z[2,7,5]  R1359     -7.5115984678268433e-01
    z[2,7,5]  R1360     1.7373837530612946e-01
    z[2,7,5]  R1361     -2.7775179594755173e-02
    z[2,7,5]  R1362     -1.8732881546020508e-01
    z[2,7,5]  R1363     -1.5532526373863220e-01
    z[2,7,5]  R1364     -4.3492570519447327e-01
    z[2,7,5]  R1365     3.4181350469589233e-01
    z[2,7,5]  R1366     0.00815114751458168
    z[2,7,5]  R1367     1.6097424924373627e-01
    z[2,7,5]  R1368     -2.4331073462963104e-01
    z[2,7,5]  R1369     -2.3352622985839844e-01
    z[2,7,5]  R1370     -2.2083316743373871e-01
    z[2,7,5]  R1371     -5.2200831472873688e-02
    z[2,7,5]  R1372     5.9199732542037964e-01
    z[2,7,5]  R1373     3.0169311165809631e-01
    z[2,7,5]  R1374     1.8120923638343811e-01
    z[2,7,5]  R1375     -1.6136570274829865e-01
    z[2,7,5]  R1376     -3.1965515017509460e-01
    z[2,7,5]  R1377     -3.1550022959709167e-01
    z[2,7,5]  R1378     -2.1198825538158417e-01
    z[2,7,5]  R1379     -4.0874508023262024e-01
    z[2,7,5]  R1380     -2.1739758551120758e-01
    z[2,7,5]  R1381     -1.3742758333683014e-01
    z[2,7,5]  R1382     -3.5361200571060181e-01
    z[2,7,5]  R1383     -3.7164643406867981e-01
    z[2,7,5]  R1384     -3.7035247683525085e-01
    z[2,7,5]  R1385     -5.2202105522155762e-01
    z[2,7,5]  R1386     3.2202634215354919e-01
    z[2,7,5]  R1387     -1.7131336033344269e-01
    z[2,7,5]  R1388     -3.4875169396400452e-01
    z[2,7,5]  R1389     1.1485569924116135e-01
    z[2,7,5]  R1390     2.5832670927047729e-01
    z[2,7,5]  R1391     1.6578520834445953e-01
    z[2,7,5]  R1392     1.6976547241210938e-01
    z[2,7,5]  R1393     5.2896046638488770e-01
    z[2,7,5]  R1394     5.3319811820983887e-01
    z[2,7,5]  R1395     -7.9358108341693878e-03
    z[2,7,5]  R1396     4.1155338287353516e-01
    z[2,7,5]  R1397     5.7823747396469116e-01
    z[2,7,5]  R1398     -2.5613831356167793e-02
    z[2,7,5]  R1399     5.0028479099273682e-01
    z[2,7,5]  R1400     -1.8670815974473953e-02
    z[2,7,5]  R1401     1.6047197580337524e-01
    z[2,7,5]  R1402     3.6025676876306534e-02
    z[2,7,5]  R1403     1.9604517519474030e-01
    z[2,7,5]  R1404     -0.429318368434906
    z[2,7,5]  R1405     -1.7985065281391144e-01
    z[2,7,5]  R1406     -5.0258863717317581e-02
    z[2,7,5]  R1407     -0.50553959608078
    z[2,7,5]  R1408     -4.1002359986305237e-01
    z[2,7,5]  R1409     -2.0191858708858490e-01
    z[2,7,5]  R1410     1.1014650017023087e-01
    z[2,7,5]  R1411     -2.7247246354818344e-02
    z[2,7,5]  R1412     -6.9881081581115723e-02
    z[2,7,5]  R1413     2.1768143773078918e-01
    z[2,7,5]  R1414     -6.6732531785964966e-01
    z[2,7,5]  R1415     -6.9999217987060547e-01
    z[2,7,5]  R1416     4.3726280331611633e-01
    z[2,7,5]  R1417     1.4854957163333893e-01
    z[2,7,5]  R1418     1.5420123934745789e-01
    z[2,7,5]  R1419     -0.094334177672863
    z[2,7,5]  R1420     -2.8806936740875244e-01
    z[2,7,5]  R1421     3.0473349615931511e-02
    z[2,7,5]  R1422     7.1793437004089355e-02
    z[2,7,5]  R1423     -1.9304917752742767e-01
    z[2,7,5]  R1424     1.3385677337646484e-01
    z[2,7,5]  R1425     1.9853435456752777e-01
    z[2,7,5]  R1426     4.3308857083320618e-01
    z[2,7,5]  R1427     0.0741511881351471
    z[2,7,5]  R1428     -4.2723512649536133e-01
    z[2,7,5]  R1429     5.9995427727699280e-02
    z[2,7,5]  R1430     -3.5500192642211914e-01
    z[2,7,5]  R1431     2.8033751249313354e-01
    z[2,7,5]  R1432     -1.9317139685153961e-01
    z[2,7,5]  R1433     4.1094236075878143e-02
    z[2,7,5]  R1434     -2.1376991271972656e-01
    z[2,7,5]  R1435     -1.1652937391772866e-03
    z[2,7,6]  R26       -1
    z[2,7,6]  R71       1
    z[2,7,6]  R1314     -1
    z[2,7,6]  R1315     1
    z[2,7,6]  R1316     -3.6359116435050964e-01
    z[2,7,6]  R1317     4.8671197891235352e-01
    z[2,7,6]  R1318     1.2976335361599922e-02
    z[2,7,6]  R1319     1.9841415632981807e-04
    z[2,7,6]  R1320     2.5747016072273254e-01
    z[2,7,6]  R1321     -4.0895272046327591e-02
    z[2,7,6]  R1322     4.0123319625854492e-01
    z[2,7,6]  R1323     0.0415741428732872
    z[2,7,6]  R1324     -4.4453600049018860e-01
    z[2,7,6]  R1325     -4.2160528898239136e-01
    z[2,7,6]  R1326     -8.6947746574878693e-02
    z[2,7,6]  R1327     2.4069288372993469e-01
    z[2,7,6]  R1328     2.6291970163583755e-02
    z[2,7,6]  R1329     2.4520504474639893e-01
    z[2,7,6]  R1330     2.1488258242607117e-01
    z[2,7,6]  R1331     1.6737145185470581e-01
    z[2,7,6]  R1332     3.9287796616554260e-01
    z[2,7,6]  R1333     3.1707757711410522e-01
    z[2,7,6]  R1334     -1.3823526911437511e-02
    z[2,7,6]  R1335     -1.9499093294143677e-01
    z[2,7,6]  R1336     3.3367431163787842e-01
    z[2,7,6]  R1337     -9.4794243574142456e-02
    z[2,7,6]  R1338     3.8932305574417114e-01
    z[2,7,6]  R1339     -4.3811149895191193e-02
    z[2,7,6]  R1340     2.0110045373439789e-01
    z[2,7,6]  R1341     -8.5356742143630981e-02
    z[2,7,6]  R1342     -3.1291925907135010e-01
    z[2,7,6]  R1343     -1.1640454828739166e-01
    z[2,7,6]  R1344     6.2806069850921631e-02
    z[2,7,6]  R1345     -1.5487149357795715e-01
    z[2,7,6]  R1346     -2.8832051157951355e-01
    z[2,7,6]  R1347     1.5724253654479980e-01
    z[2,7,6]  R1348     -3.9755105972290039e-01
    z[2,7,6]  R1349     -1.4447268843650818e-01
    z[2,7,6]  R1350     -0.627393364906311
    z[2,7,6]  R1351     9.4787724316120148e-02
    z[2,7,6]  R1352     -0.618626058101654
    z[2,7,6]  R1353     -2.2545768320560455e-01
    z[2,7,6]  R1354     -1.1636500060558319e-01
    z[2,7,6]  R1355     7.9149333760142326e-03
    z[2,7,6]  R1356     6.7283022217452526e-03
    z[2,7,6]  R1357     -3.9602261781692505e-01
    z[2,7,6]  R1358     -3.3947536349296570e-01
    z[2,7,6]  R1359     2.0234017074108124e-01
    z[2,7,6]  R1360     -2.2302420809864998e-02
    z[2,7,6]  R1361     -1.0750397294759750e-01
    z[2,7,6]  R1362     3.0643166974186897e-02
    z[2,7,6]  R1363     1.7943707108497620e-01
    z[2,7,6]  R1364     -2.0033207535743713e-01
    z[2,7,6]  R1365     4.6682354062795639e-02
    z[2,7,6]  R1366     -8.5424654185771942e-02
    z[2,7,6]  R1367     1.4204651117324829e-01
    z[2,7,6]  R1368     -3.1563821434974670e-01
    z[2,7,6]  R1369     -3.3982202410697937e-02
    z[2,7,6]  R1370     -9.3037769198417664e-02
    z[2,7,6]  R1371     -2.5839787721633911e-01
    z[2,7,6]  R1372     -1.9042136147618294e-02
    z[2,7,6]  R1373     1.1859728395938873e-01
    z[2,7,6]  R1374     -1.7192541854456067e-03
    z[2,7,6]  R1375     -2.5719583034515381e-02
    z[2,7,6]  R1376     0.272826224565506
    z[2,7,6]  R1377     -1.4592908322811127e-01
    z[2,7,6]  R1378     0.0883352980017662
    z[2,7,6]  R1379     2.3601607978343964e-01
    z[2,7,6]  R1380     2.8957530856132507e-01
    z[2,7,6]  R1381     3.5161668062210083e-01
    z[2,7,6]  R1382     -2.2178536280989647e-02
    z[2,7,6]  R1383     -2.2910106182098389e-01
    z[2,7,6]  R1384     -0.279342383146286
    z[2,7,6]  R1385     6.8481385707855225e-02
    z[2,7,6]  R1386     2.2746691107749939e-01
    z[2,7,6]  R1387     2.7614927291870117e-01
    z[2,7,6]  R1388     -2.7461913228034973e-01
    z[2,7,6]  R1389     -4.0738663077354431e-01
    z[2,7,6]  R1390     -3.3743351697921753e-01
    z[2,7,6]  R1391     6.0053861141204834e-01
    z[2,7,6]  R1392     -2.7851322293281555e-01
    z[2,7,6]  R1393     -1.3669953681528568e-02
    z[2,7,6]  R1394     7.1014779806137085e-01
    z[2,7,6]  R1395     3.0918738245964050e-01
    z[2,7,6]  R1396     6.2395554780960083e-01
    z[2,7,6]  R1397     4.5911943912506104e-01
    z[2,7,6]  R1398     -2.8632143139839172e-01
    z[2,7,6]  R1399     1.2162868864834309e-02
    z[2,7,6]  R1400     -2.2372503578662872e-01
    z[2,7,6]  R1401     -5.6143510341644287e-01
    z[2,7,6]  R1402     5.4943454265594482e-01
    z[2,7,6]  R1403     -0.665951132774353
    z[2,7,6]  R1404     1.5840151906013489e-01
    z[2,7,6]  R1405     -2.1365078166127205e-02
    z[2,7,6]  R1406     1.5309567749500275e-01
    z[2,7,6]  R1407     4.5373108237981796e-02
    z[2,7,6]  R1408     -2.7633062005043030e-01
    z[2,7,6]  R1409     -3.1513014435768127e-01
    z[2,7,6]  R1410     -5.8834567666053772e-02
    z[2,7,6]  R1411     -1.0482275485992432e-01
    z[2,7,6]  R1412     -1.5043185651302338e-01
    z[2,7,6]  R1413     -1.1765944957733154e-01
    z[2,7,6]  R1414     1.9668446853756905e-02
    z[2,7,6]  R1415     -8.1644721329212189e-02
    z[2,7,6]  R1416     2.2319868206977844e-02
    z[2,7,6]  R1417     -2.9431256651878357e-01
    z[2,7,6]  R1418     3.7668031454086304e-01
    z[2,7,6]  R1419     -2.7511370182037354e-01
    z[2,7,6]  R1420     3.4089684486389160e-02
    z[2,7,6]  R1421     -1.6389900445938110e-01
    z[2,7,6]  R1422     2.8716831002384424e-04
    z[2,7,6]  R1423     1.8524080514907837e-01
    z[2,7,6]  R1424     -2.3157205432653427e-02
    z[2,7,6]  R1425     -3.3950844407081604e-01
    z[2,7,6]  R1426     -3.4378501772880554e-01
    z[2,7,6]  R1427     -5.8123809099197388e-01
    z[2,7,6]  R1428     -2.1278581023216248e-01
    z[2,7,6]  R1429     2.2819848358631134e-01
    z[2,7,6]  R1430     4.4436073303222656e-01
    z[2,7,6]  R1431     6.3039287924766541e-02
    z[2,7,6]  R1432     2.1365134045481682e-02
    z[2,7,6]  R1433     1.3199381530284882e-01
    z[2,7,6]  R1434     -1.1755295097827911e-01
    z[2,7,6]  R1435     -2.9218699783086777e-02
    z[7,2,0]  R20       1
    z[7,2,0]  R65       -1
    z[7,2,0]  R1436     -1
    z[7,2,0]  R1437     1
    z[7,2,0]  R1450     -5.5729341506958008e-01
    z[7,2,0]  R1451     -0.570170521736145
    z[7,2,0]  R1452     -0.519062876701355
    z[7,2,0]  R1453     -1.5749590098857880e-01
    z[7,2,0]  R1454     -2.7505412697792053e-01
    z[7,2,0]  R1455     -3.7525451183319092e-01
    z[7,2,0]  R1456     2.3901455104351044e-02
    z[7,2,0]  R1457     -2.5289878249168396e-01
    z[7,2,0]  R1458     4.0116536617279053e-01
    z[7,2,0]  R1459     -1.9124847650527954e-01
    z[7,2,0]  R1460     -5.3013980388641357e-01
    z[7,2,0]  R1461     7.6019114255905151e-01
    z[7,2,0]  R1462     -2.5712382793426514e-01
    z[7,2,0]  R1463     -3.3564478158950806e-01
    z[7,2,0]  R1464     -0.532228410243988
    z[7,2,0]  R1465     7.5140100717544556e-01
    z[7,2,0]  R1466     -6.1134433746337891e-01
    z[7,2,0]  R1467     -7.5698435306549072e-01
    z[7,2,0]  R1468     -5.2028256654739380e-01
    z[7,2,0]  R1469     1.3251268863677979e-01
    z[7,2,0]  R1470     6.0195124149322510e-01
    z[7,2,0]  R1471     5.9818547964096069e-01
    z[7,2,0]  R1472     6.7245703935623169e-01
    z[7,2,0]  R1473     4.9734145402908325e-01
    z[7,2,0]  R1474     0.382784366607666
    z[7,2,0]  R1475     5.3919726610183716e-01
    z[7,2,0]  R1476     0.352083295583725
    z[7,2,0]  R1477     1.0322692990303040e-01
    z[7,2,0]  R1478     -3.5776447504758835e-02
    z[7,2,0]  R1479     -6.2972344458103180e-02
    z[7,2,0]  R1480     3.9761614799499512e-01
    z[7,2,0]  R1481     3.1109130382537842e-01
    z[7,2,0]  R1482     6.0046070814132690e-01
    z[7,2,0]  R1483     6.0410302132368088e-02
    z[7,2,0]  R1484     -4.0367566980421543e-03
    z[7,2,0]  R1485     3.0294919013977051e-01
    z[7,2,0]  R1486     5.7300585508346558e-01
    z[7,2,0]  R1487     1.5232123434543610e-01
    z[7,2,0]  R1488     -5.1245975494384766e-01
    z[7,2,0]  R1489     7.1005530655384064e-02
    z[7,2,0]  R1490     -1.8540312349796295e-01
    z[7,2,0]  R1491     -6.8541193008422852e-01
    z[7,2,0]  R1492     -2.7038168907165527e-01
    z[7,2,0]  R1493     -0.452766478061676
    z[7,2,0]  R1494     -4.6305142343044281e-02
    z[7,2,0]  R1495     -7.7871638350188732e-03
    z[7,2,0]  R1496     7.7178925275802612e-02
    z[7,2,0]  R1497     -2.6318386197090149e-01
    z[7,2,0]  R1498     2.7791216969490051e-01
    z[7,2,0]  R1499     0.000984802725724876
    z[7,2,0]  R1500     2.8282368183135986e-01
    z[7,2,0]  R1501     -2.5316581130027771e-01
    z[7,2,0]  R1502     1.2265031225979328e-02
    z[7,2,0]  R1503     -4.1162014007568359e-01
    z[7,2,0]  R1504     -2.6204910874366760e-01
    z[7,2,0]  R1505     -6.1397153139114380e-01
    z[7,2,0]  R1506     -1.5431550145149231e-01
    z[7,2,0]  R1507     2.1453516185283661e-01
    z[7,2,0]  R1508     1.5545056760311127e-01
    z[7,2,0]  R1509     -5.9662234783172607e-01
    z[7,2,0]  R1510     -1.2338148802518845e-01
    z[7,2,0]  R1511     -1.2407746165990829e-01
    z[7,2,0]  R1512     -3.0643790960311890e-01
    z[7,2,0]  R1513     2.3313535749912262e-01
    z[7,2,0]  R1514     5.5375963449478149e-01
    z[7,2,0]  R1515     -1.8920011818408966e-01
    z[7,2,0]  R1516     -5.3123313188552856e-01
    z[7,2,0]  R1517     5.9123420715332031e-01
    z[7,2,0]  R1518     5.3236150741577148e-01
    z[7,2,0]  R1519     3.4476128220558167e-01
    z[7,2,0]  R1520     -1.4782412350177765e-01
    z[7,2,0]  R1521     -2.7121052145957947e-01
    z[7,2,0]  R1522     -4.2609363794326782e-01
    z[7,2,0]  R1523     8.9835673570632935e-02
    z[7,2,0]  R1524     1.5872716903686523e-01
    z[7,2,0]  R1525     -4.2676275968551636e-01
    z[7,2,0]  R1526     -4.4167912006378174e-01
    z[7,2,0]  R1527     -4.8775526881217957e-01
    z[7,2,0]  R1528     -4.5682573318481445e-01
    z[7,2,0]  R1529     -1.1885754019021988e-01
    z[7,2,0]  R1530     3.8897725939750671e-01
    z[7,2,0]  R1531     3.5454452037811279e-01
    z[7,2,0]  R1532     2.8881320357322693e-01
    z[7,2,0]  R1533     4.6142455935478210e-01
    z[7,2,0]  R1534     5.3530693054199219e-01
    z[7,2,0]  R1535     3.7302318215370178e-01
    z[7,2,0]  R1536     4.8588916659355164e-01
    z[7,2,0]  R1537     5.7735973596572876e-01
    z[7,2,0]  R1538     5.8803540468215942e-01
    z[7,2,0]  R1539     5.1394337415695190e-01
    z[7,2,0]  R1540     4.3111103773117065e-01
    z[7,2,0]  R1541     3.4580138325691223e-01
    z[7,2,0]  R1542     0.584464430809021
    z[7,2,0]  R1543     0.696518063545227
    z[7,2,0]  R1544     6.6535425186157227e-01
    z[7,2,0]  R1545     2.6260477304458618e-01
    z[7,2,0]  R1546     3.3323770761489868e-01
    z[7,2,0]  R1547     2.3147930204868317e-01
    z[7,2,0]  R1548     5.5249071121215820e-01
    z[7,2,0]  R1549     -2.8479587286710739e-02
    z[7,2,0]  R1550     -2.8795897960662842e-01
    z[7,2,0]  R1551     1.7002350091934204e-01
    z[7,2,0]  R1552     3.7074264883995056e-01
    z[7,2,0]  R1553     4.0712225437164307e-01
    z[7,2,0]  R1554     2.7213799953460693e-01
    z[7,2,0]  R1555     2.5323492288589478e-01
    z[7,2,0]  R1556     1.2948262691497803e-01
    z[7,2,0]  R1557     6.1186432838439941e-01
    z[7,2,0]  R1558     6.2839525938034058e-01
    z[7,2,0]  R1559     5.9266000986099243e-01
    z[7,2,0]  R1560     -2.9768115282058716e-01
    z[7,2,0]  R1561     7.9456394910812378e-01
    z[7,2,0]  R1562     1.2260476499795914e-01
    z[7,2,0]  R1563     1.8940119445323944e-01
    z[7,2,0]  R1564     8.9682662487030029e-01
    z[7,2,0]  R1565     1.5533445775508881e-01
    z[7,2,0]  R1566     2.3656730353832245e-01
    z[7,2,0]  R1567     1.4052592217922211e-01
    z[7,2,0]  R1568     1.9808086752891541e-01
    z[7,2,0]  R1569     -2.1435850858688354e-01
    z[7,2,1]  R21       1
    z[7,2,1]  R66       -1
    z[7,2,1]  R1438     -1
    z[7,2,1]  R1439     1
    z[7,2,1]  R1450     -7.3747581243515015e-01
    z[7,2,1]  R1451     -7.4708157777786255e-01
    z[7,2,1]  R1452     -7.3020076751708984e-01
    z[7,2,1]  R1453     -9.3595254421234131e-01
    z[7,2,1]  R1454     -8.7157249450683594e-01
    z[7,2,1]  R1455     -8.0742329359054565e-01
    z[7,2,1]  R1456     -1.9723260775208473e-02
    z[7,2,1]  R1457     -8.6047857999801636e-01
    z[7,2,1]  R1458     3.9040920138359070e-01
    z[7,2,1]  R1459     -8.3041661977767944e-01
    z[7,2,1]  R1460     0.418416827917099
    z[7,2,1]  R1461     5.7618740946054459e-02
    z[7,2,1]  R1462     3.9711853861808777e-01
    z[7,2,1]  R1463     3.7892201542854309e-01
    z[7,2,1]  R1464     4.4411951303482056e-01
    z[7,2,1]  R1465     -2.7559101581573486e-01
    z[7,2,1]  R1466     4.4987294077873230e-01
    z[7,2,1]  R1467     3.6728054285049438e-01
    z[7,2,1]  R1468     0.534921407699585
    z[7,2,1]  R1469     2.6610809564590454e-01
    z[7,2,1]  R1470     1.7845438420772552e-01
    z[7,2,1]  R1471     -4.6498408913612366e-01
    z[7,2,1]  R1472     -2.5442427396774292e-01
    z[7,2,1]  R1473     -4.4862989336252213e-02
    z[7,2,1]  R1474     -1.2408622354269028e-01
    z[7,2,1]  R1475     -3.0851846933364868e-01
    z[7,2,1]  R1476     -4.3527570366859436e-01
    z[7,2,1]  R1477     3.5347703844308853e-02
    z[7,2,1]  R1478     2.0681785047054291e-01
    z[7,2,1]  R1479     9.0527945756912231e-01
    z[7,2,1]  R1480     -1.1390823125839233e-01
    z[7,2,1]  R1481     3.4702695906162262e-02
    z[7,2,1]  R1482     -2.0013208687305450e-01
    z[7,2,1]  R1483     -3.1605863571166992e-01
    z[7,2,1]  R1484     -6.7666035890579224e-01
    z[7,2,1]  R1485     3.5550642013549805e-01
    z[7,2,1]  R1486     1.4513367414474487e-01
    z[7,2,1]  R1487     -1.2593352794647217e-01
    z[7,2,1]  R1488     1.0443762689828873e-01
    z[7,2,1]  R1489     9.5946002006530762e-01
    z[7,2,1]  R1490     -6.5885370969772339e-01
    z[7,2,1]  R1491     2.4410164356231689e-01
    z[7,2,1]  R1492     2.7930954098701477e-01
    z[7,2,1]  R1493     4.5855066180229187e-01
    z[7,2,1]  R1494     9.0118712186813354e-01
    z[7,2,1]  R1495     9.7862249612808228e-01
    z[7,2,1]  R1496     0.916998565196991
    z[7,2,1]  R1497     9.1740399599075317e-01
    z[7,2,1]  R1498     -5.0423923879861832e-02
    z[7,2,1]  R1499     2.1070607006549835e-01
    z[7,2,1]  R1500     -4.6093201637268066e-01
    z[7,2,1]  R1501     -5.1532387733459473e-01
    z[7,2,1]  R1502     -5.8087170124053955e-01
    z[7,2,1]  R1503     2.6048794388771057e-01
    z[7,2,1]  R1504     1.4729660749435425e-01
    z[7,2,1]  R1505     4.6828430891036987e-01
    z[7,2,1]  R1506     9.2185807228088379e-01
    z[7,2,1]  R1507     8.7684553861618042e-01
    z[7,2,1]  R1508     9.4337785243988037e-01
    z[7,2,1]  R1509     3.8790026307106018e-01
    z[7,2,1]  R1510     0.128950834274292
    z[7,2,1]  R1511     -4.7677025198936462e-01
    z[7,2,1]  R1512     5.0981199741363525e-01
    z[7,2,1]  R1513     9.1037929058074951e-01
    z[7,2,1]  R1514     1.2420173734426498e-01
    z[7,2,1]  R1515     7.7613222599029541e-01
    z[7,2,1]  R1516     7.1518266201019287e-01
    z[7,2,1]  R1517     1.3515974581241608e-01
    z[7,2,1]  R1518     -1.9805087149143219e-01
    z[7,2,1]  R1519     -4.6662919223308563e-02
    z[7,2,1]  R1520     -0.450273722410202
    z[7,2,1]  R1521     -3.6599117517471313e-01
    z[7,2,1]  R1522     -1.7743575572967529e-01
    z[7,2,1]  R1523     -5.0480651855468750e-01
    z[7,2,1]  R1524     -6.7000722885131836e-01
    z[7,2,1]  R1525     -8.3980625867843628e-01
    z[7,2,1]  R1526     -7.3805534839630127e-01
    z[7,2,1]  R1527     -6.8874347209930420e-01
    z[7,2,1]  R1528     -0.69554603099823
    z[7,2,1]  R1529     -8.4459286928176880e-01
    z[7,2,1]  R1530     9.0619117021560669e-02
    z[7,2,1]  R1531     3.5812300629913807e-03
    z[7,2,1]  R1532     1.0858666896820068e-01
    z[7,2,1]  R1533     3.2087564468383789e-01
    z[7,2,1]  R1534     3.6810154560953379e-03
    z[7,2,1]  R1535     -2.2005392611026764e-01
    z[7,2,1]  R1536     4.5547958463430405e-02
    z[7,2,1]  R1537     1.2174101918935776e-01
    z[7,2,1]  R1538     -7.4106492102146149e-02
    z[7,2,1]  R1539     4.8135435581207275e-01
    z[7,2,1]  R1540     3.6078253388404846e-01
    z[7,2,1]  R1541     5.2687269449234009e-01
    z[7,2,1]  R1542     -1.9589845836162567e-01
    z[7,2,1]  R1543     -1.6955339908599854e-01
    z[7,2,1]  R1544     -1.4765505492687225e-01
    z[7,2,1]  R1545     2.3742891848087311e-01
    z[7,2,1]  R1546     6.7550569772720337e-01
    z[7,2,1]  R1547     6.8556523323059082e-01
    z[7,2,1]  R1548     3.7840464711189270e-01
    z[7,2,1]  R1549     7.0039027929306030e-01
    z[7,2,1]  R1550     3.6631658673286438e-01
    z[7,2,1]  R1551     -9.6432730555534363e-02
    z[7,2,1]  R1552     -1.7140366137027740e-01
    z[7,2,1]  R1553     -1.8234404921531677e-01
    z[7,2,1]  R1554     -1.4444039762020111e-01
    z[7,2,1]  R1555     -5.5179785937070847e-02
    z[7,2,1]  R1556     -7.5423799455165863e-02
    z[7,2,1]  R1557     4.8955509066581726e-01
    z[7,2,1]  R1558     5.2413874864578247e-01
    z[7,2,1]  R1559     4.3968778848648071e-01
    z[7,2,1]  R1560     2.2655875980854034e-01
    z[7,2,1]  R1561     -2.6407933235168457e-01
    z[7,2,1]  R1562     -4.6501386910676956e-02
    z[7,2,1]  R1563     1.6103906929492950e-01
    z[7,2,1]  R1564     3.6249703168869019e-01
    z[7,2,1]  R1565     5.4928815364837646e-01
    z[7,2,1]  R1566     7.9501521587371826e-01
    z[7,2,1]  R1567     0.604786217212677
    z[7,2,1]  R1568     4.5172744989395142e-01
    z[7,2,1]  R1569     4.8909822106361389e-01
    z[7,2,2]  R22       1
    z[7,2,2]  R67       -1
    z[7,2,2]  R1440     -1
    z[7,2,2]  R1441     1
    z[7,2,2]  R1450     0.298555850982666
    z[7,2,2]  R1451     1.8358130753040314e-01
    z[7,2,2]  R1452     1.9443720579147339e-01
    z[7,2,2]  R1453     1.5707209706306458e-01
    z[7,2,2]  R1454     -2.6619702577590942e-01
    z[7,2,2]  R1455     -1.0090090334415436e-01
    z[7,2,2]  R1456     -7.4030059576034546e-01
    z[7,2,2]  R1457     -1.6972111165523529e-01
    z[7,2,2]  R1458     -7.7183133363723755e-01
    z[7,2,2]  R1459     1.4229343831539154e-01
    z[7,2,2]  R1460     5.8528393507003784e-01
    z[7,2,2]  R1461     -3.7061061710119247e-02
    z[7,2,2]  R1462     8.3552157878875732e-01
    z[7,2,2]  R1463     4.7039976716041565e-01
    z[7,2,2]  R1464     3.7349972128868103e-01
    z[7,2,2]  R1465     5.8752644807100296e-02
    z[7,2,2]  R1466     2.3887164890766144e-01
    z[7,2,2]  R1467     2.6121550798416138e-01
    z[7,2,2]  R1468     3.0541107058525085e-01
    z[7,2,2]  R1469     7.8861457109451294e-01
    z[7,2,2]  R1470     -1.9163978099822998e-01
    z[7,2,2]  R1471     -5.1818495988845825e-01
    z[7,2,2]  R1472     -3.6145347356796265e-01
    z[7,2,2]  R1473     -5.7662930339574814e-02
    z[7,2,2]  R1474     -1.6415746882557869e-02
    z[7,2,2]  R1475     -7.3851391673088074e-02
    z[7,2,2]  R1476     -2.2096006572246552e-01
    z[7,2,2]  R1477     -5.3146738559007645e-02
    z[7,2,2]  R1478     -1.4740160107612610e-01
    z[7,2,2]  R1479     2.1982432901859283e-01
    z[7,2,2]  R1480     -3.8245442509651184e-01
    z[7,2,2]  R1481     -2.9966729879379272e-01
    z[7,2,2]  R1482     -3.2674607634544373e-01
    z[7,2,2]  R1483     -2.6593995094299316e-01
    z[7,2,2]  R1484     -4.1883742809295654e-01
    z[7,2,2]  R1485     -4.2928963899612427e-01
    z[7,2,2]  R1486     -4.4848346710205078e-01
    z[7,2,2]  R1487     -3.6271527409553528e-01
    z[7,2,2]  R1488     2.6568377017974854e-01
    z[7,2,2]  R1489     5.1571227610111237e-02
    z[7,2,2]  R1490     -5.2012479305267334e-01
    z[7,2,2]  R1491     0.430862158536911
    z[7,2,2]  R1492     6.4673972129821777e-01
    z[7,2,2]  R1493     5.3898984193801880e-01
    z[7,2,2]  R1494     1.5493386983871460e-01
    z[7,2,2]  R1495     1.5950405597686768e-01
    z[7,2,2]  R1496     1.4847847819328308e-01
    z[7,2,2]  R1497     1.4667649567127228e-01
    z[7,2,2]  R1498     6.8408769369125366e-01
    z[7,2,2]  R1499     5.0998938083648682e-01
    z[7,2,2]  R1500     -1.5722635388374329e-01
    z[7,2,2]  R1501     -1.3574923574924469e-01
    z[7,2,2]  R1502     -4.8064518719911575e-02
    z[7,2,2]  R1503     8.1105232238769531e-01
    z[7,2,2]  R1504     8.8950288295745850e-01
    z[7,2,2]  R1505     5.5517274141311646e-01
    z[7,2,2]  R1506     0.0680805891752243
    z[7,2,2]  R1507     1.5615177154541016e-01
    z[7,2,2]  R1508     1.3400849699974060e-01
    z[7,2,2]  R1509     5.0934523344039917e-01
    z[7,2,2]  R1510     -4.7807180881500244e-01
    z[7,2,2]  R1511     -5.9512192010879517e-01
    z[7,2,2]  R1512     4.7363206744194031e-01
    z[7,2,2]  R1513     2.0909920334815979e-01
    z[7,2,2]  R1514     5.8233773708343506e-01
    z[7,2,2]  R1515     -0.0377717949450016
    z[7,2,2]  R1516     -2.4989375472068787e-01
    z[7,2,2]  R1517     7.7504372596740723e-01
    z[7,2,2]  R1518     7.0783507823944092e-01
    z[7,2,2]  R1519     8.4468716382980347e-01
    z[7,2,2]  R1520     6.8378245830535889e-01
    z[7,2,2]  R1521     6.3701760768890381e-01
    z[7,2,2]  R1522     8.2270896434783936e-01
    z[7,2,2]  R1523     7.8873842954635620e-01
    z[7,2,2]  R1524     4.9533864855766296e-01
    z[7,2,2]  R1525     1.3021484017372131e-01
    z[7,2,2]  R1526     1.9035948812961578e-01
    z[7,2,2]  R1527     0.517758846282959
    z[7,2,2]  R1528     2.3810453712940216e-01
    z[7,2,2]  R1529     -1.1931928992271423e-01
    z[7,2,2]  R1530     -8.0693596601486206e-01
    z[7,2,2]  R1531     -7.6489633321762085e-01
    z[7,2,2]  R1532     -6.3491022586822510e-01
    z[7,2,2]  R1533     -6.3651943206787109e-01
    z[7,2,2]  R1534     -6.1497306823730469e-01
    z[7,2,2]  R1535     -5.7035428285598755e-01
    z[7,2,2]  R1536     -5.6095844507217407e-01
    z[7,2,2]  R1537     -5.2547782659530640e-01
    z[7,2,2]  R1538     -6.7329776287078857e-01
    z[7,2,2]  R1539     -3.2091107964515686e-01
    z[7,2,2]  R1540     2.6161280274391174e-01
    z[7,2,2]  R1541     4.5063313841819763e-01
    z[7,2,2]  R1542     9.8026670515537262e-02
    z[7,2,2]  R1543     -1.2122385203838348e-01
    z[7,2,2]  R1544     -1.2712979316711426e-01
    z[7,2,2]  R1545     -1.3833381235599518e-01
    z[7,2,2]  R1546     -1.5411974489688873e-01
    z[7,2,2]  R1547     -2.5532284751534462e-02
    z[7,2,2]  R1548     -1.9931019842624664e-01
    z[7,2,2]  R1549     -7.1439862251281738e-02
    z[7,2,2]  R1550     4.4743287563323975e-01
    z[7,2,2]  R1551     3.6612075567245483e-01
    z[7,2,2]  R1552     3.0734816193580627e-01
    z[7,2,2]  R1553     -9.8225146532058716e-02
    z[7,2,2]  R1554     1.1402430245652795e-03
    z[7,2,2]  R1555     2.8212782740592957e-01
    z[7,2,2]  R1556     -1.5990474820137024e-01
    z[7,2,2]  R1557     -3.8946467638015747e-01
    z[7,2,2]  R1558     1.6579274833202362e-01
    z[7,2,2]  R1559     1.4172625541687012e-01
    z[7,2,2]  R1560     3.9897614717483521e-01
    z[7,2,2]  R1561     1.8585719168186188e-01
    z[7,2,2]  R1562     5.6403100490570068e-02
    z[7,2,2]  R1563     3.4615629911422729e-01
    z[7,2,2]  R1564     -6.6663399338722229e-02
    z[7,2,2]  R1565     -1.8497291207313538e-01
    z[7,2,2]  R1566     -1.4014115929603577e-01
    z[7,2,2]  R1567     -2.6403433084487915e-01
    z[7,2,2]  R1568     -4.2821100354194641e-01
    z[7,2,2]  R1569     -0.280825138092041
    z[7,2,3]  R23       1
    z[7,2,3]  R68       -1
    z[7,2,3]  R1442     -1
    z[7,2,3]  R1443     1
    z[7,2,3]  R1450     2.1336081624031067e-01
    z[7,2,3]  R1451     7.9396776854991913e-03
    z[7,2,3]  R1452     -1.5130911953747272e-02
    z[7,2,3]  R1453     -8.4489017724990845e-02
    z[7,2,3]  R1454     1.9082543253898621e-01
    z[7,2,3]  R1455     0.310305118560791
    z[7,2,3]  R1456     1.1281483806669712e-02
    z[7,2,3]  R1457     2.4558851122856140e-01
    z[7,2,3]  R1458     2.4062691628932953e-01
    z[7,2,3]  R1459     3.6169907450675964e-01
    z[7,2,3]  R1460     -9.5866424089763314e-05
    z[7,2,3]  R1461     6.2737171538174152e-03
    z[7,2,3]  R1462     -4.9242008477449417e-02
    z[7,2,3]  R1463     -8.9440263807773590e-02
    z[7,2,3]  R1464     -1.2167779356241226e-01
    z[7,2,3]  R1465     1.7906905710697174e-01
    z[7,2,3]  R1466     1.5895548462867737e-01
    z[7,2,3]  R1467     -9.5122829079627991e-02
    z[7,2,3]  R1468     -7.8436203300952911e-02
    z[7,2,3]  R1469     6.6721066832542419e-03
    z[7,2,3]  R1470     3.1728571653366089e-01
    z[7,2,3]  R1471     -1.3364253938198090e-01
    z[7,2,3]  R1472     -4.9848143011331558e-02
    z[7,2,3]  R1473     4.1682282090187073e-01
    z[7,2,3]  R1474     6.3563042879104614e-01
    z[7,2,3]  R1475     4.5382767915725708e-01
    z[7,2,3]  R1476     6.9629192352294922e-01
    z[7,2,3]  R1477     7.9223698377609253e-01
    z[7,2,3]  R1478     3.2487702369689941e-01
    z[7,2,3]  R1479     -1.7021021246910095e-01
    z[7,2,3]  R1480     3.3239468932151794e-01
    z[7,2,3]  R1481     1.1013448238372803e-01
    z[7,2,3]  R1482     5.5118042975664139e-02
    z[7,2,3]  R1483     7.5845491886138916e-01
    z[7,2,3]  R1484     -4.6045112609863281e-01
    z[7,2,3]  R1485     1.1464538425207138e-01
    z[7,2,3]  R1486     -2.7030047774314880e-01
    z[7,2,3]  R1487     5.3859239816665649e-01
    z[7,2,3]  R1488     2.4339058995246887e-01
    z[7,2,3]  R1489     -1.8081294000148773e-01
    z[7,2,3]  R1490     -4.1440117359161377e-01
    z[7,2,3]  R1491     1.3351282104849815e-02
    z[7,2,3]  R1492     1.4195926487445831e-01
    z[7,2,3]  R1493     7.4260458350181580e-02
    z[7,2,3]  R1494     3.7941688299179077e-01
    z[7,2,3]  R1495     -0.0711718425154686
    z[7,2,3]  R1496     2.7141135931015015e-01
    z[7,2,3]  R1497     0.0403439924120903
    z[7,2,3]  R1498     -7.0779860019683838e-02
    z[7,2,3]  R1499     -1.4947031438350677e-01
    z[7,2,3]  R1500     5.7387119531631470e-01
    z[7,2,3]  R1501     -1.8258984386920929e-01
    z[7,2,3]  R1502     -5.4872053861618042e-01
    z[7,2,3]  R1503     1.2046121805906296e-01
    z[7,2,3]  R1504     1.4531119167804718e-01
    z[7,2,3]  R1505     -2.5036895275115967e-01
    z[7,2,3]  R1506     1.3941834867000580e-01
    z[7,2,3]  R1507     2.9689857363700867e-01
    z[7,2,3]  R1508     1.6956686973571777e-01
    z[7,2,3]  R1509     1.1790903657674789e-01
    z[7,2,3]  R1510     0.635644793510437
    z[7,2,3]  R1511     2.1650105714797974e-01
    z[7,2,3]  R1512     -2.8590098023414612e-01
    z[7,2,3]  R1513     5.9115849435329437e-02
    z[7,2,3]  R1514     -6.6254511475563049e-03
    z[7,2,3]  R1515     -0.457742303609848
    z[7,2,3]  R1516     1.0660663992166519e-01
    z[7,2,3]  R1517     1.0329223424196243e-01
    z[7,2,3]  R1518     2.9699310660362244e-01
    z[7,2,3]  R1519     1.2285843491554260e-01
    z[7,2,3]  R1520     -1.1237671226263046e-01
    z[7,2,3]  R1521     -9.2583127319812775e-02
    z[7,2,3]  R1522     3.4817929845303297e-03
    z[7,2,3]  R1523     5.8322656899690628e-02
    z[7,2,3]  R1524     1.2655712664127350e-01
    z[7,2,3]  R1525     -7.5186669826507568e-02
    z[7,2,3]  R1526     -2.6910807937383652e-02
    z[7,2,3]  R1527     9.5883026719093323e-02
    z[7,2,3]  R1528     2.2942881286144257e-01
    z[7,2,3]  R1529     1.6687752306461334e-01
    z[7,2,3]  R1530     1.9492086768150330e-01
    z[7,2,3]  R1531     8.3154529333114624e-02
    z[7,2,3]  R1532     1.1766187101602554e-01
    z[7,2,3]  R1533     1.5138009190559387e-01
    z[7,2,3]  R1534     3.8418102264404297e-01
    z[7,2,3]  R1535     -3.4220034722238779e-03
    z[7,2,3]  R1536     -3.3298607915639877e-02
    z[7,2,3]  R1537     0.188424214720726
    z[7,2,3]  R1538     -1.5593400597572327e-01
    z[7,2,3]  R1539     -5.7853475213050842e-02
    z[7,2,3]  R1540     -5.2110069990158081e-01
    z[7,2,3]  R1541     -0.59122234582901
    z[7,2,3]  R1542     -5.0959432125091553e-01
    z[7,2,3]  R1543     -3.4905630350112915e-01
    z[7,2,3]  R1544     -4.1432005167007446e-01
    z[7,2,3]  R1545     -3.6713162064552307e-01
    z[7,2,3]  R1546     4.4533109664916992e-01
    z[7,2,3]  R1547     5.5941206216812134e-01
    z[7,2,3]  R1548     3.9711400866508484e-01
    z[7,2,3]  R1549     0.643405556678772
    z[7,2,3]  R1550     -3.2677242159843445e-01
    z[7,2,3]  R1551     -7.3861151933670044e-01
    z[7,2,3]  R1552     -5.7146298885345459e-01
    z[7,2,3]  R1553     1.2318743765354156e-01
    z[7,2,3]  R1554     -5.0712424516677856e-01
    z[7,2,3]  R1555     -1.5272945165634155e-01
    z[7,2,3]  R1556     -6.1037933826446533e-01
    z[7,2,3]  R1557     2.3904601112008095e-02
    z[7,2,3]  R1558     5.0548028945922852e-01
    z[7,2,3]  R1559     0.298697829246521
    z[7,2,3]  R1560     -7.8724640607833862e-01
    z[7,2,3]  R1561     -5.3819864988327026e-02
    z[7,2,3]  R1562     -7.6515994966030121e-02
    z[7,2,3]  R1563     1.6152633726596832e-01
    z[7,2,3]  R1564     7.2003252804279327e-02
    z[7,2,3]  R1565     7.9220914840698242e-01
    z[7,2,3]  R1566     5.0273102521896362e-01
    z[7,2,3]  R1567     6.5140515565872192e-01
    z[7,2,3]  R1568     5.3595691919326782e-01
    z[7,2,3]  R1569     0.577110767364502
    z[7,2,4]  R24       1
    z[7,2,4]  R69       -1
    z[7,2,4]  R1444     -1
    z[7,2,4]  R1445     1
    z[7,2,4]  R1450     5.9422351419925690e-02
    z[7,2,4]  R1451     -1.9214452803134918e-01
    z[7,2,4]  R1452     2.2768998518586159e-02
    z[7,2,4]  R1453     -1.0811345279216766e-01
    z[7,2,4]  R1454     2.8450158424675465e-03
    z[7,2,4]  R1455     -1.7688177525997162e-01
    z[7,2,4]  R1456     3.1629720330238342e-01
    z[7,2,4]  R1457     3.7627778947353363e-02
    z[7,2,4]  R1458     -1.3504016213119030e-02
    z[7,2,4]  R1459     -3.0993264913558960e-01
    z[7,2,4]  R1460     -1.5718884766101837e-01
    z[7,2,4]  R1461     5.4455578327178955e-01
    z[7,2,4]  R1462     -1.5139667689800262e-01
    z[7,2,4]  R1463     -5.4010105133056641e-01
    z[7,2,4]  R1464     -4.8380544781684875e-01
    z[7,2,4]  R1465     4.2592003941535950e-01
    z[7,2,4]  R1466     -4.6477150917053223e-01
    z[7,2,4]  R1467     1.5552908182144165e-01
    z[7,2,4]  R1468     -0.358530193567276
    z[7,2,4]  R1469     -1.1168579757213593e-01
    z[7,2,4]  R1470     5.5943781137466431e-01
    z[7,2,4]  R1471     1.8434017896652222e-01
    z[7,2,4]  R1472     3.9101520180702209e-01
    z[7,2,4]  R1473     6.2802612781524658e-01
    z[7,2,4]  R1474     5.0317895412445068e-01
    z[7,2,4]  R1475     1.2057242542505264e-01
    z[7,2,4]  R1476     2.1572346985340118e-01
    z[7,2,4]  R1477     -2.7864813804626465e-01
    z[7,2,4]  R1478     -2.0015962421894073e-01
    z[7,2,4]  R1479     -5.9578165411949158e-02
    z[7,2,4]  R1480     1.1606896668672562e-01
    z[7,2,4]  R1481     5.0491452217102051e-01
    z[7,2,4]  R1482     6.3793194293975830e-01
    z[7,2,4]  R1483     6.8251579068601131e-03
    z[7,2,4]  R1484     3.2291319966316223e-01
    z[7,2,4]  R1485     4.9339967966079712e-01
    z[7,2,4]  R1486     2.7060031890869141e-01
    z[7,2,4]  R1487     2.3952074348926544e-01
    z[7,2,4]  R1488     -6.2229067087173462e-01
    z[7,2,4]  R1489     7.8987866640090942e-02
    z[7,2,4]  R1490     -2.5162476301193237e-01
    z[7,2,4]  R1491     -1.6484941542148590e-01
    z[7,2,4]  R1492     -4.0740302205085754e-01
    z[7,2,4]  R1493     -3.8552686572074890e-01
    z[7,2,4]  R1494     4.6498816460371017e-02
    z[7,2,4]  R1495     -3.8213570951484144e-04
    z[7,2,4]  R1496     -1.7301419377326965e-01
    z[7,2,4]  R1497     -6.8801701068878174e-02
    z[7,2,4]  R1498     -3.9071694016456604e-02
    z[7,2,4]  R1499     -4.2013868689537048e-01
    z[7,2,4]  R1500     4.0225276350975037e-01
    z[7,2,4]  R1501     7.1406906843185425e-01
    z[7,2,4]  R1502     4.3973532319068909e-01
    z[7,2,4]  R1503     -7.6233841478824615e-02
    z[7,2,4]  R1504     1.1470503360033035e-01
    z[7,2,4]  R1505     7.1103684604167938e-02
    z[7,2,4]  R1506     -3.1166917085647583e-01
    z[7,2,4]  R1507     3.1659644097089767e-02
    z[7,2,4]  R1508     1.4390356838703156e-01
    z[7,2,4]  R1509     2.5604346394538879e-01
    z[7,2,4]  R1510     -1.7262098193168640e-01
    z[7,2,4]  R1511     -1.1364775896072388e-01
    z[7,2,4]  R1512     -3.3513152599334717e-01
    z[7,2,4]  R1513     1.1817936599254608e-01
    z[7,2,4]  R1514     -1.2361352145671844e-01
    z[7,2,4]  R1515     2.6135078072547913e-01
    z[7,2,4]  R1516     3.0776894092559814e-01
    z[7,2,4]  R1517     4.1240427643060684e-02
    z[7,2,4]  R1518     -1.6916111111640930e-01
    z[7,2,4]  R1519     3.8667380809783936e-01
    z[7,2,4]  R1520     -2.5894564390182495e-01
    z[7,2,4]  R1521     -2.9697573184967041e-01
    z[7,2,4]  R1522     -1.2680433690547943e-01
    z[7,2,4]  R1523     2.6569423079490662e-01
    z[7,2,4]  R1524     0.0797264575958252
    z[7,2,4]  R1525     -9.9610462784767151e-02
    z[7,2,4]  R1526     -2.4736022949218750e-01
    z[7,2,4]  R1527     7.5029850006103516e-02
    z[7,2,4]  R1528     -1.2354150414466858e-02
    z[7,2,4]  R1529     7.8336149454116821e-02
    z[7,2,4]  R1530     1.5492191910743713e-01
    z[7,2,4]  R1531     0.0875663235783577
    z[7,2,4]  R1532     2.2947868704795837e-01
    z[7,2,4]  R1533     2.0054118335247040e-01
    z[7,2,4]  R1534     3.2300212979316711e-01
    z[7,2,4]  R1535     3.6831492185592651e-01
    z[7,2,4]  R1536     3.1155723333358765e-01
    z[7,2,4]  R1537     4.0080478787422180e-01
    z[7,2,4]  R1538     3.9789858460426331e-01
    z[7,2,4]  R1539     5.3485298156738281e-01
    z[7,2,4]  R1540     2.0066809654235840e-01
    z[7,2,4]  R1541     -1.9148169457912445e-01
    z[7,2,4]  R1542     -4.1219338774681091e-01
    z[7,2,4]  R1543     -5.5085223913192749e-01
    z[7,2,4]  R1544     -4.9488613009452820e-01
    z[7,2,4]  R1545     -7.1058726310729980e-01
    z[7,2,4]  R1546     1.6640616953372955e-01
    z[7,2,4]  R1547     3.5721543245017529e-03
    z[7,2,4]  R1548     -4.6340253949165344e-01
    z[7,2,4]  R1549     -2.2988986968994141e-01
    z[7,2,4]  R1550     -3.2883152365684509e-01
    z[7,2,4]  R1551     4.7746646404266357e-01
    z[7,2,4]  R1552     -1.1411070078611374e-01
    z[7,2,4]  R1553     -4.4207006692886353e-01
    z[7,2,4]  R1554     4.8652318120002747e-01
    z[7,2,4]  R1555     -8.9223784208297729e-01
    z[7,2,4]  R1556     -4.0364375710487366e-01
    z[7,2,4]  R1557     -4.2736896872520447e-01
    z[7,2,4]  R1558     -1.2966082990169525e-01
    z[7,2,4]  R1559     -0.33858522772789
    z[7,2,4]  R1560     -2.7010414004325867e-01
    z[7,2,4]  R1561     -9.6203640103340149e-02
    z[7,2,4]  R1562     -8.7878651916980743e-02
    z[7,2,4]  R1563     -4.3254595994949341e-01
    z[7,2,4]  R1564     -1.5487727522850037e-01
    z[7,2,4]  R1565     3.8389221299439669e-03
    z[7,2,4]  R1566     -5.9812910854816437e-02
    z[7,2,4]  R1567     -2.5321865081787109e-01
    z[7,2,4]  R1568     -2.3832413554191589e-01
    z[7,2,4]  R1569     -4.2883336544036865e-01
    z[7,2,5]  R25       1
    z[7,2,5]  R70       -1
    z[7,2,5]  R1446     -1
    z[7,2,5]  R1447     1
    z[7,2,5]  R1450     0.00815114751458168
    z[7,2,5]  R1451     1.6097424924373627e-01
    z[7,2,5]  R1452     -2.4331073462963104e-01
    z[7,2,5]  R1453     -2.3352622985839844e-01
    z[7,2,5]  R1454     -2.2083316743373871e-01
    z[7,2,5]  R1455     -5.2200831472873688e-02
    z[7,2,5]  R1456     5.9199732542037964e-01
    z[7,2,5]  R1457     3.0169311165809631e-01
    z[7,2,5]  R1458     1.8120923638343811e-01
    z[7,2,5]  R1459     -1.6136570274829865e-01
    z[7,2,5]  R1460     -3.1965515017509460e-01
    z[7,2,5]  R1461     -3.1550022959709167e-01
    z[7,2,5]  R1462     -2.1198825538158417e-01
    z[7,2,5]  R1463     -4.0874508023262024e-01
    z[7,2,5]  R1464     -2.1739758551120758e-01
    z[7,2,5]  R1465     -1.3742758333683014e-01
    z[7,2,5]  R1466     -3.5361200571060181e-01
    z[7,2,5]  R1467     -3.7164643406867981e-01
    z[7,2,5]  R1468     -3.7035247683525085e-01
    z[7,2,5]  R1469     -5.2202105522155762e-01
    z[7,2,5]  R1470     3.2202634215354919e-01
    z[7,2,5]  R1471     -1.7131336033344269e-01
    z[7,2,5]  R1472     -3.4875169396400452e-01
    z[7,2,5]  R1473     1.1485569924116135e-01
    z[7,2,5]  R1474     2.5832670927047729e-01
    z[7,2,5]  R1475     1.6578520834445953e-01
    z[7,2,5]  R1476     1.6976547241210938e-01
    z[7,2,5]  R1477     5.2896046638488770e-01
    z[7,2,5]  R1478     5.3319811820983887e-01
    z[7,2,5]  R1479     -7.9358108341693878e-03
    z[7,2,5]  R1480     4.1155338287353516e-01
    z[7,2,5]  R1481     5.7823747396469116e-01
    z[7,2,5]  R1482     -2.5613831356167793e-02
    z[7,2,5]  R1483     5.0028479099273682e-01
    z[7,2,5]  R1484     -1.8670815974473953e-02
    z[7,2,5]  R1485     1.6047197580337524e-01
    z[7,2,5]  R1486     3.6025676876306534e-02
    z[7,2,5]  R1487     1.9604517519474030e-01
    z[7,2,5]  R1488     -0.429318368434906
    z[7,2,5]  R1489     -1.7985065281391144e-01
    z[7,2,5]  R1490     -5.0258863717317581e-02
    z[7,2,5]  R1491     -0.50553959608078
    z[7,2,5]  R1492     -4.1002359986305237e-01
    z[7,2,5]  R1493     -2.0191858708858490e-01
    z[7,2,5]  R1494     1.1014650017023087e-01
    z[7,2,5]  R1495     -2.7247246354818344e-02
    z[7,2,5]  R1496     -6.9881081581115723e-02
    z[7,2,5]  R1497     2.1768143773078918e-01
    z[7,2,5]  R1498     -6.6732531785964966e-01
    z[7,2,5]  R1499     -6.9999217987060547e-01
    z[7,2,5]  R1500     4.3726280331611633e-01
    z[7,2,5]  R1501     1.4854957163333893e-01
    z[7,2,5]  R1502     1.5420123934745789e-01
    z[7,2,5]  R1503     -0.094334177672863
    z[7,2,5]  R1504     -2.8806936740875244e-01
    z[7,2,5]  R1505     3.0473349615931511e-02
    z[7,2,5]  R1506     7.1793437004089355e-02
    z[7,2,5]  R1507     -1.9304917752742767e-01
    z[7,2,5]  R1508     1.3385677337646484e-01
    z[7,2,5]  R1509     1.9853435456752777e-01
    z[7,2,5]  R1510     4.3308857083320618e-01
    z[7,2,5]  R1511     0.0741511881351471
    z[7,2,5]  R1512     -4.2723512649536133e-01
    z[7,2,5]  R1513     5.9995427727699280e-02
    z[7,2,5]  R1514     -3.5500192642211914e-01
    z[7,2,5]  R1515     2.8033751249313354e-01
    z[7,2,5]  R1516     -1.9317139685153961e-01
    z[7,2,5]  R1517     4.1094236075878143e-02
    z[7,2,5]  R1518     -2.1376991271972656e-01
    z[7,2,5]  R1519     -1.1652937391772866e-03
    z[7,2,5]  R1520     -3.0977943539619446e-01
    z[7,2,5]  R1521     -2.3032417893409729e-01
    z[7,2,5]  R1522     -3.0635091662406921e-01
    z[7,2,5]  R1523     -2.0247609913349152e-01
    z[7,2,5]  R1524     -4.3803164362907410e-01
    z[7,2,5]  R1525     2.7999192476272583e-01
    z[7,2,5]  R1526     -3.2522909343242645e-02
    z[7,2,5]  R1527     -5.5692322552204132e-02
    z[7,2,5]  R1528     -2.0731480792164803e-02
    z[7,2,5]  R1529     -2.1578426659107208e-01
    z[7,2,5]  R1530     3.4609884023666382e-01
    z[7,2,5]  R1531     4.6551403403282166e-01
    z[7,2,5]  R1532     6.5915763378143311e-01
    z[7,2,5]  R1533     3.9460220932960510e-01
    z[7,2,5]  R1534     0.192719966173172
    z[7,2,5]  R1535     5.6872242689132690e-01
    z[7,2,5]  R1536     4.4117224216461182e-01
    z[7,2,5]  R1537     2.8110796213150024e-01
    z[7,2,5]  R1538     1.1208473145961761e-01
    z[7,2,5]  R1539     2.7155107259750366e-01
    z[7,2,5]  R1540     -4.3861803412437439e-01
    z[7,2,5]  R1541     -6.7537024617195129e-02
    z[7,2,5]  R1542     1.7103704810142517e-01
    z[7,2,5]  R1543     -2.1028815209865570e-01
    z[7,2,5]  R1544     -2.4964958429336548e-01
    z[7,2,5]  R1545     -4.5664468407630920e-01
    z[7,2,5]  R1546     -2.9148340225219727e-01
    z[7,2,5]  R1547     -3.8634309172630310e-01
    z[7,2,5]  R1548     -3.6803993582725525e-01
    z[7,2,5]  R1549     -1.1284297704696655e-01
    z[7,2,5]  R1550     -5.3353202342987061e-01
    z[7,2,5]  R1551     1.7176094651222229e-01
    z[7,2,5]  R1552     4.9098852276802063e-01
    z[7,2,5]  R1553     -7.4825161695480347e-01
    z[7,2,5]  R1554     -1.3256806135177612e-01
    z[7,2,5]  R1555     1.5758083760738373e-01
    z[7,2,5]  R1556     -1.8381103873252869e-01
    z[7,2,5]  R1557     1.5108172781765461e-02
    z[7,2,5]  R1558     1.3056656718254089e-01
    z[7,2,5]  R1559     0.481060653924942
    z[7,2,5]  R1560     -9.0091437101364136e-02
    z[7,2,5]  R1561     -3.0887165665626526e-01
    z[7,2,5]  R1562     -9.2239004373550415e-01
    z[7,2,5]  R1563     -7.5115984678268433e-01
    z[7,2,5]  R1564     1.7373837530612946e-01
    z[7,2,5]  R1565     -2.7775179594755173e-02
    z[7,2,5]  R1566     -1.8732881546020508e-01
    z[7,2,5]  R1567     -1.5532526373863220e-01
    z[7,2,5]  R1568     -4.3492570519447327e-01
    z[7,2,5]  R1569     3.4181350469589233e-01
    z[7,2,6]  R26       1
    z[7,2,6]  R71       -1
    z[7,2,6]  R1448     -1
    z[7,2,6]  R1449     1
    z[7,2,6]  R1450     -8.5424654185771942e-02
    z[7,2,6]  R1451     1.4204651117324829e-01
    z[7,2,6]  R1452     -3.1563821434974670e-01
    z[7,2,6]  R1453     -3.3982202410697937e-02
    z[7,2,6]  R1454     -9.3037769198417664e-02
    z[7,2,6]  R1455     -2.5839787721633911e-01
    z[7,2,6]  R1456     -1.9042136147618294e-02
    z[7,2,6]  R1457     1.1859728395938873e-01
    z[7,2,6]  R1458     -1.7192541854456067e-03
    z[7,2,6]  R1459     -2.5719583034515381e-02
    z[7,2,6]  R1460     0.272826224565506
    z[7,2,6]  R1461     -1.4592908322811127e-01
    z[7,2,6]  R1462     0.0883352980017662
    z[7,2,6]  R1463     2.3601607978343964e-01
    z[7,2,6]  R1464     2.8957530856132507e-01
    z[7,2,6]  R1465     3.5161668062210083e-01
    z[7,2,6]  R1466     -2.2178536280989647e-02
    z[7,2,6]  R1467     -2.2910106182098389e-01
    z[7,2,6]  R1468     -0.279342383146286
    z[7,2,6]  R1469     6.8481385707855225e-02
    z[7,2,6]  R1470     2.2746691107749939e-01
    z[7,2,6]  R1471     2.7614927291870117e-01
    z[7,2,6]  R1472     -2.7461913228034973e-01
    z[7,2,6]  R1473     -4.0738663077354431e-01
    z[7,2,6]  R1474     -3.3743351697921753e-01
    z[7,2,6]  R1475     6.0053861141204834e-01
    z[7,2,6]  R1476     -2.7851322293281555e-01
    z[7,2,6]  R1477     -1.3669953681528568e-02
    z[7,2,6]  R1478     7.1014779806137085e-01
    z[7,2,6]  R1479     3.0918738245964050e-01
    z[7,2,6]  R1480     6.2395554780960083e-01
    z[7,2,6]  R1481     4.5911943912506104e-01
    z[7,2,6]  R1482     -2.8632143139839172e-01
    z[7,2,6]  R1483     1.2162868864834309e-02
    z[7,2,6]  R1484     -2.2372503578662872e-01
    z[7,2,6]  R1485     -5.6143510341644287e-01
    z[7,2,6]  R1486     5.4943454265594482e-01
    z[7,2,6]  R1487     -0.665951132774353
    z[7,2,6]  R1488     1.5840151906013489e-01
    z[7,2,6]  R1489     -2.1365078166127205e-02
    z[7,2,6]  R1490     1.5309567749500275e-01
    z[7,2,6]  R1491     4.5373108237981796e-02
    z[7,2,6]  R1492     -2.7633062005043030e-01
    z[7,2,6]  R1493     -3.1513014435768127e-01
    z[7,2,6]  R1494     -5.8834567666053772e-02
    z[7,2,6]  R1495     -1.0482275485992432e-01
    z[7,2,6]  R1496     -1.5043185651302338e-01
    z[7,2,6]  R1497     -1.1765944957733154e-01
    z[7,2,6]  R1498     1.9668446853756905e-02
    z[7,2,6]  R1499     -8.1644721329212189e-02
    z[7,2,6]  R1500     2.2319868206977844e-02
    z[7,2,6]  R1501     -2.9431256651878357e-01
    z[7,2,6]  R1502     3.7668031454086304e-01
    z[7,2,6]  R1503     -2.7511370182037354e-01
    z[7,2,6]  R1504     3.4089684486389160e-02
    z[7,2,6]  R1505     -1.6389900445938110e-01
    z[7,2,6]  R1506     2.8716831002384424e-04
    z[7,2,6]  R1507     1.8524080514907837e-01
    z[7,2,6]  R1508     -2.3157205432653427e-02
    z[7,2,6]  R1509     -3.3950844407081604e-01
    z[7,2,6]  R1510     -3.4378501772880554e-01
    z[7,2,6]  R1511     -5.8123809099197388e-01
    z[7,2,6]  R1512     -2.1278581023216248e-01
    z[7,2,6]  R1513     2.2819848358631134e-01
    z[7,2,6]  R1514     4.4436073303222656e-01
    z[7,2,6]  R1515     6.3039287924766541e-02
    z[7,2,6]  R1516     2.1365134045481682e-02
    z[7,2,6]  R1517     1.3199381530284882e-01
    z[7,2,6]  R1518     -1.1755295097827911e-01
    z[7,2,6]  R1519     -2.9218699783086777e-02
    z[7,2,6]  R1520     -3.6359116435050964e-01
    z[7,2,6]  R1521     4.8671197891235352e-01
    z[7,2,6]  R1522     1.2976335361599922e-02
    z[7,2,6]  R1523     1.9841415632981807e-04
    z[7,2,6]  R1524     2.5747016072273254e-01
    z[7,2,6]  R1525     -4.0895272046327591e-02
    z[7,2,6]  R1526     4.0123319625854492e-01
    z[7,2,6]  R1527     0.0415741428732872
    z[7,2,6]  R1528     -4.4453600049018860e-01
    z[7,2,6]  R1529     -4.2160528898239136e-01
    z[7,2,6]  R1530     -8.6947746574878693e-02
    z[7,2,6]  R1531     2.4069288372993469e-01
    z[7,2,6]  R1532     2.6291970163583755e-02
    z[7,2,6]  R1533     2.4520504474639893e-01
    z[7,2,6]  R1534     2.1488258242607117e-01
    z[7,2,6]  R1535     1.6737145185470581e-01
    z[7,2,6]  R1536     3.9287796616554260e-01
    z[7,2,6]  R1537     3.1707757711410522e-01
    z[7,2,6]  R1538     -1.3823526911437511e-02
    z[7,2,6]  R1539     -1.9499093294143677e-01
    z[7,2,6]  R1540     3.3367431163787842e-01
    z[7,2,6]  R1541     -9.4794243574142456e-02
    z[7,2,6]  R1542     3.8932305574417114e-01
    z[7,2,6]  R1543     -4.3811149895191193e-02
    z[7,2,6]  R1544     2.0110045373439789e-01
    z[7,2,6]  R1545     -8.5356742143630981e-02
    z[7,2,6]  R1546     -3.1291925907135010e-01
    z[7,2,6]  R1547     -1.1640454828739166e-01
    z[7,2,6]  R1548     6.2806069850921631e-02
    z[7,2,6]  R1549     -1.5487149357795715e-01
    z[7,2,6]  R1550     -2.8832051157951355e-01
    z[7,2,6]  R1551     1.5724253654479980e-01
    z[7,2,6]  R1552     -3.9755105972290039e-01
    z[7,2,6]  R1553     -1.4447268843650818e-01
    z[7,2,6]  R1554     -0.627393364906311
    z[7,2,6]  R1555     9.4787724316120148e-02
    z[7,2,6]  R1556     -0.618626058101654
    z[7,2,6]  R1557     -2.2545768320560455e-01
    z[7,2,6]  R1558     -1.1636500060558319e-01
    z[7,2,6]  R1559     7.9149333760142326e-03
    z[7,2,6]  R1560     6.7283022217452526e-03
    z[7,2,6]  R1561     -3.9602261781692505e-01
    z[7,2,6]  R1562     -3.3947536349296570e-01
    z[7,2,6]  R1563     2.0234017074108124e-01
    z[7,2,6]  R1564     -2.2302420809864998e-02
    z[7,2,6]  R1565     -1.0750397294759750e-01
    z[7,2,6]  R1566     3.0643166974186897e-02
    z[7,2,6]  R1567     1.7943707108497620e-01
    z[7,2,6]  R1568     -2.0033207535743713e-01
    z[7,2,6]  R1569     4.6682354062795639e-02
    z[3,4,0]  R29       -1
    z[3,4,0]  R38       1
    z[3,4,0]  R1634     -1
    z[3,4,0]  R1635     1
    z[3,4,0]  R1648     4.3805766105651855e-01
    z[3,4,0]  R1649     0.417502224445343
    z[3,4,0]  R1650     0.575057327747345
    z[3,4,0]  R1651     7.2431176900863647e-02
    z[3,4,0]  R1652     1.5262040495872498e-01
    z[3,4,0]  R1653     4.0876439213752747e-01
    z[3,4,0]  R1654     2.4220088124275208e-01
    z[3,4,0]  R1655     2.1401388943195343e-01
    z[3,4,0]  R1656     4.3158498406410217e-01
    z[3,4,0]  R1657     7.0104628801345825e-01
    z[3,4,0]  R1658     8.0959171056747437e-01
    z[3,4,0]  R1659     6.4698415994644165e-01
    z[3,4,0]  R1660     7.3615294694900513e-01
    z[3,4,0]  R1661     7.3598664999008179e-01
    z[3,4,0]  R1662     7.0550125837326050e-01
    z[3,4,0]  R1663     6.3437575101852417e-01
    z[3,4,0]  R1664     5.7536059617996216e-01
    z[3,4,0]  R1665     5.6623983383178711e-01
    z[3,4,0]  R1666     6.3096511363983154e-01
    z[3,4,0]  R1667     6.5490937232971191e-01
    z[3,4,0]  R1668     -1.9726440310478210e-01
    z[3,4,0]  R1669     -1.0529028624296188e-01
    z[3,4,0]  R1670     -7.1863353252410889e-01
    z[3,4,0]  R1671     -7.8457134962081909e-01
    z[3,4,0]  R1672     -0.79290771484375
    z[3,4,0]  R1673     -7.3468130826950073e-01
    z[3,4,0]  R1674     -6.3682740926742554e-01
    z[3,4,0]  R1675     -6.2035316228866577e-01
    z[3,4,0]  R1676     -6.7900937795639038e-01
    z[3,4,0]  R1677     -6.7543321847915649e-01
    z[3,4,0]  R1678     4.1349714994430542e-01
    z[3,4,0]  R1679     5.1700967550277710e-01
    z[3,4,0]  R1680     -1.0512983798980713e-01
    z[3,4,0]  R1681     -1.7748099565505981e-01
    z[3,4,0]  R1682     -7.1416527032852173e-01
    z[3,4,0]  R1683     -7.9319137334823608e-01
    z[3,4,0]  R1684     -1.2548317201435566e-02
    z[3,4,0]  R1685     -7.7411487698554993e-02
    z[3,4,0]  R1686     -8.6458724737167358e-01
    z[3,4,0]  R1687     -9.1031205654144287e-01
    z[3,4,0]  R1688     7.3104846477508545e-01
    z[3,4,0]  R1689     2.9177516698837280e-01
    z[3,4,0]  R1690     2.8340291976928711e-01
    z[3,4,0]  R1691     -4.5324318110942841e-02
    z[3,4,0]  R1692     1.8512003123760223e-01
    z[3,4,0]  R1693     -1.1372501403093338e-01
    z[3,4,0]  R1694     5.3195875138044357e-02
    z[3,4,0]  R1695     -6.2801039218902588e-01
    z[3,4,0]  R1696     1.1845371872186661e-01
    z[3,4,0]  R1697     -7.9882496595382690e-01
    z[3,4,0]  R1698     0.524105429649353
    z[3,4,0]  R1699     4.0315771102905273e-01
    z[3,4,0]  R1700     2.0439341664314270e-01
    z[3,4,0]  R1701     0.686012327671051
    z[3,4,0]  R1702     -7.8146022558212280e-01
    z[3,4,0]  R1703     -8.6590969562530518e-01
    z[3,4,0]  R1704     -7.6497918367385864e-01
    z[3,4,0]  R1705     -8.5123002529144287e-01
    z[3,4,0]  R1706     -8.9121866226196289e-01
    z[3,4,0]  R1707     -0.826116681098938
    z[3,4,0]  R1708     5.2226793766021729e-01
    z[3,4,0]  R1709     4.6512582898139954e-01
    z[3,4,0]  R1710     1.1516742408275604e-01
    z[3,4,0]  R1711     3.5153231024742126e-01
    z[3,4,0]  R1712     5.0296396017074585e-01
    z[3,4,0]  R1713     -5.8018577098846436e-01
    z[3,4,0]  R1714     -8.2047873735427856e-01
    z[3,4,0]  R1715     -8.1746226549148560e-01
    z[3,4,0]  R1716     -8.9487850666046143e-01
    z[3,4,0]  R1717     8.7175302207469940e-02
    z[3,4,0]  R1718     1.8273948132991791e-01
    z[3,4,0]  R1719     7.5243353843688965e-02
    z[3,4,0]  R1720     -2.0890556275844574e-01
    z[3,4,0]  R1721     6.4720004796981812e-01
    z[3,4,0]  R1722     2.2473375499248505e-01
    z[3,4,0]  R1723     3.4467941522598267e-01
    z[3,4,0]  R1724     -1.7299796640872955e-01
    z[3,4,0]  R1725     2.0742221176624298e-01
    z[3,4,0]  R1726     6.4767844974994659e-02
    z[3,4,0]  R1727     2.0509274303913116e-01
    z[3,4,0]  R1728     -1.0053467005491257e-01
    z[3,4,0]  R1729     1.3686452805995941e-01
    z[3,4,0]  R1730     -1.1812112480401993e-01
    z[3,4,0]  R1731     1.1632069945335388e-01
    z[3,4,0]  R1732     -4.2024865746498108e-02
    z[3,4,0]  R1733     2.4728041887283325e-01
    z[3,4,0]  R1734     3.3589640259742737e-01
    z[3,4,0]  R1735     -0.0842878594994545
    z[3,4,0]  R1736     -0.0749136209487915
    z[3,4,0]  R1737     6.1640333384275436e-02
    z[3,4,0]  R1738     -3.2477363944053650e-02
    z[3,4,0]  R1739     -1.2521438300609589e-01
    z[3,4,0]  R1740     -9.0394169092178345e-02
    z[3,4,0]  R1741     -1.7760178446769714e-01
    z[3,4,0]  R1742     0.206633523106575
    z[3,4,0]  R1743     2.0787317771464586e-03
    z[3,4,0]  R1744     -1.7261725664138794e-01
    z[3,4,0]  R1745     1.8793597817420959e-01
    z[3,4,0]  R1746     -7.3890708386898041e-02
    z[3,4,0]  R1747     -5.5151319503784180e-01
    z[3,4,0]  R1748     8.4341593086719513e-02
    z[3,4,0]  R1749     -2.9460051655769348e-01
    z[3,4,0]  R1750     2.2809910774230957e-01
    z[3,4,0]  R1751     1.8554365634918213e-01
    z[3,4,0]  R1752     -1.5891253948211670e-01
    z[3,4,0]  R1753     2.3968566954135895e-01
    z[3,4,0]  R1754     1.2430764734745026e-01
    z[3,4,0]  R1755     -1.7151252925395966e-01
    z[3,4,0]  R1756     -3.8300785422325134e-01
    z[3,4,0]  R1757     -2.5668612122535706e-01
    z[3,4,0]  R1758     -1.6947200521826744e-02
    z[3,4,0]  R1759     3.4027022123336792e-01
    z[3,4,0]  R1760     2.6533061265945435e-01
    z[3,4,0]  R1761     -2.0327101647853851e-01
    z[3,4,0]  R1762     -9.8297879099845886e-02
    z[3,4,0]  R1763     -4.8372265696525574e-01
    z[3,4,0]  R1764     -1.4247813820838928e-01
    z[3,4,0]  R1765     -5.4091745615005493e-01
    z[3,4,0]  R1766     -4.2434650659561157e-01
    z[3,4,0]  R1767     -6.4929658174514771e-01
    z[3,4,1]  R30       -1
    z[3,4,1]  R39       1
    z[3,4,1]  R1636     -1
    z[3,4,1]  R1637     1
    z[3,4,1]  R1648     -7.4315059185028076e-01
    z[3,4,1]  R1649     -6.4629071950912476e-01
    z[3,4,1]  R1650     -5.4676425457000732e-01
    z[3,4,1]  R1651     -7.6116353273391724e-01
    z[3,4,1]  R1652     -6.2137299776077271e-01
    z[3,4,1]  R1653     -4.7046065330505371e-01
    z[3,4,1]  R1654     -4.7412568330764771e-01
    z[3,4,1]  R1655     -5.4200416803359985e-01
    z[3,4,1]  R1656     -3.9279901981353760e-01
    z[3,4,1]  R1657     -4.4781142473220825e-01
    z[3,4,1]  R1658     4.3983411788940430e-01
    z[3,4,1]  R1659     4.2036175727844238e-01
    z[3,4,1]  R1660     5.3850877285003662e-01
    z[3,4,1]  R1661     2.9302990436553955e-01
    z[3,4,1]  R1662     4.8259556293487549e-01
    z[3,4,1]  R1663     4.1428366303443909e-01
    z[3,4,1]  R1664     6.3172364234924316e-01
    z[3,4,1]  R1665     4.1547408699989319e-01
    z[3,4,1]  R1666     3.5577812790870667e-01
    z[3,4,1]  R1667     5.5575639009475708e-01
    z[3,4,1]  R1668     -5.0551635026931763e-01
    z[3,4,1]  R1669     -6.2404167652130127e-01
    z[3,4,1]  R1670     3.2444596290588379e-01
    z[3,4,1]  R1671     1.3832947611808777e-01
    z[3,4,1]  R1672     3.6259597539901733e-01
    z[3,4,1]  R1673     0.476630836725235
    z[3,4,1]  R1674     5.2922356128692627e-01
    z[3,4,1]  R1675     4.3140381574630737e-01
    z[3,4,1]  R1676     5.2916640043258667e-01
    z[3,4,1]  R1677     5.5091768503189087e-01
    z[3,4,1]  R1678     -2.2911764681339264e-01
    z[3,4,1]  R1679     3.1199318170547485e-01
    z[3,4,1]  R1680     3.6908298730850220e-01
    z[3,4,1]  R1681     0.517268180847168
    z[3,4,1]  R1682     3.4748798608779907e-01
    z[3,4,1]  R1683     -0.525443971157074
    z[3,4,1]  R1684     -2.8569707274436951e-01
    z[3,4,1]  R1685     -2.5481000542640686e-01
    z[3,4,1]  R1686     -3.9693346619606018e-01
    z[3,4,1]  R1687     -2.4970203638076782e-01
    z[3,4,1]  R1688     3.6790484189987183e-01
    z[3,4,1]  R1689     4.9255335330963135e-01
    z[3,4,1]  R1690     8.3790290355682373e-01
    z[3,4,1]  R1691     0.460196852684021
    z[3,4,1]  R1692     -4.7581657767295837e-02
    z[3,4,1]  R1693     3.6662113666534424e-01
    z[3,4,1]  R1694     5.3846889734268188e-01
    z[3,4,1]  R1695     3.4729701280593872e-01
    z[3,4,1]  R1696     5.4520481824874878e-01
    z[3,4,1]  R1697     1.6787196695804596e-01
    z[3,4,1]  R1698     -5.1416093111038208e-01
    z[3,4,1]  R1699     -1.9312760233879089e-01
    z[3,4,1]  R1700     6.2209200859069824e-01
    z[3,4,1]  R1701     -0.256678968667984
    z[3,4,1]  R1702     3.0892390012741089e-01
    z[3,4,1]  R1703     1.2741953134536743e-01
    z[3,4,1]  R1704     4.0049365162849426e-01
    z[3,4,1]  R1705     3.3169683814048767e-01
    z[3,4,1]  R1706     1.0963108390569687e-01
    z[3,4,1]  R1707     2.1821531653404236e-01
    z[3,4,1]  R1708     -3.7440881133079529e-01
    z[3,4,1]  R1709     -0.374693363904953
    z[3,4,1]  R1710     -4.1260075569152832e-01
    z[3,4,1]  R1711     0.281189888715744
    z[3,4,1]  R1712     -2.9525252059102058e-02
    z[3,4,1]  R1713     -2.7286946773529053e-01
    z[3,4,1]  R1714     -4.3413645029067993e-01
    z[3,4,1]  R1715     0.0749564915895462
    z[3,4,1]  R1716     -2.5474876165390015e-01
    z[3,4,1]  R1717     -3.6620470881462097e-01
    z[3,4,1]  R1718     -8.1072676181793213e-01
    z[3,4,1]  R1719     -6.7871409654617310e-01
    z[3,4,1]  R1720     -6.7564535140991211e-01
    z[3,4,1]  R1721     -6.3561600446701050e-01
    z[3,4,1]  R1722     -4.6969485282897949e-01
    z[3,4,1]  R1723     -6.1447870731353760e-01
    z[3,4,1]  R1724     -4.5773589611053467e-01
    z[3,4,1]  R1725     -5.2216702699661255e-01
    z[3,4,1]  R1726     -4.9167856574058533e-01
    z[3,4,1]  R1727     -5.1526272296905518e-01
    z[3,4,1]  R1728     9.1978579759597778e-01
    z[3,4,1]  R1729     9.0769237279891968e-01
    z[3,4,1]  R1730     8.8948029279708862e-01
    z[3,4,1]  R1731     8.7213045358657837e-01
    z[3,4,1]  R1732     8.9554357528686523e-01
    z[3,4,1]  R1733     0.841696560382843
    z[3,4,1]  R1734     8.5505813360214233e-01
    z[3,4,1]  R1735     8.2347893714904785e-01
    z[3,4,1]  R1736     8.3122414350509644e-01
    z[3,4,1]  R1737     8.2374644279479980e-01
    z[3,4,1]  R1738     6.2490773200988770e-01
    z[3,4,1]  R1739     -4.6254453063011169e-01
    z[3,4,1]  R1740     -3.9497679471969604e-01
    z[3,4,1]  R1741     -4.7766700387001038e-01
    z[3,4,1]  R1742     -1.5034003555774689e-01
    z[3,4,1]  R1743     -4.6923229098320007e-01
    z[3,4,1]  R1744     -0.536043643951416
    z[3,4,1]  R1745     -4.5698961615562439e-01
    z[3,4,1]  R1746     3.9782455563545227e-01
    z[3,4,1]  R1747     -1.7178170382976532e-01
    z[3,4,1]  R1748     -8.6554270982742310e-01
    z[3,4,1]  R1749     -6.4300930500030518e-01
    z[3,4,1]  R1750     8.4201908111572266e-01
    z[3,4,1]  R1751     -7.0415306091308594e-01
    z[3,4,1]  R1752     -7.0064681768417358e-01
    z[3,4,1]  R1753     -3.7490347027778625e-01
    z[3,4,1]  R1754     -3.7599790096282959e-01
    z[3,4,1]  R1755     0.580936849117279
    z[3,4,1]  R1756     4.4202911853790283e-01
    z[3,4,1]  R1757     1.0483112186193466e-01
    z[3,4,1]  R1758     -8.6755198240280151e-01
    z[3,4,1]  R1759     -8.3970564603805542e-01
    z[3,4,1]  R1760     -7.3522913455963135e-01
    z[3,4,1]  R1761     6.9517850875854492e-01
    z[3,4,1]  R1762     9.3139477074146271e-02
    z[3,4,1]  R1763     -5.8083377778530121e-02
    z[3,4,1]  R1764     2.4324165657162666e-02
    z[3,4,1]  R1765     -4.4814877212047577e-02
    z[3,4,1]  R1766     -3.8592919707298279e-02
    z[3,4,1]  R1767     -2.4696400389075279e-02
    z[3,4,2]  R31       -1
    z[3,4,2]  R40       1
    z[3,4,2]  R1638     -1
    z[3,4,2]  R1639     1
    z[3,4,2]  R1648     -2.5924375653266907e-01
    z[3,4,2]  R1649     9.1730482876300812e-02
    z[3,4,2]  R1650     4.8309704661369324e-01
    z[3,4,2]  R1651     9.3876376748085022e-02
    z[3,4,2]  R1652     3.8764795660972595e-01
    z[3,4,2]  R1653     -0.00233491905964911
    z[3,4,2]  R1654     -0.00865908246487379
    z[3,4,2]  R1655     5.1715171337127686e-01
    z[3,4,2]  R1656     8.3564911037683487e-03
    z[3,4,2]  R1657     1.9294353201985359e-02
    z[3,4,2]  R1658     -2.1823914349079132e-01
    z[3,4,2]  R1659     -3.9614400267601013e-01
    z[3,4,2]  R1660     -3.5059735178947449e-01
    z[3,4,2]  R1661     -3.1809780001640320e-01
    z[3,4,2]  R1662     -3.2828783988952637e-01
    z[3,4,2]  R1663     -5.7305407524108887e-01
    z[3,4,2]  R1664     1.7797026038169861e-01
    z[3,4,2]  R1665     3.8262477517127991e-01
    z[3,4,2]  R1666     1.4956396818161011e-01
    z[3,4,2]  R1667     2.2001340985298157e-01
    z[3,4,2]  R1668     3.6332961916923523e-01
    z[3,4,2]  R1669     -2.7133089303970337e-01
    z[3,4,2]  R1670     -1.6312594711780548e-01
    z[3,4,2]  R1671     -4.2357784695923328e-03
    z[3,4,2]  R1672     -1.2825167179107666e-01
    z[3,4,2]  R1673     1.2461613118648529e-01
    z[3,4,2]  R1674     8.4123559296131134e-02
    z[3,4,2]  R1675     1.0180328786373138e-01
    z[3,4,2]  R1676     -1.1466205865144730e-01
    z[3,4,2]  R1677     1.6040942072868347e-01
    z[3,4,2]  R1678     2.4013815820217133e-01
    z[3,4,2]  R1679     3.6817422509193420e-01
    z[3,4,2]  R1680     -1.8781460821628571e-01
    z[3,4,2]  R1681     -2.0988664031028748e-01
    z[3,4,2]  R1682     -5.1806366443634033e-01
    z[3,4,2]  R1683     -1.5469801425933838e-01
    z[3,4,2]  R1684     -3.6768436431884766e-01
    z[3,4,2]  R1685     -3.9628565311431885e-01
    z[3,4,2]  R1686     -1.6091901063919067e-01
    z[3,4,2]  R1687     -1.0736337304115295e-01
    z[3,4,2]  R1688     3.1245386600494385e-01
    z[3,4,2]  R1689     9.0317949652671814e-02
    z[3,4,2]  R1690     1.5061146020889282e-01
    z[3,4,2]  R1691     -7.1832996606826782e-01
    z[3,4,2]  R1692     1.0902821272611618e-01
    z[3,4,2]  R1693     -4.9349340796470642e-01
    z[3,4,2]  R1694     -2.2480714321136475e-01
    z[3,4,2]  R1695     0.60881507396698
    z[3,4,2]  R1696     -3.0338427051901817e-02
    z[3,4,2]  R1697     4.3201163411140442e-01
    z[3,4,2]  R1698     -8.8836506009101868e-02
    z[3,4,2]  R1699     -3.0723696947097778e-01
    z[3,4,2]  R1700     -3.7479674816131592e-01
    z[3,4,2]  R1701     1.1668688803911209e-01
    z[3,4,2]  R1702     -2.1206364035606384e-01
    z[3,4,2]  R1703     -3.5514822602272034e-01
    z[3,4,2]  R1704     3.0323070287704468e-01
    z[3,4,2]  R1705     -5.6406762450933456e-03
    z[3,4,2]  R1706     2.9734751582145691e-01
    z[3,4,2]  R1707     -2.9981845617294312e-01
    z[3,4,2]  R1708     -9.7930260002613068e-02
    z[3,4,2]  R1709     1.9548104703426361e-01
    z[3,4,2]  R1710     -4.7278085350990295e-01
    z[3,4,2]  R1711     -3.1819036602973938e-01
    z[3,4,2]  R1712     5.8277076482772827e-01
    z[3,4,2]  R1713     -2.1691782400012016e-02
    z[3,4,2]  R1714     -9.2265717685222626e-02
    z[3,4,2]  R1715     3.5283961892127991e-01
    z[3,4,2]  R1716     8.4181100130081177e-02
    z[3,4,2]  R1717     5.7402491569519043e-02
    z[3,4,2]  R1718     4.6575747430324554e-02
    z[3,4,2]  R1719     -4.4898384809494019e-01
    z[3,4,2]  R1720     -3.9891722798347473e-01
    z[3,4,2]  R1721     -1.3940635323524475e-01
    z[3,4,2]  R1722     -0.392828106880188
    z[3,4,2]  R1723     -3.9671313762664795e-01
    z[3,4,2]  R1724     -1.5920653939247131e-02
    z[3,4,2]  R1725     3.0823811888694763e-01
    z[3,4,2]  R1726     -1.7982932925224304e-01
    z[3,4,2]  R1727     4.2525655031204224e-01
    z[3,4,2]  R1728     1.4306181669235229e-01
    z[3,4,2]  R1729     -1.1526767164468765e-01
    z[3,4,2]  R1730     -2.4151550233364105e-01
    z[3,4,2]  R1731     1.8396852910518646e-01
    z[3,4,2]  R1732     -4.1573038697242737e-01
    z[3,4,2]  R1733     2.9827040433883667e-01
    z[3,4,2]  R1734     2.0655937492847443e-01
    z[3,4,2]  R1735     4.3210950493812561e-01
    z[3,4,2]  R1736     2.8976443409919739e-01
    z[3,4,2]  R1737     2.5015175342559814e-01
    z[3,4,2]  R1738     -1.1019866913557053e-01
    z[3,4,2]  R1739     5.0250756740570068e-01
    z[3,4,2]  R1740     5.8804297447204590e-01
    z[3,4,2]  R1741     6.0417884588241577e-01
    z[3,4,2]  R1742     6.4746642112731934e-01
    z[3,4,2]  R1743     1.5681222081184387e-01
    z[3,4,2]  R1744     1.3179703056812286e-01
    z[3,4,2]  R1745     -4.0013585239648819e-02
    z[3,4,2]  R1746     -0.195712149143219
    z[3,4,2]  R1747     -1.1446216702461243e-01
    z[3,4,2]  R1748     3.0641865730285645e-01
    z[3,4,2]  R1749     6.6967093944549561e-01
    z[3,4,2]  R1750     -1.8188336491584778e-01
    z[3,4,2]  R1751     -3.5695701837539673e-01
    z[3,4,2]  R1752     0.272125780582428
    z[3,4,2]  R1753     7.3076236248016357e-01
    z[3,4,2]  R1754     4.7682681679725647e-01
    z[3,4,2]  R1755     5.7388770580291748e-01
    z[3,4,2]  R1756     -2.4268349632620811e-02
    z[3,4,2]  R1757     -1.3904811441898346e-01
    z[3,4,2]  R1758     1.0298167914152145e-01
    z[3,4,2]  R1759     2.3890449106693268e-01
    z[3,4,2]  R1760     0.562421441078186
    z[3,4,2]  R1761     1.2121919542551041e-01
    z[3,4,2]  R1762     -3.0836266279220581e-01
    z[3,4,2]  R1763     -5.7609234005212784e-02
    z[3,4,2]  R1764     -2.4657705426216125e-01
    z[3,4,2]  R1765     1.0175630450248718e-01
    z[3,4,2]  R1766     -1.5905712544918060e-01
    z[3,4,2]  R1767     1.7889384925365448e-01
    z[3,4,3]  R32       -1
    z[3,4,3]  R41       1
    z[3,4,3]  R1640     -1
    z[3,4,3]  R1641     1
    z[3,4,3]  R1648     -2.3028573393821716e-01
    z[3,4,3]  R1649     -3.9770260453224182e-01
    z[3,4,3]  R1650     -1.9360916316509247e-01
    z[3,4,3]  R1651     -0.411496102809906
    z[3,4,3]  R1652     -0.531631350517273
    z[3,4,3]  R1653     -6.0601687431335449e-01
    z[3,4,3]  R1654     -8.1906592845916748e-01
    z[3,4,3]  R1655     -5.9192508459091187e-01
    z[3,4,3]  R1656     -6.6998499631881714e-01
    z[3,4,3]  R1657     -5.4565912485122681e-01
    z[3,4,3]  R1658     2.2777134180068970e-01
    z[3,4,3]  R1659     4.9239867925643921e-01
    z[3,4,3]  R1660     1.3949842751026154e-01
    z[3,4,3]  R1661     4.3091511726379395e-01
    z[3,4,3]  R1662     2.8371140360832214e-01
    z[3,4,3]  R1663     9.3603268265724182e-02
    z[3,4,3]  R1664     3.9086464047431946e-01
    z[3,4,3]  R1665     5.6015163660049438e-01
    z[3,4,3]  R1666     5.0423681735992432e-01
    z[3,4,3]  R1667     0.244984433054924
    z[3,4,3]  R1668     7.1642976999282837e-01
    z[3,4,3]  R1669     5.9662669897079468e-01
    z[3,4,3]  R1670     -5.3482079505920410e-01
    z[3,4,3]  R1671     -5.9529459476470947e-01
    z[3,4,3]  R1672     -3.5588398575782776e-01
    z[3,4,3]  R1673     -3.5378125309944153e-01
    z[3,4,3]  R1674     -5.3700417280197144e-01
    z[3,4,3]  R1675     -5.7328951358795166e-01
    z[3,4,3]  R1676     -4.2559444904327393e-01
    z[3,4,3]  R1677     -3.9520761370658875e-01
    z[3,4,3]  R1678     4.8846620321273804e-01
    z[3,4,3]  R1679     -2.5209185481071472e-01
    z[3,4,3]  R1680     3.9737510681152344e-01
    z[3,4,3]  R1681     2.4219667911529541e-01
    z[3,4,3]  R1682     -2.5597441941499710e-02
    z[3,4,3]  R1683     -2.1603195369243622e-01
    z[3,4,3]  R1684     -1.7789797484874725e-01
    z[3,4,3]  R1685     -2.3374319076538086e-01
    z[3,4,3]  R1686     4.4634109362959862e-03
    z[3,4,3]  R1687     -6.6339030861854553e-02
    z[3,4,3]  R1688     -4.6688544750213623e-01
    z[3,4,3]  R1689     -1.5835982561111450e-01
    z[3,4,3]  R1690     -1.8619684875011444e-01
    z[3,4,3]  R1691     1.5709747374057770e-01
    z[3,4,3]  R1692     9.1810613870620728e-01
    z[3,4,3]  R1693     2.7690944075584412e-01
    z[3,4,3]  R1694     -5.3713542222976685e-01
    z[3,4,3]  R1695     -3.0108150839805603e-01
    z[3,4,3]  R1696     -5.8500421047210693e-01
    z[3,4,3]  R1697     -9.2559941112995148e-02
    z[3,4,3]  R1698     4.6010515093803406e-01
    z[3,4,3]  R1699     5.2026033401489258e-01
    z[3,4,3]  R1700     -4.6925750374794006e-01
    z[3,4,3]  R1701     0.349550724029541
    z[3,4,3]  R1702     -2.4423709511756897e-01
    z[3,4,3]  R1703     -1.5320216119289398e-01
    z[3,4,3]  R1704     -1.4417918026447296e-01
    z[3,4,3]  R1705     -2.4125318974256516e-02
    z[3,4,3]  R1706     -1.8347722291946411e-01
    z[3,4,3]  R1707     -9.7090564668178558e-02
    z[3,4,3]  R1708     6.2152963876724243e-01
    z[3,4,3]  R1709     5.3341861814260483e-02
    z[3,4,3]  R1710     4.5880961418151855e-01
    z[3,4,3]  R1711     -7.9395341873168945e-01
    z[3,4,3]  R1712     3.8047265261411667e-02
    z[3,4,3]  R1713     6.0204431414604187e-02
    z[3,4,3]  R1714     2.0130556821823120e-01
    z[3,4,3]  R1715     -1.3111500442028046e-01
    z[3,4,3]  R1716     1.4534957706928253e-01
    z[3,4,3]  R1717     1.8573263287544250e-01
    z[3,4,3]  R1718     -3.2698315382003784e-01
    z[3,4,3]  R1719     -4.0670457482337952e-01
    z[3,4,3]  R1720     -3.6919006705284119e-01
    z[3,4,3]  R1721     7.1565821766853333e-02
    z[3,4,3]  R1722     -7.1684509515762329e-01
    z[3,4,3]  R1723     -1.7682163417339325e-01
    z[3,4,3]  R1724     -8.5256582498550415e-01
    z[3,4,3]  R1725     -0.595733106136322
    z[3,4,3]  R1726     -4.8289006948471069e-01
    z[3,4,3]  R1727     -3.4410575032234192e-01
    z[3,4,3]  R1728     3.2040110230445862e-01
    z[3,4,3]  R1729     -3.5573536157608032e-01
    z[3,4,3]  R1730     -6.2316235154867172e-02
    z[3,4,3]  R1731     -3.5193055868148804e-01
    z[3,4,3]  R1732     -9.4288922846317291e-02
    z[3,4,3]  R1733     -2.3346070945262909e-01
    z[3,4,3]  R1734     -6.5149967558681965e-03
    z[3,4,3]  R1735     -3.7961628288030624e-02
    z[3,4,3]  R1736     -8.3082199096679688e-02
    z[3,4,3]  R1737     -1.7763453722000122e-01
    z[3,4,3]  R1738     -3.2958149909973145e-01
    z[3,4,3]  R1739     6.0544097423553467e-01
    z[3,4,3]  R1740     0.659436047077179
    z[3,4,3]  R1741     3.0554351210594177e-01
    z[3,4,3]  R1742     4.1048571467399597e-01
    z[3,4,3]  R1743     6.0898989439010620e-01
    z[3,4,3]  R1744     4.5346373319625854e-01
    z[3,4,3]  R1745     5.7801395654678345e-01
    z[3,4,3]  R1746     6.9905549287796021e-02
    z[3,4,3]  R1747     7.0637071132659912e-01
    z[3,4,3]  R1748     -1.6438831388950348e-01
    z[3,4,3]  R1749     -6.8297930993139744e-03
    z[3,4,3]  R1750     1.5079972147941589e-01
    z[3,4,3]  R1751     5.4189282655715942e-01
    z[3,4,3]  R1752     3.8812670111656189e-01
    z[3,4,3]  R1753     4.8228484392166138e-01
    z[3,4,3]  R1754     5.7043421268463135e-01
    z[3,4,3]  R1755     -1.8974894285202026e-01
    z[3,4,3]  R1756     -1.1921525001525879e-01
    z[3,4,3]  R1757     5.4200851917266846e-01
    z[3,4,3]  R1758     -2.6978492736816406e-01
    z[3,4,3]  R1759     2.2138184309005737e-01
    z[3,4,3]  R1760     1.6960693895816803e-01
    z[3,4,3]  R1761     -0.569624662399292
    z[3,4,3]  R1762     6.6334950923919678e-01
    z[3,4,3]  R1763     7.2761672735214233e-01
    z[3,4,3]  R1764     0.734235405921936
    z[3,4,3]  R1765     5.1514565944671631e-01
    z[3,4,3]  R1766     6.0097473859786987e-01
    z[3,4,3]  R1767     3.8841915130615234e-01
    z[3,4,4]  R33       -1
    z[3,4,4]  R42       1
    z[3,4,4]  R1642     -1
    z[3,4,4]  R1643     1
    z[3,4,4]  R1648     0.313882052898407
    z[3,4,4]  R1649     -0.17757648229599
    z[3,4,4]  R1650     2.2189372777938843e-01
    z[3,4,4]  R1651     1.3936987519264221e-01
    z[3,4,4]  R1652     8.0580234527587891e-02
    z[3,4,4]  R1653     3.1831413507461548e-01
    z[3,4,4]  R1654     -0.0188454482704401
    z[3,4,4]  R1655     1.6043645143508911e-01
    z[3,4,4]  R1656     3.3634293079376221e-01
    z[3,4,4]  R1657     5.3304746747016907e-02
    z[3,4,4]  R1658     -4.5975916087627411e-02
    z[3,4,4]  R1659     4.6409916132688522e-02
    z[3,4,4]  R1660     1.0899879038333893e-01
    z[3,4,4]  R1661     -2.2519369423389435e-01
    z[3,4,4]  R1662     -1.8193525075912476e-01
    z[3,4,4]  R1663     -1.2886960804462433e-01
    z[3,4,4]  R1664     2.3661321401596069e-01
    z[3,4,4]  R1665     6.2497023493051529e-02
    z[3,4,4]  R1666     7.5856409966945648e-02
    z[3,4,4]  R1667     -1.9202180206775665e-01
    z[3,4,4]  R1668     1.3539313338696957e-02
    z[3,4,4]  R1669     -0.0705077275633812
    z[3,4,4]  R1670     2.4219135940074921e-01
    z[3,4,4]  R1671     4.8514604568481445e-02
    z[3,4,4]  R1672     -0.034210454672575
    z[3,4,4]  R1673     -1.3851335644721985e-01
    z[3,4,4]  R1674     -9.0229168534278870e-02
    z[3,4,4]  R1675     2.8347185254096985e-01
    z[3,4,4]  R1676     7.8540280461311340e-02
    z[3,4,4]  R1677     -0.149052694439888
    z[3,4,4]  R1678     -3.3165118098258972e-01
    z[3,4,4]  R1679     4.7080585360527039e-01
    z[3,4,4]  R1680     1.0023064911365509e-01
    z[3,4,4]  R1681     -1.9911248981952667e-01
    z[3,4,4]  R1682     -2.5786471366882324e-01
    z[3,4,4]  R1683     -1.5476179122924805e-01
    z[3,4,4]  R1684     -5.5405050516128540e-01
    z[3,4,4]  R1685     -2.6255378127098083e-01
    z[3,4,4]  R1686     4.4327285140752792e-03
    z[3,4,4]  R1687     -1.2686847150325775e-01
    z[3,4,4]  R1688     4.2611941695213318e-02
    z[3,4,4]  R1689     -2.5303918123245239e-01
    z[3,4,4]  R1690     -9.9313586950302124e-02
    z[3,4,4]  R1691     1.6156564652919769e-01
    z[3,4,4]  R1692     -1.4396056532859802e-01
    z[3,4,4]  R1693     -2.7360531687736511e-01
    z[3,4,4]  R1694     2.3966661095619202e-01
    z[3,4,4]  R1695     1.1521905660629272e-01
    z[3,4,4]  R1696     -2.0077142119407654e-01
    z[3,4,4]  R1697     -2.2211013734340668e-01
    z[3,4,4]  R1698     -2.8791356086730957e-01
    z[3,4,4]  R1699     2.1502962335944176e-02
    z[3,4,4]  R1700     -1.7876857519149780e-01
    z[3,4,4]  R1701     2.1146588027477264e-01
    z[3,4,4]  R1702     -1.4546494185924530e-01
    z[3,4,4]  R1703     -2.7341198921203613e-01
    z[3,4,4]  R1704     -4.8977032303810120e-02
    z[3,4,4]  R1705     1.4836145937442780e-01
    z[3,4,4]  R1706     -2.3469938337802887e-01
    z[3,4,4]  R1707     -1.5348145365715027e-01
    z[3,4,4]  R1708     3.1884219497442245e-02
    z[3,4,4]  R1709     -3.7615177035331726e-01
    z[3,4,4]  R1710     1.6664399206638336e-01
    z[3,4,4]  R1711     -9.2443741858005524e-02
    z[3,4,4]  R1712     1.8520836532115936e-01
    z[3,4,4]  R1713     1.2274316698312759e-01
    z[3,4,4]  R1714     -0.0294036865234375
    z[3,4,4]  R1715     2.8596383333206177e-01
    z[3,4,4]  R1716     0.30115807056427
    z[3,4,4]  R1717     -4.5189487934112549e-01
    z[3,4,4]  R1718     9.8430924117565155e-02
    z[3,4,4]  R1719     -1.8710391223430634e-01
    z[3,4,4]  R1720     4.4314882159233093e-01
    z[3,4,4]  R1721     -1.6496485471725464e-01
    z[3,4,4]  R1722     -1.3414295017719269e-01
    z[3,4,4]  R1723     2.9464820027351379e-01
    z[3,4,4]  R1724     1.2383643537759781e-01
    z[3,4,4]  R1725     -4.0240734815597534e-01
    z[3,4,4]  R1726     3.8772711157798767e-01
    z[3,4,4]  R1727     1.3923652470111847e-01
    z[3,4,4]  R1728     -2.5536835193634033e-02
    z[3,4,4]  R1729     1.2949708104133606e-01
    z[3,4,4]  R1730     -2.2019621729850769e-01
    z[3,4,4]  R1731     1.0598796652629972e-03
    z[3,4,4]  R1732     8.8494084775447845e-02
    z[3,4,4]  R1733     -2.9208001494407654e-01
    z[3,4,4]  R1734     2.4737942218780518e-01
    z[3,4,4]  R1735     -8.6463037878274918e-03
    z[3,4,4]  R1736     2.9909974336624146e-01
    z[3,4,4]  R1737     1.0704813152551651e-01
    z[3,4,4]  R1738     0.446789026260376
    z[3,4,4]  R1739     -7.2337381541728973e-02
    z[3,4,4]  R1740     8.3119682967662811e-02
    z[3,4,4]  R1741     -2.2192949056625366e-01
    z[3,4,4]  R1742     -1.5212824940681458e-01
    z[3,4,4]  R1743     -2.1435758471488953e-01
    z[3,4,4]  R1744     -0.0946648046374321
    z[3,4,4]  R1745     3.6931118369102478e-01
    z[3,4,4]  R1746     0.379222571849823
    z[3,4,4]  R1747     -2.4310941994190216e-01
    z[3,4,4]  R1748     -2.5651225820183754e-02
    z[3,4,4]  R1749     1.2730209529399872e-01
    z[3,4,4]  R1750     1.7170648276805878e-01
    z[3,4,4]  R1751     5.5817224085330963e-02
    z[3,4,4]  R1752     -1.1799231171607971e-01
    z[3,4,4]  R1753     -2.0960466936230659e-03
    z[3,4,4]  R1754     4.3104174733161926e-01
    z[3,4,4]  R1755     2.8437113761901855e-01
    z[3,4,4]  R1756     3.1697955727577209e-01
    z[3,4,4]  R1757     -5.0764739513397217e-01
    z[3,4,4]  R1758     -2.5927874445915222e-01
    z[3,4,4]  R1759     1.0246764123439789e-01
    z[3,4,4]  R1760     -1.5932027995586395e-01
    z[3,4,4]  R1761     1.0432998090982437e-01
    z[3,4,4]  R1762     -3.1737962365150452e-01
    z[3,4,4]  R1763     -1.3017675280570984e-01
    z[3,4,4]  R1764     -4.1775807738304138e-01
    z[3,4,4]  R1765     -0.491071492433548
    z[3,4,4]  R1766     -1.2468812055885792e-02
    z[3,4,4]  R1767     -3.4238421916961670e-01
    z[3,4,5]  R34       -1
    z[3,4,5]  R43       1
    z[3,4,5]  R1644     -1
    z[3,4,5]  R1645     1
    z[3,4,5]  R1648     -1.8468056619167328e-01
    z[3,4,5]  R1649     -2.4679200351238251e-01
    z[3,4,5]  R1650     -9.3075439333915710e-02
    z[3,4,5]  R1651     -2.2437015548348427e-02
    z[3,4,5]  R1652     3.1480625271797180e-02
    z[3,4,5]  R1653     -1.7917092144489288e-01
    z[3,4,5]  R1654     -2.0761974155902863e-01
    z[3,4,5]  R1655     1.2972506880760193e-01
    z[3,4,5]  R1656     -2.0474882423877716e-01
    z[3,4,5]  R1657     -3.4563150256872177e-02
    z[3,4,5]  R1658     1.7839744687080383e-01
    z[3,4,5]  R1659     -5.3027976304292679e-02
    z[3,4,5]  R1660     6.5192244946956635e-02
    z[3,4,5]  R1661     1.6985410451889038e-01
    z[3,4,5]  R1662     -1.0913661867380142e-01
    z[3,4,5]  R1663     -2.4268977344036102e-01
    z[3,4,5]  R1664     4.9006618559360504e-02
    z[3,4,5]  R1665     8.3451326936483383e-03
    z[3,4,5]  R1666     -3.5888835787773132e-01
    z[3,4,5]  R1667     2.9074522852897644e-01
    z[3,4,5]  R1668     -0.226058229804039
    z[3,4,5]  R1669     -3.7904545664787292e-01
    z[3,4,5]  R1670     -7.0306479930877686e-02
    z[3,4,5]  R1671     -4.7628339380025864e-02
    z[3,4,5]  R1672     -2.0866043865680695e-01
    z[3,4,5]  R1673     2.4772900342941284e-01
    z[3,4,5]  R1674     7.1531340479850769e-02
    z[3,4,5]  R1675     -5.2819490432739258e-02
    z[3,4,5]  R1676     1.6068877279758453e-01
    z[3,4,5]  R1677     -9.9442936480045319e-02
    z[3,4,5]  R1678     -0.54718416929245
    z[3,4,5]  R1679     -0.462632954120636
    z[3,4,5]  R1680     7.9853492975234985e-01
    z[3,4,5]  R1681     7.0025348663330078e-01
    z[3,4,5]  R1682     -1.6692537069320679e-01
    z[3,4,5]  R1683     -1.2781160883605480e-02
    z[3,4,5]  R1684     0.666630208492279
    z[3,4,5]  R1685     8.0307203531265259e-01
    z[3,4,5]  R1686     -1.8419317901134491e-01
    z[3,4,5]  R1687     1.7388838529586792e-01
    z[3,4,5]  R1688     -5.7286724448204041e-02
    z[3,4,5]  R1689     0.718159019947052
    z[3,4,5]  R1690     3.6404278874397278e-01
    z[3,4,5]  R1691     0.460068941116333
    z[3,4,5]  R1692     2.9649391770362854e-01
    z[3,4,5]  R1693     6.6731852293014526e-01
    z[3,4,5]  R1694     -4.3767508864402771e-01
    z[3,4,5]  R1695     -5.4317567497491837e-02
    z[3,4,5]  R1696     5.4549443721771240e-01
    z[3,4,5]  R1697     4.6343334019184113e-02
    z[3,4,5]  R1698     -1.0235474258661270e-01
    z[3,4,5]  R1699     -4.3656334280967712e-01
    z[3,4,5]  R1700     4.0708357095718384e-01
    z[3,4,5]  R1701     -2.6709970831871033e-01
    z[3,4,5]  R1702     3.8735663890838623e-01
    z[3,4,5]  R1703     -9.8011508584022522e-02
    z[3,4,5]  R1704     -3.4187024831771851e-01
    z[3,4,5]  R1705     3.1506073474884033e-01
    z[3,4,5]  R1706     1.2127444893121719e-01
    z[3,4,5]  R1707     -1.1943063884973526e-01
    z[3,4,5]  R1708     -2.2009097039699554e-01
    z[3,4,5]  R1709     -0.613559365272522
    z[3,4,5]  R1710     -5.5540448427200317e-01
    z[3,4,5]  R1711     -2.3913922905921936e-01
    z[3,4,5]  R1712     3.8042879104614258e-01
    z[3,4,5]  R1713     -6.5704119205474854e-01
    z[3,4,5]  R1714     0.292542964220047
    z[3,4,5]  R1715     1.0635441541671753e-01
    z[3,4,5]  R1716     -1.6225801780819893e-02
    z[3,4,5]  R1717     7.6356399059295654e-01
    z[3,4,5]  R1718     -3.4275892376899719e-01
    z[3,4,5]  R1719     4.5087933540344238e-02
    z[3,4,5]  R1720     -2.9953157529234886e-02
    z[3,4,5]  R1721     -2.9334187507629395e-01
    z[3,4,5]  R1722     -2.0664717257022858e-01
    z[3,4,5]  R1723     -2.7806335687637329e-01
    z[3,4,5]  R1724     -8.7379798293113708e-02
    z[3,4,5]  R1725     -1.8528784811496735e-01
    z[3,4,5]  R1726     -1.8259078264236450e-01
    z[3,4,5]  R1727     -2.4348990619182587e-01
    z[3,4,5]  R1728     5.3352709859609604e-02
    z[3,4,5]  R1729     0.00816498976200819
    z[3,4,5]  R1730     2.2049862146377563e-01
    z[3,4,5]  R1731     1.4124831557273865e-01
    z[3,4,5]  R1732     6.3177652657032013e-02
    z[3,4,5]  R1733     -1.7479600384831429e-02
    z[3,4,5]  R1734     -2.2237753868103027e-01
    z[3,4,5]  R1735     2.3980200290679932e-01
    z[3,4,5]  R1736     3.1261703372001648e-01
    z[3,4,5]  R1737     -6.2608927488327026e-02
    z[3,4,5]  R1738     -5.2011895179748535e-01
    z[3,4,5]  R1739     3.6351811885833740e-01
    z[3,4,5]  R1740     1.7412659525871277e-01
    z[3,4,5]  R1741     4.7694477438926697e-01
    z[3,4,5]  R1742     -2.9019734263420105e-01
    z[3,4,5]  R1743     2.7124032378196716e-01
    z[3,4,5]  R1744     6.3384497165679932e-01
    z[3,4,5]  R1745     0.338814914226532
    z[3,4,5]  R1746     -4.9608775973320007e-01
    z[3,4,5]  R1747     -2.6866504549980164e-01
    z[3,4,5]  R1748     0.118772953748703
    z[3,4,5]  R1749     1.4905580878257751e-01
    z[3,4,5]  R1750     -3.9016890525817871e-01
    z[3,4,5]  R1751     1.9322144985198975e-01
    z[3,4,5]  R1752     4.0428814291954041e-01
    z[3,4,5]  R1753     -1.8809929490089417e-01
    z[3,4,5]  R1754     -3.2025733590126038e-01
    z[3,4,5]  R1755     -4.2974588274955750e-01
    z[3,4,5]  R1756     -2.5475805997848511e-01
    z[3,4,5]  R1757     -5.9276670217514038e-01
    z[3,4,5]  R1758     3.0984953045845032e-01
    z[3,4,5]  R1759     -1.6345185041427612e-01
    z[3,4,5]  R1760     -2.6504019275307655e-02
    z[3,4,5]  R1761     -3.3260446786880493e-01
    z[3,4,5]  R1762     -0.58106929063797
    z[3,4,5]  R1763     -3.7125506997108459e-01
    z[3,4,5]  R1764     -3.0003935098648071e-01
    z[3,4,5]  R1765     -3.7825220823287964e-01
    z[3,4,5]  R1766     -6.4805221557617188e-01
    z[3,4,5]  R1767     -5.2606594562530518e-01
    z[3,4,6]  R35       -1
    z[3,4,6]  R44       1
    z[3,4,6]  R1646     -1
    z[3,4,6]  R1647     1
    z[3,4,6]  R1648     -5.4451610893011093e-02
    z[3,4,6]  R1649     -0.385977566242218
    z[3,4,6]  R1650     -2.0393805205821991e-01
    z[3,4,6]  R1651     4.6617004275321960e-01
    z[3,4,6]  R1652     -0.387576699256897
    z[3,4,6]  R1653     -3.3300212025642395e-01
    z[3,4,6]  R1654     4.6243309974670410e-02
    z[3,4,6]  R1655     6.3250800594687462e-03
    z[3,4,6]  R1656     2.3546755313873291e-01
    z[3,4,6]  R1657     7.6464921236038208e-02
    z[3,4,6]  R1658     -1.3288977742195129e-01
    z[3,4,6]  R1659     1.8841318786144257e-02
    z[3,4,6]  R1660     -9.7866818308830261e-02
    z[3,4,6]  R1661     -0.0775921568274498
    z[3,4,6]  R1662     1.8998172879219055e-01
    z[3,4,6]  R1663     1.1523085087537766e-01
    z[3,4,6]  R1664     1.6446661949157715e-01
    z[3,4,6]  R1665     2.0641405880451202e-01
    z[3,4,6]  R1666     2.5323063135147095e-01
    z[3,4,6]  R1667     1.8000033497810364e-01
    z[3,4,6]  R1668     -9.4732239842414856e-02
    z[3,4,6]  R1669     -1.4579197764396667e-01
    z[3,4,6]  R1670     -4.5361623167991638e-02
    z[3,4,6]  R1671     -7.9353392124176025e-02
    z[3,4,6]  R1672     2.2805716097354889e-01
    z[3,4,6]  R1673     1.0872198641300201e-01
    z[3,4,6]  R1674     -7.5266361236572266e-02
    z[3,4,6]  R1675     -8.2955874502658844e-02
    z[3,4,6]  R1676     1.8072535097599030e-01
    z[3,4,6]  R1677     1.6203030943870544e-01
    z[3,4,6]  R1678     2.6618912816047668e-01
    z[3,4,6]  R1679     -2.3902162909507751e-02
    z[3,4,6]  R1680     -1.0881227999925613e-01
    z[3,4,6]  R1681     2.6119291782379150e-01
    z[3,4,6]  R1682     -7.6266713440418243e-02
    z[3,4,6]  R1683     6.3522164709866047e-03
    z[3,4,6]  R1684     3.5366213414818048e-03
    z[3,4,6]  R1685     -5.9513486921787262e-02
    z[3,4,6]  R1686     1.8727298080921173e-01
    z[3,4,6]  R1687     2.1614888310432434e-01
    z[3,4,6]  R1688     -9.7504250705242157e-02
    z[3,4,6]  R1689     -2.4339678883552551e-01
    z[3,4,6]  R1690     -1.3363434374332428e-01
    z[3,4,6]  R1691     -8.7864056229591370e-02
    z[3,4,6]  R1692     5.2130836993455887e-03
    z[3,4,6]  R1693     1.1075641214847565e-01
    z[3,4,6]  R1694     3.4520891308784485e-01
    z[3,4,6]  R1695     -8.6348660290241241e-02
    z[3,4,6]  R1696     8.7730973958969116e-02
    z[3,4,6]  R1697     -0.294983834028244
    z[3,4,6]  R1698     -3.8469800353050232e-01
    z[3,4,6]  R1699     -4.9401441216468811e-01
    z[3,4,6]  R1700     1.1346577107906342e-01
    z[3,4,6]  R1701     -4.6004495024681091e-01
    z[3,4,6]  R1702     -1.3438005745410919e-01
    z[3,4,6]  R1703     -1.7469539307057858e-03
    z[3,4,6]  R1704     1.4967045187950134e-01
    z[3,4,6]  R1705     -2.0855763554573059e-01
    z[3,4,6]  R1706     -4.2886976152658463e-02
    z[3,4,6]  R1707     -3.6438378691673279e-01
    z[3,4,6]  R1708     -3.7644156813621521e-01
    z[3,4,6]  R1709     -0.290274441242218
    z[3,4,6]  R1710     -2.1499957144260406e-01
    z[3,4,6]  R1711     4.1045309044420719e-03
    z[3,4,6]  R1712     -4.7545540332794189e-01
    z[3,4,6]  R1713     3.7156778573989868e-01
    z[3,4,6]  R1714     -0.0534537211060524
    z[3,4,6]  R1715     3.0226361751556396e-01
    z[3,4,6]  R1716     1.2297625839710236e-01
    z[3,4,6]  R1717     -1.8238408863544464e-01
    z[3,4,6]  R1718     -2.7031236886978149e-01
    z[3,4,6]  R1719     -3.6006903648376465e-01
    z[3,4,6]  R1720     -8.4542363882064819e-02
    z[3,4,6]  R1721     1.9825683534145355e-01
    z[3,4,6]  R1722     1.8086800118908286e-03
    z[3,4,6]  R1723     3.8836565613746643e-01
    z[3,4,6]  R1724     1.0225946456193924e-01
    z[3,4,6]  R1725     -1.9530941545963287e-01
    z[3,4,6]  R1726     5.5214506387710571e-01
    z[3,4,6]  R1727     5.6081664562225342e-01
    z[3,4,6]  R1728     1.3139556348323822e-01
    z[3,4,6]  R1729     2.6312194764614105e-02
    z[3,4,6]  R1730     -1.8855512142181396e-01
    z[3,4,6]  R1731     0.219558984041214
    z[3,4,6]  R1732     5.1874320954084396e-02
    z[3,4,6]  R1733     -3.6246750503778458e-02
    z[3,4,6]  R1734     5.1881197839975357e-02
    z[3,4,6]  R1735     -2.6275175809860229e-01
    z[3,4,6]  R1736     1.5936821699142456e-01
    z[3,4,6]  R1737     4.5621609687805176e-01
    z[3,4,6]  R1738     1.3237684965133667e-01
    z[3,4,6]  R1739     -1.1799604445695877e-01
    z[3,4,6]  R1740     -1.3395063579082489e-01
    z[3,4,6]  R1741     7.1930542588233948e-02
    z[3,4,6]  R1742     -4.8952198028564453e-01
    z[3,4,6]  R1743     -5.1462358236312866e-01
    z[3,4,6]  R1744     2.2167497873306274e-01
    z[3,4,6]  R1745     -4.1103911399841309e-01
    z[3,4,6]  R1746     -6.3495904207229614e-01
    z[3,4,6]  R1747     -1.5159158408641815e-01
    z[3,4,6]  R1748     3.2869648933410645e-01
    z[3,4,6]  R1749     -1.1322646588087082e-01
    z[3,4,6]  R1750     -3.7916172295808792e-02
    z[3,4,6]  R1751     -9.0696640312671661e-02
    z[3,4,6]  R1752     -2.8596329689025879e-01
    z[3,4,6]  R1753     3.6390227614901960e-04
    z[3,4,6]  R1754     -4.5304756611585617e-02
    z[3,4,6]  R1755     -4.6856012195348740e-02
    z[3,4,6]  R1756     -6.9118463993072510e-01
    z[3,4,6]  R1757     -3.0608588829636574e-02
    z[3,4,6]  R1758     2.1094322204589844e-02
    z[3,4,6]  R1759     1.8923284113407135e-01
    z[3,4,6]  R1760     1.3367126882076263e-01
    z[3,4,6]  R1761     -1.2137117236852646e-01
    z[3,4,6]  R1762     -9.0393684804439545e-02
    z[3,4,6]  R1763     2.7407559752464294e-01
    z[3,4,6]  R1764     3.3861619234085083e-01
    z[3,4,6]  R1765     2.1317753195762634e-01
    z[3,4,6]  R1766     1.0882806777954102e-01
    z[3,4,6]  R1767     3.0970957130193710e-02
    z[4,3,0]  R29       1
    z[4,3,0]  R38       -1
    z[4,3,0]  R1768     -1
    z[4,3,0]  R1769     1
    z[4,3,0]  R1782     1.8273948132991791e-01
    z[4,3,0]  R1783     7.5243353843688965e-02
    z[4,3,0]  R1784     -2.0890556275844574e-01
    z[4,3,0]  R1785     6.4720004796981812e-01
    z[4,3,0]  R1786     2.2473375499248505e-01
    z[4,3,0]  R1787     3.4467941522598267e-01
    z[4,3,0]  R1788     -1.7299796640872955e-01
    z[4,3,0]  R1789     2.0742221176624298e-01
    z[4,3,0]  R1790     6.4767844974994659e-02
    z[4,3,0]  R1791     2.0509274303913116e-01
    z[4,3,0]  R1792     -1.0053467005491257e-01
    z[4,3,0]  R1793     1.3686452805995941e-01
    z[4,3,0]  R1794     -1.1812112480401993e-01
    z[4,3,0]  R1795     1.1632069945335388e-01
    z[4,3,0]  R1796     -4.2024865746498108e-02
    z[4,3,0]  R1797     2.4728041887283325e-01
    z[4,3,0]  R1798     3.3589640259742737e-01
    z[4,3,0]  R1799     -0.0842878594994545
    z[4,3,0]  R1800     -0.0749136209487915
    z[4,3,0]  R1801     6.1640333384275436e-02
    z[4,3,0]  R1802     -3.2477363944053650e-02
    z[4,3,0]  R1803     -1.2521438300609589e-01
    z[4,3,0]  R1804     -9.0394169092178345e-02
    z[4,3,0]  R1805     -1.7760178446769714e-01
    z[4,3,0]  R1806     0.206633523106575
    z[4,3,0]  R1807     2.0787317771464586e-03
    z[4,3,0]  R1808     -1.7261725664138794e-01
    z[4,3,0]  R1809     1.8793597817420959e-01
    z[4,3,0]  R1810     -7.3890708386898041e-02
    z[4,3,0]  R1811     -5.5151319503784180e-01
    z[4,3,0]  R1812     8.4341593086719513e-02
    z[4,3,0]  R1813     -2.9460051655769348e-01
    z[4,3,0]  R1814     2.2809910774230957e-01
    z[4,3,0]  R1815     1.8554365634918213e-01
    z[4,3,0]  R1816     -1.5891253948211670e-01
    z[4,3,0]  R1817     2.3968566954135895e-01
    z[4,3,0]  R1818     1.2430764734745026e-01
    z[4,3,0]  R1819     -1.7151252925395966e-01
    z[4,3,0]  R1820     -3.8300785422325134e-01
    z[4,3,0]  R1821     -2.5668612122535706e-01
    z[4,3,0]  R1822     -1.6947200521826744e-02
    z[4,3,0]  R1823     3.4027022123336792e-01
    z[4,3,0]  R1824     2.6533061265945435e-01
    z[4,3,0]  R1825     -2.0327101647853851e-01
    z[4,3,0]  R1826     -9.8297879099845886e-02
    z[4,3,0]  R1827     -4.8372265696525574e-01
    z[4,3,0]  R1828     -1.4247813820838928e-01
    z[4,3,0]  R1829     -5.4091745615005493e-01
    z[4,3,0]  R1830     -4.2434650659561157e-01
    z[4,3,0]  R1831     -6.4929658174514771e-01
    z[4,3,0]  R1832     4.3805766105651855e-01
    z[4,3,0]  R1833     0.417502224445343
    z[4,3,0]  R1834     0.575057327747345
    z[4,3,0]  R1835     7.2431176900863647e-02
    z[4,3,0]  R1836     1.5262040495872498e-01
    z[4,3,0]  R1837     4.0876439213752747e-01
    z[4,3,0]  R1838     2.4220088124275208e-01
    z[4,3,0]  R1839     2.1401388943195343e-01
    z[4,3,0]  R1840     4.3158498406410217e-01
    z[4,3,0]  R1841     7.0104628801345825e-01
    z[4,3,0]  R1842     8.0959171056747437e-01
    z[4,3,0]  R1843     6.4698415994644165e-01
    z[4,3,0]  R1844     7.3615294694900513e-01
    z[4,3,0]  R1845     7.3598664999008179e-01
    z[4,3,0]  R1846     7.0550125837326050e-01
    z[4,3,0]  R1847     6.3437575101852417e-01
    z[4,3,0]  R1848     5.7536059617996216e-01
    z[4,3,0]  R1849     5.6623983383178711e-01
    z[4,3,0]  R1850     6.3096511363983154e-01
    z[4,3,0]  R1851     6.5490937232971191e-01
    z[4,3,0]  R1852     -1.9726440310478210e-01
    z[4,3,0]  R1853     -1.0529028624296188e-01
    z[4,3,0]  R1854     -7.1863353252410889e-01
    z[4,3,0]  R1855     -7.8457134962081909e-01
    z[4,3,0]  R1856     -0.79290771484375
    z[4,3,0]  R1857     -7.3468130826950073e-01
    z[4,3,0]  R1858     -6.3682740926742554e-01
    z[4,3,0]  R1859     -6.2035316228866577e-01
    z[4,3,0]  R1860     -6.7900937795639038e-01
    z[4,3,0]  R1861     -6.7543321847915649e-01
    z[4,3,0]  R1862     4.1349714994430542e-01
    z[4,3,0]  R1863     5.1700967550277710e-01
    z[4,3,0]  R1864     -1.0512983798980713e-01
    z[4,3,0]  R1865     -1.7748099565505981e-01
    z[4,3,0]  R1866     -7.1416527032852173e-01
    z[4,3,0]  R1867     -7.9319137334823608e-01
    z[4,3,0]  R1868     -1.2548317201435566e-02
    z[4,3,0]  R1869     -7.7411487698554993e-02
    z[4,3,0]  R1870     -8.6458724737167358e-01
    z[4,3,0]  R1871     -9.1031205654144287e-01
    z[4,3,0]  R1872     7.3104846477508545e-01
    z[4,3,0]  R1873     2.9177516698837280e-01
    z[4,3,0]  R1874     2.8340291976928711e-01
    z[4,3,0]  R1875     -4.5324318110942841e-02
    z[4,3,0]  R1876     1.8512003123760223e-01
    z[4,3,0]  R1877     -1.1372501403093338e-01
    z[4,3,0]  R1878     5.3195875138044357e-02
    z[4,3,0]  R1879     -6.2801039218902588e-01
    z[4,3,0]  R1880     1.1845371872186661e-01
    z[4,3,0]  R1881     -7.9882496595382690e-01
    z[4,3,0]  R1882     0.524105429649353
    z[4,3,0]  R1883     4.0315771102905273e-01
    z[4,3,0]  R1884     2.0439341664314270e-01
    z[4,3,0]  R1885     0.686012327671051
    z[4,3,0]  R1886     -7.8146022558212280e-01
    z[4,3,0]  R1887     -8.6590969562530518e-01
    z[4,3,0]  R1888     -7.6497918367385864e-01
    z[4,3,0]  R1889     -8.5123002529144287e-01
    z[4,3,0]  R1890     -8.9121866226196289e-01
    z[4,3,0]  R1891     -0.826116681098938
    z[4,3,0]  R1892     5.2226793766021729e-01
    z[4,3,0]  R1893     4.6512582898139954e-01
    z[4,3,0]  R1894     1.1516742408275604e-01
    z[4,3,0]  R1895     3.5153231024742126e-01
    z[4,3,0]  R1896     5.0296396017074585e-01
    z[4,3,0]  R1897     -5.8018577098846436e-01
    z[4,3,0]  R1898     -8.2047873735427856e-01
    z[4,3,0]  R1899     -8.1746226549148560e-01
    z[4,3,0]  R1900     -8.9487850666046143e-01
    z[4,3,0]  R1901     8.7175302207469940e-02
    z[4,3,1]  R30       1
    z[4,3,1]  R39       -1
    z[4,3,1]  R1770     -1
    z[4,3,1]  R1771     1
    z[4,3,1]  R1782     -8.1072676181793213e-01
    z[4,3,1]  R1783     -6.7871409654617310e-01
    z[4,3,1]  R1784     -6.7564535140991211e-01
    z[4,3,1]  R1785     -6.3561600446701050e-01
    z[4,3,1]  R1786     -4.6969485282897949e-01
    z[4,3,1]  R1787     -6.1447870731353760e-01
    z[4,3,1]  R1788     -4.5773589611053467e-01
    z[4,3,1]  R1789     -5.2216702699661255e-01
    z[4,3,1]  R1790     -4.9167856574058533e-01
    z[4,3,1]  R1791     -5.1526272296905518e-01
    z[4,3,1]  R1792     9.1978579759597778e-01
    z[4,3,1]  R1793     9.0769237279891968e-01
    z[4,3,1]  R1794     8.8948029279708862e-01
    z[4,3,1]  R1795     8.7213045358657837e-01
    z[4,3,1]  R1796     8.9554357528686523e-01
    z[4,3,1]  R1797     0.841696560382843
    z[4,3,1]  R1798     8.5505813360214233e-01
    z[4,3,1]  R1799     8.2347893714904785e-01
    z[4,3,1]  R1800     8.3122414350509644e-01
    z[4,3,1]  R1801     8.2374644279479980e-01
    z[4,3,1]  R1802     6.2490773200988770e-01
    z[4,3,1]  R1803     -4.6254453063011169e-01
    z[4,3,1]  R1804     -3.9497679471969604e-01
    z[4,3,1]  R1805     -4.7766700387001038e-01
    z[4,3,1]  R1806     -1.5034003555774689e-01
    z[4,3,1]  R1807     -4.6923229098320007e-01
    z[4,3,1]  R1808     -0.536043643951416
    z[4,3,1]  R1809     -4.5698961615562439e-01
    z[4,3,1]  R1810     3.9782455563545227e-01
    z[4,3,1]  R1811     -1.7178170382976532e-01
    z[4,3,1]  R1812     -8.6554270982742310e-01
    z[4,3,1]  R1813     -6.4300930500030518e-01
    z[4,3,1]  R1814     8.4201908111572266e-01
    z[4,3,1]  R1815     -7.0415306091308594e-01
    z[4,3,1]  R1816     -7.0064681768417358e-01
    z[4,3,1]  R1817     -3.7490347027778625e-01
    z[4,3,1]  R1818     -3.7599790096282959e-01
    z[4,3,1]  R1819     0.580936849117279
    z[4,3,1]  R1820     4.4202911853790283e-01
    z[4,3,1]  R1821     1.0483112186193466e-01
    z[4,3,1]  R1822     -8.6755198240280151e-01
    z[4,3,1]  R1823     -8.3970564603805542e-01
    z[4,3,1]  R1824     -7.3522913455963135e-01
    z[4,3,1]  R1825     6.9517850875854492e-01
    z[4,3,1]  R1826     9.3139477074146271e-02
    z[4,3,1]  R1827     -5.8083377778530121e-02
    z[4,3,1]  R1828     2.4324165657162666e-02
    z[4,3,1]  R1829     -4.4814877212047577e-02
    z[4,3,1]  R1830     -3.8592919707298279e-02
    z[4,3,1]  R1831     -2.4696400389075279e-02
    z[4,3,1]  R1832     -7.4315059185028076e-01
    z[4,3,1]  R1833     -6.4629071950912476e-01
    z[4,3,1]  R1834     -5.4676425457000732e-01
    z[4,3,1]  R1835     -7.6116353273391724e-01
    z[4,3,1]  R1836     -6.2137299776077271e-01
    z[4,3,1]  R1837     -4.7046065330505371e-01
    z[4,3,1]  R1838     -4.7412568330764771e-01
    z[4,3,1]  R1839     -5.4200416803359985e-01
    z[4,3,1]  R1840     -3.9279901981353760e-01
    z[4,3,1]  R1841     -4.4781142473220825e-01
    z[4,3,1]  R1842     4.3983411788940430e-01
    z[4,3,1]  R1843     4.2036175727844238e-01
    z[4,3,1]  R1844     5.3850877285003662e-01
    z[4,3,1]  R1845     2.9302990436553955e-01
    z[4,3,1]  R1846     4.8259556293487549e-01
    z[4,3,1]  R1847     4.1428366303443909e-01
    z[4,3,1]  R1848     6.3172364234924316e-01
    z[4,3,1]  R1849     4.1547408699989319e-01
    z[4,3,1]  R1850     3.5577812790870667e-01
    z[4,3,1]  R1851     5.5575639009475708e-01
    z[4,3,1]  R1852     -5.0551635026931763e-01
    z[4,3,1]  R1853     -6.2404167652130127e-01
    z[4,3,1]  R1854     3.2444596290588379e-01
    z[4,3,1]  R1855     1.3832947611808777e-01
    z[4,3,1]  R1856     3.6259597539901733e-01
    z[4,3,1]  R1857     0.476630836725235
    z[4,3,1]  R1858     5.2922356128692627e-01
    z[4,3,1]  R1859     4.3140381574630737e-01
    z[4,3,1]  R1860     5.2916640043258667e-01
    z[4,3,1]  R1861     5.5091768503189087e-01
    z[4,3,1]  R1862     -2.2911764681339264e-01
    z[4,3,1]  R1863     3.1199318170547485e-01
    z[4,3,1]  R1864     3.6908298730850220e-01
    z[4,3,1]  R1865     0.517268180847168
    z[4,3,1]  R1866     3.4748798608779907e-01
    z[4,3,1]  R1867     -0.525443971157074
    z[4,3,1]  R1868     -2.8569707274436951e-01
    z[4,3,1]  R1869     -2.5481000542640686e-01
    z[4,3,1]  R1870     -3.9693346619606018e-01
    z[4,3,1]  R1871     -2.4970203638076782e-01
    z[4,3,1]  R1872     3.6790484189987183e-01
    z[4,3,1]  R1873     4.9255335330963135e-01
    z[4,3,1]  R1874     8.3790290355682373e-01
    z[4,3,1]  R1875     0.460196852684021
    z[4,3,1]  R1876     -4.7581657767295837e-02
    z[4,3,1]  R1877     3.6662113666534424e-01
    z[4,3,1]  R1878     5.3846889734268188e-01
    z[4,3,1]  R1879     3.4729701280593872e-01
    z[4,3,1]  R1880     5.4520481824874878e-01
    z[4,3,1]  R1881     1.6787196695804596e-01
    z[4,3,1]  R1882     -5.1416093111038208e-01
    z[4,3,1]  R1883     -1.9312760233879089e-01
    z[4,3,1]  R1884     6.2209200859069824e-01
    z[4,3,1]  R1885     -0.256678968667984
    z[4,3,1]  R1886     3.0892390012741089e-01
    z[4,3,1]  R1887     1.2741953134536743e-01
    z[4,3,1]  R1888     4.0049365162849426e-01
    z[4,3,1]  R1889     3.3169683814048767e-01
    z[4,3,1]  R1890     1.0963108390569687e-01
    z[4,3,1]  R1891     2.1821531653404236e-01
    z[4,3,1]  R1892     -3.7440881133079529e-01
    z[4,3,1]  R1893     -0.374693363904953
    z[4,3,1]  R1894     -4.1260075569152832e-01
    z[4,3,1]  R1895     0.281189888715744
    z[4,3,1]  R1896     -2.9525252059102058e-02
    z[4,3,1]  R1897     -2.7286946773529053e-01
    z[4,3,1]  R1898     -4.3413645029067993e-01
    z[4,3,1]  R1899     0.0749564915895462
    z[4,3,1]  R1900     -2.5474876165390015e-01
    z[4,3,1]  R1901     -3.6620470881462097e-01
    z[4,3,2]  R31       1
    z[4,3,2]  R40       -1
    z[4,3,2]  R1772     -1
    z[4,3,2]  R1773     1
    z[4,3,2]  R1782     4.6575747430324554e-02
    z[4,3,2]  R1783     -4.4898384809494019e-01
    z[4,3,2]  R1784     -3.9891722798347473e-01
    z[4,3,2]  R1785     -1.3940635323524475e-01
    z[4,3,2]  R1786     -0.392828106880188
    z[4,3,2]  R1787     -3.9671313762664795e-01
    z[4,3,2]  R1788     -1.5920653939247131e-02
    z[4,3,2]  R1789     3.0823811888694763e-01
    z[4,3,2]  R1790     -1.7982932925224304e-01
    z[4,3,2]  R1791     4.2525655031204224e-01
    z[4,3,2]  R1792     1.4306181669235229e-01
    z[4,3,2]  R1793     -1.1526767164468765e-01
    z[4,3,2]  R1794     -2.4151550233364105e-01
    z[4,3,2]  R1795     1.8396852910518646e-01
    z[4,3,2]  R1796     -4.1573038697242737e-01
    z[4,3,2]  R1797     2.9827040433883667e-01
    z[4,3,2]  R1798     2.0655937492847443e-01
    z[4,3,2]  R1799     4.3210950493812561e-01
    z[4,3,2]  R1800     2.8976443409919739e-01
    z[4,3,2]  R1801     2.5015175342559814e-01
    z[4,3,2]  R1802     -1.1019866913557053e-01
    z[4,3,2]  R1803     5.0250756740570068e-01
    z[4,3,2]  R1804     5.8804297447204590e-01
    z[4,3,2]  R1805     6.0417884588241577e-01
    z[4,3,2]  R1806     6.4746642112731934e-01
    z[4,3,2]  R1807     1.5681222081184387e-01
    z[4,3,2]  R1808     1.3179703056812286e-01
    z[4,3,2]  R1809     -4.0013585239648819e-02
    z[4,3,2]  R1810     -0.195712149143219
    z[4,3,2]  R1811     -1.1446216702461243e-01
    z[4,3,2]  R1812     3.0641865730285645e-01
    z[4,3,2]  R1813     6.6967093944549561e-01
    z[4,3,2]  R1814     -1.8188336491584778e-01
    z[4,3,2]  R1815     -3.5695701837539673e-01
    z[4,3,2]  R1816     0.272125780582428
    z[4,3,2]  R1817     7.3076236248016357e-01
    z[4,3,2]  R1818     4.7682681679725647e-01
    z[4,3,2]  R1819     5.7388770580291748e-01
    z[4,3,2]  R1820     -2.4268349632620811e-02
    z[4,3,2]  R1821     -1.3904811441898346e-01
    z[4,3,2]  R1822     1.0298167914152145e-01
    z[4,3,2]  R1823     2.3890449106693268e-01
    z[4,3,2]  R1824     0.562421441078186
    z[4,3,2]  R1825     1.2121919542551041e-01
    z[4,3,2]  R1826     -3.0836266279220581e-01
    z[4,3,2]  R1827     -5.7609234005212784e-02
    z[4,3,2]  R1828     -2.4657705426216125e-01
    z[4,3,2]  R1829     1.0175630450248718e-01
    z[4,3,2]  R1830     -1.5905712544918060e-01
    z[4,3,2]  R1831     1.7889384925365448e-01
    z[4,3,2]  R1832     -2.5924375653266907e-01
    z[4,3,2]  R1833     9.1730482876300812e-02
    z[4,3,2]  R1834     4.8309704661369324e-01
    z[4,3,2]  R1835     9.3876376748085022e-02
    z[4,3,2]  R1836     3.8764795660972595e-01
    z[4,3,2]  R1837     -0.00233491905964911
    z[4,3,2]  R1838     -0.00865908246487379
    z[4,3,2]  R1839     5.1715171337127686e-01
    z[4,3,2]  R1840     8.3564911037683487e-03
    z[4,3,2]  R1841     1.9294353201985359e-02
    z[4,3,2]  R1842     -2.1823914349079132e-01
    z[4,3,2]  R1843     -3.9614400267601013e-01
    z[4,3,2]  R1844     -3.5059735178947449e-01
    z[4,3,2]  R1845     -3.1809780001640320e-01
    z[4,3,2]  R1846     -3.2828783988952637e-01
    z[4,3,2]  R1847     -5.7305407524108887e-01
    z[4,3,2]  R1848     1.7797026038169861e-01
    z[4,3,2]  R1849     3.8262477517127991e-01
    z[4,3,2]  R1850     1.4956396818161011e-01
    z[4,3,2]  R1851     2.2001340985298157e-01
    z[4,3,2]  R1852     3.6332961916923523e-01
    z[4,3,2]  R1853     -2.7133089303970337e-01
    z[4,3,2]  R1854     -1.6312594711780548e-01
    z[4,3,2]  R1855     -4.2357784695923328e-03
    z[4,3,2]  R1856     -1.2825167179107666e-01
    z[4,3,2]  R1857     1.2461613118648529e-01
    z[4,3,2]  R1858     8.4123559296131134e-02
    z[4,3,2]  R1859     1.0180328786373138e-01
    z[4,3,2]  R1860     -1.1466205865144730e-01
    z[4,3,2]  R1861     1.6040942072868347e-01
    z[4,3,2]  R1862     2.4013815820217133e-01
    z[4,3,2]  R1863     3.6817422509193420e-01
    z[4,3,2]  R1864     -1.8781460821628571e-01
    z[4,3,2]  R1865     -2.0988664031028748e-01
    z[4,3,2]  R1866     -5.1806366443634033e-01
    z[4,3,2]  R1867     -1.5469801425933838e-01
    z[4,3,2]  R1868     -3.6768436431884766e-01
    z[4,3,2]  R1869     -3.9628565311431885e-01
    z[4,3,2]  R1870     -1.6091901063919067e-01
    z[4,3,2]  R1871     -1.0736337304115295e-01
    z[4,3,2]  R1872     3.1245386600494385e-01
    z[4,3,2]  R1873     9.0317949652671814e-02
    z[4,3,2]  R1874     1.5061146020889282e-01
    z[4,3,2]  R1875     -7.1832996606826782e-01
    z[4,3,2]  R1876     1.0902821272611618e-01
    z[4,3,2]  R1877     -4.9349340796470642e-01
    z[4,3,2]  R1878     -2.2480714321136475e-01
    z[4,3,2]  R1879     0.60881507396698
    z[4,3,2]  R1880     -3.0338427051901817e-02
    z[4,3,2]  R1881     4.3201163411140442e-01
    z[4,3,2]  R1882     -8.8836506009101868e-02
    z[4,3,2]  R1883     -3.0723696947097778e-01
    z[4,3,2]  R1884     -3.7479674816131592e-01
    z[4,3,2]  R1885     1.1668688803911209e-01
    z[4,3,2]  R1886     -2.1206364035606384e-01
    z[4,3,2]  R1887     -3.5514822602272034e-01
    z[4,3,2]  R1888     3.0323070287704468e-01
    z[4,3,2]  R1889     -5.6406762450933456e-03
    z[4,3,2]  R1890     2.9734751582145691e-01
    z[4,3,2]  R1891     -2.9981845617294312e-01
    z[4,3,2]  R1892     -9.7930260002613068e-02
    z[4,3,2]  R1893     1.9548104703426361e-01
    z[4,3,2]  R1894     -4.7278085350990295e-01
    z[4,3,2]  R1895     -3.1819036602973938e-01
    z[4,3,2]  R1896     5.8277076482772827e-01
    z[4,3,2]  R1897     -2.1691782400012016e-02
    z[4,3,2]  R1898     -9.2265717685222626e-02
    z[4,3,2]  R1899     3.5283961892127991e-01
    z[4,3,2]  R1900     8.4181100130081177e-02
    z[4,3,2]  R1901     5.7402491569519043e-02
    z[4,3,3]  R32       1
    z[4,3,3]  R41       -1
    z[4,3,3]  R1774     -1
    z[4,3,3]  R1775     1
    z[4,3,3]  R1782     -3.2698315382003784e-01
    z[4,3,3]  R1783     -4.0670457482337952e-01
    z[4,3,3]  R1784     -3.6919006705284119e-01
    z[4,3,3]  R1785     7.1565821766853333e-02
    z[4,3,3]  R1786     -7.1684509515762329e-01
    z[4,3,3]  R1787     -1.7682163417339325e-01
    z[4,3,3]  R1788     -8.5256582498550415e-01
    z[4,3,3]  R1789     -0.595733106136322
    z[4,3,3]  R1790     -4.8289006948471069e-01
    z[4,3,3]  R1791     -3.4410575032234192e-01
    z[4,3,3]  R1792     3.2040110230445862e-01
    z[4,3,3]  R1793     -3.5573536157608032e-01
    z[4,3,3]  R1794     -6.2316235154867172e-02
    z[4,3,3]  R1795     -3.5193055868148804e-01
    z[4,3,3]  R1796     -9.4288922846317291e-02
    z[4,3,3]  R1797     -2.3346070945262909e-01
    z[4,3,3]  R1798     -6.5149967558681965e-03
    z[4,3,3]  R1799     -3.7961628288030624e-02
    z[4,3,3]  R1800     -8.3082199096679688e-02
    z[4,3,3]  R1801     -1.7763453722000122e-01
    z[4,3,3]  R1802     -3.2958149909973145e-01
    z[4,3,3]  R1803     6.0544097423553467e-01
    z[4,3,3]  R1804     0.659436047077179
    z[4,3,3]  R1805     3.0554351210594177e-01
    z[4,3,3]  R1806     4.1048571467399597e-01
    z[4,3,3]  R1807     6.0898989439010620e-01
    z[4,3,3]  R1808     4.5346373319625854e-01
    z[4,3,3]  R1809     5.7801395654678345e-01
    z[4,3,3]  R1810     6.9905549287796021e-02
    z[4,3,3]  R1811     7.0637071132659912e-01
    z[4,3,3]  R1812     -1.6438831388950348e-01
    z[4,3,3]  R1813     -6.8297930993139744e-03
    z[4,3,3]  R1814     1.5079972147941589e-01
    z[4,3,3]  R1815     5.4189282655715942e-01
    z[4,3,3]  R1816     3.8812670111656189e-01
    z[4,3,3]  R1817     4.8228484392166138e-01
    z[4,3,3]  R1818     5.7043421268463135e-01
    z[4,3,3]  R1819     -1.8974894285202026e-01
    z[4,3,3]  R1820     -1.1921525001525879e-01
    z[4,3,3]  R1821     5.4200851917266846e-01
    z[4,3,3]  R1822     -2.6978492736816406e-01
    z[4,3,3]  R1823     2.2138184309005737e-01
    z[4,3,3]  R1824     1.6960693895816803e-01
    z[4,3,3]  R1825     -0.569624662399292
    z[4,3,3]  R1826     6.6334950923919678e-01
    z[4,3,3]  R1827     7.2761672735214233e-01
    z[4,3,3]  R1828     0.734235405921936
    z[4,3,3]  R1829     5.1514565944671631e-01
    z[4,3,3]  R1830     6.0097473859786987e-01
    z[4,3,3]  R1831     3.8841915130615234e-01
    z[4,3,3]  R1832     -2.3028573393821716e-01
    z[4,3,3]  R1833     -3.9770260453224182e-01
    z[4,3,3]  R1834     -1.9360916316509247e-01
    z[4,3,3]  R1835     -0.411496102809906
    z[4,3,3]  R1836     -0.531631350517273
    z[4,3,3]  R1837     -6.0601687431335449e-01
    z[4,3,3]  R1838     -8.1906592845916748e-01
    z[4,3,3]  R1839     -5.9192508459091187e-01
    z[4,3,3]  R1840     -6.6998499631881714e-01
    z[4,3,3]  R1841     -5.4565912485122681e-01
    z[4,3,3]  R1842     2.2777134180068970e-01
    z[4,3,3]  R1843     4.9239867925643921e-01
    z[4,3,3]  R1844     1.3949842751026154e-01
    z[4,3,3]  R1845     4.3091511726379395e-01
    z[4,3,3]  R1846     2.8371140360832214e-01
    z[4,3,3]  R1847     9.3603268265724182e-02
    z[4,3,3]  R1848     3.9086464047431946e-01
    z[4,3,3]  R1849     5.6015163660049438e-01
    z[4,3,3]  R1850     5.0423681735992432e-01
    z[4,3,3]  R1851     0.244984433054924
    z[4,3,3]  R1852     7.1642976999282837e-01
    z[4,3,3]  R1853     5.9662669897079468e-01
    z[4,3,3]  R1854     -5.3482079505920410e-01
    z[4,3,3]  R1855     -5.9529459476470947e-01
    z[4,3,3]  R1856     -3.5588398575782776e-01
    z[4,3,3]  R1857     -3.5378125309944153e-01
    z[4,3,3]  R1858     -5.3700417280197144e-01
    z[4,3,3]  R1859     -5.7328951358795166e-01
    z[4,3,3]  R1860     -4.2559444904327393e-01
    z[4,3,3]  R1861     -3.9520761370658875e-01
    z[4,3,3]  R1862     4.8846620321273804e-01
    z[4,3,3]  R1863     -2.5209185481071472e-01
    z[4,3,3]  R1864     3.9737510681152344e-01
    z[4,3,3]  R1865     2.4219667911529541e-01
    z[4,3,3]  R1866     -2.5597441941499710e-02
    z[4,3,3]  R1867     -2.1603195369243622e-01
    z[4,3,3]  R1868     -1.7789797484874725e-01
    z[4,3,3]  R1869     -2.3374319076538086e-01
    z[4,3,3]  R1870     4.4634109362959862e-03
    z[4,3,3]  R1871     -6.6339030861854553e-02
    z[4,3,3]  R1872     -4.6688544750213623e-01
    z[4,3,3]  R1873     -1.5835982561111450e-01
    z[4,3,3]  R1874     -1.8619684875011444e-01
    z[4,3,3]  R1875     1.5709747374057770e-01
    z[4,3,3]  R1876     9.1810613870620728e-01
    z[4,3,3]  R1877     2.7690944075584412e-01
    z[4,3,3]  R1878     -5.3713542222976685e-01
    z[4,3,3]  R1879     -3.0108150839805603e-01
    z[4,3,3]  R1880     -5.8500421047210693e-01
    z[4,3,3]  R1881     -9.2559941112995148e-02
    z[4,3,3]  R1882     4.6010515093803406e-01
    z[4,3,3]  R1883     5.2026033401489258e-01
    z[4,3,3]  R1884     -4.6925750374794006e-01
    z[4,3,3]  R1885     0.349550724029541
    z[4,3,3]  R1886     -2.4423709511756897e-01
    z[4,3,3]  R1887     -1.5320216119289398e-01
    z[4,3,3]  R1888     -1.4417918026447296e-01
    z[4,3,3]  R1889     -2.4125318974256516e-02
    z[4,3,3]  R1890     -1.8347722291946411e-01
    z[4,3,3]  R1891     -9.7090564668178558e-02
    z[4,3,3]  R1892     6.2152963876724243e-01
    z[4,3,3]  R1893     5.3341861814260483e-02
    z[4,3,3]  R1894     4.5880961418151855e-01
    z[4,3,3]  R1895     -7.9395341873168945e-01
    z[4,3,3]  R1896     3.8047265261411667e-02
    z[4,3,3]  R1897     6.0204431414604187e-02
    z[4,3,3]  R1898     2.0130556821823120e-01
    z[4,3,3]  R1899     -1.3111500442028046e-01
    z[4,3,3]  R1900     1.4534957706928253e-01
    z[4,3,3]  R1901     1.8573263287544250e-01
    z[4,3,4]  R33       1
    z[4,3,4]  R42       -1
    z[4,3,4]  R1776     -1
    z[4,3,4]  R1777     1
    z[4,3,4]  R1782     9.8430924117565155e-02
    z[4,3,4]  R1783     -1.8710391223430634e-01
    z[4,3,4]  R1784     4.4314882159233093e-01
    z[4,3,4]  R1785     -1.6496485471725464e-01
    z[4,3,4]  R1786     -1.3414295017719269e-01
    z[4,3,4]  R1787     2.9464820027351379e-01
    z[4,3,4]  R1788     1.2383643537759781e-01
    z[4,3,4]  R1789     -4.0240734815597534e-01
    z[4,3,4]  R1790     3.8772711157798767e-01
    z[4,3,4]  R1791     1.3923652470111847e-01
    z[4,3,4]  R1792     -2.5536835193634033e-02
    z[4,3,4]  R1793     1.2949708104133606e-01
    z[4,3,4]  R1794     -2.2019621729850769e-01
    z[4,3,4]  R1795     1.0598796652629972e-03
    z[4,3,4]  R1796     8.8494084775447845e-02
    z[4,3,4]  R1797     -2.9208001494407654e-01
    z[4,3,4]  R1798     2.4737942218780518e-01
    z[4,3,4]  R1799     -8.6463037878274918e-03
    z[4,3,4]  R1800     2.9909974336624146e-01
    z[4,3,4]  R1801     1.0704813152551651e-01
    z[4,3,4]  R1802     0.446789026260376
    z[4,3,4]  R1803     -7.2337381541728973e-02
    z[4,3,4]  R1804     8.3119682967662811e-02
    z[4,3,4]  R1805     -2.2192949056625366e-01
    z[4,3,4]  R1806     -1.5212824940681458e-01
    z[4,3,4]  R1807     -2.1435758471488953e-01
    z[4,3,4]  R1808     -0.0946648046374321
    z[4,3,4]  R1809     3.6931118369102478e-01
    z[4,3,4]  R1810     0.379222571849823
    z[4,3,4]  R1811     -2.4310941994190216e-01
    z[4,3,4]  R1812     -2.5651225820183754e-02
    z[4,3,4]  R1813     1.2730209529399872e-01
    z[4,3,4]  R1814     1.7170648276805878e-01
    z[4,3,4]  R1815     5.5817224085330963e-02
    z[4,3,4]  R1816     -1.1799231171607971e-01
    z[4,3,4]  R1817     -2.0960466936230659e-03
    z[4,3,4]  R1818     4.3104174733161926e-01
    z[4,3,4]  R1819     2.8437113761901855e-01
    z[4,3,4]  R1820     3.1697955727577209e-01
    z[4,3,4]  R1821     -5.0764739513397217e-01
    z[4,3,4]  R1822     -2.5927874445915222e-01
    z[4,3,4]  R1823     1.0246764123439789e-01
    z[4,3,4]  R1824     -1.5932027995586395e-01
    z[4,3,4]  R1825     1.0432998090982437e-01
    z[4,3,4]  R1826     -3.1737962365150452e-01
    z[4,3,4]  R1827     -1.3017675280570984e-01
    z[4,3,4]  R1828     -4.1775807738304138e-01
    z[4,3,4]  R1829     -0.491071492433548
    z[4,3,4]  R1830     -1.2468812055885792e-02
    z[4,3,4]  R1831     -3.4238421916961670e-01
    z[4,3,4]  R1832     0.313882052898407
    z[4,3,4]  R1833     -0.17757648229599
    z[4,3,4]  R1834     2.2189372777938843e-01
    z[4,3,4]  R1835     1.3936987519264221e-01
    z[4,3,4]  R1836     8.0580234527587891e-02
    z[4,3,4]  R1837     3.1831413507461548e-01
    z[4,3,4]  R1838     -0.0188454482704401
    z[4,3,4]  R1839     1.6043645143508911e-01
    z[4,3,4]  R1840     3.3634293079376221e-01
    z[4,3,4]  R1841     5.3304746747016907e-02
    z[4,3,4]  R1842     -4.5975916087627411e-02
    z[4,3,4]  R1843     4.6409916132688522e-02
    z[4,3,4]  R1844     1.0899879038333893e-01
    z[4,3,4]  R1845     -2.2519369423389435e-01
    z[4,3,4]  R1846     -1.8193525075912476e-01
    z[4,3,4]  R1847     -1.2886960804462433e-01
    z[4,3,4]  R1848     2.3661321401596069e-01
    z[4,3,4]  R1849     6.2497023493051529e-02
    z[4,3,4]  R1850     7.5856409966945648e-02
    z[4,3,4]  R1851     -1.9202180206775665e-01
    z[4,3,4]  R1852     1.3539313338696957e-02
    z[4,3,4]  R1853     -0.0705077275633812
    z[4,3,4]  R1854     2.4219135940074921e-01
    z[4,3,4]  R1855     4.8514604568481445e-02
    z[4,3,4]  R1856     -0.034210454672575
    z[4,3,4]  R1857     -1.3851335644721985e-01
    z[4,3,4]  R1858     -9.0229168534278870e-02
    z[4,3,4]  R1859     2.8347185254096985e-01
    z[4,3,4]  R1860     7.8540280461311340e-02
    z[4,3,4]  R1861     -0.149052694439888
    z[4,3,4]  R1862     -3.3165118098258972e-01
    z[4,3,4]  R1863     4.7080585360527039e-01
    z[4,3,4]  R1864     1.0023064911365509e-01
    z[4,3,4]  R1865     -1.9911248981952667e-01
    z[4,3,4]  R1866     -2.5786471366882324e-01
    z[4,3,4]  R1867     -1.5476179122924805e-01
    z[4,3,4]  R1868     -5.5405050516128540e-01
    z[4,3,4]  R1869     -2.6255378127098083e-01
    z[4,3,4]  R1870     4.4327285140752792e-03
    z[4,3,4]  R1871     -1.2686847150325775e-01
    z[4,3,4]  R1872     4.2611941695213318e-02
    z[4,3,4]  R1873     -2.5303918123245239e-01
    z[4,3,4]  R1874     -9.9313586950302124e-02
    z[4,3,4]  R1875     1.6156564652919769e-01
    z[4,3,4]  R1876     -1.4396056532859802e-01
    z[4,3,4]  R1877     -2.7360531687736511e-01
    z[4,3,4]  R1878     2.3966661095619202e-01
    z[4,3,4]  R1879     1.1521905660629272e-01
    z[4,3,4]  R1880     -2.0077142119407654e-01
    z[4,3,4]  R1881     -2.2211013734340668e-01
    z[4,3,4]  R1882     -2.8791356086730957e-01
    z[4,3,4]  R1883     2.1502962335944176e-02
    z[4,3,4]  R1884     -1.7876857519149780e-01
    z[4,3,4]  R1885     2.1146588027477264e-01
    z[4,3,4]  R1886     -1.4546494185924530e-01
    z[4,3,4]  R1887     -2.7341198921203613e-01
    z[4,3,4]  R1888     -4.8977032303810120e-02
    z[4,3,4]  R1889     1.4836145937442780e-01
    z[4,3,4]  R1890     -2.3469938337802887e-01
    z[4,3,4]  R1891     -1.5348145365715027e-01
    z[4,3,4]  R1892     3.1884219497442245e-02
    z[4,3,4]  R1893     -3.7615177035331726e-01
    z[4,3,4]  R1894     1.6664399206638336e-01
    z[4,3,4]  R1895     -9.2443741858005524e-02
    z[4,3,4]  R1896     1.8520836532115936e-01
    z[4,3,4]  R1897     1.2274316698312759e-01
    z[4,3,4]  R1898     -0.0294036865234375
    z[4,3,4]  R1899     2.8596383333206177e-01
    z[4,3,4]  R1900     0.30115807056427
    z[4,3,4]  R1901     -4.5189487934112549e-01
    z[4,3,5]  R34       1
    z[4,3,5]  R43       -1
    z[4,3,5]  R1778     -1
    z[4,3,5]  R1779     1
    z[4,3,5]  R1782     -3.4275892376899719e-01
    z[4,3,5]  R1783     4.5087933540344238e-02
    z[4,3,5]  R1784     -2.9953157529234886e-02
    z[4,3,5]  R1785     -2.9334187507629395e-01
    z[4,3,5]  R1786     -2.0664717257022858e-01
    z[4,3,5]  R1787     -2.7806335687637329e-01
    z[4,3,5]  R1788     -8.7379798293113708e-02
    z[4,3,5]  R1789     -1.8528784811496735e-01
    z[4,3,5]  R1790     -1.8259078264236450e-01
    z[4,3,5]  R1791     -2.4348990619182587e-01
    z[4,3,5]  R1792     5.3352709859609604e-02
    z[4,3,5]  R1793     0.00816498976200819
    z[4,3,5]  R1794     2.2049862146377563e-01
    z[4,3,5]  R1795     1.4124831557273865e-01
    z[4,3,5]  R1796     6.3177652657032013e-02
    z[4,3,5]  R1797     -1.7479600384831429e-02
    z[4,3,5]  R1798     -2.2237753868103027e-01
    z[4,3,5]  R1799     2.3980200290679932e-01
    z[4,3,5]  R1800     3.1261703372001648e-01
    z[4,3,5]  R1801     -6.2608927488327026e-02
    z[4,3,5]  R1802     -5.2011895179748535e-01
    z[4,3,5]  R1803     3.6351811885833740e-01
    z[4,3,5]  R1804     1.7412659525871277e-01
    z[4,3,5]  R1805     4.7694477438926697e-01
    z[4,3,5]  R1806     -2.9019734263420105e-01
    z[4,3,5]  R1807     2.7124032378196716e-01
    z[4,3,5]  R1808     6.3384497165679932e-01
    z[4,3,5]  R1809     0.338814914226532
    z[4,3,5]  R1810     -4.9608775973320007e-01
    z[4,3,5]  R1811     -2.6866504549980164e-01
    z[4,3,5]  R1812     0.118772953748703
    z[4,3,5]  R1813     1.4905580878257751e-01
    z[4,3,5]  R1814     -3.9016890525817871e-01
    z[4,3,5]  R1815     1.9322144985198975e-01
    z[4,3,5]  R1816     4.0428814291954041e-01
    z[4,3,5]  R1817     -1.8809929490089417e-01
    z[4,3,5]  R1818     -3.2025733590126038e-01
    z[4,3,5]  R1819     -4.2974588274955750e-01
    z[4,3,5]  R1820     -2.5475805997848511e-01
    z[4,3,5]  R1821     -5.9276670217514038e-01
    z[4,3,5]  R1822     3.0984953045845032e-01
    z[4,3,5]  R1823     -1.6345185041427612e-01
    z[4,3,5]  R1824     -2.6504019275307655e-02
    z[4,3,5]  R1825     -3.3260446786880493e-01
    z[4,3,5]  R1826     -0.58106929063797
    z[4,3,5]  R1827     -3.7125506997108459e-01
    z[4,3,5]  R1828     -3.0003935098648071e-01
    z[4,3,5]  R1829     -3.7825220823287964e-01
    z[4,3,5]  R1830     -6.4805221557617188e-01
    z[4,3,5]  R1831     -5.2606594562530518e-01
    z[4,3,5]  R1832     -1.8468056619167328e-01
    z[4,3,5]  R1833     -2.4679200351238251e-01
    z[4,3,5]  R1834     -9.3075439333915710e-02
    z[4,3,5]  R1835     -2.2437015548348427e-02
    z[4,3,5]  R1836     3.1480625271797180e-02
    z[4,3,5]  R1837     -1.7917092144489288e-01
    z[4,3,5]  R1838     -2.0761974155902863e-01
    z[4,3,5]  R1839     1.2972506880760193e-01
    z[4,3,5]  R1840     -2.0474882423877716e-01
    z[4,3,5]  R1841     -3.4563150256872177e-02
    z[4,3,5]  R1842     1.7839744687080383e-01
    z[4,3,5]  R1843     -5.3027976304292679e-02
    z[4,3,5]  R1844     6.5192244946956635e-02
    z[4,3,5]  R1845     1.6985410451889038e-01
    z[4,3,5]  R1846     -1.0913661867380142e-01
    z[4,3,5]  R1847     -2.4268977344036102e-01
    z[4,3,5]  R1848     4.9006618559360504e-02
    z[4,3,5]  R1849     8.3451326936483383e-03
    z[4,3,5]  R1850     -3.5888835787773132e-01
    z[4,3,5]  R1851     2.9074522852897644e-01
    z[4,3,5]  R1852     -0.226058229804039
    z[4,3,5]  R1853     -3.7904545664787292e-01
    z[4,3,5]  R1854     -7.0306479930877686e-02
    z[4,3,5]  R1855     -4.7628339380025864e-02
    z[4,3,5]  R1856     -2.0866043865680695e-01
    z[4,3,5]  R1857     2.4772900342941284e-01
    z[4,3,5]  R1858     7.1531340479850769e-02
    z[4,3,5]  R1859     -5.2819490432739258e-02
    z[4,3,5]  R1860     1.6068877279758453e-01
    z[4,3,5]  R1861     -9.9442936480045319e-02
    z[4,3,5]  R1862     -0.54718416929245
    z[4,3,5]  R1863     -0.462632954120636
    z[4,3,5]  R1864     7.9853492975234985e-01
    z[4,3,5]  R1865     7.0025348663330078e-01
    z[4,3,5]  R1866     -1.6692537069320679e-01
    z[4,3,5]  R1867     -1.2781160883605480e-02
    z[4,3,5]  R1868     0.666630208492279
    z[4,3,5]  R1869     8.0307203531265259e-01
    z[4,3,5]  R1870     -1.8419317901134491e-01
    z[4,3,5]  R1871     1.7388838529586792e-01
    z[4,3,5]  R1872     -5.7286724448204041e-02
    z[4,3,5]  R1873     0.718159019947052
    z[4,3,5]  R1874     3.6404278874397278e-01
    z[4,3,5]  R1875     0.460068941116333
    z[4,3,5]  R1876     2.9649391770362854e-01
    z[4,3,5]  R1877     6.6731852293014526e-01
    z[4,3,5]  R1878     -4.3767508864402771e-01
    z[4,3,5]  R1879     -5.4317567497491837e-02
    z[4,3,5]  R1880     5.4549443721771240e-01
    z[4,3,5]  R1881     4.6343334019184113e-02
    z[4,3,5]  R1882     -1.0235474258661270e-01
    z[4,3,5]  R1883     -4.3656334280967712e-01
    z[4,3,5]  R1884     4.0708357095718384e-01
    z[4,3,5]  R1885     -2.6709970831871033e-01
    z[4,3,5]  R1886     3.8735663890838623e-01
    z[4,3,5]  R1887     -9.8011508584022522e-02
    z[4,3,5]  R1888     -3.4187024831771851e-01
    z[4,3,5]  R1889     3.1506073474884033e-01
    z[4,3,5]  R1890     1.2127444893121719e-01
    z[4,3,5]  R1891     -1.1943063884973526e-01
    z[4,3,5]  R1892     -2.2009097039699554e-01
    z[4,3,5]  R1893     -0.613559365272522
    z[4,3,5]  R1894     -5.5540448427200317e-01
    z[4,3,5]  R1895     -2.3913922905921936e-01
    z[4,3,5]  R1896     3.8042879104614258e-01
    z[4,3,5]  R1897     -6.5704119205474854e-01
    z[4,3,5]  R1898     0.292542964220047
    z[4,3,5]  R1899     1.0635441541671753e-01
    z[4,3,5]  R1900     -1.6225801780819893e-02
    z[4,3,5]  R1901     7.6356399059295654e-01
    z[4,3,6]  R35       1
    z[4,3,6]  R44       -1
    z[4,3,6]  R1780     -1
    z[4,3,6]  R1781     1
    z[4,3,6]  R1782     -2.7031236886978149e-01
    z[4,3,6]  R1783     -3.6006903648376465e-01
    z[4,3,6]  R1784     -8.4542363882064819e-02
    z[4,3,6]  R1785     1.9825683534145355e-01
    z[4,3,6]  R1786     1.8086800118908286e-03
    z[4,3,6]  R1787     3.8836565613746643e-01
    z[4,3,6]  R1788     1.0225946456193924e-01
    z[4,3,6]  R1789     -1.9530941545963287e-01
    z[4,3,6]  R1790     5.5214506387710571e-01
    z[4,3,6]  R1791     5.6081664562225342e-01
    z[4,3,6]  R1792     1.3139556348323822e-01
    z[4,3,6]  R1793     2.6312194764614105e-02
    z[4,3,6]  R1794     -1.8855512142181396e-01
    z[4,3,6]  R1795     0.219558984041214
    z[4,3,6]  R1796     5.1874320954084396e-02
    z[4,3,6]  R1797     -3.6246750503778458e-02
    z[4,3,6]  R1798     5.1881197839975357e-02
    z[4,3,6]  R1799     -2.6275175809860229e-01
    z[4,3,6]  R1800     1.5936821699142456e-01
    z[4,3,6]  R1801     4.5621609687805176e-01
    z[4,3,6]  R1802     1.3237684965133667e-01
    z[4,3,6]  R1803     -1.1799604445695877e-01
    z[4,3,6]  R1804     -1.3395063579082489e-01
    z[4,3,6]  R1805     7.1930542588233948e-02
    z[4,3,6]  R1806     -4.8952198028564453e-01
    z[4,3,6]  R1807     -5.1462358236312866e-01
    z[4,3,6]  R1808     2.2167497873306274e-01
    z[4,3,6]  R1809     -4.1103911399841309e-01
    z[4,3,6]  R1810     -6.3495904207229614e-01
    z[4,3,6]  R1811     -1.5159158408641815e-01
    z[4,3,6]  R1812     3.2869648933410645e-01
    z[4,3,6]  R1813     -1.1322646588087082e-01
    z[4,3,6]  R1814     -3.7916172295808792e-02
    z[4,3,6]  R1815     -9.0696640312671661e-02
    z[4,3,6]  R1816     -2.8596329689025879e-01
    z[4,3,6]  R1817     3.6390227614901960e-04
    z[4,3,6]  R1818     -4.5304756611585617e-02
    z[4,3,6]  R1819     -4.6856012195348740e-02
    z[4,3,6]  R1820     -6.9118463993072510e-01
    z[4,3,6]  R1821     -3.0608588829636574e-02
    z[4,3,6]  R1822     2.1094322204589844e-02
    z[4,3,6]  R1823     1.8923284113407135e-01
    z[4,3,6]  R1824     1.3367126882076263e-01
    z[4,3,6]  R1825     -1.2137117236852646e-01
    z[4,3,6]  R1826     -9.0393684804439545e-02
    z[4,3,6]  R1827     2.7407559752464294e-01
    z[4,3,6]  R1828     3.3861619234085083e-01
    z[4,3,6]  R1829     2.1317753195762634e-01
    z[4,3,6]  R1830     1.0882806777954102e-01
    z[4,3,6]  R1831     3.0970957130193710e-02
    z[4,3,6]  R1832     -5.4451610893011093e-02
    z[4,3,6]  R1833     -0.385977566242218
    z[4,3,6]  R1834     -2.0393805205821991e-01
    z[4,3,6]  R1835     4.6617004275321960e-01
    z[4,3,6]  R1836     -0.387576699256897
    z[4,3,6]  R1837     -3.3300212025642395e-01
    z[4,3,6]  R1838     4.6243309974670410e-02
    z[4,3,6]  R1839     6.3250800594687462e-03
    z[4,3,6]  R1840     2.3546755313873291e-01
    z[4,3,6]  R1841     7.6464921236038208e-02
    z[4,3,6]  R1842     -1.3288977742195129e-01
    z[4,3,6]  R1843     1.8841318786144257e-02
    z[4,3,6]  R1844     -9.7866818308830261e-02
    z[4,3,6]  R1845     -0.0775921568274498
    z[4,3,6]  R1846     1.8998172879219055e-01
    z[4,3,6]  R1847     1.1523085087537766e-01
    z[4,3,6]  R1848     1.6446661949157715e-01
    z[4,3,6]  R1849     2.0641405880451202e-01
    z[4,3,6]  R1850     2.5323063135147095e-01
    z[4,3,6]  R1851     1.8000033497810364e-01
    z[4,3,6]  R1852     -9.4732239842414856e-02
    z[4,3,6]  R1853     -1.4579197764396667e-01
    z[4,3,6]  R1854     -4.5361623167991638e-02
    z[4,3,6]  R1855     -7.9353392124176025e-02
    z[4,3,6]  R1856     2.2805716097354889e-01
    z[4,3,6]  R1857     1.0872198641300201e-01
    z[4,3,6]  R1858     -7.5266361236572266e-02
    z[4,3,6]  R1859     -8.2955874502658844e-02
    z[4,3,6]  R1860     1.8072535097599030e-01
    z[4,3,6]  R1861     1.6203030943870544e-01
    z[4,3,6]  R1862     2.6618912816047668e-01
    z[4,3,6]  R1863     -2.3902162909507751e-02
    z[4,3,6]  R1864     -1.0881227999925613e-01
    z[4,3,6]  R1865     2.6119291782379150e-01
    z[4,3,6]  R1866     -7.6266713440418243e-02
    z[4,3,6]  R1867     6.3522164709866047e-03
    z[4,3,6]  R1868     3.5366213414818048e-03
    z[4,3,6]  R1869     -5.9513486921787262e-02
    z[4,3,6]  R1870     1.8727298080921173e-01
    z[4,3,6]  R1871     2.1614888310432434e-01
    z[4,3,6]  R1872     -9.7504250705242157e-02
    z[4,3,6]  R1873     -2.4339678883552551e-01
    z[4,3,6]  R1874     -1.3363434374332428e-01
    z[4,3,6]  R1875     -8.7864056229591370e-02
    z[4,3,6]  R1876     5.2130836993455887e-03
    z[4,3,6]  R1877     1.1075641214847565e-01
    z[4,3,6]  R1878     3.4520891308784485e-01
    z[4,3,6]  R1879     -8.6348660290241241e-02
    z[4,3,6]  R1880     8.7730973958969116e-02
    z[4,3,6]  R1881     -0.294983834028244
    z[4,3,6]  R1882     -3.8469800353050232e-01
    z[4,3,6]  R1883     -4.9401441216468811e-01
    z[4,3,6]  R1884     1.1346577107906342e-01
    z[4,3,6]  R1885     -4.6004495024681091e-01
    z[4,3,6]  R1886     -1.3438005745410919e-01
    z[4,3,6]  R1887     -1.7469539307057858e-03
    z[4,3,6]  R1888     1.4967045187950134e-01
    z[4,3,6]  R1889     -2.0855763554573059e-01
    z[4,3,6]  R1890     -4.2886976152658463e-02
    z[4,3,6]  R1891     -3.6438378691673279e-01
    z[4,3,6]  R1892     -3.7644156813621521e-01
    z[4,3,6]  R1893     -0.290274441242218
    z[4,3,6]  R1894     -2.1499957144260406e-01
    z[4,3,6]  R1895     4.1045309044420719e-03
    z[4,3,6]  R1896     -4.7545540332794189e-01
    z[4,3,6]  R1897     3.7156778573989868e-01
    z[4,3,6]  R1898     -0.0534537211060524
    z[4,3,6]  R1899     3.0226361751556396e-01
    z[4,3,6]  R1900     1.2297625839710236e-01
    z[4,3,6]  R1901     -1.8238408863544464e-01
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R1986     -1
    z[4,5,0]  R1987     1
    z[4,5,0]  R2000     1.8273948132991791e-01
    z[4,5,0]  R2001     7.5243353843688965e-02
    z[4,5,0]  R2002     -2.0890556275844574e-01
    z[4,5,0]  R2003     6.4720004796981812e-01
    z[4,5,0]  R2004     2.2473375499248505e-01
    z[4,5,0]  R2005     3.4467941522598267e-01
    z[4,5,0]  R2006     -1.7299796640872955e-01
    z[4,5,0]  R2007     2.0742221176624298e-01
    z[4,5,0]  R2008     6.4767844974994659e-02
    z[4,5,0]  R2009     2.0509274303913116e-01
    z[4,5,0]  R2010     -1.0053467005491257e-01
    z[4,5,0]  R2011     1.3686452805995941e-01
    z[4,5,0]  R2012     -1.1812112480401993e-01
    z[4,5,0]  R2013     1.1632069945335388e-01
    z[4,5,0]  R2014     -4.2024865746498108e-02
    z[4,5,0]  R2015     2.4728041887283325e-01
    z[4,5,0]  R2016     3.3589640259742737e-01
    z[4,5,0]  R2017     -0.0842878594994545
    z[4,5,0]  R2018     -0.0749136209487915
    z[4,5,0]  R2019     6.1640333384275436e-02
    z[4,5,0]  R2020     -3.2477363944053650e-02
    z[4,5,0]  R2021     -1.2521438300609589e-01
    z[4,5,0]  R2022     -9.0394169092178345e-02
    z[4,5,0]  R2023     -1.7760178446769714e-01
    z[4,5,0]  R2024     0.206633523106575
    z[4,5,0]  R2025     2.0787317771464586e-03
    z[4,5,0]  R2026     -1.7261725664138794e-01
    z[4,5,0]  R2027     1.8793597817420959e-01
    z[4,5,0]  R2028     -7.3890708386898041e-02
    z[4,5,0]  R2029     -5.5151319503784180e-01
    z[4,5,0]  R2030     8.4341593086719513e-02
    z[4,5,0]  R2031     -2.9460051655769348e-01
    z[4,5,0]  R2032     2.2809910774230957e-01
    z[4,5,0]  R2033     1.8554365634918213e-01
    z[4,5,0]  R2034     -1.5891253948211670e-01
    z[4,5,0]  R2035     2.3968566954135895e-01
    z[4,5,0]  R2036     1.2430764734745026e-01
    z[4,5,0]  R2037     -1.7151252925395966e-01
    z[4,5,0]  R2038     -3.8300785422325134e-01
    z[4,5,0]  R2039     -2.5668612122535706e-01
    z[4,5,0]  R2040     -1.6947200521826744e-02
    z[4,5,0]  R2041     3.4027022123336792e-01
    z[4,5,0]  R2042     2.6533061265945435e-01
    z[4,5,0]  R2043     -2.0327101647853851e-01
    z[4,5,0]  R2044     -9.8297879099845886e-02
    z[4,5,0]  R2045     -4.8372265696525574e-01
    z[4,5,0]  R2046     -1.4247813820838928e-01
    z[4,5,0]  R2047     -5.4091745615005493e-01
    z[4,5,0]  R2048     -4.2434650659561157e-01
    z[4,5,0]  R2049     -6.4929658174514771e-01
    z[4,5,0]  R2050     -1.1327574402093887e-01
    z[4,5,0]  R2051     1.1821000277996063e-01
    z[4,5,0]  R2052     -3.5126686096191406e-01
    z[4,5,0]  R2053     2.0345158874988556e-01
    z[4,5,0]  R2054     1.5866951644420624e-01
    z[4,5,0]  R2055     1.4918965101242065e-01
    z[4,5,0]  R2056     1.4596323668956757e-01
    z[4,5,0]  R2057     -5.2205246686935425e-01
    z[4,5,0]  R2058     -4.4384837150573730e-01
    z[4,5,0]  R2059     -0.854417622089386
    z[4,5,0]  R2060     3.4748545289039612e-01
    z[4,5,0]  R2061     -1.2408905476331711e-01
    z[4,5,0]  R2062     1.9600579142570496e-01
    z[4,5,0]  R2063     1.4159527420997620e-01
    z[4,5,0]  R2064     0.352468878030777
    z[4,5,0]  R2065     2.5963535904884338e-01
    z[4,5,0]  R2066     1.6861203312873840e-01
    z[4,5,0]  R2067     1.5843059122562408e-01
    z[4,5,0]  R2068     1.5164570510387421e-01
    z[4,5,0]  R2069     1.8139271438121796e-01
    z[4,5,0]  R2070     1.8842476606369019e-01
    z[4,5,0]  R2071     -1.6518227756023407e-02
    z[4,5,0]  R2072     3.1579241156578064e-02
    z[4,5,0]  R2073     -3.2002660632133484e-01
    z[4,5,0]  R2074     -2.0104108750820160e-01
    z[4,5,0]  R2075     -2.2300831973552704e-01
    z[4,5,0]  R2076     5.1281917095184326e-01
    z[4,5,0]  R2077     2.4213770031929016e-01
    z[4,5,0]  R2078     1.4620113186538219e-02
    z[4,5,0]  R2079     2.5184684991836548e-01
    z[4,5,0]  R2080     -0.406929075717926
    z[4,5,0]  R2081     -2.2387205064296722e-01
    z[4,5,0]  R2082     3.8542559742927551e-01
    z[4,5,0]  R2083     -2.3967489600181580e-01
    z[4,5,0]  R2084     -2.3025350272655487e-01
    z[4,5,0]  R2085     -3.9414188265800476e-01
    z[4,5,0]  R2086     -7.0512875914573669e-02
    z[4,5,0]  R2087     4.3129718303680420e-01
    z[4,5,0]  R2088     -4.4638893008232117e-01
    z[4,5,0]  R2089     0.214206725358963
    z[4,5,0]  R2090     -2.7951663732528687e-01
    z[4,5,0]  R2091     6.2482478097081184e-03
    z[4,5,0]  R2092     -5.6338828802108765e-01
    z[4,5,0]  R2093     -2.9648989439010620e-01
    z[4,5,0]  R2094     -2.6210770010948181e-01
    z[4,5,0]  R2095     -0.746512770652771
    z[4,5,0]  R2096     -1.4326098561286926e-01
    z[4,5,0]  R2097     -8.8023543357849121e-03
    z[4,5,0]  R2098     6.6120497882366180e-02
    z[4,5,0]  R2099     2.4554353952407837e-01
    z[4,5,0]  R2100     -5.1022070646286011e-01
    z[4,5,0]  R2101     -7.1848720312118530e-01
    z[4,5,0]  R2102     2.2021791338920593e-01
    z[4,5,0]  R2103     0.188834086060524
    z[4,5,0]  R2104     4.7437706589698792e-01
    z[4,5,0]  R2105     4.6587541699409485e-01
    z[4,5,0]  R2106     7.2910927236080170e-02
    z[4,5,0]  R2107     7.2841948270797729e-01
    z[4,5,0]  R2108     3.0446156859397888e-01
    z[4,5,0]  R2109     5.4198443889617920e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R1988     -1
    z[4,5,1]  R1989     1
    z[4,5,1]  R2000     -8.1072676181793213e-01
    z[4,5,1]  R2001     -6.7871409654617310e-01
    z[4,5,1]  R2002     -6.7564535140991211e-01
    z[4,5,1]  R2003     -6.3561600446701050e-01
    z[4,5,1]  R2004     -4.6969485282897949e-01
    z[4,5,1]  R2005     -6.1447870731353760e-01
    z[4,5,1]  R2006     -4.5773589611053467e-01
    z[4,5,1]  R2007     -5.2216702699661255e-01
    z[4,5,1]  R2008     -4.9167856574058533e-01
    z[4,5,1]  R2009     -5.1526272296905518e-01
    z[4,5,1]  R2010     9.1978579759597778e-01
    z[4,5,1]  R2011     9.0769237279891968e-01
    z[4,5,1]  R2012     8.8948029279708862e-01
    z[4,5,1]  R2013     8.7213045358657837e-01
    z[4,5,1]  R2014     8.9554357528686523e-01
    z[4,5,1]  R2015     0.841696560382843
    z[4,5,1]  R2016     8.5505813360214233e-01
    z[4,5,1]  R2017     8.2347893714904785e-01
    z[4,5,1]  R2018     8.3122414350509644e-01
    z[4,5,1]  R2019     8.2374644279479980e-01
    z[4,5,1]  R2020     6.2490773200988770e-01
    z[4,5,1]  R2021     -4.6254453063011169e-01
    z[4,5,1]  R2022     -3.9497679471969604e-01
    z[4,5,1]  R2023     -4.7766700387001038e-01
    z[4,5,1]  R2024     -1.5034003555774689e-01
    z[4,5,1]  R2025     -4.6923229098320007e-01
    z[4,5,1]  R2026     -0.536043643951416
    z[4,5,1]  R2027     -4.5698961615562439e-01
    z[4,5,1]  R2028     3.9782455563545227e-01
    z[4,5,1]  R2029     -1.7178170382976532e-01
    z[4,5,1]  R2030     -8.6554270982742310e-01
    z[4,5,1]  R2031     -6.4300930500030518e-01
    z[4,5,1]  R2032     8.4201908111572266e-01
    z[4,5,1]  R2033     -7.0415306091308594e-01
    z[4,5,1]  R2034     -7.0064681768417358e-01
    z[4,5,1]  R2035     -3.7490347027778625e-01
    z[4,5,1]  R2036     -3.7599790096282959e-01
    z[4,5,1]  R2037     0.580936849117279
    z[4,5,1]  R2038     4.4202911853790283e-01
    z[4,5,1]  R2039     1.0483112186193466e-01
    z[4,5,1]  R2040     -8.6755198240280151e-01
    z[4,5,1]  R2041     -8.3970564603805542e-01
    z[4,5,1]  R2042     -7.3522913455963135e-01
    z[4,5,1]  R2043     6.9517850875854492e-01
    z[4,5,1]  R2044     9.3139477074146271e-02
    z[4,5,1]  R2045     -5.8083377778530121e-02
    z[4,5,1]  R2046     2.4324165657162666e-02
    z[4,5,1]  R2047     -4.4814877212047577e-02
    z[4,5,1]  R2048     -3.8592919707298279e-02
    z[4,5,1]  R2049     -2.4696400389075279e-02
    z[4,5,1]  R2050     9.0267688035964966e-01
    z[4,5,1]  R2051     8.7850195169448853e-01
    z[4,5,1]  R2052     8.0297881364822388e-01
    z[4,5,1]  R2053     8.2115840911865234e-01
    z[4,5,1]  R2054     -4.2180785536766052e-01
    z[4,5,1]  R2055     7.3890346288681030e-01
    z[4,5,1]  R2056     0.775105357170105
    z[4,5,1]  R2057     -6.7736494541168213e-01
    z[4,5,1]  R2058     -3.3908748626708984e-01
    z[4,5,1]  R2059     -4.1606849431991577e-01
    z[4,5,1]  R2060     -7.6730751991271973e-01
    z[4,5,1]  R2061     -7.0995074510574341e-01
    z[4,5,1]  R2062     -6.6837781667709351e-01
    z[4,5,1]  R2063     -6.6868335008621216e-01
    z[4,5,1]  R2064     -6.8870180845260620e-01
    z[4,5,1]  R2065     -0.689148485660553
    z[4,5,1]  R2066     -0.724707841873169
    z[4,5,1]  R2067     -6.5316039323806763e-01
    z[4,5,1]  R2068     -6.6812676191329956e-01
    z[4,5,1]  R2069     -5.3825861215591431e-01
    z[4,5,1]  R2070     -8.6119043827056885e-01
    z[4,5,1]  R2071     -7.1934396028518677e-01
    z[4,5,1]  R2072     -6.6734534502029419e-01
    z[4,5,1]  R2073     -3.2121309638023376e-01
    z[4,5,1]  R2074     -3.4441930055618286e-01
    z[4,5,1]  R2075     -7.9870028421282768e-03
    z[4,5,1]  R2076     7.0969969034194946e-01
    z[4,5,1]  R2077     -3.8341563940048218e-01
    z[4,5,1]  R2078     8.0171310901641846e-01
    z[4,5,1]  R2079     6.8133169412612915e-01
    z[4,5,1]  R2080     -8.1819391250610352e-01
    z[4,5,1]  R2081     -8.3834046125411987e-01
    z[4,5,1]  R2082     8.9345055818557739e-01
    z[4,5,1]  R2083     8.7546640634536743e-01
    z[4,5,1]  R2084     -5.0110530853271484e-01
    z[4,5,1]  R2085     -5.1602822542190552e-01
    z[4,5,1]  R2086     -3.5946887731552124e-01
    z[4,5,1]  R2087     -3.1774255633354187e-01
    z[4,5,1]  R2088     -2.0169923081994057e-02
    z[4,5,1]  R2089     6.5325963497161865e-01
    z[4,5,1]  R2090     -5.1344031095504761e-01
    z[4,5,1]  R2091     7.9660427570343018e-01
    z[4,5,1]  R2092     -3.0994272232055664e-01
    z[4,5,1]  R2093     7.2402888536453247e-01
    z[4,5,1]  R2094     -5.4558837413787842e-01
    z[4,5,1]  R2095     -3.2240059226751328e-02
    z[4,5,1]  R2096     0.500961422920227
    z[4,5,1]  R2097     0.430346816778183
    z[4,5,1]  R2098     -5.9856027364730835e-01
    z[4,5,1]  R2099     -8.0516338348388672e-02
    z[4,5,1]  R2100     7.1003675460815430e-01
    z[4,5,1]  R2101     -2.7539357542991638e-01
    z[4,5,1]  R2102     -7.8431165218353271e-01
    z[4,5,1]  R2103     6.0737508535385132e-01
    z[4,5,1]  R2104     -2.3485994338989258e-01
    z[4,5,1]  R2105     -3.7489861249923706e-01
    z[4,5,1]  R2106     -4.6983989886939526e-04
    z[4,5,1]  R2107     -2.7126595377922058e-01
    z[4,5,1]  R2108     -0.0902019739151001
    z[4,5,1]  R2109     -9.1256782412528992e-02
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R1990     -1
    z[4,5,2]  R1991     1
    z[4,5,2]  R2000     4.6575747430324554e-02
    z[4,5,2]  R2001     -4.4898384809494019e-01
    z[4,5,2]  R2002     -3.9891722798347473e-01
    z[4,5,2]  R2003     -1.3940635323524475e-01
    z[4,5,2]  R2004     -0.392828106880188
    z[4,5,2]  R2005     -3.9671313762664795e-01
    z[4,5,2]  R2006     -1.5920653939247131e-02
    z[4,5,2]  R2007     3.0823811888694763e-01
    z[4,5,2]  R2008     -1.7982932925224304e-01
    z[4,5,2]  R2009     4.2525655031204224e-01
    z[4,5,2]  R2010     1.4306181669235229e-01
    z[4,5,2]  R2011     -1.1526767164468765e-01
    z[4,5,2]  R2012     -2.4151550233364105e-01
    z[4,5,2]  R2013     1.8396852910518646e-01
    z[4,5,2]  R2014     -4.1573038697242737e-01
    z[4,5,2]  R2015     2.9827040433883667e-01
    z[4,5,2]  R2016     2.0655937492847443e-01
    z[4,5,2]  R2017     4.3210950493812561e-01
    z[4,5,2]  R2018     2.8976443409919739e-01
    z[4,5,2]  R2019     2.5015175342559814e-01
    z[4,5,2]  R2020     -1.1019866913557053e-01
    z[4,5,2]  R2021     5.0250756740570068e-01
    z[4,5,2]  R2022     5.8804297447204590e-01
    z[4,5,2]  R2023     6.0417884588241577e-01
    z[4,5,2]  R2024     6.4746642112731934e-01
    z[4,5,2]  R2025     1.5681222081184387e-01
    z[4,5,2]  R2026     1.3179703056812286e-01
    z[4,5,2]  R2027     -4.0013585239648819e-02
    z[4,5,2]  R2028     -0.195712149143219
    z[4,5,2]  R2029     -1.1446216702461243e-01
    z[4,5,2]  R2030     3.0641865730285645e-01
    z[4,5,2]  R2031     6.6967093944549561e-01
    z[4,5,2]  R2032     -1.8188336491584778e-01
    z[4,5,2]  R2033     -3.5695701837539673e-01
    z[4,5,2]  R2034     0.272125780582428
    z[4,5,2]  R2035     7.3076236248016357e-01
    z[4,5,2]  R2036     4.7682681679725647e-01
    z[4,5,2]  R2037     5.7388770580291748e-01
    z[4,5,2]  R2038     -2.4268349632620811e-02
    z[4,5,2]  R2039     -1.3904811441898346e-01
    z[4,5,2]  R2040     1.0298167914152145e-01
    z[4,5,2]  R2041     2.3890449106693268e-01
    z[4,5,2]  R2042     0.562421441078186
    z[4,5,2]  R2043     1.2121919542551041e-01
    z[4,5,2]  R2044     -3.0836266279220581e-01
    z[4,5,2]  R2045     -5.7609234005212784e-02
    z[4,5,2]  R2046     -2.4657705426216125e-01
    z[4,5,2]  R2047     1.0175630450248718e-01
    z[4,5,2]  R2048     -1.5905712544918060e-01
    z[4,5,2]  R2049     1.7889384925365448e-01
    z[4,5,2]  R2050     -2.2743935883045197e-01
    z[4,5,2]  R2051     -1.9896794855594635e-01
    z[4,5,2]  R2052     2.6907011866569519e-01
    z[4,5,2]  R2053     -7.0819951593875885e-02
    z[4,5,2]  R2054     -0.866377055644989
    z[4,5,2]  R2055     0.3300761282444
    z[4,5,2]  R2056     -2.3459206521511078e-01
    z[4,5,2]  R2057     -2.7051535248756409e-01
    z[4,5,2]  R2058     -7.5094038248062134e-01
    z[4,5,2]  R2059     -1.8892247974872589e-01
    z[4,5,2]  R2060     -6.9927543401718140e-02
    z[4,5,2]  R2061     4.7661286592483521e-01
    z[4,5,2]  R2062     3.4003669023513794e-01
    z[4,5,2]  R2063     9.9839836359024048e-02
    z[4,5,2]  R2064     2.5200808048248291e-01
    z[4,5,2]  R2065     2.2952046990394592e-01
    z[4,5,2]  R2066     4.0556395053863525e-01
    z[4,5,2]  R2067     4.4633349776268005e-01
    z[4,5,2]  R2068     3.1033965945243835e-01
    z[4,5,2]  R2069     0.05144052952528
    z[4,5,2]  R2070     -2.4051231145858765e-01
    z[4,5,2]  R2071     -1.4661246538162231e-01
    z[4,5,2]  R2072     4.6668898314237595e-02
    z[4,5,2]  R2073     -4.7202974557876587e-01
    z[4,5,2]  R2074     -5.4179519414901733e-01
    z[4,5,2]  R2075     -4.4095999002456665e-01
    z[4,5,2]  R2076     3.7452599406242371e-01
    z[4,5,2]  R2077     -4.8140594363212585e-01
    z[4,5,2]  R2078     0.00958534050732851
    z[4,5,2]  R2079     5.9043139219284058e-01
    z[4,5,2]  R2080     -2.9375061858445406e-03
    z[4,5,2]  R2081     5.9286791831254959e-02
    z[4,5,2]  R2082     1.3947954773902893e-01
    z[4,5,2]  R2083     -8.9126199483871460e-02
    z[4,5,2]  R2084     -4.3336143717169762e-03
    z[4,5,2]  R2085     -1.2201385945081711e-01
    z[4,5,2]  R2086     -3.6684155464172363e-01
    z[4,5,2]  R2087     -4.4460549950599670e-01
    z[4,5,2]  R2088     -4.5316964387893677e-01
    z[4,5,2]  R2089     0.624812662601471
    z[4,5,2]  R2090     -2.8168469667434692e-01
    z[4,5,2]  R2091     -2.1682465448975563e-02
    z[4,5,2]  R2092     -2.8477707505226135e-01
    z[4,5,2]  R2093     -6.5252050757408142e-02
    z[4,5,2]  R2094     -6.0091644525527954e-01
    z[4,5,2]  R2095     -3.7112745642662048e-01
    z[4,5,2]  R2096     6.2278604507446289e-01
    z[4,5,2]  R2097     0.732809841632843
    z[4,5,2]  R2098     -3.1777489185333252e-01
    z[4,5,2]  R2099     1.8926402926445007e-01
    z[4,5,2]  R2100     2.5441799312829971e-02
    z[4,5,2]  R2101     -3.5456672310829163e-01
    z[4,5,2]  R2102     -3.9431047439575195e-01
    z[4,5,2]  R2103     5.3239309787750244e-01
    z[4,5,2]  R2104     -3.5722586512565613e-01
    z[4,5,2]  R2105     -1.5683230757713318e-01
    z[4,5,2]  R2106     1.3258498907089233e-01
    z[4,5,2]  R2107     -1.2050031125545502e-01
    z[4,5,2]  R2108     -1.5476141870021820e-01
    z[4,5,2]  R2109     7.6779276132583618e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R1992     -1
    z[4,5,3]  R1993     1
    z[4,5,3]  R2000     -3.2698315382003784e-01
    z[4,5,3]  R2001     -4.0670457482337952e-01
    z[4,5,3]  R2002     -3.6919006705284119e-01
    z[4,5,3]  R2003     7.1565821766853333e-02
    z[4,5,3]  R2004     -7.1684509515762329e-01
    z[4,5,3]  R2005     -1.7682163417339325e-01
    z[4,5,3]  R2006     -8.5256582498550415e-01
    z[4,5,3]  R2007     -0.595733106136322
    z[4,5,3]  R2008     -4.8289006948471069e-01
    z[4,5,3]  R2009     -3.4410575032234192e-01
    z[4,5,3]  R2010     3.2040110230445862e-01
    z[4,5,3]  R2011     -3.5573536157608032e-01
    z[4,5,3]  R2012     -6.2316235154867172e-02
    z[4,5,3]  R2013     -3.5193055868148804e-01
    z[4,5,3]  R2014     -9.4288922846317291e-02
    z[4,5,3]  R2015     -2.3346070945262909e-01
    z[4,5,3]  R2016     -6.5149967558681965e-03
    z[4,5,3]  R2017     -3.7961628288030624e-02
    z[4,5,3]  R2018     -8.3082199096679688e-02
    z[4,5,3]  R2019     -1.7763453722000122e-01
    z[4,5,3]  R2020     -3.2958149909973145e-01
    z[4,5,3]  R2021     6.0544097423553467e-01
    z[4,5,3]  R2022     0.659436047077179
    z[4,5,3]  R2023     3.0554351210594177e-01
    z[4,5,3]  R2024     4.1048571467399597e-01
    z[4,5,3]  R2025     6.0898989439010620e-01
    z[4,5,3]  R2026     4.5346373319625854e-01
    z[4,5,3]  R2027     5.7801395654678345e-01
    z[4,5,3]  R2028     6.9905549287796021e-02
    z[4,5,3]  R2029     7.0637071132659912e-01
    z[4,5,3]  R2030     -1.6438831388950348e-01
    z[4,5,3]  R2031     -6.8297930993139744e-03
    z[4,5,3]  R2032     1.5079972147941589e-01
    z[4,5,3]  R2033     5.4189282655715942e-01
    z[4,5,3]  R2034     3.8812670111656189e-01
    z[4,5,3]  R2035     4.8228484392166138e-01
    z[4,5,3]  R2036     5.7043421268463135e-01
    z[4,5,3]  R2037     -1.8974894285202026e-01
    z[4,5,3]  R2038     -1.1921525001525879e-01
    z[4,5,3]  R2039     5.4200851917266846e-01
    z[4,5,3]  R2040     -2.6978492736816406e-01
    z[4,5,3]  R2041     2.2138184309005737e-01
    z[4,5,3]  R2042     1.6960693895816803e-01
    z[4,5,3]  R2043     -0.569624662399292
    z[4,5,3]  R2044     6.6334950923919678e-01
    z[4,5,3]  R2045     7.2761672735214233e-01
    z[4,5,3]  R2046     0.734235405921936
    z[4,5,3]  R2047     5.1514565944671631e-01
    z[4,5,3]  R2048     6.0097473859786987e-01
    z[4,5,3]  R2049     3.8841915130615234e-01
    z[4,5,3]  R2050     2.0366741716861725e-01
    z[4,5,3]  R2051     -8.0570735037326813e-02
    z[4,5,3]  R2052     -8.3505190908908844e-02
    z[4,5,3]  R2053     8.0725461244583130e-02
    z[4,5,3]  R2054     -7.2167336940765381e-02
    z[4,5,3]  R2055     -2.2841072082519531e-01
    z[4,5,3]  R2056     4.0657523274421692e-01
    z[4,5,3]  R2057     -0.263260155916214
    z[4,5,3]  R2058     0.166749507188797
    z[4,5,3]  R2059     -1.0699054598808289e-01
    z[4,5,3]  R2060     4.3049424886703491e-01
    z[4,5,3]  R2061     4.2185938358306885e-01
    z[4,5,3]  R2062     5.9203559160232544e-01
    z[4,5,3]  R2063     6.1240088939666748e-01
    z[4,5,3]  R2064     5.3675752878189087e-01
    z[4,5,3]  R2065     5.6509578227996826e-01
    z[4,5,3]  R2066     4.6101042628288269e-01
    z[4,5,3]  R2067     5.4883146286010742e-01
    z[4,5,3]  R2068     3.9355498552322388e-01
    z[4,5,3]  R2069     4.2227292060852051e-01
    z[4,5,3]  R2070     2.5027993321418762e-01
    z[4,5,3]  R2071     5.1352363824844360e-01
    z[4,5,3]  R2072     5.5233132839202881e-01
    z[4,5,3]  R2073     1.2936948239803314e-01
    z[4,5,3]  R2074     4.5526260137557983e-01
    z[4,5,3]  R2075     -6.4852249622344971e-01
    z[4,5,3]  R2076     -6.5455652773380280e-02
    z[4,5,3]  R2077     -7.6473824679851532e-02
    z[4,5,3]  R2078     -3.1890928745269775e-01
    z[4,5,3]  R2079     -2.4057717621326447e-01
    z[4,5,3]  R2080     3.1125918030738831e-01
    z[4,5,3]  R2081     1.9973684847354889e-01
    z[4,5,3]  R2082     -3.6254484206438065e-02
    z[4,5,3]  R2083     5.7488363236188889e-02
    z[4,5,3]  R2084     6.2126670032739639e-02
    z[4,5,3]  R2085     2.3014867305755615e-01
    z[4,5,3]  R2086     -2.5437323376536369e-02
    z[4,5,3]  R2087     -5.4442435503005981e-01
    z[4,5,3]  R2088     -1.4999739825725555e-01
    z[4,5,3]  R2089     -3.1958681344985962e-01
    z[4,5,3]  R2090     2.1795186400413513e-01
    z[4,5,3]  R2091     -1.7320780456066132e-01
    z[4,5,3]  R2092     3.2342472672462463e-01
    z[4,5,3]  R2093     -3.4075376391410828e-01
    z[4,5,3]  R2094     -2.6483917608857155e-02
    z[4,5,3]  R2095     -4.7934178262948990e-02
    z[4,5,3]  R2096     1.0756554454565048e-01
    z[4,5,3]  R2097     2.1706764400005341e-01
    z[4,5,3]  R2098     3.6363206803798676e-02
    z[4,5,3]  R2099     -0.61332768201828
    z[4,5,3]  R2100     -2.5294670462608337e-01
    z[4,5,3]  R2101     2.6586598157882690e-01
    z[4,5,3]  R2102     2.7846372127532959e-01
    z[4,5,3]  R2103     5.0934362411499023e-01
    z[4,5,3]  R2104     -6.7820960283279419e-01
    z[4,5,3]  R2105     -3.7399837374687195e-01
    z[4,5,3]  R2106     -5.4185372591018677e-01
    z[4,5,3]  R2107     5.3974837064743042e-01
    z[4,5,3]  R2108     -4.6572342514991760e-01
    z[4,5,3]  R2109     -1.0125853121280670e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R1994     -1
    z[4,5,4]  R1995     1
    z[4,5,4]  R2000     9.8430924117565155e-02
    z[4,5,4]  R2001     -1.8710391223430634e-01
    z[4,5,4]  R2002     4.4314882159233093e-01
    z[4,5,4]  R2003     -1.6496485471725464e-01
    z[4,5,4]  R2004     -1.3414295017719269e-01
    z[4,5,4]  R2005     2.9464820027351379e-01
    z[4,5,4]  R2006     1.2383643537759781e-01
    z[4,5,4]  R2007     -4.0240734815597534e-01
    z[4,5,4]  R2008     3.8772711157798767e-01
    z[4,5,4]  R2009     1.3923652470111847e-01
    z[4,5,4]  R2010     -2.5536835193634033e-02
    z[4,5,4]  R2011     1.2949708104133606e-01
    z[4,5,4]  R2012     -2.2019621729850769e-01
    z[4,5,4]  R2013     1.0598796652629972e-03
    z[4,5,4]  R2014     8.8494084775447845e-02
    z[4,5,4]  R2015     -2.9208001494407654e-01
    z[4,5,4]  R2016     2.4737942218780518e-01
    z[4,5,4]  R2017     -8.6463037878274918e-03
    z[4,5,4]  R2018     2.9909974336624146e-01
    z[4,5,4]  R2019     1.0704813152551651e-01
    z[4,5,4]  R2020     0.446789026260376
    z[4,5,4]  R2021     -7.2337381541728973e-02
    z[4,5,4]  R2022     8.3119682967662811e-02
    z[4,5,4]  R2023     -2.2192949056625366e-01
    z[4,5,4]  R2024     -1.5212824940681458e-01
    z[4,5,4]  R2025     -2.1435758471488953e-01
    z[4,5,4]  R2026     -0.0946648046374321
    z[4,5,4]  R2027     3.6931118369102478e-01
    z[4,5,4]  R2028     0.379222571849823
    z[4,5,4]  R2029     -2.4310941994190216e-01
    z[4,5,4]  R2030     -2.5651225820183754e-02
    z[4,5,4]  R2031     1.2730209529399872e-01
    z[4,5,4]  R2032     1.7170648276805878e-01
    z[4,5,4]  R2033     5.5817224085330963e-02
    z[4,5,4]  R2034     -1.1799231171607971e-01
    z[4,5,4]  R2035     -2.0960466936230659e-03
    z[4,5,4]  R2036     4.3104174733161926e-01
    z[4,5,4]  R2037     2.8437113761901855e-01
    z[4,5,4]  R2038     3.1697955727577209e-01
    z[4,5,4]  R2039     -5.0764739513397217e-01
    z[4,5,4]  R2040     -2.5927874445915222e-01
    z[4,5,4]  R2041     1.0246764123439789e-01
    z[4,5,4]  R2042     -1.5932027995586395e-01
    z[4,5,4]  R2043     1.0432998090982437e-01
    z[4,5,4]  R2044     -3.1737962365150452e-01
    z[4,5,4]  R2045     -1.3017675280570984e-01
    z[4,5,4]  R2046     -4.1775807738304138e-01
    z[4,5,4]  R2047     -0.491071492433548
    z[4,5,4]  R2048     -1.2468812055885792e-02
    z[4,5,4]  R2049     -3.4238421916961670e-01
    z[4,5,4]  R2050     1.7936299741268158e-01
    z[4,5,4]  R2051     -3.8924279808998108e-01
    z[4,5,4]  R2052     -2.1627798676490784e-01
    z[4,5,4]  R2053     5.2010279148817062e-02
    z[4,5,4]  R2054     -1.1546332389116287e-01
    z[4,5,4]  R2055     8.3594217896461487e-02
    z[4,5,4]  R2056     -1.9497834146022797e-01
    z[4,5,4]  R2057     -1.6167469322681427e-02
    z[4,5,4]  R2058     2.3384955525398254e-01
    z[4,5,4]  R2059     -5.3835760802030563e-02
    z[4,5,4]  R2060     -2.2014346718788147e-01
    z[4,5,4]  R2061     -4.5374695211648941e-02
    z[4,5,4]  R2062     3.4137617796659470e-02
    z[4,5,4]  R2063     -3.1233888119459152e-02
    z[4,5,4]  R2064     6.6238231956958771e-02
    z[4,5,4]  R2065     2.9615478590130806e-02
    z[4,5,4]  R2066     2.5716400146484375e-01
    z[4,5,4]  R2067     -1.7625771462917328e-01
    z[4,5,4]  R2068     -4.7561034560203552e-01
    z[4,5,4]  R2069     -1.9259326159954071e-01
    z[4,5,4]  R2070     -2.0585859194397926e-02
    z[4,5,4]  R2071     0.266190767288208
    z[4,5,4]  R2072     4.8363244533538818e-01
    z[4,5,4]  R2073     -4.9662560224533081e-01
    z[4,5,4]  R2074     -2.7106830477714539e-01
    z[4,5,4]  R2075     -5.3728890419006348e-01
    z[4,5,4]  R2076     -6.1553839594125748e-02
    z[4,5,4]  R2077     -0.562829852104187
    z[4,5,4]  R2078     7.7291913330554962e-02
    z[4,5,4]  R2079     -1.1433874815702438e-01
    z[4,5,4]  R2080     2.5169411301612854e-01
    z[4,5,4]  R2081     -3.1164211034774780e-01
    z[4,5,4]  R2082     1.7597810924053192e-01
    z[4,5,4]  R2083     3.6798211932182312e-01
    z[4,5,4]  R2084     -0.179236501455307
    z[4,5,4]  R2085     2.1292287856340408e-02
    z[4,5,4]  R2086     -3.7797105312347412e-01
    z[4,5,4]  R2087     3.0390709638595581e-01
    z[4,5,4]  R2088     -3.8187372684478760e-01
    z[4,5,4]  R2089     -9.3844980001449585e-02
    z[4,5,4]  R2090     -0.236972376704216
    z[4,5,4]  R2091     9.4497419893741608e-02
    z[4,5,4]  R2092     -3.8247920572757721e-02
    z[4,5,4]  R2093     2.7009603381156921e-01
    z[4,5,4]  R2094     -4.2381209135055542e-01
    z[4,5,4]  R2095     2.4931342899799347e-01
    z[4,5,4]  R2096     5.3998857736587524e-01
    z[4,5,4]  R2097     4.0488681197166443e-01
    z[4,5,4]  R2098     8.3670176565647125e-02
    z[4,5,4]  R2099     -4.5888268947601318e-01
    z[4,5,4]  R2100     -4.6604439616203308e-02
    z[4,5,4]  R2101     3.2704961299896240e-01
    z[4,5,4]  R2102     7.0567227900028229e-02
    z[4,5,4]  R2103     6.8108029663562775e-02
    z[4,5,4]  R2104     -3.2181560993194580e-01
    z[4,5,4]  R2105     1.1002613604068756e-01
    z[4,5,4]  R2106     -2.1122857928276062e-01
    z[4,5,4]  R2107     5.9931587427854538e-02
    z[4,5,4]  R2108     3.5749897360801697e-01
    z[4,5,4]  R2109     3.9830144494771957e-02
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R1996     -1
    z[4,5,5]  R1997     1
    z[4,5,5]  R2000     -3.4275892376899719e-01
    z[4,5,5]  R2001     4.5087933540344238e-02
    z[4,5,5]  R2002     -2.9953157529234886e-02
    z[4,5,5]  R2003     -2.9334187507629395e-01
    z[4,5,5]  R2004     -2.0664717257022858e-01
    z[4,5,5]  R2005     -2.7806335687637329e-01
    z[4,5,5]  R2006     -8.7379798293113708e-02
    z[4,5,5]  R2007     -1.8528784811496735e-01
    z[4,5,5]  R2008     -1.8259078264236450e-01
    z[4,5,5]  R2009     -2.4348990619182587e-01
    z[4,5,5]  R2010     5.3352709859609604e-02
    z[4,5,5]  R2011     0.00816498976200819
    z[4,5,5]  R2012     2.2049862146377563e-01
    z[4,5,5]  R2013     1.4124831557273865e-01
    z[4,5,5]  R2014     6.3177652657032013e-02
    z[4,5,5]  R2015     -1.7479600384831429e-02
    z[4,5,5]  R2016     -2.2237753868103027e-01
    z[4,5,5]  R2017     2.3980200290679932e-01
    z[4,5,5]  R2018     3.1261703372001648e-01
    z[4,5,5]  R2019     -6.2608927488327026e-02
    z[4,5,5]  R2020     -5.2011895179748535e-01
    z[4,5,5]  R2021     3.6351811885833740e-01
    z[4,5,5]  R2022     1.7412659525871277e-01
    z[4,5,5]  R2023     4.7694477438926697e-01
    z[4,5,5]  R2024     -2.9019734263420105e-01
    z[4,5,5]  R2025     2.7124032378196716e-01
    z[4,5,5]  R2026     6.3384497165679932e-01
    z[4,5,5]  R2027     0.338814914226532
    z[4,5,5]  R2028     -4.9608775973320007e-01
    z[4,5,5]  R2029     -2.6866504549980164e-01
    z[4,5,5]  R2030     0.118772953748703
    z[4,5,5]  R2031     1.4905580878257751e-01
    z[4,5,5]  R2032     -3.9016890525817871e-01
    z[4,5,5]  R2033     1.9322144985198975e-01
    z[4,5,5]  R2034     4.0428814291954041e-01
    z[4,5,5]  R2035     -1.8809929490089417e-01
    z[4,5,5]  R2036     -3.2025733590126038e-01
    z[4,5,5]  R2037     -4.2974588274955750e-01
    z[4,5,5]  R2038     -2.5475805997848511e-01
    z[4,5,5]  R2039     -5.9276670217514038e-01
    z[4,5,5]  R2040     3.0984953045845032e-01
    z[4,5,5]  R2041     -1.6345185041427612e-01
    z[4,5,5]  R2042     -2.6504019275307655e-02
    z[4,5,5]  R2043     -3.3260446786880493e-01
    z[4,5,5]  R2044     -0.58106929063797
    z[4,5,5]  R2045     -3.7125506997108459e-01
    z[4,5,5]  R2046     -3.0003935098648071e-01
    z[4,5,5]  R2047     -3.7825220823287964e-01
    z[4,5,5]  R2048     -6.4805221557617188e-01
    z[4,5,5]  R2049     -5.2606594562530518e-01
    z[4,5,5]  R2050     3.8588356226682663e-02
    z[4,5,5]  R2051     -5.9759981930255890e-02
    z[4,5,5]  R2052     -9.8781652748584747e-02
    z[4,5,5]  R2053     4.9851533770561218e-01
    z[4,5,5]  R2054     8.8417582213878632e-02
    z[4,5,5]  R2055     4.1982212662696838e-01
    z[4,5,5]  R2056     5.0388105213642120e-02
    z[4,5,5]  R2057     -2.9312046244740486e-02
    z[4,5,5]  R2058     2.2549599409103394e-02
    z[4,5,5]  R2059     9.7208611667156219e-02
    z[4,5,5]  R2060     -0.20915587246418
    z[4,5,5]  R2061     2.7075076103210449e-01
    z[4,5,5]  R2062     -1.3327005505561829e-01
    z[4,5,5]  R2063     -1.0672775655984879e-01
    z[4,5,5]  R2064     -1.8711720407009125e-01
    z[4,5,5]  R2065     4.2427446693181992e-02
    z[4,5,5]  R2066     -5.3012490272521973e-02
    z[4,5,5]  R2067     1.2396091967821121e-01
    z[4,5,5]  R2068     -5.7057093828916550e-02
    z[4,5,5]  R2069     -0.664159893989563
    z[4,5,5]  R2070     -1.6862601041793823e-01
    z[4,5,5]  R2071     -3.3100903034210205e-01
    z[4,5,5]  R2072     4.1131377220153809e-02
    z[4,5,5]  R2073     -4.3417149782180786e-01
    z[4,5,5]  R2074     -6.4314886927604675e-02
    z[4,5,5]  R2075     3.2166644930839539e-02
    z[4,5,5]  R2076     -2.9103556275367737e-01
    z[4,5,5]  R2077     -4.6886539459228516e-01
    z[4,5,5]  R2078     -4.1835474967956543e-01
    z[4,5,5]  R2079     8.4974959492683411e-02
    z[4,5,5]  R2080     -6.5110139548778534e-02
    z[4,5,5]  R2081     -1.3007238507270813e-01
    z[4,5,5]  R2082     -1.4972680248320103e-02
    z[4,5,5]  R2083     -1.5832929313182831e-01
    z[4,5,5]  R2084     -8.0520617961883545e-01
    z[4,5,5]  R2085     -7.1239614486694336e-01
    z[4,5,5]  R2086     -7.5145828723907471e-01
    z[4,5,5]  R2087     -7.3359489440917969e-02
    z[4,5,5]  R2088     -6.5183258056640625e-01
    z[4,5,5]  R2089     0.0919019877910614
    z[4,5,5]  R2090     -6.8476825952529907e-01
    z[4,5,5]  R2091     -0.540597677230835
    z[4,5,5]  R2092     -5.7579392194747925e-01
    z[4,5,5]  R2093     4.3393453955650330e-01
    z[4,5,5]  R2094     -3.0361536145210266e-01
    z[4,5,5]  R2095     -4.4442582130432129e-01
    z[4,5,5]  R2096     -1.9340707361698151e-01
    z[4,5,5]  R2097     -1.2813787162303925e-01
    z[4,5,5]  R2098     7.0793461799621582e-01
    z[4,5,5]  R2099     -5.4943698644638062e-01
    z[4,5,5]  R2100     4.1062682867050171e-01
    z[4,5,5]  R2101     2.5218388438224792e-01
    z[4,5,5]  R2102     1.0526556521654129e-01
    z[4,5,5]  R2103     -2.0504812896251678e-01
    z[4,5,5]  R2104     -8.4403932094573975e-02
    z[4,5,5]  R2105     5.3338732570409775e-02
    z[4,5,5]  R2106     -0.770687997341156
    z[4,5,5]  R2107     2.7705445885658264e-01
    z[4,5,5]  R2108     6.9618618488311768e-01
    z[4,5,5]  R2109     -1.8352276086807251e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R1998     -1
    z[4,5,6]  R1999     1
    z[4,5,6]  R2000     -2.7031236886978149e-01
    z[4,5,6]  R2001     -3.6006903648376465e-01
    z[4,5,6]  R2002     -8.4542363882064819e-02
    z[4,5,6]  R2003     1.9825683534145355e-01
    z[4,5,6]  R2004     1.8086800118908286e-03
    z[4,5,6]  R2005     3.8836565613746643e-01
    z[4,5,6]  R2006     1.0225946456193924e-01
    z[4,5,6]  R2007     -1.9530941545963287e-01
    z[4,5,6]  R2008     5.5214506387710571e-01
    z[4,5,6]  R2009     5.6081664562225342e-01
    z[4,5,6]  R2010     1.3139556348323822e-01
    z[4,5,6]  R2011     2.6312194764614105e-02
    z[4,5,6]  R2012     -1.8855512142181396e-01
    z[4,5,6]  R2013     0.219558984041214
    z[4,5,6]  R2014     5.1874320954084396e-02
    z[4,5,6]  R2015     -3.6246750503778458e-02
    z[4,5,6]  R2016     5.1881197839975357e-02
    z[4,5,6]  R2017     -2.6275175809860229e-01
    z[4,5,6]  R2018     1.5936821699142456e-01
    z[4,5,6]  R2019     4.5621609687805176e-01
    z[4,5,6]  R2020     1.3237684965133667e-01
    z[4,5,6]  R2021     -1.1799604445695877e-01
    z[4,5,6]  R2022     -1.3395063579082489e-01
    z[4,5,6]  R2023     7.1930542588233948e-02
    z[4,5,6]  R2024     -4.8952198028564453e-01
    z[4,5,6]  R2025     -5.1462358236312866e-01
    z[4,5,6]  R2026     2.2167497873306274e-01
    z[4,5,6]  R2027     -4.1103911399841309e-01
    z[4,5,6]  R2028     -6.3495904207229614e-01
    z[4,5,6]  R2029     -1.5159158408641815e-01
    z[4,5,6]  R2030     3.2869648933410645e-01
    z[4,5,6]  R2031     -1.1322646588087082e-01
    z[4,5,6]  R2032     -3.7916172295808792e-02
    z[4,5,6]  R2033     -9.0696640312671661e-02
    z[4,5,6]  R2034     -2.8596329689025879e-01
    z[4,5,6]  R2035     3.6390227614901960e-04
    z[4,5,6]  R2036     -4.5304756611585617e-02
    z[4,5,6]  R2037     -4.6856012195348740e-02
    z[4,5,6]  R2038     -6.9118463993072510e-01
    z[4,5,6]  R2039     -3.0608588829636574e-02
    z[4,5,6]  R2040     2.1094322204589844e-02
    z[4,5,6]  R2041     1.8923284113407135e-01
    z[4,5,6]  R2042     1.3367126882076263e-01
    z[4,5,6]  R2043     -1.2137117236852646e-01
    z[4,5,6]  R2044     -9.0393684804439545e-02
    z[4,5,6]  R2045     2.7407559752464294e-01
    z[4,5,6]  R2046     3.3861619234085083e-01
    z[4,5,6]  R2047     2.1317753195762634e-01
    z[4,5,6]  R2048     1.0882806777954102e-01
    z[4,5,6]  R2049     3.0970957130193710e-02
    z[4,5,6]  R2050     -0.213245689868927
    z[4,5,6]  R2051     -1.1445382237434387e-01
    z[4,5,6]  R2052     3.0972677469253540e-01
    z[4,5,6]  R2053     -1.4680434763431549e-01
    z[4,5,6]  R2054     1.4119245111942291e-01
    z[4,5,6]  R2055     -2.9564124345779419e-01
    z[4,5,6]  R2056     3.4207320213317871e-01
    z[4,5,6]  R2057     -3.5359996557235718e-01
    z[4,5,6]  R2058     -2.0274966955184937e-01
    z[4,5,6]  R2059     1.9331571459770203e-01
    z[4,5,6]  R2060     -8.9825429022312164e-02
    z[4,5,6]  R2061     -9.0498877689242363e-03
    z[4,5,6]  R2062     1.7261378467082977e-01
    z[4,5,6]  R2063     3.6802750825881958e-01
    z[4,5,6]  R2064     1.0216881334781647e-01
    z[4,5,6]  R2065     2.8805169463157654e-01
    z[4,5,6]  R2066     2.0300626754760742e-02
    z[4,5,6]  R2067     3.7663422524929047e-02
    z[4,5,6]  R2068     2.2350224852561951e-01
    z[4,5,6]  R2069     1.3495652377605438e-01
    z[4,5,6]  R2070     -2.7111336588859558e-01
    z[4,5,6]  R2071     -1.2901568412780762e-01
    z[4,5,6]  R2072     -1.0398577898740768e-01
    z[4,5,6]  R2073     3.4599813818931580e-01
    z[4,5,6]  R2074     5.1238399744033813e-01
    z[4,5,6]  R2075     -2.1321910619735718e-01
    z[4,5,6]  R2076     1.7266513779759407e-02
    z[4,5,6]  R2077     -1.4194932579994202e-01
    z[4,5,6]  R2078     -2.7249327301979065e-01
    z[4,5,6]  R2079     2.1349404752254486e-01
    z[4,5,6]  R2080     -2.2075112909078598e-02
    z[4,5,6]  R2081     2.9936149716377258e-01
    z[4,5,6]  R2082     -3.5097181797027588e-02
    z[4,5,6]  R2083     6.6236026585102081e-02
    z[4,5,6]  R2084     -1.0731033980846405e-01
    z[4,5,6]  R2085     -5.0495218485593796e-02
    z[4,5,6]  R2086     -1.5178513526916504e-01
    z[4,5,6]  R2087     -3.4815138578414917e-01
    z[4,5,6]  R2088     4.1891507804393768e-02
    z[4,5,6]  R2089     1.3261966407299042e-01
    z[4,5,6]  R2090     7.9603493213653564e-02
    z[4,5,6]  R2091     -1.8367318809032440e-01
    z[4,5,6]  R2092     2.6043435931205750e-01
    z[4,5,6]  R2093     -7.9081624746322632e-02
    z[4,5,6]  R2094     -5.6449435651302338e-03
    z[4,5,6]  R2095     -2.0487642288208008e-01
    z[4,5,6]  R2096     9.3412511050701141e-03
    z[4,5,6]  R2097     2.2414916753768921e-01
    z[4,5,6]  R2098     -1.6394597291946411e-01
    z[4,5,6]  R2099     9.3698501586914062e-02
    z[4,5,6]  R2100     1.0346536524593830e-02
    z[4,5,6]  R2101     2.0242041349411011e-01
    z[4,5,6]  R2102     2.9542511701583862e-01
    z[4,5,6]  R2103     -0.0766846090555191
    z[4,5,6]  R2104     -1.4676292240619659e-01
    z[4,5,6]  R2105     6.8043315410614014e-01
    z[4,5,6]  R2106     -2.1194823086261749e-01
    z[4,5,6]  R2107     9.8082497715950012e-02
    z[4,5,6]  R2108     2.1409492194652557e-01
    z[4,5,6]  R2109     -2.5079679489135742e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2110     -1
    z[5,4,0]  R2111     1
    z[5,4,0]  R2124     -1.1327574402093887e-01
    z[5,4,0]  R2125     1.1821000277996063e-01
    z[5,4,0]  R2126     -3.5126686096191406e-01
    z[5,4,0]  R2127     2.0345158874988556e-01
    z[5,4,0]  R2128     1.5866951644420624e-01
    z[5,4,0]  R2129     1.4918965101242065e-01
    z[5,4,0]  R2130     1.4596323668956757e-01
    z[5,4,0]  R2131     -5.2205246686935425e-01
    z[5,4,0]  R2132     -4.4384837150573730e-01
    z[5,4,0]  R2133     -0.854417622089386
    z[5,4,0]  R2134     3.4748545289039612e-01
    z[5,4,0]  R2135     -1.2408905476331711e-01
    z[5,4,0]  R2136     1.9600579142570496e-01
    z[5,4,0]  R2137     1.4159527420997620e-01
    z[5,4,0]  R2138     0.352468878030777
    z[5,4,0]  R2139     2.5963535904884338e-01
    z[5,4,0]  R2140     1.6861203312873840e-01
    z[5,4,0]  R2141     1.5843059122562408e-01
    z[5,4,0]  R2142     1.5164570510387421e-01
    z[5,4,0]  R2143     1.8139271438121796e-01
    z[5,4,0]  R2144     1.8842476606369019e-01
    z[5,4,0]  R2145     -1.6518227756023407e-02
    z[5,4,0]  R2146     3.1579241156578064e-02
    z[5,4,0]  R2147     -3.2002660632133484e-01
    z[5,4,0]  R2148     -2.0104108750820160e-01
    z[5,4,0]  R2149     -2.2300831973552704e-01
    z[5,4,0]  R2150     5.1281917095184326e-01
    z[5,4,0]  R2151     2.4213770031929016e-01
    z[5,4,0]  R2152     1.4620113186538219e-02
    z[5,4,0]  R2153     2.5184684991836548e-01
    z[5,4,0]  R2154     -0.406929075717926
    z[5,4,0]  R2155     -2.2387205064296722e-01
    z[5,4,0]  R2156     3.8542559742927551e-01
    z[5,4,0]  R2157     -2.3967489600181580e-01
    z[5,4,0]  R2158     -2.3025350272655487e-01
    z[5,4,0]  R2159     -3.9414188265800476e-01
    z[5,4,0]  R2160     -7.0512875914573669e-02
    z[5,4,0]  R2161     4.3129718303680420e-01
    z[5,4,0]  R2162     -4.4638893008232117e-01
    z[5,4,0]  R2163     0.214206725358963
    z[5,4,0]  R2164     -2.7951663732528687e-01
    z[5,4,0]  R2165     6.2482478097081184e-03
    z[5,4,0]  R2166     -5.6338828802108765e-01
    z[5,4,0]  R2167     -2.9648989439010620e-01
    z[5,4,0]  R2168     -2.6210770010948181e-01
    z[5,4,0]  R2169     -0.746512770652771
    z[5,4,0]  R2170     -1.4326098561286926e-01
    z[5,4,0]  R2171     -8.8023543357849121e-03
    z[5,4,0]  R2172     6.6120497882366180e-02
    z[5,4,0]  R2173     2.4554353952407837e-01
    z[5,4,0]  R2174     -5.1022070646286011e-01
    z[5,4,0]  R2175     -7.1848720312118530e-01
    z[5,4,0]  R2176     2.2021791338920593e-01
    z[5,4,0]  R2177     0.188834086060524
    z[5,4,0]  R2178     4.7437706589698792e-01
    z[5,4,0]  R2179     4.6587541699409485e-01
    z[5,4,0]  R2180     7.2910927236080170e-02
    z[5,4,0]  R2181     7.2841948270797729e-01
    z[5,4,0]  R2182     3.0446156859397888e-01
    z[5,4,0]  R2183     5.4198443889617920e-01
    z[5,4,0]  R2184     1.8273948132991791e-01
    z[5,4,0]  R2185     7.5243353843688965e-02
    z[5,4,0]  R2186     -2.0890556275844574e-01
    z[5,4,0]  R2187     6.4720004796981812e-01
    z[5,4,0]  R2188     2.2473375499248505e-01
    z[5,4,0]  R2189     3.4467941522598267e-01
    z[5,4,0]  R2190     -1.7299796640872955e-01
    z[5,4,0]  R2191     2.0742221176624298e-01
    z[5,4,0]  R2192     6.4767844974994659e-02
    z[5,4,0]  R2193     2.0509274303913116e-01
    z[5,4,0]  R2194     -1.0053467005491257e-01
    z[5,4,0]  R2195     1.3686452805995941e-01
    z[5,4,0]  R2196     -1.1812112480401993e-01
    z[5,4,0]  R2197     1.1632069945335388e-01
    z[5,4,0]  R2198     -4.2024865746498108e-02
    z[5,4,0]  R2199     2.4728041887283325e-01
    z[5,4,0]  R2200     3.3589640259742737e-01
    z[5,4,0]  R2201     -0.0842878594994545
    z[5,4,0]  R2202     -0.0749136209487915
    z[5,4,0]  R2203     6.1640333384275436e-02
    z[5,4,0]  R2204     -3.2477363944053650e-02
    z[5,4,0]  R2205     -1.2521438300609589e-01
    z[5,4,0]  R2206     -9.0394169092178345e-02
    z[5,4,0]  R2207     -1.7760178446769714e-01
    z[5,4,0]  R2208     0.206633523106575
    z[5,4,0]  R2209     2.0787317771464586e-03
    z[5,4,0]  R2210     -1.7261725664138794e-01
    z[5,4,0]  R2211     1.8793597817420959e-01
    z[5,4,0]  R2212     -7.3890708386898041e-02
    z[5,4,0]  R2213     -5.5151319503784180e-01
    z[5,4,0]  R2214     8.4341593086719513e-02
    z[5,4,0]  R2215     -2.9460051655769348e-01
    z[5,4,0]  R2216     2.2809910774230957e-01
    z[5,4,0]  R2217     1.8554365634918213e-01
    z[5,4,0]  R2218     -1.5891253948211670e-01
    z[5,4,0]  R2219     2.3968566954135895e-01
    z[5,4,0]  R2220     1.2430764734745026e-01
    z[5,4,0]  R2221     -1.7151252925395966e-01
    z[5,4,0]  R2222     -3.8300785422325134e-01
    z[5,4,0]  R2223     -2.5668612122535706e-01
    z[5,4,0]  R2224     -1.6947200521826744e-02
    z[5,4,0]  R2225     3.4027022123336792e-01
    z[5,4,0]  R2226     2.6533061265945435e-01
    z[5,4,0]  R2227     -2.0327101647853851e-01
    z[5,4,0]  R2228     -9.8297879099845886e-02
    z[5,4,0]  R2229     -4.8372265696525574e-01
    z[5,4,0]  R2230     -1.4247813820838928e-01
    z[5,4,0]  R2231     -5.4091745615005493e-01
    z[5,4,0]  R2232     -4.2434650659561157e-01
    z[5,4,0]  R2233     -6.4929658174514771e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2112     -1
    z[5,4,1]  R2113     1
    z[5,4,1]  R2124     9.0267688035964966e-01
    z[5,4,1]  R2125     8.7850195169448853e-01
    z[5,4,1]  R2126     8.0297881364822388e-01
    z[5,4,1]  R2127     8.2115840911865234e-01
    z[5,4,1]  R2128     -4.2180785536766052e-01
    z[5,4,1]  R2129     7.3890346288681030e-01
    z[5,4,1]  R2130     0.775105357170105
    z[5,4,1]  R2131     -6.7736494541168213e-01
    z[5,4,1]  R2132     -3.3908748626708984e-01
    z[5,4,1]  R2133     -4.1606849431991577e-01
    z[5,4,1]  R2134     -7.6730751991271973e-01
    z[5,4,1]  R2135     -7.0995074510574341e-01
    z[5,4,1]  R2136     -6.6837781667709351e-01
    z[5,4,1]  R2137     -6.6868335008621216e-01
    z[5,4,1]  R2138     -6.8870180845260620e-01
    z[5,4,1]  R2139     -0.689148485660553
    z[5,4,1]  R2140     -0.724707841873169
    z[5,4,1]  R2141     -6.5316039323806763e-01
    z[5,4,1]  R2142     -6.6812676191329956e-01
    z[5,4,1]  R2143     -5.3825861215591431e-01
    z[5,4,1]  R2144     -8.6119043827056885e-01
    z[5,4,1]  R2145     -7.1934396028518677e-01
    z[5,4,1]  R2146     -6.6734534502029419e-01
    z[5,4,1]  R2147     -3.2121309638023376e-01
    z[5,4,1]  R2148     -3.4441930055618286e-01
    z[5,4,1]  R2149     -7.9870028421282768e-03
    z[5,4,1]  R2150     7.0969969034194946e-01
    z[5,4,1]  R2151     -3.8341563940048218e-01
    z[5,4,1]  R2152     8.0171310901641846e-01
    z[5,4,1]  R2153     6.8133169412612915e-01
    z[5,4,1]  R2154     -8.1819391250610352e-01
    z[5,4,1]  R2155     -8.3834046125411987e-01
    z[5,4,1]  R2156     8.9345055818557739e-01
    z[5,4,1]  R2157     8.7546640634536743e-01
    z[5,4,1]  R2158     -5.0110530853271484e-01
    z[5,4,1]  R2159     -5.1602822542190552e-01
    z[5,4,1]  R2160     -3.5946887731552124e-01
    z[5,4,1]  R2161     -3.1774255633354187e-01
    z[5,4,1]  R2162     -2.0169923081994057e-02
    z[5,4,1]  R2163     6.5325963497161865e-01
    z[5,4,1]  R2164     -5.1344031095504761e-01
    z[5,4,1]  R2165     7.9660427570343018e-01
    z[5,4,1]  R2166     -3.0994272232055664e-01
    z[5,4,1]  R2167     7.2402888536453247e-01
    z[5,4,1]  R2168     -5.4558837413787842e-01
    z[5,4,1]  R2169     -3.2240059226751328e-02
    z[5,4,1]  R2170     0.500961422920227
    z[5,4,1]  R2171     0.430346816778183
    z[5,4,1]  R2172     -5.9856027364730835e-01
    z[5,4,1]  R2173     -8.0516338348388672e-02
    z[5,4,1]  R2174     7.1003675460815430e-01
    z[5,4,1]  R2175     -2.7539357542991638e-01
    z[5,4,1]  R2176     -7.8431165218353271e-01
    z[5,4,1]  R2177     6.0737508535385132e-01
    z[5,4,1]  R2178     -2.3485994338989258e-01
    z[5,4,1]  R2179     -3.7489861249923706e-01
    z[5,4,1]  R2180     -4.6983989886939526e-04
    z[5,4,1]  R2181     -2.7126595377922058e-01
    z[5,4,1]  R2182     -0.0902019739151001
    z[5,4,1]  R2183     -9.1256782412528992e-02
    z[5,4,1]  R2184     -8.1072676181793213e-01
    z[5,4,1]  R2185     -6.7871409654617310e-01
    z[5,4,1]  R2186     -6.7564535140991211e-01
    z[5,4,1]  R2187     -6.3561600446701050e-01
    z[5,4,1]  R2188     -4.6969485282897949e-01
    z[5,4,1]  R2189     -6.1447870731353760e-01
    z[5,4,1]  R2190     -4.5773589611053467e-01
    z[5,4,1]  R2191     -5.2216702699661255e-01
    z[5,4,1]  R2192     -4.9167856574058533e-01
    z[5,4,1]  R2193     -5.1526272296905518e-01
    z[5,4,1]  R2194     9.1978579759597778e-01
    z[5,4,1]  R2195     9.0769237279891968e-01
    z[5,4,1]  R2196     8.8948029279708862e-01
    z[5,4,1]  R2197     8.7213045358657837e-01
    z[5,4,1]  R2198     8.9554357528686523e-01
    z[5,4,1]  R2199     0.841696560382843
    z[5,4,1]  R2200     8.5505813360214233e-01
    z[5,4,1]  R2201     8.2347893714904785e-01
    z[5,4,1]  R2202     8.3122414350509644e-01
    z[5,4,1]  R2203     8.2374644279479980e-01
    z[5,4,1]  R2204     6.2490773200988770e-01
    z[5,4,1]  R2205     -4.6254453063011169e-01
    z[5,4,1]  R2206     -3.9497679471969604e-01
    z[5,4,1]  R2207     -4.7766700387001038e-01
    z[5,4,1]  R2208     -1.5034003555774689e-01
    z[5,4,1]  R2209     -4.6923229098320007e-01
    z[5,4,1]  R2210     -0.536043643951416
    z[5,4,1]  R2211     -4.5698961615562439e-01
    z[5,4,1]  R2212     3.9782455563545227e-01
    z[5,4,1]  R2213     -1.7178170382976532e-01
    z[5,4,1]  R2214     -8.6554270982742310e-01
    z[5,4,1]  R2215     -6.4300930500030518e-01
    z[5,4,1]  R2216     8.4201908111572266e-01
    z[5,4,1]  R2217     -7.0415306091308594e-01
    z[5,4,1]  R2218     -7.0064681768417358e-01
    z[5,4,1]  R2219     -3.7490347027778625e-01
    z[5,4,1]  R2220     -3.7599790096282959e-01
    z[5,4,1]  R2221     0.580936849117279
    z[5,4,1]  R2222     4.4202911853790283e-01
    z[5,4,1]  R2223     1.0483112186193466e-01
    z[5,4,1]  R2224     -8.6755198240280151e-01
    z[5,4,1]  R2225     -8.3970564603805542e-01
    z[5,4,1]  R2226     -7.3522913455963135e-01
    z[5,4,1]  R2227     6.9517850875854492e-01
    z[5,4,1]  R2228     9.3139477074146271e-02
    z[5,4,1]  R2229     -5.8083377778530121e-02
    z[5,4,1]  R2230     2.4324165657162666e-02
    z[5,4,1]  R2231     -4.4814877212047577e-02
    z[5,4,1]  R2232     -3.8592919707298279e-02
    z[5,4,1]  R2233     -2.4696400389075279e-02
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2114     -1
    z[5,4,2]  R2115     1
    z[5,4,2]  R2124     -2.2743935883045197e-01
    z[5,4,2]  R2125     -1.9896794855594635e-01
    z[5,4,2]  R2126     2.6907011866569519e-01
    z[5,4,2]  R2127     -7.0819951593875885e-02
    z[5,4,2]  R2128     -0.866377055644989
    z[5,4,2]  R2129     0.3300761282444
    z[5,4,2]  R2130     -2.3459206521511078e-01
    z[5,4,2]  R2131     -2.7051535248756409e-01
    z[5,4,2]  R2132     -7.5094038248062134e-01
    z[5,4,2]  R2133     -1.8892247974872589e-01
    z[5,4,2]  R2134     -6.9927543401718140e-02
    z[5,4,2]  R2135     4.7661286592483521e-01
    z[5,4,2]  R2136     3.4003669023513794e-01
    z[5,4,2]  R2137     9.9839836359024048e-02
    z[5,4,2]  R2138     2.5200808048248291e-01
    z[5,4,2]  R2139     2.2952046990394592e-01
    z[5,4,2]  R2140     4.0556395053863525e-01
    z[5,4,2]  R2141     4.4633349776268005e-01
    z[5,4,2]  R2142     3.1033965945243835e-01
    z[5,4,2]  R2143     0.05144052952528
    z[5,4,2]  R2144     -2.4051231145858765e-01
    z[5,4,2]  R2145     -1.4661246538162231e-01
    z[5,4,2]  R2146     4.6668898314237595e-02
    z[5,4,2]  R2147     -4.7202974557876587e-01
    z[5,4,2]  R2148     -5.4179519414901733e-01
    z[5,4,2]  R2149     -4.4095999002456665e-01
    z[5,4,2]  R2150     3.7452599406242371e-01
    z[5,4,2]  R2151     -4.8140594363212585e-01
    z[5,4,2]  R2152     0.00958534050732851
    z[5,4,2]  R2153     5.9043139219284058e-01
    z[5,4,2]  R2154     -2.9375061858445406e-03
    z[5,4,2]  R2155     5.9286791831254959e-02
    z[5,4,2]  R2156     1.3947954773902893e-01
    z[5,4,2]  R2157     -8.9126199483871460e-02
    z[5,4,2]  R2158     -4.3336143717169762e-03
    z[5,4,2]  R2159     -1.2201385945081711e-01
    z[5,4,2]  R2160     -3.6684155464172363e-01
    z[5,4,2]  R2161     -4.4460549950599670e-01
    z[5,4,2]  R2162     -4.5316964387893677e-01
    z[5,4,2]  R2163     0.624812662601471
    z[5,4,2]  R2164     -2.8168469667434692e-01
    z[5,4,2]  R2165     -2.1682465448975563e-02
    z[5,4,2]  R2166     -2.8477707505226135e-01
    z[5,4,2]  R2167     -6.5252050757408142e-02
    z[5,4,2]  R2168     -6.0091644525527954e-01
    z[5,4,2]  R2169     -3.7112745642662048e-01
    z[5,4,2]  R2170     6.2278604507446289e-01
    z[5,4,2]  R2171     0.732809841632843
    z[5,4,2]  R2172     -3.1777489185333252e-01
    z[5,4,2]  R2173     1.8926402926445007e-01
    z[5,4,2]  R2174     2.5441799312829971e-02
    z[5,4,2]  R2175     -3.5456672310829163e-01
    z[5,4,2]  R2176     -3.9431047439575195e-01
    z[5,4,2]  R2177     5.3239309787750244e-01
    z[5,4,2]  R2178     -3.5722586512565613e-01
    z[5,4,2]  R2179     -1.5683230757713318e-01
    z[5,4,2]  R2180     1.3258498907089233e-01
    z[5,4,2]  R2181     -1.2050031125545502e-01
    z[5,4,2]  R2182     -1.5476141870021820e-01
    z[5,4,2]  R2183     7.6779276132583618e-01
    z[5,4,2]  R2184     4.6575747430324554e-02
    z[5,4,2]  R2185     -4.4898384809494019e-01
    z[5,4,2]  R2186     -3.9891722798347473e-01
    z[5,4,2]  R2187     -1.3940635323524475e-01
    z[5,4,2]  R2188     -0.392828106880188
    z[5,4,2]  R2189     -3.9671313762664795e-01
    z[5,4,2]  R2190     -1.5920653939247131e-02
    z[5,4,2]  R2191     3.0823811888694763e-01
    z[5,4,2]  R2192     -1.7982932925224304e-01
    z[5,4,2]  R2193     4.2525655031204224e-01
    z[5,4,2]  R2194     1.4306181669235229e-01
    z[5,4,2]  R2195     -1.1526767164468765e-01
    z[5,4,2]  R2196     -2.4151550233364105e-01
    z[5,4,2]  R2197     1.8396852910518646e-01
    z[5,4,2]  R2198     -4.1573038697242737e-01
    z[5,4,2]  R2199     2.9827040433883667e-01
    z[5,4,2]  R2200     2.0655937492847443e-01
    z[5,4,2]  R2201     4.3210950493812561e-01
    z[5,4,2]  R2202     2.8976443409919739e-01
    z[5,4,2]  R2203     2.5015175342559814e-01
    z[5,4,2]  R2204     -1.1019866913557053e-01
    z[5,4,2]  R2205     5.0250756740570068e-01
    z[5,4,2]  R2206     5.8804297447204590e-01
    z[5,4,2]  R2207     6.0417884588241577e-01
    z[5,4,2]  R2208     6.4746642112731934e-01
    z[5,4,2]  R2209     1.5681222081184387e-01
    z[5,4,2]  R2210     1.3179703056812286e-01
    z[5,4,2]  R2211     -4.0013585239648819e-02
    z[5,4,2]  R2212     -0.195712149143219
    z[5,4,2]  R2213     -1.1446216702461243e-01
    z[5,4,2]  R2214     3.0641865730285645e-01
    z[5,4,2]  R2215     6.6967093944549561e-01
    z[5,4,2]  R2216     -1.8188336491584778e-01
    z[5,4,2]  R2217     -3.5695701837539673e-01
    z[5,4,2]  R2218     0.272125780582428
    z[5,4,2]  R2219     7.3076236248016357e-01
    z[5,4,2]  R2220     4.7682681679725647e-01
    z[5,4,2]  R2221     5.7388770580291748e-01
    z[5,4,2]  R2222     -2.4268349632620811e-02
    z[5,4,2]  R2223     -1.3904811441898346e-01
    z[5,4,2]  R2224     1.0298167914152145e-01
    z[5,4,2]  R2225     2.3890449106693268e-01
    z[5,4,2]  R2226     0.562421441078186
    z[5,4,2]  R2227     1.2121919542551041e-01
    z[5,4,2]  R2228     -3.0836266279220581e-01
    z[5,4,2]  R2229     -5.7609234005212784e-02
    z[5,4,2]  R2230     -2.4657705426216125e-01
    z[5,4,2]  R2231     1.0175630450248718e-01
    z[5,4,2]  R2232     -1.5905712544918060e-01
    z[5,4,2]  R2233     1.7889384925365448e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2116     -1
    z[5,4,3]  R2117     1
    z[5,4,3]  R2124     2.0366741716861725e-01
    z[5,4,3]  R2125     -8.0570735037326813e-02
    z[5,4,3]  R2126     -8.3505190908908844e-02
    z[5,4,3]  R2127     8.0725461244583130e-02
    z[5,4,3]  R2128     -7.2167336940765381e-02
    z[5,4,3]  R2129     -2.2841072082519531e-01
    z[5,4,3]  R2130     4.0657523274421692e-01
    z[5,4,3]  R2131     -0.263260155916214
    z[5,4,3]  R2132     0.166749507188797
    z[5,4,3]  R2133     -1.0699054598808289e-01
    z[5,4,3]  R2134     4.3049424886703491e-01
    z[5,4,3]  R2135     4.2185938358306885e-01
    z[5,4,3]  R2136     5.9203559160232544e-01
    z[5,4,3]  R2137     6.1240088939666748e-01
    z[5,4,3]  R2138     5.3675752878189087e-01
    z[5,4,3]  R2139     5.6509578227996826e-01
    z[5,4,3]  R2140     4.6101042628288269e-01
    z[5,4,3]  R2141     5.4883146286010742e-01
    z[5,4,3]  R2142     3.9355498552322388e-01
    z[5,4,3]  R2143     4.2227292060852051e-01
    z[5,4,3]  R2144     2.5027993321418762e-01
    z[5,4,3]  R2145     5.1352363824844360e-01
    z[5,4,3]  R2146     5.5233132839202881e-01
    z[5,4,3]  R2147     1.2936948239803314e-01
    z[5,4,3]  R2148     4.5526260137557983e-01
    z[5,4,3]  R2149     -6.4852249622344971e-01
    z[5,4,3]  R2150     -6.5455652773380280e-02
    z[5,4,3]  R2151     -7.6473824679851532e-02
    z[5,4,3]  R2152     -3.1890928745269775e-01
    z[5,4,3]  R2153     -2.4057717621326447e-01
    z[5,4,3]  R2154     3.1125918030738831e-01
    z[5,4,3]  R2155     1.9973684847354889e-01
    z[5,4,3]  R2156     -3.6254484206438065e-02
    z[5,4,3]  R2157     5.7488363236188889e-02
    z[5,4,3]  R2158     6.2126670032739639e-02
    z[5,4,3]  R2159     2.3014867305755615e-01
    z[5,4,3]  R2160     -2.5437323376536369e-02
    z[5,4,3]  R2161     -5.4442435503005981e-01
    z[5,4,3]  R2162     -1.4999739825725555e-01
    z[5,4,3]  R2163     -3.1958681344985962e-01
    z[5,4,3]  R2164     2.1795186400413513e-01
    z[5,4,3]  R2165     -1.7320780456066132e-01
    z[5,4,3]  R2166     3.2342472672462463e-01
    z[5,4,3]  R2167     -3.4075376391410828e-01
    z[5,4,3]  R2168     -2.6483917608857155e-02
    z[5,4,3]  R2169     -4.7934178262948990e-02
    z[5,4,3]  R2170     1.0756554454565048e-01
    z[5,4,3]  R2171     2.1706764400005341e-01
    z[5,4,3]  R2172     3.6363206803798676e-02
    z[5,4,3]  R2173     -0.61332768201828
    z[5,4,3]  R2174     -2.5294670462608337e-01
    z[5,4,3]  R2175     2.6586598157882690e-01
    z[5,4,3]  R2176     2.7846372127532959e-01
    z[5,4,3]  R2177     5.0934362411499023e-01
    z[5,4,3]  R2178     -6.7820960283279419e-01
    z[5,4,3]  R2179     -3.7399837374687195e-01
    z[5,4,3]  R2180     -5.4185372591018677e-01
    z[5,4,3]  R2181     5.3974837064743042e-01
    z[5,4,3]  R2182     -4.6572342514991760e-01
    z[5,4,3]  R2183     -1.0125853121280670e-01
    z[5,4,3]  R2184     -3.2698315382003784e-01
    z[5,4,3]  R2185     -4.0670457482337952e-01
    z[5,4,3]  R2186     -3.6919006705284119e-01
    z[5,4,3]  R2187     7.1565821766853333e-02
    z[5,4,3]  R2188     -7.1684509515762329e-01
    z[5,4,3]  R2189     -1.7682163417339325e-01
    z[5,4,3]  R2190     -8.5256582498550415e-01
    z[5,4,3]  R2191     -0.595733106136322
    z[5,4,3]  R2192     -4.8289006948471069e-01
    z[5,4,3]  R2193     -3.4410575032234192e-01
    z[5,4,3]  R2194     3.2040110230445862e-01
    z[5,4,3]  R2195     -3.5573536157608032e-01
    z[5,4,3]  R2196     -6.2316235154867172e-02
    z[5,4,3]  R2197     -3.5193055868148804e-01
    z[5,4,3]  R2198     -9.4288922846317291e-02
    z[5,4,3]  R2199     -2.3346070945262909e-01
    z[5,4,3]  R2200     -6.5149967558681965e-03
    z[5,4,3]  R2201     -3.7961628288030624e-02
    z[5,4,3]  R2202     -8.3082199096679688e-02
    z[5,4,3]  R2203     -1.7763453722000122e-01
    z[5,4,3]  R2204     -3.2958149909973145e-01
    z[5,4,3]  R2205     6.0544097423553467e-01
    z[5,4,3]  R2206     0.659436047077179
    z[5,4,3]  R2207     3.0554351210594177e-01
    z[5,4,3]  R2208     4.1048571467399597e-01
    z[5,4,3]  R2209     6.0898989439010620e-01
    z[5,4,3]  R2210     4.5346373319625854e-01
    z[5,4,3]  R2211     5.7801395654678345e-01
    z[5,4,3]  R2212     6.9905549287796021e-02
    z[5,4,3]  R2213     7.0637071132659912e-01
    z[5,4,3]  R2214     -1.6438831388950348e-01
    z[5,4,3]  R2215     -6.8297930993139744e-03
    z[5,4,3]  R2216     1.5079972147941589e-01
    z[5,4,3]  R2217     5.4189282655715942e-01
    z[5,4,3]  R2218     3.8812670111656189e-01
    z[5,4,3]  R2219     4.8228484392166138e-01
    z[5,4,3]  R2220     5.7043421268463135e-01
    z[5,4,3]  R2221     -1.8974894285202026e-01
    z[5,4,3]  R2222     -1.1921525001525879e-01
    z[5,4,3]  R2223     5.4200851917266846e-01
    z[5,4,3]  R2224     -2.6978492736816406e-01
    z[5,4,3]  R2225     2.2138184309005737e-01
    z[5,4,3]  R2226     1.6960693895816803e-01
    z[5,4,3]  R2227     -0.569624662399292
    z[5,4,3]  R2228     6.6334950923919678e-01
    z[5,4,3]  R2229     7.2761672735214233e-01
    z[5,4,3]  R2230     0.734235405921936
    z[5,4,3]  R2231     5.1514565944671631e-01
    z[5,4,3]  R2232     6.0097473859786987e-01
    z[5,4,3]  R2233     3.8841915130615234e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2118     -1
    z[5,4,4]  R2119     1
    z[5,4,4]  R2124     1.7936299741268158e-01
    z[5,4,4]  R2125     -3.8924279808998108e-01
    z[5,4,4]  R2126     -2.1627798676490784e-01
    z[5,4,4]  R2127     5.2010279148817062e-02
    z[5,4,4]  R2128     -1.1546332389116287e-01
    z[5,4,4]  R2129     8.3594217896461487e-02
    z[5,4,4]  R2130     -1.9497834146022797e-01
    z[5,4,4]  R2131     -1.6167469322681427e-02
    z[5,4,4]  R2132     2.3384955525398254e-01
    z[5,4,4]  R2133     -5.3835760802030563e-02
    z[5,4,4]  R2134     -2.2014346718788147e-01
    z[5,4,4]  R2135     -4.5374695211648941e-02
    z[5,4,4]  R2136     3.4137617796659470e-02
    z[5,4,4]  R2137     -3.1233888119459152e-02
    z[5,4,4]  R2138     6.6238231956958771e-02
    z[5,4,4]  R2139     2.9615478590130806e-02
    z[5,4,4]  R2140     2.5716400146484375e-01
    z[5,4,4]  R2141     -1.7625771462917328e-01
    z[5,4,4]  R2142     -4.7561034560203552e-01
    z[5,4,4]  R2143     -1.9259326159954071e-01
    z[5,4,4]  R2144     -2.0585859194397926e-02
    z[5,4,4]  R2145     0.266190767288208
    z[5,4,4]  R2146     4.8363244533538818e-01
    z[5,4,4]  R2147     -4.9662560224533081e-01
    z[5,4,4]  R2148     -2.7106830477714539e-01
    z[5,4,4]  R2149     -5.3728890419006348e-01
    z[5,4,4]  R2150     -6.1553839594125748e-02
    z[5,4,4]  R2151     -0.562829852104187
    z[5,4,4]  R2152     7.7291913330554962e-02
    z[5,4,4]  R2153     -1.1433874815702438e-01
    z[5,4,4]  R2154     2.5169411301612854e-01
    z[5,4,4]  R2155     -3.1164211034774780e-01
    z[5,4,4]  R2156     1.7597810924053192e-01
    z[5,4,4]  R2157     3.6798211932182312e-01
    z[5,4,4]  R2158     -0.179236501455307
    z[5,4,4]  R2159     2.1292287856340408e-02
    z[5,4,4]  R2160     -3.7797105312347412e-01
    z[5,4,4]  R2161     3.0390709638595581e-01
    z[5,4,4]  R2162     -3.8187372684478760e-01
    z[5,4,4]  R2163     -9.3844980001449585e-02
    z[5,4,4]  R2164     -0.236972376704216
    z[5,4,4]  R2165     9.4497419893741608e-02
    z[5,4,4]  R2166     -3.8247920572757721e-02
    z[5,4,4]  R2167     2.7009603381156921e-01
    z[5,4,4]  R2168     -4.2381209135055542e-01
    z[5,4,4]  R2169     2.4931342899799347e-01
    z[5,4,4]  R2170     5.3998857736587524e-01
    z[5,4,4]  R2171     4.0488681197166443e-01
    z[5,4,4]  R2172     8.3670176565647125e-02
    z[5,4,4]  R2173     -4.5888268947601318e-01
    z[5,4,4]  R2174     -4.6604439616203308e-02
    z[5,4,4]  R2175     3.2704961299896240e-01
    z[5,4,4]  R2176     7.0567227900028229e-02
    z[5,4,4]  R2177     6.8108029663562775e-02
    z[5,4,4]  R2178     -3.2181560993194580e-01
    z[5,4,4]  R2179     1.1002613604068756e-01
    z[5,4,4]  R2180     -2.1122857928276062e-01
    z[5,4,4]  R2181     5.9931587427854538e-02
    z[5,4,4]  R2182     3.5749897360801697e-01
    z[5,4,4]  R2183     3.9830144494771957e-02
    z[5,4,4]  R2184     9.8430924117565155e-02
    z[5,4,4]  R2185     -1.8710391223430634e-01
    z[5,4,4]  R2186     4.4314882159233093e-01
    z[5,4,4]  R2187     -1.6496485471725464e-01
    z[5,4,4]  R2188     -1.3414295017719269e-01
    z[5,4,4]  R2189     2.9464820027351379e-01
    z[5,4,4]  R2190     1.2383643537759781e-01
    z[5,4,4]  R2191     -4.0240734815597534e-01
    z[5,4,4]  R2192     3.8772711157798767e-01
    z[5,4,4]  R2193     1.3923652470111847e-01
    z[5,4,4]  R2194     -2.5536835193634033e-02
    z[5,4,4]  R2195     1.2949708104133606e-01
    z[5,4,4]  R2196     -2.2019621729850769e-01
    z[5,4,4]  R2197     1.0598796652629972e-03
    z[5,4,4]  R2198     8.8494084775447845e-02
    z[5,4,4]  R2199     -2.9208001494407654e-01
    z[5,4,4]  R2200     2.4737942218780518e-01
    z[5,4,4]  R2201     -8.6463037878274918e-03
    z[5,4,4]  R2202     2.9909974336624146e-01
    z[5,4,4]  R2203     1.0704813152551651e-01
    z[5,4,4]  R2204     0.446789026260376
    z[5,4,4]  R2205     -7.2337381541728973e-02
    z[5,4,4]  R2206     8.3119682967662811e-02
    z[5,4,4]  R2207     -2.2192949056625366e-01
    z[5,4,4]  R2208     -1.5212824940681458e-01
    z[5,4,4]  R2209     -2.1435758471488953e-01
    z[5,4,4]  R2210     -0.0946648046374321
    z[5,4,4]  R2211     3.6931118369102478e-01
    z[5,4,4]  R2212     0.379222571849823
    z[5,4,4]  R2213     -2.4310941994190216e-01
    z[5,4,4]  R2214     -2.5651225820183754e-02
    z[5,4,4]  R2215     1.2730209529399872e-01
    z[5,4,4]  R2216     1.7170648276805878e-01
    z[5,4,4]  R2217     5.5817224085330963e-02
    z[5,4,4]  R2218     -1.1799231171607971e-01
    z[5,4,4]  R2219     -2.0960466936230659e-03
    z[5,4,4]  R2220     4.3104174733161926e-01
    z[5,4,4]  R2221     2.8437113761901855e-01
    z[5,4,4]  R2222     3.1697955727577209e-01
    z[5,4,4]  R2223     -5.0764739513397217e-01
    z[5,4,4]  R2224     -2.5927874445915222e-01
    z[5,4,4]  R2225     1.0246764123439789e-01
    z[5,4,4]  R2226     -1.5932027995586395e-01
    z[5,4,4]  R2227     1.0432998090982437e-01
    z[5,4,4]  R2228     -3.1737962365150452e-01
    z[5,4,4]  R2229     -1.3017675280570984e-01
    z[5,4,4]  R2230     -4.1775807738304138e-01
    z[5,4,4]  R2231     -0.491071492433548
    z[5,4,4]  R2232     -1.2468812055885792e-02
    z[5,4,4]  R2233     -3.4238421916961670e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2120     -1
    z[5,4,5]  R2121     1
    z[5,4,5]  R2124     3.8588356226682663e-02
    z[5,4,5]  R2125     -5.9759981930255890e-02
    z[5,4,5]  R2126     -9.8781652748584747e-02
    z[5,4,5]  R2127     4.9851533770561218e-01
    z[5,4,5]  R2128     8.8417582213878632e-02
    z[5,4,5]  R2129     4.1982212662696838e-01
    z[5,4,5]  R2130     5.0388105213642120e-02
    z[5,4,5]  R2131     -2.9312046244740486e-02
    z[5,4,5]  R2132     2.2549599409103394e-02
    z[5,4,5]  R2133     9.7208611667156219e-02
    z[5,4,5]  R2134     -0.20915587246418
    z[5,4,5]  R2135     2.7075076103210449e-01
    z[5,4,5]  R2136     -1.3327005505561829e-01
    z[5,4,5]  R2137     -1.0672775655984879e-01
    z[5,4,5]  R2138     -1.8711720407009125e-01
    z[5,4,5]  R2139     4.2427446693181992e-02
    z[5,4,5]  R2140     -5.3012490272521973e-02
    z[5,4,5]  R2141     1.2396091967821121e-01
    z[5,4,5]  R2142     -5.7057093828916550e-02
    z[5,4,5]  R2143     -0.664159893989563
    z[5,4,5]  R2144     -1.6862601041793823e-01
    z[5,4,5]  R2145     -3.3100903034210205e-01
    z[5,4,5]  R2146     4.1131377220153809e-02
    z[5,4,5]  R2147     -4.3417149782180786e-01
    z[5,4,5]  R2148     -6.4314886927604675e-02
    z[5,4,5]  R2149     3.2166644930839539e-02
    z[5,4,5]  R2150     -2.9103556275367737e-01
    z[5,4,5]  R2151     -4.6886539459228516e-01
    z[5,4,5]  R2152     -4.1835474967956543e-01
    z[5,4,5]  R2153     8.4974959492683411e-02
    z[5,4,5]  R2154     -6.5110139548778534e-02
    z[5,4,5]  R2155     -1.3007238507270813e-01
    z[5,4,5]  R2156     -1.4972680248320103e-02
    z[5,4,5]  R2157     -1.5832929313182831e-01
    z[5,4,5]  R2158     -8.0520617961883545e-01
    z[5,4,5]  R2159     -7.1239614486694336e-01
    z[5,4,5]  R2160     -7.5145828723907471e-01
    z[5,4,5]  R2161     -7.3359489440917969e-02
    z[5,4,5]  R2162     -6.5183258056640625e-01
    z[5,4,5]  R2163     0.0919019877910614
    z[5,4,5]  R2164     -6.8476825952529907e-01
    z[5,4,5]  R2165     -0.540597677230835
    z[5,4,5]  R2166     -5.7579392194747925e-01
    z[5,4,5]  R2167     4.3393453955650330e-01
    z[5,4,5]  R2168     -3.0361536145210266e-01
    z[5,4,5]  R2169     -4.4442582130432129e-01
    z[5,4,5]  R2170     -1.9340707361698151e-01
    z[5,4,5]  R2171     -1.2813787162303925e-01
    z[5,4,5]  R2172     7.0793461799621582e-01
    z[5,4,5]  R2173     -5.4943698644638062e-01
    z[5,4,5]  R2174     4.1062682867050171e-01
    z[5,4,5]  R2175     2.5218388438224792e-01
    z[5,4,5]  R2176     1.0526556521654129e-01
    z[5,4,5]  R2177     -2.0504812896251678e-01
    z[5,4,5]  R2178     -8.4403932094573975e-02
    z[5,4,5]  R2179     5.3338732570409775e-02
    z[5,4,5]  R2180     -0.770687997341156
    z[5,4,5]  R2181     2.7705445885658264e-01
    z[5,4,5]  R2182     6.9618618488311768e-01
    z[5,4,5]  R2183     -1.8352276086807251e-01
    z[5,4,5]  R2184     -3.4275892376899719e-01
    z[5,4,5]  R2185     4.5087933540344238e-02
    z[5,4,5]  R2186     -2.9953157529234886e-02
    z[5,4,5]  R2187     -2.9334187507629395e-01
    z[5,4,5]  R2188     -2.0664717257022858e-01
    z[5,4,5]  R2189     -2.7806335687637329e-01
    z[5,4,5]  R2190     -8.7379798293113708e-02
    z[5,4,5]  R2191     -1.8528784811496735e-01
    z[5,4,5]  R2192     -1.8259078264236450e-01
    z[5,4,5]  R2193     -2.4348990619182587e-01
    z[5,4,5]  R2194     5.3352709859609604e-02
    z[5,4,5]  R2195     0.00816498976200819
    z[5,4,5]  R2196     2.2049862146377563e-01
    z[5,4,5]  R2197     1.4124831557273865e-01
    z[5,4,5]  R2198     6.3177652657032013e-02
    z[5,4,5]  R2199     -1.7479600384831429e-02
    z[5,4,5]  R2200     -2.2237753868103027e-01
    z[5,4,5]  R2201     2.3980200290679932e-01
    z[5,4,5]  R2202     3.1261703372001648e-01
    z[5,4,5]  R2203     -6.2608927488327026e-02
    z[5,4,5]  R2204     -5.2011895179748535e-01
    z[5,4,5]  R2205     3.6351811885833740e-01
    z[5,4,5]  R2206     1.7412659525871277e-01
    z[5,4,5]  R2207     4.7694477438926697e-01
    z[5,4,5]  R2208     -2.9019734263420105e-01
    z[5,4,5]  R2209     2.7124032378196716e-01
    z[5,4,5]  R2210     6.3384497165679932e-01
    z[5,4,5]  R2211     0.338814914226532
    z[5,4,5]  R2212     -4.9608775973320007e-01
    z[5,4,5]  R2213     -2.6866504549980164e-01
    z[5,4,5]  R2214     0.118772953748703
    z[5,4,5]  R2215     1.4905580878257751e-01
    z[5,4,5]  R2216     -3.9016890525817871e-01
    z[5,4,5]  R2217     1.9322144985198975e-01
    z[5,4,5]  R2218     4.0428814291954041e-01
    z[5,4,5]  R2219     -1.8809929490089417e-01
    z[5,4,5]  R2220     -3.2025733590126038e-01
    z[5,4,5]  R2221     -4.2974588274955750e-01
    z[5,4,5]  R2222     -2.5475805997848511e-01
    z[5,4,5]  R2223     -5.9276670217514038e-01
    z[5,4,5]  R2224     3.0984953045845032e-01
    z[5,4,5]  R2225     -1.6345185041427612e-01
    z[5,4,5]  R2226     -2.6504019275307655e-02
    z[5,4,5]  R2227     -3.3260446786880493e-01
    z[5,4,5]  R2228     -0.58106929063797
    z[5,4,5]  R2229     -3.7125506997108459e-01
    z[5,4,5]  R2230     -3.0003935098648071e-01
    z[5,4,5]  R2231     -3.7825220823287964e-01
    z[5,4,5]  R2232     -6.4805221557617188e-01
    z[5,4,5]  R2233     -5.2606594562530518e-01
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2122     -1
    z[5,4,6]  R2123     1
    z[5,4,6]  R2124     -0.213245689868927
    z[5,4,6]  R2125     -1.1445382237434387e-01
    z[5,4,6]  R2126     3.0972677469253540e-01
    z[5,4,6]  R2127     -1.4680434763431549e-01
    z[5,4,6]  R2128     1.4119245111942291e-01
    z[5,4,6]  R2129     -2.9564124345779419e-01
    z[5,4,6]  R2130     3.4207320213317871e-01
    z[5,4,6]  R2131     -3.5359996557235718e-01
    z[5,4,6]  R2132     -2.0274966955184937e-01
    z[5,4,6]  R2133     1.9331571459770203e-01
    z[5,4,6]  R2134     -8.9825429022312164e-02
    z[5,4,6]  R2135     -9.0498877689242363e-03
    z[5,4,6]  R2136     1.7261378467082977e-01
    z[5,4,6]  R2137     3.6802750825881958e-01
    z[5,4,6]  R2138     1.0216881334781647e-01
    z[5,4,6]  R2139     2.8805169463157654e-01
    z[5,4,6]  R2140     2.0300626754760742e-02
    z[5,4,6]  R2141     3.7663422524929047e-02
    z[5,4,6]  R2142     2.2350224852561951e-01
    z[5,4,6]  R2143     1.3495652377605438e-01
    z[5,4,6]  R2144     -2.7111336588859558e-01
    z[5,4,6]  R2145     -1.2901568412780762e-01
    z[5,4,6]  R2146     -1.0398577898740768e-01
    z[5,4,6]  R2147     3.4599813818931580e-01
    z[5,4,6]  R2148     5.1238399744033813e-01
    z[5,4,6]  R2149     -2.1321910619735718e-01
    z[5,4,6]  R2150     1.7266513779759407e-02
    z[5,4,6]  R2151     -1.4194932579994202e-01
    z[5,4,6]  R2152     -2.7249327301979065e-01
    z[5,4,6]  R2153     2.1349404752254486e-01
    z[5,4,6]  R2154     -2.2075112909078598e-02
    z[5,4,6]  R2155     2.9936149716377258e-01
    z[5,4,6]  R2156     -3.5097181797027588e-02
    z[5,4,6]  R2157     6.6236026585102081e-02
    z[5,4,6]  R2158     -1.0731033980846405e-01
    z[5,4,6]  R2159     -5.0495218485593796e-02
    z[5,4,6]  R2160     -1.5178513526916504e-01
    z[5,4,6]  R2161     -3.4815138578414917e-01
    z[5,4,6]  R2162     4.1891507804393768e-02
    z[5,4,6]  R2163     1.3261966407299042e-01
    z[5,4,6]  R2164     7.9603493213653564e-02
    z[5,4,6]  R2165     -1.8367318809032440e-01
    z[5,4,6]  R2166     2.6043435931205750e-01
    z[5,4,6]  R2167     -7.9081624746322632e-02
    z[5,4,6]  R2168     -5.6449435651302338e-03
    z[5,4,6]  R2169     -2.0487642288208008e-01
    z[5,4,6]  R2170     9.3412511050701141e-03
    z[5,4,6]  R2171     2.2414916753768921e-01
    z[5,4,6]  R2172     -1.6394597291946411e-01
    z[5,4,6]  R2173     9.3698501586914062e-02
    z[5,4,6]  R2174     1.0346536524593830e-02
    z[5,4,6]  R2175     2.0242041349411011e-01
    z[5,4,6]  R2176     2.9542511701583862e-01
    z[5,4,6]  R2177     -0.0766846090555191
    z[5,4,6]  R2178     -1.4676292240619659e-01
    z[5,4,6]  R2179     6.8043315410614014e-01
    z[5,4,6]  R2180     -2.1194823086261749e-01
    z[5,4,6]  R2181     9.8082497715950012e-02
    z[5,4,6]  R2182     2.1409492194652557e-01
    z[5,4,6]  R2183     -2.5079679489135742e-01
    z[5,4,6]  R2184     -2.7031236886978149e-01
    z[5,4,6]  R2185     -3.6006903648376465e-01
    z[5,4,6]  R2186     -8.4542363882064819e-02
    z[5,4,6]  R2187     1.9825683534145355e-01
    z[5,4,6]  R2188     1.8086800118908286e-03
    z[5,4,6]  R2189     3.8836565613746643e-01
    z[5,4,6]  R2190     1.0225946456193924e-01
    z[5,4,6]  R2191     -1.9530941545963287e-01
    z[5,4,6]  R2192     5.5214506387710571e-01
    z[5,4,6]  R2193     5.6081664562225342e-01
    z[5,4,6]  R2194     1.3139556348323822e-01
    z[5,4,6]  R2195     2.6312194764614105e-02
    z[5,4,6]  R2196     -1.8855512142181396e-01
    z[5,4,6]  R2197     0.219558984041214
    z[5,4,6]  R2198     5.1874320954084396e-02
    z[5,4,6]  R2199     -3.6246750503778458e-02
    z[5,4,6]  R2200     5.1881197839975357e-02
    z[5,4,6]  R2201     -2.6275175809860229e-01
    z[5,4,6]  R2202     1.5936821699142456e-01
    z[5,4,6]  R2203     4.5621609687805176e-01
    z[5,4,6]  R2204     1.3237684965133667e-01
    z[5,4,6]  R2205     -1.1799604445695877e-01
    z[5,4,6]  R2206     -1.3395063579082489e-01
    z[5,4,6]  R2207     7.1930542588233948e-02
    z[5,4,6]  R2208     -4.8952198028564453e-01
    z[5,4,6]  R2209     -5.1462358236312866e-01
    z[5,4,6]  R2210     2.2167497873306274e-01
    z[5,4,6]  R2211     -4.1103911399841309e-01
    z[5,4,6]  R2212     -6.3495904207229614e-01
    z[5,4,6]  R2213     -1.5159158408641815e-01
    z[5,4,6]  R2214     3.2869648933410645e-01
    z[5,4,6]  R2215     -1.1322646588087082e-01
    z[5,4,6]  R2216     -3.7916172295808792e-02
    z[5,4,6]  R2217     -9.0696640312671661e-02
    z[5,4,6]  R2218     -2.8596329689025879e-01
    z[5,4,6]  R2219     3.6390227614901960e-04
    z[5,4,6]  R2220     -4.5304756611585617e-02
    z[5,4,6]  R2221     -4.6856012195348740e-02
    z[5,4,6]  R2222     -6.9118463993072510e-01
    z[5,4,6]  R2223     -3.0608588829636574e-02
    z[5,4,6]  R2224     2.1094322204589844e-02
    z[5,4,6]  R2225     1.8923284113407135e-01
    z[5,4,6]  R2226     1.3367126882076263e-01
    z[5,4,6]  R2227     -1.2137117236852646e-01
    z[5,4,6]  R2228     -9.0393684804439545e-02
    z[5,4,6]  R2229     2.7407559752464294e-01
    z[5,4,6]  R2230     3.3861619234085083e-01
    z[5,4,6]  R2231     2.1317753195762634e-01
    z[5,4,6]  R2232     1.0882806777954102e-01
    z[5,4,6]  R2233     3.0970957130193710e-02
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2234     -1
    z[5,6,0]  R2235     1
    z[5,6,0]  R2248     -1.1327574402093887e-01
    z[5,6,0]  R2249     1.1821000277996063e-01
    z[5,6,0]  R2250     -3.5126686096191406e-01
    z[5,6,0]  R2251     2.0345158874988556e-01
    z[5,6,0]  R2252     1.5866951644420624e-01
    z[5,6,0]  R2253     1.4918965101242065e-01
    z[5,6,0]  R2254     1.4596323668956757e-01
    z[5,6,0]  R2255     -5.2205246686935425e-01
    z[5,6,0]  R2256     -4.4384837150573730e-01
    z[5,6,0]  R2257     -0.854417622089386
    z[5,6,0]  R2258     3.4748545289039612e-01
    z[5,6,0]  R2259     -1.2408905476331711e-01
    z[5,6,0]  R2260     1.9600579142570496e-01
    z[5,6,0]  R2261     1.4159527420997620e-01
    z[5,6,0]  R2262     0.352468878030777
    z[5,6,0]  R2263     2.5963535904884338e-01
    z[5,6,0]  R2264     1.6861203312873840e-01
    z[5,6,0]  R2265     1.5843059122562408e-01
    z[5,6,0]  R2266     1.5164570510387421e-01
    z[5,6,0]  R2267     1.8139271438121796e-01
    z[5,6,0]  R2268     1.8842476606369019e-01
    z[5,6,0]  R2269     -1.6518227756023407e-02
    z[5,6,0]  R2270     3.1579241156578064e-02
    z[5,6,0]  R2271     -3.2002660632133484e-01
    z[5,6,0]  R2272     -2.0104108750820160e-01
    z[5,6,0]  R2273     -2.2300831973552704e-01
    z[5,6,0]  R2274     5.1281917095184326e-01
    z[5,6,0]  R2275     2.4213770031929016e-01
    z[5,6,0]  R2276     1.4620113186538219e-02
    z[5,6,0]  R2277     2.5184684991836548e-01
    z[5,6,0]  R2278     -0.406929075717926
    z[5,6,0]  R2279     -2.2387205064296722e-01
    z[5,6,0]  R2280     3.8542559742927551e-01
    z[5,6,0]  R2281     -2.3967489600181580e-01
    z[5,6,0]  R2282     -2.3025350272655487e-01
    z[5,6,0]  R2283     -3.9414188265800476e-01
    z[5,6,0]  R2284     -7.0512875914573669e-02
    z[5,6,0]  R2285     4.3129718303680420e-01
    z[5,6,0]  R2286     -4.4638893008232117e-01
    z[5,6,0]  R2287     0.214206725358963
    z[5,6,0]  R2288     -2.7951663732528687e-01
    z[5,6,0]  R2289     6.2482478097081184e-03
    z[5,6,0]  R2290     -5.6338828802108765e-01
    z[5,6,0]  R2291     -2.9648989439010620e-01
    z[5,6,0]  R2292     -2.6210770010948181e-01
    z[5,6,0]  R2293     -0.746512770652771
    z[5,6,0]  R2294     -1.4326098561286926e-01
    z[5,6,0]  R2295     -8.8023543357849121e-03
    z[5,6,0]  R2296     6.6120497882366180e-02
    z[5,6,0]  R2297     2.4554353952407837e-01
    z[5,6,0]  R2298     -5.1022070646286011e-01
    z[5,6,0]  R2299     -7.1848720312118530e-01
    z[5,6,0]  R2300     2.2021791338920593e-01
    z[5,6,0]  R2301     0.188834086060524
    z[5,6,0]  R2302     4.7437706589698792e-01
    z[5,6,0]  R2303     4.6587541699409485e-01
    z[5,6,0]  R2304     7.2910927236080170e-02
    z[5,6,0]  R2305     7.2841948270797729e-01
    z[5,6,0]  R2306     3.0446156859397888e-01
    z[5,6,0]  R2307     5.4198443889617920e-01
    z[5,6,0]  R2308     -7.1324408054351807e-03
    z[5,6,0]  R2309     -0.609872043132782
    z[5,6,0]  R2310     -3.5625150799751282e-01
    z[5,6,0]  R2311     3.0565840005874634e-01
    z[5,6,0]  R2312     5.8468718081712723e-02
    z[5,6,0]  R2313     3.7295544147491455e-01
    z[5,6,0]  R2314     -4.7175645828247070e-02
    z[5,6,0]  R2315     -3.3855131268501282e-01
    z[5,6,0]  R2316     3.1291771680116653e-02
    z[5,6,0]  R2317     -2.0230922847986221e-02
    z[5,6,0]  R2318     1.5634299814701080e-01
    z[5,6,0]  R2319     3.0353438854217529e-01
    z[5,6,0]  R2320     -7.5079208612442017e-01
    z[5,6,0]  R2321     2.2267715632915497e-01
    z[5,6,0]  R2322     4.5826411247253418e-01
    z[5,6,0]  R2323     3.4416344761848450e-01
    z[5,6,0]  R2324     1.6742998361587524e-01
    z[5,6,0]  R2325     5.6998956203460693e-01
    z[5,6,0]  R2326     -7.1649444103240967e-01
    z[5,6,0]  R2327     -7.2960138320922852e-01
    z[5,6,0]  R2328     -3.8719708099961281e-03
    z[5,6,0]  R2329     0.377970814704895
    z[5,6,0]  R2330     3.6683431267738342e-01
    z[5,6,0]  R2331     5.4809135198593140e-01
    z[5,6,0]  R2332     3.9708280563354492e-01
    z[5,6,0]  R2333     2.5789085030555725e-01
    z[5,6,0]  R2334     6.8862646818161011e-01
    z[5,6,0]  R2335     -6.4441777765750885e-02
    z[5,6,0]  R2336     4.6054384112358093e-01
    z[5,6,0]  R2337     -1.5428721904754639e-01
    z[5,6,0]  R2338     -1.6341438889503479e-01
    z[5,6,0]  R2339     -3.2093605399131775e-01
    z[5,6,0]  R2340     -8.8356596231460571e-01
    z[5,6,0]  R2341     -1.7391633987426758e-01
    z[5,6,0]  R2342     -0.804546594619751
    z[5,6,0]  R2343     -8.6530953645706177e-01
    z[5,6,0]  R2344     6.3675379753112793e-01
    z[5,6,0]  R2345     -0.66482013463974
    z[5,6,0]  R2346     -6.4516210556030273e-01
    z[5,6,0]  R2347     -3.7745776772499084e-01
    z[5,6,0]  R2348     -2.4024908244609833e-01
    z[5,6,0]  R2349     -2.0745202898979187e-02
    z[5,6,0]  R2350     -3.7880662828683853e-02
    z[5,6,0]  R2351     -2.6529708504676819e-01
    z[5,6,0]  R2352     0.00278069986961782
    z[5,6,0]  R2353     -0.371847540140152
    z[5,6,0]  R2354     -8.7815326452255249e-01
    z[5,6,0]  R2355     -1.9606430083513260e-02
    z[5,6,0]  R2356     -1.5016080439090729e-01
    z[5,6,0]  R2357     2.2420510649681091e-01
    z[5,6,0]  R2358     -1.9836762547492981e-01
    z[5,6,0]  R2359     4.6706837415695190e-01
    z[5,6,0]  R2360     -1.8074283376336098e-02
    z[5,6,0]  R2361     1.8469411134719849e-01
    z[5,6,0]  R2362     -6.5395943820476532e-02
    z[5,6,0]  R2363     2.0739491283893585e-01
    z[5,6,0]  R2364     9.2153802514076233e-02
    z[5,6,0]  R2365     -3.3485004305839539e-01
    z[5,6,0]  R2366     5.7475157082080841e-02
    z[5,6,0]  R2367     8.2998253405094147e-02
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2236     -1
    z[5,6,1]  R2237     1
    z[5,6,1]  R2248     9.0267688035964966e-01
    z[5,6,1]  R2249     8.7850195169448853e-01
    z[5,6,1]  R2250     8.0297881364822388e-01
    z[5,6,1]  R2251     8.2115840911865234e-01
    z[5,6,1]  R2252     -4.2180785536766052e-01
    z[5,6,1]  R2253     7.3890346288681030e-01
    z[5,6,1]  R2254     0.775105357170105
    z[5,6,1]  R2255     -6.7736494541168213e-01
    z[5,6,1]  R2256     -3.3908748626708984e-01
    z[5,6,1]  R2257     -4.1606849431991577e-01
    z[5,6,1]  R2258     -7.6730751991271973e-01
    z[5,6,1]  R2259     -7.0995074510574341e-01
    z[5,6,1]  R2260     -6.6837781667709351e-01
    z[5,6,1]  R2261     -6.6868335008621216e-01
    z[5,6,1]  R2262     -6.8870180845260620e-01
    z[5,6,1]  R2263     -0.689148485660553
    z[5,6,1]  R2264     -0.724707841873169
    z[5,6,1]  R2265     -6.5316039323806763e-01
    z[5,6,1]  R2266     -6.6812676191329956e-01
    z[5,6,1]  R2267     -5.3825861215591431e-01
    z[5,6,1]  R2268     -8.6119043827056885e-01
    z[5,6,1]  R2269     -7.1934396028518677e-01
    z[5,6,1]  R2270     -6.6734534502029419e-01
    z[5,6,1]  R2271     -3.2121309638023376e-01
    z[5,6,1]  R2272     -3.4441930055618286e-01
    z[5,6,1]  R2273     -7.9870028421282768e-03
    z[5,6,1]  R2274     7.0969969034194946e-01
    z[5,6,1]  R2275     -3.8341563940048218e-01
    z[5,6,1]  R2276     8.0171310901641846e-01
    z[5,6,1]  R2277     6.8133169412612915e-01
    z[5,6,1]  R2278     -8.1819391250610352e-01
    z[5,6,1]  R2279     -8.3834046125411987e-01
    z[5,6,1]  R2280     8.9345055818557739e-01
    z[5,6,1]  R2281     8.7546640634536743e-01
    z[5,6,1]  R2282     -5.0110530853271484e-01
    z[5,6,1]  R2283     -5.1602822542190552e-01
    z[5,6,1]  R2284     -3.5946887731552124e-01
    z[5,6,1]  R2285     -3.1774255633354187e-01
    z[5,6,1]  R2286     -2.0169923081994057e-02
    z[5,6,1]  R2287     6.5325963497161865e-01
    z[5,6,1]  R2288     -5.1344031095504761e-01
    z[5,6,1]  R2289     7.9660427570343018e-01
    z[5,6,1]  R2290     -3.0994272232055664e-01
    z[5,6,1]  R2291     7.2402888536453247e-01
    z[5,6,1]  R2292     -5.4558837413787842e-01
    z[5,6,1]  R2293     -3.2240059226751328e-02
    z[5,6,1]  R2294     0.500961422920227
    z[5,6,1]  R2295     0.430346816778183
    z[5,6,1]  R2296     -5.9856027364730835e-01
    z[5,6,1]  R2297     -8.0516338348388672e-02
    z[5,6,1]  R2298     7.1003675460815430e-01
    z[5,6,1]  R2299     -2.7539357542991638e-01
    z[5,6,1]  R2300     -7.8431165218353271e-01
    z[5,6,1]  R2301     6.0737508535385132e-01
    z[5,6,1]  R2302     -2.3485994338989258e-01
    z[5,6,1]  R2303     -3.7489861249923706e-01
    z[5,6,1]  R2304     -4.6983989886939526e-04
    z[5,6,1]  R2305     -2.7126595377922058e-01
    z[5,6,1]  R2306     -0.0902019739151001
    z[5,6,1]  R2307     -9.1256782412528992e-02
    z[5,6,1]  R2308     1.1356388777494431e-01
    z[5,6,1]  R2309     -4.9036312103271484e-01
    z[5,6,1]  R2310     -0.268771767616272
    z[5,6,1]  R2311     -1.7898106575012207e-01
    z[5,6,1]  R2312     1.5737524256110191e-02
    z[5,6,1]  R2313     9.0887606143951416e-02
    z[5,6,1]  R2314     -4.1235667467117310e-01
    z[5,6,1]  R2315     1.8914127349853516e-01
    z[5,6,1]  R2316     -3.6051037907600403e-01
    z[5,6,1]  R2317     -4.4455164670944214e-01
    z[5,6,1]  R2318     5.7409924268722534e-01
    z[5,6,1]  R2319     0.521532416343689
    z[5,6,1]  R2320     4.0930244326591492e-01
    z[5,6,1]  R2321     5.2007561922073364e-01
    z[5,6,1]  R2322     6.0095995664596558e-01
    z[5,6,1]  R2323     4.5345729589462280e-01
    z[5,6,1]  R2324     5.4914832115173340e-01
    z[5,6,1]  R2325     5.0805473327636719e-01
    z[5,6,1]  R2326     5.8904081583023071e-01
    z[5,6,1]  R2327     2.8098881244659424e-01
    z[5,6,1]  R2328     -8.2848638296127319e-01
    z[5,6,1]  R2329     -6.1497098207473755e-01
    z[5,6,1]  R2330     -5.0910407304763794e-01
    z[5,6,1]  R2331     -6.8660420179367065e-01
    z[5,6,1]  R2332     -0.74765944480896
    z[5,6,1]  R2333     -7.9350328445434570e-01
    z[5,6,1]  R2334     -3.7632763385772705e-01
    z[5,6,1]  R2335     -5.1575195789337158e-01
    z[5,6,1]  R2336     -6.1419796943664551e-01
    z[5,6,1]  R2337     -3.1984734535217285e-01
    z[5,6,1]  R2338     -2.7069896459579468e-01
    z[5,6,1]  R2339     -4.9074128270149231e-01
    z[5,6,1]  R2340     8.4123871056362987e-04
    z[5,6,1]  R2341     -5.9279185533523560e-01
    z[5,6,1]  R2342     3.5964214801788330e-01
    z[5,6,1]  R2343     1.4193475246429443e-01
    z[5,6,1]  R2344     -6.0124039649963379e-01
    z[5,6,1]  R2345     0.0818859413266182
    z[5,6,1]  R2346     -5.1137939095497131e-02
    z[5,6,1]  R2347     -5.5152320861816406e-01
    z[5,6,1]  R2348     -6.5132069587707520e-01
    z[5,6,1]  R2349     -6.1464887857437134e-01
    z[5,6,1]  R2350     -2.9878202080726624e-01
    z[5,6,1]  R2351     -3.0940631031990051e-01
    z[5,6,1]  R2352     -3.6072564125061035e-01
    z[5,6,1]  R2353     -0.62802654504776
    z[5,6,1]  R2354     2.0927037298679352e-01
    z[5,6,1]  R2355     -6.8977546691894531e-01
    z[5,6,1]  R2356     -6.4189249277114868e-01
    z[5,6,1]  R2357     2.0453146100044250e-01
    z[5,6,1]  R2358     -6.6997438669204712e-01
    z[5,6,1]  R2359     -3.8101676106452942e-01
    z[5,6,1]  R2360     0.609222948551178
    z[5,6,1]  R2361     6.8127177655696869e-02
    z[5,6,1]  R2362     2.0265281200408936e-01
    z[5,6,1]  R2363     4.5337605476379395e-01
    z[5,6,1]  R2364     2.0321825146675110e-01
    z[5,6,1]  R2365     -5.7266287505626678e-02
    z[5,6,1]  R2366     1.5035147964954376e-01
    z[5,6,1]  R2367     -1.6053926199674606e-02
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2238     -1
    z[5,6,2]  R2239     1
    z[5,6,2]  R2248     -2.2743935883045197e-01
    z[5,6,2]  R2249     -1.9896794855594635e-01
    z[5,6,2]  R2250     2.6907011866569519e-01
    z[5,6,2]  R2251     -7.0819951593875885e-02
    z[5,6,2]  R2252     -0.866377055644989
    z[5,6,2]  R2253     0.3300761282444
    z[5,6,2]  R2254     -2.3459206521511078e-01
    z[5,6,2]  R2255     -2.7051535248756409e-01
    z[5,6,2]  R2256     -7.5094038248062134e-01
    z[5,6,2]  R2257     -1.8892247974872589e-01
    z[5,6,2]  R2258     -6.9927543401718140e-02
    z[5,6,2]  R2259     4.7661286592483521e-01
    z[5,6,2]  R2260     3.4003669023513794e-01
    z[5,6,2]  R2261     9.9839836359024048e-02
    z[5,6,2]  R2262     2.5200808048248291e-01
    z[5,6,2]  R2263     2.2952046990394592e-01
    z[5,6,2]  R2264     4.0556395053863525e-01
    z[5,6,2]  R2265     4.4633349776268005e-01
    z[5,6,2]  R2266     3.1033965945243835e-01
    z[5,6,2]  R2267     0.05144052952528
    z[5,6,2]  R2268     -2.4051231145858765e-01
    z[5,6,2]  R2269     -1.4661246538162231e-01
    z[5,6,2]  R2270     4.6668898314237595e-02
    z[5,6,2]  R2271     -4.7202974557876587e-01
    z[5,6,2]  R2272     -5.4179519414901733e-01
    z[5,6,2]  R2273     -4.4095999002456665e-01
    z[5,6,2]  R2274     3.7452599406242371e-01
    z[5,6,2]  R2275     -4.8140594363212585e-01
    z[5,6,2]  R2276     0.00958534050732851
    z[5,6,2]  R2277     5.9043139219284058e-01
    z[5,6,2]  R2278     -2.9375061858445406e-03
    z[5,6,2]  R2279     5.9286791831254959e-02
    z[5,6,2]  R2280     1.3947954773902893e-01
    z[5,6,2]  R2281     -8.9126199483871460e-02
    z[5,6,2]  R2282     -4.3336143717169762e-03
    z[5,6,2]  R2283     -1.2201385945081711e-01
    z[5,6,2]  R2284     -3.6684155464172363e-01
    z[5,6,2]  R2285     -4.4460549950599670e-01
    z[5,6,2]  R2286     -4.5316964387893677e-01
    z[5,6,2]  R2287     0.624812662601471
    z[5,6,2]  R2288     -2.8168469667434692e-01
    z[5,6,2]  R2289     -2.1682465448975563e-02
    z[5,6,2]  R2290     -2.8477707505226135e-01
    z[5,6,2]  R2291     -6.5252050757408142e-02
    z[5,6,2]  R2292     -6.0091644525527954e-01
    z[5,6,2]  R2293     -3.7112745642662048e-01
    z[5,6,2]  R2294     6.2278604507446289e-01
    z[5,6,2]  R2295     0.732809841632843
    z[5,6,2]  R2296     -3.1777489185333252e-01
    z[5,6,2]  R2297     1.8926402926445007e-01
    z[5,6,2]  R2298     2.5441799312829971e-02
    z[5,6,2]  R2299     -3.5456672310829163e-01
    z[5,6,2]  R2300     -3.9431047439575195e-01
    z[5,6,2]  R2301     5.3239309787750244e-01
    z[5,6,2]  R2302     -3.5722586512565613e-01
    z[5,6,2]  R2303     -1.5683230757713318e-01
    z[5,6,2]  R2304     1.3258498907089233e-01
    z[5,6,2]  R2305     -1.2050031125545502e-01
    z[5,6,2]  R2306     -1.5476141870021820e-01
    z[5,6,2]  R2307     7.6779276132583618e-01
    z[5,6,2]  R2308     -6.6207003593444824e-01
    z[5,6,2]  R2309     -5.6170988082885742e-01
    z[5,6,2]  R2310     -4.9344068765640259e-01
    z[5,6,2]  R2311     -7.3885542154312134e-01
    z[5,6,2]  R2312     -5.0496435165405273e-01
    z[5,6,2]  R2313     -3.2723531126976013e-01
    z[5,6,2]  R2314     -6.5867567062377930e-01
    z[5,6,2]  R2315     -4.8692572116851807e-01
    z[5,6,2]  R2316     -5.9139841794967651e-01
    z[5,6,2]  R2317     -5.0206708908081055e-01
    z[5,6,2]  R2318     7.6512783765792847e-01
    z[5,6,2]  R2319     6.8397843837738037e-01
    z[5,6,2]  R2320     3.6982640624046326e-01
    z[5,6,2]  R2321     7.0460414886474609e-01
    z[5,6,2]  R2322     0.552261471748352
    z[5,6,2]  R2323     6.2330263853073120e-01
    z[5,6,2]  R2324     6.0658687353134155e-01
    z[5,6,2]  R2325     5.6052255630493164e-01
    z[5,6,2]  R2326     1.9127818942070007e-01
    z[5,6,2]  R2327     4.7686657309532166e-01
    z[5,6,2]  R2328     -2.2575299441814423e-01
    z[5,6,2]  R2329     -4.3765774369239807e-01
    z[5,6,2]  R2330     -3.4211507439613342e-01
    z[5,6,2]  R2331     -4.0068873763084412e-01
    z[5,6,2]  R2332     -1.5267378091812134e-01
    z[5,6,2]  R2333     -3.5434699058532715e-01
    z[5,6,2]  R2334     -3.5900583863258362e-01
    z[5,6,2]  R2335     -1.2537996470928192e-01
    z[5,6,2]  R2336     -1.0073851794004440e-01
    z[5,6,2]  R2337     -3.6328250169754028e-01
    z[5,6,2]  R2338     -5.9387695789337158e-01
    z[5,6,2]  R2339     -3.5038021206855774e-01
    z[5,6,2]  R2340     -9.6438162028789520e-02
    z[5,6,2]  R2341     -4.6328902244567871e-01
    z[5,6,2]  R2342     -2.7555164694786072e-01
    z[5,6,2]  R2343     1.7317138612270355e-01
    z[5,6,2]  R2344     -3.0879771709442139e-01
    z[5,6,2]  R2345     -4.7949111461639404e-01
    z[5,6,2]  R2346     -4.8743149638175964e-01
    z[5,6,2]  R2347     2.0412076264619827e-02
    z[5,6,2]  R2348     -0.616512656211853
    z[5,6,2]  R2349     -5.6968605518341064e-01
    z[5,6,2]  R2350     -5.5516713857650757e-01
    z[5,6,2]  R2351     -5.1011794805526733e-01
    z[5,6,2]  R2352     -6.2455916404724121e-01
    z[5,6,2]  R2353     -2.4228592216968536e-01
    z[5,6,2]  R2354     2.3195035755634308e-01
    z[5,6,2]  R2355     -3.4269922971725464e-01
    z[5,6,2]  R2356     -4.9695184826850891e-01
    z[5,6,2]  R2357     1.2902058660984039e-01
    z[5,6,2]  R2358     -2.7538421750068665e-01
    z[5,6,2]  R2359     -2.1320012211799622e-01
    z[5,6,2]  R2360     4.7804632782936096e-01
    z[5,6,2]  R2361     5.1289552450180054e-01
    z[5,6,2]  R2362     4.1988608241081238e-01
    z[5,6,2]  R2363     -1.2099956721067429e-01
    z[5,6,2]  R2364     -4.5156544446945190e-01
    z[5,6,2]  R2365     -6.2282466888427734e-01
    z[5,6,2]  R2366     2.7554255723953247e-01
    z[5,6,2]  R2367     3.4326678514480591e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2240     -1
    z[5,6,3]  R2241     1
    z[5,6,3]  R2248     2.0366741716861725e-01
    z[5,6,3]  R2249     -8.0570735037326813e-02
    z[5,6,3]  R2250     -8.3505190908908844e-02
    z[5,6,3]  R2251     8.0725461244583130e-02
    z[5,6,3]  R2252     -7.2167336940765381e-02
    z[5,6,3]  R2253     -2.2841072082519531e-01
    z[5,6,3]  R2254     4.0657523274421692e-01
    z[5,6,3]  R2255     -0.263260155916214
    z[5,6,3]  R2256     0.166749507188797
    z[5,6,3]  R2257     -1.0699054598808289e-01
    z[5,6,3]  R2258     4.3049424886703491e-01
    z[5,6,3]  R2259     4.2185938358306885e-01
    z[5,6,3]  R2260     5.9203559160232544e-01
    z[5,6,3]  R2261     6.1240088939666748e-01
    z[5,6,3]  R2262     5.3675752878189087e-01
    z[5,6,3]  R2263     5.6509578227996826e-01
    z[5,6,3]  R2264     4.6101042628288269e-01
    z[5,6,3]  R2265     5.4883146286010742e-01
    z[5,6,3]  R2266     3.9355498552322388e-01
    z[5,6,3]  R2267     4.2227292060852051e-01
    z[5,6,3]  R2268     2.5027993321418762e-01
    z[5,6,3]  R2269     5.1352363824844360e-01
    z[5,6,3]  R2270     5.5233132839202881e-01
    z[5,6,3]  R2271     1.2936948239803314e-01
    z[5,6,3]  R2272     4.5526260137557983e-01
    z[5,6,3]  R2273     -6.4852249622344971e-01
    z[5,6,3]  R2274     -6.5455652773380280e-02
    z[5,6,3]  R2275     -7.6473824679851532e-02
    z[5,6,3]  R2276     -3.1890928745269775e-01
    z[5,6,3]  R2277     -2.4057717621326447e-01
    z[5,6,3]  R2278     3.1125918030738831e-01
    z[5,6,3]  R2279     1.9973684847354889e-01
    z[5,6,3]  R2280     -3.6254484206438065e-02
    z[5,6,3]  R2281     5.7488363236188889e-02
    z[5,6,3]  R2282     6.2126670032739639e-02
    z[5,6,3]  R2283     2.3014867305755615e-01
    z[5,6,3]  R2284     -2.5437323376536369e-02
    z[5,6,3]  R2285     -5.4442435503005981e-01
    z[5,6,3]  R2286     -1.4999739825725555e-01
    z[5,6,3]  R2287     -3.1958681344985962e-01
    z[5,6,3]  R2288     2.1795186400413513e-01
    z[5,6,3]  R2289     -1.7320780456066132e-01
    z[5,6,3]  R2290     3.2342472672462463e-01
    z[5,6,3]  R2291     -3.4075376391410828e-01
    z[5,6,3]  R2292     -2.6483917608857155e-02
    z[5,6,3]  R2293     -4.7934178262948990e-02
    z[5,6,3]  R2294     1.0756554454565048e-01
    z[5,6,3]  R2295     2.1706764400005341e-01
    z[5,6,3]  R2296     3.6363206803798676e-02
    z[5,6,3]  R2297     -0.61332768201828
    z[5,6,3]  R2298     -2.5294670462608337e-01
    z[5,6,3]  R2299     2.6586598157882690e-01
    z[5,6,3]  R2300     2.7846372127532959e-01
    z[5,6,3]  R2301     5.0934362411499023e-01
    z[5,6,3]  R2302     -6.7820960283279419e-01
    z[5,6,3]  R2303     -3.7399837374687195e-01
    z[5,6,3]  R2304     -5.4185372591018677e-01
    z[5,6,3]  R2305     5.3974837064743042e-01
    z[5,6,3]  R2306     -4.6572342514991760e-01
    z[5,6,3]  R2307     -1.0125853121280670e-01
    z[5,6,3]  R2308     7.0285123586654663e-01
    z[5,6,3]  R2309     -1.7225007712841034e-01
    z[5,6,3]  R2310     4.4561344385147095e-01
    z[5,6,3]  R2311     3.9838501811027527e-01
    z[5,6,3]  R2312     3.7805780768394470e-01
    z[5,6,3]  R2313     6.2986296415328979e-01
    z[5,6,3]  R2314     -1.2511213123798370e-01
    z[5,6,3]  R2315     0.42557492852211
    z[5,6,3]  R2316     -1.0559994727373123e-01
    z[5,6,3]  R2317     2.1751316264271736e-02
    z[5,6,3]  R2318     1.7642891407012939e-01
    z[5,6,3]  R2319     2.7874562144279480e-01
    z[5,6,3]  R2320     1.1768934130668640e-01
    z[5,6,3]  R2321     0.139877051115036
    z[5,6,3]  R2322     1.7006102204322815e-01
    z[5,6,3]  R2323     4.9650269746780396e-01
    z[5,6,3]  R2324     4.2137256264686584e-01
    z[5,6,3]  R2325     1.0021498799324036e-01
    z[5,6,3]  R2326     5.2976712584495544e-02
    z[5,6,3]  R2327     2.5871220976114273e-02
    z[5,6,3]  R2328     -4.0048643946647644e-01
    z[5,6,3]  R2329     -2.1492913365364075e-01
    z[5,6,3]  R2330     -1.8450836837291718e-01
    z[5,6,3]  R2331     1.2105809897184372e-01
    z[5,6,3]  R2332     -1.1410713195800781e-01
    z[5,6,3]  R2333     2.2164495661854744e-02
    z[5,6,3]  R2334     -4.1962409019470215e-01
    z[5,6,3]  R2335     -4.3861925601959229e-01
    z[5,6,3]  R2336     -5.0154322385787964e-01
    z[5,6,3]  R2337     -3.6153492331504822e-01
    z[5,6,3]  R2338     -5.6492835283279419e-01
    z[5,6,3]  R2339     -0.350996732711792
    z[5,6,3]  R2340     7.1377992630004883e-02
    z[5,6,3]  R2341     -3.6774033308029175e-01
    z[5,6,3]  R2342     1.1131998151540756e-01
    z[5,6,3]  R2343     -2.9271697998046875e-01
    z[5,6,3]  R2344     -3.3724820613861084e-01
    z[5,6,3]  R2345     1.0116033256053925e-01
    z[5,6,3]  R2346     2.8972604870796204e-01
    z[5,6,3]  R2347     -2.9796159267425537e-01
    z[5,6,3]  R2348     -2.4730089306831360e-01
    z[5,6,3]  R2349     -3.6283436417579651e-01
    z[5,6,3]  R2350     -6.5098208189010620e-01
    z[5,6,3]  R2351     -6.8950426578521729e-01
    z[5,6,3]  R2352     -2.6326560974121094e-01
    z[5,6,3]  R2353     -2.6847904920578003e-01
    z[5,6,3]  R2354     -1.8104347586631775e-01
    z[5,6,3]  R2355     2.9219800233840942e-01
    z[5,6,3]  R2356     5.3422415256500244e-01
    z[5,6,3]  R2357     9.3962311744689941e-02
    z[5,6,3]  R2358     -3.1924274563789368e-01
    z[5,6,3]  R2359     -6.8487578630447388e-01
    z[5,6,3]  R2360     -1.2396093457937241e-01
    z[5,6,3]  R2361     1.1860295385122299e-01
    z[5,6,3]  R2362     -3.6851714830845594e-03
    z[5,6,3]  R2363     3.0113914608955383e-01
    z[5,6,3]  R2364     2.2926524281501770e-01
    z[5,6,3]  R2365     2.7679237723350525e-01
    z[5,6,3]  R2366     -5.6929498910903931e-01
    z[5,6,3]  R2367     -5.3526127338409424e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2242     -1
    z[5,6,4]  R2243     1
    z[5,6,4]  R2248     1.7936299741268158e-01
    z[5,6,4]  R2249     -3.8924279808998108e-01
    z[5,6,4]  R2250     -2.1627798676490784e-01
    z[5,6,4]  R2251     5.2010279148817062e-02
    z[5,6,4]  R2252     -1.1546332389116287e-01
    z[5,6,4]  R2253     8.3594217896461487e-02
    z[5,6,4]  R2254     -1.9497834146022797e-01
    z[5,6,4]  R2255     -1.6167469322681427e-02
    z[5,6,4]  R2256     2.3384955525398254e-01
    z[5,6,4]  R2257     -5.3835760802030563e-02
    z[5,6,4]  R2258     -2.2014346718788147e-01
    z[5,6,4]  R2259     -4.5374695211648941e-02
    z[5,6,4]  R2260     3.4137617796659470e-02
    z[5,6,4]  R2261     -3.1233888119459152e-02
    z[5,6,4]  R2262     6.6238231956958771e-02
    z[5,6,4]  R2263     2.9615478590130806e-02
    z[5,6,4]  R2264     2.5716400146484375e-01
    z[5,6,4]  R2265     -1.7625771462917328e-01
    z[5,6,4]  R2266     -4.7561034560203552e-01
    z[5,6,4]  R2267     -1.9259326159954071e-01
    z[5,6,4]  R2268     -2.0585859194397926e-02
    z[5,6,4]  R2269     0.266190767288208
    z[5,6,4]  R2270     4.8363244533538818e-01
    z[5,6,4]  R2271     -4.9662560224533081e-01
    z[5,6,4]  R2272     -2.7106830477714539e-01
    z[5,6,4]  R2273     -5.3728890419006348e-01
    z[5,6,4]  R2274     -6.1553839594125748e-02
    z[5,6,4]  R2275     -0.562829852104187
    z[5,6,4]  R2276     7.7291913330554962e-02
    z[5,6,4]  R2277     -1.1433874815702438e-01
    z[5,6,4]  R2278     2.5169411301612854e-01
    z[5,6,4]  R2279     -3.1164211034774780e-01
    z[5,6,4]  R2280     1.7597810924053192e-01
    z[5,6,4]  R2281     3.6798211932182312e-01
    z[5,6,4]  R2282     -0.179236501455307
    z[5,6,4]  R2283     2.1292287856340408e-02
    z[5,6,4]  R2284     -3.7797105312347412e-01
    z[5,6,4]  R2285     3.0390709638595581e-01
    z[5,6,4]  R2286     -3.8187372684478760e-01
    z[5,6,4]  R2287     -9.3844980001449585e-02
    z[5,6,4]  R2288     -0.236972376704216
    z[5,6,4]  R2289     9.4497419893741608e-02
    z[5,6,4]  R2290     -3.8247920572757721e-02
    z[5,6,4]  R2291     2.7009603381156921e-01
    z[5,6,4]  R2292     -4.2381209135055542e-01
    z[5,6,4]  R2293     2.4931342899799347e-01
    z[5,6,4]  R2294     5.3998857736587524e-01
    z[5,6,4]  R2295     4.0488681197166443e-01
    z[5,6,4]  R2296     8.3670176565647125e-02
    z[5,6,4]  R2297     -4.5888268947601318e-01
    z[5,6,4]  R2298     -4.6604439616203308e-02
    z[5,6,4]  R2299     3.2704961299896240e-01
    z[5,6,4]  R2300     7.0567227900028229e-02
    z[5,6,4]  R2301     6.8108029663562775e-02
    z[5,6,4]  R2302     -3.2181560993194580e-01
    z[5,6,4]  R2303     1.1002613604068756e-01
    z[5,6,4]  R2304     -2.1122857928276062e-01
    z[5,6,4]  R2305     5.9931587427854538e-02
    z[5,6,4]  R2306     3.5749897360801697e-01
    z[5,6,4]  R2307     3.9830144494771957e-02
    z[5,6,4]  R2308     7.3707611300051212e-03
    z[5,6,4]  R2309     -1.1025711894035339e-01
    z[5,6,4]  R2310     2.2705543041229248e-01
    z[5,6,4]  R2311     1.8147720396518707e-01
    z[5,6,4]  R2312     3.1352239847183228e-01
    z[5,6,4]  R2313     3.4658116102218628e-01
    z[5,6,4]  R2314     -2.7731582522392273e-01
    z[5,6,4]  R2315     2.6809543371200562e-01
    z[5,6,4]  R2316     -1.9075492024421692e-01
    z[5,6,4]  R2317     -5.3753042221069336e-01
    z[5,6,4]  R2318     9.7786642611026764e-02
    z[5,6,4]  R2319     2.6051837205886841e-01
    z[5,6,4]  R2320     -4.0340710431337357e-02
    z[5,6,4]  R2321     -2.0097592473030090e-01
    z[5,6,4]  R2322     2.7689328417181969e-02
    z[5,6,4]  R2323     2.0092625170946121e-02
    z[5,6,4]  R2324     -1.9369050860404968e-01
    z[5,6,4]  R2325     0.0772441104054451
    z[5,6,4]  R2326     -6.6140934824943542e-02
    z[5,6,4]  R2327     2.9915568232536316e-01
    z[5,6,4]  R2328     1.8556652963161469e-01
    z[5,6,4]  R2329     -1.8377484381198883e-01
    z[5,6,4]  R2330     -4.2894887924194336e-01
    z[5,6,4]  R2331     6.9989293813705444e-02
    z[5,6,4]  R2332     2.6184371113777161e-01
    z[5,6,4]  R2333     3.8881441950798035e-01
    z[5,6,4]  R2334     -2.6986005902290344e-01
    z[5,6,4]  R2335     0.478142648935318
    z[5,6,4]  R2336     3.4068933129310608e-01
    z[5,6,4]  R2337     -5.9474412351846695e-02
    z[5,6,4]  R2338     -2.1574285626411438e-01
    z[5,6,4]  R2339     -2.8994113206863403e-01
    z[5,6,4]  R2340     -1.7099156975746155e-01
    z[5,6,4]  R2341     4.3007937073707581e-01
    z[5,6,4]  R2342     -1.8034437298774719e-01
    z[5,6,4]  R2343     3.6082316190004349e-02
    z[5,6,4]  R2344     1.0241910815238953e-01
    z[5,6,4]  R2345     -2.6553717255592346e-01
    z[5,6,4]  R2346     8.7884448468685150e-02
    z[5,6,4]  R2347     3.7979838252067566e-01
    z[5,6,4]  R2348     1.2877424061298370e-01
    z[5,6,4]  R2349     -2.3375539481639862e-01
    z[5,6,4]  R2350     -3.0089142918586731e-01
    z[5,6,4]  R2351     -2.5148290395736694e-01
    z[5,6,4]  R2352     8.1425786018371582e-02
    z[5,6,4]  R2353     5.4870493710041046e-02
    z[5,6,4]  R2354     2.2733654081821442e-01
    z[5,6,4]  R2355     9.5197439193725586e-02
    z[5,6,4]  R2356     -8.6993388831615448e-02
    z[5,6,4]  R2357     -4.7589138150215149e-02
    z[5,6,4]  R2358     -2.9893046244978905e-02
    z[5,6,4]  R2359     -1.7614772915840149e-01
    z[5,6,4]  R2360     -8.7283954024314880e-02
    z[5,6,4]  R2361     2.7306738495826721e-01
    z[5,6,4]  R2362     2.1143786609172821e-01
    z[5,6,4]  R2363     7.3112696409225464e-01
    z[5,6,4]  R2364     1.8248160183429718e-01
    z[5,6,4]  R2365     -5.6155747175216675e-01
    z[5,6,4]  R2366     -5.0185203552246094e-01
    z[5,6,4]  R2367     -3.0351039767265320e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2244     -1
    z[5,6,5]  R2245     1
    z[5,6,5]  R2248     3.8588356226682663e-02
    z[5,6,5]  R2249     -5.9759981930255890e-02
    z[5,6,5]  R2250     -9.8781652748584747e-02
    z[5,6,5]  R2251     4.9851533770561218e-01
    z[5,6,5]  R2252     8.8417582213878632e-02
    z[5,6,5]  R2253     4.1982212662696838e-01
    z[5,6,5]  R2254     5.0388105213642120e-02
    z[5,6,5]  R2255     -2.9312046244740486e-02
    z[5,6,5]  R2256     2.2549599409103394e-02
    z[5,6,5]  R2257     9.7208611667156219e-02
    z[5,6,5]  R2258     -0.20915587246418
    z[5,6,5]  R2259     2.7075076103210449e-01
    z[5,6,5]  R2260     -1.3327005505561829e-01
    z[5,6,5]  R2261     -1.0672775655984879e-01
    z[5,6,5]  R2262     -1.8711720407009125e-01
    z[5,6,5]  R2263     4.2427446693181992e-02
    z[5,6,5]  R2264     -5.3012490272521973e-02
    z[5,6,5]  R2265     1.2396091967821121e-01
    z[5,6,5]  R2266     -5.7057093828916550e-02
    z[5,6,5]  R2267     -0.664159893989563
    z[5,6,5]  R2268     -1.6862601041793823e-01
    z[5,6,5]  R2269     -3.3100903034210205e-01
    z[5,6,5]  R2270     4.1131377220153809e-02
    z[5,6,5]  R2271     -4.3417149782180786e-01
    z[5,6,5]  R2272     -6.4314886927604675e-02
    z[5,6,5]  R2273     3.2166644930839539e-02
    z[5,6,5]  R2274     -2.9103556275367737e-01
    z[5,6,5]  R2275     -4.6886539459228516e-01
    z[5,6,5]  R2276     -4.1835474967956543e-01
    z[5,6,5]  R2277     8.4974959492683411e-02
    z[5,6,5]  R2278     -6.5110139548778534e-02
    z[5,6,5]  R2279     -1.3007238507270813e-01
    z[5,6,5]  R2280     -1.4972680248320103e-02
    z[5,6,5]  R2281     -1.5832929313182831e-01
    z[5,6,5]  R2282     -8.0520617961883545e-01
    z[5,6,5]  R2283     -7.1239614486694336e-01
    z[5,6,5]  R2284     -7.5145828723907471e-01
    z[5,6,5]  R2285     -7.3359489440917969e-02
    z[5,6,5]  R2286     -6.5183258056640625e-01
    z[5,6,5]  R2287     0.0919019877910614
    z[5,6,5]  R2288     -6.8476825952529907e-01
    z[5,6,5]  R2289     -0.540597677230835
    z[5,6,5]  R2290     -5.7579392194747925e-01
    z[5,6,5]  R2291     4.3393453955650330e-01
    z[5,6,5]  R2292     -3.0361536145210266e-01
    z[5,6,5]  R2293     -4.4442582130432129e-01
    z[5,6,5]  R2294     -1.9340707361698151e-01
    z[5,6,5]  R2295     -1.2813787162303925e-01
    z[5,6,5]  R2296     7.0793461799621582e-01
    z[5,6,5]  R2297     -5.4943698644638062e-01
    z[5,6,5]  R2298     4.1062682867050171e-01
    z[5,6,5]  R2299     2.5218388438224792e-01
    z[5,6,5]  R2300     1.0526556521654129e-01
    z[5,6,5]  R2301     -2.0504812896251678e-01
    z[5,6,5]  R2302     -8.4403932094573975e-02
    z[5,6,5]  R2303     5.3338732570409775e-02
    z[5,6,5]  R2304     -0.770687997341156
    z[5,6,5]  R2305     2.7705445885658264e-01
    z[5,6,5]  R2306     6.9618618488311768e-01
    z[5,6,5]  R2307     -1.8352276086807251e-01
    z[5,6,5]  R2308     2.3018307983875275e-01
    z[5,6,5]  R2309     1.7263543605804443e-01
    z[5,6,5]  R2310     5.5181562900543213e-01
    z[5,6,5]  R2311     3.4368079900741577e-01
    z[5,6,5]  R2312     7.0261436700820923e-01
    z[5,6,5]  R2313     4.7340282797813416e-01
    z[5,6,5]  R2314     -2.5899496674537659e-01
    z[5,6,5]  R2315     5.5541670322418213e-01
    z[5,6,5]  R2316     4.8063647747039795e-01
    z[5,6,5]  R2317     3.3625525236129761e-01
    z[5,6,5]  R2318     1.1956129968166351e-01
    z[5,6,5]  R2319     -3.9061307907104492e-02
    z[5,6,5]  R2320     -2.4524421989917755e-01
    z[5,6,5]  R2321     -1.1231366544961929e-01
    z[5,6,5]  R2322     1.6097915172576904e-01
    z[5,6,5]  R2323     -8.4550447762012482e-02
    z[5,6,5]  R2324     -6.6976338624954224e-02
    z[5,6,5]  R2325     -1.4751136302947998e-01
    z[5,6,5]  R2326     2.2243642807006836e-01
    z[5,6,5]  R2327     -2.1594022214412689e-01
    z[5,6,5]  R2328     9.0554483234882355e-02
    z[5,6,5]  R2329     3.4834283590316772e-01
    z[5,6,5]  R2330     4.0248975157737732e-02
    z[5,6,5]  R2331     -1.4654375612735748e-02
    z[5,6,5]  R2332     1.6400316357612610e-01
    z[5,6,5]  R2333     -2.3947756737470627e-02
    z[5,6,5]  R2334     6.5748989582061768e-02
    z[5,6,5]  R2335     5.3899574279785156e-01
    z[5,6,5]  R2336     1.7916370928287506e-01
    z[5,6,5]  R2337     7.7944636344909668e-01
    z[5,6,5]  R2338     3.2812169194221497e-01
    z[5,6,5]  R2339     -2.5396534800529480e-01
    z[5,6,5]  R2340     -1.5706744790077209e-01
    z[5,6,5]  R2341     -7.3487579822540283e-02
    z[5,6,5]  R2342     3.1989347189664841e-02
    z[5,6,5]  R2343     -2.9093673825263977e-01
    z[5,6,5]  R2344     -1.1443016678094864e-01
    z[5,6,5]  R2345     -4.5611268281936646e-01
    z[5,6,5]  R2346     -3.9596292376518250e-01
    z[5,6,5]  R2347     3.6357650160789490e-01
    z[5,6,5]  R2348     -2.4460119009017944e-01
    z[5,6,5]  R2349     -2.2914563119411469e-01
    z[5,6,5]  R2350     -1.7768631875514984e-01
    z[5,6,5]  R2351     -1.5092007815837860e-01
    z[5,6,5]  R2352     4.6170303225517273e-01
    z[5,6,5]  R2353     1.8440628051757812e-01
    z[5,6,5]  R2354     2.1487553417682648e-01
    z[5,6,5]  R2355     1.4064885675907135e-01
    z[5,6,5]  R2356     7.8019447624683380e-02
    z[5,6,5]  R2357     -9.2405569553375244e-01
    z[5,6,5]  R2358     1.0758799314498901e-01
    z[5,6,5]  R2359     2.9926860332489014e-01
    z[5,6,5]  R2360     -5.7398641109466553e-01
    z[5,6,5]  R2361     -7.5456231832504272e-01
    z[5,6,5]  R2362     -8.5650849342346191e-01
    z[5,6,5]  R2363     -4.2700063437223434e-02
    z[5,6,5]  R2364     -1.5010915696620941e-01
    z[5,6,5]  R2365     3.0066564679145813e-01
    z[5,6,5]  R2366     -5.5725187063217163e-01
    z[5,6,5]  R2367     -6.9269603490829468e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2246     -1
    z[5,6,6]  R2247     1
    z[5,6,6]  R2248     -0.213245689868927
    z[5,6,6]  R2249     -1.1445382237434387e-01
    z[5,6,6]  R2250     3.0972677469253540e-01
    z[5,6,6]  R2251     -1.4680434763431549e-01
    z[5,6,6]  R2252     1.4119245111942291e-01
    z[5,6,6]  R2253     -2.9564124345779419e-01
    z[5,6,6]  R2254     3.4207320213317871e-01
    z[5,6,6]  R2255     -3.5359996557235718e-01
    z[5,6,6]  R2256     -2.0274966955184937e-01
    z[5,6,6]  R2257     1.9331571459770203e-01
    z[5,6,6]  R2258     -8.9825429022312164e-02
    z[5,6,6]  R2259     -9.0498877689242363e-03
    z[5,6,6]  R2260     1.7261378467082977e-01
    z[5,6,6]  R2261     3.6802750825881958e-01
    z[5,6,6]  R2262     1.0216881334781647e-01
    z[5,6,6]  R2263     2.8805169463157654e-01
    z[5,6,6]  R2264     2.0300626754760742e-02
    z[5,6,6]  R2265     3.7663422524929047e-02
    z[5,6,6]  R2266     2.2350224852561951e-01
    z[5,6,6]  R2267     1.3495652377605438e-01
    z[5,6,6]  R2268     -2.7111336588859558e-01
    z[5,6,6]  R2269     -1.2901568412780762e-01
    z[5,6,6]  R2270     -1.0398577898740768e-01
    z[5,6,6]  R2271     3.4599813818931580e-01
    z[5,6,6]  R2272     5.1238399744033813e-01
    z[5,6,6]  R2273     -2.1321910619735718e-01
    z[5,6,6]  R2274     1.7266513779759407e-02
    z[5,6,6]  R2275     -1.4194932579994202e-01
    z[5,6,6]  R2276     -2.7249327301979065e-01
    z[5,6,6]  R2277     2.1349404752254486e-01
    z[5,6,6]  R2278     -2.2075112909078598e-02
    z[5,6,6]  R2279     2.9936149716377258e-01
    z[5,6,6]  R2280     -3.5097181797027588e-02
    z[5,6,6]  R2281     6.6236026585102081e-02
    z[5,6,6]  R2282     -1.0731033980846405e-01
    z[5,6,6]  R2283     -5.0495218485593796e-02
    z[5,6,6]  R2284     -1.5178513526916504e-01
    z[5,6,6]  R2285     -3.4815138578414917e-01
    z[5,6,6]  R2286     4.1891507804393768e-02
    z[5,6,6]  R2287     1.3261966407299042e-01
    z[5,6,6]  R2288     7.9603493213653564e-02
    z[5,6,6]  R2289     -1.8367318809032440e-01
    z[5,6,6]  R2290     2.6043435931205750e-01
    z[5,6,6]  R2291     -7.9081624746322632e-02
    z[5,6,6]  R2292     -5.6449435651302338e-03
    z[5,6,6]  R2293     -2.0487642288208008e-01
    z[5,6,6]  R2294     9.3412511050701141e-03
    z[5,6,6]  R2295     2.2414916753768921e-01
    z[5,6,6]  R2296     -1.6394597291946411e-01
    z[5,6,6]  R2297     9.3698501586914062e-02
    z[5,6,6]  R2298     1.0346536524593830e-02
    z[5,6,6]  R2299     2.0242041349411011e-01
    z[5,6,6]  R2300     2.9542511701583862e-01
    z[5,6,6]  R2301     -0.0766846090555191
    z[5,6,6]  R2302     -1.4676292240619659e-01
    z[5,6,6]  R2303     6.8043315410614014e-01
    z[5,6,6]  R2304     -2.1194823086261749e-01
    z[5,6,6]  R2305     9.8082497715950012e-02
    z[5,6,6]  R2306     2.1409492194652557e-01
    z[5,6,6]  R2307     -2.5079679489135742e-01
    z[5,6,6]  R2308     -4.0954638272523880e-02
    z[5,6,6]  R2309     2.1268339827656746e-02
    z[5,6,6]  R2310     5.2315339446067810e-02
    z[5,6,6]  R2311     1.3736955821514130e-01
    z[5,6,6]  R2312     8.0335631966590881e-02
    z[5,6,6]  R2313     6.7857488989830017e-02
    z[5,6,6]  R2314     -4.8399096727371216e-01
    z[5,6,6]  R2315     -2.2590938210487366e-01
    z[5,6,6]  R2316     -4.9066364765167236e-01
    z[5,6,6]  R2317     -3.8394466042518616e-01
    z[5,6,6]  R2318     7.4578978121280670e-02
    z[5,6,6]  R2319     -1.4473941922187805e-01
    z[5,6,6]  R2320     2.3746220767498016e-01
    z[5,6,6]  R2321     3.3301338553428650e-01
    z[5,6,6]  R2322     -2.6124054193496704e-01
    z[5,6,6]  R2323     1.8263176083564758e-01
    z[5,6,6]  R2324     2.8792208433151245e-01
    z[5,6,6]  R2325     -2.5502455234527588e-01
    z[5,6,6]  R2326     -2.1545359492301941e-01
    z[5,6,6]  R2327     1.5662631392478943e-01
    z[5,6,6]  R2328     2.4414452910423279e-01
    z[5,6,6]  R2329     2.9341778159141541e-01
    z[5,6,6]  R2330     5.1917475461959839e-01
    z[5,6,6]  R2331     2.1874819695949554e-01
    z[5,6,6]  R2332     3.8928383588790894e-01
    z[5,6,6]  R2333     1.6137449443340302e-01
    z[5,6,6]  R2334     -4.5322526246309280e-02
    z[5,6,6]  R2335     -5.1023606210947037e-02
    z[5,6,6]  R2336     2.8241056948900223e-02
    z[5,6,6]  R2337     1.1728116311132908e-02
    z[5,6,6]  R2338     -2.7198362350463867e-01
    z[5,6,6]  R2339     5.1151126623153687e-01
    z[5,6,6]  R2340     3.8859617710113525e-01
    z[5,6,6]  R2341     -2.7948606014251709e-01
    z[5,6,6]  R2342     -3.1858119368553162e-01
    z[5,6,6]  R2343     1.7168654501438141e-01
    z[5,6,6]  R2344     -1.9448006525635719e-02
    z[5,6,6]  R2345     -0.180596262216568
    z[5,6,6]  R2346     -3.0839884281158447e-01
    z[5,6,6]  R2347     4.3326136469841003e-01
    z[5,6,6]  R2348     -2.0089246332645416e-02
    z[5,6,6]  R2349     2.4173586070537567e-01
    z[5,6,6]  R2350     -2.3494267463684082e-01
    z[5,6,6]  R2351     -1.1058136820793152e-01
    z[5,6,6]  R2352     -4.3667659163475037e-01
    z[5,6,6]  R2353     5.4727697372436523e-01
    z[5,6,6]  R2354     2.4932242929935455e-02
    z[5,6,6]  R2355     5.4051667451858521e-01
    z[5,6,6]  R2356     -1.3933502137660980e-01
    z[5,6,6]  R2357     -1.6211152076721191e-01
    z[5,6,6]  R2358     5.6706565618515015e-01
    z[5,6,6]  R2359     3.9679959416389465e-02
    z[5,6,6]  R2360     -2.1805323660373688e-01
    z[5,6,6]  R2361     2.0046980679035187e-01
    z[5,6,6]  R2362     4.9520316533744335e-03
    z[5,6,6]  R2363     -3.3127307891845703e-01
    z[5,6,6]  R2364     7.9868882894515991e-01
    z[5,6,6]  R2365     1.1968600749969482e-01
    z[5,6,6]  R2366     1.0809897631406784e-01
    z[5,6,6]  R2367     -1.2872619926929474e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2368     -1
    z[6,5,0]  R2369     1
    z[6,5,0]  R2382     -7.1324408054351807e-03
    z[6,5,0]  R2383     -0.609872043132782
    z[6,5,0]  R2384     -3.5625150799751282e-01
    z[6,5,0]  R2385     3.0565840005874634e-01
    z[6,5,0]  R2386     5.8468718081712723e-02
    z[6,5,0]  R2387     3.7295544147491455e-01
    z[6,5,0]  R2388     -4.7175645828247070e-02
    z[6,5,0]  R2389     -3.3855131268501282e-01
    z[6,5,0]  R2390     3.1291771680116653e-02
    z[6,5,0]  R2391     -2.0230922847986221e-02
    z[6,5,0]  R2392     1.5634299814701080e-01
    z[6,5,0]  R2393     3.0353438854217529e-01
    z[6,5,0]  R2394     -7.5079208612442017e-01
    z[6,5,0]  R2395     2.2267715632915497e-01
    z[6,5,0]  R2396     4.5826411247253418e-01
    z[6,5,0]  R2397     3.4416344761848450e-01
    z[6,5,0]  R2398     1.6742998361587524e-01
    z[6,5,0]  R2399     5.6998956203460693e-01
    z[6,5,0]  R2400     -7.1649444103240967e-01
    z[6,5,0]  R2401     -7.2960138320922852e-01
    z[6,5,0]  R2402     -3.8719708099961281e-03
    z[6,5,0]  R2403     0.377970814704895
    z[6,5,0]  R2404     3.6683431267738342e-01
    z[6,5,0]  R2405     5.4809135198593140e-01
    z[6,5,0]  R2406     3.9708280563354492e-01
    z[6,5,0]  R2407     2.5789085030555725e-01
    z[6,5,0]  R2408     6.8862646818161011e-01
    z[6,5,0]  R2409     -6.4441777765750885e-02
    z[6,5,0]  R2410     4.6054384112358093e-01
    z[6,5,0]  R2411     -1.5428721904754639e-01
    z[6,5,0]  R2412     -1.6341438889503479e-01
    z[6,5,0]  R2413     -3.2093605399131775e-01
    z[6,5,0]  R2414     -8.8356596231460571e-01
    z[6,5,0]  R2415     -1.7391633987426758e-01
    z[6,5,0]  R2416     -0.804546594619751
    z[6,5,0]  R2417     -8.6530953645706177e-01
    z[6,5,0]  R2418     6.3675379753112793e-01
    z[6,5,0]  R2419     -0.66482013463974
    z[6,5,0]  R2420     -6.4516210556030273e-01
    z[6,5,0]  R2421     -3.7745776772499084e-01
    z[6,5,0]  R2422     -2.4024908244609833e-01
    z[6,5,0]  R2423     -2.0745202898979187e-02
    z[6,5,0]  R2424     -3.7880662828683853e-02
    z[6,5,0]  R2425     -2.6529708504676819e-01
    z[6,5,0]  R2426     0.00278069986961782
    z[6,5,0]  R2427     -0.371847540140152
    z[6,5,0]  R2428     -8.7815326452255249e-01
    z[6,5,0]  R2429     -1.9606430083513260e-02
    z[6,5,0]  R2430     -1.5016080439090729e-01
    z[6,5,0]  R2431     2.2420510649681091e-01
    z[6,5,0]  R2432     -1.9836762547492981e-01
    z[6,5,0]  R2433     4.6706837415695190e-01
    z[6,5,0]  R2434     -1.8074283376336098e-02
    z[6,5,0]  R2435     1.8469411134719849e-01
    z[6,5,0]  R2436     -6.5395943820476532e-02
    z[6,5,0]  R2437     2.0739491283893585e-01
    z[6,5,0]  R2438     9.2153802514076233e-02
    z[6,5,0]  R2439     -3.3485004305839539e-01
    z[6,5,0]  R2440     5.7475157082080841e-02
    z[6,5,0]  R2441     8.2998253405094147e-02
    z[6,5,0]  R2442     -1.1327574402093887e-01
    z[6,5,0]  R2443     1.1821000277996063e-01
    z[6,5,0]  R2444     -3.5126686096191406e-01
    z[6,5,0]  R2445     2.0345158874988556e-01
    z[6,5,0]  R2446     1.5866951644420624e-01
    z[6,5,0]  R2447     1.4918965101242065e-01
    z[6,5,0]  R2448     1.4596323668956757e-01
    z[6,5,0]  R2449     -5.2205246686935425e-01
    z[6,5,0]  R2450     -4.4384837150573730e-01
    z[6,5,0]  R2451     -0.854417622089386
    z[6,5,0]  R2452     3.4748545289039612e-01
    z[6,5,0]  R2453     -1.2408905476331711e-01
    z[6,5,0]  R2454     1.9600579142570496e-01
    z[6,5,0]  R2455     1.4159527420997620e-01
    z[6,5,0]  R2456     0.352468878030777
    z[6,5,0]  R2457     2.5963535904884338e-01
    z[6,5,0]  R2458     1.6861203312873840e-01
    z[6,5,0]  R2459     1.5843059122562408e-01
    z[6,5,0]  R2460     1.5164570510387421e-01
    z[6,5,0]  R2461     1.8139271438121796e-01
    z[6,5,0]  R2462     1.8842476606369019e-01
    z[6,5,0]  R2463     -1.6518227756023407e-02
    z[6,5,0]  R2464     3.1579241156578064e-02
    z[6,5,0]  R2465     -3.2002660632133484e-01
    z[6,5,0]  R2466     -2.0104108750820160e-01
    z[6,5,0]  R2467     -2.2300831973552704e-01
    z[6,5,0]  R2468     5.1281917095184326e-01
    z[6,5,0]  R2469     2.4213770031929016e-01
    z[6,5,0]  R2470     1.4620113186538219e-02
    z[6,5,0]  R2471     2.5184684991836548e-01
    z[6,5,0]  R2472     -0.406929075717926
    z[6,5,0]  R2473     -2.2387205064296722e-01
    z[6,5,0]  R2474     3.8542559742927551e-01
    z[6,5,0]  R2475     -2.3967489600181580e-01
    z[6,5,0]  R2476     -2.3025350272655487e-01
    z[6,5,0]  R2477     -3.9414188265800476e-01
    z[6,5,0]  R2478     -7.0512875914573669e-02
    z[6,5,0]  R2479     4.3129718303680420e-01
    z[6,5,0]  R2480     -4.4638893008232117e-01
    z[6,5,0]  R2481     0.214206725358963
    z[6,5,0]  R2482     -2.7951663732528687e-01
    z[6,5,0]  R2483     6.2482478097081184e-03
    z[6,5,0]  R2484     -5.6338828802108765e-01
    z[6,5,0]  R2485     -2.9648989439010620e-01
    z[6,5,0]  R2486     -2.6210770010948181e-01
    z[6,5,0]  R2487     -0.746512770652771
    z[6,5,0]  R2488     -1.4326098561286926e-01
    z[6,5,0]  R2489     -8.8023543357849121e-03
    z[6,5,0]  R2490     6.6120497882366180e-02
    z[6,5,0]  R2491     2.4554353952407837e-01
    z[6,5,0]  R2492     -5.1022070646286011e-01
    z[6,5,0]  R2493     -7.1848720312118530e-01
    z[6,5,0]  R2494     2.2021791338920593e-01
    z[6,5,0]  R2495     0.188834086060524
    z[6,5,0]  R2496     4.7437706589698792e-01
    z[6,5,0]  R2497     4.6587541699409485e-01
    z[6,5,0]  R2498     7.2910927236080170e-02
    z[6,5,0]  R2499     7.2841948270797729e-01
    z[6,5,0]  R2500     3.0446156859397888e-01
    z[6,5,0]  R2501     5.4198443889617920e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2370     -1
    z[6,5,1]  R2371     1
    z[6,5,1]  R2382     1.1356388777494431e-01
    z[6,5,1]  R2383     -4.9036312103271484e-01
    z[6,5,1]  R2384     -0.268771767616272
    z[6,5,1]  R2385     -1.7898106575012207e-01
    z[6,5,1]  R2386     1.5737524256110191e-02
    z[6,5,1]  R2387     9.0887606143951416e-02
    z[6,5,1]  R2388     -4.1235667467117310e-01
    z[6,5,1]  R2389     1.8914127349853516e-01
    z[6,5,1]  R2390     -3.6051037907600403e-01
    z[6,5,1]  R2391     -4.4455164670944214e-01
    z[6,5,1]  R2392     5.7409924268722534e-01
    z[6,5,1]  R2393     0.521532416343689
    z[6,5,1]  R2394     4.0930244326591492e-01
    z[6,5,1]  R2395     5.2007561922073364e-01
    z[6,5,1]  R2396     6.0095995664596558e-01
    z[6,5,1]  R2397     4.5345729589462280e-01
    z[6,5,1]  R2398     5.4914832115173340e-01
    z[6,5,1]  R2399     5.0805473327636719e-01
    z[6,5,1]  R2400     5.8904081583023071e-01
    z[6,5,1]  R2401     2.8098881244659424e-01
    z[6,5,1]  R2402     -8.2848638296127319e-01
    z[6,5,1]  R2403     -6.1497098207473755e-01
    z[6,5,1]  R2404     -5.0910407304763794e-01
    z[6,5,1]  R2405     -6.8660420179367065e-01
    z[6,5,1]  R2406     -0.74765944480896
    z[6,5,1]  R2407     -7.9350328445434570e-01
    z[6,5,1]  R2408     -3.7632763385772705e-01
    z[6,5,1]  R2409     -5.1575195789337158e-01
    z[6,5,1]  R2410     -6.1419796943664551e-01
    z[6,5,1]  R2411     -3.1984734535217285e-01
    z[6,5,1]  R2412     -2.7069896459579468e-01
    z[6,5,1]  R2413     -4.9074128270149231e-01
    z[6,5,1]  R2414     8.4123871056362987e-04
    z[6,5,1]  R2415     -5.9279185533523560e-01
    z[6,5,1]  R2416     3.5964214801788330e-01
    z[6,5,1]  R2417     1.4193475246429443e-01
    z[6,5,1]  R2418     -6.0124039649963379e-01
    z[6,5,1]  R2419     0.0818859413266182
    z[6,5,1]  R2420     -5.1137939095497131e-02
    z[6,5,1]  R2421     -5.5152320861816406e-01
    z[6,5,1]  R2422     -6.5132069587707520e-01
    z[6,5,1]  R2423     -6.1464887857437134e-01
    z[6,5,1]  R2424     -2.9878202080726624e-01
    z[6,5,1]  R2425     -3.0940631031990051e-01
    z[6,5,1]  R2426     -3.6072564125061035e-01
    z[6,5,1]  R2427     -0.62802654504776
    z[6,5,1]  R2428     2.0927037298679352e-01
    z[6,5,1]  R2429     -6.8977546691894531e-01
    z[6,5,1]  R2430     -6.4189249277114868e-01
    z[6,5,1]  R2431     2.0453146100044250e-01
    z[6,5,1]  R2432     -6.6997438669204712e-01
    z[6,5,1]  R2433     -3.8101676106452942e-01
    z[6,5,1]  R2434     0.609222948551178
    z[6,5,1]  R2435     6.8127177655696869e-02
    z[6,5,1]  R2436     2.0265281200408936e-01
    z[6,5,1]  R2437     4.5337605476379395e-01
    z[6,5,1]  R2438     2.0321825146675110e-01
    z[6,5,1]  R2439     -5.7266287505626678e-02
    z[6,5,1]  R2440     1.5035147964954376e-01
    z[6,5,1]  R2441     -1.6053926199674606e-02
    z[6,5,1]  R2442     9.0267688035964966e-01
    z[6,5,1]  R2443     8.7850195169448853e-01
    z[6,5,1]  R2444     8.0297881364822388e-01
    z[6,5,1]  R2445     8.2115840911865234e-01
    z[6,5,1]  R2446     -4.2180785536766052e-01
    z[6,5,1]  R2447     7.3890346288681030e-01
    z[6,5,1]  R2448     0.775105357170105
    z[6,5,1]  R2449     -6.7736494541168213e-01
    z[6,5,1]  R2450     -3.3908748626708984e-01
    z[6,5,1]  R2451     -4.1606849431991577e-01
    z[6,5,1]  R2452     -7.6730751991271973e-01
    z[6,5,1]  R2453     -7.0995074510574341e-01
    z[6,5,1]  R2454     -6.6837781667709351e-01
    z[6,5,1]  R2455     -6.6868335008621216e-01
    z[6,5,1]  R2456     -6.8870180845260620e-01
    z[6,5,1]  R2457     -0.689148485660553
    z[6,5,1]  R2458     -0.724707841873169
    z[6,5,1]  R2459     -6.5316039323806763e-01
    z[6,5,1]  R2460     -6.6812676191329956e-01
    z[6,5,1]  R2461     -5.3825861215591431e-01
    z[6,5,1]  R2462     -8.6119043827056885e-01
    z[6,5,1]  R2463     -7.1934396028518677e-01
    z[6,5,1]  R2464     -6.6734534502029419e-01
    z[6,5,1]  R2465     -3.2121309638023376e-01
    z[6,5,1]  R2466     -3.4441930055618286e-01
    z[6,5,1]  R2467     -7.9870028421282768e-03
    z[6,5,1]  R2468     7.0969969034194946e-01
    z[6,5,1]  R2469     -3.8341563940048218e-01
    z[6,5,1]  R2470     8.0171310901641846e-01
    z[6,5,1]  R2471     6.8133169412612915e-01
    z[6,5,1]  R2472     -8.1819391250610352e-01
    z[6,5,1]  R2473     -8.3834046125411987e-01
    z[6,5,1]  R2474     8.9345055818557739e-01
    z[6,5,1]  R2475     8.7546640634536743e-01
    z[6,5,1]  R2476     -5.0110530853271484e-01
    z[6,5,1]  R2477     -5.1602822542190552e-01
    z[6,5,1]  R2478     -3.5946887731552124e-01
    z[6,5,1]  R2479     -3.1774255633354187e-01
    z[6,5,1]  R2480     -2.0169923081994057e-02
    z[6,5,1]  R2481     6.5325963497161865e-01
    z[6,5,1]  R2482     -5.1344031095504761e-01
    z[6,5,1]  R2483     7.9660427570343018e-01
    z[6,5,1]  R2484     -3.0994272232055664e-01
    z[6,5,1]  R2485     7.2402888536453247e-01
    z[6,5,1]  R2486     -5.4558837413787842e-01
    z[6,5,1]  R2487     -3.2240059226751328e-02
    z[6,5,1]  R2488     0.500961422920227
    z[6,5,1]  R2489     0.430346816778183
    z[6,5,1]  R2490     -5.9856027364730835e-01
    z[6,5,1]  R2491     -8.0516338348388672e-02
    z[6,5,1]  R2492     7.1003675460815430e-01
    z[6,5,1]  R2493     -2.7539357542991638e-01
    z[6,5,1]  R2494     -7.8431165218353271e-01
    z[6,5,1]  R2495     6.0737508535385132e-01
    z[6,5,1]  R2496     -2.3485994338989258e-01
    z[6,5,1]  R2497     -3.7489861249923706e-01
    z[6,5,1]  R2498     -4.6983989886939526e-04
    z[6,5,1]  R2499     -2.7126595377922058e-01
    z[6,5,1]  R2500     -0.0902019739151001
    z[6,5,1]  R2501     -9.1256782412528992e-02
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2372     -1
    z[6,5,2]  R2373     1
    z[6,5,2]  R2382     -6.6207003593444824e-01
    z[6,5,2]  R2383     -5.6170988082885742e-01
    z[6,5,2]  R2384     -4.9344068765640259e-01
    z[6,5,2]  R2385     -7.3885542154312134e-01
    z[6,5,2]  R2386     -5.0496435165405273e-01
    z[6,5,2]  R2387     -3.2723531126976013e-01
    z[6,5,2]  R2388     -6.5867567062377930e-01
    z[6,5,2]  R2389     -4.8692572116851807e-01
    z[6,5,2]  R2390     -5.9139841794967651e-01
    z[6,5,2]  R2391     -5.0206708908081055e-01
    z[6,5,2]  R2392     7.6512783765792847e-01
    z[6,5,2]  R2393     6.8397843837738037e-01
    z[6,5,2]  R2394     3.6982640624046326e-01
    z[6,5,2]  R2395     7.0460414886474609e-01
    z[6,5,2]  R2396     0.552261471748352
    z[6,5,2]  R2397     6.2330263853073120e-01
    z[6,5,2]  R2398     6.0658687353134155e-01
    z[6,5,2]  R2399     5.6052255630493164e-01
    z[6,5,2]  R2400     1.9127818942070007e-01
    z[6,5,2]  R2401     4.7686657309532166e-01
    z[6,5,2]  R2402     -2.2575299441814423e-01
    z[6,5,2]  R2403     -4.3765774369239807e-01
    z[6,5,2]  R2404     -3.4211507439613342e-01
    z[6,5,2]  R2405     -4.0068873763084412e-01
    z[6,5,2]  R2406     -1.5267378091812134e-01
    z[6,5,2]  R2407     -3.5434699058532715e-01
    z[6,5,2]  R2408     -3.5900583863258362e-01
    z[6,5,2]  R2409     -1.2537996470928192e-01
    z[6,5,2]  R2410     -1.0073851794004440e-01
    z[6,5,2]  R2411     -3.6328250169754028e-01
    z[6,5,2]  R2412     -5.9387695789337158e-01
    z[6,5,2]  R2413     -3.5038021206855774e-01
    z[6,5,2]  R2414     -9.6438162028789520e-02
    z[6,5,2]  R2415     -4.6328902244567871e-01
    z[6,5,2]  R2416     -2.7555164694786072e-01
    z[6,5,2]  R2417     1.7317138612270355e-01
    z[6,5,2]  R2418     -3.0879771709442139e-01
    z[6,5,2]  R2419     -4.7949111461639404e-01
    z[6,5,2]  R2420     -4.8743149638175964e-01
    z[6,5,2]  R2421     2.0412076264619827e-02
    z[6,5,2]  R2422     -0.616512656211853
    z[6,5,2]  R2423     -5.6968605518341064e-01
    z[6,5,2]  R2424     -5.5516713857650757e-01
    z[6,5,2]  R2425     -5.1011794805526733e-01
    z[6,5,2]  R2426     -6.2455916404724121e-01
    z[6,5,2]  R2427     -2.4228592216968536e-01
    z[6,5,2]  R2428     2.3195035755634308e-01
    z[6,5,2]  R2429     -3.4269922971725464e-01
    z[6,5,2]  R2430     -4.9695184826850891e-01
    z[6,5,2]  R2431     1.2902058660984039e-01
    z[6,5,2]  R2432     -2.7538421750068665e-01
    z[6,5,2]  R2433     -2.1320012211799622e-01
    z[6,5,2]  R2434     4.7804632782936096e-01
    z[6,5,2]  R2435     5.1289552450180054e-01
    z[6,5,2]  R2436     4.1988608241081238e-01
    z[6,5,2]  R2437     -1.2099956721067429e-01
    z[6,5,2]  R2438     -4.5156544446945190e-01
    z[6,5,2]  R2439     -6.2282466888427734e-01
    z[6,5,2]  R2440     2.7554255723953247e-01
    z[6,5,2]  R2441     3.4326678514480591e-01
    z[6,5,2]  R2442     -2.2743935883045197e-01
    z[6,5,2]  R2443     -1.9896794855594635e-01
    z[6,5,2]  R2444     2.6907011866569519e-01
    z[6,5,2]  R2445     -7.0819951593875885e-02
    z[6,5,2]  R2446     -0.866377055644989
    z[6,5,2]  R2447     0.3300761282444
    z[6,5,2]  R2448     -2.3459206521511078e-01
    z[6,5,2]  R2449     -2.7051535248756409e-01
    z[6,5,2]  R2450     -7.5094038248062134e-01
    z[6,5,2]  R2451     -1.8892247974872589e-01
    z[6,5,2]  R2452     -6.9927543401718140e-02
    z[6,5,2]  R2453     4.7661286592483521e-01
    z[6,5,2]  R2454     3.4003669023513794e-01
    z[6,5,2]  R2455     9.9839836359024048e-02
    z[6,5,2]  R2456     2.5200808048248291e-01
    z[6,5,2]  R2457     2.2952046990394592e-01
    z[6,5,2]  R2458     4.0556395053863525e-01
    z[6,5,2]  R2459     4.4633349776268005e-01
    z[6,5,2]  R2460     3.1033965945243835e-01
    z[6,5,2]  R2461     0.05144052952528
    z[6,5,2]  R2462     -2.4051231145858765e-01
    z[6,5,2]  R2463     -1.4661246538162231e-01
    z[6,5,2]  R2464     4.6668898314237595e-02
    z[6,5,2]  R2465     -4.7202974557876587e-01
    z[6,5,2]  R2466     -5.4179519414901733e-01
    z[6,5,2]  R2467     -4.4095999002456665e-01
    z[6,5,2]  R2468     3.7452599406242371e-01
    z[6,5,2]  R2469     -4.8140594363212585e-01
    z[6,5,2]  R2470     0.00958534050732851
    z[6,5,2]  R2471     5.9043139219284058e-01
    z[6,5,2]  R2472     -2.9375061858445406e-03
    z[6,5,2]  R2473     5.9286791831254959e-02
    z[6,5,2]  R2474     1.3947954773902893e-01
    z[6,5,2]  R2475     -8.9126199483871460e-02
    z[6,5,2]  R2476     -4.3336143717169762e-03
    z[6,5,2]  R2477     -1.2201385945081711e-01
    z[6,5,2]  R2478     -3.6684155464172363e-01
    z[6,5,2]  R2479     -4.4460549950599670e-01
    z[6,5,2]  R2480     -4.5316964387893677e-01
    z[6,5,2]  R2481     0.624812662601471
    z[6,5,2]  R2482     -2.8168469667434692e-01
    z[6,5,2]  R2483     -2.1682465448975563e-02
    z[6,5,2]  R2484     -2.8477707505226135e-01
    z[6,5,2]  R2485     -6.5252050757408142e-02
    z[6,5,2]  R2486     -6.0091644525527954e-01
    z[6,5,2]  R2487     -3.7112745642662048e-01
    z[6,5,2]  R2488     6.2278604507446289e-01
    z[6,5,2]  R2489     0.732809841632843
    z[6,5,2]  R2490     -3.1777489185333252e-01
    z[6,5,2]  R2491     1.8926402926445007e-01
    z[6,5,2]  R2492     2.5441799312829971e-02
    z[6,5,2]  R2493     -3.5456672310829163e-01
    z[6,5,2]  R2494     -3.9431047439575195e-01
    z[6,5,2]  R2495     5.3239309787750244e-01
    z[6,5,2]  R2496     -3.5722586512565613e-01
    z[6,5,2]  R2497     -1.5683230757713318e-01
    z[6,5,2]  R2498     1.3258498907089233e-01
    z[6,5,2]  R2499     -1.2050031125545502e-01
    z[6,5,2]  R2500     -1.5476141870021820e-01
    z[6,5,2]  R2501     7.6779276132583618e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2374     -1
    z[6,5,3]  R2375     1
    z[6,5,3]  R2382     7.0285123586654663e-01
    z[6,5,3]  R2383     -1.7225007712841034e-01
    z[6,5,3]  R2384     4.4561344385147095e-01
    z[6,5,3]  R2385     3.9838501811027527e-01
    z[6,5,3]  R2386     3.7805780768394470e-01
    z[6,5,3]  R2387     6.2986296415328979e-01
    z[6,5,3]  R2388     -1.2511213123798370e-01
    z[6,5,3]  R2389     0.42557492852211
    z[6,5,3]  R2390     -1.0559994727373123e-01
    z[6,5,3]  R2391     2.1751316264271736e-02
    z[6,5,3]  R2392     1.7642891407012939e-01
    z[6,5,3]  R2393     2.7874562144279480e-01
    z[6,5,3]  R2394     1.1768934130668640e-01
    z[6,5,3]  R2395     0.139877051115036
    z[6,5,3]  R2396     1.7006102204322815e-01
    z[6,5,3]  R2397     4.9650269746780396e-01
    z[6,5,3]  R2398     4.2137256264686584e-01
    z[6,5,3]  R2399     1.0021498799324036e-01
    z[6,5,3]  R2400     5.2976712584495544e-02
    z[6,5,3]  R2401     2.5871220976114273e-02
    z[6,5,3]  R2402     -4.0048643946647644e-01
    z[6,5,3]  R2403     -2.1492913365364075e-01
    z[6,5,3]  R2404     -1.8450836837291718e-01
    z[6,5,3]  R2405     1.2105809897184372e-01
    z[6,5,3]  R2406     -1.1410713195800781e-01
    z[6,5,3]  R2407     2.2164495661854744e-02
    z[6,5,3]  R2408     -4.1962409019470215e-01
    z[6,5,3]  R2409     -4.3861925601959229e-01
    z[6,5,3]  R2410     -5.0154322385787964e-01
    z[6,5,3]  R2411     -3.6153492331504822e-01
    z[6,5,3]  R2412     -5.6492835283279419e-01
    z[6,5,3]  R2413     -0.350996732711792
    z[6,5,3]  R2414     7.1377992630004883e-02
    z[6,5,3]  R2415     -3.6774033308029175e-01
    z[6,5,3]  R2416     1.1131998151540756e-01
    z[6,5,3]  R2417     -2.9271697998046875e-01
    z[6,5,3]  R2418     -3.3724820613861084e-01
    z[6,5,3]  R2419     1.0116033256053925e-01
    z[6,5,3]  R2420     2.8972604870796204e-01
    z[6,5,3]  R2421     -2.9796159267425537e-01
    z[6,5,3]  R2422     -2.4730089306831360e-01
    z[6,5,3]  R2423     -3.6283436417579651e-01
    z[6,5,3]  R2424     -6.5098208189010620e-01
    z[6,5,3]  R2425     -6.8950426578521729e-01
    z[6,5,3]  R2426     -2.6326560974121094e-01
    z[6,5,3]  R2427     -2.6847904920578003e-01
    z[6,5,3]  R2428     -1.8104347586631775e-01
    z[6,5,3]  R2429     2.9219800233840942e-01
    z[6,5,3]  R2430     5.3422415256500244e-01
    z[6,5,3]  R2431     9.3962311744689941e-02
    z[6,5,3]  R2432     -3.1924274563789368e-01
    z[6,5,3]  R2433     -6.8487578630447388e-01
    z[6,5,3]  R2434     -1.2396093457937241e-01
    z[6,5,3]  R2435     1.1860295385122299e-01
    z[6,5,3]  R2436     -3.6851714830845594e-03
    z[6,5,3]  R2437     3.0113914608955383e-01
    z[6,5,3]  R2438     2.2926524281501770e-01
    z[6,5,3]  R2439     2.7679237723350525e-01
    z[6,5,3]  R2440     -5.6929498910903931e-01
    z[6,5,3]  R2441     -5.3526127338409424e-01
    z[6,5,3]  R2442     2.0366741716861725e-01
    z[6,5,3]  R2443     -8.0570735037326813e-02
    z[6,5,3]  R2444     -8.3505190908908844e-02
    z[6,5,3]  R2445     8.0725461244583130e-02
    z[6,5,3]  R2446     -7.2167336940765381e-02
    z[6,5,3]  R2447     -2.2841072082519531e-01
    z[6,5,3]  R2448     4.0657523274421692e-01
    z[6,5,3]  R2449     -0.263260155916214
    z[6,5,3]  R2450     0.166749507188797
    z[6,5,3]  R2451     -1.0699054598808289e-01
    z[6,5,3]  R2452     4.3049424886703491e-01
    z[6,5,3]  R2453     4.2185938358306885e-01
    z[6,5,3]  R2454     5.9203559160232544e-01
    z[6,5,3]  R2455     6.1240088939666748e-01
    z[6,5,3]  R2456     5.3675752878189087e-01
    z[6,5,3]  R2457     5.6509578227996826e-01
    z[6,5,3]  R2458     4.6101042628288269e-01
    z[6,5,3]  R2459     5.4883146286010742e-01
    z[6,5,3]  R2460     3.9355498552322388e-01
    z[6,5,3]  R2461     4.2227292060852051e-01
    z[6,5,3]  R2462     2.5027993321418762e-01
    z[6,5,3]  R2463     5.1352363824844360e-01
    z[6,5,3]  R2464     5.5233132839202881e-01
    z[6,5,3]  R2465     1.2936948239803314e-01
    z[6,5,3]  R2466     4.5526260137557983e-01
    z[6,5,3]  R2467     -6.4852249622344971e-01
    z[6,5,3]  R2468     -6.5455652773380280e-02
    z[6,5,3]  R2469     -7.6473824679851532e-02
    z[6,5,3]  R2470     -3.1890928745269775e-01
    z[6,5,3]  R2471     -2.4057717621326447e-01
    z[6,5,3]  R2472     3.1125918030738831e-01
    z[6,5,3]  R2473     1.9973684847354889e-01
    z[6,5,3]  R2474     -3.6254484206438065e-02
    z[6,5,3]  R2475     5.7488363236188889e-02
    z[6,5,3]  R2476     6.2126670032739639e-02
    z[6,5,3]  R2477     2.3014867305755615e-01
    z[6,5,3]  R2478     -2.5437323376536369e-02
    z[6,5,3]  R2479     -5.4442435503005981e-01
    z[6,5,3]  R2480     -1.4999739825725555e-01
    z[6,5,3]  R2481     -3.1958681344985962e-01
    z[6,5,3]  R2482     2.1795186400413513e-01
    z[6,5,3]  R2483     -1.7320780456066132e-01
    z[6,5,3]  R2484     3.2342472672462463e-01
    z[6,5,3]  R2485     -3.4075376391410828e-01
    z[6,5,3]  R2486     -2.6483917608857155e-02
    z[6,5,3]  R2487     -4.7934178262948990e-02
    z[6,5,3]  R2488     1.0756554454565048e-01
    z[6,5,3]  R2489     2.1706764400005341e-01
    z[6,5,3]  R2490     3.6363206803798676e-02
    z[6,5,3]  R2491     -0.61332768201828
    z[6,5,3]  R2492     -2.5294670462608337e-01
    z[6,5,3]  R2493     2.6586598157882690e-01
    z[6,5,3]  R2494     2.7846372127532959e-01
    z[6,5,3]  R2495     5.0934362411499023e-01
    z[6,5,3]  R2496     -6.7820960283279419e-01
    z[6,5,3]  R2497     -3.7399837374687195e-01
    z[6,5,3]  R2498     -5.4185372591018677e-01
    z[6,5,3]  R2499     5.3974837064743042e-01
    z[6,5,3]  R2500     -4.6572342514991760e-01
    z[6,5,3]  R2501     -1.0125853121280670e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2376     -1
    z[6,5,4]  R2377     1
    z[6,5,4]  R2382     7.3707611300051212e-03
    z[6,5,4]  R2383     -1.1025711894035339e-01
    z[6,5,4]  R2384     2.2705543041229248e-01
    z[6,5,4]  R2385     1.8147720396518707e-01
    z[6,5,4]  R2386     3.1352239847183228e-01
    z[6,5,4]  R2387     3.4658116102218628e-01
    z[6,5,4]  R2388     -2.7731582522392273e-01
    z[6,5,4]  R2389     2.6809543371200562e-01
    z[6,5,4]  R2390     -1.9075492024421692e-01
    z[6,5,4]  R2391     -5.3753042221069336e-01
    z[6,5,4]  R2392     9.7786642611026764e-02
    z[6,5,4]  R2393     2.6051837205886841e-01
    z[6,5,4]  R2394     -4.0340710431337357e-02
    z[6,5,4]  R2395     -2.0097592473030090e-01
    z[6,5,4]  R2396     2.7689328417181969e-02
    z[6,5,4]  R2397     2.0092625170946121e-02
    z[6,5,4]  R2398     -1.9369050860404968e-01
    z[6,5,4]  R2399     0.0772441104054451
    z[6,5,4]  R2400     -6.6140934824943542e-02
    z[6,5,4]  R2401     2.9915568232536316e-01
    z[6,5,4]  R2402     1.8556652963161469e-01
    z[6,5,4]  R2403     -1.8377484381198883e-01
    z[6,5,4]  R2404     -4.2894887924194336e-01
    z[6,5,4]  R2405     6.9989293813705444e-02
    z[6,5,4]  R2406     2.6184371113777161e-01
    z[6,5,4]  R2407     3.8881441950798035e-01
    z[6,5,4]  R2408     -2.6986005902290344e-01
    z[6,5,4]  R2409     0.478142648935318
    z[6,5,4]  R2410     3.4068933129310608e-01
    z[6,5,4]  R2411     -5.9474412351846695e-02
    z[6,5,4]  R2412     -2.1574285626411438e-01
    z[6,5,4]  R2413     -2.8994113206863403e-01
    z[6,5,4]  R2414     -1.7099156975746155e-01
    z[6,5,4]  R2415     4.3007937073707581e-01
    z[6,5,4]  R2416     -1.8034437298774719e-01
    z[6,5,4]  R2417     3.6082316190004349e-02
    z[6,5,4]  R2418     1.0241910815238953e-01
    z[6,5,4]  R2419     -2.6553717255592346e-01
    z[6,5,4]  R2420     8.7884448468685150e-02
    z[6,5,4]  R2421     3.7979838252067566e-01
    z[6,5,4]  R2422     1.2877424061298370e-01
    z[6,5,4]  R2423     -2.3375539481639862e-01
    z[6,5,4]  R2424     -3.0089142918586731e-01
    z[6,5,4]  R2425     -2.5148290395736694e-01
    z[6,5,4]  R2426     8.1425786018371582e-02
    z[6,5,4]  R2427     5.4870493710041046e-02
    z[6,5,4]  R2428     2.2733654081821442e-01
    z[6,5,4]  R2429     9.5197439193725586e-02
    z[6,5,4]  R2430     -8.6993388831615448e-02
    z[6,5,4]  R2431     -4.7589138150215149e-02
    z[6,5,4]  R2432     -2.9893046244978905e-02
    z[6,5,4]  R2433     -1.7614772915840149e-01
    z[6,5,4]  R2434     -8.7283954024314880e-02
    z[6,5,4]  R2435     2.7306738495826721e-01
    z[6,5,4]  R2436     2.1143786609172821e-01
    z[6,5,4]  R2437     7.3112696409225464e-01
    z[6,5,4]  R2438     1.8248160183429718e-01
    z[6,5,4]  R2439     -5.6155747175216675e-01
    z[6,5,4]  R2440     -5.0185203552246094e-01
    z[6,5,4]  R2441     -3.0351039767265320e-01
    z[6,5,4]  R2442     1.7936299741268158e-01
    z[6,5,4]  R2443     -3.8924279808998108e-01
    z[6,5,4]  R2444     -2.1627798676490784e-01
    z[6,5,4]  R2445     5.2010279148817062e-02
    z[6,5,4]  R2446     -1.1546332389116287e-01
    z[6,5,4]  R2447     8.3594217896461487e-02
    z[6,5,4]  R2448     -1.9497834146022797e-01
    z[6,5,4]  R2449     -1.6167469322681427e-02
    z[6,5,4]  R2450     2.3384955525398254e-01
    z[6,5,4]  R2451     -5.3835760802030563e-02
    z[6,5,4]  R2452     -2.2014346718788147e-01
    z[6,5,4]  R2453     -4.5374695211648941e-02
    z[6,5,4]  R2454     3.4137617796659470e-02
    z[6,5,4]  R2455     -3.1233888119459152e-02
    z[6,5,4]  R2456     6.6238231956958771e-02
    z[6,5,4]  R2457     2.9615478590130806e-02
    z[6,5,4]  R2458     2.5716400146484375e-01
    z[6,5,4]  R2459     -1.7625771462917328e-01
    z[6,5,4]  R2460     -4.7561034560203552e-01
    z[6,5,4]  R2461     -1.9259326159954071e-01
    z[6,5,4]  R2462     -2.0585859194397926e-02
    z[6,5,4]  R2463     0.266190767288208
    z[6,5,4]  R2464     4.8363244533538818e-01
    z[6,5,4]  R2465     -4.9662560224533081e-01
    z[6,5,4]  R2466     -2.7106830477714539e-01
    z[6,5,4]  R2467     -5.3728890419006348e-01
    z[6,5,4]  R2468     -6.1553839594125748e-02
    z[6,5,4]  R2469     -0.562829852104187
    z[6,5,4]  R2470     7.7291913330554962e-02
    z[6,5,4]  R2471     -1.1433874815702438e-01
    z[6,5,4]  R2472     2.5169411301612854e-01
    z[6,5,4]  R2473     -3.1164211034774780e-01
    z[6,5,4]  R2474     1.7597810924053192e-01
    z[6,5,4]  R2475     3.6798211932182312e-01
    z[6,5,4]  R2476     -0.179236501455307
    z[6,5,4]  R2477     2.1292287856340408e-02
    z[6,5,4]  R2478     -3.7797105312347412e-01
    z[6,5,4]  R2479     3.0390709638595581e-01
    z[6,5,4]  R2480     -3.8187372684478760e-01
    z[6,5,4]  R2481     -9.3844980001449585e-02
    z[6,5,4]  R2482     -0.236972376704216
    z[6,5,4]  R2483     9.4497419893741608e-02
    z[6,5,4]  R2484     -3.8247920572757721e-02
    z[6,5,4]  R2485     2.7009603381156921e-01
    z[6,5,4]  R2486     -4.2381209135055542e-01
    z[6,5,4]  R2487     2.4931342899799347e-01
    z[6,5,4]  R2488     5.3998857736587524e-01
    z[6,5,4]  R2489     4.0488681197166443e-01
    z[6,5,4]  R2490     8.3670176565647125e-02
    z[6,5,4]  R2491     -4.5888268947601318e-01
    z[6,5,4]  R2492     -4.6604439616203308e-02
    z[6,5,4]  R2493     3.2704961299896240e-01
    z[6,5,4]  R2494     7.0567227900028229e-02
    z[6,5,4]  R2495     6.8108029663562775e-02
    z[6,5,4]  R2496     -3.2181560993194580e-01
    z[6,5,4]  R2497     1.1002613604068756e-01
    z[6,5,4]  R2498     -2.1122857928276062e-01
    z[6,5,4]  R2499     5.9931587427854538e-02
    z[6,5,4]  R2500     3.5749897360801697e-01
    z[6,5,4]  R2501     3.9830144494771957e-02
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2378     -1
    z[6,5,5]  R2379     1
    z[6,5,5]  R2382     2.3018307983875275e-01
    z[6,5,5]  R2383     1.7263543605804443e-01
    z[6,5,5]  R2384     5.5181562900543213e-01
    z[6,5,5]  R2385     3.4368079900741577e-01
    z[6,5,5]  R2386     7.0261436700820923e-01
    z[6,5,5]  R2387     4.7340282797813416e-01
    z[6,5,5]  R2388     -2.5899496674537659e-01
    z[6,5,5]  R2389     5.5541670322418213e-01
    z[6,5,5]  R2390     4.8063647747039795e-01
    z[6,5,5]  R2391     3.3625525236129761e-01
    z[6,5,5]  R2392     1.1956129968166351e-01
    z[6,5,5]  R2393     -3.9061307907104492e-02
    z[6,5,5]  R2394     -2.4524421989917755e-01
    z[6,5,5]  R2395     -1.1231366544961929e-01
    z[6,5,5]  R2396     1.6097915172576904e-01
    z[6,5,5]  R2397     -8.4550447762012482e-02
    z[6,5,5]  R2398     -6.6976338624954224e-02
    z[6,5,5]  R2399     -1.4751136302947998e-01
    z[6,5,5]  R2400     2.2243642807006836e-01
    z[6,5,5]  R2401     -2.1594022214412689e-01
    z[6,5,5]  R2402     9.0554483234882355e-02
    z[6,5,5]  R2403     3.4834283590316772e-01
    z[6,5,5]  R2404     4.0248975157737732e-02
    z[6,5,5]  R2405     -1.4654375612735748e-02
    z[6,5,5]  R2406     1.6400316357612610e-01
    z[6,5,5]  R2407     -2.3947756737470627e-02
    z[6,5,5]  R2408     6.5748989582061768e-02
    z[6,5,5]  R2409     5.3899574279785156e-01
    z[6,5,5]  R2410     1.7916370928287506e-01
    z[6,5,5]  R2411     7.7944636344909668e-01
    z[6,5,5]  R2412     3.2812169194221497e-01
    z[6,5,5]  R2413     -2.5396534800529480e-01
    z[6,5,5]  R2414     -1.5706744790077209e-01
    z[6,5,5]  R2415     -7.3487579822540283e-02
    z[6,5,5]  R2416     3.1989347189664841e-02
    z[6,5,5]  R2417     -2.9093673825263977e-01
    z[6,5,5]  R2418     -1.1443016678094864e-01
    z[6,5,5]  R2419     -4.5611268281936646e-01
    z[6,5,5]  R2420     -3.9596292376518250e-01
    z[6,5,5]  R2421     3.6357650160789490e-01
    z[6,5,5]  R2422     -2.4460119009017944e-01
    z[6,5,5]  R2423     -2.2914563119411469e-01
    z[6,5,5]  R2424     -1.7768631875514984e-01
    z[6,5,5]  R2425     -1.5092007815837860e-01
    z[6,5,5]  R2426     4.6170303225517273e-01
    z[6,5,5]  R2427     1.8440628051757812e-01
    z[6,5,5]  R2428     2.1487553417682648e-01
    z[6,5,5]  R2429     1.4064885675907135e-01
    z[6,5,5]  R2430     7.8019447624683380e-02
    z[6,5,5]  R2431     -9.2405569553375244e-01
    z[6,5,5]  R2432     1.0758799314498901e-01
    z[6,5,5]  R2433     2.9926860332489014e-01
    z[6,5,5]  R2434     -5.7398641109466553e-01
    z[6,5,5]  R2435     -7.5456231832504272e-01
    z[6,5,5]  R2436     -8.5650849342346191e-01
    z[6,5,5]  R2437     -4.2700063437223434e-02
    z[6,5,5]  R2438     -1.5010915696620941e-01
    z[6,5,5]  R2439     3.0066564679145813e-01
    z[6,5,5]  R2440     -5.5725187063217163e-01
    z[6,5,5]  R2441     -6.9269603490829468e-01
    z[6,5,5]  R2442     3.8588356226682663e-02
    z[6,5,5]  R2443     -5.9759981930255890e-02
    z[6,5,5]  R2444     -9.8781652748584747e-02
    z[6,5,5]  R2445     4.9851533770561218e-01
    z[6,5,5]  R2446     8.8417582213878632e-02
    z[6,5,5]  R2447     4.1982212662696838e-01
    z[6,5,5]  R2448     5.0388105213642120e-02
    z[6,5,5]  R2449     -2.9312046244740486e-02
    z[6,5,5]  R2450     2.2549599409103394e-02
    z[6,5,5]  R2451     9.7208611667156219e-02
    z[6,5,5]  R2452     -0.20915587246418
    z[6,5,5]  R2453     2.7075076103210449e-01
    z[6,5,5]  R2454     -1.3327005505561829e-01
    z[6,5,5]  R2455     -1.0672775655984879e-01
    z[6,5,5]  R2456     -1.8711720407009125e-01
    z[6,5,5]  R2457     4.2427446693181992e-02
    z[6,5,5]  R2458     -5.3012490272521973e-02
    z[6,5,5]  R2459     1.2396091967821121e-01
    z[6,5,5]  R2460     -5.7057093828916550e-02
    z[6,5,5]  R2461     -0.664159893989563
    z[6,5,5]  R2462     -1.6862601041793823e-01
    z[6,5,5]  R2463     -3.3100903034210205e-01
    z[6,5,5]  R2464     4.1131377220153809e-02
    z[6,5,5]  R2465     -4.3417149782180786e-01
    z[6,5,5]  R2466     -6.4314886927604675e-02
    z[6,5,5]  R2467     3.2166644930839539e-02
    z[6,5,5]  R2468     -2.9103556275367737e-01
    z[6,5,5]  R2469     -4.6886539459228516e-01
    z[6,5,5]  R2470     -4.1835474967956543e-01
    z[6,5,5]  R2471     8.4974959492683411e-02
    z[6,5,5]  R2472     -6.5110139548778534e-02
    z[6,5,5]  R2473     -1.3007238507270813e-01
    z[6,5,5]  R2474     -1.4972680248320103e-02
    z[6,5,5]  R2475     -1.5832929313182831e-01
    z[6,5,5]  R2476     -8.0520617961883545e-01
    z[6,5,5]  R2477     -7.1239614486694336e-01
    z[6,5,5]  R2478     -7.5145828723907471e-01
    z[6,5,5]  R2479     -7.3359489440917969e-02
    z[6,5,5]  R2480     -6.5183258056640625e-01
    z[6,5,5]  R2481     0.0919019877910614
    z[6,5,5]  R2482     -6.8476825952529907e-01
    z[6,5,5]  R2483     -0.540597677230835
    z[6,5,5]  R2484     -5.7579392194747925e-01
    z[6,5,5]  R2485     4.3393453955650330e-01
    z[6,5,5]  R2486     -3.0361536145210266e-01
    z[6,5,5]  R2487     -4.4442582130432129e-01
    z[6,5,5]  R2488     -1.9340707361698151e-01
    z[6,5,5]  R2489     -1.2813787162303925e-01
    z[6,5,5]  R2490     7.0793461799621582e-01
    z[6,5,5]  R2491     -5.4943698644638062e-01
    z[6,5,5]  R2492     4.1062682867050171e-01
    z[6,5,5]  R2493     2.5218388438224792e-01
    z[6,5,5]  R2494     1.0526556521654129e-01
    z[6,5,5]  R2495     -2.0504812896251678e-01
    z[6,5,5]  R2496     -8.4403932094573975e-02
    z[6,5,5]  R2497     5.3338732570409775e-02
    z[6,5,5]  R2498     -0.770687997341156
    z[6,5,5]  R2499     2.7705445885658264e-01
    z[6,5,5]  R2500     6.9618618488311768e-01
    z[6,5,5]  R2501     -1.8352276086807251e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2380     -1
    z[6,5,6]  R2381     1
    z[6,5,6]  R2382     -4.0954638272523880e-02
    z[6,5,6]  R2383     2.1268339827656746e-02
    z[6,5,6]  R2384     5.2315339446067810e-02
    z[6,5,6]  R2385     1.3736955821514130e-01
    z[6,5,6]  R2386     8.0335631966590881e-02
    z[6,5,6]  R2387     6.7857488989830017e-02
    z[6,5,6]  R2388     -4.8399096727371216e-01
    z[6,5,6]  R2389     -2.2590938210487366e-01
    z[6,5,6]  R2390     -4.9066364765167236e-01
    z[6,5,6]  R2391     -3.8394466042518616e-01
    z[6,5,6]  R2392     7.4578978121280670e-02
    z[6,5,6]  R2393     -1.4473941922187805e-01
    z[6,5,6]  R2394     2.3746220767498016e-01
    z[6,5,6]  R2395     3.3301338553428650e-01
    z[6,5,6]  R2396     -2.6124054193496704e-01
    z[6,5,6]  R2397     1.8263176083564758e-01
    z[6,5,6]  R2398     2.8792208433151245e-01
    z[6,5,6]  R2399     -2.5502455234527588e-01
    z[6,5,6]  R2400     -2.1545359492301941e-01
    z[6,5,6]  R2401     1.5662631392478943e-01
    z[6,5,6]  R2402     2.4414452910423279e-01
    z[6,5,6]  R2403     2.9341778159141541e-01
    z[6,5,6]  R2404     5.1917475461959839e-01
    z[6,5,6]  R2405     2.1874819695949554e-01
    z[6,5,6]  R2406     3.8928383588790894e-01
    z[6,5,6]  R2407     1.6137449443340302e-01
    z[6,5,6]  R2408     -4.5322526246309280e-02
    z[6,5,6]  R2409     -5.1023606210947037e-02
    z[6,5,6]  R2410     2.8241056948900223e-02
    z[6,5,6]  R2411     1.1728116311132908e-02
    z[6,5,6]  R2412     -2.7198362350463867e-01
    z[6,5,6]  R2413     5.1151126623153687e-01
    z[6,5,6]  R2414     3.8859617710113525e-01
    z[6,5,6]  R2415     -2.7948606014251709e-01
    z[6,5,6]  R2416     -3.1858119368553162e-01
    z[6,5,6]  R2417     1.7168654501438141e-01
    z[6,5,6]  R2418     -1.9448006525635719e-02
    z[6,5,6]  R2419     -0.180596262216568
    z[6,5,6]  R2420     -3.0839884281158447e-01
    z[6,5,6]  R2421     4.3326136469841003e-01
    z[6,5,6]  R2422     -2.0089246332645416e-02
    z[6,5,6]  R2423     2.4173586070537567e-01
    z[6,5,6]  R2424     -2.3494267463684082e-01
    z[6,5,6]  R2425     -1.1058136820793152e-01
    z[6,5,6]  R2426     -4.3667659163475037e-01
    z[6,5,6]  R2427     5.4727697372436523e-01
    z[6,5,6]  R2428     2.4932242929935455e-02
    z[6,5,6]  R2429     5.4051667451858521e-01
    z[6,5,6]  R2430     -1.3933502137660980e-01
    z[6,5,6]  R2431     -1.6211152076721191e-01
    z[6,5,6]  R2432     5.6706565618515015e-01
    z[6,5,6]  R2433     3.9679959416389465e-02
    z[6,5,6]  R2434     -2.1805323660373688e-01
    z[6,5,6]  R2435     2.0046980679035187e-01
    z[6,5,6]  R2436     4.9520316533744335e-03
    z[6,5,6]  R2437     -3.3127307891845703e-01
    z[6,5,6]  R2438     7.9868882894515991e-01
    z[6,5,6]  R2439     1.1968600749969482e-01
    z[6,5,6]  R2440     1.0809897631406784e-01
    z[6,5,6]  R2441     -1.2872619926929474e-01
    z[6,5,6]  R2442     -0.213245689868927
    z[6,5,6]  R2443     -1.1445382237434387e-01
    z[6,5,6]  R2444     3.0972677469253540e-01
    z[6,5,6]  R2445     -1.4680434763431549e-01
    z[6,5,6]  R2446     1.4119245111942291e-01
    z[6,5,6]  R2447     -2.9564124345779419e-01
    z[6,5,6]  R2448     3.4207320213317871e-01
    z[6,5,6]  R2449     -3.5359996557235718e-01
    z[6,5,6]  R2450     -2.0274966955184937e-01
    z[6,5,6]  R2451     1.9331571459770203e-01
    z[6,5,6]  R2452     -8.9825429022312164e-02
    z[6,5,6]  R2453     -9.0498877689242363e-03
    z[6,5,6]  R2454     1.7261378467082977e-01
    z[6,5,6]  R2455     3.6802750825881958e-01
    z[6,5,6]  R2456     1.0216881334781647e-01
    z[6,5,6]  R2457     2.8805169463157654e-01
    z[6,5,6]  R2458     2.0300626754760742e-02
    z[6,5,6]  R2459     3.7663422524929047e-02
    z[6,5,6]  R2460     2.2350224852561951e-01
    z[6,5,6]  R2461     1.3495652377605438e-01
    z[6,5,6]  R2462     -2.7111336588859558e-01
    z[6,5,6]  R2463     -1.2901568412780762e-01
    z[6,5,6]  R2464     -1.0398577898740768e-01
    z[6,5,6]  R2465     3.4599813818931580e-01
    z[6,5,6]  R2466     5.1238399744033813e-01
    z[6,5,6]  R2467     -2.1321910619735718e-01
    z[6,5,6]  R2468     1.7266513779759407e-02
    z[6,5,6]  R2469     -1.4194932579994202e-01
    z[6,5,6]  R2470     -2.7249327301979065e-01
    z[6,5,6]  R2471     2.1349404752254486e-01
    z[6,5,6]  R2472     -2.2075112909078598e-02
    z[6,5,6]  R2473     2.9936149716377258e-01
    z[6,5,6]  R2474     -3.5097181797027588e-02
    z[6,5,6]  R2475     6.6236026585102081e-02
    z[6,5,6]  R2476     -1.0731033980846405e-01
    z[6,5,6]  R2477     -5.0495218485593796e-02
    z[6,5,6]  R2478     -1.5178513526916504e-01
    z[6,5,6]  R2479     -3.4815138578414917e-01
    z[6,5,6]  R2480     4.1891507804393768e-02
    z[6,5,6]  R2481     1.3261966407299042e-01
    z[6,5,6]  R2482     7.9603493213653564e-02
    z[6,5,6]  R2483     -1.8367318809032440e-01
    z[6,5,6]  R2484     2.6043435931205750e-01
    z[6,5,6]  R2485     -7.9081624746322632e-02
    z[6,5,6]  R2486     -5.6449435651302338e-03
    z[6,5,6]  R2487     -2.0487642288208008e-01
    z[6,5,6]  R2488     9.3412511050701141e-03
    z[6,5,6]  R2489     2.2414916753768921e-01
    z[6,5,6]  R2490     -1.6394597291946411e-01
    z[6,5,6]  R2491     9.3698501586914062e-02
    z[6,5,6]  R2492     1.0346536524593830e-02
    z[6,5,6]  R2493     2.0242041349411011e-01
    z[6,5,6]  R2494     2.9542511701583862e-01
    z[6,5,6]  R2495     -0.0766846090555191
    z[6,5,6]  R2496     -1.4676292240619659e-01
    z[6,5,6]  R2497     6.8043315410614014e-01
    z[6,5,6]  R2498     -2.1194823086261749e-01
    z[6,5,6]  R2499     9.8082497715950012e-02
    z[6,5,6]  R2500     2.1409492194652557e-01
    z[6,5,6]  R2501     -2.5079679489135742e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2502     -1
    z[6,7,0]  R2503     1
    z[6,7,0]  R2516     -7.1324408054351807e-03
    z[6,7,0]  R2517     -0.609872043132782
    z[6,7,0]  R2518     -3.5625150799751282e-01
    z[6,7,0]  R2519     3.0565840005874634e-01
    z[6,7,0]  R2520     5.8468718081712723e-02
    z[6,7,0]  R2521     3.7295544147491455e-01
    z[6,7,0]  R2522     -4.7175645828247070e-02
    z[6,7,0]  R2523     -3.3855131268501282e-01
    z[6,7,0]  R2524     3.1291771680116653e-02
    z[6,7,0]  R2525     -2.0230922847986221e-02
    z[6,7,0]  R2526     1.5634299814701080e-01
    z[6,7,0]  R2527     3.0353438854217529e-01
    z[6,7,0]  R2528     -7.5079208612442017e-01
    z[6,7,0]  R2529     2.2267715632915497e-01
    z[6,7,0]  R2530     4.5826411247253418e-01
    z[6,7,0]  R2531     3.4416344761848450e-01
    z[6,7,0]  R2532     1.6742998361587524e-01
    z[6,7,0]  R2533     5.6998956203460693e-01
    z[6,7,0]  R2534     -7.1649444103240967e-01
    z[6,7,0]  R2535     -7.2960138320922852e-01
    z[6,7,0]  R2536     -3.8719708099961281e-03
    z[6,7,0]  R2537     0.377970814704895
    z[6,7,0]  R2538     3.6683431267738342e-01
    z[6,7,0]  R2539     5.4809135198593140e-01
    z[6,7,0]  R2540     3.9708280563354492e-01
    z[6,7,0]  R2541     2.5789085030555725e-01
    z[6,7,0]  R2542     6.8862646818161011e-01
    z[6,7,0]  R2543     -6.4441777765750885e-02
    z[6,7,0]  R2544     4.6054384112358093e-01
    z[6,7,0]  R2545     -1.5428721904754639e-01
    z[6,7,0]  R2546     -1.6341438889503479e-01
    z[6,7,0]  R2547     -3.2093605399131775e-01
    z[6,7,0]  R2548     -8.8356596231460571e-01
    z[6,7,0]  R2549     -1.7391633987426758e-01
    z[6,7,0]  R2550     -0.804546594619751
    z[6,7,0]  R2551     -8.6530953645706177e-01
    z[6,7,0]  R2552     6.3675379753112793e-01
    z[6,7,0]  R2553     -0.66482013463974
    z[6,7,0]  R2554     -6.4516210556030273e-01
    z[6,7,0]  R2555     -3.7745776772499084e-01
    z[6,7,0]  R2556     -2.4024908244609833e-01
    z[6,7,0]  R2557     -2.0745202898979187e-02
    z[6,7,0]  R2558     -3.7880662828683853e-02
    z[6,7,0]  R2559     -2.6529708504676819e-01
    z[6,7,0]  R2560     0.00278069986961782
    z[6,7,0]  R2561     -0.371847540140152
    z[6,7,0]  R2562     -8.7815326452255249e-01
    z[6,7,0]  R2563     -1.9606430083513260e-02
    z[6,7,0]  R2564     -1.5016080439090729e-01
    z[6,7,0]  R2565     2.2420510649681091e-01
    z[6,7,0]  R2566     -1.9836762547492981e-01
    z[6,7,0]  R2567     4.6706837415695190e-01
    z[6,7,0]  R2568     -1.8074283376336098e-02
    z[6,7,0]  R2569     1.8469411134719849e-01
    z[6,7,0]  R2570     -6.5395943820476532e-02
    z[6,7,0]  R2571     2.0739491283893585e-01
    z[6,7,0]  R2572     9.2153802514076233e-02
    z[6,7,0]  R2573     -3.3485004305839539e-01
    z[6,7,0]  R2574     5.7475157082080841e-02
    z[6,7,0]  R2575     8.2998253405094147e-02
    z[6,7,0]  R2576     -5.5729341506958008e-01
    z[6,7,0]  R2577     -0.570170521736145
    z[6,7,0]  R2578     -0.519062876701355
    z[6,7,0]  R2579     -1.5749590098857880e-01
    z[6,7,0]  R2580     -2.7505412697792053e-01
    z[6,7,0]  R2581     -3.7525451183319092e-01
    z[6,7,0]  R2582     2.3901455104351044e-02
    z[6,7,0]  R2583     -2.5289878249168396e-01
    z[6,7,0]  R2584     4.0116536617279053e-01
    z[6,7,0]  R2585     -1.9124847650527954e-01
    z[6,7,0]  R2586     -5.3013980388641357e-01
    z[6,7,0]  R2587     7.6019114255905151e-01
    z[6,7,0]  R2588     -2.5712382793426514e-01
    z[6,7,0]  R2589     -3.3564478158950806e-01
    z[6,7,0]  R2590     -0.532228410243988
    z[6,7,0]  R2591     7.5140100717544556e-01
    z[6,7,0]  R2592     -6.1134433746337891e-01
    z[6,7,0]  R2593     -7.5698435306549072e-01
    z[6,7,0]  R2594     -5.2028256654739380e-01
    z[6,7,0]  R2595     1.3251268863677979e-01
    z[6,7,0]  R2596     6.0195124149322510e-01
    z[6,7,0]  R2597     5.9818547964096069e-01
    z[6,7,0]  R2598     6.7245703935623169e-01
    z[6,7,0]  R2599     4.9734145402908325e-01
    z[6,7,0]  R2600     0.382784366607666
    z[6,7,0]  R2601     5.3919726610183716e-01
    z[6,7,0]  R2602     0.352083295583725
    z[6,7,0]  R2603     1.0322692990303040e-01
    z[6,7,0]  R2604     -3.5776447504758835e-02
    z[6,7,0]  R2605     -6.2972344458103180e-02
    z[6,7,0]  R2606     3.9761614799499512e-01
    z[6,7,0]  R2607     3.1109130382537842e-01
    z[6,7,0]  R2608     6.0046070814132690e-01
    z[6,7,0]  R2609     6.0410302132368088e-02
    z[6,7,0]  R2610     -4.0367566980421543e-03
    z[6,7,0]  R2611     3.0294919013977051e-01
    z[6,7,0]  R2612     5.7300585508346558e-01
    z[6,7,0]  R2613     1.5232123434543610e-01
    z[6,7,0]  R2614     -5.1245975494384766e-01
    z[6,7,0]  R2615     7.1005530655384064e-02
    z[6,7,0]  R2616     -1.8540312349796295e-01
    z[6,7,0]  R2617     -6.8541193008422852e-01
    z[6,7,0]  R2618     -2.7038168907165527e-01
    z[6,7,0]  R2619     -0.452766478061676
    z[6,7,0]  R2620     -4.6305142343044281e-02
    z[6,7,0]  R2621     -7.7871638350188732e-03
    z[6,7,0]  R2622     7.7178925275802612e-02
    z[6,7,0]  R2623     -2.6318386197090149e-01
    z[6,7,0]  R2624     2.7791216969490051e-01
    z[6,7,0]  R2625     0.000984802725724876
    z[6,7,0]  R2626     2.8282368183135986e-01
    z[6,7,0]  R2627     -2.5316581130027771e-01
    z[6,7,0]  R2628     1.2265031225979328e-02
    z[6,7,0]  R2629     -4.1162014007568359e-01
    z[6,7,0]  R2630     -2.6204910874366760e-01
    z[6,7,0]  R2631     -6.1397153139114380e-01
    z[6,7,0]  R2632     -1.5431550145149231e-01
    z[6,7,0]  R2633     2.1453516185283661e-01
    z[6,7,0]  R2634     1.5545056760311127e-01
    z[6,7,0]  R2635     -5.9662234783172607e-01
    z[6,7,0]  R2636     -1.2338148802518845e-01
    z[6,7,0]  R2637     -1.2407746165990829e-01
    z[6,7,0]  R2638     -3.0643790960311890e-01
    z[6,7,0]  R2639     2.3313535749912262e-01
    z[6,7,0]  R2640     5.5375963449478149e-01
    z[6,7,0]  R2641     -1.8920011818408966e-01
    z[6,7,0]  R2642     -5.3123313188552856e-01
    z[6,7,0]  R2643     5.9123420715332031e-01
    z[6,7,0]  R2644     5.3236150741577148e-01
    z[6,7,0]  R2645     3.4476128220558167e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2504     -1
    z[6,7,1]  R2505     1
    z[6,7,1]  R2516     1.1356388777494431e-01
    z[6,7,1]  R2517     -4.9036312103271484e-01
    z[6,7,1]  R2518     -0.268771767616272
    z[6,7,1]  R2519     -1.7898106575012207e-01
    z[6,7,1]  R2520     1.5737524256110191e-02
    z[6,7,1]  R2521     9.0887606143951416e-02
    z[6,7,1]  R2522     -4.1235667467117310e-01
    z[6,7,1]  R2523     1.8914127349853516e-01
    z[6,7,1]  R2524     -3.6051037907600403e-01
    z[6,7,1]  R2525     -4.4455164670944214e-01
    z[6,7,1]  R2526     5.7409924268722534e-01
    z[6,7,1]  R2527     0.521532416343689
    z[6,7,1]  R2528     4.0930244326591492e-01
    z[6,7,1]  R2529     5.2007561922073364e-01
    z[6,7,1]  R2530     6.0095995664596558e-01
    z[6,7,1]  R2531     4.5345729589462280e-01
    z[6,7,1]  R2532     5.4914832115173340e-01
    z[6,7,1]  R2533     5.0805473327636719e-01
    z[6,7,1]  R2534     5.8904081583023071e-01
    z[6,7,1]  R2535     2.8098881244659424e-01
    z[6,7,1]  R2536     -8.2848638296127319e-01
    z[6,7,1]  R2537     -6.1497098207473755e-01
    z[6,7,1]  R2538     -5.0910407304763794e-01
    z[6,7,1]  R2539     -6.8660420179367065e-01
    z[6,7,1]  R2540     -0.74765944480896
    z[6,7,1]  R2541     -7.9350328445434570e-01
    z[6,7,1]  R2542     -3.7632763385772705e-01
    z[6,7,1]  R2543     -5.1575195789337158e-01
    z[6,7,1]  R2544     -6.1419796943664551e-01
    z[6,7,1]  R2545     -3.1984734535217285e-01
    z[6,7,1]  R2546     -2.7069896459579468e-01
    z[6,7,1]  R2547     -4.9074128270149231e-01
    z[6,7,1]  R2548     8.4123871056362987e-04
    z[6,7,1]  R2549     -5.9279185533523560e-01
    z[6,7,1]  R2550     3.5964214801788330e-01
    z[6,7,1]  R2551     1.4193475246429443e-01
    z[6,7,1]  R2552     -6.0124039649963379e-01
    z[6,7,1]  R2553     0.0818859413266182
    z[6,7,1]  R2554     -5.1137939095497131e-02
    z[6,7,1]  R2555     -5.5152320861816406e-01
    z[6,7,1]  R2556     -6.5132069587707520e-01
    z[6,7,1]  R2557     -6.1464887857437134e-01
    z[6,7,1]  R2558     -2.9878202080726624e-01
    z[6,7,1]  R2559     -3.0940631031990051e-01
    z[6,7,1]  R2560     -3.6072564125061035e-01
    z[6,7,1]  R2561     -0.62802654504776
    z[6,7,1]  R2562     2.0927037298679352e-01
    z[6,7,1]  R2563     -6.8977546691894531e-01
    z[6,7,1]  R2564     -6.4189249277114868e-01
    z[6,7,1]  R2565     2.0453146100044250e-01
    z[6,7,1]  R2566     -6.6997438669204712e-01
    z[6,7,1]  R2567     -3.8101676106452942e-01
    z[6,7,1]  R2568     0.609222948551178
    z[6,7,1]  R2569     6.8127177655696869e-02
    z[6,7,1]  R2570     2.0265281200408936e-01
    z[6,7,1]  R2571     4.5337605476379395e-01
    z[6,7,1]  R2572     2.0321825146675110e-01
    z[6,7,1]  R2573     -5.7266287505626678e-02
    z[6,7,1]  R2574     1.5035147964954376e-01
    z[6,7,1]  R2575     -1.6053926199674606e-02
    z[6,7,1]  R2576     -7.3747581243515015e-01
    z[6,7,1]  R2577     -7.4708157777786255e-01
    z[6,7,1]  R2578     -7.3020076751708984e-01
    z[6,7,1]  R2579     -9.3595254421234131e-01
    z[6,7,1]  R2580     -8.7157249450683594e-01
    z[6,7,1]  R2581     -8.0742329359054565e-01
    z[6,7,1]  R2582     -1.9723260775208473e-02
    z[6,7,1]  R2583     -8.6047857999801636e-01
    z[6,7,1]  R2584     3.9040920138359070e-01
    z[6,7,1]  R2585     -8.3041661977767944e-01
    z[6,7,1]  R2586     0.418416827917099
    z[6,7,1]  R2587     5.7618740946054459e-02
    z[6,7,1]  R2588     3.9711853861808777e-01
    z[6,7,1]  R2589     3.7892201542854309e-01
    z[6,7,1]  R2590     4.4411951303482056e-01
    z[6,7,1]  R2591     -2.7559101581573486e-01
    z[6,7,1]  R2592     4.4987294077873230e-01
    z[6,7,1]  R2593     3.6728054285049438e-01
    z[6,7,1]  R2594     0.534921407699585
    z[6,7,1]  R2595     2.6610809564590454e-01
    z[6,7,1]  R2596     1.7845438420772552e-01
    z[6,7,1]  R2597     -4.6498408913612366e-01
    z[6,7,1]  R2598     -2.5442427396774292e-01
    z[6,7,1]  R2599     -4.4862989336252213e-02
    z[6,7,1]  R2600     -1.2408622354269028e-01
    z[6,7,1]  R2601     -3.0851846933364868e-01
    z[6,7,1]  R2602     -4.3527570366859436e-01
    z[6,7,1]  R2603     3.5347703844308853e-02
    z[6,7,1]  R2604     2.0681785047054291e-01
    z[6,7,1]  R2605     9.0527945756912231e-01
    z[6,7,1]  R2606     -1.1390823125839233e-01
    z[6,7,1]  R2607     3.4702695906162262e-02
    z[6,7,1]  R2608     -2.0013208687305450e-01
    z[6,7,1]  R2609     -3.1605863571166992e-01
    z[6,7,1]  R2610     -6.7666035890579224e-01
    z[6,7,1]  R2611     3.5550642013549805e-01
    z[6,7,1]  R2612     1.4513367414474487e-01
    z[6,7,1]  R2613     -1.2593352794647217e-01
    z[6,7,1]  R2614     1.0443762689828873e-01
    z[6,7,1]  R2615     9.5946002006530762e-01
    z[6,7,1]  R2616     -6.5885370969772339e-01
    z[6,7,1]  R2617     2.4410164356231689e-01
    z[6,7,1]  R2618     2.7930954098701477e-01
    z[6,7,1]  R2619     4.5855066180229187e-01
    z[6,7,1]  R2620     9.0118712186813354e-01
    z[6,7,1]  R2621     9.7862249612808228e-01
    z[6,7,1]  R2622     0.916998565196991
    z[6,7,1]  R2623     9.1740399599075317e-01
    z[6,7,1]  R2624     -5.0423923879861832e-02
    z[6,7,1]  R2625     2.1070607006549835e-01
    z[6,7,1]  R2626     -4.6093201637268066e-01
    z[6,7,1]  R2627     -5.1532387733459473e-01
    z[6,7,1]  R2628     -5.8087170124053955e-01
    z[6,7,1]  R2629     2.6048794388771057e-01
    z[6,7,1]  R2630     1.4729660749435425e-01
    z[6,7,1]  R2631     4.6828430891036987e-01
    z[6,7,1]  R2632     9.2185807228088379e-01
    z[6,7,1]  R2633     8.7684553861618042e-01
    z[6,7,1]  R2634     9.4337785243988037e-01
    z[6,7,1]  R2635     3.8790026307106018e-01
    z[6,7,1]  R2636     0.128950834274292
    z[6,7,1]  R2637     -4.7677025198936462e-01
    z[6,7,1]  R2638     5.0981199741363525e-01
    z[6,7,1]  R2639     9.1037929058074951e-01
    z[6,7,1]  R2640     1.2420173734426498e-01
    z[6,7,1]  R2641     7.7613222599029541e-01
    z[6,7,1]  R2642     7.1518266201019287e-01
    z[6,7,1]  R2643     1.3515974581241608e-01
    z[6,7,1]  R2644     -1.9805087149143219e-01
    z[6,7,1]  R2645     -4.6662919223308563e-02
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2506     -1
    z[6,7,2]  R2507     1
    z[6,7,2]  R2516     -6.6207003593444824e-01
    z[6,7,2]  R2517     -5.6170988082885742e-01
    z[6,7,2]  R2518     -4.9344068765640259e-01
    z[6,7,2]  R2519     -7.3885542154312134e-01
    z[6,7,2]  R2520     -5.0496435165405273e-01
    z[6,7,2]  R2521     -3.2723531126976013e-01
    z[6,7,2]  R2522     -6.5867567062377930e-01
    z[6,7,2]  R2523     -4.8692572116851807e-01
    z[6,7,2]  R2524     -5.9139841794967651e-01
    z[6,7,2]  R2525     -5.0206708908081055e-01
    z[6,7,2]  R2526     7.6512783765792847e-01
    z[6,7,2]  R2527     6.8397843837738037e-01
    z[6,7,2]  R2528     3.6982640624046326e-01
    z[6,7,2]  R2529     7.0460414886474609e-01
    z[6,7,2]  R2530     0.552261471748352
    z[6,7,2]  R2531     6.2330263853073120e-01
    z[6,7,2]  R2532     6.0658687353134155e-01
    z[6,7,2]  R2533     5.6052255630493164e-01
    z[6,7,2]  R2534     1.9127818942070007e-01
    z[6,7,2]  R2535     4.7686657309532166e-01
    z[6,7,2]  R2536     -2.2575299441814423e-01
    z[6,7,2]  R2537     -4.3765774369239807e-01
    z[6,7,2]  R2538     -3.4211507439613342e-01
    z[6,7,2]  R2539     -4.0068873763084412e-01
    z[6,7,2]  R2540     -1.5267378091812134e-01
    z[6,7,2]  R2541     -3.5434699058532715e-01
    z[6,7,2]  R2542     -3.5900583863258362e-01
    z[6,7,2]  R2543     -1.2537996470928192e-01
    z[6,7,2]  R2544     -1.0073851794004440e-01
    z[6,7,2]  R2545     -3.6328250169754028e-01
    z[6,7,2]  R2546     -5.9387695789337158e-01
    z[6,7,2]  R2547     -3.5038021206855774e-01
    z[6,7,2]  R2548     -9.6438162028789520e-02
    z[6,7,2]  R2549     -4.6328902244567871e-01
    z[6,7,2]  R2550     -2.7555164694786072e-01
    z[6,7,2]  R2551     1.7317138612270355e-01
    z[6,7,2]  R2552     -3.0879771709442139e-01
    z[6,7,2]  R2553     -4.7949111461639404e-01
    z[6,7,2]  R2554     -4.8743149638175964e-01
    z[6,7,2]  R2555     2.0412076264619827e-02
    z[6,7,2]  R2556     -0.616512656211853
    z[6,7,2]  R2557     -5.6968605518341064e-01
    z[6,7,2]  R2558     -5.5516713857650757e-01
    z[6,7,2]  R2559     -5.1011794805526733e-01
    z[6,7,2]  R2560     -6.2455916404724121e-01
    z[6,7,2]  R2561     -2.4228592216968536e-01
    z[6,7,2]  R2562     2.3195035755634308e-01
    z[6,7,2]  R2563     -3.4269922971725464e-01
    z[6,7,2]  R2564     -4.9695184826850891e-01
    z[6,7,2]  R2565     1.2902058660984039e-01
    z[6,7,2]  R2566     -2.7538421750068665e-01
    z[6,7,2]  R2567     -2.1320012211799622e-01
    z[6,7,2]  R2568     4.7804632782936096e-01
    z[6,7,2]  R2569     5.1289552450180054e-01
    z[6,7,2]  R2570     4.1988608241081238e-01
    z[6,7,2]  R2571     -1.2099956721067429e-01
    z[6,7,2]  R2572     -4.5156544446945190e-01
    z[6,7,2]  R2573     -6.2282466888427734e-01
    z[6,7,2]  R2574     2.7554255723953247e-01
    z[6,7,2]  R2575     3.4326678514480591e-01
    z[6,7,2]  R2576     0.298555850982666
    z[6,7,2]  R2577     1.8358130753040314e-01
    z[6,7,2]  R2578     1.9443720579147339e-01
    z[6,7,2]  R2579     1.5707209706306458e-01
    z[6,7,2]  R2580     -2.6619702577590942e-01
    z[6,7,2]  R2581     -1.0090090334415436e-01
    z[6,7,2]  R2582     -7.4030059576034546e-01
    z[6,7,2]  R2583     -1.6972111165523529e-01
    z[6,7,2]  R2584     -7.7183133363723755e-01
    z[6,7,2]  R2585     1.4229343831539154e-01
    z[6,7,2]  R2586     5.8528393507003784e-01
    z[6,7,2]  R2587     -3.7061061710119247e-02
    z[6,7,2]  R2588     8.3552157878875732e-01
    z[6,7,2]  R2589     4.7039976716041565e-01
    z[6,7,2]  R2590     3.7349972128868103e-01
    z[6,7,2]  R2591     5.8752644807100296e-02
    z[6,7,2]  R2592     2.3887164890766144e-01
    z[6,7,2]  R2593     2.6121550798416138e-01
    z[6,7,2]  R2594     3.0541107058525085e-01
    z[6,7,2]  R2595     7.8861457109451294e-01
    z[6,7,2]  R2596     -1.9163978099822998e-01
    z[6,7,2]  R2597     -5.1818495988845825e-01
    z[6,7,2]  R2598     -3.6145347356796265e-01
    z[6,7,2]  R2599     -5.7662930339574814e-02
    z[6,7,2]  R2600     -1.6415746882557869e-02
    z[6,7,2]  R2601     -7.3851391673088074e-02
    z[6,7,2]  R2602     -2.2096006572246552e-01
    z[6,7,2]  R2603     -5.3146738559007645e-02
    z[6,7,2]  R2604     -1.4740160107612610e-01
    z[6,7,2]  R2605     2.1982432901859283e-01
    z[6,7,2]  R2606     -3.8245442509651184e-01
    z[6,7,2]  R2607     -2.9966729879379272e-01
    z[6,7,2]  R2608     -3.2674607634544373e-01
    z[6,7,2]  R2609     -2.6593995094299316e-01
    z[6,7,2]  R2610     -4.1883742809295654e-01
    z[6,7,2]  R2611     -4.2928963899612427e-01
    z[6,7,2]  R2612     -4.4848346710205078e-01
    z[6,7,2]  R2613     -3.6271527409553528e-01
    z[6,7,2]  R2614     2.6568377017974854e-01
    z[6,7,2]  R2615     5.1571227610111237e-02
    z[6,7,2]  R2616     -5.2012479305267334e-01
    z[6,7,2]  R2617     0.430862158536911
    z[6,7,2]  R2618     6.4673972129821777e-01
    z[6,7,2]  R2619     5.3898984193801880e-01
    z[6,7,2]  R2620     1.5493386983871460e-01
    z[6,7,2]  R2621     1.5950405597686768e-01
    z[6,7,2]  R2622     1.4847847819328308e-01
    z[6,7,2]  R2623     1.4667649567127228e-01
    z[6,7,2]  R2624     6.8408769369125366e-01
    z[6,7,2]  R2625     5.0998938083648682e-01
    z[6,7,2]  R2626     -1.5722635388374329e-01
    z[6,7,2]  R2627     -1.3574923574924469e-01
    z[6,7,2]  R2628     -4.8064518719911575e-02
    z[6,7,2]  R2629     8.1105232238769531e-01
    z[6,7,2]  R2630     8.8950288295745850e-01
    z[6,7,2]  R2631     5.5517274141311646e-01
    z[6,7,2]  R2632     0.0680805891752243
    z[6,7,2]  R2633     1.5615177154541016e-01
    z[6,7,2]  R2634     1.3400849699974060e-01
    z[6,7,2]  R2635     5.0934523344039917e-01
    z[6,7,2]  R2636     -4.7807180881500244e-01
    z[6,7,2]  R2637     -5.9512192010879517e-01
    z[6,7,2]  R2638     4.7363206744194031e-01
    z[6,7,2]  R2639     2.0909920334815979e-01
    z[6,7,2]  R2640     5.8233773708343506e-01
    z[6,7,2]  R2641     -0.0377717949450016
    z[6,7,2]  R2642     -2.4989375472068787e-01
    z[6,7,2]  R2643     7.7504372596740723e-01
    z[6,7,2]  R2644     7.0783507823944092e-01
    z[6,7,2]  R2645     8.4468716382980347e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2508     -1
    z[6,7,3]  R2509     1
    z[6,7,3]  R2516     7.0285123586654663e-01
    z[6,7,3]  R2517     -1.7225007712841034e-01
    z[6,7,3]  R2518     4.4561344385147095e-01
    z[6,7,3]  R2519     3.9838501811027527e-01
    z[6,7,3]  R2520     3.7805780768394470e-01
    z[6,7,3]  R2521     6.2986296415328979e-01
    z[6,7,3]  R2522     -1.2511213123798370e-01
    z[6,7,3]  R2523     0.42557492852211
    z[6,7,3]  R2524     -1.0559994727373123e-01
    z[6,7,3]  R2525     2.1751316264271736e-02
    z[6,7,3]  R2526     1.7642891407012939e-01
    z[6,7,3]  R2527     2.7874562144279480e-01
    z[6,7,3]  R2528     1.1768934130668640e-01
    z[6,7,3]  R2529     0.139877051115036
    z[6,7,3]  R2530     1.7006102204322815e-01
    z[6,7,3]  R2531     4.9650269746780396e-01
    z[6,7,3]  R2532     4.2137256264686584e-01
    z[6,7,3]  R2533     1.0021498799324036e-01
    z[6,7,3]  R2534     5.2976712584495544e-02
    z[6,7,3]  R2535     2.5871220976114273e-02
    z[6,7,3]  R2536     -4.0048643946647644e-01
    z[6,7,3]  R2537     -2.1492913365364075e-01
    z[6,7,3]  R2538     -1.8450836837291718e-01
    z[6,7,3]  R2539     1.2105809897184372e-01
    z[6,7,3]  R2540     -1.1410713195800781e-01
    z[6,7,3]  R2541     2.2164495661854744e-02
    z[6,7,3]  R2542     -4.1962409019470215e-01
    z[6,7,3]  R2543     -4.3861925601959229e-01
    z[6,7,3]  R2544     -5.0154322385787964e-01
    z[6,7,3]  R2545     -3.6153492331504822e-01
    z[6,7,3]  R2546     -5.6492835283279419e-01
    z[6,7,3]  R2547     -0.350996732711792
    z[6,7,3]  R2548     7.1377992630004883e-02
    z[6,7,3]  R2549     -3.6774033308029175e-01
    z[6,7,3]  R2550     1.1131998151540756e-01
    z[6,7,3]  R2551     -2.9271697998046875e-01
    z[6,7,3]  R2552     -3.3724820613861084e-01
    z[6,7,3]  R2553     1.0116033256053925e-01
    z[6,7,3]  R2554     2.8972604870796204e-01
    z[6,7,3]  R2555     -2.9796159267425537e-01
    z[6,7,3]  R2556     -2.4730089306831360e-01
    z[6,7,3]  R2557     -3.6283436417579651e-01
    z[6,7,3]  R2558     -6.5098208189010620e-01
    z[6,7,3]  R2559     -6.8950426578521729e-01
    z[6,7,3]  R2560     -2.6326560974121094e-01
    z[6,7,3]  R2561     -2.6847904920578003e-01
    z[6,7,3]  R2562     -1.8104347586631775e-01
    z[6,7,3]  R2563     2.9219800233840942e-01
    z[6,7,3]  R2564     5.3422415256500244e-01
    z[6,7,3]  R2565     9.3962311744689941e-02
    z[6,7,3]  R2566     -3.1924274563789368e-01
    z[6,7,3]  R2567     -6.8487578630447388e-01
    z[6,7,3]  R2568     -1.2396093457937241e-01
    z[6,7,3]  R2569     1.1860295385122299e-01
    z[6,7,3]  R2570     -3.6851714830845594e-03
    z[6,7,3]  R2571     3.0113914608955383e-01
    z[6,7,3]  R2572     2.2926524281501770e-01
    z[6,7,3]  R2573     2.7679237723350525e-01
    z[6,7,3]  R2574     -5.6929498910903931e-01
    z[6,7,3]  R2575     -5.3526127338409424e-01
    z[6,7,3]  R2576     2.1336081624031067e-01
    z[6,7,3]  R2577     7.9396776854991913e-03
    z[6,7,3]  R2578     -1.5130911953747272e-02
    z[6,7,3]  R2579     -8.4489017724990845e-02
    z[6,7,3]  R2580     1.9082543253898621e-01
    z[6,7,3]  R2581     0.310305118560791
    z[6,7,3]  R2582     1.1281483806669712e-02
    z[6,7,3]  R2583     2.4558851122856140e-01
    z[6,7,3]  R2584     2.4062691628932953e-01
    z[6,7,3]  R2585     3.6169907450675964e-01
    z[6,7,3]  R2586     -9.5866424089763314e-05
    z[6,7,3]  R2587     6.2737171538174152e-03
    z[6,7,3]  R2588     -4.9242008477449417e-02
    z[6,7,3]  R2589     -8.9440263807773590e-02
    z[6,7,3]  R2590     -1.2167779356241226e-01
    z[6,7,3]  R2591     1.7906905710697174e-01
    z[6,7,3]  R2592     1.5895548462867737e-01
    z[6,7,3]  R2593     -9.5122829079627991e-02
    z[6,7,3]  R2594     -7.8436203300952911e-02
    z[6,7,3]  R2595     6.6721066832542419e-03
    z[6,7,3]  R2596     3.1728571653366089e-01
    z[6,7,3]  R2597     -1.3364253938198090e-01
    z[6,7,3]  R2598     -4.9848143011331558e-02
    z[6,7,3]  R2599     4.1682282090187073e-01
    z[6,7,3]  R2600     6.3563042879104614e-01
    z[6,7,3]  R2601     4.5382767915725708e-01
    z[6,7,3]  R2602     6.9629192352294922e-01
    z[6,7,3]  R2603     7.9223698377609253e-01
    z[6,7,3]  R2604     3.2487702369689941e-01
    z[6,7,3]  R2605     -1.7021021246910095e-01
    z[6,7,3]  R2606     3.3239468932151794e-01
    z[6,7,3]  R2607     1.1013448238372803e-01
    z[6,7,3]  R2608     5.5118042975664139e-02
    z[6,7,3]  R2609     7.5845491886138916e-01
    z[6,7,3]  R2610     -4.6045112609863281e-01
    z[6,7,3]  R2611     1.1464538425207138e-01
    z[6,7,3]  R2612     -2.7030047774314880e-01
    z[6,7,3]  R2613     5.3859239816665649e-01
    z[6,7,3]  R2614     2.4339058995246887e-01
    z[6,7,3]  R2615     -1.8081294000148773e-01
    z[6,7,3]  R2616     -4.1440117359161377e-01
    z[6,7,3]  R2617     1.3351282104849815e-02
    z[6,7,3]  R2618     1.4195926487445831e-01
    z[6,7,3]  R2619     7.4260458350181580e-02
    z[6,7,3]  R2620     3.7941688299179077e-01
    z[6,7,3]  R2621     -0.0711718425154686
    z[6,7,3]  R2622     2.7141135931015015e-01
    z[6,7,3]  R2623     0.0403439924120903
    z[6,7,3]  R2624     -7.0779860019683838e-02
    z[6,7,3]  R2625     -1.4947031438350677e-01
    z[6,7,3]  R2626     5.7387119531631470e-01
    z[6,7,3]  R2627     -1.8258984386920929e-01
    z[6,7,3]  R2628     -5.4872053861618042e-01
    z[6,7,3]  R2629     1.2046121805906296e-01
    z[6,7,3]  R2630     1.4531119167804718e-01
    z[6,7,3]  R2631     -2.5036895275115967e-01
    z[6,7,3]  R2632     1.3941834867000580e-01
    z[6,7,3]  R2633     2.9689857363700867e-01
    z[6,7,3]  R2634     1.6956686973571777e-01
    z[6,7,3]  R2635     1.1790903657674789e-01
    z[6,7,3]  R2636     0.635644793510437
    z[6,7,3]  R2637     2.1650105714797974e-01
    z[6,7,3]  R2638     -2.8590098023414612e-01
    z[6,7,3]  R2639     5.9115849435329437e-02
    z[6,7,3]  R2640     -6.6254511475563049e-03
    z[6,7,3]  R2641     -0.457742303609848
    z[6,7,3]  R2642     1.0660663992166519e-01
    z[6,7,3]  R2643     1.0329223424196243e-01
    z[6,7,3]  R2644     2.9699310660362244e-01
    z[6,7,3]  R2645     1.2285843491554260e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2510     -1
    z[6,7,4]  R2511     1
    z[6,7,4]  R2516     7.3707611300051212e-03
    z[6,7,4]  R2517     -1.1025711894035339e-01
    z[6,7,4]  R2518     2.2705543041229248e-01
    z[6,7,4]  R2519     1.8147720396518707e-01
    z[6,7,4]  R2520     3.1352239847183228e-01
    z[6,7,4]  R2521     3.4658116102218628e-01
    z[6,7,4]  R2522     -2.7731582522392273e-01
    z[6,7,4]  R2523     2.6809543371200562e-01
    z[6,7,4]  R2524     -1.9075492024421692e-01
    z[6,7,4]  R2525     -5.3753042221069336e-01
    z[6,7,4]  R2526     9.7786642611026764e-02
    z[6,7,4]  R2527     2.6051837205886841e-01
    z[6,7,4]  R2528     -4.0340710431337357e-02
    z[6,7,4]  R2529     -2.0097592473030090e-01
    z[6,7,4]  R2530     2.7689328417181969e-02
    z[6,7,4]  R2531     2.0092625170946121e-02
    z[6,7,4]  R2532     -1.9369050860404968e-01
    z[6,7,4]  R2533     0.0772441104054451
    z[6,7,4]  R2534     -6.6140934824943542e-02
    z[6,7,4]  R2535     2.9915568232536316e-01
    z[6,7,4]  R2536     1.8556652963161469e-01
    z[6,7,4]  R2537     -1.8377484381198883e-01
    z[6,7,4]  R2538     -4.2894887924194336e-01
    z[6,7,4]  R2539     6.9989293813705444e-02
    z[6,7,4]  R2540     2.6184371113777161e-01
    z[6,7,4]  R2541     3.8881441950798035e-01
    z[6,7,4]  R2542     -2.6986005902290344e-01
    z[6,7,4]  R2543     0.478142648935318
    z[6,7,4]  R2544     3.4068933129310608e-01
    z[6,7,4]  R2545     -5.9474412351846695e-02
    z[6,7,4]  R2546     -2.1574285626411438e-01
    z[6,7,4]  R2547     -2.8994113206863403e-01
    z[6,7,4]  R2548     -1.7099156975746155e-01
    z[6,7,4]  R2549     4.3007937073707581e-01
    z[6,7,4]  R2550     -1.8034437298774719e-01
    z[6,7,4]  R2551     3.6082316190004349e-02
    z[6,7,4]  R2552     1.0241910815238953e-01
    z[6,7,4]  R2553     -2.6553717255592346e-01
    z[6,7,4]  R2554     8.7884448468685150e-02
    z[6,7,4]  R2555     3.7979838252067566e-01
    z[6,7,4]  R2556     1.2877424061298370e-01
    z[6,7,4]  R2557     -2.3375539481639862e-01
    z[6,7,4]  R2558     -3.0089142918586731e-01
    z[6,7,4]  R2559     -2.5148290395736694e-01
    z[6,7,4]  R2560     8.1425786018371582e-02
    z[6,7,4]  R2561     5.4870493710041046e-02
    z[6,7,4]  R2562     2.2733654081821442e-01
    z[6,7,4]  R2563     9.5197439193725586e-02
    z[6,7,4]  R2564     -8.6993388831615448e-02
    z[6,7,4]  R2565     -4.7589138150215149e-02
    z[6,7,4]  R2566     -2.9893046244978905e-02
    z[6,7,4]  R2567     -1.7614772915840149e-01
    z[6,7,4]  R2568     -8.7283954024314880e-02
    z[6,7,4]  R2569     2.7306738495826721e-01
    z[6,7,4]  R2570     2.1143786609172821e-01
    z[6,7,4]  R2571     7.3112696409225464e-01
    z[6,7,4]  R2572     1.8248160183429718e-01
    z[6,7,4]  R2573     -5.6155747175216675e-01
    z[6,7,4]  R2574     -5.0185203552246094e-01
    z[6,7,4]  R2575     -3.0351039767265320e-01
    z[6,7,4]  R2576     5.9422351419925690e-02
    z[6,7,4]  R2577     -1.9214452803134918e-01
    z[6,7,4]  R2578     2.2768998518586159e-02
    z[6,7,4]  R2579     -1.0811345279216766e-01
    z[6,7,4]  R2580     2.8450158424675465e-03
    z[6,7,4]  R2581     -1.7688177525997162e-01
    z[6,7,4]  R2582     3.1629720330238342e-01
    z[6,7,4]  R2583     3.7627778947353363e-02
    z[6,7,4]  R2584     -1.3504016213119030e-02
    z[6,7,4]  R2585     -3.0993264913558960e-01
    z[6,7,4]  R2586     -1.5718884766101837e-01
    z[6,7,4]  R2587     5.4455578327178955e-01
    z[6,7,4]  R2588     -1.5139667689800262e-01
    z[6,7,4]  R2589     -5.4010105133056641e-01
    z[6,7,4]  R2590     -4.8380544781684875e-01
    z[6,7,4]  R2591     4.2592003941535950e-01
    z[6,7,4]  R2592     -4.6477150917053223e-01
    z[6,7,4]  R2593     1.5552908182144165e-01
    z[6,7,4]  R2594     -0.358530193567276
    z[6,7,4]  R2595     -1.1168579757213593e-01
    z[6,7,4]  R2596     5.5943781137466431e-01
    z[6,7,4]  R2597     1.8434017896652222e-01
    z[6,7,4]  R2598     3.9101520180702209e-01
    z[6,7,4]  R2599     6.2802612781524658e-01
    z[6,7,4]  R2600     5.0317895412445068e-01
    z[6,7,4]  R2601     1.2057242542505264e-01
    z[6,7,4]  R2602     2.1572346985340118e-01
    z[6,7,4]  R2603     -2.7864813804626465e-01
    z[6,7,4]  R2604     -2.0015962421894073e-01
    z[6,7,4]  R2605     -5.9578165411949158e-02
    z[6,7,4]  R2606     1.1606896668672562e-01
    z[6,7,4]  R2607     5.0491452217102051e-01
    z[6,7,4]  R2608     6.3793194293975830e-01
    z[6,7,4]  R2609     6.8251579068601131e-03
    z[6,7,4]  R2610     3.2291319966316223e-01
    z[6,7,4]  R2611     4.9339967966079712e-01
    z[6,7,4]  R2612     2.7060031890869141e-01
    z[6,7,4]  R2613     2.3952074348926544e-01
    z[6,7,4]  R2614     -6.2229067087173462e-01
    z[6,7,4]  R2615     7.8987866640090942e-02
    z[6,7,4]  R2616     -2.5162476301193237e-01
    z[6,7,4]  R2617     -1.6484941542148590e-01
    z[6,7,4]  R2618     -4.0740302205085754e-01
    z[6,7,4]  R2619     -3.8552686572074890e-01
    z[6,7,4]  R2620     4.6498816460371017e-02
    z[6,7,4]  R2621     -3.8213570951484144e-04
    z[6,7,4]  R2622     -1.7301419377326965e-01
    z[6,7,4]  R2623     -6.8801701068878174e-02
    z[6,7,4]  R2624     -3.9071694016456604e-02
    z[6,7,4]  R2625     -4.2013868689537048e-01
    z[6,7,4]  R2626     4.0225276350975037e-01
    z[6,7,4]  R2627     7.1406906843185425e-01
    z[6,7,4]  R2628     4.3973532319068909e-01
    z[6,7,4]  R2629     -7.6233841478824615e-02
    z[6,7,4]  R2630     1.1470503360033035e-01
    z[6,7,4]  R2631     7.1103684604167938e-02
    z[6,7,4]  R2632     -3.1166917085647583e-01
    z[6,7,4]  R2633     3.1659644097089767e-02
    z[6,7,4]  R2634     1.4390356838703156e-01
    z[6,7,4]  R2635     2.5604346394538879e-01
    z[6,7,4]  R2636     -1.7262098193168640e-01
    z[6,7,4]  R2637     -1.1364775896072388e-01
    z[6,7,4]  R2638     -3.3513152599334717e-01
    z[6,7,4]  R2639     1.1817936599254608e-01
    z[6,7,4]  R2640     -1.2361352145671844e-01
    z[6,7,4]  R2641     2.6135078072547913e-01
    z[6,7,4]  R2642     3.0776894092559814e-01
    z[6,7,4]  R2643     4.1240427643060684e-02
    z[6,7,4]  R2644     -1.6916111111640930e-01
    z[6,7,4]  R2645     3.8667380809783936e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2512     -1
    z[6,7,5]  R2513     1
    z[6,7,5]  R2516     2.3018307983875275e-01
    z[6,7,5]  R2517     1.7263543605804443e-01
    z[6,7,5]  R2518     5.5181562900543213e-01
    z[6,7,5]  R2519     3.4368079900741577e-01
    z[6,7,5]  R2520     7.0261436700820923e-01
    z[6,7,5]  R2521     4.7340282797813416e-01
    z[6,7,5]  R2522     -2.5899496674537659e-01
    z[6,7,5]  R2523     5.5541670322418213e-01
    z[6,7,5]  R2524     4.8063647747039795e-01
    z[6,7,5]  R2525     3.3625525236129761e-01
    z[6,7,5]  R2526     1.1956129968166351e-01
    z[6,7,5]  R2527     -3.9061307907104492e-02
    z[6,7,5]  R2528     -2.4524421989917755e-01
    z[6,7,5]  R2529     -1.1231366544961929e-01
    z[6,7,5]  R2530     1.6097915172576904e-01
    z[6,7,5]  R2531     -8.4550447762012482e-02
    z[6,7,5]  R2532     -6.6976338624954224e-02
    z[6,7,5]  R2533     -1.4751136302947998e-01
    z[6,7,5]  R2534     2.2243642807006836e-01
    z[6,7,5]  R2535     -2.1594022214412689e-01
    z[6,7,5]  R2536     9.0554483234882355e-02
    z[6,7,5]  R2537     3.4834283590316772e-01
    z[6,7,5]  R2538     4.0248975157737732e-02
    z[6,7,5]  R2539     -1.4654375612735748e-02
    z[6,7,5]  R2540     1.6400316357612610e-01
    z[6,7,5]  R2541     -2.3947756737470627e-02
    z[6,7,5]  R2542     6.5748989582061768e-02
    z[6,7,5]  R2543     5.3899574279785156e-01
    z[6,7,5]  R2544     1.7916370928287506e-01
    z[6,7,5]  R2545     7.7944636344909668e-01
    z[6,7,5]  R2546     3.2812169194221497e-01
    z[6,7,5]  R2547     -2.5396534800529480e-01
    z[6,7,5]  R2548     -1.5706744790077209e-01
    z[6,7,5]  R2549     -7.3487579822540283e-02
    z[6,7,5]  R2550     3.1989347189664841e-02
    z[6,7,5]  R2551     -2.9093673825263977e-01
    z[6,7,5]  R2552     -1.1443016678094864e-01
    z[6,7,5]  R2553     -4.5611268281936646e-01
    z[6,7,5]  R2554     -3.9596292376518250e-01
    z[6,7,5]  R2555     3.6357650160789490e-01
    z[6,7,5]  R2556     -2.4460119009017944e-01
    z[6,7,5]  R2557     -2.2914563119411469e-01
    z[6,7,5]  R2558     -1.7768631875514984e-01
    z[6,7,5]  R2559     -1.5092007815837860e-01
    z[6,7,5]  R2560     4.6170303225517273e-01
    z[6,7,5]  R2561     1.8440628051757812e-01
    z[6,7,5]  R2562     2.1487553417682648e-01
    z[6,7,5]  R2563     1.4064885675907135e-01
    z[6,7,5]  R2564     7.8019447624683380e-02
    z[6,7,5]  R2565     -9.2405569553375244e-01
    z[6,7,5]  R2566     1.0758799314498901e-01
    z[6,7,5]  R2567     2.9926860332489014e-01
    z[6,7,5]  R2568     -5.7398641109466553e-01
    z[6,7,5]  R2569     -7.5456231832504272e-01
    z[6,7,5]  R2570     -8.5650849342346191e-01
    z[6,7,5]  R2571     -4.2700063437223434e-02
    z[6,7,5]  R2572     -1.5010915696620941e-01
    z[6,7,5]  R2573     3.0066564679145813e-01
    z[6,7,5]  R2574     -5.5725187063217163e-01
    z[6,7,5]  R2575     -6.9269603490829468e-01
    z[6,7,5]  R2576     0.00815114751458168
    z[6,7,5]  R2577     1.6097424924373627e-01
    z[6,7,5]  R2578     -2.4331073462963104e-01
    z[6,7,5]  R2579     -2.3352622985839844e-01
    z[6,7,5]  R2580     -2.2083316743373871e-01
    z[6,7,5]  R2581     -5.2200831472873688e-02
    z[6,7,5]  R2582     5.9199732542037964e-01
    z[6,7,5]  R2583     3.0169311165809631e-01
    z[6,7,5]  R2584     1.8120923638343811e-01
    z[6,7,5]  R2585     -1.6136570274829865e-01
    z[6,7,5]  R2586     -3.1965515017509460e-01
    z[6,7,5]  R2587     -3.1550022959709167e-01
    z[6,7,5]  R2588     -2.1198825538158417e-01
    z[6,7,5]  R2589     -4.0874508023262024e-01
    z[6,7,5]  R2590     -2.1739758551120758e-01
    z[6,7,5]  R2591     -1.3742758333683014e-01
    z[6,7,5]  R2592     -3.5361200571060181e-01
    z[6,7,5]  R2593     -3.7164643406867981e-01
    z[6,7,5]  R2594     -3.7035247683525085e-01
    z[6,7,5]  R2595     -5.2202105522155762e-01
    z[6,7,5]  R2596     3.2202634215354919e-01
    z[6,7,5]  R2597     -1.7131336033344269e-01
    z[6,7,5]  R2598     -3.4875169396400452e-01
    z[6,7,5]  R2599     1.1485569924116135e-01
    z[6,7,5]  R2600     2.5832670927047729e-01
    z[6,7,5]  R2601     1.6578520834445953e-01
    z[6,7,5]  R2602     1.6976547241210938e-01
    z[6,7,5]  R2603     5.2896046638488770e-01
    z[6,7,5]  R2604     5.3319811820983887e-01
    z[6,7,5]  R2605     -7.9358108341693878e-03
    z[6,7,5]  R2606     4.1155338287353516e-01
    z[6,7,5]  R2607     5.7823747396469116e-01
    z[6,7,5]  R2608     -2.5613831356167793e-02
    z[6,7,5]  R2609     5.0028479099273682e-01
    z[6,7,5]  R2610     -1.8670815974473953e-02
    z[6,7,5]  R2611     1.6047197580337524e-01
    z[6,7,5]  R2612     3.6025676876306534e-02
    z[6,7,5]  R2613     1.9604517519474030e-01
    z[6,7,5]  R2614     -0.429318368434906
    z[6,7,5]  R2615     -1.7985065281391144e-01
    z[6,7,5]  R2616     -5.0258863717317581e-02
    z[6,7,5]  R2617     -0.50553959608078
    z[6,7,5]  R2618     -4.1002359986305237e-01
    z[6,7,5]  R2619     -2.0191858708858490e-01
    z[6,7,5]  R2620     1.1014650017023087e-01
    z[6,7,5]  R2621     -2.7247246354818344e-02
    z[6,7,5]  R2622     -6.9881081581115723e-02
    z[6,7,5]  R2623     2.1768143773078918e-01
    z[6,7,5]  R2624     -6.6732531785964966e-01
    z[6,7,5]  R2625     -6.9999217987060547e-01
    z[6,7,5]  R2626     4.3726280331611633e-01
    z[6,7,5]  R2627     1.4854957163333893e-01
    z[6,7,5]  R2628     1.5420123934745789e-01
    z[6,7,5]  R2629     -0.094334177672863
    z[6,7,5]  R2630     -2.8806936740875244e-01
    z[6,7,5]  R2631     3.0473349615931511e-02
    z[6,7,5]  R2632     7.1793437004089355e-02
    z[6,7,5]  R2633     -1.9304917752742767e-01
    z[6,7,5]  R2634     1.3385677337646484e-01
    z[6,7,5]  R2635     1.9853435456752777e-01
    z[6,7,5]  R2636     4.3308857083320618e-01
    z[6,7,5]  R2637     0.0741511881351471
    z[6,7,5]  R2638     -4.2723512649536133e-01
    z[6,7,5]  R2639     5.9995427727699280e-02
    z[6,7,5]  R2640     -3.5500192642211914e-01
    z[6,7,5]  R2641     2.8033751249313354e-01
    z[6,7,5]  R2642     -1.9317139685153961e-01
    z[6,7,5]  R2643     4.1094236075878143e-02
    z[6,7,5]  R2644     -2.1376991271972656e-01
    z[6,7,5]  R2645     -1.1652937391772866e-03
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2514     -1
    z[6,7,6]  R2515     1
    z[6,7,6]  R2516     -4.0954638272523880e-02
    z[6,7,6]  R2517     2.1268339827656746e-02
    z[6,7,6]  R2518     5.2315339446067810e-02
    z[6,7,6]  R2519     1.3736955821514130e-01
    z[6,7,6]  R2520     8.0335631966590881e-02
    z[6,7,6]  R2521     6.7857488989830017e-02
    z[6,7,6]  R2522     -4.8399096727371216e-01
    z[6,7,6]  R2523     -2.2590938210487366e-01
    z[6,7,6]  R2524     -4.9066364765167236e-01
    z[6,7,6]  R2525     -3.8394466042518616e-01
    z[6,7,6]  R2526     7.4578978121280670e-02
    z[6,7,6]  R2527     -1.4473941922187805e-01
    z[6,7,6]  R2528     2.3746220767498016e-01
    z[6,7,6]  R2529     3.3301338553428650e-01
    z[6,7,6]  R2530     -2.6124054193496704e-01
    z[6,7,6]  R2531     1.8263176083564758e-01
    z[6,7,6]  R2532     2.8792208433151245e-01
    z[6,7,6]  R2533     -2.5502455234527588e-01
    z[6,7,6]  R2534     -2.1545359492301941e-01
    z[6,7,6]  R2535     1.5662631392478943e-01
    z[6,7,6]  R2536     2.4414452910423279e-01
    z[6,7,6]  R2537     2.9341778159141541e-01
    z[6,7,6]  R2538     5.1917475461959839e-01
    z[6,7,6]  R2539     2.1874819695949554e-01
    z[6,7,6]  R2540     3.8928383588790894e-01
    z[6,7,6]  R2541     1.6137449443340302e-01
    z[6,7,6]  R2542     -4.5322526246309280e-02
    z[6,7,6]  R2543     -5.1023606210947037e-02
    z[6,7,6]  R2544     2.8241056948900223e-02
    z[6,7,6]  R2545     1.1728116311132908e-02
    z[6,7,6]  R2546     -2.7198362350463867e-01
    z[6,7,6]  R2547     5.1151126623153687e-01
    z[6,7,6]  R2548     3.8859617710113525e-01
    z[6,7,6]  R2549     -2.7948606014251709e-01
    z[6,7,6]  R2550     -3.1858119368553162e-01
    z[6,7,6]  R2551     1.7168654501438141e-01
    z[6,7,6]  R2552     -1.9448006525635719e-02
    z[6,7,6]  R2553     -0.180596262216568
    z[6,7,6]  R2554     -3.0839884281158447e-01
    z[6,7,6]  R2555     4.3326136469841003e-01
    z[6,7,6]  R2556     -2.0089246332645416e-02
    z[6,7,6]  R2557     2.4173586070537567e-01
    z[6,7,6]  R2558     -2.3494267463684082e-01
    z[6,7,6]  R2559     -1.1058136820793152e-01
    z[6,7,6]  R2560     -4.3667659163475037e-01
    z[6,7,6]  R2561     5.4727697372436523e-01
    z[6,7,6]  R2562     2.4932242929935455e-02
    z[6,7,6]  R2563     5.4051667451858521e-01
    z[6,7,6]  R2564     -1.3933502137660980e-01
    z[6,7,6]  R2565     -1.6211152076721191e-01
    z[6,7,6]  R2566     5.6706565618515015e-01
    z[6,7,6]  R2567     3.9679959416389465e-02
    z[6,7,6]  R2568     -2.1805323660373688e-01
    z[6,7,6]  R2569     2.0046980679035187e-01
    z[6,7,6]  R2570     4.9520316533744335e-03
    z[6,7,6]  R2571     -3.3127307891845703e-01
    z[6,7,6]  R2572     7.9868882894515991e-01
    z[6,7,6]  R2573     1.1968600749969482e-01
    z[6,7,6]  R2574     1.0809897631406784e-01
    z[6,7,6]  R2575     -1.2872619926929474e-01
    z[6,7,6]  R2576     -8.5424654185771942e-02
    z[6,7,6]  R2577     1.4204651117324829e-01
    z[6,7,6]  R2578     -3.1563821434974670e-01
    z[6,7,6]  R2579     -3.3982202410697937e-02
    z[6,7,6]  R2580     -9.3037769198417664e-02
    z[6,7,6]  R2581     -2.5839787721633911e-01
    z[6,7,6]  R2582     -1.9042136147618294e-02
    z[6,7,6]  R2583     1.1859728395938873e-01
    z[6,7,6]  R2584     -1.7192541854456067e-03
    z[6,7,6]  R2585     -2.5719583034515381e-02
    z[6,7,6]  R2586     0.272826224565506
    z[6,7,6]  R2587     -1.4592908322811127e-01
    z[6,7,6]  R2588     0.0883352980017662
    z[6,7,6]  R2589     2.3601607978343964e-01
    z[6,7,6]  R2590     2.8957530856132507e-01
    z[6,7,6]  R2591     3.5161668062210083e-01
    z[6,7,6]  R2592     -2.2178536280989647e-02
    z[6,7,6]  R2593     -2.2910106182098389e-01
    z[6,7,6]  R2594     -0.279342383146286
    z[6,7,6]  R2595     6.8481385707855225e-02
    z[6,7,6]  R2596     2.2746691107749939e-01
    z[6,7,6]  R2597     2.7614927291870117e-01
    z[6,7,6]  R2598     -2.7461913228034973e-01
    z[6,7,6]  R2599     -4.0738663077354431e-01
    z[6,7,6]  R2600     -3.3743351697921753e-01
    z[6,7,6]  R2601     6.0053861141204834e-01
    z[6,7,6]  R2602     -2.7851322293281555e-01
    z[6,7,6]  R2603     -1.3669953681528568e-02
    z[6,7,6]  R2604     7.1014779806137085e-01
    z[6,7,6]  R2605     3.0918738245964050e-01
    z[6,7,6]  R2606     6.2395554780960083e-01
    z[6,7,6]  R2607     4.5911943912506104e-01
    z[6,7,6]  R2608     -2.8632143139839172e-01
    z[6,7,6]  R2609     1.2162868864834309e-02
    z[6,7,6]  R2610     -2.2372503578662872e-01
    z[6,7,6]  R2611     -5.6143510341644287e-01
    z[6,7,6]  R2612     5.4943454265594482e-01
    z[6,7,6]  R2613     -0.665951132774353
    z[6,7,6]  R2614     1.5840151906013489e-01
    z[6,7,6]  R2615     -2.1365078166127205e-02
    z[6,7,6]  R2616     1.5309567749500275e-01
    z[6,7,6]  R2617     4.5373108237981796e-02
    z[6,7,6]  R2618     -2.7633062005043030e-01
    z[6,7,6]  R2619     -3.1513014435768127e-01
    z[6,7,6]  R2620     -5.8834567666053772e-02
    z[6,7,6]  R2621     -1.0482275485992432e-01
    z[6,7,6]  R2622     -1.5043185651302338e-01
    z[6,7,6]  R2623     -1.1765944957733154e-01
    z[6,7,6]  R2624     1.9668446853756905e-02
    z[6,7,6]  R2625     -8.1644721329212189e-02
    z[6,7,6]  R2626     2.2319868206977844e-02
    z[6,7,6]  R2627     -2.9431256651878357e-01
    z[6,7,6]  R2628     3.7668031454086304e-01
    z[6,7,6]  R2629     -2.7511370182037354e-01
    z[6,7,6]  R2630     3.4089684486389160e-02
    z[6,7,6]  R2631     -1.6389900445938110e-01
    z[6,7,6]  R2632     2.8716831002384424e-04
    z[6,7,6]  R2633     1.8524080514907837e-01
    z[6,7,6]  R2634     -2.3157205432653427e-02
    z[6,7,6]  R2635     -3.3950844407081604e-01
    z[6,7,6]  R2636     -3.4378501772880554e-01
    z[6,7,6]  R2637     -5.8123809099197388e-01
    z[6,7,6]  R2638     -2.1278581023216248e-01
    z[6,7,6]  R2639     2.2819848358631134e-01
    z[6,7,6]  R2640     4.4436073303222656e-01
    z[6,7,6]  R2641     6.3039287924766541e-02
    z[6,7,6]  R2642     2.1365134045481682e-02
    z[6,7,6]  R2643     1.3199381530284882e-01
    z[6,7,6]  R2644     -1.1755295097827911e-01
    z[6,7,6]  R2645     -2.9218699783086777e-02
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2646     -1
    z[7,6,0]  R2647     1
    z[7,6,0]  R2660     -5.5729341506958008e-01
    z[7,6,0]  R2661     -0.570170521736145
    z[7,6,0]  R2662     -0.519062876701355
    z[7,6,0]  R2663     -1.5749590098857880e-01
    z[7,6,0]  R2664     -2.7505412697792053e-01
    z[7,6,0]  R2665     -3.7525451183319092e-01
    z[7,6,0]  R2666     2.3901455104351044e-02
    z[7,6,0]  R2667     -2.5289878249168396e-01
    z[7,6,0]  R2668     4.0116536617279053e-01
    z[7,6,0]  R2669     -1.9124847650527954e-01
    z[7,6,0]  R2670     -5.3013980388641357e-01
    z[7,6,0]  R2671     7.6019114255905151e-01
    z[7,6,0]  R2672     -2.5712382793426514e-01
    z[7,6,0]  R2673     -3.3564478158950806e-01
    z[7,6,0]  R2674     -0.532228410243988
    z[7,6,0]  R2675     7.5140100717544556e-01
    z[7,6,0]  R2676     -6.1134433746337891e-01
    z[7,6,0]  R2677     -7.5698435306549072e-01
    z[7,6,0]  R2678     -5.2028256654739380e-01
    z[7,6,0]  R2679     1.3251268863677979e-01
    z[7,6,0]  R2680     6.0195124149322510e-01
    z[7,6,0]  R2681     5.9818547964096069e-01
    z[7,6,0]  R2682     6.7245703935623169e-01
    z[7,6,0]  R2683     4.9734145402908325e-01
    z[7,6,0]  R2684     0.382784366607666
    z[7,6,0]  R2685     5.3919726610183716e-01
    z[7,6,0]  R2686     0.352083295583725
    z[7,6,0]  R2687     1.0322692990303040e-01
    z[7,6,0]  R2688     -3.5776447504758835e-02
    z[7,6,0]  R2689     -6.2972344458103180e-02
    z[7,6,0]  R2690     3.9761614799499512e-01
    z[7,6,0]  R2691     3.1109130382537842e-01
    z[7,6,0]  R2692     6.0046070814132690e-01
    z[7,6,0]  R2693     6.0410302132368088e-02
    z[7,6,0]  R2694     -4.0367566980421543e-03
    z[7,6,0]  R2695     3.0294919013977051e-01
    z[7,6,0]  R2696     5.7300585508346558e-01
    z[7,6,0]  R2697     1.5232123434543610e-01
    z[7,6,0]  R2698     -5.1245975494384766e-01
    z[7,6,0]  R2699     7.1005530655384064e-02
    z[7,6,0]  R2700     -1.8540312349796295e-01
    z[7,6,0]  R2701     -6.8541193008422852e-01
    z[7,6,0]  R2702     -2.7038168907165527e-01
    z[7,6,0]  R2703     -0.452766478061676
    z[7,6,0]  R2704     -4.6305142343044281e-02
    z[7,6,0]  R2705     -7.7871638350188732e-03
    z[7,6,0]  R2706     7.7178925275802612e-02
    z[7,6,0]  R2707     -2.6318386197090149e-01
    z[7,6,0]  R2708     2.7791216969490051e-01
    z[7,6,0]  R2709     0.000984802725724876
    z[7,6,0]  R2710     2.8282368183135986e-01
    z[7,6,0]  R2711     -2.5316581130027771e-01
    z[7,6,0]  R2712     1.2265031225979328e-02
    z[7,6,0]  R2713     -4.1162014007568359e-01
    z[7,6,0]  R2714     -2.6204910874366760e-01
    z[7,6,0]  R2715     -6.1397153139114380e-01
    z[7,6,0]  R2716     -1.5431550145149231e-01
    z[7,6,0]  R2717     2.1453516185283661e-01
    z[7,6,0]  R2718     1.5545056760311127e-01
    z[7,6,0]  R2719     -5.9662234783172607e-01
    z[7,6,0]  R2720     -1.2338148802518845e-01
    z[7,6,0]  R2721     -1.2407746165990829e-01
    z[7,6,0]  R2722     -3.0643790960311890e-01
    z[7,6,0]  R2723     2.3313535749912262e-01
    z[7,6,0]  R2724     5.5375963449478149e-01
    z[7,6,0]  R2725     -1.8920011818408966e-01
    z[7,6,0]  R2726     -5.3123313188552856e-01
    z[7,6,0]  R2727     5.9123420715332031e-01
    z[7,6,0]  R2728     5.3236150741577148e-01
    z[7,6,0]  R2729     3.4476128220558167e-01
    z[7,6,0]  R2730     -7.1324408054351807e-03
    z[7,6,0]  R2731     -0.609872043132782
    z[7,6,0]  R2732     -3.5625150799751282e-01
    z[7,6,0]  R2733     3.0565840005874634e-01
    z[7,6,0]  R2734     5.8468718081712723e-02
    z[7,6,0]  R2735     3.7295544147491455e-01
    z[7,6,0]  R2736     -4.7175645828247070e-02
    z[7,6,0]  R2737     -3.3855131268501282e-01
    z[7,6,0]  R2738     3.1291771680116653e-02
    z[7,6,0]  R2739     -2.0230922847986221e-02
    z[7,6,0]  R2740     1.5634299814701080e-01
    z[7,6,0]  R2741     3.0353438854217529e-01
    z[7,6,0]  R2742     -7.5079208612442017e-01
    z[7,6,0]  R2743     2.2267715632915497e-01
    z[7,6,0]  R2744     4.5826411247253418e-01
    z[7,6,0]  R2745     3.4416344761848450e-01
    z[7,6,0]  R2746     1.6742998361587524e-01
    z[7,6,0]  R2747     5.6998956203460693e-01
    z[7,6,0]  R2748     -7.1649444103240967e-01
    z[7,6,0]  R2749     -7.2960138320922852e-01
    z[7,6,0]  R2750     -3.8719708099961281e-03
    z[7,6,0]  R2751     0.377970814704895
    z[7,6,0]  R2752     3.6683431267738342e-01
    z[7,6,0]  R2753     5.4809135198593140e-01
    z[7,6,0]  R2754     3.9708280563354492e-01
    z[7,6,0]  R2755     2.5789085030555725e-01
    z[7,6,0]  R2756     6.8862646818161011e-01
    z[7,6,0]  R2757     -6.4441777765750885e-02
    z[7,6,0]  R2758     4.6054384112358093e-01
    z[7,6,0]  R2759     -1.5428721904754639e-01
    z[7,6,0]  R2760     -1.6341438889503479e-01
    z[7,6,0]  R2761     -3.2093605399131775e-01
    z[7,6,0]  R2762     -8.8356596231460571e-01
    z[7,6,0]  R2763     -1.7391633987426758e-01
    z[7,6,0]  R2764     -0.804546594619751
    z[7,6,0]  R2765     -8.6530953645706177e-01
    z[7,6,0]  R2766     6.3675379753112793e-01
    z[7,6,0]  R2767     -0.66482013463974
    z[7,6,0]  R2768     -6.4516210556030273e-01
    z[7,6,0]  R2769     -3.7745776772499084e-01
    z[7,6,0]  R2770     -2.4024908244609833e-01
    z[7,6,0]  R2771     -2.0745202898979187e-02
    z[7,6,0]  R2772     -3.7880662828683853e-02
    z[7,6,0]  R2773     -2.6529708504676819e-01
    z[7,6,0]  R2774     0.00278069986961782
    z[7,6,0]  R2775     -0.371847540140152
    z[7,6,0]  R2776     -8.7815326452255249e-01
    z[7,6,0]  R2777     -1.9606430083513260e-02
    z[7,6,0]  R2778     -1.5016080439090729e-01
    z[7,6,0]  R2779     2.2420510649681091e-01
    z[7,6,0]  R2780     -1.9836762547492981e-01
    z[7,6,0]  R2781     4.6706837415695190e-01
    z[7,6,0]  R2782     -1.8074283376336098e-02
    z[7,6,0]  R2783     1.8469411134719849e-01
    z[7,6,0]  R2784     -6.5395943820476532e-02
    z[7,6,0]  R2785     2.0739491283893585e-01
    z[7,6,0]  R2786     9.2153802514076233e-02
    z[7,6,0]  R2787     -3.3485004305839539e-01
    z[7,6,0]  R2788     5.7475157082080841e-02
    z[7,6,0]  R2789     8.2998253405094147e-02
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2648     -1
    z[7,6,1]  R2649     1
    z[7,6,1]  R2660     -7.3747581243515015e-01
    z[7,6,1]  R2661     -7.4708157777786255e-01
    z[7,6,1]  R2662     -7.3020076751708984e-01
    z[7,6,1]  R2663     -9.3595254421234131e-01
    z[7,6,1]  R2664     -8.7157249450683594e-01
    z[7,6,1]  R2665     -8.0742329359054565e-01
    z[7,6,1]  R2666     -1.9723260775208473e-02
    z[7,6,1]  R2667     -8.6047857999801636e-01
    z[7,6,1]  R2668     3.9040920138359070e-01
    z[7,6,1]  R2669     -8.3041661977767944e-01
    z[7,6,1]  R2670     0.418416827917099
    z[7,6,1]  R2671     5.7618740946054459e-02
    z[7,6,1]  R2672     3.9711853861808777e-01
    z[7,6,1]  R2673     3.7892201542854309e-01
    z[7,6,1]  R2674     4.4411951303482056e-01
    z[7,6,1]  R2675     -2.7559101581573486e-01
    z[7,6,1]  R2676     4.4987294077873230e-01
    z[7,6,1]  R2677     3.6728054285049438e-01
    z[7,6,1]  R2678     0.534921407699585
    z[7,6,1]  R2679     2.6610809564590454e-01
    z[7,6,1]  R2680     1.7845438420772552e-01
    z[7,6,1]  R2681     -4.6498408913612366e-01
    z[7,6,1]  R2682     -2.5442427396774292e-01
    z[7,6,1]  R2683     -4.4862989336252213e-02
    z[7,6,1]  R2684     -1.2408622354269028e-01
    z[7,6,1]  R2685     -3.0851846933364868e-01
    z[7,6,1]  R2686     -4.3527570366859436e-01
    z[7,6,1]  R2687     3.5347703844308853e-02
    z[7,6,1]  R2688     2.0681785047054291e-01
    z[7,6,1]  R2689     9.0527945756912231e-01
    z[7,6,1]  R2690     -1.1390823125839233e-01
    z[7,6,1]  R2691     3.4702695906162262e-02
    z[7,6,1]  R2692     -2.0013208687305450e-01
    z[7,6,1]  R2693     -3.1605863571166992e-01
    z[7,6,1]  R2694     -6.7666035890579224e-01
    z[7,6,1]  R2695     3.5550642013549805e-01
    z[7,6,1]  R2696     1.4513367414474487e-01
    z[7,6,1]  R2697     -1.2593352794647217e-01
    z[7,6,1]  R2698     1.0443762689828873e-01
    z[7,6,1]  R2699     9.5946002006530762e-01
    z[7,6,1]  R2700     -6.5885370969772339e-01
    z[7,6,1]  R2701     2.4410164356231689e-01
    z[7,6,1]  R2702     2.7930954098701477e-01
    z[7,6,1]  R2703     4.5855066180229187e-01
    z[7,6,1]  R2704     9.0118712186813354e-01
    z[7,6,1]  R2705     9.7862249612808228e-01
    z[7,6,1]  R2706     0.916998565196991
    z[7,6,1]  R2707     9.1740399599075317e-01
    z[7,6,1]  R2708     -5.0423923879861832e-02
    z[7,6,1]  R2709     2.1070607006549835e-01
    z[7,6,1]  R2710     -4.6093201637268066e-01
    z[7,6,1]  R2711     -5.1532387733459473e-01
    z[7,6,1]  R2712     -5.8087170124053955e-01
    z[7,6,1]  R2713     2.6048794388771057e-01
    z[7,6,1]  R2714     1.4729660749435425e-01
    z[7,6,1]  R2715     4.6828430891036987e-01
    z[7,6,1]  R2716     9.2185807228088379e-01
    z[7,6,1]  R2717     8.7684553861618042e-01
    z[7,6,1]  R2718     9.4337785243988037e-01
    z[7,6,1]  R2719     3.8790026307106018e-01
    z[7,6,1]  R2720     0.128950834274292
    z[7,6,1]  R2721     -4.7677025198936462e-01
    z[7,6,1]  R2722     5.0981199741363525e-01
    z[7,6,1]  R2723     9.1037929058074951e-01
    z[7,6,1]  R2724     1.2420173734426498e-01
    z[7,6,1]  R2725     7.7613222599029541e-01
    z[7,6,1]  R2726     7.1518266201019287e-01
    z[7,6,1]  R2727     1.3515974581241608e-01
    z[7,6,1]  R2728     -1.9805087149143219e-01
    z[7,6,1]  R2729     -4.6662919223308563e-02
    z[7,6,1]  R2730     1.1356388777494431e-01
    z[7,6,1]  R2731     -4.9036312103271484e-01
    z[7,6,1]  R2732     -0.268771767616272
    z[7,6,1]  R2733     -1.7898106575012207e-01
    z[7,6,1]  R2734     1.5737524256110191e-02
    z[7,6,1]  R2735     9.0887606143951416e-02
    z[7,6,1]  R2736     -4.1235667467117310e-01
    z[7,6,1]  R2737     1.8914127349853516e-01
    z[7,6,1]  R2738     -3.6051037907600403e-01
    z[7,6,1]  R2739     -4.4455164670944214e-01
    z[7,6,1]  R2740     5.7409924268722534e-01
    z[7,6,1]  R2741     0.521532416343689
    z[7,6,1]  R2742     4.0930244326591492e-01
    z[7,6,1]  R2743     5.2007561922073364e-01
    z[7,6,1]  R2744     6.0095995664596558e-01
    z[7,6,1]  R2745     4.5345729589462280e-01
    z[7,6,1]  R2746     5.4914832115173340e-01
    z[7,6,1]  R2747     5.0805473327636719e-01
    z[7,6,1]  R2748     5.8904081583023071e-01
    z[7,6,1]  R2749     2.8098881244659424e-01
    z[7,6,1]  R2750     -8.2848638296127319e-01
    z[7,6,1]  R2751     -6.1497098207473755e-01
    z[7,6,1]  R2752     -5.0910407304763794e-01
    z[7,6,1]  R2753     -6.8660420179367065e-01
    z[7,6,1]  R2754     -0.74765944480896
    z[7,6,1]  R2755     -7.9350328445434570e-01
    z[7,6,1]  R2756     -3.7632763385772705e-01
    z[7,6,1]  R2757     -5.1575195789337158e-01
    z[7,6,1]  R2758     -6.1419796943664551e-01
    z[7,6,1]  R2759     -3.1984734535217285e-01
    z[7,6,1]  R2760     -2.7069896459579468e-01
    z[7,6,1]  R2761     -4.9074128270149231e-01
    z[7,6,1]  R2762     8.4123871056362987e-04
    z[7,6,1]  R2763     -5.9279185533523560e-01
    z[7,6,1]  R2764     3.5964214801788330e-01
    z[7,6,1]  R2765     1.4193475246429443e-01
    z[7,6,1]  R2766     -6.0124039649963379e-01
    z[7,6,1]  R2767     0.0818859413266182
    z[7,6,1]  R2768     -5.1137939095497131e-02
    z[7,6,1]  R2769     -5.5152320861816406e-01
    z[7,6,1]  R2770     -6.5132069587707520e-01
    z[7,6,1]  R2771     -6.1464887857437134e-01
    z[7,6,1]  R2772     -2.9878202080726624e-01
    z[7,6,1]  R2773     -3.0940631031990051e-01
    z[7,6,1]  R2774     -3.6072564125061035e-01
    z[7,6,1]  R2775     -0.62802654504776
    z[7,6,1]  R2776     2.0927037298679352e-01
    z[7,6,1]  R2777     -6.8977546691894531e-01
    z[7,6,1]  R2778     -6.4189249277114868e-01
    z[7,6,1]  R2779     2.0453146100044250e-01
    z[7,6,1]  R2780     -6.6997438669204712e-01
    z[7,6,1]  R2781     -3.8101676106452942e-01
    z[7,6,1]  R2782     0.609222948551178
    z[7,6,1]  R2783     6.8127177655696869e-02
    z[7,6,1]  R2784     2.0265281200408936e-01
    z[7,6,1]  R2785     4.5337605476379395e-01
    z[7,6,1]  R2786     2.0321825146675110e-01
    z[7,6,1]  R2787     -5.7266287505626678e-02
    z[7,6,1]  R2788     1.5035147964954376e-01
    z[7,6,1]  R2789     -1.6053926199674606e-02
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2650     -1
    z[7,6,2]  R2651     1
    z[7,6,2]  R2660     0.298555850982666
    z[7,6,2]  R2661     1.8358130753040314e-01
    z[7,6,2]  R2662     1.9443720579147339e-01
    z[7,6,2]  R2663     1.5707209706306458e-01
    z[7,6,2]  R2664     -2.6619702577590942e-01
    z[7,6,2]  R2665     -1.0090090334415436e-01
    z[7,6,2]  R2666     -7.4030059576034546e-01
    z[7,6,2]  R2667     -1.6972111165523529e-01
    z[7,6,2]  R2668     -7.7183133363723755e-01
    z[7,6,2]  R2669     1.4229343831539154e-01
    z[7,6,2]  R2670     5.8528393507003784e-01
    z[7,6,2]  R2671     -3.7061061710119247e-02
    z[7,6,2]  R2672     8.3552157878875732e-01
    z[7,6,2]  R2673     4.7039976716041565e-01
    z[7,6,2]  R2674     3.7349972128868103e-01
    z[7,6,2]  R2675     5.8752644807100296e-02
    z[7,6,2]  R2676     2.3887164890766144e-01
    z[7,6,2]  R2677     2.6121550798416138e-01
    z[7,6,2]  R2678     3.0541107058525085e-01
    z[7,6,2]  R2679     7.8861457109451294e-01
    z[7,6,2]  R2680     -1.9163978099822998e-01
    z[7,6,2]  R2681     -5.1818495988845825e-01
    z[7,6,2]  R2682     -3.6145347356796265e-01
    z[7,6,2]  R2683     -5.7662930339574814e-02
    z[7,6,2]  R2684     -1.6415746882557869e-02
    z[7,6,2]  R2685     -7.3851391673088074e-02
    z[7,6,2]  R2686     -2.2096006572246552e-01
    z[7,6,2]  R2687     -5.3146738559007645e-02
    z[7,6,2]  R2688     -1.4740160107612610e-01
    z[7,6,2]  R2689     2.1982432901859283e-01
    z[7,6,2]  R2690     -3.8245442509651184e-01
    z[7,6,2]  R2691     -2.9966729879379272e-01
    z[7,6,2]  R2692     -3.2674607634544373e-01
    z[7,6,2]  R2693     -2.6593995094299316e-01
    z[7,6,2]  R2694     -4.1883742809295654e-01
    z[7,6,2]  R2695     -4.2928963899612427e-01
    z[7,6,2]  R2696     -4.4848346710205078e-01
    z[7,6,2]  R2697     -3.6271527409553528e-01
    z[7,6,2]  R2698     2.6568377017974854e-01
    z[7,6,2]  R2699     5.1571227610111237e-02
    z[7,6,2]  R2700     -5.2012479305267334e-01
    z[7,6,2]  R2701     0.430862158536911
    z[7,6,2]  R2702     6.4673972129821777e-01
    z[7,6,2]  R2703     5.3898984193801880e-01
    z[7,6,2]  R2704     1.5493386983871460e-01
    z[7,6,2]  R2705     1.5950405597686768e-01
    z[7,6,2]  R2706     1.4847847819328308e-01
    z[7,6,2]  R2707     1.4667649567127228e-01
    z[7,6,2]  R2708     6.8408769369125366e-01
    z[7,6,2]  R2709     5.0998938083648682e-01
    z[7,6,2]  R2710     -1.5722635388374329e-01
    z[7,6,2]  R2711     -1.3574923574924469e-01
    z[7,6,2]  R2712     -4.8064518719911575e-02
    z[7,6,2]  R2713     8.1105232238769531e-01
    z[7,6,2]  R2714     8.8950288295745850e-01
    z[7,6,2]  R2715     5.5517274141311646e-01
    z[7,6,2]  R2716     0.0680805891752243
    z[7,6,2]  R2717     1.5615177154541016e-01
    z[7,6,2]  R2718     1.3400849699974060e-01
    z[7,6,2]  R2719     5.0934523344039917e-01
    z[7,6,2]  R2720     -4.7807180881500244e-01
    z[7,6,2]  R2721     -5.9512192010879517e-01
    z[7,6,2]  R2722     4.7363206744194031e-01
    z[7,6,2]  R2723     2.0909920334815979e-01
    z[7,6,2]  R2724     5.8233773708343506e-01
    z[7,6,2]  R2725     -0.0377717949450016
    z[7,6,2]  R2726     -2.4989375472068787e-01
    z[7,6,2]  R2727     7.7504372596740723e-01
    z[7,6,2]  R2728     7.0783507823944092e-01
    z[7,6,2]  R2729     8.4468716382980347e-01
    z[7,6,2]  R2730     -6.6207003593444824e-01
    z[7,6,2]  R2731     -5.6170988082885742e-01
    z[7,6,2]  R2732     -4.9344068765640259e-01
    z[7,6,2]  R2733     -7.3885542154312134e-01
    z[7,6,2]  R2734     -5.0496435165405273e-01
    z[7,6,2]  R2735     -3.2723531126976013e-01
    z[7,6,2]  R2736     -6.5867567062377930e-01
    z[7,6,2]  R2737     -4.8692572116851807e-01
    z[7,6,2]  R2738     -5.9139841794967651e-01
    z[7,6,2]  R2739     -5.0206708908081055e-01
    z[7,6,2]  R2740     7.6512783765792847e-01
    z[7,6,2]  R2741     6.8397843837738037e-01
    z[7,6,2]  R2742     3.6982640624046326e-01
    z[7,6,2]  R2743     7.0460414886474609e-01
    z[7,6,2]  R2744     0.552261471748352
    z[7,6,2]  R2745     6.2330263853073120e-01
    z[7,6,2]  R2746     6.0658687353134155e-01
    z[7,6,2]  R2747     5.6052255630493164e-01
    z[7,6,2]  R2748     1.9127818942070007e-01
    z[7,6,2]  R2749     4.7686657309532166e-01
    z[7,6,2]  R2750     -2.2575299441814423e-01
    z[7,6,2]  R2751     -4.3765774369239807e-01
    z[7,6,2]  R2752     -3.4211507439613342e-01
    z[7,6,2]  R2753     -4.0068873763084412e-01
    z[7,6,2]  R2754     -1.5267378091812134e-01
    z[7,6,2]  R2755     -3.5434699058532715e-01
    z[7,6,2]  R2756     -3.5900583863258362e-01
    z[7,6,2]  R2757     -1.2537996470928192e-01
    z[7,6,2]  R2758     -1.0073851794004440e-01
    z[7,6,2]  R2759     -3.6328250169754028e-01
    z[7,6,2]  R2760     -5.9387695789337158e-01
    z[7,6,2]  R2761     -3.5038021206855774e-01
    z[7,6,2]  R2762     -9.6438162028789520e-02
    z[7,6,2]  R2763     -4.6328902244567871e-01
    z[7,6,2]  R2764     -2.7555164694786072e-01
    z[7,6,2]  R2765     1.7317138612270355e-01
    z[7,6,2]  R2766     -3.0879771709442139e-01
    z[7,6,2]  R2767     -4.7949111461639404e-01
    z[7,6,2]  R2768     -4.8743149638175964e-01
    z[7,6,2]  R2769     2.0412076264619827e-02
    z[7,6,2]  R2770     -0.616512656211853
    z[7,6,2]  R2771     -5.6968605518341064e-01
    z[7,6,2]  R2772     -5.5516713857650757e-01
    z[7,6,2]  R2773     -5.1011794805526733e-01
    z[7,6,2]  R2774     -6.2455916404724121e-01
    z[7,6,2]  R2775     -2.4228592216968536e-01
    z[7,6,2]  R2776     2.3195035755634308e-01
    z[7,6,2]  R2777     -3.4269922971725464e-01
    z[7,6,2]  R2778     -4.9695184826850891e-01
    z[7,6,2]  R2779     1.2902058660984039e-01
    z[7,6,2]  R2780     -2.7538421750068665e-01
    z[7,6,2]  R2781     -2.1320012211799622e-01
    z[7,6,2]  R2782     4.7804632782936096e-01
    z[7,6,2]  R2783     5.1289552450180054e-01
    z[7,6,2]  R2784     4.1988608241081238e-01
    z[7,6,2]  R2785     -1.2099956721067429e-01
    z[7,6,2]  R2786     -4.5156544446945190e-01
    z[7,6,2]  R2787     -6.2282466888427734e-01
    z[7,6,2]  R2788     2.7554255723953247e-01
    z[7,6,2]  R2789     3.4326678514480591e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2652     -1
    z[7,6,3]  R2653     1
    z[7,6,3]  R2660     2.1336081624031067e-01
    z[7,6,3]  R2661     7.9396776854991913e-03
    z[7,6,3]  R2662     -1.5130911953747272e-02
    z[7,6,3]  R2663     -8.4489017724990845e-02
    z[7,6,3]  R2664     1.9082543253898621e-01
    z[7,6,3]  R2665     0.310305118560791
    z[7,6,3]  R2666     1.1281483806669712e-02
    z[7,6,3]  R2667     2.4558851122856140e-01
    z[7,6,3]  R2668     2.4062691628932953e-01
    z[7,6,3]  R2669     3.6169907450675964e-01
    z[7,6,3]  R2670     -9.5866424089763314e-05
    z[7,6,3]  R2671     6.2737171538174152e-03
    z[7,6,3]  R2672     -4.9242008477449417e-02
    z[7,6,3]  R2673     -8.9440263807773590e-02
    z[7,6,3]  R2674     -1.2167779356241226e-01
    z[7,6,3]  R2675     1.7906905710697174e-01
    z[7,6,3]  R2676     1.5895548462867737e-01
    z[7,6,3]  R2677     -9.5122829079627991e-02
    z[7,6,3]  R2678     -7.8436203300952911e-02
    z[7,6,3]  R2679     6.6721066832542419e-03
    z[7,6,3]  R2680     3.1728571653366089e-01
    z[7,6,3]  R2681     -1.3364253938198090e-01
    z[7,6,3]  R2682     -4.9848143011331558e-02
    z[7,6,3]  R2683     4.1682282090187073e-01
    z[7,6,3]  R2684     6.3563042879104614e-01
    z[7,6,3]  R2685     4.5382767915725708e-01
    z[7,6,3]  R2686     6.9629192352294922e-01
    z[7,6,3]  R2687     7.9223698377609253e-01
    z[7,6,3]  R2688     3.2487702369689941e-01
    z[7,6,3]  R2689     -1.7021021246910095e-01
    z[7,6,3]  R2690     3.3239468932151794e-01
    z[7,6,3]  R2691     1.1013448238372803e-01
    z[7,6,3]  R2692     5.5118042975664139e-02
    z[7,6,3]  R2693     7.5845491886138916e-01
    z[7,6,3]  R2694     -4.6045112609863281e-01
    z[7,6,3]  R2695     1.1464538425207138e-01
    z[7,6,3]  R2696     -2.7030047774314880e-01
    z[7,6,3]  R2697     5.3859239816665649e-01
    z[7,6,3]  R2698     2.4339058995246887e-01
    z[7,6,3]  R2699     -1.8081294000148773e-01
    z[7,6,3]  R2700     -4.1440117359161377e-01
    z[7,6,3]  R2701     1.3351282104849815e-02
    z[7,6,3]  R2702     1.4195926487445831e-01
    z[7,6,3]  R2703     7.4260458350181580e-02
    z[7,6,3]  R2704     3.7941688299179077e-01
    z[7,6,3]  R2705     -0.0711718425154686
    z[7,6,3]  R2706     2.7141135931015015e-01
    z[7,6,3]  R2707     0.0403439924120903
    z[7,6,3]  R2708     -7.0779860019683838e-02
    z[7,6,3]  R2709     -1.4947031438350677e-01
    z[7,6,3]  R2710     5.7387119531631470e-01
    z[7,6,3]  R2711     -1.8258984386920929e-01
    z[7,6,3]  R2712     -5.4872053861618042e-01
    z[7,6,3]  R2713     1.2046121805906296e-01
    z[7,6,3]  R2714     1.4531119167804718e-01
    z[7,6,3]  R2715     -2.5036895275115967e-01
    z[7,6,3]  R2716     1.3941834867000580e-01
    z[7,6,3]  R2717     2.9689857363700867e-01
    z[7,6,3]  R2718     1.6956686973571777e-01
    z[7,6,3]  R2719     1.1790903657674789e-01
    z[7,6,3]  R2720     0.635644793510437
    z[7,6,3]  R2721     2.1650105714797974e-01
    z[7,6,3]  R2722     -2.8590098023414612e-01
    z[7,6,3]  R2723     5.9115849435329437e-02
    z[7,6,3]  R2724     -6.6254511475563049e-03
    z[7,6,3]  R2725     -0.457742303609848
    z[7,6,3]  R2726     1.0660663992166519e-01
    z[7,6,3]  R2727     1.0329223424196243e-01
    z[7,6,3]  R2728     2.9699310660362244e-01
    z[7,6,3]  R2729     1.2285843491554260e-01
    z[7,6,3]  R2730     7.0285123586654663e-01
    z[7,6,3]  R2731     -1.7225007712841034e-01
    z[7,6,3]  R2732     4.4561344385147095e-01
    z[7,6,3]  R2733     3.9838501811027527e-01
    z[7,6,3]  R2734     3.7805780768394470e-01
    z[7,6,3]  R2735     6.2986296415328979e-01
    z[7,6,3]  R2736     -1.2511213123798370e-01
    z[7,6,3]  R2737     0.42557492852211
    z[7,6,3]  R2738     -1.0559994727373123e-01
    z[7,6,3]  R2739     2.1751316264271736e-02
    z[7,6,3]  R2740     1.7642891407012939e-01
    z[7,6,3]  R2741     2.7874562144279480e-01
    z[7,6,3]  R2742     1.1768934130668640e-01
    z[7,6,3]  R2743     0.139877051115036
    z[7,6,3]  R2744     1.7006102204322815e-01
    z[7,6,3]  R2745     4.9650269746780396e-01
    z[7,6,3]  R2746     4.2137256264686584e-01
    z[7,6,3]  R2747     1.0021498799324036e-01
    z[7,6,3]  R2748     5.2976712584495544e-02
    z[7,6,3]  R2749     2.5871220976114273e-02
    z[7,6,3]  R2750     -4.0048643946647644e-01
    z[7,6,3]  R2751     -2.1492913365364075e-01
    z[7,6,3]  R2752     -1.8450836837291718e-01
    z[7,6,3]  R2753     1.2105809897184372e-01
    z[7,6,3]  R2754     -1.1410713195800781e-01
    z[7,6,3]  R2755     2.2164495661854744e-02
    z[7,6,3]  R2756     -4.1962409019470215e-01
    z[7,6,3]  R2757     -4.3861925601959229e-01
    z[7,6,3]  R2758     -5.0154322385787964e-01
    z[7,6,3]  R2759     -3.6153492331504822e-01
    z[7,6,3]  R2760     -5.6492835283279419e-01
    z[7,6,3]  R2761     -0.350996732711792
    z[7,6,3]  R2762     7.1377992630004883e-02
    z[7,6,3]  R2763     -3.6774033308029175e-01
    z[7,6,3]  R2764     1.1131998151540756e-01
    z[7,6,3]  R2765     -2.9271697998046875e-01
    z[7,6,3]  R2766     -3.3724820613861084e-01
    z[7,6,3]  R2767     1.0116033256053925e-01
    z[7,6,3]  R2768     2.8972604870796204e-01
    z[7,6,3]  R2769     -2.9796159267425537e-01
    z[7,6,3]  R2770     -2.4730089306831360e-01
    z[7,6,3]  R2771     -3.6283436417579651e-01
    z[7,6,3]  R2772     -6.5098208189010620e-01
    z[7,6,3]  R2773     -6.8950426578521729e-01
    z[7,6,3]  R2774     -2.6326560974121094e-01
    z[7,6,3]  R2775     -2.6847904920578003e-01
    z[7,6,3]  R2776     -1.8104347586631775e-01
    z[7,6,3]  R2777     2.9219800233840942e-01
    z[7,6,3]  R2778     5.3422415256500244e-01
    z[7,6,3]  R2779     9.3962311744689941e-02
    z[7,6,3]  R2780     -3.1924274563789368e-01
    z[7,6,3]  R2781     -6.8487578630447388e-01
    z[7,6,3]  R2782     -1.2396093457937241e-01
    z[7,6,3]  R2783     1.1860295385122299e-01
    z[7,6,3]  R2784     -3.6851714830845594e-03
    z[7,6,3]  R2785     3.0113914608955383e-01
    z[7,6,3]  R2786     2.2926524281501770e-01
    z[7,6,3]  R2787     2.7679237723350525e-01
    z[7,6,3]  R2788     -5.6929498910903931e-01
    z[7,6,3]  R2789     -5.3526127338409424e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2654     -1
    z[7,6,4]  R2655     1
    z[7,6,4]  R2660     5.9422351419925690e-02
    z[7,6,4]  R2661     -1.9214452803134918e-01
    z[7,6,4]  R2662     2.2768998518586159e-02
    z[7,6,4]  R2663     -1.0811345279216766e-01
    z[7,6,4]  R2664     2.8450158424675465e-03
    z[7,6,4]  R2665     -1.7688177525997162e-01
    z[7,6,4]  R2666     3.1629720330238342e-01
    z[7,6,4]  R2667     3.7627778947353363e-02
    z[7,6,4]  R2668     -1.3504016213119030e-02
    z[7,6,4]  R2669     -3.0993264913558960e-01
    z[7,6,4]  R2670     -1.5718884766101837e-01
    z[7,6,4]  R2671     5.4455578327178955e-01
    z[7,6,4]  R2672     -1.5139667689800262e-01
    z[7,6,4]  R2673     -5.4010105133056641e-01
    z[7,6,4]  R2674     -4.8380544781684875e-01
    z[7,6,4]  R2675     4.2592003941535950e-01
    z[7,6,4]  R2676     -4.6477150917053223e-01
    z[7,6,4]  R2677     1.5552908182144165e-01
    z[7,6,4]  R2678     -0.358530193567276
    z[7,6,4]  R2679     -1.1168579757213593e-01
    z[7,6,4]  R2680     5.5943781137466431e-01
    z[7,6,4]  R2681     1.8434017896652222e-01
    z[7,6,4]  R2682     3.9101520180702209e-01
    z[7,6,4]  R2683     6.2802612781524658e-01
    z[7,6,4]  R2684     5.0317895412445068e-01
    z[7,6,4]  R2685     1.2057242542505264e-01
    z[7,6,4]  R2686     2.1572346985340118e-01
    z[7,6,4]  R2687     -2.7864813804626465e-01
    z[7,6,4]  R2688     -2.0015962421894073e-01
    z[7,6,4]  R2689     -5.9578165411949158e-02
    z[7,6,4]  R2690     1.1606896668672562e-01
    z[7,6,4]  R2691     5.0491452217102051e-01
    z[7,6,4]  R2692     6.3793194293975830e-01
    z[7,6,4]  R2693     6.8251579068601131e-03
    z[7,6,4]  R2694     3.2291319966316223e-01
    z[7,6,4]  R2695     4.9339967966079712e-01
    z[7,6,4]  R2696     2.7060031890869141e-01
    z[7,6,4]  R2697     2.3952074348926544e-01
    z[7,6,4]  R2698     -6.2229067087173462e-01
    z[7,6,4]  R2699     7.8987866640090942e-02
    z[7,6,4]  R2700     -2.5162476301193237e-01
    z[7,6,4]  R2701     -1.6484941542148590e-01
    z[7,6,4]  R2702     -4.0740302205085754e-01
    z[7,6,4]  R2703     -3.8552686572074890e-01
    z[7,6,4]  R2704     4.6498816460371017e-02
    z[7,6,4]  R2705     -3.8213570951484144e-04
    z[7,6,4]  R2706     -1.7301419377326965e-01
    z[7,6,4]  R2707     -6.8801701068878174e-02
    z[7,6,4]  R2708     -3.9071694016456604e-02
    z[7,6,4]  R2709     -4.2013868689537048e-01
    z[7,6,4]  R2710     4.0225276350975037e-01
    z[7,6,4]  R2711     7.1406906843185425e-01
    z[7,6,4]  R2712     4.3973532319068909e-01
    z[7,6,4]  R2713     -7.6233841478824615e-02
    z[7,6,4]  R2714     1.1470503360033035e-01
    z[7,6,4]  R2715     7.1103684604167938e-02
    z[7,6,4]  R2716     -3.1166917085647583e-01
    z[7,6,4]  R2717     3.1659644097089767e-02
    z[7,6,4]  R2718     1.4390356838703156e-01
    z[7,6,4]  R2719     2.5604346394538879e-01
    z[7,6,4]  R2720     -1.7262098193168640e-01
    z[7,6,4]  R2721     -1.1364775896072388e-01
    z[7,6,4]  R2722     -3.3513152599334717e-01
    z[7,6,4]  R2723     1.1817936599254608e-01
    z[7,6,4]  R2724     -1.2361352145671844e-01
    z[7,6,4]  R2725     2.6135078072547913e-01
    z[7,6,4]  R2726     3.0776894092559814e-01
    z[7,6,4]  R2727     4.1240427643060684e-02
    z[7,6,4]  R2728     -1.6916111111640930e-01
    z[7,6,4]  R2729     3.8667380809783936e-01
    z[7,6,4]  R2730     7.3707611300051212e-03
    z[7,6,4]  R2731     -1.1025711894035339e-01
    z[7,6,4]  R2732     2.2705543041229248e-01
    z[7,6,4]  R2733     1.8147720396518707e-01
    z[7,6,4]  R2734     3.1352239847183228e-01
    z[7,6,4]  R2735     3.4658116102218628e-01
    z[7,6,4]  R2736     -2.7731582522392273e-01
    z[7,6,4]  R2737     2.6809543371200562e-01
    z[7,6,4]  R2738     -1.9075492024421692e-01
    z[7,6,4]  R2739     -5.3753042221069336e-01
    z[7,6,4]  R2740     9.7786642611026764e-02
    z[7,6,4]  R2741     2.6051837205886841e-01
    z[7,6,4]  R2742     -4.0340710431337357e-02
    z[7,6,4]  R2743     -2.0097592473030090e-01
    z[7,6,4]  R2744     2.7689328417181969e-02
    z[7,6,4]  R2745     2.0092625170946121e-02
    z[7,6,4]  R2746     -1.9369050860404968e-01
    z[7,6,4]  R2747     0.0772441104054451
    z[7,6,4]  R2748     -6.6140934824943542e-02
    z[7,6,4]  R2749     2.9915568232536316e-01
    z[7,6,4]  R2750     1.8556652963161469e-01
    z[7,6,4]  R2751     -1.8377484381198883e-01
    z[7,6,4]  R2752     -4.2894887924194336e-01
    z[7,6,4]  R2753     6.9989293813705444e-02
    z[7,6,4]  R2754     2.6184371113777161e-01
    z[7,6,4]  R2755     3.8881441950798035e-01
    z[7,6,4]  R2756     -2.6986005902290344e-01
    z[7,6,4]  R2757     0.478142648935318
    z[7,6,4]  R2758     3.4068933129310608e-01
    z[7,6,4]  R2759     -5.9474412351846695e-02
    z[7,6,4]  R2760     -2.1574285626411438e-01
    z[7,6,4]  R2761     -2.8994113206863403e-01
    z[7,6,4]  R2762     -1.7099156975746155e-01
    z[7,6,4]  R2763     4.3007937073707581e-01
    z[7,6,4]  R2764     -1.8034437298774719e-01
    z[7,6,4]  R2765     3.6082316190004349e-02
    z[7,6,4]  R2766     1.0241910815238953e-01
    z[7,6,4]  R2767     -2.6553717255592346e-01
    z[7,6,4]  R2768     8.7884448468685150e-02
    z[7,6,4]  R2769     3.7979838252067566e-01
    z[7,6,4]  R2770     1.2877424061298370e-01
    z[7,6,4]  R2771     -2.3375539481639862e-01
    z[7,6,4]  R2772     -3.0089142918586731e-01
    z[7,6,4]  R2773     -2.5148290395736694e-01
    z[7,6,4]  R2774     8.1425786018371582e-02
    z[7,6,4]  R2775     5.4870493710041046e-02
    z[7,6,4]  R2776     2.2733654081821442e-01
    z[7,6,4]  R2777     9.5197439193725586e-02
    z[7,6,4]  R2778     -8.6993388831615448e-02
    z[7,6,4]  R2779     -4.7589138150215149e-02
    z[7,6,4]  R2780     -2.9893046244978905e-02
    z[7,6,4]  R2781     -1.7614772915840149e-01
    z[7,6,4]  R2782     -8.7283954024314880e-02
    z[7,6,4]  R2783     2.7306738495826721e-01
    z[7,6,4]  R2784     2.1143786609172821e-01
    z[7,6,4]  R2785     7.3112696409225464e-01
    z[7,6,4]  R2786     1.8248160183429718e-01
    z[7,6,4]  R2787     -5.6155747175216675e-01
    z[7,6,4]  R2788     -5.0185203552246094e-01
    z[7,6,4]  R2789     -3.0351039767265320e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2656     -1
    z[7,6,5]  R2657     1
    z[7,6,5]  R2660     0.00815114751458168
    z[7,6,5]  R2661     1.6097424924373627e-01
    z[7,6,5]  R2662     -2.4331073462963104e-01
    z[7,6,5]  R2663     -2.3352622985839844e-01
    z[7,6,5]  R2664     -2.2083316743373871e-01
    z[7,6,5]  R2665     -5.2200831472873688e-02
    z[7,6,5]  R2666     5.9199732542037964e-01
    z[7,6,5]  R2667     3.0169311165809631e-01
    z[7,6,5]  R2668     1.8120923638343811e-01
    z[7,6,5]  R2669     -1.6136570274829865e-01
    z[7,6,5]  R2670     -3.1965515017509460e-01
    z[7,6,5]  R2671     -3.1550022959709167e-01
    z[7,6,5]  R2672     -2.1198825538158417e-01
    z[7,6,5]  R2673     -4.0874508023262024e-01
    z[7,6,5]  R2674     -2.1739758551120758e-01
    z[7,6,5]  R2675     -1.3742758333683014e-01
    z[7,6,5]  R2676     -3.5361200571060181e-01
    z[7,6,5]  R2677     -3.7164643406867981e-01
    z[7,6,5]  R2678     -3.7035247683525085e-01
    z[7,6,5]  R2679     -5.2202105522155762e-01
    z[7,6,5]  R2680     3.2202634215354919e-01
    z[7,6,5]  R2681     -1.7131336033344269e-01
    z[7,6,5]  R2682     -3.4875169396400452e-01
    z[7,6,5]  R2683     1.1485569924116135e-01
    z[7,6,5]  R2684     2.5832670927047729e-01
    z[7,6,5]  R2685     1.6578520834445953e-01
    z[7,6,5]  R2686     1.6976547241210938e-01
    z[7,6,5]  R2687     5.2896046638488770e-01
    z[7,6,5]  R2688     5.3319811820983887e-01
    z[7,6,5]  R2689     -7.9358108341693878e-03
    z[7,6,5]  R2690     4.1155338287353516e-01
    z[7,6,5]  R2691     5.7823747396469116e-01
    z[7,6,5]  R2692     -2.5613831356167793e-02
    z[7,6,5]  R2693     5.0028479099273682e-01
    z[7,6,5]  R2694     -1.8670815974473953e-02
    z[7,6,5]  R2695     1.6047197580337524e-01
    z[7,6,5]  R2696     3.6025676876306534e-02
    z[7,6,5]  R2697     1.9604517519474030e-01
    z[7,6,5]  R2698     -0.429318368434906
    z[7,6,5]  R2699     -1.7985065281391144e-01
    z[7,6,5]  R2700     -5.0258863717317581e-02
    z[7,6,5]  R2701     -0.50553959608078
    z[7,6,5]  R2702     -4.1002359986305237e-01
    z[7,6,5]  R2703     -2.0191858708858490e-01
    z[7,6,5]  R2704     1.1014650017023087e-01
    z[7,6,5]  R2705     -2.7247246354818344e-02
    z[7,6,5]  R2706     -6.9881081581115723e-02
    z[7,6,5]  R2707     2.1768143773078918e-01
    z[7,6,5]  R2708     -6.6732531785964966e-01
    z[7,6,5]  R2709     -6.9999217987060547e-01
    z[7,6,5]  R2710     4.3726280331611633e-01
    z[7,6,5]  R2711     1.4854957163333893e-01
    z[7,6,5]  R2712     1.5420123934745789e-01
    z[7,6,5]  R2713     -0.094334177672863
    z[7,6,5]  R2714     -2.8806936740875244e-01
    z[7,6,5]  R2715     3.0473349615931511e-02
    z[7,6,5]  R2716     7.1793437004089355e-02
    z[7,6,5]  R2717     -1.9304917752742767e-01
    z[7,6,5]  R2718     1.3385677337646484e-01
    z[7,6,5]  R2719     1.9853435456752777e-01
    z[7,6,5]  R2720     4.3308857083320618e-01
    z[7,6,5]  R2721     0.0741511881351471
    z[7,6,5]  R2722     -4.2723512649536133e-01
    z[7,6,5]  R2723     5.9995427727699280e-02
    z[7,6,5]  R2724     -3.5500192642211914e-01
    z[7,6,5]  R2725     2.8033751249313354e-01
    z[7,6,5]  R2726     -1.9317139685153961e-01
    z[7,6,5]  R2727     4.1094236075878143e-02
    z[7,6,5]  R2728     -2.1376991271972656e-01
    z[7,6,5]  R2729     -1.1652937391772866e-03
    z[7,6,5]  R2730     2.3018307983875275e-01
    z[7,6,5]  R2731     1.7263543605804443e-01
    z[7,6,5]  R2732     5.5181562900543213e-01
    z[7,6,5]  R2733     3.4368079900741577e-01
    z[7,6,5]  R2734     7.0261436700820923e-01
    z[7,6,5]  R2735     4.7340282797813416e-01
    z[7,6,5]  R2736     -2.5899496674537659e-01
    z[7,6,5]  R2737     5.5541670322418213e-01
    z[7,6,5]  R2738     4.8063647747039795e-01
    z[7,6,5]  R2739     3.3625525236129761e-01
    z[7,6,5]  R2740     1.1956129968166351e-01
    z[7,6,5]  R2741     -3.9061307907104492e-02
    z[7,6,5]  R2742     -2.4524421989917755e-01
    z[7,6,5]  R2743     -1.1231366544961929e-01
    z[7,6,5]  R2744     1.6097915172576904e-01
    z[7,6,5]  R2745     -8.4550447762012482e-02
    z[7,6,5]  R2746     -6.6976338624954224e-02
    z[7,6,5]  R2747     -1.4751136302947998e-01
    z[7,6,5]  R2748     2.2243642807006836e-01
    z[7,6,5]  R2749     -2.1594022214412689e-01
    z[7,6,5]  R2750     9.0554483234882355e-02
    z[7,6,5]  R2751     3.4834283590316772e-01
    z[7,6,5]  R2752     4.0248975157737732e-02
    z[7,6,5]  R2753     -1.4654375612735748e-02
    z[7,6,5]  R2754     1.6400316357612610e-01
    z[7,6,5]  R2755     -2.3947756737470627e-02
    z[7,6,5]  R2756     6.5748989582061768e-02
    z[7,6,5]  R2757     5.3899574279785156e-01
    z[7,6,5]  R2758     1.7916370928287506e-01
    z[7,6,5]  R2759     7.7944636344909668e-01
    z[7,6,5]  R2760     3.2812169194221497e-01
    z[7,6,5]  R2761     -2.5396534800529480e-01
    z[7,6,5]  R2762     -1.5706744790077209e-01
    z[7,6,5]  R2763     -7.3487579822540283e-02
    z[7,6,5]  R2764     3.1989347189664841e-02
    z[7,6,5]  R2765     -2.9093673825263977e-01
    z[7,6,5]  R2766     -1.1443016678094864e-01
    z[7,6,5]  R2767     -4.5611268281936646e-01
    z[7,6,5]  R2768     -3.9596292376518250e-01
    z[7,6,5]  R2769     3.6357650160789490e-01
    z[7,6,5]  R2770     -2.4460119009017944e-01
    z[7,6,5]  R2771     -2.2914563119411469e-01
    z[7,6,5]  R2772     -1.7768631875514984e-01
    z[7,6,5]  R2773     -1.5092007815837860e-01
    z[7,6,5]  R2774     4.6170303225517273e-01
    z[7,6,5]  R2775     1.8440628051757812e-01
    z[7,6,5]  R2776     2.1487553417682648e-01
    z[7,6,5]  R2777     1.4064885675907135e-01
    z[7,6,5]  R2778     7.8019447624683380e-02
    z[7,6,5]  R2779     -9.2405569553375244e-01
    z[7,6,5]  R2780     1.0758799314498901e-01
    z[7,6,5]  R2781     2.9926860332489014e-01
    z[7,6,5]  R2782     -5.7398641109466553e-01
    z[7,6,5]  R2783     -7.5456231832504272e-01
    z[7,6,5]  R2784     -8.5650849342346191e-01
    z[7,6,5]  R2785     -4.2700063437223434e-02
    z[7,6,5]  R2786     -1.5010915696620941e-01
    z[7,6,5]  R2787     3.0066564679145813e-01
    z[7,6,5]  R2788     -5.5725187063217163e-01
    z[7,6,5]  R2789     -6.9269603490829468e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2658     -1
    z[7,6,6]  R2659     1
    z[7,6,6]  R2660     -8.5424654185771942e-02
    z[7,6,6]  R2661     1.4204651117324829e-01
    z[7,6,6]  R2662     -3.1563821434974670e-01
    z[7,6,6]  R2663     -3.3982202410697937e-02
    z[7,6,6]  R2664     -9.3037769198417664e-02
    z[7,6,6]  R2665     -2.5839787721633911e-01
    z[7,6,6]  R2666     -1.9042136147618294e-02
    z[7,6,6]  R2667     1.1859728395938873e-01
    z[7,6,6]  R2668     -1.7192541854456067e-03
    z[7,6,6]  R2669     -2.5719583034515381e-02
    z[7,6,6]  R2670     0.272826224565506
    z[7,6,6]  R2671     -1.4592908322811127e-01
    z[7,6,6]  R2672     0.0883352980017662
    z[7,6,6]  R2673     2.3601607978343964e-01
    z[7,6,6]  R2674     2.8957530856132507e-01
    z[7,6,6]  R2675     3.5161668062210083e-01
    z[7,6,6]  R2676     -2.2178536280989647e-02
    z[7,6,6]  R2677     -2.2910106182098389e-01
    z[7,6,6]  R2678     -0.279342383146286
    z[7,6,6]  R2679     6.8481385707855225e-02
    z[7,6,6]  R2680     2.2746691107749939e-01
    z[7,6,6]  R2681     2.7614927291870117e-01
    z[7,6,6]  R2682     -2.7461913228034973e-01
    z[7,6,6]  R2683     -4.0738663077354431e-01
    z[7,6,6]  R2684     -3.3743351697921753e-01
    z[7,6,6]  R2685     6.0053861141204834e-01
    z[7,6,6]  R2686     -2.7851322293281555e-01
    z[7,6,6]  R2687     -1.3669953681528568e-02
    z[7,6,6]  R2688     7.1014779806137085e-01
    z[7,6,6]  R2689     3.0918738245964050e-01
    z[7,6,6]  R2690     6.2395554780960083e-01
    z[7,6,6]  R2691     4.5911943912506104e-01
    z[7,6,6]  R2692     -2.8632143139839172e-01
    z[7,6,6]  R2693     1.2162868864834309e-02
    z[7,6,6]  R2694     -2.2372503578662872e-01
    z[7,6,6]  R2695     -5.6143510341644287e-01
    z[7,6,6]  R2696     5.4943454265594482e-01
    z[7,6,6]  R2697     -0.665951132774353
    z[7,6,6]  R2698     1.5840151906013489e-01
    z[7,6,6]  R2699     -2.1365078166127205e-02
    z[7,6,6]  R2700     1.5309567749500275e-01
    z[7,6,6]  R2701     4.5373108237981796e-02
    z[7,6,6]  R2702     -2.7633062005043030e-01
    z[7,6,6]  R2703     -3.1513014435768127e-01
    z[7,6,6]  R2704     -5.8834567666053772e-02
    z[7,6,6]  R2705     -1.0482275485992432e-01
    z[7,6,6]  R2706     -1.5043185651302338e-01
    z[7,6,6]  R2707     -1.1765944957733154e-01
    z[7,6,6]  R2708     1.9668446853756905e-02
    z[7,6,6]  R2709     -8.1644721329212189e-02
    z[7,6,6]  R2710     2.2319868206977844e-02
    z[7,6,6]  R2711     -2.9431256651878357e-01
    z[7,6,6]  R2712     3.7668031454086304e-01
    z[7,6,6]  R2713     -2.7511370182037354e-01
    z[7,6,6]  R2714     3.4089684486389160e-02
    z[7,6,6]  R2715     -1.6389900445938110e-01
    z[7,6,6]  R2716     2.8716831002384424e-04
    z[7,6,6]  R2717     1.8524080514907837e-01
    z[7,6,6]  R2718     -2.3157205432653427e-02
    z[7,6,6]  R2719     -3.3950844407081604e-01
    z[7,6,6]  R2720     -3.4378501772880554e-01
    z[7,6,6]  R2721     -5.8123809099197388e-01
    z[7,6,6]  R2722     -2.1278581023216248e-01
    z[7,6,6]  R2723     2.2819848358631134e-01
    z[7,6,6]  R2724     4.4436073303222656e-01
    z[7,6,6]  R2725     6.3039287924766541e-02
    z[7,6,6]  R2726     2.1365134045481682e-02
    z[7,6,6]  R2727     1.3199381530284882e-01
    z[7,6,6]  R2728     -1.1755295097827911e-01
    z[7,6,6]  R2729     -2.9218699783086777e-02
    z[7,6,6]  R2730     -4.0954638272523880e-02
    z[7,6,6]  R2731     2.1268339827656746e-02
    z[7,6,6]  R2732     5.2315339446067810e-02
    z[7,6,6]  R2733     1.3736955821514130e-01
    z[7,6,6]  R2734     8.0335631966590881e-02
    z[7,6,6]  R2735     6.7857488989830017e-02
    z[7,6,6]  R2736     -4.8399096727371216e-01
    z[7,6,6]  R2737     -2.2590938210487366e-01
    z[7,6,6]  R2738     -4.9066364765167236e-01
    z[7,6,6]  R2739     -3.8394466042518616e-01
    z[7,6,6]  R2740     7.4578978121280670e-02
    z[7,6,6]  R2741     -1.4473941922187805e-01
    z[7,6,6]  R2742     2.3746220767498016e-01
    z[7,6,6]  R2743     3.3301338553428650e-01
    z[7,6,6]  R2744     -2.6124054193496704e-01
    z[7,6,6]  R2745     1.8263176083564758e-01
    z[7,6,6]  R2746     2.8792208433151245e-01
    z[7,6,6]  R2747     -2.5502455234527588e-01
    z[7,6,6]  R2748     -2.1545359492301941e-01
    z[7,6,6]  R2749     1.5662631392478943e-01
    z[7,6,6]  R2750     2.4414452910423279e-01
    z[7,6,6]  R2751     2.9341778159141541e-01
    z[7,6,6]  R2752     5.1917475461959839e-01
    z[7,6,6]  R2753     2.1874819695949554e-01
    z[7,6,6]  R2754     3.8928383588790894e-01
    z[7,6,6]  R2755     1.6137449443340302e-01
    z[7,6,6]  R2756     -4.5322526246309280e-02
    z[7,6,6]  R2757     -5.1023606210947037e-02
    z[7,6,6]  R2758     2.8241056948900223e-02
    z[7,6,6]  R2759     1.1728116311132908e-02
    z[7,6,6]  R2760     -2.7198362350463867e-01
    z[7,6,6]  R2761     5.1151126623153687e-01
    z[7,6,6]  R2762     3.8859617710113525e-01
    z[7,6,6]  R2763     -2.7948606014251709e-01
    z[7,6,6]  R2764     -3.1858119368553162e-01
    z[7,6,6]  R2765     1.7168654501438141e-01
    z[7,6,6]  R2766     -1.9448006525635719e-02
    z[7,6,6]  R2767     -0.180596262216568
    z[7,6,6]  R2768     -3.0839884281158447e-01
    z[7,6,6]  R2769     4.3326136469841003e-01
    z[7,6,6]  R2770     -2.0089246332645416e-02
    z[7,6,6]  R2771     2.4173586070537567e-01
    z[7,6,6]  R2772     -2.3494267463684082e-01
    z[7,6,6]  R2773     -1.1058136820793152e-01
    z[7,6,6]  R2774     -4.3667659163475037e-01
    z[7,6,6]  R2775     5.4727697372436523e-01
    z[7,6,6]  R2776     2.4932242929935455e-02
    z[7,6,6]  R2777     5.4051667451858521e-01
    z[7,6,6]  R2778     -1.3933502137660980e-01
    z[7,6,6]  R2779     -1.6211152076721191e-01
    z[7,6,6]  R2780     5.6706565618515015e-01
    z[7,6,6]  R2781     3.9679959416389465e-02
    z[7,6,6]  R2782     -2.1805323660373688e-01
    z[7,6,6]  R2783     2.0046980679035187e-01
    z[7,6,6]  R2784     4.9520316533744335e-03
    z[7,6,6]  R2785     -3.3127307891845703e-01
    z[7,6,6]  R2786     7.9868882894515991e-01
    z[7,6,6]  R2787     1.1968600749969482e-01
    z[7,6,6]  R2788     1.0809897631406784e-01
    z[7,6,6]  R2789     -1.2872619926929474e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,3]
 BV BND1      phi[3,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,6]
 BV BND1      phi[6,1]
 BV BND1      phi[1,7]
 BV BND1      phi[7,1]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[2,7]
 BV BND1      phi[7,2]
 BV BND1      phi[2,9]
 BV BND1      phi[3,4]
 BV BND1      phi[4,3]
 BV BND1      phi[8,3]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,3,0]
 FR BND1      z[0,3,1]
 FR BND1      z[0,3,2]
 FR BND1      z[0,3,3]
 FR BND1      z[0,3,4]
 FR BND1      z[0,3,5]
 FR BND1      z[0,3,6]
 FR BND1      z[3,0,0]
 FR BND1      z[3,0,1]
 FR BND1      z[3,0,2]
 FR BND1      z[3,0,3]
 FR BND1      z[3,0,4]
 FR BND1      z[3,0,5]
 FR BND1      z[3,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,6,0]
 FR BND1      z[1,6,1]
 FR BND1      z[1,6,2]
 FR BND1      z[1,6,3]
 FR BND1      z[1,6,4]
 FR BND1      z[1,6,5]
 FR BND1      z[1,6,6]
 FR BND1      z[6,1,0]
 FR BND1      z[6,1,1]
 FR BND1      z[6,1,2]
 FR BND1      z[6,1,3]
 FR BND1      z[6,1,4]
 FR BND1      z[6,1,5]
 FR BND1      z[6,1,6]
 FR BND1      z[1,7,0]
 FR BND1      z[1,7,1]
 FR BND1      z[1,7,2]
 FR BND1      z[1,7,3]
 FR BND1      z[1,7,4]
 FR BND1      z[1,7,5]
 FR BND1      z[1,7,6]
 FR BND1      z[7,1,0]
 FR BND1      z[7,1,1]
 FR BND1      z[7,1,2]
 FR BND1      z[7,1,3]
 FR BND1      z[7,1,4]
 FR BND1      z[7,1,5]
 FR BND1      z[7,1,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[2,7,0]
 FR BND1      z[2,7,1]
 FR BND1      z[2,7,2]
 FR BND1      z[2,7,3]
 FR BND1      z[2,7,4]
 FR BND1      z[2,7,5]
 FR BND1      z[2,7,6]
 FR BND1      z[7,2,0]
 FR BND1      z[7,2,1]
 FR BND1      z[7,2,2]
 FR BND1      z[7,2,3]
 FR BND1      z[7,2,4]
 FR BND1      z[7,2,5]
 FR BND1      z[7,2,6]
 FR BND1      z[3,4,0]
 FR BND1      z[3,4,1]
 FR BND1      z[3,4,2]
 FR BND1      z[3,4,3]
 FR BND1      z[3,4,4]
 FR BND1      z[3,4,5]
 FR BND1      z[3,4,6]
 FR BND1      z[4,3,0]
 FR BND1      z[4,3,1]
 FR BND1      z[4,3,2]
 FR BND1      z[4,3,3]
 FR BND1      z[4,3,4]
 FR BND1      z[4,3,5]
 FR BND1      z[4,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
