NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       2.0790758132934570e+00
    phi[0,1]  R89       1.7336772680282593e+00
    phi[0,1]  R90       2.6700022220611572e+00
    phi[0,1]  R91       1.3267384767532349e+00
    phi[0,1]  R92       1.4857345819473267e+00
    phi[0,1]  R93       1.9579923152923584e+00
    phi[0,1]  R94       4.2878517508506775e-01
    phi[0,1]  R95       2.4746768176555634e-01
    phi[0,1]  R96       -3.3534765243530273e-01
    phi[0,1]  R97       3.9467948675155640e-01
    phi[0,1]  R98       -9.8592466115951538e-01
    phi[0,1]  R99       -5.3472393751144409e-01
    phi[0,1]  R100      -1.8358557224273682e+00
    phi[0,1]  R101      -1.9635578393936157e+00
    phi[0,1]  R102      -6.5009564161300659e-01
    phi[0,1]  R103      -5.7508921623229980e-01
    phi[0,1]  R104      -6.9969344139099121e-01
    phi[0,1]  R105      -1.0891226530075073e+00
    phi[0,1]  R106      -3.0091669559478760e+00
    phi[0,1]  R107      -2.8232758045196533e+00
    phi[0,1]  R108      -3.2204120159149170e+00
    phi[0,1]  R109      -7.8583620488643646e-02
    phi[0,1]  R110      -2.7659997940063477e+00
    phi[0,1]  R111      -2.7136492729187012e+00
    phi[0,1]  R112      -1.6983270645141602e+00
    phi[0,1]  R113      -6.4856702089309692e-01
    phi[0,1]  R114      -2.4952642917633057e+00
    phi[0,1]  R115      -2.4015958309173584e+00
    phi[0,1]  R116      -2.5714185237884521e+00
    phi[0,1]  R117      -2.1999158859252930e+00
    phi[0,1]  R118      -1.0668712854385376e+00
    phi[0,1]  R119      -5.5346179008483887e-01
    phi[0,1]  R120      -2.2266287803649902e+00
    phi[0,1]  R121      -1.4832295179367065e+00
    phi[0,1]  R122      -0.692664384841919
    phi[0,1]  R123      -1.8919977545738220e-01
    phi[0,1]  R124      -6.1599820852279663e-01
    phi[0,1]  R125      -1.8731740713119507e+00
    phi[0,1]  R126      -2.3838498592376709e+00
    phi[0,1]  R127      -2.28676438331604
    phi[0,1]  R128      -1.5655457973480225e+00
    phi[0,1]  R129      -2.2496452331542969e+00
    phi[0,1]  R130      -1.1047999858856201e+00
    phi[0,1]  R131      -3.9112296104431152e+00
    phi[0,1]  R132      -2.0878802239894867e-01
    phi[0,1]  R133      -1.8144193887710571e+00
    phi[0,1]  R134      -5.6198197603225708e-01
    phi[0,1]  R135      -3.2846946716308594e+00
    phi[0,1]  R136      -3.6389198303222656e+00
    phi[0,1]  R137      8.5871362686157227e-01
    phi[0,1]  R138      -2.1571755409240723e+00
    phi[0,1]  R139      -8.6044591665267944e-01
    phi[0,1]  R140      -1.7498689889907837e-01
    phi[0,1]  R141      -3.0747380256652832e+00
    phi[0,1]  R142      -2.4851908683776855e+00
    phi[0,1]  R143      -3.2661199569702148e+00
    phi[0,1]  R144      -1.5259279012680054e+00
    phi[0,1]  R145      -2.0724122524261475e+00
    phi[0,1]  R146      -6.7088341712951660e-01
    phi[0,1]  R147      -1.7524101734161377e+00
    phi[0,1]  R148      2.1723256111145020e+00
    phi[0,1]  R149      -1.4818421602249146e+00
    phi[0,1]  R150      -2.7236732840538025e-01
    phi[0,1]  R151      -5.0426638126373291e-01
    phi[0,1]  R152      -7.3406076431274414e-01
    phi[0,1]  R153      -1.1358362436294556e+00
    phi[0,1]  R154      -1.5497237443923950e+00
    phi[0,1]  R155      -1.5645905733108521e+00
    phi[0,1]  R156      -2.3188908100128174e+00
    phi[0,1]  R157      -3.2849791049957275e+00
    phi[0,1]  R158      1.1891631036996841e-01
    phi[0,1]  R159      -1.6643502712249756e+00
    phi[0,1]  R160      -2.4927651882171631e+00
    phi[0,1]  R161      -2.3385400772094727e+00
    phi[0,1]  R162      -1.3907653093338013e+00
    phi[0,1]  R163      -3.7895064353942871e+00
    phi[0,1]  R164      -9.0979856252670288e-01
    phi[0,1]  R165      -1.6453093290328979e+00
    phi[0,1]  R166      8.1865197420120239e-01
    phi[0,1]  R167      1.7010173797607422e+00
    phi[0,1]  R168      -1.2764931917190552e+00
    phi[0,1]  R169      -6.2317693233489990e-01
    phi[0,1]  R170      -4.0274820327758789e+00
    phi[0,1]  R171      -1.5860296487808228e+00
    phi[0,1]  R172      8.0893862247467041e-01
    phi[0,1]  R173      1.6444036960601807e+00
    phi[0,1]  R174      7.9198122024536133e-01
    phi[0,1]  R175      1.9786010980606079e+00
    phi[0,1]  R176      8.9858734607696533e-01
    phi[0,1]  R177      -5.7812377810478210e-02
    phi[0,1]  R178      9.5445340871810913e-01
    phi[0,1]  R179      1.2998161315917969e+00
    phi[0,1]  R180      1.0465599298477173e+00
    phi[0,1]  R181      2.6158740743994713e-02
    phi[0,1]  R182      2.1373325586318970e-01
    phi[0,1]  R183      -6.8143838644027710e-01
    phi[0,1]  R184      -9.9843695759773254e-02
    phi[0,1]  R185      1.2743975222110748e-01
    phi[0,1]  R186      1.2238606810569763e-01
    phi[0,1]  R187      1.7150139808654785e+00
    phi[0,1]  R188      -1.1234804391860962e+00
    phi[0,1]  R189      -1.0450192689895630e+00
    phi[0,1]  R190      1.1121588945388794e+00
    phi[0,1]  R191      -4.6447181701660156e-01
    phi[0,1]  R192      -8.6480677127838135e-01
    phi[0,1]  R193      7.2725892066955566e-01
    phi[0,1]  R194      1.5826387405395508e+00
    phi[0,1]  R195      -2.5051634311676025e+00
    phi[0,1]  R196      -1.4275000095367432e+00
    phi[0,1]  R197      -0.590865433216095
    phi[0,1]  R198      -1.2557660341262817e+00
    phi[0,1]  R199      -1.3735866546630859e+00
    phi[0,1]  R200      -3.0288317799568176e-01
    phi[0,1]  R201      -2.3822064399719238e+00
    phi[0,1]  R202      -1.4790401458740234e+00
    phi[0,1]  R203      -1.7038631439208984e+00
    phi[0,1]  R204      -1.7806206941604614e+00
    phi[0,1]  R205      -1.3582774400711060e+00
    phi[0,1]  R206      -1.0864902734756470e+00
    phi[0,1]  R207      -2.1867434978485107e+00
    phi[0,1]  R208      -1.0920318365097046e+00
    phi[0,1]  R209      -2.7628526687622070e+00
    phi[0,1]  R210      -2.0831971168518066e+00
    phi[0,1]  R211      -1.6829729080200195e+00
    phi[0,1]  R212      -2.1751441955566406e+00
    phi[0,1]  R213      -2.3437447547912598e+00
    phi[0,1]  R214      -3.8724580407142639e-01
    phi[0,1]  R215      -0.306571900844574
    phi[0,1]  R216      5.8354310691356659e-02
    phi[0,1]  R217      -3.9608082175254822e-01
    phi[0,1]  R218      -9.7112111747264862e-02
    phi[0,1]  R219      -2.9196338653564453e+00
    phi[0,1]  R220      -1.9592336416244507e+00
    phi[0,1]  R221      -2.2466211318969727e+00
    phi[0,1]  R222      5.8903777599334717e-01
    phi[0,1]  R223      -1.0373470783233643e+00
    phi[0,1]  R224      -0.665643036365509
    phi[0,1]  R225      -7.7095907926559448e-01
    phi[0,1]  R226      1.2159402370452881e+00
    phi[0,1]  R227      1.4450672864913940e+00
    phi[0,1]  R228      -4.2596060037612915e-01
    phi[0,1]  R229      -1.3469914197921753e+00
    phi[0,1]  R230      -4.3488636612892151e-02
    phi[0,1]  R231      -7.0555508136749268e-01
    phi[0,1]  R232      5.9295517206192017e-01
    phi[0,1]  R233      -2.3364315927028656e-01
    phi[0,1]  R234      5.0910699367523193e-01
    phi[0,1]  R235      -1.2763220071792603e+00
    phi[0,1]  R236      -1.3888007402420044e+00
    phi[0,1]  R237      -4.2772921919822693e-01
    phi[0,1]  R238      3.9427958428859711e-02
    phi[0,1]  R239      -1.0137538909912109e+00
    phi[0,1]  R240      -2.6533478498458862e-01
    phi[0,1]  R241      7.0117235183715820e-01
    phi[0,1]  R242      -1.0164970159530640e+00
    phi[0,1]  R243      3.9723372459411621e-01
    phi[0,1]  R244      7.5587362051010132e-01
    phi[0,1]  R245      -4.7668302059173584e-01
    phi[0,1]  R246      4.8567700386047363e-01
    phi[0,1]  R247      5.3765308856964111e-01
    phi[0,1]  R248      -1.6315293312072754e+00
    phi[0,1]  R249      -9.6208804845809937e-01
    phi[0,1]  R250      -0.453605979681015
    phi[0,1]  R251      7.2854363918304443e-01
    phi[0,1]  R252      3.3638885617256165e-01
    phi[0,1]  R253      -4.1308665275573730e-01
    phi[0,1]  R254      9.0818881988525391e-01
    phi[0,1]  R255      -5.2399986982345581e-01
    phi[0,1]  R256      3.7004329264163971e-02
    phi[0,1]  R257      3.1211572885513306e-01
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R258      -3.0999999046325684e+00
    phi[1,0]  R259      -3.0999999046325684e+00
    phi[1,0]  R260      -2.2400000095367432e+00
    phi[1,0]  R261      -2.2400000095367432e+00
    phi[1,0]  R262      -3.0999999046325684e+00
    phi[1,0]  R263      -3.0999999046325684e+00
    phi[1,0]  R264      -2.5699999332427979e+00
    phi[1,0]  R265      -2.5699999332427979e+00
    phi[1,0]  R266      -3.0999999046325684e+00
    phi[1,0]  R267      -3.0999999046325684e+00
    phi[1,0]  R268      -2.0899999141693115e+00
    phi[1,0]  R269      -2.0899999141693115e+00
    phi[1,0]  R270      -3.0999999046325684e+00
    phi[1,0]  R271      -3.0999999046325684e+00
    phi[1,0]  R272      9.5445340871810913e-01
    phi[1,0]  R273      1.2998161315917969e+00
    phi[1,0]  R274      1.0465599298477173e+00
    phi[1,0]  R275      2.6158740743994713e-02
    phi[1,0]  R276      2.1373325586318970e-01
    phi[1,0]  R277      -6.8143838644027710e-01
    phi[1,0]  R278      -9.9843695759773254e-02
    phi[1,0]  R279      1.2743975222110748e-01
    phi[1,0]  R280      1.2238606810569763e-01
    phi[1,0]  R281      1.7150139808654785e+00
    phi[1,0]  R282      -1.1234804391860962e+00
    phi[1,0]  R283      -1.0450192689895630e+00
    phi[1,0]  R284      1.1121588945388794e+00
    phi[1,0]  R285      -4.6447181701660156e-01
    phi[1,0]  R286      -8.6480677127838135e-01
    phi[1,0]  R287      7.2725892066955566e-01
    phi[1,0]  R288      1.5826387405395508e+00
    phi[1,0]  R289      -2.5051634311676025e+00
    phi[1,0]  R290      -1.4275000095367432e+00
    phi[1,0]  R291      -0.590865433216095
    phi[1,0]  R292      -1.2557660341262817e+00
    phi[1,0]  R293      -1.3735866546630859e+00
    phi[1,0]  R294      -3.0288317799568176e-01
    phi[1,0]  R295      -2.3822064399719238e+00
    phi[1,0]  R296      -1.4790401458740234e+00
    phi[1,0]  R297      -1.7038631439208984e+00
    phi[1,0]  R298      -1.7806206941604614e+00
    phi[1,0]  R299      -1.3582774400711060e+00
    phi[1,0]  R300      -1.0864902734756470e+00
    phi[1,0]  R301      -2.1867434978485107e+00
    phi[1,0]  R302      -1.0920318365097046e+00
    phi[1,0]  R303      -2.7628526687622070e+00
    phi[1,0]  R304      -2.0831971168518066e+00
    phi[1,0]  R305      -1.6829729080200195e+00
    phi[1,0]  R306      -2.1751441955566406e+00
    phi[1,0]  R307      -2.3437447547912598e+00
    phi[1,0]  R308      -3.8724580407142639e-01
    phi[1,0]  R309      -0.306571900844574
    phi[1,0]  R310      5.8354310691356659e-02
    phi[1,0]  R311      -3.9608082175254822e-01
    phi[1,0]  R312      -9.7112111747264862e-02
    phi[1,0]  R313      -2.9196338653564453e+00
    phi[1,0]  R314      -1.9592336416244507e+00
    phi[1,0]  R315      -2.2466211318969727e+00
    phi[1,0]  R316      5.8903777599334717e-01
    phi[1,0]  R317      -1.0373470783233643e+00
    phi[1,0]  R318      -0.665643036365509
    phi[1,0]  R319      -7.7095907926559448e-01
    phi[1,0]  R320      1.2159402370452881e+00
    phi[1,0]  R321      1.4450672864913940e+00
    phi[1,0]  R322      -4.2596060037612915e-01
    phi[1,0]  R323      -1.3469914197921753e+00
    phi[1,0]  R324      -4.3488636612892151e-02
    phi[1,0]  R325      -7.0555508136749268e-01
    phi[1,0]  R326      5.9295517206192017e-01
    phi[1,0]  R327      -2.3364315927028656e-01
    phi[1,0]  R328      5.0910699367523193e-01
    phi[1,0]  R329      -1.2763220071792603e+00
    phi[1,0]  R330      -1.3888007402420044e+00
    phi[1,0]  R331      -4.2772921919822693e-01
    phi[1,0]  R332      3.9427958428859711e-02
    phi[1,0]  R333      -1.0137538909912109e+00
    phi[1,0]  R334      -2.6533478498458862e-01
    phi[1,0]  R335      7.0117235183715820e-01
    phi[1,0]  R336      -1.0164970159530640e+00
    phi[1,0]  R337      3.9723372459411621e-01
    phi[1,0]  R338      7.5587362051010132e-01
    phi[1,0]  R339      -4.7668302059173584e-01
    phi[1,0]  R340      4.8567700386047363e-01
    phi[1,0]  R341      5.3765308856964111e-01
    phi[1,0]  R342      -1.6315293312072754e+00
    phi[1,0]  R343      -9.6208804845809937e-01
    phi[1,0]  R344      -0.453605979681015
    phi[1,0]  R345      7.2854363918304443e-01
    phi[1,0]  R346      3.3638885617256165e-01
    phi[1,0]  R347      -4.1308665275573730e-01
    phi[1,0]  R348      9.0818881988525391e-01
    phi[1,0]  R349      -5.2399986982345581e-01
    phi[1,0]  R350      3.7004329264163971e-02
    phi[1,0]  R351      3.1211572885513306e-01
    phi[1,0]  R352      2.0790758132934570e+00
    phi[1,0]  R353      1.7336772680282593e+00
    phi[1,0]  R354      2.6700022220611572e+00
    phi[1,0]  R355      1.3267384767532349e+00
    phi[1,0]  R356      1.4857345819473267e+00
    phi[1,0]  R357      1.9579923152923584e+00
    phi[1,0]  R358      4.2878517508506775e-01
    phi[1,0]  R359      2.4746768176555634e-01
    phi[1,0]  R360      -3.3534765243530273e-01
    phi[1,0]  R361      3.9467948675155640e-01
    phi[1,0]  R362      -9.8592466115951538e-01
    phi[1,0]  R363      -5.3472393751144409e-01
    phi[1,0]  R364      -1.8358557224273682e+00
    phi[1,0]  R365      -1.9635578393936157e+00
    phi[1,0]  R366      -6.5009564161300659e-01
    phi[1,0]  R367      -5.7508921623229980e-01
    phi[1,0]  R368      -6.9969344139099121e-01
    phi[1,0]  R369      -1.0891226530075073e+00
    phi[1,0]  R370      -3.0091669559478760e+00
    phi[1,0]  R371      -2.8232758045196533e+00
    phi[1,0]  R372      -3.2204120159149170e+00
    phi[1,0]  R373      -7.8583620488643646e-02
    phi[1,0]  R374      -2.7659997940063477e+00
    phi[1,0]  R375      -2.7136492729187012e+00
    phi[1,0]  R376      -1.6983270645141602e+00
    phi[1,0]  R377      -6.4856702089309692e-01
    phi[1,0]  R378      -2.4952642917633057e+00
    phi[1,0]  R379      -2.4015958309173584e+00
    phi[1,0]  R380      -2.5714185237884521e+00
    phi[1,0]  R381      -2.1999158859252930e+00
    phi[1,0]  R382      -1.0668712854385376e+00
    phi[1,0]  R383      -5.5346179008483887e-01
    phi[1,0]  R384      -2.2266287803649902e+00
    phi[1,0]  R385      -1.4832295179367065e+00
    phi[1,0]  R386      -0.692664384841919
    phi[1,0]  R387      -1.8919977545738220e-01
    phi[1,0]  R388      -6.1599820852279663e-01
    phi[1,0]  R389      -1.8731740713119507e+00
    phi[1,0]  R390      -2.3838498592376709e+00
    phi[1,0]  R391      -2.28676438331604
    phi[1,0]  R392      -1.5655457973480225e+00
    phi[1,0]  R393      -2.2496452331542969e+00
    phi[1,0]  R394      -1.1047999858856201e+00
    phi[1,0]  R395      -3.9112296104431152e+00
    phi[1,0]  R396      -2.0878802239894867e-01
    phi[1,0]  R397      -1.8144193887710571e+00
    phi[1,0]  R398      -5.6198197603225708e-01
    phi[1,0]  R399      -3.2846946716308594e+00
    phi[1,0]  R400      -3.6389198303222656e+00
    phi[1,0]  R401      8.5871362686157227e-01
    phi[1,0]  R402      -2.1571755409240723e+00
    phi[1,0]  R403      -8.6044591665267944e-01
    phi[1,0]  R404      -1.7498689889907837e-01
    phi[1,0]  R405      -3.0747380256652832e+00
    phi[1,0]  R406      -2.4851908683776855e+00
    phi[1,0]  R407      -3.2661199569702148e+00
    phi[1,0]  R408      -1.5259279012680054e+00
    phi[1,0]  R409      -2.0724122524261475e+00
    phi[1,0]  R410      -6.7088341712951660e-01
    phi[1,0]  R411      -1.7524101734161377e+00
    phi[1,0]  R412      2.1723256111145020e+00
    phi[1,0]  R413      -1.4818421602249146e+00
    phi[1,0]  R414      -2.7236732840538025e-01
    phi[1,0]  R415      -5.0426638126373291e-01
    phi[1,0]  R416      -7.3406076431274414e-01
    phi[1,0]  R417      -1.1358362436294556e+00
    phi[1,0]  R418      -1.5497237443923950e+00
    phi[1,0]  R419      -1.5645905733108521e+00
    phi[1,0]  R420      -2.3188908100128174e+00
    phi[1,0]  R421      -3.2849791049957275e+00
    phi[1,0]  R422      1.1891631036996841e-01
    phi[1,0]  R423      -1.6643502712249756e+00
    phi[1,0]  R424      -2.4927651882171631e+00
    phi[1,0]  R425      -2.3385400772094727e+00
    phi[1,0]  R426      -1.3907653093338013e+00
    phi[1,0]  R427      -3.7895064353942871e+00
    phi[1,0]  R428      -9.0979856252670288e-01
    phi[1,0]  R429      -1.6453093290328979e+00
    phi[1,0]  R430      8.1865197420120239e-01
    phi[1,0]  R431      1.7010173797607422e+00
    phi[1,0]  R432      -1.2764931917190552e+00
    phi[1,0]  R433      -6.2317693233489990e-01
    phi[1,0]  R434      -4.0274820327758789e+00
    phi[1,0]  R435      -1.5860296487808228e+00
    phi[1,0]  R436      8.0893862247467041e-01
    phi[1,0]  R437      1.6444036960601807e+00
    phi[1,0]  R438      7.9198122024536133e-01
    phi[1,0]  R439      1.9786010980606079e+00
    phi[1,0]  R440      8.9858734607696533e-01
    phi[1,0]  R441      -5.7812377810478210e-02
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R442      -3.0999999046325684e+00
    phi[0,4]  R443      -3.0999999046325684e+00
    phi[0,4]  R444      -2.2400000095367432e+00
    phi[0,4]  R445      -2.2400000095367432e+00
    phi[0,4]  R446      -3.0999999046325684e+00
    phi[0,4]  R447      -3.0999999046325684e+00
    phi[0,4]  R448      -2.5699999332427979e+00
    phi[0,4]  R449      -2.5699999332427979e+00
    phi[0,4]  R450      -3.0999999046325684e+00
    phi[0,4]  R451      -3.0999999046325684e+00
    phi[0,4]  R452      -2.0899999141693115e+00
    phi[0,4]  R453      -2.0899999141693115e+00
    phi[0,4]  R454      -3.0999999046325684e+00
    phi[0,4]  R455      -3.0999999046325684e+00
    phi[0,4]  R456      2.0790758132934570e+00
    phi[0,4]  R457      1.7336772680282593e+00
    phi[0,4]  R458      2.6700022220611572e+00
    phi[0,4]  R459      1.3267384767532349e+00
    phi[0,4]  R460      1.4857345819473267e+00
    phi[0,4]  R461      1.9579923152923584e+00
    phi[0,4]  R462      4.2878517508506775e-01
    phi[0,4]  R463      2.4746768176555634e-01
    phi[0,4]  R464      -3.3534765243530273e-01
    phi[0,4]  R465      3.9467948675155640e-01
    phi[0,4]  R466      -9.8592466115951538e-01
    phi[0,4]  R467      -5.3472393751144409e-01
    phi[0,4]  R468      -1.8358557224273682e+00
    phi[0,4]  R469      -1.9635578393936157e+00
    phi[0,4]  R470      -6.5009564161300659e-01
    phi[0,4]  R471      -5.7508921623229980e-01
    phi[0,4]  R472      -6.9969344139099121e-01
    phi[0,4]  R473      -1.0891226530075073e+00
    phi[0,4]  R474      -3.0091669559478760e+00
    phi[0,4]  R475      -2.8232758045196533e+00
    phi[0,4]  R476      -3.2204120159149170e+00
    phi[0,4]  R477      -7.8583620488643646e-02
    phi[0,4]  R478      -2.7659997940063477e+00
    phi[0,4]  R479      -2.7136492729187012e+00
    phi[0,4]  R480      -1.6983270645141602e+00
    phi[0,4]  R481      -6.4856702089309692e-01
    phi[0,4]  R482      -2.4952642917633057e+00
    phi[0,4]  R483      -2.4015958309173584e+00
    phi[0,4]  R484      -2.5714185237884521e+00
    phi[0,4]  R485      -2.1999158859252930e+00
    phi[0,4]  R486      -1.0668712854385376e+00
    phi[0,4]  R487      -5.5346179008483887e-01
    phi[0,4]  R488      -2.2266287803649902e+00
    phi[0,4]  R489      -1.4832295179367065e+00
    phi[0,4]  R490      -0.692664384841919
    phi[0,4]  R491      -1.8919977545738220e-01
    phi[0,4]  R492      -6.1599820852279663e-01
    phi[0,4]  R493      -1.8731740713119507e+00
    phi[0,4]  R494      -2.3838498592376709e+00
    phi[0,4]  R495      -2.28676438331604
    phi[0,4]  R496      -1.5655457973480225e+00
    phi[0,4]  R497      -2.2496452331542969e+00
    phi[0,4]  R498      -1.1047999858856201e+00
    phi[0,4]  R499      -3.9112296104431152e+00
    phi[0,4]  R500      -2.0878802239894867e-01
    phi[0,4]  R501      -1.8144193887710571e+00
    phi[0,4]  R502      -5.6198197603225708e-01
    phi[0,4]  R503      -3.2846946716308594e+00
    phi[0,4]  R504      -3.6389198303222656e+00
    phi[0,4]  R505      8.5871362686157227e-01
    phi[0,4]  R506      -2.1571755409240723e+00
    phi[0,4]  R507      -8.6044591665267944e-01
    phi[0,4]  R508      -1.7498689889907837e-01
    phi[0,4]  R509      -3.0747380256652832e+00
    phi[0,4]  R510      -2.4851908683776855e+00
    phi[0,4]  R511      -3.2661199569702148e+00
    phi[0,4]  R512      -1.5259279012680054e+00
    phi[0,4]  R513      -2.0724122524261475e+00
    phi[0,4]  R514      -6.7088341712951660e-01
    phi[0,4]  R515      -1.7524101734161377e+00
    phi[0,4]  R516      2.1723256111145020e+00
    phi[0,4]  R517      -1.4818421602249146e+00
    phi[0,4]  R518      -2.7236732840538025e-01
    phi[0,4]  R519      -5.0426638126373291e-01
    phi[0,4]  R520      -7.3406076431274414e-01
    phi[0,4]  R521      -1.1358362436294556e+00
    phi[0,4]  R522      -1.5497237443923950e+00
    phi[0,4]  R523      -1.5645905733108521e+00
    phi[0,4]  R524      -2.3188908100128174e+00
    phi[0,4]  R525      -3.2849791049957275e+00
    phi[0,4]  R526      1.1891631036996841e-01
    phi[0,4]  R527      -1.6643502712249756e+00
    phi[0,4]  R528      -2.4927651882171631e+00
    phi[0,4]  R529      -2.3385400772094727e+00
    phi[0,4]  R530      -1.3907653093338013e+00
    phi[0,4]  R531      -3.7895064353942871e+00
    phi[0,4]  R532      -9.0979856252670288e-01
    phi[0,4]  R533      -1.6453093290328979e+00
    phi[0,4]  R534      8.1865197420120239e-01
    phi[0,4]  R535      1.7010173797607422e+00
    phi[0,4]  R536      -1.2764931917190552e+00
    phi[0,4]  R537      -6.2317693233489990e-01
    phi[0,4]  R538      -4.0274820327758789e+00
    phi[0,4]  R539      -1.5860296487808228e+00
    phi[0,4]  R540      8.0893862247467041e-01
    phi[0,4]  R541      1.6444036960601807e+00
    phi[0,4]  R542      7.9198122024536133e-01
    phi[0,4]  R543      1.9786010980606079e+00
    phi[0,4]  R544      8.9858734607696533e-01
    phi[0,4]  R545      -5.7812377810478210e-02
    phi[0,4]  R546      9.8341327905654907e-01
    phi[0,4]  R547      2.0948660373687744e+00
    phi[0,4]  R548      -3.6840125918388367e-01
    phi[0,4]  R549      2.2145066261291504e+00
    phi[0,4]  R550      1.6157926321029663e+00
    phi[0,4]  R551      1.0907759666442871e+00
    phi[0,4]  R552      -8.4334135055541992e-02
    phi[0,4]  R553      6.9346809387207031e-01
    phi[0,4]  R554      -2.6535394191741943e+00
    phi[0,4]  R555      -3.7644690275192261e-01
    phi[0,4]  R556      -1.8635175228118896e+00
    phi[0,4]  R557      -3.8741405010223389e+00
    phi[0,4]  R558      -2.4752168655395508e+00
    phi[0,4]  R559      -1.4937758445739746e-02
    phi[0,4]  R560      -2.4671635627746582e+00
    phi[0,4]  R561      -1.9044086933135986e+00
    phi[0,4]  R562      -7.7057951688766479e-01
    phi[0,4]  R563      -1.0320322513580322e+00
    phi[0,4]  R564      -4.8893445730209351e-01
    phi[0,4]  R565      -2.5546479225158691e+00
    phi[0,4]  R566      -1.1023164987564087e+00
    phi[0,4]  R567      -1.5694333314895630e+00
    phi[0,4]  R568      -1.1629192829132080e+00
    phi[0,4]  R569      -3.3400299549102783e+00
    phi[0,4]  R570      -2.3218419551849365e+00
    phi[0,4]  R571      -1.9715992212295532e+00
    phi[0,4]  R572      -2.1862585544586182e+00
    phi[0,4]  R573      -1.7571188211441040e+00
    phi[0,4]  R574      -8.9870297908782959e-01
    phi[0,4]  R575      -0.860573410987854
    phi[0,4]  R576      -9.3219071626663208e-01
    phi[0,4]  R577      -2.5157997608184814e+00
    phi[0,4]  R578      -4.8017680644989014e-01
    phi[0,4]  R579      -9.8018229007720947e-01
    phi[0,4]  R580      1.5706716775894165e+00
    phi[0,4]  R581      1.9583405256271362e+00
    phi[0,4]  R582      1.2287366390228271e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R583      -3.0999999046325684e+00
    phi[4,0]  R584      -3.0999999046325684e+00
    phi[4,0]  R585      -2.2400000095367432e+00
    phi[4,0]  R586      -2.2400000095367432e+00
    phi[4,0]  R587      -3.0999999046325684e+00
    phi[4,0]  R588      -3.0999999046325684e+00
    phi[4,0]  R589      -2.5699999332427979e+00
    phi[4,0]  R590      -2.5699999332427979e+00
    phi[4,0]  R591      -3.0999999046325684e+00
    phi[4,0]  R592      -3.0999999046325684e+00
    phi[4,0]  R593      -2.0899999141693115e+00
    phi[4,0]  R594      -2.0899999141693115e+00
    phi[4,0]  R595      -3.0999999046325684e+00
    phi[4,0]  R596      -3.0999999046325684e+00
    phi[4,0]  R597      9.8341327905654907e-01
    phi[4,0]  R598      2.0948660373687744e+00
    phi[4,0]  R599      -3.6840125918388367e-01
    phi[4,0]  R600      2.2145066261291504e+00
    phi[4,0]  R601      1.6157926321029663e+00
    phi[4,0]  R602      1.0907759666442871e+00
    phi[4,0]  R603      -8.4334135055541992e-02
    phi[4,0]  R604      6.9346809387207031e-01
    phi[4,0]  R605      -2.6535394191741943e+00
    phi[4,0]  R606      -3.7644690275192261e-01
    phi[4,0]  R607      -1.8635175228118896e+00
    phi[4,0]  R608      -3.8741405010223389e+00
    phi[4,0]  R609      -2.4752168655395508e+00
    phi[4,0]  R610      -1.4937758445739746e-02
    phi[4,0]  R611      -2.4671635627746582e+00
    phi[4,0]  R612      -1.9044086933135986e+00
    phi[4,0]  R613      -7.7057951688766479e-01
    phi[4,0]  R614      -1.0320322513580322e+00
    phi[4,0]  R615      -4.8893445730209351e-01
    phi[4,0]  R616      -2.5546479225158691e+00
    phi[4,0]  R617      -1.1023164987564087e+00
    phi[4,0]  R618      -1.5694333314895630e+00
    phi[4,0]  R619      -1.1629192829132080e+00
    phi[4,0]  R620      -3.3400299549102783e+00
    phi[4,0]  R621      -2.3218419551849365e+00
    phi[4,0]  R622      -1.9715992212295532e+00
    phi[4,0]  R623      -2.1862585544586182e+00
    phi[4,0]  R624      -1.7571188211441040e+00
    phi[4,0]  R625      -8.9870297908782959e-01
    phi[4,0]  R626      -0.860573410987854
    phi[4,0]  R627      -9.3219071626663208e-01
    phi[4,0]  R628      -2.5157997608184814e+00
    phi[4,0]  R629      -4.8017680644989014e-01
    phi[4,0]  R630      -9.8018229007720947e-01
    phi[4,0]  R631      1.5706716775894165e+00
    phi[4,0]  R632      1.9583405256271362e+00
    phi[4,0]  R633      1.2287366390228271e+00
    phi[4,0]  R634      2.0790758132934570e+00
    phi[4,0]  R635      1.7336772680282593e+00
    phi[4,0]  R636      2.6700022220611572e+00
    phi[4,0]  R637      1.3267384767532349e+00
    phi[4,0]  R638      1.4857345819473267e+00
    phi[4,0]  R639      1.9579923152923584e+00
    phi[4,0]  R640      4.2878517508506775e-01
    phi[4,0]  R641      2.4746768176555634e-01
    phi[4,0]  R642      -3.3534765243530273e-01
    phi[4,0]  R643      3.9467948675155640e-01
    phi[4,0]  R644      -9.8592466115951538e-01
    phi[4,0]  R645      -5.3472393751144409e-01
    phi[4,0]  R646      -1.8358557224273682e+00
    phi[4,0]  R647      -1.9635578393936157e+00
    phi[4,0]  R648      -6.5009564161300659e-01
    phi[4,0]  R649      -5.7508921623229980e-01
    phi[4,0]  R650      -6.9969344139099121e-01
    phi[4,0]  R651      -1.0891226530075073e+00
    phi[4,0]  R652      -3.0091669559478760e+00
    phi[4,0]  R653      -2.8232758045196533e+00
    phi[4,0]  R654      -3.2204120159149170e+00
    phi[4,0]  R655      -7.8583620488643646e-02
    phi[4,0]  R656      -2.7659997940063477e+00
    phi[4,0]  R657      -2.7136492729187012e+00
    phi[4,0]  R658      -1.6983270645141602e+00
    phi[4,0]  R659      -6.4856702089309692e-01
    phi[4,0]  R660      -2.4952642917633057e+00
    phi[4,0]  R661      -2.4015958309173584e+00
    phi[4,0]  R662      -2.5714185237884521e+00
    phi[4,0]  R663      -2.1999158859252930e+00
    phi[4,0]  R664      -1.0668712854385376e+00
    phi[4,0]  R665      -5.5346179008483887e-01
    phi[4,0]  R666      -2.2266287803649902e+00
    phi[4,0]  R667      -1.4832295179367065e+00
    phi[4,0]  R668      -0.692664384841919
    phi[4,0]  R669      -1.8919977545738220e-01
    phi[4,0]  R670      -6.1599820852279663e-01
    phi[4,0]  R671      -1.8731740713119507e+00
    phi[4,0]  R672      -2.3838498592376709e+00
    phi[4,0]  R673      -2.28676438331604
    phi[4,0]  R674      -1.5655457973480225e+00
    phi[4,0]  R675      -2.2496452331542969e+00
    phi[4,0]  R676      -1.1047999858856201e+00
    phi[4,0]  R677      -3.9112296104431152e+00
    phi[4,0]  R678      -2.0878802239894867e-01
    phi[4,0]  R679      -1.8144193887710571e+00
    phi[4,0]  R680      -5.6198197603225708e-01
    phi[4,0]  R681      -3.2846946716308594e+00
    phi[4,0]  R682      -3.6389198303222656e+00
    phi[4,0]  R683      8.5871362686157227e-01
    phi[4,0]  R684      -2.1571755409240723e+00
    phi[4,0]  R685      -8.6044591665267944e-01
    phi[4,0]  R686      -1.7498689889907837e-01
    phi[4,0]  R687      -3.0747380256652832e+00
    phi[4,0]  R688      -2.4851908683776855e+00
    phi[4,0]  R689      -3.2661199569702148e+00
    phi[4,0]  R690      -1.5259279012680054e+00
    phi[4,0]  R691      -2.0724122524261475e+00
    phi[4,0]  R692      -6.7088341712951660e-01
    phi[4,0]  R693      -1.7524101734161377e+00
    phi[4,0]  R694      2.1723256111145020e+00
    phi[4,0]  R695      -1.4818421602249146e+00
    phi[4,0]  R696      -2.7236732840538025e-01
    phi[4,0]  R697      -5.0426638126373291e-01
    phi[4,0]  R698      -7.3406076431274414e-01
    phi[4,0]  R699      -1.1358362436294556e+00
    phi[4,0]  R700      -1.5497237443923950e+00
    phi[4,0]  R701      -1.5645905733108521e+00
    phi[4,0]  R702      -2.3188908100128174e+00
    phi[4,0]  R703      -3.2849791049957275e+00
    phi[4,0]  R704      1.1891631036996841e-01
    phi[4,0]  R705      -1.6643502712249756e+00
    phi[4,0]  R706      -2.4927651882171631e+00
    phi[4,0]  R707      -2.3385400772094727e+00
    phi[4,0]  R708      -1.3907653093338013e+00
    phi[4,0]  R709      -3.7895064353942871e+00
    phi[4,0]  R710      -9.0979856252670288e-01
    phi[4,0]  R711      -1.6453093290328979e+00
    phi[4,0]  R712      8.1865197420120239e-01
    phi[4,0]  R713      1.7010173797607422e+00
    phi[4,0]  R714      -1.2764931917190552e+00
    phi[4,0]  R715      -6.2317693233489990e-01
    phi[4,0]  R716      -4.0274820327758789e+00
    phi[4,0]  R717      -1.5860296487808228e+00
    phi[4,0]  R718      8.0893862247467041e-01
    phi[4,0]  R719      1.6444036960601807e+00
    phi[4,0]  R720      7.9198122024536133e-01
    phi[4,0]  R721      1.9786010980606079e+00
    phi[4,0]  R722      8.9858734607696533e-01
    phi[4,0]  R723      -5.7812377810478210e-02
    phi[0,5]  R0        1
    phi[0,5]  R1        1
    phi[0,5]  R45       -1
    phi[0,5]  R724      -3.0999999046325684e+00
    phi[0,5]  R725      -3.0999999046325684e+00
    phi[0,5]  R726      -2.2400000095367432e+00
    phi[0,5]  R727      -2.2400000095367432e+00
    phi[0,5]  R728      -3.0999999046325684e+00
    phi[0,5]  R729      -3.0999999046325684e+00
    phi[0,5]  R730      -2.5699999332427979e+00
    phi[0,5]  R731      -2.5699999332427979e+00
    phi[0,5]  R732      -3.0999999046325684e+00
    phi[0,5]  R733      -3.0999999046325684e+00
    phi[0,5]  R734      -2.0899999141693115e+00
    phi[0,5]  R735      -2.0899999141693115e+00
    phi[0,5]  R736      -3.0999999046325684e+00
    phi[0,5]  R737      -3.0999999046325684e+00
    phi[0,5]  R738      2.0790758132934570e+00
    phi[0,5]  R739      1.7336772680282593e+00
    phi[0,5]  R740      2.6700022220611572e+00
    phi[0,5]  R741      1.3267384767532349e+00
    phi[0,5]  R742      1.4857345819473267e+00
    phi[0,5]  R743      1.9579923152923584e+00
    phi[0,5]  R744      4.2878517508506775e-01
    phi[0,5]  R745      2.4746768176555634e-01
    phi[0,5]  R746      -3.3534765243530273e-01
    phi[0,5]  R747      3.9467948675155640e-01
    phi[0,5]  R748      -9.8592466115951538e-01
    phi[0,5]  R749      -5.3472393751144409e-01
    phi[0,5]  R750      -1.8358557224273682e+00
    phi[0,5]  R751      -1.9635578393936157e+00
    phi[0,5]  R752      -6.5009564161300659e-01
    phi[0,5]  R753      -5.7508921623229980e-01
    phi[0,5]  R754      -6.9969344139099121e-01
    phi[0,5]  R755      -1.0891226530075073e+00
    phi[0,5]  R756      -3.0091669559478760e+00
    phi[0,5]  R757      -2.8232758045196533e+00
    phi[0,5]  R758      -3.2204120159149170e+00
    phi[0,5]  R759      -7.8583620488643646e-02
    phi[0,5]  R760      -2.7659997940063477e+00
    phi[0,5]  R761      -2.7136492729187012e+00
    phi[0,5]  R762      -1.6983270645141602e+00
    phi[0,5]  R763      -6.4856702089309692e-01
    phi[0,5]  R764      -2.4952642917633057e+00
    phi[0,5]  R765      -2.4015958309173584e+00
    phi[0,5]  R766      -2.5714185237884521e+00
    phi[0,5]  R767      -2.1999158859252930e+00
    phi[0,5]  R768      -1.0668712854385376e+00
    phi[0,5]  R769      -5.5346179008483887e-01
    phi[0,5]  R770      -2.2266287803649902e+00
    phi[0,5]  R771      -1.4832295179367065e+00
    phi[0,5]  R772      -0.692664384841919
    phi[0,5]  R773      -1.8919977545738220e-01
    phi[0,5]  R774      -6.1599820852279663e-01
    phi[0,5]  R775      -1.8731740713119507e+00
    phi[0,5]  R776      -2.3838498592376709e+00
    phi[0,5]  R777      -2.28676438331604
    phi[0,5]  R778      -1.5655457973480225e+00
    phi[0,5]  R779      -2.2496452331542969e+00
    phi[0,5]  R780      -1.1047999858856201e+00
    phi[0,5]  R781      -3.9112296104431152e+00
    phi[0,5]  R782      -2.0878802239894867e-01
    phi[0,5]  R783      -1.8144193887710571e+00
    phi[0,5]  R784      -5.6198197603225708e-01
    phi[0,5]  R785      -3.2846946716308594e+00
    phi[0,5]  R786      -3.6389198303222656e+00
    phi[0,5]  R787      8.5871362686157227e-01
    phi[0,5]  R788      -2.1571755409240723e+00
    phi[0,5]  R789      -8.6044591665267944e-01
    phi[0,5]  R790      -1.7498689889907837e-01
    phi[0,5]  R791      -3.0747380256652832e+00
    phi[0,5]  R792      -2.4851908683776855e+00
    phi[0,5]  R793      -3.2661199569702148e+00
    phi[0,5]  R794      -1.5259279012680054e+00
    phi[0,5]  R795      -2.0724122524261475e+00
    phi[0,5]  R796      -6.7088341712951660e-01
    phi[0,5]  R797      -1.7524101734161377e+00
    phi[0,5]  R798      2.1723256111145020e+00
    phi[0,5]  R799      -1.4818421602249146e+00
    phi[0,5]  R800      -2.7236732840538025e-01
    phi[0,5]  R801      -5.0426638126373291e-01
    phi[0,5]  R802      -7.3406076431274414e-01
    phi[0,5]  R803      -1.1358362436294556e+00
    phi[0,5]  R804      -1.5497237443923950e+00
    phi[0,5]  R805      -1.5645905733108521e+00
    phi[0,5]  R806      -2.3188908100128174e+00
    phi[0,5]  R807      -3.2849791049957275e+00
    phi[0,5]  R808      1.1891631036996841e-01
    phi[0,5]  R809      -1.6643502712249756e+00
    phi[0,5]  R810      -2.4927651882171631e+00
    phi[0,5]  R811      -2.3385400772094727e+00
    phi[0,5]  R812      -1.3907653093338013e+00
    phi[0,5]  R813      -3.7895064353942871e+00
    phi[0,5]  R814      -9.0979856252670288e-01
    phi[0,5]  R815      -1.6453093290328979e+00
    phi[0,5]  R816      8.1865197420120239e-01
    phi[0,5]  R817      1.7010173797607422e+00
    phi[0,5]  R818      -1.2764931917190552e+00
    phi[0,5]  R819      -6.2317693233489990e-01
    phi[0,5]  R820      -4.0274820327758789e+00
    phi[0,5]  R821      -1.5860296487808228e+00
    phi[0,5]  R822      8.0893862247467041e-01
    phi[0,5]  R823      1.6444036960601807e+00
    phi[0,5]  R824      7.9198122024536133e-01
    phi[0,5]  R825      1.9786010980606079e+00
    phi[0,5]  R826      8.9858734607696533e-01
    phi[0,5]  R827      -5.7812377810478210e-02
    phi[0,5]  R828      3.8366794586181641e-01
    phi[0,5]  R829      1.3445776700973511e+00
    phi[0,5]  R830      1.6221430301666260e+00
    phi[0,5]  R831      1.0565568208694458e+00
    phi[0,5]  R832      1.4058091640472412e+00
    phi[0,5]  R833      -6.7188709974288940e-01
    phi[0,5]  R834      1.0800620317459106e+00
    phi[0,5]  R835      7.0081883668899536e-01
    phi[0,5]  R836      1.5403277873992920e+00
    phi[0,5]  R837      8.6432105302810669e-01
    phi[0,5]  R838      -1.8816745281219482e+00
    phi[0,5]  R839      -4.3075603246688843e-01
    phi[0,5]  R840      2.4889285862445831e-01
    phi[0,5]  R841      -4.8190689086914062e-01
    phi[0,5]  R842      8.1806343793869019e-01
    phi[0,5]  R843      -2.3819696903228760e+00
    phi[0,5]  R844      -6.7526981234550476e-02
    phi[0,5]  R845      3.6781147122383118e-01
    phi[0,5]  R846      1.3672226667404175e-01
    phi[0,5]  R847      -1.8449516296386719e+00
    phi[0,5]  R848      -1.4144712686538696e+00
    phi[0,5]  R849      -4.5123642683029175e-01
    phi[0,5]  R850      9.7672455012798309e-02
    phi[0,5]  R851      -1.1275695562362671e+00
    phi[0,5]  R852      -1.2604030370712280e+00
    phi[0,5]  R853      -4.0946716070175171e-01
    phi[0,5]  R854      -1.5646628141403198e+00
    phi[0,5]  R855      -6.0414898395538330e-01
    phi[0,5]  R856      -1.6126250028610229e+00
    phi[0,5]  R857      -1.6807780265808105e+00
    phi[0,5]  R858      1.1445027589797974e+00
    phi[0,5]  R859      -1.1493481397628784e+00
    phi[0,5]  R860      1.0303270816802979e+00
    phi[0,5]  R861      -2.3878691196441650e+00
    phi[0,5]  R862      0.889646589756012
    phi[0,5]  R863      -2.1160848140716553e+00
    phi[0,5]  R864      -4.5015635490417480e+00
    phi[0,5]  R865      -5.3858470916748047e-01
    phi[0,5]  R866      -4.0514345169067383e+00
    phi[0,5]  R867      -1.2144057750701904e+00
    phi[0,5]  R868      6.9984000921249390e-01
    phi[0,5]  R869      1.2734032869338989e+00
    phi[0,5]  R870      -2.3474791049957275e+00
    phi[0,5]  R871      -3.7649455070495605e+00
    phi[0,5]  R872      -3.6166725158691406e+00
    phi[0,5]  R873      -1.3383241891860962e+00
    phi[0,5]  R874      -1.3237434625625610e+00
    phi[0,5]  R875      -1.0584704875946045e+00
    phi[0,5]  R876      -1.9773107767105103e+00
    phi[0,5]  R877      -2.6628782749176025e+00
    phi[5,0]  R0        -1
    phi[5,0]  R45       1
    phi[5,0]  R46       1
    phi[5,0]  R878      -3.0999999046325684e+00
    phi[5,0]  R879      -3.0999999046325684e+00
    phi[5,0]  R880      -2.2400000095367432e+00
    phi[5,0]  R881      -2.2400000095367432e+00
    phi[5,0]  R882      -3.0999999046325684e+00
    phi[5,0]  R883      -3.0999999046325684e+00
    phi[5,0]  R884      -2.5699999332427979e+00
    phi[5,0]  R885      -2.5699999332427979e+00
    phi[5,0]  R886      -3.0999999046325684e+00
    phi[5,0]  R887      -3.0999999046325684e+00
    phi[5,0]  R888      -2.0899999141693115e+00
    phi[5,0]  R889      -2.0899999141693115e+00
    phi[5,0]  R890      -3.0999999046325684e+00
    phi[5,0]  R891      -3.0999999046325684e+00
    phi[5,0]  R892      3.8366794586181641e-01
    phi[5,0]  R893      1.3445776700973511e+00
    phi[5,0]  R894      1.6221430301666260e+00
    phi[5,0]  R895      1.0565568208694458e+00
    phi[5,0]  R896      1.4058091640472412e+00
    phi[5,0]  R897      -6.7188709974288940e-01
    phi[5,0]  R898      1.0800620317459106e+00
    phi[5,0]  R899      7.0081883668899536e-01
    phi[5,0]  R900      1.5403277873992920e+00
    phi[5,0]  R901      8.6432105302810669e-01
    phi[5,0]  R902      -1.8816745281219482e+00
    phi[5,0]  R903      -4.3075603246688843e-01
    phi[5,0]  R904      2.4889285862445831e-01
    phi[5,0]  R905      -4.8190689086914062e-01
    phi[5,0]  R906      8.1806343793869019e-01
    phi[5,0]  R907      -2.3819696903228760e+00
    phi[5,0]  R908      -6.7526981234550476e-02
    phi[5,0]  R909      3.6781147122383118e-01
    phi[5,0]  R910      1.3672226667404175e-01
    phi[5,0]  R911      -1.8449516296386719e+00
    phi[5,0]  R912      -1.4144712686538696e+00
    phi[5,0]  R913      -4.5123642683029175e-01
    phi[5,0]  R914      9.7672455012798309e-02
    phi[5,0]  R915      -1.1275695562362671e+00
    phi[5,0]  R916      -1.2604030370712280e+00
    phi[5,0]  R917      -4.0946716070175171e-01
    phi[5,0]  R918      -1.5646628141403198e+00
    phi[5,0]  R919      -6.0414898395538330e-01
    phi[5,0]  R920      -1.6126250028610229e+00
    phi[5,0]  R921      -1.6807780265808105e+00
    phi[5,0]  R922      1.1445027589797974e+00
    phi[5,0]  R923      -1.1493481397628784e+00
    phi[5,0]  R924      1.0303270816802979e+00
    phi[5,0]  R925      -2.3878691196441650e+00
    phi[5,0]  R926      0.889646589756012
    phi[5,0]  R927      -2.1160848140716553e+00
    phi[5,0]  R928      -4.5015635490417480e+00
    phi[5,0]  R929      -5.3858470916748047e-01
    phi[5,0]  R930      -4.0514345169067383e+00
    phi[5,0]  R931      -1.2144057750701904e+00
    phi[5,0]  R932      6.9984000921249390e-01
    phi[5,0]  R933      1.2734032869338989e+00
    phi[5,0]  R934      -2.3474791049957275e+00
    phi[5,0]  R935      -3.7649455070495605e+00
    phi[5,0]  R936      -3.6166725158691406e+00
    phi[5,0]  R937      -1.3383241891860962e+00
    phi[5,0]  R938      -1.3237434625625610e+00
    phi[5,0]  R939      -1.0584704875946045e+00
    phi[5,0]  R940      -1.9773107767105103e+00
    phi[5,0]  R941      -2.6628782749176025e+00
    phi[5,0]  R942      2.0790758132934570e+00
    phi[5,0]  R943      1.7336772680282593e+00
    phi[5,0]  R944      2.6700022220611572e+00
    phi[5,0]  R945      1.3267384767532349e+00
    phi[5,0]  R946      1.4857345819473267e+00
    phi[5,0]  R947      1.9579923152923584e+00
    phi[5,0]  R948      4.2878517508506775e-01
    phi[5,0]  R949      2.4746768176555634e-01
    phi[5,0]  R950      -3.3534765243530273e-01
    phi[5,0]  R951      3.9467948675155640e-01
    phi[5,0]  R952      -9.8592466115951538e-01
    phi[5,0]  R953      -5.3472393751144409e-01
    phi[5,0]  R954      -1.8358557224273682e+00
    phi[5,0]  R955      -1.9635578393936157e+00
    phi[5,0]  R956      -6.5009564161300659e-01
    phi[5,0]  R957      -5.7508921623229980e-01
    phi[5,0]  R958      -6.9969344139099121e-01
    phi[5,0]  R959      -1.0891226530075073e+00
    phi[5,0]  R960      -3.0091669559478760e+00
    phi[5,0]  R961      -2.8232758045196533e+00
    phi[5,0]  R962      -3.2204120159149170e+00
    phi[5,0]  R963      -7.8583620488643646e-02
    phi[5,0]  R964      -2.7659997940063477e+00
    phi[5,0]  R965      -2.7136492729187012e+00
    phi[5,0]  R966      -1.6983270645141602e+00
    phi[5,0]  R967      -6.4856702089309692e-01
    phi[5,0]  R968      -2.4952642917633057e+00
    phi[5,0]  R969      -2.4015958309173584e+00
    phi[5,0]  R970      -2.5714185237884521e+00
    phi[5,0]  R971      -2.1999158859252930e+00
    phi[5,0]  R972      -1.0668712854385376e+00
    phi[5,0]  R973      -5.5346179008483887e-01
    phi[5,0]  R974      -2.2266287803649902e+00
    phi[5,0]  R975      -1.4832295179367065e+00
    phi[5,0]  R976      -0.692664384841919
    phi[5,0]  R977      -1.8919977545738220e-01
    phi[5,0]  R978      -6.1599820852279663e-01
    phi[5,0]  R979      -1.8731740713119507e+00
    phi[5,0]  R980      -2.3838498592376709e+00
    phi[5,0]  R981      -2.28676438331604
    phi[5,0]  R982      -1.5655457973480225e+00
    phi[5,0]  R983      -2.2496452331542969e+00
    phi[5,0]  R984      -1.1047999858856201e+00
    phi[5,0]  R985      -3.9112296104431152e+00
    phi[5,0]  R986      -2.0878802239894867e-01
    phi[5,0]  R987      -1.8144193887710571e+00
    phi[5,0]  R988      -5.6198197603225708e-01
    phi[5,0]  R989      -3.2846946716308594e+00
    phi[5,0]  R990      -3.6389198303222656e+00
    phi[5,0]  R991      8.5871362686157227e-01
    phi[5,0]  R992      -2.1571755409240723e+00
    phi[5,0]  R993      -8.6044591665267944e-01
    phi[5,0]  R994      -1.7498689889907837e-01
    phi[5,0]  R995      -3.0747380256652832e+00
    phi[5,0]  R996      -2.4851908683776855e+00
    phi[5,0]  R997      -3.2661199569702148e+00
    phi[5,0]  R998      -1.5259279012680054e+00
    phi[5,0]  R999      -2.0724122524261475e+00
    phi[5,0]  R1000     -6.7088341712951660e-01
    phi[5,0]  R1001     -1.7524101734161377e+00
    phi[5,0]  R1002     2.1723256111145020e+00
    phi[5,0]  R1003     -1.4818421602249146e+00
    phi[5,0]  R1004     -2.7236732840538025e-01
    phi[5,0]  R1005     -5.0426638126373291e-01
    phi[5,0]  R1006     -7.3406076431274414e-01
    phi[5,0]  R1007     -1.1358362436294556e+00
    phi[5,0]  R1008     -1.5497237443923950e+00
    phi[5,0]  R1009     -1.5645905733108521e+00
    phi[5,0]  R1010     -2.3188908100128174e+00
    phi[5,0]  R1011     -3.2849791049957275e+00
    phi[5,0]  R1012     1.1891631036996841e-01
    phi[5,0]  R1013     -1.6643502712249756e+00
    phi[5,0]  R1014     -2.4927651882171631e+00
    phi[5,0]  R1015     -2.3385400772094727e+00
    phi[5,0]  R1016     -1.3907653093338013e+00
    phi[5,0]  R1017     -3.7895064353942871e+00
    phi[5,0]  R1018     -9.0979856252670288e-01
    phi[5,0]  R1019     -1.6453093290328979e+00
    phi[5,0]  R1020     8.1865197420120239e-01
    phi[5,0]  R1021     1.7010173797607422e+00
    phi[5,0]  R1022     -1.2764931917190552e+00
    phi[5,0]  R1023     -6.2317693233489990e-01
    phi[5,0]  R1024     -4.0274820327758789e+00
    phi[5,0]  R1025     -1.5860296487808228e+00
    phi[5,0]  R1026     8.0893862247467041e-01
    phi[5,0]  R1027     1.6444036960601807e+00
    phi[5,0]  R1028     7.9198122024536133e-01
    phi[5,0]  R1029     1.9786010980606079e+00
    phi[5,0]  R1030     8.9858734607696533e-01
    phi[5,0]  R1031     -5.7812377810478210e-02
    phi[8,0]  R0        -1
    phi[8,0]  R2        2.4988626383964481e+00
    phi[8,0]  R3        1.1155125521061739e+00
    phi[8,0]  R4        1.3169240654141183e+00
    phi[8,0]  R5        2.3094059559701177e+00
    phi[8,0]  R6        1.0508153472736645e+00
    phi[8,0]  R7        1.8036317031965696e+00
    phi[8,0]  R8        -6.2164954926904770e-01
    phi[8,0]  R72       1
    phi[8,0]  R1032     -5.5988625430290160e+00
    phi[8,0]  R1033     -6.0113726623612029e-01
    phi[8,0]  R1034     -3.3555125616429171e+00
    phi[8,0]  R1035     -1.1244874574305692e+00
    phi[8,0]  R1036     -4.4169239700466871e+00
    phi[8,0]  R1037     -1.78307583921845
    phi[8,0]  R1038     -4.8794058892129151e+00
    phi[8,0]  R1039     -2.6059397727268019e-01
    phi[8,0]  R1040     -4.1508152519062325e+00
    phi[8,0]  R1041     -2.0491845573589038e+00
    phi[8,0]  R1042     -3.8936316173658811e+00
    phi[8,0]  R1043     -2.8636821097274190e-01
    phi[8,0]  R1044     -2.4783503553635207e+00
    phi[8,0]  R1045     -3.7216494539016161e+00
    phi[8,0]  R1046     -2.1509698483951745e-01
    phi[8,0]  R1047     -2.2074198328549643e-01
    phi[8,0]  R1048     -2.2686782762616708e-01
    phi[8,0]  R1049     -2.4320302697551055e-01
    phi[8,0]  R1050     -2.4326792667357666e-01
    phi[8,0]  R1051     -2.4642798956830259e-01
    phi[8,0]  R1052     -2.5225034871651775e-01
    phi[8,0]  R1053     -4.2185856780694575e-01
    phi[8,0]  R1054     -4.4148230327296750e-01
    phi[8,0]  R1055     -1.6923160241832167e+00
    phi[8,0]  R1056     -3.6975939960214821e-01
    phi[8,0]  R1057     -3.7227459984552597e-01
    phi[8,0]  R1058     -0.372493793776971
    phi[8,0]  R1059     -3.7958314258964454e-01
    phi[8,0]  R1060     -3.8299665794554738e-01
    phi[8,0]  R1061     -3.9290723611431638e-01
    phi[8,0]  R1062     -3.9405951339481565e-01
    phi[8,0]  R1063     -3.9918020303769008e-01
    phi[8,0]  R1064     -4.0677050608517007e-01
    phi[8,0]  R1065     -4.0705288783973748e-01
    phi[8,0]  R1066     -3.8309717015366340e-01
    phi[8,0]  R1067     -3.8528210712580035e-01
    phi[8,0]  R1068     -4.1348594814603912e-01
    phi[8,0]  R1069     -4.3871630412418527e-01
    phi[8,0]  R1070     -4.7977409425631379e-01
    phi[8,0]  R1071     -5.0773966716478225e-01
    phi[8,0]  R1072     -5.1687459451613460e-01
    phi[8,0]  R1073     -5.2352428486219615e-01
    phi[8,0]  R1074     -5.4009125291878624e-01
    phi[8,0]  R1075     -5.4047105043644894e-01
    phi[8,0]  R1076     -3.0280871173705848e-01
    phi[8,0]  R1077     -3.4471858709475289e-01
    phi[8,0]  R1078     -3.5587638012042633e-01
    phi[8,0]  R1079     -3.6773403345359368e-01
    phi[8,0]  R1080     -3.9713221651287289e-01
    phi[8,0]  R1081     -3.9792494466577366e-01
    phi[8,0]  R1082     -4.0632080502353574e-01
    phi[8,0]  R1083     -4.1362809571422976e-01
    phi[8,0]  R1084     -4.7041425681715210e-01
    phi[8,0]  R1085     -4.8544087306941508e-01
    phi[8,0]  R1086     -3.5046298963009703e-01
    phi[8,0]  R1087     -3.7535972570674159e-01
    phi[8,0]  R1088     -3.7614541709493587e-01
    phi[8,0]  R1089     -3.8865552651181234e-01
    phi[8,0]  R1090     -4.6597062136131306e-01
    phi[8,0]  R1091     -4.6652883812542845e-01
    phi[8,0]  R1092     -5.1689738594720658e-01
    phi[8,0]  R1093     -5.4230954747526994e-01
    phi[8,0]  R1094     -5.5357453572793425e-01
    phi[8,0]  R1095     -5.7170984209583642e-01
    phi[8,0]  R1096     -3.4005424984680088e-01
    phi[8,0]  R1097     -3.4648119869666627e-01
    phi[8,0]  R1098     -3.4981551510162712e-01
    phi[8,0]  R1099     -3.5141423429616747e-01
    phi[8,0]  R1100     -3.8046697320227274e-01
    phi[8,0]  R1101     -4.0009445184759773e-01
    phi[8,0]  R1102     -4.0624029812637263e-01
    phi[8,0]  R1103     -4.1963369467047462e-01
    phi[8,0]  R1104     -0.449179880161905
    phi[8,0]  R1105     -4.5724224050739970e-01
    phi[8,0]  R1106     -2.2907946465342466e-01
    phi[8,0]  R1107     -2.9114947297923344e-01
    phi[8,0]  R1108     -2.9491409902853827e-01
    phi[8,0]  R1109     -2.9964617120950932e-01
    phi[8,0]  R1110     -3.3141448213915420e-01
    phi[8,0]  R1111     -3.5502635014943995e-01
    phi[8,0]  R1112     -3.5897248642468726e-01
    phi[8,0]  R1113     -3.7268438482673005e-01
    phi[8,0]  R1114     -3.8481331397103991e-01
    phi[8,0]  R1115     -4.5127718628413405e-01
    phi[8,0]  R1116     -2.5868631968142120e-01
    phi[8,0]  R1117     -3.1914774378018329e-01
    phi[8,0]  R1118     -3.4311558691792987e-01
    phi[8,0]  R1119     -3.5602001308416042e-01
    phi[8,0]  R1120     -3.6938471148893304e-01
    phi[8,0]  R1121     -4.0697545658742973e-01
    phi[8,0]  R1122     -4.2237595534578282e-01
    phi[8,0]  R1123     -2.2072210884687382e+00
    phi[8,0]  R1124     -5.9713174163513738e-01
    phi[8,0]  R1125     -6.0488388479407806e-01
    phi[8,0]  R1126     -3.2262466977785509e-01
    phi[8,0]  R1127     -3.3009661398834206e-01
    phi[8,0]  R1128     -3.5278476891934663e-01
    phi[8,0]  R1129     -3.9945542679657975e-01
    phi[8,0]  R1130     -5.8993575373297480e-01
    phi[8,0]  R1131     -6.0787638963116741e-01
    phi[8,0]  R1132     -0.609440257180923
    phi[8,0]  R1133     -6.1631209488975225e-01
    phi[8,0]  R1134     -6.2537655560680872e-01
    phi[8,0]  R1135     -6.4995123784002873e-01
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R1136     -3.0999999046325684e+00
    phi[1,2]  R1137     -3.0999999046325684e+00
    phi[1,2]  R1138     -2.2400000095367432e+00
    phi[1,2]  R1139     -2.2400000095367432e+00
    phi[1,2]  R1140     -3.0999999046325684e+00
    phi[1,2]  R1141     -3.0999999046325684e+00
    phi[1,2]  R1142     -2.5699999332427979e+00
    phi[1,2]  R1143     -2.5699999332427979e+00
    phi[1,2]  R1144     -3.0999999046325684e+00
    phi[1,2]  R1145     -3.0999999046325684e+00
    phi[1,2]  R1146     -2.0899999141693115e+00
    phi[1,2]  R1147     -2.0899999141693115e+00
    phi[1,2]  R1148     -3.0999999046325684e+00
    phi[1,2]  R1149     -3.0999999046325684e+00
    phi[1,2]  R1150     9.5445340871810913e-01
    phi[1,2]  R1151     1.2998161315917969e+00
    phi[1,2]  R1152     1.0465599298477173e+00
    phi[1,2]  R1153     2.6158740743994713e-02
    phi[1,2]  R1154     2.1373325586318970e-01
    phi[1,2]  R1155     -6.8143838644027710e-01
    phi[1,2]  R1156     -9.9843695759773254e-02
    phi[1,2]  R1157     1.2743975222110748e-01
    phi[1,2]  R1158     1.2238606810569763e-01
    phi[1,2]  R1159     1.7150139808654785e+00
    phi[1,2]  R1160     -1.1234804391860962e+00
    phi[1,2]  R1161     -1.0450192689895630e+00
    phi[1,2]  R1162     1.1121588945388794e+00
    phi[1,2]  R1163     -4.6447181701660156e-01
    phi[1,2]  R1164     -8.6480677127838135e-01
    phi[1,2]  R1165     7.2725892066955566e-01
    phi[1,2]  R1166     1.5826387405395508e+00
    phi[1,2]  R1167     -2.5051634311676025e+00
    phi[1,2]  R1168     -1.4275000095367432e+00
    phi[1,2]  R1169     -0.590865433216095
    phi[1,2]  R1170     -1.2557660341262817e+00
    phi[1,2]  R1171     -1.3735866546630859e+00
    phi[1,2]  R1172     -3.0288317799568176e-01
    phi[1,2]  R1173     -2.3822064399719238e+00
    phi[1,2]  R1174     -1.4790401458740234e+00
    phi[1,2]  R1175     -1.7038631439208984e+00
    phi[1,2]  R1176     -1.7806206941604614e+00
    phi[1,2]  R1177     -1.3582774400711060e+00
    phi[1,2]  R1178     -1.0864902734756470e+00
    phi[1,2]  R1179     -2.1867434978485107e+00
    phi[1,2]  R1180     -1.0920318365097046e+00
    phi[1,2]  R1181     -2.7628526687622070e+00
    phi[1,2]  R1182     -2.0831971168518066e+00
    phi[1,2]  R1183     -1.6829729080200195e+00
    phi[1,2]  R1184     -2.1751441955566406e+00
    phi[1,2]  R1185     -2.3437447547912598e+00
    phi[1,2]  R1186     -3.8724580407142639e-01
    phi[1,2]  R1187     -0.306571900844574
    phi[1,2]  R1188     5.8354310691356659e-02
    phi[1,2]  R1189     -3.9608082175254822e-01
    phi[1,2]  R1190     -9.7112111747264862e-02
    phi[1,2]  R1191     -2.9196338653564453e+00
    phi[1,2]  R1192     -1.9592336416244507e+00
    phi[1,2]  R1193     -2.2466211318969727e+00
    phi[1,2]  R1194     5.8903777599334717e-01
    phi[1,2]  R1195     -1.0373470783233643e+00
    phi[1,2]  R1196     -0.665643036365509
    phi[1,2]  R1197     -7.7095907926559448e-01
    phi[1,2]  R1198     1.2159402370452881e+00
    phi[1,2]  R1199     1.4450672864913940e+00
    phi[1,2]  R1200     -4.2596060037612915e-01
    phi[1,2]  R1201     -1.3469914197921753e+00
    phi[1,2]  R1202     -4.3488636612892151e-02
    phi[1,2]  R1203     -7.0555508136749268e-01
    phi[1,2]  R1204     5.9295517206192017e-01
    phi[1,2]  R1205     -2.3364315927028656e-01
    phi[1,2]  R1206     5.0910699367523193e-01
    phi[1,2]  R1207     -1.2763220071792603e+00
    phi[1,2]  R1208     -1.3888007402420044e+00
    phi[1,2]  R1209     -4.2772921919822693e-01
    phi[1,2]  R1210     3.9427958428859711e-02
    phi[1,2]  R1211     -1.0137538909912109e+00
    phi[1,2]  R1212     -2.6533478498458862e-01
    phi[1,2]  R1213     7.0117235183715820e-01
    phi[1,2]  R1214     -1.0164970159530640e+00
    phi[1,2]  R1215     3.9723372459411621e-01
    phi[1,2]  R1216     7.5587362051010132e-01
    phi[1,2]  R1217     -4.7668302059173584e-01
    phi[1,2]  R1218     4.8567700386047363e-01
    phi[1,2]  R1219     5.3765308856964111e-01
    phi[1,2]  R1220     -1.6315293312072754e+00
    phi[1,2]  R1221     -9.6208804845809937e-01
    phi[1,2]  R1222     -0.453605979681015
    phi[1,2]  R1223     7.2854363918304443e-01
    phi[1,2]  R1224     3.3638885617256165e-01
    phi[1,2]  R1225     -4.1308665275573730e-01
    phi[1,2]  R1226     9.0818881988525391e-01
    phi[1,2]  R1227     -5.2399986982345581e-01
    phi[1,2]  R1228     3.7004329264163971e-02
    phi[1,2]  R1229     3.1211572885513306e-01
    phi[1,2]  R1230     3.5585775971412659e-01
    phi[1,2]  R1231     9.6406465768814087e-01
    phi[1,2]  R1232     5.7580178976058960e-01
    phi[1,2]  R1233     -8.9371937513351440e-01
    phi[1,2]  R1234     1.0209938287734985e+00
    phi[1,2]  R1235     1.9247062504291534e-01
    phi[1,2]  R1236     1.0486173629760742e+00
    phi[1,2]  R1237     -2.5680476427078247e-01
    phi[1,2]  R1238     3.6642253398895264e-01
    phi[1,2]  R1239     -3.8091205060482025e-02
    phi[1,2]  R1240     1.1892268657684326e+00
    phi[1,2]  R1241     7.8256106376647949e-01
    phi[1,2]  R1242     -0.451742559671402
    phi[1,2]  R1243     -6.0869228839874268e-01
    phi[1,2]  R1244     8.4558510780334473e-01
    phi[1,2]  R1245     1.0185252428054810e+00
    phi[1,2]  R1246     -1.6792182624340057e-01
    phi[1,2]  R1247     -4.6601867675781250e-01
    phi[1,2]  R1248     -7.7613002061843872e-01
    phi[1,2]  R1249     -0.853714644908905
    phi[1,2]  R1250     -1.1418981552124023e+00
    phi[1,2]  R1251     -1.4407485723495483e+00
    phi[1,2]  R1252     -1.3943345546722412e+00
    phi[1,2]  R1253     1.0306119173765182e-01
    phi[1,2]  R1254     -7.9448485374450684e-01
    phi[1,2]  R1255     4.0824121236801147e-01
    phi[1,2]  R1256     1.1788765192031860e+00
    phi[1,2]  R1257     1.2675729990005493e+00
    phi[1,2]  R1258     -5.7105940580368042e-01
    phi[1,2]  R1259     4.3831646442413330e-01
    phi[1,2]  R1260     1.0975919961929321e+00
    phi[1,2]  R1261     -0.864722728729248
    phi[1,2]  R1262     -2.1740472316741943e+00
    phi[1,2]  R1263     -1.6923584938049316e+00
    phi[1,2]  R1264     -0.0430297777056694
    phi[1,2]  R1265     -6.3506138324737549e-01
    phi[1,2]  R1266     -2.1119022369384766e+00
    phi[1,2]  R1267     2.9268914461135864e-01
    phi[1,2]  R1268     -2.4455361366271973e+00
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R1269     -3.0999999046325684e+00
    phi[2,1]  R1270     -3.0999999046325684e+00
    phi[2,1]  R1271     -2.2400000095367432e+00
    phi[2,1]  R1272     -2.2400000095367432e+00
    phi[2,1]  R1273     -3.0999999046325684e+00
    phi[2,1]  R1274     -3.0999999046325684e+00
    phi[2,1]  R1275     -2.5699999332427979e+00
    phi[2,1]  R1276     -2.5699999332427979e+00
    phi[2,1]  R1277     -3.0999999046325684e+00
    phi[2,1]  R1278     -3.0999999046325684e+00
    phi[2,1]  R1279     -2.0899999141693115e+00
    phi[2,1]  R1280     -2.0899999141693115e+00
    phi[2,1]  R1281     -3.0999999046325684e+00
    phi[2,1]  R1282     -3.0999999046325684e+00
    phi[2,1]  R1283     3.5585775971412659e-01
    phi[2,1]  R1284     9.6406465768814087e-01
    phi[2,1]  R1285     5.7580178976058960e-01
    phi[2,1]  R1286     -8.9371937513351440e-01
    phi[2,1]  R1287     1.0209938287734985e+00
    phi[2,1]  R1288     1.9247062504291534e-01
    phi[2,1]  R1289     1.0486173629760742e+00
    phi[2,1]  R1290     -2.5680476427078247e-01
    phi[2,1]  R1291     3.6642253398895264e-01
    phi[2,1]  R1292     -3.8091205060482025e-02
    phi[2,1]  R1293     1.1892268657684326e+00
    phi[2,1]  R1294     7.8256106376647949e-01
    phi[2,1]  R1295     -0.451742559671402
    phi[2,1]  R1296     -6.0869228839874268e-01
    phi[2,1]  R1297     8.4558510780334473e-01
    phi[2,1]  R1298     1.0185252428054810e+00
    phi[2,1]  R1299     -1.6792182624340057e-01
    phi[2,1]  R1300     -4.6601867675781250e-01
    phi[2,1]  R1301     -7.7613002061843872e-01
    phi[2,1]  R1302     -0.853714644908905
    phi[2,1]  R1303     -1.1418981552124023e+00
    phi[2,1]  R1304     -1.4407485723495483e+00
    phi[2,1]  R1305     -1.3943345546722412e+00
    phi[2,1]  R1306     1.0306119173765182e-01
    phi[2,1]  R1307     -7.9448485374450684e-01
    phi[2,1]  R1308     4.0824121236801147e-01
    phi[2,1]  R1309     1.1788765192031860e+00
    phi[2,1]  R1310     1.2675729990005493e+00
    phi[2,1]  R1311     -5.7105940580368042e-01
    phi[2,1]  R1312     4.3831646442413330e-01
    phi[2,1]  R1313     1.0975919961929321e+00
    phi[2,1]  R1314     -0.864722728729248
    phi[2,1]  R1315     -2.1740472316741943e+00
    phi[2,1]  R1316     -1.6923584938049316e+00
    phi[2,1]  R1317     -0.0430297777056694
    phi[2,1]  R1318     -6.3506138324737549e-01
    phi[2,1]  R1319     -2.1119022369384766e+00
    phi[2,1]  R1320     2.9268914461135864e-01
    phi[2,1]  R1321     -2.4455361366271973e+00
    phi[2,1]  R1322     9.5445340871810913e-01
    phi[2,1]  R1323     1.2998161315917969e+00
    phi[2,1]  R1324     1.0465599298477173e+00
    phi[2,1]  R1325     2.6158740743994713e-02
    phi[2,1]  R1326     2.1373325586318970e-01
    phi[2,1]  R1327     -6.8143838644027710e-01
    phi[2,1]  R1328     -9.9843695759773254e-02
    phi[2,1]  R1329     1.2743975222110748e-01
    phi[2,1]  R1330     1.2238606810569763e-01
    phi[2,1]  R1331     1.7150139808654785e+00
    phi[2,1]  R1332     -1.1234804391860962e+00
    phi[2,1]  R1333     -1.0450192689895630e+00
    phi[2,1]  R1334     1.1121588945388794e+00
    phi[2,1]  R1335     -4.6447181701660156e-01
    phi[2,1]  R1336     -8.6480677127838135e-01
    phi[2,1]  R1337     7.2725892066955566e-01
    phi[2,1]  R1338     1.5826387405395508e+00
    phi[2,1]  R1339     -2.5051634311676025e+00
    phi[2,1]  R1340     -1.4275000095367432e+00
    phi[2,1]  R1341     -0.590865433216095
    phi[2,1]  R1342     -1.2557660341262817e+00
    phi[2,1]  R1343     -1.3735866546630859e+00
    phi[2,1]  R1344     -3.0288317799568176e-01
    phi[2,1]  R1345     -2.3822064399719238e+00
    phi[2,1]  R1346     -1.4790401458740234e+00
    phi[2,1]  R1347     -1.7038631439208984e+00
    phi[2,1]  R1348     -1.7806206941604614e+00
    phi[2,1]  R1349     -1.3582774400711060e+00
    phi[2,1]  R1350     -1.0864902734756470e+00
    phi[2,1]  R1351     -2.1867434978485107e+00
    phi[2,1]  R1352     -1.0920318365097046e+00
    phi[2,1]  R1353     -2.7628526687622070e+00
    phi[2,1]  R1354     -2.0831971168518066e+00
    phi[2,1]  R1355     -1.6829729080200195e+00
    phi[2,1]  R1356     -2.1751441955566406e+00
    phi[2,1]  R1357     -2.3437447547912598e+00
    phi[2,1]  R1358     -3.8724580407142639e-01
    phi[2,1]  R1359     -0.306571900844574
    phi[2,1]  R1360     5.8354310691356659e-02
    phi[2,1]  R1361     -3.9608082175254822e-01
    phi[2,1]  R1362     -9.7112111747264862e-02
    phi[2,1]  R1363     -2.9196338653564453e+00
    phi[2,1]  R1364     -1.9592336416244507e+00
    phi[2,1]  R1365     -2.2466211318969727e+00
    phi[2,1]  R1366     5.8903777599334717e-01
    phi[2,1]  R1367     -1.0373470783233643e+00
    phi[2,1]  R1368     -0.665643036365509
    phi[2,1]  R1369     -7.7095907926559448e-01
    phi[2,1]  R1370     1.2159402370452881e+00
    phi[2,1]  R1371     1.4450672864913940e+00
    phi[2,1]  R1372     -4.2596060037612915e-01
    phi[2,1]  R1373     -1.3469914197921753e+00
    phi[2,1]  R1374     -4.3488636612892151e-02
    phi[2,1]  R1375     -7.0555508136749268e-01
    phi[2,1]  R1376     5.9295517206192017e-01
    phi[2,1]  R1377     -2.3364315927028656e-01
    phi[2,1]  R1378     5.0910699367523193e-01
    phi[2,1]  R1379     -1.2763220071792603e+00
    phi[2,1]  R1380     -1.3888007402420044e+00
    phi[2,1]  R1381     -4.2772921919822693e-01
    phi[2,1]  R1382     3.9427958428859711e-02
    phi[2,1]  R1383     -1.0137538909912109e+00
    phi[2,1]  R1384     -2.6533478498458862e-01
    phi[2,1]  R1385     7.0117235183715820e-01
    phi[2,1]  R1386     -1.0164970159530640e+00
    phi[2,1]  R1387     3.9723372459411621e-01
    phi[2,1]  R1388     7.5587362051010132e-01
    phi[2,1]  R1389     -4.7668302059173584e-01
    phi[2,1]  R1390     4.8567700386047363e-01
    phi[2,1]  R1391     5.3765308856964111e-01
    phi[2,1]  R1392     -1.6315293312072754e+00
    phi[2,1]  R1393     -9.6208804845809937e-01
    phi[2,1]  R1394     -0.453605979681015
    phi[2,1]  R1395     7.2854363918304443e-01
    phi[2,1]  R1396     3.3638885617256165e-01
    phi[2,1]  R1397     -4.1308665275573730e-01
    phi[2,1]  R1398     9.0818881988525391e-01
    phi[2,1]  R1399     -5.2399986982345581e-01
    phi[2,1]  R1400     3.7004329264163971e-02
    phi[2,1]  R1401     3.1211572885513306e-01
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R1402     -3.0999999046325684e+00
    phi[2,3]  R1403     -3.0999999046325684e+00
    phi[2,3]  R1404     -2.2400000095367432e+00
    phi[2,3]  R1405     -2.2400000095367432e+00
    phi[2,3]  R1406     -3.0999999046325684e+00
    phi[2,3]  R1407     -3.0999999046325684e+00
    phi[2,3]  R1408     -2.5699999332427979e+00
    phi[2,3]  R1409     -2.5699999332427979e+00
    phi[2,3]  R1410     -3.0999999046325684e+00
    phi[2,3]  R1411     -3.0999999046325684e+00
    phi[2,3]  R1412     -2.0899999141693115e+00
    phi[2,3]  R1413     -2.0899999141693115e+00
    phi[2,3]  R1414     -3.0999999046325684e+00
    phi[2,3]  R1415     -3.0999999046325684e+00
    phi[2,3]  R1416     3.5585775971412659e-01
    phi[2,3]  R1417     9.6406465768814087e-01
    phi[2,3]  R1418     5.7580178976058960e-01
    phi[2,3]  R1419     -8.9371937513351440e-01
    phi[2,3]  R1420     1.0209938287734985e+00
    phi[2,3]  R1421     1.9247062504291534e-01
    phi[2,3]  R1422     1.0486173629760742e+00
    phi[2,3]  R1423     -2.5680476427078247e-01
    phi[2,3]  R1424     3.6642253398895264e-01
    phi[2,3]  R1425     -3.8091205060482025e-02
    phi[2,3]  R1426     1.1892268657684326e+00
    phi[2,3]  R1427     7.8256106376647949e-01
    phi[2,3]  R1428     -0.451742559671402
    phi[2,3]  R1429     -6.0869228839874268e-01
    phi[2,3]  R1430     8.4558510780334473e-01
    phi[2,3]  R1431     1.0185252428054810e+00
    phi[2,3]  R1432     -1.6792182624340057e-01
    phi[2,3]  R1433     -4.6601867675781250e-01
    phi[2,3]  R1434     -7.7613002061843872e-01
    phi[2,3]  R1435     -0.853714644908905
    phi[2,3]  R1436     -1.1418981552124023e+00
    phi[2,3]  R1437     -1.4407485723495483e+00
    phi[2,3]  R1438     -1.3943345546722412e+00
    phi[2,3]  R1439     1.0306119173765182e-01
    phi[2,3]  R1440     -7.9448485374450684e-01
    phi[2,3]  R1441     4.0824121236801147e-01
    phi[2,3]  R1442     1.1788765192031860e+00
    phi[2,3]  R1443     1.2675729990005493e+00
    phi[2,3]  R1444     -5.7105940580368042e-01
    phi[2,3]  R1445     4.3831646442413330e-01
    phi[2,3]  R1446     1.0975919961929321e+00
    phi[2,3]  R1447     -0.864722728729248
    phi[2,3]  R1448     -2.1740472316741943e+00
    phi[2,3]  R1449     -1.6923584938049316e+00
    phi[2,3]  R1450     -0.0430297777056694
    phi[2,3]  R1451     -6.3506138324737549e-01
    phi[2,3]  R1452     -2.1119022369384766e+00
    phi[2,3]  R1453     2.9268914461135864e-01
    phi[2,3]  R1454     -2.4455361366271973e+00
    phi[2,3]  R1455     1.2750611305236816e+00
    phi[2,3]  R1456     -1.0193871259689331e+00
    phi[2,3]  R1457     6.6280996799468994e-01
    phi[2,3]  R1458     1.9177225232124329e-01
    phi[2,3]  R1459     2.2841414809226990e-01
    phi[2,3]  R1460     5.1101052761077881e-01
    phi[2,3]  R1461     -2.4765176773071289e+00
    phi[2,3]  R1462     9.4632118940353394e-01
    phi[2,3]  R1463     1.5906384214758873e-03
    phi[2,3]  R1464     -3.0656335353851318e+00
    phi[2,3]  R1465     4.3246039748191833e-01
    phi[2,3]  R1466     1.5574162006378174e+00
    phi[2,3]  R1467     1.5564637184143066e+00
    phi[2,3]  R1468     2.1236889064311981e-01
    phi[2,3]  R1469     -9.7022807598114014e-01
    phi[2,3]  R1470     4.8991248011589050e-02
    phi[2,3]  R1471     -1.4896863698959351e+00
    phi[2,3]  R1472     -2.9681241512298584e+00
    phi[2,3]  R1473     -9.9440479278564453e-01
    phi[2,3]  R1474     1.5531022548675537e+00
    phi[2,3]  R1475     -3.1024255752563477e+00
    phi[2,3]  R1476     -3.6585597991943359e+00
    phi[2,3]  R1477     -2.6091744899749756e+00
    phi[2,3]  R1478     -2.3486399650573730e+00
    phi[2,3]  R1479     -2.1553784608840942e-01
    phi[2,3]  R1480     -0.984927237033844
    phi[2,3]  R1481     2.6275757700204849e-02
    phi[2,3]  R1482     -1.4217659235000610e+00
    phi[2,3]  R1483     -3.2184071838855743e-02
    phi[2,3]  R1484     -9.1687482595443726e-01
    phi[2,3]  R1485     1.0131727904081345e-03
    phi[2,3]  R1486     -2.0705003738403320e+00
    phi[2,3]  R1487     4.3474385142326355e-01
    phi[2,3]  R1488     -7.7667397260665894e-01
    phi[2,3]  R1489     -3.3311076164245605e+00
    phi[2,3]  R1490     -1.9384204149246216e+00
    phi[2,3]  R1491     -1.2497197389602661e+00
    phi[2,3]  R1492     -1.6457222700119019e+00
    phi[2,3]  R1493     3.9467829465866089e-01
    phi[2,3]  R1494     -2.0629756450653076e+00
    phi[2,3]  R1495     -2.4886839389801025e+00
    phi[2,3]  R1496     -2.9636569023132324e+00
    phi[2,3]  R1497     -1.9893159866333008e+00
    phi[2,3]  R1498     1.3387296199798584e+00
    phi[2,3]  R1499     -9.1892659664154053e-01
    phi[2,3]  R1500     3.7916311621665955e-01
    phi[2,3]  R1501     7.0439261198043823e-01
    phi[2,3]  R1502     1.2836631536483765e+00
    phi[2,3]  R1503     -1.1880122423171997e+00
    phi[2,3]  R1504     2.6326513290405273e+00
    phi[2,3]  R1505     -1.9612210988998413e+00
    phi[2,3]  R1506     1.4763481616973877e+00
    phi[2,3]  R1507     -1.9758594036102295e-01
    phi[2,3]  R1508     5.5797058343887329e-01
    phi[2,3]  R1509     1.2076336145401
    phi[2,3]  R1510     -1.9537040591239929e-01
    phi[2,3]  R1511     2.2815218195319176e-02
    phi[2,3]  R1512     1.0461459159851074e+00
    phi[2,3]  R1513     1.7430247366428375e-01
    phi[2,3]  R1514     2.4732495844364166e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1515     -3.0999999046325684e+00
    phi[3,2]  R1516     -3.0999999046325684e+00
    phi[3,2]  R1517     -2.2400000095367432e+00
    phi[3,2]  R1518     -2.2400000095367432e+00
    phi[3,2]  R1519     -3.0999999046325684e+00
    phi[3,2]  R1520     -3.0999999046325684e+00
    phi[3,2]  R1521     -2.5699999332427979e+00
    phi[3,2]  R1522     -2.5699999332427979e+00
    phi[3,2]  R1523     -3.0999999046325684e+00
    phi[3,2]  R1524     -3.0999999046325684e+00
    phi[3,2]  R1525     -2.0899999141693115e+00
    phi[3,2]  R1526     -2.0899999141693115e+00
    phi[3,2]  R1527     -3.0999999046325684e+00
    phi[3,2]  R1528     -3.0999999046325684e+00
    phi[3,2]  R1529     1.2750611305236816e+00
    phi[3,2]  R1530     -1.0193871259689331e+00
    phi[3,2]  R1531     6.6280996799468994e-01
    phi[3,2]  R1532     1.9177225232124329e-01
    phi[3,2]  R1533     2.2841414809226990e-01
    phi[3,2]  R1534     5.1101052761077881e-01
    phi[3,2]  R1535     -2.4765176773071289e+00
    phi[3,2]  R1536     9.4632118940353394e-01
    phi[3,2]  R1537     1.5906384214758873e-03
    phi[3,2]  R1538     -3.0656335353851318e+00
    phi[3,2]  R1539     4.3246039748191833e-01
    phi[3,2]  R1540     1.5574162006378174e+00
    phi[3,2]  R1541     1.5564637184143066e+00
    phi[3,2]  R1542     2.1236889064311981e-01
    phi[3,2]  R1543     -9.7022807598114014e-01
    phi[3,2]  R1544     4.8991248011589050e-02
    phi[3,2]  R1545     -1.4896863698959351e+00
    phi[3,2]  R1546     -2.9681241512298584e+00
    phi[3,2]  R1547     -9.9440479278564453e-01
    phi[3,2]  R1548     1.5531022548675537e+00
    phi[3,2]  R1549     -3.1024255752563477e+00
    phi[3,2]  R1550     -3.6585597991943359e+00
    phi[3,2]  R1551     -2.6091744899749756e+00
    phi[3,2]  R1552     -2.3486399650573730e+00
    phi[3,2]  R1553     -2.1553784608840942e-01
    phi[3,2]  R1554     -0.984927237033844
    phi[3,2]  R1555     2.6275757700204849e-02
    phi[3,2]  R1556     -1.4217659235000610e+00
    phi[3,2]  R1557     -3.2184071838855743e-02
    phi[3,2]  R1558     -9.1687482595443726e-01
    phi[3,2]  R1559     1.0131727904081345e-03
    phi[3,2]  R1560     -2.0705003738403320e+00
    phi[3,2]  R1561     4.3474385142326355e-01
    phi[3,2]  R1562     -7.7667397260665894e-01
    phi[3,2]  R1563     -3.3311076164245605e+00
    phi[3,2]  R1564     -1.9384204149246216e+00
    phi[3,2]  R1565     -1.2497197389602661e+00
    phi[3,2]  R1566     -1.6457222700119019e+00
    phi[3,2]  R1567     3.9467829465866089e-01
    phi[3,2]  R1568     -2.0629756450653076e+00
    phi[3,2]  R1569     -2.4886839389801025e+00
    phi[3,2]  R1570     -2.9636569023132324e+00
    phi[3,2]  R1571     -1.9893159866333008e+00
    phi[3,2]  R1572     1.3387296199798584e+00
    phi[3,2]  R1573     -9.1892659664154053e-01
    phi[3,2]  R1574     3.7916311621665955e-01
    phi[3,2]  R1575     7.0439261198043823e-01
    phi[3,2]  R1576     1.2836631536483765e+00
    phi[3,2]  R1577     -1.1880122423171997e+00
    phi[3,2]  R1578     2.6326513290405273e+00
    phi[3,2]  R1579     -1.9612210988998413e+00
    phi[3,2]  R1580     1.4763481616973877e+00
    phi[3,2]  R1581     -1.9758594036102295e-01
    phi[3,2]  R1582     5.5797058343887329e-01
    phi[3,2]  R1583     1.2076336145401
    phi[3,2]  R1584     -1.9537040591239929e-01
    phi[3,2]  R1585     2.2815218195319176e-02
    phi[3,2]  R1586     1.0461459159851074e+00
    phi[3,2]  R1587     1.7430247366428375e-01
    phi[3,2]  R1588     2.4732495844364166e-01
    phi[3,2]  R1589     3.5585775971412659e-01
    phi[3,2]  R1590     9.6406465768814087e-01
    phi[3,2]  R1591     5.7580178976058960e-01
    phi[3,2]  R1592     -8.9371937513351440e-01
    phi[3,2]  R1593     1.0209938287734985e+00
    phi[3,2]  R1594     1.9247062504291534e-01
    phi[3,2]  R1595     1.0486173629760742e+00
    phi[3,2]  R1596     -2.5680476427078247e-01
    phi[3,2]  R1597     3.6642253398895264e-01
    phi[3,2]  R1598     -3.8091205060482025e-02
    phi[3,2]  R1599     1.1892268657684326e+00
    phi[3,2]  R1600     7.8256106376647949e-01
    phi[3,2]  R1601     -0.451742559671402
    phi[3,2]  R1602     -6.0869228839874268e-01
    phi[3,2]  R1603     8.4558510780334473e-01
    phi[3,2]  R1604     1.0185252428054810e+00
    phi[3,2]  R1605     -1.6792182624340057e-01
    phi[3,2]  R1606     -4.6601867675781250e-01
    phi[3,2]  R1607     -7.7613002061843872e-01
    phi[3,2]  R1608     -0.853714644908905
    phi[3,2]  R1609     -1.1418981552124023e+00
    phi[3,2]  R1610     -1.4407485723495483e+00
    phi[3,2]  R1611     -1.3943345546722412e+00
    phi[3,2]  R1612     1.0306119173765182e-01
    phi[3,2]  R1613     -7.9448485374450684e-01
    phi[3,2]  R1614     4.0824121236801147e-01
    phi[3,2]  R1615     1.1788765192031860e+00
    phi[3,2]  R1616     1.2675729990005493e+00
    phi[3,2]  R1617     -5.7105940580368042e-01
    phi[3,2]  R1618     4.3831646442413330e-01
    phi[3,2]  R1619     1.0975919961929321e+00
    phi[3,2]  R1620     -0.864722728729248
    phi[3,2]  R1621     -2.1740472316741943e+00
    phi[3,2]  R1622     -1.6923584938049316e+00
    phi[3,2]  R1623     -0.0430297777056694
    phi[3,2]  R1624     -6.3506138324737549e-01
    phi[3,2]  R1625     -2.1119022369384766e+00
    phi[3,2]  R1626     2.9268914461135864e-01
    phi[3,2]  R1627     -2.4455361366271973e+00
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R63       -1
    phi[2,7]  R1628     -3.0999999046325684e+00
    phi[2,7]  R1629     -3.0999999046325684e+00
    phi[2,7]  R1630     -2.2400000095367432e+00
    phi[2,7]  R1631     -2.2400000095367432e+00
    phi[2,7]  R1632     -3.0999999046325684e+00
    phi[2,7]  R1633     -3.0999999046325684e+00
    phi[2,7]  R1634     -2.5699999332427979e+00
    phi[2,7]  R1635     -2.5699999332427979e+00
    phi[2,7]  R1636     -3.0999999046325684e+00
    phi[2,7]  R1637     -3.0999999046325684e+00
    phi[2,7]  R1638     -2.0899999141693115e+00
    phi[2,7]  R1639     -2.0899999141693115e+00
    phi[2,7]  R1640     -3.0999999046325684e+00
    phi[2,7]  R1641     -3.0999999046325684e+00
    phi[2,7]  R1642     3.5585775971412659e-01
    phi[2,7]  R1643     9.6406465768814087e-01
    phi[2,7]  R1644     5.7580178976058960e-01
    phi[2,7]  R1645     -8.9371937513351440e-01
    phi[2,7]  R1646     1.0209938287734985e+00
    phi[2,7]  R1647     1.9247062504291534e-01
    phi[2,7]  R1648     1.0486173629760742e+00
    phi[2,7]  R1649     -2.5680476427078247e-01
    phi[2,7]  R1650     3.6642253398895264e-01
    phi[2,7]  R1651     -3.8091205060482025e-02
    phi[2,7]  R1652     1.1892268657684326e+00
    phi[2,7]  R1653     7.8256106376647949e-01
    phi[2,7]  R1654     -0.451742559671402
    phi[2,7]  R1655     -6.0869228839874268e-01
    phi[2,7]  R1656     8.4558510780334473e-01
    phi[2,7]  R1657     1.0185252428054810e+00
    phi[2,7]  R1658     -1.6792182624340057e-01
    phi[2,7]  R1659     -4.6601867675781250e-01
    phi[2,7]  R1660     -7.7613002061843872e-01
    phi[2,7]  R1661     -0.853714644908905
    phi[2,7]  R1662     -1.1418981552124023e+00
    phi[2,7]  R1663     -1.4407485723495483e+00
    phi[2,7]  R1664     -1.3943345546722412e+00
    phi[2,7]  R1665     1.0306119173765182e-01
    phi[2,7]  R1666     -7.9448485374450684e-01
    phi[2,7]  R1667     4.0824121236801147e-01
    phi[2,7]  R1668     1.1788765192031860e+00
    phi[2,7]  R1669     1.2675729990005493e+00
    phi[2,7]  R1670     -5.7105940580368042e-01
    phi[2,7]  R1671     4.3831646442413330e-01
    phi[2,7]  R1672     1.0975919961929321e+00
    phi[2,7]  R1673     -0.864722728729248
    phi[2,7]  R1674     -2.1740472316741943e+00
    phi[2,7]  R1675     -1.6923584938049316e+00
    phi[2,7]  R1676     -0.0430297777056694
    phi[2,7]  R1677     -6.3506138324737549e-01
    phi[2,7]  R1678     -2.1119022369384766e+00
    phi[2,7]  R1679     2.9268914461135864e-01
    phi[2,7]  R1680     -2.4455361366271973e+00
    phi[2,7]  R1681     -0.509100079536438
    phi[2,7]  R1682     -5.4582124948501587e-01
    phi[2,7]  R1683     -1.3468535244464874e-01
    phi[2,7]  R1684     -1.3789841532707214e-01
    phi[2,7]  R1685     5.4770298302173615e-02
    phi[2,7]  R1686     2.1304650306701660e+00
    phi[2,7]  R1687     -1.2972854375839233e+00
    phi[2,7]  R1688     3.2123723626136780e-01
    phi[2,7]  R1689     1.7603840827941895e+00
    phi[2,7]  R1690     2.6542577743530273e+00
    phi[2,7]  R1691     -9.0353327989578247e-01
    phi[2,7]  R1692     -1.3421695232391357e+00
    phi[2,7]  R1693     -3.1466927528381348e+00
    phi[2,7]  R1694     -1.0275068283081055e+00
    phi[2,7]  R1695     -1.7306109666824341e+00
    phi[2,7]  R1696     -0.603119969367981
    phi[2,7]  R1697     -1.0538656711578369e+00
    phi[2,7]  R1698     -2.2965674400329590e+00
    phi[2,7]  R1699     -2.0353040695190430e+00
    phi[2,7]  R1700     -9.5020908117294312e-01
    phi[2,7]  R1701     -2.1424562931060791e+00
    phi[2,7]  R1702     1.4938391745090485e-02
    phi[2,7]  R1703     3.9530289173126221e-01
    phi[2,7]  R1704     -1.6884776949882507e-01
    phi[2,7]  R1705     -4.2270806431770325e-01
    phi[2,7]  R1706     -2.3892448842525482e-01
    phi[2,7]  R1707     1.7799629271030426e-01
    phi[2,7]  R1708     9.9110698699951172e-01
    phi[2,7]  R1709     -1.6048654317855835e+00
    phi[2,7]  R1710     -1.4987109899520874e+00
    phi[7,2]  R18       -1
    phi[7,2]  R63       1
    phi[7,2]  R64       1
    phi[7,2]  R1711     -3.0999999046325684e+00
    phi[7,2]  R1712     -3.0999999046325684e+00
    phi[7,2]  R1713     -2.2400000095367432e+00
    phi[7,2]  R1714     -2.2400000095367432e+00
    phi[7,2]  R1715     -3.0999999046325684e+00
    phi[7,2]  R1716     -3.0999999046325684e+00
    phi[7,2]  R1717     -2.5699999332427979e+00
    phi[7,2]  R1718     -2.5699999332427979e+00
    phi[7,2]  R1719     -3.0999999046325684e+00
    phi[7,2]  R1720     -3.0999999046325684e+00
    phi[7,2]  R1721     -2.0899999141693115e+00
    phi[7,2]  R1722     -2.0899999141693115e+00
    phi[7,2]  R1723     -3.0999999046325684e+00
    phi[7,2]  R1724     -3.0999999046325684e+00
    phi[7,2]  R1725     -0.509100079536438
    phi[7,2]  R1726     -5.4582124948501587e-01
    phi[7,2]  R1727     -1.3468535244464874e-01
    phi[7,2]  R1728     -1.3789841532707214e-01
    phi[7,2]  R1729     5.4770298302173615e-02
    phi[7,2]  R1730     2.1304650306701660e+00
    phi[7,2]  R1731     -1.2972854375839233e+00
    phi[7,2]  R1732     3.2123723626136780e-01
    phi[7,2]  R1733     1.7603840827941895e+00
    phi[7,2]  R1734     2.6542577743530273e+00
    phi[7,2]  R1735     -9.0353327989578247e-01
    phi[7,2]  R1736     -1.3421695232391357e+00
    phi[7,2]  R1737     -3.1466927528381348e+00
    phi[7,2]  R1738     -1.0275068283081055e+00
    phi[7,2]  R1739     -1.7306109666824341e+00
    phi[7,2]  R1740     -0.603119969367981
    phi[7,2]  R1741     -1.0538656711578369e+00
    phi[7,2]  R1742     -2.2965674400329590e+00
    phi[7,2]  R1743     -2.0353040695190430e+00
    phi[7,2]  R1744     -9.5020908117294312e-01
    phi[7,2]  R1745     -2.1424562931060791e+00
    phi[7,2]  R1746     1.4938391745090485e-02
    phi[7,2]  R1747     3.9530289173126221e-01
    phi[7,2]  R1748     -1.6884776949882507e-01
    phi[7,2]  R1749     -4.2270806431770325e-01
    phi[7,2]  R1750     -2.3892448842525482e-01
    phi[7,2]  R1751     1.7799629271030426e-01
    phi[7,2]  R1752     9.9110698699951172e-01
    phi[7,2]  R1753     -1.6048654317855835e+00
    phi[7,2]  R1754     -1.4987109899520874e+00
    phi[7,2]  R1755     3.5585775971412659e-01
    phi[7,2]  R1756     9.6406465768814087e-01
    phi[7,2]  R1757     5.7580178976058960e-01
    phi[7,2]  R1758     -8.9371937513351440e-01
    phi[7,2]  R1759     1.0209938287734985e+00
    phi[7,2]  R1760     1.9247062504291534e-01
    phi[7,2]  R1761     1.0486173629760742e+00
    phi[7,2]  R1762     -2.5680476427078247e-01
    phi[7,2]  R1763     3.6642253398895264e-01
    phi[7,2]  R1764     -3.8091205060482025e-02
    phi[7,2]  R1765     1.1892268657684326e+00
    phi[7,2]  R1766     7.8256106376647949e-01
    phi[7,2]  R1767     -0.451742559671402
    phi[7,2]  R1768     -6.0869228839874268e-01
    phi[7,2]  R1769     8.4558510780334473e-01
    phi[7,2]  R1770     1.0185252428054810e+00
    phi[7,2]  R1771     -1.6792182624340057e-01
    phi[7,2]  R1772     -4.6601867675781250e-01
    phi[7,2]  R1773     -7.7613002061843872e-01
    phi[7,2]  R1774     -0.853714644908905
    phi[7,2]  R1775     -1.1418981552124023e+00
    phi[7,2]  R1776     -1.4407485723495483e+00
    phi[7,2]  R1777     -1.3943345546722412e+00
    phi[7,2]  R1778     1.0306119173765182e-01
    phi[7,2]  R1779     -7.9448485374450684e-01
    phi[7,2]  R1780     4.0824121236801147e-01
    phi[7,2]  R1781     1.1788765192031860e+00
    phi[7,2]  R1782     1.2675729990005493e+00
    phi[7,2]  R1783     -5.7105940580368042e-01
    phi[7,2]  R1784     4.3831646442413330e-01
    phi[7,2]  R1785     1.0975919961929321e+00
    phi[7,2]  R1786     -0.864722728729248
    phi[7,2]  R1787     -2.1740472316741943e+00
    phi[7,2]  R1788     -1.6923584938049316e+00
    phi[7,2]  R1789     -0.0430297777056694
    phi[7,2]  R1790     -6.3506138324737549e-01
    phi[7,2]  R1791     -2.1119022369384766e+00
    phi[7,2]  R1792     2.9268914461135864e-01
    phi[7,2]  R1793     -2.4455361366271973e+00
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1794     -3.0999999046325684e+00
    phi[3,7]  R1795     -3.0999999046325684e+00
    phi[3,7]  R1796     -2.2400000095367432e+00
    phi[3,7]  R1797     -2.2400000095367432e+00
    phi[3,7]  R1798     -3.0999999046325684e+00
    phi[3,7]  R1799     -3.0999999046325684e+00
    phi[3,7]  R1800     -2.5699999332427979e+00
    phi[3,7]  R1801     -2.5699999332427979e+00
    phi[3,7]  R1802     -3.0999999046325684e+00
    phi[3,7]  R1803     -3.0999999046325684e+00
    phi[3,7]  R1804     -2.0899999141693115e+00
    phi[3,7]  R1805     -2.0899999141693115e+00
    phi[3,7]  R1806     -3.0999999046325684e+00
    phi[3,7]  R1807     -3.0999999046325684e+00
    phi[3,7]  R1808     1.2750611305236816e+00
    phi[3,7]  R1809     -1.0193871259689331e+00
    phi[3,7]  R1810     6.6280996799468994e-01
    phi[3,7]  R1811     1.9177225232124329e-01
    phi[3,7]  R1812     2.2841414809226990e-01
    phi[3,7]  R1813     5.1101052761077881e-01
    phi[3,7]  R1814     -2.4765176773071289e+00
    phi[3,7]  R1815     9.4632118940353394e-01
    phi[3,7]  R1816     1.5906384214758873e-03
    phi[3,7]  R1817     -3.0656335353851318e+00
    phi[3,7]  R1818     4.3246039748191833e-01
    phi[3,7]  R1819     1.5574162006378174e+00
    phi[3,7]  R1820     1.5564637184143066e+00
    phi[3,7]  R1821     2.1236889064311981e-01
    phi[3,7]  R1822     -9.7022807598114014e-01
    phi[3,7]  R1823     4.8991248011589050e-02
    phi[3,7]  R1824     -1.4896863698959351e+00
    phi[3,7]  R1825     -2.9681241512298584e+00
    phi[3,7]  R1826     -9.9440479278564453e-01
    phi[3,7]  R1827     1.5531022548675537e+00
    phi[3,7]  R1828     -3.1024255752563477e+00
    phi[3,7]  R1829     -3.6585597991943359e+00
    phi[3,7]  R1830     -2.6091744899749756e+00
    phi[3,7]  R1831     -2.3486399650573730e+00
    phi[3,7]  R1832     -2.1553784608840942e-01
    phi[3,7]  R1833     -0.984927237033844
    phi[3,7]  R1834     2.6275757700204849e-02
    phi[3,7]  R1835     -1.4217659235000610e+00
    phi[3,7]  R1836     -3.2184071838855743e-02
    phi[3,7]  R1837     -9.1687482595443726e-01
    phi[3,7]  R1838     1.0131727904081345e-03
    phi[3,7]  R1839     -2.0705003738403320e+00
    phi[3,7]  R1840     4.3474385142326355e-01
    phi[3,7]  R1841     -7.7667397260665894e-01
    phi[3,7]  R1842     -3.3311076164245605e+00
    phi[3,7]  R1843     -1.9384204149246216e+00
    phi[3,7]  R1844     -1.2497197389602661e+00
    phi[3,7]  R1845     -1.6457222700119019e+00
    phi[3,7]  R1846     3.9467829465866089e-01
    phi[3,7]  R1847     -2.0629756450653076e+00
    phi[3,7]  R1848     -2.4886839389801025e+00
    phi[3,7]  R1849     -2.9636569023132324e+00
    phi[3,7]  R1850     -1.9893159866333008e+00
    phi[3,7]  R1851     1.3387296199798584e+00
    phi[3,7]  R1852     -9.1892659664154053e-01
    phi[3,7]  R1853     3.7916311621665955e-01
    phi[3,7]  R1854     7.0439261198043823e-01
    phi[3,7]  R1855     1.2836631536483765e+00
    phi[3,7]  R1856     -1.1880122423171997e+00
    phi[3,7]  R1857     2.6326513290405273e+00
    phi[3,7]  R1858     -1.9612210988998413e+00
    phi[3,7]  R1859     1.4763481616973877e+00
    phi[3,7]  R1860     -1.9758594036102295e-01
    phi[3,7]  R1861     5.5797058343887329e-01
    phi[3,7]  R1862     1.2076336145401
    phi[3,7]  R1863     -1.9537040591239929e-01
    phi[3,7]  R1864     2.2815218195319176e-02
    phi[3,7]  R1865     1.0461459159851074e+00
    phi[3,7]  R1866     1.7430247366428375e-01
    phi[3,7]  R1867     2.4732495844364166e-01
    phi[3,7]  R1868     -0.509100079536438
    phi[3,7]  R1869     -5.4582124948501587e-01
    phi[3,7]  R1870     -1.3468535244464874e-01
    phi[3,7]  R1871     -1.3789841532707214e-01
    phi[3,7]  R1872     5.4770298302173615e-02
    phi[3,7]  R1873     2.1304650306701660e+00
    phi[3,7]  R1874     -1.2972854375839233e+00
    phi[3,7]  R1875     3.2123723626136780e-01
    phi[3,7]  R1876     1.7603840827941895e+00
    phi[3,7]  R1877     2.6542577743530273e+00
    phi[3,7]  R1878     -9.0353327989578247e-01
    phi[3,7]  R1879     -1.3421695232391357e+00
    phi[3,7]  R1880     -3.1466927528381348e+00
    phi[3,7]  R1881     -1.0275068283081055e+00
    phi[3,7]  R1882     -1.7306109666824341e+00
    phi[3,7]  R1883     -0.603119969367981
    phi[3,7]  R1884     -1.0538656711578369e+00
    phi[3,7]  R1885     -2.2965674400329590e+00
    phi[3,7]  R1886     -2.0353040695190430e+00
    phi[3,7]  R1887     -9.5020908117294312e-01
    phi[3,7]  R1888     -2.1424562931060791e+00
    phi[3,7]  R1889     1.4938391745090485e-02
    phi[3,7]  R1890     3.9530289173126221e-01
    phi[3,7]  R1891     -1.6884776949882507e-01
    phi[3,7]  R1892     -4.2270806431770325e-01
    phi[3,7]  R1893     -2.3892448842525482e-01
    phi[3,7]  R1894     1.7799629271030426e-01
    phi[3,7]  R1895     9.9110698699951172e-01
    phi[3,7]  R1896     -1.6048654317855835e+00
    phi[3,7]  R1897     -1.4987109899520874e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1898     -3.0999999046325684e+00
    phi[7,3]  R1899     -3.0999999046325684e+00
    phi[7,3]  R1900     -2.2400000095367432e+00
    phi[7,3]  R1901     -2.2400000095367432e+00
    phi[7,3]  R1902     -3.0999999046325684e+00
    phi[7,3]  R1903     -3.0999999046325684e+00
    phi[7,3]  R1904     -2.5699999332427979e+00
    phi[7,3]  R1905     -2.5699999332427979e+00
    phi[7,3]  R1906     -3.0999999046325684e+00
    phi[7,3]  R1907     -3.0999999046325684e+00
    phi[7,3]  R1908     -2.0899999141693115e+00
    phi[7,3]  R1909     -2.0899999141693115e+00
    phi[7,3]  R1910     -3.0999999046325684e+00
    phi[7,3]  R1911     -3.0999999046325684e+00
    phi[7,3]  R1912     -0.509100079536438
    phi[7,3]  R1913     -5.4582124948501587e-01
    phi[7,3]  R1914     -1.3468535244464874e-01
    phi[7,3]  R1915     -1.3789841532707214e-01
    phi[7,3]  R1916     5.4770298302173615e-02
    phi[7,3]  R1917     2.1304650306701660e+00
    phi[7,3]  R1918     -1.2972854375839233e+00
    phi[7,3]  R1919     3.2123723626136780e-01
    phi[7,3]  R1920     1.7603840827941895e+00
    phi[7,3]  R1921     2.6542577743530273e+00
    phi[7,3]  R1922     -9.0353327989578247e-01
    phi[7,3]  R1923     -1.3421695232391357e+00
    phi[7,3]  R1924     -3.1466927528381348e+00
    phi[7,3]  R1925     -1.0275068283081055e+00
    phi[7,3]  R1926     -1.7306109666824341e+00
    phi[7,3]  R1927     -0.603119969367981
    phi[7,3]  R1928     -1.0538656711578369e+00
    phi[7,3]  R1929     -2.2965674400329590e+00
    phi[7,3]  R1930     -2.0353040695190430e+00
    phi[7,3]  R1931     -9.5020908117294312e-01
    phi[7,3]  R1932     -2.1424562931060791e+00
    phi[7,3]  R1933     1.4938391745090485e-02
    phi[7,3]  R1934     3.9530289173126221e-01
    phi[7,3]  R1935     -1.6884776949882507e-01
    phi[7,3]  R1936     -4.2270806431770325e-01
    phi[7,3]  R1937     -2.3892448842525482e-01
    phi[7,3]  R1938     1.7799629271030426e-01
    phi[7,3]  R1939     9.9110698699951172e-01
    phi[7,3]  R1940     -1.6048654317855835e+00
    phi[7,3]  R1941     -1.4987109899520874e+00
    phi[7,3]  R1942     1.2750611305236816e+00
    phi[7,3]  R1943     -1.0193871259689331e+00
    phi[7,3]  R1944     6.6280996799468994e-01
    phi[7,3]  R1945     1.9177225232124329e-01
    phi[7,3]  R1946     2.2841414809226990e-01
    phi[7,3]  R1947     5.1101052761077881e-01
    phi[7,3]  R1948     -2.4765176773071289e+00
    phi[7,3]  R1949     9.4632118940353394e-01
    phi[7,3]  R1950     1.5906384214758873e-03
    phi[7,3]  R1951     -3.0656335353851318e+00
    phi[7,3]  R1952     4.3246039748191833e-01
    phi[7,3]  R1953     1.5574162006378174e+00
    phi[7,3]  R1954     1.5564637184143066e+00
    phi[7,3]  R1955     2.1236889064311981e-01
    phi[7,3]  R1956     -9.7022807598114014e-01
    phi[7,3]  R1957     4.8991248011589050e-02
    phi[7,3]  R1958     -1.4896863698959351e+00
    phi[7,3]  R1959     -2.9681241512298584e+00
    phi[7,3]  R1960     -9.9440479278564453e-01
    phi[7,3]  R1961     1.5531022548675537e+00
    phi[7,3]  R1962     -3.1024255752563477e+00
    phi[7,3]  R1963     -3.6585597991943359e+00
    phi[7,3]  R1964     -2.6091744899749756e+00
    phi[7,3]  R1965     -2.3486399650573730e+00
    phi[7,3]  R1966     -2.1553784608840942e-01
    phi[7,3]  R1967     -0.984927237033844
    phi[7,3]  R1968     2.6275757700204849e-02
    phi[7,3]  R1969     -1.4217659235000610e+00
    phi[7,3]  R1970     -3.2184071838855743e-02
    phi[7,3]  R1971     -9.1687482595443726e-01
    phi[7,3]  R1972     1.0131727904081345e-03
    phi[7,3]  R1973     -2.0705003738403320e+00
    phi[7,3]  R1974     4.3474385142326355e-01
    phi[7,3]  R1975     -7.7667397260665894e-01
    phi[7,3]  R1976     -3.3311076164245605e+00
    phi[7,3]  R1977     -1.9384204149246216e+00
    phi[7,3]  R1978     -1.2497197389602661e+00
    phi[7,3]  R1979     -1.6457222700119019e+00
    phi[7,3]  R1980     3.9467829465866089e-01
    phi[7,3]  R1981     -2.0629756450653076e+00
    phi[7,3]  R1982     -2.4886839389801025e+00
    phi[7,3]  R1983     -2.9636569023132324e+00
    phi[7,3]  R1984     -1.9893159866333008e+00
    phi[7,3]  R1985     1.3387296199798584e+00
    phi[7,3]  R1986     -9.1892659664154053e-01
    phi[7,3]  R1987     3.7916311621665955e-01
    phi[7,3]  R1988     7.0439261198043823e-01
    phi[7,3]  R1989     1.2836631536483765e+00
    phi[7,3]  R1990     -1.1880122423171997e+00
    phi[7,3]  R1991     2.6326513290405273e+00
    phi[7,3]  R1992     -1.9612210988998413e+00
    phi[7,3]  R1993     1.4763481616973877e+00
    phi[7,3]  R1994     -1.9758594036102295e-01
    phi[7,3]  R1995     5.5797058343887329e-01
    phi[7,3]  R1996     1.2076336145401
    phi[7,3]  R1997     -1.9537040591239929e-01
    phi[7,3]  R1998     2.2815218195319176e-02
    phi[7,3]  R1999     1.0461459159851074e+00
    phi[7,3]  R2000     1.7430247366428375e-01
    phi[7,3]  R2001     2.4732495844364166e-01
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R29       1.6467661140570644e+00
    phi[3,9]  R30       -1.0900934418643611e+00
    phi[3,9]  R31       -1.8966064735023589e+00
    phi[3,9]  R32       3.1072766440922361e-01
    phi[3,9]  R33       2.1560212699207635e+00
    phi[3,9]  R34       -7.8481442390854683e-01
    phi[3,9]  R35       2.1409913286535369e+00
    phi[3,9]  R73       -1
    phi[3,9]  R2002     -1.4532337905755039e+00
    phi[3,9]  R2003     -4.7467660186896330e+00
    phi[3,9]  R2004     -3.3300934514011042e+00
    phi[3,9]  R2005     -1.1499065676723821e+00
    phi[3,9]  R2006     -4.9966063781349277e+00
    phi[3,9]  R2007     -1.2033934311302095e+00
    phi[3,9]  R2008     -2.2592722688335742e+00
    phi[3,9]  R2009     -2.8807275976520215e+00
    phi[3,9]  R2010     -9.4397863471180488e-01
    phi[3,9]  R2011     -5.2560211745533323e+00
    phi[3,9]  R2012     -2.8748143380778584e+00
    phi[3,9]  R2013     -1.3051854902607647e+00
    phi[3,9]  R2014     -9.5900857597903144e-01
    phi[3,9]  R2015     -5.2409912332861053e+00
    phi[3,9]  R2016     -1.7444706025179979e-01
    phi[3,9]  R2017     -1.7612136072587037e-01
    phi[3,9]  R2018     -1.7770574393056715e-01
    phi[3,9]  R2019     -1.9632610073626017e-01
    phi[3,9]  R2020     -1.9799968152428771e-01
    phi[3,9]  R2021     -2.1450485355006987e-01
    phi[3,9]  R2022     -2.1678532978975662e-01
    phi[3,9]  R2023     -2.2254477603331813e-01
    phi[3,9]  R2024     -2.5856097735675110e-01
    phi[3,9]  R2025     -2.6355695890665976e-01
    phi[3,9]  R2026     -9.2162311473753045e-01
    phi[3,9]  R2027     -7.3856628999933127e-01
    phi[3,9]  R2028     -1.0121141507930580e+00
    phi[3,9]  R2029     -6.9339243451435151e-01
    phi[3,9]  R2030     -1.1303572258829977e+00
    phi[3,9]  R2031     -1.0317711669987444e+00
    phi[3,9]  R2032     -6.8464188323783060e-01
    phi[3,9]  R2033     -7.2680536747411750e-01
    phi[3,9]  R2034     -7.3980315510437544e-01
    phi[3,9]  R2035     -8.0986357962083755e-01
    phi[3,9]  R2036     -1.9249659274391462e-01
    phi[3,9]  R2037     -3.3930201643666713e-01
    phi[3,9]  R2038     -3.8939974462769333e-01
    phi[3,9]  R2039     -4.1422705829917317e-01
    phi[3,9]  R2040     -7.8167559816810894e-01
    phi[3,9]  R2041     -1.0171999687263236e+00
    phi[3,9]  R2042     -4.8238751831308890e-01
    phi[3,9]  R2043     -4.8667910605169862e-01
    phi[3,9]  R2044     -4.9544904241337617e-01
    phi[3,9]  R2045     -1.1949524333330561e+00
    phi[3,9]  R2046     -1.0313961347971659e+00
    phi[3,9]  R2047     -1.0031069724987496e+00
    phi[3,9]  R2048     -1.1926668875159294e+00
    phi[3,9]  R2049     -1.4742722734329385e+00
    phi[3,9]  R2050     -1.5031439382895018e+00
    phi[3,9]  R2051     -6.2574492887511335e-01
    phi[3,9]  R2052     -0.62813335453404
    phi[3,9]  R2053     -6.8974439288115785e-01
    phi[3,9]  R2054     -8.5845176184840044e-01
    phi[3,9]  R2055     -7.0306712270957639e-01
    phi[3,9]  R2056     -2.0174863708622137e-01
    phi[3,9]  R2057     -2.1110367268724284e-01
    phi[3,9]  R2058     -3.1827776753719572e-01
    phi[3,9]  R2059     -9.1522181724975038e-01
    phi[3,9]  R2060     -4.5319742557726717e-01
    phi[3,9]  R2061     -7.9574617270947634e-01
    phi[3,9]  R2062     -6.3115052065568089e-01
    phi[3,9]  R2063     -9.5635809465481181e-01
    phi[3,9]  R2064     -5.0708319571462124e-01
    phi[3,9]  R2065     -0.547598585999002
    phi[3,9]  R2066     -2.4050283484131940e-01
    phi[3,9]  R2067     -8.0913633946323138e-01
    phi[3,9]  R2068     -9.4252796020863350e-01
    phi[3,9]  R2069     -7.7483227644058572e-01
    phi[3,9]  R2070     -7.8095196019390367e-01
    phi[3,9]  R2071     -7.8952116298017394e-01
    phi[3,9]  R2072     -7.9367441489591584e-01
    phi[3,9]  R2073     -0.799674310544102
    phi[3,9]  R2074     -0.80600845677233
    phi[3,9]  R2075     -0.807816821140227
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2076     -3.0999999046325684e+00
    phi[4,5]  R2077     -3.0999999046325684e+00
    phi[4,5]  R2078     -2.2400000095367432e+00
    phi[4,5]  R2079     -2.2400000095367432e+00
    phi[4,5]  R2080     -3.0999999046325684e+00
    phi[4,5]  R2081     -3.0999999046325684e+00
    phi[4,5]  R2082     -2.5699999332427979e+00
    phi[4,5]  R2083     -2.5699999332427979e+00
    phi[4,5]  R2084     -3.0999999046325684e+00
    phi[4,5]  R2085     -3.0999999046325684e+00
    phi[4,5]  R2086     -2.0899999141693115e+00
    phi[4,5]  R2087     -2.0899999141693115e+00
    phi[4,5]  R2088     -3.0999999046325684e+00
    phi[4,5]  R2089     -3.0999999046325684e+00
    phi[4,5]  R2090     9.8341327905654907e-01
    phi[4,5]  R2091     2.0948660373687744e+00
    phi[4,5]  R2092     -3.6840125918388367e-01
    phi[4,5]  R2093     2.2145066261291504e+00
    phi[4,5]  R2094     1.6157926321029663e+00
    phi[4,5]  R2095     1.0907759666442871e+00
    phi[4,5]  R2096     -8.4334135055541992e-02
    phi[4,5]  R2097     6.9346809387207031e-01
    phi[4,5]  R2098     -2.6535394191741943e+00
    phi[4,5]  R2099     -3.7644690275192261e-01
    phi[4,5]  R2100     -1.8635175228118896e+00
    phi[4,5]  R2101     -3.8741405010223389e+00
    phi[4,5]  R2102     -2.4752168655395508e+00
    phi[4,5]  R2103     -1.4937758445739746e-02
    phi[4,5]  R2104     -2.4671635627746582e+00
    phi[4,5]  R2105     -1.9044086933135986e+00
    phi[4,5]  R2106     -7.7057951688766479e-01
    phi[4,5]  R2107     -1.0320322513580322e+00
    phi[4,5]  R2108     -4.8893445730209351e-01
    phi[4,5]  R2109     -2.5546479225158691e+00
    phi[4,5]  R2110     -1.1023164987564087e+00
    phi[4,5]  R2111     -1.5694333314895630e+00
    phi[4,5]  R2112     -1.1629192829132080e+00
    phi[4,5]  R2113     -3.3400299549102783e+00
    phi[4,5]  R2114     -2.3218419551849365e+00
    phi[4,5]  R2115     -1.9715992212295532e+00
    phi[4,5]  R2116     -2.1862585544586182e+00
    phi[4,5]  R2117     -1.7571188211441040e+00
    phi[4,5]  R2118     -8.9870297908782959e-01
    phi[4,5]  R2119     -0.860573410987854
    phi[4,5]  R2120     -9.3219071626663208e-01
    phi[4,5]  R2121     -2.5157997608184814e+00
    phi[4,5]  R2122     -4.8017680644989014e-01
    phi[4,5]  R2123     -9.8018229007720947e-01
    phi[4,5]  R2124     1.5706716775894165e+00
    phi[4,5]  R2125     1.9583405256271362e+00
    phi[4,5]  R2126     1.2287366390228271e+00
    phi[4,5]  R2127     3.8366794586181641e-01
    phi[4,5]  R2128     1.3445776700973511e+00
    phi[4,5]  R2129     1.6221430301666260e+00
    phi[4,5]  R2130     1.0565568208694458e+00
    phi[4,5]  R2131     1.4058091640472412e+00
    phi[4,5]  R2132     -6.7188709974288940e-01
    phi[4,5]  R2133     1.0800620317459106e+00
    phi[4,5]  R2134     7.0081883668899536e-01
    phi[4,5]  R2135     1.5403277873992920e+00
    phi[4,5]  R2136     8.6432105302810669e-01
    phi[4,5]  R2137     -1.8816745281219482e+00
    phi[4,5]  R2138     -4.3075603246688843e-01
    phi[4,5]  R2139     2.4889285862445831e-01
    phi[4,5]  R2140     -4.8190689086914062e-01
    phi[4,5]  R2141     8.1806343793869019e-01
    phi[4,5]  R2142     -2.3819696903228760e+00
    phi[4,5]  R2143     -6.7526981234550476e-02
    phi[4,5]  R2144     3.6781147122383118e-01
    phi[4,5]  R2145     1.3672226667404175e-01
    phi[4,5]  R2146     -1.8449516296386719e+00
    phi[4,5]  R2147     -1.4144712686538696e+00
    phi[4,5]  R2148     -4.5123642683029175e-01
    phi[4,5]  R2149     9.7672455012798309e-02
    phi[4,5]  R2150     -1.1275695562362671e+00
    phi[4,5]  R2151     -1.2604030370712280e+00
    phi[4,5]  R2152     -4.0946716070175171e-01
    phi[4,5]  R2153     -1.5646628141403198e+00
    phi[4,5]  R2154     -6.0414898395538330e-01
    phi[4,5]  R2155     -1.6126250028610229e+00
    phi[4,5]  R2156     -1.6807780265808105e+00
    phi[4,5]  R2157     1.1445027589797974e+00
    phi[4,5]  R2158     -1.1493481397628784e+00
    phi[4,5]  R2159     1.0303270816802979e+00
    phi[4,5]  R2160     -2.3878691196441650e+00
    phi[4,5]  R2161     0.889646589756012
    phi[4,5]  R2162     -2.1160848140716553e+00
    phi[4,5]  R2163     -4.5015635490417480e+00
    phi[4,5]  R2164     -5.3858470916748047e-01
    phi[4,5]  R2165     -4.0514345169067383e+00
    phi[4,5]  R2166     -1.2144057750701904e+00
    phi[4,5]  R2167     6.9984000921249390e-01
    phi[4,5]  R2168     1.2734032869338989e+00
    phi[4,5]  R2169     -2.3474791049957275e+00
    phi[4,5]  R2170     -3.7649455070495605e+00
    phi[4,5]  R2171     -3.6166725158691406e+00
    phi[4,5]  R2172     -1.3383241891860962e+00
    phi[4,5]  R2173     -1.3237434625625610e+00
    phi[4,5]  R2174     -1.0584704875946045e+00
    phi[4,5]  R2175     -1.9773107767105103e+00
    phi[4,5]  R2176     -2.6628782749176025e+00
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2177     -3.0999999046325684e+00
    phi[5,4]  R2178     -3.0999999046325684e+00
    phi[5,4]  R2179     -2.2400000095367432e+00
    phi[5,4]  R2180     -2.2400000095367432e+00
    phi[5,4]  R2181     -3.0999999046325684e+00
    phi[5,4]  R2182     -3.0999999046325684e+00
    phi[5,4]  R2183     -2.5699999332427979e+00
    phi[5,4]  R2184     -2.5699999332427979e+00
    phi[5,4]  R2185     -3.0999999046325684e+00
    phi[5,4]  R2186     -3.0999999046325684e+00
    phi[5,4]  R2187     -2.0899999141693115e+00
    phi[5,4]  R2188     -2.0899999141693115e+00
    phi[5,4]  R2189     -3.0999999046325684e+00
    phi[5,4]  R2190     -3.0999999046325684e+00
    phi[5,4]  R2191     3.8366794586181641e-01
    phi[5,4]  R2192     1.3445776700973511e+00
    phi[5,4]  R2193     1.6221430301666260e+00
    phi[5,4]  R2194     1.0565568208694458e+00
    phi[5,4]  R2195     1.4058091640472412e+00
    phi[5,4]  R2196     -6.7188709974288940e-01
    phi[5,4]  R2197     1.0800620317459106e+00
    phi[5,4]  R2198     7.0081883668899536e-01
    phi[5,4]  R2199     1.5403277873992920e+00
    phi[5,4]  R2200     8.6432105302810669e-01
    phi[5,4]  R2201     -1.8816745281219482e+00
    phi[5,4]  R2202     -4.3075603246688843e-01
    phi[5,4]  R2203     2.4889285862445831e-01
    phi[5,4]  R2204     -4.8190689086914062e-01
    phi[5,4]  R2205     8.1806343793869019e-01
    phi[5,4]  R2206     -2.3819696903228760e+00
    phi[5,4]  R2207     -6.7526981234550476e-02
    phi[5,4]  R2208     3.6781147122383118e-01
    phi[5,4]  R2209     1.3672226667404175e-01
    phi[5,4]  R2210     -1.8449516296386719e+00
    phi[5,4]  R2211     -1.4144712686538696e+00
    phi[5,4]  R2212     -4.5123642683029175e-01
    phi[5,4]  R2213     9.7672455012798309e-02
    phi[5,4]  R2214     -1.1275695562362671e+00
    phi[5,4]  R2215     -1.2604030370712280e+00
    phi[5,4]  R2216     -4.0946716070175171e-01
    phi[5,4]  R2217     -1.5646628141403198e+00
    phi[5,4]  R2218     -6.0414898395538330e-01
    phi[5,4]  R2219     -1.6126250028610229e+00
    phi[5,4]  R2220     -1.6807780265808105e+00
    phi[5,4]  R2221     1.1445027589797974e+00
    phi[5,4]  R2222     -1.1493481397628784e+00
    phi[5,4]  R2223     1.0303270816802979e+00
    phi[5,4]  R2224     -2.3878691196441650e+00
    phi[5,4]  R2225     0.889646589756012
    phi[5,4]  R2226     -2.1160848140716553e+00
    phi[5,4]  R2227     -4.5015635490417480e+00
    phi[5,4]  R2228     -5.3858470916748047e-01
    phi[5,4]  R2229     -4.0514345169067383e+00
    phi[5,4]  R2230     -1.2144057750701904e+00
    phi[5,4]  R2231     6.9984000921249390e-01
    phi[5,4]  R2232     1.2734032869338989e+00
    phi[5,4]  R2233     -2.3474791049957275e+00
    phi[5,4]  R2234     -3.7649455070495605e+00
    phi[5,4]  R2235     -3.6166725158691406e+00
    phi[5,4]  R2236     -1.3383241891860962e+00
    phi[5,4]  R2237     -1.3237434625625610e+00
    phi[5,4]  R2238     -1.0584704875946045e+00
    phi[5,4]  R2239     -1.9773107767105103e+00
    phi[5,4]  R2240     -2.6628782749176025e+00
    phi[5,4]  R2241     9.8341327905654907e-01
    phi[5,4]  R2242     2.0948660373687744e+00
    phi[5,4]  R2243     -3.6840125918388367e-01
    phi[5,4]  R2244     2.2145066261291504e+00
    phi[5,4]  R2245     1.6157926321029663e+00
    phi[5,4]  R2246     1.0907759666442871e+00
    phi[5,4]  R2247     -8.4334135055541992e-02
    phi[5,4]  R2248     6.9346809387207031e-01
    phi[5,4]  R2249     -2.6535394191741943e+00
    phi[5,4]  R2250     -3.7644690275192261e-01
    phi[5,4]  R2251     -1.8635175228118896e+00
    phi[5,4]  R2252     -3.8741405010223389e+00
    phi[5,4]  R2253     -2.4752168655395508e+00
    phi[5,4]  R2254     -1.4937758445739746e-02
    phi[5,4]  R2255     -2.4671635627746582e+00
    phi[5,4]  R2256     -1.9044086933135986e+00
    phi[5,4]  R2257     -7.7057951688766479e-01
    phi[5,4]  R2258     -1.0320322513580322e+00
    phi[5,4]  R2259     -4.8893445730209351e-01
    phi[5,4]  R2260     -2.5546479225158691e+00
    phi[5,4]  R2261     -1.1023164987564087e+00
    phi[5,4]  R2262     -1.5694333314895630e+00
    phi[5,4]  R2263     -1.1629192829132080e+00
    phi[5,4]  R2264     -3.3400299549102783e+00
    phi[5,4]  R2265     -2.3218419551849365e+00
    phi[5,4]  R2266     -1.9715992212295532e+00
    phi[5,4]  R2267     -2.1862585544586182e+00
    phi[5,4]  R2268     -1.7571188211441040e+00
    phi[5,4]  R2269     -8.9870297908782959e-01
    phi[5,4]  R2270     -0.860573410987854
    phi[5,4]  R2271     -9.3219071626663208e-01
    phi[5,4]  R2272     -2.5157997608184814e+00
    phi[5,4]  R2273     -4.8017680644989014e-01
    phi[5,4]  R2274     -9.8018229007720947e-01
    phi[5,4]  R2275     1.5706716775894165e+00
    phi[5,4]  R2276     1.9583405256271362e+00
    phi[5,4]  R2277     1.2287366390228271e+00
    phi[8,4]  R36       -1
    phi[8,4]  R38       2.4988626383964481e+00
    phi[8,4]  R39       1.1155125521061739e+00
    phi[8,4]  R40       1.3169240654141183e+00
    phi[8,4]  R41       2.3094059559701177e+00
    phi[8,4]  R42       1.0508153472736645e+00
    phi[8,4]  R43       1.8036317031965696e+00
    phi[8,4]  R44       -6.2164954926904770e-01
    phi[8,4]  R72       1
    phi[8,4]  R2278     -5.5988625430290160e+00
    phi[8,4]  R2279     -6.0113726623612029e-01
    phi[8,4]  R2280     -3.3555125616429171e+00
    phi[8,4]  R2281     -1.1244874574305692e+00
    phi[8,4]  R2282     -4.4169239700466871e+00
    phi[8,4]  R2283     -1.78307583921845
    phi[8,4]  R2284     -4.8794058892129151e+00
    phi[8,4]  R2285     -2.6059397727268019e-01
    phi[8,4]  R2286     -4.1508152519062325e+00
    phi[8,4]  R2287     -2.0491845573589038e+00
    phi[8,4]  R2288     -3.8936316173658811e+00
    phi[8,4]  R2289     -2.8636821097274190e-01
    phi[8,4]  R2290     -2.4783503553635207e+00
    phi[8,4]  R2291     -3.7216494539016161e+00
    phi[8,4]  R2292     -0.00535947805252357
    phi[8,4]  R2293     -2.8975306091640007e-02
    phi[8,4]  R2294     -4.2109007773873997e-02
    phi[8,4]  R2295     -4.8418104091181746e-02
    phi[8,4]  R2296     -1.0782591129223751e-01
    phi[8,4]  R2297     -1.0598854208156379e+00
    phi[8,4]  R2298     -1.1091373271882288e+00
    phi[8,4]  R2299     -1.7862623913257023e+00
    phi[8,4]  R2300     -1.3564560839361539e+00
    phi[8,4]  R2301     -2.4875194073026128e+00
    phi[8,4]  R2302     -4.0664779129125250e-02
    phi[8,4]  R2303     -2.3286381290815461e-01
    phi[8,4]  R2304     -3.0603442235033596e-01
    phi[8,4]  R2305     -3.1912283495519489e-01
    phi[8,4]  R2306     -3.2583894622965071e-01
    phi[8,4]  R2307     -3.2659012887738270e-01
    phi[8,4]  R2308     -3.3105440614846737e-01
    phi[8,4]  R2309     -3.3772648669921712e-01
    phi[8,4]  R2310     -3.3890526729159876e-01
    phi[8,4]  R2311     -3.4479742035530636e-01
    phi[8,4]  R2312     -2.9407975514613627e-01
    phi[8,4]  R2313     -3.0499939076903337e-01
    phi[8,4]  R2314     -3.0820830955547840e-01
    phi[8,4]  R2315     -3.1246127190659934e-01
    phi[8,4]  R2316     -3.1259798871938393e-01
    phi[8,4]  R2317     -3.1332931846275081e-01
    phi[8,4]  R2318     -3.1534981199415868e-01
    phi[8,4]  R2319     -3.1974764733809646e-01
    phi[8,4]  R2320     -3.3562443256046626e-01
    phi[8,4]  R2321     -3.4862884726510279e-01
    phi[8,4]  R2322     -2.8910031278208859e-01
    phi[8,4]  R2323     -0.309789816450849
    phi[8,4]  R2324     -3.3859321526297648e-01
    phi[8,4]  R2325     -3.4279376609015011e-01
    phi[8,4]  R2326     -6.2925981424612765e-01
    phi[8,4]  R2327     -6.3146047712709663e-01
    phi[8,4]  R2328     -6.5617300333822448e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2329     -3.0999999046325684e+00
    phi[5,6]  R2330     -3.0999999046325684e+00
    phi[5,6]  R2331     -2.2400000095367432e+00
    phi[5,6]  R2332     -2.2400000095367432e+00
    phi[5,6]  R2333     -3.0999999046325684e+00
    phi[5,6]  R2334     -3.0999999046325684e+00
    phi[5,6]  R2335     -2.5699999332427979e+00
    phi[5,6]  R2336     -2.5699999332427979e+00
    phi[5,6]  R2337     -3.0999999046325684e+00
    phi[5,6]  R2338     -3.0999999046325684e+00
    phi[5,6]  R2339     -2.0899999141693115e+00
    phi[5,6]  R2340     -2.0899999141693115e+00
    phi[5,6]  R2341     -3.0999999046325684e+00
    phi[5,6]  R2342     -3.0999999046325684e+00
    phi[5,6]  R2343     3.8366794586181641e-01
    phi[5,6]  R2344     1.3445776700973511e+00
    phi[5,6]  R2345     1.6221430301666260e+00
    phi[5,6]  R2346     1.0565568208694458e+00
    phi[5,6]  R2347     1.4058091640472412e+00
    phi[5,6]  R2348     -6.7188709974288940e-01
    phi[5,6]  R2349     1.0800620317459106e+00
    phi[5,6]  R2350     7.0081883668899536e-01
    phi[5,6]  R2351     1.5403277873992920e+00
    phi[5,6]  R2352     8.6432105302810669e-01
    phi[5,6]  R2353     -1.8816745281219482e+00
    phi[5,6]  R2354     -4.3075603246688843e-01
    phi[5,6]  R2355     2.4889285862445831e-01
    phi[5,6]  R2356     -4.8190689086914062e-01
    phi[5,6]  R2357     8.1806343793869019e-01
    phi[5,6]  R2358     -2.3819696903228760e+00
    phi[5,6]  R2359     -6.7526981234550476e-02
    phi[5,6]  R2360     3.6781147122383118e-01
    phi[5,6]  R2361     1.3672226667404175e-01
    phi[5,6]  R2362     -1.8449516296386719e+00
    phi[5,6]  R2363     -1.4144712686538696e+00
    phi[5,6]  R2364     -4.5123642683029175e-01
    phi[5,6]  R2365     9.7672455012798309e-02
    phi[5,6]  R2366     -1.1275695562362671e+00
    phi[5,6]  R2367     -1.2604030370712280e+00
    phi[5,6]  R2368     -4.0946716070175171e-01
    phi[5,6]  R2369     -1.5646628141403198e+00
    phi[5,6]  R2370     -6.0414898395538330e-01
    phi[5,6]  R2371     -1.6126250028610229e+00
    phi[5,6]  R2372     -1.6807780265808105e+00
    phi[5,6]  R2373     1.1445027589797974e+00
    phi[5,6]  R2374     -1.1493481397628784e+00
    phi[5,6]  R2375     1.0303270816802979e+00
    phi[5,6]  R2376     -2.3878691196441650e+00
    phi[5,6]  R2377     0.889646589756012
    phi[5,6]  R2378     -2.1160848140716553e+00
    phi[5,6]  R2379     -4.5015635490417480e+00
    phi[5,6]  R2380     -5.3858470916748047e-01
    phi[5,6]  R2381     -4.0514345169067383e+00
    phi[5,6]  R2382     -1.2144057750701904e+00
    phi[5,6]  R2383     6.9984000921249390e-01
    phi[5,6]  R2384     1.2734032869338989e+00
    phi[5,6]  R2385     -2.3474791049957275e+00
    phi[5,6]  R2386     -3.7649455070495605e+00
    phi[5,6]  R2387     -3.6166725158691406e+00
    phi[5,6]  R2388     -1.3383241891860962e+00
    phi[5,6]  R2389     -1.3237434625625610e+00
    phi[5,6]  R2390     -1.0584704875946045e+00
    phi[5,6]  R2391     -1.9773107767105103e+00
    phi[5,6]  R2392     -2.6628782749176025e+00
    phi[5,6]  R2393     1.3193278014659882e-01
    phi[5,6]  R2394     2.9593631625175476e-01
    phi[5,6]  R2395     1.2675023078918457e+00
    phi[5,6]  R2396     8.5200232267379761e-01
    phi[5,6]  R2397     1.6841987371444702e+00
    phi[5,6]  R2398     9.3283337354660034e-01
    phi[5,6]  R2399     5.4867851734161377e-01
    phi[5,6]  R2400     1.5676145255565643e-01
    phi[5,6]  R2401     -1.7623569965362549e+00
    phi[5,6]  R2402     2.1422662734985352e+00
    phi[5,6]  R2403     -1.6789739131927490e+00
    phi[5,6]  R2404     -1.1386463642120361e+00
    phi[5,6]  R2405     -9.7037839889526367e-01
    phi[5,6]  R2406     -4.0429848432540894e-01
    phi[5,6]  R2407     -6.6835576295852661e-01
    phi[5,6]  R2408     -4.5904809236526489e-01
    phi[5,6]  R2409     -5.6741154193878174e-01
    phi[5,6]  R2410     -1.0232281684875488e+00
    phi[5,6]  R2411     -4.6817946434020996e-01
    phi[5,6]  R2412     4.2745381593704224e-01
    phi[5,6]  R2413     0.586158037185669
    phi[5,6]  R2414     -1.1873445510864258e+00
    phi[5,6]  R2415     8.3569222688674927e-01
    phi[5,6]  R2416     -6.6599881649017334e-01
    phi[5,6]  R2417     -2.8104436397552490e-01
    phi[5,6]  R2418     -4.7718322277069092e-01
    phi[5,6]  R2419     -3.2573205232620239e-01
    phi[5,6]  R2420     -1.7913311719894409e-01
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2421     -3.0999999046325684e+00
    phi[6,5]  R2422     -3.0999999046325684e+00
    phi[6,5]  R2423     -2.2400000095367432e+00
    phi[6,5]  R2424     -2.2400000095367432e+00
    phi[6,5]  R2425     -3.0999999046325684e+00
    phi[6,5]  R2426     -3.0999999046325684e+00
    phi[6,5]  R2427     -2.5699999332427979e+00
    phi[6,5]  R2428     -2.5699999332427979e+00
    phi[6,5]  R2429     -3.0999999046325684e+00
    phi[6,5]  R2430     -3.0999999046325684e+00
    phi[6,5]  R2431     -2.0899999141693115e+00
    phi[6,5]  R2432     -2.0899999141693115e+00
    phi[6,5]  R2433     -3.0999999046325684e+00
    phi[6,5]  R2434     -3.0999999046325684e+00
    phi[6,5]  R2435     1.3193278014659882e-01
    phi[6,5]  R2436     2.9593631625175476e-01
    phi[6,5]  R2437     1.2675023078918457e+00
    phi[6,5]  R2438     8.5200232267379761e-01
    phi[6,5]  R2439     1.6841987371444702e+00
    phi[6,5]  R2440     9.3283337354660034e-01
    phi[6,5]  R2441     5.4867851734161377e-01
    phi[6,5]  R2442     1.5676145255565643e-01
    phi[6,5]  R2443     -1.7623569965362549e+00
    phi[6,5]  R2444     2.1422662734985352e+00
    phi[6,5]  R2445     -1.6789739131927490e+00
    phi[6,5]  R2446     -1.1386463642120361e+00
    phi[6,5]  R2447     -9.7037839889526367e-01
    phi[6,5]  R2448     -4.0429848432540894e-01
    phi[6,5]  R2449     -6.6835576295852661e-01
    phi[6,5]  R2450     -4.5904809236526489e-01
    phi[6,5]  R2451     -5.6741154193878174e-01
    phi[6,5]  R2452     -1.0232281684875488e+00
    phi[6,5]  R2453     -4.6817946434020996e-01
    phi[6,5]  R2454     4.2745381593704224e-01
    phi[6,5]  R2455     0.586158037185669
    phi[6,5]  R2456     -1.1873445510864258e+00
    phi[6,5]  R2457     8.3569222688674927e-01
    phi[6,5]  R2458     -6.6599881649017334e-01
    phi[6,5]  R2459     -2.8104436397552490e-01
    phi[6,5]  R2460     -4.7718322277069092e-01
    phi[6,5]  R2461     -3.2573205232620239e-01
    phi[6,5]  R2462     -1.7913311719894409e-01
    phi[6,5]  R2463     3.8366794586181641e-01
    phi[6,5]  R2464     1.3445776700973511e+00
    phi[6,5]  R2465     1.6221430301666260e+00
    phi[6,5]  R2466     1.0565568208694458e+00
    phi[6,5]  R2467     1.4058091640472412e+00
    phi[6,5]  R2468     -6.7188709974288940e-01
    phi[6,5]  R2469     1.0800620317459106e+00
    phi[6,5]  R2470     7.0081883668899536e-01
    phi[6,5]  R2471     1.5403277873992920e+00
    phi[6,5]  R2472     8.6432105302810669e-01
    phi[6,5]  R2473     -1.8816745281219482e+00
    phi[6,5]  R2474     -4.3075603246688843e-01
    phi[6,5]  R2475     2.4889285862445831e-01
    phi[6,5]  R2476     -4.8190689086914062e-01
    phi[6,5]  R2477     8.1806343793869019e-01
    phi[6,5]  R2478     -2.3819696903228760e+00
    phi[6,5]  R2479     -6.7526981234550476e-02
    phi[6,5]  R2480     3.6781147122383118e-01
    phi[6,5]  R2481     1.3672226667404175e-01
    phi[6,5]  R2482     -1.8449516296386719e+00
    phi[6,5]  R2483     -1.4144712686538696e+00
    phi[6,5]  R2484     -4.5123642683029175e-01
    phi[6,5]  R2485     9.7672455012798309e-02
    phi[6,5]  R2486     -1.1275695562362671e+00
    phi[6,5]  R2487     -1.2604030370712280e+00
    phi[6,5]  R2488     -4.0946716070175171e-01
    phi[6,5]  R2489     -1.5646628141403198e+00
    phi[6,5]  R2490     -6.0414898395538330e-01
    phi[6,5]  R2491     -1.6126250028610229e+00
    phi[6,5]  R2492     -1.6807780265808105e+00
    phi[6,5]  R2493     1.1445027589797974e+00
    phi[6,5]  R2494     -1.1493481397628784e+00
    phi[6,5]  R2495     1.0303270816802979e+00
    phi[6,5]  R2496     -2.3878691196441650e+00
    phi[6,5]  R2497     0.889646589756012
    phi[6,5]  R2498     -2.1160848140716553e+00
    phi[6,5]  R2499     -4.5015635490417480e+00
    phi[6,5]  R2500     -5.3858470916748047e-01
    phi[6,5]  R2501     -4.0514345169067383e+00
    phi[6,5]  R2502     -1.2144057750701904e+00
    phi[6,5]  R2503     6.9984000921249390e-01
    phi[6,5]  R2504     1.2734032869338989e+00
    phi[6,5]  R2505     -2.3474791049957275e+00
    phi[6,5]  R2506     -3.7649455070495605e+00
    phi[6,5]  R2507     -3.6166725158691406e+00
    phi[6,5]  R2508     -1.3383241891860962e+00
    phi[6,5]  R2509     -1.3237434625625610e+00
    phi[6,5]  R2510     -1.0584704875946045e+00
    phi[6,5]  R2511     -1.9773107767105103e+00
    phi[6,5]  R2512     -2.6628782749176025e+00
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2513     -3.0999999046325684e+00
    phi[6,7]  R2514     -3.0999999046325684e+00
    phi[6,7]  R2515     -2.2400000095367432e+00
    phi[6,7]  R2516     -2.2400000095367432e+00
    phi[6,7]  R2517     -3.0999999046325684e+00
    phi[6,7]  R2518     -3.0999999046325684e+00
    phi[6,7]  R2519     -2.5699999332427979e+00
    phi[6,7]  R2520     -2.5699999332427979e+00
    phi[6,7]  R2521     -3.0999999046325684e+00
    phi[6,7]  R2522     -3.0999999046325684e+00
    phi[6,7]  R2523     -2.0899999141693115e+00
    phi[6,7]  R2524     -2.0899999141693115e+00
    phi[6,7]  R2525     -3.0999999046325684e+00
    phi[6,7]  R2526     -3.0999999046325684e+00
    phi[6,7]  R2527     1.3193278014659882e-01
    phi[6,7]  R2528     2.9593631625175476e-01
    phi[6,7]  R2529     1.2675023078918457e+00
    phi[6,7]  R2530     8.5200232267379761e-01
    phi[6,7]  R2531     1.6841987371444702e+00
    phi[6,7]  R2532     9.3283337354660034e-01
    phi[6,7]  R2533     5.4867851734161377e-01
    phi[6,7]  R2534     1.5676145255565643e-01
    phi[6,7]  R2535     -1.7623569965362549e+00
    phi[6,7]  R2536     2.1422662734985352e+00
    phi[6,7]  R2537     -1.6789739131927490e+00
    phi[6,7]  R2538     -1.1386463642120361e+00
    phi[6,7]  R2539     -9.7037839889526367e-01
    phi[6,7]  R2540     -4.0429848432540894e-01
    phi[6,7]  R2541     -6.6835576295852661e-01
    phi[6,7]  R2542     -4.5904809236526489e-01
    phi[6,7]  R2543     -5.6741154193878174e-01
    phi[6,7]  R2544     -1.0232281684875488e+00
    phi[6,7]  R2545     -4.6817946434020996e-01
    phi[6,7]  R2546     4.2745381593704224e-01
    phi[6,7]  R2547     0.586158037185669
    phi[6,7]  R2548     -1.1873445510864258e+00
    phi[6,7]  R2549     8.3569222688674927e-01
    phi[6,7]  R2550     -6.6599881649017334e-01
    phi[6,7]  R2551     -2.8104436397552490e-01
    phi[6,7]  R2552     -4.7718322277069092e-01
    phi[6,7]  R2553     -3.2573205232620239e-01
    phi[6,7]  R2554     -1.7913311719894409e-01
    phi[6,7]  R2555     -0.509100079536438
    phi[6,7]  R2556     -5.4582124948501587e-01
    phi[6,7]  R2557     -1.3468535244464874e-01
    phi[6,7]  R2558     -1.3789841532707214e-01
    phi[6,7]  R2559     5.4770298302173615e-02
    phi[6,7]  R2560     2.1304650306701660e+00
    phi[6,7]  R2561     -1.2972854375839233e+00
    phi[6,7]  R2562     3.2123723626136780e-01
    phi[6,7]  R2563     1.7603840827941895e+00
    phi[6,7]  R2564     2.6542577743530273e+00
    phi[6,7]  R2565     -9.0353327989578247e-01
    phi[6,7]  R2566     -1.3421695232391357e+00
    phi[6,7]  R2567     -3.1466927528381348e+00
    phi[6,7]  R2568     -1.0275068283081055e+00
    phi[6,7]  R2569     -1.7306109666824341e+00
    phi[6,7]  R2570     -0.603119969367981
    phi[6,7]  R2571     -1.0538656711578369e+00
    phi[6,7]  R2572     -2.2965674400329590e+00
    phi[6,7]  R2573     -2.0353040695190430e+00
    phi[6,7]  R2574     -9.5020908117294312e-01
    phi[6,7]  R2575     -2.1424562931060791e+00
    phi[6,7]  R2576     1.4938391745090485e-02
    phi[6,7]  R2577     3.9530289173126221e-01
    phi[6,7]  R2578     -1.6884776949882507e-01
    phi[6,7]  R2579     -4.2270806431770325e-01
    phi[6,7]  R2580     -2.3892448842525482e-01
    phi[6,7]  R2581     1.7799629271030426e-01
    phi[6,7]  R2582     9.9110698699951172e-01
    phi[6,7]  R2583     -1.6048654317855835e+00
    phi[6,7]  R2584     -1.4987109899520874e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2585     -3.0999999046325684e+00
    phi[7,6]  R2586     -3.0999999046325684e+00
    phi[7,6]  R2587     -2.2400000095367432e+00
    phi[7,6]  R2588     -2.2400000095367432e+00
    phi[7,6]  R2589     -3.0999999046325684e+00
    phi[7,6]  R2590     -3.0999999046325684e+00
    phi[7,6]  R2591     -2.5699999332427979e+00
    phi[7,6]  R2592     -2.5699999332427979e+00
    phi[7,6]  R2593     -3.0999999046325684e+00
    phi[7,6]  R2594     -3.0999999046325684e+00
    phi[7,6]  R2595     -2.0899999141693115e+00
    phi[7,6]  R2596     -2.0899999141693115e+00
    phi[7,6]  R2597     -3.0999999046325684e+00
    phi[7,6]  R2598     -3.0999999046325684e+00
    phi[7,6]  R2599     -0.509100079536438
    phi[7,6]  R2600     -5.4582124948501587e-01
    phi[7,6]  R2601     -1.3468535244464874e-01
    phi[7,6]  R2602     -1.3789841532707214e-01
    phi[7,6]  R2603     5.4770298302173615e-02
    phi[7,6]  R2604     2.1304650306701660e+00
    phi[7,6]  R2605     -1.2972854375839233e+00
    phi[7,6]  R2606     3.2123723626136780e-01
    phi[7,6]  R2607     1.7603840827941895e+00
    phi[7,6]  R2608     2.6542577743530273e+00
    phi[7,6]  R2609     -9.0353327989578247e-01
    phi[7,6]  R2610     -1.3421695232391357e+00
    phi[7,6]  R2611     -3.1466927528381348e+00
    phi[7,6]  R2612     -1.0275068283081055e+00
    phi[7,6]  R2613     -1.7306109666824341e+00
    phi[7,6]  R2614     -0.603119969367981
    phi[7,6]  R2615     -1.0538656711578369e+00
    phi[7,6]  R2616     -2.2965674400329590e+00
    phi[7,6]  R2617     -2.0353040695190430e+00
    phi[7,6]  R2618     -9.5020908117294312e-01
    phi[7,6]  R2619     -2.1424562931060791e+00
    phi[7,6]  R2620     1.4938391745090485e-02
    phi[7,6]  R2621     3.9530289173126221e-01
    phi[7,6]  R2622     -1.6884776949882507e-01
    phi[7,6]  R2623     -4.2270806431770325e-01
    phi[7,6]  R2624     -2.3892448842525482e-01
    phi[7,6]  R2625     1.7799629271030426e-01
    phi[7,6]  R2626     9.9110698699951172e-01
    phi[7,6]  R2627     -1.6048654317855835e+00
    phi[7,6]  R2628     -1.4987109899520874e+00
    phi[7,6]  R2629     1.3193278014659882e-01
    phi[7,6]  R2630     2.9593631625175476e-01
    phi[7,6]  R2631     1.2675023078918457e+00
    phi[7,6]  R2632     8.5200232267379761e-01
    phi[7,6]  R2633     1.6841987371444702e+00
    phi[7,6]  R2634     9.3283337354660034e-01
    phi[7,6]  R2635     5.4867851734161377e-01
    phi[7,6]  R2636     1.5676145255565643e-01
    phi[7,6]  R2637     -1.7623569965362549e+00
    phi[7,6]  R2638     2.1422662734985352e+00
    phi[7,6]  R2639     -1.6789739131927490e+00
    phi[7,6]  R2640     -1.1386463642120361e+00
    phi[7,6]  R2641     -9.7037839889526367e-01
    phi[7,6]  R2642     -4.0429848432540894e-01
    phi[7,6]  R2643     -6.6835576295852661e-01
    phi[7,6]  R2644     -4.5904809236526489e-01
    phi[7,6]  R2645     -5.6741154193878174e-01
    phi[7,6]  R2646     -1.0232281684875488e+00
    phi[7,6]  R2647     -4.6817946434020996e-01
    phi[7,6]  R2648     4.2745381593704224e-01
    phi[7,6]  R2649     0.586158037185669
    phi[7,6]  R2650     -1.1873445510864258e+00
    phi[7,6]  R2651     8.3569222688674927e-01
    phi[7,6]  R2652     -6.6599881649017334e-01
    phi[7,6]  R2653     -2.8104436397552490e-01
    phi[7,6]  R2654     -4.7718322277069092e-01
    phi[7,6]  R2655     -3.2573205232620239e-01
    phi[7,6]  R2656     -1.7913311719894409e-01
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       1.6467661140570644e+00
    phi[7,9]  R66       -1.0900934418643611e+00
    phi[7,9]  R67       -1.8966064735023589e+00
    phi[7,9]  R68       3.1072766440922361e-01
    phi[7,9]  R69       2.1560212699207635e+00
    phi[7,9]  R70       -7.8481442390854683e-01
    phi[7,9]  R71       2.1409913286535369e+00
    phi[7,9]  R73       -1
    phi[7,9]  R2657     -1.4532337905755039e+00
    phi[7,9]  R2658     -4.7467660186896330e+00
    phi[7,9]  R2659     -3.3300934514011042e+00
    phi[7,9]  R2660     -1.1499065676723821e+00
    phi[7,9]  R2661     -4.9966063781349277e+00
    phi[7,9]  R2662     -1.2033934311302095e+00
    phi[7,9]  R2663     -2.2592722688335742e+00
    phi[7,9]  R2664     -2.8807275976520215e+00
    phi[7,9]  R2665     -9.4397863471180488e-01
    phi[7,9]  R2666     -5.2560211745533323e+00
    phi[7,9]  R2667     -2.8748143380778584e+00
    phi[7,9]  R2668     -1.3051854902607647e+00
    phi[7,9]  R2669     -9.5900857597903144e-01
    phi[7,9]  R2670     -5.2409912332861053e+00
    phi[7,9]  R2671     -1.3318197879287461e+00
    phi[7,9]  R2672     -1.5680550830323647e+00
    phi[7,9]  R2673     -6.8464009136598680e-01
    phi[7,9]  R2674     -1.3436483043132132e+00
    phi[7,9]  R2675     -4.5463158076275167e-01
    phi[7,9]  R2676     -7.0434254358132753e-01
    phi[7,9]  R2677     -8.6216838985162525e-02
    phi[7,9]  R2678     -4.1705984072746738e-01
    phi[7,9]  R2679     -0.614112946532237
    phi[7,9]  R2680     -2.6680125173098546e-01
    phi[7,9]  R2681     -1.1872699727741964e-01
    phi[7,9]  R2682     -1.2253656163690430e-01
    phi[7,9]  R2683     -1.4915919849444759e-01
    phi[7,9]  R2684     -1.6152724469845081e-01
    phi[7,9]  R2685     -1.6661519456767437e-01
    phi[7,9]  R2686     -2.3249746949777017e-01
    phi[7,9]  R2687     -4.9550069124368745e-01
    phi[7,9]  R2688     -5.1351521661334987e-01
    phi[7,9]  R2689     -5.3179038201333961e-01
    phi[7,9]  R2690     -5.3478529600305869e-01
    phi[7,9]  R2691     -4.9312332998770825e-01
    phi[7,9]  R2692     -6.1990020841297255e-01
    phi[7,9]  R2693     -0.631063980572723
    phi[7,9]  R2694     -6.5958892004249736e-01
    phi[7,9]  R2695     -6.6906945996771749e-01
    phi[7,9]  R2696     -6.8996573308153963e-01
    phi[7,9]  R2697     -7.1626750800020478e-01
    phi[7,9]  R2698     -7.2943341963951580e-01
    phi[7,9]  R2699     -7.3504404249249422e-01
    phi[7,9]  R2700     -9.3874106723509221e-01
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       -6.4063489437103271e-02
    z[0,1,0]  R89       1.6059769690036774e-01
    z[0,1,0]  R90       1.3274246454238892e-01
    z[0,1,0]  R91       6.3208468258380890e-02
    z[0,1,0]  R92       1.0475829988718033e-01
    z[0,1,0]  R93       1.5666396915912628e-01
    z[0,1,0]  R94       2.4719725549221039e-01
    z[0,1,0]  R95       5.6741088628768921e-01
    z[0,1,0]  R96       5.1577204465866089e-01
    z[0,1,0]  R97       -6.9601279497146606e-01
    z[0,1,0]  R98       -1.3350605964660645e-01
    z[0,1,0]  R99       1.7930482327938080e-01
    z[0,1,0]  R100      -2.8537398576736450e-01
    z[0,1,0]  R101      1.6607774794101715e-01
    z[0,1,0]  R102      5.1720064133405685e-02
    z[0,1,0]  R103      -8.3205364644527435e-03
    z[0,1,0]  R104      4.0531735867261887e-02
    z[0,1,0]  R105      7.2678372263908386e-02
    z[0,1,0]  R106      0.260046124458313
    z[0,1,0]  R107      1.3106101751327515e-01
    z[0,1,0]  R108      -3.5949856042861938e-02
    z[0,1,0]  R109      2.7664564549922943e-02
    z[0,1,0]  R110      7.8953303396701813e-02
    z[0,1,0]  R111      1.5168353915214539e-01
    z[0,1,0]  R112      -3.3841833472251892e-01
    z[0,1,0]  R113      -2.2327479720115662e-01
    z[0,1,0]  R114      -2.6558920741081238e-01
    z[0,1,0]  R115      1.4662556350231171e-02
    z[0,1,0]  R116      -0.260986864566803
    z[0,1,0]  R117      -3.6370101571083069e-01
    z[0,1,0]  R118      3.5187106579542160e-02
    z[0,1,0]  R119      -1.2392750382423401e-01
    z[0,1,0]  R120      -4.5920538902282715e-01
    z[0,1,0]  R121      0.0667165070772171
    z[0,1,0]  R122      -2.9462891817092896e-01
    z[0,1,0]  R123      0.644294261932373
    z[0,1,0]  R124      -4.7134527564048767e-01
    z[0,1,0]  R125      2.8061863034963608e-02
    z[0,1,0]  R126      3.2971829175949097e-01
    z[0,1,0]  R127      6.9544982910156250e-01
    z[0,1,0]  R128      8.0374181270599365e-02
    z[0,1,0]  R129      4.4361403584480286e-01
    z[0,1,0]  R130      -2.3828917741775513e-01
    z[0,1,0]  R131      3.4130752086639404e-01
    z[0,1,0]  R132      -4.8296146094799042e-02
    z[0,1,0]  R133      -2.8567740321159363e-01
    z[0,1,0]  R134      -3.0408853292465210e-01
    z[0,1,0]  R135      7.3413014411926270e-01
    z[0,1,0]  R136      0.762452244758606
    z[0,1,0]  R137      -1.3330757617950439e-01
    z[0,1,0]  R138      0.0967952162027359
    z[0,1,0]  R139      5.4665857553482056e-01
    z[0,1,0]  R140      5.7045292854309082e-01
    z[0,1,0]  R141      4.8920072615146637e-02
    z[0,1,0]  R142      2.1173666417598724e-01
    z[0,1,0]  R143      4.0548691153526306e-01
    z[0,1,0]  R144      1.5091603994369507e-01
    z[0,1,0]  R145      6.5789061784744263e-01
    z[0,1,0]  R146      -4.8623021692037582e-02
    z[0,1,0]  R147      2.5142499804496765e-01
    z[0,1,0]  R148      1.9243241846561432e-01
    z[0,1,0]  R149      3.9235064387321472e-01
    z[0,1,0]  R150      2.9140564799308777e-01
    z[0,1,0]  R151      6.2068152427673340e-01
    z[0,1,0]  R152      -3.7842559814453125e-01
    z[0,1,0]  R153      1.0778354853391647e-01
    z[0,1,0]  R154      4.9369942396879196e-02
    z[0,1,0]  R155      -6.9795258343219757e-02
    z[0,1,0]  R156      -1.4652828872203827e-01
    z[0,1,0]  R157      0.0670105367898941
    z[0,1,0]  R158      0.550288736820221
    z[0,1,0]  R159      3.2825458794832230e-02
    z[0,1,0]  R160      -2.2199097275733948e-01
    z[0,1,0]  R161      -3.4488037228584290e-02
    z[0,1,0]  R162      1.8360415101051331e-01
    z[0,1,0]  R163      1.9765444099903107e-01
    z[0,1,0]  R164      -4.3908235430717468e-01
    z[0,1,0]  R165      -6.3887882232666016e-01
    z[0,1,0]  R166      -4.3565583229064941e-01
    z[0,1,0]  R167      -4.5687532424926758e-01
    z[0,1,0]  R168      0.084299735724926
    z[0,1,0]  R169      -4.7861550003290176e-02
    z[0,1,0]  R170      3.4174117445945740e-01
    z[0,1,0]  R171      -3.4983676671981812e-01
    z[0,1,0]  R172      -1.5232269465923309e-01
    z[0,1,0]  R173      -4.1082230210304260e-01
    z[0,1,0]  R174      -3.1880471110343933e-01
    z[0,1,0]  R175      -2.5601112842559814e-01
    z[0,1,0]  R176      -1.4790304005146027e-01
    z[0,1,0]  R177      1.4020407572388649e-02
    z[0,1,0]  R178      6.6226828098297119e-01
    z[0,1,0]  R179      5.0675106048583984e-01
    z[0,1,0]  R180      6.5007501840591431e-01
    z[0,1,0]  R181      1.0458222776651382e-01
    z[0,1,0]  R182      2.2211848199367523e-01
    z[0,1,0]  R183      3.1830188632011414e-01
    z[0,1,0]  R184      7.1310373023152351e-03
    z[0,1,0]  R185      1.2181148678064346e-01
    z[0,1,0]  R186      5.2474808692932129e-01
    z[0,1,0]  R187      2.7573135495185852e-01
    z[0,1,0]  R188      -3.1164163723587990e-02
    z[0,1,0]  R189      4.1819611191749573e-01
    z[0,1,0]  R190      -1.1259645689278841e-03
    z[0,1,0]  R191      1.9186483323574066e-01
    z[0,1,0]  R192      4.5464757084846497e-01
    z[0,1,0]  R193      2.1068836748600006e-01
    z[0,1,0]  R194      4.2194575071334839e-01
    z[0,1,0]  R195      0.0399978905916214
    z[0,1,0]  R196      -7.8884936869144440e-02
    z[0,1,0]  R197      -3.5735324025154114e-01
    z[0,1,0]  R198      4.9055644869804382e-01
    z[0,1,0]  R199      4.2514945380389690e-03
    z[0,1,0]  R200      -3.6638548970222473e-01
    z[0,1,0]  R201      7.1098022162914276e-02
    z[0,1,0]  R202      3.7249189615249634e-01
    z[0,1,0]  R203      1.7393809556961060e-01
    z[0,1,0]  R204      -3.4418198466300964e-01
    z[0,1,0]  R205      -6.9354742765426636e-02
    z[0,1,0]  R206      5.6962281465530396e-02
    z[0,1,0]  R207      -1.6051355749368668e-02
    z[0,1,0]  R208      1.4299128204584122e-02
    z[0,1,0]  R209      -2.2865882515907288e-01
    z[0,1,0]  R210      1.5479490393772721e-03
    z[0,1,0]  R211      2.1054595708847046e-01
    z[0,1,0]  R212      -1.3603353500366211e-01
    z[0,1,0]  R213      -5.2306145429611206e-01
    z[0,1,0]  R214      -2.8902623057365417e-01
    z[0,1,0]  R215      5.5070221424102783e-01
    z[0,1,0]  R216      -1.3425610959529877e-01
    z[0,1,0]  R217      -1.5736041963100433e-01
    z[0,1,0]  R218      4.6794205904006958e-01
    z[0,1,0]  R219      4.7420230694115162e-03
    z[0,1,0]  R220      5.1805965602397919e-02
    z[0,1,0]  R221      0.0555608794093132
    z[0,1,0]  R222      7.6698541641235352e-02
    z[0,1,0]  R223      -1.5540167689323425e-01
    z[0,1,0]  R224      -3.9058607071638107e-02
    z[0,1,0]  R225      1.5152822434902191e-01
    z[0,1,0]  R226      1.5403473377227783e-01
    z[0,1,0]  R227      2.5715324282646179e-01
    z[0,1,0]  R228      2.2457849979400635e-01
    z[0,1,0]  R229      1.5101094543933868e-01
    z[0,1,0]  R230      5.6134972721338272e-02
    z[0,1,0]  R231      -1.3665618002414703e-01
    z[0,1,0]  R232      2.1534779667854309e-01
    z[0,1,0]  R233      1.2021030124742538e-04
    z[0,1,0]  R234      9.9304080009460449e-02
    z[0,1,0]  R235      -6.8425840139389038e-01
    z[0,1,0]  R236      -6.2479972839355469e-01
    z[0,1,0]  R237      -5.2208727598190308e-01
    z[0,1,0]  R238      3.6214053630828857e-01
    z[0,1,0]  R239      -3.7188172340393066e-02
    z[0,1,0]  R240      -1.6319125890731812e-02
    z[0,1,0]  R241      1.0568692535161972e-01
    z[0,1,0]  R242      -4.8138600587844849e-01
    z[0,1,0]  R243      2.8912544250488281e-01
    z[0,1,0]  R244      3.7493386864662170e-01
    z[0,1,0]  R245      7.4260830879211426e-03
    z[0,1,0]  R246      5.1129949092864990e-01
    z[0,1,0]  R247      2.9517391324043274e-01
    z[0,1,0]  R248      -4.0680280327796936e-01
    z[0,1,0]  R249      -5.5722106248140335e-02
    z[0,1,0]  R250      2.4958252906799316e-01
    z[0,1,0]  R251      7.6721549034118652e-02
    z[0,1,0]  R252      3.0775913596153259e-01
    z[0,1,0]  R253      -5.7606834173202515e-01
    z[0,1,0]  R254      -5.7863569259643555e-01
    z[0,1,0]  R255      -0.365887314081192
    z[0,1,0]  R256      -3.7225973606109619e-01
    z[0,1,0]  R257      -3.6723691225051880e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       -5.2023779600858688e-02
    z[0,1,1]  R89       1.8688815832138062e-01
    z[0,1,1]  R90       -2.0055456459522247e-01
    z[0,1,1]  R91       4.0589934587478638e-01
    z[0,1,1]  R92       -3.5552942752838135e-01
    z[0,1,1]  R93       1.1135175079107285e-01
    z[0,1,1]  R94       1.5564145147800446e-01
    z[0,1,1]  R95       -1.4409725368022919e-01
    z[0,1,1]  R96       -3.5696956515312195e-01
    z[0,1,1]  R97       -6.0474425554275513e-01
    z[0,1,1]  R98       5.9611005708575249e-03
    z[0,1,1]  R99       -1.3778430223464966e-01
    z[0,1,1]  R100      1.5254957973957062e-01
    z[0,1,1]  R101      4.2437443137168884e-01
    z[0,1,1]  R102      -3.2389974594116211e-01
    z[0,1,1]  R103      -3.8495957851409912e-01
    z[0,1,1]  R104      -5.0874465703964233e-01
    z[0,1,1]  R105      -3.6350693553686142e-02
    z[0,1,1]  R106      0.101785808801651
    z[0,1,1]  R107      1.9338355958461761e-01
    z[0,1,1]  R108      4.4235434383153915e-02
    z[0,1,1]  R109      -5.3629451990127563e-01
    z[0,1,1]  R110      0.81854248046875
    z[0,1,1]  R111      6.3725358247756958e-01
    z[0,1,1]  R112      -1.5819889307022095e-01
    z[0,1,1]  R113      4.4261854887008667e-01
    z[0,1,1]  R114      -4.1794739663600922e-02
    z[0,1,1]  R115      8.7619268894195557e-01
    z[0,1,1]  R116      1.1899554729461670e-01
    z[0,1,1]  R117      3.3444416522979736e-01
    z[0,1,1]  R118      -2.4165698885917664e-01
    z[0,1,1]  R119      2.8275391459465027e-01
    z[0,1,1]  R120      3.5537354648113251e-02
    z[0,1,1]  R121      -7.6254919171333313e-02
    z[0,1,1]  R122      -4.0073856711387634e-02
    z[0,1,1]  R123      0.0935761034488678
    z[0,1,1]  R124      -2.2781632840633392e-01
    z[0,1,1]  R125      0.36614990234375
    z[0,1,1]  R126      2.5656276941299438e-01
    z[0,1,1]  R127      3.1483608484268188e-01
    z[0,1,1]  R128      5.7906292378902435e-02
    z[0,1,1]  R129      7.1568292379379272e-01
    z[0,1,1]  R130      -3.4410279989242554e-01
    z[0,1,1]  R131      2.2935485467314720e-03
    z[0,1,1]  R132      0.634415328502655
    z[0,1,1]  R133      7.4076700210571289e-01
    z[0,1,1]  R134      5.5692654848098755e-01
    z[0,1,1]  R135      6.0079181194305420e-01
    z[0,1,1]  R136      5.2259796857833862e-01
    z[0,1,1]  R137      -9.6683973073959351e-01
    z[0,1,1]  R138      3.7239167094230652e-01
    z[0,1,1]  R139      -5.7963605970144272e-02
    z[0,1,1]  R140      -4.1433505713939667e-02
    z[0,1,1]  R141      -6.8225346505641937e-02
    z[0,1,1]  R142      -1.5415996313095093e-01
    z[0,1,1]  R143      -3.3002066612243652e-01
    z[0,1,1]  R144      -0.294149249792099
    z[0,1,1]  R145      3.0904176831245422e-01
    z[0,1,1]  R146      1.3697081804275513e-01
    z[0,1,1]  R147      0.750571072101593
    z[0,1,1]  R148      -3.0818048119544983e-01
    z[0,1,1]  R149      2.4123266339302063e-01
    z[0,1,1]  R150      1.3480287790298462e-01
    z[0,1,1]  R151      1.3289435207843781e-01
    z[0,1,1]  R152      -2.2830264270305634e-01
    z[0,1,1]  R153      3.2131770253181458e-01
    z[0,1,1]  R154      -2.1391832828521729e-01
    z[0,1,1]  R155      2.7872404456138611e-01
    z[0,1,1]  R156      -2.0348201692104340e-01
    z[0,1,1]  R157      6.0059273242950439e-01
    z[0,1,1]  R158      1.6556029021739960e-01
    z[0,1,1]  R159      -1.4329962432384491e-01
    z[0,1,1]  R160      2.1220651268959045e-01
    z[0,1,1]  R161      -1.6914875805377960e-01
    z[0,1,1]  R162      -1.4743930101394653e-01
    z[0,1,1]  R163      -1.7499189078807831e-01
    z[0,1,1]  R164      -3.5884156823158264e-01
    z[0,1,1]  R165      5.8143043518066406e-01
    z[0,1,1]  R166      -8.5988634824752808e-01
    z[0,1,1]  R167      -8.2960969209671021e-01
    z[0,1,1]  R168      2.7405783534049988e-01
    z[0,1,1]  R169      1.1639898270368576e-01
    z[0,1,1]  R170      -9.9900364875793457e-02
    z[0,1,1]  R171      -1.8450449407100677e-01
    z[0,1,1]  R172      -9.3087553977966309e-01
    z[0,1,1]  R173      -8.3404815196990967e-01
    z[0,1,1]  R174      -0.841460645198822
    z[0,1,1]  R175      -8.5124516487121582e-01
    z[0,1,1]  R176      -3.2479953765869141e-01
    z[0,1,1]  R177      -9.0595930814743042e-01
    z[0,1,1]  R178      -6.7258083820343018e-01
    z[0,1,1]  R179      -6.8709844350814819e-01
    z[0,1,1]  R180      -5.6269049644470215e-01
    z[0,1,1]  R181      -7.4100935459136963e-01
    z[0,1,1]  R182      -3.2611182332038879e-01
    z[0,1,1]  R183      -3.8324546813964844e-01
    z[0,1,1]  R184      -4.3025317788124084e-01
    z[0,1,1]  R185      2.0489771664142609e-01
    z[0,1,1]  R186      1.4688260853290558e-01
    z[0,1,1]  R187      1.5543220937252045e-01
    z[0,1,1]  R188      6.3851112127304077e-01
    z[0,1,1]  R189      5.9961098432540894e-01
    z[0,1,1]  R190      5.2976197004318237e-01
    z[0,1,1]  R191      5.1576942205429077e-01
    z[0,1,1]  R192      5.9200048446655273e-01
    z[0,1,1]  R193      6.2387037277221680e-01
    z[0,1,1]  R194      4.2148393392562866e-01
    z[0,1,1]  R195      5.3740245103836060e-01
    z[0,1,1]  R196      5.1812380552291870e-01
    z[0,1,1]  R197      7.2589772939682007e-01
    z[0,1,1]  R198      -4.7521993517875671e-01
    z[0,1,1]  R199      8.1426149606704712e-01
    z[0,1,1]  R200      8.0973690748214722e-01
    z[0,1,1]  R201      7.7333015203475952e-01
    z[0,1,1]  R202      7.5256580114364624e-01
    z[0,1,1]  R203      7.4798589944839478e-01
    z[0,1,1]  R204      7.3069638013839722e-01
    z[0,1,1]  R205      7.2040134668350220e-01
    z[0,1,1]  R206      7.1463263034820557e-01
    z[0,1,1]  R207      6.6782295703887939e-01
    z[0,1,1]  R208      -4.9307525157928467e-01
    z[0,1,1]  R209      -4.1209849715232849e-01
    z[0,1,1]  R210      -4.0078794956207275e-01
    z[0,1,1]  R211      7.5803959369659424e-01
    z[0,1,1]  R212      7.2552794218063354e-01
    z[0,1,1]  R213      0.687884509563446
    z[0,1,1]  R214      6.7090785503387451e-01
    z[0,1,1]  R215      6.7062664031982422e-01
    z[0,1,1]  R216      4.3769472837448120e-01
    z[0,1,1]  R217      5.0664401054382324e-01
    z[0,1,1]  R218      -4.2647719383239746e-01
    z[0,1,1]  R219      9.2548382282257080e-01
    z[0,1,1]  R220      9.3614894151687622e-01
    z[0,1,1]  R221      -5.5481582880020142e-01
    z[0,1,1]  R222      3.9922478795051575e-01
    z[0,1,1]  R223      5.6196242570877075e-01
    z[0,1,1]  R224      3.0727306008338928e-01
    z[0,1,1]  R225      5.6547051668167114e-01
    z[0,1,1]  R226      3.8533520698547363e-01
    z[0,1,1]  R227      5.2388507127761841e-01
    z[0,1,1]  R228      -0.412022203207016
    z[0,1,1]  R229      7.7927333116531372e-01
    z[0,1,1]  R230      5.2602005004882812e-01
    z[0,1,1]  R231      3.4048739075660706e-01
    z[0,1,1]  R232      0.622753381729126
    z[0,1,1]  R233      6.6513508558273315e-01
    z[0,1,1]  R234      5.4914355278015137e-01
    z[0,1,1]  R235      2.9145723674446344e-03
    z[0,1,1]  R236      2.1156106889247894e-01
    z[0,1,1]  R237      2.6425412297248840e-01
    z[0,1,1]  R238      -7.1557760238647461e-01
    z[0,1,1]  R239      -0.357464075088501
    z[0,1,1]  R240      4.5127025246620178e-01
    z[0,1,1]  R241      5.9350270032882690e-01
    z[0,1,1]  R242      6.6273349523544312e-01
    z[0,1,1]  R243      7.0407730340957642e-01
    z[0,1,1]  R244      6.6769748926162720e-01
    z[0,1,1]  R245      6.0759299993515015e-01
    z[0,1,1]  R246      3.6614662408828735e-01
    z[0,1,1]  R247      1.9975721836090088e-01
    z[0,1,1]  R248      7.7622473239898682e-01
    z[0,1,1]  R249      6.4539241790771484e-01
    z[0,1,1]  R250      6.8543708324432373e-01
    z[0,1,1]  R251      0.50160151720047
    z[0,1,1]  R252      2.3102851212024689e-01
    z[0,1,1]  R253      2.4664409458637238e-01
    z[0,1,1]  R254      1.3632266223430634e-01
    z[0,1,1]  R255      -6.9078433513641357e-01
    z[0,1,1]  R256      -6.7879754304885864e-01
    z[0,1,1]  R257      -6.8327230215072632e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       -5.6777913123369217e-02
    z[0,1,2]  R89       1.0353393852710724e-01
    z[0,1,2]  R90       -3.2702925801277161e-01
    z[0,1,2]  R91       -1.2539622187614441e-01
    z[0,1,2]  R92       -2.3582690954208374e-01
    z[0,1,2]  R93       -3.1900930404663086e-01
    z[0,1,2]  R94       -2.7136135101318359e-01
    z[0,1,2]  R95       4.4235885143280029e-02
    z[0,1,2]  R96       3.3006185293197632e-01
    z[0,1,2]  R97       2.7378043532371521e-01
    z[0,1,2]  R98       2.8532043099403381e-01
    z[0,1,2]  R99       -1.7149317264556885e-01
    z[0,1,2]  R100      8.2180345058441162e-01
    z[0,1,2]  R101      -6.7168600857257843e-02
    z[0,1,2]  R102      -1.7426814138889313e-01
    z[0,1,2]  R103      1.7528069019317627e-01
    z[0,1,2]  R104      -1.4055498875677586e-02
    z[0,1,2]  R105      3.2149147987365723e-01
    z[0,1,2]  R106      8.6558210849761963e-01
    z[0,1,2]  R107      9.3931305408477783e-01
    z[0,1,2]  R108      7.3067253828048706e-01
    z[0,1,2]  R109      -2.2591440379619598e-01
    z[0,1,2]  R110      -1.5671806037425995e-01
    z[0,1,2]  R111      5.5256050825119019e-01
    z[0,1,2]  R112      0.467549592256546
    z[0,1,2]  R113      -3.3615368604660034e-01
    z[0,1,2]  R114      3.6083319783210754e-01
    z[0,1,2]  R115      6.0788080096244812e-02
    z[0,1,2]  R116      -1.4985999464988708e-01
    z[0,1,2]  R117      2.6378521323204041e-01
    z[0,1,2]  R118      -3.1577392946928740e-03
    z[0,1,2]  R119      -2.0002222061157227e-01
    z[0,1,2]  R120      2.6407885551452637e-01
    z[0,1,2]  R121      -2.5432729721069336e-01
    z[0,1,2]  R122      -3.1636923551559448e-01
    z[0,1,2]  R123      -2.6361331343650818e-01
    z[0,1,2]  R124      -1.0337930172681808e-01
    z[0,1,2]  R125      4.4319942593574524e-01
    z[0,1,2]  R126      3.6318498849868774e-01
    z[0,1,2]  R127      2.8820511698722839e-01
    z[0,1,2]  R128      -3.6796236038208008e-01
    z[0,1,2]  R129      2.7848687767982483e-01
    z[0,1,2]  R130      -3.0173275619745255e-02
    z[0,1,2]  R131      7.3003798723220825e-01
    z[0,1,2]  R132      -1.7617985606193542e-01
    z[0,1,2]  R133      -8.4466069936752319e-02
    z[0,1,2]  R134      1.8327631056308746e-01
    z[0,1,2]  R135      -6.3278481364250183e-02
    z[0,1,2]  R136      -1.6766825318336487e-01
    z[0,1,2]  R137      1.3303583860397339e-01
    z[0,1,2]  R138      2.4208576977252960e-01
    z[0,1,2]  R139      -0.179097518324852
    z[0,1,2]  R140      1.1233936063945293e-02
    z[0,1,2]  R141      4.3308448791503906e-01
    z[0,1,2]  R142      2.5103539228439331e-01
    z[0,1,2]  R143      4.5756268501281738e-01
    z[0,1,2]  R144      4.3825164437294006e-01
    z[0,1,2]  R145      0.348513126373291
    z[0,1,2]  R146      3.1630018353462219e-01
    z[0,1,2]  R147      -4.0792483091354370e-01
    z[0,1,2]  R148      -1.5815148130059242e-02
    z[0,1,2]  R149      1.3097250461578369e-01
    z[0,1,2]  R150      5.2823996543884277e-01
    z[0,1,2]  R151      -2.1121042966842651e-01
    z[0,1,2]  R152      -8.3415031433105469e-02
    z[0,1,2]  R153      -1.9119301438331604e-01
    z[0,1,2]  R154      5.0723668187856674e-02
    z[0,1,2]  R155      1.6085717082023621e-01
    z[0,1,2]  R156      8.1871229410171509e-01
    z[0,1,2]  R157      4.4781997799873352e-01
    z[0,1,2]  R158      -2.5352808833122253e-01
    z[0,1,2]  R159      1.1890961229801178e-01
    z[0,1,2]  R160      5.4404580593109131e-01
    z[0,1,2]  R161      2.9344305396080017e-01
    z[0,1,2]  R162      0.0649917870759964
    z[0,1,2]  R163      3.0003413558006287e-01
    z[0,1,2]  R164      5.0687056779861450e-01
    z[0,1,2]  R165      1.9926688075065613e-01
    z[0,1,2]  R166      2.7861837297677994e-02
    z[0,1,2]  R167      6.4635850489139557e-02
    z[0,1,2]  R168      -2.6343947649002075e-01
    z[0,1,2]  R169      7.1777254343032837e-02
    z[0,1,2]  R170      6.4623379707336426e-01
    z[0,1,2]  R171      4.6222358942031860e-01
    z[0,1,2]  R172      -0.252784788608551
    z[0,1,2]  R173      -1.6858577728271484e-01
    z[0,1,2]  R174      -2.5062909722328186e-01
    z[0,1,2]  R175      -0.354160875082016
    z[0,1,2]  R176      -1.4349471032619476e-01
    z[0,1,2]  R177      1.0102648288011551e-01
    z[0,1,2]  R178      2.3809601366519928e-01
    z[0,1,2]  R179      1.9728195667266846e-01
    z[0,1,2]  R180      1.2139609456062317e-01
    z[0,1,2]  R181      0.398151695728302
    z[0,1,2]  R182      7.1022289991378784e-01
    z[0,1,2]  R183      6.8480712175369263e-01
    z[0,1,2]  R184      4.3799924850463867e-01
    z[0,1,2]  R185      -8.5877221822738647e-01
    z[0,1,2]  R186      -0.642659068107605
    z[0,1,2]  R187      -7.8482675552368164e-01
    z[0,1,2]  R188      4.8950761556625366e-01
    z[0,1,2]  R189      1.9180183112621307e-01
    z[0,1,2]  R190      -7.4636816978454590e-01
    z[0,1,2]  R191      -7.1551853418350220e-01
    z[0,1,2]  R192      -1.7958484590053558e-01
    z[0,1,2]  R193      -3.6169543862342834e-01
    z[0,1,2]  R194      -5.7209855318069458e-01
    z[0,1,2]  R195      9.4921469688415527e-02
    z[0,1,2]  R196      4.8071792721748352e-01
    z[0,1,2]  R197      -0.515275239944458
    z[0,1,2]  R198      -2.7619307860732079e-02
    z[0,1,2]  R199      3.4795442223548889e-01
    z[0,1,2]  R200      -1.5366819500923157e-01
    z[0,1,2]  R201      -1.1325717717409134e-01
    z[0,1,2]  R202      2.0715330541133881e-01
    z[0,1,2]  R203      1.8174743652343750e-01
    z[0,1,2]  R204      9.6815852448344231e-03
    z[0,1,2]  R205      1.4354528486728668e-01
    z[0,1,2]  R206      -4.8036918044090271e-02
    z[0,1,2]  R207      0.524165689945221
    z[0,1,2]  R208      6.7092680931091309e-01
    z[0,1,2]  R209      5.9876251220703125e-01
    z[0,1,2]  R210      4.6418240666389465e-01
    z[0,1,2]  R211      -8.6913526058197021e-02
    z[0,1,2]  R212      6.2506929039955139e-02
    z[0,1,2]  R213      1.9782467186450958e-01
    z[0,1,2]  R214      -5.9149265289306641e-01
    z[0,1,2]  R215      -2.3733480274677277e-01
    z[0,1,2]  R216      -0.854716956615448
    z[0,1,2]  R217      -6.3081711530685425e-01
    z[0,1,2]  R218      5.0678193569183350e-01
    z[0,1,2]  R219      2.5052627921104431e-01
    z[0,1,2]  R220      -7.1417480707168579e-02
    z[0,1,2]  R221      4.8525348305702209e-01
    z[0,1,2]  R222      -8.4976166486740112e-01
    z[0,1,2]  R223      -4.9339225888252258e-01
    z[0,1,2]  R224      -6.9705766439437866e-01
    z[0,1,2]  R225      -6.1198842525482178e-01
    z[0,1,2]  R226      -7.8054195642471313e-01
    z[0,1,2]  R227      -5.7120490074157715e-01
    z[0,1,2]  R228      6.3946527242660522e-01
    z[0,1,2]  R229      -2.7680985629558563e-02
    z[0,1,2]  R230      -7.0935946702957153e-01
    z[0,1,2]  R231      -8.1507086753845215e-01
    z[0,1,2]  R232      -5.3898376226425171e-01
    z[0,1,2]  R233      -7.9467020928859711e-02
    z[0,1,2]  R234      -0.486939400434494
    z[0,1,2]  R235      6.3790476322174072e-01
    z[0,1,2]  R236      2.1087015047669411e-02
    z[0,1,2]  R237      1.9639053940773010e-01
    z[0,1,2]  R238      4.5591777563095093e-01
    z[0,1,2]  R239      8.5431921482086182e-01
    z[0,1,2]  R240      -0.84015291929245
    z[0,1,2]  R241      -6.8678051233291626e-01
    z[0,1,2]  R242      2.4733814597129822e-01
    z[0,1,2]  R243      -4.7133666276931763e-01
    z[0,1,2]  R244      -1.5307798981666565e-01
    z[0,1,2]  R245      -6.3151675462722778e-01
    z[0,1,2]  R246      -5.1250952482223511e-01
    z[0,1,2]  R247      -5.3278762102127075e-01
    z[0,1,2]  R248      -3.0677095055580139e-01
    z[0,1,2]  R249      -5.1467049121856689e-01
    z[0,1,2]  R250      -2.1590860188007355e-01
    z[0,1,2]  R251      -5.6937223672866821e-01
    z[0,1,2]  R252      -0.542125940322876
    z[0,1,2]  R253      -1.8518763780593872e-01
    z[0,1,2]  R254      -1.1581188440322876e-01
    z[0,1,2]  R255      -0.445984810590744
    z[0,1,2]  R256      -5.3687328100204468e-01
    z[0,1,2]  R257      -3.8116714358329773e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       -9.2928916215896606e-01
    z[0,1,3]  R89       -0.804606556892395
    z[0,1,3]  R90       -8.5726940631866455e-01
    z[0,1,3]  R91       -8.5723048448562622e-01
    z[0,1,3]  R92       -8.0125230550765991e-01
    z[0,1,3]  R93       -7.1358543634414673e-01
    z[0,1,3]  R94       -7.9580336809158325e-01
    z[0,1,3]  R95       -1.5711851418018341e-01
    z[0,1,3]  R96       -2.7160879969596863e-01
    z[0,1,3]  R97       -1.3891610503196716e-01
    z[0,1,3]  R98       3.8556548953056335e-01
    z[0,1,3]  R99       4.3534025549888611e-01
    z[0,1,3]  R100      1.7657354474067688e-01
    z[0,1,3]  R101      3.9180862903594971e-01
    z[0,1,3]  R102      2.4762172996997833e-01
    z[0,1,3]  R103      2.9850077629089355e-01
    z[0,1,3]  R104      5.1189678907394409e-01
    z[0,1,3]  R105      3.6862105131149292e-01
    z[0,1,3]  R106      2.1526399254798889e-01
    z[0,1,3]  R107      1.1522676795721054e-01
    z[0,1,3]  R108      4.4608378410339355e-01
    z[0,1,3]  R109      5.6817245483398438e-01
    z[0,1,3]  R110      2.0419143140316010e-01
    z[0,1,3]  R111      -2.1266290545463562e-01
    z[0,1,3]  R112      6.1207717657089233e-01
    z[0,1,3]  R113      2.3714180290699005e-01
    z[0,1,3]  R114      1.5064767003059387e-01
    z[0,1,3]  R115      3.3175039291381836e-01
    z[0,1,3]  R116      7.5979363918304443e-01
    z[0,1,3]  R117      6.5049648284912109e-01
    z[0,1,3]  R118      5.3698408603668213e-01
    z[0,1,3]  R119      4.9911034107208252e-01
    z[0,1,3]  R120      5.5468392372131348e-01
    z[0,1,3]  R121      5.2799969911575317e-01
    z[0,1,3]  R122      4.9183416366577148e-01
    z[0,1,3]  R123      -1.7968240380287170e-01
    z[0,1,3]  R124      5.0459164381027222e-01
    z[0,1,3]  R125      3.0800908803939819e-01
    z[0,1,3]  R126      6.0138350725173950e-01
    z[0,1,3]  R127      -2.4376663565635681e-01
    z[0,1,3]  R128      6.8626904487609863e-01
    z[0,1,3]  R129      -3.3575016260147095e-01
    z[0,1,3]  R130      6.3144260644912720e-01
    z[0,1,3]  R131      4.2121031880378723e-01
    z[0,1,3]  R132      5.6819815188646317e-02
    z[0,1,3]  R133      0.336073100566864
    z[0,1,3]  R134      1.5416452288627625e-01
    z[0,1,3]  R135      2.4057245254516602e-01
    z[0,1,3]  R136      1.6548976302146912e-01
    z[0,1,3]  R137      -9.2471368610858917e-02
    z[0,1,3]  R138      5.3288924694061279e-01
    z[0,1,3]  R139      -0.455875039100647
    z[0,1,3]  R140      -3.8344934582710266e-01
    z[0,1,3]  R141      0.614128053188324
    z[0,1,3]  R142      0.767065703868866
    z[0,1,3]  R143      3.5107195377349854e-01
    z[0,1,3]  R144      6.2618285417556763e-01
    z[0,1,3]  R145      -3.4679338335990906e-01
    z[0,1,3]  R146      5.5651229619979858e-01
    z[0,1,3]  R147      1.9736245274543762e-01
    z[0,1,3]  R148      -8.5408180952072144e-01
    z[0,1,3]  R149      -5.5037140846252441e-01
    z[0,1,3]  R150      -7.3549979925155640e-01
    z[0,1,3]  R151      -4.9482280015945435e-01
    z[0,1,3]  R152      6.7564916610717773e-01
    z[0,1,3]  R153      6.6907513141632080e-01
    z[0,1,3]  R154      8.2581186294555664e-01
    z[0,1,3]  R155      0.79014652967453
    z[0,1,3]  R156      1.7215198278427124e-01
    z[0,1,3]  R157      5.8378702402114868e-01
    z[0,1,3]  R158      -0.62684565782547
    z[0,1,3]  R159      0.827559769153595
    z[0,1,3]  R160      6.0564368963241577e-01
    z[0,1,3]  R161      6.2602764368057251e-01
    z[0,1,3]  R162      2.5464054942131042e-01
    z[0,1,3]  R163      4.9707618355751038e-01
    z[0,1,3]  R164      2.4635070562362671e-01
    z[0,1,3]  R165      7.9420171678066254e-03
    z[0,1,3]  R166      7.3591373860836029e-02
    z[0,1,3]  R167      -1.1864126473665237e-01
    z[0,1,3]  R168      7.1144467592239380e-01
    z[0,1,3]  R169      -6.2321805953979492e-01
    z[0,1,3]  R170      0.448964923620224
    z[0,1,3]  R171      1.6619957983493805e-01
    z[0,1,3]  R172      1.0466784238815308e-01
    z[0,1,3]  R173      1.7910125851631165e-01
    z[0,1,3]  R174      3.1129390001296997e-01
    z[0,1,3]  R175      2.0030494779348373e-02
    z[0,1,3]  R176      9.6967602148652077e-03
    z[0,1,3]  R177      2.0940619707107544e-01
    z[0,1,3]  R178      8.0558732151985168e-02
    z[0,1,3]  R179      1.0039541125297546e-01
    z[0,1,3]  R180      1.9324548542499542e-01
    z[0,1,3]  R181      3.8288459181785583e-01
    z[0,1,3]  R182      -4.8785403370857239e-02
    z[0,1,3]  R183      1.1430404335260391e-01
    z[0,1,3]  R184      1.4981566369533539e-01
    z[0,1,3]  R185      2.7314114570617676e-01
    z[0,1,3]  R186      6.9600507616996765e-02
    z[0,1,3]  R187      1.8743287026882172e-01
    z[0,1,3]  R188      0.0943765640258789
    z[0,1,3]  R189      2.7693882584571838e-01
    z[0,1,3]  R190      -2.2504374384880066e-01
    z[0,1,3]  R191      2.6922838762402534e-02
    z[0,1,3]  R192      1.7071780562400818e-01
    z[0,1,3]  R193      -0.51454758644104
    z[0,1,3]  R194      -1.6613106429576874e-01
    z[0,1,3]  R195      4.2972767353057861e-01
    z[0,1,3]  R196      -9.3862272799015045e-02
    z[0,1,3]  R197      -1.9204561412334442e-01
    z[0,1,3]  R198      4.3587011098861694e-01
    z[0,1,3]  R199      -4.2580872774124146e-01
    z[0,1,3]  R200      6.1133846640586853e-02
    z[0,1,3]  R201      3.4089264273643494e-01
    z[0,1,3]  R202      -4.1056537628173828e-01
    z[0,1,3]  R203      -3.5162556171417236e-01
    z[0,1,3]  R204      -2.5002938508987427e-01
    z[0,1,3]  R205      -1.5374928712844849e-01
    z[0,1,3]  R206      2.7975007891654968e-01
    z[0,1,3]  R207      2.9702642560005188e-01
    z[0,1,3]  R208      -3.8059610128402710e-01
    z[0,1,3]  R209      2.1868069469928741e-01
    z[0,1,3]  R210      5.3026580810546875e-01
    z[0,1,3]  R211      0.469642698764801
    z[0,1,3]  R212      3.5498702526092529e-01
    z[0,1,3]  R213      1.2456343322992325e-01
    z[0,1,3]  R214      -1.5270821750164032e-01
    z[0,1,3]  R215      -5.5474929511547089e-02
    z[0,1,3]  R216      2.1719707548618317e-01
    z[0,1,3]  R217      4.4158515334129333e-01
    z[0,1,3]  R218      -3.9123344421386719e-01
    z[0,1,3]  R219      1.8698923289775848e-01
    z[0,1,3]  R220      1.7250998318195343e-01
    z[0,1,3]  R221      -5.2650339901447296e-02
    z[0,1,3]  R222      -5.9175956994295120e-02
    z[0,1,3]  R223      -2.0117217674851418e-02
    z[0,1,3]  R224      -1.4995169825851917e-02
    z[0,1,3]  R225      -2.1370522677898407e-01
    z[0,1,3]  R226      2.4888768792152405e-01
    z[0,1,3]  R227      -1.7991498112678528e-01
    z[0,1,3]  R228      -3.0606150627136230e-01
    z[0,1,3]  R229      1.7265869677066803e-01
    z[0,1,3]  R230      -2.0424877107143402e-01
    z[0,1,3]  R231      2.1565240621566772e-01
    z[0,1,3]  R232      -0.337464839220047
    z[0,1,3]  R233      -2.5335872173309326e-01
    z[0,1,3]  R234      -6.1320036649703979e-01
    z[0,1,3]  R235      6.1767648905515671e-02
    z[0,1,3]  R236      -3.2199603319168091e-01
    z[0,1,3]  R237      -3.8293069601058960e-01
    z[0,1,3]  R238      1.2954463064670563e-01
    z[0,1,3]  R239      -1.9647832214832306e-01
    z[0,1,3]  R240      8.8400296866893768e-02
    z[0,1,3]  R241      -2.8740128874778748e-01
    z[0,1,3]  R242      -3.0023294687271118e-01
    z[0,1,3]  R243      -2.0498682558536530e-01
    z[0,1,3]  R244      -2.0276100933551788e-01
    z[0,1,3]  R245      -2.4268874526023865e-01
    z[0,1,3]  R246      4.5972842723131180e-02
    z[0,1,3]  R247      2.2287148237228394e-01
    z[0,1,3]  R248      0.0639379695057869
    z[0,1,3]  R249      -0.0262119323015213
    z[0,1,3]  R250      -0.391450971364975
    z[0,1,3]  R251      -5.5759406089782715e-01
    z[0,1,3]  R252      2.0403346419334412e-01
    z[0,1,3]  R253      -5.0263935327529907e-01
    z[0,1,3]  R254      -1.4866378903388977e-01
    z[0,1,3]  R255      -2.9711639881134033e-01
    z[0,1,3]  R256      -2.8054785728454590e-01
    z[0,1,3]  R257      -4.5000320672988892e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       2.9850891232490540e-01
    z[0,1,4]  R89       1.0379948467016220e-01
    z[0,1,4]  R90       6.7134196870028973e-03
    z[0,1,4]  R91       -2.4092530831694603e-02
    z[0,1,4]  R92       3.4442999958992004e-01
    z[0,1,4]  R93       -5.1885211467742920e-01
    z[0,1,4]  R94       3.5841333866119385e-01
    z[0,1,4]  R95       -4.1127124428749084e-01
    z[0,1,4]  R96       8.8618598878383636e-02
    z[0,1,4]  R97       2.2265779972076416e-01
    z[0,1,4]  R98       -4.9502938985824585e-01
    z[0,1,4]  R99       -8.5293418169021606e-01
    z[0,1,4]  R100      3.3291608095169067e-01
    z[0,1,4]  R101      -7.1162384748458862e-01
    z[0,1,4]  R102      -7.4344772100448608e-01
    z[0,1,4]  R103      -7.7911502122879028e-01
    z[0,1,4]  R104      -0.671019434928894
    z[0,1,4]  R105      -8.1939530372619629e-01
    z[0,1,4]  R106      2.0195983350276947e-01
    z[0,1,4]  R107      2.0293138921260834e-01
    z[0,1,4]  R108      4.4607225060462952e-01
    z[0,1,4]  R109      -4.4644799828529358e-01
    z[0,1,4]  R110      8.7363161146640778e-03
    z[0,1,4]  R111      3.6340811848640442e-01
    z[0,1,4]  R112      -2.9440057277679443e-01
    z[0,1,4]  R113      -3.7326484918594360e-01
    z[0,1,4]  R114      2.4924322962760925e-01
    z[0,1,4]  R115      3.0503988265991211e-01
    z[0,1,4]  R116      -7.0223741233348846e-02
    z[0,1,4]  R117      -1.9835433363914490e-01
    z[0,1,4]  R118      -7.0246893167495728e-01
    z[0,1,4]  R119      -0.702630341053009
    z[0,1,4]  R120      0.272499144077301
    z[0,1,4]  R121      -6.6848033666610718e-01
    z[0,1,4]  R122      -5.1927280426025391e-01
    z[0,1,4]  R123      -0.247806116938591
    z[0,1,4]  R124      -3.1744873523712158e-01
    z[0,1,4]  R125      -6.3552063703536987e-01
    z[0,1,4]  R126      -4.9319875240325928e-01
    z[0,1,4]  R127      -4.1530814766883850e-01
    z[0,1,4]  R128      -5.6754702329635620e-01
    z[0,1,4]  R129      2.3077231645584106e-01
    z[0,1,4]  R130      -4.7983753681182861e-01
    z[0,1,4]  R131      3.4534502029418945e-01
    z[0,1,4]  R132      4.1923069953918457e-01
    z[0,1,4]  R133      4.8716527223587036e-01
    z[0,1,4]  R134      4.9648800492286682e-01
    z[0,1,4]  R135      -1.5960346907377243e-02
    z[0,1,4]  R136      -6.6549576818943024e-02
    z[0,1,4]  R137      -1.2255188077688217e-01
    z[0,1,4]  R138      -6.6290569305419922e-01
    z[0,1,4]  R139      -3.7945404648780823e-01
    z[0,1,4]  R140      2.0986701548099518e-01
    z[0,1,4]  R141      2.1012732386589050e-01
    z[0,1,4]  R142      -0.489188551902771
    z[0,1,4]  R143      -3.6255702376365662e-02
    z[0,1,4]  R144      -5.0594764947891235e-01
    z[0,1,4]  R145      -3.7479439377784729e-01
    z[0,1,4]  R146      -4.5726552605628967e-01
    z[0,1,4]  R147      2.2959679365158081e-01
    z[0,1,4]  R148      -3.2122680544853210e-01
    z[0,1,4]  R149      -1.9119140505790710e-01
    z[0,1,4]  R150      -1.7439144849777222e-01
    z[0,1,4]  R151      -4.4242069125175476e-01
    z[0,1,4]  R152      -4.1691732406616211e-01
    z[0,1,4]  R153      -5.6202590465545654e-01
    z[0,1,4]  R154      -0.505794107913971
    z[0,1,4]  R155      -3.8944569230079651e-01
    z[0,1,4]  R156      2.2215992212295532e-01
    z[0,1,4]  R157      2.6274007558822632e-01
    z[0,1,4]  R158      -4.0438213944435120e-01
    z[0,1,4]  R159      -5.2583914995193481e-01
    z[0,1,4]  R160      2.2356854379177094e-01
    z[0,1,4]  R161      -4.9322238564491272e-01
    z[0,1,4]  R162      -8.0460679531097412e-01
    z[0,1,4]  R163      1.6704671084880829e-01
    z[0,1,4]  R164      -2.9823830351233482e-02
    z[0,1,4]  R165      4.2493402957916260e-01
    z[0,1,4]  R166      2.2571101784706116e-01
    z[0,1,4]  R167      1.7069098353385925e-01
    z[0,1,4]  R168      -5.4182070493698120e-01
    z[0,1,4]  R169      2.2802498936653137e-01
    z[0,1,4]  R170      1.1553851515054703e-01
    z[0,1,4]  R171      3.4038805961608887e-01
    z[0,1,4]  R172      -4.0117930620908737e-02
    z[0,1,4]  R173      -2.6049926877021790e-02
    z[0,1,4]  R174      1.1090749502182007e-01
    z[0,1,4]  R175      -3.5114653408527374e-02
    z[0,1,4]  R176      6.0660088062286377e-01
    z[0,1,4]  R177      6.9004237651824951e-02
    z[0,1,4]  R178      -1.1163435131311417e-01
    z[0,1,4]  R179      3.4751546382904053e-01
    z[0,1,4]  R180      0.395954966545105
    z[0,1,4]  R181      -7.0475861430168152e-02
    z[0,1,4]  R182      3.7594917416572571e-01
    z[0,1,4]  R183      -3.3839130401611328e-01
    z[0,1,4]  R184      7.7024394273757935e-01
    z[0,1,4]  R185      -3.0939653515815735e-01
    z[0,1,4]  R186      -5.1315951347351074e-01
    z[0,1,4]  R187      -5.5964458733797073e-02
    z[0,1,4]  R188      -2.9413056373596191e-01
    z[0,1,4]  R189      -3.6034524440765381e-01
    z[0,1,4]  R190      1.6683399677276611e-01
    z[0,1,4]  R191      8.0830223858356476e-02
    z[0,1,4]  R192      -5.3942567110061646e-01
    z[0,1,4]  R193      -2.0701089501380920e-01
    z[0,1,4]  R194      -1.9030489027500153e-01
    z[0,1,4]  R195      -1.8470701575279236e-01
    z[0,1,4]  R196      -2.5172075629234314e-01
    z[0,1,4]  R197      1.8056106567382812e-01
    z[0,1,4]  R198      -3.7811735272407532e-01
    z[0,1,4]  R199      1.2574869394302368e-01
    z[0,1,4]  R200      8.3340726792812347e-02
    z[0,1,4]  R201      1.8651063740253448e-01
    z[0,1,4]  R202      -2.3539149761199951e-01
    z[0,1,4]  R203      -4.7724953293800354e-01
    z[0,1,4]  R204      -2.5400611758232117e-01
    z[0,1,4]  R205      0.585501492023468
    z[0,1,4]  R206      5.8831650018692017e-01
    z[0,1,4]  R207      3.0771106481552124e-01
    z[0,1,4]  R208      7.4283942580223083e-02
    z[0,1,4]  R209      1.8063382804393768e-01
    z[0,1,4]  R210      2.4540023505687714e-01
    z[0,1,4]  R211      2.2678276896476746e-01
    z[0,1,4]  R212      -5.2724468708038330e-01
    z[0,1,4]  R213      1.2705012224614620e-02
    z[0,1,4]  R214      -3.0059751868247986e-01
    z[0,1,4]  R215      3.8329407572746277e-01
    z[0,1,4]  R216      -4.2918534018099308e-03
    z[0,1,4]  R217      -2.0145541429519653e-01
    z[0,1,4]  R218      3.8457381725311279e-01
    z[0,1,4]  R219      -8.0744408071041107e-02
    z[0,1,4]  R220      -1.4044919610023499e-01
    z[0,1,4]  R221      -3.9815533906221390e-02
    z[0,1,4]  R222      -2.3382633924484253e-01
    z[0,1,4]  R223      -6.2321889400482178e-01
    z[0,1,4]  R224      -5.3854364156723022e-01
    z[0,1,4]  R225      -3.1705516576766968e-01
    z[0,1,4]  R226      3.6146484781056643e-03
    z[0,1,4]  R227      -2.3531749844551086e-01
    z[0,1,4]  R228      4.9750307202339172e-01
    z[0,1,4]  R229      5.4032534360885620e-01
    z[0,1,4]  R230      -4.1118609905242920e-01
    z[0,1,4]  R231      -2.6080089807510376e-01
    z[0,1,4]  R232      2.1534284949302673e-01
    z[0,1,4]  R233      1.9201648235321045e-01
    z[0,1,4]  R234      0.273902952671051
    z[0,1,4]  R235      5.1875393837690353e-02
    z[0,1,4]  R236      -3.1416463851928711e-01
    z[0,1,4]  R237      -4.7365394234657288e-01
    z[0,1,4]  R238      3.5780209302902222e-01
    z[0,1,4]  R239      2.7632737159729004e-01
    z[0,1,4]  R240      -2.4677792191505432e-01
    z[0,1,4]  R241      -2.3934873938560486e-01
    z[0,1,4]  R242      -2.8821733593940735e-01
    z[0,1,4]  R243      1.6172325611114502e-01
    z[0,1,4]  R244      9.7935229539871216e-02
    z[0,1,4]  R245      2.8338557481765747e-01
    z[0,1,4]  R246      -2.0178347826004028e-01
    z[0,1,4]  R247      -6.7096483707427979e-01
    z[0,1,4]  R248      -3.3685117959976196e-01
    z[0,1,4]  R249      -4.3128201365470886e-01
    z[0,1,4]  R250      2.8159880638122559e-01
    z[0,1,4]  R251      3.0252316594123840e-01
    z[0,1,4]  R252      -6.7659044265747070e-01
    z[0,1,4]  R253      -1.1162239313125610e-01
    z[0,1,4]  R254      -2.2105583921074867e-02
    z[0,1,4]  R255      -3.5612594336271286e-02
    z[0,1,4]  R256      -1.1146171391010284e-01
    z[0,1,4]  R257      8.9615978300571442e-02
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       -2.7762185782194138e-02
    z[0,1,5]  R89       -4.2355707287788391e-01
    z[0,1,5]  R90       -2.8850415349006653e-01
    z[0,1,5]  R91       8.6988382041454315e-02
    z[0,1,5]  R92       4.0703356266021729e-02
    z[0,1,5]  R93       3.9076272398233414e-02
    z[0,1,5]  R94       1.0142208635807037e-01
    z[0,1,5]  R95       -6.7737591266632080e-01
    z[0,1,5]  R96       -5.8848005533218384e-01
    z[0,1,5]  R97       4.9932379275560379e-02
    z[0,1,5]  R98       3.2726475596427917e-01
    z[0,1,5]  R99       8.3617325872182846e-03
    z[0,1,5]  R100      1.6888137161731720e-01
    z[0,1,5]  R101      3.5665473341941833e-01
    z[0,1,5]  R102      4.9061697721481323e-01
    z[0,1,5]  R103      3.3408010005950928e-01
    z[0,1,5]  R104      1.5271255373954773e-01
    z[0,1,5]  R105      1.5786384046077728e-01
    z[0,1,5]  R106      9.0284220874309540e-02
    z[0,1,5]  R107      9.1893002390861511e-02
    z[0,1,5]  R108      1.6373126208782196e-01
    z[0,1,5]  R109      -5.2146852016448975e-02
    z[0,1,5]  R110      4.7652739286422729e-01
    z[0,1,5]  R111      2.7792543172836304e-01
    z[0,1,5]  R112      3.6418086290359497e-01
    z[0,1,5]  R113      4.4458580017089844e-01
    z[0,1,5]  R114      8.2012486457824707e-01
    z[0,1,5]  R115      -1.5312202274799347e-01
    z[0,1,5]  R116      5.3218954801559448e-01
    z[0,1,5]  R117      3.9623332023620605e-01
    z[0,1,5]  R118      0.326760470867157
    z[0,1,5]  R119      1.3923436403274536e-01
    z[0,1,5]  R120      5.7900595664978027e-01
    z[0,1,5]  R121      4.2071428894996643e-01
    z[0,1,5]  R122      5.3725987672805786e-01
    z[0,1,5]  R123      -5.8837610483169556e-01
    z[0,1,5]  R124      5.7882612943649292e-01
    z[0,1,5]  R125      2.9531732201576233e-01
    z[0,1,5]  R126      -2.9737564921379089e-01
    z[0,1,5]  R127      7.7173076570034027e-02
    z[0,1,5]  R128      1.9338364899158478e-01
    z[0,1,5]  R129      -1.0505378013476729e-03
    z[0,1,5]  R130      4.4149649143218994e-01
    z[0,1,5]  R131      2.2492264211177826e-01
    z[0,1,5]  R132      -5.8490353822708130e-01
    z[0,1,5]  R133      6.3682332634925842e-02
    z[0,1,5]  R134      -3.8847097754478455e-01
    z[0,1,5]  R135      -5.6462105363607407e-02
    z[0,1,5]  R136      2.9099500179290771e-01
    z[0,1,5]  R137      6.9737970829010010e-02
    z[0,1,5]  R138      2.2050644457340240e-01
    z[0,1,5]  R139      3.4751009941101074e-01
    z[0,1,5]  R140      -6.1318314075469971e-01
    z[0,1,5]  R141      4.1727980971336365e-01
    z[0,1,5]  R142      1.9269576296210289e-02
    z[0,1,5]  R143      5.6343454122543335e-01
    z[0,1,5]  R144      -2.2268386185169220e-01
    z[0,1,5]  R145      1.2859074771404266e-01
    z[0,1,5]  R146      -4.2583969235420227e-01
    z[0,1,5]  R147      -2.5887307524681091e-01
    z[0,1,5]  R148      -5.3237382322549820e-02
    z[0,1,5]  R149      5.8502310514450073e-01
    z[0,1,5]  R150      1.9193184375762939e-01
    z[0,1,5]  R151      1.0772937536239624e-01
    z[0,1,5]  R152      3.7983378767967224e-01
    z[0,1,5]  R153      -2.5783991813659668e-01
    z[0,1,5]  R154      -9.3516901135444641e-02
    z[0,1,5]  R155      -2.3123618960380554e-01
    z[0,1,5]  R156      4.2595624923706055e-01
    z[0,1,5]  R157      -1.4268389344215393e-01
    z[0,1,5]  R158      0.0777122750878334
    z[0,1,5]  R159      -5.3333669900894165e-02
    z[0,1,5]  R160      1.9997552037239075e-01
    z[0,1,5]  R161      4.8900499939918518e-01
    z[0,1,5]  R162      4.7088339924812317e-01
    z[0,1,5]  R163      6.0139906406402588e-01
    z[0,1,5]  R164      5.2955496311187744e-01
    z[0,1,5]  R165      -1.8144200742244720e-01
    z[0,1,5]  R166      1.1370515823364258e-01
    z[0,1,5]  R167      -4.7502916306257248e-02
    z[0,1,5]  R168      -9.1118104755878448e-02
    z[0,1,5]  R169      7.1925801038742065e-01
    z[0,1,5]  R170      4.3071508407592773e-01
    z[0,1,5]  R171      6.1889731884002686e-01
    z[0,1,5]  R172      2.2198554128408432e-02
    z[0,1,5]  R173      -1.8600904941558838e-01
    z[0,1,5]  R174      -1.1791043728590012e-01
    z[0,1,5]  R175      -2.7503988146781921e-01
    z[0,1,5]  R176      -6.9555658102035522e-01
    z[0,1,5]  R177      -2.5169846415519714e-01
    z[0,1,5]  R178      -1.3124023377895355e-01
    z[0,1,5]  R179      -2.8038018941879272e-01
    z[0,1,5]  R180      7.5025603175163269e-02
    z[0,1,5]  R181      -3.6038011312484741e-01
    z[0,1,5]  R182      2.1793329715728760e-01
    z[0,1,5]  R183      0.327493280172348
    z[0,1,5]  R184      4.5138490386307240e-03
    z[0,1,5]  R185      -1.6327352821826935e-01
    z[0,1,5]  R186      1.4789652824401855e-01
    z[0,1,5]  R187      -3.5024428367614746e-01
    z[0,1,5]  R188      -8.0627001821994781e-02
    z[0,1,5]  R189      1.1245064437389374e-01
    z[0,1,5]  R190      -2.2123867273330688e-01
    z[0,1,5]  R191      4.2015653848648071e-01
    z[0,1,5]  R192      -2.4561443924903870e-01
    z[0,1,5]  R193      1.3122916221618652e-01
    z[0,1,5]  R194      2.1605223417282104e-02
    z[0,1,5]  R195      6.8585580587387085e-01
    z[0,1,5]  R196      -6.3566464185714722e-01
    z[0,1,5]  R197      1.0161749273538589e-01
    z[0,1,5]  R198      3.2601559162139893e-01
    z[0,1,5]  R199      2.3436428979039192e-02
    z[0,1,5]  R200      -4.8586927354335785e-02
    z[0,1,5]  R201      4.8255950212478638e-01
    z[0,1,5]  R202      1.6032800078392029e-01
    z[0,1,5]  R203      1.6008377075195312e-01
    z[0,1,5]  R204      4.6952900290489197e-01
    z[0,1,5]  R205      2.7046111226081848e-01
    z[0,1,5]  R206      -9.7774252295494080e-02
    z[0,1,5]  R207      -2.4051584303379059e-01
    z[0,1,5]  R208      -1.6773492097854614e-01
    z[0,1,5]  R209      3.0281695723533630e-01
    z[0,1,5]  R210      5.0691539049148560e-01
    z[0,1,5]  R211      -3.0283734202384949e-01
    z[0,1,5]  R212      -2.0944355428218842e-01
    z[0,1,5]  R213      4.4047471880912781e-01
    z[0,1,5]  R214      -5.1340639591217041e-02
    z[0,1,5]  R215      -4.2167093604803085e-02
    z[0,1,5]  R216      -1.0983082652091980e-01
    z[0,1,5]  R217      2.0590883493423462e-01
    z[0,1,5]  R218      1.8038934469223022e-01
    z[0,1,5]  R219      1.9750857353210449e-01
    z[0,1,5]  R220      -2.5759214162826538e-01
    z[0,1,5]  R221      1.0314231365919113e-01
    z[0,1,5]  R222      -2.3229399323463440e-01
    z[0,1,5]  R223      1.4108738303184509e-01
    z[0,1,5]  R224      -1.6553550958633423e-01
    z[0,1,5]  R225      3.3517107367515564e-01
    z[0,1,5]  R226      -6.1202347278594971e-02
    z[0,1,5]  R227      -2.1936956793069839e-02
    z[0,1,5]  R228      1.5046262741088867e-01
    z[0,1,5]  R229      -1.9028775393962860e-01
    z[0,1,5]  R230      -3.2681442797183990e-02
    z[0,1,5]  R231      -1.0058090090751648e-01
    z[0,1,5]  R232      2.3878295719623566e-01
    z[0,1,5]  R233      5.3994023799896240e-01
    z[0,1,5]  R234      -1.7359418561682105e-03
    z[0,1,5]  R235      -0.302208811044693
    z[0,1,5]  R236      -5.0271379947662354e-01
    z[0,1,5]  R237      -4.7846382856369019e-01
    z[0,1,5]  R238      -3.9522830396890640e-02
    z[0,1,5]  R239      1.5944422781467438e-01
    z[0,1,5]  R240      -1.1943912133574486e-02
    z[0,1,5]  R241      -4.6248380094766617e-02
    z[0,1,5]  R242      -2.5208237767219543e-01
    z[0,1,5]  R243      1.9102320075035095e-01
    z[0,1,5]  R244      7.8355357050895691e-02
    z[0,1,5]  R245      2.8564539551734924e-01
    z[0,1,5]  R246      4.2012757062911987e-01
    z[0,1,5]  R247      -4.8686340451240540e-02
    z[0,1,5]  R248      1.3680109381675720e-01
    z[0,1,5]  R249      3.5877469182014465e-01
    z[0,1,5]  R250      4.1626819968223572e-01
    z[0,1,5]  R251      -1.2600140273571014e-01
    z[0,1,5]  R252      3.3882644027471542e-02
    z[0,1,5]  R253      -0.522332489490509
    z[0,1,5]  R254      -6.4811789989471436e-01
    z[0,1,5]  R255      3.1140094995498657e-01
    z[0,1,5]  R256      -1.1855640262365341e-01
    z[0,1,5]  R257      1.4906461536884308e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       1.9107328355312347e-01
    z[0,1,6]  R89       3.0165421962738037e-01
    z[0,1,6]  R90       1.3045558333396912e-01
    z[0,1,6]  R91       2.6932266354560852e-01
    z[0,1,6]  R92       -2.1146193146705627e-01
    z[0,1,6]  R93       2.8522223234176636e-01
    z[0,1,6]  R94       -2.6264557242393494e-01
    z[0,1,6]  R95       -5.1534049212932587e-02
    z[0,1,6]  R96       -2.6396539807319641e-01
    z[0,1,6]  R97       5.9392873197793961e-02
    z[0,1,6]  R98       6.3238894939422607e-01
    z[0,1,6]  R99       4.8657186329364777e-02
    z[0,1,6]  R100      2.2225466370582581e-01
    z[0,1,6]  R101      2.6226265355944633e-02
    z[0,1,6]  R102      -8.5489697754383087e-02
    z[0,1,6]  R103      1.1524365842342377e-01
    z[0,1,6]  R104      -6.0925945639610291e-02
    z[0,1,6]  R105      2.4047592282295227e-01
    z[0,1,6]  R106      2.7839845418930054e-01
    z[0,1,6]  R107      1.4632443897426128e-02
    z[0,1,6]  R108      -1.9516487419605255e-01
    z[0,1,6]  R109      3.6841621994972229e-01
    z[0,1,6]  R110      -1.7419892549514771e-01
    z[0,1,6]  R111      -1.0508665442466736e-01
    z[0,1,6]  R112      2.1887370944023132e-01
    z[0,1,6]  R113      4.9801462888717651e-01
    z[0,1,6]  R114      -2.0023313164710999e-01
    z[0,1,6]  R115      4.2687371373176575e-02
    z[0,1,6]  R116      -1.7269712686538696e-01
    z[0,1,6]  R117      2.5844737887382507e-01
    z[0,1,6]  R118      2.2752356529235840e-01
    z[0,1,6]  R119      3.2015082240104675e-01
    z[0,1,6]  R120      -3.0852247029542923e-02
    z[0,1,6]  R121      -1.4967158436775208e-01
    z[0,1,6]  R122      1.0632573813199997e-01
    z[0,1,6]  R123      -2.5837266445159912e-01
    z[0,1,6]  R124      1.5754364430904388e-01
    z[0,1,6]  R125      2.8766760230064392e-01
    z[0,1,6]  R126      1.4787826687097549e-02
    z[0,1,6]  R127      -3.1033328175544739e-01
    z[0,1,6]  R128      -1.5594394505023956e-01
    z[0,1,6]  R129      -2.1786347031593323e-01
    z[0,1,6]  R130      4.2473133653402328e-03
    z[0,1,6]  R131      5.7245563715696335e-02
    z[0,1,6]  R132      2.0748578011989594e-01
    z[0,1,6]  R133      9.0484723448753357e-02
    z[0,1,6]  R134      3.7761884927749634e-01
    z[0,1,6]  R135      1.8649470806121826e-01
    z[0,1,6]  R136      3.0846813693642616e-02
    z[0,1,6]  R137      -3.6305539309978485e-02
    z[0,1,6]  R138      1.4598475396633148e-01
    z[0,1,6]  R139      -4.3949750065803528e-01
    z[0,1,6]  R140      -3.2506820559501648e-01
    z[0,1,6]  R141      4.5821475982666016e-01
    z[0,1,6]  R142      -2.0079061388969421e-01
    z[0,1,6]  R143      2.7436956763267517e-01
    z[0,1,6]  R144      3.0983682721853256e-02
    z[0,1,6]  R145      -2.7007344365119934e-01
    z[0,1,6]  R146      4.2271953821182251e-01
    z[0,1,6]  R147      -2.1987275779247284e-01
    z[0,1,6]  R148      1.7963241040706635e-01
    z[0,1,6]  R149      -2.9832735657691956e-01
    z[0,1,6]  R150      0.0983017086982727
    z[0,1,6]  R151      -3.1668996810913086e-01
    z[0,1,6]  R152      1.5204668045043945e-01
    z[0,1,6]  R153      1.3626010715961456e-01
    z[0,1,6]  R154      -5.1867388188838959e-02
    z[0,1,6]  R155      2.4919275939464569e-01
    z[0,1,6]  R156      -8.0029524862766266e-02
    z[0,1,6]  R157      -6.3693143427371979e-02
    z[0,1,6]  R158      -2.0735444128513336e-01
    z[0,1,6]  R159      -6.4610382542014122e-03
    z[0,1,6]  R160      3.9105647802352905e-01
    z[0,1,6]  R161      -9.8922356963157654e-02
    z[0,1,6]  R162      -7.9763151705265045e-02
    z[0,1,6]  R163      -4.5124265551567078e-01
    z[0,1,6]  R164      2.8198403120040894e-01
    z[0,1,6]  R165      2.2629508748650551e-02
    z[0,1,6]  R166      2.7077522128820419e-02
    z[0,1,6]  R167      2.3101305961608887e-01
    z[0,1,6]  R168      0.200897216796875
    z[0,1,6]  R169      -1.4587773382663727e-01
    z[0,1,6]  R170      -2.3490564525127411e-01
    z[0,1,6]  R171      3.2156085968017578e-01
    z[0,1,6]  R172      -1.8251250684261322e-01
    z[0,1,6]  R173      1.9953005015850067e-01
    z[0,1,6]  R174      -6.6221915185451508e-02
    z[0,1,6]  R175      8.4433071315288544e-02
    z[0,1,6]  R176      0.0134742995724082
    z[0,1,6]  R177      -2.3847445845603943e-01
    z[0,1,6]  R178      1.2716157734394073e-01
    z[0,1,6]  R179      1.5073044598102570e-01
    z[0,1,6]  R180      2.1515524387359619e-01
    z[0,1,6]  R181      1.2325572315603495e-03
    z[0,1,6]  R182      3.8559707999229431e-01
    z[0,1,6]  R183      2.1913446485996246e-01
    z[0,1,6]  R184      8.5130125284194946e-02
    z[0,1,6]  R185      -9.3266211450099945e-02
    z[0,1,6]  R186      -1.9759789574891329e-03
    z[0,1,6]  R187      3.5060763359069824e-01
    z[0,1,6]  R188      4.9979421496391296e-01
    z[0,1,6]  R189      4.5782285928726196e-01
    z[0,1,6]  R190      0.186710387468338
    z[0,1,6]  R191      -3.7591807544231415e-02
    z[0,1,6]  R192      1.7357769608497620e-01
    z[0,1,6]  R193      3.3277422189712524e-01
    z[0,1,6]  R194      5.0272655487060547e-01
    z[0,1,6]  R195      1.0680851340293884e-01
    z[0,1,6]  R196      1.3413478434085846e-01
    z[0,1,6]  R197      7.2482489049434662e-03
    z[0,1,6]  R198      -3.0580368638038635e-01
    z[0,1,6]  R199      1.3495469093322754e-01
    z[0,1,6]  R200      4.1644933819770813e-01
    z[0,1,6]  R201      -1.4860205352306366e-02
    z[0,1,6]  R202      4.7997146844863892e-02
    z[0,1,6]  R203      1.3998521491885185e-02
    z[0,1,6]  R204      -6.0403626412153244e-03
    z[0,1,6]  R205      1.2651675939559937e-01
    z[0,1,6]  R206      2.2318558394908905e-01
    z[0,1,6]  R207      0.195567324757576
    z[0,1,6]  R208      -3.5780292749404907e-01
    z[0,1,6]  R209      -4.9721777439117432e-01
    z[0,1,6]  R210      -1.5979675948619843e-01
    z[0,1,6]  R211      9.8930552601814270e-02
    z[0,1,6]  R212      5.7686984539031982e-02
    z[0,1,6]  R213      6.6268257796764374e-02
    z[0,1,6]  R214      -1.2977904640138149e-02
    z[0,1,6]  R215      1.9720393419265747e-01
    z[0,1,6]  R216      -2.4530166760087013e-02
    z[0,1,6]  R217      2.0649281144142151e-01
    z[0,1,6]  R218      -9.3907155096530914e-02
    z[0,1,6]  R219      -1.4130038209259510e-02
    z[0,1,6]  R220      1.2083718320354819e-03
    z[0,1,6]  R221      -6.6228836774826050e-01
    z[0,1,6]  R222      -2.2472234442830086e-02
    z[0,1,6]  R223      -8.8884793221950531e-02
    z[0,1,6]  R224      -3.1703668832778931e-01
    z[0,1,6]  R225      -1.5562385320663452e-01
    z[0,1,6]  R226      3.9094823598861694e-01
    z[0,1,6]  R227      4.9489045143127441e-01
    z[0,1,6]  R228      -8.4049604833126068e-02
    z[0,1,6]  R229      1.0578565299510956e-01
    z[0,1,6]  R230      -7.1422919631004333e-02
    z[0,1,6]  R231      -2.7642959356307983e-01
    z[0,1,6]  R232      2.4088962376117706e-01
    z[0,1,6]  R233      3.9835140109062195e-01
    z[0,1,6]  R234      2.0724989473819733e-02
    z[0,1,6]  R235      1.6438685357570648e-01
    z[0,1,6]  R236      -0.330636590719223
    z[0,1,6]  R237      0.138252854347229
    z[0,1,6]  R238      -5.0750296562910080e-02
    z[0,1,6]  R239      -2.4333896115422249e-02
    z[0,1,6]  R240      -1.4620308578014374e-01
    z[0,1,6]  R241      1.5129800140857697e-01
    z[0,1,6]  R242      1.7641171813011169e-01
    z[0,1,6]  R243      3.0636507272720337e-01
    z[0,1,6]  R244      5.7734644412994385e-01
    z[0,1,6]  R245      -1.0565790534019470e-01
    z[0,1,6]  R246      3.5000890493392944e-01
    z[0,1,6]  R247      2.9473862051963806e-01
    z[0,1,6]  R248      -4.0086947381496429e-02
    z[0,1,6]  R249      -8.2158427685499191e-03
    z[0,1,6]  R250      1.2432643026113510e-01
    z[0,1,6]  R251      4.1455402970314026e-03
    z[0,1,6]  R252      2.3970237374305725e-01
    z[0,1,6]  R253      -1.8729726970195770e-01
    z[0,1,6]  R254      4.3650665879249573e-01
    z[0,1,6]  R255      -5.9363774955272675e-02
    z[0,1,6]  R256      -8.5072867572307587e-02
    z[0,1,6]  R257      1.4224433898925781e-01
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R258      -1
    z[1,0,0]  R259      1
    z[1,0,0]  R272      6.6226828098297119e-01
    z[1,0,0]  R273      5.0675106048583984e-01
    z[1,0,0]  R274      6.5007501840591431e-01
    z[1,0,0]  R275      1.0458222776651382e-01
    z[1,0,0]  R276      2.2211848199367523e-01
    z[1,0,0]  R277      3.1830188632011414e-01
    z[1,0,0]  R278      7.1310373023152351e-03
    z[1,0,0]  R279      1.2181148678064346e-01
    z[1,0,0]  R280      5.2474808692932129e-01
    z[1,0,0]  R281      2.7573135495185852e-01
    z[1,0,0]  R282      -3.1164163723587990e-02
    z[1,0,0]  R283      4.1819611191749573e-01
    z[1,0,0]  R284      -1.1259645689278841e-03
    z[1,0,0]  R285      1.9186483323574066e-01
    z[1,0,0]  R286      4.5464757084846497e-01
    z[1,0,0]  R287      2.1068836748600006e-01
    z[1,0,0]  R288      4.2194575071334839e-01
    z[1,0,0]  R289      0.0399978905916214
    z[1,0,0]  R290      -7.8884936869144440e-02
    z[1,0,0]  R291      -3.5735324025154114e-01
    z[1,0,0]  R292      4.9055644869804382e-01
    z[1,0,0]  R293      4.2514945380389690e-03
    z[1,0,0]  R294      -3.6638548970222473e-01
    z[1,0,0]  R295      7.1098022162914276e-02
    z[1,0,0]  R296      3.7249189615249634e-01
    z[1,0,0]  R297      1.7393809556961060e-01
    z[1,0,0]  R298      -3.4418198466300964e-01
    z[1,0,0]  R299      -6.9354742765426636e-02
    z[1,0,0]  R300      5.6962281465530396e-02
    z[1,0,0]  R301      -1.6051355749368668e-02
    z[1,0,0]  R302      1.4299128204584122e-02
    z[1,0,0]  R303      -2.2865882515907288e-01
    z[1,0,0]  R304      1.5479490393772721e-03
    z[1,0,0]  R305      2.1054595708847046e-01
    z[1,0,0]  R306      -1.3603353500366211e-01
    z[1,0,0]  R307      -5.2306145429611206e-01
    z[1,0,0]  R308      -2.8902623057365417e-01
    z[1,0,0]  R309      5.5070221424102783e-01
    z[1,0,0]  R310      -1.3425610959529877e-01
    z[1,0,0]  R311      -1.5736041963100433e-01
    z[1,0,0]  R312      4.6794205904006958e-01
    z[1,0,0]  R313      4.7420230694115162e-03
    z[1,0,0]  R314      5.1805965602397919e-02
    z[1,0,0]  R315      0.0555608794093132
    z[1,0,0]  R316      7.6698541641235352e-02
    z[1,0,0]  R317      -1.5540167689323425e-01
    z[1,0,0]  R318      -3.9058607071638107e-02
    z[1,0,0]  R319      1.5152822434902191e-01
    z[1,0,0]  R320      1.5403473377227783e-01
    z[1,0,0]  R321      2.5715324282646179e-01
    z[1,0,0]  R322      2.2457849979400635e-01
    z[1,0,0]  R323      1.5101094543933868e-01
    z[1,0,0]  R324      5.6134972721338272e-02
    z[1,0,0]  R325      -1.3665618002414703e-01
    z[1,0,0]  R326      2.1534779667854309e-01
    z[1,0,0]  R327      1.2021030124742538e-04
    z[1,0,0]  R328      9.9304080009460449e-02
    z[1,0,0]  R329      -6.8425840139389038e-01
    z[1,0,0]  R330      -6.2479972839355469e-01
    z[1,0,0]  R331      -5.2208727598190308e-01
    z[1,0,0]  R332      3.6214053630828857e-01
    z[1,0,0]  R333      -3.7188172340393066e-02
    z[1,0,0]  R334      -1.6319125890731812e-02
    z[1,0,0]  R335      1.0568692535161972e-01
    z[1,0,0]  R336      -4.8138600587844849e-01
    z[1,0,0]  R337      2.8912544250488281e-01
    z[1,0,0]  R338      3.7493386864662170e-01
    z[1,0,0]  R339      7.4260830879211426e-03
    z[1,0,0]  R340      5.1129949092864990e-01
    z[1,0,0]  R341      2.9517391324043274e-01
    z[1,0,0]  R342      -4.0680280327796936e-01
    z[1,0,0]  R343      -5.5722106248140335e-02
    z[1,0,0]  R344      2.4958252906799316e-01
    z[1,0,0]  R345      7.6721549034118652e-02
    z[1,0,0]  R346      3.0775913596153259e-01
    z[1,0,0]  R347      -5.7606834173202515e-01
    z[1,0,0]  R348      -5.7863569259643555e-01
    z[1,0,0]  R349      -0.365887314081192
    z[1,0,0]  R350      -3.7225973606109619e-01
    z[1,0,0]  R351      -3.6723691225051880e-01
    z[1,0,0]  R352      -6.4063489437103271e-02
    z[1,0,0]  R353      1.6059769690036774e-01
    z[1,0,0]  R354      1.3274246454238892e-01
    z[1,0,0]  R355      6.3208468258380890e-02
    z[1,0,0]  R356      1.0475829988718033e-01
    z[1,0,0]  R357      1.5666396915912628e-01
    z[1,0,0]  R358      2.4719725549221039e-01
    z[1,0,0]  R359      5.6741088628768921e-01
    z[1,0,0]  R360      5.1577204465866089e-01
    z[1,0,0]  R361      -6.9601279497146606e-01
    z[1,0,0]  R362      -1.3350605964660645e-01
    z[1,0,0]  R363      1.7930482327938080e-01
    z[1,0,0]  R364      -2.8537398576736450e-01
    z[1,0,0]  R365      1.6607774794101715e-01
    z[1,0,0]  R366      5.1720064133405685e-02
    z[1,0,0]  R367      -8.3205364644527435e-03
    z[1,0,0]  R368      4.0531735867261887e-02
    z[1,0,0]  R369      7.2678372263908386e-02
    z[1,0,0]  R370      0.260046124458313
    z[1,0,0]  R371      1.3106101751327515e-01
    z[1,0,0]  R372      -3.5949856042861938e-02
    z[1,0,0]  R373      2.7664564549922943e-02
    z[1,0,0]  R374      7.8953303396701813e-02
    z[1,0,0]  R375      1.5168353915214539e-01
    z[1,0,0]  R376      -3.3841833472251892e-01
    z[1,0,0]  R377      -2.2327479720115662e-01
    z[1,0,0]  R378      -2.6558920741081238e-01
    z[1,0,0]  R379      1.4662556350231171e-02
    z[1,0,0]  R380      -0.260986864566803
    z[1,0,0]  R381      -3.6370101571083069e-01
    z[1,0,0]  R382      3.5187106579542160e-02
    z[1,0,0]  R383      -1.2392750382423401e-01
    z[1,0,0]  R384      -4.5920538902282715e-01
    z[1,0,0]  R385      0.0667165070772171
    z[1,0,0]  R386      -2.9462891817092896e-01
    z[1,0,0]  R387      0.644294261932373
    z[1,0,0]  R388      -4.7134527564048767e-01
    z[1,0,0]  R389      2.8061863034963608e-02
    z[1,0,0]  R390      3.2971829175949097e-01
    z[1,0,0]  R391      6.9544982910156250e-01
    z[1,0,0]  R392      8.0374181270599365e-02
    z[1,0,0]  R393      4.4361403584480286e-01
    z[1,0,0]  R394      -2.3828917741775513e-01
    z[1,0,0]  R395      3.4130752086639404e-01
    z[1,0,0]  R396      -4.8296146094799042e-02
    z[1,0,0]  R397      -2.8567740321159363e-01
    z[1,0,0]  R398      -3.0408853292465210e-01
    z[1,0,0]  R399      7.3413014411926270e-01
    z[1,0,0]  R400      0.762452244758606
    z[1,0,0]  R401      -1.3330757617950439e-01
    z[1,0,0]  R402      0.0967952162027359
    z[1,0,0]  R403      5.4665857553482056e-01
    z[1,0,0]  R404      5.7045292854309082e-01
    z[1,0,0]  R405      4.8920072615146637e-02
    z[1,0,0]  R406      2.1173666417598724e-01
    z[1,0,0]  R407      4.0548691153526306e-01
    z[1,0,0]  R408      1.5091603994369507e-01
    z[1,0,0]  R409      6.5789061784744263e-01
    z[1,0,0]  R410      -4.8623021692037582e-02
    z[1,0,0]  R411      2.5142499804496765e-01
    z[1,0,0]  R412      1.9243241846561432e-01
    z[1,0,0]  R413      3.9235064387321472e-01
    z[1,0,0]  R414      2.9140564799308777e-01
    z[1,0,0]  R415      6.2068152427673340e-01
    z[1,0,0]  R416      -3.7842559814453125e-01
    z[1,0,0]  R417      1.0778354853391647e-01
    z[1,0,0]  R418      4.9369942396879196e-02
    z[1,0,0]  R419      -6.9795258343219757e-02
    z[1,0,0]  R420      -1.4652828872203827e-01
    z[1,0,0]  R421      0.0670105367898941
    z[1,0,0]  R422      0.550288736820221
    z[1,0,0]  R423      3.2825458794832230e-02
    z[1,0,0]  R424      -2.2199097275733948e-01
    z[1,0,0]  R425      -3.4488037228584290e-02
    z[1,0,0]  R426      1.8360415101051331e-01
    z[1,0,0]  R427      1.9765444099903107e-01
    z[1,0,0]  R428      -4.3908235430717468e-01
    z[1,0,0]  R429      -6.3887882232666016e-01
    z[1,0,0]  R430      -4.3565583229064941e-01
    z[1,0,0]  R431      -4.5687532424926758e-01
    z[1,0,0]  R432      0.084299735724926
    z[1,0,0]  R433      -4.7861550003290176e-02
    z[1,0,0]  R434      3.4174117445945740e-01
    z[1,0,0]  R435      -3.4983676671981812e-01
    z[1,0,0]  R436      -1.5232269465923309e-01
    z[1,0,0]  R437      -4.1082230210304260e-01
    z[1,0,0]  R438      -3.1880471110343933e-01
    z[1,0,0]  R439      -2.5601112842559814e-01
    z[1,0,0]  R440      -1.4790304005146027e-01
    z[1,0,0]  R441      1.4020407572388649e-02
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R260      -1
    z[1,0,1]  R261      1
    z[1,0,1]  R272      -6.7258083820343018e-01
    z[1,0,1]  R273      -6.8709844350814819e-01
    z[1,0,1]  R274      -5.6269049644470215e-01
    z[1,0,1]  R275      -7.4100935459136963e-01
    z[1,0,1]  R276      -3.2611182332038879e-01
    z[1,0,1]  R277      -3.8324546813964844e-01
    z[1,0,1]  R278      -4.3025317788124084e-01
    z[1,0,1]  R279      2.0489771664142609e-01
    z[1,0,1]  R280      1.4688260853290558e-01
    z[1,0,1]  R281      1.5543220937252045e-01
    z[1,0,1]  R282      6.3851112127304077e-01
    z[1,0,1]  R283      5.9961098432540894e-01
    z[1,0,1]  R284      5.2976197004318237e-01
    z[1,0,1]  R285      5.1576942205429077e-01
    z[1,0,1]  R286      5.9200048446655273e-01
    z[1,0,1]  R287      6.2387037277221680e-01
    z[1,0,1]  R288      4.2148393392562866e-01
    z[1,0,1]  R289      5.3740245103836060e-01
    z[1,0,1]  R290      5.1812380552291870e-01
    z[1,0,1]  R291      7.2589772939682007e-01
    z[1,0,1]  R292      -4.7521993517875671e-01
    z[1,0,1]  R293      8.1426149606704712e-01
    z[1,0,1]  R294      8.0973690748214722e-01
    z[1,0,1]  R295      7.7333015203475952e-01
    z[1,0,1]  R296      7.5256580114364624e-01
    z[1,0,1]  R297      7.4798589944839478e-01
    z[1,0,1]  R298      7.3069638013839722e-01
    z[1,0,1]  R299      7.2040134668350220e-01
    z[1,0,1]  R300      7.1463263034820557e-01
    z[1,0,1]  R301      6.6782295703887939e-01
    z[1,0,1]  R302      -4.9307525157928467e-01
    z[1,0,1]  R303      -4.1209849715232849e-01
    z[1,0,1]  R304      -4.0078794956207275e-01
    z[1,0,1]  R305      7.5803959369659424e-01
    z[1,0,1]  R306      7.2552794218063354e-01
    z[1,0,1]  R307      0.687884509563446
    z[1,0,1]  R308      6.7090785503387451e-01
    z[1,0,1]  R309      6.7062664031982422e-01
    z[1,0,1]  R310      4.3769472837448120e-01
    z[1,0,1]  R311      5.0664401054382324e-01
    z[1,0,1]  R312      -4.2647719383239746e-01
    z[1,0,1]  R313      9.2548382282257080e-01
    z[1,0,1]  R314      9.3614894151687622e-01
    z[1,0,1]  R315      -5.5481582880020142e-01
    z[1,0,1]  R316      3.9922478795051575e-01
    z[1,0,1]  R317      5.6196242570877075e-01
    z[1,0,1]  R318      3.0727306008338928e-01
    z[1,0,1]  R319      5.6547051668167114e-01
    z[1,0,1]  R320      3.8533520698547363e-01
    z[1,0,1]  R321      5.2388507127761841e-01
    z[1,0,1]  R322      -0.412022203207016
    z[1,0,1]  R323      7.7927333116531372e-01
    z[1,0,1]  R324      5.2602005004882812e-01
    z[1,0,1]  R325      3.4048739075660706e-01
    z[1,0,1]  R326      0.622753381729126
    z[1,0,1]  R327      6.6513508558273315e-01
    z[1,0,1]  R328      5.4914355278015137e-01
    z[1,0,1]  R329      2.9145723674446344e-03
    z[1,0,1]  R330      2.1156106889247894e-01
    z[1,0,1]  R331      2.6425412297248840e-01
    z[1,0,1]  R332      -7.1557760238647461e-01
    z[1,0,1]  R333      -0.357464075088501
    z[1,0,1]  R334      4.5127025246620178e-01
    z[1,0,1]  R335      5.9350270032882690e-01
    z[1,0,1]  R336      6.6273349523544312e-01
    z[1,0,1]  R337      7.0407730340957642e-01
    z[1,0,1]  R338      6.6769748926162720e-01
    z[1,0,1]  R339      6.0759299993515015e-01
    z[1,0,1]  R340      3.6614662408828735e-01
    z[1,0,1]  R341      1.9975721836090088e-01
    z[1,0,1]  R342      7.7622473239898682e-01
    z[1,0,1]  R343      6.4539241790771484e-01
    z[1,0,1]  R344      6.8543708324432373e-01
    z[1,0,1]  R345      0.50160151720047
    z[1,0,1]  R346      2.3102851212024689e-01
    z[1,0,1]  R347      2.4664409458637238e-01
    z[1,0,1]  R348      1.3632266223430634e-01
    z[1,0,1]  R349      -6.9078433513641357e-01
    z[1,0,1]  R350      -6.7879754304885864e-01
    z[1,0,1]  R351      -6.8327230215072632e-01
    z[1,0,1]  R352      -5.2023779600858688e-02
    z[1,0,1]  R353      1.8688815832138062e-01
    z[1,0,1]  R354      -2.0055456459522247e-01
    z[1,0,1]  R355      4.0589934587478638e-01
    z[1,0,1]  R356      -3.5552942752838135e-01
    z[1,0,1]  R357      1.1135175079107285e-01
    z[1,0,1]  R358      1.5564145147800446e-01
    z[1,0,1]  R359      -1.4409725368022919e-01
    z[1,0,1]  R360      -3.5696956515312195e-01
    z[1,0,1]  R361      -6.0474425554275513e-01
    z[1,0,1]  R362      5.9611005708575249e-03
    z[1,0,1]  R363      -1.3778430223464966e-01
    z[1,0,1]  R364      1.5254957973957062e-01
    z[1,0,1]  R365      4.2437443137168884e-01
    z[1,0,1]  R366      -3.2389974594116211e-01
    z[1,0,1]  R367      -3.8495957851409912e-01
    z[1,0,1]  R368      -5.0874465703964233e-01
    z[1,0,1]  R369      -3.6350693553686142e-02
    z[1,0,1]  R370      0.101785808801651
    z[1,0,1]  R371      1.9338355958461761e-01
    z[1,0,1]  R372      4.4235434383153915e-02
    z[1,0,1]  R373      -5.3629451990127563e-01
    z[1,0,1]  R374      0.81854248046875
    z[1,0,1]  R375      6.3725358247756958e-01
    z[1,0,1]  R376      -1.5819889307022095e-01
    z[1,0,1]  R377      4.4261854887008667e-01
    z[1,0,1]  R378      -4.1794739663600922e-02
    z[1,0,1]  R379      8.7619268894195557e-01
    z[1,0,1]  R380      1.1899554729461670e-01
    z[1,0,1]  R381      3.3444416522979736e-01
    z[1,0,1]  R382      -2.4165698885917664e-01
    z[1,0,1]  R383      2.8275391459465027e-01
    z[1,0,1]  R384      3.5537354648113251e-02
    z[1,0,1]  R385      -7.6254919171333313e-02
    z[1,0,1]  R386      -4.0073856711387634e-02
    z[1,0,1]  R387      0.0935761034488678
    z[1,0,1]  R388      -2.2781632840633392e-01
    z[1,0,1]  R389      0.36614990234375
    z[1,0,1]  R390      2.5656276941299438e-01
    z[1,0,1]  R391      3.1483608484268188e-01
    z[1,0,1]  R392      5.7906292378902435e-02
    z[1,0,1]  R393      7.1568292379379272e-01
    z[1,0,1]  R394      -3.4410279989242554e-01
    z[1,0,1]  R395      2.2935485467314720e-03
    z[1,0,1]  R396      0.634415328502655
    z[1,0,1]  R397      7.4076700210571289e-01
    z[1,0,1]  R398      5.5692654848098755e-01
    z[1,0,1]  R399      6.0079181194305420e-01
    z[1,0,1]  R400      5.2259796857833862e-01
    z[1,0,1]  R401      -9.6683973073959351e-01
    z[1,0,1]  R402      3.7239167094230652e-01
    z[1,0,1]  R403      -5.7963605970144272e-02
    z[1,0,1]  R404      -4.1433505713939667e-02
    z[1,0,1]  R405      -6.8225346505641937e-02
    z[1,0,1]  R406      -1.5415996313095093e-01
    z[1,0,1]  R407      -3.3002066612243652e-01
    z[1,0,1]  R408      -0.294149249792099
    z[1,0,1]  R409      3.0904176831245422e-01
    z[1,0,1]  R410      1.3697081804275513e-01
    z[1,0,1]  R411      0.750571072101593
    z[1,0,1]  R412      -3.0818048119544983e-01
    z[1,0,1]  R413      2.4123266339302063e-01
    z[1,0,1]  R414      1.3480287790298462e-01
    z[1,0,1]  R415      1.3289435207843781e-01
    z[1,0,1]  R416      -2.2830264270305634e-01
    z[1,0,1]  R417      3.2131770253181458e-01
    z[1,0,1]  R418      -2.1391832828521729e-01
    z[1,0,1]  R419      2.7872404456138611e-01
    z[1,0,1]  R420      -2.0348201692104340e-01
    z[1,0,1]  R421      6.0059273242950439e-01
    z[1,0,1]  R422      1.6556029021739960e-01
    z[1,0,1]  R423      -1.4329962432384491e-01
    z[1,0,1]  R424      2.1220651268959045e-01
    z[1,0,1]  R425      -1.6914875805377960e-01
    z[1,0,1]  R426      -1.4743930101394653e-01
    z[1,0,1]  R427      -1.7499189078807831e-01
    z[1,0,1]  R428      -3.5884156823158264e-01
    z[1,0,1]  R429      5.8143043518066406e-01
    z[1,0,1]  R430      -8.5988634824752808e-01
    z[1,0,1]  R431      -8.2960969209671021e-01
    z[1,0,1]  R432      2.7405783534049988e-01
    z[1,0,1]  R433      1.1639898270368576e-01
    z[1,0,1]  R434      -9.9900364875793457e-02
    z[1,0,1]  R435      -1.8450449407100677e-01
    z[1,0,1]  R436      -9.3087553977966309e-01
    z[1,0,1]  R437      -8.3404815196990967e-01
    z[1,0,1]  R438      -0.841460645198822
    z[1,0,1]  R439      -8.5124516487121582e-01
    z[1,0,1]  R440      -3.2479953765869141e-01
    z[1,0,1]  R441      -9.0595930814743042e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R262      -1
    z[1,0,2]  R263      1
    z[1,0,2]  R272      2.3809601366519928e-01
    z[1,0,2]  R273      1.9728195667266846e-01
    z[1,0,2]  R274      1.2139609456062317e-01
    z[1,0,2]  R275      0.398151695728302
    z[1,0,2]  R276      7.1022289991378784e-01
    z[1,0,2]  R277      6.8480712175369263e-01
    z[1,0,2]  R278      4.3799924850463867e-01
    z[1,0,2]  R279      -8.5877221822738647e-01
    z[1,0,2]  R280      -0.642659068107605
    z[1,0,2]  R281      -7.8482675552368164e-01
    z[1,0,2]  R282      4.8950761556625366e-01
    z[1,0,2]  R283      1.9180183112621307e-01
    z[1,0,2]  R284      -7.4636816978454590e-01
    z[1,0,2]  R285      -7.1551853418350220e-01
    z[1,0,2]  R286      -1.7958484590053558e-01
    z[1,0,2]  R287      -3.6169543862342834e-01
    z[1,0,2]  R288      -5.7209855318069458e-01
    z[1,0,2]  R289      9.4921469688415527e-02
    z[1,0,2]  R290      4.8071792721748352e-01
    z[1,0,2]  R291      -0.515275239944458
    z[1,0,2]  R292      -2.7619307860732079e-02
    z[1,0,2]  R293      3.4795442223548889e-01
    z[1,0,2]  R294      -1.5366819500923157e-01
    z[1,0,2]  R295      -1.1325717717409134e-01
    z[1,0,2]  R296      2.0715330541133881e-01
    z[1,0,2]  R297      1.8174743652343750e-01
    z[1,0,2]  R298      9.6815852448344231e-03
    z[1,0,2]  R299      1.4354528486728668e-01
    z[1,0,2]  R300      -4.8036918044090271e-02
    z[1,0,2]  R301      0.524165689945221
    z[1,0,2]  R302      6.7092680931091309e-01
    z[1,0,2]  R303      5.9876251220703125e-01
    z[1,0,2]  R304      4.6418240666389465e-01
    z[1,0,2]  R305      -8.6913526058197021e-02
    z[1,0,2]  R306      6.2506929039955139e-02
    z[1,0,2]  R307      1.9782467186450958e-01
    z[1,0,2]  R308      -5.9149265289306641e-01
    z[1,0,2]  R309      -2.3733480274677277e-01
    z[1,0,2]  R310      -0.854716956615448
    z[1,0,2]  R311      -6.3081711530685425e-01
    z[1,0,2]  R312      5.0678193569183350e-01
    z[1,0,2]  R313      2.5052627921104431e-01
    z[1,0,2]  R314      -7.1417480707168579e-02
    z[1,0,2]  R315      4.8525348305702209e-01
    z[1,0,2]  R316      -8.4976166486740112e-01
    z[1,0,2]  R317      -4.9339225888252258e-01
    z[1,0,2]  R318      -6.9705766439437866e-01
    z[1,0,2]  R319      -6.1198842525482178e-01
    z[1,0,2]  R320      -7.8054195642471313e-01
    z[1,0,2]  R321      -5.7120490074157715e-01
    z[1,0,2]  R322      6.3946527242660522e-01
    z[1,0,2]  R323      -2.7680985629558563e-02
    z[1,0,2]  R324      -7.0935946702957153e-01
    z[1,0,2]  R325      -8.1507086753845215e-01
    z[1,0,2]  R326      -5.3898376226425171e-01
    z[1,0,2]  R327      -7.9467020928859711e-02
    z[1,0,2]  R328      -0.486939400434494
    z[1,0,2]  R329      6.3790476322174072e-01
    z[1,0,2]  R330      2.1087015047669411e-02
    z[1,0,2]  R331      1.9639053940773010e-01
    z[1,0,2]  R332      4.5591777563095093e-01
    z[1,0,2]  R333      8.5431921482086182e-01
    z[1,0,2]  R334      -0.84015291929245
    z[1,0,2]  R335      -6.8678051233291626e-01
    z[1,0,2]  R336      2.4733814597129822e-01
    z[1,0,2]  R337      -4.7133666276931763e-01
    z[1,0,2]  R338      -1.5307798981666565e-01
    z[1,0,2]  R339      -6.3151675462722778e-01
    z[1,0,2]  R340      -5.1250952482223511e-01
    z[1,0,2]  R341      -5.3278762102127075e-01
    z[1,0,2]  R342      -3.0677095055580139e-01
    z[1,0,2]  R343      -5.1467049121856689e-01
    z[1,0,2]  R344      -2.1590860188007355e-01
    z[1,0,2]  R345      -5.6937223672866821e-01
    z[1,0,2]  R346      -0.542125940322876
    z[1,0,2]  R347      -1.8518763780593872e-01
    z[1,0,2]  R348      -1.1581188440322876e-01
    z[1,0,2]  R349      -0.445984810590744
    z[1,0,2]  R350      -5.3687328100204468e-01
    z[1,0,2]  R351      -3.8116714358329773e-01
    z[1,0,2]  R352      -5.6777913123369217e-02
    z[1,0,2]  R353      1.0353393852710724e-01
    z[1,0,2]  R354      -3.2702925801277161e-01
    z[1,0,2]  R355      -1.2539622187614441e-01
    z[1,0,2]  R356      -2.3582690954208374e-01
    z[1,0,2]  R357      -3.1900930404663086e-01
    z[1,0,2]  R358      -2.7136135101318359e-01
    z[1,0,2]  R359      4.4235885143280029e-02
    z[1,0,2]  R360      3.3006185293197632e-01
    z[1,0,2]  R361      2.7378043532371521e-01
    z[1,0,2]  R362      2.8532043099403381e-01
    z[1,0,2]  R363      -1.7149317264556885e-01
    z[1,0,2]  R364      8.2180345058441162e-01
    z[1,0,2]  R365      -6.7168600857257843e-02
    z[1,0,2]  R366      -1.7426814138889313e-01
    z[1,0,2]  R367      1.7528069019317627e-01
    z[1,0,2]  R368      -1.4055498875677586e-02
    z[1,0,2]  R369      3.2149147987365723e-01
    z[1,0,2]  R370      8.6558210849761963e-01
    z[1,0,2]  R371      9.3931305408477783e-01
    z[1,0,2]  R372      7.3067253828048706e-01
    z[1,0,2]  R373      -2.2591440379619598e-01
    z[1,0,2]  R374      -1.5671806037425995e-01
    z[1,0,2]  R375      5.5256050825119019e-01
    z[1,0,2]  R376      0.467549592256546
    z[1,0,2]  R377      -3.3615368604660034e-01
    z[1,0,2]  R378      3.6083319783210754e-01
    z[1,0,2]  R379      6.0788080096244812e-02
    z[1,0,2]  R380      -1.4985999464988708e-01
    z[1,0,2]  R381      2.6378521323204041e-01
    z[1,0,2]  R382      -3.1577392946928740e-03
    z[1,0,2]  R383      -2.0002222061157227e-01
    z[1,0,2]  R384      2.6407885551452637e-01
    z[1,0,2]  R385      -2.5432729721069336e-01
    z[1,0,2]  R386      -3.1636923551559448e-01
    z[1,0,2]  R387      -2.6361331343650818e-01
    z[1,0,2]  R388      -1.0337930172681808e-01
    z[1,0,2]  R389      4.4319942593574524e-01
    z[1,0,2]  R390      3.6318498849868774e-01
    z[1,0,2]  R391      2.8820511698722839e-01
    z[1,0,2]  R392      -3.6796236038208008e-01
    z[1,0,2]  R393      2.7848687767982483e-01
    z[1,0,2]  R394      -3.0173275619745255e-02
    z[1,0,2]  R395      7.3003798723220825e-01
    z[1,0,2]  R396      -1.7617985606193542e-01
    z[1,0,2]  R397      -8.4466069936752319e-02
    z[1,0,2]  R398      1.8327631056308746e-01
    z[1,0,2]  R399      -6.3278481364250183e-02
    z[1,0,2]  R400      -1.6766825318336487e-01
    z[1,0,2]  R401      1.3303583860397339e-01
    z[1,0,2]  R402      2.4208576977252960e-01
    z[1,0,2]  R403      -0.179097518324852
    z[1,0,2]  R404      1.1233936063945293e-02
    z[1,0,2]  R405      4.3308448791503906e-01
    z[1,0,2]  R406      2.5103539228439331e-01
    z[1,0,2]  R407      4.5756268501281738e-01
    z[1,0,2]  R408      4.3825164437294006e-01
    z[1,0,2]  R409      0.348513126373291
    z[1,0,2]  R410      3.1630018353462219e-01
    z[1,0,2]  R411      -4.0792483091354370e-01
    z[1,0,2]  R412      -1.5815148130059242e-02
    z[1,0,2]  R413      1.3097250461578369e-01
    z[1,0,2]  R414      5.2823996543884277e-01
    z[1,0,2]  R415      -2.1121042966842651e-01
    z[1,0,2]  R416      -8.3415031433105469e-02
    z[1,0,2]  R417      -1.9119301438331604e-01
    z[1,0,2]  R418      5.0723668187856674e-02
    z[1,0,2]  R419      1.6085717082023621e-01
    z[1,0,2]  R420      8.1871229410171509e-01
    z[1,0,2]  R421      4.4781997799873352e-01
    z[1,0,2]  R422      -2.5352808833122253e-01
    z[1,0,2]  R423      1.1890961229801178e-01
    z[1,0,2]  R424      5.4404580593109131e-01
    z[1,0,2]  R425      2.9344305396080017e-01
    z[1,0,2]  R426      0.0649917870759964
    z[1,0,2]  R427      3.0003413558006287e-01
    z[1,0,2]  R428      5.0687056779861450e-01
    z[1,0,2]  R429      1.9926688075065613e-01
    z[1,0,2]  R430      2.7861837297677994e-02
    z[1,0,2]  R431      6.4635850489139557e-02
    z[1,0,2]  R432      -2.6343947649002075e-01
    z[1,0,2]  R433      7.1777254343032837e-02
    z[1,0,2]  R434      6.4623379707336426e-01
    z[1,0,2]  R435      4.6222358942031860e-01
    z[1,0,2]  R436      -0.252784788608551
    z[1,0,2]  R437      -1.6858577728271484e-01
    z[1,0,2]  R438      -2.5062909722328186e-01
    z[1,0,2]  R439      -0.354160875082016
    z[1,0,2]  R440      -1.4349471032619476e-01
    z[1,0,2]  R441      1.0102648288011551e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R264      -1
    z[1,0,3]  R265      1
    z[1,0,3]  R272      8.0558732151985168e-02
    z[1,0,3]  R273      1.0039541125297546e-01
    z[1,0,3]  R274      1.9324548542499542e-01
    z[1,0,3]  R275      3.8288459181785583e-01
    z[1,0,3]  R276      -4.8785403370857239e-02
    z[1,0,3]  R277      1.1430404335260391e-01
    z[1,0,3]  R278      1.4981566369533539e-01
    z[1,0,3]  R279      2.7314114570617676e-01
    z[1,0,3]  R280      6.9600507616996765e-02
    z[1,0,3]  R281      1.8743287026882172e-01
    z[1,0,3]  R282      0.0943765640258789
    z[1,0,3]  R283      2.7693882584571838e-01
    z[1,0,3]  R284      -2.2504374384880066e-01
    z[1,0,3]  R285      2.6922838762402534e-02
    z[1,0,3]  R286      1.7071780562400818e-01
    z[1,0,3]  R287      -0.51454758644104
    z[1,0,3]  R288      -1.6613106429576874e-01
    z[1,0,3]  R289      4.2972767353057861e-01
    z[1,0,3]  R290      -9.3862272799015045e-02
    z[1,0,3]  R291      -1.9204561412334442e-01
    z[1,0,3]  R292      4.3587011098861694e-01
    z[1,0,3]  R293      -4.2580872774124146e-01
    z[1,0,3]  R294      6.1133846640586853e-02
    z[1,0,3]  R295      3.4089264273643494e-01
    z[1,0,3]  R296      -4.1056537628173828e-01
    z[1,0,3]  R297      -3.5162556171417236e-01
    z[1,0,3]  R298      -2.5002938508987427e-01
    z[1,0,3]  R299      -1.5374928712844849e-01
    z[1,0,3]  R300      2.7975007891654968e-01
    z[1,0,3]  R301      2.9702642560005188e-01
    z[1,0,3]  R302      -3.8059610128402710e-01
    z[1,0,3]  R303      2.1868069469928741e-01
    z[1,0,3]  R304      5.3026580810546875e-01
    z[1,0,3]  R305      0.469642698764801
    z[1,0,3]  R306      3.5498702526092529e-01
    z[1,0,3]  R307      1.2456343322992325e-01
    z[1,0,3]  R308      -1.5270821750164032e-01
    z[1,0,3]  R309      -5.5474929511547089e-02
    z[1,0,3]  R310      2.1719707548618317e-01
    z[1,0,3]  R311      4.4158515334129333e-01
    z[1,0,3]  R312      -3.9123344421386719e-01
    z[1,0,3]  R313      1.8698923289775848e-01
    z[1,0,3]  R314      1.7250998318195343e-01
    z[1,0,3]  R315      -5.2650339901447296e-02
    z[1,0,3]  R316      -5.9175956994295120e-02
    z[1,0,3]  R317      -2.0117217674851418e-02
    z[1,0,3]  R318      -1.4995169825851917e-02
    z[1,0,3]  R319      -2.1370522677898407e-01
    z[1,0,3]  R320      2.4888768792152405e-01
    z[1,0,3]  R321      -1.7991498112678528e-01
    z[1,0,3]  R322      -3.0606150627136230e-01
    z[1,0,3]  R323      1.7265869677066803e-01
    z[1,0,3]  R324      -2.0424877107143402e-01
    z[1,0,3]  R325      2.1565240621566772e-01
    z[1,0,3]  R326      -0.337464839220047
    z[1,0,3]  R327      -2.5335872173309326e-01
    z[1,0,3]  R328      -6.1320036649703979e-01
    z[1,0,3]  R329      6.1767648905515671e-02
    z[1,0,3]  R330      -3.2199603319168091e-01
    z[1,0,3]  R331      -3.8293069601058960e-01
    z[1,0,3]  R332      1.2954463064670563e-01
    z[1,0,3]  R333      -1.9647832214832306e-01
    z[1,0,3]  R334      8.8400296866893768e-02
    z[1,0,3]  R335      -2.8740128874778748e-01
    z[1,0,3]  R336      -3.0023294687271118e-01
    z[1,0,3]  R337      -2.0498682558536530e-01
    z[1,0,3]  R338      -2.0276100933551788e-01
    z[1,0,3]  R339      -2.4268874526023865e-01
    z[1,0,3]  R340      4.5972842723131180e-02
    z[1,0,3]  R341      2.2287148237228394e-01
    z[1,0,3]  R342      0.0639379695057869
    z[1,0,3]  R343      -0.0262119323015213
    z[1,0,3]  R344      -0.391450971364975
    z[1,0,3]  R345      -5.5759406089782715e-01
    z[1,0,3]  R346      2.0403346419334412e-01
    z[1,0,3]  R347      -5.0263935327529907e-01
    z[1,0,3]  R348      -1.4866378903388977e-01
    z[1,0,3]  R349      -2.9711639881134033e-01
    z[1,0,3]  R350      -2.8054785728454590e-01
    z[1,0,3]  R351      -4.5000320672988892e-01
    z[1,0,3]  R352      -9.2928916215896606e-01
    z[1,0,3]  R353      -0.804606556892395
    z[1,0,3]  R354      -8.5726940631866455e-01
    z[1,0,3]  R355      -8.5723048448562622e-01
    z[1,0,3]  R356      -8.0125230550765991e-01
    z[1,0,3]  R357      -7.1358543634414673e-01
    z[1,0,3]  R358      -7.9580336809158325e-01
    z[1,0,3]  R359      -1.5711851418018341e-01
    z[1,0,3]  R360      -2.7160879969596863e-01
    z[1,0,3]  R361      -1.3891610503196716e-01
    z[1,0,3]  R362      3.8556548953056335e-01
    z[1,0,3]  R363      4.3534025549888611e-01
    z[1,0,3]  R364      1.7657354474067688e-01
    z[1,0,3]  R365      3.9180862903594971e-01
    z[1,0,3]  R366      2.4762172996997833e-01
    z[1,0,3]  R367      2.9850077629089355e-01
    z[1,0,3]  R368      5.1189678907394409e-01
    z[1,0,3]  R369      3.6862105131149292e-01
    z[1,0,3]  R370      2.1526399254798889e-01
    z[1,0,3]  R371      1.1522676795721054e-01
    z[1,0,3]  R372      4.4608378410339355e-01
    z[1,0,3]  R373      5.6817245483398438e-01
    z[1,0,3]  R374      2.0419143140316010e-01
    z[1,0,3]  R375      -2.1266290545463562e-01
    z[1,0,3]  R376      6.1207717657089233e-01
    z[1,0,3]  R377      2.3714180290699005e-01
    z[1,0,3]  R378      1.5064767003059387e-01
    z[1,0,3]  R379      3.3175039291381836e-01
    z[1,0,3]  R380      7.5979363918304443e-01
    z[1,0,3]  R381      6.5049648284912109e-01
    z[1,0,3]  R382      5.3698408603668213e-01
    z[1,0,3]  R383      4.9911034107208252e-01
    z[1,0,3]  R384      5.5468392372131348e-01
    z[1,0,3]  R385      5.2799969911575317e-01
    z[1,0,3]  R386      4.9183416366577148e-01
    z[1,0,3]  R387      -1.7968240380287170e-01
    z[1,0,3]  R388      5.0459164381027222e-01
    z[1,0,3]  R389      3.0800908803939819e-01
    z[1,0,3]  R390      6.0138350725173950e-01
    z[1,0,3]  R391      -2.4376663565635681e-01
    z[1,0,3]  R392      6.8626904487609863e-01
    z[1,0,3]  R393      -3.3575016260147095e-01
    z[1,0,3]  R394      6.3144260644912720e-01
    z[1,0,3]  R395      4.2121031880378723e-01
    z[1,0,3]  R396      5.6819815188646317e-02
    z[1,0,3]  R397      0.336073100566864
    z[1,0,3]  R398      1.5416452288627625e-01
    z[1,0,3]  R399      2.4057245254516602e-01
    z[1,0,3]  R400      1.6548976302146912e-01
    z[1,0,3]  R401      -9.2471368610858917e-02
    z[1,0,3]  R402      5.3288924694061279e-01
    z[1,0,3]  R403      -0.455875039100647
    z[1,0,3]  R404      -3.8344934582710266e-01
    z[1,0,3]  R405      0.614128053188324
    z[1,0,3]  R406      0.767065703868866
    z[1,0,3]  R407      3.5107195377349854e-01
    z[1,0,3]  R408      6.2618285417556763e-01
    z[1,0,3]  R409      -3.4679338335990906e-01
    z[1,0,3]  R410      5.5651229619979858e-01
    z[1,0,3]  R411      1.9736245274543762e-01
    z[1,0,3]  R412      -8.5408180952072144e-01
    z[1,0,3]  R413      -5.5037140846252441e-01
    z[1,0,3]  R414      -7.3549979925155640e-01
    z[1,0,3]  R415      -4.9482280015945435e-01
    z[1,0,3]  R416      6.7564916610717773e-01
    z[1,0,3]  R417      6.6907513141632080e-01
    z[1,0,3]  R418      8.2581186294555664e-01
    z[1,0,3]  R419      0.79014652967453
    z[1,0,3]  R420      1.7215198278427124e-01
    z[1,0,3]  R421      5.8378702402114868e-01
    z[1,0,3]  R422      -0.62684565782547
    z[1,0,3]  R423      0.827559769153595
    z[1,0,3]  R424      6.0564368963241577e-01
    z[1,0,3]  R425      6.2602764368057251e-01
    z[1,0,3]  R426      2.5464054942131042e-01
    z[1,0,3]  R427      4.9707618355751038e-01
    z[1,0,3]  R428      2.4635070562362671e-01
    z[1,0,3]  R429      7.9420171678066254e-03
    z[1,0,3]  R430      7.3591373860836029e-02
    z[1,0,3]  R431      -1.1864126473665237e-01
    z[1,0,3]  R432      7.1144467592239380e-01
    z[1,0,3]  R433      -6.2321805953979492e-01
    z[1,0,3]  R434      0.448964923620224
    z[1,0,3]  R435      1.6619957983493805e-01
    z[1,0,3]  R436      1.0466784238815308e-01
    z[1,0,3]  R437      1.7910125851631165e-01
    z[1,0,3]  R438      3.1129390001296997e-01
    z[1,0,3]  R439      2.0030494779348373e-02
    z[1,0,3]  R440      9.6967602148652077e-03
    z[1,0,3]  R441      2.0940619707107544e-01
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R266      -1
    z[1,0,4]  R267      1
    z[1,0,4]  R272      -1.1163435131311417e-01
    z[1,0,4]  R273      3.4751546382904053e-01
    z[1,0,4]  R274      0.395954966545105
    z[1,0,4]  R275      -7.0475861430168152e-02
    z[1,0,4]  R276      3.7594917416572571e-01
    z[1,0,4]  R277      -3.3839130401611328e-01
    z[1,0,4]  R278      7.7024394273757935e-01
    z[1,0,4]  R279      -3.0939653515815735e-01
    z[1,0,4]  R280      -5.1315951347351074e-01
    z[1,0,4]  R281      -5.5964458733797073e-02
    z[1,0,4]  R282      -2.9413056373596191e-01
    z[1,0,4]  R283      -3.6034524440765381e-01
    z[1,0,4]  R284      1.6683399677276611e-01
    z[1,0,4]  R285      8.0830223858356476e-02
    z[1,0,4]  R286      -5.3942567110061646e-01
    z[1,0,4]  R287      -2.0701089501380920e-01
    z[1,0,4]  R288      -1.9030489027500153e-01
    z[1,0,4]  R289      -1.8470701575279236e-01
    z[1,0,4]  R290      -2.5172075629234314e-01
    z[1,0,4]  R291      1.8056106567382812e-01
    z[1,0,4]  R292      -3.7811735272407532e-01
    z[1,0,4]  R293      1.2574869394302368e-01
    z[1,0,4]  R294      8.3340726792812347e-02
    z[1,0,4]  R295      1.8651063740253448e-01
    z[1,0,4]  R296      -2.3539149761199951e-01
    z[1,0,4]  R297      -4.7724953293800354e-01
    z[1,0,4]  R298      -2.5400611758232117e-01
    z[1,0,4]  R299      0.585501492023468
    z[1,0,4]  R300      5.8831650018692017e-01
    z[1,0,4]  R301      3.0771106481552124e-01
    z[1,0,4]  R302      7.4283942580223083e-02
    z[1,0,4]  R303      1.8063382804393768e-01
    z[1,0,4]  R304      2.4540023505687714e-01
    z[1,0,4]  R305      2.2678276896476746e-01
    z[1,0,4]  R306      -5.2724468708038330e-01
    z[1,0,4]  R307      1.2705012224614620e-02
    z[1,0,4]  R308      -3.0059751868247986e-01
    z[1,0,4]  R309      3.8329407572746277e-01
    z[1,0,4]  R310      -4.2918534018099308e-03
    z[1,0,4]  R311      -2.0145541429519653e-01
    z[1,0,4]  R312      3.8457381725311279e-01
    z[1,0,4]  R313      -8.0744408071041107e-02
    z[1,0,4]  R314      -1.4044919610023499e-01
    z[1,0,4]  R315      -3.9815533906221390e-02
    z[1,0,4]  R316      -2.3382633924484253e-01
    z[1,0,4]  R317      -6.2321889400482178e-01
    z[1,0,4]  R318      -5.3854364156723022e-01
    z[1,0,4]  R319      -3.1705516576766968e-01
    z[1,0,4]  R320      3.6146484781056643e-03
    z[1,0,4]  R321      -2.3531749844551086e-01
    z[1,0,4]  R322      4.9750307202339172e-01
    z[1,0,4]  R323      5.4032534360885620e-01
    z[1,0,4]  R324      -4.1118609905242920e-01
    z[1,0,4]  R325      -2.6080089807510376e-01
    z[1,0,4]  R326      2.1534284949302673e-01
    z[1,0,4]  R327      1.9201648235321045e-01
    z[1,0,4]  R328      0.273902952671051
    z[1,0,4]  R329      5.1875393837690353e-02
    z[1,0,4]  R330      -3.1416463851928711e-01
    z[1,0,4]  R331      -4.7365394234657288e-01
    z[1,0,4]  R332      3.5780209302902222e-01
    z[1,0,4]  R333      2.7632737159729004e-01
    z[1,0,4]  R334      -2.4677792191505432e-01
    z[1,0,4]  R335      -2.3934873938560486e-01
    z[1,0,4]  R336      -2.8821733593940735e-01
    z[1,0,4]  R337      1.6172325611114502e-01
    z[1,0,4]  R338      9.7935229539871216e-02
    z[1,0,4]  R339      2.8338557481765747e-01
    z[1,0,4]  R340      -2.0178347826004028e-01
    z[1,0,4]  R341      -6.7096483707427979e-01
    z[1,0,4]  R342      -3.3685117959976196e-01
    z[1,0,4]  R343      -4.3128201365470886e-01
    z[1,0,4]  R344      2.8159880638122559e-01
    z[1,0,4]  R345      3.0252316594123840e-01
    z[1,0,4]  R346      -6.7659044265747070e-01
    z[1,0,4]  R347      -1.1162239313125610e-01
    z[1,0,4]  R348      -2.2105583921074867e-02
    z[1,0,4]  R349      -3.5612594336271286e-02
    z[1,0,4]  R350      -1.1146171391010284e-01
    z[1,0,4]  R351      8.9615978300571442e-02
    z[1,0,4]  R352      2.9850891232490540e-01
    z[1,0,4]  R353      1.0379948467016220e-01
    z[1,0,4]  R354      6.7134196870028973e-03
    z[1,0,4]  R355      -2.4092530831694603e-02
    z[1,0,4]  R356      3.4442999958992004e-01
    z[1,0,4]  R357      -5.1885211467742920e-01
    z[1,0,4]  R358      3.5841333866119385e-01
    z[1,0,4]  R359      -4.1127124428749084e-01
    z[1,0,4]  R360      8.8618598878383636e-02
    z[1,0,4]  R361      2.2265779972076416e-01
    z[1,0,4]  R362      -4.9502938985824585e-01
    z[1,0,4]  R363      -8.5293418169021606e-01
    z[1,0,4]  R364      3.3291608095169067e-01
    z[1,0,4]  R365      -7.1162384748458862e-01
    z[1,0,4]  R366      -7.4344772100448608e-01
    z[1,0,4]  R367      -7.7911502122879028e-01
    z[1,0,4]  R368      -0.671019434928894
    z[1,0,4]  R369      -8.1939530372619629e-01
    z[1,0,4]  R370      2.0195983350276947e-01
    z[1,0,4]  R371      2.0293138921260834e-01
    z[1,0,4]  R372      4.4607225060462952e-01
    z[1,0,4]  R373      -4.4644799828529358e-01
    z[1,0,4]  R374      8.7363161146640778e-03
    z[1,0,4]  R375      3.6340811848640442e-01
    z[1,0,4]  R376      -2.9440057277679443e-01
    z[1,0,4]  R377      -3.7326484918594360e-01
    z[1,0,4]  R378      2.4924322962760925e-01
    z[1,0,4]  R379      3.0503988265991211e-01
    z[1,0,4]  R380      -7.0223741233348846e-02
    z[1,0,4]  R381      -1.9835433363914490e-01
    z[1,0,4]  R382      -7.0246893167495728e-01
    z[1,0,4]  R383      -0.702630341053009
    z[1,0,4]  R384      0.272499144077301
    z[1,0,4]  R385      -6.6848033666610718e-01
    z[1,0,4]  R386      -5.1927280426025391e-01
    z[1,0,4]  R387      -0.247806116938591
    z[1,0,4]  R388      -3.1744873523712158e-01
    z[1,0,4]  R389      -6.3552063703536987e-01
    z[1,0,4]  R390      -4.9319875240325928e-01
    z[1,0,4]  R391      -4.1530814766883850e-01
    z[1,0,4]  R392      -5.6754702329635620e-01
    z[1,0,4]  R393      2.3077231645584106e-01
    z[1,0,4]  R394      -4.7983753681182861e-01
    z[1,0,4]  R395      3.4534502029418945e-01
    z[1,0,4]  R396      4.1923069953918457e-01
    z[1,0,4]  R397      4.8716527223587036e-01
    z[1,0,4]  R398      4.9648800492286682e-01
    z[1,0,4]  R399      -1.5960346907377243e-02
    z[1,0,4]  R400      -6.6549576818943024e-02
    z[1,0,4]  R401      -1.2255188077688217e-01
    z[1,0,4]  R402      -6.6290569305419922e-01
    z[1,0,4]  R403      -3.7945404648780823e-01
    z[1,0,4]  R404      2.0986701548099518e-01
    z[1,0,4]  R405      2.1012732386589050e-01
    z[1,0,4]  R406      -0.489188551902771
    z[1,0,4]  R407      -3.6255702376365662e-02
    z[1,0,4]  R408      -5.0594764947891235e-01
    z[1,0,4]  R409      -3.7479439377784729e-01
    z[1,0,4]  R410      -4.5726552605628967e-01
    z[1,0,4]  R411      2.2959679365158081e-01
    z[1,0,4]  R412      -3.2122680544853210e-01
    z[1,0,4]  R413      -1.9119140505790710e-01
    z[1,0,4]  R414      -1.7439144849777222e-01
    z[1,0,4]  R415      -4.4242069125175476e-01
    z[1,0,4]  R416      -4.1691732406616211e-01
    z[1,0,4]  R417      -5.6202590465545654e-01
    z[1,0,4]  R418      -0.505794107913971
    z[1,0,4]  R419      -3.8944569230079651e-01
    z[1,0,4]  R420      2.2215992212295532e-01
    z[1,0,4]  R421      2.6274007558822632e-01
    z[1,0,4]  R422      -4.0438213944435120e-01
    z[1,0,4]  R423      -5.2583914995193481e-01
    z[1,0,4]  R424      2.2356854379177094e-01
    z[1,0,4]  R425      -4.9322238564491272e-01
    z[1,0,4]  R426      -8.0460679531097412e-01
    z[1,0,4]  R427      1.6704671084880829e-01
    z[1,0,4]  R428      -2.9823830351233482e-02
    z[1,0,4]  R429      4.2493402957916260e-01
    z[1,0,4]  R430      2.2571101784706116e-01
    z[1,0,4]  R431      1.7069098353385925e-01
    z[1,0,4]  R432      -5.4182070493698120e-01
    z[1,0,4]  R433      2.2802498936653137e-01
    z[1,0,4]  R434      1.1553851515054703e-01
    z[1,0,4]  R435      3.4038805961608887e-01
    z[1,0,4]  R436      -4.0117930620908737e-02
    z[1,0,4]  R437      -2.6049926877021790e-02
    z[1,0,4]  R438      1.1090749502182007e-01
    z[1,0,4]  R439      -3.5114653408527374e-02
    z[1,0,4]  R440      6.0660088062286377e-01
    z[1,0,4]  R441      6.9004237651824951e-02
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R268      -1
    z[1,0,5]  R269      1
    z[1,0,5]  R272      -1.3124023377895355e-01
    z[1,0,5]  R273      -2.8038018941879272e-01
    z[1,0,5]  R274      7.5025603175163269e-02
    z[1,0,5]  R275      -3.6038011312484741e-01
    z[1,0,5]  R276      2.1793329715728760e-01
    z[1,0,5]  R277      0.327493280172348
    z[1,0,5]  R278      4.5138490386307240e-03
    z[1,0,5]  R279      -1.6327352821826935e-01
    z[1,0,5]  R280      1.4789652824401855e-01
    z[1,0,5]  R281      -3.5024428367614746e-01
    z[1,0,5]  R282      -8.0627001821994781e-02
    z[1,0,5]  R283      1.1245064437389374e-01
    z[1,0,5]  R284      -2.2123867273330688e-01
    z[1,0,5]  R285      4.2015653848648071e-01
    z[1,0,5]  R286      -2.4561443924903870e-01
    z[1,0,5]  R287      1.3122916221618652e-01
    z[1,0,5]  R288      2.1605223417282104e-02
    z[1,0,5]  R289      6.8585580587387085e-01
    z[1,0,5]  R290      -6.3566464185714722e-01
    z[1,0,5]  R291      1.0161749273538589e-01
    z[1,0,5]  R292      3.2601559162139893e-01
    z[1,0,5]  R293      2.3436428979039192e-02
    z[1,0,5]  R294      -4.8586927354335785e-02
    z[1,0,5]  R295      4.8255950212478638e-01
    z[1,0,5]  R296      1.6032800078392029e-01
    z[1,0,5]  R297      1.6008377075195312e-01
    z[1,0,5]  R298      4.6952900290489197e-01
    z[1,0,5]  R299      2.7046111226081848e-01
    z[1,0,5]  R300      -9.7774252295494080e-02
    z[1,0,5]  R301      -2.4051584303379059e-01
    z[1,0,5]  R302      -1.6773492097854614e-01
    z[1,0,5]  R303      3.0281695723533630e-01
    z[1,0,5]  R304      5.0691539049148560e-01
    z[1,0,5]  R305      -3.0283734202384949e-01
    z[1,0,5]  R306      -2.0944355428218842e-01
    z[1,0,5]  R307      4.4047471880912781e-01
    z[1,0,5]  R308      -5.1340639591217041e-02
    z[1,0,5]  R309      -4.2167093604803085e-02
    z[1,0,5]  R310      -1.0983082652091980e-01
    z[1,0,5]  R311      2.0590883493423462e-01
    z[1,0,5]  R312      1.8038934469223022e-01
    z[1,0,5]  R313      1.9750857353210449e-01
    z[1,0,5]  R314      -2.5759214162826538e-01
    z[1,0,5]  R315      1.0314231365919113e-01
    z[1,0,5]  R316      -2.3229399323463440e-01
    z[1,0,5]  R317      1.4108738303184509e-01
    z[1,0,5]  R318      -1.6553550958633423e-01
    z[1,0,5]  R319      3.3517107367515564e-01
    z[1,0,5]  R320      -6.1202347278594971e-02
    z[1,0,5]  R321      -2.1936956793069839e-02
    z[1,0,5]  R322      1.5046262741088867e-01
    z[1,0,5]  R323      -1.9028775393962860e-01
    z[1,0,5]  R324      -3.2681442797183990e-02
    z[1,0,5]  R325      -1.0058090090751648e-01
    z[1,0,5]  R326      2.3878295719623566e-01
    z[1,0,5]  R327      5.3994023799896240e-01
    z[1,0,5]  R328      -1.7359418561682105e-03
    z[1,0,5]  R329      -0.302208811044693
    z[1,0,5]  R330      -5.0271379947662354e-01
    z[1,0,5]  R331      -4.7846382856369019e-01
    z[1,0,5]  R332      -3.9522830396890640e-02
    z[1,0,5]  R333      1.5944422781467438e-01
    z[1,0,5]  R334      -1.1943912133574486e-02
    z[1,0,5]  R335      -4.6248380094766617e-02
    z[1,0,5]  R336      -2.5208237767219543e-01
    z[1,0,5]  R337      1.9102320075035095e-01
    z[1,0,5]  R338      7.8355357050895691e-02
    z[1,0,5]  R339      2.8564539551734924e-01
    z[1,0,5]  R340      4.2012757062911987e-01
    z[1,0,5]  R341      -4.8686340451240540e-02
    z[1,0,5]  R342      1.3680109381675720e-01
    z[1,0,5]  R343      3.5877469182014465e-01
    z[1,0,5]  R344      4.1626819968223572e-01
    z[1,0,5]  R345      -1.2600140273571014e-01
    z[1,0,5]  R346      3.3882644027471542e-02
    z[1,0,5]  R347      -0.522332489490509
    z[1,0,5]  R348      -6.4811789989471436e-01
    z[1,0,5]  R349      3.1140094995498657e-01
    z[1,0,5]  R350      -1.1855640262365341e-01
    z[1,0,5]  R351      1.4906461536884308e-01
    z[1,0,5]  R352      -2.7762185782194138e-02
    z[1,0,5]  R353      -4.2355707287788391e-01
    z[1,0,5]  R354      -2.8850415349006653e-01
    z[1,0,5]  R355      8.6988382041454315e-02
    z[1,0,5]  R356      4.0703356266021729e-02
    z[1,0,5]  R357      3.9076272398233414e-02
    z[1,0,5]  R358      1.0142208635807037e-01
    z[1,0,5]  R359      -6.7737591266632080e-01
    z[1,0,5]  R360      -5.8848005533218384e-01
    z[1,0,5]  R361      4.9932379275560379e-02
    z[1,0,5]  R362      3.2726475596427917e-01
    z[1,0,5]  R363      8.3617325872182846e-03
    z[1,0,5]  R364      1.6888137161731720e-01
    z[1,0,5]  R365      3.5665473341941833e-01
    z[1,0,5]  R366      4.9061697721481323e-01
    z[1,0,5]  R367      3.3408010005950928e-01
    z[1,0,5]  R368      1.5271255373954773e-01
    z[1,0,5]  R369      1.5786384046077728e-01
    z[1,0,5]  R370      9.0284220874309540e-02
    z[1,0,5]  R371      9.1893002390861511e-02
    z[1,0,5]  R372      1.6373126208782196e-01
    z[1,0,5]  R373      -5.2146852016448975e-02
    z[1,0,5]  R374      4.7652739286422729e-01
    z[1,0,5]  R375      2.7792543172836304e-01
    z[1,0,5]  R376      3.6418086290359497e-01
    z[1,0,5]  R377      4.4458580017089844e-01
    z[1,0,5]  R378      8.2012486457824707e-01
    z[1,0,5]  R379      -1.5312202274799347e-01
    z[1,0,5]  R380      5.3218954801559448e-01
    z[1,0,5]  R381      3.9623332023620605e-01
    z[1,0,5]  R382      0.326760470867157
    z[1,0,5]  R383      1.3923436403274536e-01
    z[1,0,5]  R384      5.7900595664978027e-01
    z[1,0,5]  R385      4.2071428894996643e-01
    z[1,0,5]  R386      5.3725987672805786e-01
    z[1,0,5]  R387      -5.8837610483169556e-01
    z[1,0,5]  R388      5.7882612943649292e-01
    z[1,0,5]  R389      2.9531732201576233e-01
    z[1,0,5]  R390      -2.9737564921379089e-01
    z[1,0,5]  R391      7.7173076570034027e-02
    z[1,0,5]  R392      1.9338364899158478e-01
    z[1,0,5]  R393      -1.0505378013476729e-03
    z[1,0,5]  R394      4.4149649143218994e-01
    z[1,0,5]  R395      2.2492264211177826e-01
    z[1,0,5]  R396      -5.8490353822708130e-01
    z[1,0,5]  R397      6.3682332634925842e-02
    z[1,0,5]  R398      -3.8847097754478455e-01
    z[1,0,5]  R399      -5.6462105363607407e-02
    z[1,0,5]  R400      2.9099500179290771e-01
    z[1,0,5]  R401      6.9737970829010010e-02
    z[1,0,5]  R402      2.2050644457340240e-01
    z[1,0,5]  R403      3.4751009941101074e-01
    z[1,0,5]  R404      -6.1318314075469971e-01
    z[1,0,5]  R405      4.1727980971336365e-01
    z[1,0,5]  R406      1.9269576296210289e-02
    z[1,0,5]  R407      5.6343454122543335e-01
    z[1,0,5]  R408      -2.2268386185169220e-01
    z[1,0,5]  R409      1.2859074771404266e-01
    z[1,0,5]  R410      -4.2583969235420227e-01
    z[1,0,5]  R411      -2.5887307524681091e-01
    z[1,0,5]  R412      -5.3237382322549820e-02
    z[1,0,5]  R413      5.8502310514450073e-01
    z[1,0,5]  R414      1.9193184375762939e-01
    z[1,0,5]  R415      1.0772937536239624e-01
    z[1,0,5]  R416      3.7983378767967224e-01
    z[1,0,5]  R417      -2.5783991813659668e-01
    z[1,0,5]  R418      -9.3516901135444641e-02
    z[1,0,5]  R419      -2.3123618960380554e-01
    z[1,0,5]  R420      4.2595624923706055e-01
    z[1,0,5]  R421      -1.4268389344215393e-01
    z[1,0,5]  R422      0.0777122750878334
    z[1,0,5]  R423      -5.3333669900894165e-02
    z[1,0,5]  R424      1.9997552037239075e-01
    z[1,0,5]  R425      4.8900499939918518e-01
    z[1,0,5]  R426      4.7088339924812317e-01
    z[1,0,5]  R427      6.0139906406402588e-01
    z[1,0,5]  R428      5.2955496311187744e-01
    z[1,0,5]  R429      -1.8144200742244720e-01
    z[1,0,5]  R430      1.1370515823364258e-01
    z[1,0,5]  R431      -4.7502916306257248e-02
    z[1,0,5]  R432      -9.1118104755878448e-02
    z[1,0,5]  R433      7.1925801038742065e-01
    z[1,0,5]  R434      4.3071508407592773e-01
    z[1,0,5]  R435      6.1889731884002686e-01
    z[1,0,5]  R436      2.2198554128408432e-02
    z[1,0,5]  R437      -1.8600904941558838e-01
    z[1,0,5]  R438      -1.1791043728590012e-01
    z[1,0,5]  R439      -2.7503988146781921e-01
    z[1,0,5]  R440      -6.9555658102035522e-01
    z[1,0,5]  R441      -2.5169846415519714e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R270      -1
    z[1,0,6]  R271      1
    z[1,0,6]  R272      1.2716157734394073e-01
    z[1,0,6]  R273      1.5073044598102570e-01
    z[1,0,6]  R274      2.1515524387359619e-01
    z[1,0,6]  R275      1.2325572315603495e-03
    z[1,0,6]  R276      3.8559707999229431e-01
    z[1,0,6]  R277      2.1913446485996246e-01
    z[1,0,6]  R278      8.5130125284194946e-02
    z[1,0,6]  R279      -9.3266211450099945e-02
    z[1,0,6]  R280      -1.9759789574891329e-03
    z[1,0,6]  R281      3.5060763359069824e-01
    z[1,0,6]  R282      4.9979421496391296e-01
    z[1,0,6]  R283      4.5782285928726196e-01
    z[1,0,6]  R284      0.186710387468338
    z[1,0,6]  R285      -3.7591807544231415e-02
    z[1,0,6]  R286      1.7357769608497620e-01
    z[1,0,6]  R287      3.3277422189712524e-01
    z[1,0,6]  R288      5.0272655487060547e-01
    z[1,0,6]  R289      1.0680851340293884e-01
    z[1,0,6]  R290      1.3413478434085846e-01
    z[1,0,6]  R291      7.2482489049434662e-03
    z[1,0,6]  R292      -3.0580368638038635e-01
    z[1,0,6]  R293      1.3495469093322754e-01
    z[1,0,6]  R294      4.1644933819770813e-01
    z[1,0,6]  R295      -1.4860205352306366e-02
    z[1,0,6]  R296      4.7997146844863892e-02
    z[1,0,6]  R297      1.3998521491885185e-02
    z[1,0,6]  R298      -6.0403626412153244e-03
    z[1,0,6]  R299      1.2651675939559937e-01
    z[1,0,6]  R300      2.2318558394908905e-01
    z[1,0,6]  R301      0.195567324757576
    z[1,0,6]  R302      -3.5780292749404907e-01
    z[1,0,6]  R303      -4.9721777439117432e-01
    z[1,0,6]  R304      -1.5979675948619843e-01
    z[1,0,6]  R305      9.8930552601814270e-02
    z[1,0,6]  R306      5.7686984539031982e-02
    z[1,0,6]  R307      6.6268257796764374e-02
    z[1,0,6]  R308      -1.2977904640138149e-02
    z[1,0,6]  R309      1.9720393419265747e-01
    z[1,0,6]  R310      -2.4530166760087013e-02
    z[1,0,6]  R311      2.0649281144142151e-01
    z[1,0,6]  R312      -9.3907155096530914e-02
    z[1,0,6]  R313      -1.4130038209259510e-02
    z[1,0,6]  R314      1.2083718320354819e-03
    z[1,0,6]  R315      -6.6228836774826050e-01
    z[1,0,6]  R316      -2.2472234442830086e-02
    z[1,0,6]  R317      -8.8884793221950531e-02
    z[1,0,6]  R318      -3.1703668832778931e-01
    z[1,0,6]  R319      -1.5562385320663452e-01
    z[1,0,6]  R320      3.9094823598861694e-01
    z[1,0,6]  R321      4.9489045143127441e-01
    z[1,0,6]  R322      -8.4049604833126068e-02
    z[1,0,6]  R323      1.0578565299510956e-01
    z[1,0,6]  R324      -7.1422919631004333e-02
    z[1,0,6]  R325      -2.7642959356307983e-01
    z[1,0,6]  R326      2.4088962376117706e-01
    z[1,0,6]  R327      3.9835140109062195e-01
    z[1,0,6]  R328      2.0724989473819733e-02
    z[1,0,6]  R329      1.6438685357570648e-01
    z[1,0,6]  R330      -0.330636590719223
    z[1,0,6]  R331      0.138252854347229
    z[1,0,6]  R332      -5.0750296562910080e-02
    z[1,0,6]  R333      -2.4333896115422249e-02
    z[1,0,6]  R334      -1.4620308578014374e-01
    z[1,0,6]  R335      1.5129800140857697e-01
    z[1,0,6]  R336      1.7641171813011169e-01
    z[1,0,6]  R337      3.0636507272720337e-01
    z[1,0,6]  R338      5.7734644412994385e-01
    z[1,0,6]  R339      -1.0565790534019470e-01
    z[1,0,6]  R340      3.5000890493392944e-01
    z[1,0,6]  R341      2.9473862051963806e-01
    z[1,0,6]  R342      -4.0086947381496429e-02
    z[1,0,6]  R343      -8.2158427685499191e-03
    z[1,0,6]  R344      1.2432643026113510e-01
    z[1,0,6]  R345      4.1455402970314026e-03
    z[1,0,6]  R346      2.3970237374305725e-01
    z[1,0,6]  R347      -1.8729726970195770e-01
    z[1,0,6]  R348      4.3650665879249573e-01
    z[1,0,6]  R349      -5.9363774955272675e-02
    z[1,0,6]  R350      -8.5072867572307587e-02
    z[1,0,6]  R351      1.4224433898925781e-01
    z[1,0,6]  R352      1.9107328355312347e-01
    z[1,0,6]  R353      3.0165421962738037e-01
    z[1,0,6]  R354      1.3045558333396912e-01
    z[1,0,6]  R355      2.6932266354560852e-01
    z[1,0,6]  R356      -2.1146193146705627e-01
    z[1,0,6]  R357      2.8522223234176636e-01
    z[1,0,6]  R358      -2.6264557242393494e-01
    z[1,0,6]  R359      -5.1534049212932587e-02
    z[1,0,6]  R360      -2.6396539807319641e-01
    z[1,0,6]  R361      5.9392873197793961e-02
    z[1,0,6]  R362      6.3238894939422607e-01
    z[1,0,6]  R363      4.8657186329364777e-02
    z[1,0,6]  R364      2.2225466370582581e-01
    z[1,0,6]  R365      2.6226265355944633e-02
    z[1,0,6]  R366      -8.5489697754383087e-02
    z[1,0,6]  R367      1.1524365842342377e-01
    z[1,0,6]  R368      -6.0925945639610291e-02
    z[1,0,6]  R369      2.4047592282295227e-01
    z[1,0,6]  R370      2.7839845418930054e-01
    z[1,0,6]  R371      1.4632443897426128e-02
    z[1,0,6]  R372      -1.9516487419605255e-01
    z[1,0,6]  R373      3.6841621994972229e-01
    z[1,0,6]  R374      -1.7419892549514771e-01
    z[1,0,6]  R375      -1.0508665442466736e-01
    z[1,0,6]  R376      2.1887370944023132e-01
    z[1,0,6]  R377      4.9801462888717651e-01
    z[1,0,6]  R378      -2.0023313164710999e-01
    z[1,0,6]  R379      4.2687371373176575e-02
    z[1,0,6]  R380      -1.7269712686538696e-01
    z[1,0,6]  R381      2.5844737887382507e-01
    z[1,0,6]  R382      2.2752356529235840e-01
    z[1,0,6]  R383      3.2015082240104675e-01
    z[1,0,6]  R384      -3.0852247029542923e-02
    z[1,0,6]  R385      -1.4967158436775208e-01
    z[1,0,6]  R386      1.0632573813199997e-01
    z[1,0,6]  R387      -2.5837266445159912e-01
    z[1,0,6]  R388      1.5754364430904388e-01
    z[1,0,6]  R389      2.8766760230064392e-01
    z[1,0,6]  R390      1.4787826687097549e-02
    z[1,0,6]  R391      -3.1033328175544739e-01
    z[1,0,6]  R392      -1.5594394505023956e-01
    z[1,0,6]  R393      -2.1786347031593323e-01
    z[1,0,6]  R394      4.2473133653402328e-03
    z[1,0,6]  R395      5.7245563715696335e-02
    z[1,0,6]  R396      2.0748578011989594e-01
    z[1,0,6]  R397      9.0484723448753357e-02
    z[1,0,6]  R398      3.7761884927749634e-01
    z[1,0,6]  R399      1.8649470806121826e-01
    z[1,0,6]  R400      3.0846813693642616e-02
    z[1,0,6]  R401      -3.6305539309978485e-02
    z[1,0,6]  R402      1.4598475396633148e-01
    z[1,0,6]  R403      -4.3949750065803528e-01
    z[1,0,6]  R404      -3.2506820559501648e-01
    z[1,0,6]  R405      4.5821475982666016e-01
    z[1,0,6]  R406      -2.0079061388969421e-01
    z[1,0,6]  R407      2.7436956763267517e-01
    z[1,0,6]  R408      3.0983682721853256e-02
    z[1,0,6]  R409      -2.7007344365119934e-01
    z[1,0,6]  R410      4.2271953821182251e-01
    z[1,0,6]  R411      -2.1987275779247284e-01
    z[1,0,6]  R412      1.7963241040706635e-01
    z[1,0,6]  R413      -2.9832735657691956e-01
    z[1,0,6]  R414      0.0983017086982727
    z[1,0,6]  R415      -3.1668996810913086e-01
    z[1,0,6]  R416      1.5204668045043945e-01
    z[1,0,6]  R417      1.3626010715961456e-01
    z[1,0,6]  R418      -5.1867388188838959e-02
    z[1,0,6]  R419      2.4919275939464569e-01
    z[1,0,6]  R420      -8.0029524862766266e-02
    z[1,0,6]  R421      -6.3693143427371979e-02
    z[1,0,6]  R422      -2.0735444128513336e-01
    z[1,0,6]  R423      -6.4610382542014122e-03
    z[1,0,6]  R424      3.9105647802352905e-01
    z[1,0,6]  R425      -9.8922356963157654e-02
    z[1,0,6]  R426      -7.9763151705265045e-02
    z[1,0,6]  R427      -4.5124265551567078e-01
    z[1,0,6]  R428      2.8198403120040894e-01
    z[1,0,6]  R429      2.2629508748650551e-02
    z[1,0,6]  R430      2.7077522128820419e-02
    z[1,0,6]  R431      2.3101305961608887e-01
    z[1,0,6]  R432      0.200897216796875
    z[1,0,6]  R433      -1.4587773382663727e-01
    z[1,0,6]  R434      -2.3490564525127411e-01
    z[1,0,6]  R435      3.2156085968017578e-01
    z[1,0,6]  R436      -1.8251250684261322e-01
    z[1,0,6]  R437      1.9953005015850067e-01
    z[1,0,6]  R438      -6.6221915185451508e-02
    z[1,0,6]  R439      8.4433071315288544e-02
    z[1,0,6]  R440      0.0134742995724082
    z[1,0,6]  R441      -2.3847445845603943e-01
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R442      -1
    z[0,4,0]  R443      1
    z[0,4,0]  R456      -6.4063489437103271e-02
    z[0,4,0]  R457      1.6059769690036774e-01
    z[0,4,0]  R458      1.3274246454238892e-01
    z[0,4,0]  R459      6.3208468258380890e-02
    z[0,4,0]  R460      1.0475829988718033e-01
    z[0,4,0]  R461      1.5666396915912628e-01
    z[0,4,0]  R462      2.4719725549221039e-01
    z[0,4,0]  R463      5.6741088628768921e-01
    z[0,4,0]  R464      5.1577204465866089e-01
    z[0,4,0]  R465      -6.9601279497146606e-01
    z[0,4,0]  R466      -1.3350605964660645e-01
    z[0,4,0]  R467      1.7930482327938080e-01
    z[0,4,0]  R468      -2.8537398576736450e-01
    z[0,4,0]  R469      1.6607774794101715e-01
    z[0,4,0]  R470      5.1720064133405685e-02
    z[0,4,0]  R471      -8.3205364644527435e-03
    z[0,4,0]  R472      4.0531735867261887e-02
    z[0,4,0]  R473      7.2678372263908386e-02
    z[0,4,0]  R474      0.260046124458313
    z[0,4,0]  R475      1.3106101751327515e-01
    z[0,4,0]  R476      -3.5949856042861938e-02
    z[0,4,0]  R477      2.7664564549922943e-02
    z[0,4,0]  R478      7.8953303396701813e-02
    z[0,4,0]  R479      1.5168353915214539e-01
    z[0,4,0]  R480      -3.3841833472251892e-01
    z[0,4,0]  R481      -2.2327479720115662e-01
    z[0,4,0]  R482      -2.6558920741081238e-01
    z[0,4,0]  R483      1.4662556350231171e-02
    z[0,4,0]  R484      -0.260986864566803
    z[0,4,0]  R485      -3.6370101571083069e-01
    z[0,4,0]  R486      3.5187106579542160e-02
    z[0,4,0]  R487      -1.2392750382423401e-01
    z[0,4,0]  R488      -4.5920538902282715e-01
    z[0,4,0]  R489      0.0667165070772171
    z[0,4,0]  R490      -2.9462891817092896e-01
    z[0,4,0]  R491      0.644294261932373
    z[0,4,0]  R492      -4.7134527564048767e-01
    z[0,4,0]  R493      2.8061863034963608e-02
    z[0,4,0]  R494      3.2971829175949097e-01
    z[0,4,0]  R495      6.9544982910156250e-01
    z[0,4,0]  R496      8.0374181270599365e-02
    z[0,4,0]  R497      4.4361403584480286e-01
    z[0,4,0]  R498      -2.3828917741775513e-01
    z[0,4,0]  R499      3.4130752086639404e-01
    z[0,4,0]  R500      -4.8296146094799042e-02
    z[0,4,0]  R501      -2.8567740321159363e-01
    z[0,4,0]  R502      -3.0408853292465210e-01
    z[0,4,0]  R503      7.3413014411926270e-01
    z[0,4,0]  R504      0.762452244758606
    z[0,4,0]  R505      -1.3330757617950439e-01
    z[0,4,0]  R506      0.0967952162027359
    z[0,4,0]  R507      5.4665857553482056e-01
    z[0,4,0]  R508      5.7045292854309082e-01
    z[0,4,0]  R509      4.8920072615146637e-02
    z[0,4,0]  R510      2.1173666417598724e-01
    z[0,4,0]  R511      4.0548691153526306e-01
    z[0,4,0]  R512      1.5091603994369507e-01
    z[0,4,0]  R513      6.5789061784744263e-01
    z[0,4,0]  R514      -4.8623021692037582e-02
    z[0,4,0]  R515      2.5142499804496765e-01
    z[0,4,0]  R516      1.9243241846561432e-01
    z[0,4,0]  R517      3.9235064387321472e-01
    z[0,4,0]  R518      2.9140564799308777e-01
    z[0,4,0]  R519      6.2068152427673340e-01
    z[0,4,0]  R520      -3.7842559814453125e-01
    z[0,4,0]  R521      1.0778354853391647e-01
    z[0,4,0]  R522      4.9369942396879196e-02
    z[0,4,0]  R523      -6.9795258343219757e-02
    z[0,4,0]  R524      -1.4652828872203827e-01
    z[0,4,0]  R525      0.0670105367898941
    z[0,4,0]  R526      0.550288736820221
    z[0,4,0]  R527      3.2825458794832230e-02
    z[0,4,0]  R528      -2.2199097275733948e-01
    z[0,4,0]  R529      -3.4488037228584290e-02
    z[0,4,0]  R530      1.8360415101051331e-01
    z[0,4,0]  R531      1.9765444099903107e-01
    z[0,4,0]  R532      -4.3908235430717468e-01
    z[0,4,0]  R533      -6.3887882232666016e-01
    z[0,4,0]  R534      -4.3565583229064941e-01
    z[0,4,0]  R535      -4.5687532424926758e-01
    z[0,4,0]  R536      0.084299735724926
    z[0,4,0]  R537      -4.7861550003290176e-02
    z[0,4,0]  R538      3.4174117445945740e-01
    z[0,4,0]  R539      -3.4983676671981812e-01
    z[0,4,0]  R540      -1.5232269465923309e-01
    z[0,4,0]  R541      -4.1082230210304260e-01
    z[0,4,0]  R542      -3.1880471110343933e-01
    z[0,4,0]  R543      -2.5601112842559814e-01
    z[0,4,0]  R544      -1.4790304005146027e-01
    z[0,4,0]  R545      1.4020407572388649e-02
    z[0,4,0]  R546      2.4772234261035919e-01
    z[0,4,0]  R547      2.4696488678455353e-01
    z[0,4,0]  R548      3.6294525861740112e-01
    z[0,4,0]  R549      -8.6895838379859924e-02
    z[0,4,0]  R550      -2.8850749135017395e-01
    z[0,4,0]  R551      -5.8941280841827393e-01
    z[0,4,0]  R552      -4.5666575431823730e-01
    z[0,4,0]  R553      -6.8102669715881348e-01
    z[0,4,0]  R554      1.6378079354763031e-01
    z[0,4,0]  R555      -7.7737474441528320e-01
    z[0,4,0]  R556      4.2044779658317566e-01
    z[0,4,0]  R557      4.9880540370941162e-01
    z[0,4,0]  R558      -1.2612174451351166e-01
    z[0,4,0]  R559      -4.1878500580787659e-01
    z[0,4,0]  R560      2.1678902208805084e-01
    z[0,4,0]  R561      -1.3231416046619415e-01
    z[0,4,0]  R562      0.0712457224726677
    z[0,4,0]  R563      7.9802796244621277e-02
    z[0,4,0]  R564      -2.8022137284278870e-01
    z[0,4,0]  R565      9.2771604657173157e-02
    z[0,4,0]  R566      5.8583840727806091e-02
    z[0,4,0]  R567      3.5452548414468765e-02
    z[0,4,0]  R568      -1.6146329045295715e-01
    z[0,4,0]  R569      -4.4147886335849762e-02
    z[0,4,0]  R570      1.3029080629348755e-01
    z[0,4,0]  R571      -4.9732866883277893e-01
    z[0,4,0]  R572      -3.5069355368614197e-01
    z[0,4,0]  R573      3.1645726412534714e-02
    z[0,4,0]  R574      8.7404318153858185e-02
    z[0,4,0]  R575      -0.0250399112701416
    z[0,4,0]  R576      -2.7012780308723450e-02
    z[0,4,0]  R577      -2.1615663170814514e-01
    z[0,4,0]  R578      -2.8485766053199768e-01
    z[0,4,0]  R579      -3.6229911446571350e-01
    z[0,4,0]  R580      -6.1006546020507812e-01
    z[0,4,0]  R581      -5.8062785863876343e-01
    z[0,4,0]  R582      -6.0760623216629028e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R444      -1
    z[0,4,1]  R445      1
    z[0,4,1]  R456      -5.2023779600858688e-02
    z[0,4,1]  R457      1.8688815832138062e-01
    z[0,4,1]  R458      -2.0055456459522247e-01
    z[0,4,1]  R459      4.0589934587478638e-01
    z[0,4,1]  R460      -3.5552942752838135e-01
    z[0,4,1]  R461      1.1135175079107285e-01
    z[0,4,1]  R462      1.5564145147800446e-01
    z[0,4,1]  R463      -1.4409725368022919e-01
    z[0,4,1]  R464      -3.5696956515312195e-01
    z[0,4,1]  R465      -6.0474425554275513e-01
    z[0,4,1]  R466      5.9611005708575249e-03
    z[0,4,1]  R467      -1.3778430223464966e-01
    z[0,4,1]  R468      1.5254957973957062e-01
    z[0,4,1]  R469      4.2437443137168884e-01
    z[0,4,1]  R470      -3.2389974594116211e-01
    z[0,4,1]  R471      -3.8495957851409912e-01
    z[0,4,1]  R472      -5.0874465703964233e-01
    z[0,4,1]  R473      -3.6350693553686142e-02
    z[0,4,1]  R474      0.101785808801651
    z[0,4,1]  R475      1.9338355958461761e-01
    z[0,4,1]  R476      4.4235434383153915e-02
    z[0,4,1]  R477      -5.3629451990127563e-01
    z[0,4,1]  R478      0.81854248046875
    z[0,4,1]  R479      6.3725358247756958e-01
    z[0,4,1]  R480      -1.5819889307022095e-01
    z[0,4,1]  R481      4.4261854887008667e-01
    z[0,4,1]  R482      -4.1794739663600922e-02
    z[0,4,1]  R483      8.7619268894195557e-01
    z[0,4,1]  R484      1.1899554729461670e-01
    z[0,4,1]  R485      3.3444416522979736e-01
    z[0,4,1]  R486      -2.4165698885917664e-01
    z[0,4,1]  R487      2.8275391459465027e-01
    z[0,4,1]  R488      3.5537354648113251e-02
    z[0,4,1]  R489      -7.6254919171333313e-02
    z[0,4,1]  R490      -4.0073856711387634e-02
    z[0,4,1]  R491      0.0935761034488678
    z[0,4,1]  R492      -2.2781632840633392e-01
    z[0,4,1]  R493      0.36614990234375
    z[0,4,1]  R494      2.5656276941299438e-01
    z[0,4,1]  R495      3.1483608484268188e-01
    z[0,4,1]  R496      5.7906292378902435e-02
    z[0,4,1]  R497      7.1568292379379272e-01
    z[0,4,1]  R498      -3.4410279989242554e-01
    z[0,4,1]  R499      2.2935485467314720e-03
    z[0,4,1]  R500      0.634415328502655
    z[0,4,1]  R501      7.4076700210571289e-01
    z[0,4,1]  R502      5.5692654848098755e-01
    z[0,4,1]  R503      6.0079181194305420e-01
    z[0,4,1]  R504      5.2259796857833862e-01
    z[0,4,1]  R505      -9.6683973073959351e-01
    z[0,4,1]  R506      3.7239167094230652e-01
    z[0,4,1]  R507      -5.7963605970144272e-02
    z[0,4,1]  R508      -4.1433505713939667e-02
    z[0,4,1]  R509      -6.8225346505641937e-02
    z[0,4,1]  R510      -1.5415996313095093e-01
    z[0,4,1]  R511      -3.3002066612243652e-01
    z[0,4,1]  R512      -0.294149249792099
    z[0,4,1]  R513      3.0904176831245422e-01
    z[0,4,1]  R514      1.3697081804275513e-01
    z[0,4,1]  R515      0.750571072101593
    z[0,4,1]  R516      -3.0818048119544983e-01
    z[0,4,1]  R517      2.4123266339302063e-01
    z[0,4,1]  R518      1.3480287790298462e-01
    z[0,4,1]  R519      1.3289435207843781e-01
    z[0,4,1]  R520      -2.2830264270305634e-01
    z[0,4,1]  R521      3.2131770253181458e-01
    z[0,4,1]  R522      -2.1391832828521729e-01
    z[0,4,1]  R523      2.7872404456138611e-01
    z[0,4,1]  R524      -2.0348201692104340e-01
    z[0,4,1]  R525      6.0059273242950439e-01
    z[0,4,1]  R526      1.6556029021739960e-01
    z[0,4,1]  R527      -1.4329962432384491e-01
    z[0,4,1]  R528      2.1220651268959045e-01
    z[0,4,1]  R529      -1.6914875805377960e-01
    z[0,4,1]  R530      -1.4743930101394653e-01
    z[0,4,1]  R531      -1.7499189078807831e-01
    z[0,4,1]  R532      -3.5884156823158264e-01
    z[0,4,1]  R533      5.8143043518066406e-01
    z[0,4,1]  R534      -8.5988634824752808e-01
    z[0,4,1]  R535      -8.2960969209671021e-01
    z[0,4,1]  R536      2.7405783534049988e-01
    z[0,4,1]  R537      1.1639898270368576e-01
    z[0,4,1]  R538      -9.9900364875793457e-02
    z[0,4,1]  R539      -1.8450449407100677e-01
    z[0,4,1]  R540      -9.3087553977966309e-01
    z[0,4,1]  R541      -8.3404815196990967e-01
    z[0,4,1]  R542      -0.841460645198822
    z[0,4,1]  R543      -8.5124516487121582e-01
    z[0,4,1]  R544      -3.2479953765869141e-01
    z[0,4,1]  R545      -9.0595930814743042e-01
    z[0,4,1]  R546      1.4595788717269897e-01
    z[0,4,1]  R547      -3.5114955902099609e-01
    z[0,4,1]  R548      -4.1777870059013367e-01
    z[0,4,1]  R549      6.1551898717880249e-02
    z[0,4,1]  R550      1.3498616218566895e-01
    z[0,4,1]  R551      -2.5606042146682739e-01
    z[0,4,1]  R552      -1.7154380679130554e-01
    z[0,4,1]  R553      -5.9940207004547119e-01
    z[0,4,1]  R554      2.0661603659391403e-02
    z[0,4,1]  R555      -3.7383487820625305e-01
    z[0,4,1]  R556      -3.1460642814636230e-01
    z[0,4,1]  R557      6.7527025938034058e-01
    z[0,4,1]  R558      -4.2850311729125679e-04
    z[0,4,1]  R559      2.1219305694103241e-02
    z[0,4,1]  R560      4.2749759554862976e-01
    z[0,4,1]  R561      4.1486227512359619e-01
    z[0,4,1]  R562      -1.2789431214332581e-01
    z[0,4,1]  R563      1.4151163399219513e-01
    z[0,4,1]  R564      3.4211838245391846e-01
    z[0,4,1]  R565      3.2706397771835327e-01
    z[0,4,1]  R566      -2.5861749053001404e-01
    z[0,4,1]  R567      1.7459358274936676e-01
    z[0,4,1]  R568      -4.4919971376657486e-02
    z[0,4,1]  R569      2.0421484112739563e-01
    z[0,4,1]  R570      4.0388610959053040e-01
    z[0,4,1]  R571      1.8536414951086044e-02
    z[0,4,1]  R572      -7.0024833083152771e-02
    z[0,4,1]  R573      3.2747775316238403e-01
    z[0,4,1]  R574      2.3994833230972290e-01
    z[0,4,1]  R575      2.8354302048683167e-01
    z[0,4,1]  R576      -4.4861879199743271e-02
    z[0,4,1]  R577      5.6180745363235474e-02
    z[0,4,1]  R578      8.0625161528587341e-02
    z[0,4,1]  R579      1.1535218358039856e-01
    z[0,4,1]  R580      -7.6415991783142090e-01
    z[0,4,1]  R581      -0.756704568862915
    z[0,4,1]  R582      -7.4083060026168823e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R446      -1
    z[0,4,2]  R447      1
    z[0,4,2]  R456      -5.6777913123369217e-02
    z[0,4,2]  R457      1.0353393852710724e-01
    z[0,4,2]  R458      -3.2702925801277161e-01
    z[0,4,2]  R459      -1.2539622187614441e-01
    z[0,4,2]  R460      -2.3582690954208374e-01
    z[0,4,2]  R461      -3.1900930404663086e-01
    z[0,4,2]  R462      -2.7136135101318359e-01
    z[0,4,2]  R463      4.4235885143280029e-02
    z[0,4,2]  R464      3.3006185293197632e-01
    z[0,4,2]  R465      2.7378043532371521e-01
    z[0,4,2]  R466      2.8532043099403381e-01
    z[0,4,2]  R467      -1.7149317264556885e-01
    z[0,4,2]  R468      8.2180345058441162e-01
    z[0,4,2]  R469      -6.7168600857257843e-02
    z[0,4,2]  R470      -1.7426814138889313e-01
    z[0,4,2]  R471      1.7528069019317627e-01
    z[0,4,2]  R472      -1.4055498875677586e-02
    z[0,4,2]  R473      3.2149147987365723e-01
    z[0,4,2]  R474      8.6558210849761963e-01
    z[0,4,2]  R475      9.3931305408477783e-01
    z[0,4,2]  R476      7.3067253828048706e-01
    z[0,4,2]  R477      -2.2591440379619598e-01
    z[0,4,2]  R478      -1.5671806037425995e-01
    z[0,4,2]  R479      5.5256050825119019e-01
    z[0,4,2]  R480      0.467549592256546
    z[0,4,2]  R481      -3.3615368604660034e-01
    z[0,4,2]  R482      3.6083319783210754e-01
    z[0,4,2]  R483      6.0788080096244812e-02
    z[0,4,2]  R484      -1.4985999464988708e-01
    z[0,4,2]  R485      2.6378521323204041e-01
    z[0,4,2]  R486      -3.1577392946928740e-03
    z[0,4,2]  R487      -2.0002222061157227e-01
    z[0,4,2]  R488      2.6407885551452637e-01
    z[0,4,2]  R489      -2.5432729721069336e-01
    z[0,4,2]  R490      -3.1636923551559448e-01
    z[0,4,2]  R491      -2.6361331343650818e-01
    z[0,4,2]  R492      -1.0337930172681808e-01
    z[0,4,2]  R493      4.4319942593574524e-01
    z[0,4,2]  R494      3.6318498849868774e-01
    z[0,4,2]  R495      2.8820511698722839e-01
    z[0,4,2]  R496      -3.6796236038208008e-01
    z[0,4,2]  R497      2.7848687767982483e-01
    z[0,4,2]  R498      -3.0173275619745255e-02
    z[0,4,2]  R499      7.3003798723220825e-01
    z[0,4,2]  R500      -1.7617985606193542e-01
    z[0,4,2]  R501      -8.4466069936752319e-02
    z[0,4,2]  R502      1.8327631056308746e-01
    z[0,4,2]  R503      -6.3278481364250183e-02
    z[0,4,2]  R504      -1.6766825318336487e-01
    z[0,4,2]  R505      1.3303583860397339e-01
    z[0,4,2]  R506      2.4208576977252960e-01
    z[0,4,2]  R507      -0.179097518324852
    z[0,4,2]  R508      1.1233936063945293e-02
    z[0,4,2]  R509      4.3308448791503906e-01
    z[0,4,2]  R510      2.5103539228439331e-01
    z[0,4,2]  R511      4.5756268501281738e-01
    z[0,4,2]  R512      4.3825164437294006e-01
    z[0,4,2]  R513      0.348513126373291
    z[0,4,2]  R514      3.1630018353462219e-01
    z[0,4,2]  R515      -4.0792483091354370e-01
    z[0,4,2]  R516      -1.5815148130059242e-02
    z[0,4,2]  R517      1.3097250461578369e-01
    z[0,4,2]  R518      5.2823996543884277e-01
    z[0,4,2]  R519      -2.1121042966842651e-01
    z[0,4,2]  R520      -8.3415031433105469e-02
    z[0,4,2]  R521      -1.9119301438331604e-01
    z[0,4,2]  R522      5.0723668187856674e-02
    z[0,4,2]  R523      1.6085717082023621e-01
    z[0,4,2]  R524      8.1871229410171509e-01
    z[0,4,2]  R525      4.4781997799873352e-01
    z[0,4,2]  R526      -2.5352808833122253e-01
    z[0,4,2]  R527      1.1890961229801178e-01
    z[0,4,2]  R528      5.4404580593109131e-01
    z[0,4,2]  R529      2.9344305396080017e-01
    z[0,4,2]  R530      0.0649917870759964
    z[0,4,2]  R531      3.0003413558006287e-01
    z[0,4,2]  R532      5.0687056779861450e-01
    z[0,4,2]  R533      1.9926688075065613e-01
    z[0,4,2]  R534      2.7861837297677994e-02
    z[0,4,2]  R535      6.4635850489139557e-02
    z[0,4,2]  R536      -2.6343947649002075e-01
    z[0,4,2]  R537      7.1777254343032837e-02
    z[0,4,2]  R538      6.4623379707336426e-01
    z[0,4,2]  R539      4.6222358942031860e-01
    z[0,4,2]  R540      -0.252784788608551
    z[0,4,2]  R541      -1.6858577728271484e-01
    z[0,4,2]  R542      -2.5062909722328186e-01
    z[0,4,2]  R543      -0.354160875082016
    z[0,4,2]  R544      -1.4349471032619476e-01
    z[0,4,2]  R545      1.0102648288011551e-01
    z[0,4,2]  R546      2.2578868269920349e-01
    z[0,4,2]  R547      -4.8831388354301453e-01
    z[0,4,2]  R548      2.3956601321697235e-01
    z[0,4,2]  R549      -9.2622911930084229e-01
    z[0,4,2]  R550      -5.6925896555185318e-02
    z[0,4,2]  R551      1.8781113624572754e-01
    z[0,4,2]  R552      4.5199862122535706e-01
    z[0,4,2]  R553      2.2137674689292908e-01
    z[0,4,2]  R554      3.0540555715560913e-01
    z[0,4,2]  R555      1.8160057067871094e-01
    z[0,4,2]  R556      1.8379474058747292e-02
    z[0,4,2]  R557      1.0136752575635910e-01
    z[0,4,2]  R558      0.719666063785553
    z[0,4,2]  R559      -3.1923856586217880e-02
    z[0,4,2]  R560      -1.0549058765172958e-01
    z[0,4,2]  R561      1.2692656368017197e-02
    z[0,4,2]  R562      -0.097258560359478
    z[0,4,2]  R563      2.4996910989284515e-01
    z[0,4,2]  R564      4.1910886764526367e-02
    z[0,4,2]  R565      3.1649264693260193e-01
    z[0,4,2]  R566      -3.3787362277507782e-02
    z[0,4,2]  R567      -3.2035586237907410e-01
    z[0,4,2]  R568      6.3951745629310608e-02
    z[0,4,2]  R569      0.658301830291748
    z[0,4,2]  R570      4.8984782770276070e-03
    z[0,4,2]  R571      3.0478018522262573e-01
    z[0,4,2]  R572      6.9895529747009277e-01
    z[0,4,2]  R573      8.5863113403320312e-02
    z[0,4,2]  R574      -1.6348041594028473e-02
    z[0,4,2]  R575      1.1734221875667572e-01
    z[0,4,2]  R576      -1.5207682549953461e-01
    z[0,4,2]  R577      4.1668361425399780e-01
    z[0,4,2]  R578      1.6104342043399811e-01
    z[0,4,2]  R579      2.7280882000923157e-01
    z[0,4,2]  R580      5.7944428175687790e-02
    z[0,4,2]  R581      1.0019752383232117e-01
    z[0,4,2]  R582      1.4930146932601929e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R448      -1
    z[0,4,3]  R449      1
    z[0,4,3]  R456      -9.2928916215896606e-01
    z[0,4,3]  R457      -0.804606556892395
    z[0,4,3]  R458      -8.5726940631866455e-01
    z[0,4,3]  R459      -8.5723048448562622e-01
    z[0,4,3]  R460      -8.0125230550765991e-01
    z[0,4,3]  R461      -7.1358543634414673e-01
    z[0,4,3]  R462      -7.9580336809158325e-01
    z[0,4,3]  R463      -1.5711851418018341e-01
    z[0,4,3]  R464      -2.7160879969596863e-01
    z[0,4,3]  R465      -1.3891610503196716e-01
    z[0,4,3]  R466      3.8556548953056335e-01
    z[0,4,3]  R467      4.3534025549888611e-01
    z[0,4,3]  R468      1.7657354474067688e-01
    z[0,4,3]  R469      3.9180862903594971e-01
    z[0,4,3]  R470      2.4762172996997833e-01
    z[0,4,3]  R471      2.9850077629089355e-01
    z[0,4,3]  R472      5.1189678907394409e-01
    z[0,4,3]  R473      3.6862105131149292e-01
    z[0,4,3]  R474      2.1526399254798889e-01
    z[0,4,3]  R475      1.1522676795721054e-01
    z[0,4,3]  R476      4.4608378410339355e-01
    z[0,4,3]  R477      5.6817245483398438e-01
    z[0,4,3]  R478      2.0419143140316010e-01
    z[0,4,3]  R479      -2.1266290545463562e-01
    z[0,4,3]  R480      6.1207717657089233e-01
    z[0,4,3]  R481      2.3714180290699005e-01
    z[0,4,3]  R482      1.5064767003059387e-01
    z[0,4,3]  R483      3.3175039291381836e-01
    z[0,4,3]  R484      7.5979363918304443e-01
    z[0,4,3]  R485      6.5049648284912109e-01
    z[0,4,3]  R486      5.3698408603668213e-01
    z[0,4,3]  R487      4.9911034107208252e-01
    z[0,4,3]  R488      5.5468392372131348e-01
    z[0,4,3]  R489      5.2799969911575317e-01
    z[0,4,3]  R490      4.9183416366577148e-01
    z[0,4,3]  R491      -1.7968240380287170e-01
    z[0,4,3]  R492      5.0459164381027222e-01
    z[0,4,3]  R493      3.0800908803939819e-01
    z[0,4,3]  R494      6.0138350725173950e-01
    z[0,4,3]  R495      -2.4376663565635681e-01
    z[0,4,3]  R496      6.8626904487609863e-01
    z[0,4,3]  R497      -3.3575016260147095e-01
    z[0,4,3]  R498      6.3144260644912720e-01
    z[0,4,3]  R499      4.2121031880378723e-01
    z[0,4,3]  R500      5.6819815188646317e-02
    z[0,4,3]  R501      0.336073100566864
    z[0,4,3]  R502      1.5416452288627625e-01
    z[0,4,3]  R503      2.4057245254516602e-01
    z[0,4,3]  R504      1.6548976302146912e-01
    z[0,4,3]  R505      -9.2471368610858917e-02
    z[0,4,3]  R506      5.3288924694061279e-01
    z[0,4,3]  R507      -0.455875039100647
    z[0,4,3]  R508      -3.8344934582710266e-01
    z[0,4,3]  R509      0.614128053188324
    z[0,4,3]  R510      0.767065703868866
    z[0,4,3]  R511      3.5107195377349854e-01
    z[0,4,3]  R512      6.2618285417556763e-01
    z[0,4,3]  R513      -3.4679338335990906e-01
    z[0,4,3]  R514      5.5651229619979858e-01
    z[0,4,3]  R515      1.9736245274543762e-01
    z[0,4,3]  R516      -8.5408180952072144e-01
    z[0,4,3]  R517      -5.5037140846252441e-01
    z[0,4,3]  R518      -7.3549979925155640e-01
    z[0,4,3]  R519      -4.9482280015945435e-01
    z[0,4,3]  R520      6.7564916610717773e-01
    z[0,4,3]  R521      6.6907513141632080e-01
    z[0,4,3]  R522      8.2581186294555664e-01
    z[0,4,3]  R523      0.79014652967453
    z[0,4,3]  R524      1.7215198278427124e-01
    z[0,4,3]  R525      5.8378702402114868e-01
    z[0,4,3]  R526      -0.62684565782547
    z[0,4,3]  R527      0.827559769153595
    z[0,4,3]  R528      6.0564368963241577e-01
    z[0,4,3]  R529      6.2602764368057251e-01
    z[0,4,3]  R530      2.5464054942131042e-01
    z[0,4,3]  R531      4.9707618355751038e-01
    z[0,4,3]  R532      2.4635070562362671e-01
    z[0,4,3]  R533      7.9420171678066254e-03
    z[0,4,3]  R534      7.3591373860836029e-02
    z[0,4,3]  R535      -1.1864126473665237e-01
    z[0,4,3]  R536      7.1144467592239380e-01
    z[0,4,3]  R537      -6.2321805953979492e-01
    z[0,4,3]  R538      0.448964923620224
    z[0,4,3]  R539      1.6619957983493805e-01
    z[0,4,3]  R540      1.0466784238815308e-01
    z[0,4,3]  R541      1.7910125851631165e-01
    z[0,4,3]  R542      3.1129390001296997e-01
    z[0,4,3]  R543      2.0030494779348373e-02
    z[0,4,3]  R544      9.6967602148652077e-03
    z[0,4,3]  R545      2.0940619707107544e-01
    z[0,4,3]  R546      -8.6045974493026733e-01
    z[0,4,3]  R547      -1.4862245321273804e-01
    z[0,4,3]  R548      -1.6409538686275482e-02
    z[0,4,3]  R549      -2.5952234864234924e-01
    z[0,4,3]  R550      1.7812801524996758e-02
    z[0,4,3]  R551      8.6579039692878723e-02
    z[0,4,3]  R552      8.2425296306610107e-02
    z[0,4,3]  R553      -8.2052469253540039e-02
    z[0,4,3]  R554      3.0150455236434937e-01
    z[0,4,3]  R555      -1.7092892527580261e-01
    z[0,4,3]  R556      -8.4106504917144775e-02
    z[0,4,3]  R557      2.7513271570205688e-01
    z[0,4,3]  R558      4.0931177139282227e-01
    z[0,4,3]  R559      6.1861896514892578e-01
    z[0,4,3]  R560      5.9167939424514771e-01
    z[0,4,3]  R561      5.5876374244689941e-01
    z[0,4,3]  R562      3.9200946688652039e-01
    z[0,4,3]  R563      4.5328933000564575e-01
    z[0,4,3]  R564      4.8418885469436646e-01
    z[0,4,3]  R565      4.8538509011268616e-01
    z[0,4,3]  R566      0.664361834526062
    z[0,4,3]  R567      0.720909833908081
    z[0,4,3]  R568      0.516990602016449
    z[0,4,3]  R569      6.9094288349151611e-01
    z[0,4,3]  R570      5.9732836484909058e-01
    z[0,4,3]  R571      6.3530176877975464e-01
    z[0,4,3]  R572      0.408335417509079
    z[0,4,3]  R573      5.4951918125152588e-01
    z[0,4,3]  R574      4.5598819851875305e-01
    z[0,4,3]  R575      6.2091869115829468e-01
    z[0,4,3]  R576      7.3603373765945435e-01
    z[0,4,3]  R577      6.5980148315429688e-01
    z[0,4,3]  R578      6.3465386629104614e-01
    z[0,4,3]  R579      0.608033299446106
    z[0,4,3]  R580      -1.8308252096176147e-02
    z[0,4,3]  R581      -1.7723189294338226e-01
    z[0,4,3]  R582      1.3498324155807495e-01
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R450      -1
    z[0,4,4]  R451      1
    z[0,4,4]  R456      2.9850891232490540e-01
    z[0,4,4]  R457      1.0379948467016220e-01
    z[0,4,4]  R458      6.7134196870028973e-03
    z[0,4,4]  R459      -2.4092530831694603e-02
    z[0,4,4]  R460      3.4442999958992004e-01
    z[0,4,4]  R461      -5.1885211467742920e-01
    z[0,4,4]  R462      3.5841333866119385e-01
    z[0,4,4]  R463      -4.1127124428749084e-01
    z[0,4,4]  R464      8.8618598878383636e-02
    z[0,4,4]  R465      2.2265779972076416e-01
    z[0,4,4]  R466      -4.9502938985824585e-01
    z[0,4,4]  R467      -8.5293418169021606e-01
    z[0,4,4]  R468      3.3291608095169067e-01
    z[0,4,4]  R469      -7.1162384748458862e-01
    z[0,4,4]  R470      -7.4344772100448608e-01
    z[0,4,4]  R471      -7.7911502122879028e-01
    z[0,4,4]  R472      -0.671019434928894
    z[0,4,4]  R473      -8.1939530372619629e-01
    z[0,4,4]  R474      2.0195983350276947e-01
    z[0,4,4]  R475      2.0293138921260834e-01
    z[0,4,4]  R476      4.4607225060462952e-01
    z[0,4,4]  R477      -4.4644799828529358e-01
    z[0,4,4]  R478      8.7363161146640778e-03
    z[0,4,4]  R479      3.6340811848640442e-01
    z[0,4,4]  R480      -2.9440057277679443e-01
    z[0,4,4]  R481      -3.7326484918594360e-01
    z[0,4,4]  R482      2.4924322962760925e-01
    z[0,4,4]  R483      3.0503988265991211e-01
    z[0,4,4]  R484      -7.0223741233348846e-02
    z[0,4,4]  R485      -1.9835433363914490e-01
    z[0,4,4]  R486      -7.0246893167495728e-01
    z[0,4,4]  R487      -0.702630341053009
    z[0,4,4]  R488      0.272499144077301
    z[0,4,4]  R489      -6.6848033666610718e-01
    z[0,4,4]  R490      -5.1927280426025391e-01
    z[0,4,4]  R491      -0.247806116938591
    z[0,4,4]  R492      -3.1744873523712158e-01
    z[0,4,4]  R493      -6.3552063703536987e-01
    z[0,4,4]  R494      -4.9319875240325928e-01
    z[0,4,4]  R495      -4.1530814766883850e-01
    z[0,4,4]  R496      -5.6754702329635620e-01
    z[0,4,4]  R497      2.3077231645584106e-01
    z[0,4,4]  R498      -4.7983753681182861e-01
    z[0,4,4]  R499      3.4534502029418945e-01
    z[0,4,4]  R500      4.1923069953918457e-01
    z[0,4,4]  R501      4.8716527223587036e-01
    z[0,4,4]  R502      4.9648800492286682e-01
    z[0,4,4]  R503      -1.5960346907377243e-02
    z[0,4,4]  R504      -6.6549576818943024e-02
    z[0,4,4]  R505      -1.2255188077688217e-01
    z[0,4,4]  R506      -6.6290569305419922e-01
    z[0,4,4]  R507      -3.7945404648780823e-01
    z[0,4,4]  R508      2.0986701548099518e-01
    z[0,4,4]  R509      2.1012732386589050e-01
    z[0,4,4]  R510      -0.489188551902771
    z[0,4,4]  R511      -3.6255702376365662e-02
    z[0,4,4]  R512      -5.0594764947891235e-01
    z[0,4,4]  R513      -3.7479439377784729e-01
    z[0,4,4]  R514      -4.5726552605628967e-01
    z[0,4,4]  R515      2.2959679365158081e-01
    z[0,4,4]  R516      -3.2122680544853210e-01
    z[0,4,4]  R517      -1.9119140505790710e-01
    z[0,4,4]  R518      -1.7439144849777222e-01
    z[0,4,4]  R519      -4.4242069125175476e-01
    z[0,4,4]  R520      -4.1691732406616211e-01
    z[0,4,4]  R521      -5.6202590465545654e-01
    z[0,4,4]  R522      -0.505794107913971
    z[0,4,4]  R523      -3.8944569230079651e-01
    z[0,4,4]  R524      2.2215992212295532e-01
    z[0,4,4]  R525      2.6274007558822632e-01
    z[0,4,4]  R526      -4.0438213944435120e-01
    z[0,4,4]  R527      -5.2583914995193481e-01
    z[0,4,4]  R528      2.2356854379177094e-01
    z[0,4,4]  R529      -4.9322238564491272e-01
    z[0,4,4]  R530      -8.0460679531097412e-01
    z[0,4,4]  R531      1.6704671084880829e-01
    z[0,4,4]  R532      -2.9823830351233482e-02
    z[0,4,4]  R533      4.2493402957916260e-01
    z[0,4,4]  R534      2.2571101784706116e-01
    z[0,4,4]  R535      1.7069098353385925e-01
    z[0,4,4]  R536      -5.4182070493698120e-01
    z[0,4,4]  R537      2.2802498936653137e-01
    z[0,4,4]  R538      1.1553851515054703e-01
    z[0,4,4]  R539      3.4038805961608887e-01
    z[0,4,4]  R540      -4.0117930620908737e-02
    z[0,4,4]  R541      -2.6049926877021790e-02
    z[0,4,4]  R542      1.1090749502182007e-01
    z[0,4,4]  R543      -3.5114653408527374e-02
    z[0,4,4]  R544      6.0660088062286377e-01
    z[0,4,4]  R545      6.9004237651824951e-02
    z[0,4,4]  R546      -4.3812990188598633e-02
    z[0,4,4]  R547      -2.3397125303745270e-01
    z[0,4,4]  R548      4.8334822058677673e-01
    z[0,4,4]  R549      8.1369958817958832e-02
    z[0,4,4]  R550      4.1641953587532043e-01
    z[0,4,4]  R551      -7.0744216442108154e-01
    z[0,4,4]  R552      -7.0412427186965942e-01
    z[0,4,4]  R553      -3.2751148939132690e-01
    z[0,4,4]  R554      -7.7893167734146118e-01
    z[0,4,4]  R555      -1.9485269486904144e-01
    z[0,4,4]  R556      -1.3611069321632385e-01
    z[0,4,4]  R557      3.5755693912506104e-01
    z[0,4,4]  R558      9.4899103045463562e-02
    z[0,4,4]  R559      -5.7386392354965210e-01
    z[0,4,4]  R560      -5.0568145513534546e-01
    z[0,4,4]  R561      -0.574921190738678
    z[0,4,4]  R562      -7.2078096866607666e-01
    z[0,4,4]  R563      -8.1240636110305786e-01
    z[0,4,4]  R564      -7.3139494657516479e-01
    z[0,4,4]  R565      -4.9469089508056641e-01
    z[0,4,4]  R566      -6.0339617729187012e-01
    z[0,4,4]  R567      -5.5495953559875488e-01
    z[0,4,4]  R568      -5.7392561435699463e-01
    z[0,4,4]  R569      1.4989911019802094e-01
    z[0,4,4]  R570      -6.0175734758377075e-01
    z[0,4,4]  R571      9.2814810574054718e-02
    z[0,4,4]  R572      1.5847903490066528e-01
    z[0,4,4]  R573      -5.4320687055587769e-01
    z[0,4,4]  R574      -8.4174668788909912e-01
    z[0,4,4]  R575      -6.2490385770797729e-01
    z[0,4,4]  R576      -6.0696178674697876e-01
    z[0,4,4]  R577      2.7905102819204330e-02
    z[0,4,4]  R578      -6.7005246877670288e-01
    z[0,4,4]  R579      -6.2093317508697510e-01
    z[0,4,4]  R580      4.1517388075590134e-02
    z[0,4,4]  R581      -1.3797618448734283e-01
    z[0,4,4]  R582      -1.8680550158023834e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R452      -1
    z[0,4,5]  R453      1
    z[0,4,5]  R456      -2.7762185782194138e-02
    z[0,4,5]  R457      -4.2355707287788391e-01
    z[0,4,5]  R458      -2.8850415349006653e-01
    z[0,4,5]  R459      8.6988382041454315e-02
    z[0,4,5]  R460      4.0703356266021729e-02
    z[0,4,5]  R461      3.9076272398233414e-02
    z[0,4,5]  R462      1.0142208635807037e-01
    z[0,4,5]  R463      -6.7737591266632080e-01
    z[0,4,5]  R464      -5.8848005533218384e-01
    z[0,4,5]  R465      4.9932379275560379e-02
    z[0,4,5]  R466      3.2726475596427917e-01
    z[0,4,5]  R467      8.3617325872182846e-03
    z[0,4,5]  R468      1.6888137161731720e-01
    z[0,4,5]  R469      3.5665473341941833e-01
    z[0,4,5]  R470      4.9061697721481323e-01
    z[0,4,5]  R471      3.3408010005950928e-01
    z[0,4,5]  R472      1.5271255373954773e-01
    z[0,4,5]  R473      1.5786384046077728e-01
    z[0,4,5]  R474      9.0284220874309540e-02
    z[0,4,5]  R475      9.1893002390861511e-02
    z[0,4,5]  R476      1.6373126208782196e-01
    z[0,4,5]  R477      -5.2146852016448975e-02
    z[0,4,5]  R478      4.7652739286422729e-01
    z[0,4,5]  R479      2.7792543172836304e-01
    z[0,4,5]  R480      3.6418086290359497e-01
    z[0,4,5]  R481      4.4458580017089844e-01
    z[0,4,5]  R482      8.2012486457824707e-01
    z[0,4,5]  R483      -1.5312202274799347e-01
    z[0,4,5]  R484      5.3218954801559448e-01
    z[0,4,5]  R485      3.9623332023620605e-01
    z[0,4,5]  R486      0.326760470867157
    z[0,4,5]  R487      1.3923436403274536e-01
    z[0,4,5]  R488      5.7900595664978027e-01
    z[0,4,5]  R489      4.2071428894996643e-01
    z[0,4,5]  R490      5.3725987672805786e-01
    z[0,4,5]  R491      -5.8837610483169556e-01
    z[0,4,5]  R492      5.7882612943649292e-01
    z[0,4,5]  R493      2.9531732201576233e-01
    z[0,4,5]  R494      -2.9737564921379089e-01
    z[0,4,5]  R495      7.7173076570034027e-02
    z[0,4,5]  R496      1.9338364899158478e-01
    z[0,4,5]  R497      -1.0505378013476729e-03
    z[0,4,5]  R498      4.4149649143218994e-01
    z[0,4,5]  R499      2.2492264211177826e-01
    z[0,4,5]  R500      -5.8490353822708130e-01
    z[0,4,5]  R501      6.3682332634925842e-02
    z[0,4,5]  R502      -3.8847097754478455e-01
    z[0,4,5]  R503      -5.6462105363607407e-02
    z[0,4,5]  R504      2.9099500179290771e-01
    z[0,4,5]  R505      6.9737970829010010e-02
    z[0,4,5]  R506      2.2050644457340240e-01
    z[0,4,5]  R507      3.4751009941101074e-01
    z[0,4,5]  R508      -6.1318314075469971e-01
    z[0,4,5]  R509      4.1727980971336365e-01
    z[0,4,5]  R510      1.9269576296210289e-02
    z[0,4,5]  R511      5.6343454122543335e-01
    z[0,4,5]  R512      -2.2268386185169220e-01
    z[0,4,5]  R513      1.2859074771404266e-01
    z[0,4,5]  R514      -4.2583969235420227e-01
    z[0,4,5]  R515      -2.5887307524681091e-01
    z[0,4,5]  R516      -5.3237382322549820e-02
    z[0,4,5]  R517      5.8502310514450073e-01
    z[0,4,5]  R518      1.9193184375762939e-01
    z[0,4,5]  R519      1.0772937536239624e-01
    z[0,4,5]  R520      3.7983378767967224e-01
    z[0,4,5]  R521      -2.5783991813659668e-01
    z[0,4,5]  R522      -9.3516901135444641e-02
    z[0,4,5]  R523      -2.3123618960380554e-01
    z[0,4,5]  R524      4.2595624923706055e-01
    z[0,4,5]  R525      -1.4268389344215393e-01
    z[0,4,5]  R526      0.0777122750878334
    z[0,4,5]  R527      -5.3333669900894165e-02
    z[0,4,5]  R528      1.9997552037239075e-01
    z[0,4,5]  R529      4.8900499939918518e-01
    z[0,4,5]  R530      4.7088339924812317e-01
    z[0,4,5]  R531      6.0139906406402588e-01
    z[0,4,5]  R532      5.2955496311187744e-01
    z[0,4,5]  R533      -1.8144200742244720e-01
    z[0,4,5]  R534      1.1370515823364258e-01
    z[0,4,5]  R535      -4.7502916306257248e-02
    z[0,4,5]  R536      -9.1118104755878448e-02
    z[0,4,5]  R537      7.1925801038742065e-01
    z[0,4,5]  R538      4.3071508407592773e-01
    z[0,4,5]  R539      6.1889731884002686e-01
    z[0,4,5]  R540      2.2198554128408432e-02
    z[0,4,5]  R541      -1.8600904941558838e-01
    z[0,4,5]  R542      -1.1791043728590012e-01
    z[0,4,5]  R543      -2.7503988146781921e-01
    z[0,4,5]  R544      -6.9555658102035522e-01
    z[0,4,5]  R545      -2.5169846415519714e-01
    z[0,4,5]  R546      0.0973777249455452
    z[0,4,5]  R547      -6.8293410539627075e-01
    z[0,4,5]  R548      -5.8425325155258179e-01
    z[0,4,5]  R549      -1.4632146060466766e-01
    z[0,4,5]  R550      -6.9484394788742065e-01
    z[0,4,5]  R551      1.8580364063382149e-02
    z[0,4,5]  R552      1.9190703332424164e-01
    z[0,4,5]  R553      3.4785460680723190e-02
    z[0,4,5]  R554      1.9320763647556305e-01
    z[0,4,5]  R555      2.2605451941490173e-01
    z[0,4,5]  R556      5.9355276823043823e-01
    z[0,4,5]  R557      2.0836704969406128e-01
    z[0,4,5]  R558      3.9777347445487976e-01
    z[0,4,5]  R559      7.5879737734794617e-02
    z[0,4,5]  R560      3.1614589691162109e-01
    z[0,4,5]  R561      4.0916091203689575e-01
    z[0,4,5]  R562      3.5511884093284607e-01
    z[0,4,5]  R563      -2.9819600284099579e-02
    z[0,4,5]  R564      9.0072564780712128e-02
    z[0,4,5]  R565      4.4309636950492859e-01
    z[0,4,5]  R566      1.6005451977252960e-01
    z[0,4,5]  R567      1.9110429286956787e-01
    z[0,4,5]  R568      4.8027086257934570e-01
    z[0,4,5]  R569      1.4256159961223602e-01
    z[0,4,5]  R570      3.0097925662994385e-01
    z[0,4,5]  R571      4.9623328447341919e-01
    z[0,4,5]  R572      4.3775799870491028e-01
    z[0,4,5]  R573      2.6191705465316772e-01
    z[0,4,5]  R574      7.4255662038922310e-03
    z[0,4,5]  R575      -3.1197839975357056e-01
    z[0,4,5]  R576      3.0499780550599098e-02
    z[0,4,5]  R577      4.5033949613571167e-01
    z[0,4,5]  R578      -1.5306897461414337e-01
    z[0,4,5]  R579      1.4283972978591919e-01
    z[0,4,5]  R580      1.1083095520734787e-01
    z[0,4,5]  R581      1.1505434662103653e-01
    z[0,4,5]  R582      8.1059344112873077e-02
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R454      -1
    z[0,4,6]  R455      1
    z[0,4,6]  R456      1.9107328355312347e-01
    z[0,4,6]  R457      3.0165421962738037e-01
    z[0,4,6]  R458      1.3045558333396912e-01
    z[0,4,6]  R459      2.6932266354560852e-01
    z[0,4,6]  R460      -2.1146193146705627e-01
    z[0,4,6]  R461      2.8522223234176636e-01
    z[0,4,6]  R462      -2.6264557242393494e-01
    z[0,4,6]  R463      -5.1534049212932587e-02
    z[0,4,6]  R464      -2.6396539807319641e-01
    z[0,4,6]  R465      5.9392873197793961e-02
    z[0,4,6]  R466      6.3238894939422607e-01
    z[0,4,6]  R467      4.8657186329364777e-02
    z[0,4,6]  R468      2.2225466370582581e-01
    z[0,4,6]  R469      2.6226265355944633e-02
    z[0,4,6]  R470      -8.5489697754383087e-02
    z[0,4,6]  R471      1.1524365842342377e-01
    z[0,4,6]  R472      -6.0925945639610291e-02
    z[0,4,6]  R473      2.4047592282295227e-01
    z[0,4,6]  R474      2.7839845418930054e-01
    z[0,4,6]  R475      1.4632443897426128e-02
    z[0,4,6]  R476      -1.9516487419605255e-01
    z[0,4,6]  R477      3.6841621994972229e-01
    z[0,4,6]  R478      -1.7419892549514771e-01
    z[0,4,6]  R479      -1.0508665442466736e-01
    z[0,4,6]  R480      2.1887370944023132e-01
    z[0,4,6]  R481      4.9801462888717651e-01
    z[0,4,6]  R482      -2.0023313164710999e-01
    z[0,4,6]  R483      4.2687371373176575e-02
    z[0,4,6]  R484      -1.7269712686538696e-01
    z[0,4,6]  R485      2.5844737887382507e-01
    z[0,4,6]  R486      2.2752356529235840e-01
    z[0,4,6]  R487      3.2015082240104675e-01
    z[0,4,6]  R488      -3.0852247029542923e-02
    z[0,4,6]  R489      -1.4967158436775208e-01
    z[0,4,6]  R490      1.0632573813199997e-01
    z[0,4,6]  R491      -2.5837266445159912e-01
    z[0,4,6]  R492      1.5754364430904388e-01
    z[0,4,6]  R493      2.8766760230064392e-01
    z[0,4,6]  R494      1.4787826687097549e-02
    z[0,4,6]  R495      -3.1033328175544739e-01
    z[0,4,6]  R496      -1.5594394505023956e-01
    z[0,4,6]  R497      -2.1786347031593323e-01
    z[0,4,6]  R498      4.2473133653402328e-03
    z[0,4,6]  R499      5.7245563715696335e-02
    z[0,4,6]  R500      2.0748578011989594e-01
    z[0,4,6]  R501      9.0484723448753357e-02
    z[0,4,6]  R502      3.7761884927749634e-01
    z[0,4,6]  R503      1.8649470806121826e-01
    z[0,4,6]  R504      3.0846813693642616e-02
    z[0,4,6]  R505      -3.6305539309978485e-02
    z[0,4,6]  R506      1.4598475396633148e-01
    z[0,4,6]  R507      -4.3949750065803528e-01
    z[0,4,6]  R508      -3.2506820559501648e-01
    z[0,4,6]  R509      4.5821475982666016e-01
    z[0,4,6]  R510      -2.0079061388969421e-01
    z[0,4,6]  R511      2.7436956763267517e-01
    z[0,4,6]  R512      3.0983682721853256e-02
    z[0,4,6]  R513      -2.7007344365119934e-01
    z[0,4,6]  R514      4.2271953821182251e-01
    z[0,4,6]  R515      -2.1987275779247284e-01
    z[0,4,6]  R516      1.7963241040706635e-01
    z[0,4,6]  R517      -2.9832735657691956e-01
    z[0,4,6]  R518      0.0983017086982727
    z[0,4,6]  R519      -3.1668996810913086e-01
    z[0,4,6]  R520      1.5204668045043945e-01
    z[0,4,6]  R521      1.3626010715961456e-01
    z[0,4,6]  R522      -5.1867388188838959e-02
    z[0,4,6]  R523      2.4919275939464569e-01
    z[0,4,6]  R524      -8.0029524862766266e-02
    z[0,4,6]  R525      -6.3693143427371979e-02
    z[0,4,6]  R526      -2.0735444128513336e-01
    z[0,4,6]  R527      -6.4610382542014122e-03
    z[0,4,6]  R528      3.9105647802352905e-01
    z[0,4,6]  R529      -9.8922356963157654e-02
    z[0,4,6]  R530      -7.9763151705265045e-02
    z[0,4,6]  R531      -4.5124265551567078e-01
    z[0,4,6]  R532      2.8198403120040894e-01
    z[0,4,6]  R533      2.2629508748650551e-02
    z[0,4,6]  R534      2.7077522128820419e-02
    z[0,4,6]  R535      2.3101305961608887e-01
    z[0,4,6]  R536      0.200897216796875
    z[0,4,6]  R537      -1.4587773382663727e-01
    z[0,4,6]  R538      -2.3490564525127411e-01
    z[0,4,6]  R539      3.2156085968017578e-01
    z[0,4,6]  R540      -1.8251250684261322e-01
    z[0,4,6]  R541      1.9953005015850067e-01
    z[0,4,6]  R542      -6.6221915185451508e-02
    z[0,4,6]  R543      8.4433071315288544e-02
    z[0,4,6]  R544      0.0134742995724082
    z[0,4,6]  R545      -2.3847445845603943e-01
    z[0,4,6]  R546      3.3846175670623779e-01
    z[0,4,6]  R547      -1.8444980680942535e-01
    z[0,4,6]  R548      -2.4717026948928833e-01
    z[0,4,6]  R549      1.8808794021606445e-01
    z[0,4,6]  R550      4.8864200711250305e-01
    z[0,4,6]  R551      2.0841538906097412e-01
    z[0,4,6]  R552      1.3532589375972748e-01
    z[0,4,6]  R553      -1.1271986365318298e-01
    z[0,4,6]  R554      -3.8014176487922668e-01
    z[0,4,6]  R555      -3.2353103160858154e-01
    z[0,4,6]  R556      -5.8822077512741089e-01
    z[0,4,6]  R557      -1.9484908878803253e-01
    z[0,4,6]  R558      3.6250251531600952e-01
    z[0,4,6]  R559      3.2462725043296814e-01
    z[0,4,6]  R560      2.3102736473083496e-01
    z[0,4,6]  R561      -7.5641330331563950e-03
    z[0,4,6]  R562      4.1207012534141541e-01
    z[0,4,6]  R563      2.1155847609043121e-01
    z[0,4,6]  R564      1.5869426727294922e-01
    z[0,4,6]  R565      3.2802861928939819e-01
    z[0,4,6]  R566      3.1218940019607544e-01
    z[0,4,6]  R567      0.037688959389925
    z[0,4,6]  R568      3.7482264637947083e-01
    z[0,4,6]  R569      -5.2823860198259354e-02
    z[0,4,6]  R570      1.0185701400041580e-01
    z[0,4,6]  R571      -3.0970774590969086e-02
    z[0,4,6]  R572      -9.3101290985941887e-03
    z[0,4,6]  R573      4.6769526600837708e-01
    z[0,4,6]  R574      1.3416497409343719e-01
    z[0,4,6]  R575      1.7841459810733795e-01
    z[0,4,6]  R576      2.5110137462615967e-01
    z[0,4,6]  R577      3.7090754508972168e-01
    z[0,4,6]  R578      -1.0599456727504730e-01
    z[0,4,6]  R579      -7.3094330728054047e-02
    z[0,4,6]  R580      1.6180223226547241e-01
    z[0,4,6]  R581      1.2862329185009003e-01
    z[0,4,6]  R582      -2.5219817180186510e-03
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R583      -1
    z[4,0,0]  R584      1
    z[4,0,0]  R597      2.4772234261035919e-01
    z[4,0,0]  R598      2.4696488678455353e-01
    z[4,0,0]  R599      3.6294525861740112e-01
    z[4,0,0]  R600      -8.6895838379859924e-02
    z[4,0,0]  R601      -2.8850749135017395e-01
    z[4,0,0]  R602      -5.8941280841827393e-01
    z[4,0,0]  R603      -4.5666575431823730e-01
    z[4,0,0]  R604      -6.8102669715881348e-01
    z[4,0,0]  R605      1.6378079354763031e-01
    z[4,0,0]  R606      -7.7737474441528320e-01
    z[4,0,0]  R607      4.2044779658317566e-01
    z[4,0,0]  R608      4.9880540370941162e-01
    z[4,0,0]  R609      -1.2612174451351166e-01
    z[4,0,0]  R610      -4.1878500580787659e-01
    z[4,0,0]  R611      2.1678902208805084e-01
    z[4,0,0]  R612      -1.3231416046619415e-01
    z[4,0,0]  R613      0.0712457224726677
    z[4,0,0]  R614      7.9802796244621277e-02
    z[4,0,0]  R615      -2.8022137284278870e-01
    z[4,0,0]  R616      9.2771604657173157e-02
    z[4,0,0]  R617      5.8583840727806091e-02
    z[4,0,0]  R618      3.5452548414468765e-02
    z[4,0,0]  R619      -1.6146329045295715e-01
    z[4,0,0]  R620      -4.4147886335849762e-02
    z[4,0,0]  R621      1.3029080629348755e-01
    z[4,0,0]  R622      -4.9732866883277893e-01
    z[4,0,0]  R623      -3.5069355368614197e-01
    z[4,0,0]  R624      3.1645726412534714e-02
    z[4,0,0]  R625      8.7404318153858185e-02
    z[4,0,0]  R626      -0.0250399112701416
    z[4,0,0]  R627      -2.7012780308723450e-02
    z[4,0,0]  R628      -2.1615663170814514e-01
    z[4,0,0]  R629      -2.8485766053199768e-01
    z[4,0,0]  R630      -3.6229911446571350e-01
    z[4,0,0]  R631      -6.1006546020507812e-01
    z[4,0,0]  R632      -5.8062785863876343e-01
    z[4,0,0]  R633      -6.0760623216629028e-01
    z[4,0,0]  R634      -6.4063489437103271e-02
    z[4,0,0]  R635      1.6059769690036774e-01
    z[4,0,0]  R636      1.3274246454238892e-01
    z[4,0,0]  R637      6.3208468258380890e-02
    z[4,0,0]  R638      1.0475829988718033e-01
    z[4,0,0]  R639      1.5666396915912628e-01
    z[4,0,0]  R640      2.4719725549221039e-01
    z[4,0,0]  R641      5.6741088628768921e-01
    z[4,0,0]  R642      5.1577204465866089e-01
    z[4,0,0]  R643      -6.9601279497146606e-01
    z[4,0,0]  R644      -1.3350605964660645e-01
    z[4,0,0]  R645      1.7930482327938080e-01
    z[4,0,0]  R646      -2.8537398576736450e-01
    z[4,0,0]  R647      1.6607774794101715e-01
    z[4,0,0]  R648      5.1720064133405685e-02
    z[4,0,0]  R649      -8.3205364644527435e-03
    z[4,0,0]  R650      4.0531735867261887e-02
    z[4,0,0]  R651      7.2678372263908386e-02
    z[4,0,0]  R652      0.260046124458313
    z[4,0,0]  R653      1.3106101751327515e-01
    z[4,0,0]  R654      -3.5949856042861938e-02
    z[4,0,0]  R655      2.7664564549922943e-02
    z[4,0,0]  R656      7.8953303396701813e-02
    z[4,0,0]  R657      1.5168353915214539e-01
    z[4,0,0]  R658      -3.3841833472251892e-01
    z[4,0,0]  R659      -2.2327479720115662e-01
    z[4,0,0]  R660      -2.6558920741081238e-01
    z[4,0,0]  R661      1.4662556350231171e-02
    z[4,0,0]  R662      -0.260986864566803
    z[4,0,0]  R663      -3.6370101571083069e-01
    z[4,0,0]  R664      3.5187106579542160e-02
    z[4,0,0]  R665      -1.2392750382423401e-01
    z[4,0,0]  R666      -4.5920538902282715e-01
    z[4,0,0]  R667      0.0667165070772171
    z[4,0,0]  R668      -2.9462891817092896e-01
    z[4,0,0]  R669      0.644294261932373
    z[4,0,0]  R670      -4.7134527564048767e-01
    z[4,0,0]  R671      2.8061863034963608e-02
    z[4,0,0]  R672      3.2971829175949097e-01
    z[4,0,0]  R673      6.9544982910156250e-01
    z[4,0,0]  R674      8.0374181270599365e-02
    z[4,0,0]  R675      4.4361403584480286e-01
    z[4,0,0]  R676      -2.3828917741775513e-01
    z[4,0,0]  R677      3.4130752086639404e-01
    z[4,0,0]  R678      -4.8296146094799042e-02
    z[4,0,0]  R679      -2.8567740321159363e-01
    z[4,0,0]  R680      -3.0408853292465210e-01
    z[4,0,0]  R681      7.3413014411926270e-01
    z[4,0,0]  R682      0.762452244758606
    z[4,0,0]  R683      -1.3330757617950439e-01
    z[4,0,0]  R684      0.0967952162027359
    z[4,0,0]  R685      5.4665857553482056e-01
    z[4,0,0]  R686      5.7045292854309082e-01
    z[4,0,0]  R687      4.8920072615146637e-02
    z[4,0,0]  R688      2.1173666417598724e-01
    z[4,0,0]  R689      4.0548691153526306e-01
    z[4,0,0]  R690      1.5091603994369507e-01
    z[4,0,0]  R691      6.5789061784744263e-01
    z[4,0,0]  R692      -4.8623021692037582e-02
    z[4,0,0]  R693      2.5142499804496765e-01
    z[4,0,0]  R694      1.9243241846561432e-01
    z[4,0,0]  R695      3.9235064387321472e-01
    z[4,0,0]  R696      2.9140564799308777e-01
    z[4,0,0]  R697      6.2068152427673340e-01
    z[4,0,0]  R698      -3.7842559814453125e-01
    z[4,0,0]  R699      1.0778354853391647e-01
    z[4,0,0]  R700      4.9369942396879196e-02
    z[4,0,0]  R701      -6.9795258343219757e-02
    z[4,0,0]  R702      -1.4652828872203827e-01
    z[4,0,0]  R703      0.0670105367898941
    z[4,0,0]  R704      0.550288736820221
    z[4,0,0]  R705      3.2825458794832230e-02
    z[4,0,0]  R706      -2.2199097275733948e-01
    z[4,0,0]  R707      -3.4488037228584290e-02
    z[4,0,0]  R708      1.8360415101051331e-01
    z[4,0,0]  R709      1.9765444099903107e-01
    z[4,0,0]  R710      -4.3908235430717468e-01
    z[4,0,0]  R711      -6.3887882232666016e-01
    z[4,0,0]  R712      -4.3565583229064941e-01
    z[4,0,0]  R713      -4.5687532424926758e-01
    z[4,0,0]  R714      0.084299735724926
    z[4,0,0]  R715      -4.7861550003290176e-02
    z[4,0,0]  R716      3.4174117445945740e-01
    z[4,0,0]  R717      -3.4983676671981812e-01
    z[4,0,0]  R718      -1.5232269465923309e-01
    z[4,0,0]  R719      -4.1082230210304260e-01
    z[4,0,0]  R720      -3.1880471110343933e-01
    z[4,0,0]  R721      -2.5601112842559814e-01
    z[4,0,0]  R722      -1.4790304005146027e-01
    z[4,0,0]  R723      1.4020407572388649e-02
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R585      -1
    z[4,0,1]  R586      1
    z[4,0,1]  R597      1.4595788717269897e-01
    z[4,0,1]  R598      -3.5114955902099609e-01
    z[4,0,1]  R599      -4.1777870059013367e-01
    z[4,0,1]  R600      6.1551898717880249e-02
    z[4,0,1]  R601      1.3498616218566895e-01
    z[4,0,1]  R602      -2.5606042146682739e-01
    z[4,0,1]  R603      -1.7154380679130554e-01
    z[4,0,1]  R604      -5.9940207004547119e-01
    z[4,0,1]  R605      2.0661603659391403e-02
    z[4,0,1]  R606      -3.7383487820625305e-01
    z[4,0,1]  R607      -3.1460642814636230e-01
    z[4,0,1]  R608      6.7527025938034058e-01
    z[4,0,1]  R609      -4.2850311729125679e-04
    z[4,0,1]  R610      2.1219305694103241e-02
    z[4,0,1]  R611      4.2749759554862976e-01
    z[4,0,1]  R612      4.1486227512359619e-01
    z[4,0,1]  R613      -1.2789431214332581e-01
    z[4,0,1]  R614      1.4151163399219513e-01
    z[4,0,1]  R615      3.4211838245391846e-01
    z[4,0,1]  R616      3.2706397771835327e-01
    z[4,0,1]  R617      -2.5861749053001404e-01
    z[4,0,1]  R618      1.7459358274936676e-01
    z[4,0,1]  R619      -4.4919971376657486e-02
    z[4,0,1]  R620      2.0421484112739563e-01
    z[4,0,1]  R621      4.0388610959053040e-01
    z[4,0,1]  R622      1.8536414951086044e-02
    z[4,0,1]  R623      -7.0024833083152771e-02
    z[4,0,1]  R624      3.2747775316238403e-01
    z[4,0,1]  R625      2.3994833230972290e-01
    z[4,0,1]  R626      2.8354302048683167e-01
    z[4,0,1]  R627      -4.4861879199743271e-02
    z[4,0,1]  R628      5.6180745363235474e-02
    z[4,0,1]  R629      8.0625161528587341e-02
    z[4,0,1]  R630      1.1535218358039856e-01
    z[4,0,1]  R631      -7.6415991783142090e-01
    z[4,0,1]  R632      -0.756704568862915
    z[4,0,1]  R633      -7.4083060026168823e-01
    z[4,0,1]  R634      -5.2023779600858688e-02
    z[4,0,1]  R635      1.8688815832138062e-01
    z[4,0,1]  R636      -2.0055456459522247e-01
    z[4,0,1]  R637      4.0589934587478638e-01
    z[4,0,1]  R638      -3.5552942752838135e-01
    z[4,0,1]  R639      1.1135175079107285e-01
    z[4,0,1]  R640      1.5564145147800446e-01
    z[4,0,1]  R641      -1.4409725368022919e-01
    z[4,0,1]  R642      -3.5696956515312195e-01
    z[4,0,1]  R643      -6.0474425554275513e-01
    z[4,0,1]  R644      5.9611005708575249e-03
    z[4,0,1]  R645      -1.3778430223464966e-01
    z[4,0,1]  R646      1.5254957973957062e-01
    z[4,0,1]  R647      4.2437443137168884e-01
    z[4,0,1]  R648      -3.2389974594116211e-01
    z[4,0,1]  R649      -3.8495957851409912e-01
    z[4,0,1]  R650      -5.0874465703964233e-01
    z[4,0,1]  R651      -3.6350693553686142e-02
    z[4,0,1]  R652      0.101785808801651
    z[4,0,1]  R653      1.9338355958461761e-01
    z[4,0,1]  R654      4.4235434383153915e-02
    z[4,0,1]  R655      -5.3629451990127563e-01
    z[4,0,1]  R656      0.81854248046875
    z[4,0,1]  R657      6.3725358247756958e-01
    z[4,0,1]  R658      -1.5819889307022095e-01
    z[4,0,1]  R659      4.4261854887008667e-01
    z[4,0,1]  R660      -4.1794739663600922e-02
    z[4,0,1]  R661      8.7619268894195557e-01
    z[4,0,1]  R662      1.1899554729461670e-01
    z[4,0,1]  R663      3.3444416522979736e-01
    z[4,0,1]  R664      -2.4165698885917664e-01
    z[4,0,1]  R665      2.8275391459465027e-01
    z[4,0,1]  R666      3.5537354648113251e-02
    z[4,0,1]  R667      -7.6254919171333313e-02
    z[4,0,1]  R668      -4.0073856711387634e-02
    z[4,0,1]  R669      0.0935761034488678
    z[4,0,1]  R670      -2.2781632840633392e-01
    z[4,0,1]  R671      0.36614990234375
    z[4,0,1]  R672      2.5656276941299438e-01
    z[4,0,1]  R673      3.1483608484268188e-01
    z[4,0,1]  R674      5.7906292378902435e-02
    z[4,0,1]  R675      7.1568292379379272e-01
    z[4,0,1]  R676      -3.4410279989242554e-01
    z[4,0,1]  R677      2.2935485467314720e-03
    z[4,0,1]  R678      0.634415328502655
    z[4,0,1]  R679      7.4076700210571289e-01
    z[4,0,1]  R680      5.5692654848098755e-01
    z[4,0,1]  R681      6.0079181194305420e-01
    z[4,0,1]  R682      5.2259796857833862e-01
    z[4,0,1]  R683      -9.6683973073959351e-01
    z[4,0,1]  R684      3.7239167094230652e-01
    z[4,0,1]  R685      -5.7963605970144272e-02
    z[4,0,1]  R686      -4.1433505713939667e-02
    z[4,0,1]  R687      -6.8225346505641937e-02
    z[4,0,1]  R688      -1.5415996313095093e-01
    z[4,0,1]  R689      -3.3002066612243652e-01
    z[4,0,1]  R690      -0.294149249792099
    z[4,0,1]  R691      3.0904176831245422e-01
    z[4,0,1]  R692      1.3697081804275513e-01
    z[4,0,1]  R693      0.750571072101593
    z[4,0,1]  R694      -3.0818048119544983e-01
    z[4,0,1]  R695      2.4123266339302063e-01
    z[4,0,1]  R696      1.3480287790298462e-01
    z[4,0,1]  R697      1.3289435207843781e-01
    z[4,0,1]  R698      -2.2830264270305634e-01
    z[4,0,1]  R699      3.2131770253181458e-01
    z[4,0,1]  R700      -2.1391832828521729e-01
    z[4,0,1]  R701      2.7872404456138611e-01
    z[4,0,1]  R702      -2.0348201692104340e-01
    z[4,0,1]  R703      6.0059273242950439e-01
    z[4,0,1]  R704      1.6556029021739960e-01
    z[4,0,1]  R705      -1.4329962432384491e-01
    z[4,0,1]  R706      2.1220651268959045e-01
    z[4,0,1]  R707      -1.6914875805377960e-01
    z[4,0,1]  R708      -1.4743930101394653e-01
    z[4,0,1]  R709      -1.7499189078807831e-01
    z[4,0,1]  R710      -3.5884156823158264e-01
    z[4,0,1]  R711      5.8143043518066406e-01
    z[4,0,1]  R712      -8.5988634824752808e-01
    z[4,0,1]  R713      -8.2960969209671021e-01
    z[4,0,1]  R714      2.7405783534049988e-01
    z[4,0,1]  R715      1.1639898270368576e-01
    z[4,0,1]  R716      -9.9900364875793457e-02
    z[4,0,1]  R717      -1.8450449407100677e-01
    z[4,0,1]  R718      -9.3087553977966309e-01
    z[4,0,1]  R719      -8.3404815196990967e-01
    z[4,0,1]  R720      -0.841460645198822
    z[4,0,1]  R721      -8.5124516487121582e-01
    z[4,0,1]  R722      -3.2479953765869141e-01
    z[4,0,1]  R723      -9.0595930814743042e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R587      -1
    z[4,0,2]  R588      1
    z[4,0,2]  R597      2.2578868269920349e-01
    z[4,0,2]  R598      -4.8831388354301453e-01
    z[4,0,2]  R599      2.3956601321697235e-01
    z[4,0,2]  R600      -9.2622911930084229e-01
    z[4,0,2]  R601      -5.6925896555185318e-02
    z[4,0,2]  R602      1.8781113624572754e-01
    z[4,0,2]  R603      4.5199862122535706e-01
    z[4,0,2]  R604      2.2137674689292908e-01
    z[4,0,2]  R605      3.0540555715560913e-01
    z[4,0,2]  R606      1.8160057067871094e-01
    z[4,0,2]  R607      1.8379474058747292e-02
    z[4,0,2]  R608      1.0136752575635910e-01
    z[4,0,2]  R609      0.719666063785553
    z[4,0,2]  R610      -3.1923856586217880e-02
    z[4,0,2]  R611      -1.0549058765172958e-01
    z[4,0,2]  R612      1.2692656368017197e-02
    z[4,0,2]  R613      -0.097258560359478
    z[4,0,2]  R614      2.4996910989284515e-01
    z[4,0,2]  R615      4.1910886764526367e-02
    z[4,0,2]  R616      3.1649264693260193e-01
    z[4,0,2]  R617      -3.3787362277507782e-02
    z[4,0,2]  R618      -3.2035586237907410e-01
    z[4,0,2]  R619      6.3951745629310608e-02
    z[4,0,2]  R620      0.658301830291748
    z[4,0,2]  R621      4.8984782770276070e-03
    z[4,0,2]  R622      3.0478018522262573e-01
    z[4,0,2]  R623      6.9895529747009277e-01
    z[4,0,2]  R624      8.5863113403320312e-02
    z[4,0,2]  R625      -1.6348041594028473e-02
    z[4,0,2]  R626      1.1734221875667572e-01
    z[4,0,2]  R627      -1.5207682549953461e-01
    z[4,0,2]  R628      4.1668361425399780e-01
    z[4,0,2]  R629      1.6104342043399811e-01
    z[4,0,2]  R630      2.7280882000923157e-01
    z[4,0,2]  R631      5.7944428175687790e-02
    z[4,0,2]  R632      1.0019752383232117e-01
    z[4,0,2]  R633      1.4930146932601929e-01
    z[4,0,2]  R634      -5.6777913123369217e-02
    z[4,0,2]  R635      1.0353393852710724e-01
    z[4,0,2]  R636      -3.2702925801277161e-01
    z[4,0,2]  R637      -1.2539622187614441e-01
    z[4,0,2]  R638      -2.3582690954208374e-01
    z[4,0,2]  R639      -3.1900930404663086e-01
    z[4,0,2]  R640      -2.7136135101318359e-01
    z[4,0,2]  R641      4.4235885143280029e-02
    z[4,0,2]  R642      3.3006185293197632e-01
    z[4,0,2]  R643      2.7378043532371521e-01
    z[4,0,2]  R644      2.8532043099403381e-01
    z[4,0,2]  R645      -1.7149317264556885e-01
    z[4,0,2]  R646      8.2180345058441162e-01
    z[4,0,2]  R647      -6.7168600857257843e-02
    z[4,0,2]  R648      -1.7426814138889313e-01
    z[4,0,2]  R649      1.7528069019317627e-01
    z[4,0,2]  R650      -1.4055498875677586e-02
    z[4,0,2]  R651      3.2149147987365723e-01
    z[4,0,2]  R652      8.6558210849761963e-01
    z[4,0,2]  R653      9.3931305408477783e-01
    z[4,0,2]  R654      7.3067253828048706e-01
    z[4,0,2]  R655      -2.2591440379619598e-01
    z[4,0,2]  R656      -1.5671806037425995e-01
    z[4,0,2]  R657      5.5256050825119019e-01
    z[4,0,2]  R658      0.467549592256546
    z[4,0,2]  R659      -3.3615368604660034e-01
    z[4,0,2]  R660      3.6083319783210754e-01
    z[4,0,2]  R661      6.0788080096244812e-02
    z[4,0,2]  R662      -1.4985999464988708e-01
    z[4,0,2]  R663      2.6378521323204041e-01
    z[4,0,2]  R664      -3.1577392946928740e-03
    z[4,0,2]  R665      -2.0002222061157227e-01
    z[4,0,2]  R666      2.6407885551452637e-01
    z[4,0,2]  R667      -2.5432729721069336e-01
    z[4,0,2]  R668      -3.1636923551559448e-01
    z[4,0,2]  R669      -2.6361331343650818e-01
    z[4,0,2]  R670      -1.0337930172681808e-01
    z[4,0,2]  R671      4.4319942593574524e-01
    z[4,0,2]  R672      3.6318498849868774e-01
    z[4,0,2]  R673      2.8820511698722839e-01
    z[4,0,2]  R674      -3.6796236038208008e-01
    z[4,0,2]  R675      2.7848687767982483e-01
    z[4,0,2]  R676      -3.0173275619745255e-02
    z[4,0,2]  R677      7.3003798723220825e-01
    z[4,0,2]  R678      -1.7617985606193542e-01
    z[4,0,2]  R679      -8.4466069936752319e-02
    z[4,0,2]  R680      1.8327631056308746e-01
    z[4,0,2]  R681      -6.3278481364250183e-02
    z[4,0,2]  R682      -1.6766825318336487e-01
    z[4,0,2]  R683      1.3303583860397339e-01
    z[4,0,2]  R684      2.4208576977252960e-01
    z[4,0,2]  R685      -0.179097518324852
    z[4,0,2]  R686      1.1233936063945293e-02
    z[4,0,2]  R687      4.3308448791503906e-01
    z[4,0,2]  R688      2.5103539228439331e-01
    z[4,0,2]  R689      4.5756268501281738e-01
    z[4,0,2]  R690      4.3825164437294006e-01
    z[4,0,2]  R691      0.348513126373291
    z[4,0,2]  R692      3.1630018353462219e-01
    z[4,0,2]  R693      -4.0792483091354370e-01
    z[4,0,2]  R694      -1.5815148130059242e-02
    z[4,0,2]  R695      1.3097250461578369e-01
    z[4,0,2]  R696      5.2823996543884277e-01
    z[4,0,2]  R697      -2.1121042966842651e-01
    z[4,0,2]  R698      -8.3415031433105469e-02
    z[4,0,2]  R699      -1.9119301438331604e-01
    z[4,0,2]  R700      5.0723668187856674e-02
    z[4,0,2]  R701      1.6085717082023621e-01
    z[4,0,2]  R702      8.1871229410171509e-01
    z[4,0,2]  R703      4.4781997799873352e-01
    z[4,0,2]  R704      -2.5352808833122253e-01
    z[4,0,2]  R705      1.1890961229801178e-01
    z[4,0,2]  R706      5.4404580593109131e-01
    z[4,0,2]  R707      2.9344305396080017e-01
    z[4,0,2]  R708      0.0649917870759964
    z[4,0,2]  R709      3.0003413558006287e-01
    z[4,0,2]  R710      5.0687056779861450e-01
    z[4,0,2]  R711      1.9926688075065613e-01
    z[4,0,2]  R712      2.7861837297677994e-02
    z[4,0,2]  R713      6.4635850489139557e-02
    z[4,0,2]  R714      -2.6343947649002075e-01
    z[4,0,2]  R715      7.1777254343032837e-02
    z[4,0,2]  R716      6.4623379707336426e-01
    z[4,0,2]  R717      4.6222358942031860e-01
    z[4,0,2]  R718      -0.252784788608551
    z[4,0,2]  R719      -1.6858577728271484e-01
    z[4,0,2]  R720      -2.5062909722328186e-01
    z[4,0,2]  R721      -0.354160875082016
    z[4,0,2]  R722      -1.4349471032619476e-01
    z[4,0,2]  R723      1.0102648288011551e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R589      -1
    z[4,0,3]  R590      1
    z[4,0,3]  R597      -8.6045974493026733e-01
    z[4,0,3]  R598      -1.4862245321273804e-01
    z[4,0,3]  R599      -1.6409538686275482e-02
    z[4,0,3]  R600      -2.5952234864234924e-01
    z[4,0,3]  R601      1.7812801524996758e-02
    z[4,0,3]  R602      8.6579039692878723e-02
    z[4,0,3]  R603      8.2425296306610107e-02
    z[4,0,3]  R604      -8.2052469253540039e-02
    z[4,0,3]  R605      3.0150455236434937e-01
    z[4,0,3]  R606      -1.7092892527580261e-01
    z[4,0,3]  R607      -8.4106504917144775e-02
    z[4,0,3]  R608      2.7513271570205688e-01
    z[4,0,3]  R609      4.0931177139282227e-01
    z[4,0,3]  R610      6.1861896514892578e-01
    z[4,0,3]  R611      5.9167939424514771e-01
    z[4,0,3]  R612      5.5876374244689941e-01
    z[4,0,3]  R613      3.9200946688652039e-01
    z[4,0,3]  R614      4.5328933000564575e-01
    z[4,0,3]  R615      4.8418885469436646e-01
    z[4,0,3]  R616      4.8538509011268616e-01
    z[4,0,3]  R617      0.664361834526062
    z[4,0,3]  R618      0.720909833908081
    z[4,0,3]  R619      0.516990602016449
    z[4,0,3]  R620      6.9094288349151611e-01
    z[4,0,3]  R621      5.9732836484909058e-01
    z[4,0,3]  R622      6.3530176877975464e-01
    z[4,0,3]  R623      0.408335417509079
    z[4,0,3]  R624      5.4951918125152588e-01
    z[4,0,3]  R625      4.5598819851875305e-01
    z[4,0,3]  R626      6.2091869115829468e-01
    z[4,0,3]  R627      7.3603373765945435e-01
    z[4,0,3]  R628      6.5980148315429688e-01
    z[4,0,3]  R629      6.3465386629104614e-01
    z[4,0,3]  R630      0.608033299446106
    z[4,0,3]  R631      -1.8308252096176147e-02
    z[4,0,3]  R632      -1.7723189294338226e-01
    z[4,0,3]  R633      1.3498324155807495e-01
    z[4,0,3]  R634      -9.2928916215896606e-01
    z[4,0,3]  R635      -0.804606556892395
    z[4,0,3]  R636      -8.5726940631866455e-01
    z[4,0,3]  R637      -8.5723048448562622e-01
    z[4,0,3]  R638      -8.0125230550765991e-01
    z[4,0,3]  R639      -7.1358543634414673e-01
    z[4,0,3]  R640      -7.9580336809158325e-01
    z[4,0,3]  R641      -1.5711851418018341e-01
    z[4,0,3]  R642      -2.7160879969596863e-01
    z[4,0,3]  R643      -1.3891610503196716e-01
    z[4,0,3]  R644      3.8556548953056335e-01
    z[4,0,3]  R645      4.3534025549888611e-01
    z[4,0,3]  R646      1.7657354474067688e-01
    z[4,0,3]  R647      3.9180862903594971e-01
    z[4,0,3]  R648      2.4762172996997833e-01
    z[4,0,3]  R649      2.9850077629089355e-01
    z[4,0,3]  R650      5.1189678907394409e-01
    z[4,0,3]  R651      3.6862105131149292e-01
    z[4,0,3]  R652      2.1526399254798889e-01
    z[4,0,3]  R653      1.1522676795721054e-01
    z[4,0,3]  R654      4.4608378410339355e-01
    z[4,0,3]  R655      5.6817245483398438e-01
    z[4,0,3]  R656      2.0419143140316010e-01
    z[4,0,3]  R657      -2.1266290545463562e-01
    z[4,0,3]  R658      6.1207717657089233e-01
    z[4,0,3]  R659      2.3714180290699005e-01
    z[4,0,3]  R660      1.5064767003059387e-01
    z[4,0,3]  R661      3.3175039291381836e-01
    z[4,0,3]  R662      7.5979363918304443e-01
    z[4,0,3]  R663      6.5049648284912109e-01
    z[4,0,3]  R664      5.3698408603668213e-01
    z[4,0,3]  R665      4.9911034107208252e-01
    z[4,0,3]  R666      5.5468392372131348e-01
    z[4,0,3]  R667      5.2799969911575317e-01
    z[4,0,3]  R668      4.9183416366577148e-01
    z[4,0,3]  R669      -1.7968240380287170e-01
    z[4,0,3]  R670      5.0459164381027222e-01
    z[4,0,3]  R671      3.0800908803939819e-01
    z[4,0,3]  R672      6.0138350725173950e-01
    z[4,0,3]  R673      -2.4376663565635681e-01
    z[4,0,3]  R674      6.8626904487609863e-01
    z[4,0,3]  R675      -3.3575016260147095e-01
    z[4,0,3]  R676      6.3144260644912720e-01
    z[4,0,3]  R677      4.2121031880378723e-01
    z[4,0,3]  R678      5.6819815188646317e-02
    z[4,0,3]  R679      0.336073100566864
    z[4,0,3]  R680      1.5416452288627625e-01
    z[4,0,3]  R681      2.4057245254516602e-01
    z[4,0,3]  R682      1.6548976302146912e-01
    z[4,0,3]  R683      -9.2471368610858917e-02
    z[4,0,3]  R684      5.3288924694061279e-01
    z[4,0,3]  R685      -0.455875039100647
    z[4,0,3]  R686      -3.8344934582710266e-01
    z[4,0,3]  R687      0.614128053188324
    z[4,0,3]  R688      0.767065703868866
    z[4,0,3]  R689      3.5107195377349854e-01
    z[4,0,3]  R690      6.2618285417556763e-01
    z[4,0,3]  R691      -3.4679338335990906e-01
    z[4,0,3]  R692      5.5651229619979858e-01
    z[4,0,3]  R693      1.9736245274543762e-01
    z[4,0,3]  R694      -8.5408180952072144e-01
    z[4,0,3]  R695      -5.5037140846252441e-01
    z[4,0,3]  R696      -7.3549979925155640e-01
    z[4,0,3]  R697      -4.9482280015945435e-01
    z[4,0,3]  R698      6.7564916610717773e-01
    z[4,0,3]  R699      6.6907513141632080e-01
    z[4,0,3]  R700      8.2581186294555664e-01
    z[4,0,3]  R701      0.79014652967453
    z[4,0,3]  R702      1.7215198278427124e-01
    z[4,0,3]  R703      5.8378702402114868e-01
    z[4,0,3]  R704      -0.62684565782547
    z[4,0,3]  R705      0.827559769153595
    z[4,0,3]  R706      6.0564368963241577e-01
    z[4,0,3]  R707      6.2602764368057251e-01
    z[4,0,3]  R708      2.5464054942131042e-01
    z[4,0,3]  R709      4.9707618355751038e-01
    z[4,0,3]  R710      2.4635070562362671e-01
    z[4,0,3]  R711      7.9420171678066254e-03
    z[4,0,3]  R712      7.3591373860836029e-02
    z[4,0,3]  R713      -1.1864126473665237e-01
    z[4,0,3]  R714      7.1144467592239380e-01
    z[4,0,3]  R715      -6.2321805953979492e-01
    z[4,0,3]  R716      0.448964923620224
    z[4,0,3]  R717      1.6619957983493805e-01
    z[4,0,3]  R718      1.0466784238815308e-01
    z[4,0,3]  R719      1.7910125851631165e-01
    z[4,0,3]  R720      3.1129390001296997e-01
    z[4,0,3]  R721      2.0030494779348373e-02
    z[4,0,3]  R722      9.6967602148652077e-03
    z[4,0,3]  R723      2.0940619707107544e-01
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R591      -1
    z[4,0,4]  R592      1
    z[4,0,4]  R597      -4.3812990188598633e-02
    z[4,0,4]  R598      -2.3397125303745270e-01
    z[4,0,4]  R599      4.8334822058677673e-01
    z[4,0,4]  R600      8.1369958817958832e-02
    z[4,0,4]  R601      4.1641953587532043e-01
    z[4,0,4]  R602      -7.0744216442108154e-01
    z[4,0,4]  R603      -7.0412427186965942e-01
    z[4,0,4]  R604      -3.2751148939132690e-01
    z[4,0,4]  R605      -7.7893167734146118e-01
    z[4,0,4]  R606      -1.9485269486904144e-01
    z[4,0,4]  R607      -1.3611069321632385e-01
    z[4,0,4]  R608      3.5755693912506104e-01
    z[4,0,4]  R609      9.4899103045463562e-02
    z[4,0,4]  R610      -5.7386392354965210e-01
    z[4,0,4]  R611      -5.0568145513534546e-01
    z[4,0,4]  R612      -0.574921190738678
    z[4,0,4]  R613      -7.2078096866607666e-01
    z[4,0,4]  R614      -8.1240636110305786e-01
    z[4,0,4]  R615      -7.3139494657516479e-01
    z[4,0,4]  R616      -4.9469089508056641e-01
    z[4,0,4]  R617      -6.0339617729187012e-01
    z[4,0,4]  R618      -5.5495953559875488e-01
    z[4,0,4]  R619      -5.7392561435699463e-01
    z[4,0,4]  R620      1.4989911019802094e-01
    z[4,0,4]  R621      -6.0175734758377075e-01
    z[4,0,4]  R622      9.2814810574054718e-02
    z[4,0,4]  R623      1.5847903490066528e-01
    z[4,0,4]  R624      -5.4320687055587769e-01
    z[4,0,4]  R625      -8.4174668788909912e-01
    z[4,0,4]  R626      -6.2490385770797729e-01
    z[4,0,4]  R627      -6.0696178674697876e-01
    z[4,0,4]  R628      2.7905102819204330e-02
    z[4,0,4]  R629      -6.7005246877670288e-01
    z[4,0,4]  R630      -6.2093317508697510e-01
    z[4,0,4]  R631      4.1517388075590134e-02
    z[4,0,4]  R632      -1.3797618448734283e-01
    z[4,0,4]  R633      -1.8680550158023834e-01
    z[4,0,4]  R634      2.9850891232490540e-01
    z[4,0,4]  R635      1.0379948467016220e-01
    z[4,0,4]  R636      6.7134196870028973e-03
    z[4,0,4]  R637      -2.4092530831694603e-02
    z[4,0,4]  R638      3.4442999958992004e-01
    z[4,0,4]  R639      -5.1885211467742920e-01
    z[4,0,4]  R640      3.5841333866119385e-01
    z[4,0,4]  R641      -4.1127124428749084e-01
    z[4,0,4]  R642      8.8618598878383636e-02
    z[4,0,4]  R643      2.2265779972076416e-01
    z[4,0,4]  R644      -4.9502938985824585e-01
    z[4,0,4]  R645      -8.5293418169021606e-01
    z[4,0,4]  R646      3.3291608095169067e-01
    z[4,0,4]  R647      -7.1162384748458862e-01
    z[4,0,4]  R648      -7.4344772100448608e-01
    z[4,0,4]  R649      -7.7911502122879028e-01
    z[4,0,4]  R650      -0.671019434928894
    z[4,0,4]  R651      -8.1939530372619629e-01
    z[4,0,4]  R652      2.0195983350276947e-01
    z[4,0,4]  R653      2.0293138921260834e-01
    z[4,0,4]  R654      4.4607225060462952e-01
    z[4,0,4]  R655      -4.4644799828529358e-01
    z[4,0,4]  R656      8.7363161146640778e-03
    z[4,0,4]  R657      3.6340811848640442e-01
    z[4,0,4]  R658      -2.9440057277679443e-01
    z[4,0,4]  R659      -3.7326484918594360e-01
    z[4,0,4]  R660      2.4924322962760925e-01
    z[4,0,4]  R661      3.0503988265991211e-01
    z[4,0,4]  R662      -7.0223741233348846e-02
    z[4,0,4]  R663      -1.9835433363914490e-01
    z[4,0,4]  R664      -7.0246893167495728e-01
    z[4,0,4]  R665      -0.702630341053009
    z[4,0,4]  R666      0.272499144077301
    z[4,0,4]  R667      -6.6848033666610718e-01
    z[4,0,4]  R668      -5.1927280426025391e-01
    z[4,0,4]  R669      -0.247806116938591
    z[4,0,4]  R670      -3.1744873523712158e-01
    z[4,0,4]  R671      -6.3552063703536987e-01
    z[4,0,4]  R672      -4.9319875240325928e-01
    z[4,0,4]  R673      -4.1530814766883850e-01
    z[4,0,4]  R674      -5.6754702329635620e-01
    z[4,0,4]  R675      2.3077231645584106e-01
    z[4,0,4]  R676      -4.7983753681182861e-01
    z[4,0,4]  R677      3.4534502029418945e-01
    z[4,0,4]  R678      4.1923069953918457e-01
    z[4,0,4]  R679      4.8716527223587036e-01
    z[4,0,4]  R680      4.9648800492286682e-01
    z[4,0,4]  R681      -1.5960346907377243e-02
    z[4,0,4]  R682      -6.6549576818943024e-02
    z[4,0,4]  R683      -1.2255188077688217e-01
    z[4,0,4]  R684      -6.6290569305419922e-01
    z[4,0,4]  R685      -3.7945404648780823e-01
    z[4,0,4]  R686      2.0986701548099518e-01
    z[4,0,4]  R687      2.1012732386589050e-01
    z[4,0,4]  R688      -0.489188551902771
    z[4,0,4]  R689      -3.6255702376365662e-02
    z[4,0,4]  R690      -5.0594764947891235e-01
    z[4,0,4]  R691      -3.7479439377784729e-01
    z[4,0,4]  R692      -4.5726552605628967e-01
    z[4,0,4]  R693      2.2959679365158081e-01
    z[4,0,4]  R694      -3.2122680544853210e-01
    z[4,0,4]  R695      -1.9119140505790710e-01
    z[4,0,4]  R696      -1.7439144849777222e-01
    z[4,0,4]  R697      -4.4242069125175476e-01
    z[4,0,4]  R698      -4.1691732406616211e-01
    z[4,0,4]  R699      -5.6202590465545654e-01
    z[4,0,4]  R700      -0.505794107913971
    z[4,0,4]  R701      -3.8944569230079651e-01
    z[4,0,4]  R702      2.2215992212295532e-01
    z[4,0,4]  R703      2.6274007558822632e-01
    z[4,0,4]  R704      -4.0438213944435120e-01
    z[4,0,4]  R705      -5.2583914995193481e-01
    z[4,0,4]  R706      2.2356854379177094e-01
    z[4,0,4]  R707      -4.9322238564491272e-01
    z[4,0,4]  R708      -8.0460679531097412e-01
    z[4,0,4]  R709      1.6704671084880829e-01
    z[4,0,4]  R710      -2.9823830351233482e-02
    z[4,0,4]  R711      4.2493402957916260e-01
    z[4,0,4]  R712      2.2571101784706116e-01
    z[4,0,4]  R713      1.7069098353385925e-01
    z[4,0,4]  R714      -5.4182070493698120e-01
    z[4,0,4]  R715      2.2802498936653137e-01
    z[4,0,4]  R716      1.1553851515054703e-01
    z[4,0,4]  R717      3.4038805961608887e-01
    z[4,0,4]  R718      -4.0117930620908737e-02
    z[4,0,4]  R719      -2.6049926877021790e-02
    z[4,0,4]  R720      1.1090749502182007e-01
    z[4,0,4]  R721      -3.5114653408527374e-02
    z[4,0,4]  R722      6.0660088062286377e-01
    z[4,0,4]  R723      6.9004237651824951e-02
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R593      -1
    z[4,0,5]  R594      1
    z[4,0,5]  R597      0.0973777249455452
    z[4,0,5]  R598      -6.8293410539627075e-01
    z[4,0,5]  R599      -5.8425325155258179e-01
    z[4,0,5]  R600      -1.4632146060466766e-01
    z[4,0,5]  R601      -6.9484394788742065e-01
    z[4,0,5]  R602      1.8580364063382149e-02
    z[4,0,5]  R603      1.9190703332424164e-01
    z[4,0,5]  R604      3.4785460680723190e-02
    z[4,0,5]  R605      1.9320763647556305e-01
    z[4,0,5]  R606      2.2605451941490173e-01
    z[4,0,5]  R607      5.9355276823043823e-01
    z[4,0,5]  R608      2.0836704969406128e-01
    z[4,0,5]  R609      3.9777347445487976e-01
    z[4,0,5]  R610      7.5879737734794617e-02
    z[4,0,5]  R611      3.1614589691162109e-01
    z[4,0,5]  R612      4.0916091203689575e-01
    z[4,0,5]  R613      3.5511884093284607e-01
    z[4,0,5]  R614      -2.9819600284099579e-02
    z[4,0,5]  R615      9.0072564780712128e-02
    z[4,0,5]  R616      4.4309636950492859e-01
    z[4,0,5]  R617      1.6005451977252960e-01
    z[4,0,5]  R618      1.9110429286956787e-01
    z[4,0,5]  R619      4.8027086257934570e-01
    z[4,0,5]  R620      1.4256159961223602e-01
    z[4,0,5]  R621      3.0097925662994385e-01
    z[4,0,5]  R622      4.9623328447341919e-01
    z[4,0,5]  R623      4.3775799870491028e-01
    z[4,0,5]  R624      2.6191705465316772e-01
    z[4,0,5]  R625      7.4255662038922310e-03
    z[4,0,5]  R626      -3.1197839975357056e-01
    z[4,0,5]  R627      3.0499780550599098e-02
    z[4,0,5]  R628      4.5033949613571167e-01
    z[4,0,5]  R629      -1.5306897461414337e-01
    z[4,0,5]  R630      1.4283972978591919e-01
    z[4,0,5]  R631      1.1083095520734787e-01
    z[4,0,5]  R632      1.1505434662103653e-01
    z[4,0,5]  R633      8.1059344112873077e-02
    z[4,0,5]  R634      -2.7762185782194138e-02
    z[4,0,5]  R635      -4.2355707287788391e-01
    z[4,0,5]  R636      -2.8850415349006653e-01
    z[4,0,5]  R637      8.6988382041454315e-02
    z[4,0,5]  R638      4.0703356266021729e-02
    z[4,0,5]  R639      3.9076272398233414e-02
    z[4,0,5]  R640      1.0142208635807037e-01
    z[4,0,5]  R641      -6.7737591266632080e-01
    z[4,0,5]  R642      -5.8848005533218384e-01
    z[4,0,5]  R643      4.9932379275560379e-02
    z[4,0,5]  R644      3.2726475596427917e-01
    z[4,0,5]  R645      8.3617325872182846e-03
    z[4,0,5]  R646      1.6888137161731720e-01
    z[4,0,5]  R647      3.5665473341941833e-01
    z[4,0,5]  R648      4.9061697721481323e-01
    z[4,0,5]  R649      3.3408010005950928e-01
    z[4,0,5]  R650      1.5271255373954773e-01
    z[4,0,5]  R651      1.5786384046077728e-01
    z[4,0,5]  R652      9.0284220874309540e-02
    z[4,0,5]  R653      9.1893002390861511e-02
    z[4,0,5]  R654      1.6373126208782196e-01
    z[4,0,5]  R655      -5.2146852016448975e-02
    z[4,0,5]  R656      4.7652739286422729e-01
    z[4,0,5]  R657      2.7792543172836304e-01
    z[4,0,5]  R658      3.6418086290359497e-01
    z[4,0,5]  R659      4.4458580017089844e-01
    z[4,0,5]  R660      8.2012486457824707e-01
    z[4,0,5]  R661      -1.5312202274799347e-01
    z[4,0,5]  R662      5.3218954801559448e-01
    z[4,0,5]  R663      3.9623332023620605e-01
    z[4,0,5]  R664      0.326760470867157
    z[4,0,5]  R665      1.3923436403274536e-01
    z[4,0,5]  R666      5.7900595664978027e-01
    z[4,0,5]  R667      4.2071428894996643e-01
    z[4,0,5]  R668      5.3725987672805786e-01
    z[4,0,5]  R669      -5.8837610483169556e-01
    z[4,0,5]  R670      5.7882612943649292e-01
    z[4,0,5]  R671      2.9531732201576233e-01
    z[4,0,5]  R672      -2.9737564921379089e-01
    z[4,0,5]  R673      7.7173076570034027e-02
    z[4,0,5]  R674      1.9338364899158478e-01
    z[4,0,5]  R675      -1.0505378013476729e-03
    z[4,0,5]  R676      4.4149649143218994e-01
    z[4,0,5]  R677      2.2492264211177826e-01
    z[4,0,5]  R678      -5.8490353822708130e-01
    z[4,0,5]  R679      6.3682332634925842e-02
    z[4,0,5]  R680      -3.8847097754478455e-01
    z[4,0,5]  R681      -5.6462105363607407e-02
    z[4,0,5]  R682      2.9099500179290771e-01
    z[4,0,5]  R683      6.9737970829010010e-02
    z[4,0,5]  R684      2.2050644457340240e-01
    z[4,0,5]  R685      3.4751009941101074e-01
    z[4,0,5]  R686      -6.1318314075469971e-01
    z[4,0,5]  R687      4.1727980971336365e-01
    z[4,0,5]  R688      1.9269576296210289e-02
    z[4,0,5]  R689      5.6343454122543335e-01
    z[4,0,5]  R690      -2.2268386185169220e-01
    z[4,0,5]  R691      1.2859074771404266e-01
    z[4,0,5]  R692      -4.2583969235420227e-01
    z[4,0,5]  R693      -2.5887307524681091e-01
    z[4,0,5]  R694      -5.3237382322549820e-02
    z[4,0,5]  R695      5.8502310514450073e-01
    z[4,0,5]  R696      1.9193184375762939e-01
    z[4,0,5]  R697      1.0772937536239624e-01
    z[4,0,5]  R698      3.7983378767967224e-01
    z[4,0,5]  R699      -2.5783991813659668e-01
    z[4,0,5]  R700      -9.3516901135444641e-02
    z[4,0,5]  R701      -2.3123618960380554e-01
    z[4,0,5]  R702      4.2595624923706055e-01
    z[4,0,5]  R703      -1.4268389344215393e-01
    z[4,0,5]  R704      0.0777122750878334
    z[4,0,5]  R705      -5.3333669900894165e-02
    z[4,0,5]  R706      1.9997552037239075e-01
    z[4,0,5]  R707      4.8900499939918518e-01
    z[4,0,5]  R708      4.7088339924812317e-01
    z[4,0,5]  R709      6.0139906406402588e-01
    z[4,0,5]  R710      5.2955496311187744e-01
    z[4,0,5]  R711      -1.8144200742244720e-01
    z[4,0,5]  R712      1.1370515823364258e-01
    z[4,0,5]  R713      -4.7502916306257248e-02
    z[4,0,5]  R714      -9.1118104755878448e-02
    z[4,0,5]  R715      7.1925801038742065e-01
    z[4,0,5]  R716      4.3071508407592773e-01
    z[4,0,5]  R717      6.1889731884002686e-01
    z[4,0,5]  R718      2.2198554128408432e-02
    z[4,0,5]  R719      -1.8600904941558838e-01
    z[4,0,5]  R720      -1.1791043728590012e-01
    z[4,0,5]  R721      -2.7503988146781921e-01
    z[4,0,5]  R722      -6.9555658102035522e-01
    z[4,0,5]  R723      -2.5169846415519714e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R595      -1
    z[4,0,6]  R596      1
    z[4,0,6]  R597      3.3846175670623779e-01
    z[4,0,6]  R598      -1.8444980680942535e-01
    z[4,0,6]  R599      -2.4717026948928833e-01
    z[4,0,6]  R600      1.8808794021606445e-01
    z[4,0,6]  R601      4.8864200711250305e-01
    z[4,0,6]  R602      2.0841538906097412e-01
    z[4,0,6]  R603      1.3532589375972748e-01
    z[4,0,6]  R604      -1.1271986365318298e-01
    z[4,0,6]  R605      -3.8014176487922668e-01
    z[4,0,6]  R606      -3.2353103160858154e-01
    z[4,0,6]  R607      -5.8822077512741089e-01
    z[4,0,6]  R608      -1.9484908878803253e-01
    z[4,0,6]  R609      3.6250251531600952e-01
    z[4,0,6]  R610      3.2462725043296814e-01
    z[4,0,6]  R611      2.3102736473083496e-01
    z[4,0,6]  R612      -7.5641330331563950e-03
    z[4,0,6]  R613      4.1207012534141541e-01
    z[4,0,6]  R614      2.1155847609043121e-01
    z[4,0,6]  R615      1.5869426727294922e-01
    z[4,0,6]  R616      3.2802861928939819e-01
    z[4,0,6]  R617      3.1218940019607544e-01
    z[4,0,6]  R618      0.037688959389925
    z[4,0,6]  R619      3.7482264637947083e-01
    z[4,0,6]  R620      -5.2823860198259354e-02
    z[4,0,6]  R621      1.0185701400041580e-01
    z[4,0,6]  R622      -3.0970774590969086e-02
    z[4,0,6]  R623      -9.3101290985941887e-03
    z[4,0,6]  R624      4.6769526600837708e-01
    z[4,0,6]  R625      1.3416497409343719e-01
    z[4,0,6]  R626      1.7841459810733795e-01
    z[4,0,6]  R627      2.5110137462615967e-01
    z[4,0,6]  R628      3.7090754508972168e-01
    z[4,0,6]  R629      -1.0599456727504730e-01
    z[4,0,6]  R630      -7.3094330728054047e-02
    z[4,0,6]  R631      1.6180223226547241e-01
    z[4,0,6]  R632      1.2862329185009003e-01
    z[4,0,6]  R633      -2.5219817180186510e-03
    z[4,0,6]  R634      1.9107328355312347e-01
    z[4,0,6]  R635      3.0165421962738037e-01
    z[4,0,6]  R636      1.3045558333396912e-01
    z[4,0,6]  R637      2.6932266354560852e-01
    z[4,0,6]  R638      -2.1146193146705627e-01
    z[4,0,6]  R639      2.8522223234176636e-01
    z[4,0,6]  R640      -2.6264557242393494e-01
    z[4,0,6]  R641      -5.1534049212932587e-02
    z[4,0,6]  R642      -2.6396539807319641e-01
    z[4,0,6]  R643      5.9392873197793961e-02
    z[4,0,6]  R644      6.3238894939422607e-01
    z[4,0,6]  R645      4.8657186329364777e-02
    z[4,0,6]  R646      2.2225466370582581e-01
    z[4,0,6]  R647      2.6226265355944633e-02
    z[4,0,6]  R648      -8.5489697754383087e-02
    z[4,0,6]  R649      1.1524365842342377e-01
    z[4,0,6]  R650      -6.0925945639610291e-02
    z[4,0,6]  R651      2.4047592282295227e-01
    z[4,0,6]  R652      2.7839845418930054e-01
    z[4,0,6]  R653      1.4632443897426128e-02
    z[4,0,6]  R654      -1.9516487419605255e-01
    z[4,0,6]  R655      3.6841621994972229e-01
    z[4,0,6]  R656      -1.7419892549514771e-01
    z[4,0,6]  R657      -1.0508665442466736e-01
    z[4,0,6]  R658      2.1887370944023132e-01
    z[4,0,6]  R659      4.9801462888717651e-01
    z[4,0,6]  R660      -2.0023313164710999e-01
    z[4,0,6]  R661      4.2687371373176575e-02
    z[4,0,6]  R662      -1.7269712686538696e-01
    z[4,0,6]  R663      2.5844737887382507e-01
    z[4,0,6]  R664      2.2752356529235840e-01
    z[4,0,6]  R665      3.2015082240104675e-01
    z[4,0,6]  R666      -3.0852247029542923e-02
    z[4,0,6]  R667      -1.4967158436775208e-01
    z[4,0,6]  R668      1.0632573813199997e-01
    z[4,0,6]  R669      -2.5837266445159912e-01
    z[4,0,6]  R670      1.5754364430904388e-01
    z[4,0,6]  R671      2.8766760230064392e-01
    z[4,0,6]  R672      1.4787826687097549e-02
    z[4,0,6]  R673      -3.1033328175544739e-01
    z[4,0,6]  R674      -1.5594394505023956e-01
    z[4,0,6]  R675      -2.1786347031593323e-01
    z[4,0,6]  R676      4.2473133653402328e-03
    z[4,0,6]  R677      5.7245563715696335e-02
    z[4,0,6]  R678      2.0748578011989594e-01
    z[4,0,6]  R679      9.0484723448753357e-02
    z[4,0,6]  R680      3.7761884927749634e-01
    z[4,0,6]  R681      1.8649470806121826e-01
    z[4,0,6]  R682      3.0846813693642616e-02
    z[4,0,6]  R683      -3.6305539309978485e-02
    z[4,0,6]  R684      1.4598475396633148e-01
    z[4,0,6]  R685      -4.3949750065803528e-01
    z[4,0,6]  R686      -3.2506820559501648e-01
    z[4,0,6]  R687      4.5821475982666016e-01
    z[4,0,6]  R688      -2.0079061388969421e-01
    z[4,0,6]  R689      2.7436956763267517e-01
    z[4,0,6]  R690      3.0983682721853256e-02
    z[4,0,6]  R691      -2.7007344365119934e-01
    z[4,0,6]  R692      4.2271953821182251e-01
    z[4,0,6]  R693      -2.1987275779247284e-01
    z[4,0,6]  R694      1.7963241040706635e-01
    z[4,0,6]  R695      -2.9832735657691956e-01
    z[4,0,6]  R696      0.0983017086982727
    z[4,0,6]  R697      -3.1668996810913086e-01
    z[4,0,6]  R698      1.5204668045043945e-01
    z[4,0,6]  R699      1.3626010715961456e-01
    z[4,0,6]  R700      -5.1867388188838959e-02
    z[4,0,6]  R701      2.4919275939464569e-01
    z[4,0,6]  R702      -8.0029524862766266e-02
    z[4,0,6]  R703      -6.3693143427371979e-02
    z[4,0,6]  R704      -2.0735444128513336e-01
    z[4,0,6]  R705      -6.4610382542014122e-03
    z[4,0,6]  R706      3.9105647802352905e-01
    z[4,0,6]  R707      -9.8922356963157654e-02
    z[4,0,6]  R708      -7.9763151705265045e-02
    z[4,0,6]  R709      -4.5124265551567078e-01
    z[4,0,6]  R710      2.8198403120040894e-01
    z[4,0,6]  R711      2.2629508748650551e-02
    z[4,0,6]  R712      2.7077522128820419e-02
    z[4,0,6]  R713      2.3101305961608887e-01
    z[4,0,6]  R714      0.200897216796875
    z[4,0,6]  R715      -1.4587773382663727e-01
    z[4,0,6]  R716      -2.3490564525127411e-01
    z[4,0,6]  R717      3.2156085968017578e-01
    z[4,0,6]  R718      -1.8251250684261322e-01
    z[4,0,6]  R719      1.9953005015850067e-01
    z[4,0,6]  R720      -6.6221915185451508e-02
    z[4,0,6]  R721      8.4433071315288544e-02
    z[4,0,6]  R722      0.0134742995724082
    z[4,0,6]  R723      -2.3847445845603943e-01
    z[0,5,0]  R2        -1
    z[0,5,0]  R47       1
    z[0,5,0]  R724      -1
    z[0,5,0]  R725      1
    z[0,5,0]  R738      -6.4063489437103271e-02
    z[0,5,0]  R739      1.6059769690036774e-01
    z[0,5,0]  R740      1.3274246454238892e-01
    z[0,5,0]  R741      6.3208468258380890e-02
    z[0,5,0]  R742      1.0475829988718033e-01
    z[0,5,0]  R743      1.5666396915912628e-01
    z[0,5,0]  R744      2.4719725549221039e-01
    z[0,5,0]  R745      5.6741088628768921e-01
    z[0,5,0]  R746      5.1577204465866089e-01
    z[0,5,0]  R747      -6.9601279497146606e-01
    z[0,5,0]  R748      -1.3350605964660645e-01
    z[0,5,0]  R749      1.7930482327938080e-01
    z[0,5,0]  R750      -2.8537398576736450e-01
    z[0,5,0]  R751      1.6607774794101715e-01
    z[0,5,0]  R752      5.1720064133405685e-02
    z[0,5,0]  R753      -8.3205364644527435e-03
    z[0,5,0]  R754      4.0531735867261887e-02
    z[0,5,0]  R755      7.2678372263908386e-02
    z[0,5,0]  R756      0.260046124458313
    z[0,5,0]  R757      1.3106101751327515e-01
    z[0,5,0]  R758      -3.5949856042861938e-02
    z[0,5,0]  R759      2.7664564549922943e-02
    z[0,5,0]  R760      7.8953303396701813e-02
    z[0,5,0]  R761      1.5168353915214539e-01
    z[0,5,0]  R762      -3.3841833472251892e-01
    z[0,5,0]  R763      -2.2327479720115662e-01
    z[0,5,0]  R764      -2.6558920741081238e-01
    z[0,5,0]  R765      1.4662556350231171e-02
    z[0,5,0]  R766      -0.260986864566803
    z[0,5,0]  R767      -3.6370101571083069e-01
    z[0,5,0]  R768      3.5187106579542160e-02
    z[0,5,0]  R769      -1.2392750382423401e-01
    z[0,5,0]  R770      -4.5920538902282715e-01
    z[0,5,0]  R771      0.0667165070772171
    z[0,5,0]  R772      -2.9462891817092896e-01
    z[0,5,0]  R773      0.644294261932373
    z[0,5,0]  R774      -4.7134527564048767e-01
    z[0,5,0]  R775      2.8061863034963608e-02
    z[0,5,0]  R776      3.2971829175949097e-01
    z[0,5,0]  R777      6.9544982910156250e-01
    z[0,5,0]  R778      8.0374181270599365e-02
    z[0,5,0]  R779      4.4361403584480286e-01
    z[0,5,0]  R780      -2.3828917741775513e-01
    z[0,5,0]  R781      3.4130752086639404e-01
    z[0,5,0]  R782      -4.8296146094799042e-02
    z[0,5,0]  R783      -2.8567740321159363e-01
    z[0,5,0]  R784      -3.0408853292465210e-01
    z[0,5,0]  R785      7.3413014411926270e-01
    z[0,5,0]  R786      0.762452244758606
    z[0,5,0]  R787      -1.3330757617950439e-01
    z[0,5,0]  R788      0.0967952162027359
    z[0,5,0]  R789      5.4665857553482056e-01
    z[0,5,0]  R790      5.7045292854309082e-01
    z[0,5,0]  R791      4.8920072615146637e-02
    z[0,5,0]  R792      2.1173666417598724e-01
    z[0,5,0]  R793      4.0548691153526306e-01
    z[0,5,0]  R794      1.5091603994369507e-01
    z[0,5,0]  R795      6.5789061784744263e-01
    z[0,5,0]  R796      -4.8623021692037582e-02
    z[0,5,0]  R797      2.5142499804496765e-01
    z[0,5,0]  R798      1.9243241846561432e-01
    z[0,5,0]  R799      3.9235064387321472e-01
    z[0,5,0]  R800      2.9140564799308777e-01
    z[0,5,0]  R801      6.2068152427673340e-01
    z[0,5,0]  R802      -3.7842559814453125e-01
    z[0,5,0]  R803      1.0778354853391647e-01
    z[0,5,0]  R804      4.9369942396879196e-02
    z[0,5,0]  R805      -6.9795258343219757e-02
    z[0,5,0]  R806      -1.4652828872203827e-01
    z[0,5,0]  R807      0.0670105367898941
    z[0,5,0]  R808      0.550288736820221
    z[0,5,0]  R809      3.2825458794832230e-02
    z[0,5,0]  R810      -2.2199097275733948e-01
    z[0,5,0]  R811      -3.4488037228584290e-02
    z[0,5,0]  R812      1.8360415101051331e-01
    z[0,5,0]  R813      1.9765444099903107e-01
    z[0,5,0]  R814      -4.3908235430717468e-01
    z[0,5,0]  R815      -6.3887882232666016e-01
    z[0,5,0]  R816      -4.3565583229064941e-01
    z[0,5,0]  R817      -4.5687532424926758e-01
    z[0,5,0]  R818      0.084299735724926
    z[0,5,0]  R819      -4.7861550003290176e-02
    z[0,5,0]  R820      3.4174117445945740e-01
    z[0,5,0]  R821      -3.4983676671981812e-01
    z[0,5,0]  R822      -1.5232269465923309e-01
    z[0,5,0]  R823      -4.1082230210304260e-01
    z[0,5,0]  R824      -3.1880471110343933e-01
    z[0,5,0]  R825      -2.5601112842559814e-01
    z[0,5,0]  R826      -1.4790304005146027e-01
    z[0,5,0]  R827      1.4020407572388649e-02
    z[0,5,0]  R828      6.8481421470642090e-01
    z[0,5,0]  R829      4.2407432198524475e-01
    z[0,5,0]  R830      4.7219285368919373e-01
    z[0,5,0]  R831      2.9902374744415283e-01
    z[0,5,0]  R832      0.471809983253479
    z[0,5,0]  R833      0.557436466217041
    z[0,5,0]  R834      4.0043455362319946e-01
    z[0,5,0]  R835      4.1340434551239014e-01
    z[0,5,0]  R836      5.8189934492111206e-01
    z[0,5,0]  R837      -1.5772767364978790e-01
    z[0,5,0]  R838      -2.9264262318611145e-01
    z[0,5,0]  R839      2.9907515645027161e-01
    z[0,5,0]  R840      1.0870525985956192e-01
    z[0,5,0]  R841      4.1055597364902496e-02
    z[0,5,0]  R842      3.0551312491297722e-02
    z[0,5,0]  R843      -1.6856157779693604e-01
    z[0,5,0]  R844      -2.2263364493846893e-01
    z[0,5,0]  R845      -2.1212583780288696e-01
    z[0,5,0]  R846      -3.8890343159437180e-02
    z[0,5,0]  R847      -4.6333214640617371e-01
    z[0,5,0]  R848      6.4265592955052853e-03
    z[0,5,0]  R849      -3.6780755966901779e-02
    z[0,5,0]  R850      -2.7314704656600952e-01
    z[0,5,0]  R851      -3.8201864808797836e-02
    z[0,5,0]  R852      -3.4061646461486816e-01
    z[0,5,0]  R853      -3.0403605103492737e-01
    z[0,5,0]  R854      4.5423296093940735e-01
    z[0,5,0]  R855      -4.1578122973442078e-01
    z[0,5,0]  R856      -3.0241400003433228e-01
    z[0,5,0]  R857      3.4000226855278015e-01
    z[0,5,0]  R858      -1.1205981671810150e-01
    z[0,5,0]  R859      7.9000806808471680e-01
    z[0,5,0]  R860      5.3096508979797363e-01
    z[0,5,0]  R861      2.3741620779037476e-01
    z[0,5,0]  R862      5.5252593010663986e-02
    z[0,5,0]  R863      6.1953570693731308e-02
    z[0,5,0]  R864      3.7581798434257507e-01
    z[0,5,0]  R865      -0.425283819437027
    z[0,5,0]  R866      2.7152949571609497e-01
    z[0,5,0]  R867      -4.0629756450653076e-01
    z[0,5,0]  R868      -9.1883011162281036e-02
    z[0,5,0]  R869      3.7221607565879822e-01
    z[0,5,0]  R870      1.4681921899318695e-01
    z[0,5,0]  R871      4.0812635421752930e-01
    z[0,5,0]  R872      2.3946161568164825e-01
    z[0,5,0]  R873      -5.7091158628463745e-01
    z[0,5,0]  R874      -7.7465665340423584e-01
    z[0,5,0]  R875      -6.2244963645935059e-01
    z[0,5,0]  R876      -2.3654049634933472e-01
    z[0,5,0]  R877      -3.8324549794197083e-01
    z[0,5,1]  R3        -1
    z[0,5,1]  R48       1
    z[0,5,1]  R726      -1
    z[0,5,1]  R727      1
    z[0,5,1]  R738      -5.2023779600858688e-02
    z[0,5,1]  R739      1.8688815832138062e-01
    z[0,5,1]  R740      -2.0055456459522247e-01
    z[0,5,1]  R741      4.0589934587478638e-01
    z[0,5,1]  R742      -3.5552942752838135e-01
    z[0,5,1]  R743      1.1135175079107285e-01
    z[0,5,1]  R744      1.5564145147800446e-01
    z[0,5,1]  R745      -1.4409725368022919e-01
    z[0,5,1]  R746      -3.5696956515312195e-01
    z[0,5,1]  R747      -6.0474425554275513e-01
    z[0,5,1]  R748      5.9611005708575249e-03
    z[0,5,1]  R749      -1.3778430223464966e-01
    z[0,5,1]  R750      1.5254957973957062e-01
    z[0,5,1]  R751      4.2437443137168884e-01
    z[0,5,1]  R752      -3.2389974594116211e-01
    z[0,5,1]  R753      -3.8495957851409912e-01
    z[0,5,1]  R754      -5.0874465703964233e-01
    z[0,5,1]  R755      -3.6350693553686142e-02
    z[0,5,1]  R756      0.101785808801651
    z[0,5,1]  R757      1.9338355958461761e-01
    z[0,5,1]  R758      4.4235434383153915e-02
    z[0,5,1]  R759      -5.3629451990127563e-01
    z[0,5,1]  R760      0.81854248046875
    z[0,5,1]  R761      6.3725358247756958e-01
    z[0,5,1]  R762      -1.5819889307022095e-01
    z[0,5,1]  R763      4.4261854887008667e-01
    z[0,5,1]  R764      -4.1794739663600922e-02
    z[0,5,1]  R765      8.7619268894195557e-01
    z[0,5,1]  R766      1.1899554729461670e-01
    z[0,5,1]  R767      3.3444416522979736e-01
    z[0,5,1]  R768      -2.4165698885917664e-01
    z[0,5,1]  R769      2.8275391459465027e-01
    z[0,5,1]  R770      3.5537354648113251e-02
    z[0,5,1]  R771      -7.6254919171333313e-02
    z[0,5,1]  R772      -4.0073856711387634e-02
    z[0,5,1]  R773      0.0935761034488678
    z[0,5,1]  R774      -2.2781632840633392e-01
    z[0,5,1]  R775      0.36614990234375
    z[0,5,1]  R776      2.5656276941299438e-01
    z[0,5,1]  R777      3.1483608484268188e-01
    z[0,5,1]  R778      5.7906292378902435e-02
    z[0,5,1]  R779      7.1568292379379272e-01
    z[0,5,1]  R780      -3.4410279989242554e-01
    z[0,5,1]  R781      2.2935485467314720e-03
    z[0,5,1]  R782      0.634415328502655
    z[0,5,1]  R783      7.4076700210571289e-01
    z[0,5,1]  R784      5.5692654848098755e-01
    z[0,5,1]  R785      6.0079181194305420e-01
    z[0,5,1]  R786      5.2259796857833862e-01
    z[0,5,1]  R787      -9.6683973073959351e-01
    z[0,5,1]  R788      3.7239167094230652e-01
    z[0,5,1]  R789      -5.7963605970144272e-02
    z[0,5,1]  R790      -4.1433505713939667e-02
    z[0,5,1]  R791      -6.8225346505641937e-02
    z[0,5,1]  R792      -1.5415996313095093e-01
    z[0,5,1]  R793      -3.3002066612243652e-01
    z[0,5,1]  R794      -0.294149249792099
    z[0,5,1]  R795      3.0904176831245422e-01
    z[0,5,1]  R796      1.3697081804275513e-01
    z[0,5,1]  R797      0.750571072101593
    z[0,5,1]  R798      -3.0818048119544983e-01
    z[0,5,1]  R799      2.4123266339302063e-01
    z[0,5,1]  R800      1.3480287790298462e-01
    z[0,5,1]  R801      1.3289435207843781e-01
    z[0,5,1]  R802      -2.2830264270305634e-01
    z[0,5,1]  R803      3.2131770253181458e-01
    z[0,5,1]  R804      -2.1391832828521729e-01
    z[0,5,1]  R805      2.7872404456138611e-01
    z[0,5,1]  R806      -2.0348201692104340e-01
    z[0,5,1]  R807      6.0059273242950439e-01
    z[0,5,1]  R808      1.6556029021739960e-01
    z[0,5,1]  R809      -1.4329962432384491e-01
    z[0,5,1]  R810      2.1220651268959045e-01
    z[0,5,1]  R811      -1.6914875805377960e-01
    z[0,5,1]  R812      -1.4743930101394653e-01
    z[0,5,1]  R813      -1.7499189078807831e-01
    z[0,5,1]  R814      -3.5884156823158264e-01
    z[0,5,1]  R815      5.8143043518066406e-01
    z[0,5,1]  R816      -8.5988634824752808e-01
    z[0,5,1]  R817      -8.2960969209671021e-01
    z[0,5,1]  R818      2.7405783534049988e-01
    z[0,5,1]  R819      1.1639898270368576e-01
    z[0,5,1]  R820      -9.9900364875793457e-02
    z[0,5,1]  R821      -1.8450449407100677e-01
    z[0,5,1]  R822      -9.3087553977966309e-01
    z[0,5,1]  R823      -8.3404815196990967e-01
    z[0,5,1]  R824      -0.841460645198822
    z[0,5,1]  R825      -8.5124516487121582e-01
    z[0,5,1]  R826      -3.2479953765869141e-01
    z[0,5,1]  R827      -9.0595930814743042e-01
    z[0,5,1]  R828      -8.1086881458759308e-02
    z[0,5,1]  R829      -6.2803596258163452e-02
    z[0,5,1]  R830      -3.4306907653808594e-01
    z[0,5,1]  R831      -1.9525711238384247e-01
    z[0,5,1]  R832      -4.2736664414405823e-01
    z[0,5,1]  R833      3.7686202675104141e-02
    z[0,5,1]  R834      8.1025041639804840e-02
    z[0,5,1]  R835      -5.9450343251228333e-02
    z[0,5,1]  R836      1.1442169547080994e-01
    z[0,5,1]  R837      1.1627613753080368e-01
    z[0,5,1]  R838      6.6820508241653442e-01
    z[0,5,1]  R839      -7.8152108192443848e-01
    z[0,5,1]  R840      -8.5610884428024292e-01
    z[0,5,1]  R841      -8.3617657423019409e-01
    z[0,5,1]  R842      -8.7166756391525269e-01
    z[0,5,1]  R843      6.8277293443679810e-01
    z[0,5,1]  R844      -8.6038815975189209e-01
    z[0,5,1]  R845      -8.2086509466171265e-01
    z[0,5,1]  R846      -7.5712805986404419e-01
    z[0,5,1]  R847      0.513932466506958
    z[0,5,1]  R848      7.9905492067337036e-01
    z[0,5,1]  R849      5.6476676464080811e-01
    z[0,5,1]  R850      7.2334295511245728e-01
    z[0,5,1]  R851      6.2016886472702026e-01
    z[0,5,1]  R852      5.9186714887619019e-01
    z[0,5,1]  R853      6.1776363849639893e-01
    z[0,5,1]  R854      7.4573993682861328e-01
    z[0,5,1]  R855      7.5574219226837158e-01
    z[0,5,1]  R856      9.0976518392562866e-01
    z[0,5,1]  R857      7.1882611513137817e-01
    z[0,5,1]  R858      3.0438011884689331e-01
    z[0,5,1]  R859      -4.9998942762613297e-02
    z[0,5,1]  R860      -0.732832133769989
    z[0,5,1]  R861      5.9587860107421875e-01
    z[0,5,1]  R862      -7.4152338504791260e-01
    z[0,5,1]  R863      5.1899129152297974e-01
    z[0,5,1]  R864      4.2850050330162048e-01
    z[0,5,1]  R865      6.1402846127748489e-02
    z[0,5,1]  R866      3.9935836195945740e-01
    z[0,5,1]  R867      -1.1253734678030014e-01
    z[0,5,1]  R868      4.6186193823814392e-01
    z[0,5,1]  R869      -8.9172267913818359e-01
    z[0,5,1]  R870      7.1494489908218384e-01
    z[0,5,1]  R871      5.7863938808441162e-01
    z[0,5,1]  R872      5.5286550521850586e-01
    z[0,5,1]  R873      -7.4655382195487618e-04
    z[0,5,1]  R874      -1.5049608051776886e-01
    z[0,5,1]  R875      -7.8971035778522491e-02
    z[0,5,1]  R876      -2.5156855583190918e-01
    z[0,5,1]  R877      -6.4073219895362854e-02
    z[0,5,2]  R4        -1
    z[0,5,2]  R49       1
    z[0,5,2]  R728      -1
    z[0,5,2]  R729      1
    z[0,5,2]  R738      -5.6777913123369217e-02
    z[0,5,2]  R739      1.0353393852710724e-01
    z[0,5,2]  R740      -3.2702925801277161e-01
    z[0,5,2]  R741      -1.2539622187614441e-01
    z[0,5,2]  R742      -2.3582690954208374e-01
    z[0,5,2]  R743      -3.1900930404663086e-01
    z[0,5,2]  R744      -2.7136135101318359e-01
    z[0,5,2]  R745      4.4235885143280029e-02
    z[0,5,2]  R746      3.3006185293197632e-01
    z[0,5,2]  R747      2.7378043532371521e-01
    z[0,5,2]  R748      2.8532043099403381e-01
    z[0,5,2]  R749      -1.7149317264556885e-01
    z[0,5,2]  R750      8.2180345058441162e-01
    z[0,5,2]  R751      -6.7168600857257843e-02
    z[0,5,2]  R752      -1.7426814138889313e-01
    z[0,5,2]  R753      1.7528069019317627e-01
    z[0,5,2]  R754      -1.4055498875677586e-02
    z[0,5,2]  R755      3.2149147987365723e-01
    z[0,5,2]  R756      8.6558210849761963e-01
    z[0,5,2]  R757      9.3931305408477783e-01
    z[0,5,2]  R758      7.3067253828048706e-01
    z[0,5,2]  R759      -2.2591440379619598e-01
    z[0,5,2]  R760      -1.5671806037425995e-01
    z[0,5,2]  R761      5.5256050825119019e-01
    z[0,5,2]  R762      0.467549592256546
    z[0,5,2]  R763      -3.3615368604660034e-01
    z[0,5,2]  R764      3.6083319783210754e-01
    z[0,5,2]  R765      6.0788080096244812e-02
    z[0,5,2]  R766      -1.4985999464988708e-01
    z[0,5,2]  R767      2.6378521323204041e-01
    z[0,5,2]  R768      -3.1577392946928740e-03
    z[0,5,2]  R769      -2.0002222061157227e-01
    z[0,5,2]  R770      2.6407885551452637e-01
    z[0,5,2]  R771      -2.5432729721069336e-01
    z[0,5,2]  R772      -3.1636923551559448e-01
    z[0,5,2]  R773      -2.6361331343650818e-01
    z[0,5,2]  R774      -1.0337930172681808e-01
    z[0,5,2]  R775      4.4319942593574524e-01
    z[0,5,2]  R776      3.6318498849868774e-01
    z[0,5,2]  R777      2.8820511698722839e-01
    z[0,5,2]  R778      -3.6796236038208008e-01
    z[0,5,2]  R779      2.7848687767982483e-01
    z[0,5,2]  R780      -3.0173275619745255e-02
    z[0,5,2]  R781      7.3003798723220825e-01
    z[0,5,2]  R782      -1.7617985606193542e-01
    z[0,5,2]  R783      -8.4466069936752319e-02
    z[0,5,2]  R784      1.8327631056308746e-01
    z[0,5,2]  R785      -6.3278481364250183e-02
    z[0,5,2]  R786      -1.6766825318336487e-01
    z[0,5,2]  R787      1.3303583860397339e-01
    z[0,5,2]  R788      2.4208576977252960e-01
    z[0,5,2]  R789      -0.179097518324852
    z[0,5,2]  R790      1.1233936063945293e-02
    z[0,5,2]  R791      4.3308448791503906e-01
    z[0,5,2]  R792      2.5103539228439331e-01
    z[0,5,2]  R793      4.5756268501281738e-01
    z[0,5,2]  R794      4.3825164437294006e-01
    z[0,5,2]  R795      0.348513126373291
    z[0,5,2]  R796      3.1630018353462219e-01
    z[0,5,2]  R797      -4.0792483091354370e-01
    z[0,5,2]  R798      -1.5815148130059242e-02
    z[0,5,2]  R799      1.3097250461578369e-01
    z[0,5,2]  R800      5.2823996543884277e-01
    z[0,5,2]  R801      -2.1121042966842651e-01
    z[0,5,2]  R802      -8.3415031433105469e-02
    z[0,5,2]  R803      -1.9119301438331604e-01
    z[0,5,2]  R804      5.0723668187856674e-02
    z[0,5,2]  R805      1.6085717082023621e-01
    z[0,5,2]  R806      8.1871229410171509e-01
    z[0,5,2]  R807      4.4781997799873352e-01
    z[0,5,2]  R808      -2.5352808833122253e-01
    z[0,5,2]  R809      1.1890961229801178e-01
    z[0,5,2]  R810      5.4404580593109131e-01
    z[0,5,2]  R811      2.9344305396080017e-01
    z[0,5,2]  R812      0.0649917870759964
    z[0,5,2]  R813      3.0003413558006287e-01
    z[0,5,2]  R814      5.0687056779861450e-01
    z[0,5,2]  R815      1.9926688075065613e-01
    z[0,5,2]  R816      2.7861837297677994e-02
    z[0,5,2]  R817      6.4635850489139557e-02
    z[0,5,2]  R818      -2.6343947649002075e-01
    z[0,5,2]  R819      7.1777254343032837e-02
    z[0,5,2]  R820      6.4623379707336426e-01
    z[0,5,2]  R821      4.6222358942031860e-01
    z[0,5,2]  R822      -0.252784788608551
    z[0,5,2]  R823      -1.6858577728271484e-01
    z[0,5,2]  R824      -2.5062909722328186e-01
    z[0,5,2]  R825      -0.354160875082016
    z[0,5,2]  R826      -1.4349471032619476e-01
    z[0,5,2]  R827      1.0102648288011551e-01
    z[0,5,2]  R828      -4.9701955914497375e-01
    z[0,5,2]  R829      -4.9604868888854980e-01
    z[0,5,2]  R830      -4.8486655950546265e-01
    z[0,5,2]  R831      -2.7913671731948853e-01
    z[0,5,2]  R832      -9.4179607927799225e-02
    z[0,5,2]  R833      -3.9441445469856262e-01
    z[0,5,2]  R834      -5.9366188943386078e-02
    z[0,5,2]  R835      -7.4587929248809814e-01
    z[0,5,2]  R836      -3.0251011252403259e-01
    z[0,5,2]  R837      -9.3451154232025146e-01
    z[0,5,2]  R838      1.1230071634054184e-01
    z[0,5,2]  R839      5.0350213050842285e-01
    z[0,5,2]  R840      -7.9214975237846375e-02
    z[0,5,2]  R841      4.4775810837745667e-01
    z[0,5,2]  R842      6.5615884959697723e-02
    z[0,5,2]  R843      3.6876353621482849e-01
    z[0,5,2]  R844      1.0235640406608582e-01
    z[0,5,2]  R845      0.285470187664032
    z[0,5,2]  R846      4.4804835319519043e-01
    z[0,5,2]  R847      -2.7570006251335144e-01
    z[0,5,2]  R848      -3.4256786108016968e-01
    z[0,5,2]  R849      -6.4214640855789185e-01
    z[0,5,2]  R850      -4.3363049626350403e-01
    z[0,5,2]  R851      -5.2234929800033569e-01
    z[0,5,2]  R852      -5.8482336997985840e-01
    z[0,5,2]  R853      -6.3599956035614014e-01
    z[0,5,2]  R854      -4.3129000067710876e-01
    z[0,5,2]  R855      -3.1067979335784912e-01
    z[0,5,2]  R856      1.2998823076486588e-02
    z[0,5,2]  R857      1.3436928391456604e-01
    z[0,5,2]  R858      -8.5875076055526733e-01
    z[0,5,2]  R859      3.4931668639183044e-01
    z[0,5,2]  R860      -1.3806378841400146e-01
    z[0,5,2]  R861      5.3474318981170654e-01
    z[0,5,2]  R862      4.8715031147003174e-01
    z[0,5,2]  R863      7.9511761665344238e-01
    z[0,5,2]  R864      6.2353795766830444e-01
    z[0,5,2]  R865      4.3923398852348328e-01
    z[0,5,2]  R866      6.3465487957000732e-01
    z[0,5,2]  R867      6.8603628873825073e-01
    z[0,5,2]  R868      -5.9742176532745361e-01
    z[0,5,2]  R869      -3.2313343137502670e-02
    z[0,5,2]  R870      5.7549959421157837e-01
    z[0,5,2]  R871      5.0004667043685913e-01
    z[0,5,2]  R872      7.4372583627700806e-01
    z[0,5,2]  R873      3.8138604164123535e-01
    z[0,5,2]  R874      4.4182300567626953e-01
    z[0,5,2]  R875      -3.1139988452196121e-02
    z[0,5,2]  R876      -2.3227233439683914e-02
    z[0,5,2]  R877      3.3875235915184021e-01
    z[0,5,3]  R5        -1
    z[0,5,3]  R50       1
    z[0,5,3]  R730      -1
    z[0,5,3]  R731      1
    z[0,5,3]  R738      -9.2928916215896606e-01
    z[0,5,3]  R739      -0.804606556892395
    z[0,5,3]  R740      -8.5726940631866455e-01
    z[0,5,3]  R741      -8.5723048448562622e-01
    z[0,5,3]  R742      -8.0125230550765991e-01
    z[0,5,3]  R743      -7.1358543634414673e-01
    z[0,5,3]  R744      -7.9580336809158325e-01
    z[0,5,3]  R745      -1.5711851418018341e-01
    z[0,5,3]  R746      -2.7160879969596863e-01
    z[0,5,3]  R747      -1.3891610503196716e-01
    z[0,5,3]  R748      3.8556548953056335e-01
    z[0,5,3]  R749      4.3534025549888611e-01
    z[0,5,3]  R750      1.7657354474067688e-01
    z[0,5,3]  R751      3.9180862903594971e-01
    z[0,5,3]  R752      2.4762172996997833e-01
    z[0,5,3]  R753      2.9850077629089355e-01
    z[0,5,3]  R754      5.1189678907394409e-01
    z[0,5,3]  R755      3.6862105131149292e-01
    z[0,5,3]  R756      2.1526399254798889e-01
    z[0,5,3]  R757      1.1522676795721054e-01
    z[0,5,3]  R758      4.4608378410339355e-01
    z[0,5,3]  R759      5.6817245483398438e-01
    z[0,5,3]  R760      2.0419143140316010e-01
    z[0,5,3]  R761      -2.1266290545463562e-01
    z[0,5,3]  R762      6.1207717657089233e-01
    z[0,5,3]  R763      2.3714180290699005e-01
    z[0,5,3]  R764      1.5064767003059387e-01
    z[0,5,3]  R765      3.3175039291381836e-01
    z[0,5,3]  R766      7.5979363918304443e-01
    z[0,5,3]  R767      6.5049648284912109e-01
    z[0,5,3]  R768      5.3698408603668213e-01
    z[0,5,3]  R769      4.9911034107208252e-01
    z[0,5,3]  R770      5.5468392372131348e-01
    z[0,5,3]  R771      5.2799969911575317e-01
    z[0,5,3]  R772      4.9183416366577148e-01
    z[0,5,3]  R773      -1.7968240380287170e-01
    z[0,5,3]  R774      5.0459164381027222e-01
    z[0,5,3]  R775      3.0800908803939819e-01
    z[0,5,3]  R776      6.0138350725173950e-01
    z[0,5,3]  R777      -2.4376663565635681e-01
    z[0,5,3]  R778      6.8626904487609863e-01
    z[0,5,3]  R779      -3.3575016260147095e-01
    z[0,5,3]  R780      6.3144260644912720e-01
    z[0,5,3]  R781      4.2121031880378723e-01
    z[0,5,3]  R782      5.6819815188646317e-02
    z[0,5,3]  R783      0.336073100566864
    z[0,5,3]  R784      1.5416452288627625e-01
    z[0,5,3]  R785      2.4057245254516602e-01
    z[0,5,3]  R786      1.6548976302146912e-01
    z[0,5,3]  R787      -9.2471368610858917e-02
    z[0,5,3]  R788      5.3288924694061279e-01
    z[0,5,3]  R789      -0.455875039100647
    z[0,5,3]  R790      -3.8344934582710266e-01
    z[0,5,3]  R791      0.614128053188324
    z[0,5,3]  R792      0.767065703868866
    z[0,5,3]  R793      3.5107195377349854e-01
    z[0,5,3]  R794      6.2618285417556763e-01
    z[0,5,3]  R795      -3.4679338335990906e-01
    z[0,5,3]  R796      5.5651229619979858e-01
    z[0,5,3]  R797      1.9736245274543762e-01
    z[0,5,3]  R798      -8.5408180952072144e-01
    z[0,5,3]  R799      -5.5037140846252441e-01
    z[0,5,3]  R800      -7.3549979925155640e-01
    z[0,5,3]  R801      -4.9482280015945435e-01
    z[0,5,3]  R802      6.7564916610717773e-01
    z[0,5,3]  R803      6.6907513141632080e-01
    z[0,5,3]  R804      8.2581186294555664e-01
    z[0,5,3]  R805      0.79014652967453
    z[0,5,3]  R806      1.7215198278427124e-01
    z[0,5,3]  R807      5.8378702402114868e-01
    z[0,5,3]  R808      -0.62684565782547
    z[0,5,3]  R809      0.827559769153595
    z[0,5,3]  R810      6.0564368963241577e-01
    z[0,5,3]  R811      6.2602764368057251e-01
    z[0,5,3]  R812      2.5464054942131042e-01
    z[0,5,3]  R813      4.9707618355751038e-01
    z[0,5,3]  R814      2.4635070562362671e-01
    z[0,5,3]  R815      7.9420171678066254e-03
    z[0,5,3]  R816      7.3591373860836029e-02
    z[0,5,3]  R817      -1.1864126473665237e-01
    z[0,5,3]  R818      7.1144467592239380e-01
    z[0,5,3]  R819      -6.2321805953979492e-01
    z[0,5,3]  R820      0.448964923620224
    z[0,5,3]  R821      1.6619957983493805e-01
    z[0,5,3]  R822      1.0466784238815308e-01
    z[0,5,3]  R823      1.7910125851631165e-01
    z[0,5,3]  R824      3.1129390001296997e-01
    z[0,5,3]  R825      2.0030494779348373e-02
    z[0,5,3]  R826      9.6967602148652077e-03
    z[0,5,3]  R827      2.0940619707107544e-01
    z[0,5,3]  R828      -3.5028973221778870e-01
    z[0,5,3]  R829      -8.2846589386463165e-02
    z[0,5,3]  R830      3.2014327589422464e-03
    z[0,5,3]  R831      -1.4209325611591339e-01
    z[0,5,3]  R832      7.1378417313098907e-02
    z[0,5,3]  R833      2.7369028329849243e-01
    z[0,5,3]  R834      1.1251424252986908e-01
    z[0,5,3]  R835      -2.3168994486331940e-01
    z[0,5,3]  R836      -2.6467078924179077e-01
    z[0,5,3]  R837      1.0491105914115906e-01
    z[0,5,3]  R838      0.0898166075348854
    z[0,5,3]  R839      -1.1651634424924850e-01
    z[0,5,3]  R840      -2.1026555448770523e-02
    z[0,5,3]  R841      6.8229183554649353e-02
    z[0,5,3]  R842      1.2749873101711273e-01
    z[0,5,3]  R843      4.5084267854690552e-02
    z[0,5,3]  R844      2.7704444527626038e-01
    z[0,5,3]  R845      0.355803906917572
    z[0,5,3]  R846      2.7114561200141907e-01
    z[0,5,3]  R847      2.5887799263000488e-01
    z[0,5,3]  R848      -2.9570633172988892e-01
    z[0,5,3]  R849      -1.3546113669872284e-01
    z[0,5,3]  R850      1.8554992973804474e-01
    z[0,5,3]  R851      -1.0255632549524307e-01
    z[0,5,3]  R852      6.0594443231821060e-02
    z[0,5,3]  R853      1.5278393030166626e-01
    z[0,5,3]  R854      6.0688290745019913e-02
    z[0,5,3]  R855      1.1022411286830902e-01
    z[0,5,3]  R856      6.9968298077583313e-02
    z[0,5,3]  R857      -3.5158935189247131e-01
    z[0,5,3]  R858      1.0737839341163635e-01
    z[0,5,3]  R859      1.6416235268115997e-01
    z[0,5,3]  R860      -1.6629289090633392e-01
    z[0,5,3]  R861      1.3947841711342335e-02
    z[0,5,3]  R862      2.2214072942733765e-01
    z[0,5,3]  R863      -1.9584783911705017e-01
    z[0,5,3]  R864      0.281126469373703
    z[0,5,3]  R865      -5.7939112186431885e-01
    z[0,5,3]  R866      5.0716590881347656e-01
    z[0,5,3]  R867      -3.6588475108146667e-01
    z[0,5,3]  R868      -7.0546649396419525e-02
    z[0,5,3]  R869      -0.0752662867307663
    z[0,5,3]  R870      8.5963584482669830e-02
    z[0,5,3]  R871      3.4735634922981262e-01
    z[0,5,3]  R872      7.2962991893291473e-02
    z[0,5,3]  R873      -6.3346517086029053e-01
    z[0,5,3]  R874      -3.9998832345008850e-01
    z[0,5,3]  R875      -0.642842173576355
    z[0,5,3]  R876      3.7850666791200638e-02
    z[0,5,3]  R877      1.6396088898181915e-01
    z[0,5,4]  R6        -1
    z[0,5,4]  R51       1
    z[0,5,4]  R732      -1
    z[0,5,4]  R733      1
    z[0,5,4]  R738      2.9850891232490540e-01
    z[0,5,4]  R739      1.0379948467016220e-01
    z[0,5,4]  R740      6.7134196870028973e-03
    z[0,5,4]  R741      -2.4092530831694603e-02
    z[0,5,4]  R742      3.4442999958992004e-01
    z[0,5,4]  R743      -5.1885211467742920e-01
    z[0,5,4]  R744      3.5841333866119385e-01
    z[0,5,4]  R745      -4.1127124428749084e-01
    z[0,5,4]  R746      8.8618598878383636e-02
    z[0,5,4]  R747      2.2265779972076416e-01
    z[0,5,4]  R748      -4.9502938985824585e-01
    z[0,5,4]  R749      -8.5293418169021606e-01
    z[0,5,4]  R750      3.3291608095169067e-01
    z[0,5,4]  R751      -7.1162384748458862e-01
    z[0,5,4]  R752      -7.4344772100448608e-01
    z[0,5,4]  R753      -7.7911502122879028e-01
    z[0,5,4]  R754      -0.671019434928894
    z[0,5,4]  R755      -8.1939530372619629e-01
    z[0,5,4]  R756      2.0195983350276947e-01
    z[0,5,4]  R757      2.0293138921260834e-01
    z[0,5,4]  R758      4.4607225060462952e-01
    z[0,5,4]  R759      -4.4644799828529358e-01
    z[0,5,4]  R760      8.7363161146640778e-03
    z[0,5,4]  R761      3.6340811848640442e-01
    z[0,5,4]  R762      -2.9440057277679443e-01
    z[0,5,4]  R763      -3.7326484918594360e-01
    z[0,5,4]  R764      2.4924322962760925e-01
    z[0,5,4]  R765      3.0503988265991211e-01
    z[0,5,4]  R766      -7.0223741233348846e-02
    z[0,5,4]  R767      -1.9835433363914490e-01
    z[0,5,4]  R768      -7.0246893167495728e-01
    z[0,5,4]  R769      -0.702630341053009
    z[0,5,4]  R770      0.272499144077301
    z[0,5,4]  R771      -6.6848033666610718e-01
    z[0,5,4]  R772      -5.1927280426025391e-01
    z[0,5,4]  R773      -0.247806116938591
    z[0,5,4]  R774      -3.1744873523712158e-01
    z[0,5,4]  R775      -6.3552063703536987e-01
    z[0,5,4]  R776      -4.9319875240325928e-01
    z[0,5,4]  R777      -4.1530814766883850e-01
    z[0,5,4]  R778      -5.6754702329635620e-01
    z[0,5,4]  R779      2.3077231645584106e-01
    z[0,5,4]  R780      -4.7983753681182861e-01
    z[0,5,4]  R781      3.4534502029418945e-01
    z[0,5,4]  R782      4.1923069953918457e-01
    z[0,5,4]  R783      4.8716527223587036e-01
    z[0,5,4]  R784      4.9648800492286682e-01
    z[0,5,4]  R785      -1.5960346907377243e-02
    z[0,5,4]  R786      -6.6549576818943024e-02
    z[0,5,4]  R787      -1.2255188077688217e-01
    z[0,5,4]  R788      -6.6290569305419922e-01
    z[0,5,4]  R789      -3.7945404648780823e-01
    z[0,5,4]  R790      2.0986701548099518e-01
    z[0,5,4]  R791      2.1012732386589050e-01
    z[0,5,4]  R792      -0.489188551902771
    z[0,5,4]  R793      -3.6255702376365662e-02
    z[0,5,4]  R794      -5.0594764947891235e-01
    z[0,5,4]  R795      -3.7479439377784729e-01
    z[0,5,4]  R796      -4.5726552605628967e-01
    z[0,5,4]  R797      2.2959679365158081e-01
    z[0,5,4]  R798      -3.2122680544853210e-01
    z[0,5,4]  R799      -1.9119140505790710e-01
    z[0,5,4]  R800      -1.7439144849777222e-01
    z[0,5,4]  R801      -4.4242069125175476e-01
    z[0,5,4]  R802      -4.1691732406616211e-01
    z[0,5,4]  R803      -5.6202590465545654e-01
    z[0,5,4]  R804      -0.505794107913971
    z[0,5,4]  R805      -3.8944569230079651e-01
    z[0,5,4]  R806      2.2215992212295532e-01
    z[0,5,4]  R807      2.6274007558822632e-01
    z[0,5,4]  R808      -4.0438213944435120e-01
    z[0,5,4]  R809      -5.2583914995193481e-01
    z[0,5,4]  R810      2.2356854379177094e-01
    z[0,5,4]  R811      -4.9322238564491272e-01
    z[0,5,4]  R812      -8.0460679531097412e-01
    z[0,5,4]  R813      1.6704671084880829e-01
    z[0,5,4]  R814      -2.9823830351233482e-02
    z[0,5,4]  R815      4.2493402957916260e-01
    z[0,5,4]  R816      2.2571101784706116e-01
    z[0,5,4]  R817      1.7069098353385925e-01
    z[0,5,4]  R818      -5.4182070493698120e-01
    z[0,5,4]  R819      2.2802498936653137e-01
    z[0,5,4]  R820      1.1553851515054703e-01
    z[0,5,4]  R821      3.4038805961608887e-01
    z[0,5,4]  R822      -4.0117930620908737e-02
    z[0,5,4]  R823      -2.6049926877021790e-02
    z[0,5,4]  R824      1.1090749502182007e-01
    z[0,5,4]  R825      -3.5114653408527374e-02
    z[0,5,4]  R826      6.0660088062286377e-01
    z[0,5,4]  R827      6.9004237651824951e-02
    z[0,5,4]  R828      -1.5760441124439240e-01
    z[0,5,4]  R829      -0.446170449256897
    z[0,5,4]  R830      1.4418350160121918e-01
    z[0,5,4]  R831      2.7568724751472473e-01
    z[0,5,4]  R832      -1.8833811581134796e-01
    z[0,5,4]  R833      4.8487776517868042e-01
    z[0,5,4]  R834      -1.1457122862339020e-01
    z[0,5,4]  R835      4.2632073163986206e-01
    z[0,5,4]  R836      -3.1137070059776306e-01
    z[0,5,4]  R837      1.9011422991752625e-01
    z[0,5,4]  R838      -2.8852125629782677e-02
    z[0,5,4]  R839      4.2678169906139374e-02
    z[0,5,4]  R840      2.9173517227172852e-01
    z[0,5,4]  R841      1.2564468383789062e-01
    z[0,5,4]  R842      1.3905872404575348e-01
    z[0,5,4]  R843      -4.8676499724388123e-01
    z[0,5,4]  R844      2.2104050219058990e-01
    z[0,5,4]  R845      -2.9736701399087906e-02
    z[0,5,4]  R846      -3.0702257156372070e-01
    z[0,5,4]  R847      -2.6921811699867249e-01
    z[0,5,4]  R848      0.3248310983181
    z[0,5,4]  R849      -1.3797611929476261e-02
    z[0,5,4]  R850      -3.2528871297836304e-01
    z[0,5,4]  R851      -2.8412604331970215e-01
    z[0,5,4]  R852      9.5781035721302032e-02
    z[0,5,4]  R853      -1.1825407296419144e-01
    z[0,5,4]  R854      -4.2378310114145279e-02
    z[0,5,4]  R855      3.1653138995170593e-01
    z[0,5,4]  R856      -2.2756111621856689e-01
    z[0,5,4]  R857      -4.3291386961936951e-01
    z[0,5,4]  R858      1.3337983749806881e-02
    z[0,5,4]  R859      1.0181195288896561e-01
    z[0,5,4]  R860      -3.2449635863304138e-01
    z[0,5,4]  R861      2.5695082545280457e-01
    z[0,5,4]  R862      -1.6070288419723511e-01
    z[0,5,4]  R863      7.1187183260917664e-02
    z[0,5,4]  R864      2.2787061333656311e-01
    z[0,5,4]  R865      9.6975639462471008e-02
    z[0,5,4]  R866      1.7501041293144226e-01
    z[0,5,4]  R867      -3.1704951077699661e-02
    z[0,5,4]  R868      3.8346165418624878e-01
    z[0,5,4]  R869      8.7240047752857208e-02
    z[0,5,4]  R870      1.6404733061790466e-01
    z[0,5,4]  R871      -0.103693388402462
    z[0,5,4]  R872      -2.4617625400424004e-02
    z[0,5,4]  R873      7.9239696264266968e-02
    z[0,5,4]  R874      -7.7282056212425232e-02
    z[0,5,4]  R875      4.3240282684564590e-02
    z[0,5,4]  R876      2.2247716784477234e-01
    z[0,5,4]  R877      3.1550772488117218e-02
    z[0,5,5]  R7        -1
    z[0,5,5]  R52       1
    z[0,5,5]  R734      -1
    z[0,5,5]  R735      1
    z[0,5,5]  R738      -2.7762185782194138e-02
    z[0,5,5]  R739      -4.2355707287788391e-01
    z[0,5,5]  R740      -2.8850415349006653e-01
    z[0,5,5]  R741      8.6988382041454315e-02
    z[0,5,5]  R742      4.0703356266021729e-02
    z[0,5,5]  R743      3.9076272398233414e-02
    z[0,5,5]  R744      1.0142208635807037e-01
    z[0,5,5]  R745      -6.7737591266632080e-01
    z[0,5,5]  R746      -5.8848005533218384e-01
    z[0,5,5]  R747      4.9932379275560379e-02
    z[0,5,5]  R748      3.2726475596427917e-01
    z[0,5,5]  R749      8.3617325872182846e-03
    z[0,5,5]  R750      1.6888137161731720e-01
    z[0,5,5]  R751      3.5665473341941833e-01
    z[0,5,5]  R752      4.9061697721481323e-01
    z[0,5,5]  R753      3.3408010005950928e-01
    z[0,5,5]  R754      1.5271255373954773e-01
    z[0,5,5]  R755      1.5786384046077728e-01
    z[0,5,5]  R756      9.0284220874309540e-02
    z[0,5,5]  R757      9.1893002390861511e-02
    z[0,5,5]  R758      1.6373126208782196e-01
    z[0,5,5]  R759      -5.2146852016448975e-02
    z[0,5,5]  R760      4.7652739286422729e-01
    z[0,5,5]  R761      2.7792543172836304e-01
    z[0,5,5]  R762      3.6418086290359497e-01
    z[0,5,5]  R763      4.4458580017089844e-01
    z[0,5,5]  R764      8.2012486457824707e-01
    z[0,5,5]  R765      -1.5312202274799347e-01
    z[0,5,5]  R766      5.3218954801559448e-01
    z[0,5,5]  R767      3.9623332023620605e-01
    z[0,5,5]  R768      0.326760470867157
    z[0,5,5]  R769      1.3923436403274536e-01
    z[0,5,5]  R770      5.7900595664978027e-01
    z[0,5,5]  R771      4.2071428894996643e-01
    z[0,5,5]  R772      5.3725987672805786e-01
    z[0,5,5]  R773      -5.8837610483169556e-01
    z[0,5,5]  R774      5.7882612943649292e-01
    z[0,5,5]  R775      2.9531732201576233e-01
    z[0,5,5]  R776      -2.9737564921379089e-01
    z[0,5,5]  R777      7.7173076570034027e-02
    z[0,5,5]  R778      1.9338364899158478e-01
    z[0,5,5]  R779      -1.0505378013476729e-03
    z[0,5,5]  R780      4.4149649143218994e-01
    z[0,5,5]  R781      2.2492264211177826e-01
    z[0,5,5]  R782      -5.8490353822708130e-01
    z[0,5,5]  R783      6.3682332634925842e-02
    z[0,5,5]  R784      -3.8847097754478455e-01
    z[0,5,5]  R785      -5.6462105363607407e-02
    z[0,5,5]  R786      2.9099500179290771e-01
    z[0,5,5]  R787      6.9737970829010010e-02
    z[0,5,5]  R788      2.2050644457340240e-01
    z[0,5,5]  R789      3.4751009941101074e-01
    z[0,5,5]  R790      -6.1318314075469971e-01
    z[0,5,5]  R791      4.1727980971336365e-01
    z[0,5,5]  R792      1.9269576296210289e-02
    z[0,5,5]  R793      5.6343454122543335e-01
    z[0,5,5]  R794      -2.2268386185169220e-01
    z[0,5,5]  R795      1.2859074771404266e-01
    z[0,5,5]  R796      -4.2583969235420227e-01
    z[0,5,5]  R797      -2.5887307524681091e-01
    z[0,5,5]  R798      -5.3237382322549820e-02
    z[0,5,5]  R799      5.8502310514450073e-01
    z[0,5,5]  R800      1.9193184375762939e-01
    z[0,5,5]  R801      1.0772937536239624e-01
    z[0,5,5]  R802      3.7983378767967224e-01
    z[0,5,5]  R803      -2.5783991813659668e-01
    z[0,5,5]  R804      -9.3516901135444641e-02
    z[0,5,5]  R805      -2.3123618960380554e-01
    z[0,5,5]  R806      4.2595624923706055e-01
    z[0,5,5]  R807      -1.4268389344215393e-01
    z[0,5,5]  R808      0.0777122750878334
    z[0,5,5]  R809      -5.3333669900894165e-02
    z[0,5,5]  R810      1.9997552037239075e-01
    z[0,5,5]  R811      4.8900499939918518e-01
    z[0,5,5]  R812      4.7088339924812317e-01
    z[0,5,5]  R813      6.0139906406402588e-01
    z[0,5,5]  R814      5.2955496311187744e-01
    z[0,5,5]  R815      -1.8144200742244720e-01
    z[0,5,5]  R816      1.1370515823364258e-01
    z[0,5,5]  R817      -4.7502916306257248e-02
    z[0,5,5]  R818      -9.1118104755878448e-02
    z[0,5,5]  R819      7.1925801038742065e-01
    z[0,5,5]  R820      4.3071508407592773e-01
    z[0,5,5]  R821      6.1889731884002686e-01
    z[0,5,5]  R822      2.2198554128408432e-02
    z[0,5,5]  R823      -1.8600904941558838e-01
    z[0,5,5]  R824      -1.1791043728590012e-01
    z[0,5,5]  R825      -2.7503988146781921e-01
    z[0,5,5]  R826      -6.9555658102035522e-01
    z[0,5,5]  R827      -2.5169846415519714e-01
    z[0,5,5]  R828      -2.6819872856140137e-01
    z[0,5,5]  R829      -5.8968561887741089e-01
    z[0,5,5]  R830      -6.0464257001876831e-01
    z[0,5,5]  R831      -8.3057153224945068e-01
    z[0,5,5]  R832      -7.3555302619934082e-01
    z[0,5,5]  R833      -4.6865555644035339e-01
    z[0,5,5]  R834      -8.2228648662567139e-01
    z[0,5,5]  R835      -0.147823303937912
    z[0,5,5]  R836      -2.2303384542465210e-01
    z[0,5,5]  R837      -2.0209042727947235e-01
    z[0,5,5]  R838      -0.435959130525589
    z[0,5,5]  R839      1.2202298641204834e-01
    z[0,5,5]  R840      4.0418398380279541e-01
    z[0,5,5]  R841      2.4127800762653351e-01
    z[0,5,5]  R842      3.3906900882720947e-01
    z[0,5,5]  R843      1.9571685791015625e-01
    z[0,5,5]  R844      1.9128678739070892e-01
    z[0,5,5]  R845      2.3606701195240021e-01
    z[0,5,5]  R846      2.2576029598712921e-01
    z[0,5,5]  R847      2.5895288586616516e-01
    z[0,5,5]  R848      -9.7800888121128082e-02
    z[0,5,5]  R849      4.8127859830856323e-01
    z[0,5,5]  R850      3.4379370510578156e-02
    z[0,5,5]  R851      4.5455446839332581e-01
    z[0,5,5]  R852      1.9042412936687469e-01
    z[0,5,5]  R853      -1.4963570237159729e-01
    z[0,5,5]  R854      1.5943725407123566e-01
    z[0,5,5]  R855      -1.4460238814353943e-01
    z[0,5,5]  R856      0.153371199965477
    z[0,5,5]  R857      -3.3803086262196302e-03
    z[0,5,5]  R858      -3.6988425254821777e-01
    z[0,5,5]  R859      -8.7918937206268311e-02
    z[0,5,5]  R860      1.4753676950931549e-01
    z[0,5,5]  R861      2.2540971636772156e-01
    z[0,5,5]  R862      -1.2416794151067734e-01
    z[0,5,5]  R863      -2.2571860253810883e-01
    z[0,5,5]  R864      2.1349491178989410e-01
    z[0,5,5]  R865      -3.2175779342651367e-01
    z[0,5,5]  R866      -8.9688688516616821e-02
    z[0,5,5]  R867      -4.6436771750450134e-01
    z[0,5,5]  R868      -4.8269324004650116e-02
    z[0,5,5]  R869      -2.1966648101806641e-01
    z[0,5,5]  R870      -2.3388341069221497e-02
    z[0,5,5]  R871      -9.2022478580474854e-02
    z[0,5,5]  R872      5.3409904241561890e-02
    z[0,5,5]  R873      -3.2578635215759277e-01
    z[0,5,5]  R874      -8.8714793324470520e-02
    z[0,5,5]  R875      -0.312102735042572
    z[0,5,5]  R876      0.867109477519989
    z[0,5,5]  R877      7.5873774290084839e-01
    z[0,5,6]  R8        -1
    z[0,5,6]  R53       1
    z[0,5,6]  R736      -1
    z[0,5,6]  R737      1
    z[0,5,6]  R738      1.9107328355312347e-01
    z[0,5,6]  R739      3.0165421962738037e-01
    z[0,5,6]  R740      1.3045558333396912e-01
    z[0,5,6]  R741      2.6932266354560852e-01
    z[0,5,6]  R742      -2.1146193146705627e-01
    z[0,5,6]  R743      2.8522223234176636e-01
    z[0,5,6]  R744      -2.6264557242393494e-01
    z[0,5,6]  R745      -5.1534049212932587e-02
    z[0,5,6]  R746      -2.6396539807319641e-01
    z[0,5,6]  R747      5.9392873197793961e-02
    z[0,5,6]  R748      6.3238894939422607e-01
    z[0,5,6]  R749      4.8657186329364777e-02
    z[0,5,6]  R750      2.2225466370582581e-01
    z[0,5,6]  R751      2.6226265355944633e-02
    z[0,5,6]  R752      -8.5489697754383087e-02
    z[0,5,6]  R753      1.1524365842342377e-01
    z[0,5,6]  R754      -6.0925945639610291e-02
    z[0,5,6]  R755      2.4047592282295227e-01
    z[0,5,6]  R756      2.7839845418930054e-01
    z[0,5,6]  R757      1.4632443897426128e-02
    z[0,5,6]  R758      -1.9516487419605255e-01
    z[0,5,6]  R759      3.6841621994972229e-01
    z[0,5,6]  R760      -1.7419892549514771e-01
    z[0,5,6]  R761      -1.0508665442466736e-01
    z[0,5,6]  R762      2.1887370944023132e-01
    z[0,5,6]  R763      4.9801462888717651e-01
    z[0,5,6]  R764      -2.0023313164710999e-01
    z[0,5,6]  R765      4.2687371373176575e-02
    z[0,5,6]  R766      -1.7269712686538696e-01
    z[0,5,6]  R767      2.5844737887382507e-01
    z[0,5,6]  R768      2.2752356529235840e-01
    z[0,5,6]  R769      3.2015082240104675e-01
    z[0,5,6]  R770      -3.0852247029542923e-02
    z[0,5,6]  R771      -1.4967158436775208e-01
    z[0,5,6]  R772      1.0632573813199997e-01
    z[0,5,6]  R773      -2.5837266445159912e-01
    z[0,5,6]  R774      1.5754364430904388e-01
    z[0,5,6]  R775      2.8766760230064392e-01
    z[0,5,6]  R776      1.4787826687097549e-02
    z[0,5,6]  R777      -3.1033328175544739e-01
    z[0,5,6]  R778      -1.5594394505023956e-01
    z[0,5,6]  R779      -2.1786347031593323e-01
    z[0,5,6]  R780      4.2473133653402328e-03
    z[0,5,6]  R781      5.7245563715696335e-02
    z[0,5,6]  R782      2.0748578011989594e-01
    z[0,5,6]  R783      9.0484723448753357e-02
    z[0,5,6]  R784      3.7761884927749634e-01
    z[0,5,6]  R785      1.8649470806121826e-01
    z[0,5,6]  R786      3.0846813693642616e-02
    z[0,5,6]  R787      -3.6305539309978485e-02
    z[0,5,6]  R788      1.4598475396633148e-01
    z[0,5,6]  R789      -4.3949750065803528e-01
    z[0,5,6]  R790      -3.2506820559501648e-01
    z[0,5,6]  R791      4.5821475982666016e-01
    z[0,5,6]  R792      -2.0079061388969421e-01
    z[0,5,6]  R793      2.7436956763267517e-01
    z[0,5,6]  R794      3.0983682721853256e-02
    z[0,5,6]  R795      -2.7007344365119934e-01
    z[0,5,6]  R796      4.2271953821182251e-01
    z[0,5,6]  R797      -2.1987275779247284e-01
    z[0,5,6]  R798      1.7963241040706635e-01
    z[0,5,6]  R799      -2.9832735657691956e-01
    z[0,5,6]  R800      0.0983017086982727
    z[0,5,6]  R801      -3.1668996810913086e-01
    z[0,5,6]  R802      1.5204668045043945e-01
    z[0,5,6]  R803      1.3626010715961456e-01
    z[0,5,6]  R804      -5.1867388188838959e-02
    z[0,5,6]  R805      2.4919275939464569e-01
    z[0,5,6]  R806      -8.0029524862766266e-02
    z[0,5,6]  R807      -6.3693143427371979e-02
    z[0,5,6]  R808      -2.0735444128513336e-01
    z[0,5,6]  R809      -6.4610382542014122e-03
    z[0,5,6]  R810      3.9105647802352905e-01
    z[0,5,6]  R811      -9.8922356963157654e-02
    z[0,5,6]  R812      -7.9763151705265045e-02
    z[0,5,6]  R813      -4.5124265551567078e-01
    z[0,5,6]  R814      2.8198403120040894e-01
    z[0,5,6]  R815      2.2629508748650551e-02
    z[0,5,6]  R816      2.7077522128820419e-02
    z[0,5,6]  R817      2.3101305961608887e-01
    z[0,5,6]  R818      0.200897216796875
    z[0,5,6]  R819      -1.4587773382663727e-01
    z[0,5,6]  R820      -2.3490564525127411e-01
    z[0,5,6]  R821      3.2156085968017578e-01
    z[0,5,6]  R822      -1.8251250684261322e-01
    z[0,5,6]  R823      1.9953005015850067e-01
    z[0,5,6]  R824      -6.6221915185451508e-02
    z[0,5,6]  R825      8.4433071315288544e-02
    z[0,5,6]  R826      0.0134742995724082
    z[0,5,6]  R827      -2.3847445845603943e-01
    z[0,5,6]  R828      -2.4073512852191925e-01
    z[0,5,6]  R829      -1.2841922044754028e-01
    z[0,5,6]  R830      1.9455133378505707e-01
    z[0,5,6]  R831      -9.2191033065319061e-02
    z[0,5,6]  R832      6.5413199365139008e-02
    z[0,5,6]  R833      5.1288757473230362e-02
    z[0,5,6]  R834      3.5724171996116638e-01
    z[0,5,6]  R835      1.0929439961910248e-01
    z[0,5,6]  R836      5.8313125371932983e-01
    z[0,5,6]  R837      -1.7309702932834625e-02
    z[0,5,6]  R838      -5.0625193119049072e-01
    z[0,5,6]  R839      -1.2640132009983063e-01
    z[0,5,6]  R840      8.3364490419626236e-03
    z[0,5,6]  R841      -1.4134739339351654e-01
    z[0,5,6]  R842      2.9050955176353455e-01
    z[0,5,6]  R843      -3.0355167388916016e-01
    z[0,5,6]  R844      -1.9361393153667450e-01
    z[0,5,6]  R845      1.2838077545166016e-01
    z[0,5,6]  R846      7.5807720422744751e-02
    z[0,5,6]  R847      -4.8850125074386597e-01
    z[0,5,6]  R848      -2.0394796133041382e-01
    z[0,5,6]  R849      1.3101337850093842e-01
    z[0,5,6]  R850      2.6964184641838074e-01
    z[0,5,6]  R851      -2.0788739621639252e-01
    z[0,5,6]  R852      -3.7755563855171204e-01
    z[0,5,6]  R853      -2.4842904508113861e-01
    z[0,5,6]  R854      1.4364540576934814e-01
    z[0,5,6]  R855      1.6188396513462067e-01
    z[0,5,6]  R856      -2.2402470931410789e-02
    z[0,5,6]  R857      -1.9644704461097717e-01
    z[0,5,6]  R858      9.3915618956089020e-02
    z[0,5,6]  R859      0.454225093126297
    z[0,5,6]  R860      8.5165657103061676e-02
    z[0,5,6]  R861      4.3079477548599243e-01
    z[0,5,6]  R862      3.4523203969001770e-01
    z[0,5,6]  R863      1.4997215941548347e-02
    z[0,5,6]  R864      -3.3137810230255127e-01
    z[0,5,6]  R865      4.1690585017204285e-01
    z[0,5,6]  R866      -2.6097485423088074e-01
    z[0,5,6]  R867      -3.3129367977380753e-02
    z[0,5,6]  R868      5.1669991016387939e-01
    z[0,5,6]  R869      6.0928516089916229e-02
    z[0,5,6]  R870      3.1819772720336914e-01
    z[0,5,6]  R871      -3.2967534661293030e-01
    z[0,5,6]  R872      -2.7402088046073914e-01
    z[0,5,6]  R873      -1.2210775911808014e-01
    z[0,5,6]  R874      -9.0648196637630463e-02
    z[0,5,6]  R875      -3.0467414855957031e-01
    z[0,5,6]  R876      -2.7823492884635925e-01
    z[0,5,6]  R877      -3.6152851581573486e-01
    z[5,0,0]  R2        1
    z[5,0,0]  R47       -1
    z[5,0,0]  R878      -1
    z[5,0,0]  R879      1
    z[5,0,0]  R892      6.8481421470642090e-01
    z[5,0,0]  R893      4.2407432198524475e-01
    z[5,0,0]  R894      4.7219285368919373e-01
    z[5,0,0]  R895      2.9902374744415283e-01
    z[5,0,0]  R896      0.471809983253479
    z[5,0,0]  R897      0.557436466217041
    z[5,0,0]  R898      4.0043455362319946e-01
    z[5,0,0]  R899      4.1340434551239014e-01
    z[5,0,0]  R900      5.8189934492111206e-01
    z[5,0,0]  R901      -1.5772767364978790e-01
    z[5,0,0]  R902      -2.9264262318611145e-01
    z[5,0,0]  R903      2.9907515645027161e-01
    z[5,0,0]  R904      1.0870525985956192e-01
    z[5,0,0]  R905      4.1055597364902496e-02
    z[5,0,0]  R906      3.0551312491297722e-02
    z[5,0,0]  R907      -1.6856157779693604e-01
    z[5,0,0]  R908      -2.2263364493846893e-01
    z[5,0,0]  R909      -2.1212583780288696e-01
    z[5,0,0]  R910      -3.8890343159437180e-02
    z[5,0,0]  R911      -4.6333214640617371e-01
    z[5,0,0]  R912      6.4265592955052853e-03
    z[5,0,0]  R913      -3.6780755966901779e-02
    z[5,0,0]  R914      -2.7314704656600952e-01
    z[5,0,0]  R915      -3.8201864808797836e-02
    z[5,0,0]  R916      -3.4061646461486816e-01
    z[5,0,0]  R917      -3.0403605103492737e-01
    z[5,0,0]  R918      4.5423296093940735e-01
    z[5,0,0]  R919      -4.1578122973442078e-01
    z[5,0,0]  R920      -3.0241400003433228e-01
    z[5,0,0]  R921      3.4000226855278015e-01
    z[5,0,0]  R922      -1.1205981671810150e-01
    z[5,0,0]  R923      7.9000806808471680e-01
    z[5,0,0]  R924      5.3096508979797363e-01
    z[5,0,0]  R925      2.3741620779037476e-01
    z[5,0,0]  R926      5.5252593010663986e-02
    z[5,0,0]  R927      6.1953570693731308e-02
    z[5,0,0]  R928      3.7581798434257507e-01
    z[5,0,0]  R929      -0.425283819437027
    z[5,0,0]  R930      2.7152949571609497e-01
    z[5,0,0]  R931      -4.0629756450653076e-01
    z[5,0,0]  R932      -9.1883011162281036e-02
    z[5,0,0]  R933      3.7221607565879822e-01
    z[5,0,0]  R934      1.4681921899318695e-01
    z[5,0,0]  R935      4.0812635421752930e-01
    z[5,0,0]  R936      2.3946161568164825e-01
    z[5,0,0]  R937      -5.7091158628463745e-01
    z[5,0,0]  R938      -7.7465665340423584e-01
    z[5,0,0]  R939      -6.2244963645935059e-01
    z[5,0,0]  R940      -2.3654049634933472e-01
    z[5,0,0]  R941      -3.8324549794197083e-01
    z[5,0,0]  R942      -6.4063489437103271e-02
    z[5,0,0]  R943      1.6059769690036774e-01
    z[5,0,0]  R944      1.3274246454238892e-01
    z[5,0,0]  R945      6.3208468258380890e-02
    z[5,0,0]  R946      1.0475829988718033e-01
    z[5,0,0]  R947      1.5666396915912628e-01
    z[5,0,0]  R948      2.4719725549221039e-01
    z[5,0,0]  R949      5.6741088628768921e-01
    z[5,0,0]  R950      5.1577204465866089e-01
    z[5,0,0]  R951      -6.9601279497146606e-01
    z[5,0,0]  R952      -1.3350605964660645e-01
    z[5,0,0]  R953      1.7930482327938080e-01
    z[5,0,0]  R954      -2.8537398576736450e-01
    z[5,0,0]  R955      1.6607774794101715e-01
    z[5,0,0]  R956      5.1720064133405685e-02
    z[5,0,0]  R957      -8.3205364644527435e-03
    z[5,0,0]  R958      4.0531735867261887e-02
    z[5,0,0]  R959      7.2678372263908386e-02
    z[5,0,0]  R960      0.260046124458313
    z[5,0,0]  R961      1.3106101751327515e-01
    z[5,0,0]  R962      -3.5949856042861938e-02
    z[5,0,0]  R963      2.7664564549922943e-02
    z[5,0,0]  R964      7.8953303396701813e-02
    z[5,0,0]  R965      1.5168353915214539e-01
    z[5,0,0]  R966      -3.3841833472251892e-01
    z[5,0,0]  R967      -2.2327479720115662e-01
    z[5,0,0]  R968      -2.6558920741081238e-01
    z[5,0,0]  R969      1.4662556350231171e-02
    z[5,0,0]  R970      -0.260986864566803
    z[5,0,0]  R971      -3.6370101571083069e-01
    z[5,0,0]  R972      3.5187106579542160e-02
    z[5,0,0]  R973      -1.2392750382423401e-01
    z[5,0,0]  R974      -4.5920538902282715e-01
    z[5,0,0]  R975      0.0667165070772171
    z[5,0,0]  R976      -2.9462891817092896e-01
    z[5,0,0]  R977      0.644294261932373
    z[5,0,0]  R978      -4.7134527564048767e-01
    z[5,0,0]  R979      2.8061863034963608e-02
    z[5,0,0]  R980      3.2971829175949097e-01
    z[5,0,0]  R981      6.9544982910156250e-01
    z[5,0,0]  R982      8.0374181270599365e-02
    z[5,0,0]  R983      4.4361403584480286e-01
    z[5,0,0]  R984      -2.3828917741775513e-01
    z[5,0,0]  R985      3.4130752086639404e-01
    z[5,0,0]  R986      -4.8296146094799042e-02
    z[5,0,0]  R987      -2.8567740321159363e-01
    z[5,0,0]  R988      -3.0408853292465210e-01
    z[5,0,0]  R989      7.3413014411926270e-01
    z[5,0,0]  R990      0.762452244758606
    z[5,0,0]  R991      -1.3330757617950439e-01
    z[5,0,0]  R992      0.0967952162027359
    z[5,0,0]  R993      5.4665857553482056e-01
    z[5,0,0]  R994      5.7045292854309082e-01
    z[5,0,0]  R995      4.8920072615146637e-02
    z[5,0,0]  R996      2.1173666417598724e-01
    z[5,0,0]  R997      4.0548691153526306e-01
    z[5,0,0]  R998      1.5091603994369507e-01
    z[5,0,0]  R999      6.5789061784744263e-01
    z[5,0,0]  R1000     -4.8623021692037582e-02
    z[5,0,0]  R1001     2.5142499804496765e-01
    z[5,0,0]  R1002     1.9243241846561432e-01
    z[5,0,0]  R1003     3.9235064387321472e-01
    z[5,0,0]  R1004     2.9140564799308777e-01
    z[5,0,0]  R1005     6.2068152427673340e-01
    z[5,0,0]  R1006     -3.7842559814453125e-01
    z[5,0,0]  R1007     1.0778354853391647e-01
    z[5,0,0]  R1008     4.9369942396879196e-02
    z[5,0,0]  R1009     -6.9795258343219757e-02
    z[5,0,0]  R1010     -1.4652828872203827e-01
    z[5,0,0]  R1011     0.0670105367898941
    z[5,0,0]  R1012     0.550288736820221
    z[5,0,0]  R1013     3.2825458794832230e-02
    z[5,0,0]  R1014     -2.2199097275733948e-01
    z[5,0,0]  R1015     -3.4488037228584290e-02
    z[5,0,0]  R1016     1.8360415101051331e-01
    z[5,0,0]  R1017     1.9765444099903107e-01
    z[5,0,0]  R1018     -4.3908235430717468e-01
    z[5,0,0]  R1019     -6.3887882232666016e-01
    z[5,0,0]  R1020     -4.3565583229064941e-01
    z[5,0,0]  R1021     -4.5687532424926758e-01
    z[5,0,0]  R1022     0.084299735724926
    z[5,0,0]  R1023     -4.7861550003290176e-02
    z[5,0,0]  R1024     3.4174117445945740e-01
    z[5,0,0]  R1025     -3.4983676671981812e-01
    z[5,0,0]  R1026     -1.5232269465923309e-01
    z[5,0,0]  R1027     -4.1082230210304260e-01
    z[5,0,0]  R1028     -3.1880471110343933e-01
    z[5,0,0]  R1029     -2.5601112842559814e-01
    z[5,0,0]  R1030     -1.4790304005146027e-01
    z[5,0,0]  R1031     1.4020407572388649e-02
    z[5,0,1]  R3        1
    z[5,0,1]  R48       -1
    z[5,0,1]  R880      -1
    z[5,0,1]  R881      1
    z[5,0,1]  R892      -8.1086881458759308e-02
    z[5,0,1]  R893      -6.2803596258163452e-02
    z[5,0,1]  R894      -3.4306907653808594e-01
    z[5,0,1]  R895      -1.9525711238384247e-01
    z[5,0,1]  R896      -4.2736664414405823e-01
    z[5,0,1]  R897      3.7686202675104141e-02
    z[5,0,1]  R898      8.1025041639804840e-02
    z[5,0,1]  R899      -5.9450343251228333e-02
    z[5,0,1]  R900      1.1442169547080994e-01
    z[5,0,1]  R901      1.1627613753080368e-01
    z[5,0,1]  R902      6.6820508241653442e-01
    z[5,0,1]  R903      -7.8152108192443848e-01
    z[5,0,1]  R904      -8.5610884428024292e-01
    z[5,0,1]  R905      -8.3617657423019409e-01
    z[5,0,1]  R906      -8.7166756391525269e-01
    z[5,0,1]  R907      6.8277293443679810e-01
    z[5,0,1]  R908      -8.6038815975189209e-01
    z[5,0,1]  R909      -8.2086509466171265e-01
    z[5,0,1]  R910      -7.5712805986404419e-01
    z[5,0,1]  R911      0.513932466506958
    z[5,0,1]  R912      7.9905492067337036e-01
    z[5,0,1]  R913      5.6476676464080811e-01
    z[5,0,1]  R914      7.2334295511245728e-01
    z[5,0,1]  R915      6.2016886472702026e-01
    z[5,0,1]  R916      5.9186714887619019e-01
    z[5,0,1]  R917      6.1776363849639893e-01
    z[5,0,1]  R918      7.4573993682861328e-01
    z[5,0,1]  R919      7.5574219226837158e-01
    z[5,0,1]  R920      9.0976518392562866e-01
    z[5,0,1]  R921      7.1882611513137817e-01
    z[5,0,1]  R922      3.0438011884689331e-01
    z[5,0,1]  R923      -4.9998942762613297e-02
    z[5,0,1]  R924      -0.732832133769989
    z[5,0,1]  R925      5.9587860107421875e-01
    z[5,0,1]  R926      -7.4152338504791260e-01
    z[5,0,1]  R927      5.1899129152297974e-01
    z[5,0,1]  R928      4.2850050330162048e-01
    z[5,0,1]  R929      6.1402846127748489e-02
    z[5,0,1]  R930      3.9935836195945740e-01
    z[5,0,1]  R931      -1.1253734678030014e-01
    z[5,0,1]  R932      4.6186193823814392e-01
    z[5,0,1]  R933      -8.9172267913818359e-01
    z[5,0,1]  R934      7.1494489908218384e-01
    z[5,0,1]  R935      5.7863938808441162e-01
    z[5,0,1]  R936      5.5286550521850586e-01
    z[5,0,1]  R937      -7.4655382195487618e-04
    z[5,0,1]  R938      -1.5049608051776886e-01
    z[5,0,1]  R939      -7.8971035778522491e-02
    z[5,0,1]  R940      -2.5156855583190918e-01
    z[5,0,1]  R941      -6.4073219895362854e-02
    z[5,0,1]  R942      -5.2023779600858688e-02
    z[5,0,1]  R943      1.8688815832138062e-01
    z[5,0,1]  R944      -2.0055456459522247e-01
    z[5,0,1]  R945      4.0589934587478638e-01
    z[5,0,1]  R946      -3.5552942752838135e-01
    z[5,0,1]  R947      1.1135175079107285e-01
    z[5,0,1]  R948      1.5564145147800446e-01
    z[5,0,1]  R949      -1.4409725368022919e-01
    z[5,0,1]  R950      -3.5696956515312195e-01
    z[5,0,1]  R951      -6.0474425554275513e-01
    z[5,0,1]  R952      5.9611005708575249e-03
    z[5,0,1]  R953      -1.3778430223464966e-01
    z[5,0,1]  R954      1.5254957973957062e-01
    z[5,0,1]  R955      4.2437443137168884e-01
    z[5,0,1]  R956      -3.2389974594116211e-01
    z[5,0,1]  R957      -3.8495957851409912e-01
    z[5,0,1]  R958      -5.0874465703964233e-01
    z[5,0,1]  R959      -3.6350693553686142e-02
    z[5,0,1]  R960      0.101785808801651
    z[5,0,1]  R961      1.9338355958461761e-01
    z[5,0,1]  R962      4.4235434383153915e-02
    z[5,0,1]  R963      -5.3629451990127563e-01
    z[5,0,1]  R964      0.81854248046875
    z[5,0,1]  R965      6.3725358247756958e-01
    z[5,0,1]  R966      -1.5819889307022095e-01
    z[5,0,1]  R967      4.4261854887008667e-01
    z[5,0,1]  R968      -4.1794739663600922e-02
    z[5,0,1]  R969      8.7619268894195557e-01
    z[5,0,1]  R970      1.1899554729461670e-01
    z[5,0,1]  R971      3.3444416522979736e-01
    z[5,0,1]  R972      -2.4165698885917664e-01
    z[5,0,1]  R973      2.8275391459465027e-01
    z[5,0,1]  R974      3.5537354648113251e-02
    z[5,0,1]  R975      -7.6254919171333313e-02
    z[5,0,1]  R976      -4.0073856711387634e-02
    z[5,0,1]  R977      0.0935761034488678
    z[5,0,1]  R978      -2.2781632840633392e-01
    z[5,0,1]  R979      0.36614990234375
    z[5,0,1]  R980      2.5656276941299438e-01
    z[5,0,1]  R981      3.1483608484268188e-01
    z[5,0,1]  R982      5.7906292378902435e-02
    z[5,0,1]  R983      7.1568292379379272e-01
    z[5,0,1]  R984      -3.4410279989242554e-01
    z[5,0,1]  R985      2.2935485467314720e-03
    z[5,0,1]  R986      0.634415328502655
    z[5,0,1]  R987      7.4076700210571289e-01
    z[5,0,1]  R988      5.5692654848098755e-01
    z[5,0,1]  R989      6.0079181194305420e-01
    z[5,0,1]  R990      5.2259796857833862e-01
    z[5,0,1]  R991      -9.6683973073959351e-01
    z[5,0,1]  R992      3.7239167094230652e-01
    z[5,0,1]  R993      -5.7963605970144272e-02
    z[5,0,1]  R994      -4.1433505713939667e-02
    z[5,0,1]  R995      -6.8225346505641937e-02
    z[5,0,1]  R996      -1.5415996313095093e-01
    z[5,0,1]  R997      -3.3002066612243652e-01
    z[5,0,1]  R998      -0.294149249792099
    z[5,0,1]  R999      3.0904176831245422e-01
    z[5,0,1]  R1000     1.3697081804275513e-01
    z[5,0,1]  R1001     0.750571072101593
    z[5,0,1]  R1002     -3.0818048119544983e-01
    z[5,0,1]  R1003     2.4123266339302063e-01
    z[5,0,1]  R1004     1.3480287790298462e-01
    z[5,0,1]  R1005     1.3289435207843781e-01
    z[5,0,1]  R1006     -2.2830264270305634e-01
    z[5,0,1]  R1007     3.2131770253181458e-01
    z[5,0,1]  R1008     -2.1391832828521729e-01
    z[5,0,1]  R1009     2.7872404456138611e-01
    z[5,0,1]  R1010     -2.0348201692104340e-01
    z[5,0,1]  R1011     6.0059273242950439e-01
    z[5,0,1]  R1012     1.6556029021739960e-01
    z[5,0,1]  R1013     -1.4329962432384491e-01
    z[5,0,1]  R1014     2.1220651268959045e-01
    z[5,0,1]  R1015     -1.6914875805377960e-01
    z[5,0,1]  R1016     -1.4743930101394653e-01
    z[5,0,1]  R1017     -1.7499189078807831e-01
    z[5,0,1]  R1018     -3.5884156823158264e-01
    z[5,0,1]  R1019     5.8143043518066406e-01
    z[5,0,1]  R1020     -8.5988634824752808e-01
    z[5,0,1]  R1021     -8.2960969209671021e-01
    z[5,0,1]  R1022     2.7405783534049988e-01
    z[5,0,1]  R1023     1.1639898270368576e-01
    z[5,0,1]  R1024     -9.9900364875793457e-02
    z[5,0,1]  R1025     -1.8450449407100677e-01
    z[5,0,1]  R1026     -9.3087553977966309e-01
    z[5,0,1]  R1027     -8.3404815196990967e-01
    z[5,0,1]  R1028     -0.841460645198822
    z[5,0,1]  R1029     -8.5124516487121582e-01
    z[5,0,1]  R1030     -3.2479953765869141e-01
    z[5,0,1]  R1031     -9.0595930814743042e-01
    z[5,0,2]  R4        1
    z[5,0,2]  R49       -1
    z[5,0,2]  R882      -1
    z[5,0,2]  R883      1
    z[5,0,2]  R892      -4.9701955914497375e-01
    z[5,0,2]  R893      -4.9604868888854980e-01
    z[5,0,2]  R894      -4.8486655950546265e-01
    z[5,0,2]  R895      -2.7913671731948853e-01
    z[5,0,2]  R896      -9.4179607927799225e-02
    z[5,0,2]  R897      -3.9441445469856262e-01
    z[5,0,2]  R898      -5.9366188943386078e-02
    z[5,0,2]  R899      -7.4587929248809814e-01
    z[5,0,2]  R900      -3.0251011252403259e-01
    z[5,0,2]  R901      -9.3451154232025146e-01
    z[5,0,2]  R902      1.1230071634054184e-01
    z[5,0,2]  R903      5.0350213050842285e-01
    z[5,0,2]  R904      -7.9214975237846375e-02
    z[5,0,2]  R905      4.4775810837745667e-01
    z[5,0,2]  R906      6.5615884959697723e-02
    z[5,0,2]  R907      3.6876353621482849e-01
    z[5,0,2]  R908      1.0235640406608582e-01
    z[5,0,2]  R909      0.285470187664032
    z[5,0,2]  R910      4.4804835319519043e-01
    z[5,0,2]  R911      -2.7570006251335144e-01
    z[5,0,2]  R912      -3.4256786108016968e-01
    z[5,0,2]  R913      -6.4214640855789185e-01
    z[5,0,2]  R914      -4.3363049626350403e-01
    z[5,0,2]  R915      -5.2234929800033569e-01
    z[5,0,2]  R916      -5.8482336997985840e-01
    z[5,0,2]  R917      -6.3599956035614014e-01
    z[5,0,2]  R918      -4.3129000067710876e-01
    z[5,0,2]  R919      -3.1067979335784912e-01
    z[5,0,2]  R920      1.2998823076486588e-02
    z[5,0,2]  R921      1.3436928391456604e-01
    z[5,0,2]  R922      -8.5875076055526733e-01
    z[5,0,2]  R923      3.4931668639183044e-01
    z[5,0,2]  R924      -1.3806378841400146e-01
    z[5,0,2]  R925      5.3474318981170654e-01
    z[5,0,2]  R926      4.8715031147003174e-01
    z[5,0,2]  R927      7.9511761665344238e-01
    z[5,0,2]  R928      6.2353795766830444e-01
    z[5,0,2]  R929      4.3923398852348328e-01
    z[5,0,2]  R930      6.3465487957000732e-01
    z[5,0,2]  R931      6.8603628873825073e-01
    z[5,0,2]  R932      -5.9742176532745361e-01
    z[5,0,2]  R933      -3.2313343137502670e-02
    z[5,0,2]  R934      5.7549959421157837e-01
    z[5,0,2]  R935      5.0004667043685913e-01
    z[5,0,2]  R936      7.4372583627700806e-01
    z[5,0,2]  R937      3.8138604164123535e-01
    z[5,0,2]  R938      4.4182300567626953e-01
    z[5,0,2]  R939      -3.1139988452196121e-02
    z[5,0,2]  R940      -2.3227233439683914e-02
    z[5,0,2]  R941      3.3875235915184021e-01
    z[5,0,2]  R942      -5.6777913123369217e-02
    z[5,0,2]  R943      1.0353393852710724e-01
    z[5,0,2]  R944      -3.2702925801277161e-01
    z[5,0,2]  R945      -1.2539622187614441e-01
    z[5,0,2]  R946      -2.3582690954208374e-01
    z[5,0,2]  R947      -3.1900930404663086e-01
    z[5,0,2]  R948      -2.7136135101318359e-01
    z[5,0,2]  R949      4.4235885143280029e-02
    z[5,0,2]  R950      3.3006185293197632e-01
    z[5,0,2]  R951      2.7378043532371521e-01
    z[5,0,2]  R952      2.8532043099403381e-01
    z[5,0,2]  R953      -1.7149317264556885e-01
    z[5,0,2]  R954      8.2180345058441162e-01
    z[5,0,2]  R955      -6.7168600857257843e-02
    z[5,0,2]  R956      -1.7426814138889313e-01
    z[5,0,2]  R957      1.7528069019317627e-01
    z[5,0,2]  R958      -1.4055498875677586e-02
    z[5,0,2]  R959      3.2149147987365723e-01
    z[5,0,2]  R960      8.6558210849761963e-01
    z[5,0,2]  R961      9.3931305408477783e-01
    z[5,0,2]  R962      7.3067253828048706e-01
    z[5,0,2]  R963      -2.2591440379619598e-01
    z[5,0,2]  R964      -1.5671806037425995e-01
    z[5,0,2]  R965      5.5256050825119019e-01
    z[5,0,2]  R966      0.467549592256546
    z[5,0,2]  R967      -3.3615368604660034e-01
    z[5,0,2]  R968      3.6083319783210754e-01
    z[5,0,2]  R969      6.0788080096244812e-02
    z[5,0,2]  R970      -1.4985999464988708e-01
    z[5,0,2]  R971      2.6378521323204041e-01
    z[5,0,2]  R972      -3.1577392946928740e-03
    z[5,0,2]  R973      -2.0002222061157227e-01
    z[5,0,2]  R974      2.6407885551452637e-01
    z[5,0,2]  R975      -2.5432729721069336e-01
    z[5,0,2]  R976      -3.1636923551559448e-01
    z[5,0,2]  R977      -2.6361331343650818e-01
    z[5,0,2]  R978      -1.0337930172681808e-01
    z[5,0,2]  R979      4.4319942593574524e-01
    z[5,0,2]  R980      3.6318498849868774e-01
    z[5,0,2]  R981      2.8820511698722839e-01
    z[5,0,2]  R982      -3.6796236038208008e-01
    z[5,0,2]  R983      2.7848687767982483e-01
    z[5,0,2]  R984      -3.0173275619745255e-02
    z[5,0,2]  R985      7.3003798723220825e-01
    z[5,0,2]  R986      -1.7617985606193542e-01
    z[5,0,2]  R987      -8.4466069936752319e-02
    z[5,0,2]  R988      1.8327631056308746e-01
    z[5,0,2]  R989      -6.3278481364250183e-02
    z[5,0,2]  R990      -1.6766825318336487e-01
    z[5,0,2]  R991      1.3303583860397339e-01
    z[5,0,2]  R992      2.4208576977252960e-01
    z[5,0,2]  R993      -0.179097518324852
    z[5,0,2]  R994      1.1233936063945293e-02
    z[5,0,2]  R995      4.3308448791503906e-01
    z[5,0,2]  R996      2.5103539228439331e-01
    z[5,0,2]  R997      4.5756268501281738e-01
    z[5,0,2]  R998      4.3825164437294006e-01
    z[5,0,2]  R999      0.348513126373291
    z[5,0,2]  R1000     3.1630018353462219e-01
    z[5,0,2]  R1001     -4.0792483091354370e-01
    z[5,0,2]  R1002     -1.5815148130059242e-02
    z[5,0,2]  R1003     1.3097250461578369e-01
    z[5,0,2]  R1004     5.2823996543884277e-01
    z[5,0,2]  R1005     -2.1121042966842651e-01
    z[5,0,2]  R1006     -8.3415031433105469e-02
    z[5,0,2]  R1007     -1.9119301438331604e-01
    z[5,0,2]  R1008     5.0723668187856674e-02
    z[5,0,2]  R1009     1.6085717082023621e-01
    z[5,0,2]  R1010     8.1871229410171509e-01
    z[5,0,2]  R1011     4.4781997799873352e-01
    z[5,0,2]  R1012     -2.5352808833122253e-01
    z[5,0,2]  R1013     1.1890961229801178e-01
    z[5,0,2]  R1014     5.4404580593109131e-01
    z[5,0,2]  R1015     2.9344305396080017e-01
    z[5,0,2]  R1016     0.0649917870759964
    z[5,0,2]  R1017     3.0003413558006287e-01
    z[5,0,2]  R1018     5.0687056779861450e-01
    z[5,0,2]  R1019     1.9926688075065613e-01
    z[5,0,2]  R1020     2.7861837297677994e-02
    z[5,0,2]  R1021     6.4635850489139557e-02
    z[5,0,2]  R1022     -2.6343947649002075e-01
    z[5,0,2]  R1023     7.1777254343032837e-02
    z[5,0,2]  R1024     6.4623379707336426e-01
    z[5,0,2]  R1025     4.6222358942031860e-01
    z[5,0,2]  R1026     -0.252784788608551
    z[5,0,2]  R1027     -1.6858577728271484e-01
    z[5,0,2]  R1028     -2.5062909722328186e-01
    z[5,0,2]  R1029     -0.354160875082016
    z[5,0,2]  R1030     -1.4349471032619476e-01
    z[5,0,2]  R1031     1.0102648288011551e-01
    z[5,0,3]  R5        1
    z[5,0,3]  R50       -1
    z[5,0,3]  R884      -1
    z[5,0,3]  R885      1
    z[5,0,3]  R892      -3.5028973221778870e-01
    z[5,0,3]  R893      -8.2846589386463165e-02
    z[5,0,3]  R894      3.2014327589422464e-03
    z[5,0,3]  R895      -1.4209325611591339e-01
    z[5,0,3]  R896      7.1378417313098907e-02
    z[5,0,3]  R897      2.7369028329849243e-01
    z[5,0,3]  R898      1.1251424252986908e-01
    z[5,0,3]  R899      -2.3168994486331940e-01
    z[5,0,3]  R900      -2.6467078924179077e-01
    z[5,0,3]  R901      1.0491105914115906e-01
    z[5,0,3]  R902      0.0898166075348854
    z[5,0,3]  R903      -1.1651634424924850e-01
    z[5,0,3]  R904      -2.1026555448770523e-02
    z[5,0,3]  R905      6.8229183554649353e-02
    z[5,0,3]  R906      1.2749873101711273e-01
    z[5,0,3]  R907      4.5084267854690552e-02
    z[5,0,3]  R908      2.7704444527626038e-01
    z[5,0,3]  R909      0.355803906917572
    z[5,0,3]  R910      2.7114561200141907e-01
    z[5,0,3]  R911      2.5887799263000488e-01
    z[5,0,3]  R912      -2.9570633172988892e-01
    z[5,0,3]  R913      -1.3546113669872284e-01
    z[5,0,3]  R914      1.8554992973804474e-01
    z[5,0,3]  R915      -1.0255632549524307e-01
    z[5,0,3]  R916      6.0594443231821060e-02
    z[5,0,3]  R917      1.5278393030166626e-01
    z[5,0,3]  R918      6.0688290745019913e-02
    z[5,0,3]  R919      1.1022411286830902e-01
    z[5,0,3]  R920      6.9968298077583313e-02
    z[5,0,3]  R921      -3.5158935189247131e-01
    z[5,0,3]  R922      1.0737839341163635e-01
    z[5,0,3]  R923      1.6416235268115997e-01
    z[5,0,3]  R924      -1.6629289090633392e-01
    z[5,0,3]  R925      1.3947841711342335e-02
    z[5,0,3]  R926      2.2214072942733765e-01
    z[5,0,3]  R927      -1.9584783911705017e-01
    z[5,0,3]  R928      0.281126469373703
    z[5,0,3]  R929      -5.7939112186431885e-01
    z[5,0,3]  R930      5.0716590881347656e-01
    z[5,0,3]  R931      -3.6588475108146667e-01
    z[5,0,3]  R932      -7.0546649396419525e-02
    z[5,0,3]  R933      -0.0752662867307663
    z[5,0,3]  R934      8.5963584482669830e-02
    z[5,0,3]  R935      3.4735634922981262e-01
    z[5,0,3]  R936      7.2962991893291473e-02
    z[5,0,3]  R937      -6.3346517086029053e-01
    z[5,0,3]  R938      -3.9998832345008850e-01
    z[5,0,3]  R939      -0.642842173576355
    z[5,0,3]  R940      3.7850666791200638e-02
    z[5,0,3]  R941      1.6396088898181915e-01
    z[5,0,3]  R942      -9.2928916215896606e-01
    z[5,0,3]  R943      -0.804606556892395
    z[5,0,3]  R944      -8.5726940631866455e-01
    z[5,0,3]  R945      -8.5723048448562622e-01
    z[5,0,3]  R946      -8.0125230550765991e-01
    z[5,0,3]  R947      -7.1358543634414673e-01
    z[5,0,3]  R948      -7.9580336809158325e-01
    z[5,0,3]  R949      -1.5711851418018341e-01
    z[5,0,3]  R950      -2.7160879969596863e-01
    z[5,0,3]  R951      -1.3891610503196716e-01
    z[5,0,3]  R952      3.8556548953056335e-01
    z[5,0,3]  R953      4.3534025549888611e-01
    z[5,0,3]  R954      1.7657354474067688e-01
    z[5,0,3]  R955      3.9180862903594971e-01
    z[5,0,3]  R956      2.4762172996997833e-01
    z[5,0,3]  R957      2.9850077629089355e-01
    z[5,0,3]  R958      5.1189678907394409e-01
    z[5,0,3]  R959      3.6862105131149292e-01
    z[5,0,3]  R960      2.1526399254798889e-01
    z[5,0,3]  R961      1.1522676795721054e-01
    z[5,0,3]  R962      4.4608378410339355e-01
    z[5,0,3]  R963      5.6817245483398438e-01
    z[5,0,3]  R964      2.0419143140316010e-01
    z[5,0,3]  R965      -2.1266290545463562e-01
    z[5,0,3]  R966      6.1207717657089233e-01
    z[5,0,3]  R967      2.3714180290699005e-01
    z[5,0,3]  R968      1.5064767003059387e-01
    z[5,0,3]  R969      3.3175039291381836e-01
    z[5,0,3]  R970      7.5979363918304443e-01
    z[5,0,3]  R971      6.5049648284912109e-01
    z[5,0,3]  R972      5.3698408603668213e-01
    z[5,0,3]  R973      4.9911034107208252e-01
    z[5,0,3]  R974      5.5468392372131348e-01
    z[5,0,3]  R975      5.2799969911575317e-01
    z[5,0,3]  R976      4.9183416366577148e-01
    z[5,0,3]  R977      -1.7968240380287170e-01
    z[5,0,3]  R978      5.0459164381027222e-01
    z[5,0,3]  R979      3.0800908803939819e-01
    z[5,0,3]  R980      6.0138350725173950e-01
    z[5,0,3]  R981      -2.4376663565635681e-01
    z[5,0,3]  R982      6.8626904487609863e-01
    z[5,0,3]  R983      -3.3575016260147095e-01
    z[5,0,3]  R984      6.3144260644912720e-01
    z[5,0,3]  R985      4.2121031880378723e-01
    z[5,0,3]  R986      5.6819815188646317e-02
    z[5,0,3]  R987      0.336073100566864
    z[5,0,3]  R988      1.5416452288627625e-01
    z[5,0,3]  R989      2.4057245254516602e-01
    z[5,0,3]  R990      1.6548976302146912e-01
    z[5,0,3]  R991      -9.2471368610858917e-02
    z[5,0,3]  R992      5.3288924694061279e-01
    z[5,0,3]  R993      -0.455875039100647
    z[5,0,3]  R994      -3.8344934582710266e-01
    z[5,0,3]  R995      0.614128053188324
    z[5,0,3]  R996      0.767065703868866
    z[5,0,3]  R997      3.5107195377349854e-01
    z[5,0,3]  R998      6.2618285417556763e-01
    z[5,0,3]  R999      -3.4679338335990906e-01
    z[5,0,3]  R1000     5.5651229619979858e-01
    z[5,0,3]  R1001     1.9736245274543762e-01
    z[5,0,3]  R1002     -8.5408180952072144e-01
    z[5,0,3]  R1003     -5.5037140846252441e-01
    z[5,0,3]  R1004     -7.3549979925155640e-01
    z[5,0,3]  R1005     -4.9482280015945435e-01
    z[5,0,3]  R1006     6.7564916610717773e-01
    z[5,0,3]  R1007     6.6907513141632080e-01
    z[5,0,3]  R1008     8.2581186294555664e-01
    z[5,0,3]  R1009     0.79014652967453
    z[5,0,3]  R1010     1.7215198278427124e-01
    z[5,0,3]  R1011     5.8378702402114868e-01
    z[5,0,3]  R1012     -0.62684565782547
    z[5,0,3]  R1013     0.827559769153595
    z[5,0,3]  R1014     6.0564368963241577e-01
    z[5,0,3]  R1015     6.2602764368057251e-01
    z[5,0,3]  R1016     2.5464054942131042e-01
    z[5,0,3]  R1017     4.9707618355751038e-01
    z[5,0,3]  R1018     2.4635070562362671e-01
    z[5,0,3]  R1019     7.9420171678066254e-03
    z[5,0,3]  R1020     7.3591373860836029e-02
    z[5,0,3]  R1021     -1.1864126473665237e-01
    z[5,0,3]  R1022     7.1144467592239380e-01
    z[5,0,3]  R1023     -6.2321805953979492e-01
    z[5,0,3]  R1024     0.448964923620224
    z[5,0,3]  R1025     1.6619957983493805e-01
    z[5,0,3]  R1026     1.0466784238815308e-01
    z[5,0,3]  R1027     1.7910125851631165e-01
    z[5,0,3]  R1028     3.1129390001296997e-01
    z[5,0,3]  R1029     2.0030494779348373e-02
    z[5,0,3]  R1030     9.6967602148652077e-03
    z[5,0,3]  R1031     2.0940619707107544e-01
    z[5,0,4]  R6        1
    z[5,0,4]  R51       -1
    z[5,0,4]  R886      -1
    z[5,0,4]  R887      1
    z[5,0,4]  R892      -1.5760441124439240e-01
    z[5,0,4]  R893      -0.446170449256897
    z[5,0,4]  R894      1.4418350160121918e-01
    z[5,0,4]  R895      2.7568724751472473e-01
    z[5,0,4]  R896      -1.8833811581134796e-01
    z[5,0,4]  R897      4.8487776517868042e-01
    z[5,0,4]  R898      -1.1457122862339020e-01
    z[5,0,4]  R899      4.2632073163986206e-01
    z[5,0,4]  R900      -3.1137070059776306e-01
    z[5,0,4]  R901      1.9011422991752625e-01
    z[5,0,4]  R902      -2.8852125629782677e-02
    z[5,0,4]  R903      4.2678169906139374e-02
    z[5,0,4]  R904      2.9173517227172852e-01
    z[5,0,4]  R905      1.2564468383789062e-01
    z[5,0,4]  R906      1.3905872404575348e-01
    z[5,0,4]  R907      -4.8676499724388123e-01
    z[5,0,4]  R908      2.2104050219058990e-01
    z[5,0,4]  R909      -2.9736701399087906e-02
    z[5,0,4]  R910      -3.0702257156372070e-01
    z[5,0,4]  R911      -2.6921811699867249e-01
    z[5,0,4]  R912      0.3248310983181
    z[5,0,4]  R913      -1.3797611929476261e-02
    z[5,0,4]  R914      -3.2528871297836304e-01
    z[5,0,4]  R915      -2.8412604331970215e-01
    z[5,0,4]  R916      9.5781035721302032e-02
    z[5,0,4]  R917      -1.1825407296419144e-01
    z[5,0,4]  R918      -4.2378310114145279e-02
    z[5,0,4]  R919      3.1653138995170593e-01
    z[5,0,4]  R920      -2.2756111621856689e-01
    z[5,0,4]  R921      -4.3291386961936951e-01
    z[5,0,4]  R922      1.3337983749806881e-02
    z[5,0,4]  R923      1.0181195288896561e-01
    z[5,0,4]  R924      -3.2449635863304138e-01
    z[5,0,4]  R925      2.5695082545280457e-01
    z[5,0,4]  R926      -1.6070288419723511e-01
    z[5,0,4]  R927      7.1187183260917664e-02
    z[5,0,4]  R928      2.2787061333656311e-01
    z[5,0,4]  R929      9.6975639462471008e-02
    z[5,0,4]  R930      1.7501041293144226e-01
    z[5,0,4]  R931      -3.1704951077699661e-02
    z[5,0,4]  R932      3.8346165418624878e-01
    z[5,0,4]  R933      8.7240047752857208e-02
    z[5,0,4]  R934      1.6404733061790466e-01
    z[5,0,4]  R935      -0.103693388402462
    z[5,0,4]  R936      -2.4617625400424004e-02
    z[5,0,4]  R937      7.9239696264266968e-02
    z[5,0,4]  R938      -7.7282056212425232e-02
    z[5,0,4]  R939      4.3240282684564590e-02
    z[5,0,4]  R940      2.2247716784477234e-01
    z[5,0,4]  R941      3.1550772488117218e-02
    z[5,0,4]  R942      2.9850891232490540e-01
    z[5,0,4]  R943      1.0379948467016220e-01
    z[5,0,4]  R944      6.7134196870028973e-03
    z[5,0,4]  R945      -2.4092530831694603e-02
    z[5,0,4]  R946      3.4442999958992004e-01
    z[5,0,4]  R947      -5.1885211467742920e-01
    z[5,0,4]  R948      3.5841333866119385e-01
    z[5,0,4]  R949      -4.1127124428749084e-01
    z[5,0,4]  R950      8.8618598878383636e-02
    z[5,0,4]  R951      2.2265779972076416e-01
    z[5,0,4]  R952      -4.9502938985824585e-01
    z[5,0,4]  R953      -8.5293418169021606e-01
    z[5,0,4]  R954      3.3291608095169067e-01
    z[5,0,4]  R955      -7.1162384748458862e-01
    z[5,0,4]  R956      -7.4344772100448608e-01
    z[5,0,4]  R957      -7.7911502122879028e-01
    z[5,0,4]  R958      -0.671019434928894
    z[5,0,4]  R959      -8.1939530372619629e-01
    z[5,0,4]  R960      2.0195983350276947e-01
    z[5,0,4]  R961      2.0293138921260834e-01
    z[5,0,4]  R962      4.4607225060462952e-01
    z[5,0,4]  R963      -4.4644799828529358e-01
    z[5,0,4]  R964      8.7363161146640778e-03
    z[5,0,4]  R965      3.6340811848640442e-01
    z[5,0,4]  R966      -2.9440057277679443e-01
    z[5,0,4]  R967      -3.7326484918594360e-01
    z[5,0,4]  R968      2.4924322962760925e-01
    z[5,0,4]  R969      3.0503988265991211e-01
    z[5,0,4]  R970      -7.0223741233348846e-02
    z[5,0,4]  R971      -1.9835433363914490e-01
    z[5,0,4]  R972      -7.0246893167495728e-01
    z[5,0,4]  R973      -0.702630341053009
    z[5,0,4]  R974      0.272499144077301
    z[5,0,4]  R975      -6.6848033666610718e-01
    z[5,0,4]  R976      -5.1927280426025391e-01
    z[5,0,4]  R977      -0.247806116938591
    z[5,0,4]  R978      -3.1744873523712158e-01
    z[5,0,4]  R979      -6.3552063703536987e-01
    z[5,0,4]  R980      -4.9319875240325928e-01
    z[5,0,4]  R981      -4.1530814766883850e-01
    z[5,0,4]  R982      -5.6754702329635620e-01
    z[5,0,4]  R983      2.3077231645584106e-01
    z[5,0,4]  R984      -4.7983753681182861e-01
    z[5,0,4]  R985      3.4534502029418945e-01
    z[5,0,4]  R986      4.1923069953918457e-01
    z[5,0,4]  R987      4.8716527223587036e-01
    z[5,0,4]  R988      4.9648800492286682e-01
    z[5,0,4]  R989      -1.5960346907377243e-02
    z[5,0,4]  R990      -6.6549576818943024e-02
    z[5,0,4]  R991      -1.2255188077688217e-01
    z[5,0,4]  R992      -6.6290569305419922e-01
    z[5,0,4]  R993      -3.7945404648780823e-01
    z[5,0,4]  R994      2.0986701548099518e-01
    z[5,0,4]  R995      2.1012732386589050e-01
    z[5,0,4]  R996      -0.489188551902771
    z[5,0,4]  R997      -3.6255702376365662e-02
    z[5,0,4]  R998      -5.0594764947891235e-01
    z[5,0,4]  R999      -3.7479439377784729e-01
    z[5,0,4]  R1000     -4.5726552605628967e-01
    z[5,0,4]  R1001     2.2959679365158081e-01
    z[5,0,4]  R1002     -3.2122680544853210e-01
    z[5,0,4]  R1003     -1.9119140505790710e-01
    z[5,0,4]  R1004     -1.7439144849777222e-01
    z[5,0,4]  R1005     -4.4242069125175476e-01
    z[5,0,4]  R1006     -4.1691732406616211e-01
    z[5,0,4]  R1007     -5.6202590465545654e-01
    z[5,0,4]  R1008     -0.505794107913971
    z[5,0,4]  R1009     -3.8944569230079651e-01
    z[5,0,4]  R1010     2.2215992212295532e-01
    z[5,0,4]  R1011     2.6274007558822632e-01
    z[5,0,4]  R1012     -4.0438213944435120e-01
    z[5,0,4]  R1013     -5.2583914995193481e-01
    z[5,0,4]  R1014     2.2356854379177094e-01
    z[5,0,4]  R1015     -4.9322238564491272e-01
    z[5,0,4]  R1016     -8.0460679531097412e-01
    z[5,0,4]  R1017     1.6704671084880829e-01
    z[5,0,4]  R1018     -2.9823830351233482e-02
    z[5,0,4]  R1019     4.2493402957916260e-01
    z[5,0,4]  R1020     2.2571101784706116e-01
    z[5,0,4]  R1021     1.7069098353385925e-01
    z[5,0,4]  R1022     -5.4182070493698120e-01
    z[5,0,4]  R1023     2.2802498936653137e-01
    z[5,0,4]  R1024     1.1553851515054703e-01
    z[5,0,4]  R1025     3.4038805961608887e-01
    z[5,0,4]  R1026     -4.0117930620908737e-02
    z[5,0,4]  R1027     -2.6049926877021790e-02
    z[5,0,4]  R1028     1.1090749502182007e-01
    z[5,0,4]  R1029     -3.5114653408527374e-02
    z[5,0,4]  R1030     6.0660088062286377e-01
    z[5,0,4]  R1031     6.9004237651824951e-02
    z[5,0,5]  R7        1
    z[5,0,5]  R52       -1
    z[5,0,5]  R888      -1
    z[5,0,5]  R889      1
    z[5,0,5]  R892      -2.6819872856140137e-01
    z[5,0,5]  R893      -5.8968561887741089e-01
    z[5,0,5]  R894      -6.0464257001876831e-01
    z[5,0,5]  R895      -8.3057153224945068e-01
    z[5,0,5]  R896      -7.3555302619934082e-01
    z[5,0,5]  R897      -4.6865555644035339e-01
    z[5,0,5]  R898      -8.2228648662567139e-01
    z[5,0,5]  R899      -0.147823303937912
    z[5,0,5]  R900      -2.2303384542465210e-01
    z[5,0,5]  R901      -2.0209042727947235e-01
    z[5,0,5]  R902      -0.435959130525589
    z[5,0,5]  R903      1.2202298641204834e-01
    z[5,0,5]  R904      4.0418398380279541e-01
    z[5,0,5]  R905      2.4127800762653351e-01
    z[5,0,5]  R906      3.3906900882720947e-01
    z[5,0,5]  R907      1.9571685791015625e-01
    z[5,0,5]  R908      1.9128678739070892e-01
    z[5,0,5]  R909      2.3606701195240021e-01
    z[5,0,5]  R910      2.2576029598712921e-01
    z[5,0,5]  R911      2.5895288586616516e-01
    z[5,0,5]  R912      -9.7800888121128082e-02
    z[5,0,5]  R913      4.8127859830856323e-01
    z[5,0,5]  R914      3.4379370510578156e-02
    z[5,0,5]  R915      4.5455446839332581e-01
    z[5,0,5]  R916      1.9042412936687469e-01
    z[5,0,5]  R917      -1.4963570237159729e-01
    z[5,0,5]  R918      1.5943725407123566e-01
    z[5,0,5]  R919      -1.4460238814353943e-01
    z[5,0,5]  R920      0.153371199965477
    z[5,0,5]  R921      -3.3803086262196302e-03
    z[5,0,5]  R922      -3.6988425254821777e-01
    z[5,0,5]  R923      -8.7918937206268311e-02
    z[5,0,5]  R924      1.4753676950931549e-01
    z[5,0,5]  R925      2.2540971636772156e-01
    z[5,0,5]  R926      -1.2416794151067734e-01
    z[5,0,5]  R927      -2.2571860253810883e-01
    z[5,0,5]  R928      2.1349491178989410e-01
    z[5,0,5]  R929      -3.2175779342651367e-01
    z[5,0,5]  R930      -8.9688688516616821e-02
    z[5,0,5]  R931      -4.6436771750450134e-01
    z[5,0,5]  R932      -4.8269324004650116e-02
    z[5,0,5]  R933      -2.1966648101806641e-01
    z[5,0,5]  R934      -2.3388341069221497e-02
    z[5,0,5]  R935      -9.2022478580474854e-02
    z[5,0,5]  R936      5.3409904241561890e-02
    z[5,0,5]  R937      -3.2578635215759277e-01
    z[5,0,5]  R938      -8.8714793324470520e-02
    z[5,0,5]  R939      -0.312102735042572
    z[5,0,5]  R940      0.867109477519989
    z[5,0,5]  R941      7.5873774290084839e-01
    z[5,0,5]  R942      -2.7762185782194138e-02
    z[5,0,5]  R943      -4.2355707287788391e-01
    z[5,0,5]  R944      -2.8850415349006653e-01
    z[5,0,5]  R945      8.6988382041454315e-02
    z[5,0,5]  R946      4.0703356266021729e-02
    z[5,0,5]  R947      3.9076272398233414e-02
    z[5,0,5]  R948      1.0142208635807037e-01
    z[5,0,5]  R949      -6.7737591266632080e-01
    z[5,0,5]  R950      -5.8848005533218384e-01
    z[5,0,5]  R951      4.9932379275560379e-02
    z[5,0,5]  R952      3.2726475596427917e-01
    z[5,0,5]  R953      8.3617325872182846e-03
    z[5,0,5]  R954      1.6888137161731720e-01
    z[5,0,5]  R955      3.5665473341941833e-01
    z[5,0,5]  R956      4.9061697721481323e-01
    z[5,0,5]  R957      3.3408010005950928e-01
    z[5,0,5]  R958      1.5271255373954773e-01
    z[5,0,5]  R959      1.5786384046077728e-01
    z[5,0,5]  R960      9.0284220874309540e-02
    z[5,0,5]  R961      9.1893002390861511e-02
    z[5,0,5]  R962      1.6373126208782196e-01
    z[5,0,5]  R963      -5.2146852016448975e-02
    z[5,0,5]  R964      4.7652739286422729e-01
    z[5,0,5]  R965      2.7792543172836304e-01
    z[5,0,5]  R966      3.6418086290359497e-01
    z[5,0,5]  R967      4.4458580017089844e-01
    z[5,0,5]  R968      8.2012486457824707e-01
    z[5,0,5]  R969      -1.5312202274799347e-01
    z[5,0,5]  R970      5.3218954801559448e-01
    z[5,0,5]  R971      3.9623332023620605e-01
    z[5,0,5]  R972      0.326760470867157
    z[5,0,5]  R973      1.3923436403274536e-01
    z[5,0,5]  R974      5.7900595664978027e-01
    z[5,0,5]  R975      4.2071428894996643e-01
    z[5,0,5]  R976      5.3725987672805786e-01
    z[5,0,5]  R977      -5.8837610483169556e-01
    z[5,0,5]  R978      5.7882612943649292e-01
    z[5,0,5]  R979      2.9531732201576233e-01
    z[5,0,5]  R980      -2.9737564921379089e-01
    z[5,0,5]  R981      7.7173076570034027e-02
    z[5,0,5]  R982      1.9338364899158478e-01
    z[5,0,5]  R983      -1.0505378013476729e-03
    z[5,0,5]  R984      4.4149649143218994e-01
    z[5,0,5]  R985      2.2492264211177826e-01
    z[5,0,5]  R986      -5.8490353822708130e-01
    z[5,0,5]  R987      6.3682332634925842e-02
    z[5,0,5]  R988      -3.8847097754478455e-01
    z[5,0,5]  R989      -5.6462105363607407e-02
    z[5,0,5]  R990      2.9099500179290771e-01
    z[5,0,5]  R991      6.9737970829010010e-02
    z[5,0,5]  R992      2.2050644457340240e-01
    z[5,0,5]  R993      3.4751009941101074e-01
    z[5,0,5]  R994      -6.1318314075469971e-01
    z[5,0,5]  R995      4.1727980971336365e-01
    z[5,0,5]  R996      1.9269576296210289e-02
    z[5,0,5]  R997      5.6343454122543335e-01
    z[5,0,5]  R998      -2.2268386185169220e-01
    z[5,0,5]  R999      1.2859074771404266e-01
    z[5,0,5]  R1000     -4.2583969235420227e-01
    z[5,0,5]  R1001     -2.5887307524681091e-01
    z[5,0,5]  R1002     -5.3237382322549820e-02
    z[5,0,5]  R1003     5.8502310514450073e-01
    z[5,0,5]  R1004     1.9193184375762939e-01
    z[5,0,5]  R1005     1.0772937536239624e-01
    z[5,0,5]  R1006     3.7983378767967224e-01
    z[5,0,5]  R1007     -2.5783991813659668e-01
    z[5,0,5]  R1008     -9.3516901135444641e-02
    z[5,0,5]  R1009     -2.3123618960380554e-01
    z[5,0,5]  R1010     4.2595624923706055e-01
    z[5,0,5]  R1011     -1.4268389344215393e-01
    z[5,0,5]  R1012     0.0777122750878334
    z[5,0,5]  R1013     -5.3333669900894165e-02
    z[5,0,5]  R1014     1.9997552037239075e-01
    z[5,0,5]  R1015     4.8900499939918518e-01
    z[5,0,5]  R1016     4.7088339924812317e-01
    z[5,0,5]  R1017     6.0139906406402588e-01
    z[5,0,5]  R1018     5.2955496311187744e-01
    z[5,0,5]  R1019     -1.8144200742244720e-01
    z[5,0,5]  R1020     1.1370515823364258e-01
    z[5,0,5]  R1021     -4.7502916306257248e-02
    z[5,0,5]  R1022     -9.1118104755878448e-02
    z[5,0,5]  R1023     7.1925801038742065e-01
    z[5,0,5]  R1024     4.3071508407592773e-01
    z[5,0,5]  R1025     6.1889731884002686e-01
    z[5,0,5]  R1026     2.2198554128408432e-02
    z[5,0,5]  R1027     -1.8600904941558838e-01
    z[5,0,5]  R1028     -1.1791043728590012e-01
    z[5,0,5]  R1029     -2.7503988146781921e-01
    z[5,0,5]  R1030     -6.9555658102035522e-01
    z[5,0,5]  R1031     -2.5169846415519714e-01
    z[5,0,6]  R8        1
    z[5,0,6]  R53       -1
    z[5,0,6]  R890      -1
    z[5,0,6]  R891      1
    z[5,0,6]  R892      -2.4073512852191925e-01
    z[5,0,6]  R893      -1.2841922044754028e-01
    z[5,0,6]  R894      1.9455133378505707e-01
    z[5,0,6]  R895      -9.2191033065319061e-02
    z[5,0,6]  R896      6.5413199365139008e-02
    z[5,0,6]  R897      5.1288757473230362e-02
    z[5,0,6]  R898      3.5724171996116638e-01
    z[5,0,6]  R899      1.0929439961910248e-01
    z[5,0,6]  R900      5.8313125371932983e-01
    z[5,0,6]  R901      -1.7309702932834625e-02
    z[5,0,6]  R902      -5.0625193119049072e-01
    z[5,0,6]  R903      -1.2640132009983063e-01
    z[5,0,6]  R904      8.3364490419626236e-03
    z[5,0,6]  R905      -1.4134739339351654e-01
    z[5,0,6]  R906      2.9050955176353455e-01
    z[5,0,6]  R907      -3.0355167388916016e-01
    z[5,0,6]  R908      -1.9361393153667450e-01
    z[5,0,6]  R909      1.2838077545166016e-01
    z[5,0,6]  R910      7.5807720422744751e-02
    z[5,0,6]  R911      -4.8850125074386597e-01
    z[5,0,6]  R912      -2.0394796133041382e-01
    z[5,0,6]  R913      1.3101337850093842e-01
    z[5,0,6]  R914      2.6964184641838074e-01
    z[5,0,6]  R915      -2.0788739621639252e-01
    z[5,0,6]  R916      -3.7755563855171204e-01
    z[5,0,6]  R917      -2.4842904508113861e-01
    z[5,0,6]  R918      1.4364540576934814e-01
    z[5,0,6]  R919      1.6188396513462067e-01
    z[5,0,6]  R920      -2.2402470931410789e-02
    z[5,0,6]  R921      -1.9644704461097717e-01
    z[5,0,6]  R922      9.3915618956089020e-02
    z[5,0,6]  R923      0.454225093126297
    z[5,0,6]  R924      8.5165657103061676e-02
    z[5,0,6]  R925      4.3079477548599243e-01
    z[5,0,6]  R926      3.4523203969001770e-01
    z[5,0,6]  R927      1.4997215941548347e-02
    z[5,0,6]  R928      -3.3137810230255127e-01
    z[5,0,6]  R929      4.1690585017204285e-01
    z[5,0,6]  R930      -2.6097485423088074e-01
    z[5,0,6]  R931      -3.3129367977380753e-02
    z[5,0,6]  R932      5.1669991016387939e-01
    z[5,0,6]  R933      6.0928516089916229e-02
    z[5,0,6]  R934      3.1819772720336914e-01
    z[5,0,6]  R935      -3.2967534661293030e-01
    z[5,0,6]  R936      -2.7402088046073914e-01
    z[5,0,6]  R937      -1.2210775911808014e-01
    z[5,0,6]  R938      -9.0648196637630463e-02
    z[5,0,6]  R939      -3.0467414855957031e-01
    z[5,0,6]  R940      -2.7823492884635925e-01
    z[5,0,6]  R941      -3.6152851581573486e-01
    z[5,0,6]  R942      1.9107328355312347e-01
    z[5,0,6]  R943      3.0165421962738037e-01
    z[5,0,6]  R944      1.3045558333396912e-01
    z[5,0,6]  R945      2.6932266354560852e-01
    z[5,0,6]  R946      -2.1146193146705627e-01
    z[5,0,6]  R947      2.8522223234176636e-01
    z[5,0,6]  R948      -2.6264557242393494e-01
    z[5,0,6]  R949      -5.1534049212932587e-02
    z[5,0,6]  R950      -2.6396539807319641e-01
    z[5,0,6]  R951      5.9392873197793961e-02
    z[5,0,6]  R952      6.3238894939422607e-01
    z[5,0,6]  R953      4.8657186329364777e-02
    z[5,0,6]  R954      2.2225466370582581e-01
    z[5,0,6]  R955      2.6226265355944633e-02
    z[5,0,6]  R956      -8.5489697754383087e-02
    z[5,0,6]  R957      1.1524365842342377e-01
    z[5,0,6]  R958      -6.0925945639610291e-02
    z[5,0,6]  R959      2.4047592282295227e-01
    z[5,0,6]  R960      2.7839845418930054e-01
    z[5,0,6]  R961      1.4632443897426128e-02
    z[5,0,6]  R962      -1.9516487419605255e-01
    z[5,0,6]  R963      3.6841621994972229e-01
    z[5,0,6]  R964      -1.7419892549514771e-01
    z[5,0,6]  R965      -1.0508665442466736e-01
    z[5,0,6]  R966      2.1887370944023132e-01
    z[5,0,6]  R967      4.9801462888717651e-01
    z[5,0,6]  R968      -2.0023313164710999e-01
    z[5,0,6]  R969      4.2687371373176575e-02
    z[5,0,6]  R970      -1.7269712686538696e-01
    z[5,0,6]  R971      2.5844737887382507e-01
    z[5,0,6]  R972      2.2752356529235840e-01
    z[5,0,6]  R973      3.2015082240104675e-01
    z[5,0,6]  R974      -3.0852247029542923e-02
    z[5,0,6]  R975      -1.4967158436775208e-01
    z[5,0,6]  R976      1.0632573813199997e-01
    z[5,0,6]  R977      -2.5837266445159912e-01
    z[5,0,6]  R978      1.5754364430904388e-01
    z[5,0,6]  R979      2.8766760230064392e-01
    z[5,0,6]  R980      1.4787826687097549e-02
    z[5,0,6]  R981      -3.1033328175544739e-01
    z[5,0,6]  R982      -1.5594394505023956e-01
    z[5,0,6]  R983      -2.1786347031593323e-01
    z[5,0,6]  R984      4.2473133653402328e-03
    z[5,0,6]  R985      5.7245563715696335e-02
    z[5,0,6]  R986      2.0748578011989594e-01
    z[5,0,6]  R987      9.0484723448753357e-02
    z[5,0,6]  R988      3.7761884927749634e-01
    z[5,0,6]  R989      1.8649470806121826e-01
    z[5,0,6]  R990      3.0846813693642616e-02
    z[5,0,6]  R991      -3.6305539309978485e-02
    z[5,0,6]  R992      1.4598475396633148e-01
    z[5,0,6]  R993      -4.3949750065803528e-01
    z[5,0,6]  R994      -3.2506820559501648e-01
    z[5,0,6]  R995      4.5821475982666016e-01
    z[5,0,6]  R996      -2.0079061388969421e-01
    z[5,0,6]  R997      2.7436956763267517e-01
    z[5,0,6]  R998      3.0983682721853256e-02
    z[5,0,6]  R999      -2.7007344365119934e-01
    z[5,0,6]  R1000     4.2271953821182251e-01
    z[5,0,6]  R1001     -2.1987275779247284e-01
    z[5,0,6]  R1002     1.7963241040706635e-01
    z[5,0,6]  R1003     -2.9832735657691956e-01
    z[5,0,6]  R1004     0.0983017086982727
    z[5,0,6]  R1005     -3.1668996810913086e-01
    z[5,0,6]  R1006     1.5204668045043945e-01
    z[5,0,6]  R1007     1.3626010715961456e-01
    z[5,0,6]  R1008     -5.1867388188838959e-02
    z[5,0,6]  R1009     2.4919275939464569e-01
    z[5,0,6]  R1010     -8.0029524862766266e-02
    z[5,0,6]  R1011     -6.3693143427371979e-02
    z[5,0,6]  R1012     -2.0735444128513336e-01
    z[5,0,6]  R1013     -6.4610382542014122e-03
    z[5,0,6]  R1014     3.9105647802352905e-01
    z[5,0,6]  R1015     -9.8922356963157654e-02
    z[5,0,6]  R1016     -7.9763151705265045e-02
    z[5,0,6]  R1017     -4.5124265551567078e-01
    z[5,0,6]  R1018     2.8198403120040894e-01
    z[5,0,6]  R1019     2.2629508748650551e-02
    z[5,0,6]  R1020     2.7077522128820419e-02
    z[5,0,6]  R1021     2.3101305961608887e-01
    z[5,0,6]  R1022     0.200897216796875
    z[5,0,6]  R1023     -1.4587773382663727e-01
    z[5,0,6]  R1024     -2.3490564525127411e-01
    z[5,0,6]  R1025     3.2156085968017578e-01
    z[5,0,6]  R1026     -1.8251250684261322e-01
    z[5,0,6]  R1027     1.9953005015850067e-01
    z[5,0,6]  R1028     -6.6221915185451508e-02
    z[5,0,6]  R1029     8.4433071315288544e-02
    z[5,0,6]  R1030     0.0134742995724082
    z[5,0,6]  R1031     -2.3847445845603943e-01
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R1136     -1
    z[1,2,0]  R1137     1
    z[1,2,0]  R1150     6.6226828098297119e-01
    z[1,2,0]  R1151     5.0675106048583984e-01
    z[1,2,0]  R1152     6.5007501840591431e-01
    z[1,2,0]  R1153     1.0458222776651382e-01
    z[1,2,0]  R1154     2.2211848199367523e-01
    z[1,2,0]  R1155     3.1830188632011414e-01
    z[1,2,0]  R1156     7.1310373023152351e-03
    z[1,2,0]  R1157     1.2181148678064346e-01
    z[1,2,0]  R1158     5.2474808692932129e-01
    z[1,2,0]  R1159     2.7573135495185852e-01
    z[1,2,0]  R1160     -3.1164163723587990e-02
    z[1,2,0]  R1161     4.1819611191749573e-01
    z[1,2,0]  R1162     -1.1259645689278841e-03
    z[1,2,0]  R1163     1.9186483323574066e-01
    z[1,2,0]  R1164     4.5464757084846497e-01
    z[1,2,0]  R1165     2.1068836748600006e-01
    z[1,2,0]  R1166     4.2194575071334839e-01
    z[1,2,0]  R1167     0.0399978905916214
    z[1,2,0]  R1168     -7.8884936869144440e-02
    z[1,2,0]  R1169     -3.5735324025154114e-01
    z[1,2,0]  R1170     4.9055644869804382e-01
    z[1,2,0]  R1171     4.2514945380389690e-03
    z[1,2,0]  R1172     -3.6638548970222473e-01
    z[1,2,0]  R1173     7.1098022162914276e-02
    z[1,2,0]  R1174     3.7249189615249634e-01
    z[1,2,0]  R1175     1.7393809556961060e-01
    z[1,2,0]  R1176     -3.4418198466300964e-01
    z[1,2,0]  R1177     -6.9354742765426636e-02
    z[1,2,0]  R1178     5.6962281465530396e-02
    z[1,2,0]  R1179     -1.6051355749368668e-02
    z[1,2,0]  R1180     1.4299128204584122e-02
    z[1,2,0]  R1181     -2.2865882515907288e-01
    z[1,2,0]  R1182     1.5479490393772721e-03
    z[1,2,0]  R1183     2.1054595708847046e-01
    z[1,2,0]  R1184     -1.3603353500366211e-01
    z[1,2,0]  R1185     -5.2306145429611206e-01
    z[1,2,0]  R1186     -2.8902623057365417e-01
    z[1,2,0]  R1187     5.5070221424102783e-01
    z[1,2,0]  R1188     -1.3425610959529877e-01
    z[1,2,0]  R1189     -1.5736041963100433e-01
    z[1,2,0]  R1190     4.6794205904006958e-01
    z[1,2,0]  R1191     4.7420230694115162e-03
    z[1,2,0]  R1192     5.1805965602397919e-02
    z[1,2,0]  R1193     0.0555608794093132
    z[1,2,0]  R1194     7.6698541641235352e-02
    z[1,2,0]  R1195     -1.5540167689323425e-01
    z[1,2,0]  R1196     -3.9058607071638107e-02
    z[1,2,0]  R1197     1.5152822434902191e-01
    z[1,2,0]  R1198     1.5403473377227783e-01
    z[1,2,0]  R1199     2.5715324282646179e-01
    z[1,2,0]  R1200     2.2457849979400635e-01
    z[1,2,0]  R1201     1.5101094543933868e-01
    z[1,2,0]  R1202     5.6134972721338272e-02
    z[1,2,0]  R1203     -1.3665618002414703e-01
    z[1,2,0]  R1204     2.1534779667854309e-01
    z[1,2,0]  R1205     1.2021030124742538e-04
    z[1,2,0]  R1206     9.9304080009460449e-02
    z[1,2,0]  R1207     -6.8425840139389038e-01
    z[1,2,0]  R1208     -6.2479972839355469e-01
    z[1,2,0]  R1209     -5.2208727598190308e-01
    z[1,2,0]  R1210     3.6214053630828857e-01
    z[1,2,0]  R1211     -3.7188172340393066e-02
    z[1,2,0]  R1212     -1.6319125890731812e-02
    z[1,2,0]  R1213     1.0568692535161972e-01
    z[1,2,0]  R1214     -4.8138600587844849e-01
    z[1,2,0]  R1215     2.8912544250488281e-01
    z[1,2,0]  R1216     3.7493386864662170e-01
    z[1,2,0]  R1217     7.4260830879211426e-03
    z[1,2,0]  R1218     5.1129949092864990e-01
    z[1,2,0]  R1219     2.9517391324043274e-01
    z[1,2,0]  R1220     -4.0680280327796936e-01
    z[1,2,0]  R1221     -5.5722106248140335e-02
    z[1,2,0]  R1222     2.4958252906799316e-01
    z[1,2,0]  R1223     7.6721549034118652e-02
    z[1,2,0]  R1224     3.0775913596153259e-01
    z[1,2,0]  R1225     -5.7606834173202515e-01
    z[1,2,0]  R1226     -5.7863569259643555e-01
    z[1,2,0]  R1227     -0.365887314081192
    z[1,2,0]  R1228     -3.7225973606109619e-01
    z[1,2,0]  R1229     -3.6723691225051880e-01
    z[1,2,0]  R1230     7.4633646011352539e-01
    z[1,2,0]  R1231     7.1900504827499390e-01
    z[1,2,0]  R1232     4.6687984466552734e-01
    z[1,2,0]  R1233     6.2324780225753784e-01
    z[1,2,0]  R1234     0.674728512763977
    z[1,2,0]  R1235     5.8700817823410034e-01
    z[1,2,0]  R1236     5.3296184539794922e-01
    z[1,2,0]  R1237     6.4067316055297852e-01
    z[1,2,0]  R1238     2.5798881053924561e-01
    z[1,2,0]  R1239     0.51311856508255
    z[1,2,0]  R1240     3.4854099154472351e-02
    z[1,2,0]  R1241     1.2561009824275970e-01
    z[1,2,0]  R1242     -6.3351500034332275e-01
    z[1,2,0]  R1243     -9.2627131938934326e-01
    z[1,2,0]  R1244     -4.4369208812713623e-01
    z[1,2,0]  R1245     -3.5934317111968994e-01
    z[1,2,0]  R1246     -4.2872470617294312e-01
    z[1,2,0]  R1247     -5.9073930978775024e-01
    z[1,2,0]  R1248     -7.7080458402633667e-01
    z[1,2,0]  R1249     -5.9364432096481323e-01
    z[1,2,0]  R1250     7.1253530681133270e-02
    z[1,2,0]  R1251     -1.1843587458133698e-01
    z[1,2,0]  R1252     -1.0165821760892868e-01
    z[1,2,0]  R1253     -2.9861640930175781e-01
    z[1,2,0]  R1254     -2.4031141400337219e-01
    z[1,2,0]  R1255     -1.9633817672729492e-01
    z[1,2,0]  R1256     -1.6695541143417358e-01
    z[1,2,0]  R1257     6.3124731183052063e-02
    z[1,2,0]  R1258     -9.9326990544795990e-02
    z[1,2,0]  R1259     1.6456462442874908e-02
    z[1,2,0]  R1260     1.8886549770832062e-01
    z[1,2,0]  R1261     -2.7452784776687622e-01
    z[1,2,0]  R1262     4.1046494245529175e-01
    z[1,2,0]  R1263     -4.1521570086479187e-01
    z[1,2,0]  R1264     -6.7262166738510132e-01
    z[1,2,0]  R1265     1.6913972795009613e-01
    z[1,2,0]  R1266     3.1891646981239319e-01
    z[1,2,0]  R1267     -1.7496973276138306e-01
    z[1,2,0]  R1268     2.2483965754508972e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R1138     -1
    z[1,2,1]  R1139     1
    z[1,2,1]  R1150     -6.7258083820343018e-01
    z[1,2,1]  R1151     -6.8709844350814819e-01
    z[1,2,1]  R1152     -5.6269049644470215e-01
    z[1,2,1]  R1153     -7.4100935459136963e-01
    z[1,2,1]  R1154     -3.2611182332038879e-01
    z[1,2,1]  R1155     -3.8324546813964844e-01
    z[1,2,1]  R1156     -4.3025317788124084e-01
    z[1,2,1]  R1157     2.0489771664142609e-01
    z[1,2,1]  R1158     1.4688260853290558e-01
    z[1,2,1]  R1159     1.5543220937252045e-01
    z[1,2,1]  R1160     6.3851112127304077e-01
    z[1,2,1]  R1161     5.9961098432540894e-01
    z[1,2,1]  R1162     5.2976197004318237e-01
    z[1,2,1]  R1163     5.1576942205429077e-01
    z[1,2,1]  R1164     5.9200048446655273e-01
    z[1,2,1]  R1165     6.2387037277221680e-01
    z[1,2,1]  R1166     4.2148393392562866e-01
    z[1,2,1]  R1167     5.3740245103836060e-01
    z[1,2,1]  R1168     5.1812380552291870e-01
    z[1,2,1]  R1169     7.2589772939682007e-01
    z[1,2,1]  R1170     -4.7521993517875671e-01
    z[1,2,1]  R1171     8.1426149606704712e-01
    z[1,2,1]  R1172     8.0973690748214722e-01
    z[1,2,1]  R1173     7.7333015203475952e-01
    z[1,2,1]  R1174     7.5256580114364624e-01
    z[1,2,1]  R1175     7.4798589944839478e-01
    z[1,2,1]  R1176     7.3069638013839722e-01
    z[1,2,1]  R1177     7.2040134668350220e-01
    z[1,2,1]  R1178     7.1463263034820557e-01
    z[1,2,1]  R1179     6.6782295703887939e-01
    z[1,2,1]  R1180     -4.9307525157928467e-01
    z[1,2,1]  R1181     -4.1209849715232849e-01
    z[1,2,1]  R1182     -4.0078794956207275e-01
    z[1,2,1]  R1183     7.5803959369659424e-01
    z[1,2,1]  R1184     7.2552794218063354e-01
    z[1,2,1]  R1185     0.687884509563446
    z[1,2,1]  R1186     6.7090785503387451e-01
    z[1,2,1]  R1187     6.7062664031982422e-01
    z[1,2,1]  R1188     4.3769472837448120e-01
    z[1,2,1]  R1189     5.0664401054382324e-01
    z[1,2,1]  R1190     -4.2647719383239746e-01
    z[1,2,1]  R1191     9.2548382282257080e-01
    z[1,2,1]  R1192     9.3614894151687622e-01
    z[1,2,1]  R1193     -5.5481582880020142e-01
    z[1,2,1]  R1194     3.9922478795051575e-01
    z[1,2,1]  R1195     5.6196242570877075e-01
    z[1,2,1]  R1196     3.0727306008338928e-01
    z[1,2,1]  R1197     5.6547051668167114e-01
    z[1,2,1]  R1198     3.8533520698547363e-01
    z[1,2,1]  R1199     5.2388507127761841e-01
    z[1,2,1]  R1200     -0.412022203207016
    z[1,2,1]  R1201     7.7927333116531372e-01
    z[1,2,1]  R1202     5.2602005004882812e-01
    z[1,2,1]  R1203     3.4048739075660706e-01
    z[1,2,1]  R1204     0.622753381729126
    z[1,2,1]  R1205     6.6513508558273315e-01
    z[1,2,1]  R1206     5.4914355278015137e-01
    z[1,2,1]  R1207     2.9145723674446344e-03
    z[1,2,1]  R1208     2.1156106889247894e-01
    z[1,2,1]  R1209     2.6425412297248840e-01
    z[1,2,1]  R1210     -7.1557760238647461e-01
    z[1,2,1]  R1211     -0.357464075088501
    z[1,2,1]  R1212     4.5127025246620178e-01
    z[1,2,1]  R1213     5.9350270032882690e-01
    z[1,2,1]  R1214     6.6273349523544312e-01
    z[1,2,1]  R1215     7.0407730340957642e-01
    z[1,2,1]  R1216     6.6769748926162720e-01
    z[1,2,1]  R1217     6.0759299993515015e-01
    z[1,2,1]  R1218     3.6614662408828735e-01
    z[1,2,1]  R1219     1.9975721836090088e-01
    z[1,2,1]  R1220     7.7622473239898682e-01
    z[1,2,1]  R1221     6.4539241790771484e-01
    z[1,2,1]  R1222     6.8543708324432373e-01
    z[1,2,1]  R1223     0.50160151720047
    z[1,2,1]  R1224     2.3102851212024689e-01
    z[1,2,1]  R1225     2.4664409458637238e-01
    z[1,2,1]  R1226     1.3632266223430634e-01
    z[1,2,1]  R1227     -6.9078433513641357e-01
    z[1,2,1]  R1228     -6.7879754304885864e-01
    z[1,2,1]  R1229     -6.8327230215072632e-01
    z[1,2,1]  R1230     -4.0034747123718262e-01
    z[1,2,1]  R1231     -6.0209697484970093e-01
    z[1,2,1]  R1232     -6.6832476854324341e-01
    z[1,2,1]  R1233     -1.7312319576740265e-01
    z[1,2,1]  R1234     -5.4768007993698120e-01
    z[1,2,1]  R1235     -4.1051355004310608e-01
    z[1,2,1]  R1236     -4.7652366757392883e-01
    z[1,2,1]  R1237     -3.5312104225158691e-01
    z[1,2,1]  R1238     -4.9516549706459045e-01
    z[1,2,1]  R1239     -1.2680651247501373e-01
    z[1,2,1]  R1240     5.8382898569107056e-01
    z[1,2,1]  R1241     6.0742568969726562e-01
    z[1,2,1]  R1242     1.7663152515888214e-01
    z[1,2,1]  R1243     3.5486739128828049e-02
    z[1,2,1]  R1244     -5.5451724678277969e-02
    z[1,2,1]  R1245     -1.2574690580368042e-01
    z[1,2,1]  R1246     3.8177499175071716e-01
    z[1,2,1]  R1247     2.3090101778507233e-01
    z[1,2,1]  R1248     4.3733924627304077e-01
    z[1,2,1]  R1249     5.9414225816726685e-01
    z[1,2,1]  R1250     7.4466150999069214e-01
    z[1,2,1]  R1251     -8.7734496593475342e-01
    z[1,2,1]  R1252     -8.5569155216217041e-01
    z[1,2,1]  R1253     -8.4874033927917480e-01
    z[1,2,1]  R1254     -8.4980607032775879e-01
    z[1,2,1]  R1255     -8.1663197278976440e-01
    z[1,2,1]  R1256     -9.0548592805862427e-01
    z[1,2,1]  R1257     -8.9221370220184326e-01
    z[1,2,1]  R1258     -8.9116054773330688e-01
    z[1,2,1]  R1259     -7.8599756956100464e-01
    z[1,2,1]  R1260     6.4114809036254883e-01
    z[1,2,1]  R1261     7.1110695600509644e-01
    z[1,2,1]  R1262     4.1350635886192322e-01
    z[1,2,1]  R1263     4.2939990758895874e-01
    z[1,2,1]  R1264     3.7744721770286560e-01
    z[1,2,1]  R1265     -8.3991122245788574e-01
    z[1,2,1]  R1266     -4.9871000647544861e-01
    z[1,2,1]  R1267     -6.9016766548156738e-01
    z[1,2,1]  R1268     -1.6022150218486786e-01
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R1140     -1
    z[1,2,2]  R1141     1
    z[1,2,2]  R1150     2.3809601366519928e-01
    z[1,2,2]  R1151     1.9728195667266846e-01
    z[1,2,2]  R1152     1.2139609456062317e-01
    z[1,2,2]  R1153     0.398151695728302
    z[1,2,2]  R1154     7.1022289991378784e-01
    z[1,2,2]  R1155     6.8480712175369263e-01
    z[1,2,2]  R1156     4.3799924850463867e-01
    z[1,2,2]  R1157     -8.5877221822738647e-01
    z[1,2,2]  R1158     -0.642659068107605
    z[1,2,2]  R1159     -7.8482675552368164e-01
    z[1,2,2]  R1160     4.8950761556625366e-01
    z[1,2,2]  R1161     1.9180183112621307e-01
    z[1,2,2]  R1162     -7.4636816978454590e-01
    z[1,2,2]  R1163     -7.1551853418350220e-01
    z[1,2,2]  R1164     -1.7958484590053558e-01
    z[1,2,2]  R1165     -3.6169543862342834e-01
    z[1,2,2]  R1166     -5.7209855318069458e-01
    z[1,2,2]  R1167     9.4921469688415527e-02
    z[1,2,2]  R1168     4.8071792721748352e-01
    z[1,2,2]  R1169     -0.515275239944458
    z[1,2,2]  R1170     -2.7619307860732079e-02
    z[1,2,2]  R1171     3.4795442223548889e-01
    z[1,2,2]  R1172     -1.5366819500923157e-01
    z[1,2,2]  R1173     -1.1325717717409134e-01
    z[1,2,2]  R1174     2.0715330541133881e-01
    z[1,2,2]  R1175     1.8174743652343750e-01
    z[1,2,2]  R1176     9.6815852448344231e-03
    z[1,2,2]  R1177     1.4354528486728668e-01
    z[1,2,2]  R1178     -4.8036918044090271e-02
    z[1,2,2]  R1179     0.524165689945221
    z[1,2,2]  R1180     6.7092680931091309e-01
    z[1,2,2]  R1181     5.9876251220703125e-01
    z[1,2,2]  R1182     4.6418240666389465e-01
    z[1,2,2]  R1183     -8.6913526058197021e-02
    z[1,2,2]  R1184     6.2506929039955139e-02
    z[1,2,2]  R1185     1.9782467186450958e-01
    z[1,2,2]  R1186     -5.9149265289306641e-01
    z[1,2,2]  R1187     -2.3733480274677277e-01
    z[1,2,2]  R1188     -0.854716956615448
    z[1,2,2]  R1189     -6.3081711530685425e-01
    z[1,2,2]  R1190     5.0678193569183350e-01
    z[1,2,2]  R1191     2.5052627921104431e-01
    z[1,2,2]  R1192     -7.1417480707168579e-02
    z[1,2,2]  R1193     4.8525348305702209e-01
    z[1,2,2]  R1194     -8.4976166486740112e-01
    z[1,2,2]  R1195     -4.9339225888252258e-01
    z[1,2,2]  R1196     -6.9705766439437866e-01
    z[1,2,2]  R1197     -6.1198842525482178e-01
    z[1,2,2]  R1198     -7.8054195642471313e-01
    z[1,2,2]  R1199     -5.7120490074157715e-01
    z[1,2,2]  R1200     6.3946527242660522e-01
    z[1,2,2]  R1201     -2.7680985629558563e-02
    z[1,2,2]  R1202     -7.0935946702957153e-01
    z[1,2,2]  R1203     -8.1507086753845215e-01
    z[1,2,2]  R1204     -5.3898376226425171e-01
    z[1,2,2]  R1205     -7.9467020928859711e-02
    z[1,2,2]  R1206     -0.486939400434494
    z[1,2,2]  R1207     6.3790476322174072e-01
    z[1,2,2]  R1208     2.1087015047669411e-02
    z[1,2,2]  R1209     1.9639053940773010e-01
    z[1,2,2]  R1210     4.5591777563095093e-01
    z[1,2,2]  R1211     8.5431921482086182e-01
    z[1,2,2]  R1212     -0.84015291929245
    z[1,2,2]  R1213     -6.8678051233291626e-01
    z[1,2,2]  R1214     2.4733814597129822e-01
    z[1,2,2]  R1215     -4.7133666276931763e-01
    z[1,2,2]  R1216     -1.5307798981666565e-01
    z[1,2,2]  R1217     -6.3151675462722778e-01
    z[1,2,2]  R1218     -5.1250952482223511e-01
    z[1,2,2]  R1219     -5.3278762102127075e-01
    z[1,2,2]  R1220     -3.0677095055580139e-01
    z[1,2,2]  R1221     -5.1467049121856689e-01
    z[1,2,2]  R1222     -2.1590860188007355e-01
    z[1,2,2]  R1223     -5.6937223672866821e-01
    z[1,2,2]  R1224     -0.542125940322876
    z[1,2,2]  R1225     -1.8518763780593872e-01
    z[1,2,2]  R1226     -1.1581188440322876e-01
    z[1,2,2]  R1227     -0.445984810590744
    z[1,2,2]  R1228     -5.3687328100204468e-01
    z[1,2,2]  R1229     -3.8116714358329773e-01
    z[1,2,2]  R1230     2.7930381894111633e-01
    z[1,2,2]  R1231     2.6787906885147095e-01
    z[1,2,2]  R1232     3.8824307918548584e-01
    z[1,2,2]  R1233     5.2606755495071411e-01
    z[1,2,2]  R1234     2.9414427280426025e-01
    z[1,2,2]  R1235     3.2297840714454651e-01
    z[1,2,2]  R1236     3.0626228451728821e-01
    z[1,2,2]  R1237     2.0133000612258911e-01
    z[1,2,2]  R1238     5.0488901138305664e-01
    z[1,2,2]  R1239     5.7198160886764526e-01
    z[1,2,2]  R1240     -3.8364905118942261e-01
    z[1,2,2]  R1241     -6.2465769052505493e-01
    z[1,2,2]  R1242     -3.8598701357841492e-01
    z[1,2,2]  R1243     -8.0465242266654968e-02
    z[1,2,2]  R1244     -5.5144089460372925e-01
    z[1,2,2]  R1245     -4.8674494028091431e-01
    z[1,2,2]  R1246     -4.4633024930953979e-01
    z[1,2,2]  R1247     -1.2243931740522385e-01
    z[1,2,2]  R1248     -2.9714056849479675e-01
    z[1,2,2]  R1249     6.4323648810386658e-02
    z[1,2,2]  R1250     4.5305392146110535e-01
    z[1,2,2]  R1251     -0.0395146943628788
    z[1,2,2]  R1252     0.0572814904153347
    z[1,2,2]  R1253     9.0387947857379913e-02
    z[1,2,2]  R1254     9.6831507980823517e-02
    z[1,2,2]  R1255     -4.2133229970932007e-01
    z[1,2,2]  R1256     -2.3272365331649780e-01
    z[1,2,2]  R1257     -3.3689412474632263e-01
    z[1,2,2]  R1258     -2.7912008762359619e-01
    z[1,2,2]  R1259     2.3952837288379669e-01
    z[1,2,2]  R1260     -5.2558034658432007e-01
    z[1,2,2]  R1261     -3.7949335575103760e-01
    z[1,2,2]  R1262     -5.0442464649677277e-02
    z[1,2,2]  R1263     0.0793595239520073
    z[1,2,2]  R1264     -1.1186948418617249e-01
    z[1,2,2]  R1265     -2.4897256866097450e-02
    z[1,2,2]  R1266     2.4634398519992828e-01
    z[1,2,2]  R1267     3.8176274299621582e-01
    z[1,2,2]  R1268     2.1233913302421570e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R1142     -1
    z[1,2,3]  R1143     1
    z[1,2,3]  R1150     8.0558732151985168e-02
    z[1,2,3]  R1151     1.0039541125297546e-01
    z[1,2,3]  R1152     1.9324548542499542e-01
    z[1,2,3]  R1153     3.8288459181785583e-01
    z[1,2,3]  R1154     -4.8785403370857239e-02
    z[1,2,3]  R1155     1.1430404335260391e-01
    z[1,2,3]  R1156     1.4981566369533539e-01
    z[1,2,3]  R1157     2.7314114570617676e-01
    z[1,2,3]  R1158     6.9600507616996765e-02
    z[1,2,3]  R1159     1.8743287026882172e-01
    z[1,2,3]  R1160     0.0943765640258789
    z[1,2,3]  R1161     2.7693882584571838e-01
    z[1,2,3]  R1162     -2.2504374384880066e-01
    z[1,2,3]  R1163     2.6922838762402534e-02
    z[1,2,3]  R1164     1.7071780562400818e-01
    z[1,2,3]  R1165     -0.51454758644104
    z[1,2,3]  R1166     -1.6613106429576874e-01
    z[1,2,3]  R1167     4.2972767353057861e-01
    z[1,2,3]  R1168     -9.3862272799015045e-02
    z[1,2,3]  R1169     -1.9204561412334442e-01
    z[1,2,3]  R1170     4.3587011098861694e-01
    z[1,2,3]  R1171     -4.2580872774124146e-01
    z[1,2,3]  R1172     6.1133846640586853e-02
    z[1,2,3]  R1173     3.4089264273643494e-01
    z[1,2,3]  R1174     -4.1056537628173828e-01
    z[1,2,3]  R1175     -3.5162556171417236e-01
    z[1,2,3]  R1176     -2.5002938508987427e-01
    z[1,2,3]  R1177     -1.5374928712844849e-01
    z[1,2,3]  R1178     2.7975007891654968e-01
    z[1,2,3]  R1179     2.9702642560005188e-01
    z[1,2,3]  R1180     -3.8059610128402710e-01
    z[1,2,3]  R1181     2.1868069469928741e-01
    z[1,2,3]  R1182     5.3026580810546875e-01
    z[1,2,3]  R1183     0.469642698764801
    z[1,2,3]  R1184     3.5498702526092529e-01
    z[1,2,3]  R1185     1.2456343322992325e-01
    z[1,2,3]  R1186     -1.5270821750164032e-01
    z[1,2,3]  R1187     -5.5474929511547089e-02
    z[1,2,3]  R1188     2.1719707548618317e-01
    z[1,2,3]  R1189     4.4158515334129333e-01
    z[1,2,3]  R1190     -3.9123344421386719e-01
    z[1,2,3]  R1191     1.8698923289775848e-01
    z[1,2,3]  R1192     1.7250998318195343e-01
    z[1,2,3]  R1193     -5.2650339901447296e-02
    z[1,2,3]  R1194     -5.9175956994295120e-02
    z[1,2,3]  R1195     -2.0117217674851418e-02
    z[1,2,3]  R1196     -1.4995169825851917e-02
    z[1,2,3]  R1197     -2.1370522677898407e-01
    z[1,2,3]  R1198     2.4888768792152405e-01
    z[1,2,3]  R1199     -1.7991498112678528e-01
    z[1,2,3]  R1200     -3.0606150627136230e-01
    z[1,2,3]  R1201     1.7265869677066803e-01
    z[1,2,3]  R1202     -2.0424877107143402e-01
    z[1,2,3]  R1203     2.1565240621566772e-01
    z[1,2,3]  R1204     -0.337464839220047
    z[1,2,3]  R1205     -2.5335872173309326e-01
    z[1,2,3]  R1206     -6.1320036649703979e-01
    z[1,2,3]  R1207     6.1767648905515671e-02
    z[1,2,3]  R1208     -3.2199603319168091e-01
    z[1,2,3]  R1209     -3.8293069601058960e-01
    z[1,2,3]  R1210     1.2954463064670563e-01
    z[1,2,3]  R1211     -1.9647832214832306e-01
    z[1,2,3]  R1212     8.8400296866893768e-02
    z[1,2,3]  R1213     -2.8740128874778748e-01
    z[1,2,3]  R1214     -3.0023294687271118e-01
    z[1,2,3]  R1215     -2.0498682558536530e-01
    z[1,2,3]  R1216     -2.0276100933551788e-01
    z[1,2,3]  R1217     -2.4268874526023865e-01
    z[1,2,3]  R1218     4.5972842723131180e-02
    z[1,2,3]  R1219     2.2287148237228394e-01
    z[1,2,3]  R1220     0.0639379695057869
    z[1,2,3]  R1221     -0.0262119323015213
    z[1,2,3]  R1222     -0.391450971364975
    z[1,2,3]  R1223     -5.5759406089782715e-01
    z[1,2,3]  R1224     2.0403346419334412e-01
    z[1,2,3]  R1225     -5.0263935327529907e-01
    z[1,2,3]  R1226     -1.4866378903388977e-01
    z[1,2,3]  R1227     -2.9711639881134033e-01
    z[1,2,3]  R1228     -2.8054785728454590e-01
    z[1,2,3]  R1229     -4.5000320672988892e-01
    z[1,2,3]  R1230     3.3067500591278076e-01
    z[1,2,3]  R1231     9.6278652548789978e-02
    z[1,2,3]  R1232     1.2748534977436066e-01
    z[1,2,3]  R1233     3.3887475728988647e-01
    z[1,2,3]  R1234     5.7916469871997833e-02
    z[1,2,3]  R1235     1.9778871536254883e-01
    z[1,2,3]  R1236     2.0071412622928619e-01
    z[1,2,3]  R1237     6.0937386751174927e-01
    z[1,2,3]  R1238     3.7540411949157715e-01
    z[1,2,3]  R1239     1.9863419234752655e-01
    z[1,2,3]  R1240     1.9271922111511230e-01
    z[1,2,3]  R1241     -2.4844960868358612e-01
    z[1,2,3]  R1242     -5.9494799375534058e-01
    z[1,2,3]  R1243     -1.6164198517799377e-01
    z[1,2,3]  R1244     -4.6853333711624146e-01
    z[1,2,3]  R1245     -6.6356897354125977e-01
    z[1,2,3]  R1246     -5.4165536165237427e-01
    z[1,2,3]  R1247     -4.6803241968154907e-01
    z[1,2,3]  R1248     5.5928952991962433e-02
    z[1,2,3]  R1249     -4.2371249198913574e-01
    z[1,2,3]  R1250     -3.2224440574645996e-01
    z[1,2,3]  R1251     1.0479624569416046e-01
    z[1,2,3]  R1252     1.4834481477737427e-01
    z[1,2,3]  R1253     3.1913340091705322e-01
    z[1,2,3]  R1254     2.4048164486885071e-01
    z[1,2,3]  R1255     -7.8706553904339671e-04
    z[1,2,3]  R1256     -1.0655672103166580e-01
    z[1,2,3]  R1257     1.9051907584071159e-02
    z[1,2,3]  R1258     1.5867017209529877e-01
    z[1,2,3]  R1259     -2.9746058583259583e-01
    z[1,2,3]  R1260     -4.8250073194503784e-01
    z[1,2,3]  R1261     -2.4838294088840485e-01
    z[1,2,3]  R1262     3.1995039433240891e-02
    z[1,2,3]  R1263     3.0408254265785217e-01
    z[1,2,3]  R1264     -3.2031536102294922e-02
    z[1,2,3]  R1265     -3.9799782633781433e-01
    z[1,2,3]  R1266     -7.4008069932460785e-02
    z[1,2,3]  R1267     1.1232008039951324e-01
    z[1,2,3]  R1268     7.0545274019241333e-01
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R1144     -1
    z[1,2,4]  R1145     1
    z[1,2,4]  R1150     -1.1163435131311417e-01
    z[1,2,4]  R1151     3.4751546382904053e-01
    z[1,2,4]  R1152     0.395954966545105
    z[1,2,4]  R1153     -7.0475861430168152e-02
    z[1,2,4]  R1154     3.7594917416572571e-01
    z[1,2,4]  R1155     -3.3839130401611328e-01
    z[1,2,4]  R1156     7.7024394273757935e-01
    z[1,2,4]  R1157     -3.0939653515815735e-01
    z[1,2,4]  R1158     -5.1315951347351074e-01
    z[1,2,4]  R1159     -5.5964458733797073e-02
    z[1,2,4]  R1160     -2.9413056373596191e-01
    z[1,2,4]  R1161     -3.6034524440765381e-01
    z[1,2,4]  R1162     1.6683399677276611e-01
    z[1,2,4]  R1163     8.0830223858356476e-02
    z[1,2,4]  R1164     -5.3942567110061646e-01
    z[1,2,4]  R1165     -2.0701089501380920e-01
    z[1,2,4]  R1166     -1.9030489027500153e-01
    z[1,2,4]  R1167     -1.8470701575279236e-01
    z[1,2,4]  R1168     -2.5172075629234314e-01
    z[1,2,4]  R1169     1.8056106567382812e-01
    z[1,2,4]  R1170     -3.7811735272407532e-01
    z[1,2,4]  R1171     1.2574869394302368e-01
    z[1,2,4]  R1172     8.3340726792812347e-02
    z[1,2,4]  R1173     1.8651063740253448e-01
    z[1,2,4]  R1174     -2.3539149761199951e-01
    z[1,2,4]  R1175     -4.7724953293800354e-01
    z[1,2,4]  R1176     -2.5400611758232117e-01
    z[1,2,4]  R1177     0.585501492023468
    z[1,2,4]  R1178     5.8831650018692017e-01
    z[1,2,4]  R1179     3.0771106481552124e-01
    z[1,2,4]  R1180     7.4283942580223083e-02
    z[1,2,4]  R1181     1.8063382804393768e-01
    z[1,2,4]  R1182     2.4540023505687714e-01
    z[1,2,4]  R1183     2.2678276896476746e-01
    z[1,2,4]  R1184     -5.2724468708038330e-01
    z[1,2,4]  R1185     1.2705012224614620e-02
    z[1,2,4]  R1186     -3.0059751868247986e-01
    z[1,2,4]  R1187     3.8329407572746277e-01
    z[1,2,4]  R1188     -4.2918534018099308e-03
    z[1,2,4]  R1189     -2.0145541429519653e-01
    z[1,2,4]  R1190     3.8457381725311279e-01
    z[1,2,4]  R1191     -8.0744408071041107e-02
    z[1,2,4]  R1192     -1.4044919610023499e-01
    z[1,2,4]  R1193     -3.9815533906221390e-02
    z[1,2,4]  R1194     -2.3382633924484253e-01
    z[1,2,4]  R1195     -6.2321889400482178e-01
    z[1,2,4]  R1196     -5.3854364156723022e-01
    z[1,2,4]  R1197     -3.1705516576766968e-01
    z[1,2,4]  R1198     3.6146484781056643e-03
    z[1,2,4]  R1199     -2.3531749844551086e-01
    z[1,2,4]  R1200     4.9750307202339172e-01
    z[1,2,4]  R1201     5.4032534360885620e-01
    z[1,2,4]  R1202     -4.1118609905242920e-01
    z[1,2,4]  R1203     -2.6080089807510376e-01
    z[1,2,4]  R1204     2.1534284949302673e-01
    z[1,2,4]  R1205     1.9201648235321045e-01
    z[1,2,4]  R1206     0.273902952671051
    z[1,2,4]  R1207     5.1875393837690353e-02
    z[1,2,4]  R1208     -3.1416463851928711e-01
    z[1,2,4]  R1209     -4.7365394234657288e-01
    z[1,2,4]  R1210     3.5780209302902222e-01
    z[1,2,4]  R1211     2.7632737159729004e-01
    z[1,2,4]  R1212     -2.4677792191505432e-01
    z[1,2,4]  R1213     -2.3934873938560486e-01
    z[1,2,4]  R1214     -2.8821733593940735e-01
    z[1,2,4]  R1215     1.6172325611114502e-01
    z[1,2,4]  R1216     9.7935229539871216e-02
    z[1,2,4]  R1217     2.8338557481765747e-01
    z[1,2,4]  R1218     -2.0178347826004028e-01
    z[1,2,4]  R1219     -6.7096483707427979e-01
    z[1,2,4]  R1220     -3.3685117959976196e-01
    z[1,2,4]  R1221     -4.3128201365470886e-01
    z[1,2,4]  R1222     2.8159880638122559e-01
    z[1,2,4]  R1223     3.0252316594123840e-01
    z[1,2,4]  R1224     -6.7659044265747070e-01
    z[1,2,4]  R1225     -1.1162239313125610e-01
    z[1,2,4]  R1226     -2.2105583921074867e-02
    z[1,2,4]  R1227     -3.5612594336271286e-02
    z[1,2,4]  R1228     -1.1146171391010284e-01
    z[1,2,4]  R1229     8.9615978300571442e-02
    z[1,2,4]  R1230     1.5591309964656830e-01
    z[1,2,4]  R1231     3.3210579305887222e-02
    z[1,2,4]  R1232     3.2860311865806580e-01
    z[1,2,4]  R1233     2.3615252971649170e-01
    z[1,2,4]  R1234     2.7785533666610718e-01
    z[1,2,4]  R1235     5.7523810863494873e-01
    z[1,2,4]  R1236     0.505702555179596
    z[1,2,4]  R1237     1.4279535412788391e-01
    z[1,2,4]  R1238     4.5110586285591125e-01
    z[1,2,4]  R1239     5.5977356433868408e-01
    z[1,2,4]  R1240     -3.8477557897567749e-01
    z[1,2,4]  R1241     -9.1467574238777161e-02
    z[1,2,4]  R1242     2.3537762463092804e-01
    z[1,2,4]  R1243     5.7685323059558868e-02
    z[1,2,4]  R1244     -0.207729309797287
    z[1,2,4]  R1245     -4.6287890523672104e-02
    z[1,2,4]  R1246     2.6507401838898659e-02
    z[1,2,4]  R1247     2.2686150670051575e-01
    z[1,2,4]  R1248     -2.1972274780273438e-01
    z[1,2,4]  R1249     6.8991214036941528e-02
    z[1,2,4]  R1250     2.7227815985679626e-01
    z[1,2,4]  R1251     -4.2880597710609436e-01
    z[1,2,4]  R1252     -0.341124564409256
    z[1,2,4]  R1253     -5.3095526993274689e-02
    z[1,2,4]  R1254     -1.3309714198112488e-01
    z[1,2,4]  R1255     0.0838802382349968
    z[1,2,4]  R1256     9.1450840234756470e-02
    z[1,2,4]  R1257     -1.2955079972743988e-01
    z[1,2,4]  R1258     -1.3842868804931641e-01
    z[1,2,4]  R1259     2.5895136594772339e-01
    z[1,2,4]  R1260     -9.0126700699329376e-02
    z[1,2,4]  R1261     -2.3520599305629730e-01
    z[1,2,4]  R1262     -4.7348889708518982e-01
    z[1,2,4]  R1263     2.4419422447681427e-01
    z[1,2,4]  R1264     3.8060879707336426e-01
    z[1,2,4]  R1265     -1.5124662220478058e-01
    z[1,2,4]  R1266     1.5121409296989441e-01
    z[1,2,4]  R1267     4.3616327643394470e-01
    z[1,2,4]  R1268     -5.3156131505966187e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R1146     -1
    z[1,2,5]  R1147     1
    z[1,2,5]  R1150     -1.3124023377895355e-01
    z[1,2,5]  R1151     -2.8038018941879272e-01
    z[1,2,5]  R1152     7.5025603175163269e-02
    z[1,2,5]  R1153     -3.6038011312484741e-01
    z[1,2,5]  R1154     2.1793329715728760e-01
    z[1,2,5]  R1155     0.327493280172348
    z[1,2,5]  R1156     4.5138490386307240e-03
    z[1,2,5]  R1157     -1.6327352821826935e-01
    z[1,2,5]  R1158     1.4789652824401855e-01
    z[1,2,5]  R1159     -3.5024428367614746e-01
    z[1,2,5]  R1160     -8.0627001821994781e-02
    z[1,2,5]  R1161     1.1245064437389374e-01
    z[1,2,5]  R1162     -2.2123867273330688e-01
    z[1,2,5]  R1163     4.2015653848648071e-01
    z[1,2,5]  R1164     -2.4561443924903870e-01
    z[1,2,5]  R1165     1.3122916221618652e-01
    z[1,2,5]  R1166     2.1605223417282104e-02
    z[1,2,5]  R1167     6.8585580587387085e-01
    z[1,2,5]  R1168     -6.3566464185714722e-01
    z[1,2,5]  R1169     1.0161749273538589e-01
    z[1,2,5]  R1170     3.2601559162139893e-01
    z[1,2,5]  R1171     2.3436428979039192e-02
    z[1,2,5]  R1172     -4.8586927354335785e-02
    z[1,2,5]  R1173     4.8255950212478638e-01
    z[1,2,5]  R1174     1.6032800078392029e-01
    z[1,2,5]  R1175     1.6008377075195312e-01
    z[1,2,5]  R1176     4.6952900290489197e-01
    z[1,2,5]  R1177     2.7046111226081848e-01
    z[1,2,5]  R1178     -9.7774252295494080e-02
    z[1,2,5]  R1179     -2.4051584303379059e-01
    z[1,2,5]  R1180     -1.6773492097854614e-01
    z[1,2,5]  R1181     3.0281695723533630e-01
    z[1,2,5]  R1182     5.0691539049148560e-01
    z[1,2,5]  R1183     -3.0283734202384949e-01
    z[1,2,5]  R1184     -2.0944355428218842e-01
    z[1,2,5]  R1185     4.4047471880912781e-01
    z[1,2,5]  R1186     -5.1340639591217041e-02
    z[1,2,5]  R1187     -4.2167093604803085e-02
    z[1,2,5]  R1188     -1.0983082652091980e-01
    z[1,2,5]  R1189     2.0590883493423462e-01
    z[1,2,5]  R1190     1.8038934469223022e-01
    z[1,2,5]  R1191     1.9750857353210449e-01
    z[1,2,5]  R1192     -2.5759214162826538e-01
    z[1,2,5]  R1193     1.0314231365919113e-01
    z[1,2,5]  R1194     -2.3229399323463440e-01
    z[1,2,5]  R1195     1.4108738303184509e-01
    z[1,2,5]  R1196     -1.6553550958633423e-01
    z[1,2,5]  R1197     3.3517107367515564e-01
    z[1,2,5]  R1198     -6.1202347278594971e-02
    z[1,2,5]  R1199     -2.1936956793069839e-02
    z[1,2,5]  R1200     1.5046262741088867e-01
    z[1,2,5]  R1201     -1.9028775393962860e-01
    z[1,2,5]  R1202     -3.2681442797183990e-02
    z[1,2,5]  R1203     -1.0058090090751648e-01
    z[1,2,5]  R1204     2.3878295719623566e-01
    z[1,2,5]  R1205     5.3994023799896240e-01
    z[1,2,5]  R1206     -1.7359418561682105e-03
    z[1,2,5]  R1207     -0.302208811044693
    z[1,2,5]  R1208     -5.0271379947662354e-01
    z[1,2,5]  R1209     -4.7846382856369019e-01
    z[1,2,5]  R1210     -3.9522830396890640e-02
    z[1,2,5]  R1211     1.5944422781467438e-01
    z[1,2,5]  R1212     -1.1943912133574486e-02
    z[1,2,5]  R1213     -4.6248380094766617e-02
    z[1,2,5]  R1214     -2.5208237767219543e-01
    z[1,2,5]  R1215     1.9102320075035095e-01
    z[1,2,5]  R1216     7.8355357050895691e-02
    z[1,2,5]  R1217     2.8564539551734924e-01
    z[1,2,5]  R1218     4.2012757062911987e-01
    z[1,2,5]  R1219     -4.8686340451240540e-02
    z[1,2,5]  R1220     1.3680109381675720e-01
    z[1,2,5]  R1221     3.5877469182014465e-01
    z[1,2,5]  R1222     4.1626819968223572e-01
    z[1,2,5]  R1223     -1.2600140273571014e-01
    z[1,2,5]  R1224     3.3882644027471542e-02
    z[1,2,5]  R1225     -0.522332489490509
    z[1,2,5]  R1226     -6.4811789989471436e-01
    z[1,2,5]  R1227     3.1140094995498657e-01
    z[1,2,5]  R1228     -1.1855640262365341e-01
    z[1,2,5]  R1229     1.4906461536884308e-01
    z[1,2,5]  R1230     -2.6245030760765076e-01
    z[1,2,5]  R1231     -0.0670199990272522
    z[1,2,5]  R1232     -2.4436776340007782e-01
    z[1,2,5]  R1233     3.6630305647850037e-01
    z[1,2,5]  R1234     -2.6340955495834351e-01
    z[1,2,5]  R1235     -9.4148583710193634e-02
    z[1,2,5]  R1236     -3.4305401146411896e-02
    z[1,2,5]  R1237     1.6856788098812103e-01
    z[1,2,5]  R1238     -5.0172898918390274e-02
    z[1,2,5]  R1239     9.5535710453987122e-02
    z[1,2,5]  R1240     -2.5173571705818176e-01
    z[1,2,5]  R1241     -3.9147889614105225e-01
    z[1,2,5]  R1242     5.3077928721904755e-02
    z[1,2,5]  R1243     -9.2946678400039673e-02
    z[1,2,5]  R1244     9.7296662628650665e-02
    z[1,2,5]  R1245     -9.6086002886295319e-02
    z[1,2,5]  R1246     -4.2067468166351318e-01
    z[1,2,5]  R1247     -5.5732220411300659e-01
    z[1,2,5]  R1248     -9.7770117223262787e-02
    z[1,2,5]  R1249     -1.1749976128339767e-01
    z[1,2,5]  R1250     2.3909299075603485e-01
    z[1,2,5]  R1251     -2.1298358216881752e-02
    z[1,2,5]  R1252     -2.9836791753768921e-01
    z[1,2,5]  R1253     -1.0847450233995914e-02
    z[1,2,5]  R1254     3.6222180724143982e-01
    z[1,2,5]  R1255     -2.8392225503921509e-01
    z[1,2,5]  R1256     -3.4298751503229141e-02
    z[1,2,5]  R1257     -0.0587601400911808
    z[1,2,5]  R1258     5.3964339196681976e-02
    z[1,2,5]  R1259     3.1064370274543762e-01
    z[1,2,5]  R1260     -4.3982222676277161e-02
    z[1,2,5]  R1261     3.9665651321411133e-01
    z[1,2,5]  R1262     5.3600388765335083e-01
    z[1,2,5]  R1263     -5.4437303543090820e-01
    z[1,2,5]  R1264     -4.8453959822654724e-01
    z[1,2,5]  R1265     -2.4696022272109985e-01
    z[1,2,5]  R1266     1.7080970108509064e-01
    z[1,2,5]  R1267     -0.337971568107605
    z[1,2,5]  R1268     1.9546246528625488e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R1148     -1
    z[1,2,6]  R1149     1
    z[1,2,6]  R1150     1.2716157734394073e-01
    z[1,2,6]  R1151     1.5073044598102570e-01
    z[1,2,6]  R1152     2.1515524387359619e-01
    z[1,2,6]  R1153     1.2325572315603495e-03
    z[1,2,6]  R1154     3.8559707999229431e-01
    z[1,2,6]  R1155     2.1913446485996246e-01
    z[1,2,6]  R1156     8.5130125284194946e-02
    z[1,2,6]  R1157     -9.3266211450099945e-02
    z[1,2,6]  R1158     -1.9759789574891329e-03
    z[1,2,6]  R1159     3.5060763359069824e-01
    z[1,2,6]  R1160     4.9979421496391296e-01
    z[1,2,6]  R1161     4.5782285928726196e-01
    z[1,2,6]  R1162     0.186710387468338
    z[1,2,6]  R1163     -3.7591807544231415e-02
    z[1,2,6]  R1164     1.7357769608497620e-01
    z[1,2,6]  R1165     3.3277422189712524e-01
    z[1,2,6]  R1166     5.0272655487060547e-01
    z[1,2,6]  R1167     1.0680851340293884e-01
    z[1,2,6]  R1168     1.3413478434085846e-01
    z[1,2,6]  R1169     7.2482489049434662e-03
    z[1,2,6]  R1170     -3.0580368638038635e-01
    z[1,2,6]  R1171     1.3495469093322754e-01
    z[1,2,6]  R1172     4.1644933819770813e-01
    z[1,2,6]  R1173     -1.4860205352306366e-02
    z[1,2,6]  R1174     4.7997146844863892e-02
    z[1,2,6]  R1175     1.3998521491885185e-02
    z[1,2,6]  R1176     -6.0403626412153244e-03
    z[1,2,6]  R1177     1.2651675939559937e-01
    z[1,2,6]  R1178     2.2318558394908905e-01
    z[1,2,6]  R1179     0.195567324757576
    z[1,2,6]  R1180     -3.5780292749404907e-01
    z[1,2,6]  R1181     -4.9721777439117432e-01
    z[1,2,6]  R1182     -1.5979675948619843e-01
    z[1,2,6]  R1183     9.8930552601814270e-02
    z[1,2,6]  R1184     5.7686984539031982e-02
    z[1,2,6]  R1185     6.6268257796764374e-02
    z[1,2,6]  R1186     -1.2977904640138149e-02
    z[1,2,6]  R1187     1.9720393419265747e-01
    z[1,2,6]  R1188     -2.4530166760087013e-02
    z[1,2,6]  R1189     2.0649281144142151e-01
    z[1,2,6]  R1190     -9.3907155096530914e-02
    z[1,2,6]  R1191     -1.4130038209259510e-02
    z[1,2,6]  R1192     1.2083718320354819e-03
    z[1,2,6]  R1193     -6.6228836774826050e-01
    z[1,2,6]  R1194     -2.2472234442830086e-02
    z[1,2,6]  R1195     -8.8884793221950531e-02
    z[1,2,6]  R1196     -3.1703668832778931e-01
    z[1,2,6]  R1197     -1.5562385320663452e-01
    z[1,2,6]  R1198     3.9094823598861694e-01
    z[1,2,6]  R1199     4.9489045143127441e-01
    z[1,2,6]  R1200     -8.4049604833126068e-02
    z[1,2,6]  R1201     1.0578565299510956e-01
    z[1,2,6]  R1202     -7.1422919631004333e-02
    z[1,2,6]  R1203     -2.7642959356307983e-01
    z[1,2,6]  R1204     2.4088962376117706e-01
    z[1,2,6]  R1205     3.9835140109062195e-01
    z[1,2,6]  R1206     2.0724989473819733e-02
    z[1,2,6]  R1207     1.6438685357570648e-01
    z[1,2,6]  R1208     -0.330636590719223
    z[1,2,6]  R1209     0.138252854347229
    z[1,2,6]  R1210     -5.0750296562910080e-02
    z[1,2,6]  R1211     -2.4333896115422249e-02
    z[1,2,6]  R1212     -1.4620308578014374e-01
    z[1,2,6]  R1213     1.5129800140857697e-01
    z[1,2,6]  R1214     1.7641171813011169e-01
    z[1,2,6]  R1215     3.0636507272720337e-01
    z[1,2,6]  R1216     5.7734644412994385e-01
    z[1,2,6]  R1217     -1.0565790534019470e-01
    z[1,2,6]  R1218     3.5000890493392944e-01
    z[1,2,6]  R1219     2.9473862051963806e-01
    z[1,2,6]  R1220     -4.0086947381496429e-02
    z[1,2,6]  R1221     -8.2158427685499191e-03
    z[1,2,6]  R1222     1.2432643026113510e-01
    z[1,2,6]  R1223     4.1455402970314026e-03
    z[1,2,6]  R1224     2.3970237374305725e-01
    z[1,2,6]  R1225     -1.8729726970195770e-01
    z[1,2,6]  R1226     4.3650665879249573e-01
    z[1,2,6]  R1227     -5.9363774955272675e-02
    z[1,2,6]  R1228     -8.5072867572307587e-02
    z[1,2,6]  R1229     1.4224433898925781e-01
    z[1,2,6]  R1230     -4.6458251774311066e-02
    z[1,2,6]  R1231     1.8408608436584473e-01
    z[1,2,6]  R1232     2.6160009205341339e-02
    z[1,2,6]  R1233     7.8310193493962288e-03
    z[1,2,6]  R1234     9.1239757835865021e-02
    z[1,2,6]  R1235     -0.0608413964509964
    z[1,2,6]  R1236     3.1286141276359558e-01
    z[1,2,6]  R1237     6.4555965363979340e-02
    z[1,2,6]  R1238     2.9393553733825684e-01
    z[1,2,6]  R1239     1.7758828401565552e-01
    z[1,2,6]  R1240     5.1203376054763794e-01
    z[1,2,6]  R1241     -4.1345804929733276e-02
    z[1,2,6]  R1242     -7.9316355288028717e-02
    z[1,2,6]  R1243     3.1014952063560486e-01
    z[1,2,6]  R1244     4.7311067581176758e-01
    z[1,2,6]  R1245     4.0797162055969238e-01
    z[1,2,6]  R1246     1.3117515482008457e-02
    z[1,2,6]  R1247     3.9898250252008438e-02
    z[1,2,6]  R1248     2.5561091303825378e-01
    z[1,2,6]  R1249     0.303884357213974
    z[1,2,6]  R1250     -1.4541435521095991e-03
    z[1,2,6]  R1251     -1.3916519284248352e-01
    z[1,2,6]  R1252     -1.6364848613739014e-01
    z[1,2,6]  R1253     2.7841567993164062e-01
    z[1,2,6]  R1254     6.2870927155017853e-02
    z[1,2,6]  R1255     -1.7144758999347687e-01
    z[1,2,6]  R1256     2.7778929471969604e-01
    z[1,2,6]  R1257     2.5665801763534546e-01
    z[1,2,6]  R1258     -2.6609787344932556e-01
    z[1,2,6]  R1259     2.6930475234985352e-01
    z[1,2,6]  R1260     1.8482415378093719e-01
    z[1,2,6]  R1261     2.4370370432734489e-02
    z[1,2,6]  R1262     -3.8140645623207092e-01
    z[1,2,6]  R1263     -4.3413665890693665e-01
    z[1,2,6]  R1264     1.0922961682081223e-01
    z[1,2,6]  R1265     -1.5183512866497040e-01
    z[1,2,6]  R1266     -7.2895568609237671e-01
    z[1,2,6]  R1267     1.7387457191944122e-01
    z[1,2,6]  R1268     -2.4548269808292389e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R1269     -1
    z[2,1,0]  R1270     1
    z[2,1,0]  R1283     7.4633646011352539e-01
    z[2,1,0]  R1284     7.1900504827499390e-01
    z[2,1,0]  R1285     4.6687984466552734e-01
    z[2,1,0]  R1286     6.2324780225753784e-01
    z[2,1,0]  R1287     0.674728512763977
    z[2,1,0]  R1288     5.8700817823410034e-01
    z[2,1,0]  R1289     5.3296184539794922e-01
    z[2,1,0]  R1290     6.4067316055297852e-01
    z[2,1,0]  R1291     2.5798881053924561e-01
    z[2,1,0]  R1292     0.51311856508255
    z[2,1,0]  R1293     3.4854099154472351e-02
    z[2,1,0]  R1294     1.2561009824275970e-01
    z[2,1,0]  R1295     -6.3351500034332275e-01
    z[2,1,0]  R1296     -9.2627131938934326e-01
    z[2,1,0]  R1297     -4.4369208812713623e-01
    z[2,1,0]  R1298     -3.5934317111968994e-01
    z[2,1,0]  R1299     -4.2872470617294312e-01
    z[2,1,0]  R1300     -5.9073930978775024e-01
    z[2,1,0]  R1301     -7.7080458402633667e-01
    z[2,1,0]  R1302     -5.9364432096481323e-01
    z[2,1,0]  R1303     7.1253530681133270e-02
    z[2,1,0]  R1304     -1.1843587458133698e-01
    z[2,1,0]  R1305     -1.0165821760892868e-01
    z[2,1,0]  R1306     -2.9861640930175781e-01
    z[2,1,0]  R1307     -2.4031141400337219e-01
    z[2,1,0]  R1308     -1.9633817672729492e-01
    z[2,1,0]  R1309     -1.6695541143417358e-01
    z[2,1,0]  R1310     6.3124731183052063e-02
    z[2,1,0]  R1311     -9.9326990544795990e-02
    z[2,1,0]  R1312     1.6456462442874908e-02
    z[2,1,0]  R1313     1.8886549770832062e-01
    z[2,1,0]  R1314     -2.7452784776687622e-01
    z[2,1,0]  R1315     4.1046494245529175e-01
    z[2,1,0]  R1316     -4.1521570086479187e-01
    z[2,1,0]  R1317     -6.7262166738510132e-01
    z[2,1,0]  R1318     1.6913972795009613e-01
    z[2,1,0]  R1319     3.1891646981239319e-01
    z[2,1,0]  R1320     -1.7496973276138306e-01
    z[2,1,0]  R1321     2.2483965754508972e-01
    z[2,1,0]  R1322     6.6226828098297119e-01
    z[2,1,0]  R1323     5.0675106048583984e-01
    z[2,1,0]  R1324     6.5007501840591431e-01
    z[2,1,0]  R1325     1.0458222776651382e-01
    z[2,1,0]  R1326     2.2211848199367523e-01
    z[2,1,0]  R1327     3.1830188632011414e-01
    z[2,1,0]  R1328     7.1310373023152351e-03
    z[2,1,0]  R1329     1.2181148678064346e-01
    z[2,1,0]  R1330     5.2474808692932129e-01
    z[2,1,0]  R1331     2.7573135495185852e-01
    z[2,1,0]  R1332     -3.1164163723587990e-02
    z[2,1,0]  R1333     4.1819611191749573e-01
    z[2,1,0]  R1334     -1.1259645689278841e-03
    z[2,1,0]  R1335     1.9186483323574066e-01
    z[2,1,0]  R1336     4.5464757084846497e-01
    z[2,1,0]  R1337     2.1068836748600006e-01
    z[2,1,0]  R1338     4.2194575071334839e-01
    z[2,1,0]  R1339     0.0399978905916214
    z[2,1,0]  R1340     -7.8884936869144440e-02
    z[2,1,0]  R1341     -3.5735324025154114e-01
    z[2,1,0]  R1342     4.9055644869804382e-01
    z[2,1,0]  R1343     4.2514945380389690e-03
    z[2,1,0]  R1344     -3.6638548970222473e-01
    z[2,1,0]  R1345     7.1098022162914276e-02
    z[2,1,0]  R1346     3.7249189615249634e-01
    z[2,1,0]  R1347     1.7393809556961060e-01
    z[2,1,0]  R1348     -3.4418198466300964e-01
    z[2,1,0]  R1349     -6.9354742765426636e-02
    z[2,1,0]  R1350     5.6962281465530396e-02
    z[2,1,0]  R1351     -1.6051355749368668e-02
    z[2,1,0]  R1352     1.4299128204584122e-02
    z[2,1,0]  R1353     -2.2865882515907288e-01
    z[2,1,0]  R1354     1.5479490393772721e-03
    z[2,1,0]  R1355     2.1054595708847046e-01
    z[2,1,0]  R1356     -1.3603353500366211e-01
    z[2,1,0]  R1357     -5.2306145429611206e-01
    z[2,1,0]  R1358     -2.8902623057365417e-01
    z[2,1,0]  R1359     5.5070221424102783e-01
    z[2,1,0]  R1360     -1.3425610959529877e-01
    z[2,1,0]  R1361     -1.5736041963100433e-01
    z[2,1,0]  R1362     4.6794205904006958e-01
    z[2,1,0]  R1363     4.7420230694115162e-03
    z[2,1,0]  R1364     5.1805965602397919e-02
    z[2,1,0]  R1365     0.0555608794093132
    z[2,1,0]  R1366     7.6698541641235352e-02
    z[2,1,0]  R1367     -1.5540167689323425e-01
    z[2,1,0]  R1368     -3.9058607071638107e-02
    z[2,1,0]  R1369     1.5152822434902191e-01
    z[2,1,0]  R1370     1.5403473377227783e-01
    z[2,1,0]  R1371     2.5715324282646179e-01
    z[2,1,0]  R1372     2.2457849979400635e-01
    z[2,1,0]  R1373     1.5101094543933868e-01
    z[2,1,0]  R1374     5.6134972721338272e-02
    z[2,1,0]  R1375     -1.3665618002414703e-01
    z[2,1,0]  R1376     2.1534779667854309e-01
    z[2,1,0]  R1377     1.2021030124742538e-04
    z[2,1,0]  R1378     9.9304080009460449e-02
    z[2,1,0]  R1379     -6.8425840139389038e-01
    z[2,1,0]  R1380     -6.2479972839355469e-01
    z[2,1,0]  R1381     -5.2208727598190308e-01
    z[2,1,0]  R1382     3.6214053630828857e-01
    z[2,1,0]  R1383     -3.7188172340393066e-02
    z[2,1,0]  R1384     -1.6319125890731812e-02
    z[2,1,0]  R1385     1.0568692535161972e-01
    z[2,1,0]  R1386     -4.8138600587844849e-01
    z[2,1,0]  R1387     2.8912544250488281e-01
    z[2,1,0]  R1388     3.7493386864662170e-01
    z[2,1,0]  R1389     7.4260830879211426e-03
    z[2,1,0]  R1390     5.1129949092864990e-01
    z[2,1,0]  R1391     2.9517391324043274e-01
    z[2,1,0]  R1392     -4.0680280327796936e-01
    z[2,1,0]  R1393     -5.5722106248140335e-02
    z[2,1,0]  R1394     2.4958252906799316e-01
    z[2,1,0]  R1395     7.6721549034118652e-02
    z[2,1,0]  R1396     3.0775913596153259e-01
    z[2,1,0]  R1397     -5.7606834173202515e-01
    z[2,1,0]  R1398     -5.7863569259643555e-01
    z[2,1,0]  R1399     -0.365887314081192
    z[2,1,0]  R1400     -3.7225973606109619e-01
    z[2,1,0]  R1401     -3.6723691225051880e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R1271     -1
    z[2,1,1]  R1272     1
    z[2,1,1]  R1283     -4.0034747123718262e-01
    z[2,1,1]  R1284     -6.0209697484970093e-01
    z[2,1,1]  R1285     -6.6832476854324341e-01
    z[2,1,1]  R1286     -1.7312319576740265e-01
    z[2,1,1]  R1287     -5.4768007993698120e-01
    z[2,1,1]  R1288     -4.1051355004310608e-01
    z[2,1,1]  R1289     -4.7652366757392883e-01
    z[2,1,1]  R1290     -3.5312104225158691e-01
    z[2,1,1]  R1291     -4.9516549706459045e-01
    z[2,1,1]  R1292     -1.2680651247501373e-01
    z[2,1,1]  R1293     5.8382898569107056e-01
    z[2,1,1]  R1294     6.0742568969726562e-01
    z[2,1,1]  R1295     1.7663152515888214e-01
    z[2,1,1]  R1296     3.5486739128828049e-02
    z[2,1,1]  R1297     -5.5451724678277969e-02
    z[2,1,1]  R1298     -1.2574690580368042e-01
    z[2,1,1]  R1299     3.8177499175071716e-01
    z[2,1,1]  R1300     2.3090101778507233e-01
    z[2,1,1]  R1301     4.3733924627304077e-01
    z[2,1,1]  R1302     5.9414225816726685e-01
    z[2,1,1]  R1303     7.4466150999069214e-01
    z[2,1,1]  R1304     -8.7734496593475342e-01
    z[2,1,1]  R1305     -8.5569155216217041e-01
    z[2,1,1]  R1306     -8.4874033927917480e-01
    z[2,1,1]  R1307     -8.4980607032775879e-01
    z[2,1,1]  R1308     -8.1663197278976440e-01
    z[2,1,1]  R1309     -9.0548592805862427e-01
    z[2,1,1]  R1310     -8.9221370220184326e-01
    z[2,1,1]  R1311     -8.9116054773330688e-01
    z[2,1,1]  R1312     -7.8599756956100464e-01
    z[2,1,1]  R1313     6.4114809036254883e-01
    z[2,1,1]  R1314     7.1110695600509644e-01
    z[2,1,1]  R1315     4.1350635886192322e-01
    z[2,1,1]  R1316     4.2939990758895874e-01
    z[2,1,1]  R1317     3.7744721770286560e-01
    z[2,1,1]  R1318     -8.3991122245788574e-01
    z[2,1,1]  R1319     -4.9871000647544861e-01
    z[2,1,1]  R1320     -6.9016766548156738e-01
    z[2,1,1]  R1321     -1.6022150218486786e-01
    z[2,1,1]  R1322     -6.7258083820343018e-01
    z[2,1,1]  R1323     -6.8709844350814819e-01
    z[2,1,1]  R1324     -5.6269049644470215e-01
    z[2,1,1]  R1325     -7.4100935459136963e-01
    z[2,1,1]  R1326     -3.2611182332038879e-01
    z[2,1,1]  R1327     -3.8324546813964844e-01
    z[2,1,1]  R1328     -4.3025317788124084e-01
    z[2,1,1]  R1329     2.0489771664142609e-01
    z[2,1,1]  R1330     1.4688260853290558e-01
    z[2,1,1]  R1331     1.5543220937252045e-01
    z[2,1,1]  R1332     6.3851112127304077e-01
    z[2,1,1]  R1333     5.9961098432540894e-01
    z[2,1,1]  R1334     5.2976197004318237e-01
    z[2,1,1]  R1335     5.1576942205429077e-01
    z[2,1,1]  R1336     5.9200048446655273e-01
    z[2,1,1]  R1337     6.2387037277221680e-01
    z[2,1,1]  R1338     4.2148393392562866e-01
    z[2,1,1]  R1339     5.3740245103836060e-01
    z[2,1,1]  R1340     5.1812380552291870e-01
    z[2,1,1]  R1341     7.2589772939682007e-01
    z[2,1,1]  R1342     -4.7521993517875671e-01
    z[2,1,1]  R1343     8.1426149606704712e-01
    z[2,1,1]  R1344     8.0973690748214722e-01
    z[2,1,1]  R1345     7.7333015203475952e-01
    z[2,1,1]  R1346     7.5256580114364624e-01
    z[2,1,1]  R1347     7.4798589944839478e-01
    z[2,1,1]  R1348     7.3069638013839722e-01
    z[2,1,1]  R1349     7.2040134668350220e-01
    z[2,1,1]  R1350     7.1463263034820557e-01
    z[2,1,1]  R1351     6.6782295703887939e-01
    z[2,1,1]  R1352     -4.9307525157928467e-01
    z[2,1,1]  R1353     -4.1209849715232849e-01
    z[2,1,1]  R1354     -4.0078794956207275e-01
    z[2,1,1]  R1355     7.5803959369659424e-01
    z[2,1,1]  R1356     7.2552794218063354e-01
    z[2,1,1]  R1357     0.687884509563446
    z[2,1,1]  R1358     6.7090785503387451e-01
    z[2,1,1]  R1359     6.7062664031982422e-01
    z[2,1,1]  R1360     4.3769472837448120e-01
    z[2,1,1]  R1361     5.0664401054382324e-01
    z[2,1,1]  R1362     -4.2647719383239746e-01
    z[2,1,1]  R1363     9.2548382282257080e-01
    z[2,1,1]  R1364     9.3614894151687622e-01
    z[2,1,1]  R1365     -5.5481582880020142e-01
    z[2,1,1]  R1366     3.9922478795051575e-01
    z[2,1,1]  R1367     5.6196242570877075e-01
    z[2,1,1]  R1368     3.0727306008338928e-01
    z[2,1,1]  R1369     5.6547051668167114e-01
    z[2,1,1]  R1370     3.8533520698547363e-01
    z[2,1,1]  R1371     5.2388507127761841e-01
    z[2,1,1]  R1372     -0.412022203207016
    z[2,1,1]  R1373     7.7927333116531372e-01
    z[2,1,1]  R1374     5.2602005004882812e-01
    z[2,1,1]  R1375     3.4048739075660706e-01
    z[2,1,1]  R1376     0.622753381729126
    z[2,1,1]  R1377     6.6513508558273315e-01
    z[2,1,1]  R1378     5.4914355278015137e-01
    z[2,1,1]  R1379     2.9145723674446344e-03
    z[2,1,1]  R1380     2.1156106889247894e-01
    z[2,1,1]  R1381     2.6425412297248840e-01
    z[2,1,1]  R1382     -7.1557760238647461e-01
    z[2,1,1]  R1383     -0.357464075088501
    z[2,1,1]  R1384     4.5127025246620178e-01
    z[2,1,1]  R1385     5.9350270032882690e-01
    z[2,1,1]  R1386     6.6273349523544312e-01
    z[2,1,1]  R1387     7.0407730340957642e-01
    z[2,1,1]  R1388     6.6769748926162720e-01
    z[2,1,1]  R1389     6.0759299993515015e-01
    z[2,1,1]  R1390     3.6614662408828735e-01
    z[2,1,1]  R1391     1.9975721836090088e-01
    z[2,1,1]  R1392     7.7622473239898682e-01
    z[2,1,1]  R1393     6.4539241790771484e-01
    z[2,1,1]  R1394     6.8543708324432373e-01
    z[2,1,1]  R1395     0.50160151720047
    z[2,1,1]  R1396     2.3102851212024689e-01
    z[2,1,1]  R1397     2.4664409458637238e-01
    z[2,1,1]  R1398     1.3632266223430634e-01
    z[2,1,1]  R1399     -6.9078433513641357e-01
    z[2,1,1]  R1400     -6.7879754304885864e-01
    z[2,1,1]  R1401     -6.8327230215072632e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R1273     -1
    z[2,1,2]  R1274     1
    z[2,1,2]  R1283     2.7930381894111633e-01
    z[2,1,2]  R1284     2.6787906885147095e-01
    z[2,1,2]  R1285     3.8824307918548584e-01
    z[2,1,2]  R1286     5.2606755495071411e-01
    z[2,1,2]  R1287     2.9414427280426025e-01
    z[2,1,2]  R1288     3.2297840714454651e-01
    z[2,1,2]  R1289     3.0626228451728821e-01
    z[2,1,2]  R1290     2.0133000612258911e-01
    z[2,1,2]  R1291     5.0488901138305664e-01
    z[2,1,2]  R1292     5.7198160886764526e-01
    z[2,1,2]  R1293     -3.8364905118942261e-01
    z[2,1,2]  R1294     -6.2465769052505493e-01
    z[2,1,2]  R1295     -3.8598701357841492e-01
    z[2,1,2]  R1296     -8.0465242266654968e-02
    z[2,1,2]  R1297     -5.5144089460372925e-01
    z[2,1,2]  R1298     -4.8674494028091431e-01
    z[2,1,2]  R1299     -4.4633024930953979e-01
    z[2,1,2]  R1300     -1.2243931740522385e-01
    z[2,1,2]  R1301     -2.9714056849479675e-01
    z[2,1,2]  R1302     6.4323648810386658e-02
    z[2,1,2]  R1303     4.5305392146110535e-01
    z[2,1,2]  R1304     -0.0395146943628788
    z[2,1,2]  R1305     0.0572814904153347
    z[2,1,2]  R1306     9.0387947857379913e-02
    z[2,1,2]  R1307     9.6831507980823517e-02
    z[2,1,2]  R1308     -4.2133229970932007e-01
    z[2,1,2]  R1309     -2.3272365331649780e-01
    z[2,1,2]  R1310     -3.3689412474632263e-01
    z[2,1,2]  R1311     -2.7912008762359619e-01
    z[2,1,2]  R1312     2.3952837288379669e-01
    z[2,1,2]  R1313     -5.2558034658432007e-01
    z[2,1,2]  R1314     -3.7949335575103760e-01
    z[2,1,2]  R1315     -5.0442464649677277e-02
    z[2,1,2]  R1316     0.0793595239520073
    z[2,1,2]  R1317     -1.1186948418617249e-01
    z[2,1,2]  R1318     -2.4897256866097450e-02
    z[2,1,2]  R1319     2.4634398519992828e-01
    z[2,1,2]  R1320     3.8176274299621582e-01
    z[2,1,2]  R1321     2.1233913302421570e-01
    z[2,1,2]  R1322     2.3809601366519928e-01
    z[2,1,2]  R1323     1.9728195667266846e-01
    z[2,1,2]  R1324     1.2139609456062317e-01
    z[2,1,2]  R1325     0.398151695728302
    z[2,1,2]  R1326     7.1022289991378784e-01
    z[2,1,2]  R1327     6.8480712175369263e-01
    z[2,1,2]  R1328     4.3799924850463867e-01
    z[2,1,2]  R1329     -8.5877221822738647e-01
    z[2,1,2]  R1330     -0.642659068107605
    z[2,1,2]  R1331     -7.8482675552368164e-01
    z[2,1,2]  R1332     4.8950761556625366e-01
    z[2,1,2]  R1333     1.9180183112621307e-01
    z[2,1,2]  R1334     -7.4636816978454590e-01
    z[2,1,2]  R1335     -7.1551853418350220e-01
    z[2,1,2]  R1336     -1.7958484590053558e-01
    z[2,1,2]  R1337     -3.6169543862342834e-01
    z[2,1,2]  R1338     -5.7209855318069458e-01
    z[2,1,2]  R1339     9.4921469688415527e-02
    z[2,1,2]  R1340     4.8071792721748352e-01
    z[2,1,2]  R1341     -0.515275239944458
    z[2,1,2]  R1342     -2.7619307860732079e-02
    z[2,1,2]  R1343     3.4795442223548889e-01
    z[2,1,2]  R1344     -1.5366819500923157e-01
    z[2,1,2]  R1345     -1.1325717717409134e-01
    z[2,1,2]  R1346     2.0715330541133881e-01
    z[2,1,2]  R1347     1.8174743652343750e-01
    z[2,1,2]  R1348     9.6815852448344231e-03
    z[2,1,2]  R1349     1.4354528486728668e-01
    z[2,1,2]  R1350     -4.8036918044090271e-02
    z[2,1,2]  R1351     0.524165689945221
    z[2,1,2]  R1352     6.7092680931091309e-01
    z[2,1,2]  R1353     5.9876251220703125e-01
    z[2,1,2]  R1354     4.6418240666389465e-01
    z[2,1,2]  R1355     -8.6913526058197021e-02
    z[2,1,2]  R1356     6.2506929039955139e-02
    z[2,1,2]  R1357     1.9782467186450958e-01
    z[2,1,2]  R1358     -5.9149265289306641e-01
    z[2,1,2]  R1359     -2.3733480274677277e-01
    z[2,1,2]  R1360     -0.854716956615448
    z[2,1,2]  R1361     -6.3081711530685425e-01
    z[2,1,2]  R1362     5.0678193569183350e-01
    z[2,1,2]  R1363     2.5052627921104431e-01
    z[2,1,2]  R1364     -7.1417480707168579e-02
    z[2,1,2]  R1365     4.8525348305702209e-01
    z[2,1,2]  R1366     -8.4976166486740112e-01
    z[2,1,2]  R1367     -4.9339225888252258e-01
    z[2,1,2]  R1368     -6.9705766439437866e-01
    z[2,1,2]  R1369     -6.1198842525482178e-01
    z[2,1,2]  R1370     -7.8054195642471313e-01
    z[2,1,2]  R1371     -5.7120490074157715e-01
    z[2,1,2]  R1372     6.3946527242660522e-01
    z[2,1,2]  R1373     -2.7680985629558563e-02
    z[2,1,2]  R1374     -7.0935946702957153e-01
    z[2,1,2]  R1375     -8.1507086753845215e-01
    z[2,1,2]  R1376     -5.3898376226425171e-01
    z[2,1,2]  R1377     -7.9467020928859711e-02
    z[2,1,2]  R1378     -0.486939400434494
    z[2,1,2]  R1379     6.3790476322174072e-01
    z[2,1,2]  R1380     2.1087015047669411e-02
    z[2,1,2]  R1381     1.9639053940773010e-01
    z[2,1,2]  R1382     4.5591777563095093e-01
    z[2,1,2]  R1383     8.5431921482086182e-01
    z[2,1,2]  R1384     -0.84015291929245
    z[2,1,2]  R1385     -6.8678051233291626e-01
    z[2,1,2]  R1386     2.4733814597129822e-01
    z[2,1,2]  R1387     -4.7133666276931763e-01
    z[2,1,2]  R1388     -1.5307798981666565e-01
    z[2,1,2]  R1389     -6.3151675462722778e-01
    z[2,1,2]  R1390     -5.1250952482223511e-01
    z[2,1,2]  R1391     -5.3278762102127075e-01
    z[2,1,2]  R1392     -3.0677095055580139e-01
    z[2,1,2]  R1393     -5.1467049121856689e-01
    z[2,1,2]  R1394     -2.1590860188007355e-01
    z[2,1,2]  R1395     -5.6937223672866821e-01
    z[2,1,2]  R1396     -0.542125940322876
    z[2,1,2]  R1397     -1.8518763780593872e-01
    z[2,1,2]  R1398     -1.1581188440322876e-01
    z[2,1,2]  R1399     -0.445984810590744
    z[2,1,2]  R1400     -5.3687328100204468e-01
    z[2,1,2]  R1401     -3.8116714358329773e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R1275     -1
    z[2,1,3]  R1276     1
    z[2,1,3]  R1283     3.3067500591278076e-01
    z[2,1,3]  R1284     9.6278652548789978e-02
    z[2,1,3]  R1285     1.2748534977436066e-01
    z[2,1,3]  R1286     3.3887475728988647e-01
    z[2,1,3]  R1287     5.7916469871997833e-02
    z[2,1,3]  R1288     1.9778871536254883e-01
    z[2,1,3]  R1289     2.0071412622928619e-01
    z[2,1,3]  R1290     6.0937386751174927e-01
    z[2,1,3]  R1291     3.7540411949157715e-01
    z[2,1,3]  R1292     1.9863419234752655e-01
    z[2,1,3]  R1293     1.9271922111511230e-01
    z[2,1,3]  R1294     -2.4844960868358612e-01
    z[2,1,3]  R1295     -5.9494799375534058e-01
    z[2,1,3]  R1296     -1.6164198517799377e-01
    z[2,1,3]  R1297     -4.6853333711624146e-01
    z[2,1,3]  R1298     -6.6356897354125977e-01
    z[2,1,3]  R1299     -5.4165536165237427e-01
    z[2,1,3]  R1300     -4.6803241968154907e-01
    z[2,1,3]  R1301     5.5928952991962433e-02
    z[2,1,3]  R1302     -4.2371249198913574e-01
    z[2,1,3]  R1303     -3.2224440574645996e-01
    z[2,1,3]  R1304     1.0479624569416046e-01
    z[2,1,3]  R1305     1.4834481477737427e-01
    z[2,1,3]  R1306     3.1913340091705322e-01
    z[2,1,3]  R1307     2.4048164486885071e-01
    z[2,1,3]  R1308     -7.8706553904339671e-04
    z[2,1,3]  R1309     -1.0655672103166580e-01
    z[2,1,3]  R1310     1.9051907584071159e-02
    z[2,1,3]  R1311     1.5867017209529877e-01
    z[2,1,3]  R1312     -2.9746058583259583e-01
    z[2,1,3]  R1313     -4.8250073194503784e-01
    z[2,1,3]  R1314     -2.4838294088840485e-01
    z[2,1,3]  R1315     3.1995039433240891e-02
    z[2,1,3]  R1316     3.0408254265785217e-01
    z[2,1,3]  R1317     -3.2031536102294922e-02
    z[2,1,3]  R1318     -3.9799782633781433e-01
    z[2,1,3]  R1319     -7.4008069932460785e-02
    z[2,1,3]  R1320     1.1232008039951324e-01
    z[2,1,3]  R1321     7.0545274019241333e-01
    z[2,1,3]  R1322     8.0558732151985168e-02
    z[2,1,3]  R1323     1.0039541125297546e-01
    z[2,1,3]  R1324     1.9324548542499542e-01
    z[2,1,3]  R1325     3.8288459181785583e-01
    z[2,1,3]  R1326     -4.8785403370857239e-02
    z[2,1,3]  R1327     1.1430404335260391e-01
    z[2,1,3]  R1328     1.4981566369533539e-01
    z[2,1,3]  R1329     2.7314114570617676e-01
    z[2,1,3]  R1330     6.9600507616996765e-02
    z[2,1,3]  R1331     1.8743287026882172e-01
    z[2,1,3]  R1332     0.0943765640258789
    z[2,1,3]  R1333     2.7693882584571838e-01
    z[2,1,3]  R1334     -2.2504374384880066e-01
    z[2,1,3]  R1335     2.6922838762402534e-02
    z[2,1,3]  R1336     1.7071780562400818e-01
    z[2,1,3]  R1337     -0.51454758644104
    z[2,1,3]  R1338     -1.6613106429576874e-01
    z[2,1,3]  R1339     4.2972767353057861e-01
    z[2,1,3]  R1340     -9.3862272799015045e-02
    z[2,1,3]  R1341     -1.9204561412334442e-01
    z[2,1,3]  R1342     4.3587011098861694e-01
    z[2,1,3]  R1343     -4.2580872774124146e-01
    z[2,1,3]  R1344     6.1133846640586853e-02
    z[2,1,3]  R1345     3.4089264273643494e-01
    z[2,1,3]  R1346     -4.1056537628173828e-01
    z[2,1,3]  R1347     -3.5162556171417236e-01
    z[2,1,3]  R1348     -2.5002938508987427e-01
    z[2,1,3]  R1349     -1.5374928712844849e-01
    z[2,1,3]  R1350     2.7975007891654968e-01
    z[2,1,3]  R1351     2.9702642560005188e-01
    z[2,1,3]  R1352     -3.8059610128402710e-01
    z[2,1,3]  R1353     2.1868069469928741e-01
    z[2,1,3]  R1354     5.3026580810546875e-01
    z[2,1,3]  R1355     0.469642698764801
    z[2,1,3]  R1356     3.5498702526092529e-01
    z[2,1,3]  R1357     1.2456343322992325e-01
    z[2,1,3]  R1358     -1.5270821750164032e-01
    z[2,1,3]  R1359     -5.5474929511547089e-02
    z[2,1,3]  R1360     2.1719707548618317e-01
    z[2,1,3]  R1361     4.4158515334129333e-01
    z[2,1,3]  R1362     -3.9123344421386719e-01
    z[2,1,3]  R1363     1.8698923289775848e-01
    z[2,1,3]  R1364     1.7250998318195343e-01
    z[2,1,3]  R1365     -5.2650339901447296e-02
    z[2,1,3]  R1366     -5.9175956994295120e-02
    z[2,1,3]  R1367     -2.0117217674851418e-02
    z[2,1,3]  R1368     -1.4995169825851917e-02
    z[2,1,3]  R1369     -2.1370522677898407e-01
    z[2,1,3]  R1370     2.4888768792152405e-01
    z[2,1,3]  R1371     -1.7991498112678528e-01
    z[2,1,3]  R1372     -3.0606150627136230e-01
    z[2,1,3]  R1373     1.7265869677066803e-01
    z[2,1,3]  R1374     -2.0424877107143402e-01
    z[2,1,3]  R1375     2.1565240621566772e-01
    z[2,1,3]  R1376     -0.337464839220047
    z[2,1,3]  R1377     -2.5335872173309326e-01
    z[2,1,3]  R1378     -6.1320036649703979e-01
    z[2,1,3]  R1379     6.1767648905515671e-02
    z[2,1,3]  R1380     -3.2199603319168091e-01
    z[2,1,3]  R1381     -3.8293069601058960e-01
    z[2,1,3]  R1382     1.2954463064670563e-01
    z[2,1,3]  R1383     -1.9647832214832306e-01
    z[2,1,3]  R1384     8.8400296866893768e-02
    z[2,1,3]  R1385     -2.8740128874778748e-01
    z[2,1,3]  R1386     -3.0023294687271118e-01
    z[2,1,3]  R1387     -2.0498682558536530e-01
    z[2,1,3]  R1388     -2.0276100933551788e-01
    z[2,1,3]  R1389     -2.4268874526023865e-01
    z[2,1,3]  R1390     4.5972842723131180e-02
    z[2,1,3]  R1391     2.2287148237228394e-01
    z[2,1,3]  R1392     0.0639379695057869
    z[2,1,3]  R1393     -0.0262119323015213
    z[2,1,3]  R1394     -0.391450971364975
    z[2,1,3]  R1395     -5.5759406089782715e-01
    z[2,1,3]  R1396     2.0403346419334412e-01
    z[2,1,3]  R1397     -5.0263935327529907e-01
    z[2,1,3]  R1398     -1.4866378903388977e-01
    z[2,1,3]  R1399     -2.9711639881134033e-01
    z[2,1,3]  R1400     -2.8054785728454590e-01
    z[2,1,3]  R1401     -4.5000320672988892e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R1277     -1
    z[2,1,4]  R1278     1
    z[2,1,4]  R1283     1.5591309964656830e-01
    z[2,1,4]  R1284     3.3210579305887222e-02
    z[2,1,4]  R1285     3.2860311865806580e-01
    z[2,1,4]  R1286     2.3615252971649170e-01
    z[2,1,4]  R1287     2.7785533666610718e-01
    z[2,1,4]  R1288     5.7523810863494873e-01
    z[2,1,4]  R1289     0.505702555179596
    z[2,1,4]  R1290     1.4279535412788391e-01
    z[2,1,4]  R1291     4.5110586285591125e-01
    z[2,1,4]  R1292     5.5977356433868408e-01
    z[2,1,4]  R1293     -3.8477557897567749e-01
    z[2,1,4]  R1294     -9.1467574238777161e-02
    z[2,1,4]  R1295     2.3537762463092804e-01
    z[2,1,4]  R1296     5.7685323059558868e-02
    z[2,1,4]  R1297     -0.207729309797287
    z[2,1,4]  R1298     -4.6287890523672104e-02
    z[2,1,4]  R1299     2.6507401838898659e-02
    z[2,1,4]  R1300     2.2686150670051575e-01
    z[2,1,4]  R1301     -2.1972274780273438e-01
    z[2,1,4]  R1302     6.8991214036941528e-02
    z[2,1,4]  R1303     2.7227815985679626e-01
    z[2,1,4]  R1304     -4.2880597710609436e-01
    z[2,1,4]  R1305     -0.341124564409256
    z[2,1,4]  R1306     -5.3095526993274689e-02
    z[2,1,4]  R1307     -1.3309714198112488e-01
    z[2,1,4]  R1308     0.0838802382349968
    z[2,1,4]  R1309     9.1450840234756470e-02
    z[2,1,4]  R1310     -1.2955079972743988e-01
    z[2,1,4]  R1311     -1.3842868804931641e-01
    z[2,1,4]  R1312     2.5895136594772339e-01
    z[2,1,4]  R1313     -9.0126700699329376e-02
    z[2,1,4]  R1314     -2.3520599305629730e-01
    z[2,1,4]  R1315     -4.7348889708518982e-01
    z[2,1,4]  R1316     2.4419422447681427e-01
    z[2,1,4]  R1317     3.8060879707336426e-01
    z[2,1,4]  R1318     -1.5124662220478058e-01
    z[2,1,4]  R1319     1.5121409296989441e-01
    z[2,1,4]  R1320     4.3616327643394470e-01
    z[2,1,4]  R1321     -5.3156131505966187e-01
    z[2,1,4]  R1322     -1.1163435131311417e-01
    z[2,1,4]  R1323     3.4751546382904053e-01
    z[2,1,4]  R1324     0.395954966545105
    z[2,1,4]  R1325     -7.0475861430168152e-02
    z[2,1,4]  R1326     3.7594917416572571e-01
    z[2,1,4]  R1327     -3.3839130401611328e-01
    z[2,1,4]  R1328     7.7024394273757935e-01
    z[2,1,4]  R1329     -3.0939653515815735e-01
    z[2,1,4]  R1330     -5.1315951347351074e-01
    z[2,1,4]  R1331     -5.5964458733797073e-02
    z[2,1,4]  R1332     -2.9413056373596191e-01
    z[2,1,4]  R1333     -3.6034524440765381e-01
    z[2,1,4]  R1334     1.6683399677276611e-01
    z[2,1,4]  R1335     8.0830223858356476e-02
    z[2,1,4]  R1336     -5.3942567110061646e-01
    z[2,1,4]  R1337     -2.0701089501380920e-01
    z[2,1,4]  R1338     -1.9030489027500153e-01
    z[2,1,4]  R1339     -1.8470701575279236e-01
    z[2,1,4]  R1340     -2.5172075629234314e-01
    z[2,1,4]  R1341     1.8056106567382812e-01
    z[2,1,4]  R1342     -3.7811735272407532e-01
    z[2,1,4]  R1343     1.2574869394302368e-01
    z[2,1,4]  R1344     8.3340726792812347e-02
    z[2,1,4]  R1345     1.8651063740253448e-01
    z[2,1,4]  R1346     -2.3539149761199951e-01
    z[2,1,4]  R1347     -4.7724953293800354e-01
    z[2,1,4]  R1348     -2.5400611758232117e-01
    z[2,1,4]  R1349     0.585501492023468
    z[2,1,4]  R1350     5.8831650018692017e-01
    z[2,1,4]  R1351     3.0771106481552124e-01
    z[2,1,4]  R1352     7.4283942580223083e-02
    z[2,1,4]  R1353     1.8063382804393768e-01
    z[2,1,4]  R1354     2.4540023505687714e-01
    z[2,1,4]  R1355     2.2678276896476746e-01
    z[2,1,4]  R1356     -5.2724468708038330e-01
    z[2,1,4]  R1357     1.2705012224614620e-02
    z[2,1,4]  R1358     -3.0059751868247986e-01
    z[2,1,4]  R1359     3.8329407572746277e-01
    z[2,1,4]  R1360     -4.2918534018099308e-03
    z[2,1,4]  R1361     -2.0145541429519653e-01
    z[2,1,4]  R1362     3.8457381725311279e-01
    z[2,1,4]  R1363     -8.0744408071041107e-02
    z[2,1,4]  R1364     -1.4044919610023499e-01
    z[2,1,4]  R1365     -3.9815533906221390e-02
    z[2,1,4]  R1366     -2.3382633924484253e-01
    z[2,1,4]  R1367     -6.2321889400482178e-01
    z[2,1,4]  R1368     -5.3854364156723022e-01
    z[2,1,4]  R1369     -3.1705516576766968e-01
    z[2,1,4]  R1370     3.6146484781056643e-03
    z[2,1,4]  R1371     -2.3531749844551086e-01
    z[2,1,4]  R1372     4.9750307202339172e-01
    z[2,1,4]  R1373     5.4032534360885620e-01
    z[2,1,4]  R1374     -4.1118609905242920e-01
    z[2,1,4]  R1375     -2.6080089807510376e-01
    z[2,1,4]  R1376     2.1534284949302673e-01
    z[2,1,4]  R1377     1.9201648235321045e-01
    z[2,1,4]  R1378     0.273902952671051
    z[2,1,4]  R1379     5.1875393837690353e-02
    z[2,1,4]  R1380     -3.1416463851928711e-01
    z[2,1,4]  R1381     -4.7365394234657288e-01
    z[2,1,4]  R1382     3.5780209302902222e-01
    z[2,1,4]  R1383     2.7632737159729004e-01
    z[2,1,4]  R1384     -2.4677792191505432e-01
    z[2,1,4]  R1385     -2.3934873938560486e-01
    z[2,1,4]  R1386     -2.8821733593940735e-01
    z[2,1,4]  R1387     1.6172325611114502e-01
    z[2,1,4]  R1388     9.7935229539871216e-02
    z[2,1,4]  R1389     2.8338557481765747e-01
    z[2,1,4]  R1390     -2.0178347826004028e-01
    z[2,1,4]  R1391     -6.7096483707427979e-01
    z[2,1,4]  R1392     -3.3685117959976196e-01
    z[2,1,4]  R1393     -4.3128201365470886e-01
    z[2,1,4]  R1394     2.8159880638122559e-01
    z[2,1,4]  R1395     3.0252316594123840e-01
    z[2,1,4]  R1396     -6.7659044265747070e-01
    z[2,1,4]  R1397     -1.1162239313125610e-01
    z[2,1,4]  R1398     -2.2105583921074867e-02
    z[2,1,4]  R1399     -3.5612594336271286e-02
    z[2,1,4]  R1400     -1.1146171391010284e-01
    z[2,1,4]  R1401     8.9615978300571442e-02
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R1279     -1
    z[2,1,5]  R1280     1
    z[2,1,5]  R1283     -2.6245030760765076e-01
    z[2,1,5]  R1284     -0.0670199990272522
    z[2,1,5]  R1285     -2.4436776340007782e-01
    z[2,1,5]  R1286     3.6630305647850037e-01
    z[2,1,5]  R1287     -2.6340955495834351e-01
    z[2,1,5]  R1288     -9.4148583710193634e-02
    z[2,1,5]  R1289     -3.4305401146411896e-02
    z[2,1,5]  R1290     1.6856788098812103e-01
    z[2,1,5]  R1291     -5.0172898918390274e-02
    z[2,1,5]  R1292     9.5535710453987122e-02
    z[2,1,5]  R1293     -2.5173571705818176e-01
    z[2,1,5]  R1294     -3.9147889614105225e-01
    z[2,1,5]  R1295     5.3077928721904755e-02
    z[2,1,5]  R1296     -9.2946678400039673e-02
    z[2,1,5]  R1297     9.7296662628650665e-02
    z[2,1,5]  R1298     -9.6086002886295319e-02
    z[2,1,5]  R1299     -4.2067468166351318e-01
    z[2,1,5]  R1300     -5.5732220411300659e-01
    z[2,1,5]  R1301     -9.7770117223262787e-02
    z[2,1,5]  R1302     -1.1749976128339767e-01
    z[2,1,5]  R1303     2.3909299075603485e-01
    z[2,1,5]  R1304     -2.1298358216881752e-02
    z[2,1,5]  R1305     -2.9836791753768921e-01
    z[2,1,5]  R1306     -1.0847450233995914e-02
    z[2,1,5]  R1307     3.6222180724143982e-01
    z[2,1,5]  R1308     -2.8392225503921509e-01
    z[2,1,5]  R1309     -3.4298751503229141e-02
    z[2,1,5]  R1310     -0.0587601400911808
    z[2,1,5]  R1311     5.3964339196681976e-02
    z[2,1,5]  R1312     3.1064370274543762e-01
    z[2,1,5]  R1313     -4.3982222676277161e-02
    z[2,1,5]  R1314     3.9665651321411133e-01
    z[2,1,5]  R1315     5.3600388765335083e-01
    z[2,1,5]  R1316     -5.4437303543090820e-01
    z[2,1,5]  R1317     -4.8453959822654724e-01
    z[2,1,5]  R1318     -2.4696022272109985e-01
    z[2,1,5]  R1319     1.7080970108509064e-01
    z[2,1,5]  R1320     -0.337971568107605
    z[2,1,5]  R1321     1.9546246528625488e-01
    z[2,1,5]  R1322     -1.3124023377895355e-01
    z[2,1,5]  R1323     -2.8038018941879272e-01
    z[2,1,5]  R1324     7.5025603175163269e-02
    z[2,1,5]  R1325     -3.6038011312484741e-01
    z[2,1,5]  R1326     2.1793329715728760e-01
    z[2,1,5]  R1327     0.327493280172348
    z[2,1,5]  R1328     4.5138490386307240e-03
    z[2,1,5]  R1329     -1.6327352821826935e-01
    z[2,1,5]  R1330     1.4789652824401855e-01
    z[2,1,5]  R1331     -3.5024428367614746e-01
    z[2,1,5]  R1332     -8.0627001821994781e-02
    z[2,1,5]  R1333     1.1245064437389374e-01
    z[2,1,5]  R1334     -2.2123867273330688e-01
    z[2,1,5]  R1335     4.2015653848648071e-01
    z[2,1,5]  R1336     -2.4561443924903870e-01
    z[2,1,5]  R1337     1.3122916221618652e-01
    z[2,1,5]  R1338     2.1605223417282104e-02
    z[2,1,5]  R1339     6.8585580587387085e-01
    z[2,1,5]  R1340     -6.3566464185714722e-01
    z[2,1,5]  R1341     1.0161749273538589e-01
    z[2,1,5]  R1342     3.2601559162139893e-01
    z[2,1,5]  R1343     2.3436428979039192e-02
    z[2,1,5]  R1344     -4.8586927354335785e-02
    z[2,1,5]  R1345     4.8255950212478638e-01
    z[2,1,5]  R1346     1.6032800078392029e-01
    z[2,1,5]  R1347     1.6008377075195312e-01
    z[2,1,5]  R1348     4.6952900290489197e-01
    z[2,1,5]  R1349     2.7046111226081848e-01
    z[2,1,5]  R1350     -9.7774252295494080e-02
    z[2,1,5]  R1351     -2.4051584303379059e-01
    z[2,1,5]  R1352     -1.6773492097854614e-01
    z[2,1,5]  R1353     3.0281695723533630e-01
    z[2,1,5]  R1354     5.0691539049148560e-01
    z[2,1,5]  R1355     -3.0283734202384949e-01
    z[2,1,5]  R1356     -2.0944355428218842e-01
    z[2,1,5]  R1357     4.4047471880912781e-01
    z[2,1,5]  R1358     -5.1340639591217041e-02
    z[2,1,5]  R1359     -4.2167093604803085e-02
    z[2,1,5]  R1360     -1.0983082652091980e-01
    z[2,1,5]  R1361     2.0590883493423462e-01
    z[2,1,5]  R1362     1.8038934469223022e-01
    z[2,1,5]  R1363     1.9750857353210449e-01
    z[2,1,5]  R1364     -2.5759214162826538e-01
    z[2,1,5]  R1365     1.0314231365919113e-01
    z[2,1,5]  R1366     -2.3229399323463440e-01
    z[2,1,5]  R1367     1.4108738303184509e-01
    z[2,1,5]  R1368     -1.6553550958633423e-01
    z[2,1,5]  R1369     3.3517107367515564e-01
    z[2,1,5]  R1370     -6.1202347278594971e-02
    z[2,1,5]  R1371     -2.1936956793069839e-02
    z[2,1,5]  R1372     1.5046262741088867e-01
    z[2,1,5]  R1373     -1.9028775393962860e-01
    z[2,1,5]  R1374     -3.2681442797183990e-02
    z[2,1,5]  R1375     -1.0058090090751648e-01
    z[2,1,5]  R1376     2.3878295719623566e-01
    z[2,1,5]  R1377     5.3994023799896240e-01
    z[2,1,5]  R1378     -1.7359418561682105e-03
    z[2,1,5]  R1379     -0.302208811044693
    z[2,1,5]  R1380     -5.0271379947662354e-01
    z[2,1,5]  R1381     -4.7846382856369019e-01
    z[2,1,5]  R1382     -3.9522830396890640e-02
    z[2,1,5]  R1383     1.5944422781467438e-01
    z[2,1,5]  R1384     -1.1943912133574486e-02
    z[2,1,5]  R1385     -4.6248380094766617e-02
    z[2,1,5]  R1386     -2.5208237767219543e-01
    z[2,1,5]  R1387     1.9102320075035095e-01
    z[2,1,5]  R1388     7.8355357050895691e-02
    z[2,1,5]  R1389     2.8564539551734924e-01
    z[2,1,5]  R1390     4.2012757062911987e-01
    z[2,1,5]  R1391     -4.8686340451240540e-02
    z[2,1,5]  R1392     1.3680109381675720e-01
    z[2,1,5]  R1393     3.5877469182014465e-01
    z[2,1,5]  R1394     4.1626819968223572e-01
    z[2,1,5]  R1395     -1.2600140273571014e-01
    z[2,1,5]  R1396     3.3882644027471542e-02
    z[2,1,5]  R1397     -0.522332489490509
    z[2,1,5]  R1398     -6.4811789989471436e-01
    z[2,1,5]  R1399     3.1140094995498657e-01
    z[2,1,5]  R1400     -1.1855640262365341e-01
    z[2,1,5]  R1401     1.4906461536884308e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R1281     -1
    z[2,1,6]  R1282     1
    z[2,1,6]  R1283     -4.6458251774311066e-02
    z[2,1,6]  R1284     1.8408608436584473e-01
    z[2,1,6]  R1285     2.6160009205341339e-02
    z[2,1,6]  R1286     7.8310193493962288e-03
    z[2,1,6]  R1287     9.1239757835865021e-02
    z[2,1,6]  R1288     -0.0608413964509964
    z[2,1,6]  R1289     3.1286141276359558e-01
    z[2,1,6]  R1290     6.4555965363979340e-02
    z[2,1,6]  R1291     2.9393553733825684e-01
    z[2,1,6]  R1292     1.7758828401565552e-01
    z[2,1,6]  R1293     5.1203376054763794e-01
    z[2,1,6]  R1294     -4.1345804929733276e-02
    z[2,1,6]  R1295     -7.9316355288028717e-02
    z[2,1,6]  R1296     3.1014952063560486e-01
    z[2,1,6]  R1297     4.7311067581176758e-01
    z[2,1,6]  R1298     4.0797162055969238e-01
    z[2,1,6]  R1299     1.3117515482008457e-02
    z[2,1,6]  R1300     3.9898250252008438e-02
    z[2,1,6]  R1301     2.5561091303825378e-01
    z[2,1,6]  R1302     0.303884357213974
    z[2,1,6]  R1303     -1.4541435521095991e-03
    z[2,1,6]  R1304     -1.3916519284248352e-01
    z[2,1,6]  R1305     -1.6364848613739014e-01
    z[2,1,6]  R1306     2.7841567993164062e-01
    z[2,1,6]  R1307     6.2870927155017853e-02
    z[2,1,6]  R1308     -1.7144758999347687e-01
    z[2,1,6]  R1309     2.7778929471969604e-01
    z[2,1,6]  R1310     2.5665801763534546e-01
    z[2,1,6]  R1311     -2.6609787344932556e-01
    z[2,1,6]  R1312     2.6930475234985352e-01
    z[2,1,6]  R1313     1.8482415378093719e-01
    z[2,1,6]  R1314     2.4370370432734489e-02
    z[2,1,6]  R1315     -3.8140645623207092e-01
    z[2,1,6]  R1316     -4.3413665890693665e-01
    z[2,1,6]  R1317     1.0922961682081223e-01
    z[2,1,6]  R1318     -1.5183512866497040e-01
    z[2,1,6]  R1319     -7.2895568609237671e-01
    z[2,1,6]  R1320     1.7387457191944122e-01
    z[2,1,6]  R1321     -2.4548269808292389e-01
    z[2,1,6]  R1322     1.2716157734394073e-01
    z[2,1,6]  R1323     1.5073044598102570e-01
    z[2,1,6]  R1324     2.1515524387359619e-01
    z[2,1,6]  R1325     1.2325572315603495e-03
    z[2,1,6]  R1326     3.8559707999229431e-01
    z[2,1,6]  R1327     2.1913446485996246e-01
    z[2,1,6]  R1328     8.5130125284194946e-02
    z[2,1,6]  R1329     -9.3266211450099945e-02
    z[2,1,6]  R1330     -1.9759789574891329e-03
    z[2,1,6]  R1331     3.5060763359069824e-01
    z[2,1,6]  R1332     4.9979421496391296e-01
    z[2,1,6]  R1333     4.5782285928726196e-01
    z[2,1,6]  R1334     0.186710387468338
    z[2,1,6]  R1335     -3.7591807544231415e-02
    z[2,1,6]  R1336     1.7357769608497620e-01
    z[2,1,6]  R1337     3.3277422189712524e-01
    z[2,1,6]  R1338     5.0272655487060547e-01
    z[2,1,6]  R1339     1.0680851340293884e-01
    z[2,1,6]  R1340     1.3413478434085846e-01
    z[2,1,6]  R1341     7.2482489049434662e-03
    z[2,1,6]  R1342     -3.0580368638038635e-01
    z[2,1,6]  R1343     1.3495469093322754e-01
    z[2,1,6]  R1344     4.1644933819770813e-01
    z[2,1,6]  R1345     -1.4860205352306366e-02
    z[2,1,6]  R1346     4.7997146844863892e-02
    z[2,1,6]  R1347     1.3998521491885185e-02
    z[2,1,6]  R1348     -6.0403626412153244e-03
    z[2,1,6]  R1349     1.2651675939559937e-01
    z[2,1,6]  R1350     2.2318558394908905e-01
    z[2,1,6]  R1351     0.195567324757576
    z[2,1,6]  R1352     -3.5780292749404907e-01
    z[2,1,6]  R1353     -4.9721777439117432e-01
    z[2,1,6]  R1354     -1.5979675948619843e-01
    z[2,1,6]  R1355     9.8930552601814270e-02
    z[2,1,6]  R1356     5.7686984539031982e-02
    z[2,1,6]  R1357     6.6268257796764374e-02
    z[2,1,6]  R1358     -1.2977904640138149e-02
    z[2,1,6]  R1359     1.9720393419265747e-01
    z[2,1,6]  R1360     -2.4530166760087013e-02
    z[2,1,6]  R1361     2.0649281144142151e-01
    z[2,1,6]  R1362     -9.3907155096530914e-02
    z[2,1,6]  R1363     -1.4130038209259510e-02
    z[2,1,6]  R1364     1.2083718320354819e-03
    z[2,1,6]  R1365     -6.6228836774826050e-01
    z[2,1,6]  R1366     -2.2472234442830086e-02
    z[2,1,6]  R1367     -8.8884793221950531e-02
    z[2,1,6]  R1368     -3.1703668832778931e-01
    z[2,1,6]  R1369     -1.5562385320663452e-01
    z[2,1,6]  R1370     3.9094823598861694e-01
    z[2,1,6]  R1371     4.9489045143127441e-01
    z[2,1,6]  R1372     -8.4049604833126068e-02
    z[2,1,6]  R1373     1.0578565299510956e-01
    z[2,1,6]  R1374     -7.1422919631004333e-02
    z[2,1,6]  R1375     -2.7642959356307983e-01
    z[2,1,6]  R1376     2.4088962376117706e-01
    z[2,1,6]  R1377     3.9835140109062195e-01
    z[2,1,6]  R1378     2.0724989473819733e-02
    z[2,1,6]  R1379     1.6438685357570648e-01
    z[2,1,6]  R1380     -0.330636590719223
    z[2,1,6]  R1381     0.138252854347229
    z[2,1,6]  R1382     -5.0750296562910080e-02
    z[2,1,6]  R1383     -2.4333896115422249e-02
    z[2,1,6]  R1384     -1.4620308578014374e-01
    z[2,1,6]  R1385     1.5129800140857697e-01
    z[2,1,6]  R1386     1.7641171813011169e-01
    z[2,1,6]  R1387     3.0636507272720337e-01
    z[2,1,6]  R1388     5.7734644412994385e-01
    z[2,1,6]  R1389     -1.0565790534019470e-01
    z[2,1,6]  R1390     3.5000890493392944e-01
    z[2,1,6]  R1391     2.9473862051963806e-01
    z[2,1,6]  R1392     -4.0086947381496429e-02
    z[2,1,6]  R1393     -8.2158427685499191e-03
    z[2,1,6]  R1394     1.2432643026113510e-01
    z[2,1,6]  R1395     4.1455402970314026e-03
    z[2,1,6]  R1396     2.3970237374305725e-01
    z[2,1,6]  R1397     -1.8729726970195770e-01
    z[2,1,6]  R1398     4.3650665879249573e-01
    z[2,1,6]  R1399     -5.9363774955272675e-02
    z[2,1,6]  R1400     -8.5072867572307587e-02
    z[2,1,6]  R1401     1.4224433898925781e-01
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R1402     -1
    z[2,3,0]  R1403     1
    z[2,3,0]  R1416     7.4633646011352539e-01
    z[2,3,0]  R1417     7.1900504827499390e-01
    z[2,3,0]  R1418     4.6687984466552734e-01
    z[2,3,0]  R1419     6.2324780225753784e-01
    z[2,3,0]  R1420     0.674728512763977
    z[2,3,0]  R1421     5.8700817823410034e-01
    z[2,3,0]  R1422     5.3296184539794922e-01
    z[2,3,0]  R1423     6.4067316055297852e-01
    z[2,3,0]  R1424     2.5798881053924561e-01
    z[2,3,0]  R1425     0.51311856508255
    z[2,3,0]  R1426     3.4854099154472351e-02
    z[2,3,0]  R1427     1.2561009824275970e-01
    z[2,3,0]  R1428     -6.3351500034332275e-01
    z[2,3,0]  R1429     -9.2627131938934326e-01
    z[2,3,0]  R1430     -4.4369208812713623e-01
    z[2,3,0]  R1431     -3.5934317111968994e-01
    z[2,3,0]  R1432     -4.2872470617294312e-01
    z[2,3,0]  R1433     -5.9073930978775024e-01
    z[2,3,0]  R1434     -7.7080458402633667e-01
    z[2,3,0]  R1435     -5.9364432096481323e-01
    z[2,3,0]  R1436     7.1253530681133270e-02
    z[2,3,0]  R1437     -1.1843587458133698e-01
    z[2,3,0]  R1438     -1.0165821760892868e-01
    z[2,3,0]  R1439     -2.9861640930175781e-01
    z[2,3,0]  R1440     -2.4031141400337219e-01
    z[2,3,0]  R1441     -1.9633817672729492e-01
    z[2,3,0]  R1442     -1.6695541143417358e-01
    z[2,3,0]  R1443     6.3124731183052063e-02
    z[2,3,0]  R1444     -9.9326990544795990e-02
    z[2,3,0]  R1445     1.6456462442874908e-02
    z[2,3,0]  R1446     1.8886549770832062e-01
    z[2,3,0]  R1447     -2.7452784776687622e-01
    z[2,3,0]  R1448     4.1046494245529175e-01
    z[2,3,0]  R1449     -4.1521570086479187e-01
    z[2,3,0]  R1450     -6.7262166738510132e-01
    z[2,3,0]  R1451     1.6913972795009613e-01
    z[2,3,0]  R1452     3.1891646981239319e-01
    z[2,3,0]  R1453     -1.7496973276138306e-01
    z[2,3,0]  R1454     2.2483965754508972e-01
    z[2,3,0]  R1455     -3.5991060733795166e-01
    z[2,3,0]  R1456     -4.5456355810165405e-01
    z[2,3,0]  R1457     -4.4574731588363647e-01
    z[2,3,0]  R1458     -4.6410277485847473e-01
    z[2,3,0]  R1459     -5.2192157506942749e-01
    z[2,3,0]  R1460     -4.0470978617668152e-01
    z[2,3,0]  R1461     -5.7777029275894165e-01
    z[2,3,0]  R1462     -4.0178349614143372e-01
    z[2,3,0]  R1463     -3.2651230692863464e-01
    z[2,3,0]  R1464     -4.1116729378700256e-01
    z[2,3,0]  R1465     4.0314695239067078e-01
    z[2,3,0]  R1466     3.2006826996803284e-01
    z[2,3,0]  R1467     3.1858152151107788e-01
    z[2,3,0]  R1468     -5.3300172090530396e-02
    z[2,3,0]  R1469     -0.0971560999751091
    z[2,3,0]  R1470     -1.9486416876316071e-01
    z[2,3,0]  R1471     6.5823340415954590e-01
    z[2,3,0]  R1472     2.6445361971855164e-01
    z[2,3,0]  R1473     5.6431043148040771e-01
    z[2,3,0]  R1474     6.9859266281127930e-01
    z[2,3,0]  R1475     -8.1654220819473267e-01
    z[2,3,0]  R1476     -4.6711954474449158e-01
    z[2,3,0]  R1477     -2.5209191441535950e-01
    z[2,3,0]  R1478     -3.8560062646865845e-01
    z[2,3,0]  R1479     -7.2104871273040771e-02
    z[2,3,0]  R1480     -1.8766702711582184e-01
    z[2,3,0]  R1481     3.5074448585510254e-01
    z[2,3,0]  R1482     1.5124855935573578e-01
    z[2,3,0]  R1483     3.6888447403907776e-01
    z[2,3,0]  R1484     -0.0568423829972744
    z[2,3,0]  R1485     0.269486665725708
    z[2,3,0]  R1486     -4.7959303855895996e-01
    z[2,3,0]  R1487     3.5856714844703674e-01
    z[2,3,0]  R1488     2.4458761513233185e-01
    z[2,3,0]  R1489     -2.5855675339698792e-02
    z[2,3,0]  R1490     4.8005181550979614e-01
    z[2,3,0]  R1491     3.8531249761581421e-01
    z[2,3,0]  R1492     3.6964043974876404e-01
    z[2,3,0]  R1493     -3.5606625676155090e-01
    z[2,3,0]  R1494     6.2695044279098511e-01
    z[2,3,0]  R1495     -9.1189378499984741e-01
    z[2,3,0]  R1496     -5.0960201025009155e-01
    z[2,3,0]  R1497     -5.2936893701553345e-01
    z[2,3,0]  R1498     2.7014988660812378e-01
    z[2,3,0]  R1499     1.2836974859237671e-01
    z[2,3,0]  R1500     -3.2415881752967834e-01
    z[2,3,0]  R1501     1.9237544620409608e-03
    z[2,3,0]  R1502     3.3115983009338379e-01
    z[2,3,0]  R1503     4.5234140753746033e-01
    z[2,3,0]  R1504     2.3212891817092896e-01
    z[2,3,0]  R1505     -6.2432825565338135e-01
    z[2,3,0]  R1506     3.9158350229263306e-01
    z[2,3,0]  R1507     2.5368806719779968e-01
    z[2,3,0]  R1508     8.4511172771453857e-01
    z[2,3,0]  R1509     9.3903625011444092e-01
    z[2,3,0]  R1510     8.1066626310348511e-01
    z[2,3,0]  R1511     8.7860095500946045e-01
    z[2,3,0]  R1512     8.9351570606231689e-01
    z[2,3,0]  R1513     8.3863776922225952e-01
    z[2,3,0]  R1514     9.1565757989883423e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R1404     -1
    z[2,3,1]  R1405     1
    z[2,3,1]  R1416     -4.0034747123718262e-01
    z[2,3,1]  R1417     -6.0209697484970093e-01
    z[2,3,1]  R1418     -6.6832476854324341e-01
    z[2,3,1]  R1419     -1.7312319576740265e-01
    z[2,3,1]  R1420     -5.4768007993698120e-01
    z[2,3,1]  R1421     -4.1051355004310608e-01
    z[2,3,1]  R1422     -4.7652366757392883e-01
    z[2,3,1]  R1423     -3.5312104225158691e-01
    z[2,3,1]  R1424     -4.9516549706459045e-01
    z[2,3,1]  R1425     -1.2680651247501373e-01
    z[2,3,1]  R1426     5.8382898569107056e-01
    z[2,3,1]  R1427     6.0742568969726562e-01
    z[2,3,1]  R1428     1.7663152515888214e-01
    z[2,3,1]  R1429     3.5486739128828049e-02
    z[2,3,1]  R1430     -5.5451724678277969e-02
    z[2,3,1]  R1431     -1.2574690580368042e-01
    z[2,3,1]  R1432     3.8177499175071716e-01
    z[2,3,1]  R1433     2.3090101778507233e-01
    z[2,3,1]  R1434     4.3733924627304077e-01
    z[2,3,1]  R1435     5.9414225816726685e-01
    z[2,3,1]  R1436     7.4466150999069214e-01
    z[2,3,1]  R1437     -8.7734496593475342e-01
    z[2,3,1]  R1438     -8.5569155216217041e-01
    z[2,3,1]  R1439     -8.4874033927917480e-01
    z[2,3,1]  R1440     -8.4980607032775879e-01
    z[2,3,1]  R1441     -8.1663197278976440e-01
    z[2,3,1]  R1442     -9.0548592805862427e-01
    z[2,3,1]  R1443     -8.9221370220184326e-01
    z[2,3,1]  R1444     -8.9116054773330688e-01
    z[2,3,1]  R1445     -7.8599756956100464e-01
    z[2,3,1]  R1446     6.4114809036254883e-01
    z[2,3,1]  R1447     7.1110695600509644e-01
    z[2,3,1]  R1448     4.1350635886192322e-01
    z[2,3,1]  R1449     4.2939990758895874e-01
    z[2,3,1]  R1450     3.7744721770286560e-01
    z[2,3,1]  R1451     -8.3991122245788574e-01
    z[2,3,1]  R1452     -4.9871000647544861e-01
    z[2,3,1]  R1453     -6.9016766548156738e-01
    z[2,3,1]  R1454     -1.6022150218486786e-01
    z[2,3,1]  R1455     5.0554737448692322e-02
    z[2,3,1]  R1456     9.8127990961074829e-02
    z[2,3,1]  R1457     -3.9291703701019287e-01
    z[2,3,1]  R1458     -1.1177907884120941e-01
    z[2,3,1]  R1459     -2.9897859692573547e-01
    z[2,3,1]  R1460     3.5906076431274414e-01
    z[2,3,1]  R1461     3.8666567206382751e-01
    z[2,3,1]  R1462     2.4915374815464020e-01
    z[2,3,1]  R1463     2.0148459076881409e-01
    z[2,3,1]  R1464     2.9861399531364441e-01
    z[2,3,1]  R1465     -8.7873065471649170e-01
    z[2,3,1]  R1466     -7.7030980587005615e-01
    z[2,3,1]  R1467     -7.4472886323928833e-01
    z[2,3,1]  R1468     -7.0607739686965942e-01
    z[2,3,1]  R1469     -6.1061781644821167e-01
    z[2,3,1]  R1470     -5.8673632144927979e-01
    z[2,3,1]  R1471     5.6714862585067749e-01
    z[2,3,1]  R1472     6.0628509521484375e-01
    z[2,3,1]  R1473     6.5020549297332764e-01
    z[2,3,1]  R1474     -3.5180736333131790e-02
    z[2,3,1]  R1475     1.5650710463523865e-01
    z[2,3,1]  R1476     3.1514936685562134e-01
    z[2,3,1]  R1477     -1.5191204845905304e-01
    z[2,3,1]  R1478     -2.3847508430480957e-01
    z[2,3,1]  R1479     -8.9345580339431763e-01
    z[2,3,1]  R1480     -8.7426781654357910e-01
    z[2,3,1]  R1481     8.1471043825149536e-01
    z[2,3,1]  R1482     0.825800895690918
    z[2,3,1]  R1483     7.9975461959838867e-01
    z[2,3,1]  R1484     -7.1221423149108887e-01
    z[2,3,1]  R1485     -7.7294135093688965e-01
    z[2,3,1]  R1486     -7.2220253944396973e-01
    z[2,3,1]  R1487     -6.6316813230514526e-01
    z[2,3,1]  R1488     -6.6478884220123291e-01
    z[2,3,1]  R1489     -6.2566965818405151e-01
    z[2,3,1]  R1490     6.6959112882614136e-01
    z[2,3,1]  R1491     7.3697966337203979e-01
    z[2,3,1]  R1492     7.4696606397628784e-01
    z[2,3,1]  R1493     -0.578748345375061
    z[2,3,1]  R1494     5.0334107875823975e-01
    z[2,3,1]  R1495     1.3572555780410767e-01
    z[2,3,1]  R1496     0.361227422952652
    z[2,3,1]  R1497     -3.4717705845832825e-01
    z[2,3,1]  R1498     -8.4776496887207031e-01
    z[2,3,1]  R1499     9.0776854753494263e-01
    z[2,3,1]  R1500     -0.807357132434845
    z[2,3,1]  R1501     -8.0007779598236084e-01
    z[2,3,1]  R1502     -0.755072832107544
    z[2,3,1]  R1503     7.3512774705886841e-01
    z[2,3,1]  R1504     -6.8834644556045532e-01
    z[2,3,1]  R1505     1.4412263035774231e-01
    z[2,3,1]  R1506     -7.5586807727813721e-01
    z[2,3,1]  R1507     -7.2229963541030884e-01
    z[2,3,1]  R1508     1.0070722550153732e-01
    z[2,3,1]  R1509     1.9718358293175697e-02
    z[2,3,1]  R1510     1.5232196450233459e-01
    z[2,3,1]  R1511     2.2131569683551788e-01
    z[2,3,1]  R1512     0.0603828951716423
    z[2,3,1]  R1513     -2.1022692322731018e-02
    z[2,3,1]  R1514     1.4718034863471985e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R1406     -1
    z[2,3,2]  R1407     1
    z[2,3,2]  R1416     2.7930381894111633e-01
    z[2,3,2]  R1417     2.6787906885147095e-01
    z[2,3,2]  R1418     3.8824307918548584e-01
    z[2,3,2]  R1419     5.2606755495071411e-01
    z[2,3,2]  R1420     2.9414427280426025e-01
    z[2,3,2]  R1421     3.2297840714454651e-01
    z[2,3,2]  R1422     3.0626228451728821e-01
    z[2,3,2]  R1423     2.0133000612258911e-01
    z[2,3,2]  R1424     5.0488901138305664e-01
    z[2,3,2]  R1425     5.7198160886764526e-01
    z[2,3,2]  R1426     -3.8364905118942261e-01
    z[2,3,2]  R1427     -6.2465769052505493e-01
    z[2,3,2]  R1428     -3.8598701357841492e-01
    z[2,3,2]  R1429     -8.0465242266654968e-02
    z[2,3,2]  R1430     -5.5144089460372925e-01
    z[2,3,2]  R1431     -4.8674494028091431e-01
    z[2,3,2]  R1432     -4.4633024930953979e-01
    z[2,3,2]  R1433     -1.2243931740522385e-01
    z[2,3,2]  R1434     -2.9714056849479675e-01
    z[2,3,2]  R1435     6.4323648810386658e-02
    z[2,3,2]  R1436     4.5305392146110535e-01
    z[2,3,2]  R1437     -0.0395146943628788
    z[2,3,2]  R1438     0.0572814904153347
    z[2,3,2]  R1439     9.0387947857379913e-02
    z[2,3,2]  R1440     9.6831507980823517e-02
    z[2,3,2]  R1441     -4.2133229970932007e-01
    z[2,3,2]  R1442     -2.3272365331649780e-01
    z[2,3,2]  R1443     -3.3689412474632263e-01
    z[2,3,2]  R1444     -2.7912008762359619e-01
    z[2,3,2]  R1445     2.3952837288379669e-01
    z[2,3,2]  R1446     -5.2558034658432007e-01
    z[2,3,2]  R1447     -3.7949335575103760e-01
    z[2,3,2]  R1448     -5.0442464649677277e-02
    z[2,3,2]  R1449     0.0793595239520073
    z[2,3,2]  R1450     -1.1186948418617249e-01
    z[2,3,2]  R1451     -2.4897256866097450e-02
    z[2,3,2]  R1452     2.4634398519992828e-01
    z[2,3,2]  R1453     3.8176274299621582e-01
    z[2,3,2]  R1454     2.1233913302421570e-01
    z[2,3,2]  R1455     -5.7450437545776367e-01
    z[2,3,2]  R1456     -5.4136312007904053e-01
    z[2,3,2]  R1457     -4.8270869255065918e-01
    z[2,3,2]  R1458     -6.6043287515640259e-01
    z[2,3,2]  R1459     1.9376932084560394e-01
    z[2,3,2]  R1460     -0.762722373008728
    z[2,3,2]  R1461     5.5558848381042480e-01
    z[2,3,2]  R1462     -5.3006899356842041e-01
    z[2,3,2]  R1463     1.7786386609077454e-01
    z[2,3,2]  R1464     3.8306677341461182e-01
    z[2,3,2]  R1465     1.2119157612323761e-01
    z[2,3,2]  R1466     -2.3542407155036926e-01
    z[2,3,2]  R1467     -7.2500328533351421e-03
    z[2,3,2]  R1468     -0.0172028299421072
    z[2,3,2]  R1469     2.1154652535915375e-01
    z[2,3,2]  R1470     8.4976553916931152e-02
    z[2,3,2]  R1471     -4.9993500113487244e-02
    z[2,3,2]  R1472     3.0862805247306824e-01
    z[2,3,2]  R1473     2.4009078741073608e-01
    z[2,3,2]  R1474     0.0586773082613945
    z[2,3,2]  R1475     2.2539477050304413e-01
    z[2,3,2]  R1476     1.4220415614545345e-02
    z[2,3,2]  R1477     -6.3256755471229553e-02
    z[2,3,2]  R1478     -1.6211499273777008e-01
    z[2,3,2]  R1479     -1.1996103823184967e-01
    z[2,3,2]  R1480     9.2876493930816650e-02
    z[2,3,2]  R1481     -4.4878937304019928e-02
    z[2,3,2]  R1482     3.0679382383823395e-02
    z[2,3,2]  R1483     1.7138579487800598e-01
    z[2,3,2]  R1484     8.4675490856170654e-02
    z[2,3,2]  R1485     1.3530911877751350e-02
    z[2,3,2]  R1486     2.7614161372184753e-01
    z[2,3,2]  R1487     -1.5526381134986877e-01
    z[2,3,2]  R1488     4.7609332203865051e-01
    z[2,3,2]  R1489     2.2000728547573090e-01
    z[2,3,2]  R1490     2.9708305001258850e-01
    z[2,3,2]  R1491     7.5209461152553558e-02
    z[2,3,2]  R1492     -1.4300939440727234e-01
    z[2,3,2]  R1493     1.3825416564941406e-01
    z[2,3,2]  R1494     5.0136047601699829e-01
    z[2,3,2]  R1495     1.3743334449827671e-02
    z[2,3,2]  R1496     -2.3087030649185181e-01
    z[2,3,2]  R1497     -2.7897748351097107e-01
    z[2,3,2]  R1498     -2.2459983825683594e-01
    z[2,3,2]  R1499     -0.21180360019207
    z[2,3,2]  R1500     -1.8946641683578491e-01
    z[2,3,2]  R1501     -1.6353523731231689e-01
    z[2,3,2]  R1502     -2.2070477902889252e-01
    z[2,3,2]  R1503     6.5782824531197548e-03
    z[2,3,2]  R1504     -3.8861316442489624e-01
    z[2,3,2]  R1505     1.6582390666007996e-01
    z[2,3,2]  R1506     -0.30942302942276
    z[2,3,2]  R1507     -2.1762351691722870e-01
    z[2,3,2]  R1508     3.2298988103866577e-01
    z[2,3,2]  R1509     6.7150115966796875e-02
    z[2,3,2]  R1510     4.4720417261123657e-01
    z[2,3,2]  R1511     4.0122170001268387e-02
    z[2,3,2]  R1512     1.4636841416358948e-01
    z[2,3,2]  R1513     1.9571933150291443e-01
    z[2,3,2]  R1514     1.6245013475418091e-01
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R1408     -1
    z[2,3,3]  R1409     1
    z[2,3,3]  R1416     3.3067500591278076e-01
    z[2,3,3]  R1417     9.6278652548789978e-02
    z[2,3,3]  R1418     1.2748534977436066e-01
    z[2,3,3]  R1419     3.3887475728988647e-01
    z[2,3,3]  R1420     5.7916469871997833e-02
    z[2,3,3]  R1421     1.9778871536254883e-01
    z[2,3,3]  R1422     2.0071412622928619e-01
    z[2,3,3]  R1423     6.0937386751174927e-01
    z[2,3,3]  R1424     3.7540411949157715e-01
    z[2,3,3]  R1425     1.9863419234752655e-01
    z[2,3,3]  R1426     1.9271922111511230e-01
    z[2,3,3]  R1427     -2.4844960868358612e-01
    z[2,3,3]  R1428     -5.9494799375534058e-01
    z[2,3,3]  R1429     -1.6164198517799377e-01
    z[2,3,3]  R1430     -4.6853333711624146e-01
    z[2,3,3]  R1431     -6.6356897354125977e-01
    z[2,3,3]  R1432     -5.4165536165237427e-01
    z[2,3,3]  R1433     -4.6803241968154907e-01
    z[2,3,3]  R1434     5.5928952991962433e-02
    z[2,3,3]  R1435     -4.2371249198913574e-01
    z[2,3,3]  R1436     -3.2224440574645996e-01
    z[2,3,3]  R1437     1.0479624569416046e-01
    z[2,3,3]  R1438     1.4834481477737427e-01
    z[2,3,3]  R1439     3.1913340091705322e-01
    z[2,3,3]  R1440     2.4048164486885071e-01
    z[2,3,3]  R1441     -7.8706553904339671e-04
    z[2,3,3]  R1442     -1.0655672103166580e-01
    z[2,3,3]  R1443     1.9051907584071159e-02
    z[2,3,3]  R1444     1.5867017209529877e-01
    z[2,3,3]  R1445     -2.9746058583259583e-01
    z[2,3,3]  R1446     -4.8250073194503784e-01
    z[2,3,3]  R1447     -2.4838294088840485e-01
    z[2,3,3]  R1448     3.1995039433240891e-02
    z[2,3,3]  R1449     3.0408254265785217e-01
    z[2,3,3]  R1450     -3.2031536102294922e-02
    z[2,3,3]  R1451     -3.9799782633781433e-01
    z[2,3,3]  R1452     -7.4008069932460785e-02
    z[2,3,3]  R1453     1.1232008039951324e-01
    z[2,3,3]  R1454     7.0545274019241333e-01
    z[2,3,3]  R1455     -5.5182403326034546e-01
    z[2,3,3]  R1456     -2.5081974267959595e-01
    z[2,3,3]  R1457     -3.1413015723228455e-01
    z[2,3,3]  R1458     -5.4775989055633545e-01
    z[2,3,3]  R1459     -5.4104810953140259e-01
    z[2,3,3]  R1460     -1.3957542367279530e-02
    z[2,3,3]  R1461     -3.8215351104736328e-01
    z[2,3,3]  R1462     -2.6786011457443237e-01
    z[2,3,3]  R1463     -4.9451878666877747e-01
    z[2,3,3]  R1464     -6.1520993709564209e-01
    z[2,3,3]  R1465     1.1706600338220596e-01
    z[2,3,3]  R1466     1.7956618964672089e-01
    z[2,3,3]  R1467     2.1216855943202972e-01
    z[2,3,3]  R1468     5.1769173145294189e-01
    z[2,3,3]  R1469     6.4694148302078247e-01
    z[2,3,3]  R1470     6.5466111898422241e-01
    z[2,3,3]  R1471     -1.8238945305347443e-01
    z[2,3,3]  R1472     4.4153988361358643e-01
    z[2,3,3]  R1473     3.9338329434394836e-01
    z[2,3,3]  R1474     0.610335648059845
    z[2,3,3]  R1475     6.5426409244537354e-02
    z[2,3,3]  R1476     4.9048196524381638e-02
    z[2,3,3]  R1477     -3.0986478924751282e-01
    z[2,3,3]  R1478     -1.7784656584262848e-01
    z[2,3,3]  R1479     1.1586633324623108e-01
    z[2,3,3]  R1480     -1.1492399126291275e-01
    z[2,3,3]  R1481     -2.9630091786384583e-01
    z[2,3,3]  R1482     2.5218906998634338e-01
    z[2,3,3]  R1483     -4.9235463142395020e-02
    z[2,3,3]  R1484     2.7134326100349426e-01
    z[2,3,3]  R1485     4.4782254099845886e-01
    z[2,3,3]  R1486     2.7273058891296387e-01
    z[2,3,3]  R1487     4.8097413033246994e-02
    z[2,3,3]  R1488     -5.0844904035329819e-02
    z[2,3,3]  R1489     -2.6202961802482605e-01
    z[2,3,3]  R1490     -5.7135045528411865e-02
    z[2,3,3]  R1491     4.1552387177944183e-02
    z[2,3,3]  R1492     3.9916276931762695e-02
    z[2,3,3]  R1493     5.5593556165695190e-01
    z[2,3,3]  R1494     3.3694509416818619e-02
    z[2,3,3]  R1495     2.4267129600048065e-01
    z[2,3,3]  R1496     -2.9687255620956421e-01
    z[2,3,3]  R1497     4.6162612736225128e-02
    z[2,3,3]  R1498     1.0166615247726440e-02
    z[2,3,3]  R1499     -0.074288509786129
    z[2,3,3]  R1500     2.5950086116790771e-01
    z[2,3,3]  R1501     4.0295529365539551e-01
    z[2,3,3]  R1502     3.8861134648323059e-01
    z[2,3,3]  R1503     -4.7248327732086182e-01
    z[2,3,3]  R1504     9.4653815031051636e-02
    z[2,3,3]  R1505     -5.4831784963607788e-01
    z[2,3,3]  R1506     3.3024334907531738e-01
    z[2,3,3]  R1507     -4.7218668460845947e-01
    z[2,3,3]  R1508     3.7375611066818237e-01
    z[2,3,3]  R1509     2.7929738163948059e-01
    z[2,3,3]  R1510     9.5742210745811462e-02
    z[2,3,3]  R1511     3.8788342475891113e-01
    z[2,3,3]  R1512     1.6844633221626282e-01
    z[2,3,3]  R1513     3.8832414150238037e-01
    z[2,3,3]  R1514     2.2806464135646820e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R1410     -1
    z[2,3,4]  R1411     1
    z[2,3,4]  R1416     1.5591309964656830e-01
    z[2,3,4]  R1417     3.3210579305887222e-02
    z[2,3,4]  R1418     3.2860311865806580e-01
    z[2,3,4]  R1419     2.3615252971649170e-01
    z[2,3,4]  R1420     2.7785533666610718e-01
    z[2,3,4]  R1421     5.7523810863494873e-01
    z[2,3,4]  R1422     0.505702555179596
    z[2,3,4]  R1423     1.4279535412788391e-01
    z[2,3,4]  R1424     4.5110586285591125e-01
    z[2,3,4]  R1425     5.5977356433868408e-01
    z[2,3,4]  R1426     -3.8477557897567749e-01
    z[2,3,4]  R1427     -9.1467574238777161e-02
    z[2,3,4]  R1428     2.3537762463092804e-01
    z[2,3,4]  R1429     5.7685323059558868e-02
    z[2,3,4]  R1430     -0.207729309797287
    z[2,3,4]  R1431     -4.6287890523672104e-02
    z[2,3,4]  R1432     2.6507401838898659e-02
    z[2,3,4]  R1433     2.2686150670051575e-01
    z[2,3,4]  R1434     -2.1972274780273438e-01
    z[2,3,4]  R1435     6.8991214036941528e-02
    z[2,3,4]  R1436     2.7227815985679626e-01
    z[2,3,4]  R1437     -4.2880597710609436e-01
    z[2,3,4]  R1438     -0.341124564409256
    z[2,3,4]  R1439     -5.3095526993274689e-02
    z[2,3,4]  R1440     -1.3309714198112488e-01
    z[2,3,4]  R1441     0.0838802382349968
    z[2,3,4]  R1442     9.1450840234756470e-02
    z[2,3,4]  R1443     -1.2955079972743988e-01
    z[2,3,4]  R1444     -1.3842868804931641e-01
    z[2,3,4]  R1445     2.5895136594772339e-01
    z[2,3,4]  R1446     -9.0126700699329376e-02
    z[2,3,4]  R1447     -2.3520599305629730e-01
    z[2,3,4]  R1448     -4.7348889708518982e-01
    z[2,3,4]  R1449     2.4419422447681427e-01
    z[2,3,4]  R1450     3.8060879707336426e-01
    z[2,3,4]  R1451     -1.5124662220478058e-01
    z[2,3,4]  R1452     1.5121409296989441e-01
    z[2,3,4]  R1453     4.3616327643394470e-01
    z[2,3,4]  R1454     -5.3156131505966187e-01
    z[2,3,4]  R1455     3.8681440055370331e-02
    z[2,3,4]  R1456     -3.4683328866958618e-01
    z[2,3,4]  R1457     -3.0500268936157227e-01
    z[2,3,4]  R1458     4.3743055313825607e-02
    z[2,3,4]  R1459     1.3978804647922516e-01
    z[2,3,4]  R1460     -1.5404058992862701e-01
    z[2,3,4]  R1461     -0.0876581221818924
    z[2,3,4]  R1462     3.1593859195709229e-01
    z[2,3,4]  R1463     4.8961933702230453e-02
    z[2,3,4]  R1464     -1.2086918950080872e-01
    z[2,3,4]  R1465     -6.4705125987529755e-02
    z[2,3,4]  R1466     3.7865522503852844e-01
    z[2,3,4]  R1467     4.4442600011825562e-01
    z[2,3,4]  R1468     2.3144865036010742e-01
    z[2,3,4]  R1469     -2.1084553003311157e-01
    z[2,3,4]  R1470     1.6681958734989166e-01
    z[2,3,4]  R1471     -1.5593305230140686e-01
    z[2,3,4]  R1472     -0.275911420583725
    z[2,3,4]  R1473     -1.8377138674259186e-01
    z[2,3,4]  R1474     2.6651170849800110e-01
    z[2,3,4]  R1475     -1.0773171670734882e-03
    z[2,3,4]  R1476     -7.9781693220138550e-01
    z[2,3,4]  R1477     -5.2463328838348389e-01
    z[2,3,4]  R1478     -7.3747575283050537e-01
    z[2,3,4]  R1479     -4.4086609035730362e-02
    z[2,3,4]  R1480     1.6232788562774658e-01
    z[2,3,4]  R1481     3.2864493131637573e-01
    z[2,3,4]  R1482     2.0857295393943787e-01
    z[2,3,4]  R1483     0.376196026802063
    z[2,3,4]  R1484     -3.8204070925712585e-01
    z[2,3,4]  R1485     -2.7704018354415894e-01
    z[2,3,4]  R1486     -3.0748006701469421e-01
    z[2,3,4]  R1487     -2.4504117667675018e-01
    z[2,3,4]  R1488     1.9450557231903076e-01
    z[2,3,4]  R1489     -0.614127516746521
    z[2,3,4]  R1490     -4.1097548604011536e-01
    z[2,3,4]  R1491     1.3882963359355927e-01
    z[2,3,4]  R1492     -3.6934280395507812e-01
    z[2,3,4]  R1493     2.3542624711990356e-01
    z[2,3,4]  R1494     -2.0454618334770203e-01
    z[2,3,4]  R1495     -1.6884620487689972e-01
    z[2,3,4]  R1496     -6.3305526971817017e-01
    z[2,3,4]  R1497     -5.4552334547042847e-01
    z[2,3,4]  R1498     3.6771696805953979e-01
    z[2,3,4]  R1499     1.9974310696125031e-01
    z[2,3,4]  R1500     3.4017801284790039e-01
    z[2,3,4]  R1501     -2.6309159398078918e-01
    z[2,3,4]  R1502     2.5382652878761292e-02
    z[2,3,4]  R1503     -1.6438420116901398e-01
    z[2,3,4]  R1504     3.2526103314012289e-03
    z[2,3,4]  R1505     3.2445633411407471e-01
    z[2,3,4]  R1506     -1.4153721928596497e-01
    z[2,3,4]  R1507     -3.0477762222290039e-01
    z[2,3,4]  R1508     1.4489167928695679e-01
    z[2,3,4]  R1509     1.8020328879356384e-01
    z[2,3,4]  R1510     2.0290957391262054e-01
    z[2,3,4]  R1511     -6.0020685195922852e-02
    z[2,3,4]  R1512     3.7530052661895752e-01
    z[2,3,4]  R1513     1.0802821815013885e-01
    z[2,3,4]  R1514     1.0176397860050201e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R1412     -1
    z[2,3,5]  R1413     1
    z[2,3,5]  R1416     -2.6245030760765076e-01
    z[2,3,5]  R1417     -0.0670199990272522
    z[2,3,5]  R1418     -2.4436776340007782e-01
    z[2,3,5]  R1419     3.6630305647850037e-01
    z[2,3,5]  R1420     -2.6340955495834351e-01
    z[2,3,5]  R1421     -9.4148583710193634e-02
    z[2,3,5]  R1422     -3.4305401146411896e-02
    z[2,3,5]  R1423     1.6856788098812103e-01
    z[2,3,5]  R1424     -5.0172898918390274e-02
    z[2,3,5]  R1425     9.5535710453987122e-02
    z[2,3,5]  R1426     -2.5173571705818176e-01
    z[2,3,5]  R1427     -3.9147889614105225e-01
    z[2,3,5]  R1428     5.3077928721904755e-02
    z[2,3,5]  R1429     -9.2946678400039673e-02
    z[2,3,5]  R1430     9.7296662628650665e-02
    z[2,3,5]  R1431     -9.6086002886295319e-02
    z[2,3,5]  R1432     -4.2067468166351318e-01
    z[2,3,5]  R1433     -5.5732220411300659e-01
    z[2,3,5]  R1434     -9.7770117223262787e-02
    z[2,3,5]  R1435     -1.1749976128339767e-01
    z[2,3,5]  R1436     2.3909299075603485e-01
    z[2,3,5]  R1437     -2.1298358216881752e-02
    z[2,3,5]  R1438     -2.9836791753768921e-01
    z[2,3,5]  R1439     -1.0847450233995914e-02
    z[2,3,5]  R1440     3.6222180724143982e-01
    z[2,3,5]  R1441     -2.8392225503921509e-01
    z[2,3,5]  R1442     -3.4298751503229141e-02
    z[2,3,5]  R1443     -0.0587601400911808
    z[2,3,5]  R1444     5.3964339196681976e-02
    z[2,3,5]  R1445     3.1064370274543762e-01
    z[2,3,5]  R1446     -4.3982222676277161e-02
    z[2,3,5]  R1447     3.9665651321411133e-01
    z[2,3,5]  R1448     5.3600388765335083e-01
    z[2,3,5]  R1449     -5.4437303543090820e-01
    z[2,3,5]  R1450     -4.8453959822654724e-01
    z[2,3,5]  R1451     -2.4696022272109985e-01
    z[2,3,5]  R1452     1.7080970108509064e-01
    z[2,3,5]  R1453     -0.337971568107605
    z[2,3,5]  R1454     1.9546246528625488e-01
    z[2,3,5]  R1455     -1.3671287894248962e-01
    z[2,3,5]  R1456     5.4327660799026489e-01
    z[2,3,5]  R1457     2.7519872412085533e-02
    z[2,3,5]  R1458     -1.4023344218730927e-01
    z[2,3,5]  R1459     -6.8692475557327271e-02
    z[2,3,5]  R1460     1.1228796094655991e-02
    z[2,3,5]  R1461     -1.6981534659862518e-01
    z[2,3,5]  R1462     -5.6863898038864136e-01
    z[2,3,5]  R1463     -6.2710106372833252e-01
    z[2,3,5]  R1464     4.2931646108627319e-01
    z[2,3,5]  R1465     1.5785978734493256e-01
    z[2,3,5]  R1466     2.5563362240791321e-01
    z[2,3,5]  R1467     -0.317251980304718
    z[2,3,5]  R1468     0.415078729391098
    z[2,3,5]  R1469     -3.3079841732978821e-01
    z[2,3,5]  R1470     -3.9183324575424194e-01
    z[2,3,5]  R1471     1.9849547743797302e-01
    z[2,3,5]  R1472     2.5840106606483459e-01
    z[2,3,5]  R1473     -2.5410490110516548e-02
    z[2,3,5]  R1474     -1.7936001718044281e-01
    z[2,3,5]  R1475     3.9175990223884583e-01
    z[2,3,5]  R1476     6.6067695617675781e-02
    z[2,3,5]  R1477     7.2028040885925293e-01
    z[2,3,5]  R1478     4.3533289432525635e-01
    z[2,3,5]  R1479     4.0302121639251709e-01
    z[2,3,5]  R1480     3.1039389967918396e-01
    z[2,3,5]  R1481     8.8278248906135559e-02
    z[2,3,5]  R1482     3.7574744224548340e-01
    z[2,3,5]  R1483     1.4499436318874359e-01
    z[2,3,5]  R1484     -5.1070624589920044e-01
    z[2,3,5]  R1485     -2.2779320180416107e-01
    z[2,3,5]  R1486     4.5578092336654663e-02
    z[2,3,5]  R1487     -5.8653438091278076e-01
    z[2,3,5]  R1488     -4.6099528670310974e-01
    z[2,3,5]  R1489     -7.5132623314857483e-02
    z[2,3,5]  R1490     -2.4239070713520050e-01
    z[2,3,5]  R1491     -3.3351576328277588e-01
    z[2,3,5]  R1492     -3.1046655774116516e-01
    z[2,3,5]  R1493     -2.9368317127227783e-01
    z[2,3,5]  R1494     1.9626735150814056e-01
    z[2,3,5]  R1495     -1.4469853043556213e-01
    z[2,3,5]  R1496     -5.5544916540384293e-02
    z[2,3,5]  R1497     4.6312987804412842e-01
    z[2,3,5]  R1498     2.5895142927765846e-02
    z[2,3,5]  R1499     2.1338342130184174e-01
    z[2,3,5]  R1500     8.5565216839313507e-02
    z[2,3,5]  R1501     0.0840703547000885
    z[2,3,5]  R1502     -3.4614598751068115e-01
    z[2,3,5]  R1503     6.1836522072553635e-02
    z[2,3,5]  R1504     -1.8361641466617584e-01
    z[2,3,5]  R1505     3.1850022077560425e-01
    z[2,3,5]  R1506     -1.7846895754337311e-01
    z[2,3,5]  R1507     2.1995152533054352e-01
    z[2,3,5]  R1508     -3.9587166160345078e-02
    z[2,3,5]  R1509     -3.2489750534296036e-02
    z[2,3,5]  R1510     0.263158917427063
    z[2,3,5]  R1511     -2.4518856778740883e-02
    z[2,3,5]  R1512     7.6157540082931519e-02
    z[2,3,5]  R1513     2.9837989807128906e-01
    z[2,3,5]  R1514     2.2120243310928345e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R1414     -1
    z[2,3,6]  R1415     1
    z[2,3,6]  R1416     -4.6458251774311066e-02
    z[2,3,6]  R1417     1.8408608436584473e-01
    z[2,3,6]  R1418     2.6160009205341339e-02
    z[2,3,6]  R1419     7.8310193493962288e-03
    z[2,3,6]  R1420     9.1239757835865021e-02
    z[2,3,6]  R1421     -0.0608413964509964
    z[2,3,6]  R1422     3.1286141276359558e-01
    z[2,3,6]  R1423     6.4555965363979340e-02
    z[2,3,6]  R1424     2.9393553733825684e-01
    z[2,3,6]  R1425     1.7758828401565552e-01
    z[2,3,6]  R1426     5.1203376054763794e-01
    z[2,3,6]  R1427     -4.1345804929733276e-02
    z[2,3,6]  R1428     -7.9316355288028717e-02
    z[2,3,6]  R1429     3.1014952063560486e-01
    z[2,3,6]  R1430     4.7311067581176758e-01
    z[2,3,6]  R1431     4.0797162055969238e-01
    z[2,3,6]  R1432     1.3117515482008457e-02
    z[2,3,6]  R1433     3.9898250252008438e-02
    z[2,3,6]  R1434     2.5561091303825378e-01
    z[2,3,6]  R1435     0.303884357213974
    z[2,3,6]  R1436     -1.4541435521095991e-03
    z[2,3,6]  R1437     -1.3916519284248352e-01
    z[2,3,6]  R1438     -1.6364848613739014e-01
    z[2,3,6]  R1439     2.7841567993164062e-01
    z[2,3,6]  R1440     6.2870927155017853e-02
    z[2,3,6]  R1441     -1.7144758999347687e-01
    z[2,3,6]  R1442     2.7778929471969604e-01
    z[2,3,6]  R1443     2.5665801763534546e-01
    z[2,3,6]  R1444     -2.6609787344932556e-01
    z[2,3,6]  R1445     2.6930475234985352e-01
    z[2,3,6]  R1446     1.8482415378093719e-01
    z[2,3,6]  R1447     2.4370370432734489e-02
    z[2,3,6]  R1448     -3.8140645623207092e-01
    z[2,3,6]  R1449     -4.3413665890693665e-01
    z[2,3,6]  R1450     1.0922961682081223e-01
    z[2,3,6]  R1451     -1.5183512866497040e-01
    z[2,3,6]  R1452     -7.2895568609237671e-01
    z[2,3,6]  R1453     1.7387457191944122e-01
    z[2,3,6]  R1454     -2.4548269808292389e-01
    z[2,3,6]  R1455     4.6168902516365051e-01
    z[2,3,6]  R1456     1.1097563803195953e-01
    z[2,3,6]  R1457     4.7059124708175659e-01
    z[2,3,6]  R1458     -1.1967720836400986e-01
    z[2,3,6]  R1459     5.3260743618011475e-01
    z[2,3,6]  R1460     3.1857562065124512e-01
    z[2,3,6]  R1461     1.5946796536445618e-01
    z[2,3,6]  R1462     2.4550843983888626e-02
    z[2,3,6]  R1463     4.2538964748382568e-01
    z[2,3,6]  R1464     -1.3276237249374390e-01
    z[2,3,6]  R1465     8.8356077671051025e-02
    z[2,3,6]  R1466     -0.0882168561220169
    z[2,3,6]  R1467     -2.5562165305018425e-02
    z[2,3,6]  R1468     -6.6741362214088440e-02
    z[2,3,6]  R1469     2.3195805028080940e-02
    z[2,3,6]  R1470     2.4579038843512535e-02
    z[2,3,6]  R1471     -3.8156315684318542e-01
    z[2,3,6]  R1472     -3.5968831181526184e-01
    z[2,3,6]  R1473     1.0943107306957245e-01
    z[2,3,6]  R1474     1.7770607769489288e-01
    z[2,3,6]  R1475     -3.1654992699623108e-01
    z[2,3,6]  R1476     -1.9747292995452881e-01
    z[2,3,6]  R1477     -1.3896332681179047e-01
    z[2,3,6]  R1478     5.6087784469127655e-02
    z[2,3,6]  R1479     -0.0659722089767456
    z[2,3,6]  R1480     -2.3645015060901642e-01
    z[2,3,6]  R1481     8.7271459400653839e-02
    z[2,3,6]  R1482     -2.1435341238975525e-01
    z[2,3,6]  R1483     1.7312683165073395e-01
    z[2,3,6]  R1484     4.4121686369180679e-02
    z[2,3,6]  R1485     2.3863058537244797e-02
    z[2,3,6]  R1486     3.4006141126155853e-02
    z[2,3,6]  R1487     3.3906292170286179e-02
    z[2,3,6]  R1488     -1.3650478422641754e-01
    z[2,3,6]  R1489     -3.2864677906036377e-01
    z[2,3,6]  R1490     -4.4955067336559296e-02
    z[2,3,6]  R1491     -4.1292348504066467e-01
    z[2,3,6]  R1492     -2.2485366463661194e-01
    z[2,3,6]  R1493     2.6155945658683777e-01
    z[2,3,6]  R1494     -1.4395545423030853e-01
    z[2,3,6]  R1495     -2.0372359454631805e-01
    z[2,3,6]  R1496     -2.5405132770538330e-01
    z[2,3,6]  R1497     -8.4806688129901886e-02
    z[2,3,6]  R1498     -1.4791491627693176e-01
    z[2,3,6]  R1499     -1.5384469926357269e-01
    z[2,3,6]  R1500     -1.2967227399349213e-01
    z[2,3,6]  R1501     3.0735993385314941e-01
    z[2,3,6]  R1502     2.7324759867042303e-03
    z[2,3,6]  R1503     -2.9068564996123314e-02
    z[2,3,6]  R1504     5.2781653404235840e-01
    z[2,3,6]  R1505     -2.3362050950527191e-01
    z[2,3,6]  R1506     1.3652274012565613e-01
    z[2,3,6]  R1507     4.8345115035772324e-02
    z[2,3,6]  R1508     9.5223180949687958e-02
    z[2,3,6]  R1509     4.2157445102930069e-02
    z[2,3,6]  R1510     5.9282500296831131e-03
    z[2,3,6]  R1511     -1.5103885531425476e-01
    z[2,3,6]  R1512     -3.9183810353279114e-02
    z[2,3,6]  R1513     -0.0802641361951828
    z[2,3,6]  R1514     -4.7107253223657608e-02
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1515     -1
    z[3,2,0]  R1516     1
    z[3,2,0]  R1529     -3.5991060733795166e-01
    z[3,2,0]  R1530     -4.5456355810165405e-01
    z[3,2,0]  R1531     -4.4574731588363647e-01
    z[3,2,0]  R1532     -4.6410277485847473e-01
    z[3,2,0]  R1533     -5.2192157506942749e-01
    z[3,2,0]  R1534     -4.0470978617668152e-01
    z[3,2,0]  R1535     -5.7777029275894165e-01
    z[3,2,0]  R1536     -4.0178349614143372e-01
    z[3,2,0]  R1537     -3.2651230692863464e-01
    z[3,2,0]  R1538     -4.1116729378700256e-01
    z[3,2,0]  R1539     4.0314695239067078e-01
    z[3,2,0]  R1540     3.2006826996803284e-01
    z[3,2,0]  R1541     3.1858152151107788e-01
    z[3,2,0]  R1542     -5.3300172090530396e-02
    z[3,2,0]  R1543     -0.0971560999751091
    z[3,2,0]  R1544     -1.9486416876316071e-01
    z[3,2,0]  R1545     6.5823340415954590e-01
    z[3,2,0]  R1546     2.6445361971855164e-01
    z[3,2,0]  R1547     5.6431043148040771e-01
    z[3,2,0]  R1548     6.9859266281127930e-01
    z[3,2,0]  R1549     -8.1654220819473267e-01
    z[3,2,0]  R1550     -4.6711954474449158e-01
    z[3,2,0]  R1551     -2.5209191441535950e-01
    z[3,2,0]  R1552     -3.8560062646865845e-01
    z[3,2,0]  R1553     -7.2104871273040771e-02
    z[3,2,0]  R1554     -1.8766702711582184e-01
    z[3,2,0]  R1555     3.5074448585510254e-01
    z[3,2,0]  R1556     1.5124855935573578e-01
    z[3,2,0]  R1557     3.6888447403907776e-01
    z[3,2,0]  R1558     -0.0568423829972744
    z[3,2,0]  R1559     0.269486665725708
    z[3,2,0]  R1560     -4.7959303855895996e-01
    z[3,2,0]  R1561     3.5856714844703674e-01
    z[3,2,0]  R1562     2.4458761513233185e-01
    z[3,2,0]  R1563     -2.5855675339698792e-02
    z[3,2,0]  R1564     4.8005181550979614e-01
    z[3,2,0]  R1565     3.8531249761581421e-01
    z[3,2,0]  R1566     3.6964043974876404e-01
    z[3,2,0]  R1567     -3.5606625676155090e-01
    z[3,2,0]  R1568     6.2695044279098511e-01
    z[3,2,0]  R1569     -9.1189378499984741e-01
    z[3,2,0]  R1570     -5.0960201025009155e-01
    z[3,2,0]  R1571     -5.2936893701553345e-01
    z[3,2,0]  R1572     2.7014988660812378e-01
    z[3,2,0]  R1573     1.2836974859237671e-01
    z[3,2,0]  R1574     -3.2415881752967834e-01
    z[3,2,0]  R1575     1.9237544620409608e-03
    z[3,2,0]  R1576     3.3115983009338379e-01
    z[3,2,0]  R1577     4.5234140753746033e-01
    z[3,2,0]  R1578     2.3212891817092896e-01
    z[3,2,0]  R1579     -6.2432825565338135e-01
    z[3,2,0]  R1580     3.9158350229263306e-01
    z[3,2,0]  R1581     2.5368806719779968e-01
    z[3,2,0]  R1582     8.4511172771453857e-01
    z[3,2,0]  R1583     9.3903625011444092e-01
    z[3,2,0]  R1584     8.1066626310348511e-01
    z[3,2,0]  R1585     8.7860095500946045e-01
    z[3,2,0]  R1586     8.9351570606231689e-01
    z[3,2,0]  R1587     8.3863776922225952e-01
    z[3,2,0]  R1588     9.1565757989883423e-01
    z[3,2,0]  R1589     7.4633646011352539e-01
    z[3,2,0]  R1590     7.1900504827499390e-01
    z[3,2,0]  R1591     4.6687984466552734e-01
    z[3,2,0]  R1592     6.2324780225753784e-01
    z[3,2,0]  R1593     0.674728512763977
    z[3,2,0]  R1594     5.8700817823410034e-01
    z[3,2,0]  R1595     5.3296184539794922e-01
    z[3,2,0]  R1596     6.4067316055297852e-01
    z[3,2,0]  R1597     2.5798881053924561e-01
    z[3,2,0]  R1598     0.51311856508255
    z[3,2,0]  R1599     3.4854099154472351e-02
    z[3,2,0]  R1600     1.2561009824275970e-01
    z[3,2,0]  R1601     -6.3351500034332275e-01
    z[3,2,0]  R1602     -9.2627131938934326e-01
    z[3,2,0]  R1603     -4.4369208812713623e-01
    z[3,2,0]  R1604     -3.5934317111968994e-01
    z[3,2,0]  R1605     -4.2872470617294312e-01
    z[3,2,0]  R1606     -5.9073930978775024e-01
    z[3,2,0]  R1607     -7.7080458402633667e-01
    z[3,2,0]  R1608     -5.9364432096481323e-01
    z[3,2,0]  R1609     7.1253530681133270e-02
    z[3,2,0]  R1610     -1.1843587458133698e-01
    z[3,2,0]  R1611     -1.0165821760892868e-01
    z[3,2,0]  R1612     -2.9861640930175781e-01
    z[3,2,0]  R1613     -2.4031141400337219e-01
    z[3,2,0]  R1614     -1.9633817672729492e-01
    z[3,2,0]  R1615     -1.6695541143417358e-01
    z[3,2,0]  R1616     6.3124731183052063e-02
    z[3,2,0]  R1617     -9.9326990544795990e-02
    z[3,2,0]  R1618     1.6456462442874908e-02
    z[3,2,0]  R1619     1.8886549770832062e-01
    z[3,2,0]  R1620     -2.7452784776687622e-01
    z[3,2,0]  R1621     4.1046494245529175e-01
    z[3,2,0]  R1622     -4.1521570086479187e-01
    z[3,2,0]  R1623     -6.7262166738510132e-01
    z[3,2,0]  R1624     1.6913972795009613e-01
    z[3,2,0]  R1625     3.1891646981239319e-01
    z[3,2,0]  R1626     -1.7496973276138306e-01
    z[3,2,0]  R1627     2.2483965754508972e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1517     -1
    z[3,2,1]  R1518     1
    z[3,2,1]  R1529     5.0554737448692322e-02
    z[3,2,1]  R1530     9.8127990961074829e-02
    z[3,2,1]  R1531     -3.9291703701019287e-01
    z[3,2,1]  R1532     -1.1177907884120941e-01
    z[3,2,1]  R1533     -2.9897859692573547e-01
    z[3,2,1]  R1534     3.5906076431274414e-01
    z[3,2,1]  R1535     3.8666567206382751e-01
    z[3,2,1]  R1536     2.4915374815464020e-01
    z[3,2,1]  R1537     2.0148459076881409e-01
    z[3,2,1]  R1538     2.9861399531364441e-01
    z[3,2,1]  R1539     -8.7873065471649170e-01
    z[3,2,1]  R1540     -7.7030980587005615e-01
    z[3,2,1]  R1541     -7.4472886323928833e-01
    z[3,2,1]  R1542     -7.0607739686965942e-01
    z[3,2,1]  R1543     -6.1061781644821167e-01
    z[3,2,1]  R1544     -5.8673632144927979e-01
    z[3,2,1]  R1545     5.6714862585067749e-01
    z[3,2,1]  R1546     6.0628509521484375e-01
    z[3,2,1]  R1547     6.5020549297332764e-01
    z[3,2,1]  R1548     -3.5180736333131790e-02
    z[3,2,1]  R1549     1.5650710463523865e-01
    z[3,2,1]  R1550     3.1514936685562134e-01
    z[3,2,1]  R1551     -1.5191204845905304e-01
    z[3,2,1]  R1552     -2.3847508430480957e-01
    z[3,2,1]  R1553     -8.9345580339431763e-01
    z[3,2,1]  R1554     -8.7426781654357910e-01
    z[3,2,1]  R1555     8.1471043825149536e-01
    z[3,2,1]  R1556     0.825800895690918
    z[3,2,1]  R1557     7.9975461959838867e-01
    z[3,2,1]  R1558     -7.1221423149108887e-01
    z[3,2,1]  R1559     -7.7294135093688965e-01
    z[3,2,1]  R1560     -7.2220253944396973e-01
    z[3,2,1]  R1561     -6.6316813230514526e-01
    z[3,2,1]  R1562     -6.6478884220123291e-01
    z[3,2,1]  R1563     -6.2566965818405151e-01
    z[3,2,1]  R1564     6.6959112882614136e-01
    z[3,2,1]  R1565     7.3697966337203979e-01
    z[3,2,1]  R1566     7.4696606397628784e-01
    z[3,2,1]  R1567     -0.578748345375061
    z[3,2,1]  R1568     5.0334107875823975e-01
    z[3,2,1]  R1569     1.3572555780410767e-01
    z[3,2,1]  R1570     0.361227422952652
    z[3,2,1]  R1571     -3.4717705845832825e-01
    z[3,2,1]  R1572     -8.4776496887207031e-01
    z[3,2,1]  R1573     9.0776854753494263e-01
    z[3,2,1]  R1574     -0.807357132434845
    z[3,2,1]  R1575     -8.0007779598236084e-01
    z[3,2,1]  R1576     -0.755072832107544
    z[3,2,1]  R1577     7.3512774705886841e-01
    z[3,2,1]  R1578     -6.8834644556045532e-01
    z[3,2,1]  R1579     1.4412263035774231e-01
    z[3,2,1]  R1580     -7.5586807727813721e-01
    z[3,2,1]  R1581     -7.2229963541030884e-01
    z[3,2,1]  R1582     1.0070722550153732e-01
    z[3,2,1]  R1583     1.9718358293175697e-02
    z[3,2,1]  R1584     1.5232196450233459e-01
    z[3,2,1]  R1585     2.2131569683551788e-01
    z[3,2,1]  R1586     0.0603828951716423
    z[3,2,1]  R1587     -2.1022692322731018e-02
    z[3,2,1]  R1588     1.4718034863471985e-01
    z[3,2,1]  R1589     -4.0034747123718262e-01
    z[3,2,1]  R1590     -6.0209697484970093e-01
    z[3,2,1]  R1591     -6.6832476854324341e-01
    z[3,2,1]  R1592     -1.7312319576740265e-01
    z[3,2,1]  R1593     -5.4768007993698120e-01
    z[3,2,1]  R1594     -4.1051355004310608e-01
    z[3,2,1]  R1595     -4.7652366757392883e-01
    z[3,2,1]  R1596     -3.5312104225158691e-01
    z[3,2,1]  R1597     -4.9516549706459045e-01
    z[3,2,1]  R1598     -1.2680651247501373e-01
    z[3,2,1]  R1599     5.8382898569107056e-01
    z[3,2,1]  R1600     6.0742568969726562e-01
    z[3,2,1]  R1601     1.7663152515888214e-01
    z[3,2,1]  R1602     3.5486739128828049e-02
    z[3,2,1]  R1603     -5.5451724678277969e-02
    z[3,2,1]  R1604     -1.2574690580368042e-01
    z[3,2,1]  R1605     3.8177499175071716e-01
    z[3,2,1]  R1606     2.3090101778507233e-01
    z[3,2,1]  R1607     4.3733924627304077e-01
    z[3,2,1]  R1608     5.9414225816726685e-01
    z[3,2,1]  R1609     7.4466150999069214e-01
    z[3,2,1]  R1610     -8.7734496593475342e-01
    z[3,2,1]  R1611     -8.5569155216217041e-01
    z[3,2,1]  R1612     -8.4874033927917480e-01
    z[3,2,1]  R1613     -8.4980607032775879e-01
    z[3,2,1]  R1614     -8.1663197278976440e-01
    z[3,2,1]  R1615     -9.0548592805862427e-01
    z[3,2,1]  R1616     -8.9221370220184326e-01
    z[3,2,1]  R1617     -8.9116054773330688e-01
    z[3,2,1]  R1618     -7.8599756956100464e-01
    z[3,2,1]  R1619     6.4114809036254883e-01
    z[3,2,1]  R1620     7.1110695600509644e-01
    z[3,2,1]  R1621     4.1350635886192322e-01
    z[3,2,1]  R1622     4.2939990758895874e-01
    z[3,2,1]  R1623     3.7744721770286560e-01
    z[3,2,1]  R1624     -8.3991122245788574e-01
    z[3,2,1]  R1625     -4.9871000647544861e-01
    z[3,2,1]  R1626     -6.9016766548156738e-01
    z[3,2,1]  R1627     -1.6022150218486786e-01
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1519     -1
    z[3,2,2]  R1520     1
    z[3,2,2]  R1529     -5.7450437545776367e-01
    z[3,2,2]  R1530     -5.4136312007904053e-01
    z[3,2,2]  R1531     -4.8270869255065918e-01
    z[3,2,2]  R1532     -6.6043287515640259e-01
    z[3,2,2]  R1533     1.9376932084560394e-01
    z[3,2,2]  R1534     -0.762722373008728
    z[3,2,2]  R1535     5.5558848381042480e-01
    z[3,2,2]  R1536     -5.3006899356842041e-01
    z[3,2,2]  R1537     1.7786386609077454e-01
    z[3,2,2]  R1538     3.8306677341461182e-01
    z[3,2,2]  R1539     1.2119157612323761e-01
    z[3,2,2]  R1540     -2.3542407155036926e-01
    z[3,2,2]  R1541     -7.2500328533351421e-03
    z[3,2,2]  R1542     -0.0172028299421072
    z[3,2,2]  R1543     2.1154652535915375e-01
    z[3,2,2]  R1544     8.4976553916931152e-02
    z[3,2,2]  R1545     -4.9993500113487244e-02
    z[3,2,2]  R1546     3.0862805247306824e-01
    z[3,2,2]  R1547     2.4009078741073608e-01
    z[3,2,2]  R1548     0.0586773082613945
    z[3,2,2]  R1549     2.2539477050304413e-01
    z[3,2,2]  R1550     1.4220415614545345e-02
    z[3,2,2]  R1551     -6.3256755471229553e-02
    z[3,2,2]  R1552     -1.6211499273777008e-01
    z[3,2,2]  R1553     -1.1996103823184967e-01
    z[3,2,2]  R1554     9.2876493930816650e-02
    z[3,2,2]  R1555     -4.4878937304019928e-02
    z[3,2,2]  R1556     3.0679382383823395e-02
    z[3,2,2]  R1557     1.7138579487800598e-01
    z[3,2,2]  R1558     8.4675490856170654e-02
    z[3,2,2]  R1559     1.3530911877751350e-02
    z[3,2,2]  R1560     2.7614161372184753e-01
    z[3,2,2]  R1561     -1.5526381134986877e-01
    z[3,2,2]  R1562     4.7609332203865051e-01
    z[3,2,2]  R1563     2.2000728547573090e-01
    z[3,2,2]  R1564     2.9708305001258850e-01
    z[3,2,2]  R1565     7.5209461152553558e-02
    z[3,2,2]  R1566     -1.4300939440727234e-01
    z[3,2,2]  R1567     1.3825416564941406e-01
    z[3,2,2]  R1568     5.0136047601699829e-01
    z[3,2,2]  R1569     1.3743334449827671e-02
    z[3,2,2]  R1570     -2.3087030649185181e-01
    z[3,2,2]  R1571     -2.7897748351097107e-01
    z[3,2,2]  R1572     -2.2459983825683594e-01
    z[3,2,2]  R1573     -0.21180360019207
    z[3,2,2]  R1574     -1.8946641683578491e-01
    z[3,2,2]  R1575     -1.6353523731231689e-01
    z[3,2,2]  R1576     -2.2070477902889252e-01
    z[3,2,2]  R1577     6.5782824531197548e-03
    z[3,2,2]  R1578     -3.8861316442489624e-01
    z[3,2,2]  R1579     1.6582390666007996e-01
    z[3,2,2]  R1580     -0.30942302942276
    z[3,2,2]  R1581     -2.1762351691722870e-01
    z[3,2,2]  R1582     3.2298988103866577e-01
    z[3,2,2]  R1583     6.7150115966796875e-02
    z[3,2,2]  R1584     4.4720417261123657e-01
    z[3,2,2]  R1585     4.0122170001268387e-02
    z[3,2,2]  R1586     1.4636841416358948e-01
    z[3,2,2]  R1587     1.9571933150291443e-01
    z[3,2,2]  R1588     1.6245013475418091e-01
    z[3,2,2]  R1589     2.7930381894111633e-01
    z[3,2,2]  R1590     2.6787906885147095e-01
    z[3,2,2]  R1591     3.8824307918548584e-01
    z[3,2,2]  R1592     5.2606755495071411e-01
    z[3,2,2]  R1593     2.9414427280426025e-01
    z[3,2,2]  R1594     3.2297840714454651e-01
    z[3,2,2]  R1595     3.0626228451728821e-01
    z[3,2,2]  R1596     2.0133000612258911e-01
    z[3,2,2]  R1597     5.0488901138305664e-01
    z[3,2,2]  R1598     5.7198160886764526e-01
    z[3,2,2]  R1599     -3.8364905118942261e-01
    z[3,2,2]  R1600     -6.2465769052505493e-01
    z[3,2,2]  R1601     -3.8598701357841492e-01
    z[3,2,2]  R1602     -8.0465242266654968e-02
    z[3,2,2]  R1603     -5.5144089460372925e-01
    z[3,2,2]  R1604     -4.8674494028091431e-01
    z[3,2,2]  R1605     -4.4633024930953979e-01
    z[3,2,2]  R1606     -1.2243931740522385e-01
    z[3,2,2]  R1607     -2.9714056849479675e-01
    z[3,2,2]  R1608     6.4323648810386658e-02
    z[3,2,2]  R1609     4.5305392146110535e-01
    z[3,2,2]  R1610     -0.0395146943628788
    z[3,2,2]  R1611     0.0572814904153347
    z[3,2,2]  R1612     9.0387947857379913e-02
    z[3,2,2]  R1613     9.6831507980823517e-02
    z[3,2,2]  R1614     -4.2133229970932007e-01
    z[3,2,2]  R1615     -2.3272365331649780e-01
    z[3,2,2]  R1616     -3.3689412474632263e-01
    z[3,2,2]  R1617     -2.7912008762359619e-01
    z[3,2,2]  R1618     2.3952837288379669e-01
    z[3,2,2]  R1619     -5.2558034658432007e-01
    z[3,2,2]  R1620     -3.7949335575103760e-01
    z[3,2,2]  R1621     -5.0442464649677277e-02
    z[3,2,2]  R1622     0.0793595239520073
    z[3,2,2]  R1623     -1.1186948418617249e-01
    z[3,2,2]  R1624     -2.4897256866097450e-02
    z[3,2,2]  R1625     2.4634398519992828e-01
    z[3,2,2]  R1626     3.8176274299621582e-01
    z[3,2,2]  R1627     2.1233913302421570e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1521     -1
    z[3,2,3]  R1522     1
    z[3,2,3]  R1529     -5.5182403326034546e-01
    z[3,2,3]  R1530     -2.5081974267959595e-01
    z[3,2,3]  R1531     -3.1413015723228455e-01
    z[3,2,3]  R1532     -5.4775989055633545e-01
    z[3,2,3]  R1533     -5.4104810953140259e-01
    z[3,2,3]  R1534     -1.3957542367279530e-02
    z[3,2,3]  R1535     -3.8215351104736328e-01
    z[3,2,3]  R1536     -2.6786011457443237e-01
    z[3,2,3]  R1537     -4.9451878666877747e-01
    z[3,2,3]  R1538     -6.1520993709564209e-01
    z[3,2,3]  R1539     1.1706600338220596e-01
    z[3,2,3]  R1540     1.7956618964672089e-01
    z[3,2,3]  R1541     2.1216855943202972e-01
    z[3,2,3]  R1542     5.1769173145294189e-01
    z[3,2,3]  R1543     6.4694148302078247e-01
    z[3,2,3]  R1544     6.5466111898422241e-01
    z[3,2,3]  R1545     -1.8238945305347443e-01
    z[3,2,3]  R1546     4.4153988361358643e-01
    z[3,2,3]  R1547     3.9338329434394836e-01
    z[3,2,3]  R1548     0.610335648059845
    z[3,2,3]  R1549     6.5426409244537354e-02
    z[3,2,3]  R1550     4.9048196524381638e-02
    z[3,2,3]  R1551     -3.0986478924751282e-01
    z[3,2,3]  R1552     -1.7784656584262848e-01
    z[3,2,3]  R1553     1.1586633324623108e-01
    z[3,2,3]  R1554     -1.1492399126291275e-01
    z[3,2,3]  R1555     -2.9630091786384583e-01
    z[3,2,3]  R1556     2.5218906998634338e-01
    z[3,2,3]  R1557     -4.9235463142395020e-02
    z[3,2,3]  R1558     2.7134326100349426e-01
    z[3,2,3]  R1559     4.4782254099845886e-01
    z[3,2,3]  R1560     2.7273058891296387e-01
    z[3,2,3]  R1561     4.8097413033246994e-02
    z[3,2,3]  R1562     -5.0844904035329819e-02
    z[3,2,3]  R1563     -2.6202961802482605e-01
    z[3,2,3]  R1564     -5.7135045528411865e-02
    z[3,2,3]  R1565     4.1552387177944183e-02
    z[3,2,3]  R1566     3.9916276931762695e-02
    z[3,2,3]  R1567     5.5593556165695190e-01
    z[3,2,3]  R1568     3.3694509416818619e-02
    z[3,2,3]  R1569     2.4267129600048065e-01
    z[3,2,3]  R1570     -2.9687255620956421e-01
    z[3,2,3]  R1571     4.6162612736225128e-02
    z[3,2,3]  R1572     1.0166615247726440e-02
    z[3,2,3]  R1573     -0.074288509786129
    z[3,2,3]  R1574     2.5950086116790771e-01
    z[3,2,3]  R1575     4.0295529365539551e-01
    z[3,2,3]  R1576     3.8861134648323059e-01
    z[3,2,3]  R1577     -4.7248327732086182e-01
    z[3,2,3]  R1578     9.4653815031051636e-02
    z[3,2,3]  R1579     -5.4831784963607788e-01
    z[3,2,3]  R1580     3.3024334907531738e-01
    z[3,2,3]  R1581     -4.7218668460845947e-01
    z[3,2,3]  R1582     3.7375611066818237e-01
    z[3,2,3]  R1583     2.7929738163948059e-01
    z[3,2,3]  R1584     9.5742210745811462e-02
    z[3,2,3]  R1585     3.8788342475891113e-01
    z[3,2,3]  R1586     1.6844633221626282e-01
    z[3,2,3]  R1587     3.8832414150238037e-01
    z[3,2,3]  R1588     2.2806464135646820e-01
    z[3,2,3]  R1589     3.3067500591278076e-01
    z[3,2,3]  R1590     9.6278652548789978e-02
    z[3,2,3]  R1591     1.2748534977436066e-01
    z[3,2,3]  R1592     3.3887475728988647e-01
    z[3,2,3]  R1593     5.7916469871997833e-02
    z[3,2,3]  R1594     1.9778871536254883e-01
    z[3,2,3]  R1595     2.0071412622928619e-01
    z[3,2,3]  R1596     6.0937386751174927e-01
    z[3,2,3]  R1597     3.7540411949157715e-01
    z[3,2,3]  R1598     1.9863419234752655e-01
    z[3,2,3]  R1599     1.9271922111511230e-01
    z[3,2,3]  R1600     -2.4844960868358612e-01
    z[3,2,3]  R1601     -5.9494799375534058e-01
    z[3,2,3]  R1602     -1.6164198517799377e-01
    z[3,2,3]  R1603     -4.6853333711624146e-01
    z[3,2,3]  R1604     -6.6356897354125977e-01
    z[3,2,3]  R1605     -5.4165536165237427e-01
    z[3,2,3]  R1606     -4.6803241968154907e-01
    z[3,2,3]  R1607     5.5928952991962433e-02
    z[3,2,3]  R1608     -4.2371249198913574e-01
    z[3,2,3]  R1609     -3.2224440574645996e-01
    z[3,2,3]  R1610     1.0479624569416046e-01
    z[3,2,3]  R1611     1.4834481477737427e-01
    z[3,2,3]  R1612     3.1913340091705322e-01
    z[3,2,3]  R1613     2.4048164486885071e-01
    z[3,2,3]  R1614     -7.8706553904339671e-04
    z[3,2,3]  R1615     -1.0655672103166580e-01
    z[3,2,3]  R1616     1.9051907584071159e-02
    z[3,2,3]  R1617     1.5867017209529877e-01
    z[3,2,3]  R1618     -2.9746058583259583e-01
    z[3,2,3]  R1619     -4.8250073194503784e-01
    z[3,2,3]  R1620     -2.4838294088840485e-01
    z[3,2,3]  R1621     3.1995039433240891e-02
    z[3,2,3]  R1622     3.0408254265785217e-01
    z[3,2,3]  R1623     -3.2031536102294922e-02
    z[3,2,3]  R1624     -3.9799782633781433e-01
    z[3,2,3]  R1625     -7.4008069932460785e-02
    z[3,2,3]  R1626     1.1232008039951324e-01
    z[3,2,3]  R1627     7.0545274019241333e-01
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1523     -1
    z[3,2,4]  R1524     1
    z[3,2,4]  R1529     3.8681440055370331e-02
    z[3,2,4]  R1530     -3.4683328866958618e-01
    z[3,2,4]  R1531     -3.0500268936157227e-01
    z[3,2,4]  R1532     4.3743055313825607e-02
    z[3,2,4]  R1533     1.3978804647922516e-01
    z[3,2,4]  R1534     -1.5404058992862701e-01
    z[3,2,4]  R1535     -0.0876581221818924
    z[3,2,4]  R1536     3.1593859195709229e-01
    z[3,2,4]  R1537     4.8961933702230453e-02
    z[3,2,4]  R1538     -1.2086918950080872e-01
    z[3,2,4]  R1539     -6.4705125987529755e-02
    z[3,2,4]  R1540     3.7865522503852844e-01
    z[3,2,4]  R1541     4.4442600011825562e-01
    z[3,2,4]  R1542     2.3144865036010742e-01
    z[3,2,4]  R1543     -2.1084553003311157e-01
    z[3,2,4]  R1544     1.6681958734989166e-01
    z[3,2,4]  R1545     -1.5593305230140686e-01
    z[3,2,4]  R1546     -0.275911420583725
    z[3,2,4]  R1547     -1.8377138674259186e-01
    z[3,2,4]  R1548     2.6651170849800110e-01
    z[3,2,4]  R1549     -1.0773171670734882e-03
    z[3,2,4]  R1550     -7.9781693220138550e-01
    z[3,2,4]  R1551     -5.2463328838348389e-01
    z[3,2,4]  R1552     -7.3747575283050537e-01
    z[3,2,4]  R1553     -4.4086609035730362e-02
    z[3,2,4]  R1554     1.6232788562774658e-01
    z[3,2,4]  R1555     3.2864493131637573e-01
    z[3,2,4]  R1556     2.0857295393943787e-01
    z[3,2,4]  R1557     0.376196026802063
    z[3,2,4]  R1558     -3.8204070925712585e-01
    z[3,2,4]  R1559     -2.7704018354415894e-01
    z[3,2,4]  R1560     -3.0748006701469421e-01
    z[3,2,4]  R1561     -2.4504117667675018e-01
    z[3,2,4]  R1562     1.9450557231903076e-01
    z[3,2,4]  R1563     -0.614127516746521
    z[3,2,4]  R1564     -4.1097548604011536e-01
    z[3,2,4]  R1565     1.3882963359355927e-01
    z[3,2,4]  R1566     -3.6934280395507812e-01
    z[3,2,4]  R1567     2.3542624711990356e-01
    z[3,2,4]  R1568     -2.0454618334770203e-01
    z[3,2,4]  R1569     -1.6884620487689972e-01
    z[3,2,4]  R1570     -6.3305526971817017e-01
    z[3,2,4]  R1571     -5.4552334547042847e-01
    z[3,2,4]  R1572     3.6771696805953979e-01
    z[3,2,4]  R1573     1.9974310696125031e-01
    z[3,2,4]  R1574     3.4017801284790039e-01
    z[3,2,4]  R1575     -2.6309159398078918e-01
    z[3,2,4]  R1576     2.5382652878761292e-02
    z[3,2,4]  R1577     -1.6438420116901398e-01
    z[3,2,4]  R1578     3.2526103314012289e-03
    z[3,2,4]  R1579     3.2445633411407471e-01
    z[3,2,4]  R1580     -1.4153721928596497e-01
    z[3,2,4]  R1581     -3.0477762222290039e-01
    z[3,2,4]  R1582     1.4489167928695679e-01
    z[3,2,4]  R1583     1.8020328879356384e-01
    z[3,2,4]  R1584     2.0290957391262054e-01
    z[3,2,4]  R1585     -6.0020685195922852e-02
    z[3,2,4]  R1586     3.7530052661895752e-01
    z[3,2,4]  R1587     1.0802821815013885e-01
    z[3,2,4]  R1588     1.0176397860050201e-01
    z[3,2,4]  R1589     1.5591309964656830e-01
    z[3,2,4]  R1590     3.3210579305887222e-02
    z[3,2,4]  R1591     3.2860311865806580e-01
    z[3,2,4]  R1592     2.3615252971649170e-01
    z[3,2,4]  R1593     2.7785533666610718e-01
    z[3,2,4]  R1594     5.7523810863494873e-01
    z[3,2,4]  R1595     0.505702555179596
    z[3,2,4]  R1596     1.4279535412788391e-01
    z[3,2,4]  R1597     4.5110586285591125e-01
    z[3,2,4]  R1598     5.5977356433868408e-01
    z[3,2,4]  R1599     -3.8477557897567749e-01
    z[3,2,4]  R1600     -9.1467574238777161e-02
    z[3,2,4]  R1601     2.3537762463092804e-01
    z[3,2,4]  R1602     5.7685323059558868e-02
    z[3,2,4]  R1603     -0.207729309797287
    z[3,2,4]  R1604     -4.6287890523672104e-02
    z[3,2,4]  R1605     2.6507401838898659e-02
    z[3,2,4]  R1606     2.2686150670051575e-01
    z[3,2,4]  R1607     -2.1972274780273438e-01
    z[3,2,4]  R1608     6.8991214036941528e-02
    z[3,2,4]  R1609     2.7227815985679626e-01
    z[3,2,4]  R1610     -4.2880597710609436e-01
    z[3,2,4]  R1611     -0.341124564409256
    z[3,2,4]  R1612     -5.3095526993274689e-02
    z[3,2,4]  R1613     -1.3309714198112488e-01
    z[3,2,4]  R1614     0.0838802382349968
    z[3,2,4]  R1615     9.1450840234756470e-02
    z[3,2,4]  R1616     -1.2955079972743988e-01
    z[3,2,4]  R1617     -1.3842868804931641e-01
    z[3,2,4]  R1618     2.5895136594772339e-01
    z[3,2,4]  R1619     -9.0126700699329376e-02
    z[3,2,4]  R1620     -2.3520599305629730e-01
    z[3,2,4]  R1621     -4.7348889708518982e-01
    z[3,2,4]  R1622     2.4419422447681427e-01
    z[3,2,4]  R1623     3.8060879707336426e-01
    z[3,2,4]  R1624     -1.5124662220478058e-01
    z[3,2,4]  R1625     1.5121409296989441e-01
    z[3,2,4]  R1626     4.3616327643394470e-01
    z[3,2,4]  R1627     -5.3156131505966187e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1525     -1
    z[3,2,5]  R1526     1
    z[3,2,5]  R1529     -1.3671287894248962e-01
    z[3,2,5]  R1530     5.4327660799026489e-01
    z[3,2,5]  R1531     2.7519872412085533e-02
    z[3,2,5]  R1532     -1.4023344218730927e-01
    z[3,2,5]  R1533     -6.8692475557327271e-02
    z[3,2,5]  R1534     1.1228796094655991e-02
    z[3,2,5]  R1535     -1.6981534659862518e-01
    z[3,2,5]  R1536     -5.6863898038864136e-01
    z[3,2,5]  R1537     -6.2710106372833252e-01
    z[3,2,5]  R1538     4.2931646108627319e-01
    z[3,2,5]  R1539     1.5785978734493256e-01
    z[3,2,5]  R1540     2.5563362240791321e-01
    z[3,2,5]  R1541     -0.317251980304718
    z[3,2,5]  R1542     0.415078729391098
    z[3,2,5]  R1543     -3.3079841732978821e-01
    z[3,2,5]  R1544     -3.9183324575424194e-01
    z[3,2,5]  R1545     1.9849547743797302e-01
    z[3,2,5]  R1546     2.5840106606483459e-01
    z[3,2,5]  R1547     -2.5410490110516548e-02
    z[3,2,5]  R1548     -1.7936001718044281e-01
    z[3,2,5]  R1549     3.9175990223884583e-01
    z[3,2,5]  R1550     6.6067695617675781e-02
    z[3,2,5]  R1551     7.2028040885925293e-01
    z[3,2,5]  R1552     4.3533289432525635e-01
    z[3,2,5]  R1553     4.0302121639251709e-01
    z[3,2,5]  R1554     3.1039389967918396e-01
    z[3,2,5]  R1555     8.8278248906135559e-02
    z[3,2,5]  R1556     3.7574744224548340e-01
    z[3,2,5]  R1557     1.4499436318874359e-01
    z[3,2,5]  R1558     -5.1070624589920044e-01
    z[3,2,5]  R1559     -2.2779320180416107e-01
    z[3,2,5]  R1560     4.5578092336654663e-02
    z[3,2,5]  R1561     -5.8653438091278076e-01
    z[3,2,5]  R1562     -4.6099528670310974e-01
    z[3,2,5]  R1563     -7.5132623314857483e-02
    z[3,2,5]  R1564     -2.4239070713520050e-01
    z[3,2,5]  R1565     -3.3351576328277588e-01
    z[3,2,5]  R1566     -3.1046655774116516e-01
    z[3,2,5]  R1567     -2.9368317127227783e-01
    z[3,2,5]  R1568     1.9626735150814056e-01
    z[3,2,5]  R1569     -1.4469853043556213e-01
    z[3,2,5]  R1570     -5.5544916540384293e-02
    z[3,2,5]  R1571     4.6312987804412842e-01
    z[3,2,5]  R1572     2.5895142927765846e-02
    z[3,2,5]  R1573     2.1338342130184174e-01
    z[3,2,5]  R1574     8.5565216839313507e-02
    z[3,2,5]  R1575     0.0840703547000885
    z[3,2,5]  R1576     -3.4614598751068115e-01
    z[3,2,5]  R1577     6.1836522072553635e-02
    z[3,2,5]  R1578     -1.8361641466617584e-01
    z[3,2,5]  R1579     3.1850022077560425e-01
    z[3,2,5]  R1580     -1.7846895754337311e-01
    z[3,2,5]  R1581     2.1995152533054352e-01
    z[3,2,5]  R1582     -3.9587166160345078e-02
    z[3,2,5]  R1583     -3.2489750534296036e-02
    z[3,2,5]  R1584     0.263158917427063
    z[3,2,5]  R1585     -2.4518856778740883e-02
    z[3,2,5]  R1586     7.6157540082931519e-02
    z[3,2,5]  R1587     2.9837989807128906e-01
    z[3,2,5]  R1588     2.2120243310928345e-01
    z[3,2,5]  R1589     -2.6245030760765076e-01
    z[3,2,5]  R1590     -0.0670199990272522
    z[3,2,5]  R1591     -2.4436776340007782e-01
    z[3,2,5]  R1592     3.6630305647850037e-01
    z[3,2,5]  R1593     -2.6340955495834351e-01
    z[3,2,5]  R1594     -9.4148583710193634e-02
    z[3,2,5]  R1595     -3.4305401146411896e-02
    z[3,2,5]  R1596     1.6856788098812103e-01
    z[3,2,5]  R1597     -5.0172898918390274e-02
    z[3,2,5]  R1598     9.5535710453987122e-02
    z[3,2,5]  R1599     -2.5173571705818176e-01
    z[3,2,5]  R1600     -3.9147889614105225e-01
    z[3,2,5]  R1601     5.3077928721904755e-02
    z[3,2,5]  R1602     -9.2946678400039673e-02
    z[3,2,5]  R1603     9.7296662628650665e-02
    z[3,2,5]  R1604     -9.6086002886295319e-02
    z[3,2,5]  R1605     -4.2067468166351318e-01
    z[3,2,5]  R1606     -5.5732220411300659e-01
    z[3,2,5]  R1607     -9.7770117223262787e-02
    z[3,2,5]  R1608     -1.1749976128339767e-01
    z[3,2,5]  R1609     2.3909299075603485e-01
    z[3,2,5]  R1610     -2.1298358216881752e-02
    z[3,2,5]  R1611     -2.9836791753768921e-01
    z[3,2,5]  R1612     -1.0847450233995914e-02
    z[3,2,5]  R1613     3.6222180724143982e-01
    z[3,2,5]  R1614     -2.8392225503921509e-01
    z[3,2,5]  R1615     -3.4298751503229141e-02
    z[3,2,5]  R1616     -0.0587601400911808
    z[3,2,5]  R1617     5.3964339196681976e-02
    z[3,2,5]  R1618     3.1064370274543762e-01
    z[3,2,5]  R1619     -4.3982222676277161e-02
    z[3,2,5]  R1620     3.9665651321411133e-01
    z[3,2,5]  R1621     5.3600388765335083e-01
    z[3,2,5]  R1622     -5.4437303543090820e-01
    z[3,2,5]  R1623     -4.8453959822654724e-01
    z[3,2,5]  R1624     -2.4696022272109985e-01
    z[3,2,5]  R1625     1.7080970108509064e-01
    z[3,2,5]  R1626     -0.337971568107605
    z[3,2,5]  R1627     1.9546246528625488e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1527     -1
    z[3,2,6]  R1528     1
    z[3,2,6]  R1529     4.6168902516365051e-01
    z[3,2,6]  R1530     1.1097563803195953e-01
    z[3,2,6]  R1531     4.7059124708175659e-01
    z[3,2,6]  R1532     -1.1967720836400986e-01
    z[3,2,6]  R1533     5.3260743618011475e-01
    z[3,2,6]  R1534     3.1857562065124512e-01
    z[3,2,6]  R1535     1.5946796536445618e-01
    z[3,2,6]  R1536     2.4550843983888626e-02
    z[3,2,6]  R1537     4.2538964748382568e-01
    z[3,2,6]  R1538     -1.3276237249374390e-01
    z[3,2,6]  R1539     8.8356077671051025e-02
    z[3,2,6]  R1540     -0.0882168561220169
    z[3,2,6]  R1541     -2.5562165305018425e-02
    z[3,2,6]  R1542     -6.6741362214088440e-02
    z[3,2,6]  R1543     2.3195805028080940e-02
    z[3,2,6]  R1544     2.4579038843512535e-02
    z[3,2,6]  R1545     -3.8156315684318542e-01
    z[3,2,6]  R1546     -3.5968831181526184e-01
    z[3,2,6]  R1547     1.0943107306957245e-01
    z[3,2,6]  R1548     1.7770607769489288e-01
    z[3,2,6]  R1549     -3.1654992699623108e-01
    z[3,2,6]  R1550     -1.9747292995452881e-01
    z[3,2,6]  R1551     -1.3896332681179047e-01
    z[3,2,6]  R1552     5.6087784469127655e-02
    z[3,2,6]  R1553     -0.0659722089767456
    z[3,2,6]  R1554     -2.3645015060901642e-01
    z[3,2,6]  R1555     8.7271459400653839e-02
    z[3,2,6]  R1556     -2.1435341238975525e-01
    z[3,2,6]  R1557     1.7312683165073395e-01
    z[3,2,6]  R1558     4.4121686369180679e-02
    z[3,2,6]  R1559     2.3863058537244797e-02
    z[3,2,6]  R1560     3.4006141126155853e-02
    z[3,2,6]  R1561     3.3906292170286179e-02
    z[3,2,6]  R1562     -1.3650478422641754e-01
    z[3,2,6]  R1563     -3.2864677906036377e-01
    z[3,2,6]  R1564     -4.4955067336559296e-02
    z[3,2,6]  R1565     -4.1292348504066467e-01
    z[3,2,6]  R1566     -2.2485366463661194e-01
    z[3,2,6]  R1567     2.6155945658683777e-01
    z[3,2,6]  R1568     -1.4395545423030853e-01
    z[3,2,6]  R1569     -2.0372359454631805e-01
    z[3,2,6]  R1570     -2.5405132770538330e-01
    z[3,2,6]  R1571     -8.4806688129901886e-02
    z[3,2,6]  R1572     -1.4791491627693176e-01
    z[3,2,6]  R1573     -1.5384469926357269e-01
    z[3,2,6]  R1574     -1.2967227399349213e-01
    z[3,2,6]  R1575     3.0735993385314941e-01
    z[3,2,6]  R1576     2.7324759867042303e-03
    z[3,2,6]  R1577     -2.9068564996123314e-02
    z[3,2,6]  R1578     5.2781653404235840e-01
    z[3,2,6]  R1579     -2.3362050950527191e-01
    z[3,2,6]  R1580     1.3652274012565613e-01
    z[3,2,6]  R1581     4.8345115035772324e-02
    z[3,2,6]  R1582     9.5223180949687958e-02
    z[3,2,6]  R1583     4.2157445102930069e-02
    z[3,2,6]  R1584     5.9282500296831131e-03
    z[3,2,6]  R1585     -1.5103885531425476e-01
    z[3,2,6]  R1586     -3.9183810353279114e-02
    z[3,2,6]  R1587     -0.0802641361951828
    z[3,2,6]  R1588     -4.7107253223657608e-02
    z[3,2,6]  R1589     -4.6458251774311066e-02
    z[3,2,6]  R1590     1.8408608436584473e-01
    z[3,2,6]  R1591     2.6160009205341339e-02
    z[3,2,6]  R1592     7.8310193493962288e-03
    z[3,2,6]  R1593     9.1239757835865021e-02
    z[3,2,6]  R1594     -0.0608413964509964
    z[3,2,6]  R1595     3.1286141276359558e-01
    z[3,2,6]  R1596     6.4555965363979340e-02
    z[3,2,6]  R1597     2.9393553733825684e-01
    z[3,2,6]  R1598     1.7758828401565552e-01
    z[3,2,6]  R1599     5.1203376054763794e-01
    z[3,2,6]  R1600     -4.1345804929733276e-02
    z[3,2,6]  R1601     -7.9316355288028717e-02
    z[3,2,6]  R1602     3.1014952063560486e-01
    z[3,2,6]  R1603     4.7311067581176758e-01
    z[3,2,6]  R1604     4.0797162055969238e-01
    z[3,2,6]  R1605     1.3117515482008457e-02
    z[3,2,6]  R1606     3.9898250252008438e-02
    z[3,2,6]  R1607     2.5561091303825378e-01
    z[3,2,6]  R1608     0.303884357213974
    z[3,2,6]  R1609     -1.4541435521095991e-03
    z[3,2,6]  R1610     -1.3916519284248352e-01
    z[3,2,6]  R1611     -1.6364848613739014e-01
    z[3,2,6]  R1612     2.7841567993164062e-01
    z[3,2,6]  R1613     6.2870927155017853e-02
    z[3,2,6]  R1614     -1.7144758999347687e-01
    z[3,2,6]  R1615     2.7778929471969604e-01
    z[3,2,6]  R1616     2.5665801763534546e-01
    z[3,2,6]  R1617     -2.6609787344932556e-01
    z[3,2,6]  R1618     2.6930475234985352e-01
    z[3,2,6]  R1619     1.8482415378093719e-01
    z[3,2,6]  R1620     2.4370370432734489e-02
    z[3,2,6]  R1621     -3.8140645623207092e-01
    z[3,2,6]  R1622     -4.3413665890693665e-01
    z[3,2,6]  R1623     1.0922961682081223e-01
    z[3,2,6]  R1624     -1.5183512866497040e-01
    z[3,2,6]  R1625     -7.2895568609237671e-01
    z[3,2,6]  R1626     1.7387457191944122e-01
    z[3,2,6]  R1627     -2.4548269808292389e-01
    z[2,7,0]  R20       -1
    z[2,7,0]  R65       1
    z[2,7,0]  R1628     -1
    z[2,7,0]  R1629     1
    z[2,7,0]  R1642     7.4633646011352539e-01
    z[2,7,0]  R1643     7.1900504827499390e-01
    z[2,7,0]  R1644     4.6687984466552734e-01
    z[2,7,0]  R1645     6.2324780225753784e-01
    z[2,7,0]  R1646     0.674728512763977
    z[2,7,0]  R1647     5.8700817823410034e-01
    z[2,7,0]  R1648     5.3296184539794922e-01
    z[2,7,0]  R1649     6.4067316055297852e-01
    z[2,7,0]  R1650     2.5798881053924561e-01
    z[2,7,0]  R1651     0.51311856508255
    z[2,7,0]  R1652     3.4854099154472351e-02
    z[2,7,0]  R1653     1.2561009824275970e-01
    z[2,7,0]  R1654     -6.3351500034332275e-01
    z[2,7,0]  R1655     -9.2627131938934326e-01
    z[2,7,0]  R1656     -4.4369208812713623e-01
    z[2,7,0]  R1657     -3.5934317111968994e-01
    z[2,7,0]  R1658     -4.2872470617294312e-01
    z[2,7,0]  R1659     -5.9073930978775024e-01
    z[2,7,0]  R1660     -7.7080458402633667e-01
    z[2,7,0]  R1661     -5.9364432096481323e-01
    z[2,7,0]  R1662     7.1253530681133270e-02
    z[2,7,0]  R1663     -1.1843587458133698e-01
    z[2,7,0]  R1664     -1.0165821760892868e-01
    z[2,7,0]  R1665     -2.9861640930175781e-01
    z[2,7,0]  R1666     -2.4031141400337219e-01
    z[2,7,0]  R1667     -1.9633817672729492e-01
    z[2,7,0]  R1668     -1.6695541143417358e-01
    z[2,7,0]  R1669     6.3124731183052063e-02
    z[2,7,0]  R1670     -9.9326990544795990e-02
    z[2,7,0]  R1671     1.6456462442874908e-02
    z[2,7,0]  R1672     1.8886549770832062e-01
    z[2,7,0]  R1673     -2.7452784776687622e-01
    z[2,7,0]  R1674     4.1046494245529175e-01
    z[2,7,0]  R1675     -4.1521570086479187e-01
    z[2,7,0]  R1676     -6.7262166738510132e-01
    z[2,7,0]  R1677     1.6913972795009613e-01
    z[2,7,0]  R1678     3.1891646981239319e-01
    z[2,7,0]  R1679     -1.7496973276138306e-01
    z[2,7,0]  R1680     2.2483965754508972e-01
    z[2,7,0]  R1681     -5.5066294968128204e-02
    z[2,7,0]  R1682     -5.4952509701251984e-02
    z[2,7,0]  R1683     -1.3514424860477448e-01
    z[2,7,0]  R1684     -2.0544309914112091e-01
    z[2,7,0]  R1685     -3.3502045273780823e-01
    z[2,7,0]  R1686     3.9353778958320618e-01
    z[2,7,0]  R1687     -3.9055220782756805e-02
    z[2,7,0]  R1688     0.0508398562669754
    z[2,7,0]  R1689     7.3907065391540527e-01
    z[2,7,0]  R1690     4.8043563961982727e-01
    z[2,7,0]  R1691     -8.2265603542327881e-01
    z[2,7,0]  R1692     -8.5410159826278687e-01
    z[2,7,0]  R1693     -7.0194125175476074e-01
    z[2,7,0]  R1694     -7.8165721893310547e-01
    z[2,7,0]  R1695     -9.0683442354202271e-01
    z[2,7,0]  R1696     -1.5419508516788483e-01
    z[2,7,0]  R1697     0.0777321606874466
    z[2,7,0]  R1698     4.1521093249320984e-01
    z[2,7,0]  R1699     3.1091028451919556e-01
    z[2,7,0]  R1700     2.6029297709465027e-01
    z[2,7,0]  R1701     1.7411856353282928e-01
    z[2,7,0]  R1702     2.8291067481040955e-01
    z[2,7,0]  R1703     2.3529216647148132e-01
    z[2,7,0]  R1704     5.3404539823532104e-02
    z[2,7,0]  R1705     4.6603572368621826e-01
    z[2,7,0]  R1706     0.563897967338562
    z[2,7,0]  R1707     3.7199625372886658e-01
    z[2,7,0]  R1708     3.0794638395309448e-01
    z[2,7,0]  R1709     2.9737782478332520e-01
    z[2,7,0]  R1710     6.5450179576873779e-01
    z[2,7,1]  R21       -1
    z[2,7,1]  R66       1
    z[2,7,1]  R1630     -1
    z[2,7,1]  R1631     1
    z[2,7,1]  R1642     -4.0034747123718262e-01
    z[2,7,1]  R1643     -6.0209697484970093e-01
    z[2,7,1]  R1644     -6.6832476854324341e-01
    z[2,7,1]  R1645     -1.7312319576740265e-01
    z[2,7,1]  R1646     -5.4768007993698120e-01
    z[2,7,1]  R1647     -4.1051355004310608e-01
    z[2,7,1]  R1648     -4.7652366757392883e-01
    z[2,7,1]  R1649     -3.5312104225158691e-01
    z[2,7,1]  R1650     -4.9516549706459045e-01
    z[2,7,1]  R1651     -1.2680651247501373e-01
    z[2,7,1]  R1652     5.8382898569107056e-01
    z[2,7,1]  R1653     6.0742568969726562e-01
    z[2,7,1]  R1654     1.7663152515888214e-01
    z[2,7,1]  R1655     3.5486739128828049e-02
    z[2,7,1]  R1656     -5.5451724678277969e-02
    z[2,7,1]  R1657     -1.2574690580368042e-01
    z[2,7,1]  R1658     3.8177499175071716e-01
    z[2,7,1]  R1659     2.3090101778507233e-01
    z[2,7,1]  R1660     4.3733924627304077e-01
    z[2,7,1]  R1661     5.9414225816726685e-01
    z[2,7,1]  R1662     7.4466150999069214e-01
    z[2,7,1]  R1663     -8.7734496593475342e-01
    z[2,7,1]  R1664     -8.5569155216217041e-01
    z[2,7,1]  R1665     -8.4874033927917480e-01
    z[2,7,1]  R1666     -8.4980607032775879e-01
    z[2,7,1]  R1667     -8.1663197278976440e-01
    z[2,7,1]  R1668     -9.0548592805862427e-01
    z[2,7,1]  R1669     -8.9221370220184326e-01
    z[2,7,1]  R1670     -8.9116054773330688e-01
    z[2,7,1]  R1671     -7.8599756956100464e-01
    z[2,7,1]  R1672     6.4114809036254883e-01
    z[2,7,1]  R1673     7.1110695600509644e-01
    z[2,7,1]  R1674     4.1350635886192322e-01
    z[2,7,1]  R1675     4.2939990758895874e-01
    z[2,7,1]  R1676     3.7744721770286560e-01
    z[2,7,1]  R1677     -8.3991122245788574e-01
    z[2,7,1]  R1678     -4.9871000647544861e-01
    z[2,7,1]  R1679     -6.9016766548156738e-01
    z[2,7,1]  R1680     -1.6022150218486786e-01
    z[2,7,1]  R1681     -0.743045449256897
    z[2,7,1]  R1682     -7.4928855895996094e-01
    z[2,7,1]  R1683     -7.2837853431701660e-01
    z[2,7,1]  R1684     -7.0721590518951416e-01
    z[2,7,1]  R1685     -7.0768111944198608e-01
    z[2,7,1]  R1686     -6.8114686012268066e-01
    z[2,7,1]  R1687     -6.6867059469223022e-01
    z[2,7,1]  R1688     -5.9756278991699219e-01
    z[2,7,1]  R1689     -5.9231704473495483e-01
    z[2,7,1]  R1690     -5.1949393749237061e-01
    z[2,7,1]  R1691     1.4352588355541229e-01
    z[2,7,1]  R1692     1.7586836218833923e-01
    z[2,7,1]  R1693     4.2263475060462952e-01
    z[2,7,1]  R1694     2.6250369846820831e-02
    z[2,7,1]  R1695     -1.4274181798100471e-02
    z[2,7,1]  R1696     3.5868328809738159e-01
    z[2,7,1]  R1697     8.4278291463851929e-01
    z[2,7,1]  R1698     6.1004316806793213e-01
    z[2,7,1]  R1699     6.5526819229125977e-01
    z[2,7,1]  R1700     6.4741140604019165e-01
    z[2,7,1]  R1701     0.793921172618866
    z[2,7,1]  R1702     6.9187086820602417e-01
    z[2,7,1]  R1703     7.2983145713806152e-01
    z[2,7,1]  R1704     7.1048659086227417e-01
    z[2,7,1]  R1705     7.0828109979629517e-01
    z[2,7,1]  R1706     6.3068258762359619e-01
    z[2,7,1]  R1707     7.3375660181045532e-01
    z[2,7,1]  R1708     6.5386146306991577e-01
    z[2,7,1]  R1709     6.2505561113357544e-01
    z[2,7,1]  R1710     2.6948049664497375e-01
    z[2,7,2]  R22       -1
    z[2,7,2]  R67       1
    z[2,7,2]  R1632     -1
    z[2,7,2]  R1633     1
    z[2,7,2]  R1642     2.7930381894111633e-01
    z[2,7,2]  R1643     2.6787906885147095e-01
    z[2,7,2]  R1644     3.8824307918548584e-01
    z[2,7,2]  R1645     5.2606755495071411e-01
    z[2,7,2]  R1646     2.9414427280426025e-01
    z[2,7,2]  R1647     3.2297840714454651e-01
    z[2,7,2]  R1648     3.0626228451728821e-01
    z[2,7,2]  R1649     2.0133000612258911e-01
    z[2,7,2]  R1650     5.0488901138305664e-01
    z[2,7,2]  R1651     5.7198160886764526e-01
    z[2,7,2]  R1652     -3.8364905118942261e-01
    z[2,7,2]  R1653     -6.2465769052505493e-01
    z[2,7,2]  R1654     -3.8598701357841492e-01
    z[2,7,2]  R1655     -8.0465242266654968e-02
    z[2,7,2]  R1656     -5.5144089460372925e-01
    z[2,7,2]  R1657     -4.8674494028091431e-01
    z[2,7,2]  R1658     -4.4633024930953979e-01
    z[2,7,2]  R1659     -1.2243931740522385e-01
    z[2,7,2]  R1660     -2.9714056849479675e-01
    z[2,7,2]  R1661     6.4323648810386658e-02
    z[2,7,2]  R1662     4.5305392146110535e-01
    z[2,7,2]  R1663     -0.0395146943628788
    z[2,7,2]  R1664     0.0572814904153347
    z[2,7,2]  R1665     9.0387947857379913e-02
    z[2,7,2]  R1666     9.6831507980823517e-02
    z[2,7,2]  R1667     -4.2133229970932007e-01
    z[2,7,2]  R1668     -2.3272365331649780e-01
    z[2,7,2]  R1669     -3.3689412474632263e-01
    z[2,7,2]  R1670     -2.7912008762359619e-01
    z[2,7,2]  R1671     2.3952837288379669e-01
    z[2,7,2]  R1672     -5.2558034658432007e-01
    z[2,7,2]  R1673     -3.7949335575103760e-01
    z[2,7,2]  R1674     -5.0442464649677277e-02
    z[2,7,2]  R1675     0.0793595239520073
    z[2,7,2]  R1676     -1.1186948418617249e-01
    z[2,7,2]  R1677     -2.4897256866097450e-02
    z[2,7,2]  R1678     2.4634398519992828e-01
    z[2,7,2]  R1679     3.8176274299621582e-01
    z[2,7,2]  R1680     2.1233913302421570e-01
    z[2,7,2]  R1681     -0.0832938700914383
    z[2,7,2]  R1682     7.8313037753105164e-02
    z[2,7,2]  R1683     1.8474750220775604e-01
    z[2,7,2]  R1684     1.7942178249359131e-01
    z[2,7,2]  R1685     -1.0637225210666656e-01
    z[2,7,2]  R1686     -4.5578071475028992e-01
    z[2,7,2]  R1687     1.4830625057220459e-01
    z[2,7,2]  R1688     -1.3196821324527264e-02
    z[2,7,2]  R1689     1.0675847530364990e-01
    z[2,7,2]  R1690     -2.0281404256820679e-02
    z[2,7,2]  R1691     -3.2566487789154053e-01
    z[2,7,2]  R1692     -0.0940450057387352
    z[2,7,2]  R1693     -4.0577489882707596e-02
    z[2,7,2]  R1694     -4.8938649892807007e-01
    z[2,7,2]  R1695     -7.5737267732620239e-02
    z[2,7,2]  R1696     -4.7218307852745056e-01
    z[2,7,2]  R1697     2.2482825815677643e-01
    z[2,7,2]  R1698     4.6637746691703796e-01
    z[2,7,2]  R1699     5.5652713775634766e-01
    z[2,7,2]  R1700     4.3382686376571655e-01
    z[2,7,2]  R1701     5.7313352823257446e-01
    z[2,7,2]  R1702     -3.0905985832214355e-01
    z[2,7,2]  R1703     -0.466251939535141
    z[2,7,2]  R1704     -8.3113173022866249e-03
    z[2,7,2]  R1705     1.0023440234363079e-02
    z[2,7,2]  R1706     0.0632082000374794
    z[2,7,2]  R1707     -2.7546146512031555e-01
    z[2,7,2]  R1708     -6.0453660786151886e-02
    z[2,7,2]  R1709     0.0542115643620491
    z[2,7,2]  R1710     1.9810880720615387e-01
    z[2,7,3]  R23       -1
    z[2,7,3]  R68       1
    z[2,7,3]  R1634     -1
    z[2,7,3]  R1635     1
    z[2,7,3]  R1642     3.3067500591278076e-01
    z[2,7,3]  R1643     9.6278652548789978e-02
    z[2,7,3]  R1644     1.2748534977436066e-01
    z[2,7,3]  R1645     3.3887475728988647e-01
    z[2,7,3]  R1646     5.7916469871997833e-02
    z[2,7,3]  R1647     1.9778871536254883e-01
    z[2,7,3]  R1648     2.0071412622928619e-01
    z[2,7,3]  R1649     6.0937386751174927e-01
    z[2,7,3]  R1650     3.7540411949157715e-01
    z[2,7,3]  R1651     1.9863419234752655e-01
    z[2,7,3]  R1652     1.9271922111511230e-01
    z[2,7,3]  R1653     -2.4844960868358612e-01
    z[2,7,3]  R1654     -5.9494799375534058e-01
    z[2,7,3]  R1655     -1.6164198517799377e-01
    z[2,7,3]  R1656     -4.6853333711624146e-01
    z[2,7,3]  R1657     -6.6356897354125977e-01
    z[2,7,3]  R1658     -5.4165536165237427e-01
    z[2,7,3]  R1659     -4.6803241968154907e-01
    z[2,7,3]  R1660     5.5928952991962433e-02
    z[2,7,3]  R1661     -4.2371249198913574e-01
    z[2,7,3]  R1662     -3.2224440574645996e-01
    z[2,7,3]  R1663     1.0479624569416046e-01
    z[2,7,3]  R1664     1.4834481477737427e-01
    z[2,7,3]  R1665     3.1913340091705322e-01
    z[2,7,3]  R1666     2.4048164486885071e-01
    z[2,7,3]  R1667     -7.8706553904339671e-04
    z[2,7,3]  R1668     -1.0655672103166580e-01
    z[2,7,3]  R1669     1.9051907584071159e-02
    z[2,7,3]  R1670     1.5867017209529877e-01
    z[2,7,3]  R1671     -2.9746058583259583e-01
    z[2,7,3]  R1672     -4.8250073194503784e-01
    z[2,7,3]  R1673     -2.4838294088840485e-01
    z[2,7,3]  R1674     3.1995039433240891e-02
    z[2,7,3]  R1675     3.0408254265785217e-01
    z[2,7,3]  R1676     -3.2031536102294922e-02
    z[2,7,3]  R1677     -3.9799782633781433e-01
    z[2,7,3]  R1678     -7.4008069932460785e-02
    z[2,7,3]  R1679     1.1232008039951324e-01
    z[2,7,3]  R1680     7.0545274019241333e-01
    z[2,7,3]  R1681     -5.3115785121917725e-01
    z[2,7,3]  R1682     -0.517676055431366
    z[2,7,3]  R1683     -4.5510104298591614e-01
    z[2,7,3]  R1684     1.4501862227916718e-01
    z[2,7,3]  R1685     5.4367440938949585e-01
    z[2,7,3]  R1686     -1.2788806855678558e-01
    z[2,7,3]  R1687     -2.4055039882659912e-01
    z[2,7,3]  R1688     -2.2824862599372864e-01
    z[2,7,3]  R1689     -2.6141172274947166e-02
    z[2,7,3]  R1690     0.362593412399292
    z[2,7,3]  R1691     -3.7873315811157227e-01
    z[2,7,3]  R1692     -3.8320377469062805e-01
    z[2,7,3]  R1693     -3.0686238408088684e-01
    z[2,7,3]  R1694     -1.0967943817377090e-02
    z[2,7,3]  R1695     8.8958166539669037e-02
    z[2,7,3]  R1696     -7.3784607648849487e-01
    z[2,7,3]  R1697     -1.4718878269195557e-01
    z[2,7,3]  R1698     -2.7771508693695068e-01
    z[2,7,3]  R1699     -3.1631910800933838e-01
    z[2,7,3]  R1700     -9.4376482069492340e-02
    z[2,7,3]  R1701     -2.9263095930218697e-03
    z[2,7,3]  R1702     2.9952365159988403e-01
    z[2,7,3]  R1703     3.1823712587356567e-01
    z[2,7,3]  R1704     5.2354931831359863e-01
    z[2,7,3]  R1705     -2.7067307382822037e-02
    z[2,7,3]  R1706     2.8740158677101135e-01
    z[2,7,3]  R1707     3.9176261425018311e-01
    z[2,7,3]  R1708     1.5172840654850006e-01
    z[2,7,3]  R1709     1.9516982138156891e-01
    z[2,7,3]  R1710     4.9416700005531311e-01
    z[2,7,4]  R24       -1
    z[2,7,4]  R69       1
    z[2,7,4]  R1636     -1
    z[2,7,4]  R1637     1
    z[2,7,4]  R1642     1.5591309964656830e-01
    z[2,7,4]  R1643     3.3210579305887222e-02
    z[2,7,4]  R1644     3.2860311865806580e-01
    z[2,7,4]  R1645     2.3615252971649170e-01
    z[2,7,4]  R1646     2.7785533666610718e-01
    z[2,7,4]  R1647     5.7523810863494873e-01
    z[2,7,4]  R1648     0.505702555179596
    z[2,7,4]  R1649     1.4279535412788391e-01
    z[2,7,4]  R1650     4.5110586285591125e-01
    z[2,7,4]  R1651     5.5977356433868408e-01
    z[2,7,4]  R1652     -3.8477557897567749e-01
    z[2,7,4]  R1653     -9.1467574238777161e-02
    z[2,7,4]  R1654     2.3537762463092804e-01
    z[2,7,4]  R1655     5.7685323059558868e-02
    z[2,7,4]  R1656     -0.207729309797287
    z[2,7,4]  R1657     -4.6287890523672104e-02
    z[2,7,4]  R1658     2.6507401838898659e-02
    z[2,7,4]  R1659     2.2686150670051575e-01
    z[2,7,4]  R1660     -2.1972274780273438e-01
    z[2,7,4]  R1661     6.8991214036941528e-02
    z[2,7,4]  R1662     2.7227815985679626e-01
    z[2,7,4]  R1663     -4.2880597710609436e-01
    z[2,7,4]  R1664     -0.341124564409256
    z[2,7,4]  R1665     -5.3095526993274689e-02
    z[2,7,4]  R1666     -1.3309714198112488e-01
    z[2,7,4]  R1667     0.0838802382349968
    z[2,7,4]  R1668     9.1450840234756470e-02
    z[2,7,4]  R1669     -1.2955079972743988e-01
    z[2,7,4]  R1670     -1.3842868804931641e-01
    z[2,7,4]  R1671     2.5895136594772339e-01
    z[2,7,4]  R1672     -9.0126700699329376e-02
    z[2,7,4]  R1673     -2.3520599305629730e-01
    z[2,7,4]  R1674     -4.7348889708518982e-01
    z[2,7,4]  R1675     2.4419422447681427e-01
    z[2,7,4]  R1676     3.8060879707336426e-01
    z[2,7,4]  R1677     -1.5124662220478058e-01
    z[2,7,4]  R1678     1.5121409296989441e-01
    z[2,7,4]  R1679     4.3616327643394470e-01
    z[2,7,4]  R1680     -5.3156131505966187e-01
    z[2,7,4]  R1681     2.0416952669620514e-01
    z[2,7,4]  R1682     3.3035805821418762e-01
    z[2,7,4]  R1683     -1.7304044961929321e-01
    z[2,7,4]  R1684     4.3810001015663147e-01
    z[2,7,4]  R1685     -2.5421399623155594e-02
    z[2,7,4]  R1686     2.4416697025299072e-01
    z[2,7,4]  R1687     -6.8618965148925781e-01
    z[2,7,4]  R1688     -1.9128118455410004e-01
    z[2,7,4]  R1689     1.0645785182714462e-01
    z[2,7,4]  R1690     1.9151549041271210e-01
    z[2,7,4]  R1691     -9.5341891050338745e-02
    z[2,7,4]  R1692     -2.3639196529984474e-02
    z[2,7,4]  R1693     -2.1149487793445587e-01
    z[2,7,4]  R1694     5.1366519182920456e-02
    z[2,7,4]  R1695     -7.3919579386711121e-02
    z[2,7,4]  R1696     8.4743246436119080e-02
    z[2,7,4]  R1697     -1.3100887835025787e-01
    z[2,7,4]  R1698     -3.0006036162376404e-01
    z[2,7,4]  R1699     5.8689940720796585e-02
    z[2,7,4]  R1700     1.6048046946525574e-01
    z[2,7,4]  R1701     -3.9442688226699829e-02
    z[2,7,4]  R1702     3.7176007032394409e-01
    z[2,7,4]  R1703     2.0438171923160553e-01
    z[2,7,4]  R1704     4.1999229788780212e-01
    z[2,7,4]  R1705     4.3914774060249329e-01
    z[2,7,4]  R1706     3.6389192938804626e-01
    z[2,7,4]  R1707     1.3818424940109253e-01
    z[2,7,4]  R1708     0.651690661907196
    z[2,7,4]  R1709     2.8211387991905212e-01
    z[2,7,4]  R1710     -1.8998704850673676e-01
    z[2,7,5]  R25       -1
    z[2,7,5]  R70       1
    z[2,7,5]  R1638     -1
    z[2,7,5]  R1639     1
    z[2,7,5]  R1642     -2.6245030760765076e-01
    z[2,7,5]  R1643     -0.0670199990272522
    z[2,7,5]  R1644     -2.4436776340007782e-01
    z[2,7,5]  R1645     3.6630305647850037e-01
    z[2,7,5]  R1646     -2.6340955495834351e-01
    z[2,7,5]  R1647     -9.4148583710193634e-02
    z[2,7,5]  R1648     -3.4305401146411896e-02
    z[2,7,5]  R1649     1.6856788098812103e-01
    z[2,7,5]  R1650     -5.0172898918390274e-02
    z[2,7,5]  R1651     9.5535710453987122e-02
    z[2,7,5]  R1652     -2.5173571705818176e-01
    z[2,7,5]  R1653     -3.9147889614105225e-01
    z[2,7,5]  R1654     5.3077928721904755e-02
    z[2,7,5]  R1655     -9.2946678400039673e-02
    z[2,7,5]  R1656     9.7296662628650665e-02
    z[2,7,5]  R1657     -9.6086002886295319e-02
    z[2,7,5]  R1658     -4.2067468166351318e-01
    z[2,7,5]  R1659     -5.5732220411300659e-01
    z[2,7,5]  R1660     -9.7770117223262787e-02
    z[2,7,5]  R1661     -1.1749976128339767e-01
    z[2,7,5]  R1662     2.3909299075603485e-01
    z[2,7,5]  R1663     -2.1298358216881752e-02
    z[2,7,5]  R1664     -2.9836791753768921e-01
    z[2,7,5]  R1665     -1.0847450233995914e-02
    z[2,7,5]  R1666     3.6222180724143982e-01
    z[2,7,5]  R1667     -2.8392225503921509e-01
    z[2,7,5]  R1668     -3.4298751503229141e-02
    z[2,7,5]  R1669     -0.0587601400911808
    z[2,7,5]  R1670     5.3964339196681976e-02
    z[2,7,5]  R1671     3.1064370274543762e-01
    z[2,7,5]  R1672     -4.3982222676277161e-02
    z[2,7,5]  R1673     3.9665651321411133e-01
    z[2,7,5]  R1674     5.3600388765335083e-01
    z[2,7,5]  R1675     -5.4437303543090820e-01
    z[2,7,5]  R1676     -4.8453959822654724e-01
    z[2,7,5]  R1677     -2.4696022272109985e-01
    z[2,7,5]  R1678     1.7080970108509064e-01
    z[2,7,5]  R1679     -0.337971568107605
    z[2,7,5]  R1680     1.9546246528625488e-01
    z[2,7,5]  R1681     3.3638903498649597e-01
    z[2,7,5]  R1682     -1.9399334490299225e-01
    z[2,7,5]  R1683     6.7884378135204315e-02
    z[2,7,5]  R1684     4.1109851002693176e-01
    z[2,7,5]  R1685     -2.6039877533912659e-01
    z[2,7,5]  R1686     -0.304644912481308
    z[2,7,5]  R1687     -1.0937741026282310e-02
    z[2,7,5]  R1688     -7.4050599336624146e-01
    z[2,7,5]  R1689     -2.4446092545986176e-01
    z[2,7,5]  R1690     1.9868181645870209e-01
    z[2,7,5]  R1691     1.9656149670481682e-02
    z[2,7,5]  R1692     -2.7998128533363342e-01
    z[2,7,5]  R1693     2.9966005682945251e-01
    z[2,7,5]  R1694     3.5412353277206421e-01
    z[2,7,5]  R1695     0.386221319437027
    z[2,7,5]  R1696     -4.7760433517396450e-03
    z[2,7,5]  R1697     -2.2735865414142609e-01
    z[2,7,5]  R1698     2.6579296588897705e-01
    z[2,7,5]  R1699     2.4337849020957947e-01
    z[2,7,5]  R1700     4.2711076140403748e-01
    z[2,7,5]  R1701     -9.5728859305381775e-02
    z[2,7,5]  R1702     3.1036314368247986e-01
    z[2,7,5]  R1703     2.1151506900787354e-01
    z[2,7,5]  R1704     1.7396314442157745e-01
    z[2,7,5]  R1705     1.3783389329910278e-01
    z[2,7,5]  R1706     1.6777409613132477e-01
    z[2,7,5]  R1707     -0.27127605676651
    z[2,7,5]  R1708     -1.8786061555147171e-02
    z[2,7,5]  R1709     -1.1283921450376511e-01
    z[2,7,5]  R1710     -1.6121678054332733e-01
    z[2,7,6]  R26       -1
    z[2,7,6]  R71       1
    z[2,7,6]  R1640     -1
    z[2,7,6]  R1641     1
    z[2,7,6]  R1642     -4.6458251774311066e-02
    z[2,7,6]  R1643     1.8408608436584473e-01
    z[2,7,6]  R1644     2.6160009205341339e-02
    z[2,7,6]  R1645     7.8310193493962288e-03
    z[2,7,6]  R1646     9.1239757835865021e-02
    z[2,7,6]  R1647     -0.0608413964509964
    z[2,7,6]  R1648     3.1286141276359558e-01
    z[2,7,6]  R1649     6.4555965363979340e-02
    z[2,7,6]  R1650     2.9393553733825684e-01
    z[2,7,6]  R1651     1.7758828401565552e-01
    z[2,7,6]  R1652     5.1203376054763794e-01
    z[2,7,6]  R1653     -4.1345804929733276e-02
    z[2,7,6]  R1654     -7.9316355288028717e-02
    z[2,7,6]  R1655     3.1014952063560486e-01
    z[2,7,6]  R1656     4.7311067581176758e-01
    z[2,7,6]  R1657     4.0797162055969238e-01
    z[2,7,6]  R1658     1.3117515482008457e-02
    z[2,7,6]  R1659     3.9898250252008438e-02
    z[2,7,6]  R1660     2.5561091303825378e-01
    z[2,7,6]  R1661     0.303884357213974
    z[2,7,6]  R1662     -1.4541435521095991e-03
    z[2,7,6]  R1663     -1.3916519284248352e-01
    z[2,7,6]  R1664     -1.6364848613739014e-01
    z[2,7,6]  R1665     2.7841567993164062e-01
    z[2,7,6]  R1666     6.2870927155017853e-02
    z[2,7,6]  R1667     -1.7144758999347687e-01
    z[2,7,6]  R1668     2.7778929471969604e-01
    z[2,7,6]  R1669     2.5665801763534546e-01
    z[2,7,6]  R1670     -2.6609787344932556e-01
    z[2,7,6]  R1671     2.6930475234985352e-01
    z[2,7,6]  R1672     1.8482415378093719e-01
    z[2,7,6]  R1673     2.4370370432734489e-02
    z[2,7,6]  R1674     -3.8140645623207092e-01
    z[2,7,6]  R1675     -4.3413665890693665e-01
    z[2,7,6]  R1676     1.0922961682081223e-01
    z[2,7,6]  R1677     -1.5183512866497040e-01
    z[2,7,6]  R1678     -7.2895568609237671e-01
    z[2,7,6]  R1679     1.7387457191944122e-01
    z[2,7,6]  R1680     -2.4548269808292389e-01
    z[2,7,6]  R1681     -3.0690962448716164e-02
    z[2,7,6]  R1682     -1.2106040120124817e-01
    z[2,7,6]  R1683     4.1880896687507629e-01
    z[2,7,6]  R1684     2.0852467417716980e-01
    z[2,7,6]  R1685     -1.0769448429346085e-01
    z[2,7,6]  R1686     -6.8187125027179718e-02
    z[2,7,6]  R1687     -2.2787373512983322e-02
    z[2,7,6]  R1688     -5.5900763720273972e-02
    z[2,7,6]  R1689     1.4057008922100067e-01
    z[2,7,6]  R1690     5.3969401121139526e-01
    z[2,7,6]  R1691     2.0896056294441223e-01
    z[2,7,6]  R1692     0.0703059658408165
    z[2,7,6]  R1693     -3.1356176733970642e-01
    z[2,7,6]  R1694     -1.4374145865440369e-01
    z[2,7,6]  R1695     9.5743931829929352e-02
    z[2,7,6]  R1696     -2.7017101645469666e-01
    z[2,7,6]  R1697     0.377633661031723
    z[2,7,6]  R1698     1.1471087113022804e-02
    z[2,7,6]  R1699     -3.8736443966627121e-02
    z[2,7,6]  R1700     3.2835307717323303e-01
    z[2,7,6]  R1701     1.2709383852779865e-02
    z[2,7,6]  R1702     -1.4667297899723053e-01
    z[2,7,6]  R1703     8.2507297396659851e-02
    z[2,7,6]  R1704     1.0736383497714996e-01
    z[2,7,6]  R1705     -2.6166132092475891e-01
    z[2,7,6]  R1706     -1.9260872900485992e-01
    z[2,7,6]  R1707     -3.4314379096031189e-02
    z[2,7,6]  R1708     1.6094848513603210e-01
    z[2,7,6]  R1709     -6.2251168489456177e-01
    z[2,7,6]  R1710     -3.9175704121589661e-01
    z[7,2,0]  R20       1
    z[7,2,0]  R65       -1
    z[7,2,0]  R1711     -1
    z[7,2,0]  R1712     1
    z[7,2,0]  R1725     -5.5066294968128204e-02
    z[7,2,0]  R1726     -5.4952509701251984e-02
    z[7,2,0]  R1727     -1.3514424860477448e-01
    z[7,2,0]  R1728     -2.0544309914112091e-01
    z[7,2,0]  R1729     -3.3502045273780823e-01
    z[7,2,0]  R1730     3.9353778958320618e-01
    z[7,2,0]  R1731     -3.9055220782756805e-02
    z[7,2,0]  R1732     0.0508398562669754
    z[7,2,0]  R1733     7.3907065391540527e-01
    z[7,2,0]  R1734     4.8043563961982727e-01
    z[7,2,0]  R1735     -8.2265603542327881e-01
    z[7,2,0]  R1736     -8.5410159826278687e-01
    z[7,2,0]  R1737     -7.0194125175476074e-01
    z[7,2,0]  R1738     -7.8165721893310547e-01
    z[7,2,0]  R1739     -9.0683442354202271e-01
    z[7,2,0]  R1740     -1.5419508516788483e-01
    z[7,2,0]  R1741     0.0777321606874466
    z[7,2,0]  R1742     4.1521093249320984e-01
    z[7,2,0]  R1743     3.1091028451919556e-01
    z[7,2,0]  R1744     2.6029297709465027e-01
    z[7,2,0]  R1745     1.7411856353282928e-01
    z[7,2,0]  R1746     2.8291067481040955e-01
    z[7,2,0]  R1747     2.3529216647148132e-01
    z[7,2,0]  R1748     5.3404539823532104e-02
    z[7,2,0]  R1749     4.6603572368621826e-01
    z[7,2,0]  R1750     0.563897967338562
    z[7,2,0]  R1751     3.7199625372886658e-01
    z[7,2,0]  R1752     3.0794638395309448e-01
    z[7,2,0]  R1753     2.9737782478332520e-01
    z[7,2,0]  R1754     6.5450179576873779e-01
    z[7,2,0]  R1755     7.4633646011352539e-01
    z[7,2,0]  R1756     7.1900504827499390e-01
    z[7,2,0]  R1757     4.6687984466552734e-01
    z[7,2,0]  R1758     6.2324780225753784e-01
    z[7,2,0]  R1759     0.674728512763977
    z[7,2,0]  R1760     5.8700817823410034e-01
    z[7,2,0]  R1761     5.3296184539794922e-01
    z[7,2,0]  R1762     6.4067316055297852e-01
    z[7,2,0]  R1763     2.5798881053924561e-01
    z[7,2,0]  R1764     0.51311856508255
    z[7,2,0]  R1765     3.4854099154472351e-02
    z[7,2,0]  R1766     1.2561009824275970e-01
    z[7,2,0]  R1767     -6.3351500034332275e-01
    z[7,2,0]  R1768     -9.2627131938934326e-01
    z[7,2,0]  R1769     -4.4369208812713623e-01
    z[7,2,0]  R1770     -3.5934317111968994e-01
    z[7,2,0]  R1771     -4.2872470617294312e-01
    z[7,2,0]  R1772     -5.9073930978775024e-01
    z[7,2,0]  R1773     -7.7080458402633667e-01
    z[7,2,0]  R1774     -5.9364432096481323e-01
    z[7,2,0]  R1775     7.1253530681133270e-02
    z[7,2,0]  R1776     -1.1843587458133698e-01
    z[7,2,0]  R1777     -1.0165821760892868e-01
    z[7,2,0]  R1778     -2.9861640930175781e-01
    z[7,2,0]  R1779     -2.4031141400337219e-01
    z[7,2,0]  R1780     -1.9633817672729492e-01
    z[7,2,0]  R1781     -1.6695541143417358e-01
    z[7,2,0]  R1782     6.3124731183052063e-02
    z[7,2,0]  R1783     -9.9326990544795990e-02
    z[7,2,0]  R1784     1.6456462442874908e-02
    z[7,2,0]  R1785     1.8886549770832062e-01
    z[7,2,0]  R1786     -2.7452784776687622e-01
    z[7,2,0]  R1787     4.1046494245529175e-01
    z[7,2,0]  R1788     -4.1521570086479187e-01
    z[7,2,0]  R1789     -6.7262166738510132e-01
    z[7,2,0]  R1790     1.6913972795009613e-01
    z[7,2,0]  R1791     3.1891646981239319e-01
    z[7,2,0]  R1792     -1.7496973276138306e-01
    z[7,2,0]  R1793     2.2483965754508972e-01
    z[7,2,1]  R21       1
    z[7,2,1]  R66       -1
    z[7,2,1]  R1713     -1
    z[7,2,1]  R1714     1
    z[7,2,1]  R1725     -0.743045449256897
    z[7,2,1]  R1726     -7.4928855895996094e-01
    z[7,2,1]  R1727     -7.2837853431701660e-01
    z[7,2,1]  R1728     -7.0721590518951416e-01
    z[7,2,1]  R1729     -7.0768111944198608e-01
    z[7,2,1]  R1730     -6.8114686012268066e-01
    z[7,2,1]  R1731     -6.6867059469223022e-01
    z[7,2,1]  R1732     -5.9756278991699219e-01
    z[7,2,1]  R1733     -5.9231704473495483e-01
    z[7,2,1]  R1734     -5.1949393749237061e-01
    z[7,2,1]  R1735     1.4352588355541229e-01
    z[7,2,1]  R1736     1.7586836218833923e-01
    z[7,2,1]  R1737     4.2263475060462952e-01
    z[7,2,1]  R1738     2.6250369846820831e-02
    z[7,2,1]  R1739     -1.4274181798100471e-02
    z[7,2,1]  R1740     3.5868328809738159e-01
    z[7,2,1]  R1741     8.4278291463851929e-01
    z[7,2,1]  R1742     6.1004316806793213e-01
    z[7,2,1]  R1743     6.5526819229125977e-01
    z[7,2,1]  R1744     6.4741140604019165e-01
    z[7,2,1]  R1745     0.793921172618866
    z[7,2,1]  R1746     6.9187086820602417e-01
    z[7,2,1]  R1747     7.2983145713806152e-01
    z[7,2,1]  R1748     7.1048659086227417e-01
    z[7,2,1]  R1749     7.0828109979629517e-01
    z[7,2,1]  R1750     6.3068258762359619e-01
    z[7,2,1]  R1751     7.3375660181045532e-01
    z[7,2,1]  R1752     6.5386146306991577e-01
    z[7,2,1]  R1753     6.2505561113357544e-01
    z[7,2,1]  R1754     2.6948049664497375e-01
    z[7,2,1]  R1755     -4.0034747123718262e-01
    z[7,2,1]  R1756     -6.0209697484970093e-01
    z[7,2,1]  R1757     -6.6832476854324341e-01
    z[7,2,1]  R1758     -1.7312319576740265e-01
    z[7,2,1]  R1759     -5.4768007993698120e-01
    z[7,2,1]  R1760     -4.1051355004310608e-01
    z[7,2,1]  R1761     -4.7652366757392883e-01
    z[7,2,1]  R1762     -3.5312104225158691e-01
    z[7,2,1]  R1763     -4.9516549706459045e-01
    z[7,2,1]  R1764     -1.2680651247501373e-01
    z[7,2,1]  R1765     5.8382898569107056e-01
    z[7,2,1]  R1766     6.0742568969726562e-01
    z[7,2,1]  R1767     1.7663152515888214e-01
    z[7,2,1]  R1768     3.5486739128828049e-02
    z[7,2,1]  R1769     -5.5451724678277969e-02
    z[7,2,1]  R1770     -1.2574690580368042e-01
    z[7,2,1]  R1771     3.8177499175071716e-01
    z[7,2,1]  R1772     2.3090101778507233e-01
    z[7,2,1]  R1773     4.3733924627304077e-01
    z[7,2,1]  R1774     5.9414225816726685e-01
    z[7,2,1]  R1775     7.4466150999069214e-01
    z[7,2,1]  R1776     -8.7734496593475342e-01
    z[7,2,1]  R1777     -8.5569155216217041e-01
    z[7,2,1]  R1778     -8.4874033927917480e-01
    z[7,2,1]  R1779     -8.4980607032775879e-01
    z[7,2,1]  R1780     -8.1663197278976440e-01
    z[7,2,1]  R1781     -9.0548592805862427e-01
    z[7,2,1]  R1782     -8.9221370220184326e-01
    z[7,2,1]  R1783     -8.9116054773330688e-01
    z[7,2,1]  R1784     -7.8599756956100464e-01
    z[7,2,1]  R1785     6.4114809036254883e-01
    z[7,2,1]  R1786     7.1110695600509644e-01
    z[7,2,1]  R1787     4.1350635886192322e-01
    z[7,2,1]  R1788     4.2939990758895874e-01
    z[7,2,1]  R1789     3.7744721770286560e-01
    z[7,2,1]  R1790     -8.3991122245788574e-01
    z[7,2,1]  R1791     -4.9871000647544861e-01
    z[7,2,1]  R1792     -6.9016766548156738e-01
    z[7,2,1]  R1793     -1.6022150218486786e-01
    z[7,2,2]  R22       1
    z[7,2,2]  R67       -1
    z[7,2,2]  R1715     -1
    z[7,2,2]  R1716     1
    z[7,2,2]  R1725     -0.0832938700914383
    z[7,2,2]  R1726     7.8313037753105164e-02
    z[7,2,2]  R1727     1.8474750220775604e-01
    z[7,2,2]  R1728     1.7942178249359131e-01
    z[7,2,2]  R1729     -1.0637225210666656e-01
    z[7,2,2]  R1730     -4.5578071475028992e-01
    z[7,2,2]  R1731     1.4830625057220459e-01
    z[7,2,2]  R1732     -1.3196821324527264e-02
    z[7,2,2]  R1733     1.0675847530364990e-01
    z[7,2,2]  R1734     -2.0281404256820679e-02
    z[7,2,2]  R1735     -3.2566487789154053e-01
    z[7,2,2]  R1736     -0.0940450057387352
    z[7,2,2]  R1737     -4.0577489882707596e-02
    z[7,2,2]  R1738     -4.8938649892807007e-01
    z[7,2,2]  R1739     -7.5737267732620239e-02
    z[7,2,2]  R1740     -4.7218307852745056e-01
    z[7,2,2]  R1741     2.2482825815677643e-01
    z[7,2,2]  R1742     4.6637746691703796e-01
    z[7,2,2]  R1743     5.5652713775634766e-01
    z[7,2,2]  R1744     4.3382686376571655e-01
    z[7,2,2]  R1745     5.7313352823257446e-01
    z[7,2,2]  R1746     -3.0905985832214355e-01
    z[7,2,2]  R1747     -0.466251939535141
    z[7,2,2]  R1748     -8.3113173022866249e-03
    z[7,2,2]  R1749     1.0023440234363079e-02
    z[7,2,2]  R1750     0.0632082000374794
    z[7,2,2]  R1751     -2.7546146512031555e-01
    z[7,2,2]  R1752     -6.0453660786151886e-02
    z[7,2,2]  R1753     0.0542115643620491
    z[7,2,2]  R1754     1.9810880720615387e-01
    z[7,2,2]  R1755     2.7930381894111633e-01
    z[7,2,2]  R1756     2.6787906885147095e-01
    z[7,2,2]  R1757     3.8824307918548584e-01
    z[7,2,2]  R1758     5.2606755495071411e-01
    z[7,2,2]  R1759     2.9414427280426025e-01
    z[7,2,2]  R1760     3.2297840714454651e-01
    z[7,2,2]  R1761     3.0626228451728821e-01
    z[7,2,2]  R1762     2.0133000612258911e-01
    z[7,2,2]  R1763     5.0488901138305664e-01
    z[7,2,2]  R1764     5.7198160886764526e-01
    z[7,2,2]  R1765     -3.8364905118942261e-01
    z[7,2,2]  R1766     -6.2465769052505493e-01
    z[7,2,2]  R1767     -3.8598701357841492e-01
    z[7,2,2]  R1768     -8.0465242266654968e-02
    z[7,2,2]  R1769     -5.5144089460372925e-01
    z[7,2,2]  R1770     -4.8674494028091431e-01
    z[7,2,2]  R1771     -4.4633024930953979e-01
    z[7,2,2]  R1772     -1.2243931740522385e-01
    z[7,2,2]  R1773     -2.9714056849479675e-01
    z[7,2,2]  R1774     6.4323648810386658e-02
    z[7,2,2]  R1775     4.5305392146110535e-01
    z[7,2,2]  R1776     -0.0395146943628788
    z[7,2,2]  R1777     0.0572814904153347
    z[7,2,2]  R1778     9.0387947857379913e-02
    z[7,2,2]  R1779     9.6831507980823517e-02
    z[7,2,2]  R1780     -4.2133229970932007e-01
    z[7,2,2]  R1781     -2.3272365331649780e-01
    z[7,2,2]  R1782     -3.3689412474632263e-01
    z[7,2,2]  R1783     -2.7912008762359619e-01
    z[7,2,2]  R1784     2.3952837288379669e-01
    z[7,2,2]  R1785     -5.2558034658432007e-01
    z[7,2,2]  R1786     -3.7949335575103760e-01
    z[7,2,2]  R1787     -5.0442464649677277e-02
    z[7,2,2]  R1788     0.0793595239520073
    z[7,2,2]  R1789     -1.1186948418617249e-01
    z[7,2,2]  R1790     -2.4897256866097450e-02
    z[7,2,2]  R1791     2.4634398519992828e-01
    z[7,2,2]  R1792     3.8176274299621582e-01
    z[7,2,2]  R1793     2.1233913302421570e-01
    z[7,2,3]  R23       1
    z[7,2,3]  R68       -1
    z[7,2,3]  R1717     -1
    z[7,2,3]  R1718     1
    z[7,2,3]  R1725     -5.3115785121917725e-01
    z[7,2,3]  R1726     -0.517676055431366
    z[7,2,3]  R1727     -4.5510104298591614e-01
    z[7,2,3]  R1728     1.4501862227916718e-01
    z[7,2,3]  R1729     5.4367440938949585e-01
    z[7,2,3]  R1730     -1.2788806855678558e-01
    z[7,2,3]  R1731     -2.4055039882659912e-01
    z[7,2,3]  R1732     -2.2824862599372864e-01
    z[7,2,3]  R1733     -2.6141172274947166e-02
    z[7,2,3]  R1734     0.362593412399292
    z[7,2,3]  R1735     -3.7873315811157227e-01
    z[7,2,3]  R1736     -3.8320377469062805e-01
    z[7,2,3]  R1737     -3.0686238408088684e-01
    z[7,2,3]  R1738     -1.0967943817377090e-02
    z[7,2,3]  R1739     8.8958166539669037e-02
    z[7,2,3]  R1740     -7.3784607648849487e-01
    z[7,2,3]  R1741     -1.4718878269195557e-01
    z[7,2,3]  R1742     -2.7771508693695068e-01
    z[7,2,3]  R1743     -3.1631910800933838e-01
    z[7,2,3]  R1744     -9.4376482069492340e-02
    z[7,2,3]  R1745     -2.9263095930218697e-03
    z[7,2,3]  R1746     2.9952365159988403e-01
    z[7,2,3]  R1747     3.1823712587356567e-01
    z[7,2,3]  R1748     5.2354931831359863e-01
    z[7,2,3]  R1749     -2.7067307382822037e-02
    z[7,2,3]  R1750     2.8740158677101135e-01
    z[7,2,3]  R1751     3.9176261425018311e-01
    z[7,2,3]  R1752     1.5172840654850006e-01
    z[7,2,3]  R1753     1.9516982138156891e-01
    z[7,2,3]  R1754     4.9416700005531311e-01
    z[7,2,3]  R1755     3.3067500591278076e-01
    z[7,2,3]  R1756     9.6278652548789978e-02
    z[7,2,3]  R1757     1.2748534977436066e-01
    z[7,2,3]  R1758     3.3887475728988647e-01
    z[7,2,3]  R1759     5.7916469871997833e-02
    z[7,2,3]  R1760     1.9778871536254883e-01
    z[7,2,3]  R1761     2.0071412622928619e-01
    z[7,2,3]  R1762     6.0937386751174927e-01
    z[7,2,3]  R1763     3.7540411949157715e-01
    z[7,2,3]  R1764     1.9863419234752655e-01
    z[7,2,3]  R1765     1.9271922111511230e-01
    z[7,2,3]  R1766     -2.4844960868358612e-01
    z[7,2,3]  R1767     -5.9494799375534058e-01
    z[7,2,3]  R1768     -1.6164198517799377e-01
    z[7,2,3]  R1769     -4.6853333711624146e-01
    z[7,2,3]  R1770     -6.6356897354125977e-01
    z[7,2,3]  R1771     -5.4165536165237427e-01
    z[7,2,3]  R1772     -4.6803241968154907e-01
    z[7,2,3]  R1773     5.5928952991962433e-02
    z[7,2,3]  R1774     -4.2371249198913574e-01
    z[7,2,3]  R1775     -3.2224440574645996e-01
    z[7,2,3]  R1776     1.0479624569416046e-01
    z[7,2,3]  R1777     1.4834481477737427e-01
    z[7,2,3]  R1778     3.1913340091705322e-01
    z[7,2,3]  R1779     2.4048164486885071e-01
    z[7,2,3]  R1780     -7.8706553904339671e-04
    z[7,2,3]  R1781     -1.0655672103166580e-01
    z[7,2,3]  R1782     1.9051907584071159e-02
    z[7,2,3]  R1783     1.5867017209529877e-01
    z[7,2,3]  R1784     -2.9746058583259583e-01
    z[7,2,3]  R1785     -4.8250073194503784e-01
    z[7,2,3]  R1786     -2.4838294088840485e-01
    z[7,2,3]  R1787     3.1995039433240891e-02
    z[7,2,3]  R1788     3.0408254265785217e-01
    z[7,2,3]  R1789     -3.2031536102294922e-02
    z[7,2,3]  R1790     -3.9799782633781433e-01
    z[7,2,3]  R1791     -7.4008069932460785e-02
    z[7,2,3]  R1792     1.1232008039951324e-01
    z[7,2,3]  R1793     7.0545274019241333e-01
    z[7,2,4]  R24       1
    z[7,2,4]  R69       -1
    z[7,2,4]  R1719     -1
    z[7,2,4]  R1720     1
    z[7,2,4]  R1725     2.0416952669620514e-01
    z[7,2,4]  R1726     3.3035805821418762e-01
    z[7,2,4]  R1727     -1.7304044961929321e-01
    z[7,2,4]  R1728     4.3810001015663147e-01
    z[7,2,4]  R1729     -2.5421399623155594e-02
    z[7,2,4]  R1730     2.4416697025299072e-01
    z[7,2,4]  R1731     -6.8618965148925781e-01
    z[7,2,4]  R1732     -1.9128118455410004e-01
    z[7,2,4]  R1733     1.0645785182714462e-01
    z[7,2,4]  R1734     1.9151549041271210e-01
    z[7,2,4]  R1735     -9.5341891050338745e-02
    z[7,2,4]  R1736     -2.3639196529984474e-02
    z[7,2,4]  R1737     -2.1149487793445587e-01
    z[7,2,4]  R1738     5.1366519182920456e-02
    z[7,2,4]  R1739     -7.3919579386711121e-02
    z[7,2,4]  R1740     8.4743246436119080e-02
    z[7,2,4]  R1741     -1.3100887835025787e-01
    z[7,2,4]  R1742     -3.0006036162376404e-01
    z[7,2,4]  R1743     5.8689940720796585e-02
    z[7,2,4]  R1744     1.6048046946525574e-01
    z[7,2,4]  R1745     -3.9442688226699829e-02
    z[7,2,4]  R1746     3.7176007032394409e-01
    z[7,2,4]  R1747     2.0438171923160553e-01
    z[7,2,4]  R1748     4.1999229788780212e-01
    z[7,2,4]  R1749     4.3914774060249329e-01
    z[7,2,4]  R1750     3.6389192938804626e-01
    z[7,2,4]  R1751     1.3818424940109253e-01
    z[7,2,4]  R1752     0.651690661907196
    z[7,2,4]  R1753     2.8211387991905212e-01
    z[7,2,4]  R1754     -1.8998704850673676e-01
    z[7,2,4]  R1755     1.5591309964656830e-01
    z[7,2,4]  R1756     3.3210579305887222e-02
    z[7,2,4]  R1757     3.2860311865806580e-01
    z[7,2,4]  R1758     2.3615252971649170e-01
    z[7,2,4]  R1759     2.7785533666610718e-01
    z[7,2,4]  R1760     5.7523810863494873e-01
    z[7,2,4]  R1761     0.505702555179596
    z[7,2,4]  R1762     1.4279535412788391e-01
    z[7,2,4]  R1763     4.5110586285591125e-01
    z[7,2,4]  R1764     5.5977356433868408e-01
    z[7,2,4]  R1765     -3.8477557897567749e-01
    z[7,2,4]  R1766     -9.1467574238777161e-02
    z[7,2,4]  R1767     2.3537762463092804e-01
    z[7,2,4]  R1768     5.7685323059558868e-02
    z[7,2,4]  R1769     -0.207729309797287
    z[7,2,4]  R1770     -4.6287890523672104e-02
    z[7,2,4]  R1771     2.6507401838898659e-02
    z[7,2,4]  R1772     2.2686150670051575e-01
    z[7,2,4]  R1773     -2.1972274780273438e-01
    z[7,2,4]  R1774     6.8991214036941528e-02
    z[7,2,4]  R1775     2.7227815985679626e-01
    z[7,2,4]  R1776     -4.2880597710609436e-01
    z[7,2,4]  R1777     -0.341124564409256
    z[7,2,4]  R1778     -5.3095526993274689e-02
    z[7,2,4]  R1779     -1.3309714198112488e-01
    z[7,2,4]  R1780     0.0838802382349968
    z[7,2,4]  R1781     9.1450840234756470e-02
    z[7,2,4]  R1782     -1.2955079972743988e-01
    z[7,2,4]  R1783     -1.3842868804931641e-01
    z[7,2,4]  R1784     2.5895136594772339e-01
    z[7,2,4]  R1785     -9.0126700699329376e-02
    z[7,2,4]  R1786     -2.3520599305629730e-01
    z[7,2,4]  R1787     -4.7348889708518982e-01
    z[7,2,4]  R1788     2.4419422447681427e-01
    z[7,2,4]  R1789     3.8060879707336426e-01
    z[7,2,4]  R1790     -1.5124662220478058e-01
    z[7,2,4]  R1791     1.5121409296989441e-01
    z[7,2,4]  R1792     4.3616327643394470e-01
    z[7,2,4]  R1793     -5.3156131505966187e-01
    z[7,2,5]  R25       1
    z[7,2,5]  R70       -1
    z[7,2,5]  R1721     -1
    z[7,2,5]  R1722     1
    z[7,2,5]  R1725     3.3638903498649597e-01
    z[7,2,5]  R1726     -1.9399334490299225e-01
    z[7,2,5]  R1727     6.7884378135204315e-02
    z[7,2,5]  R1728     4.1109851002693176e-01
    z[7,2,5]  R1729     -2.6039877533912659e-01
    z[7,2,5]  R1730     -0.304644912481308
    z[7,2,5]  R1731     -1.0937741026282310e-02
    z[7,2,5]  R1732     -7.4050599336624146e-01
    z[7,2,5]  R1733     -2.4446092545986176e-01
    z[7,2,5]  R1734     1.9868181645870209e-01
    z[7,2,5]  R1735     1.9656149670481682e-02
    z[7,2,5]  R1736     -2.7998128533363342e-01
    z[7,2,5]  R1737     2.9966005682945251e-01
    z[7,2,5]  R1738     3.5412353277206421e-01
    z[7,2,5]  R1739     0.386221319437027
    z[7,2,5]  R1740     -4.7760433517396450e-03
    z[7,2,5]  R1741     -2.2735865414142609e-01
    z[7,2,5]  R1742     2.6579296588897705e-01
    z[7,2,5]  R1743     2.4337849020957947e-01
    z[7,2,5]  R1744     4.2711076140403748e-01
    z[7,2,5]  R1745     -9.5728859305381775e-02
    z[7,2,5]  R1746     3.1036314368247986e-01
    z[7,2,5]  R1747     2.1151506900787354e-01
    z[7,2,5]  R1748     1.7396314442157745e-01
    z[7,2,5]  R1749     1.3783389329910278e-01
    z[7,2,5]  R1750     1.6777409613132477e-01
    z[7,2,5]  R1751     -0.27127605676651
    z[7,2,5]  R1752     -1.8786061555147171e-02
    z[7,2,5]  R1753     -1.1283921450376511e-01
    z[7,2,5]  R1754     -1.6121678054332733e-01
    z[7,2,5]  R1755     -2.6245030760765076e-01
    z[7,2,5]  R1756     -0.0670199990272522
    z[7,2,5]  R1757     -2.4436776340007782e-01
    z[7,2,5]  R1758     3.6630305647850037e-01
    z[7,2,5]  R1759     -2.6340955495834351e-01
    z[7,2,5]  R1760     -9.4148583710193634e-02
    z[7,2,5]  R1761     -3.4305401146411896e-02
    z[7,2,5]  R1762     1.6856788098812103e-01
    z[7,2,5]  R1763     -5.0172898918390274e-02
    z[7,2,5]  R1764     9.5535710453987122e-02
    z[7,2,5]  R1765     -2.5173571705818176e-01
    z[7,2,5]  R1766     -3.9147889614105225e-01
    z[7,2,5]  R1767     5.3077928721904755e-02
    z[7,2,5]  R1768     -9.2946678400039673e-02
    z[7,2,5]  R1769     9.7296662628650665e-02
    z[7,2,5]  R1770     -9.6086002886295319e-02
    z[7,2,5]  R1771     -4.2067468166351318e-01
    z[7,2,5]  R1772     -5.5732220411300659e-01
    z[7,2,5]  R1773     -9.7770117223262787e-02
    z[7,2,5]  R1774     -1.1749976128339767e-01
    z[7,2,5]  R1775     2.3909299075603485e-01
    z[7,2,5]  R1776     -2.1298358216881752e-02
    z[7,2,5]  R1777     -2.9836791753768921e-01
    z[7,2,5]  R1778     -1.0847450233995914e-02
    z[7,2,5]  R1779     3.6222180724143982e-01
    z[7,2,5]  R1780     -2.8392225503921509e-01
    z[7,2,5]  R1781     -3.4298751503229141e-02
    z[7,2,5]  R1782     -0.0587601400911808
    z[7,2,5]  R1783     5.3964339196681976e-02
    z[7,2,5]  R1784     3.1064370274543762e-01
    z[7,2,5]  R1785     -4.3982222676277161e-02
    z[7,2,5]  R1786     3.9665651321411133e-01
    z[7,2,5]  R1787     5.3600388765335083e-01
    z[7,2,5]  R1788     -5.4437303543090820e-01
    z[7,2,5]  R1789     -4.8453959822654724e-01
    z[7,2,5]  R1790     -2.4696022272109985e-01
    z[7,2,5]  R1791     1.7080970108509064e-01
    z[7,2,5]  R1792     -0.337971568107605
    z[7,2,5]  R1793     1.9546246528625488e-01
    z[7,2,6]  R26       1
    z[7,2,6]  R71       -1
    z[7,2,6]  R1723     -1
    z[7,2,6]  R1724     1
    z[7,2,6]  R1725     -3.0690962448716164e-02
    z[7,2,6]  R1726     -1.2106040120124817e-01
    z[7,2,6]  R1727     4.1880896687507629e-01
    z[7,2,6]  R1728     2.0852467417716980e-01
    z[7,2,6]  R1729     -1.0769448429346085e-01
    z[7,2,6]  R1730     -6.8187125027179718e-02
    z[7,2,6]  R1731     -2.2787373512983322e-02
    z[7,2,6]  R1732     -5.5900763720273972e-02
    z[7,2,6]  R1733     1.4057008922100067e-01
    z[7,2,6]  R1734     5.3969401121139526e-01
    z[7,2,6]  R1735     2.0896056294441223e-01
    z[7,2,6]  R1736     0.0703059658408165
    z[7,2,6]  R1737     -3.1356176733970642e-01
    z[7,2,6]  R1738     -1.4374145865440369e-01
    z[7,2,6]  R1739     9.5743931829929352e-02
    z[7,2,6]  R1740     -2.7017101645469666e-01
    z[7,2,6]  R1741     0.377633661031723
    z[7,2,6]  R1742     1.1471087113022804e-02
    z[7,2,6]  R1743     -3.8736443966627121e-02
    z[7,2,6]  R1744     3.2835307717323303e-01
    z[7,2,6]  R1745     1.2709383852779865e-02
    z[7,2,6]  R1746     -1.4667297899723053e-01
    z[7,2,6]  R1747     8.2507297396659851e-02
    z[7,2,6]  R1748     1.0736383497714996e-01
    z[7,2,6]  R1749     -2.6166132092475891e-01
    z[7,2,6]  R1750     -1.9260872900485992e-01
    z[7,2,6]  R1751     -3.4314379096031189e-02
    z[7,2,6]  R1752     1.6094848513603210e-01
    z[7,2,6]  R1753     -6.2251168489456177e-01
    z[7,2,6]  R1754     -3.9175704121589661e-01
    z[7,2,6]  R1755     -4.6458251774311066e-02
    z[7,2,6]  R1756     1.8408608436584473e-01
    z[7,2,6]  R1757     2.6160009205341339e-02
    z[7,2,6]  R1758     7.8310193493962288e-03
    z[7,2,6]  R1759     9.1239757835865021e-02
    z[7,2,6]  R1760     -0.0608413964509964
    z[7,2,6]  R1761     3.1286141276359558e-01
    z[7,2,6]  R1762     6.4555965363979340e-02
    z[7,2,6]  R1763     2.9393553733825684e-01
    z[7,2,6]  R1764     1.7758828401565552e-01
    z[7,2,6]  R1765     5.1203376054763794e-01
    z[7,2,6]  R1766     -4.1345804929733276e-02
    z[7,2,6]  R1767     -7.9316355288028717e-02
    z[7,2,6]  R1768     3.1014952063560486e-01
    z[7,2,6]  R1769     4.7311067581176758e-01
    z[7,2,6]  R1770     4.0797162055969238e-01
    z[7,2,6]  R1771     1.3117515482008457e-02
    z[7,2,6]  R1772     3.9898250252008438e-02
    z[7,2,6]  R1773     2.5561091303825378e-01
    z[7,2,6]  R1774     0.303884357213974
    z[7,2,6]  R1775     -1.4541435521095991e-03
    z[7,2,6]  R1776     -1.3916519284248352e-01
    z[7,2,6]  R1777     -1.6364848613739014e-01
    z[7,2,6]  R1778     2.7841567993164062e-01
    z[7,2,6]  R1779     6.2870927155017853e-02
    z[7,2,6]  R1780     -1.7144758999347687e-01
    z[7,2,6]  R1781     2.7778929471969604e-01
    z[7,2,6]  R1782     2.5665801763534546e-01
    z[7,2,6]  R1783     -2.6609787344932556e-01
    z[7,2,6]  R1784     2.6930475234985352e-01
    z[7,2,6]  R1785     1.8482415378093719e-01
    z[7,2,6]  R1786     2.4370370432734489e-02
    z[7,2,6]  R1787     -3.8140645623207092e-01
    z[7,2,6]  R1788     -4.3413665890693665e-01
    z[7,2,6]  R1789     1.0922961682081223e-01
    z[7,2,6]  R1790     -1.5183512866497040e-01
    z[7,2,6]  R1791     -7.2895568609237671e-01
    z[7,2,6]  R1792     1.7387457191944122e-01
    z[7,2,6]  R1793     -2.4548269808292389e-01
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1794     -1
    z[3,7,0]  R1795     1
    z[3,7,0]  R1808     -3.5991060733795166e-01
    z[3,7,0]  R1809     -4.5456355810165405e-01
    z[3,7,0]  R1810     -4.4574731588363647e-01
    z[3,7,0]  R1811     -4.6410277485847473e-01
    z[3,7,0]  R1812     -5.2192157506942749e-01
    z[3,7,0]  R1813     -4.0470978617668152e-01
    z[3,7,0]  R1814     -5.7777029275894165e-01
    z[3,7,0]  R1815     -4.0178349614143372e-01
    z[3,7,0]  R1816     -3.2651230692863464e-01
    z[3,7,0]  R1817     -4.1116729378700256e-01
    z[3,7,0]  R1818     4.0314695239067078e-01
    z[3,7,0]  R1819     3.2006826996803284e-01
    z[3,7,0]  R1820     3.1858152151107788e-01
    z[3,7,0]  R1821     -5.3300172090530396e-02
    z[3,7,0]  R1822     -0.0971560999751091
    z[3,7,0]  R1823     -1.9486416876316071e-01
    z[3,7,0]  R1824     6.5823340415954590e-01
    z[3,7,0]  R1825     2.6445361971855164e-01
    z[3,7,0]  R1826     5.6431043148040771e-01
    z[3,7,0]  R1827     6.9859266281127930e-01
    z[3,7,0]  R1828     -8.1654220819473267e-01
    z[3,7,0]  R1829     -4.6711954474449158e-01
    z[3,7,0]  R1830     -2.5209191441535950e-01
    z[3,7,0]  R1831     -3.8560062646865845e-01
    z[3,7,0]  R1832     -7.2104871273040771e-02
    z[3,7,0]  R1833     -1.8766702711582184e-01
    z[3,7,0]  R1834     3.5074448585510254e-01
    z[3,7,0]  R1835     1.5124855935573578e-01
    z[3,7,0]  R1836     3.6888447403907776e-01
    z[3,7,0]  R1837     -0.0568423829972744
    z[3,7,0]  R1838     0.269486665725708
    z[3,7,0]  R1839     -4.7959303855895996e-01
    z[3,7,0]  R1840     3.5856714844703674e-01
    z[3,7,0]  R1841     2.4458761513233185e-01
    z[3,7,0]  R1842     -2.5855675339698792e-02
    z[3,7,0]  R1843     4.8005181550979614e-01
    z[3,7,0]  R1844     3.8531249761581421e-01
    z[3,7,0]  R1845     3.6964043974876404e-01
    z[3,7,0]  R1846     -3.5606625676155090e-01
    z[3,7,0]  R1847     6.2695044279098511e-01
    z[3,7,0]  R1848     -9.1189378499984741e-01
    z[3,7,0]  R1849     -5.0960201025009155e-01
    z[3,7,0]  R1850     -5.2936893701553345e-01
    z[3,7,0]  R1851     2.7014988660812378e-01
    z[3,7,0]  R1852     1.2836974859237671e-01
    z[3,7,0]  R1853     -3.2415881752967834e-01
    z[3,7,0]  R1854     1.9237544620409608e-03
    z[3,7,0]  R1855     3.3115983009338379e-01
    z[3,7,0]  R1856     4.5234140753746033e-01
    z[3,7,0]  R1857     2.3212891817092896e-01
    z[3,7,0]  R1858     -6.2432825565338135e-01
    z[3,7,0]  R1859     3.9158350229263306e-01
    z[3,7,0]  R1860     2.5368806719779968e-01
    z[3,7,0]  R1861     8.4511172771453857e-01
    z[3,7,0]  R1862     9.3903625011444092e-01
    z[3,7,0]  R1863     8.1066626310348511e-01
    z[3,7,0]  R1864     8.7860095500946045e-01
    z[3,7,0]  R1865     8.9351570606231689e-01
    z[3,7,0]  R1866     8.3863776922225952e-01
    z[3,7,0]  R1867     9.1565757989883423e-01
    z[3,7,0]  R1868     -5.5066294968128204e-02
    z[3,7,0]  R1869     -5.4952509701251984e-02
    z[3,7,0]  R1870     -1.3514424860477448e-01
    z[3,7,0]  R1871     -2.0544309914112091e-01
    z[3,7,0]  R1872     -3.3502045273780823e-01
    z[3,7,0]  R1873     3.9353778958320618e-01
    z[3,7,0]  R1874     -3.9055220782756805e-02
    z[3,7,0]  R1875     0.0508398562669754
    z[3,7,0]  R1876     7.3907065391540527e-01
    z[3,7,0]  R1877     4.8043563961982727e-01
    z[3,7,0]  R1878     -8.2265603542327881e-01
    z[3,7,0]  R1879     -8.5410159826278687e-01
    z[3,7,0]  R1880     -7.0194125175476074e-01
    z[3,7,0]  R1881     -7.8165721893310547e-01
    z[3,7,0]  R1882     -9.0683442354202271e-01
    z[3,7,0]  R1883     -1.5419508516788483e-01
    z[3,7,0]  R1884     0.0777321606874466
    z[3,7,0]  R1885     4.1521093249320984e-01
    z[3,7,0]  R1886     3.1091028451919556e-01
    z[3,7,0]  R1887     2.6029297709465027e-01
    z[3,7,0]  R1888     1.7411856353282928e-01
    z[3,7,0]  R1889     2.8291067481040955e-01
    z[3,7,0]  R1890     2.3529216647148132e-01
    z[3,7,0]  R1891     5.3404539823532104e-02
    z[3,7,0]  R1892     4.6603572368621826e-01
    z[3,7,0]  R1893     0.563897967338562
    z[3,7,0]  R1894     3.7199625372886658e-01
    z[3,7,0]  R1895     3.0794638395309448e-01
    z[3,7,0]  R1896     2.9737782478332520e-01
    z[3,7,0]  R1897     6.5450179576873779e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1796     -1
    z[3,7,1]  R1797     1
    z[3,7,1]  R1808     5.0554737448692322e-02
    z[3,7,1]  R1809     9.8127990961074829e-02
    z[3,7,1]  R1810     -3.9291703701019287e-01
    z[3,7,1]  R1811     -1.1177907884120941e-01
    z[3,7,1]  R1812     -2.9897859692573547e-01
    z[3,7,1]  R1813     3.5906076431274414e-01
    z[3,7,1]  R1814     3.8666567206382751e-01
    z[3,7,1]  R1815     2.4915374815464020e-01
    z[3,7,1]  R1816     2.0148459076881409e-01
    z[3,7,1]  R1817     2.9861399531364441e-01
    z[3,7,1]  R1818     -8.7873065471649170e-01
    z[3,7,1]  R1819     -7.7030980587005615e-01
    z[3,7,1]  R1820     -7.4472886323928833e-01
    z[3,7,1]  R1821     -7.0607739686965942e-01
    z[3,7,1]  R1822     -6.1061781644821167e-01
    z[3,7,1]  R1823     -5.8673632144927979e-01
    z[3,7,1]  R1824     5.6714862585067749e-01
    z[3,7,1]  R1825     6.0628509521484375e-01
    z[3,7,1]  R1826     6.5020549297332764e-01
    z[3,7,1]  R1827     -3.5180736333131790e-02
    z[3,7,1]  R1828     1.5650710463523865e-01
    z[3,7,1]  R1829     3.1514936685562134e-01
    z[3,7,1]  R1830     -1.5191204845905304e-01
    z[3,7,1]  R1831     -2.3847508430480957e-01
    z[3,7,1]  R1832     -8.9345580339431763e-01
    z[3,7,1]  R1833     -8.7426781654357910e-01
    z[3,7,1]  R1834     8.1471043825149536e-01
    z[3,7,1]  R1835     0.825800895690918
    z[3,7,1]  R1836     7.9975461959838867e-01
    z[3,7,1]  R1837     -7.1221423149108887e-01
    z[3,7,1]  R1838     -7.7294135093688965e-01
    z[3,7,1]  R1839     -7.2220253944396973e-01
    z[3,7,1]  R1840     -6.6316813230514526e-01
    z[3,7,1]  R1841     -6.6478884220123291e-01
    z[3,7,1]  R1842     -6.2566965818405151e-01
    z[3,7,1]  R1843     6.6959112882614136e-01
    z[3,7,1]  R1844     7.3697966337203979e-01
    z[3,7,1]  R1845     7.4696606397628784e-01
    z[3,7,1]  R1846     -0.578748345375061
    z[3,7,1]  R1847     5.0334107875823975e-01
    z[3,7,1]  R1848     1.3572555780410767e-01
    z[3,7,1]  R1849     0.361227422952652
    z[3,7,1]  R1850     -3.4717705845832825e-01
    z[3,7,1]  R1851     -8.4776496887207031e-01
    z[3,7,1]  R1852     9.0776854753494263e-01
    z[3,7,1]  R1853     -0.807357132434845
    z[3,7,1]  R1854     -8.0007779598236084e-01
    z[3,7,1]  R1855     -0.755072832107544
    z[3,7,1]  R1856     7.3512774705886841e-01
    z[3,7,1]  R1857     -6.8834644556045532e-01
    z[3,7,1]  R1858     1.4412263035774231e-01
    z[3,7,1]  R1859     -7.5586807727813721e-01
    z[3,7,1]  R1860     -7.2229963541030884e-01
    z[3,7,1]  R1861     1.0070722550153732e-01
    z[3,7,1]  R1862     1.9718358293175697e-02
    z[3,7,1]  R1863     1.5232196450233459e-01
    z[3,7,1]  R1864     2.2131569683551788e-01
    z[3,7,1]  R1865     0.0603828951716423
    z[3,7,1]  R1866     -2.1022692322731018e-02
    z[3,7,1]  R1867     1.4718034863471985e-01
    z[3,7,1]  R1868     -0.743045449256897
    z[3,7,1]  R1869     -7.4928855895996094e-01
    z[3,7,1]  R1870     -7.2837853431701660e-01
    z[3,7,1]  R1871     -7.0721590518951416e-01
    z[3,7,1]  R1872     -7.0768111944198608e-01
    z[3,7,1]  R1873     -6.8114686012268066e-01
    z[3,7,1]  R1874     -6.6867059469223022e-01
    z[3,7,1]  R1875     -5.9756278991699219e-01
    z[3,7,1]  R1876     -5.9231704473495483e-01
    z[3,7,1]  R1877     -5.1949393749237061e-01
    z[3,7,1]  R1878     1.4352588355541229e-01
    z[3,7,1]  R1879     1.7586836218833923e-01
    z[3,7,1]  R1880     4.2263475060462952e-01
    z[3,7,1]  R1881     2.6250369846820831e-02
    z[3,7,1]  R1882     -1.4274181798100471e-02
    z[3,7,1]  R1883     3.5868328809738159e-01
    z[3,7,1]  R1884     8.4278291463851929e-01
    z[3,7,1]  R1885     6.1004316806793213e-01
    z[3,7,1]  R1886     6.5526819229125977e-01
    z[3,7,1]  R1887     6.4741140604019165e-01
    z[3,7,1]  R1888     0.793921172618866
    z[3,7,1]  R1889     6.9187086820602417e-01
    z[3,7,1]  R1890     7.2983145713806152e-01
    z[3,7,1]  R1891     7.1048659086227417e-01
    z[3,7,1]  R1892     7.0828109979629517e-01
    z[3,7,1]  R1893     6.3068258762359619e-01
    z[3,7,1]  R1894     7.3375660181045532e-01
    z[3,7,1]  R1895     6.5386146306991577e-01
    z[3,7,1]  R1896     6.2505561113357544e-01
    z[3,7,1]  R1897     2.6948049664497375e-01
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1798     -1
    z[3,7,2]  R1799     1
    z[3,7,2]  R1808     -5.7450437545776367e-01
    z[3,7,2]  R1809     -5.4136312007904053e-01
    z[3,7,2]  R1810     -4.8270869255065918e-01
    z[3,7,2]  R1811     -6.6043287515640259e-01
    z[3,7,2]  R1812     1.9376932084560394e-01
    z[3,7,2]  R1813     -0.762722373008728
    z[3,7,2]  R1814     5.5558848381042480e-01
    z[3,7,2]  R1815     -5.3006899356842041e-01
    z[3,7,2]  R1816     1.7786386609077454e-01
    z[3,7,2]  R1817     3.8306677341461182e-01
    z[3,7,2]  R1818     1.2119157612323761e-01
    z[3,7,2]  R1819     -2.3542407155036926e-01
    z[3,7,2]  R1820     -7.2500328533351421e-03
    z[3,7,2]  R1821     -0.0172028299421072
    z[3,7,2]  R1822     2.1154652535915375e-01
    z[3,7,2]  R1823     8.4976553916931152e-02
    z[3,7,2]  R1824     -4.9993500113487244e-02
    z[3,7,2]  R1825     3.0862805247306824e-01
    z[3,7,2]  R1826     2.4009078741073608e-01
    z[3,7,2]  R1827     0.0586773082613945
    z[3,7,2]  R1828     2.2539477050304413e-01
    z[3,7,2]  R1829     1.4220415614545345e-02
    z[3,7,2]  R1830     -6.3256755471229553e-02
    z[3,7,2]  R1831     -1.6211499273777008e-01
    z[3,7,2]  R1832     -1.1996103823184967e-01
    z[3,7,2]  R1833     9.2876493930816650e-02
    z[3,7,2]  R1834     -4.4878937304019928e-02
    z[3,7,2]  R1835     3.0679382383823395e-02
    z[3,7,2]  R1836     1.7138579487800598e-01
    z[3,7,2]  R1837     8.4675490856170654e-02
    z[3,7,2]  R1838     1.3530911877751350e-02
    z[3,7,2]  R1839     2.7614161372184753e-01
    z[3,7,2]  R1840     -1.5526381134986877e-01
    z[3,7,2]  R1841     4.7609332203865051e-01
    z[3,7,2]  R1842     2.2000728547573090e-01
    z[3,7,2]  R1843     2.9708305001258850e-01
    z[3,7,2]  R1844     7.5209461152553558e-02
    z[3,7,2]  R1845     -1.4300939440727234e-01
    z[3,7,2]  R1846     1.3825416564941406e-01
    z[3,7,2]  R1847     5.0136047601699829e-01
    z[3,7,2]  R1848     1.3743334449827671e-02
    z[3,7,2]  R1849     -2.3087030649185181e-01
    z[3,7,2]  R1850     -2.7897748351097107e-01
    z[3,7,2]  R1851     -2.2459983825683594e-01
    z[3,7,2]  R1852     -0.21180360019207
    z[3,7,2]  R1853     -1.8946641683578491e-01
    z[3,7,2]  R1854     -1.6353523731231689e-01
    z[3,7,2]  R1855     -2.2070477902889252e-01
    z[3,7,2]  R1856     6.5782824531197548e-03
    z[3,7,2]  R1857     -3.8861316442489624e-01
    z[3,7,2]  R1858     1.6582390666007996e-01
    z[3,7,2]  R1859     -0.30942302942276
    z[3,7,2]  R1860     -2.1762351691722870e-01
    z[3,7,2]  R1861     3.2298988103866577e-01
    z[3,7,2]  R1862     6.7150115966796875e-02
    z[3,7,2]  R1863     4.4720417261123657e-01
    z[3,7,2]  R1864     4.0122170001268387e-02
    z[3,7,2]  R1865     1.4636841416358948e-01
    z[3,7,2]  R1866     1.9571933150291443e-01
    z[3,7,2]  R1867     1.6245013475418091e-01
    z[3,7,2]  R1868     -0.0832938700914383
    z[3,7,2]  R1869     7.8313037753105164e-02
    z[3,7,2]  R1870     1.8474750220775604e-01
    z[3,7,2]  R1871     1.7942178249359131e-01
    z[3,7,2]  R1872     -1.0637225210666656e-01
    z[3,7,2]  R1873     -4.5578071475028992e-01
    z[3,7,2]  R1874     1.4830625057220459e-01
    z[3,7,2]  R1875     -1.3196821324527264e-02
    z[3,7,2]  R1876     1.0675847530364990e-01
    z[3,7,2]  R1877     -2.0281404256820679e-02
    z[3,7,2]  R1878     -3.2566487789154053e-01
    z[3,7,2]  R1879     -0.0940450057387352
    z[3,7,2]  R1880     -4.0577489882707596e-02
    z[3,7,2]  R1881     -4.8938649892807007e-01
    z[3,7,2]  R1882     -7.5737267732620239e-02
    z[3,7,2]  R1883     -4.7218307852745056e-01
    z[3,7,2]  R1884     2.2482825815677643e-01
    z[3,7,2]  R1885     4.6637746691703796e-01
    z[3,7,2]  R1886     5.5652713775634766e-01
    z[3,7,2]  R1887     4.3382686376571655e-01
    z[3,7,2]  R1888     5.7313352823257446e-01
    z[3,7,2]  R1889     -3.0905985832214355e-01
    z[3,7,2]  R1890     -0.466251939535141
    z[3,7,2]  R1891     -8.3113173022866249e-03
    z[3,7,2]  R1892     1.0023440234363079e-02
    z[3,7,2]  R1893     0.0632082000374794
    z[3,7,2]  R1894     -2.7546146512031555e-01
    z[3,7,2]  R1895     -6.0453660786151886e-02
    z[3,7,2]  R1896     0.0542115643620491
    z[3,7,2]  R1897     1.9810880720615387e-01
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1800     -1
    z[3,7,3]  R1801     1
    z[3,7,3]  R1808     -5.5182403326034546e-01
    z[3,7,3]  R1809     -2.5081974267959595e-01
    z[3,7,3]  R1810     -3.1413015723228455e-01
    z[3,7,3]  R1811     -5.4775989055633545e-01
    z[3,7,3]  R1812     -5.4104810953140259e-01
    z[3,7,3]  R1813     -1.3957542367279530e-02
    z[3,7,3]  R1814     -3.8215351104736328e-01
    z[3,7,3]  R1815     -2.6786011457443237e-01
    z[3,7,3]  R1816     -4.9451878666877747e-01
    z[3,7,3]  R1817     -6.1520993709564209e-01
    z[3,7,3]  R1818     1.1706600338220596e-01
    z[3,7,3]  R1819     1.7956618964672089e-01
    z[3,7,3]  R1820     2.1216855943202972e-01
    z[3,7,3]  R1821     5.1769173145294189e-01
    z[3,7,3]  R1822     6.4694148302078247e-01
    z[3,7,3]  R1823     6.5466111898422241e-01
    z[3,7,3]  R1824     -1.8238945305347443e-01
    z[3,7,3]  R1825     4.4153988361358643e-01
    z[3,7,3]  R1826     3.9338329434394836e-01
    z[3,7,3]  R1827     0.610335648059845
    z[3,7,3]  R1828     6.5426409244537354e-02
    z[3,7,3]  R1829     4.9048196524381638e-02
    z[3,7,3]  R1830     -3.0986478924751282e-01
    z[3,7,3]  R1831     -1.7784656584262848e-01
    z[3,7,3]  R1832     1.1586633324623108e-01
    z[3,7,3]  R1833     -1.1492399126291275e-01
    z[3,7,3]  R1834     -2.9630091786384583e-01
    z[3,7,3]  R1835     2.5218906998634338e-01
    z[3,7,3]  R1836     -4.9235463142395020e-02
    z[3,7,3]  R1837     2.7134326100349426e-01
    z[3,7,3]  R1838     4.4782254099845886e-01
    z[3,7,3]  R1839     2.7273058891296387e-01
    z[3,7,3]  R1840     4.8097413033246994e-02
    z[3,7,3]  R1841     -5.0844904035329819e-02
    z[3,7,3]  R1842     -2.6202961802482605e-01
    z[3,7,3]  R1843     -5.7135045528411865e-02
    z[3,7,3]  R1844     4.1552387177944183e-02
    z[3,7,3]  R1845     3.9916276931762695e-02
    z[3,7,3]  R1846     5.5593556165695190e-01
    z[3,7,3]  R1847     3.3694509416818619e-02
    z[3,7,3]  R1848     2.4267129600048065e-01
    z[3,7,3]  R1849     -2.9687255620956421e-01
    z[3,7,3]  R1850     4.6162612736225128e-02
    z[3,7,3]  R1851     1.0166615247726440e-02
    z[3,7,3]  R1852     -0.074288509786129
    z[3,7,3]  R1853     2.5950086116790771e-01
    z[3,7,3]  R1854     4.0295529365539551e-01
    z[3,7,3]  R1855     3.8861134648323059e-01
    z[3,7,3]  R1856     -4.7248327732086182e-01
    z[3,7,3]  R1857     9.4653815031051636e-02
    z[3,7,3]  R1858     -5.4831784963607788e-01
    z[3,7,3]  R1859     3.3024334907531738e-01
    z[3,7,3]  R1860     -4.7218668460845947e-01
    z[3,7,3]  R1861     3.7375611066818237e-01
    z[3,7,3]  R1862     2.7929738163948059e-01
    z[3,7,3]  R1863     9.5742210745811462e-02
    z[3,7,3]  R1864     3.8788342475891113e-01
    z[3,7,3]  R1865     1.6844633221626282e-01
    z[3,7,3]  R1866     3.8832414150238037e-01
    z[3,7,3]  R1867     2.2806464135646820e-01
    z[3,7,3]  R1868     -5.3115785121917725e-01
    z[3,7,3]  R1869     -0.517676055431366
    z[3,7,3]  R1870     -4.5510104298591614e-01
    z[3,7,3]  R1871     1.4501862227916718e-01
    z[3,7,3]  R1872     5.4367440938949585e-01
    z[3,7,3]  R1873     -1.2788806855678558e-01
    z[3,7,3]  R1874     -2.4055039882659912e-01
    z[3,7,3]  R1875     -2.2824862599372864e-01
    z[3,7,3]  R1876     -2.6141172274947166e-02
    z[3,7,3]  R1877     0.362593412399292
    z[3,7,3]  R1878     -3.7873315811157227e-01
    z[3,7,3]  R1879     -3.8320377469062805e-01
    z[3,7,3]  R1880     -3.0686238408088684e-01
    z[3,7,3]  R1881     -1.0967943817377090e-02
    z[3,7,3]  R1882     8.8958166539669037e-02
    z[3,7,3]  R1883     -7.3784607648849487e-01
    z[3,7,3]  R1884     -1.4718878269195557e-01
    z[3,7,3]  R1885     -2.7771508693695068e-01
    z[3,7,3]  R1886     -3.1631910800933838e-01
    z[3,7,3]  R1887     -9.4376482069492340e-02
    z[3,7,3]  R1888     -2.9263095930218697e-03
    z[3,7,3]  R1889     2.9952365159988403e-01
    z[3,7,3]  R1890     3.1823712587356567e-01
    z[3,7,3]  R1891     5.2354931831359863e-01
    z[3,7,3]  R1892     -2.7067307382822037e-02
    z[3,7,3]  R1893     2.8740158677101135e-01
    z[3,7,3]  R1894     3.9176261425018311e-01
    z[3,7,3]  R1895     1.5172840654850006e-01
    z[3,7,3]  R1896     1.9516982138156891e-01
    z[3,7,3]  R1897     4.9416700005531311e-01
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1802     -1
    z[3,7,4]  R1803     1
    z[3,7,4]  R1808     3.8681440055370331e-02
    z[3,7,4]  R1809     -3.4683328866958618e-01
    z[3,7,4]  R1810     -3.0500268936157227e-01
    z[3,7,4]  R1811     4.3743055313825607e-02
    z[3,7,4]  R1812     1.3978804647922516e-01
    z[3,7,4]  R1813     -1.5404058992862701e-01
    z[3,7,4]  R1814     -0.0876581221818924
    z[3,7,4]  R1815     3.1593859195709229e-01
    z[3,7,4]  R1816     4.8961933702230453e-02
    z[3,7,4]  R1817     -1.2086918950080872e-01
    z[3,7,4]  R1818     -6.4705125987529755e-02
    z[3,7,4]  R1819     3.7865522503852844e-01
    z[3,7,4]  R1820     4.4442600011825562e-01
    z[3,7,4]  R1821     2.3144865036010742e-01
    z[3,7,4]  R1822     -2.1084553003311157e-01
    z[3,7,4]  R1823     1.6681958734989166e-01
    z[3,7,4]  R1824     -1.5593305230140686e-01
    z[3,7,4]  R1825     -0.275911420583725
    z[3,7,4]  R1826     -1.8377138674259186e-01
    z[3,7,4]  R1827     2.6651170849800110e-01
    z[3,7,4]  R1828     -1.0773171670734882e-03
    z[3,7,4]  R1829     -7.9781693220138550e-01
    z[3,7,4]  R1830     -5.2463328838348389e-01
    z[3,7,4]  R1831     -7.3747575283050537e-01
    z[3,7,4]  R1832     -4.4086609035730362e-02
    z[3,7,4]  R1833     1.6232788562774658e-01
    z[3,7,4]  R1834     3.2864493131637573e-01
    z[3,7,4]  R1835     2.0857295393943787e-01
    z[3,7,4]  R1836     0.376196026802063
    z[3,7,4]  R1837     -3.8204070925712585e-01
    z[3,7,4]  R1838     -2.7704018354415894e-01
    z[3,7,4]  R1839     -3.0748006701469421e-01
    z[3,7,4]  R1840     -2.4504117667675018e-01
    z[3,7,4]  R1841     1.9450557231903076e-01
    z[3,7,4]  R1842     -0.614127516746521
    z[3,7,4]  R1843     -4.1097548604011536e-01
    z[3,7,4]  R1844     1.3882963359355927e-01
    z[3,7,4]  R1845     -3.6934280395507812e-01
    z[3,7,4]  R1846     2.3542624711990356e-01
    z[3,7,4]  R1847     -2.0454618334770203e-01
    z[3,7,4]  R1848     -1.6884620487689972e-01
    z[3,7,4]  R1849     -6.3305526971817017e-01
    z[3,7,4]  R1850     -5.4552334547042847e-01
    z[3,7,4]  R1851     3.6771696805953979e-01
    z[3,7,4]  R1852     1.9974310696125031e-01
    z[3,7,4]  R1853     3.4017801284790039e-01
    z[3,7,4]  R1854     -2.6309159398078918e-01
    z[3,7,4]  R1855     2.5382652878761292e-02
    z[3,7,4]  R1856     -1.6438420116901398e-01
    z[3,7,4]  R1857     3.2526103314012289e-03
    z[3,7,4]  R1858     3.2445633411407471e-01
    z[3,7,4]  R1859     -1.4153721928596497e-01
    z[3,7,4]  R1860     -3.0477762222290039e-01
    z[3,7,4]  R1861     1.4489167928695679e-01
    z[3,7,4]  R1862     1.8020328879356384e-01
    z[3,7,4]  R1863     2.0290957391262054e-01
    z[3,7,4]  R1864     -6.0020685195922852e-02
    z[3,7,4]  R1865     3.7530052661895752e-01
    z[3,7,4]  R1866     1.0802821815013885e-01
    z[3,7,4]  R1867     1.0176397860050201e-01
    z[3,7,4]  R1868     2.0416952669620514e-01
    z[3,7,4]  R1869     3.3035805821418762e-01
    z[3,7,4]  R1870     -1.7304044961929321e-01
    z[3,7,4]  R1871     4.3810001015663147e-01
    z[3,7,4]  R1872     -2.5421399623155594e-02
    z[3,7,4]  R1873     2.4416697025299072e-01
    z[3,7,4]  R1874     -6.8618965148925781e-01
    z[3,7,4]  R1875     -1.9128118455410004e-01
    z[3,7,4]  R1876     1.0645785182714462e-01
    z[3,7,4]  R1877     1.9151549041271210e-01
    z[3,7,4]  R1878     -9.5341891050338745e-02
    z[3,7,4]  R1879     -2.3639196529984474e-02
    z[3,7,4]  R1880     -2.1149487793445587e-01
    z[3,7,4]  R1881     5.1366519182920456e-02
    z[3,7,4]  R1882     -7.3919579386711121e-02
    z[3,7,4]  R1883     8.4743246436119080e-02
    z[3,7,4]  R1884     -1.3100887835025787e-01
    z[3,7,4]  R1885     -3.0006036162376404e-01
    z[3,7,4]  R1886     5.8689940720796585e-02
    z[3,7,4]  R1887     1.6048046946525574e-01
    z[3,7,4]  R1888     -3.9442688226699829e-02
    z[3,7,4]  R1889     3.7176007032394409e-01
    z[3,7,4]  R1890     2.0438171923160553e-01
    z[3,7,4]  R1891     4.1999229788780212e-01
    z[3,7,4]  R1892     4.3914774060249329e-01
    z[3,7,4]  R1893     3.6389192938804626e-01
    z[3,7,4]  R1894     1.3818424940109253e-01
    z[3,7,4]  R1895     0.651690661907196
    z[3,7,4]  R1896     2.8211387991905212e-01
    z[3,7,4]  R1897     -1.8998704850673676e-01
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1804     -1
    z[3,7,5]  R1805     1
    z[3,7,5]  R1808     -1.3671287894248962e-01
    z[3,7,5]  R1809     5.4327660799026489e-01
    z[3,7,5]  R1810     2.7519872412085533e-02
    z[3,7,5]  R1811     -1.4023344218730927e-01
    z[3,7,5]  R1812     -6.8692475557327271e-02
    z[3,7,5]  R1813     1.1228796094655991e-02
    z[3,7,5]  R1814     -1.6981534659862518e-01
    z[3,7,5]  R1815     -5.6863898038864136e-01
    z[3,7,5]  R1816     -6.2710106372833252e-01
    z[3,7,5]  R1817     4.2931646108627319e-01
    z[3,7,5]  R1818     1.5785978734493256e-01
    z[3,7,5]  R1819     2.5563362240791321e-01
    z[3,7,5]  R1820     -0.317251980304718
    z[3,7,5]  R1821     0.415078729391098
    z[3,7,5]  R1822     -3.3079841732978821e-01
    z[3,7,5]  R1823     -3.9183324575424194e-01
    z[3,7,5]  R1824     1.9849547743797302e-01
    z[3,7,5]  R1825     2.5840106606483459e-01
    z[3,7,5]  R1826     -2.5410490110516548e-02
    z[3,7,5]  R1827     -1.7936001718044281e-01
    z[3,7,5]  R1828     3.9175990223884583e-01
    z[3,7,5]  R1829     6.6067695617675781e-02
    z[3,7,5]  R1830     7.2028040885925293e-01
    z[3,7,5]  R1831     4.3533289432525635e-01
    z[3,7,5]  R1832     4.0302121639251709e-01
    z[3,7,5]  R1833     3.1039389967918396e-01
    z[3,7,5]  R1834     8.8278248906135559e-02
    z[3,7,5]  R1835     3.7574744224548340e-01
    z[3,7,5]  R1836     1.4499436318874359e-01
    z[3,7,5]  R1837     -5.1070624589920044e-01
    z[3,7,5]  R1838     -2.2779320180416107e-01
    z[3,7,5]  R1839     4.5578092336654663e-02
    z[3,7,5]  R1840     -5.8653438091278076e-01
    z[3,7,5]  R1841     -4.6099528670310974e-01
    z[3,7,5]  R1842     -7.5132623314857483e-02
    z[3,7,5]  R1843     -2.4239070713520050e-01
    z[3,7,5]  R1844     -3.3351576328277588e-01
    z[3,7,5]  R1845     -3.1046655774116516e-01
    z[3,7,5]  R1846     -2.9368317127227783e-01
    z[3,7,5]  R1847     1.9626735150814056e-01
    z[3,7,5]  R1848     -1.4469853043556213e-01
    z[3,7,5]  R1849     -5.5544916540384293e-02
    z[3,7,5]  R1850     4.6312987804412842e-01
    z[3,7,5]  R1851     2.5895142927765846e-02
    z[3,7,5]  R1852     2.1338342130184174e-01
    z[3,7,5]  R1853     8.5565216839313507e-02
    z[3,7,5]  R1854     0.0840703547000885
    z[3,7,5]  R1855     -3.4614598751068115e-01
    z[3,7,5]  R1856     6.1836522072553635e-02
    z[3,7,5]  R1857     -1.8361641466617584e-01
    z[3,7,5]  R1858     3.1850022077560425e-01
    z[3,7,5]  R1859     -1.7846895754337311e-01
    z[3,7,5]  R1860     2.1995152533054352e-01
    z[3,7,5]  R1861     -3.9587166160345078e-02
    z[3,7,5]  R1862     -3.2489750534296036e-02
    z[3,7,5]  R1863     0.263158917427063
    z[3,7,5]  R1864     -2.4518856778740883e-02
    z[3,7,5]  R1865     7.6157540082931519e-02
    z[3,7,5]  R1866     2.9837989807128906e-01
    z[3,7,5]  R1867     2.2120243310928345e-01
    z[3,7,5]  R1868     3.3638903498649597e-01
    z[3,7,5]  R1869     -1.9399334490299225e-01
    z[3,7,5]  R1870     6.7884378135204315e-02
    z[3,7,5]  R1871     4.1109851002693176e-01
    z[3,7,5]  R1872     -2.6039877533912659e-01
    z[3,7,5]  R1873     -0.304644912481308
    z[3,7,5]  R1874     -1.0937741026282310e-02
    z[3,7,5]  R1875     -7.4050599336624146e-01
    z[3,7,5]  R1876     -2.4446092545986176e-01
    z[3,7,5]  R1877     1.9868181645870209e-01
    z[3,7,5]  R1878     1.9656149670481682e-02
    z[3,7,5]  R1879     -2.7998128533363342e-01
    z[3,7,5]  R1880     2.9966005682945251e-01
    z[3,7,5]  R1881     3.5412353277206421e-01
    z[3,7,5]  R1882     0.386221319437027
    z[3,7,5]  R1883     -4.7760433517396450e-03
    z[3,7,5]  R1884     -2.2735865414142609e-01
    z[3,7,5]  R1885     2.6579296588897705e-01
    z[3,7,5]  R1886     2.4337849020957947e-01
    z[3,7,5]  R1887     4.2711076140403748e-01
    z[3,7,5]  R1888     -9.5728859305381775e-02
    z[3,7,5]  R1889     3.1036314368247986e-01
    z[3,7,5]  R1890     2.1151506900787354e-01
    z[3,7,5]  R1891     1.7396314442157745e-01
    z[3,7,5]  R1892     1.3783389329910278e-01
    z[3,7,5]  R1893     1.6777409613132477e-01
    z[3,7,5]  R1894     -0.27127605676651
    z[3,7,5]  R1895     -1.8786061555147171e-02
    z[3,7,5]  R1896     -1.1283921450376511e-01
    z[3,7,5]  R1897     -1.6121678054332733e-01
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1806     -1
    z[3,7,6]  R1807     1
    z[3,7,6]  R1808     4.6168902516365051e-01
    z[3,7,6]  R1809     1.1097563803195953e-01
    z[3,7,6]  R1810     4.7059124708175659e-01
    z[3,7,6]  R1811     -1.1967720836400986e-01
    z[3,7,6]  R1812     5.3260743618011475e-01
    z[3,7,6]  R1813     3.1857562065124512e-01
    z[3,7,6]  R1814     1.5946796536445618e-01
    z[3,7,6]  R1815     2.4550843983888626e-02
    z[3,7,6]  R1816     4.2538964748382568e-01
    z[3,7,6]  R1817     -1.3276237249374390e-01
    z[3,7,6]  R1818     8.8356077671051025e-02
    z[3,7,6]  R1819     -0.0882168561220169
    z[3,7,6]  R1820     -2.5562165305018425e-02
    z[3,7,6]  R1821     -6.6741362214088440e-02
    z[3,7,6]  R1822     2.3195805028080940e-02
    z[3,7,6]  R1823     2.4579038843512535e-02
    z[3,7,6]  R1824     -3.8156315684318542e-01
    z[3,7,6]  R1825     -3.5968831181526184e-01
    z[3,7,6]  R1826     1.0943107306957245e-01
    z[3,7,6]  R1827     1.7770607769489288e-01
    z[3,7,6]  R1828     -3.1654992699623108e-01
    z[3,7,6]  R1829     -1.9747292995452881e-01
    z[3,7,6]  R1830     -1.3896332681179047e-01
    z[3,7,6]  R1831     5.6087784469127655e-02
    z[3,7,6]  R1832     -0.0659722089767456
    z[3,7,6]  R1833     -2.3645015060901642e-01
    z[3,7,6]  R1834     8.7271459400653839e-02
    z[3,7,6]  R1835     -2.1435341238975525e-01
    z[3,7,6]  R1836     1.7312683165073395e-01
    z[3,7,6]  R1837     4.4121686369180679e-02
    z[3,7,6]  R1838     2.3863058537244797e-02
    z[3,7,6]  R1839     3.4006141126155853e-02
    z[3,7,6]  R1840     3.3906292170286179e-02
    z[3,7,6]  R1841     -1.3650478422641754e-01
    z[3,7,6]  R1842     -3.2864677906036377e-01
    z[3,7,6]  R1843     -4.4955067336559296e-02
    z[3,7,6]  R1844     -4.1292348504066467e-01
    z[3,7,6]  R1845     -2.2485366463661194e-01
    z[3,7,6]  R1846     2.6155945658683777e-01
    z[3,7,6]  R1847     -1.4395545423030853e-01
    z[3,7,6]  R1848     -2.0372359454631805e-01
    z[3,7,6]  R1849     -2.5405132770538330e-01
    z[3,7,6]  R1850     -8.4806688129901886e-02
    z[3,7,6]  R1851     -1.4791491627693176e-01
    z[3,7,6]  R1852     -1.5384469926357269e-01
    z[3,7,6]  R1853     -1.2967227399349213e-01
    z[3,7,6]  R1854     3.0735993385314941e-01
    z[3,7,6]  R1855     2.7324759867042303e-03
    z[3,7,6]  R1856     -2.9068564996123314e-02
    z[3,7,6]  R1857     5.2781653404235840e-01
    z[3,7,6]  R1858     -2.3362050950527191e-01
    z[3,7,6]  R1859     1.3652274012565613e-01
    z[3,7,6]  R1860     4.8345115035772324e-02
    z[3,7,6]  R1861     9.5223180949687958e-02
    z[3,7,6]  R1862     4.2157445102930069e-02
    z[3,7,6]  R1863     5.9282500296831131e-03
    z[3,7,6]  R1864     -1.5103885531425476e-01
    z[3,7,6]  R1865     -3.9183810353279114e-02
    z[3,7,6]  R1866     -0.0802641361951828
    z[3,7,6]  R1867     -4.7107253223657608e-02
    z[3,7,6]  R1868     -3.0690962448716164e-02
    z[3,7,6]  R1869     -1.2106040120124817e-01
    z[3,7,6]  R1870     4.1880896687507629e-01
    z[3,7,6]  R1871     2.0852467417716980e-01
    z[3,7,6]  R1872     -1.0769448429346085e-01
    z[3,7,6]  R1873     -6.8187125027179718e-02
    z[3,7,6]  R1874     -2.2787373512983322e-02
    z[3,7,6]  R1875     -5.5900763720273972e-02
    z[3,7,6]  R1876     1.4057008922100067e-01
    z[3,7,6]  R1877     5.3969401121139526e-01
    z[3,7,6]  R1878     2.0896056294441223e-01
    z[3,7,6]  R1879     0.0703059658408165
    z[3,7,6]  R1880     -3.1356176733970642e-01
    z[3,7,6]  R1881     -1.4374145865440369e-01
    z[3,7,6]  R1882     9.5743931829929352e-02
    z[3,7,6]  R1883     -2.7017101645469666e-01
    z[3,7,6]  R1884     0.377633661031723
    z[3,7,6]  R1885     1.1471087113022804e-02
    z[3,7,6]  R1886     -3.8736443966627121e-02
    z[3,7,6]  R1887     3.2835307717323303e-01
    z[3,7,6]  R1888     1.2709383852779865e-02
    z[3,7,6]  R1889     -1.4667297899723053e-01
    z[3,7,6]  R1890     8.2507297396659851e-02
    z[3,7,6]  R1891     1.0736383497714996e-01
    z[3,7,6]  R1892     -2.6166132092475891e-01
    z[3,7,6]  R1893     -1.9260872900485992e-01
    z[3,7,6]  R1894     -3.4314379096031189e-02
    z[3,7,6]  R1895     1.6094848513603210e-01
    z[3,7,6]  R1896     -6.2251168489456177e-01
    z[3,7,6]  R1897     -3.9175704121589661e-01
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1898     -1
    z[7,3,0]  R1899     1
    z[7,3,0]  R1912     -5.5066294968128204e-02
    z[7,3,0]  R1913     -5.4952509701251984e-02
    z[7,3,0]  R1914     -1.3514424860477448e-01
    z[7,3,0]  R1915     -2.0544309914112091e-01
    z[7,3,0]  R1916     -3.3502045273780823e-01
    z[7,3,0]  R1917     3.9353778958320618e-01
    z[7,3,0]  R1918     -3.9055220782756805e-02
    z[7,3,0]  R1919     0.0508398562669754
    z[7,3,0]  R1920     7.3907065391540527e-01
    z[7,3,0]  R1921     4.8043563961982727e-01
    z[7,3,0]  R1922     -8.2265603542327881e-01
    z[7,3,0]  R1923     -8.5410159826278687e-01
    z[7,3,0]  R1924     -7.0194125175476074e-01
    z[7,3,0]  R1925     -7.8165721893310547e-01
    z[7,3,0]  R1926     -9.0683442354202271e-01
    z[7,3,0]  R1927     -1.5419508516788483e-01
    z[7,3,0]  R1928     0.0777321606874466
    z[7,3,0]  R1929     4.1521093249320984e-01
    z[7,3,0]  R1930     3.1091028451919556e-01
    z[7,3,0]  R1931     2.6029297709465027e-01
    z[7,3,0]  R1932     1.7411856353282928e-01
    z[7,3,0]  R1933     2.8291067481040955e-01
    z[7,3,0]  R1934     2.3529216647148132e-01
    z[7,3,0]  R1935     5.3404539823532104e-02
    z[7,3,0]  R1936     4.6603572368621826e-01
    z[7,3,0]  R1937     0.563897967338562
    z[7,3,0]  R1938     3.7199625372886658e-01
    z[7,3,0]  R1939     3.0794638395309448e-01
    z[7,3,0]  R1940     2.9737782478332520e-01
    z[7,3,0]  R1941     6.5450179576873779e-01
    z[7,3,0]  R1942     -3.5991060733795166e-01
    z[7,3,0]  R1943     -4.5456355810165405e-01
    z[7,3,0]  R1944     -4.4574731588363647e-01
    z[7,3,0]  R1945     -4.6410277485847473e-01
    z[7,3,0]  R1946     -5.2192157506942749e-01
    z[7,3,0]  R1947     -4.0470978617668152e-01
    z[7,3,0]  R1948     -5.7777029275894165e-01
    z[7,3,0]  R1949     -4.0178349614143372e-01
    z[7,3,0]  R1950     -3.2651230692863464e-01
    z[7,3,0]  R1951     -4.1116729378700256e-01
    z[7,3,0]  R1952     4.0314695239067078e-01
    z[7,3,0]  R1953     3.2006826996803284e-01
    z[7,3,0]  R1954     3.1858152151107788e-01
    z[7,3,0]  R1955     -5.3300172090530396e-02
    z[7,3,0]  R1956     -0.0971560999751091
    z[7,3,0]  R1957     -1.9486416876316071e-01
    z[7,3,0]  R1958     6.5823340415954590e-01
    z[7,3,0]  R1959     2.6445361971855164e-01
    z[7,3,0]  R1960     5.6431043148040771e-01
    z[7,3,0]  R1961     6.9859266281127930e-01
    z[7,3,0]  R1962     -8.1654220819473267e-01
    z[7,3,0]  R1963     -4.6711954474449158e-01
    z[7,3,0]  R1964     -2.5209191441535950e-01
    z[7,3,0]  R1965     -3.8560062646865845e-01
    z[7,3,0]  R1966     -7.2104871273040771e-02
    z[7,3,0]  R1967     -1.8766702711582184e-01
    z[7,3,0]  R1968     3.5074448585510254e-01
    z[7,3,0]  R1969     1.5124855935573578e-01
    z[7,3,0]  R1970     3.6888447403907776e-01
    z[7,3,0]  R1971     -0.0568423829972744
    z[7,3,0]  R1972     0.269486665725708
    z[7,3,0]  R1973     -4.7959303855895996e-01
    z[7,3,0]  R1974     3.5856714844703674e-01
    z[7,3,0]  R1975     2.4458761513233185e-01
    z[7,3,0]  R1976     -2.5855675339698792e-02
    z[7,3,0]  R1977     4.8005181550979614e-01
    z[7,3,0]  R1978     3.8531249761581421e-01
    z[7,3,0]  R1979     3.6964043974876404e-01
    z[7,3,0]  R1980     -3.5606625676155090e-01
    z[7,3,0]  R1981     6.2695044279098511e-01
    z[7,3,0]  R1982     -9.1189378499984741e-01
    z[7,3,0]  R1983     -5.0960201025009155e-01
    z[7,3,0]  R1984     -5.2936893701553345e-01
    z[7,3,0]  R1985     2.7014988660812378e-01
    z[7,3,0]  R1986     1.2836974859237671e-01
    z[7,3,0]  R1987     -3.2415881752967834e-01
    z[7,3,0]  R1988     1.9237544620409608e-03
    z[7,3,0]  R1989     3.3115983009338379e-01
    z[7,3,0]  R1990     4.5234140753746033e-01
    z[7,3,0]  R1991     2.3212891817092896e-01
    z[7,3,0]  R1992     -6.2432825565338135e-01
    z[7,3,0]  R1993     3.9158350229263306e-01
    z[7,3,0]  R1994     2.5368806719779968e-01
    z[7,3,0]  R1995     8.4511172771453857e-01
    z[7,3,0]  R1996     9.3903625011444092e-01
    z[7,3,0]  R1997     8.1066626310348511e-01
    z[7,3,0]  R1998     8.7860095500946045e-01
    z[7,3,0]  R1999     8.9351570606231689e-01
    z[7,3,0]  R2000     8.3863776922225952e-01
    z[7,3,0]  R2001     9.1565757989883423e-01
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1900     -1
    z[7,3,1]  R1901     1
    z[7,3,1]  R1912     -0.743045449256897
    z[7,3,1]  R1913     -7.4928855895996094e-01
    z[7,3,1]  R1914     -7.2837853431701660e-01
    z[7,3,1]  R1915     -7.0721590518951416e-01
    z[7,3,1]  R1916     -7.0768111944198608e-01
    z[7,3,1]  R1917     -6.8114686012268066e-01
    z[7,3,1]  R1918     -6.6867059469223022e-01
    z[7,3,1]  R1919     -5.9756278991699219e-01
    z[7,3,1]  R1920     -5.9231704473495483e-01
    z[7,3,1]  R1921     -5.1949393749237061e-01
    z[7,3,1]  R1922     1.4352588355541229e-01
    z[7,3,1]  R1923     1.7586836218833923e-01
    z[7,3,1]  R1924     4.2263475060462952e-01
    z[7,3,1]  R1925     2.6250369846820831e-02
    z[7,3,1]  R1926     -1.4274181798100471e-02
    z[7,3,1]  R1927     3.5868328809738159e-01
    z[7,3,1]  R1928     8.4278291463851929e-01
    z[7,3,1]  R1929     6.1004316806793213e-01
    z[7,3,1]  R1930     6.5526819229125977e-01
    z[7,3,1]  R1931     6.4741140604019165e-01
    z[7,3,1]  R1932     0.793921172618866
    z[7,3,1]  R1933     6.9187086820602417e-01
    z[7,3,1]  R1934     7.2983145713806152e-01
    z[7,3,1]  R1935     7.1048659086227417e-01
    z[7,3,1]  R1936     7.0828109979629517e-01
    z[7,3,1]  R1937     6.3068258762359619e-01
    z[7,3,1]  R1938     7.3375660181045532e-01
    z[7,3,1]  R1939     6.5386146306991577e-01
    z[7,3,1]  R1940     6.2505561113357544e-01
    z[7,3,1]  R1941     2.6948049664497375e-01
    z[7,3,1]  R1942     5.0554737448692322e-02
    z[7,3,1]  R1943     9.8127990961074829e-02
    z[7,3,1]  R1944     -3.9291703701019287e-01
    z[7,3,1]  R1945     -1.1177907884120941e-01
    z[7,3,1]  R1946     -2.9897859692573547e-01
    z[7,3,1]  R1947     3.5906076431274414e-01
    z[7,3,1]  R1948     3.8666567206382751e-01
    z[7,3,1]  R1949     2.4915374815464020e-01
    z[7,3,1]  R1950     2.0148459076881409e-01
    z[7,3,1]  R1951     2.9861399531364441e-01
    z[7,3,1]  R1952     -8.7873065471649170e-01
    z[7,3,1]  R1953     -7.7030980587005615e-01
    z[7,3,1]  R1954     -7.4472886323928833e-01
    z[7,3,1]  R1955     -7.0607739686965942e-01
    z[7,3,1]  R1956     -6.1061781644821167e-01
    z[7,3,1]  R1957     -5.8673632144927979e-01
    z[7,3,1]  R1958     5.6714862585067749e-01
    z[7,3,1]  R1959     6.0628509521484375e-01
    z[7,3,1]  R1960     6.5020549297332764e-01
    z[7,3,1]  R1961     -3.5180736333131790e-02
    z[7,3,1]  R1962     1.5650710463523865e-01
    z[7,3,1]  R1963     3.1514936685562134e-01
    z[7,3,1]  R1964     -1.5191204845905304e-01
    z[7,3,1]  R1965     -2.3847508430480957e-01
    z[7,3,1]  R1966     -8.9345580339431763e-01
    z[7,3,1]  R1967     -8.7426781654357910e-01
    z[7,3,1]  R1968     8.1471043825149536e-01
    z[7,3,1]  R1969     0.825800895690918
    z[7,3,1]  R1970     7.9975461959838867e-01
    z[7,3,1]  R1971     -7.1221423149108887e-01
    z[7,3,1]  R1972     -7.7294135093688965e-01
    z[7,3,1]  R1973     -7.2220253944396973e-01
    z[7,3,1]  R1974     -6.6316813230514526e-01
    z[7,3,1]  R1975     -6.6478884220123291e-01
    z[7,3,1]  R1976     -6.2566965818405151e-01
    z[7,3,1]  R1977     6.6959112882614136e-01
    z[7,3,1]  R1978     7.3697966337203979e-01
    z[7,3,1]  R1979     7.4696606397628784e-01
    z[7,3,1]  R1980     -0.578748345375061
    z[7,3,1]  R1981     5.0334107875823975e-01
    z[7,3,1]  R1982     1.3572555780410767e-01
    z[7,3,1]  R1983     0.361227422952652
    z[7,3,1]  R1984     -3.4717705845832825e-01
    z[7,3,1]  R1985     -8.4776496887207031e-01
    z[7,3,1]  R1986     9.0776854753494263e-01
    z[7,3,1]  R1987     -0.807357132434845
    z[7,3,1]  R1988     -8.0007779598236084e-01
    z[7,3,1]  R1989     -0.755072832107544
    z[7,3,1]  R1990     7.3512774705886841e-01
    z[7,3,1]  R1991     -6.8834644556045532e-01
    z[7,3,1]  R1992     1.4412263035774231e-01
    z[7,3,1]  R1993     -7.5586807727813721e-01
    z[7,3,1]  R1994     -7.2229963541030884e-01
    z[7,3,1]  R1995     1.0070722550153732e-01
    z[7,3,1]  R1996     1.9718358293175697e-02
    z[7,3,1]  R1997     1.5232196450233459e-01
    z[7,3,1]  R1998     2.2131569683551788e-01
    z[7,3,1]  R1999     0.0603828951716423
    z[7,3,1]  R2000     -2.1022692322731018e-02
    z[7,3,1]  R2001     1.4718034863471985e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1902     -1
    z[7,3,2]  R1903     1
    z[7,3,2]  R1912     -0.0832938700914383
    z[7,3,2]  R1913     7.8313037753105164e-02
    z[7,3,2]  R1914     1.8474750220775604e-01
    z[7,3,2]  R1915     1.7942178249359131e-01
    z[7,3,2]  R1916     -1.0637225210666656e-01
    z[7,3,2]  R1917     -4.5578071475028992e-01
    z[7,3,2]  R1918     1.4830625057220459e-01
    z[7,3,2]  R1919     -1.3196821324527264e-02
    z[7,3,2]  R1920     1.0675847530364990e-01
    z[7,3,2]  R1921     -2.0281404256820679e-02
    z[7,3,2]  R1922     -3.2566487789154053e-01
    z[7,3,2]  R1923     -0.0940450057387352
    z[7,3,2]  R1924     -4.0577489882707596e-02
    z[7,3,2]  R1925     -4.8938649892807007e-01
    z[7,3,2]  R1926     -7.5737267732620239e-02
    z[7,3,2]  R1927     -4.7218307852745056e-01
    z[7,3,2]  R1928     2.2482825815677643e-01
    z[7,3,2]  R1929     4.6637746691703796e-01
    z[7,3,2]  R1930     5.5652713775634766e-01
    z[7,3,2]  R1931     4.3382686376571655e-01
    z[7,3,2]  R1932     5.7313352823257446e-01
    z[7,3,2]  R1933     -3.0905985832214355e-01
    z[7,3,2]  R1934     -0.466251939535141
    z[7,3,2]  R1935     -8.3113173022866249e-03
    z[7,3,2]  R1936     1.0023440234363079e-02
    z[7,3,2]  R1937     0.0632082000374794
    z[7,3,2]  R1938     -2.7546146512031555e-01
    z[7,3,2]  R1939     -6.0453660786151886e-02
    z[7,3,2]  R1940     0.0542115643620491
    z[7,3,2]  R1941     1.9810880720615387e-01
    z[7,3,2]  R1942     -5.7450437545776367e-01
    z[7,3,2]  R1943     -5.4136312007904053e-01
    z[7,3,2]  R1944     -4.8270869255065918e-01
    z[7,3,2]  R1945     -6.6043287515640259e-01
    z[7,3,2]  R1946     1.9376932084560394e-01
    z[7,3,2]  R1947     -0.762722373008728
    z[7,3,2]  R1948     5.5558848381042480e-01
    z[7,3,2]  R1949     -5.3006899356842041e-01
    z[7,3,2]  R1950     1.7786386609077454e-01
    z[7,3,2]  R1951     3.8306677341461182e-01
    z[7,3,2]  R1952     1.2119157612323761e-01
    z[7,3,2]  R1953     -2.3542407155036926e-01
    z[7,3,2]  R1954     -7.2500328533351421e-03
    z[7,3,2]  R1955     -0.0172028299421072
    z[7,3,2]  R1956     2.1154652535915375e-01
    z[7,3,2]  R1957     8.4976553916931152e-02
    z[7,3,2]  R1958     -4.9993500113487244e-02
    z[7,3,2]  R1959     3.0862805247306824e-01
    z[7,3,2]  R1960     2.4009078741073608e-01
    z[7,3,2]  R1961     0.0586773082613945
    z[7,3,2]  R1962     2.2539477050304413e-01
    z[7,3,2]  R1963     1.4220415614545345e-02
    z[7,3,2]  R1964     -6.3256755471229553e-02
    z[7,3,2]  R1965     -1.6211499273777008e-01
    z[7,3,2]  R1966     -1.1996103823184967e-01
    z[7,3,2]  R1967     9.2876493930816650e-02
    z[7,3,2]  R1968     -4.4878937304019928e-02
    z[7,3,2]  R1969     3.0679382383823395e-02
    z[7,3,2]  R1970     1.7138579487800598e-01
    z[7,3,2]  R1971     8.4675490856170654e-02
    z[7,3,2]  R1972     1.3530911877751350e-02
    z[7,3,2]  R1973     2.7614161372184753e-01
    z[7,3,2]  R1974     -1.5526381134986877e-01
    z[7,3,2]  R1975     4.7609332203865051e-01
    z[7,3,2]  R1976     2.2000728547573090e-01
    z[7,3,2]  R1977     2.9708305001258850e-01
    z[7,3,2]  R1978     7.5209461152553558e-02
    z[7,3,2]  R1979     -1.4300939440727234e-01
    z[7,3,2]  R1980     1.3825416564941406e-01
    z[7,3,2]  R1981     5.0136047601699829e-01
    z[7,3,2]  R1982     1.3743334449827671e-02
    z[7,3,2]  R1983     -2.3087030649185181e-01
    z[7,3,2]  R1984     -2.7897748351097107e-01
    z[7,3,2]  R1985     -2.2459983825683594e-01
    z[7,3,2]  R1986     -0.21180360019207
    z[7,3,2]  R1987     -1.8946641683578491e-01
    z[7,3,2]  R1988     -1.6353523731231689e-01
    z[7,3,2]  R1989     -2.2070477902889252e-01
    z[7,3,2]  R1990     6.5782824531197548e-03
    z[7,3,2]  R1991     -3.8861316442489624e-01
    z[7,3,2]  R1992     1.6582390666007996e-01
    z[7,3,2]  R1993     -0.30942302942276
    z[7,3,2]  R1994     -2.1762351691722870e-01
    z[7,3,2]  R1995     3.2298988103866577e-01
    z[7,3,2]  R1996     6.7150115966796875e-02
    z[7,3,2]  R1997     4.4720417261123657e-01
    z[7,3,2]  R1998     4.0122170001268387e-02
    z[7,3,2]  R1999     1.4636841416358948e-01
    z[7,3,2]  R2000     1.9571933150291443e-01
    z[7,3,2]  R2001     1.6245013475418091e-01
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1904     -1
    z[7,3,3]  R1905     1
    z[7,3,3]  R1912     -5.3115785121917725e-01
    z[7,3,3]  R1913     -0.517676055431366
    z[7,3,3]  R1914     -4.5510104298591614e-01
    z[7,3,3]  R1915     1.4501862227916718e-01
    z[7,3,3]  R1916     5.4367440938949585e-01
    z[7,3,3]  R1917     -1.2788806855678558e-01
    z[7,3,3]  R1918     -2.4055039882659912e-01
    z[7,3,3]  R1919     -2.2824862599372864e-01
    z[7,3,3]  R1920     -2.6141172274947166e-02
    z[7,3,3]  R1921     0.362593412399292
    z[7,3,3]  R1922     -3.7873315811157227e-01
    z[7,3,3]  R1923     -3.8320377469062805e-01
    z[7,3,3]  R1924     -3.0686238408088684e-01
    z[7,3,3]  R1925     -1.0967943817377090e-02
    z[7,3,3]  R1926     8.8958166539669037e-02
    z[7,3,3]  R1927     -7.3784607648849487e-01
    z[7,3,3]  R1928     -1.4718878269195557e-01
    z[7,3,3]  R1929     -2.7771508693695068e-01
    z[7,3,3]  R1930     -3.1631910800933838e-01
    z[7,3,3]  R1931     -9.4376482069492340e-02
    z[7,3,3]  R1932     -2.9263095930218697e-03
    z[7,3,3]  R1933     2.9952365159988403e-01
    z[7,3,3]  R1934     3.1823712587356567e-01
    z[7,3,3]  R1935     5.2354931831359863e-01
    z[7,3,3]  R1936     -2.7067307382822037e-02
    z[7,3,3]  R1937     2.8740158677101135e-01
    z[7,3,3]  R1938     3.9176261425018311e-01
    z[7,3,3]  R1939     1.5172840654850006e-01
    z[7,3,3]  R1940     1.9516982138156891e-01
    z[7,3,3]  R1941     4.9416700005531311e-01
    z[7,3,3]  R1942     -5.5182403326034546e-01
    z[7,3,3]  R1943     -2.5081974267959595e-01
    z[7,3,3]  R1944     -3.1413015723228455e-01
    z[7,3,3]  R1945     -5.4775989055633545e-01
    z[7,3,3]  R1946     -5.4104810953140259e-01
    z[7,3,3]  R1947     -1.3957542367279530e-02
    z[7,3,3]  R1948     -3.8215351104736328e-01
    z[7,3,3]  R1949     -2.6786011457443237e-01
    z[7,3,3]  R1950     -4.9451878666877747e-01
    z[7,3,3]  R1951     -6.1520993709564209e-01
    z[7,3,3]  R1952     1.1706600338220596e-01
    z[7,3,3]  R1953     1.7956618964672089e-01
    z[7,3,3]  R1954     2.1216855943202972e-01
    z[7,3,3]  R1955     5.1769173145294189e-01
    z[7,3,3]  R1956     6.4694148302078247e-01
    z[7,3,3]  R1957     6.5466111898422241e-01
    z[7,3,3]  R1958     -1.8238945305347443e-01
    z[7,3,3]  R1959     4.4153988361358643e-01
    z[7,3,3]  R1960     3.9338329434394836e-01
    z[7,3,3]  R1961     0.610335648059845
    z[7,3,3]  R1962     6.5426409244537354e-02
    z[7,3,3]  R1963     4.9048196524381638e-02
    z[7,3,3]  R1964     -3.0986478924751282e-01
    z[7,3,3]  R1965     -1.7784656584262848e-01
    z[7,3,3]  R1966     1.1586633324623108e-01
    z[7,3,3]  R1967     -1.1492399126291275e-01
    z[7,3,3]  R1968     -2.9630091786384583e-01
    z[7,3,3]  R1969     2.5218906998634338e-01
    z[7,3,3]  R1970     -4.9235463142395020e-02
    z[7,3,3]  R1971     2.7134326100349426e-01
    z[7,3,3]  R1972     4.4782254099845886e-01
    z[7,3,3]  R1973     2.7273058891296387e-01
    z[7,3,3]  R1974     4.8097413033246994e-02
    z[7,3,3]  R1975     -5.0844904035329819e-02
    z[7,3,3]  R1976     -2.6202961802482605e-01
    z[7,3,3]  R1977     -5.7135045528411865e-02
    z[7,3,3]  R1978     4.1552387177944183e-02
    z[7,3,3]  R1979     3.9916276931762695e-02
    z[7,3,3]  R1980     5.5593556165695190e-01
    z[7,3,3]  R1981     3.3694509416818619e-02
    z[7,3,3]  R1982     2.4267129600048065e-01
    z[7,3,3]  R1983     -2.9687255620956421e-01
    z[7,3,3]  R1984     4.6162612736225128e-02
    z[7,3,3]  R1985     1.0166615247726440e-02
    z[7,3,3]  R1986     -0.074288509786129
    z[7,3,3]  R1987     2.5950086116790771e-01
    z[7,3,3]  R1988     4.0295529365539551e-01
    z[7,3,3]  R1989     3.8861134648323059e-01
    z[7,3,3]  R1990     -4.7248327732086182e-01
    z[7,3,3]  R1991     9.4653815031051636e-02
    z[7,3,3]  R1992     -5.4831784963607788e-01
    z[7,3,3]  R1993     3.3024334907531738e-01
    z[7,3,3]  R1994     -4.7218668460845947e-01
    z[7,3,3]  R1995     3.7375611066818237e-01
    z[7,3,3]  R1996     2.7929738163948059e-01
    z[7,3,3]  R1997     9.5742210745811462e-02
    z[7,3,3]  R1998     3.8788342475891113e-01
    z[7,3,3]  R1999     1.6844633221626282e-01
    z[7,3,3]  R2000     3.8832414150238037e-01
    z[7,3,3]  R2001     2.2806464135646820e-01
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1906     -1
    z[7,3,4]  R1907     1
    z[7,3,4]  R1912     2.0416952669620514e-01
    z[7,3,4]  R1913     3.3035805821418762e-01
    z[7,3,4]  R1914     -1.7304044961929321e-01
    z[7,3,4]  R1915     4.3810001015663147e-01
    z[7,3,4]  R1916     -2.5421399623155594e-02
    z[7,3,4]  R1917     2.4416697025299072e-01
    z[7,3,4]  R1918     -6.8618965148925781e-01
    z[7,3,4]  R1919     -1.9128118455410004e-01
    z[7,3,4]  R1920     1.0645785182714462e-01
    z[7,3,4]  R1921     1.9151549041271210e-01
    z[7,3,4]  R1922     -9.5341891050338745e-02
    z[7,3,4]  R1923     -2.3639196529984474e-02
    z[7,3,4]  R1924     -2.1149487793445587e-01
    z[7,3,4]  R1925     5.1366519182920456e-02
    z[7,3,4]  R1926     -7.3919579386711121e-02
    z[7,3,4]  R1927     8.4743246436119080e-02
    z[7,3,4]  R1928     -1.3100887835025787e-01
    z[7,3,4]  R1929     -3.0006036162376404e-01
    z[7,3,4]  R1930     5.8689940720796585e-02
    z[7,3,4]  R1931     1.6048046946525574e-01
    z[7,3,4]  R1932     -3.9442688226699829e-02
    z[7,3,4]  R1933     3.7176007032394409e-01
    z[7,3,4]  R1934     2.0438171923160553e-01
    z[7,3,4]  R1935     4.1999229788780212e-01
    z[7,3,4]  R1936     4.3914774060249329e-01
    z[7,3,4]  R1937     3.6389192938804626e-01
    z[7,3,4]  R1938     1.3818424940109253e-01
    z[7,3,4]  R1939     0.651690661907196
    z[7,3,4]  R1940     2.8211387991905212e-01
    z[7,3,4]  R1941     -1.8998704850673676e-01
    z[7,3,4]  R1942     3.8681440055370331e-02
    z[7,3,4]  R1943     -3.4683328866958618e-01
    z[7,3,4]  R1944     -3.0500268936157227e-01
    z[7,3,4]  R1945     4.3743055313825607e-02
    z[7,3,4]  R1946     1.3978804647922516e-01
    z[7,3,4]  R1947     -1.5404058992862701e-01
    z[7,3,4]  R1948     -0.0876581221818924
    z[7,3,4]  R1949     3.1593859195709229e-01
    z[7,3,4]  R1950     4.8961933702230453e-02
    z[7,3,4]  R1951     -1.2086918950080872e-01
    z[7,3,4]  R1952     -6.4705125987529755e-02
    z[7,3,4]  R1953     3.7865522503852844e-01
    z[7,3,4]  R1954     4.4442600011825562e-01
    z[7,3,4]  R1955     2.3144865036010742e-01
    z[7,3,4]  R1956     -2.1084553003311157e-01
    z[7,3,4]  R1957     1.6681958734989166e-01
    z[7,3,4]  R1958     -1.5593305230140686e-01
    z[7,3,4]  R1959     -0.275911420583725
    z[7,3,4]  R1960     -1.8377138674259186e-01
    z[7,3,4]  R1961     2.6651170849800110e-01
    z[7,3,4]  R1962     -1.0773171670734882e-03
    z[7,3,4]  R1963     -7.9781693220138550e-01
    z[7,3,4]  R1964     -5.2463328838348389e-01
    z[7,3,4]  R1965     -7.3747575283050537e-01
    z[7,3,4]  R1966     -4.4086609035730362e-02
    z[7,3,4]  R1967     1.6232788562774658e-01
    z[7,3,4]  R1968     3.2864493131637573e-01
    z[7,3,4]  R1969     2.0857295393943787e-01
    z[7,3,4]  R1970     0.376196026802063
    z[7,3,4]  R1971     -3.8204070925712585e-01
    z[7,3,4]  R1972     -2.7704018354415894e-01
    z[7,3,4]  R1973     -3.0748006701469421e-01
    z[7,3,4]  R1974     -2.4504117667675018e-01
    z[7,3,4]  R1975     1.9450557231903076e-01
    z[7,3,4]  R1976     -0.614127516746521
    z[7,3,4]  R1977     -4.1097548604011536e-01
    z[7,3,4]  R1978     1.3882963359355927e-01
    z[7,3,4]  R1979     -3.6934280395507812e-01
    z[7,3,4]  R1980     2.3542624711990356e-01
    z[7,3,4]  R1981     -2.0454618334770203e-01
    z[7,3,4]  R1982     -1.6884620487689972e-01
    z[7,3,4]  R1983     -6.3305526971817017e-01
    z[7,3,4]  R1984     -5.4552334547042847e-01
    z[7,3,4]  R1985     3.6771696805953979e-01
    z[7,3,4]  R1986     1.9974310696125031e-01
    z[7,3,4]  R1987     3.4017801284790039e-01
    z[7,3,4]  R1988     -2.6309159398078918e-01
    z[7,3,4]  R1989     2.5382652878761292e-02
    z[7,3,4]  R1990     -1.6438420116901398e-01
    z[7,3,4]  R1991     3.2526103314012289e-03
    z[7,3,4]  R1992     3.2445633411407471e-01
    z[7,3,4]  R1993     -1.4153721928596497e-01
    z[7,3,4]  R1994     -3.0477762222290039e-01
    z[7,3,4]  R1995     1.4489167928695679e-01
    z[7,3,4]  R1996     1.8020328879356384e-01
    z[7,3,4]  R1997     2.0290957391262054e-01
    z[7,3,4]  R1998     -6.0020685195922852e-02
    z[7,3,4]  R1999     3.7530052661895752e-01
    z[7,3,4]  R2000     1.0802821815013885e-01
    z[7,3,4]  R2001     1.0176397860050201e-01
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1908     -1
    z[7,3,5]  R1909     1
    z[7,3,5]  R1912     3.3638903498649597e-01
    z[7,3,5]  R1913     -1.9399334490299225e-01
    z[7,3,5]  R1914     6.7884378135204315e-02
    z[7,3,5]  R1915     4.1109851002693176e-01
    z[7,3,5]  R1916     -2.6039877533912659e-01
    z[7,3,5]  R1917     -0.304644912481308
    z[7,3,5]  R1918     -1.0937741026282310e-02
    z[7,3,5]  R1919     -7.4050599336624146e-01
    z[7,3,5]  R1920     -2.4446092545986176e-01
    z[7,3,5]  R1921     1.9868181645870209e-01
    z[7,3,5]  R1922     1.9656149670481682e-02
    z[7,3,5]  R1923     -2.7998128533363342e-01
    z[7,3,5]  R1924     2.9966005682945251e-01
    z[7,3,5]  R1925     3.5412353277206421e-01
    z[7,3,5]  R1926     0.386221319437027
    z[7,3,5]  R1927     -4.7760433517396450e-03
    z[7,3,5]  R1928     -2.2735865414142609e-01
    z[7,3,5]  R1929     2.6579296588897705e-01
    z[7,3,5]  R1930     2.4337849020957947e-01
    z[7,3,5]  R1931     4.2711076140403748e-01
    z[7,3,5]  R1932     -9.5728859305381775e-02
    z[7,3,5]  R1933     3.1036314368247986e-01
    z[7,3,5]  R1934     2.1151506900787354e-01
    z[7,3,5]  R1935     1.7396314442157745e-01
    z[7,3,5]  R1936     1.3783389329910278e-01
    z[7,3,5]  R1937     1.6777409613132477e-01
    z[7,3,5]  R1938     -0.27127605676651
    z[7,3,5]  R1939     -1.8786061555147171e-02
    z[7,3,5]  R1940     -1.1283921450376511e-01
    z[7,3,5]  R1941     -1.6121678054332733e-01
    z[7,3,5]  R1942     -1.3671287894248962e-01
    z[7,3,5]  R1943     5.4327660799026489e-01
    z[7,3,5]  R1944     2.7519872412085533e-02
    z[7,3,5]  R1945     -1.4023344218730927e-01
    z[7,3,5]  R1946     -6.8692475557327271e-02
    z[7,3,5]  R1947     1.1228796094655991e-02
    z[7,3,5]  R1948     -1.6981534659862518e-01
    z[7,3,5]  R1949     -5.6863898038864136e-01
    z[7,3,5]  R1950     -6.2710106372833252e-01
    z[7,3,5]  R1951     4.2931646108627319e-01
    z[7,3,5]  R1952     1.5785978734493256e-01
    z[7,3,5]  R1953     2.5563362240791321e-01
    z[7,3,5]  R1954     -0.317251980304718
    z[7,3,5]  R1955     0.415078729391098
    z[7,3,5]  R1956     -3.3079841732978821e-01
    z[7,3,5]  R1957     -3.9183324575424194e-01
    z[7,3,5]  R1958     1.9849547743797302e-01
    z[7,3,5]  R1959     2.5840106606483459e-01
    z[7,3,5]  R1960     -2.5410490110516548e-02
    z[7,3,5]  R1961     -1.7936001718044281e-01
    z[7,3,5]  R1962     3.9175990223884583e-01
    z[7,3,5]  R1963     6.6067695617675781e-02
    z[7,3,5]  R1964     7.2028040885925293e-01
    z[7,3,5]  R1965     4.3533289432525635e-01
    z[7,3,5]  R1966     4.0302121639251709e-01
    z[7,3,5]  R1967     3.1039389967918396e-01
    z[7,3,5]  R1968     8.8278248906135559e-02
    z[7,3,5]  R1969     3.7574744224548340e-01
    z[7,3,5]  R1970     1.4499436318874359e-01
    z[7,3,5]  R1971     -5.1070624589920044e-01
    z[7,3,5]  R1972     -2.2779320180416107e-01
    z[7,3,5]  R1973     4.5578092336654663e-02
    z[7,3,5]  R1974     -5.8653438091278076e-01
    z[7,3,5]  R1975     -4.6099528670310974e-01
    z[7,3,5]  R1976     -7.5132623314857483e-02
    z[7,3,5]  R1977     -2.4239070713520050e-01
    z[7,3,5]  R1978     -3.3351576328277588e-01
    z[7,3,5]  R1979     -3.1046655774116516e-01
    z[7,3,5]  R1980     -2.9368317127227783e-01
    z[7,3,5]  R1981     1.9626735150814056e-01
    z[7,3,5]  R1982     -1.4469853043556213e-01
    z[7,3,5]  R1983     -5.5544916540384293e-02
    z[7,3,5]  R1984     4.6312987804412842e-01
    z[7,3,5]  R1985     2.5895142927765846e-02
    z[7,3,5]  R1986     2.1338342130184174e-01
    z[7,3,5]  R1987     8.5565216839313507e-02
    z[7,3,5]  R1988     0.0840703547000885
    z[7,3,5]  R1989     -3.4614598751068115e-01
    z[7,3,5]  R1990     6.1836522072553635e-02
    z[7,3,5]  R1991     -1.8361641466617584e-01
    z[7,3,5]  R1992     3.1850022077560425e-01
    z[7,3,5]  R1993     -1.7846895754337311e-01
    z[7,3,5]  R1994     2.1995152533054352e-01
    z[7,3,5]  R1995     -3.9587166160345078e-02
    z[7,3,5]  R1996     -3.2489750534296036e-02
    z[7,3,5]  R1997     0.263158917427063
    z[7,3,5]  R1998     -2.4518856778740883e-02
    z[7,3,5]  R1999     7.6157540082931519e-02
    z[7,3,5]  R2000     2.9837989807128906e-01
    z[7,3,5]  R2001     2.2120243310928345e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1910     -1
    z[7,3,6]  R1911     1
    z[7,3,6]  R1912     -3.0690962448716164e-02
    z[7,3,6]  R1913     -1.2106040120124817e-01
    z[7,3,6]  R1914     4.1880896687507629e-01
    z[7,3,6]  R1915     2.0852467417716980e-01
    z[7,3,6]  R1916     -1.0769448429346085e-01
    z[7,3,6]  R1917     -6.8187125027179718e-02
    z[7,3,6]  R1918     -2.2787373512983322e-02
    z[7,3,6]  R1919     -5.5900763720273972e-02
    z[7,3,6]  R1920     1.4057008922100067e-01
    z[7,3,6]  R1921     5.3969401121139526e-01
    z[7,3,6]  R1922     2.0896056294441223e-01
    z[7,3,6]  R1923     0.0703059658408165
    z[7,3,6]  R1924     -3.1356176733970642e-01
    z[7,3,6]  R1925     -1.4374145865440369e-01
    z[7,3,6]  R1926     9.5743931829929352e-02
    z[7,3,6]  R1927     -2.7017101645469666e-01
    z[7,3,6]  R1928     0.377633661031723
    z[7,3,6]  R1929     1.1471087113022804e-02
    z[7,3,6]  R1930     -3.8736443966627121e-02
    z[7,3,6]  R1931     3.2835307717323303e-01
    z[7,3,6]  R1932     1.2709383852779865e-02
    z[7,3,6]  R1933     -1.4667297899723053e-01
    z[7,3,6]  R1934     8.2507297396659851e-02
    z[7,3,6]  R1935     1.0736383497714996e-01
    z[7,3,6]  R1936     -2.6166132092475891e-01
    z[7,3,6]  R1937     -1.9260872900485992e-01
    z[7,3,6]  R1938     -3.4314379096031189e-02
    z[7,3,6]  R1939     1.6094848513603210e-01
    z[7,3,6]  R1940     -6.2251168489456177e-01
    z[7,3,6]  R1941     -3.9175704121589661e-01
    z[7,3,6]  R1942     4.6168902516365051e-01
    z[7,3,6]  R1943     1.1097563803195953e-01
    z[7,3,6]  R1944     4.7059124708175659e-01
    z[7,3,6]  R1945     -1.1967720836400986e-01
    z[7,3,6]  R1946     5.3260743618011475e-01
    z[7,3,6]  R1947     3.1857562065124512e-01
    z[7,3,6]  R1948     1.5946796536445618e-01
    z[7,3,6]  R1949     2.4550843983888626e-02
    z[7,3,6]  R1950     4.2538964748382568e-01
    z[7,3,6]  R1951     -1.3276237249374390e-01
    z[7,3,6]  R1952     8.8356077671051025e-02
    z[7,3,6]  R1953     -0.0882168561220169
    z[7,3,6]  R1954     -2.5562165305018425e-02
    z[7,3,6]  R1955     -6.6741362214088440e-02
    z[7,3,6]  R1956     2.3195805028080940e-02
    z[7,3,6]  R1957     2.4579038843512535e-02
    z[7,3,6]  R1958     -3.8156315684318542e-01
    z[7,3,6]  R1959     -3.5968831181526184e-01
    z[7,3,6]  R1960     1.0943107306957245e-01
    z[7,3,6]  R1961     1.7770607769489288e-01
    z[7,3,6]  R1962     -3.1654992699623108e-01
    z[7,3,6]  R1963     -1.9747292995452881e-01
    z[7,3,6]  R1964     -1.3896332681179047e-01
    z[7,3,6]  R1965     5.6087784469127655e-02
    z[7,3,6]  R1966     -0.0659722089767456
    z[7,3,6]  R1967     -2.3645015060901642e-01
    z[7,3,6]  R1968     8.7271459400653839e-02
    z[7,3,6]  R1969     -2.1435341238975525e-01
    z[7,3,6]  R1970     1.7312683165073395e-01
    z[7,3,6]  R1971     4.4121686369180679e-02
    z[7,3,6]  R1972     2.3863058537244797e-02
    z[7,3,6]  R1973     3.4006141126155853e-02
    z[7,3,6]  R1974     3.3906292170286179e-02
    z[7,3,6]  R1975     -1.3650478422641754e-01
    z[7,3,6]  R1976     -3.2864677906036377e-01
    z[7,3,6]  R1977     -4.4955067336559296e-02
    z[7,3,6]  R1978     -4.1292348504066467e-01
    z[7,3,6]  R1979     -2.2485366463661194e-01
    z[7,3,6]  R1980     2.6155945658683777e-01
    z[7,3,6]  R1981     -1.4395545423030853e-01
    z[7,3,6]  R1982     -2.0372359454631805e-01
    z[7,3,6]  R1983     -2.5405132770538330e-01
    z[7,3,6]  R1984     -8.4806688129901886e-02
    z[7,3,6]  R1985     -1.4791491627693176e-01
    z[7,3,6]  R1986     -1.5384469926357269e-01
    z[7,3,6]  R1987     -1.2967227399349213e-01
    z[7,3,6]  R1988     3.0735993385314941e-01
    z[7,3,6]  R1989     2.7324759867042303e-03
    z[7,3,6]  R1990     -2.9068564996123314e-02
    z[7,3,6]  R1991     5.2781653404235840e-01
    z[7,3,6]  R1992     -2.3362050950527191e-01
    z[7,3,6]  R1993     1.3652274012565613e-01
    z[7,3,6]  R1994     4.8345115035772324e-02
    z[7,3,6]  R1995     9.5223180949687958e-02
    z[7,3,6]  R1996     4.2157445102930069e-02
    z[7,3,6]  R1997     5.9282500296831131e-03
    z[7,3,6]  R1998     -1.5103885531425476e-01
    z[7,3,6]  R1999     -3.9183810353279114e-02
    z[7,3,6]  R2000     -0.0802641361951828
    z[7,3,6]  R2001     -4.7107253223657608e-02
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2076     -1
    z[4,5,0]  R2077     1
    z[4,5,0]  R2090     2.4772234261035919e-01
    z[4,5,0]  R2091     2.4696488678455353e-01
    z[4,5,0]  R2092     3.6294525861740112e-01
    z[4,5,0]  R2093     -8.6895838379859924e-02
    z[4,5,0]  R2094     -2.8850749135017395e-01
    z[4,5,0]  R2095     -5.8941280841827393e-01
    z[4,5,0]  R2096     -4.5666575431823730e-01
    z[4,5,0]  R2097     -6.8102669715881348e-01
    z[4,5,0]  R2098     1.6378079354763031e-01
    z[4,5,0]  R2099     -7.7737474441528320e-01
    z[4,5,0]  R2100     4.2044779658317566e-01
    z[4,5,0]  R2101     4.9880540370941162e-01
    z[4,5,0]  R2102     -1.2612174451351166e-01
    z[4,5,0]  R2103     -4.1878500580787659e-01
    z[4,5,0]  R2104     2.1678902208805084e-01
    z[4,5,0]  R2105     -1.3231416046619415e-01
    z[4,5,0]  R2106     0.0712457224726677
    z[4,5,0]  R2107     7.9802796244621277e-02
    z[4,5,0]  R2108     -2.8022137284278870e-01
    z[4,5,0]  R2109     9.2771604657173157e-02
    z[4,5,0]  R2110     5.8583840727806091e-02
    z[4,5,0]  R2111     3.5452548414468765e-02
    z[4,5,0]  R2112     -1.6146329045295715e-01
    z[4,5,0]  R2113     -4.4147886335849762e-02
    z[4,5,0]  R2114     1.3029080629348755e-01
    z[4,5,0]  R2115     -4.9732866883277893e-01
    z[4,5,0]  R2116     -3.5069355368614197e-01
    z[4,5,0]  R2117     3.1645726412534714e-02
    z[4,5,0]  R2118     8.7404318153858185e-02
    z[4,5,0]  R2119     -0.0250399112701416
    z[4,5,0]  R2120     -2.7012780308723450e-02
    z[4,5,0]  R2121     -2.1615663170814514e-01
    z[4,5,0]  R2122     -2.8485766053199768e-01
    z[4,5,0]  R2123     -3.6229911446571350e-01
    z[4,5,0]  R2124     -6.1006546020507812e-01
    z[4,5,0]  R2125     -5.8062785863876343e-01
    z[4,5,0]  R2126     -6.0760623216629028e-01
    z[4,5,0]  R2127     6.8481421470642090e-01
    z[4,5,0]  R2128     4.2407432198524475e-01
    z[4,5,0]  R2129     4.7219285368919373e-01
    z[4,5,0]  R2130     2.9902374744415283e-01
    z[4,5,0]  R2131     0.471809983253479
    z[4,5,0]  R2132     0.557436466217041
    z[4,5,0]  R2133     4.0043455362319946e-01
    z[4,5,0]  R2134     4.1340434551239014e-01
    z[4,5,0]  R2135     5.8189934492111206e-01
    z[4,5,0]  R2136     -1.5772767364978790e-01
    z[4,5,0]  R2137     -2.9264262318611145e-01
    z[4,5,0]  R2138     2.9907515645027161e-01
    z[4,5,0]  R2139     1.0870525985956192e-01
    z[4,5,0]  R2140     4.1055597364902496e-02
    z[4,5,0]  R2141     3.0551312491297722e-02
    z[4,5,0]  R2142     -1.6856157779693604e-01
    z[4,5,0]  R2143     -2.2263364493846893e-01
    z[4,5,0]  R2144     -2.1212583780288696e-01
    z[4,5,0]  R2145     -3.8890343159437180e-02
    z[4,5,0]  R2146     -4.6333214640617371e-01
    z[4,5,0]  R2147     6.4265592955052853e-03
    z[4,5,0]  R2148     -3.6780755966901779e-02
    z[4,5,0]  R2149     -2.7314704656600952e-01
    z[4,5,0]  R2150     -3.8201864808797836e-02
    z[4,5,0]  R2151     -3.4061646461486816e-01
    z[4,5,0]  R2152     -3.0403605103492737e-01
    z[4,5,0]  R2153     4.5423296093940735e-01
    z[4,5,0]  R2154     -4.1578122973442078e-01
    z[4,5,0]  R2155     -3.0241400003433228e-01
    z[4,5,0]  R2156     3.4000226855278015e-01
    z[4,5,0]  R2157     -1.1205981671810150e-01
    z[4,5,0]  R2158     7.9000806808471680e-01
    z[4,5,0]  R2159     5.3096508979797363e-01
    z[4,5,0]  R2160     2.3741620779037476e-01
    z[4,5,0]  R2161     5.5252593010663986e-02
    z[4,5,0]  R2162     6.1953570693731308e-02
    z[4,5,0]  R2163     3.7581798434257507e-01
    z[4,5,0]  R2164     -0.425283819437027
    z[4,5,0]  R2165     2.7152949571609497e-01
    z[4,5,0]  R2166     -4.0629756450653076e-01
    z[4,5,0]  R2167     -9.1883011162281036e-02
    z[4,5,0]  R2168     3.7221607565879822e-01
    z[4,5,0]  R2169     1.4681921899318695e-01
    z[4,5,0]  R2170     4.0812635421752930e-01
    z[4,5,0]  R2171     2.3946161568164825e-01
    z[4,5,0]  R2172     -5.7091158628463745e-01
    z[4,5,0]  R2173     -7.7465665340423584e-01
    z[4,5,0]  R2174     -6.2244963645935059e-01
    z[4,5,0]  R2175     -2.3654049634933472e-01
    z[4,5,0]  R2176     -3.8324549794197083e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2078     -1
    z[4,5,1]  R2079     1
    z[4,5,1]  R2090     1.4595788717269897e-01
    z[4,5,1]  R2091     -3.5114955902099609e-01
    z[4,5,1]  R2092     -4.1777870059013367e-01
    z[4,5,1]  R2093     6.1551898717880249e-02
    z[4,5,1]  R2094     1.3498616218566895e-01
    z[4,5,1]  R2095     -2.5606042146682739e-01
    z[4,5,1]  R2096     -1.7154380679130554e-01
    z[4,5,1]  R2097     -5.9940207004547119e-01
    z[4,5,1]  R2098     2.0661603659391403e-02
    z[4,5,1]  R2099     -3.7383487820625305e-01
    z[4,5,1]  R2100     -3.1460642814636230e-01
    z[4,5,1]  R2101     6.7527025938034058e-01
    z[4,5,1]  R2102     -4.2850311729125679e-04
    z[4,5,1]  R2103     2.1219305694103241e-02
    z[4,5,1]  R2104     4.2749759554862976e-01
    z[4,5,1]  R2105     4.1486227512359619e-01
    z[4,5,1]  R2106     -1.2789431214332581e-01
    z[4,5,1]  R2107     1.4151163399219513e-01
    z[4,5,1]  R2108     3.4211838245391846e-01
    z[4,5,1]  R2109     3.2706397771835327e-01
    z[4,5,1]  R2110     -2.5861749053001404e-01
    z[4,5,1]  R2111     1.7459358274936676e-01
    z[4,5,1]  R2112     -4.4919971376657486e-02
    z[4,5,1]  R2113     2.0421484112739563e-01
    z[4,5,1]  R2114     4.0388610959053040e-01
    z[4,5,1]  R2115     1.8536414951086044e-02
    z[4,5,1]  R2116     -7.0024833083152771e-02
    z[4,5,1]  R2117     3.2747775316238403e-01
    z[4,5,1]  R2118     2.3994833230972290e-01
    z[4,5,1]  R2119     2.8354302048683167e-01
    z[4,5,1]  R2120     -4.4861879199743271e-02
    z[4,5,1]  R2121     5.6180745363235474e-02
    z[4,5,1]  R2122     8.0625161528587341e-02
    z[4,5,1]  R2123     1.1535218358039856e-01
    z[4,5,1]  R2124     -7.6415991783142090e-01
    z[4,5,1]  R2125     -0.756704568862915
    z[4,5,1]  R2126     -7.4083060026168823e-01
    z[4,5,1]  R2127     -8.1086881458759308e-02
    z[4,5,1]  R2128     -6.2803596258163452e-02
    z[4,5,1]  R2129     -3.4306907653808594e-01
    z[4,5,1]  R2130     -1.9525711238384247e-01
    z[4,5,1]  R2131     -4.2736664414405823e-01
    z[4,5,1]  R2132     3.7686202675104141e-02
    z[4,5,1]  R2133     8.1025041639804840e-02
    z[4,5,1]  R2134     -5.9450343251228333e-02
    z[4,5,1]  R2135     1.1442169547080994e-01
    z[4,5,1]  R2136     1.1627613753080368e-01
    z[4,5,1]  R2137     6.6820508241653442e-01
    z[4,5,1]  R2138     -7.8152108192443848e-01
    z[4,5,1]  R2139     -8.5610884428024292e-01
    z[4,5,1]  R2140     -8.3617657423019409e-01
    z[4,5,1]  R2141     -8.7166756391525269e-01
    z[4,5,1]  R2142     6.8277293443679810e-01
    z[4,5,1]  R2143     -8.6038815975189209e-01
    z[4,5,1]  R2144     -8.2086509466171265e-01
    z[4,5,1]  R2145     -7.5712805986404419e-01
    z[4,5,1]  R2146     0.513932466506958
    z[4,5,1]  R2147     7.9905492067337036e-01
    z[4,5,1]  R2148     5.6476676464080811e-01
    z[4,5,1]  R2149     7.2334295511245728e-01
    z[4,5,1]  R2150     6.2016886472702026e-01
    z[4,5,1]  R2151     5.9186714887619019e-01
    z[4,5,1]  R2152     6.1776363849639893e-01
    z[4,5,1]  R2153     7.4573993682861328e-01
    z[4,5,1]  R2154     7.5574219226837158e-01
    z[4,5,1]  R2155     9.0976518392562866e-01
    z[4,5,1]  R2156     7.1882611513137817e-01
    z[4,5,1]  R2157     3.0438011884689331e-01
    z[4,5,1]  R2158     -4.9998942762613297e-02
    z[4,5,1]  R2159     -0.732832133769989
    z[4,5,1]  R2160     5.9587860107421875e-01
    z[4,5,1]  R2161     -7.4152338504791260e-01
    z[4,5,1]  R2162     5.1899129152297974e-01
    z[4,5,1]  R2163     4.2850050330162048e-01
    z[4,5,1]  R2164     6.1402846127748489e-02
    z[4,5,1]  R2165     3.9935836195945740e-01
    z[4,5,1]  R2166     -1.1253734678030014e-01
    z[4,5,1]  R2167     4.6186193823814392e-01
    z[4,5,1]  R2168     -8.9172267913818359e-01
    z[4,5,1]  R2169     7.1494489908218384e-01
    z[4,5,1]  R2170     5.7863938808441162e-01
    z[4,5,1]  R2171     5.5286550521850586e-01
    z[4,5,1]  R2172     -7.4655382195487618e-04
    z[4,5,1]  R2173     -1.5049608051776886e-01
    z[4,5,1]  R2174     -7.8971035778522491e-02
    z[4,5,1]  R2175     -2.5156855583190918e-01
    z[4,5,1]  R2176     -6.4073219895362854e-02
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2080     -1
    z[4,5,2]  R2081     1
    z[4,5,2]  R2090     2.2578868269920349e-01
    z[4,5,2]  R2091     -4.8831388354301453e-01
    z[4,5,2]  R2092     2.3956601321697235e-01
    z[4,5,2]  R2093     -9.2622911930084229e-01
    z[4,5,2]  R2094     -5.6925896555185318e-02
    z[4,5,2]  R2095     1.8781113624572754e-01
    z[4,5,2]  R2096     4.5199862122535706e-01
    z[4,5,2]  R2097     2.2137674689292908e-01
    z[4,5,2]  R2098     3.0540555715560913e-01
    z[4,5,2]  R2099     1.8160057067871094e-01
    z[4,5,2]  R2100     1.8379474058747292e-02
    z[4,5,2]  R2101     1.0136752575635910e-01
    z[4,5,2]  R2102     0.719666063785553
    z[4,5,2]  R2103     -3.1923856586217880e-02
    z[4,5,2]  R2104     -1.0549058765172958e-01
    z[4,5,2]  R2105     1.2692656368017197e-02
    z[4,5,2]  R2106     -0.097258560359478
    z[4,5,2]  R2107     2.4996910989284515e-01
    z[4,5,2]  R2108     4.1910886764526367e-02
    z[4,5,2]  R2109     3.1649264693260193e-01
    z[4,5,2]  R2110     -3.3787362277507782e-02
    z[4,5,2]  R2111     -3.2035586237907410e-01
    z[4,5,2]  R2112     6.3951745629310608e-02
    z[4,5,2]  R2113     0.658301830291748
    z[4,5,2]  R2114     4.8984782770276070e-03
    z[4,5,2]  R2115     3.0478018522262573e-01
    z[4,5,2]  R2116     6.9895529747009277e-01
    z[4,5,2]  R2117     8.5863113403320312e-02
    z[4,5,2]  R2118     -1.6348041594028473e-02
    z[4,5,2]  R2119     1.1734221875667572e-01
    z[4,5,2]  R2120     -1.5207682549953461e-01
    z[4,5,2]  R2121     4.1668361425399780e-01
    z[4,5,2]  R2122     1.6104342043399811e-01
    z[4,5,2]  R2123     2.7280882000923157e-01
    z[4,5,2]  R2124     5.7944428175687790e-02
    z[4,5,2]  R2125     1.0019752383232117e-01
    z[4,5,2]  R2126     1.4930146932601929e-01
    z[4,5,2]  R2127     -4.9701955914497375e-01
    z[4,5,2]  R2128     -4.9604868888854980e-01
    z[4,5,2]  R2129     -4.8486655950546265e-01
    z[4,5,2]  R2130     -2.7913671731948853e-01
    z[4,5,2]  R2131     -9.4179607927799225e-02
    z[4,5,2]  R2132     -3.9441445469856262e-01
    z[4,5,2]  R2133     -5.9366188943386078e-02
    z[4,5,2]  R2134     -7.4587929248809814e-01
    z[4,5,2]  R2135     -3.0251011252403259e-01
    z[4,5,2]  R2136     -9.3451154232025146e-01
    z[4,5,2]  R2137     1.1230071634054184e-01
    z[4,5,2]  R2138     5.0350213050842285e-01
    z[4,5,2]  R2139     -7.9214975237846375e-02
    z[4,5,2]  R2140     4.4775810837745667e-01
    z[4,5,2]  R2141     6.5615884959697723e-02
    z[4,5,2]  R2142     3.6876353621482849e-01
    z[4,5,2]  R2143     1.0235640406608582e-01
    z[4,5,2]  R2144     0.285470187664032
    z[4,5,2]  R2145     4.4804835319519043e-01
    z[4,5,2]  R2146     -2.7570006251335144e-01
    z[4,5,2]  R2147     -3.4256786108016968e-01
    z[4,5,2]  R2148     -6.4214640855789185e-01
    z[4,5,2]  R2149     -4.3363049626350403e-01
    z[4,5,2]  R2150     -5.2234929800033569e-01
    z[4,5,2]  R2151     -5.8482336997985840e-01
    z[4,5,2]  R2152     -6.3599956035614014e-01
    z[4,5,2]  R2153     -4.3129000067710876e-01
    z[4,5,2]  R2154     -3.1067979335784912e-01
    z[4,5,2]  R2155     1.2998823076486588e-02
    z[4,5,2]  R2156     1.3436928391456604e-01
    z[4,5,2]  R2157     -8.5875076055526733e-01
    z[4,5,2]  R2158     3.4931668639183044e-01
    z[4,5,2]  R2159     -1.3806378841400146e-01
    z[4,5,2]  R2160     5.3474318981170654e-01
    z[4,5,2]  R2161     4.8715031147003174e-01
    z[4,5,2]  R2162     7.9511761665344238e-01
    z[4,5,2]  R2163     6.2353795766830444e-01
    z[4,5,2]  R2164     4.3923398852348328e-01
    z[4,5,2]  R2165     6.3465487957000732e-01
    z[4,5,2]  R2166     6.8603628873825073e-01
    z[4,5,2]  R2167     -5.9742176532745361e-01
    z[4,5,2]  R2168     -3.2313343137502670e-02
    z[4,5,2]  R2169     5.7549959421157837e-01
    z[4,5,2]  R2170     5.0004667043685913e-01
    z[4,5,2]  R2171     7.4372583627700806e-01
    z[4,5,2]  R2172     3.8138604164123535e-01
    z[4,5,2]  R2173     4.4182300567626953e-01
    z[4,5,2]  R2174     -3.1139988452196121e-02
    z[4,5,2]  R2175     -2.3227233439683914e-02
    z[4,5,2]  R2176     3.3875235915184021e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2082     -1
    z[4,5,3]  R2083     1
    z[4,5,3]  R2090     -8.6045974493026733e-01
    z[4,5,3]  R2091     -1.4862245321273804e-01
    z[4,5,3]  R2092     -1.6409538686275482e-02
    z[4,5,3]  R2093     -2.5952234864234924e-01
    z[4,5,3]  R2094     1.7812801524996758e-02
    z[4,5,3]  R2095     8.6579039692878723e-02
    z[4,5,3]  R2096     8.2425296306610107e-02
    z[4,5,3]  R2097     -8.2052469253540039e-02
    z[4,5,3]  R2098     3.0150455236434937e-01
    z[4,5,3]  R2099     -1.7092892527580261e-01
    z[4,5,3]  R2100     -8.4106504917144775e-02
    z[4,5,3]  R2101     2.7513271570205688e-01
    z[4,5,3]  R2102     4.0931177139282227e-01
    z[4,5,3]  R2103     6.1861896514892578e-01
    z[4,5,3]  R2104     5.9167939424514771e-01
    z[4,5,3]  R2105     5.5876374244689941e-01
    z[4,5,3]  R2106     3.9200946688652039e-01
    z[4,5,3]  R2107     4.5328933000564575e-01
    z[4,5,3]  R2108     4.8418885469436646e-01
    z[4,5,3]  R2109     4.8538509011268616e-01
    z[4,5,3]  R2110     0.664361834526062
    z[4,5,3]  R2111     0.720909833908081
    z[4,5,3]  R2112     0.516990602016449
    z[4,5,3]  R2113     6.9094288349151611e-01
    z[4,5,3]  R2114     5.9732836484909058e-01
    z[4,5,3]  R2115     6.3530176877975464e-01
    z[4,5,3]  R2116     0.408335417509079
    z[4,5,3]  R2117     5.4951918125152588e-01
    z[4,5,3]  R2118     4.5598819851875305e-01
    z[4,5,3]  R2119     6.2091869115829468e-01
    z[4,5,3]  R2120     7.3603373765945435e-01
    z[4,5,3]  R2121     6.5980148315429688e-01
    z[4,5,3]  R2122     6.3465386629104614e-01
    z[4,5,3]  R2123     0.608033299446106
    z[4,5,3]  R2124     -1.8308252096176147e-02
    z[4,5,3]  R2125     -1.7723189294338226e-01
    z[4,5,3]  R2126     1.3498324155807495e-01
    z[4,5,3]  R2127     -3.5028973221778870e-01
    z[4,5,3]  R2128     -8.2846589386463165e-02
    z[4,5,3]  R2129     3.2014327589422464e-03
    z[4,5,3]  R2130     -1.4209325611591339e-01
    z[4,5,3]  R2131     7.1378417313098907e-02
    z[4,5,3]  R2132     2.7369028329849243e-01
    z[4,5,3]  R2133     1.1251424252986908e-01
    z[4,5,3]  R2134     -2.3168994486331940e-01
    z[4,5,3]  R2135     -2.6467078924179077e-01
    z[4,5,3]  R2136     1.0491105914115906e-01
    z[4,5,3]  R2137     0.0898166075348854
    z[4,5,3]  R2138     -1.1651634424924850e-01
    z[4,5,3]  R2139     -2.1026555448770523e-02
    z[4,5,3]  R2140     6.8229183554649353e-02
    z[4,5,3]  R2141     1.2749873101711273e-01
    z[4,5,3]  R2142     4.5084267854690552e-02
    z[4,5,3]  R2143     2.7704444527626038e-01
    z[4,5,3]  R2144     0.355803906917572
    z[4,5,3]  R2145     2.7114561200141907e-01
    z[4,5,3]  R2146     2.5887799263000488e-01
    z[4,5,3]  R2147     -2.9570633172988892e-01
    z[4,5,3]  R2148     -1.3546113669872284e-01
    z[4,5,3]  R2149     1.8554992973804474e-01
    z[4,5,3]  R2150     -1.0255632549524307e-01
    z[4,5,3]  R2151     6.0594443231821060e-02
    z[4,5,3]  R2152     1.5278393030166626e-01
    z[4,5,3]  R2153     6.0688290745019913e-02
    z[4,5,3]  R2154     1.1022411286830902e-01
    z[4,5,3]  R2155     6.9968298077583313e-02
    z[4,5,3]  R2156     -3.5158935189247131e-01
    z[4,5,3]  R2157     1.0737839341163635e-01
    z[4,5,3]  R2158     1.6416235268115997e-01
    z[4,5,3]  R2159     -1.6629289090633392e-01
    z[4,5,3]  R2160     1.3947841711342335e-02
    z[4,5,3]  R2161     2.2214072942733765e-01
    z[4,5,3]  R2162     -1.9584783911705017e-01
    z[4,5,3]  R2163     0.281126469373703
    z[4,5,3]  R2164     -5.7939112186431885e-01
    z[4,5,3]  R2165     5.0716590881347656e-01
    z[4,5,3]  R2166     -3.6588475108146667e-01
    z[4,5,3]  R2167     -7.0546649396419525e-02
    z[4,5,3]  R2168     -0.0752662867307663
    z[4,5,3]  R2169     8.5963584482669830e-02
    z[4,5,3]  R2170     3.4735634922981262e-01
    z[4,5,3]  R2171     7.2962991893291473e-02
    z[4,5,3]  R2172     -6.3346517086029053e-01
    z[4,5,3]  R2173     -3.9998832345008850e-01
    z[4,5,3]  R2174     -0.642842173576355
    z[4,5,3]  R2175     3.7850666791200638e-02
    z[4,5,3]  R2176     1.6396088898181915e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2084     -1
    z[4,5,4]  R2085     1
    z[4,5,4]  R2090     -4.3812990188598633e-02
    z[4,5,4]  R2091     -2.3397125303745270e-01
    z[4,5,4]  R2092     4.8334822058677673e-01
    z[4,5,4]  R2093     8.1369958817958832e-02
    z[4,5,4]  R2094     4.1641953587532043e-01
    z[4,5,4]  R2095     -7.0744216442108154e-01
    z[4,5,4]  R2096     -7.0412427186965942e-01
    z[4,5,4]  R2097     -3.2751148939132690e-01
    z[4,5,4]  R2098     -7.7893167734146118e-01
    z[4,5,4]  R2099     -1.9485269486904144e-01
    z[4,5,4]  R2100     -1.3611069321632385e-01
    z[4,5,4]  R2101     3.5755693912506104e-01
    z[4,5,4]  R2102     9.4899103045463562e-02
    z[4,5,4]  R2103     -5.7386392354965210e-01
    z[4,5,4]  R2104     -5.0568145513534546e-01
    z[4,5,4]  R2105     -0.574921190738678
    z[4,5,4]  R2106     -7.2078096866607666e-01
    z[4,5,4]  R2107     -8.1240636110305786e-01
    z[4,5,4]  R2108     -7.3139494657516479e-01
    z[4,5,4]  R2109     -4.9469089508056641e-01
    z[4,5,4]  R2110     -6.0339617729187012e-01
    z[4,5,4]  R2111     -5.5495953559875488e-01
    z[4,5,4]  R2112     -5.7392561435699463e-01
    z[4,5,4]  R2113     1.4989911019802094e-01
    z[4,5,4]  R2114     -6.0175734758377075e-01
    z[4,5,4]  R2115     9.2814810574054718e-02
    z[4,5,4]  R2116     1.5847903490066528e-01
    z[4,5,4]  R2117     -5.4320687055587769e-01
    z[4,5,4]  R2118     -8.4174668788909912e-01
    z[4,5,4]  R2119     -6.2490385770797729e-01
    z[4,5,4]  R2120     -6.0696178674697876e-01
    z[4,5,4]  R2121     2.7905102819204330e-02
    z[4,5,4]  R2122     -6.7005246877670288e-01
    z[4,5,4]  R2123     -6.2093317508697510e-01
    z[4,5,4]  R2124     4.1517388075590134e-02
    z[4,5,4]  R2125     -1.3797618448734283e-01
    z[4,5,4]  R2126     -1.8680550158023834e-01
    z[4,5,4]  R2127     -1.5760441124439240e-01
    z[4,5,4]  R2128     -0.446170449256897
    z[4,5,4]  R2129     1.4418350160121918e-01
    z[4,5,4]  R2130     2.7568724751472473e-01
    z[4,5,4]  R2131     -1.8833811581134796e-01
    z[4,5,4]  R2132     4.8487776517868042e-01
    z[4,5,4]  R2133     -1.1457122862339020e-01
    z[4,5,4]  R2134     4.2632073163986206e-01
    z[4,5,4]  R2135     -3.1137070059776306e-01
    z[4,5,4]  R2136     1.9011422991752625e-01
    z[4,5,4]  R2137     -2.8852125629782677e-02
    z[4,5,4]  R2138     4.2678169906139374e-02
    z[4,5,4]  R2139     2.9173517227172852e-01
    z[4,5,4]  R2140     1.2564468383789062e-01
    z[4,5,4]  R2141     1.3905872404575348e-01
    z[4,5,4]  R2142     -4.8676499724388123e-01
    z[4,5,4]  R2143     2.2104050219058990e-01
    z[4,5,4]  R2144     -2.9736701399087906e-02
    z[4,5,4]  R2145     -3.0702257156372070e-01
    z[4,5,4]  R2146     -2.6921811699867249e-01
    z[4,5,4]  R2147     0.3248310983181
    z[4,5,4]  R2148     -1.3797611929476261e-02
    z[4,5,4]  R2149     -3.2528871297836304e-01
    z[4,5,4]  R2150     -2.8412604331970215e-01
    z[4,5,4]  R2151     9.5781035721302032e-02
    z[4,5,4]  R2152     -1.1825407296419144e-01
    z[4,5,4]  R2153     -4.2378310114145279e-02
    z[4,5,4]  R2154     3.1653138995170593e-01
    z[4,5,4]  R2155     -2.2756111621856689e-01
    z[4,5,4]  R2156     -4.3291386961936951e-01
    z[4,5,4]  R2157     1.3337983749806881e-02
    z[4,5,4]  R2158     1.0181195288896561e-01
    z[4,5,4]  R2159     -3.2449635863304138e-01
    z[4,5,4]  R2160     2.5695082545280457e-01
    z[4,5,4]  R2161     -1.6070288419723511e-01
    z[4,5,4]  R2162     7.1187183260917664e-02
    z[4,5,4]  R2163     2.2787061333656311e-01
    z[4,5,4]  R2164     9.6975639462471008e-02
    z[4,5,4]  R2165     1.7501041293144226e-01
    z[4,5,4]  R2166     -3.1704951077699661e-02
    z[4,5,4]  R2167     3.8346165418624878e-01
    z[4,5,4]  R2168     8.7240047752857208e-02
    z[4,5,4]  R2169     1.6404733061790466e-01
    z[4,5,4]  R2170     -0.103693388402462
    z[4,5,4]  R2171     -2.4617625400424004e-02
    z[4,5,4]  R2172     7.9239696264266968e-02
    z[4,5,4]  R2173     -7.7282056212425232e-02
    z[4,5,4]  R2174     4.3240282684564590e-02
    z[4,5,4]  R2175     2.2247716784477234e-01
    z[4,5,4]  R2176     3.1550772488117218e-02
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2086     -1
    z[4,5,5]  R2087     1
    z[4,5,5]  R2090     0.0973777249455452
    z[4,5,5]  R2091     -6.8293410539627075e-01
    z[4,5,5]  R2092     -5.8425325155258179e-01
    z[4,5,5]  R2093     -1.4632146060466766e-01
    z[4,5,5]  R2094     -6.9484394788742065e-01
    z[4,5,5]  R2095     1.8580364063382149e-02
    z[4,5,5]  R2096     1.9190703332424164e-01
    z[4,5,5]  R2097     3.4785460680723190e-02
    z[4,5,5]  R2098     1.9320763647556305e-01
    z[4,5,5]  R2099     2.2605451941490173e-01
    z[4,5,5]  R2100     5.9355276823043823e-01
    z[4,5,5]  R2101     2.0836704969406128e-01
    z[4,5,5]  R2102     3.9777347445487976e-01
    z[4,5,5]  R2103     7.5879737734794617e-02
    z[4,5,5]  R2104     3.1614589691162109e-01
    z[4,5,5]  R2105     4.0916091203689575e-01
    z[4,5,5]  R2106     3.5511884093284607e-01
    z[4,5,5]  R2107     -2.9819600284099579e-02
    z[4,5,5]  R2108     9.0072564780712128e-02
    z[4,5,5]  R2109     4.4309636950492859e-01
    z[4,5,5]  R2110     1.6005451977252960e-01
    z[4,5,5]  R2111     1.9110429286956787e-01
    z[4,5,5]  R2112     4.8027086257934570e-01
    z[4,5,5]  R2113     1.4256159961223602e-01
    z[4,5,5]  R2114     3.0097925662994385e-01
    z[4,5,5]  R2115     4.9623328447341919e-01
    z[4,5,5]  R2116     4.3775799870491028e-01
    z[4,5,5]  R2117     2.6191705465316772e-01
    z[4,5,5]  R2118     7.4255662038922310e-03
    z[4,5,5]  R2119     -3.1197839975357056e-01
    z[4,5,5]  R2120     3.0499780550599098e-02
    z[4,5,5]  R2121     4.5033949613571167e-01
    z[4,5,5]  R2122     -1.5306897461414337e-01
    z[4,5,5]  R2123     1.4283972978591919e-01
    z[4,5,5]  R2124     1.1083095520734787e-01
    z[4,5,5]  R2125     1.1505434662103653e-01
    z[4,5,5]  R2126     8.1059344112873077e-02
    z[4,5,5]  R2127     -2.6819872856140137e-01
    z[4,5,5]  R2128     -5.8968561887741089e-01
    z[4,5,5]  R2129     -6.0464257001876831e-01
    z[4,5,5]  R2130     -8.3057153224945068e-01
    z[4,5,5]  R2131     -7.3555302619934082e-01
    z[4,5,5]  R2132     -4.6865555644035339e-01
    z[4,5,5]  R2133     -8.2228648662567139e-01
    z[4,5,5]  R2134     -0.147823303937912
    z[4,5,5]  R2135     -2.2303384542465210e-01
    z[4,5,5]  R2136     -2.0209042727947235e-01
    z[4,5,5]  R2137     -0.435959130525589
    z[4,5,5]  R2138     1.2202298641204834e-01
    z[4,5,5]  R2139     4.0418398380279541e-01
    z[4,5,5]  R2140     2.4127800762653351e-01
    z[4,5,5]  R2141     3.3906900882720947e-01
    z[4,5,5]  R2142     1.9571685791015625e-01
    z[4,5,5]  R2143     1.9128678739070892e-01
    z[4,5,5]  R2144     2.3606701195240021e-01
    z[4,5,5]  R2145     2.2576029598712921e-01
    z[4,5,5]  R2146     2.5895288586616516e-01
    z[4,5,5]  R2147     -9.7800888121128082e-02
    z[4,5,5]  R2148     4.8127859830856323e-01
    z[4,5,5]  R2149     3.4379370510578156e-02
    z[4,5,5]  R2150     4.5455446839332581e-01
    z[4,5,5]  R2151     1.9042412936687469e-01
    z[4,5,5]  R2152     -1.4963570237159729e-01
    z[4,5,5]  R2153     1.5943725407123566e-01
    z[4,5,5]  R2154     -1.4460238814353943e-01
    z[4,5,5]  R2155     0.153371199965477
    z[4,5,5]  R2156     -3.3803086262196302e-03
    z[4,5,5]  R2157     -3.6988425254821777e-01
    z[4,5,5]  R2158     -8.7918937206268311e-02
    z[4,5,5]  R2159     1.4753676950931549e-01
    z[4,5,5]  R2160     2.2540971636772156e-01
    z[4,5,5]  R2161     -1.2416794151067734e-01
    z[4,5,5]  R2162     -2.2571860253810883e-01
    z[4,5,5]  R2163     2.1349491178989410e-01
    z[4,5,5]  R2164     -3.2175779342651367e-01
    z[4,5,5]  R2165     -8.9688688516616821e-02
    z[4,5,5]  R2166     -4.6436771750450134e-01
    z[4,5,5]  R2167     -4.8269324004650116e-02
    z[4,5,5]  R2168     -2.1966648101806641e-01
    z[4,5,5]  R2169     -2.3388341069221497e-02
    z[4,5,5]  R2170     -9.2022478580474854e-02
    z[4,5,5]  R2171     5.3409904241561890e-02
    z[4,5,5]  R2172     -3.2578635215759277e-01
    z[4,5,5]  R2173     -8.8714793324470520e-02
    z[4,5,5]  R2174     -0.312102735042572
    z[4,5,5]  R2175     0.867109477519989
    z[4,5,5]  R2176     7.5873774290084839e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2088     -1
    z[4,5,6]  R2089     1
    z[4,5,6]  R2090     3.3846175670623779e-01
    z[4,5,6]  R2091     -1.8444980680942535e-01
    z[4,5,6]  R2092     -2.4717026948928833e-01
    z[4,5,6]  R2093     1.8808794021606445e-01
    z[4,5,6]  R2094     4.8864200711250305e-01
    z[4,5,6]  R2095     2.0841538906097412e-01
    z[4,5,6]  R2096     1.3532589375972748e-01
    z[4,5,6]  R2097     -1.1271986365318298e-01
    z[4,5,6]  R2098     -3.8014176487922668e-01
    z[4,5,6]  R2099     -3.2353103160858154e-01
    z[4,5,6]  R2100     -5.8822077512741089e-01
    z[4,5,6]  R2101     -1.9484908878803253e-01
    z[4,5,6]  R2102     3.6250251531600952e-01
    z[4,5,6]  R2103     3.2462725043296814e-01
    z[4,5,6]  R2104     2.3102736473083496e-01
    z[4,5,6]  R2105     -7.5641330331563950e-03
    z[4,5,6]  R2106     4.1207012534141541e-01
    z[4,5,6]  R2107     2.1155847609043121e-01
    z[4,5,6]  R2108     1.5869426727294922e-01
    z[4,5,6]  R2109     3.2802861928939819e-01
    z[4,5,6]  R2110     3.1218940019607544e-01
    z[4,5,6]  R2111     0.037688959389925
    z[4,5,6]  R2112     3.7482264637947083e-01
    z[4,5,6]  R2113     -5.2823860198259354e-02
    z[4,5,6]  R2114     1.0185701400041580e-01
    z[4,5,6]  R2115     -3.0970774590969086e-02
    z[4,5,6]  R2116     -9.3101290985941887e-03
    z[4,5,6]  R2117     4.6769526600837708e-01
    z[4,5,6]  R2118     1.3416497409343719e-01
    z[4,5,6]  R2119     1.7841459810733795e-01
    z[4,5,6]  R2120     2.5110137462615967e-01
    z[4,5,6]  R2121     3.7090754508972168e-01
    z[4,5,6]  R2122     -1.0599456727504730e-01
    z[4,5,6]  R2123     -7.3094330728054047e-02
    z[4,5,6]  R2124     1.6180223226547241e-01
    z[4,5,6]  R2125     1.2862329185009003e-01
    z[4,5,6]  R2126     -2.5219817180186510e-03
    z[4,5,6]  R2127     -2.4073512852191925e-01
    z[4,5,6]  R2128     -1.2841922044754028e-01
    z[4,5,6]  R2129     1.9455133378505707e-01
    z[4,5,6]  R2130     -9.2191033065319061e-02
    z[4,5,6]  R2131     6.5413199365139008e-02
    z[4,5,6]  R2132     5.1288757473230362e-02
    z[4,5,6]  R2133     3.5724171996116638e-01
    z[4,5,6]  R2134     1.0929439961910248e-01
    z[4,5,6]  R2135     5.8313125371932983e-01
    z[4,5,6]  R2136     -1.7309702932834625e-02
    z[4,5,6]  R2137     -5.0625193119049072e-01
    z[4,5,6]  R2138     -1.2640132009983063e-01
    z[4,5,6]  R2139     8.3364490419626236e-03
    z[4,5,6]  R2140     -1.4134739339351654e-01
    z[4,5,6]  R2141     2.9050955176353455e-01
    z[4,5,6]  R2142     -3.0355167388916016e-01
    z[4,5,6]  R2143     -1.9361393153667450e-01
    z[4,5,6]  R2144     1.2838077545166016e-01
    z[4,5,6]  R2145     7.5807720422744751e-02
    z[4,5,6]  R2146     -4.8850125074386597e-01
    z[4,5,6]  R2147     -2.0394796133041382e-01
    z[4,5,6]  R2148     1.3101337850093842e-01
    z[4,5,6]  R2149     2.6964184641838074e-01
    z[4,5,6]  R2150     -2.0788739621639252e-01
    z[4,5,6]  R2151     -3.7755563855171204e-01
    z[4,5,6]  R2152     -2.4842904508113861e-01
    z[4,5,6]  R2153     1.4364540576934814e-01
    z[4,5,6]  R2154     1.6188396513462067e-01
    z[4,5,6]  R2155     -2.2402470931410789e-02
    z[4,5,6]  R2156     -1.9644704461097717e-01
    z[4,5,6]  R2157     9.3915618956089020e-02
    z[4,5,6]  R2158     0.454225093126297
    z[4,5,6]  R2159     8.5165657103061676e-02
    z[4,5,6]  R2160     4.3079477548599243e-01
    z[4,5,6]  R2161     3.4523203969001770e-01
    z[4,5,6]  R2162     1.4997215941548347e-02
    z[4,5,6]  R2163     -3.3137810230255127e-01
    z[4,5,6]  R2164     4.1690585017204285e-01
    z[4,5,6]  R2165     -2.6097485423088074e-01
    z[4,5,6]  R2166     -3.3129367977380753e-02
    z[4,5,6]  R2167     5.1669991016387939e-01
    z[4,5,6]  R2168     6.0928516089916229e-02
    z[4,5,6]  R2169     3.1819772720336914e-01
    z[4,5,6]  R2170     -3.2967534661293030e-01
    z[4,5,6]  R2171     -2.7402088046073914e-01
    z[4,5,6]  R2172     -1.2210775911808014e-01
    z[4,5,6]  R2173     -9.0648196637630463e-02
    z[4,5,6]  R2174     -3.0467414855957031e-01
    z[4,5,6]  R2175     -2.7823492884635925e-01
    z[4,5,6]  R2176     -3.6152851581573486e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2177     -1
    z[5,4,0]  R2178     1
    z[5,4,0]  R2191     6.8481421470642090e-01
    z[5,4,0]  R2192     4.2407432198524475e-01
    z[5,4,0]  R2193     4.7219285368919373e-01
    z[5,4,0]  R2194     2.9902374744415283e-01
    z[5,4,0]  R2195     0.471809983253479
    z[5,4,0]  R2196     0.557436466217041
    z[5,4,0]  R2197     4.0043455362319946e-01
    z[5,4,0]  R2198     4.1340434551239014e-01
    z[5,4,0]  R2199     5.8189934492111206e-01
    z[5,4,0]  R2200     -1.5772767364978790e-01
    z[5,4,0]  R2201     -2.9264262318611145e-01
    z[5,4,0]  R2202     2.9907515645027161e-01
    z[5,4,0]  R2203     1.0870525985956192e-01
    z[5,4,0]  R2204     4.1055597364902496e-02
    z[5,4,0]  R2205     3.0551312491297722e-02
    z[5,4,0]  R2206     -1.6856157779693604e-01
    z[5,4,0]  R2207     -2.2263364493846893e-01
    z[5,4,0]  R2208     -2.1212583780288696e-01
    z[5,4,0]  R2209     -3.8890343159437180e-02
    z[5,4,0]  R2210     -4.6333214640617371e-01
    z[5,4,0]  R2211     6.4265592955052853e-03
    z[5,4,0]  R2212     -3.6780755966901779e-02
    z[5,4,0]  R2213     -2.7314704656600952e-01
    z[5,4,0]  R2214     -3.8201864808797836e-02
    z[5,4,0]  R2215     -3.4061646461486816e-01
    z[5,4,0]  R2216     -3.0403605103492737e-01
    z[5,4,0]  R2217     4.5423296093940735e-01
    z[5,4,0]  R2218     -4.1578122973442078e-01
    z[5,4,0]  R2219     -3.0241400003433228e-01
    z[5,4,0]  R2220     3.4000226855278015e-01
    z[5,4,0]  R2221     -1.1205981671810150e-01
    z[5,4,0]  R2222     7.9000806808471680e-01
    z[5,4,0]  R2223     5.3096508979797363e-01
    z[5,4,0]  R2224     2.3741620779037476e-01
    z[5,4,0]  R2225     5.5252593010663986e-02
    z[5,4,0]  R2226     6.1953570693731308e-02
    z[5,4,0]  R2227     3.7581798434257507e-01
    z[5,4,0]  R2228     -0.425283819437027
    z[5,4,0]  R2229     2.7152949571609497e-01
    z[5,4,0]  R2230     -4.0629756450653076e-01
    z[5,4,0]  R2231     -9.1883011162281036e-02
    z[5,4,0]  R2232     3.7221607565879822e-01
    z[5,4,0]  R2233     1.4681921899318695e-01
    z[5,4,0]  R2234     4.0812635421752930e-01
    z[5,4,0]  R2235     2.3946161568164825e-01
    z[5,4,0]  R2236     -5.7091158628463745e-01
    z[5,4,0]  R2237     -7.7465665340423584e-01
    z[5,4,0]  R2238     -6.2244963645935059e-01
    z[5,4,0]  R2239     -2.3654049634933472e-01
    z[5,4,0]  R2240     -3.8324549794197083e-01
    z[5,4,0]  R2241     2.4772234261035919e-01
    z[5,4,0]  R2242     2.4696488678455353e-01
    z[5,4,0]  R2243     3.6294525861740112e-01
    z[5,4,0]  R2244     -8.6895838379859924e-02
    z[5,4,0]  R2245     -2.8850749135017395e-01
    z[5,4,0]  R2246     -5.8941280841827393e-01
    z[5,4,0]  R2247     -4.5666575431823730e-01
    z[5,4,0]  R2248     -6.8102669715881348e-01
    z[5,4,0]  R2249     1.6378079354763031e-01
    z[5,4,0]  R2250     -7.7737474441528320e-01
    z[5,4,0]  R2251     4.2044779658317566e-01
    z[5,4,0]  R2252     4.9880540370941162e-01
    z[5,4,0]  R2253     -1.2612174451351166e-01
    z[5,4,0]  R2254     -4.1878500580787659e-01
    z[5,4,0]  R2255     2.1678902208805084e-01
    z[5,4,0]  R2256     -1.3231416046619415e-01
    z[5,4,0]  R2257     0.0712457224726677
    z[5,4,0]  R2258     7.9802796244621277e-02
    z[5,4,0]  R2259     -2.8022137284278870e-01
    z[5,4,0]  R2260     9.2771604657173157e-02
    z[5,4,0]  R2261     5.8583840727806091e-02
    z[5,4,0]  R2262     3.5452548414468765e-02
    z[5,4,0]  R2263     -1.6146329045295715e-01
    z[5,4,0]  R2264     -4.4147886335849762e-02
    z[5,4,0]  R2265     1.3029080629348755e-01
    z[5,4,0]  R2266     -4.9732866883277893e-01
    z[5,4,0]  R2267     -3.5069355368614197e-01
    z[5,4,0]  R2268     3.1645726412534714e-02
    z[5,4,0]  R2269     8.7404318153858185e-02
    z[5,4,0]  R2270     -0.0250399112701416
    z[5,4,0]  R2271     -2.7012780308723450e-02
    z[5,4,0]  R2272     -2.1615663170814514e-01
    z[5,4,0]  R2273     -2.8485766053199768e-01
    z[5,4,0]  R2274     -3.6229911446571350e-01
    z[5,4,0]  R2275     -6.1006546020507812e-01
    z[5,4,0]  R2276     -5.8062785863876343e-01
    z[5,4,0]  R2277     -6.0760623216629028e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2179     -1
    z[5,4,1]  R2180     1
    z[5,4,1]  R2191     -8.1086881458759308e-02
    z[5,4,1]  R2192     -6.2803596258163452e-02
    z[5,4,1]  R2193     -3.4306907653808594e-01
    z[5,4,1]  R2194     -1.9525711238384247e-01
    z[5,4,1]  R2195     -4.2736664414405823e-01
    z[5,4,1]  R2196     3.7686202675104141e-02
    z[5,4,1]  R2197     8.1025041639804840e-02
    z[5,4,1]  R2198     -5.9450343251228333e-02
    z[5,4,1]  R2199     1.1442169547080994e-01
    z[5,4,1]  R2200     1.1627613753080368e-01
    z[5,4,1]  R2201     6.6820508241653442e-01
    z[5,4,1]  R2202     -7.8152108192443848e-01
    z[5,4,1]  R2203     -8.5610884428024292e-01
    z[5,4,1]  R2204     -8.3617657423019409e-01
    z[5,4,1]  R2205     -8.7166756391525269e-01
    z[5,4,1]  R2206     6.8277293443679810e-01
    z[5,4,1]  R2207     -8.6038815975189209e-01
    z[5,4,1]  R2208     -8.2086509466171265e-01
    z[5,4,1]  R2209     -7.5712805986404419e-01
    z[5,4,1]  R2210     0.513932466506958
    z[5,4,1]  R2211     7.9905492067337036e-01
    z[5,4,1]  R2212     5.6476676464080811e-01
    z[5,4,1]  R2213     7.2334295511245728e-01
    z[5,4,1]  R2214     6.2016886472702026e-01
    z[5,4,1]  R2215     5.9186714887619019e-01
    z[5,4,1]  R2216     6.1776363849639893e-01
    z[5,4,1]  R2217     7.4573993682861328e-01
    z[5,4,1]  R2218     7.5574219226837158e-01
    z[5,4,1]  R2219     9.0976518392562866e-01
    z[5,4,1]  R2220     7.1882611513137817e-01
    z[5,4,1]  R2221     3.0438011884689331e-01
    z[5,4,1]  R2222     -4.9998942762613297e-02
    z[5,4,1]  R2223     -0.732832133769989
    z[5,4,1]  R2224     5.9587860107421875e-01
    z[5,4,1]  R2225     -7.4152338504791260e-01
    z[5,4,1]  R2226     5.1899129152297974e-01
    z[5,4,1]  R2227     4.2850050330162048e-01
    z[5,4,1]  R2228     6.1402846127748489e-02
    z[5,4,1]  R2229     3.9935836195945740e-01
    z[5,4,1]  R2230     -1.1253734678030014e-01
    z[5,4,1]  R2231     4.6186193823814392e-01
    z[5,4,1]  R2232     -8.9172267913818359e-01
    z[5,4,1]  R2233     7.1494489908218384e-01
    z[5,4,1]  R2234     5.7863938808441162e-01
    z[5,4,1]  R2235     5.5286550521850586e-01
    z[5,4,1]  R2236     -7.4655382195487618e-04
    z[5,4,1]  R2237     -1.5049608051776886e-01
    z[5,4,1]  R2238     -7.8971035778522491e-02
    z[5,4,1]  R2239     -2.5156855583190918e-01
    z[5,4,1]  R2240     -6.4073219895362854e-02
    z[5,4,1]  R2241     1.4595788717269897e-01
    z[5,4,1]  R2242     -3.5114955902099609e-01
    z[5,4,1]  R2243     -4.1777870059013367e-01
    z[5,4,1]  R2244     6.1551898717880249e-02
    z[5,4,1]  R2245     1.3498616218566895e-01
    z[5,4,1]  R2246     -2.5606042146682739e-01
    z[5,4,1]  R2247     -1.7154380679130554e-01
    z[5,4,1]  R2248     -5.9940207004547119e-01
    z[5,4,1]  R2249     2.0661603659391403e-02
    z[5,4,1]  R2250     -3.7383487820625305e-01
    z[5,4,1]  R2251     -3.1460642814636230e-01
    z[5,4,1]  R2252     6.7527025938034058e-01
    z[5,4,1]  R2253     -4.2850311729125679e-04
    z[5,4,1]  R2254     2.1219305694103241e-02
    z[5,4,1]  R2255     4.2749759554862976e-01
    z[5,4,1]  R2256     4.1486227512359619e-01
    z[5,4,1]  R2257     -1.2789431214332581e-01
    z[5,4,1]  R2258     1.4151163399219513e-01
    z[5,4,1]  R2259     3.4211838245391846e-01
    z[5,4,1]  R2260     3.2706397771835327e-01
    z[5,4,1]  R2261     -2.5861749053001404e-01
    z[5,4,1]  R2262     1.7459358274936676e-01
    z[5,4,1]  R2263     -4.4919971376657486e-02
    z[5,4,1]  R2264     2.0421484112739563e-01
    z[5,4,1]  R2265     4.0388610959053040e-01
    z[5,4,1]  R2266     1.8536414951086044e-02
    z[5,4,1]  R2267     -7.0024833083152771e-02
    z[5,4,1]  R2268     3.2747775316238403e-01
    z[5,4,1]  R2269     2.3994833230972290e-01
    z[5,4,1]  R2270     2.8354302048683167e-01
    z[5,4,1]  R2271     -4.4861879199743271e-02
    z[5,4,1]  R2272     5.6180745363235474e-02
    z[5,4,1]  R2273     8.0625161528587341e-02
    z[5,4,1]  R2274     1.1535218358039856e-01
    z[5,4,1]  R2275     -7.6415991783142090e-01
    z[5,4,1]  R2276     -0.756704568862915
    z[5,4,1]  R2277     -7.4083060026168823e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2181     -1
    z[5,4,2]  R2182     1
    z[5,4,2]  R2191     -4.9701955914497375e-01
    z[5,4,2]  R2192     -4.9604868888854980e-01
    z[5,4,2]  R2193     -4.8486655950546265e-01
    z[5,4,2]  R2194     -2.7913671731948853e-01
    z[5,4,2]  R2195     -9.4179607927799225e-02
    z[5,4,2]  R2196     -3.9441445469856262e-01
    z[5,4,2]  R2197     -5.9366188943386078e-02
    z[5,4,2]  R2198     -7.4587929248809814e-01
    z[5,4,2]  R2199     -3.0251011252403259e-01
    z[5,4,2]  R2200     -9.3451154232025146e-01
    z[5,4,2]  R2201     1.1230071634054184e-01
    z[5,4,2]  R2202     5.0350213050842285e-01
    z[5,4,2]  R2203     -7.9214975237846375e-02
    z[5,4,2]  R2204     4.4775810837745667e-01
    z[5,4,2]  R2205     6.5615884959697723e-02
    z[5,4,2]  R2206     3.6876353621482849e-01
    z[5,4,2]  R2207     1.0235640406608582e-01
    z[5,4,2]  R2208     0.285470187664032
    z[5,4,2]  R2209     4.4804835319519043e-01
    z[5,4,2]  R2210     -2.7570006251335144e-01
    z[5,4,2]  R2211     -3.4256786108016968e-01
    z[5,4,2]  R2212     -6.4214640855789185e-01
    z[5,4,2]  R2213     -4.3363049626350403e-01
    z[5,4,2]  R2214     -5.2234929800033569e-01
    z[5,4,2]  R2215     -5.8482336997985840e-01
    z[5,4,2]  R2216     -6.3599956035614014e-01
    z[5,4,2]  R2217     -4.3129000067710876e-01
    z[5,4,2]  R2218     -3.1067979335784912e-01
    z[5,4,2]  R2219     1.2998823076486588e-02
    z[5,4,2]  R2220     1.3436928391456604e-01
    z[5,4,2]  R2221     -8.5875076055526733e-01
    z[5,4,2]  R2222     3.4931668639183044e-01
    z[5,4,2]  R2223     -1.3806378841400146e-01
    z[5,4,2]  R2224     5.3474318981170654e-01
    z[5,4,2]  R2225     4.8715031147003174e-01
    z[5,4,2]  R2226     7.9511761665344238e-01
    z[5,4,2]  R2227     6.2353795766830444e-01
    z[5,4,2]  R2228     4.3923398852348328e-01
    z[5,4,2]  R2229     6.3465487957000732e-01
    z[5,4,2]  R2230     6.8603628873825073e-01
    z[5,4,2]  R2231     -5.9742176532745361e-01
    z[5,4,2]  R2232     -3.2313343137502670e-02
    z[5,4,2]  R2233     5.7549959421157837e-01
    z[5,4,2]  R2234     5.0004667043685913e-01
    z[5,4,2]  R2235     7.4372583627700806e-01
    z[5,4,2]  R2236     3.8138604164123535e-01
    z[5,4,2]  R2237     4.4182300567626953e-01
    z[5,4,2]  R2238     -3.1139988452196121e-02
    z[5,4,2]  R2239     -2.3227233439683914e-02
    z[5,4,2]  R2240     3.3875235915184021e-01
    z[5,4,2]  R2241     2.2578868269920349e-01
    z[5,4,2]  R2242     -4.8831388354301453e-01
    z[5,4,2]  R2243     2.3956601321697235e-01
    z[5,4,2]  R2244     -9.2622911930084229e-01
    z[5,4,2]  R2245     -5.6925896555185318e-02
    z[5,4,2]  R2246     1.8781113624572754e-01
    z[5,4,2]  R2247     4.5199862122535706e-01
    z[5,4,2]  R2248     2.2137674689292908e-01
    z[5,4,2]  R2249     3.0540555715560913e-01
    z[5,4,2]  R2250     1.8160057067871094e-01
    z[5,4,2]  R2251     1.8379474058747292e-02
    z[5,4,2]  R2252     1.0136752575635910e-01
    z[5,4,2]  R2253     0.719666063785553
    z[5,4,2]  R2254     -3.1923856586217880e-02
    z[5,4,2]  R2255     -1.0549058765172958e-01
    z[5,4,2]  R2256     1.2692656368017197e-02
    z[5,4,2]  R2257     -0.097258560359478
    z[5,4,2]  R2258     2.4996910989284515e-01
    z[5,4,2]  R2259     4.1910886764526367e-02
    z[5,4,2]  R2260     3.1649264693260193e-01
    z[5,4,2]  R2261     -3.3787362277507782e-02
    z[5,4,2]  R2262     -3.2035586237907410e-01
    z[5,4,2]  R2263     6.3951745629310608e-02
    z[5,4,2]  R2264     0.658301830291748
    z[5,4,2]  R2265     4.8984782770276070e-03
    z[5,4,2]  R2266     3.0478018522262573e-01
    z[5,4,2]  R2267     6.9895529747009277e-01
    z[5,4,2]  R2268     8.5863113403320312e-02
    z[5,4,2]  R2269     -1.6348041594028473e-02
    z[5,4,2]  R2270     1.1734221875667572e-01
    z[5,4,2]  R2271     -1.5207682549953461e-01
    z[5,4,2]  R2272     4.1668361425399780e-01
    z[5,4,2]  R2273     1.6104342043399811e-01
    z[5,4,2]  R2274     2.7280882000923157e-01
    z[5,4,2]  R2275     5.7944428175687790e-02
    z[5,4,2]  R2276     1.0019752383232117e-01
    z[5,4,2]  R2277     1.4930146932601929e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2183     -1
    z[5,4,3]  R2184     1
    z[5,4,3]  R2191     -3.5028973221778870e-01
    z[5,4,3]  R2192     -8.2846589386463165e-02
    z[5,4,3]  R2193     3.2014327589422464e-03
    z[5,4,3]  R2194     -1.4209325611591339e-01
    z[5,4,3]  R2195     7.1378417313098907e-02
    z[5,4,3]  R2196     2.7369028329849243e-01
    z[5,4,3]  R2197     1.1251424252986908e-01
    z[5,4,3]  R2198     -2.3168994486331940e-01
    z[5,4,3]  R2199     -2.6467078924179077e-01
    z[5,4,3]  R2200     1.0491105914115906e-01
    z[5,4,3]  R2201     0.0898166075348854
    z[5,4,3]  R2202     -1.1651634424924850e-01
    z[5,4,3]  R2203     -2.1026555448770523e-02
    z[5,4,3]  R2204     6.8229183554649353e-02
    z[5,4,3]  R2205     1.2749873101711273e-01
    z[5,4,3]  R2206     4.5084267854690552e-02
    z[5,4,3]  R2207     2.7704444527626038e-01
    z[5,4,3]  R2208     0.355803906917572
    z[5,4,3]  R2209     2.7114561200141907e-01
    z[5,4,3]  R2210     2.5887799263000488e-01
    z[5,4,3]  R2211     -2.9570633172988892e-01
    z[5,4,3]  R2212     -1.3546113669872284e-01
    z[5,4,3]  R2213     1.8554992973804474e-01
    z[5,4,3]  R2214     -1.0255632549524307e-01
    z[5,4,3]  R2215     6.0594443231821060e-02
    z[5,4,3]  R2216     1.5278393030166626e-01
    z[5,4,3]  R2217     6.0688290745019913e-02
    z[5,4,3]  R2218     1.1022411286830902e-01
    z[5,4,3]  R2219     6.9968298077583313e-02
    z[5,4,3]  R2220     -3.5158935189247131e-01
    z[5,4,3]  R2221     1.0737839341163635e-01
    z[5,4,3]  R2222     1.6416235268115997e-01
    z[5,4,3]  R2223     -1.6629289090633392e-01
    z[5,4,3]  R2224     1.3947841711342335e-02
    z[5,4,3]  R2225     2.2214072942733765e-01
    z[5,4,3]  R2226     -1.9584783911705017e-01
    z[5,4,3]  R2227     0.281126469373703
    z[5,4,3]  R2228     -5.7939112186431885e-01
    z[5,4,3]  R2229     5.0716590881347656e-01
    z[5,4,3]  R2230     -3.6588475108146667e-01
    z[5,4,3]  R2231     -7.0546649396419525e-02
    z[5,4,3]  R2232     -0.0752662867307663
    z[5,4,3]  R2233     8.5963584482669830e-02
    z[5,4,3]  R2234     3.4735634922981262e-01
    z[5,4,3]  R2235     7.2962991893291473e-02
    z[5,4,3]  R2236     -6.3346517086029053e-01
    z[5,4,3]  R2237     -3.9998832345008850e-01
    z[5,4,3]  R2238     -0.642842173576355
    z[5,4,3]  R2239     3.7850666791200638e-02
    z[5,4,3]  R2240     1.6396088898181915e-01
    z[5,4,3]  R2241     -8.6045974493026733e-01
    z[5,4,3]  R2242     -1.4862245321273804e-01
    z[5,4,3]  R2243     -1.6409538686275482e-02
    z[5,4,3]  R2244     -2.5952234864234924e-01
    z[5,4,3]  R2245     1.7812801524996758e-02
    z[5,4,3]  R2246     8.6579039692878723e-02
    z[5,4,3]  R2247     8.2425296306610107e-02
    z[5,4,3]  R2248     -8.2052469253540039e-02
    z[5,4,3]  R2249     3.0150455236434937e-01
    z[5,4,3]  R2250     -1.7092892527580261e-01
    z[5,4,3]  R2251     -8.4106504917144775e-02
    z[5,4,3]  R2252     2.7513271570205688e-01
    z[5,4,3]  R2253     4.0931177139282227e-01
    z[5,4,3]  R2254     6.1861896514892578e-01
    z[5,4,3]  R2255     5.9167939424514771e-01
    z[5,4,3]  R2256     5.5876374244689941e-01
    z[5,4,3]  R2257     3.9200946688652039e-01
    z[5,4,3]  R2258     4.5328933000564575e-01
    z[5,4,3]  R2259     4.8418885469436646e-01
    z[5,4,3]  R2260     4.8538509011268616e-01
    z[5,4,3]  R2261     0.664361834526062
    z[5,4,3]  R2262     0.720909833908081
    z[5,4,3]  R2263     0.516990602016449
    z[5,4,3]  R2264     6.9094288349151611e-01
    z[5,4,3]  R2265     5.9732836484909058e-01
    z[5,4,3]  R2266     6.3530176877975464e-01
    z[5,4,3]  R2267     0.408335417509079
    z[5,4,3]  R2268     5.4951918125152588e-01
    z[5,4,3]  R2269     4.5598819851875305e-01
    z[5,4,3]  R2270     6.2091869115829468e-01
    z[5,4,3]  R2271     7.3603373765945435e-01
    z[5,4,3]  R2272     6.5980148315429688e-01
    z[5,4,3]  R2273     6.3465386629104614e-01
    z[5,4,3]  R2274     0.608033299446106
    z[5,4,3]  R2275     -1.8308252096176147e-02
    z[5,4,3]  R2276     -1.7723189294338226e-01
    z[5,4,3]  R2277     1.3498324155807495e-01
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2185     -1
    z[5,4,4]  R2186     1
    z[5,4,4]  R2191     -1.5760441124439240e-01
    z[5,4,4]  R2192     -0.446170449256897
    z[5,4,4]  R2193     1.4418350160121918e-01
    z[5,4,4]  R2194     2.7568724751472473e-01
    z[5,4,4]  R2195     -1.8833811581134796e-01
    z[5,4,4]  R2196     4.8487776517868042e-01
    z[5,4,4]  R2197     -1.1457122862339020e-01
    z[5,4,4]  R2198     4.2632073163986206e-01
    z[5,4,4]  R2199     -3.1137070059776306e-01
    z[5,4,4]  R2200     1.9011422991752625e-01
    z[5,4,4]  R2201     -2.8852125629782677e-02
    z[5,4,4]  R2202     4.2678169906139374e-02
    z[5,4,4]  R2203     2.9173517227172852e-01
    z[5,4,4]  R2204     1.2564468383789062e-01
    z[5,4,4]  R2205     1.3905872404575348e-01
    z[5,4,4]  R2206     -4.8676499724388123e-01
    z[5,4,4]  R2207     2.2104050219058990e-01
    z[5,4,4]  R2208     -2.9736701399087906e-02
    z[5,4,4]  R2209     -3.0702257156372070e-01
    z[5,4,4]  R2210     -2.6921811699867249e-01
    z[5,4,4]  R2211     0.3248310983181
    z[5,4,4]  R2212     -1.3797611929476261e-02
    z[5,4,4]  R2213     -3.2528871297836304e-01
    z[5,4,4]  R2214     -2.8412604331970215e-01
    z[5,4,4]  R2215     9.5781035721302032e-02
    z[5,4,4]  R2216     -1.1825407296419144e-01
    z[5,4,4]  R2217     -4.2378310114145279e-02
    z[5,4,4]  R2218     3.1653138995170593e-01
    z[5,4,4]  R2219     -2.2756111621856689e-01
    z[5,4,4]  R2220     -4.3291386961936951e-01
    z[5,4,4]  R2221     1.3337983749806881e-02
    z[5,4,4]  R2222     1.0181195288896561e-01
    z[5,4,4]  R2223     -3.2449635863304138e-01
    z[5,4,4]  R2224     2.5695082545280457e-01
    z[5,4,4]  R2225     -1.6070288419723511e-01
    z[5,4,4]  R2226     7.1187183260917664e-02
    z[5,4,4]  R2227     2.2787061333656311e-01
    z[5,4,4]  R2228     9.6975639462471008e-02
    z[5,4,4]  R2229     1.7501041293144226e-01
    z[5,4,4]  R2230     -3.1704951077699661e-02
    z[5,4,4]  R2231     3.8346165418624878e-01
    z[5,4,4]  R2232     8.7240047752857208e-02
    z[5,4,4]  R2233     1.6404733061790466e-01
    z[5,4,4]  R2234     -0.103693388402462
    z[5,4,4]  R2235     -2.4617625400424004e-02
    z[5,4,4]  R2236     7.9239696264266968e-02
    z[5,4,4]  R2237     -7.7282056212425232e-02
    z[5,4,4]  R2238     4.3240282684564590e-02
    z[5,4,4]  R2239     2.2247716784477234e-01
    z[5,4,4]  R2240     3.1550772488117218e-02
    z[5,4,4]  R2241     -4.3812990188598633e-02
    z[5,4,4]  R2242     -2.3397125303745270e-01
    z[5,4,4]  R2243     4.8334822058677673e-01
    z[5,4,4]  R2244     8.1369958817958832e-02
    z[5,4,4]  R2245     4.1641953587532043e-01
    z[5,4,4]  R2246     -7.0744216442108154e-01
    z[5,4,4]  R2247     -7.0412427186965942e-01
    z[5,4,4]  R2248     -3.2751148939132690e-01
    z[5,4,4]  R2249     -7.7893167734146118e-01
    z[5,4,4]  R2250     -1.9485269486904144e-01
    z[5,4,4]  R2251     -1.3611069321632385e-01
    z[5,4,4]  R2252     3.5755693912506104e-01
    z[5,4,4]  R2253     9.4899103045463562e-02
    z[5,4,4]  R2254     -5.7386392354965210e-01
    z[5,4,4]  R2255     -5.0568145513534546e-01
    z[5,4,4]  R2256     -0.574921190738678
    z[5,4,4]  R2257     -7.2078096866607666e-01
    z[5,4,4]  R2258     -8.1240636110305786e-01
    z[5,4,4]  R2259     -7.3139494657516479e-01
    z[5,4,4]  R2260     -4.9469089508056641e-01
    z[5,4,4]  R2261     -6.0339617729187012e-01
    z[5,4,4]  R2262     -5.5495953559875488e-01
    z[5,4,4]  R2263     -5.7392561435699463e-01
    z[5,4,4]  R2264     1.4989911019802094e-01
    z[5,4,4]  R2265     -6.0175734758377075e-01
    z[5,4,4]  R2266     9.2814810574054718e-02
    z[5,4,4]  R2267     1.5847903490066528e-01
    z[5,4,4]  R2268     -5.4320687055587769e-01
    z[5,4,4]  R2269     -8.4174668788909912e-01
    z[5,4,4]  R2270     -6.2490385770797729e-01
    z[5,4,4]  R2271     -6.0696178674697876e-01
    z[5,4,4]  R2272     2.7905102819204330e-02
    z[5,4,4]  R2273     -6.7005246877670288e-01
    z[5,4,4]  R2274     -6.2093317508697510e-01
    z[5,4,4]  R2275     4.1517388075590134e-02
    z[5,4,4]  R2276     -1.3797618448734283e-01
    z[5,4,4]  R2277     -1.8680550158023834e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2187     -1
    z[5,4,5]  R2188     1
    z[5,4,5]  R2191     -2.6819872856140137e-01
    z[5,4,5]  R2192     -5.8968561887741089e-01
    z[5,4,5]  R2193     -6.0464257001876831e-01
    z[5,4,5]  R2194     -8.3057153224945068e-01
    z[5,4,5]  R2195     -7.3555302619934082e-01
    z[5,4,5]  R2196     -4.6865555644035339e-01
    z[5,4,5]  R2197     -8.2228648662567139e-01
    z[5,4,5]  R2198     -0.147823303937912
    z[5,4,5]  R2199     -2.2303384542465210e-01
    z[5,4,5]  R2200     -2.0209042727947235e-01
    z[5,4,5]  R2201     -0.435959130525589
    z[5,4,5]  R2202     1.2202298641204834e-01
    z[5,4,5]  R2203     4.0418398380279541e-01
    z[5,4,5]  R2204     2.4127800762653351e-01
    z[5,4,5]  R2205     3.3906900882720947e-01
    z[5,4,5]  R2206     1.9571685791015625e-01
    z[5,4,5]  R2207     1.9128678739070892e-01
    z[5,4,5]  R2208     2.3606701195240021e-01
    z[5,4,5]  R2209     2.2576029598712921e-01
    z[5,4,5]  R2210     2.5895288586616516e-01
    z[5,4,5]  R2211     -9.7800888121128082e-02
    z[5,4,5]  R2212     4.8127859830856323e-01
    z[5,4,5]  R2213     3.4379370510578156e-02
    z[5,4,5]  R2214     4.5455446839332581e-01
    z[5,4,5]  R2215     1.9042412936687469e-01
    z[5,4,5]  R2216     -1.4963570237159729e-01
    z[5,4,5]  R2217     1.5943725407123566e-01
    z[5,4,5]  R2218     -1.4460238814353943e-01
    z[5,4,5]  R2219     0.153371199965477
    z[5,4,5]  R2220     -3.3803086262196302e-03
    z[5,4,5]  R2221     -3.6988425254821777e-01
    z[5,4,5]  R2222     -8.7918937206268311e-02
    z[5,4,5]  R2223     1.4753676950931549e-01
    z[5,4,5]  R2224     2.2540971636772156e-01
    z[5,4,5]  R2225     -1.2416794151067734e-01
    z[5,4,5]  R2226     -2.2571860253810883e-01
    z[5,4,5]  R2227     2.1349491178989410e-01
    z[5,4,5]  R2228     -3.2175779342651367e-01
    z[5,4,5]  R2229     -8.9688688516616821e-02
    z[5,4,5]  R2230     -4.6436771750450134e-01
    z[5,4,5]  R2231     -4.8269324004650116e-02
    z[5,4,5]  R2232     -2.1966648101806641e-01
    z[5,4,5]  R2233     -2.3388341069221497e-02
    z[5,4,5]  R2234     -9.2022478580474854e-02
    z[5,4,5]  R2235     5.3409904241561890e-02
    z[5,4,5]  R2236     -3.2578635215759277e-01
    z[5,4,5]  R2237     -8.8714793324470520e-02
    z[5,4,5]  R2238     -0.312102735042572
    z[5,4,5]  R2239     0.867109477519989
    z[5,4,5]  R2240     7.5873774290084839e-01
    z[5,4,5]  R2241     0.0973777249455452
    z[5,4,5]  R2242     -6.8293410539627075e-01
    z[5,4,5]  R2243     -5.8425325155258179e-01
    z[5,4,5]  R2244     -1.4632146060466766e-01
    z[5,4,5]  R2245     -6.9484394788742065e-01
    z[5,4,5]  R2246     1.8580364063382149e-02
    z[5,4,5]  R2247     1.9190703332424164e-01
    z[5,4,5]  R2248     3.4785460680723190e-02
    z[5,4,5]  R2249     1.9320763647556305e-01
    z[5,4,5]  R2250     2.2605451941490173e-01
    z[5,4,5]  R2251     5.9355276823043823e-01
    z[5,4,5]  R2252     2.0836704969406128e-01
    z[5,4,5]  R2253     3.9777347445487976e-01
    z[5,4,5]  R2254     7.5879737734794617e-02
    z[5,4,5]  R2255     3.1614589691162109e-01
    z[5,4,5]  R2256     4.0916091203689575e-01
    z[5,4,5]  R2257     3.5511884093284607e-01
    z[5,4,5]  R2258     -2.9819600284099579e-02
    z[5,4,5]  R2259     9.0072564780712128e-02
    z[5,4,5]  R2260     4.4309636950492859e-01
    z[5,4,5]  R2261     1.6005451977252960e-01
    z[5,4,5]  R2262     1.9110429286956787e-01
    z[5,4,5]  R2263     4.8027086257934570e-01
    z[5,4,5]  R2264     1.4256159961223602e-01
    z[5,4,5]  R2265     3.0097925662994385e-01
    z[5,4,5]  R2266     4.9623328447341919e-01
    z[5,4,5]  R2267     4.3775799870491028e-01
    z[5,4,5]  R2268     2.6191705465316772e-01
    z[5,4,5]  R2269     7.4255662038922310e-03
    z[5,4,5]  R2270     -3.1197839975357056e-01
    z[5,4,5]  R2271     3.0499780550599098e-02
    z[5,4,5]  R2272     4.5033949613571167e-01
    z[5,4,5]  R2273     -1.5306897461414337e-01
    z[5,4,5]  R2274     1.4283972978591919e-01
    z[5,4,5]  R2275     1.1083095520734787e-01
    z[5,4,5]  R2276     1.1505434662103653e-01
    z[5,4,5]  R2277     8.1059344112873077e-02
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2189     -1
    z[5,4,6]  R2190     1
    z[5,4,6]  R2191     -2.4073512852191925e-01
    z[5,4,6]  R2192     -1.2841922044754028e-01
    z[5,4,6]  R2193     1.9455133378505707e-01
    z[5,4,6]  R2194     -9.2191033065319061e-02
    z[5,4,6]  R2195     6.5413199365139008e-02
    z[5,4,6]  R2196     5.1288757473230362e-02
    z[5,4,6]  R2197     3.5724171996116638e-01
    z[5,4,6]  R2198     1.0929439961910248e-01
    z[5,4,6]  R2199     5.8313125371932983e-01
    z[5,4,6]  R2200     -1.7309702932834625e-02
    z[5,4,6]  R2201     -5.0625193119049072e-01
    z[5,4,6]  R2202     -1.2640132009983063e-01
    z[5,4,6]  R2203     8.3364490419626236e-03
    z[5,4,6]  R2204     -1.4134739339351654e-01
    z[5,4,6]  R2205     2.9050955176353455e-01
    z[5,4,6]  R2206     -3.0355167388916016e-01
    z[5,4,6]  R2207     -1.9361393153667450e-01
    z[5,4,6]  R2208     1.2838077545166016e-01
    z[5,4,6]  R2209     7.5807720422744751e-02
    z[5,4,6]  R2210     -4.8850125074386597e-01
    z[5,4,6]  R2211     -2.0394796133041382e-01
    z[5,4,6]  R2212     1.3101337850093842e-01
    z[5,4,6]  R2213     2.6964184641838074e-01
    z[5,4,6]  R2214     -2.0788739621639252e-01
    z[5,4,6]  R2215     -3.7755563855171204e-01
    z[5,4,6]  R2216     -2.4842904508113861e-01
    z[5,4,6]  R2217     1.4364540576934814e-01
    z[5,4,6]  R2218     1.6188396513462067e-01
    z[5,4,6]  R2219     -2.2402470931410789e-02
    z[5,4,6]  R2220     -1.9644704461097717e-01
    z[5,4,6]  R2221     9.3915618956089020e-02
    z[5,4,6]  R2222     0.454225093126297
    z[5,4,6]  R2223     8.5165657103061676e-02
    z[5,4,6]  R2224     4.3079477548599243e-01
    z[5,4,6]  R2225     3.4523203969001770e-01
    z[5,4,6]  R2226     1.4997215941548347e-02
    z[5,4,6]  R2227     -3.3137810230255127e-01
    z[5,4,6]  R2228     4.1690585017204285e-01
    z[5,4,6]  R2229     -2.6097485423088074e-01
    z[5,4,6]  R2230     -3.3129367977380753e-02
    z[5,4,6]  R2231     5.1669991016387939e-01
    z[5,4,6]  R2232     6.0928516089916229e-02
    z[5,4,6]  R2233     3.1819772720336914e-01
    z[5,4,6]  R2234     -3.2967534661293030e-01
    z[5,4,6]  R2235     -2.7402088046073914e-01
    z[5,4,6]  R2236     -1.2210775911808014e-01
    z[5,4,6]  R2237     -9.0648196637630463e-02
    z[5,4,6]  R2238     -3.0467414855957031e-01
    z[5,4,6]  R2239     -2.7823492884635925e-01
    z[5,4,6]  R2240     -3.6152851581573486e-01
    z[5,4,6]  R2241     3.3846175670623779e-01
    z[5,4,6]  R2242     -1.8444980680942535e-01
    z[5,4,6]  R2243     -2.4717026948928833e-01
    z[5,4,6]  R2244     1.8808794021606445e-01
    z[5,4,6]  R2245     4.8864200711250305e-01
    z[5,4,6]  R2246     2.0841538906097412e-01
    z[5,4,6]  R2247     1.3532589375972748e-01
    z[5,4,6]  R2248     -1.1271986365318298e-01
    z[5,4,6]  R2249     -3.8014176487922668e-01
    z[5,4,6]  R2250     -3.2353103160858154e-01
    z[5,4,6]  R2251     -5.8822077512741089e-01
    z[5,4,6]  R2252     -1.9484908878803253e-01
    z[5,4,6]  R2253     3.6250251531600952e-01
    z[5,4,6]  R2254     3.2462725043296814e-01
    z[5,4,6]  R2255     2.3102736473083496e-01
    z[5,4,6]  R2256     -7.5641330331563950e-03
    z[5,4,6]  R2257     4.1207012534141541e-01
    z[5,4,6]  R2258     2.1155847609043121e-01
    z[5,4,6]  R2259     1.5869426727294922e-01
    z[5,4,6]  R2260     3.2802861928939819e-01
    z[5,4,6]  R2261     3.1218940019607544e-01
    z[5,4,6]  R2262     0.037688959389925
    z[5,4,6]  R2263     3.7482264637947083e-01
    z[5,4,6]  R2264     -5.2823860198259354e-02
    z[5,4,6]  R2265     1.0185701400041580e-01
    z[5,4,6]  R2266     -3.0970774590969086e-02
    z[5,4,6]  R2267     -9.3101290985941887e-03
    z[5,4,6]  R2268     4.6769526600837708e-01
    z[5,4,6]  R2269     1.3416497409343719e-01
    z[5,4,6]  R2270     1.7841459810733795e-01
    z[5,4,6]  R2271     2.5110137462615967e-01
    z[5,4,6]  R2272     3.7090754508972168e-01
    z[5,4,6]  R2273     -1.0599456727504730e-01
    z[5,4,6]  R2274     -7.3094330728054047e-02
    z[5,4,6]  R2275     1.6180223226547241e-01
    z[5,4,6]  R2276     1.2862329185009003e-01
    z[5,4,6]  R2277     -2.5219817180186510e-03
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2329     -1
    z[5,6,0]  R2330     1
    z[5,6,0]  R2343     6.8481421470642090e-01
    z[5,6,0]  R2344     4.2407432198524475e-01
    z[5,6,0]  R2345     4.7219285368919373e-01
    z[5,6,0]  R2346     2.9902374744415283e-01
    z[5,6,0]  R2347     0.471809983253479
    z[5,6,0]  R2348     0.557436466217041
    z[5,6,0]  R2349     4.0043455362319946e-01
    z[5,6,0]  R2350     4.1340434551239014e-01
    z[5,6,0]  R2351     5.8189934492111206e-01
    z[5,6,0]  R2352     -1.5772767364978790e-01
    z[5,6,0]  R2353     -2.9264262318611145e-01
    z[5,6,0]  R2354     2.9907515645027161e-01
    z[5,6,0]  R2355     1.0870525985956192e-01
    z[5,6,0]  R2356     4.1055597364902496e-02
    z[5,6,0]  R2357     3.0551312491297722e-02
    z[5,6,0]  R2358     -1.6856157779693604e-01
    z[5,6,0]  R2359     -2.2263364493846893e-01
    z[5,6,0]  R2360     -2.1212583780288696e-01
    z[5,6,0]  R2361     -3.8890343159437180e-02
    z[5,6,0]  R2362     -4.6333214640617371e-01
    z[5,6,0]  R2363     6.4265592955052853e-03
    z[5,6,0]  R2364     -3.6780755966901779e-02
    z[5,6,0]  R2365     -2.7314704656600952e-01
    z[5,6,0]  R2366     -3.8201864808797836e-02
    z[5,6,0]  R2367     -3.4061646461486816e-01
    z[5,6,0]  R2368     -3.0403605103492737e-01
    z[5,6,0]  R2369     4.5423296093940735e-01
    z[5,6,0]  R2370     -4.1578122973442078e-01
    z[5,6,0]  R2371     -3.0241400003433228e-01
    z[5,6,0]  R2372     3.4000226855278015e-01
    z[5,6,0]  R2373     -1.1205981671810150e-01
    z[5,6,0]  R2374     7.9000806808471680e-01
    z[5,6,0]  R2375     5.3096508979797363e-01
    z[5,6,0]  R2376     2.3741620779037476e-01
    z[5,6,0]  R2377     5.5252593010663986e-02
    z[5,6,0]  R2378     6.1953570693731308e-02
    z[5,6,0]  R2379     3.7581798434257507e-01
    z[5,6,0]  R2380     -0.425283819437027
    z[5,6,0]  R2381     2.7152949571609497e-01
    z[5,6,0]  R2382     -4.0629756450653076e-01
    z[5,6,0]  R2383     -9.1883011162281036e-02
    z[5,6,0]  R2384     3.7221607565879822e-01
    z[5,6,0]  R2385     1.4681921899318695e-01
    z[5,6,0]  R2386     4.0812635421752930e-01
    z[5,6,0]  R2387     2.3946161568164825e-01
    z[5,6,0]  R2388     -5.7091158628463745e-01
    z[5,6,0]  R2389     -7.7465665340423584e-01
    z[5,6,0]  R2390     -6.2244963645935059e-01
    z[5,6,0]  R2391     -2.3654049634933472e-01
    z[5,6,0]  R2392     -3.8324549794197083e-01
    z[5,6,0]  R2393     -1.2808595784008503e-02
    z[5,6,0]  R2394     1.9614402204751968e-02
    z[5,6,0]  R2395     0.426605224609375
    z[5,6,0]  R2396     -3.6192893981933594e-01
    z[5,6,0]  R2397     1.8868026137351990e-01
    z[5,6,0]  R2398     5.9049296379089355e-01
    z[5,6,0]  R2399     -3.0709570273756981e-02
    z[5,6,0]  R2400     -4.2208233475685120e-01
    z[5,6,0]  R2401     3.7201613187789917e-01
    z[5,6,0]  R2402     -5.7482451200485229e-02
    z[5,6,0]  R2403     -1.5361925959587097e-01
    z[5,6,0]  R2404     -0.279266357421875
    z[5,6,0]  R2405     -3.1568318605422974e-01
    z[5,6,0]  R2406     6.2692761421203613e-01
    z[5,6,0]  R2407     -6.3902062177658081e-01
    z[5,6,0]  R2408     1.4368177950382233e-01
    z[5,6,0]  R2409     3.5535556077957153e-01
    z[5,6,0]  R2410     4.1406655311584473e-01
    z[5,6,0]  R2411     -2.4012443423271179e-01
    z[5,6,0]  R2412     7.6279568672180176e-01
    z[5,6,0]  R2413     4.7961592674255371e-01
    z[5,6,0]  R2414     3.2556268572807312e-01
    z[5,6,0]  R2415     5.9694701433181763e-01
    z[5,6,0]  R2416     5.6772679090499878e-01
    z[5,6,0]  R2417     5.7338184118270874e-01
    z[5,6,0]  R2418     -3.6375731229782104e-01
    z[5,6,0]  R2419     5.2672243118286133e-01
    z[5,6,0]  R2420     3.2841497659683228e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2331     -1
    z[5,6,1]  R2332     1
    z[5,6,1]  R2343     -8.1086881458759308e-02
    z[5,6,1]  R2344     -6.2803596258163452e-02
    z[5,6,1]  R2345     -3.4306907653808594e-01
    z[5,6,1]  R2346     -1.9525711238384247e-01
    z[5,6,1]  R2347     -4.2736664414405823e-01
    z[5,6,1]  R2348     3.7686202675104141e-02
    z[5,6,1]  R2349     8.1025041639804840e-02
    z[5,6,1]  R2350     -5.9450343251228333e-02
    z[5,6,1]  R2351     1.1442169547080994e-01
    z[5,6,1]  R2352     1.1627613753080368e-01
    z[5,6,1]  R2353     6.6820508241653442e-01
    z[5,6,1]  R2354     -7.8152108192443848e-01
    z[5,6,1]  R2355     -8.5610884428024292e-01
    z[5,6,1]  R2356     -8.3617657423019409e-01
    z[5,6,1]  R2357     -8.7166756391525269e-01
    z[5,6,1]  R2358     6.8277293443679810e-01
    z[5,6,1]  R2359     -8.6038815975189209e-01
    z[5,6,1]  R2360     -8.2086509466171265e-01
    z[5,6,1]  R2361     -7.5712805986404419e-01
    z[5,6,1]  R2362     0.513932466506958
    z[5,6,1]  R2363     7.9905492067337036e-01
    z[5,6,1]  R2364     5.6476676464080811e-01
    z[5,6,1]  R2365     7.2334295511245728e-01
    z[5,6,1]  R2366     6.2016886472702026e-01
    z[5,6,1]  R2367     5.9186714887619019e-01
    z[5,6,1]  R2368     6.1776363849639893e-01
    z[5,6,1]  R2369     7.4573993682861328e-01
    z[5,6,1]  R2370     7.5574219226837158e-01
    z[5,6,1]  R2371     9.0976518392562866e-01
    z[5,6,1]  R2372     7.1882611513137817e-01
    z[5,6,1]  R2373     3.0438011884689331e-01
    z[5,6,1]  R2374     -4.9998942762613297e-02
    z[5,6,1]  R2375     -0.732832133769989
    z[5,6,1]  R2376     5.9587860107421875e-01
    z[5,6,1]  R2377     -7.4152338504791260e-01
    z[5,6,1]  R2378     5.1899129152297974e-01
    z[5,6,1]  R2379     4.2850050330162048e-01
    z[5,6,1]  R2380     6.1402846127748489e-02
    z[5,6,1]  R2381     3.9935836195945740e-01
    z[5,6,1]  R2382     -1.1253734678030014e-01
    z[5,6,1]  R2383     4.6186193823814392e-01
    z[5,6,1]  R2384     -8.9172267913818359e-01
    z[5,6,1]  R2385     7.1494489908218384e-01
    z[5,6,1]  R2386     5.7863938808441162e-01
    z[5,6,1]  R2387     5.5286550521850586e-01
    z[5,6,1]  R2388     -7.4655382195487618e-04
    z[5,6,1]  R2389     -1.5049608051776886e-01
    z[5,6,1]  R2390     -7.8971035778522491e-02
    z[5,6,1]  R2391     -2.5156855583190918e-01
    z[5,6,1]  R2392     -6.4073219895362854e-02
    z[5,6,1]  R2393     -8.5665351152420044e-01
    z[5,6,1]  R2394     -7.6960867643356323e-01
    z[5,6,1]  R2395     -7.1765071153640747e-01
    z[5,6,1]  R2396     -0.614878237247467
    z[5,6,1]  R2397     1.6149619221687317e-01
    z[5,6,1]  R2398     -4.9843534827232361e-01
    z[5,6,1]  R2399     -5.1870477199554443e-01
    z[5,6,1]  R2400     -0.48763307929039
    z[5,6,1]  R2401     3.6125433444976807e-01
    z[5,6,1]  R2402     -3.9068728685379028e-01
    z[5,6,1]  R2403     0.531035304069519
    z[5,6,1]  R2404     4.2480081319808960e-01
    z[5,6,1]  R2405     5.0707006454467773e-01
    z[5,6,1]  R2406     -5.2635347843170166e-01
    z[5,6,1]  R2407     2.8780847787857056e-01
    z[5,6,1]  R2408     -0.422394722700119
    z[5,6,1]  R2409     -2.8031843900680542e-01
    z[5,6,1]  R2410     -5.1171295344829559e-02
    z[5,6,1]  R2411     0.348254531621933
    z[5,6,1]  R2412     -4.5135945081710815e-01
    z[5,6,1]  R2413     -4.7845938801765442e-01
    z[5,6,1]  R2414     -0.479305237531662
    z[5,6,1]  R2415     -3.3661171793937683e-01
    z[5,6,1]  R2416     -5.0828850269317627e-01
    z[5,6,1]  R2417     -3.8467141985893250e-01
    z[5,6,1]  R2418     -1.2730935215950012e-01
    z[5,6,1]  R2419     -3.6874574422836304e-01
    z[5,6,1]  R2420     -3.7385082244873047e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2333     -1
    z[5,6,2]  R2334     1
    z[5,6,2]  R2343     -4.9701955914497375e-01
    z[5,6,2]  R2344     -4.9604868888854980e-01
    z[5,6,2]  R2345     -4.8486655950546265e-01
    z[5,6,2]  R2346     -2.7913671731948853e-01
    z[5,6,2]  R2347     -9.4179607927799225e-02
    z[5,6,2]  R2348     -3.9441445469856262e-01
    z[5,6,2]  R2349     -5.9366188943386078e-02
    z[5,6,2]  R2350     -7.4587929248809814e-01
    z[5,6,2]  R2351     -3.0251011252403259e-01
    z[5,6,2]  R2352     -9.3451154232025146e-01
    z[5,6,2]  R2353     1.1230071634054184e-01
    z[5,6,2]  R2354     5.0350213050842285e-01
    z[5,6,2]  R2355     -7.9214975237846375e-02
    z[5,6,2]  R2356     4.4775810837745667e-01
    z[5,6,2]  R2357     6.5615884959697723e-02
    z[5,6,2]  R2358     3.6876353621482849e-01
    z[5,6,2]  R2359     1.0235640406608582e-01
    z[5,6,2]  R2360     0.285470187664032
    z[5,6,2]  R2361     4.4804835319519043e-01
    z[5,6,2]  R2362     -2.7570006251335144e-01
    z[5,6,2]  R2363     -3.4256786108016968e-01
    z[5,6,2]  R2364     -6.4214640855789185e-01
    z[5,6,2]  R2365     -4.3363049626350403e-01
    z[5,6,2]  R2366     -5.2234929800033569e-01
    z[5,6,2]  R2367     -5.8482336997985840e-01
    z[5,6,2]  R2368     -6.3599956035614014e-01
    z[5,6,2]  R2369     -4.3129000067710876e-01
    z[5,6,2]  R2370     -3.1067979335784912e-01
    z[5,6,2]  R2371     1.2998823076486588e-02
    z[5,6,2]  R2372     1.3436928391456604e-01
    z[5,6,2]  R2373     -8.5875076055526733e-01
    z[5,6,2]  R2374     3.4931668639183044e-01
    z[5,6,2]  R2375     -1.3806378841400146e-01
    z[5,6,2]  R2376     5.3474318981170654e-01
    z[5,6,2]  R2377     4.8715031147003174e-01
    z[5,6,2]  R2378     7.9511761665344238e-01
    z[5,6,2]  R2379     6.2353795766830444e-01
    z[5,6,2]  R2380     4.3923398852348328e-01
    z[5,6,2]  R2381     6.3465487957000732e-01
    z[5,6,2]  R2382     6.8603628873825073e-01
    z[5,6,2]  R2383     -5.9742176532745361e-01
    z[5,6,2]  R2384     -3.2313343137502670e-02
    z[5,6,2]  R2385     5.7549959421157837e-01
    z[5,6,2]  R2386     5.0004667043685913e-01
    z[5,6,2]  R2387     7.4372583627700806e-01
    z[5,6,2]  R2388     3.8138604164123535e-01
    z[5,6,2]  R2389     4.4182300567626953e-01
    z[5,6,2]  R2390     -3.1139988452196121e-02
    z[5,6,2]  R2391     -2.3227233439683914e-02
    z[5,6,2]  R2392     3.3875235915184021e-01
    z[5,6,2]  R2393     9.4488039612770081e-02
    z[5,6,2]  R2394     8.1025578081607819e-02
    z[5,6,2]  R2395     -1.2611103057861328e-01
    z[5,6,2]  R2396     -1.7394740879535675e-01
    z[5,6,2]  R2397     6.0527596622705460e-02
    z[5,6,2]  R2398     -1.6110622882843018e-01
    z[5,6,2]  R2399     -4.9716871976852417e-01
    z[5,6,2]  R2400     -2.5580269098281860e-01
    z[5,6,2]  R2401     6.2039190530776978e-01
    z[5,6,2]  R2402     -1.3901941478252411e-01
    z[5,6,2]  R2403     -2.2000320255756378e-01
    z[5,6,2]  R2404     -4.5445561408996582e-01
    z[5,6,2]  R2405     0.338427871465683
    z[5,6,2]  R2406     2.2712418437004089e-01
    z[5,6,2]  R2407     -1.2703558802604675e-01
    z[5,6,2]  R2408     -3.8430088758468628e-01
    z[5,6,2]  R2409     -5.2579361200332642e-01
    z[5,6,2]  R2410     -4.1893506050109863e-01
    z[5,6,2]  R2411     -0.291093111038208
    z[5,6,2]  R2412     7.7318707481026649e-03
    z[5,6,2]  R2413     -3.1196326017379761e-01
    z[5,6,2]  R2414     -4.1107237339019775e-02
    z[5,6,2]  R2415     -6.4293992519378662e-01
    z[5,6,2]  R2416     -1.1912114173173904e-01
    z[5,6,2]  R2417     -3.8850709795951843e-01
    z[5,6,2]  R2418     1.3469946384429932e-01
    z[5,6,2]  R2419     -5.2824616432189941e-01
    z[5,6,2]  R2420     1.5535375475883484e-01
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2335     -1
    z[5,6,3]  R2336     1
    z[5,6,3]  R2343     -3.5028973221778870e-01
    z[5,6,3]  R2344     -8.2846589386463165e-02
    z[5,6,3]  R2345     3.2014327589422464e-03
    z[5,6,3]  R2346     -1.4209325611591339e-01
    z[5,6,3]  R2347     7.1378417313098907e-02
    z[5,6,3]  R2348     2.7369028329849243e-01
    z[5,6,3]  R2349     1.1251424252986908e-01
    z[5,6,3]  R2350     -2.3168994486331940e-01
    z[5,6,3]  R2351     -2.6467078924179077e-01
    z[5,6,3]  R2352     1.0491105914115906e-01
    z[5,6,3]  R2353     0.0898166075348854
    z[5,6,3]  R2354     -1.1651634424924850e-01
    z[5,6,3]  R2355     -2.1026555448770523e-02
    z[5,6,3]  R2356     6.8229183554649353e-02
    z[5,6,3]  R2357     1.2749873101711273e-01
    z[5,6,3]  R2358     4.5084267854690552e-02
    z[5,6,3]  R2359     2.7704444527626038e-01
    z[5,6,3]  R2360     0.355803906917572
    z[5,6,3]  R2361     2.7114561200141907e-01
    z[5,6,3]  R2362     2.5887799263000488e-01
    z[5,6,3]  R2363     -2.9570633172988892e-01
    z[5,6,3]  R2364     -1.3546113669872284e-01
    z[5,6,3]  R2365     1.8554992973804474e-01
    z[5,6,3]  R2366     -1.0255632549524307e-01
    z[5,6,3]  R2367     6.0594443231821060e-02
    z[5,6,3]  R2368     1.5278393030166626e-01
    z[5,6,3]  R2369     6.0688290745019913e-02
    z[5,6,3]  R2370     1.1022411286830902e-01
    z[5,6,3]  R2371     6.9968298077583313e-02
    z[5,6,3]  R2372     -3.5158935189247131e-01
    z[5,6,3]  R2373     1.0737839341163635e-01
    z[5,6,3]  R2374     1.6416235268115997e-01
    z[5,6,3]  R2375     -1.6629289090633392e-01
    z[5,6,3]  R2376     1.3947841711342335e-02
    z[5,6,3]  R2377     2.2214072942733765e-01
    z[5,6,3]  R2378     -1.9584783911705017e-01
    z[5,6,3]  R2379     0.281126469373703
    z[5,6,3]  R2380     -5.7939112186431885e-01
    z[5,6,3]  R2381     5.0716590881347656e-01
    z[5,6,3]  R2382     -3.6588475108146667e-01
    z[5,6,3]  R2383     -7.0546649396419525e-02
    z[5,6,3]  R2384     -0.0752662867307663
    z[5,6,3]  R2385     8.5963584482669830e-02
    z[5,6,3]  R2386     3.4735634922981262e-01
    z[5,6,3]  R2387     7.2962991893291473e-02
    z[5,6,3]  R2388     -6.3346517086029053e-01
    z[5,6,3]  R2389     -3.9998832345008850e-01
    z[5,6,3]  R2390     -0.642842173576355
    z[5,6,3]  R2391     3.7850666791200638e-02
    z[5,6,3]  R2392     1.6396088898181915e-01
    z[5,6,3]  R2393     -2.4991051852703094e-01
    z[5,6,3]  R2394     -4.9090600013732910e-01
    z[5,6,3]  R2395     6.1710983514785767e-02
    z[5,6,3]  R2396     5.2725905179977417e-01
    z[5,6,3]  R2397     -9.0583063662052155e-02
    z[5,6,3]  R2398     5.6679673492908478e-02
    z[5,6,3]  R2399     -8.3638131618499756e-02
    z[5,6,3]  R2400     -7.5017638504505157e-02
    z[5,6,3]  R2401     -0.505151629447937
    z[5,6,3]  R2402     4.1810753941535950e-01
    z[5,6,3]  R2403     3.8386559486389160e-01
    z[5,6,3]  R2404     1.2411752343177795e-01
    z[5,6,3]  R2405     7.2582387924194336e-01
    z[5,6,3]  R2406     3.2066649198532104e-01
    z[5,6,3]  R2407     -5.2132230997085571e-01
    z[5,6,3]  R2408     3.6223033070564270e-01
    z[5,6,3]  R2409     -1.4278753101825714e-01
    z[5,6,3]  R2410     -3.9068478345870972e-01
    z[5,6,3]  R2411     -8.4565865993499756e-01
    z[5,6,3]  R2412     2.4282032251358032e-01
    z[5,6,3]  R2413     5.5883687734603882e-01
    z[5,6,3]  R2414     2.3872801661491394e-01
    z[5,6,3]  R2415     1.3471964001655579e-01
    z[5,6,3]  R2416     -4.1854333877563477e-01
    z[5,6,3]  R2417     -3.5155874490737915e-01
    z[5,6,3]  R2418     -1.6112793982028961e-01
    z[5,6,3]  R2419     -2.5874251127243042e-01
    z[5,6,3]  R2420     4.1502866148948669e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2337     -1
    z[5,6,4]  R2338     1
    z[5,6,4]  R2343     -1.5760441124439240e-01
    z[5,6,4]  R2344     -0.446170449256897
    z[5,6,4]  R2345     1.4418350160121918e-01
    z[5,6,4]  R2346     2.7568724751472473e-01
    z[5,6,4]  R2347     -1.8833811581134796e-01
    z[5,6,4]  R2348     4.8487776517868042e-01
    z[5,6,4]  R2349     -1.1457122862339020e-01
    z[5,6,4]  R2350     4.2632073163986206e-01
    z[5,6,4]  R2351     -3.1137070059776306e-01
    z[5,6,4]  R2352     1.9011422991752625e-01
    z[5,6,4]  R2353     -2.8852125629782677e-02
    z[5,6,4]  R2354     4.2678169906139374e-02
    z[5,6,4]  R2355     2.9173517227172852e-01
    z[5,6,4]  R2356     1.2564468383789062e-01
    z[5,6,4]  R2357     1.3905872404575348e-01
    z[5,6,4]  R2358     -4.8676499724388123e-01
    z[5,6,4]  R2359     2.2104050219058990e-01
    z[5,6,4]  R2360     -2.9736701399087906e-02
    z[5,6,4]  R2361     -3.0702257156372070e-01
    z[5,6,4]  R2362     -2.6921811699867249e-01
    z[5,6,4]  R2363     0.3248310983181
    z[5,6,4]  R2364     -1.3797611929476261e-02
    z[5,6,4]  R2365     -3.2528871297836304e-01
    z[5,6,4]  R2366     -2.8412604331970215e-01
    z[5,6,4]  R2367     9.5781035721302032e-02
    z[5,6,4]  R2368     -1.1825407296419144e-01
    z[5,6,4]  R2369     -4.2378310114145279e-02
    z[5,6,4]  R2370     3.1653138995170593e-01
    z[5,6,4]  R2371     -2.2756111621856689e-01
    z[5,6,4]  R2372     -4.3291386961936951e-01
    z[5,6,4]  R2373     1.3337983749806881e-02
    z[5,6,4]  R2374     1.0181195288896561e-01
    z[5,6,4]  R2375     -3.2449635863304138e-01
    z[5,6,4]  R2376     2.5695082545280457e-01
    z[5,6,4]  R2377     -1.6070288419723511e-01
    z[5,6,4]  R2378     7.1187183260917664e-02
    z[5,6,4]  R2379     2.2787061333656311e-01
    z[5,6,4]  R2380     9.6975639462471008e-02
    z[5,6,4]  R2381     1.7501041293144226e-01
    z[5,6,4]  R2382     -3.1704951077699661e-02
    z[5,6,4]  R2383     3.8346165418624878e-01
    z[5,6,4]  R2384     8.7240047752857208e-02
    z[5,6,4]  R2385     1.6404733061790466e-01
    z[5,6,4]  R2386     -0.103693388402462
    z[5,6,4]  R2387     -2.4617625400424004e-02
    z[5,6,4]  R2388     7.9239696264266968e-02
    z[5,6,4]  R2389     -7.7282056212425232e-02
    z[5,6,4]  R2390     4.3240282684564590e-02
    z[5,6,4]  R2391     2.2247716784477234e-01
    z[5,6,4]  R2392     3.1550772488117218e-02
    z[5,6,4]  R2393     3.3453932404518127e-01
    z[5,6,4]  R2394     3.4996751695871353e-02
    z[5,6,4]  R2395     -2.2012539207935333e-01
    z[5,6,4]  R2396     0.0924614816904068
    z[5,6,4]  R2397     -5.1727288961410522e-01
    z[5,6,4]  R2398     -5.6982642412185669e-01
    z[5,6,4]  R2399     -6.3058042526245117e-01
    z[5,6,4]  R2400     -0.63797527551651
    z[5,6,4]  R2401     6.4029365777969360e-02
    z[5,6,4]  R2402     -4.0712919831275940e-01
    z[5,6,4]  R2403     -2.3536796867847443e-01
    z[5,6,4]  R2404     -2.5398181751370430e-02
    z[5,6,4]  R2405     1.9153960049152374e-02
    z[5,6,4]  R2406     3.9977955818176270e-01
    z[5,6,4]  R2407     3.3283424377441406e-01
    z[5,6,4]  R2408     5.4633373022079468e-01
    z[5,6,4]  R2409     6.9716709852218628e-01
    z[5,6,4]  R2410     0.662807047367096
    z[5,6,4]  R2411     -1.0015836358070374e-01
    z[5,6,4]  R2412     3.7013238668441772e-01
    z[5,6,4]  R2413     3.5940846800804138e-01
    z[5,6,4]  R2414     3.0568319559097290e-01
    z[5,6,4]  R2415     2.8309425711631775e-01
    z[5,6,4]  R2416     4.1968545317649841e-01
    z[5,6,4]  R2417     3.2576340436935425e-01
    z[5,6,4]  R2418     6.6773736476898193e-01
    z[5,6,4]  R2419     4.0545329451560974e-01
    z[5,6,4]  R2420     2.2538343071937561e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2339     -1
    z[5,6,5]  R2340     1
    z[5,6,5]  R2343     -2.6819872856140137e-01
    z[5,6,5]  R2344     -5.8968561887741089e-01
    z[5,6,5]  R2345     -6.0464257001876831e-01
    z[5,6,5]  R2346     -8.3057153224945068e-01
    z[5,6,5]  R2347     -7.3555302619934082e-01
    z[5,6,5]  R2348     -4.6865555644035339e-01
    z[5,6,5]  R2349     -8.2228648662567139e-01
    z[5,6,5]  R2350     -0.147823303937912
    z[5,6,5]  R2351     -2.2303384542465210e-01
    z[5,6,5]  R2352     -2.0209042727947235e-01
    z[5,6,5]  R2353     -0.435959130525589
    z[5,6,5]  R2354     1.2202298641204834e-01
    z[5,6,5]  R2355     4.0418398380279541e-01
    z[5,6,5]  R2356     2.4127800762653351e-01
    z[5,6,5]  R2357     3.3906900882720947e-01
    z[5,6,5]  R2358     1.9571685791015625e-01
    z[5,6,5]  R2359     1.9128678739070892e-01
    z[5,6,5]  R2360     2.3606701195240021e-01
    z[5,6,5]  R2361     2.2576029598712921e-01
    z[5,6,5]  R2362     2.5895288586616516e-01
    z[5,6,5]  R2363     -9.7800888121128082e-02
    z[5,6,5]  R2364     4.8127859830856323e-01
    z[5,6,5]  R2365     3.4379370510578156e-02
    z[5,6,5]  R2366     4.5455446839332581e-01
    z[5,6,5]  R2367     1.9042412936687469e-01
    z[5,6,5]  R2368     -1.4963570237159729e-01
    z[5,6,5]  R2369     1.5943725407123566e-01
    z[5,6,5]  R2370     -1.4460238814353943e-01
    z[5,6,5]  R2371     0.153371199965477
    z[5,6,5]  R2372     -3.3803086262196302e-03
    z[5,6,5]  R2373     -3.6988425254821777e-01
    z[5,6,5]  R2374     -8.7918937206268311e-02
    z[5,6,5]  R2375     1.4753676950931549e-01
    z[5,6,5]  R2376     2.2540971636772156e-01
    z[5,6,5]  R2377     -1.2416794151067734e-01
    z[5,6,5]  R2378     -2.2571860253810883e-01
    z[5,6,5]  R2379     2.1349491178989410e-01
    z[5,6,5]  R2380     -3.2175779342651367e-01
    z[5,6,5]  R2381     -8.9688688516616821e-02
    z[5,6,5]  R2382     -4.6436771750450134e-01
    z[5,6,5]  R2383     -4.8269324004650116e-02
    z[5,6,5]  R2384     -2.1966648101806641e-01
    z[5,6,5]  R2385     -2.3388341069221497e-02
    z[5,6,5]  R2386     -9.2022478580474854e-02
    z[5,6,5]  R2387     5.3409904241561890e-02
    z[5,6,5]  R2388     -3.2578635215759277e-01
    z[5,6,5]  R2389     -8.8714793324470520e-02
    z[5,6,5]  R2390     -0.312102735042572
    z[5,6,5]  R2391     0.867109477519989
    z[5,6,5]  R2392     7.5873774290084839e-01
    z[5,6,5]  R2393     -2.8739389777183533e-01
    z[5,6,5]  R2394     1.8173862993717194e-01
    z[5,6,5]  R2395     -4.7996816039085388e-01
    z[5,6,5]  R2396     -4.1274634003639221e-01
    z[5,6,5]  R2397     -5.5949634313583374e-01
    z[5,6,5]  R2398     2.1661236882209778e-01
    z[5,6,5]  R2399     2.6686948537826538e-01
    z[5,6,5]  R2400     -1.4320363104343414e-01
    z[5,6,5]  R2401     -2.2835098206996918e-01
    z[5,6,5]  R2402     -1.3993540406227112e-01
    z[5,6,5]  R2403     2.7319532632827759e-01
    z[5,6,5]  R2404     -1.7754796147346497e-01
    z[5,6,5]  R2405     -3.8767889142036438e-02
    z[5,6,5]  R2406     8.5950538516044617e-02
    z[5,6,5]  R2407     -1.6209097206592560e-01
    z[5,6,5]  R2408     4.7172746062278748e-01
    z[5,6,5]  R2409     4.6875979751348495e-02
    z[5,6,5]  R2410     2.2366017103195190e-01
    z[5,6,5]  R2411     -0.0428200364112854
    z[5,6,5]  R2412     -4.5355938374996185e-02
    z[5,6,5]  R2413     -2.9270714148879051e-02
    z[5,6,5]  R2414     6.7510330677032471e-01
    z[5,6,5]  R2415     -1.3562041521072388e-01
    z[5,6,5]  R2416     1.8841637670993805e-01
    z[5,6,5]  R2417     -1.9970889389514923e-01
    z[5,6,5]  R2418     -5.9418958425521851e-01
    z[5,6,5]  R2419     4.2719464749097824e-02
    z[5,6,5]  R2420     5.6427270174026489e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2341     -1
    z[5,6,6]  R2342     1
    z[5,6,6]  R2343     -2.4073512852191925e-01
    z[5,6,6]  R2344     -1.2841922044754028e-01
    z[5,6,6]  R2345     1.9455133378505707e-01
    z[5,6,6]  R2346     -9.2191033065319061e-02
    z[5,6,6]  R2347     6.5413199365139008e-02
    z[5,6,6]  R2348     5.1288757473230362e-02
    z[5,6,6]  R2349     3.5724171996116638e-01
    z[5,6,6]  R2350     1.0929439961910248e-01
    z[5,6,6]  R2351     5.8313125371932983e-01
    z[5,6,6]  R2352     -1.7309702932834625e-02
    z[5,6,6]  R2353     -5.0625193119049072e-01
    z[5,6,6]  R2354     -1.2640132009983063e-01
    z[5,6,6]  R2355     8.3364490419626236e-03
    z[5,6,6]  R2356     -1.4134739339351654e-01
    z[5,6,6]  R2357     2.9050955176353455e-01
    z[5,6,6]  R2358     -3.0355167388916016e-01
    z[5,6,6]  R2359     -1.9361393153667450e-01
    z[5,6,6]  R2360     1.2838077545166016e-01
    z[5,6,6]  R2361     7.5807720422744751e-02
    z[5,6,6]  R2362     -4.8850125074386597e-01
    z[5,6,6]  R2363     -2.0394796133041382e-01
    z[5,6,6]  R2364     1.3101337850093842e-01
    z[5,6,6]  R2365     2.6964184641838074e-01
    z[5,6,6]  R2366     -2.0788739621639252e-01
    z[5,6,6]  R2367     -3.7755563855171204e-01
    z[5,6,6]  R2368     -2.4842904508113861e-01
    z[5,6,6]  R2369     1.4364540576934814e-01
    z[5,6,6]  R2370     1.6188396513462067e-01
    z[5,6,6]  R2371     -2.2402470931410789e-02
    z[5,6,6]  R2372     -1.9644704461097717e-01
    z[5,6,6]  R2373     9.3915618956089020e-02
    z[5,6,6]  R2374     0.454225093126297
    z[5,6,6]  R2375     8.5165657103061676e-02
    z[5,6,6]  R2376     4.3079477548599243e-01
    z[5,6,6]  R2377     3.4523203969001770e-01
    z[5,6,6]  R2378     1.4997215941548347e-02
    z[5,6,6]  R2379     -3.3137810230255127e-01
    z[5,6,6]  R2380     4.1690585017204285e-01
    z[5,6,6]  R2381     -2.6097485423088074e-01
    z[5,6,6]  R2382     -3.3129367977380753e-02
    z[5,6,6]  R2383     5.1669991016387939e-01
    z[5,6,6]  R2384     6.0928516089916229e-02
    z[5,6,6]  R2385     3.1819772720336914e-01
    z[5,6,6]  R2386     -3.2967534661293030e-01
    z[5,6,6]  R2387     -2.7402088046073914e-01
    z[5,6,6]  R2388     -1.2210775911808014e-01
    z[5,6,6]  R2389     -9.0648196637630463e-02
    z[5,6,6]  R2390     -3.0467414855957031e-01
    z[5,6,6]  R2391     -2.7823492884635925e-01
    z[5,6,6]  R2392     -3.6152851581573486e-01
    z[5,6,6]  R2393     -9.2577878385782242e-03
    z[5,6,6]  R2394     3.5427427291870117e-01
    z[5,6,6]  R2395     -6.6698074340820312e-02
    z[5,6,6]  R2396     6.1350151896476746e-02
    z[5,6,6]  R2397     5.8808368444442749e-01
    z[5,6,6]  R2398     0.0457102470099926
    z[5,6,6]  R2399     8.3541408181190491e-02
    z[5,6,6]  R2400     2.9236632585525513e-01
    z[5,6,6]  R2401     -1.8652334809303284e-01
    z[5,6,6]  R2402     6.8160313367843628e-01
    z[5,6,6]  R2403     -6.0713642835617065e-01
    z[5,6,6]  R2404     -6.9817709922790527e-01
    z[5,6,6]  R2405     -5.8500305749475956e-04
    z[5,6,6]  R2406     -9.1050438582897186e-02
    z[5,6,6]  R2407     2.8957182168960571e-01
    z[5,6,6]  R2408     -3.2140389084815979e-02
    z[5,6,6]  R2409     -1.0028751939535141e-01
    z[5,6,6]  R2410     9.1935552656650543e-02
    z[5,6,6]  R2411     9.6539907157421112e-02
    z[5,6,6]  R2412     1.2783069908618927e-01
    z[5,6,6]  R2413     -3.7338647991418839e-02
    z[5,6,6]  R2414     -2.3746129870414734e-01
    z[5,6,6]  R2415     -1.7043109983205795e-02
    z[5,6,6]  R2416     -1.3536711037158966e-01
    z[5,6,6]  R2417     -3.2050654292106628e-01
    z[5,6,6]  R2418     9.1828316450119019e-02
    z[5,6,6]  R2419     -2.7272889018058777e-01
    z[5,6,6]  R2420     4.3219694495201111e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2421     -1
    z[6,5,0]  R2422     1
    z[6,5,0]  R2435     -1.2808595784008503e-02
    z[6,5,0]  R2436     1.9614402204751968e-02
    z[6,5,0]  R2437     0.426605224609375
    z[6,5,0]  R2438     -3.6192893981933594e-01
    z[6,5,0]  R2439     1.8868026137351990e-01
    z[6,5,0]  R2440     5.9049296379089355e-01
    z[6,5,0]  R2441     -3.0709570273756981e-02
    z[6,5,0]  R2442     -4.2208233475685120e-01
    z[6,5,0]  R2443     3.7201613187789917e-01
    z[6,5,0]  R2444     -5.7482451200485229e-02
    z[6,5,0]  R2445     -1.5361925959587097e-01
    z[6,5,0]  R2446     -0.279266357421875
    z[6,5,0]  R2447     -3.1568318605422974e-01
    z[6,5,0]  R2448     6.2692761421203613e-01
    z[6,5,0]  R2449     -6.3902062177658081e-01
    z[6,5,0]  R2450     1.4368177950382233e-01
    z[6,5,0]  R2451     3.5535556077957153e-01
    z[6,5,0]  R2452     4.1406655311584473e-01
    z[6,5,0]  R2453     -2.4012443423271179e-01
    z[6,5,0]  R2454     7.6279568672180176e-01
    z[6,5,0]  R2455     4.7961592674255371e-01
    z[6,5,0]  R2456     3.2556268572807312e-01
    z[6,5,0]  R2457     5.9694701433181763e-01
    z[6,5,0]  R2458     5.6772679090499878e-01
    z[6,5,0]  R2459     5.7338184118270874e-01
    z[6,5,0]  R2460     -3.6375731229782104e-01
    z[6,5,0]  R2461     5.2672243118286133e-01
    z[6,5,0]  R2462     3.2841497659683228e-01
    z[6,5,0]  R2463     6.8481421470642090e-01
    z[6,5,0]  R2464     4.2407432198524475e-01
    z[6,5,0]  R2465     4.7219285368919373e-01
    z[6,5,0]  R2466     2.9902374744415283e-01
    z[6,5,0]  R2467     0.471809983253479
    z[6,5,0]  R2468     0.557436466217041
    z[6,5,0]  R2469     4.0043455362319946e-01
    z[6,5,0]  R2470     4.1340434551239014e-01
    z[6,5,0]  R2471     5.8189934492111206e-01
    z[6,5,0]  R2472     -1.5772767364978790e-01
    z[6,5,0]  R2473     -2.9264262318611145e-01
    z[6,5,0]  R2474     2.9907515645027161e-01
    z[6,5,0]  R2475     1.0870525985956192e-01
    z[6,5,0]  R2476     4.1055597364902496e-02
    z[6,5,0]  R2477     3.0551312491297722e-02
    z[6,5,0]  R2478     -1.6856157779693604e-01
    z[6,5,0]  R2479     -2.2263364493846893e-01
    z[6,5,0]  R2480     -2.1212583780288696e-01
    z[6,5,0]  R2481     -3.8890343159437180e-02
    z[6,5,0]  R2482     -4.6333214640617371e-01
    z[6,5,0]  R2483     6.4265592955052853e-03
    z[6,5,0]  R2484     -3.6780755966901779e-02
    z[6,5,0]  R2485     -2.7314704656600952e-01
    z[6,5,0]  R2486     -3.8201864808797836e-02
    z[6,5,0]  R2487     -3.4061646461486816e-01
    z[6,5,0]  R2488     -3.0403605103492737e-01
    z[6,5,0]  R2489     4.5423296093940735e-01
    z[6,5,0]  R2490     -4.1578122973442078e-01
    z[6,5,0]  R2491     -3.0241400003433228e-01
    z[6,5,0]  R2492     3.4000226855278015e-01
    z[6,5,0]  R2493     -1.1205981671810150e-01
    z[6,5,0]  R2494     7.9000806808471680e-01
    z[6,5,0]  R2495     5.3096508979797363e-01
    z[6,5,0]  R2496     2.3741620779037476e-01
    z[6,5,0]  R2497     5.5252593010663986e-02
    z[6,5,0]  R2498     6.1953570693731308e-02
    z[6,5,0]  R2499     3.7581798434257507e-01
    z[6,5,0]  R2500     -0.425283819437027
    z[6,5,0]  R2501     2.7152949571609497e-01
    z[6,5,0]  R2502     -4.0629756450653076e-01
    z[6,5,0]  R2503     -9.1883011162281036e-02
    z[6,5,0]  R2504     3.7221607565879822e-01
    z[6,5,0]  R2505     1.4681921899318695e-01
    z[6,5,0]  R2506     4.0812635421752930e-01
    z[6,5,0]  R2507     2.3946161568164825e-01
    z[6,5,0]  R2508     -5.7091158628463745e-01
    z[6,5,0]  R2509     -7.7465665340423584e-01
    z[6,5,0]  R2510     -6.2244963645935059e-01
    z[6,5,0]  R2511     -2.3654049634933472e-01
    z[6,5,0]  R2512     -3.8324549794197083e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2423     -1
    z[6,5,1]  R2424     1
    z[6,5,1]  R2435     -8.5665351152420044e-01
    z[6,5,1]  R2436     -7.6960867643356323e-01
    z[6,5,1]  R2437     -7.1765071153640747e-01
    z[6,5,1]  R2438     -0.614878237247467
    z[6,5,1]  R2439     1.6149619221687317e-01
    z[6,5,1]  R2440     -4.9843534827232361e-01
    z[6,5,1]  R2441     -5.1870477199554443e-01
    z[6,5,1]  R2442     -0.48763307929039
    z[6,5,1]  R2443     3.6125433444976807e-01
    z[6,5,1]  R2444     -3.9068728685379028e-01
    z[6,5,1]  R2445     0.531035304069519
    z[6,5,1]  R2446     4.2480081319808960e-01
    z[6,5,1]  R2447     5.0707006454467773e-01
    z[6,5,1]  R2448     -5.2635347843170166e-01
    z[6,5,1]  R2449     2.8780847787857056e-01
    z[6,5,1]  R2450     -0.422394722700119
    z[6,5,1]  R2451     -2.8031843900680542e-01
    z[6,5,1]  R2452     -5.1171295344829559e-02
    z[6,5,1]  R2453     0.348254531621933
    z[6,5,1]  R2454     -4.5135945081710815e-01
    z[6,5,1]  R2455     -4.7845938801765442e-01
    z[6,5,1]  R2456     -0.479305237531662
    z[6,5,1]  R2457     -3.3661171793937683e-01
    z[6,5,1]  R2458     -5.0828850269317627e-01
    z[6,5,1]  R2459     -3.8467141985893250e-01
    z[6,5,1]  R2460     -1.2730935215950012e-01
    z[6,5,1]  R2461     -3.6874574422836304e-01
    z[6,5,1]  R2462     -3.7385082244873047e-01
    z[6,5,1]  R2463     -8.1086881458759308e-02
    z[6,5,1]  R2464     -6.2803596258163452e-02
    z[6,5,1]  R2465     -3.4306907653808594e-01
    z[6,5,1]  R2466     -1.9525711238384247e-01
    z[6,5,1]  R2467     -4.2736664414405823e-01
    z[6,5,1]  R2468     3.7686202675104141e-02
    z[6,5,1]  R2469     8.1025041639804840e-02
    z[6,5,1]  R2470     -5.9450343251228333e-02
    z[6,5,1]  R2471     1.1442169547080994e-01
    z[6,5,1]  R2472     1.1627613753080368e-01
    z[6,5,1]  R2473     6.6820508241653442e-01
    z[6,5,1]  R2474     -7.8152108192443848e-01
    z[6,5,1]  R2475     -8.5610884428024292e-01
    z[6,5,1]  R2476     -8.3617657423019409e-01
    z[6,5,1]  R2477     -8.7166756391525269e-01
    z[6,5,1]  R2478     6.8277293443679810e-01
    z[6,5,1]  R2479     -8.6038815975189209e-01
    z[6,5,1]  R2480     -8.2086509466171265e-01
    z[6,5,1]  R2481     -7.5712805986404419e-01
    z[6,5,1]  R2482     0.513932466506958
    z[6,5,1]  R2483     7.9905492067337036e-01
    z[6,5,1]  R2484     5.6476676464080811e-01
    z[6,5,1]  R2485     7.2334295511245728e-01
    z[6,5,1]  R2486     6.2016886472702026e-01
    z[6,5,1]  R2487     5.9186714887619019e-01
    z[6,5,1]  R2488     6.1776363849639893e-01
    z[6,5,1]  R2489     7.4573993682861328e-01
    z[6,5,1]  R2490     7.5574219226837158e-01
    z[6,5,1]  R2491     9.0976518392562866e-01
    z[6,5,1]  R2492     7.1882611513137817e-01
    z[6,5,1]  R2493     3.0438011884689331e-01
    z[6,5,1]  R2494     -4.9998942762613297e-02
    z[6,5,1]  R2495     -0.732832133769989
    z[6,5,1]  R2496     5.9587860107421875e-01
    z[6,5,1]  R2497     -7.4152338504791260e-01
    z[6,5,1]  R2498     5.1899129152297974e-01
    z[6,5,1]  R2499     4.2850050330162048e-01
    z[6,5,1]  R2500     6.1402846127748489e-02
    z[6,5,1]  R2501     3.9935836195945740e-01
    z[6,5,1]  R2502     -1.1253734678030014e-01
    z[6,5,1]  R2503     4.6186193823814392e-01
    z[6,5,1]  R2504     -8.9172267913818359e-01
    z[6,5,1]  R2505     7.1494489908218384e-01
    z[6,5,1]  R2506     5.7863938808441162e-01
    z[6,5,1]  R2507     5.5286550521850586e-01
    z[6,5,1]  R2508     -7.4655382195487618e-04
    z[6,5,1]  R2509     -1.5049608051776886e-01
    z[6,5,1]  R2510     -7.8971035778522491e-02
    z[6,5,1]  R2511     -2.5156855583190918e-01
    z[6,5,1]  R2512     -6.4073219895362854e-02
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2425     -1
    z[6,5,2]  R2426     1
    z[6,5,2]  R2435     9.4488039612770081e-02
    z[6,5,2]  R2436     8.1025578081607819e-02
    z[6,5,2]  R2437     -1.2611103057861328e-01
    z[6,5,2]  R2438     -1.7394740879535675e-01
    z[6,5,2]  R2439     6.0527596622705460e-02
    z[6,5,2]  R2440     -1.6110622882843018e-01
    z[6,5,2]  R2441     -4.9716871976852417e-01
    z[6,5,2]  R2442     -2.5580269098281860e-01
    z[6,5,2]  R2443     6.2039190530776978e-01
    z[6,5,2]  R2444     -1.3901941478252411e-01
    z[6,5,2]  R2445     -2.2000320255756378e-01
    z[6,5,2]  R2446     -4.5445561408996582e-01
    z[6,5,2]  R2447     0.338427871465683
    z[6,5,2]  R2448     2.2712418437004089e-01
    z[6,5,2]  R2449     -1.2703558802604675e-01
    z[6,5,2]  R2450     -3.8430088758468628e-01
    z[6,5,2]  R2451     -5.2579361200332642e-01
    z[6,5,2]  R2452     -4.1893506050109863e-01
    z[6,5,2]  R2453     -0.291093111038208
    z[6,5,2]  R2454     7.7318707481026649e-03
    z[6,5,2]  R2455     -3.1196326017379761e-01
    z[6,5,2]  R2456     -4.1107237339019775e-02
    z[6,5,2]  R2457     -6.4293992519378662e-01
    z[6,5,2]  R2458     -1.1912114173173904e-01
    z[6,5,2]  R2459     -3.8850709795951843e-01
    z[6,5,2]  R2460     1.3469946384429932e-01
    z[6,5,2]  R2461     -5.2824616432189941e-01
    z[6,5,2]  R2462     1.5535375475883484e-01
    z[6,5,2]  R2463     -4.9701955914497375e-01
    z[6,5,2]  R2464     -4.9604868888854980e-01
    z[6,5,2]  R2465     -4.8486655950546265e-01
    z[6,5,2]  R2466     -2.7913671731948853e-01
    z[6,5,2]  R2467     -9.4179607927799225e-02
    z[6,5,2]  R2468     -3.9441445469856262e-01
    z[6,5,2]  R2469     -5.9366188943386078e-02
    z[6,5,2]  R2470     -7.4587929248809814e-01
    z[6,5,2]  R2471     -3.0251011252403259e-01
    z[6,5,2]  R2472     -9.3451154232025146e-01
    z[6,5,2]  R2473     1.1230071634054184e-01
    z[6,5,2]  R2474     5.0350213050842285e-01
    z[6,5,2]  R2475     -7.9214975237846375e-02
    z[6,5,2]  R2476     4.4775810837745667e-01
    z[6,5,2]  R2477     6.5615884959697723e-02
    z[6,5,2]  R2478     3.6876353621482849e-01
    z[6,5,2]  R2479     1.0235640406608582e-01
    z[6,5,2]  R2480     0.285470187664032
    z[6,5,2]  R2481     4.4804835319519043e-01
    z[6,5,2]  R2482     -2.7570006251335144e-01
    z[6,5,2]  R2483     -3.4256786108016968e-01
    z[6,5,2]  R2484     -6.4214640855789185e-01
    z[6,5,2]  R2485     -4.3363049626350403e-01
    z[6,5,2]  R2486     -5.2234929800033569e-01
    z[6,5,2]  R2487     -5.8482336997985840e-01
    z[6,5,2]  R2488     -6.3599956035614014e-01
    z[6,5,2]  R2489     -4.3129000067710876e-01
    z[6,5,2]  R2490     -3.1067979335784912e-01
    z[6,5,2]  R2491     1.2998823076486588e-02
    z[6,5,2]  R2492     1.3436928391456604e-01
    z[6,5,2]  R2493     -8.5875076055526733e-01
    z[6,5,2]  R2494     3.4931668639183044e-01
    z[6,5,2]  R2495     -1.3806378841400146e-01
    z[6,5,2]  R2496     5.3474318981170654e-01
    z[6,5,2]  R2497     4.8715031147003174e-01
    z[6,5,2]  R2498     7.9511761665344238e-01
    z[6,5,2]  R2499     6.2353795766830444e-01
    z[6,5,2]  R2500     4.3923398852348328e-01
    z[6,5,2]  R2501     6.3465487957000732e-01
    z[6,5,2]  R2502     6.8603628873825073e-01
    z[6,5,2]  R2503     -5.9742176532745361e-01
    z[6,5,2]  R2504     -3.2313343137502670e-02
    z[6,5,2]  R2505     5.7549959421157837e-01
    z[6,5,2]  R2506     5.0004667043685913e-01
    z[6,5,2]  R2507     7.4372583627700806e-01
    z[6,5,2]  R2508     3.8138604164123535e-01
    z[6,5,2]  R2509     4.4182300567626953e-01
    z[6,5,2]  R2510     -3.1139988452196121e-02
    z[6,5,2]  R2511     -2.3227233439683914e-02
    z[6,5,2]  R2512     3.3875235915184021e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2427     -1
    z[6,5,3]  R2428     1
    z[6,5,3]  R2435     -2.4991051852703094e-01
    z[6,5,3]  R2436     -4.9090600013732910e-01
    z[6,5,3]  R2437     6.1710983514785767e-02
    z[6,5,3]  R2438     5.2725905179977417e-01
    z[6,5,3]  R2439     -9.0583063662052155e-02
    z[6,5,3]  R2440     5.6679673492908478e-02
    z[6,5,3]  R2441     -8.3638131618499756e-02
    z[6,5,3]  R2442     -7.5017638504505157e-02
    z[6,5,3]  R2443     -0.505151629447937
    z[6,5,3]  R2444     4.1810753941535950e-01
    z[6,5,3]  R2445     3.8386559486389160e-01
    z[6,5,3]  R2446     1.2411752343177795e-01
    z[6,5,3]  R2447     7.2582387924194336e-01
    z[6,5,3]  R2448     3.2066649198532104e-01
    z[6,5,3]  R2449     -5.2132230997085571e-01
    z[6,5,3]  R2450     3.6223033070564270e-01
    z[6,5,3]  R2451     -1.4278753101825714e-01
    z[6,5,3]  R2452     -3.9068478345870972e-01
    z[6,5,3]  R2453     -8.4565865993499756e-01
    z[6,5,3]  R2454     2.4282032251358032e-01
    z[6,5,3]  R2455     5.5883687734603882e-01
    z[6,5,3]  R2456     2.3872801661491394e-01
    z[6,5,3]  R2457     1.3471964001655579e-01
    z[6,5,3]  R2458     -4.1854333877563477e-01
    z[6,5,3]  R2459     -3.5155874490737915e-01
    z[6,5,3]  R2460     -1.6112793982028961e-01
    z[6,5,3]  R2461     -2.5874251127243042e-01
    z[6,5,3]  R2462     4.1502866148948669e-01
    z[6,5,3]  R2463     -3.5028973221778870e-01
    z[6,5,3]  R2464     -8.2846589386463165e-02
    z[6,5,3]  R2465     3.2014327589422464e-03
    z[6,5,3]  R2466     -1.4209325611591339e-01
    z[6,5,3]  R2467     7.1378417313098907e-02
    z[6,5,3]  R2468     2.7369028329849243e-01
    z[6,5,3]  R2469     1.1251424252986908e-01
    z[6,5,3]  R2470     -2.3168994486331940e-01
    z[6,5,3]  R2471     -2.6467078924179077e-01
    z[6,5,3]  R2472     1.0491105914115906e-01
    z[6,5,3]  R2473     0.0898166075348854
    z[6,5,3]  R2474     -1.1651634424924850e-01
    z[6,5,3]  R2475     -2.1026555448770523e-02
    z[6,5,3]  R2476     6.8229183554649353e-02
    z[6,5,3]  R2477     1.2749873101711273e-01
    z[6,5,3]  R2478     4.5084267854690552e-02
    z[6,5,3]  R2479     2.7704444527626038e-01
    z[6,5,3]  R2480     0.355803906917572
    z[6,5,3]  R2481     2.7114561200141907e-01
    z[6,5,3]  R2482     2.5887799263000488e-01
    z[6,5,3]  R2483     -2.9570633172988892e-01
    z[6,5,3]  R2484     -1.3546113669872284e-01
    z[6,5,3]  R2485     1.8554992973804474e-01
    z[6,5,3]  R2486     -1.0255632549524307e-01
    z[6,5,3]  R2487     6.0594443231821060e-02
    z[6,5,3]  R2488     1.5278393030166626e-01
    z[6,5,3]  R2489     6.0688290745019913e-02
    z[6,5,3]  R2490     1.1022411286830902e-01
    z[6,5,3]  R2491     6.9968298077583313e-02
    z[6,5,3]  R2492     -3.5158935189247131e-01
    z[6,5,3]  R2493     1.0737839341163635e-01
    z[6,5,3]  R2494     1.6416235268115997e-01
    z[6,5,3]  R2495     -1.6629289090633392e-01
    z[6,5,3]  R2496     1.3947841711342335e-02
    z[6,5,3]  R2497     2.2214072942733765e-01
    z[6,5,3]  R2498     -1.9584783911705017e-01
    z[6,5,3]  R2499     0.281126469373703
    z[6,5,3]  R2500     -5.7939112186431885e-01
    z[6,5,3]  R2501     5.0716590881347656e-01
    z[6,5,3]  R2502     -3.6588475108146667e-01
    z[6,5,3]  R2503     -7.0546649396419525e-02
    z[6,5,3]  R2504     -0.0752662867307663
    z[6,5,3]  R2505     8.5963584482669830e-02
    z[6,5,3]  R2506     3.4735634922981262e-01
    z[6,5,3]  R2507     7.2962991893291473e-02
    z[6,5,3]  R2508     -6.3346517086029053e-01
    z[6,5,3]  R2509     -3.9998832345008850e-01
    z[6,5,3]  R2510     -0.642842173576355
    z[6,5,3]  R2511     3.7850666791200638e-02
    z[6,5,3]  R2512     1.6396088898181915e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2429     -1
    z[6,5,4]  R2430     1
    z[6,5,4]  R2435     3.3453932404518127e-01
    z[6,5,4]  R2436     3.4996751695871353e-02
    z[6,5,4]  R2437     -2.2012539207935333e-01
    z[6,5,4]  R2438     0.0924614816904068
    z[6,5,4]  R2439     -5.1727288961410522e-01
    z[6,5,4]  R2440     -5.6982642412185669e-01
    z[6,5,4]  R2441     -6.3058042526245117e-01
    z[6,5,4]  R2442     -0.63797527551651
    z[6,5,4]  R2443     6.4029365777969360e-02
    z[6,5,4]  R2444     -4.0712919831275940e-01
    z[6,5,4]  R2445     -2.3536796867847443e-01
    z[6,5,4]  R2446     -2.5398181751370430e-02
    z[6,5,4]  R2447     1.9153960049152374e-02
    z[6,5,4]  R2448     3.9977955818176270e-01
    z[6,5,4]  R2449     3.3283424377441406e-01
    z[6,5,4]  R2450     5.4633373022079468e-01
    z[6,5,4]  R2451     6.9716709852218628e-01
    z[6,5,4]  R2452     0.662807047367096
    z[6,5,4]  R2453     -1.0015836358070374e-01
    z[6,5,4]  R2454     3.7013238668441772e-01
    z[6,5,4]  R2455     3.5940846800804138e-01
    z[6,5,4]  R2456     3.0568319559097290e-01
    z[6,5,4]  R2457     2.8309425711631775e-01
    z[6,5,4]  R2458     4.1968545317649841e-01
    z[6,5,4]  R2459     3.2576340436935425e-01
    z[6,5,4]  R2460     6.6773736476898193e-01
    z[6,5,4]  R2461     4.0545329451560974e-01
    z[6,5,4]  R2462     2.2538343071937561e-01
    z[6,5,4]  R2463     -1.5760441124439240e-01
    z[6,5,4]  R2464     -0.446170449256897
    z[6,5,4]  R2465     1.4418350160121918e-01
    z[6,5,4]  R2466     2.7568724751472473e-01
    z[6,5,4]  R2467     -1.8833811581134796e-01
    z[6,5,4]  R2468     4.8487776517868042e-01
    z[6,5,4]  R2469     -1.1457122862339020e-01
    z[6,5,4]  R2470     4.2632073163986206e-01
    z[6,5,4]  R2471     -3.1137070059776306e-01
    z[6,5,4]  R2472     1.9011422991752625e-01
    z[6,5,4]  R2473     -2.8852125629782677e-02
    z[6,5,4]  R2474     4.2678169906139374e-02
    z[6,5,4]  R2475     2.9173517227172852e-01
    z[6,5,4]  R2476     1.2564468383789062e-01
    z[6,5,4]  R2477     1.3905872404575348e-01
    z[6,5,4]  R2478     -4.8676499724388123e-01
    z[6,5,4]  R2479     2.2104050219058990e-01
    z[6,5,4]  R2480     -2.9736701399087906e-02
    z[6,5,4]  R2481     -3.0702257156372070e-01
    z[6,5,4]  R2482     -2.6921811699867249e-01
    z[6,5,4]  R2483     0.3248310983181
    z[6,5,4]  R2484     -1.3797611929476261e-02
    z[6,5,4]  R2485     -3.2528871297836304e-01
    z[6,5,4]  R2486     -2.8412604331970215e-01
    z[6,5,4]  R2487     9.5781035721302032e-02
    z[6,5,4]  R2488     -1.1825407296419144e-01
    z[6,5,4]  R2489     -4.2378310114145279e-02
    z[6,5,4]  R2490     3.1653138995170593e-01
    z[6,5,4]  R2491     -2.2756111621856689e-01
    z[6,5,4]  R2492     -4.3291386961936951e-01
    z[6,5,4]  R2493     1.3337983749806881e-02
    z[6,5,4]  R2494     1.0181195288896561e-01
    z[6,5,4]  R2495     -3.2449635863304138e-01
    z[6,5,4]  R2496     2.5695082545280457e-01
    z[6,5,4]  R2497     -1.6070288419723511e-01
    z[6,5,4]  R2498     7.1187183260917664e-02
    z[6,5,4]  R2499     2.2787061333656311e-01
    z[6,5,4]  R2500     9.6975639462471008e-02
    z[6,5,4]  R2501     1.7501041293144226e-01
    z[6,5,4]  R2502     -3.1704951077699661e-02
    z[6,5,4]  R2503     3.8346165418624878e-01
    z[6,5,4]  R2504     8.7240047752857208e-02
    z[6,5,4]  R2505     1.6404733061790466e-01
    z[6,5,4]  R2506     -0.103693388402462
    z[6,5,4]  R2507     -2.4617625400424004e-02
    z[6,5,4]  R2508     7.9239696264266968e-02
    z[6,5,4]  R2509     -7.7282056212425232e-02
    z[6,5,4]  R2510     4.3240282684564590e-02
    z[6,5,4]  R2511     2.2247716784477234e-01
    z[6,5,4]  R2512     3.1550772488117218e-02
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2431     -1
    z[6,5,5]  R2432     1
    z[6,5,5]  R2435     -2.8739389777183533e-01
    z[6,5,5]  R2436     1.8173862993717194e-01
    z[6,5,5]  R2437     -4.7996816039085388e-01
    z[6,5,5]  R2438     -4.1274634003639221e-01
    z[6,5,5]  R2439     -5.5949634313583374e-01
    z[6,5,5]  R2440     2.1661236882209778e-01
    z[6,5,5]  R2441     2.6686948537826538e-01
    z[6,5,5]  R2442     -1.4320363104343414e-01
    z[6,5,5]  R2443     -2.2835098206996918e-01
    z[6,5,5]  R2444     -1.3993540406227112e-01
    z[6,5,5]  R2445     2.7319532632827759e-01
    z[6,5,5]  R2446     -1.7754796147346497e-01
    z[6,5,5]  R2447     -3.8767889142036438e-02
    z[6,5,5]  R2448     8.5950538516044617e-02
    z[6,5,5]  R2449     -1.6209097206592560e-01
    z[6,5,5]  R2450     4.7172746062278748e-01
    z[6,5,5]  R2451     4.6875979751348495e-02
    z[6,5,5]  R2452     2.2366017103195190e-01
    z[6,5,5]  R2453     -0.0428200364112854
    z[6,5,5]  R2454     -4.5355938374996185e-02
    z[6,5,5]  R2455     -2.9270714148879051e-02
    z[6,5,5]  R2456     6.7510330677032471e-01
    z[6,5,5]  R2457     -1.3562041521072388e-01
    z[6,5,5]  R2458     1.8841637670993805e-01
    z[6,5,5]  R2459     -1.9970889389514923e-01
    z[6,5,5]  R2460     -5.9418958425521851e-01
    z[6,5,5]  R2461     4.2719464749097824e-02
    z[6,5,5]  R2462     5.6427270174026489e-01
    z[6,5,5]  R2463     -2.6819872856140137e-01
    z[6,5,5]  R2464     -5.8968561887741089e-01
    z[6,5,5]  R2465     -6.0464257001876831e-01
    z[6,5,5]  R2466     -8.3057153224945068e-01
    z[6,5,5]  R2467     -7.3555302619934082e-01
    z[6,5,5]  R2468     -4.6865555644035339e-01
    z[6,5,5]  R2469     -8.2228648662567139e-01
    z[6,5,5]  R2470     -0.147823303937912
    z[6,5,5]  R2471     -2.2303384542465210e-01
    z[6,5,5]  R2472     -2.0209042727947235e-01
    z[6,5,5]  R2473     -0.435959130525589
    z[6,5,5]  R2474     1.2202298641204834e-01
    z[6,5,5]  R2475     4.0418398380279541e-01
    z[6,5,5]  R2476     2.4127800762653351e-01
    z[6,5,5]  R2477     3.3906900882720947e-01
    z[6,5,5]  R2478     1.9571685791015625e-01
    z[6,5,5]  R2479     1.9128678739070892e-01
    z[6,5,5]  R2480     2.3606701195240021e-01
    z[6,5,5]  R2481     2.2576029598712921e-01
    z[6,5,5]  R2482     2.5895288586616516e-01
    z[6,5,5]  R2483     -9.7800888121128082e-02
    z[6,5,5]  R2484     4.8127859830856323e-01
    z[6,5,5]  R2485     3.4379370510578156e-02
    z[6,5,5]  R2486     4.5455446839332581e-01
    z[6,5,5]  R2487     1.9042412936687469e-01
    z[6,5,5]  R2488     -1.4963570237159729e-01
    z[6,5,5]  R2489     1.5943725407123566e-01
    z[6,5,5]  R2490     -1.4460238814353943e-01
    z[6,5,5]  R2491     0.153371199965477
    z[6,5,5]  R2492     -3.3803086262196302e-03
    z[6,5,5]  R2493     -3.6988425254821777e-01
    z[6,5,5]  R2494     -8.7918937206268311e-02
    z[6,5,5]  R2495     1.4753676950931549e-01
    z[6,5,5]  R2496     2.2540971636772156e-01
    z[6,5,5]  R2497     -1.2416794151067734e-01
    z[6,5,5]  R2498     -2.2571860253810883e-01
    z[6,5,5]  R2499     2.1349491178989410e-01
    z[6,5,5]  R2500     -3.2175779342651367e-01
    z[6,5,5]  R2501     -8.9688688516616821e-02
    z[6,5,5]  R2502     -4.6436771750450134e-01
    z[6,5,5]  R2503     -4.8269324004650116e-02
    z[6,5,5]  R2504     -2.1966648101806641e-01
    z[6,5,5]  R2505     -2.3388341069221497e-02
    z[6,5,5]  R2506     -9.2022478580474854e-02
    z[6,5,5]  R2507     5.3409904241561890e-02
    z[6,5,5]  R2508     -3.2578635215759277e-01
    z[6,5,5]  R2509     -8.8714793324470520e-02
    z[6,5,5]  R2510     -0.312102735042572
    z[6,5,5]  R2511     0.867109477519989
    z[6,5,5]  R2512     7.5873774290084839e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2433     -1
    z[6,5,6]  R2434     1
    z[6,5,6]  R2435     -9.2577878385782242e-03
    z[6,5,6]  R2436     3.5427427291870117e-01
    z[6,5,6]  R2437     -6.6698074340820312e-02
    z[6,5,6]  R2438     6.1350151896476746e-02
    z[6,5,6]  R2439     5.8808368444442749e-01
    z[6,5,6]  R2440     0.0457102470099926
    z[6,5,6]  R2441     8.3541408181190491e-02
    z[6,5,6]  R2442     2.9236632585525513e-01
    z[6,5,6]  R2443     -1.8652334809303284e-01
    z[6,5,6]  R2444     6.8160313367843628e-01
    z[6,5,6]  R2445     -6.0713642835617065e-01
    z[6,5,6]  R2446     -6.9817709922790527e-01
    z[6,5,6]  R2447     -5.8500305749475956e-04
    z[6,5,6]  R2448     -9.1050438582897186e-02
    z[6,5,6]  R2449     2.8957182168960571e-01
    z[6,5,6]  R2450     -3.2140389084815979e-02
    z[6,5,6]  R2451     -1.0028751939535141e-01
    z[6,5,6]  R2452     9.1935552656650543e-02
    z[6,5,6]  R2453     9.6539907157421112e-02
    z[6,5,6]  R2454     1.2783069908618927e-01
    z[6,5,6]  R2455     -3.7338647991418839e-02
    z[6,5,6]  R2456     -2.3746129870414734e-01
    z[6,5,6]  R2457     -1.7043109983205795e-02
    z[6,5,6]  R2458     -1.3536711037158966e-01
    z[6,5,6]  R2459     -3.2050654292106628e-01
    z[6,5,6]  R2460     9.1828316450119019e-02
    z[6,5,6]  R2461     -2.7272889018058777e-01
    z[6,5,6]  R2462     4.3219694495201111e-01
    z[6,5,6]  R2463     -2.4073512852191925e-01
    z[6,5,6]  R2464     -1.2841922044754028e-01
    z[6,5,6]  R2465     1.9455133378505707e-01
    z[6,5,6]  R2466     -9.2191033065319061e-02
    z[6,5,6]  R2467     6.5413199365139008e-02
    z[6,5,6]  R2468     5.1288757473230362e-02
    z[6,5,6]  R2469     3.5724171996116638e-01
    z[6,5,6]  R2470     1.0929439961910248e-01
    z[6,5,6]  R2471     5.8313125371932983e-01
    z[6,5,6]  R2472     -1.7309702932834625e-02
    z[6,5,6]  R2473     -5.0625193119049072e-01
    z[6,5,6]  R2474     -1.2640132009983063e-01
    z[6,5,6]  R2475     8.3364490419626236e-03
    z[6,5,6]  R2476     -1.4134739339351654e-01
    z[6,5,6]  R2477     2.9050955176353455e-01
    z[6,5,6]  R2478     -3.0355167388916016e-01
    z[6,5,6]  R2479     -1.9361393153667450e-01
    z[6,5,6]  R2480     1.2838077545166016e-01
    z[6,5,6]  R2481     7.5807720422744751e-02
    z[6,5,6]  R2482     -4.8850125074386597e-01
    z[6,5,6]  R2483     -2.0394796133041382e-01
    z[6,5,6]  R2484     1.3101337850093842e-01
    z[6,5,6]  R2485     2.6964184641838074e-01
    z[6,5,6]  R2486     -2.0788739621639252e-01
    z[6,5,6]  R2487     -3.7755563855171204e-01
    z[6,5,6]  R2488     -2.4842904508113861e-01
    z[6,5,6]  R2489     1.4364540576934814e-01
    z[6,5,6]  R2490     1.6188396513462067e-01
    z[6,5,6]  R2491     -2.2402470931410789e-02
    z[6,5,6]  R2492     -1.9644704461097717e-01
    z[6,5,6]  R2493     9.3915618956089020e-02
    z[6,5,6]  R2494     0.454225093126297
    z[6,5,6]  R2495     8.5165657103061676e-02
    z[6,5,6]  R2496     4.3079477548599243e-01
    z[6,5,6]  R2497     3.4523203969001770e-01
    z[6,5,6]  R2498     1.4997215941548347e-02
    z[6,5,6]  R2499     -3.3137810230255127e-01
    z[6,5,6]  R2500     4.1690585017204285e-01
    z[6,5,6]  R2501     -2.6097485423088074e-01
    z[6,5,6]  R2502     -3.3129367977380753e-02
    z[6,5,6]  R2503     5.1669991016387939e-01
    z[6,5,6]  R2504     6.0928516089916229e-02
    z[6,5,6]  R2505     3.1819772720336914e-01
    z[6,5,6]  R2506     -3.2967534661293030e-01
    z[6,5,6]  R2507     -2.7402088046073914e-01
    z[6,5,6]  R2508     -1.2210775911808014e-01
    z[6,5,6]  R2509     -9.0648196637630463e-02
    z[6,5,6]  R2510     -3.0467414855957031e-01
    z[6,5,6]  R2511     -2.7823492884635925e-01
    z[6,5,6]  R2512     -3.6152851581573486e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2513     -1
    z[6,7,0]  R2514     1
    z[6,7,0]  R2527     -1.2808595784008503e-02
    z[6,7,0]  R2528     1.9614402204751968e-02
    z[6,7,0]  R2529     0.426605224609375
    z[6,7,0]  R2530     -3.6192893981933594e-01
    z[6,7,0]  R2531     1.8868026137351990e-01
    z[6,7,0]  R2532     5.9049296379089355e-01
    z[6,7,0]  R2533     -3.0709570273756981e-02
    z[6,7,0]  R2534     -4.2208233475685120e-01
    z[6,7,0]  R2535     3.7201613187789917e-01
    z[6,7,0]  R2536     -5.7482451200485229e-02
    z[6,7,0]  R2537     -1.5361925959587097e-01
    z[6,7,0]  R2538     -0.279266357421875
    z[6,7,0]  R2539     -3.1568318605422974e-01
    z[6,7,0]  R2540     6.2692761421203613e-01
    z[6,7,0]  R2541     -6.3902062177658081e-01
    z[6,7,0]  R2542     1.4368177950382233e-01
    z[6,7,0]  R2543     3.5535556077957153e-01
    z[6,7,0]  R2544     4.1406655311584473e-01
    z[6,7,0]  R2545     -2.4012443423271179e-01
    z[6,7,0]  R2546     7.6279568672180176e-01
    z[6,7,0]  R2547     4.7961592674255371e-01
    z[6,7,0]  R2548     3.2556268572807312e-01
    z[6,7,0]  R2549     5.9694701433181763e-01
    z[6,7,0]  R2550     5.6772679090499878e-01
    z[6,7,0]  R2551     5.7338184118270874e-01
    z[6,7,0]  R2552     -3.6375731229782104e-01
    z[6,7,0]  R2553     5.2672243118286133e-01
    z[6,7,0]  R2554     3.2841497659683228e-01
    z[6,7,0]  R2555     -5.5066294968128204e-02
    z[6,7,0]  R2556     -5.4952509701251984e-02
    z[6,7,0]  R2557     -1.3514424860477448e-01
    z[6,7,0]  R2558     -2.0544309914112091e-01
    z[6,7,0]  R2559     -3.3502045273780823e-01
    z[6,7,0]  R2560     3.9353778958320618e-01
    z[6,7,0]  R2561     -3.9055220782756805e-02
    z[6,7,0]  R2562     0.0508398562669754
    z[6,7,0]  R2563     7.3907065391540527e-01
    z[6,7,0]  R2564     4.8043563961982727e-01
    z[6,7,0]  R2565     -8.2265603542327881e-01
    z[6,7,0]  R2566     -8.5410159826278687e-01
    z[6,7,0]  R2567     -7.0194125175476074e-01
    z[6,7,0]  R2568     -7.8165721893310547e-01
    z[6,7,0]  R2569     -9.0683442354202271e-01
    z[6,7,0]  R2570     -1.5419508516788483e-01
    z[6,7,0]  R2571     0.0777321606874466
    z[6,7,0]  R2572     4.1521093249320984e-01
    z[6,7,0]  R2573     3.1091028451919556e-01
    z[6,7,0]  R2574     2.6029297709465027e-01
    z[6,7,0]  R2575     1.7411856353282928e-01
    z[6,7,0]  R2576     2.8291067481040955e-01
    z[6,7,0]  R2577     2.3529216647148132e-01
    z[6,7,0]  R2578     5.3404539823532104e-02
    z[6,7,0]  R2579     4.6603572368621826e-01
    z[6,7,0]  R2580     0.563897967338562
    z[6,7,0]  R2581     3.7199625372886658e-01
    z[6,7,0]  R2582     3.0794638395309448e-01
    z[6,7,0]  R2583     2.9737782478332520e-01
    z[6,7,0]  R2584     6.5450179576873779e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2515     -1
    z[6,7,1]  R2516     1
    z[6,7,1]  R2527     -8.5665351152420044e-01
    z[6,7,1]  R2528     -7.6960867643356323e-01
    z[6,7,1]  R2529     -7.1765071153640747e-01
    z[6,7,1]  R2530     -0.614878237247467
    z[6,7,1]  R2531     1.6149619221687317e-01
    z[6,7,1]  R2532     -4.9843534827232361e-01
    z[6,7,1]  R2533     -5.1870477199554443e-01
    z[6,7,1]  R2534     -0.48763307929039
    z[6,7,1]  R2535     3.6125433444976807e-01
    z[6,7,1]  R2536     -3.9068728685379028e-01
    z[6,7,1]  R2537     0.531035304069519
    z[6,7,1]  R2538     4.2480081319808960e-01
    z[6,7,1]  R2539     5.0707006454467773e-01
    z[6,7,1]  R2540     -5.2635347843170166e-01
    z[6,7,1]  R2541     2.8780847787857056e-01
    z[6,7,1]  R2542     -0.422394722700119
    z[6,7,1]  R2543     -2.8031843900680542e-01
    z[6,7,1]  R2544     -5.1171295344829559e-02
    z[6,7,1]  R2545     0.348254531621933
    z[6,7,1]  R2546     -4.5135945081710815e-01
    z[6,7,1]  R2547     -4.7845938801765442e-01
    z[6,7,1]  R2548     -0.479305237531662
    z[6,7,1]  R2549     -3.3661171793937683e-01
    z[6,7,1]  R2550     -5.0828850269317627e-01
    z[6,7,1]  R2551     -3.8467141985893250e-01
    z[6,7,1]  R2552     -1.2730935215950012e-01
    z[6,7,1]  R2553     -3.6874574422836304e-01
    z[6,7,1]  R2554     -3.7385082244873047e-01
    z[6,7,1]  R2555     -0.743045449256897
    z[6,7,1]  R2556     -7.4928855895996094e-01
    z[6,7,1]  R2557     -7.2837853431701660e-01
    z[6,7,1]  R2558     -7.0721590518951416e-01
    z[6,7,1]  R2559     -7.0768111944198608e-01
    z[6,7,1]  R2560     -6.8114686012268066e-01
    z[6,7,1]  R2561     -6.6867059469223022e-01
    z[6,7,1]  R2562     -5.9756278991699219e-01
    z[6,7,1]  R2563     -5.9231704473495483e-01
    z[6,7,1]  R2564     -5.1949393749237061e-01
    z[6,7,1]  R2565     1.4352588355541229e-01
    z[6,7,1]  R2566     1.7586836218833923e-01
    z[6,7,1]  R2567     4.2263475060462952e-01
    z[6,7,1]  R2568     2.6250369846820831e-02
    z[6,7,1]  R2569     -1.4274181798100471e-02
    z[6,7,1]  R2570     3.5868328809738159e-01
    z[6,7,1]  R2571     8.4278291463851929e-01
    z[6,7,1]  R2572     6.1004316806793213e-01
    z[6,7,1]  R2573     6.5526819229125977e-01
    z[6,7,1]  R2574     6.4741140604019165e-01
    z[6,7,1]  R2575     0.793921172618866
    z[6,7,1]  R2576     6.9187086820602417e-01
    z[6,7,1]  R2577     7.2983145713806152e-01
    z[6,7,1]  R2578     7.1048659086227417e-01
    z[6,7,1]  R2579     7.0828109979629517e-01
    z[6,7,1]  R2580     6.3068258762359619e-01
    z[6,7,1]  R2581     7.3375660181045532e-01
    z[6,7,1]  R2582     6.5386146306991577e-01
    z[6,7,1]  R2583     6.2505561113357544e-01
    z[6,7,1]  R2584     2.6948049664497375e-01
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2517     -1
    z[6,7,2]  R2518     1
    z[6,7,2]  R2527     9.4488039612770081e-02
    z[6,7,2]  R2528     8.1025578081607819e-02
    z[6,7,2]  R2529     -1.2611103057861328e-01
    z[6,7,2]  R2530     -1.7394740879535675e-01
    z[6,7,2]  R2531     6.0527596622705460e-02
    z[6,7,2]  R2532     -1.6110622882843018e-01
    z[6,7,2]  R2533     -4.9716871976852417e-01
    z[6,7,2]  R2534     -2.5580269098281860e-01
    z[6,7,2]  R2535     6.2039190530776978e-01
    z[6,7,2]  R2536     -1.3901941478252411e-01
    z[6,7,2]  R2537     -2.2000320255756378e-01
    z[6,7,2]  R2538     -4.5445561408996582e-01
    z[6,7,2]  R2539     0.338427871465683
    z[6,7,2]  R2540     2.2712418437004089e-01
    z[6,7,2]  R2541     -1.2703558802604675e-01
    z[6,7,2]  R2542     -3.8430088758468628e-01
    z[6,7,2]  R2543     -5.2579361200332642e-01
    z[6,7,2]  R2544     -4.1893506050109863e-01
    z[6,7,2]  R2545     -0.291093111038208
    z[6,7,2]  R2546     7.7318707481026649e-03
    z[6,7,2]  R2547     -3.1196326017379761e-01
    z[6,7,2]  R2548     -4.1107237339019775e-02
    z[6,7,2]  R2549     -6.4293992519378662e-01
    z[6,7,2]  R2550     -1.1912114173173904e-01
    z[6,7,2]  R2551     -3.8850709795951843e-01
    z[6,7,2]  R2552     1.3469946384429932e-01
    z[6,7,2]  R2553     -5.2824616432189941e-01
    z[6,7,2]  R2554     1.5535375475883484e-01
    z[6,7,2]  R2555     -0.0832938700914383
    z[6,7,2]  R2556     7.8313037753105164e-02
    z[6,7,2]  R2557     1.8474750220775604e-01
    z[6,7,2]  R2558     1.7942178249359131e-01
    z[6,7,2]  R2559     -1.0637225210666656e-01
    z[6,7,2]  R2560     -4.5578071475028992e-01
    z[6,7,2]  R2561     1.4830625057220459e-01
    z[6,7,2]  R2562     -1.3196821324527264e-02
    z[6,7,2]  R2563     1.0675847530364990e-01
    z[6,7,2]  R2564     -2.0281404256820679e-02
    z[6,7,2]  R2565     -3.2566487789154053e-01
    z[6,7,2]  R2566     -0.0940450057387352
    z[6,7,2]  R2567     -4.0577489882707596e-02
    z[6,7,2]  R2568     -4.8938649892807007e-01
    z[6,7,2]  R2569     -7.5737267732620239e-02
    z[6,7,2]  R2570     -4.7218307852745056e-01
    z[6,7,2]  R2571     2.2482825815677643e-01
    z[6,7,2]  R2572     4.6637746691703796e-01
    z[6,7,2]  R2573     5.5652713775634766e-01
    z[6,7,2]  R2574     4.3382686376571655e-01
    z[6,7,2]  R2575     5.7313352823257446e-01
    z[6,7,2]  R2576     -3.0905985832214355e-01
    z[6,7,2]  R2577     -0.466251939535141
    z[6,7,2]  R2578     -8.3113173022866249e-03
    z[6,7,2]  R2579     1.0023440234363079e-02
    z[6,7,2]  R2580     0.0632082000374794
    z[6,7,2]  R2581     -2.7546146512031555e-01
    z[6,7,2]  R2582     -6.0453660786151886e-02
    z[6,7,2]  R2583     0.0542115643620491
    z[6,7,2]  R2584     1.9810880720615387e-01
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2519     -1
    z[6,7,3]  R2520     1
    z[6,7,3]  R2527     -2.4991051852703094e-01
    z[6,7,3]  R2528     -4.9090600013732910e-01
    z[6,7,3]  R2529     6.1710983514785767e-02
    z[6,7,3]  R2530     5.2725905179977417e-01
    z[6,7,3]  R2531     -9.0583063662052155e-02
    z[6,7,3]  R2532     5.6679673492908478e-02
    z[6,7,3]  R2533     -8.3638131618499756e-02
    z[6,7,3]  R2534     -7.5017638504505157e-02
    z[6,7,3]  R2535     -0.505151629447937
    z[6,7,3]  R2536     4.1810753941535950e-01
    z[6,7,3]  R2537     3.8386559486389160e-01
    z[6,7,3]  R2538     1.2411752343177795e-01
    z[6,7,3]  R2539     7.2582387924194336e-01
    z[6,7,3]  R2540     3.2066649198532104e-01
    z[6,7,3]  R2541     -5.2132230997085571e-01
    z[6,7,3]  R2542     3.6223033070564270e-01
    z[6,7,3]  R2543     -1.4278753101825714e-01
    z[6,7,3]  R2544     -3.9068478345870972e-01
    z[6,7,3]  R2545     -8.4565865993499756e-01
    z[6,7,3]  R2546     2.4282032251358032e-01
    z[6,7,3]  R2547     5.5883687734603882e-01
    z[6,7,3]  R2548     2.3872801661491394e-01
    z[6,7,3]  R2549     1.3471964001655579e-01
    z[6,7,3]  R2550     -4.1854333877563477e-01
    z[6,7,3]  R2551     -3.5155874490737915e-01
    z[6,7,3]  R2552     -1.6112793982028961e-01
    z[6,7,3]  R2553     -2.5874251127243042e-01
    z[6,7,3]  R2554     4.1502866148948669e-01
    z[6,7,3]  R2555     -5.3115785121917725e-01
    z[6,7,3]  R2556     -0.517676055431366
    z[6,7,3]  R2557     -4.5510104298591614e-01
    z[6,7,3]  R2558     1.4501862227916718e-01
    z[6,7,3]  R2559     5.4367440938949585e-01
    z[6,7,3]  R2560     -1.2788806855678558e-01
    z[6,7,3]  R2561     -2.4055039882659912e-01
    z[6,7,3]  R2562     -2.2824862599372864e-01
    z[6,7,3]  R2563     -2.6141172274947166e-02
    z[6,7,3]  R2564     0.362593412399292
    z[6,7,3]  R2565     -3.7873315811157227e-01
    z[6,7,3]  R2566     -3.8320377469062805e-01
    z[6,7,3]  R2567     -3.0686238408088684e-01
    z[6,7,3]  R2568     -1.0967943817377090e-02
    z[6,7,3]  R2569     8.8958166539669037e-02
    z[6,7,3]  R2570     -7.3784607648849487e-01
    z[6,7,3]  R2571     -1.4718878269195557e-01
    z[6,7,3]  R2572     -2.7771508693695068e-01
    z[6,7,3]  R2573     -3.1631910800933838e-01
    z[6,7,3]  R2574     -9.4376482069492340e-02
    z[6,7,3]  R2575     -2.9263095930218697e-03
    z[6,7,3]  R2576     2.9952365159988403e-01
    z[6,7,3]  R2577     3.1823712587356567e-01
    z[6,7,3]  R2578     5.2354931831359863e-01
    z[6,7,3]  R2579     -2.7067307382822037e-02
    z[6,7,3]  R2580     2.8740158677101135e-01
    z[6,7,3]  R2581     3.9176261425018311e-01
    z[6,7,3]  R2582     1.5172840654850006e-01
    z[6,7,3]  R2583     1.9516982138156891e-01
    z[6,7,3]  R2584     4.9416700005531311e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2521     -1
    z[6,7,4]  R2522     1
    z[6,7,4]  R2527     3.3453932404518127e-01
    z[6,7,4]  R2528     3.4996751695871353e-02
    z[6,7,4]  R2529     -2.2012539207935333e-01
    z[6,7,4]  R2530     0.0924614816904068
    z[6,7,4]  R2531     -5.1727288961410522e-01
    z[6,7,4]  R2532     -5.6982642412185669e-01
    z[6,7,4]  R2533     -6.3058042526245117e-01
    z[6,7,4]  R2534     -0.63797527551651
    z[6,7,4]  R2535     6.4029365777969360e-02
    z[6,7,4]  R2536     -4.0712919831275940e-01
    z[6,7,4]  R2537     -2.3536796867847443e-01
    z[6,7,4]  R2538     -2.5398181751370430e-02
    z[6,7,4]  R2539     1.9153960049152374e-02
    z[6,7,4]  R2540     3.9977955818176270e-01
    z[6,7,4]  R2541     3.3283424377441406e-01
    z[6,7,4]  R2542     5.4633373022079468e-01
    z[6,7,4]  R2543     6.9716709852218628e-01
    z[6,7,4]  R2544     0.662807047367096
    z[6,7,4]  R2545     -1.0015836358070374e-01
    z[6,7,4]  R2546     3.7013238668441772e-01
    z[6,7,4]  R2547     3.5940846800804138e-01
    z[6,7,4]  R2548     3.0568319559097290e-01
    z[6,7,4]  R2549     2.8309425711631775e-01
    z[6,7,4]  R2550     4.1968545317649841e-01
    z[6,7,4]  R2551     3.2576340436935425e-01
    z[6,7,4]  R2552     6.6773736476898193e-01
    z[6,7,4]  R2553     4.0545329451560974e-01
    z[6,7,4]  R2554     2.2538343071937561e-01
    z[6,7,4]  R2555     2.0416952669620514e-01
    z[6,7,4]  R2556     3.3035805821418762e-01
    z[6,7,4]  R2557     -1.7304044961929321e-01
    z[6,7,4]  R2558     4.3810001015663147e-01
    z[6,7,4]  R2559     -2.5421399623155594e-02
    z[6,7,4]  R2560     2.4416697025299072e-01
    z[6,7,4]  R2561     -6.8618965148925781e-01
    z[6,7,4]  R2562     -1.9128118455410004e-01
    z[6,7,4]  R2563     1.0645785182714462e-01
    z[6,7,4]  R2564     1.9151549041271210e-01
    z[6,7,4]  R2565     -9.5341891050338745e-02
    z[6,7,4]  R2566     -2.3639196529984474e-02
    z[6,7,4]  R2567     -2.1149487793445587e-01
    z[6,7,4]  R2568     5.1366519182920456e-02
    z[6,7,4]  R2569     -7.3919579386711121e-02
    z[6,7,4]  R2570     8.4743246436119080e-02
    z[6,7,4]  R2571     -1.3100887835025787e-01
    z[6,7,4]  R2572     -3.0006036162376404e-01
    z[6,7,4]  R2573     5.8689940720796585e-02
    z[6,7,4]  R2574     1.6048046946525574e-01
    z[6,7,4]  R2575     -3.9442688226699829e-02
    z[6,7,4]  R2576     3.7176007032394409e-01
    z[6,7,4]  R2577     2.0438171923160553e-01
    z[6,7,4]  R2578     4.1999229788780212e-01
    z[6,7,4]  R2579     4.3914774060249329e-01
    z[6,7,4]  R2580     3.6389192938804626e-01
    z[6,7,4]  R2581     1.3818424940109253e-01
    z[6,7,4]  R2582     0.651690661907196
    z[6,7,4]  R2583     2.8211387991905212e-01
    z[6,7,4]  R2584     -1.8998704850673676e-01
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2523     -1
    z[6,7,5]  R2524     1
    z[6,7,5]  R2527     -2.8739389777183533e-01
    z[6,7,5]  R2528     1.8173862993717194e-01
    z[6,7,5]  R2529     -4.7996816039085388e-01
    z[6,7,5]  R2530     -4.1274634003639221e-01
    z[6,7,5]  R2531     -5.5949634313583374e-01
    z[6,7,5]  R2532     2.1661236882209778e-01
    z[6,7,5]  R2533     2.6686948537826538e-01
    z[6,7,5]  R2534     -1.4320363104343414e-01
    z[6,7,5]  R2535     -2.2835098206996918e-01
    z[6,7,5]  R2536     -1.3993540406227112e-01
    z[6,7,5]  R2537     2.7319532632827759e-01
    z[6,7,5]  R2538     -1.7754796147346497e-01
    z[6,7,5]  R2539     -3.8767889142036438e-02
    z[6,7,5]  R2540     8.5950538516044617e-02
    z[6,7,5]  R2541     -1.6209097206592560e-01
    z[6,7,5]  R2542     4.7172746062278748e-01
    z[6,7,5]  R2543     4.6875979751348495e-02
    z[6,7,5]  R2544     2.2366017103195190e-01
    z[6,7,5]  R2545     -0.0428200364112854
    z[6,7,5]  R2546     -4.5355938374996185e-02
    z[6,7,5]  R2547     -2.9270714148879051e-02
    z[6,7,5]  R2548     6.7510330677032471e-01
    z[6,7,5]  R2549     -1.3562041521072388e-01
    z[6,7,5]  R2550     1.8841637670993805e-01
    z[6,7,5]  R2551     -1.9970889389514923e-01
    z[6,7,5]  R2552     -5.9418958425521851e-01
    z[6,7,5]  R2553     4.2719464749097824e-02
    z[6,7,5]  R2554     5.6427270174026489e-01
    z[6,7,5]  R2555     3.3638903498649597e-01
    z[6,7,5]  R2556     -1.9399334490299225e-01
    z[6,7,5]  R2557     6.7884378135204315e-02
    z[6,7,5]  R2558     4.1109851002693176e-01
    z[6,7,5]  R2559     -2.6039877533912659e-01
    z[6,7,5]  R2560     -0.304644912481308
    z[6,7,5]  R2561     -1.0937741026282310e-02
    z[6,7,5]  R2562     -7.4050599336624146e-01
    z[6,7,5]  R2563     -2.4446092545986176e-01
    z[6,7,5]  R2564     1.9868181645870209e-01
    z[6,7,5]  R2565     1.9656149670481682e-02
    z[6,7,5]  R2566     -2.7998128533363342e-01
    z[6,7,5]  R2567     2.9966005682945251e-01
    z[6,7,5]  R2568     3.5412353277206421e-01
    z[6,7,5]  R2569     0.386221319437027
    z[6,7,5]  R2570     -4.7760433517396450e-03
    z[6,7,5]  R2571     -2.2735865414142609e-01
    z[6,7,5]  R2572     2.6579296588897705e-01
    z[6,7,5]  R2573     2.4337849020957947e-01
    z[6,7,5]  R2574     4.2711076140403748e-01
    z[6,7,5]  R2575     -9.5728859305381775e-02
    z[6,7,5]  R2576     3.1036314368247986e-01
    z[6,7,5]  R2577     2.1151506900787354e-01
    z[6,7,5]  R2578     1.7396314442157745e-01
    z[6,7,5]  R2579     1.3783389329910278e-01
    z[6,7,5]  R2580     1.6777409613132477e-01
    z[6,7,5]  R2581     -0.27127605676651
    z[6,7,5]  R2582     -1.8786061555147171e-02
    z[6,7,5]  R2583     -1.1283921450376511e-01
    z[6,7,5]  R2584     -1.6121678054332733e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2525     -1
    z[6,7,6]  R2526     1
    z[6,7,6]  R2527     -9.2577878385782242e-03
    z[6,7,6]  R2528     3.5427427291870117e-01
    z[6,7,6]  R2529     -6.6698074340820312e-02
    z[6,7,6]  R2530     6.1350151896476746e-02
    z[6,7,6]  R2531     5.8808368444442749e-01
    z[6,7,6]  R2532     0.0457102470099926
    z[6,7,6]  R2533     8.3541408181190491e-02
    z[6,7,6]  R2534     2.9236632585525513e-01
    z[6,7,6]  R2535     -1.8652334809303284e-01
    z[6,7,6]  R2536     6.8160313367843628e-01
    z[6,7,6]  R2537     -6.0713642835617065e-01
    z[6,7,6]  R2538     -6.9817709922790527e-01
    z[6,7,6]  R2539     -5.8500305749475956e-04
    z[6,7,6]  R2540     -9.1050438582897186e-02
    z[6,7,6]  R2541     2.8957182168960571e-01
    z[6,7,6]  R2542     -3.2140389084815979e-02
    z[6,7,6]  R2543     -1.0028751939535141e-01
    z[6,7,6]  R2544     9.1935552656650543e-02
    z[6,7,6]  R2545     9.6539907157421112e-02
    z[6,7,6]  R2546     1.2783069908618927e-01
    z[6,7,6]  R2547     -3.7338647991418839e-02
    z[6,7,6]  R2548     -2.3746129870414734e-01
    z[6,7,6]  R2549     -1.7043109983205795e-02
    z[6,7,6]  R2550     -1.3536711037158966e-01
    z[6,7,6]  R2551     -3.2050654292106628e-01
    z[6,7,6]  R2552     9.1828316450119019e-02
    z[6,7,6]  R2553     -2.7272889018058777e-01
    z[6,7,6]  R2554     4.3219694495201111e-01
    z[6,7,6]  R2555     -3.0690962448716164e-02
    z[6,7,6]  R2556     -1.2106040120124817e-01
    z[6,7,6]  R2557     4.1880896687507629e-01
    z[6,7,6]  R2558     2.0852467417716980e-01
    z[6,7,6]  R2559     -1.0769448429346085e-01
    z[6,7,6]  R2560     -6.8187125027179718e-02
    z[6,7,6]  R2561     -2.2787373512983322e-02
    z[6,7,6]  R2562     -5.5900763720273972e-02
    z[6,7,6]  R2563     1.4057008922100067e-01
    z[6,7,6]  R2564     5.3969401121139526e-01
    z[6,7,6]  R2565     2.0896056294441223e-01
    z[6,7,6]  R2566     0.0703059658408165
    z[6,7,6]  R2567     -3.1356176733970642e-01
    z[6,7,6]  R2568     -1.4374145865440369e-01
    z[6,7,6]  R2569     9.5743931829929352e-02
    z[6,7,6]  R2570     -2.7017101645469666e-01
    z[6,7,6]  R2571     0.377633661031723
    z[6,7,6]  R2572     1.1471087113022804e-02
    z[6,7,6]  R2573     -3.8736443966627121e-02
    z[6,7,6]  R2574     3.2835307717323303e-01
    z[6,7,6]  R2575     1.2709383852779865e-02
    z[6,7,6]  R2576     -1.4667297899723053e-01
    z[6,7,6]  R2577     8.2507297396659851e-02
    z[6,7,6]  R2578     1.0736383497714996e-01
    z[6,7,6]  R2579     -2.6166132092475891e-01
    z[6,7,6]  R2580     -1.9260872900485992e-01
    z[6,7,6]  R2581     -3.4314379096031189e-02
    z[6,7,6]  R2582     1.6094848513603210e-01
    z[6,7,6]  R2583     -6.2251168489456177e-01
    z[6,7,6]  R2584     -3.9175704121589661e-01
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2585     -1
    z[7,6,0]  R2586     1
    z[7,6,0]  R2599     -5.5066294968128204e-02
    z[7,6,0]  R2600     -5.4952509701251984e-02
    z[7,6,0]  R2601     -1.3514424860477448e-01
    z[7,6,0]  R2602     -2.0544309914112091e-01
    z[7,6,0]  R2603     -3.3502045273780823e-01
    z[7,6,0]  R2604     3.9353778958320618e-01
    z[7,6,0]  R2605     -3.9055220782756805e-02
    z[7,6,0]  R2606     0.0508398562669754
    z[7,6,0]  R2607     7.3907065391540527e-01
    z[7,6,0]  R2608     4.8043563961982727e-01
    z[7,6,0]  R2609     -8.2265603542327881e-01
    z[7,6,0]  R2610     -8.5410159826278687e-01
    z[7,6,0]  R2611     -7.0194125175476074e-01
    z[7,6,0]  R2612     -7.8165721893310547e-01
    z[7,6,0]  R2613     -9.0683442354202271e-01
    z[7,6,0]  R2614     -1.5419508516788483e-01
    z[7,6,0]  R2615     0.0777321606874466
    z[7,6,0]  R2616     4.1521093249320984e-01
    z[7,6,0]  R2617     3.1091028451919556e-01
    z[7,6,0]  R2618     2.6029297709465027e-01
    z[7,6,0]  R2619     1.7411856353282928e-01
    z[7,6,0]  R2620     2.8291067481040955e-01
    z[7,6,0]  R2621     2.3529216647148132e-01
    z[7,6,0]  R2622     5.3404539823532104e-02
    z[7,6,0]  R2623     4.6603572368621826e-01
    z[7,6,0]  R2624     0.563897967338562
    z[7,6,0]  R2625     3.7199625372886658e-01
    z[7,6,0]  R2626     3.0794638395309448e-01
    z[7,6,0]  R2627     2.9737782478332520e-01
    z[7,6,0]  R2628     6.5450179576873779e-01
    z[7,6,0]  R2629     -1.2808595784008503e-02
    z[7,6,0]  R2630     1.9614402204751968e-02
    z[7,6,0]  R2631     0.426605224609375
    z[7,6,0]  R2632     -3.6192893981933594e-01
    z[7,6,0]  R2633     1.8868026137351990e-01
    z[7,6,0]  R2634     5.9049296379089355e-01
    z[7,6,0]  R2635     -3.0709570273756981e-02
    z[7,6,0]  R2636     -4.2208233475685120e-01
    z[7,6,0]  R2637     3.7201613187789917e-01
    z[7,6,0]  R2638     -5.7482451200485229e-02
    z[7,6,0]  R2639     -1.5361925959587097e-01
    z[7,6,0]  R2640     -0.279266357421875
    z[7,6,0]  R2641     -3.1568318605422974e-01
    z[7,6,0]  R2642     6.2692761421203613e-01
    z[7,6,0]  R2643     -6.3902062177658081e-01
    z[7,6,0]  R2644     1.4368177950382233e-01
    z[7,6,0]  R2645     3.5535556077957153e-01
    z[7,6,0]  R2646     4.1406655311584473e-01
    z[7,6,0]  R2647     -2.4012443423271179e-01
    z[7,6,0]  R2648     7.6279568672180176e-01
    z[7,6,0]  R2649     4.7961592674255371e-01
    z[7,6,0]  R2650     3.2556268572807312e-01
    z[7,6,0]  R2651     5.9694701433181763e-01
    z[7,6,0]  R2652     5.6772679090499878e-01
    z[7,6,0]  R2653     5.7338184118270874e-01
    z[7,6,0]  R2654     -3.6375731229782104e-01
    z[7,6,0]  R2655     5.2672243118286133e-01
    z[7,6,0]  R2656     3.2841497659683228e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2587     -1
    z[7,6,1]  R2588     1
    z[7,6,1]  R2599     -0.743045449256897
    z[7,6,1]  R2600     -7.4928855895996094e-01
    z[7,6,1]  R2601     -7.2837853431701660e-01
    z[7,6,1]  R2602     -7.0721590518951416e-01
    z[7,6,1]  R2603     -7.0768111944198608e-01
    z[7,6,1]  R2604     -6.8114686012268066e-01
    z[7,6,1]  R2605     -6.6867059469223022e-01
    z[7,6,1]  R2606     -5.9756278991699219e-01
    z[7,6,1]  R2607     -5.9231704473495483e-01
    z[7,6,1]  R2608     -5.1949393749237061e-01
    z[7,6,1]  R2609     1.4352588355541229e-01
    z[7,6,1]  R2610     1.7586836218833923e-01
    z[7,6,1]  R2611     4.2263475060462952e-01
    z[7,6,1]  R2612     2.6250369846820831e-02
    z[7,6,1]  R2613     -1.4274181798100471e-02
    z[7,6,1]  R2614     3.5868328809738159e-01
    z[7,6,1]  R2615     8.4278291463851929e-01
    z[7,6,1]  R2616     6.1004316806793213e-01
    z[7,6,1]  R2617     6.5526819229125977e-01
    z[7,6,1]  R2618     6.4741140604019165e-01
    z[7,6,1]  R2619     0.793921172618866
    z[7,6,1]  R2620     6.9187086820602417e-01
    z[7,6,1]  R2621     7.2983145713806152e-01
    z[7,6,1]  R2622     7.1048659086227417e-01
    z[7,6,1]  R2623     7.0828109979629517e-01
    z[7,6,1]  R2624     6.3068258762359619e-01
    z[7,6,1]  R2625     7.3375660181045532e-01
    z[7,6,1]  R2626     6.5386146306991577e-01
    z[7,6,1]  R2627     6.2505561113357544e-01
    z[7,6,1]  R2628     2.6948049664497375e-01
    z[7,6,1]  R2629     -8.5665351152420044e-01
    z[7,6,1]  R2630     -7.6960867643356323e-01
    z[7,6,1]  R2631     -7.1765071153640747e-01
    z[7,6,1]  R2632     -0.614878237247467
    z[7,6,1]  R2633     1.6149619221687317e-01
    z[7,6,1]  R2634     -4.9843534827232361e-01
    z[7,6,1]  R2635     -5.1870477199554443e-01
    z[7,6,1]  R2636     -0.48763307929039
    z[7,6,1]  R2637     3.6125433444976807e-01
    z[7,6,1]  R2638     -3.9068728685379028e-01
    z[7,6,1]  R2639     0.531035304069519
    z[7,6,1]  R2640     4.2480081319808960e-01
    z[7,6,1]  R2641     5.0707006454467773e-01
    z[7,6,1]  R2642     -5.2635347843170166e-01
    z[7,6,1]  R2643     2.8780847787857056e-01
    z[7,6,1]  R2644     -0.422394722700119
    z[7,6,1]  R2645     -2.8031843900680542e-01
    z[7,6,1]  R2646     -5.1171295344829559e-02
    z[7,6,1]  R2647     0.348254531621933
    z[7,6,1]  R2648     -4.5135945081710815e-01
    z[7,6,1]  R2649     -4.7845938801765442e-01
    z[7,6,1]  R2650     -0.479305237531662
    z[7,6,1]  R2651     -3.3661171793937683e-01
    z[7,6,1]  R2652     -5.0828850269317627e-01
    z[7,6,1]  R2653     -3.8467141985893250e-01
    z[7,6,1]  R2654     -1.2730935215950012e-01
    z[7,6,1]  R2655     -3.6874574422836304e-01
    z[7,6,1]  R2656     -3.7385082244873047e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2589     -1
    z[7,6,2]  R2590     1
    z[7,6,2]  R2599     -0.0832938700914383
    z[7,6,2]  R2600     7.8313037753105164e-02
    z[7,6,2]  R2601     1.8474750220775604e-01
    z[7,6,2]  R2602     1.7942178249359131e-01
    z[7,6,2]  R2603     -1.0637225210666656e-01
    z[7,6,2]  R2604     -4.5578071475028992e-01
    z[7,6,2]  R2605     1.4830625057220459e-01
    z[7,6,2]  R2606     -1.3196821324527264e-02
    z[7,6,2]  R2607     1.0675847530364990e-01
    z[7,6,2]  R2608     -2.0281404256820679e-02
    z[7,6,2]  R2609     -3.2566487789154053e-01
    z[7,6,2]  R2610     -0.0940450057387352
    z[7,6,2]  R2611     -4.0577489882707596e-02
    z[7,6,2]  R2612     -4.8938649892807007e-01
    z[7,6,2]  R2613     -7.5737267732620239e-02
    z[7,6,2]  R2614     -4.7218307852745056e-01
    z[7,6,2]  R2615     2.2482825815677643e-01
    z[7,6,2]  R2616     4.6637746691703796e-01
    z[7,6,2]  R2617     5.5652713775634766e-01
    z[7,6,2]  R2618     4.3382686376571655e-01
    z[7,6,2]  R2619     5.7313352823257446e-01
    z[7,6,2]  R2620     -3.0905985832214355e-01
    z[7,6,2]  R2621     -0.466251939535141
    z[7,6,2]  R2622     -8.3113173022866249e-03
    z[7,6,2]  R2623     1.0023440234363079e-02
    z[7,6,2]  R2624     0.0632082000374794
    z[7,6,2]  R2625     -2.7546146512031555e-01
    z[7,6,2]  R2626     -6.0453660786151886e-02
    z[7,6,2]  R2627     0.0542115643620491
    z[7,6,2]  R2628     1.9810880720615387e-01
    z[7,6,2]  R2629     9.4488039612770081e-02
    z[7,6,2]  R2630     8.1025578081607819e-02
    z[7,6,2]  R2631     -1.2611103057861328e-01
    z[7,6,2]  R2632     -1.7394740879535675e-01
    z[7,6,2]  R2633     6.0527596622705460e-02
    z[7,6,2]  R2634     -1.6110622882843018e-01
    z[7,6,2]  R2635     -4.9716871976852417e-01
    z[7,6,2]  R2636     -2.5580269098281860e-01
    z[7,6,2]  R2637     6.2039190530776978e-01
    z[7,6,2]  R2638     -1.3901941478252411e-01
    z[7,6,2]  R2639     -2.2000320255756378e-01
    z[7,6,2]  R2640     -4.5445561408996582e-01
    z[7,6,2]  R2641     0.338427871465683
    z[7,6,2]  R2642     2.2712418437004089e-01
    z[7,6,2]  R2643     -1.2703558802604675e-01
    z[7,6,2]  R2644     -3.8430088758468628e-01
    z[7,6,2]  R2645     -5.2579361200332642e-01
    z[7,6,2]  R2646     -4.1893506050109863e-01
    z[7,6,2]  R2647     -0.291093111038208
    z[7,6,2]  R2648     7.7318707481026649e-03
    z[7,6,2]  R2649     -3.1196326017379761e-01
    z[7,6,2]  R2650     -4.1107237339019775e-02
    z[7,6,2]  R2651     -6.4293992519378662e-01
    z[7,6,2]  R2652     -1.1912114173173904e-01
    z[7,6,2]  R2653     -3.8850709795951843e-01
    z[7,6,2]  R2654     1.3469946384429932e-01
    z[7,6,2]  R2655     -5.2824616432189941e-01
    z[7,6,2]  R2656     1.5535375475883484e-01
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2591     -1
    z[7,6,3]  R2592     1
    z[7,6,3]  R2599     -5.3115785121917725e-01
    z[7,6,3]  R2600     -0.517676055431366
    z[7,6,3]  R2601     -4.5510104298591614e-01
    z[7,6,3]  R2602     1.4501862227916718e-01
    z[7,6,3]  R2603     5.4367440938949585e-01
    z[7,6,3]  R2604     -1.2788806855678558e-01
    z[7,6,3]  R2605     -2.4055039882659912e-01
    z[7,6,3]  R2606     -2.2824862599372864e-01
    z[7,6,3]  R2607     -2.6141172274947166e-02
    z[7,6,3]  R2608     0.362593412399292
    z[7,6,3]  R2609     -3.7873315811157227e-01
    z[7,6,3]  R2610     -3.8320377469062805e-01
    z[7,6,3]  R2611     -3.0686238408088684e-01
    z[7,6,3]  R2612     -1.0967943817377090e-02
    z[7,6,3]  R2613     8.8958166539669037e-02
    z[7,6,3]  R2614     -7.3784607648849487e-01
    z[7,6,3]  R2615     -1.4718878269195557e-01
    z[7,6,3]  R2616     -2.7771508693695068e-01
    z[7,6,3]  R2617     -3.1631910800933838e-01
    z[7,6,3]  R2618     -9.4376482069492340e-02
    z[7,6,3]  R2619     -2.9263095930218697e-03
    z[7,6,3]  R2620     2.9952365159988403e-01
    z[7,6,3]  R2621     3.1823712587356567e-01
    z[7,6,3]  R2622     5.2354931831359863e-01
    z[7,6,3]  R2623     -2.7067307382822037e-02
    z[7,6,3]  R2624     2.8740158677101135e-01
    z[7,6,3]  R2625     3.9176261425018311e-01
    z[7,6,3]  R2626     1.5172840654850006e-01
    z[7,6,3]  R2627     1.9516982138156891e-01
    z[7,6,3]  R2628     4.9416700005531311e-01
    z[7,6,3]  R2629     -2.4991051852703094e-01
    z[7,6,3]  R2630     -4.9090600013732910e-01
    z[7,6,3]  R2631     6.1710983514785767e-02
    z[7,6,3]  R2632     5.2725905179977417e-01
    z[7,6,3]  R2633     -9.0583063662052155e-02
    z[7,6,3]  R2634     5.6679673492908478e-02
    z[7,6,3]  R2635     -8.3638131618499756e-02
    z[7,6,3]  R2636     -7.5017638504505157e-02
    z[7,6,3]  R2637     -0.505151629447937
    z[7,6,3]  R2638     4.1810753941535950e-01
    z[7,6,3]  R2639     3.8386559486389160e-01
    z[7,6,3]  R2640     1.2411752343177795e-01
    z[7,6,3]  R2641     7.2582387924194336e-01
    z[7,6,3]  R2642     3.2066649198532104e-01
    z[7,6,3]  R2643     -5.2132230997085571e-01
    z[7,6,3]  R2644     3.6223033070564270e-01
    z[7,6,3]  R2645     -1.4278753101825714e-01
    z[7,6,3]  R2646     -3.9068478345870972e-01
    z[7,6,3]  R2647     -8.4565865993499756e-01
    z[7,6,3]  R2648     2.4282032251358032e-01
    z[7,6,3]  R2649     5.5883687734603882e-01
    z[7,6,3]  R2650     2.3872801661491394e-01
    z[7,6,3]  R2651     1.3471964001655579e-01
    z[7,6,3]  R2652     -4.1854333877563477e-01
    z[7,6,3]  R2653     -3.5155874490737915e-01
    z[7,6,3]  R2654     -1.6112793982028961e-01
    z[7,6,3]  R2655     -2.5874251127243042e-01
    z[7,6,3]  R2656     4.1502866148948669e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2593     -1
    z[7,6,4]  R2594     1
    z[7,6,4]  R2599     2.0416952669620514e-01
    z[7,6,4]  R2600     3.3035805821418762e-01
    z[7,6,4]  R2601     -1.7304044961929321e-01
    z[7,6,4]  R2602     4.3810001015663147e-01
    z[7,6,4]  R2603     -2.5421399623155594e-02
    z[7,6,4]  R2604     2.4416697025299072e-01
    z[7,6,4]  R2605     -6.8618965148925781e-01
    z[7,6,4]  R2606     -1.9128118455410004e-01
    z[7,6,4]  R2607     1.0645785182714462e-01
    z[7,6,4]  R2608     1.9151549041271210e-01
    z[7,6,4]  R2609     -9.5341891050338745e-02
    z[7,6,4]  R2610     -2.3639196529984474e-02
    z[7,6,4]  R2611     -2.1149487793445587e-01
    z[7,6,4]  R2612     5.1366519182920456e-02
    z[7,6,4]  R2613     -7.3919579386711121e-02
    z[7,6,4]  R2614     8.4743246436119080e-02
    z[7,6,4]  R2615     -1.3100887835025787e-01
    z[7,6,4]  R2616     -3.0006036162376404e-01
    z[7,6,4]  R2617     5.8689940720796585e-02
    z[7,6,4]  R2618     1.6048046946525574e-01
    z[7,6,4]  R2619     -3.9442688226699829e-02
    z[7,6,4]  R2620     3.7176007032394409e-01
    z[7,6,4]  R2621     2.0438171923160553e-01
    z[7,6,4]  R2622     4.1999229788780212e-01
    z[7,6,4]  R2623     4.3914774060249329e-01
    z[7,6,4]  R2624     3.6389192938804626e-01
    z[7,6,4]  R2625     1.3818424940109253e-01
    z[7,6,4]  R2626     0.651690661907196
    z[7,6,4]  R2627     2.8211387991905212e-01
    z[7,6,4]  R2628     -1.8998704850673676e-01
    z[7,6,4]  R2629     3.3453932404518127e-01
    z[7,6,4]  R2630     3.4996751695871353e-02
    z[7,6,4]  R2631     -2.2012539207935333e-01
    z[7,6,4]  R2632     0.0924614816904068
    z[7,6,4]  R2633     -5.1727288961410522e-01
    z[7,6,4]  R2634     -5.6982642412185669e-01
    z[7,6,4]  R2635     -6.3058042526245117e-01
    z[7,6,4]  R2636     -0.63797527551651
    z[7,6,4]  R2637     6.4029365777969360e-02
    z[7,6,4]  R2638     -4.0712919831275940e-01
    z[7,6,4]  R2639     -2.3536796867847443e-01
    z[7,6,4]  R2640     -2.5398181751370430e-02
    z[7,6,4]  R2641     1.9153960049152374e-02
    z[7,6,4]  R2642     3.9977955818176270e-01
    z[7,6,4]  R2643     3.3283424377441406e-01
    z[7,6,4]  R2644     5.4633373022079468e-01
    z[7,6,4]  R2645     6.9716709852218628e-01
    z[7,6,4]  R2646     0.662807047367096
    z[7,6,4]  R2647     -1.0015836358070374e-01
    z[7,6,4]  R2648     3.7013238668441772e-01
    z[7,6,4]  R2649     3.5940846800804138e-01
    z[7,6,4]  R2650     3.0568319559097290e-01
    z[7,6,4]  R2651     2.8309425711631775e-01
    z[7,6,4]  R2652     4.1968545317649841e-01
    z[7,6,4]  R2653     3.2576340436935425e-01
    z[7,6,4]  R2654     6.6773736476898193e-01
    z[7,6,4]  R2655     4.0545329451560974e-01
    z[7,6,4]  R2656     2.2538343071937561e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2595     -1
    z[7,6,5]  R2596     1
    z[7,6,5]  R2599     3.3638903498649597e-01
    z[7,6,5]  R2600     -1.9399334490299225e-01
    z[7,6,5]  R2601     6.7884378135204315e-02
    z[7,6,5]  R2602     4.1109851002693176e-01
    z[7,6,5]  R2603     -2.6039877533912659e-01
    z[7,6,5]  R2604     -0.304644912481308
    z[7,6,5]  R2605     -1.0937741026282310e-02
    z[7,6,5]  R2606     -7.4050599336624146e-01
    z[7,6,5]  R2607     -2.4446092545986176e-01
    z[7,6,5]  R2608     1.9868181645870209e-01
    z[7,6,5]  R2609     1.9656149670481682e-02
    z[7,6,5]  R2610     -2.7998128533363342e-01
    z[7,6,5]  R2611     2.9966005682945251e-01
    z[7,6,5]  R2612     3.5412353277206421e-01
    z[7,6,5]  R2613     0.386221319437027
    z[7,6,5]  R2614     -4.7760433517396450e-03
    z[7,6,5]  R2615     -2.2735865414142609e-01
    z[7,6,5]  R2616     2.6579296588897705e-01
    z[7,6,5]  R2617     2.4337849020957947e-01
    z[7,6,5]  R2618     4.2711076140403748e-01
    z[7,6,5]  R2619     -9.5728859305381775e-02
    z[7,6,5]  R2620     3.1036314368247986e-01
    z[7,6,5]  R2621     2.1151506900787354e-01
    z[7,6,5]  R2622     1.7396314442157745e-01
    z[7,6,5]  R2623     1.3783389329910278e-01
    z[7,6,5]  R2624     1.6777409613132477e-01
    z[7,6,5]  R2625     -0.27127605676651
    z[7,6,5]  R2626     -1.8786061555147171e-02
    z[7,6,5]  R2627     -1.1283921450376511e-01
    z[7,6,5]  R2628     -1.6121678054332733e-01
    z[7,6,5]  R2629     -2.8739389777183533e-01
    z[7,6,5]  R2630     1.8173862993717194e-01
    z[7,6,5]  R2631     -4.7996816039085388e-01
    z[7,6,5]  R2632     -4.1274634003639221e-01
    z[7,6,5]  R2633     -5.5949634313583374e-01
    z[7,6,5]  R2634     2.1661236882209778e-01
    z[7,6,5]  R2635     2.6686948537826538e-01
    z[7,6,5]  R2636     -1.4320363104343414e-01
    z[7,6,5]  R2637     -2.2835098206996918e-01
    z[7,6,5]  R2638     -1.3993540406227112e-01
    z[7,6,5]  R2639     2.7319532632827759e-01
    z[7,6,5]  R2640     -1.7754796147346497e-01
    z[7,6,5]  R2641     -3.8767889142036438e-02
    z[7,6,5]  R2642     8.5950538516044617e-02
    z[7,6,5]  R2643     -1.6209097206592560e-01
    z[7,6,5]  R2644     4.7172746062278748e-01
    z[7,6,5]  R2645     4.6875979751348495e-02
    z[7,6,5]  R2646     2.2366017103195190e-01
    z[7,6,5]  R2647     -0.0428200364112854
    z[7,6,5]  R2648     -4.5355938374996185e-02
    z[7,6,5]  R2649     -2.9270714148879051e-02
    z[7,6,5]  R2650     6.7510330677032471e-01
    z[7,6,5]  R2651     -1.3562041521072388e-01
    z[7,6,5]  R2652     1.8841637670993805e-01
    z[7,6,5]  R2653     -1.9970889389514923e-01
    z[7,6,5]  R2654     -5.9418958425521851e-01
    z[7,6,5]  R2655     4.2719464749097824e-02
    z[7,6,5]  R2656     5.6427270174026489e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2597     -1
    z[7,6,6]  R2598     1
    z[7,6,6]  R2599     -3.0690962448716164e-02
    z[7,6,6]  R2600     -1.2106040120124817e-01
    z[7,6,6]  R2601     4.1880896687507629e-01
    z[7,6,6]  R2602     2.0852467417716980e-01
    z[7,6,6]  R2603     -1.0769448429346085e-01
    z[7,6,6]  R2604     -6.8187125027179718e-02
    z[7,6,6]  R2605     -2.2787373512983322e-02
    z[7,6,6]  R2606     -5.5900763720273972e-02
    z[7,6,6]  R2607     1.4057008922100067e-01
    z[7,6,6]  R2608     5.3969401121139526e-01
    z[7,6,6]  R2609     2.0896056294441223e-01
    z[7,6,6]  R2610     0.0703059658408165
    z[7,6,6]  R2611     -3.1356176733970642e-01
    z[7,6,6]  R2612     -1.4374145865440369e-01
    z[7,6,6]  R2613     9.5743931829929352e-02
    z[7,6,6]  R2614     -2.7017101645469666e-01
    z[7,6,6]  R2615     0.377633661031723
    z[7,6,6]  R2616     1.1471087113022804e-02
    z[7,6,6]  R2617     -3.8736443966627121e-02
    z[7,6,6]  R2618     3.2835307717323303e-01
    z[7,6,6]  R2619     1.2709383852779865e-02
    z[7,6,6]  R2620     -1.4667297899723053e-01
    z[7,6,6]  R2621     8.2507297396659851e-02
    z[7,6,6]  R2622     1.0736383497714996e-01
    z[7,6,6]  R2623     -2.6166132092475891e-01
    z[7,6,6]  R2624     -1.9260872900485992e-01
    z[7,6,6]  R2625     -3.4314379096031189e-02
    z[7,6,6]  R2626     1.6094848513603210e-01
    z[7,6,6]  R2627     -6.2251168489456177e-01
    z[7,6,6]  R2628     -3.9175704121589661e-01
    z[7,6,6]  R2629     -9.2577878385782242e-03
    z[7,6,6]  R2630     3.5427427291870117e-01
    z[7,6,6]  R2631     -6.6698074340820312e-02
    z[7,6,6]  R2632     6.1350151896476746e-02
    z[7,6,6]  R2633     5.8808368444442749e-01
    z[7,6,6]  R2634     0.0457102470099926
    z[7,6,6]  R2635     8.3541408181190491e-02
    z[7,6,6]  R2636     2.9236632585525513e-01
    z[7,6,6]  R2637     -1.8652334809303284e-01
    z[7,6,6]  R2638     6.8160313367843628e-01
    z[7,6,6]  R2639     -6.0713642835617065e-01
    z[7,6,6]  R2640     -6.9817709922790527e-01
    z[7,6,6]  R2641     -5.8500305749475956e-04
    z[7,6,6]  R2642     -9.1050438582897186e-02
    z[7,6,6]  R2643     2.8957182168960571e-01
    z[7,6,6]  R2644     -3.2140389084815979e-02
    z[7,6,6]  R2645     -1.0028751939535141e-01
    z[7,6,6]  R2646     9.1935552656650543e-02
    z[7,6,6]  R2647     9.6539907157421112e-02
    z[7,6,6]  R2648     1.2783069908618927e-01
    z[7,6,6]  R2649     -3.7338647991418839e-02
    z[7,6,6]  R2650     -2.3746129870414734e-01
    z[7,6,6]  R2651     -1.7043109983205795e-02
    z[7,6,6]  R2652     -1.3536711037158966e-01
    z[7,6,6]  R2653     -3.2050654292106628e-01
    z[7,6,6]  R2654     9.1828316450119019e-02
    z[7,6,6]  R2655     -2.7272889018058777e-01
    z[7,6,6]  R2656     4.3219694495201111e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[0,5]
 BV BND1      phi[5,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,7]
 BV BND1      phi[7,2]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,9]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[8,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[0,5,0]
 FR BND1      z[0,5,1]
 FR BND1      z[0,5,2]
 FR BND1      z[0,5,3]
 FR BND1      z[0,5,4]
 FR BND1      z[0,5,5]
 FR BND1      z[0,5,6]
 FR BND1      z[5,0,0]
 FR BND1      z[5,0,1]
 FR BND1      z[5,0,2]
 FR BND1      z[5,0,3]
 FR BND1      z[5,0,4]
 FR BND1      z[5,0,5]
 FR BND1      z[5,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,7,0]
 FR BND1      z[2,7,1]
 FR BND1      z[2,7,2]
 FR BND1      z[2,7,3]
 FR BND1      z[2,7,4]
 FR BND1      z[2,7,5]
 FR BND1      z[2,7,6]
 FR BND1      z[7,2,0]
 FR BND1      z[7,2,1]
 FR BND1      z[7,2,2]
 FR BND1      z[7,2,3]
 FR BND1      z[7,2,4]
 FR BND1      z[7,2,5]
 FR BND1      z[7,2,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
