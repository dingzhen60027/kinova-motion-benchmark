NAME LGCS_GCS_Eq5_5_projected
ROWS
 N  OBJ
 E  R0      
 L  R1      
 E  R2      
 E  R3      
 E  R4      
 E  R5      
 E  R6      
 E  R7      
 E  R8      
 E  R9      
 L  R10     
 E  R11     
 E  R12     
 E  R13     
 E  R14     
 E  R15     
 E  R16     
 E  R17     
 E  R18     
 L  R19     
 E  R20     
 E  R21     
 E  R22     
 E  R23     
 E  R24     
 E  R25     
 E  R26     
 E  R27     
 L  R28     
 E  R29     
 E  R30     
 E  R31     
 E  R32     
 E  R33     
 E  R34     
 E  R35     
 E  R36     
 L  R37     
 E  R38     
 E  R39     
 E  R40     
 E  R41     
 E  R42     
 E  R43     
 E  R44     
 E  R45     
 L  R46     
 E  R47     
 E  R48     
 E  R49     
 E  R50     
 E  R51     
 E  R52     
 E  R53     
 E  R54     
 L  R55     
 E  R56     
 E  R57     
 E  R58     
 E  R59     
 E  R60     
 E  R61     
 E  R62     
 E  R63     
 L  R64     
 E  R65     
 E  R66     
 E  R67     
 E  R68     
 E  R69     
 E  R70     
 E  R71     
 E  R72     
 E  R73     
 L  R74     
 L  R75     
 L  R76     
 L  R77     
 L  R78     
 L  R79     
 L  R80     
 L  R81     
 L  R82     
 L  R83     
 L  R84     
 L  R85     
 L  R86     
 L  R87     
 L  R88     
 L  R89     
 L  R90     
 L  R91     
 L  R92     
 L  R93     
 L  R94     
 L  R95     
 L  R96     
 L  R97     
 L  R98     
 L  R99     
 L  R100    
 L  R101    
 L  R102    
 L  R103    
 L  R104    
 L  R105    
 L  R106    
 L  R107    
 L  R108    
 L  R109    
 L  R110    
 L  R111    
 L  R112    
 L  R113    
 L  R114    
 L  R115    
 L  R116    
 L  R117    
 L  R118    
 L  R119    
 L  R120    
 L  R121    
 L  R122    
 L  R123    
 L  R124    
 L  R125    
 L  R126    
 L  R127    
 L  R128    
 L  R129    
 L  R130    
 L  R131    
 L  R132    
 L  R133    
 L  R134    
 L  R135    
 L  R136    
 L  R137    
 L  R138    
 L  R139    
 L  R140    
 L  R141    
 L  R142    
 L  R143    
 L  R144    
 L  R145    
 L  R146    
 L  R147    
 L  R148    
 L  R149    
 L  R150    
 L  R151    
 L  R152    
 L  R153    
 L  R154    
 L  R155    
 L  R156    
 L  R157    
 L  R158    
 L  R159    
 L  R160    
 L  R161    
 L  R162    
 L  R163    
 L  R164    
 L  R165    
 L  R166    
 L  R167    
 L  R168    
 L  R169    
 L  R170    
 L  R171    
 L  R172    
 L  R173    
 L  R174    
 L  R175    
 L  R176    
 L  R177    
 L  R178    
 L  R179    
 L  R180    
 L  R181    
 L  R182    
 L  R183    
 L  R184    
 L  R185    
 L  R186    
 L  R187    
 L  R188    
 L  R189    
 L  R190    
 L  R191    
 L  R192    
 L  R193    
 L  R194    
 L  R195    
 L  R196    
 L  R197    
 L  R198    
 L  R199    
 L  R200    
 L  R201    
 L  R202    
 L  R203    
 L  R204    
 L  R205    
 L  R206    
 L  R207    
 L  R208    
 L  R209    
 L  R210    
 L  R211    
 L  R212    
 L  R213    
 L  R214    
 L  R215    
 L  R216    
 L  R217    
 L  R218    
 L  R219    
 L  R220    
 L  R221    
 L  R222    
 L  R223    
 L  R224    
 L  R225    
 L  R226    
 L  R227    
 L  R228    
 L  R229    
 L  R230    
 L  R231    
 L  R232    
 L  R233    
 L  R234    
 L  R235    
 L  R236    
 L  R237    
 L  R238    
 L  R239    
 L  R240    
 L  R241    
 L  R242    
 L  R243    
 L  R244    
 L  R245    
 L  R246    
 L  R247    
 L  R248    
 L  R249    
 L  R250    
 L  R251    
 L  R252    
 L  R253    
 L  R254    
 L  R255    
 L  R256    
 L  R257    
 L  R258    
 L  R259    
 L  R260    
 L  R261    
 L  R262    
 L  R263    
 L  R264    
 L  R265    
 L  R266    
 L  R267    
 L  R268    
 L  R269    
 L  R270    
 L  R271    
 L  R272    
 L  R273    
 L  R274    
 L  R275    
 L  R276    
 L  R277    
 L  R278    
 L  R279    
 L  R280    
 L  R281    
 L  R282    
 L  R283    
 L  R284    
 L  R285    
 L  R286    
 L  R287    
 L  R288    
 L  R289    
 L  R290    
 L  R291    
 L  R292    
 L  R293    
 L  R294    
 L  R295    
 L  R296    
 L  R297    
 L  R298    
 L  R299    
 L  R300    
 L  R301    
 L  R302    
 L  R303    
 L  R304    
 L  R305    
 L  R306    
 L  R307    
 L  R308    
 L  R309    
 L  R310    
 L  R311    
 L  R312    
 L  R313    
 L  R314    
 L  R315    
 L  R316    
 L  R317    
 L  R318    
 L  R319    
 L  R320    
 L  R321    
 L  R322    
 L  R323    
 L  R324    
 L  R325    
 L  R326    
 L  R327    
 L  R328    
 L  R329    
 L  R330    
 L  R331    
 L  R332    
 L  R333    
 L  R334    
 L  R335    
 L  R336    
 L  R337    
 L  R338    
 L  R339    
 L  R340    
 L  R341    
 L  R342    
 L  R343    
 L  R344    
 L  R345    
 L  R346    
 L  R347    
 L  R348    
 L  R349    
 L  R350    
 L  R351    
 L  R352    
 L  R353    
 L  R354    
 L  R355    
 L  R356    
 L  R357    
 L  R358    
 L  R359    
 L  R360    
 L  R361    
 L  R362    
 L  R363    
 L  R364    
 L  R365    
 L  R366    
 L  R367    
 L  R368    
 L  R369    
 L  R370    
 L  R371    
 L  R372    
 L  R373    
 L  R374    
 L  R375    
 L  R376    
 L  R377    
 L  R378    
 L  R379    
 L  R380    
 L  R381    
 L  R382    
 L  R383    
 L  R384    
 L  R385    
 L  R386    
 L  R387    
 L  R388    
 L  R389    
 L  R390    
 L  R391    
 L  R392    
 L  R393    
 L  R394    
 L  R395    
 L  R396    
 L  R397    
 L  R398    
 L  R399    
 L  R400    
 L  R401    
 L  R402    
 L  R403    
 L  R404    
 L  R405    
 L  R406    
 L  R407    
 L  R408    
 L  R409    
 L  R410    
 L  R411    
 L  R412    
 L  R413    
 L  R414    
 L  R415    
 L  R416    
 L  R417    
 L  R418    
 L  R419    
 L  R420    
 L  R421    
 L  R422    
 L  R423    
 L  R424    
 L  R425    
 L  R426    
 L  R427    
 L  R428    
 L  R429    
 L  R430    
 L  R431    
 L  R432    
 L  R433    
 L  R434    
 L  R435    
 L  R436    
 L  R437    
 L  R438    
 L  R439    
 L  R440    
 L  R441    
 L  R442    
 L  R443    
 L  R444    
 L  R445    
 L  R446    
 L  R447    
 L  R448    
 L  R449    
 L  R450    
 L  R451    
 L  R452    
 L  R453    
 L  R454    
 L  R455    
 L  R456    
 L  R457    
 L  R458    
 L  R459    
 L  R460    
 L  R461    
 L  R462    
 L  R463    
 L  R464    
 L  R465    
 L  R466    
 L  R467    
 L  R468    
 L  R469    
 L  R470    
 L  R471    
 L  R472    
 L  R473    
 L  R474    
 L  R475    
 L  R476    
 L  R477    
 L  R478    
 L  R479    
 L  R480    
 L  R481    
 L  R482    
 L  R483    
 L  R484    
 L  R485    
 L  R486    
 L  R487    
 L  R488    
 L  R489    
 L  R490    
 L  R491    
 L  R492    
 L  R493    
 L  R494    
 L  R495    
 L  R496    
 L  R497    
 L  R498    
 L  R499    
 L  R500    
 L  R501    
 L  R502    
 L  R503    
 L  R504    
 L  R505    
 L  R506    
 L  R507    
 L  R508    
 L  R509    
 L  R510    
 L  R511    
 L  R512    
 L  R513    
 L  R514    
 L  R515    
 L  R516    
 L  R517    
 L  R518    
 L  R519    
 L  R520    
 L  R521    
 L  R522    
 L  R523    
 L  R524    
 L  R525    
 L  R526    
 L  R527    
 L  R528    
 L  R529    
 L  R530    
 L  R531    
 L  R532    
 L  R533    
 L  R534    
 L  R535    
 L  R536    
 L  R537    
 L  R538    
 L  R539    
 L  R540    
 L  R541    
 L  R542    
 L  R543    
 L  R544    
 L  R545    
 L  R546    
 L  R547    
 L  R548    
 L  R549    
 L  R550    
 L  R551    
 L  R552    
 L  R553    
 L  R554    
 L  R555    
 L  R556    
 L  R557    
 L  R558    
 L  R559    
 L  R560    
 L  R561    
 L  R562    
 L  R563    
 L  R564    
 L  R565    
 L  R566    
 L  R567    
 L  R568    
 L  R569    
 L  R570    
 L  R571    
 L  R572    
 L  R573    
 L  R574    
 L  R575    
 L  R576    
 L  R577    
 L  R578    
 L  R579    
 L  R580    
 L  R581    
 L  R582    
 L  R583    
 L  R584    
 L  R585    
 L  R586    
 L  R587    
 L  R588    
 L  R589    
 L  R590    
 L  R591    
 L  R592    
 L  R593    
 L  R594    
 L  R595    
 L  R596    
 L  R597    
 L  R598    
 L  R599    
 L  R600    
 L  R601    
 L  R602    
 L  R603    
 L  R604    
 L  R605    
 L  R606    
 L  R607    
 L  R608    
 L  R609    
 L  R610    
 L  R611    
 L  R612    
 L  R613    
 L  R614    
 L  R615    
 L  R616    
 L  R617    
 L  R618    
 L  R619    
 L  R620    
 L  R621    
 L  R622    
 L  R623    
 L  R624    
 L  R625    
 L  R626    
 L  R627    
 L  R628    
 L  R629    
 L  R630    
 L  R631    
 L  R632    
 L  R633    
 L  R634    
 L  R635    
 L  R636    
 L  R637    
 L  R638    
 L  R639    
 L  R640    
 L  R641    
 L  R642    
 L  R643    
 L  R644    
 L  R645    
 L  R646    
 L  R647    
 L  R648    
 L  R649    
 L  R650    
 L  R651    
 L  R652    
 L  R653    
 L  R654    
 L  R655    
 L  R656    
 L  R657    
 L  R658    
 L  R659    
 L  R660    
 L  R661    
 L  R662    
 L  R663    
 L  R664    
 L  R665    
 L  R666    
 L  R667    
 L  R668    
 L  R669    
 L  R670    
 L  R671    
 L  R672    
 L  R673    
 L  R674    
 L  R675    
 L  R676    
 L  R677    
 L  R678    
 L  R679    
 L  R680    
 L  R681    
 L  R682    
 L  R683    
 L  R684    
 L  R685    
 L  R686    
 L  R687    
 L  R688    
 L  R689    
 L  R690    
 L  R691    
 L  R692    
 L  R693    
 L  R694    
 L  R695    
 L  R696    
 L  R697    
 L  R698    
 L  R699    
 L  R700    
 L  R701    
 L  R702    
 L  R703    
 L  R704    
 L  R705    
 L  R706    
 L  R707    
 L  R708    
 L  R709    
 L  R710    
 L  R711    
 L  R712    
 L  R713    
 L  R714    
 L  R715    
 L  R716    
 L  R717    
 L  R718    
 L  R719    
 L  R720    
 L  R721    
 L  R722    
 L  R723    
 L  R724    
 L  R725    
 L  R726    
 L  R727    
 L  R728    
 L  R729    
 L  R730    
 L  R731    
 L  R732    
 L  R733    
 L  R734    
 L  R735    
 L  R736    
 L  R737    
 L  R738    
 L  R739    
 L  R740    
 L  R741    
 L  R742    
 L  R743    
 L  R744    
 L  R745    
 L  R746    
 L  R747    
 L  R748    
 L  R749    
 L  R750    
 L  R751    
 L  R752    
 L  R753    
 L  R754    
 L  R755    
 L  R756    
 L  R757    
 L  R758    
 L  R759    
 L  R760    
 L  R761    
 L  R762    
 L  R763    
 L  R764    
 L  R765    
 L  R766    
 L  R767    
 L  R768    
 L  R769    
 L  R770    
 L  R771    
 L  R772    
 L  R773    
 L  R774    
 L  R775    
 L  R776    
 L  R777    
 L  R778    
 L  R779    
 L  R780    
 L  R781    
 L  R782    
 L  R783    
 L  R784    
 L  R785    
 L  R786    
 L  R787    
 L  R788    
 L  R789    
 L  R790    
 L  R791    
 L  R792    
 L  R793    
 L  R794    
 L  R795    
 L  R796    
 L  R797    
 L  R798    
 L  R799    
 L  R800    
 L  R801    
 L  R802    
 L  R803    
 L  R804    
 L  R805    
 L  R806    
 L  R807    
 L  R808    
 L  R809    
 L  R810    
 L  R811    
 L  R812    
 L  R813    
 L  R814    
 L  R815    
 L  R816    
 L  R817    
 L  R818    
 L  R819    
 L  R820    
 L  R821    
 L  R822    
 L  R823    
 L  R824    
 L  R825    
 L  R826    
 L  R827    
 L  R828    
 L  R829    
 L  R830    
 L  R831    
 L  R832    
 L  R833    
 L  R834    
 L  R835    
 L  R836    
 L  R837    
 L  R838    
 L  R839    
 L  R840    
 L  R841    
 L  R842    
 L  R843    
 L  R844    
 L  R845    
 L  R846    
 L  R847    
 L  R848    
 L  R849    
 L  R850    
 L  R851    
 L  R852    
 L  R853    
 L  R854    
 L  R855    
 L  R856    
 L  R857    
 L  R858    
 L  R859    
 L  R860    
 L  R861    
 L  R862    
 L  R863    
 L  R864    
 L  R865    
 L  R866    
 L  R867    
 L  R868    
 L  R869    
 L  R870    
 L  R871    
 L  R872    
 L  R873    
 L  R874    
 L  R875    
 L  R876    
 L  R877    
 L  R878    
 L  R879    
 L  R880    
 L  R881    
 L  R882    
 L  R883    
 L  R884    
 L  R885    
 L  R886    
 L  R887    
 L  R888    
 L  R889    
 L  R890    
 L  R891    
 L  R892    
 L  R893    
 L  R894    
 L  R895    
 L  R896    
 L  R897    
 L  R898    
 L  R899    
 L  R900    
 L  R901    
 L  R902    
 L  R903    
 L  R904    
 L  R905    
 L  R906    
 L  R907    
 L  R908    
 L  R909    
 L  R910    
 L  R911    
 L  R912    
 L  R913    
 L  R914    
 L  R915    
 L  R916    
 L  R917    
 L  R918    
 L  R919    
 L  R920    
 L  R921    
 L  R922    
 L  R923    
 L  R924    
 L  R925    
 L  R926    
 L  R927    
 L  R928    
 L  R929    
 L  R930    
 L  R931    
 L  R932    
 L  R933    
 L  R934    
 L  R935    
 L  R936    
 L  R937    
 L  R938    
 L  R939    
 L  R940    
 L  R941    
 L  R942    
 L  R943    
 L  R944    
 L  R945    
 L  R946    
 L  R947    
 L  R948    
 L  R949    
 L  R950    
 L  R951    
 L  R952    
 L  R953    
 L  R954    
 L  R955    
 L  R956    
 L  R957    
 L  R958    
 L  R959    
 L  R960    
 L  R961    
 L  R962    
 L  R963    
 L  R964    
 L  R965    
 L  R966    
 L  R967    
 L  R968    
 L  R969    
 L  R970    
 L  R971    
 L  R972    
 L  R973    
 L  R974    
 L  R975    
 L  R976    
 L  R977    
 L  R978    
 L  R979    
 L  R980    
 L  R981    
 L  R982    
 L  R983    
 L  R984    
 L  R985    
 L  R986    
 L  R987    
 L  R988    
 L  R989    
 L  R990    
 L  R991    
 L  R992    
 L  R993    
 L  R994    
 L  R995    
 L  R996    
 L  R997    
 L  R998    
 L  R999    
 L  R1000   
 L  R1001   
 L  R1002   
 L  R1003   
 L  R1004   
 L  R1005   
 L  R1006   
 L  R1007   
 L  R1008   
 L  R1009   
 L  R1010   
 L  R1011   
 L  R1012   
 L  R1013   
 L  R1014   
 L  R1015   
 L  R1016   
 L  R1017   
 L  R1018   
 L  R1019   
 L  R1020   
 L  R1021   
 L  R1022   
 L  R1023   
 L  R1024   
 L  R1025   
 L  R1026   
 L  R1027   
 L  R1028   
 L  R1029   
 L  R1030   
 L  R1031   
 L  R1032   
 L  R1033   
 L  R1034   
 L  R1035   
 L  R1036   
 L  R1037   
 L  R1038   
 L  R1039   
 L  R1040   
 L  R1041   
 L  R1042   
 L  R1043   
 L  R1044   
 L  R1045   
 L  R1046   
 L  R1047   
 L  R1048   
 L  R1049   
 L  R1050   
 L  R1051   
 L  R1052   
 L  R1053   
 L  R1054   
 L  R1055   
 L  R1056   
 L  R1057   
 L  R1058   
 L  R1059   
 L  R1060   
 L  R1061   
 L  R1062   
 L  R1063   
 L  R1064   
 L  R1065   
 L  R1066   
 L  R1067   
 L  R1068   
 L  R1069   
 L  R1070   
 L  R1071   
 L  R1072   
 L  R1073   
 L  R1074   
 L  R1075   
 L  R1076   
 L  R1077   
 L  R1078   
 L  R1079   
 L  R1080   
 L  R1081   
 L  R1082   
 L  R1083   
 L  R1084   
 L  R1085   
 L  R1086   
 L  R1087   
 L  R1088   
 L  R1089   
 L  R1090   
 L  R1091   
 L  R1092   
 L  R1093   
 L  R1094   
 L  R1095   
 L  R1096   
 L  R1097   
 L  R1098   
 L  R1099   
 L  R1100   
 L  R1101   
 L  R1102   
 L  R1103   
 L  R1104   
 L  R1105   
 L  R1106   
 L  R1107   
 L  R1108   
 L  R1109   
 L  R1110   
 L  R1111   
 L  R1112   
 L  R1113   
 L  R1114   
 L  R1115   
 L  R1116   
 L  R1117   
 L  R1118   
 L  R1119   
 L  R1120   
 L  R1121   
 L  R1122   
 L  R1123   
 L  R1124   
 L  R1125   
 L  R1126   
 L  R1127   
 L  R1128   
 L  R1129   
 L  R1130   
 L  R1131   
 L  R1132   
 L  R1133   
 L  R1134   
 L  R1135   
 L  R1136   
 L  R1137   
 L  R1138   
 L  R1139   
 L  R1140   
 L  R1141   
 L  R1142   
 L  R1143   
 L  R1144   
 L  R1145   
 L  R1146   
 L  R1147   
 L  R1148   
 L  R1149   
 L  R1150   
 L  R1151   
 L  R1152   
 L  R1153   
 L  R1154   
 L  R1155   
 L  R1156   
 L  R1157   
 L  R1158   
 L  R1159   
 L  R1160   
 L  R1161   
 L  R1162   
 L  R1163   
 L  R1164   
 L  R1165   
 L  R1166   
 L  R1167   
 L  R1168   
 L  R1169   
 L  R1170   
 L  R1171   
 L  R1172   
 L  R1173   
 L  R1174   
 L  R1175   
 L  R1176   
 L  R1177   
 L  R1178   
 L  R1179   
 L  R1180   
 L  R1181   
 L  R1182   
 L  R1183   
 L  R1184   
 L  R1185   
 L  R1186   
 L  R1187   
 L  R1188   
 L  R1189   
 L  R1190   
 L  R1191   
 L  R1192   
 L  R1193   
 L  R1194   
 L  R1195   
 L  R1196   
 L  R1197   
 L  R1198   
 L  R1199   
 L  R1200   
 L  R1201   
 L  R1202   
 L  R1203   
 L  R1204   
 L  R1205   
 L  R1206   
 L  R1207   
 L  R1208   
 L  R1209   
 L  R1210   
 L  R1211   
 L  R1212   
 L  R1213   
 L  R1214   
 L  R1215   
 L  R1216   
 L  R1217   
 L  R1218   
 L  R1219   
 L  R1220   
 L  R1221   
 L  R1222   
 L  R1223   
 L  R1224   
 L  R1225   
 L  R1226   
 L  R1227   
 L  R1228   
 L  R1229   
 L  R1230   
 L  R1231   
 L  R1232   
 L  R1233   
 L  R1234   
 L  R1235   
 L  R1236   
 L  R1237   
 L  R1238   
 L  R1239   
 L  R1240   
 L  R1241   
 L  R1242   
 L  R1243   
 L  R1244   
 L  R1245   
 L  R1246   
 L  R1247   
 L  R1248   
 L  R1249   
 L  R1250   
 L  R1251   
 L  R1252   
 L  R1253   
 L  R1254   
 L  R1255   
 L  R1256   
 L  R1257   
 L  R1258   
 L  R1259   
 L  R1260   
 L  R1261   
 L  R1262   
 L  R1263   
 L  R1264   
 L  R1265   
 L  R1266   
 L  R1267   
 L  R1268   
 L  R1269   
 L  R1270   
 L  R1271   
 L  R1272   
 L  R1273   
 L  R1274   
 L  R1275   
 L  R1276   
 L  R1277   
 L  R1278   
 L  R1279   
 L  R1280   
 L  R1281   
 L  R1282   
 L  R1283   
 L  R1284   
 L  R1285   
 L  R1286   
 L  R1287   
 L  R1288   
 L  R1289   
 L  R1290   
 L  R1291   
 L  R1292   
 L  R1293   
 L  R1294   
 L  R1295   
 L  R1296   
 L  R1297   
 L  R1298   
 L  R1299   
 L  R1300   
 L  R1301   
 L  R1302   
 L  R1303   
 L  R1304   
 L  R1305   
 L  R1306   
 L  R1307   
 L  R1308   
 L  R1309   
 L  R1310   
 L  R1311   
 L  R1312   
 L  R1313   
 L  R1314   
 L  R1315   
 L  R1316   
 L  R1317   
 L  R1318   
 L  R1319   
 L  R1320   
 L  R1321   
 L  R1322   
 L  R1323   
 L  R1324   
 L  R1325   
 L  R1326   
 L  R1327   
 L  R1328   
 L  R1329   
 L  R1330   
 L  R1331   
 L  R1332   
 L  R1333   
 L  R1334   
 L  R1335   
 L  R1336   
 L  R1337   
 L  R1338   
 L  R1339   
 L  R1340   
 L  R1341   
 L  R1342   
 L  R1343   
 L  R1344   
 L  R1345   
 L  R1346   
 L  R1347   
 L  R1348   
 L  R1349   
 L  R1350   
 L  R1351   
 L  R1352   
 L  R1353   
 L  R1354   
 L  R1355   
 L  R1356   
 L  R1357   
 L  R1358   
 L  R1359   
 L  R1360   
 L  R1361   
 L  R1362   
 L  R1363   
 L  R1364   
 L  R1365   
 L  R1366   
 L  R1367   
 L  R1368   
 L  R1369   
 L  R1370   
 L  R1371   
 L  R1372   
 L  R1373   
 L  R1374   
 L  R1375   
 L  R1376   
 L  R1377   
 L  R1378   
 L  R1379   
 L  R1380   
 L  R1381   
 L  R1382   
 L  R1383   
 L  R1384   
 L  R1385   
 L  R1386   
 L  R1387   
 L  R1388   
 L  R1389   
 L  R1390   
 L  R1391   
 L  R1392   
 L  R1393   
 L  R1394   
 L  R1395   
 L  R1396   
 L  R1397   
 L  R1398   
 L  R1399   
 L  R1400   
 L  R1401   
 L  R1402   
 L  R1403   
 L  R1404   
 L  R1405   
 L  R1406   
 L  R1407   
 L  R1408   
 L  R1409   
 L  R1410   
 L  R1411   
 L  R1412   
 L  R1413   
 L  R1414   
 L  R1415   
 L  R1416   
 L  R1417   
 L  R1418   
 L  R1419   
 L  R1420   
 L  R1421   
 L  R1422   
 L  R1423   
 L  R1424   
 L  R1425   
 L  R1426   
 L  R1427   
 L  R1428   
 L  R1429   
 L  R1430   
 L  R1431   
 L  R1432   
 L  R1433   
 L  R1434   
 L  R1435   
 L  R1436   
 L  R1437   
 L  R1438   
 L  R1439   
 L  R1440   
 L  R1441   
 L  R1442   
 L  R1443   
 L  R1444   
 L  R1445   
 L  R1446   
 L  R1447   
 L  R1448   
 L  R1449   
 L  R1450   
 L  R1451   
 L  R1452   
 L  R1453   
 L  R1454   
 L  R1455   
 L  R1456   
 L  R1457   
 L  R1458   
 L  R1459   
 L  R1460   
 L  R1461   
 L  R1462   
 L  R1463   
 L  R1464   
 L  R1465   
 L  R1466   
 L  R1467   
 L  R1468   
 L  R1469   
 L  R1470   
 L  R1471   
 L  R1472   
 L  R1473   
 L  R1474   
 L  R1475   
 L  R1476   
 L  R1477   
 L  R1478   
 L  R1479   
 L  R1480   
 L  R1481   
 L  R1482   
 L  R1483   
 L  R1484   
 L  R1485   
 L  R1486   
 L  R1487   
 L  R1488   
 L  R1489   
 L  R1490   
 L  R1491   
 L  R1492   
 L  R1493   
 L  R1494   
 L  R1495   
 L  R1496   
 L  R1497   
 L  R1498   
 L  R1499   
 L  R1500   
 L  R1501   
 L  R1502   
 L  R1503   
 L  R1504   
 L  R1505   
 L  R1506   
 L  R1507   
 L  R1508   
 L  R1509   
 L  R1510   
 L  R1511   
 L  R1512   
 L  R1513   
 L  R1514   
 L  R1515   
 L  R1516   
 L  R1517   
 L  R1518   
 L  R1519   
 L  R1520   
 L  R1521   
 L  R1522   
 L  R1523   
 L  R1524   
 L  R1525   
 L  R1526   
 L  R1527   
 L  R1528   
 L  R1529   
 L  R1530   
 L  R1531   
 L  R1532   
 L  R1533   
 L  R1534   
 L  R1535   
 L  R1536   
 L  R1537   
 L  R1538   
 L  R1539   
 L  R1540   
 L  R1541   
 L  R1542   
 L  R1543   
 L  R1544   
 L  R1545   
 L  R1546   
 L  R1547   
 L  R1548   
 L  R1549   
 L  R1550   
 L  R1551   
 L  R1552   
 L  R1553   
 L  R1554   
 L  R1555   
 L  R1556   
 L  R1557   
 L  R1558   
 L  R1559   
 L  R1560   
 L  R1561   
 L  R1562   
 L  R1563   
 L  R1564   
 L  R1565   
 L  R1566   
 L  R1567   
 L  R1568   
 L  R1569   
 L  R1570   
 L  R1571   
 L  R1572   
 L  R1573   
 L  R1574   
 L  R1575   
 L  R1576   
 L  R1577   
 L  R1578   
 L  R1579   
 L  R1580   
 L  R1581   
 L  R1582   
 L  R1583   
 L  R1584   
 L  R1585   
 L  R1586   
 L  R1587   
 L  R1588   
 L  R1589   
 L  R1590   
 L  R1591   
 L  R1592   
 L  R1593   
 L  R1594   
 L  R1595   
 L  R1596   
 L  R1597   
 L  R1598   
 L  R1599   
 L  R1600   
 L  R1601   
 L  R1602   
 L  R1603   
 L  R1604   
 L  R1605   
 L  R1606   
 L  R1607   
 L  R1608   
 L  R1609   
 L  R1610   
 L  R1611   
 L  R1612   
 L  R1613   
 L  R1614   
 L  R1615   
 L  R1616   
 L  R1617   
 L  R1618   
 L  R1619   
 L  R1620   
 L  R1621   
 L  R1622   
 L  R1623   
 L  R1624   
 L  R1625   
 L  R1626   
 L  R1627   
 L  R1628   
 L  R1629   
 L  R1630   
 L  R1631   
 L  R1632   
 L  R1633   
 L  R1634   
 L  R1635   
 L  R1636   
 L  R1637   
 L  R1638   
 L  R1639   
 L  R1640   
 L  R1641   
 L  R1642   
 L  R1643   
 L  R1644   
 L  R1645   
 L  R1646   
 L  R1647   
 L  R1648   
 L  R1649   
 L  R1650   
 L  R1651   
 L  R1652   
 L  R1653   
 L  R1654   
 L  R1655   
 L  R1656   
 L  R1657   
 L  R1658   
 L  R1659   
 L  R1660   
 L  R1661   
 L  R1662   
 L  R1663   
 L  R1664   
 L  R1665   
 L  R1666   
 L  R1667   
 L  R1668   
 L  R1669   
 L  R1670   
 L  R1671   
 L  R1672   
 L  R1673   
 L  R1674   
 L  R1675   
 L  R1676   
 L  R1677   
 L  R1678   
 L  R1679   
 L  R1680   
 L  R1681   
 L  R1682   
 L  R1683   
 L  R1684   
 L  R1685   
 L  R1686   
 L  R1687   
 L  R1688   
 L  R1689   
 L  R1690   
 L  R1691   
 L  R1692   
 L  R1693   
 L  R1694   
 L  R1695   
 L  R1696   
 L  R1697   
 L  R1698   
 L  R1699   
 L  R1700   
 L  R1701   
 L  R1702   
 L  R1703   
 L  R1704   
 L  R1705   
 L  R1706   
 L  R1707   
 L  R1708   
 L  R1709   
 L  R1710   
 L  R1711   
 L  R1712   
 L  R1713   
 L  R1714   
 L  R1715   
 L  R1716   
 L  R1717   
 L  R1718   
 L  R1719   
 L  R1720   
 L  R1721   
 L  R1722   
 L  R1723   
 L  R1724   
 L  R1725   
 L  R1726   
 L  R1727   
 L  R1728   
 L  R1729   
 L  R1730   
 L  R1731   
 L  R1732   
 L  R1733   
 L  R1734   
 L  R1735   
 L  R1736   
 L  R1737   
 L  R1738   
 L  R1739   
 L  R1740   
 L  R1741   
 L  R1742   
 L  R1743   
 L  R1744   
 L  R1745   
 L  R1746   
 L  R1747   
 L  R1748   
 L  R1749   
 L  R1750   
 L  R1751   
 L  R1752   
 L  R1753   
 L  R1754   
 L  R1755   
 L  R1756   
 L  R1757   
 L  R1758   
 L  R1759   
 L  R1760   
 L  R1761   
 L  R1762   
 L  R1763   
 L  R1764   
 L  R1765   
 L  R1766   
 L  R1767   
 L  R1768   
 L  R1769   
 L  R1770   
 L  R1771   
 L  R1772   
 L  R1773   
 L  R1774   
 L  R1775   
 L  R1776   
 L  R1777   
 L  R1778   
 L  R1779   
 L  R1780   
 L  R1781   
 L  R1782   
 L  R1783   
 L  R1784   
 L  R1785   
 L  R1786   
 L  R1787   
 L  R1788   
 L  R1789   
 L  R1790   
 L  R1791   
 L  R1792   
 L  R1793   
 L  R1794   
 L  R1795   
 L  R1796   
 L  R1797   
 L  R1798   
 L  R1799   
 L  R1800   
 L  R1801   
 L  R1802   
 L  R1803   
 L  R1804   
 L  R1805   
 L  R1806   
 L  R1807   
 L  R1808   
 L  R1809   
 L  R1810   
 L  R1811   
 L  R1812   
 L  R1813   
 L  R1814   
 L  R1815   
 L  R1816   
 L  R1817   
 L  R1818   
 L  R1819   
 L  R1820   
 L  R1821   
 L  R1822   
 L  R1823   
 L  R1824   
 L  R1825   
 L  R1826   
 L  R1827   
 L  R1828   
 L  R1829   
 L  R1830   
 L  R1831   
 L  R1832   
 L  R1833   
 L  R1834   
 L  R1835   
 L  R1836   
 L  R1837   
 L  R1838   
 L  R1839   
 L  R1840   
 L  R1841   
 L  R1842   
 L  R1843   
 L  R1844   
 L  R1845   
 L  R1846   
 L  R1847   
 L  R1848   
 L  R1849   
 L  R1850   
 L  R1851   
 L  R1852   
 L  R1853   
 L  R1854   
 L  R1855   
 L  R1856   
 L  R1857   
 L  R1858   
 L  R1859   
 L  R1860   
 L  R1861   
 L  R1862   
 L  R1863   
 L  R1864   
 L  R1865   
 L  R1866   
 L  R1867   
 L  R1868   
 L  R1869   
 L  R1870   
 L  R1871   
 L  R1872   
 L  R1873   
 L  R1874   
 L  R1875   
 L  R1876   
 L  R1877   
 L  R1878   
 L  R1879   
 L  R1880   
 L  R1881   
 L  R1882   
 L  R1883   
 L  R1884   
 L  R1885   
 L  R1886   
 L  R1887   
 L  R1888   
 L  R1889   
 L  R1890   
 L  R1891   
 L  R1892   
 L  R1893   
 L  R1894   
 L  R1895   
 L  R1896   
 L  R1897   
 L  R1898   
 L  R1899   
 L  R1900   
 L  R1901   
 L  R1902   
 L  R1903   
 L  R1904   
 L  R1905   
 L  R1906   
 L  R1907   
 L  R1908   
 L  R1909   
 L  R1910   
 L  R1911   
 L  R1912   
 L  R1913   
 L  R1914   
 L  R1915   
 L  R1916   
 L  R1917   
 L  R1918   
 L  R1919   
 L  R1920   
 L  R1921   
 L  R1922   
 L  R1923   
 L  R1924   
 L  R1925   
 L  R1926   
 L  R1927   
 L  R1928   
 L  R1929   
 L  R1930   
 L  R1931   
 L  R1932   
 L  R1933   
 L  R1934   
 L  R1935   
 L  R1936   
 L  R1937   
 L  R1938   
 L  R1939   
 L  R1940   
 L  R1941   
 L  R1942   
 L  R1943   
 L  R1944   
 L  R1945   
 L  R1946   
 L  R1947   
 L  R1948   
 L  R1949   
 L  R1950   
 L  R1951   
 L  R1952   
 L  R1953   
 L  R1954   
 L  R1955   
 L  R1956   
 L  R1957   
 L  R1958   
 L  R1959   
 L  R1960   
 L  R1961   
 L  R1962   
 L  R1963   
 L  R1964   
 L  R1965   
 L  R1966   
 L  R1967   
 L  R1968   
 L  R1969   
 L  R1970   
 L  R1971   
 L  R1972   
 L  R1973   
 L  R1974   
 L  R1975   
 L  R1976   
 L  R1977   
 L  R1978   
 L  R1979   
 L  R1980   
 L  R1981   
 L  R1982   
 L  R1983   
 L  R1984   
 L  R1985   
 L  R1986   
 L  R1987   
 L  R1988   
 L  R1989   
 L  R1990   
 L  R1991   
 L  R1992   
 L  R1993   
 L  R1994   
 L  R1995   
 L  R1996   
 L  R1997   
 L  R1998   
 L  R1999   
 L  R2000   
 L  R2001   
 L  R2002   
 L  R2003   
 L  R2004   
 L  R2005   
 L  R2006   
 L  R2007   
 L  R2008   
 L  R2009   
 L  R2010   
 L  R2011   
 L  R2012   
 L  R2013   
 L  R2014   
 L  R2015   
 L  R2016   
 L  R2017   
 L  R2018   
 L  R2019   
 L  R2020   
 L  R2021   
 L  R2022   
 L  R2023   
 L  R2024   
 L  R2025   
 L  R2026   
 L  R2027   
 L  R2028   
 L  R2029   
 L  R2030   
 L  R2031   
 L  R2032   
 L  R2033   
 L  R2034   
 L  R2035   
 L  R2036   
 L  R2037   
 L  R2038   
 L  R2039   
 L  R2040   
 L  R2041   
 L  R2042   
 L  R2043   
 L  R2044   
 L  R2045   
 L  R2046   
 L  R2047   
 L  R2048   
 L  R2049   
 L  R2050   
 L  R2051   
 L  R2052   
 L  R2053   
 L  R2054   
 L  R2055   
 L  R2056   
 L  R2057   
 L  R2058   
 L  R2059   
 L  R2060   
 L  R2061   
 L  R2062   
 L  R2063   
 L  R2064   
 L  R2065   
 L  R2066   
 L  R2067   
 L  R2068   
 L  R2069   
 L  R2070   
 L  R2071   
 L  R2072   
 L  R2073   
 L  R2074   
 L  R2075   
 L  R2076   
 L  R2077   
 L  R2078   
 L  R2079   
 L  R2080   
 L  R2081   
 L  R2082   
 L  R2083   
 L  R2084   
 L  R2085   
 L  R2086   
 L  R2087   
 L  R2088   
 L  R2089   
 L  R2090   
 L  R2091   
 L  R2092   
 L  R2093   
 L  R2094   
 L  R2095   
 L  R2096   
 L  R2097   
 L  R2098   
 L  R2099   
 L  R2100   
 L  R2101   
 L  R2102   
 L  R2103   
 L  R2104   
 L  R2105   
 L  R2106   
 L  R2107   
 L  R2108   
 L  R2109   
 L  R2110   
 L  R2111   
 L  R2112   
 L  R2113   
 L  R2114   
 L  R2115   
 L  R2116   
 L  R2117   
 L  R2118   
 L  R2119   
 L  R2120   
 L  R2121   
 L  R2122   
 L  R2123   
 L  R2124   
 L  R2125   
 L  R2126   
 L  R2127   
 L  R2128   
 L  R2129   
 L  R2130   
 L  R2131   
 L  R2132   
 L  R2133   
 L  R2134   
 L  R2135   
 L  R2136   
 L  R2137   
 L  R2138   
 L  R2139   
 L  R2140   
 L  R2141   
 L  R2142   
 L  R2143   
 L  R2144   
 L  R2145   
 L  R2146   
 L  R2147   
 L  R2148   
 L  R2149   
 L  R2150   
 L  R2151   
 L  R2152   
 L  R2153   
 L  R2154   
 L  R2155   
 L  R2156   
 L  R2157   
 L  R2158   
 L  R2159   
 L  R2160   
 L  R2161   
 L  R2162   
 L  R2163   
 L  R2164   
 L  R2165   
 L  R2166   
 L  R2167   
 L  R2168   
 L  R2169   
 L  R2170   
 L  R2171   
 L  R2172   
 L  R2173   
 L  R2174   
 L  R2175   
 L  R2176   
 L  R2177   
 L  R2178   
 L  R2179   
 L  R2180   
 L  R2181   
 L  R2182   
 L  R2183   
 L  R2184   
 L  R2185   
 L  R2186   
 L  R2187   
 L  R2188   
 L  R2189   
 L  R2190   
 L  R2191   
 L  R2192   
 L  R2193   
 L  R2194   
 L  R2195   
 L  R2196   
 L  R2197   
 L  R2198   
 L  R2199   
 L  R2200   
 L  R2201   
 L  R2202   
 L  R2203   
 L  R2204   
 L  R2205   
 L  R2206   
 L  R2207   
 L  R2208   
 L  R2209   
 L  R2210   
 L  R2211   
 L  R2212   
 L  R2213   
 L  R2214   
 L  R2215   
 L  R2216   
 L  R2217   
 L  R2218   
 L  R2219   
 L  R2220   
 L  R2221   
 L  R2222   
 L  R2223   
 L  R2224   
 L  R2225   
 L  R2226   
 L  R2227   
 L  R2228   
 L  R2229   
 L  R2230   
 L  R2231   
 L  R2232   
 L  R2233   
 L  R2234   
 L  R2235   
 L  R2236   
 L  R2237   
 L  R2238   
 L  R2239   
 L  R2240   
 L  R2241   
 L  R2242   
 L  R2243   
 L  R2244   
 L  R2245   
 L  R2246   
 L  R2247   
 L  R2248   
 L  R2249   
 L  R2250   
 L  R2251   
 L  R2252   
 L  R2253   
 L  R2254   
 L  R2255   
 L  R2256   
 L  R2257   
 L  R2258   
 L  R2259   
 L  R2260   
 L  R2261   
 L  R2262   
 L  R2263   
 L  R2264   
 L  R2265   
 L  R2266   
 L  R2267   
 L  R2268   
 L  R2269   
 L  R2270   
 L  R2271   
 L  R2272   
 L  R2273   
 L  R2274   
 L  R2275   
 L  R2276   
 L  R2277   
 L  R2278   
 L  R2279   
 L  R2280   
 L  R2281   
 L  R2282   
 L  R2283   
 L  R2284   
 L  R2285   
 L  R2286   
 L  R2287   
 L  R2288   
 L  R2289   
 L  R2290   
 L  R2291   
 L  R2292   
 L  R2293   
 L  R2294   
 L  R2295   
 L  R2296   
 L  R2297   
 L  R2298   
 L  R2299   
 L  R2300   
 L  R2301   
 L  R2302   
 L  R2303   
 L  R2304   
 L  R2305   
 L  R2306   
 L  R2307   
 L  R2308   
 L  R2309   
 L  R2310   
 L  R2311   
 L  R2312   
 L  R2313   
 L  R2314   
 L  R2315   
 L  R2316   
 L  R2317   
 L  R2318   
 L  R2319   
 L  R2320   
 L  R2321   
 L  R2322   
 L  R2323   
 L  R2324   
 L  R2325   
 L  R2326   
 L  R2327   
 L  R2328   
 L  R2329   
 L  R2330   
 L  R2331   
 L  R2332   
 L  R2333   
 L  R2334   
 L  R2335   
 L  R2336   
 L  R2337   
 L  R2338   
 L  R2339   
 L  R2340   
 L  R2341   
 L  R2342   
 L  R2343   
 L  R2344   
 L  R2345   
 L  R2346   
 L  R2347   
 L  R2348   
 L  R2349   
 L  R2350   
 L  R2351   
 L  R2352   
 L  R2353   
 L  R2354   
 L  R2355   
 L  R2356   
 L  R2357   
 L  R2358   
 L  R2359   
 L  R2360   
 L  R2361   
 L  R2362   
 L  R2363   
 L  R2364   
 L  R2365   
 L  R2366   
 L  R2367   
 L  R2368   
 L  R2369   
 L  R2370   
 L  R2371   
 L  R2372   
 L  R2373   
 L  R2374   
 L  R2375   
 L  R2376   
 L  R2377   
 L  R2378   
 L  R2379   
 L  R2380   
 L  R2381   
 L  R2382   
 L  R2383   
 L  R2384   
 L  R2385   
 L  R2386   
 L  R2387   
 L  R2388   
 L  R2389   
 L  R2390   
 L  R2391   
 L  R2392   
 L  R2393   
 L  R2394   
 L  R2395   
 L  R2396   
 L  R2397   
 L  R2398   
 L  R2399   
 L  R2400   
 L  R2401   
 L  R2402   
 L  R2403   
 L  R2404   
 L  R2405   
 L  R2406   
 L  R2407   
 L  R2408   
 L  R2409   
 L  R2410   
 L  R2411   
 L  R2412   
 L  R2413   
 L  R2414   
 L  R2415   
 L  R2416   
 L  R2417   
 L  R2418   
 L  R2419   
 L  R2420   
 L  R2421   
 L  R2422   
 L  R2423   
 L  R2424   
 L  R2425   
 L  R2426   
 L  R2427   
 L  R2428   
 L  R2429   
 L  R2430   
 L  R2431   
 L  R2432   
 L  R2433   
 L  R2434   
 L  R2435   
 L  R2436   
 L  R2437   
 L  R2438   
 L  R2439   
 L  R2440   
 L  R2441   
 L  R2442   
 L  R2443   
 L  R2444   
 L  R2445   
 L  R2446   
 L  R2447   
 L  R2448   
 L  R2449   
 L  R2450   
 L  R2451   
 L  R2452   
 L  R2453   
 L  R2454   
 L  R2455   
 L  R2456   
 L  R2457   
 L  R2458   
 L  R2459   
 L  R2460   
 L  R2461   
 L  R2462   
 L  R2463   
 L  R2464   
 L  R2465   
 L  R2466   
 L  R2467   
 L  R2468   
 L  R2469   
 L  R2470   
 L  R2471   
 L  R2472   
 L  R2473   
 L  R2474   
 L  R2475   
 L  R2476   
 L  R2477   
 L  R2478   
 L  R2479   
 L  R2480   
 L  R2481   
 L  R2482   
 L  R2483   
 L  R2484   
 L  R2485   
 L  R2486   
 L  R2487   
 L  R2488   
 L  R2489   
 L  R2490   
 L  R2491   
 L  R2492   
 L  R2493   
 L  R2494   
 L  R2495   
 L  R2496   
 L  R2497   
 L  R2498   
 L  R2499   
 L  R2500   
 L  R2501   
 L  R2502   
 L  R2503   
 L  R2504   
 L  R2505   
 L  R2506   
 L  R2507   
 L  R2508   
 L  R2509   
 L  R2510   
 L  R2511   
 L  R2512   
 L  R2513   
 L  R2514   
 L  R2515   
 L  R2516   
 L  R2517   
 L  R2518   
 L  R2519   
 L  R2520   
 L  R2521   
 L  R2522   
 L  R2523   
 L  R2524   
 L  R2525   
 L  R2526   
 L  R2527   
 L  R2528   
 L  R2529   
 L  R2530   
 L  R2531   
 L  R2532   
 L  R2533   
 L  R2534   
 L  R2535   
 L  R2536   
 L  R2537   
 L  R2538   
 L  R2539   
 L  R2540   
 L  R2541   
 L  R2542   
 L  R2543   
 L  R2544   
 L  R2545   
 L  R2546   
 L  R2547   
 L  R2548   
 L  R2549   
 L  R2550   
 L  R2551   
 L  R2552   
 L  R2553   
 L  R2554   
 L  R2555   
 L  R2556   
 L  R2557   
 L  R2558   
 L  R2559   
 L  R2560   
 L  R2561   
 L  R2562   
 L  R2563   
 L  R2564   
 L  R2565   
 L  R2566   
 L  R2567   
 L  R2568   
 L  R2569   
 L  R2570   
 L  R2571   
 L  R2572   
 L  R2573   
 L  R2574   
 L  R2575   
 L  R2576   
 L  R2577   
 L  R2578   
 L  R2579   
 L  R2580   
 L  R2581   
 L  R2582   
 L  R2583   
 L  R2584   
 L  R2585   
 L  R2586   
 L  R2587   
 L  R2588   
 L  R2589   
 L  R2590   
 L  R2591   
 L  R2592   
 L  R2593   
 L  R2594   
 L  R2595   
 L  R2596   
 L  R2597   
 L  R2598   
 L  R2599   
 L  R2600   
 L  R2601   
 L  R2602   
 L  R2603   
 L  R2604   
 L  R2605   
 L  R2606   
 L  R2607   
 L  R2608   
 L  R2609   
 L  R2610   
 L  R2611   
 L  R2612   
 L  R2613   
 L  R2614   
 L  R2615   
 L  R2616   
 L  R2617   
 L  R2618   
 L  R2619   
 L  R2620   
 L  R2621   
 L  R2622   
 L  R2623   
 L  R2624   
 L  R2625   
 L  R2626   
 L  R2627   
 L  R2628   
 L  R2629   
 L  R2630   
 L  R2631   
 L  R2632   
 L  R2633   
 L  R2634   
 L  R2635   
 L  R2636   
 L  R2637   
 L  R2638   
 L  R2639   
 L  R2640   
 L  R2641   
 L  R2642   
 L  R2643   
 L  R2644   
 L  R2645   
 L  R2646   
 L  R2647   
 L  R2648   
 L  R2649   
 L  R2650   
 L  R2651   
 L  R2652   
 L  R2653   
 L  R2654   
 L  R2655   
 L  R2656   
 L  R2657   
 L  R2658   
 L  R2659   
 L  R2660   
 L  R2661   
 L  R2662   
 L  R2663   
 L  R2664   
 L  R2665   
 L  R2666   
 L  R2667   
 L  R2668   
 L  R2669   
 L  R2670   
 L  R2671   
 L  R2672   
 L  R2673   
 L  R2674   
 L  R2675   
 L  R2676   
 L  R2677   
 L  R2678   
 L  R2679   
 L  R2680   
 L  R2681   
 L  R2682   
 L  R2683   
 L  R2684   
 L  R2685   
 L  R2686   
 L  R2687   
 L  R2688   
 L  R2689   
 L  R2690   
 L  R2691   
 L  R2692   
 L  R2693   
 L  R2694   
 L  R2695   
 L  R2696   
 L  R2697   
 L  R2698   
 L  R2699   
 L  R2700   
 L  R2701   
 L  R2702   
 L  R2703   
 L  R2704   
 L  R2705   
 L  R2706   
 L  R2707   
 L  R2708   
 L  R2709   
 L  R2710   
 L  R2711   
 L  R2712   
 L  R2713   
 L  R2714   
 L  R2715   
 L  R2716   
 L  R2717   
 L  R2718   
 L  R2719   
 L  R2720   
 L  R2721   
 L  R2722   
 L  R2723   
 L  R2724   
 L  R2725   
 L  R2726   
 L  R2727   
 L  R2728   
 L  R2729   
 L  R2730   
 L  R2731   
 L  R2732   
 L  R2733   
 L  R2734   
 L  R2735   
 L  R2736   
 L  R2737   
 L  R2738   
 L  R2739   
 L  R2740   
 L  R2741   
 L  R2742   
 L  R2743   
 L  R2744   
 L  R2745   
 L  R2746   
 L  R2747   
 L  R2748   
 L  R2749   
 L  R2750   
 L  R2751   
 L  R2752   
 L  R2753   
 L  R2754   
 L  R2755   
 L  R2756   
 L  R2757   
 L  R2758   
 L  R2759   
 L  R2760   
 L  R2761   
 L  R2762   
 L  R2763   
 L  R2764   
 L  R2765   
 L  R2766   
 L  R2767   
 L  R2768   
 L  R2769   
 L  R2770   
 L  R2771   
 L  R2772   
 L  R2773   
 L  R2774   
 L  R2775   
 L  R2776   
 L  R2777   
 L  R2778   
 L  R2779   
 L  R2780   
 L  R2781   
 L  R2782   
 L  R2783   
 L  R2784   
 L  R2785   
 L  R2786   
 L  R2787   
 L  R2788   
 L  R2789   
 L  R2790   
 L  R2791   
 L  R2792   
 L  R2793   
 L  R2794   
 L  R2795   
 L  qc0     
 L  qc1     
 L  qc2     
 L  qc3     
 L  qc4     
 L  qc5     
 L  qc6     
 L  qc7     
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    phi[0,1]  R0        1
    phi[0,1]  R1        1
    phi[0,1]  R9        -1
    phi[0,1]  R74       -3.0999999046325684e+00
    phi[0,1]  R75       -3.0999999046325684e+00
    phi[0,1]  R76       -2.2400000095367432e+00
    phi[0,1]  R77       -2.2400000095367432e+00
    phi[0,1]  R78       -3.0999999046325684e+00
    phi[0,1]  R79       -3.0999999046325684e+00
    phi[0,1]  R80       -2.5699999332427979e+00
    phi[0,1]  R81       -2.5699999332427979e+00
    phi[0,1]  R82       -3.0999999046325684e+00
    phi[0,1]  R83       -3.0999999046325684e+00
    phi[0,1]  R84       -2.0899999141693115e+00
    phi[0,1]  R85       -2.0899999141693115e+00
    phi[0,1]  R86       -3.0999999046325684e+00
    phi[0,1]  R87       -3.0999999046325684e+00
    phi[0,1]  R88       0.625244677066803
    phi[0,1]  R89       1.2717968225479126e+00
    phi[0,1]  R90       3.3309084177017212e-01
    phi[0,1]  R91       0.686057984828949
    phi[0,1]  R92       1.6004391908645630e+00
    phi[0,1]  R93       2.2717559337615967e+00
    phi[0,1]  R94       -3.1097415089607239e-01
    phi[0,1]  R95       1.9003097712993622e-01
    phi[0,1]  R96       1.7814581394195557e+00
    phi[0,1]  R97       6.2946307659149170e-01
    phi[0,1]  R98       -2.1473641395568848e+00
    phi[0,1]  R99       -1.5435588359832764e+00
    phi[0,1]  R100      -2.9351737499237061e+00
    phi[0,1]  R101      -6.6800886392593384e-01
    phi[0,1]  R102      -1.5970200300216675e+00
    phi[0,1]  R103      7.4499297142028809e-01
    phi[0,1]  R104      5.5260056257247925e-01
    phi[0,1]  R105      -9.7976565361022949e-01
    phi[0,1]  R106      2.6851642131805420e-01
    phi[0,1]  R107      4.7060213983058929e-02
    phi[0,1]  R108      -2.1756343841552734e+00
    phi[0,1]  R109      -2.8722872734069824e+00
    phi[0,1]  R110      -2.3372904956340790e-01
    phi[0,1]  R111      -1.1735140085220337e+00
    phi[0,1]  R112      -1.2816771268844604e+00
    phi[0,1]  R113      -1.1608783155679703e-01
    phi[0,1]  R114      3.8702431321144104e-01
    phi[0,1]  R115      7.9299086332321167e-01
    phi[0,1]  R116      -5.5382376909255981e-01
    phi[0,1]  R117      2.4207285046577454e-01
    phi[0,1]  R118      1.2096215486526489e+00
    phi[0,1]  R119      -1.1823527812957764e+00
    phi[0,1]  R120      -7.6700264215469360e-01
    phi[0,1]  R121      -5.6112051010131836e-01
    phi[0,1]  R122      5.2405405044555664e-01
    phi[0,1]  R123      -1.2267128229141235e+00
    phi[0,1]  R124      -1.2640870809555054e+00
    phi[0,1]  R125      -1.1300996541976929e+00
    phi[0,1]  R126      -2.1962814331054688e+00
    phi[0,1]  R127      -1.0897940397262573e+00
    phi[0,1]  R128      1.9534587860107422e+00
    phi[0,1]  R129      1.2907648086547852e+00
    phi[0,1]  R130      -8.8761484622955322e-01
    phi[0,1]  R131      1.9785450696945190e+00
    phi[0,1]  R132      4.7387224435806274e-01
    phi[0,1]  R133      -0.0670148953795433
    phi[0,1]  R134      4.6802043914794922e-01
    phi[0,1]  R135      -2.7090033888816833e-01
    phi[0,1]  R136      -5.6464749574661255e-01
    phi[0,1]  R137      -0.398283988237381
    phi[0,1]  R138      -4.4524499773979187e-01
    phi[0,1]  R139      7.5308001041412354e-01
    phi[0,1]  R140      -1.7003352642059326e+00
    phi[0,1]  R141      -1.8118373155593872e+00
    phi[0,1]  R142      -1.0007159709930420e+00
    phi[0,1]  R143      -1.8160146474838257e+00
    phi[0,1]  R144      -1.0122696161270142e+00
    phi[0,1]  R145      -1.3669914007186890e+00
    phi[0,1]  R146      -2.6228461265563965e+00
    phi[0,1]  R147      -2.7332201004028320e+00
    phi[0,1]  R148      -4.3170168995857239e-01
    phi[0,1]  R149      -2.0487210154533386e-01
    phi[0,1]  R150      2.6822918653488159e-01
    phi[0,1]  R151      -1.5420988798141479e+00
    phi[0,1]  R152      -0.587051272392273
    phi[0,1]  R153      3.0129665508866310e-02
    phi[0,1]  R154      -1.9064785242080688e+00
    phi[0,1]  R155      -1.1628345251083374e+00
    phi[0,1]  R156      -3.7289586663246155e-01
    phi[0,1]  R157      -2.0391874313354492e+00
    phi[0,1]  R158      1.6316741704940796e-02
    phi[0,1]  R159      6.3646368682384491e-02
    phi[0,1]  R160      -7.2649228572845459e-01
    phi[0,1]  R161      -8.7619185447692871e-01
    phi[0,1]  R162      -2.70692777633667
    phi[0,1]  R163      -3.1485168933868408e+00
    phi[0,1]  R164      -3.2671751976013184e+00
    phi[0,1]  R165      -2.1625380516052246e+00
    phi[0,1]  R166      -2.1425621509552
    phi[0,1]  R167      -2.2223665714263916e+00
    phi[1,0]  R0        -1
    phi[1,0]  R9        1
    phi[1,0]  R10       1
    phi[1,0]  R168      -3.0999999046325684e+00
    phi[1,0]  R169      -3.0999999046325684e+00
    phi[1,0]  R170      -2.2400000095367432e+00
    phi[1,0]  R171      -2.2400000095367432e+00
    phi[1,0]  R172      -3.0999999046325684e+00
    phi[1,0]  R173      -3.0999999046325684e+00
    phi[1,0]  R174      -2.5699999332427979e+00
    phi[1,0]  R175      -2.5699999332427979e+00
    phi[1,0]  R176      -3.0999999046325684e+00
    phi[1,0]  R177      -3.0999999046325684e+00
    phi[1,0]  R178      -2.0899999141693115e+00
    phi[1,0]  R179      -2.0899999141693115e+00
    phi[1,0]  R180      -3.0999999046325684e+00
    phi[1,0]  R181      -3.0999999046325684e+00
    phi[1,0]  R182      1.9534587860107422e+00
    phi[1,0]  R183      1.2907648086547852e+00
    phi[1,0]  R184      -8.8761484622955322e-01
    phi[1,0]  R185      1.9785450696945190e+00
    phi[1,0]  R186      4.7387224435806274e-01
    phi[1,0]  R187      -0.0670148953795433
    phi[1,0]  R188      4.6802043914794922e-01
    phi[1,0]  R189      -2.7090033888816833e-01
    phi[1,0]  R190      -5.6464749574661255e-01
    phi[1,0]  R191      -0.398283988237381
    phi[1,0]  R192      -4.4524499773979187e-01
    phi[1,0]  R193      7.5308001041412354e-01
    phi[1,0]  R194      -1.7003352642059326e+00
    phi[1,0]  R195      -1.8118373155593872e+00
    phi[1,0]  R196      -1.0007159709930420e+00
    phi[1,0]  R197      -1.8160146474838257e+00
    phi[1,0]  R198      -1.0122696161270142e+00
    phi[1,0]  R199      -1.3669914007186890e+00
    phi[1,0]  R200      -2.6228461265563965e+00
    phi[1,0]  R201      -2.7332201004028320e+00
    phi[1,0]  R202      -4.3170168995857239e-01
    phi[1,0]  R203      -2.0487210154533386e-01
    phi[1,0]  R204      2.6822918653488159e-01
    phi[1,0]  R205      -1.5420988798141479e+00
    phi[1,0]  R206      -0.587051272392273
    phi[1,0]  R207      3.0129665508866310e-02
    phi[1,0]  R208      -1.9064785242080688e+00
    phi[1,0]  R209      -1.1628345251083374e+00
    phi[1,0]  R210      -3.7289586663246155e-01
    phi[1,0]  R211      -2.0391874313354492e+00
    phi[1,0]  R212      1.6316741704940796e-02
    phi[1,0]  R213      6.3646368682384491e-02
    phi[1,0]  R214      -7.2649228572845459e-01
    phi[1,0]  R215      -8.7619185447692871e-01
    phi[1,0]  R216      -2.70692777633667
    phi[1,0]  R217      -3.1485168933868408e+00
    phi[1,0]  R218      -3.2671751976013184e+00
    phi[1,0]  R219      -2.1625380516052246e+00
    phi[1,0]  R220      -2.1425621509552
    phi[1,0]  R221      -2.2223665714263916e+00
    phi[1,0]  R222      0.625244677066803
    phi[1,0]  R223      1.2717968225479126e+00
    phi[1,0]  R224      3.3309084177017212e-01
    phi[1,0]  R225      0.686057984828949
    phi[1,0]  R226      1.6004391908645630e+00
    phi[1,0]  R227      2.2717559337615967e+00
    phi[1,0]  R228      -3.1097415089607239e-01
    phi[1,0]  R229      1.9003097712993622e-01
    phi[1,0]  R230      1.7814581394195557e+00
    phi[1,0]  R231      6.2946307659149170e-01
    phi[1,0]  R232      -2.1473641395568848e+00
    phi[1,0]  R233      -1.5435588359832764e+00
    phi[1,0]  R234      -2.9351737499237061e+00
    phi[1,0]  R235      -6.6800886392593384e-01
    phi[1,0]  R236      -1.5970200300216675e+00
    phi[1,0]  R237      7.4499297142028809e-01
    phi[1,0]  R238      5.5260056257247925e-01
    phi[1,0]  R239      -9.7976565361022949e-01
    phi[1,0]  R240      2.6851642131805420e-01
    phi[1,0]  R241      4.7060213983058929e-02
    phi[1,0]  R242      -2.1756343841552734e+00
    phi[1,0]  R243      -2.8722872734069824e+00
    phi[1,0]  R244      -2.3372904956340790e-01
    phi[1,0]  R245      -1.1735140085220337e+00
    phi[1,0]  R246      -1.2816771268844604e+00
    phi[1,0]  R247      -1.1608783155679703e-01
    phi[1,0]  R248      3.8702431321144104e-01
    phi[1,0]  R249      7.9299086332321167e-01
    phi[1,0]  R250      -5.5382376909255981e-01
    phi[1,0]  R251      2.4207285046577454e-01
    phi[1,0]  R252      1.2096215486526489e+00
    phi[1,0]  R253      -1.1823527812957764e+00
    phi[1,0]  R254      -7.6700264215469360e-01
    phi[1,0]  R255      -5.6112051010131836e-01
    phi[1,0]  R256      5.2405405044555664e-01
    phi[1,0]  R257      -1.2267128229141235e+00
    phi[1,0]  R258      -1.2640870809555054e+00
    phi[1,0]  R259      -1.1300996541976929e+00
    phi[1,0]  R260      -2.1962814331054688e+00
    phi[1,0]  R261      -1.0897940397262573e+00
    phi[0,4]  R0        1
    phi[0,4]  R1        1
    phi[0,4]  R36       -1
    phi[0,4]  R262      -3.0999999046325684e+00
    phi[0,4]  R263      -3.0999999046325684e+00
    phi[0,4]  R264      -2.2400000095367432e+00
    phi[0,4]  R265      -2.2400000095367432e+00
    phi[0,4]  R266      -3.0999999046325684e+00
    phi[0,4]  R267      -3.0999999046325684e+00
    phi[0,4]  R268      -2.5699999332427979e+00
    phi[0,4]  R269      -2.5699999332427979e+00
    phi[0,4]  R270      -3.0999999046325684e+00
    phi[0,4]  R271      -3.0999999046325684e+00
    phi[0,4]  R272      -2.0899999141693115e+00
    phi[0,4]  R273      -2.0899999141693115e+00
    phi[0,4]  R274      -3.0999999046325684e+00
    phi[0,4]  R275      -3.0999999046325684e+00
    phi[0,4]  R276      0.625244677066803
    phi[0,4]  R277      1.2717968225479126e+00
    phi[0,4]  R278      3.3309084177017212e-01
    phi[0,4]  R279      0.686057984828949
    phi[0,4]  R280      1.6004391908645630e+00
    phi[0,4]  R281      2.2717559337615967e+00
    phi[0,4]  R282      -3.1097415089607239e-01
    phi[0,4]  R283      1.9003097712993622e-01
    phi[0,4]  R284      1.7814581394195557e+00
    phi[0,4]  R285      6.2946307659149170e-01
    phi[0,4]  R286      -2.1473641395568848e+00
    phi[0,4]  R287      -1.5435588359832764e+00
    phi[0,4]  R288      -2.9351737499237061e+00
    phi[0,4]  R289      -6.6800886392593384e-01
    phi[0,4]  R290      -1.5970200300216675e+00
    phi[0,4]  R291      7.4499297142028809e-01
    phi[0,4]  R292      5.5260056257247925e-01
    phi[0,4]  R293      -9.7976565361022949e-01
    phi[0,4]  R294      2.6851642131805420e-01
    phi[0,4]  R295      4.7060213983058929e-02
    phi[0,4]  R296      -2.1756343841552734e+00
    phi[0,4]  R297      -2.8722872734069824e+00
    phi[0,4]  R298      -2.3372904956340790e-01
    phi[0,4]  R299      -1.1735140085220337e+00
    phi[0,4]  R300      -1.2816771268844604e+00
    phi[0,4]  R301      -1.1608783155679703e-01
    phi[0,4]  R302      3.8702431321144104e-01
    phi[0,4]  R303      7.9299086332321167e-01
    phi[0,4]  R304      -5.5382376909255981e-01
    phi[0,4]  R305      2.4207285046577454e-01
    phi[0,4]  R306      1.2096215486526489e+00
    phi[0,4]  R307      -1.1823527812957764e+00
    phi[0,4]  R308      -7.6700264215469360e-01
    phi[0,4]  R309      -5.6112051010131836e-01
    phi[0,4]  R310      5.2405405044555664e-01
    phi[0,4]  R311      -1.2267128229141235e+00
    phi[0,4]  R312      -1.2640870809555054e+00
    phi[0,4]  R313      -1.1300996541976929e+00
    phi[0,4]  R314      -2.1962814331054688e+00
    phi[0,4]  R315      -1.0897940397262573e+00
    phi[0,4]  R316      1.1150593757629395e+00
    phi[0,4]  R317      1.2419869899749756e+00
    phi[0,4]  R318      0.728791356086731
    phi[0,4]  R319      7.6842325925827026e-01
    phi[0,4]  R320      2.0779460668563843e-02
    phi[0,4]  R321      2.6512444019317627e-01
    phi[0,4]  R322      1.8616312742233276e+00
    phi[0,4]  R323      1.28358793258667
    phi[0,4]  R324      -1.3091965913772583e+00
    phi[0,4]  R325      -1.7219940423965454e+00
    phi[0,4]  R326      -3.5932448506355286e-01
    phi[0,4]  R327      -2.9508392810821533e+00
    phi[0,4]  R328      -2.7252867221832275e+00
    phi[0,4]  R329      -2.0521202087402344e+00
    phi[0,4]  R330      -2.5044696331024170e+00
    phi[0,4]  R331      3.2158738374710083e-01
    phi[0,4]  R332      2.6838254928588867e-01
    phi[0,4]  R333      -1.4843361377716064e+00
    phi[0,4]  R334      -1.2136816978454590e+00
    phi[4,0]  R0        -1
    phi[4,0]  R36       1
    phi[4,0]  R37       1
    phi[4,0]  R335      -3.0999999046325684e+00
    phi[4,0]  R336      -3.0999999046325684e+00
    phi[4,0]  R337      -2.2400000095367432e+00
    phi[4,0]  R338      -2.2400000095367432e+00
    phi[4,0]  R339      -3.0999999046325684e+00
    phi[4,0]  R340      -3.0999999046325684e+00
    phi[4,0]  R341      -2.5699999332427979e+00
    phi[4,0]  R342      -2.5699999332427979e+00
    phi[4,0]  R343      -3.0999999046325684e+00
    phi[4,0]  R344      -3.0999999046325684e+00
    phi[4,0]  R345      -2.0899999141693115e+00
    phi[4,0]  R346      -2.0899999141693115e+00
    phi[4,0]  R347      -3.0999999046325684e+00
    phi[4,0]  R348      -3.0999999046325684e+00
    phi[4,0]  R349      1.1150593757629395e+00
    phi[4,0]  R350      3.3309084177017212e-01
    phi[4,0]  R351      1.2419869899749756e+00
    phi[4,0]  R352      0.728791356086731
    phi[4,0]  R353      7.6842325925827026e-01
    phi[4,0]  R354      2.0779460668563843e-02
    phi[4,0]  R355      2.6512444019317627e-01
    phi[4,0]  R356      1.8616312742233276e+00
    phi[4,0]  R357      1.28358793258667
    phi[4,0]  R358      -1.3091965913772583e+00
    phi[4,0]  R359      -1.7219940423965454e+00
    phi[4,0]  R360      -3.5932448506355286e-01
    phi[4,0]  R361      -2.9508392810821533e+00
    phi[4,0]  R362      -2.7252867221832275e+00
    phi[4,0]  R363      -2.0521202087402344e+00
    phi[4,0]  R364      -2.5044696331024170e+00
    phi[4,0]  R365      3.2158738374710083e-01
    phi[4,0]  R366      2.6838254928588867e-01
    phi[4,0]  R367      -1.4843361377716064e+00
    phi[4,0]  R368      -1.2136816978454590e+00
    phi[4,0]  R369      0.625244677066803
    phi[4,0]  R370      1.2717968225479126e+00
    phi[4,0]  R371      0.686057984828949
    phi[4,0]  R372      1.6004391908645630e+00
    phi[4,0]  R373      2.2717559337615967e+00
    phi[4,0]  R374      -3.1097415089607239e-01
    phi[4,0]  R375      1.9003097712993622e-01
    phi[4,0]  R376      1.7814581394195557e+00
    phi[4,0]  R377      6.2946307659149170e-01
    phi[4,0]  R378      -2.1473641395568848e+00
    phi[4,0]  R379      -1.5435588359832764e+00
    phi[4,0]  R380      -2.9351737499237061e+00
    phi[4,0]  R381      -6.6800886392593384e-01
    phi[4,0]  R382      -1.5970200300216675e+00
    phi[4,0]  R383      7.4499297142028809e-01
    phi[4,0]  R384      5.5260056257247925e-01
    phi[4,0]  R385      -9.7976565361022949e-01
    phi[4,0]  R386      2.6851642131805420e-01
    phi[4,0]  R387      4.7060213983058929e-02
    phi[4,0]  R388      -2.1756343841552734e+00
    phi[4,0]  R389      -2.8722872734069824e+00
    phi[4,0]  R390      -2.3372904956340790e-01
    phi[4,0]  R391      -1.1735140085220337e+00
    phi[4,0]  R392      -1.2816771268844604e+00
    phi[4,0]  R393      -1.1608783155679703e-01
    phi[4,0]  R394      3.8702431321144104e-01
    phi[4,0]  R395      7.9299086332321167e-01
    phi[4,0]  R396      -5.5382376909255981e-01
    phi[4,0]  R397      2.4207285046577454e-01
    phi[4,0]  R398      1.2096215486526489e+00
    phi[4,0]  R399      -1.1823527812957764e+00
    phi[4,0]  R400      -7.6700264215469360e-01
    phi[4,0]  R401      -5.6112051010131836e-01
    phi[4,0]  R402      5.2405405044555664e-01
    phi[4,0]  R403      -1.2267128229141235e+00
    phi[4,0]  R404      -1.2640870809555054e+00
    phi[4,0]  R405      -1.1300996541976929e+00
    phi[4,0]  R406      -2.1962814331054688e+00
    phi[4,0]  R407      -1.0897940397262573e+00
    phi[8,0]  R0        -1
    phi[8,0]  R2        7.0228414596440913e-02
    phi[8,0]  R3        5.4910706062212711e-02
    phi[8,0]  R4        2.0952565097815068e-01
    phi[8,0]  R5        -1.8869161085578066e+00
    phi[8,0]  R6        -6.5481283780954147e-01
    phi[8,0]  R7        -1.8866424625401128e+00
    phi[8,0]  R8        2.9328268902393275e+00
    phi[8,0]  R72       1
    phi[8,0]  R408      -3.1702283192290093e+00
    phi[8,0]  R409      -3.0297714900361274e+00
    phi[8,0]  R410      -2.2949107155989559e+00
    phi[8,0]  R411      -2.1850893034745305e+00
    phi[8,0]  R412      -3.3095255556107190e+00
    phi[8,0]  R413      -2.8904742536544177e+00
    phi[8,0]  R414      -6.8308382468499129e-01
    phi[8,0]  R415      -4.4569160418006044e+00
    phi[8,0]  R416      -2.4451870668230269e+00
    phi[8,0]  R417      -3.75481274244211
    phi[8,0]  R418      -2.0335745162919872e-01
    phi[8,0]  R419      -3.9766423767094246e+00
    phi[8,0]  R420      -6.0328267948718963e+00
    phi[8,0]  R421      -1.6717301439324084e-01
    phi[8,0]  R422      -2.6480394786351003e-02
    phi[8,0]  R423      -2.7982491760093708e-02
    phi[8,0]  R424      -2.9011516916215285e-02
    phi[8,0]  R425      -9.5658514051146448e-02
    phi[8,0]  R426      -1.2441308384502392e-01
    phi[8,0]  R427      -1.5996070317608613e-01
    phi[8,0]  R428      -1.7223259999807838e-01
    phi[8,0]  R429      -1.7755494315958242e-01
    phi[8,0]  R430      -1.9970391359648154e-01
    phi[8,0]  R431      -4.3874476754337444e-01
    phi[8,0]  R432      -1.4354281407725367e-01
    phi[8,0]  R433      -1.9853311896203651e-01
    phi[8,0]  R434      -2.2688642458489650e-01
    phi[8,0]  R435      -3.8337723533244139e-01
    phi[8,0]  R436      -3.8789866002414475e-01
    phi[8,0]  R437      -3.9606328667900592e-01
    phi[8,0]  R438      -4.0105320335199290e-01
    phi[8,0]  R439      -4.1029512956138758e-01
    phi[8,0]  R440      -4.1044225976825044e-01
    phi[8,0]  R441      -4.1778625951730680e-01
    phi[8,0]  R442      -9.4355143334007519e-02
    phi[8,0]  R443      -1.0572827534300666e-01
    phi[8,0]  R444      -1.4263022285996141e-01
    phi[8,0]  R445      -1.8409716143538146e-01
    phi[8,0]  R446      -2.3631665156499659e-01
    phi[8,0]  R447      -3.3494464993364803e-01
    phi[8,0]  R448      -3.5073732336985186e-01
    phi[8,0]  R449      -3.5452353054609564e-01
    phi[8,0]  R450      -3.6220306504703248e-01
    phi[8,0]  R451      -3.8174465428463611e-01
    phi[8,0]  R452      -1.1416673721652493e-01
    phi[8,0]  R453      -1.5890555707740917e-01
    phi[8,0]  R454      -1.6819494582153971e-01
    phi[8,0]  R455      -3.4320809207536407e-01
    phi[8,0]  R456      -3.5653004475921235e-01
    phi[8,0]  R457      -4.3302844247647521e-01
    phi[8,0]  R458      -4.4077358513061404e-01
    phi[8,0]  R459      -4.4710353295035643e-01
    phi[8,0]  R460      -4.5018566839792573e-01
    phi[8,0]  R461      -2.0774369018721965e+00
    phi[1,2]  R9        1
    phi[1,2]  R10       1
    phi[1,2]  R18       -1
    phi[1,2]  R462      -3.0999999046325684e+00
    phi[1,2]  R463      -3.0999999046325684e+00
    phi[1,2]  R464      -2.2400000095367432e+00
    phi[1,2]  R465      -2.2400000095367432e+00
    phi[1,2]  R466      -3.0999999046325684e+00
    phi[1,2]  R467      -3.0999999046325684e+00
    phi[1,2]  R468      -2.5699999332427979e+00
    phi[1,2]  R469      -2.5699999332427979e+00
    phi[1,2]  R470      -3.0999999046325684e+00
    phi[1,2]  R471      -3.0999999046325684e+00
    phi[1,2]  R472      -2.0899999141693115e+00
    phi[1,2]  R473      -2.0899999141693115e+00
    phi[1,2]  R474      -3.0999999046325684e+00
    phi[1,2]  R475      -3.0999999046325684e+00
    phi[1,2]  R476      1.9534587860107422e+00
    phi[1,2]  R477      1.2907648086547852e+00
    phi[1,2]  R478      -8.8761484622955322e-01
    phi[1,2]  R479      1.9785450696945190e+00
    phi[1,2]  R480      4.7387224435806274e-01
    phi[1,2]  R481      -0.0670148953795433
    phi[1,2]  R482      4.6802043914794922e-01
    phi[1,2]  R483      -2.7090033888816833e-01
    phi[1,2]  R484      -5.6464749574661255e-01
    phi[1,2]  R485      -0.398283988237381
    phi[1,2]  R486      -4.4524499773979187e-01
    phi[1,2]  R487      7.5308001041412354e-01
    phi[1,2]  R488      -1.7003352642059326e+00
    phi[1,2]  R489      -1.8118373155593872e+00
    phi[1,2]  R490      -1.0007159709930420e+00
    phi[1,2]  R491      -1.8160146474838257e+00
    phi[1,2]  R492      -1.0122696161270142e+00
    phi[1,2]  R493      -1.3669914007186890e+00
    phi[1,2]  R494      -2.6228461265563965e+00
    phi[1,2]  R495      -2.7332201004028320e+00
    phi[1,2]  R496      -4.3170168995857239e-01
    phi[1,2]  R497      -2.0487210154533386e-01
    phi[1,2]  R498      2.6822918653488159e-01
    phi[1,2]  R499      -1.5420988798141479e+00
    phi[1,2]  R500      -0.587051272392273
    phi[1,2]  R501      3.0129665508866310e-02
    phi[1,2]  R502      -1.9064785242080688e+00
    phi[1,2]  R503      -1.1628345251083374e+00
    phi[1,2]  R504      -3.7289586663246155e-01
    phi[1,2]  R505      -2.0391874313354492e+00
    phi[1,2]  R506      1.6316741704940796e-02
    phi[1,2]  R507      6.3646368682384491e-02
    phi[1,2]  R508      -7.2649228572845459e-01
    phi[1,2]  R509      -8.7619185447692871e-01
    phi[1,2]  R510      -2.70692777633667
    phi[1,2]  R511      -3.1485168933868408e+00
    phi[1,2]  R512      -3.2671751976013184e+00
    phi[1,2]  R513      -2.1625380516052246e+00
    phi[1,2]  R514      -2.1425621509552
    phi[1,2]  R515      -2.2223665714263916e+00
    phi[1,2]  R516      1.3047358989715576e+00
    phi[1,2]  R517      4.1172495484352112e-01
    phi[1,2]  R518      8.7909883260726929e-01
    phi[1,2]  R519      4.6104875206947327e-01
    phi[1,2]  R520      4.1273573040962219e-01
    phi[1,2]  R521      5.1101166009902954e-01
    phi[1,2]  R522      7.1229869127273560e-01
    phi[1,2]  R523      2.3374792933464050e-01
    phi[1,2]  R524      1.2030222415924072e+00
    phi[1,2]  R525      1.1831997334957123e-01
    phi[1,2]  R526      -2.6728730201721191e+00
    phi[1,2]  R527      -1.4288252592086792e+00
    phi[1,2]  R528      -1.0392203330993652e+00
    phi[1,2]  R529      -1.0590454339981079e+00
    phi[1,2]  R530      -7.7259004116058350e-01
    phi[1,2]  R531      2.3839337751269341e-02
    phi[1,2]  R532      3.3910638093948364e-01
    phi[1,2]  R533      -2.0534980297088623e+00
    phi[1,2]  R534      5.3213603794574738e-02
    phi[1,2]  R535      -1.5161970853805542e+00
    phi[1,2]  R536      -2.0537593364715576e+00
    phi[1,2]  R537      -1.8724329471588135e+00
    phi[1,2]  R538      -1.5916792154312134e+00
    phi[1,2]  R539      -2.4505271911621094e+00
    phi[1,2]  R540      -1.6712915897369385e+00
    phi[1,2]  R541      -1.6788634061813354e+00
    phi[1,2]  R542      -2.6346435546875
    phi[1,2]  R543      -1.7578318119049072e+00
    phi[1,2]  R544      -1.2436305284500122e+00
    phi[1,2]  R545      -1.2571961879730225e+00
    phi[1,2]  R546      -2.5362503528594971e+00
    phi[1,2]  R547      -2.1557533740997314e+00
    phi[1,2]  R548      -2.1820735931396484e+00
    phi[1,2]  R549      1.0436213016510010e+00
    phi[1,2]  R550      4.4097694754600525e-01
    phi[1,2]  R551      -2.1269376277923584e+00
    phi[1,2]  R552      4.0015664696693420e-01
    phi[1,2]  R553      -1.0450927019119263e+00
    phi[1,2]  R554      -9.4470000267028809e-01
    phi[1,2]  R555      -1.7921125888824463e+00
    phi[1,2]  R556      -2.7738664150238037e+00
    phi[1,2]  R557      6.2504762411117554e-01
    phi[1,2]  R558      -2.6095008850097656e+00
    phi[1,2]  R559      1.8816313743591309e+00
    phi[1,2]  R560      3.9819464087486267e-01
    phi[1,2]  R561      -1.5890978574752808e+00
    phi[1,2]  R562      -1.2044396400451660e+00
    phi[1,2]  R563      -2.2337517738342285e+00
    phi[1,2]  R564      5.8172410726547241e-01
    phi[1,2]  R565      -2.0298480987548828e-01
    phi[1,2]  R566      -1.3787635564804077e+00
    phi[1,2]  R567      -2.4265046119689941e+00
    phi[1,2]  R568      1.5516848564147949e+00
    phi[1,2]  R569      1.4242736995220184e-01
    phi[1,2]  R570      -1.7214224338531494e+00
    phi[1,2]  R571      7.5395369529724121e-01
    phi[1,2]  R572      -1.8111455440521240e+00
    phi[1,2]  R573      -2.1221132278442383e+00
    phi[1,2]  R574      -1.8514742851257324e+00
    phi[1,2]  R575      -1.4006950855255127e+00
    phi[1,2]  R576      -1.8294088840484619e+00
    phi[1,2]  R577      -0.584247350692749
    phi[1,2]  R578      1.3262991905212402e+00
    phi[1,2]  R579      1.0354204177856445e+00
    phi[1,2]  R580      -1.4866268634796143e-01
    phi[1,2]  R581      -1.0482614040374756e+00
    phi[1,2]  R582      -6.1557716131210327e-01
    phi[1,2]  R583      -6.5056753158569336e-01
    phi[1,2]  R584      8.7806200981140137e-01
    phi[1,2]  R585      -1.06460702419281
    phi[2,1]  R9        -1
    phi[2,1]  R18       1
    phi[2,1]  R19       1
    phi[2,1]  R586      -3.0999999046325684e+00
    phi[2,1]  R587      -3.0999999046325684e+00
    phi[2,1]  R588      -2.2400000095367432e+00
    phi[2,1]  R589      -2.2400000095367432e+00
    phi[2,1]  R590      -3.0999999046325684e+00
    phi[2,1]  R591      -3.0999999046325684e+00
    phi[2,1]  R592      -2.5699999332427979e+00
    phi[2,1]  R593      -2.5699999332427979e+00
    phi[2,1]  R594      -3.0999999046325684e+00
    phi[2,1]  R595      -3.0999999046325684e+00
    phi[2,1]  R596      -2.0899999141693115e+00
    phi[2,1]  R597      -2.0899999141693115e+00
    phi[2,1]  R598      -3.0999999046325684e+00
    phi[2,1]  R599      -3.0999999046325684e+00
    phi[2,1]  R600      1.3047358989715576e+00
    phi[2,1]  R601      4.1172495484352112e-01
    phi[2,1]  R602      8.7909883260726929e-01
    phi[2,1]  R603      4.6104875206947327e-01
    phi[2,1]  R604      4.1273573040962219e-01
    phi[2,1]  R605      5.1101166009902954e-01
    phi[2,1]  R606      7.1229869127273560e-01
    phi[2,1]  R607      2.3374792933464050e-01
    phi[2,1]  R608      1.2030222415924072e+00
    phi[2,1]  R609      1.1831997334957123e-01
    phi[2,1]  R610      -2.6728730201721191e+00
    phi[2,1]  R611      -1.4288252592086792e+00
    phi[2,1]  R612      -1.0392203330993652e+00
    phi[2,1]  R613      -1.0590454339981079e+00
    phi[2,1]  R614      -7.7259004116058350e-01
    phi[2,1]  R615      2.3839337751269341e-02
    phi[2,1]  R616      3.3910638093948364e-01
    phi[2,1]  R617      -2.0534980297088623e+00
    phi[2,1]  R618      5.3213603794574738e-02
    phi[2,1]  R619      -1.5161970853805542e+00
    phi[2,1]  R620      -2.0537593364715576e+00
    phi[2,1]  R621      -1.8724329471588135e+00
    phi[2,1]  R622      -1.5916792154312134e+00
    phi[2,1]  R623      -2.4505271911621094e+00
    phi[2,1]  R624      -1.6712915897369385e+00
    phi[2,1]  R625      -1.6788634061813354e+00
    phi[2,1]  R626      -2.6346435546875
    phi[2,1]  R627      -1.7578318119049072e+00
    phi[2,1]  R628      -1.2436305284500122e+00
    phi[2,1]  R629      -1.2571961879730225e+00
    phi[2,1]  R630      -2.5362503528594971e+00
    phi[2,1]  R631      -2.1557533740997314e+00
    phi[2,1]  R632      -2.1820735931396484e+00
    phi[2,1]  R633      1.0436213016510010e+00
    phi[2,1]  R634      4.4097694754600525e-01
    phi[2,1]  R635      -2.1269376277923584e+00
    phi[2,1]  R636      4.0015664696693420e-01
    phi[2,1]  R637      -1.0450927019119263e+00
    phi[2,1]  R638      -9.4470000267028809e-01
    phi[2,1]  R639      -1.7921125888824463e+00
    phi[2,1]  R640      -2.7738664150238037e+00
    phi[2,1]  R641      6.2504762411117554e-01
    phi[2,1]  R642      -2.6095008850097656e+00
    phi[2,1]  R643      1.8816313743591309e+00
    phi[2,1]  R644      3.9819464087486267e-01
    phi[2,1]  R645      -1.5890978574752808e+00
    phi[2,1]  R646      -1.2044396400451660e+00
    phi[2,1]  R647      -2.2337517738342285e+00
    phi[2,1]  R648      5.8172410726547241e-01
    phi[2,1]  R649      -2.0298480987548828e-01
    phi[2,1]  R650      -1.3787635564804077e+00
    phi[2,1]  R651      -2.4265046119689941e+00
    phi[2,1]  R652      1.5516848564147949e+00
    phi[2,1]  R653      1.4242736995220184e-01
    phi[2,1]  R654      -1.7214224338531494e+00
    phi[2,1]  R655      7.5395369529724121e-01
    phi[2,1]  R656      -1.8111455440521240e+00
    phi[2,1]  R657      -2.1221132278442383e+00
    phi[2,1]  R658      -1.8514742851257324e+00
    phi[2,1]  R659      -1.4006950855255127e+00
    phi[2,1]  R660      -1.8294088840484619e+00
    phi[2,1]  R661      -0.584247350692749
    phi[2,1]  R662      1.3262991905212402e+00
    phi[2,1]  R663      1.0354204177856445e+00
    phi[2,1]  R664      -1.4866268634796143e-01
    phi[2,1]  R665      -1.0482614040374756e+00
    phi[2,1]  R666      -6.1557716131210327e-01
    phi[2,1]  R667      -6.5056753158569336e-01
    phi[2,1]  R668      8.7806200981140137e-01
    phi[2,1]  R669      -1.06460702419281
    phi[2,1]  R670      1.9534587860107422e+00
    phi[2,1]  R671      1.2907648086547852e+00
    phi[2,1]  R672      -8.8761484622955322e-01
    phi[2,1]  R673      1.9785450696945190e+00
    phi[2,1]  R674      4.7387224435806274e-01
    phi[2,1]  R675      -0.0670148953795433
    phi[2,1]  R676      4.6802043914794922e-01
    phi[2,1]  R677      -2.7090033888816833e-01
    phi[2,1]  R678      -5.6464749574661255e-01
    phi[2,1]  R679      -0.398283988237381
    phi[2,1]  R680      -4.4524499773979187e-01
    phi[2,1]  R681      7.5308001041412354e-01
    phi[2,1]  R682      -1.7003352642059326e+00
    phi[2,1]  R683      -1.8118373155593872e+00
    phi[2,1]  R684      -1.0007159709930420e+00
    phi[2,1]  R685      -1.8160146474838257e+00
    phi[2,1]  R686      -1.0122696161270142e+00
    phi[2,1]  R687      -1.3669914007186890e+00
    phi[2,1]  R688      -2.6228461265563965e+00
    phi[2,1]  R689      -2.7332201004028320e+00
    phi[2,1]  R690      -4.3170168995857239e-01
    phi[2,1]  R691      -2.0487210154533386e-01
    phi[2,1]  R692      2.6822918653488159e-01
    phi[2,1]  R693      -1.5420988798141479e+00
    phi[2,1]  R694      -0.587051272392273
    phi[2,1]  R695      3.0129665508866310e-02
    phi[2,1]  R696      -1.9064785242080688e+00
    phi[2,1]  R697      -1.1628345251083374e+00
    phi[2,1]  R698      -3.7289586663246155e-01
    phi[2,1]  R699      -2.0391874313354492e+00
    phi[2,1]  R700      1.6316741704940796e-02
    phi[2,1]  R701      6.3646368682384491e-02
    phi[2,1]  R702      -7.2649228572845459e-01
    phi[2,1]  R703      -8.7619185447692871e-01
    phi[2,1]  R704      -2.70692777633667
    phi[2,1]  R705      -3.1485168933868408e+00
    phi[2,1]  R706      -3.2671751976013184e+00
    phi[2,1]  R707      -2.1625380516052246e+00
    phi[2,1]  R708      -2.1425621509552
    phi[2,1]  R709      -2.2223665714263916e+00
    phi[1,5]  R9        1
    phi[1,5]  R10       1
    phi[1,5]  R45       -1
    phi[1,5]  R710      -3.0999999046325684e+00
    phi[1,5]  R711      -3.0999999046325684e+00
    phi[1,5]  R712      -2.2400000095367432e+00
    phi[1,5]  R713      -2.2400000095367432e+00
    phi[1,5]  R714      -3.0999999046325684e+00
    phi[1,5]  R715      -3.0999999046325684e+00
    phi[1,5]  R716      -2.5699999332427979e+00
    phi[1,5]  R717      -2.5699999332427979e+00
    phi[1,5]  R718      -3.0999999046325684e+00
    phi[1,5]  R719      -3.0999999046325684e+00
    phi[1,5]  R720      -2.0899999141693115e+00
    phi[1,5]  R721      -2.0899999141693115e+00
    phi[1,5]  R722      -3.0999999046325684e+00
    phi[1,5]  R723      -3.0999999046325684e+00
    phi[1,5]  R724      1.9534587860107422e+00
    phi[1,5]  R725      1.2907648086547852e+00
    phi[1,5]  R726      -8.8761484622955322e-01
    phi[1,5]  R727      1.9785450696945190e+00
    phi[1,5]  R728      4.7387224435806274e-01
    phi[1,5]  R729      -0.0670148953795433
    phi[1,5]  R730      4.6802043914794922e-01
    phi[1,5]  R731      -2.7090033888816833e-01
    phi[1,5]  R732      -5.6464749574661255e-01
    phi[1,5]  R733      -0.398283988237381
    phi[1,5]  R734      -4.4524499773979187e-01
    phi[1,5]  R735      7.5308001041412354e-01
    phi[1,5]  R736      -1.7003352642059326e+00
    phi[1,5]  R737      -1.8118373155593872e+00
    phi[1,5]  R738      -1.0007159709930420e+00
    phi[1,5]  R739      -1.8160146474838257e+00
    phi[1,5]  R740      -1.0122696161270142e+00
    phi[1,5]  R741      -1.3669914007186890e+00
    phi[1,5]  R742      -2.6228461265563965e+00
    phi[1,5]  R743      -2.7332201004028320e+00
    phi[1,5]  R744      -4.3170168995857239e-01
    phi[1,5]  R745      -2.0487210154533386e-01
    phi[1,5]  R746      2.6822918653488159e-01
    phi[1,5]  R747      -1.5420988798141479e+00
    phi[1,5]  R748      -0.587051272392273
    phi[1,5]  R749      3.0129665508866310e-02
    phi[1,5]  R750      -1.9064785242080688e+00
    phi[1,5]  R751      -1.1628345251083374e+00
    phi[1,5]  R752      -3.7289586663246155e-01
    phi[1,5]  R753      -2.0391874313354492e+00
    phi[1,5]  R754      1.6316741704940796e-02
    phi[1,5]  R755      6.3646368682384491e-02
    phi[1,5]  R756      -7.2649228572845459e-01
    phi[1,5]  R757      -8.7619185447692871e-01
    phi[1,5]  R758      -2.70692777633667
    phi[1,5]  R759      -3.1485168933868408e+00
    phi[1,5]  R760      -3.2671751976013184e+00
    phi[1,5]  R761      -2.1625380516052246e+00
    phi[1,5]  R762      -2.1425621509552
    phi[1,5]  R763      -2.2223665714263916e+00
    phi[1,5]  R764      9.6797335147857666e-01
    phi[1,5]  R765      1.9853407144546509e+00
    phi[1,5]  R766      9.9929773807525635e-01
    phi[1,5]  R767      1.0713571310043335e+00
    phi[1,5]  R768      4.4302535057067871e-01
    phi[1,5]  R769      2.5828036665916443e-01
    phi[1,5]  R770      1.4327461719512939e+00
    phi[1,5]  R771      2.5175604224205017e-01
    phi[1,5]  R772      7.7759909629821777e-01
    phi[1,5]  R773      4.3319219350814819e-01
    phi[1,5]  R774      -1.9167469739913940e+00
    phi[1,5]  R775      -1.6906956434249878e+00
    phi[1,5]  R776      -1.6558649539947510e+00
    phi[1,5]  R777      -1.5378329753875732e+00
    phi[1,5]  R778      -2.2091202735900879e+00
    phi[1,5]  R779      -1.7884228229522705e+00
    phi[1,5]  R780      -5.3868192434310913e-01
    phi[1,5]  R781      -6.3095498085021973e-01
    phi[1,5]  R782      -9.2647832632064819e-01
    phi[1,5]  R783      -1.09926438331604
    phi[1,5]  R784      -9.4597154855728149e-01
    phi[1,5]  R785      -4.6445050835609436e-01
    phi[1,5]  R786      -7.9716169834136963e-01
    phi[1,5]  R787      -9.3050795793533325e-01
    phi[1,5]  R788      -1.3097333908081055e+00
    phi[1,5]  R789      -1.0196890830993652e+00
    phi[1,5]  R790      -1.7185614109039307e+00
    phi[1,5]  R791      -1.7277870327234268e-02
    phi[1,5]  R792      -3.7796512246131897e-01
    phi[1,5]  R793      7.0352292060852051e-01
    phi[1,5]  R794      9.8357729613780975e-02
    phi[1,5]  R795      -1.1302938461303711e+00
    phi[1,5]  R796      -6.9745355844497681e-01
    phi[1,5]  R797      -1.2573032379150391e+00
    phi[1,5]  R798      -1.4541997909545898e+00
    phi[1,5]  R799      -2.13244891166687
    phi[5,1]  R9        -1
    phi[5,1]  R45       1
    phi[5,1]  R46       1
    phi[5,1]  R800      -3.0999999046325684e+00
    phi[5,1]  R801      -3.0999999046325684e+00
    phi[5,1]  R802      -2.2400000095367432e+00
    phi[5,1]  R803      -2.2400000095367432e+00
    phi[5,1]  R804      -3.0999999046325684e+00
    phi[5,1]  R805      -3.0999999046325684e+00
    phi[5,1]  R806      -2.5699999332427979e+00
    phi[5,1]  R807      -2.5699999332427979e+00
    phi[5,1]  R808      -3.0999999046325684e+00
    phi[5,1]  R809      -3.0999999046325684e+00
    phi[5,1]  R810      -2.0899999141693115e+00
    phi[5,1]  R811      -2.0899999141693115e+00
    phi[5,1]  R812      -3.0999999046325684e+00
    phi[5,1]  R813      -3.0999999046325684e+00
    phi[5,1]  R814      9.6797335147857666e-01
    phi[5,1]  R815      1.9853407144546509e+00
    phi[5,1]  R816      9.9929773807525635e-01
    phi[5,1]  R817      1.0713571310043335e+00
    phi[5,1]  R818      4.4302535057067871e-01
    phi[5,1]  R819      2.5828036665916443e-01
    phi[5,1]  R820      1.4327461719512939e+00
    phi[5,1]  R821      2.5175604224205017e-01
    phi[5,1]  R822      7.7759909629821777e-01
    phi[5,1]  R823      4.3319219350814819e-01
    phi[5,1]  R824      -1.9167469739913940e+00
    phi[5,1]  R825      -1.6906956434249878e+00
    phi[5,1]  R826      -1.6558649539947510e+00
    phi[5,1]  R827      -1.5378329753875732e+00
    phi[5,1]  R828      -2.2091202735900879e+00
    phi[5,1]  R829      -1.7884228229522705e+00
    phi[5,1]  R830      -5.3868192434310913e-01
    phi[5,1]  R831      -6.3095498085021973e-01
    phi[5,1]  R832      -9.2647832632064819e-01
    phi[5,1]  R833      -1.09926438331604
    phi[5,1]  R834      -9.4597154855728149e-01
    phi[5,1]  R835      -4.6445050835609436e-01
    phi[5,1]  R836      -7.9716169834136963e-01
    phi[5,1]  R837      -9.3050795793533325e-01
    phi[5,1]  R838      -1.3097333908081055e+00
    phi[5,1]  R839      -1.0196890830993652e+00
    phi[5,1]  R840      -1.7185614109039307e+00
    phi[5,1]  R841      -1.7277870327234268e-02
    phi[5,1]  R842      -3.7796512246131897e-01
    phi[5,1]  R843      7.0352292060852051e-01
    phi[5,1]  R844      9.8357729613780975e-02
    phi[5,1]  R845      -1.1302938461303711e+00
    phi[5,1]  R846      -6.9745355844497681e-01
    phi[5,1]  R847      -1.2573032379150391e+00
    phi[5,1]  R848      -1.4541997909545898e+00
    phi[5,1]  R849      -2.13244891166687
    phi[5,1]  R850      1.9534587860107422e+00
    phi[5,1]  R851      1.2907648086547852e+00
    phi[5,1]  R852      -8.8761484622955322e-01
    phi[5,1]  R853      1.9785450696945190e+00
    phi[5,1]  R854      4.7387224435806274e-01
    phi[5,1]  R855      -0.0670148953795433
    phi[5,1]  R856      4.6802043914794922e-01
    phi[5,1]  R857      -2.7090033888816833e-01
    phi[5,1]  R858      -5.6464749574661255e-01
    phi[5,1]  R859      -0.398283988237381
    phi[5,1]  R860      -4.4524499773979187e-01
    phi[5,1]  R861      7.5308001041412354e-01
    phi[5,1]  R862      -1.7003352642059326e+00
    phi[5,1]  R863      -1.8118373155593872e+00
    phi[5,1]  R864      -1.0007159709930420e+00
    phi[5,1]  R865      -1.8160146474838257e+00
    phi[5,1]  R866      -1.0122696161270142e+00
    phi[5,1]  R867      -1.3669914007186890e+00
    phi[5,1]  R868      -2.6228461265563965e+00
    phi[5,1]  R869      -2.7332201004028320e+00
    phi[5,1]  R870      -4.3170168995857239e-01
    phi[5,1]  R871      -2.0487210154533386e-01
    phi[5,1]  R872      2.6822918653488159e-01
    phi[5,1]  R873      -1.5420988798141479e+00
    phi[5,1]  R874      -0.587051272392273
    phi[5,1]  R875      3.0129665508866310e-02
    phi[5,1]  R876      -1.9064785242080688e+00
    phi[5,1]  R877      -1.1628345251083374e+00
    phi[5,1]  R878      -3.7289586663246155e-01
    phi[5,1]  R879      -2.0391874313354492e+00
    phi[5,1]  R880      1.6316741704940796e-02
    phi[5,1]  R881      6.3646368682384491e-02
    phi[5,1]  R882      -7.2649228572845459e-01
    phi[5,1]  R883      -8.7619185447692871e-01
    phi[5,1]  R884      -2.70692777633667
    phi[5,1]  R885      -3.1485168933868408e+00
    phi[5,1]  R886      -3.2671751976013184e+00
    phi[5,1]  R887      -2.1625380516052246e+00
    phi[5,1]  R888      -2.1425621509552
    phi[5,1]  R889      -2.2223665714263916e+00
    phi[2,3]  R18       1
    phi[2,3]  R19       1
    phi[2,3]  R27       -1
    phi[2,3]  R890      -3.0999999046325684e+00
    phi[2,3]  R891      -3.0999999046325684e+00
    phi[2,3]  R892      -2.2400000095367432e+00
    phi[2,3]  R893      -2.2400000095367432e+00
    phi[2,3]  R894      -3.0999999046325684e+00
    phi[2,3]  R895      -3.0999999046325684e+00
    phi[2,3]  R896      -2.5699999332427979e+00
    phi[2,3]  R897      -2.5699999332427979e+00
    phi[2,3]  R898      -3.0999999046325684e+00
    phi[2,3]  R899      -3.0999999046325684e+00
    phi[2,3]  R900      -2.0899999141693115e+00
    phi[2,3]  R901      -2.0899999141693115e+00
    phi[2,3]  R902      -3.0999999046325684e+00
    phi[2,3]  R903      -3.0999999046325684e+00
    phi[2,3]  R904      1.3047358989715576e+00
    phi[2,3]  R905      4.1172495484352112e-01
    phi[2,3]  R906      8.7909883260726929e-01
    phi[2,3]  R907      4.6104875206947327e-01
    phi[2,3]  R908      4.1273573040962219e-01
    phi[2,3]  R909      5.1101166009902954e-01
    phi[2,3]  R910      7.1229869127273560e-01
    phi[2,3]  R911      2.3374792933464050e-01
    phi[2,3]  R912      1.2030222415924072e+00
    phi[2,3]  R913      1.1831997334957123e-01
    phi[2,3]  R914      -2.6728730201721191e+00
    phi[2,3]  R915      -1.4288252592086792e+00
    phi[2,3]  R916      -1.0392203330993652e+00
    phi[2,3]  R917      -1.0590454339981079e+00
    phi[2,3]  R918      -7.7259004116058350e-01
    phi[2,3]  R919      2.3839337751269341e-02
    phi[2,3]  R920      3.3910638093948364e-01
    phi[2,3]  R921      -2.0534980297088623e+00
    phi[2,3]  R922      5.3213603794574738e-02
    phi[2,3]  R923      -1.5161970853805542e+00
    phi[2,3]  R924      -2.0537593364715576e+00
    phi[2,3]  R925      -1.8724329471588135e+00
    phi[2,3]  R926      -1.5916792154312134e+00
    phi[2,3]  R927      -2.4505271911621094e+00
    phi[2,3]  R928      -1.6712915897369385e+00
    phi[2,3]  R929      -1.6788634061813354e+00
    phi[2,3]  R930      -2.6346435546875
    phi[2,3]  R931      -1.7578318119049072e+00
    phi[2,3]  R932      -1.2436305284500122e+00
    phi[2,3]  R933      -1.2571961879730225e+00
    phi[2,3]  R934      -2.5362503528594971e+00
    phi[2,3]  R935      -2.1557533740997314e+00
    phi[2,3]  R936      -2.1820735931396484e+00
    phi[2,3]  R937      1.0436213016510010e+00
    phi[2,3]  R938      4.4097694754600525e-01
    phi[2,3]  R939      -2.1269376277923584e+00
    phi[2,3]  R940      4.0015664696693420e-01
    phi[2,3]  R941      -1.0450927019119263e+00
    phi[2,3]  R942      -9.4470000267028809e-01
    phi[2,3]  R943      -1.7921125888824463e+00
    phi[2,3]  R944      -2.7738664150238037e+00
    phi[2,3]  R945      6.2504762411117554e-01
    phi[2,3]  R946      -2.6095008850097656e+00
    phi[2,3]  R947      1.8816313743591309e+00
    phi[2,3]  R948      3.9819464087486267e-01
    phi[2,3]  R949      -1.5890978574752808e+00
    phi[2,3]  R950      -1.2044396400451660e+00
    phi[2,3]  R951      -2.2337517738342285e+00
    phi[2,3]  R952      5.8172410726547241e-01
    phi[2,3]  R953      -2.0298480987548828e-01
    phi[2,3]  R954      -1.3787635564804077e+00
    phi[2,3]  R955      -2.4265046119689941e+00
    phi[2,3]  R956      1.5516848564147949e+00
    phi[2,3]  R957      1.4242736995220184e-01
    phi[2,3]  R958      -1.7214224338531494e+00
    phi[2,3]  R959      7.5395369529724121e-01
    phi[2,3]  R960      -1.8111455440521240e+00
    phi[2,3]  R961      -2.1221132278442383e+00
    phi[2,3]  R962      -1.8514742851257324e+00
    phi[2,3]  R963      -1.4006950855255127e+00
    phi[2,3]  R964      -1.8294088840484619e+00
    phi[2,3]  R965      -0.584247350692749
    phi[2,3]  R966      1.3262991905212402e+00
    phi[2,3]  R967      1.0354204177856445e+00
    phi[2,3]  R968      -1.4866268634796143e-01
    phi[2,3]  R969      -1.0482614040374756e+00
    phi[2,3]  R970      -6.1557716131210327e-01
    phi[2,3]  R971      -6.5056753158569336e-01
    phi[2,3]  R972      8.7806200981140137e-01
    phi[2,3]  R973      -1.06460702419281
    phi[2,3]  R974      1.3132629394531250e+00
    phi[2,3]  R975      5.9209907054901123e-01
    phi[2,3]  R976      1.4335892200469971e+00
    phi[2,3]  R977      2.8268089294433594e+00
    phi[2,3]  R978      2.2504229545593262e+00
    phi[2,3]  R979      1.9293751716613770e+00
    phi[2,3]  R980      1.5463392734527588e+00
    phi[2,3]  R981      -3.1073608994483948e-01
    phi[2,3]  R982      -3.1540915369987488e-01
    phi[2,3]  R983      3.8748973608016968e-01
    phi[2,3]  R984      -1.0358899831771851e+00
    phi[2,3]  R985      -1.6490143537521362e+00
    phi[2,3]  R986      -1.7502099275588989e+00
    phi[2,3]  R987      -1.8528970479965210e+00
    phi[2,3]  R988      -0.154770627617836
    phi[2,3]  R989      0.503047525882721
    phi[2,3]  R990      -2.3411171436309814e+00
    phi[2,3]  R991      -1.5184706449508667e+00
    phi[2,3]  R992      -2.0552301406860352e+00
    phi[2,3]  R993      -3.0953278541564941e+00
    phi[2,3]  R994      -1.5549764633178711e+00
    phi[2,3]  R995      -8.9567416906356812e-01
    phi[2,3]  R996      -2.1195132732391357e+00
    phi[2,3]  R997      -1.0136455297470093e+00
    phi[2,3]  R998      -2.1495256423950195e+00
    phi[2,3]  R999      -3.9254549145698547e-01
    phi[2,3]  R1000     -1.0671377182006836e+00
    phi[2,3]  R1001     -1.8839714527130127e+00
    phi[2,3]  R1002     9.7120665013790131e-03
    phi[2,3]  R1003     -1.3727135658264160e+00
    phi[2,3]  R1004     -8.7287724018096924e-03
    phi[2,3]  R1005     -1.3634074926376343e+00
    phi[2,3]  R1006     -3.1052780151367188e-01
    phi[2,3]  R1007     6.4304918050765991e-01
    phi[2,3]  R1008     -9.6809273958206177e-01
    phi[2,3]  R1009     -5.4477047920227051e-01
    phi[2,3]  R1010     3.2963702082633972e-01
    phi[2,3]  R1011     4.5905942097306252e-03
    phi[2,3]  R1012     1.2166296243667603e+00
    phi[2,3]  R1013     5.9750485420227051e-01
    phi[3,2]  R18       -1
    phi[3,2]  R27       1
    phi[3,2]  R28       1
    phi[3,2]  R1014     -3.0999999046325684e+00
    phi[3,2]  R1015     -3.0999999046325684e+00
    phi[3,2]  R1016     -2.2400000095367432e+00
    phi[3,2]  R1017     -2.2400000095367432e+00
    phi[3,2]  R1018     -3.0999999046325684e+00
    phi[3,2]  R1019     -3.0999999046325684e+00
    phi[3,2]  R1020     -2.5699999332427979e+00
    phi[3,2]  R1021     -2.5699999332427979e+00
    phi[3,2]  R1022     -3.0999999046325684e+00
    phi[3,2]  R1023     -3.0999999046325684e+00
    phi[3,2]  R1024     -2.0899999141693115e+00
    phi[3,2]  R1025     -2.0899999141693115e+00
    phi[3,2]  R1026     -3.0999999046325684e+00
    phi[3,2]  R1027     -3.0999999046325684e+00
    phi[3,2]  R1028     1.3132629394531250e+00
    phi[3,2]  R1029     5.9209907054901123e-01
    phi[3,2]  R1030     1.4335892200469971e+00
    phi[3,2]  R1031     2.8268089294433594e+00
    phi[3,2]  R1032     2.2504229545593262e+00
    phi[3,2]  R1033     1.9293751716613770e+00
    phi[3,2]  R1034     1.5463392734527588e+00
    phi[3,2]  R1035     -3.1073608994483948e-01
    phi[3,2]  R1036     -3.1540915369987488e-01
    phi[3,2]  R1037     3.8748973608016968e-01
    phi[3,2]  R1038     -1.0358899831771851e+00
    phi[3,2]  R1039     -1.6490143537521362e+00
    phi[3,2]  R1040     -1.7502099275588989e+00
    phi[3,2]  R1041     -1.8528970479965210e+00
    phi[3,2]  R1042     -0.154770627617836
    phi[3,2]  R1043     0.503047525882721
    phi[3,2]  R1044     -2.3411171436309814e+00
    phi[3,2]  R1045     -1.5184706449508667e+00
    phi[3,2]  R1046     -2.0552301406860352e+00
    phi[3,2]  R1047     -3.0953278541564941e+00
    phi[3,2]  R1048     -1.5549764633178711e+00
    phi[3,2]  R1049     -8.9567416906356812e-01
    phi[3,2]  R1050     -2.1195132732391357e+00
    phi[3,2]  R1051     -1.0136455297470093e+00
    phi[3,2]  R1052     -2.1495256423950195e+00
    phi[3,2]  R1053     -3.9254549145698547e-01
    phi[3,2]  R1054     -1.0671377182006836e+00
    phi[3,2]  R1055     -1.8839714527130127e+00
    phi[3,2]  R1056     9.7120665013790131e-03
    phi[3,2]  R1057     -1.3727135658264160e+00
    phi[3,2]  R1058     -8.7287724018096924e-03
    phi[3,2]  R1059     -1.3634074926376343e+00
    phi[3,2]  R1060     -3.1052780151367188e-01
    phi[3,2]  R1061     6.4304918050765991e-01
    phi[3,2]  R1062     -9.6809273958206177e-01
    phi[3,2]  R1063     -5.4477047920227051e-01
    phi[3,2]  R1064     3.2963702082633972e-01
    phi[3,2]  R1065     4.5905942097306252e-03
    phi[3,2]  R1066     1.2166296243667603e+00
    phi[3,2]  R1067     5.9750485420227051e-01
    phi[3,2]  R1068     1.3047358989715576e+00
    phi[3,2]  R1069     4.1172495484352112e-01
    phi[3,2]  R1070     8.7909883260726929e-01
    phi[3,2]  R1071     4.6104875206947327e-01
    phi[3,2]  R1072     4.1273573040962219e-01
    phi[3,2]  R1073     5.1101166009902954e-01
    phi[3,2]  R1074     7.1229869127273560e-01
    phi[3,2]  R1075     2.3374792933464050e-01
    phi[3,2]  R1076     1.2030222415924072e+00
    phi[3,2]  R1077     1.1831997334957123e-01
    phi[3,2]  R1078     -2.6728730201721191e+00
    phi[3,2]  R1079     -1.4288252592086792e+00
    phi[3,2]  R1080     -1.0392203330993652e+00
    phi[3,2]  R1081     -1.0590454339981079e+00
    phi[3,2]  R1082     -7.7259004116058350e-01
    phi[3,2]  R1083     2.3839337751269341e-02
    phi[3,2]  R1084     3.3910638093948364e-01
    phi[3,2]  R1085     -2.0534980297088623e+00
    phi[3,2]  R1086     5.3213603794574738e-02
    phi[3,2]  R1087     -1.5161970853805542e+00
    phi[3,2]  R1088     -2.0537593364715576e+00
    phi[3,2]  R1089     -1.8724329471588135e+00
    phi[3,2]  R1090     -1.5916792154312134e+00
    phi[3,2]  R1091     -2.4505271911621094e+00
    phi[3,2]  R1092     -1.6712915897369385e+00
    phi[3,2]  R1093     -1.6788634061813354e+00
    phi[3,2]  R1094     -2.6346435546875
    phi[3,2]  R1095     -1.7578318119049072e+00
    phi[3,2]  R1096     -1.2436305284500122e+00
    phi[3,2]  R1097     -1.2571961879730225e+00
    phi[3,2]  R1098     -2.5362503528594971e+00
    phi[3,2]  R1099     -2.1557533740997314e+00
    phi[3,2]  R1100     -2.1820735931396484e+00
    phi[3,2]  R1101     1.0436213016510010e+00
    phi[3,2]  R1102     4.4097694754600525e-01
    phi[3,2]  R1103     -2.1269376277923584e+00
    phi[3,2]  R1104     4.0015664696693420e-01
    phi[3,2]  R1105     -1.0450927019119263e+00
    phi[3,2]  R1106     -9.4470000267028809e-01
    phi[3,2]  R1107     -1.7921125888824463e+00
    phi[3,2]  R1108     -2.7738664150238037e+00
    phi[3,2]  R1109     6.2504762411117554e-01
    phi[3,2]  R1110     -2.6095008850097656e+00
    phi[3,2]  R1111     1.8816313743591309e+00
    phi[3,2]  R1112     3.9819464087486267e-01
    phi[3,2]  R1113     -1.5890978574752808e+00
    phi[3,2]  R1114     -1.2044396400451660e+00
    phi[3,2]  R1115     -2.2337517738342285e+00
    phi[3,2]  R1116     5.8172410726547241e-01
    phi[3,2]  R1117     -2.0298480987548828e-01
    phi[3,2]  R1118     -1.3787635564804077e+00
    phi[3,2]  R1119     -2.4265046119689941e+00
    phi[3,2]  R1120     1.5516848564147949e+00
    phi[3,2]  R1121     1.4242736995220184e-01
    phi[3,2]  R1122     -1.7214224338531494e+00
    phi[3,2]  R1123     7.5395369529724121e-01
    phi[3,2]  R1124     -1.8111455440521240e+00
    phi[3,2]  R1125     -2.1221132278442383e+00
    phi[3,2]  R1126     -1.8514742851257324e+00
    phi[3,2]  R1127     -1.4006950855255127e+00
    phi[3,2]  R1128     -1.8294088840484619e+00
    phi[3,2]  R1129     -0.584247350692749
    phi[3,2]  R1130     1.3262991905212402e+00
    phi[3,2]  R1131     1.0354204177856445e+00
    phi[3,2]  R1132     -1.4866268634796143e-01
    phi[3,2]  R1133     -1.0482614040374756e+00
    phi[3,2]  R1134     -6.1557716131210327e-01
    phi[3,2]  R1135     -6.5056753158569336e-01
    phi[3,2]  R1136     8.7806200981140137e-01
    phi[3,2]  R1137     -1.06460702419281
    phi[2,6]  R18       1
    phi[2,6]  R19       1
    phi[2,6]  R54       -1
    phi[2,6]  R1138     -3.0999999046325684e+00
    phi[2,6]  R1139     -3.0999999046325684e+00
    phi[2,6]  R1140     -2.2400000095367432e+00
    phi[2,6]  R1141     -2.2400000095367432e+00
    phi[2,6]  R1142     -3.0999999046325684e+00
    phi[2,6]  R1143     -3.0999999046325684e+00
    phi[2,6]  R1144     -2.5699999332427979e+00
    phi[2,6]  R1145     -2.5699999332427979e+00
    phi[2,6]  R1146     -3.0999999046325684e+00
    phi[2,6]  R1147     -3.0999999046325684e+00
    phi[2,6]  R1148     -2.0899999141693115e+00
    phi[2,6]  R1149     -2.0899999141693115e+00
    phi[2,6]  R1150     -3.0999999046325684e+00
    phi[2,6]  R1151     -3.0999999046325684e+00
    phi[2,6]  R1152     1.3047358989715576e+00
    phi[2,6]  R1153     4.1172495484352112e-01
    phi[2,6]  R1154     8.7909883260726929e-01
    phi[2,6]  R1155     4.6104875206947327e-01
    phi[2,6]  R1156     4.1273573040962219e-01
    phi[2,6]  R1157     5.1101166009902954e-01
    phi[2,6]  R1158     7.1229869127273560e-01
    phi[2,6]  R1159     2.3374792933464050e-01
    phi[2,6]  R1160     1.2030222415924072e+00
    phi[2,6]  R1161     1.1831997334957123e-01
    phi[2,6]  R1162     -2.6728730201721191e+00
    phi[2,6]  R1163     -1.4288252592086792e+00
    phi[2,6]  R1164     -1.0392203330993652e+00
    phi[2,6]  R1165     -1.0590454339981079e+00
    phi[2,6]  R1166     -7.7259004116058350e-01
    phi[2,6]  R1167     2.3839337751269341e-02
    phi[2,6]  R1168     3.3910638093948364e-01
    phi[2,6]  R1169     -2.0534980297088623e+00
    phi[2,6]  R1170     5.3213603794574738e-02
    phi[2,6]  R1171     -1.5161970853805542e+00
    phi[2,6]  R1172     -2.0537593364715576e+00
    phi[2,6]  R1173     -1.8724329471588135e+00
    phi[2,6]  R1174     -1.5916792154312134e+00
    phi[2,6]  R1175     -2.4505271911621094e+00
    phi[2,6]  R1176     -1.6712915897369385e+00
    phi[2,6]  R1177     -1.6788634061813354e+00
    phi[2,6]  R1178     -2.6346435546875
    phi[2,6]  R1179     -1.7578318119049072e+00
    phi[2,6]  R1180     -1.2436305284500122e+00
    phi[2,6]  R1181     -1.2571961879730225e+00
    phi[2,6]  R1182     -2.5362503528594971e+00
    phi[2,6]  R1183     -2.1557533740997314e+00
    phi[2,6]  R1184     -2.1820735931396484e+00
    phi[2,6]  R1185     1.0436213016510010e+00
    phi[2,6]  R1186     4.4097694754600525e-01
    phi[2,6]  R1187     -2.1269376277923584e+00
    phi[2,6]  R1188     4.0015664696693420e-01
    phi[2,6]  R1189     -1.0450927019119263e+00
    phi[2,6]  R1190     -9.4470000267028809e-01
    phi[2,6]  R1191     -1.7921125888824463e+00
    phi[2,6]  R1192     -2.7738664150238037e+00
    phi[2,6]  R1193     6.2504762411117554e-01
    phi[2,6]  R1194     -2.6095008850097656e+00
    phi[2,6]  R1195     1.8816313743591309e+00
    phi[2,6]  R1196     3.9819464087486267e-01
    phi[2,6]  R1197     -1.5890978574752808e+00
    phi[2,6]  R1198     -1.2044396400451660e+00
    phi[2,6]  R1199     -2.2337517738342285e+00
    phi[2,6]  R1200     5.8172410726547241e-01
    phi[2,6]  R1201     -2.0298480987548828e-01
    phi[2,6]  R1202     -1.3787635564804077e+00
    phi[2,6]  R1203     -2.4265046119689941e+00
    phi[2,6]  R1204     1.5516848564147949e+00
    phi[2,6]  R1205     1.4242736995220184e-01
    phi[2,6]  R1206     -1.7214224338531494e+00
    phi[2,6]  R1207     7.5395369529724121e-01
    phi[2,6]  R1208     -1.8111455440521240e+00
    phi[2,6]  R1209     -2.1221132278442383e+00
    phi[2,6]  R1210     -1.8514742851257324e+00
    phi[2,6]  R1211     -1.4006950855255127e+00
    phi[2,6]  R1212     -1.8294088840484619e+00
    phi[2,6]  R1213     -0.584247350692749
    phi[2,6]  R1214     1.3262991905212402e+00
    phi[2,6]  R1215     1.0354204177856445e+00
    phi[2,6]  R1216     -1.4866268634796143e-01
    phi[2,6]  R1217     -1.0482614040374756e+00
    phi[2,6]  R1218     -6.1557716131210327e-01
    phi[2,6]  R1219     -6.5056753158569336e-01
    phi[2,6]  R1220     8.7806200981140137e-01
    phi[2,6]  R1221     -1.06460702419281
    phi[2,6]  R1222     1.3158118724822998e+00
    phi[2,6]  R1223     1.0136498212814331e+00
    phi[2,6]  R1224     1.6971484422683716e+00
    phi[2,6]  R1225     -0.00740637443959713
    phi[2,6]  R1226     -1.1320413351058960e+00
    phi[2,6]  R1227     1.2587369680404663e+00
    phi[2,6]  R1228     2.8136524558067322e-01
    phi[2,6]  R1229     1.8806435167789459e-01
    phi[2,6]  R1230     -0.626270592212677
    phi[2,6]  R1231     -1.2289618700742722e-01
    phi[2,6]  R1232     -1.1546353101730347e+00
    phi[2,6]  R1233     -1.1861183643341064e+00
    phi[2,6]  R1234     -8.3952236175537109e-01
    phi[2,6]  R1235     -9.8340153694152832e-01
    phi[2,6]  R1236     -1.6373997926712036e+00
    phi[2,6]  R1237     -7.5717383623123169e-01
    phi[2,6]  R1238     -0.738964319229126
    phi[2,6]  R1239     -2.4987680912017822e+00
    phi[2,6]  R1240     -1.2792247533798218e+00
    phi[2,6]  R1241     -1.2742787599563599e+00
    phi[2,6]  R1242     -1.7653902769088745e+00
    phi[2,6]  R1243     -2.6553840637207031e+00
    phi[2,6]  R1244     -1.7547312974929810e+00
    phi[2,6]  R1245     -2.4235565662384033e+00
    phi[2,6]  R1246     -1.5518461465835571e+00
    phi[2,6]  R1247     -1.7951462268829346e+00
    phi[2,6]  R1248     -1.7648845911026
    phi[2,6]  R1249     -1.2291798591613770e+00
    phi[2,6]  R1250     -9.1166895627975464e-01
    phi[2,6]  R1251     -1.5914812088012695e+00
    phi[2,6]  R1252     -1.6912870407104492e+00
    phi[2,6]  R1253     -2.2351670265197754e+00
    phi[2,6]  R1254     -1.6432310342788696e+00
    phi[2,6]  R1255     -9.1125357151031494e-01
    phi[2,6]  R1256     -2.2653753757476807e+00
    phi[2,6]  R1257     -2.4446706473827362e-01
    phi[2,6]  R1258     -2.8012716770172119e-01
    phi[2,6]  R1259     -1.0967670679092407e+00
    phi[2,6]  R1260     9.6231400966644287e-02
    phi[2,6]  R1261     -1.8381308317184448e+00
    phi[2,6]  R1262     -7.7290922403335571e-01
    phi[2,6]  R1263     -1.5832005739212036e+00
    phi[2,6]  R1264     -3.1118106842041016e-01
    phi[2,6]  R1265     -5.6111347675323486e-01
    phi[2,6]  R1266     -1.0217463970184326e+00
    phi[2,6]  R1267     -1.5180538892745972e+00
    phi[2,6]  R1268     -1.3807417154312134e+00
    phi[2,6]  R1269     -7.0455574989318848e-01
    phi[2,6]  R1270     -1.4603086709976196e+00
    phi[2,6]  R1271     -9.5732325315475464e-01
    phi[2,6]  R1272     -1.9040203094482422e+00
    phi[2,6]  R1273     -4.7447791695594788e-01
    phi[2,6]  R1274     -1.9068344831466675e+00
    phi[2,6]  R1275     -7.2076320648193359e-01
    phi[2,6]  R1276     7.0202302932739258e-01
    phi[2,6]  R1277     4.7585070133209229e-02
    phi[2,6]  R1278     -1.6228001117706299e+00
    phi[6,2]  R18       -1
    phi[6,2]  R54       1
    phi[6,2]  R55       1
    phi[6,2]  R1279     -3.0999999046325684e+00
    phi[6,2]  R1280     -3.0999999046325684e+00
    phi[6,2]  R1281     -2.2400000095367432e+00
    phi[6,2]  R1282     -2.2400000095367432e+00
    phi[6,2]  R1283     -3.0999999046325684e+00
    phi[6,2]  R1284     -3.0999999046325684e+00
    phi[6,2]  R1285     -2.5699999332427979e+00
    phi[6,2]  R1286     -2.5699999332427979e+00
    phi[6,2]  R1287     -3.0999999046325684e+00
    phi[6,2]  R1288     -3.0999999046325684e+00
    phi[6,2]  R1289     -2.0899999141693115e+00
    phi[6,2]  R1290     -2.0899999141693115e+00
    phi[6,2]  R1291     -3.0999999046325684e+00
    phi[6,2]  R1292     -3.0999999046325684e+00
    phi[6,2]  R1293     1.3158118724822998e+00
    phi[6,2]  R1294     1.0136498212814331e+00
    phi[6,2]  R1295     1.6971484422683716e+00
    phi[6,2]  R1296     -0.00740637443959713
    phi[6,2]  R1297     -1.1320413351058960e+00
    phi[6,2]  R1298     1.2587369680404663e+00
    phi[6,2]  R1299     2.8136524558067322e-01
    phi[6,2]  R1300     1.8806435167789459e-01
    phi[6,2]  R1301     -0.626270592212677
    phi[6,2]  R1302     -1.2289618700742722e-01
    phi[6,2]  R1303     -1.1546353101730347e+00
    phi[6,2]  R1304     -1.1861183643341064e+00
    phi[6,2]  R1305     -8.3952236175537109e-01
    phi[6,2]  R1306     -9.8340153694152832e-01
    phi[6,2]  R1307     -1.6373997926712036e+00
    phi[6,2]  R1308     -7.5717383623123169e-01
    phi[6,2]  R1309     -0.738964319229126
    phi[6,2]  R1310     -2.4987680912017822e+00
    phi[6,2]  R1311     -1.2792247533798218e+00
    phi[6,2]  R1312     -1.2742787599563599e+00
    phi[6,2]  R1313     -1.7653902769088745e+00
    phi[6,2]  R1314     -2.6553840637207031e+00
    phi[6,2]  R1315     -1.7547312974929810e+00
    phi[6,2]  R1316     -2.4235565662384033e+00
    phi[6,2]  R1317     -1.5518461465835571e+00
    phi[6,2]  R1318     -1.7951462268829346e+00
    phi[6,2]  R1319     -1.7648845911026
    phi[6,2]  R1320     -1.2291798591613770e+00
    phi[6,2]  R1321     -9.1166895627975464e-01
    phi[6,2]  R1322     -1.5914812088012695e+00
    phi[6,2]  R1323     -1.6912870407104492e+00
    phi[6,2]  R1324     -2.2351670265197754e+00
    phi[6,2]  R1325     -1.6432310342788696e+00
    phi[6,2]  R1326     -9.1125357151031494e-01
    phi[6,2]  R1327     -2.2653753757476807e+00
    phi[6,2]  R1328     -2.4446706473827362e-01
    phi[6,2]  R1329     -2.8012716770172119e-01
    phi[6,2]  R1330     -1.0967670679092407e+00
    phi[6,2]  R1331     9.6231400966644287e-02
    phi[6,2]  R1332     -1.8381308317184448e+00
    phi[6,2]  R1333     -7.7290922403335571e-01
    phi[6,2]  R1334     -1.5832005739212036e+00
    phi[6,2]  R1335     -3.1118106842041016e-01
    phi[6,2]  R1336     -5.6111347675323486e-01
    phi[6,2]  R1337     -1.0217463970184326e+00
    phi[6,2]  R1338     -1.5180538892745972e+00
    phi[6,2]  R1339     -1.3807417154312134e+00
    phi[6,2]  R1340     -7.0455574989318848e-01
    phi[6,2]  R1341     -1.4603086709976196e+00
    phi[6,2]  R1342     -9.5732325315475464e-01
    phi[6,2]  R1343     -1.9040203094482422e+00
    phi[6,2]  R1344     -4.7447791695594788e-01
    phi[6,2]  R1345     -1.9068344831466675e+00
    phi[6,2]  R1346     -7.2076320648193359e-01
    phi[6,2]  R1347     7.0202302932739258e-01
    phi[6,2]  R1348     4.7585070133209229e-02
    phi[6,2]  R1349     -1.6228001117706299e+00
    phi[6,2]  R1350     1.3047358989715576e+00
    phi[6,2]  R1351     4.1172495484352112e-01
    phi[6,2]  R1352     8.7909883260726929e-01
    phi[6,2]  R1353     4.6104875206947327e-01
    phi[6,2]  R1354     4.1273573040962219e-01
    phi[6,2]  R1355     5.1101166009902954e-01
    phi[6,2]  R1356     7.1229869127273560e-01
    phi[6,2]  R1357     2.3374792933464050e-01
    phi[6,2]  R1358     1.2030222415924072e+00
    phi[6,2]  R1359     1.1831997334957123e-01
    phi[6,2]  R1360     -2.6728730201721191e+00
    phi[6,2]  R1361     -1.4288252592086792e+00
    phi[6,2]  R1362     -1.0392203330993652e+00
    phi[6,2]  R1363     -1.0590454339981079e+00
    phi[6,2]  R1364     -7.7259004116058350e-01
    phi[6,2]  R1365     2.3839337751269341e-02
    phi[6,2]  R1366     3.3910638093948364e-01
    phi[6,2]  R1367     -2.0534980297088623e+00
    phi[6,2]  R1368     5.3213603794574738e-02
    phi[6,2]  R1369     -1.5161970853805542e+00
    phi[6,2]  R1370     -2.0537593364715576e+00
    phi[6,2]  R1371     -1.8724329471588135e+00
    phi[6,2]  R1372     -1.5916792154312134e+00
    phi[6,2]  R1373     -2.4505271911621094e+00
    phi[6,2]  R1374     -1.6712915897369385e+00
    phi[6,2]  R1375     -1.6788634061813354e+00
    phi[6,2]  R1376     -2.6346435546875
    phi[6,2]  R1377     -1.7578318119049072e+00
    phi[6,2]  R1378     -1.2436305284500122e+00
    phi[6,2]  R1379     -1.2571961879730225e+00
    phi[6,2]  R1380     -2.5362503528594971e+00
    phi[6,2]  R1381     -2.1557533740997314e+00
    phi[6,2]  R1382     -2.1820735931396484e+00
    phi[6,2]  R1383     1.0436213016510010e+00
    phi[6,2]  R1384     4.4097694754600525e-01
    phi[6,2]  R1385     -2.1269376277923584e+00
    phi[6,2]  R1386     4.0015664696693420e-01
    phi[6,2]  R1387     -1.0450927019119263e+00
    phi[6,2]  R1388     -9.4470000267028809e-01
    phi[6,2]  R1389     -1.7921125888824463e+00
    phi[6,2]  R1390     -2.7738664150238037e+00
    phi[6,2]  R1391     6.2504762411117554e-01
    phi[6,2]  R1392     -2.6095008850097656e+00
    phi[6,2]  R1393     1.8816313743591309e+00
    phi[6,2]  R1394     3.9819464087486267e-01
    phi[6,2]  R1395     -1.5890978574752808e+00
    phi[6,2]  R1396     -1.2044396400451660e+00
    phi[6,2]  R1397     -2.2337517738342285e+00
    phi[6,2]  R1398     5.8172410726547241e-01
    phi[6,2]  R1399     -2.0298480987548828e-01
    phi[6,2]  R1400     -1.3787635564804077e+00
    phi[6,2]  R1401     -2.4265046119689941e+00
    phi[6,2]  R1402     1.5516848564147949e+00
    phi[6,2]  R1403     1.4242736995220184e-01
    phi[6,2]  R1404     -1.7214224338531494e+00
    phi[6,2]  R1405     7.5395369529724121e-01
    phi[6,2]  R1406     -1.8111455440521240e+00
    phi[6,2]  R1407     -2.1221132278442383e+00
    phi[6,2]  R1408     -1.8514742851257324e+00
    phi[6,2]  R1409     -1.4006950855255127e+00
    phi[6,2]  R1410     -1.8294088840484619e+00
    phi[6,2]  R1411     -0.584247350692749
    phi[6,2]  R1412     1.3262991905212402e+00
    phi[6,2]  R1413     1.0354204177856445e+00
    phi[6,2]  R1414     -1.4866268634796143e-01
    phi[6,2]  R1415     -1.0482614040374756e+00
    phi[6,2]  R1416     -6.1557716131210327e-01
    phi[6,2]  R1417     -6.5056753158569336e-01
    phi[6,2]  R1418     8.7806200981140137e-01
    phi[6,2]  R1419     -1.06460702419281
    phi[2,7]  R18       1
    phi[2,7]  R19       1
    phi[2,7]  R63       -1
    phi[2,7]  R1420     -3.0999999046325684e+00
    phi[2,7]  R1421     -3.0999999046325684e+00
    phi[2,7]  R1422     -2.2400000095367432e+00
    phi[2,7]  R1423     -2.2400000095367432e+00
    phi[2,7]  R1424     -3.0999999046325684e+00
    phi[2,7]  R1425     -3.0999999046325684e+00
    phi[2,7]  R1426     -2.5699999332427979e+00
    phi[2,7]  R1427     -2.5699999332427979e+00
    phi[2,7]  R1428     -3.0999999046325684e+00
    phi[2,7]  R1429     -3.0999999046325684e+00
    phi[2,7]  R1430     -2.0899999141693115e+00
    phi[2,7]  R1431     -2.0899999141693115e+00
    phi[2,7]  R1432     -3.0999999046325684e+00
    phi[2,7]  R1433     -3.0999999046325684e+00
    phi[2,7]  R1434     1.3047358989715576e+00
    phi[2,7]  R1435     4.1172495484352112e-01
    phi[2,7]  R1436     8.7909883260726929e-01
    phi[2,7]  R1437     4.6104875206947327e-01
    phi[2,7]  R1438     4.1273573040962219e-01
    phi[2,7]  R1439     5.1101166009902954e-01
    phi[2,7]  R1440     7.1229869127273560e-01
    phi[2,7]  R1441     2.3374792933464050e-01
    phi[2,7]  R1442     1.2030222415924072e+00
    phi[2,7]  R1443     1.1831997334957123e-01
    phi[2,7]  R1444     -2.6728730201721191e+00
    phi[2,7]  R1445     -1.4288252592086792e+00
    phi[2,7]  R1446     -1.0392203330993652e+00
    phi[2,7]  R1447     -1.0590454339981079e+00
    phi[2,7]  R1448     -7.7259004116058350e-01
    phi[2,7]  R1449     2.3839337751269341e-02
    phi[2,7]  R1450     3.3910638093948364e-01
    phi[2,7]  R1451     -2.0534980297088623e+00
    phi[2,7]  R1452     5.3213603794574738e-02
    phi[2,7]  R1453     -1.5161970853805542e+00
    phi[2,7]  R1454     -2.0537593364715576e+00
    phi[2,7]  R1455     -1.8724329471588135e+00
    phi[2,7]  R1456     -1.5916792154312134e+00
    phi[2,7]  R1457     -2.4505271911621094e+00
    phi[2,7]  R1458     -1.6712915897369385e+00
    phi[2,7]  R1459     -1.6788634061813354e+00
    phi[2,7]  R1460     -2.6346435546875
    phi[2,7]  R1461     -1.7578318119049072e+00
    phi[2,7]  R1462     -1.2436305284500122e+00
    phi[2,7]  R1463     -1.2571961879730225e+00
    phi[2,7]  R1464     -2.5362503528594971e+00
    phi[2,7]  R1465     -2.1557533740997314e+00
    phi[2,7]  R1466     -2.1820735931396484e+00
    phi[2,7]  R1467     1.0436213016510010e+00
    phi[2,7]  R1468     4.4097694754600525e-01
    phi[2,7]  R1469     -2.1269376277923584e+00
    phi[2,7]  R1470     4.0015664696693420e-01
    phi[2,7]  R1471     -1.0450927019119263e+00
    phi[2,7]  R1472     -9.4470000267028809e-01
    phi[2,7]  R1473     -1.7921125888824463e+00
    phi[2,7]  R1474     -2.7738664150238037e+00
    phi[2,7]  R1475     6.2504762411117554e-01
    phi[2,7]  R1476     -2.6095008850097656e+00
    phi[2,7]  R1477     1.8816313743591309e+00
    phi[2,7]  R1478     3.9819464087486267e-01
    phi[2,7]  R1479     -1.5890978574752808e+00
    phi[2,7]  R1480     -1.2044396400451660e+00
    phi[2,7]  R1481     -2.2337517738342285e+00
    phi[2,7]  R1482     5.8172410726547241e-01
    phi[2,7]  R1483     -2.0298480987548828e-01
    phi[2,7]  R1484     -1.3787635564804077e+00
    phi[2,7]  R1485     -2.4265046119689941e+00
    phi[2,7]  R1486     1.5516848564147949e+00
    phi[2,7]  R1487     1.4242736995220184e-01
    phi[2,7]  R1488     -1.7214224338531494e+00
    phi[2,7]  R1489     7.5395369529724121e-01
    phi[2,7]  R1490     -1.8111455440521240e+00
    phi[2,7]  R1491     -2.1221132278442383e+00
    phi[2,7]  R1492     -1.8514742851257324e+00
    phi[2,7]  R1493     -1.4006950855255127e+00
    phi[2,7]  R1494     -1.8294088840484619e+00
    phi[2,7]  R1495     -0.584247350692749
    phi[2,7]  R1496     1.3262991905212402e+00
    phi[2,7]  R1497     1.0354204177856445e+00
    phi[2,7]  R1498     -1.4866268634796143e-01
    phi[2,7]  R1499     -1.0482614040374756e+00
    phi[2,7]  R1500     -6.1557716131210327e-01
    phi[2,7]  R1501     -6.5056753158569336e-01
    phi[2,7]  R1502     8.7806200981140137e-01
    phi[2,7]  R1503     -1.06460702419281
    phi[2,7]  R1504     8.0538213253021240e-01
    phi[2,7]  R1505     1.9378125667572021e+00
    phi[2,7]  R1506     2.0790770053863525e+00
    phi[2,7]  R1507     1.7048386335372925e+00
    phi[2,7]  R1508     1.6482667922973633e+00
    phi[2,7]  R1509     1.7414242029190063e+00
    phi[2,7]  R1510     2.5279121398925781e+00
    phi[2,7]  R1511     -4.4490702450275421e-02
    phi[2,7]  R1512     2.0533767342567444e-01
    phi[2,7]  R1513     7.6173257827758789e-01
    phi[2,7]  R1514     -0.847429096698761
    phi[2,7]  R1515     -2.7495008707046509e-01
    phi[2,7]  R1516     -1.2146545648574829e+00
    phi[2,7]  R1517     -1.3557885885238647e+00
    phi[2,7]  R1518     8.0339562892913818e-01
    phi[2,7]  R1519     -2.6922621726989746e+00
    phi[2,7]  R1520     -9.7602713108062744e-01
    phi[2,7]  R1521     -3.7119886279106140e-01
    phi[2,7]  R1522     -2.3485741615295410e+00
    phi[2,7]  R1523     -7.8629720211029053e-01
    phi[2,7]  R1524     4.7607097029685974e-01
    phi[2,7]  R1525     -1.6095542907714844e+00
    phi[2,7]  R1526     -2.1832215785980225e+00
    phi[2,7]  R1527     -1.8138754367828369e+00
    phi[2,7]  R1528     -2.6593339443206787e+00
    phi[2,7]  R1529     -2.5867209434509277e+00
    phi[2,7]  R1530     2.4291884899139404e-01
    phi[2,7]  R1531     -2.1750781536102295e+00
    phi[2,7]  R1532     1.4012350142002106e-01
    phi[2,7]  R1533     -2.3885660171508789e+00
    phi[2,7]  R1534     2.9597362875938416e-01
    phi[2,7]  R1535     2.6440870761871338e-01
    phi[2,7]  R1536     -1.4455686807632446e+00
    phi[2,7]  R1537     -1.4282138347625732e+00
    phi[2,7]  R1538     -2.8020324707031250e+00
    phi[2,7]  R1539     -2.0756087303161621e+00
    phi[2,7]  R1540     -2.3310575485229492e+00
    phi[2,7]  R1541     -2.3053517341613770e+00
    phi[2,7]  R1542     -1.8596346378326416e+00
    phi[2,7]  R1543     -1.1832216978073120e+00
    phi[7,2]  R18       -1
    phi[7,2]  R63       1
    phi[7,2]  R64       1
    phi[7,2]  R1544     -3.0999999046325684e+00
    phi[7,2]  R1545     -3.0999999046325684e+00
    phi[7,2]  R1546     -2.2400000095367432e+00
    phi[7,2]  R1547     -2.2400000095367432e+00
    phi[7,2]  R1548     -3.0999999046325684e+00
    phi[7,2]  R1549     -3.0999999046325684e+00
    phi[7,2]  R1550     -2.5699999332427979e+00
    phi[7,2]  R1551     -2.5699999332427979e+00
    phi[7,2]  R1552     -3.0999999046325684e+00
    phi[7,2]  R1553     -3.0999999046325684e+00
    phi[7,2]  R1554     -2.0899999141693115e+00
    phi[7,2]  R1555     -2.0899999141693115e+00
    phi[7,2]  R1556     -3.0999999046325684e+00
    phi[7,2]  R1557     -3.0999999046325684e+00
    phi[7,2]  R1558     8.0538213253021240e-01
    phi[7,2]  R1559     1.9378125667572021e+00
    phi[7,2]  R1560     2.0790770053863525e+00
    phi[7,2]  R1561     1.7048386335372925e+00
    phi[7,2]  R1562     1.6482667922973633e+00
    phi[7,2]  R1563     1.7414242029190063e+00
    phi[7,2]  R1564     2.5279121398925781e+00
    phi[7,2]  R1565     -4.4490702450275421e-02
    phi[7,2]  R1566     2.0533767342567444e-01
    phi[7,2]  R1567     7.6173257827758789e-01
    phi[7,2]  R1568     -0.847429096698761
    phi[7,2]  R1569     -2.7495008707046509e-01
    phi[7,2]  R1570     -1.2146545648574829e+00
    phi[7,2]  R1571     -1.3557885885238647e+00
    phi[7,2]  R1572     8.0339562892913818e-01
    phi[7,2]  R1573     -2.6922621726989746e+00
    phi[7,2]  R1574     -9.7602713108062744e-01
    phi[7,2]  R1575     -3.7119886279106140e-01
    phi[7,2]  R1576     -2.3485741615295410e+00
    phi[7,2]  R1577     -7.8629720211029053e-01
    phi[7,2]  R1578     4.7607097029685974e-01
    phi[7,2]  R1579     -1.6095542907714844e+00
    phi[7,2]  R1580     -2.1832215785980225e+00
    phi[7,2]  R1581     -1.8138754367828369e+00
    phi[7,2]  R1582     -2.6593339443206787e+00
    phi[7,2]  R1583     -2.5867209434509277e+00
    phi[7,2]  R1584     2.4291884899139404e-01
    phi[7,2]  R1585     -2.1750781536102295e+00
    phi[7,2]  R1586     1.4012350142002106e-01
    phi[7,2]  R1587     -2.3885660171508789e+00
    phi[7,2]  R1588     2.9597362875938416e-01
    phi[7,2]  R1589     2.6440870761871338e-01
    phi[7,2]  R1590     -1.4455686807632446e+00
    phi[7,2]  R1591     -1.4282138347625732e+00
    phi[7,2]  R1592     -2.8020324707031250e+00
    phi[7,2]  R1593     -2.0756087303161621e+00
    phi[7,2]  R1594     -2.3310575485229492e+00
    phi[7,2]  R1595     -2.3053517341613770e+00
    phi[7,2]  R1596     -1.8596346378326416e+00
    phi[7,2]  R1597     -1.1832216978073120e+00
    phi[7,2]  R1598     1.3047358989715576e+00
    phi[7,2]  R1599     4.1172495484352112e-01
    phi[7,2]  R1600     8.7909883260726929e-01
    phi[7,2]  R1601     4.6104875206947327e-01
    phi[7,2]  R1602     4.1273573040962219e-01
    phi[7,2]  R1603     5.1101166009902954e-01
    phi[7,2]  R1604     7.1229869127273560e-01
    phi[7,2]  R1605     2.3374792933464050e-01
    phi[7,2]  R1606     1.2030222415924072e+00
    phi[7,2]  R1607     1.1831997334957123e-01
    phi[7,2]  R1608     -2.6728730201721191e+00
    phi[7,2]  R1609     -1.4288252592086792e+00
    phi[7,2]  R1610     -1.0392203330993652e+00
    phi[7,2]  R1611     -1.0590454339981079e+00
    phi[7,2]  R1612     -7.7259004116058350e-01
    phi[7,2]  R1613     2.3839337751269341e-02
    phi[7,2]  R1614     3.3910638093948364e-01
    phi[7,2]  R1615     -2.0534980297088623e+00
    phi[7,2]  R1616     5.3213603794574738e-02
    phi[7,2]  R1617     -1.5161970853805542e+00
    phi[7,2]  R1618     -2.0537593364715576e+00
    phi[7,2]  R1619     -1.8724329471588135e+00
    phi[7,2]  R1620     -1.5916792154312134e+00
    phi[7,2]  R1621     -2.4505271911621094e+00
    phi[7,2]  R1622     -1.6712915897369385e+00
    phi[7,2]  R1623     -1.6788634061813354e+00
    phi[7,2]  R1624     -2.6346435546875
    phi[7,2]  R1625     -1.7578318119049072e+00
    phi[7,2]  R1626     -1.2436305284500122e+00
    phi[7,2]  R1627     -1.2571961879730225e+00
    phi[7,2]  R1628     -2.5362503528594971e+00
    phi[7,2]  R1629     -2.1557533740997314e+00
    phi[7,2]  R1630     -2.1820735931396484e+00
    phi[7,2]  R1631     1.0436213016510010e+00
    phi[7,2]  R1632     4.4097694754600525e-01
    phi[7,2]  R1633     -2.1269376277923584e+00
    phi[7,2]  R1634     4.0015664696693420e-01
    phi[7,2]  R1635     -1.0450927019119263e+00
    phi[7,2]  R1636     -9.4470000267028809e-01
    phi[7,2]  R1637     -1.7921125888824463e+00
    phi[7,2]  R1638     -2.7738664150238037e+00
    phi[7,2]  R1639     6.2504762411117554e-01
    phi[7,2]  R1640     -2.6095008850097656e+00
    phi[7,2]  R1641     1.8816313743591309e+00
    phi[7,2]  R1642     3.9819464087486267e-01
    phi[7,2]  R1643     -1.5890978574752808e+00
    phi[7,2]  R1644     -1.2044396400451660e+00
    phi[7,2]  R1645     -2.2337517738342285e+00
    phi[7,2]  R1646     5.8172410726547241e-01
    phi[7,2]  R1647     -2.0298480987548828e-01
    phi[7,2]  R1648     -1.3787635564804077e+00
    phi[7,2]  R1649     -2.4265046119689941e+00
    phi[7,2]  R1650     1.5516848564147949e+00
    phi[7,2]  R1651     1.4242736995220184e-01
    phi[7,2]  R1652     -1.7214224338531494e+00
    phi[7,2]  R1653     7.5395369529724121e-01
    phi[7,2]  R1654     -1.8111455440521240e+00
    phi[7,2]  R1655     -2.1221132278442383e+00
    phi[7,2]  R1656     -1.8514742851257324e+00
    phi[7,2]  R1657     -1.4006950855255127e+00
    phi[7,2]  R1658     -1.8294088840484619e+00
    phi[7,2]  R1659     -0.584247350692749
    phi[7,2]  R1660     1.3262991905212402e+00
    phi[7,2]  R1661     1.0354204177856445e+00
    phi[7,2]  R1662     -1.4866268634796143e-01
    phi[7,2]  R1663     -1.0482614040374756e+00
    phi[7,2]  R1664     -6.1557716131210327e-01
    phi[7,2]  R1665     -6.5056753158569336e-01
    phi[7,2]  R1666     8.7806200981140137e-01
    phi[7,2]  R1667     -1.06460702419281
    phi[3,6]  R27       1
    phi[3,6]  R28       1
    phi[3,6]  R54       -1
    phi[3,6]  R1668     -3.0999999046325684e+00
    phi[3,6]  R1669     -3.0999999046325684e+00
    phi[3,6]  R1670     -2.2400000095367432e+00
    phi[3,6]  R1671     -2.2400000095367432e+00
    phi[3,6]  R1672     -3.0999999046325684e+00
    phi[3,6]  R1673     -3.0999999046325684e+00
    phi[3,6]  R1674     -2.5699999332427979e+00
    phi[3,6]  R1675     -2.5699999332427979e+00
    phi[3,6]  R1676     -3.0999999046325684e+00
    phi[3,6]  R1677     -3.0999999046325684e+00
    phi[3,6]  R1678     -2.0899999141693115e+00
    phi[3,6]  R1679     -2.0899999141693115e+00
    phi[3,6]  R1680     -3.0999999046325684e+00
    phi[3,6]  R1681     -3.0999999046325684e+00
    phi[3,6]  R1682     1.3132629394531250e+00
    phi[3,6]  R1683     5.9209907054901123e-01
    phi[3,6]  R1684     1.4335892200469971e+00
    phi[3,6]  R1685     2.8268089294433594e+00
    phi[3,6]  R1686     2.2504229545593262e+00
    phi[3,6]  R1687     1.9293751716613770e+00
    phi[3,6]  R1688     1.5463392734527588e+00
    phi[3,6]  R1689     -3.1073608994483948e-01
    phi[3,6]  R1690     -3.1540915369987488e-01
    phi[3,6]  R1691     3.8748973608016968e-01
    phi[3,6]  R1692     -1.0358899831771851e+00
    phi[3,6]  R1693     -1.6490143537521362e+00
    phi[3,6]  R1694     -1.7502099275588989e+00
    phi[3,6]  R1695     -1.8528970479965210e+00
    phi[3,6]  R1696     -0.154770627617836
    phi[3,6]  R1697     0.503047525882721
    phi[3,6]  R1698     -2.3411171436309814e+00
    phi[3,6]  R1699     -1.5184706449508667e+00
    phi[3,6]  R1700     -2.0552301406860352e+00
    phi[3,6]  R1701     -3.0953278541564941e+00
    phi[3,6]  R1702     -1.5549764633178711e+00
    phi[3,6]  R1703     -8.9567416906356812e-01
    phi[3,6]  R1704     -2.1195132732391357e+00
    phi[3,6]  R1705     -1.0136455297470093e+00
    phi[3,6]  R1706     -2.1495256423950195e+00
    phi[3,6]  R1707     -3.9254549145698547e-01
    phi[3,6]  R1708     -1.0671377182006836e+00
    phi[3,6]  R1709     -1.8839714527130127e+00
    phi[3,6]  R1710     9.7120665013790131e-03
    phi[3,6]  R1711     -1.3727135658264160e+00
    phi[3,6]  R1712     -8.7287724018096924e-03
    phi[3,6]  R1713     -1.3634074926376343e+00
    phi[3,6]  R1714     -3.1052780151367188e-01
    phi[3,6]  R1715     6.4304918050765991e-01
    phi[3,6]  R1716     -9.6809273958206177e-01
    phi[3,6]  R1717     -5.4477047920227051e-01
    phi[3,6]  R1718     3.2963702082633972e-01
    phi[3,6]  R1719     4.5905942097306252e-03
    phi[3,6]  R1720     1.2166296243667603e+00
    phi[3,6]  R1721     5.9750485420227051e-01
    phi[3,6]  R1722     1.3158118724822998e+00
    phi[3,6]  R1723     1.0136498212814331e+00
    phi[3,6]  R1724     1.6971484422683716e+00
    phi[3,6]  R1725     -0.00740637443959713
    phi[3,6]  R1726     -1.1320413351058960e+00
    phi[3,6]  R1727     1.2587369680404663e+00
    phi[3,6]  R1728     2.8136524558067322e-01
    phi[3,6]  R1729     1.8806435167789459e-01
    phi[3,6]  R1730     -0.626270592212677
    phi[3,6]  R1731     -1.2289618700742722e-01
    phi[3,6]  R1732     -1.1546353101730347e+00
    phi[3,6]  R1733     -1.1861183643341064e+00
    phi[3,6]  R1734     -8.3952236175537109e-01
    phi[3,6]  R1735     -9.8340153694152832e-01
    phi[3,6]  R1736     -1.6373997926712036e+00
    phi[3,6]  R1737     -7.5717383623123169e-01
    phi[3,6]  R1738     -0.738964319229126
    phi[3,6]  R1739     -2.4987680912017822e+00
    phi[3,6]  R1740     -1.2792247533798218e+00
    phi[3,6]  R1741     -1.2742787599563599e+00
    phi[3,6]  R1742     -1.7653902769088745e+00
    phi[3,6]  R1743     -2.6553840637207031e+00
    phi[3,6]  R1744     -1.7547312974929810e+00
    phi[3,6]  R1745     -2.4235565662384033e+00
    phi[3,6]  R1746     -1.5518461465835571e+00
    phi[3,6]  R1747     -1.7951462268829346e+00
    phi[3,6]  R1748     -1.7648845911026
    phi[3,6]  R1749     -1.2291798591613770e+00
    phi[3,6]  R1750     -9.1166895627975464e-01
    phi[3,6]  R1751     -1.5914812088012695e+00
    phi[3,6]  R1752     -1.6912870407104492e+00
    phi[3,6]  R1753     -2.2351670265197754e+00
    phi[3,6]  R1754     -1.6432310342788696e+00
    phi[3,6]  R1755     -9.1125357151031494e-01
    phi[3,6]  R1756     -2.2653753757476807e+00
    phi[3,6]  R1757     -2.4446706473827362e-01
    phi[3,6]  R1758     -2.8012716770172119e-01
    phi[3,6]  R1759     -1.0967670679092407e+00
    phi[3,6]  R1760     9.6231400966644287e-02
    phi[3,6]  R1761     -1.8381308317184448e+00
    phi[3,6]  R1762     -7.7290922403335571e-01
    phi[3,6]  R1763     -1.5832005739212036e+00
    phi[3,6]  R1764     -3.1118106842041016e-01
    phi[3,6]  R1765     -5.6111347675323486e-01
    phi[3,6]  R1766     -1.0217463970184326e+00
    phi[3,6]  R1767     -1.5180538892745972e+00
    phi[3,6]  R1768     -1.3807417154312134e+00
    phi[3,6]  R1769     -7.0455574989318848e-01
    phi[3,6]  R1770     -1.4603086709976196e+00
    phi[3,6]  R1771     -9.5732325315475464e-01
    phi[3,6]  R1772     -1.9040203094482422e+00
    phi[3,6]  R1773     -4.7447791695594788e-01
    phi[3,6]  R1774     -1.9068344831466675e+00
    phi[3,6]  R1775     -7.2076320648193359e-01
    phi[3,6]  R1776     7.0202302932739258e-01
    phi[3,6]  R1777     4.7585070133209229e-02
    phi[3,6]  R1778     -1.6228001117706299e+00
    phi[6,3]  R27       -1
    phi[6,3]  R54       1
    phi[6,3]  R55       1
    phi[6,3]  R1779     -3.0999999046325684e+00
    phi[6,3]  R1780     -3.0999999046325684e+00
    phi[6,3]  R1781     -2.2400000095367432e+00
    phi[6,3]  R1782     -2.2400000095367432e+00
    phi[6,3]  R1783     -3.0999999046325684e+00
    phi[6,3]  R1784     -3.0999999046325684e+00
    phi[6,3]  R1785     -2.5699999332427979e+00
    phi[6,3]  R1786     -2.5699999332427979e+00
    phi[6,3]  R1787     -3.0999999046325684e+00
    phi[6,3]  R1788     -3.0999999046325684e+00
    phi[6,3]  R1789     -2.0899999141693115e+00
    phi[6,3]  R1790     -2.0899999141693115e+00
    phi[6,3]  R1791     -3.0999999046325684e+00
    phi[6,3]  R1792     -3.0999999046325684e+00
    phi[6,3]  R1793     1.3158118724822998e+00
    phi[6,3]  R1794     1.0136498212814331e+00
    phi[6,3]  R1795     1.6971484422683716e+00
    phi[6,3]  R1796     -0.00740637443959713
    phi[6,3]  R1797     -1.1320413351058960e+00
    phi[6,3]  R1798     1.2587369680404663e+00
    phi[6,3]  R1799     2.8136524558067322e-01
    phi[6,3]  R1800     1.8806435167789459e-01
    phi[6,3]  R1801     -0.626270592212677
    phi[6,3]  R1802     -1.2289618700742722e-01
    phi[6,3]  R1803     -1.1546353101730347e+00
    phi[6,3]  R1804     -1.1861183643341064e+00
    phi[6,3]  R1805     -8.3952236175537109e-01
    phi[6,3]  R1806     -9.8340153694152832e-01
    phi[6,3]  R1807     -1.6373997926712036e+00
    phi[6,3]  R1808     -7.5717383623123169e-01
    phi[6,3]  R1809     -0.738964319229126
    phi[6,3]  R1810     -2.4987680912017822e+00
    phi[6,3]  R1811     -1.2792247533798218e+00
    phi[6,3]  R1812     -1.2742787599563599e+00
    phi[6,3]  R1813     -1.7653902769088745e+00
    phi[6,3]  R1814     -2.6553840637207031e+00
    phi[6,3]  R1815     -1.7547312974929810e+00
    phi[6,3]  R1816     -2.4235565662384033e+00
    phi[6,3]  R1817     -1.5518461465835571e+00
    phi[6,3]  R1818     -1.7951462268829346e+00
    phi[6,3]  R1819     -1.7648845911026
    phi[6,3]  R1820     -1.2291798591613770e+00
    phi[6,3]  R1821     -9.1166895627975464e-01
    phi[6,3]  R1822     -1.5914812088012695e+00
    phi[6,3]  R1823     -1.6912870407104492e+00
    phi[6,3]  R1824     -2.2351670265197754e+00
    phi[6,3]  R1825     -1.6432310342788696e+00
    phi[6,3]  R1826     -9.1125357151031494e-01
    phi[6,3]  R1827     -2.2653753757476807e+00
    phi[6,3]  R1828     -2.4446706473827362e-01
    phi[6,3]  R1829     -2.8012716770172119e-01
    phi[6,3]  R1830     -1.0967670679092407e+00
    phi[6,3]  R1831     9.6231400966644287e-02
    phi[6,3]  R1832     -1.8381308317184448e+00
    phi[6,3]  R1833     -7.7290922403335571e-01
    phi[6,3]  R1834     -1.5832005739212036e+00
    phi[6,3]  R1835     -3.1118106842041016e-01
    phi[6,3]  R1836     -5.6111347675323486e-01
    phi[6,3]  R1837     -1.0217463970184326e+00
    phi[6,3]  R1838     -1.5180538892745972e+00
    phi[6,3]  R1839     -1.3807417154312134e+00
    phi[6,3]  R1840     -7.0455574989318848e-01
    phi[6,3]  R1841     -1.4603086709976196e+00
    phi[6,3]  R1842     -9.5732325315475464e-01
    phi[6,3]  R1843     -1.9040203094482422e+00
    phi[6,3]  R1844     -4.7447791695594788e-01
    phi[6,3]  R1845     -1.9068344831466675e+00
    phi[6,3]  R1846     -7.2076320648193359e-01
    phi[6,3]  R1847     7.0202302932739258e-01
    phi[6,3]  R1848     4.7585070133209229e-02
    phi[6,3]  R1849     -1.6228001117706299e+00
    phi[6,3]  R1850     1.3132629394531250e+00
    phi[6,3]  R1851     5.9209907054901123e-01
    phi[6,3]  R1852     1.4335892200469971e+00
    phi[6,3]  R1853     2.8268089294433594e+00
    phi[6,3]  R1854     2.2504229545593262e+00
    phi[6,3]  R1855     1.9293751716613770e+00
    phi[6,3]  R1856     1.5463392734527588e+00
    phi[6,3]  R1857     -3.1073608994483948e-01
    phi[6,3]  R1858     -3.1540915369987488e-01
    phi[6,3]  R1859     3.8748973608016968e-01
    phi[6,3]  R1860     -1.0358899831771851e+00
    phi[6,3]  R1861     -1.6490143537521362e+00
    phi[6,3]  R1862     -1.7502099275588989e+00
    phi[6,3]  R1863     -1.8528970479965210e+00
    phi[6,3]  R1864     -0.154770627617836
    phi[6,3]  R1865     0.503047525882721
    phi[6,3]  R1866     -2.3411171436309814e+00
    phi[6,3]  R1867     -1.5184706449508667e+00
    phi[6,3]  R1868     -2.0552301406860352e+00
    phi[6,3]  R1869     -3.0953278541564941e+00
    phi[6,3]  R1870     -1.5549764633178711e+00
    phi[6,3]  R1871     -8.9567416906356812e-01
    phi[6,3]  R1872     -2.1195132732391357e+00
    phi[6,3]  R1873     -1.0136455297470093e+00
    phi[6,3]  R1874     -2.1495256423950195e+00
    phi[6,3]  R1875     -3.9254549145698547e-01
    phi[6,3]  R1876     -1.0671377182006836e+00
    phi[6,3]  R1877     -1.8839714527130127e+00
    phi[6,3]  R1878     9.7120665013790131e-03
    phi[6,3]  R1879     -1.3727135658264160e+00
    phi[6,3]  R1880     -8.7287724018096924e-03
    phi[6,3]  R1881     -1.3634074926376343e+00
    phi[6,3]  R1882     -3.1052780151367188e-01
    phi[6,3]  R1883     6.4304918050765991e-01
    phi[6,3]  R1884     -9.6809273958206177e-01
    phi[6,3]  R1885     -5.4477047920227051e-01
    phi[6,3]  R1886     3.2963702082633972e-01
    phi[6,3]  R1887     4.5905942097306252e-03
    phi[6,3]  R1888     1.2166296243667603e+00
    phi[6,3]  R1889     5.9750485420227051e-01
    phi[3,7]  R27       1
    phi[3,7]  R28       1
    phi[3,7]  R63       -1
    phi[3,7]  R1890     -3.0999999046325684e+00
    phi[3,7]  R1891     -3.0999999046325684e+00
    phi[3,7]  R1892     -2.2400000095367432e+00
    phi[3,7]  R1893     -2.2400000095367432e+00
    phi[3,7]  R1894     -3.0999999046325684e+00
    phi[3,7]  R1895     -3.0999999046325684e+00
    phi[3,7]  R1896     -2.5699999332427979e+00
    phi[3,7]  R1897     -2.5699999332427979e+00
    phi[3,7]  R1898     -3.0999999046325684e+00
    phi[3,7]  R1899     -3.0999999046325684e+00
    phi[3,7]  R1900     -2.0899999141693115e+00
    phi[3,7]  R1901     -2.0899999141693115e+00
    phi[3,7]  R1902     -3.0999999046325684e+00
    phi[3,7]  R1903     -3.0999999046325684e+00
    phi[3,7]  R1904     1.3132629394531250e+00
    phi[3,7]  R1905     5.9209907054901123e-01
    phi[3,7]  R1906     1.4335892200469971e+00
    phi[3,7]  R1907     2.8268089294433594e+00
    phi[3,7]  R1908     2.2504229545593262e+00
    phi[3,7]  R1909     1.9293751716613770e+00
    phi[3,7]  R1910     1.5463392734527588e+00
    phi[3,7]  R1911     -3.1073608994483948e-01
    phi[3,7]  R1912     -3.1540915369987488e-01
    phi[3,7]  R1913     3.8748973608016968e-01
    phi[3,7]  R1914     -1.0358899831771851e+00
    phi[3,7]  R1915     -1.6490143537521362e+00
    phi[3,7]  R1916     -1.7502099275588989e+00
    phi[3,7]  R1917     -1.8528970479965210e+00
    phi[3,7]  R1918     -0.154770627617836
    phi[3,7]  R1919     0.503047525882721
    phi[3,7]  R1920     -2.3411171436309814e+00
    phi[3,7]  R1921     -1.5184706449508667e+00
    phi[3,7]  R1922     -2.0552301406860352e+00
    phi[3,7]  R1923     -3.0953278541564941e+00
    phi[3,7]  R1924     -1.5549764633178711e+00
    phi[3,7]  R1925     -8.9567416906356812e-01
    phi[3,7]  R1926     -2.1195132732391357e+00
    phi[3,7]  R1927     -1.0136455297470093e+00
    phi[3,7]  R1928     -2.1495256423950195e+00
    phi[3,7]  R1929     -3.9254549145698547e-01
    phi[3,7]  R1930     -1.0671377182006836e+00
    phi[3,7]  R1931     -1.8839714527130127e+00
    phi[3,7]  R1932     9.7120665013790131e-03
    phi[3,7]  R1933     -1.3727135658264160e+00
    phi[3,7]  R1934     -8.7287724018096924e-03
    phi[3,7]  R1935     -1.3634074926376343e+00
    phi[3,7]  R1936     -3.1052780151367188e-01
    phi[3,7]  R1937     6.4304918050765991e-01
    phi[3,7]  R1938     -9.6809273958206177e-01
    phi[3,7]  R1939     -5.4477047920227051e-01
    phi[3,7]  R1940     3.2963702082633972e-01
    phi[3,7]  R1941     4.5905942097306252e-03
    phi[3,7]  R1942     1.2166296243667603e+00
    phi[3,7]  R1943     5.9750485420227051e-01
    phi[3,7]  R1944     8.0538213253021240e-01
    phi[3,7]  R1945     1.9378125667572021e+00
    phi[3,7]  R1946     2.0790770053863525e+00
    phi[3,7]  R1947     1.7048386335372925e+00
    phi[3,7]  R1948     1.6482667922973633e+00
    phi[3,7]  R1949     1.7414242029190063e+00
    phi[3,7]  R1950     2.5279121398925781e+00
    phi[3,7]  R1951     -4.4490702450275421e-02
    phi[3,7]  R1952     2.0533767342567444e-01
    phi[3,7]  R1953     7.6173257827758789e-01
    phi[3,7]  R1954     -0.847429096698761
    phi[3,7]  R1955     -2.7495008707046509e-01
    phi[3,7]  R1956     -1.2146545648574829e+00
    phi[3,7]  R1957     -1.3557885885238647e+00
    phi[3,7]  R1958     8.0339562892913818e-01
    phi[3,7]  R1959     -2.6922621726989746e+00
    phi[3,7]  R1960     -9.7602713108062744e-01
    phi[3,7]  R1961     -3.7119886279106140e-01
    phi[3,7]  R1962     -2.3485741615295410e+00
    phi[3,7]  R1963     -7.8629720211029053e-01
    phi[3,7]  R1964     4.7607097029685974e-01
    phi[3,7]  R1965     -1.6095542907714844e+00
    phi[3,7]  R1966     -2.1832215785980225e+00
    phi[3,7]  R1967     -1.8138754367828369e+00
    phi[3,7]  R1968     -2.6593339443206787e+00
    phi[3,7]  R1969     -2.5867209434509277e+00
    phi[3,7]  R1970     2.4291884899139404e-01
    phi[3,7]  R1971     -2.1750781536102295e+00
    phi[3,7]  R1972     1.4012350142002106e-01
    phi[3,7]  R1973     -2.3885660171508789e+00
    phi[3,7]  R1974     2.9597362875938416e-01
    phi[3,7]  R1975     2.6440870761871338e-01
    phi[3,7]  R1976     -1.4455686807632446e+00
    phi[3,7]  R1977     -1.4282138347625732e+00
    phi[3,7]  R1978     -2.8020324707031250e+00
    phi[3,7]  R1979     -2.0756087303161621e+00
    phi[3,7]  R1980     -2.3310575485229492e+00
    phi[3,7]  R1981     -2.3053517341613770e+00
    phi[3,7]  R1982     -1.8596346378326416e+00
    phi[3,7]  R1983     -1.1832216978073120e+00
    phi[7,3]  R27       -1
    phi[7,3]  R63       1
    phi[7,3]  R64       1
    phi[7,3]  R1984     -3.0999999046325684e+00
    phi[7,3]  R1985     -3.0999999046325684e+00
    phi[7,3]  R1986     -2.2400000095367432e+00
    phi[7,3]  R1987     -2.2400000095367432e+00
    phi[7,3]  R1988     -3.0999999046325684e+00
    phi[7,3]  R1989     -3.0999999046325684e+00
    phi[7,3]  R1990     -2.5699999332427979e+00
    phi[7,3]  R1991     -2.5699999332427979e+00
    phi[7,3]  R1992     -3.0999999046325684e+00
    phi[7,3]  R1993     -3.0999999046325684e+00
    phi[7,3]  R1994     -2.0899999141693115e+00
    phi[7,3]  R1995     -2.0899999141693115e+00
    phi[7,3]  R1996     -3.0999999046325684e+00
    phi[7,3]  R1997     -3.0999999046325684e+00
    phi[7,3]  R1998     8.0538213253021240e-01
    phi[7,3]  R1999     1.9378125667572021e+00
    phi[7,3]  R2000     2.0790770053863525e+00
    phi[7,3]  R2001     1.7048386335372925e+00
    phi[7,3]  R2002     1.6482667922973633e+00
    phi[7,3]  R2003     1.7414242029190063e+00
    phi[7,3]  R2004     2.5279121398925781e+00
    phi[7,3]  R2005     -4.4490702450275421e-02
    phi[7,3]  R2006     2.0533767342567444e-01
    phi[7,3]  R2007     7.6173257827758789e-01
    phi[7,3]  R2008     -0.847429096698761
    phi[7,3]  R2009     -2.7495008707046509e-01
    phi[7,3]  R2010     -1.2146545648574829e+00
    phi[7,3]  R2011     -1.3557885885238647e+00
    phi[7,3]  R2012     8.0339562892913818e-01
    phi[7,3]  R2013     -2.6922621726989746e+00
    phi[7,3]  R2014     -9.7602713108062744e-01
    phi[7,3]  R2015     -3.7119886279106140e-01
    phi[7,3]  R2016     -2.3485741615295410e+00
    phi[7,3]  R2017     -7.8629720211029053e-01
    phi[7,3]  R2018     4.7607097029685974e-01
    phi[7,3]  R2019     -1.6095542907714844e+00
    phi[7,3]  R2020     -2.1832215785980225e+00
    phi[7,3]  R2021     -1.8138754367828369e+00
    phi[7,3]  R2022     -2.6593339443206787e+00
    phi[7,3]  R2023     -2.5867209434509277e+00
    phi[7,3]  R2024     2.4291884899139404e-01
    phi[7,3]  R2025     -2.1750781536102295e+00
    phi[7,3]  R2026     1.4012350142002106e-01
    phi[7,3]  R2027     -2.3885660171508789e+00
    phi[7,3]  R2028     2.9597362875938416e-01
    phi[7,3]  R2029     2.6440870761871338e-01
    phi[7,3]  R2030     -1.4455686807632446e+00
    phi[7,3]  R2031     -1.4282138347625732e+00
    phi[7,3]  R2032     -2.8020324707031250e+00
    phi[7,3]  R2033     -2.0756087303161621e+00
    phi[7,3]  R2034     -2.3310575485229492e+00
    phi[7,3]  R2035     -2.3053517341613770e+00
    phi[7,3]  R2036     -1.8596346378326416e+00
    phi[7,3]  R2037     -1.1832216978073120e+00
    phi[7,3]  R2038     1.3132629394531250e+00
    phi[7,3]  R2039     5.9209907054901123e-01
    phi[7,3]  R2040     1.4335892200469971e+00
    phi[7,3]  R2041     2.8268089294433594e+00
    phi[7,3]  R2042     2.2504229545593262e+00
    phi[7,3]  R2043     1.9293751716613770e+00
    phi[7,3]  R2044     1.5463392734527588e+00
    phi[7,3]  R2045     -3.1073608994483948e-01
    phi[7,3]  R2046     -3.1540915369987488e-01
    phi[7,3]  R2047     3.8748973608016968e-01
    phi[7,3]  R2048     -1.0358899831771851e+00
    phi[7,3]  R2049     -1.6490143537521362e+00
    phi[7,3]  R2050     -1.7502099275588989e+00
    phi[7,3]  R2051     -1.8528970479965210e+00
    phi[7,3]  R2052     -0.154770627617836
    phi[7,3]  R2053     0.503047525882721
    phi[7,3]  R2054     -2.3411171436309814e+00
    phi[7,3]  R2055     -1.5184706449508667e+00
    phi[7,3]  R2056     -2.0552301406860352e+00
    phi[7,3]  R2057     -3.0953278541564941e+00
    phi[7,3]  R2058     -1.5549764633178711e+00
    phi[7,3]  R2059     -8.9567416906356812e-01
    phi[7,3]  R2060     -2.1195132732391357e+00
    phi[7,3]  R2061     -1.0136455297470093e+00
    phi[7,3]  R2062     -2.1495256423950195e+00
    phi[7,3]  R2063     -3.9254549145698547e-01
    phi[7,3]  R2064     -1.0671377182006836e+00
    phi[7,3]  R2065     -1.8839714527130127e+00
    phi[7,3]  R2066     9.7120665013790131e-03
    phi[7,3]  R2067     -1.3727135658264160e+00
    phi[7,3]  R2068     -8.7287724018096924e-03
    phi[7,3]  R2069     -1.3634074926376343e+00
    phi[7,3]  R2070     -3.1052780151367188e-01
    phi[7,3]  R2071     6.4304918050765991e-01
    phi[7,3]  R2072     -9.6809273958206177e-01
    phi[7,3]  R2073     -5.4477047920227051e-01
    phi[7,3]  R2074     3.2963702082633972e-01
    phi[7,3]  R2075     4.5905942097306252e-03
    phi[7,3]  R2076     1.2166296243667603e+00
    phi[7,3]  R2077     5.9750485420227051e-01
    phi[3,9]  R27       1
    phi[3,9]  R28       1
    phi[3,9]  R29       -1.6078156894763307e-01
    phi[3,9]  R30       8.2505627710863561e-02
    phi[3,9]  R31       -8.4987547698228161e-01
    phi[3,9]  R32       1.8815668677009914e+00
    phi[3,9]  R33       2.8702099755595842e+00
    phi[3,9]  R34       1.6610677775870315e+00
    phi[3,9]  R35       1.3381563446877955e+00
    phi[3,9]  R73       -1
    phi[3,9]  R2078     -3.2607814735802014e+00
    phi[3,9]  R2079     -2.9392183356849353e+00
    phi[3,9]  R2080     -2.1574943818258796e+00
    phi[3,9]  R2081     -2.3225056372476067e+00
    phi[3,9]  R2082     -3.94987538161485
    phi[3,9]  R2083     -2.2501244276502868e+00
    phi[3,9]  R2084     -6.8843306554180650e-01
    phi[3,9]  R2085     -4.4515668009437892e+00
    phi[3,9]  R2086     -2.2978992907298412e-01
    phi[3,9]  R2087     -5.9702098801921526e+00
    phi[3,9]  R2088     -0.42893213658228
    phi[3,9]  R2089     -3.7510676917563428e+00
    phi[3,9]  R2090     -1.7618435599447728e+00
    phi[3,9]  R2091     -4.4381562493203637e+00
    phi[3,9]  R2092     -9.2763369438392473e-02
    phi[3,9]  R2093     -9.8292219470236808e-02
    phi[3,9]  R2094     -1.0063804665846687e-01
    phi[3,9]  R2095     -1.0099218375110786e-01
    phi[3,9]  R2096     -1.0261823873736597e-01
    phi[3,9]  R2097     -1.0654674916010443e-01
    phi[3,9]  R2098     -1.1677778520192428e-01
    phi[3,9]  R2099     -7.5282519183976360e-01
    phi[3,9]  R2100     -2.2159709368376734e-01
    phi[3,9]  R2101     -2.2902399143095864e-01
    phi[3,9]  R2102     -3.3932083808998914e-01
    phi[3,9]  R2103     -3.6555960073620719e-01
    phi[3,9]  R2104     -3.8681203191231694e-01
    phi[3,9]  R2105     -3.8988773113578312e-01
    phi[3,9]  R2106     -4.0281728380891152e-01
    phi[3,9]  R2107     -4.0433376544100896e-01
    phi[3,9]  R2108     -4.0692766326965990e-01
    phi[3,9]  R2109     -4.0799159050392997e-01
    phi[3,9]  R2110     -4.2318378246889732e-01
    phi[3,9]  R2111     -4.3627885381193110e-01
    phi[3,9]  R2112     -2.7428951922922606e-01
    phi[3,9]  R2113     -2.8099111897695261e-01
    phi[3,9]  R2114     -3.1452808607577820e-01
    phi[3,9]  R2115     -6.1812153609434606e-01
    phi[3,9]  R2116     -8.3562398093883261e-01
    phi[3,9]  R2117     -3.4002476080363231e-01
    phi[3,9]  R2118     -1.2535010402883995e+00
    phi[3,9]  R2119     -3.7491373509251980e-01
    phi[3,9]  R2120     -3.7493033064436576e-01
    phi[3,9]  R2121     -3.7991282002246551e-01
    phi[3,9]  R2122     -5.6003674210192078e-01
    phi[3,9]  R2123     -2.6156408252299945e-01
    phi[3,9]  R2124     -2.6713704862601073e-01
    phi[3,9]  R2125     -6.4525123525443284e-01
    phi[3,9]  R2126     -2.7881407217377518e-01
    phi[3,9]  R2127     -2.9424769462723988e-01
    phi[3,9]  R2128     -2.9654083675854370e-01
    phi[3,9]  R2129     -2.9701963636576739e-01
    phi[3,9]  R2130     -3.0434467156448552e-01
    phi[3,9]  R2131     -3.0663537344495440e-01
    phi[4,5]  R36       1
    phi[4,5]  R37       1
    phi[4,5]  R45       -1
    phi[4,5]  R2132     -3.0999999046325684e+00
    phi[4,5]  R2133     -3.0999999046325684e+00
    phi[4,5]  R2134     -2.2400000095367432e+00
    phi[4,5]  R2135     -2.2400000095367432e+00
    phi[4,5]  R2136     -3.0999999046325684e+00
    phi[4,5]  R2137     -3.0999999046325684e+00
    phi[4,5]  R2138     -2.5699999332427979e+00
    phi[4,5]  R2139     -2.5699999332427979e+00
    phi[4,5]  R2140     -3.0999999046325684e+00
    phi[4,5]  R2141     -3.0999999046325684e+00
    phi[4,5]  R2142     -2.0899999141693115e+00
    phi[4,5]  R2143     -2.0899999141693115e+00
    phi[4,5]  R2144     -3.0999999046325684e+00
    phi[4,5]  R2145     -3.0999999046325684e+00
    phi[4,5]  R2146     1.1150593757629395e+00
    phi[4,5]  R2147     3.3309084177017212e-01
    phi[4,5]  R2148     1.2419869899749756e+00
    phi[4,5]  R2149     0.728791356086731
    phi[4,5]  R2150     7.6842325925827026e-01
    phi[4,5]  R2151     2.0779460668563843e-02
    phi[4,5]  R2152     2.6512444019317627e-01
    phi[4,5]  R2153     1.8616312742233276e+00
    phi[4,5]  R2154     1.28358793258667
    phi[4,5]  R2155     -1.3091965913772583e+00
    phi[4,5]  R2156     -1.7219940423965454e+00
    phi[4,5]  R2157     -3.5932448506355286e-01
    phi[4,5]  R2158     -2.9508392810821533e+00
    phi[4,5]  R2159     -2.7252867221832275e+00
    phi[4,5]  R2160     -2.0521202087402344e+00
    phi[4,5]  R2161     -2.5044696331024170e+00
    phi[4,5]  R2162     3.2158738374710083e-01
    phi[4,5]  R2163     2.6838254928588867e-01
    phi[4,5]  R2164     -1.4843361377716064e+00
    phi[4,5]  R2165     -1.2136816978454590e+00
    phi[4,5]  R2166     9.6797335147857666e-01
    phi[4,5]  R2167     1.9853407144546509e+00
    phi[4,5]  R2168     9.9929773807525635e-01
    phi[4,5]  R2169     1.0713571310043335e+00
    phi[4,5]  R2170     4.4302535057067871e-01
    phi[4,5]  R2171     2.5828036665916443e-01
    phi[4,5]  R2172     1.4327461719512939e+00
    phi[4,5]  R2173     2.5175604224205017e-01
    phi[4,5]  R2174     7.7759909629821777e-01
    phi[4,5]  R2175     4.3319219350814819e-01
    phi[4,5]  R2176     -1.9167469739913940e+00
    phi[4,5]  R2177     -1.6906956434249878e+00
    phi[4,5]  R2178     -1.6558649539947510e+00
    phi[4,5]  R2179     -1.5378329753875732e+00
    phi[4,5]  R2180     -2.2091202735900879e+00
    phi[4,5]  R2181     -1.7884228229522705e+00
    phi[4,5]  R2182     -5.3868192434310913e-01
    phi[4,5]  R2183     -6.3095498085021973e-01
    phi[4,5]  R2184     -9.2647832632064819e-01
    phi[4,5]  R2185     -1.09926438331604
    phi[4,5]  R2186     -9.4597154855728149e-01
    phi[4,5]  R2187     -4.6445050835609436e-01
    phi[4,5]  R2188     -7.9716169834136963e-01
    phi[4,5]  R2189     -9.3050795793533325e-01
    phi[4,5]  R2190     -1.3097333908081055e+00
    phi[4,5]  R2191     -1.0196890830993652e+00
    phi[4,5]  R2192     -1.7185614109039307e+00
    phi[4,5]  R2193     -1.7277870327234268e-02
    phi[4,5]  R2194     -3.7796512246131897e-01
    phi[4,5]  R2195     7.0352292060852051e-01
    phi[4,5]  R2196     9.8357729613780975e-02
    phi[4,5]  R2197     -1.1302938461303711e+00
    phi[4,5]  R2198     -6.9745355844497681e-01
    phi[4,5]  R2199     -1.2573032379150391e+00
    phi[4,5]  R2200     -1.4541997909545898e+00
    phi[4,5]  R2201     -2.13244891166687
    phi[5,4]  R36       -1
    phi[5,4]  R45       1
    phi[5,4]  R46       1
    phi[5,4]  R2202     -3.0999999046325684e+00
    phi[5,4]  R2203     -3.0999999046325684e+00
    phi[5,4]  R2204     -2.2400000095367432e+00
    phi[5,4]  R2205     -2.2400000095367432e+00
    phi[5,4]  R2206     -3.0999999046325684e+00
    phi[5,4]  R2207     -3.0999999046325684e+00
    phi[5,4]  R2208     -2.5699999332427979e+00
    phi[5,4]  R2209     -2.5699999332427979e+00
    phi[5,4]  R2210     -3.0999999046325684e+00
    phi[5,4]  R2211     -3.0999999046325684e+00
    phi[5,4]  R2212     -2.0899999141693115e+00
    phi[5,4]  R2213     -2.0899999141693115e+00
    phi[5,4]  R2214     -3.0999999046325684e+00
    phi[5,4]  R2215     -3.0999999046325684e+00
    phi[5,4]  R2216     9.6797335147857666e-01
    phi[5,4]  R2217     1.9853407144546509e+00
    phi[5,4]  R2218     9.9929773807525635e-01
    phi[5,4]  R2219     1.0713571310043335e+00
    phi[5,4]  R2220     4.4302535057067871e-01
    phi[5,4]  R2221     2.5828036665916443e-01
    phi[5,4]  R2222     1.4327461719512939e+00
    phi[5,4]  R2223     2.5175604224205017e-01
    phi[5,4]  R2224     7.7759909629821777e-01
    phi[5,4]  R2225     4.3319219350814819e-01
    phi[5,4]  R2226     -1.9167469739913940e+00
    phi[5,4]  R2227     -1.6906956434249878e+00
    phi[5,4]  R2228     -1.6558649539947510e+00
    phi[5,4]  R2229     -1.5378329753875732e+00
    phi[5,4]  R2230     -2.2091202735900879e+00
    phi[5,4]  R2231     -1.7884228229522705e+00
    phi[5,4]  R2232     -5.3868192434310913e-01
    phi[5,4]  R2233     -6.3095498085021973e-01
    phi[5,4]  R2234     -9.2647832632064819e-01
    phi[5,4]  R2235     -1.09926438331604
    phi[5,4]  R2236     -9.4597154855728149e-01
    phi[5,4]  R2237     -4.6445050835609436e-01
    phi[5,4]  R2238     -7.9716169834136963e-01
    phi[5,4]  R2239     -9.3050795793533325e-01
    phi[5,4]  R2240     -1.3097333908081055e+00
    phi[5,4]  R2241     -1.0196890830993652e+00
    phi[5,4]  R2242     -1.7185614109039307e+00
    phi[5,4]  R2243     -1.7277870327234268e-02
    phi[5,4]  R2244     -3.7796512246131897e-01
    phi[5,4]  R2245     7.0352292060852051e-01
    phi[5,4]  R2246     9.8357729613780975e-02
    phi[5,4]  R2247     -1.1302938461303711e+00
    phi[5,4]  R2248     -6.9745355844497681e-01
    phi[5,4]  R2249     -1.2573032379150391e+00
    phi[5,4]  R2250     -1.4541997909545898e+00
    phi[5,4]  R2251     -2.13244891166687
    phi[5,4]  R2252     1.1150593757629395e+00
    phi[5,4]  R2253     3.3309084177017212e-01
    phi[5,4]  R2254     1.2419869899749756e+00
    phi[5,4]  R2255     0.728791356086731
    phi[5,4]  R2256     7.6842325925827026e-01
    phi[5,4]  R2257     2.0779460668563843e-02
    phi[5,4]  R2258     2.6512444019317627e-01
    phi[5,4]  R2259     1.8616312742233276e+00
    phi[5,4]  R2260     1.28358793258667
    phi[5,4]  R2261     -1.3091965913772583e+00
    phi[5,4]  R2262     -1.7219940423965454e+00
    phi[5,4]  R2263     -3.5932448506355286e-01
    phi[5,4]  R2264     -2.9508392810821533e+00
    phi[5,4]  R2265     -2.7252867221832275e+00
    phi[5,4]  R2266     -2.0521202087402344e+00
    phi[5,4]  R2267     -2.5044696331024170e+00
    phi[5,4]  R2268     3.2158738374710083e-01
    phi[5,4]  R2269     2.6838254928588867e-01
    phi[5,4]  R2270     -1.4843361377716064e+00
    phi[5,4]  R2271     -1.2136816978454590e+00
    phi[8,4]  R36       -1
    phi[8,4]  R38       7.0228414596440913e-02
    phi[8,4]  R39       5.4910706062212711e-02
    phi[8,4]  R40       2.0952565097815068e-01
    phi[8,4]  R41       -1.8869161085578066e+00
    phi[8,4]  R42       -6.5481283780954147e-01
    phi[8,4]  R43       -1.8866424625401128e+00
    phi[8,4]  R44       2.9328268902393275e+00
    phi[8,4]  R72       1
    phi[8,4]  R2272     -3.1702283192290093e+00
    phi[8,4]  R2273     -3.0297714900361274e+00
    phi[8,4]  R2274     -2.2949107155989559e+00
    phi[8,4]  R2275     -2.1850893034745305e+00
    phi[8,4]  R2276     -3.3095255556107190e+00
    phi[8,4]  R2277     -2.8904742536544177e+00
    phi[8,4]  R2278     -6.8308382468499129e-01
    phi[8,4]  R2279     -4.4569160418006044e+00
    phi[8,4]  R2280     -2.4451870668230269e+00
    phi[8,4]  R2281     -3.75481274244211
    phi[8,4]  R2282     -2.0335745162919872e-01
    phi[8,4]  R2283     -3.9766423767094246e+00
    phi[8,4]  R2284     -6.0328267948718963e+00
    phi[8,4]  R2285     -1.6717301439324084e-01
    phi[8,4]  R2286     -2.7302382376846124e-02
    phi[8,4]  R2287     -2.9011516916215285e-02
    phi[8,4]  R2288     -3.2727796572160184e-02
    phi[8,4]  R2289     -8.0016689064475455e-02
    phi[8,4]  R2290     -1.4216686127122791e-01
    phi[8,4]  R2291     -1.5549859083035644e-01
    phi[8,4]  R2292     -1.6406405848812766e-01
    phi[8,4]  R2293     -1.7170230454347690e-01
    phi[8,4]  R2294     -1.7233140577283645e-01
    phi[8,4]  R2295     -1.7346732319936087e-01
    phi[8,4]  R2296     -6.7472747943609246e-02
    phi[8,4]  R2297     -8.9175867140589116e-02
    phi[8,4]  R2298     -1.2143115832321305e-01
    phi[8,4]  R2299     -1.3345398531728403e-01
    phi[8,4]  R2300     -1.3808868649793204e-01
    phi[8,4]  R2301     -1.3954515292088665e-01
    phi[8,4]  R2302     -2.0068274206355741e-01
    phi[8,4]  R2303     -2.4656853503045939e-01
    phi[8,4]  R2304     -2.9489663409503786e-01
    phi[8,4]  R2305     -3.5847330307230063e-01
    phi[5,6]  R45       1
    phi[5,6]  R46       1
    phi[5,6]  R54       -1
    phi[5,6]  R2306     -3.0999999046325684e+00
    phi[5,6]  R2307     -3.0999999046325684e+00
    phi[5,6]  R2308     -2.2400000095367432e+00
    phi[5,6]  R2309     -2.2400000095367432e+00
    phi[5,6]  R2310     -3.0999999046325684e+00
    phi[5,6]  R2311     -3.0999999046325684e+00
    phi[5,6]  R2312     -2.5699999332427979e+00
    phi[5,6]  R2313     -2.5699999332427979e+00
    phi[5,6]  R2314     -3.0999999046325684e+00
    phi[5,6]  R2315     -3.0999999046325684e+00
    phi[5,6]  R2316     -2.0899999141693115e+00
    phi[5,6]  R2317     -2.0899999141693115e+00
    phi[5,6]  R2318     -3.0999999046325684e+00
    phi[5,6]  R2319     -3.0999999046325684e+00
    phi[5,6]  R2320     9.6797335147857666e-01
    phi[5,6]  R2321     1.9853407144546509e+00
    phi[5,6]  R2322     9.9929773807525635e-01
    phi[5,6]  R2323     1.0713571310043335e+00
    phi[5,6]  R2324     4.4302535057067871e-01
    phi[5,6]  R2325     2.5828036665916443e-01
    phi[5,6]  R2326     1.4327461719512939e+00
    phi[5,6]  R2327     2.5175604224205017e-01
    phi[5,6]  R2328     7.7759909629821777e-01
    phi[5,6]  R2329     4.3319219350814819e-01
    phi[5,6]  R2330     -1.9167469739913940e+00
    phi[5,6]  R2331     -1.6906956434249878e+00
    phi[5,6]  R2332     -1.6558649539947510e+00
    phi[5,6]  R2333     -1.5378329753875732e+00
    phi[5,6]  R2334     -2.2091202735900879e+00
    phi[5,6]  R2335     -1.7884228229522705e+00
    phi[5,6]  R2336     -5.3868192434310913e-01
    phi[5,6]  R2337     -6.3095498085021973e-01
    phi[5,6]  R2338     -9.2647832632064819e-01
    phi[5,6]  R2339     -1.09926438331604
    phi[5,6]  R2340     -9.4597154855728149e-01
    phi[5,6]  R2341     -4.6445050835609436e-01
    phi[5,6]  R2342     -7.9716169834136963e-01
    phi[5,6]  R2343     -9.3050795793533325e-01
    phi[5,6]  R2344     -1.3097333908081055e+00
    phi[5,6]  R2345     -1.0196890830993652e+00
    phi[5,6]  R2346     -1.7185614109039307e+00
    phi[5,6]  R2347     -1.7277870327234268e-02
    phi[5,6]  R2348     -3.7796512246131897e-01
    phi[5,6]  R2349     7.0352292060852051e-01
    phi[5,6]  R2350     9.8357729613780975e-02
    phi[5,6]  R2351     -1.1302938461303711e+00
    phi[5,6]  R2352     -6.9745355844497681e-01
    phi[5,6]  R2353     -1.2573032379150391e+00
    phi[5,6]  R2354     -1.4541997909545898e+00
    phi[5,6]  R2355     -2.13244891166687
    phi[5,6]  R2356     1.3158118724822998e+00
    phi[5,6]  R2357     1.0136498212814331e+00
    phi[5,6]  R2358     1.6971484422683716e+00
    phi[5,6]  R2359     -0.00740637443959713
    phi[5,6]  R2360     -1.1320413351058960e+00
    phi[5,6]  R2361     1.2587369680404663e+00
    phi[5,6]  R2362     2.8136524558067322e-01
    phi[5,6]  R2363     1.8806435167789459e-01
    phi[5,6]  R2364     -0.626270592212677
    phi[5,6]  R2365     -1.2289618700742722e-01
    phi[5,6]  R2366     -1.1546353101730347e+00
    phi[5,6]  R2367     -1.1861183643341064e+00
    phi[5,6]  R2368     -8.3952236175537109e-01
    phi[5,6]  R2369     -9.8340153694152832e-01
    phi[5,6]  R2370     -1.6373997926712036e+00
    phi[5,6]  R2371     -7.5717383623123169e-01
    phi[5,6]  R2372     -0.738964319229126
    phi[5,6]  R2373     -2.4987680912017822e+00
    phi[5,6]  R2374     -1.2792247533798218e+00
    phi[5,6]  R2375     -1.2742787599563599e+00
    phi[5,6]  R2376     -1.7653902769088745e+00
    phi[5,6]  R2377     -2.6553840637207031e+00
    phi[5,6]  R2378     -1.7547312974929810e+00
    phi[5,6]  R2379     -2.4235565662384033e+00
    phi[5,6]  R2380     -1.5518461465835571e+00
    phi[5,6]  R2381     -1.7951462268829346e+00
    phi[5,6]  R2382     -1.7648845911026
    phi[5,6]  R2383     -1.2291798591613770e+00
    phi[5,6]  R2384     -9.1166895627975464e-01
    phi[5,6]  R2385     -1.5914812088012695e+00
    phi[5,6]  R2386     -1.6912870407104492e+00
    phi[5,6]  R2387     -2.2351670265197754e+00
    phi[5,6]  R2388     -1.6432310342788696e+00
    phi[5,6]  R2389     -9.1125357151031494e-01
    phi[5,6]  R2390     -2.2653753757476807e+00
    phi[5,6]  R2391     -2.4446706473827362e-01
    phi[5,6]  R2392     -2.8012716770172119e-01
    phi[5,6]  R2393     -1.0967670679092407e+00
    phi[5,6]  R2394     9.6231400966644287e-02
    phi[5,6]  R2395     -1.8381308317184448e+00
    phi[5,6]  R2396     -7.7290922403335571e-01
    phi[5,6]  R2397     -1.5832005739212036e+00
    phi[5,6]  R2398     -3.1118106842041016e-01
    phi[5,6]  R2399     -5.6111347675323486e-01
    phi[5,6]  R2400     -1.0217463970184326e+00
    phi[5,6]  R2401     -1.5180538892745972e+00
    phi[5,6]  R2402     -1.3807417154312134e+00
    phi[5,6]  R2403     -7.0455574989318848e-01
    phi[5,6]  R2404     -1.4603086709976196e+00
    phi[5,6]  R2405     -9.5732325315475464e-01
    phi[5,6]  R2406     -1.9040203094482422e+00
    phi[5,6]  R2407     -4.7447791695594788e-01
    phi[5,6]  R2408     -1.9068344831466675e+00
    phi[5,6]  R2409     -7.2076320648193359e-01
    phi[5,6]  R2410     7.0202302932739258e-01
    phi[5,6]  R2411     4.7585070133209229e-02
    phi[5,6]  R2412     -1.6228001117706299e+00
    phi[6,5]  R45       -1
    phi[6,5]  R54       1
    phi[6,5]  R55       1
    phi[6,5]  R2413     -3.0999999046325684e+00
    phi[6,5]  R2414     -3.0999999046325684e+00
    phi[6,5]  R2415     -2.2400000095367432e+00
    phi[6,5]  R2416     -2.2400000095367432e+00
    phi[6,5]  R2417     -3.0999999046325684e+00
    phi[6,5]  R2418     -3.0999999046325684e+00
    phi[6,5]  R2419     -2.5699999332427979e+00
    phi[6,5]  R2420     -2.5699999332427979e+00
    phi[6,5]  R2421     -3.0999999046325684e+00
    phi[6,5]  R2422     -3.0999999046325684e+00
    phi[6,5]  R2423     -2.0899999141693115e+00
    phi[6,5]  R2424     -2.0899999141693115e+00
    phi[6,5]  R2425     -3.0999999046325684e+00
    phi[6,5]  R2426     -3.0999999046325684e+00
    phi[6,5]  R2427     1.3158118724822998e+00
    phi[6,5]  R2428     1.0136498212814331e+00
    phi[6,5]  R2429     1.6971484422683716e+00
    phi[6,5]  R2430     -0.00740637443959713
    phi[6,5]  R2431     -1.1320413351058960e+00
    phi[6,5]  R2432     1.2587369680404663e+00
    phi[6,5]  R2433     2.8136524558067322e-01
    phi[6,5]  R2434     1.8806435167789459e-01
    phi[6,5]  R2435     -0.626270592212677
    phi[6,5]  R2436     -1.2289618700742722e-01
    phi[6,5]  R2437     -1.1546353101730347e+00
    phi[6,5]  R2438     -1.1861183643341064e+00
    phi[6,5]  R2439     -8.3952236175537109e-01
    phi[6,5]  R2440     -9.8340153694152832e-01
    phi[6,5]  R2441     -1.6373997926712036e+00
    phi[6,5]  R2442     -7.5717383623123169e-01
    phi[6,5]  R2443     -0.738964319229126
    phi[6,5]  R2444     -2.4987680912017822e+00
    phi[6,5]  R2445     -1.2792247533798218e+00
    phi[6,5]  R2446     -1.2742787599563599e+00
    phi[6,5]  R2447     -1.7653902769088745e+00
    phi[6,5]  R2448     -2.6553840637207031e+00
    phi[6,5]  R2449     -1.7547312974929810e+00
    phi[6,5]  R2450     -2.4235565662384033e+00
    phi[6,5]  R2451     -1.5518461465835571e+00
    phi[6,5]  R2452     -1.7951462268829346e+00
    phi[6,5]  R2453     -1.7648845911026
    phi[6,5]  R2454     -1.2291798591613770e+00
    phi[6,5]  R2455     -9.1166895627975464e-01
    phi[6,5]  R2456     -1.5914812088012695e+00
    phi[6,5]  R2457     -1.6912870407104492e+00
    phi[6,5]  R2458     -2.2351670265197754e+00
    phi[6,5]  R2459     -1.6432310342788696e+00
    phi[6,5]  R2460     -9.1125357151031494e-01
    phi[6,5]  R2461     -2.2653753757476807e+00
    phi[6,5]  R2462     -2.4446706473827362e-01
    phi[6,5]  R2463     -2.8012716770172119e-01
    phi[6,5]  R2464     -1.0967670679092407e+00
    phi[6,5]  R2465     9.6231400966644287e-02
    phi[6,5]  R2466     -1.8381308317184448e+00
    phi[6,5]  R2467     -7.7290922403335571e-01
    phi[6,5]  R2468     -1.5832005739212036e+00
    phi[6,5]  R2469     -3.1118106842041016e-01
    phi[6,5]  R2470     -5.6111347675323486e-01
    phi[6,5]  R2471     -1.0217463970184326e+00
    phi[6,5]  R2472     -1.5180538892745972e+00
    phi[6,5]  R2473     -1.3807417154312134e+00
    phi[6,5]  R2474     -7.0455574989318848e-01
    phi[6,5]  R2475     -1.4603086709976196e+00
    phi[6,5]  R2476     -9.5732325315475464e-01
    phi[6,5]  R2477     -1.9040203094482422e+00
    phi[6,5]  R2478     -4.7447791695594788e-01
    phi[6,5]  R2479     -1.9068344831466675e+00
    phi[6,5]  R2480     -7.2076320648193359e-01
    phi[6,5]  R2481     7.0202302932739258e-01
    phi[6,5]  R2482     4.7585070133209229e-02
    phi[6,5]  R2483     -1.6228001117706299e+00
    phi[6,5]  R2484     9.6797335147857666e-01
    phi[6,5]  R2485     1.9853407144546509e+00
    phi[6,5]  R2486     9.9929773807525635e-01
    phi[6,5]  R2487     1.0713571310043335e+00
    phi[6,5]  R2488     4.4302535057067871e-01
    phi[6,5]  R2489     2.5828036665916443e-01
    phi[6,5]  R2490     1.4327461719512939e+00
    phi[6,5]  R2491     2.5175604224205017e-01
    phi[6,5]  R2492     7.7759909629821777e-01
    phi[6,5]  R2493     4.3319219350814819e-01
    phi[6,5]  R2494     -1.9167469739913940e+00
    phi[6,5]  R2495     -1.6906956434249878e+00
    phi[6,5]  R2496     -1.6558649539947510e+00
    phi[6,5]  R2497     -1.5378329753875732e+00
    phi[6,5]  R2498     -2.2091202735900879e+00
    phi[6,5]  R2499     -1.7884228229522705e+00
    phi[6,5]  R2500     -5.3868192434310913e-01
    phi[6,5]  R2501     -6.3095498085021973e-01
    phi[6,5]  R2502     -9.2647832632064819e-01
    phi[6,5]  R2503     -1.09926438331604
    phi[6,5]  R2504     -9.4597154855728149e-01
    phi[6,5]  R2505     -4.6445050835609436e-01
    phi[6,5]  R2506     -7.9716169834136963e-01
    phi[6,5]  R2507     -9.3050795793533325e-01
    phi[6,5]  R2508     -1.3097333908081055e+00
    phi[6,5]  R2509     -1.0196890830993652e+00
    phi[6,5]  R2510     -1.7185614109039307e+00
    phi[6,5]  R2511     -1.7277870327234268e-02
    phi[6,5]  R2512     -3.7796512246131897e-01
    phi[6,5]  R2513     7.0352292060852051e-01
    phi[6,5]  R2514     9.8357729613780975e-02
    phi[6,5]  R2515     -1.1302938461303711e+00
    phi[6,5]  R2516     -6.9745355844497681e-01
    phi[6,5]  R2517     -1.2573032379150391e+00
    phi[6,5]  R2518     -1.4541997909545898e+00
    phi[6,5]  R2519     -2.13244891166687
    phi[6,7]  R54       1
    phi[6,7]  R55       1
    phi[6,7]  R63       -1
    phi[6,7]  R2520     -3.0999999046325684e+00
    phi[6,7]  R2521     -3.0999999046325684e+00
    phi[6,7]  R2522     -2.2400000095367432e+00
    phi[6,7]  R2523     -2.2400000095367432e+00
    phi[6,7]  R2524     -3.0999999046325684e+00
    phi[6,7]  R2525     -3.0999999046325684e+00
    phi[6,7]  R2526     -2.5699999332427979e+00
    phi[6,7]  R2527     -2.5699999332427979e+00
    phi[6,7]  R2528     -3.0999999046325684e+00
    phi[6,7]  R2529     -3.0999999046325684e+00
    phi[6,7]  R2530     -2.0899999141693115e+00
    phi[6,7]  R2531     -2.0899999141693115e+00
    phi[6,7]  R2532     -3.0999999046325684e+00
    phi[6,7]  R2533     -3.0999999046325684e+00
    phi[6,7]  R2534     1.3158118724822998e+00
    phi[6,7]  R2535     1.0136498212814331e+00
    phi[6,7]  R2536     1.6971484422683716e+00
    phi[6,7]  R2537     -0.00740637443959713
    phi[6,7]  R2538     -1.1320413351058960e+00
    phi[6,7]  R2539     1.2587369680404663e+00
    phi[6,7]  R2540     2.8136524558067322e-01
    phi[6,7]  R2541     1.8806435167789459e-01
    phi[6,7]  R2542     -0.626270592212677
    phi[6,7]  R2543     -1.2289618700742722e-01
    phi[6,7]  R2544     -1.1546353101730347e+00
    phi[6,7]  R2545     -1.1861183643341064e+00
    phi[6,7]  R2546     -8.3952236175537109e-01
    phi[6,7]  R2547     -9.8340153694152832e-01
    phi[6,7]  R2548     -1.6373997926712036e+00
    phi[6,7]  R2549     -7.5717383623123169e-01
    phi[6,7]  R2550     -0.738964319229126
    phi[6,7]  R2551     -2.4987680912017822e+00
    phi[6,7]  R2552     -1.2792247533798218e+00
    phi[6,7]  R2553     -1.2742787599563599e+00
    phi[6,7]  R2554     -1.7653902769088745e+00
    phi[6,7]  R2555     -2.6553840637207031e+00
    phi[6,7]  R2556     -1.7547312974929810e+00
    phi[6,7]  R2557     -2.4235565662384033e+00
    phi[6,7]  R2558     -1.5518461465835571e+00
    phi[6,7]  R2559     -1.7951462268829346e+00
    phi[6,7]  R2560     -1.7648845911026
    phi[6,7]  R2561     -1.2291798591613770e+00
    phi[6,7]  R2562     -9.1166895627975464e-01
    phi[6,7]  R2563     -1.5914812088012695e+00
    phi[6,7]  R2564     -1.6912870407104492e+00
    phi[6,7]  R2565     -2.2351670265197754e+00
    phi[6,7]  R2566     -1.6432310342788696e+00
    phi[6,7]  R2567     -9.1125357151031494e-01
    phi[6,7]  R2568     -2.2653753757476807e+00
    phi[6,7]  R2569     -2.4446706473827362e-01
    phi[6,7]  R2570     -2.8012716770172119e-01
    phi[6,7]  R2571     -1.0967670679092407e+00
    phi[6,7]  R2572     9.6231400966644287e-02
    phi[6,7]  R2573     -1.8381308317184448e+00
    phi[6,7]  R2574     -7.7290922403335571e-01
    phi[6,7]  R2575     -1.5832005739212036e+00
    phi[6,7]  R2576     -3.1118106842041016e-01
    phi[6,7]  R2577     -5.6111347675323486e-01
    phi[6,7]  R2578     -1.0217463970184326e+00
    phi[6,7]  R2579     -1.5180538892745972e+00
    phi[6,7]  R2580     -1.3807417154312134e+00
    phi[6,7]  R2581     -7.0455574989318848e-01
    phi[6,7]  R2582     -1.4603086709976196e+00
    phi[6,7]  R2583     -9.5732325315475464e-01
    phi[6,7]  R2584     -1.9040203094482422e+00
    phi[6,7]  R2585     -4.7447791695594788e-01
    phi[6,7]  R2586     -1.9068344831466675e+00
    phi[6,7]  R2587     -7.2076320648193359e-01
    phi[6,7]  R2588     7.0202302932739258e-01
    phi[6,7]  R2589     4.7585070133209229e-02
    phi[6,7]  R2590     -1.6228001117706299e+00
    phi[6,7]  R2591     8.0538213253021240e-01
    phi[6,7]  R2592     1.9378125667572021e+00
    phi[6,7]  R2593     2.0790770053863525e+00
    phi[6,7]  R2594     1.7048386335372925e+00
    phi[6,7]  R2595     1.6482667922973633e+00
    phi[6,7]  R2596     1.7414242029190063e+00
    phi[6,7]  R2597     2.5279121398925781e+00
    phi[6,7]  R2598     -4.4490702450275421e-02
    phi[6,7]  R2599     2.0533767342567444e-01
    phi[6,7]  R2600     7.6173257827758789e-01
    phi[6,7]  R2601     -0.847429096698761
    phi[6,7]  R2602     -2.7495008707046509e-01
    phi[6,7]  R2603     -1.2146545648574829e+00
    phi[6,7]  R2604     -1.3557885885238647e+00
    phi[6,7]  R2605     8.0339562892913818e-01
    phi[6,7]  R2606     -2.6922621726989746e+00
    phi[6,7]  R2607     -9.7602713108062744e-01
    phi[6,7]  R2608     -3.7119886279106140e-01
    phi[6,7]  R2609     -2.3485741615295410e+00
    phi[6,7]  R2610     -7.8629720211029053e-01
    phi[6,7]  R2611     4.7607097029685974e-01
    phi[6,7]  R2612     -1.6095542907714844e+00
    phi[6,7]  R2613     -2.1832215785980225e+00
    phi[6,7]  R2614     -1.8138754367828369e+00
    phi[6,7]  R2615     -2.6593339443206787e+00
    phi[6,7]  R2616     -2.5867209434509277e+00
    phi[6,7]  R2617     2.4291884899139404e-01
    phi[6,7]  R2618     -2.1750781536102295e+00
    phi[6,7]  R2619     1.4012350142002106e-01
    phi[6,7]  R2620     -2.3885660171508789e+00
    phi[6,7]  R2621     2.9597362875938416e-01
    phi[6,7]  R2622     2.6440870761871338e-01
    phi[6,7]  R2623     -1.4455686807632446e+00
    phi[6,7]  R2624     -1.4282138347625732e+00
    phi[6,7]  R2625     -2.8020324707031250e+00
    phi[6,7]  R2626     -2.0756087303161621e+00
    phi[6,7]  R2627     -2.3310575485229492e+00
    phi[6,7]  R2628     -2.3053517341613770e+00
    phi[6,7]  R2629     -1.8596346378326416e+00
    phi[6,7]  R2630     -1.1832216978073120e+00
    phi[7,6]  R54       -1
    phi[7,6]  R63       1
    phi[7,6]  R64       1
    phi[7,6]  R2631     -3.0999999046325684e+00
    phi[7,6]  R2632     -3.0999999046325684e+00
    phi[7,6]  R2633     -2.2400000095367432e+00
    phi[7,6]  R2634     -2.2400000095367432e+00
    phi[7,6]  R2635     -3.0999999046325684e+00
    phi[7,6]  R2636     -3.0999999046325684e+00
    phi[7,6]  R2637     -2.5699999332427979e+00
    phi[7,6]  R2638     -2.5699999332427979e+00
    phi[7,6]  R2639     -3.0999999046325684e+00
    phi[7,6]  R2640     -3.0999999046325684e+00
    phi[7,6]  R2641     -2.0899999141693115e+00
    phi[7,6]  R2642     -2.0899999141693115e+00
    phi[7,6]  R2643     -3.0999999046325684e+00
    phi[7,6]  R2644     -3.0999999046325684e+00
    phi[7,6]  R2645     8.0538213253021240e-01
    phi[7,6]  R2646     1.9378125667572021e+00
    phi[7,6]  R2647     2.0790770053863525e+00
    phi[7,6]  R2648     1.7048386335372925e+00
    phi[7,6]  R2649     1.6482667922973633e+00
    phi[7,6]  R2650     1.7414242029190063e+00
    phi[7,6]  R2651     2.5279121398925781e+00
    phi[7,6]  R2652     -4.4490702450275421e-02
    phi[7,6]  R2653     2.0533767342567444e-01
    phi[7,6]  R2654     7.6173257827758789e-01
    phi[7,6]  R2655     -0.847429096698761
    phi[7,6]  R2656     -2.7495008707046509e-01
    phi[7,6]  R2657     -1.2146545648574829e+00
    phi[7,6]  R2658     -1.3557885885238647e+00
    phi[7,6]  R2659     8.0339562892913818e-01
    phi[7,6]  R2660     -2.6922621726989746e+00
    phi[7,6]  R2661     -9.7602713108062744e-01
    phi[7,6]  R2662     -3.7119886279106140e-01
    phi[7,6]  R2663     -2.3485741615295410e+00
    phi[7,6]  R2664     -7.8629720211029053e-01
    phi[7,6]  R2665     4.7607097029685974e-01
    phi[7,6]  R2666     -1.6095542907714844e+00
    phi[7,6]  R2667     -2.1832215785980225e+00
    phi[7,6]  R2668     -1.8138754367828369e+00
    phi[7,6]  R2669     -2.6593339443206787e+00
    phi[7,6]  R2670     -2.5867209434509277e+00
    phi[7,6]  R2671     2.4291884899139404e-01
    phi[7,6]  R2672     -2.1750781536102295e+00
    phi[7,6]  R2673     1.4012350142002106e-01
    phi[7,6]  R2674     -2.3885660171508789e+00
    phi[7,6]  R2675     2.9597362875938416e-01
    phi[7,6]  R2676     2.6440870761871338e-01
    phi[7,6]  R2677     -1.4455686807632446e+00
    phi[7,6]  R2678     -1.4282138347625732e+00
    phi[7,6]  R2679     -2.8020324707031250e+00
    phi[7,6]  R2680     -2.0756087303161621e+00
    phi[7,6]  R2681     -2.3310575485229492e+00
    phi[7,6]  R2682     -2.3053517341613770e+00
    phi[7,6]  R2683     -1.8596346378326416e+00
    phi[7,6]  R2684     -1.1832216978073120e+00
    phi[7,6]  R2685     1.3158118724822998e+00
    phi[7,6]  R2686     1.0136498212814331e+00
    phi[7,6]  R2687     1.6971484422683716e+00
    phi[7,6]  R2688     -0.00740637443959713
    phi[7,6]  R2689     -1.1320413351058960e+00
    phi[7,6]  R2690     1.2587369680404663e+00
    phi[7,6]  R2691     2.8136524558067322e-01
    phi[7,6]  R2692     1.8806435167789459e-01
    phi[7,6]  R2693     -0.626270592212677
    phi[7,6]  R2694     -1.2289618700742722e-01
    phi[7,6]  R2695     -1.1546353101730347e+00
    phi[7,6]  R2696     -1.1861183643341064e+00
    phi[7,6]  R2697     -8.3952236175537109e-01
    phi[7,6]  R2698     -9.8340153694152832e-01
    phi[7,6]  R2699     -1.6373997926712036e+00
    phi[7,6]  R2700     -7.5717383623123169e-01
    phi[7,6]  R2701     -0.738964319229126
    phi[7,6]  R2702     -2.4987680912017822e+00
    phi[7,6]  R2703     -1.2792247533798218e+00
    phi[7,6]  R2704     -1.2742787599563599e+00
    phi[7,6]  R2705     -1.7653902769088745e+00
    phi[7,6]  R2706     -2.6553840637207031e+00
    phi[7,6]  R2707     -1.7547312974929810e+00
    phi[7,6]  R2708     -2.4235565662384033e+00
    phi[7,6]  R2709     -1.5518461465835571e+00
    phi[7,6]  R2710     -1.7951462268829346e+00
    phi[7,6]  R2711     -1.7648845911026
    phi[7,6]  R2712     -1.2291798591613770e+00
    phi[7,6]  R2713     -9.1166895627975464e-01
    phi[7,6]  R2714     -1.5914812088012695e+00
    phi[7,6]  R2715     -1.6912870407104492e+00
    phi[7,6]  R2716     -2.2351670265197754e+00
    phi[7,6]  R2717     -1.6432310342788696e+00
    phi[7,6]  R2718     -9.1125357151031494e-01
    phi[7,6]  R2719     -2.2653753757476807e+00
    phi[7,6]  R2720     -2.4446706473827362e-01
    phi[7,6]  R2721     -2.8012716770172119e-01
    phi[7,6]  R2722     -1.0967670679092407e+00
    phi[7,6]  R2723     9.6231400966644287e-02
    phi[7,6]  R2724     -1.8381308317184448e+00
    phi[7,6]  R2725     -7.7290922403335571e-01
    phi[7,6]  R2726     -1.5832005739212036e+00
    phi[7,6]  R2727     -3.1118106842041016e-01
    phi[7,6]  R2728     -5.6111347675323486e-01
    phi[7,6]  R2729     -1.0217463970184326e+00
    phi[7,6]  R2730     -1.5180538892745972e+00
    phi[7,6]  R2731     -1.3807417154312134e+00
    phi[7,6]  R2732     -7.0455574989318848e-01
    phi[7,6]  R2733     -1.4603086709976196e+00
    phi[7,6]  R2734     -9.5732325315475464e-01
    phi[7,6]  R2735     -1.9040203094482422e+00
    phi[7,6]  R2736     -4.7447791695594788e-01
    phi[7,6]  R2737     -1.9068344831466675e+00
    phi[7,6]  R2738     -7.2076320648193359e-01
    phi[7,6]  R2739     7.0202302932739258e-01
    phi[7,6]  R2740     4.7585070133209229e-02
    phi[7,6]  R2741     -1.6228001117706299e+00
    phi[7,9]  R63       1
    phi[7,9]  R64       1
    phi[7,9]  R65       -1.6078156894763307e-01
    phi[7,9]  R66       8.2505627710863561e-02
    phi[7,9]  R67       -8.4987547698228161e-01
    phi[7,9]  R68       1.8815668677009914e+00
    phi[7,9]  R69       2.8702099755595842e+00
    phi[7,9]  R70       1.6610677775870315e+00
    phi[7,9]  R71       1.3381563446877955e+00
    phi[7,9]  R73       -1
    phi[7,9]  R2742     -3.2607814735802014e+00
    phi[7,9]  R2743     -2.9392183356849353e+00
    phi[7,9]  R2744     -2.1574943818258796e+00
    phi[7,9]  R2745     -2.3225056372476067e+00
    phi[7,9]  R2746     -3.94987538161485
    phi[7,9]  R2747     -2.2501244276502868e+00
    phi[7,9]  R2748     -6.8843306554180650e-01
    phi[7,9]  R2749     -4.4515668009437892e+00
    phi[7,9]  R2750     -2.2978992907298412e-01
    phi[7,9]  R2751     -5.9702098801921526e+00
    phi[7,9]  R2752     -0.42893213658228
    phi[7,9]  R2753     -3.7510676917563428e+00
    phi[7,9]  R2754     -1.7618435599447728e+00
    phi[7,9]  R2755     -4.4381562493203637e+00
    phi[7,9]  R2756     -9.1006409055395809e-02
    phi[7,9]  R2757     -9.9855440867278933e-02
    phi[7,9]  R2758     -1.0090474488745915e-01
    phi[7,9]  R2759     -1.0436410079875369e-01
    phi[7,9]  R2760     -1.1579616360616218e-01
    phi[7,9]  R2761     -1.2920566568837555e-01
    phi[7,9]  R2762     -0.132715772942825
    phi[7,9]  R2763     -0.143510165477156
    phi[7,9]  R2764     -2.2981764135645394e-01
    phi[7,9]  R2765     -2.5041017173686431e-01
    phi[7,9]  R2766     -2.5072009934320050e-01
    phi[7,9]  R2767     -3.1298419664574634e-01
    phi[7,9]  R2768     -3.5789212360295841e-01
    phi[7,9]  R2769     -3.8113316859768220e-01
    phi[7,9]  R2770     -3.8794390930451783e-01
    phi[7,9]  R2771     -3.8849078204985732e-01
    phi[7,9]  R2772     -3.9174372246063116e-01
    phi[7,9]  R2773     -4.1785637550886645e-01
    phi[7,9]  R2774     -4.5226226135334158e-01
    phi[7,9]  R2775     -4.7547233663048116e-01
    phi[7,9]  R2776     -3.7363491983389285e-01
    phi[7,9]  R2777     -4.2115281617760059e-01
    phi[7,9]  R2778     -4.7706830447339432e-01
    phi[7,9]  R2779     -4.9205920630238009e-01
    phi[7,9]  R2780     -4.9707226715088293e-01
    phi[7,9]  R2781     -0.542244090334453
    phi[7,9]  R2782     -0.560878330649259
    phi[7,9]  R2783     -5.6573236791238113e-01
    phi[7,9]  R2784     -6.4025709130198816e-01
    phi[7,9]  R2785     -7.3075142996055420e-01
    phi[7,9]  R2786     -3.0147685202594110e-01
    phi[7,9]  R2787     -4.2467000722662884e-01
    phi[7,9]  R2788     -4.4779170552254466e-01
    phi[7,9]  R2789     -4.8080409577825611e-01
    phi[7,9]  R2790     -4.9655754705666144e-01
    phi[7,9]  R2791     -1.3105735355444805e+00
    phi[7,9]  R2792     -2.3571009860782413e+00
    phi[7,9]  R2793     -2.3312573918303512e+00
    phi[7,9]  R2794     -1.9086274582838390e+00
    phi[7,9]  R2795     -2.5454108530625836e+00
    MARKER    'MARKER'                 'INTEND'
    z[0,1,0]  R2        -1
    z[0,1,0]  R11       1
    z[0,1,0]  R74       -1
    z[0,1,0]  R75       1
    z[0,1,0]  R88       -4.5784229040145874e-01
    z[0,1,0]  R89       4.6131291985511780e-01
    z[0,1,0]  R90       3.7151578068733215e-01
    z[0,1,0]  R91       -6.8760626018047333e-02
    z[0,1,0]  R92       0.0141522828489542
    z[0,1,0]  R93       -1.6506123542785645e-01
    z[0,1,0]  R94       -7.6237481832504272e-01
    z[0,1,0]  R95       5.3342336416244507e-01
    z[0,1,0]  R96       -3.3378910273313522e-02
    z[0,1,0]  R97       -1.6487009823322296e-01
    z[0,1,0]  R98       2.8163021802902222e-01
    z[0,1,0]  R99       2.4612860381603241e-01
    z[0,1,0]  R100      2.1519605815410614e-01
    z[0,1,0]  R101      2.7198189496994019e-01
    z[0,1,0]  R102      3.3863645792007446e-01
    z[0,1,0]  R103      5.9116703271865845e-01
    z[0,1,0]  R104      4.1720378398895264e-01
    z[0,1,0]  R105      2.8617396950721741e-01
    z[0,1,0]  R106      1.5544786583632231e-03
    z[0,1,0]  R107      4.7697207331657410e-01
    z[0,1,0]  R108      2.3475369811058044e-01
    z[0,1,0]  R109      -1.9980992376804352e-01
    z[0,1,0]  R110      3.2136179506778717e-02
    z[0,1,0]  R111      6.4604693651199341e-01
    z[0,1,0]  R112      3.6950138211250305e-01
    z[0,1,0]  R113      2.7707502245903015e-01
    z[0,1,0]  R114      5.1643788814544678e-02
    z[0,1,0]  R115      1.8287500739097595e-01
    z[0,1,0]  R116      1.7971959710121155e-01
    z[0,1,0]  R117      -8.7597921490669250e-02
    z[0,1,0]  R118      1.5850837528705597e-01
    z[0,1,0]  R119      3.3547121286392212e-01
    z[0,1,0]  R120      -7.3378556966781616e-01
    z[0,1,0]  R121      7.8569218516349792e-02
    z[0,1,0]  R122      3.8134112954139709e-01
    z[0,1,0]  R123      -2.4140600860118866e-01
    z[0,1,0]  R124      -7.0312604308128357e-02
    z[0,1,0]  R125      -3.6191427707672119e-01
    z[0,1,0]  R126      -1.1698658764362335e-01
    z[0,1,0]  R127      -6.2288141250610352e-01
    z[0,1,0]  R128      2.7962762117385864e-01
    z[0,1,0]  R129      2.0304465293884277e-01
    z[0,1,0]  R130      4.8196381330490112e-01
    z[0,1,0]  R131      4.9614846706390381e-01
    z[0,1,0]  R132      1.2865640223026276e-01
    z[0,1,0]  R133      -6.1407768726348877e-01
    z[0,1,0]  R134      -3.2301995903253555e-02
    z[0,1,0]  R135      -6.5264117717742920e-01
    z[0,1,0]  R136      5.8207523822784424e-01
    z[0,1,0]  R137      -3.2870405912399292e-01
    z[0,1,0]  R138      -3.1641387939453125e-01
    z[0,1,0]  R139      -4.2277911305427551e-01
    z[0,1,0]  R140      -1.0244952887296677e-01
    z[0,1,0]  R141      -1.2051765620708466e-01
    z[0,1,0]  R142      -4.8893335461616516e-01
    z[0,1,0]  R143      -1.8897777795791626e-01
    z[0,1,0]  R144      1.3949221372604370e-01
    z[0,1,0]  R145      -2.2030605375766754e-01
    z[0,1,0]  R146      -2.1836702525615692e-01
    z[0,1,0]  R147      2.3509931564331055e-01
    z[0,1,0]  R148      -7.6377198100090027e-02
    z[0,1,0]  R149      3.1136092543601990e-01
    z[0,1,0]  R150      3.0841851234436035e-01
    z[0,1,0]  R151      2.2287490963935852e-01
    z[0,1,0]  R152      -5.3050625324249268e-01
    z[0,1,0]  R153      -1.4284588396549225e-01
    z[0,1,0]  R154      2.0959232747554779e-01
    z[0,1,0]  R155      2.6491835713386536e-01
    z[0,1,0]  R156      4.4635945558547974e-01
    z[0,1,0]  R157      8.6355626583099365e-02
    z[0,1,0]  R158      2.9921406507492065e-01
    z[0,1,0]  R159      -3.4507188200950623e-01
    z[0,1,0]  R160      -6.5469577908515930e-02
    z[0,1,0]  R161      8.4681533277034760e-02
    z[0,1,0]  R162      -4.7394716739654541e-01
    z[0,1,0]  R163      -0.486203134059906
    z[0,1,0]  R164      -5.0084066390991211e-01
    z[0,1,0]  R165      -6.6228991746902466e-01
    z[0,1,0]  R166      -6.7427629232406616e-01
    z[0,1,0]  R167      -7.0876157283782959e-01
    z[0,1,1]  R3        -1
    z[0,1,1]  R12       1
    z[0,1,1]  R76       -1
    z[0,1,1]  R77       1
    z[0,1,1]  R88       6.9972306489944458e-01
    z[0,1,1]  R89       5.9919810295104980e-01
    z[0,1,1]  R90       5.3524309396743774e-01
    z[0,1,1]  R91       0.841986358165741
    z[0,1,1]  R92       7.0326012372970581e-01
    z[0,1,1]  R93       5.3300845623016357e-01
    z[0,1,1]  R94       4.3354243040084839e-01
    z[0,1,1]  R95       3.0983239412307739e-01
    z[0,1,1]  R96       4.4980236887931824e-01
    z[0,1,1]  R97       -8.6187058687210083e-01
    z[0,1,1]  R98       2.3115375638008118e-01
    z[0,1,1]  R99       5.3061640262603760e-01
    z[0,1,1]  R100      4.6046841144561768e-01
    z[0,1,1]  R101      -7.6222550868988037e-01
    z[0,1,1]  R102      -8.3081328868865967e-01
    z[0,1,1]  R103      -7.4058449268341064e-01
    z[0,1,1]  R104      -0.678173303604126
    z[0,1,1]  R105      -7.3438102006912231e-01
    z[0,1,1]  R106      -7.9568070173263550e-01
    z[0,1,1]  R107      -0.67437344789505
    z[0,1,1]  R108      6.9934010505676270e-01
    z[0,1,1]  R109      4.0863081812858582e-01
    z[0,1,1]  R110      7.5545167922973633e-01
    z[0,1,1]  R111      8.9056707918643951e-02
    z[0,1,1]  R112      1.5969778597354889e-01
    z[0,1,1]  R113      -9.3229299783706665e-01
    z[0,1,1]  R114      -8.6355835199356079e-01
    z[0,1,1]  R115      -8.9983057975769043e-01
    z[0,1,1]  R116      -8.6051493883132935e-01
    z[0,1,1]  R117      -8.0782520771026611e-01
    z[0,1,1]  R118      5.6270515918731689e-01
    z[0,1,1]  R119      2.5091478228569031e-01
    z[0,1,1]  R120      4.7580823302268982e-01
    z[0,1,1]  R121      -9.2943161725997925e-01
    z[0,1,1]  R122      -8.3177280426025391e-01
    z[0,1,1]  R123      -4.4241887331008911e-01
    z[0,1,1]  R124      -4.0229710936546326e-01
    z[0,1,1]  R125      -3.4467756748199463e-01
    z[0,1,1]  R126      -0.289137065410614
    z[0,1,1]  R127      -3.1193533539772034e-01
    z[0,1,1]  R128      -2.1921348571777344e-01
    z[0,1,1]  R129      -7.4452593922615051e-02
    z[0,1,1]  R130      -5.0826704502105713e-01
    z[0,1,1]  R131      -3.2922571897506714e-01
    z[0,1,1]  R132      8.1142103672027588e-01
    z[0,1,1]  R133      6.1842817068099976e-01
    z[0,1,1]  R134      6.8973690271377563e-01
    z[0,1,1]  R135      5.9134668111801147e-01
    z[0,1,1]  R136      6.1284792423248291e-01
    z[0,1,1]  R137      0.573715090751648
    z[0,1,1]  R138      9.0683412551879883e-01
    z[0,1,1]  R139      8.3137172460556030e-01
    z[0,1,1]  R140      8.0535823106765747e-01
    z[0,1,1]  R141      -3.2495595514774323e-02
    z[0,1,1]  R142      7.1907246112823486e-01
    z[0,1,1]  R143      -4.5671343803405762e-02
    z[0,1,1]  R144      8.2761889696121216e-01
    z[0,1,1]  R145      6.8467676639556885e-01
    z[0,1,1]  R146      -3.5720226168632507e-01
    z[0,1,1]  R147      2.8877329826354980e-01
    z[0,1,1]  R148      9.3616098165512085e-01
    z[0,1,1]  R149      8.7562519311904907e-01
    z[0,1,1]  R150      9.1728532314300537e-01
    z[0,1,1]  R151      8.2997298240661621e-01
    z[0,1,1]  R152      7.4703454971313477e-01
    z[0,1,1]  R153      8.3241719007492065e-01
    z[0,1,1]  R154      7.4476099014282227e-01
    z[0,1,1]  R155      7.3139709234237671e-01
    z[0,1,1]  R156      7.7011620998382568e-01
    z[0,1,1]  R157      2.8373071551322937e-01
    z[0,1,1]  R158      9.1313737630844116e-01
    z[0,1,1]  R159      8.1033390760421753e-01
    z[0,1,1]  R160      8.0890297889709473e-01
    z[0,1,1]  R161      0.686237633228302
    z[0,1,1]  R162      3.3341646194458008e-01
    z[0,1,1]  R163      2.3928360641002655e-01
    z[0,1,1]  R164      1.6235956549644470e-01
    z[0,1,1]  R165      -3.7058692425489426e-02
    z[0,1,1]  R166      -1.9127799198031425e-02
    z[0,1,1]  R167      1.4989666640758514e-01
    z[0,1,2]  R4        -1
    z[0,1,2]  R13       1
    z[0,1,2]  R78       -1
    z[0,1,2]  R79       1
    z[0,1,2]  R88       4.1182544827461243e-01
    z[0,1,2]  R89       3.4214559197425842e-01
    z[0,1,2]  R90       6.4146476984024048e-01
    z[0,1,2]  R91       -5.8745678514242172e-02
    z[0,1,2]  R92       2.9820975661277771e-01
    z[0,1,2]  R93       2.3407407104969025e-01
    z[0,1,2]  R94       2.0372729003429413e-01
    z[0,1,2]  R95       -2.8888460993766785e-01
    z[0,1,2]  R96       1.2944971024990082e-01
    z[0,1,2]  R97       3.1971395015716553e-01
    z[0,1,2]  R98       -5.3114318847656250e-01
    z[0,1,2]  R99       -2.8720572590827942e-01
    z[0,1,2]  R100      -3.4075200557708740e-01
    z[0,1,2]  R101      0.0651799812912941
    z[0,1,2]  R102      -1.0540736466646194e-01
    z[0,1,2]  R103      5.5763799697160721e-02
    z[0,1,2]  R104      2.1315130591392517e-01
    z[0,1,2]  R105      9.7647868096828461e-03
    z[0,1,2]  R106      2.7516508102416992e-01
    z[0,1,2]  R107      1.2211017310619354e-01
    z[0,1,2]  R108      -4.1460892558097839e-01
    z[0,1,2]  R109      -3.3463403582572937e-01
    z[0,1,2]  R110      -1.6629112884402275e-02
    z[0,1,2]  R111      -1.5568526089191437e-01
    z[0,1,2]  R112      4.0350826457142830e-03
    z[0,1,2]  R113      1.0063806176185608e-01
    z[0,1,2]  R114      2.9198083281517029e-01
    z[0,1,2]  R115      1.2186415493488312e-01
    z[0,1,2]  R116      1.2220936268568039e-01
    z[0,1,2]  R117      2.6314669847488403e-01
    z[0,1,2]  R118      -3.0581615865230560e-03
    z[0,1,2]  R119      -5.9071831405162811e-02
    z[0,1,2]  R120      2.3816527426242828e-01
    z[0,1,2]  R121      1.3352888822555542e-01
    z[0,1,2]  R122      9.2853292822837830e-02
    z[0,1,2]  R123      1.5188363194465637e-01
    z[0,1,2]  R124      3.7422287464141846e-01
    z[0,1,2]  R125      4.6395204961299896e-02
    z[0,1,2]  R126      3.1327095627784729e-01
    z[0,1,2]  R127      -5.4369044303894043e-01
    z[0,1,2]  R128      5.3371560573577881e-01
    z[0,1,2]  R129      6.8362191319465637e-02
    z[0,1,2]  R130      1.8323728442192078e-01
    z[0,1,2]  R131      -2.4813309311866760e-01
    z[0,1,2]  R132      2.8203356266021729e-01
    z[0,1,2]  R133      3.6106950044631958e-01
    z[0,1,2]  R134      -4.1474151611328125e-01
    z[0,1,2]  R135      3.9721819758415222e-01
    z[0,1,2]  R136      -1.3042224943637848e-01
    z[0,1,2]  R137      -5.7017207145690918e-01
    z[0,1,2]  R138      1.1580395698547363e-01
    z[0,1,2]  R139      1.8631696701049805e-01
    z[0,1,2]  R140      -2.3490869998931885e-01
    z[0,1,2]  R141      6.1722569167613983e-02
    z[0,1,2]  R142      -4.1013407707214355e-01
    z[0,1,2]  R143      -4.0237170457839966e-01
    z[0,1,2]  R144      1.8765635788440704e-01
    z[0,1,2]  R145      -0.515556275844574
    z[0,1,2]  R146      -1.5989071130752563e-01
    z[0,1,2]  R147      -1.3489606976509094e-01
    z[0,1,2]  R148      -3.3976398408412933e-02
    z[0,1,2]  R149      -2.9960241913795471e-01
    z[0,1,2]  R150      -1.3145267963409424e-01
    z[0,1,2]  R151      -3.2863074541091919e-01
    z[0,1,2]  R152      -2.4547062814235687e-01
    z[0,1,2]  R153      4.0565276145935059e-01
    z[0,1,2]  R154      1.3377526402473450e-01
    z[0,1,2]  R155      7.7422477304935455e-02
    z[0,1,2]  R156      1.4425605535507202e-01
    z[0,1,2]  R157      1.4587850868701935e-01
    z[0,1,2]  R158      2.3768074810504913e-01
    z[0,1,2]  R159      -3.1970882415771484e-01
    z[0,1,2]  R160      2.7199709415435791e-01
    z[0,1,2]  R161      -4.0316683053970337e-01
    z[0,1,2]  R162      -4.2920511960983276e-01
    z[0,1,2]  R163      -4.8564866185188293e-01
    z[0,1,2]  R164      -5.3797960281372070e-01
    z[0,1,2]  R165      -5.8077478408813477e-01
    z[0,1,2]  R166      -6.0098898410797119e-01
    z[0,1,2]  R167      -1.6859672963619232e-01
    z[0,1,3]  R5        -1
    z[0,1,3]  R14       1
    z[0,1,3]  R80       -1
    z[0,1,3]  R81       1
    z[0,1,3]  R88       2.1571151912212372e-01
    z[0,1,3]  R89       1.1827246844768524e-01
    z[0,1,3]  R90       6.1942975968122482e-02
    z[0,1,3]  R91       1.4734905958175659e-01
    z[0,1,3]  R92       4.6738174557685852e-01
    z[0,1,3]  R93       -8.1005841493606567e-02
    z[0,1,3]  R94       -1.9384460151195526e-01
    z[0,1,3]  R95       -3.4577727317810059e-02
    z[0,1,3]  R96       -1.3444166630506516e-02
    z[0,1,3]  R97       3.0745112895965576e-01
    z[0,1,3]  R98       -6.9761967658996582e-01
    z[0,1,3]  R99       -4.5262724161148071e-01
    z[0,1,3]  R100      -1.8227195739746094e-01
    z[0,1,3]  R101      4.3465545773506165e-01
    z[0,1,3]  R102      9.3317292630672455e-02
    z[0,1,3]  R103      1.8307955563068390e-01
    z[0,1,3]  R104      4.3990376591682434e-01
    z[0,1,3]  R105      1.5750470757484436e-01
    z[0,1,3]  R106      3.4503984451293945e-01
    z[0,1,3]  R107      2.1747404336929321e-01
    z[0,1,3]  R108      -2.3556582629680634e-01
    z[0,1,3]  R109      -3.6711838841438293e-01
    z[0,1,3]  R110      -1.5590147674083710e-01
    z[0,1,3]  R111      2.1487775444984436e-01
    z[0,1,3]  R112      6.1241549253463745e-01
    z[0,1,3]  R113      1.1795209348201752e-01
    z[0,1,3]  R114      3.7257385253906250e-01
    z[0,1,3]  R115      1.6701427102088928e-01
    z[0,1,3]  R116      1.6665865480899811e-01
    z[0,1,3]  R117      3.8207578659057617e-01
    z[0,1,3]  R118      -0.322479784488678
    z[0,1,3]  R119      -1.3925144076347351e-01
    z[0,1,3]  R120      2.5316730141639709e-01
    z[0,1,3]  R121      2.4352559447288513e-01
    z[0,1,3]  R122      3.0174168944358826e-01
    z[0,1,3]  R123      -2.3458187282085419e-01
    z[0,1,3]  R124      -2.9041069746017456e-01
    z[0,1,3]  R125      -4.8186635971069336e-01
    z[0,1,3]  R126      -5.5097401142120361e-01
    z[0,1,3]  R127      -7.3731496930122375e-02
    z[0,1,3]  R128      6.4021801948547363e-01
    z[0,1,3]  R129      8.7169617414474487e-01
    z[0,1,3]  R130      3.1608742475509644e-01
    z[0,1,3]  R131      5.3747820854187012e-01
    z[0,1,3]  R132      6.8027116358280182e-02
    z[0,1,3]  R133      0.0730455219745636
    z[0,1,3]  R134      -2.5397205352783203e-01
    z[0,1,3]  R135      -1.9554081559181213e-01
    z[0,1,3]  R136      -4.5375058054924011e-01
    z[0,1,3]  R137      1.3821160793304443e-01
    z[0,1,3]  R138      0.0708138570189476
    z[0,1,3]  R139      -2.3503344506025314e-02
    z[0,1,3]  R140      -3.5512641072273254e-01
    z[0,1,3]  R141      -8.0423909425735474e-01
    z[0,1,3]  R142      -1.5500102937221527e-01
    z[0,1,3]  R143      -7.8048378229141235e-01
    z[0,1,3]  R144      -3.1121698021888733e-01
    z[0,1,3]  R145      1.7341528832912445e-01
    z[0,1,3]  R146      -8.1789320707321167e-01
    z[0,1,3]  R147      -7.1255475282669067e-01
    z[0,1,3]  R148      -2.0603038370609283e-01
    z[0,1,3]  R149      4.0164690464735031e-02
    z[0,1,3]  R150      -0.0616854727268219
    z[0,1,3]  R151      1.6903959214687347e-02
    z[0,1,3]  R152      -2.6691758632659912e-01
    z[0,1,3]  R153      -3.0812656879425049e-01
    z[0,1,3]  R154      -0.0676007941365242
    z[0,1,3]  R155      1.2762063741683960e-01
    z[0,1,3]  R156      -3.7457591295242310e-01
    z[0,1,3]  R157      -4.1808575391769409e-01
    z[0,1,3]  R158      -8.0341942608356476e-02
    z[0,1,3]  R159      9.2959113419055939e-02
    z[0,1,3]  R160      -1.3726647198200226e-01
    z[0,1,3]  R161      -1.3386221230030060e-01
    z[0,1,3]  R162      -2.7941063046455383e-01
    z[0,1,3]  R163      -5.8254975825548172e-02
    z[0,1,3]  R164      -4.0904280543327332e-01
    z[0,1,3]  R165      -1.1424877494573593e-01
    z[0,1,3]  R166      -1.3846483826637268e-01
    z[0,1,3]  R167      -4.9811783432960510e-01
    z[0,1,4]  R6        -1
    z[0,1,4]  R15       1
    z[0,1,4]  R82       -1
    z[0,1,4]  R83       1
    z[0,1,4]  R88       2.6801860332489014e-01
    z[0,1,4]  R89       2.0113915205001831e-01
    z[0,1,4]  R90       -3.5000029206275940e-01
    z[0,1,4]  R91       3.5793926566839218e-02
    z[0,1,4]  R92       -2.7939385175704956e-01
    z[0,1,4]  R93       -6.3287980854511261e-02
    z[0,1,4]  R94       -3.6065548658370972e-01
    z[0,1,4]  R95       7.3096376657485962e-01
    z[0,1,4]  R96       6.7142558097839355e-01
    z[0,1,4]  R97       7.0937581360340118e-02
    z[0,1,4]  R98       1.3463832437992096e-01
    z[0,1,4]  R99       -5.1618558168411255e-01
    z[0,1,4]  R100      -4.5868670940399170e-01
    z[0,1,4]  R101      -5.8191988617181778e-02
    z[0,1,4]  R102      3.4410521388053894e-02
    z[0,1,4]  R103      1.1503663845360279e-03
    z[0,1,4]  R104      1.5963628888130188e-01
    z[0,1,4]  R105      -5.5157607793807983e-01
    z[0,1,4]  R106      -0.375713586807251
    z[0,1,4]  R107      -4.3983921408653259e-01
    z[0,1,4]  R108      -1.2373851612210274e-02
    z[0,1,4]  R109      -4.7766295075416565e-01
    z[0,1,4]  R110      4.1211850941181183e-02
    z[0,1,4]  R111      3.7129971385002136e-01
    z[0,1,4]  R112      -3.9886510372161865e-01
    z[0,1,4]  R113      -1.2034978717565536e-02
    z[0,1,4]  R114      -1.5882951021194458e-01
    z[0,1,4]  R115      1.3550990819931030e-01
    z[0,1,4]  R116      -4.2395928502082825e-01
    z[0,1,4]  R117      3.4098449349403381e-01
    z[0,1,4]  R118      -1.9753496162593365e-03
    z[0,1,4]  R119      -4.6900838613510132e-01
    z[0,1,4]  R120      -1.5267118811607361e-01
    z[0,1,4]  R121      7.8578270971775055e-02
    z[0,1,4]  R122      -6.4628034830093384e-02
    z[0,1,4]  R123      7.3250883817672729e-01
    z[0,1,4]  R124      0.703118085861206
    z[0,1,4]  R125      0.709367036819458
    z[0,1,4]  R126      0.629349946975708
    z[0,1,4]  R127      3.3739086985588074e-01
    z[0,1,4]  R128      -2.9989248514175415e-01
    z[0,1,4]  R129      4.0327611565589905e-01
    z[0,1,4]  R130      1.3635893166065216e-01
    z[0,1,4]  R131      -1.1704660207033157e-01
    z[0,1,4]  R132      -1.5881028771400452e-01
    z[0,1,4]  R133      -3.1409943103790283e-01
    z[0,1,4]  R134      -1.0652378201484680e-01
    z[0,1,4]  R135      -8.4657326340675354e-02
    z[0,1,4]  R136      -2.3083089292049408e-01
    z[0,1,4]  R137      -2.1730849146842957e-01
    z[0,1,4]  R138      -1.2386199086904526e-01
    z[0,1,4]  R139      1.3840185105800629e-01
    z[0,1,4]  R140      1.9290681183338165e-01
    z[0,1,4]  R141      -4.6147534251213074e-01
    z[0,1,4]  R142      -1.8422381579875946e-01
    z[0,1,4]  R143      -2.5764617323875427e-01
    z[0,1,4]  R144      1.6537123918533325e-01
    z[0,1,4]  R145      -4.1052049398422241e-01
    z[0,1,4]  R146      -2.0468063652515411e-01
    z[0,1,4]  R147      -7.2437569499015808e-02
    z[0,1,4]  R148      -2.6350542902946472e-01
    z[0,1,4]  R149      1.0137168318033218e-01
    z[0,1,4]  R150      1.3075691461563110e-01
    z[0,1,4]  R151      -1.4864277839660645e-01
    z[0,1,4]  R152      -9.7453128546476364e-04
    z[0,1,4]  R153      -1.4390507340431213e-01
    z[0,1,4]  R154      -1.9986103475093842e-01
    z[0,1,4]  R155      -2.4364335834980011e-01
    z[0,1,4]  R156      -2.0298688113689423e-01
    z[0,1,4]  R157      -1.5748099982738495e-01
    z[0,1,4]  R158      7.0507891476154327e-02
    z[0,1,4]  R159      2.3336309194564819e-01
    z[0,1,4]  R160      4.8944371519610286e-04
    z[0,1,4]  R161      2.4909204244613647e-01
    z[0,1,4]  R162      -5.0483405590057373e-01
    z[0,1,4]  R163      -3.9216119050979614e-01
    z[0,1,4]  R164      -6.7085914313793182e-02
    z[0,1,4]  R165      -3.5326597094535828e-01
    z[0,1,4]  R166      5.3770218044519424e-02
    z[0,1,4]  R167      -2.8380699455738068e-02
    z[0,1,5]  R7        -1
    z[0,1,5]  R16       1
    z[0,1,5]  R84       -1
    z[0,1,5]  R85       1
    z[0,1,5]  R88       -6.1701886355876923e-02
    z[0,1,5]  R89       5.0466352701187134e-01
    z[0,1,5]  R90       7.1706078946590424e-02
    z[0,1,5]  R91       4.8978742957115173e-01
    z[0,1,5]  R92       7.1435786783695221e-02
    z[0,1,5]  R93       2.7940362691879272e-01
    z[0,1,5]  R94       2.7574056759476662e-02
    z[0,1,5]  R95       -2.2223636507987976e-02
    z[0,1,5]  R96       -3.3171564340591431e-02
    z[0,1,5]  R97       1.6031476855278015e-01
    z[0,1,5]  R98       -2.5239479541778564e-01
    z[0,1,5]  R99       -2.9416564106941223e-01
    z[0,1,5]  R100      -4.4694498181343079e-01
    z[0,1,5]  R101      2.7287902310490608e-02
    z[0,1,5]  R102      -2.4877880513668060e-01
    z[0,1,5]  R103      3.3808764070272446e-02
    z[0,1,5]  R104      -2.5906574726104736e-01
    z[0,1,5]  R105      5.7204663753509521e-02
    z[0,1,5]  R106      1.7534929513931274e-01
    z[0,1,5]  R107      -1.3360358774662018e-01
    z[0,1,5]  R108      -2.9011952877044678e-01
    z[0,1,5]  R109      -1.0443875938653946e-01
    z[0,1,5]  R110      -4.9709695577621460e-01
    z[0,1,5]  R111      -5.7766562700271606e-01
    z[0,1,5]  R112      -2.3226347565650940e-01
    z[0,1,5]  R113      -1.4635747671127319e-01
    z[0,1,5]  R114      9.5519470050930977e-03
    z[0,1,5]  R115      3.0473536252975464e-01
    z[0,1,5]  R116      -4.6242665499448776e-02
    z[0,1,5]  R117      -4.3257344514131546e-02
    z[0,1,5]  R118      -0.0999906063079834
    z[0,1,5]  R119      -6.9952070713043213e-01
    z[0,1,5]  R120      -3.9647076278924942e-02
    z[0,1,5]  R121      -1.4046829938888550e-01
    z[0,1,5]  R122      2.4029399454593658e-01
    z[0,1,5]  R123      -3.5800644755363464e-01
    z[0,1,5]  R124      -0.337938517332077
    z[0,1,5]  R125      -1.1036282777786255e-01
    z[0,1,5]  R126      -8.4956243634223938e-02
    z[0,1,5]  R127      3.1225770711898804e-01
    z[0,1,5]  R128      -5.6651927297934890e-04
    z[0,1,5]  R129      9.0601295232772827e-02
    z[0,1,5]  R130      -1.7133527994155884e-01
    z[0,1,5]  R131      3.7299975752830505e-01
    z[0,1,5]  R132      4.1182979941368103e-01
    z[0,1,5]  R133      7.7907584607601166e-02
    z[0,1,5]  R134      2.6482158899307251e-01
    z[0,1,5]  R135      1.2379072606563568e-01
    z[0,1,5]  R136      6.4545914530754089e-02
    z[0,1,5]  R137      4.1312563419342041e-01
    z[0,1,5]  R138      -2.0584091544151306e-01
    z[0,1,5]  R139      2.3110151290893555e-01
    z[0,1,5]  R140      -5.2509274333715439e-02
    z[0,1,5]  R141      -3.2188376784324646e-01
    z[0,1,5]  R142      1.3271375000476837e-01
    z[0,1,5]  R143      -2.4289096891880035e-01
    z[0,1,5]  R144      7.5283623300492764e-03
    z[0,1,5]  R145      -1.3356009125709534e-01
    z[0,1,5]  R146      -1.5559597313404083e-01
    z[0,1,5]  R147      -5.3729629516601562e-01
    z[0,1,5]  R148      5.8139726519584656e-02
    z[0,1,5]  R149      1.5446808934211731e-01
    z[0,1,5]  R150      2.1611662581562996e-02
    z[0,1,5]  R151      -0.069243885576725
    z[0,1,5]  R152      1.6166546940803528e-01
    z[0,1,5]  R153      2.5690641254186630e-02
    z[0,1,5]  R154      -4.5451423525810242e-01
    z[0,1,5]  R155      -5.5896449089050293e-01
    z[0,1,5]  R156      -5.0081085413694382e-02
    z[0,1,5]  R157      -8.2788634300231934e-01
    z[0,1,5]  R158      -7.5349416583776474e-03
    z[0,1,5]  R159      -0.040500458329916
    z[0,1,5]  R160      2.0076100528240204e-01
    z[0,1,5]  R161      -0.453075110912323
    z[0,1,5]  R162      -3.6468061804771423e-01
    z[0,1,5]  R163      -4.3863037228584290e-01
    z[0,1,5]  R164      -3.8898301124572754e-01
    z[0,1,5]  R165      -2.8561952710151672e-01
    z[0,1,5]  R166      -3.9827275276184082e-01
    z[0,1,5]  R167      -4.4335415959358215e-01
    z[0,1,6]  R8        -1
    z[0,1,6]  R17       1
    z[0,1,6]  R86       -1
    z[0,1,6]  R87       1
    z[0,1,6]  R88       -9.4843529164791107e-02
    z[0,1,6]  R89       -4.4247034937143326e-02
    z[0,1,6]  R90       -1.8037442862987518e-01
    z[0,1,6]  R91       1.4140436053276062e-01
    z[0,1,6]  R92       -3.3865347504615784e-01
    z[0,1,6]  R93       -7.3839861154556274e-01
    z[0,1,6]  R94       -1.4461073279380798e-01
    z[0,1,6]  R95       3.3890013583004475e-03
    z[0,1,6]  R96       -0.572462260723114
    z[0,1,6]  R97       -5.0207413733005524e-02
    z[0,1,6]  R98       1.2897881865501404e-01
    z[0,1,6]  R99       -1.3239070773124695e-01
    z[0,1,6]  R100      4.2681512236595154e-01
    z[0,1,6]  R101      3.8436099886894226e-01
    z[0,1,6]  R102      3.3493393659591675e-01
    z[0,1,6]  R103      -2.5354269146919250e-01
    z[0,1,6]  R104      -1.8567276000976562e-01
    z[0,1,6]  R105      2.1535407006740570e-01
    z[0,1,6]  R106      1.4603652060031891e-02
    z[0,1,6]  R107      -2.1024686098098755e-01
    z[0,1,6]  R108      3.7960490584373474e-01
    z[0,1,6]  R109      5.5432099103927612e-01
    z[0,1,6]  R110      -3.9354091882705688e-01
    z[0,1,6]  R111      1.8088878691196442e-01
    z[0,1,6]  R112      4.9985662102699280e-01
    z[0,1,6]  R113      -9.1941304504871368e-02
    z[0,1,6]  R114      -4.7092538326978683e-02
    z[0,1,6]  R115      -5.3763326257467270e-02
    z[0,1,6]  R116      5.1233269274234772e-02
    z[0,1,6]  R117      7.9844966530799866e-02
    z[0,1,6]  R118      -7.3772174119949341e-01
    z[0,1,6]  R119      -3.0384582281112671e-01
    z[0,1,6]  R120      2.9911282658576965e-01
    z[0,1,6]  R121      1.6414389014244080e-01
    z[0,1,6]  R122      3.3838972449302673e-02
    z[0,1,6]  R123      5.6156627833843231e-02
    z[0,1,6]  R124      1.5955096110701561e-02
    z[0,1,6]  R125      2.2048467770218849e-02
    z[0,1,6]  R126      3.1257644295692444e-01
    z[0,1,6]  R127      -4.8394206911325455e-02
    z[0,1,6]  R128      -2.9847362637519836e-01
    z[0,1,6]  R129      1.3364848494529724e-01
    z[0,1,6]  R130      5.7265937328338623e-01
    z[0,1,6]  R131      -3.7704864144325256e-01
    z[0,1,6]  R132      2.1458871662616730e-01
    z[0,1,6]  R133      4.5019667595624924e-03
    z[0,1,6]  R134      -4.5302253961563110e-01
    z[0,1,6]  R135      7.6544538140296936e-02
    z[0,1,6]  R136      -7.2506345808506012e-02
    z[0,1,6]  R137      2.6650076732039452e-02
    z[0,1,6]  R138      -3.7373367697000504e-02
    z[0,1,6]  R139      -1.4916238188743591e-01
    z[0,1,6]  R140      3.4588301181793213e-01
    z[0,1,6]  R141      -1.3130338490009308e-01
    z[0,1,6]  R142      9.6046822145581245e-03
    z[0,1,6]  R143      -2.5644913315773010e-01
    z[0,1,6]  R144      0.368935763835907
    z[0,1,6]  R145      2.1128838881850243e-02
    z[0,1,6]  R146      2.5318679213523865e-01
    z[0,1,6]  R147      2.0364819467067719e-01
    z[0,1,6]  R148      -3.6755308508872986e-02
    z[0,1,6]  R149      1.0403539240360260e-01
    z[0,1,6]  R150      -1.5753178298473358e-01
    z[0,1,6]  R151      3.5538470745086670e-01
    z[0,1,6]  R152      -5.3524747490882874e-02
    z[0,1,6]  R153      -7.6234750449657440e-02
    z[0,1,6]  R154      3.6388018727302551e-01
    z[0,1,6]  R155      2.8143441304564476e-02
    z[0,1,6]  R156      -5.3437568247318268e-02
    z[0,1,6]  R157      -7.5942777097225189e-02
    z[0,1,6]  R158      9.3145325779914856e-02
    z[0,1,6]  R159      -0.239437997341156
    z[0,1,6]  R160      4.5635515451431274e-01
    z[0,1,6]  R161      -2.7225065231323242e-01
    z[0,1,6]  R162      1.1862057447433472e-01
    z[0,1,6]  R163      3.4772762656211853e-01
    z[0,1,6]  R164      3.3204165101051331e-01
    z[0,1,6]  R165      -5.7194292545318604e-02
    z[0,1,6]  R166      -5.5794060230255127e-02
    z[0,1,6]  R167      -3.5684242844581604e-02
    z[1,0,0]  R2        1
    z[1,0,0]  R11       -1
    z[1,0,0]  R168      -1
    z[1,0,0]  R169      1
    z[1,0,0]  R182      2.7962762117385864e-01
    z[1,0,0]  R183      2.0304465293884277e-01
    z[1,0,0]  R184      4.8196381330490112e-01
    z[1,0,0]  R185      4.9614846706390381e-01
    z[1,0,0]  R186      1.2865640223026276e-01
    z[1,0,0]  R187      -6.1407768726348877e-01
    z[1,0,0]  R188      -3.2301995903253555e-02
    z[1,0,0]  R189      -6.5264117717742920e-01
    z[1,0,0]  R190      5.8207523822784424e-01
    z[1,0,0]  R191      -3.2870405912399292e-01
    z[1,0,0]  R192      -3.1641387939453125e-01
    z[1,0,0]  R193      -4.2277911305427551e-01
    z[1,0,0]  R194      -1.0244952887296677e-01
    z[1,0,0]  R195      -1.2051765620708466e-01
    z[1,0,0]  R196      -4.8893335461616516e-01
    z[1,0,0]  R197      -1.8897777795791626e-01
    z[1,0,0]  R198      1.3949221372604370e-01
    z[1,0,0]  R199      -2.2030605375766754e-01
    z[1,0,0]  R200      -2.1836702525615692e-01
    z[1,0,0]  R201      2.3509931564331055e-01
    z[1,0,0]  R202      -7.6377198100090027e-02
    z[1,0,0]  R203      3.1136092543601990e-01
    z[1,0,0]  R204      3.0841851234436035e-01
    z[1,0,0]  R205      2.2287490963935852e-01
    z[1,0,0]  R206      -5.3050625324249268e-01
    z[1,0,0]  R207      -1.4284588396549225e-01
    z[1,0,0]  R208      2.0959232747554779e-01
    z[1,0,0]  R209      2.6491835713386536e-01
    z[1,0,0]  R210      4.4635945558547974e-01
    z[1,0,0]  R211      8.6355626583099365e-02
    z[1,0,0]  R212      2.9921406507492065e-01
    z[1,0,0]  R213      -3.4507188200950623e-01
    z[1,0,0]  R214      -6.5469577908515930e-02
    z[1,0,0]  R215      8.4681533277034760e-02
    z[1,0,0]  R216      -4.7394716739654541e-01
    z[1,0,0]  R217      -0.486203134059906
    z[1,0,0]  R218      -5.0084066390991211e-01
    z[1,0,0]  R219      -6.6228991746902466e-01
    z[1,0,0]  R220      -6.7427629232406616e-01
    z[1,0,0]  R221      -7.0876157283782959e-01
    z[1,0,0]  R222      -4.5784229040145874e-01
    z[1,0,0]  R223      4.6131291985511780e-01
    z[1,0,0]  R224      3.7151578068733215e-01
    z[1,0,0]  R225      -6.8760626018047333e-02
    z[1,0,0]  R226      0.0141522828489542
    z[1,0,0]  R227      -1.6506123542785645e-01
    z[1,0,0]  R228      -7.6237481832504272e-01
    z[1,0,0]  R229      5.3342336416244507e-01
    z[1,0,0]  R230      -3.3378910273313522e-02
    z[1,0,0]  R231      -1.6487009823322296e-01
    z[1,0,0]  R232      2.8163021802902222e-01
    z[1,0,0]  R233      2.4612860381603241e-01
    z[1,0,0]  R234      2.1519605815410614e-01
    z[1,0,0]  R235      2.7198189496994019e-01
    z[1,0,0]  R236      3.3863645792007446e-01
    z[1,0,0]  R237      5.9116703271865845e-01
    z[1,0,0]  R238      4.1720378398895264e-01
    z[1,0,0]  R239      2.8617396950721741e-01
    z[1,0,0]  R240      1.5544786583632231e-03
    z[1,0,0]  R241      4.7697207331657410e-01
    z[1,0,0]  R242      2.3475369811058044e-01
    z[1,0,0]  R243      -1.9980992376804352e-01
    z[1,0,0]  R244      3.2136179506778717e-02
    z[1,0,0]  R245      6.4604693651199341e-01
    z[1,0,0]  R246      3.6950138211250305e-01
    z[1,0,0]  R247      2.7707502245903015e-01
    z[1,0,0]  R248      5.1643788814544678e-02
    z[1,0,0]  R249      1.8287500739097595e-01
    z[1,0,0]  R250      1.7971959710121155e-01
    z[1,0,0]  R251      -8.7597921490669250e-02
    z[1,0,0]  R252      1.5850837528705597e-01
    z[1,0,0]  R253      3.3547121286392212e-01
    z[1,0,0]  R254      -7.3378556966781616e-01
    z[1,0,0]  R255      7.8569218516349792e-02
    z[1,0,0]  R256      3.8134112954139709e-01
    z[1,0,0]  R257      -2.4140600860118866e-01
    z[1,0,0]  R258      -7.0312604308128357e-02
    z[1,0,0]  R259      -3.6191427707672119e-01
    z[1,0,0]  R260      -1.1698658764362335e-01
    z[1,0,0]  R261      -6.2288141250610352e-01
    z[1,0,1]  R3        1
    z[1,0,1]  R12       -1
    z[1,0,1]  R170      -1
    z[1,0,1]  R171      1
    z[1,0,1]  R182      -2.1921348571777344e-01
    z[1,0,1]  R183      -7.4452593922615051e-02
    z[1,0,1]  R184      -5.0826704502105713e-01
    z[1,0,1]  R185      -3.2922571897506714e-01
    z[1,0,1]  R186      8.1142103672027588e-01
    z[1,0,1]  R187      6.1842817068099976e-01
    z[1,0,1]  R188      6.8973690271377563e-01
    z[1,0,1]  R189      5.9134668111801147e-01
    z[1,0,1]  R190      6.1284792423248291e-01
    z[1,0,1]  R191      0.573715090751648
    z[1,0,1]  R192      9.0683412551879883e-01
    z[1,0,1]  R193      8.3137172460556030e-01
    z[1,0,1]  R194      8.0535823106765747e-01
    z[1,0,1]  R195      -3.2495595514774323e-02
    z[1,0,1]  R196      7.1907246112823486e-01
    z[1,0,1]  R197      -4.5671343803405762e-02
    z[1,0,1]  R198      8.2761889696121216e-01
    z[1,0,1]  R199      6.8467676639556885e-01
    z[1,0,1]  R200      -3.5720226168632507e-01
    z[1,0,1]  R201      2.8877329826354980e-01
    z[1,0,1]  R202      9.3616098165512085e-01
    z[1,0,1]  R203      8.7562519311904907e-01
    z[1,0,1]  R204      9.1728532314300537e-01
    z[1,0,1]  R205      8.2997298240661621e-01
    z[1,0,1]  R206      7.4703454971313477e-01
    z[1,0,1]  R207      8.3241719007492065e-01
    z[1,0,1]  R208      7.4476099014282227e-01
    z[1,0,1]  R209      7.3139709234237671e-01
    z[1,0,1]  R210      7.7011620998382568e-01
    z[1,0,1]  R211      2.8373071551322937e-01
    z[1,0,1]  R212      9.1313737630844116e-01
    z[1,0,1]  R213      8.1033390760421753e-01
    z[1,0,1]  R214      8.0890297889709473e-01
    z[1,0,1]  R215      0.686237633228302
    z[1,0,1]  R216      3.3341646194458008e-01
    z[1,0,1]  R217      2.3928360641002655e-01
    z[1,0,1]  R218      1.6235956549644470e-01
    z[1,0,1]  R219      -3.7058692425489426e-02
    z[1,0,1]  R220      -1.9127799198031425e-02
    z[1,0,1]  R221      1.4989666640758514e-01
    z[1,0,1]  R222      6.9972306489944458e-01
    z[1,0,1]  R223      5.9919810295104980e-01
    z[1,0,1]  R224      5.3524309396743774e-01
    z[1,0,1]  R225      0.841986358165741
    z[1,0,1]  R226      7.0326012372970581e-01
    z[1,0,1]  R227      5.3300845623016357e-01
    z[1,0,1]  R228      4.3354243040084839e-01
    z[1,0,1]  R229      3.0983239412307739e-01
    z[1,0,1]  R230      4.4980236887931824e-01
    z[1,0,1]  R231      -8.6187058687210083e-01
    z[1,0,1]  R232      2.3115375638008118e-01
    z[1,0,1]  R233      5.3061640262603760e-01
    z[1,0,1]  R234      4.6046841144561768e-01
    z[1,0,1]  R235      -7.6222550868988037e-01
    z[1,0,1]  R236      -8.3081328868865967e-01
    z[1,0,1]  R237      -7.4058449268341064e-01
    z[1,0,1]  R238      -0.678173303604126
    z[1,0,1]  R239      -7.3438102006912231e-01
    z[1,0,1]  R240      -7.9568070173263550e-01
    z[1,0,1]  R241      -0.67437344789505
    z[1,0,1]  R242      6.9934010505676270e-01
    z[1,0,1]  R243      4.0863081812858582e-01
    z[1,0,1]  R244      7.5545167922973633e-01
    z[1,0,1]  R245      8.9056707918643951e-02
    z[1,0,1]  R246      1.5969778597354889e-01
    z[1,0,1]  R247      -9.3229299783706665e-01
    z[1,0,1]  R248      -8.6355835199356079e-01
    z[1,0,1]  R249      -8.9983057975769043e-01
    z[1,0,1]  R250      -8.6051493883132935e-01
    z[1,0,1]  R251      -8.0782520771026611e-01
    z[1,0,1]  R252      5.6270515918731689e-01
    z[1,0,1]  R253      2.5091478228569031e-01
    z[1,0,1]  R254      4.7580823302268982e-01
    z[1,0,1]  R255      -9.2943161725997925e-01
    z[1,0,1]  R256      -8.3177280426025391e-01
    z[1,0,1]  R257      -4.4241887331008911e-01
    z[1,0,1]  R258      -4.0229710936546326e-01
    z[1,0,1]  R259      -3.4467756748199463e-01
    z[1,0,1]  R260      -0.289137065410614
    z[1,0,1]  R261      -3.1193533539772034e-01
    z[1,0,2]  R4        1
    z[1,0,2]  R13       -1
    z[1,0,2]  R172      -1
    z[1,0,2]  R173      1
    z[1,0,2]  R182      5.3371560573577881e-01
    z[1,0,2]  R183      6.8362191319465637e-02
    z[1,0,2]  R184      1.8323728442192078e-01
    z[1,0,2]  R185      -2.4813309311866760e-01
    z[1,0,2]  R186      2.8203356266021729e-01
    z[1,0,2]  R187      3.6106950044631958e-01
    z[1,0,2]  R188      -4.1474151611328125e-01
    z[1,0,2]  R189      3.9721819758415222e-01
    z[1,0,2]  R190      -1.3042224943637848e-01
    z[1,0,2]  R191      -5.7017207145690918e-01
    z[1,0,2]  R192      1.1580395698547363e-01
    z[1,0,2]  R193      1.8631696701049805e-01
    z[1,0,2]  R194      -2.3490869998931885e-01
    z[1,0,2]  R195      6.1722569167613983e-02
    z[1,0,2]  R196      -4.1013407707214355e-01
    z[1,0,2]  R197      -4.0237170457839966e-01
    z[1,0,2]  R198      1.8765635788440704e-01
    z[1,0,2]  R199      -0.515556275844574
    z[1,0,2]  R200      -1.5989071130752563e-01
    z[1,0,2]  R201      -1.3489606976509094e-01
    z[1,0,2]  R202      -3.3976398408412933e-02
    z[1,0,2]  R203      -2.9960241913795471e-01
    z[1,0,2]  R204      -1.3145267963409424e-01
    z[1,0,2]  R205      -3.2863074541091919e-01
    z[1,0,2]  R206      -2.4547062814235687e-01
    z[1,0,2]  R207      4.0565276145935059e-01
    z[1,0,2]  R208      1.3377526402473450e-01
    z[1,0,2]  R209      7.7422477304935455e-02
    z[1,0,2]  R210      1.4425605535507202e-01
    z[1,0,2]  R211      1.4587850868701935e-01
    z[1,0,2]  R212      2.3768074810504913e-01
    z[1,0,2]  R213      -3.1970882415771484e-01
    z[1,0,2]  R214      2.7199709415435791e-01
    z[1,0,2]  R215      -4.0316683053970337e-01
    z[1,0,2]  R216      -4.2920511960983276e-01
    z[1,0,2]  R217      -4.8564866185188293e-01
    z[1,0,2]  R218      -5.3797960281372070e-01
    z[1,0,2]  R219      -5.8077478408813477e-01
    z[1,0,2]  R220      -6.0098898410797119e-01
    z[1,0,2]  R221      -1.6859672963619232e-01
    z[1,0,2]  R222      4.1182544827461243e-01
    z[1,0,2]  R223      3.4214559197425842e-01
    z[1,0,2]  R224      6.4146476984024048e-01
    z[1,0,2]  R225      -5.8745678514242172e-02
    z[1,0,2]  R226      2.9820975661277771e-01
    z[1,0,2]  R227      2.3407407104969025e-01
    z[1,0,2]  R228      2.0372729003429413e-01
    z[1,0,2]  R229      -2.8888460993766785e-01
    z[1,0,2]  R230      1.2944971024990082e-01
    z[1,0,2]  R231      3.1971395015716553e-01
    z[1,0,2]  R232      -5.3114318847656250e-01
    z[1,0,2]  R233      -2.8720572590827942e-01
    z[1,0,2]  R234      -3.4075200557708740e-01
    z[1,0,2]  R235      0.0651799812912941
    z[1,0,2]  R236      -1.0540736466646194e-01
    z[1,0,2]  R237      5.5763799697160721e-02
    z[1,0,2]  R238      2.1315130591392517e-01
    z[1,0,2]  R239      9.7647868096828461e-03
    z[1,0,2]  R240      2.7516508102416992e-01
    z[1,0,2]  R241      1.2211017310619354e-01
    z[1,0,2]  R242      -4.1460892558097839e-01
    z[1,0,2]  R243      -3.3463403582572937e-01
    z[1,0,2]  R244      -1.6629112884402275e-02
    z[1,0,2]  R245      -1.5568526089191437e-01
    z[1,0,2]  R246      4.0350826457142830e-03
    z[1,0,2]  R247      1.0063806176185608e-01
    z[1,0,2]  R248      2.9198083281517029e-01
    z[1,0,2]  R249      1.2186415493488312e-01
    z[1,0,2]  R250      1.2220936268568039e-01
    z[1,0,2]  R251      2.6314669847488403e-01
    z[1,0,2]  R252      -3.0581615865230560e-03
    z[1,0,2]  R253      -5.9071831405162811e-02
    z[1,0,2]  R254      2.3816527426242828e-01
    z[1,0,2]  R255      1.3352888822555542e-01
    z[1,0,2]  R256      9.2853292822837830e-02
    z[1,0,2]  R257      1.5188363194465637e-01
    z[1,0,2]  R258      3.7422287464141846e-01
    z[1,0,2]  R259      4.6395204961299896e-02
    z[1,0,2]  R260      3.1327095627784729e-01
    z[1,0,2]  R261      -5.4369044303894043e-01
    z[1,0,3]  R5        1
    z[1,0,3]  R14       -1
    z[1,0,3]  R174      -1
    z[1,0,3]  R175      1
    z[1,0,3]  R182      6.4021801948547363e-01
    z[1,0,3]  R183      8.7169617414474487e-01
    z[1,0,3]  R184      3.1608742475509644e-01
    z[1,0,3]  R185      5.3747820854187012e-01
    z[1,0,3]  R186      6.8027116358280182e-02
    z[1,0,3]  R187      0.0730455219745636
    z[1,0,3]  R188      -2.5397205352783203e-01
    z[1,0,3]  R189      -1.9554081559181213e-01
    z[1,0,3]  R190      -4.5375058054924011e-01
    z[1,0,3]  R191      1.3821160793304443e-01
    z[1,0,3]  R192      0.0708138570189476
    z[1,0,3]  R193      -2.3503344506025314e-02
    z[1,0,3]  R194      -3.5512641072273254e-01
    z[1,0,3]  R195      -8.0423909425735474e-01
    z[1,0,3]  R196      -1.5500102937221527e-01
    z[1,0,3]  R197      -7.8048378229141235e-01
    z[1,0,3]  R198      -3.1121698021888733e-01
    z[1,0,3]  R199      1.7341528832912445e-01
    z[1,0,3]  R200      -8.1789320707321167e-01
    z[1,0,3]  R201      -7.1255475282669067e-01
    z[1,0,3]  R202      -2.0603038370609283e-01
    z[1,0,3]  R203      4.0164690464735031e-02
    z[1,0,3]  R204      -0.0616854727268219
    z[1,0,3]  R205      1.6903959214687347e-02
    z[1,0,3]  R206      -2.6691758632659912e-01
    z[1,0,3]  R207      -3.0812656879425049e-01
    z[1,0,3]  R208      -0.0676007941365242
    z[1,0,3]  R209      1.2762063741683960e-01
    z[1,0,3]  R210      -3.7457591295242310e-01
    z[1,0,3]  R211      -4.1808575391769409e-01
    z[1,0,3]  R212      -8.0341942608356476e-02
    z[1,0,3]  R213      9.2959113419055939e-02
    z[1,0,3]  R214      -1.3726647198200226e-01
    z[1,0,3]  R215      -1.3386221230030060e-01
    z[1,0,3]  R216      -2.7941063046455383e-01
    z[1,0,3]  R217      -5.8254975825548172e-02
    z[1,0,3]  R218      -4.0904280543327332e-01
    z[1,0,3]  R219      -1.1424877494573593e-01
    z[1,0,3]  R220      -1.3846483826637268e-01
    z[1,0,3]  R221      -4.9811783432960510e-01
    z[1,0,3]  R222      2.1571151912212372e-01
    z[1,0,3]  R223      1.1827246844768524e-01
    z[1,0,3]  R224      6.1942975968122482e-02
    z[1,0,3]  R225      1.4734905958175659e-01
    z[1,0,3]  R226      4.6738174557685852e-01
    z[1,0,3]  R227      -8.1005841493606567e-02
    z[1,0,3]  R228      -1.9384460151195526e-01
    z[1,0,3]  R229      -3.4577727317810059e-02
    z[1,0,3]  R230      -1.3444166630506516e-02
    z[1,0,3]  R231      3.0745112895965576e-01
    z[1,0,3]  R232      -6.9761967658996582e-01
    z[1,0,3]  R233      -4.5262724161148071e-01
    z[1,0,3]  R234      -1.8227195739746094e-01
    z[1,0,3]  R235      4.3465545773506165e-01
    z[1,0,3]  R236      9.3317292630672455e-02
    z[1,0,3]  R237      1.8307955563068390e-01
    z[1,0,3]  R238      4.3990376591682434e-01
    z[1,0,3]  R239      1.5750470757484436e-01
    z[1,0,3]  R240      3.4503984451293945e-01
    z[1,0,3]  R241      2.1747404336929321e-01
    z[1,0,3]  R242      -2.3556582629680634e-01
    z[1,0,3]  R243      -3.6711838841438293e-01
    z[1,0,3]  R244      -1.5590147674083710e-01
    z[1,0,3]  R245      2.1487775444984436e-01
    z[1,0,3]  R246      6.1241549253463745e-01
    z[1,0,3]  R247      1.1795209348201752e-01
    z[1,0,3]  R248      3.7257385253906250e-01
    z[1,0,3]  R249      1.6701427102088928e-01
    z[1,0,3]  R250      1.6665865480899811e-01
    z[1,0,3]  R251      3.8207578659057617e-01
    z[1,0,3]  R252      -0.322479784488678
    z[1,0,3]  R253      -1.3925144076347351e-01
    z[1,0,3]  R254      2.5316730141639709e-01
    z[1,0,3]  R255      2.4352559447288513e-01
    z[1,0,3]  R256      3.0174168944358826e-01
    z[1,0,3]  R257      -2.3458187282085419e-01
    z[1,0,3]  R258      -2.9041069746017456e-01
    z[1,0,3]  R259      -4.8186635971069336e-01
    z[1,0,3]  R260      -5.5097401142120361e-01
    z[1,0,3]  R261      -7.3731496930122375e-02
    z[1,0,4]  R6        1
    z[1,0,4]  R15       -1
    z[1,0,4]  R176      -1
    z[1,0,4]  R177      1
    z[1,0,4]  R182      -2.9989248514175415e-01
    z[1,0,4]  R183      4.0327611565589905e-01
    z[1,0,4]  R184      1.3635893166065216e-01
    z[1,0,4]  R185      -1.1704660207033157e-01
    z[1,0,4]  R186      -1.5881028771400452e-01
    z[1,0,4]  R187      -3.1409943103790283e-01
    z[1,0,4]  R188      -1.0652378201484680e-01
    z[1,0,4]  R189      -8.4657326340675354e-02
    z[1,0,4]  R190      -2.3083089292049408e-01
    z[1,0,4]  R191      -2.1730849146842957e-01
    z[1,0,4]  R192      -1.2386199086904526e-01
    z[1,0,4]  R193      1.3840185105800629e-01
    z[1,0,4]  R194      1.9290681183338165e-01
    z[1,0,4]  R195      -4.6147534251213074e-01
    z[1,0,4]  R196      -1.8422381579875946e-01
    z[1,0,4]  R197      -2.5764617323875427e-01
    z[1,0,4]  R198      1.6537123918533325e-01
    z[1,0,4]  R199      -4.1052049398422241e-01
    z[1,0,4]  R200      -2.0468063652515411e-01
    z[1,0,4]  R201      -7.2437569499015808e-02
    z[1,0,4]  R202      -2.6350542902946472e-01
    z[1,0,4]  R203      1.0137168318033218e-01
    z[1,0,4]  R204      1.3075691461563110e-01
    z[1,0,4]  R205      -1.4864277839660645e-01
    z[1,0,4]  R206      -9.7453128546476364e-04
    z[1,0,4]  R207      -1.4390507340431213e-01
    z[1,0,4]  R208      -1.9986103475093842e-01
    z[1,0,4]  R209      -2.4364335834980011e-01
    z[1,0,4]  R210      -2.0298688113689423e-01
    z[1,0,4]  R211      -1.5748099982738495e-01
    z[1,0,4]  R212      7.0507891476154327e-02
    z[1,0,4]  R213      2.3336309194564819e-01
    z[1,0,4]  R214      4.8944371519610286e-04
    z[1,0,4]  R215      2.4909204244613647e-01
    z[1,0,4]  R216      -5.0483405590057373e-01
    z[1,0,4]  R217      -3.9216119050979614e-01
    z[1,0,4]  R218      -6.7085914313793182e-02
    z[1,0,4]  R219      -3.5326597094535828e-01
    z[1,0,4]  R220      5.3770218044519424e-02
    z[1,0,4]  R221      -2.8380699455738068e-02
    z[1,0,4]  R222      2.6801860332489014e-01
    z[1,0,4]  R223      2.0113915205001831e-01
    z[1,0,4]  R224      -3.5000029206275940e-01
    z[1,0,4]  R225      3.5793926566839218e-02
    z[1,0,4]  R226      -2.7939385175704956e-01
    z[1,0,4]  R227      -6.3287980854511261e-02
    z[1,0,4]  R228      -3.6065548658370972e-01
    z[1,0,4]  R229      7.3096376657485962e-01
    z[1,0,4]  R230      6.7142558097839355e-01
    z[1,0,4]  R231      7.0937581360340118e-02
    z[1,0,4]  R232      1.3463832437992096e-01
    z[1,0,4]  R233      -5.1618558168411255e-01
    z[1,0,4]  R234      -4.5868670940399170e-01
    z[1,0,4]  R235      -5.8191988617181778e-02
    z[1,0,4]  R236      3.4410521388053894e-02
    z[1,0,4]  R237      1.1503663845360279e-03
    z[1,0,4]  R238      1.5963628888130188e-01
    z[1,0,4]  R239      -5.5157607793807983e-01
    z[1,0,4]  R240      -0.375713586807251
    z[1,0,4]  R241      -4.3983921408653259e-01
    z[1,0,4]  R242      -1.2373851612210274e-02
    z[1,0,4]  R243      -4.7766295075416565e-01
    z[1,0,4]  R244      4.1211850941181183e-02
    z[1,0,4]  R245      3.7129971385002136e-01
    z[1,0,4]  R246      -3.9886510372161865e-01
    z[1,0,4]  R247      -1.2034978717565536e-02
    z[1,0,4]  R248      -1.5882951021194458e-01
    z[1,0,4]  R249      1.3550990819931030e-01
    z[1,0,4]  R250      -4.2395928502082825e-01
    z[1,0,4]  R251      3.4098449349403381e-01
    z[1,0,4]  R252      -1.9753496162593365e-03
    z[1,0,4]  R253      -4.6900838613510132e-01
    z[1,0,4]  R254      -1.5267118811607361e-01
    z[1,0,4]  R255      7.8578270971775055e-02
    z[1,0,4]  R256      -6.4628034830093384e-02
    z[1,0,4]  R257      7.3250883817672729e-01
    z[1,0,4]  R258      0.703118085861206
    z[1,0,4]  R259      0.709367036819458
    z[1,0,4]  R260      0.629349946975708
    z[1,0,4]  R261      3.3739086985588074e-01
    z[1,0,5]  R7        1
    z[1,0,5]  R16       -1
    z[1,0,5]  R178      -1
    z[1,0,5]  R179      1
    z[1,0,5]  R182      -5.6651927297934890e-04
    z[1,0,5]  R183      9.0601295232772827e-02
    z[1,0,5]  R184      -1.7133527994155884e-01
    z[1,0,5]  R185      3.7299975752830505e-01
    z[1,0,5]  R186      4.1182979941368103e-01
    z[1,0,5]  R187      7.7907584607601166e-02
    z[1,0,5]  R188      2.6482158899307251e-01
    z[1,0,5]  R189      1.2379072606563568e-01
    z[1,0,5]  R190      6.4545914530754089e-02
    z[1,0,5]  R191      4.1312563419342041e-01
    z[1,0,5]  R192      -2.0584091544151306e-01
    z[1,0,5]  R193      2.3110151290893555e-01
    z[1,0,5]  R194      -5.2509274333715439e-02
    z[1,0,5]  R195      -3.2188376784324646e-01
    z[1,0,5]  R196      1.3271375000476837e-01
    z[1,0,5]  R197      -2.4289096891880035e-01
    z[1,0,5]  R198      7.5283623300492764e-03
    z[1,0,5]  R199      -1.3356009125709534e-01
    z[1,0,5]  R200      -1.5559597313404083e-01
    z[1,0,5]  R201      -5.3729629516601562e-01
    z[1,0,5]  R202      5.8139726519584656e-02
    z[1,0,5]  R203      1.5446808934211731e-01
    z[1,0,5]  R204      2.1611662581562996e-02
    z[1,0,5]  R205      -0.069243885576725
    z[1,0,5]  R206      1.6166546940803528e-01
    z[1,0,5]  R207      2.5690641254186630e-02
    z[1,0,5]  R208      -4.5451423525810242e-01
    z[1,0,5]  R209      -5.5896449089050293e-01
    z[1,0,5]  R210      -5.0081085413694382e-02
    z[1,0,5]  R211      -8.2788634300231934e-01
    z[1,0,5]  R212      -7.5349416583776474e-03
    z[1,0,5]  R213      -0.040500458329916
    z[1,0,5]  R214      2.0076100528240204e-01
    z[1,0,5]  R215      -0.453075110912323
    z[1,0,5]  R216      -3.6468061804771423e-01
    z[1,0,5]  R217      -4.3863037228584290e-01
    z[1,0,5]  R218      -3.8898301124572754e-01
    z[1,0,5]  R219      -2.8561952710151672e-01
    z[1,0,5]  R220      -3.9827275276184082e-01
    z[1,0,5]  R221      -4.4335415959358215e-01
    z[1,0,5]  R222      -6.1701886355876923e-02
    z[1,0,5]  R223      5.0466352701187134e-01
    z[1,0,5]  R224      7.1706078946590424e-02
    z[1,0,5]  R225      4.8978742957115173e-01
    z[1,0,5]  R226      7.1435786783695221e-02
    z[1,0,5]  R227      2.7940362691879272e-01
    z[1,0,5]  R228      2.7574056759476662e-02
    z[1,0,5]  R229      -2.2223636507987976e-02
    z[1,0,5]  R230      -3.3171564340591431e-02
    z[1,0,5]  R231      1.6031476855278015e-01
    z[1,0,5]  R232      -2.5239479541778564e-01
    z[1,0,5]  R233      -2.9416564106941223e-01
    z[1,0,5]  R234      -4.4694498181343079e-01
    z[1,0,5]  R235      2.7287902310490608e-02
    z[1,0,5]  R236      -2.4877880513668060e-01
    z[1,0,5]  R237      3.3808764070272446e-02
    z[1,0,5]  R238      -2.5906574726104736e-01
    z[1,0,5]  R239      5.7204663753509521e-02
    z[1,0,5]  R240      1.7534929513931274e-01
    z[1,0,5]  R241      -1.3360358774662018e-01
    z[1,0,5]  R242      -2.9011952877044678e-01
    z[1,0,5]  R243      -1.0443875938653946e-01
    z[1,0,5]  R244      -4.9709695577621460e-01
    z[1,0,5]  R245      -5.7766562700271606e-01
    z[1,0,5]  R246      -2.3226347565650940e-01
    z[1,0,5]  R247      -1.4635747671127319e-01
    z[1,0,5]  R248      9.5519470050930977e-03
    z[1,0,5]  R249      3.0473536252975464e-01
    z[1,0,5]  R250      -4.6242665499448776e-02
    z[1,0,5]  R251      -4.3257344514131546e-02
    z[1,0,5]  R252      -0.0999906063079834
    z[1,0,5]  R253      -6.9952070713043213e-01
    z[1,0,5]  R254      -3.9647076278924942e-02
    z[1,0,5]  R255      -1.4046829938888550e-01
    z[1,0,5]  R256      2.4029399454593658e-01
    z[1,0,5]  R257      -3.5800644755363464e-01
    z[1,0,5]  R258      -0.337938517332077
    z[1,0,5]  R259      -1.1036282777786255e-01
    z[1,0,5]  R260      -8.4956243634223938e-02
    z[1,0,5]  R261      3.1225770711898804e-01
    z[1,0,6]  R8        1
    z[1,0,6]  R17       -1
    z[1,0,6]  R180      -1
    z[1,0,6]  R181      1
    z[1,0,6]  R182      -2.9847362637519836e-01
    z[1,0,6]  R183      1.3364848494529724e-01
    z[1,0,6]  R184      5.7265937328338623e-01
    z[1,0,6]  R185      -3.7704864144325256e-01
    z[1,0,6]  R186      2.1458871662616730e-01
    z[1,0,6]  R187      4.5019667595624924e-03
    z[1,0,6]  R188      -4.5302253961563110e-01
    z[1,0,6]  R189      7.6544538140296936e-02
    z[1,0,6]  R190      -7.2506345808506012e-02
    z[1,0,6]  R191      2.6650076732039452e-02
    z[1,0,6]  R192      -3.7373367697000504e-02
    z[1,0,6]  R193      -1.4916238188743591e-01
    z[1,0,6]  R194      3.4588301181793213e-01
    z[1,0,6]  R195      -1.3130338490009308e-01
    z[1,0,6]  R196      9.6046822145581245e-03
    z[1,0,6]  R197      -2.5644913315773010e-01
    z[1,0,6]  R198      0.368935763835907
    z[1,0,6]  R199      2.1128838881850243e-02
    z[1,0,6]  R200      2.5318679213523865e-01
    z[1,0,6]  R201      2.0364819467067719e-01
    z[1,0,6]  R202      -3.6755308508872986e-02
    z[1,0,6]  R203      1.0403539240360260e-01
    z[1,0,6]  R204      -1.5753178298473358e-01
    z[1,0,6]  R205      3.5538470745086670e-01
    z[1,0,6]  R206      -5.3524747490882874e-02
    z[1,0,6]  R207      -7.6234750449657440e-02
    z[1,0,6]  R208      3.6388018727302551e-01
    z[1,0,6]  R209      2.8143441304564476e-02
    z[1,0,6]  R210      -5.3437568247318268e-02
    z[1,0,6]  R211      -7.5942777097225189e-02
    z[1,0,6]  R212      9.3145325779914856e-02
    z[1,0,6]  R213      -0.239437997341156
    z[1,0,6]  R214      4.5635515451431274e-01
    z[1,0,6]  R215      -2.7225065231323242e-01
    z[1,0,6]  R216      1.1862057447433472e-01
    z[1,0,6]  R217      3.4772762656211853e-01
    z[1,0,6]  R218      3.3204165101051331e-01
    z[1,0,6]  R219      -5.7194292545318604e-02
    z[1,0,6]  R220      -5.5794060230255127e-02
    z[1,0,6]  R221      -3.5684242844581604e-02
    z[1,0,6]  R222      -9.4843529164791107e-02
    z[1,0,6]  R223      -4.4247034937143326e-02
    z[1,0,6]  R224      -1.8037442862987518e-01
    z[1,0,6]  R225      1.4140436053276062e-01
    z[1,0,6]  R226      -3.3865347504615784e-01
    z[1,0,6]  R227      -7.3839861154556274e-01
    z[1,0,6]  R228      -1.4461073279380798e-01
    z[1,0,6]  R229      3.3890013583004475e-03
    z[1,0,6]  R230      -0.572462260723114
    z[1,0,6]  R231      -5.0207413733005524e-02
    z[1,0,6]  R232      1.2897881865501404e-01
    z[1,0,6]  R233      -1.3239070773124695e-01
    z[1,0,6]  R234      4.2681512236595154e-01
    z[1,0,6]  R235      3.8436099886894226e-01
    z[1,0,6]  R236      3.3493393659591675e-01
    z[1,0,6]  R237      -2.5354269146919250e-01
    z[1,0,6]  R238      -1.8567276000976562e-01
    z[1,0,6]  R239      2.1535407006740570e-01
    z[1,0,6]  R240      1.4603652060031891e-02
    z[1,0,6]  R241      -2.1024686098098755e-01
    z[1,0,6]  R242      3.7960490584373474e-01
    z[1,0,6]  R243      5.5432099103927612e-01
    z[1,0,6]  R244      -3.9354091882705688e-01
    z[1,0,6]  R245      1.8088878691196442e-01
    z[1,0,6]  R246      4.9985662102699280e-01
    z[1,0,6]  R247      -9.1941304504871368e-02
    z[1,0,6]  R248      -4.7092538326978683e-02
    z[1,0,6]  R249      -5.3763326257467270e-02
    z[1,0,6]  R250      5.1233269274234772e-02
    z[1,0,6]  R251      7.9844966530799866e-02
    z[1,0,6]  R252      -7.3772174119949341e-01
    z[1,0,6]  R253      -3.0384582281112671e-01
    z[1,0,6]  R254      2.9911282658576965e-01
    z[1,0,6]  R255      1.6414389014244080e-01
    z[1,0,6]  R256      3.3838972449302673e-02
    z[1,0,6]  R257      5.6156627833843231e-02
    z[1,0,6]  R258      1.5955096110701561e-02
    z[1,0,6]  R259      2.2048467770218849e-02
    z[1,0,6]  R260      3.1257644295692444e-01
    z[1,0,6]  R261      -4.8394206911325455e-02
    z[0,4,0]  R2        -1
    z[0,4,0]  R38       1
    z[0,4,0]  R262      -1
    z[0,4,0]  R263      1
    z[0,4,0]  R276      -4.5784229040145874e-01
    z[0,4,0]  R277      4.6131291985511780e-01
    z[0,4,0]  R278      3.7151578068733215e-01
    z[0,4,0]  R279      -6.8760626018047333e-02
    z[0,4,0]  R280      0.0141522828489542
    z[0,4,0]  R281      -1.6506123542785645e-01
    z[0,4,0]  R282      -7.6237481832504272e-01
    z[0,4,0]  R283      5.3342336416244507e-01
    z[0,4,0]  R284      -3.3378910273313522e-02
    z[0,4,0]  R285      -1.6487009823322296e-01
    z[0,4,0]  R286      2.8163021802902222e-01
    z[0,4,0]  R287      2.4612860381603241e-01
    z[0,4,0]  R288      2.1519605815410614e-01
    z[0,4,0]  R289      2.7198189496994019e-01
    z[0,4,0]  R290      3.3863645792007446e-01
    z[0,4,0]  R291      5.9116703271865845e-01
    z[0,4,0]  R292      4.1720378398895264e-01
    z[0,4,0]  R293      2.8617396950721741e-01
    z[0,4,0]  R294      1.5544786583632231e-03
    z[0,4,0]  R295      4.7697207331657410e-01
    z[0,4,0]  R296      2.3475369811058044e-01
    z[0,4,0]  R297      -1.9980992376804352e-01
    z[0,4,0]  R298      3.2136179506778717e-02
    z[0,4,0]  R299      6.4604693651199341e-01
    z[0,4,0]  R300      3.6950138211250305e-01
    z[0,4,0]  R301      2.7707502245903015e-01
    z[0,4,0]  R302      5.1643788814544678e-02
    z[0,4,0]  R303      1.8287500739097595e-01
    z[0,4,0]  R304      1.7971959710121155e-01
    z[0,4,0]  R305      -8.7597921490669250e-02
    z[0,4,0]  R306      1.5850837528705597e-01
    z[0,4,0]  R307      3.3547121286392212e-01
    z[0,4,0]  R308      -7.3378556966781616e-01
    z[0,4,0]  R309      7.8569218516349792e-02
    z[0,4,0]  R310      3.8134112954139709e-01
    z[0,4,0]  R311      -2.4140600860118866e-01
    z[0,4,0]  R312      -7.0312604308128357e-02
    z[0,4,0]  R313      -3.6191427707672119e-01
    z[0,4,0]  R314      -1.1698658764362335e-01
    z[0,4,0]  R315      -6.2288141250610352e-01
    z[0,4,0]  R316      -1.3544252514839172e-01
    z[0,4,0]  R317      4.6744519472122192e-01
    z[0,4,0]  R318      3.8565129041671753e-01
    z[0,4,0]  R319      2.2729112207889557e-01
    z[0,4,0]  R320      3.9012342691421509e-02
    z[0,4,0]  R321      -3.9402687549591064e-01
    z[0,4,0]  R322      3.7529698014259338e-01
    z[0,4,0]  R323      -2.4144466221332550e-01
    z[0,4,0]  R324      -4.5150774717330933e-01
    z[0,4,0]  R325      -0.0822141021490097
    z[0,4,0]  R326      -3.6437591910362244e-01
    z[0,4,0]  R327      2.1702052652835846e-01
    z[0,4,0]  R328      -1.5074262022972107e-01
    z[0,4,0]  R329      -4.3471691012382507e-01
    z[0,4,0]  R330      -4.4951498508453369e-01
    z[0,4,0]  R331      4.3127852678298950e-01
    z[0,4,0]  R332      1.6457749903202057e-01
    z[0,4,0]  R333      1.2404111027717590e-01
    z[0,4,0]  R334      1.3128182291984558e-01
    z[0,4,1]  R3        -1
    z[0,4,1]  R39       1
    z[0,4,1]  R264      -1
    z[0,4,1]  R265      1
    z[0,4,1]  R276      6.9972306489944458e-01
    z[0,4,1]  R277      5.9919810295104980e-01
    z[0,4,1]  R278      5.3524309396743774e-01
    z[0,4,1]  R279      0.841986358165741
    z[0,4,1]  R280      7.0326012372970581e-01
    z[0,4,1]  R281      5.3300845623016357e-01
    z[0,4,1]  R282      4.3354243040084839e-01
    z[0,4,1]  R283      3.0983239412307739e-01
    z[0,4,1]  R284      4.4980236887931824e-01
    z[0,4,1]  R285      -8.6187058687210083e-01
    z[0,4,1]  R286      2.3115375638008118e-01
    z[0,4,1]  R287      5.3061640262603760e-01
    z[0,4,1]  R288      4.6046841144561768e-01
    z[0,4,1]  R289      -7.6222550868988037e-01
    z[0,4,1]  R290      -8.3081328868865967e-01
    z[0,4,1]  R291      -7.4058449268341064e-01
    z[0,4,1]  R292      -0.678173303604126
    z[0,4,1]  R293      -7.3438102006912231e-01
    z[0,4,1]  R294      -7.9568070173263550e-01
    z[0,4,1]  R295      -0.67437344789505
    z[0,4,1]  R296      6.9934010505676270e-01
    z[0,4,1]  R297      4.0863081812858582e-01
    z[0,4,1]  R298      7.5545167922973633e-01
    z[0,4,1]  R299      8.9056707918643951e-02
    z[0,4,1]  R300      1.5969778597354889e-01
    z[0,4,1]  R301      -9.3229299783706665e-01
    z[0,4,1]  R302      -8.6355835199356079e-01
    z[0,4,1]  R303      -8.9983057975769043e-01
    z[0,4,1]  R304      -8.6051493883132935e-01
    z[0,4,1]  R305      -8.0782520771026611e-01
    z[0,4,1]  R306      5.6270515918731689e-01
    z[0,4,1]  R307      2.5091478228569031e-01
    z[0,4,1]  R308      4.7580823302268982e-01
    z[0,4,1]  R309      -9.2943161725997925e-01
    z[0,4,1]  R310      -8.3177280426025391e-01
    z[0,4,1]  R311      -4.4241887331008911e-01
    z[0,4,1]  R312      -4.0229710936546326e-01
    z[0,4,1]  R313      -3.4467756748199463e-01
    z[0,4,1]  R314      -0.289137065410614
    z[0,4,1]  R315      -3.1193533539772034e-01
    z[0,4,1]  R316      5.9941875934600830e-01
    z[0,4,1]  R317      5.9997326135635376e-01
    z[0,4,1]  R318      3.2528099417686462e-01
    z[0,4,1]  R319      -4.5928034186363220e-01
    z[0,4,1]  R320      5.6652998924255371e-01
    z[0,4,1]  R321      5.0626343488693237e-01
    z[0,4,1]  R322      -4.8687958717346191e-01
    z[0,4,1]  R323      4.6423014998435974e-01
    z[0,4,1]  R324      3.9923894405364990e-01
    z[0,4,1]  R325      3.7479737401008606e-01
    z[0,4,1]  R326      5.6444448232650757e-01
    z[0,4,1]  R327      1.4548103511333466e-01
    z[0,4,1]  R328      3.9232549071311951e-01
    z[0,4,1]  R329      0.671127200126648
    z[0,4,1]  R330      5.6460309028625488e-01
    z[0,4,1]  R331      -6.0256713628768921e-01
    z[0,4,1]  R332      -6.9524329900741577e-01
    z[0,4,1]  R333      -4.3254745006561279e-01
    z[0,4,1]  R334      -8.9349585771560669e-01
    z[0,4,2]  R4        -1
    z[0,4,2]  R40       1
    z[0,4,2]  R266      -1
    z[0,4,2]  R267      1
    z[0,4,2]  R276      4.1182544827461243e-01
    z[0,4,2]  R277      3.4214559197425842e-01
    z[0,4,2]  R278      6.4146476984024048e-01
    z[0,4,2]  R279      -5.8745678514242172e-02
    z[0,4,2]  R280      2.9820975661277771e-01
    z[0,4,2]  R281      2.3407407104969025e-01
    z[0,4,2]  R282      2.0372729003429413e-01
    z[0,4,2]  R283      -2.8888460993766785e-01
    z[0,4,2]  R284      1.2944971024990082e-01
    z[0,4,2]  R285      3.1971395015716553e-01
    z[0,4,2]  R286      -5.3114318847656250e-01
    z[0,4,2]  R287      -2.8720572590827942e-01
    z[0,4,2]  R288      -3.4075200557708740e-01
    z[0,4,2]  R289      0.0651799812912941
    z[0,4,2]  R290      -1.0540736466646194e-01
    z[0,4,2]  R291      5.5763799697160721e-02
    z[0,4,2]  R292      2.1315130591392517e-01
    z[0,4,2]  R293      9.7647868096828461e-03
    z[0,4,2]  R294      2.7516508102416992e-01
    z[0,4,2]  R295      1.2211017310619354e-01
    z[0,4,2]  R296      -4.1460892558097839e-01
    z[0,4,2]  R297      -3.3463403582572937e-01
    z[0,4,2]  R298      -1.6629112884402275e-02
    z[0,4,2]  R299      -1.5568526089191437e-01
    z[0,4,2]  R300      4.0350826457142830e-03
    z[0,4,2]  R301      1.0063806176185608e-01
    z[0,4,2]  R302      2.9198083281517029e-01
    z[0,4,2]  R303      1.2186415493488312e-01
    z[0,4,2]  R304      1.2220936268568039e-01
    z[0,4,2]  R305      2.6314669847488403e-01
    z[0,4,2]  R306      -3.0581615865230560e-03
    z[0,4,2]  R307      -5.9071831405162811e-02
    z[0,4,2]  R308      2.3816527426242828e-01
    z[0,4,2]  R309      1.3352888822555542e-01
    z[0,4,2]  R310      9.2853292822837830e-02
    z[0,4,2]  R311      1.5188363194465637e-01
    z[0,4,2]  R312      3.7422287464141846e-01
    z[0,4,2]  R313      4.6395204961299896e-02
    z[0,4,2]  R314      3.1327095627784729e-01
    z[0,4,2]  R315      -5.4369044303894043e-01
    z[0,4,2]  R316      4.7314766049385071e-01
    z[0,4,2]  R317      3.4393441677093506e-01
    z[0,4,2]  R318      -5.5661749839782715e-01
    z[0,4,2]  R319      7.3411154747009277e-01
    z[0,4,2]  R320      -7.3292267322540283e-01
    z[0,4,2]  R321      -2.2035045921802521e-01
    z[0,4,2]  R322      0.354841947555542
    z[0,4,2]  R323      -4.4543719291687012e-01
    z[0,4,2]  R324      -4.6101558208465576e-01
    z[0,4,2]  R325      -3.0765122175216675e-01
    z[0,4,2]  R326      -4.0702033042907715e-01
    z[0,4,2]  R327      9.9146686494350433e-02
    z[0,4,2]  R328      -1.1688224039971828e-02
    z[0,4,2]  R329      1.8368528783321381e-01
    z[0,4,2]  R330      -2.7939698100090027e-01
    z[0,4,2]  R331      -2.1570718288421631e-01
    z[0,4,2]  R332      2.5934013724327087e-01
    z[0,4,2]  R333      1.0537172108888626e-01
    z[0,4,2]  R334      -1.0331146419048309e-01
    z[0,4,3]  R5        -1
    z[0,4,3]  R41       1
    z[0,4,3]  R268      -1
    z[0,4,3]  R269      1
    z[0,4,3]  R276      2.1571151912212372e-01
    z[0,4,3]  R277      1.1827246844768524e-01
    z[0,4,3]  R278      6.1942975968122482e-02
    z[0,4,3]  R279      1.4734905958175659e-01
    z[0,4,3]  R280      4.6738174557685852e-01
    z[0,4,3]  R281      -8.1005841493606567e-02
    z[0,4,3]  R282      -1.9384460151195526e-01
    z[0,4,3]  R283      -3.4577727317810059e-02
    z[0,4,3]  R284      -1.3444166630506516e-02
    z[0,4,3]  R285      3.0745112895965576e-01
    z[0,4,3]  R286      -6.9761967658996582e-01
    z[0,4,3]  R287      -4.5262724161148071e-01
    z[0,4,3]  R288      -1.8227195739746094e-01
    z[0,4,3]  R289      4.3465545773506165e-01
    z[0,4,3]  R290      9.3317292630672455e-02
    z[0,4,3]  R291      1.8307955563068390e-01
    z[0,4,3]  R292      4.3990376591682434e-01
    z[0,4,3]  R293      1.5750470757484436e-01
    z[0,4,3]  R294      3.4503984451293945e-01
    z[0,4,3]  R295      2.1747404336929321e-01
    z[0,4,3]  R296      -2.3556582629680634e-01
    z[0,4,3]  R297      -3.6711838841438293e-01
    z[0,4,3]  R298      -1.5590147674083710e-01
    z[0,4,3]  R299      2.1487775444984436e-01
    z[0,4,3]  R300      6.1241549253463745e-01
    z[0,4,3]  R301      1.1795209348201752e-01
    z[0,4,3]  R302      3.7257385253906250e-01
    z[0,4,3]  R303      1.6701427102088928e-01
    z[0,4,3]  R304      1.6665865480899811e-01
    z[0,4,3]  R305      3.8207578659057617e-01
    z[0,4,3]  R306      -0.322479784488678
    z[0,4,3]  R307      -1.3925144076347351e-01
    z[0,4,3]  R308      2.5316730141639709e-01
    z[0,4,3]  R309      2.4352559447288513e-01
    z[0,4,3]  R310      3.0174168944358826e-01
    z[0,4,3]  R311      -2.3458187282085419e-01
    z[0,4,3]  R312      -2.9041069746017456e-01
    z[0,4,3]  R313      -4.8186635971069336e-01
    z[0,4,3]  R314      -5.5097401142120361e-01
    z[0,4,3]  R315      -7.3731496930122375e-02
    z[0,4,3]  R316      -2.4220316112041473e-01
    z[0,4,3]  R317      1.1200608313083649e-01
    z[0,4,3]  R318      -9.1599315404891968e-02
    z[0,4,3]  R319      3.8009887933731079e-01
    z[0,4,3]  R320      1.6812488436698914e-01
    z[0,4,3]  R321      -3.6225453019142151e-01
    z[0,4,3]  R322      4.8625072836875916e-01
    z[0,4,3]  R323      -2.2988341748714447e-01
    z[0,4,3]  R324      -5.0863057374954224e-01
    z[0,4,3]  R325      1.8882469832897186e-01
    z[0,4,3]  R326      -9.0798944234848022e-02
    z[0,4,3]  R327      -4.2324650287628174e-01
    z[0,4,3]  R328      2.4133273959159851e-01
    z[0,4,3]  R329      7.0253565907478333e-02
    z[0,4,3]  R330      -1.6083383560180664e-01
    z[0,4,3]  R331      -1.9417789578437805e-01
    z[0,4,3]  R332      -3.5769420862197876e-01
    z[0,4,3]  R333      -4.0315032005310059e-01
    z[0,4,3]  R334      7.3971413075923920e-02
    z[0,4,4]  R6        -1
    z[0,4,4]  R42       1
    z[0,4,4]  R270      -1
    z[0,4,4]  R271      1
    z[0,4,4]  R276      2.6801860332489014e-01
    z[0,4,4]  R277      2.0113915205001831e-01
    z[0,4,4]  R278      -3.5000029206275940e-01
    z[0,4,4]  R279      3.5793926566839218e-02
    z[0,4,4]  R280      -2.7939385175704956e-01
    z[0,4,4]  R281      -6.3287980854511261e-02
    z[0,4,4]  R282      -3.6065548658370972e-01
    z[0,4,4]  R283      7.3096376657485962e-01
    z[0,4,4]  R284      6.7142558097839355e-01
    z[0,4,4]  R285      7.0937581360340118e-02
    z[0,4,4]  R286      1.3463832437992096e-01
    z[0,4,4]  R287      -5.1618558168411255e-01
    z[0,4,4]  R288      -4.5868670940399170e-01
    z[0,4,4]  R289      -5.8191988617181778e-02
    z[0,4,4]  R290      3.4410521388053894e-02
    z[0,4,4]  R291      1.1503663845360279e-03
    z[0,4,4]  R292      1.5963628888130188e-01
    z[0,4,4]  R293      -5.5157607793807983e-01
    z[0,4,4]  R294      -0.375713586807251
    z[0,4,4]  R295      -4.3983921408653259e-01
    z[0,4,4]  R296      -1.2373851612210274e-02
    z[0,4,4]  R297      -4.7766295075416565e-01
    z[0,4,4]  R298      4.1211850941181183e-02
    z[0,4,4]  R299      3.7129971385002136e-01
    z[0,4,4]  R300      -3.9886510372161865e-01
    z[0,4,4]  R301      -1.2034978717565536e-02
    z[0,4,4]  R302      -1.5882951021194458e-01
    z[0,4,4]  R303      1.3550990819931030e-01
    z[0,4,4]  R304      -4.2395928502082825e-01
    z[0,4,4]  R305      3.4098449349403381e-01
    z[0,4,4]  R306      -1.9753496162593365e-03
    z[0,4,4]  R307      -4.6900838613510132e-01
    z[0,4,4]  R308      -1.5267118811607361e-01
    z[0,4,4]  R309      7.8578270971775055e-02
    z[0,4,4]  R310      -6.4628034830093384e-02
    z[0,4,4]  R311      7.3250883817672729e-01
    z[0,4,4]  R312      0.703118085861206
    z[0,4,4]  R313      0.709367036819458
    z[0,4,4]  R314      0.629349946975708
    z[0,4,4]  R315      3.3739086985588074e-01
    z[0,4,4]  R316      2.8842657804489136e-01
    z[0,4,4]  R317      1.9966131448745728e-01
    z[0,4,4]  R318      -4.4427019357681274e-01
    z[0,4,4]  R319      1.9556620717048645e-01
    z[0,4,4]  R320      -2.0001649856567383e-01
    z[0,4,4]  R321      5.0343668460845947e-01
    z[0,4,4]  R322      -1.6372986137866974e-01
    z[0,4,4]  R323      3.1951498240232468e-03
    z[0,4,4]  R324      -3.9187619090080261e-01
    z[0,4,4]  R325      3.1968098878860474e-01
    z[0,4,4]  R326      -5.4483091831207275e-01
    z[0,4,4]  R327      5.3580832481384277e-01
    z[0,4,4]  R328      -8.9582674205303192e-02
    z[0,4,4]  R329      -1.2088719755411148e-01
    z[0,4,4]  R330      1.6698222607374191e-02
    z[0,4,4]  R331      4.3900626897811890e-01
    z[0,4,4]  R332      0.0387524850666523
    z[0,4,4]  R333      -1.5400440990924835e-01
    z[0,4,4]  R334      -2.8708747029304504e-01
    z[0,4,5]  R7        -1
    z[0,4,5]  R43       1
    z[0,4,5]  R272      -1
    z[0,4,5]  R273      1
    z[0,4,5]  R276      -6.1701886355876923e-02
    z[0,4,5]  R277      5.0466352701187134e-01
    z[0,4,5]  R278      7.1706078946590424e-02
    z[0,4,5]  R279      4.8978742957115173e-01
    z[0,4,5]  R280      7.1435786783695221e-02
    z[0,4,5]  R281      2.7940362691879272e-01
    z[0,4,5]  R282      2.7574056759476662e-02
    z[0,4,5]  R283      -2.2223636507987976e-02
    z[0,4,5]  R284      -3.3171564340591431e-02
    z[0,4,5]  R285      1.6031476855278015e-01
    z[0,4,5]  R286      -2.5239479541778564e-01
    z[0,4,5]  R287      -2.9416564106941223e-01
    z[0,4,5]  R288      -4.4694498181343079e-01
    z[0,4,5]  R289      2.7287902310490608e-02
    z[0,4,5]  R290      -2.4877880513668060e-01
    z[0,4,5]  R291      3.3808764070272446e-02
    z[0,4,5]  R292      -2.5906574726104736e-01
    z[0,4,5]  R293      5.7204663753509521e-02
    z[0,4,5]  R294      1.7534929513931274e-01
    z[0,4,5]  R295      -1.3360358774662018e-01
    z[0,4,5]  R296      -2.9011952877044678e-01
    z[0,4,5]  R297      -1.0443875938653946e-01
    z[0,4,5]  R298      -4.9709695577621460e-01
    z[0,4,5]  R299      -5.7766562700271606e-01
    z[0,4,5]  R300      -2.3226347565650940e-01
    z[0,4,5]  R301      -1.4635747671127319e-01
    z[0,4,5]  R302      9.5519470050930977e-03
    z[0,4,5]  R303      3.0473536252975464e-01
    z[0,4,5]  R304      -4.6242665499448776e-02
    z[0,4,5]  R305      -4.3257344514131546e-02
    z[0,4,5]  R306      -0.0999906063079834
    z[0,4,5]  R307      -6.9952070713043213e-01
    z[0,4,5]  R308      -3.9647076278924942e-02
    z[0,4,5]  R309      -1.4046829938888550e-01
    z[0,4,5]  R310      2.4029399454593658e-01
    z[0,4,5]  R311      -3.5800644755363464e-01
    z[0,4,5]  R312      -0.337938517332077
    z[0,4,5]  R313      -1.1036282777786255e-01
    z[0,4,5]  R314      -8.4956243634223938e-02
    z[0,4,5]  R315      3.1225770711898804e-01
    z[0,4,5]  R316      2.6128500699996948e-02
    z[0,4,5]  R317      4.9888265132904053e-01
    z[0,4,5]  R318      4.6686807274818420e-01
    z[0,4,5]  R319      -6.0093704611063004e-02
    z[0,4,5]  R320      -2.4372828006744385e-01
    z[0,4,5]  R321      -1.6527295112609863e-01
    z[0,4,5]  R322      -0.0574694387614727
    z[0,4,5]  R323      -1.0356678813695908e-01
    z[0,4,5]  R324      8.7697193026542664e-02
    z[0,4,5]  R325      -0.725053608417511
    z[0,4,5]  R326      -2.0311726629734039e-01
    z[0,4,5]  R327      -2.9575619101524353e-01
    z[0,4,5]  R328      -0.324920654296875
    z[0,4,5]  R329      -3.4698531031608582e-01
    z[0,4,5]  R330      -2.9969671368598938e-01
    z[0,4,5]  R331      4.1022595763206482e-01
    z[0,4,5]  R332      5.3775095939636230e-01
    z[0,4,5]  R333      5.9714996814727783e-01
    z[0,4,5]  R334      -4.7690412029623985e-03
    z[0,4,6]  R8        -1
    z[0,4,6]  R44       1
    z[0,4,6]  R274      -1
    z[0,4,6]  R275      1
    z[0,4,6]  R276      -9.4843529164791107e-02
    z[0,4,6]  R277      -4.4247034937143326e-02
    z[0,4,6]  R278      -1.8037442862987518e-01
    z[0,4,6]  R279      1.4140436053276062e-01
    z[0,4,6]  R280      -3.3865347504615784e-01
    z[0,4,6]  R281      -7.3839861154556274e-01
    z[0,4,6]  R282      -1.4461073279380798e-01
    z[0,4,6]  R283      3.3890013583004475e-03
    z[0,4,6]  R284      -0.572462260723114
    z[0,4,6]  R285      -5.0207413733005524e-02
    z[0,4,6]  R286      1.2897881865501404e-01
    z[0,4,6]  R287      -1.3239070773124695e-01
    z[0,4,6]  R288      4.2681512236595154e-01
    z[0,4,6]  R289      3.8436099886894226e-01
    z[0,4,6]  R290      3.3493393659591675e-01
    z[0,4,6]  R291      -2.5354269146919250e-01
    z[0,4,6]  R292      -1.8567276000976562e-01
    z[0,4,6]  R293      2.1535407006740570e-01
    z[0,4,6]  R294      1.4603652060031891e-02
    z[0,4,6]  R295      -2.1024686098098755e-01
    z[0,4,6]  R296      3.7960490584373474e-01
    z[0,4,6]  R297      5.5432099103927612e-01
    z[0,4,6]  R298      -3.9354091882705688e-01
    z[0,4,6]  R299      1.8088878691196442e-01
    z[0,4,6]  R300      4.9985662102699280e-01
    z[0,4,6]  R301      -9.1941304504871368e-02
    z[0,4,6]  R302      -4.7092538326978683e-02
    z[0,4,6]  R303      -5.3763326257467270e-02
    z[0,4,6]  R304      5.1233269274234772e-02
    z[0,4,6]  R305      7.9844966530799866e-02
    z[0,4,6]  R306      -7.3772174119949341e-01
    z[0,4,6]  R307      -3.0384582281112671e-01
    z[0,4,6]  R308      2.9911282658576965e-01
    z[0,4,6]  R309      1.6414389014244080e-01
    z[0,4,6]  R310      3.3838972449302673e-02
    z[0,4,6]  R311      5.6156627833843231e-02
    z[0,4,6]  R312      1.5955096110701561e-02
    z[0,4,6]  R313      2.2048467770218849e-02
    z[0,4,6]  R314      3.1257644295692444e-01
    z[0,4,6]  R315      -4.8394206911325455e-02
    z[0,4,6]  R316      -5.0591373443603516e-01
    z[0,4,6]  R317      -4.4070344418287277e-02
    z[0,4,6]  R318      -1.0913307219743729e-01
    z[0,4,6]  R319      -1.1021775007247925e-01
    z[0,4,6]  R320      -1.1256178468465805e-01
    z[0,4,6]  R321      -3.5762250423431396e-01
    z[0,4,6]  R322      -4.7920525074005127e-01
    z[0,4,6]  R323      -6.8132072687149048e-01
    z[0,4,6]  R324      6.5198019146919250e-02
    z[0,4,6]  R325      3.0751428008079529e-01
    z[0,4,6]  R326      -1.9137734174728394e-01
    z[0,4,6]  R327      6.0680097341537476e-01
    z[0,4,6]  R328      8.0708169937133789e-01
    z[0,4,6]  R329      4.3234363198280334e-01
    z[0,4,6]  R330      5.3397798538208008e-01
    z[0,4,6]  R331      7.5266867876052856e-02
    z[0,4,6]  R332      -6.0586854815483093e-02
    z[0,4,6]  R333      4.9353587627410889e-01
    z[0,4,6]  R334      2.9299014806747437e-01
    z[4,0,0]  R2        1
    z[4,0,0]  R38       -1
    z[4,0,0]  R335      -1
    z[4,0,0]  R336      1
    z[4,0,0]  R349      -1.3544252514839172e-01
    z[4,0,0]  R350      3.7151578068733215e-01
    z[4,0,0]  R351      4.6744519472122192e-01
    z[4,0,0]  R352      3.8565129041671753e-01
    z[4,0,0]  R353      2.2729112207889557e-01
    z[4,0,0]  R354      3.9012342691421509e-02
    z[4,0,0]  R355      -3.9402687549591064e-01
    z[4,0,0]  R356      3.7529698014259338e-01
    z[4,0,0]  R357      -2.4144466221332550e-01
    z[4,0,0]  R358      -4.5150774717330933e-01
    z[4,0,0]  R359      -0.0822141021490097
    z[4,0,0]  R360      -3.6437591910362244e-01
    z[4,0,0]  R361      2.1702052652835846e-01
    z[4,0,0]  R362      -1.5074262022972107e-01
    z[4,0,0]  R363      -4.3471691012382507e-01
    z[4,0,0]  R364      -4.4951498508453369e-01
    z[4,0,0]  R365      4.3127852678298950e-01
    z[4,0,0]  R366      1.6457749903202057e-01
    z[4,0,0]  R367      1.2404111027717590e-01
    z[4,0,0]  R368      1.3128182291984558e-01
    z[4,0,0]  R369      -4.5784229040145874e-01
    z[4,0,0]  R370      4.6131291985511780e-01
    z[4,0,0]  R371      -6.8760626018047333e-02
    z[4,0,0]  R372      0.0141522828489542
    z[4,0,0]  R373      -1.6506123542785645e-01
    z[4,0,0]  R374      -7.6237481832504272e-01
    z[4,0,0]  R375      5.3342336416244507e-01
    z[4,0,0]  R376      -3.3378910273313522e-02
    z[4,0,0]  R377      -1.6487009823322296e-01
    z[4,0,0]  R378      2.8163021802902222e-01
    z[4,0,0]  R379      2.4612860381603241e-01
    z[4,0,0]  R380      2.1519605815410614e-01
    z[4,0,0]  R381      2.7198189496994019e-01
    z[4,0,0]  R382      3.3863645792007446e-01
    z[4,0,0]  R383      5.9116703271865845e-01
    z[4,0,0]  R384      4.1720378398895264e-01
    z[4,0,0]  R385      2.8617396950721741e-01
    z[4,0,0]  R386      1.5544786583632231e-03
    z[4,0,0]  R387      4.7697207331657410e-01
    z[4,0,0]  R388      2.3475369811058044e-01
    z[4,0,0]  R389      -1.9980992376804352e-01
    z[4,0,0]  R390      3.2136179506778717e-02
    z[4,0,0]  R391      6.4604693651199341e-01
    z[4,0,0]  R392      3.6950138211250305e-01
    z[4,0,0]  R393      2.7707502245903015e-01
    z[4,0,0]  R394      5.1643788814544678e-02
    z[4,0,0]  R395      1.8287500739097595e-01
    z[4,0,0]  R396      1.7971959710121155e-01
    z[4,0,0]  R397      -8.7597921490669250e-02
    z[4,0,0]  R398      1.5850837528705597e-01
    z[4,0,0]  R399      3.3547121286392212e-01
    z[4,0,0]  R400      -7.3378556966781616e-01
    z[4,0,0]  R401      7.8569218516349792e-02
    z[4,0,0]  R402      3.8134112954139709e-01
    z[4,0,0]  R403      -2.4140600860118866e-01
    z[4,0,0]  R404      -7.0312604308128357e-02
    z[4,0,0]  R405      -3.6191427707672119e-01
    z[4,0,0]  R406      -1.1698658764362335e-01
    z[4,0,0]  R407      -6.2288141250610352e-01
    z[4,0,1]  R3        1
    z[4,0,1]  R39       -1
    z[4,0,1]  R337      -1
    z[4,0,1]  R338      1
    z[4,0,1]  R349      5.9941875934600830e-01
    z[4,0,1]  R350      5.3524309396743774e-01
    z[4,0,1]  R351      5.9997326135635376e-01
    z[4,0,1]  R352      3.2528099417686462e-01
    z[4,0,1]  R353      -4.5928034186363220e-01
    z[4,0,1]  R354      5.6652998924255371e-01
    z[4,0,1]  R355      5.0626343488693237e-01
    z[4,0,1]  R356      -4.8687958717346191e-01
    z[4,0,1]  R357      4.6423014998435974e-01
    z[4,0,1]  R358      3.9923894405364990e-01
    z[4,0,1]  R359      3.7479737401008606e-01
    z[4,0,1]  R360      5.6444448232650757e-01
    z[4,0,1]  R361      1.4548103511333466e-01
    z[4,0,1]  R362      3.9232549071311951e-01
    z[4,0,1]  R363      0.671127200126648
    z[4,0,1]  R364      5.6460309028625488e-01
    z[4,0,1]  R365      -6.0256713628768921e-01
    z[4,0,1]  R366      -6.9524329900741577e-01
    z[4,0,1]  R367      -4.3254745006561279e-01
    z[4,0,1]  R368      -8.9349585771560669e-01
    z[4,0,1]  R369      6.9972306489944458e-01
    z[4,0,1]  R370      5.9919810295104980e-01
    z[4,0,1]  R371      0.841986358165741
    z[4,0,1]  R372      7.0326012372970581e-01
    z[4,0,1]  R373      5.3300845623016357e-01
    z[4,0,1]  R374      4.3354243040084839e-01
    z[4,0,1]  R375      3.0983239412307739e-01
    z[4,0,1]  R376      4.4980236887931824e-01
    z[4,0,1]  R377      -8.6187058687210083e-01
    z[4,0,1]  R378      2.3115375638008118e-01
    z[4,0,1]  R379      5.3061640262603760e-01
    z[4,0,1]  R380      4.6046841144561768e-01
    z[4,0,1]  R381      -7.6222550868988037e-01
    z[4,0,1]  R382      -8.3081328868865967e-01
    z[4,0,1]  R383      -7.4058449268341064e-01
    z[4,0,1]  R384      -0.678173303604126
    z[4,0,1]  R385      -7.3438102006912231e-01
    z[4,0,1]  R386      -7.9568070173263550e-01
    z[4,0,1]  R387      -0.67437344789505
    z[4,0,1]  R388      6.9934010505676270e-01
    z[4,0,1]  R389      4.0863081812858582e-01
    z[4,0,1]  R390      7.5545167922973633e-01
    z[4,0,1]  R391      8.9056707918643951e-02
    z[4,0,1]  R392      1.5969778597354889e-01
    z[4,0,1]  R393      -9.3229299783706665e-01
    z[4,0,1]  R394      -8.6355835199356079e-01
    z[4,0,1]  R395      -8.9983057975769043e-01
    z[4,0,1]  R396      -8.6051493883132935e-01
    z[4,0,1]  R397      -8.0782520771026611e-01
    z[4,0,1]  R398      5.6270515918731689e-01
    z[4,0,1]  R399      2.5091478228569031e-01
    z[4,0,1]  R400      4.7580823302268982e-01
    z[4,0,1]  R401      -9.2943161725997925e-01
    z[4,0,1]  R402      -8.3177280426025391e-01
    z[4,0,1]  R403      -4.4241887331008911e-01
    z[4,0,1]  R404      -4.0229710936546326e-01
    z[4,0,1]  R405      -3.4467756748199463e-01
    z[4,0,1]  R406      -0.289137065410614
    z[4,0,1]  R407      -3.1193533539772034e-01
    z[4,0,2]  R4        1
    z[4,0,2]  R40       -1
    z[4,0,2]  R339      -1
    z[4,0,2]  R340      1
    z[4,0,2]  R349      4.7314766049385071e-01
    z[4,0,2]  R350      6.4146476984024048e-01
    z[4,0,2]  R351      3.4393441677093506e-01
    z[4,0,2]  R352      -5.5661749839782715e-01
    z[4,0,2]  R353      7.3411154747009277e-01
    z[4,0,2]  R354      -7.3292267322540283e-01
    z[4,0,2]  R355      -2.2035045921802521e-01
    z[4,0,2]  R356      0.354841947555542
    z[4,0,2]  R357      -4.4543719291687012e-01
    z[4,0,2]  R358      -4.6101558208465576e-01
    z[4,0,2]  R359      -3.0765122175216675e-01
    z[4,0,2]  R360      -4.0702033042907715e-01
    z[4,0,2]  R361      9.9146686494350433e-02
    z[4,0,2]  R362      -1.1688224039971828e-02
    z[4,0,2]  R363      1.8368528783321381e-01
    z[4,0,2]  R364      -2.7939698100090027e-01
    z[4,0,2]  R365      -2.1570718288421631e-01
    z[4,0,2]  R366      2.5934013724327087e-01
    z[4,0,2]  R367      1.0537172108888626e-01
    z[4,0,2]  R368      -1.0331146419048309e-01
    z[4,0,2]  R369      4.1182544827461243e-01
    z[4,0,2]  R370      3.4214559197425842e-01
    z[4,0,2]  R371      -5.8745678514242172e-02
    z[4,0,2]  R372      2.9820975661277771e-01
    z[4,0,2]  R373      2.3407407104969025e-01
    z[4,0,2]  R374      2.0372729003429413e-01
    z[4,0,2]  R375      -2.8888460993766785e-01
    z[4,0,2]  R376      1.2944971024990082e-01
    z[4,0,2]  R377      3.1971395015716553e-01
    z[4,0,2]  R378      -5.3114318847656250e-01
    z[4,0,2]  R379      -2.8720572590827942e-01
    z[4,0,2]  R380      -3.4075200557708740e-01
    z[4,0,2]  R381      0.0651799812912941
    z[4,0,2]  R382      -1.0540736466646194e-01
    z[4,0,2]  R383      5.5763799697160721e-02
    z[4,0,2]  R384      2.1315130591392517e-01
    z[4,0,2]  R385      9.7647868096828461e-03
    z[4,0,2]  R386      2.7516508102416992e-01
    z[4,0,2]  R387      1.2211017310619354e-01
    z[4,0,2]  R388      -4.1460892558097839e-01
    z[4,0,2]  R389      -3.3463403582572937e-01
    z[4,0,2]  R390      -1.6629112884402275e-02
    z[4,0,2]  R391      -1.5568526089191437e-01
    z[4,0,2]  R392      4.0350826457142830e-03
    z[4,0,2]  R393      1.0063806176185608e-01
    z[4,0,2]  R394      2.9198083281517029e-01
    z[4,0,2]  R395      1.2186415493488312e-01
    z[4,0,2]  R396      1.2220936268568039e-01
    z[4,0,2]  R397      2.6314669847488403e-01
    z[4,0,2]  R398      -3.0581615865230560e-03
    z[4,0,2]  R399      -5.9071831405162811e-02
    z[4,0,2]  R400      2.3816527426242828e-01
    z[4,0,2]  R401      1.3352888822555542e-01
    z[4,0,2]  R402      9.2853292822837830e-02
    z[4,0,2]  R403      1.5188363194465637e-01
    z[4,0,2]  R404      3.7422287464141846e-01
    z[4,0,2]  R405      4.6395204961299896e-02
    z[4,0,2]  R406      3.1327095627784729e-01
    z[4,0,2]  R407      -5.4369044303894043e-01
    z[4,0,3]  R5        1
    z[4,0,3]  R41       -1
    z[4,0,3]  R341      -1
    z[4,0,3]  R342      1
    z[4,0,3]  R349      -2.4220316112041473e-01
    z[4,0,3]  R350      6.1942975968122482e-02
    z[4,0,3]  R351      1.1200608313083649e-01
    z[4,0,3]  R352      -9.1599315404891968e-02
    z[4,0,3]  R353      3.8009887933731079e-01
    z[4,0,3]  R354      1.6812488436698914e-01
    z[4,0,3]  R355      -3.6225453019142151e-01
    z[4,0,3]  R356      4.8625072836875916e-01
    z[4,0,3]  R357      -2.2988341748714447e-01
    z[4,0,3]  R358      -5.0863057374954224e-01
    z[4,0,3]  R359      1.8882469832897186e-01
    z[4,0,3]  R360      -9.0798944234848022e-02
    z[4,0,3]  R361      -4.2324650287628174e-01
    z[4,0,3]  R362      2.4133273959159851e-01
    z[4,0,3]  R363      7.0253565907478333e-02
    z[4,0,3]  R364      -1.6083383560180664e-01
    z[4,0,3]  R365      -1.9417789578437805e-01
    z[4,0,3]  R366      -3.5769420862197876e-01
    z[4,0,3]  R367      -4.0315032005310059e-01
    z[4,0,3]  R368      7.3971413075923920e-02
    z[4,0,3]  R369      2.1571151912212372e-01
    z[4,0,3]  R370      1.1827246844768524e-01
    z[4,0,3]  R371      1.4734905958175659e-01
    z[4,0,3]  R372      4.6738174557685852e-01
    z[4,0,3]  R373      -8.1005841493606567e-02
    z[4,0,3]  R374      -1.9384460151195526e-01
    z[4,0,3]  R375      -3.4577727317810059e-02
    z[4,0,3]  R376      -1.3444166630506516e-02
    z[4,0,3]  R377      3.0745112895965576e-01
    z[4,0,3]  R378      -6.9761967658996582e-01
    z[4,0,3]  R379      -4.5262724161148071e-01
    z[4,0,3]  R380      -1.8227195739746094e-01
    z[4,0,3]  R381      4.3465545773506165e-01
    z[4,0,3]  R382      9.3317292630672455e-02
    z[4,0,3]  R383      1.8307955563068390e-01
    z[4,0,3]  R384      4.3990376591682434e-01
    z[4,0,3]  R385      1.5750470757484436e-01
    z[4,0,3]  R386      3.4503984451293945e-01
    z[4,0,3]  R387      2.1747404336929321e-01
    z[4,0,3]  R388      -2.3556582629680634e-01
    z[4,0,3]  R389      -3.6711838841438293e-01
    z[4,0,3]  R390      -1.5590147674083710e-01
    z[4,0,3]  R391      2.1487775444984436e-01
    z[4,0,3]  R392      6.1241549253463745e-01
    z[4,0,3]  R393      1.1795209348201752e-01
    z[4,0,3]  R394      3.7257385253906250e-01
    z[4,0,3]  R395      1.6701427102088928e-01
    z[4,0,3]  R396      1.6665865480899811e-01
    z[4,0,3]  R397      3.8207578659057617e-01
    z[4,0,3]  R398      -0.322479784488678
    z[4,0,3]  R399      -1.3925144076347351e-01
    z[4,0,3]  R400      2.5316730141639709e-01
    z[4,0,3]  R401      2.4352559447288513e-01
    z[4,0,3]  R402      3.0174168944358826e-01
    z[4,0,3]  R403      -2.3458187282085419e-01
    z[4,0,3]  R404      -2.9041069746017456e-01
    z[4,0,3]  R405      -4.8186635971069336e-01
    z[4,0,3]  R406      -5.5097401142120361e-01
    z[4,0,3]  R407      -7.3731496930122375e-02
    z[4,0,4]  R6        1
    z[4,0,4]  R42       -1
    z[4,0,4]  R343      -1
    z[4,0,4]  R344      1
    z[4,0,4]  R349      2.8842657804489136e-01
    z[4,0,4]  R350      -3.5000029206275940e-01
    z[4,0,4]  R351      1.9966131448745728e-01
    z[4,0,4]  R352      -4.4427019357681274e-01
    z[4,0,4]  R353      1.9556620717048645e-01
    z[4,0,4]  R354      -2.0001649856567383e-01
    z[4,0,4]  R355      5.0343668460845947e-01
    z[4,0,4]  R356      -1.6372986137866974e-01
    z[4,0,4]  R357      3.1951498240232468e-03
    z[4,0,4]  R358      -3.9187619090080261e-01
    z[4,0,4]  R359      3.1968098878860474e-01
    z[4,0,4]  R360      -5.4483091831207275e-01
    z[4,0,4]  R361      5.3580832481384277e-01
    z[4,0,4]  R362      -8.9582674205303192e-02
    z[4,0,4]  R363      -1.2088719755411148e-01
    z[4,0,4]  R364      1.6698222607374191e-02
    z[4,0,4]  R365      4.3900626897811890e-01
    z[4,0,4]  R366      0.0387524850666523
    z[4,0,4]  R367      -1.5400440990924835e-01
    z[4,0,4]  R368      -2.8708747029304504e-01
    z[4,0,4]  R369      2.6801860332489014e-01
    z[4,0,4]  R370      2.0113915205001831e-01
    z[4,0,4]  R371      3.5793926566839218e-02
    z[4,0,4]  R372      -2.7939385175704956e-01
    z[4,0,4]  R373      -6.3287980854511261e-02
    z[4,0,4]  R374      -3.6065548658370972e-01
    z[4,0,4]  R375      7.3096376657485962e-01
    z[4,0,4]  R376      6.7142558097839355e-01
    z[4,0,4]  R377      7.0937581360340118e-02
    z[4,0,4]  R378      1.3463832437992096e-01
    z[4,0,4]  R379      -5.1618558168411255e-01
    z[4,0,4]  R380      -4.5868670940399170e-01
    z[4,0,4]  R381      -5.8191988617181778e-02
    z[4,0,4]  R382      3.4410521388053894e-02
    z[4,0,4]  R383      1.1503663845360279e-03
    z[4,0,4]  R384      1.5963628888130188e-01
    z[4,0,4]  R385      -5.5157607793807983e-01
    z[4,0,4]  R386      -0.375713586807251
    z[4,0,4]  R387      -4.3983921408653259e-01
    z[4,0,4]  R388      -1.2373851612210274e-02
    z[4,0,4]  R389      -4.7766295075416565e-01
    z[4,0,4]  R390      4.1211850941181183e-02
    z[4,0,4]  R391      3.7129971385002136e-01
    z[4,0,4]  R392      -3.9886510372161865e-01
    z[4,0,4]  R393      -1.2034978717565536e-02
    z[4,0,4]  R394      -1.5882951021194458e-01
    z[4,0,4]  R395      1.3550990819931030e-01
    z[4,0,4]  R396      -4.2395928502082825e-01
    z[4,0,4]  R397      3.4098449349403381e-01
    z[4,0,4]  R398      -1.9753496162593365e-03
    z[4,0,4]  R399      -4.6900838613510132e-01
    z[4,0,4]  R400      -1.5267118811607361e-01
    z[4,0,4]  R401      7.8578270971775055e-02
    z[4,0,4]  R402      -6.4628034830093384e-02
    z[4,0,4]  R403      7.3250883817672729e-01
    z[4,0,4]  R404      0.703118085861206
    z[4,0,4]  R405      0.709367036819458
    z[4,0,4]  R406      0.629349946975708
    z[4,0,4]  R407      3.3739086985588074e-01
    z[4,0,5]  R7        1
    z[4,0,5]  R43       -1
    z[4,0,5]  R345      -1
    z[4,0,5]  R346      1
    z[4,0,5]  R349      2.6128500699996948e-02
    z[4,0,5]  R350      7.1706078946590424e-02
    z[4,0,5]  R351      4.9888265132904053e-01
    z[4,0,5]  R352      4.6686807274818420e-01
    z[4,0,5]  R353      -6.0093704611063004e-02
    z[4,0,5]  R354      -2.4372828006744385e-01
    z[4,0,5]  R355      -1.6527295112609863e-01
    z[4,0,5]  R356      -0.0574694387614727
    z[4,0,5]  R357      -1.0356678813695908e-01
    z[4,0,5]  R358      8.7697193026542664e-02
    z[4,0,5]  R359      -0.725053608417511
    z[4,0,5]  R360      -2.0311726629734039e-01
    z[4,0,5]  R361      -2.9575619101524353e-01
    z[4,0,5]  R362      -0.324920654296875
    z[4,0,5]  R363      -3.4698531031608582e-01
    z[4,0,5]  R364      -2.9969671368598938e-01
    z[4,0,5]  R365      4.1022595763206482e-01
    z[4,0,5]  R366      5.3775095939636230e-01
    z[4,0,5]  R367      5.9714996814727783e-01
    z[4,0,5]  R368      -4.7690412029623985e-03
    z[4,0,5]  R369      -6.1701886355876923e-02
    z[4,0,5]  R370      5.0466352701187134e-01
    z[4,0,5]  R371      4.8978742957115173e-01
    z[4,0,5]  R372      7.1435786783695221e-02
    z[4,0,5]  R373      2.7940362691879272e-01
    z[4,0,5]  R374      2.7574056759476662e-02
    z[4,0,5]  R375      -2.2223636507987976e-02
    z[4,0,5]  R376      -3.3171564340591431e-02
    z[4,0,5]  R377      1.6031476855278015e-01
    z[4,0,5]  R378      -2.5239479541778564e-01
    z[4,0,5]  R379      -2.9416564106941223e-01
    z[4,0,5]  R380      -4.4694498181343079e-01
    z[4,0,5]  R381      2.7287902310490608e-02
    z[4,0,5]  R382      -2.4877880513668060e-01
    z[4,0,5]  R383      3.3808764070272446e-02
    z[4,0,5]  R384      -2.5906574726104736e-01
    z[4,0,5]  R385      5.7204663753509521e-02
    z[4,0,5]  R386      1.7534929513931274e-01
    z[4,0,5]  R387      -1.3360358774662018e-01
    z[4,0,5]  R388      -2.9011952877044678e-01
    z[4,0,5]  R389      -1.0443875938653946e-01
    z[4,0,5]  R390      -4.9709695577621460e-01
    z[4,0,5]  R391      -5.7766562700271606e-01
    z[4,0,5]  R392      -2.3226347565650940e-01
    z[4,0,5]  R393      -1.4635747671127319e-01
    z[4,0,5]  R394      9.5519470050930977e-03
    z[4,0,5]  R395      3.0473536252975464e-01
    z[4,0,5]  R396      -4.6242665499448776e-02
    z[4,0,5]  R397      -4.3257344514131546e-02
    z[4,0,5]  R398      -0.0999906063079834
    z[4,0,5]  R399      -6.9952070713043213e-01
    z[4,0,5]  R400      -3.9647076278924942e-02
    z[4,0,5]  R401      -1.4046829938888550e-01
    z[4,0,5]  R402      2.4029399454593658e-01
    z[4,0,5]  R403      -3.5800644755363464e-01
    z[4,0,5]  R404      -0.337938517332077
    z[4,0,5]  R405      -1.1036282777786255e-01
    z[4,0,5]  R406      -8.4956243634223938e-02
    z[4,0,5]  R407      3.1225770711898804e-01
    z[4,0,6]  R8        1
    z[4,0,6]  R44       -1
    z[4,0,6]  R347      -1
    z[4,0,6]  R348      1
    z[4,0,6]  R349      -5.0591373443603516e-01
    z[4,0,6]  R350      -1.8037442862987518e-01
    z[4,0,6]  R351      -4.4070344418287277e-02
    z[4,0,6]  R352      -1.0913307219743729e-01
    z[4,0,6]  R353      -1.1021775007247925e-01
    z[4,0,6]  R354      -1.1256178468465805e-01
    z[4,0,6]  R355      -3.5762250423431396e-01
    z[4,0,6]  R356      -4.7920525074005127e-01
    z[4,0,6]  R357      -6.8132072687149048e-01
    z[4,0,6]  R358      6.5198019146919250e-02
    z[4,0,6]  R359      3.0751428008079529e-01
    z[4,0,6]  R360      -1.9137734174728394e-01
    z[4,0,6]  R361      6.0680097341537476e-01
    z[4,0,6]  R362      8.0708169937133789e-01
    z[4,0,6]  R363      4.3234363198280334e-01
    z[4,0,6]  R364      5.3397798538208008e-01
    z[4,0,6]  R365      7.5266867876052856e-02
    z[4,0,6]  R366      -6.0586854815483093e-02
    z[4,0,6]  R367      4.9353587627410889e-01
    z[4,0,6]  R368      2.9299014806747437e-01
    z[4,0,6]  R369      -9.4843529164791107e-02
    z[4,0,6]  R370      -4.4247034937143326e-02
    z[4,0,6]  R371      1.4140436053276062e-01
    z[4,0,6]  R372      -3.3865347504615784e-01
    z[4,0,6]  R373      -7.3839861154556274e-01
    z[4,0,6]  R374      -1.4461073279380798e-01
    z[4,0,6]  R375      3.3890013583004475e-03
    z[4,0,6]  R376      -0.572462260723114
    z[4,0,6]  R377      -5.0207413733005524e-02
    z[4,0,6]  R378      1.2897881865501404e-01
    z[4,0,6]  R379      -1.3239070773124695e-01
    z[4,0,6]  R380      4.2681512236595154e-01
    z[4,0,6]  R381      3.8436099886894226e-01
    z[4,0,6]  R382      3.3493393659591675e-01
    z[4,0,6]  R383      -2.5354269146919250e-01
    z[4,0,6]  R384      -1.8567276000976562e-01
    z[4,0,6]  R385      2.1535407006740570e-01
    z[4,0,6]  R386      1.4603652060031891e-02
    z[4,0,6]  R387      -2.1024686098098755e-01
    z[4,0,6]  R388      3.7960490584373474e-01
    z[4,0,6]  R389      5.5432099103927612e-01
    z[4,0,6]  R390      -3.9354091882705688e-01
    z[4,0,6]  R391      1.8088878691196442e-01
    z[4,0,6]  R392      4.9985662102699280e-01
    z[4,0,6]  R393      -9.1941304504871368e-02
    z[4,0,6]  R394      -4.7092538326978683e-02
    z[4,0,6]  R395      -5.3763326257467270e-02
    z[4,0,6]  R396      5.1233269274234772e-02
    z[4,0,6]  R397      7.9844966530799866e-02
    z[4,0,6]  R398      -7.3772174119949341e-01
    z[4,0,6]  R399      -3.0384582281112671e-01
    z[4,0,6]  R400      2.9911282658576965e-01
    z[4,0,6]  R401      1.6414389014244080e-01
    z[4,0,6]  R402      3.3838972449302673e-02
    z[4,0,6]  R403      5.6156627833843231e-02
    z[4,0,6]  R404      1.5955096110701561e-02
    z[4,0,6]  R405      2.2048467770218849e-02
    z[4,0,6]  R406      3.1257644295692444e-01
    z[4,0,6]  R407      -4.8394206911325455e-02
    z[1,2,0]  R11       -1
    z[1,2,0]  R20       1
    z[1,2,0]  R462      -1
    z[1,2,0]  R463      1
    z[1,2,0]  R476      2.7962762117385864e-01
    z[1,2,0]  R477      2.0304465293884277e-01
    z[1,2,0]  R478      4.8196381330490112e-01
    z[1,2,0]  R479      4.9614846706390381e-01
    z[1,2,0]  R480      1.2865640223026276e-01
    z[1,2,0]  R481      -6.1407768726348877e-01
    z[1,2,0]  R482      -3.2301995903253555e-02
    z[1,2,0]  R483      -6.5264117717742920e-01
    z[1,2,0]  R484      5.8207523822784424e-01
    z[1,2,0]  R485      -3.2870405912399292e-01
    z[1,2,0]  R486      -3.1641387939453125e-01
    z[1,2,0]  R487      -4.2277911305427551e-01
    z[1,2,0]  R488      -1.0244952887296677e-01
    z[1,2,0]  R489      -1.2051765620708466e-01
    z[1,2,0]  R490      -4.8893335461616516e-01
    z[1,2,0]  R491      -1.8897777795791626e-01
    z[1,2,0]  R492      1.3949221372604370e-01
    z[1,2,0]  R493      -2.2030605375766754e-01
    z[1,2,0]  R494      -2.1836702525615692e-01
    z[1,2,0]  R495      2.3509931564331055e-01
    z[1,2,0]  R496      -7.6377198100090027e-02
    z[1,2,0]  R497      3.1136092543601990e-01
    z[1,2,0]  R498      3.0841851234436035e-01
    z[1,2,0]  R499      2.2287490963935852e-01
    z[1,2,0]  R500      -5.3050625324249268e-01
    z[1,2,0]  R501      -1.4284588396549225e-01
    z[1,2,0]  R502      2.0959232747554779e-01
    z[1,2,0]  R503      2.6491835713386536e-01
    z[1,2,0]  R504      4.4635945558547974e-01
    z[1,2,0]  R505      8.6355626583099365e-02
    z[1,2,0]  R506      2.9921406507492065e-01
    z[1,2,0]  R507      -3.4507188200950623e-01
    z[1,2,0]  R508      -6.5469577908515930e-02
    z[1,2,0]  R509      8.4681533277034760e-02
    z[1,2,0]  R510      -4.7394716739654541e-01
    z[1,2,0]  R511      -0.486203134059906
    z[1,2,0]  R512      -5.0084066390991211e-01
    z[1,2,0]  R513      -6.6228991746902466e-01
    z[1,2,0]  R514      -6.7427629232406616e-01
    z[1,2,0]  R515      -7.0876157283782959e-01
    z[1,2,0]  R516      -4.9124273657798767e-01
    z[1,2,0]  R517      -7.7634233236312866e-01
    z[1,2,0]  R518      -4.5373073220252991e-01
    z[1,2,0]  R519      -6.8108010292053223e-01
    z[1,2,0]  R520      -7.1953850984573364e-01
    z[1,2,0]  R521      -4.6407660841941833e-01
    z[1,2,0]  R522      -3.3312138915061951e-01
    z[1,2,0]  R523      -7.2410744428634644e-01
    z[1,2,0]  R524      -6.1397582292556763e-01
    z[1,2,0]  R525      -1.4422667026519775e-01
    z[1,2,0]  R526      6.1473723500967026e-02
    z[1,2,0]  R527      0.153394877910614
    z[1,2,0]  R528      -2.0218744874000549e-01
    z[1,2,0]  R529      -1.8500488996505737e-01
    z[1,2,0]  R530      1.5352945029735565e-01
    z[1,2,0]  R531      9.4493657350540161e-02
    z[1,2,0]  R532      -0.059889055788517
    z[1,2,0]  R533      2.3794810473918915e-01
    z[1,2,0]  R534      -2.4597447365522385e-02
    z[1,2,0]  R535      4.5672440528869629e-01
    z[1,2,0]  R536      4.7142812609672546e-01
    z[1,2,0]  R537      2.4861901998519897e-02
    z[1,2,0]  R538      -1.4215698838233948e-01
    z[1,2,0]  R539      5.0571531057357788e-01
    z[1,2,0]  R540      1.2481260299682617e-01
    z[1,2,0]  R541      -4.0614360570907593e-01
    z[1,2,0]  R542      -1.9890600442886353e-01
    z[1,2,0]  R543      1.8972903490066528e-02
    z[1,2,0]  R544      -6.2058974057435989e-02
    z[1,2,0]  R545      -1.0376165807247162e-01
    z[1,2,0]  R546      -1.7810884118080139e-01
    z[1,2,0]  R547      9.4430714845657349e-02
    z[1,2,0]  R548      1.2676912546157837e-01
    z[1,2,0]  R549      -1.5843637287616730e-01
    z[1,2,0]  R550      4.0129086375236511e-01
    z[1,2,0]  R551      2.0959985256195068e-01
    z[1,2,0]  R552      4.2695617675781250e-01
    z[1,2,0]  R553      -8.0943085253238678e-02
    z[1,2,0]  R554      -3.6984920501708984e-01
    z[1,2,0]  R555      -6.6380125284194946e-01
    z[1,2,0]  R556      -4.9481880851089954e-03
    z[1,2,0]  R557      -6.7595876753330231e-03
    z[1,2,0]  R558      2.1995209157466888e-01
    z[1,2,0]  R559      -5.0826031714677811e-02
    z[1,2,0]  R560      4.4874809682369232e-02
    z[1,2,0]  R561      -3.3454048633575439e-01
    z[1,2,0]  R562      2.5708615779876709e-01
    z[1,2,0]  R563      6.0063779354095459e-01
    z[1,2,0]  R564      -6.4115297794342041e-01
    z[1,2,0]  R565      -3.8052040338516235e-01
    z[1,2,0]  R566      2.9909870028495789e-01
    z[1,2,0]  R567      -1.2768530286848545e-02
    z[1,2,0]  R568      -2.4318021535873413e-01
    z[1,2,0]  R569      6.0623455792665482e-02
    z[1,2,0]  R570      -4.2846912145614624e-01
    z[1,2,0]  R571      -2.1448197960853577e-01
    z[1,2,0]  R572      -3.8751190900802612e-01
    z[1,2,0]  R573      5.0506293773651123e-01
    z[1,2,0]  R574      2.9371036216616631e-02
    z[1,2,0]  R575      -1.8463903665542603e-01
    z[1,2,0]  R576      -1.7569494247436523e-01
    z[1,2,0]  R577      -3.0998736619949341e-01
    z[1,2,0]  R578      -0.0892467051744461
    z[1,2,0]  R579      3.0539789795875549e-01
    z[1,2,0]  R580      -3.7317898869514465e-01
    z[1,2,0]  R581      4.7704753279685974e-01
    z[1,2,0]  R582      3.6393198370933533e-01
    z[1,2,0]  R583      6.0187149047851562e-01
    z[1,2,0]  R584      0.573669970035553
    z[1,2,0]  R585      6.0565555095672607e-01
    z[1,2,1]  R12       -1
    z[1,2,1]  R21       1
    z[1,2,1]  R464      -1
    z[1,2,1]  R465      1
    z[1,2,1]  R476      -2.1921348571777344e-01
    z[1,2,1]  R477      -7.4452593922615051e-02
    z[1,2,1]  R478      -5.0826704502105713e-01
    z[1,2,1]  R479      -3.2922571897506714e-01
    z[1,2,1]  R480      8.1142103672027588e-01
    z[1,2,1]  R481      6.1842817068099976e-01
    z[1,2,1]  R482      6.8973690271377563e-01
    z[1,2,1]  R483      5.9134668111801147e-01
    z[1,2,1]  R484      6.1284792423248291e-01
    z[1,2,1]  R485      0.573715090751648
    z[1,2,1]  R486      9.0683412551879883e-01
    z[1,2,1]  R487      8.3137172460556030e-01
    z[1,2,1]  R488      8.0535823106765747e-01
    z[1,2,1]  R489      -3.2495595514774323e-02
    z[1,2,1]  R490      7.1907246112823486e-01
    z[1,2,1]  R491      -4.5671343803405762e-02
    z[1,2,1]  R492      8.2761889696121216e-01
    z[1,2,1]  R493      6.8467676639556885e-01
    z[1,2,1]  R494      -3.5720226168632507e-01
    z[1,2,1]  R495      2.8877329826354980e-01
    z[1,2,1]  R496      9.3616098165512085e-01
    z[1,2,1]  R497      8.7562519311904907e-01
    z[1,2,1]  R498      9.1728532314300537e-01
    z[1,2,1]  R499      8.2997298240661621e-01
    z[1,2,1]  R500      7.4703454971313477e-01
    z[1,2,1]  R501      8.3241719007492065e-01
    z[1,2,1]  R502      7.4476099014282227e-01
    z[1,2,1]  R503      7.3139709234237671e-01
    z[1,2,1]  R504      7.7011620998382568e-01
    z[1,2,1]  R505      2.8373071551322937e-01
    z[1,2,1]  R506      9.1313737630844116e-01
    z[1,2,1]  R507      8.1033390760421753e-01
    z[1,2,1]  R508      8.0890297889709473e-01
    z[1,2,1]  R509      0.686237633228302
    z[1,2,1]  R510      3.3341646194458008e-01
    z[1,2,1]  R511      2.3928360641002655e-01
    z[1,2,1]  R512      1.6235956549644470e-01
    z[1,2,1]  R513      -3.7058692425489426e-02
    z[1,2,1]  R514      -1.9127799198031425e-02
    z[1,2,1]  R515      1.4989666640758514e-01
    z[1,2,1]  R516      -4.4544604420661926e-01
    z[1,2,1]  R517      -4.0777593851089478e-01
    z[1,2,1]  R518      -4.2607891559600830e-01
    z[1,2,1]  R519      -2.7949529886245728e-01
    z[1,2,1]  R520      -0.350705623626709
    z[1,2,1]  R521      -0.363901287317276
    z[1,2,1]  R522      -4.9221006035804749e-01
    z[1,2,1]  R523      -3.8024628162384033e-01
    z[1,2,1]  R524      0.237028107047081
    z[1,2,1]  R525      -8.7349957227706909e-01
    z[1,2,1]  R526      -2.5577083230018616e-01
    z[1,2,1]  R527      2.4164129793643951e-01
    z[1,2,1]  R528      0.829850971698761
    z[1,2,1]  R529      6.4701384305953979e-01
    z[1,2,1]  R530      9.1239744424819946e-01
    z[1,2,1]  R531      8.7869280576705933e-01
    z[1,2,1]  R532      8.8222002983093262e-01
    z[1,2,1]  R533      3.3945631980895996e-01
    z[1,2,1]  R534      7.9038488864898682e-01
    z[1,2,1]  R535      4.7249439358711243e-01
    z[1,2,1]  R536      -2.5328485295176506e-02
    z[1,2,1]  R537      -4.2231306433677673e-01
    z[1,2,1]  R538      1.6041561961174011e-01
    z[1,2,1]  R539      9.7372457385063171e-02
    z[1,2,1]  R540      3.9665067195892334e-01
    z[1,2,1]  R541      5.0427418947219849e-01
    z[1,2,1]  R542      -2.2575311362743378e-01
    z[1,2,1]  R543      2.1479836106300354e-01
    z[1,2,1]  R544      2.1152751147747040e-01
    z[1,2,1]  R545      2.3155732452869415e-01
    z[1,2,1]  R546      -2.0896512269973755e-01
    z[1,2,1]  R547      -8.6768402252346277e-04
    z[1,2,1]  R548      4.8274621367454529e-01
    z[1,2,1]  R549      3.2020667195320129e-01
    z[1,2,1]  R550      1.8010555207729340e-01
    z[1,2,1]  R551      -4.0624219179153442e-01
    z[1,2,1]  R552      -4.6342805027961731e-02
    z[1,2,1]  R553      2.6514491438865662e-01
    z[1,2,1]  R554      2.3521491885185242e-01
    z[1,2,1]  R555      2.4544388055801392e-01
    z[1,2,1]  R556      -8.3455711603164673e-02
    z[1,2,1]  R557      1.5370737016201019e-01
    z[1,2,1]  R558      2.3272086679935455e-01
    z[1,2,1]  R559      3.5309621691703796e-01
    z[1,2,1]  R560      1.4941997826099396e-01
    z[1,2,1]  R561      -3.7667483091354370e-02
    z[1,2,1]  R562      4.8218145966529846e-01
    z[1,2,1]  R563      -1.7782464623451233e-01
    z[1,2,1]  R564      3.9055651426315308e-01
    z[1,2,1]  R565      4.6254959702491760e-01
    z[1,2,1]  R566      2.5293555110692978e-02
    z[1,2,1]  R567      1.9626750051975250e-01
    z[1,2,1]  R568      9.6097335219383240e-02
    z[1,2,1]  R569      1.5056197345256805e-01
    z[1,2,1]  R570      1.8992094695568085e-01
    z[1,2,1]  R571      3.4925243258476257e-01
    z[1,2,1]  R572      -9.8732315003871918e-02
    z[1,2,1]  R573      -1.1955556273460388e-01
    z[1,2,1]  R574      -4.8471504449844360e-01
    z[1,2,1]  R575      3.3883380889892578e-01
    z[1,2,1]  R576      -4.6554881334304810e-01
    z[1,2,1]  R577      8.7587319314479828e-02
    z[1,2,1]  R578      3.0281466245651245e-01
    z[1,2,1]  R579      0.00760143157094717
    z[1,2,1]  R580      2.8109899163246155e-01
    z[1,2,1]  R581      4.2320245504379272e-01
    z[1,2,1]  R582      -2.1706353127956390e-01
    z[1,2,1]  R583      -3.9704304933547974e-01
    z[1,2,1]  R584      -1.0005540400743484e-01
    z[1,2,1]  R585      -0.344194233417511
    z[1,2,2]  R13       -1
    z[1,2,2]  R22       1
    z[1,2,2]  R466      -1
    z[1,2,2]  R467      1
    z[1,2,2]  R476      5.3371560573577881e-01
    z[1,2,2]  R477      6.8362191319465637e-02
    z[1,2,2]  R478      1.8323728442192078e-01
    z[1,2,2]  R479      -2.4813309311866760e-01
    z[1,2,2]  R480      2.8203356266021729e-01
    z[1,2,2]  R481      3.6106950044631958e-01
    z[1,2,2]  R482      -4.1474151611328125e-01
    z[1,2,2]  R483      3.9721819758415222e-01
    z[1,2,2]  R484      -1.3042224943637848e-01
    z[1,2,2]  R485      -5.7017207145690918e-01
    z[1,2,2]  R486      1.1580395698547363e-01
    z[1,2,2]  R487      1.8631696701049805e-01
    z[1,2,2]  R488      -2.3490869998931885e-01
    z[1,2,2]  R489      6.1722569167613983e-02
    z[1,2,2]  R490      -4.1013407707214355e-01
    z[1,2,2]  R491      -4.0237170457839966e-01
    z[1,2,2]  R492      1.8765635788440704e-01
    z[1,2,2]  R493      -0.515556275844574
    z[1,2,2]  R494      -1.5989071130752563e-01
    z[1,2,2]  R495      -1.3489606976509094e-01
    z[1,2,2]  R496      -3.3976398408412933e-02
    z[1,2,2]  R497      -2.9960241913795471e-01
    z[1,2,2]  R498      -1.3145267963409424e-01
    z[1,2,2]  R499      -3.2863074541091919e-01
    z[1,2,2]  R500      -2.4547062814235687e-01
    z[1,2,2]  R501      4.0565276145935059e-01
    z[1,2,2]  R502      1.3377526402473450e-01
    z[1,2,2]  R503      7.7422477304935455e-02
    z[1,2,2]  R504      1.4425605535507202e-01
    z[1,2,2]  R505      1.4587850868701935e-01
    z[1,2,2]  R506      2.3768074810504913e-01
    z[1,2,2]  R507      -3.1970882415771484e-01
    z[1,2,2]  R508      2.7199709415435791e-01
    z[1,2,2]  R509      -4.0316683053970337e-01
    z[1,2,2]  R510      -4.2920511960983276e-01
    z[1,2,2]  R511      -4.8564866185188293e-01
    z[1,2,2]  R512      -5.3797960281372070e-01
    z[1,2,2]  R513      -5.8077478408813477e-01
    z[1,2,2]  R514      -6.0098898410797119e-01
    z[1,2,2]  R515      -1.6859672963619232e-01
    z[1,2,2]  R516      -5.0723069906234741e-01
    z[1,2,2]  R517      -3.0221751332283020e-01
    z[1,2,2]  R518      -5.4670047760009766e-01
    z[1,2,2]  R519      -5.1954925060272217e-01
    z[1,2,2]  R520      -3.8589019328355789e-02
    z[1,2,2]  R521      -6.0903567075729370e-01
    z[1,2,2]  R522      -4.8527535051107407e-02
    z[1,2,2]  R523      -2.2927054762840271e-01
    z[1,2,2]  R524      -6.1901479959487915e-01
    z[1,2,2]  R525      3.8353729993104935e-02
    z[1,2,2]  R526      4.4338819384574890e-01
    z[1,2,2]  R527      -3.2167810946702957e-02
    z[1,2,2]  R528      3.1972485780715942e-01
    z[1,2,2]  R529      5.0286766141653061e-02
    z[1,2,2]  R530      1.2339603155851364e-01
    z[1,2,2]  R531      2.6287573575973511e-01
    z[1,2,2]  R532      2.2269165515899658e-01
    z[1,2,2]  R533      6.6414773464202881e-01
    z[1,2,2]  R534      7.4134194292128086e-03
    z[1,2,2]  R535      -2.6723316311836243e-01
    z[1,2,2]  R536      -0.0663272812962532
    z[1,2,2]  R537      -3.2018488645553589e-01
    z[1,2,2]  R538      -3.5017940402030945e-01
    z[1,2,2]  R539      1.4386005699634552e-01
    z[1,2,2]  R540      -8.9014537632465363e-02
    z[1,2,2]  R541      1.2869903445243835e-01
    z[1,2,2]  R542      3.2295051217079163e-01
    z[1,2,2]  R543      3.2745265960693359e-01
    z[1,2,2]  R544      -2.7053061127662659e-01
    z[1,2,2]  R545      -3.1839540600776672e-01
    z[1,2,2]  R546      4.8677217960357666e-01
    z[1,2,2]  R547      8.2149881124496460e-01
    z[1,2,2]  R548      5.7530528306961060e-01
    z[1,2,2]  R549      1.1776317656040192e-01
    z[1,2,2]  R550      -4.4055002927780151e-01
    z[1,2,2]  R551      3.9006423950195312e-01
    z[1,2,2]  R552      -2.8825944662094116e-01
    z[1,2,2]  R553      -1.3484659790992737e-01
    z[1,2,2]  R554      2.1095946431159973e-01
    z[1,2,2]  R555      -1.1477702856063843e-01
    z[1,2,2]  R556      5.4724162817001343e-01
    z[1,2,2]  R557      -2.2157758474349976e-01
    z[1,2,2]  R558      3.6912760138511658e-01
    z[1,2,2]  R559      -1.3935816287994385e-01
    z[1,2,2]  R560      -1.5904602408409119e-01
    z[1,2,2]  R561      -1.1023134738206863e-01
    z[1,2,2]  R562      -3.6716946959495544e-01
    z[1,2,2]  R563      6.4137715101242065e-01
    z[1,2,2]  R564      4.7803804278373718e-02
    z[1,2,2]  R565      -1.0268244892358780e-01
    z[1,2,2]  R566      -4.5061972737312317e-01
    z[1,2,2]  R567      3.8992297649383545e-01
    z[1,2,2]  R568      1.1180755496025085e-01
    z[1,2,2]  R569      -4.3792682886123657e-01
    z[1,2,2]  R570      -2.3457825183868408e-01
    z[1,2,2]  R571      5.8858606964349747e-02
    z[1,2,2]  R572      -3.3551222085952759e-01
    z[1,2,2]  R573      0.629315972328186
    z[1,2,2]  R574      -3.7618912756443024e-02
    z[1,2,2]  R575      -1.8613802269101143e-02
    z[1,2,2]  R576      -1.5646006166934967e-01
    z[1,2,2]  R577      -3.8047635555267334e-01
    z[1,2,2]  R578      -2.5038030743598938e-01
    z[1,2,2]  R579      -2.7576902508735657e-01
    z[1,2,2]  R580      -1.3379658758640289e-01
    z[1,2,2]  R581      4.4476044178009033e-01
    z[1,2,2]  R582      -3.8278463482856750e-01
    z[1,2,2]  R583      -1.5245710313320160e-01
    z[1,2,2]  R584      -3.1500127911567688e-01
    z[1,2,2]  R585      -4.9095860123634338e-01
    z[1,2,3]  R14       -1
    z[1,2,3]  R23       1
    z[1,2,3]  R468      -1
    z[1,2,3]  R469      1
    z[1,2,3]  R476      6.4021801948547363e-01
    z[1,2,3]  R477      8.7169617414474487e-01
    z[1,2,3]  R478      3.1608742475509644e-01
    z[1,2,3]  R479      5.3747820854187012e-01
    z[1,2,3]  R480      6.8027116358280182e-02
    z[1,2,3]  R481      0.0730455219745636
    z[1,2,3]  R482      -2.5397205352783203e-01
    z[1,2,3]  R483      -1.9554081559181213e-01
    z[1,2,3]  R484      -4.5375058054924011e-01
    z[1,2,3]  R485      1.3821160793304443e-01
    z[1,2,3]  R486      0.0708138570189476
    z[1,2,3]  R487      -2.3503344506025314e-02
    z[1,2,3]  R488      -3.5512641072273254e-01
    z[1,2,3]  R489      -8.0423909425735474e-01
    z[1,2,3]  R490      -1.5500102937221527e-01
    z[1,2,3]  R491      -7.8048378229141235e-01
    z[1,2,3]  R492      -3.1121698021888733e-01
    z[1,2,3]  R493      1.7341528832912445e-01
    z[1,2,3]  R494      -8.1789320707321167e-01
    z[1,2,3]  R495      -7.1255475282669067e-01
    z[1,2,3]  R496      -2.0603038370609283e-01
    z[1,2,3]  R497      4.0164690464735031e-02
    z[1,2,3]  R498      -0.0616854727268219
    z[1,2,3]  R499      1.6903959214687347e-02
    z[1,2,3]  R500      -2.6691758632659912e-01
    z[1,2,3]  R501      -3.0812656879425049e-01
    z[1,2,3]  R502      -0.0676007941365242
    z[1,2,3]  R503      1.2762063741683960e-01
    z[1,2,3]  R504      -3.7457591295242310e-01
    z[1,2,3]  R505      -4.1808575391769409e-01
    z[1,2,3]  R506      -8.0341942608356476e-02
    z[1,2,3]  R507      9.2959113419055939e-02
    z[1,2,3]  R508      -1.3726647198200226e-01
    z[1,2,3]  R509      -1.3386221230030060e-01
    z[1,2,3]  R510      -2.7941063046455383e-01
    z[1,2,3]  R511      -5.8254975825548172e-02
    z[1,2,3]  R512      -4.0904280543327332e-01
    z[1,2,3]  R513      -1.1424877494573593e-01
    z[1,2,3]  R514      -1.3846483826637268e-01
    z[1,2,3]  R515      -4.9811783432960510e-01
    z[1,2,3]  R516      5.0857901573181152e-01
    z[1,2,3]  R517      2.4969819188117981e-01
    z[1,2,3]  R518      4.9621476791799068e-03
    z[1,2,3]  R519      -1.0981449484825134e-01
    z[1,2,3]  R520      5.2821516990661621e-01
    z[1,2,3]  R521      -3.8038119673728943e-02
    z[1,2,3]  R522      6.7629760503768921e-01
    z[1,2,3]  R523      -1.7949819564819336e-01
    z[1,2,3]  R524      3.6374571919441223e-01
    z[1,2,3]  R525      2.1840167045593262e-01
    z[1,2,3]  R526      -0.52577143907547
    z[1,2,3]  R527      -4.1349199414253235e-01
    z[1,2,3]  R528      -1.5367542207241058e-01
    z[1,2,3]  R529      -4.5624691247940063e-01
    z[1,2,3]  R530      -2.2992837429046631e-01
    z[1,2,3]  R531      -5.1483251154422760e-02
    z[1,2,3]  R532      9.5154352486133575e-02
    z[1,2,3]  R533      -3.0231153964996338e-01
    z[1,2,3]  R534      -3.1349179148674011e-01
    z[1,2,3]  R535      -4.9525824189186096e-01
    z[1,2,3]  R536      -7.8650033473968506e-01
    z[1,2,3]  R537      -4.3379139900207520e-01
    z[1,2,3]  R538      -6.5854293107986450e-01
    z[1,2,3]  R539      -5.3881102800369263e-01
    z[1,2,3]  R540      -7.9445666074752808e-01
    z[1,2,3]  R541      -4.4195863604545593e-01
    z[1,2,3]  R542      -7.2630548477172852e-01
    z[1,2,3]  R543      -8.7272793054580688e-01
    z[1,2,3]  R544      2.8594639897346497e-01
    z[1,2,3]  R545      0.0881413072347641
    z[1,2,3]  R546      -8.0582714080810547e-01
    z[1,2,3]  R547      -2.6946470141410828e-01
    z[1,2,3]  R548      -4.8328486084938049e-01
    z[1,2,3]  R549      6.5524083375930786e-01
    z[1,2,3]  R550      6.8470877408981323e-01
    z[1,2,3]  R551      -4.3322277069091797e-01
    z[1,2,3]  R552      7.4889016151428223e-01
    z[1,2,3]  R553      -6.5494573116302490e-01
    z[1,2,3]  R554      7.3258213698863983e-02
    z[1,2,3]  R555      -2.6382020115852356e-01
    z[1,2,3]  R556      -4.8871728777885437e-01
    z[1,2,3]  R557      8.1759041547775269e-01
    z[1,2,3]  R558      -0.515705943107605
    z[1,2,3]  R559      0.695762038230896
    z[1,2,3]  R560      6.9523996114730835e-01
    z[1,2,3]  R561      8.0560527741909027e-02
    z[1,2,3]  R562      -2.6228037476539612e-01
    z[1,2,3]  R563      -1.9468809664249420e-01
    z[1,2,3]  R564      2.4396492540836334e-01
    z[1,2,3]  R565      0.0779092013835907
    z[1,2,3]  R566      -6.5498644113540649e-01
    z[1,2,3]  R567      -4.8331132531166077e-01
    z[1,2,3]  R568      6.9152086973190308e-01
    z[1,2,3]  R569      4.8625549674034119e-01
    z[1,2,3]  R570      5.0809867680072784e-02
    z[1,2,3]  R571      7.3908466100692749e-01
    z[1,2,3]  R572      -4.5410543680191040e-02
    z[1,2,3]  R573      -2.5981745123863220e-01
    z[1,2,3]  R574      -3.5016742348670959e-01
    z[1,2,3]  R575      -5.8826500177383423e-01
    z[1,2,3]  R576      -5.9510171413421631e-01
    z[1,2,3]  R577      4.4107037782669067e-01
    z[1,2,3]  R578      8.3597046136856079e-01
    z[1,2,3]  R579      8.7238538265228271e-01
    z[1,2,3]  R580      2.2495311498641968e-01
    z[1,2,3]  R581      2.1142323315143585e-01
    z[1,2,3]  R582      1.0871886461973190e-01
    z[1,2,3]  R583      -2.1498848497867584e-01
    z[1,2,3]  R584      2.7603426575660706e-01
    z[1,2,3]  R585      -3.3645071089267731e-02
    z[1,2,4]  R15       -1
    z[1,2,4]  R24       1
    z[1,2,4]  R470      -1
    z[1,2,4]  R471      1
    z[1,2,4]  R476      -2.9989248514175415e-01
    z[1,2,4]  R477      4.0327611565589905e-01
    z[1,2,4]  R478      1.3635893166065216e-01
    z[1,2,4]  R479      -1.1704660207033157e-01
    z[1,2,4]  R480      -1.5881028771400452e-01
    z[1,2,4]  R481      -3.1409943103790283e-01
    z[1,2,4]  R482      -1.0652378201484680e-01
    z[1,2,4]  R483      -8.4657326340675354e-02
    z[1,2,4]  R484      -2.3083089292049408e-01
    z[1,2,4]  R485      -2.1730849146842957e-01
    z[1,2,4]  R486      -1.2386199086904526e-01
    z[1,2,4]  R487      1.3840185105800629e-01
    z[1,2,4]  R488      1.9290681183338165e-01
    z[1,2,4]  R489      -4.6147534251213074e-01
    z[1,2,4]  R490      -1.8422381579875946e-01
    z[1,2,4]  R491      -2.5764617323875427e-01
    z[1,2,4]  R492      1.6537123918533325e-01
    z[1,2,4]  R493      -4.1052049398422241e-01
    z[1,2,4]  R494      -2.0468063652515411e-01
    z[1,2,4]  R495      -7.2437569499015808e-02
    z[1,2,4]  R496      -2.6350542902946472e-01
    z[1,2,4]  R497      1.0137168318033218e-01
    z[1,2,4]  R498      1.3075691461563110e-01
    z[1,2,4]  R499      -1.4864277839660645e-01
    z[1,2,4]  R500      -9.7453128546476364e-04
    z[1,2,4]  R501      -1.4390507340431213e-01
    z[1,2,4]  R502      -1.9986103475093842e-01
    z[1,2,4]  R503      -2.4364335834980011e-01
    z[1,2,4]  R504      -2.0298688113689423e-01
    z[1,2,4]  R505      -1.5748099982738495e-01
    z[1,2,4]  R506      7.0507891476154327e-02
    z[1,2,4]  R507      2.3336309194564819e-01
    z[1,2,4]  R508      4.8944371519610286e-04
    z[1,2,4]  R509      2.4909204244613647e-01
    z[1,2,4]  R510      -5.0483405590057373e-01
    z[1,2,4]  R511      -3.9216119050979614e-01
    z[1,2,4]  R512      -6.7085914313793182e-02
    z[1,2,4]  R513      -3.5326597094535828e-01
    z[1,2,4]  R514      5.3770218044519424e-02
    z[1,2,4]  R515      -2.8380699455738068e-02
    z[1,2,4]  R516      -1.2899169325828552e-01
    z[1,2,4]  R517      -7.8646056354045868e-02
    z[1,2,4]  R518      -3.1243902444839478e-01
    z[1,2,4]  R519      -3.5084882378578186e-01
    z[1,2,4]  R520      4.9095014110207558e-03
    z[1,2,4]  R521      -2.2748914361000061e-01
    z[1,2,4]  R522      2.7913349866867065e-01
    z[1,2,4]  R523      -1.1331176012754440e-01
    z[1,2,4]  R524      -1.6841015219688416e-01
    z[1,2,4]  R525      1.2260024249553680e-01
    z[1,2,4]  R526      -2.2443506121635437e-01
    z[1,2,4]  R527      1.1996795237064362e-01
    z[1,2,4]  R528      1.7525520920753479e-01
    z[1,2,4]  R529      1.0365176200866699e-01
    z[1,2,4]  R530      9.6559226512908936e-02
    z[1,2,4]  R531      0.200368732213974
    z[1,2,4]  R532      3.1327697634696960e-01
    z[1,2,4]  R533      8.6123727262020111e-02
    z[1,2,4]  R534      -4.3691907078027725e-02
    z[1,2,4]  R535      -1.7748209834098816e-01
    z[1,2,4]  R536      -2.5371336936950684e-01
    z[1,2,4]  R537      -4.9698883295059204e-01
    z[1,2,4]  R538      -3.7619143724441528e-01
    z[1,2,4]  R539      -0.0938776507973671
    z[1,2,4]  R540      -1.9570156931877136e-01
    z[1,2,4]  R541      -1.9608359038829803e-01
    z[1,2,4]  R542      -7.5157403945922852e-02
    z[1,2,4]  R543      -5.9292886406183243e-02
    z[1,2,4]  R544      8.0217522382736206e-01
    z[1,2,4]  R545      8.0292326211929321e-01
    z[1,2,4]  R546      -1.2176158279180527e-01
    z[1,2,4]  R547      3.5552206635475159e-01
    z[1,2,4]  R548      1.0803960263729095e-01
    z[1,2,4]  R549      5.2238047122955322e-01
    z[1,2,4]  R550      3.6268595606088638e-02
    z[1,2,4]  R551      2.2943180799484253e-01
    z[1,2,4]  R552      1.8939814763143659e-03
    z[1,2,4]  R553      -4.4640892744064331e-01
    z[1,2,4]  R554      8.2703399658203125e-01
    z[1,2,4]  R555      6.3625681400299072e-01
    z[1,2,4]  R556      1.1765540577471256e-02
    z[1,2,4]  R557      1.6907185316085815e-01
    z[1,2,4]  R558      -6.3812166452407837e-02
    z[1,2,4]  R559      2.1971662342548370e-01
    z[1,2,4]  R560      6.1889201402664185e-01
    z[1,2,4]  R561      8.9461815357208252e-01
    z[1,2,4]  R562      -4.0109932422637939e-01
    z[1,2,4]  R563      2.2225309908390045e-01
    z[1,2,4]  R564      4.2056638002395630e-01
    z[1,2,4]  R565      6.5803945064544678e-01
    z[1,2,4]  R566      -5.1296311616897583e-01
    z[1,2,4]  R567      -1.9633677601814270e-01
    z[1,2,4]  R568      2.6759955286979675e-01
    z[1,2,4]  R569      0.706939697265625
    z[1,2,4]  R570      8.1082159280776978e-01
    z[1,2,4]  R571      0.498468816280365
    z[1,2,4]  R572      0.851675808429718
    z[1,2,4]  R573      3.3378455042839050e-01
    z[1,2,4]  R574      5.2420613355934620e-03
    z[1,2,4]  R575      -4.4159126281738281e-01
    z[1,2,4]  R576      -5.1426267623901367e-01
    z[1,2,4]  R577      7.2900778055191040e-01
    z[1,2,4]  R578      7.7739447355270386e-02
    z[1,2,4]  R579      1.2438498437404633e-01
    z[1,2,4]  R580      7.5727772712707520e-01
    z[1,2,4]  R581      4.4296798110008240e-01
    z[1,2,4]  R582      3.0513456463813782e-01
    z[1,2,4]  R583      -2.3997746407985687e-01
    z[1,2,4]  R584      7.3908336460590363e-02
    z[1,2,4]  R585      1.9979287683963776e-01
    z[1,2,5]  R16       -1
    z[1,2,5]  R25       1
    z[1,2,5]  R472      -1
    z[1,2,5]  R473      1
    z[1,2,5]  R476      -5.6651927297934890e-04
    z[1,2,5]  R477      9.0601295232772827e-02
    z[1,2,5]  R478      -1.7133527994155884e-01
    z[1,2,5]  R479      3.7299975752830505e-01
    z[1,2,5]  R480      4.1182979941368103e-01
    z[1,2,5]  R481      7.7907584607601166e-02
    z[1,2,5]  R482      2.6482158899307251e-01
    z[1,2,5]  R483      1.2379072606563568e-01
    z[1,2,5]  R484      6.4545914530754089e-02
    z[1,2,5]  R485      4.1312563419342041e-01
    z[1,2,5]  R486      -2.0584091544151306e-01
    z[1,2,5]  R487      2.3110151290893555e-01
    z[1,2,5]  R488      -5.2509274333715439e-02
    z[1,2,5]  R489      -3.2188376784324646e-01
    z[1,2,5]  R490      1.3271375000476837e-01
    z[1,2,5]  R491      -2.4289096891880035e-01
    z[1,2,5]  R492      7.5283623300492764e-03
    z[1,2,5]  R493      -1.3356009125709534e-01
    z[1,2,5]  R494      -1.5559597313404083e-01
    z[1,2,5]  R495      -5.3729629516601562e-01
    z[1,2,5]  R496      5.8139726519584656e-02
    z[1,2,5]  R497      1.5446808934211731e-01
    z[1,2,5]  R498      2.1611662581562996e-02
    z[1,2,5]  R499      -0.069243885576725
    z[1,2,5]  R500      1.6166546940803528e-01
    z[1,2,5]  R501      2.5690641254186630e-02
    z[1,2,5]  R502      -4.5451423525810242e-01
    z[1,2,5]  R503      -5.5896449089050293e-01
    z[1,2,5]  R504      -5.0081085413694382e-02
    z[1,2,5]  R505      -8.2788634300231934e-01
    z[1,2,5]  R506      -7.5349416583776474e-03
    z[1,2,5]  R507      -0.040500458329916
    z[1,2,5]  R508      2.0076100528240204e-01
    z[1,2,5]  R509      -0.453075110912323
    z[1,2,5]  R510      -3.6468061804771423e-01
    z[1,2,5]  R511      -4.3863037228584290e-01
    z[1,2,5]  R512      -3.8898301124572754e-01
    z[1,2,5]  R513      -2.8561952710151672e-01
    z[1,2,5]  R514      -3.9827275276184082e-01
    z[1,2,5]  R515      -4.4335415959358215e-01
    z[1,2,5]  R516      1.5868553519248962e-01
    z[1,2,5]  R517      -1.3307699561119080e-01
    z[1,2,5]  R518      4.5616918802261353e-01
    z[1,2,5]  R519      2.0551607012748718e-01
    z[1,2,5]  R520      -1.8133243918418884e-01
    z[1,2,5]  R521      1.0346614569425583e-01
    z[1,2,5]  R522      -1.3034285604953766e-01
    z[1,2,5]  R523      2.8997424244880676e-01
    z[1,2,5]  R524      -1.0508912801742554e-01
    z[1,2,5]  R525      2.8377994894981384e-01
    z[1,2,5]  R526      -3.8235333561897278e-01
    z[1,2,5]  R527      -4.5161581039428711e-01
    z[1,2,5]  R528      -2.6684507727622986e-01
    z[1,2,5]  R529      -2.4281406402587891e-01
    z[1,2,5]  R530      -5.1673788577318192e-02
    z[1,2,5]  R531      2.9943871498107910e-01
    z[1,2,5]  R532      2.3046833276748657e-01
    z[1,2,5]  R533      -2.0786814391613007e-01
    z[1,2,5]  R534      5.2016609907150269e-01
    z[1,2,5]  R535      -3.8530153036117554e-01
    z[1,2,5]  R536      -2.1397693455219269e-01
    z[1,2,5]  R537      -5.0712251663208008e-01
    z[1,2,5]  R538      -4.4329392910003662e-01
    z[1,2,5]  R539      -0.636333703994751
    z[1,2,5]  R540      -2.1468611061573029e-01
    z[1,2,5]  R541      -5.3010553121566772e-01
    z[1,2,5]  R542      -4.5094919204711914e-01
    z[1,2,5]  R543      2.3007138073444366e-01
    z[1,2,5]  R544      -6.2233596108853817e-03
    z[1,2,5]  R545      2.4792146682739258e-01
    z[1,2,5]  R546      -1.4309531450271606e-01
    z[1,2,5]  R547      -3.3593752980232239e-01
    z[1,2,5]  R548      -3.9521834254264832e-01
    z[1,2,5]  R549      3.8066470623016357e-01
    z[1,2,5]  R550      -3.7482002377510071e-01
    z[1,2,5]  R551      -2.3112215101718903e-01
    z[1,2,5]  R552      -1.9764302670955658e-01
    z[1,2,5]  R553      3.4995386004447937e-01
    z[1,2,5]  R554      0.262921005487442
    z[1,2,5]  R555      7.3634006083011627e-02
    z[1,2,5]  R556      -6.6669160127639771e-01
    z[1,2,5]  R557      -4.7642791271209717e-01
    z[1,2,5]  R558      -6.8624633550643921e-01
    z[1,2,5]  R559      5.4921054840087891e-01
    z[1,2,5]  R560      1.7313297092914581e-01
    z[1,2,5]  R561      1.3795202970504761e-01
    z[1,2,5]  R562      -0.472665399312973
    z[1,2,5]  R563      -3.0621027946472168e-01
    z[1,2,5]  R564      4.4452944397926331e-01
    z[1,2,5]  R565      4.3774670362472534e-01
    z[1,2,5]  R566      -1.1383699625730515e-01
    z[1,2,5]  R567      -5.2780801057815552e-01
    z[1,2,5]  R568      5.5221915245056152e-01
    z[1,2,5]  R569      2.0059312880039215e-01
    z[1,2,5]  R570      -1.3569347560405731e-01
    z[1,2,5]  R571      4.4040087610483170e-02
    z[1,2,5]  R572      8.8828159496188164e-03
    z[1,2,5]  R573      -3.1864476203918457e-01
    z[1,2,5]  R574      -4.9679529666900635e-01
    z[1,2,5]  R575      1.2843219563364983e-02
    z[1,2,5]  R576      -1.8174874782562256e-01
    z[1,2,5]  R577      -1.4751896262168884e-01
    z[1,2,5]  R578      -3.6593183875083923e-02
    z[1,2,5]  R579      -8.8280633091926575e-02
    z[1,2,5]  R580      1.9343499839305878e-01
    z[1,2,5]  R581      -3.6710628867149353e-01
    z[1,2,5]  R582      0.607828676700592
    z[1,2,5]  R583      5.4488813877105713e-01
    z[1,2,5]  R584      0.67137610912323
    z[1,2,5]  R585      4.1305643320083618e-01
    z[1,2,6]  R17       -1
    z[1,2,6]  R26       1
    z[1,2,6]  R474      -1
    z[1,2,6]  R475      1
    z[1,2,6]  R476      -2.9847362637519836e-01
    z[1,2,6]  R477      1.3364848494529724e-01
    z[1,2,6]  R478      5.7265937328338623e-01
    z[1,2,6]  R479      -3.7704864144325256e-01
    z[1,2,6]  R480      2.1458871662616730e-01
    z[1,2,6]  R481      4.5019667595624924e-03
    z[1,2,6]  R482      -4.5302253961563110e-01
    z[1,2,6]  R483      7.6544538140296936e-02
    z[1,2,6]  R484      -7.2506345808506012e-02
    z[1,2,6]  R485      2.6650076732039452e-02
    z[1,2,6]  R486      -3.7373367697000504e-02
    z[1,2,6]  R487      -1.4916238188743591e-01
    z[1,2,6]  R488      3.4588301181793213e-01
    z[1,2,6]  R489      -1.3130338490009308e-01
    z[1,2,6]  R490      9.6046822145581245e-03
    z[1,2,6]  R491      -2.5644913315773010e-01
    z[1,2,6]  R492      0.368935763835907
    z[1,2,6]  R493      2.1128838881850243e-02
    z[1,2,6]  R494      2.5318679213523865e-01
    z[1,2,6]  R495      2.0364819467067719e-01
    z[1,2,6]  R496      -3.6755308508872986e-02
    z[1,2,6]  R497      1.0403539240360260e-01
    z[1,2,6]  R498      -1.5753178298473358e-01
    z[1,2,6]  R499      3.5538470745086670e-01
    z[1,2,6]  R500      -5.3524747490882874e-02
    z[1,2,6]  R501      -7.6234750449657440e-02
    z[1,2,6]  R502      3.6388018727302551e-01
    z[1,2,6]  R503      2.8143441304564476e-02
    z[1,2,6]  R504      -5.3437568247318268e-02
    z[1,2,6]  R505      -7.5942777097225189e-02
    z[1,2,6]  R506      9.3145325779914856e-02
    z[1,2,6]  R507      -0.239437997341156
    z[1,2,6]  R508      4.5635515451431274e-01
    z[1,2,6]  R509      -2.7225065231323242e-01
    z[1,2,6]  R510      1.1862057447433472e-01
    z[1,2,6]  R511      3.4772762656211853e-01
    z[1,2,6]  R512      3.3204165101051331e-01
    z[1,2,6]  R513      -5.7194292545318604e-02
    z[1,2,6]  R514      -5.5794060230255127e-02
    z[1,2,6]  R515      -3.5684242844581604e-02
    z[1,2,6]  R516      -5.0029113888740540e-02
    z[1,2,6]  R517      -2.3115381598472595e-01
    z[1,2,6]  R518      -8.9278884232044220e-02
    z[1,2,6]  R519      -1.0339193791151047e-01
    z[1,2,6]  R520      2.1415881812572479e-01
    z[1,2,6]  R521      -4.6624112129211426e-01
    z[1,2,6]  R522      -3.0351492762565613e-01
    z[1,2,6]  R523      -3.8648679852485657e-01
    z[1,2,6]  R524      -1.0934099555015564e-01
    z[1,2,6]  R525      -2.6732918620109558e-01
    z[1,2,6]  R526      5.1108545064926147e-01
    z[1,2,6]  R527      -7.2644329071044922e-01
    z[1,2,6]  R528      -2.0665641129016876e-01
    z[1,2,6]  R529      -5.1648229360580444e-01
    z[1,2,6]  R530      -2.5272938609123230e-01
    z[1,2,6]  R531      1.3192677497863770e-01
    z[1,2,6]  R532      -9.0538740158081055e-02
    z[1,2,6]  R533      4.9501422047615051e-01
    z[1,2,6]  R534      6.2232349067926407e-02
    z[1,2,6]  R535      -2.6739564538002014e-01
    z[1,2,6]  R536      -2.0970292389392853e-01
    z[1,2,6]  R537      1.6176858544349670e-01
    z[1,2,6]  R538      -2.4438551068305969e-01
    z[1,2,6]  R539      -1.0012000799179077e-01
    z[1,2,6]  R540      -3.2189422845840454e-01
    z[1,2,6]  R541      2.2226870059967041e-01
    z[1,2,6]  R542      -0.262014240026474
    z[1,2,6]  R543      -1.6785086691379547e-01
    z[1,2,6]  R544      3.9106106758117676e-01
    z[1,2,6]  R545      3.4687098860740662e-01
    z[1,2,6]  R546      5.4809689521789551e-02
    z[1,2,6]  R547      -6.6034264862537384e-02
    z[1,2,6]  R548      1.3592340052127838e-01
    z[1,2,6]  R549      1.0662989318370819e-01
    z[1,2,6]  R550      4.2565248906612396e-02
    z[1,2,6]  R551      -5.8749181032180786e-01
    z[1,2,6]  R552      3.6409419775009155e-01
    z[1,2,6]  R553      3.9275979995727539e-01
    z[1,2,6]  R554      -7.0015847682952881e-02
    z[1,2,6]  R555      7.8138843178749084e-02
    z[1,2,6]  R556      1.0038229823112488e-01
    z[1,2,6]  R557      5.6645695120096207e-02
    z[1,2,6]  R558      1.4229616522789001e-01
    z[1,2,6]  R559      1.3901987671852112e-01
    z[1,2,6]  R560      0.23238605260849
    z[1,2,6]  R561      2.2056837379932404e-01
    z[1,2,6]  R562      3.3691248297691345e-01
    z[1,2,6]  R563      1.2322041392326355e-01
    z[1,2,6]  R564      1.0096822865307331e-02
    z[1,2,6]  R565      6.1866792384535074e-04
    z[1,2,6]  R566      0.0417693592607975
    z[1,2,6]  R567      5.0848484039306641e-01
    z[1,2,6]  R568      2.5371477007865906e-01
    z[1,2,6]  R569      -7.3690533638000488e-02
    z[1,2,6]  R570      2.1654383838176727e-01
    z[1,2,6]  R571      1.7860314249992371e-01
    z[1,2,6]  R572      -5.0366683863103390e-03
    z[1,2,6]  R573      -2.3265336453914642e-01
    z[1,2,6]  R574      -6.2715482711791992e-01
    z[1,2,6]  R575      0.556354284286499
    z[1,2,6]  R576      2.7617228031158447e-01
    z[1,2,6]  R577      6.0965497046709061e-02
    z[1,2,6]  R578      3.6251747608184814e-01
    z[1,2,6]  R579      2.1518450975418091e-01
    z[1,2,6]  R580      -3.1988853216171265e-01
    z[1,2,6]  R581      -1.4080493152141571e-01
    z[1,2,6]  R582      4.4668808579444885e-01
    z[1,2,6]  R583      2.3696416616439819e-01
    z[1,2,6]  R584      -1.7106316983699799e-01
    z[1,2,6]  R585      2.4901130795478821e-01
    z[2,1,0]  R11       1
    z[2,1,0]  R20       -1
    z[2,1,0]  R586      -1
    z[2,1,0]  R587      1
    z[2,1,0]  R600      -4.9124273657798767e-01
    z[2,1,0]  R601      -7.7634233236312866e-01
    z[2,1,0]  R602      -4.5373073220252991e-01
    z[2,1,0]  R603      -6.8108010292053223e-01
    z[2,1,0]  R604      -7.1953850984573364e-01
    z[2,1,0]  R605      -4.6407660841941833e-01
    z[2,1,0]  R606      -3.3312138915061951e-01
    z[2,1,0]  R607      -7.2410744428634644e-01
    z[2,1,0]  R608      -6.1397582292556763e-01
    z[2,1,0]  R609      -1.4422667026519775e-01
    z[2,1,0]  R610      6.1473723500967026e-02
    z[2,1,0]  R611      0.153394877910614
    z[2,1,0]  R612      -2.0218744874000549e-01
    z[2,1,0]  R613      -1.8500488996505737e-01
    z[2,1,0]  R614      1.5352945029735565e-01
    z[2,1,0]  R615      9.4493657350540161e-02
    z[2,1,0]  R616      -0.059889055788517
    z[2,1,0]  R617      2.3794810473918915e-01
    z[2,1,0]  R618      -2.4597447365522385e-02
    z[2,1,0]  R619      4.5672440528869629e-01
    z[2,1,0]  R620      4.7142812609672546e-01
    z[2,1,0]  R621      2.4861901998519897e-02
    z[2,1,0]  R622      -1.4215698838233948e-01
    z[2,1,0]  R623      5.0571531057357788e-01
    z[2,1,0]  R624      1.2481260299682617e-01
    z[2,1,0]  R625      -4.0614360570907593e-01
    z[2,1,0]  R626      -1.9890600442886353e-01
    z[2,1,0]  R627      1.8972903490066528e-02
    z[2,1,0]  R628      -6.2058974057435989e-02
    z[2,1,0]  R629      -1.0376165807247162e-01
    z[2,1,0]  R630      -1.7810884118080139e-01
    z[2,1,0]  R631      9.4430714845657349e-02
    z[2,1,0]  R632      1.2676912546157837e-01
    z[2,1,0]  R633      -1.5843637287616730e-01
    z[2,1,0]  R634      4.0129086375236511e-01
    z[2,1,0]  R635      2.0959985256195068e-01
    z[2,1,0]  R636      4.2695617675781250e-01
    z[2,1,0]  R637      -8.0943085253238678e-02
    z[2,1,0]  R638      -3.6984920501708984e-01
    z[2,1,0]  R639      -6.6380125284194946e-01
    z[2,1,0]  R640      -4.9481880851089954e-03
    z[2,1,0]  R641      -6.7595876753330231e-03
    z[2,1,0]  R642      2.1995209157466888e-01
    z[2,1,0]  R643      -5.0826031714677811e-02
    z[2,1,0]  R644      4.4874809682369232e-02
    z[2,1,0]  R645      -3.3454048633575439e-01
    z[2,1,0]  R646      2.5708615779876709e-01
    z[2,1,0]  R647      6.0063779354095459e-01
    z[2,1,0]  R648      -6.4115297794342041e-01
    z[2,1,0]  R649      -3.8052040338516235e-01
    z[2,1,0]  R650      2.9909870028495789e-01
    z[2,1,0]  R651      -1.2768530286848545e-02
    z[2,1,0]  R652      -2.4318021535873413e-01
    z[2,1,0]  R653      6.0623455792665482e-02
    z[2,1,0]  R654      -4.2846912145614624e-01
    z[2,1,0]  R655      -2.1448197960853577e-01
    z[2,1,0]  R656      -3.8751190900802612e-01
    z[2,1,0]  R657      5.0506293773651123e-01
    z[2,1,0]  R658      2.9371036216616631e-02
    z[2,1,0]  R659      -1.8463903665542603e-01
    z[2,1,0]  R660      -1.7569494247436523e-01
    z[2,1,0]  R661      -3.0998736619949341e-01
    z[2,1,0]  R662      -0.0892467051744461
    z[2,1,0]  R663      3.0539789795875549e-01
    z[2,1,0]  R664      -3.7317898869514465e-01
    z[2,1,0]  R665      4.7704753279685974e-01
    z[2,1,0]  R666      3.6393198370933533e-01
    z[2,1,0]  R667      6.0187149047851562e-01
    z[2,1,0]  R668      0.573669970035553
    z[2,1,0]  R669      6.0565555095672607e-01
    z[2,1,0]  R670      2.7962762117385864e-01
    z[2,1,0]  R671      2.0304465293884277e-01
    z[2,1,0]  R672      4.8196381330490112e-01
    z[2,1,0]  R673      4.9614846706390381e-01
    z[2,1,0]  R674      1.2865640223026276e-01
    z[2,1,0]  R675      -6.1407768726348877e-01
    z[2,1,0]  R676      -3.2301995903253555e-02
    z[2,1,0]  R677      -6.5264117717742920e-01
    z[2,1,0]  R678      5.8207523822784424e-01
    z[2,1,0]  R679      -3.2870405912399292e-01
    z[2,1,0]  R680      -3.1641387939453125e-01
    z[2,1,0]  R681      -4.2277911305427551e-01
    z[2,1,0]  R682      -1.0244952887296677e-01
    z[2,1,0]  R683      -1.2051765620708466e-01
    z[2,1,0]  R684      -4.8893335461616516e-01
    z[2,1,0]  R685      -1.8897777795791626e-01
    z[2,1,0]  R686      1.3949221372604370e-01
    z[2,1,0]  R687      -2.2030605375766754e-01
    z[2,1,0]  R688      -2.1836702525615692e-01
    z[2,1,0]  R689      2.3509931564331055e-01
    z[2,1,0]  R690      -7.6377198100090027e-02
    z[2,1,0]  R691      3.1136092543601990e-01
    z[2,1,0]  R692      3.0841851234436035e-01
    z[2,1,0]  R693      2.2287490963935852e-01
    z[2,1,0]  R694      -5.3050625324249268e-01
    z[2,1,0]  R695      -1.4284588396549225e-01
    z[2,1,0]  R696      2.0959232747554779e-01
    z[2,1,0]  R697      2.6491835713386536e-01
    z[2,1,0]  R698      4.4635945558547974e-01
    z[2,1,0]  R699      8.6355626583099365e-02
    z[2,1,0]  R700      2.9921406507492065e-01
    z[2,1,0]  R701      -3.4507188200950623e-01
    z[2,1,0]  R702      -6.5469577908515930e-02
    z[2,1,0]  R703      8.4681533277034760e-02
    z[2,1,0]  R704      -4.7394716739654541e-01
    z[2,1,0]  R705      -0.486203134059906
    z[2,1,0]  R706      -5.0084066390991211e-01
    z[2,1,0]  R707      -6.6228991746902466e-01
    z[2,1,0]  R708      -6.7427629232406616e-01
    z[2,1,0]  R709      -7.0876157283782959e-01
    z[2,1,1]  R12       1
    z[2,1,1]  R21       -1
    z[2,1,1]  R588      -1
    z[2,1,1]  R589      1
    z[2,1,1]  R600      -4.4544604420661926e-01
    z[2,1,1]  R601      -4.0777593851089478e-01
    z[2,1,1]  R602      -4.2607891559600830e-01
    z[2,1,1]  R603      -2.7949529886245728e-01
    z[2,1,1]  R604      -0.350705623626709
    z[2,1,1]  R605      -0.363901287317276
    z[2,1,1]  R606      -4.9221006035804749e-01
    z[2,1,1]  R607      -3.8024628162384033e-01
    z[2,1,1]  R608      0.237028107047081
    z[2,1,1]  R609      -8.7349957227706909e-01
    z[2,1,1]  R610      -2.5577083230018616e-01
    z[2,1,1]  R611      2.4164129793643951e-01
    z[2,1,1]  R612      0.829850971698761
    z[2,1,1]  R613      6.4701384305953979e-01
    z[2,1,1]  R614      9.1239744424819946e-01
    z[2,1,1]  R615      8.7869280576705933e-01
    z[2,1,1]  R616      8.8222002983093262e-01
    z[2,1,1]  R617      3.3945631980895996e-01
    z[2,1,1]  R618      7.9038488864898682e-01
    z[2,1,1]  R619      4.7249439358711243e-01
    z[2,1,1]  R620      -2.5328485295176506e-02
    z[2,1,1]  R621      -4.2231306433677673e-01
    z[2,1,1]  R622      1.6041561961174011e-01
    z[2,1,1]  R623      9.7372457385063171e-02
    z[2,1,1]  R624      3.9665067195892334e-01
    z[2,1,1]  R625      5.0427418947219849e-01
    z[2,1,1]  R626      -2.2575311362743378e-01
    z[2,1,1]  R627      2.1479836106300354e-01
    z[2,1,1]  R628      2.1152751147747040e-01
    z[2,1,1]  R629      2.3155732452869415e-01
    z[2,1,1]  R630      -2.0896512269973755e-01
    z[2,1,1]  R631      -8.6768402252346277e-04
    z[2,1,1]  R632      4.8274621367454529e-01
    z[2,1,1]  R633      3.2020667195320129e-01
    z[2,1,1]  R634      1.8010555207729340e-01
    z[2,1,1]  R635      -4.0624219179153442e-01
    z[2,1,1]  R636      -4.6342805027961731e-02
    z[2,1,1]  R637      2.6514491438865662e-01
    z[2,1,1]  R638      2.3521491885185242e-01
    z[2,1,1]  R639      2.4544388055801392e-01
    z[2,1,1]  R640      -8.3455711603164673e-02
    z[2,1,1]  R641      1.5370737016201019e-01
    z[2,1,1]  R642      2.3272086679935455e-01
    z[2,1,1]  R643      3.5309621691703796e-01
    z[2,1,1]  R644      1.4941997826099396e-01
    z[2,1,1]  R645      -3.7667483091354370e-02
    z[2,1,1]  R646      4.8218145966529846e-01
    z[2,1,1]  R647      -1.7782464623451233e-01
    z[2,1,1]  R648      3.9055651426315308e-01
    z[2,1,1]  R649      4.6254959702491760e-01
    z[2,1,1]  R650      2.5293555110692978e-02
    z[2,1,1]  R651      1.9626750051975250e-01
    z[2,1,1]  R652      9.6097335219383240e-02
    z[2,1,1]  R653      1.5056197345256805e-01
    z[2,1,1]  R654      1.8992094695568085e-01
    z[2,1,1]  R655      3.4925243258476257e-01
    z[2,1,1]  R656      -9.8732315003871918e-02
    z[2,1,1]  R657      -1.1955556273460388e-01
    z[2,1,1]  R658      -4.8471504449844360e-01
    z[2,1,1]  R659      3.3883380889892578e-01
    z[2,1,1]  R660      -4.6554881334304810e-01
    z[2,1,1]  R661      8.7587319314479828e-02
    z[2,1,1]  R662      3.0281466245651245e-01
    z[2,1,1]  R663      0.00760143157094717
    z[2,1,1]  R664      2.8109899163246155e-01
    z[2,1,1]  R665      4.2320245504379272e-01
    z[2,1,1]  R666      -2.1706353127956390e-01
    z[2,1,1]  R667      -3.9704304933547974e-01
    z[2,1,1]  R668      -1.0005540400743484e-01
    z[2,1,1]  R669      -0.344194233417511
    z[2,1,1]  R670      -2.1921348571777344e-01
    z[2,1,1]  R671      -7.4452593922615051e-02
    z[2,1,1]  R672      -5.0826704502105713e-01
    z[2,1,1]  R673      -3.2922571897506714e-01
    z[2,1,1]  R674      8.1142103672027588e-01
    z[2,1,1]  R675      6.1842817068099976e-01
    z[2,1,1]  R676      6.8973690271377563e-01
    z[2,1,1]  R677      5.9134668111801147e-01
    z[2,1,1]  R678      6.1284792423248291e-01
    z[2,1,1]  R679      0.573715090751648
    z[2,1,1]  R680      9.0683412551879883e-01
    z[2,1,1]  R681      8.3137172460556030e-01
    z[2,1,1]  R682      8.0535823106765747e-01
    z[2,1,1]  R683      -3.2495595514774323e-02
    z[2,1,1]  R684      7.1907246112823486e-01
    z[2,1,1]  R685      -4.5671343803405762e-02
    z[2,1,1]  R686      8.2761889696121216e-01
    z[2,1,1]  R687      6.8467676639556885e-01
    z[2,1,1]  R688      -3.5720226168632507e-01
    z[2,1,1]  R689      2.8877329826354980e-01
    z[2,1,1]  R690      9.3616098165512085e-01
    z[2,1,1]  R691      8.7562519311904907e-01
    z[2,1,1]  R692      9.1728532314300537e-01
    z[2,1,1]  R693      8.2997298240661621e-01
    z[2,1,1]  R694      7.4703454971313477e-01
    z[2,1,1]  R695      8.3241719007492065e-01
    z[2,1,1]  R696      7.4476099014282227e-01
    z[2,1,1]  R697      7.3139709234237671e-01
    z[2,1,1]  R698      7.7011620998382568e-01
    z[2,1,1]  R699      2.8373071551322937e-01
    z[2,1,1]  R700      9.1313737630844116e-01
    z[2,1,1]  R701      8.1033390760421753e-01
    z[2,1,1]  R702      8.0890297889709473e-01
    z[2,1,1]  R703      0.686237633228302
    z[2,1,1]  R704      3.3341646194458008e-01
    z[2,1,1]  R705      2.3928360641002655e-01
    z[2,1,1]  R706      1.6235956549644470e-01
    z[2,1,1]  R707      -3.7058692425489426e-02
    z[2,1,1]  R708      -1.9127799198031425e-02
    z[2,1,1]  R709      1.4989666640758514e-01
    z[2,1,2]  R13       1
    z[2,1,2]  R22       -1
    z[2,1,2]  R590      -1
    z[2,1,2]  R591      1
    z[2,1,2]  R600      -5.0723069906234741e-01
    z[2,1,2]  R601      -3.0221751332283020e-01
    z[2,1,2]  R602      -5.4670047760009766e-01
    z[2,1,2]  R603      -5.1954925060272217e-01
    z[2,1,2]  R604      -3.8589019328355789e-02
    z[2,1,2]  R605      -6.0903567075729370e-01
    z[2,1,2]  R606      -4.8527535051107407e-02
    z[2,1,2]  R607      -2.2927054762840271e-01
    z[2,1,2]  R608      -6.1901479959487915e-01
    z[2,1,2]  R609      3.8353729993104935e-02
    z[2,1,2]  R610      4.4338819384574890e-01
    z[2,1,2]  R611      -3.2167810946702957e-02
    z[2,1,2]  R612      3.1972485780715942e-01
    z[2,1,2]  R613      5.0286766141653061e-02
    z[2,1,2]  R614      1.2339603155851364e-01
    z[2,1,2]  R615      2.6287573575973511e-01
    z[2,1,2]  R616      2.2269165515899658e-01
    z[2,1,2]  R617      6.6414773464202881e-01
    z[2,1,2]  R618      7.4134194292128086e-03
    z[2,1,2]  R619      -2.6723316311836243e-01
    z[2,1,2]  R620      -0.0663272812962532
    z[2,1,2]  R621      -3.2018488645553589e-01
    z[2,1,2]  R622      -3.5017940402030945e-01
    z[2,1,2]  R623      1.4386005699634552e-01
    z[2,1,2]  R624      -8.9014537632465363e-02
    z[2,1,2]  R625      1.2869903445243835e-01
    z[2,1,2]  R626      3.2295051217079163e-01
    z[2,1,2]  R627      3.2745265960693359e-01
    z[2,1,2]  R628      -2.7053061127662659e-01
    z[2,1,2]  R629      -3.1839540600776672e-01
    z[2,1,2]  R630      4.8677217960357666e-01
    z[2,1,2]  R631      8.2149881124496460e-01
    z[2,1,2]  R632      5.7530528306961060e-01
    z[2,1,2]  R633      1.1776317656040192e-01
    z[2,1,2]  R634      -4.4055002927780151e-01
    z[2,1,2]  R635      3.9006423950195312e-01
    z[2,1,2]  R636      -2.8825944662094116e-01
    z[2,1,2]  R637      -1.3484659790992737e-01
    z[2,1,2]  R638      2.1095946431159973e-01
    z[2,1,2]  R639      -1.1477702856063843e-01
    z[2,1,2]  R640      5.4724162817001343e-01
    z[2,1,2]  R641      -2.2157758474349976e-01
    z[2,1,2]  R642      3.6912760138511658e-01
    z[2,1,2]  R643      -1.3935816287994385e-01
    z[2,1,2]  R644      -1.5904602408409119e-01
    z[2,1,2]  R645      -1.1023134738206863e-01
    z[2,1,2]  R646      -3.6716946959495544e-01
    z[2,1,2]  R647      6.4137715101242065e-01
    z[2,1,2]  R648      4.7803804278373718e-02
    z[2,1,2]  R649      -1.0268244892358780e-01
    z[2,1,2]  R650      -4.5061972737312317e-01
    z[2,1,2]  R651      3.8992297649383545e-01
    z[2,1,2]  R652      1.1180755496025085e-01
    z[2,1,2]  R653      -4.3792682886123657e-01
    z[2,1,2]  R654      -2.3457825183868408e-01
    z[2,1,2]  R655      5.8858606964349747e-02
    z[2,1,2]  R656      -3.3551222085952759e-01
    z[2,1,2]  R657      0.629315972328186
    z[2,1,2]  R658      -3.7618912756443024e-02
    z[2,1,2]  R659      -1.8613802269101143e-02
    z[2,1,2]  R660      -1.5646006166934967e-01
    z[2,1,2]  R661      -3.8047635555267334e-01
    z[2,1,2]  R662      -2.5038030743598938e-01
    z[2,1,2]  R663      -2.7576902508735657e-01
    z[2,1,2]  R664      -1.3379658758640289e-01
    z[2,1,2]  R665      4.4476044178009033e-01
    z[2,1,2]  R666      -3.8278463482856750e-01
    z[2,1,2]  R667      -1.5245710313320160e-01
    z[2,1,2]  R668      -3.1500127911567688e-01
    z[2,1,2]  R669      -4.9095860123634338e-01
    z[2,1,2]  R670      5.3371560573577881e-01
    z[2,1,2]  R671      6.8362191319465637e-02
    z[2,1,2]  R672      1.8323728442192078e-01
    z[2,1,2]  R673      -2.4813309311866760e-01
    z[2,1,2]  R674      2.8203356266021729e-01
    z[2,1,2]  R675      3.6106950044631958e-01
    z[2,1,2]  R676      -4.1474151611328125e-01
    z[2,1,2]  R677      3.9721819758415222e-01
    z[2,1,2]  R678      -1.3042224943637848e-01
    z[2,1,2]  R679      -5.7017207145690918e-01
    z[2,1,2]  R680      1.1580395698547363e-01
    z[2,1,2]  R681      1.8631696701049805e-01
    z[2,1,2]  R682      -2.3490869998931885e-01
    z[2,1,2]  R683      6.1722569167613983e-02
    z[2,1,2]  R684      -4.1013407707214355e-01
    z[2,1,2]  R685      -4.0237170457839966e-01
    z[2,1,2]  R686      1.8765635788440704e-01
    z[2,1,2]  R687      -0.515556275844574
    z[2,1,2]  R688      -1.5989071130752563e-01
    z[2,1,2]  R689      -1.3489606976509094e-01
    z[2,1,2]  R690      -3.3976398408412933e-02
    z[2,1,2]  R691      -2.9960241913795471e-01
    z[2,1,2]  R692      -1.3145267963409424e-01
    z[2,1,2]  R693      -3.2863074541091919e-01
    z[2,1,2]  R694      -2.4547062814235687e-01
    z[2,1,2]  R695      4.0565276145935059e-01
    z[2,1,2]  R696      1.3377526402473450e-01
    z[2,1,2]  R697      7.7422477304935455e-02
    z[2,1,2]  R698      1.4425605535507202e-01
    z[2,1,2]  R699      1.4587850868701935e-01
    z[2,1,2]  R700      2.3768074810504913e-01
    z[2,1,2]  R701      -3.1970882415771484e-01
    z[2,1,2]  R702      2.7199709415435791e-01
    z[2,1,2]  R703      -4.0316683053970337e-01
    z[2,1,2]  R704      -4.2920511960983276e-01
    z[2,1,2]  R705      -4.8564866185188293e-01
    z[2,1,2]  R706      -5.3797960281372070e-01
    z[2,1,2]  R707      -5.8077478408813477e-01
    z[2,1,2]  R708      -6.0098898410797119e-01
    z[2,1,2]  R709      -1.6859672963619232e-01
    z[2,1,3]  R14       1
    z[2,1,3]  R23       -1
    z[2,1,3]  R592      -1
    z[2,1,3]  R593      1
    z[2,1,3]  R600      5.0857901573181152e-01
    z[2,1,3]  R601      2.4969819188117981e-01
    z[2,1,3]  R602      4.9621476791799068e-03
    z[2,1,3]  R603      -1.0981449484825134e-01
    z[2,1,3]  R604      5.2821516990661621e-01
    z[2,1,3]  R605      -3.8038119673728943e-02
    z[2,1,3]  R606      6.7629760503768921e-01
    z[2,1,3]  R607      -1.7949819564819336e-01
    z[2,1,3]  R608      3.6374571919441223e-01
    z[2,1,3]  R609      2.1840167045593262e-01
    z[2,1,3]  R610      -0.52577143907547
    z[2,1,3]  R611      -4.1349199414253235e-01
    z[2,1,3]  R612      -1.5367542207241058e-01
    z[2,1,3]  R613      -4.5624691247940063e-01
    z[2,1,3]  R614      -2.2992837429046631e-01
    z[2,1,3]  R615      -5.1483251154422760e-02
    z[2,1,3]  R616      9.5154352486133575e-02
    z[2,1,3]  R617      -3.0231153964996338e-01
    z[2,1,3]  R618      -3.1349179148674011e-01
    z[2,1,3]  R619      -4.9525824189186096e-01
    z[2,1,3]  R620      -7.8650033473968506e-01
    z[2,1,3]  R621      -4.3379139900207520e-01
    z[2,1,3]  R622      -6.5854293107986450e-01
    z[2,1,3]  R623      -5.3881102800369263e-01
    z[2,1,3]  R624      -7.9445666074752808e-01
    z[2,1,3]  R625      -4.4195863604545593e-01
    z[2,1,3]  R626      -7.2630548477172852e-01
    z[2,1,3]  R627      -8.7272793054580688e-01
    z[2,1,3]  R628      2.8594639897346497e-01
    z[2,1,3]  R629      0.0881413072347641
    z[2,1,3]  R630      -8.0582714080810547e-01
    z[2,1,3]  R631      -2.6946470141410828e-01
    z[2,1,3]  R632      -4.8328486084938049e-01
    z[2,1,3]  R633      6.5524083375930786e-01
    z[2,1,3]  R634      6.8470877408981323e-01
    z[2,1,3]  R635      -4.3322277069091797e-01
    z[2,1,3]  R636      7.4889016151428223e-01
    z[2,1,3]  R637      -6.5494573116302490e-01
    z[2,1,3]  R638      7.3258213698863983e-02
    z[2,1,3]  R639      -2.6382020115852356e-01
    z[2,1,3]  R640      -4.8871728777885437e-01
    z[2,1,3]  R641      8.1759041547775269e-01
    z[2,1,3]  R642      -0.515705943107605
    z[2,1,3]  R643      0.695762038230896
    z[2,1,3]  R644      6.9523996114730835e-01
    z[2,1,3]  R645      8.0560527741909027e-02
    z[2,1,3]  R646      -2.6228037476539612e-01
    z[2,1,3]  R647      -1.9468809664249420e-01
    z[2,1,3]  R648      2.4396492540836334e-01
    z[2,1,3]  R649      0.0779092013835907
    z[2,1,3]  R650      -6.5498644113540649e-01
    z[2,1,3]  R651      -4.8331132531166077e-01
    z[2,1,3]  R652      6.9152086973190308e-01
    z[2,1,3]  R653      4.8625549674034119e-01
    z[2,1,3]  R654      5.0809867680072784e-02
    z[2,1,3]  R655      7.3908466100692749e-01
    z[2,1,3]  R656      -4.5410543680191040e-02
    z[2,1,3]  R657      -2.5981745123863220e-01
    z[2,1,3]  R658      -3.5016742348670959e-01
    z[2,1,3]  R659      -5.8826500177383423e-01
    z[2,1,3]  R660      -5.9510171413421631e-01
    z[2,1,3]  R661      4.4107037782669067e-01
    z[2,1,3]  R662      8.3597046136856079e-01
    z[2,1,3]  R663      8.7238538265228271e-01
    z[2,1,3]  R664      2.2495311498641968e-01
    z[2,1,3]  R665      2.1142323315143585e-01
    z[2,1,3]  R666      1.0871886461973190e-01
    z[2,1,3]  R667      -2.1498848497867584e-01
    z[2,1,3]  R668      2.7603426575660706e-01
    z[2,1,3]  R669      -3.3645071089267731e-02
    z[2,1,3]  R670      6.4021801948547363e-01
    z[2,1,3]  R671      8.7169617414474487e-01
    z[2,1,3]  R672      3.1608742475509644e-01
    z[2,1,3]  R673      5.3747820854187012e-01
    z[2,1,3]  R674      6.8027116358280182e-02
    z[2,1,3]  R675      0.0730455219745636
    z[2,1,3]  R676      -2.5397205352783203e-01
    z[2,1,3]  R677      -1.9554081559181213e-01
    z[2,1,3]  R678      -4.5375058054924011e-01
    z[2,1,3]  R679      1.3821160793304443e-01
    z[2,1,3]  R680      0.0708138570189476
    z[2,1,3]  R681      -2.3503344506025314e-02
    z[2,1,3]  R682      -3.5512641072273254e-01
    z[2,1,3]  R683      -8.0423909425735474e-01
    z[2,1,3]  R684      -1.5500102937221527e-01
    z[2,1,3]  R685      -7.8048378229141235e-01
    z[2,1,3]  R686      -3.1121698021888733e-01
    z[2,1,3]  R687      1.7341528832912445e-01
    z[2,1,3]  R688      -8.1789320707321167e-01
    z[2,1,3]  R689      -7.1255475282669067e-01
    z[2,1,3]  R690      -2.0603038370609283e-01
    z[2,1,3]  R691      4.0164690464735031e-02
    z[2,1,3]  R692      -0.0616854727268219
    z[2,1,3]  R693      1.6903959214687347e-02
    z[2,1,3]  R694      -2.6691758632659912e-01
    z[2,1,3]  R695      -3.0812656879425049e-01
    z[2,1,3]  R696      -0.0676007941365242
    z[2,1,3]  R697      1.2762063741683960e-01
    z[2,1,3]  R698      -3.7457591295242310e-01
    z[2,1,3]  R699      -4.1808575391769409e-01
    z[2,1,3]  R700      -8.0341942608356476e-02
    z[2,1,3]  R701      9.2959113419055939e-02
    z[2,1,3]  R702      -1.3726647198200226e-01
    z[2,1,3]  R703      -1.3386221230030060e-01
    z[2,1,3]  R704      -2.7941063046455383e-01
    z[2,1,3]  R705      -5.8254975825548172e-02
    z[2,1,3]  R706      -4.0904280543327332e-01
    z[2,1,3]  R707      -1.1424877494573593e-01
    z[2,1,3]  R708      -1.3846483826637268e-01
    z[2,1,3]  R709      -4.9811783432960510e-01
    z[2,1,4]  R15       1
    z[2,1,4]  R24       -1
    z[2,1,4]  R594      -1
    z[2,1,4]  R595      1
    z[2,1,4]  R600      -1.2899169325828552e-01
    z[2,1,4]  R601      -7.8646056354045868e-02
    z[2,1,4]  R602      -3.1243902444839478e-01
    z[2,1,4]  R603      -3.5084882378578186e-01
    z[2,1,4]  R604      4.9095014110207558e-03
    z[2,1,4]  R605      -2.2748914361000061e-01
    z[2,1,4]  R606      2.7913349866867065e-01
    z[2,1,4]  R607      -1.1331176012754440e-01
    z[2,1,4]  R608      -1.6841015219688416e-01
    z[2,1,4]  R609      1.2260024249553680e-01
    z[2,1,4]  R610      -2.2443506121635437e-01
    z[2,1,4]  R611      1.1996795237064362e-01
    z[2,1,4]  R612      1.7525520920753479e-01
    z[2,1,4]  R613      1.0365176200866699e-01
    z[2,1,4]  R614      9.6559226512908936e-02
    z[2,1,4]  R615      0.200368732213974
    z[2,1,4]  R616      3.1327697634696960e-01
    z[2,1,4]  R617      8.6123727262020111e-02
    z[2,1,4]  R618      -4.3691907078027725e-02
    z[2,1,4]  R619      -1.7748209834098816e-01
    z[2,1,4]  R620      -2.5371336936950684e-01
    z[2,1,4]  R621      -4.9698883295059204e-01
    z[2,1,4]  R622      -3.7619143724441528e-01
    z[2,1,4]  R623      -0.0938776507973671
    z[2,1,4]  R624      -1.9570156931877136e-01
    z[2,1,4]  R625      -1.9608359038829803e-01
    z[2,1,4]  R626      -7.5157403945922852e-02
    z[2,1,4]  R627      -5.9292886406183243e-02
    z[2,1,4]  R628      8.0217522382736206e-01
    z[2,1,4]  R629      8.0292326211929321e-01
    z[2,1,4]  R630      -1.2176158279180527e-01
    z[2,1,4]  R631      3.5552206635475159e-01
    z[2,1,4]  R632      1.0803960263729095e-01
    z[2,1,4]  R633      5.2238047122955322e-01
    z[2,1,4]  R634      3.6268595606088638e-02
    z[2,1,4]  R635      2.2943180799484253e-01
    z[2,1,4]  R636      1.8939814763143659e-03
    z[2,1,4]  R637      -4.4640892744064331e-01
    z[2,1,4]  R638      8.2703399658203125e-01
    z[2,1,4]  R639      6.3625681400299072e-01
    z[2,1,4]  R640      1.1765540577471256e-02
    z[2,1,4]  R641      1.6907185316085815e-01
    z[2,1,4]  R642      -6.3812166452407837e-02
    z[2,1,4]  R643      2.1971662342548370e-01
    z[2,1,4]  R644      6.1889201402664185e-01
    z[2,1,4]  R645      8.9461815357208252e-01
    z[2,1,4]  R646      -4.0109932422637939e-01
    z[2,1,4]  R647      2.2225309908390045e-01
    z[2,1,4]  R648      4.2056638002395630e-01
    z[2,1,4]  R649      6.5803945064544678e-01
    z[2,1,4]  R650      -5.1296311616897583e-01
    z[2,1,4]  R651      -1.9633677601814270e-01
    z[2,1,4]  R652      2.6759955286979675e-01
    z[2,1,4]  R653      0.706939697265625
    z[2,1,4]  R654      8.1082159280776978e-01
    z[2,1,4]  R655      0.498468816280365
    z[2,1,4]  R656      0.851675808429718
    z[2,1,4]  R657      3.3378455042839050e-01
    z[2,1,4]  R658      5.2420613355934620e-03
    z[2,1,4]  R659      -4.4159126281738281e-01
    z[2,1,4]  R660      -5.1426267623901367e-01
    z[2,1,4]  R661      7.2900778055191040e-01
    z[2,1,4]  R662      7.7739447355270386e-02
    z[2,1,4]  R663      1.2438498437404633e-01
    z[2,1,4]  R664      7.5727772712707520e-01
    z[2,1,4]  R665      4.4296798110008240e-01
    z[2,1,4]  R666      3.0513456463813782e-01
    z[2,1,4]  R667      -2.3997746407985687e-01
    z[2,1,4]  R668      7.3908336460590363e-02
    z[2,1,4]  R669      1.9979287683963776e-01
    z[2,1,4]  R670      -2.9989248514175415e-01
    z[2,1,4]  R671      4.0327611565589905e-01
    z[2,1,4]  R672      1.3635893166065216e-01
    z[2,1,4]  R673      -1.1704660207033157e-01
    z[2,1,4]  R674      -1.5881028771400452e-01
    z[2,1,4]  R675      -3.1409943103790283e-01
    z[2,1,4]  R676      -1.0652378201484680e-01
    z[2,1,4]  R677      -8.4657326340675354e-02
    z[2,1,4]  R678      -2.3083089292049408e-01
    z[2,1,4]  R679      -2.1730849146842957e-01
    z[2,1,4]  R680      -1.2386199086904526e-01
    z[2,1,4]  R681      1.3840185105800629e-01
    z[2,1,4]  R682      1.9290681183338165e-01
    z[2,1,4]  R683      -4.6147534251213074e-01
    z[2,1,4]  R684      -1.8422381579875946e-01
    z[2,1,4]  R685      -2.5764617323875427e-01
    z[2,1,4]  R686      1.6537123918533325e-01
    z[2,1,4]  R687      -4.1052049398422241e-01
    z[2,1,4]  R688      -2.0468063652515411e-01
    z[2,1,4]  R689      -7.2437569499015808e-02
    z[2,1,4]  R690      -2.6350542902946472e-01
    z[2,1,4]  R691      1.0137168318033218e-01
    z[2,1,4]  R692      1.3075691461563110e-01
    z[2,1,4]  R693      -1.4864277839660645e-01
    z[2,1,4]  R694      -9.7453128546476364e-04
    z[2,1,4]  R695      -1.4390507340431213e-01
    z[2,1,4]  R696      -1.9986103475093842e-01
    z[2,1,4]  R697      -2.4364335834980011e-01
    z[2,1,4]  R698      -2.0298688113689423e-01
    z[2,1,4]  R699      -1.5748099982738495e-01
    z[2,1,4]  R700      7.0507891476154327e-02
    z[2,1,4]  R701      2.3336309194564819e-01
    z[2,1,4]  R702      4.8944371519610286e-04
    z[2,1,4]  R703      2.4909204244613647e-01
    z[2,1,4]  R704      -5.0483405590057373e-01
    z[2,1,4]  R705      -3.9216119050979614e-01
    z[2,1,4]  R706      -6.7085914313793182e-02
    z[2,1,4]  R707      -3.5326597094535828e-01
    z[2,1,4]  R708      5.3770218044519424e-02
    z[2,1,4]  R709      -2.8380699455738068e-02
    z[2,1,5]  R16       1
    z[2,1,5]  R25       -1
    z[2,1,5]  R596      -1
    z[2,1,5]  R597      1
    z[2,1,5]  R600      1.5868553519248962e-01
    z[2,1,5]  R601      -1.3307699561119080e-01
    z[2,1,5]  R602      4.5616918802261353e-01
    z[2,1,5]  R603      2.0551607012748718e-01
    z[2,1,5]  R604      -1.8133243918418884e-01
    z[2,1,5]  R605      1.0346614569425583e-01
    z[2,1,5]  R606      -1.3034285604953766e-01
    z[2,1,5]  R607      2.8997424244880676e-01
    z[2,1,5]  R608      -1.0508912801742554e-01
    z[2,1,5]  R609      2.8377994894981384e-01
    z[2,1,5]  R610      -3.8235333561897278e-01
    z[2,1,5]  R611      -4.5161581039428711e-01
    z[2,1,5]  R612      -2.6684507727622986e-01
    z[2,1,5]  R613      -2.4281406402587891e-01
    z[2,1,5]  R614      -5.1673788577318192e-02
    z[2,1,5]  R615      2.9943871498107910e-01
    z[2,1,5]  R616      2.3046833276748657e-01
    z[2,1,5]  R617      -2.0786814391613007e-01
    z[2,1,5]  R618      5.2016609907150269e-01
    z[2,1,5]  R619      -3.8530153036117554e-01
    z[2,1,5]  R620      -2.1397693455219269e-01
    z[2,1,5]  R621      -5.0712251663208008e-01
    z[2,1,5]  R622      -4.4329392910003662e-01
    z[2,1,5]  R623      -0.636333703994751
    z[2,1,5]  R624      -2.1468611061573029e-01
    z[2,1,5]  R625      -5.3010553121566772e-01
    z[2,1,5]  R626      -4.5094919204711914e-01
    z[2,1,5]  R627      2.3007138073444366e-01
    z[2,1,5]  R628      -6.2233596108853817e-03
    z[2,1,5]  R629      2.4792146682739258e-01
    z[2,1,5]  R630      -1.4309531450271606e-01
    z[2,1,5]  R631      -3.3593752980232239e-01
    z[2,1,5]  R632      -3.9521834254264832e-01
    z[2,1,5]  R633      3.8066470623016357e-01
    z[2,1,5]  R634      -3.7482002377510071e-01
    z[2,1,5]  R635      -2.3112215101718903e-01
    z[2,1,5]  R636      -1.9764302670955658e-01
    z[2,1,5]  R637      3.4995386004447937e-01
    z[2,1,5]  R638      0.262921005487442
    z[2,1,5]  R639      7.3634006083011627e-02
    z[2,1,5]  R640      -6.6669160127639771e-01
    z[2,1,5]  R641      -4.7642791271209717e-01
    z[2,1,5]  R642      -6.8624633550643921e-01
    z[2,1,5]  R643      5.4921054840087891e-01
    z[2,1,5]  R644      1.7313297092914581e-01
    z[2,1,5]  R645      1.3795202970504761e-01
    z[2,1,5]  R646      -0.472665399312973
    z[2,1,5]  R647      -3.0621027946472168e-01
    z[2,1,5]  R648      4.4452944397926331e-01
    z[2,1,5]  R649      4.3774670362472534e-01
    z[2,1,5]  R650      -1.1383699625730515e-01
    z[2,1,5]  R651      -5.2780801057815552e-01
    z[2,1,5]  R652      5.5221915245056152e-01
    z[2,1,5]  R653      2.0059312880039215e-01
    z[2,1,5]  R654      -1.3569347560405731e-01
    z[2,1,5]  R655      4.4040087610483170e-02
    z[2,1,5]  R656      8.8828159496188164e-03
    z[2,1,5]  R657      -3.1864476203918457e-01
    z[2,1,5]  R658      -4.9679529666900635e-01
    z[2,1,5]  R659      1.2843219563364983e-02
    z[2,1,5]  R660      -1.8174874782562256e-01
    z[2,1,5]  R661      -1.4751896262168884e-01
    z[2,1,5]  R662      -3.6593183875083923e-02
    z[2,1,5]  R663      -8.8280633091926575e-02
    z[2,1,5]  R664      1.9343499839305878e-01
    z[2,1,5]  R665      -3.6710628867149353e-01
    z[2,1,5]  R666      0.607828676700592
    z[2,1,5]  R667      5.4488813877105713e-01
    z[2,1,5]  R668      0.67137610912323
    z[2,1,5]  R669      4.1305643320083618e-01
    z[2,1,5]  R670      -5.6651927297934890e-04
    z[2,1,5]  R671      9.0601295232772827e-02
    z[2,1,5]  R672      -1.7133527994155884e-01
    z[2,1,5]  R673      3.7299975752830505e-01
    z[2,1,5]  R674      4.1182979941368103e-01
    z[2,1,5]  R675      7.7907584607601166e-02
    z[2,1,5]  R676      2.6482158899307251e-01
    z[2,1,5]  R677      1.2379072606563568e-01
    z[2,1,5]  R678      6.4545914530754089e-02
    z[2,1,5]  R679      4.1312563419342041e-01
    z[2,1,5]  R680      -2.0584091544151306e-01
    z[2,1,5]  R681      2.3110151290893555e-01
    z[2,1,5]  R682      -5.2509274333715439e-02
    z[2,1,5]  R683      -3.2188376784324646e-01
    z[2,1,5]  R684      1.3271375000476837e-01
    z[2,1,5]  R685      -2.4289096891880035e-01
    z[2,1,5]  R686      7.5283623300492764e-03
    z[2,1,5]  R687      -1.3356009125709534e-01
    z[2,1,5]  R688      -1.5559597313404083e-01
    z[2,1,5]  R689      -5.3729629516601562e-01
    z[2,1,5]  R690      5.8139726519584656e-02
    z[2,1,5]  R691      1.5446808934211731e-01
    z[2,1,5]  R692      2.1611662581562996e-02
    z[2,1,5]  R693      -0.069243885576725
    z[2,1,5]  R694      1.6166546940803528e-01
    z[2,1,5]  R695      2.5690641254186630e-02
    z[2,1,5]  R696      -4.5451423525810242e-01
    z[2,1,5]  R697      -5.5896449089050293e-01
    z[2,1,5]  R698      -5.0081085413694382e-02
    z[2,1,5]  R699      -8.2788634300231934e-01
    z[2,1,5]  R700      -7.5349416583776474e-03
    z[2,1,5]  R701      -0.040500458329916
    z[2,1,5]  R702      2.0076100528240204e-01
    z[2,1,5]  R703      -0.453075110912323
    z[2,1,5]  R704      -3.6468061804771423e-01
    z[2,1,5]  R705      -4.3863037228584290e-01
    z[2,1,5]  R706      -3.8898301124572754e-01
    z[2,1,5]  R707      -2.8561952710151672e-01
    z[2,1,5]  R708      -3.9827275276184082e-01
    z[2,1,5]  R709      -4.4335415959358215e-01
    z[2,1,6]  R17       1
    z[2,1,6]  R26       -1
    z[2,1,6]  R598      -1
    z[2,1,6]  R599      1
    z[2,1,6]  R600      -5.0029113888740540e-02
    z[2,1,6]  R601      -2.3115381598472595e-01
    z[2,1,6]  R602      -8.9278884232044220e-02
    z[2,1,6]  R603      -1.0339193791151047e-01
    z[2,1,6]  R604      2.1415881812572479e-01
    z[2,1,6]  R605      -4.6624112129211426e-01
    z[2,1,6]  R606      -3.0351492762565613e-01
    z[2,1,6]  R607      -3.8648679852485657e-01
    z[2,1,6]  R608      -1.0934099555015564e-01
    z[2,1,6]  R609      -2.6732918620109558e-01
    z[2,1,6]  R610      5.1108545064926147e-01
    z[2,1,6]  R611      -7.2644329071044922e-01
    z[2,1,6]  R612      -2.0665641129016876e-01
    z[2,1,6]  R613      -5.1648229360580444e-01
    z[2,1,6]  R614      -2.5272938609123230e-01
    z[2,1,6]  R615      1.3192677497863770e-01
    z[2,1,6]  R616      -9.0538740158081055e-02
    z[2,1,6]  R617      4.9501422047615051e-01
    z[2,1,6]  R618      6.2232349067926407e-02
    z[2,1,6]  R619      -2.6739564538002014e-01
    z[2,1,6]  R620      -2.0970292389392853e-01
    z[2,1,6]  R621      1.6176858544349670e-01
    z[2,1,6]  R622      -2.4438551068305969e-01
    z[2,1,6]  R623      -1.0012000799179077e-01
    z[2,1,6]  R624      -3.2189422845840454e-01
    z[2,1,6]  R625      2.2226870059967041e-01
    z[2,1,6]  R626      -0.262014240026474
    z[2,1,6]  R627      -1.6785086691379547e-01
    z[2,1,6]  R628      3.9106106758117676e-01
    z[2,1,6]  R629      3.4687098860740662e-01
    z[2,1,6]  R630      5.4809689521789551e-02
    z[2,1,6]  R631      -6.6034264862537384e-02
    z[2,1,6]  R632      1.3592340052127838e-01
    z[2,1,6]  R633      1.0662989318370819e-01
    z[2,1,6]  R634      4.2565248906612396e-02
    z[2,1,6]  R635      -5.8749181032180786e-01
    z[2,1,6]  R636      3.6409419775009155e-01
    z[2,1,6]  R637      3.9275979995727539e-01
    z[2,1,6]  R638      -7.0015847682952881e-02
    z[2,1,6]  R639      7.8138843178749084e-02
    z[2,1,6]  R640      1.0038229823112488e-01
    z[2,1,6]  R641      5.6645695120096207e-02
    z[2,1,6]  R642      1.4229616522789001e-01
    z[2,1,6]  R643      1.3901987671852112e-01
    z[2,1,6]  R644      0.23238605260849
    z[2,1,6]  R645      2.2056837379932404e-01
    z[2,1,6]  R646      3.3691248297691345e-01
    z[2,1,6]  R647      1.2322041392326355e-01
    z[2,1,6]  R648      1.0096822865307331e-02
    z[2,1,6]  R649      6.1866792384535074e-04
    z[2,1,6]  R650      0.0417693592607975
    z[2,1,6]  R651      5.0848484039306641e-01
    z[2,1,6]  R652      2.5371477007865906e-01
    z[2,1,6]  R653      -7.3690533638000488e-02
    z[2,1,6]  R654      2.1654383838176727e-01
    z[2,1,6]  R655      1.7860314249992371e-01
    z[2,1,6]  R656      -5.0366683863103390e-03
    z[2,1,6]  R657      -2.3265336453914642e-01
    z[2,1,6]  R658      -6.2715482711791992e-01
    z[2,1,6]  R659      0.556354284286499
    z[2,1,6]  R660      2.7617228031158447e-01
    z[2,1,6]  R661      6.0965497046709061e-02
    z[2,1,6]  R662      3.6251747608184814e-01
    z[2,1,6]  R663      2.1518450975418091e-01
    z[2,1,6]  R664      -3.1988853216171265e-01
    z[2,1,6]  R665      -1.4080493152141571e-01
    z[2,1,6]  R666      4.4668808579444885e-01
    z[2,1,6]  R667      2.3696416616439819e-01
    z[2,1,6]  R668      -1.7106316983699799e-01
    z[2,1,6]  R669      2.4901130795478821e-01
    z[2,1,6]  R670      -2.9847362637519836e-01
    z[2,1,6]  R671      1.3364848494529724e-01
    z[2,1,6]  R672      5.7265937328338623e-01
    z[2,1,6]  R673      -3.7704864144325256e-01
    z[2,1,6]  R674      2.1458871662616730e-01
    z[2,1,6]  R675      4.5019667595624924e-03
    z[2,1,6]  R676      -4.5302253961563110e-01
    z[2,1,6]  R677      7.6544538140296936e-02
    z[2,1,6]  R678      -7.2506345808506012e-02
    z[2,1,6]  R679      2.6650076732039452e-02
    z[2,1,6]  R680      -3.7373367697000504e-02
    z[2,1,6]  R681      -1.4916238188743591e-01
    z[2,1,6]  R682      3.4588301181793213e-01
    z[2,1,6]  R683      -1.3130338490009308e-01
    z[2,1,6]  R684      9.6046822145581245e-03
    z[2,1,6]  R685      -2.5644913315773010e-01
    z[2,1,6]  R686      0.368935763835907
    z[2,1,6]  R687      2.1128838881850243e-02
    z[2,1,6]  R688      2.5318679213523865e-01
    z[2,1,6]  R689      2.0364819467067719e-01
    z[2,1,6]  R690      -3.6755308508872986e-02
    z[2,1,6]  R691      1.0403539240360260e-01
    z[2,1,6]  R692      -1.5753178298473358e-01
    z[2,1,6]  R693      3.5538470745086670e-01
    z[2,1,6]  R694      -5.3524747490882874e-02
    z[2,1,6]  R695      -7.6234750449657440e-02
    z[2,1,6]  R696      3.6388018727302551e-01
    z[2,1,6]  R697      2.8143441304564476e-02
    z[2,1,6]  R698      -5.3437568247318268e-02
    z[2,1,6]  R699      -7.5942777097225189e-02
    z[2,1,6]  R700      9.3145325779914856e-02
    z[2,1,6]  R701      -0.239437997341156
    z[2,1,6]  R702      4.5635515451431274e-01
    z[2,1,6]  R703      -2.7225065231323242e-01
    z[2,1,6]  R704      1.1862057447433472e-01
    z[2,1,6]  R705      3.4772762656211853e-01
    z[2,1,6]  R706      3.3204165101051331e-01
    z[2,1,6]  R707      -5.7194292545318604e-02
    z[2,1,6]  R708      -5.5794060230255127e-02
    z[2,1,6]  R709      -3.5684242844581604e-02
    z[1,5,0]  R11       -1
    z[1,5,0]  R47       1
    z[1,5,0]  R710      -1
    z[1,5,0]  R711      1
    z[1,5,0]  R724      2.7962762117385864e-01
    z[1,5,0]  R725      2.0304465293884277e-01
    z[1,5,0]  R726      4.8196381330490112e-01
    z[1,5,0]  R727      4.9614846706390381e-01
    z[1,5,0]  R728      1.2865640223026276e-01
    z[1,5,0]  R729      -6.1407768726348877e-01
    z[1,5,0]  R730      -3.2301995903253555e-02
    z[1,5,0]  R731      -6.5264117717742920e-01
    z[1,5,0]  R732      5.8207523822784424e-01
    z[1,5,0]  R733      -3.2870405912399292e-01
    z[1,5,0]  R734      -3.1641387939453125e-01
    z[1,5,0]  R735      -4.2277911305427551e-01
    z[1,5,0]  R736      -1.0244952887296677e-01
    z[1,5,0]  R737      -1.2051765620708466e-01
    z[1,5,0]  R738      -4.8893335461616516e-01
    z[1,5,0]  R739      -1.8897777795791626e-01
    z[1,5,0]  R740      1.3949221372604370e-01
    z[1,5,0]  R741      -2.2030605375766754e-01
    z[1,5,0]  R742      -2.1836702525615692e-01
    z[1,5,0]  R743      2.3509931564331055e-01
    z[1,5,0]  R744      -7.6377198100090027e-02
    z[1,5,0]  R745      3.1136092543601990e-01
    z[1,5,0]  R746      3.0841851234436035e-01
    z[1,5,0]  R747      2.2287490963935852e-01
    z[1,5,0]  R748      -5.3050625324249268e-01
    z[1,5,0]  R749      -1.4284588396549225e-01
    z[1,5,0]  R750      2.0959232747554779e-01
    z[1,5,0]  R751      2.6491835713386536e-01
    z[1,5,0]  R752      4.4635945558547974e-01
    z[1,5,0]  R753      8.6355626583099365e-02
    z[1,5,0]  R754      2.9921406507492065e-01
    z[1,5,0]  R755      -3.4507188200950623e-01
    z[1,5,0]  R756      -6.5469577908515930e-02
    z[1,5,0]  R757      8.4681533277034760e-02
    z[1,5,0]  R758      -4.7394716739654541e-01
    z[1,5,0]  R759      -0.486203134059906
    z[1,5,0]  R760      -5.0084066390991211e-01
    z[1,5,0]  R761      -6.6228991746902466e-01
    z[1,5,0]  R762      -6.7427629232406616e-01
    z[1,5,0]  R763      -7.0876157283782959e-01
    z[1,5,0]  R764      4.8252713680267334e-01
    z[1,5,0]  R765      3.9966791868209839e-01
    z[1,5,0]  R766      0.402807354927063
    z[1,5,0]  R767      0.506476879119873
    z[1,5,0]  R768      3.8504651188850403e-01
    z[1,5,0]  R769      8.1525808572769165e-01
    z[1,5,0]  R770      1.3341283798217773e-01
    z[1,5,0]  R771      7.1224117279052734e-01
    z[1,5,0]  R772      1.9481061398983002e-01
    z[1,5,0]  R773      -1.5624713897705078e-01
    z[1,5,0]  R774      1.8087498843669891e-02
    z[1,5,0]  R775      -2.4753254652023315e-01
    z[1,5,0]  R776      -1.8546250462532043e-01
    z[1,5,0]  R777      -5.6664252281188965e-01
    z[1,5,0]  R778      -4.5358520746231079e-01
    z[1,5,0]  R779      -3.3044105768203735e-01
    z[1,5,0]  R780      -7.2640764713287354e-01
    z[1,5,0]  R781      -0.276757150888443
    z[1,5,0]  R782      -3.7866771221160889e-01
    z[1,5,0]  R783      -5.9387886524200439e-01
    z[1,5,0]  R784      -2.3243264853954315e-01
    z[1,5,0]  R785      -4.6389874815940857e-01
    z[1,5,0]  R786      -5.6616473197937012e-01
    z[1,5,0]  R787      0.01770637370646
    z[1,5,0]  R788      -0.0440821535885334
    z[1,5,0]  R789      -1.9195194542407990e-01
    z[1,5,0]  R790      1.2960492074489594e-01
    z[1,5,0]  R791      1.6947485506534576e-01
    z[1,5,0]  R792      1.3789768517017365e-01
    z[1,5,0]  R793      -2.1324107050895691e-01
    z[1,5,0]  R794      5.0671076774597168e-01
    z[1,5,0]  R795      -1.9885918498039246e-01
    z[1,5,0]  R796      -3.0448371171951294e-01
    z[1,5,0]  R797      -5.0142383575439453e-01
    z[1,5,0]  R798      -5.4543703794479370e-01
    z[1,5,0]  R799      -4.7971585392951965e-01
    z[1,5,1]  R12       -1
    z[1,5,1]  R48       1
    z[1,5,1]  R712      -1
    z[1,5,1]  R713      1
    z[1,5,1]  R724      -2.1921348571777344e-01
    z[1,5,1]  R725      -7.4452593922615051e-02
    z[1,5,1]  R726      -5.0826704502105713e-01
    z[1,5,1]  R727      -3.2922571897506714e-01
    z[1,5,1]  R728      8.1142103672027588e-01
    z[1,5,1]  R729      6.1842817068099976e-01
    z[1,5,1]  R730      6.8973690271377563e-01
    z[1,5,1]  R731      5.9134668111801147e-01
    z[1,5,1]  R732      6.1284792423248291e-01
    z[1,5,1]  R733      0.573715090751648
    z[1,5,1]  R734      9.0683412551879883e-01
    z[1,5,1]  R735      8.3137172460556030e-01
    z[1,5,1]  R736      8.0535823106765747e-01
    z[1,5,1]  R737      -3.2495595514774323e-02
    z[1,5,1]  R738      7.1907246112823486e-01
    z[1,5,1]  R739      -4.5671343803405762e-02
    z[1,5,1]  R740      8.2761889696121216e-01
    z[1,5,1]  R741      6.8467676639556885e-01
    z[1,5,1]  R742      -3.5720226168632507e-01
    z[1,5,1]  R743      2.8877329826354980e-01
    z[1,5,1]  R744      9.3616098165512085e-01
    z[1,5,1]  R745      8.7562519311904907e-01
    z[1,5,1]  R746      9.1728532314300537e-01
    z[1,5,1]  R747      8.2997298240661621e-01
    z[1,5,1]  R748      7.4703454971313477e-01
    z[1,5,1]  R749      8.3241719007492065e-01
    z[1,5,1]  R750      7.4476099014282227e-01
    z[1,5,1]  R751      7.3139709234237671e-01
    z[1,5,1]  R752      7.7011620998382568e-01
    z[1,5,1]  R753      2.8373071551322937e-01
    z[1,5,1]  R754      9.1313737630844116e-01
    z[1,5,1]  R755      8.1033390760421753e-01
    z[1,5,1]  R756      8.0890297889709473e-01
    z[1,5,1]  R757      0.686237633228302
    z[1,5,1]  R758      3.3341646194458008e-01
    z[1,5,1]  R759      2.3928360641002655e-01
    z[1,5,1]  R760      1.6235956549644470e-01
    z[1,5,1]  R761      -3.7058692425489426e-02
    z[1,5,1]  R762      -1.9127799198031425e-02
    z[1,5,1]  R763      1.4989666640758514e-01
    z[1,5,1]  R764      -2.9579332470893860e-01
    z[1,5,1]  R765      -3.3140763640403748e-01
    z[1,5,1]  R766      3.6768081784248352e-01
    z[1,5,1]  R767      -3.8896843791007996e-02
    z[1,5,1]  R768      -3.9393520355224609e-01
    z[1,5,1]  R769      -0.417843759059906
    z[1,5,1]  R770      2.1209548413753510e-01
    z[1,5,1]  R771      -5.1100033521652222e-01
    z[1,5,1]  R772      8.0563133955001831e-01
    z[1,5,1]  R773      8.0624979734420776e-01
    z[1,5,1]  R774      5.9764266014099121e-01
    z[1,5,1]  R775      4.2195639014244080e-01
    z[1,5,1]  R776      3.9931362867355347e-01
    z[1,5,1]  R777      4.5708245038986206e-01
    z[1,5,1]  R778      4.1171273589134216e-01
    z[1,5,1]  R779      4.4868674874305725e-01
    z[1,5,1]  R780      4.4769674539566040e-01
    z[1,5,1]  R781      -4.8848456144332886e-01
    z[1,5,1]  R782      1.7885313928127289e-01
    z[1,5,1]  R783      -7.0007240772247314e-01
    z[1,5,1]  R784      7.5460141897201538e-01
    z[1,5,1]  R785      7.0336228609085083e-01
    z[1,5,1]  R786      7.3183369636535645e-01
    z[1,5,1]  R787      6.8371903896331787e-01
    z[1,5,1]  R788      7.2825807332992554e-01
    z[1,5,1]  R789      6.1534881591796875e-01
    z[1,5,1]  R790      5.5842143297195435e-01
    z[1,5,1]  R791      6.6320836544036865e-01
    z[1,5,1]  R792      5.2656018733978271e-01
    z[1,5,1]  R793      0.50145024061203
    z[1,5,1]  R794      0.673224151134491
    z[1,5,1]  R795      0.654941976070404
    z[1,5,1]  R796      -6.9678771495819092e-01
    z[1,5,1]  R797      -6.7250436544418335e-01
    z[1,5,1]  R798      -5.7821273803710938e-01
    z[1,5,1]  R799      -6.0361069440841675e-01
    z[1,5,2]  R13       -1
    z[1,5,2]  R49       1
    z[1,5,2]  R714      -1
    z[1,5,2]  R715      1
    z[1,5,2]  R724      5.3371560573577881e-01
    z[1,5,2]  R725      6.8362191319465637e-02
    z[1,5,2]  R726      1.8323728442192078e-01
    z[1,5,2]  R727      -2.4813309311866760e-01
    z[1,5,2]  R728      2.8203356266021729e-01
    z[1,5,2]  R729      3.6106950044631958e-01
    z[1,5,2]  R730      -4.1474151611328125e-01
    z[1,5,2]  R731      3.9721819758415222e-01
    z[1,5,2]  R732      -1.3042224943637848e-01
    z[1,5,2]  R733      -5.7017207145690918e-01
    z[1,5,2]  R734      1.1580395698547363e-01
    z[1,5,2]  R735      1.8631696701049805e-01
    z[1,5,2]  R736      -2.3490869998931885e-01
    z[1,5,2]  R737      6.1722569167613983e-02
    z[1,5,2]  R738      -4.1013407707214355e-01
    z[1,5,2]  R739      -4.0237170457839966e-01
    z[1,5,2]  R740      1.8765635788440704e-01
    z[1,5,2]  R741      -0.515556275844574
    z[1,5,2]  R742      -1.5989071130752563e-01
    z[1,5,2]  R743      -1.3489606976509094e-01
    z[1,5,2]  R744      -3.3976398408412933e-02
    z[1,5,2]  R745      -2.9960241913795471e-01
    z[1,5,2]  R746      -1.3145267963409424e-01
    z[1,5,2]  R747      -3.2863074541091919e-01
    z[1,5,2]  R748      -2.4547062814235687e-01
    z[1,5,2]  R749      4.0565276145935059e-01
    z[1,5,2]  R750      1.3377526402473450e-01
    z[1,5,2]  R751      7.7422477304935455e-02
    z[1,5,2]  R752      1.4425605535507202e-01
    z[1,5,2]  R753      1.4587850868701935e-01
    z[1,5,2]  R754      2.3768074810504913e-01
    z[1,5,2]  R755      -3.1970882415771484e-01
    z[1,5,2]  R756      2.7199709415435791e-01
    z[1,5,2]  R757      -4.0316683053970337e-01
    z[1,5,2]  R758      -4.2920511960983276e-01
    z[1,5,2]  R759      -4.8564866185188293e-01
    z[1,5,2]  R760      -5.3797960281372070e-01
    z[1,5,2]  R761      -5.8077478408813477e-01
    z[1,5,2]  R762      -6.0098898410797119e-01
    z[1,5,2]  R763      -1.6859672963619232e-01
    z[1,5,2]  R764      6.5029317140579224e-01
    z[1,5,2]  R765      2.3039247095584869e-01
    z[1,5,2]  R766      5.5591195821762085e-01
    z[1,5,2]  R767      3.4478139877319336e-01
    z[1,5,2]  R768      4.7812196612358093e-01
    z[1,5,2]  R769      3.3615015447139740e-02
    z[1,5,2]  R770      5.6970185041427612e-01
    z[1,5,2]  R771      -1.1947441101074219e-01
    z[1,5,2]  R772      -3.0314254760742188e-01
    z[1,5,2]  R773      -4.1481822729110718e-02
    z[1,5,2]  R774      1.9685681164264679e-01
    z[1,5,2]  R775      -2.0552419126033783e-01
    z[1,5,2]  R776      -1.6960366070270538e-01
    z[1,5,2]  R777      -2.7856704592704773e-01
    z[1,5,2]  R778      -2.1651954948902130e-01
    z[1,5,2]  R779      3.3400931954383850e-01
    z[1,5,2]  R780      2.2183121740818024e-01
    z[1,5,2]  R781      -4.7147122025489807e-01
    z[1,5,2]  R782      -3.6279717087745667e-01
    z[1,5,2]  R783      -1.6546821594238281e-01
    z[1,5,2]  R784      -2.2869546711444855e-01
    z[1,5,2]  R785      6.2293823808431625e-02
    z[1,5,2]  R786      1.7335507273674011e-01
    z[1,5,2]  R787      4.2720317840576172e-01
    z[1,5,2]  R788      -2.0526179671287537e-01
    z[1,5,2]  R789      2.8183031082153320e-01
    z[1,5,2]  R790      -2.2353968024253845e-01
    z[1,5,2]  R791      3.6107987165451050e-01
    z[1,5,2]  R792      -1.0032659024000168e-01
    z[1,5,2]  R793      -2.8439259529113770e-01
    z[1,5,2]  R794      -5.0510197877883911e-01
    z[1,5,2]  R795      -2.8678017854690552e-01
    z[1,5,2]  R796      1.0988084971904755e-01
    z[1,5,2]  R797      -1.1029504239559174e-01
    z[1,5,2]  R798      1.6776882112026215e-01
    z[1,5,2]  R799      2.3622474074363708e-01
    z[1,5,3]  R14       -1
    z[1,5,3]  R50       1
    z[1,5,3]  R716      -1
    z[1,5,3]  R717      1
    z[1,5,3]  R724      6.4021801948547363e-01
    z[1,5,3]  R725      8.7169617414474487e-01
    z[1,5,3]  R726      3.1608742475509644e-01
    z[1,5,3]  R727      5.3747820854187012e-01
    z[1,5,3]  R728      6.8027116358280182e-02
    z[1,5,3]  R729      0.0730455219745636
    z[1,5,3]  R730      -2.5397205352783203e-01
    z[1,5,3]  R731      -1.9554081559181213e-01
    z[1,5,3]  R732      -4.5375058054924011e-01
    z[1,5,3]  R733      1.3821160793304443e-01
    z[1,5,3]  R734      0.0708138570189476
    z[1,5,3]  R735      -2.3503344506025314e-02
    z[1,5,3]  R736      -3.5512641072273254e-01
    z[1,5,3]  R737      -8.0423909425735474e-01
    z[1,5,3]  R738      -1.5500102937221527e-01
    z[1,5,3]  R739      -7.8048378229141235e-01
    z[1,5,3]  R740      -3.1121698021888733e-01
    z[1,5,3]  R741      1.7341528832912445e-01
    z[1,5,3]  R742      -8.1789320707321167e-01
    z[1,5,3]  R743      -7.1255475282669067e-01
    z[1,5,3]  R744      -2.0603038370609283e-01
    z[1,5,3]  R745      4.0164690464735031e-02
    z[1,5,3]  R746      -0.0616854727268219
    z[1,5,3]  R747      1.6903959214687347e-02
    z[1,5,3]  R748      -2.6691758632659912e-01
    z[1,5,3]  R749      -3.0812656879425049e-01
    z[1,5,3]  R750      -0.0676007941365242
    z[1,5,3]  R751      1.2762063741683960e-01
    z[1,5,3]  R752      -3.7457591295242310e-01
    z[1,5,3]  R753      -4.1808575391769409e-01
    z[1,5,3]  R754      -8.0341942608356476e-02
    z[1,5,3]  R755      9.2959113419055939e-02
    z[1,5,3]  R756      -1.3726647198200226e-01
    z[1,5,3]  R757      -1.3386221230030060e-01
    z[1,5,3]  R758      -2.7941063046455383e-01
    z[1,5,3]  R759      -5.8254975825548172e-02
    z[1,5,3]  R760      -4.0904280543327332e-01
    z[1,5,3]  R761      -1.1424877494573593e-01
    z[1,5,3]  R762      -1.3846483826637268e-01
    z[1,5,3]  R763      -4.9811783432960510e-01
    z[1,5,3]  R764      3.3118334412574768e-01
    z[1,5,3]  R765      5.2328133583068848e-01
    z[1,5,3]  R766      6.3107900321483612e-02
    z[1,5,3]  R767      -3.7122715730220079e-03
    z[1,5,3]  R768      1.1415149271488190e-01
    z[1,5,3]  R769      2.2451011836528778e-01
    z[1,5,3]  R770      3.1727319955825806e-01
    z[1,5,3]  R771      -1.0649629682302475e-01
    z[1,5,3]  R772      1.8137918412685394e-01
    z[1,5,3]  R773      4.3290373682975769e-01
    z[1,5,3]  R774      -3.4623432159423828e-01
    z[1,5,3]  R775      -0.375354528427124
    z[1,5,3]  R776      -6.7517482675611973e-03
    z[1,5,3]  R777      -3.3685654401779175e-01
    z[1,5,3]  R778      -4.8288854956626892e-01
    z[1,5,3]  R779      -2.4150630831718445e-01
    z[1,5,3]  R780      1.5619641542434692e-01
    z[1,5,3]  R781      -1.4916208386421204e-01
    z[1,5,3]  R782      -2.1368719637393951e-01
    z[1,5,3]  R783      -2.2419057786464691e-01
    z[1,5,3]  R784      -4.1027626395225525e-01
    z[1,5,3]  R785      3.5584408789873123e-02
    z[1,5,3]  R786      -2.5215500593185425e-01
    z[1,5,3]  R787      -0.0723184123635292
    z[1,5,3]  R788      -4.9420168995857239e-01
    z[1,5,3]  R789      2.2640155255794525e-01
    z[1,5,3]  R790      -1.4711397886276245e-01
    z[1,5,3]  R791      4.0763825178146362e-01
    z[1,5,3]  R792      2.9277700185775757e-01
    z[1,5,3]  R793      5.6977385282516479e-01
    z[1,5,3]  R794      -1.2279611080884933e-02
    z[1,5,3]  R795      -3.3612366765737534e-02
    z[1,5,3]  R796      3.4877711534500122e-01
    z[1,5,3]  R797      -3.0873927474021912e-01
    z[1,5,3]  R798      -4.2799431085586548e-01
    z[1,5,3]  R799      -5.2732646465301514e-01
    z[1,5,4]  R15       -1
    z[1,5,4]  R51       1
    z[1,5,4]  R718      -1
    z[1,5,4]  R719      1
    z[1,5,4]  R724      -2.9989248514175415e-01
    z[1,5,4]  R725      4.0327611565589905e-01
    z[1,5,4]  R726      1.3635893166065216e-01
    z[1,5,4]  R727      -1.1704660207033157e-01
    z[1,5,4]  R728      -1.5881028771400452e-01
    z[1,5,4]  R729      -3.1409943103790283e-01
    z[1,5,4]  R730      -1.0652378201484680e-01
    z[1,5,4]  R731      -8.4657326340675354e-02
    z[1,5,4]  R732      -2.3083089292049408e-01
    z[1,5,4]  R733      -2.1730849146842957e-01
    z[1,5,4]  R734      -1.2386199086904526e-01
    z[1,5,4]  R735      1.3840185105800629e-01
    z[1,5,4]  R736      1.9290681183338165e-01
    z[1,5,4]  R737      -4.6147534251213074e-01
    z[1,5,4]  R738      -1.8422381579875946e-01
    z[1,5,4]  R739      -2.5764617323875427e-01
    z[1,5,4]  R740      1.6537123918533325e-01
    z[1,5,4]  R741      -4.1052049398422241e-01
    z[1,5,4]  R742      -2.0468063652515411e-01
    z[1,5,4]  R743      -7.2437569499015808e-02
    z[1,5,4]  R744      -2.6350542902946472e-01
    z[1,5,4]  R745      1.0137168318033218e-01
    z[1,5,4]  R746      1.3075691461563110e-01
    z[1,5,4]  R747      -1.4864277839660645e-01
    z[1,5,4]  R748      -9.7453128546476364e-04
    z[1,5,4]  R749      -1.4390507340431213e-01
    z[1,5,4]  R750      -1.9986103475093842e-01
    z[1,5,4]  R751      -2.4364335834980011e-01
    z[1,5,4]  R752      -2.0298688113689423e-01
    z[1,5,4]  R753      -1.5748099982738495e-01
    z[1,5,4]  R754      7.0507891476154327e-02
    z[1,5,4]  R755      2.3336309194564819e-01
    z[1,5,4]  R756      4.8944371519610286e-04
    z[1,5,4]  R757      2.4909204244613647e-01
    z[1,5,4]  R758      -5.0483405590057373e-01
    z[1,5,4]  R759      -3.9216119050979614e-01
    z[1,5,4]  R760      -6.7085914313793182e-02
    z[1,5,4]  R761      -3.5326597094535828e-01
    z[1,5,4]  R762      5.3770218044519424e-02
    z[1,5,4]  R763      -2.8380699455738068e-02
    z[1,5,4]  R764      9.4280634075403214e-03
    z[1,5,4]  R765      2.9374551773071289e-01
    z[1,5,4]  R766      1.9206385314464569e-01
    z[1,5,4]  R767      5.6137222051620483e-01
    z[1,5,4]  R768      6.7019534111022949e-01
    z[1,5,4]  R769      -2.3307195305824280e-01
    z[1,5,4]  R770      6.1939394474029541e-01
    z[1,5,4]  R771      2.3664748668670654e-01
    z[1,5,4]  R772      3.9568841457366943e-01
    z[1,5,4]  R773      1.7387686669826508e-01
    z[1,5,4]  R774      -4.8594778776168823e-01
    z[1,5,4]  R775      -7.3324447870254517e-01
    z[1,5,4]  R776      -4.2227414250373840e-01
    z[1,5,4]  R777      -4.9721163511276245e-01
    z[1,5,4]  R778      -2.3260879516601562e-01
    z[1,5,4]  R779      1.9123084843158722e-01
    z[1,5,4]  R780      -3.1898370385169983e-01
    z[1,5,4]  R781      4.3852204084396362e-01
    z[1,5,4]  R782      6.9909161329269409e-01
    z[1,5,4]  R783      6.7884959280490875e-02
    z[1,5,4]  R784      -3.6485812067985535e-01
    z[1,5,4]  R785      -5.1581335067749023e-01
    z[1,5,4]  R786      1.2401795387268066e-01
    z[1,5,4]  R787      2.2467546164989471e-01
    z[1,5,4]  R788      2.3399452865123749e-01
    z[1,5,4]  R789      -3.7361967563629150e-01
    z[1,5,4]  R790      -5.3972554206848145e-01
    z[1,5,4]  R791      -3.5437917709350586e-01
    z[1,5,4]  R792      -7.3020040988922119e-01
    z[1,5,4]  R793      1.8432773649692535e-02
    z[1,5,4]  R794      -1.6219811141490936e-01
    z[1,5,4]  R795      -3.4186261892318726e-01
    z[1,5,4]  R796      -1.4937274158000946e-01
    z[1,5,4]  R797      -1.9341942667961121e-01
    z[1,5,4]  R798      2.0830312743782997e-02
    z[1,5,4]  R799      -9.0662986040115356e-02
    z[1,5,5]  R16       -1
    z[1,5,5]  R52       1
    z[1,5,5]  R720      -1
    z[1,5,5]  R721      1
    z[1,5,5]  R724      -5.6651927297934890e-04
    z[1,5,5]  R725      9.0601295232772827e-02
    z[1,5,5]  R726      -1.7133527994155884e-01
    z[1,5,5]  R727      3.7299975752830505e-01
    z[1,5,5]  R728      4.1182979941368103e-01
    z[1,5,5]  R729      7.7907584607601166e-02
    z[1,5,5]  R730      2.6482158899307251e-01
    z[1,5,5]  R731      1.2379072606563568e-01
    z[1,5,5]  R732      6.4545914530754089e-02
    z[1,5,5]  R733      4.1312563419342041e-01
    z[1,5,5]  R734      -2.0584091544151306e-01
    z[1,5,5]  R735      2.3110151290893555e-01
    z[1,5,5]  R736      -5.2509274333715439e-02
    z[1,5,5]  R737      -3.2188376784324646e-01
    z[1,5,5]  R738      1.3271375000476837e-01
    z[1,5,5]  R739      -2.4289096891880035e-01
    z[1,5,5]  R740      7.5283623300492764e-03
    z[1,5,5]  R741      -1.3356009125709534e-01
    z[1,5,5]  R742      -1.5559597313404083e-01
    z[1,5,5]  R743      -5.3729629516601562e-01
    z[1,5,5]  R744      5.8139726519584656e-02
    z[1,5,5]  R745      1.5446808934211731e-01
    z[1,5,5]  R746      2.1611662581562996e-02
    z[1,5,5]  R747      -0.069243885576725
    z[1,5,5]  R748      1.6166546940803528e-01
    z[1,5,5]  R749      2.5690641254186630e-02
    z[1,5,5]  R750      -4.5451423525810242e-01
    z[1,5,5]  R751      -5.5896449089050293e-01
    z[1,5,5]  R752      -5.0081085413694382e-02
    z[1,5,5]  R753      -8.2788634300231934e-01
    z[1,5,5]  R754      -7.5349416583776474e-03
    z[1,5,5]  R755      -0.040500458329916
    z[1,5,5]  R756      2.0076100528240204e-01
    z[1,5,5]  R757      -0.453075110912323
    z[1,5,5]  R758      -3.6468061804771423e-01
    z[1,5,5]  R759      -4.3863037228584290e-01
    z[1,5,5]  R760      -3.8898301124572754e-01
    z[1,5,5]  R761      -2.8561952710151672e-01
    z[1,5,5]  R762      -3.9827275276184082e-01
    z[1,5,5]  R763      -4.4335415959358215e-01
    z[1,5,5]  R764      3.8242614269256592e-01
    z[1,5,5]  R765      5.0597274303436279e-01
    z[1,5,5]  R766      5.9371012449264526e-01
    z[1,5,5]  R767      5.5435377359390259e-01
    z[1,5,5]  R768      -3.4342953003942966e-03
    z[1,5,5]  R769      9.8959669470787048e-02
    z[1,5,5]  R770      2.9374006390571594e-01
    z[1,5,5]  R771      3.2743221521377563e-01
    z[1,5,5]  R772      1.5588788688182831e-01
    z[1,5,5]  R773      3.2585912942886353e-01
    z[1,5,5]  R774      -3.5222217440605164e-01
    z[1,5,5]  R775      -7.2058849036693573e-02
    z[1,5,5]  R776      -7.6254093647003174e-01
    z[1,5,5]  R777      -1.7625318467617035e-01
    z[1,5,5]  R778      -5.0293862819671631e-01
    z[1,5,5]  R779      -6.7311418056488037e-01
    z[1,5,5]  R780      -2.0385213196277618e-01
    z[1,5,5]  R781      -1.0849576443433762e-01
    z[1,5,5]  R782      -3.8317084312438965e-01
    z[1,5,5]  R783      2.3181456327438354e-01
    z[1,5,5]  R784      1.2535206973552704e-01
    z[1,5,5]  R785      -7.0958539843559265e-02
    z[1,5,5]  R786      -1.7830401659011841e-01
    z[1,5,5]  R787      -5.1603770256042480e-01
    z[1,5,5]  R788      -2.8873044252395630e-01
    z[1,5,5]  R789      -5.5137360095977783e-01
    z[1,5,5]  R790      1.7858842015266418e-01
    z[1,5,5]  R791      -3.3059626817703247e-01
    z[1,5,5]  R792      -2.7245754003524780e-01
    z[1,5,5]  R793      -4.0308335423469543e-01
    z[1,5,5]  R794      4.5589298009872437e-02
    z[1,5,5]  R795      -5.7330334186553955e-01
    z[1,5,5]  R796      -5.0638669729232788e-01
    z[1,5,5]  R797      3.8519567251205444e-01
    z[1,5,5]  R798      3.9548525214195251e-01
    z[1,5,5]  R799      2.0005165040493011e-01
    z[1,5,6]  R17       -1
    z[1,5,6]  R53       1
    z[1,5,6]  R722      -1
    z[1,5,6]  R723      1
    z[1,5,6]  R724      -2.9847362637519836e-01
    z[1,5,6]  R725      1.3364848494529724e-01
    z[1,5,6]  R726      5.7265937328338623e-01
    z[1,5,6]  R727      -3.7704864144325256e-01
    z[1,5,6]  R728      2.1458871662616730e-01
    z[1,5,6]  R729      4.5019667595624924e-03
    z[1,5,6]  R730      -4.5302253961563110e-01
    z[1,5,6]  R731      7.6544538140296936e-02
    z[1,5,6]  R732      -7.2506345808506012e-02
    z[1,5,6]  R733      2.6650076732039452e-02
    z[1,5,6]  R734      -3.7373367697000504e-02
    z[1,5,6]  R735      -1.4916238188743591e-01
    z[1,5,6]  R736      3.4588301181793213e-01
    z[1,5,6]  R737      -1.3130338490009308e-01
    z[1,5,6]  R738      9.6046822145581245e-03
    z[1,5,6]  R739      -2.5644913315773010e-01
    z[1,5,6]  R740      0.368935763835907
    z[1,5,6]  R741      2.1128838881850243e-02
    z[1,5,6]  R742      2.5318679213523865e-01
    z[1,5,6]  R743      2.0364819467067719e-01
    z[1,5,6]  R744      -3.6755308508872986e-02
    z[1,5,6]  R745      1.0403539240360260e-01
    z[1,5,6]  R746      -1.5753178298473358e-01
    z[1,5,6]  R747      3.5538470745086670e-01
    z[1,5,6]  R748      -5.3524747490882874e-02
    z[1,5,6]  R749      -7.6234750449657440e-02
    z[1,5,6]  R750      3.6388018727302551e-01
    z[1,5,6]  R751      2.8143441304564476e-02
    z[1,5,6]  R752      -5.3437568247318268e-02
    z[1,5,6]  R753      -7.5942777097225189e-02
    z[1,5,6]  R754      9.3145325779914856e-02
    z[1,5,6]  R755      -0.239437997341156
    z[1,5,6]  R756      4.5635515451431274e-01
    z[1,5,6]  R757      -2.7225065231323242e-01
    z[1,5,6]  R758      1.1862057447433472e-01
    z[1,5,6]  R759      3.4772762656211853e-01
    z[1,5,6]  R760      3.3204165101051331e-01
    z[1,5,6]  R761      -5.7194292545318604e-02
    z[1,5,6]  R762      -5.5794060230255127e-02
    z[1,5,6]  R763      -3.5684242844581604e-02
    z[1,5,6]  R764      2.7778422459959984e-02
    z[1,5,6]  R765      -2.4745856225490570e-01
    z[1,5,6]  R766      1.2494678609073162e-02
    z[1,5,6]  R767      2.5164343416690826e-02
    z[1,5,6]  R768      7.5825154781341553e-02
    z[1,5,6]  R769      2.1239224076271057e-01
    z[1,5,6]  R770      -2.0509015023708344e-01
    z[1,5,6]  R771      2.0678873360157013e-01
    z[1,5,6]  R772      -8.5689671337604523e-02
    z[1,5,6]  R773      2.1212226711213589e-03
    z[1,5,6]  R774      3.5165277123451233e-01
    z[1,5,6]  R775      1.8630404770374298e-01
    z[1,5,6]  R776      1.3250321149826050e-01
    z[1,5,6]  R777      2.5208277627825737e-02
    z[1,5,6]  R778      1.9400231540203094e-01
    z[1,5,6]  R779      1.7305904626846313e-01
    z[1,5,6]  R780      -0.234492689371109
    z[1,5,6]  R781      -4.8598459362983704e-01
    z[1,5,6]  R782      -1.0857817530632019e-01
    z[1,5,6]  R783      -1.4566726982593536e-01
    z[1,5,6]  R784      8.4196001291275024e-02
    z[1,5,6]  R785      -1.1761871725320816e-01
    z[1,5,6]  R786      -5.5409427732229233e-02
    z[1,5,6]  R787      1.6645808517932892e-01
    z[1,5,6]  R788      2.0787145197391510e-01
    z[1,5,6]  R789      1.0104341804981232e-01
    z[1,5,6]  R790      5.2588790655136108e-01
    z[1,5,6]  R791      -2.5872574187815189e-03
    z[1,5,6]  R792      2.2560091689229012e-02
    z[1,5,6]  R793      -3.6706754565238953e-01
    z[1,5,6]  R794      7.9674273729324341e-02
    z[1,5,6]  R795      5.0857108086347580e-02
    z[1,5,6]  R796      -9.6527636051177979e-02
    z[1,5,6]  R797      -5.5138994008302689e-02
    z[1,5,6]  R798      -0.000664629100356251
    z[1,5,6]  R799      1.5300613641738892e-01
    z[5,1,0]  R11       1
    z[5,1,0]  R47       -1
    z[5,1,0]  R800      -1
    z[5,1,0]  R801      1
    z[5,1,0]  R814      4.8252713680267334e-01
    z[5,1,0]  R815      3.9966791868209839e-01
    z[5,1,0]  R816      0.402807354927063
    z[5,1,0]  R817      0.506476879119873
    z[5,1,0]  R818      3.8504651188850403e-01
    z[5,1,0]  R819      8.1525808572769165e-01
    z[5,1,0]  R820      1.3341283798217773e-01
    z[5,1,0]  R821      7.1224117279052734e-01
    z[5,1,0]  R822      1.9481061398983002e-01
    z[5,1,0]  R823      -1.5624713897705078e-01
    z[5,1,0]  R824      1.8087498843669891e-02
    z[5,1,0]  R825      -2.4753254652023315e-01
    z[5,1,0]  R826      -1.8546250462532043e-01
    z[5,1,0]  R827      -5.6664252281188965e-01
    z[5,1,0]  R828      -4.5358520746231079e-01
    z[5,1,0]  R829      -3.3044105768203735e-01
    z[5,1,0]  R830      -7.2640764713287354e-01
    z[5,1,0]  R831      -0.276757150888443
    z[5,1,0]  R832      -3.7866771221160889e-01
    z[5,1,0]  R833      -5.9387886524200439e-01
    z[5,1,0]  R834      -2.3243264853954315e-01
    z[5,1,0]  R835      -4.6389874815940857e-01
    z[5,1,0]  R836      -5.6616473197937012e-01
    z[5,1,0]  R837      0.01770637370646
    z[5,1,0]  R838      -0.0440821535885334
    z[5,1,0]  R839      -1.9195194542407990e-01
    z[5,1,0]  R840      1.2960492074489594e-01
    z[5,1,0]  R841      1.6947485506534576e-01
    z[5,1,0]  R842      1.3789768517017365e-01
    z[5,1,0]  R843      -2.1324107050895691e-01
    z[5,1,0]  R844      5.0671076774597168e-01
    z[5,1,0]  R845      -1.9885918498039246e-01
    z[5,1,0]  R846      -3.0448371171951294e-01
    z[5,1,0]  R847      -5.0142383575439453e-01
    z[5,1,0]  R848      -5.4543703794479370e-01
    z[5,1,0]  R849      -4.7971585392951965e-01
    z[5,1,0]  R850      2.7962762117385864e-01
    z[5,1,0]  R851      2.0304465293884277e-01
    z[5,1,0]  R852      4.8196381330490112e-01
    z[5,1,0]  R853      4.9614846706390381e-01
    z[5,1,0]  R854      1.2865640223026276e-01
    z[5,1,0]  R855      -6.1407768726348877e-01
    z[5,1,0]  R856      -3.2301995903253555e-02
    z[5,1,0]  R857      -6.5264117717742920e-01
    z[5,1,0]  R858      5.8207523822784424e-01
    z[5,1,0]  R859      -3.2870405912399292e-01
    z[5,1,0]  R860      -3.1641387939453125e-01
    z[5,1,0]  R861      -4.2277911305427551e-01
    z[5,1,0]  R862      -1.0244952887296677e-01
    z[5,1,0]  R863      -1.2051765620708466e-01
    z[5,1,0]  R864      -4.8893335461616516e-01
    z[5,1,0]  R865      -1.8897777795791626e-01
    z[5,1,0]  R866      1.3949221372604370e-01
    z[5,1,0]  R867      -2.2030605375766754e-01
    z[5,1,0]  R868      -2.1836702525615692e-01
    z[5,1,0]  R869      2.3509931564331055e-01
    z[5,1,0]  R870      -7.6377198100090027e-02
    z[5,1,0]  R871      3.1136092543601990e-01
    z[5,1,0]  R872      3.0841851234436035e-01
    z[5,1,0]  R873      2.2287490963935852e-01
    z[5,1,0]  R874      -5.3050625324249268e-01
    z[5,1,0]  R875      -1.4284588396549225e-01
    z[5,1,0]  R876      2.0959232747554779e-01
    z[5,1,0]  R877      2.6491835713386536e-01
    z[5,1,0]  R878      4.4635945558547974e-01
    z[5,1,0]  R879      8.6355626583099365e-02
    z[5,1,0]  R880      2.9921406507492065e-01
    z[5,1,0]  R881      -3.4507188200950623e-01
    z[5,1,0]  R882      -6.5469577908515930e-02
    z[5,1,0]  R883      8.4681533277034760e-02
    z[5,1,0]  R884      -4.7394716739654541e-01
    z[5,1,0]  R885      -0.486203134059906
    z[5,1,0]  R886      -5.0084066390991211e-01
    z[5,1,0]  R887      -6.6228991746902466e-01
    z[5,1,0]  R888      -6.7427629232406616e-01
    z[5,1,0]  R889      -7.0876157283782959e-01
    z[5,1,1]  R12       1
    z[5,1,1]  R48       -1
    z[5,1,1]  R802      -1
    z[5,1,1]  R803      1
    z[5,1,1]  R814      -2.9579332470893860e-01
    z[5,1,1]  R815      -3.3140763640403748e-01
    z[5,1,1]  R816      3.6768081784248352e-01
    z[5,1,1]  R817      -3.8896843791007996e-02
    z[5,1,1]  R818      -3.9393520355224609e-01
    z[5,1,1]  R819      -0.417843759059906
    z[5,1,1]  R820      2.1209548413753510e-01
    z[5,1,1]  R821      -5.1100033521652222e-01
    z[5,1,1]  R822      8.0563133955001831e-01
    z[5,1,1]  R823      8.0624979734420776e-01
    z[5,1,1]  R824      5.9764266014099121e-01
    z[5,1,1]  R825      4.2195639014244080e-01
    z[5,1,1]  R826      3.9931362867355347e-01
    z[5,1,1]  R827      4.5708245038986206e-01
    z[5,1,1]  R828      4.1171273589134216e-01
    z[5,1,1]  R829      4.4868674874305725e-01
    z[5,1,1]  R830      4.4769674539566040e-01
    z[5,1,1]  R831      -4.8848456144332886e-01
    z[5,1,1]  R832      1.7885313928127289e-01
    z[5,1,1]  R833      -7.0007240772247314e-01
    z[5,1,1]  R834      7.5460141897201538e-01
    z[5,1,1]  R835      7.0336228609085083e-01
    z[5,1,1]  R836      7.3183369636535645e-01
    z[5,1,1]  R837      6.8371903896331787e-01
    z[5,1,1]  R838      7.2825807332992554e-01
    z[5,1,1]  R839      6.1534881591796875e-01
    z[5,1,1]  R840      5.5842143297195435e-01
    z[5,1,1]  R841      6.6320836544036865e-01
    z[5,1,1]  R842      5.2656018733978271e-01
    z[5,1,1]  R843      0.50145024061203
    z[5,1,1]  R844      0.673224151134491
    z[5,1,1]  R845      0.654941976070404
    z[5,1,1]  R846      -6.9678771495819092e-01
    z[5,1,1]  R847      -6.7250436544418335e-01
    z[5,1,1]  R848      -5.7821273803710938e-01
    z[5,1,1]  R849      -6.0361069440841675e-01
    z[5,1,1]  R850      -2.1921348571777344e-01
    z[5,1,1]  R851      -7.4452593922615051e-02
    z[5,1,1]  R852      -5.0826704502105713e-01
    z[5,1,1]  R853      -3.2922571897506714e-01
    z[5,1,1]  R854      8.1142103672027588e-01
    z[5,1,1]  R855      6.1842817068099976e-01
    z[5,1,1]  R856      6.8973690271377563e-01
    z[5,1,1]  R857      5.9134668111801147e-01
    z[5,1,1]  R858      6.1284792423248291e-01
    z[5,1,1]  R859      0.573715090751648
    z[5,1,1]  R860      9.0683412551879883e-01
    z[5,1,1]  R861      8.3137172460556030e-01
    z[5,1,1]  R862      8.0535823106765747e-01
    z[5,1,1]  R863      -3.2495595514774323e-02
    z[5,1,1]  R864      7.1907246112823486e-01
    z[5,1,1]  R865      -4.5671343803405762e-02
    z[5,1,1]  R866      8.2761889696121216e-01
    z[5,1,1]  R867      6.8467676639556885e-01
    z[5,1,1]  R868      -3.5720226168632507e-01
    z[5,1,1]  R869      2.8877329826354980e-01
    z[5,1,1]  R870      9.3616098165512085e-01
    z[5,1,1]  R871      8.7562519311904907e-01
    z[5,1,1]  R872      9.1728532314300537e-01
    z[5,1,1]  R873      8.2997298240661621e-01
    z[5,1,1]  R874      7.4703454971313477e-01
    z[5,1,1]  R875      8.3241719007492065e-01
    z[5,1,1]  R876      7.4476099014282227e-01
    z[5,1,1]  R877      7.3139709234237671e-01
    z[5,1,1]  R878      7.7011620998382568e-01
    z[5,1,1]  R879      2.8373071551322937e-01
    z[5,1,1]  R880      9.1313737630844116e-01
    z[5,1,1]  R881      8.1033390760421753e-01
    z[5,1,1]  R882      8.0890297889709473e-01
    z[5,1,1]  R883      0.686237633228302
    z[5,1,1]  R884      3.3341646194458008e-01
    z[5,1,1]  R885      2.3928360641002655e-01
    z[5,1,1]  R886      1.6235956549644470e-01
    z[5,1,1]  R887      -3.7058692425489426e-02
    z[5,1,1]  R888      -1.9127799198031425e-02
    z[5,1,1]  R889      1.4989666640758514e-01
    z[5,1,2]  R13       1
    z[5,1,2]  R49       -1
    z[5,1,2]  R804      -1
    z[5,1,2]  R805      1
    z[5,1,2]  R814      6.5029317140579224e-01
    z[5,1,2]  R815      2.3039247095584869e-01
    z[5,1,2]  R816      5.5591195821762085e-01
    z[5,1,2]  R817      3.4478139877319336e-01
    z[5,1,2]  R818      4.7812196612358093e-01
    z[5,1,2]  R819      3.3615015447139740e-02
    z[5,1,2]  R820      5.6970185041427612e-01
    z[5,1,2]  R821      -1.1947441101074219e-01
    z[5,1,2]  R822      -3.0314254760742188e-01
    z[5,1,2]  R823      -4.1481822729110718e-02
    z[5,1,2]  R824      1.9685681164264679e-01
    z[5,1,2]  R825      -2.0552419126033783e-01
    z[5,1,2]  R826      -1.6960366070270538e-01
    z[5,1,2]  R827      -2.7856704592704773e-01
    z[5,1,2]  R828      -2.1651954948902130e-01
    z[5,1,2]  R829      3.3400931954383850e-01
    z[5,1,2]  R830      2.2183121740818024e-01
    z[5,1,2]  R831      -4.7147122025489807e-01
    z[5,1,2]  R832      -3.6279717087745667e-01
    z[5,1,2]  R833      -1.6546821594238281e-01
    z[5,1,2]  R834      -2.2869546711444855e-01
    z[5,1,2]  R835      6.2293823808431625e-02
    z[5,1,2]  R836      1.7335507273674011e-01
    z[5,1,2]  R837      4.2720317840576172e-01
    z[5,1,2]  R838      -2.0526179671287537e-01
    z[5,1,2]  R839      2.8183031082153320e-01
    z[5,1,2]  R840      -2.2353968024253845e-01
    z[5,1,2]  R841      3.6107987165451050e-01
    z[5,1,2]  R842      -1.0032659024000168e-01
    z[5,1,2]  R843      -2.8439259529113770e-01
    z[5,1,2]  R844      -5.0510197877883911e-01
    z[5,1,2]  R845      -2.8678017854690552e-01
    z[5,1,2]  R846      1.0988084971904755e-01
    z[5,1,2]  R847      -1.1029504239559174e-01
    z[5,1,2]  R848      1.6776882112026215e-01
    z[5,1,2]  R849      2.3622474074363708e-01
    z[5,1,2]  R850      5.3371560573577881e-01
    z[5,1,2]  R851      6.8362191319465637e-02
    z[5,1,2]  R852      1.8323728442192078e-01
    z[5,1,2]  R853      -2.4813309311866760e-01
    z[5,1,2]  R854      2.8203356266021729e-01
    z[5,1,2]  R855      3.6106950044631958e-01
    z[5,1,2]  R856      -4.1474151611328125e-01
    z[5,1,2]  R857      3.9721819758415222e-01
    z[5,1,2]  R858      -1.3042224943637848e-01
    z[5,1,2]  R859      -5.7017207145690918e-01
    z[5,1,2]  R860      1.1580395698547363e-01
    z[5,1,2]  R861      1.8631696701049805e-01
    z[5,1,2]  R862      -2.3490869998931885e-01
    z[5,1,2]  R863      6.1722569167613983e-02
    z[5,1,2]  R864      -4.1013407707214355e-01
    z[5,1,2]  R865      -4.0237170457839966e-01
    z[5,1,2]  R866      1.8765635788440704e-01
    z[5,1,2]  R867      -0.515556275844574
    z[5,1,2]  R868      -1.5989071130752563e-01
    z[5,1,2]  R869      -1.3489606976509094e-01
    z[5,1,2]  R870      -3.3976398408412933e-02
    z[5,1,2]  R871      -2.9960241913795471e-01
    z[5,1,2]  R872      -1.3145267963409424e-01
    z[5,1,2]  R873      -3.2863074541091919e-01
    z[5,1,2]  R874      -2.4547062814235687e-01
    z[5,1,2]  R875      4.0565276145935059e-01
    z[5,1,2]  R876      1.3377526402473450e-01
    z[5,1,2]  R877      7.7422477304935455e-02
    z[5,1,2]  R878      1.4425605535507202e-01
    z[5,1,2]  R879      1.4587850868701935e-01
    z[5,1,2]  R880      2.3768074810504913e-01
    z[5,1,2]  R881      -3.1970882415771484e-01
    z[5,1,2]  R882      2.7199709415435791e-01
    z[5,1,2]  R883      -4.0316683053970337e-01
    z[5,1,2]  R884      -4.2920511960983276e-01
    z[5,1,2]  R885      -4.8564866185188293e-01
    z[5,1,2]  R886      -5.3797960281372070e-01
    z[5,1,2]  R887      -5.8077478408813477e-01
    z[5,1,2]  R888      -6.0098898410797119e-01
    z[5,1,2]  R889      -1.6859672963619232e-01
    z[5,1,3]  R14       1
    z[5,1,3]  R50       -1
    z[5,1,3]  R806      -1
    z[5,1,3]  R807      1
    z[5,1,3]  R814      3.3118334412574768e-01
    z[5,1,3]  R815      5.2328133583068848e-01
    z[5,1,3]  R816      6.3107900321483612e-02
    z[5,1,3]  R817      -3.7122715730220079e-03
    z[5,1,3]  R818      1.1415149271488190e-01
    z[5,1,3]  R819      2.2451011836528778e-01
    z[5,1,3]  R820      3.1727319955825806e-01
    z[5,1,3]  R821      -1.0649629682302475e-01
    z[5,1,3]  R822      1.8137918412685394e-01
    z[5,1,3]  R823      4.3290373682975769e-01
    z[5,1,3]  R824      -3.4623432159423828e-01
    z[5,1,3]  R825      -0.375354528427124
    z[5,1,3]  R826      -6.7517482675611973e-03
    z[5,1,3]  R827      -3.3685654401779175e-01
    z[5,1,3]  R828      -4.8288854956626892e-01
    z[5,1,3]  R829      -2.4150630831718445e-01
    z[5,1,3]  R830      1.5619641542434692e-01
    z[5,1,3]  R831      -1.4916208386421204e-01
    z[5,1,3]  R832      -2.1368719637393951e-01
    z[5,1,3]  R833      -2.2419057786464691e-01
    z[5,1,3]  R834      -4.1027626395225525e-01
    z[5,1,3]  R835      3.5584408789873123e-02
    z[5,1,3]  R836      -2.5215500593185425e-01
    z[5,1,3]  R837      -0.0723184123635292
    z[5,1,3]  R838      -4.9420168995857239e-01
    z[5,1,3]  R839      2.2640155255794525e-01
    z[5,1,3]  R840      -1.4711397886276245e-01
    z[5,1,3]  R841      4.0763825178146362e-01
    z[5,1,3]  R842      2.9277700185775757e-01
    z[5,1,3]  R843      5.6977385282516479e-01
    z[5,1,3]  R844      -1.2279611080884933e-02
    z[5,1,3]  R845      -3.3612366765737534e-02
    z[5,1,3]  R846      3.4877711534500122e-01
    z[5,1,3]  R847      -3.0873927474021912e-01
    z[5,1,3]  R848      -4.2799431085586548e-01
    z[5,1,3]  R849      -5.2732646465301514e-01
    z[5,1,3]  R850      6.4021801948547363e-01
    z[5,1,3]  R851      8.7169617414474487e-01
    z[5,1,3]  R852      3.1608742475509644e-01
    z[5,1,3]  R853      5.3747820854187012e-01
    z[5,1,3]  R854      6.8027116358280182e-02
    z[5,1,3]  R855      0.0730455219745636
    z[5,1,3]  R856      -2.5397205352783203e-01
    z[5,1,3]  R857      -1.9554081559181213e-01
    z[5,1,3]  R858      -4.5375058054924011e-01
    z[5,1,3]  R859      1.3821160793304443e-01
    z[5,1,3]  R860      0.0708138570189476
    z[5,1,3]  R861      -2.3503344506025314e-02
    z[5,1,3]  R862      -3.5512641072273254e-01
    z[5,1,3]  R863      -8.0423909425735474e-01
    z[5,1,3]  R864      -1.5500102937221527e-01
    z[5,1,3]  R865      -7.8048378229141235e-01
    z[5,1,3]  R866      -3.1121698021888733e-01
    z[5,1,3]  R867      1.7341528832912445e-01
    z[5,1,3]  R868      -8.1789320707321167e-01
    z[5,1,3]  R869      -7.1255475282669067e-01
    z[5,1,3]  R870      -2.0603038370609283e-01
    z[5,1,3]  R871      4.0164690464735031e-02
    z[5,1,3]  R872      -0.0616854727268219
    z[5,1,3]  R873      1.6903959214687347e-02
    z[5,1,3]  R874      -2.6691758632659912e-01
    z[5,1,3]  R875      -3.0812656879425049e-01
    z[5,1,3]  R876      -0.0676007941365242
    z[5,1,3]  R877      1.2762063741683960e-01
    z[5,1,3]  R878      -3.7457591295242310e-01
    z[5,1,3]  R879      -4.1808575391769409e-01
    z[5,1,3]  R880      -8.0341942608356476e-02
    z[5,1,3]  R881      9.2959113419055939e-02
    z[5,1,3]  R882      -1.3726647198200226e-01
    z[5,1,3]  R883      -1.3386221230030060e-01
    z[5,1,3]  R884      -2.7941063046455383e-01
    z[5,1,3]  R885      -5.8254975825548172e-02
    z[5,1,3]  R886      -4.0904280543327332e-01
    z[5,1,3]  R887      -1.1424877494573593e-01
    z[5,1,3]  R888      -1.3846483826637268e-01
    z[5,1,3]  R889      -4.9811783432960510e-01
    z[5,1,4]  R15       1
    z[5,1,4]  R51       -1
    z[5,1,4]  R808      -1
    z[5,1,4]  R809      1
    z[5,1,4]  R814      9.4280634075403214e-03
    z[5,1,4]  R815      2.9374551773071289e-01
    z[5,1,4]  R816      1.9206385314464569e-01
    z[5,1,4]  R817      5.6137222051620483e-01
    z[5,1,4]  R818      6.7019534111022949e-01
    z[5,1,4]  R819      -2.3307195305824280e-01
    z[5,1,4]  R820      6.1939394474029541e-01
    z[5,1,4]  R821      2.3664748668670654e-01
    z[5,1,4]  R822      3.9568841457366943e-01
    z[5,1,4]  R823      1.7387686669826508e-01
    z[5,1,4]  R824      -4.8594778776168823e-01
    z[5,1,4]  R825      -7.3324447870254517e-01
    z[5,1,4]  R826      -4.2227414250373840e-01
    z[5,1,4]  R827      -4.9721163511276245e-01
    z[5,1,4]  R828      -2.3260879516601562e-01
    z[5,1,4]  R829      1.9123084843158722e-01
    z[5,1,4]  R830      -3.1898370385169983e-01
    z[5,1,4]  R831      4.3852204084396362e-01
    z[5,1,4]  R832      6.9909161329269409e-01
    z[5,1,4]  R833      6.7884959280490875e-02
    z[5,1,4]  R834      -3.6485812067985535e-01
    z[5,1,4]  R835      -5.1581335067749023e-01
    z[5,1,4]  R836      1.2401795387268066e-01
    z[5,1,4]  R837      2.2467546164989471e-01
    z[5,1,4]  R838      2.3399452865123749e-01
    z[5,1,4]  R839      -3.7361967563629150e-01
    z[5,1,4]  R840      -5.3972554206848145e-01
    z[5,1,4]  R841      -3.5437917709350586e-01
    z[5,1,4]  R842      -7.3020040988922119e-01
    z[5,1,4]  R843      1.8432773649692535e-02
    z[5,1,4]  R844      -1.6219811141490936e-01
    z[5,1,4]  R845      -3.4186261892318726e-01
    z[5,1,4]  R846      -1.4937274158000946e-01
    z[5,1,4]  R847      -1.9341942667961121e-01
    z[5,1,4]  R848      2.0830312743782997e-02
    z[5,1,4]  R849      -9.0662986040115356e-02
    z[5,1,4]  R850      -2.9989248514175415e-01
    z[5,1,4]  R851      4.0327611565589905e-01
    z[5,1,4]  R852      1.3635893166065216e-01
    z[5,1,4]  R853      -1.1704660207033157e-01
    z[5,1,4]  R854      -1.5881028771400452e-01
    z[5,1,4]  R855      -3.1409943103790283e-01
    z[5,1,4]  R856      -1.0652378201484680e-01
    z[5,1,4]  R857      -8.4657326340675354e-02
    z[5,1,4]  R858      -2.3083089292049408e-01
    z[5,1,4]  R859      -2.1730849146842957e-01
    z[5,1,4]  R860      -1.2386199086904526e-01
    z[5,1,4]  R861      1.3840185105800629e-01
    z[5,1,4]  R862      1.9290681183338165e-01
    z[5,1,4]  R863      -4.6147534251213074e-01
    z[5,1,4]  R864      -1.8422381579875946e-01
    z[5,1,4]  R865      -2.5764617323875427e-01
    z[5,1,4]  R866      1.6537123918533325e-01
    z[5,1,4]  R867      -4.1052049398422241e-01
    z[5,1,4]  R868      -2.0468063652515411e-01
    z[5,1,4]  R869      -7.2437569499015808e-02
    z[5,1,4]  R870      -2.6350542902946472e-01
    z[5,1,4]  R871      1.0137168318033218e-01
    z[5,1,4]  R872      1.3075691461563110e-01
    z[5,1,4]  R873      -1.4864277839660645e-01
    z[5,1,4]  R874      -9.7453128546476364e-04
    z[5,1,4]  R875      -1.4390507340431213e-01
    z[5,1,4]  R876      -1.9986103475093842e-01
    z[5,1,4]  R877      -2.4364335834980011e-01
    z[5,1,4]  R878      -2.0298688113689423e-01
    z[5,1,4]  R879      -1.5748099982738495e-01
    z[5,1,4]  R880      7.0507891476154327e-02
    z[5,1,4]  R881      2.3336309194564819e-01
    z[5,1,4]  R882      4.8944371519610286e-04
    z[5,1,4]  R883      2.4909204244613647e-01
    z[5,1,4]  R884      -5.0483405590057373e-01
    z[5,1,4]  R885      -3.9216119050979614e-01
    z[5,1,4]  R886      -6.7085914313793182e-02
    z[5,1,4]  R887      -3.5326597094535828e-01
    z[5,1,4]  R888      5.3770218044519424e-02
    z[5,1,4]  R889      -2.8380699455738068e-02
    z[5,1,5]  R16       1
    z[5,1,5]  R52       -1
    z[5,1,5]  R810      -1
    z[5,1,5]  R811      1
    z[5,1,5]  R814      3.8242614269256592e-01
    z[5,1,5]  R815      5.0597274303436279e-01
    z[5,1,5]  R816      5.9371012449264526e-01
    z[5,1,5]  R817      5.5435377359390259e-01
    z[5,1,5]  R818      -3.4342953003942966e-03
    z[5,1,5]  R819      9.8959669470787048e-02
    z[5,1,5]  R820      2.9374006390571594e-01
    z[5,1,5]  R821      3.2743221521377563e-01
    z[5,1,5]  R822      1.5588788688182831e-01
    z[5,1,5]  R823      3.2585912942886353e-01
    z[5,1,5]  R824      -3.5222217440605164e-01
    z[5,1,5]  R825      -7.2058849036693573e-02
    z[5,1,5]  R826      -7.6254093647003174e-01
    z[5,1,5]  R827      -1.7625318467617035e-01
    z[5,1,5]  R828      -5.0293862819671631e-01
    z[5,1,5]  R829      -6.7311418056488037e-01
    z[5,1,5]  R830      -2.0385213196277618e-01
    z[5,1,5]  R831      -1.0849576443433762e-01
    z[5,1,5]  R832      -3.8317084312438965e-01
    z[5,1,5]  R833      2.3181456327438354e-01
    z[5,1,5]  R834      1.2535206973552704e-01
    z[5,1,5]  R835      -7.0958539843559265e-02
    z[5,1,5]  R836      -1.7830401659011841e-01
    z[5,1,5]  R837      -5.1603770256042480e-01
    z[5,1,5]  R838      -2.8873044252395630e-01
    z[5,1,5]  R839      -5.5137360095977783e-01
    z[5,1,5]  R840      1.7858842015266418e-01
    z[5,1,5]  R841      -3.3059626817703247e-01
    z[5,1,5]  R842      -2.7245754003524780e-01
    z[5,1,5]  R843      -4.0308335423469543e-01
    z[5,1,5]  R844      4.5589298009872437e-02
    z[5,1,5]  R845      -5.7330334186553955e-01
    z[5,1,5]  R846      -5.0638669729232788e-01
    z[5,1,5]  R847      3.8519567251205444e-01
    z[5,1,5]  R848      3.9548525214195251e-01
    z[5,1,5]  R849      2.0005165040493011e-01
    z[5,1,5]  R850      -5.6651927297934890e-04
    z[5,1,5]  R851      9.0601295232772827e-02
    z[5,1,5]  R852      -1.7133527994155884e-01
    z[5,1,5]  R853      3.7299975752830505e-01
    z[5,1,5]  R854      4.1182979941368103e-01
    z[5,1,5]  R855      7.7907584607601166e-02
    z[5,1,5]  R856      2.6482158899307251e-01
    z[5,1,5]  R857      1.2379072606563568e-01
    z[5,1,5]  R858      6.4545914530754089e-02
    z[5,1,5]  R859      4.1312563419342041e-01
    z[5,1,5]  R860      -2.0584091544151306e-01
    z[5,1,5]  R861      2.3110151290893555e-01
    z[5,1,5]  R862      -5.2509274333715439e-02
    z[5,1,5]  R863      -3.2188376784324646e-01
    z[5,1,5]  R864      1.3271375000476837e-01
    z[5,1,5]  R865      -2.4289096891880035e-01
    z[5,1,5]  R866      7.5283623300492764e-03
    z[5,1,5]  R867      -1.3356009125709534e-01
    z[5,1,5]  R868      -1.5559597313404083e-01
    z[5,1,5]  R869      -5.3729629516601562e-01
    z[5,1,5]  R870      5.8139726519584656e-02
    z[5,1,5]  R871      1.5446808934211731e-01
    z[5,1,5]  R872      2.1611662581562996e-02
    z[5,1,5]  R873      -0.069243885576725
    z[5,1,5]  R874      1.6166546940803528e-01
    z[5,1,5]  R875      2.5690641254186630e-02
    z[5,1,5]  R876      -4.5451423525810242e-01
    z[5,1,5]  R877      -5.5896449089050293e-01
    z[5,1,5]  R878      -5.0081085413694382e-02
    z[5,1,5]  R879      -8.2788634300231934e-01
    z[5,1,5]  R880      -7.5349416583776474e-03
    z[5,1,5]  R881      -0.040500458329916
    z[5,1,5]  R882      2.0076100528240204e-01
    z[5,1,5]  R883      -0.453075110912323
    z[5,1,5]  R884      -3.6468061804771423e-01
    z[5,1,5]  R885      -4.3863037228584290e-01
    z[5,1,5]  R886      -3.8898301124572754e-01
    z[5,1,5]  R887      -2.8561952710151672e-01
    z[5,1,5]  R888      -3.9827275276184082e-01
    z[5,1,5]  R889      -4.4335415959358215e-01
    z[5,1,6]  R17       1
    z[5,1,6]  R53       -1
    z[5,1,6]  R812      -1
    z[5,1,6]  R813      1
    z[5,1,6]  R814      2.7778422459959984e-02
    z[5,1,6]  R815      -2.4745856225490570e-01
    z[5,1,6]  R816      1.2494678609073162e-02
    z[5,1,6]  R817      2.5164343416690826e-02
    z[5,1,6]  R818      7.5825154781341553e-02
    z[5,1,6]  R819      2.1239224076271057e-01
    z[5,1,6]  R820      -2.0509015023708344e-01
    z[5,1,6]  R821      2.0678873360157013e-01
    z[5,1,6]  R822      -8.5689671337604523e-02
    z[5,1,6]  R823      2.1212226711213589e-03
    z[5,1,6]  R824      3.5165277123451233e-01
    z[5,1,6]  R825      1.8630404770374298e-01
    z[5,1,6]  R826      1.3250321149826050e-01
    z[5,1,6]  R827      2.5208277627825737e-02
    z[5,1,6]  R828      1.9400231540203094e-01
    z[5,1,6]  R829      1.7305904626846313e-01
    z[5,1,6]  R830      -0.234492689371109
    z[5,1,6]  R831      -4.8598459362983704e-01
    z[5,1,6]  R832      -1.0857817530632019e-01
    z[5,1,6]  R833      -1.4566726982593536e-01
    z[5,1,6]  R834      8.4196001291275024e-02
    z[5,1,6]  R835      -1.1761871725320816e-01
    z[5,1,6]  R836      -5.5409427732229233e-02
    z[5,1,6]  R837      1.6645808517932892e-01
    z[5,1,6]  R838      2.0787145197391510e-01
    z[5,1,6]  R839      1.0104341804981232e-01
    z[5,1,6]  R840      5.2588790655136108e-01
    z[5,1,6]  R841      -2.5872574187815189e-03
    z[5,1,6]  R842      2.2560091689229012e-02
    z[5,1,6]  R843      -3.6706754565238953e-01
    z[5,1,6]  R844      7.9674273729324341e-02
    z[5,1,6]  R845      5.0857108086347580e-02
    z[5,1,6]  R846      -9.6527636051177979e-02
    z[5,1,6]  R847      -5.5138994008302689e-02
    z[5,1,6]  R848      -0.000664629100356251
    z[5,1,6]  R849      1.5300613641738892e-01
    z[5,1,6]  R850      -2.9847362637519836e-01
    z[5,1,6]  R851      1.3364848494529724e-01
    z[5,1,6]  R852      5.7265937328338623e-01
    z[5,1,6]  R853      -3.7704864144325256e-01
    z[5,1,6]  R854      2.1458871662616730e-01
    z[5,1,6]  R855      4.5019667595624924e-03
    z[5,1,6]  R856      -4.5302253961563110e-01
    z[5,1,6]  R857      7.6544538140296936e-02
    z[5,1,6]  R858      -7.2506345808506012e-02
    z[5,1,6]  R859      2.6650076732039452e-02
    z[5,1,6]  R860      -3.7373367697000504e-02
    z[5,1,6]  R861      -1.4916238188743591e-01
    z[5,1,6]  R862      3.4588301181793213e-01
    z[5,1,6]  R863      -1.3130338490009308e-01
    z[5,1,6]  R864      9.6046822145581245e-03
    z[5,1,6]  R865      -2.5644913315773010e-01
    z[5,1,6]  R866      0.368935763835907
    z[5,1,6]  R867      2.1128838881850243e-02
    z[5,1,6]  R868      2.5318679213523865e-01
    z[5,1,6]  R869      2.0364819467067719e-01
    z[5,1,6]  R870      -3.6755308508872986e-02
    z[5,1,6]  R871      1.0403539240360260e-01
    z[5,1,6]  R872      -1.5753178298473358e-01
    z[5,1,6]  R873      3.5538470745086670e-01
    z[5,1,6]  R874      -5.3524747490882874e-02
    z[5,1,6]  R875      -7.6234750449657440e-02
    z[5,1,6]  R876      3.6388018727302551e-01
    z[5,1,6]  R877      2.8143441304564476e-02
    z[5,1,6]  R878      -5.3437568247318268e-02
    z[5,1,6]  R879      -7.5942777097225189e-02
    z[5,1,6]  R880      9.3145325779914856e-02
    z[5,1,6]  R881      -0.239437997341156
    z[5,1,6]  R882      4.5635515451431274e-01
    z[5,1,6]  R883      -2.7225065231323242e-01
    z[5,1,6]  R884      1.1862057447433472e-01
    z[5,1,6]  R885      3.4772762656211853e-01
    z[5,1,6]  R886      3.3204165101051331e-01
    z[5,1,6]  R887      -5.7194292545318604e-02
    z[5,1,6]  R888      -5.5794060230255127e-02
    z[5,1,6]  R889      -3.5684242844581604e-02
    z[2,3,0]  R20       -1
    z[2,3,0]  R29       1
    z[2,3,0]  R890      -1
    z[2,3,0]  R891      1
    z[2,3,0]  R904      -4.9124273657798767e-01
    z[2,3,0]  R905      -7.7634233236312866e-01
    z[2,3,0]  R906      -4.5373073220252991e-01
    z[2,3,0]  R907      -6.8108010292053223e-01
    z[2,3,0]  R908      -7.1953850984573364e-01
    z[2,3,0]  R909      -4.6407660841941833e-01
    z[2,3,0]  R910      -3.3312138915061951e-01
    z[2,3,0]  R911      -7.2410744428634644e-01
    z[2,3,0]  R912      -6.1397582292556763e-01
    z[2,3,0]  R913      -1.4422667026519775e-01
    z[2,3,0]  R914      6.1473723500967026e-02
    z[2,3,0]  R915      0.153394877910614
    z[2,3,0]  R916      -2.0218744874000549e-01
    z[2,3,0]  R917      -1.8500488996505737e-01
    z[2,3,0]  R918      1.5352945029735565e-01
    z[2,3,0]  R919      9.4493657350540161e-02
    z[2,3,0]  R920      -0.059889055788517
    z[2,3,0]  R921      2.3794810473918915e-01
    z[2,3,0]  R922      -2.4597447365522385e-02
    z[2,3,0]  R923      4.5672440528869629e-01
    z[2,3,0]  R924      4.7142812609672546e-01
    z[2,3,0]  R925      2.4861901998519897e-02
    z[2,3,0]  R926      -1.4215698838233948e-01
    z[2,3,0]  R927      5.0571531057357788e-01
    z[2,3,0]  R928      1.2481260299682617e-01
    z[2,3,0]  R929      -4.0614360570907593e-01
    z[2,3,0]  R930      -1.9890600442886353e-01
    z[2,3,0]  R931      1.8972903490066528e-02
    z[2,3,0]  R932      -6.2058974057435989e-02
    z[2,3,0]  R933      -1.0376165807247162e-01
    z[2,3,0]  R934      -1.7810884118080139e-01
    z[2,3,0]  R935      9.4430714845657349e-02
    z[2,3,0]  R936      1.2676912546157837e-01
    z[2,3,0]  R937      -1.5843637287616730e-01
    z[2,3,0]  R938      4.0129086375236511e-01
    z[2,3,0]  R939      2.0959985256195068e-01
    z[2,3,0]  R940      4.2695617675781250e-01
    z[2,3,0]  R941      -8.0943085253238678e-02
    z[2,3,0]  R942      -3.6984920501708984e-01
    z[2,3,0]  R943      -6.6380125284194946e-01
    z[2,3,0]  R944      -4.9481880851089954e-03
    z[2,3,0]  R945      -6.7595876753330231e-03
    z[2,3,0]  R946      2.1995209157466888e-01
    z[2,3,0]  R947      -5.0826031714677811e-02
    z[2,3,0]  R948      4.4874809682369232e-02
    z[2,3,0]  R949      -3.3454048633575439e-01
    z[2,3,0]  R950      2.5708615779876709e-01
    z[2,3,0]  R951      6.0063779354095459e-01
    z[2,3,0]  R952      -6.4115297794342041e-01
    z[2,3,0]  R953      -3.8052040338516235e-01
    z[2,3,0]  R954      2.9909870028495789e-01
    z[2,3,0]  R955      -1.2768530286848545e-02
    z[2,3,0]  R956      -2.4318021535873413e-01
    z[2,3,0]  R957      6.0623455792665482e-02
    z[2,3,0]  R958      -4.2846912145614624e-01
    z[2,3,0]  R959      -2.1448197960853577e-01
    z[2,3,0]  R960      -3.8751190900802612e-01
    z[2,3,0]  R961      5.0506293773651123e-01
    z[2,3,0]  R962      2.9371036216616631e-02
    z[2,3,0]  R963      -1.8463903665542603e-01
    z[2,3,0]  R964      -1.7569494247436523e-01
    z[2,3,0]  R965      -3.0998736619949341e-01
    z[2,3,0]  R966      -0.0892467051744461
    z[2,3,0]  R967      3.0539789795875549e-01
    z[2,3,0]  R968      -3.7317898869514465e-01
    z[2,3,0]  R969      4.7704753279685974e-01
    z[2,3,0]  R970      3.6393198370933533e-01
    z[2,3,0]  R971      6.0187149047851562e-01
    z[2,3,0]  R972      0.573669970035553
    z[2,3,0]  R973      6.0565555095672607e-01
    z[2,3,0]  R974      -6.8427008390426636e-01
    z[2,3,0]  R975      -1.4818302355706692e-02
    z[2,3,0]  R976      -3.4127944707870483e-01
    z[2,3,0]  R977      -3.2248872518539429e-01
    z[2,3,0]  R978      -4.1533282399177551e-01
    z[2,3,0]  R979      3.2071336172521114e-03
    z[2,3,0]  R980      -7.8725844621658325e-02
    z[2,3,0]  R981      -1.8082509934902191e-01
    z[2,3,0]  R982      -3.0452203750610352e-01
    z[2,3,0]  R983      2.1030250191688538e-01
    z[2,3,0]  R984      -0.369750440120697
    z[2,3,0]  R985      -3.6885312199592590e-01
    z[2,3,0]  R986      3.4414097666740417e-01
    z[2,3,0]  R987      -3.8569509983062744e-01
    z[2,3,0]  R988      -3.7709867954254150e-01
    z[2,3,0]  R989      -2.5882118940353394e-01
    z[2,3,0]  R990      5.3064805269241333e-01
    z[2,3,0]  R991      -4.6140491962432861e-01
    z[2,3,0]  R992      1.0283546894788742e-01
    z[2,3,0]  R993      1.1462587118148804e-01
    z[2,3,0]  R994      2.0582200586795807e-01
    z[2,3,0]  R995      -1.8039016425609589e-01
    z[2,3,0]  R996      -1.4154779911041260e-01
    z[2,3,0]  R997      2.8120434284210205e-01
    z[2,3,0]  R998      2.1532581746578217e-01
    z[2,3,0]  R999      -3.2824245095252991e-01
    z[2,3,0]  R1000     3.4028959274291992e-01
    z[2,3,0]  R1001     2.9312244057655334e-01
    z[2,3,0]  R1002     1.1301513016223907e-01
    z[2,3,0]  R1003     2.0777639746665955e-01
    z[2,3,0]  R1004     -4.3527320027351379e-01
    z[2,3,0]  R1005     1.6804765909910202e-02
    z[2,3,0]  R1006     -1.4892593026161194e-01
    z[2,3,0]  R1007     3.1925755739212036e-01
    z[2,3,0]  R1008     -1.5773749351501465e-01
    z[2,3,0]  R1009     -1.5710341930389404e-01
    z[2,3,0]  R1010     -1.9159191846847534e-01
    z[2,3,0]  R1011     -0.639341413974762
    z[2,3,0]  R1012     1.9629706442356110e-01
    z[2,3,0]  R1013     -2.8094035387039185e-01
    z[2,3,1]  R21       -1
    z[2,3,1]  R30       1
    z[2,3,1]  R892      -1
    z[2,3,1]  R893      1
    z[2,3,1]  R904      -4.4544604420661926e-01
    z[2,3,1]  R905      -4.0777593851089478e-01
    z[2,3,1]  R906      -4.2607891559600830e-01
    z[2,3,1]  R907      -2.7949529886245728e-01
    z[2,3,1]  R908      -0.350705623626709
    z[2,3,1]  R909      -0.363901287317276
    z[2,3,1]  R910      -4.9221006035804749e-01
    z[2,3,1]  R911      -3.8024628162384033e-01
    z[2,3,1]  R912      0.237028107047081
    z[2,3,1]  R913      -8.7349957227706909e-01
    z[2,3,1]  R914      -2.5577083230018616e-01
    z[2,3,1]  R915      2.4164129793643951e-01
    z[2,3,1]  R916      0.829850971698761
    z[2,3,1]  R917      6.4701384305953979e-01
    z[2,3,1]  R918      9.1239744424819946e-01
    z[2,3,1]  R919      8.7869280576705933e-01
    z[2,3,1]  R920      8.8222002983093262e-01
    z[2,3,1]  R921      3.3945631980895996e-01
    z[2,3,1]  R922      7.9038488864898682e-01
    z[2,3,1]  R923      4.7249439358711243e-01
    z[2,3,1]  R924      -2.5328485295176506e-02
    z[2,3,1]  R925      -4.2231306433677673e-01
    z[2,3,1]  R926      1.6041561961174011e-01
    z[2,3,1]  R927      9.7372457385063171e-02
    z[2,3,1]  R928      3.9665067195892334e-01
    z[2,3,1]  R929      5.0427418947219849e-01
    z[2,3,1]  R930      -2.2575311362743378e-01
    z[2,3,1]  R931      2.1479836106300354e-01
    z[2,3,1]  R932      2.1152751147747040e-01
    z[2,3,1]  R933      2.3155732452869415e-01
    z[2,3,1]  R934      -2.0896512269973755e-01
    z[2,3,1]  R935      -8.6768402252346277e-04
    z[2,3,1]  R936      4.8274621367454529e-01
    z[2,3,1]  R937      3.2020667195320129e-01
    z[2,3,1]  R938      1.8010555207729340e-01
    z[2,3,1]  R939      -4.0624219179153442e-01
    z[2,3,1]  R940      -4.6342805027961731e-02
    z[2,3,1]  R941      2.6514491438865662e-01
    z[2,3,1]  R942      2.3521491885185242e-01
    z[2,3,1]  R943      2.4544388055801392e-01
    z[2,3,1]  R944      -8.3455711603164673e-02
    z[2,3,1]  R945      1.5370737016201019e-01
    z[2,3,1]  R946      2.3272086679935455e-01
    z[2,3,1]  R947      3.5309621691703796e-01
    z[2,3,1]  R948      1.4941997826099396e-01
    z[2,3,1]  R949      -3.7667483091354370e-02
    z[2,3,1]  R950      4.8218145966529846e-01
    z[2,3,1]  R951      -1.7782464623451233e-01
    z[2,3,1]  R952      3.9055651426315308e-01
    z[2,3,1]  R953      4.6254959702491760e-01
    z[2,3,1]  R954      2.5293555110692978e-02
    z[2,3,1]  R955      1.9626750051975250e-01
    z[2,3,1]  R956      9.6097335219383240e-02
    z[2,3,1]  R957      1.5056197345256805e-01
    z[2,3,1]  R958      1.8992094695568085e-01
    z[2,3,1]  R959      3.4925243258476257e-01
    z[2,3,1]  R960      -9.8732315003871918e-02
    z[2,3,1]  R961      -1.1955556273460388e-01
    z[2,3,1]  R962      -4.8471504449844360e-01
    z[2,3,1]  R963      3.3883380889892578e-01
    z[2,3,1]  R964      -4.6554881334304810e-01
    z[2,3,1]  R965      8.7587319314479828e-02
    z[2,3,1]  R966      3.0281466245651245e-01
    z[2,3,1]  R967      0.00760143157094717
    z[2,3,1]  R968      2.8109899163246155e-01
    z[2,3,1]  R969      4.2320245504379272e-01
    z[2,3,1]  R970      -2.1706353127956390e-01
    z[2,3,1]  R971      -3.9704304933547974e-01
    z[2,3,1]  R972      -1.0005540400743484e-01
    z[2,3,1]  R973      -0.344194233417511
    z[2,3,1]  R974      -5.6477773189544678e-01
    z[2,3,1]  R975      -7.5187635421752930e-01
    z[2,3,1]  R976      -6.2260061502456665e-01
    z[2,3,1]  R977      -4.6212467551231384e-01
    z[2,3,1]  R978      -3.4248134493827820e-01
    z[2,3,1]  R979      -5.2284485101699829e-01
    z[2,3,1]  R980      -5.7583832740783691e-01
    z[2,3,1]  R981      -0.672904372215271
    z[2,3,1]  R982      7.6640832424163818e-01
    z[2,3,1]  R983      8.8993984460830688e-01
    z[2,3,1]  R984      0.696917712688446
    z[2,3,1]  R985      7.6524215936660767e-01
    z[2,3,1]  R986      5.4195505380630493e-01
    z[2,3,1]  R987      0.670072078704834
    z[2,3,1]  R988      6.4999777078628540e-01
    z[2,3,1]  R989      7.1910876035690308e-01
    z[2,3,1]  R990      2.6219698786735535e-01
    z[2,3,1]  R991      6.5600740909576416e-01
    z[2,3,1]  R992      0.321405291557312
    z[2,3,1]  R993      5.5682206153869629e-01
    z[2,3,1]  R994      0.855639636516571
    z[2,3,1]  R995      9.2047715187072754e-01
    z[2,3,1]  R996      -5.6608009338378906e-01
    z[2,3,1]  R997      -6.5798693895339966e-01
    z[2,3,1]  R998      -7.5619047880172729e-01
    z[2,3,1]  R999      6.1508959531784058e-01
    z[2,3,1]  R1000     -4.8962280154228210e-01
    z[2,3,1]  R1001     5.5734282732009888e-01
    z[2,3,1]  R1002     6.2382537126541138e-01
    z[2,3,1]  R1003     6.9943684339523315e-01
    z[2,3,1]  R1004     -5.6367683410644531e-01
    z[2,3,1]  R1005     7.6815813779830933e-01
    z[2,3,1]  R1006     -7.6969122886657715e-01
    z[2,3,1]  R1007     -7.3696362972259521e-01
    z[2,3,1]  R1008     -9.2049682140350342e-01
    z[2,3,1]  R1009     -7.5868427753448486e-01
    z[2,3,1]  R1010     6.7385560274124146e-01
    z[2,3,1]  R1011     5.2036279439926147e-01
    z[2,3,1]  R1012     0.868614137172699
    z[2,3,1]  R1013     8.1428307294845581e-01
    z[2,3,2]  R22       -1
    z[2,3,2]  R31       1
    z[2,3,2]  R894      -1
    z[2,3,2]  R895      1
    z[2,3,2]  R904      -5.0723069906234741e-01
    z[2,3,2]  R905      -3.0221751332283020e-01
    z[2,3,2]  R906      -5.4670047760009766e-01
    z[2,3,2]  R907      -5.1954925060272217e-01
    z[2,3,2]  R908      -3.8589019328355789e-02
    z[2,3,2]  R909      -6.0903567075729370e-01
    z[2,3,2]  R910      -4.8527535051107407e-02
    z[2,3,2]  R911      -2.2927054762840271e-01
    z[2,3,2]  R912      -6.1901479959487915e-01
    z[2,3,2]  R913      3.8353729993104935e-02
    z[2,3,2]  R914      4.4338819384574890e-01
    z[2,3,2]  R915      -3.2167810946702957e-02
    z[2,3,2]  R916      3.1972485780715942e-01
    z[2,3,2]  R917      5.0286766141653061e-02
    z[2,3,2]  R918      1.2339603155851364e-01
    z[2,3,2]  R919      2.6287573575973511e-01
    z[2,3,2]  R920      2.2269165515899658e-01
    z[2,3,2]  R921      6.6414773464202881e-01
    z[2,3,2]  R922      7.4134194292128086e-03
    z[2,3,2]  R923      -2.6723316311836243e-01
    z[2,3,2]  R924      -0.0663272812962532
    z[2,3,2]  R925      -3.2018488645553589e-01
    z[2,3,2]  R926      -3.5017940402030945e-01
    z[2,3,2]  R927      1.4386005699634552e-01
    z[2,3,2]  R928      -8.9014537632465363e-02
    z[2,3,2]  R929      1.2869903445243835e-01
    z[2,3,2]  R930      3.2295051217079163e-01
    z[2,3,2]  R931      3.2745265960693359e-01
    z[2,3,2]  R932      -2.7053061127662659e-01
    z[2,3,2]  R933      -3.1839540600776672e-01
    z[2,3,2]  R934      4.8677217960357666e-01
    z[2,3,2]  R935      8.2149881124496460e-01
    z[2,3,2]  R936      5.7530528306961060e-01
    z[2,3,2]  R937      1.1776317656040192e-01
    z[2,3,2]  R938      -4.4055002927780151e-01
    z[2,3,2]  R939      3.9006423950195312e-01
    z[2,3,2]  R940      -2.8825944662094116e-01
    z[2,3,2]  R941      -1.3484659790992737e-01
    z[2,3,2]  R942      2.1095946431159973e-01
    z[2,3,2]  R943      -1.1477702856063843e-01
    z[2,3,2]  R944      5.4724162817001343e-01
    z[2,3,2]  R945      -2.2157758474349976e-01
    z[2,3,2]  R946      3.6912760138511658e-01
    z[2,3,2]  R947      -1.3935816287994385e-01
    z[2,3,2]  R948      -1.5904602408409119e-01
    z[2,3,2]  R949      -1.1023134738206863e-01
    z[2,3,2]  R950      -3.6716946959495544e-01
    z[2,3,2]  R951      6.4137715101242065e-01
    z[2,3,2]  R952      4.7803804278373718e-02
    z[2,3,2]  R953      -1.0268244892358780e-01
    z[2,3,2]  R954      -4.5061972737312317e-01
    z[2,3,2]  R955      3.8992297649383545e-01
    z[2,3,2]  R956      1.1180755496025085e-01
    z[2,3,2]  R957      -4.3792682886123657e-01
    z[2,3,2]  R958      -2.3457825183868408e-01
    z[2,3,2]  R959      5.8858606964349747e-02
    z[2,3,2]  R960      -3.3551222085952759e-01
    z[2,3,2]  R961      0.629315972328186
    z[2,3,2]  R962      -3.7618912756443024e-02
    z[2,3,2]  R963      -1.8613802269101143e-02
    z[2,3,2]  R964      -1.5646006166934967e-01
    z[2,3,2]  R965      -3.8047635555267334e-01
    z[2,3,2]  R966      -2.5038030743598938e-01
    z[2,3,2]  R967      -2.7576902508735657e-01
    z[2,3,2]  R968      -1.3379658758640289e-01
    z[2,3,2]  R969      4.4476044178009033e-01
    z[2,3,2]  R970      -3.8278463482856750e-01
    z[2,3,2]  R971      -1.5245710313320160e-01
    z[2,3,2]  R972      -3.1500127911567688e-01
    z[2,3,2]  R973      -4.9095860123634338e-01
    z[2,3,2]  R974      -1.5577442944049835e-01
    z[2,3,2]  R975      -6.0458236932754517e-01
    z[2,3,2]  R976      -5.1972138881683350e-01
    z[2,3,2]  R977      -3.8542884588241577e-01
    z[2,3,2]  R978      -4.9501702189445496e-01
    z[2,3,2]  R979      -3.6971840262413025e-01
    z[2,3,2]  R980      -0.673039972782135
    z[2,3,2]  R981      7.3226056993007660e-02
    z[2,3,2]  R982      -3.3864775300025940e-01
    z[2,3,2]  R983      -1.6483345627784729e-01
    z[2,3,2]  R984      4.4338285923004150e-01
    z[2,3,2]  R985      2.1244935691356659e-01
    z[2,3,2]  R986      4.1812750697135925e-01
    z[2,3,2]  R987      3.2986089587211609e-01
    z[2,3,2]  R988      7.5422719120979309e-02
    z[2,3,2]  R989      -1.8810895085334778e-01
    z[2,3,2]  R990      4.7620362043380737e-01
    z[2,3,2]  R991      3.8832318782806396e-01
    z[2,3,2]  R992      6.0331451892852783e-01
    z[2,3,2]  R993      4.2715713381767273e-01
    z[2,3,2]  R994      1.9687317311763763e-01
    z[2,3,2]  R995      1.8519483506679535e-01
    z[2,3,2]  R996      -0.0568130724132061
    z[2,3,2]  R997      -1.6443207859992981e-01
    z[2,3,2]  R998      1.1148890107870102e-01
    z[2,3,2]  R999      1.9072158634662628e-01
    z[2,3,2]  R1000     -0.0665467232465744
    z[2,3,2]  R1001     4.0483516454696655e-01
    z[2,3,2]  R1002     3.5350584983825684e-01
    z[2,3,2]  R1003     1.7171221971511841e-01
    z[2,3,2]  R1004     -1.9684784114360809e-01
    z[2,3,2]  R1005     7.5926974415779114e-02
    z[2,3,2]  R1006     -3.3008918166160583e-01
    z[2,3,2]  R1007     -3.6259409785270691e-01
    z[2,3,2]  R1008     1.0326393693685532e-01
    z[2,3,2]  R1009     -3.9868235588073730e-02
    z[2,3,2]  R1010     -6.3102908432483673e-02
    z[2,3,2]  R1011     -0.0151675371453166
    z[2,3,2]  R1012     -1.6450341045856476e-01
    z[2,3,2]  R1013     8.5549578070640564e-02
    z[2,3,3]  R23       -1
    z[2,3,3]  R32       1
    z[2,3,3]  R896      -1
    z[2,3,3]  R897      1
    z[2,3,3]  R904      5.0857901573181152e-01
    z[2,3,3]  R905      2.4969819188117981e-01
    z[2,3,3]  R906      4.9621476791799068e-03
    z[2,3,3]  R907      -1.0981449484825134e-01
    z[2,3,3]  R908      5.2821516990661621e-01
    z[2,3,3]  R909      -3.8038119673728943e-02
    z[2,3,3]  R910      6.7629760503768921e-01
    z[2,3,3]  R911      -1.7949819564819336e-01
    z[2,3,3]  R912      3.6374571919441223e-01
    z[2,3,3]  R913      2.1840167045593262e-01
    z[2,3,3]  R914      -0.52577143907547
    z[2,3,3]  R915      -4.1349199414253235e-01
    z[2,3,3]  R916      -1.5367542207241058e-01
    z[2,3,3]  R917      -4.5624691247940063e-01
    z[2,3,3]  R918      -2.2992837429046631e-01
    z[2,3,3]  R919      -5.1483251154422760e-02
    z[2,3,3]  R920      9.5154352486133575e-02
    z[2,3,3]  R921      -3.0231153964996338e-01
    z[2,3,3]  R922      -3.1349179148674011e-01
    z[2,3,3]  R923      -4.9525824189186096e-01
    z[2,3,3]  R924      -7.8650033473968506e-01
    z[2,3,3]  R925      -4.3379139900207520e-01
    z[2,3,3]  R926      -6.5854293107986450e-01
    z[2,3,3]  R927      -5.3881102800369263e-01
    z[2,3,3]  R928      -7.9445666074752808e-01
    z[2,3,3]  R929      -4.4195863604545593e-01
    z[2,3,3]  R930      -7.2630548477172852e-01
    z[2,3,3]  R931      -8.7272793054580688e-01
    z[2,3,3]  R932      2.8594639897346497e-01
    z[2,3,3]  R933      0.0881413072347641
    z[2,3,3]  R934      -8.0582714080810547e-01
    z[2,3,3]  R935      -2.6946470141410828e-01
    z[2,3,3]  R936      -4.8328486084938049e-01
    z[2,3,3]  R937      6.5524083375930786e-01
    z[2,3,3]  R938      6.8470877408981323e-01
    z[2,3,3]  R939      -4.3322277069091797e-01
    z[2,3,3]  R940      7.4889016151428223e-01
    z[2,3,3]  R941      -6.5494573116302490e-01
    z[2,3,3]  R942      7.3258213698863983e-02
    z[2,3,3]  R943      -2.6382020115852356e-01
    z[2,3,3]  R944      -4.8871728777885437e-01
    z[2,3,3]  R945      8.1759041547775269e-01
    z[2,3,3]  R946      -0.515705943107605
    z[2,3,3]  R947      0.695762038230896
    z[2,3,3]  R948      6.9523996114730835e-01
    z[2,3,3]  R949      8.0560527741909027e-02
    z[2,3,3]  R950      -2.6228037476539612e-01
    z[2,3,3]  R951      -1.9468809664249420e-01
    z[2,3,3]  R952      2.4396492540836334e-01
    z[2,3,3]  R953      0.0779092013835907
    z[2,3,3]  R954      -6.5498644113540649e-01
    z[2,3,3]  R955      -4.8331132531166077e-01
    z[2,3,3]  R956      6.9152086973190308e-01
    z[2,3,3]  R957      4.8625549674034119e-01
    z[2,3,3]  R958      5.0809867680072784e-02
    z[2,3,3]  R959      7.3908466100692749e-01
    z[2,3,3]  R960      -4.5410543680191040e-02
    z[2,3,3]  R961      -2.5981745123863220e-01
    z[2,3,3]  R962      -3.5016742348670959e-01
    z[2,3,3]  R963      -5.8826500177383423e-01
    z[2,3,3]  R964      -5.9510171413421631e-01
    z[2,3,3]  R965      4.4107037782669067e-01
    z[2,3,3]  R966      8.3597046136856079e-01
    z[2,3,3]  R967      8.7238538265228271e-01
    z[2,3,3]  R968      2.2495311498641968e-01
    z[2,3,3]  R969      2.1142323315143585e-01
    z[2,3,3]  R970      1.0871886461973190e-01
    z[2,3,3]  R971      -2.1498848497867584e-01
    z[2,3,3]  R972      2.7603426575660706e-01
    z[2,3,3]  R973      -3.3645071089267731e-02
    z[2,3,3]  R974      -9.7489524632692337e-03
    z[2,3,3]  R975      -1.8885856866836548e-01
    z[2,3,3]  R976      2.1941512823104858e-01
    z[2,3,3]  R977      1.1851963587105274e-02
    z[2,3,3]  R978      -5.8438103646039963e-02
    z[2,3,3]  R979      0.045077845454216
    z[2,3,3]  R980      3.5778489708900452e-01
    z[2,3,3]  R981      5.2593439817428589e-01
    z[2,3,3]  R982      8.0375157296657562e-02
    z[2,3,3]  R983      3.9720643311738968e-02
    z[2,3,3]  R984      -3.7784284353256226e-01
    z[2,3,3]  R985      1.4121010899543762e-01
    z[2,3,3]  R986      -4.6531671285629272e-01
    z[2,3,3]  R987      -1.1461026966571808e-02
    z[2,3,3]  R988      -3.4973528236150742e-02
    z[2,3,3]  R989      1.7360763251781464e-01
    z[2,3,3]  R990      -5.9369200468063354e-01
    z[2,3,3]  R991      5.9511110186576843e-02
    z[2,3,3]  R992      -6.6745573282241821e-01
    z[2,3,3]  R993      -5.3625065833330154e-02
    z[2,3,3]  R994      -5.7023368775844574e-02
    z[2,3,3]  R995      1.3739582896232605e-01
    z[2,3,3]  R996      1.2602323293685913e-01
    z[2,3,3]  R997      1.6580019891262054e-01
    z[2,3,3]  R998      4.8164751380681992e-02
    z[2,3,3]  R999      -1.5695963799953461e-01
    z[2,3,3]  R1000     5.0392758846282959e-01
    z[2,3,3]  R1001     -4.8290807008743286e-01
    z[2,3,3]  R1002     -4.1087540984153748e-01
    z[2,3,3]  R1003     -2.4842780828475952e-01
    z[2,3,3]  R1004     4.7737839818000793e-01
    z[2,3,3]  R1005     -3.4771889448165894e-01
    z[2,3,3]  R1006     3.4257954359054565e-01
    z[2,3,3]  R1007     0.376578152179718
    z[2,3,3]  R1008     -0.270519495010376
    z[2,3,3]  R1009     9.1828359290957451e-03
    z[2,3,3]  R1010     -9.3843534588813782e-02
    z[2,3,3]  R1011     1.2134262919425964e-01
    z[2,3,3]  R1012     1.5632796287536621e-01
    z[2,3,3]  R1013     1.5583147108554840e-01
    z[2,3,4]  R24       -1
    z[2,3,4]  R33       1
    z[2,3,4]  R898      -1
    z[2,3,4]  R899      1
    z[2,3,4]  R904      -1.2899169325828552e-01
    z[2,3,4]  R905      -7.8646056354045868e-02
    z[2,3,4]  R906      -3.1243902444839478e-01
    z[2,3,4]  R907      -3.5084882378578186e-01
    z[2,3,4]  R908      4.9095014110207558e-03
    z[2,3,4]  R909      -2.2748914361000061e-01
    z[2,3,4]  R910      2.7913349866867065e-01
    z[2,3,4]  R911      -1.1331176012754440e-01
    z[2,3,4]  R912      -1.6841015219688416e-01
    z[2,3,4]  R913      1.2260024249553680e-01
    z[2,3,4]  R914      -2.2443506121635437e-01
    z[2,3,4]  R915      1.1996795237064362e-01
    z[2,3,4]  R916      1.7525520920753479e-01
    z[2,3,4]  R917      1.0365176200866699e-01
    z[2,3,4]  R918      9.6559226512908936e-02
    z[2,3,4]  R919      0.200368732213974
    z[2,3,4]  R920      3.1327697634696960e-01
    z[2,3,4]  R921      8.6123727262020111e-02
    z[2,3,4]  R922      -4.3691907078027725e-02
    z[2,3,4]  R923      -1.7748209834098816e-01
    z[2,3,4]  R924      -2.5371336936950684e-01
    z[2,3,4]  R925      -4.9698883295059204e-01
    z[2,3,4]  R926      -3.7619143724441528e-01
    z[2,3,4]  R927      -0.0938776507973671
    z[2,3,4]  R928      -1.9570156931877136e-01
    z[2,3,4]  R929      -1.9608359038829803e-01
    z[2,3,4]  R930      -7.5157403945922852e-02
    z[2,3,4]  R931      -5.9292886406183243e-02
    z[2,3,4]  R932      8.0217522382736206e-01
    z[2,3,4]  R933      8.0292326211929321e-01
    z[2,3,4]  R934      -1.2176158279180527e-01
    z[2,3,4]  R935      3.5552206635475159e-01
    z[2,3,4]  R936      1.0803960263729095e-01
    z[2,3,4]  R937      5.2238047122955322e-01
    z[2,3,4]  R938      3.6268595606088638e-02
    z[2,3,4]  R939      2.2943180799484253e-01
    z[2,3,4]  R940      1.8939814763143659e-03
    z[2,3,4]  R941      -4.4640892744064331e-01
    z[2,3,4]  R942      8.2703399658203125e-01
    z[2,3,4]  R943      6.3625681400299072e-01
    z[2,3,4]  R944      1.1765540577471256e-02
    z[2,3,4]  R945      1.6907185316085815e-01
    z[2,3,4]  R946      -6.3812166452407837e-02
    z[2,3,4]  R947      2.1971662342548370e-01
    z[2,3,4]  R948      6.1889201402664185e-01
    z[2,3,4]  R949      8.9461815357208252e-01
    z[2,3,4]  R950      -4.0109932422637939e-01
    z[2,3,4]  R951      2.2225309908390045e-01
    z[2,3,4]  R952      4.2056638002395630e-01
    z[2,3,4]  R953      6.5803945064544678e-01
    z[2,3,4]  R954      -5.1296311616897583e-01
    z[2,3,4]  R955      -1.9633677601814270e-01
    z[2,3,4]  R956      2.6759955286979675e-01
    z[2,3,4]  R957      0.706939697265625
    z[2,3,4]  R958      8.1082159280776978e-01
    z[2,3,4]  R959      0.498468816280365
    z[2,3,4]  R960      0.851675808429718
    z[2,3,4]  R961      3.3378455042839050e-01
    z[2,3,4]  R962      5.2420613355934620e-03
    z[2,3,4]  R963      -4.4159126281738281e-01
    z[2,3,4]  R964      -5.1426267623901367e-01
    z[2,3,4]  R965      7.2900778055191040e-01
    z[2,3,4]  R966      7.7739447355270386e-02
    z[2,3,4]  R967      1.2438498437404633e-01
    z[2,3,4]  R968      7.5727772712707520e-01
    z[2,3,4]  R969      4.4296798110008240e-01
    z[2,3,4]  R970      3.0513456463813782e-01
    z[2,3,4]  R971      -2.3997746407985687e-01
    z[2,3,4]  R972      7.3908336460590363e-02
    z[2,3,4]  R973      1.9979287683963776e-01
    z[2,3,4]  R974      3.0825203657150269e-01
    z[2,3,4]  R975      0.101965993642807
    z[2,3,4]  R976      -7.2813339531421661e-02
    z[2,3,4]  R977      5.3983730077743530e-01
    z[2,3,4]  R978      2.6378706097602844e-01
    z[2,3,4]  R979      5.3849774599075317e-01
    z[2,3,4]  R980      1.8499688804149628e-01
    z[2,3,4]  R981      1.7156605422496796e-01
    z[2,3,4]  R982      5.0421640276908875e-02
    z[2,3,4]  R983      0.0775560736656189
    z[2,3,4]  R984      9.6017621457576752e-02
    z[2,3,4]  R985      -0.452067106962204
    z[2,3,4]  R986      1.6617333889007568e-01
    z[2,3,4]  R987      -1.8061715364456177e-01
    z[2,3,4]  R988      7.5188815593719482e-02
    z[2,3,4]  R989      -2.5747114419937134e-01
    z[2,3,4]  R990      6.2724113464355469e-02
    z[2,3,4]  R991      -7.3110930621623993e-02
    z[2,3,4]  R992      1.9055263698101044e-01
    z[2,3,4]  R993      -3.1058004498481750e-01
    z[2,3,4]  R994      -2.2223468124866486e-01
    z[2,3,4]  R995      -1.9229148328304291e-01
    z[2,3,4]  R996      -5.6604868173599243e-01
    z[2,3,4]  R997      -2.6208677887916565e-01
    z[2,3,4]  R998      -5.1472359895706177e-01
    z[2,3,4]  R999      -2.4435704946517944e-01
    z[2,3,4]  R1000     -4.8377969861030579e-01
    z[2,3,4]  R1001     -2.3590198159217834e-01
    z[2,3,4]  R1002     0.509386420249939
    z[2,3,4]  R1003     -4.3700519204139709e-01
    z[2,3,4]  R1004     -2.1561256051063538e-01
    z[2,3,4]  R1005     -1.8238714337348938e-01
    z[2,3,4]  R1006     -2.8487563133239746e-01
    z[2,3,4]  R1007     -5.8203574270009995e-02
    z[2,3,4]  R1008     4.1803520172834396e-02
    z[2,3,4]  R1009     1.7025732994079590e-01
    z[2,3,4]  R1010     -2.4461135268211365e-01
    z[2,3,4]  R1011     -1.7198120057582855e-01
    z[2,3,4]  R1012     1.3553853332996368e-01
    z[2,3,4]  R1013     3.7733739614486694e-01
    z[2,3,5]  R25       -1
    z[2,3,5]  R34       1
    z[2,3,5]  R900      -1
    z[2,3,5]  R901      1
    z[2,3,5]  R904      1.5868553519248962e-01
    z[2,3,5]  R905      -1.3307699561119080e-01
    z[2,3,5]  R906      4.5616918802261353e-01
    z[2,3,5]  R907      2.0551607012748718e-01
    z[2,3,5]  R908      -1.8133243918418884e-01
    z[2,3,5]  R909      1.0346614569425583e-01
    z[2,3,5]  R910      -1.3034285604953766e-01
    z[2,3,5]  R911      2.8997424244880676e-01
    z[2,3,5]  R912      -1.0508912801742554e-01
    z[2,3,5]  R913      2.8377994894981384e-01
    z[2,3,5]  R914      -3.8235333561897278e-01
    z[2,3,5]  R915      -4.5161581039428711e-01
    z[2,3,5]  R916      -2.6684507727622986e-01
    z[2,3,5]  R917      -2.4281406402587891e-01
    z[2,3,5]  R918      -5.1673788577318192e-02
    z[2,3,5]  R919      2.9943871498107910e-01
    z[2,3,5]  R920      2.3046833276748657e-01
    z[2,3,5]  R921      -2.0786814391613007e-01
    z[2,3,5]  R922      5.2016609907150269e-01
    z[2,3,5]  R923      -3.8530153036117554e-01
    z[2,3,5]  R924      -2.1397693455219269e-01
    z[2,3,5]  R925      -5.0712251663208008e-01
    z[2,3,5]  R926      -4.4329392910003662e-01
    z[2,3,5]  R927      -0.636333703994751
    z[2,3,5]  R928      -2.1468611061573029e-01
    z[2,3,5]  R929      -5.3010553121566772e-01
    z[2,3,5]  R930      -4.5094919204711914e-01
    z[2,3,5]  R931      2.3007138073444366e-01
    z[2,3,5]  R932      -6.2233596108853817e-03
    z[2,3,5]  R933      2.4792146682739258e-01
    z[2,3,5]  R934      -1.4309531450271606e-01
    z[2,3,5]  R935      -3.3593752980232239e-01
    z[2,3,5]  R936      -3.9521834254264832e-01
    z[2,3,5]  R937      3.8066470623016357e-01
    z[2,3,5]  R938      -3.7482002377510071e-01
    z[2,3,5]  R939      -2.3112215101718903e-01
    z[2,3,5]  R940      -1.9764302670955658e-01
    z[2,3,5]  R941      3.4995386004447937e-01
    z[2,3,5]  R942      0.262921005487442
    z[2,3,5]  R943      7.3634006083011627e-02
    z[2,3,5]  R944      -6.6669160127639771e-01
    z[2,3,5]  R945      -4.7642791271209717e-01
    z[2,3,5]  R946      -6.8624633550643921e-01
    z[2,3,5]  R947      5.4921054840087891e-01
    z[2,3,5]  R948      1.7313297092914581e-01
    z[2,3,5]  R949      1.3795202970504761e-01
    z[2,3,5]  R950      -0.472665399312973
    z[2,3,5]  R951      -3.0621027946472168e-01
    z[2,3,5]  R952      4.4452944397926331e-01
    z[2,3,5]  R953      4.3774670362472534e-01
    z[2,3,5]  R954      -1.1383699625730515e-01
    z[2,3,5]  R955      -5.2780801057815552e-01
    z[2,3,5]  R956      5.5221915245056152e-01
    z[2,3,5]  R957      2.0059312880039215e-01
    z[2,3,5]  R958      -1.3569347560405731e-01
    z[2,3,5]  R959      4.4040087610483170e-02
    z[2,3,5]  R960      8.8828159496188164e-03
    z[2,3,5]  R961      -3.1864476203918457e-01
    z[2,3,5]  R962      -4.9679529666900635e-01
    z[2,3,5]  R963      1.2843219563364983e-02
    z[2,3,5]  R964      -1.8174874782562256e-01
    z[2,3,5]  R965      -1.4751896262168884e-01
    z[2,3,5]  R966      -3.6593183875083923e-02
    z[2,3,5]  R967      -8.8280633091926575e-02
    z[2,3,5]  R968      1.9343499839305878e-01
    z[2,3,5]  R969      -3.6710628867149353e-01
    z[2,3,5]  R970      0.607828676700592
    z[2,3,5]  R971      5.4488813877105713e-01
    z[2,3,5]  R972      0.67137610912323
    z[2,3,5]  R973      4.1305643320083618e-01
    z[2,3,5]  R974      0.288438618183136
    z[2,3,5]  R975      7.3415338993072510e-02
    z[2,3,5]  R976      3.1598886847496033e-01
    z[2,3,5]  R977      2.9113727807998657e-01
    z[2,3,5]  R978      5.9622806310653687e-01
    z[2,3,5]  R979      3.8937801122665405e-01
    z[2,3,5]  R980      1.0548871755599976e-01
    z[2,3,5]  R981      -3.0654066801071167e-01
    z[2,3,5]  R982      -1.3580715656280518e-01
    z[2,3,5]  R983      2.7249258756637573e-01
    z[2,3,5]  R984      -1.0735871642827988e-01
    z[2,3,5]  R985      -5.4265994578599930e-02
    z[2,3,5]  R986      -4.0690630674362183e-01
    z[2,3,5]  R987      -5.0688081979751587e-01
    z[2,3,5]  R988      -3.9016571640968323e-01
    z[2,3,5]  R989      2.6489531993865967e-01
    z[2,3,5]  R990      -2.3758928477764130e-01
    z[2,3,5]  R991      -1.5222407877445221e-01
    z[2,3,5]  R992      -1.7769478261470795e-01
    z[2,3,5]  R993      -5.3262615203857422e-01
    z[2,3,5]  R994      -3.4445360302925110e-01
    z[2,3,5]  R995      -2.3536950349807739e-02
    z[2,3,5]  R996      -4.9152320623397827e-01
    z[2,3,5]  R997      -3.7724217772483826e-01
    z[2,3,5]  R998      -8.8155664503574371e-02
    z[2,3,5]  R999      6.2642043828964233e-01
    z[2,3,5]  R1000     9.6060521900653839e-02
    z[2,3,5]  R1001     3.6358323693275452e-01
    z[2,3,5]  R1002     1.1877653747797012e-01
    z[2,3,5]  R1003     4.1252571344375610e-01
    z[2,3,5]  R1004     -2.3521672189235687e-01
    z[2,3,5]  R1005     3.4173348546028137e-01
    z[2,3,5]  R1006     -2.1266996860504150e-01
    z[2,3,5]  R1007     1.3347616791725159e-01
    z[2,3,5]  R1008     -1.7888711392879486e-01
    z[2,3,5]  R1009     -5.8507549762725830e-01
    z[2,3,5]  R1010     3.9482930302619934e-01
    z[2,3,5]  R1011     -1.5781989693641663e-01
    z[2,3,5]  R1012     3.6871945858001709e-01
    z[2,3,5]  R1013     -2.8889900445938110e-01
    z[2,3,6]  R26       -1
    z[2,3,6]  R35       1
    z[2,3,6]  R902      -1
    z[2,3,6]  R903      1
    z[2,3,6]  R904      -5.0029113888740540e-02
    z[2,3,6]  R905      -2.3115381598472595e-01
    z[2,3,6]  R906      -8.9278884232044220e-02
    z[2,3,6]  R907      -1.0339193791151047e-01
    z[2,3,6]  R908      2.1415881812572479e-01
    z[2,3,6]  R909      -4.6624112129211426e-01
    z[2,3,6]  R910      -3.0351492762565613e-01
    z[2,3,6]  R911      -3.8648679852485657e-01
    z[2,3,6]  R912      -1.0934099555015564e-01
    z[2,3,6]  R913      -2.6732918620109558e-01
    z[2,3,6]  R914      5.1108545064926147e-01
    z[2,3,6]  R915      -7.2644329071044922e-01
    z[2,3,6]  R916      -2.0665641129016876e-01
    z[2,3,6]  R917      -5.1648229360580444e-01
    z[2,3,6]  R918      -2.5272938609123230e-01
    z[2,3,6]  R919      1.3192677497863770e-01
    z[2,3,6]  R920      -9.0538740158081055e-02
    z[2,3,6]  R921      4.9501422047615051e-01
    z[2,3,6]  R922      6.2232349067926407e-02
    z[2,3,6]  R923      -2.6739564538002014e-01
    z[2,3,6]  R924      -2.0970292389392853e-01
    z[2,3,6]  R925      1.6176858544349670e-01
    z[2,3,6]  R926      -2.4438551068305969e-01
    z[2,3,6]  R927      -1.0012000799179077e-01
    z[2,3,6]  R928      -3.2189422845840454e-01
    z[2,3,6]  R929      2.2226870059967041e-01
    z[2,3,6]  R930      -0.262014240026474
    z[2,3,6]  R931      -1.6785086691379547e-01
    z[2,3,6]  R932      3.9106106758117676e-01
    z[2,3,6]  R933      3.4687098860740662e-01
    z[2,3,6]  R934      5.4809689521789551e-02
    z[2,3,6]  R935      -6.6034264862537384e-02
    z[2,3,6]  R936      1.3592340052127838e-01
    z[2,3,6]  R937      1.0662989318370819e-01
    z[2,3,6]  R938      4.2565248906612396e-02
    z[2,3,6]  R939      -5.8749181032180786e-01
    z[2,3,6]  R940      3.6409419775009155e-01
    z[2,3,6]  R941      3.9275979995727539e-01
    z[2,3,6]  R942      -7.0015847682952881e-02
    z[2,3,6]  R943      7.8138843178749084e-02
    z[2,3,6]  R944      1.0038229823112488e-01
    z[2,3,6]  R945      5.6645695120096207e-02
    z[2,3,6]  R946      1.4229616522789001e-01
    z[2,3,6]  R947      1.3901987671852112e-01
    z[2,3,6]  R948      0.23238605260849
    z[2,3,6]  R949      2.2056837379932404e-01
    z[2,3,6]  R950      3.3691248297691345e-01
    z[2,3,6]  R951      1.2322041392326355e-01
    z[2,3,6]  R952      1.0096822865307331e-02
    z[2,3,6]  R953      6.1866792384535074e-04
    z[2,3,6]  R954      0.0417693592607975
    z[2,3,6]  R955      5.0848484039306641e-01
    z[2,3,6]  R956      2.5371477007865906e-01
    z[2,3,6]  R957      -7.3690533638000488e-02
    z[2,3,6]  R958      2.1654383838176727e-01
    z[2,3,6]  R959      1.7860314249992371e-01
    z[2,3,6]  R960      -5.0366683863103390e-03
    z[2,3,6]  R961      -2.3265336453914642e-01
    z[2,3,6]  R962      -6.2715482711791992e-01
    z[2,3,6]  R963      0.556354284286499
    z[2,3,6]  R964      2.7617228031158447e-01
    z[2,3,6]  R965      6.0965497046709061e-02
    z[2,3,6]  R966      3.6251747608184814e-01
    z[2,3,6]  R967      2.1518450975418091e-01
    z[2,3,6]  R968      -3.1988853216171265e-01
    z[2,3,6]  R969      -1.4080493152141571e-01
    z[2,3,6]  R970      4.4668808579444885e-01
    z[2,3,6]  R971      2.3696416616439819e-01
    z[2,3,6]  R972      -1.7106316983699799e-01
    z[2,3,6]  R973      2.4901130795478821e-01
    z[2,3,6]  R974      -1.0111232101917267e-01
    z[2,3,6]  R975      1.3224272429943085e-01
    z[2,3,6]  R976      2.6924493908882141e-01
    z[2,3,6]  R977      3.9693927764892578e-01
    z[2,3,6]  R978      1.9151189923286438e-01
    z[2,3,6]  R979      -3.8249734044075012e-01
    z[2,3,6]  R980      -1.8938811123371124e-01
    z[2,3,6]  R981      -3.3034953474998474e-01
    z[2,3,6]  R982      -4.2161145806312561e-01
    z[2,3,6]  R983      -2.3401927947998047e-01
    z[2,3,6]  R984      1.3225534558296204e-01
    z[2,3,6]  R985      -7.7248126268386841e-02
    z[2,3,6]  R986      5.7576749473810196e-02
    z[2,3,6]  R987      6.1256840825080872e-02
    z[2,3,6]  R988      5.2010113000869751e-01
    z[2,3,6]  R989      4.6250253915786743e-01
    z[2,3,6]  R990      -1.0021121054887772e-01
    z[2,3,6]  R991      -4.1702026128768921e-01
    z[2,3,6]  R992      -9.3552783131599426e-02
    z[2,3,6]  R993      -3.3364757895469666e-01
    z[2,3,6]  R994      1.2438180297613144e-01
    z[2,3,6]  R995      -1.7168733477592468e-01
    z[2,3,6]  R996      2.8000321984291077e-01
    z[2,3,6]  R997      4.7164449095726013e-01
    z[2,3,6]  R998      3.0716332793235779e-01
    z[2,3,6]  R999      -2.8244480490684509e-02
    z[2,3,6]  R1000     3.7792941927909851e-01
    z[2,3,6]  R1001     -1.3606618344783783e-01
    z[2,3,6]  R1002     -1.7522041499614716e-01
    z[2,3,6]  R1003     1.2355015426874161e-01
    z[2,3,6]  R1004     3.5263389348983765e-01
    z[2,3,6]  R1005     -3.6459651589393616e-01
    z[2,3,6]  R1006     1.8081568181514740e-01
    z[2,3,6]  R1007     2.4590662121772766e-01
    z[2,3,6]  R1008     1.0105468332767487e-01
    z[2,3,6]  R1009     0.163529634475708
    z[2,3,6]  R1010     5.2980917692184448e-01
    z[2,3,6]  R1011     5.0102514028549194e-01
    z[2,3,6]  R1012     3.3948723226785660e-02
    z[2,3,6]  R1013     -2.3816585540771484e-02
    z[3,2,0]  R20       1
    z[3,2,0]  R29       -1
    z[3,2,0]  R1014     -1
    z[3,2,0]  R1015     1
    z[3,2,0]  R1028     -6.8427008390426636e-01
    z[3,2,0]  R1029     -1.4818302355706692e-02
    z[3,2,0]  R1030     -3.4127944707870483e-01
    z[3,2,0]  R1031     -3.2248872518539429e-01
    z[3,2,0]  R1032     -4.1533282399177551e-01
    z[3,2,0]  R1033     3.2071336172521114e-03
    z[3,2,0]  R1034     -7.8725844621658325e-02
    z[3,2,0]  R1035     -1.8082509934902191e-01
    z[3,2,0]  R1036     -3.0452203750610352e-01
    z[3,2,0]  R1037     2.1030250191688538e-01
    z[3,2,0]  R1038     -0.369750440120697
    z[3,2,0]  R1039     -3.6885312199592590e-01
    z[3,2,0]  R1040     3.4414097666740417e-01
    z[3,2,0]  R1041     -3.8569509983062744e-01
    z[3,2,0]  R1042     -3.7709867954254150e-01
    z[3,2,0]  R1043     -2.5882118940353394e-01
    z[3,2,0]  R1044     5.3064805269241333e-01
    z[3,2,0]  R1045     -4.6140491962432861e-01
    z[3,2,0]  R1046     1.0283546894788742e-01
    z[3,2,0]  R1047     1.1462587118148804e-01
    z[3,2,0]  R1048     2.0582200586795807e-01
    z[3,2,0]  R1049     -1.8039016425609589e-01
    z[3,2,0]  R1050     -1.4154779911041260e-01
    z[3,2,0]  R1051     2.8120434284210205e-01
    z[3,2,0]  R1052     2.1532581746578217e-01
    z[3,2,0]  R1053     -3.2824245095252991e-01
    z[3,2,0]  R1054     3.4028959274291992e-01
    z[3,2,0]  R1055     2.9312244057655334e-01
    z[3,2,0]  R1056     1.1301513016223907e-01
    z[3,2,0]  R1057     2.0777639746665955e-01
    z[3,2,0]  R1058     -4.3527320027351379e-01
    z[3,2,0]  R1059     1.6804765909910202e-02
    z[3,2,0]  R1060     -1.4892593026161194e-01
    z[3,2,0]  R1061     3.1925755739212036e-01
    z[3,2,0]  R1062     -1.5773749351501465e-01
    z[3,2,0]  R1063     -1.5710341930389404e-01
    z[3,2,0]  R1064     -1.9159191846847534e-01
    z[3,2,0]  R1065     -0.639341413974762
    z[3,2,0]  R1066     1.9629706442356110e-01
    z[3,2,0]  R1067     -2.8094035387039185e-01
    z[3,2,0]  R1068     -4.9124273657798767e-01
    z[3,2,0]  R1069     -7.7634233236312866e-01
    z[3,2,0]  R1070     -4.5373073220252991e-01
    z[3,2,0]  R1071     -6.8108010292053223e-01
    z[3,2,0]  R1072     -7.1953850984573364e-01
    z[3,2,0]  R1073     -4.6407660841941833e-01
    z[3,2,0]  R1074     -3.3312138915061951e-01
    z[3,2,0]  R1075     -7.2410744428634644e-01
    z[3,2,0]  R1076     -6.1397582292556763e-01
    z[3,2,0]  R1077     -1.4422667026519775e-01
    z[3,2,0]  R1078     6.1473723500967026e-02
    z[3,2,0]  R1079     0.153394877910614
    z[3,2,0]  R1080     -2.0218744874000549e-01
    z[3,2,0]  R1081     -1.8500488996505737e-01
    z[3,2,0]  R1082     1.5352945029735565e-01
    z[3,2,0]  R1083     9.4493657350540161e-02
    z[3,2,0]  R1084     -0.059889055788517
    z[3,2,0]  R1085     2.3794810473918915e-01
    z[3,2,0]  R1086     -2.4597447365522385e-02
    z[3,2,0]  R1087     4.5672440528869629e-01
    z[3,2,0]  R1088     4.7142812609672546e-01
    z[3,2,0]  R1089     2.4861901998519897e-02
    z[3,2,0]  R1090     -1.4215698838233948e-01
    z[3,2,0]  R1091     5.0571531057357788e-01
    z[3,2,0]  R1092     1.2481260299682617e-01
    z[3,2,0]  R1093     -4.0614360570907593e-01
    z[3,2,0]  R1094     -1.9890600442886353e-01
    z[3,2,0]  R1095     1.8972903490066528e-02
    z[3,2,0]  R1096     -6.2058974057435989e-02
    z[3,2,0]  R1097     -1.0376165807247162e-01
    z[3,2,0]  R1098     -1.7810884118080139e-01
    z[3,2,0]  R1099     9.4430714845657349e-02
    z[3,2,0]  R1100     1.2676912546157837e-01
    z[3,2,0]  R1101     -1.5843637287616730e-01
    z[3,2,0]  R1102     4.0129086375236511e-01
    z[3,2,0]  R1103     2.0959985256195068e-01
    z[3,2,0]  R1104     4.2695617675781250e-01
    z[3,2,0]  R1105     -8.0943085253238678e-02
    z[3,2,0]  R1106     -3.6984920501708984e-01
    z[3,2,0]  R1107     -6.6380125284194946e-01
    z[3,2,0]  R1108     -4.9481880851089954e-03
    z[3,2,0]  R1109     -6.7595876753330231e-03
    z[3,2,0]  R1110     2.1995209157466888e-01
    z[3,2,0]  R1111     -5.0826031714677811e-02
    z[3,2,0]  R1112     4.4874809682369232e-02
    z[3,2,0]  R1113     -3.3454048633575439e-01
    z[3,2,0]  R1114     2.5708615779876709e-01
    z[3,2,0]  R1115     6.0063779354095459e-01
    z[3,2,0]  R1116     -6.4115297794342041e-01
    z[3,2,0]  R1117     -3.8052040338516235e-01
    z[3,2,0]  R1118     2.9909870028495789e-01
    z[3,2,0]  R1119     -1.2768530286848545e-02
    z[3,2,0]  R1120     -2.4318021535873413e-01
    z[3,2,0]  R1121     6.0623455792665482e-02
    z[3,2,0]  R1122     -4.2846912145614624e-01
    z[3,2,0]  R1123     -2.1448197960853577e-01
    z[3,2,0]  R1124     -3.8751190900802612e-01
    z[3,2,0]  R1125     5.0506293773651123e-01
    z[3,2,0]  R1126     2.9371036216616631e-02
    z[3,2,0]  R1127     -1.8463903665542603e-01
    z[3,2,0]  R1128     -1.7569494247436523e-01
    z[3,2,0]  R1129     -3.0998736619949341e-01
    z[3,2,0]  R1130     -0.0892467051744461
    z[3,2,0]  R1131     3.0539789795875549e-01
    z[3,2,0]  R1132     -3.7317898869514465e-01
    z[3,2,0]  R1133     4.7704753279685974e-01
    z[3,2,0]  R1134     3.6393198370933533e-01
    z[3,2,0]  R1135     6.0187149047851562e-01
    z[3,2,0]  R1136     0.573669970035553
    z[3,2,0]  R1137     6.0565555095672607e-01
    z[3,2,1]  R21       1
    z[3,2,1]  R30       -1
    z[3,2,1]  R1016     -1
    z[3,2,1]  R1017     1
    z[3,2,1]  R1028     -5.6477773189544678e-01
    z[3,2,1]  R1029     -7.5187635421752930e-01
    z[3,2,1]  R1030     -6.2260061502456665e-01
    z[3,2,1]  R1031     -4.6212467551231384e-01
    z[3,2,1]  R1032     -3.4248134493827820e-01
    z[3,2,1]  R1033     -5.2284485101699829e-01
    z[3,2,1]  R1034     -5.7583832740783691e-01
    z[3,2,1]  R1035     -0.672904372215271
    z[3,2,1]  R1036     7.6640832424163818e-01
    z[3,2,1]  R1037     8.8993984460830688e-01
    z[3,2,1]  R1038     0.696917712688446
    z[3,2,1]  R1039     7.6524215936660767e-01
    z[3,2,1]  R1040     5.4195505380630493e-01
    z[3,2,1]  R1041     0.670072078704834
    z[3,2,1]  R1042     6.4999777078628540e-01
    z[3,2,1]  R1043     7.1910876035690308e-01
    z[3,2,1]  R1044     2.6219698786735535e-01
    z[3,2,1]  R1045     6.5600740909576416e-01
    z[3,2,1]  R1046     0.321405291557312
    z[3,2,1]  R1047     5.5682206153869629e-01
    z[3,2,1]  R1048     0.855639636516571
    z[3,2,1]  R1049     9.2047715187072754e-01
    z[3,2,1]  R1050     -5.6608009338378906e-01
    z[3,2,1]  R1051     -6.5798693895339966e-01
    z[3,2,1]  R1052     -7.5619047880172729e-01
    z[3,2,1]  R1053     6.1508959531784058e-01
    z[3,2,1]  R1054     -4.8962280154228210e-01
    z[3,2,1]  R1055     5.5734282732009888e-01
    z[3,2,1]  R1056     6.2382537126541138e-01
    z[3,2,1]  R1057     6.9943684339523315e-01
    z[3,2,1]  R1058     -5.6367683410644531e-01
    z[3,2,1]  R1059     7.6815813779830933e-01
    z[3,2,1]  R1060     -7.6969122886657715e-01
    z[3,2,1]  R1061     -7.3696362972259521e-01
    z[3,2,1]  R1062     -9.2049682140350342e-01
    z[3,2,1]  R1063     -7.5868427753448486e-01
    z[3,2,1]  R1064     6.7385560274124146e-01
    z[3,2,1]  R1065     5.2036279439926147e-01
    z[3,2,1]  R1066     0.868614137172699
    z[3,2,1]  R1067     8.1428307294845581e-01
    z[3,2,1]  R1068     -4.4544604420661926e-01
    z[3,2,1]  R1069     -4.0777593851089478e-01
    z[3,2,1]  R1070     -4.2607891559600830e-01
    z[3,2,1]  R1071     -2.7949529886245728e-01
    z[3,2,1]  R1072     -0.350705623626709
    z[3,2,1]  R1073     -0.363901287317276
    z[3,2,1]  R1074     -4.9221006035804749e-01
    z[3,2,1]  R1075     -3.8024628162384033e-01
    z[3,2,1]  R1076     0.237028107047081
    z[3,2,1]  R1077     -8.7349957227706909e-01
    z[3,2,1]  R1078     -2.5577083230018616e-01
    z[3,2,1]  R1079     2.4164129793643951e-01
    z[3,2,1]  R1080     0.829850971698761
    z[3,2,1]  R1081     6.4701384305953979e-01
    z[3,2,1]  R1082     9.1239744424819946e-01
    z[3,2,1]  R1083     8.7869280576705933e-01
    z[3,2,1]  R1084     8.8222002983093262e-01
    z[3,2,1]  R1085     3.3945631980895996e-01
    z[3,2,1]  R1086     7.9038488864898682e-01
    z[3,2,1]  R1087     4.7249439358711243e-01
    z[3,2,1]  R1088     -2.5328485295176506e-02
    z[3,2,1]  R1089     -4.2231306433677673e-01
    z[3,2,1]  R1090     1.6041561961174011e-01
    z[3,2,1]  R1091     9.7372457385063171e-02
    z[3,2,1]  R1092     3.9665067195892334e-01
    z[3,2,1]  R1093     5.0427418947219849e-01
    z[3,2,1]  R1094     -2.2575311362743378e-01
    z[3,2,1]  R1095     2.1479836106300354e-01
    z[3,2,1]  R1096     2.1152751147747040e-01
    z[3,2,1]  R1097     2.3155732452869415e-01
    z[3,2,1]  R1098     -2.0896512269973755e-01
    z[3,2,1]  R1099     -8.6768402252346277e-04
    z[3,2,1]  R1100     4.8274621367454529e-01
    z[3,2,1]  R1101     3.2020667195320129e-01
    z[3,2,1]  R1102     1.8010555207729340e-01
    z[3,2,1]  R1103     -4.0624219179153442e-01
    z[3,2,1]  R1104     -4.6342805027961731e-02
    z[3,2,1]  R1105     2.6514491438865662e-01
    z[3,2,1]  R1106     2.3521491885185242e-01
    z[3,2,1]  R1107     2.4544388055801392e-01
    z[3,2,1]  R1108     -8.3455711603164673e-02
    z[3,2,1]  R1109     1.5370737016201019e-01
    z[3,2,1]  R1110     2.3272086679935455e-01
    z[3,2,1]  R1111     3.5309621691703796e-01
    z[3,2,1]  R1112     1.4941997826099396e-01
    z[3,2,1]  R1113     -3.7667483091354370e-02
    z[3,2,1]  R1114     4.8218145966529846e-01
    z[3,2,1]  R1115     -1.7782464623451233e-01
    z[3,2,1]  R1116     3.9055651426315308e-01
    z[3,2,1]  R1117     4.6254959702491760e-01
    z[3,2,1]  R1118     2.5293555110692978e-02
    z[3,2,1]  R1119     1.9626750051975250e-01
    z[3,2,1]  R1120     9.6097335219383240e-02
    z[3,2,1]  R1121     1.5056197345256805e-01
    z[3,2,1]  R1122     1.8992094695568085e-01
    z[3,2,1]  R1123     3.4925243258476257e-01
    z[3,2,1]  R1124     -9.8732315003871918e-02
    z[3,2,1]  R1125     -1.1955556273460388e-01
    z[3,2,1]  R1126     -4.8471504449844360e-01
    z[3,2,1]  R1127     3.3883380889892578e-01
    z[3,2,1]  R1128     -4.6554881334304810e-01
    z[3,2,1]  R1129     8.7587319314479828e-02
    z[3,2,1]  R1130     3.0281466245651245e-01
    z[3,2,1]  R1131     0.00760143157094717
    z[3,2,1]  R1132     2.8109899163246155e-01
    z[3,2,1]  R1133     4.2320245504379272e-01
    z[3,2,1]  R1134     -2.1706353127956390e-01
    z[3,2,1]  R1135     -3.9704304933547974e-01
    z[3,2,1]  R1136     -1.0005540400743484e-01
    z[3,2,1]  R1137     -0.344194233417511
    z[3,2,2]  R22       1
    z[3,2,2]  R31       -1
    z[3,2,2]  R1018     -1
    z[3,2,2]  R1019     1
    z[3,2,2]  R1028     -1.5577442944049835e-01
    z[3,2,2]  R1029     -6.0458236932754517e-01
    z[3,2,2]  R1030     -5.1972138881683350e-01
    z[3,2,2]  R1031     -3.8542884588241577e-01
    z[3,2,2]  R1032     -4.9501702189445496e-01
    z[3,2,2]  R1033     -3.6971840262413025e-01
    z[3,2,2]  R1034     -0.673039972782135
    z[3,2,2]  R1035     7.3226056993007660e-02
    z[3,2,2]  R1036     -3.3864775300025940e-01
    z[3,2,2]  R1037     -1.6483345627784729e-01
    z[3,2,2]  R1038     4.4338285923004150e-01
    z[3,2,2]  R1039     2.1244935691356659e-01
    z[3,2,2]  R1040     4.1812750697135925e-01
    z[3,2,2]  R1041     3.2986089587211609e-01
    z[3,2,2]  R1042     7.5422719120979309e-02
    z[3,2,2]  R1043     -1.8810895085334778e-01
    z[3,2,2]  R1044     4.7620362043380737e-01
    z[3,2,2]  R1045     3.8832318782806396e-01
    z[3,2,2]  R1046     6.0331451892852783e-01
    z[3,2,2]  R1047     4.2715713381767273e-01
    z[3,2,2]  R1048     1.9687317311763763e-01
    z[3,2,2]  R1049     1.8519483506679535e-01
    z[3,2,2]  R1050     -0.0568130724132061
    z[3,2,2]  R1051     -1.6443207859992981e-01
    z[3,2,2]  R1052     1.1148890107870102e-01
    z[3,2,2]  R1053     1.9072158634662628e-01
    z[3,2,2]  R1054     -0.0665467232465744
    z[3,2,2]  R1055     4.0483516454696655e-01
    z[3,2,2]  R1056     3.5350584983825684e-01
    z[3,2,2]  R1057     1.7171221971511841e-01
    z[3,2,2]  R1058     -1.9684784114360809e-01
    z[3,2,2]  R1059     7.5926974415779114e-02
    z[3,2,2]  R1060     -3.3008918166160583e-01
    z[3,2,2]  R1061     -3.6259409785270691e-01
    z[3,2,2]  R1062     1.0326393693685532e-01
    z[3,2,2]  R1063     -3.9868235588073730e-02
    z[3,2,2]  R1064     -6.3102908432483673e-02
    z[3,2,2]  R1065     -0.0151675371453166
    z[3,2,2]  R1066     -1.6450341045856476e-01
    z[3,2,2]  R1067     8.5549578070640564e-02
    z[3,2,2]  R1068     -5.0723069906234741e-01
    z[3,2,2]  R1069     -3.0221751332283020e-01
    z[3,2,2]  R1070     -5.4670047760009766e-01
    z[3,2,2]  R1071     -5.1954925060272217e-01
    z[3,2,2]  R1072     -3.8589019328355789e-02
    z[3,2,2]  R1073     -6.0903567075729370e-01
    z[3,2,2]  R1074     -4.8527535051107407e-02
    z[3,2,2]  R1075     -2.2927054762840271e-01
    z[3,2,2]  R1076     -6.1901479959487915e-01
    z[3,2,2]  R1077     3.8353729993104935e-02
    z[3,2,2]  R1078     4.4338819384574890e-01
    z[3,2,2]  R1079     -3.2167810946702957e-02
    z[3,2,2]  R1080     3.1972485780715942e-01
    z[3,2,2]  R1081     5.0286766141653061e-02
    z[3,2,2]  R1082     1.2339603155851364e-01
    z[3,2,2]  R1083     2.6287573575973511e-01
    z[3,2,2]  R1084     2.2269165515899658e-01
    z[3,2,2]  R1085     6.6414773464202881e-01
    z[3,2,2]  R1086     7.4134194292128086e-03
    z[3,2,2]  R1087     -2.6723316311836243e-01
    z[3,2,2]  R1088     -0.0663272812962532
    z[3,2,2]  R1089     -3.2018488645553589e-01
    z[3,2,2]  R1090     -3.5017940402030945e-01
    z[3,2,2]  R1091     1.4386005699634552e-01
    z[3,2,2]  R1092     -8.9014537632465363e-02
    z[3,2,2]  R1093     1.2869903445243835e-01
    z[3,2,2]  R1094     3.2295051217079163e-01
    z[3,2,2]  R1095     3.2745265960693359e-01
    z[3,2,2]  R1096     -2.7053061127662659e-01
    z[3,2,2]  R1097     -3.1839540600776672e-01
    z[3,2,2]  R1098     4.8677217960357666e-01
    z[3,2,2]  R1099     8.2149881124496460e-01
    z[3,2,2]  R1100     5.7530528306961060e-01
    z[3,2,2]  R1101     1.1776317656040192e-01
    z[3,2,2]  R1102     -4.4055002927780151e-01
    z[3,2,2]  R1103     3.9006423950195312e-01
    z[3,2,2]  R1104     -2.8825944662094116e-01
    z[3,2,2]  R1105     -1.3484659790992737e-01
    z[3,2,2]  R1106     2.1095946431159973e-01
    z[3,2,2]  R1107     -1.1477702856063843e-01
    z[3,2,2]  R1108     5.4724162817001343e-01
    z[3,2,2]  R1109     -2.2157758474349976e-01
    z[3,2,2]  R1110     3.6912760138511658e-01
    z[3,2,2]  R1111     -1.3935816287994385e-01
    z[3,2,2]  R1112     -1.5904602408409119e-01
    z[3,2,2]  R1113     -1.1023134738206863e-01
    z[3,2,2]  R1114     -3.6716946959495544e-01
    z[3,2,2]  R1115     6.4137715101242065e-01
    z[3,2,2]  R1116     4.7803804278373718e-02
    z[3,2,2]  R1117     -1.0268244892358780e-01
    z[3,2,2]  R1118     -4.5061972737312317e-01
    z[3,2,2]  R1119     3.8992297649383545e-01
    z[3,2,2]  R1120     1.1180755496025085e-01
    z[3,2,2]  R1121     -4.3792682886123657e-01
    z[3,2,2]  R1122     -2.3457825183868408e-01
    z[3,2,2]  R1123     5.8858606964349747e-02
    z[3,2,2]  R1124     -3.3551222085952759e-01
    z[3,2,2]  R1125     0.629315972328186
    z[3,2,2]  R1126     -3.7618912756443024e-02
    z[3,2,2]  R1127     -1.8613802269101143e-02
    z[3,2,2]  R1128     -1.5646006166934967e-01
    z[3,2,2]  R1129     -3.8047635555267334e-01
    z[3,2,2]  R1130     -2.5038030743598938e-01
    z[3,2,2]  R1131     -2.7576902508735657e-01
    z[3,2,2]  R1132     -1.3379658758640289e-01
    z[3,2,2]  R1133     4.4476044178009033e-01
    z[3,2,2]  R1134     -3.8278463482856750e-01
    z[3,2,2]  R1135     -1.5245710313320160e-01
    z[3,2,2]  R1136     -3.1500127911567688e-01
    z[3,2,2]  R1137     -4.9095860123634338e-01
    z[3,2,3]  R23       1
    z[3,2,3]  R32       -1
    z[3,2,3]  R1020     -1
    z[3,2,3]  R1021     1
    z[3,2,3]  R1028     -9.7489524632692337e-03
    z[3,2,3]  R1029     -1.8885856866836548e-01
    z[3,2,3]  R1030     2.1941512823104858e-01
    z[3,2,3]  R1031     1.1851963587105274e-02
    z[3,2,3]  R1032     -5.8438103646039963e-02
    z[3,2,3]  R1033     0.045077845454216
    z[3,2,3]  R1034     3.5778489708900452e-01
    z[3,2,3]  R1035     5.2593439817428589e-01
    z[3,2,3]  R1036     8.0375157296657562e-02
    z[3,2,3]  R1037     3.9720643311738968e-02
    z[3,2,3]  R1038     -3.7784284353256226e-01
    z[3,2,3]  R1039     1.4121010899543762e-01
    z[3,2,3]  R1040     -4.6531671285629272e-01
    z[3,2,3]  R1041     -1.1461026966571808e-02
    z[3,2,3]  R1042     -3.4973528236150742e-02
    z[3,2,3]  R1043     1.7360763251781464e-01
    z[3,2,3]  R1044     -5.9369200468063354e-01
    z[3,2,3]  R1045     5.9511110186576843e-02
    z[3,2,3]  R1046     -6.6745573282241821e-01
    z[3,2,3]  R1047     -5.3625065833330154e-02
    z[3,2,3]  R1048     -5.7023368775844574e-02
    z[3,2,3]  R1049     1.3739582896232605e-01
    z[3,2,3]  R1050     1.2602323293685913e-01
    z[3,2,3]  R1051     1.6580019891262054e-01
    z[3,2,3]  R1052     4.8164751380681992e-02
    z[3,2,3]  R1053     -1.5695963799953461e-01
    z[3,2,3]  R1054     5.0392758846282959e-01
    z[3,2,3]  R1055     -4.8290807008743286e-01
    z[3,2,3]  R1056     -4.1087540984153748e-01
    z[3,2,3]  R1057     -2.4842780828475952e-01
    z[3,2,3]  R1058     4.7737839818000793e-01
    z[3,2,3]  R1059     -3.4771889448165894e-01
    z[3,2,3]  R1060     3.4257954359054565e-01
    z[3,2,3]  R1061     0.376578152179718
    z[3,2,3]  R1062     -0.270519495010376
    z[3,2,3]  R1063     9.1828359290957451e-03
    z[3,2,3]  R1064     -9.3843534588813782e-02
    z[3,2,3]  R1065     1.2134262919425964e-01
    z[3,2,3]  R1066     1.5632796287536621e-01
    z[3,2,3]  R1067     1.5583147108554840e-01
    z[3,2,3]  R1068     5.0857901573181152e-01
    z[3,2,3]  R1069     2.4969819188117981e-01
    z[3,2,3]  R1070     4.9621476791799068e-03
    z[3,2,3]  R1071     -1.0981449484825134e-01
    z[3,2,3]  R1072     5.2821516990661621e-01
    z[3,2,3]  R1073     -3.8038119673728943e-02
    z[3,2,3]  R1074     6.7629760503768921e-01
    z[3,2,3]  R1075     -1.7949819564819336e-01
    z[3,2,3]  R1076     3.6374571919441223e-01
    z[3,2,3]  R1077     2.1840167045593262e-01
    z[3,2,3]  R1078     -0.52577143907547
    z[3,2,3]  R1079     -4.1349199414253235e-01
    z[3,2,3]  R1080     -1.5367542207241058e-01
    z[3,2,3]  R1081     -4.5624691247940063e-01
    z[3,2,3]  R1082     -2.2992837429046631e-01
    z[3,2,3]  R1083     -5.1483251154422760e-02
    z[3,2,3]  R1084     9.5154352486133575e-02
    z[3,2,3]  R1085     -3.0231153964996338e-01
    z[3,2,3]  R1086     -3.1349179148674011e-01
    z[3,2,3]  R1087     -4.9525824189186096e-01
    z[3,2,3]  R1088     -7.8650033473968506e-01
    z[3,2,3]  R1089     -4.3379139900207520e-01
    z[3,2,3]  R1090     -6.5854293107986450e-01
    z[3,2,3]  R1091     -5.3881102800369263e-01
    z[3,2,3]  R1092     -7.9445666074752808e-01
    z[3,2,3]  R1093     -4.4195863604545593e-01
    z[3,2,3]  R1094     -7.2630548477172852e-01
    z[3,2,3]  R1095     -8.7272793054580688e-01
    z[3,2,3]  R1096     2.8594639897346497e-01
    z[3,2,3]  R1097     0.0881413072347641
    z[3,2,3]  R1098     -8.0582714080810547e-01
    z[3,2,3]  R1099     -2.6946470141410828e-01
    z[3,2,3]  R1100     -4.8328486084938049e-01
    z[3,2,3]  R1101     6.5524083375930786e-01
    z[3,2,3]  R1102     6.8470877408981323e-01
    z[3,2,3]  R1103     -4.3322277069091797e-01
    z[3,2,3]  R1104     7.4889016151428223e-01
    z[3,2,3]  R1105     -6.5494573116302490e-01
    z[3,2,3]  R1106     7.3258213698863983e-02
    z[3,2,3]  R1107     -2.6382020115852356e-01
    z[3,2,3]  R1108     -4.8871728777885437e-01
    z[3,2,3]  R1109     8.1759041547775269e-01
    z[3,2,3]  R1110     -0.515705943107605
    z[3,2,3]  R1111     0.695762038230896
    z[3,2,3]  R1112     6.9523996114730835e-01
    z[3,2,3]  R1113     8.0560527741909027e-02
    z[3,2,3]  R1114     -2.6228037476539612e-01
    z[3,2,3]  R1115     -1.9468809664249420e-01
    z[3,2,3]  R1116     2.4396492540836334e-01
    z[3,2,3]  R1117     0.0779092013835907
    z[3,2,3]  R1118     -6.5498644113540649e-01
    z[3,2,3]  R1119     -4.8331132531166077e-01
    z[3,2,3]  R1120     6.9152086973190308e-01
    z[3,2,3]  R1121     4.8625549674034119e-01
    z[3,2,3]  R1122     5.0809867680072784e-02
    z[3,2,3]  R1123     7.3908466100692749e-01
    z[3,2,3]  R1124     -4.5410543680191040e-02
    z[3,2,3]  R1125     -2.5981745123863220e-01
    z[3,2,3]  R1126     -3.5016742348670959e-01
    z[3,2,3]  R1127     -5.8826500177383423e-01
    z[3,2,3]  R1128     -5.9510171413421631e-01
    z[3,2,3]  R1129     4.4107037782669067e-01
    z[3,2,3]  R1130     8.3597046136856079e-01
    z[3,2,3]  R1131     8.7238538265228271e-01
    z[3,2,3]  R1132     2.2495311498641968e-01
    z[3,2,3]  R1133     2.1142323315143585e-01
    z[3,2,3]  R1134     1.0871886461973190e-01
    z[3,2,3]  R1135     -2.1498848497867584e-01
    z[3,2,3]  R1136     2.7603426575660706e-01
    z[3,2,3]  R1137     -3.3645071089267731e-02
    z[3,2,4]  R24       1
    z[3,2,4]  R33       -1
    z[3,2,4]  R1022     -1
    z[3,2,4]  R1023     1
    z[3,2,4]  R1028     3.0825203657150269e-01
    z[3,2,4]  R1029     0.101965993642807
    z[3,2,4]  R1030     -7.2813339531421661e-02
    z[3,2,4]  R1031     5.3983730077743530e-01
    z[3,2,4]  R1032     2.6378706097602844e-01
    z[3,2,4]  R1033     5.3849774599075317e-01
    z[3,2,4]  R1034     1.8499688804149628e-01
    z[3,2,4]  R1035     1.7156605422496796e-01
    z[3,2,4]  R1036     5.0421640276908875e-02
    z[3,2,4]  R1037     0.0775560736656189
    z[3,2,4]  R1038     9.6017621457576752e-02
    z[3,2,4]  R1039     -0.452067106962204
    z[3,2,4]  R1040     1.6617333889007568e-01
    z[3,2,4]  R1041     -1.8061715364456177e-01
    z[3,2,4]  R1042     7.5188815593719482e-02
    z[3,2,4]  R1043     -2.5747114419937134e-01
    z[3,2,4]  R1044     6.2724113464355469e-02
    z[3,2,4]  R1045     -7.3110930621623993e-02
    z[3,2,4]  R1046     1.9055263698101044e-01
    z[3,2,4]  R1047     -3.1058004498481750e-01
    z[3,2,4]  R1048     -2.2223468124866486e-01
    z[3,2,4]  R1049     -1.9229148328304291e-01
    z[3,2,4]  R1050     -5.6604868173599243e-01
    z[3,2,4]  R1051     -2.6208677887916565e-01
    z[3,2,4]  R1052     -5.1472359895706177e-01
    z[3,2,4]  R1053     -2.4435704946517944e-01
    z[3,2,4]  R1054     -4.8377969861030579e-01
    z[3,2,4]  R1055     -2.3590198159217834e-01
    z[3,2,4]  R1056     0.509386420249939
    z[3,2,4]  R1057     -4.3700519204139709e-01
    z[3,2,4]  R1058     -2.1561256051063538e-01
    z[3,2,4]  R1059     -1.8238714337348938e-01
    z[3,2,4]  R1060     -2.8487563133239746e-01
    z[3,2,4]  R1061     -5.8203574270009995e-02
    z[3,2,4]  R1062     4.1803520172834396e-02
    z[3,2,4]  R1063     1.7025732994079590e-01
    z[3,2,4]  R1064     -2.4461135268211365e-01
    z[3,2,4]  R1065     -1.7198120057582855e-01
    z[3,2,4]  R1066     1.3553853332996368e-01
    z[3,2,4]  R1067     3.7733739614486694e-01
    z[3,2,4]  R1068     -1.2899169325828552e-01
    z[3,2,4]  R1069     -7.8646056354045868e-02
    z[3,2,4]  R1070     -3.1243902444839478e-01
    z[3,2,4]  R1071     -3.5084882378578186e-01
    z[3,2,4]  R1072     4.9095014110207558e-03
    z[3,2,4]  R1073     -2.2748914361000061e-01
    z[3,2,4]  R1074     2.7913349866867065e-01
    z[3,2,4]  R1075     -1.1331176012754440e-01
    z[3,2,4]  R1076     -1.6841015219688416e-01
    z[3,2,4]  R1077     1.2260024249553680e-01
    z[3,2,4]  R1078     -2.2443506121635437e-01
    z[3,2,4]  R1079     1.1996795237064362e-01
    z[3,2,4]  R1080     1.7525520920753479e-01
    z[3,2,4]  R1081     1.0365176200866699e-01
    z[3,2,4]  R1082     9.6559226512908936e-02
    z[3,2,4]  R1083     0.200368732213974
    z[3,2,4]  R1084     3.1327697634696960e-01
    z[3,2,4]  R1085     8.6123727262020111e-02
    z[3,2,4]  R1086     -4.3691907078027725e-02
    z[3,2,4]  R1087     -1.7748209834098816e-01
    z[3,2,4]  R1088     -2.5371336936950684e-01
    z[3,2,4]  R1089     -4.9698883295059204e-01
    z[3,2,4]  R1090     -3.7619143724441528e-01
    z[3,2,4]  R1091     -0.0938776507973671
    z[3,2,4]  R1092     -1.9570156931877136e-01
    z[3,2,4]  R1093     -1.9608359038829803e-01
    z[3,2,4]  R1094     -7.5157403945922852e-02
    z[3,2,4]  R1095     -5.9292886406183243e-02
    z[3,2,4]  R1096     8.0217522382736206e-01
    z[3,2,4]  R1097     8.0292326211929321e-01
    z[3,2,4]  R1098     -1.2176158279180527e-01
    z[3,2,4]  R1099     3.5552206635475159e-01
    z[3,2,4]  R1100     1.0803960263729095e-01
    z[3,2,4]  R1101     5.2238047122955322e-01
    z[3,2,4]  R1102     3.6268595606088638e-02
    z[3,2,4]  R1103     2.2943180799484253e-01
    z[3,2,4]  R1104     1.8939814763143659e-03
    z[3,2,4]  R1105     -4.4640892744064331e-01
    z[3,2,4]  R1106     8.2703399658203125e-01
    z[3,2,4]  R1107     6.3625681400299072e-01
    z[3,2,4]  R1108     1.1765540577471256e-02
    z[3,2,4]  R1109     1.6907185316085815e-01
    z[3,2,4]  R1110     -6.3812166452407837e-02
    z[3,2,4]  R1111     2.1971662342548370e-01
    z[3,2,4]  R1112     6.1889201402664185e-01
    z[3,2,4]  R1113     8.9461815357208252e-01
    z[3,2,4]  R1114     -4.0109932422637939e-01
    z[3,2,4]  R1115     2.2225309908390045e-01
    z[3,2,4]  R1116     4.2056638002395630e-01
    z[3,2,4]  R1117     6.5803945064544678e-01
    z[3,2,4]  R1118     -5.1296311616897583e-01
    z[3,2,4]  R1119     -1.9633677601814270e-01
    z[3,2,4]  R1120     2.6759955286979675e-01
    z[3,2,4]  R1121     0.706939697265625
    z[3,2,4]  R1122     8.1082159280776978e-01
    z[3,2,4]  R1123     0.498468816280365
    z[3,2,4]  R1124     0.851675808429718
    z[3,2,4]  R1125     3.3378455042839050e-01
    z[3,2,4]  R1126     5.2420613355934620e-03
    z[3,2,4]  R1127     -4.4159126281738281e-01
    z[3,2,4]  R1128     -5.1426267623901367e-01
    z[3,2,4]  R1129     7.2900778055191040e-01
    z[3,2,4]  R1130     7.7739447355270386e-02
    z[3,2,4]  R1131     1.2438498437404633e-01
    z[3,2,4]  R1132     7.5727772712707520e-01
    z[3,2,4]  R1133     4.4296798110008240e-01
    z[3,2,4]  R1134     3.0513456463813782e-01
    z[3,2,4]  R1135     -2.3997746407985687e-01
    z[3,2,4]  R1136     7.3908336460590363e-02
    z[3,2,4]  R1137     1.9979287683963776e-01
    z[3,2,5]  R25       1
    z[3,2,5]  R34       -1
    z[3,2,5]  R1024     -1
    z[3,2,5]  R1025     1
    z[3,2,5]  R1028     0.288438618183136
    z[3,2,5]  R1029     7.3415338993072510e-02
    z[3,2,5]  R1030     3.1598886847496033e-01
    z[3,2,5]  R1031     2.9113727807998657e-01
    z[3,2,5]  R1032     5.9622806310653687e-01
    z[3,2,5]  R1033     3.8937801122665405e-01
    z[3,2,5]  R1034     1.0548871755599976e-01
    z[3,2,5]  R1035     -3.0654066801071167e-01
    z[3,2,5]  R1036     -1.3580715656280518e-01
    z[3,2,5]  R1037     2.7249258756637573e-01
    z[3,2,5]  R1038     -1.0735871642827988e-01
    z[3,2,5]  R1039     -5.4265994578599930e-02
    z[3,2,5]  R1040     -4.0690630674362183e-01
    z[3,2,5]  R1041     -5.0688081979751587e-01
    z[3,2,5]  R1042     -3.9016571640968323e-01
    z[3,2,5]  R1043     2.6489531993865967e-01
    z[3,2,5]  R1044     -2.3758928477764130e-01
    z[3,2,5]  R1045     -1.5222407877445221e-01
    z[3,2,5]  R1046     -1.7769478261470795e-01
    z[3,2,5]  R1047     -5.3262615203857422e-01
    z[3,2,5]  R1048     -3.4445360302925110e-01
    z[3,2,5]  R1049     -2.3536950349807739e-02
    z[3,2,5]  R1050     -4.9152320623397827e-01
    z[3,2,5]  R1051     -3.7724217772483826e-01
    z[3,2,5]  R1052     -8.8155664503574371e-02
    z[3,2,5]  R1053     6.2642043828964233e-01
    z[3,2,5]  R1054     9.6060521900653839e-02
    z[3,2,5]  R1055     3.6358323693275452e-01
    z[3,2,5]  R1056     1.1877653747797012e-01
    z[3,2,5]  R1057     4.1252571344375610e-01
    z[3,2,5]  R1058     -2.3521672189235687e-01
    z[3,2,5]  R1059     3.4173348546028137e-01
    z[3,2,5]  R1060     -2.1266996860504150e-01
    z[3,2,5]  R1061     1.3347616791725159e-01
    z[3,2,5]  R1062     -1.7888711392879486e-01
    z[3,2,5]  R1063     -5.8507549762725830e-01
    z[3,2,5]  R1064     3.9482930302619934e-01
    z[3,2,5]  R1065     -1.5781989693641663e-01
    z[3,2,5]  R1066     3.6871945858001709e-01
    z[3,2,5]  R1067     -2.8889900445938110e-01
    z[3,2,5]  R1068     1.5868553519248962e-01
    z[3,2,5]  R1069     -1.3307699561119080e-01
    z[3,2,5]  R1070     4.5616918802261353e-01
    z[3,2,5]  R1071     2.0551607012748718e-01
    z[3,2,5]  R1072     -1.8133243918418884e-01
    z[3,2,5]  R1073     1.0346614569425583e-01
    z[3,2,5]  R1074     -1.3034285604953766e-01
    z[3,2,5]  R1075     2.8997424244880676e-01
    z[3,2,5]  R1076     -1.0508912801742554e-01
    z[3,2,5]  R1077     2.8377994894981384e-01
    z[3,2,5]  R1078     -3.8235333561897278e-01
    z[3,2,5]  R1079     -4.5161581039428711e-01
    z[3,2,5]  R1080     -2.6684507727622986e-01
    z[3,2,5]  R1081     -2.4281406402587891e-01
    z[3,2,5]  R1082     -5.1673788577318192e-02
    z[3,2,5]  R1083     2.9943871498107910e-01
    z[3,2,5]  R1084     2.3046833276748657e-01
    z[3,2,5]  R1085     -2.0786814391613007e-01
    z[3,2,5]  R1086     5.2016609907150269e-01
    z[3,2,5]  R1087     -3.8530153036117554e-01
    z[3,2,5]  R1088     -2.1397693455219269e-01
    z[3,2,5]  R1089     -5.0712251663208008e-01
    z[3,2,5]  R1090     -4.4329392910003662e-01
    z[3,2,5]  R1091     -0.636333703994751
    z[3,2,5]  R1092     -2.1468611061573029e-01
    z[3,2,5]  R1093     -5.3010553121566772e-01
    z[3,2,5]  R1094     -4.5094919204711914e-01
    z[3,2,5]  R1095     2.3007138073444366e-01
    z[3,2,5]  R1096     -6.2233596108853817e-03
    z[3,2,5]  R1097     2.4792146682739258e-01
    z[3,2,5]  R1098     -1.4309531450271606e-01
    z[3,2,5]  R1099     -3.3593752980232239e-01
    z[3,2,5]  R1100     -3.9521834254264832e-01
    z[3,2,5]  R1101     3.8066470623016357e-01
    z[3,2,5]  R1102     -3.7482002377510071e-01
    z[3,2,5]  R1103     -2.3112215101718903e-01
    z[3,2,5]  R1104     -1.9764302670955658e-01
    z[3,2,5]  R1105     3.4995386004447937e-01
    z[3,2,5]  R1106     0.262921005487442
    z[3,2,5]  R1107     7.3634006083011627e-02
    z[3,2,5]  R1108     -6.6669160127639771e-01
    z[3,2,5]  R1109     -4.7642791271209717e-01
    z[3,2,5]  R1110     -6.8624633550643921e-01
    z[3,2,5]  R1111     5.4921054840087891e-01
    z[3,2,5]  R1112     1.7313297092914581e-01
    z[3,2,5]  R1113     1.3795202970504761e-01
    z[3,2,5]  R1114     -0.472665399312973
    z[3,2,5]  R1115     -3.0621027946472168e-01
    z[3,2,5]  R1116     4.4452944397926331e-01
    z[3,2,5]  R1117     4.3774670362472534e-01
    z[3,2,5]  R1118     -1.1383699625730515e-01
    z[3,2,5]  R1119     -5.2780801057815552e-01
    z[3,2,5]  R1120     5.5221915245056152e-01
    z[3,2,5]  R1121     2.0059312880039215e-01
    z[3,2,5]  R1122     -1.3569347560405731e-01
    z[3,2,5]  R1123     4.4040087610483170e-02
    z[3,2,5]  R1124     8.8828159496188164e-03
    z[3,2,5]  R1125     -3.1864476203918457e-01
    z[3,2,5]  R1126     -4.9679529666900635e-01
    z[3,2,5]  R1127     1.2843219563364983e-02
    z[3,2,5]  R1128     -1.8174874782562256e-01
    z[3,2,5]  R1129     -1.4751896262168884e-01
    z[3,2,5]  R1130     -3.6593183875083923e-02
    z[3,2,5]  R1131     -8.8280633091926575e-02
    z[3,2,5]  R1132     1.9343499839305878e-01
    z[3,2,5]  R1133     -3.6710628867149353e-01
    z[3,2,5]  R1134     0.607828676700592
    z[3,2,5]  R1135     5.4488813877105713e-01
    z[3,2,5]  R1136     0.67137610912323
    z[3,2,5]  R1137     4.1305643320083618e-01
    z[3,2,6]  R26       1
    z[3,2,6]  R35       -1
    z[3,2,6]  R1026     -1
    z[3,2,6]  R1027     1
    z[3,2,6]  R1028     -1.0111232101917267e-01
    z[3,2,6]  R1029     1.3224272429943085e-01
    z[3,2,6]  R1030     2.6924493908882141e-01
    z[3,2,6]  R1031     3.9693927764892578e-01
    z[3,2,6]  R1032     1.9151189923286438e-01
    z[3,2,6]  R1033     -3.8249734044075012e-01
    z[3,2,6]  R1034     -1.8938811123371124e-01
    z[3,2,6]  R1035     -3.3034953474998474e-01
    z[3,2,6]  R1036     -4.2161145806312561e-01
    z[3,2,6]  R1037     -2.3401927947998047e-01
    z[3,2,6]  R1038     1.3225534558296204e-01
    z[3,2,6]  R1039     -7.7248126268386841e-02
    z[3,2,6]  R1040     5.7576749473810196e-02
    z[3,2,6]  R1041     6.1256840825080872e-02
    z[3,2,6]  R1042     5.2010113000869751e-01
    z[3,2,6]  R1043     4.6250253915786743e-01
    z[3,2,6]  R1044     -1.0021121054887772e-01
    z[3,2,6]  R1045     -4.1702026128768921e-01
    z[3,2,6]  R1046     -9.3552783131599426e-02
    z[3,2,6]  R1047     -3.3364757895469666e-01
    z[3,2,6]  R1048     1.2438180297613144e-01
    z[3,2,6]  R1049     -1.7168733477592468e-01
    z[3,2,6]  R1050     2.8000321984291077e-01
    z[3,2,6]  R1051     4.7164449095726013e-01
    z[3,2,6]  R1052     3.0716332793235779e-01
    z[3,2,6]  R1053     -2.8244480490684509e-02
    z[3,2,6]  R1054     3.7792941927909851e-01
    z[3,2,6]  R1055     -1.3606618344783783e-01
    z[3,2,6]  R1056     -1.7522041499614716e-01
    z[3,2,6]  R1057     1.2355015426874161e-01
    z[3,2,6]  R1058     3.5263389348983765e-01
    z[3,2,6]  R1059     -3.6459651589393616e-01
    z[3,2,6]  R1060     1.8081568181514740e-01
    z[3,2,6]  R1061     2.4590662121772766e-01
    z[3,2,6]  R1062     1.0105468332767487e-01
    z[3,2,6]  R1063     0.163529634475708
    z[3,2,6]  R1064     5.2980917692184448e-01
    z[3,2,6]  R1065     5.0102514028549194e-01
    z[3,2,6]  R1066     3.3948723226785660e-02
    z[3,2,6]  R1067     -2.3816585540771484e-02
    z[3,2,6]  R1068     -5.0029113888740540e-02
    z[3,2,6]  R1069     -2.3115381598472595e-01
    z[3,2,6]  R1070     -8.9278884232044220e-02
    z[3,2,6]  R1071     -1.0339193791151047e-01
    z[3,2,6]  R1072     2.1415881812572479e-01
    z[3,2,6]  R1073     -4.6624112129211426e-01
    z[3,2,6]  R1074     -3.0351492762565613e-01
    z[3,2,6]  R1075     -3.8648679852485657e-01
    z[3,2,6]  R1076     -1.0934099555015564e-01
    z[3,2,6]  R1077     -2.6732918620109558e-01
    z[3,2,6]  R1078     5.1108545064926147e-01
    z[3,2,6]  R1079     -7.2644329071044922e-01
    z[3,2,6]  R1080     -2.0665641129016876e-01
    z[3,2,6]  R1081     -5.1648229360580444e-01
    z[3,2,6]  R1082     -2.5272938609123230e-01
    z[3,2,6]  R1083     1.3192677497863770e-01
    z[3,2,6]  R1084     -9.0538740158081055e-02
    z[3,2,6]  R1085     4.9501422047615051e-01
    z[3,2,6]  R1086     6.2232349067926407e-02
    z[3,2,6]  R1087     -2.6739564538002014e-01
    z[3,2,6]  R1088     -2.0970292389392853e-01
    z[3,2,6]  R1089     1.6176858544349670e-01
    z[3,2,6]  R1090     -2.4438551068305969e-01
    z[3,2,6]  R1091     -1.0012000799179077e-01
    z[3,2,6]  R1092     -3.2189422845840454e-01
    z[3,2,6]  R1093     2.2226870059967041e-01
    z[3,2,6]  R1094     -0.262014240026474
    z[3,2,6]  R1095     -1.6785086691379547e-01
    z[3,2,6]  R1096     3.9106106758117676e-01
    z[3,2,6]  R1097     3.4687098860740662e-01
    z[3,2,6]  R1098     5.4809689521789551e-02
    z[3,2,6]  R1099     -6.6034264862537384e-02
    z[3,2,6]  R1100     1.3592340052127838e-01
    z[3,2,6]  R1101     1.0662989318370819e-01
    z[3,2,6]  R1102     4.2565248906612396e-02
    z[3,2,6]  R1103     -5.8749181032180786e-01
    z[3,2,6]  R1104     3.6409419775009155e-01
    z[3,2,6]  R1105     3.9275979995727539e-01
    z[3,2,6]  R1106     -7.0015847682952881e-02
    z[3,2,6]  R1107     7.8138843178749084e-02
    z[3,2,6]  R1108     1.0038229823112488e-01
    z[3,2,6]  R1109     5.6645695120096207e-02
    z[3,2,6]  R1110     1.4229616522789001e-01
    z[3,2,6]  R1111     1.3901987671852112e-01
    z[3,2,6]  R1112     0.23238605260849
    z[3,2,6]  R1113     2.2056837379932404e-01
    z[3,2,6]  R1114     3.3691248297691345e-01
    z[3,2,6]  R1115     1.2322041392326355e-01
    z[3,2,6]  R1116     1.0096822865307331e-02
    z[3,2,6]  R1117     6.1866792384535074e-04
    z[3,2,6]  R1118     0.0417693592607975
    z[3,2,6]  R1119     5.0848484039306641e-01
    z[3,2,6]  R1120     2.5371477007865906e-01
    z[3,2,6]  R1121     -7.3690533638000488e-02
    z[3,2,6]  R1122     2.1654383838176727e-01
    z[3,2,6]  R1123     1.7860314249992371e-01
    z[3,2,6]  R1124     -5.0366683863103390e-03
    z[3,2,6]  R1125     -2.3265336453914642e-01
    z[3,2,6]  R1126     -6.2715482711791992e-01
    z[3,2,6]  R1127     0.556354284286499
    z[3,2,6]  R1128     2.7617228031158447e-01
    z[3,2,6]  R1129     6.0965497046709061e-02
    z[3,2,6]  R1130     3.6251747608184814e-01
    z[3,2,6]  R1131     2.1518450975418091e-01
    z[3,2,6]  R1132     -3.1988853216171265e-01
    z[3,2,6]  R1133     -1.4080493152141571e-01
    z[3,2,6]  R1134     4.4668808579444885e-01
    z[3,2,6]  R1135     2.3696416616439819e-01
    z[3,2,6]  R1136     -1.7106316983699799e-01
    z[3,2,6]  R1137     2.4901130795478821e-01
    z[2,6,0]  R20       -1
    z[2,6,0]  R56       1
    z[2,6,0]  R1138     -1
    z[2,6,0]  R1139     1
    z[2,6,0]  R1152     -4.9124273657798767e-01
    z[2,6,0]  R1153     -7.7634233236312866e-01
    z[2,6,0]  R1154     -4.5373073220252991e-01
    z[2,6,0]  R1155     -6.8108010292053223e-01
    z[2,6,0]  R1156     -7.1953850984573364e-01
    z[2,6,0]  R1157     -4.6407660841941833e-01
    z[2,6,0]  R1158     -3.3312138915061951e-01
    z[2,6,0]  R1159     -7.2410744428634644e-01
    z[2,6,0]  R1160     -6.1397582292556763e-01
    z[2,6,0]  R1161     -1.4422667026519775e-01
    z[2,6,0]  R1162     6.1473723500967026e-02
    z[2,6,0]  R1163     0.153394877910614
    z[2,6,0]  R1164     -2.0218744874000549e-01
    z[2,6,0]  R1165     -1.8500488996505737e-01
    z[2,6,0]  R1166     1.5352945029735565e-01
    z[2,6,0]  R1167     9.4493657350540161e-02
    z[2,6,0]  R1168     -0.059889055788517
    z[2,6,0]  R1169     2.3794810473918915e-01
    z[2,6,0]  R1170     -2.4597447365522385e-02
    z[2,6,0]  R1171     4.5672440528869629e-01
    z[2,6,0]  R1172     4.7142812609672546e-01
    z[2,6,0]  R1173     2.4861901998519897e-02
    z[2,6,0]  R1174     -1.4215698838233948e-01
    z[2,6,0]  R1175     5.0571531057357788e-01
    z[2,6,0]  R1176     1.2481260299682617e-01
    z[2,6,0]  R1177     -4.0614360570907593e-01
    z[2,6,0]  R1178     -1.9890600442886353e-01
    z[2,6,0]  R1179     1.8972903490066528e-02
    z[2,6,0]  R1180     -6.2058974057435989e-02
    z[2,6,0]  R1181     -1.0376165807247162e-01
    z[2,6,0]  R1182     -1.7810884118080139e-01
    z[2,6,0]  R1183     9.4430714845657349e-02
    z[2,6,0]  R1184     1.2676912546157837e-01
    z[2,6,0]  R1185     -1.5843637287616730e-01
    z[2,6,0]  R1186     4.0129086375236511e-01
    z[2,6,0]  R1187     2.0959985256195068e-01
    z[2,6,0]  R1188     4.2695617675781250e-01
    z[2,6,0]  R1189     -8.0943085253238678e-02
    z[2,6,0]  R1190     -3.6984920501708984e-01
    z[2,6,0]  R1191     -6.6380125284194946e-01
    z[2,6,0]  R1192     -4.9481880851089954e-03
    z[2,6,0]  R1193     -6.7595876753330231e-03
    z[2,6,0]  R1194     2.1995209157466888e-01
    z[2,6,0]  R1195     -5.0826031714677811e-02
    z[2,6,0]  R1196     4.4874809682369232e-02
    z[2,6,0]  R1197     -3.3454048633575439e-01
    z[2,6,0]  R1198     2.5708615779876709e-01
    z[2,6,0]  R1199     6.0063779354095459e-01
    z[2,6,0]  R1200     -6.4115297794342041e-01
    z[2,6,0]  R1201     -3.8052040338516235e-01
    z[2,6,0]  R1202     2.9909870028495789e-01
    z[2,6,0]  R1203     -1.2768530286848545e-02
    z[2,6,0]  R1204     -2.4318021535873413e-01
    z[2,6,0]  R1205     6.0623455792665482e-02
    z[2,6,0]  R1206     -4.2846912145614624e-01
    z[2,6,0]  R1207     -2.1448197960853577e-01
    z[2,6,0]  R1208     -3.8751190900802612e-01
    z[2,6,0]  R1209     5.0506293773651123e-01
    z[2,6,0]  R1210     2.9371036216616631e-02
    z[2,6,0]  R1211     -1.8463903665542603e-01
    z[2,6,0]  R1212     -1.7569494247436523e-01
    z[2,6,0]  R1213     -3.0998736619949341e-01
    z[2,6,0]  R1214     -0.0892467051744461
    z[2,6,0]  R1215     3.0539789795875549e-01
    z[2,6,0]  R1216     -3.7317898869514465e-01
    z[2,6,0]  R1217     4.7704753279685974e-01
    z[2,6,0]  R1218     3.6393198370933533e-01
    z[2,6,0]  R1219     6.0187149047851562e-01
    z[2,6,0]  R1220     0.573669970035553
    z[2,6,0]  R1221     6.0565555095672607e-01
    z[2,6,0]  R1222     -2.6799976825714111e-01
    z[2,6,0]  R1223     -3.0848485231399536e-01
    z[2,6,0]  R1224     -0.502948522567749
    z[2,6,0]  R1225     -4.1463658213615417e-01
    z[2,6,0]  R1226     -4.0166664123535156e-01
    z[2,6,0]  R1227     -6.7071980237960815e-01
    z[2,6,0]  R1228     4.1482448577880859e-01
    z[2,6,0]  R1229     1.3724394142627716e-01
    z[2,6,0]  R1230     1.4065656065940857e-01
    z[2,6,0]  R1231     -1.9479477405548096e-01
    z[2,6,0]  R1232     3.3613452315330505e-01
    z[2,6,0]  R1233     1.0425824671983719e-01
    z[2,6,0]  R1234     0.254373162984848
    z[2,6,0]  R1235     -1.9016842544078827e-01
    z[2,6,0]  R1236     1.0421057045459747e-01
    z[2,6,0]  R1237     5.0094765424728394e-01
    z[2,6,0]  R1238     -4.1455483436584473e-01
    z[2,6,0]  R1239     -1.5327689051628113e-01
    z[2,6,0]  R1240     -7.3224997520446777e-01
    z[2,6,0]  R1241     -4.9367743730545044e-01
    z[2,6,0]  R1242     1.4100821316242218e-01
    z[2,6,0]  R1243     2.1753439307212830e-01
    z[2,6,0]  R1244     -1.2073613703250885e-01
    z[2,6,0]  R1245     -1.8786756694316864e-01
    z[2,6,0]  R1246     -9.2207081615924835e-03
    z[2,6,0]  R1247     2.0490171015262604e-01
    z[2,6,0]  R1248     -4.1622537374496460e-01
    z[2,6,0]  R1249     -0.274004727602005
    z[2,6,0]  R1250     1.6240687668323517e-01
    z[2,6,0]  R1251     -5.9607338905334473e-01
    z[2,6,0]  R1252     -3.1939432024955750e-01
    z[2,6,0]  R1253     -4.3587210774421692e-01
    z[2,6,0]  R1254     4.1314664483070374e-01
    z[2,6,0]  R1255     -1.7168661952018738e-01
    z[2,6,0]  R1256     -0.0768650621175766
    z[2,6,0]  R1257     1.2949213385581970e-01
    z[2,6,0]  R1258     -8.7719194591045380e-02
    z[2,6,0]  R1259     5.6931927800178528e-02
    z[2,6,0]  R1260     5.4856240749359131e-01
    z[2,6,0]  R1261     6.0297280550003052e-01
    z[2,6,0]  R1262     -1.9797690212726593e-01
    z[2,6,0]  R1263     1.5428879298269749e-02
    z[2,6,0]  R1264     1.7626523971557617e-01
    z[2,6,0]  R1265     4.1131421923637390e-01
    z[2,6,0]  R1266     2.3615600541234016e-02
    z[2,6,0]  R1267     5.5942213535308838e-01
    z[2,6,0]  R1268     3.5299485921859741e-01
    z[2,6,0]  R1269     -1.6912724822759628e-02
    z[2,6,0]  R1270     1.3452319800853729e-01
    z[2,6,0]  R1271     2.1778613328933716e-01
    z[2,6,0]  R1272     -2.8781610727310181e-01
    z[2,6,0]  R1273     3.7395498156547546e-01
    z[2,6,0]  R1274     2.0948988199234009e-01
    z[2,6,0]  R1275     1.1307834833860397e-01
    z[2,6,0]  R1276     -1.8201948702335358e-01
    z[2,6,0]  R1277     -2.8810063004493713e-01
    z[2,6,0]  R1278     9.0143084526062012e-01
    z[2,6,1]  R21       -1
    z[2,6,1]  R57       1
    z[2,6,1]  R1140     -1
    z[2,6,1]  R1141     1
    z[2,6,1]  R1152     -4.4544604420661926e-01
    z[2,6,1]  R1153     -4.0777593851089478e-01
    z[2,6,1]  R1154     -4.2607891559600830e-01
    z[2,6,1]  R1155     -2.7949529886245728e-01
    z[2,6,1]  R1156     -0.350705623626709
    z[2,6,1]  R1157     -0.363901287317276
    z[2,6,1]  R1158     -4.9221006035804749e-01
    z[2,6,1]  R1159     -3.8024628162384033e-01
    z[2,6,1]  R1160     0.237028107047081
    z[2,6,1]  R1161     -8.7349957227706909e-01
    z[2,6,1]  R1162     -2.5577083230018616e-01
    z[2,6,1]  R1163     2.4164129793643951e-01
    z[2,6,1]  R1164     0.829850971698761
    z[2,6,1]  R1165     6.4701384305953979e-01
    z[2,6,1]  R1166     9.1239744424819946e-01
    z[2,6,1]  R1167     8.7869280576705933e-01
    z[2,6,1]  R1168     8.8222002983093262e-01
    z[2,6,1]  R1169     3.3945631980895996e-01
    z[2,6,1]  R1170     7.9038488864898682e-01
    z[2,6,1]  R1171     4.7249439358711243e-01
    z[2,6,1]  R1172     -2.5328485295176506e-02
    z[2,6,1]  R1173     -4.2231306433677673e-01
    z[2,6,1]  R1174     1.6041561961174011e-01
    z[2,6,1]  R1175     9.7372457385063171e-02
    z[2,6,1]  R1176     3.9665067195892334e-01
    z[2,6,1]  R1177     5.0427418947219849e-01
    z[2,6,1]  R1178     -2.2575311362743378e-01
    z[2,6,1]  R1179     2.1479836106300354e-01
    z[2,6,1]  R1180     2.1152751147747040e-01
    z[2,6,1]  R1181     2.3155732452869415e-01
    z[2,6,1]  R1182     -2.0896512269973755e-01
    z[2,6,1]  R1183     -8.6768402252346277e-04
    z[2,6,1]  R1184     4.8274621367454529e-01
    z[2,6,1]  R1185     3.2020667195320129e-01
    z[2,6,1]  R1186     1.8010555207729340e-01
    z[2,6,1]  R1187     -4.0624219179153442e-01
    z[2,6,1]  R1188     -4.6342805027961731e-02
    z[2,6,1]  R1189     2.6514491438865662e-01
    z[2,6,1]  R1190     2.3521491885185242e-01
    z[2,6,1]  R1191     2.4544388055801392e-01
    z[2,6,1]  R1192     -8.3455711603164673e-02
    z[2,6,1]  R1193     1.5370737016201019e-01
    z[2,6,1]  R1194     2.3272086679935455e-01
    z[2,6,1]  R1195     3.5309621691703796e-01
    z[2,6,1]  R1196     1.4941997826099396e-01
    z[2,6,1]  R1197     -3.7667483091354370e-02
    z[2,6,1]  R1198     4.8218145966529846e-01
    z[2,6,1]  R1199     -1.7782464623451233e-01
    z[2,6,1]  R1200     3.9055651426315308e-01
    z[2,6,1]  R1201     4.6254959702491760e-01
    z[2,6,1]  R1202     2.5293555110692978e-02
    z[2,6,1]  R1203     1.9626750051975250e-01
    z[2,6,1]  R1204     9.6097335219383240e-02
    z[2,6,1]  R1205     1.5056197345256805e-01
    z[2,6,1]  R1206     1.8992094695568085e-01
    z[2,6,1]  R1207     3.4925243258476257e-01
    z[2,6,1]  R1208     -9.8732315003871918e-02
    z[2,6,1]  R1209     -1.1955556273460388e-01
    z[2,6,1]  R1210     -4.8471504449844360e-01
    z[2,6,1]  R1211     3.3883380889892578e-01
    z[2,6,1]  R1212     -4.6554881334304810e-01
    z[2,6,1]  R1213     8.7587319314479828e-02
    z[2,6,1]  R1214     3.0281466245651245e-01
    z[2,6,1]  R1215     0.00760143157094717
    z[2,6,1]  R1216     2.8109899163246155e-01
    z[2,6,1]  R1217     4.2320245504379272e-01
    z[2,6,1]  R1218     -2.1706353127956390e-01
    z[2,6,1]  R1219     -3.9704304933547974e-01
    z[2,6,1]  R1220     -1.0005540400743484e-01
    z[2,6,1]  R1221     -0.344194233417511
    z[2,6,1]  R1222     2.6034945249557495e-01
    z[2,6,1]  R1223     -3.4273234009742737e-01
    z[2,6,1]  R1224     3.3970236778259277e-01
    z[2,6,1]  R1225     0.287553071975708
    z[2,6,1]  R1226     -1.8081579357385635e-02
    z[2,6,1]  R1227     -1.0382114350795746e-01
    z[2,6,1]  R1228     6.3087075948715210e-01
    z[2,6,1]  R1229     6.6886502504348755e-01
    z[2,6,1]  R1230     7.1507990360260010e-01
    z[2,6,1]  R1231     1.6465568542480469e-01
    z[2,6,1]  R1232     -1.9731727242469788e-01
    z[2,6,1]  R1233     2.3253744840621948e-01
    z[2,6,1]  R1234     -1.3593323528766632e-01
    z[2,6,1]  R1235     4.5358244329690933e-02
    z[2,6,1]  R1236     -0.3088398873806
    z[2,6,1]  R1237     -2.1598720923066139e-02
    z[2,6,1]  R1238     -1.5587671659886837e-02
    z[2,6,1]  R1239     -1.1244186758995056e-01
    z[2,6,1]  R1240     -1.2262280285358429e-01
    z[2,6,1]  R1241     -4.1260862350463867e-01
    z[2,6,1]  R1242     -2.0453684031963348e-01
    z[2,6,1]  R1243     1.3772989809513092e-01
    z[2,6,1]  R1244     -3.0731928348541260e-01
    z[2,6,1]  R1245     3.0537009239196777e-01
    z[2,6,1]  R1246     1.7410951852798462e-01
    z[2,6,1]  R1247     5.5265665054321289e-01
    z[2,6,1]  R1248     3.9770871400833130e-01
    z[2,6,1]  R1249     1.5753868967294693e-02
    z[2,6,1]  R1250     -2.0316170156002045e-01
    z[2,6,1]  R1251     -2.0895386114716530e-02
    z[2,6,1]  R1252     3.3721652626991272e-01
    z[2,6,1]  R1253     0.0609736330807209
    z[2,6,1]  R1254     -3.0422195792198181e-01
    z[2,6,1]  R1255     2.3960523307323456e-01
    z[2,6,1]  R1256     5.8998677879571915e-02
    z[2,6,1]  R1257     8.6291587352752686e-01
    z[2,6,1]  R1258     8.5653185844421387e-01
    z[2,6,1]  R1259     8.1906998157501221e-01
    z[2,6,1]  R1260     7.3512208461761475e-01
    z[2,6,1]  R1261     4.4444590806961060e-01
    z[2,6,1]  R1262     -2.5734481215476990e-01
    z[2,6,1]  R1263     3.8917216658592224e-01
    z[2,6,1]  R1264     9.5235210657119751e-01
    z[2,6,1]  R1265     -1.1356313712894917e-02
    z[2,6,1]  R1266     9.0541803836822510e-01
    z[2,6,1]  R1267     5.4022759199142456e-01
    z[2,6,1]  R1268     5.0834619998931885e-01
    z[2,6,1]  R1269     -9.0297651290893555e-01
    z[2,6,1]  R1270     -8.1154477596282959e-01
    z[2,6,1]  R1271     -9.0584987401962280e-01
    z[2,6,1]  R1272     -1.6611185669898987e-01
    z[2,6,1]  R1273     9.2443414032459259e-02
    z[2,6,1]  R1274     3.8873386383056641e-01
    z[2,6,1]  R1275     -6.8229228258132935e-01
    z[2,6,1]  R1276     -3.2924848794937134e-01
    z[2,6,1]  R1277     -2.0766112208366394e-01
    z[2,6,1]  R1278     -1.3121864199638367e-01
    z[2,6,2]  R22       -1
    z[2,6,2]  R58       1
    z[2,6,2]  R1142     -1
    z[2,6,2]  R1143     1
    z[2,6,2]  R1152     -5.0723069906234741e-01
    z[2,6,2]  R1153     -3.0221751332283020e-01
    z[2,6,2]  R1154     -5.4670047760009766e-01
    z[2,6,2]  R1155     -5.1954925060272217e-01
    z[2,6,2]  R1156     -3.8589019328355789e-02
    z[2,6,2]  R1157     -6.0903567075729370e-01
    z[2,6,2]  R1158     -4.8527535051107407e-02
    z[2,6,2]  R1159     -2.2927054762840271e-01
    z[2,6,2]  R1160     -6.1901479959487915e-01
    z[2,6,2]  R1161     3.8353729993104935e-02
    z[2,6,2]  R1162     4.4338819384574890e-01
    z[2,6,2]  R1163     -3.2167810946702957e-02
    z[2,6,2]  R1164     3.1972485780715942e-01
    z[2,6,2]  R1165     5.0286766141653061e-02
    z[2,6,2]  R1166     1.2339603155851364e-01
    z[2,6,2]  R1167     2.6287573575973511e-01
    z[2,6,2]  R1168     2.2269165515899658e-01
    z[2,6,2]  R1169     6.6414773464202881e-01
    z[2,6,2]  R1170     7.4134194292128086e-03
    z[2,6,2]  R1171     -2.6723316311836243e-01
    z[2,6,2]  R1172     -0.0663272812962532
    z[2,6,2]  R1173     -3.2018488645553589e-01
    z[2,6,2]  R1174     -3.5017940402030945e-01
    z[2,6,2]  R1175     1.4386005699634552e-01
    z[2,6,2]  R1176     -8.9014537632465363e-02
    z[2,6,2]  R1177     1.2869903445243835e-01
    z[2,6,2]  R1178     3.2295051217079163e-01
    z[2,6,2]  R1179     3.2745265960693359e-01
    z[2,6,2]  R1180     -2.7053061127662659e-01
    z[2,6,2]  R1181     -3.1839540600776672e-01
    z[2,6,2]  R1182     4.8677217960357666e-01
    z[2,6,2]  R1183     8.2149881124496460e-01
    z[2,6,2]  R1184     5.7530528306961060e-01
    z[2,6,2]  R1185     1.1776317656040192e-01
    z[2,6,2]  R1186     -4.4055002927780151e-01
    z[2,6,2]  R1187     3.9006423950195312e-01
    z[2,6,2]  R1188     -2.8825944662094116e-01
    z[2,6,2]  R1189     -1.3484659790992737e-01
    z[2,6,2]  R1190     2.1095946431159973e-01
    z[2,6,2]  R1191     -1.1477702856063843e-01
    z[2,6,2]  R1192     5.4724162817001343e-01
    z[2,6,2]  R1193     -2.2157758474349976e-01
    z[2,6,2]  R1194     3.6912760138511658e-01
    z[2,6,2]  R1195     -1.3935816287994385e-01
    z[2,6,2]  R1196     -1.5904602408409119e-01
    z[2,6,2]  R1197     -1.1023134738206863e-01
    z[2,6,2]  R1198     -3.6716946959495544e-01
    z[2,6,2]  R1199     6.4137715101242065e-01
    z[2,6,2]  R1200     4.7803804278373718e-02
    z[2,6,2]  R1201     -1.0268244892358780e-01
    z[2,6,2]  R1202     -4.5061972737312317e-01
    z[2,6,2]  R1203     3.8992297649383545e-01
    z[2,6,2]  R1204     1.1180755496025085e-01
    z[2,6,2]  R1205     -4.3792682886123657e-01
    z[2,6,2]  R1206     -2.3457825183868408e-01
    z[2,6,2]  R1207     5.8858606964349747e-02
    z[2,6,2]  R1208     -3.3551222085952759e-01
    z[2,6,2]  R1209     0.629315972328186
    z[2,6,2]  R1210     -3.7618912756443024e-02
    z[2,6,2]  R1211     -1.8613802269101143e-02
    z[2,6,2]  R1212     -1.5646006166934967e-01
    z[2,6,2]  R1213     -3.8047635555267334e-01
    z[2,6,2]  R1214     -2.5038030743598938e-01
    z[2,6,2]  R1215     -2.7576902508735657e-01
    z[2,6,2]  R1216     -1.3379658758640289e-01
    z[2,6,2]  R1217     4.4476044178009033e-01
    z[2,6,2]  R1218     -3.8278463482856750e-01
    z[2,6,2]  R1219     -1.5245710313320160e-01
    z[2,6,2]  R1220     -3.1500127911567688e-01
    z[2,6,2]  R1221     -4.9095860123634338e-01
    z[2,6,2]  R1222     -3.9756676554679871e-01
    z[2,6,2]  R1223     -4.9994894862174988e-01
    z[2,6,2]  R1224     -2.3084443807601929e-01
    z[2,6,2]  R1225     -2.0341536402702332e-01
    z[2,6,2]  R1226     1.1693882942199707e-01
    z[2,6,2]  R1227     8.1346176564693451e-02
    z[2,6,2]  R1228     -2.8455637395381927e-02
    z[2,6,2]  R1229     -4.7480916976928711e-01
    z[2,6,2]  R1230     0.399924099445343
    z[2,6,2]  R1231     -3.5927772521972656e-01
    z[2,6,2]  R1232     -2.6057684421539307e-01
    z[2,6,2]  R1233     7.0517949759960175e-02
    z[2,6,2]  R1234     1.9377246499061584e-01
    z[2,6,2]  R1235     -3.5220120102167130e-02
    z[2,6,2]  R1236     -1.5724499523639679e-01
    z[2,6,2]  R1237     -0.251311331987381
    z[2,6,2]  R1238     -4.4861888885498047e-01
    z[2,6,2]  R1239     8.4616623818874359e-02
    z[2,6,2]  R1240     -4.3666278943419456e-03
    z[2,6,2]  R1241     2.8069657087326050e-01
    z[2,6,2]  R1242     1.4100825786590576e-01
    z[2,6,2]  R1243     -8.8609211146831512e-02
    z[2,6,2]  R1244     -3.8922277092933655e-01
    z[2,6,2]  R1245     -8.1903554499149323e-02
    z[2,6,2]  R1246     -0.564672589302063
    z[2,6,2]  R1247     -3.1437207013368607e-02
    z[2,6,2]  R1248     -1.1584430932998657e-01
    z[2,6,2]  R1249     -2.2531510889530182e-01
    z[2,6,2]  R1250     2.7839755639433861e-03
    z[2,6,2]  R1251     -5.0746973603963852e-02
    z[2,6,2]  R1252     -2.3050782084465027e-01
    z[2,6,2]  R1253     2.4781459942460060e-02
    z[2,6,2]  R1254     -6.3811242580413818e-02
    z[2,6,2]  R1255     -8.2455776631832123e-02
    z[2,6,2]  R1256     -2.8026726841926575e-01
    z[2,6,2]  R1257     7.1502029895782471e-02
    z[2,6,2]  R1258     2.1758085489273071e-01
    z[2,6,2]  R1259     3.5238778591156006e-01
    z[2,6,2]  R1260     -1.8645766377449036e-01
    z[2,6,2]  R1261     3.1171867251396179e-01
    z[2,6,2]  R1262     -3.9491170644760132e-01
    z[2,6,2]  R1263     1.6960716247558594e-01
    z[2,6,2]  R1264     -1.4601002633571625e-01
    z[2,6,2]  R1265     -4.1508537530899048e-01
    z[2,6,2]  R1266     2.7347663044929504e-01
    z[2,6,2]  R1267     2.0718546211719513e-01
    z[2,6,2]  R1268     3.8754299283027649e-01
    z[2,6,2]  R1269     7.2244450449943542e-02
    z[2,6,2]  R1270     0.145552858710289
    z[2,6,2]  R1271     5.7123210281133652e-02
    z[2,6,2]  R1272     -3.3237934112548828e-01
    z[2,6,2]  R1273     -3.8678976893424988e-01
    z[2,6,2]  R1274     5.5587112903594971e-01
    z[2,6,2]  R1275     -3.4621194005012512e-02
    z[2,6,2]  R1276     -0.0864488035440445
    z[2,6,2]  R1277     -1.7532606422901154e-01
    z[2,6,2]  R1278     -0.0704229474067688
    z[2,6,3]  R23       -1
    z[2,6,3]  R59       1
    z[2,6,3]  R1144     -1
    z[2,6,3]  R1145     1
    z[2,6,3]  R1152     5.0857901573181152e-01
    z[2,6,3]  R1153     2.4969819188117981e-01
    z[2,6,3]  R1154     4.9621476791799068e-03
    z[2,6,3]  R1155     -1.0981449484825134e-01
    z[2,6,3]  R1156     5.2821516990661621e-01
    z[2,6,3]  R1157     -3.8038119673728943e-02
    z[2,6,3]  R1158     6.7629760503768921e-01
    z[2,6,3]  R1159     -1.7949819564819336e-01
    z[2,6,3]  R1160     3.6374571919441223e-01
    z[2,6,3]  R1161     2.1840167045593262e-01
    z[2,6,3]  R1162     -0.52577143907547
    z[2,6,3]  R1163     -4.1349199414253235e-01
    z[2,6,3]  R1164     -1.5367542207241058e-01
    z[2,6,3]  R1165     -4.5624691247940063e-01
    z[2,6,3]  R1166     -2.2992837429046631e-01
    z[2,6,3]  R1167     -5.1483251154422760e-02
    z[2,6,3]  R1168     9.5154352486133575e-02
    z[2,6,3]  R1169     -3.0231153964996338e-01
    z[2,6,3]  R1170     -3.1349179148674011e-01
    z[2,6,3]  R1171     -4.9525824189186096e-01
    z[2,6,3]  R1172     -7.8650033473968506e-01
    z[2,6,3]  R1173     -4.3379139900207520e-01
    z[2,6,3]  R1174     -6.5854293107986450e-01
    z[2,6,3]  R1175     -5.3881102800369263e-01
    z[2,6,3]  R1176     -7.9445666074752808e-01
    z[2,6,3]  R1177     -4.4195863604545593e-01
    z[2,6,3]  R1178     -7.2630548477172852e-01
    z[2,6,3]  R1179     -8.7272793054580688e-01
    z[2,6,3]  R1180     2.8594639897346497e-01
    z[2,6,3]  R1181     0.0881413072347641
    z[2,6,3]  R1182     -8.0582714080810547e-01
    z[2,6,3]  R1183     -2.6946470141410828e-01
    z[2,6,3]  R1184     -4.8328486084938049e-01
    z[2,6,3]  R1185     6.5524083375930786e-01
    z[2,6,3]  R1186     6.8470877408981323e-01
    z[2,6,3]  R1187     -4.3322277069091797e-01
    z[2,6,3]  R1188     7.4889016151428223e-01
    z[2,6,3]  R1189     -6.5494573116302490e-01
    z[2,6,3]  R1190     7.3258213698863983e-02
    z[2,6,3]  R1191     -2.6382020115852356e-01
    z[2,6,3]  R1192     -4.8871728777885437e-01
    z[2,6,3]  R1193     8.1759041547775269e-01
    z[2,6,3]  R1194     -0.515705943107605
    z[2,6,3]  R1195     0.695762038230896
    z[2,6,3]  R1196     6.9523996114730835e-01
    z[2,6,3]  R1197     8.0560527741909027e-02
    z[2,6,3]  R1198     -2.6228037476539612e-01
    z[2,6,3]  R1199     -1.9468809664249420e-01
    z[2,6,3]  R1200     2.4396492540836334e-01
    z[2,6,3]  R1201     0.0779092013835907
    z[2,6,3]  R1202     -6.5498644113540649e-01
    z[2,6,3]  R1203     -4.8331132531166077e-01
    z[2,6,3]  R1204     6.9152086973190308e-01
    z[2,6,3]  R1205     4.8625549674034119e-01
    z[2,6,3]  R1206     5.0809867680072784e-02
    z[2,6,3]  R1207     7.3908466100692749e-01
    z[2,6,3]  R1208     -4.5410543680191040e-02
    z[2,6,3]  R1209     -2.5981745123863220e-01
    z[2,6,3]  R1210     -3.5016742348670959e-01
    z[2,6,3]  R1211     -5.8826500177383423e-01
    z[2,6,3]  R1212     -5.9510171413421631e-01
    z[2,6,3]  R1213     4.4107037782669067e-01
    z[2,6,3]  R1214     8.3597046136856079e-01
    z[2,6,3]  R1215     8.7238538265228271e-01
    z[2,6,3]  R1216     2.2495311498641968e-01
    z[2,6,3]  R1217     2.1142323315143585e-01
    z[2,6,3]  R1218     1.0871886461973190e-01
    z[2,6,3]  R1219     -2.1498848497867584e-01
    z[2,6,3]  R1220     2.7603426575660706e-01
    z[2,6,3]  R1221     -3.3645071089267731e-02
    z[2,6,3]  R1222     6.5393263101577759e-01
    z[2,6,3]  R1223     5.0959396362304688e-01
    z[2,6,3]  R1224     4.0262740850448608e-01
    z[2,6,3]  R1225     0.0463026687502861
    z[2,6,3]  R1226     -7.2940096259117126e-02
    z[2,6,3]  R1227     2.8767937421798706e-01
    z[2,6,3]  R1228     -0.0512276254594326
    z[2,6,3]  R1229     -7.1023985743522644e-02
    z[2,6,3]  R1230     -3.7454909086227417e-01
    z[2,6,3]  R1231     -7.4034363031387329e-02
    z[2,6,3]  R1232     -3.3794444799423218e-01
    z[2,6,3]  R1233     -2.8308334946632385e-01
    z[2,6,3]  R1234     -0.391967236995697
    z[2,6,3]  R1235     -2.7441471815109253e-01
    z[2,6,3]  R1236     -3.5618439316749573e-01
    z[2,6,3]  R1237     -4.3386444449424744e-01
    z[2,6,3]  R1238     -2.6035135984420776e-01
    z[2,6,3]  R1239     -3.7802201509475708e-01
    z[2,6,3]  R1240     -3.1466564536094666e-01
    z[2,6,3]  R1241     -2.4095329642295837e-01
    z[2,6,3]  R1242     -6.8053388595581055e-01
    z[2,6,3]  R1243     -7.2847908735275269e-01
    z[2,6,3]  R1244     -7.1762156486511230e-01
    z[2,6,3]  R1245     -6.7181175947189331e-01
    z[2,6,3]  R1246     -7.5338131189346313e-01
    z[2,6,3]  R1247     -6.4652174711227417e-01
    z[2,6,3]  R1248     -6.3391441106796265e-01
    z[2,6,3]  R1249     -5.2807462215423584e-01
    z[2,6,3]  R1250     -6.9509744644165039e-01
    z[2,6,3]  R1251     -7.5340855121612549e-01
    z[2,6,3]  R1252     -6.3471955060958862e-01
    z[2,6,3]  R1253     -7.7655339241027832e-01
    z[2,6,3]  R1254     -6.2197327613830566e-01
    z[2,6,3]  R1255     -6.6663116216659546e-01
    z[2,6,3]  R1256     -5.9071314334869385e-01
    z[2,6,3]  R1257     2.1089186891913414e-02
    z[2,6,3]  R1258     4.1512794792652130e-02
    z[2,6,3]  R1259     -3.4831660985946655e-01
    z[2,6,3]  R1260     -3.0824735760688782e-02
    z[2,6,3]  R1261     -5.2167940139770508e-01
    z[2,6,3]  R1262     -4.0444770455360413e-01
    z[2,6,3]  R1263     -8.0958712100982666e-01
    z[2,6,3]  R1264     -1.7638245224952698e-01
    z[2,6,3]  R1265     -4.1537594795227051e-01
    z[2,6,3]  R1266     -1.8703933060169220e-01
    z[2,6,3]  R1267     -5.4770672321319580e-01
    z[2,6,3]  R1268     -5.7849675416946411e-01
    z[2,6,3]  R1269     -2.0557032525539398e-01
    z[2,6,3]  R1270     -4.5151209831237793e-01
    z[2,6,3]  R1271     -2.2021782398223877e-01
    z[2,6,3]  R1272     -8.3125251531600952e-01
    z[2,6,3]  R1273     -0.372031033039093
    z[2,6,3]  R1274     -0.626023530960083
    z[2,6,3]  R1275     -3.2117596268653870e-01
    z[2,6,3]  R1276     4.4315099716186523e-01
    z[2,6,3]  R1277     3.2139471173286438e-01
    z[2,6,3]  R1278     2.2495168447494507e-01
    z[2,6,4]  R24       -1
    z[2,6,4]  R60       1
    z[2,6,4]  R1146     -1
    z[2,6,4]  R1147     1
    z[2,6,4]  R1152     -1.2899169325828552e-01
    z[2,6,4]  R1153     -7.8646056354045868e-02
    z[2,6,4]  R1154     -3.1243902444839478e-01
    z[2,6,4]  R1155     -3.5084882378578186e-01
    z[2,6,4]  R1156     4.9095014110207558e-03
    z[2,6,4]  R1157     -2.2748914361000061e-01
    z[2,6,4]  R1158     2.7913349866867065e-01
    z[2,6,4]  R1159     -1.1331176012754440e-01
    z[2,6,4]  R1160     -1.6841015219688416e-01
    z[2,6,4]  R1161     1.2260024249553680e-01
    z[2,6,4]  R1162     -2.2443506121635437e-01
    z[2,6,4]  R1163     1.1996795237064362e-01
    z[2,6,4]  R1164     1.7525520920753479e-01
    z[2,6,4]  R1165     1.0365176200866699e-01
    z[2,6,4]  R1166     9.6559226512908936e-02
    z[2,6,4]  R1167     0.200368732213974
    z[2,6,4]  R1168     3.1327697634696960e-01
    z[2,6,4]  R1169     8.6123727262020111e-02
    z[2,6,4]  R1170     -4.3691907078027725e-02
    z[2,6,4]  R1171     -1.7748209834098816e-01
    z[2,6,4]  R1172     -2.5371336936950684e-01
    z[2,6,4]  R1173     -4.9698883295059204e-01
    z[2,6,4]  R1174     -3.7619143724441528e-01
    z[2,6,4]  R1175     -0.0938776507973671
    z[2,6,4]  R1176     -1.9570156931877136e-01
    z[2,6,4]  R1177     -1.9608359038829803e-01
    z[2,6,4]  R1178     -7.5157403945922852e-02
    z[2,6,4]  R1179     -5.9292886406183243e-02
    z[2,6,4]  R1180     8.0217522382736206e-01
    z[2,6,4]  R1181     8.0292326211929321e-01
    z[2,6,4]  R1182     -1.2176158279180527e-01
    z[2,6,4]  R1183     3.5552206635475159e-01
    z[2,6,4]  R1184     1.0803960263729095e-01
    z[2,6,4]  R1185     5.2238047122955322e-01
    z[2,6,4]  R1186     3.6268595606088638e-02
    z[2,6,4]  R1187     2.2943180799484253e-01
    z[2,6,4]  R1188     1.8939814763143659e-03
    z[2,6,4]  R1189     -4.4640892744064331e-01
    z[2,6,4]  R1190     8.2703399658203125e-01
    z[2,6,4]  R1191     6.3625681400299072e-01
    z[2,6,4]  R1192     1.1765540577471256e-02
    z[2,6,4]  R1193     1.6907185316085815e-01
    z[2,6,4]  R1194     -6.3812166452407837e-02
    z[2,6,4]  R1195     2.1971662342548370e-01
    z[2,6,4]  R1196     6.1889201402664185e-01
    z[2,6,4]  R1197     8.9461815357208252e-01
    z[2,6,4]  R1198     -4.0109932422637939e-01
    z[2,6,4]  R1199     2.2225309908390045e-01
    z[2,6,4]  R1200     4.2056638002395630e-01
    z[2,6,4]  R1201     6.5803945064544678e-01
    z[2,6,4]  R1202     -5.1296311616897583e-01
    z[2,6,4]  R1203     -1.9633677601814270e-01
    z[2,6,4]  R1204     2.6759955286979675e-01
    z[2,6,4]  R1205     0.706939697265625
    z[2,6,4]  R1206     8.1082159280776978e-01
    z[2,6,4]  R1207     0.498468816280365
    z[2,6,4]  R1208     0.851675808429718
    z[2,6,4]  R1209     3.3378455042839050e-01
    z[2,6,4]  R1210     5.2420613355934620e-03
    z[2,6,4]  R1211     -4.4159126281738281e-01
    z[2,6,4]  R1212     -5.1426267623901367e-01
    z[2,6,4]  R1213     7.2900778055191040e-01
    z[2,6,4]  R1214     7.7739447355270386e-02
    z[2,6,4]  R1215     1.2438498437404633e-01
    z[2,6,4]  R1216     7.5727772712707520e-01
    z[2,6,4]  R1217     4.4296798110008240e-01
    z[2,6,4]  R1218     3.0513456463813782e-01
    z[2,6,4]  R1219     -2.3997746407985687e-01
    z[2,6,4]  R1220     7.3908336460590363e-02
    z[2,6,4]  R1221     1.9979287683963776e-01
    z[2,6,4]  R1222     -3.6099845170974731e-01
    z[2,6,4]  R1223     -5.0128477811813354e-01
    z[2,6,4]  R1224     -2.4232718348503113e-01
    z[2,6,4]  R1225     -6.2378132343292236e-01
    z[2,6,4]  R1226     -7.6530051231384277e-01
    z[2,6,4]  R1227     -8.2309916615486145e-02
    z[2,6,4]  R1228     5.0870066881179810e-01
    z[2,6,4]  R1229     5.2494859695434570e-01
    z[2,6,4]  R1230     2.2784644365310669e-01
    z[2,6,4]  R1231     6.3623136281967163e-01
    z[2,6,4]  R1232     6.6906195878982544e-01
    z[2,6,4]  R1233     0.715188205242157
    z[2,6,4]  R1234     8.1924271583557129e-01
    z[2,6,4]  R1235     7.3967492580413818e-01
    z[2,6,4]  R1236     4.9545809626579285e-01
    z[2,6,4]  R1237     6.3771128654479980e-01
    z[2,6,4]  R1238     6.3362246751785278e-01
    z[2,6,4]  R1239     1.2641207873821259e-01
    z[2,6,4]  R1240     4.4084584712982178e-01
    z[2,6,4]  R1241     5.3377324342727661e-01
    z[2,6,4]  R1242     5.4180890321731567e-01
    z[2,6,4]  R1243     1.1982502788305283e-01
    z[2,6,4]  R1244     3.1549152731895447e-01
    z[2,6,4]  R1245     1.6357085108757019e-01
    z[2,6,4]  R1246     2.0659507811069489e-01
    z[2,6,4]  R1247     3.2729476690292358e-01
    z[2,6,4]  R1248     3.3463621139526367e-01
    z[2,6,4]  R1249     5.3437018394470215e-01
    z[2,6,4]  R1250     5.3751307725906372e-01
    z[2,6,4]  R1251     2.0646791160106659e-01
    z[2,6,4]  R1252     4.4832786917686462e-01
    z[2,6,4]  R1253     2.7401667833328247e-01
    z[2,6,4]  R1254     5.2053558826446533e-01
    z[2,6,4]  R1255     5.4928040504455566e-01
    z[2,6,4]  R1256     1.5408772230148315e-01
    z[2,6,4]  R1257     2.7578663825988770e-01
    z[2,6,4]  R1258     3.2866501808166504e-01
    z[2,6,4]  R1259     -1.2901960313320160e-01
    z[2,6,4]  R1260     0.0457758866250515
    z[2,6,4]  R1261     -2.8694493696093559e-02
    z[2,6,4]  R1262     7.3351776599884033e-01
    z[2,6,4]  R1263     0.338083416223526
    z[2,6,4]  R1264     0.0929412767291069
    z[2,6,4]  R1265     6.1885702610015869e-01
    z[2,6,4]  R1266     -1.6371940076351166e-01
    z[2,6,4]  R1267     -0.0817561224102974
    z[2,6,4]  R1268     -0.0737539529800415
    z[2,6,4]  R1269     2.4493876099586487e-01
    z[2,6,4]  R1270     -6.9230049848556519e-02
    z[2,6,4]  R1271     1.8002241849899292e-01
    z[2,6,4]  R1272     2.5551870465278625e-01
    z[2,6,4]  R1273     6.9033432006835938e-01
    z[2,6,4]  R1274     2.9557922482490540e-01
    z[2,6,4]  R1275     1.9327664747834206e-02
    z[2,6,4]  R1276     7.8321486711502075e-01
    z[2,6,4]  R1277     5.0879049301147461e-01
    z[2,6,4]  R1278     2.1860572695732117e-01
    z[2,6,5]  R25       -1
    z[2,6,5]  R61       1
    z[2,6,5]  R1148     -1
    z[2,6,5]  R1149     1
    z[2,6,5]  R1152     1.5868553519248962e-01
    z[2,6,5]  R1153     -1.3307699561119080e-01
    z[2,6,5]  R1154     4.5616918802261353e-01
    z[2,6,5]  R1155     2.0551607012748718e-01
    z[2,6,5]  R1156     -1.8133243918418884e-01
    z[2,6,5]  R1157     1.0346614569425583e-01
    z[2,6,5]  R1158     -1.3034285604953766e-01
    z[2,6,5]  R1159     2.8997424244880676e-01
    z[2,6,5]  R1160     -1.0508912801742554e-01
    z[2,6,5]  R1161     2.8377994894981384e-01
    z[2,6,5]  R1162     -3.8235333561897278e-01
    z[2,6,5]  R1163     -4.5161581039428711e-01
    z[2,6,5]  R1164     -2.6684507727622986e-01
    z[2,6,5]  R1165     -2.4281406402587891e-01
    z[2,6,5]  R1166     -5.1673788577318192e-02
    z[2,6,5]  R1167     2.9943871498107910e-01
    z[2,6,5]  R1168     2.3046833276748657e-01
    z[2,6,5]  R1169     -2.0786814391613007e-01
    z[2,6,5]  R1170     5.2016609907150269e-01
    z[2,6,5]  R1171     -3.8530153036117554e-01
    z[2,6,5]  R1172     -2.1397693455219269e-01
    z[2,6,5]  R1173     -5.0712251663208008e-01
    z[2,6,5]  R1174     -4.4329392910003662e-01
    z[2,6,5]  R1175     -0.636333703994751
    z[2,6,5]  R1176     -2.1468611061573029e-01
    z[2,6,5]  R1177     -5.3010553121566772e-01
    z[2,6,5]  R1178     -4.5094919204711914e-01
    z[2,6,5]  R1179     2.3007138073444366e-01
    z[2,6,5]  R1180     -6.2233596108853817e-03
    z[2,6,5]  R1181     2.4792146682739258e-01
    z[2,6,5]  R1182     -1.4309531450271606e-01
    z[2,6,5]  R1183     -3.3593752980232239e-01
    z[2,6,5]  R1184     -3.9521834254264832e-01
    z[2,6,5]  R1185     3.8066470623016357e-01
    z[2,6,5]  R1186     -3.7482002377510071e-01
    z[2,6,5]  R1187     -2.3112215101718903e-01
    z[2,6,5]  R1188     -1.9764302670955658e-01
    z[2,6,5]  R1189     3.4995386004447937e-01
    z[2,6,5]  R1190     0.262921005487442
    z[2,6,5]  R1191     7.3634006083011627e-02
    z[2,6,5]  R1192     -6.6669160127639771e-01
    z[2,6,5]  R1193     -4.7642791271209717e-01
    z[2,6,5]  R1194     -6.8624633550643921e-01
    z[2,6,5]  R1195     5.4921054840087891e-01
    z[2,6,5]  R1196     1.7313297092914581e-01
    z[2,6,5]  R1197     1.3795202970504761e-01
    z[2,6,5]  R1198     -0.472665399312973
    z[2,6,5]  R1199     -3.0621027946472168e-01
    z[2,6,5]  R1200     4.4452944397926331e-01
    z[2,6,5]  R1201     4.3774670362472534e-01
    z[2,6,5]  R1202     -1.1383699625730515e-01
    z[2,6,5]  R1203     -5.2780801057815552e-01
    z[2,6,5]  R1204     5.5221915245056152e-01
    z[2,6,5]  R1205     2.0059312880039215e-01
    z[2,6,5]  R1206     -1.3569347560405731e-01
    z[2,6,5]  R1207     4.4040087610483170e-02
    z[2,6,5]  R1208     8.8828159496188164e-03
    z[2,6,5]  R1209     -3.1864476203918457e-01
    z[2,6,5]  R1210     -4.9679529666900635e-01
    z[2,6,5]  R1211     1.2843219563364983e-02
    z[2,6,5]  R1212     -1.8174874782562256e-01
    z[2,6,5]  R1213     -1.4751896262168884e-01
    z[2,6,5]  R1214     -3.6593183875083923e-02
    z[2,6,5]  R1215     -8.8280633091926575e-02
    z[2,6,5]  R1216     1.9343499839305878e-01
    z[2,6,5]  R1217     -3.6710628867149353e-01
    z[2,6,5]  R1218     0.607828676700592
    z[2,6,5]  R1219     5.4488813877105713e-01
    z[2,6,5]  R1220     0.67137610912323
    z[2,6,5]  R1221     4.1305643320083618e-01
    z[2,6,5]  R1222     -0.018271429464221
    z[2,6,5]  R1223     1.4349387586116791e-01
    z[2,6,5]  R1224     5.8392512798309326e-01
    z[2,6,5]  R1225     2.1635049581527710e-01
    z[2,6,5]  R1226     -1.1129476875066757e-01
    z[2,6,5]  R1227     5.4812282323837280e-01
    z[2,6,5]  R1228     1.7855556309223175e-01
    z[2,6,5]  R1229     3.8373034447431564e-02
    z[2,6,5]  R1230     3.3966964483261108e-01
    z[2,6,5]  R1231     -1.1695603281259537e-01
    z[2,6,5]  R1232     -4.6720793843269348e-01
    z[2,6,5]  R1233     -5.8165037631988525e-01
    z[2,6,5]  R1234     -1.4780853688716888e-01
    z[2,6,5]  R1235     -4.4981312751770020e-01
    z[2,6,5]  R1236     -5.9563565254211426e-01
    z[2,6,5]  R1237     -4.4312477111816406e-02
    z[2,6,5]  R1238     -3.2998120784759521e-01
    z[2,6,5]  R1239     -8.6903309822082520e-01
    z[2,6,5]  R1240     -3.4434261918067932e-01
    z[2,6,5]  R1241     -3.8126403093338013e-01
    z[2,6,5]  R1242     -2.0543164014816284e-01
    z[2,6,5]  R1243     -5.7612472772598267e-01
    z[2,6,5]  R1244     -1.0551296174526215e-01
    z[2,6,5]  R1245     -5.4740172624588013e-01
    z[2,6,5]  R1246     1.8206527456641197e-02
    z[2,6,5]  R1247     -2.8901594877243042e-01
    z[2,6,5]  R1248     -2.9624858498573303e-01
    z[2,6,5]  R1249     -1.8342342972755432e-01
    z[2,6,5]  R1250     3.7831076979637146e-01
    z[2,6,5]  R1251     1.7657433450222015e-01
    z[2,6,5]  R1252     -3.4343191981315613e-01
    z[2,6,5]  R1253     -2.7499023079872131e-01
    z[2,6,5]  R1254     -2.2095876932144165e-01
    z[2,6,5]  R1255     2.4364241957664490e-01
    z[2,6,5]  R1256     -5.7318305969238281e-01
    z[2,6,5]  R1257     -2.4612143635749817e-01
    z[2,6,5]  R1258     -2.8453272581100464e-01
    z[2,6,5]  R1259     0.06783477216959
    z[2,6,5]  R1260     1.8392252922058105e-01
    z[2,6,5]  R1261     -8.6709603667259216e-02
    z[2,6,5]  R1262     -1.7306198179721832e-01
    z[2,6,5]  R1263     1.6388094425201416e-01
    z[2,6,5]  R1264     2.9382398352026939e-02
    z[2,6,5]  R1265     2.2259229794144630e-02
    z[2,6,5]  R1266     -1.5884411334991455e-01
    z[2,6,5]  R1267     1.3070951402187347e-01
    z[2,6,5]  R1268     3.4013697504997253e-01
    z[2,6,5]  R1269     2.4353970587253571e-01
    z[2,6,5]  R1270     3.0460250377655029e-01
    z[2,6,5]  R1271     1.4695046842098236e-01
    z[2,6,5]  R1272     -2.7154510840773582e-02
    z[2,6,5]  R1273     -4.0896151214838028e-02
    z[2,6,5]  R1274     -5.0095748156309128e-02
    z[2,6,5]  R1275     4.9466714262962341e-01
    z[2,6,5]  R1276     -1.7966248095035553e-01
    z[2,6,5]  R1277     -2.6726812124252319e-01
    z[2,6,5]  R1278     -2.2878044843673706e-01
    z[2,6,6]  R26       -1
    z[2,6,6]  R62       1
    z[2,6,6]  R1150     -1
    z[2,6,6]  R1151     1
    z[2,6,6]  R1152     -5.0029113888740540e-02
    z[2,6,6]  R1153     -2.3115381598472595e-01
    z[2,6,6]  R1154     -8.9278884232044220e-02
    z[2,6,6]  R1155     -1.0339193791151047e-01
    z[2,6,6]  R1156     2.1415881812572479e-01
    z[2,6,6]  R1157     -4.6624112129211426e-01
    z[2,6,6]  R1158     -3.0351492762565613e-01
    z[2,6,6]  R1159     -3.8648679852485657e-01
    z[2,6,6]  R1160     -1.0934099555015564e-01
    z[2,6,6]  R1161     -2.6732918620109558e-01
    z[2,6,6]  R1162     5.1108545064926147e-01
    z[2,6,6]  R1163     -7.2644329071044922e-01
    z[2,6,6]  R1164     -2.0665641129016876e-01
    z[2,6,6]  R1165     -5.1648229360580444e-01
    z[2,6,6]  R1166     -2.5272938609123230e-01
    z[2,6,6]  R1167     1.3192677497863770e-01
    z[2,6,6]  R1168     -9.0538740158081055e-02
    z[2,6,6]  R1169     4.9501422047615051e-01
    z[2,6,6]  R1170     6.2232349067926407e-02
    z[2,6,6]  R1171     -2.6739564538002014e-01
    z[2,6,6]  R1172     -2.0970292389392853e-01
    z[2,6,6]  R1173     1.6176858544349670e-01
    z[2,6,6]  R1174     -2.4438551068305969e-01
    z[2,6,6]  R1175     -1.0012000799179077e-01
    z[2,6,6]  R1176     -3.2189422845840454e-01
    z[2,6,6]  R1177     2.2226870059967041e-01
    z[2,6,6]  R1178     -0.262014240026474
    z[2,6,6]  R1179     -1.6785086691379547e-01
    z[2,6,6]  R1180     3.9106106758117676e-01
    z[2,6,6]  R1181     3.4687098860740662e-01
    z[2,6,6]  R1182     5.4809689521789551e-02
    z[2,6,6]  R1183     -6.6034264862537384e-02
    z[2,6,6]  R1184     1.3592340052127838e-01
    z[2,6,6]  R1185     1.0662989318370819e-01
    z[2,6,6]  R1186     4.2565248906612396e-02
    z[2,6,6]  R1187     -5.8749181032180786e-01
    z[2,6,6]  R1188     3.6409419775009155e-01
    z[2,6,6]  R1189     3.9275979995727539e-01
    z[2,6,6]  R1190     -7.0015847682952881e-02
    z[2,6,6]  R1191     7.8138843178749084e-02
    z[2,6,6]  R1192     1.0038229823112488e-01
    z[2,6,6]  R1193     5.6645695120096207e-02
    z[2,6,6]  R1194     1.4229616522789001e-01
    z[2,6,6]  R1195     1.3901987671852112e-01
    z[2,6,6]  R1196     0.23238605260849
    z[2,6,6]  R1197     2.2056837379932404e-01
    z[2,6,6]  R1198     3.3691248297691345e-01
    z[2,6,6]  R1199     1.2322041392326355e-01
    z[2,6,6]  R1200     1.0096822865307331e-02
    z[2,6,6]  R1201     6.1866792384535074e-04
    z[2,6,6]  R1202     0.0417693592607975
    z[2,6,6]  R1203     5.0848484039306641e-01
    z[2,6,6]  R1204     2.5371477007865906e-01
    z[2,6,6]  R1205     -7.3690533638000488e-02
    z[2,6,6]  R1206     2.1654383838176727e-01
    z[2,6,6]  R1207     1.7860314249992371e-01
    z[2,6,6]  R1208     -5.0366683863103390e-03
    z[2,6,6]  R1209     -2.3265336453914642e-01
    z[2,6,6]  R1210     -6.2715482711791992e-01
    z[2,6,6]  R1211     0.556354284286499
    z[2,6,6]  R1212     2.7617228031158447e-01
    z[2,6,6]  R1213     6.0965497046709061e-02
    z[2,6,6]  R1214     3.6251747608184814e-01
    z[2,6,6]  R1215     2.1518450975418091e-01
    z[2,6,6]  R1216     -3.1988853216171265e-01
    z[2,6,6]  R1217     -1.4080493152141571e-01
    z[2,6,6]  R1218     4.4668808579444885e-01
    z[2,6,6]  R1219     2.3696416616439819e-01
    z[2,6,6]  R1220     -1.7106316983699799e-01
    z[2,6,6]  R1221     2.4901130795478821e-01
    z[2,6,6]  R1222     3.7954360246658325e-01
    z[2,6,6]  R1223     7.6548673212528229e-02
    z[2,6,6]  R1224     -1.2867036461830139e-01
    z[2,6,6]  R1225     -5.1571053266525269e-01
    z[2,6,6]  R1226     4.7039404511451721e-01
    z[2,6,6]  R1227     3.7784385681152344e-01
    z[2,6,6]  R1228     -3.6855155229568481e-01
    z[2,6,6]  R1229     -1.6202476620674133e-01
    z[2,6,6]  R1230     -3.6887574940919876e-02
    z[2,6,6]  R1231     -6.1799097061157227e-01
    z[2,6,6]  R1232     -6.7602782510221004e-03
    z[2,6,6]  R1233     -1.1672931723296642e-02
    z[2,6,6]  R1234     1.8062233924865723e-01
    z[2,6,6]  R1235     0.368488609790802
    z[2,6,6]  R1236     3.7670186161994934e-01
    z[2,6,6]  R1237     2.9757311940193176e-01
    z[2,6,6]  R1238     2.2021479904651642e-01
    z[2,6,6]  R1239     -2.0640711486339569e-01
    z[2,6,6]  R1240     -1.9189366698265076e-01
    z[2,6,6]  R1241     -1.3751919567584991e-01
    z[2,6,6]  R1242     -0.345706045627594
    z[2,6,6]  R1243     2.2112955152988434e-01
    z[2,6,6]  R1244     3.3739423751831055e-01
    z[2,6,6]  R1245     2.9497742652893066e-01
    z[2,6,6]  R1246     -2.0037274062633514e-01
    z[2,6,6]  R1247     2.0725630223751068e-01
    z[2,6,6]  R1248     -2.3145695030689240e-01
    z[2,6,6]  R1249     -5.2521222829818726e-01
    z[2,6,6]  R1250     -1.3092701137065887e-01
    z[2,6,6]  R1251     -1.5891024842858315e-02
    z[2,6,6]  R1252     -9.6572116017341614e-02
    z[2,6,6]  R1253     2.2791130840778351e-01
    z[2,6,6]  R1254     1.6141925752162933e-01
    z[2,6,6]  R1255     3.1756326556205750e-01
    z[2,6,6]  R1256     -4.5917022228240967e-01
    z[2,6,6]  R1257     -3.1051045656204224e-01
    z[2,6,6]  R1258     -1.4357627928256989e-01
    z[2,6,6]  R1259     2.4317464232444763e-01
    z[2,6,6]  R1260     -2.9501739144325256e-01
    z[2,6,6]  R1261     2.4745029211044312e-01
    z[2,6,6]  R1262     8.3945758640766144e-02
    z[2,6,6]  R1263     0.151498481631279
    z[2,6,6]  R1264     4.9973125569522381e-03
    z[2,6,6]  R1265     -3.1996732950210571e-01
    z[2,6,6]  R1266     1.3361082971096039e-01
    z[2,6,6]  R1267     -1.6888926923274994e-01
    z[2,6,6]  R1268     1.0487063229084015e-01
    z[2,6,6]  R1269     -1.3252280652523041e-01
    z[2,6,6]  R1270     -2.5968968868255615e-02
    z[2,6,6]  R1271     1.6199924051761627e-01
    z[2,6,6]  R1272     -1.4860944449901581e-01
    z[2,6,6]  R1273     -2.9217207431793213e-01
    z[2,6,6]  R1274     -1.1926929652690887e-01
    z[2,6,6]  R1275     -4.1505265235900879e-01
    z[2,6,6]  R1276     -0.0943610891699791
    z[2,6,6]  R1277     -6.3995391130447388e-01
    z[2,6,6]  R1278     -1.2046817690134048e-01
    z[6,2,0]  R20       1
    z[6,2,0]  R56       -1
    z[6,2,0]  R1279     -1
    z[6,2,0]  R1280     1
    z[6,2,0]  R1293     -2.6799976825714111e-01
    z[6,2,0]  R1294     -3.0848485231399536e-01
    z[6,2,0]  R1295     -0.502948522567749
    z[6,2,0]  R1296     -4.1463658213615417e-01
    z[6,2,0]  R1297     -4.0166664123535156e-01
    z[6,2,0]  R1298     -6.7071980237960815e-01
    z[6,2,0]  R1299     4.1482448577880859e-01
    z[6,2,0]  R1300     1.3724394142627716e-01
    z[6,2,0]  R1301     1.4065656065940857e-01
    z[6,2,0]  R1302     -1.9479477405548096e-01
    z[6,2,0]  R1303     3.3613452315330505e-01
    z[6,2,0]  R1304     1.0425824671983719e-01
    z[6,2,0]  R1305     0.254373162984848
    z[6,2,0]  R1306     -1.9016842544078827e-01
    z[6,2,0]  R1307     1.0421057045459747e-01
    z[6,2,0]  R1308     5.0094765424728394e-01
    z[6,2,0]  R1309     -4.1455483436584473e-01
    z[6,2,0]  R1310     -1.5327689051628113e-01
    z[6,2,0]  R1311     -7.3224997520446777e-01
    z[6,2,0]  R1312     -4.9367743730545044e-01
    z[6,2,0]  R1313     1.4100821316242218e-01
    z[6,2,0]  R1314     2.1753439307212830e-01
    z[6,2,0]  R1315     -1.2073613703250885e-01
    z[6,2,0]  R1316     -1.8786756694316864e-01
    z[6,2,0]  R1317     -9.2207081615924835e-03
    z[6,2,0]  R1318     2.0490171015262604e-01
    z[6,2,0]  R1319     -4.1622537374496460e-01
    z[6,2,0]  R1320     -0.274004727602005
    z[6,2,0]  R1321     1.6240687668323517e-01
    z[6,2,0]  R1322     -5.9607338905334473e-01
    z[6,2,0]  R1323     -3.1939432024955750e-01
    z[6,2,0]  R1324     -4.3587210774421692e-01
    z[6,2,0]  R1325     4.1314664483070374e-01
    z[6,2,0]  R1326     -1.7168661952018738e-01
    z[6,2,0]  R1327     -0.0768650621175766
    z[6,2,0]  R1328     1.2949213385581970e-01
    z[6,2,0]  R1329     -8.7719194591045380e-02
    z[6,2,0]  R1330     5.6931927800178528e-02
    z[6,2,0]  R1331     5.4856240749359131e-01
    z[6,2,0]  R1332     6.0297280550003052e-01
    z[6,2,0]  R1333     -1.9797690212726593e-01
    z[6,2,0]  R1334     1.5428879298269749e-02
    z[6,2,0]  R1335     1.7626523971557617e-01
    z[6,2,0]  R1336     4.1131421923637390e-01
    z[6,2,0]  R1337     2.3615600541234016e-02
    z[6,2,0]  R1338     5.5942213535308838e-01
    z[6,2,0]  R1339     3.5299485921859741e-01
    z[6,2,0]  R1340     -1.6912724822759628e-02
    z[6,2,0]  R1341     1.3452319800853729e-01
    z[6,2,0]  R1342     2.1778613328933716e-01
    z[6,2,0]  R1343     -2.8781610727310181e-01
    z[6,2,0]  R1344     3.7395498156547546e-01
    z[6,2,0]  R1345     2.0948988199234009e-01
    z[6,2,0]  R1346     1.1307834833860397e-01
    z[6,2,0]  R1347     -1.8201948702335358e-01
    z[6,2,0]  R1348     -2.8810063004493713e-01
    z[6,2,0]  R1349     9.0143084526062012e-01
    z[6,2,0]  R1350     -4.9124273657798767e-01
    z[6,2,0]  R1351     -7.7634233236312866e-01
    z[6,2,0]  R1352     -4.5373073220252991e-01
    z[6,2,0]  R1353     -6.8108010292053223e-01
    z[6,2,0]  R1354     -7.1953850984573364e-01
    z[6,2,0]  R1355     -4.6407660841941833e-01
    z[6,2,0]  R1356     -3.3312138915061951e-01
    z[6,2,0]  R1357     -7.2410744428634644e-01
    z[6,2,0]  R1358     -6.1397582292556763e-01
    z[6,2,0]  R1359     -1.4422667026519775e-01
    z[6,2,0]  R1360     6.1473723500967026e-02
    z[6,2,0]  R1361     0.153394877910614
    z[6,2,0]  R1362     -2.0218744874000549e-01
    z[6,2,0]  R1363     -1.8500488996505737e-01
    z[6,2,0]  R1364     1.5352945029735565e-01
    z[6,2,0]  R1365     9.4493657350540161e-02
    z[6,2,0]  R1366     -0.059889055788517
    z[6,2,0]  R1367     2.3794810473918915e-01
    z[6,2,0]  R1368     -2.4597447365522385e-02
    z[6,2,0]  R1369     4.5672440528869629e-01
    z[6,2,0]  R1370     4.7142812609672546e-01
    z[6,2,0]  R1371     2.4861901998519897e-02
    z[6,2,0]  R1372     -1.4215698838233948e-01
    z[6,2,0]  R1373     5.0571531057357788e-01
    z[6,2,0]  R1374     1.2481260299682617e-01
    z[6,2,0]  R1375     -4.0614360570907593e-01
    z[6,2,0]  R1376     -1.9890600442886353e-01
    z[6,2,0]  R1377     1.8972903490066528e-02
    z[6,2,0]  R1378     -6.2058974057435989e-02
    z[6,2,0]  R1379     -1.0376165807247162e-01
    z[6,2,0]  R1380     -1.7810884118080139e-01
    z[6,2,0]  R1381     9.4430714845657349e-02
    z[6,2,0]  R1382     1.2676912546157837e-01
    z[6,2,0]  R1383     -1.5843637287616730e-01
    z[6,2,0]  R1384     4.0129086375236511e-01
    z[6,2,0]  R1385     2.0959985256195068e-01
    z[6,2,0]  R1386     4.2695617675781250e-01
    z[6,2,0]  R1387     -8.0943085253238678e-02
    z[6,2,0]  R1388     -3.6984920501708984e-01
    z[6,2,0]  R1389     -6.6380125284194946e-01
    z[6,2,0]  R1390     -4.9481880851089954e-03
    z[6,2,0]  R1391     -6.7595876753330231e-03
    z[6,2,0]  R1392     2.1995209157466888e-01
    z[6,2,0]  R1393     -5.0826031714677811e-02
    z[6,2,0]  R1394     4.4874809682369232e-02
    z[6,2,0]  R1395     -3.3454048633575439e-01
    z[6,2,0]  R1396     2.5708615779876709e-01
    z[6,2,0]  R1397     6.0063779354095459e-01
    z[6,2,0]  R1398     -6.4115297794342041e-01
    z[6,2,0]  R1399     -3.8052040338516235e-01
    z[6,2,0]  R1400     2.9909870028495789e-01
    z[6,2,0]  R1401     -1.2768530286848545e-02
    z[6,2,0]  R1402     -2.4318021535873413e-01
    z[6,2,0]  R1403     6.0623455792665482e-02
    z[6,2,0]  R1404     -4.2846912145614624e-01
    z[6,2,0]  R1405     -2.1448197960853577e-01
    z[6,2,0]  R1406     -3.8751190900802612e-01
    z[6,2,0]  R1407     5.0506293773651123e-01
    z[6,2,0]  R1408     2.9371036216616631e-02
    z[6,2,0]  R1409     -1.8463903665542603e-01
    z[6,2,0]  R1410     -1.7569494247436523e-01
    z[6,2,0]  R1411     -3.0998736619949341e-01
    z[6,2,0]  R1412     -0.0892467051744461
    z[6,2,0]  R1413     3.0539789795875549e-01
    z[6,2,0]  R1414     -3.7317898869514465e-01
    z[6,2,0]  R1415     4.7704753279685974e-01
    z[6,2,0]  R1416     3.6393198370933533e-01
    z[6,2,0]  R1417     6.0187149047851562e-01
    z[6,2,0]  R1418     0.573669970035553
    z[6,2,0]  R1419     6.0565555095672607e-01
    z[6,2,1]  R21       1
    z[6,2,1]  R57       -1
    z[6,2,1]  R1281     -1
    z[6,2,1]  R1282     1
    z[6,2,1]  R1293     2.6034945249557495e-01
    z[6,2,1]  R1294     -3.4273234009742737e-01
    z[6,2,1]  R1295     3.3970236778259277e-01
    z[6,2,1]  R1296     0.287553071975708
    z[6,2,1]  R1297     -1.8081579357385635e-02
    z[6,2,1]  R1298     -1.0382114350795746e-01
    z[6,2,1]  R1299     6.3087075948715210e-01
    z[6,2,1]  R1300     6.6886502504348755e-01
    z[6,2,1]  R1301     7.1507990360260010e-01
    z[6,2,1]  R1302     1.6465568542480469e-01
    z[6,2,1]  R1303     -1.9731727242469788e-01
    z[6,2,1]  R1304     2.3253744840621948e-01
    z[6,2,1]  R1305     -1.3593323528766632e-01
    z[6,2,1]  R1306     4.5358244329690933e-02
    z[6,2,1]  R1307     -0.3088398873806
    z[6,2,1]  R1308     -2.1598720923066139e-02
    z[6,2,1]  R1309     -1.5587671659886837e-02
    z[6,2,1]  R1310     -1.1244186758995056e-01
    z[6,2,1]  R1311     -1.2262280285358429e-01
    z[6,2,1]  R1312     -4.1260862350463867e-01
    z[6,2,1]  R1313     -2.0453684031963348e-01
    z[6,2,1]  R1314     1.3772989809513092e-01
    z[6,2,1]  R1315     -3.0731928348541260e-01
    z[6,2,1]  R1316     3.0537009239196777e-01
    z[6,2,1]  R1317     1.7410951852798462e-01
    z[6,2,1]  R1318     5.5265665054321289e-01
    z[6,2,1]  R1319     3.9770871400833130e-01
    z[6,2,1]  R1320     1.5753868967294693e-02
    z[6,2,1]  R1321     -2.0316170156002045e-01
    z[6,2,1]  R1322     -2.0895386114716530e-02
    z[6,2,1]  R1323     3.3721652626991272e-01
    z[6,2,1]  R1324     0.0609736330807209
    z[6,2,1]  R1325     -3.0422195792198181e-01
    z[6,2,1]  R1326     2.3960523307323456e-01
    z[6,2,1]  R1327     5.8998677879571915e-02
    z[6,2,1]  R1328     8.6291587352752686e-01
    z[6,2,1]  R1329     8.5653185844421387e-01
    z[6,2,1]  R1330     8.1906998157501221e-01
    z[6,2,1]  R1331     7.3512208461761475e-01
    z[6,2,1]  R1332     4.4444590806961060e-01
    z[6,2,1]  R1333     -2.5734481215476990e-01
    z[6,2,1]  R1334     3.8917216658592224e-01
    z[6,2,1]  R1335     9.5235210657119751e-01
    z[6,2,1]  R1336     -1.1356313712894917e-02
    z[6,2,1]  R1337     9.0541803836822510e-01
    z[6,2,1]  R1338     5.4022759199142456e-01
    z[6,2,1]  R1339     5.0834619998931885e-01
    z[6,2,1]  R1340     -9.0297651290893555e-01
    z[6,2,1]  R1341     -8.1154477596282959e-01
    z[6,2,1]  R1342     -9.0584987401962280e-01
    z[6,2,1]  R1343     -1.6611185669898987e-01
    z[6,2,1]  R1344     9.2443414032459259e-02
    z[6,2,1]  R1345     3.8873386383056641e-01
    z[6,2,1]  R1346     -6.8229228258132935e-01
    z[6,2,1]  R1347     -3.2924848794937134e-01
    z[6,2,1]  R1348     -2.0766112208366394e-01
    z[6,2,1]  R1349     -1.3121864199638367e-01
    z[6,2,1]  R1350     -4.4544604420661926e-01
    z[6,2,1]  R1351     -4.0777593851089478e-01
    z[6,2,1]  R1352     -4.2607891559600830e-01
    z[6,2,1]  R1353     -2.7949529886245728e-01
    z[6,2,1]  R1354     -0.350705623626709
    z[6,2,1]  R1355     -0.363901287317276
    z[6,2,1]  R1356     -4.9221006035804749e-01
    z[6,2,1]  R1357     -3.8024628162384033e-01
    z[6,2,1]  R1358     0.237028107047081
    z[6,2,1]  R1359     -8.7349957227706909e-01
    z[6,2,1]  R1360     -2.5577083230018616e-01
    z[6,2,1]  R1361     2.4164129793643951e-01
    z[6,2,1]  R1362     0.829850971698761
    z[6,2,1]  R1363     6.4701384305953979e-01
    z[6,2,1]  R1364     9.1239744424819946e-01
    z[6,2,1]  R1365     8.7869280576705933e-01
    z[6,2,1]  R1366     8.8222002983093262e-01
    z[6,2,1]  R1367     3.3945631980895996e-01
    z[6,2,1]  R1368     7.9038488864898682e-01
    z[6,2,1]  R1369     4.7249439358711243e-01
    z[6,2,1]  R1370     -2.5328485295176506e-02
    z[6,2,1]  R1371     -4.2231306433677673e-01
    z[6,2,1]  R1372     1.6041561961174011e-01
    z[6,2,1]  R1373     9.7372457385063171e-02
    z[6,2,1]  R1374     3.9665067195892334e-01
    z[6,2,1]  R1375     5.0427418947219849e-01
    z[6,2,1]  R1376     -2.2575311362743378e-01
    z[6,2,1]  R1377     2.1479836106300354e-01
    z[6,2,1]  R1378     2.1152751147747040e-01
    z[6,2,1]  R1379     2.3155732452869415e-01
    z[6,2,1]  R1380     -2.0896512269973755e-01
    z[6,2,1]  R1381     -8.6768402252346277e-04
    z[6,2,1]  R1382     4.8274621367454529e-01
    z[6,2,1]  R1383     3.2020667195320129e-01
    z[6,2,1]  R1384     1.8010555207729340e-01
    z[6,2,1]  R1385     -4.0624219179153442e-01
    z[6,2,1]  R1386     -4.6342805027961731e-02
    z[6,2,1]  R1387     2.6514491438865662e-01
    z[6,2,1]  R1388     2.3521491885185242e-01
    z[6,2,1]  R1389     2.4544388055801392e-01
    z[6,2,1]  R1390     -8.3455711603164673e-02
    z[6,2,1]  R1391     1.5370737016201019e-01
    z[6,2,1]  R1392     2.3272086679935455e-01
    z[6,2,1]  R1393     3.5309621691703796e-01
    z[6,2,1]  R1394     1.4941997826099396e-01
    z[6,2,1]  R1395     -3.7667483091354370e-02
    z[6,2,1]  R1396     4.8218145966529846e-01
    z[6,2,1]  R1397     -1.7782464623451233e-01
    z[6,2,1]  R1398     3.9055651426315308e-01
    z[6,2,1]  R1399     4.6254959702491760e-01
    z[6,2,1]  R1400     2.5293555110692978e-02
    z[6,2,1]  R1401     1.9626750051975250e-01
    z[6,2,1]  R1402     9.6097335219383240e-02
    z[6,2,1]  R1403     1.5056197345256805e-01
    z[6,2,1]  R1404     1.8992094695568085e-01
    z[6,2,1]  R1405     3.4925243258476257e-01
    z[6,2,1]  R1406     -9.8732315003871918e-02
    z[6,2,1]  R1407     -1.1955556273460388e-01
    z[6,2,1]  R1408     -4.8471504449844360e-01
    z[6,2,1]  R1409     3.3883380889892578e-01
    z[6,2,1]  R1410     -4.6554881334304810e-01
    z[6,2,1]  R1411     8.7587319314479828e-02
    z[6,2,1]  R1412     3.0281466245651245e-01
    z[6,2,1]  R1413     0.00760143157094717
    z[6,2,1]  R1414     2.8109899163246155e-01
    z[6,2,1]  R1415     4.2320245504379272e-01
    z[6,2,1]  R1416     -2.1706353127956390e-01
    z[6,2,1]  R1417     -3.9704304933547974e-01
    z[6,2,1]  R1418     -1.0005540400743484e-01
    z[6,2,1]  R1419     -0.344194233417511
    z[6,2,2]  R22       1
    z[6,2,2]  R58       -1
    z[6,2,2]  R1283     -1
    z[6,2,2]  R1284     1
    z[6,2,2]  R1293     -3.9756676554679871e-01
    z[6,2,2]  R1294     -4.9994894862174988e-01
    z[6,2,2]  R1295     -2.3084443807601929e-01
    z[6,2,2]  R1296     -2.0341536402702332e-01
    z[6,2,2]  R1297     1.1693882942199707e-01
    z[6,2,2]  R1298     8.1346176564693451e-02
    z[6,2,2]  R1299     -2.8455637395381927e-02
    z[6,2,2]  R1300     -4.7480916976928711e-01
    z[6,2,2]  R1301     0.399924099445343
    z[6,2,2]  R1302     -3.5927772521972656e-01
    z[6,2,2]  R1303     -2.6057684421539307e-01
    z[6,2,2]  R1304     7.0517949759960175e-02
    z[6,2,2]  R1305     1.9377246499061584e-01
    z[6,2,2]  R1306     -3.5220120102167130e-02
    z[6,2,2]  R1307     -1.5724499523639679e-01
    z[6,2,2]  R1308     -0.251311331987381
    z[6,2,2]  R1309     -4.4861888885498047e-01
    z[6,2,2]  R1310     8.4616623818874359e-02
    z[6,2,2]  R1311     -4.3666278943419456e-03
    z[6,2,2]  R1312     2.8069657087326050e-01
    z[6,2,2]  R1313     1.4100825786590576e-01
    z[6,2,2]  R1314     -8.8609211146831512e-02
    z[6,2,2]  R1315     -3.8922277092933655e-01
    z[6,2,2]  R1316     -8.1903554499149323e-02
    z[6,2,2]  R1317     -0.564672589302063
    z[6,2,2]  R1318     -3.1437207013368607e-02
    z[6,2,2]  R1319     -1.1584430932998657e-01
    z[6,2,2]  R1320     -2.2531510889530182e-01
    z[6,2,2]  R1321     2.7839755639433861e-03
    z[6,2,2]  R1322     -5.0746973603963852e-02
    z[6,2,2]  R1323     -2.3050782084465027e-01
    z[6,2,2]  R1324     2.4781459942460060e-02
    z[6,2,2]  R1325     -6.3811242580413818e-02
    z[6,2,2]  R1326     -8.2455776631832123e-02
    z[6,2,2]  R1327     -2.8026726841926575e-01
    z[6,2,2]  R1328     7.1502029895782471e-02
    z[6,2,2]  R1329     2.1758085489273071e-01
    z[6,2,2]  R1330     3.5238778591156006e-01
    z[6,2,2]  R1331     -1.8645766377449036e-01
    z[6,2,2]  R1332     3.1171867251396179e-01
    z[6,2,2]  R1333     -3.9491170644760132e-01
    z[6,2,2]  R1334     1.6960716247558594e-01
    z[6,2,2]  R1335     -1.4601002633571625e-01
    z[6,2,2]  R1336     -4.1508537530899048e-01
    z[6,2,2]  R1337     2.7347663044929504e-01
    z[6,2,2]  R1338     2.0718546211719513e-01
    z[6,2,2]  R1339     3.8754299283027649e-01
    z[6,2,2]  R1340     7.2244450449943542e-02
    z[6,2,2]  R1341     0.145552858710289
    z[6,2,2]  R1342     5.7123210281133652e-02
    z[6,2,2]  R1343     -3.3237934112548828e-01
    z[6,2,2]  R1344     -3.8678976893424988e-01
    z[6,2,2]  R1345     5.5587112903594971e-01
    z[6,2,2]  R1346     -3.4621194005012512e-02
    z[6,2,2]  R1347     -0.0864488035440445
    z[6,2,2]  R1348     -1.7532606422901154e-01
    z[6,2,2]  R1349     -0.0704229474067688
    z[6,2,2]  R1350     -5.0723069906234741e-01
    z[6,2,2]  R1351     -3.0221751332283020e-01
    z[6,2,2]  R1352     -5.4670047760009766e-01
    z[6,2,2]  R1353     -5.1954925060272217e-01
    z[6,2,2]  R1354     -3.8589019328355789e-02
    z[6,2,2]  R1355     -6.0903567075729370e-01
    z[6,2,2]  R1356     -4.8527535051107407e-02
    z[6,2,2]  R1357     -2.2927054762840271e-01
    z[6,2,2]  R1358     -6.1901479959487915e-01
    z[6,2,2]  R1359     3.8353729993104935e-02
    z[6,2,2]  R1360     4.4338819384574890e-01
    z[6,2,2]  R1361     -3.2167810946702957e-02
    z[6,2,2]  R1362     3.1972485780715942e-01
    z[6,2,2]  R1363     5.0286766141653061e-02
    z[6,2,2]  R1364     1.2339603155851364e-01
    z[6,2,2]  R1365     2.6287573575973511e-01
    z[6,2,2]  R1366     2.2269165515899658e-01
    z[6,2,2]  R1367     6.6414773464202881e-01
    z[6,2,2]  R1368     7.4134194292128086e-03
    z[6,2,2]  R1369     -2.6723316311836243e-01
    z[6,2,2]  R1370     -0.0663272812962532
    z[6,2,2]  R1371     -3.2018488645553589e-01
    z[6,2,2]  R1372     -3.5017940402030945e-01
    z[6,2,2]  R1373     1.4386005699634552e-01
    z[6,2,2]  R1374     -8.9014537632465363e-02
    z[6,2,2]  R1375     1.2869903445243835e-01
    z[6,2,2]  R1376     3.2295051217079163e-01
    z[6,2,2]  R1377     3.2745265960693359e-01
    z[6,2,2]  R1378     -2.7053061127662659e-01
    z[6,2,2]  R1379     -3.1839540600776672e-01
    z[6,2,2]  R1380     4.8677217960357666e-01
    z[6,2,2]  R1381     8.2149881124496460e-01
    z[6,2,2]  R1382     5.7530528306961060e-01
    z[6,2,2]  R1383     1.1776317656040192e-01
    z[6,2,2]  R1384     -4.4055002927780151e-01
    z[6,2,2]  R1385     3.9006423950195312e-01
    z[6,2,2]  R1386     -2.8825944662094116e-01
    z[6,2,2]  R1387     -1.3484659790992737e-01
    z[6,2,2]  R1388     2.1095946431159973e-01
    z[6,2,2]  R1389     -1.1477702856063843e-01
    z[6,2,2]  R1390     5.4724162817001343e-01
    z[6,2,2]  R1391     -2.2157758474349976e-01
    z[6,2,2]  R1392     3.6912760138511658e-01
    z[6,2,2]  R1393     -1.3935816287994385e-01
    z[6,2,2]  R1394     -1.5904602408409119e-01
    z[6,2,2]  R1395     -1.1023134738206863e-01
    z[6,2,2]  R1396     -3.6716946959495544e-01
    z[6,2,2]  R1397     6.4137715101242065e-01
    z[6,2,2]  R1398     4.7803804278373718e-02
    z[6,2,2]  R1399     -1.0268244892358780e-01
    z[6,2,2]  R1400     -4.5061972737312317e-01
    z[6,2,2]  R1401     3.8992297649383545e-01
    z[6,2,2]  R1402     1.1180755496025085e-01
    z[6,2,2]  R1403     -4.3792682886123657e-01
    z[6,2,2]  R1404     -2.3457825183868408e-01
    z[6,2,2]  R1405     5.8858606964349747e-02
    z[6,2,2]  R1406     -3.3551222085952759e-01
    z[6,2,2]  R1407     0.629315972328186
    z[6,2,2]  R1408     -3.7618912756443024e-02
    z[6,2,2]  R1409     -1.8613802269101143e-02
    z[6,2,2]  R1410     -1.5646006166934967e-01
    z[6,2,2]  R1411     -3.8047635555267334e-01
    z[6,2,2]  R1412     -2.5038030743598938e-01
    z[6,2,2]  R1413     -2.7576902508735657e-01
    z[6,2,2]  R1414     -1.3379658758640289e-01
    z[6,2,2]  R1415     4.4476044178009033e-01
    z[6,2,2]  R1416     -3.8278463482856750e-01
    z[6,2,2]  R1417     -1.5245710313320160e-01
    z[6,2,2]  R1418     -3.1500127911567688e-01
    z[6,2,2]  R1419     -4.9095860123634338e-01
    z[6,2,3]  R23       1
    z[6,2,3]  R59       -1
    z[6,2,3]  R1285     -1
    z[6,2,3]  R1286     1
    z[6,2,3]  R1293     6.5393263101577759e-01
    z[6,2,3]  R1294     5.0959396362304688e-01
    z[6,2,3]  R1295     4.0262740850448608e-01
    z[6,2,3]  R1296     0.0463026687502861
    z[6,2,3]  R1297     -7.2940096259117126e-02
    z[6,2,3]  R1298     2.8767937421798706e-01
    z[6,2,3]  R1299     -0.0512276254594326
    z[6,2,3]  R1300     -7.1023985743522644e-02
    z[6,2,3]  R1301     -3.7454909086227417e-01
    z[6,2,3]  R1302     -7.4034363031387329e-02
    z[6,2,3]  R1303     -3.3794444799423218e-01
    z[6,2,3]  R1304     -2.8308334946632385e-01
    z[6,2,3]  R1305     -0.391967236995697
    z[6,2,3]  R1306     -2.7441471815109253e-01
    z[6,2,3]  R1307     -3.5618439316749573e-01
    z[6,2,3]  R1308     -4.3386444449424744e-01
    z[6,2,3]  R1309     -2.6035135984420776e-01
    z[6,2,3]  R1310     -3.7802201509475708e-01
    z[6,2,3]  R1311     -3.1466564536094666e-01
    z[6,2,3]  R1312     -2.4095329642295837e-01
    z[6,2,3]  R1313     -6.8053388595581055e-01
    z[6,2,3]  R1314     -7.2847908735275269e-01
    z[6,2,3]  R1315     -7.1762156486511230e-01
    z[6,2,3]  R1316     -6.7181175947189331e-01
    z[6,2,3]  R1317     -7.5338131189346313e-01
    z[6,2,3]  R1318     -6.4652174711227417e-01
    z[6,2,3]  R1319     -6.3391441106796265e-01
    z[6,2,3]  R1320     -5.2807462215423584e-01
    z[6,2,3]  R1321     -6.9509744644165039e-01
    z[6,2,3]  R1322     -7.5340855121612549e-01
    z[6,2,3]  R1323     -6.3471955060958862e-01
    z[6,2,3]  R1324     -7.7655339241027832e-01
    z[6,2,3]  R1325     -6.2197327613830566e-01
    z[6,2,3]  R1326     -6.6663116216659546e-01
    z[6,2,3]  R1327     -5.9071314334869385e-01
    z[6,2,3]  R1328     2.1089186891913414e-02
    z[6,2,3]  R1329     4.1512794792652130e-02
    z[6,2,3]  R1330     -3.4831660985946655e-01
    z[6,2,3]  R1331     -3.0824735760688782e-02
    z[6,2,3]  R1332     -5.2167940139770508e-01
    z[6,2,3]  R1333     -4.0444770455360413e-01
    z[6,2,3]  R1334     -8.0958712100982666e-01
    z[6,2,3]  R1335     -1.7638245224952698e-01
    z[6,2,3]  R1336     -4.1537594795227051e-01
    z[6,2,3]  R1337     -1.8703933060169220e-01
    z[6,2,3]  R1338     -5.4770672321319580e-01
    z[6,2,3]  R1339     -5.7849675416946411e-01
    z[6,2,3]  R1340     -2.0557032525539398e-01
    z[6,2,3]  R1341     -4.5151209831237793e-01
    z[6,2,3]  R1342     -2.2021782398223877e-01
    z[6,2,3]  R1343     -8.3125251531600952e-01
    z[6,2,3]  R1344     -0.372031033039093
    z[6,2,3]  R1345     -0.626023530960083
    z[6,2,3]  R1346     -3.2117596268653870e-01
    z[6,2,3]  R1347     4.4315099716186523e-01
    z[6,2,3]  R1348     3.2139471173286438e-01
    z[6,2,3]  R1349     2.2495168447494507e-01
    z[6,2,3]  R1350     5.0857901573181152e-01
    z[6,2,3]  R1351     2.4969819188117981e-01
    z[6,2,3]  R1352     4.9621476791799068e-03
    z[6,2,3]  R1353     -1.0981449484825134e-01
    z[6,2,3]  R1354     5.2821516990661621e-01
    z[6,2,3]  R1355     -3.8038119673728943e-02
    z[6,2,3]  R1356     6.7629760503768921e-01
    z[6,2,3]  R1357     -1.7949819564819336e-01
    z[6,2,3]  R1358     3.6374571919441223e-01
    z[6,2,3]  R1359     2.1840167045593262e-01
    z[6,2,3]  R1360     -0.52577143907547
    z[6,2,3]  R1361     -4.1349199414253235e-01
    z[6,2,3]  R1362     -1.5367542207241058e-01
    z[6,2,3]  R1363     -4.5624691247940063e-01
    z[6,2,3]  R1364     -2.2992837429046631e-01
    z[6,2,3]  R1365     -5.1483251154422760e-02
    z[6,2,3]  R1366     9.5154352486133575e-02
    z[6,2,3]  R1367     -3.0231153964996338e-01
    z[6,2,3]  R1368     -3.1349179148674011e-01
    z[6,2,3]  R1369     -4.9525824189186096e-01
    z[6,2,3]  R1370     -7.8650033473968506e-01
    z[6,2,3]  R1371     -4.3379139900207520e-01
    z[6,2,3]  R1372     -6.5854293107986450e-01
    z[6,2,3]  R1373     -5.3881102800369263e-01
    z[6,2,3]  R1374     -7.9445666074752808e-01
    z[6,2,3]  R1375     -4.4195863604545593e-01
    z[6,2,3]  R1376     -7.2630548477172852e-01
    z[6,2,3]  R1377     -8.7272793054580688e-01
    z[6,2,3]  R1378     2.8594639897346497e-01
    z[6,2,3]  R1379     0.0881413072347641
    z[6,2,3]  R1380     -8.0582714080810547e-01
    z[6,2,3]  R1381     -2.6946470141410828e-01
    z[6,2,3]  R1382     -4.8328486084938049e-01
    z[6,2,3]  R1383     6.5524083375930786e-01
    z[6,2,3]  R1384     6.8470877408981323e-01
    z[6,2,3]  R1385     -4.3322277069091797e-01
    z[6,2,3]  R1386     7.4889016151428223e-01
    z[6,2,3]  R1387     -6.5494573116302490e-01
    z[6,2,3]  R1388     7.3258213698863983e-02
    z[6,2,3]  R1389     -2.6382020115852356e-01
    z[6,2,3]  R1390     -4.8871728777885437e-01
    z[6,2,3]  R1391     8.1759041547775269e-01
    z[6,2,3]  R1392     -0.515705943107605
    z[6,2,3]  R1393     0.695762038230896
    z[6,2,3]  R1394     6.9523996114730835e-01
    z[6,2,3]  R1395     8.0560527741909027e-02
    z[6,2,3]  R1396     -2.6228037476539612e-01
    z[6,2,3]  R1397     -1.9468809664249420e-01
    z[6,2,3]  R1398     2.4396492540836334e-01
    z[6,2,3]  R1399     0.0779092013835907
    z[6,2,3]  R1400     -6.5498644113540649e-01
    z[6,2,3]  R1401     -4.8331132531166077e-01
    z[6,2,3]  R1402     6.9152086973190308e-01
    z[6,2,3]  R1403     4.8625549674034119e-01
    z[6,2,3]  R1404     5.0809867680072784e-02
    z[6,2,3]  R1405     7.3908466100692749e-01
    z[6,2,3]  R1406     -4.5410543680191040e-02
    z[6,2,3]  R1407     -2.5981745123863220e-01
    z[6,2,3]  R1408     -3.5016742348670959e-01
    z[6,2,3]  R1409     -5.8826500177383423e-01
    z[6,2,3]  R1410     -5.9510171413421631e-01
    z[6,2,3]  R1411     4.4107037782669067e-01
    z[6,2,3]  R1412     8.3597046136856079e-01
    z[6,2,3]  R1413     8.7238538265228271e-01
    z[6,2,3]  R1414     2.2495311498641968e-01
    z[6,2,3]  R1415     2.1142323315143585e-01
    z[6,2,3]  R1416     1.0871886461973190e-01
    z[6,2,3]  R1417     -2.1498848497867584e-01
    z[6,2,3]  R1418     2.7603426575660706e-01
    z[6,2,3]  R1419     -3.3645071089267731e-02
    z[6,2,4]  R24       1
    z[6,2,4]  R60       -1
    z[6,2,4]  R1287     -1
    z[6,2,4]  R1288     1
    z[6,2,4]  R1293     -3.6099845170974731e-01
    z[6,2,4]  R1294     -5.0128477811813354e-01
    z[6,2,4]  R1295     -2.4232718348503113e-01
    z[6,2,4]  R1296     -6.2378132343292236e-01
    z[6,2,4]  R1297     -7.6530051231384277e-01
    z[6,2,4]  R1298     -8.2309916615486145e-02
    z[6,2,4]  R1299     5.0870066881179810e-01
    z[6,2,4]  R1300     5.2494859695434570e-01
    z[6,2,4]  R1301     2.2784644365310669e-01
    z[6,2,4]  R1302     6.3623136281967163e-01
    z[6,2,4]  R1303     6.6906195878982544e-01
    z[6,2,4]  R1304     0.715188205242157
    z[6,2,4]  R1305     8.1924271583557129e-01
    z[6,2,4]  R1306     7.3967492580413818e-01
    z[6,2,4]  R1307     4.9545809626579285e-01
    z[6,2,4]  R1308     6.3771128654479980e-01
    z[6,2,4]  R1309     6.3362246751785278e-01
    z[6,2,4]  R1310     1.2641207873821259e-01
    z[6,2,4]  R1311     4.4084584712982178e-01
    z[6,2,4]  R1312     5.3377324342727661e-01
    z[6,2,4]  R1313     5.4180890321731567e-01
    z[6,2,4]  R1314     1.1982502788305283e-01
    z[6,2,4]  R1315     3.1549152731895447e-01
    z[6,2,4]  R1316     1.6357085108757019e-01
    z[6,2,4]  R1317     2.0659507811069489e-01
    z[6,2,4]  R1318     3.2729476690292358e-01
    z[6,2,4]  R1319     3.3463621139526367e-01
    z[6,2,4]  R1320     5.3437018394470215e-01
    z[6,2,4]  R1321     5.3751307725906372e-01
    z[6,2,4]  R1322     2.0646791160106659e-01
    z[6,2,4]  R1323     4.4832786917686462e-01
    z[6,2,4]  R1324     2.7401667833328247e-01
    z[6,2,4]  R1325     5.2053558826446533e-01
    z[6,2,4]  R1326     5.4928040504455566e-01
    z[6,2,4]  R1327     1.5408772230148315e-01
    z[6,2,4]  R1328     2.7578663825988770e-01
    z[6,2,4]  R1329     3.2866501808166504e-01
    z[6,2,4]  R1330     -1.2901960313320160e-01
    z[6,2,4]  R1331     0.0457758866250515
    z[6,2,4]  R1332     -2.8694493696093559e-02
    z[6,2,4]  R1333     7.3351776599884033e-01
    z[6,2,4]  R1334     0.338083416223526
    z[6,2,4]  R1335     0.0929412767291069
    z[6,2,4]  R1336     6.1885702610015869e-01
    z[6,2,4]  R1337     -1.6371940076351166e-01
    z[6,2,4]  R1338     -0.0817561224102974
    z[6,2,4]  R1339     -0.0737539529800415
    z[6,2,4]  R1340     2.4493876099586487e-01
    z[6,2,4]  R1341     -6.9230049848556519e-02
    z[6,2,4]  R1342     1.8002241849899292e-01
    z[6,2,4]  R1343     2.5551870465278625e-01
    z[6,2,4]  R1344     6.9033432006835938e-01
    z[6,2,4]  R1345     2.9557922482490540e-01
    z[6,2,4]  R1346     1.9327664747834206e-02
    z[6,2,4]  R1347     7.8321486711502075e-01
    z[6,2,4]  R1348     5.0879049301147461e-01
    z[6,2,4]  R1349     2.1860572695732117e-01
    z[6,2,4]  R1350     -1.2899169325828552e-01
    z[6,2,4]  R1351     -7.8646056354045868e-02
    z[6,2,4]  R1352     -3.1243902444839478e-01
    z[6,2,4]  R1353     -3.5084882378578186e-01
    z[6,2,4]  R1354     4.9095014110207558e-03
    z[6,2,4]  R1355     -2.2748914361000061e-01
    z[6,2,4]  R1356     2.7913349866867065e-01
    z[6,2,4]  R1357     -1.1331176012754440e-01
    z[6,2,4]  R1358     -1.6841015219688416e-01
    z[6,2,4]  R1359     1.2260024249553680e-01
    z[6,2,4]  R1360     -2.2443506121635437e-01
    z[6,2,4]  R1361     1.1996795237064362e-01
    z[6,2,4]  R1362     1.7525520920753479e-01
    z[6,2,4]  R1363     1.0365176200866699e-01
    z[6,2,4]  R1364     9.6559226512908936e-02
    z[6,2,4]  R1365     0.200368732213974
    z[6,2,4]  R1366     3.1327697634696960e-01
    z[6,2,4]  R1367     8.6123727262020111e-02
    z[6,2,4]  R1368     -4.3691907078027725e-02
    z[6,2,4]  R1369     -1.7748209834098816e-01
    z[6,2,4]  R1370     -2.5371336936950684e-01
    z[6,2,4]  R1371     -4.9698883295059204e-01
    z[6,2,4]  R1372     -3.7619143724441528e-01
    z[6,2,4]  R1373     -0.0938776507973671
    z[6,2,4]  R1374     -1.9570156931877136e-01
    z[6,2,4]  R1375     -1.9608359038829803e-01
    z[6,2,4]  R1376     -7.5157403945922852e-02
    z[6,2,4]  R1377     -5.9292886406183243e-02
    z[6,2,4]  R1378     8.0217522382736206e-01
    z[6,2,4]  R1379     8.0292326211929321e-01
    z[6,2,4]  R1380     -1.2176158279180527e-01
    z[6,2,4]  R1381     3.5552206635475159e-01
    z[6,2,4]  R1382     1.0803960263729095e-01
    z[6,2,4]  R1383     5.2238047122955322e-01
    z[6,2,4]  R1384     3.6268595606088638e-02
    z[6,2,4]  R1385     2.2943180799484253e-01
    z[6,2,4]  R1386     1.8939814763143659e-03
    z[6,2,4]  R1387     -4.4640892744064331e-01
    z[6,2,4]  R1388     8.2703399658203125e-01
    z[6,2,4]  R1389     6.3625681400299072e-01
    z[6,2,4]  R1390     1.1765540577471256e-02
    z[6,2,4]  R1391     1.6907185316085815e-01
    z[6,2,4]  R1392     -6.3812166452407837e-02
    z[6,2,4]  R1393     2.1971662342548370e-01
    z[6,2,4]  R1394     6.1889201402664185e-01
    z[6,2,4]  R1395     8.9461815357208252e-01
    z[6,2,4]  R1396     -4.0109932422637939e-01
    z[6,2,4]  R1397     2.2225309908390045e-01
    z[6,2,4]  R1398     4.2056638002395630e-01
    z[6,2,4]  R1399     6.5803945064544678e-01
    z[6,2,4]  R1400     -5.1296311616897583e-01
    z[6,2,4]  R1401     -1.9633677601814270e-01
    z[6,2,4]  R1402     2.6759955286979675e-01
    z[6,2,4]  R1403     0.706939697265625
    z[6,2,4]  R1404     8.1082159280776978e-01
    z[6,2,4]  R1405     0.498468816280365
    z[6,2,4]  R1406     0.851675808429718
    z[6,2,4]  R1407     3.3378455042839050e-01
    z[6,2,4]  R1408     5.2420613355934620e-03
    z[6,2,4]  R1409     -4.4159126281738281e-01
    z[6,2,4]  R1410     -5.1426267623901367e-01
    z[6,2,4]  R1411     7.2900778055191040e-01
    z[6,2,4]  R1412     7.7739447355270386e-02
    z[6,2,4]  R1413     1.2438498437404633e-01
    z[6,2,4]  R1414     7.5727772712707520e-01
    z[6,2,4]  R1415     4.4296798110008240e-01
    z[6,2,4]  R1416     3.0513456463813782e-01
    z[6,2,4]  R1417     -2.3997746407985687e-01
    z[6,2,4]  R1418     7.3908336460590363e-02
    z[6,2,4]  R1419     1.9979287683963776e-01
    z[6,2,5]  R25       1
    z[6,2,5]  R61       -1
    z[6,2,5]  R1289     -1
    z[6,2,5]  R1290     1
    z[6,2,5]  R1293     -0.018271429464221
    z[6,2,5]  R1294     1.4349387586116791e-01
    z[6,2,5]  R1295     5.8392512798309326e-01
    z[6,2,5]  R1296     2.1635049581527710e-01
    z[6,2,5]  R1297     -1.1129476875066757e-01
    z[6,2,5]  R1298     5.4812282323837280e-01
    z[6,2,5]  R1299     1.7855556309223175e-01
    z[6,2,5]  R1300     3.8373034447431564e-02
    z[6,2,5]  R1301     3.3966964483261108e-01
    z[6,2,5]  R1302     -1.1695603281259537e-01
    z[6,2,5]  R1303     -4.6720793843269348e-01
    z[6,2,5]  R1304     -5.8165037631988525e-01
    z[6,2,5]  R1305     -1.4780853688716888e-01
    z[6,2,5]  R1306     -4.4981312751770020e-01
    z[6,2,5]  R1307     -5.9563565254211426e-01
    z[6,2,5]  R1308     -4.4312477111816406e-02
    z[6,2,5]  R1309     -3.2998120784759521e-01
    z[6,2,5]  R1310     -8.6903309822082520e-01
    z[6,2,5]  R1311     -3.4434261918067932e-01
    z[6,2,5]  R1312     -3.8126403093338013e-01
    z[6,2,5]  R1313     -2.0543164014816284e-01
    z[6,2,5]  R1314     -5.7612472772598267e-01
    z[6,2,5]  R1315     -1.0551296174526215e-01
    z[6,2,5]  R1316     -5.4740172624588013e-01
    z[6,2,5]  R1317     1.8206527456641197e-02
    z[6,2,5]  R1318     -2.8901594877243042e-01
    z[6,2,5]  R1319     -2.9624858498573303e-01
    z[6,2,5]  R1320     -1.8342342972755432e-01
    z[6,2,5]  R1321     3.7831076979637146e-01
    z[6,2,5]  R1322     1.7657433450222015e-01
    z[6,2,5]  R1323     -3.4343191981315613e-01
    z[6,2,5]  R1324     -2.7499023079872131e-01
    z[6,2,5]  R1325     -2.2095876932144165e-01
    z[6,2,5]  R1326     2.4364241957664490e-01
    z[6,2,5]  R1327     -5.7318305969238281e-01
    z[6,2,5]  R1328     -2.4612143635749817e-01
    z[6,2,5]  R1329     -2.8453272581100464e-01
    z[6,2,5]  R1330     0.06783477216959
    z[6,2,5]  R1331     1.8392252922058105e-01
    z[6,2,5]  R1332     -8.6709603667259216e-02
    z[6,2,5]  R1333     -1.7306198179721832e-01
    z[6,2,5]  R1334     1.6388094425201416e-01
    z[6,2,5]  R1335     2.9382398352026939e-02
    z[6,2,5]  R1336     2.2259229794144630e-02
    z[6,2,5]  R1337     -1.5884411334991455e-01
    z[6,2,5]  R1338     1.3070951402187347e-01
    z[6,2,5]  R1339     3.4013697504997253e-01
    z[6,2,5]  R1340     2.4353970587253571e-01
    z[6,2,5]  R1341     3.0460250377655029e-01
    z[6,2,5]  R1342     1.4695046842098236e-01
    z[6,2,5]  R1343     -2.7154510840773582e-02
    z[6,2,5]  R1344     -4.0896151214838028e-02
    z[6,2,5]  R1345     -5.0095748156309128e-02
    z[6,2,5]  R1346     4.9466714262962341e-01
    z[6,2,5]  R1347     -1.7966248095035553e-01
    z[6,2,5]  R1348     -2.6726812124252319e-01
    z[6,2,5]  R1349     -2.2878044843673706e-01
    z[6,2,5]  R1350     1.5868553519248962e-01
    z[6,2,5]  R1351     -1.3307699561119080e-01
    z[6,2,5]  R1352     4.5616918802261353e-01
    z[6,2,5]  R1353     2.0551607012748718e-01
    z[6,2,5]  R1354     -1.8133243918418884e-01
    z[6,2,5]  R1355     1.0346614569425583e-01
    z[6,2,5]  R1356     -1.3034285604953766e-01
    z[6,2,5]  R1357     2.8997424244880676e-01
    z[6,2,5]  R1358     -1.0508912801742554e-01
    z[6,2,5]  R1359     2.8377994894981384e-01
    z[6,2,5]  R1360     -3.8235333561897278e-01
    z[6,2,5]  R1361     -4.5161581039428711e-01
    z[6,2,5]  R1362     -2.6684507727622986e-01
    z[6,2,5]  R1363     -2.4281406402587891e-01
    z[6,2,5]  R1364     -5.1673788577318192e-02
    z[6,2,5]  R1365     2.9943871498107910e-01
    z[6,2,5]  R1366     2.3046833276748657e-01
    z[6,2,5]  R1367     -2.0786814391613007e-01
    z[6,2,5]  R1368     5.2016609907150269e-01
    z[6,2,5]  R1369     -3.8530153036117554e-01
    z[6,2,5]  R1370     -2.1397693455219269e-01
    z[6,2,5]  R1371     -5.0712251663208008e-01
    z[6,2,5]  R1372     -4.4329392910003662e-01
    z[6,2,5]  R1373     -0.636333703994751
    z[6,2,5]  R1374     -2.1468611061573029e-01
    z[6,2,5]  R1375     -5.3010553121566772e-01
    z[6,2,5]  R1376     -4.5094919204711914e-01
    z[6,2,5]  R1377     2.3007138073444366e-01
    z[6,2,5]  R1378     -6.2233596108853817e-03
    z[6,2,5]  R1379     2.4792146682739258e-01
    z[6,2,5]  R1380     -1.4309531450271606e-01
    z[6,2,5]  R1381     -3.3593752980232239e-01
    z[6,2,5]  R1382     -3.9521834254264832e-01
    z[6,2,5]  R1383     3.8066470623016357e-01
    z[6,2,5]  R1384     -3.7482002377510071e-01
    z[6,2,5]  R1385     -2.3112215101718903e-01
    z[6,2,5]  R1386     -1.9764302670955658e-01
    z[6,2,5]  R1387     3.4995386004447937e-01
    z[6,2,5]  R1388     0.262921005487442
    z[6,2,5]  R1389     7.3634006083011627e-02
    z[6,2,5]  R1390     -6.6669160127639771e-01
    z[6,2,5]  R1391     -4.7642791271209717e-01
    z[6,2,5]  R1392     -6.8624633550643921e-01
    z[6,2,5]  R1393     5.4921054840087891e-01
    z[6,2,5]  R1394     1.7313297092914581e-01
    z[6,2,5]  R1395     1.3795202970504761e-01
    z[6,2,5]  R1396     -0.472665399312973
    z[6,2,5]  R1397     -3.0621027946472168e-01
    z[6,2,5]  R1398     4.4452944397926331e-01
    z[6,2,5]  R1399     4.3774670362472534e-01
    z[6,2,5]  R1400     -1.1383699625730515e-01
    z[6,2,5]  R1401     -5.2780801057815552e-01
    z[6,2,5]  R1402     5.5221915245056152e-01
    z[6,2,5]  R1403     2.0059312880039215e-01
    z[6,2,5]  R1404     -1.3569347560405731e-01
    z[6,2,5]  R1405     4.4040087610483170e-02
    z[6,2,5]  R1406     8.8828159496188164e-03
    z[6,2,5]  R1407     -3.1864476203918457e-01
    z[6,2,5]  R1408     -4.9679529666900635e-01
    z[6,2,5]  R1409     1.2843219563364983e-02
    z[6,2,5]  R1410     -1.8174874782562256e-01
    z[6,2,5]  R1411     -1.4751896262168884e-01
    z[6,2,5]  R1412     -3.6593183875083923e-02
    z[6,2,5]  R1413     -8.8280633091926575e-02
    z[6,2,5]  R1414     1.9343499839305878e-01
    z[6,2,5]  R1415     -3.6710628867149353e-01
    z[6,2,5]  R1416     0.607828676700592
    z[6,2,5]  R1417     5.4488813877105713e-01
    z[6,2,5]  R1418     0.67137610912323
    z[6,2,5]  R1419     4.1305643320083618e-01
    z[6,2,6]  R26       1
    z[6,2,6]  R62       -1
    z[6,2,6]  R1291     -1
    z[6,2,6]  R1292     1
    z[6,2,6]  R1293     3.7954360246658325e-01
    z[6,2,6]  R1294     7.6548673212528229e-02
    z[6,2,6]  R1295     -1.2867036461830139e-01
    z[6,2,6]  R1296     -5.1571053266525269e-01
    z[6,2,6]  R1297     4.7039404511451721e-01
    z[6,2,6]  R1298     3.7784385681152344e-01
    z[6,2,6]  R1299     -3.6855155229568481e-01
    z[6,2,6]  R1300     -1.6202476620674133e-01
    z[6,2,6]  R1301     -3.6887574940919876e-02
    z[6,2,6]  R1302     -6.1799097061157227e-01
    z[6,2,6]  R1303     -6.7602782510221004e-03
    z[6,2,6]  R1304     -1.1672931723296642e-02
    z[6,2,6]  R1305     1.8062233924865723e-01
    z[6,2,6]  R1306     0.368488609790802
    z[6,2,6]  R1307     3.7670186161994934e-01
    z[6,2,6]  R1308     2.9757311940193176e-01
    z[6,2,6]  R1309     2.2021479904651642e-01
    z[6,2,6]  R1310     -2.0640711486339569e-01
    z[6,2,6]  R1311     -1.9189366698265076e-01
    z[6,2,6]  R1312     -1.3751919567584991e-01
    z[6,2,6]  R1313     -0.345706045627594
    z[6,2,6]  R1314     2.2112955152988434e-01
    z[6,2,6]  R1315     3.3739423751831055e-01
    z[6,2,6]  R1316     2.9497742652893066e-01
    z[6,2,6]  R1317     -2.0037274062633514e-01
    z[6,2,6]  R1318     2.0725630223751068e-01
    z[6,2,6]  R1319     -2.3145695030689240e-01
    z[6,2,6]  R1320     -5.2521222829818726e-01
    z[6,2,6]  R1321     -1.3092701137065887e-01
    z[6,2,6]  R1322     -1.5891024842858315e-02
    z[6,2,6]  R1323     -9.6572116017341614e-02
    z[6,2,6]  R1324     2.2791130840778351e-01
    z[6,2,6]  R1325     1.6141925752162933e-01
    z[6,2,6]  R1326     3.1756326556205750e-01
    z[6,2,6]  R1327     -4.5917022228240967e-01
    z[6,2,6]  R1328     -3.1051045656204224e-01
    z[6,2,6]  R1329     -1.4357627928256989e-01
    z[6,2,6]  R1330     2.4317464232444763e-01
    z[6,2,6]  R1331     -2.9501739144325256e-01
    z[6,2,6]  R1332     2.4745029211044312e-01
    z[6,2,6]  R1333     8.3945758640766144e-02
    z[6,2,6]  R1334     0.151498481631279
    z[6,2,6]  R1335     4.9973125569522381e-03
    z[6,2,6]  R1336     -3.1996732950210571e-01
    z[6,2,6]  R1337     1.3361082971096039e-01
    z[6,2,6]  R1338     -1.6888926923274994e-01
    z[6,2,6]  R1339     1.0487063229084015e-01
    z[6,2,6]  R1340     -1.3252280652523041e-01
    z[6,2,6]  R1341     -2.5968968868255615e-02
    z[6,2,6]  R1342     1.6199924051761627e-01
    z[6,2,6]  R1343     -1.4860944449901581e-01
    z[6,2,6]  R1344     -2.9217207431793213e-01
    z[6,2,6]  R1345     -1.1926929652690887e-01
    z[6,2,6]  R1346     -4.1505265235900879e-01
    z[6,2,6]  R1347     -0.0943610891699791
    z[6,2,6]  R1348     -6.3995391130447388e-01
    z[6,2,6]  R1349     -1.2046817690134048e-01
    z[6,2,6]  R1350     -5.0029113888740540e-02
    z[6,2,6]  R1351     -2.3115381598472595e-01
    z[6,2,6]  R1352     -8.9278884232044220e-02
    z[6,2,6]  R1353     -1.0339193791151047e-01
    z[6,2,6]  R1354     2.1415881812572479e-01
    z[6,2,6]  R1355     -4.6624112129211426e-01
    z[6,2,6]  R1356     -3.0351492762565613e-01
    z[6,2,6]  R1357     -3.8648679852485657e-01
    z[6,2,6]  R1358     -1.0934099555015564e-01
    z[6,2,6]  R1359     -2.6732918620109558e-01
    z[6,2,6]  R1360     5.1108545064926147e-01
    z[6,2,6]  R1361     -7.2644329071044922e-01
    z[6,2,6]  R1362     -2.0665641129016876e-01
    z[6,2,6]  R1363     -5.1648229360580444e-01
    z[6,2,6]  R1364     -2.5272938609123230e-01
    z[6,2,6]  R1365     1.3192677497863770e-01
    z[6,2,6]  R1366     -9.0538740158081055e-02
    z[6,2,6]  R1367     4.9501422047615051e-01
    z[6,2,6]  R1368     6.2232349067926407e-02
    z[6,2,6]  R1369     -2.6739564538002014e-01
    z[6,2,6]  R1370     -2.0970292389392853e-01
    z[6,2,6]  R1371     1.6176858544349670e-01
    z[6,2,6]  R1372     -2.4438551068305969e-01
    z[6,2,6]  R1373     -1.0012000799179077e-01
    z[6,2,6]  R1374     -3.2189422845840454e-01
    z[6,2,6]  R1375     2.2226870059967041e-01
    z[6,2,6]  R1376     -0.262014240026474
    z[6,2,6]  R1377     -1.6785086691379547e-01
    z[6,2,6]  R1378     3.9106106758117676e-01
    z[6,2,6]  R1379     3.4687098860740662e-01
    z[6,2,6]  R1380     5.4809689521789551e-02
    z[6,2,6]  R1381     -6.6034264862537384e-02
    z[6,2,6]  R1382     1.3592340052127838e-01
    z[6,2,6]  R1383     1.0662989318370819e-01
    z[6,2,6]  R1384     4.2565248906612396e-02
    z[6,2,6]  R1385     -5.8749181032180786e-01
    z[6,2,6]  R1386     3.6409419775009155e-01
    z[6,2,6]  R1387     3.9275979995727539e-01
    z[6,2,6]  R1388     -7.0015847682952881e-02
    z[6,2,6]  R1389     7.8138843178749084e-02
    z[6,2,6]  R1390     1.0038229823112488e-01
    z[6,2,6]  R1391     5.6645695120096207e-02
    z[6,2,6]  R1392     1.4229616522789001e-01
    z[6,2,6]  R1393     1.3901987671852112e-01
    z[6,2,6]  R1394     0.23238605260849
    z[6,2,6]  R1395     2.2056837379932404e-01
    z[6,2,6]  R1396     3.3691248297691345e-01
    z[6,2,6]  R1397     1.2322041392326355e-01
    z[6,2,6]  R1398     1.0096822865307331e-02
    z[6,2,6]  R1399     6.1866792384535074e-04
    z[6,2,6]  R1400     0.0417693592607975
    z[6,2,6]  R1401     5.0848484039306641e-01
    z[6,2,6]  R1402     2.5371477007865906e-01
    z[6,2,6]  R1403     -7.3690533638000488e-02
    z[6,2,6]  R1404     2.1654383838176727e-01
    z[6,2,6]  R1405     1.7860314249992371e-01
    z[6,2,6]  R1406     -5.0366683863103390e-03
    z[6,2,6]  R1407     -2.3265336453914642e-01
    z[6,2,6]  R1408     -6.2715482711791992e-01
    z[6,2,6]  R1409     0.556354284286499
    z[6,2,6]  R1410     2.7617228031158447e-01
    z[6,2,6]  R1411     6.0965497046709061e-02
    z[6,2,6]  R1412     3.6251747608184814e-01
    z[6,2,6]  R1413     2.1518450975418091e-01
    z[6,2,6]  R1414     -3.1988853216171265e-01
    z[6,2,6]  R1415     -1.4080493152141571e-01
    z[6,2,6]  R1416     4.4668808579444885e-01
    z[6,2,6]  R1417     2.3696416616439819e-01
    z[6,2,6]  R1418     -1.7106316983699799e-01
    z[6,2,6]  R1419     2.4901130795478821e-01
    z[2,7,0]  R20       -1
    z[2,7,0]  R65       1
    z[2,7,0]  R1420     -1
    z[2,7,0]  R1421     1
    z[2,7,0]  R1434     -4.9124273657798767e-01
    z[2,7,0]  R1435     -7.7634233236312866e-01
    z[2,7,0]  R1436     -4.5373073220252991e-01
    z[2,7,0]  R1437     -6.8108010292053223e-01
    z[2,7,0]  R1438     -7.1953850984573364e-01
    z[2,7,0]  R1439     -4.6407660841941833e-01
    z[2,7,0]  R1440     -3.3312138915061951e-01
    z[2,7,0]  R1441     -7.2410744428634644e-01
    z[2,7,0]  R1442     -6.1397582292556763e-01
    z[2,7,0]  R1443     -1.4422667026519775e-01
    z[2,7,0]  R1444     6.1473723500967026e-02
    z[2,7,0]  R1445     0.153394877910614
    z[2,7,0]  R1446     -2.0218744874000549e-01
    z[2,7,0]  R1447     -1.8500488996505737e-01
    z[2,7,0]  R1448     1.5352945029735565e-01
    z[2,7,0]  R1449     9.4493657350540161e-02
    z[2,7,0]  R1450     -0.059889055788517
    z[2,7,0]  R1451     2.3794810473918915e-01
    z[2,7,0]  R1452     -2.4597447365522385e-02
    z[2,7,0]  R1453     4.5672440528869629e-01
    z[2,7,0]  R1454     4.7142812609672546e-01
    z[2,7,0]  R1455     2.4861901998519897e-02
    z[2,7,0]  R1456     -1.4215698838233948e-01
    z[2,7,0]  R1457     5.0571531057357788e-01
    z[2,7,0]  R1458     1.2481260299682617e-01
    z[2,7,0]  R1459     -4.0614360570907593e-01
    z[2,7,0]  R1460     -1.9890600442886353e-01
    z[2,7,0]  R1461     1.8972903490066528e-02
    z[2,7,0]  R1462     -6.2058974057435989e-02
    z[2,7,0]  R1463     -1.0376165807247162e-01
    z[2,7,0]  R1464     -1.7810884118080139e-01
    z[2,7,0]  R1465     9.4430714845657349e-02
    z[2,7,0]  R1466     1.2676912546157837e-01
    z[2,7,0]  R1467     -1.5843637287616730e-01
    z[2,7,0]  R1468     4.0129086375236511e-01
    z[2,7,0]  R1469     2.0959985256195068e-01
    z[2,7,0]  R1470     4.2695617675781250e-01
    z[2,7,0]  R1471     -8.0943085253238678e-02
    z[2,7,0]  R1472     -3.6984920501708984e-01
    z[2,7,0]  R1473     -6.6380125284194946e-01
    z[2,7,0]  R1474     -4.9481880851089954e-03
    z[2,7,0]  R1475     -6.7595876753330231e-03
    z[2,7,0]  R1476     2.1995209157466888e-01
    z[2,7,0]  R1477     -5.0826031714677811e-02
    z[2,7,0]  R1478     4.4874809682369232e-02
    z[2,7,0]  R1479     -3.3454048633575439e-01
    z[2,7,0]  R1480     2.5708615779876709e-01
    z[2,7,0]  R1481     6.0063779354095459e-01
    z[2,7,0]  R1482     -6.4115297794342041e-01
    z[2,7,0]  R1483     -3.8052040338516235e-01
    z[2,7,0]  R1484     2.9909870028495789e-01
    z[2,7,0]  R1485     -1.2768530286848545e-02
    z[2,7,0]  R1486     -2.4318021535873413e-01
    z[2,7,0]  R1487     6.0623455792665482e-02
    z[2,7,0]  R1488     -4.2846912145614624e-01
    z[2,7,0]  R1489     -2.1448197960853577e-01
    z[2,7,0]  R1490     -3.8751190900802612e-01
    z[2,7,0]  R1491     5.0506293773651123e-01
    z[2,7,0]  R1492     2.9371036216616631e-02
    z[2,7,0]  R1493     -1.8463903665542603e-01
    z[2,7,0]  R1494     -1.7569494247436523e-01
    z[2,7,0]  R1495     -3.0998736619949341e-01
    z[2,7,0]  R1496     -0.0892467051744461
    z[2,7,0]  R1497     3.0539789795875549e-01
    z[2,7,0]  R1498     -3.7317898869514465e-01
    z[2,7,0]  R1499     4.7704753279685974e-01
    z[2,7,0]  R1500     3.6393198370933533e-01
    z[2,7,0]  R1501     6.0187149047851562e-01
    z[2,7,0]  R1502     0.573669970035553
    z[2,7,0]  R1503     6.0565555095672607e-01
    z[2,7,0]  R1504     -2.1621994674205780e-01
    z[2,7,0]  R1505     -4.5511227846145630e-01
    z[2,7,0]  R1506     1.1857293546199799e-01
    z[2,7,0]  R1507     -2.6836407184600830e-01
    z[2,7,0]  R1508     -6.1877554655075073e-01
    z[2,7,0]  R1509     -5.6078499555587769e-01
    z[2,7,0]  R1510     -4.8424881696701050e-01
    z[2,7,0]  R1511     -0.493665486574173
    z[2,7,0]  R1512     -6.5295916795730591e-01
    z[2,7,0]  R1513     -5.0218790769577026e-01
    z[2,7,0]  R1514     4.4836950302124023e-01
    z[2,7,0]  R1515     3.7923336029052734e-01
    z[2,7,0]  R1516     3.2009416818618774e-01
    z[2,7,0]  R1517     4.2270222306251526e-01
    z[2,7,0]  R1518     3.3594289422035217e-01
    z[2,7,0]  R1519     0.368246465921402
    z[2,7,0]  R1520     4.5081678032875061e-01
    z[2,7,0]  R1521     4.2248663306236267e-01
    z[2,7,0]  R1522     3.4102728962898254e-01
    z[2,7,0]  R1523     2.0220804214477539e-01
    z[2,7,0]  R1524     -2.8328239917755127e-01
    z[2,7,0]  R1525     -1.7455467581748962e-01
    z[2,7,0]  R1526     -1.4616841077804565e-01
    z[2,7,0]  R1527     2.8160439804196358e-02
    z[2,7,0]  R1528     1.1431477218866348e-01
    z[2,7,0]  R1529     1.0720545798540115e-01
    z[2,7,0]  R1530     2.2843575105071068e-02
    z[2,7,0]  R1531     -2.9791104793548584e-01
    z[2,7,0]  R1532     -2.2452485561370850e-01
    z[2,7,0]  R1533     5.9810775518417358e-01
    z[2,7,0]  R1534     8.8973073288798332e-03
    z[2,7,0]  R1535     -9.1658718883991241e-02
    z[2,7,0]  R1536     1.0764811933040619e-01
    z[2,7,0]  R1537     -2.6607245206832886e-01
    z[2,7,0]  R1538     -4.6468096971511841e-01
    z[2,7,0]  R1539     9.6932905912399292e-01
    z[2,7,0]  R1540     9.6469402313232422e-01
    z[2,7,0]  R1541     9.1660410165786743e-01
    z[2,7,0]  R1542     0.891918957233429
    z[2,7,0]  R1543     8.0443078279495239e-01
    z[2,7,1]  R21       -1
    z[2,7,1]  R66       1
    z[2,7,1]  R1422     -1
    z[2,7,1]  R1423     1
    z[2,7,1]  R1434     -4.4544604420661926e-01
    z[2,7,1]  R1435     -4.0777593851089478e-01
    z[2,7,1]  R1436     -4.2607891559600830e-01
    z[2,7,1]  R1437     -2.7949529886245728e-01
    z[2,7,1]  R1438     -0.350705623626709
    z[2,7,1]  R1439     -0.363901287317276
    z[2,7,1]  R1440     -4.9221006035804749e-01
    z[2,7,1]  R1441     -3.8024628162384033e-01
    z[2,7,1]  R1442     0.237028107047081
    z[2,7,1]  R1443     -8.7349957227706909e-01
    z[2,7,1]  R1444     -2.5577083230018616e-01
    z[2,7,1]  R1445     2.4164129793643951e-01
    z[2,7,1]  R1446     0.829850971698761
    z[2,7,1]  R1447     6.4701384305953979e-01
    z[2,7,1]  R1448     9.1239744424819946e-01
    z[2,7,1]  R1449     8.7869280576705933e-01
    z[2,7,1]  R1450     8.8222002983093262e-01
    z[2,7,1]  R1451     3.3945631980895996e-01
    z[2,7,1]  R1452     7.9038488864898682e-01
    z[2,7,1]  R1453     4.7249439358711243e-01
    z[2,7,1]  R1454     -2.5328485295176506e-02
    z[2,7,1]  R1455     -4.2231306433677673e-01
    z[2,7,1]  R1456     1.6041561961174011e-01
    z[2,7,1]  R1457     9.7372457385063171e-02
    z[2,7,1]  R1458     3.9665067195892334e-01
    z[2,7,1]  R1459     5.0427418947219849e-01
    z[2,7,1]  R1460     -2.2575311362743378e-01
    z[2,7,1]  R1461     2.1479836106300354e-01
    z[2,7,1]  R1462     2.1152751147747040e-01
    z[2,7,1]  R1463     2.3155732452869415e-01
    z[2,7,1]  R1464     -2.0896512269973755e-01
    z[2,7,1]  R1465     -8.6768402252346277e-04
    z[2,7,1]  R1466     4.8274621367454529e-01
    z[2,7,1]  R1467     3.2020667195320129e-01
    z[2,7,1]  R1468     1.8010555207729340e-01
    z[2,7,1]  R1469     -4.0624219179153442e-01
    z[2,7,1]  R1470     -4.6342805027961731e-02
    z[2,7,1]  R1471     2.6514491438865662e-01
    z[2,7,1]  R1472     2.3521491885185242e-01
    z[2,7,1]  R1473     2.4544388055801392e-01
    z[2,7,1]  R1474     -8.3455711603164673e-02
    z[2,7,1]  R1475     1.5370737016201019e-01
    z[2,7,1]  R1476     2.3272086679935455e-01
    z[2,7,1]  R1477     3.5309621691703796e-01
    z[2,7,1]  R1478     1.4941997826099396e-01
    z[2,7,1]  R1479     -3.7667483091354370e-02
    z[2,7,1]  R1480     4.8218145966529846e-01
    z[2,7,1]  R1481     -1.7782464623451233e-01
    z[2,7,1]  R1482     3.9055651426315308e-01
    z[2,7,1]  R1483     4.6254959702491760e-01
    z[2,7,1]  R1484     2.5293555110692978e-02
    z[2,7,1]  R1485     1.9626750051975250e-01
    z[2,7,1]  R1486     9.6097335219383240e-02
    z[2,7,1]  R1487     1.5056197345256805e-01
    z[2,7,1]  R1488     1.8992094695568085e-01
    z[2,7,1]  R1489     3.4925243258476257e-01
    z[2,7,1]  R1490     -9.8732315003871918e-02
    z[2,7,1]  R1491     -1.1955556273460388e-01
    z[2,7,1]  R1492     -4.8471504449844360e-01
    z[2,7,1]  R1493     3.3883380889892578e-01
    z[2,7,1]  R1494     -4.6554881334304810e-01
    z[2,7,1]  R1495     8.7587319314479828e-02
    z[2,7,1]  R1496     3.0281466245651245e-01
    z[2,7,1]  R1497     0.00760143157094717
    z[2,7,1]  R1498     2.8109899163246155e-01
    z[2,7,1]  R1499     4.2320245504379272e-01
    z[2,7,1]  R1500     -2.1706353127956390e-01
    z[2,7,1]  R1501     -3.9704304933547974e-01
    z[2,7,1]  R1502     -1.0005540400743484e-01
    z[2,7,1]  R1503     -0.344194233417511
    z[2,7,1]  R1504     -7.6087635755538940e-01
    z[2,7,1]  R1505     -3.7918284535408020e-01
    z[2,7,1]  R1506     -5.8403360843658447e-01
    z[2,7,1]  R1507     -0.577204704284668
    z[2,7,1]  R1508     -5.0304710865020752e-01
    z[2,7,1]  R1509     -5.1557654142379761e-01
    z[2,7,1]  R1510     -3.6960625648498535e-01
    z[2,7,1]  R1511     -6.7872440814971924e-01
    z[2,7,1]  R1512     7.0590823888778687e-01
    z[2,7,1]  R1513     6.5275180339813232e-01
    z[2,7,1]  R1514     7.7657061815261841e-01
    z[2,7,1]  R1515     6.8200689554214478e-01
    z[2,7,1]  R1516     6.6349774599075317e-01
    z[2,7,1]  R1517     6.1811476945877075e-01
    z[2,7,1]  R1518     6.1596262454986572e-01
    z[2,7,1]  R1519     5.7915139198303223e-01
    z[2,7,1]  R1520     7.0773756504058838e-01
    z[2,7,1]  R1521     5.3430587053298950e-01
    z[2,7,1]  R1522     3.9622643589973450e-01
    z[2,7,1]  R1523     4.3754762411117554e-01
    z[2,7,1]  R1524     4.8011958599090576e-01
    z[2,7,1]  R1525     3.8664203882217407e-01
    z[2,7,1]  R1526     -2.5440484285354614e-01
    z[2,7,1]  R1527     -3.0046477913856506e-01
    z[2,7,1]  R1528     -6.3220870494842529e-01
    z[2,7,1]  R1529     -5.6545984745025635e-01
    z[2,7,1]  R1530     4.8776644468307495e-01
    z[2,7,1]  R1531     4.6707892417907715e-01
    z[2,7,1]  R1532     5.2490210533142090e-01
    z[2,7,1]  R1533     -2.4439743161201477e-01
    z[2,7,1]  R1534     0.74985671043396
    z[2,7,1]  R1535     7.4483048915863037e-01
    z[2,7,1]  R1536     6.0011005401611328e-01
    z[2,7,1]  R1537     -1.0027145594358444e-01
    z[2,7,1]  R1538     -3.2934451103210449e-01
    z[2,7,1]  R1539     -1.1398215591907501e-01
    z[2,7,1]  R1540     -1.0426852852106094e-01
    z[2,7,1]  R1541     -0.144050732254982
    z[2,7,1]  R1542     -0.0899525135755539
    z[2,7,1]  R1543     7.9007655382156372e-02
    z[2,7,2]  R22       -1
    z[2,7,2]  R67       1
    z[2,7,2]  R1424     -1
    z[2,7,2]  R1425     1
    z[2,7,2]  R1434     -5.0723069906234741e-01
    z[2,7,2]  R1435     -3.0221751332283020e-01
    z[2,7,2]  R1436     -5.4670047760009766e-01
    z[2,7,2]  R1437     -5.1954925060272217e-01
    z[2,7,2]  R1438     -3.8589019328355789e-02
    z[2,7,2]  R1439     -6.0903567075729370e-01
    z[2,7,2]  R1440     -4.8527535051107407e-02
    z[2,7,2]  R1441     -2.2927054762840271e-01
    z[2,7,2]  R1442     -6.1901479959487915e-01
    z[2,7,2]  R1443     3.8353729993104935e-02
    z[2,7,2]  R1444     4.4338819384574890e-01
    z[2,7,2]  R1445     -3.2167810946702957e-02
    z[2,7,2]  R1446     3.1972485780715942e-01
    z[2,7,2]  R1447     5.0286766141653061e-02
    z[2,7,2]  R1448     1.2339603155851364e-01
    z[2,7,2]  R1449     2.6287573575973511e-01
    z[2,7,2]  R1450     2.2269165515899658e-01
    z[2,7,2]  R1451     6.6414773464202881e-01
    z[2,7,2]  R1452     7.4134194292128086e-03
    z[2,7,2]  R1453     -2.6723316311836243e-01
    z[2,7,2]  R1454     -0.0663272812962532
    z[2,7,2]  R1455     -3.2018488645553589e-01
    z[2,7,2]  R1456     -3.5017940402030945e-01
    z[2,7,2]  R1457     1.4386005699634552e-01
    z[2,7,2]  R1458     -8.9014537632465363e-02
    z[2,7,2]  R1459     1.2869903445243835e-01
    z[2,7,2]  R1460     3.2295051217079163e-01
    z[2,7,2]  R1461     3.2745265960693359e-01
    z[2,7,2]  R1462     -2.7053061127662659e-01
    z[2,7,2]  R1463     -3.1839540600776672e-01
    z[2,7,2]  R1464     4.8677217960357666e-01
    z[2,7,2]  R1465     8.2149881124496460e-01
    z[2,7,2]  R1466     5.7530528306961060e-01
    z[2,7,2]  R1467     1.1776317656040192e-01
    z[2,7,2]  R1468     -4.4055002927780151e-01
    z[2,7,2]  R1469     3.9006423950195312e-01
    z[2,7,2]  R1470     -2.8825944662094116e-01
    z[2,7,2]  R1471     -1.3484659790992737e-01
    z[2,7,2]  R1472     2.1095946431159973e-01
    z[2,7,2]  R1473     -1.1477702856063843e-01
    z[2,7,2]  R1474     5.4724162817001343e-01
    z[2,7,2]  R1475     -2.2157758474349976e-01
    z[2,7,2]  R1476     3.6912760138511658e-01
    z[2,7,2]  R1477     -1.3935816287994385e-01
    z[2,7,2]  R1478     -1.5904602408409119e-01
    z[2,7,2]  R1479     -1.1023134738206863e-01
    z[2,7,2]  R1480     -3.6716946959495544e-01
    z[2,7,2]  R1481     6.4137715101242065e-01
    z[2,7,2]  R1482     4.7803804278373718e-02
    z[2,7,2]  R1483     -1.0268244892358780e-01
    z[2,7,2]  R1484     -4.5061972737312317e-01
    z[2,7,2]  R1485     3.8992297649383545e-01
    z[2,7,2]  R1486     1.1180755496025085e-01
    z[2,7,2]  R1487     -4.3792682886123657e-01
    z[2,7,2]  R1488     -2.3457825183868408e-01
    z[2,7,2]  R1489     5.8858606964349747e-02
    z[2,7,2]  R1490     -3.3551222085952759e-01
    z[2,7,2]  R1491     0.629315972328186
    z[2,7,2]  R1492     -3.7618912756443024e-02
    z[2,7,2]  R1493     -1.8613802269101143e-02
    z[2,7,2]  R1494     -1.5646006166934967e-01
    z[2,7,2]  R1495     -3.8047635555267334e-01
    z[2,7,2]  R1496     -2.5038030743598938e-01
    z[2,7,2]  R1497     -2.7576902508735657e-01
    z[2,7,2]  R1498     -1.3379658758640289e-01
    z[2,7,2]  R1499     4.4476044178009033e-01
    z[2,7,2]  R1500     -3.8278463482856750e-01
    z[2,7,2]  R1501     -1.5245710313320160e-01
    z[2,7,2]  R1502     -3.1500127911567688e-01
    z[2,7,2]  R1503     -4.9095860123634338e-01
    z[2,7,2]  R1504     -4.9087649583816528e-01
    z[2,7,2]  R1505     -4.5914888381958008e-01
    z[2,7,2]  R1506     -5.7204127311706543e-01
    z[2,7,2]  R1507     -5.5474025011062622e-01
    z[2,7,2]  R1508     -2.0608049631118774e-01
    z[2,7,2]  R1509     -3.8284295797348022e-01
    z[2,7,2]  R1510     -3.7049689888954163e-01
    z[2,7,2]  R1511     1.8101982772350311e-01
    z[2,7,2]  R1512     0.0501449890434742
    z[2,7,2]  R1513     -2.6582766324281693e-02
    z[2,7,2]  R1514     1.1455873399972916e-01
    z[2,7,2]  R1515     -1.9130834937095642e-01
    z[2,7,2]  R1516     3.4527698159217834e-01
    z[2,7,2]  R1517     2.9010051488876343e-01
    z[2,7,2]  R1518     -1.4007273316383362e-01
    z[2,7,2]  R1519     5.3694641590118408e-01
    z[2,7,2]  R1520     0.0927298292517662
    z[2,7,2]  R1521     -6.8193182349205017e-02
    z[2,7,2]  R1522     0.50670325756073
    z[2,7,2]  R1523     3.2412725687026978e-01
    z[2,7,2]  R1524     1.1077066510915756e-01
    z[2,7,2]  R1525     -2.5768473744392395e-01
    z[2,7,2]  R1526     1.4226564764976501e-01
    z[2,7,2]  R1527     -8.1668600440025330e-02
    z[2,7,2]  R1528     7.0994421839714050e-02
    z[2,7,2]  R1529     9.5608517527580261e-02
    z[2,7,2]  R1530     -4.6972211450338364e-02
    z[2,7,2]  R1531     5.4767513275146484e-01
    z[2,7,2]  R1532     1.6562581062316895e-01
    z[2,7,2]  R1533     2.7310448884963989e-01
    z[2,7,2]  R1534     1.8667300045490265e-01
    z[2,7,2]  R1535     9.7441887483000755e-03
    z[2,7,2]  R1536     2.2966033220291138e-01
    z[2,7,2]  R1537     7.1472458541393280e-02
    z[2,7,2]  R1538     4.2513498663902283e-01
    z[2,7,2]  R1539     -0.0327107198536396
    z[2,7,2]  R1540     2.1202708780765533e-01
    z[2,7,2]  R1541     1.3398066163063049e-01
    z[2,7,2]  R1542     8.6986780166625977e-02
    z[2,7,2]  R1543     9.7790569067001343e-02
    z[2,7,3]  R23       -1
    z[2,7,3]  R68       1
    z[2,7,3]  R1426     -1
    z[2,7,3]  R1427     1
    z[2,7,3]  R1434     5.0857901573181152e-01
    z[2,7,3]  R1435     2.4969819188117981e-01
    z[2,7,3]  R1436     4.9621476791799068e-03
    z[2,7,3]  R1437     -1.0981449484825134e-01
    z[2,7,3]  R1438     5.2821516990661621e-01
    z[2,7,3]  R1439     -3.8038119673728943e-02
    z[2,7,3]  R1440     6.7629760503768921e-01
    z[2,7,3]  R1441     -1.7949819564819336e-01
    z[2,7,3]  R1442     3.6374571919441223e-01
    z[2,7,3]  R1443     2.1840167045593262e-01
    z[2,7,3]  R1444     -0.52577143907547
    z[2,7,3]  R1445     -4.1349199414253235e-01
    z[2,7,3]  R1446     -1.5367542207241058e-01
    z[2,7,3]  R1447     -4.5624691247940063e-01
    z[2,7,3]  R1448     -2.2992837429046631e-01
    z[2,7,3]  R1449     -5.1483251154422760e-02
    z[2,7,3]  R1450     9.5154352486133575e-02
    z[2,7,3]  R1451     -3.0231153964996338e-01
    z[2,7,3]  R1452     -3.1349179148674011e-01
    z[2,7,3]  R1453     -4.9525824189186096e-01
    z[2,7,3]  R1454     -7.8650033473968506e-01
    z[2,7,3]  R1455     -4.3379139900207520e-01
    z[2,7,3]  R1456     -6.5854293107986450e-01
    z[2,7,3]  R1457     -5.3881102800369263e-01
    z[2,7,3]  R1458     -7.9445666074752808e-01
    z[2,7,3]  R1459     -4.4195863604545593e-01
    z[2,7,3]  R1460     -7.2630548477172852e-01
    z[2,7,3]  R1461     -8.7272793054580688e-01
    z[2,7,3]  R1462     2.8594639897346497e-01
    z[2,7,3]  R1463     0.0881413072347641
    z[2,7,3]  R1464     -8.0582714080810547e-01
    z[2,7,3]  R1465     -2.6946470141410828e-01
    z[2,7,3]  R1466     -4.8328486084938049e-01
    z[2,7,3]  R1467     6.5524083375930786e-01
    z[2,7,3]  R1468     6.8470877408981323e-01
    z[2,7,3]  R1469     -4.3322277069091797e-01
    z[2,7,3]  R1470     7.4889016151428223e-01
    z[2,7,3]  R1471     -6.5494573116302490e-01
    z[2,7,3]  R1472     7.3258213698863983e-02
    z[2,7,3]  R1473     -2.6382020115852356e-01
    z[2,7,3]  R1474     -4.8871728777885437e-01
    z[2,7,3]  R1475     8.1759041547775269e-01
    z[2,7,3]  R1476     -0.515705943107605
    z[2,7,3]  R1477     0.695762038230896
    z[2,7,3]  R1478     6.9523996114730835e-01
    z[2,7,3]  R1479     8.0560527741909027e-02
    z[2,7,3]  R1480     -2.6228037476539612e-01
    z[2,7,3]  R1481     -1.9468809664249420e-01
    z[2,7,3]  R1482     2.4396492540836334e-01
    z[2,7,3]  R1483     0.0779092013835907
    z[2,7,3]  R1484     -6.5498644113540649e-01
    z[2,7,3]  R1485     -4.8331132531166077e-01
    z[2,7,3]  R1486     6.9152086973190308e-01
    z[2,7,3]  R1487     4.8625549674034119e-01
    z[2,7,3]  R1488     5.0809867680072784e-02
    z[2,7,3]  R1489     7.3908466100692749e-01
    z[2,7,3]  R1490     -4.5410543680191040e-02
    z[2,7,3]  R1491     -2.5981745123863220e-01
    z[2,7,3]  R1492     -3.5016742348670959e-01
    z[2,7,3]  R1493     -5.8826500177383423e-01
    z[2,7,3]  R1494     -5.9510171413421631e-01
    z[2,7,3]  R1495     4.4107037782669067e-01
    z[2,7,3]  R1496     8.3597046136856079e-01
    z[2,7,3]  R1497     8.7238538265228271e-01
    z[2,7,3]  R1498     2.2495311498641968e-01
    z[2,7,3]  R1499     2.1142323315143585e-01
    z[2,7,3]  R1500     1.0871886461973190e-01
    z[2,7,3]  R1501     -2.1498848497867584e-01
    z[2,7,3]  R1502     2.7603426575660706e-01
    z[2,7,3]  R1503     -3.3645071089267731e-02
    z[2,7,3]  R1504     -1.9534103572368622e-01
    z[2,7,3]  R1505     -6.7476667463779449e-02
    z[2,7,3]  R1506     -7.6603449881076813e-02
    z[2,7,3]  R1507     3.7834087014198303e-01
    z[2,7,3]  R1508     7.6880931854248047e-02
    z[2,7,3]  R1509     3.3753588795661926e-01
    z[2,7,3]  R1510     1.9323676824569702e-02
    z[2,7,3]  R1511     -2.4950817227363586e-01
    z[2,7,3]  R1512     2.1537464857101440e-01
    z[2,7,3]  R1513     4.7597751021385193e-01
    z[2,7,3]  R1514     -3.5705888271331787e-01
    z[2,7,3]  R1515     3.9178112149238586e-01
    z[2,7,3]  R1516     -5.1507627964019775e-01
    z[2,7,3]  R1517     -5.1381522417068481e-01
    z[2,7,3]  R1518     -3.5033130645751953e-01
    z[2,7,3]  R1519     -3.7505501508712769e-01
    z[2,7,3]  R1520     -2.3978227376937866e-01
    z[2,7,3]  R1521     -2.6280593872070312e-01
    z[2,7,3]  R1522     -3.5178834199905396e-01
    z[2,7,3]  R1523     -0.566901445388794
    z[2,7,3]  R1524     -0.554315984249115
    z[2,7,3]  R1525     -8.1742691993713379e-01
    z[2,7,3]  R1526     5.3159141540527344e-01
    z[2,7,3]  R1527     5.3855520486831665e-01
    z[2,7,3]  R1528     1.6299067437648773e-01
    z[2,7,3]  R1529     3.1442412734031677e-01
    z[2,7,3]  R1530     3.9757695794105530e-01
    z[2,7,3]  R1531     -2.7959507703781128e-01
    z[2,7,3]  R1532     6.3443198800086975e-02
    z[2,7,3]  R1533     -0.675109326839447
    z[2,7,3]  R1534     -2.0627894997596741e-01
    z[2,7,3]  R1535     -7.3001608252525330e-02
    z[2,7,3]  R1536     3.6904498934745789e-01
    z[2,7,3]  R1537     6.6535556316375732e-01
    z[2,7,3]  R1538     1.6231556236743927e-01
    z[2,7,3]  R1539     -3.4614145755767822e-02
    z[2,7,3]  R1540     9.6747368574142456e-02
    z[2,7,3]  R1541     2.3363502323627472e-01
    z[2,7,3]  R1542     3.2033350318670273e-02
    z[2,7,3]  R1543     2.9793012142181396e-01
    z[2,7,4]  R24       -1
    z[2,7,4]  R69       1
    z[2,7,4]  R1428     -1
    z[2,7,4]  R1429     1
    z[2,7,4]  R1434     -1.2899169325828552e-01
    z[2,7,4]  R1435     -7.8646056354045868e-02
    z[2,7,4]  R1436     -3.1243902444839478e-01
    z[2,7,4]  R1437     -3.5084882378578186e-01
    z[2,7,4]  R1438     4.9095014110207558e-03
    z[2,7,4]  R1439     -2.2748914361000061e-01
    z[2,7,4]  R1440     2.7913349866867065e-01
    z[2,7,4]  R1441     -1.1331176012754440e-01
    z[2,7,4]  R1442     -1.6841015219688416e-01
    z[2,7,4]  R1443     1.2260024249553680e-01
    z[2,7,4]  R1444     -2.2443506121635437e-01
    z[2,7,4]  R1445     1.1996795237064362e-01
    z[2,7,4]  R1446     1.7525520920753479e-01
    z[2,7,4]  R1447     1.0365176200866699e-01
    z[2,7,4]  R1448     9.6559226512908936e-02
    z[2,7,4]  R1449     0.200368732213974
    z[2,7,4]  R1450     3.1327697634696960e-01
    z[2,7,4]  R1451     8.6123727262020111e-02
    z[2,7,4]  R1452     -4.3691907078027725e-02
    z[2,7,4]  R1453     -1.7748209834098816e-01
    z[2,7,4]  R1454     -2.5371336936950684e-01
    z[2,7,4]  R1455     -4.9698883295059204e-01
    z[2,7,4]  R1456     -3.7619143724441528e-01
    z[2,7,4]  R1457     -0.0938776507973671
    z[2,7,4]  R1458     -1.9570156931877136e-01
    z[2,7,4]  R1459     -1.9608359038829803e-01
    z[2,7,4]  R1460     -7.5157403945922852e-02
    z[2,7,4]  R1461     -5.9292886406183243e-02
    z[2,7,4]  R1462     8.0217522382736206e-01
    z[2,7,4]  R1463     8.0292326211929321e-01
    z[2,7,4]  R1464     -1.2176158279180527e-01
    z[2,7,4]  R1465     3.5552206635475159e-01
    z[2,7,4]  R1466     1.0803960263729095e-01
    z[2,7,4]  R1467     5.2238047122955322e-01
    z[2,7,4]  R1468     3.6268595606088638e-02
    z[2,7,4]  R1469     2.2943180799484253e-01
    z[2,7,4]  R1470     1.8939814763143659e-03
    z[2,7,4]  R1471     -4.4640892744064331e-01
    z[2,7,4]  R1472     8.2703399658203125e-01
    z[2,7,4]  R1473     6.3625681400299072e-01
    z[2,7,4]  R1474     1.1765540577471256e-02
    z[2,7,4]  R1475     1.6907185316085815e-01
    z[2,7,4]  R1476     -6.3812166452407837e-02
    z[2,7,4]  R1477     2.1971662342548370e-01
    z[2,7,4]  R1478     6.1889201402664185e-01
    z[2,7,4]  R1479     8.9461815357208252e-01
    z[2,7,4]  R1480     -4.0109932422637939e-01
    z[2,7,4]  R1481     2.2225309908390045e-01
    z[2,7,4]  R1482     4.2056638002395630e-01
    z[2,7,4]  R1483     6.5803945064544678e-01
    z[2,7,4]  R1484     -5.1296311616897583e-01
    z[2,7,4]  R1485     -1.9633677601814270e-01
    z[2,7,4]  R1486     2.6759955286979675e-01
    z[2,7,4]  R1487     0.706939697265625
    z[2,7,4]  R1488     8.1082159280776978e-01
    z[2,7,4]  R1489     0.498468816280365
    z[2,7,4]  R1490     0.851675808429718
    z[2,7,4]  R1491     3.3378455042839050e-01
    z[2,7,4]  R1492     5.2420613355934620e-03
    z[2,7,4]  R1493     -4.4159126281738281e-01
    z[2,7,4]  R1494     -5.1426267623901367e-01
    z[2,7,4]  R1495     7.2900778055191040e-01
    z[2,7,4]  R1496     7.7739447355270386e-02
    z[2,7,4]  R1497     1.2438498437404633e-01
    z[2,7,4]  R1498     7.5727772712707520e-01
    z[2,7,4]  R1499     4.4296798110008240e-01
    z[2,7,4]  R1500     3.0513456463813782e-01
    z[2,7,4]  R1501     -2.3997746407985687e-01
    z[2,7,4]  R1502     7.3908336460590363e-02
    z[2,7,4]  R1503     1.9979287683963776e-01
    z[2,7,4]  R1504     8.8081859052181244e-02
    z[2,7,4]  R1505     4.2256745696067810e-01
    z[2,7,4]  R1506     4.9313545227050781e-01
    z[2,7,4]  R1507     1.0212492197751999e-01
    z[2,7,4]  R1508     9.8563842475414276e-02
    z[2,7,4]  R1509     3.8314953446388245e-01
    z[2,7,4]  R1510     6.5418505668640137e-01
    z[2,7,4]  R1511     5.4040521383285522e-02
    z[2,7,4]  R1512     -3.5474825650453568e-02
    z[2,7,4]  R1513     1.6338813304901123e-01
    z[2,7,4]  R1514     1.1716998182237148e-02
    z[2,7,4]  R1515     -2.0683860778808594e-01
    z[2,7,4]  R1516     2.3803491145372391e-02
    z[2,7,4]  R1517     2.1660542488098145e-01
    z[2,7,4]  R1518     5.1346683502197266e-01
    z[2,7,4]  R1519     -2.5644731521606445e-01
    z[2,7,4]  R1520     8.7570890784263611e-02
    z[2,7,4]  R1521     4.4482216238975525e-01
    z[2,7,4]  R1522     -1.8806131184101105e-01
    z[2,7,4]  R1523     3.8330635428428650e-01
    z[2,7,4]  R1524     2.7388921380043030e-01
    z[2,7,4]  R1525     -1.1197332292795181e-01
    z[2,7,4]  R1526     -7.5706982612609863e-01
    z[2,7,4]  R1527     -6.3856667280197144e-01
    z[2,7,4]  R1528     -5.2379405498504639e-01
    z[2,7,4]  R1529     -4.8556759953498840e-01
    z[2,7,4]  R1530     -3.9496758580207825e-01
    z[2,7,4]  R1531     1.3980881869792938e-01
    z[2,7,4]  R1532     -2.8170329332351685e-01
    z[2,7,4]  R1533     -1.0841037333011627e-01
    z[2,7,4]  R1534     -6.2899775803089142e-02
    z[2,7,4]  R1535     3.2857468724250793e-01
    z[2,7,4]  R1536     -0.607761025428772
    z[2,7,4]  R1537     -5.4443657398223877e-01
    z[2,7,4]  R1538     -5.0919461250305176e-01
    z[2,7,4]  R1539     -1.6262637078762054e-01
    z[2,7,4]  R1540     3.6612160503864288e-02
    z[2,7,4]  R1541     1.1570832133293152e-01
    z[2,7,4]  R1542     -2.0798210799694061e-01
    z[2,7,4]  R1543     6.3452489674091339e-02
    z[2,7,5]  R25       -1
    z[2,7,5]  R70       1
    z[2,7,5]  R1430     -1
    z[2,7,5]  R1431     1
    z[2,7,5]  R1434     1.5868553519248962e-01
    z[2,7,5]  R1435     -1.3307699561119080e-01
    z[2,7,5]  R1436     4.5616918802261353e-01
    z[2,7,5]  R1437     2.0551607012748718e-01
    z[2,7,5]  R1438     -1.8133243918418884e-01
    z[2,7,5]  R1439     1.0346614569425583e-01
    z[2,7,5]  R1440     -1.3034285604953766e-01
    z[2,7,5]  R1441     2.8997424244880676e-01
    z[2,7,5]  R1442     -1.0508912801742554e-01
    z[2,7,5]  R1443     2.8377994894981384e-01
    z[2,7,5]  R1444     -3.8235333561897278e-01
    z[2,7,5]  R1445     -4.5161581039428711e-01
    z[2,7,5]  R1446     -2.6684507727622986e-01
    z[2,7,5]  R1447     -2.4281406402587891e-01
    z[2,7,5]  R1448     -5.1673788577318192e-02
    z[2,7,5]  R1449     2.9943871498107910e-01
    z[2,7,5]  R1450     2.3046833276748657e-01
    z[2,7,5]  R1451     -2.0786814391613007e-01
    z[2,7,5]  R1452     5.2016609907150269e-01
    z[2,7,5]  R1453     -3.8530153036117554e-01
    z[2,7,5]  R1454     -2.1397693455219269e-01
    z[2,7,5]  R1455     -5.0712251663208008e-01
    z[2,7,5]  R1456     -4.4329392910003662e-01
    z[2,7,5]  R1457     -0.636333703994751
    z[2,7,5]  R1458     -2.1468611061573029e-01
    z[2,7,5]  R1459     -5.3010553121566772e-01
    z[2,7,5]  R1460     -4.5094919204711914e-01
    z[2,7,5]  R1461     2.3007138073444366e-01
    z[2,7,5]  R1462     -6.2233596108853817e-03
    z[2,7,5]  R1463     2.4792146682739258e-01
    z[2,7,5]  R1464     -1.4309531450271606e-01
    z[2,7,5]  R1465     -3.3593752980232239e-01
    z[2,7,5]  R1466     -3.9521834254264832e-01
    z[2,7,5]  R1467     3.8066470623016357e-01
    z[2,7,5]  R1468     -3.7482002377510071e-01
    z[2,7,5]  R1469     -2.3112215101718903e-01
    z[2,7,5]  R1470     -1.9764302670955658e-01
    z[2,7,5]  R1471     3.4995386004447937e-01
    z[2,7,5]  R1472     0.262921005487442
    z[2,7,5]  R1473     7.3634006083011627e-02
    z[2,7,5]  R1474     -6.6669160127639771e-01
    z[2,7,5]  R1475     -4.7642791271209717e-01
    z[2,7,5]  R1476     -6.8624633550643921e-01
    z[2,7,5]  R1477     5.4921054840087891e-01
    z[2,7,5]  R1478     1.7313297092914581e-01
    z[2,7,5]  R1479     1.3795202970504761e-01
    z[2,7,5]  R1480     -0.472665399312973
    z[2,7,5]  R1481     -3.0621027946472168e-01
    z[2,7,5]  R1482     4.4452944397926331e-01
    z[2,7,5]  R1483     4.3774670362472534e-01
    z[2,7,5]  R1484     -1.1383699625730515e-01
    z[2,7,5]  R1485     -5.2780801057815552e-01
    z[2,7,5]  R1486     5.5221915245056152e-01
    z[2,7,5]  R1487     2.0059312880039215e-01
    z[2,7,5]  R1488     -1.3569347560405731e-01
    z[2,7,5]  R1489     4.4040087610483170e-02
    z[2,7,5]  R1490     8.8828159496188164e-03
    z[2,7,5]  R1491     -3.1864476203918457e-01
    z[2,7,5]  R1492     -4.9679529666900635e-01
    z[2,7,5]  R1493     1.2843219563364983e-02
    z[2,7,5]  R1494     -1.8174874782562256e-01
    z[2,7,5]  R1495     -1.4751896262168884e-01
    z[2,7,5]  R1496     -3.6593183875083923e-02
    z[2,7,5]  R1497     -8.8280633091926575e-02
    z[2,7,5]  R1498     1.9343499839305878e-01
    z[2,7,5]  R1499     -3.6710628867149353e-01
    z[2,7,5]  R1500     0.607828676700592
    z[2,7,5]  R1501     5.4488813877105713e-01
    z[2,7,5]  R1502     0.67137610912323
    z[2,7,5]  R1503     4.1305643320083618e-01
    z[2,7,5]  R1504     1.9620141386985779e-01
    z[2,7,5]  R1505     4.6732330322265625e-01
    z[2,7,5]  R1506     0.257762610912323
    z[2,7,5]  R1507     3.2977280020713806e-01
    z[2,7,5]  R1508     2.7991998195648193e-01
    z[2,7,5]  R1509     -9.0255342423915863e-02
    z[2,7,5]  R1510     2.5046941637992859e-01
    z[2,7,5]  R1511     4.2706301808357239e-01
    z[2,7,5]  R1512     -9.5430992543697357e-02
    z[2,7,5]  R1513     -1.2117945402860641e-01
    z[2,7,5]  R1514     0.194473534822464
    z[2,7,5]  R1515     -3.3332142233848572e-01
    z[2,7,5]  R1516     -1.4950575307011604e-02
    z[2,7,5]  R1517     -2.0976434648036957e-01
    z[2,7,5]  R1518     -0.0895463153719902
    z[2,7,5]  R1519     -1.3865956664085388e-01
    z[2,7,5]  R1520     -3.8939729332923889e-01
    z[2,7,5]  R1521     -5.1084810495376587e-01
    z[2,7,5]  R1522     2.5415942072868347e-01
    z[2,7,5]  R1523     2.4926245212554932e-01
    z[2,7,5]  R1524     3.1599956750869751e-01
    z[2,7,5]  R1525     1.9042393192648888e-02
    z[2,7,5]  R1526     -1.4626312255859375e-01
    z[2,7,5]  R1527     -4.3257924914360046e-01
    z[2,7,5]  R1528     -5.2931028604507446e-01
    z[2,7,5]  R1529     -2.4646340310573578e-01
    z[2,7,5]  R1530     6.6729128360748291e-01
    z[2,7,5]  R1531     -5.0630003213882446e-01
    z[2,7,5]  R1532     6.9655174016952515e-01
    z[2,7,5]  R1533     1.9682997465133667e-01
    z[2,7,5]  R1534     4.1747590899467468e-01
    z[2,7,5]  R1535     -4.2000961303710938e-01
    z[2,7,5]  R1536     2.3197035491466522e-01
    z[2,7,5]  R1537     -3.1511966139078140e-02
    z[2,7,5]  R1538     -4.5322397351264954e-01
    z[2,7,5]  R1539     4.6095319092273712e-02
    z[2,7,5]  R1540     7.3622646741569042e-03
    z[2,7,5]  R1541     -1.3261437416076660e-01
    z[2,7,5]  R1542     3.0438652634620667e-01
    z[2,7,5]  R1543     4.9425348639488220e-01
    z[2,7,6]  R26       -1
    z[2,7,6]  R71       1
    z[2,7,6]  R1432     -1
    z[2,7,6]  R1433     1
    z[2,7,6]  R1434     -5.0029113888740540e-02
    z[2,7,6]  R1435     -2.3115381598472595e-01
    z[2,7,6]  R1436     -8.9278884232044220e-02
    z[2,7,6]  R1437     -1.0339193791151047e-01
    z[2,7,6]  R1438     2.1415881812572479e-01
    z[2,7,6]  R1439     -4.6624112129211426e-01
    z[2,7,6]  R1440     -3.0351492762565613e-01
    z[2,7,6]  R1441     -3.8648679852485657e-01
    z[2,7,6]  R1442     -1.0934099555015564e-01
    z[2,7,6]  R1443     -2.6732918620109558e-01
    z[2,7,6]  R1444     5.1108545064926147e-01
    z[2,7,6]  R1445     -7.2644329071044922e-01
    z[2,7,6]  R1446     -2.0665641129016876e-01
    z[2,7,6]  R1447     -5.1648229360580444e-01
    z[2,7,6]  R1448     -2.5272938609123230e-01
    z[2,7,6]  R1449     1.3192677497863770e-01
    z[2,7,6]  R1450     -9.0538740158081055e-02
    z[2,7,6]  R1451     4.9501422047615051e-01
    z[2,7,6]  R1452     6.2232349067926407e-02
    z[2,7,6]  R1453     -2.6739564538002014e-01
    z[2,7,6]  R1454     -2.0970292389392853e-01
    z[2,7,6]  R1455     1.6176858544349670e-01
    z[2,7,6]  R1456     -2.4438551068305969e-01
    z[2,7,6]  R1457     -1.0012000799179077e-01
    z[2,7,6]  R1458     -3.2189422845840454e-01
    z[2,7,6]  R1459     2.2226870059967041e-01
    z[2,7,6]  R1460     -0.262014240026474
    z[2,7,6]  R1461     -1.6785086691379547e-01
    z[2,7,6]  R1462     3.9106106758117676e-01
    z[2,7,6]  R1463     3.4687098860740662e-01
    z[2,7,6]  R1464     5.4809689521789551e-02
    z[2,7,6]  R1465     -6.6034264862537384e-02
    z[2,7,6]  R1466     1.3592340052127838e-01
    z[2,7,6]  R1467     1.0662989318370819e-01
    z[2,7,6]  R1468     4.2565248906612396e-02
    z[2,7,6]  R1469     -5.8749181032180786e-01
    z[2,7,6]  R1470     3.6409419775009155e-01
    z[2,7,6]  R1471     3.9275979995727539e-01
    z[2,7,6]  R1472     -7.0015847682952881e-02
    z[2,7,6]  R1473     7.8138843178749084e-02
    z[2,7,6]  R1474     1.0038229823112488e-01
    z[2,7,6]  R1475     5.6645695120096207e-02
    z[2,7,6]  R1476     1.4229616522789001e-01
    z[2,7,6]  R1477     1.3901987671852112e-01
    z[2,7,6]  R1478     0.23238605260849
    z[2,7,6]  R1479     2.2056837379932404e-01
    z[2,7,6]  R1480     3.3691248297691345e-01
    z[2,7,6]  R1481     1.2322041392326355e-01
    z[2,7,6]  R1482     1.0096822865307331e-02
    z[2,7,6]  R1483     6.1866792384535074e-04
    z[2,7,6]  R1484     0.0417693592607975
    z[2,7,6]  R1485     5.0848484039306641e-01
    z[2,7,6]  R1486     2.5371477007865906e-01
    z[2,7,6]  R1487     -7.3690533638000488e-02
    z[2,7,6]  R1488     2.1654383838176727e-01
    z[2,7,6]  R1489     1.7860314249992371e-01
    z[2,7,6]  R1490     -5.0366683863103390e-03
    z[2,7,6]  R1491     -2.3265336453914642e-01
    z[2,7,6]  R1492     -6.2715482711791992e-01
    z[2,7,6]  R1493     0.556354284286499
    z[2,7,6]  R1494     2.7617228031158447e-01
    z[2,7,6]  R1495     6.0965497046709061e-02
    z[2,7,6]  R1496     3.6251747608184814e-01
    z[2,7,6]  R1497     2.1518450975418091e-01
    z[2,7,6]  R1498     -3.1988853216171265e-01
    z[2,7,6]  R1499     -1.4080493152141571e-01
    z[2,7,6]  R1500     4.4668808579444885e-01
    z[2,7,6]  R1501     2.3696416616439819e-01
    z[2,7,6]  R1502     -1.7106316983699799e-01
    z[2,7,6]  R1503     2.4901130795478821e-01
    z[2,7,6]  R1504     2.2123497724533081e-01
    z[2,7,6]  R1505     -1.9174998998641968e-01
    z[2,7,6]  R1506     0.0460628941655159
    z[2,7,6]  R1507     -1.5734435617923737e-01
    z[2,7,6]  R1508     4.7708559036254883e-01
    z[2,7,6]  R1509     -6.5209582448005676e-02
    z[2,7,6]  R1510     -2.3663861677050591e-02
    z[2,7,6]  R1511     -1.2370146811008453e-01
    z[2,7,6]  R1512     1.2677356600761414e-01
    z[2,7,6]  R1513     -2.3039312660694122e-01
    z[2,7,6]  R1514     -1.3164682686328888e-01
    z[2,7,6]  R1515     2.1696081757545471e-01
    z[2,7,6]  R1516     2.6832911372184753e-01
    z[2,7,6]  R1517     -1.3177742250263691e-02
    z[2,7,6]  R1518     3.0612629652023315e-01
    z[2,7,6]  R1519     -1.2251044809818268e-01
    z[2,7,6]  R1520     2.6547789573669434e-01
    z[2,7,6]  R1521     0.0589272603392601
    z[2,7,6]  R1522     -4.9622341990470886e-01
    z[2,7,6]  R1523     -3.6355575919151306e-01
    z[2,7,6]  R1524     4.4139412045478821e-01
    z[2,7,6]  R1525     2.6935037970542908e-01
    z[2,7,6]  R1526     -1.2859410047531128e-01
    z[2,7,6]  R1527     1.3162109255790710e-01
    z[2,7,6]  R1528     3.3296972513198853e-02
    z[2,7,6]  R1529     -5.1404148340225220e-01
    z[2,7,6]  R1530     3.3346044365316629e-03
    z[2,7,6]  R1531     -1.9768282771110535e-01
    z[2,7,6]  R1532     2.7940711379051208e-01
    z[2,7,6]  R1533     -4.1030306369066238e-02
    z[2,7,6]  R1534     4.2660921812057495e-01
    z[2,7,6]  R1535     3.8344833254814148e-01
    z[2,7,6]  R1536     -1.2711404263973236e-01
    z[2,7,6]  R1537     -4.1706174612045288e-01
    z[2,7,6]  R1538     -6.1860390007495880e-02
    z[2,7,6]  R1539     -1.2872008979320526e-01
    z[2,7,6]  R1540     5.2757188677787781e-02
    z[2,7,6]  R1541     -1.8861402571201324e-01
    z[2,7,6]  R1542     2.2779045999050140e-01
    z[2,7,6]  R1543     3.3120752777904272e-03
    z[7,2,0]  R20       1
    z[7,2,0]  R65       -1
    z[7,2,0]  R1544     -1
    z[7,2,0]  R1545     1
    z[7,2,0]  R1558     -2.1621994674205780e-01
    z[7,2,0]  R1559     -4.5511227846145630e-01
    z[7,2,0]  R1560     1.1857293546199799e-01
    z[7,2,0]  R1561     -2.6836407184600830e-01
    z[7,2,0]  R1562     -6.1877554655075073e-01
    z[7,2,0]  R1563     -5.6078499555587769e-01
    z[7,2,0]  R1564     -4.8424881696701050e-01
    z[7,2,0]  R1565     -0.493665486574173
    z[7,2,0]  R1566     -6.5295916795730591e-01
    z[7,2,0]  R1567     -5.0218790769577026e-01
    z[7,2,0]  R1568     4.4836950302124023e-01
    z[7,2,0]  R1569     3.7923336029052734e-01
    z[7,2,0]  R1570     3.2009416818618774e-01
    z[7,2,0]  R1571     4.2270222306251526e-01
    z[7,2,0]  R1572     3.3594289422035217e-01
    z[7,2,0]  R1573     0.368246465921402
    z[7,2,0]  R1574     4.5081678032875061e-01
    z[7,2,0]  R1575     4.2248663306236267e-01
    z[7,2,0]  R1576     3.4102728962898254e-01
    z[7,2,0]  R1577     2.0220804214477539e-01
    z[7,2,0]  R1578     -2.8328239917755127e-01
    z[7,2,0]  R1579     -1.7455467581748962e-01
    z[7,2,0]  R1580     -1.4616841077804565e-01
    z[7,2,0]  R1581     2.8160439804196358e-02
    z[7,2,0]  R1582     1.1431477218866348e-01
    z[7,2,0]  R1583     1.0720545798540115e-01
    z[7,2,0]  R1584     2.2843575105071068e-02
    z[7,2,0]  R1585     -2.9791104793548584e-01
    z[7,2,0]  R1586     -2.2452485561370850e-01
    z[7,2,0]  R1587     5.9810775518417358e-01
    z[7,2,0]  R1588     8.8973073288798332e-03
    z[7,2,0]  R1589     -9.1658718883991241e-02
    z[7,2,0]  R1590     1.0764811933040619e-01
    z[7,2,0]  R1591     -2.6607245206832886e-01
    z[7,2,0]  R1592     -4.6468096971511841e-01
    z[7,2,0]  R1593     9.6932905912399292e-01
    z[7,2,0]  R1594     9.6469402313232422e-01
    z[7,2,0]  R1595     9.1660410165786743e-01
    z[7,2,0]  R1596     0.891918957233429
    z[7,2,0]  R1597     8.0443078279495239e-01
    z[7,2,0]  R1598     -4.9124273657798767e-01
    z[7,2,0]  R1599     -7.7634233236312866e-01
    z[7,2,0]  R1600     -4.5373073220252991e-01
    z[7,2,0]  R1601     -6.8108010292053223e-01
    z[7,2,0]  R1602     -7.1953850984573364e-01
    z[7,2,0]  R1603     -4.6407660841941833e-01
    z[7,2,0]  R1604     -3.3312138915061951e-01
    z[7,2,0]  R1605     -7.2410744428634644e-01
    z[7,2,0]  R1606     -6.1397582292556763e-01
    z[7,2,0]  R1607     -1.4422667026519775e-01
    z[7,2,0]  R1608     6.1473723500967026e-02
    z[7,2,0]  R1609     0.153394877910614
    z[7,2,0]  R1610     -2.0218744874000549e-01
    z[7,2,0]  R1611     -1.8500488996505737e-01
    z[7,2,0]  R1612     1.5352945029735565e-01
    z[7,2,0]  R1613     9.4493657350540161e-02
    z[7,2,0]  R1614     -0.059889055788517
    z[7,2,0]  R1615     2.3794810473918915e-01
    z[7,2,0]  R1616     -2.4597447365522385e-02
    z[7,2,0]  R1617     4.5672440528869629e-01
    z[7,2,0]  R1618     4.7142812609672546e-01
    z[7,2,0]  R1619     2.4861901998519897e-02
    z[7,2,0]  R1620     -1.4215698838233948e-01
    z[7,2,0]  R1621     5.0571531057357788e-01
    z[7,2,0]  R1622     1.2481260299682617e-01
    z[7,2,0]  R1623     -4.0614360570907593e-01
    z[7,2,0]  R1624     -1.9890600442886353e-01
    z[7,2,0]  R1625     1.8972903490066528e-02
    z[7,2,0]  R1626     -6.2058974057435989e-02
    z[7,2,0]  R1627     -1.0376165807247162e-01
    z[7,2,0]  R1628     -1.7810884118080139e-01
    z[7,2,0]  R1629     9.4430714845657349e-02
    z[7,2,0]  R1630     1.2676912546157837e-01
    z[7,2,0]  R1631     -1.5843637287616730e-01
    z[7,2,0]  R1632     4.0129086375236511e-01
    z[7,2,0]  R1633     2.0959985256195068e-01
    z[7,2,0]  R1634     4.2695617675781250e-01
    z[7,2,0]  R1635     -8.0943085253238678e-02
    z[7,2,0]  R1636     -3.6984920501708984e-01
    z[7,2,0]  R1637     -6.6380125284194946e-01
    z[7,2,0]  R1638     -4.9481880851089954e-03
    z[7,2,0]  R1639     -6.7595876753330231e-03
    z[7,2,0]  R1640     2.1995209157466888e-01
    z[7,2,0]  R1641     -5.0826031714677811e-02
    z[7,2,0]  R1642     4.4874809682369232e-02
    z[7,2,0]  R1643     -3.3454048633575439e-01
    z[7,2,0]  R1644     2.5708615779876709e-01
    z[7,2,0]  R1645     6.0063779354095459e-01
    z[7,2,0]  R1646     -6.4115297794342041e-01
    z[7,2,0]  R1647     -3.8052040338516235e-01
    z[7,2,0]  R1648     2.9909870028495789e-01
    z[7,2,0]  R1649     -1.2768530286848545e-02
    z[7,2,0]  R1650     -2.4318021535873413e-01
    z[7,2,0]  R1651     6.0623455792665482e-02
    z[7,2,0]  R1652     -4.2846912145614624e-01
    z[7,2,0]  R1653     -2.1448197960853577e-01
    z[7,2,0]  R1654     -3.8751190900802612e-01
    z[7,2,0]  R1655     5.0506293773651123e-01
    z[7,2,0]  R1656     2.9371036216616631e-02
    z[7,2,0]  R1657     -1.8463903665542603e-01
    z[7,2,0]  R1658     -1.7569494247436523e-01
    z[7,2,0]  R1659     -3.0998736619949341e-01
    z[7,2,0]  R1660     -0.0892467051744461
    z[7,2,0]  R1661     3.0539789795875549e-01
    z[7,2,0]  R1662     -3.7317898869514465e-01
    z[7,2,0]  R1663     4.7704753279685974e-01
    z[7,2,0]  R1664     3.6393198370933533e-01
    z[7,2,0]  R1665     6.0187149047851562e-01
    z[7,2,0]  R1666     0.573669970035553
    z[7,2,0]  R1667     6.0565555095672607e-01
    z[7,2,1]  R21       1
    z[7,2,1]  R66       -1
    z[7,2,1]  R1546     -1
    z[7,2,1]  R1547     1
    z[7,2,1]  R1558     -7.6087635755538940e-01
    z[7,2,1]  R1559     -3.7918284535408020e-01
    z[7,2,1]  R1560     -5.8403360843658447e-01
    z[7,2,1]  R1561     -0.577204704284668
    z[7,2,1]  R1562     -5.0304710865020752e-01
    z[7,2,1]  R1563     -5.1557654142379761e-01
    z[7,2,1]  R1564     -3.6960625648498535e-01
    z[7,2,1]  R1565     -6.7872440814971924e-01
    z[7,2,1]  R1566     7.0590823888778687e-01
    z[7,2,1]  R1567     6.5275180339813232e-01
    z[7,2,1]  R1568     7.7657061815261841e-01
    z[7,2,1]  R1569     6.8200689554214478e-01
    z[7,2,1]  R1570     6.6349774599075317e-01
    z[7,2,1]  R1571     6.1811476945877075e-01
    z[7,2,1]  R1572     6.1596262454986572e-01
    z[7,2,1]  R1573     5.7915139198303223e-01
    z[7,2,1]  R1574     7.0773756504058838e-01
    z[7,2,1]  R1575     5.3430587053298950e-01
    z[7,2,1]  R1576     3.9622643589973450e-01
    z[7,2,1]  R1577     4.3754762411117554e-01
    z[7,2,1]  R1578     4.8011958599090576e-01
    z[7,2,1]  R1579     3.8664203882217407e-01
    z[7,2,1]  R1580     -2.5440484285354614e-01
    z[7,2,1]  R1581     -3.0046477913856506e-01
    z[7,2,1]  R1582     -6.3220870494842529e-01
    z[7,2,1]  R1583     -5.6545984745025635e-01
    z[7,2,1]  R1584     4.8776644468307495e-01
    z[7,2,1]  R1585     4.6707892417907715e-01
    z[7,2,1]  R1586     5.2490210533142090e-01
    z[7,2,1]  R1587     -2.4439743161201477e-01
    z[7,2,1]  R1588     0.74985671043396
    z[7,2,1]  R1589     7.4483048915863037e-01
    z[7,2,1]  R1590     6.0011005401611328e-01
    z[7,2,1]  R1591     -1.0027145594358444e-01
    z[7,2,1]  R1592     -3.2934451103210449e-01
    z[7,2,1]  R1593     -1.1398215591907501e-01
    z[7,2,1]  R1594     -1.0426852852106094e-01
    z[7,2,1]  R1595     -0.144050732254982
    z[7,2,1]  R1596     -0.0899525135755539
    z[7,2,1]  R1597     7.9007655382156372e-02
    z[7,2,1]  R1598     -4.4544604420661926e-01
    z[7,2,1]  R1599     -4.0777593851089478e-01
    z[7,2,1]  R1600     -4.2607891559600830e-01
    z[7,2,1]  R1601     -2.7949529886245728e-01
    z[7,2,1]  R1602     -0.350705623626709
    z[7,2,1]  R1603     -0.363901287317276
    z[7,2,1]  R1604     -4.9221006035804749e-01
    z[7,2,1]  R1605     -3.8024628162384033e-01
    z[7,2,1]  R1606     0.237028107047081
    z[7,2,1]  R1607     -8.7349957227706909e-01
    z[7,2,1]  R1608     -2.5577083230018616e-01
    z[7,2,1]  R1609     2.4164129793643951e-01
    z[7,2,1]  R1610     0.829850971698761
    z[7,2,1]  R1611     6.4701384305953979e-01
    z[7,2,1]  R1612     9.1239744424819946e-01
    z[7,2,1]  R1613     8.7869280576705933e-01
    z[7,2,1]  R1614     8.8222002983093262e-01
    z[7,2,1]  R1615     3.3945631980895996e-01
    z[7,2,1]  R1616     7.9038488864898682e-01
    z[7,2,1]  R1617     4.7249439358711243e-01
    z[7,2,1]  R1618     -2.5328485295176506e-02
    z[7,2,1]  R1619     -4.2231306433677673e-01
    z[7,2,1]  R1620     1.6041561961174011e-01
    z[7,2,1]  R1621     9.7372457385063171e-02
    z[7,2,1]  R1622     3.9665067195892334e-01
    z[7,2,1]  R1623     5.0427418947219849e-01
    z[7,2,1]  R1624     -2.2575311362743378e-01
    z[7,2,1]  R1625     2.1479836106300354e-01
    z[7,2,1]  R1626     2.1152751147747040e-01
    z[7,2,1]  R1627     2.3155732452869415e-01
    z[7,2,1]  R1628     -2.0896512269973755e-01
    z[7,2,1]  R1629     -8.6768402252346277e-04
    z[7,2,1]  R1630     4.8274621367454529e-01
    z[7,2,1]  R1631     3.2020667195320129e-01
    z[7,2,1]  R1632     1.8010555207729340e-01
    z[7,2,1]  R1633     -4.0624219179153442e-01
    z[7,2,1]  R1634     -4.6342805027961731e-02
    z[7,2,1]  R1635     2.6514491438865662e-01
    z[7,2,1]  R1636     2.3521491885185242e-01
    z[7,2,1]  R1637     2.4544388055801392e-01
    z[7,2,1]  R1638     -8.3455711603164673e-02
    z[7,2,1]  R1639     1.5370737016201019e-01
    z[7,2,1]  R1640     2.3272086679935455e-01
    z[7,2,1]  R1641     3.5309621691703796e-01
    z[7,2,1]  R1642     1.4941997826099396e-01
    z[7,2,1]  R1643     -3.7667483091354370e-02
    z[7,2,1]  R1644     4.8218145966529846e-01
    z[7,2,1]  R1645     -1.7782464623451233e-01
    z[7,2,1]  R1646     3.9055651426315308e-01
    z[7,2,1]  R1647     4.6254959702491760e-01
    z[7,2,1]  R1648     2.5293555110692978e-02
    z[7,2,1]  R1649     1.9626750051975250e-01
    z[7,2,1]  R1650     9.6097335219383240e-02
    z[7,2,1]  R1651     1.5056197345256805e-01
    z[7,2,1]  R1652     1.8992094695568085e-01
    z[7,2,1]  R1653     3.4925243258476257e-01
    z[7,2,1]  R1654     -9.8732315003871918e-02
    z[7,2,1]  R1655     -1.1955556273460388e-01
    z[7,2,1]  R1656     -4.8471504449844360e-01
    z[7,2,1]  R1657     3.3883380889892578e-01
    z[7,2,1]  R1658     -4.6554881334304810e-01
    z[7,2,1]  R1659     8.7587319314479828e-02
    z[7,2,1]  R1660     3.0281466245651245e-01
    z[7,2,1]  R1661     0.00760143157094717
    z[7,2,1]  R1662     2.8109899163246155e-01
    z[7,2,1]  R1663     4.2320245504379272e-01
    z[7,2,1]  R1664     -2.1706353127956390e-01
    z[7,2,1]  R1665     -3.9704304933547974e-01
    z[7,2,1]  R1666     -1.0005540400743484e-01
    z[7,2,1]  R1667     -0.344194233417511
    z[7,2,2]  R22       1
    z[7,2,2]  R67       -1
    z[7,2,2]  R1548     -1
    z[7,2,2]  R1549     1
    z[7,2,2]  R1558     -4.9087649583816528e-01
    z[7,2,2]  R1559     -4.5914888381958008e-01
    z[7,2,2]  R1560     -5.7204127311706543e-01
    z[7,2,2]  R1561     -5.5474025011062622e-01
    z[7,2,2]  R1562     -2.0608049631118774e-01
    z[7,2,2]  R1563     -3.8284295797348022e-01
    z[7,2,2]  R1564     -3.7049689888954163e-01
    z[7,2,2]  R1565     1.8101982772350311e-01
    z[7,2,2]  R1566     0.0501449890434742
    z[7,2,2]  R1567     -2.6582766324281693e-02
    z[7,2,2]  R1568     1.1455873399972916e-01
    z[7,2,2]  R1569     -1.9130834937095642e-01
    z[7,2,2]  R1570     3.4527698159217834e-01
    z[7,2,2]  R1571     2.9010051488876343e-01
    z[7,2,2]  R1572     -1.4007273316383362e-01
    z[7,2,2]  R1573     5.3694641590118408e-01
    z[7,2,2]  R1574     0.0927298292517662
    z[7,2,2]  R1575     -6.8193182349205017e-02
    z[7,2,2]  R1576     0.50670325756073
    z[7,2,2]  R1577     3.2412725687026978e-01
    z[7,2,2]  R1578     1.1077066510915756e-01
    z[7,2,2]  R1579     -2.5768473744392395e-01
    z[7,2,2]  R1580     1.4226564764976501e-01
    z[7,2,2]  R1581     -8.1668600440025330e-02
    z[7,2,2]  R1582     7.0994421839714050e-02
    z[7,2,2]  R1583     9.5608517527580261e-02
    z[7,2,2]  R1584     -4.6972211450338364e-02
    z[7,2,2]  R1585     5.4767513275146484e-01
    z[7,2,2]  R1586     1.6562581062316895e-01
    z[7,2,2]  R1587     2.7310448884963989e-01
    z[7,2,2]  R1588     1.8667300045490265e-01
    z[7,2,2]  R1589     9.7441887483000755e-03
    z[7,2,2]  R1590     2.2966033220291138e-01
    z[7,2,2]  R1591     7.1472458541393280e-02
    z[7,2,2]  R1592     4.2513498663902283e-01
    z[7,2,2]  R1593     -0.0327107198536396
    z[7,2,2]  R1594     2.1202708780765533e-01
    z[7,2,2]  R1595     1.3398066163063049e-01
    z[7,2,2]  R1596     8.6986780166625977e-02
    z[7,2,2]  R1597     9.7790569067001343e-02
    z[7,2,2]  R1598     -5.0723069906234741e-01
    z[7,2,2]  R1599     -3.0221751332283020e-01
    z[7,2,2]  R1600     -5.4670047760009766e-01
    z[7,2,2]  R1601     -5.1954925060272217e-01
    z[7,2,2]  R1602     -3.8589019328355789e-02
    z[7,2,2]  R1603     -6.0903567075729370e-01
    z[7,2,2]  R1604     -4.8527535051107407e-02
    z[7,2,2]  R1605     -2.2927054762840271e-01
    z[7,2,2]  R1606     -6.1901479959487915e-01
    z[7,2,2]  R1607     3.8353729993104935e-02
    z[7,2,2]  R1608     4.4338819384574890e-01
    z[7,2,2]  R1609     -3.2167810946702957e-02
    z[7,2,2]  R1610     3.1972485780715942e-01
    z[7,2,2]  R1611     5.0286766141653061e-02
    z[7,2,2]  R1612     1.2339603155851364e-01
    z[7,2,2]  R1613     2.6287573575973511e-01
    z[7,2,2]  R1614     2.2269165515899658e-01
    z[7,2,2]  R1615     6.6414773464202881e-01
    z[7,2,2]  R1616     7.4134194292128086e-03
    z[7,2,2]  R1617     -2.6723316311836243e-01
    z[7,2,2]  R1618     -0.0663272812962532
    z[7,2,2]  R1619     -3.2018488645553589e-01
    z[7,2,2]  R1620     -3.5017940402030945e-01
    z[7,2,2]  R1621     1.4386005699634552e-01
    z[7,2,2]  R1622     -8.9014537632465363e-02
    z[7,2,2]  R1623     1.2869903445243835e-01
    z[7,2,2]  R1624     3.2295051217079163e-01
    z[7,2,2]  R1625     3.2745265960693359e-01
    z[7,2,2]  R1626     -2.7053061127662659e-01
    z[7,2,2]  R1627     -3.1839540600776672e-01
    z[7,2,2]  R1628     4.8677217960357666e-01
    z[7,2,2]  R1629     8.2149881124496460e-01
    z[7,2,2]  R1630     5.7530528306961060e-01
    z[7,2,2]  R1631     1.1776317656040192e-01
    z[7,2,2]  R1632     -4.4055002927780151e-01
    z[7,2,2]  R1633     3.9006423950195312e-01
    z[7,2,2]  R1634     -2.8825944662094116e-01
    z[7,2,2]  R1635     -1.3484659790992737e-01
    z[7,2,2]  R1636     2.1095946431159973e-01
    z[7,2,2]  R1637     -1.1477702856063843e-01
    z[7,2,2]  R1638     5.4724162817001343e-01
    z[7,2,2]  R1639     -2.2157758474349976e-01
    z[7,2,2]  R1640     3.6912760138511658e-01
    z[7,2,2]  R1641     -1.3935816287994385e-01
    z[7,2,2]  R1642     -1.5904602408409119e-01
    z[7,2,2]  R1643     -1.1023134738206863e-01
    z[7,2,2]  R1644     -3.6716946959495544e-01
    z[7,2,2]  R1645     6.4137715101242065e-01
    z[7,2,2]  R1646     4.7803804278373718e-02
    z[7,2,2]  R1647     -1.0268244892358780e-01
    z[7,2,2]  R1648     -4.5061972737312317e-01
    z[7,2,2]  R1649     3.8992297649383545e-01
    z[7,2,2]  R1650     1.1180755496025085e-01
    z[7,2,2]  R1651     -4.3792682886123657e-01
    z[7,2,2]  R1652     -2.3457825183868408e-01
    z[7,2,2]  R1653     5.8858606964349747e-02
    z[7,2,2]  R1654     -3.3551222085952759e-01
    z[7,2,2]  R1655     0.629315972328186
    z[7,2,2]  R1656     -3.7618912756443024e-02
    z[7,2,2]  R1657     -1.8613802269101143e-02
    z[7,2,2]  R1658     -1.5646006166934967e-01
    z[7,2,2]  R1659     -3.8047635555267334e-01
    z[7,2,2]  R1660     -2.5038030743598938e-01
    z[7,2,2]  R1661     -2.7576902508735657e-01
    z[7,2,2]  R1662     -1.3379658758640289e-01
    z[7,2,2]  R1663     4.4476044178009033e-01
    z[7,2,2]  R1664     -3.8278463482856750e-01
    z[7,2,2]  R1665     -1.5245710313320160e-01
    z[7,2,2]  R1666     -3.1500127911567688e-01
    z[7,2,2]  R1667     -4.9095860123634338e-01
    z[7,2,3]  R23       1
    z[7,2,3]  R68       -1
    z[7,2,3]  R1550     -1
    z[7,2,3]  R1551     1
    z[7,2,3]  R1558     -1.9534103572368622e-01
    z[7,2,3]  R1559     -6.7476667463779449e-02
    z[7,2,3]  R1560     -7.6603449881076813e-02
    z[7,2,3]  R1561     3.7834087014198303e-01
    z[7,2,3]  R1562     7.6880931854248047e-02
    z[7,2,3]  R1563     3.3753588795661926e-01
    z[7,2,3]  R1564     1.9323676824569702e-02
    z[7,2,3]  R1565     -2.4950817227363586e-01
    z[7,2,3]  R1566     2.1537464857101440e-01
    z[7,2,3]  R1567     4.7597751021385193e-01
    z[7,2,3]  R1568     -3.5705888271331787e-01
    z[7,2,3]  R1569     3.9178112149238586e-01
    z[7,2,3]  R1570     -5.1507627964019775e-01
    z[7,2,3]  R1571     -5.1381522417068481e-01
    z[7,2,3]  R1572     -3.5033130645751953e-01
    z[7,2,3]  R1573     -3.7505501508712769e-01
    z[7,2,3]  R1574     -2.3978227376937866e-01
    z[7,2,3]  R1575     -2.6280593872070312e-01
    z[7,2,3]  R1576     -3.5178834199905396e-01
    z[7,2,3]  R1577     -0.566901445388794
    z[7,2,3]  R1578     -0.554315984249115
    z[7,2,3]  R1579     -8.1742691993713379e-01
    z[7,2,3]  R1580     5.3159141540527344e-01
    z[7,2,3]  R1581     5.3855520486831665e-01
    z[7,2,3]  R1582     1.6299067437648773e-01
    z[7,2,3]  R1583     3.1442412734031677e-01
    z[7,2,3]  R1584     3.9757695794105530e-01
    z[7,2,3]  R1585     -2.7959507703781128e-01
    z[7,2,3]  R1586     6.3443198800086975e-02
    z[7,2,3]  R1587     -0.675109326839447
    z[7,2,3]  R1588     -2.0627894997596741e-01
    z[7,2,3]  R1589     -7.3001608252525330e-02
    z[7,2,3]  R1590     3.6904498934745789e-01
    z[7,2,3]  R1591     6.6535556316375732e-01
    z[7,2,3]  R1592     1.6231556236743927e-01
    z[7,2,3]  R1593     -3.4614145755767822e-02
    z[7,2,3]  R1594     9.6747368574142456e-02
    z[7,2,3]  R1595     2.3363502323627472e-01
    z[7,2,3]  R1596     3.2033350318670273e-02
    z[7,2,3]  R1597     2.9793012142181396e-01
    z[7,2,3]  R1598     5.0857901573181152e-01
    z[7,2,3]  R1599     2.4969819188117981e-01
    z[7,2,3]  R1600     4.9621476791799068e-03
    z[7,2,3]  R1601     -1.0981449484825134e-01
    z[7,2,3]  R1602     5.2821516990661621e-01
    z[7,2,3]  R1603     -3.8038119673728943e-02
    z[7,2,3]  R1604     6.7629760503768921e-01
    z[7,2,3]  R1605     -1.7949819564819336e-01
    z[7,2,3]  R1606     3.6374571919441223e-01
    z[7,2,3]  R1607     2.1840167045593262e-01
    z[7,2,3]  R1608     -0.52577143907547
    z[7,2,3]  R1609     -4.1349199414253235e-01
    z[7,2,3]  R1610     -1.5367542207241058e-01
    z[7,2,3]  R1611     -4.5624691247940063e-01
    z[7,2,3]  R1612     -2.2992837429046631e-01
    z[7,2,3]  R1613     -5.1483251154422760e-02
    z[7,2,3]  R1614     9.5154352486133575e-02
    z[7,2,3]  R1615     -3.0231153964996338e-01
    z[7,2,3]  R1616     -3.1349179148674011e-01
    z[7,2,3]  R1617     -4.9525824189186096e-01
    z[7,2,3]  R1618     -7.8650033473968506e-01
    z[7,2,3]  R1619     -4.3379139900207520e-01
    z[7,2,3]  R1620     -6.5854293107986450e-01
    z[7,2,3]  R1621     -5.3881102800369263e-01
    z[7,2,3]  R1622     -7.9445666074752808e-01
    z[7,2,3]  R1623     -4.4195863604545593e-01
    z[7,2,3]  R1624     -7.2630548477172852e-01
    z[7,2,3]  R1625     -8.7272793054580688e-01
    z[7,2,3]  R1626     2.8594639897346497e-01
    z[7,2,3]  R1627     0.0881413072347641
    z[7,2,3]  R1628     -8.0582714080810547e-01
    z[7,2,3]  R1629     -2.6946470141410828e-01
    z[7,2,3]  R1630     -4.8328486084938049e-01
    z[7,2,3]  R1631     6.5524083375930786e-01
    z[7,2,3]  R1632     6.8470877408981323e-01
    z[7,2,3]  R1633     -4.3322277069091797e-01
    z[7,2,3]  R1634     7.4889016151428223e-01
    z[7,2,3]  R1635     -6.5494573116302490e-01
    z[7,2,3]  R1636     7.3258213698863983e-02
    z[7,2,3]  R1637     -2.6382020115852356e-01
    z[7,2,3]  R1638     -4.8871728777885437e-01
    z[7,2,3]  R1639     8.1759041547775269e-01
    z[7,2,3]  R1640     -0.515705943107605
    z[7,2,3]  R1641     0.695762038230896
    z[7,2,3]  R1642     6.9523996114730835e-01
    z[7,2,3]  R1643     8.0560527741909027e-02
    z[7,2,3]  R1644     -2.6228037476539612e-01
    z[7,2,3]  R1645     -1.9468809664249420e-01
    z[7,2,3]  R1646     2.4396492540836334e-01
    z[7,2,3]  R1647     0.0779092013835907
    z[7,2,3]  R1648     -6.5498644113540649e-01
    z[7,2,3]  R1649     -4.8331132531166077e-01
    z[7,2,3]  R1650     6.9152086973190308e-01
    z[7,2,3]  R1651     4.8625549674034119e-01
    z[7,2,3]  R1652     5.0809867680072784e-02
    z[7,2,3]  R1653     7.3908466100692749e-01
    z[7,2,3]  R1654     -4.5410543680191040e-02
    z[7,2,3]  R1655     -2.5981745123863220e-01
    z[7,2,3]  R1656     -3.5016742348670959e-01
    z[7,2,3]  R1657     -5.8826500177383423e-01
    z[7,2,3]  R1658     -5.9510171413421631e-01
    z[7,2,3]  R1659     4.4107037782669067e-01
    z[7,2,3]  R1660     8.3597046136856079e-01
    z[7,2,3]  R1661     8.7238538265228271e-01
    z[7,2,3]  R1662     2.2495311498641968e-01
    z[7,2,3]  R1663     2.1142323315143585e-01
    z[7,2,3]  R1664     1.0871886461973190e-01
    z[7,2,3]  R1665     -2.1498848497867584e-01
    z[7,2,3]  R1666     2.7603426575660706e-01
    z[7,2,3]  R1667     -3.3645071089267731e-02
    z[7,2,4]  R24       1
    z[7,2,4]  R69       -1
    z[7,2,4]  R1552     -1
    z[7,2,4]  R1553     1
    z[7,2,4]  R1558     8.8081859052181244e-02
    z[7,2,4]  R1559     4.2256745696067810e-01
    z[7,2,4]  R1560     4.9313545227050781e-01
    z[7,2,4]  R1561     1.0212492197751999e-01
    z[7,2,4]  R1562     9.8563842475414276e-02
    z[7,2,4]  R1563     3.8314953446388245e-01
    z[7,2,4]  R1564     6.5418505668640137e-01
    z[7,2,4]  R1565     5.4040521383285522e-02
    z[7,2,4]  R1566     -3.5474825650453568e-02
    z[7,2,4]  R1567     1.6338813304901123e-01
    z[7,2,4]  R1568     1.1716998182237148e-02
    z[7,2,4]  R1569     -2.0683860778808594e-01
    z[7,2,4]  R1570     2.3803491145372391e-02
    z[7,2,4]  R1571     2.1660542488098145e-01
    z[7,2,4]  R1572     5.1346683502197266e-01
    z[7,2,4]  R1573     -2.5644731521606445e-01
    z[7,2,4]  R1574     8.7570890784263611e-02
    z[7,2,4]  R1575     4.4482216238975525e-01
    z[7,2,4]  R1576     -1.8806131184101105e-01
    z[7,2,4]  R1577     3.8330635428428650e-01
    z[7,2,4]  R1578     2.7388921380043030e-01
    z[7,2,4]  R1579     -1.1197332292795181e-01
    z[7,2,4]  R1580     -7.5706982612609863e-01
    z[7,2,4]  R1581     -6.3856667280197144e-01
    z[7,2,4]  R1582     -5.2379405498504639e-01
    z[7,2,4]  R1583     -4.8556759953498840e-01
    z[7,2,4]  R1584     -3.9496758580207825e-01
    z[7,2,4]  R1585     1.3980881869792938e-01
    z[7,2,4]  R1586     -2.8170329332351685e-01
    z[7,2,4]  R1587     -1.0841037333011627e-01
    z[7,2,4]  R1588     -6.2899775803089142e-02
    z[7,2,4]  R1589     3.2857468724250793e-01
    z[7,2,4]  R1590     -0.607761025428772
    z[7,2,4]  R1591     -5.4443657398223877e-01
    z[7,2,4]  R1592     -5.0919461250305176e-01
    z[7,2,4]  R1593     -1.6262637078762054e-01
    z[7,2,4]  R1594     3.6612160503864288e-02
    z[7,2,4]  R1595     1.1570832133293152e-01
    z[7,2,4]  R1596     -2.0798210799694061e-01
    z[7,2,4]  R1597     6.3452489674091339e-02
    z[7,2,4]  R1598     -1.2899169325828552e-01
    z[7,2,4]  R1599     -7.8646056354045868e-02
    z[7,2,4]  R1600     -3.1243902444839478e-01
    z[7,2,4]  R1601     -3.5084882378578186e-01
    z[7,2,4]  R1602     4.9095014110207558e-03
    z[7,2,4]  R1603     -2.2748914361000061e-01
    z[7,2,4]  R1604     2.7913349866867065e-01
    z[7,2,4]  R1605     -1.1331176012754440e-01
    z[7,2,4]  R1606     -1.6841015219688416e-01
    z[7,2,4]  R1607     1.2260024249553680e-01
    z[7,2,4]  R1608     -2.2443506121635437e-01
    z[7,2,4]  R1609     1.1996795237064362e-01
    z[7,2,4]  R1610     1.7525520920753479e-01
    z[7,2,4]  R1611     1.0365176200866699e-01
    z[7,2,4]  R1612     9.6559226512908936e-02
    z[7,2,4]  R1613     0.200368732213974
    z[7,2,4]  R1614     3.1327697634696960e-01
    z[7,2,4]  R1615     8.6123727262020111e-02
    z[7,2,4]  R1616     -4.3691907078027725e-02
    z[7,2,4]  R1617     -1.7748209834098816e-01
    z[7,2,4]  R1618     -2.5371336936950684e-01
    z[7,2,4]  R1619     -4.9698883295059204e-01
    z[7,2,4]  R1620     -3.7619143724441528e-01
    z[7,2,4]  R1621     -0.0938776507973671
    z[7,2,4]  R1622     -1.9570156931877136e-01
    z[7,2,4]  R1623     -1.9608359038829803e-01
    z[7,2,4]  R1624     -7.5157403945922852e-02
    z[7,2,4]  R1625     -5.9292886406183243e-02
    z[7,2,4]  R1626     8.0217522382736206e-01
    z[7,2,4]  R1627     8.0292326211929321e-01
    z[7,2,4]  R1628     -1.2176158279180527e-01
    z[7,2,4]  R1629     3.5552206635475159e-01
    z[7,2,4]  R1630     1.0803960263729095e-01
    z[7,2,4]  R1631     5.2238047122955322e-01
    z[7,2,4]  R1632     3.6268595606088638e-02
    z[7,2,4]  R1633     2.2943180799484253e-01
    z[7,2,4]  R1634     1.8939814763143659e-03
    z[7,2,4]  R1635     -4.4640892744064331e-01
    z[7,2,4]  R1636     8.2703399658203125e-01
    z[7,2,4]  R1637     6.3625681400299072e-01
    z[7,2,4]  R1638     1.1765540577471256e-02
    z[7,2,4]  R1639     1.6907185316085815e-01
    z[7,2,4]  R1640     -6.3812166452407837e-02
    z[7,2,4]  R1641     2.1971662342548370e-01
    z[7,2,4]  R1642     6.1889201402664185e-01
    z[7,2,4]  R1643     8.9461815357208252e-01
    z[7,2,4]  R1644     -4.0109932422637939e-01
    z[7,2,4]  R1645     2.2225309908390045e-01
    z[7,2,4]  R1646     4.2056638002395630e-01
    z[7,2,4]  R1647     6.5803945064544678e-01
    z[7,2,4]  R1648     -5.1296311616897583e-01
    z[7,2,4]  R1649     -1.9633677601814270e-01
    z[7,2,4]  R1650     2.6759955286979675e-01
    z[7,2,4]  R1651     0.706939697265625
    z[7,2,4]  R1652     8.1082159280776978e-01
    z[7,2,4]  R1653     0.498468816280365
    z[7,2,4]  R1654     0.851675808429718
    z[7,2,4]  R1655     3.3378455042839050e-01
    z[7,2,4]  R1656     5.2420613355934620e-03
    z[7,2,4]  R1657     -4.4159126281738281e-01
    z[7,2,4]  R1658     -5.1426267623901367e-01
    z[7,2,4]  R1659     7.2900778055191040e-01
    z[7,2,4]  R1660     7.7739447355270386e-02
    z[7,2,4]  R1661     1.2438498437404633e-01
    z[7,2,4]  R1662     7.5727772712707520e-01
    z[7,2,4]  R1663     4.4296798110008240e-01
    z[7,2,4]  R1664     3.0513456463813782e-01
    z[7,2,4]  R1665     -2.3997746407985687e-01
    z[7,2,4]  R1666     7.3908336460590363e-02
    z[7,2,4]  R1667     1.9979287683963776e-01
    z[7,2,5]  R25       1
    z[7,2,5]  R70       -1
    z[7,2,5]  R1554     -1
    z[7,2,5]  R1555     1
    z[7,2,5]  R1558     1.9620141386985779e-01
    z[7,2,5]  R1559     4.6732330322265625e-01
    z[7,2,5]  R1560     0.257762610912323
    z[7,2,5]  R1561     3.2977280020713806e-01
    z[7,2,5]  R1562     2.7991998195648193e-01
    z[7,2,5]  R1563     -9.0255342423915863e-02
    z[7,2,5]  R1564     2.5046941637992859e-01
    z[7,2,5]  R1565     4.2706301808357239e-01
    z[7,2,5]  R1566     -9.5430992543697357e-02
    z[7,2,5]  R1567     -1.2117945402860641e-01
    z[7,2,5]  R1568     0.194473534822464
    z[7,2,5]  R1569     -3.3332142233848572e-01
    z[7,2,5]  R1570     -1.4950575307011604e-02
    z[7,2,5]  R1571     -2.0976434648036957e-01
    z[7,2,5]  R1572     -0.0895463153719902
    z[7,2,5]  R1573     -1.3865956664085388e-01
    z[7,2,5]  R1574     -3.8939729332923889e-01
    z[7,2,5]  R1575     -5.1084810495376587e-01
    z[7,2,5]  R1576     2.5415942072868347e-01
    z[7,2,5]  R1577     2.4926245212554932e-01
    z[7,2,5]  R1578     3.1599956750869751e-01
    z[7,2,5]  R1579     1.9042393192648888e-02
    z[7,2,5]  R1580     -1.4626312255859375e-01
    z[7,2,5]  R1581     -4.3257924914360046e-01
    z[7,2,5]  R1582     -5.2931028604507446e-01
    z[7,2,5]  R1583     -2.4646340310573578e-01
    z[7,2,5]  R1584     6.6729128360748291e-01
    z[7,2,5]  R1585     -5.0630003213882446e-01
    z[7,2,5]  R1586     6.9655174016952515e-01
    z[7,2,5]  R1587     1.9682997465133667e-01
    z[7,2,5]  R1588     4.1747590899467468e-01
    z[7,2,5]  R1589     -4.2000961303710938e-01
    z[7,2,5]  R1590     2.3197035491466522e-01
    z[7,2,5]  R1591     -3.1511966139078140e-02
    z[7,2,5]  R1592     -4.5322397351264954e-01
    z[7,2,5]  R1593     4.6095319092273712e-02
    z[7,2,5]  R1594     7.3622646741569042e-03
    z[7,2,5]  R1595     -1.3261437416076660e-01
    z[7,2,5]  R1596     3.0438652634620667e-01
    z[7,2,5]  R1597     4.9425348639488220e-01
    z[7,2,5]  R1598     1.5868553519248962e-01
    z[7,2,5]  R1599     -1.3307699561119080e-01
    z[7,2,5]  R1600     4.5616918802261353e-01
    z[7,2,5]  R1601     2.0551607012748718e-01
    z[7,2,5]  R1602     -1.8133243918418884e-01
    z[7,2,5]  R1603     1.0346614569425583e-01
    z[7,2,5]  R1604     -1.3034285604953766e-01
    z[7,2,5]  R1605     2.8997424244880676e-01
    z[7,2,5]  R1606     -1.0508912801742554e-01
    z[7,2,5]  R1607     2.8377994894981384e-01
    z[7,2,5]  R1608     -3.8235333561897278e-01
    z[7,2,5]  R1609     -4.5161581039428711e-01
    z[7,2,5]  R1610     -2.6684507727622986e-01
    z[7,2,5]  R1611     -2.4281406402587891e-01
    z[7,2,5]  R1612     -5.1673788577318192e-02
    z[7,2,5]  R1613     2.9943871498107910e-01
    z[7,2,5]  R1614     2.3046833276748657e-01
    z[7,2,5]  R1615     -2.0786814391613007e-01
    z[7,2,5]  R1616     5.2016609907150269e-01
    z[7,2,5]  R1617     -3.8530153036117554e-01
    z[7,2,5]  R1618     -2.1397693455219269e-01
    z[7,2,5]  R1619     -5.0712251663208008e-01
    z[7,2,5]  R1620     -4.4329392910003662e-01
    z[7,2,5]  R1621     -0.636333703994751
    z[7,2,5]  R1622     -2.1468611061573029e-01
    z[7,2,5]  R1623     -5.3010553121566772e-01
    z[7,2,5]  R1624     -4.5094919204711914e-01
    z[7,2,5]  R1625     2.3007138073444366e-01
    z[7,2,5]  R1626     -6.2233596108853817e-03
    z[7,2,5]  R1627     2.4792146682739258e-01
    z[7,2,5]  R1628     -1.4309531450271606e-01
    z[7,2,5]  R1629     -3.3593752980232239e-01
    z[7,2,5]  R1630     -3.9521834254264832e-01
    z[7,2,5]  R1631     3.8066470623016357e-01
    z[7,2,5]  R1632     -3.7482002377510071e-01
    z[7,2,5]  R1633     -2.3112215101718903e-01
    z[7,2,5]  R1634     -1.9764302670955658e-01
    z[7,2,5]  R1635     3.4995386004447937e-01
    z[7,2,5]  R1636     0.262921005487442
    z[7,2,5]  R1637     7.3634006083011627e-02
    z[7,2,5]  R1638     -6.6669160127639771e-01
    z[7,2,5]  R1639     -4.7642791271209717e-01
    z[7,2,5]  R1640     -6.8624633550643921e-01
    z[7,2,5]  R1641     5.4921054840087891e-01
    z[7,2,5]  R1642     1.7313297092914581e-01
    z[7,2,5]  R1643     1.3795202970504761e-01
    z[7,2,5]  R1644     -0.472665399312973
    z[7,2,5]  R1645     -3.0621027946472168e-01
    z[7,2,5]  R1646     4.4452944397926331e-01
    z[7,2,5]  R1647     4.3774670362472534e-01
    z[7,2,5]  R1648     -1.1383699625730515e-01
    z[7,2,5]  R1649     -5.2780801057815552e-01
    z[7,2,5]  R1650     5.5221915245056152e-01
    z[7,2,5]  R1651     2.0059312880039215e-01
    z[7,2,5]  R1652     -1.3569347560405731e-01
    z[7,2,5]  R1653     4.4040087610483170e-02
    z[7,2,5]  R1654     8.8828159496188164e-03
    z[7,2,5]  R1655     -3.1864476203918457e-01
    z[7,2,5]  R1656     -4.9679529666900635e-01
    z[7,2,5]  R1657     1.2843219563364983e-02
    z[7,2,5]  R1658     -1.8174874782562256e-01
    z[7,2,5]  R1659     -1.4751896262168884e-01
    z[7,2,5]  R1660     -3.6593183875083923e-02
    z[7,2,5]  R1661     -8.8280633091926575e-02
    z[7,2,5]  R1662     1.9343499839305878e-01
    z[7,2,5]  R1663     -3.6710628867149353e-01
    z[7,2,5]  R1664     0.607828676700592
    z[7,2,5]  R1665     5.4488813877105713e-01
    z[7,2,5]  R1666     0.67137610912323
    z[7,2,5]  R1667     4.1305643320083618e-01
    z[7,2,6]  R26       1
    z[7,2,6]  R71       -1
    z[7,2,6]  R1556     -1
    z[7,2,6]  R1557     1
    z[7,2,6]  R1558     2.2123497724533081e-01
    z[7,2,6]  R1559     -1.9174998998641968e-01
    z[7,2,6]  R1560     0.0460628941655159
    z[7,2,6]  R1561     -1.5734435617923737e-01
    z[7,2,6]  R1562     4.7708559036254883e-01
    z[7,2,6]  R1563     -6.5209582448005676e-02
    z[7,2,6]  R1564     -2.3663861677050591e-02
    z[7,2,6]  R1565     -1.2370146811008453e-01
    z[7,2,6]  R1566     1.2677356600761414e-01
    z[7,2,6]  R1567     -2.3039312660694122e-01
    z[7,2,6]  R1568     -1.3164682686328888e-01
    z[7,2,6]  R1569     2.1696081757545471e-01
    z[7,2,6]  R1570     2.6832911372184753e-01
    z[7,2,6]  R1571     -1.3177742250263691e-02
    z[7,2,6]  R1572     3.0612629652023315e-01
    z[7,2,6]  R1573     -1.2251044809818268e-01
    z[7,2,6]  R1574     2.6547789573669434e-01
    z[7,2,6]  R1575     0.0589272603392601
    z[7,2,6]  R1576     -4.9622341990470886e-01
    z[7,2,6]  R1577     -3.6355575919151306e-01
    z[7,2,6]  R1578     4.4139412045478821e-01
    z[7,2,6]  R1579     2.6935037970542908e-01
    z[7,2,6]  R1580     -1.2859410047531128e-01
    z[7,2,6]  R1581     1.3162109255790710e-01
    z[7,2,6]  R1582     3.3296972513198853e-02
    z[7,2,6]  R1583     -5.1404148340225220e-01
    z[7,2,6]  R1584     3.3346044365316629e-03
    z[7,2,6]  R1585     -1.9768282771110535e-01
    z[7,2,6]  R1586     2.7940711379051208e-01
    z[7,2,6]  R1587     -4.1030306369066238e-02
    z[7,2,6]  R1588     4.2660921812057495e-01
    z[7,2,6]  R1589     3.8344833254814148e-01
    z[7,2,6]  R1590     -1.2711404263973236e-01
    z[7,2,6]  R1591     -4.1706174612045288e-01
    z[7,2,6]  R1592     -6.1860390007495880e-02
    z[7,2,6]  R1593     -1.2872008979320526e-01
    z[7,2,6]  R1594     5.2757188677787781e-02
    z[7,2,6]  R1595     -1.8861402571201324e-01
    z[7,2,6]  R1596     2.2779045999050140e-01
    z[7,2,6]  R1597     3.3120752777904272e-03
    z[7,2,6]  R1598     -5.0029113888740540e-02
    z[7,2,6]  R1599     -2.3115381598472595e-01
    z[7,2,6]  R1600     -8.9278884232044220e-02
    z[7,2,6]  R1601     -1.0339193791151047e-01
    z[7,2,6]  R1602     2.1415881812572479e-01
    z[7,2,6]  R1603     -4.6624112129211426e-01
    z[7,2,6]  R1604     -3.0351492762565613e-01
    z[7,2,6]  R1605     -3.8648679852485657e-01
    z[7,2,6]  R1606     -1.0934099555015564e-01
    z[7,2,6]  R1607     -2.6732918620109558e-01
    z[7,2,6]  R1608     5.1108545064926147e-01
    z[7,2,6]  R1609     -7.2644329071044922e-01
    z[7,2,6]  R1610     -2.0665641129016876e-01
    z[7,2,6]  R1611     -5.1648229360580444e-01
    z[7,2,6]  R1612     -2.5272938609123230e-01
    z[7,2,6]  R1613     1.3192677497863770e-01
    z[7,2,6]  R1614     -9.0538740158081055e-02
    z[7,2,6]  R1615     4.9501422047615051e-01
    z[7,2,6]  R1616     6.2232349067926407e-02
    z[7,2,6]  R1617     -2.6739564538002014e-01
    z[7,2,6]  R1618     -2.0970292389392853e-01
    z[7,2,6]  R1619     1.6176858544349670e-01
    z[7,2,6]  R1620     -2.4438551068305969e-01
    z[7,2,6]  R1621     -1.0012000799179077e-01
    z[7,2,6]  R1622     -3.2189422845840454e-01
    z[7,2,6]  R1623     2.2226870059967041e-01
    z[7,2,6]  R1624     -0.262014240026474
    z[7,2,6]  R1625     -1.6785086691379547e-01
    z[7,2,6]  R1626     3.9106106758117676e-01
    z[7,2,6]  R1627     3.4687098860740662e-01
    z[7,2,6]  R1628     5.4809689521789551e-02
    z[7,2,6]  R1629     -6.6034264862537384e-02
    z[7,2,6]  R1630     1.3592340052127838e-01
    z[7,2,6]  R1631     1.0662989318370819e-01
    z[7,2,6]  R1632     4.2565248906612396e-02
    z[7,2,6]  R1633     -5.8749181032180786e-01
    z[7,2,6]  R1634     3.6409419775009155e-01
    z[7,2,6]  R1635     3.9275979995727539e-01
    z[7,2,6]  R1636     -7.0015847682952881e-02
    z[7,2,6]  R1637     7.8138843178749084e-02
    z[7,2,6]  R1638     1.0038229823112488e-01
    z[7,2,6]  R1639     5.6645695120096207e-02
    z[7,2,6]  R1640     1.4229616522789001e-01
    z[7,2,6]  R1641     1.3901987671852112e-01
    z[7,2,6]  R1642     0.23238605260849
    z[7,2,6]  R1643     2.2056837379932404e-01
    z[7,2,6]  R1644     3.3691248297691345e-01
    z[7,2,6]  R1645     1.2322041392326355e-01
    z[7,2,6]  R1646     1.0096822865307331e-02
    z[7,2,6]  R1647     6.1866792384535074e-04
    z[7,2,6]  R1648     0.0417693592607975
    z[7,2,6]  R1649     5.0848484039306641e-01
    z[7,2,6]  R1650     2.5371477007865906e-01
    z[7,2,6]  R1651     -7.3690533638000488e-02
    z[7,2,6]  R1652     2.1654383838176727e-01
    z[7,2,6]  R1653     1.7860314249992371e-01
    z[7,2,6]  R1654     -5.0366683863103390e-03
    z[7,2,6]  R1655     -2.3265336453914642e-01
    z[7,2,6]  R1656     -6.2715482711791992e-01
    z[7,2,6]  R1657     0.556354284286499
    z[7,2,6]  R1658     2.7617228031158447e-01
    z[7,2,6]  R1659     6.0965497046709061e-02
    z[7,2,6]  R1660     3.6251747608184814e-01
    z[7,2,6]  R1661     2.1518450975418091e-01
    z[7,2,6]  R1662     -3.1988853216171265e-01
    z[7,2,6]  R1663     -1.4080493152141571e-01
    z[7,2,6]  R1664     4.4668808579444885e-01
    z[7,2,6]  R1665     2.3696416616439819e-01
    z[7,2,6]  R1666     -1.7106316983699799e-01
    z[7,2,6]  R1667     2.4901130795478821e-01
    z[3,6,0]  R29       -1
    z[3,6,0]  R56       1
    z[3,6,0]  R1668     -1
    z[3,6,0]  R1669     1
    z[3,6,0]  R1682     -6.8427008390426636e-01
    z[3,6,0]  R1683     -1.4818302355706692e-02
    z[3,6,0]  R1684     -3.4127944707870483e-01
    z[3,6,0]  R1685     -3.2248872518539429e-01
    z[3,6,0]  R1686     -4.1533282399177551e-01
    z[3,6,0]  R1687     3.2071336172521114e-03
    z[3,6,0]  R1688     -7.8725844621658325e-02
    z[3,6,0]  R1689     -1.8082509934902191e-01
    z[3,6,0]  R1690     -3.0452203750610352e-01
    z[3,6,0]  R1691     2.1030250191688538e-01
    z[3,6,0]  R1692     -0.369750440120697
    z[3,6,0]  R1693     -3.6885312199592590e-01
    z[3,6,0]  R1694     3.4414097666740417e-01
    z[3,6,0]  R1695     -3.8569509983062744e-01
    z[3,6,0]  R1696     -3.7709867954254150e-01
    z[3,6,0]  R1697     -2.5882118940353394e-01
    z[3,6,0]  R1698     5.3064805269241333e-01
    z[3,6,0]  R1699     -4.6140491962432861e-01
    z[3,6,0]  R1700     1.0283546894788742e-01
    z[3,6,0]  R1701     1.1462587118148804e-01
    z[3,6,0]  R1702     2.0582200586795807e-01
    z[3,6,0]  R1703     -1.8039016425609589e-01
    z[3,6,0]  R1704     -1.4154779911041260e-01
    z[3,6,0]  R1705     2.8120434284210205e-01
    z[3,6,0]  R1706     2.1532581746578217e-01
    z[3,6,0]  R1707     -3.2824245095252991e-01
    z[3,6,0]  R1708     3.4028959274291992e-01
    z[3,6,0]  R1709     2.9312244057655334e-01
    z[3,6,0]  R1710     1.1301513016223907e-01
    z[3,6,0]  R1711     2.0777639746665955e-01
    z[3,6,0]  R1712     -4.3527320027351379e-01
    z[3,6,0]  R1713     1.6804765909910202e-02
    z[3,6,0]  R1714     -1.4892593026161194e-01
    z[3,6,0]  R1715     3.1925755739212036e-01
    z[3,6,0]  R1716     -1.5773749351501465e-01
    z[3,6,0]  R1717     -1.5710341930389404e-01
    z[3,6,0]  R1718     -1.9159191846847534e-01
    z[3,6,0]  R1719     -0.639341413974762
    z[3,6,0]  R1720     1.9629706442356110e-01
    z[3,6,0]  R1721     -2.8094035387039185e-01
    z[3,6,0]  R1722     -2.6799976825714111e-01
    z[3,6,0]  R1723     -3.0848485231399536e-01
    z[3,6,0]  R1724     -0.502948522567749
    z[3,6,0]  R1725     -4.1463658213615417e-01
    z[3,6,0]  R1726     -4.0166664123535156e-01
    z[3,6,0]  R1727     -6.7071980237960815e-01
    z[3,6,0]  R1728     4.1482448577880859e-01
    z[3,6,0]  R1729     1.3724394142627716e-01
    z[3,6,0]  R1730     1.4065656065940857e-01
    z[3,6,0]  R1731     -1.9479477405548096e-01
    z[3,6,0]  R1732     3.3613452315330505e-01
    z[3,6,0]  R1733     1.0425824671983719e-01
    z[3,6,0]  R1734     0.254373162984848
    z[3,6,0]  R1735     -1.9016842544078827e-01
    z[3,6,0]  R1736     1.0421057045459747e-01
    z[3,6,0]  R1737     5.0094765424728394e-01
    z[3,6,0]  R1738     -4.1455483436584473e-01
    z[3,6,0]  R1739     -1.5327689051628113e-01
    z[3,6,0]  R1740     -7.3224997520446777e-01
    z[3,6,0]  R1741     -4.9367743730545044e-01
    z[3,6,0]  R1742     1.4100821316242218e-01
    z[3,6,0]  R1743     2.1753439307212830e-01
    z[3,6,0]  R1744     -1.2073613703250885e-01
    z[3,6,0]  R1745     -1.8786756694316864e-01
    z[3,6,0]  R1746     -9.2207081615924835e-03
    z[3,6,0]  R1747     2.0490171015262604e-01
    z[3,6,0]  R1748     -4.1622537374496460e-01
    z[3,6,0]  R1749     -0.274004727602005
    z[3,6,0]  R1750     1.6240687668323517e-01
    z[3,6,0]  R1751     -5.9607338905334473e-01
    z[3,6,0]  R1752     -3.1939432024955750e-01
    z[3,6,0]  R1753     -4.3587210774421692e-01
    z[3,6,0]  R1754     4.1314664483070374e-01
    z[3,6,0]  R1755     -1.7168661952018738e-01
    z[3,6,0]  R1756     -0.0768650621175766
    z[3,6,0]  R1757     1.2949213385581970e-01
    z[3,6,0]  R1758     -8.7719194591045380e-02
    z[3,6,0]  R1759     5.6931927800178528e-02
    z[3,6,0]  R1760     5.4856240749359131e-01
    z[3,6,0]  R1761     6.0297280550003052e-01
    z[3,6,0]  R1762     -1.9797690212726593e-01
    z[3,6,0]  R1763     1.5428879298269749e-02
    z[3,6,0]  R1764     1.7626523971557617e-01
    z[3,6,0]  R1765     4.1131421923637390e-01
    z[3,6,0]  R1766     2.3615600541234016e-02
    z[3,6,0]  R1767     5.5942213535308838e-01
    z[3,6,0]  R1768     3.5299485921859741e-01
    z[3,6,0]  R1769     -1.6912724822759628e-02
    z[3,6,0]  R1770     1.3452319800853729e-01
    z[3,6,0]  R1771     2.1778613328933716e-01
    z[3,6,0]  R1772     -2.8781610727310181e-01
    z[3,6,0]  R1773     3.7395498156547546e-01
    z[3,6,0]  R1774     2.0948988199234009e-01
    z[3,6,0]  R1775     1.1307834833860397e-01
    z[3,6,0]  R1776     -1.8201948702335358e-01
    z[3,6,0]  R1777     -2.8810063004493713e-01
    z[3,6,0]  R1778     9.0143084526062012e-01
    z[3,6,1]  R30       -1
    z[3,6,1]  R57       1
    z[3,6,1]  R1670     -1
    z[3,6,1]  R1671     1
    z[3,6,1]  R1682     -5.6477773189544678e-01
    z[3,6,1]  R1683     -7.5187635421752930e-01
    z[3,6,1]  R1684     -6.2260061502456665e-01
    z[3,6,1]  R1685     -4.6212467551231384e-01
    z[3,6,1]  R1686     -3.4248134493827820e-01
    z[3,6,1]  R1687     -5.2284485101699829e-01
    z[3,6,1]  R1688     -5.7583832740783691e-01
    z[3,6,1]  R1689     -0.672904372215271
    z[3,6,1]  R1690     7.6640832424163818e-01
    z[3,6,1]  R1691     8.8993984460830688e-01
    z[3,6,1]  R1692     0.696917712688446
    z[3,6,1]  R1693     7.6524215936660767e-01
    z[3,6,1]  R1694     5.4195505380630493e-01
    z[3,6,1]  R1695     0.670072078704834
    z[3,6,1]  R1696     6.4999777078628540e-01
    z[3,6,1]  R1697     7.1910876035690308e-01
    z[3,6,1]  R1698     2.6219698786735535e-01
    z[3,6,1]  R1699     6.5600740909576416e-01
    z[3,6,1]  R1700     0.321405291557312
    z[3,6,1]  R1701     5.5682206153869629e-01
    z[3,6,1]  R1702     0.855639636516571
    z[3,6,1]  R1703     9.2047715187072754e-01
    z[3,6,1]  R1704     -5.6608009338378906e-01
    z[3,6,1]  R1705     -6.5798693895339966e-01
    z[3,6,1]  R1706     -7.5619047880172729e-01
    z[3,6,1]  R1707     6.1508959531784058e-01
    z[3,6,1]  R1708     -4.8962280154228210e-01
    z[3,6,1]  R1709     5.5734282732009888e-01
    z[3,6,1]  R1710     6.2382537126541138e-01
    z[3,6,1]  R1711     6.9943684339523315e-01
    z[3,6,1]  R1712     -5.6367683410644531e-01
    z[3,6,1]  R1713     7.6815813779830933e-01
    z[3,6,1]  R1714     -7.6969122886657715e-01
    z[3,6,1]  R1715     -7.3696362972259521e-01
    z[3,6,1]  R1716     -9.2049682140350342e-01
    z[3,6,1]  R1717     -7.5868427753448486e-01
    z[3,6,1]  R1718     6.7385560274124146e-01
    z[3,6,1]  R1719     5.2036279439926147e-01
    z[3,6,1]  R1720     0.868614137172699
    z[3,6,1]  R1721     8.1428307294845581e-01
    z[3,6,1]  R1722     2.6034945249557495e-01
    z[3,6,1]  R1723     -3.4273234009742737e-01
    z[3,6,1]  R1724     3.3970236778259277e-01
    z[3,6,1]  R1725     0.287553071975708
    z[3,6,1]  R1726     -1.8081579357385635e-02
    z[3,6,1]  R1727     -1.0382114350795746e-01
    z[3,6,1]  R1728     6.3087075948715210e-01
    z[3,6,1]  R1729     6.6886502504348755e-01
    z[3,6,1]  R1730     7.1507990360260010e-01
    z[3,6,1]  R1731     1.6465568542480469e-01
    z[3,6,1]  R1732     -1.9731727242469788e-01
    z[3,6,1]  R1733     2.3253744840621948e-01
    z[3,6,1]  R1734     -1.3593323528766632e-01
    z[3,6,1]  R1735     4.5358244329690933e-02
    z[3,6,1]  R1736     -0.3088398873806
    z[3,6,1]  R1737     -2.1598720923066139e-02
    z[3,6,1]  R1738     -1.5587671659886837e-02
    z[3,6,1]  R1739     -1.1244186758995056e-01
    z[3,6,1]  R1740     -1.2262280285358429e-01
    z[3,6,1]  R1741     -4.1260862350463867e-01
    z[3,6,1]  R1742     -2.0453684031963348e-01
    z[3,6,1]  R1743     1.3772989809513092e-01
    z[3,6,1]  R1744     -3.0731928348541260e-01
    z[3,6,1]  R1745     3.0537009239196777e-01
    z[3,6,1]  R1746     1.7410951852798462e-01
    z[3,6,1]  R1747     5.5265665054321289e-01
    z[3,6,1]  R1748     3.9770871400833130e-01
    z[3,6,1]  R1749     1.5753868967294693e-02
    z[3,6,1]  R1750     -2.0316170156002045e-01
    z[3,6,1]  R1751     -2.0895386114716530e-02
    z[3,6,1]  R1752     3.3721652626991272e-01
    z[3,6,1]  R1753     0.0609736330807209
    z[3,6,1]  R1754     -3.0422195792198181e-01
    z[3,6,1]  R1755     2.3960523307323456e-01
    z[3,6,1]  R1756     5.8998677879571915e-02
    z[3,6,1]  R1757     8.6291587352752686e-01
    z[3,6,1]  R1758     8.5653185844421387e-01
    z[3,6,1]  R1759     8.1906998157501221e-01
    z[3,6,1]  R1760     7.3512208461761475e-01
    z[3,6,1]  R1761     4.4444590806961060e-01
    z[3,6,1]  R1762     -2.5734481215476990e-01
    z[3,6,1]  R1763     3.8917216658592224e-01
    z[3,6,1]  R1764     9.5235210657119751e-01
    z[3,6,1]  R1765     -1.1356313712894917e-02
    z[3,6,1]  R1766     9.0541803836822510e-01
    z[3,6,1]  R1767     5.4022759199142456e-01
    z[3,6,1]  R1768     5.0834619998931885e-01
    z[3,6,1]  R1769     -9.0297651290893555e-01
    z[3,6,1]  R1770     -8.1154477596282959e-01
    z[3,6,1]  R1771     -9.0584987401962280e-01
    z[3,6,1]  R1772     -1.6611185669898987e-01
    z[3,6,1]  R1773     9.2443414032459259e-02
    z[3,6,1]  R1774     3.8873386383056641e-01
    z[3,6,1]  R1775     -6.8229228258132935e-01
    z[3,6,1]  R1776     -3.2924848794937134e-01
    z[3,6,1]  R1777     -2.0766112208366394e-01
    z[3,6,1]  R1778     -1.3121864199638367e-01
    z[3,6,2]  R31       -1
    z[3,6,2]  R58       1
    z[3,6,2]  R1672     -1
    z[3,6,2]  R1673     1
    z[3,6,2]  R1682     -1.5577442944049835e-01
    z[3,6,2]  R1683     -6.0458236932754517e-01
    z[3,6,2]  R1684     -5.1972138881683350e-01
    z[3,6,2]  R1685     -3.8542884588241577e-01
    z[3,6,2]  R1686     -4.9501702189445496e-01
    z[3,6,2]  R1687     -3.6971840262413025e-01
    z[3,6,2]  R1688     -0.673039972782135
    z[3,6,2]  R1689     7.3226056993007660e-02
    z[3,6,2]  R1690     -3.3864775300025940e-01
    z[3,6,2]  R1691     -1.6483345627784729e-01
    z[3,6,2]  R1692     4.4338285923004150e-01
    z[3,6,2]  R1693     2.1244935691356659e-01
    z[3,6,2]  R1694     4.1812750697135925e-01
    z[3,6,2]  R1695     3.2986089587211609e-01
    z[3,6,2]  R1696     7.5422719120979309e-02
    z[3,6,2]  R1697     -1.8810895085334778e-01
    z[3,6,2]  R1698     4.7620362043380737e-01
    z[3,6,2]  R1699     3.8832318782806396e-01
    z[3,6,2]  R1700     6.0331451892852783e-01
    z[3,6,2]  R1701     4.2715713381767273e-01
    z[3,6,2]  R1702     1.9687317311763763e-01
    z[3,6,2]  R1703     1.8519483506679535e-01
    z[3,6,2]  R1704     -0.0568130724132061
    z[3,6,2]  R1705     -1.6443207859992981e-01
    z[3,6,2]  R1706     1.1148890107870102e-01
    z[3,6,2]  R1707     1.9072158634662628e-01
    z[3,6,2]  R1708     -0.0665467232465744
    z[3,6,2]  R1709     4.0483516454696655e-01
    z[3,6,2]  R1710     3.5350584983825684e-01
    z[3,6,2]  R1711     1.7171221971511841e-01
    z[3,6,2]  R1712     -1.9684784114360809e-01
    z[3,6,2]  R1713     7.5926974415779114e-02
    z[3,6,2]  R1714     -3.3008918166160583e-01
    z[3,6,2]  R1715     -3.6259409785270691e-01
    z[3,6,2]  R1716     1.0326393693685532e-01
    z[3,6,2]  R1717     -3.9868235588073730e-02
    z[3,6,2]  R1718     -6.3102908432483673e-02
    z[3,6,2]  R1719     -0.0151675371453166
    z[3,6,2]  R1720     -1.6450341045856476e-01
    z[3,6,2]  R1721     8.5549578070640564e-02
    z[3,6,2]  R1722     -3.9756676554679871e-01
    z[3,6,2]  R1723     -4.9994894862174988e-01
    z[3,6,2]  R1724     -2.3084443807601929e-01
    z[3,6,2]  R1725     -2.0341536402702332e-01
    z[3,6,2]  R1726     1.1693882942199707e-01
    z[3,6,2]  R1727     8.1346176564693451e-02
    z[3,6,2]  R1728     -2.8455637395381927e-02
    z[3,6,2]  R1729     -4.7480916976928711e-01
    z[3,6,2]  R1730     0.399924099445343
    z[3,6,2]  R1731     -3.5927772521972656e-01
    z[3,6,2]  R1732     -2.6057684421539307e-01
    z[3,6,2]  R1733     7.0517949759960175e-02
    z[3,6,2]  R1734     1.9377246499061584e-01
    z[3,6,2]  R1735     -3.5220120102167130e-02
    z[3,6,2]  R1736     -1.5724499523639679e-01
    z[3,6,2]  R1737     -0.251311331987381
    z[3,6,2]  R1738     -4.4861888885498047e-01
    z[3,6,2]  R1739     8.4616623818874359e-02
    z[3,6,2]  R1740     -4.3666278943419456e-03
    z[3,6,2]  R1741     2.8069657087326050e-01
    z[3,6,2]  R1742     1.4100825786590576e-01
    z[3,6,2]  R1743     -8.8609211146831512e-02
    z[3,6,2]  R1744     -3.8922277092933655e-01
    z[3,6,2]  R1745     -8.1903554499149323e-02
    z[3,6,2]  R1746     -0.564672589302063
    z[3,6,2]  R1747     -3.1437207013368607e-02
    z[3,6,2]  R1748     -1.1584430932998657e-01
    z[3,6,2]  R1749     -2.2531510889530182e-01
    z[3,6,2]  R1750     2.7839755639433861e-03
    z[3,6,2]  R1751     -5.0746973603963852e-02
    z[3,6,2]  R1752     -2.3050782084465027e-01
    z[3,6,2]  R1753     2.4781459942460060e-02
    z[3,6,2]  R1754     -6.3811242580413818e-02
    z[3,6,2]  R1755     -8.2455776631832123e-02
    z[3,6,2]  R1756     -2.8026726841926575e-01
    z[3,6,2]  R1757     7.1502029895782471e-02
    z[3,6,2]  R1758     2.1758085489273071e-01
    z[3,6,2]  R1759     3.5238778591156006e-01
    z[3,6,2]  R1760     -1.8645766377449036e-01
    z[3,6,2]  R1761     3.1171867251396179e-01
    z[3,6,2]  R1762     -3.9491170644760132e-01
    z[3,6,2]  R1763     1.6960716247558594e-01
    z[3,6,2]  R1764     -1.4601002633571625e-01
    z[3,6,2]  R1765     -4.1508537530899048e-01
    z[3,6,2]  R1766     2.7347663044929504e-01
    z[3,6,2]  R1767     2.0718546211719513e-01
    z[3,6,2]  R1768     3.8754299283027649e-01
    z[3,6,2]  R1769     7.2244450449943542e-02
    z[3,6,2]  R1770     0.145552858710289
    z[3,6,2]  R1771     5.7123210281133652e-02
    z[3,6,2]  R1772     -3.3237934112548828e-01
    z[3,6,2]  R1773     -3.8678976893424988e-01
    z[3,6,2]  R1774     5.5587112903594971e-01
    z[3,6,2]  R1775     -3.4621194005012512e-02
    z[3,6,2]  R1776     -0.0864488035440445
    z[3,6,2]  R1777     -1.7532606422901154e-01
    z[3,6,2]  R1778     -0.0704229474067688
    z[3,6,3]  R32       -1
    z[3,6,3]  R59       1
    z[3,6,3]  R1674     -1
    z[3,6,3]  R1675     1
    z[3,6,3]  R1682     -9.7489524632692337e-03
    z[3,6,3]  R1683     -1.8885856866836548e-01
    z[3,6,3]  R1684     2.1941512823104858e-01
    z[3,6,3]  R1685     1.1851963587105274e-02
    z[3,6,3]  R1686     -5.8438103646039963e-02
    z[3,6,3]  R1687     0.045077845454216
    z[3,6,3]  R1688     3.5778489708900452e-01
    z[3,6,3]  R1689     5.2593439817428589e-01
    z[3,6,3]  R1690     8.0375157296657562e-02
    z[3,6,3]  R1691     3.9720643311738968e-02
    z[3,6,3]  R1692     -3.7784284353256226e-01
    z[3,6,3]  R1693     1.4121010899543762e-01
    z[3,6,3]  R1694     -4.6531671285629272e-01
    z[3,6,3]  R1695     -1.1461026966571808e-02
    z[3,6,3]  R1696     -3.4973528236150742e-02
    z[3,6,3]  R1697     1.7360763251781464e-01
    z[3,6,3]  R1698     -5.9369200468063354e-01
    z[3,6,3]  R1699     5.9511110186576843e-02
    z[3,6,3]  R1700     -6.6745573282241821e-01
    z[3,6,3]  R1701     -5.3625065833330154e-02
    z[3,6,3]  R1702     -5.7023368775844574e-02
    z[3,6,3]  R1703     1.3739582896232605e-01
    z[3,6,3]  R1704     1.2602323293685913e-01
    z[3,6,3]  R1705     1.6580019891262054e-01
    z[3,6,3]  R1706     4.8164751380681992e-02
    z[3,6,3]  R1707     -1.5695963799953461e-01
    z[3,6,3]  R1708     5.0392758846282959e-01
    z[3,6,3]  R1709     -4.8290807008743286e-01
    z[3,6,3]  R1710     -4.1087540984153748e-01
    z[3,6,3]  R1711     -2.4842780828475952e-01
    z[3,6,3]  R1712     4.7737839818000793e-01
    z[3,6,3]  R1713     -3.4771889448165894e-01
    z[3,6,3]  R1714     3.4257954359054565e-01
    z[3,6,3]  R1715     0.376578152179718
    z[3,6,3]  R1716     -0.270519495010376
    z[3,6,3]  R1717     9.1828359290957451e-03
    z[3,6,3]  R1718     -9.3843534588813782e-02
    z[3,6,3]  R1719     1.2134262919425964e-01
    z[3,6,3]  R1720     1.5632796287536621e-01
    z[3,6,3]  R1721     1.5583147108554840e-01
    z[3,6,3]  R1722     6.5393263101577759e-01
    z[3,6,3]  R1723     5.0959396362304688e-01
    z[3,6,3]  R1724     4.0262740850448608e-01
    z[3,6,3]  R1725     0.0463026687502861
    z[3,6,3]  R1726     -7.2940096259117126e-02
    z[3,6,3]  R1727     2.8767937421798706e-01
    z[3,6,3]  R1728     -0.0512276254594326
    z[3,6,3]  R1729     -7.1023985743522644e-02
    z[3,6,3]  R1730     -3.7454909086227417e-01
    z[3,6,3]  R1731     -7.4034363031387329e-02
    z[3,6,3]  R1732     -3.3794444799423218e-01
    z[3,6,3]  R1733     -2.8308334946632385e-01
    z[3,6,3]  R1734     -0.391967236995697
    z[3,6,3]  R1735     -2.7441471815109253e-01
    z[3,6,3]  R1736     -3.5618439316749573e-01
    z[3,6,3]  R1737     -4.3386444449424744e-01
    z[3,6,3]  R1738     -2.6035135984420776e-01
    z[3,6,3]  R1739     -3.7802201509475708e-01
    z[3,6,3]  R1740     -3.1466564536094666e-01
    z[3,6,3]  R1741     -2.4095329642295837e-01
    z[3,6,3]  R1742     -6.8053388595581055e-01
    z[3,6,3]  R1743     -7.2847908735275269e-01
    z[3,6,3]  R1744     -7.1762156486511230e-01
    z[3,6,3]  R1745     -6.7181175947189331e-01
    z[3,6,3]  R1746     -7.5338131189346313e-01
    z[3,6,3]  R1747     -6.4652174711227417e-01
    z[3,6,3]  R1748     -6.3391441106796265e-01
    z[3,6,3]  R1749     -5.2807462215423584e-01
    z[3,6,3]  R1750     -6.9509744644165039e-01
    z[3,6,3]  R1751     -7.5340855121612549e-01
    z[3,6,3]  R1752     -6.3471955060958862e-01
    z[3,6,3]  R1753     -7.7655339241027832e-01
    z[3,6,3]  R1754     -6.2197327613830566e-01
    z[3,6,3]  R1755     -6.6663116216659546e-01
    z[3,6,3]  R1756     -5.9071314334869385e-01
    z[3,6,3]  R1757     2.1089186891913414e-02
    z[3,6,3]  R1758     4.1512794792652130e-02
    z[3,6,3]  R1759     -3.4831660985946655e-01
    z[3,6,3]  R1760     -3.0824735760688782e-02
    z[3,6,3]  R1761     -5.2167940139770508e-01
    z[3,6,3]  R1762     -4.0444770455360413e-01
    z[3,6,3]  R1763     -8.0958712100982666e-01
    z[3,6,3]  R1764     -1.7638245224952698e-01
    z[3,6,3]  R1765     -4.1537594795227051e-01
    z[3,6,3]  R1766     -1.8703933060169220e-01
    z[3,6,3]  R1767     -5.4770672321319580e-01
    z[3,6,3]  R1768     -5.7849675416946411e-01
    z[3,6,3]  R1769     -2.0557032525539398e-01
    z[3,6,3]  R1770     -4.5151209831237793e-01
    z[3,6,3]  R1771     -2.2021782398223877e-01
    z[3,6,3]  R1772     -8.3125251531600952e-01
    z[3,6,3]  R1773     -0.372031033039093
    z[3,6,3]  R1774     -0.626023530960083
    z[3,6,3]  R1775     -3.2117596268653870e-01
    z[3,6,3]  R1776     4.4315099716186523e-01
    z[3,6,3]  R1777     3.2139471173286438e-01
    z[3,6,3]  R1778     2.2495168447494507e-01
    z[3,6,4]  R33       -1
    z[3,6,4]  R60       1
    z[3,6,4]  R1676     -1
    z[3,6,4]  R1677     1
    z[3,6,4]  R1682     3.0825203657150269e-01
    z[3,6,4]  R1683     0.101965993642807
    z[3,6,4]  R1684     -7.2813339531421661e-02
    z[3,6,4]  R1685     5.3983730077743530e-01
    z[3,6,4]  R1686     2.6378706097602844e-01
    z[3,6,4]  R1687     5.3849774599075317e-01
    z[3,6,4]  R1688     1.8499688804149628e-01
    z[3,6,4]  R1689     1.7156605422496796e-01
    z[3,6,4]  R1690     5.0421640276908875e-02
    z[3,6,4]  R1691     0.0775560736656189
    z[3,6,4]  R1692     9.6017621457576752e-02
    z[3,6,4]  R1693     -0.452067106962204
    z[3,6,4]  R1694     1.6617333889007568e-01
    z[3,6,4]  R1695     -1.8061715364456177e-01
    z[3,6,4]  R1696     7.5188815593719482e-02
    z[3,6,4]  R1697     -2.5747114419937134e-01
    z[3,6,4]  R1698     6.2724113464355469e-02
    z[3,6,4]  R1699     -7.3110930621623993e-02
    z[3,6,4]  R1700     1.9055263698101044e-01
    z[3,6,4]  R1701     -3.1058004498481750e-01
    z[3,6,4]  R1702     -2.2223468124866486e-01
    z[3,6,4]  R1703     -1.9229148328304291e-01
    z[3,6,4]  R1704     -5.6604868173599243e-01
    z[3,6,4]  R1705     -2.6208677887916565e-01
    z[3,6,4]  R1706     -5.1472359895706177e-01
    z[3,6,4]  R1707     -2.4435704946517944e-01
    z[3,6,4]  R1708     -4.8377969861030579e-01
    z[3,6,4]  R1709     -2.3590198159217834e-01
    z[3,6,4]  R1710     0.509386420249939
    z[3,6,4]  R1711     -4.3700519204139709e-01
    z[3,6,4]  R1712     -2.1561256051063538e-01
    z[3,6,4]  R1713     -1.8238714337348938e-01
    z[3,6,4]  R1714     -2.8487563133239746e-01
    z[3,6,4]  R1715     -5.8203574270009995e-02
    z[3,6,4]  R1716     4.1803520172834396e-02
    z[3,6,4]  R1717     1.7025732994079590e-01
    z[3,6,4]  R1718     -2.4461135268211365e-01
    z[3,6,4]  R1719     -1.7198120057582855e-01
    z[3,6,4]  R1720     1.3553853332996368e-01
    z[3,6,4]  R1721     3.7733739614486694e-01
    z[3,6,4]  R1722     -3.6099845170974731e-01
    z[3,6,4]  R1723     -5.0128477811813354e-01
    z[3,6,4]  R1724     -2.4232718348503113e-01
    z[3,6,4]  R1725     -6.2378132343292236e-01
    z[3,6,4]  R1726     -7.6530051231384277e-01
    z[3,6,4]  R1727     -8.2309916615486145e-02
    z[3,6,4]  R1728     5.0870066881179810e-01
    z[3,6,4]  R1729     5.2494859695434570e-01
    z[3,6,4]  R1730     2.2784644365310669e-01
    z[3,6,4]  R1731     6.3623136281967163e-01
    z[3,6,4]  R1732     6.6906195878982544e-01
    z[3,6,4]  R1733     0.715188205242157
    z[3,6,4]  R1734     8.1924271583557129e-01
    z[3,6,4]  R1735     7.3967492580413818e-01
    z[3,6,4]  R1736     4.9545809626579285e-01
    z[3,6,4]  R1737     6.3771128654479980e-01
    z[3,6,4]  R1738     6.3362246751785278e-01
    z[3,6,4]  R1739     1.2641207873821259e-01
    z[3,6,4]  R1740     4.4084584712982178e-01
    z[3,6,4]  R1741     5.3377324342727661e-01
    z[3,6,4]  R1742     5.4180890321731567e-01
    z[3,6,4]  R1743     1.1982502788305283e-01
    z[3,6,4]  R1744     3.1549152731895447e-01
    z[3,6,4]  R1745     1.6357085108757019e-01
    z[3,6,4]  R1746     2.0659507811069489e-01
    z[3,6,4]  R1747     3.2729476690292358e-01
    z[3,6,4]  R1748     3.3463621139526367e-01
    z[3,6,4]  R1749     5.3437018394470215e-01
    z[3,6,4]  R1750     5.3751307725906372e-01
    z[3,6,4]  R1751     2.0646791160106659e-01
    z[3,6,4]  R1752     4.4832786917686462e-01
    z[3,6,4]  R1753     2.7401667833328247e-01
    z[3,6,4]  R1754     5.2053558826446533e-01
    z[3,6,4]  R1755     5.4928040504455566e-01
    z[3,6,4]  R1756     1.5408772230148315e-01
    z[3,6,4]  R1757     2.7578663825988770e-01
    z[3,6,4]  R1758     3.2866501808166504e-01
    z[3,6,4]  R1759     -1.2901960313320160e-01
    z[3,6,4]  R1760     0.0457758866250515
    z[3,6,4]  R1761     -2.8694493696093559e-02
    z[3,6,4]  R1762     7.3351776599884033e-01
    z[3,6,4]  R1763     0.338083416223526
    z[3,6,4]  R1764     0.0929412767291069
    z[3,6,4]  R1765     6.1885702610015869e-01
    z[3,6,4]  R1766     -1.6371940076351166e-01
    z[3,6,4]  R1767     -0.0817561224102974
    z[3,6,4]  R1768     -0.0737539529800415
    z[3,6,4]  R1769     2.4493876099586487e-01
    z[3,6,4]  R1770     -6.9230049848556519e-02
    z[3,6,4]  R1771     1.8002241849899292e-01
    z[3,6,4]  R1772     2.5551870465278625e-01
    z[3,6,4]  R1773     6.9033432006835938e-01
    z[3,6,4]  R1774     2.9557922482490540e-01
    z[3,6,4]  R1775     1.9327664747834206e-02
    z[3,6,4]  R1776     7.8321486711502075e-01
    z[3,6,4]  R1777     5.0879049301147461e-01
    z[3,6,4]  R1778     2.1860572695732117e-01
    z[3,6,5]  R34       -1
    z[3,6,5]  R61       1
    z[3,6,5]  R1678     -1
    z[3,6,5]  R1679     1
    z[3,6,5]  R1682     0.288438618183136
    z[3,6,5]  R1683     7.3415338993072510e-02
    z[3,6,5]  R1684     3.1598886847496033e-01
    z[3,6,5]  R1685     2.9113727807998657e-01
    z[3,6,5]  R1686     5.9622806310653687e-01
    z[3,6,5]  R1687     3.8937801122665405e-01
    z[3,6,5]  R1688     1.0548871755599976e-01
    z[3,6,5]  R1689     -3.0654066801071167e-01
    z[3,6,5]  R1690     -1.3580715656280518e-01
    z[3,6,5]  R1691     2.7249258756637573e-01
    z[3,6,5]  R1692     -1.0735871642827988e-01
    z[3,6,5]  R1693     -5.4265994578599930e-02
    z[3,6,5]  R1694     -4.0690630674362183e-01
    z[3,6,5]  R1695     -5.0688081979751587e-01
    z[3,6,5]  R1696     -3.9016571640968323e-01
    z[3,6,5]  R1697     2.6489531993865967e-01
    z[3,6,5]  R1698     -2.3758928477764130e-01
    z[3,6,5]  R1699     -1.5222407877445221e-01
    z[3,6,5]  R1700     -1.7769478261470795e-01
    z[3,6,5]  R1701     -5.3262615203857422e-01
    z[3,6,5]  R1702     -3.4445360302925110e-01
    z[3,6,5]  R1703     -2.3536950349807739e-02
    z[3,6,5]  R1704     -4.9152320623397827e-01
    z[3,6,5]  R1705     -3.7724217772483826e-01
    z[3,6,5]  R1706     -8.8155664503574371e-02
    z[3,6,5]  R1707     6.2642043828964233e-01
    z[3,6,5]  R1708     9.6060521900653839e-02
    z[3,6,5]  R1709     3.6358323693275452e-01
    z[3,6,5]  R1710     1.1877653747797012e-01
    z[3,6,5]  R1711     4.1252571344375610e-01
    z[3,6,5]  R1712     -2.3521672189235687e-01
    z[3,6,5]  R1713     3.4173348546028137e-01
    z[3,6,5]  R1714     -2.1266996860504150e-01
    z[3,6,5]  R1715     1.3347616791725159e-01
    z[3,6,5]  R1716     -1.7888711392879486e-01
    z[3,6,5]  R1717     -5.8507549762725830e-01
    z[3,6,5]  R1718     3.9482930302619934e-01
    z[3,6,5]  R1719     -1.5781989693641663e-01
    z[3,6,5]  R1720     3.6871945858001709e-01
    z[3,6,5]  R1721     -2.8889900445938110e-01
    z[3,6,5]  R1722     -0.018271429464221
    z[3,6,5]  R1723     1.4349387586116791e-01
    z[3,6,5]  R1724     5.8392512798309326e-01
    z[3,6,5]  R1725     2.1635049581527710e-01
    z[3,6,5]  R1726     -1.1129476875066757e-01
    z[3,6,5]  R1727     5.4812282323837280e-01
    z[3,6,5]  R1728     1.7855556309223175e-01
    z[3,6,5]  R1729     3.8373034447431564e-02
    z[3,6,5]  R1730     3.3966964483261108e-01
    z[3,6,5]  R1731     -1.1695603281259537e-01
    z[3,6,5]  R1732     -4.6720793843269348e-01
    z[3,6,5]  R1733     -5.8165037631988525e-01
    z[3,6,5]  R1734     -1.4780853688716888e-01
    z[3,6,5]  R1735     -4.4981312751770020e-01
    z[3,6,5]  R1736     -5.9563565254211426e-01
    z[3,6,5]  R1737     -4.4312477111816406e-02
    z[3,6,5]  R1738     -3.2998120784759521e-01
    z[3,6,5]  R1739     -8.6903309822082520e-01
    z[3,6,5]  R1740     -3.4434261918067932e-01
    z[3,6,5]  R1741     -3.8126403093338013e-01
    z[3,6,5]  R1742     -2.0543164014816284e-01
    z[3,6,5]  R1743     -5.7612472772598267e-01
    z[3,6,5]  R1744     -1.0551296174526215e-01
    z[3,6,5]  R1745     -5.4740172624588013e-01
    z[3,6,5]  R1746     1.8206527456641197e-02
    z[3,6,5]  R1747     -2.8901594877243042e-01
    z[3,6,5]  R1748     -2.9624858498573303e-01
    z[3,6,5]  R1749     -1.8342342972755432e-01
    z[3,6,5]  R1750     3.7831076979637146e-01
    z[3,6,5]  R1751     1.7657433450222015e-01
    z[3,6,5]  R1752     -3.4343191981315613e-01
    z[3,6,5]  R1753     -2.7499023079872131e-01
    z[3,6,5]  R1754     -2.2095876932144165e-01
    z[3,6,5]  R1755     2.4364241957664490e-01
    z[3,6,5]  R1756     -5.7318305969238281e-01
    z[3,6,5]  R1757     -2.4612143635749817e-01
    z[3,6,5]  R1758     -2.8453272581100464e-01
    z[3,6,5]  R1759     0.06783477216959
    z[3,6,5]  R1760     1.8392252922058105e-01
    z[3,6,5]  R1761     -8.6709603667259216e-02
    z[3,6,5]  R1762     -1.7306198179721832e-01
    z[3,6,5]  R1763     1.6388094425201416e-01
    z[3,6,5]  R1764     2.9382398352026939e-02
    z[3,6,5]  R1765     2.2259229794144630e-02
    z[3,6,5]  R1766     -1.5884411334991455e-01
    z[3,6,5]  R1767     1.3070951402187347e-01
    z[3,6,5]  R1768     3.4013697504997253e-01
    z[3,6,5]  R1769     2.4353970587253571e-01
    z[3,6,5]  R1770     3.0460250377655029e-01
    z[3,6,5]  R1771     1.4695046842098236e-01
    z[3,6,5]  R1772     -2.7154510840773582e-02
    z[3,6,5]  R1773     -4.0896151214838028e-02
    z[3,6,5]  R1774     -5.0095748156309128e-02
    z[3,6,5]  R1775     4.9466714262962341e-01
    z[3,6,5]  R1776     -1.7966248095035553e-01
    z[3,6,5]  R1777     -2.6726812124252319e-01
    z[3,6,5]  R1778     -2.2878044843673706e-01
    z[3,6,6]  R35       -1
    z[3,6,6]  R62       1
    z[3,6,6]  R1680     -1
    z[3,6,6]  R1681     1
    z[3,6,6]  R1682     -1.0111232101917267e-01
    z[3,6,6]  R1683     1.3224272429943085e-01
    z[3,6,6]  R1684     2.6924493908882141e-01
    z[3,6,6]  R1685     3.9693927764892578e-01
    z[3,6,6]  R1686     1.9151189923286438e-01
    z[3,6,6]  R1687     -3.8249734044075012e-01
    z[3,6,6]  R1688     -1.8938811123371124e-01
    z[3,6,6]  R1689     -3.3034953474998474e-01
    z[3,6,6]  R1690     -4.2161145806312561e-01
    z[3,6,6]  R1691     -2.3401927947998047e-01
    z[3,6,6]  R1692     1.3225534558296204e-01
    z[3,6,6]  R1693     -7.7248126268386841e-02
    z[3,6,6]  R1694     5.7576749473810196e-02
    z[3,6,6]  R1695     6.1256840825080872e-02
    z[3,6,6]  R1696     5.2010113000869751e-01
    z[3,6,6]  R1697     4.6250253915786743e-01
    z[3,6,6]  R1698     -1.0021121054887772e-01
    z[3,6,6]  R1699     -4.1702026128768921e-01
    z[3,6,6]  R1700     -9.3552783131599426e-02
    z[3,6,6]  R1701     -3.3364757895469666e-01
    z[3,6,6]  R1702     1.2438180297613144e-01
    z[3,6,6]  R1703     -1.7168733477592468e-01
    z[3,6,6]  R1704     2.8000321984291077e-01
    z[3,6,6]  R1705     4.7164449095726013e-01
    z[3,6,6]  R1706     3.0716332793235779e-01
    z[3,6,6]  R1707     -2.8244480490684509e-02
    z[3,6,6]  R1708     3.7792941927909851e-01
    z[3,6,6]  R1709     -1.3606618344783783e-01
    z[3,6,6]  R1710     -1.7522041499614716e-01
    z[3,6,6]  R1711     1.2355015426874161e-01
    z[3,6,6]  R1712     3.5263389348983765e-01
    z[3,6,6]  R1713     -3.6459651589393616e-01
    z[3,6,6]  R1714     1.8081568181514740e-01
    z[3,6,6]  R1715     2.4590662121772766e-01
    z[3,6,6]  R1716     1.0105468332767487e-01
    z[3,6,6]  R1717     0.163529634475708
    z[3,6,6]  R1718     5.2980917692184448e-01
    z[3,6,6]  R1719     5.0102514028549194e-01
    z[3,6,6]  R1720     3.3948723226785660e-02
    z[3,6,6]  R1721     -2.3816585540771484e-02
    z[3,6,6]  R1722     3.7954360246658325e-01
    z[3,6,6]  R1723     7.6548673212528229e-02
    z[3,6,6]  R1724     -1.2867036461830139e-01
    z[3,6,6]  R1725     -5.1571053266525269e-01
    z[3,6,6]  R1726     4.7039404511451721e-01
    z[3,6,6]  R1727     3.7784385681152344e-01
    z[3,6,6]  R1728     -3.6855155229568481e-01
    z[3,6,6]  R1729     -1.6202476620674133e-01
    z[3,6,6]  R1730     -3.6887574940919876e-02
    z[3,6,6]  R1731     -6.1799097061157227e-01
    z[3,6,6]  R1732     -6.7602782510221004e-03
    z[3,6,6]  R1733     -1.1672931723296642e-02
    z[3,6,6]  R1734     1.8062233924865723e-01
    z[3,6,6]  R1735     0.368488609790802
    z[3,6,6]  R1736     3.7670186161994934e-01
    z[3,6,6]  R1737     2.9757311940193176e-01
    z[3,6,6]  R1738     2.2021479904651642e-01
    z[3,6,6]  R1739     -2.0640711486339569e-01
    z[3,6,6]  R1740     -1.9189366698265076e-01
    z[3,6,6]  R1741     -1.3751919567584991e-01
    z[3,6,6]  R1742     -0.345706045627594
    z[3,6,6]  R1743     2.2112955152988434e-01
    z[3,6,6]  R1744     3.3739423751831055e-01
    z[3,6,6]  R1745     2.9497742652893066e-01
    z[3,6,6]  R1746     -2.0037274062633514e-01
    z[3,6,6]  R1747     2.0725630223751068e-01
    z[3,6,6]  R1748     -2.3145695030689240e-01
    z[3,6,6]  R1749     -5.2521222829818726e-01
    z[3,6,6]  R1750     -1.3092701137065887e-01
    z[3,6,6]  R1751     -1.5891024842858315e-02
    z[3,6,6]  R1752     -9.6572116017341614e-02
    z[3,6,6]  R1753     2.2791130840778351e-01
    z[3,6,6]  R1754     1.6141925752162933e-01
    z[3,6,6]  R1755     3.1756326556205750e-01
    z[3,6,6]  R1756     -4.5917022228240967e-01
    z[3,6,6]  R1757     -3.1051045656204224e-01
    z[3,6,6]  R1758     -1.4357627928256989e-01
    z[3,6,6]  R1759     2.4317464232444763e-01
    z[3,6,6]  R1760     -2.9501739144325256e-01
    z[3,6,6]  R1761     2.4745029211044312e-01
    z[3,6,6]  R1762     8.3945758640766144e-02
    z[3,6,6]  R1763     0.151498481631279
    z[3,6,6]  R1764     4.9973125569522381e-03
    z[3,6,6]  R1765     -3.1996732950210571e-01
    z[3,6,6]  R1766     1.3361082971096039e-01
    z[3,6,6]  R1767     -1.6888926923274994e-01
    z[3,6,6]  R1768     1.0487063229084015e-01
    z[3,6,6]  R1769     -1.3252280652523041e-01
    z[3,6,6]  R1770     -2.5968968868255615e-02
    z[3,6,6]  R1771     1.6199924051761627e-01
    z[3,6,6]  R1772     -1.4860944449901581e-01
    z[3,6,6]  R1773     -2.9217207431793213e-01
    z[3,6,6]  R1774     -1.1926929652690887e-01
    z[3,6,6]  R1775     -4.1505265235900879e-01
    z[3,6,6]  R1776     -0.0943610891699791
    z[3,6,6]  R1777     -6.3995391130447388e-01
    z[3,6,6]  R1778     -1.2046817690134048e-01
    z[6,3,0]  R29       1
    z[6,3,0]  R56       -1
    z[6,3,0]  R1779     -1
    z[6,3,0]  R1780     1
    z[6,3,0]  R1793     -2.6799976825714111e-01
    z[6,3,0]  R1794     -3.0848485231399536e-01
    z[6,3,0]  R1795     -0.502948522567749
    z[6,3,0]  R1796     -4.1463658213615417e-01
    z[6,3,0]  R1797     -4.0166664123535156e-01
    z[6,3,0]  R1798     -6.7071980237960815e-01
    z[6,3,0]  R1799     4.1482448577880859e-01
    z[6,3,0]  R1800     1.3724394142627716e-01
    z[6,3,0]  R1801     1.4065656065940857e-01
    z[6,3,0]  R1802     -1.9479477405548096e-01
    z[6,3,0]  R1803     3.3613452315330505e-01
    z[6,3,0]  R1804     1.0425824671983719e-01
    z[6,3,0]  R1805     0.254373162984848
    z[6,3,0]  R1806     -1.9016842544078827e-01
    z[6,3,0]  R1807     1.0421057045459747e-01
    z[6,3,0]  R1808     5.0094765424728394e-01
    z[6,3,0]  R1809     -4.1455483436584473e-01
    z[6,3,0]  R1810     -1.5327689051628113e-01
    z[6,3,0]  R1811     -7.3224997520446777e-01
    z[6,3,0]  R1812     -4.9367743730545044e-01
    z[6,3,0]  R1813     1.4100821316242218e-01
    z[6,3,0]  R1814     2.1753439307212830e-01
    z[6,3,0]  R1815     -1.2073613703250885e-01
    z[6,3,0]  R1816     -1.8786756694316864e-01
    z[6,3,0]  R1817     -9.2207081615924835e-03
    z[6,3,0]  R1818     2.0490171015262604e-01
    z[6,3,0]  R1819     -4.1622537374496460e-01
    z[6,3,0]  R1820     -0.274004727602005
    z[6,3,0]  R1821     1.6240687668323517e-01
    z[6,3,0]  R1822     -5.9607338905334473e-01
    z[6,3,0]  R1823     -3.1939432024955750e-01
    z[6,3,0]  R1824     -4.3587210774421692e-01
    z[6,3,0]  R1825     4.1314664483070374e-01
    z[6,3,0]  R1826     -1.7168661952018738e-01
    z[6,3,0]  R1827     -0.0768650621175766
    z[6,3,0]  R1828     1.2949213385581970e-01
    z[6,3,0]  R1829     -8.7719194591045380e-02
    z[6,3,0]  R1830     5.6931927800178528e-02
    z[6,3,0]  R1831     5.4856240749359131e-01
    z[6,3,0]  R1832     6.0297280550003052e-01
    z[6,3,0]  R1833     -1.9797690212726593e-01
    z[6,3,0]  R1834     1.5428879298269749e-02
    z[6,3,0]  R1835     1.7626523971557617e-01
    z[6,3,0]  R1836     4.1131421923637390e-01
    z[6,3,0]  R1837     2.3615600541234016e-02
    z[6,3,0]  R1838     5.5942213535308838e-01
    z[6,3,0]  R1839     3.5299485921859741e-01
    z[6,3,0]  R1840     -1.6912724822759628e-02
    z[6,3,0]  R1841     1.3452319800853729e-01
    z[6,3,0]  R1842     2.1778613328933716e-01
    z[6,3,0]  R1843     -2.8781610727310181e-01
    z[6,3,0]  R1844     3.7395498156547546e-01
    z[6,3,0]  R1845     2.0948988199234009e-01
    z[6,3,0]  R1846     1.1307834833860397e-01
    z[6,3,0]  R1847     -1.8201948702335358e-01
    z[6,3,0]  R1848     -2.8810063004493713e-01
    z[6,3,0]  R1849     9.0143084526062012e-01
    z[6,3,0]  R1850     -6.8427008390426636e-01
    z[6,3,0]  R1851     -1.4818302355706692e-02
    z[6,3,0]  R1852     -3.4127944707870483e-01
    z[6,3,0]  R1853     -3.2248872518539429e-01
    z[6,3,0]  R1854     -4.1533282399177551e-01
    z[6,3,0]  R1855     3.2071336172521114e-03
    z[6,3,0]  R1856     -7.8725844621658325e-02
    z[6,3,0]  R1857     -1.8082509934902191e-01
    z[6,3,0]  R1858     -3.0452203750610352e-01
    z[6,3,0]  R1859     2.1030250191688538e-01
    z[6,3,0]  R1860     -0.369750440120697
    z[6,3,0]  R1861     -3.6885312199592590e-01
    z[6,3,0]  R1862     3.4414097666740417e-01
    z[6,3,0]  R1863     -3.8569509983062744e-01
    z[6,3,0]  R1864     -3.7709867954254150e-01
    z[6,3,0]  R1865     -2.5882118940353394e-01
    z[6,3,0]  R1866     5.3064805269241333e-01
    z[6,3,0]  R1867     -4.6140491962432861e-01
    z[6,3,0]  R1868     1.0283546894788742e-01
    z[6,3,0]  R1869     1.1462587118148804e-01
    z[6,3,0]  R1870     2.0582200586795807e-01
    z[6,3,0]  R1871     -1.8039016425609589e-01
    z[6,3,0]  R1872     -1.4154779911041260e-01
    z[6,3,0]  R1873     2.8120434284210205e-01
    z[6,3,0]  R1874     2.1532581746578217e-01
    z[6,3,0]  R1875     -3.2824245095252991e-01
    z[6,3,0]  R1876     3.4028959274291992e-01
    z[6,3,0]  R1877     2.9312244057655334e-01
    z[6,3,0]  R1878     1.1301513016223907e-01
    z[6,3,0]  R1879     2.0777639746665955e-01
    z[6,3,0]  R1880     -4.3527320027351379e-01
    z[6,3,0]  R1881     1.6804765909910202e-02
    z[6,3,0]  R1882     -1.4892593026161194e-01
    z[6,3,0]  R1883     3.1925755739212036e-01
    z[6,3,0]  R1884     -1.5773749351501465e-01
    z[6,3,0]  R1885     -1.5710341930389404e-01
    z[6,3,0]  R1886     -1.9159191846847534e-01
    z[6,3,0]  R1887     -0.639341413974762
    z[6,3,0]  R1888     1.9629706442356110e-01
    z[6,3,0]  R1889     -2.8094035387039185e-01
    z[6,3,1]  R30       1
    z[6,3,1]  R57       -1
    z[6,3,1]  R1781     -1
    z[6,3,1]  R1782     1
    z[6,3,1]  R1793     2.6034945249557495e-01
    z[6,3,1]  R1794     -3.4273234009742737e-01
    z[6,3,1]  R1795     3.3970236778259277e-01
    z[6,3,1]  R1796     0.287553071975708
    z[6,3,1]  R1797     -1.8081579357385635e-02
    z[6,3,1]  R1798     -1.0382114350795746e-01
    z[6,3,1]  R1799     6.3087075948715210e-01
    z[6,3,1]  R1800     6.6886502504348755e-01
    z[6,3,1]  R1801     7.1507990360260010e-01
    z[6,3,1]  R1802     1.6465568542480469e-01
    z[6,3,1]  R1803     -1.9731727242469788e-01
    z[6,3,1]  R1804     2.3253744840621948e-01
    z[6,3,1]  R1805     -1.3593323528766632e-01
    z[6,3,1]  R1806     4.5358244329690933e-02
    z[6,3,1]  R1807     -0.3088398873806
    z[6,3,1]  R1808     -2.1598720923066139e-02
    z[6,3,1]  R1809     -1.5587671659886837e-02
    z[6,3,1]  R1810     -1.1244186758995056e-01
    z[6,3,1]  R1811     -1.2262280285358429e-01
    z[6,3,1]  R1812     -4.1260862350463867e-01
    z[6,3,1]  R1813     -2.0453684031963348e-01
    z[6,3,1]  R1814     1.3772989809513092e-01
    z[6,3,1]  R1815     -3.0731928348541260e-01
    z[6,3,1]  R1816     3.0537009239196777e-01
    z[6,3,1]  R1817     1.7410951852798462e-01
    z[6,3,1]  R1818     5.5265665054321289e-01
    z[6,3,1]  R1819     3.9770871400833130e-01
    z[6,3,1]  R1820     1.5753868967294693e-02
    z[6,3,1]  R1821     -2.0316170156002045e-01
    z[6,3,1]  R1822     -2.0895386114716530e-02
    z[6,3,1]  R1823     3.3721652626991272e-01
    z[6,3,1]  R1824     0.0609736330807209
    z[6,3,1]  R1825     -3.0422195792198181e-01
    z[6,3,1]  R1826     2.3960523307323456e-01
    z[6,3,1]  R1827     5.8998677879571915e-02
    z[6,3,1]  R1828     8.6291587352752686e-01
    z[6,3,1]  R1829     8.5653185844421387e-01
    z[6,3,1]  R1830     8.1906998157501221e-01
    z[6,3,1]  R1831     7.3512208461761475e-01
    z[6,3,1]  R1832     4.4444590806961060e-01
    z[6,3,1]  R1833     -2.5734481215476990e-01
    z[6,3,1]  R1834     3.8917216658592224e-01
    z[6,3,1]  R1835     9.5235210657119751e-01
    z[6,3,1]  R1836     -1.1356313712894917e-02
    z[6,3,1]  R1837     9.0541803836822510e-01
    z[6,3,1]  R1838     5.4022759199142456e-01
    z[6,3,1]  R1839     5.0834619998931885e-01
    z[6,3,1]  R1840     -9.0297651290893555e-01
    z[6,3,1]  R1841     -8.1154477596282959e-01
    z[6,3,1]  R1842     -9.0584987401962280e-01
    z[6,3,1]  R1843     -1.6611185669898987e-01
    z[6,3,1]  R1844     9.2443414032459259e-02
    z[6,3,1]  R1845     3.8873386383056641e-01
    z[6,3,1]  R1846     -6.8229228258132935e-01
    z[6,3,1]  R1847     -3.2924848794937134e-01
    z[6,3,1]  R1848     -2.0766112208366394e-01
    z[6,3,1]  R1849     -1.3121864199638367e-01
    z[6,3,1]  R1850     -5.6477773189544678e-01
    z[6,3,1]  R1851     -7.5187635421752930e-01
    z[6,3,1]  R1852     -6.2260061502456665e-01
    z[6,3,1]  R1853     -4.6212467551231384e-01
    z[6,3,1]  R1854     -3.4248134493827820e-01
    z[6,3,1]  R1855     -5.2284485101699829e-01
    z[6,3,1]  R1856     -5.7583832740783691e-01
    z[6,3,1]  R1857     -0.672904372215271
    z[6,3,1]  R1858     7.6640832424163818e-01
    z[6,3,1]  R1859     8.8993984460830688e-01
    z[6,3,1]  R1860     0.696917712688446
    z[6,3,1]  R1861     7.6524215936660767e-01
    z[6,3,1]  R1862     5.4195505380630493e-01
    z[6,3,1]  R1863     0.670072078704834
    z[6,3,1]  R1864     6.4999777078628540e-01
    z[6,3,1]  R1865     7.1910876035690308e-01
    z[6,3,1]  R1866     2.6219698786735535e-01
    z[6,3,1]  R1867     6.5600740909576416e-01
    z[6,3,1]  R1868     0.321405291557312
    z[6,3,1]  R1869     5.5682206153869629e-01
    z[6,3,1]  R1870     0.855639636516571
    z[6,3,1]  R1871     9.2047715187072754e-01
    z[6,3,1]  R1872     -5.6608009338378906e-01
    z[6,3,1]  R1873     -6.5798693895339966e-01
    z[6,3,1]  R1874     -7.5619047880172729e-01
    z[6,3,1]  R1875     6.1508959531784058e-01
    z[6,3,1]  R1876     -4.8962280154228210e-01
    z[6,3,1]  R1877     5.5734282732009888e-01
    z[6,3,1]  R1878     6.2382537126541138e-01
    z[6,3,1]  R1879     6.9943684339523315e-01
    z[6,3,1]  R1880     -5.6367683410644531e-01
    z[6,3,1]  R1881     7.6815813779830933e-01
    z[6,3,1]  R1882     -7.6969122886657715e-01
    z[6,3,1]  R1883     -7.3696362972259521e-01
    z[6,3,1]  R1884     -9.2049682140350342e-01
    z[6,3,1]  R1885     -7.5868427753448486e-01
    z[6,3,1]  R1886     6.7385560274124146e-01
    z[6,3,1]  R1887     5.2036279439926147e-01
    z[6,3,1]  R1888     0.868614137172699
    z[6,3,1]  R1889     8.1428307294845581e-01
    z[6,3,2]  R31       1
    z[6,3,2]  R58       -1
    z[6,3,2]  R1783     -1
    z[6,3,2]  R1784     1
    z[6,3,2]  R1793     -3.9756676554679871e-01
    z[6,3,2]  R1794     -4.9994894862174988e-01
    z[6,3,2]  R1795     -2.3084443807601929e-01
    z[6,3,2]  R1796     -2.0341536402702332e-01
    z[6,3,2]  R1797     1.1693882942199707e-01
    z[6,3,2]  R1798     8.1346176564693451e-02
    z[6,3,2]  R1799     -2.8455637395381927e-02
    z[6,3,2]  R1800     -4.7480916976928711e-01
    z[6,3,2]  R1801     0.399924099445343
    z[6,3,2]  R1802     -3.5927772521972656e-01
    z[6,3,2]  R1803     -2.6057684421539307e-01
    z[6,3,2]  R1804     7.0517949759960175e-02
    z[6,3,2]  R1805     1.9377246499061584e-01
    z[6,3,2]  R1806     -3.5220120102167130e-02
    z[6,3,2]  R1807     -1.5724499523639679e-01
    z[6,3,2]  R1808     -0.251311331987381
    z[6,3,2]  R1809     -4.4861888885498047e-01
    z[6,3,2]  R1810     8.4616623818874359e-02
    z[6,3,2]  R1811     -4.3666278943419456e-03
    z[6,3,2]  R1812     2.8069657087326050e-01
    z[6,3,2]  R1813     1.4100825786590576e-01
    z[6,3,2]  R1814     -8.8609211146831512e-02
    z[6,3,2]  R1815     -3.8922277092933655e-01
    z[6,3,2]  R1816     -8.1903554499149323e-02
    z[6,3,2]  R1817     -0.564672589302063
    z[6,3,2]  R1818     -3.1437207013368607e-02
    z[6,3,2]  R1819     -1.1584430932998657e-01
    z[6,3,2]  R1820     -2.2531510889530182e-01
    z[6,3,2]  R1821     2.7839755639433861e-03
    z[6,3,2]  R1822     -5.0746973603963852e-02
    z[6,3,2]  R1823     -2.3050782084465027e-01
    z[6,3,2]  R1824     2.4781459942460060e-02
    z[6,3,2]  R1825     -6.3811242580413818e-02
    z[6,3,2]  R1826     -8.2455776631832123e-02
    z[6,3,2]  R1827     -2.8026726841926575e-01
    z[6,3,2]  R1828     7.1502029895782471e-02
    z[6,3,2]  R1829     2.1758085489273071e-01
    z[6,3,2]  R1830     3.5238778591156006e-01
    z[6,3,2]  R1831     -1.8645766377449036e-01
    z[6,3,2]  R1832     3.1171867251396179e-01
    z[6,3,2]  R1833     -3.9491170644760132e-01
    z[6,3,2]  R1834     1.6960716247558594e-01
    z[6,3,2]  R1835     -1.4601002633571625e-01
    z[6,3,2]  R1836     -4.1508537530899048e-01
    z[6,3,2]  R1837     2.7347663044929504e-01
    z[6,3,2]  R1838     2.0718546211719513e-01
    z[6,3,2]  R1839     3.8754299283027649e-01
    z[6,3,2]  R1840     7.2244450449943542e-02
    z[6,3,2]  R1841     0.145552858710289
    z[6,3,2]  R1842     5.7123210281133652e-02
    z[6,3,2]  R1843     -3.3237934112548828e-01
    z[6,3,2]  R1844     -3.8678976893424988e-01
    z[6,3,2]  R1845     5.5587112903594971e-01
    z[6,3,2]  R1846     -3.4621194005012512e-02
    z[6,3,2]  R1847     -0.0864488035440445
    z[6,3,2]  R1848     -1.7532606422901154e-01
    z[6,3,2]  R1849     -0.0704229474067688
    z[6,3,2]  R1850     -1.5577442944049835e-01
    z[6,3,2]  R1851     -6.0458236932754517e-01
    z[6,3,2]  R1852     -5.1972138881683350e-01
    z[6,3,2]  R1853     -3.8542884588241577e-01
    z[6,3,2]  R1854     -4.9501702189445496e-01
    z[6,3,2]  R1855     -3.6971840262413025e-01
    z[6,3,2]  R1856     -0.673039972782135
    z[6,3,2]  R1857     7.3226056993007660e-02
    z[6,3,2]  R1858     -3.3864775300025940e-01
    z[6,3,2]  R1859     -1.6483345627784729e-01
    z[6,3,2]  R1860     4.4338285923004150e-01
    z[6,3,2]  R1861     2.1244935691356659e-01
    z[6,3,2]  R1862     4.1812750697135925e-01
    z[6,3,2]  R1863     3.2986089587211609e-01
    z[6,3,2]  R1864     7.5422719120979309e-02
    z[6,3,2]  R1865     -1.8810895085334778e-01
    z[6,3,2]  R1866     4.7620362043380737e-01
    z[6,3,2]  R1867     3.8832318782806396e-01
    z[6,3,2]  R1868     6.0331451892852783e-01
    z[6,3,2]  R1869     4.2715713381767273e-01
    z[6,3,2]  R1870     1.9687317311763763e-01
    z[6,3,2]  R1871     1.8519483506679535e-01
    z[6,3,2]  R1872     -0.0568130724132061
    z[6,3,2]  R1873     -1.6443207859992981e-01
    z[6,3,2]  R1874     1.1148890107870102e-01
    z[6,3,2]  R1875     1.9072158634662628e-01
    z[6,3,2]  R1876     -0.0665467232465744
    z[6,3,2]  R1877     4.0483516454696655e-01
    z[6,3,2]  R1878     3.5350584983825684e-01
    z[6,3,2]  R1879     1.7171221971511841e-01
    z[6,3,2]  R1880     -1.9684784114360809e-01
    z[6,3,2]  R1881     7.5926974415779114e-02
    z[6,3,2]  R1882     -3.3008918166160583e-01
    z[6,3,2]  R1883     -3.6259409785270691e-01
    z[6,3,2]  R1884     1.0326393693685532e-01
    z[6,3,2]  R1885     -3.9868235588073730e-02
    z[6,3,2]  R1886     -6.3102908432483673e-02
    z[6,3,2]  R1887     -0.0151675371453166
    z[6,3,2]  R1888     -1.6450341045856476e-01
    z[6,3,2]  R1889     8.5549578070640564e-02
    z[6,3,3]  R32       1
    z[6,3,3]  R59       -1
    z[6,3,3]  R1785     -1
    z[6,3,3]  R1786     1
    z[6,3,3]  R1793     6.5393263101577759e-01
    z[6,3,3]  R1794     5.0959396362304688e-01
    z[6,3,3]  R1795     4.0262740850448608e-01
    z[6,3,3]  R1796     0.0463026687502861
    z[6,3,3]  R1797     -7.2940096259117126e-02
    z[6,3,3]  R1798     2.8767937421798706e-01
    z[6,3,3]  R1799     -0.0512276254594326
    z[6,3,3]  R1800     -7.1023985743522644e-02
    z[6,3,3]  R1801     -3.7454909086227417e-01
    z[6,3,3]  R1802     -7.4034363031387329e-02
    z[6,3,3]  R1803     -3.3794444799423218e-01
    z[6,3,3]  R1804     -2.8308334946632385e-01
    z[6,3,3]  R1805     -0.391967236995697
    z[6,3,3]  R1806     -2.7441471815109253e-01
    z[6,3,3]  R1807     -3.5618439316749573e-01
    z[6,3,3]  R1808     -4.3386444449424744e-01
    z[6,3,3]  R1809     -2.6035135984420776e-01
    z[6,3,3]  R1810     -3.7802201509475708e-01
    z[6,3,3]  R1811     -3.1466564536094666e-01
    z[6,3,3]  R1812     -2.4095329642295837e-01
    z[6,3,3]  R1813     -6.8053388595581055e-01
    z[6,3,3]  R1814     -7.2847908735275269e-01
    z[6,3,3]  R1815     -7.1762156486511230e-01
    z[6,3,3]  R1816     -6.7181175947189331e-01
    z[6,3,3]  R1817     -7.5338131189346313e-01
    z[6,3,3]  R1818     -6.4652174711227417e-01
    z[6,3,3]  R1819     -6.3391441106796265e-01
    z[6,3,3]  R1820     -5.2807462215423584e-01
    z[6,3,3]  R1821     -6.9509744644165039e-01
    z[6,3,3]  R1822     -7.5340855121612549e-01
    z[6,3,3]  R1823     -6.3471955060958862e-01
    z[6,3,3]  R1824     -7.7655339241027832e-01
    z[6,3,3]  R1825     -6.2197327613830566e-01
    z[6,3,3]  R1826     -6.6663116216659546e-01
    z[6,3,3]  R1827     -5.9071314334869385e-01
    z[6,3,3]  R1828     2.1089186891913414e-02
    z[6,3,3]  R1829     4.1512794792652130e-02
    z[6,3,3]  R1830     -3.4831660985946655e-01
    z[6,3,3]  R1831     -3.0824735760688782e-02
    z[6,3,3]  R1832     -5.2167940139770508e-01
    z[6,3,3]  R1833     -4.0444770455360413e-01
    z[6,3,3]  R1834     -8.0958712100982666e-01
    z[6,3,3]  R1835     -1.7638245224952698e-01
    z[6,3,3]  R1836     -4.1537594795227051e-01
    z[6,3,3]  R1837     -1.8703933060169220e-01
    z[6,3,3]  R1838     -5.4770672321319580e-01
    z[6,3,3]  R1839     -5.7849675416946411e-01
    z[6,3,3]  R1840     -2.0557032525539398e-01
    z[6,3,3]  R1841     -4.5151209831237793e-01
    z[6,3,3]  R1842     -2.2021782398223877e-01
    z[6,3,3]  R1843     -8.3125251531600952e-01
    z[6,3,3]  R1844     -0.372031033039093
    z[6,3,3]  R1845     -0.626023530960083
    z[6,3,3]  R1846     -3.2117596268653870e-01
    z[6,3,3]  R1847     4.4315099716186523e-01
    z[6,3,3]  R1848     3.2139471173286438e-01
    z[6,3,3]  R1849     2.2495168447494507e-01
    z[6,3,3]  R1850     -9.7489524632692337e-03
    z[6,3,3]  R1851     -1.8885856866836548e-01
    z[6,3,3]  R1852     2.1941512823104858e-01
    z[6,3,3]  R1853     1.1851963587105274e-02
    z[6,3,3]  R1854     -5.8438103646039963e-02
    z[6,3,3]  R1855     0.045077845454216
    z[6,3,3]  R1856     3.5778489708900452e-01
    z[6,3,3]  R1857     5.2593439817428589e-01
    z[6,3,3]  R1858     8.0375157296657562e-02
    z[6,3,3]  R1859     3.9720643311738968e-02
    z[6,3,3]  R1860     -3.7784284353256226e-01
    z[6,3,3]  R1861     1.4121010899543762e-01
    z[6,3,3]  R1862     -4.6531671285629272e-01
    z[6,3,3]  R1863     -1.1461026966571808e-02
    z[6,3,3]  R1864     -3.4973528236150742e-02
    z[6,3,3]  R1865     1.7360763251781464e-01
    z[6,3,3]  R1866     -5.9369200468063354e-01
    z[6,3,3]  R1867     5.9511110186576843e-02
    z[6,3,3]  R1868     -6.6745573282241821e-01
    z[6,3,3]  R1869     -5.3625065833330154e-02
    z[6,3,3]  R1870     -5.7023368775844574e-02
    z[6,3,3]  R1871     1.3739582896232605e-01
    z[6,3,3]  R1872     1.2602323293685913e-01
    z[6,3,3]  R1873     1.6580019891262054e-01
    z[6,3,3]  R1874     4.8164751380681992e-02
    z[6,3,3]  R1875     -1.5695963799953461e-01
    z[6,3,3]  R1876     5.0392758846282959e-01
    z[6,3,3]  R1877     -4.8290807008743286e-01
    z[6,3,3]  R1878     -4.1087540984153748e-01
    z[6,3,3]  R1879     -2.4842780828475952e-01
    z[6,3,3]  R1880     4.7737839818000793e-01
    z[6,3,3]  R1881     -3.4771889448165894e-01
    z[6,3,3]  R1882     3.4257954359054565e-01
    z[6,3,3]  R1883     0.376578152179718
    z[6,3,3]  R1884     -0.270519495010376
    z[6,3,3]  R1885     9.1828359290957451e-03
    z[6,3,3]  R1886     -9.3843534588813782e-02
    z[6,3,3]  R1887     1.2134262919425964e-01
    z[6,3,3]  R1888     1.5632796287536621e-01
    z[6,3,3]  R1889     1.5583147108554840e-01
    z[6,3,4]  R33       1
    z[6,3,4]  R60       -1
    z[6,3,4]  R1787     -1
    z[6,3,4]  R1788     1
    z[6,3,4]  R1793     -3.6099845170974731e-01
    z[6,3,4]  R1794     -5.0128477811813354e-01
    z[6,3,4]  R1795     -2.4232718348503113e-01
    z[6,3,4]  R1796     -6.2378132343292236e-01
    z[6,3,4]  R1797     -7.6530051231384277e-01
    z[6,3,4]  R1798     -8.2309916615486145e-02
    z[6,3,4]  R1799     5.0870066881179810e-01
    z[6,3,4]  R1800     5.2494859695434570e-01
    z[6,3,4]  R1801     2.2784644365310669e-01
    z[6,3,4]  R1802     6.3623136281967163e-01
    z[6,3,4]  R1803     6.6906195878982544e-01
    z[6,3,4]  R1804     0.715188205242157
    z[6,3,4]  R1805     8.1924271583557129e-01
    z[6,3,4]  R1806     7.3967492580413818e-01
    z[6,3,4]  R1807     4.9545809626579285e-01
    z[6,3,4]  R1808     6.3771128654479980e-01
    z[6,3,4]  R1809     6.3362246751785278e-01
    z[6,3,4]  R1810     1.2641207873821259e-01
    z[6,3,4]  R1811     4.4084584712982178e-01
    z[6,3,4]  R1812     5.3377324342727661e-01
    z[6,3,4]  R1813     5.4180890321731567e-01
    z[6,3,4]  R1814     1.1982502788305283e-01
    z[6,3,4]  R1815     3.1549152731895447e-01
    z[6,3,4]  R1816     1.6357085108757019e-01
    z[6,3,4]  R1817     2.0659507811069489e-01
    z[6,3,4]  R1818     3.2729476690292358e-01
    z[6,3,4]  R1819     3.3463621139526367e-01
    z[6,3,4]  R1820     5.3437018394470215e-01
    z[6,3,4]  R1821     5.3751307725906372e-01
    z[6,3,4]  R1822     2.0646791160106659e-01
    z[6,3,4]  R1823     4.4832786917686462e-01
    z[6,3,4]  R1824     2.7401667833328247e-01
    z[6,3,4]  R1825     5.2053558826446533e-01
    z[6,3,4]  R1826     5.4928040504455566e-01
    z[6,3,4]  R1827     1.5408772230148315e-01
    z[6,3,4]  R1828     2.7578663825988770e-01
    z[6,3,4]  R1829     3.2866501808166504e-01
    z[6,3,4]  R1830     -1.2901960313320160e-01
    z[6,3,4]  R1831     0.0457758866250515
    z[6,3,4]  R1832     -2.8694493696093559e-02
    z[6,3,4]  R1833     7.3351776599884033e-01
    z[6,3,4]  R1834     0.338083416223526
    z[6,3,4]  R1835     0.0929412767291069
    z[6,3,4]  R1836     6.1885702610015869e-01
    z[6,3,4]  R1837     -1.6371940076351166e-01
    z[6,3,4]  R1838     -0.0817561224102974
    z[6,3,4]  R1839     -0.0737539529800415
    z[6,3,4]  R1840     2.4493876099586487e-01
    z[6,3,4]  R1841     -6.9230049848556519e-02
    z[6,3,4]  R1842     1.8002241849899292e-01
    z[6,3,4]  R1843     2.5551870465278625e-01
    z[6,3,4]  R1844     6.9033432006835938e-01
    z[6,3,4]  R1845     2.9557922482490540e-01
    z[6,3,4]  R1846     1.9327664747834206e-02
    z[6,3,4]  R1847     7.8321486711502075e-01
    z[6,3,4]  R1848     5.0879049301147461e-01
    z[6,3,4]  R1849     2.1860572695732117e-01
    z[6,3,4]  R1850     3.0825203657150269e-01
    z[6,3,4]  R1851     0.101965993642807
    z[6,3,4]  R1852     -7.2813339531421661e-02
    z[6,3,4]  R1853     5.3983730077743530e-01
    z[6,3,4]  R1854     2.6378706097602844e-01
    z[6,3,4]  R1855     5.3849774599075317e-01
    z[6,3,4]  R1856     1.8499688804149628e-01
    z[6,3,4]  R1857     1.7156605422496796e-01
    z[6,3,4]  R1858     5.0421640276908875e-02
    z[6,3,4]  R1859     0.0775560736656189
    z[6,3,4]  R1860     9.6017621457576752e-02
    z[6,3,4]  R1861     -0.452067106962204
    z[6,3,4]  R1862     1.6617333889007568e-01
    z[6,3,4]  R1863     -1.8061715364456177e-01
    z[6,3,4]  R1864     7.5188815593719482e-02
    z[6,3,4]  R1865     -2.5747114419937134e-01
    z[6,3,4]  R1866     6.2724113464355469e-02
    z[6,3,4]  R1867     -7.3110930621623993e-02
    z[6,3,4]  R1868     1.9055263698101044e-01
    z[6,3,4]  R1869     -3.1058004498481750e-01
    z[6,3,4]  R1870     -2.2223468124866486e-01
    z[6,3,4]  R1871     -1.9229148328304291e-01
    z[6,3,4]  R1872     -5.6604868173599243e-01
    z[6,3,4]  R1873     -2.6208677887916565e-01
    z[6,3,4]  R1874     -5.1472359895706177e-01
    z[6,3,4]  R1875     -2.4435704946517944e-01
    z[6,3,4]  R1876     -4.8377969861030579e-01
    z[6,3,4]  R1877     -2.3590198159217834e-01
    z[6,3,4]  R1878     0.509386420249939
    z[6,3,4]  R1879     -4.3700519204139709e-01
    z[6,3,4]  R1880     -2.1561256051063538e-01
    z[6,3,4]  R1881     -1.8238714337348938e-01
    z[6,3,4]  R1882     -2.8487563133239746e-01
    z[6,3,4]  R1883     -5.8203574270009995e-02
    z[6,3,4]  R1884     4.1803520172834396e-02
    z[6,3,4]  R1885     1.7025732994079590e-01
    z[6,3,4]  R1886     -2.4461135268211365e-01
    z[6,3,4]  R1887     -1.7198120057582855e-01
    z[6,3,4]  R1888     1.3553853332996368e-01
    z[6,3,4]  R1889     3.7733739614486694e-01
    z[6,3,5]  R34       1
    z[6,3,5]  R61       -1
    z[6,3,5]  R1789     -1
    z[6,3,5]  R1790     1
    z[6,3,5]  R1793     -0.018271429464221
    z[6,3,5]  R1794     1.4349387586116791e-01
    z[6,3,5]  R1795     5.8392512798309326e-01
    z[6,3,5]  R1796     2.1635049581527710e-01
    z[6,3,5]  R1797     -1.1129476875066757e-01
    z[6,3,5]  R1798     5.4812282323837280e-01
    z[6,3,5]  R1799     1.7855556309223175e-01
    z[6,3,5]  R1800     3.8373034447431564e-02
    z[6,3,5]  R1801     3.3966964483261108e-01
    z[6,3,5]  R1802     -1.1695603281259537e-01
    z[6,3,5]  R1803     -4.6720793843269348e-01
    z[6,3,5]  R1804     -5.8165037631988525e-01
    z[6,3,5]  R1805     -1.4780853688716888e-01
    z[6,3,5]  R1806     -4.4981312751770020e-01
    z[6,3,5]  R1807     -5.9563565254211426e-01
    z[6,3,5]  R1808     -4.4312477111816406e-02
    z[6,3,5]  R1809     -3.2998120784759521e-01
    z[6,3,5]  R1810     -8.6903309822082520e-01
    z[6,3,5]  R1811     -3.4434261918067932e-01
    z[6,3,5]  R1812     -3.8126403093338013e-01
    z[6,3,5]  R1813     -2.0543164014816284e-01
    z[6,3,5]  R1814     -5.7612472772598267e-01
    z[6,3,5]  R1815     -1.0551296174526215e-01
    z[6,3,5]  R1816     -5.4740172624588013e-01
    z[6,3,5]  R1817     1.8206527456641197e-02
    z[6,3,5]  R1818     -2.8901594877243042e-01
    z[6,3,5]  R1819     -2.9624858498573303e-01
    z[6,3,5]  R1820     -1.8342342972755432e-01
    z[6,3,5]  R1821     3.7831076979637146e-01
    z[6,3,5]  R1822     1.7657433450222015e-01
    z[6,3,5]  R1823     -3.4343191981315613e-01
    z[6,3,5]  R1824     -2.7499023079872131e-01
    z[6,3,5]  R1825     -2.2095876932144165e-01
    z[6,3,5]  R1826     2.4364241957664490e-01
    z[6,3,5]  R1827     -5.7318305969238281e-01
    z[6,3,5]  R1828     -2.4612143635749817e-01
    z[6,3,5]  R1829     -2.8453272581100464e-01
    z[6,3,5]  R1830     0.06783477216959
    z[6,3,5]  R1831     1.8392252922058105e-01
    z[6,3,5]  R1832     -8.6709603667259216e-02
    z[6,3,5]  R1833     -1.7306198179721832e-01
    z[6,3,5]  R1834     1.6388094425201416e-01
    z[6,3,5]  R1835     2.9382398352026939e-02
    z[6,3,5]  R1836     2.2259229794144630e-02
    z[6,3,5]  R1837     -1.5884411334991455e-01
    z[6,3,5]  R1838     1.3070951402187347e-01
    z[6,3,5]  R1839     3.4013697504997253e-01
    z[6,3,5]  R1840     2.4353970587253571e-01
    z[6,3,5]  R1841     3.0460250377655029e-01
    z[6,3,5]  R1842     1.4695046842098236e-01
    z[6,3,5]  R1843     -2.7154510840773582e-02
    z[6,3,5]  R1844     -4.0896151214838028e-02
    z[6,3,5]  R1845     -5.0095748156309128e-02
    z[6,3,5]  R1846     4.9466714262962341e-01
    z[6,3,5]  R1847     -1.7966248095035553e-01
    z[6,3,5]  R1848     -2.6726812124252319e-01
    z[6,3,5]  R1849     -2.2878044843673706e-01
    z[6,3,5]  R1850     0.288438618183136
    z[6,3,5]  R1851     7.3415338993072510e-02
    z[6,3,5]  R1852     3.1598886847496033e-01
    z[6,3,5]  R1853     2.9113727807998657e-01
    z[6,3,5]  R1854     5.9622806310653687e-01
    z[6,3,5]  R1855     3.8937801122665405e-01
    z[6,3,5]  R1856     1.0548871755599976e-01
    z[6,3,5]  R1857     -3.0654066801071167e-01
    z[6,3,5]  R1858     -1.3580715656280518e-01
    z[6,3,5]  R1859     2.7249258756637573e-01
    z[6,3,5]  R1860     -1.0735871642827988e-01
    z[6,3,5]  R1861     -5.4265994578599930e-02
    z[6,3,5]  R1862     -4.0690630674362183e-01
    z[6,3,5]  R1863     -5.0688081979751587e-01
    z[6,3,5]  R1864     -3.9016571640968323e-01
    z[6,3,5]  R1865     2.6489531993865967e-01
    z[6,3,5]  R1866     -2.3758928477764130e-01
    z[6,3,5]  R1867     -1.5222407877445221e-01
    z[6,3,5]  R1868     -1.7769478261470795e-01
    z[6,3,5]  R1869     -5.3262615203857422e-01
    z[6,3,5]  R1870     -3.4445360302925110e-01
    z[6,3,5]  R1871     -2.3536950349807739e-02
    z[6,3,5]  R1872     -4.9152320623397827e-01
    z[6,3,5]  R1873     -3.7724217772483826e-01
    z[6,3,5]  R1874     -8.8155664503574371e-02
    z[6,3,5]  R1875     6.2642043828964233e-01
    z[6,3,5]  R1876     9.6060521900653839e-02
    z[6,3,5]  R1877     3.6358323693275452e-01
    z[6,3,5]  R1878     1.1877653747797012e-01
    z[6,3,5]  R1879     4.1252571344375610e-01
    z[6,3,5]  R1880     -2.3521672189235687e-01
    z[6,3,5]  R1881     3.4173348546028137e-01
    z[6,3,5]  R1882     -2.1266996860504150e-01
    z[6,3,5]  R1883     1.3347616791725159e-01
    z[6,3,5]  R1884     -1.7888711392879486e-01
    z[6,3,5]  R1885     -5.8507549762725830e-01
    z[6,3,5]  R1886     3.9482930302619934e-01
    z[6,3,5]  R1887     -1.5781989693641663e-01
    z[6,3,5]  R1888     3.6871945858001709e-01
    z[6,3,5]  R1889     -2.8889900445938110e-01
    z[6,3,6]  R35       1
    z[6,3,6]  R62       -1
    z[6,3,6]  R1791     -1
    z[6,3,6]  R1792     1
    z[6,3,6]  R1793     3.7954360246658325e-01
    z[6,3,6]  R1794     7.6548673212528229e-02
    z[6,3,6]  R1795     -1.2867036461830139e-01
    z[6,3,6]  R1796     -5.1571053266525269e-01
    z[6,3,6]  R1797     4.7039404511451721e-01
    z[6,3,6]  R1798     3.7784385681152344e-01
    z[6,3,6]  R1799     -3.6855155229568481e-01
    z[6,3,6]  R1800     -1.6202476620674133e-01
    z[6,3,6]  R1801     -3.6887574940919876e-02
    z[6,3,6]  R1802     -6.1799097061157227e-01
    z[6,3,6]  R1803     -6.7602782510221004e-03
    z[6,3,6]  R1804     -1.1672931723296642e-02
    z[6,3,6]  R1805     1.8062233924865723e-01
    z[6,3,6]  R1806     0.368488609790802
    z[6,3,6]  R1807     3.7670186161994934e-01
    z[6,3,6]  R1808     2.9757311940193176e-01
    z[6,3,6]  R1809     2.2021479904651642e-01
    z[6,3,6]  R1810     -2.0640711486339569e-01
    z[6,3,6]  R1811     -1.9189366698265076e-01
    z[6,3,6]  R1812     -1.3751919567584991e-01
    z[6,3,6]  R1813     -0.345706045627594
    z[6,3,6]  R1814     2.2112955152988434e-01
    z[6,3,6]  R1815     3.3739423751831055e-01
    z[6,3,6]  R1816     2.9497742652893066e-01
    z[6,3,6]  R1817     -2.0037274062633514e-01
    z[6,3,6]  R1818     2.0725630223751068e-01
    z[6,3,6]  R1819     -2.3145695030689240e-01
    z[6,3,6]  R1820     -5.2521222829818726e-01
    z[6,3,6]  R1821     -1.3092701137065887e-01
    z[6,3,6]  R1822     -1.5891024842858315e-02
    z[6,3,6]  R1823     -9.6572116017341614e-02
    z[6,3,6]  R1824     2.2791130840778351e-01
    z[6,3,6]  R1825     1.6141925752162933e-01
    z[6,3,6]  R1826     3.1756326556205750e-01
    z[6,3,6]  R1827     -4.5917022228240967e-01
    z[6,3,6]  R1828     -3.1051045656204224e-01
    z[6,3,6]  R1829     -1.4357627928256989e-01
    z[6,3,6]  R1830     2.4317464232444763e-01
    z[6,3,6]  R1831     -2.9501739144325256e-01
    z[6,3,6]  R1832     2.4745029211044312e-01
    z[6,3,6]  R1833     8.3945758640766144e-02
    z[6,3,6]  R1834     0.151498481631279
    z[6,3,6]  R1835     4.9973125569522381e-03
    z[6,3,6]  R1836     -3.1996732950210571e-01
    z[6,3,6]  R1837     1.3361082971096039e-01
    z[6,3,6]  R1838     -1.6888926923274994e-01
    z[6,3,6]  R1839     1.0487063229084015e-01
    z[6,3,6]  R1840     -1.3252280652523041e-01
    z[6,3,6]  R1841     -2.5968968868255615e-02
    z[6,3,6]  R1842     1.6199924051761627e-01
    z[6,3,6]  R1843     -1.4860944449901581e-01
    z[6,3,6]  R1844     -2.9217207431793213e-01
    z[6,3,6]  R1845     -1.1926929652690887e-01
    z[6,3,6]  R1846     -4.1505265235900879e-01
    z[6,3,6]  R1847     -0.0943610891699791
    z[6,3,6]  R1848     -6.3995391130447388e-01
    z[6,3,6]  R1849     -1.2046817690134048e-01
    z[6,3,6]  R1850     -1.0111232101917267e-01
    z[6,3,6]  R1851     1.3224272429943085e-01
    z[6,3,6]  R1852     2.6924493908882141e-01
    z[6,3,6]  R1853     3.9693927764892578e-01
    z[6,3,6]  R1854     1.9151189923286438e-01
    z[6,3,6]  R1855     -3.8249734044075012e-01
    z[6,3,6]  R1856     -1.8938811123371124e-01
    z[6,3,6]  R1857     -3.3034953474998474e-01
    z[6,3,6]  R1858     -4.2161145806312561e-01
    z[6,3,6]  R1859     -2.3401927947998047e-01
    z[6,3,6]  R1860     1.3225534558296204e-01
    z[6,3,6]  R1861     -7.7248126268386841e-02
    z[6,3,6]  R1862     5.7576749473810196e-02
    z[6,3,6]  R1863     6.1256840825080872e-02
    z[6,3,6]  R1864     5.2010113000869751e-01
    z[6,3,6]  R1865     4.6250253915786743e-01
    z[6,3,6]  R1866     -1.0021121054887772e-01
    z[6,3,6]  R1867     -4.1702026128768921e-01
    z[6,3,6]  R1868     -9.3552783131599426e-02
    z[6,3,6]  R1869     -3.3364757895469666e-01
    z[6,3,6]  R1870     1.2438180297613144e-01
    z[6,3,6]  R1871     -1.7168733477592468e-01
    z[6,3,6]  R1872     2.8000321984291077e-01
    z[6,3,6]  R1873     4.7164449095726013e-01
    z[6,3,6]  R1874     3.0716332793235779e-01
    z[6,3,6]  R1875     -2.8244480490684509e-02
    z[6,3,6]  R1876     3.7792941927909851e-01
    z[6,3,6]  R1877     -1.3606618344783783e-01
    z[6,3,6]  R1878     -1.7522041499614716e-01
    z[6,3,6]  R1879     1.2355015426874161e-01
    z[6,3,6]  R1880     3.5263389348983765e-01
    z[6,3,6]  R1881     -3.6459651589393616e-01
    z[6,3,6]  R1882     1.8081568181514740e-01
    z[6,3,6]  R1883     2.4590662121772766e-01
    z[6,3,6]  R1884     1.0105468332767487e-01
    z[6,3,6]  R1885     0.163529634475708
    z[6,3,6]  R1886     5.2980917692184448e-01
    z[6,3,6]  R1887     5.0102514028549194e-01
    z[6,3,6]  R1888     3.3948723226785660e-02
    z[6,3,6]  R1889     -2.3816585540771484e-02
    z[3,7,0]  R29       -1
    z[3,7,0]  R65       1
    z[3,7,0]  R1890     -1
    z[3,7,0]  R1891     1
    z[3,7,0]  R1904     -6.8427008390426636e-01
    z[3,7,0]  R1905     -1.4818302355706692e-02
    z[3,7,0]  R1906     -3.4127944707870483e-01
    z[3,7,0]  R1907     -3.2248872518539429e-01
    z[3,7,0]  R1908     -4.1533282399177551e-01
    z[3,7,0]  R1909     3.2071336172521114e-03
    z[3,7,0]  R1910     -7.8725844621658325e-02
    z[3,7,0]  R1911     -1.8082509934902191e-01
    z[3,7,0]  R1912     -3.0452203750610352e-01
    z[3,7,0]  R1913     2.1030250191688538e-01
    z[3,7,0]  R1914     -0.369750440120697
    z[3,7,0]  R1915     -3.6885312199592590e-01
    z[3,7,0]  R1916     3.4414097666740417e-01
    z[3,7,0]  R1917     -3.8569509983062744e-01
    z[3,7,0]  R1918     -3.7709867954254150e-01
    z[3,7,0]  R1919     -2.5882118940353394e-01
    z[3,7,0]  R1920     5.3064805269241333e-01
    z[3,7,0]  R1921     -4.6140491962432861e-01
    z[3,7,0]  R1922     1.0283546894788742e-01
    z[3,7,0]  R1923     1.1462587118148804e-01
    z[3,7,0]  R1924     2.0582200586795807e-01
    z[3,7,0]  R1925     -1.8039016425609589e-01
    z[3,7,0]  R1926     -1.4154779911041260e-01
    z[3,7,0]  R1927     2.8120434284210205e-01
    z[3,7,0]  R1928     2.1532581746578217e-01
    z[3,7,0]  R1929     -3.2824245095252991e-01
    z[3,7,0]  R1930     3.4028959274291992e-01
    z[3,7,0]  R1931     2.9312244057655334e-01
    z[3,7,0]  R1932     1.1301513016223907e-01
    z[3,7,0]  R1933     2.0777639746665955e-01
    z[3,7,0]  R1934     -4.3527320027351379e-01
    z[3,7,0]  R1935     1.6804765909910202e-02
    z[3,7,0]  R1936     -1.4892593026161194e-01
    z[3,7,0]  R1937     3.1925755739212036e-01
    z[3,7,0]  R1938     -1.5773749351501465e-01
    z[3,7,0]  R1939     -1.5710341930389404e-01
    z[3,7,0]  R1940     -1.9159191846847534e-01
    z[3,7,0]  R1941     -0.639341413974762
    z[3,7,0]  R1942     1.9629706442356110e-01
    z[3,7,0]  R1943     -2.8094035387039185e-01
    z[3,7,0]  R1944     -2.1621994674205780e-01
    z[3,7,0]  R1945     -4.5511227846145630e-01
    z[3,7,0]  R1946     1.1857293546199799e-01
    z[3,7,0]  R1947     -2.6836407184600830e-01
    z[3,7,0]  R1948     -6.1877554655075073e-01
    z[3,7,0]  R1949     -5.6078499555587769e-01
    z[3,7,0]  R1950     -4.8424881696701050e-01
    z[3,7,0]  R1951     -0.493665486574173
    z[3,7,0]  R1952     -6.5295916795730591e-01
    z[3,7,0]  R1953     -5.0218790769577026e-01
    z[3,7,0]  R1954     4.4836950302124023e-01
    z[3,7,0]  R1955     3.7923336029052734e-01
    z[3,7,0]  R1956     3.2009416818618774e-01
    z[3,7,0]  R1957     4.2270222306251526e-01
    z[3,7,0]  R1958     3.3594289422035217e-01
    z[3,7,0]  R1959     0.368246465921402
    z[3,7,0]  R1960     4.5081678032875061e-01
    z[3,7,0]  R1961     4.2248663306236267e-01
    z[3,7,0]  R1962     3.4102728962898254e-01
    z[3,7,0]  R1963     2.0220804214477539e-01
    z[3,7,0]  R1964     -2.8328239917755127e-01
    z[3,7,0]  R1965     -1.7455467581748962e-01
    z[3,7,0]  R1966     -1.4616841077804565e-01
    z[3,7,0]  R1967     2.8160439804196358e-02
    z[3,7,0]  R1968     1.1431477218866348e-01
    z[3,7,0]  R1969     1.0720545798540115e-01
    z[3,7,0]  R1970     2.2843575105071068e-02
    z[3,7,0]  R1971     -2.9791104793548584e-01
    z[3,7,0]  R1972     -2.2452485561370850e-01
    z[3,7,0]  R1973     5.9810775518417358e-01
    z[3,7,0]  R1974     8.8973073288798332e-03
    z[3,7,0]  R1975     -9.1658718883991241e-02
    z[3,7,0]  R1976     1.0764811933040619e-01
    z[3,7,0]  R1977     -2.6607245206832886e-01
    z[3,7,0]  R1978     -4.6468096971511841e-01
    z[3,7,0]  R1979     9.6932905912399292e-01
    z[3,7,0]  R1980     9.6469402313232422e-01
    z[3,7,0]  R1981     9.1660410165786743e-01
    z[3,7,0]  R1982     0.891918957233429
    z[3,7,0]  R1983     8.0443078279495239e-01
    z[3,7,1]  R30       -1
    z[3,7,1]  R66       1
    z[3,7,1]  R1892     -1
    z[3,7,1]  R1893     1
    z[3,7,1]  R1904     -5.6477773189544678e-01
    z[3,7,1]  R1905     -7.5187635421752930e-01
    z[3,7,1]  R1906     -6.2260061502456665e-01
    z[3,7,1]  R1907     -4.6212467551231384e-01
    z[3,7,1]  R1908     -3.4248134493827820e-01
    z[3,7,1]  R1909     -5.2284485101699829e-01
    z[3,7,1]  R1910     -5.7583832740783691e-01
    z[3,7,1]  R1911     -0.672904372215271
    z[3,7,1]  R1912     7.6640832424163818e-01
    z[3,7,1]  R1913     8.8993984460830688e-01
    z[3,7,1]  R1914     0.696917712688446
    z[3,7,1]  R1915     7.6524215936660767e-01
    z[3,7,1]  R1916     5.4195505380630493e-01
    z[3,7,1]  R1917     0.670072078704834
    z[3,7,1]  R1918     6.4999777078628540e-01
    z[3,7,1]  R1919     7.1910876035690308e-01
    z[3,7,1]  R1920     2.6219698786735535e-01
    z[3,7,1]  R1921     6.5600740909576416e-01
    z[3,7,1]  R1922     0.321405291557312
    z[3,7,1]  R1923     5.5682206153869629e-01
    z[3,7,1]  R1924     0.855639636516571
    z[3,7,1]  R1925     9.2047715187072754e-01
    z[3,7,1]  R1926     -5.6608009338378906e-01
    z[3,7,1]  R1927     -6.5798693895339966e-01
    z[3,7,1]  R1928     -7.5619047880172729e-01
    z[3,7,1]  R1929     6.1508959531784058e-01
    z[3,7,1]  R1930     -4.8962280154228210e-01
    z[3,7,1]  R1931     5.5734282732009888e-01
    z[3,7,1]  R1932     6.2382537126541138e-01
    z[3,7,1]  R1933     6.9943684339523315e-01
    z[3,7,1]  R1934     -5.6367683410644531e-01
    z[3,7,1]  R1935     7.6815813779830933e-01
    z[3,7,1]  R1936     -7.6969122886657715e-01
    z[3,7,1]  R1937     -7.3696362972259521e-01
    z[3,7,1]  R1938     -9.2049682140350342e-01
    z[3,7,1]  R1939     -7.5868427753448486e-01
    z[3,7,1]  R1940     6.7385560274124146e-01
    z[3,7,1]  R1941     5.2036279439926147e-01
    z[3,7,1]  R1942     0.868614137172699
    z[3,7,1]  R1943     8.1428307294845581e-01
    z[3,7,1]  R1944     -7.6087635755538940e-01
    z[3,7,1]  R1945     -3.7918284535408020e-01
    z[3,7,1]  R1946     -5.8403360843658447e-01
    z[3,7,1]  R1947     -0.577204704284668
    z[3,7,1]  R1948     -5.0304710865020752e-01
    z[3,7,1]  R1949     -5.1557654142379761e-01
    z[3,7,1]  R1950     -3.6960625648498535e-01
    z[3,7,1]  R1951     -6.7872440814971924e-01
    z[3,7,1]  R1952     7.0590823888778687e-01
    z[3,7,1]  R1953     6.5275180339813232e-01
    z[3,7,1]  R1954     7.7657061815261841e-01
    z[3,7,1]  R1955     6.8200689554214478e-01
    z[3,7,1]  R1956     6.6349774599075317e-01
    z[3,7,1]  R1957     6.1811476945877075e-01
    z[3,7,1]  R1958     6.1596262454986572e-01
    z[3,7,1]  R1959     5.7915139198303223e-01
    z[3,7,1]  R1960     7.0773756504058838e-01
    z[3,7,1]  R1961     5.3430587053298950e-01
    z[3,7,1]  R1962     3.9622643589973450e-01
    z[3,7,1]  R1963     4.3754762411117554e-01
    z[3,7,1]  R1964     4.8011958599090576e-01
    z[3,7,1]  R1965     3.8664203882217407e-01
    z[3,7,1]  R1966     -2.5440484285354614e-01
    z[3,7,1]  R1967     -3.0046477913856506e-01
    z[3,7,1]  R1968     -6.3220870494842529e-01
    z[3,7,1]  R1969     -5.6545984745025635e-01
    z[3,7,1]  R1970     4.8776644468307495e-01
    z[3,7,1]  R1971     4.6707892417907715e-01
    z[3,7,1]  R1972     5.2490210533142090e-01
    z[3,7,1]  R1973     -2.4439743161201477e-01
    z[3,7,1]  R1974     0.74985671043396
    z[3,7,1]  R1975     7.4483048915863037e-01
    z[3,7,1]  R1976     6.0011005401611328e-01
    z[3,7,1]  R1977     -1.0027145594358444e-01
    z[3,7,1]  R1978     -3.2934451103210449e-01
    z[3,7,1]  R1979     -1.1398215591907501e-01
    z[3,7,1]  R1980     -1.0426852852106094e-01
    z[3,7,1]  R1981     -0.144050732254982
    z[3,7,1]  R1982     -0.0899525135755539
    z[3,7,1]  R1983     7.9007655382156372e-02
    z[3,7,2]  R31       -1
    z[3,7,2]  R67       1
    z[3,7,2]  R1894     -1
    z[3,7,2]  R1895     1
    z[3,7,2]  R1904     -1.5577442944049835e-01
    z[3,7,2]  R1905     -6.0458236932754517e-01
    z[3,7,2]  R1906     -5.1972138881683350e-01
    z[3,7,2]  R1907     -3.8542884588241577e-01
    z[3,7,2]  R1908     -4.9501702189445496e-01
    z[3,7,2]  R1909     -3.6971840262413025e-01
    z[3,7,2]  R1910     -0.673039972782135
    z[3,7,2]  R1911     7.3226056993007660e-02
    z[3,7,2]  R1912     -3.3864775300025940e-01
    z[3,7,2]  R1913     -1.6483345627784729e-01
    z[3,7,2]  R1914     4.4338285923004150e-01
    z[3,7,2]  R1915     2.1244935691356659e-01
    z[3,7,2]  R1916     4.1812750697135925e-01
    z[3,7,2]  R1917     3.2986089587211609e-01
    z[3,7,2]  R1918     7.5422719120979309e-02
    z[3,7,2]  R1919     -1.8810895085334778e-01
    z[3,7,2]  R1920     4.7620362043380737e-01
    z[3,7,2]  R1921     3.8832318782806396e-01
    z[3,7,2]  R1922     6.0331451892852783e-01
    z[3,7,2]  R1923     4.2715713381767273e-01
    z[3,7,2]  R1924     1.9687317311763763e-01
    z[3,7,2]  R1925     1.8519483506679535e-01
    z[3,7,2]  R1926     -0.0568130724132061
    z[3,7,2]  R1927     -1.6443207859992981e-01
    z[3,7,2]  R1928     1.1148890107870102e-01
    z[3,7,2]  R1929     1.9072158634662628e-01
    z[3,7,2]  R1930     -0.0665467232465744
    z[3,7,2]  R1931     4.0483516454696655e-01
    z[3,7,2]  R1932     3.5350584983825684e-01
    z[3,7,2]  R1933     1.7171221971511841e-01
    z[3,7,2]  R1934     -1.9684784114360809e-01
    z[3,7,2]  R1935     7.5926974415779114e-02
    z[3,7,2]  R1936     -3.3008918166160583e-01
    z[3,7,2]  R1937     -3.6259409785270691e-01
    z[3,7,2]  R1938     1.0326393693685532e-01
    z[3,7,2]  R1939     -3.9868235588073730e-02
    z[3,7,2]  R1940     -6.3102908432483673e-02
    z[3,7,2]  R1941     -0.0151675371453166
    z[3,7,2]  R1942     -1.6450341045856476e-01
    z[3,7,2]  R1943     8.5549578070640564e-02
    z[3,7,2]  R1944     -4.9087649583816528e-01
    z[3,7,2]  R1945     -4.5914888381958008e-01
    z[3,7,2]  R1946     -5.7204127311706543e-01
    z[3,7,2]  R1947     -5.5474025011062622e-01
    z[3,7,2]  R1948     -2.0608049631118774e-01
    z[3,7,2]  R1949     -3.8284295797348022e-01
    z[3,7,2]  R1950     -3.7049689888954163e-01
    z[3,7,2]  R1951     1.8101982772350311e-01
    z[3,7,2]  R1952     0.0501449890434742
    z[3,7,2]  R1953     -2.6582766324281693e-02
    z[3,7,2]  R1954     1.1455873399972916e-01
    z[3,7,2]  R1955     -1.9130834937095642e-01
    z[3,7,2]  R1956     3.4527698159217834e-01
    z[3,7,2]  R1957     2.9010051488876343e-01
    z[3,7,2]  R1958     -1.4007273316383362e-01
    z[3,7,2]  R1959     5.3694641590118408e-01
    z[3,7,2]  R1960     0.0927298292517662
    z[3,7,2]  R1961     -6.8193182349205017e-02
    z[3,7,2]  R1962     0.50670325756073
    z[3,7,2]  R1963     3.2412725687026978e-01
    z[3,7,2]  R1964     1.1077066510915756e-01
    z[3,7,2]  R1965     -2.5768473744392395e-01
    z[3,7,2]  R1966     1.4226564764976501e-01
    z[3,7,2]  R1967     -8.1668600440025330e-02
    z[3,7,2]  R1968     7.0994421839714050e-02
    z[3,7,2]  R1969     9.5608517527580261e-02
    z[3,7,2]  R1970     -4.6972211450338364e-02
    z[3,7,2]  R1971     5.4767513275146484e-01
    z[3,7,2]  R1972     1.6562581062316895e-01
    z[3,7,2]  R1973     2.7310448884963989e-01
    z[3,7,2]  R1974     1.8667300045490265e-01
    z[3,7,2]  R1975     9.7441887483000755e-03
    z[3,7,2]  R1976     2.2966033220291138e-01
    z[3,7,2]  R1977     7.1472458541393280e-02
    z[3,7,2]  R1978     4.2513498663902283e-01
    z[3,7,2]  R1979     -0.0327107198536396
    z[3,7,2]  R1980     2.1202708780765533e-01
    z[3,7,2]  R1981     1.3398066163063049e-01
    z[3,7,2]  R1982     8.6986780166625977e-02
    z[3,7,2]  R1983     9.7790569067001343e-02
    z[3,7,3]  R32       -1
    z[3,7,3]  R68       1
    z[3,7,3]  R1896     -1
    z[3,7,3]  R1897     1
    z[3,7,3]  R1904     -9.7489524632692337e-03
    z[3,7,3]  R1905     -1.8885856866836548e-01
    z[3,7,3]  R1906     2.1941512823104858e-01
    z[3,7,3]  R1907     1.1851963587105274e-02
    z[3,7,3]  R1908     -5.8438103646039963e-02
    z[3,7,3]  R1909     0.045077845454216
    z[3,7,3]  R1910     3.5778489708900452e-01
    z[3,7,3]  R1911     5.2593439817428589e-01
    z[3,7,3]  R1912     8.0375157296657562e-02
    z[3,7,3]  R1913     3.9720643311738968e-02
    z[3,7,3]  R1914     -3.7784284353256226e-01
    z[3,7,3]  R1915     1.4121010899543762e-01
    z[3,7,3]  R1916     -4.6531671285629272e-01
    z[3,7,3]  R1917     -1.1461026966571808e-02
    z[3,7,3]  R1918     -3.4973528236150742e-02
    z[3,7,3]  R1919     1.7360763251781464e-01
    z[3,7,3]  R1920     -5.9369200468063354e-01
    z[3,7,3]  R1921     5.9511110186576843e-02
    z[3,7,3]  R1922     -6.6745573282241821e-01
    z[3,7,3]  R1923     -5.3625065833330154e-02
    z[3,7,3]  R1924     -5.7023368775844574e-02
    z[3,7,3]  R1925     1.3739582896232605e-01
    z[3,7,3]  R1926     1.2602323293685913e-01
    z[3,7,3]  R1927     1.6580019891262054e-01
    z[3,7,3]  R1928     4.8164751380681992e-02
    z[3,7,3]  R1929     -1.5695963799953461e-01
    z[3,7,3]  R1930     5.0392758846282959e-01
    z[3,7,3]  R1931     -4.8290807008743286e-01
    z[3,7,3]  R1932     -4.1087540984153748e-01
    z[3,7,3]  R1933     -2.4842780828475952e-01
    z[3,7,3]  R1934     4.7737839818000793e-01
    z[3,7,3]  R1935     -3.4771889448165894e-01
    z[3,7,3]  R1936     3.4257954359054565e-01
    z[3,7,3]  R1937     0.376578152179718
    z[3,7,3]  R1938     -0.270519495010376
    z[3,7,3]  R1939     9.1828359290957451e-03
    z[3,7,3]  R1940     -9.3843534588813782e-02
    z[3,7,3]  R1941     1.2134262919425964e-01
    z[3,7,3]  R1942     1.5632796287536621e-01
    z[3,7,3]  R1943     1.5583147108554840e-01
    z[3,7,3]  R1944     -1.9534103572368622e-01
    z[3,7,3]  R1945     -6.7476667463779449e-02
    z[3,7,3]  R1946     -7.6603449881076813e-02
    z[3,7,3]  R1947     3.7834087014198303e-01
    z[3,7,3]  R1948     7.6880931854248047e-02
    z[3,7,3]  R1949     3.3753588795661926e-01
    z[3,7,3]  R1950     1.9323676824569702e-02
    z[3,7,3]  R1951     -2.4950817227363586e-01
    z[3,7,3]  R1952     2.1537464857101440e-01
    z[3,7,3]  R1953     4.7597751021385193e-01
    z[3,7,3]  R1954     -3.5705888271331787e-01
    z[3,7,3]  R1955     3.9178112149238586e-01
    z[3,7,3]  R1956     -5.1507627964019775e-01
    z[3,7,3]  R1957     -5.1381522417068481e-01
    z[3,7,3]  R1958     -3.5033130645751953e-01
    z[3,7,3]  R1959     -3.7505501508712769e-01
    z[3,7,3]  R1960     -2.3978227376937866e-01
    z[3,7,3]  R1961     -2.6280593872070312e-01
    z[3,7,3]  R1962     -3.5178834199905396e-01
    z[3,7,3]  R1963     -0.566901445388794
    z[3,7,3]  R1964     -0.554315984249115
    z[3,7,3]  R1965     -8.1742691993713379e-01
    z[3,7,3]  R1966     5.3159141540527344e-01
    z[3,7,3]  R1967     5.3855520486831665e-01
    z[3,7,3]  R1968     1.6299067437648773e-01
    z[3,7,3]  R1969     3.1442412734031677e-01
    z[3,7,3]  R1970     3.9757695794105530e-01
    z[3,7,3]  R1971     -2.7959507703781128e-01
    z[3,7,3]  R1972     6.3443198800086975e-02
    z[3,7,3]  R1973     -0.675109326839447
    z[3,7,3]  R1974     -2.0627894997596741e-01
    z[3,7,3]  R1975     -7.3001608252525330e-02
    z[3,7,3]  R1976     3.6904498934745789e-01
    z[3,7,3]  R1977     6.6535556316375732e-01
    z[3,7,3]  R1978     1.6231556236743927e-01
    z[3,7,3]  R1979     -3.4614145755767822e-02
    z[3,7,3]  R1980     9.6747368574142456e-02
    z[3,7,3]  R1981     2.3363502323627472e-01
    z[3,7,3]  R1982     3.2033350318670273e-02
    z[3,7,3]  R1983     2.9793012142181396e-01
    z[3,7,4]  R33       -1
    z[3,7,4]  R69       1
    z[3,7,4]  R1898     -1
    z[3,7,4]  R1899     1
    z[3,7,4]  R1904     3.0825203657150269e-01
    z[3,7,4]  R1905     0.101965993642807
    z[3,7,4]  R1906     -7.2813339531421661e-02
    z[3,7,4]  R1907     5.3983730077743530e-01
    z[3,7,4]  R1908     2.6378706097602844e-01
    z[3,7,4]  R1909     5.3849774599075317e-01
    z[3,7,4]  R1910     1.8499688804149628e-01
    z[3,7,4]  R1911     1.7156605422496796e-01
    z[3,7,4]  R1912     5.0421640276908875e-02
    z[3,7,4]  R1913     0.0775560736656189
    z[3,7,4]  R1914     9.6017621457576752e-02
    z[3,7,4]  R1915     -0.452067106962204
    z[3,7,4]  R1916     1.6617333889007568e-01
    z[3,7,4]  R1917     -1.8061715364456177e-01
    z[3,7,4]  R1918     7.5188815593719482e-02
    z[3,7,4]  R1919     -2.5747114419937134e-01
    z[3,7,4]  R1920     6.2724113464355469e-02
    z[3,7,4]  R1921     -7.3110930621623993e-02
    z[3,7,4]  R1922     1.9055263698101044e-01
    z[3,7,4]  R1923     -3.1058004498481750e-01
    z[3,7,4]  R1924     -2.2223468124866486e-01
    z[3,7,4]  R1925     -1.9229148328304291e-01
    z[3,7,4]  R1926     -5.6604868173599243e-01
    z[3,7,4]  R1927     -2.6208677887916565e-01
    z[3,7,4]  R1928     -5.1472359895706177e-01
    z[3,7,4]  R1929     -2.4435704946517944e-01
    z[3,7,4]  R1930     -4.8377969861030579e-01
    z[3,7,4]  R1931     -2.3590198159217834e-01
    z[3,7,4]  R1932     0.509386420249939
    z[3,7,4]  R1933     -4.3700519204139709e-01
    z[3,7,4]  R1934     -2.1561256051063538e-01
    z[3,7,4]  R1935     -1.8238714337348938e-01
    z[3,7,4]  R1936     -2.8487563133239746e-01
    z[3,7,4]  R1937     -5.8203574270009995e-02
    z[3,7,4]  R1938     4.1803520172834396e-02
    z[3,7,4]  R1939     1.7025732994079590e-01
    z[3,7,4]  R1940     -2.4461135268211365e-01
    z[3,7,4]  R1941     -1.7198120057582855e-01
    z[3,7,4]  R1942     1.3553853332996368e-01
    z[3,7,4]  R1943     3.7733739614486694e-01
    z[3,7,4]  R1944     8.8081859052181244e-02
    z[3,7,4]  R1945     4.2256745696067810e-01
    z[3,7,4]  R1946     4.9313545227050781e-01
    z[3,7,4]  R1947     1.0212492197751999e-01
    z[3,7,4]  R1948     9.8563842475414276e-02
    z[3,7,4]  R1949     3.8314953446388245e-01
    z[3,7,4]  R1950     6.5418505668640137e-01
    z[3,7,4]  R1951     5.4040521383285522e-02
    z[3,7,4]  R1952     -3.5474825650453568e-02
    z[3,7,4]  R1953     1.6338813304901123e-01
    z[3,7,4]  R1954     1.1716998182237148e-02
    z[3,7,4]  R1955     -2.0683860778808594e-01
    z[3,7,4]  R1956     2.3803491145372391e-02
    z[3,7,4]  R1957     2.1660542488098145e-01
    z[3,7,4]  R1958     5.1346683502197266e-01
    z[3,7,4]  R1959     -2.5644731521606445e-01
    z[3,7,4]  R1960     8.7570890784263611e-02
    z[3,7,4]  R1961     4.4482216238975525e-01
    z[3,7,4]  R1962     -1.8806131184101105e-01
    z[3,7,4]  R1963     3.8330635428428650e-01
    z[3,7,4]  R1964     2.7388921380043030e-01
    z[3,7,4]  R1965     -1.1197332292795181e-01
    z[3,7,4]  R1966     -7.5706982612609863e-01
    z[3,7,4]  R1967     -6.3856667280197144e-01
    z[3,7,4]  R1968     -5.2379405498504639e-01
    z[3,7,4]  R1969     -4.8556759953498840e-01
    z[3,7,4]  R1970     -3.9496758580207825e-01
    z[3,7,4]  R1971     1.3980881869792938e-01
    z[3,7,4]  R1972     -2.8170329332351685e-01
    z[3,7,4]  R1973     -1.0841037333011627e-01
    z[3,7,4]  R1974     -6.2899775803089142e-02
    z[3,7,4]  R1975     3.2857468724250793e-01
    z[3,7,4]  R1976     -0.607761025428772
    z[3,7,4]  R1977     -5.4443657398223877e-01
    z[3,7,4]  R1978     -5.0919461250305176e-01
    z[3,7,4]  R1979     -1.6262637078762054e-01
    z[3,7,4]  R1980     3.6612160503864288e-02
    z[3,7,4]  R1981     1.1570832133293152e-01
    z[3,7,4]  R1982     -2.0798210799694061e-01
    z[3,7,4]  R1983     6.3452489674091339e-02
    z[3,7,5]  R34       -1
    z[3,7,5]  R70       1
    z[3,7,5]  R1900     -1
    z[3,7,5]  R1901     1
    z[3,7,5]  R1904     0.288438618183136
    z[3,7,5]  R1905     7.3415338993072510e-02
    z[3,7,5]  R1906     3.1598886847496033e-01
    z[3,7,5]  R1907     2.9113727807998657e-01
    z[3,7,5]  R1908     5.9622806310653687e-01
    z[3,7,5]  R1909     3.8937801122665405e-01
    z[3,7,5]  R1910     1.0548871755599976e-01
    z[3,7,5]  R1911     -3.0654066801071167e-01
    z[3,7,5]  R1912     -1.3580715656280518e-01
    z[3,7,5]  R1913     2.7249258756637573e-01
    z[3,7,5]  R1914     -1.0735871642827988e-01
    z[3,7,5]  R1915     -5.4265994578599930e-02
    z[3,7,5]  R1916     -4.0690630674362183e-01
    z[3,7,5]  R1917     -5.0688081979751587e-01
    z[3,7,5]  R1918     -3.9016571640968323e-01
    z[3,7,5]  R1919     2.6489531993865967e-01
    z[3,7,5]  R1920     -2.3758928477764130e-01
    z[3,7,5]  R1921     -1.5222407877445221e-01
    z[3,7,5]  R1922     -1.7769478261470795e-01
    z[3,7,5]  R1923     -5.3262615203857422e-01
    z[3,7,5]  R1924     -3.4445360302925110e-01
    z[3,7,5]  R1925     -2.3536950349807739e-02
    z[3,7,5]  R1926     -4.9152320623397827e-01
    z[3,7,5]  R1927     -3.7724217772483826e-01
    z[3,7,5]  R1928     -8.8155664503574371e-02
    z[3,7,5]  R1929     6.2642043828964233e-01
    z[3,7,5]  R1930     9.6060521900653839e-02
    z[3,7,5]  R1931     3.6358323693275452e-01
    z[3,7,5]  R1932     1.1877653747797012e-01
    z[3,7,5]  R1933     4.1252571344375610e-01
    z[3,7,5]  R1934     -2.3521672189235687e-01
    z[3,7,5]  R1935     3.4173348546028137e-01
    z[3,7,5]  R1936     -2.1266996860504150e-01
    z[3,7,5]  R1937     1.3347616791725159e-01
    z[3,7,5]  R1938     -1.7888711392879486e-01
    z[3,7,5]  R1939     -5.8507549762725830e-01
    z[3,7,5]  R1940     3.9482930302619934e-01
    z[3,7,5]  R1941     -1.5781989693641663e-01
    z[3,7,5]  R1942     3.6871945858001709e-01
    z[3,7,5]  R1943     -2.8889900445938110e-01
    z[3,7,5]  R1944     1.9620141386985779e-01
    z[3,7,5]  R1945     4.6732330322265625e-01
    z[3,7,5]  R1946     0.257762610912323
    z[3,7,5]  R1947     3.2977280020713806e-01
    z[3,7,5]  R1948     2.7991998195648193e-01
    z[3,7,5]  R1949     -9.0255342423915863e-02
    z[3,7,5]  R1950     2.5046941637992859e-01
    z[3,7,5]  R1951     4.2706301808357239e-01
    z[3,7,5]  R1952     -9.5430992543697357e-02
    z[3,7,5]  R1953     -1.2117945402860641e-01
    z[3,7,5]  R1954     0.194473534822464
    z[3,7,5]  R1955     -3.3332142233848572e-01
    z[3,7,5]  R1956     -1.4950575307011604e-02
    z[3,7,5]  R1957     -2.0976434648036957e-01
    z[3,7,5]  R1958     -0.0895463153719902
    z[3,7,5]  R1959     -1.3865956664085388e-01
    z[3,7,5]  R1960     -3.8939729332923889e-01
    z[3,7,5]  R1961     -5.1084810495376587e-01
    z[3,7,5]  R1962     2.5415942072868347e-01
    z[3,7,5]  R1963     2.4926245212554932e-01
    z[3,7,5]  R1964     3.1599956750869751e-01
    z[3,7,5]  R1965     1.9042393192648888e-02
    z[3,7,5]  R1966     -1.4626312255859375e-01
    z[3,7,5]  R1967     -4.3257924914360046e-01
    z[3,7,5]  R1968     -5.2931028604507446e-01
    z[3,7,5]  R1969     -2.4646340310573578e-01
    z[3,7,5]  R1970     6.6729128360748291e-01
    z[3,7,5]  R1971     -5.0630003213882446e-01
    z[3,7,5]  R1972     6.9655174016952515e-01
    z[3,7,5]  R1973     1.9682997465133667e-01
    z[3,7,5]  R1974     4.1747590899467468e-01
    z[3,7,5]  R1975     -4.2000961303710938e-01
    z[3,7,5]  R1976     2.3197035491466522e-01
    z[3,7,5]  R1977     -3.1511966139078140e-02
    z[3,7,5]  R1978     -4.5322397351264954e-01
    z[3,7,5]  R1979     4.6095319092273712e-02
    z[3,7,5]  R1980     7.3622646741569042e-03
    z[3,7,5]  R1981     -1.3261437416076660e-01
    z[3,7,5]  R1982     3.0438652634620667e-01
    z[3,7,5]  R1983     4.9425348639488220e-01
    z[3,7,6]  R35       -1
    z[3,7,6]  R71       1
    z[3,7,6]  R1902     -1
    z[3,7,6]  R1903     1
    z[3,7,6]  R1904     -1.0111232101917267e-01
    z[3,7,6]  R1905     1.3224272429943085e-01
    z[3,7,6]  R1906     2.6924493908882141e-01
    z[3,7,6]  R1907     3.9693927764892578e-01
    z[3,7,6]  R1908     1.9151189923286438e-01
    z[3,7,6]  R1909     -3.8249734044075012e-01
    z[3,7,6]  R1910     -1.8938811123371124e-01
    z[3,7,6]  R1911     -3.3034953474998474e-01
    z[3,7,6]  R1912     -4.2161145806312561e-01
    z[3,7,6]  R1913     -2.3401927947998047e-01
    z[3,7,6]  R1914     1.3225534558296204e-01
    z[3,7,6]  R1915     -7.7248126268386841e-02
    z[3,7,6]  R1916     5.7576749473810196e-02
    z[3,7,6]  R1917     6.1256840825080872e-02
    z[3,7,6]  R1918     5.2010113000869751e-01
    z[3,7,6]  R1919     4.6250253915786743e-01
    z[3,7,6]  R1920     -1.0021121054887772e-01
    z[3,7,6]  R1921     -4.1702026128768921e-01
    z[3,7,6]  R1922     -9.3552783131599426e-02
    z[3,7,6]  R1923     -3.3364757895469666e-01
    z[3,7,6]  R1924     1.2438180297613144e-01
    z[3,7,6]  R1925     -1.7168733477592468e-01
    z[3,7,6]  R1926     2.8000321984291077e-01
    z[3,7,6]  R1927     4.7164449095726013e-01
    z[3,7,6]  R1928     3.0716332793235779e-01
    z[3,7,6]  R1929     -2.8244480490684509e-02
    z[3,7,6]  R1930     3.7792941927909851e-01
    z[3,7,6]  R1931     -1.3606618344783783e-01
    z[3,7,6]  R1932     -1.7522041499614716e-01
    z[3,7,6]  R1933     1.2355015426874161e-01
    z[3,7,6]  R1934     3.5263389348983765e-01
    z[3,7,6]  R1935     -3.6459651589393616e-01
    z[3,7,6]  R1936     1.8081568181514740e-01
    z[3,7,6]  R1937     2.4590662121772766e-01
    z[3,7,6]  R1938     1.0105468332767487e-01
    z[3,7,6]  R1939     0.163529634475708
    z[3,7,6]  R1940     5.2980917692184448e-01
    z[3,7,6]  R1941     5.0102514028549194e-01
    z[3,7,6]  R1942     3.3948723226785660e-02
    z[3,7,6]  R1943     -2.3816585540771484e-02
    z[3,7,6]  R1944     2.2123497724533081e-01
    z[3,7,6]  R1945     -1.9174998998641968e-01
    z[3,7,6]  R1946     0.0460628941655159
    z[3,7,6]  R1947     -1.5734435617923737e-01
    z[3,7,6]  R1948     4.7708559036254883e-01
    z[3,7,6]  R1949     -6.5209582448005676e-02
    z[3,7,6]  R1950     -2.3663861677050591e-02
    z[3,7,6]  R1951     -1.2370146811008453e-01
    z[3,7,6]  R1952     1.2677356600761414e-01
    z[3,7,6]  R1953     -2.3039312660694122e-01
    z[3,7,6]  R1954     -1.3164682686328888e-01
    z[3,7,6]  R1955     2.1696081757545471e-01
    z[3,7,6]  R1956     2.6832911372184753e-01
    z[3,7,6]  R1957     -1.3177742250263691e-02
    z[3,7,6]  R1958     3.0612629652023315e-01
    z[3,7,6]  R1959     -1.2251044809818268e-01
    z[3,7,6]  R1960     2.6547789573669434e-01
    z[3,7,6]  R1961     0.0589272603392601
    z[3,7,6]  R1962     -4.9622341990470886e-01
    z[3,7,6]  R1963     -3.6355575919151306e-01
    z[3,7,6]  R1964     4.4139412045478821e-01
    z[3,7,6]  R1965     2.6935037970542908e-01
    z[3,7,6]  R1966     -1.2859410047531128e-01
    z[3,7,6]  R1967     1.3162109255790710e-01
    z[3,7,6]  R1968     3.3296972513198853e-02
    z[3,7,6]  R1969     -5.1404148340225220e-01
    z[3,7,6]  R1970     3.3346044365316629e-03
    z[3,7,6]  R1971     -1.9768282771110535e-01
    z[3,7,6]  R1972     2.7940711379051208e-01
    z[3,7,6]  R1973     -4.1030306369066238e-02
    z[3,7,6]  R1974     4.2660921812057495e-01
    z[3,7,6]  R1975     3.8344833254814148e-01
    z[3,7,6]  R1976     -1.2711404263973236e-01
    z[3,7,6]  R1977     -4.1706174612045288e-01
    z[3,7,6]  R1978     -6.1860390007495880e-02
    z[3,7,6]  R1979     -1.2872008979320526e-01
    z[3,7,6]  R1980     5.2757188677787781e-02
    z[3,7,6]  R1981     -1.8861402571201324e-01
    z[3,7,6]  R1982     2.2779045999050140e-01
    z[3,7,6]  R1983     3.3120752777904272e-03
    z[7,3,0]  R29       1
    z[7,3,0]  R65       -1
    z[7,3,0]  R1984     -1
    z[7,3,0]  R1985     1
    z[7,3,0]  R1998     -2.1621994674205780e-01
    z[7,3,0]  R1999     -4.5511227846145630e-01
    z[7,3,0]  R2000     1.1857293546199799e-01
    z[7,3,0]  R2001     -2.6836407184600830e-01
    z[7,3,0]  R2002     -6.1877554655075073e-01
    z[7,3,0]  R2003     -5.6078499555587769e-01
    z[7,3,0]  R2004     -4.8424881696701050e-01
    z[7,3,0]  R2005     -0.493665486574173
    z[7,3,0]  R2006     -6.5295916795730591e-01
    z[7,3,0]  R2007     -5.0218790769577026e-01
    z[7,3,0]  R2008     4.4836950302124023e-01
    z[7,3,0]  R2009     3.7923336029052734e-01
    z[7,3,0]  R2010     3.2009416818618774e-01
    z[7,3,0]  R2011     4.2270222306251526e-01
    z[7,3,0]  R2012     3.3594289422035217e-01
    z[7,3,0]  R2013     0.368246465921402
    z[7,3,0]  R2014     4.5081678032875061e-01
    z[7,3,0]  R2015     4.2248663306236267e-01
    z[7,3,0]  R2016     3.4102728962898254e-01
    z[7,3,0]  R2017     2.0220804214477539e-01
    z[7,3,0]  R2018     -2.8328239917755127e-01
    z[7,3,0]  R2019     -1.7455467581748962e-01
    z[7,3,0]  R2020     -1.4616841077804565e-01
    z[7,3,0]  R2021     2.8160439804196358e-02
    z[7,3,0]  R2022     1.1431477218866348e-01
    z[7,3,0]  R2023     1.0720545798540115e-01
    z[7,3,0]  R2024     2.2843575105071068e-02
    z[7,3,0]  R2025     -2.9791104793548584e-01
    z[7,3,0]  R2026     -2.2452485561370850e-01
    z[7,3,0]  R2027     5.9810775518417358e-01
    z[7,3,0]  R2028     8.8973073288798332e-03
    z[7,3,0]  R2029     -9.1658718883991241e-02
    z[7,3,0]  R2030     1.0764811933040619e-01
    z[7,3,0]  R2031     -2.6607245206832886e-01
    z[7,3,0]  R2032     -4.6468096971511841e-01
    z[7,3,0]  R2033     9.6932905912399292e-01
    z[7,3,0]  R2034     9.6469402313232422e-01
    z[7,3,0]  R2035     9.1660410165786743e-01
    z[7,3,0]  R2036     0.891918957233429
    z[7,3,0]  R2037     8.0443078279495239e-01
    z[7,3,0]  R2038     -6.8427008390426636e-01
    z[7,3,0]  R2039     -1.4818302355706692e-02
    z[7,3,0]  R2040     -3.4127944707870483e-01
    z[7,3,0]  R2041     -3.2248872518539429e-01
    z[7,3,0]  R2042     -4.1533282399177551e-01
    z[7,3,0]  R2043     3.2071336172521114e-03
    z[7,3,0]  R2044     -7.8725844621658325e-02
    z[7,3,0]  R2045     -1.8082509934902191e-01
    z[7,3,0]  R2046     -3.0452203750610352e-01
    z[7,3,0]  R2047     2.1030250191688538e-01
    z[7,3,0]  R2048     -0.369750440120697
    z[7,3,0]  R2049     -3.6885312199592590e-01
    z[7,3,0]  R2050     3.4414097666740417e-01
    z[7,3,0]  R2051     -3.8569509983062744e-01
    z[7,3,0]  R2052     -3.7709867954254150e-01
    z[7,3,0]  R2053     -2.5882118940353394e-01
    z[7,3,0]  R2054     5.3064805269241333e-01
    z[7,3,0]  R2055     -4.6140491962432861e-01
    z[7,3,0]  R2056     1.0283546894788742e-01
    z[7,3,0]  R2057     1.1462587118148804e-01
    z[7,3,0]  R2058     2.0582200586795807e-01
    z[7,3,0]  R2059     -1.8039016425609589e-01
    z[7,3,0]  R2060     -1.4154779911041260e-01
    z[7,3,0]  R2061     2.8120434284210205e-01
    z[7,3,0]  R2062     2.1532581746578217e-01
    z[7,3,0]  R2063     -3.2824245095252991e-01
    z[7,3,0]  R2064     3.4028959274291992e-01
    z[7,3,0]  R2065     2.9312244057655334e-01
    z[7,3,0]  R2066     1.1301513016223907e-01
    z[7,3,0]  R2067     2.0777639746665955e-01
    z[7,3,0]  R2068     -4.3527320027351379e-01
    z[7,3,0]  R2069     1.6804765909910202e-02
    z[7,3,0]  R2070     -1.4892593026161194e-01
    z[7,3,0]  R2071     3.1925755739212036e-01
    z[7,3,0]  R2072     -1.5773749351501465e-01
    z[7,3,0]  R2073     -1.5710341930389404e-01
    z[7,3,0]  R2074     -1.9159191846847534e-01
    z[7,3,0]  R2075     -0.639341413974762
    z[7,3,0]  R2076     1.9629706442356110e-01
    z[7,3,0]  R2077     -2.8094035387039185e-01
    z[7,3,1]  R30       1
    z[7,3,1]  R66       -1
    z[7,3,1]  R1986     -1
    z[7,3,1]  R1987     1
    z[7,3,1]  R1998     -7.6087635755538940e-01
    z[7,3,1]  R1999     -3.7918284535408020e-01
    z[7,3,1]  R2000     -5.8403360843658447e-01
    z[7,3,1]  R2001     -0.577204704284668
    z[7,3,1]  R2002     -5.0304710865020752e-01
    z[7,3,1]  R2003     -5.1557654142379761e-01
    z[7,3,1]  R2004     -3.6960625648498535e-01
    z[7,3,1]  R2005     -6.7872440814971924e-01
    z[7,3,1]  R2006     7.0590823888778687e-01
    z[7,3,1]  R2007     6.5275180339813232e-01
    z[7,3,1]  R2008     7.7657061815261841e-01
    z[7,3,1]  R2009     6.8200689554214478e-01
    z[7,3,1]  R2010     6.6349774599075317e-01
    z[7,3,1]  R2011     6.1811476945877075e-01
    z[7,3,1]  R2012     6.1596262454986572e-01
    z[7,3,1]  R2013     5.7915139198303223e-01
    z[7,3,1]  R2014     7.0773756504058838e-01
    z[7,3,1]  R2015     5.3430587053298950e-01
    z[7,3,1]  R2016     3.9622643589973450e-01
    z[7,3,1]  R2017     4.3754762411117554e-01
    z[7,3,1]  R2018     4.8011958599090576e-01
    z[7,3,1]  R2019     3.8664203882217407e-01
    z[7,3,1]  R2020     -2.5440484285354614e-01
    z[7,3,1]  R2021     -3.0046477913856506e-01
    z[7,3,1]  R2022     -6.3220870494842529e-01
    z[7,3,1]  R2023     -5.6545984745025635e-01
    z[7,3,1]  R2024     4.8776644468307495e-01
    z[7,3,1]  R2025     4.6707892417907715e-01
    z[7,3,1]  R2026     5.2490210533142090e-01
    z[7,3,1]  R2027     -2.4439743161201477e-01
    z[7,3,1]  R2028     0.74985671043396
    z[7,3,1]  R2029     7.4483048915863037e-01
    z[7,3,1]  R2030     6.0011005401611328e-01
    z[7,3,1]  R2031     -1.0027145594358444e-01
    z[7,3,1]  R2032     -3.2934451103210449e-01
    z[7,3,1]  R2033     -1.1398215591907501e-01
    z[7,3,1]  R2034     -1.0426852852106094e-01
    z[7,3,1]  R2035     -0.144050732254982
    z[7,3,1]  R2036     -0.0899525135755539
    z[7,3,1]  R2037     7.9007655382156372e-02
    z[7,3,1]  R2038     -5.6477773189544678e-01
    z[7,3,1]  R2039     -7.5187635421752930e-01
    z[7,3,1]  R2040     -6.2260061502456665e-01
    z[7,3,1]  R2041     -4.6212467551231384e-01
    z[7,3,1]  R2042     -3.4248134493827820e-01
    z[7,3,1]  R2043     -5.2284485101699829e-01
    z[7,3,1]  R2044     -5.7583832740783691e-01
    z[7,3,1]  R2045     -0.672904372215271
    z[7,3,1]  R2046     7.6640832424163818e-01
    z[7,3,1]  R2047     8.8993984460830688e-01
    z[7,3,1]  R2048     0.696917712688446
    z[7,3,1]  R2049     7.6524215936660767e-01
    z[7,3,1]  R2050     5.4195505380630493e-01
    z[7,3,1]  R2051     0.670072078704834
    z[7,3,1]  R2052     6.4999777078628540e-01
    z[7,3,1]  R2053     7.1910876035690308e-01
    z[7,3,1]  R2054     2.6219698786735535e-01
    z[7,3,1]  R2055     6.5600740909576416e-01
    z[7,3,1]  R2056     0.321405291557312
    z[7,3,1]  R2057     5.5682206153869629e-01
    z[7,3,1]  R2058     0.855639636516571
    z[7,3,1]  R2059     9.2047715187072754e-01
    z[7,3,1]  R2060     -5.6608009338378906e-01
    z[7,3,1]  R2061     -6.5798693895339966e-01
    z[7,3,1]  R2062     -7.5619047880172729e-01
    z[7,3,1]  R2063     6.1508959531784058e-01
    z[7,3,1]  R2064     -4.8962280154228210e-01
    z[7,3,1]  R2065     5.5734282732009888e-01
    z[7,3,1]  R2066     6.2382537126541138e-01
    z[7,3,1]  R2067     6.9943684339523315e-01
    z[7,3,1]  R2068     -5.6367683410644531e-01
    z[7,3,1]  R2069     7.6815813779830933e-01
    z[7,3,1]  R2070     -7.6969122886657715e-01
    z[7,3,1]  R2071     -7.3696362972259521e-01
    z[7,3,1]  R2072     -9.2049682140350342e-01
    z[7,3,1]  R2073     -7.5868427753448486e-01
    z[7,3,1]  R2074     6.7385560274124146e-01
    z[7,3,1]  R2075     5.2036279439926147e-01
    z[7,3,1]  R2076     0.868614137172699
    z[7,3,1]  R2077     8.1428307294845581e-01
    z[7,3,2]  R31       1
    z[7,3,2]  R67       -1
    z[7,3,2]  R1988     -1
    z[7,3,2]  R1989     1
    z[7,3,2]  R1998     -4.9087649583816528e-01
    z[7,3,2]  R1999     -4.5914888381958008e-01
    z[7,3,2]  R2000     -5.7204127311706543e-01
    z[7,3,2]  R2001     -5.5474025011062622e-01
    z[7,3,2]  R2002     -2.0608049631118774e-01
    z[7,3,2]  R2003     -3.8284295797348022e-01
    z[7,3,2]  R2004     -3.7049689888954163e-01
    z[7,3,2]  R2005     1.8101982772350311e-01
    z[7,3,2]  R2006     0.0501449890434742
    z[7,3,2]  R2007     -2.6582766324281693e-02
    z[7,3,2]  R2008     1.1455873399972916e-01
    z[7,3,2]  R2009     -1.9130834937095642e-01
    z[7,3,2]  R2010     3.4527698159217834e-01
    z[7,3,2]  R2011     2.9010051488876343e-01
    z[7,3,2]  R2012     -1.4007273316383362e-01
    z[7,3,2]  R2013     5.3694641590118408e-01
    z[7,3,2]  R2014     0.0927298292517662
    z[7,3,2]  R2015     -6.8193182349205017e-02
    z[7,3,2]  R2016     0.50670325756073
    z[7,3,2]  R2017     3.2412725687026978e-01
    z[7,3,2]  R2018     1.1077066510915756e-01
    z[7,3,2]  R2019     -2.5768473744392395e-01
    z[7,3,2]  R2020     1.4226564764976501e-01
    z[7,3,2]  R2021     -8.1668600440025330e-02
    z[7,3,2]  R2022     7.0994421839714050e-02
    z[7,3,2]  R2023     9.5608517527580261e-02
    z[7,3,2]  R2024     -4.6972211450338364e-02
    z[7,3,2]  R2025     5.4767513275146484e-01
    z[7,3,2]  R2026     1.6562581062316895e-01
    z[7,3,2]  R2027     2.7310448884963989e-01
    z[7,3,2]  R2028     1.8667300045490265e-01
    z[7,3,2]  R2029     9.7441887483000755e-03
    z[7,3,2]  R2030     2.2966033220291138e-01
    z[7,3,2]  R2031     7.1472458541393280e-02
    z[7,3,2]  R2032     4.2513498663902283e-01
    z[7,3,2]  R2033     -0.0327107198536396
    z[7,3,2]  R2034     2.1202708780765533e-01
    z[7,3,2]  R2035     1.3398066163063049e-01
    z[7,3,2]  R2036     8.6986780166625977e-02
    z[7,3,2]  R2037     9.7790569067001343e-02
    z[7,3,2]  R2038     -1.5577442944049835e-01
    z[7,3,2]  R2039     -6.0458236932754517e-01
    z[7,3,2]  R2040     -5.1972138881683350e-01
    z[7,3,2]  R2041     -3.8542884588241577e-01
    z[7,3,2]  R2042     -4.9501702189445496e-01
    z[7,3,2]  R2043     -3.6971840262413025e-01
    z[7,3,2]  R2044     -0.673039972782135
    z[7,3,2]  R2045     7.3226056993007660e-02
    z[7,3,2]  R2046     -3.3864775300025940e-01
    z[7,3,2]  R2047     -1.6483345627784729e-01
    z[7,3,2]  R2048     4.4338285923004150e-01
    z[7,3,2]  R2049     2.1244935691356659e-01
    z[7,3,2]  R2050     4.1812750697135925e-01
    z[7,3,2]  R2051     3.2986089587211609e-01
    z[7,3,2]  R2052     7.5422719120979309e-02
    z[7,3,2]  R2053     -1.8810895085334778e-01
    z[7,3,2]  R2054     4.7620362043380737e-01
    z[7,3,2]  R2055     3.8832318782806396e-01
    z[7,3,2]  R2056     6.0331451892852783e-01
    z[7,3,2]  R2057     4.2715713381767273e-01
    z[7,3,2]  R2058     1.9687317311763763e-01
    z[7,3,2]  R2059     1.8519483506679535e-01
    z[7,3,2]  R2060     -0.0568130724132061
    z[7,3,2]  R2061     -1.6443207859992981e-01
    z[7,3,2]  R2062     1.1148890107870102e-01
    z[7,3,2]  R2063     1.9072158634662628e-01
    z[7,3,2]  R2064     -0.0665467232465744
    z[7,3,2]  R2065     4.0483516454696655e-01
    z[7,3,2]  R2066     3.5350584983825684e-01
    z[7,3,2]  R2067     1.7171221971511841e-01
    z[7,3,2]  R2068     -1.9684784114360809e-01
    z[7,3,2]  R2069     7.5926974415779114e-02
    z[7,3,2]  R2070     -3.3008918166160583e-01
    z[7,3,2]  R2071     -3.6259409785270691e-01
    z[7,3,2]  R2072     1.0326393693685532e-01
    z[7,3,2]  R2073     -3.9868235588073730e-02
    z[7,3,2]  R2074     -6.3102908432483673e-02
    z[7,3,2]  R2075     -0.0151675371453166
    z[7,3,2]  R2076     -1.6450341045856476e-01
    z[7,3,2]  R2077     8.5549578070640564e-02
    z[7,3,3]  R32       1
    z[7,3,3]  R68       -1
    z[7,3,3]  R1990     -1
    z[7,3,3]  R1991     1
    z[7,3,3]  R1998     -1.9534103572368622e-01
    z[7,3,3]  R1999     -6.7476667463779449e-02
    z[7,3,3]  R2000     -7.6603449881076813e-02
    z[7,3,3]  R2001     3.7834087014198303e-01
    z[7,3,3]  R2002     7.6880931854248047e-02
    z[7,3,3]  R2003     3.3753588795661926e-01
    z[7,3,3]  R2004     1.9323676824569702e-02
    z[7,3,3]  R2005     -2.4950817227363586e-01
    z[7,3,3]  R2006     2.1537464857101440e-01
    z[7,3,3]  R2007     4.7597751021385193e-01
    z[7,3,3]  R2008     -3.5705888271331787e-01
    z[7,3,3]  R2009     3.9178112149238586e-01
    z[7,3,3]  R2010     -5.1507627964019775e-01
    z[7,3,3]  R2011     -5.1381522417068481e-01
    z[7,3,3]  R2012     -3.5033130645751953e-01
    z[7,3,3]  R2013     -3.7505501508712769e-01
    z[7,3,3]  R2014     -2.3978227376937866e-01
    z[7,3,3]  R2015     -2.6280593872070312e-01
    z[7,3,3]  R2016     -3.5178834199905396e-01
    z[7,3,3]  R2017     -0.566901445388794
    z[7,3,3]  R2018     -0.554315984249115
    z[7,3,3]  R2019     -8.1742691993713379e-01
    z[7,3,3]  R2020     5.3159141540527344e-01
    z[7,3,3]  R2021     5.3855520486831665e-01
    z[7,3,3]  R2022     1.6299067437648773e-01
    z[7,3,3]  R2023     3.1442412734031677e-01
    z[7,3,3]  R2024     3.9757695794105530e-01
    z[7,3,3]  R2025     -2.7959507703781128e-01
    z[7,3,3]  R2026     6.3443198800086975e-02
    z[7,3,3]  R2027     -0.675109326839447
    z[7,3,3]  R2028     -2.0627894997596741e-01
    z[7,3,3]  R2029     -7.3001608252525330e-02
    z[7,3,3]  R2030     3.6904498934745789e-01
    z[7,3,3]  R2031     6.6535556316375732e-01
    z[7,3,3]  R2032     1.6231556236743927e-01
    z[7,3,3]  R2033     -3.4614145755767822e-02
    z[7,3,3]  R2034     9.6747368574142456e-02
    z[7,3,3]  R2035     2.3363502323627472e-01
    z[7,3,3]  R2036     3.2033350318670273e-02
    z[7,3,3]  R2037     2.9793012142181396e-01
    z[7,3,3]  R2038     -9.7489524632692337e-03
    z[7,3,3]  R2039     -1.8885856866836548e-01
    z[7,3,3]  R2040     2.1941512823104858e-01
    z[7,3,3]  R2041     1.1851963587105274e-02
    z[7,3,3]  R2042     -5.8438103646039963e-02
    z[7,3,3]  R2043     0.045077845454216
    z[7,3,3]  R2044     3.5778489708900452e-01
    z[7,3,3]  R2045     5.2593439817428589e-01
    z[7,3,3]  R2046     8.0375157296657562e-02
    z[7,3,3]  R2047     3.9720643311738968e-02
    z[7,3,3]  R2048     -3.7784284353256226e-01
    z[7,3,3]  R2049     1.4121010899543762e-01
    z[7,3,3]  R2050     -4.6531671285629272e-01
    z[7,3,3]  R2051     -1.1461026966571808e-02
    z[7,3,3]  R2052     -3.4973528236150742e-02
    z[7,3,3]  R2053     1.7360763251781464e-01
    z[7,3,3]  R2054     -5.9369200468063354e-01
    z[7,3,3]  R2055     5.9511110186576843e-02
    z[7,3,3]  R2056     -6.6745573282241821e-01
    z[7,3,3]  R2057     -5.3625065833330154e-02
    z[7,3,3]  R2058     -5.7023368775844574e-02
    z[7,3,3]  R2059     1.3739582896232605e-01
    z[7,3,3]  R2060     1.2602323293685913e-01
    z[7,3,3]  R2061     1.6580019891262054e-01
    z[7,3,3]  R2062     4.8164751380681992e-02
    z[7,3,3]  R2063     -1.5695963799953461e-01
    z[7,3,3]  R2064     5.0392758846282959e-01
    z[7,3,3]  R2065     -4.8290807008743286e-01
    z[7,3,3]  R2066     -4.1087540984153748e-01
    z[7,3,3]  R2067     -2.4842780828475952e-01
    z[7,3,3]  R2068     4.7737839818000793e-01
    z[7,3,3]  R2069     -3.4771889448165894e-01
    z[7,3,3]  R2070     3.4257954359054565e-01
    z[7,3,3]  R2071     0.376578152179718
    z[7,3,3]  R2072     -0.270519495010376
    z[7,3,3]  R2073     9.1828359290957451e-03
    z[7,3,3]  R2074     -9.3843534588813782e-02
    z[7,3,3]  R2075     1.2134262919425964e-01
    z[7,3,3]  R2076     1.5632796287536621e-01
    z[7,3,3]  R2077     1.5583147108554840e-01
    z[7,3,4]  R33       1
    z[7,3,4]  R69       -1
    z[7,3,4]  R1992     -1
    z[7,3,4]  R1993     1
    z[7,3,4]  R1998     8.8081859052181244e-02
    z[7,3,4]  R1999     4.2256745696067810e-01
    z[7,3,4]  R2000     4.9313545227050781e-01
    z[7,3,4]  R2001     1.0212492197751999e-01
    z[7,3,4]  R2002     9.8563842475414276e-02
    z[7,3,4]  R2003     3.8314953446388245e-01
    z[7,3,4]  R2004     6.5418505668640137e-01
    z[7,3,4]  R2005     5.4040521383285522e-02
    z[7,3,4]  R2006     -3.5474825650453568e-02
    z[7,3,4]  R2007     1.6338813304901123e-01
    z[7,3,4]  R2008     1.1716998182237148e-02
    z[7,3,4]  R2009     -2.0683860778808594e-01
    z[7,3,4]  R2010     2.3803491145372391e-02
    z[7,3,4]  R2011     2.1660542488098145e-01
    z[7,3,4]  R2012     5.1346683502197266e-01
    z[7,3,4]  R2013     -2.5644731521606445e-01
    z[7,3,4]  R2014     8.7570890784263611e-02
    z[7,3,4]  R2015     4.4482216238975525e-01
    z[7,3,4]  R2016     -1.8806131184101105e-01
    z[7,3,4]  R2017     3.8330635428428650e-01
    z[7,3,4]  R2018     2.7388921380043030e-01
    z[7,3,4]  R2019     -1.1197332292795181e-01
    z[7,3,4]  R2020     -7.5706982612609863e-01
    z[7,3,4]  R2021     -6.3856667280197144e-01
    z[7,3,4]  R2022     -5.2379405498504639e-01
    z[7,3,4]  R2023     -4.8556759953498840e-01
    z[7,3,4]  R2024     -3.9496758580207825e-01
    z[7,3,4]  R2025     1.3980881869792938e-01
    z[7,3,4]  R2026     -2.8170329332351685e-01
    z[7,3,4]  R2027     -1.0841037333011627e-01
    z[7,3,4]  R2028     -6.2899775803089142e-02
    z[7,3,4]  R2029     3.2857468724250793e-01
    z[7,3,4]  R2030     -0.607761025428772
    z[7,3,4]  R2031     -5.4443657398223877e-01
    z[7,3,4]  R2032     -5.0919461250305176e-01
    z[7,3,4]  R2033     -1.6262637078762054e-01
    z[7,3,4]  R2034     3.6612160503864288e-02
    z[7,3,4]  R2035     1.1570832133293152e-01
    z[7,3,4]  R2036     -2.0798210799694061e-01
    z[7,3,4]  R2037     6.3452489674091339e-02
    z[7,3,4]  R2038     3.0825203657150269e-01
    z[7,3,4]  R2039     0.101965993642807
    z[7,3,4]  R2040     -7.2813339531421661e-02
    z[7,3,4]  R2041     5.3983730077743530e-01
    z[7,3,4]  R2042     2.6378706097602844e-01
    z[7,3,4]  R2043     5.3849774599075317e-01
    z[7,3,4]  R2044     1.8499688804149628e-01
    z[7,3,4]  R2045     1.7156605422496796e-01
    z[7,3,4]  R2046     5.0421640276908875e-02
    z[7,3,4]  R2047     0.0775560736656189
    z[7,3,4]  R2048     9.6017621457576752e-02
    z[7,3,4]  R2049     -0.452067106962204
    z[7,3,4]  R2050     1.6617333889007568e-01
    z[7,3,4]  R2051     -1.8061715364456177e-01
    z[7,3,4]  R2052     7.5188815593719482e-02
    z[7,3,4]  R2053     -2.5747114419937134e-01
    z[7,3,4]  R2054     6.2724113464355469e-02
    z[7,3,4]  R2055     -7.3110930621623993e-02
    z[7,3,4]  R2056     1.9055263698101044e-01
    z[7,3,4]  R2057     -3.1058004498481750e-01
    z[7,3,4]  R2058     -2.2223468124866486e-01
    z[7,3,4]  R2059     -1.9229148328304291e-01
    z[7,3,4]  R2060     -5.6604868173599243e-01
    z[7,3,4]  R2061     -2.6208677887916565e-01
    z[7,3,4]  R2062     -5.1472359895706177e-01
    z[7,3,4]  R2063     -2.4435704946517944e-01
    z[7,3,4]  R2064     -4.8377969861030579e-01
    z[7,3,4]  R2065     -2.3590198159217834e-01
    z[7,3,4]  R2066     0.509386420249939
    z[7,3,4]  R2067     -4.3700519204139709e-01
    z[7,3,4]  R2068     -2.1561256051063538e-01
    z[7,3,4]  R2069     -1.8238714337348938e-01
    z[7,3,4]  R2070     -2.8487563133239746e-01
    z[7,3,4]  R2071     -5.8203574270009995e-02
    z[7,3,4]  R2072     4.1803520172834396e-02
    z[7,3,4]  R2073     1.7025732994079590e-01
    z[7,3,4]  R2074     -2.4461135268211365e-01
    z[7,3,4]  R2075     -1.7198120057582855e-01
    z[7,3,4]  R2076     1.3553853332996368e-01
    z[7,3,4]  R2077     3.7733739614486694e-01
    z[7,3,5]  R34       1
    z[7,3,5]  R70       -1
    z[7,3,5]  R1994     -1
    z[7,3,5]  R1995     1
    z[7,3,5]  R1998     1.9620141386985779e-01
    z[7,3,5]  R1999     4.6732330322265625e-01
    z[7,3,5]  R2000     0.257762610912323
    z[7,3,5]  R2001     3.2977280020713806e-01
    z[7,3,5]  R2002     2.7991998195648193e-01
    z[7,3,5]  R2003     -9.0255342423915863e-02
    z[7,3,5]  R2004     2.5046941637992859e-01
    z[7,3,5]  R2005     4.2706301808357239e-01
    z[7,3,5]  R2006     -9.5430992543697357e-02
    z[7,3,5]  R2007     -1.2117945402860641e-01
    z[7,3,5]  R2008     0.194473534822464
    z[7,3,5]  R2009     -3.3332142233848572e-01
    z[7,3,5]  R2010     -1.4950575307011604e-02
    z[7,3,5]  R2011     -2.0976434648036957e-01
    z[7,3,5]  R2012     -0.0895463153719902
    z[7,3,5]  R2013     -1.3865956664085388e-01
    z[7,3,5]  R2014     -3.8939729332923889e-01
    z[7,3,5]  R2015     -5.1084810495376587e-01
    z[7,3,5]  R2016     2.5415942072868347e-01
    z[7,3,5]  R2017     2.4926245212554932e-01
    z[7,3,5]  R2018     3.1599956750869751e-01
    z[7,3,5]  R2019     1.9042393192648888e-02
    z[7,3,5]  R2020     -1.4626312255859375e-01
    z[7,3,5]  R2021     -4.3257924914360046e-01
    z[7,3,5]  R2022     -5.2931028604507446e-01
    z[7,3,5]  R2023     -2.4646340310573578e-01
    z[7,3,5]  R2024     6.6729128360748291e-01
    z[7,3,5]  R2025     -5.0630003213882446e-01
    z[7,3,5]  R2026     6.9655174016952515e-01
    z[7,3,5]  R2027     1.9682997465133667e-01
    z[7,3,5]  R2028     4.1747590899467468e-01
    z[7,3,5]  R2029     -4.2000961303710938e-01
    z[7,3,5]  R2030     2.3197035491466522e-01
    z[7,3,5]  R2031     -3.1511966139078140e-02
    z[7,3,5]  R2032     -4.5322397351264954e-01
    z[7,3,5]  R2033     4.6095319092273712e-02
    z[7,3,5]  R2034     7.3622646741569042e-03
    z[7,3,5]  R2035     -1.3261437416076660e-01
    z[7,3,5]  R2036     3.0438652634620667e-01
    z[7,3,5]  R2037     4.9425348639488220e-01
    z[7,3,5]  R2038     0.288438618183136
    z[7,3,5]  R2039     7.3415338993072510e-02
    z[7,3,5]  R2040     3.1598886847496033e-01
    z[7,3,5]  R2041     2.9113727807998657e-01
    z[7,3,5]  R2042     5.9622806310653687e-01
    z[7,3,5]  R2043     3.8937801122665405e-01
    z[7,3,5]  R2044     1.0548871755599976e-01
    z[7,3,5]  R2045     -3.0654066801071167e-01
    z[7,3,5]  R2046     -1.3580715656280518e-01
    z[7,3,5]  R2047     2.7249258756637573e-01
    z[7,3,5]  R2048     -1.0735871642827988e-01
    z[7,3,5]  R2049     -5.4265994578599930e-02
    z[7,3,5]  R2050     -4.0690630674362183e-01
    z[7,3,5]  R2051     -5.0688081979751587e-01
    z[7,3,5]  R2052     -3.9016571640968323e-01
    z[7,3,5]  R2053     2.6489531993865967e-01
    z[7,3,5]  R2054     -2.3758928477764130e-01
    z[7,3,5]  R2055     -1.5222407877445221e-01
    z[7,3,5]  R2056     -1.7769478261470795e-01
    z[7,3,5]  R2057     -5.3262615203857422e-01
    z[7,3,5]  R2058     -3.4445360302925110e-01
    z[7,3,5]  R2059     -2.3536950349807739e-02
    z[7,3,5]  R2060     -4.9152320623397827e-01
    z[7,3,5]  R2061     -3.7724217772483826e-01
    z[7,3,5]  R2062     -8.8155664503574371e-02
    z[7,3,5]  R2063     6.2642043828964233e-01
    z[7,3,5]  R2064     9.6060521900653839e-02
    z[7,3,5]  R2065     3.6358323693275452e-01
    z[7,3,5]  R2066     1.1877653747797012e-01
    z[7,3,5]  R2067     4.1252571344375610e-01
    z[7,3,5]  R2068     -2.3521672189235687e-01
    z[7,3,5]  R2069     3.4173348546028137e-01
    z[7,3,5]  R2070     -2.1266996860504150e-01
    z[7,3,5]  R2071     1.3347616791725159e-01
    z[7,3,5]  R2072     -1.7888711392879486e-01
    z[7,3,5]  R2073     -5.8507549762725830e-01
    z[7,3,5]  R2074     3.9482930302619934e-01
    z[7,3,5]  R2075     -1.5781989693641663e-01
    z[7,3,5]  R2076     3.6871945858001709e-01
    z[7,3,5]  R2077     -2.8889900445938110e-01
    z[7,3,6]  R35       1
    z[7,3,6]  R71       -1
    z[7,3,6]  R1996     -1
    z[7,3,6]  R1997     1
    z[7,3,6]  R1998     2.2123497724533081e-01
    z[7,3,6]  R1999     -1.9174998998641968e-01
    z[7,3,6]  R2000     0.0460628941655159
    z[7,3,6]  R2001     -1.5734435617923737e-01
    z[7,3,6]  R2002     4.7708559036254883e-01
    z[7,3,6]  R2003     -6.5209582448005676e-02
    z[7,3,6]  R2004     -2.3663861677050591e-02
    z[7,3,6]  R2005     -1.2370146811008453e-01
    z[7,3,6]  R2006     1.2677356600761414e-01
    z[7,3,6]  R2007     -2.3039312660694122e-01
    z[7,3,6]  R2008     -1.3164682686328888e-01
    z[7,3,6]  R2009     2.1696081757545471e-01
    z[7,3,6]  R2010     2.6832911372184753e-01
    z[7,3,6]  R2011     -1.3177742250263691e-02
    z[7,3,6]  R2012     3.0612629652023315e-01
    z[7,3,6]  R2013     -1.2251044809818268e-01
    z[7,3,6]  R2014     2.6547789573669434e-01
    z[7,3,6]  R2015     0.0589272603392601
    z[7,3,6]  R2016     -4.9622341990470886e-01
    z[7,3,6]  R2017     -3.6355575919151306e-01
    z[7,3,6]  R2018     4.4139412045478821e-01
    z[7,3,6]  R2019     2.6935037970542908e-01
    z[7,3,6]  R2020     -1.2859410047531128e-01
    z[7,3,6]  R2021     1.3162109255790710e-01
    z[7,3,6]  R2022     3.3296972513198853e-02
    z[7,3,6]  R2023     -5.1404148340225220e-01
    z[7,3,6]  R2024     3.3346044365316629e-03
    z[7,3,6]  R2025     -1.9768282771110535e-01
    z[7,3,6]  R2026     2.7940711379051208e-01
    z[7,3,6]  R2027     -4.1030306369066238e-02
    z[7,3,6]  R2028     4.2660921812057495e-01
    z[7,3,6]  R2029     3.8344833254814148e-01
    z[7,3,6]  R2030     -1.2711404263973236e-01
    z[7,3,6]  R2031     -4.1706174612045288e-01
    z[7,3,6]  R2032     -6.1860390007495880e-02
    z[7,3,6]  R2033     -1.2872008979320526e-01
    z[7,3,6]  R2034     5.2757188677787781e-02
    z[7,3,6]  R2035     -1.8861402571201324e-01
    z[7,3,6]  R2036     2.2779045999050140e-01
    z[7,3,6]  R2037     3.3120752777904272e-03
    z[7,3,6]  R2038     -1.0111232101917267e-01
    z[7,3,6]  R2039     1.3224272429943085e-01
    z[7,3,6]  R2040     2.6924493908882141e-01
    z[7,3,6]  R2041     3.9693927764892578e-01
    z[7,3,6]  R2042     1.9151189923286438e-01
    z[7,3,6]  R2043     -3.8249734044075012e-01
    z[7,3,6]  R2044     -1.8938811123371124e-01
    z[7,3,6]  R2045     -3.3034953474998474e-01
    z[7,3,6]  R2046     -4.2161145806312561e-01
    z[7,3,6]  R2047     -2.3401927947998047e-01
    z[7,3,6]  R2048     1.3225534558296204e-01
    z[7,3,6]  R2049     -7.7248126268386841e-02
    z[7,3,6]  R2050     5.7576749473810196e-02
    z[7,3,6]  R2051     6.1256840825080872e-02
    z[7,3,6]  R2052     5.2010113000869751e-01
    z[7,3,6]  R2053     4.6250253915786743e-01
    z[7,3,6]  R2054     -1.0021121054887772e-01
    z[7,3,6]  R2055     -4.1702026128768921e-01
    z[7,3,6]  R2056     -9.3552783131599426e-02
    z[7,3,6]  R2057     -3.3364757895469666e-01
    z[7,3,6]  R2058     1.2438180297613144e-01
    z[7,3,6]  R2059     -1.7168733477592468e-01
    z[7,3,6]  R2060     2.8000321984291077e-01
    z[7,3,6]  R2061     4.7164449095726013e-01
    z[7,3,6]  R2062     3.0716332793235779e-01
    z[7,3,6]  R2063     -2.8244480490684509e-02
    z[7,3,6]  R2064     3.7792941927909851e-01
    z[7,3,6]  R2065     -1.3606618344783783e-01
    z[7,3,6]  R2066     -1.7522041499614716e-01
    z[7,3,6]  R2067     1.2355015426874161e-01
    z[7,3,6]  R2068     3.5263389348983765e-01
    z[7,3,6]  R2069     -3.6459651589393616e-01
    z[7,3,6]  R2070     1.8081568181514740e-01
    z[7,3,6]  R2071     2.4590662121772766e-01
    z[7,3,6]  R2072     1.0105468332767487e-01
    z[7,3,6]  R2073     0.163529634475708
    z[7,3,6]  R2074     5.2980917692184448e-01
    z[7,3,6]  R2075     5.0102514028549194e-01
    z[7,3,6]  R2076     3.3948723226785660e-02
    z[7,3,6]  R2077     -2.3816585540771484e-02
    z[4,5,0]  R38       -1
    z[4,5,0]  R47       1
    z[4,5,0]  R2132     -1
    z[4,5,0]  R2133     1
    z[4,5,0]  R2146     -1.3544252514839172e-01
    z[4,5,0]  R2147     3.7151578068733215e-01
    z[4,5,0]  R2148     4.6744519472122192e-01
    z[4,5,0]  R2149     3.8565129041671753e-01
    z[4,5,0]  R2150     2.2729112207889557e-01
    z[4,5,0]  R2151     3.9012342691421509e-02
    z[4,5,0]  R2152     -3.9402687549591064e-01
    z[4,5,0]  R2153     3.7529698014259338e-01
    z[4,5,0]  R2154     -2.4144466221332550e-01
    z[4,5,0]  R2155     -4.5150774717330933e-01
    z[4,5,0]  R2156     -0.0822141021490097
    z[4,5,0]  R2157     -3.6437591910362244e-01
    z[4,5,0]  R2158     2.1702052652835846e-01
    z[4,5,0]  R2159     -1.5074262022972107e-01
    z[4,5,0]  R2160     -4.3471691012382507e-01
    z[4,5,0]  R2161     -4.4951498508453369e-01
    z[4,5,0]  R2162     4.3127852678298950e-01
    z[4,5,0]  R2163     1.6457749903202057e-01
    z[4,5,0]  R2164     1.2404111027717590e-01
    z[4,5,0]  R2165     1.3128182291984558e-01
    z[4,5,0]  R2166     4.8252713680267334e-01
    z[4,5,0]  R2167     3.9966791868209839e-01
    z[4,5,0]  R2168     0.402807354927063
    z[4,5,0]  R2169     0.506476879119873
    z[4,5,0]  R2170     3.8504651188850403e-01
    z[4,5,0]  R2171     8.1525808572769165e-01
    z[4,5,0]  R2172     1.3341283798217773e-01
    z[4,5,0]  R2173     7.1224117279052734e-01
    z[4,5,0]  R2174     1.9481061398983002e-01
    z[4,5,0]  R2175     -1.5624713897705078e-01
    z[4,5,0]  R2176     1.8087498843669891e-02
    z[4,5,0]  R2177     -2.4753254652023315e-01
    z[4,5,0]  R2178     -1.8546250462532043e-01
    z[4,5,0]  R2179     -5.6664252281188965e-01
    z[4,5,0]  R2180     -4.5358520746231079e-01
    z[4,5,0]  R2181     -3.3044105768203735e-01
    z[4,5,0]  R2182     -7.2640764713287354e-01
    z[4,5,0]  R2183     -0.276757150888443
    z[4,5,0]  R2184     -3.7866771221160889e-01
    z[4,5,0]  R2185     -5.9387886524200439e-01
    z[4,5,0]  R2186     -2.3243264853954315e-01
    z[4,5,0]  R2187     -4.6389874815940857e-01
    z[4,5,0]  R2188     -5.6616473197937012e-01
    z[4,5,0]  R2189     0.01770637370646
    z[4,5,0]  R2190     -0.0440821535885334
    z[4,5,0]  R2191     -1.9195194542407990e-01
    z[4,5,0]  R2192     1.2960492074489594e-01
    z[4,5,0]  R2193     1.6947485506534576e-01
    z[4,5,0]  R2194     1.3789768517017365e-01
    z[4,5,0]  R2195     -2.1324107050895691e-01
    z[4,5,0]  R2196     5.0671076774597168e-01
    z[4,5,0]  R2197     -1.9885918498039246e-01
    z[4,5,0]  R2198     -3.0448371171951294e-01
    z[4,5,0]  R2199     -5.0142383575439453e-01
    z[4,5,0]  R2200     -5.4543703794479370e-01
    z[4,5,0]  R2201     -4.7971585392951965e-01
    z[4,5,1]  R39       -1
    z[4,5,1]  R48       1
    z[4,5,1]  R2134     -1
    z[4,5,1]  R2135     1
    z[4,5,1]  R2146     5.9941875934600830e-01
    z[4,5,1]  R2147     5.3524309396743774e-01
    z[4,5,1]  R2148     5.9997326135635376e-01
    z[4,5,1]  R2149     3.2528099417686462e-01
    z[4,5,1]  R2150     -4.5928034186363220e-01
    z[4,5,1]  R2151     5.6652998924255371e-01
    z[4,5,1]  R2152     5.0626343488693237e-01
    z[4,5,1]  R2153     -4.8687958717346191e-01
    z[4,5,1]  R2154     4.6423014998435974e-01
    z[4,5,1]  R2155     3.9923894405364990e-01
    z[4,5,1]  R2156     3.7479737401008606e-01
    z[4,5,1]  R2157     5.6444448232650757e-01
    z[4,5,1]  R2158     1.4548103511333466e-01
    z[4,5,1]  R2159     3.9232549071311951e-01
    z[4,5,1]  R2160     0.671127200126648
    z[4,5,1]  R2161     5.6460309028625488e-01
    z[4,5,1]  R2162     -6.0256713628768921e-01
    z[4,5,1]  R2163     -6.9524329900741577e-01
    z[4,5,1]  R2164     -4.3254745006561279e-01
    z[4,5,1]  R2165     -8.9349585771560669e-01
    z[4,5,1]  R2166     -2.9579332470893860e-01
    z[4,5,1]  R2167     -3.3140763640403748e-01
    z[4,5,1]  R2168     3.6768081784248352e-01
    z[4,5,1]  R2169     -3.8896843791007996e-02
    z[4,5,1]  R2170     -3.9393520355224609e-01
    z[4,5,1]  R2171     -0.417843759059906
    z[4,5,1]  R2172     2.1209548413753510e-01
    z[4,5,1]  R2173     -5.1100033521652222e-01
    z[4,5,1]  R2174     8.0563133955001831e-01
    z[4,5,1]  R2175     8.0624979734420776e-01
    z[4,5,1]  R2176     5.9764266014099121e-01
    z[4,5,1]  R2177     4.2195639014244080e-01
    z[4,5,1]  R2178     3.9931362867355347e-01
    z[4,5,1]  R2179     4.5708245038986206e-01
    z[4,5,1]  R2180     4.1171273589134216e-01
    z[4,5,1]  R2181     4.4868674874305725e-01
    z[4,5,1]  R2182     4.4769674539566040e-01
    z[4,5,1]  R2183     -4.8848456144332886e-01
    z[4,5,1]  R2184     1.7885313928127289e-01
    z[4,5,1]  R2185     -7.0007240772247314e-01
    z[4,5,1]  R2186     7.5460141897201538e-01
    z[4,5,1]  R2187     7.0336228609085083e-01
    z[4,5,1]  R2188     7.3183369636535645e-01
    z[4,5,1]  R2189     6.8371903896331787e-01
    z[4,5,1]  R2190     7.2825807332992554e-01
    z[4,5,1]  R2191     6.1534881591796875e-01
    z[4,5,1]  R2192     5.5842143297195435e-01
    z[4,5,1]  R2193     6.6320836544036865e-01
    z[4,5,1]  R2194     5.2656018733978271e-01
    z[4,5,1]  R2195     0.50145024061203
    z[4,5,1]  R2196     0.673224151134491
    z[4,5,1]  R2197     0.654941976070404
    z[4,5,1]  R2198     -6.9678771495819092e-01
    z[4,5,1]  R2199     -6.7250436544418335e-01
    z[4,5,1]  R2200     -5.7821273803710938e-01
    z[4,5,1]  R2201     -6.0361069440841675e-01
    z[4,5,2]  R40       -1
    z[4,5,2]  R49       1
    z[4,5,2]  R2136     -1
    z[4,5,2]  R2137     1
    z[4,5,2]  R2146     4.7314766049385071e-01
    z[4,5,2]  R2147     6.4146476984024048e-01
    z[4,5,2]  R2148     3.4393441677093506e-01
    z[4,5,2]  R2149     -5.5661749839782715e-01
    z[4,5,2]  R2150     7.3411154747009277e-01
    z[4,5,2]  R2151     -7.3292267322540283e-01
    z[4,5,2]  R2152     -2.2035045921802521e-01
    z[4,5,2]  R2153     0.354841947555542
    z[4,5,2]  R2154     -4.4543719291687012e-01
    z[4,5,2]  R2155     -4.6101558208465576e-01
    z[4,5,2]  R2156     -3.0765122175216675e-01
    z[4,5,2]  R2157     -4.0702033042907715e-01
    z[4,5,2]  R2158     9.9146686494350433e-02
    z[4,5,2]  R2159     -1.1688224039971828e-02
    z[4,5,2]  R2160     1.8368528783321381e-01
    z[4,5,2]  R2161     -2.7939698100090027e-01
    z[4,5,2]  R2162     -2.1570718288421631e-01
    z[4,5,2]  R2163     2.5934013724327087e-01
    z[4,5,2]  R2164     1.0537172108888626e-01
    z[4,5,2]  R2165     -1.0331146419048309e-01
    z[4,5,2]  R2166     6.5029317140579224e-01
    z[4,5,2]  R2167     2.3039247095584869e-01
    z[4,5,2]  R2168     5.5591195821762085e-01
    z[4,5,2]  R2169     3.4478139877319336e-01
    z[4,5,2]  R2170     4.7812196612358093e-01
    z[4,5,2]  R2171     3.3615015447139740e-02
    z[4,5,2]  R2172     5.6970185041427612e-01
    z[4,5,2]  R2173     -1.1947441101074219e-01
    z[4,5,2]  R2174     -3.0314254760742188e-01
    z[4,5,2]  R2175     -4.1481822729110718e-02
    z[4,5,2]  R2176     1.9685681164264679e-01
    z[4,5,2]  R2177     -2.0552419126033783e-01
    z[4,5,2]  R2178     -1.6960366070270538e-01
    z[4,5,2]  R2179     -2.7856704592704773e-01
    z[4,5,2]  R2180     -2.1651954948902130e-01
    z[4,5,2]  R2181     3.3400931954383850e-01
    z[4,5,2]  R2182     2.2183121740818024e-01
    z[4,5,2]  R2183     -4.7147122025489807e-01
    z[4,5,2]  R2184     -3.6279717087745667e-01
    z[4,5,2]  R2185     -1.6546821594238281e-01
    z[4,5,2]  R2186     -2.2869546711444855e-01
    z[4,5,2]  R2187     6.2293823808431625e-02
    z[4,5,2]  R2188     1.7335507273674011e-01
    z[4,5,2]  R2189     4.2720317840576172e-01
    z[4,5,2]  R2190     -2.0526179671287537e-01
    z[4,5,2]  R2191     2.8183031082153320e-01
    z[4,5,2]  R2192     -2.2353968024253845e-01
    z[4,5,2]  R2193     3.6107987165451050e-01
    z[4,5,2]  R2194     -1.0032659024000168e-01
    z[4,5,2]  R2195     -2.8439259529113770e-01
    z[4,5,2]  R2196     -5.0510197877883911e-01
    z[4,5,2]  R2197     -2.8678017854690552e-01
    z[4,5,2]  R2198     1.0988084971904755e-01
    z[4,5,2]  R2199     -1.1029504239559174e-01
    z[4,5,2]  R2200     1.6776882112026215e-01
    z[4,5,2]  R2201     2.3622474074363708e-01
    z[4,5,3]  R41       -1
    z[4,5,3]  R50       1
    z[4,5,3]  R2138     -1
    z[4,5,3]  R2139     1
    z[4,5,3]  R2146     -2.4220316112041473e-01
    z[4,5,3]  R2147     6.1942975968122482e-02
    z[4,5,3]  R2148     1.1200608313083649e-01
    z[4,5,3]  R2149     -9.1599315404891968e-02
    z[4,5,3]  R2150     3.8009887933731079e-01
    z[4,5,3]  R2151     1.6812488436698914e-01
    z[4,5,3]  R2152     -3.6225453019142151e-01
    z[4,5,3]  R2153     4.8625072836875916e-01
    z[4,5,3]  R2154     -2.2988341748714447e-01
    z[4,5,3]  R2155     -5.0863057374954224e-01
    z[4,5,3]  R2156     1.8882469832897186e-01
    z[4,5,3]  R2157     -9.0798944234848022e-02
    z[4,5,3]  R2158     -4.2324650287628174e-01
    z[4,5,3]  R2159     2.4133273959159851e-01
    z[4,5,3]  R2160     7.0253565907478333e-02
    z[4,5,3]  R2161     -1.6083383560180664e-01
    z[4,5,3]  R2162     -1.9417789578437805e-01
    z[4,5,3]  R2163     -3.5769420862197876e-01
    z[4,5,3]  R2164     -4.0315032005310059e-01
    z[4,5,3]  R2165     7.3971413075923920e-02
    z[4,5,3]  R2166     3.3118334412574768e-01
    z[4,5,3]  R2167     5.2328133583068848e-01
    z[4,5,3]  R2168     6.3107900321483612e-02
    z[4,5,3]  R2169     -3.7122715730220079e-03
    z[4,5,3]  R2170     1.1415149271488190e-01
    z[4,5,3]  R2171     2.2451011836528778e-01
    z[4,5,3]  R2172     3.1727319955825806e-01
    z[4,5,3]  R2173     -1.0649629682302475e-01
    z[4,5,3]  R2174     1.8137918412685394e-01
    z[4,5,3]  R2175     4.3290373682975769e-01
    z[4,5,3]  R2176     -3.4623432159423828e-01
    z[4,5,3]  R2177     -0.375354528427124
    z[4,5,3]  R2178     -6.7517482675611973e-03
    z[4,5,3]  R2179     -3.3685654401779175e-01
    z[4,5,3]  R2180     -4.8288854956626892e-01
    z[4,5,3]  R2181     -2.4150630831718445e-01
    z[4,5,3]  R2182     1.5619641542434692e-01
    z[4,5,3]  R2183     -1.4916208386421204e-01
    z[4,5,3]  R2184     -2.1368719637393951e-01
    z[4,5,3]  R2185     -2.2419057786464691e-01
    z[4,5,3]  R2186     -4.1027626395225525e-01
    z[4,5,3]  R2187     3.5584408789873123e-02
    z[4,5,3]  R2188     -2.5215500593185425e-01
    z[4,5,3]  R2189     -0.0723184123635292
    z[4,5,3]  R2190     -4.9420168995857239e-01
    z[4,5,3]  R2191     2.2640155255794525e-01
    z[4,5,3]  R2192     -1.4711397886276245e-01
    z[4,5,3]  R2193     4.0763825178146362e-01
    z[4,5,3]  R2194     2.9277700185775757e-01
    z[4,5,3]  R2195     5.6977385282516479e-01
    z[4,5,3]  R2196     -1.2279611080884933e-02
    z[4,5,3]  R2197     -3.3612366765737534e-02
    z[4,5,3]  R2198     3.4877711534500122e-01
    z[4,5,3]  R2199     -3.0873927474021912e-01
    z[4,5,3]  R2200     -4.2799431085586548e-01
    z[4,5,3]  R2201     -5.2732646465301514e-01
    z[4,5,4]  R42       -1
    z[4,5,4]  R51       1
    z[4,5,4]  R2140     -1
    z[4,5,4]  R2141     1
    z[4,5,4]  R2146     2.8842657804489136e-01
    z[4,5,4]  R2147     -3.5000029206275940e-01
    z[4,5,4]  R2148     1.9966131448745728e-01
    z[4,5,4]  R2149     -4.4427019357681274e-01
    z[4,5,4]  R2150     1.9556620717048645e-01
    z[4,5,4]  R2151     -2.0001649856567383e-01
    z[4,5,4]  R2152     5.0343668460845947e-01
    z[4,5,4]  R2153     -1.6372986137866974e-01
    z[4,5,4]  R2154     3.1951498240232468e-03
    z[4,5,4]  R2155     -3.9187619090080261e-01
    z[4,5,4]  R2156     3.1968098878860474e-01
    z[4,5,4]  R2157     -5.4483091831207275e-01
    z[4,5,4]  R2158     5.3580832481384277e-01
    z[4,5,4]  R2159     -8.9582674205303192e-02
    z[4,5,4]  R2160     -1.2088719755411148e-01
    z[4,5,4]  R2161     1.6698222607374191e-02
    z[4,5,4]  R2162     4.3900626897811890e-01
    z[4,5,4]  R2163     0.0387524850666523
    z[4,5,4]  R2164     -1.5400440990924835e-01
    z[4,5,4]  R2165     -2.8708747029304504e-01
    z[4,5,4]  R2166     9.4280634075403214e-03
    z[4,5,4]  R2167     2.9374551773071289e-01
    z[4,5,4]  R2168     1.9206385314464569e-01
    z[4,5,4]  R2169     5.6137222051620483e-01
    z[4,5,4]  R2170     6.7019534111022949e-01
    z[4,5,4]  R2171     -2.3307195305824280e-01
    z[4,5,4]  R2172     6.1939394474029541e-01
    z[4,5,4]  R2173     2.3664748668670654e-01
    z[4,5,4]  R2174     3.9568841457366943e-01
    z[4,5,4]  R2175     1.7387686669826508e-01
    z[4,5,4]  R2176     -4.8594778776168823e-01
    z[4,5,4]  R2177     -7.3324447870254517e-01
    z[4,5,4]  R2178     -4.2227414250373840e-01
    z[4,5,4]  R2179     -4.9721163511276245e-01
    z[4,5,4]  R2180     -2.3260879516601562e-01
    z[4,5,4]  R2181     1.9123084843158722e-01
    z[4,5,4]  R2182     -3.1898370385169983e-01
    z[4,5,4]  R2183     4.3852204084396362e-01
    z[4,5,4]  R2184     6.9909161329269409e-01
    z[4,5,4]  R2185     6.7884959280490875e-02
    z[4,5,4]  R2186     -3.6485812067985535e-01
    z[4,5,4]  R2187     -5.1581335067749023e-01
    z[4,5,4]  R2188     1.2401795387268066e-01
    z[4,5,4]  R2189     2.2467546164989471e-01
    z[4,5,4]  R2190     2.3399452865123749e-01
    z[4,5,4]  R2191     -3.7361967563629150e-01
    z[4,5,4]  R2192     -5.3972554206848145e-01
    z[4,5,4]  R2193     -3.5437917709350586e-01
    z[4,5,4]  R2194     -7.3020040988922119e-01
    z[4,5,4]  R2195     1.8432773649692535e-02
    z[4,5,4]  R2196     -1.6219811141490936e-01
    z[4,5,4]  R2197     -3.4186261892318726e-01
    z[4,5,4]  R2198     -1.4937274158000946e-01
    z[4,5,4]  R2199     -1.9341942667961121e-01
    z[4,5,4]  R2200     2.0830312743782997e-02
    z[4,5,4]  R2201     -9.0662986040115356e-02
    z[4,5,5]  R43       -1
    z[4,5,5]  R52       1
    z[4,5,5]  R2142     -1
    z[4,5,5]  R2143     1
    z[4,5,5]  R2146     2.6128500699996948e-02
    z[4,5,5]  R2147     7.1706078946590424e-02
    z[4,5,5]  R2148     4.9888265132904053e-01
    z[4,5,5]  R2149     4.6686807274818420e-01
    z[4,5,5]  R2150     -6.0093704611063004e-02
    z[4,5,5]  R2151     -2.4372828006744385e-01
    z[4,5,5]  R2152     -1.6527295112609863e-01
    z[4,5,5]  R2153     -0.0574694387614727
    z[4,5,5]  R2154     -1.0356678813695908e-01
    z[4,5,5]  R2155     8.7697193026542664e-02
    z[4,5,5]  R2156     -0.725053608417511
    z[4,5,5]  R2157     -2.0311726629734039e-01
    z[4,5,5]  R2158     -2.9575619101524353e-01
    z[4,5,5]  R2159     -0.324920654296875
    z[4,5,5]  R2160     -3.4698531031608582e-01
    z[4,5,5]  R2161     -2.9969671368598938e-01
    z[4,5,5]  R2162     4.1022595763206482e-01
    z[4,5,5]  R2163     5.3775095939636230e-01
    z[4,5,5]  R2164     5.9714996814727783e-01
    z[4,5,5]  R2165     -4.7690412029623985e-03
    z[4,5,5]  R2166     3.8242614269256592e-01
    z[4,5,5]  R2167     5.0597274303436279e-01
    z[4,5,5]  R2168     5.9371012449264526e-01
    z[4,5,5]  R2169     5.5435377359390259e-01
    z[4,5,5]  R2170     -3.4342953003942966e-03
    z[4,5,5]  R2171     9.8959669470787048e-02
    z[4,5,5]  R2172     2.9374006390571594e-01
    z[4,5,5]  R2173     3.2743221521377563e-01
    z[4,5,5]  R2174     1.5588788688182831e-01
    z[4,5,5]  R2175     3.2585912942886353e-01
    z[4,5,5]  R2176     -3.5222217440605164e-01
    z[4,5,5]  R2177     -7.2058849036693573e-02
    z[4,5,5]  R2178     -7.6254093647003174e-01
    z[4,5,5]  R2179     -1.7625318467617035e-01
    z[4,5,5]  R2180     -5.0293862819671631e-01
    z[4,5,5]  R2181     -6.7311418056488037e-01
    z[4,5,5]  R2182     -2.0385213196277618e-01
    z[4,5,5]  R2183     -1.0849576443433762e-01
    z[4,5,5]  R2184     -3.8317084312438965e-01
    z[4,5,5]  R2185     2.3181456327438354e-01
    z[4,5,5]  R2186     1.2535206973552704e-01
    z[4,5,5]  R2187     -7.0958539843559265e-02
    z[4,5,5]  R2188     -1.7830401659011841e-01
    z[4,5,5]  R2189     -5.1603770256042480e-01
    z[4,5,5]  R2190     -2.8873044252395630e-01
    z[4,5,5]  R2191     -5.5137360095977783e-01
    z[4,5,5]  R2192     1.7858842015266418e-01
    z[4,5,5]  R2193     -3.3059626817703247e-01
    z[4,5,5]  R2194     -2.7245754003524780e-01
    z[4,5,5]  R2195     -4.0308335423469543e-01
    z[4,5,5]  R2196     4.5589298009872437e-02
    z[4,5,5]  R2197     -5.7330334186553955e-01
    z[4,5,5]  R2198     -5.0638669729232788e-01
    z[4,5,5]  R2199     3.8519567251205444e-01
    z[4,5,5]  R2200     3.9548525214195251e-01
    z[4,5,5]  R2201     2.0005165040493011e-01
    z[4,5,6]  R44       -1
    z[4,5,6]  R53       1
    z[4,5,6]  R2144     -1
    z[4,5,6]  R2145     1
    z[4,5,6]  R2146     -5.0591373443603516e-01
    z[4,5,6]  R2147     -1.8037442862987518e-01
    z[4,5,6]  R2148     -4.4070344418287277e-02
    z[4,5,6]  R2149     -1.0913307219743729e-01
    z[4,5,6]  R2150     -1.1021775007247925e-01
    z[4,5,6]  R2151     -1.1256178468465805e-01
    z[4,5,6]  R2152     -3.5762250423431396e-01
    z[4,5,6]  R2153     -4.7920525074005127e-01
    z[4,5,6]  R2154     -6.8132072687149048e-01
    z[4,5,6]  R2155     6.5198019146919250e-02
    z[4,5,6]  R2156     3.0751428008079529e-01
    z[4,5,6]  R2157     -1.9137734174728394e-01
    z[4,5,6]  R2158     6.0680097341537476e-01
    z[4,5,6]  R2159     8.0708169937133789e-01
    z[4,5,6]  R2160     4.3234363198280334e-01
    z[4,5,6]  R2161     5.3397798538208008e-01
    z[4,5,6]  R2162     7.5266867876052856e-02
    z[4,5,6]  R2163     -6.0586854815483093e-02
    z[4,5,6]  R2164     4.9353587627410889e-01
    z[4,5,6]  R2165     2.9299014806747437e-01
    z[4,5,6]  R2166     2.7778422459959984e-02
    z[4,5,6]  R2167     -2.4745856225490570e-01
    z[4,5,6]  R2168     1.2494678609073162e-02
    z[4,5,6]  R2169     2.5164343416690826e-02
    z[4,5,6]  R2170     7.5825154781341553e-02
    z[4,5,6]  R2171     2.1239224076271057e-01
    z[4,5,6]  R2172     -2.0509015023708344e-01
    z[4,5,6]  R2173     2.0678873360157013e-01
    z[4,5,6]  R2174     -8.5689671337604523e-02
    z[4,5,6]  R2175     2.1212226711213589e-03
    z[4,5,6]  R2176     3.5165277123451233e-01
    z[4,5,6]  R2177     1.8630404770374298e-01
    z[4,5,6]  R2178     1.3250321149826050e-01
    z[4,5,6]  R2179     2.5208277627825737e-02
    z[4,5,6]  R2180     1.9400231540203094e-01
    z[4,5,6]  R2181     1.7305904626846313e-01
    z[4,5,6]  R2182     -0.234492689371109
    z[4,5,6]  R2183     -4.8598459362983704e-01
    z[4,5,6]  R2184     -1.0857817530632019e-01
    z[4,5,6]  R2185     -1.4566726982593536e-01
    z[4,5,6]  R2186     8.4196001291275024e-02
    z[4,5,6]  R2187     -1.1761871725320816e-01
    z[4,5,6]  R2188     -5.5409427732229233e-02
    z[4,5,6]  R2189     1.6645808517932892e-01
    z[4,5,6]  R2190     2.0787145197391510e-01
    z[4,5,6]  R2191     1.0104341804981232e-01
    z[4,5,6]  R2192     5.2588790655136108e-01
    z[4,5,6]  R2193     -2.5872574187815189e-03
    z[4,5,6]  R2194     2.2560091689229012e-02
    z[4,5,6]  R2195     -3.6706754565238953e-01
    z[4,5,6]  R2196     7.9674273729324341e-02
    z[4,5,6]  R2197     5.0857108086347580e-02
    z[4,5,6]  R2198     -9.6527636051177979e-02
    z[4,5,6]  R2199     -5.5138994008302689e-02
    z[4,5,6]  R2200     -0.000664629100356251
    z[4,5,6]  R2201     1.5300613641738892e-01
    z[5,4,0]  R38       1
    z[5,4,0]  R47       -1
    z[5,4,0]  R2202     -1
    z[5,4,0]  R2203     1
    z[5,4,0]  R2216     4.8252713680267334e-01
    z[5,4,0]  R2217     3.9966791868209839e-01
    z[5,4,0]  R2218     0.402807354927063
    z[5,4,0]  R2219     0.506476879119873
    z[5,4,0]  R2220     3.8504651188850403e-01
    z[5,4,0]  R2221     8.1525808572769165e-01
    z[5,4,0]  R2222     1.3341283798217773e-01
    z[5,4,0]  R2223     7.1224117279052734e-01
    z[5,4,0]  R2224     1.9481061398983002e-01
    z[5,4,0]  R2225     -1.5624713897705078e-01
    z[5,4,0]  R2226     1.8087498843669891e-02
    z[5,4,0]  R2227     -2.4753254652023315e-01
    z[5,4,0]  R2228     -1.8546250462532043e-01
    z[5,4,0]  R2229     -5.6664252281188965e-01
    z[5,4,0]  R2230     -4.5358520746231079e-01
    z[5,4,0]  R2231     -3.3044105768203735e-01
    z[5,4,0]  R2232     -7.2640764713287354e-01
    z[5,4,0]  R2233     -0.276757150888443
    z[5,4,0]  R2234     -3.7866771221160889e-01
    z[5,4,0]  R2235     -5.9387886524200439e-01
    z[5,4,0]  R2236     -2.3243264853954315e-01
    z[5,4,0]  R2237     -4.6389874815940857e-01
    z[5,4,0]  R2238     -5.6616473197937012e-01
    z[5,4,0]  R2239     0.01770637370646
    z[5,4,0]  R2240     -0.0440821535885334
    z[5,4,0]  R2241     -1.9195194542407990e-01
    z[5,4,0]  R2242     1.2960492074489594e-01
    z[5,4,0]  R2243     1.6947485506534576e-01
    z[5,4,0]  R2244     1.3789768517017365e-01
    z[5,4,0]  R2245     -2.1324107050895691e-01
    z[5,4,0]  R2246     5.0671076774597168e-01
    z[5,4,0]  R2247     -1.9885918498039246e-01
    z[5,4,0]  R2248     -3.0448371171951294e-01
    z[5,4,0]  R2249     -5.0142383575439453e-01
    z[5,4,0]  R2250     -5.4543703794479370e-01
    z[5,4,0]  R2251     -4.7971585392951965e-01
    z[5,4,0]  R2252     -1.3544252514839172e-01
    z[5,4,0]  R2253     3.7151578068733215e-01
    z[5,4,0]  R2254     4.6744519472122192e-01
    z[5,4,0]  R2255     3.8565129041671753e-01
    z[5,4,0]  R2256     2.2729112207889557e-01
    z[5,4,0]  R2257     3.9012342691421509e-02
    z[5,4,0]  R2258     -3.9402687549591064e-01
    z[5,4,0]  R2259     3.7529698014259338e-01
    z[5,4,0]  R2260     -2.4144466221332550e-01
    z[5,4,0]  R2261     -4.5150774717330933e-01
    z[5,4,0]  R2262     -0.0822141021490097
    z[5,4,0]  R2263     -3.6437591910362244e-01
    z[5,4,0]  R2264     2.1702052652835846e-01
    z[5,4,0]  R2265     -1.5074262022972107e-01
    z[5,4,0]  R2266     -4.3471691012382507e-01
    z[5,4,0]  R2267     -4.4951498508453369e-01
    z[5,4,0]  R2268     4.3127852678298950e-01
    z[5,4,0]  R2269     1.6457749903202057e-01
    z[5,4,0]  R2270     1.2404111027717590e-01
    z[5,4,0]  R2271     1.3128182291984558e-01
    z[5,4,1]  R39       1
    z[5,4,1]  R48       -1
    z[5,4,1]  R2204     -1
    z[5,4,1]  R2205     1
    z[5,4,1]  R2216     -2.9579332470893860e-01
    z[5,4,1]  R2217     -3.3140763640403748e-01
    z[5,4,1]  R2218     3.6768081784248352e-01
    z[5,4,1]  R2219     -3.8896843791007996e-02
    z[5,4,1]  R2220     -3.9393520355224609e-01
    z[5,4,1]  R2221     -0.417843759059906
    z[5,4,1]  R2222     2.1209548413753510e-01
    z[5,4,1]  R2223     -5.1100033521652222e-01
    z[5,4,1]  R2224     8.0563133955001831e-01
    z[5,4,1]  R2225     8.0624979734420776e-01
    z[5,4,1]  R2226     5.9764266014099121e-01
    z[5,4,1]  R2227     4.2195639014244080e-01
    z[5,4,1]  R2228     3.9931362867355347e-01
    z[5,4,1]  R2229     4.5708245038986206e-01
    z[5,4,1]  R2230     4.1171273589134216e-01
    z[5,4,1]  R2231     4.4868674874305725e-01
    z[5,4,1]  R2232     4.4769674539566040e-01
    z[5,4,1]  R2233     -4.8848456144332886e-01
    z[5,4,1]  R2234     1.7885313928127289e-01
    z[5,4,1]  R2235     -7.0007240772247314e-01
    z[5,4,1]  R2236     7.5460141897201538e-01
    z[5,4,1]  R2237     7.0336228609085083e-01
    z[5,4,1]  R2238     7.3183369636535645e-01
    z[5,4,1]  R2239     6.8371903896331787e-01
    z[5,4,1]  R2240     7.2825807332992554e-01
    z[5,4,1]  R2241     6.1534881591796875e-01
    z[5,4,1]  R2242     5.5842143297195435e-01
    z[5,4,1]  R2243     6.6320836544036865e-01
    z[5,4,1]  R2244     5.2656018733978271e-01
    z[5,4,1]  R2245     0.50145024061203
    z[5,4,1]  R2246     0.673224151134491
    z[5,4,1]  R2247     0.654941976070404
    z[5,4,1]  R2248     -6.9678771495819092e-01
    z[5,4,1]  R2249     -6.7250436544418335e-01
    z[5,4,1]  R2250     -5.7821273803710938e-01
    z[5,4,1]  R2251     -6.0361069440841675e-01
    z[5,4,1]  R2252     5.9941875934600830e-01
    z[5,4,1]  R2253     5.3524309396743774e-01
    z[5,4,1]  R2254     5.9997326135635376e-01
    z[5,4,1]  R2255     3.2528099417686462e-01
    z[5,4,1]  R2256     -4.5928034186363220e-01
    z[5,4,1]  R2257     5.6652998924255371e-01
    z[5,4,1]  R2258     5.0626343488693237e-01
    z[5,4,1]  R2259     -4.8687958717346191e-01
    z[5,4,1]  R2260     4.6423014998435974e-01
    z[5,4,1]  R2261     3.9923894405364990e-01
    z[5,4,1]  R2262     3.7479737401008606e-01
    z[5,4,1]  R2263     5.6444448232650757e-01
    z[5,4,1]  R2264     1.4548103511333466e-01
    z[5,4,1]  R2265     3.9232549071311951e-01
    z[5,4,1]  R2266     0.671127200126648
    z[5,4,1]  R2267     5.6460309028625488e-01
    z[5,4,1]  R2268     -6.0256713628768921e-01
    z[5,4,1]  R2269     -6.9524329900741577e-01
    z[5,4,1]  R2270     -4.3254745006561279e-01
    z[5,4,1]  R2271     -8.9349585771560669e-01
    z[5,4,2]  R40       1
    z[5,4,2]  R49       -1
    z[5,4,2]  R2206     -1
    z[5,4,2]  R2207     1
    z[5,4,2]  R2216     6.5029317140579224e-01
    z[5,4,2]  R2217     2.3039247095584869e-01
    z[5,4,2]  R2218     5.5591195821762085e-01
    z[5,4,2]  R2219     3.4478139877319336e-01
    z[5,4,2]  R2220     4.7812196612358093e-01
    z[5,4,2]  R2221     3.3615015447139740e-02
    z[5,4,2]  R2222     5.6970185041427612e-01
    z[5,4,2]  R2223     -1.1947441101074219e-01
    z[5,4,2]  R2224     -3.0314254760742188e-01
    z[5,4,2]  R2225     -4.1481822729110718e-02
    z[5,4,2]  R2226     1.9685681164264679e-01
    z[5,4,2]  R2227     -2.0552419126033783e-01
    z[5,4,2]  R2228     -1.6960366070270538e-01
    z[5,4,2]  R2229     -2.7856704592704773e-01
    z[5,4,2]  R2230     -2.1651954948902130e-01
    z[5,4,2]  R2231     3.3400931954383850e-01
    z[5,4,2]  R2232     2.2183121740818024e-01
    z[5,4,2]  R2233     -4.7147122025489807e-01
    z[5,4,2]  R2234     -3.6279717087745667e-01
    z[5,4,2]  R2235     -1.6546821594238281e-01
    z[5,4,2]  R2236     -2.2869546711444855e-01
    z[5,4,2]  R2237     6.2293823808431625e-02
    z[5,4,2]  R2238     1.7335507273674011e-01
    z[5,4,2]  R2239     4.2720317840576172e-01
    z[5,4,2]  R2240     -2.0526179671287537e-01
    z[5,4,2]  R2241     2.8183031082153320e-01
    z[5,4,2]  R2242     -2.2353968024253845e-01
    z[5,4,2]  R2243     3.6107987165451050e-01
    z[5,4,2]  R2244     -1.0032659024000168e-01
    z[5,4,2]  R2245     -2.8439259529113770e-01
    z[5,4,2]  R2246     -5.0510197877883911e-01
    z[5,4,2]  R2247     -2.8678017854690552e-01
    z[5,4,2]  R2248     1.0988084971904755e-01
    z[5,4,2]  R2249     -1.1029504239559174e-01
    z[5,4,2]  R2250     1.6776882112026215e-01
    z[5,4,2]  R2251     2.3622474074363708e-01
    z[5,4,2]  R2252     4.7314766049385071e-01
    z[5,4,2]  R2253     6.4146476984024048e-01
    z[5,4,2]  R2254     3.4393441677093506e-01
    z[5,4,2]  R2255     -5.5661749839782715e-01
    z[5,4,2]  R2256     7.3411154747009277e-01
    z[5,4,2]  R2257     -7.3292267322540283e-01
    z[5,4,2]  R2258     -2.2035045921802521e-01
    z[5,4,2]  R2259     0.354841947555542
    z[5,4,2]  R2260     -4.4543719291687012e-01
    z[5,4,2]  R2261     -4.6101558208465576e-01
    z[5,4,2]  R2262     -3.0765122175216675e-01
    z[5,4,2]  R2263     -4.0702033042907715e-01
    z[5,4,2]  R2264     9.9146686494350433e-02
    z[5,4,2]  R2265     -1.1688224039971828e-02
    z[5,4,2]  R2266     1.8368528783321381e-01
    z[5,4,2]  R2267     -2.7939698100090027e-01
    z[5,4,2]  R2268     -2.1570718288421631e-01
    z[5,4,2]  R2269     2.5934013724327087e-01
    z[5,4,2]  R2270     1.0537172108888626e-01
    z[5,4,2]  R2271     -1.0331146419048309e-01
    z[5,4,3]  R41       1
    z[5,4,3]  R50       -1
    z[5,4,3]  R2208     -1
    z[5,4,3]  R2209     1
    z[5,4,3]  R2216     3.3118334412574768e-01
    z[5,4,3]  R2217     5.2328133583068848e-01
    z[5,4,3]  R2218     6.3107900321483612e-02
    z[5,4,3]  R2219     -3.7122715730220079e-03
    z[5,4,3]  R2220     1.1415149271488190e-01
    z[5,4,3]  R2221     2.2451011836528778e-01
    z[5,4,3]  R2222     3.1727319955825806e-01
    z[5,4,3]  R2223     -1.0649629682302475e-01
    z[5,4,3]  R2224     1.8137918412685394e-01
    z[5,4,3]  R2225     4.3290373682975769e-01
    z[5,4,3]  R2226     -3.4623432159423828e-01
    z[5,4,3]  R2227     -0.375354528427124
    z[5,4,3]  R2228     -6.7517482675611973e-03
    z[5,4,3]  R2229     -3.3685654401779175e-01
    z[5,4,3]  R2230     -4.8288854956626892e-01
    z[5,4,3]  R2231     -2.4150630831718445e-01
    z[5,4,3]  R2232     1.5619641542434692e-01
    z[5,4,3]  R2233     -1.4916208386421204e-01
    z[5,4,3]  R2234     -2.1368719637393951e-01
    z[5,4,3]  R2235     -2.2419057786464691e-01
    z[5,4,3]  R2236     -4.1027626395225525e-01
    z[5,4,3]  R2237     3.5584408789873123e-02
    z[5,4,3]  R2238     -2.5215500593185425e-01
    z[5,4,3]  R2239     -0.0723184123635292
    z[5,4,3]  R2240     -4.9420168995857239e-01
    z[5,4,3]  R2241     2.2640155255794525e-01
    z[5,4,3]  R2242     -1.4711397886276245e-01
    z[5,4,3]  R2243     4.0763825178146362e-01
    z[5,4,3]  R2244     2.9277700185775757e-01
    z[5,4,3]  R2245     5.6977385282516479e-01
    z[5,4,3]  R2246     -1.2279611080884933e-02
    z[5,4,3]  R2247     -3.3612366765737534e-02
    z[5,4,3]  R2248     3.4877711534500122e-01
    z[5,4,3]  R2249     -3.0873927474021912e-01
    z[5,4,3]  R2250     -4.2799431085586548e-01
    z[5,4,3]  R2251     -5.2732646465301514e-01
    z[5,4,3]  R2252     -2.4220316112041473e-01
    z[5,4,3]  R2253     6.1942975968122482e-02
    z[5,4,3]  R2254     1.1200608313083649e-01
    z[5,4,3]  R2255     -9.1599315404891968e-02
    z[5,4,3]  R2256     3.8009887933731079e-01
    z[5,4,3]  R2257     1.6812488436698914e-01
    z[5,4,3]  R2258     -3.6225453019142151e-01
    z[5,4,3]  R2259     4.8625072836875916e-01
    z[5,4,3]  R2260     -2.2988341748714447e-01
    z[5,4,3]  R2261     -5.0863057374954224e-01
    z[5,4,3]  R2262     1.8882469832897186e-01
    z[5,4,3]  R2263     -9.0798944234848022e-02
    z[5,4,3]  R2264     -4.2324650287628174e-01
    z[5,4,3]  R2265     2.4133273959159851e-01
    z[5,4,3]  R2266     7.0253565907478333e-02
    z[5,4,3]  R2267     -1.6083383560180664e-01
    z[5,4,3]  R2268     -1.9417789578437805e-01
    z[5,4,3]  R2269     -3.5769420862197876e-01
    z[5,4,3]  R2270     -4.0315032005310059e-01
    z[5,4,3]  R2271     7.3971413075923920e-02
    z[5,4,4]  R42       1
    z[5,4,4]  R51       -1
    z[5,4,4]  R2210     -1
    z[5,4,4]  R2211     1
    z[5,4,4]  R2216     9.4280634075403214e-03
    z[5,4,4]  R2217     2.9374551773071289e-01
    z[5,4,4]  R2218     1.9206385314464569e-01
    z[5,4,4]  R2219     5.6137222051620483e-01
    z[5,4,4]  R2220     6.7019534111022949e-01
    z[5,4,4]  R2221     -2.3307195305824280e-01
    z[5,4,4]  R2222     6.1939394474029541e-01
    z[5,4,4]  R2223     2.3664748668670654e-01
    z[5,4,4]  R2224     3.9568841457366943e-01
    z[5,4,4]  R2225     1.7387686669826508e-01
    z[5,4,4]  R2226     -4.8594778776168823e-01
    z[5,4,4]  R2227     -7.3324447870254517e-01
    z[5,4,4]  R2228     -4.2227414250373840e-01
    z[5,4,4]  R2229     -4.9721163511276245e-01
    z[5,4,4]  R2230     -2.3260879516601562e-01
    z[5,4,4]  R2231     1.9123084843158722e-01
    z[5,4,4]  R2232     -3.1898370385169983e-01
    z[5,4,4]  R2233     4.3852204084396362e-01
    z[5,4,4]  R2234     6.9909161329269409e-01
    z[5,4,4]  R2235     6.7884959280490875e-02
    z[5,4,4]  R2236     -3.6485812067985535e-01
    z[5,4,4]  R2237     -5.1581335067749023e-01
    z[5,4,4]  R2238     1.2401795387268066e-01
    z[5,4,4]  R2239     2.2467546164989471e-01
    z[5,4,4]  R2240     2.3399452865123749e-01
    z[5,4,4]  R2241     -3.7361967563629150e-01
    z[5,4,4]  R2242     -5.3972554206848145e-01
    z[5,4,4]  R2243     -3.5437917709350586e-01
    z[5,4,4]  R2244     -7.3020040988922119e-01
    z[5,4,4]  R2245     1.8432773649692535e-02
    z[5,4,4]  R2246     -1.6219811141490936e-01
    z[5,4,4]  R2247     -3.4186261892318726e-01
    z[5,4,4]  R2248     -1.4937274158000946e-01
    z[5,4,4]  R2249     -1.9341942667961121e-01
    z[5,4,4]  R2250     2.0830312743782997e-02
    z[5,4,4]  R2251     -9.0662986040115356e-02
    z[5,4,4]  R2252     2.8842657804489136e-01
    z[5,4,4]  R2253     -3.5000029206275940e-01
    z[5,4,4]  R2254     1.9966131448745728e-01
    z[5,4,4]  R2255     -4.4427019357681274e-01
    z[5,4,4]  R2256     1.9556620717048645e-01
    z[5,4,4]  R2257     -2.0001649856567383e-01
    z[5,4,4]  R2258     5.0343668460845947e-01
    z[5,4,4]  R2259     -1.6372986137866974e-01
    z[5,4,4]  R2260     3.1951498240232468e-03
    z[5,4,4]  R2261     -3.9187619090080261e-01
    z[5,4,4]  R2262     3.1968098878860474e-01
    z[5,4,4]  R2263     -5.4483091831207275e-01
    z[5,4,4]  R2264     5.3580832481384277e-01
    z[5,4,4]  R2265     -8.9582674205303192e-02
    z[5,4,4]  R2266     -1.2088719755411148e-01
    z[5,4,4]  R2267     1.6698222607374191e-02
    z[5,4,4]  R2268     4.3900626897811890e-01
    z[5,4,4]  R2269     0.0387524850666523
    z[5,4,4]  R2270     -1.5400440990924835e-01
    z[5,4,4]  R2271     -2.8708747029304504e-01
    z[5,4,5]  R43       1
    z[5,4,5]  R52       -1
    z[5,4,5]  R2212     -1
    z[5,4,5]  R2213     1
    z[5,4,5]  R2216     3.8242614269256592e-01
    z[5,4,5]  R2217     5.0597274303436279e-01
    z[5,4,5]  R2218     5.9371012449264526e-01
    z[5,4,5]  R2219     5.5435377359390259e-01
    z[5,4,5]  R2220     -3.4342953003942966e-03
    z[5,4,5]  R2221     9.8959669470787048e-02
    z[5,4,5]  R2222     2.9374006390571594e-01
    z[5,4,5]  R2223     3.2743221521377563e-01
    z[5,4,5]  R2224     1.5588788688182831e-01
    z[5,4,5]  R2225     3.2585912942886353e-01
    z[5,4,5]  R2226     -3.5222217440605164e-01
    z[5,4,5]  R2227     -7.2058849036693573e-02
    z[5,4,5]  R2228     -7.6254093647003174e-01
    z[5,4,5]  R2229     -1.7625318467617035e-01
    z[5,4,5]  R2230     -5.0293862819671631e-01
    z[5,4,5]  R2231     -6.7311418056488037e-01
    z[5,4,5]  R2232     -2.0385213196277618e-01
    z[5,4,5]  R2233     -1.0849576443433762e-01
    z[5,4,5]  R2234     -3.8317084312438965e-01
    z[5,4,5]  R2235     2.3181456327438354e-01
    z[5,4,5]  R2236     1.2535206973552704e-01
    z[5,4,5]  R2237     -7.0958539843559265e-02
    z[5,4,5]  R2238     -1.7830401659011841e-01
    z[5,4,5]  R2239     -5.1603770256042480e-01
    z[5,4,5]  R2240     -2.8873044252395630e-01
    z[5,4,5]  R2241     -5.5137360095977783e-01
    z[5,4,5]  R2242     1.7858842015266418e-01
    z[5,4,5]  R2243     -3.3059626817703247e-01
    z[5,4,5]  R2244     -2.7245754003524780e-01
    z[5,4,5]  R2245     -4.0308335423469543e-01
    z[5,4,5]  R2246     4.5589298009872437e-02
    z[5,4,5]  R2247     -5.7330334186553955e-01
    z[5,4,5]  R2248     -5.0638669729232788e-01
    z[5,4,5]  R2249     3.8519567251205444e-01
    z[5,4,5]  R2250     3.9548525214195251e-01
    z[5,4,5]  R2251     2.0005165040493011e-01
    z[5,4,5]  R2252     2.6128500699996948e-02
    z[5,4,5]  R2253     7.1706078946590424e-02
    z[5,4,5]  R2254     4.9888265132904053e-01
    z[5,4,5]  R2255     4.6686807274818420e-01
    z[5,4,5]  R2256     -6.0093704611063004e-02
    z[5,4,5]  R2257     -2.4372828006744385e-01
    z[5,4,5]  R2258     -1.6527295112609863e-01
    z[5,4,5]  R2259     -0.0574694387614727
    z[5,4,5]  R2260     -1.0356678813695908e-01
    z[5,4,5]  R2261     8.7697193026542664e-02
    z[5,4,5]  R2262     -0.725053608417511
    z[5,4,5]  R2263     -2.0311726629734039e-01
    z[5,4,5]  R2264     -2.9575619101524353e-01
    z[5,4,5]  R2265     -0.324920654296875
    z[5,4,5]  R2266     -3.4698531031608582e-01
    z[5,4,5]  R2267     -2.9969671368598938e-01
    z[5,4,5]  R2268     4.1022595763206482e-01
    z[5,4,5]  R2269     5.3775095939636230e-01
    z[5,4,5]  R2270     5.9714996814727783e-01
    z[5,4,5]  R2271     -4.7690412029623985e-03
    z[5,4,6]  R44       1
    z[5,4,6]  R53       -1
    z[5,4,6]  R2214     -1
    z[5,4,6]  R2215     1
    z[5,4,6]  R2216     2.7778422459959984e-02
    z[5,4,6]  R2217     -2.4745856225490570e-01
    z[5,4,6]  R2218     1.2494678609073162e-02
    z[5,4,6]  R2219     2.5164343416690826e-02
    z[5,4,6]  R2220     7.5825154781341553e-02
    z[5,4,6]  R2221     2.1239224076271057e-01
    z[5,4,6]  R2222     -2.0509015023708344e-01
    z[5,4,6]  R2223     2.0678873360157013e-01
    z[5,4,6]  R2224     -8.5689671337604523e-02
    z[5,4,6]  R2225     2.1212226711213589e-03
    z[5,4,6]  R2226     3.5165277123451233e-01
    z[5,4,6]  R2227     1.8630404770374298e-01
    z[5,4,6]  R2228     1.3250321149826050e-01
    z[5,4,6]  R2229     2.5208277627825737e-02
    z[5,4,6]  R2230     1.9400231540203094e-01
    z[5,4,6]  R2231     1.7305904626846313e-01
    z[5,4,6]  R2232     -0.234492689371109
    z[5,4,6]  R2233     -4.8598459362983704e-01
    z[5,4,6]  R2234     -1.0857817530632019e-01
    z[5,4,6]  R2235     -1.4566726982593536e-01
    z[5,4,6]  R2236     8.4196001291275024e-02
    z[5,4,6]  R2237     -1.1761871725320816e-01
    z[5,4,6]  R2238     -5.5409427732229233e-02
    z[5,4,6]  R2239     1.6645808517932892e-01
    z[5,4,6]  R2240     2.0787145197391510e-01
    z[5,4,6]  R2241     1.0104341804981232e-01
    z[5,4,6]  R2242     5.2588790655136108e-01
    z[5,4,6]  R2243     -2.5872574187815189e-03
    z[5,4,6]  R2244     2.2560091689229012e-02
    z[5,4,6]  R2245     -3.6706754565238953e-01
    z[5,4,6]  R2246     7.9674273729324341e-02
    z[5,4,6]  R2247     5.0857108086347580e-02
    z[5,4,6]  R2248     -9.6527636051177979e-02
    z[5,4,6]  R2249     -5.5138994008302689e-02
    z[5,4,6]  R2250     -0.000664629100356251
    z[5,4,6]  R2251     1.5300613641738892e-01
    z[5,4,6]  R2252     -5.0591373443603516e-01
    z[5,4,6]  R2253     -1.8037442862987518e-01
    z[5,4,6]  R2254     -4.4070344418287277e-02
    z[5,4,6]  R2255     -1.0913307219743729e-01
    z[5,4,6]  R2256     -1.1021775007247925e-01
    z[5,4,6]  R2257     -1.1256178468465805e-01
    z[5,4,6]  R2258     -3.5762250423431396e-01
    z[5,4,6]  R2259     -4.7920525074005127e-01
    z[5,4,6]  R2260     -6.8132072687149048e-01
    z[5,4,6]  R2261     6.5198019146919250e-02
    z[5,4,6]  R2262     3.0751428008079529e-01
    z[5,4,6]  R2263     -1.9137734174728394e-01
    z[5,4,6]  R2264     6.0680097341537476e-01
    z[5,4,6]  R2265     8.0708169937133789e-01
    z[5,4,6]  R2266     4.3234363198280334e-01
    z[5,4,6]  R2267     5.3397798538208008e-01
    z[5,4,6]  R2268     7.5266867876052856e-02
    z[5,4,6]  R2269     -6.0586854815483093e-02
    z[5,4,6]  R2270     4.9353587627410889e-01
    z[5,4,6]  R2271     2.9299014806747437e-01
    z[5,6,0]  R47       -1
    z[5,6,0]  R56       1
    z[5,6,0]  R2306     -1
    z[5,6,0]  R2307     1
    z[5,6,0]  R2320     4.8252713680267334e-01
    z[5,6,0]  R2321     3.9966791868209839e-01
    z[5,6,0]  R2322     0.402807354927063
    z[5,6,0]  R2323     0.506476879119873
    z[5,6,0]  R2324     3.8504651188850403e-01
    z[5,6,0]  R2325     8.1525808572769165e-01
    z[5,6,0]  R2326     1.3341283798217773e-01
    z[5,6,0]  R2327     7.1224117279052734e-01
    z[5,6,0]  R2328     1.9481061398983002e-01
    z[5,6,0]  R2329     -1.5624713897705078e-01
    z[5,6,0]  R2330     1.8087498843669891e-02
    z[5,6,0]  R2331     -2.4753254652023315e-01
    z[5,6,0]  R2332     -1.8546250462532043e-01
    z[5,6,0]  R2333     -5.6664252281188965e-01
    z[5,6,0]  R2334     -4.5358520746231079e-01
    z[5,6,0]  R2335     -3.3044105768203735e-01
    z[5,6,0]  R2336     -7.2640764713287354e-01
    z[5,6,0]  R2337     -0.276757150888443
    z[5,6,0]  R2338     -3.7866771221160889e-01
    z[5,6,0]  R2339     -5.9387886524200439e-01
    z[5,6,0]  R2340     -2.3243264853954315e-01
    z[5,6,0]  R2341     -4.6389874815940857e-01
    z[5,6,0]  R2342     -5.6616473197937012e-01
    z[5,6,0]  R2343     0.01770637370646
    z[5,6,0]  R2344     -0.0440821535885334
    z[5,6,0]  R2345     -1.9195194542407990e-01
    z[5,6,0]  R2346     1.2960492074489594e-01
    z[5,6,0]  R2347     1.6947485506534576e-01
    z[5,6,0]  R2348     1.3789768517017365e-01
    z[5,6,0]  R2349     -2.1324107050895691e-01
    z[5,6,0]  R2350     5.0671076774597168e-01
    z[5,6,0]  R2351     -1.9885918498039246e-01
    z[5,6,0]  R2352     -3.0448371171951294e-01
    z[5,6,0]  R2353     -5.0142383575439453e-01
    z[5,6,0]  R2354     -5.4543703794479370e-01
    z[5,6,0]  R2355     -4.7971585392951965e-01
    z[5,6,0]  R2356     -2.6799976825714111e-01
    z[5,6,0]  R2357     -3.0848485231399536e-01
    z[5,6,0]  R2358     -0.502948522567749
    z[5,6,0]  R2359     -4.1463658213615417e-01
    z[5,6,0]  R2360     -4.0166664123535156e-01
    z[5,6,0]  R2361     -6.7071980237960815e-01
    z[5,6,0]  R2362     4.1482448577880859e-01
    z[5,6,0]  R2363     1.3724394142627716e-01
    z[5,6,0]  R2364     1.4065656065940857e-01
    z[5,6,0]  R2365     -1.9479477405548096e-01
    z[5,6,0]  R2366     3.3613452315330505e-01
    z[5,6,0]  R2367     1.0425824671983719e-01
    z[5,6,0]  R2368     0.254373162984848
    z[5,6,0]  R2369     -1.9016842544078827e-01
    z[5,6,0]  R2370     1.0421057045459747e-01
    z[5,6,0]  R2371     5.0094765424728394e-01
    z[5,6,0]  R2372     -4.1455483436584473e-01
    z[5,6,0]  R2373     -1.5327689051628113e-01
    z[5,6,0]  R2374     -7.3224997520446777e-01
    z[5,6,0]  R2375     -4.9367743730545044e-01
    z[5,6,0]  R2376     1.4100821316242218e-01
    z[5,6,0]  R2377     2.1753439307212830e-01
    z[5,6,0]  R2378     -1.2073613703250885e-01
    z[5,6,0]  R2379     -1.8786756694316864e-01
    z[5,6,0]  R2380     -9.2207081615924835e-03
    z[5,6,0]  R2381     2.0490171015262604e-01
    z[5,6,0]  R2382     -4.1622537374496460e-01
    z[5,6,0]  R2383     -0.274004727602005
    z[5,6,0]  R2384     1.6240687668323517e-01
    z[5,6,0]  R2385     -5.9607338905334473e-01
    z[5,6,0]  R2386     -3.1939432024955750e-01
    z[5,6,0]  R2387     -4.3587210774421692e-01
    z[5,6,0]  R2388     4.1314664483070374e-01
    z[5,6,0]  R2389     -1.7168661952018738e-01
    z[5,6,0]  R2390     -0.0768650621175766
    z[5,6,0]  R2391     1.2949213385581970e-01
    z[5,6,0]  R2392     -8.7719194591045380e-02
    z[5,6,0]  R2393     5.6931927800178528e-02
    z[5,6,0]  R2394     5.4856240749359131e-01
    z[5,6,0]  R2395     6.0297280550003052e-01
    z[5,6,0]  R2396     -1.9797690212726593e-01
    z[5,6,0]  R2397     1.5428879298269749e-02
    z[5,6,0]  R2398     1.7626523971557617e-01
    z[5,6,0]  R2399     4.1131421923637390e-01
    z[5,6,0]  R2400     2.3615600541234016e-02
    z[5,6,0]  R2401     5.5942213535308838e-01
    z[5,6,0]  R2402     3.5299485921859741e-01
    z[5,6,0]  R2403     -1.6912724822759628e-02
    z[5,6,0]  R2404     1.3452319800853729e-01
    z[5,6,0]  R2405     2.1778613328933716e-01
    z[5,6,0]  R2406     -2.8781610727310181e-01
    z[5,6,0]  R2407     3.7395498156547546e-01
    z[5,6,0]  R2408     2.0948988199234009e-01
    z[5,6,0]  R2409     1.1307834833860397e-01
    z[5,6,0]  R2410     -1.8201948702335358e-01
    z[5,6,0]  R2411     -2.8810063004493713e-01
    z[5,6,0]  R2412     9.0143084526062012e-01
    z[5,6,1]  R48       -1
    z[5,6,1]  R57       1
    z[5,6,1]  R2308     -1
    z[5,6,1]  R2309     1
    z[5,6,1]  R2320     -2.9579332470893860e-01
    z[5,6,1]  R2321     -3.3140763640403748e-01
    z[5,6,1]  R2322     3.6768081784248352e-01
    z[5,6,1]  R2323     -3.8896843791007996e-02
    z[5,6,1]  R2324     -3.9393520355224609e-01
    z[5,6,1]  R2325     -0.417843759059906
    z[5,6,1]  R2326     2.1209548413753510e-01
    z[5,6,1]  R2327     -5.1100033521652222e-01
    z[5,6,1]  R2328     8.0563133955001831e-01
    z[5,6,1]  R2329     8.0624979734420776e-01
    z[5,6,1]  R2330     5.9764266014099121e-01
    z[5,6,1]  R2331     4.2195639014244080e-01
    z[5,6,1]  R2332     3.9931362867355347e-01
    z[5,6,1]  R2333     4.5708245038986206e-01
    z[5,6,1]  R2334     4.1171273589134216e-01
    z[5,6,1]  R2335     4.4868674874305725e-01
    z[5,6,1]  R2336     4.4769674539566040e-01
    z[5,6,1]  R2337     -4.8848456144332886e-01
    z[5,6,1]  R2338     1.7885313928127289e-01
    z[5,6,1]  R2339     -7.0007240772247314e-01
    z[5,6,1]  R2340     7.5460141897201538e-01
    z[5,6,1]  R2341     7.0336228609085083e-01
    z[5,6,1]  R2342     7.3183369636535645e-01
    z[5,6,1]  R2343     6.8371903896331787e-01
    z[5,6,1]  R2344     7.2825807332992554e-01
    z[5,6,1]  R2345     6.1534881591796875e-01
    z[5,6,1]  R2346     5.5842143297195435e-01
    z[5,6,1]  R2347     6.6320836544036865e-01
    z[5,6,1]  R2348     5.2656018733978271e-01
    z[5,6,1]  R2349     0.50145024061203
    z[5,6,1]  R2350     0.673224151134491
    z[5,6,1]  R2351     0.654941976070404
    z[5,6,1]  R2352     -6.9678771495819092e-01
    z[5,6,1]  R2353     -6.7250436544418335e-01
    z[5,6,1]  R2354     -5.7821273803710938e-01
    z[5,6,1]  R2355     -6.0361069440841675e-01
    z[5,6,1]  R2356     2.6034945249557495e-01
    z[5,6,1]  R2357     -3.4273234009742737e-01
    z[5,6,1]  R2358     3.3970236778259277e-01
    z[5,6,1]  R2359     0.287553071975708
    z[5,6,1]  R2360     -1.8081579357385635e-02
    z[5,6,1]  R2361     -1.0382114350795746e-01
    z[5,6,1]  R2362     6.3087075948715210e-01
    z[5,6,1]  R2363     6.6886502504348755e-01
    z[5,6,1]  R2364     7.1507990360260010e-01
    z[5,6,1]  R2365     1.6465568542480469e-01
    z[5,6,1]  R2366     -1.9731727242469788e-01
    z[5,6,1]  R2367     2.3253744840621948e-01
    z[5,6,1]  R2368     -1.3593323528766632e-01
    z[5,6,1]  R2369     4.5358244329690933e-02
    z[5,6,1]  R2370     -0.3088398873806
    z[5,6,1]  R2371     -2.1598720923066139e-02
    z[5,6,1]  R2372     -1.5587671659886837e-02
    z[5,6,1]  R2373     -1.1244186758995056e-01
    z[5,6,1]  R2374     -1.2262280285358429e-01
    z[5,6,1]  R2375     -4.1260862350463867e-01
    z[5,6,1]  R2376     -2.0453684031963348e-01
    z[5,6,1]  R2377     1.3772989809513092e-01
    z[5,6,1]  R2378     -3.0731928348541260e-01
    z[5,6,1]  R2379     3.0537009239196777e-01
    z[5,6,1]  R2380     1.7410951852798462e-01
    z[5,6,1]  R2381     5.5265665054321289e-01
    z[5,6,1]  R2382     3.9770871400833130e-01
    z[5,6,1]  R2383     1.5753868967294693e-02
    z[5,6,1]  R2384     -2.0316170156002045e-01
    z[5,6,1]  R2385     -2.0895386114716530e-02
    z[5,6,1]  R2386     3.3721652626991272e-01
    z[5,6,1]  R2387     0.0609736330807209
    z[5,6,1]  R2388     -3.0422195792198181e-01
    z[5,6,1]  R2389     2.3960523307323456e-01
    z[5,6,1]  R2390     5.8998677879571915e-02
    z[5,6,1]  R2391     8.6291587352752686e-01
    z[5,6,1]  R2392     8.5653185844421387e-01
    z[5,6,1]  R2393     8.1906998157501221e-01
    z[5,6,1]  R2394     7.3512208461761475e-01
    z[5,6,1]  R2395     4.4444590806961060e-01
    z[5,6,1]  R2396     -2.5734481215476990e-01
    z[5,6,1]  R2397     3.8917216658592224e-01
    z[5,6,1]  R2398     9.5235210657119751e-01
    z[5,6,1]  R2399     -1.1356313712894917e-02
    z[5,6,1]  R2400     9.0541803836822510e-01
    z[5,6,1]  R2401     5.4022759199142456e-01
    z[5,6,1]  R2402     5.0834619998931885e-01
    z[5,6,1]  R2403     -9.0297651290893555e-01
    z[5,6,1]  R2404     -8.1154477596282959e-01
    z[5,6,1]  R2405     -9.0584987401962280e-01
    z[5,6,1]  R2406     -1.6611185669898987e-01
    z[5,6,1]  R2407     9.2443414032459259e-02
    z[5,6,1]  R2408     3.8873386383056641e-01
    z[5,6,1]  R2409     -6.8229228258132935e-01
    z[5,6,1]  R2410     -3.2924848794937134e-01
    z[5,6,1]  R2411     -2.0766112208366394e-01
    z[5,6,1]  R2412     -1.3121864199638367e-01
    z[5,6,2]  R49       -1
    z[5,6,2]  R58       1
    z[5,6,2]  R2310     -1
    z[5,6,2]  R2311     1
    z[5,6,2]  R2320     6.5029317140579224e-01
    z[5,6,2]  R2321     2.3039247095584869e-01
    z[5,6,2]  R2322     5.5591195821762085e-01
    z[5,6,2]  R2323     3.4478139877319336e-01
    z[5,6,2]  R2324     4.7812196612358093e-01
    z[5,6,2]  R2325     3.3615015447139740e-02
    z[5,6,2]  R2326     5.6970185041427612e-01
    z[5,6,2]  R2327     -1.1947441101074219e-01
    z[5,6,2]  R2328     -3.0314254760742188e-01
    z[5,6,2]  R2329     -4.1481822729110718e-02
    z[5,6,2]  R2330     1.9685681164264679e-01
    z[5,6,2]  R2331     -2.0552419126033783e-01
    z[5,6,2]  R2332     -1.6960366070270538e-01
    z[5,6,2]  R2333     -2.7856704592704773e-01
    z[5,6,2]  R2334     -2.1651954948902130e-01
    z[5,6,2]  R2335     3.3400931954383850e-01
    z[5,6,2]  R2336     2.2183121740818024e-01
    z[5,6,2]  R2337     -4.7147122025489807e-01
    z[5,6,2]  R2338     -3.6279717087745667e-01
    z[5,6,2]  R2339     -1.6546821594238281e-01
    z[5,6,2]  R2340     -2.2869546711444855e-01
    z[5,6,2]  R2341     6.2293823808431625e-02
    z[5,6,2]  R2342     1.7335507273674011e-01
    z[5,6,2]  R2343     4.2720317840576172e-01
    z[5,6,2]  R2344     -2.0526179671287537e-01
    z[5,6,2]  R2345     2.8183031082153320e-01
    z[5,6,2]  R2346     -2.2353968024253845e-01
    z[5,6,2]  R2347     3.6107987165451050e-01
    z[5,6,2]  R2348     -1.0032659024000168e-01
    z[5,6,2]  R2349     -2.8439259529113770e-01
    z[5,6,2]  R2350     -5.0510197877883911e-01
    z[5,6,2]  R2351     -2.8678017854690552e-01
    z[5,6,2]  R2352     1.0988084971904755e-01
    z[5,6,2]  R2353     -1.1029504239559174e-01
    z[5,6,2]  R2354     1.6776882112026215e-01
    z[5,6,2]  R2355     2.3622474074363708e-01
    z[5,6,2]  R2356     -3.9756676554679871e-01
    z[5,6,2]  R2357     -4.9994894862174988e-01
    z[5,6,2]  R2358     -2.3084443807601929e-01
    z[5,6,2]  R2359     -2.0341536402702332e-01
    z[5,6,2]  R2360     1.1693882942199707e-01
    z[5,6,2]  R2361     8.1346176564693451e-02
    z[5,6,2]  R2362     -2.8455637395381927e-02
    z[5,6,2]  R2363     -4.7480916976928711e-01
    z[5,6,2]  R2364     0.399924099445343
    z[5,6,2]  R2365     -3.5927772521972656e-01
    z[5,6,2]  R2366     -2.6057684421539307e-01
    z[5,6,2]  R2367     7.0517949759960175e-02
    z[5,6,2]  R2368     1.9377246499061584e-01
    z[5,6,2]  R2369     -3.5220120102167130e-02
    z[5,6,2]  R2370     -1.5724499523639679e-01
    z[5,6,2]  R2371     -0.251311331987381
    z[5,6,2]  R2372     -4.4861888885498047e-01
    z[5,6,2]  R2373     8.4616623818874359e-02
    z[5,6,2]  R2374     -4.3666278943419456e-03
    z[5,6,2]  R2375     2.8069657087326050e-01
    z[5,6,2]  R2376     1.4100825786590576e-01
    z[5,6,2]  R2377     -8.8609211146831512e-02
    z[5,6,2]  R2378     -3.8922277092933655e-01
    z[5,6,2]  R2379     -8.1903554499149323e-02
    z[5,6,2]  R2380     -0.564672589302063
    z[5,6,2]  R2381     -3.1437207013368607e-02
    z[5,6,2]  R2382     -1.1584430932998657e-01
    z[5,6,2]  R2383     -2.2531510889530182e-01
    z[5,6,2]  R2384     2.7839755639433861e-03
    z[5,6,2]  R2385     -5.0746973603963852e-02
    z[5,6,2]  R2386     -2.3050782084465027e-01
    z[5,6,2]  R2387     2.4781459942460060e-02
    z[5,6,2]  R2388     -6.3811242580413818e-02
    z[5,6,2]  R2389     -8.2455776631832123e-02
    z[5,6,2]  R2390     -2.8026726841926575e-01
    z[5,6,2]  R2391     7.1502029895782471e-02
    z[5,6,2]  R2392     2.1758085489273071e-01
    z[5,6,2]  R2393     3.5238778591156006e-01
    z[5,6,2]  R2394     -1.8645766377449036e-01
    z[5,6,2]  R2395     3.1171867251396179e-01
    z[5,6,2]  R2396     -3.9491170644760132e-01
    z[5,6,2]  R2397     1.6960716247558594e-01
    z[5,6,2]  R2398     -1.4601002633571625e-01
    z[5,6,2]  R2399     -4.1508537530899048e-01
    z[5,6,2]  R2400     2.7347663044929504e-01
    z[5,6,2]  R2401     2.0718546211719513e-01
    z[5,6,2]  R2402     3.8754299283027649e-01
    z[5,6,2]  R2403     7.2244450449943542e-02
    z[5,6,2]  R2404     0.145552858710289
    z[5,6,2]  R2405     5.7123210281133652e-02
    z[5,6,2]  R2406     -3.3237934112548828e-01
    z[5,6,2]  R2407     -3.8678976893424988e-01
    z[5,6,2]  R2408     5.5587112903594971e-01
    z[5,6,2]  R2409     -3.4621194005012512e-02
    z[5,6,2]  R2410     -0.0864488035440445
    z[5,6,2]  R2411     -1.7532606422901154e-01
    z[5,6,2]  R2412     -0.0704229474067688
    z[5,6,3]  R50       -1
    z[5,6,3]  R59       1
    z[5,6,3]  R2312     -1
    z[5,6,3]  R2313     1
    z[5,6,3]  R2320     3.3118334412574768e-01
    z[5,6,3]  R2321     5.2328133583068848e-01
    z[5,6,3]  R2322     6.3107900321483612e-02
    z[5,6,3]  R2323     -3.7122715730220079e-03
    z[5,6,3]  R2324     1.1415149271488190e-01
    z[5,6,3]  R2325     2.2451011836528778e-01
    z[5,6,3]  R2326     3.1727319955825806e-01
    z[5,6,3]  R2327     -1.0649629682302475e-01
    z[5,6,3]  R2328     1.8137918412685394e-01
    z[5,6,3]  R2329     4.3290373682975769e-01
    z[5,6,3]  R2330     -3.4623432159423828e-01
    z[5,6,3]  R2331     -0.375354528427124
    z[5,6,3]  R2332     -6.7517482675611973e-03
    z[5,6,3]  R2333     -3.3685654401779175e-01
    z[5,6,3]  R2334     -4.8288854956626892e-01
    z[5,6,3]  R2335     -2.4150630831718445e-01
    z[5,6,3]  R2336     1.5619641542434692e-01
    z[5,6,3]  R2337     -1.4916208386421204e-01
    z[5,6,3]  R2338     -2.1368719637393951e-01
    z[5,6,3]  R2339     -2.2419057786464691e-01
    z[5,6,3]  R2340     -4.1027626395225525e-01
    z[5,6,3]  R2341     3.5584408789873123e-02
    z[5,6,3]  R2342     -2.5215500593185425e-01
    z[5,6,3]  R2343     -0.0723184123635292
    z[5,6,3]  R2344     -4.9420168995857239e-01
    z[5,6,3]  R2345     2.2640155255794525e-01
    z[5,6,3]  R2346     -1.4711397886276245e-01
    z[5,6,3]  R2347     4.0763825178146362e-01
    z[5,6,3]  R2348     2.9277700185775757e-01
    z[5,6,3]  R2349     5.6977385282516479e-01
    z[5,6,3]  R2350     -1.2279611080884933e-02
    z[5,6,3]  R2351     -3.3612366765737534e-02
    z[5,6,3]  R2352     3.4877711534500122e-01
    z[5,6,3]  R2353     -3.0873927474021912e-01
    z[5,6,3]  R2354     -4.2799431085586548e-01
    z[5,6,3]  R2355     -5.2732646465301514e-01
    z[5,6,3]  R2356     6.5393263101577759e-01
    z[5,6,3]  R2357     5.0959396362304688e-01
    z[5,6,3]  R2358     4.0262740850448608e-01
    z[5,6,3]  R2359     0.0463026687502861
    z[5,6,3]  R2360     -7.2940096259117126e-02
    z[5,6,3]  R2361     2.8767937421798706e-01
    z[5,6,3]  R2362     -0.0512276254594326
    z[5,6,3]  R2363     -7.1023985743522644e-02
    z[5,6,3]  R2364     -3.7454909086227417e-01
    z[5,6,3]  R2365     -7.4034363031387329e-02
    z[5,6,3]  R2366     -3.3794444799423218e-01
    z[5,6,3]  R2367     -2.8308334946632385e-01
    z[5,6,3]  R2368     -0.391967236995697
    z[5,6,3]  R2369     -2.7441471815109253e-01
    z[5,6,3]  R2370     -3.5618439316749573e-01
    z[5,6,3]  R2371     -4.3386444449424744e-01
    z[5,6,3]  R2372     -2.6035135984420776e-01
    z[5,6,3]  R2373     -3.7802201509475708e-01
    z[5,6,3]  R2374     -3.1466564536094666e-01
    z[5,6,3]  R2375     -2.4095329642295837e-01
    z[5,6,3]  R2376     -6.8053388595581055e-01
    z[5,6,3]  R2377     -7.2847908735275269e-01
    z[5,6,3]  R2378     -7.1762156486511230e-01
    z[5,6,3]  R2379     -6.7181175947189331e-01
    z[5,6,3]  R2380     -7.5338131189346313e-01
    z[5,6,3]  R2381     -6.4652174711227417e-01
    z[5,6,3]  R2382     -6.3391441106796265e-01
    z[5,6,3]  R2383     -5.2807462215423584e-01
    z[5,6,3]  R2384     -6.9509744644165039e-01
    z[5,6,3]  R2385     -7.5340855121612549e-01
    z[5,6,3]  R2386     -6.3471955060958862e-01
    z[5,6,3]  R2387     -7.7655339241027832e-01
    z[5,6,3]  R2388     -6.2197327613830566e-01
    z[5,6,3]  R2389     -6.6663116216659546e-01
    z[5,6,3]  R2390     -5.9071314334869385e-01
    z[5,6,3]  R2391     2.1089186891913414e-02
    z[5,6,3]  R2392     4.1512794792652130e-02
    z[5,6,3]  R2393     -3.4831660985946655e-01
    z[5,6,3]  R2394     -3.0824735760688782e-02
    z[5,6,3]  R2395     -5.2167940139770508e-01
    z[5,6,3]  R2396     -4.0444770455360413e-01
    z[5,6,3]  R2397     -8.0958712100982666e-01
    z[5,6,3]  R2398     -1.7638245224952698e-01
    z[5,6,3]  R2399     -4.1537594795227051e-01
    z[5,6,3]  R2400     -1.8703933060169220e-01
    z[5,6,3]  R2401     -5.4770672321319580e-01
    z[5,6,3]  R2402     -5.7849675416946411e-01
    z[5,6,3]  R2403     -2.0557032525539398e-01
    z[5,6,3]  R2404     -4.5151209831237793e-01
    z[5,6,3]  R2405     -2.2021782398223877e-01
    z[5,6,3]  R2406     -8.3125251531600952e-01
    z[5,6,3]  R2407     -0.372031033039093
    z[5,6,3]  R2408     -0.626023530960083
    z[5,6,3]  R2409     -3.2117596268653870e-01
    z[5,6,3]  R2410     4.4315099716186523e-01
    z[5,6,3]  R2411     3.2139471173286438e-01
    z[5,6,3]  R2412     2.2495168447494507e-01
    z[5,6,4]  R51       -1
    z[5,6,4]  R60       1
    z[5,6,4]  R2314     -1
    z[5,6,4]  R2315     1
    z[5,6,4]  R2320     9.4280634075403214e-03
    z[5,6,4]  R2321     2.9374551773071289e-01
    z[5,6,4]  R2322     1.9206385314464569e-01
    z[5,6,4]  R2323     5.6137222051620483e-01
    z[5,6,4]  R2324     6.7019534111022949e-01
    z[5,6,4]  R2325     -2.3307195305824280e-01
    z[5,6,4]  R2326     6.1939394474029541e-01
    z[5,6,4]  R2327     2.3664748668670654e-01
    z[5,6,4]  R2328     3.9568841457366943e-01
    z[5,6,4]  R2329     1.7387686669826508e-01
    z[5,6,4]  R2330     -4.8594778776168823e-01
    z[5,6,4]  R2331     -7.3324447870254517e-01
    z[5,6,4]  R2332     -4.2227414250373840e-01
    z[5,6,4]  R2333     -4.9721163511276245e-01
    z[5,6,4]  R2334     -2.3260879516601562e-01
    z[5,6,4]  R2335     1.9123084843158722e-01
    z[5,6,4]  R2336     -3.1898370385169983e-01
    z[5,6,4]  R2337     4.3852204084396362e-01
    z[5,6,4]  R2338     6.9909161329269409e-01
    z[5,6,4]  R2339     6.7884959280490875e-02
    z[5,6,4]  R2340     -3.6485812067985535e-01
    z[5,6,4]  R2341     -5.1581335067749023e-01
    z[5,6,4]  R2342     1.2401795387268066e-01
    z[5,6,4]  R2343     2.2467546164989471e-01
    z[5,6,4]  R2344     2.3399452865123749e-01
    z[5,6,4]  R2345     -3.7361967563629150e-01
    z[5,6,4]  R2346     -5.3972554206848145e-01
    z[5,6,4]  R2347     -3.5437917709350586e-01
    z[5,6,4]  R2348     -7.3020040988922119e-01
    z[5,6,4]  R2349     1.8432773649692535e-02
    z[5,6,4]  R2350     -1.6219811141490936e-01
    z[5,6,4]  R2351     -3.4186261892318726e-01
    z[5,6,4]  R2352     -1.4937274158000946e-01
    z[5,6,4]  R2353     -1.9341942667961121e-01
    z[5,6,4]  R2354     2.0830312743782997e-02
    z[5,6,4]  R2355     -9.0662986040115356e-02
    z[5,6,4]  R2356     -3.6099845170974731e-01
    z[5,6,4]  R2357     -5.0128477811813354e-01
    z[5,6,4]  R2358     -2.4232718348503113e-01
    z[5,6,4]  R2359     -6.2378132343292236e-01
    z[5,6,4]  R2360     -7.6530051231384277e-01
    z[5,6,4]  R2361     -8.2309916615486145e-02
    z[5,6,4]  R2362     5.0870066881179810e-01
    z[5,6,4]  R2363     5.2494859695434570e-01
    z[5,6,4]  R2364     2.2784644365310669e-01
    z[5,6,4]  R2365     6.3623136281967163e-01
    z[5,6,4]  R2366     6.6906195878982544e-01
    z[5,6,4]  R2367     0.715188205242157
    z[5,6,4]  R2368     8.1924271583557129e-01
    z[5,6,4]  R2369     7.3967492580413818e-01
    z[5,6,4]  R2370     4.9545809626579285e-01
    z[5,6,4]  R2371     6.3771128654479980e-01
    z[5,6,4]  R2372     6.3362246751785278e-01
    z[5,6,4]  R2373     1.2641207873821259e-01
    z[5,6,4]  R2374     4.4084584712982178e-01
    z[5,6,4]  R2375     5.3377324342727661e-01
    z[5,6,4]  R2376     5.4180890321731567e-01
    z[5,6,4]  R2377     1.1982502788305283e-01
    z[5,6,4]  R2378     3.1549152731895447e-01
    z[5,6,4]  R2379     1.6357085108757019e-01
    z[5,6,4]  R2380     2.0659507811069489e-01
    z[5,6,4]  R2381     3.2729476690292358e-01
    z[5,6,4]  R2382     3.3463621139526367e-01
    z[5,6,4]  R2383     5.3437018394470215e-01
    z[5,6,4]  R2384     5.3751307725906372e-01
    z[5,6,4]  R2385     2.0646791160106659e-01
    z[5,6,4]  R2386     4.4832786917686462e-01
    z[5,6,4]  R2387     2.7401667833328247e-01
    z[5,6,4]  R2388     5.2053558826446533e-01
    z[5,6,4]  R2389     5.4928040504455566e-01
    z[5,6,4]  R2390     1.5408772230148315e-01
    z[5,6,4]  R2391     2.7578663825988770e-01
    z[5,6,4]  R2392     3.2866501808166504e-01
    z[5,6,4]  R2393     -1.2901960313320160e-01
    z[5,6,4]  R2394     0.0457758866250515
    z[5,6,4]  R2395     -2.8694493696093559e-02
    z[5,6,4]  R2396     7.3351776599884033e-01
    z[5,6,4]  R2397     0.338083416223526
    z[5,6,4]  R2398     0.0929412767291069
    z[5,6,4]  R2399     6.1885702610015869e-01
    z[5,6,4]  R2400     -1.6371940076351166e-01
    z[5,6,4]  R2401     -0.0817561224102974
    z[5,6,4]  R2402     -0.0737539529800415
    z[5,6,4]  R2403     2.4493876099586487e-01
    z[5,6,4]  R2404     -6.9230049848556519e-02
    z[5,6,4]  R2405     1.8002241849899292e-01
    z[5,6,4]  R2406     2.5551870465278625e-01
    z[5,6,4]  R2407     6.9033432006835938e-01
    z[5,6,4]  R2408     2.9557922482490540e-01
    z[5,6,4]  R2409     1.9327664747834206e-02
    z[5,6,4]  R2410     7.8321486711502075e-01
    z[5,6,4]  R2411     5.0879049301147461e-01
    z[5,6,4]  R2412     2.1860572695732117e-01
    z[5,6,5]  R52       -1
    z[5,6,5]  R61       1
    z[5,6,5]  R2316     -1
    z[5,6,5]  R2317     1
    z[5,6,5]  R2320     3.8242614269256592e-01
    z[5,6,5]  R2321     5.0597274303436279e-01
    z[5,6,5]  R2322     5.9371012449264526e-01
    z[5,6,5]  R2323     5.5435377359390259e-01
    z[5,6,5]  R2324     -3.4342953003942966e-03
    z[5,6,5]  R2325     9.8959669470787048e-02
    z[5,6,5]  R2326     2.9374006390571594e-01
    z[5,6,5]  R2327     3.2743221521377563e-01
    z[5,6,5]  R2328     1.5588788688182831e-01
    z[5,6,5]  R2329     3.2585912942886353e-01
    z[5,6,5]  R2330     -3.5222217440605164e-01
    z[5,6,5]  R2331     -7.2058849036693573e-02
    z[5,6,5]  R2332     -7.6254093647003174e-01
    z[5,6,5]  R2333     -1.7625318467617035e-01
    z[5,6,5]  R2334     -5.0293862819671631e-01
    z[5,6,5]  R2335     -6.7311418056488037e-01
    z[5,6,5]  R2336     -2.0385213196277618e-01
    z[5,6,5]  R2337     -1.0849576443433762e-01
    z[5,6,5]  R2338     -3.8317084312438965e-01
    z[5,6,5]  R2339     2.3181456327438354e-01
    z[5,6,5]  R2340     1.2535206973552704e-01
    z[5,6,5]  R2341     -7.0958539843559265e-02
    z[5,6,5]  R2342     -1.7830401659011841e-01
    z[5,6,5]  R2343     -5.1603770256042480e-01
    z[5,6,5]  R2344     -2.8873044252395630e-01
    z[5,6,5]  R2345     -5.5137360095977783e-01
    z[5,6,5]  R2346     1.7858842015266418e-01
    z[5,6,5]  R2347     -3.3059626817703247e-01
    z[5,6,5]  R2348     -2.7245754003524780e-01
    z[5,6,5]  R2349     -4.0308335423469543e-01
    z[5,6,5]  R2350     4.5589298009872437e-02
    z[5,6,5]  R2351     -5.7330334186553955e-01
    z[5,6,5]  R2352     -5.0638669729232788e-01
    z[5,6,5]  R2353     3.8519567251205444e-01
    z[5,6,5]  R2354     3.9548525214195251e-01
    z[5,6,5]  R2355     2.0005165040493011e-01
    z[5,6,5]  R2356     -0.018271429464221
    z[5,6,5]  R2357     1.4349387586116791e-01
    z[5,6,5]  R2358     5.8392512798309326e-01
    z[5,6,5]  R2359     2.1635049581527710e-01
    z[5,6,5]  R2360     -1.1129476875066757e-01
    z[5,6,5]  R2361     5.4812282323837280e-01
    z[5,6,5]  R2362     1.7855556309223175e-01
    z[5,6,5]  R2363     3.8373034447431564e-02
    z[5,6,5]  R2364     3.3966964483261108e-01
    z[5,6,5]  R2365     -1.1695603281259537e-01
    z[5,6,5]  R2366     -4.6720793843269348e-01
    z[5,6,5]  R2367     -5.8165037631988525e-01
    z[5,6,5]  R2368     -1.4780853688716888e-01
    z[5,6,5]  R2369     -4.4981312751770020e-01
    z[5,6,5]  R2370     -5.9563565254211426e-01
    z[5,6,5]  R2371     -4.4312477111816406e-02
    z[5,6,5]  R2372     -3.2998120784759521e-01
    z[5,6,5]  R2373     -8.6903309822082520e-01
    z[5,6,5]  R2374     -3.4434261918067932e-01
    z[5,6,5]  R2375     -3.8126403093338013e-01
    z[5,6,5]  R2376     -2.0543164014816284e-01
    z[5,6,5]  R2377     -5.7612472772598267e-01
    z[5,6,5]  R2378     -1.0551296174526215e-01
    z[5,6,5]  R2379     -5.4740172624588013e-01
    z[5,6,5]  R2380     1.8206527456641197e-02
    z[5,6,5]  R2381     -2.8901594877243042e-01
    z[5,6,5]  R2382     -2.9624858498573303e-01
    z[5,6,5]  R2383     -1.8342342972755432e-01
    z[5,6,5]  R2384     3.7831076979637146e-01
    z[5,6,5]  R2385     1.7657433450222015e-01
    z[5,6,5]  R2386     -3.4343191981315613e-01
    z[5,6,5]  R2387     -2.7499023079872131e-01
    z[5,6,5]  R2388     -2.2095876932144165e-01
    z[5,6,5]  R2389     2.4364241957664490e-01
    z[5,6,5]  R2390     -5.7318305969238281e-01
    z[5,6,5]  R2391     -2.4612143635749817e-01
    z[5,6,5]  R2392     -2.8453272581100464e-01
    z[5,6,5]  R2393     0.06783477216959
    z[5,6,5]  R2394     1.8392252922058105e-01
    z[5,6,5]  R2395     -8.6709603667259216e-02
    z[5,6,5]  R2396     -1.7306198179721832e-01
    z[5,6,5]  R2397     1.6388094425201416e-01
    z[5,6,5]  R2398     2.9382398352026939e-02
    z[5,6,5]  R2399     2.2259229794144630e-02
    z[5,6,5]  R2400     -1.5884411334991455e-01
    z[5,6,5]  R2401     1.3070951402187347e-01
    z[5,6,5]  R2402     3.4013697504997253e-01
    z[5,6,5]  R2403     2.4353970587253571e-01
    z[5,6,5]  R2404     3.0460250377655029e-01
    z[5,6,5]  R2405     1.4695046842098236e-01
    z[5,6,5]  R2406     -2.7154510840773582e-02
    z[5,6,5]  R2407     -4.0896151214838028e-02
    z[5,6,5]  R2408     -5.0095748156309128e-02
    z[5,6,5]  R2409     4.9466714262962341e-01
    z[5,6,5]  R2410     -1.7966248095035553e-01
    z[5,6,5]  R2411     -2.6726812124252319e-01
    z[5,6,5]  R2412     -2.2878044843673706e-01
    z[5,6,6]  R53       -1
    z[5,6,6]  R62       1
    z[5,6,6]  R2318     -1
    z[5,6,6]  R2319     1
    z[5,6,6]  R2320     2.7778422459959984e-02
    z[5,6,6]  R2321     -2.4745856225490570e-01
    z[5,6,6]  R2322     1.2494678609073162e-02
    z[5,6,6]  R2323     2.5164343416690826e-02
    z[5,6,6]  R2324     7.5825154781341553e-02
    z[5,6,6]  R2325     2.1239224076271057e-01
    z[5,6,6]  R2326     -2.0509015023708344e-01
    z[5,6,6]  R2327     2.0678873360157013e-01
    z[5,6,6]  R2328     -8.5689671337604523e-02
    z[5,6,6]  R2329     2.1212226711213589e-03
    z[5,6,6]  R2330     3.5165277123451233e-01
    z[5,6,6]  R2331     1.8630404770374298e-01
    z[5,6,6]  R2332     1.3250321149826050e-01
    z[5,6,6]  R2333     2.5208277627825737e-02
    z[5,6,6]  R2334     1.9400231540203094e-01
    z[5,6,6]  R2335     1.7305904626846313e-01
    z[5,6,6]  R2336     -0.234492689371109
    z[5,6,6]  R2337     -4.8598459362983704e-01
    z[5,6,6]  R2338     -1.0857817530632019e-01
    z[5,6,6]  R2339     -1.4566726982593536e-01
    z[5,6,6]  R2340     8.4196001291275024e-02
    z[5,6,6]  R2341     -1.1761871725320816e-01
    z[5,6,6]  R2342     -5.5409427732229233e-02
    z[5,6,6]  R2343     1.6645808517932892e-01
    z[5,6,6]  R2344     2.0787145197391510e-01
    z[5,6,6]  R2345     1.0104341804981232e-01
    z[5,6,6]  R2346     5.2588790655136108e-01
    z[5,6,6]  R2347     -2.5872574187815189e-03
    z[5,6,6]  R2348     2.2560091689229012e-02
    z[5,6,6]  R2349     -3.6706754565238953e-01
    z[5,6,6]  R2350     7.9674273729324341e-02
    z[5,6,6]  R2351     5.0857108086347580e-02
    z[5,6,6]  R2352     -9.6527636051177979e-02
    z[5,6,6]  R2353     -5.5138994008302689e-02
    z[5,6,6]  R2354     -0.000664629100356251
    z[5,6,6]  R2355     1.5300613641738892e-01
    z[5,6,6]  R2356     3.7954360246658325e-01
    z[5,6,6]  R2357     7.6548673212528229e-02
    z[5,6,6]  R2358     -1.2867036461830139e-01
    z[5,6,6]  R2359     -5.1571053266525269e-01
    z[5,6,6]  R2360     4.7039404511451721e-01
    z[5,6,6]  R2361     3.7784385681152344e-01
    z[5,6,6]  R2362     -3.6855155229568481e-01
    z[5,6,6]  R2363     -1.6202476620674133e-01
    z[5,6,6]  R2364     -3.6887574940919876e-02
    z[5,6,6]  R2365     -6.1799097061157227e-01
    z[5,6,6]  R2366     -6.7602782510221004e-03
    z[5,6,6]  R2367     -1.1672931723296642e-02
    z[5,6,6]  R2368     1.8062233924865723e-01
    z[5,6,6]  R2369     0.368488609790802
    z[5,6,6]  R2370     3.7670186161994934e-01
    z[5,6,6]  R2371     2.9757311940193176e-01
    z[5,6,6]  R2372     2.2021479904651642e-01
    z[5,6,6]  R2373     -2.0640711486339569e-01
    z[5,6,6]  R2374     -1.9189366698265076e-01
    z[5,6,6]  R2375     -1.3751919567584991e-01
    z[5,6,6]  R2376     -0.345706045627594
    z[5,6,6]  R2377     2.2112955152988434e-01
    z[5,6,6]  R2378     3.3739423751831055e-01
    z[5,6,6]  R2379     2.9497742652893066e-01
    z[5,6,6]  R2380     -2.0037274062633514e-01
    z[5,6,6]  R2381     2.0725630223751068e-01
    z[5,6,6]  R2382     -2.3145695030689240e-01
    z[5,6,6]  R2383     -5.2521222829818726e-01
    z[5,6,6]  R2384     -1.3092701137065887e-01
    z[5,6,6]  R2385     -1.5891024842858315e-02
    z[5,6,6]  R2386     -9.6572116017341614e-02
    z[5,6,6]  R2387     2.2791130840778351e-01
    z[5,6,6]  R2388     1.6141925752162933e-01
    z[5,6,6]  R2389     3.1756326556205750e-01
    z[5,6,6]  R2390     -4.5917022228240967e-01
    z[5,6,6]  R2391     -3.1051045656204224e-01
    z[5,6,6]  R2392     -1.4357627928256989e-01
    z[5,6,6]  R2393     2.4317464232444763e-01
    z[5,6,6]  R2394     -2.9501739144325256e-01
    z[5,6,6]  R2395     2.4745029211044312e-01
    z[5,6,6]  R2396     8.3945758640766144e-02
    z[5,6,6]  R2397     0.151498481631279
    z[5,6,6]  R2398     4.9973125569522381e-03
    z[5,6,6]  R2399     -3.1996732950210571e-01
    z[5,6,6]  R2400     1.3361082971096039e-01
    z[5,6,6]  R2401     -1.6888926923274994e-01
    z[5,6,6]  R2402     1.0487063229084015e-01
    z[5,6,6]  R2403     -1.3252280652523041e-01
    z[5,6,6]  R2404     -2.5968968868255615e-02
    z[5,6,6]  R2405     1.6199924051761627e-01
    z[5,6,6]  R2406     -1.4860944449901581e-01
    z[5,6,6]  R2407     -2.9217207431793213e-01
    z[5,6,6]  R2408     -1.1926929652690887e-01
    z[5,6,6]  R2409     -4.1505265235900879e-01
    z[5,6,6]  R2410     -0.0943610891699791
    z[5,6,6]  R2411     -6.3995391130447388e-01
    z[5,6,6]  R2412     -1.2046817690134048e-01
    z[6,5,0]  R47       1
    z[6,5,0]  R56       -1
    z[6,5,0]  R2413     -1
    z[6,5,0]  R2414     1
    z[6,5,0]  R2427     -2.6799976825714111e-01
    z[6,5,0]  R2428     -3.0848485231399536e-01
    z[6,5,0]  R2429     -0.502948522567749
    z[6,5,0]  R2430     -4.1463658213615417e-01
    z[6,5,0]  R2431     -4.0166664123535156e-01
    z[6,5,0]  R2432     -6.7071980237960815e-01
    z[6,5,0]  R2433     4.1482448577880859e-01
    z[6,5,0]  R2434     1.3724394142627716e-01
    z[6,5,0]  R2435     1.4065656065940857e-01
    z[6,5,0]  R2436     -1.9479477405548096e-01
    z[6,5,0]  R2437     3.3613452315330505e-01
    z[6,5,0]  R2438     1.0425824671983719e-01
    z[6,5,0]  R2439     0.254373162984848
    z[6,5,0]  R2440     -1.9016842544078827e-01
    z[6,5,0]  R2441     1.0421057045459747e-01
    z[6,5,0]  R2442     5.0094765424728394e-01
    z[6,5,0]  R2443     -4.1455483436584473e-01
    z[6,5,0]  R2444     -1.5327689051628113e-01
    z[6,5,0]  R2445     -7.3224997520446777e-01
    z[6,5,0]  R2446     -4.9367743730545044e-01
    z[6,5,0]  R2447     1.4100821316242218e-01
    z[6,5,0]  R2448     2.1753439307212830e-01
    z[6,5,0]  R2449     -1.2073613703250885e-01
    z[6,5,0]  R2450     -1.8786756694316864e-01
    z[6,5,0]  R2451     -9.2207081615924835e-03
    z[6,5,0]  R2452     2.0490171015262604e-01
    z[6,5,0]  R2453     -4.1622537374496460e-01
    z[6,5,0]  R2454     -0.274004727602005
    z[6,5,0]  R2455     1.6240687668323517e-01
    z[6,5,0]  R2456     -5.9607338905334473e-01
    z[6,5,0]  R2457     -3.1939432024955750e-01
    z[6,5,0]  R2458     -4.3587210774421692e-01
    z[6,5,0]  R2459     4.1314664483070374e-01
    z[6,5,0]  R2460     -1.7168661952018738e-01
    z[6,5,0]  R2461     -0.0768650621175766
    z[6,5,0]  R2462     1.2949213385581970e-01
    z[6,5,0]  R2463     -8.7719194591045380e-02
    z[6,5,0]  R2464     5.6931927800178528e-02
    z[6,5,0]  R2465     5.4856240749359131e-01
    z[6,5,0]  R2466     6.0297280550003052e-01
    z[6,5,0]  R2467     -1.9797690212726593e-01
    z[6,5,0]  R2468     1.5428879298269749e-02
    z[6,5,0]  R2469     1.7626523971557617e-01
    z[6,5,0]  R2470     4.1131421923637390e-01
    z[6,5,0]  R2471     2.3615600541234016e-02
    z[6,5,0]  R2472     5.5942213535308838e-01
    z[6,5,0]  R2473     3.5299485921859741e-01
    z[6,5,0]  R2474     -1.6912724822759628e-02
    z[6,5,0]  R2475     1.3452319800853729e-01
    z[6,5,0]  R2476     2.1778613328933716e-01
    z[6,5,0]  R2477     -2.8781610727310181e-01
    z[6,5,0]  R2478     3.7395498156547546e-01
    z[6,5,0]  R2479     2.0948988199234009e-01
    z[6,5,0]  R2480     1.1307834833860397e-01
    z[6,5,0]  R2481     -1.8201948702335358e-01
    z[6,5,0]  R2482     -2.8810063004493713e-01
    z[6,5,0]  R2483     9.0143084526062012e-01
    z[6,5,0]  R2484     4.8252713680267334e-01
    z[6,5,0]  R2485     3.9966791868209839e-01
    z[6,5,0]  R2486     0.402807354927063
    z[6,5,0]  R2487     0.506476879119873
    z[6,5,0]  R2488     3.8504651188850403e-01
    z[6,5,0]  R2489     8.1525808572769165e-01
    z[6,5,0]  R2490     1.3341283798217773e-01
    z[6,5,0]  R2491     7.1224117279052734e-01
    z[6,5,0]  R2492     1.9481061398983002e-01
    z[6,5,0]  R2493     -1.5624713897705078e-01
    z[6,5,0]  R2494     1.8087498843669891e-02
    z[6,5,0]  R2495     -2.4753254652023315e-01
    z[6,5,0]  R2496     -1.8546250462532043e-01
    z[6,5,0]  R2497     -5.6664252281188965e-01
    z[6,5,0]  R2498     -4.5358520746231079e-01
    z[6,5,0]  R2499     -3.3044105768203735e-01
    z[6,5,0]  R2500     -7.2640764713287354e-01
    z[6,5,0]  R2501     -0.276757150888443
    z[6,5,0]  R2502     -3.7866771221160889e-01
    z[6,5,0]  R2503     -5.9387886524200439e-01
    z[6,5,0]  R2504     -2.3243264853954315e-01
    z[6,5,0]  R2505     -4.6389874815940857e-01
    z[6,5,0]  R2506     -5.6616473197937012e-01
    z[6,5,0]  R2507     0.01770637370646
    z[6,5,0]  R2508     -0.0440821535885334
    z[6,5,0]  R2509     -1.9195194542407990e-01
    z[6,5,0]  R2510     1.2960492074489594e-01
    z[6,5,0]  R2511     1.6947485506534576e-01
    z[6,5,0]  R2512     1.3789768517017365e-01
    z[6,5,0]  R2513     -2.1324107050895691e-01
    z[6,5,0]  R2514     5.0671076774597168e-01
    z[6,5,0]  R2515     -1.9885918498039246e-01
    z[6,5,0]  R2516     -3.0448371171951294e-01
    z[6,5,0]  R2517     -5.0142383575439453e-01
    z[6,5,0]  R2518     -5.4543703794479370e-01
    z[6,5,0]  R2519     -4.7971585392951965e-01
    z[6,5,1]  R48       1
    z[6,5,1]  R57       -1
    z[6,5,1]  R2415     -1
    z[6,5,1]  R2416     1
    z[6,5,1]  R2427     2.6034945249557495e-01
    z[6,5,1]  R2428     -3.4273234009742737e-01
    z[6,5,1]  R2429     3.3970236778259277e-01
    z[6,5,1]  R2430     0.287553071975708
    z[6,5,1]  R2431     -1.8081579357385635e-02
    z[6,5,1]  R2432     -1.0382114350795746e-01
    z[6,5,1]  R2433     6.3087075948715210e-01
    z[6,5,1]  R2434     6.6886502504348755e-01
    z[6,5,1]  R2435     7.1507990360260010e-01
    z[6,5,1]  R2436     1.6465568542480469e-01
    z[6,5,1]  R2437     -1.9731727242469788e-01
    z[6,5,1]  R2438     2.3253744840621948e-01
    z[6,5,1]  R2439     -1.3593323528766632e-01
    z[6,5,1]  R2440     4.5358244329690933e-02
    z[6,5,1]  R2441     -0.3088398873806
    z[6,5,1]  R2442     -2.1598720923066139e-02
    z[6,5,1]  R2443     -1.5587671659886837e-02
    z[6,5,1]  R2444     -1.1244186758995056e-01
    z[6,5,1]  R2445     -1.2262280285358429e-01
    z[6,5,1]  R2446     -4.1260862350463867e-01
    z[6,5,1]  R2447     -2.0453684031963348e-01
    z[6,5,1]  R2448     1.3772989809513092e-01
    z[6,5,1]  R2449     -3.0731928348541260e-01
    z[6,5,1]  R2450     3.0537009239196777e-01
    z[6,5,1]  R2451     1.7410951852798462e-01
    z[6,5,1]  R2452     5.5265665054321289e-01
    z[6,5,1]  R2453     3.9770871400833130e-01
    z[6,5,1]  R2454     1.5753868967294693e-02
    z[6,5,1]  R2455     -2.0316170156002045e-01
    z[6,5,1]  R2456     -2.0895386114716530e-02
    z[6,5,1]  R2457     3.3721652626991272e-01
    z[6,5,1]  R2458     0.0609736330807209
    z[6,5,1]  R2459     -3.0422195792198181e-01
    z[6,5,1]  R2460     2.3960523307323456e-01
    z[6,5,1]  R2461     5.8998677879571915e-02
    z[6,5,1]  R2462     8.6291587352752686e-01
    z[6,5,1]  R2463     8.5653185844421387e-01
    z[6,5,1]  R2464     8.1906998157501221e-01
    z[6,5,1]  R2465     7.3512208461761475e-01
    z[6,5,1]  R2466     4.4444590806961060e-01
    z[6,5,1]  R2467     -2.5734481215476990e-01
    z[6,5,1]  R2468     3.8917216658592224e-01
    z[6,5,1]  R2469     9.5235210657119751e-01
    z[6,5,1]  R2470     -1.1356313712894917e-02
    z[6,5,1]  R2471     9.0541803836822510e-01
    z[6,5,1]  R2472     5.4022759199142456e-01
    z[6,5,1]  R2473     5.0834619998931885e-01
    z[6,5,1]  R2474     -9.0297651290893555e-01
    z[6,5,1]  R2475     -8.1154477596282959e-01
    z[6,5,1]  R2476     -9.0584987401962280e-01
    z[6,5,1]  R2477     -1.6611185669898987e-01
    z[6,5,1]  R2478     9.2443414032459259e-02
    z[6,5,1]  R2479     3.8873386383056641e-01
    z[6,5,1]  R2480     -6.8229228258132935e-01
    z[6,5,1]  R2481     -3.2924848794937134e-01
    z[6,5,1]  R2482     -2.0766112208366394e-01
    z[6,5,1]  R2483     -1.3121864199638367e-01
    z[6,5,1]  R2484     -2.9579332470893860e-01
    z[6,5,1]  R2485     -3.3140763640403748e-01
    z[6,5,1]  R2486     3.6768081784248352e-01
    z[6,5,1]  R2487     -3.8896843791007996e-02
    z[6,5,1]  R2488     -3.9393520355224609e-01
    z[6,5,1]  R2489     -0.417843759059906
    z[6,5,1]  R2490     2.1209548413753510e-01
    z[6,5,1]  R2491     -5.1100033521652222e-01
    z[6,5,1]  R2492     8.0563133955001831e-01
    z[6,5,1]  R2493     8.0624979734420776e-01
    z[6,5,1]  R2494     5.9764266014099121e-01
    z[6,5,1]  R2495     4.2195639014244080e-01
    z[6,5,1]  R2496     3.9931362867355347e-01
    z[6,5,1]  R2497     4.5708245038986206e-01
    z[6,5,1]  R2498     4.1171273589134216e-01
    z[6,5,1]  R2499     4.4868674874305725e-01
    z[6,5,1]  R2500     4.4769674539566040e-01
    z[6,5,1]  R2501     -4.8848456144332886e-01
    z[6,5,1]  R2502     1.7885313928127289e-01
    z[6,5,1]  R2503     -7.0007240772247314e-01
    z[6,5,1]  R2504     7.5460141897201538e-01
    z[6,5,1]  R2505     7.0336228609085083e-01
    z[6,5,1]  R2506     7.3183369636535645e-01
    z[6,5,1]  R2507     6.8371903896331787e-01
    z[6,5,1]  R2508     7.2825807332992554e-01
    z[6,5,1]  R2509     6.1534881591796875e-01
    z[6,5,1]  R2510     5.5842143297195435e-01
    z[6,5,1]  R2511     6.6320836544036865e-01
    z[6,5,1]  R2512     5.2656018733978271e-01
    z[6,5,1]  R2513     0.50145024061203
    z[6,5,1]  R2514     0.673224151134491
    z[6,5,1]  R2515     0.654941976070404
    z[6,5,1]  R2516     -6.9678771495819092e-01
    z[6,5,1]  R2517     -6.7250436544418335e-01
    z[6,5,1]  R2518     -5.7821273803710938e-01
    z[6,5,1]  R2519     -6.0361069440841675e-01
    z[6,5,2]  R49       1
    z[6,5,2]  R58       -1
    z[6,5,2]  R2417     -1
    z[6,5,2]  R2418     1
    z[6,5,2]  R2427     -3.9756676554679871e-01
    z[6,5,2]  R2428     -4.9994894862174988e-01
    z[6,5,2]  R2429     -2.3084443807601929e-01
    z[6,5,2]  R2430     -2.0341536402702332e-01
    z[6,5,2]  R2431     1.1693882942199707e-01
    z[6,5,2]  R2432     8.1346176564693451e-02
    z[6,5,2]  R2433     -2.8455637395381927e-02
    z[6,5,2]  R2434     -4.7480916976928711e-01
    z[6,5,2]  R2435     0.399924099445343
    z[6,5,2]  R2436     -3.5927772521972656e-01
    z[6,5,2]  R2437     -2.6057684421539307e-01
    z[6,5,2]  R2438     7.0517949759960175e-02
    z[6,5,2]  R2439     1.9377246499061584e-01
    z[6,5,2]  R2440     -3.5220120102167130e-02
    z[6,5,2]  R2441     -1.5724499523639679e-01
    z[6,5,2]  R2442     -0.251311331987381
    z[6,5,2]  R2443     -4.4861888885498047e-01
    z[6,5,2]  R2444     8.4616623818874359e-02
    z[6,5,2]  R2445     -4.3666278943419456e-03
    z[6,5,2]  R2446     2.8069657087326050e-01
    z[6,5,2]  R2447     1.4100825786590576e-01
    z[6,5,2]  R2448     -8.8609211146831512e-02
    z[6,5,2]  R2449     -3.8922277092933655e-01
    z[6,5,2]  R2450     -8.1903554499149323e-02
    z[6,5,2]  R2451     -0.564672589302063
    z[6,5,2]  R2452     -3.1437207013368607e-02
    z[6,5,2]  R2453     -1.1584430932998657e-01
    z[6,5,2]  R2454     -2.2531510889530182e-01
    z[6,5,2]  R2455     2.7839755639433861e-03
    z[6,5,2]  R2456     -5.0746973603963852e-02
    z[6,5,2]  R2457     -2.3050782084465027e-01
    z[6,5,2]  R2458     2.4781459942460060e-02
    z[6,5,2]  R2459     -6.3811242580413818e-02
    z[6,5,2]  R2460     -8.2455776631832123e-02
    z[6,5,2]  R2461     -2.8026726841926575e-01
    z[6,5,2]  R2462     7.1502029895782471e-02
    z[6,5,2]  R2463     2.1758085489273071e-01
    z[6,5,2]  R2464     3.5238778591156006e-01
    z[6,5,2]  R2465     -1.8645766377449036e-01
    z[6,5,2]  R2466     3.1171867251396179e-01
    z[6,5,2]  R2467     -3.9491170644760132e-01
    z[6,5,2]  R2468     1.6960716247558594e-01
    z[6,5,2]  R2469     -1.4601002633571625e-01
    z[6,5,2]  R2470     -4.1508537530899048e-01
    z[6,5,2]  R2471     2.7347663044929504e-01
    z[6,5,2]  R2472     2.0718546211719513e-01
    z[6,5,2]  R2473     3.8754299283027649e-01
    z[6,5,2]  R2474     7.2244450449943542e-02
    z[6,5,2]  R2475     0.145552858710289
    z[6,5,2]  R2476     5.7123210281133652e-02
    z[6,5,2]  R2477     -3.3237934112548828e-01
    z[6,5,2]  R2478     -3.8678976893424988e-01
    z[6,5,2]  R2479     5.5587112903594971e-01
    z[6,5,2]  R2480     -3.4621194005012512e-02
    z[6,5,2]  R2481     -0.0864488035440445
    z[6,5,2]  R2482     -1.7532606422901154e-01
    z[6,5,2]  R2483     -0.0704229474067688
    z[6,5,2]  R2484     6.5029317140579224e-01
    z[6,5,2]  R2485     2.3039247095584869e-01
    z[6,5,2]  R2486     5.5591195821762085e-01
    z[6,5,2]  R2487     3.4478139877319336e-01
    z[6,5,2]  R2488     4.7812196612358093e-01
    z[6,5,2]  R2489     3.3615015447139740e-02
    z[6,5,2]  R2490     5.6970185041427612e-01
    z[6,5,2]  R2491     -1.1947441101074219e-01
    z[6,5,2]  R2492     -3.0314254760742188e-01
    z[6,5,2]  R2493     -4.1481822729110718e-02
    z[6,5,2]  R2494     1.9685681164264679e-01
    z[6,5,2]  R2495     -2.0552419126033783e-01
    z[6,5,2]  R2496     -1.6960366070270538e-01
    z[6,5,2]  R2497     -2.7856704592704773e-01
    z[6,5,2]  R2498     -2.1651954948902130e-01
    z[6,5,2]  R2499     3.3400931954383850e-01
    z[6,5,2]  R2500     2.2183121740818024e-01
    z[6,5,2]  R2501     -4.7147122025489807e-01
    z[6,5,2]  R2502     -3.6279717087745667e-01
    z[6,5,2]  R2503     -1.6546821594238281e-01
    z[6,5,2]  R2504     -2.2869546711444855e-01
    z[6,5,2]  R2505     6.2293823808431625e-02
    z[6,5,2]  R2506     1.7335507273674011e-01
    z[6,5,2]  R2507     4.2720317840576172e-01
    z[6,5,2]  R2508     -2.0526179671287537e-01
    z[6,5,2]  R2509     2.8183031082153320e-01
    z[6,5,2]  R2510     -2.2353968024253845e-01
    z[6,5,2]  R2511     3.6107987165451050e-01
    z[6,5,2]  R2512     -1.0032659024000168e-01
    z[6,5,2]  R2513     -2.8439259529113770e-01
    z[6,5,2]  R2514     -5.0510197877883911e-01
    z[6,5,2]  R2515     -2.8678017854690552e-01
    z[6,5,2]  R2516     1.0988084971904755e-01
    z[6,5,2]  R2517     -1.1029504239559174e-01
    z[6,5,2]  R2518     1.6776882112026215e-01
    z[6,5,2]  R2519     2.3622474074363708e-01
    z[6,5,3]  R50       1
    z[6,5,3]  R59       -1
    z[6,5,3]  R2419     -1
    z[6,5,3]  R2420     1
    z[6,5,3]  R2427     6.5393263101577759e-01
    z[6,5,3]  R2428     5.0959396362304688e-01
    z[6,5,3]  R2429     4.0262740850448608e-01
    z[6,5,3]  R2430     0.0463026687502861
    z[6,5,3]  R2431     -7.2940096259117126e-02
    z[6,5,3]  R2432     2.8767937421798706e-01
    z[6,5,3]  R2433     -0.0512276254594326
    z[6,5,3]  R2434     -7.1023985743522644e-02
    z[6,5,3]  R2435     -3.7454909086227417e-01
    z[6,5,3]  R2436     -7.4034363031387329e-02
    z[6,5,3]  R2437     -3.3794444799423218e-01
    z[6,5,3]  R2438     -2.8308334946632385e-01
    z[6,5,3]  R2439     -0.391967236995697
    z[6,5,3]  R2440     -2.7441471815109253e-01
    z[6,5,3]  R2441     -3.5618439316749573e-01
    z[6,5,3]  R2442     -4.3386444449424744e-01
    z[6,5,3]  R2443     -2.6035135984420776e-01
    z[6,5,3]  R2444     -3.7802201509475708e-01
    z[6,5,3]  R2445     -3.1466564536094666e-01
    z[6,5,3]  R2446     -2.4095329642295837e-01
    z[6,5,3]  R2447     -6.8053388595581055e-01
    z[6,5,3]  R2448     -7.2847908735275269e-01
    z[6,5,3]  R2449     -7.1762156486511230e-01
    z[6,5,3]  R2450     -6.7181175947189331e-01
    z[6,5,3]  R2451     -7.5338131189346313e-01
    z[6,5,3]  R2452     -6.4652174711227417e-01
    z[6,5,3]  R2453     -6.3391441106796265e-01
    z[6,5,3]  R2454     -5.2807462215423584e-01
    z[6,5,3]  R2455     -6.9509744644165039e-01
    z[6,5,3]  R2456     -7.5340855121612549e-01
    z[6,5,3]  R2457     -6.3471955060958862e-01
    z[6,5,3]  R2458     -7.7655339241027832e-01
    z[6,5,3]  R2459     -6.2197327613830566e-01
    z[6,5,3]  R2460     -6.6663116216659546e-01
    z[6,5,3]  R2461     -5.9071314334869385e-01
    z[6,5,3]  R2462     2.1089186891913414e-02
    z[6,5,3]  R2463     4.1512794792652130e-02
    z[6,5,3]  R2464     -3.4831660985946655e-01
    z[6,5,3]  R2465     -3.0824735760688782e-02
    z[6,5,3]  R2466     -5.2167940139770508e-01
    z[6,5,3]  R2467     -4.0444770455360413e-01
    z[6,5,3]  R2468     -8.0958712100982666e-01
    z[6,5,3]  R2469     -1.7638245224952698e-01
    z[6,5,3]  R2470     -4.1537594795227051e-01
    z[6,5,3]  R2471     -1.8703933060169220e-01
    z[6,5,3]  R2472     -5.4770672321319580e-01
    z[6,5,3]  R2473     -5.7849675416946411e-01
    z[6,5,3]  R2474     -2.0557032525539398e-01
    z[6,5,3]  R2475     -4.5151209831237793e-01
    z[6,5,3]  R2476     -2.2021782398223877e-01
    z[6,5,3]  R2477     -8.3125251531600952e-01
    z[6,5,3]  R2478     -0.372031033039093
    z[6,5,3]  R2479     -0.626023530960083
    z[6,5,3]  R2480     -3.2117596268653870e-01
    z[6,5,3]  R2481     4.4315099716186523e-01
    z[6,5,3]  R2482     3.2139471173286438e-01
    z[6,5,3]  R2483     2.2495168447494507e-01
    z[6,5,3]  R2484     3.3118334412574768e-01
    z[6,5,3]  R2485     5.2328133583068848e-01
    z[6,5,3]  R2486     6.3107900321483612e-02
    z[6,5,3]  R2487     -3.7122715730220079e-03
    z[6,5,3]  R2488     1.1415149271488190e-01
    z[6,5,3]  R2489     2.2451011836528778e-01
    z[6,5,3]  R2490     3.1727319955825806e-01
    z[6,5,3]  R2491     -1.0649629682302475e-01
    z[6,5,3]  R2492     1.8137918412685394e-01
    z[6,5,3]  R2493     4.3290373682975769e-01
    z[6,5,3]  R2494     -3.4623432159423828e-01
    z[6,5,3]  R2495     -0.375354528427124
    z[6,5,3]  R2496     -6.7517482675611973e-03
    z[6,5,3]  R2497     -3.3685654401779175e-01
    z[6,5,3]  R2498     -4.8288854956626892e-01
    z[6,5,3]  R2499     -2.4150630831718445e-01
    z[6,5,3]  R2500     1.5619641542434692e-01
    z[6,5,3]  R2501     -1.4916208386421204e-01
    z[6,5,3]  R2502     -2.1368719637393951e-01
    z[6,5,3]  R2503     -2.2419057786464691e-01
    z[6,5,3]  R2504     -4.1027626395225525e-01
    z[6,5,3]  R2505     3.5584408789873123e-02
    z[6,5,3]  R2506     -2.5215500593185425e-01
    z[6,5,3]  R2507     -0.0723184123635292
    z[6,5,3]  R2508     -4.9420168995857239e-01
    z[6,5,3]  R2509     2.2640155255794525e-01
    z[6,5,3]  R2510     -1.4711397886276245e-01
    z[6,5,3]  R2511     4.0763825178146362e-01
    z[6,5,3]  R2512     2.9277700185775757e-01
    z[6,5,3]  R2513     5.6977385282516479e-01
    z[6,5,3]  R2514     -1.2279611080884933e-02
    z[6,5,3]  R2515     -3.3612366765737534e-02
    z[6,5,3]  R2516     3.4877711534500122e-01
    z[6,5,3]  R2517     -3.0873927474021912e-01
    z[6,5,3]  R2518     -4.2799431085586548e-01
    z[6,5,3]  R2519     -5.2732646465301514e-01
    z[6,5,4]  R51       1
    z[6,5,4]  R60       -1
    z[6,5,4]  R2421     -1
    z[6,5,4]  R2422     1
    z[6,5,4]  R2427     -3.6099845170974731e-01
    z[6,5,4]  R2428     -5.0128477811813354e-01
    z[6,5,4]  R2429     -2.4232718348503113e-01
    z[6,5,4]  R2430     -6.2378132343292236e-01
    z[6,5,4]  R2431     -7.6530051231384277e-01
    z[6,5,4]  R2432     -8.2309916615486145e-02
    z[6,5,4]  R2433     5.0870066881179810e-01
    z[6,5,4]  R2434     5.2494859695434570e-01
    z[6,5,4]  R2435     2.2784644365310669e-01
    z[6,5,4]  R2436     6.3623136281967163e-01
    z[6,5,4]  R2437     6.6906195878982544e-01
    z[6,5,4]  R2438     0.715188205242157
    z[6,5,4]  R2439     8.1924271583557129e-01
    z[6,5,4]  R2440     7.3967492580413818e-01
    z[6,5,4]  R2441     4.9545809626579285e-01
    z[6,5,4]  R2442     6.3771128654479980e-01
    z[6,5,4]  R2443     6.3362246751785278e-01
    z[6,5,4]  R2444     1.2641207873821259e-01
    z[6,5,4]  R2445     4.4084584712982178e-01
    z[6,5,4]  R2446     5.3377324342727661e-01
    z[6,5,4]  R2447     5.4180890321731567e-01
    z[6,5,4]  R2448     1.1982502788305283e-01
    z[6,5,4]  R2449     3.1549152731895447e-01
    z[6,5,4]  R2450     1.6357085108757019e-01
    z[6,5,4]  R2451     2.0659507811069489e-01
    z[6,5,4]  R2452     3.2729476690292358e-01
    z[6,5,4]  R2453     3.3463621139526367e-01
    z[6,5,4]  R2454     5.3437018394470215e-01
    z[6,5,4]  R2455     5.3751307725906372e-01
    z[6,5,4]  R2456     2.0646791160106659e-01
    z[6,5,4]  R2457     4.4832786917686462e-01
    z[6,5,4]  R2458     2.7401667833328247e-01
    z[6,5,4]  R2459     5.2053558826446533e-01
    z[6,5,4]  R2460     5.4928040504455566e-01
    z[6,5,4]  R2461     1.5408772230148315e-01
    z[6,5,4]  R2462     2.7578663825988770e-01
    z[6,5,4]  R2463     3.2866501808166504e-01
    z[6,5,4]  R2464     -1.2901960313320160e-01
    z[6,5,4]  R2465     0.0457758866250515
    z[6,5,4]  R2466     -2.8694493696093559e-02
    z[6,5,4]  R2467     7.3351776599884033e-01
    z[6,5,4]  R2468     0.338083416223526
    z[6,5,4]  R2469     0.0929412767291069
    z[6,5,4]  R2470     6.1885702610015869e-01
    z[6,5,4]  R2471     -1.6371940076351166e-01
    z[6,5,4]  R2472     -0.0817561224102974
    z[6,5,4]  R2473     -0.0737539529800415
    z[6,5,4]  R2474     2.4493876099586487e-01
    z[6,5,4]  R2475     -6.9230049848556519e-02
    z[6,5,4]  R2476     1.8002241849899292e-01
    z[6,5,4]  R2477     2.5551870465278625e-01
    z[6,5,4]  R2478     6.9033432006835938e-01
    z[6,5,4]  R2479     2.9557922482490540e-01
    z[6,5,4]  R2480     1.9327664747834206e-02
    z[6,5,4]  R2481     7.8321486711502075e-01
    z[6,5,4]  R2482     5.0879049301147461e-01
    z[6,5,4]  R2483     2.1860572695732117e-01
    z[6,5,4]  R2484     9.4280634075403214e-03
    z[6,5,4]  R2485     2.9374551773071289e-01
    z[6,5,4]  R2486     1.9206385314464569e-01
    z[6,5,4]  R2487     5.6137222051620483e-01
    z[6,5,4]  R2488     6.7019534111022949e-01
    z[6,5,4]  R2489     -2.3307195305824280e-01
    z[6,5,4]  R2490     6.1939394474029541e-01
    z[6,5,4]  R2491     2.3664748668670654e-01
    z[6,5,4]  R2492     3.9568841457366943e-01
    z[6,5,4]  R2493     1.7387686669826508e-01
    z[6,5,4]  R2494     -4.8594778776168823e-01
    z[6,5,4]  R2495     -7.3324447870254517e-01
    z[6,5,4]  R2496     -4.2227414250373840e-01
    z[6,5,4]  R2497     -4.9721163511276245e-01
    z[6,5,4]  R2498     -2.3260879516601562e-01
    z[6,5,4]  R2499     1.9123084843158722e-01
    z[6,5,4]  R2500     -3.1898370385169983e-01
    z[6,5,4]  R2501     4.3852204084396362e-01
    z[6,5,4]  R2502     6.9909161329269409e-01
    z[6,5,4]  R2503     6.7884959280490875e-02
    z[6,5,4]  R2504     -3.6485812067985535e-01
    z[6,5,4]  R2505     -5.1581335067749023e-01
    z[6,5,4]  R2506     1.2401795387268066e-01
    z[6,5,4]  R2507     2.2467546164989471e-01
    z[6,5,4]  R2508     2.3399452865123749e-01
    z[6,5,4]  R2509     -3.7361967563629150e-01
    z[6,5,4]  R2510     -5.3972554206848145e-01
    z[6,5,4]  R2511     -3.5437917709350586e-01
    z[6,5,4]  R2512     -7.3020040988922119e-01
    z[6,5,4]  R2513     1.8432773649692535e-02
    z[6,5,4]  R2514     -1.6219811141490936e-01
    z[6,5,4]  R2515     -3.4186261892318726e-01
    z[6,5,4]  R2516     -1.4937274158000946e-01
    z[6,5,4]  R2517     -1.9341942667961121e-01
    z[6,5,4]  R2518     2.0830312743782997e-02
    z[6,5,4]  R2519     -9.0662986040115356e-02
    z[6,5,5]  R52       1
    z[6,5,5]  R61       -1
    z[6,5,5]  R2423     -1
    z[6,5,5]  R2424     1
    z[6,5,5]  R2427     -0.018271429464221
    z[6,5,5]  R2428     1.4349387586116791e-01
    z[6,5,5]  R2429     5.8392512798309326e-01
    z[6,5,5]  R2430     2.1635049581527710e-01
    z[6,5,5]  R2431     -1.1129476875066757e-01
    z[6,5,5]  R2432     5.4812282323837280e-01
    z[6,5,5]  R2433     1.7855556309223175e-01
    z[6,5,5]  R2434     3.8373034447431564e-02
    z[6,5,5]  R2435     3.3966964483261108e-01
    z[6,5,5]  R2436     -1.1695603281259537e-01
    z[6,5,5]  R2437     -4.6720793843269348e-01
    z[6,5,5]  R2438     -5.8165037631988525e-01
    z[6,5,5]  R2439     -1.4780853688716888e-01
    z[6,5,5]  R2440     -4.4981312751770020e-01
    z[6,5,5]  R2441     -5.9563565254211426e-01
    z[6,5,5]  R2442     -4.4312477111816406e-02
    z[6,5,5]  R2443     -3.2998120784759521e-01
    z[6,5,5]  R2444     -8.6903309822082520e-01
    z[6,5,5]  R2445     -3.4434261918067932e-01
    z[6,5,5]  R2446     -3.8126403093338013e-01
    z[6,5,5]  R2447     -2.0543164014816284e-01
    z[6,5,5]  R2448     -5.7612472772598267e-01
    z[6,5,5]  R2449     -1.0551296174526215e-01
    z[6,5,5]  R2450     -5.4740172624588013e-01
    z[6,5,5]  R2451     1.8206527456641197e-02
    z[6,5,5]  R2452     -2.8901594877243042e-01
    z[6,5,5]  R2453     -2.9624858498573303e-01
    z[6,5,5]  R2454     -1.8342342972755432e-01
    z[6,5,5]  R2455     3.7831076979637146e-01
    z[6,5,5]  R2456     1.7657433450222015e-01
    z[6,5,5]  R2457     -3.4343191981315613e-01
    z[6,5,5]  R2458     -2.7499023079872131e-01
    z[6,5,5]  R2459     -2.2095876932144165e-01
    z[6,5,5]  R2460     2.4364241957664490e-01
    z[6,5,5]  R2461     -5.7318305969238281e-01
    z[6,5,5]  R2462     -2.4612143635749817e-01
    z[6,5,5]  R2463     -2.8453272581100464e-01
    z[6,5,5]  R2464     0.06783477216959
    z[6,5,5]  R2465     1.8392252922058105e-01
    z[6,5,5]  R2466     -8.6709603667259216e-02
    z[6,5,5]  R2467     -1.7306198179721832e-01
    z[6,5,5]  R2468     1.6388094425201416e-01
    z[6,5,5]  R2469     2.9382398352026939e-02
    z[6,5,5]  R2470     2.2259229794144630e-02
    z[6,5,5]  R2471     -1.5884411334991455e-01
    z[6,5,5]  R2472     1.3070951402187347e-01
    z[6,5,5]  R2473     3.4013697504997253e-01
    z[6,5,5]  R2474     2.4353970587253571e-01
    z[6,5,5]  R2475     3.0460250377655029e-01
    z[6,5,5]  R2476     1.4695046842098236e-01
    z[6,5,5]  R2477     -2.7154510840773582e-02
    z[6,5,5]  R2478     -4.0896151214838028e-02
    z[6,5,5]  R2479     -5.0095748156309128e-02
    z[6,5,5]  R2480     4.9466714262962341e-01
    z[6,5,5]  R2481     -1.7966248095035553e-01
    z[6,5,5]  R2482     -2.6726812124252319e-01
    z[6,5,5]  R2483     -2.2878044843673706e-01
    z[6,5,5]  R2484     3.8242614269256592e-01
    z[6,5,5]  R2485     5.0597274303436279e-01
    z[6,5,5]  R2486     5.9371012449264526e-01
    z[6,5,5]  R2487     5.5435377359390259e-01
    z[6,5,5]  R2488     -3.4342953003942966e-03
    z[6,5,5]  R2489     9.8959669470787048e-02
    z[6,5,5]  R2490     2.9374006390571594e-01
    z[6,5,5]  R2491     3.2743221521377563e-01
    z[6,5,5]  R2492     1.5588788688182831e-01
    z[6,5,5]  R2493     3.2585912942886353e-01
    z[6,5,5]  R2494     -3.5222217440605164e-01
    z[6,5,5]  R2495     -7.2058849036693573e-02
    z[6,5,5]  R2496     -7.6254093647003174e-01
    z[6,5,5]  R2497     -1.7625318467617035e-01
    z[6,5,5]  R2498     -5.0293862819671631e-01
    z[6,5,5]  R2499     -6.7311418056488037e-01
    z[6,5,5]  R2500     -2.0385213196277618e-01
    z[6,5,5]  R2501     -1.0849576443433762e-01
    z[6,5,5]  R2502     -3.8317084312438965e-01
    z[6,5,5]  R2503     2.3181456327438354e-01
    z[6,5,5]  R2504     1.2535206973552704e-01
    z[6,5,5]  R2505     -7.0958539843559265e-02
    z[6,5,5]  R2506     -1.7830401659011841e-01
    z[6,5,5]  R2507     -5.1603770256042480e-01
    z[6,5,5]  R2508     -2.8873044252395630e-01
    z[6,5,5]  R2509     -5.5137360095977783e-01
    z[6,5,5]  R2510     1.7858842015266418e-01
    z[6,5,5]  R2511     -3.3059626817703247e-01
    z[6,5,5]  R2512     -2.7245754003524780e-01
    z[6,5,5]  R2513     -4.0308335423469543e-01
    z[6,5,5]  R2514     4.5589298009872437e-02
    z[6,5,5]  R2515     -5.7330334186553955e-01
    z[6,5,5]  R2516     -5.0638669729232788e-01
    z[6,5,5]  R2517     3.8519567251205444e-01
    z[6,5,5]  R2518     3.9548525214195251e-01
    z[6,5,5]  R2519     2.0005165040493011e-01
    z[6,5,6]  R53       1
    z[6,5,6]  R62       -1
    z[6,5,6]  R2425     -1
    z[6,5,6]  R2426     1
    z[6,5,6]  R2427     3.7954360246658325e-01
    z[6,5,6]  R2428     7.6548673212528229e-02
    z[6,5,6]  R2429     -1.2867036461830139e-01
    z[6,5,6]  R2430     -5.1571053266525269e-01
    z[6,5,6]  R2431     4.7039404511451721e-01
    z[6,5,6]  R2432     3.7784385681152344e-01
    z[6,5,6]  R2433     -3.6855155229568481e-01
    z[6,5,6]  R2434     -1.6202476620674133e-01
    z[6,5,6]  R2435     -3.6887574940919876e-02
    z[6,5,6]  R2436     -6.1799097061157227e-01
    z[6,5,6]  R2437     -6.7602782510221004e-03
    z[6,5,6]  R2438     -1.1672931723296642e-02
    z[6,5,6]  R2439     1.8062233924865723e-01
    z[6,5,6]  R2440     0.368488609790802
    z[6,5,6]  R2441     3.7670186161994934e-01
    z[6,5,6]  R2442     2.9757311940193176e-01
    z[6,5,6]  R2443     2.2021479904651642e-01
    z[6,5,6]  R2444     -2.0640711486339569e-01
    z[6,5,6]  R2445     -1.9189366698265076e-01
    z[6,5,6]  R2446     -1.3751919567584991e-01
    z[6,5,6]  R2447     -0.345706045627594
    z[6,5,6]  R2448     2.2112955152988434e-01
    z[6,5,6]  R2449     3.3739423751831055e-01
    z[6,5,6]  R2450     2.9497742652893066e-01
    z[6,5,6]  R2451     -2.0037274062633514e-01
    z[6,5,6]  R2452     2.0725630223751068e-01
    z[6,5,6]  R2453     -2.3145695030689240e-01
    z[6,5,6]  R2454     -5.2521222829818726e-01
    z[6,5,6]  R2455     -1.3092701137065887e-01
    z[6,5,6]  R2456     -1.5891024842858315e-02
    z[6,5,6]  R2457     -9.6572116017341614e-02
    z[6,5,6]  R2458     2.2791130840778351e-01
    z[6,5,6]  R2459     1.6141925752162933e-01
    z[6,5,6]  R2460     3.1756326556205750e-01
    z[6,5,6]  R2461     -4.5917022228240967e-01
    z[6,5,6]  R2462     -3.1051045656204224e-01
    z[6,5,6]  R2463     -1.4357627928256989e-01
    z[6,5,6]  R2464     2.4317464232444763e-01
    z[6,5,6]  R2465     -2.9501739144325256e-01
    z[6,5,6]  R2466     2.4745029211044312e-01
    z[6,5,6]  R2467     8.3945758640766144e-02
    z[6,5,6]  R2468     0.151498481631279
    z[6,5,6]  R2469     4.9973125569522381e-03
    z[6,5,6]  R2470     -3.1996732950210571e-01
    z[6,5,6]  R2471     1.3361082971096039e-01
    z[6,5,6]  R2472     -1.6888926923274994e-01
    z[6,5,6]  R2473     1.0487063229084015e-01
    z[6,5,6]  R2474     -1.3252280652523041e-01
    z[6,5,6]  R2475     -2.5968968868255615e-02
    z[6,5,6]  R2476     1.6199924051761627e-01
    z[6,5,6]  R2477     -1.4860944449901581e-01
    z[6,5,6]  R2478     -2.9217207431793213e-01
    z[6,5,6]  R2479     -1.1926929652690887e-01
    z[6,5,6]  R2480     -4.1505265235900879e-01
    z[6,5,6]  R2481     -0.0943610891699791
    z[6,5,6]  R2482     -6.3995391130447388e-01
    z[6,5,6]  R2483     -1.2046817690134048e-01
    z[6,5,6]  R2484     2.7778422459959984e-02
    z[6,5,6]  R2485     -2.4745856225490570e-01
    z[6,5,6]  R2486     1.2494678609073162e-02
    z[6,5,6]  R2487     2.5164343416690826e-02
    z[6,5,6]  R2488     7.5825154781341553e-02
    z[6,5,6]  R2489     2.1239224076271057e-01
    z[6,5,6]  R2490     -2.0509015023708344e-01
    z[6,5,6]  R2491     2.0678873360157013e-01
    z[6,5,6]  R2492     -8.5689671337604523e-02
    z[6,5,6]  R2493     2.1212226711213589e-03
    z[6,5,6]  R2494     3.5165277123451233e-01
    z[6,5,6]  R2495     1.8630404770374298e-01
    z[6,5,6]  R2496     1.3250321149826050e-01
    z[6,5,6]  R2497     2.5208277627825737e-02
    z[6,5,6]  R2498     1.9400231540203094e-01
    z[6,5,6]  R2499     1.7305904626846313e-01
    z[6,5,6]  R2500     -0.234492689371109
    z[6,5,6]  R2501     -4.8598459362983704e-01
    z[6,5,6]  R2502     -1.0857817530632019e-01
    z[6,5,6]  R2503     -1.4566726982593536e-01
    z[6,5,6]  R2504     8.4196001291275024e-02
    z[6,5,6]  R2505     -1.1761871725320816e-01
    z[6,5,6]  R2506     -5.5409427732229233e-02
    z[6,5,6]  R2507     1.6645808517932892e-01
    z[6,5,6]  R2508     2.0787145197391510e-01
    z[6,5,6]  R2509     1.0104341804981232e-01
    z[6,5,6]  R2510     5.2588790655136108e-01
    z[6,5,6]  R2511     -2.5872574187815189e-03
    z[6,5,6]  R2512     2.2560091689229012e-02
    z[6,5,6]  R2513     -3.6706754565238953e-01
    z[6,5,6]  R2514     7.9674273729324341e-02
    z[6,5,6]  R2515     5.0857108086347580e-02
    z[6,5,6]  R2516     -9.6527636051177979e-02
    z[6,5,6]  R2517     -5.5138994008302689e-02
    z[6,5,6]  R2518     -0.000664629100356251
    z[6,5,6]  R2519     1.5300613641738892e-01
    z[6,7,0]  R56       -1
    z[6,7,0]  R65       1
    z[6,7,0]  R2520     -1
    z[6,7,0]  R2521     1
    z[6,7,0]  R2534     -2.6799976825714111e-01
    z[6,7,0]  R2535     -3.0848485231399536e-01
    z[6,7,0]  R2536     -0.502948522567749
    z[6,7,0]  R2537     -4.1463658213615417e-01
    z[6,7,0]  R2538     -4.0166664123535156e-01
    z[6,7,0]  R2539     -6.7071980237960815e-01
    z[6,7,0]  R2540     4.1482448577880859e-01
    z[6,7,0]  R2541     1.3724394142627716e-01
    z[6,7,0]  R2542     1.4065656065940857e-01
    z[6,7,0]  R2543     -1.9479477405548096e-01
    z[6,7,0]  R2544     3.3613452315330505e-01
    z[6,7,0]  R2545     1.0425824671983719e-01
    z[6,7,0]  R2546     0.254373162984848
    z[6,7,0]  R2547     -1.9016842544078827e-01
    z[6,7,0]  R2548     1.0421057045459747e-01
    z[6,7,0]  R2549     5.0094765424728394e-01
    z[6,7,0]  R2550     -4.1455483436584473e-01
    z[6,7,0]  R2551     -1.5327689051628113e-01
    z[6,7,0]  R2552     -7.3224997520446777e-01
    z[6,7,0]  R2553     -4.9367743730545044e-01
    z[6,7,0]  R2554     1.4100821316242218e-01
    z[6,7,0]  R2555     2.1753439307212830e-01
    z[6,7,0]  R2556     -1.2073613703250885e-01
    z[6,7,0]  R2557     -1.8786756694316864e-01
    z[6,7,0]  R2558     -9.2207081615924835e-03
    z[6,7,0]  R2559     2.0490171015262604e-01
    z[6,7,0]  R2560     -4.1622537374496460e-01
    z[6,7,0]  R2561     -0.274004727602005
    z[6,7,0]  R2562     1.6240687668323517e-01
    z[6,7,0]  R2563     -5.9607338905334473e-01
    z[6,7,0]  R2564     -3.1939432024955750e-01
    z[6,7,0]  R2565     -4.3587210774421692e-01
    z[6,7,0]  R2566     4.1314664483070374e-01
    z[6,7,0]  R2567     -1.7168661952018738e-01
    z[6,7,0]  R2568     -0.0768650621175766
    z[6,7,0]  R2569     1.2949213385581970e-01
    z[6,7,0]  R2570     -8.7719194591045380e-02
    z[6,7,0]  R2571     5.6931927800178528e-02
    z[6,7,0]  R2572     5.4856240749359131e-01
    z[6,7,0]  R2573     6.0297280550003052e-01
    z[6,7,0]  R2574     -1.9797690212726593e-01
    z[6,7,0]  R2575     1.5428879298269749e-02
    z[6,7,0]  R2576     1.7626523971557617e-01
    z[6,7,0]  R2577     4.1131421923637390e-01
    z[6,7,0]  R2578     2.3615600541234016e-02
    z[6,7,0]  R2579     5.5942213535308838e-01
    z[6,7,0]  R2580     3.5299485921859741e-01
    z[6,7,0]  R2581     -1.6912724822759628e-02
    z[6,7,0]  R2582     1.3452319800853729e-01
    z[6,7,0]  R2583     2.1778613328933716e-01
    z[6,7,0]  R2584     -2.8781610727310181e-01
    z[6,7,0]  R2585     3.7395498156547546e-01
    z[6,7,0]  R2586     2.0948988199234009e-01
    z[6,7,0]  R2587     1.1307834833860397e-01
    z[6,7,0]  R2588     -1.8201948702335358e-01
    z[6,7,0]  R2589     -2.8810063004493713e-01
    z[6,7,0]  R2590     9.0143084526062012e-01
    z[6,7,0]  R2591     -2.1621994674205780e-01
    z[6,7,0]  R2592     -4.5511227846145630e-01
    z[6,7,0]  R2593     1.1857293546199799e-01
    z[6,7,0]  R2594     -2.6836407184600830e-01
    z[6,7,0]  R2595     -6.1877554655075073e-01
    z[6,7,0]  R2596     -5.6078499555587769e-01
    z[6,7,0]  R2597     -4.8424881696701050e-01
    z[6,7,0]  R2598     -0.493665486574173
    z[6,7,0]  R2599     -6.5295916795730591e-01
    z[6,7,0]  R2600     -5.0218790769577026e-01
    z[6,7,0]  R2601     4.4836950302124023e-01
    z[6,7,0]  R2602     3.7923336029052734e-01
    z[6,7,0]  R2603     3.2009416818618774e-01
    z[6,7,0]  R2604     4.2270222306251526e-01
    z[6,7,0]  R2605     3.3594289422035217e-01
    z[6,7,0]  R2606     0.368246465921402
    z[6,7,0]  R2607     4.5081678032875061e-01
    z[6,7,0]  R2608     4.2248663306236267e-01
    z[6,7,0]  R2609     3.4102728962898254e-01
    z[6,7,0]  R2610     2.0220804214477539e-01
    z[6,7,0]  R2611     -2.8328239917755127e-01
    z[6,7,0]  R2612     -1.7455467581748962e-01
    z[6,7,0]  R2613     -1.4616841077804565e-01
    z[6,7,0]  R2614     2.8160439804196358e-02
    z[6,7,0]  R2615     1.1431477218866348e-01
    z[6,7,0]  R2616     1.0720545798540115e-01
    z[6,7,0]  R2617     2.2843575105071068e-02
    z[6,7,0]  R2618     -2.9791104793548584e-01
    z[6,7,0]  R2619     -2.2452485561370850e-01
    z[6,7,0]  R2620     5.9810775518417358e-01
    z[6,7,0]  R2621     8.8973073288798332e-03
    z[6,7,0]  R2622     -9.1658718883991241e-02
    z[6,7,0]  R2623     1.0764811933040619e-01
    z[6,7,0]  R2624     -2.6607245206832886e-01
    z[6,7,0]  R2625     -4.6468096971511841e-01
    z[6,7,0]  R2626     9.6932905912399292e-01
    z[6,7,0]  R2627     9.6469402313232422e-01
    z[6,7,0]  R2628     9.1660410165786743e-01
    z[6,7,0]  R2629     0.891918957233429
    z[6,7,0]  R2630     8.0443078279495239e-01
    z[6,7,1]  R57       -1
    z[6,7,1]  R66       1
    z[6,7,1]  R2522     -1
    z[6,7,1]  R2523     1
    z[6,7,1]  R2534     2.6034945249557495e-01
    z[6,7,1]  R2535     -3.4273234009742737e-01
    z[6,7,1]  R2536     3.3970236778259277e-01
    z[6,7,1]  R2537     0.287553071975708
    z[6,7,1]  R2538     -1.8081579357385635e-02
    z[6,7,1]  R2539     -1.0382114350795746e-01
    z[6,7,1]  R2540     6.3087075948715210e-01
    z[6,7,1]  R2541     6.6886502504348755e-01
    z[6,7,1]  R2542     7.1507990360260010e-01
    z[6,7,1]  R2543     1.6465568542480469e-01
    z[6,7,1]  R2544     -1.9731727242469788e-01
    z[6,7,1]  R2545     2.3253744840621948e-01
    z[6,7,1]  R2546     -1.3593323528766632e-01
    z[6,7,1]  R2547     4.5358244329690933e-02
    z[6,7,1]  R2548     -0.3088398873806
    z[6,7,1]  R2549     -2.1598720923066139e-02
    z[6,7,1]  R2550     -1.5587671659886837e-02
    z[6,7,1]  R2551     -1.1244186758995056e-01
    z[6,7,1]  R2552     -1.2262280285358429e-01
    z[6,7,1]  R2553     -4.1260862350463867e-01
    z[6,7,1]  R2554     -2.0453684031963348e-01
    z[6,7,1]  R2555     1.3772989809513092e-01
    z[6,7,1]  R2556     -3.0731928348541260e-01
    z[6,7,1]  R2557     3.0537009239196777e-01
    z[6,7,1]  R2558     1.7410951852798462e-01
    z[6,7,1]  R2559     5.5265665054321289e-01
    z[6,7,1]  R2560     3.9770871400833130e-01
    z[6,7,1]  R2561     1.5753868967294693e-02
    z[6,7,1]  R2562     -2.0316170156002045e-01
    z[6,7,1]  R2563     -2.0895386114716530e-02
    z[6,7,1]  R2564     3.3721652626991272e-01
    z[6,7,1]  R2565     0.0609736330807209
    z[6,7,1]  R2566     -3.0422195792198181e-01
    z[6,7,1]  R2567     2.3960523307323456e-01
    z[6,7,1]  R2568     5.8998677879571915e-02
    z[6,7,1]  R2569     8.6291587352752686e-01
    z[6,7,1]  R2570     8.5653185844421387e-01
    z[6,7,1]  R2571     8.1906998157501221e-01
    z[6,7,1]  R2572     7.3512208461761475e-01
    z[6,7,1]  R2573     4.4444590806961060e-01
    z[6,7,1]  R2574     -2.5734481215476990e-01
    z[6,7,1]  R2575     3.8917216658592224e-01
    z[6,7,1]  R2576     9.5235210657119751e-01
    z[6,7,1]  R2577     -1.1356313712894917e-02
    z[6,7,1]  R2578     9.0541803836822510e-01
    z[6,7,1]  R2579     5.4022759199142456e-01
    z[6,7,1]  R2580     5.0834619998931885e-01
    z[6,7,1]  R2581     -9.0297651290893555e-01
    z[6,7,1]  R2582     -8.1154477596282959e-01
    z[6,7,1]  R2583     -9.0584987401962280e-01
    z[6,7,1]  R2584     -1.6611185669898987e-01
    z[6,7,1]  R2585     9.2443414032459259e-02
    z[6,7,1]  R2586     3.8873386383056641e-01
    z[6,7,1]  R2587     -6.8229228258132935e-01
    z[6,7,1]  R2588     -3.2924848794937134e-01
    z[6,7,1]  R2589     -2.0766112208366394e-01
    z[6,7,1]  R2590     -1.3121864199638367e-01
    z[6,7,1]  R2591     -7.6087635755538940e-01
    z[6,7,1]  R2592     -3.7918284535408020e-01
    z[6,7,1]  R2593     -5.8403360843658447e-01
    z[6,7,1]  R2594     -0.577204704284668
    z[6,7,1]  R2595     -5.0304710865020752e-01
    z[6,7,1]  R2596     -5.1557654142379761e-01
    z[6,7,1]  R2597     -3.6960625648498535e-01
    z[6,7,1]  R2598     -6.7872440814971924e-01
    z[6,7,1]  R2599     7.0590823888778687e-01
    z[6,7,1]  R2600     6.5275180339813232e-01
    z[6,7,1]  R2601     7.7657061815261841e-01
    z[6,7,1]  R2602     6.8200689554214478e-01
    z[6,7,1]  R2603     6.6349774599075317e-01
    z[6,7,1]  R2604     6.1811476945877075e-01
    z[6,7,1]  R2605     6.1596262454986572e-01
    z[6,7,1]  R2606     5.7915139198303223e-01
    z[6,7,1]  R2607     7.0773756504058838e-01
    z[6,7,1]  R2608     5.3430587053298950e-01
    z[6,7,1]  R2609     3.9622643589973450e-01
    z[6,7,1]  R2610     4.3754762411117554e-01
    z[6,7,1]  R2611     4.8011958599090576e-01
    z[6,7,1]  R2612     3.8664203882217407e-01
    z[6,7,1]  R2613     -2.5440484285354614e-01
    z[6,7,1]  R2614     -3.0046477913856506e-01
    z[6,7,1]  R2615     -6.3220870494842529e-01
    z[6,7,1]  R2616     -5.6545984745025635e-01
    z[6,7,1]  R2617     4.8776644468307495e-01
    z[6,7,1]  R2618     4.6707892417907715e-01
    z[6,7,1]  R2619     5.2490210533142090e-01
    z[6,7,1]  R2620     -2.4439743161201477e-01
    z[6,7,1]  R2621     0.74985671043396
    z[6,7,1]  R2622     7.4483048915863037e-01
    z[6,7,1]  R2623     6.0011005401611328e-01
    z[6,7,1]  R2624     -1.0027145594358444e-01
    z[6,7,1]  R2625     -3.2934451103210449e-01
    z[6,7,1]  R2626     -1.1398215591907501e-01
    z[6,7,1]  R2627     -1.0426852852106094e-01
    z[6,7,1]  R2628     -0.144050732254982
    z[6,7,1]  R2629     -0.0899525135755539
    z[6,7,1]  R2630     7.9007655382156372e-02
    z[6,7,2]  R58       -1
    z[6,7,2]  R67       1
    z[6,7,2]  R2524     -1
    z[6,7,2]  R2525     1
    z[6,7,2]  R2534     -3.9756676554679871e-01
    z[6,7,2]  R2535     -4.9994894862174988e-01
    z[6,7,2]  R2536     -2.3084443807601929e-01
    z[6,7,2]  R2537     -2.0341536402702332e-01
    z[6,7,2]  R2538     1.1693882942199707e-01
    z[6,7,2]  R2539     8.1346176564693451e-02
    z[6,7,2]  R2540     -2.8455637395381927e-02
    z[6,7,2]  R2541     -4.7480916976928711e-01
    z[6,7,2]  R2542     0.399924099445343
    z[6,7,2]  R2543     -3.5927772521972656e-01
    z[6,7,2]  R2544     -2.6057684421539307e-01
    z[6,7,2]  R2545     7.0517949759960175e-02
    z[6,7,2]  R2546     1.9377246499061584e-01
    z[6,7,2]  R2547     -3.5220120102167130e-02
    z[6,7,2]  R2548     -1.5724499523639679e-01
    z[6,7,2]  R2549     -0.251311331987381
    z[6,7,2]  R2550     -4.4861888885498047e-01
    z[6,7,2]  R2551     8.4616623818874359e-02
    z[6,7,2]  R2552     -4.3666278943419456e-03
    z[6,7,2]  R2553     2.8069657087326050e-01
    z[6,7,2]  R2554     1.4100825786590576e-01
    z[6,7,2]  R2555     -8.8609211146831512e-02
    z[6,7,2]  R2556     -3.8922277092933655e-01
    z[6,7,2]  R2557     -8.1903554499149323e-02
    z[6,7,2]  R2558     -0.564672589302063
    z[6,7,2]  R2559     -3.1437207013368607e-02
    z[6,7,2]  R2560     -1.1584430932998657e-01
    z[6,7,2]  R2561     -2.2531510889530182e-01
    z[6,7,2]  R2562     2.7839755639433861e-03
    z[6,7,2]  R2563     -5.0746973603963852e-02
    z[6,7,2]  R2564     -2.3050782084465027e-01
    z[6,7,2]  R2565     2.4781459942460060e-02
    z[6,7,2]  R2566     -6.3811242580413818e-02
    z[6,7,2]  R2567     -8.2455776631832123e-02
    z[6,7,2]  R2568     -2.8026726841926575e-01
    z[6,7,2]  R2569     7.1502029895782471e-02
    z[6,7,2]  R2570     2.1758085489273071e-01
    z[6,7,2]  R2571     3.5238778591156006e-01
    z[6,7,2]  R2572     -1.8645766377449036e-01
    z[6,7,2]  R2573     3.1171867251396179e-01
    z[6,7,2]  R2574     -3.9491170644760132e-01
    z[6,7,2]  R2575     1.6960716247558594e-01
    z[6,7,2]  R2576     -1.4601002633571625e-01
    z[6,7,2]  R2577     -4.1508537530899048e-01
    z[6,7,2]  R2578     2.7347663044929504e-01
    z[6,7,2]  R2579     2.0718546211719513e-01
    z[6,7,2]  R2580     3.8754299283027649e-01
    z[6,7,2]  R2581     7.2244450449943542e-02
    z[6,7,2]  R2582     0.145552858710289
    z[6,7,2]  R2583     5.7123210281133652e-02
    z[6,7,2]  R2584     -3.3237934112548828e-01
    z[6,7,2]  R2585     -3.8678976893424988e-01
    z[6,7,2]  R2586     5.5587112903594971e-01
    z[6,7,2]  R2587     -3.4621194005012512e-02
    z[6,7,2]  R2588     -0.0864488035440445
    z[6,7,2]  R2589     -1.7532606422901154e-01
    z[6,7,2]  R2590     -0.0704229474067688
    z[6,7,2]  R2591     -4.9087649583816528e-01
    z[6,7,2]  R2592     -4.5914888381958008e-01
    z[6,7,2]  R2593     -5.7204127311706543e-01
    z[6,7,2]  R2594     -5.5474025011062622e-01
    z[6,7,2]  R2595     -2.0608049631118774e-01
    z[6,7,2]  R2596     -3.8284295797348022e-01
    z[6,7,2]  R2597     -3.7049689888954163e-01
    z[6,7,2]  R2598     1.8101982772350311e-01
    z[6,7,2]  R2599     0.0501449890434742
    z[6,7,2]  R2600     -2.6582766324281693e-02
    z[6,7,2]  R2601     1.1455873399972916e-01
    z[6,7,2]  R2602     -1.9130834937095642e-01
    z[6,7,2]  R2603     3.4527698159217834e-01
    z[6,7,2]  R2604     2.9010051488876343e-01
    z[6,7,2]  R2605     -1.4007273316383362e-01
    z[6,7,2]  R2606     5.3694641590118408e-01
    z[6,7,2]  R2607     0.0927298292517662
    z[6,7,2]  R2608     -6.8193182349205017e-02
    z[6,7,2]  R2609     0.50670325756073
    z[6,7,2]  R2610     3.2412725687026978e-01
    z[6,7,2]  R2611     1.1077066510915756e-01
    z[6,7,2]  R2612     -2.5768473744392395e-01
    z[6,7,2]  R2613     1.4226564764976501e-01
    z[6,7,2]  R2614     -8.1668600440025330e-02
    z[6,7,2]  R2615     7.0994421839714050e-02
    z[6,7,2]  R2616     9.5608517527580261e-02
    z[6,7,2]  R2617     -4.6972211450338364e-02
    z[6,7,2]  R2618     5.4767513275146484e-01
    z[6,7,2]  R2619     1.6562581062316895e-01
    z[6,7,2]  R2620     2.7310448884963989e-01
    z[6,7,2]  R2621     1.8667300045490265e-01
    z[6,7,2]  R2622     9.7441887483000755e-03
    z[6,7,2]  R2623     2.2966033220291138e-01
    z[6,7,2]  R2624     7.1472458541393280e-02
    z[6,7,2]  R2625     4.2513498663902283e-01
    z[6,7,2]  R2626     -0.0327107198536396
    z[6,7,2]  R2627     2.1202708780765533e-01
    z[6,7,2]  R2628     1.3398066163063049e-01
    z[6,7,2]  R2629     8.6986780166625977e-02
    z[6,7,2]  R2630     9.7790569067001343e-02
    z[6,7,3]  R59       -1
    z[6,7,3]  R68       1
    z[6,7,3]  R2526     -1
    z[6,7,3]  R2527     1
    z[6,7,3]  R2534     6.5393263101577759e-01
    z[6,7,3]  R2535     5.0959396362304688e-01
    z[6,7,3]  R2536     4.0262740850448608e-01
    z[6,7,3]  R2537     0.0463026687502861
    z[6,7,3]  R2538     -7.2940096259117126e-02
    z[6,7,3]  R2539     2.8767937421798706e-01
    z[6,7,3]  R2540     -0.0512276254594326
    z[6,7,3]  R2541     -7.1023985743522644e-02
    z[6,7,3]  R2542     -3.7454909086227417e-01
    z[6,7,3]  R2543     -7.4034363031387329e-02
    z[6,7,3]  R2544     -3.3794444799423218e-01
    z[6,7,3]  R2545     -2.8308334946632385e-01
    z[6,7,3]  R2546     -0.391967236995697
    z[6,7,3]  R2547     -2.7441471815109253e-01
    z[6,7,3]  R2548     -3.5618439316749573e-01
    z[6,7,3]  R2549     -4.3386444449424744e-01
    z[6,7,3]  R2550     -2.6035135984420776e-01
    z[6,7,3]  R2551     -3.7802201509475708e-01
    z[6,7,3]  R2552     -3.1466564536094666e-01
    z[6,7,3]  R2553     -2.4095329642295837e-01
    z[6,7,3]  R2554     -6.8053388595581055e-01
    z[6,7,3]  R2555     -7.2847908735275269e-01
    z[6,7,3]  R2556     -7.1762156486511230e-01
    z[6,7,3]  R2557     -6.7181175947189331e-01
    z[6,7,3]  R2558     -7.5338131189346313e-01
    z[6,7,3]  R2559     -6.4652174711227417e-01
    z[6,7,3]  R2560     -6.3391441106796265e-01
    z[6,7,3]  R2561     -5.2807462215423584e-01
    z[6,7,3]  R2562     -6.9509744644165039e-01
    z[6,7,3]  R2563     -7.5340855121612549e-01
    z[6,7,3]  R2564     -6.3471955060958862e-01
    z[6,7,3]  R2565     -7.7655339241027832e-01
    z[6,7,3]  R2566     -6.2197327613830566e-01
    z[6,7,3]  R2567     -6.6663116216659546e-01
    z[6,7,3]  R2568     -5.9071314334869385e-01
    z[6,7,3]  R2569     2.1089186891913414e-02
    z[6,7,3]  R2570     4.1512794792652130e-02
    z[6,7,3]  R2571     -3.4831660985946655e-01
    z[6,7,3]  R2572     -3.0824735760688782e-02
    z[6,7,3]  R2573     -5.2167940139770508e-01
    z[6,7,3]  R2574     -4.0444770455360413e-01
    z[6,7,3]  R2575     -8.0958712100982666e-01
    z[6,7,3]  R2576     -1.7638245224952698e-01
    z[6,7,3]  R2577     -4.1537594795227051e-01
    z[6,7,3]  R2578     -1.8703933060169220e-01
    z[6,7,3]  R2579     -5.4770672321319580e-01
    z[6,7,3]  R2580     -5.7849675416946411e-01
    z[6,7,3]  R2581     -2.0557032525539398e-01
    z[6,7,3]  R2582     -4.5151209831237793e-01
    z[6,7,3]  R2583     -2.2021782398223877e-01
    z[6,7,3]  R2584     -8.3125251531600952e-01
    z[6,7,3]  R2585     -0.372031033039093
    z[6,7,3]  R2586     -0.626023530960083
    z[6,7,3]  R2587     -3.2117596268653870e-01
    z[6,7,3]  R2588     4.4315099716186523e-01
    z[6,7,3]  R2589     3.2139471173286438e-01
    z[6,7,3]  R2590     2.2495168447494507e-01
    z[6,7,3]  R2591     -1.9534103572368622e-01
    z[6,7,3]  R2592     -6.7476667463779449e-02
    z[6,7,3]  R2593     -7.6603449881076813e-02
    z[6,7,3]  R2594     3.7834087014198303e-01
    z[6,7,3]  R2595     7.6880931854248047e-02
    z[6,7,3]  R2596     3.3753588795661926e-01
    z[6,7,3]  R2597     1.9323676824569702e-02
    z[6,7,3]  R2598     -2.4950817227363586e-01
    z[6,7,3]  R2599     2.1537464857101440e-01
    z[6,7,3]  R2600     4.7597751021385193e-01
    z[6,7,3]  R2601     -3.5705888271331787e-01
    z[6,7,3]  R2602     3.9178112149238586e-01
    z[6,7,3]  R2603     -5.1507627964019775e-01
    z[6,7,3]  R2604     -5.1381522417068481e-01
    z[6,7,3]  R2605     -3.5033130645751953e-01
    z[6,7,3]  R2606     -3.7505501508712769e-01
    z[6,7,3]  R2607     -2.3978227376937866e-01
    z[6,7,3]  R2608     -2.6280593872070312e-01
    z[6,7,3]  R2609     -3.5178834199905396e-01
    z[6,7,3]  R2610     -0.566901445388794
    z[6,7,3]  R2611     -0.554315984249115
    z[6,7,3]  R2612     -8.1742691993713379e-01
    z[6,7,3]  R2613     5.3159141540527344e-01
    z[6,7,3]  R2614     5.3855520486831665e-01
    z[6,7,3]  R2615     1.6299067437648773e-01
    z[6,7,3]  R2616     3.1442412734031677e-01
    z[6,7,3]  R2617     3.9757695794105530e-01
    z[6,7,3]  R2618     -2.7959507703781128e-01
    z[6,7,3]  R2619     6.3443198800086975e-02
    z[6,7,3]  R2620     -0.675109326839447
    z[6,7,3]  R2621     -2.0627894997596741e-01
    z[6,7,3]  R2622     -7.3001608252525330e-02
    z[6,7,3]  R2623     3.6904498934745789e-01
    z[6,7,3]  R2624     6.6535556316375732e-01
    z[6,7,3]  R2625     1.6231556236743927e-01
    z[6,7,3]  R2626     -3.4614145755767822e-02
    z[6,7,3]  R2627     9.6747368574142456e-02
    z[6,7,3]  R2628     2.3363502323627472e-01
    z[6,7,3]  R2629     3.2033350318670273e-02
    z[6,7,3]  R2630     2.9793012142181396e-01
    z[6,7,4]  R60       -1
    z[6,7,4]  R69       1
    z[6,7,4]  R2528     -1
    z[6,7,4]  R2529     1
    z[6,7,4]  R2534     -3.6099845170974731e-01
    z[6,7,4]  R2535     -5.0128477811813354e-01
    z[6,7,4]  R2536     -2.4232718348503113e-01
    z[6,7,4]  R2537     -6.2378132343292236e-01
    z[6,7,4]  R2538     -7.6530051231384277e-01
    z[6,7,4]  R2539     -8.2309916615486145e-02
    z[6,7,4]  R2540     5.0870066881179810e-01
    z[6,7,4]  R2541     5.2494859695434570e-01
    z[6,7,4]  R2542     2.2784644365310669e-01
    z[6,7,4]  R2543     6.3623136281967163e-01
    z[6,7,4]  R2544     6.6906195878982544e-01
    z[6,7,4]  R2545     0.715188205242157
    z[6,7,4]  R2546     8.1924271583557129e-01
    z[6,7,4]  R2547     7.3967492580413818e-01
    z[6,7,4]  R2548     4.9545809626579285e-01
    z[6,7,4]  R2549     6.3771128654479980e-01
    z[6,7,4]  R2550     6.3362246751785278e-01
    z[6,7,4]  R2551     1.2641207873821259e-01
    z[6,7,4]  R2552     4.4084584712982178e-01
    z[6,7,4]  R2553     5.3377324342727661e-01
    z[6,7,4]  R2554     5.4180890321731567e-01
    z[6,7,4]  R2555     1.1982502788305283e-01
    z[6,7,4]  R2556     3.1549152731895447e-01
    z[6,7,4]  R2557     1.6357085108757019e-01
    z[6,7,4]  R2558     2.0659507811069489e-01
    z[6,7,4]  R2559     3.2729476690292358e-01
    z[6,7,4]  R2560     3.3463621139526367e-01
    z[6,7,4]  R2561     5.3437018394470215e-01
    z[6,7,4]  R2562     5.3751307725906372e-01
    z[6,7,4]  R2563     2.0646791160106659e-01
    z[6,7,4]  R2564     4.4832786917686462e-01
    z[6,7,4]  R2565     2.7401667833328247e-01
    z[6,7,4]  R2566     5.2053558826446533e-01
    z[6,7,4]  R2567     5.4928040504455566e-01
    z[6,7,4]  R2568     1.5408772230148315e-01
    z[6,7,4]  R2569     2.7578663825988770e-01
    z[6,7,4]  R2570     3.2866501808166504e-01
    z[6,7,4]  R2571     -1.2901960313320160e-01
    z[6,7,4]  R2572     0.0457758866250515
    z[6,7,4]  R2573     -2.8694493696093559e-02
    z[6,7,4]  R2574     7.3351776599884033e-01
    z[6,7,4]  R2575     0.338083416223526
    z[6,7,4]  R2576     0.0929412767291069
    z[6,7,4]  R2577     6.1885702610015869e-01
    z[6,7,4]  R2578     -1.6371940076351166e-01
    z[6,7,4]  R2579     -0.0817561224102974
    z[6,7,4]  R2580     -0.0737539529800415
    z[6,7,4]  R2581     2.4493876099586487e-01
    z[6,7,4]  R2582     -6.9230049848556519e-02
    z[6,7,4]  R2583     1.8002241849899292e-01
    z[6,7,4]  R2584     2.5551870465278625e-01
    z[6,7,4]  R2585     6.9033432006835938e-01
    z[6,7,4]  R2586     2.9557922482490540e-01
    z[6,7,4]  R2587     1.9327664747834206e-02
    z[6,7,4]  R2588     7.8321486711502075e-01
    z[6,7,4]  R2589     5.0879049301147461e-01
    z[6,7,4]  R2590     2.1860572695732117e-01
    z[6,7,4]  R2591     8.8081859052181244e-02
    z[6,7,4]  R2592     4.2256745696067810e-01
    z[6,7,4]  R2593     4.9313545227050781e-01
    z[6,7,4]  R2594     1.0212492197751999e-01
    z[6,7,4]  R2595     9.8563842475414276e-02
    z[6,7,4]  R2596     3.8314953446388245e-01
    z[6,7,4]  R2597     6.5418505668640137e-01
    z[6,7,4]  R2598     5.4040521383285522e-02
    z[6,7,4]  R2599     -3.5474825650453568e-02
    z[6,7,4]  R2600     1.6338813304901123e-01
    z[6,7,4]  R2601     1.1716998182237148e-02
    z[6,7,4]  R2602     -2.0683860778808594e-01
    z[6,7,4]  R2603     2.3803491145372391e-02
    z[6,7,4]  R2604     2.1660542488098145e-01
    z[6,7,4]  R2605     5.1346683502197266e-01
    z[6,7,4]  R2606     -2.5644731521606445e-01
    z[6,7,4]  R2607     8.7570890784263611e-02
    z[6,7,4]  R2608     4.4482216238975525e-01
    z[6,7,4]  R2609     -1.8806131184101105e-01
    z[6,7,4]  R2610     3.8330635428428650e-01
    z[6,7,4]  R2611     2.7388921380043030e-01
    z[6,7,4]  R2612     -1.1197332292795181e-01
    z[6,7,4]  R2613     -7.5706982612609863e-01
    z[6,7,4]  R2614     -6.3856667280197144e-01
    z[6,7,4]  R2615     -5.2379405498504639e-01
    z[6,7,4]  R2616     -4.8556759953498840e-01
    z[6,7,4]  R2617     -3.9496758580207825e-01
    z[6,7,4]  R2618     1.3980881869792938e-01
    z[6,7,4]  R2619     -2.8170329332351685e-01
    z[6,7,4]  R2620     -1.0841037333011627e-01
    z[6,7,4]  R2621     -6.2899775803089142e-02
    z[6,7,4]  R2622     3.2857468724250793e-01
    z[6,7,4]  R2623     -0.607761025428772
    z[6,7,4]  R2624     -5.4443657398223877e-01
    z[6,7,4]  R2625     -5.0919461250305176e-01
    z[6,7,4]  R2626     -1.6262637078762054e-01
    z[6,7,4]  R2627     3.6612160503864288e-02
    z[6,7,4]  R2628     1.1570832133293152e-01
    z[6,7,4]  R2629     -2.0798210799694061e-01
    z[6,7,4]  R2630     6.3452489674091339e-02
    z[6,7,5]  R61       -1
    z[6,7,5]  R70       1
    z[6,7,5]  R2530     -1
    z[6,7,5]  R2531     1
    z[6,7,5]  R2534     -0.018271429464221
    z[6,7,5]  R2535     1.4349387586116791e-01
    z[6,7,5]  R2536     5.8392512798309326e-01
    z[6,7,5]  R2537     2.1635049581527710e-01
    z[6,7,5]  R2538     -1.1129476875066757e-01
    z[6,7,5]  R2539     5.4812282323837280e-01
    z[6,7,5]  R2540     1.7855556309223175e-01
    z[6,7,5]  R2541     3.8373034447431564e-02
    z[6,7,5]  R2542     3.3966964483261108e-01
    z[6,7,5]  R2543     -1.1695603281259537e-01
    z[6,7,5]  R2544     -4.6720793843269348e-01
    z[6,7,5]  R2545     -5.8165037631988525e-01
    z[6,7,5]  R2546     -1.4780853688716888e-01
    z[6,7,5]  R2547     -4.4981312751770020e-01
    z[6,7,5]  R2548     -5.9563565254211426e-01
    z[6,7,5]  R2549     -4.4312477111816406e-02
    z[6,7,5]  R2550     -3.2998120784759521e-01
    z[6,7,5]  R2551     -8.6903309822082520e-01
    z[6,7,5]  R2552     -3.4434261918067932e-01
    z[6,7,5]  R2553     -3.8126403093338013e-01
    z[6,7,5]  R2554     -2.0543164014816284e-01
    z[6,7,5]  R2555     -5.7612472772598267e-01
    z[6,7,5]  R2556     -1.0551296174526215e-01
    z[6,7,5]  R2557     -5.4740172624588013e-01
    z[6,7,5]  R2558     1.8206527456641197e-02
    z[6,7,5]  R2559     -2.8901594877243042e-01
    z[6,7,5]  R2560     -2.9624858498573303e-01
    z[6,7,5]  R2561     -1.8342342972755432e-01
    z[6,7,5]  R2562     3.7831076979637146e-01
    z[6,7,5]  R2563     1.7657433450222015e-01
    z[6,7,5]  R2564     -3.4343191981315613e-01
    z[6,7,5]  R2565     -2.7499023079872131e-01
    z[6,7,5]  R2566     -2.2095876932144165e-01
    z[6,7,5]  R2567     2.4364241957664490e-01
    z[6,7,5]  R2568     -5.7318305969238281e-01
    z[6,7,5]  R2569     -2.4612143635749817e-01
    z[6,7,5]  R2570     -2.8453272581100464e-01
    z[6,7,5]  R2571     0.06783477216959
    z[6,7,5]  R2572     1.8392252922058105e-01
    z[6,7,5]  R2573     -8.6709603667259216e-02
    z[6,7,5]  R2574     -1.7306198179721832e-01
    z[6,7,5]  R2575     1.6388094425201416e-01
    z[6,7,5]  R2576     2.9382398352026939e-02
    z[6,7,5]  R2577     2.2259229794144630e-02
    z[6,7,5]  R2578     -1.5884411334991455e-01
    z[6,7,5]  R2579     1.3070951402187347e-01
    z[6,7,5]  R2580     3.4013697504997253e-01
    z[6,7,5]  R2581     2.4353970587253571e-01
    z[6,7,5]  R2582     3.0460250377655029e-01
    z[6,7,5]  R2583     1.4695046842098236e-01
    z[6,7,5]  R2584     -2.7154510840773582e-02
    z[6,7,5]  R2585     -4.0896151214838028e-02
    z[6,7,5]  R2586     -5.0095748156309128e-02
    z[6,7,5]  R2587     4.9466714262962341e-01
    z[6,7,5]  R2588     -1.7966248095035553e-01
    z[6,7,5]  R2589     -2.6726812124252319e-01
    z[6,7,5]  R2590     -2.2878044843673706e-01
    z[6,7,5]  R2591     1.9620141386985779e-01
    z[6,7,5]  R2592     4.6732330322265625e-01
    z[6,7,5]  R2593     0.257762610912323
    z[6,7,5]  R2594     3.2977280020713806e-01
    z[6,7,5]  R2595     2.7991998195648193e-01
    z[6,7,5]  R2596     -9.0255342423915863e-02
    z[6,7,5]  R2597     2.5046941637992859e-01
    z[6,7,5]  R2598     4.2706301808357239e-01
    z[6,7,5]  R2599     -9.5430992543697357e-02
    z[6,7,5]  R2600     -1.2117945402860641e-01
    z[6,7,5]  R2601     0.194473534822464
    z[6,7,5]  R2602     -3.3332142233848572e-01
    z[6,7,5]  R2603     -1.4950575307011604e-02
    z[6,7,5]  R2604     -2.0976434648036957e-01
    z[6,7,5]  R2605     -0.0895463153719902
    z[6,7,5]  R2606     -1.3865956664085388e-01
    z[6,7,5]  R2607     -3.8939729332923889e-01
    z[6,7,5]  R2608     -5.1084810495376587e-01
    z[6,7,5]  R2609     2.5415942072868347e-01
    z[6,7,5]  R2610     2.4926245212554932e-01
    z[6,7,5]  R2611     3.1599956750869751e-01
    z[6,7,5]  R2612     1.9042393192648888e-02
    z[6,7,5]  R2613     -1.4626312255859375e-01
    z[6,7,5]  R2614     -4.3257924914360046e-01
    z[6,7,5]  R2615     -5.2931028604507446e-01
    z[6,7,5]  R2616     -2.4646340310573578e-01
    z[6,7,5]  R2617     6.6729128360748291e-01
    z[6,7,5]  R2618     -5.0630003213882446e-01
    z[6,7,5]  R2619     6.9655174016952515e-01
    z[6,7,5]  R2620     1.9682997465133667e-01
    z[6,7,5]  R2621     4.1747590899467468e-01
    z[6,7,5]  R2622     -4.2000961303710938e-01
    z[6,7,5]  R2623     2.3197035491466522e-01
    z[6,7,5]  R2624     -3.1511966139078140e-02
    z[6,7,5]  R2625     -4.5322397351264954e-01
    z[6,7,5]  R2626     4.6095319092273712e-02
    z[6,7,5]  R2627     7.3622646741569042e-03
    z[6,7,5]  R2628     -1.3261437416076660e-01
    z[6,7,5]  R2629     3.0438652634620667e-01
    z[6,7,5]  R2630     4.9425348639488220e-01
    z[6,7,6]  R62       -1
    z[6,7,6]  R71       1
    z[6,7,6]  R2532     -1
    z[6,7,6]  R2533     1
    z[6,7,6]  R2534     3.7954360246658325e-01
    z[6,7,6]  R2535     7.6548673212528229e-02
    z[6,7,6]  R2536     -1.2867036461830139e-01
    z[6,7,6]  R2537     -5.1571053266525269e-01
    z[6,7,6]  R2538     4.7039404511451721e-01
    z[6,7,6]  R2539     3.7784385681152344e-01
    z[6,7,6]  R2540     -3.6855155229568481e-01
    z[6,7,6]  R2541     -1.6202476620674133e-01
    z[6,7,6]  R2542     -3.6887574940919876e-02
    z[6,7,6]  R2543     -6.1799097061157227e-01
    z[6,7,6]  R2544     -6.7602782510221004e-03
    z[6,7,6]  R2545     -1.1672931723296642e-02
    z[6,7,6]  R2546     1.8062233924865723e-01
    z[6,7,6]  R2547     0.368488609790802
    z[6,7,6]  R2548     3.7670186161994934e-01
    z[6,7,6]  R2549     2.9757311940193176e-01
    z[6,7,6]  R2550     2.2021479904651642e-01
    z[6,7,6]  R2551     -2.0640711486339569e-01
    z[6,7,6]  R2552     -1.9189366698265076e-01
    z[6,7,6]  R2553     -1.3751919567584991e-01
    z[6,7,6]  R2554     -0.345706045627594
    z[6,7,6]  R2555     2.2112955152988434e-01
    z[6,7,6]  R2556     3.3739423751831055e-01
    z[6,7,6]  R2557     2.9497742652893066e-01
    z[6,7,6]  R2558     -2.0037274062633514e-01
    z[6,7,6]  R2559     2.0725630223751068e-01
    z[6,7,6]  R2560     -2.3145695030689240e-01
    z[6,7,6]  R2561     -5.2521222829818726e-01
    z[6,7,6]  R2562     -1.3092701137065887e-01
    z[6,7,6]  R2563     -1.5891024842858315e-02
    z[6,7,6]  R2564     -9.6572116017341614e-02
    z[6,7,6]  R2565     2.2791130840778351e-01
    z[6,7,6]  R2566     1.6141925752162933e-01
    z[6,7,6]  R2567     3.1756326556205750e-01
    z[6,7,6]  R2568     -4.5917022228240967e-01
    z[6,7,6]  R2569     -3.1051045656204224e-01
    z[6,7,6]  R2570     -1.4357627928256989e-01
    z[6,7,6]  R2571     2.4317464232444763e-01
    z[6,7,6]  R2572     -2.9501739144325256e-01
    z[6,7,6]  R2573     2.4745029211044312e-01
    z[6,7,6]  R2574     8.3945758640766144e-02
    z[6,7,6]  R2575     0.151498481631279
    z[6,7,6]  R2576     4.9973125569522381e-03
    z[6,7,6]  R2577     -3.1996732950210571e-01
    z[6,7,6]  R2578     1.3361082971096039e-01
    z[6,7,6]  R2579     -1.6888926923274994e-01
    z[6,7,6]  R2580     1.0487063229084015e-01
    z[6,7,6]  R2581     -1.3252280652523041e-01
    z[6,7,6]  R2582     -2.5968968868255615e-02
    z[6,7,6]  R2583     1.6199924051761627e-01
    z[6,7,6]  R2584     -1.4860944449901581e-01
    z[6,7,6]  R2585     -2.9217207431793213e-01
    z[6,7,6]  R2586     -1.1926929652690887e-01
    z[6,7,6]  R2587     -4.1505265235900879e-01
    z[6,7,6]  R2588     -0.0943610891699791
    z[6,7,6]  R2589     -6.3995391130447388e-01
    z[6,7,6]  R2590     -1.2046817690134048e-01
    z[6,7,6]  R2591     2.2123497724533081e-01
    z[6,7,6]  R2592     -1.9174998998641968e-01
    z[6,7,6]  R2593     0.0460628941655159
    z[6,7,6]  R2594     -1.5734435617923737e-01
    z[6,7,6]  R2595     4.7708559036254883e-01
    z[6,7,6]  R2596     -6.5209582448005676e-02
    z[6,7,6]  R2597     -2.3663861677050591e-02
    z[6,7,6]  R2598     -1.2370146811008453e-01
    z[6,7,6]  R2599     1.2677356600761414e-01
    z[6,7,6]  R2600     -2.3039312660694122e-01
    z[6,7,6]  R2601     -1.3164682686328888e-01
    z[6,7,6]  R2602     2.1696081757545471e-01
    z[6,7,6]  R2603     2.6832911372184753e-01
    z[6,7,6]  R2604     -1.3177742250263691e-02
    z[6,7,6]  R2605     3.0612629652023315e-01
    z[6,7,6]  R2606     -1.2251044809818268e-01
    z[6,7,6]  R2607     2.6547789573669434e-01
    z[6,7,6]  R2608     0.0589272603392601
    z[6,7,6]  R2609     -4.9622341990470886e-01
    z[6,7,6]  R2610     -3.6355575919151306e-01
    z[6,7,6]  R2611     4.4139412045478821e-01
    z[6,7,6]  R2612     2.6935037970542908e-01
    z[6,7,6]  R2613     -1.2859410047531128e-01
    z[6,7,6]  R2614     1.3162109255790710e-01
    z[6,7,6]  R2615     3.3296972513198853e-02
    z[6,7,6]  R2616     -5.1404148340225220e-01
    z[6,7,6]  R2617     3.3346044365316629e-03
    z[6,7,6]  R2618     -1.9768282771110535e-01
    z[6,7,6]  R2619     2.7940711379051208e-01
    z[6,7,6]  R2620     -4.1030306369066238e-02
    z[6,7,6]  R2621     4.2660921812057495e-01
    z[6,7,6]  R2622     3.8344833254814148e-01
    z[6,7,6]  R2623     -1.2711404263973236e-01
    z[6,7,6]  R2624     -4.1706174612045288e-01
    z[6,7,6]  R2625     -6.1860390007495880e-02
    z[6,7,6]  R2626     -1.2872008979320526e-01
    z[6,7,6]  R2627     5.2757188677787781e-02
    z[6,7,6]  R2628     -1.8861402571201324e-01
    z[6,7,6]  R2629     2.2779045999050140e-01
    z[6,7,6]  R2630     3.3120752777904272e-03
    z[7,6,0]  R56       1
    z[7,6,0]  R65       -1
    z[7,6,0]  R2631     -1
    z[7,6,0]  R2632     1
    z[7,6,0]  R2645     -2.1621994674205780e-01
    z[7,6,0]  R2646     -4.5511227846145630e-01
    z[7,6,0]  R2647     1.1857293546199799e-01
    z[7,6,0]  R2648     -2.6836407184600830e-01
    z[7,6,0]  R2649     -6.1877554655075073e-01
    z[7,6,0]  R2650     -5.6078499555587769e-01
    z[7,6,0]  R2651     -4.8424881696701050e-01
    z[7,6,0]  R2652     -0.493665486574173
    z[7,6,0]  R2653     -6.5295916795730591e-01
    z[7,6,0]  R2654     -5.0218790769577026e-01
    z[7,6,0]  R2655     4.4836950302124023e-01
    z[7,6,0]  R2656     3.7923336029052734e-01
    z[7,6,0]  R2657     3.2009416818618774e-01
    z[7,6,0]  R2658     4.2270222306251526e-01
    z[7,6,0]  R2659     3.3594289422035217e-01
    z[7,6,0]  R2660     0.368246465921402
    z[7,6,0]  R2661     4.5081678032875061e-01
    z[7,6,0]  R2662     4.2248663306236267e-01
    z[7,6,0]  R2663     3.4102728962898254e-01
    z[7,6,0]  R2664     2.0220804214477539e-01
    z[7,6,0]  R2665     -2.8328239917755127e-01
    z[7,6,0]  R2666     -1.7455467581748962e-01
    z[7,6,0]  R2667     -1.4616841077804565e-01
    z[7,6,0]  R2668     2.8160439804196358e-02
    z[7,6,0]  R2669     1.1431477218866348e-01
    z[7,6,0]  R2670     1.0720545798540115e-01
    z[7,6,0]  R2671     2.2843575105071068e-02
    z[7,6,0]  R2672     -2.9791104793548584e-01
    z[7,6,0]  R2673     -2.2452485561370850e-01
    z[7,6,0]  R2674     5.9810775518417358e-01
    z[7,6,0]  R2675     8.8973073288798332e-03
    z[7,6,0]  R2676     -9.1658718883991241e-02
    z[7,6,0]  R2677     1.0764811933040619e-01
    z[7,6,0]  R2678     -2.6607245206832886e-01
    z[7,6,0]  R2679     -4.6468096971511841e-01
    z[7,6,0]  R2680     9.6932905912399292e-01
    z[7,6,0]  R2681     9.6469402313232422e-01
    z[7,6,0]  R2682     9.1660410165786743e-01
    z[7,6,0]  R2683     0.891918957233429
    z[7,6,0]  R2684     8.0443078279495239e-01
    z[7,6,0]  R2685     -2.6799976825714111e-01
    z[7,6,0]  R2686     -3.0848485231399536e-01
    z[7,6,0]  R2687     -0.502948522567749
    z[7,6,0]  R2688     -4.1463658213615417e-01
    z[7,6,0]  R2689     -4.0166664123535156e-01
    z[7,6,0]  R2690     -6.7071980237960815e-01
    z[7,6,0]  R2691     4.1482448577880859e-01
    z[7,6,0]  R2692     1.3724394142627716e-01
    z[7,6,0]  R2693     1.4065656065940857e-01
    z[7,6,0]  R2694     -1.9479477405548096e-01
    z[7,6,0]  R2695     3.3613452315330505e-01
    z[7,6,0]  R2696     1.0425824671983719e-01
    z[7,6,0]  R2697     0.254373162984848
    z[7,6,0]  R2698     -1.9016842544078827e-01
    z[7,6,0]  R2699     1.0421057045459747e-01
    z[7,6,0]  R2700     5.0094765424728394e-01
    z[7,6,0]  R2701     -4.1455483436584473e-01
    z[7,6,0]  R2702     -1.5327689051628113e-01
    z[7,6,0]  R2703     -7.3224997520446777e-01
    z[7,6,0]  R2704     -4.9367743730545044e-01
    z[7,6,0]  R2705     1.4100821316242218e-01
    z[7,6,0]  R2706     2.1753439307212830e-01
    z[7,6,0]  R2707     -1.2073613703250885e-01
    z[7,6,0]  R2708     -1.8786756694316864e-01
    z[7,6,0]  R2709     -9.2207081615924835e-03
    z[7,6,0]  R2710     2.0490171015262604e-01
    z[7,6,0]  R2711     -4.1622537374496460e-01
    z[7,6,0]  R2712     -0.274004727602005
    z[7,6,0]  R2713     1.6240687668323517e-01
    z[7,6,0]  R2714     -5.9607338905334473e-01
    z[7,6,0]  R2715     -3.1939432024955750e-01
    z[7,6,0]  R2716     -4.3587210774421692e-01
    z[7,6,0]  R2717     4.1314664483070374e-01
    z[7,6,0]  R2718     -1.7168661952018738e-01
    z[7,6,0]  R2719     -0.0768650621175766
    z[7,6,0]  R2720     1.2949213385581970e-01
    z[7,6,0]  R2721     -8.7719194591045380e-02
    z[7,6,0]  R2722     5.6931927800178528e-02
    z[7,6,0]  R2723     5.4856240749359131e-01
    z[7,6,0]  R2724     6.0297280550003052e-01
    z[7,6,0]  R2725     -1.9797690212726593e-01
    z[7,6,0]  R2726     1.5428879298269749e-02
    z[7,6,0]  R2727     1.7626523971557617e-01
    z[7,6,0]  R2728     4.1131421923637390e-01
    z[7,6,0]  R2729     2.3615600541234016e-02
    z[7,6,0]  R2730     5.5942213535308838e-01
    z[7,6,0]  R2731     3.5299485921859741e-01
    z[7,6,0]  R2732     -1.6912724822759628e-02
    z[7,6,0]  R2733     1.3452319800853729e-01
    z[7,6,0]  R2734     2.1778613328933716e-01
    z[7,6,0]  R2735     -2.8781610727310181e-01
    z[7,6,0]  R2736     3.7395498156547546e-01
    z[7,6,0]  R2737     2.0948988199234009e-01
    z[7,6,0]  R2738     1.1307834833860397e-01
    z[7,6,0]  R2739     -1.8201948702335358e-01
    z[7,6,0]  R2740     -2.8810063004493713e-01
    z[7,6,0]  R2741     9.0143084526062012e-01
    z[7,6,1]  R57       1
    z[7,6,1]  R66       -1
    z[7,6,1]  R2633     -1
    z[7,6,1]  R2634     1
    z[7,6,1]  R2645     -7.6087635755538940e-01
    z[7,6,1]  R2646     -3.7918284535408020e-01
    z[7,6,1]  R2647     -5.8403360843658447e-01
    z[7,6,1]  R2648     -0.577204704284668
    z[7,6,1]  R2649     -5.0304710865020752e-01
    z[7,6,1]  R2650     -5.1557654142379761e-01
    z[7,6,1]  R2651     -3.6960625648498535e-01
    z[7,6,1]  R2652     -6.7872440814971924e-01
    z[7,6,1]  R2653     7.0590823888778687e-01
    z[7,6,1]  R2654     6.5275180339813232e-01
    z[7,6,1]  R2655     7.7657061815261841e-01
    z[7,6,1]  R2656     6.8200689554214478e-01
    z[7,6,1]  R2657     6.6349774599075317e-01
    z[7,6,1]  R2658     6.1811476945877075e-01
    z[7,6,1]  R2659     6.1596262454986572e-01
    z[7,6,1]  R2660     5.7915139198303223e-01
    z[7,6,1]  R2661     7.0773756504058838e-01
    z[7,6,1]  R2662     5.3430587053298950e-01
    z[7,6,1]  R2663     3.9622643589973450e-01
    z[7,6,1]  R2664     4.3754762411117554e-01
    z[7,6,1]  R2665     4.8011958599090576e-01
    z[7,6,1]  R2666     3.8664203882217407e-01
    z[7,6,1]  R2667     -2.5440484285354614e-01
    z[7,6,1]  R2668     -3.0046477913856506e-01
    z[7,6,1]  R2669     -6.3220870494842529e-01
    z[7,6,1]  R2670     -5.6545984745025635e-01
    z[7,6,1]  R2671     4.8776644468307495e-01
    z[7,6,1]  R2672     4.6707892417907715e-01
    z[7,6,1]  R2673     5.2490210533142090e-01
    z[7,6,1]  R2674     -2.4439743161201477e-01
    z[7,6,1]  R2675     0.74985671043396
    z[7,6,1]  R2676     7.4483048915863037e-01
    z[7,6,1]  R2677     6.0011005401611328e-01
    z[7,6,1]  R2678     -1.0027145594358444e-01
    z[7,6,1]  R2679     -3.2934451103210449e-01
    z[7,6,1]  R2680     -1.1398215591907501e-01
    z[7,6,1]  R2681     -1.0426852852106094e-01
    z[7,6,1]  R2682     -0.144050732254982
    z[7,6,1]  R2683     -0.0899525135755539
    z[7,6,1]  R2684     7.9007655382156372e-02
    z[7,6,1]  R2685     2.6034945249557495e-01
    z[7,6,1]  R2686     -3.4273234009742737e-01
    z[7,6,1]  R2687     3.3970236778259277e-01
    z[7,6,1]  R2688     0.287553071975708
    z[7,6,1]  R2689     -1.8081579357385635e-02
    z[7,6,1]  R2690     -1.0382114350795746e-01
    z[7,6,1]  R2691     6.3087075948715210e-01
    z[7,6,1]  R2692     6.6886502504348755e-01
    z[7,6,1]  R2693     7.1507990360260010e-01
    z[7,6,1]  R2694     1.6465568542480469e-01
    z[7,6,1]  R2695     -1.9731727242469788e-01
    z[7,6,1]  R2696     2.3253744840621948e-01
    z[7,6,1]  R2697     -1.3593323528766632e-01
    z[7,6,1]  R2698     4.5358244329690933e-02
    z[7,6,1]  R2699     -0.3088398873806
    z[7,6,1]  R2700     -2.1598720923066139e-02
    z[7,6,1]  R2701     -1.5587671659886837e-02
    z[7,6,1]  R2702     -1.1244186758995056e-01
    z[7,6,1]  R2703     -1.2262280285358429e-01
    z[7,6,1]  R2704     -4.1260862350463867e-01
    z[7,6,1]  R2705     -2.0453684031963348e-01
    z[7,6,1]  R2706     1.3772989809513092e-01
    z[7,6,1]  R2707     -3.0731928348541260e-01
    z[7,6,1]  R2708     3.0537009239196777e-01
    z[7,6,1]  R2709     1.7410951852798462e-01
    z[7,6,1]  R2710     5.5265665054321289e-01
    z[7,6,1]  R2711     3.9770871400833130e-01
    z[7,6,1]  R2712     1.5753868967294693e-02
    z[7,6,1]  R2713     -2.0316170156002045e-01
    z[7,6,1]  R2714     -2.0895386114716530e-02
    z[7,6,1]  R2715     3.3721652626991272e-01
    z[7,6,1]  R2716     0.0609736330807209
    z[7,6,1]  R2717     -3.0422195792198181e-01
    z[7,6,1]  R2718     2.3960523307323456e-01
    z[7,6,1]  R2719     5.8998677879571915e-02
    z[7,6,1]  R2720     8.6291587352752686e-01
    z[7,6,1]  R2721     8.5653185844421387e-01
    z[7,6,1]  R2722     8.1906998157501221e-01
    z[7,6,1]  R2723     7.3512208461761475e-01
    z[7,6,1]  R2724     4.4444590806961060e-01
    z[7,6,1]  R2725     -2.5734481215476990e-01
    z[7,6,1]  R2726     3.8917216658592224e-01
    z[7,6,1]  R2727     9.5235210657119751e-01
    z[7,6,1]  R2728     -1.1356313712894917e-02
    z[7,6,1]  R2729     9.0541803836822510e-01
    z[7,6,1]  R2730     5.4022759199142456e-01
    z[7,6,1]  R2731     5.0834619998931885e-01
    z[7,6,1]  R2732     -9.0297651290893555e-01
    z[7,6,1]  R2733     -8.1154477596282959e-01
    z[7,6,1]  R2734     -9.0584987401962280e-01
    z[7,6,1]  R2735     -1.6611185669898987e-01
    z[7,6,1]  R2736     9.2443414032459259e-02
    z[7,6,1]  R2737     3.8873386383056641e-01
    z[7,6,1]  R2738     -6.8229228258132935e-01
    z[7,6,1]  R2739     -3.2924848794937134e-01
    z[7,6,1]  R2740     -2.0766112208366394e-01
    z[7,6,1]  R2741     -1.3121864199638367e-01
    z[7,6,2]  R58       1
    z[7,6,2]  R67       -1
    z[7,6,2]  R2635     -1
    z[7,6,2]  R2636     1
    z[7,6,2]  R2645     -4.9087649583816528e-01
    z[7,6,2]  R2646     -4.5914888381958008e-01
    z[7,6,2]  R2647     -5.7204127311706543e-01
    z[7,6,2]  R2648     -5.5474025011062622e-01
    z[7,6,2]  R2649     -2.0608049631118774e-01
    z[7,6,2]  R2650     -3.8284295797348022e-01
    z[7,6,2]  R2651     -3.7049689888954163e-01
    z[7,6,2]  R2652     1.8101982772350311e-01
    z[7,6,2]  R2653     0.0501449890434742
    z[7,6,2]  R2654     -2.6582766324281693e-02
    z[7,6,2]  R2655     1.1455873399972916e-01
    z[7,6,2]  R2656     -1.9130834937095642e-01
    z[7,6,2]  R2657     3.4527698159217834e-01
    z[7,6,2]  R2658     2.9010051488876343e-01
    z[7,6,2]  R2659     -1.4007273316383362e-01
    z[7,6,2]  R2660     5.3694641590118408e-01
    z[7,6,2]  R2661     0.0927298292517662
    z[7,6,2]  R2662     -6.8193182349205017e-02
    z[7,6,2]  R2663     0.50670325756073
    z[7,6,2]  R2664     3.2412725687026978e-01
    z[7,6,2]  R2665     1.1077066510915756e-01
    z[7,6,2]  R2666     -2.5768473744392395e-01
    z[7,6,2]  R2667     1.4226564764976501e-01
    z[7,6,2]  R2668     -8.1668600440025330e-02
    z[7,6,2]  R2669     7.0994421839714050e-02
    z[7,6,2]  R2670     9.5608517527580261e-02
    z[7,6,2]  R2671     -4.6972211450338364e-02
    z[7,6,2]  R2672     5.4767513275146484e-01
    z[7,6,2]  R2673     1.6562581062316895e-01
    z[7,6,2]  R2674     2.7310448884963989e-01
    z[7,6,2]  R2675     1.8667300045490265e-01
    z[7,6,2]  R2676     9.7441887483000755e-03
    z[7,6,2]  R2677     2.2966033220291138e-01
    z[7,6,2]  R2678     7.1472458541393280e-02
    z[7,6,2]  R2679     4.2513498663902283e-01
    z[7,6,2]  R2680     -0.0327107198536396
    z[7,6,2]  R2681     2.1202708780765533e-01
    z[7,6,2]  R2682     1.3398066163063049e-01
    z[7,6,2]  R2683     8.6986780166625977e-02
    z[7,6,2]  R2684     9.7790569067001343e-02
    z[7,6,2]  R2685     -3.9756676554679871e-01
    z[7,6,2]  R2686     -4.9994894862174988e-01
    z[7,6,2]  R2687     -2.3084443807601929e-01
    z[7,6,2]  R2688     -2.0341536402702332e-01
    z[7,6,2]  R2689     1.1693882942199707e-01
    z[7,6,2]  R2690     8.1346176564693451e-02
    z[7,6,2]  R2691     -2.8455637395381927e-02
    z[7,6,2]  R2692     -4.7480916976928711e-01
    z[7,6,2]  R2693     0.399924099445343
    z[7,6,2]  R2694     -3.5927772521972656e-01
    z[7,6,2]  R2695     -2.6057684421539307e-01
    z[7,6,2]  R2696     7.0517949759960175e-02
    z[7,6,2]  R2697     1.9377246499061584e-01
    z[7,6,2]  R2698     -3.5220120102167130e-02
    z[7,6,2]  R2699     -1.5724499523639679e-01
    z[7,6,2]  R2700     -0.251311331987381
    z[7,6,2]  R2701     -4.4861888885498047e-01
    z[7,6,2]  R2702     8.4616623818874359e-02
    z[7,6,2]  R2703     -4.3666278943419456e-03
    z[7,6,2]  R2704     2.8069657087326050e-01
    z[7,6,2]  R2705     1.4100825786590576e-01
    z[7,6,2]  R2706     -8.8609211146831512e-02
    z[7,6,2]  R2707     -3.8922277092933655e-01
    z[7,6,2]  R2708     -8.1903554499149323e-02
    z[7,6,2]  R2709     -0.564672589302063
    z[7,6,2]  R2710     -3.1437207013368607e-02
    z[7,6,2]  R2711     -1.1584430932998657e-01
    z[7,6,2]  R2712     -2.2531510889530182e-01
    z[7,6,2]  R2713     2.7839755639433861e-03
    z[7,6,2]  R2714     -5.0746973603963852e-02
    z[7,6,2]  R2715     -2.3050782084465027e-01
    z[7,6,2]  R2716     2.4781459942460060e-02
    z[7,6,2]  R2717     -6.3811242580413818e-02
    z[7,6,2]  R2718     -8.2455776631832123e-02
    z[7,6,2]  R2719     -2.8026726841926575e-01
    z[7,6,2]  R2720     7.1502029895782471e-02
    z[7,6,2]  R2721     2.1758085489273071e-01
    z[7,6,2]  R2722     3.5238778591156006e-01
    z[7,6,2]  R2723     -1.8645766377449036e-01
    z[7,6,2]  R2724     3.1171867251396179e-01
    z[7,6,2]  R2725     -3.9491170644760132e-01
    z[7,6,2]  R2726     1.6960716247558594e-01
    z[7,6,2]  R2727     -1.4601002633571625e-01
    z[7,6,2]  R2728     -4.1508537530899048e-01
    z[7,6,2]  R2729     2.7347663044929504e-01
    z[7,6,2]  R2730     2.0718546211719513e-01
    z[7,6,2]  R2731     3.8754299283027649e-01
    z[7,6,2]  R2732     7.2244450449943542e-02
    z[7,6,2]  R2733     0.145552858710289
    z[7,6,2]  R2734     5.7123210281133652e-02
    z[7,6,2]  R2735     -3.3237934112548828e-01
    z[7,6,2]  R2736     -3.8678976893424988e-01
    z[7,6,2]  R2737     5.5587112903594971e-01
    z[7,6,2]  R2738     -3.4621194005012512e-02
    z[7,6,2]  R2739     -0.0864488035440445
    z[7,6,2]  R2740     -1.7532606422901154e-01
    z[7,6,2]  R2741     -0.0704229474067688
    z[7,6,3]  R59       1
    z[7,6,3]  R68       -1
    z[7,6,3]  R2637     -1
    z[7,6,3]  R2638     1
    z[7,6,3]  R2645     -1.9534103572368622e-01
    z[7,6,3]  R2646     -6.7476667463779449e-02
    z[7,6,3]  R2647     -7.6603449881076813e-02
    z[7,6,3]  R2648     3.7834087014198303e-01
    z[7,6,3]  R2649     7.6880931854248047e-02
    z[7,6,3]  R2650     3.3753588795661926e-01
    z[7,6,3]  R2651     1.9323676824569702e-02
    z[7,6,3]  R2652     -2.4950817227363586e-01
    z[7,6,3]  R2653     2.1537464857101440e-01
    z[7,6,3]  R2654     4.7597751021385193e-01
    z[7,6,3]  R2655     -3.5705888271331787e-01
    z[7,6,3]  R2656     3.9178112149238586e-01
    z[7,6,3]  R2657     -5.1507627964019775e-01
    z[7,6,3]  R2658     -5.1381522417068481e-01
    z[7,6,3]  R2659     -3.5033130645751953e-01
    z[7,6,3]  R2660     -3.7505501508712769e-01
    z[7,6,3]  R2661     -2.3978227376937866e-01
    z[7,6,3]  R2662     -2.6280593872070312e-01
    z[7,6,3]  R2663     -3.5178834199905396e-01
    z[7,6,3]  R2664     -0.566901445388794
    z[7,6,3]  R2665     -0.554315984249115
    z[7,6,3]  R2666     -8.1742691993713379e-01
    z[7,6,3]  R2667     5.3159141540527344e-01
    z[7,6,3]  R2668     5.3855520486831665e-01
    z[7,6,3]  R2669     1.6299067437648773e-01
    z[7,6,3]  R2670     3.1442412734031677e-01
    z[7,6,3]  R2671     3.9757695794105530e-01
    z[7,6,3]  R2672     -2.7959507703781128e-01
    z[7,6,3]  R2673     6.3443198800086975e-02
    z[7,6,3]  R2674     -0.675109326839447
    z[7,6,3]  R2675     -2.0627894997596741e-01
    z[7,6,3]  R2676     -7.3001608252525330e-02
    z[7,6,3]  R2677     3.6904498934745789e-01
    z[7,6,3]  R2678     6.6535556316375732e-01
    z[7,6,3]  R2679     1.6231556236743927e-01
    z[7,6,3]  R2680     -3.4614145755767822e-02
    z[7,6,3]  R2681     9.6747368574142456e-02
    z[7,6,3]  R2682     2.3363502323627472e-01
    z[7,6,3]  R2683     3.2033350318670273e-02
    z[7,6,3]  R2684     2.9793012142181396e-01
    z[7,6,3]  R2685     6.5393263101577759e-01
    z[7,6,3]  R2686     5.0959396362304688e-01
    z[7,6,3]  R2687     4.0262740850448608e-01
    z[7,6,3]  R2688     0.0463026687502861
    z[7,6,3]  R2689     -7.2940096259117126e-02
    z[7,6,3]  R2690     2.8767937421798706e-01
    z[7,6,3]  R2691     -0.0512276254594326
    z[7,6,3]  R2692     -7.1023985743522644e-02
    z[7,6,3]  R2693     -3.7454909086227417e-01
    z[7,6,3]  R2694     -7.4034363031387329e-02
    z[7,6,3]  R2695     -3.3794444799423218e-01
    z[7,6,3]  R2696     -2.8308334946632385e-01
    z[7,6,3]  R2697     -0.391967236995697
    z[7,6,3]  R2698     -2.7441471815109253e-01
    z[7,6,3]  R2699     -3.5618439316749573e-01
    z[7,6,3]  R2700     -4.3386444449424744e-01
    z[7,6,3]  R2701     -2.6035135984420776e-01
    z[7,6,3]  R2702     -3.7802201509475708e-01
    z[7,6,3]  R2703     -3.1466564536094666e-01
    z[7,6,3]  R2704     -2.4095329642295837e-01
    z[7,6,3]  R2705     -6.8053388595581055e-01
    z[7,6,3]  R2706     -7.2847908735275269e-01
    z[7,6,3]  R2707     -7.1762156486511230e-01
    z[7,6,3]  R2708     -6.7181175947189331e-01
    z[7,6,3]  R2709     -7.5338131189346313e-01
    z[7,6,3]  R2710     -6.4652174711227417e-01
    z[7,6,3]  R2711     -6.3391441106796265e-01
    z[7,6,3]  R2712     -5.2807462215423584e-01
    z[7,6,3]  R2713     -6.9509744644165039e-01
    z[7,6,3]  R2714     -7.5340855121612549e-01
    z[7,6,3]  R2715     -6.3471955060958862e-01
    z[7,6,3]  R2716     -7.7655339241027832e-01
    z[7,6,3]  R2717     -6.2197327613830566e-01
    z[7,6,3]  R2718     -6.6663116216659546e-01
    z[7,6,3]  R2719     -5.9071314334869385e-01
    z[7,6,3]  R2720     2.1089186891913414e-02
    z[7,6,3]  R2721     4.1512794792652130e-02
    z[7,6,3]  R2722     -3.4831660985946655e-01
    z[7,6,3]  R2723     -3.0824735760688782e-02
    z[7,6,3]  R2724     -5.2167940139770508e-01
    z[7,6,3]  R2725     -4.0444770455360413e-01
    z[7,6,3]  R2726     -8.0958712100982666e-01
    z[7,6,3]  R2727     -1.7638245224952698e-01
    z[7,6,3]  R2728     -4.1537594795227051e-01
    z[7,6,3]  R2729     -1.8703933060169220e-01
    z[7,6,3]  R2730     -5.4770672321319580e-01
    z[7,6,3]  R2731     -5.7849675416946411e-01
    z[7,6,3]  R2732     -2.0557032525539398e-01
    z[7,6,3]  R2733     -4.5151209831237793e-01
    z[7,6,3]  R2734     -2.2021782398223877e-01
    z[7,6,3]  R2735     -8.3125251531600952e-01
    z[7,6,3]  R2736     -0.372031033039093
    z[7,6,3]  R2737     -0.626023530960083
    z[7,6,3]  R2738     -3.2117596268653870e-01
    z[7,6,3]  R2739     4.4315099716186523e-01
    z[7,6,3]  R2740     3.2139471173286438e-01
    z[7,6,3]  R2741     2.2495168447494507e-01
    z[7,6,4]  R60       1
    z[7,6,4]  R69       -1
    z[7,6,4]  R2639     -1
    z[7,6,4]  R2640     1
    z[7,6,4]  R2645     8.8081859052181244e-02
    z[7,6,4]  R2646     4.2256745696067810e-01
    z[7,6,4]  R2647     4.9313545227050781e-01
    z[7,6,4]  R2648     1.0212492197751999e-01
    z[7,6,4]  R2649     9.8563842475414276e-02
    z[7,6,4]  R2650     3.8314953446388245e-01
    z[7,6,4]  R2651     6.5418505668640137e-01
    z[7,6,4]  R2652     5.4040521383285522e-02
    z[7,6,4]  R2653     -3.5474825650453568e-02
    z[7,6,4]  R2654     1.6338813304901123e-01
    z[7,6,4]  R2655     1.1716998182237148e-02
    z[7,6,4]  R2656     -2.0683860778808594e-01
    z[7,6,4]  R2657     2.3803491145372391e-02
    z[7,6,4]  R2658     2.1660542488098145e-01
    z[7,6,4]  R2659     5.1346683502197266e-01
    z[7,6,4]  R2660     -2.5644731521606445e-01
    z[7,6,4]  R2661     8.7570890784263611e-02
    z[7,6,4]  R2662     4.4482216238975525e-01
    z[7,6,4]  R2663     -1.8806131184101105e-01
    z[7,6,4]  R2664     3.8330635428428650e-01
    z[7,6,4]  R2665     2.7388921380043030e-01
    z[7,6,4]  R2666     -1.1197332292795181e-01
    z[7,6,4]  R2667     -7.5706982612609863e-01
    z[7,6,4]  R2668     -6.3856667280197144e-01
    z[7,6,4]  R2669     -5.2379405498504639e-01
    z[7,6,4]  R2670     -4.8556759953498840e-01
    z[7,6,4]  R2671     -3.9496758580207825e-01
    z[7,6,4]  R2672     1.3980881869792938e-01
    z[7,6,4]  R2673     -2.8170329332351685e-01
    z[7,6,4]  R2674     -1.0841037333011627e-01
    z[7,6,4]  R2675     -6.2899775803089142e-02
    z[7,6,4]  R2676     3.2857468724250793e-01
    z[7,6,4]  R2677     -0.607761025428772
    z[7,6,4]  R2678     -5.4443657398223877e-01
    z[7,6,4]  R2679     -5.0919461250305176e-01
    z[7,6,4]  R2680     -1.6262637078762054e-01
    z[7,6,4]  R2681     3.6612160503864288e-02
    z[7,6,4]  R2682     1.1570832133293152e-01
    z[7,6,4]  R2683     -2.0798210799694061e-01
    z[7,6,4]  R2684     6.3452489674091339e-02
    z[7,6,4]  R2685     -3.6099845170974731e-01
    z[7,6,4]  R2686     -5.0128477811813354e-01
    z[7,6,4]  R2687     -2.4232718348503113e-01
    z[7,6,4]  R2688     -6.2378132343292236e-01
    z[7,6,4]  R2689     -7.6530051231384277e-01
    z[7,6,4]  R2690     -8.2309916615486145e-02
    z[7,6,4]  R2691     5.0870066881179810e-01
    z[7,6,4]  R2692     5.2494859695434570e-01
    z[7,6,4]  R2693     2.2784644365310669e-01
    z[7,6,4]  R2694     6.3623136281967163e-01
    z[7,6,4]  R2695     6.6906195878982544e-01
    z[7,6,4]  R2696     0.715188205242157
    z[7,6,4]  R2697     8.1924271583557129e-01
    z[7,6,4]  R2698     7.3967492580413818e-01
    z[7,6,4]  R2699     4.9545809626579285e-01
    z[7,6,4]  R2700     6.3771128654479980e-01
    z[7,6,4]  R2701     6.3362246751785278e-01
    z[7,6,4]  R2702     1.2641207873821259e-01
    z[7,6,4]  R2703     4.4084584712982178e-01
    z[7,6,4]  R2704     5.3377324342727661e-01
    z[7,6,4]  R2705     5.4180890321731567e-01
    z[7,6,4]  R2706     1.1982502788305283e-01
    z[7,6,4]  R2707     3.1549152731895447e-01
    z[7,6,4]  R2708     1.6357085108757019e-01
    z[7,6,4]  R2709     2.0659507811069489e-01
    z[7,6,4]  R2710     3.2729476690292358e-01
    z[7,6,4]  R2711     3.3463621139526367e-01
    z[7,6,4]  R2712     5.3437018394470215e-01
    z[7,6,4]  R2713     5.3751307725906372e-01
    z[7,6,4]  R2714     2.0646791160106659e-01
    z[7,6,4]  R2715     4.4832786917686462e-01
    z[7,6,4]  R2716     2.7401667833328247e-01
    z[7,6,4]  R2717     5.2053558826446533e-01
    z[7,6,4]  R2718     5.4928040504455566e-01
    z[7,6,4]  R2719     1.5408772230148315e-01
    z[7,6,4]  R2720     2.7578663825988770e-01
    z[7,6,4]  R2721     3.2866501808166504e-01
    z[7,6,4]  R2722     -1.2901960313320160e-01
    z[7,6,4]  R2723     0.0457758866250515
    z[7,6,4]  R2724     -2.8694493696093559e-02
    z[7,6,4]  R2725     7.3351776599884033e-01
    z[7,6,4]  R2726     0.338083416223526
    z[7,6,4]  R2727     0.0929412767291069
    z[7,6,4]  R2728     6.1885702610015869e-01
    z[7,6,4]  R2729     -1.6371940076351166e-01
    z[7,6,4]  R2730     -0.0817561224102974
    z[7,6,4]  R2731     -0.0737539529800415
    z[7,6,4]  R2732     2.4493876099586487e-01
    z[7,6,4]  R2733     -6.9230049848556519e-02
    z[7,6,4]  R2734     1.8002241849899292e-01
    z[7,6,4]  R2735     2.5551870465278625e-01
    z[7,6,4]  R2736     6.9033432006835938e-01
    z[7,6,4]  R2737     2.9557922482490540e-01
    z[7,6,4]  R2738     1.9327664747834206e-02
    z[7,6,4]  R2739     7.8321486711502075e-01
    z[7,6,4]  R2740     5.0879049301147461e-01
    z[7,6,4]  R2741     2.1860572695732117e-01
    z[7,6,5]  R61       1
    z[7,6,5]  R70       -1
    z[7,6,5]  R2641     -1
    z[7,6,5]  R2642     1
    z[7,6,5]  R2645     1.9620141386985779e-01
    z[7,6,5]  R2646     4.6732330322265625e-01
    z[7,6,5]  R2647     0.257762610912323
    z[7,6,5]  R2648     3.2977280020713806e-01
    z[7,6,5]  R2649     2.7991998195648193e-01
    z[7,6,5]  R2650     -9.0255342423915863e-02
    z[7,6,5]  R2651     2.5046941637992859e-01
    z[7,6,5]  R2652     4.2706301808357239e-01
    z[7,6,5]  R2653     -9.5430992543697357e-02
    z[7,6,5]  R2654     -1.2117945402860641e-01
    z[7,6,5]  R2655     0.194473534822464
    z[7,6,5]  R2656     -3.3332142233848572e-01
    z[7,6,5]  R2657     -1.4950575307011604e-02
    z[7,6,5]  R2658     -2.0976434648036957e-01
    z[7,6,5]  R2659     -0.0895463153719902
    z[7,6,5]  R2660     -1.3865956664085388e-01
    z[7,6,5]  R2661     -3.8939729332923889e-01
    z[7,6,5]  R2662     -5.1084810495376587e-01
    z[7,6,5]  R2663     2.5415942072868347e-01
    z[7,6,5]  R2664     2.4926245212554932e-01
    z[7,6,5]  R2665     3.1599956750869751e-01
    z[7,6,5]  R2666     1.9042393192648888e-02
    z[7,6,5]  R2667     -1.4626312255859375e-01
    z[7,6,5]  R2668     -4.3257924914360046e-01
    z[7,6,5]  R2669     -5.2931028604507446e-01
    z[7,6,5]  R2670     -2.4646340310573578e-01
    z[7,6,5]  R2671     6.6729128360748291e-01
    z[7,6,5]  R2672     -5.0630003213882446e-01
    z[7,6,5]  R2673     6.9655174016952515e-01
    z[7,6,5]  R2674     1.9682997465133667e-01
    z[7,6,5]  R2675     4.1747590899467468e-01
    z[7,6,5]  R2676     -4.2000961303710938e-01
    z[7,6,5]  R2677     2.3197035491466522e-01
    z[7,6,5]  R2678     -3.1511966139078140e-02
    z[7,6,5]  R2679     -4.5322397351264954e-01
    z[7,6,5]  R2680     4.6095319092273712e-02
    z[7,6,5]  R2681     7.3622646741569042e-03
    z[7,6,5]  R2682     -1.3261437416076660e-01
    z[7,6,5]  R2683     3.0438652634620667e-01
    z[7,6,5]  R2684     4.9425348639488220e-01
    z[7,6,5]  R2685     -0.018271429464221
    z[7,6,5]  R2686     1.4349387586116791e-01
    z[7,6,5]  R2687     5.8392512798309326e-01
    z[7,6,5]  R2688     2.1635049581527710e-01
    z[7,6,5]  R2689     -1.1129476875066757e-01
    z[7,6,5]  R2690     5.4812282323837280e-01
    z[7,6,5]  R2691     1.7855556309223175e-01
    z[7,6,5]  R2692     3.8373034447431564e-02
    z[7,6,5]  R2693     3.3966964483261108e-01
    z[7,6,5]  R2694     -1.1695603281259537e-01
    z[7,6,5]  R2695     -4.6720793843269348e-01
    z[7,6,5]  R2696     -5.8165037631988525e-01
    z[7,6,5]  R2697     -1.4780853688716888e-01
    z[7,6,5]  R2698     -4.4981312751770020e-01
    z[7,6,5]  R2699     -5.9563565254211426e-01
    z[7,6,5]  R2700     -4.4312477111816406e-02
    z[7,6,5]  R2701     -3.2998120784759521e-01
    z[7,6,5]  R2702     -8.6903309822082520e-01
    z[7,6,5]  R2703     -3.4434261918067932e-01
    z[7,6,5]  R2704     -3.8126403093338013e-01
    z[7,6,5]  R2705     -2.0543164014816284e-01
    z[7,6,5]  R2706     -5.7612472772598267e-01
    z[7,6,5]  R2707     -1.0551296174526215e-01
    z[7,6,5]  R2708     -5.4740172624588013e-01
    z[7,6,5]  R2709     1.8206527456641197e-02
    z[7,6,5]  R2710     -2.8901594877243042e-01
    z[7,6,5]  R2711     -2.9624858498573303e-01
    z[7,6,5]  R2712     -1.8342342972755432e-01
    z[7,6,5]  R2713     3.7831076979637146e-01
    z[7,6,5]  R2714     1.7657433450222015e-01
    z[7,6,5]  R2715     -3.4343191981315613e-01
    z[7,6,5]  R2716     -2.7499023079872131e-01
    z[7,6,5]  R2717     -2.2095876932144165e-01
    z[7,6,5]  R2718     2.4364241957664490e-01
    z[7,6,5]  R2719     -5.7318305969238281e-01
    z[7,6,5]  R2720     -2.4612143635749817e-01
    z[7,6,5]  R2721     -2.8453272581100464e-01
    z[7,6,5]  R2722     0.06783477216959
    z[7,6,5]  R2723     1.8392252922058105e-01
    z[7,6,5]  R2724     -8.6709603667259216e-02
    z[7,6,5]  R2725     -1.7306198179721832e-01
    z[7,6,5]  R2726     1.6388094425201416e-01
    z[7,6,5]  R2727     2.9382398352026939e-02
    z[7,6,5]  R2728     2.2259229794144630e-02
    z[7,6,5]  R2729     -1.5884411334991455e-01
    z[7,6,5]  R2730     1.3070951402187347e-01
    z[7,6,5]  R2731     3.4013697504997253e-01
    z[7,6,5]  R2732     2.4353970587253571e-01
    z[7,6,5]  R2733     3.0460250377655029e-01
    z[7,6,5]  R2734     1.4695046842098236e-01
    z[7,6,5]  R2735     -2.7154510840773582e-02
    z[7,6,5]  R2736     -4.0896151214838028e-02
    z[7,6,5]  R2737     -5.0095748156309128e-02
    z[7,6,5]  R2738     4.9466714262962341e-01
    z[7,6,5]  R2739     -1.7966248095035553e-01
    z[7,6,5]  R2740     -2.6726812124252319e-01
    z[7,6,5]  R2741     -2.2878044843673706e-01
    z[7,6,6]  R62       1
    z[7,6,6]  R71       -1
    z[7,6,6]  R2643     -1
    z[7,6,6]  R2644     1
    z[7,6,6]  R2645     2.2123497724533081e-01
    z[7,6,6]  R2646     -1.9174998998641968e-01
    z[7,6,6]  R2647     0.0460628941655159
    z[7,6,6]  R2648     -1.5734435617923737e-01
    z[7,6,6]  R2649     4.7708559036254883e-01
    z[7,6,6]  R2650     -6.5209582448005676e-02
    z[7,6,6]  R2651     -2.3663861677050591e-02
    z[7,6,6]  R2652     -1.2370146811008453e-01
    z[7,6,6]  R2653     1.2677356600761414e-01
    z[7,6,6]  R2654     -2.3039312660694122e-01
    z[7,6,6]  R2655     -1.3164682686328888e-01
    z[7,6,6]  R2656     2.1696081757545471e-01
    z[7,6,6]  R2657     2.6832911372184753e-01
    z[7,6,6]  R2658     -1.3177742250263691e-02
    z[7,6,6]  R2659     3.0612629652023315e-01
    z[7,6,6]  R2660     -1.2251044809818268e-01
    z[7,6,6]  R2661     2.6547789573669434e-01
    z[7,6,6]  R2662     0.0589272603392601
    z[7,6,6]  R2663     -4.9622341990470886e-01
    z[7,6,6]  R2664     -3.6355575919151306e-01
    z[7,6,6]  R2665     4.4139412045478821e-01
    z[7,6,6]  R2666     2.6935037970542908e-01
    z[7,6,6]  R2667     -1.2859410047531128e-01
    z[7,6,6]  R2668     1.3162109255790710e-01
    z[7,6,6]  R2669     3.3296972513198853e-02
    z[7,6,6]  R2670     -5.1404148340225220e-01
    z[7,6,6]  R2671     3.3346044365316629e-03
    z[7,6,6]  R2672     -1.9768282771110535e-01
    z[7,6,6]  R2673     2.7940711379051208e-01
    z[7,6,6]  R2674     -4.1030306369066238e-02
    z[7,6,6]  R2675     4.2660921812057495e-01
    z[7,6,6]  R2676     3.8344833254814148e-01
    z[7,6,6]  R2677     -1.2711404263973236e-01
    z[7,6,6]  R2678     -4.1706174612045288e-01
    z[7,6,6]  R2679     -6.1860390007495880e-02
    z[7,6,6]  R2680     -1.2872008979320526e-01
    z[7,6,6]  R2681     5.2757188677787781e-02
    z[7,6,6]  R2682     -1.8861402571201324e-01
    z[7,6,6]  R2683     2.2779045999050140e-01
    z[7,6,6]  R2684     3.3120752777904272e-03
    z[7,6,6]  R2685     3.7954360246658325e-01
    z[7,6,6]  R2686     7.6548673212528229e-02
    z[7,6,6]  R2687     -1.2867036461830139e-01
    z[7,6,6]  R2688     -5.1571053266525269e-01
    z[7,6,6]  R2689     4.7039404511451721e-01
    z[7,6,6]  R2690     3.7784385681152344e-01
    z[7,6,6]  R2691     -3.6855155229568481e-01
    z[7,6,6]  R2692     -1.6202476620674133e-01
    z[7,6,6]  R2693     -3.6887574940919876e-02
    z[7,6,6]  R2694     -6.1799097061157227e-01
    z[7,6,6]  R2695     -6.7602782510221004e-03
    z[7,6,6]  R2696     -1.1672931723296642e-02
    z[7,6,6]  R2697     1.8062233924865723e-01
    z[7,6,6]  R2698     0.368488609790802
    z[7,6,6]  R2699     3.7670186161994934e-01
    z[7,6,6]  R2700     2.9757311940193176e-01
    z[7,6,6]  R2701     2.2021479904651642e-01
    z[7,6,6]  R2702     -2.0640711486339569e-01
    z[7,6,6]  R2703     -1.9189366698265076e-01
    z[7,6,6]  R2704     -1.3751919567584991e-01
    z[7,6,6]  R2705     -0.345706045627594
    z[7,6,6]  R2706     2.2112955152988434e-01
    z[7,6,6]  R2707     3.3739423751831055e-01
    z[7,6,6]  R2708     2.9497742652893066e-01
    z[7,6,6]  R2709     -2.0037274062633514e-01
    z[7,6,6]  R2710     2.0725630223751068e-01
    z[7,6,6]  R2711     -2.3145695030689240e-01
    z[7,6,6]  R2712     -5.2521222829818726e-01
    z[7,6,6]  R2713     -1.3092701137065887e-01
    z[7,6,6]  R2714     -1.5891024842858315e-02
    z[7,6,6]  R2715     -9.6572116017341614e-02
    z[7,6,6]  R2716     2.2791130840778351e-01
    z[7,6,6]  R2717     1.6141925752162933e-01
    z[7,6,6]  R2718     3.1756326556205750e-01
    z[7,6,6]  R2719     -4.5917022228240967e-01
    z[7,6,6]  R2720     -3.1051045656204224e-01
    z[7,6,6]  R2721     -1.4357627928256989e-01
    z[7,6,6]  R2722     2.4317464232444763e-01
    z[7,6,6]  R2723     -2.9501739144325256e-01
    z[7,6,6]  R2724     2.4745029211044312e-01
    z[7,6,6]  R2725     8.3945758640766144e-02
    z[7,6,6]  R2726     0.151498481631279
    z[7,6,6]  R2727     4.9973125569522381e-03
    z[7,6,6]  R2728     -3.1996732950210571e-01
    z[7,6,6]  R2729     1.3361082971096039e-01
    z[7,6,6]  R2730     -1.6888926923274994e-01
    z[7,6,6]  R2731     1.0487063229084015e-01
    z[7,6,6]  R2732     -1.3252280652523041e-01
    z[7,6,6]  R2733     -2.5968968868255615e-02
    z[7,6,6]  R2734     1.6199924051761627e-01
    z[7,6,6]  R2735     -1.4860944449901581e-01
    z[7,6,6]  R2736     -2.9217207431793213e-01
    z[7,6,6]  R2737     -1.1926929652690887e-01
    z[7,6,6]  R2738     -4.1505265235900879e-01
    z[7,6,6]  R2739     -0.0943610891699791
    z[7,6,6]  R2740     -6.3995391130447388e-01
    z[7,6,6]  R2741     -1.2046817690134048e-01
    length[0]  OBJ       1
    length[1]  OBJ       1
    length[2]  OBJ       1
    length[3]  OBJ       1
    length[4]  OBJ       1
    length[5]  OBJ       1
    length[6]  OBJ       1
    length[7]  OBJ       1
    delta[0,0]  R2        1
    delta[0,1]  R3        1
    delta[0,2]  R4        1
    delta[0,3]  R5        1
    delta[0,4]  R6        1
    delta[0,5]  R7        1
    delta[0,6]  R8        1
    delta[1,0]  R11       1
    delta[1,1]  R12       1
    delta[1,2]  R13       1
    delta[1,3]  R14       1
    delta[1,4]  R15       1
    delta[1,5]  R16       1
    delta[1,6]  R17       1
    delta[2,0]  R20       1
    delta[2,1]  R21       1
    delta[2,2]  R22       1
    delta[2,3]  R23       1
    delta[2,4]  R24       1
    delta[2,5]  R25       1
    delta[2,6]  R26       1
    delta[3,0]  R29       1
    delta[3,1]  R30       1
    delta[3,2]  R31       1
    delta[3,3]  R32       1
    delta[3,4]  R33       1
    delta[3,5]  R34       1
    delta[3,6]  R35       1
    delta[4,0]  R38       1
    delta[4,1]  R39       1
    delta[4,2]  R40       1
    delta[4,3]  R41       1
    delta[4,4]  R42       1
    delta[4,5]  R43       1
    delta[4,6]  R44       1
    delta[5,0]  R47       1
    delta[5,1]  R48       1
    delta[5,2]  R49       1
    delta[5,3]  R50       1
    delta[5,4]  R51       1
    delta[5,5]  R52       1
    delta[5,6]  R53       1
    delta[6,0]  R56       1
    delta[6,1]  R57       1
    delta[6,2]  R58       1
    delta[6,3]  R59       1
    delta[6,4]  R60       1
    delta[6,5]  R61       1
    delta[6,6]  R62       1
    delta[7,0]  R65       1
    delta[7,1]  R66       1
    delta[7,2]  R67       1
    delta[7,3]  R68       1
    delta[7,4]  R69       1
    delta[7,5]  R70       1
    delta[7,6]  R71       1
RHS
    RHS1      R1        1
    RHS1      R10       1
    RHS1      R19       1
    RHS1      R28       1
    RHS1      R37       1
    RHS1      R46       1
    RHS1      R55       1
    RHS1      R64       1
    RHS1      R72       1
    RHS1      R73       -1
BOUNDS
 BV BND1      phi[0,1]
 BV BND1      phi[1,0]
 BV BND1      phi[0,4]
 BV BND1      phi[4,0]
 BV BND1      phi[8,0]
 BV BND1      phi[1,2]
 BV BND1      phi[2,1]
 BV BND1      phi[1,5]
 BV BND1      phi[5,1]
 BV BND1      phi[2,3]
 BV BND1      phi[3,2]
 BV BND1      phi[2,6]
 BV BND1      phi[6,2]
 BV BND1      phi[2,7]
 BV BND1      phi[7,2]
 BV BND1      phi[3,6]
 BV BND1      phi[6,3]
 BV BND1      phi[3,7]
 BV BND1      phi[7,3]
 BV BND1      phi[3,9]
 BV BND1      phi[4,5]
 BV BND1      phi[5,4]
 BV BND1      phi[8,4]
 BV BND1      phi[5,6]
 BV BND1      phi[6,5]
 BV BND1      phi[6,7]
 BV BND1      phi[7,6]
 BV BND1      phi[7,9]
 FR BND1      z[0,1,0]
 FR BND1      z[0,1,1]
 FR BND1      z[0,1,2]
 FR BND1      z[0,1,3]
 FR BND1      z[0,1,4]
 FR BND1      z[0,1,5]
 FR BND1      z[0,1,6]
 FR BND1      z[1,0,0]
 FR BND1      z[1,0,1]
 FR BND1      z[1,0,2]
 FR BND1      z[1,0,3]
 FR BND1      z[1,0,4]
 FR BND1      z[1,0,5]
 FR BND1      z[1,0,6]
 FR BND1      z[0,4,0]
 FR BND1      z[0,4,1]
 FR BND1      z[0,4,2]
 FR BND1      z[0,4,3]
 FR BND1      z[0,4,4]
 FR BND1      z[0,4,5]
 FR BND1      z[0,4,6]
 FR BND1      z[4,0,0]
 FR BND1      z[4,0,1]
 FR BND1      z[4,0,2]
 FR BND1      z[4,0,3]
 FR BND1      z[4,0,4]
 FR BND1      z[4,0,5]
 FR BND1      z[4,0,6]
 FR BND1      z[1,2,0]
 FR BND1      z[1,2,1]
 FR BND1      z[1,2,2]
 FR BND1      z[1,2,3]
 FR BND1      z[1,2,4]
 FR BND1      z[1,2,5]
 FR BND1      z[1,2,6]
 FR BND1      z[2,1,0]
 FR BND1      z[2,1,1]
 FR BND1      z[2,1,2]
 FR BND1      z[2,1,3]
 FR BND1      z[2,1,4]
 FR BND1      z[2,1,5]
 FR BND1      z[2,1,6]
 FR BND1      z[1,5,0]
 FR BND1      z[1,5,1]
 FR BND1      z[1,5,2]
 FR BND1      z[1,5,3]
 FR BND1      z[1,5,4]
 FR BND1      z[1,5,5]
 FR BND1      z[1,5,6]
 FR BND1      z[5,1,0]
 FR BND1      z[5,1,1]
 FR BND1      z[5,1,2]
 FR BND1      z[5,1,3]
 FR BND1      z[5,1,4]
 FR BND1      z[5,1,5]
 FR BND1      z[5,1,6]
 FR BND1      z[2,3,0]
 FR BND1      z[2,3,1]
 FR BND1      z[2,3,2]
 FR BND1      z[2,3,3]
 FR BND1      z[2,3,4]
 FR BND1      z[2,3,5]
 FR BND1      z[2,3,6]
 FR BND1      z[3,2,0]
 FR BND1      z[3,2,1]
 FR BND1      z[3,2,2]
 FR BND1      z[3,2,3]
 FR BND1      z[3,2,4]
 FR BND1      z[3,2,5]
 FR BND1      z[3,2,6]
 FR BND1      z[2,6,0]
 FR BND1      z[2,6,1]
 FR BND1      z[2,6,2]
 FR BND1      z[2,6,3]
 FR BND1      z[2,6,4]
 FR BND1      z[2,6,5]
 FR BND1      z[2,6,6]
 FR BND1      z[6,2,0]
 FR BND1      z[6,2,1]
 FR BND1      z[6,2,2]
 FR BND1      z[6,2,3]
 FR BND1      z[6,2,4]
 FR BND1      z[6,2,5]
 FR BND1      z[6,2,6]
 FR BND1      z[2,7,0]
 FR BND1      z[2,7,1]
 FR BND1      z[2,7,2]
 FR BND1      z[2,7,3]
 FR BND1      z[2,7,4]
 FR BND1      z[2,7,5]
 FR BND1      z[2,7,6]
 FR BND1      z[7,2,0]
 FR BND1      z[7,2,1]
 FR BND1      z[7,2,2]
 FR BND1      z[7,2,3]
 FR BND1      z[7,2,4]
 FR BND1      z[7,2,5]
 FR BND1      z[7,2,6]
 FR BND1      z[3,6,0]
 FR BND1      z[3,6,1]
 FR BND1      z[3,6,2]
 FR BND1      z[3,6,3]
 FR BND1      z[3,6,4]
 FR BND1      z[3,6,5]
 FR BND1      z[3,6,6]
 FR BND1      z[6,3,0]
 FR BND1      z[6,3,1]
 FR BND1      z[6,3,2]
 FR BND1      z[6,3,3]
 FR BND1      z[6,3,4]
 FR BND1      z[6,3,5]
 FR BND1      z[6,3,6]
 FR BND1      z[3,7,0]
 FR BND1      z[3,7,1]
 FR BND1      z[3,7,2]
 FR BND1      z[3,7,3]
 FR BND1      z[3,7,4]
 FR BND1      z[3,7,5]
 FR BND1      z[3,7,6]
 FR BND1      z[7,3,0]
 FR BND1      z[7,3,1]
 FR BND1      z[7,3,2]
 FR BND1      z[7,3,3]
 FR BND1      z[7,3,4]
 FR BND1      z[7,3,5]
 FR BND1      z[7,3,6]
 FR BND1      z[4,5,0]
 FR BND1      z[4,5,1]
 FR BND1      z[4,5,2]
 FR BND1      z[4,5,3]
 FR BND1      z[4,5,4]
 FR BND1      z[4,5,5]
 FR BND1      z[4,5,6]
 FR BND1      z[5,4,0]
 FR BND1      z[5,4,1]
 FR BND1      z[5,4,2]
 FR BND1      z[5,4,3]
 FR BND1      z[5,4,4]
 FR BND1      z[5,4,5]
 FR BND1      z[5,4,6]
 FR BND1      z[5,6,0]
 FR BND1      z[5,6,1]
 FR BND1      z[5,6,2]
 FR BND1      z[5,6,3]
 FR BND1      z[5,6,4]
 FR BND1      z[5,6,5]
 FR BND1      z[5,6,6]
 FR BND1      z[6,5,0]
 FR BND1      z[6,5,1]
 FR BND1      z[6,5,2]
 FR BND1      z[6,5,3]
 FR BND1      z[6,5,4]
 FR BND1      z[6,5,5]
 FR BND1      z[6,5,6]
 FR BND1      z[6,7,0]
 FR BND1      z[6,7,1]
 FR BND1      z[6,7,2]
 FR BND1      z[6,7,3]
 FR BND1      z[6,7,4]
 FR BND1      z[6,7,5]
 FR BND1      z[6,7,6]
 FR BND1      z[7,6,0]
 FR BND1      z[7,6,1]
 FR BND1      z[7,6,2]
 FR BND1      z[7,6,3]
 FR BND1      z[7,6,4]
 FR BND1      z[7,6,5]
 FR BND1      z[7,6,6]
 FR BND1      delta[0,0]
 FR BND1      delta[0,1]
 FR BND1      delta[0,2]
 FR BND1      delta[0,3]
 FR BND1      delta[0,4]
 FR BND1      delta[0,5]
 FR BND1      delta[0,6]
 FR BND1      delta[1,0]
 FR BND1      delta[1,1]
 FR BND1      delta[1,2]
 FR BND1      delta[1,3]
 FR BND1      delta[1,4]
 FR BND1      delta[1,5]
 FR BND1      delta[1,6]
 FR BND1      delta[2,0]
 FR BND1      delta[2,1]
 FR BND1      delta[2,2]
 FR BND1      delta[2,3]
 FR BND1      delta[2,4]
 FR BND1      delta[2,5]
 FR BND1      delta[2,6]
 FR BND1      delta[3,0]
 FR BND1      delta[3,1]
 FR BND1      delta[3,2]
 FR BND1      delta[3,3]
 FR BND1      delta[3,4]
 FR BND1      delta[3,5]
 FR BND1      delta[3,6]
 FR BND1      delta[4,0]
 FR BND1      delta[4,1]
 FR BND1      delta[4,2]
 FR BND1      delta[4,3]
 FR BND1      delta[4,4]
 FR BND1      delta[4,5]
 FR BND1      delta[4,6]
 FR BND1      delta[5,0]
 FR BND1      delta[5,1]
 FR BND1      delta[5,2]
 FR BND1      delta[5,3]
 FR BND1      delta[5,4]
 FR BND1      delta[5,5]
 FR BND1      delta[5,6]
 FR BND1      delta[6,0]
 FR BND1      delta[6,1]
 FR BND1      delta[6,2]
 FR BND1      delta[6,3]
 FR BND1      delta[6,4]
 FR BND1      delta[6,5]
 FR BND1      delta[6,6]
 FR BND1      delta[7,0]
 FR BND1      delta[7,1]
 FR BND1      delta[7,2]
 FR BND1      delta[7,3]
 FR BND1      delta[7,4]
 FR BND1      delta[7,5]
 FR BND1      delta[7,6]
QCMATRIX   qc0     
    length[0]  length[0]  -1
    delta[0,0]  delta[0,0]  1
    delta[0,1]  delta[0,1]  1
    delta[0,2]  delta[0,2]  1
    delta[0,3]  delta[0,3]  1
    delta[0,4]  delta[0,4]  1
    delta[0,5]  delta[0,5]  1
    delta[0,6]  delta[0,6]  1
QCMATRIX   qc1     
    length[1]  length[1]  -1
    delta[1,0]  delta[1,0]  1
    delta[1,1]  delta[1,1]  1
    delta[1,2]  delta[1,2]  1
    delta[1,3]  delta[1,3]  1
    delta[1,4]  delta[1,4]  1
    delta[1,5]  delta[1,5]  1
    delta[1,6]  delta[1,6]  1
QCMATRIX   qc2     
    length[2]  length[2]  -1
    delta[2,0]  delta[2,0]  1
    delta[2,1]  delta[2,1]  1
    delta[2,2]  delta[2,2]  1
    delta[2,3]  delta[2,3]  1
    delta[2,4]  delta[2,4]  1
    delta[2,5]  delta[2,5]  1
    delta[2,6]  delta[2,6]  1
QCMATRIX   qc3     
    length[3]  length[3]  -1
    delta[3,0]  delta[3,0]  1
    delta[3,1]  delta[3,1]  1
    delta[3,2]  delta[3,2]  1
    delta[3,3]  delta[3,3]  1
    delta[3,4]  delta[3,4]  1
    delta[3,5]  delta[3,5]  1
    delta[3,6]  delta[3,6]  1
QCMATRIX   qc4     
    length[4]  length[4]  -1
    delta[4,0]  delta[4,0]  1
    delta[4,1]  delta[4,1]  1
    delta[4,2]  delta[4,2]  1
    delta[4,3]  delta[4,3]  1
    delta[4,4]  delta[4,4]  1
    delta[4,5]  delta[4,5]  1
    delta[4,6]  delta[4,6]  1
QCMATRIX   qc5     
    length[5]  length[5]  -1
    delta[5,0]  delta[5,0]  1
    delta[5,1]  delta[5,1]  1
    delta[5,2]  delta[5,2]  1
    delta[5,3]  delta[5,3]  1
    delta[5,4]  delta[5,4]  1
    delta[5,5]  delta[5,5]  1
    delta[5,6]  delta[5,6]  1
QCMATRIX   qc6     
    length[6]  length[6]  -1
    delta[6,0]  delta[6,0]  1
    delta[6,1]  delta[6,1]  1
    delta[6,2]  delta[6,2]  1
    delta[6,3]  delta[6,3]  1
    delta[6,4]  delta[6,4]  1
    delta[6,5]  delta[6,5]  1
    delta[6,6]  delta[6,6]  1
QCMATRIX   qc7     
    length[7]  length[7]  -1
    delta[7,0]  delta[7,0]  1
    delta[7,1]  delta[7,1]  1
    delta[7,2]  delta[7,2]  1
    delta[7,3]  delta[7,3]  1
    delta[7,4]  delta[7,4]  1
    delta[7,5]  delta[7,5]  1
    delta[7,6]  delta[7,6]  1
ENDATA
